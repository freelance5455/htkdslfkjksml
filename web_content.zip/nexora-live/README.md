# NEXORA — Production Integration V3

هذه النسخة مبنية على NEXORA V2 وتحافظ على الواجهة الحالية.

## ما تم تجهيزه

- Production payment flow: إنشاء عملية دفع عبر Jawwal Pay أو مزود بطاقات قابل للتهيئة، مع `Idempotency-Key`.
- Webhooks موقعة HMAC + منع التكرار + التحقق من قيمة المبلغ قبل اعتماد الدفع.
- تعطيل `/api/payments/confirm` يدويًا في وضع production.
- Split ledger: عند التسليم تُخصم العمولة محاسبيًا ويُضاف صافي البائع إلى محفظته الداخلية، ثم يُنشأ payout job خارجي. لا يتم ادعاء تحويل مالي حقيقي بدون مزود payout فعلي.
- Payout worker كل 15 ثانية عند إعداد `PAYOUT_API_URL`.
- Socket.io chat + order/payment events.
- Order tracking statuses: paid → processing → shipped → out_for_delivery → delivered.
- Cloudinary أو Amazon S3 للصور مع ضغط WebP قبل التخزين.
- SMS/OTP حقيقي عبر مزود SMS متوافق مع endpoint المحدد في `.env`.
- Founder password + TOTP 2FA.
- NEXORA AI عبر OpenAI-compatible API.
- Web Push + PWA shell بدون Offline App Cache؛ التطبيق يظل Online-only.
- PDF invoices + SMTP email.

## تشغيل

1. Node.js 20+.
2. انسخ `.env.example` إلى `.env`.
3. ضع بيانات الإنتاج الحقيقية من مزود الدفع وSMS والتخزين والبريد وAI.
4. شغّل:

```bash
npm install
npm start
```

## الدفع الحقيقي

لا توجد بيانات API عامة يمكن تخمينها أو اختراعها لـ Jawwal Pay. يجب أن تحصل NEXORA على بيانات التاجر الرسمية/مفتاح API وSecret وWebhook contract من Jawwal Pay. توجد خدمات Jawwal Pay للأعمال والتسوق الإلكتروني، لكن تفاصيل API الخاصة بالتاجر ليست منشورة بشكل كافٍ لبناء endpoint production صحيح من دون عقد المزود.

لذلك:

- `JAWALPAY_API_URL` = endpoint الذي يعطيه لك Jawwal Pay.
- `JAWALPAY_API_TOKEN` = token التجاري.
- `JAWALPAY_WEBHOOK_SECRET` = secret الذي يعطيه المزود.
- `JAWALPAY_CREATE_URL` = endpoint إنشاء الدفع إن كان مختلفًا عن base URL.

وبالنسبة للبطاقات، استخدم مزود بطاقات يدعم بلد التاجر، ثم ضع endpoint/token/webhook secret الخاص به في متغيرات `CARD_GATEWAY_*`.

## Split / Payout

`PAYOUT_API_URL` يجب أن يكون API مزود التحويل الفعلي للبائعين. بدون هذا المتغير، النظام لا يرسل أموالًا خارجية؛ يحتفظ بالعملية كـ `queued` حتى لا يتم تزوير أو فقدان أموال.

## Cloud Storage

اختر Cloudinary أو S3. في production يتم رفض التخزين المحلي ما لم تضبط `ALLOW_LOCAL_UPLOADS=true` صراحة.

## Push Notifications

ضع VAPID public/private keys ثم يستطيع المتصفح تسجيل Push Subscription. الـ service worker لا يخزن نسخة Offline من التطبيق، لأن NEXORA Online-only.

## اختبار أمان الدفع

لا تستخدم `/api/payments/confirm` في production. اختبر فقط عبر webhook حقيقي أو sandbox للمزود. الـ webhook يتحقق من:

- HMAC signature
- event idempotency
- وجود الطلب
- تطابق مبلغ العملية
- عدم إعادة تسليم الطلب

## ملاحظة مهمة

الملف البرمجي جاهز لنقاط الربط الإنتاجية، لكن **تفعيل حركة أموال حقيقية لا يمكن أن يتم بدون حساب تاجر ومفاتيح API وعقد Webhook من Jawwal Pay/مزود البطاقات ومزود payout**. لا يتم اختلاق هذه البيانات داخل المشروع.
