# NEXORA V2 deployment status

| Area | Status |
|---|---|
| Online-only | Implemented |
| Founder today-control | Implemented |
| Founder TOTP 2FA | Implemented; requires secret configuration |
| OTP/SMS | Provider adapter implemented; credentials required |
| Socket.io chat | Implemented |
| Multi-image upload/compression | Implemented (local storage) |
| Cloudinary/S3 | Adapter point prepared; provider credentials/adapter required |
| Tracking timeline | Implemented |
| Delivery-triggered seller settlement | Implemented as internal ledger + payout queue |
| Jawwal Pay live API | Integration endpoint prepared; official merchant API credentials required |
| Card live API | Generic gateway adapter prepared; gateway credentials required |
| PDF invoice | Implemented |
| Email invoice | Implemented when SMTP is configured |
| AI | OpenAI-compatible adapter implemented; API key required |
| PostgreSQL | Target schema + migration script included; runtime adapter still needs deployment switch |
| Native/PWA | Web app remains suitable for PWA packaging, with online-only behavior |
