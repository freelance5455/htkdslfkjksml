import express from 'express';
import http from 'http';
import multer from 'multer';
import sharp from 'sharp';
import nodemailer from 'nodemailer';
import PDFDocument from 'pdfkit';
import speakeasy from 'speakeasy';
import { Server as SocketIOServer } from 'socket.io';
import Database from 'better-sqlite3';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import crypto from 'crypto';
import fs from 'fs';
import path from 'path';
import webpush from 'web-push';
import { S3Client, PutObjectCommand } from '@aws-sdk/client-s3';
import { v2 as cloudinary } from 'cloudinary';

const app=express();
const PORT=Number(process.env.PORT||3000);
const JWT_SECRET=process.env.JWT_SECRET||crypto.randomBytes(32).toString('hex');
const db=new Database(process.env.DB_PATH||path.join(process.cwd(),'nexora.db'));
db.pragma('foreign_keys=ON');
app.use(express.json({limit:'2mb',verify:(req,res,buf)=>{req.rawBody=Buffer.from(buf)}}));
app.use(express.static(process.cwd(), { etag: true, maxAge: 0 }));
app.use('/uploads', express.static(path.join(process.cwd(),'uploads')));
app.use('/invoices', express.static(path.join(process.cwd(),'invoices')));

// NEXORA is intentionally online-only: the UI must have network + API access.
app.get('/api/online-check',(req,res)=>res.set('Cache-Control','no-store').json({ok:true,online:true,time:now()}));
const now=()=>new Date().toISOString();
const id=p=>`${p}-${crypto.randomBytes(7).toString('hex')}`;
function auth(req,res,next){try{const h=req.headers.authorization||'';if(!h.startsWith('Bearer '))throw 0;req.user=jwt.verify(h.slice(7),JWT_SECRET);next()}catch{res.status(401).json({error:'Authentication required'})}}
function admin(req,res,next){if(['founder','admin'].includes(req.user?.role))return next();res.status(403).json({error:'Admin access required'})}
function issue(u){return jwt.sign({sub:u.id,role:u.role,email:u.email},JWT_SECRET,{expiresIn:'30d'})}
function ensureGuest(device){let u=db.prepare('SELECT * FROM users WHERE email=?').get(`device-${device}@guest.nexora`);if(!u){const uid=id('USR');db.prepare('INSERT INTO users(id,name,email,password_hash,role,status,verified,created_at) VALUES(?,?,?,?,?,?,?,?)').run(uid,'زائر NEXORA',`device-${device}@guest.nexora`,null,'buyer','active',0,now());u=db.prepare('SELECT * FROM users WHERE id=?').get(uid)}return u}
function seedDemo(){
  if(db.prepare('SELECT COUNT(*) n FROM products').get().n>0)return;
  let u=db.prepare("SELECT * FROM users WHERE email='demo-seller@nexora.local'").get();
  if(!u){const uid=id('USR');db.prepare('INSERT INTO users(id,name,email,role,status,verified,created_at) VALUES(?,?,?,?,?,?,?)').run(uid,'NEXORA Demo Seller','demo-seller@nexora.local','seller','active',1,now());u=db.prepare('SELECT * FROM users WHERE id=?').get(uid)}
  let seller=db.prepare('SELECT * FROM sellers WHERE user_id=?').get(u.id);if(!seller){const sid=id('SEL');db.prepare('INSERT INTO sellers(id,user_id,store_name,description,status,rating,total_sales,commission_rate,created_at) VALUES(?,?,?,?,?,?,?,?,?)').run(sid,u.id,'NEXORA Demo Store','منتجات تجريبية للواجهة','active',5,0,.10,now());seller=db.prepare('SELECT * FROM sellers WHERE id=?').get(sid)}
  const items=[['سماعات لاسلكية','Tech',79,'🎧'],['حقيبة يومية','Fashion',54,'🎒'],['مصباح مكتب ذكي','Home',39,'💡'],['ساعة كلاسيكية','Accessories',129,'⌚'],['لوحة مفاتيح ميكانيكية','Tech',99,'⌨️'],['حذاء رياضي','Fashion',89,'👟'],['طقم سيراميك','Home',45,'🏺'],['محفظة جلدية','Accessories',32,'👛']];
  for(const [name,cat,price,icon] of items){let c=db.prepare('SELECT id FROM categories WHERE name=?').get(cat);if(!c){const cid=id('CAT');db.prepare('INSERT INTO categories(id,name,status) VALUES(?,?,?)').run(cid,cat,'active');c={id:cid}}const pid=id('PRD');db.prepare('INSERT INTO products(id,seller_id,category_id,name,description,price,stock,condition,status,views,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)').run(pid,seller.id,c.id,name,'منتج تجريبي في NEXORA',price,25,'new','active',0,now())}
}
seedDemo();
function ensureCart(uid){let c=db.prepare('SELECT * FROM carts WHERE user_id=?').get(uid);if(!c){const cid=id('CRT');db.prepare('INSERT INTO carts(id,user_id,created_at,updated_at) VALUES(?,?,?,?)').run(cid,uid,now(),now());return cid}return c.id}

app.post('/api/bootstrap',(req,res)=>{const device=String(req.body?.device||'').replace(/[^a-zA-Z0-9_-]/g,'').slice(0,80)||crypto.randomUUID();const u=ensureGuest(device);ensureCart(u.id);res.json({token:issue(u),user:{id:u.id,name:u.name,email:u.email,role:u.role,verified:!!u.verified}})});
app.post('/api/auth/register',(req,res)=>{const {name,email,password,role='buyer'}=req.body||{};if(!name||!email||!password||password.length<8)return res.status(400).json({error:'بيانات التسجيل غير مكتملة'});if(!['buyer','seller'].includes(role))return res.status(400).json({error:'دور غير صالح'});if(db.prepare('SELECT id FROM users WHERE email=?').get(email.toLowerCase()))return res.status(409).json({error:'الحساب موجود'});const uid=id('USR');db.prepare('INSERT INTO users(id,name,email,password_hash,role,status,created_at) VALUES(?,?,?,?,?,?,?)').run(uid,name,email.toLowerCase(),bcrypt.hashSync(password,12),role,'active',now());ensureCart(uid);const u=db.prepare('SELECT * FROM users WHERE id=?').get(uid);res.json({token:issue(u),user:{id:u.id,name:u.name,email:u.email,role:u.role}})});
app.post('/api/auth/login',(req,res)=>{const {email,password}=req.body||{};const u=db.prepare('SELECT * FROM users WHERE email=?').get(String(email||'').toLowerCase());if(!u||!u.password_hash||!bcrypt.compareSync(password||'',u.password_hash))return res.status(401).json({error:'بيانات الدخول غير صحيحة'});db.prepare('UPDATE users SET last_login=? WHERE id=?').run(now(),u.id);res.json({token:issue(u),user:{id:u.id,name:u.name,email:u.email,role:u.role,verified:!!u.verified}})});
app.get('/api/me',auth,(req,res)=>{const u=db.prepare('SELECT id,name,email,phone,role,status,verified,created_at,last_login FROM users WHERE id=?').get(req.user.sub);res.json({user:u})});
app.put('/api/me',auth,(req,res)=>{const {name,email,phone}=req.body||{};db.prepare('UPDATE users SET name=COALESCE(?,name),email=COALESCE(?,email),phone=COALESCE(?,phone) WHERE id=?').run(name||null,email||null,phone||null,req.user.sub);res.json({user:db.prepare('SELECT id,name,email,phone,role,verified FROM users WHERE id=?').get(req.user.sub)})});

app.get('/api/products',(req,res)=>res.json({products:db.prepare(`SELECT p.*,s.store_name seller_name,c.name category_name FROM products p LEFT JOIN sellers s ON s.id=p.seller_id LEFT JOIN categories c ON c.id=p.category_id WHERE p.status='active' ORDER BY p.created_at DESC`).all()}));
app.post('/api/products',auth,(req,res)=>{if(!['seller','admin','founder'].includes(req.user.role))return res.status(403).json({error:'Seller access required'});const {name,category='Other',price,stock=0,description='',condition='new'}=req.body||{};if(!name||!Number.isFinite(Number(price)))return res.status(400).json({error:'بيانات المنتج غير مكتملة'});let seller=db.prepare('SELECT * FROM sellers WHERE user_id=?').get(req.user.sub);if(!seller){const sid=id('SEL');db.prepare('INSERT INTO sellers(id,user_id,store_name,status,created_at) VALUES(?,?,?,?,?)').run(sid,req.user.sub,name+' Store','active',now());seller=db.prepare('SELECT * FROM sellers WHERE id=?').get(sid)}let cat=db.prepare('SELECT id FROM categories WHERE name=?').get(category);if(!cat){const cid=id('CAT');db.prepare('INSERT INTO categories(id,name,status) VALUES(?,?,?)').run(cid,category,'active');cat={id:cid}}const pid=id('PRD');db.prepare('INSERT INTO products(id,seller_id,category_id,name,description,price,stock,condition,status,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)').run(pid,seller.id,cat.id,name,description,Number(price),Number(stock),condition,'active',now());res.status(201).json({id:pid})});

app.get('/api/cart',auth,(req,res)=>{const cid=ensureCart(req.user.sub);res.json({items:db.prepare(`SELECT ci.id,ci.product_id,ci.quantity,p.name,p.price,s.store_name seller FROM cart_items ci JOIN products p ON p.id=ci.product_id LEFT JOIN sellers s ON s.id=p.seller_id WHERE ci.cart_id=?`).all(cid)})});
app.post('/api/cart',auth,(req,res)=>{const {productId,quantity=1}=req.body||{};const p=db.prepare("SELECT id FROM products WHERE id=? AND status='active'").get(productId);if(!p)return res.status(404).json({error:'Product not found'});const cid=ensureCart(req.user.sub);db.prepare(`INSERT INTO cart_items(id,cart_id,product_id,quantity,created_at) VALUES(?,?,?,?,?) ON CONFLICT(cart_id,product_id) DO UPDATE SET quantity=quantity+excluded.quantity`).run(id('ITM'),cid,productId,Math.max(1,Number(quantity)),now());res.json({ok:true})});
app.patch('/api/cart/:id',auth,(req,res)=>{const q=Math.max(0,Number(req.body?.quantity));const cid=ensureCart(req.user.sub);if(q===0)db.prepare('DELETE FROM cart_items WHERE id=? AND cart_id=?').run(req.params.id,cid);else db.prepare('UPDATE cart_items SET quantity=? WHERE id=? AND cart_id=?').run(q,req.params.id,cid);res.json({ok:true})});
app.delete('/api/cart',auth,(req,res)=>{const cid=ensureCart(req.user.sub);db.prepare('DELETE FROM cart_items WHERE cart_id=?').run(cid);res.json({ok:true})});

app.get('/api/orders',auth,(req,res)=>{const rows=req.user.role==='buyer'?db.prepare(`SELECT o.*,p.name product FROM orders o JOIN products p ON p.id=o.product_id WHERE o.buyer_id=? ORDER BY o.created_at DESC`).all(req.user.sub):db.prepare(`SELECT o.*,p.name product FROM orders o JOIN products p ON p.id=o.product_id WHERE o.seller_id=(SELECT id FROM sellers WHERE user_id=?) ORDER BY o.created_at DESC`).all(req.user.sub);res.json({orders:rows})});
app.post('/api/orders',auth,(req,res)=>{const {productId,quantity=1,paymentMethod='pending',deliveryText='',addressId=null}=req.body||{};const p=db.prepare('SELECT p.*,s.id seller_id,c.name category_name FROM products p JOIN sellers s ON s.id=p.seller_id LEFT JOIN categories c ON c.id=p.category_id WHERE p.id=? AND p.status="active"').get(productId);if(!p)return res.status(404).json({error:'المنتج غير موجود'});const q=Math.max(1,Number(quantity));if(p.stock<q)return res.status(409).json({error:'المخزون غير كاف'});const amount=Number((p.price*q).toFixed(2));const rates={Tech:.07,Fashion:.12,Home:.10,Accessories:.12,Digital:.18};const rate=rates[p.category_name]??.10;const commission=Number((amount*rate).toFixed(2));const sellerNet=amount-commission;const oid=id('ORD');const tx=db.transaction(()=>{db.prepare('UPDATE products SET stock=stock-?,views=views+1 WHERE id=?').run(q,p.id);db.prepare(`INSERT INTO orders(id,buyer_id,product_id,seller_id,quantity,unit_price,amount,commission,seller_net,status,delivery_address_id,delivery_text,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)`).run(oid,req.user.sub,p.id,p.seller_id,q,p.price,amount,commission,sellerNet,'pending_payment',addressId,deliveryText,now());db.prepare('INSERT INTO payments(id,order_id,method,amount,status,created_at) VALUES(?,?,?,?,?,?)').run(id('PAY'),oid,paymentMethod,amount,'pending',now());});tx();res.status(201).json({orderId:oid,amount,commission,sellerNet})});
app.post('/api/payments/confirm',auth,(req,res)=>{if(String(process.env.PAYMENT_MODE||'production')==='production')return res.status(410).json({error:'Manual payment confirmation is disabled in production; use provider webhook.'});const {orderId,providerReference=''}=req.body||{};const p=db.prepare('SELECT * FROM payments WHERE order_id=? ORDER BY created_at DESC LIMIT 1').get(orderId);if(!p)return res.status(404).json({error:'Payment not found'});db.prepare('UPDATE payments SET status=?,provider_reference=?,updated_at=? WHERE id=?').run('confirmed',providerReference,now(),p.id);db.prepare('UPDATE orders SET status=?,updated_at=? WHERE id=?').run('paid',now(),orderId);res.json({ok:true})});

app.post('/api/favorites',auth,(req,res)=>{const {productId}=req.body||{};const ex=db.prepare('SELECT id FROM favorites WHERE user_id=? AND product_id=?').get(req.user.sub,productId);if(ex)db.prepare('DELETE FROM favorites WHERE id=?').run(ex.id);else db.prepare('INSERT INTO favorites(id,user_id,product_id,created_at) VALUES(?,?,?,?)').run(id('FAV'),req.user.sub,productId,now());res.json({ok:true})});
app.get('/api/favorites',auth,(req,res)=>res.json({items:db.prepare(`SELECT f.id,p.id product_id,p.name,p.price,s.store_name seller FROM favorites f JOIN products p ON p.id=f.product_id LEFT JOIN sellers s ON s.id=p.seller_id WHERE f.user_id=?`).all(req.user.sub)}));
app.post('/api/messages',auth,(req,res)=>{const {receiverId,body,orderId=null}=req.body||{};if(!receiverId||!body)return res.status(400).json({error:'Message required'});const mid=id('MSG');db.prepare('INSERT INTO messages(id,sender_id,receiver_id,order_id,body,created_at) VALUES(?,?,?,?,?,?)').run(mid,req.user.sub,receiverId,orderId,body,now());res.json({id:mid})});
app.get('/api/messages',auth,(req,res)=>res.json({messages:db.prepare(`SELECT m.*,u.name sender_name FROM messages m JOIN users u ON u.id=m.sender_id WHERE m.sender_id=? OR m.receiver_id=? ORDER BY m.created_at DESC`).all(req.user.sub,req.user.sub)}));
app.post('/api/reviews',auth,(req,res)=>{const {orderId,rating,body=''}=req.body||{};const o=db.prepare('SELECT * FROM orders WHERE id=? AND buyer_id=?').get(orderId,req.user.sub);const r=Math.trunc(Number(rating));if(!o||!['paid','processing','shipped','delivered'].includes(o.status)||r<1||r>5)return res.status(400).json({error:'Review not allowed'});const rid=id('REV');db.prepare('INSERT INTO reviews(id,order_id,buyer_id,product_id,rating,body,status,created_at) VALUES(?,?,?,?,?,?,?,?)').run(rid,orderId,req.user.sub,o.product_id,r,body,'published',now());res.status(201).json({id:rid})});
app.post('/api/addresses',auth,(req,res)=>{const {label='العنوان',address_text,city='غزة',lat=null,lng=null,is_default=0}=req.body||{};if(!address_text)return res.status(400).json({error:'Address required'});const aid=id('ADR');if(is_default)db.prepare('UPDATE addresses SET is_default=0 WHERE user_id=?').run(req.user.sub);db.prepare('INSERT INTO addresses(id,user_id,label,address_text,city,lat,lng,is_default,created_at) VALUES(?,?,?,?,?,?,?,?,?)').run(aid,req.user.sub,label,address_text,city,lat,lng,is_default,now());res.json({id:aid})});
app.get('/api/addresses',auth,(req,res)=>res.json({addresses:db.prepare('SELECT * FROM addresses WHERE user_id=? ORDER BY created_at DESC').all(req.user.sub)}));
app.get('/api/notifications',auth,(req,res)=>res.json({notifications:db.prepare('SELECT * FROM notifications WHERE user_id=? ORDER BY created_at DESC').all(req.user.sub)}));
app.post('/api/notifications/read',auth,(req,res)=>{db.prepare('UPDATE notifications SET read_at=? WHERE user_id=?').run(now(),req.user.sub);res.json({ok:true})});
app.get('/api/admin/overview',auth,admin,(req,res)=>{const count=t=>db.prepare(`SELECT COUNT(*) n FROM ${t}`).get().n;const sales=db.prepare("SELECT COALESCE(SUM(amount),0) n FROM orders WHERE status IN ('paid','processing','shipped','delivered')").get().n;const commissions=db.prepare('SELECT COALESCE(SUM(commission),0) n FROM orders').get().n;res.json({users:count('users'),sellers:count('sellers'),products:count('products'),orders:count('orders'),payments:count('payments'),reviews:count('reviews'),sales,commissions})});



// ---------- Production infrastructure adapters ----------
const uploadsDir=path.join(process.cwd(),'uploads');
const invoicesDir=path.join(process.cwd(),'invoices');
fs.mkdirSync(uploadsDir,{recursive:true}); fs.mkdirSync(invoicesDir,{recursive:true});
const upload=multer({storage:multer.memoryStorage(),limits:{files:8,fileSize:10*1024*1024}});
const otpStore=new Map();
const ioServer=http.createServer(app);
const io=new SocketIOServer(ioServer,{cors:{origin:process.env.PUBLIC_ORIGIN||'*',methods:['GET','POST']}});
const onlineUsers=new Map();

function audit(actorId,action,entityType='',entityId='',meta={}){
  try{db.prepare('INSERT INTO audit_log(id,actor_id,action,entity_type,entity_id,meta_json,created_at) VALUES(?,?,?,?,?,?,?)').run(id('AUD'),actorId||null,action,entityType||null,entityId||null,JSON.stringify(meta),now())}catch{}
}
function ensureInfraSchema(){
  const stmts=[
    `CREATE TABLE IF NOT EXISTS otp_codes(id TEXT PRIMARY KEY,user_id TEXT,phone TEXT NOT NULL,code_hash TEXT NOT NULL,expires_at TEXT NOT NULL,attempts INTEGER DEFAULT 0,verified_at TEXT,created_at TEXT NOT NULL)`,
    `CREATE TABLE IF NOT EXISTS product_images(id TEXT PRIMARY KEY,product_id TEXT NOT NULL,url TEXT NOT NULL,storage_key TEXT,sort_order INTEGER DEFAULT 0,created_at TEXT NOT NULL,FOREIGN KEY(product_id) REFERENCES products(id) ON DELETE CASCADE)`,
    `CREATE TABLE IF NOT EXISTS payment_webhooks(id TEXT PRIMARY KEY,provider TEXT NOT NULL,event_id TEXT,signature TEXT,status TEXT NOT NULL,payload_json TEXT,created_at TEXT NOT NULL,processed_at TEXT)`,
    `CREATE TABLE IF NOT EXISTS payout_jobs(id TEXT PRIMARY KEY,order_id TEXT NOT NULL, seller_id TEXT NOT NULL,amount REAL NOT NULL,status TEXT NOT NULL,provider_reference TEXT,created_at TEXT NOT NULL,updated_at TEXT,FOREIGN KEY(order_id) REFERENCES orders(id))`,
    `CREATE TABLE IF NOT EXISTS chat_reads(id TEXT PRIMARY KEY,message_id TEXT NOT NULL,user_id TEXT NOT NULL,read_at TEXT NOT NULL,UNIQUE(message_id,user_id))`
  ]; for(const q of stmts) db.exec(q);
}
ensureInfraSchema();

function safeJson(v){try{return JSON.parse(v||'{}')}catch{return {}}}
function hmac(value,secret){return crypto.createHmac('sha256',secret).update(value).digest('hex')}
function timingSafe(a,b){try{return crypto.timingSafeEqual(Buffer.from(a),Buffer.from(b))}catch{return false}}

async function sendSms(phone,message){
  if(!process.env.SMS_API_URL||!process.env.SMS_API_TOKEN) throw new Error('SMS provider is not configured');
  const r=await fetch(process.env.SMS_API_URL,{method:'POST',headers:{'content-type':'application/json','authorization':`Bearer ${process.env.SMS_API_TOKEN}`},body:JSON.stringify({to:phone,message})});
  if(!r.ok) throw new Error(`SMS provider returned ${r.status}`); return true;
}
function smtp(){if(!process.env.SMTP_HOST)return null;return nodemailer.createTransport({host:process.env.SMTP_HOST,port:Number(process.env.SMTP_PORT||587),secure:String(process.env.SMTP_SECURE||'false')==='true',auth:process.env.SMTP_USER?{user:process.env.SMTP_USER,pass:process.env.SMTP_PASS}:undefined})}
function invoicePdf(order,user){return new Promise((resolve,reject)=>{const filename=`invoice-${order.id}.pdf`,file=path.join(invoicesDir,filename),doc=new PDFDocument({margin:50});const out=fs.createWriteStream(file);doc.pipe(out);doc.fontSize(22).text('NEXORA',{align:'center'});doc.moveDown();doc.fontSize(14).text('Purchase Invoice',{align:'center'});doc.moveDown();doc.fontSize(10).text(`Order: ${order.id}`);doc.text(`Date: ${order.created_at}`);doc.text(`Customer: ${user.name||'-'}`);doc.text(`Email: ${user.email||'-'}`);doc.moveDown();doc.fontSize(12).text(`Product: ${order.product||order.product_name||'-'}`);doc.text(`Quantity: ${order.quantity}`);doc.text(`Unit price: $${Number(order.unit_price).toFixed(2)}`);doc.text(`Total: $${Number(order.amount).toFixed(2)}`);doc.text(`Platform commission: $${Number(order.commission).toFixed(2)}`);doc.text(`Seller net: $${Number(order.seller_net).toFixed(2)}`);doc.moveDown();doc.fontSize(9).text('NEXORA electronic receipt. Payment status is based on the platform payment record.');doc.end();out.on('finish',()=>resolve({filename,url:`/invoices/${filename}`,file}));out.on('error',reject)})}
async function emailInvoice(orderId){
  const row=db.prepare(`SELECT o.*,p.name product,u.name buyer_name,u.email buyer_email FROM orders o JOIN products p ON p.id=o.product_id JOIN users u ON u.id=o.buyer_id WHERE o.id=?`).get(orderId); if(!row)return;
  const user={name:row.buyer_name,email:row.buyer_email}; const pdf=await invoicePdf(row,user); const mail=smtp(); if(mail && user.email){await mail.sendMail({from:process.env.SMTP_FROM||process.env.SMTP_USER,to:user.email,subject:`NEXORA Invoice ${orderId}`,text:'Thank you for your NEXORA order.',attachments:[{filename:pdf.filename,path:pdf.file}]})} return pdf;
}

function providerConfig(provider){
  if(provider==='jawwal') return {base:process.env.JAWALPAY_API_URL,token:process.env.JAWALPAY_API_TOKEN};
  if(provider==='card') return {base:process.env.CARD_GATEWAY_API_URL,token:process.env.CARD_GATEWAY_API_TOKEN};
  throw new Error('Unsupported payment provider');
}
async function paymentProviderRequest(provider,payload){
  const {base,token}=providerConfig(provider);
  if(!base||!token) throw new Error(`${provider} production credentials are not configured`);
  const url=process.env[provider==='jawwal'?'JAWALPAY_CREATE_URL':'CARD_GATEWAY_CREATE_URL']||base;
  const headers={'content-type':'application/json','authorization':`Bearer ${token}`,'idempotency-key':payload.orderId};
  const r=await fetch(url,{method:'POST',headers,body:JSON.stringify(payload)});
  const txt=await r.text(); let data; try{data=JSON.parse(txt)}catch{data={raw:txt}};
  if(!r.ok)throw new Error(data.error||data.message||`Provider HTTP ${r.status}`);
  return data;
}
async function payoutProviderRequest(order){
  const url=process.env.PAYOUT_API_URL, token=process.env.PAYOUT_API_TOKEN;
  if(!url||!token) return {status:'queued',reference:null,external:false};
  const r=await fetch(url,{method:'POST',headers:{'content-type':'application/json','authorization':`Bearer ${token}`,'idempotency-key':`payout-${order.id}`},body:JSON.stringify({orderId:order.id,sellerId:order.seller_id,amount:order.seller_net,currency:process.env.PAYOUT_CURRENCY||'USD'})});
  const txt=await r.text(); let data; try{data=JSON.parse(txt)}catch{data={raw:txt}};
  if(!r.ok) throw new Error(data.error||data.message||`Payout HTTP ${r.status}`);
  return {status:data.status||'submitted',reference:data.reference||data.id||null,external:true};
}
function settleOrder(orderId,actorId='system'){
  const order=db.prepare('SELECT * FROM orders WHERE id=?').get(orderId); if(!order||order.status==='delivered')return false;
  const seller=db.prepare('SELECT * FROM sellers WHERE id=?').get(order.seller_id); if(!seller)return false;
  const tx=db.transaction(()=>{
    db.prepare('UPDATE orders SET status=?,updated_at=? WHERE id=?').run('delivered',now(),orderId);
    let w=db.prepare('SELECT * FROM wallets WHERE user_id=(SELECT user_id FROM sellers WHERE id=?)').get(order.seller_id);
    if(!w){const wid=id('WAL'); const su=db.prepare('SELECT user_id FROM sellers WHERE id=?').get(order.seller_id);db.prepare('INSERT INTO wallets(id,user_id,balance,pending,earnings,fees,updated_at) VALUES(?,?,?,?,?,?,?)').run(wid,su.user_id,0,0,0,0,now());w=db.prepare('SELECT * FROM wallets WHERE id=?').get(wid)}
    db.prepare('UPDATE wallets SET balance=balance+?,earnings=earnings+?,pending=MAX(0,pending-?),updated_at=? WHERE id=?').run(order.seller_net,order.seller_net,order.seller_net,now(),w.id);
    db.prepare('INSERT INTO wallet_transactions(id,wallet_id,type,amount,reference_type,reference_id,description,created_at) VALUES(?,?,?,?,?,?,?,?)').run(id('WTX'),w.id,'credit',order.seller_net,'order',orderId,'Seller balance credited after delivery',now());
    db.prepare('INSERT OR IGNORE INTO payout_jobs(id,order_id,seller_id,amount,status,created_at,updated_at) VALUES(?,?,?,?,?,?,?)').run(id('PYO'),orderId,order.seller_id,order.seller_net,'queued',now(),now());
    db.prepare('INSERT INTO notifications(id,user_id,title,body,created_at) SELECT ?,user_id,?,?,? FROM sellers WHERE id=?').run(id('NOT'), 'تم تسليم الطلب','تمت إضافة مستحقات البائع إلى محفظته الداخلية.',now(),order.seller_id);
  }); tx(); audit(actorId,'order.delivered','order',orderId,{amount:order.amount,sellerNet:order.seller_net}); return true;
}


// Real-time chat: messages are persisted first, then broadcast.
io.on('connection',socket=>{
  socket.on('auth',token=>{try{const u=jwt.verify(token,JWT_SECRET);socket.user=u;onlineUsers.set(u.sub,socket.id);socket.join(`user:${u.sub}`)}catch{socket.disconnect(true)}});
  socket.on('chat:message',async payload=>{try{if(!socket.user)return;const {receiverId,body,orderId=null}=payload||{};if(!receiverId||!body)return;const mid=id('MSG');db.prepare('INSERT INTO messages(id,sender_id,receiver_id,order_id,body,created_at) VALUES(?,?,?,?,?,?)').run(mid,socket.user.sub,receiverId,orderId,String(body).slice(0,5000),now());const msg=db.prepare('SELECT m.*,u.name sender_name FROM messages m JOIN users u ON u.id=m.sender_id WHERE m.id=?').get(mid);io.to(`user:${receiverId}`).emit('chat:message',msg);socket.emit('chat:message',msg);audit(socket.user.sub,'message.sent','message',mid,{receiverId})}catch(e){socket.emit('chat:error',{error:e.message})}});
  socket.on('disconnect',()=>{if(socket.user)onlineUsers.delete(socket.user.sub)});
});

// OTP/SMS authentication.
app.post('/api/auth/request-otp',async(req,res)=>{try{const phone=String(req.body?.phone||'').trim();if(!/^\+?[0-9]{8,15}$/.test(phone))return res.status(400).json({error:'رقم الهاتف غير صالح'});const code=String(crypto.randomInt(100000,1000000));const hash=crypto.createHash('sha256').update(code+(process.env.OTP_PEPPER||'')).digest('hex');const uid=db.prepare('SELECT id FROM users WHERE phone=?').get(phone)?.id||null;db.prepare('INSERT INTO otp_codes(id,user_id,phone,code_hash,expires_at,attempts,created_at) VALUES(?,?,?,?,?,?,?)').run(id('OTP'),uid,phone,hash,new Date(Date.now()+5*60*1000).toISOString(),0,now());await sendSms(phone,`NEXORA verification code: ${code}`);res.json({ok:true,expiresIn:300})}catch(e){res.status(503).json({error:e.message})}});
app.post('/api/auth/verify-otp',async(req,res)=>{const phone=String(req.body?.phone||'').trim(),code=String(req.body?.code||'');const row=db.prepare('SELECT * FROM otp_codes WHERE phone=? AND verified_at IS NULL ORDER BY created_at DESC LIMIT 1').get(phone);if(!row||new Date(row.expires_at)<new Date()||row.attempts>=5)return res.status(401).json({error:'رمز منتهي أو غير صالح'});const hash=crypto.createHash('sha256').update(code+(process.env.OTP_PEPPER||'')).digest('hex');db.prepare('UPDATE otp_codes SET attempts=attempts+1 WHERE id=?').run(row.id);if(!timingSafe(hash,row.code_hash))return res.status(401).json({error:'رمز غير صحيح'});db.prepare('UPDATE otp_codes SET verified_at=? WHERE id=?').run(now(),row.id);let u=db.prepare('SELECT * FROM users WHERE phone=?').get(phone);if(!u){const uid=id('USR');db.prepare('INSERT INTO users(id,name,email,phone,role,status,verified,created_at) VALUES(?,?,?,?,?,?,?,?)').run(uid,'مستخدم NEXORA',`phone-${uid}@nexora.local`,phone,'buyer','active',1,now());u=db.prepare('SELECT * FROM users WHERE id=?').get(uid);ensureCart(uid)}else db.prepare('UPDATE users SET verified=1,last_login=? WHERE id=?').run(now(),u.id);res.json({token:issue(u),user:{id:u.id,name:u.name,email:u.email,phone:u.phone,role:u.role,verified:true}})});

// Founder/admin 2FA: password first, then TOTP. Set FOUNDER_2FA_SECRET in .env.
app.post('/api/admin/login',async(req,res)=>{const idv=String(req.body?.id||''),pass=String(req.body?.password||'');if(!process.env.FOUNDER_ID||!process.env.FOUNDER_PASSWORD)return res.status(503).json({error:'Founder credentials are not configured'});if(idv!==process.env.FOUNDER_ID||pass!==process.env.FOUNDER_PASSWORD)return res.status(401).json({error:'Invalid founder credentials'});const secret=process.env.FOUNDER_2FA_SECRET;if(!secret)return res.status(428).json({error:'2FA is required. Configure FOUNDER_2FA_SECRET on the server first.'});const code=String(req.body?.code||'');if(!speakeasy.totp.verify({secret,encoding:'base32',token:code,window:1}))return res.status(401).json({error:'2FA code is required or invalid'});let u=db.prepare("SELECT * FROM users WHERE role='founder' LIMIT 1").get();let uid=u?.id;if(!uid){uid=id('USR');db.prepare('INSERT INTO users(id,name,email,role,status,verified,created_at) VALUES(?,?,?,?,?,?,?)').run(uid,'عبد الرحمن معاذ أبو طير',`founder-${uid}@nexora.local`,'founder','active',1,now())}audit(uid,'founder.login','founder',uid,{});res.json({token:issue({id:uid,role:'founder',email:''}),ok:true})});

// Founder dashboard: everything that happened today.
app.get('/api/admin/today',auth,admin,(req,res)=>{const day=new Date().toISOString().slice(0,10),from=day+'T00:00:00.000Z';const q=(sql)=>db.prepare(sql).all(from);const stats={users:db.prepare('SELECT COUNT(*) n FROM users WHERE created_at>=?').get(from).n,orders:db.prepare('SELECT COUNT(*) n FROM orders WHERE created_at>=?').get(from).n,sales:db.prepare("SELECT COALESCE(SUM(amount),0) n FROM orders WHERE created_at>=? AND status IN ('paid','processing','shipped','delivered')").get(from).n,commission:db.prepare('SELECT COALESCE(SUM(commission),0) n FROM orders WHERE created_at>=?').get(from).n,payments:db.prepare('SELECT COUNT(*) n FROM payments WHERE created_at>=?').get(from).n,messages:db.prepare('SELECT COUNT(*) n FROM messages WHERE created_at>=?').get(from).n,products:db.prepare('SELECT COUNT(*) n FROM products WHERE created_at>=?').get(from).n};res.json({date:day,stats,orders:q(`SELECT o.*,p.name product,u.name buyer FROM orders o JOIN products p ON p.id=o.product_id JOIN users u ON u.id=o.buyer_id WHERE o.created_at>=? ORDER BY o.created_at DESC`),payments:q(`SELECT * FROM payments WHERE created_at>=? ORDER BY created_at DESC`),users:q(`SELECT id,name,email,phone,role,verified,created_at,last_login FROM users WHERE created_at>=? ORDER BY created_at DESC`),messages:q(`SELECT m.*,u.name sender_name FROM messages m JOIN users u ON u.id=m.sender_id WHERE m.created_at>=? ORDER BY m.created_at DESC`),audit:q(`SELECT * FROM audit_log WHERE created_at>=? ORDER BY created_at DESC LIMIT 500`)})});

// Admin order control + live delivery timeline.
app.patch('/api/admin/orders/:id/status',auth,admin,(req,res)=>{const status=String(req.body?.status||'');const allowed=['pending_payment','paid','processing','shipped','out_for_delivery','delivered','cancelled','returned'];if(!allowed.includes(status))return res.status(400).json({error:'Invalid order status'});const o=db.prepare('SELECT * FROM orders WHERE id=?').get(req.params.id);if(!o)return res.status(404).json({error:'Order not found'});db.prepare('UPDATE orders SET status=?,updated_at=? WHERE id=?').run(status,now(),o.id);let d=db.prepare('SELECT id FROM deliveries WHERE order_id=?').get(o.id);if(!d)db.prepare('INSERT INTO deliveries(id,order_id,status,created_at,updated_at) VALUES(?,?,?,?,?)').run(id('DEL'),o.id,status,now(),now());else db.prepare('UPDATE deliveries SET status=?,updated_at=?,delivered_at=? WHERE order_id=?').run(status,now(),status==='delivered'?now():null,o.id);if(status==='delivered')settleOrder(o.id,req.user.sub);audit(req.user.sub,'order.status','order',o.id,{status});io.emit('order:update',{orderId:o.id,status});res.json({ok:true})});
app.get('/api/orders/:id/tracking',auth,(req,res)=>{const o=db.prepare('SELECT * FROM orders WHERE id=? AND (buyer_id=? OR seller_id=(SELECT id FROM sellers WHERE user_id=?))').get(req.params.id,req.user.sub,req.user.sub);if(!o)return res.status(404).json({error:'Order not found'});const states=['pending_payment','paid','processing','shipped','out_for_delivery','delivered'];const labels={pending_payment:'بانتظار الدفع',paid:'تم الدفع',processing:'قيد التجهيز',shipped:'خرج للشحن',out_for_delivery:'خرج للتوصيل',delivered:'تم التسليم'};const idx=states.indexOf(o.status);res.json({orderId:o.id,status:o.status,timeline:states.map((s,i)=>({status:s,label:labels[s],done:i<=idx,active:i===idx}))})});

// Product image upload: Cloudinary or S3 in production; local disk only when explicitly selected.
function cloudConfigured(){return !!(process.env.CLOUDINARY_CLOUD_NAME&&process.env.CLOUDINARY_API_KEY&&process.env.CLOUDINARY_API_SECRET)}
function s3Configured(){return !!(process.env.S3_BUCKET&&process.env.S3_REGION&&process.env.S3_ACCESS_KEY_ID&&process.env.S3_SECRET_ACCESS_KEY)}
async function storeImage(buffer,key){
  if(cloudConfigured()){
    cloudinary.config({cloud_name:process.env.CLOUDINARY_CLOUD_NAME,api_key:process.env.CLOUDINARY_API_KEY,api_secret:process.env.CLOUDINARY_API_SECRET,secure:true});
    const result=await new Promise((resolve,reject)=>{const st=cloudinary.uploader.upload_stream({folder:process.env.CLOUDINARY_FOLDER||'nexora/products',public_id:key.replace(/\.webp$/,''),resource_type:'image',format:'webp',quality:'auto'},(e,r)=>e?reject(e):resolve(r));st.end(buffer)});
    return {url:result.secure_url,key:result.public_id,provider:'cloudinary'};
  }
  if(s3Configured()){
    const client=new S3Client({region:process.env.S3_REGION,credentials:{accessKeyId:process.env.S3_ACCESS_KEY_ID,secretAccessKey:process.env.S3_SECRET_ACCESS_KEY}});
    const objectKey=`${process.env.S3_PREFIX||'nexora/products'}/${key}`;
    await client.send(new PutObjectCommand({Bucket:process.env.S3_BUCKET,Key:objectKey,Body:buffer,ContentType:'image/webp',CacheControl:'public,max-age=31536000,immutable'}));
    const base=process.env.S3_PUBLIC_BASE_URL||`https://${process.env.S3_BUCKET}.s3.${process.env.S3_REGION}.amazonaws.com`;
    return {url:`${base}/${objectKey}`,key:objectKey,provider:'s3'};
  }
  if(String(process.env.NODE_ENV)==='production'&&String(process.env.ALLOW_LOCAL_UPLOADS||'false')!=='true')throw new Error('Production image storage is not configured');
  const dest=path.join(uploadsDir,key); await fs.promises.writeFile(dest,buffer); return {url:`/uploads/${key}`,key,provider:'local'};
}
app.post('/api/products/:id/images',auth,upload.array('images',8),async(req,res)=>{try{const p=db.prepare('SELECT p.*,s.user_id FROM products p JOIN sellers s ON s.id=p.seller_id WHERE p.id=?').get(req.params.id);if(!p||p.user_id!==req.user.sub&& !['founder','admin'].includes(req.user.role))return res.status(403).json({error:'Not allowed'});const out=[];for(const [i,file] of (req.files||[]).entries()){const key=`${p.id}-${Date.now()}-${i}.webp`;const compressed=await sharp(file.buffer).rotate().resize({width:1600,height:1600,fit:'inside',withoutEnlargement:true}).webp({quality:82}).toBuffer();const stored=await storeImage(compressed,key);db.prepare('INSERT INTO product_images(id,product_id,url,storage_key,sort_order,created_at) VALUES(?,?,?,?,?,?)').run(id('IMG'),p.id,stored.url,stored.key,i,now());if(i===0)db.prepare('UPDATE products SET image_url=?,updated_at=? WHERE id=?').run(stored.url,now(),p.id);out.push(stored)}audit(req.user.sub,'product.images.upload','product',p.id,{count:out.length,provider:out[0]?.provider});res.json({images:out})}catch(e){res.status(503).json({error:e.message})}});
app.get('/api/products/:id/images',(req,res)=>res.json({images:db.prepare('SELECT * FROM product_images WHERE product_id=? ORDER BY sort_order,id').all(req.params.id)}));

// Payment engine endpoints. Provider credentials are required; no fake production transaction is created.
app.post('/api/payments/:provider/create',auth,async(req,res)=>{try{const provider=String(req.params.provider);if(!['jawwal','card'].includes(provider))return res.status(400).json({error:'Unsupported payment provider'});const {orderId}=req.body||{};const p=db.prepare('SELECT p.*,o.* FROM payments p JOIN orders o ON o.id=p.order_id WHERE o.id=? ORDER BY p.created_at DESC LIMIT 1').get(orderId);if(!p||p.buyer_id!==req.user.sub)return res.status(404).json({error:'Payment not found'});const data=await paymentProviderRequest(provider,{orderId:p.order_id,amount:p.amount,currency:'USD',returnUrl:process.env.PUBLIC_ORIGIN?`${process.env.PUBLIC_ORIGIN}/payment-return.html`:undefined,webhookUrl:process.env.PUBLIC_ORIGIN?`${process.env.PUBLIC_ORIGIN}/api/payments/${provider}/webhook`:undefined});db.prepare('UPDATE payments SET provider_reference=?,status=?,updated_at=? WHERE id=?').run(data.reference||data.id||'',data.status||'pending',now(),p.id);audit(req.user.sub,'payment.create','payment',p.id,{provider});res.json({ok:true,provider,data})}catch(e){res.status(503).json({error:e.message})}});
app.post('/api/payments/:provider/webhook',async(req,res)=>{try{
  const provider=req.params.provider,raw=req.rawBody||Buffer.from(JSON.stringify(req.body||{}));
  const secret=provider==='jawwal'?process.env.JAWALPAY_WEBHOOK_SECRET:process.env.CARD_GATEWAY_WEBHOOK_SECRET;
  if(!secret)return res.status(503).send('Webhook secret not configured');
  const signature=req.headers[String(process.env.WEBHOOK_SIGNATURE_HEADER||'x-nexora-signature').toLowerCase()]||req.headers['x-signature']||'';
  const expected=hmac(raw.toString(),secret); if(!timingSafe(String(signature),expected))return res.status(401).send('Invalid signature');
  const payload=safeJson(raw.toString()),eventId=String(payload.eventId||payload.event_id||payload.id||crypto.createHash('sha256').update(raw).digest('hex'));
  if(db.prepare('SELECT id FROM payment_webhooks WHERE event_id=?').get(eventId))return res.json({ok:true,duplicate:true});
  const orderId=payload.orderId||payload.order_id; const payment=db.prepare('SELECT p.*,o.amount order_amount,o.status order_status FROM payments p JOIN orders o ON o.id=p.order_id WHERE o.id=? ORDER BY p.created_at DESC LIMIT 1').get(orderId);
  if(!payment)return res.status(404).send('Unknown order');
  const amount=Number(payload.amount??payload.total??payload.value); if(Number.isFinite(amount)&&Math.abs(amount-Number(payment.amount))>0.0001)return res.status(422).send('Amount mismatch');
  const success=['success','paid','completed','captured','succeeded'].includes(String(payload.status||payload.event||'').toLowerCase());
  const status=success?'confirmed':'failed';
  db.prepare('INSERT INTO payment_webhooks(id,provider,event_id,signature,status,payload_json,created_at,processed_at) VALUES(?,?,?,?,?,?,?,?)').run(id('WHK'),provider,eventId,String(signature),status,raw.toString(),now(),now());
  db.prepare('UPDATE payments SET status=?,provider_reference=?,updated_at=? WHERE id=?').run(status,payload.reference||payload.referenceId||payload.id||'',now(),payment.id);
  if(success&&payment.order_status!=='delivered')db.prepare('UPDATE orders SET status=?,updated_at=? WHERE id=?').run('paid',now(),payment.order_id);
  audit(null,'payment.webhook','payment',payment.id,{provider,eventId,status});
  io.to(`user:${payment.buyer_id}`).emit('payment:update',{orderId:payment.order_id,status});
  res.json({ok:true});
}catch(e){res.status(400).send(e.message)}});

// Invoice generation + optional email.
app.get('/api/orders/:id/invoice',auth,async(req,res)=>{try{const o=db.prepare('SELECT o.*,p.name product,u.name buyer_name,u.email buyer_email FROM orders o JOIN products p ON p.id=o.product_id JOIN users u ON u.id=o.buyer_id WHERE o.id=? AND (o.buyer_id=? OR o.seller_id=(SELECT id FROM sellers WHERE user_id=?))').get(req.params.id,req.user.sub,req.user.sub);if(!o)return res.status(404).json({error:'Order not found'});const pdf=await emailInvoice(o.id);res.json({invoice:pdf.url,emailed:!!smtp()&&!!o.buyer_email})}catch(e){res.status(500).json({error:e.message})}});

// AI adapter. Configure OPENAI_API_KEY + OPENAI_MODEL or AI_API_URL.
app.post('/api/ai/recommend',auth,async(req,res)=>{try{const budget=Number(req.body?.budget||0),query=String(req.body?.query||'').slice(0,500);const products=db.prepare(`SELECT p.id,p.name,p.price,p.description,c.name category FROM products p LEFT JOIN categories c ON c.id=p.category_id WHERE p.status='active' AND (?<=0 OR p.price<=?) ORDER BY p.created_at DESC LIMIT 30`).all(budget,budget);if(!process.env.OPENAI_API_KEY&&!process.env.AI_API_URL)return res.json({mode:'catalog',recommendations:products});const url=process.env.AI_API_URL||'https://api.openai.com/v1/chat/completions';const headers={'content-type':'application/json',...(process.env.OPENAI_API_KEY?{authorization:`Bearer ${process.env.OPENAI_API_KEY}`}:{})};const body={model:process.env.OPENAI_MODEL||'gpt-4o-mini',messages:[{role:'system',content:'You are NEXORA shopping assistant. Return concise JSON with product ids ranked best first. Never invent ids.'},{role:'user',content:JSON.stringify({query,budget,products})}],temperature:.2};const rr=await fetch(url,{method:'POST',headers,body:JSON.stringify(body)});if(!rr.ok)throw new Error(`AI HTTP ${rr.status}`);const data=await rr.json();res.json({mode:'ai',data})}catch(e){res.status(503).json({error:e.message})}});

// Push notifications are opt-in and require VAPID keys; no fake subscription is stored.


// External payout worker: only sends real money when PAYOUT_API_URL is configured; otherwise remains queued.
async function processPayoutJobs(){
  const jobs=db.prepare("SELECT * FROM payout_jobs WHERE status='queued' ORDER BY created_at LIMIT 10").all();
  for(const job of jobs){try{
    db.prepare("UPDATE payout_jobs SET status='processing',updated_at=? WHERE id=? AND status='queued'").run(now(),job.id);
    const order=db.prepare('SELECT * FROM orders WHERE id=?').get(job.order_id); const result=await payoutProviderRequest(order);
    db.prepare('UPDATE payout_jobs SET status=?,provider_reference=?,updated_at=? WHERE id=?').run(result.status==='queued'?'queued':'paid',result.reference,now(),job.id);
    audit(null,'payout.processed','payout',job.id,{external:result.external,status:result.status});
  }catch(e){db.prepare('UPDATE payout_jobs SET status=?,updated_at=? WHERE id=?').run('failed',now(),job.id);audit(null,'payout.failed','payout',job.id,{error:e.message})}}
}
setInterval(()=>processPayoutJobs().catch(()=>{}),15000);

// Web Push configuration. No subscription is used until VAPID keys are supplied.
if(process.env.VAPID_PUBLIC_KEY&&process.env.VAPID_PRIVATE_KEY){webpush.setVapidDetails(process.env.VAPID_SUBJECT||'mailto:admin@nexora.local',process.env.VAPID_PUBLIC_KEY,process.env.VAPID_PRIVATE_KEY)}
app.get('/api/push/config',(req,res)=>res.json({enabled:!!(process.env.VAPID_PUBLIC_KEY&&process.env.VAPID_PRIVATE_KEY),publicKey:process.env.VAPID_PUBLIC_KEY||null}));
app.post('/api/push/subscribe',auth,(req,res)=>{try{if(!req.body?.endpoint)return res.status(400).json({error:'Invalid push subscription'});db.prepare(`CREATE TABLE IF NOT EXISTS push_subscriptions(id TEXT PRIMARY KEY,user_id TEXT NOT NULL,subscription_json TEXT NOT NULL,created_at TEXT NOT NULL,UNIQUE(user_id,subscription_json))`).run();db.prepare('INSERT OR IGNORE INTO push_subscriptions(id,user_id,subscription_json,created_at) VALUES(?,?,?,?)').run(id('PUS'),req.user.sub,JSON.stringify(req.body),now());res.json({ok:true})}catch(e){res.status(500).json({error:e.message})}});
app.post('/api/push/test',auth,async(req,res)=>{try{if(!process.env.VAPID_PUBLIC_KEY||!process.env.VAPID_PRIVATE_KEY)return res.status(503).json({error:'Push is not configured'});const subs=db.prepare('SELECT * FROM push_subscriptions WHERE user_id=?').all(req.user.sub);for(const s of subs){try{await webpush.sendNotification(JSON.parse(s.subscription_json),JSON.stringify({title:'NEXORA',body:'إشعار تجريبي',url:'/'}))}catch{}}res.json({ok:true,count:subs.length})}catch(e){res.status(500).json({error:e.message})}});

app.get('/api/health',(req,res)=>res.set('Cache-Control','no-store').json({ok:true,database:true,online:true,features:{payments:!!process.env.JAWALPAY_API_URL||!!process.env.CARD_GATEWAY_API_URL,sms:!!process.env.SMS_API_URL,ai:!!process.env.OPENAI_API_KEY||!!process.env.AI_API_URL,smtp:!!process.env.SMTP_HOST,founder2fa:!!process.env.FOUNDER_2FA_SECRET,cloudStorage:cloudConfigured()||s3Configured(),payout:!!process.env.PAYOUT_API_URL,push:!!process.env.VAPID_PUBLIC_KEY}}));

ioServer.listen(PORT,()=>console.log(`NEXORA live on http://localhost:${PORT}`));
