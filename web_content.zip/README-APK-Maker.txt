KÜCHENCHEF – APK MAKER UPLOAD

Dies ist ein vereinfachtes Web-App-Paket für einen Online-HTML/ZIP-zu-APK-Generator.

WICHTIG: Die ZIP ist bewusst so aufgebaut, dass index.html direkt im Hauptverzeichnis liegt (nicht in einem zusätzlichen Unterordner). Alle Oberflächen-Dateien sind eingebettet; es wird keine Website und kein Server zum Starten der App benötigt. Rezeptdaten werden lokal im App-Speicher verwaltet.

App-Name: Küchenchef
Untertitel: Rezepteinkauf · Warenkosten
Design: Dunkelblau/Cyan, Kochmütze, schräges Messer und Taschenrechner.

Beim Generator einstellen, falls möglich:
- App name / Application name: Küchenchef
- Package ID: app.kuechenchef.rezepteinkauf
- Start page: index.html
- Orientation: Portrait oder Auto
- Internet permission: nicht erforderlich für die lokale Oberfläche
- External website / website URL: NICHT verwenden; als lokale HTML-Dateien packen

HINWEIS: Drittanbieter-Generatoren unterscheiden sich. Diese ZIP bereitet die Dateien vor, garantiert aber nicht, dass jeder Dienst alle Funktionen der Anwendung vollständig unterstützt. Nach der Erstellung muss die APK auf dem Zielgerät getestet werden.
