KÜCHENCHEF – EINFACHE ANDROID-VERSION

Dieses ZIP ist für einen Online-HTML/ZIP-zu-APK-Generator gedacht. index.html liegt direkt im Hauptverzeichnis.

Empfohlene Einstellungen im APK-Maker:
- App name: Küchenchef
- Start page: index.html
- JavaScript aktivieren
- DOM Storage / Local Storage aktivieren (wichtig für gespeicherte Rezepte)

In dieser vereinfachten Version wurden WhatsApp-Teilen, Drucken, PDF-Erstellung sowie Datei-Export und -Import ausgeblendet, weil diese Funktionen in der bisherigen Android-App nicht zuverlässig funktionierten. Erfassen, Bearbeiten und lokales Speichern bleiben enthalten.

WICHTIG: Rezepte werden nur auf diesem Gerät gespeichert. Da Export/Import ausgeblendet sind, können Rezepte bei Deinstallation oder Löschen der App-Daten verloren gehen. Bitte zuerst mit Testrezepten prüfen.

App-Icon: icons/icon-512.png (PNG, 512 × 512). Eine zusätzliche Kopie liegt als Kuechenchef-App-Icon-Blau.png bei.
