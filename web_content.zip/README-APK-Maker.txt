KÜCHENCHEF – ANDROID-PAKET (Speichern / PDF / WhatsApp verbessert)

Diese ZIP-Datei ist für einen Online-HTML/ZIP-zu-APK-Generator gedacht. index.html liegt direkt im Hauptverzeichnis.

Empfohlene Einstellungen im APK-Maker:
- App name: Küchenchef
- Package ID: app.kuechenchef.rezepteinkauf
- Start page: index.html
- Internet permission: AKTIVIEREN (für WhatsApp-Teilen erforderlich)
- Dateien als lokale HTML-App einpacken; keine externe Website-URL verwenden
- Wenn verfügbar: JavaScript und DOM Storage / Local Storage aktivieren
- Wenn verfügbar: Downloads aktivieren

Änderungen in dieser Version:
- Speichern prüft, ob der lokale Speicher den Datensatz tatsächlich übernommen hat.
- Auf Android führen die Druck-Schaltflächen direkt zur PDF-Datei, weil viele WebView-APK-Generatoren den normalen Druckdialog nicht unterstützen.
- WhatsApp-Teilen öffnet den WhatsApp-Web/App-Link mit vorbereitetem Rezepttext; es wird dabei keine JSON-Datei heruntergeladen.
- Die Datensicherung per JSON bleibt getrennt in den Einstellungen.

WICHTIG:
Der APK-Generator steuert, ob Android WebView Local Storage und Downloads zulässt. Diese Optionen müssen aktiviert sein. Wenn der Generator sie nicht unterstützt, kann eine HTML-Datei das nicht allein beheben. Bitte zuerst eine Sicherung der vorhandenen Rezepte exportieren. Die fertige APK muss auf dem Android-Gerät getestet werden; dieses ZIP wurde nicht innerhalb deiner konkreten APK-Generator-App ausgeführt.
