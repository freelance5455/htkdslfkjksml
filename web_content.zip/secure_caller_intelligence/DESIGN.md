---
name: Secure Caller Intelligence
colors:
  surface: '#051424'
  surface-dim: '#051424'
  surface-bright: '#2c3a4c'
  surface-container-lowest: '#010f1f'
  surface-container-low: '#0d1c2d'
  surface-container: '#122131'
  surface-container-high: '#1c2b3c'
  surface-container-highest: '#273647'
  on-surface: '#d4e4fa'
  on-surface-variant: '#c6c6cd'
  inverse-surface: '#d4e4fa'
  inverse-on-surface: '#233143'
  outline: '#909097'
  outline-variant: '#45464d'
  surface-tint: '#bec6e0'
  primary: '#bec6e0'
  on-primary: '#283044'
  primary-container: '#0f172a'
  on-primary-container: '#798098'
  inverse-primary: '#565e74'
  secondary: '#d3fbff'
  on-secondary: '#00363a'
  secondary-container: '#00eefc'
  on-secondary-container: '#00686f'
  tertiary: '#b4c5ff'
  on-tertiary: '#002a78'
  tertiary-container: '#001443'
  on-tertiary-container: '#4278ff'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#dae2fd'
  primary-fixed-dim: '#bec6e0'
  on-primary-fixed: '#131b2e'
  on-primary-fixed-variant: '#3f465c'
  secondary-fixed: '#7df4ff'
  secondary-fixed-dim: '#00dbe9'
  on-secondary-fixed: '#002022'
  on-secondary-fixed-variant: '#004f54'
  tertiary-fixed: '#dbe1ff'
  tertiary-fixed-dim: '#b4c5ff'
  on-tertiary-fixed: '#00174b'
  on-tertiary-fixed-variant: '#003ea8'
  background: '#051424'
  on-background: '#d4e4fa'
  surface-variant: '#273647'
typography:
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Space Grotesk
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Space Grotesk
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-md:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.05em
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 10px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.05em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1.5rem
  margin: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system establishes a high-security, professional caller intelligence interface tailored for modern enterprise and high-stakes communication environments. The aesthetic is built on a foundation of absolute trust, precision, and instant data clarity. 

- **Brand Personality:** Authoritative, vigilant, highly technical, and reassuringly dependable.
- **Target Audience:** Security professionals, enterprise communications teams, and privacy-conscious organizations requiring real-time threat assessment.
- **Emotional Response:** Complete confidence, alertness, and calm control over incoming communication streams.
- **Design Style:** Corporate / Modern, blending high-contrast data visualization with sophisticated dark-mode layering, precise micro-interactions, and a rigorous structural grid.

## Colors

The color palette is engineered for low-fatigue dark-mode operation in high-stress environments. The deep navy background establishes spatial depth, while electric teal acts as the primary action and alert focal point. Vibrant blue supports secondary structural elements and active states, backed by a sophisticated neutral scale for high-contrast legibility of threat telemetry and metadata.

## Typography

The typographic hierarchy pairs geometric, futuristic headlines with neutral, highly legible body copy and technical monospace labels. This ensures that raw metadata, threat scores, and caller IDs are instantly scannable, maintaining absolute clarity across complex telemetry dashboards.

## Layout & Spacing

A disciplined 12-column fluid grid system governs the interface, optimized for dense data presentation without cognitive overload. 

- **Breakpoints:** Mobile (< 768px), Tablet (768px – 1024px), Desktop (> 1024px).
- **Reflow Rules:** On mobile form factors, multi-column telemetry panels collapse into single-column vertical stacks, prioritizing real-time threat alerts at the top of the viewport. Margins scale dynamically from 1rem on mobile to 2rem on desktop.

## Elevation & Depth

Visual hierarchy relies on tonal layering combined with low-contrast outlines and ambient shadows. 

- **Surface Tiers:** Backgrounds utilize deep navy (#0F172A), with floating cards elevated via slightly lighter indigo-tinted surface tones (#1E293B).
- **Shadows & Glows:** Interactive threat warnings and primary action zones incorporate subtle, low-opacity electric teal ambient glows to draw immediate focus without causing visual strain.
- **Outlines:** Structural boundaries are defined by razor-thin, low-opacity borders using neutral tones to maintain a crisp, uncompromising tactical interface.

## Shapes

The design system employs a soft-edged geometric language (`roundedness` level 1), utilizing subtle 0.25rem border radii for standard containers and inputs, scaling up to 0.5rem (`rounded-lg`) for primary structural cards. This precision styling avoids overly playful curves, reinforcing the secure, utilitarian, and mission-critical nature of the software.

## Components

- **Buttons:** Primary actions feature electric teal backgrounds with dark navy text, utilizing sharp hover states and slight outer glows. Secondary buttons employ ghost borders with vibrant blue text.
- **Chips & Badges:** Monospace labels paired with soft background tints for real-time risk scores (e.g., Verified, Suspicious, High Risk).
- **Input Fields:** Dark slate surface fills with subtle neutral borders, transitioning to electric teal on focus with clear monospace text for search and filter inputs.
- **Cards:** Elevated container surfaces holding caller profiles, featuring clean top-to-bottom threat telemetry hierarchy.
- **Checkboxes & Radios:** Precision squares and circles with high-contrast electric teal active fills.
- **Lists:** Dense, divider-separated data rows optimized for scanning call logs and metadata streams.
- **Specialized Components:** Real-time threat meters, audio waveform playback bars, and encrypted status indicators.