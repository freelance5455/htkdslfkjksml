(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.MRKInventoryView = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  function positiveWarehouses(warehouses, getBalance) {
    return (Array.isArray(warehouses) ? warehouses : []).map(warehouse => {
      const balance = getBalance(warehouse) || {};
      return { warehouse, quantity: Number(balance.q) || 0, value: Number(balance.v) || 0 };
    }).filter(row => row.quantity > 0);
  }
  function buildRows(goods, warehouses, getBalance) {
    return (Array.isArray(goods) ? goods : []).map(good => {
      const active = positiveWarehouses(warehouses, warehouse => getBalance(good, warehouse));
      const quantity = active.reduce((sum, row) => sum + row.quantity, 0);
      const value = active.reduce((sum, row) => sum + row.value, 0);
      return { good, warehouses: active, quantity, value, average: quantity > 0 ? Math.round(value / quantity) : 0 };
    }).filter(row => row.quantity > 0);
  }
  return { positiveWarehouses, buildRows };
});
