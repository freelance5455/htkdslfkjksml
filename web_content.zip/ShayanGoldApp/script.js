const DEFAULT_FACTOR = 4.3318;

let FACTOR =
  Number(
    localStorage.getItem("shayan_gold_factor")
  ) || DEFAULT_FACTOR;

let trades = [];

try {

  const savedTrades =
    localStorage.getItem("shayan_gold_trades");

  trades =
    savedTrades
      ? JSON.parse(savedTrades)
      : [];

  if (!Array.isArray(trades)) {
    trades = [];
  }

} catch (error) {

  trades = [];

}

let editingTradeId = null;


/* ================= DATE ================= */

function getPersianDate(date = new Date()) {

  return new Intl.DateTimeFormat(
    "fa-IR-u-ca-persian",
    {
      year: "numeric",
      month: "long",
      day: "numeric"
    }
  ).format(date);

}


function getDateKey(date = new Date()) {

  const y =
    date.getFullYear();

  const m =
    String(
      date.getMonth() + 1
    ).padStart(2, "0");

  const d =
    String(
      date.getDate()
    ).padStart(2, "0");

  return `${y}-${m}-${d}`;

}


function getTime(date = new Date()) {

  return date.toLocaleTimeString(
    "fa-IR",
    {
      hour: "2-digit",
      minute: "2-digit"
    }
  );

}


/* ================= NUMBERS ================= */

function normalizeNumber(value) {

  if (
    value === null ||
    value === undefined ||
    value === ""
  ) {
    return 0;
  }

  let text =
    String(value)
      .replace(/,/g, "")
      .replace(/\s/g, "");

  text =
    text.replace(
      /[۰-۹]/g,
      d =>
        "۰۱۲۳۴۵۶۷۸۹".indexOf(d)
    );

  text =
    text.replace(
      /[٠-٩]/g,
      d =>
        "٠١٢٣٤٥٦٧٨٩".indexOf(d)
    );

  return Number(text) || 0;

}


function formatNumber(number) {

  return Number(number || 0)
    .toLocaleString(
      "en-US",
      {
        maximumFractionDigits: 3
      }
    );

}


function formatMoney(number) {

  return Number(number || 0)
    .toLocaleString(
      "en-US",
      {
        maximumFractionDigits: 0
      }
    );

}


function formatInputNumber(value) {

  const number =
    normalizeNumber(value);

  if (!number) {
    return "";
  }

  return number.toLocaleString(
    "en-US",
    {
      maximumFractionDigits: 3
    }
  );

}


/* ================= STORAGE ================= */

function saveTrades() {

  localStorage.setItem(
    "shayan_gold_trades",
    JSON.stringify(trades)
  );

}


/* ================= LEDGER ================= */

function calculateLedger() {

  let position = 0;

  let averageCost = 0;

  let realizedProfit = 0;


  const sortedTrades =
    [...trades].sort(
      (a, b) =>
        new Date(a.createdAt).getTime() -
        new Date(b.createdAt).getTime()
    );


  for (const trade of sortedTrades) {

    const qty =
      Number(trade.weight) || 0;

    const price =
      Number(trade.price18) || 0;


    if (
      qty <= 0 ||
      price <= 0
    ) {
      continue;
    }


    /* ===== BUY ===== */

    if (trade.type === "buy") {

      if (position < 0) {

        const shortQty =
          Math.abs(position);

        const closeQty =
          Math.min(
            qty,
            shortQty
          );


        realizedProfit +=
          closeQty *
          (averageCost - price);


        position += closeQty;


        if (qty > closeQty) {

          const remaining =
            qty - closeQty;

          position = remaining;

          averageCost = price;

        } else if (position === 0) {

          averageCost = 0;

        }

      }

      else if (position > 0) {

        const oldQty =
          position;

        const newQty =
          oldQty + qty;


        averageCost =
          (
            oldQty * averageCost +
            qty * price
          ) / newQty;


        position =
          newQty;

      }

      else {

        position = qty;

        averageCost = price;

      }

    }


    /* ===== SELL ===== */

    else if (trade.type === "sell") {

      if (position > 0) {

        const closeQty =
          Math.min(
            position,
            qty
          );


        realizedProfit +=
          closeQty *
          (price - averageCost);


        position -= closeQty;


        if (qty > closeQty) {

          const remaining =
            qty - closeQty;

          position =
            -remaining;

          averageCost =
            price;

        }

        else if (position === 0) {

          averageCost = 0;

        }

      }

      else if (position < 0) {

        const oldShortQty =
          Math.abs(position);

        const newShortQty =
          oldShortQty + qty;


        averageCost =
          (
            oldShortQty * averageCost +
            qty * price
          ) / newShortQty;


        position =
          -newShortQty;

      }

      else {

        position =
          -qty;

        averageCost =
          price;

      }

    }

  }


  return {
    position,
    averageCost,
    realizedProfit
  };

}


/* ================= TRADE HTML ================= */

function createTradeHTML(trade) {

  return `

    <div class="trade-item">

      <div class="trade-main">

        <span>
          ${trade.type === "buy"
            ? "خرید"
            : "فروش"}
        </span>

        <span class="trade-type ${trade.type}">

          ${trade.type === "buy"
            ? "خرید"
            : "فروش"}

        </span>

      </div>


      <div class="trade-details">

        <span>
          وزن:
          ${formatNumber(trade.weight)}
          گرم
        </span>

        <span>
          فی:
          ${formatMoney(trade.price18)}
          تومان
        </span>

        <span>
          مظنه:
          ${formatMoney(trade.mazhane)}
          تومان
        </span>

        <span>
          کل:
          ${formatMoney(trade.totalPrice)}
          تومان
        </span>

        <span>
          ${trade.time || "-"}
        </span>

      </div>

    </div>

  `;

}


/* ================= HOME ================= */

function renderHome() {

  const today =
    getDateKey();


  const todayTrades =
    trades.filter(
      trade =>
        trade.date === today
    );


  let bought = 0;

  let sold = 0;


  todayTrades.forEach(
    trade => {

      if (trade.type === "buy") {

        bought +=
          Number(trade.weight) || 0;

      } else {

        sold +=
          Number(trade.weight) || 0;

      }

    }
  );


  const ledger =
    calculateLedger();


  const balance =
    Math.abs(ledger.position);


  const average =
    ledger.averageCost;


  const averageMazhane =
    average * FACTOR;


  const todayDate =
    document.getElementById(
      "todayDate"
    );

  if (todayDate) {

    todayDate.textContent =
      getPersianDate();

  }


  const homeTradeCount =
    document.getElementById(
      "homeTradeCount"
    );

  if (homeTradeCount) {

    homeTradeCount.textContent =
      formatNumber(todayTrades.length);

  }


  const homeBought =
    document.getElementById(
      "homeBought"
    );

  if (homeBought) {

    homeBought.textContent =
      `${formatNumber(bought)} گرم`;

  }


  const homeSold =
    document.getElementById(
      "homeSold"
    );

  if (homeSold) {

    homeSold.textContent =
      `${formatNumber(sold)} گرم`;

  }


  const homeBalance =
    document.getElementById(
      "homeBalance"
    );

  if (homeBalance) {

    homeBalance.textContent =
      `${formatNumber(balance)} گرم`;

  }


  const averageLabel =
    document.getElementById(
      "homeAverageLabel"
    );


  if (averageLabel) {

    if (ledger.position < 0) {

      averageLabel.textContent =
        "فی میانگین فروش باز";

    } else {

      averageLabel.textContent =
        "فی میانگین موجودی باقی‌مانده";

    }

  }


  const homeAveragePrice =
    document.getElementById(
      "homeAveragePrice"
    );

  if (homeAveragePrice) {

    homeAveragePrice.textContent =
      `${formatMoney(average)} تومان`;

  }


  const homeAverageMazhane =
    document.getElementById(
      "homeAverageMazhane"
    );

  if (homeAverageMazhane) {

    homeAverageMazhane.textContent =
      `مظنه میانگین: ${formatMoney(averageMazhane)} تومان`;

  }


  const profitElement =
    document.getElementById(
      "homeRealizedProfit"
    );


  if (profitElement) {

    profitElement.textContent =
      `${formatMoney(
        ledger.realizedProfit
      )} تومان`;


    profitElement.classList.remove(
      "closed-profit",
      "closed-loss"
    );


    if (ledger.realizedProfit > 0) {

      profitElement.classList.add(
        "closed-profit"
      );

    }

    else if (
      ledger.realizedProfit < 0
    ) {

      profitElement.classList.add(
        "closed-loss"
      );

    }

  }


  renderTradeList(
    todayTrades,
    "homeTrades"
  );

}


/* ================= TODAY TRADES ================= */

function renderTodayTrades() {

  const today =
    getDateKey();


  const todayTrades =
    trades.filter(
      trade =>
        trade.date === today
    );


  renderTradeList(
    todayTrades,
    "todayTrades"
  );

}


/* ================= GENERIC LIST ================= */

function renderTradeList(
  list,
  elementId
) {

  const container =
    document.getElementById(
      elementId
    );


  if (!container) {
    return;
  }


  if (
    !Array.isArray(list) ||
    list.length === 0
  ) {

    container.innerHTML =
      `<div class="empty">
        معامله‌ای ثبت نشده است.
      </div>`;

    return;

  }


  const sorted =
    [...list].sort(
      (a, b) =>
        new Date(b.createdAt).getTime() -
        new Date(a.createdAt).getTime()
    );


  container.innerHTML =
    sorted
      .map(
        trade =>
          createTradeHTML(trade)
      )
      .join("");

}


/* ================= HISTORY ================= */

function renderHistory(
  openDateKey = null
) {

  const container =
    document.getElementById(
      "historyList"
    );


  if (!container) {
    return;
  }


  /*
   * تاریخ‌هایی که قبل از رندر باز بوده‌اند
   * نگه داشته می‌شوند.
   *
   * این باعث می‌شود هنگام حذف یا ویرایش
   * پوشه ناگهان بسته نشود.
   */

  const openDates =
    new Set(
      Array.from(
        container.querySelectorAll(
          ".history-folder.open"
        )
      ).map(
        folder =>
          folder.dataset.date
      )
    );


  if (openDateKey) {

    openDates.add(
      openDateKey
    );

  }


  if (
    !Array.isArray(trades) ||
    trades.length === 0
  ) {

    container.innerHTML =
      `<div class="empty">
        هنوز معامله‌ای ثبت نشده است.
      </div>`;

    return;

  }


  const groups = {};


  trades.forEach(
    trade => {

      if (!trade) {
        return;
      }


      let dateKey =
        trade.date;


      /*
       * اگر معامله قدیمی date نداشت،
       * از createdAt تاریخ آن ساخته می‌شود.
       */

      if (
        !dateKey &&
        trade.createdAt
      ) {

        const createdDate =
          new Date(
            trade.createdAt
          );


        if (
          !isNaN(
            createdDate.getTime()
          )
        ) {

          dateKey =
            getDateKey(
              createdDate
            );

        }

      }


      if (!dateKey) {
        return;
      }


      if (!groups[dateKey]) {

        groups[dateKey] = [];

      }


      groups[dateKey].push(
        trade
      );

    }
  );


  const dates =
    Object.keys(groups).sort(
      (a, b) =>
        b.localeCompare(a)
    );


  if (dates.length === 0) {

    container.innerHTML =
      `<div class="empty">
        هنوز معامله‌ای ثبت نشده است.
      </div>`;

    return;

  }


  container.innerHTML =
    dates
      .map(
        date => {

          const list =
            [...groups[date]].sort(
              (a, b) => {

                const timeA =
                  a.createdAt
                    ? new Date(
                        a.createdAt
                      ).getTime()
                    : 0;


                const timeB =
                  b.createdAt
                    ? new Date(
                        b.createdAt
                      ).getTime()
                    : 0;


                return timeB - timeA;

              }
            );


          let dateObject;


          if (
            list[0] &&
            list[0].createdAt
          ) {

            dateObject =
              new Date(
                list[0].createdAt
              );

          }


          if (
            !dateObject ||
            isNaN(
              dateObject.getTime()
            )
          ) {

            dateObject =
              new Date(
                `${date}T00:00:00`
              );

          }


          const persianDate =
            getPersianDate(
              dateObject
            );


          const isOpen =
            openDates.has(
              date
            );


          return `

            <div
              class="history-folder ${isOpen ? "open" : ""}"
              data-date="${date}"
            >

              <div class="folder-header">

                <button
                  type="button"
                  class="folder-toggle"
                  onclick="toggleFolder(this)"
                >

                  <div class="folder-title">

                    <span class="folder-icon">
                      📁
                    </span>

                    <span>
                      ${persianDate}
                    </span>

                  </div>

                </button>


                <div class="folder-header-actions">

                  <span class="folder-count">
                    ${list.length} معامله
                  </span>


                  <button
                    type="button"
                    class="pdf-action"
                    onclick="event.stopPropagation(); generateDatePDF('${date}')"
                    title="گزارش PDF این تاریخ"
                  >
                    PDF
                  </button>

                </div>

              </div>


              <div class="folder-content">

                ${list
                  .map(
                    trade =>
                      createHistoryTradeHTML(
                        trade
                      )
                  )
                  .join("")}

              </div>

            </div>

          `;

        }
      )
      .join("");

}


function createHistoryTradeHTML(
  trade
) {

  return `

    <div class="history-trade">

      <div class="history-trade-top">

        <span class="trade-type ${trade.type}">
          ${trade.type === "buy"
            ? "خرید"
            : "فروش"}
        </span>


        <div class="history-actions">

          <button
            type="button"
            class="small-action"
            onclick="editTrade(${trade.id})"
            title="ویرایش"
          >
            ✎
          </button>


          <button
            type="button"
            class="small-action"
            onclick="deleteTrade(${trade.id})"
            title="حذف"
          >
            🗑
          </button>

        </div>

      </div>


      <div class="history-trade-info">

        <div>
          <span>وزن</span>
          <strong>
            ${formatNumber(trade.weight)}
            گرم
          </strong>
        </div>


        <div>
          <span>فی گرم ۱۸</span>
          <strong>
            ${formatMoney(trade.price18)}
          </strong>
        </div>


        <div>
          <span>مظنه</span>
          <strong>
            ${formatMoney(trade.mazhane)}
          </strong>
        </div>


        <div>
          <span>قیمت کل</span>
          <strong>
            ${formatMoney(trade.totalPrice)}
          </strong>
        </div>

      </div>


      <div class="history-time">

        ساعت معامله:
        ${trade.time || "-"}

      </div>

    </div>

  `;

}


function toggleFolder(button) {

  const folder =
    button.closest(
      ".history-folder"
    );


  if (folder) {

    folder.classList.toggle(
      "open"
    );

  }

}


/* =========================================================
   ================= DIRECT PDF ===========================
   ========================================================= */

/*
 * این نسخه PDF از html2pdf استفاده نمی‌کند.
 *
 * PDF مستقیماً با Canvas ساخته می‌شود و سپس تصویر هر صفحه
 * داخل jsPDF قرار می‌گیرد.
 *
 * مزیت:
 * - PDF سفید نمی‌شود.
 * - فارسی توسط مرورگر روی Canvas رندر می‌شود.
 * - چاپ/Print باز نمی‌شود.
 * - مستقیماً فایل دانلود می‌شود.
 * - چند صفحه‌ای هم پشتیبانی می‌شود.
 */


/* ================= LOAD JSPDF ================= */

function loadJsPDF() {

  return new Promise(
    function (resolve, reject) {

      if (
        window.jspdf &&
        window.jspdf.jsPDF
      ) {

        resolve(
          window.jspdf.jsPDF
        );

        return;

      }


      if (
        window.jsPDF
      ) {

        resolve(
          window.jsPDF
        );

        return;

      }


      const existingScript =
        document.querySelector(
          'script[data-shayan-jspdf="true"]'
        );


      if (existingScript) {

        existingScript.addEventListener(
          "load",
          function () {

            if (
              window.jspdf &&
              window.jspdf.jsPDF
            ) {

              resolve(
                window.jspdf.jsPDF
              );

            }

            else if (
              window.jsPDF
            ) {

              resolve(
                window.jsPDF
              );

            }

            else {

              reject(
                new Error(
                  "jsPDF loaded but API was not found."
                )
              );

            }

          }
        );


        existingScript.addEventListener(
          "error",
          function () {

            reject(
              new Error(
                "Could not load jsPDF."
              )
            );

          }
        );


        return;

      }


      const script =
        document.createElement(
          "script"
        );


      script.src =
        "https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js";


      script.async = true;


      script.dataset.shayanJspdf =
        "true";


      script.onload =
        function () {

          if (
            window.jspdf &&
            window.jspdf.jsPDF
          ) {

            resolve(
              window.jspdf.jsPDF
            );

          }

          else if (
            window.jsPDF
          ) {

            resolve(
              window.jsPDF
            );

          }

          else {

            reject(
              new Error(
                "jsPDF API was not found."
              )
            );

          }

        };


      script.onerror =
        function () {

          reject(
            new Error(
              "Could not load jsPDF library."
            )
          );

        };


      document.head.appendChild(
        script
      );

    }
  );

}


/* ================= PDF HELPERS ================= */

function pdfRoundRect(
  ctx,
  x,
  y,
  width,
  height,
  radius
) {

  const r =
    Math.min(
      radius,
      width / 2,
      height / 2
    );


  ctx.beginPath();

  ctx.moveTo(
    x + r,
    y
  );

  ctx.arcTo(
    x + width,
    y,
    x + width,
    y + height,
    r
  );

  ctx.arcTo(
    x + width,
    y + height,
    x,
    y + height,
    r
  );

  ctx.arcTo(
    x,
    y + height,
    x,
    y,
    r
  );

  ctx.arcTo(
    x,
    y,
    x + width,
    y,
    r
  );

  ctx.closePath();

}


function pdfSetFont(
  ctx,
  size,
  weight = "400"
) {

  ctx.font =
    `${weight} ${size}px Tahoma, Arial, sans-serif`;

}


function pdfText(
  ctx,
  text,
  x,
  y,
  options = {}
) {

  const {
    size = 24,
    weight = "400",
    color = "#172536",
    align = "right"
  } = options;


  ctx.save();

  pdfSetFont(
    ctx,
    size,
    weight
  );


  ctx.fillStyle =
    color;


  ctx.textAlign =
    align;


  ctx.textBaseline =
    "middle";


  ctx.direction =
    "rtl";


  ctx.fillText(
    String(text),
    x,
    y
  );


  ctx.restore();

}


function createPDFPageCanvas(
  dateTrades,
  persianDate,
  pageTrades,
  pageNumber,
  totalPages,
  totalBoughtWeight,
  totalSoldWeight
) {

  /*
   * ابعاد تقریبی A4 با کیفیت بالا
   */

  const WIDTH = 1654;

  const HEIGHT = 2339;


  const canvas =
    document.createElement(
      "canvas"
    );


  canvas.width =
    WIDTH;

  canvas.height =
    HEIGHT;


  const ctx =
    canvas.getContext(
      "2d"
    );


  /*
   * پس‌زمینه
   */

  ctx.fillStyle =
    "#ffffff";

  ctx.fillRect(
    0,
    0,
    WIDTH,
    HEIGHT
  );


  /*
   * حاشیه اصلی صفحه
   */

  ctx.strokeStyle =
    "#10243b";

  ctx.lineWidth =
    6;

  ctx.strokeRect(
    28,
    28,
    WIDTH - 56,
    HEIGHT - 56
  );


  /*
   * حاشیه طلایی داخلی
   */

  ctx.strokeStyle =
    "#d6ad43";

  ctx.lineWidth =
    2;

  ctx.strokeRect(
    45,
    45,
    WIDTH - 90,
    HEIGHT - 90
  );


  /* ================= HEADER ================= */

  const headerX =
    70;

  const headerY =
    70;

  const headerW =
    WIDTH - 140;

  const headerH =
    235;


  ctx.fillStyle =
    "#10243b";


  pdfRoundRect(
    ctx,
    headerX,
    headerY,
    headerW,
    headerH,
    28
  );


  ctx.fill();


  /*
   * خط طلایی زیر هدر
   */

  ctx.fillStyle =
    "#f4c95d";


  pdfRoundRect(
    ctx,
    headerX,
    headerY + headerH - 12,
    headerW,
    12,
    6
  );


  ctx.fill();


  pdfText(
    ctx,
    "ماشین حساب معاملاتی شایان",
    WIDTH - 110,
    headerY + 72,
    {
      size: 42,
      weight: "900",
      color: "#ffffff",
      align: "right"
    }
  );


  pdfText(
    ctx,
    "گزارش کامل معاملات روزانه",
    WIDTH - 110,
    headerY + 125,
    {
      size: 23,
      weight: "400",
      color: "#b9c9d9",
      align: "right"
    }
  );


  pdfText(
    ctx,
    persianDate,
    WIDTH - 110,
    headerY + 185,
    {
      size: 27,
      weight: "800",
      color: "#f4c95d",
      align: "right"
    }
  );


  /* ================= SUMMARY ================= */

  const summaryY =
    335;

  const gap =
    18;

  const cardW =
    (headerW - gap * 2) / 3;

  const cardH =
    145;


  const summaryCards = [

    {
      title: "تعداد معاملات",
      value:
        formatNumber(
          dateTrades.length
        ),
      color: "#172536"
    },

    {
      title: "مجموع خرید",
      value:
        `${formatNumber(
          totalBoughtWeight
        )} گرم`,
      color: "#15915b"
    },

    {
      title: "مجموع فروش",
      value:
        `${formatNumber(
          totalSoldWeight
        )} گرم`,
      color: "#d8465b"
    }

  ];


  summaryCards.forEach(
    function (card, index) {

      const x =
        headerX +
        index *
          (cardW + gap);


      ctx.fillStyle =
        "#f8fafc";


      ctx.strokeStyle =
        "#dce3ea";


      ctx.lineWidth =
        2;


      pdfRoundRect(
        ctx,
        x,
        summaryY,
        cardW,
        cardH,
        20
      );


      ctx.fill();

      ctx.stroke();


      pdfText(
        ctx,
        card.title,
        x + cardW - 25,
        summaryY + 43,
        {
          size: 19,
          weight: "500",
          color: "#718096",
          align: "right"
        }
      );


      pdfText(
        ctx,
        card.value,
        x + cardW - 25,
        summaryY + 94,
        {
          size: 29,
          weight: "900",
          color: card.color,
          align: "right"
        }
      );

    }
  );


  /* ================= TABLE ================= */

  const tableX =
    70;

  const tableY =
    530;

  const tableW =
    WIDTH - 140;


  /*
   * ستون‌ها:
   *
   * قیمت کل
   * مظنه
   * فی گرم ۱۸
   * وزن
   * نوع معامله
   * ساعت
   * ردیف
   *
   * مجموع = 1514
   */

  const columns = [

    {
      key: "total",
      title: "قیمت کل",
      width: 300
    },

    {
      key: "mazhane",
      title: "مظنه",
      width: 220
    },

    {
      key: "price18",
      title: "فی گرم ۱۸",
      width: 250
    },

    {
      key: "weight",
      title: "وزن",
      width: 180
    },

    {
      key: "type",
      title: "نوع معامله",
      width: 220
    },

    {
      key: "time",
      title: "ساعت",
      width: 190
    },

    {
      key: "index",
      title: "ردیف",
      width: 154
    }

  ];


  const headerHeight =
    68;

  const rowHeight =
    70;


  /*
   * Header جدول
   */

  let currentX =
    tableX;


  ctx.fillStyle =
    "#10243b";


  ctx.fillRect(
    tableX,
    tableY,
    tableW,
    headerHeight
  );


  columns.forEach(
    function (column) {

      const x =
        currentX;


      ctx.strokeStyle =
        "#29445f";

      ctx.lineWidth =
        2;

      ctx.strokeRect(
        x,
        tableY,
        column.width,
        headerHeight
      );


      pdfText(
        ctx,
        column.title,
        x + column.width / 2,
        tableY + headerHeight / 2,
        {
          size: 19,
          weight: "800",
          color: "#ffffff",
          align: "center"
        }
      );


      currentX +=
        column.width;

    }
  );


  /*
   * ردیف‌های جدول
   */

  pageTrades.forEach(
    function (trade, rowIndex) {

      const y =
        tableY +
        headerHeight +
        rowIndex *
          rowHeight;


      /*
       * رنگ زمینه یکی در میان
       */

      ctx.fillStyle =
        rowIndex % 2 === 0
          ? "#ffffff"
          : "#f7f9fb";


      ctx.fillRect(
        tableX,
        y,
        tableW,
        rowHeight
      );


      let x =
        tableX;


      columns.forEach(
        function (column) {

          ctx.strokeStyle =
            "#dce3ea";

          ctx.lineWidth =
            2;


          ctx.strokeRect(
            x,
            y,
            column.width,
            rowHeight
          );


          let value = "";


          if (
            column.key ===
            "total"
          ) {

            value =
              formatMoney(
                trade.totalPrice
              );

          }

          else if (
            column.key ===
            "mazhane"
          ) {

            value =
              formatMoney(
                trade.mazhane
              );

          }

          else if (
            column.key ===
            "price18"
          ) {

            value =
              formatMoney(
                trade.price18
              );

          }

          else if (
            column.key ===
            "weight"
          ) {

            value =
              `${formatNumber(
                trade.weight
              )} گرم`;

          }

          else if (
            column.key ===
            "type"
          ) {

            value =
              trade.type === "buy"
                ? "خرید"
                : "فروش";

          }

          else if (
            column.key ===
            "time"
          ) {

            value =
              trade.time ||
              "-";

          }

          else if (
            column.key ===
            "index"
          ) {

            value =
              formatNumber(
                rowIndex + 1
              );

          }


          let textColor =
            "#172536";


          if (
            column.key ===
            "type"
          ) {

            textColor =
              trade.type === "buy"
                ? "#15915b"
                : "#d8465b";

          }


          pdfText(
            ctx,
            value,
            x +
              column.width / 2,
            y +
              rowHeight / 2,
            {
              size:
                column.key === "type"
                  ? 20
                  : 18,
              weight:
                column.key === "type"
                  ? "800"
                  : "600",
              color:
                textColor,
              align: "center"
            }
          );


          x +=
            column.width;

        }
      );

    }
  );


  /*
   * خط جداکننده پایین جدول
   */

  const tableBottom =
    tableY +
    headerHeight +
    pageTrades.length *
      rowHeight;


  ctx.strokeStyle =
    "#10243b";

  ctx.lineWidth =
    4;

  ctx.beginPath();

  ctx.moveTo(
    tableX,
    tableBottom
  );

  ctx.lineTo(
    tableX + tableW,
    tableBottom
  );

  ctx.stroke();


  /* ================= FOOTER ================= */

  const footerY =
    HEIGHT - 115;


  ctx.strokeStyle =
    "#dce3ea";

  ctx.lineWidth =
    2;

  ctx.beginPath();

  ctx.moveTo(
    90,
    footerY - 28
  );

  ctx.lineTo(
    WIDTH - 90,
    footerY - 28
  );

  ctx.stroke();


  pdfText(
    ctx,
    "ماشین حساب معاملاتی شایان",
    WIDTH - 90,
    footerY + 5,
    {
      size: 18,
      weight: "800",
      color: "#607080",
      align: "right"
    }
  );


  pdfText(
    ctx,
    `صفحه ${pageNumber} از ${totalPages}`,
    90,
    footerY + 5,
    {
      size: 17,
      weight: "500",
      color: "#7b8794",
      align: "left"
    }
  );


  /*
   * قاب طلایی کوچک پایین صفحه
   */

  ctx.strokeStyle =
    "#d6ad43";

  ctx.lineWidth =
    2;

  ctx.strokeRect(
    45,
    HEIGHT - 75,
    WIDTH - 90,
    20
  );


  return canvas;

}


/* ================= GENERATE PDF ================= */

async function generateDatePDF(
  dateKey
) {

  const dateTrades =
    trades
      .filter(
        trade =>
          trade &&
          (
            trade.date ===
            dateKey
            ||
            (
              !trade.date &&
              trade.createdAt &&
              getDateKey(
                new Date(
                  trade.createdAt
                )
              ) === dateKey
            )
          )
      )
      .sort(
        (a, b) => {

          const timeA =
            a.createdAt
              ? new Date(
                  a.createdAt
                ).getTime()
              : 0;


          const timeB =
            b.createdAt
              ? new Date(
                  b.createdAt
                ).getTime()
              : 0;


          return timeA - timeB;

        }
      );


  if (
    dateTrades.length === 0
  ) {

    alert(
      "برای این تاریخ معامله‌ای پیدا نشد."
    );

    return;

  }


  /*
   * جلوگیری از چند کلیک پشت سر هم
   */

  const pdfButtons =
    document.querySelectorAll(
      `.history-folder[data-date="${dateKey}"] .pdf-action`
    );


  pdfButtons.forEach(
    button => {

      button.disabled =
        true;

      button.dataset.oldText =
        button.textContent;

      button.textContent =
        "در حال ساخت...";

    }
  );


  try {

    /*
     * کتابخانه jsPDF را در صورت نیاز
     * به صورت خودکار لود می‌کنیم.
     */

    const JsPDF =
      await loadJsPDF();


    if (!JsPDF) {

      throw new Error(
        "jsPDF is unavailable."
      );

    }


    const firstDate =
      dateTrades[0].createdAt
        ? new Date(
            dateTrades[0].createdAt
          )
        : new Date(
            `${dateKey}T00:00:00`
          );


    const persianDate =
      getPersianDate(
        firstDate
      );


    let totalBoughtWeight =
      0;


    let totalSoldWeight =
      0;


    dateTrades.forEach(
      trade => {

        const weight =
          Number(
            trade.weight
          ) || 0;


        if (
          trade.type ===
          "buy"
        ) {

          totalBoughtWeight +=
            weight;

        }

        else {

          totalSoldWeight +=
            weight;

        }

      }
    );


    /*
     * تعداد ردیف قابل نمایش در هر صفحه
     *
     * ارتفاع جدول به شکلی تنظیم شده که
     * اطلاعات در A4 از قاب خارج نشود.
     */

    const ROWS_PER_PAGE =
      22;


    const totalPages =
      Math.ceil(
        dateTrades.length /
        ROWS_PER_PAGE
      );


    /*
     * ساخت PDF A4
     */

    const pdf =
      new JsPDF({
        orientation:
          "portrait",
        unit:
          "mm",
        format:
          "a4",
        compress:
          true
      });


    for (
      let pageIndex = 0;
      pageIndex < totalPages;
      pageIndex++
    ) {

      if (
        pageIndex > 0
      ) {

        pdf.addPage();

      }


      const start =
        pageIndex *
        ROWS_PER_PAGE;


      const end =
        Math.min(
          start +
            ROWS_PER_PAGE,
          dateTrades.length
        );


      const pageTrades =
        dateTrades.slice(
          start,
          end
        );


      /*
       * شماره ردیف باید نسبت به کل معاملات
       * ادامه پیدا کند، نه اینکه در هر صفحه
       * دوباره از 1 شروع شود.
       *
       * برای همین یک کپی از معاملات صفحه
       * با شماره داخلی ایجاد می‌کنیم.
       */

      const numberedPageTrades =
        pageTrades.map(
          function (
            trade,
            index
          ) {

            return {
              ...trade,
              __pdfIndex:
                start +
                index +
                1
            };

          }
        );


      /*
       * Canvas مخصوص همان صفحه
       */

      const canvas =
        createPDFPageCanvas(
          dateTrades,
          persianDate,
          numberedPageTrades.map(
            function (trade) {

              /*
               * createPDFPageCanvas شماره
               * را از rowIndex می‌گیرد.
               *
               * برای حفظ شماره کلی، یک فیلد
               * موقت اضافه می‌کنیم.
               */

              return trade;

            }
          ),
          pageIndex + 1,
          totalPages,
          totalBoughtWeight,
          totalSoldWeight
        );


      /*
       * اصلاح شماره ردیف در Canvas:
       * اگر صفحه دوم یا بعدی باشد، شماره‌ها
       * باید ادامه پیدا کنند.
       *
       * دوباره Canvas را با نسخه مخصوص شماره‌ها
       * می‌سازیم.
       */

      if (
        start > 0
      ) {

        /*
         * در این حالت Canvas اصلی را بازسازی
         * می‌کنیم تا شماره ردیف‌ها درست باشند.
         */

        const ctx =
          canvas.getContext(
            "2d"
          );


        /*
         * مختصات جدول
         */

        const tableX =
          70;

        const tableY =
          530;

        const tableW =
          1654 - 140;

        const headerHeight =
          68;

        const rowHeight =
          70;


        /*
         * آخرین ستون "ردیف" را دوباره
         * با شماره صحیح نقاشی می‌کنیم.
         */

        const indexColumnWidth =
          154;


        const indexX =
          tableX +
          tableW -
          indexColumnWidth;


        pageTrades.forEach(
          function (
            trade,
            rowIndex
          ) {

            const y =
              tableY +
              headerHeight +
              rowIndex *
                rowHeight;


            /*
             * زمینه سلول
             */

            ctx.fillStyle =
              rowIndex % 2 === 0
                ? "#ffffff"
                : "#f7f9fb";


            ctx.fillRect(
              indexX + 2,
              y + 2,
              indexColumnWidth - 4,
              rowHeight - 4
            );


            ctx.strokeStyle =
              "#dce3ea";

            ctx.lineWidth =
              2;

            ctx.strokeRect(
              indexX,
              y,
              indexColumnWidth,
              rowHeight
            );


            pdfText(
              ctx,
              formatNumber(
                start +
                rowIndex +
                1
              ),
              indexX +
                indexColumnWidth / 2,
              y +
                rowHeight / 2,
              {
                size: 18,
                weight: "600",
                color: "#172536",
                align: "center"
              }
            );

          }
        );

      }


      /*
       * تبدیل Canvas به تصویر
       */

      const imageData =
        canvas.toDataURL(
          "image/png",
          1.0
        );


      /*
       * قرار دادن دقیق تصویر در A4
       */

      pdf.addImage(
        imageData,
        "PNG",
        0,
        0,
        210,
        297,
        undefined,
        "FAST"
      );

    }


    /*
     * نام فایل
     */

    const safeDate =
      persianDate
        .replace(
          /[\/\\:*?"<>|]/g,
          "-"
        );


    const filename =
      `گزارش معاملات - ${safeDate}.pdf`;


    /*
     * دانلود مستقیم
     */

    pdf.save(
      filename
    );

  }

  catch (error) {

    console.error(
      "PDF ERROR:",
      error
    );


    alert(
      "در ساخت فایل PDF مشکلی پیش آمد. اتصال اینترنت را بررسی کنید و دوباره امتحان کنید."
    );

  }

  finally {

    pdfButtons.forEach(
      button => {

        button.disabled =
          false;

        button.textContent =
          button.dataset.oldText ||
          "PDF";

      }
    );

  }

}


/* ================= DEMO ================= */

function calculateDemo() {

  const current =
    calculateLedger();


  const currentPosition =
    current.position;


  const currentWeight =
    Math.abs(
      currentPosition
    );


  const currentAverage =
    current.averageCost;


  const currentStatus =
    document.getElementById(
      "demoCurrentStatus"
    );


  const currentWeightElement =
    document.getElementById(
      "demoCurrentWeight"
    );


  const currentAverageElement =
    document.getElementById(
      "demoCurrentAverage"
    );


  if (
    !currentStatus ||
    !currentWeightElement ||
    !currentAverageElement
  ) {
    return;
  }


  if (currentPosition > 0) {

    currentStatus.textContent =
      "موجودی خرید";

  }

  else if (currentPosition < 0) {

    currentStatus.textContent =
      "فروش باز";

  }

  else {

    currentStatus.textContent =
      "بدون موجودی";

  }


  currentWeightElement.textContent =
    `${formatNumber(
      currentWeight
    )} گرم`;


  currentAverageElement.textContent =
    `${formatMoney(
      currentAverage
    )} تومان`;


  const demoWeightElement =
    document.getElementById(
      "demoWeight"
    );


  const demoPriceElement =
    document.getElementById(
      "demoPrice18"
    );


  const demoTypeElement =
    document.getElementById(
      "demoType"
    );


  const resultAverage =
    document.getElementById(
      "demoResultAverage"
    );


  const resultMazhane =
    document.getElementById(
      "demoResultMazhane"
    );


  const resultMessage =
    document.getElementById(
      "demoResultMessage"
    );


  if (
    !demoWeightElement ||
    !demoPriceElement ||
    !demoTypeElement ||
    !resultAverage ||
    !resultMazhane ||
    !resultMessage
  ) {
    return;
  }


  const demoWeight =
    normalizeNumber(
      demoWeightElement.value
    );


  const demoPrice =
    normalizeNumber(
      demoPriceElement.value
    );


  const demoType =
    demoTypeElement.value;


  if (
    demoWeight <= 0 ||
    demoPrice <= 0
  ) {

    resultAverage.textContent =
      "0 تومان";

    resultMazhane.textContent =
      "مظنه میانگین: 0 تومان";

    resultMessage.textContent =
      "وزن و فی معامله فرضی را وارد کنید.";

    resultMessage.className =
      "demo-result-message";

    return;

  }


  let simulatedPosition =
    currentPosition;


  let simulatedAverage =
    currentAverage;


  let simulatedRealized =
    0;


  /* ================= BUY DEMO ================= */

  if (demoType === "buy") {

    if (simulatedPosition < 0) {

      const shortQty =
        Math.abs(
          simulatedPosition
        );


      const closeQty =
        Math.min(
          demoWeight,
          shortQty
        );


      simulatedRealized =
        closeQty *
        (
          simulatedAverage -
          demoPrice
        );


      simulatedPosition +=
        closeQty;


      if (
        demoWeight >
        closeQty
      ) {

        const remaining =
          demoWeight -
          closeQty;


        simulatedPosition =
          remaining;


        simulatedAverage =
          demoPrice;

      }

      else if (
        simulatedPosition === 0
      ) {

        simulatedAverage = 0;

      }

    }

    else if (
      simulatedPosition > 0
    ) {

      const oldQty =
        simulatedPosition;


      const newQty =
        oldQty +
        demoWeight;


      simulatedAverage =
        (
          oldQty *
          simulatedAverage +
          demoWeight *
          demoPrice
        ) /
        newQty;


      simulatedPosition =
        newQty;

    }

    else {

      simulatedPosition =
        demoWeight;

      simulatedAverage =
        demoPrice;

    }

  }


  /* ================= SELL DEMO ================= */

  else {

    if (simulatedPosition > 0) {

      const closeQty =
        Math.min(
          simulatedPosition,
          demoWeight
        );


      simulatedRealized =
        closeQty *
        (
          demoPrice -
          simulatedAverage
        );


      simulatedPosition -=
        closeQty;


      if (
        demoWeight >
        closeQty
      ) {

        const remaining =
          demoWeight -
          closeQty;


        simulatedPosition =
          -remaining;


        simulatedAverage =
          demoPrice;

      }

      else if (
        simulatedPosition === 0
      ) {

        simulatedAverage = 0;

      }

    }

    else if (
      simulatedPosition < 0
    ) {

      const oldShortQty =
        Math.abs(
          simulatedPosition
        );


      const newShortQty =
        oldShortQty +
        demoWeight;


      simulatedAverage =
        (
          oldShortQty *
          simulatedAverage +
          demoWeight *
          demoPrice
        ) /
        newShortQty;


      simulatedPosition =
        -newShortQty;

    }

    else {

      simulatedPosition =
        -demoWeight;

      simulatedAverage =
        demoPrice;

    }

  }


  const simulatedMazhane =
    simulatedAverage *
    FACTOR;


  resultAverage.textContent =
    `${formatMoney(
      simulatedAverage
    )} تومان`;


  resultMazhane.textContent =
    `مظنه میانگین: ${formatMoney(
      simulatedMazhane
    )} تومان`;


  let statusText = "";


  if (
    simulatedPosition > 0
  ) {

    statusText =
      `بعد از این خرید، موجودی شما ${formatNumber(
        Math.abs(simulatedPosition)
      )} گرم با میانگین ${formatMoney(
        simulatedAverage
      )} تومان می‌شود.`;

  }

  else if (
    simulatedPosition < 0
  ) {

    statusText =
      `بعد از این فروش، فروش باز شما ${formatNumber(
        Math.abs(simulatedPosition)
      )} گرم با میانگین ${formatMoney(
        simulatedAverage
      )} تومان می‌شود.`;

  }

  else {

    statusText =
      "با این معامله موجودی باز شما صفر می‌شود.";

  }


  if (
    simulatedRealized !== 0
  ) {

    statusText +=
      ` سود/زیان این سناریو: ${formatMoney(
        simulatedRealized
      )} تومان.`;

  }


  resultMessage.textContent =
    statusText;


  resultMessage.className =
    "demo-result-message success";

}


/* ================= DEMO INPUTS ================= */

const demoWeightInput =
  document.getElementById(
    "demoWeight"
  );


const demoPriceInput =
  document.getElementById(
    "demoPrice18"
  );


const demoTypeInput =
  document.getElementById(
    "demoType"
  );


if (demoWeightInput) {

  demoWeightInput.addEventListener(
    "input",
    function () {

      this.value =
        this.value.replace(
          /[^0-9۰-۹٠-٩.,]/g,
          ""
        );

      calculateDemo();

    }
  );

}


if (demoPriceInput) {

  demoPriceInput.addEventListener(
    "input",
    function () {

      this.value =
        formatInputNumber(
          this.value
        );

      calculateDemo();

    }
  );

}


if (demoTypeInput) {

  demoTypeInput.addEventListener(
    "change",
    calculateDemo
  );

}


/* ================= TRADE INPUTS ================= */

const weightInput =
  document.getElementById(
    "weight"
  );


const price18Input =
  document.getElementById(
    "price18"
  );


const mazhaneInput =
  document.getElementById(
    "mazhane"
  );


const totalPriceInput =
  document.getElementById(
    "totalPrice"
  );


function updateFromPrice18() {

  const price =
    normalizeNumber(
      price18Input.value
    );


  const weight =
    normalizeNumber(
      weightInput.value
    );


  if (price > 0) {

    mazhaneInput.value =
      formatInputNumber(
        price * FACTOR
      );

  }


  if (
    price > 0 &&
    weight > 0
  ) {

    totalPriceInput.value =
      formatInputNumber(
        price * weight
      );

  }

}


function updateFromMazhane() {

  const mazhane =
    normalizeNumber(
      mazhaneInput.value
    );


  const weight =
    normalizeNumber(
      weightInput.value
    );


  if (mazhane > 0) {

    const price =
      mazhane / FACTOR;


    price18Input.value =
      formatInputNumber(
        price
      );


    if (weight > 0) {

      totalPriceInput.value =
        formatInputNumber(
          price * weight
        );

    }

  }

}


function updateFromTotal() {

  const total =
    normalizeNumber(
      totalPriceInput.value
    );


  const weight =
    normalizeNumber(
      weightInput.value
    );


  if (
    total > 0 &&
    weight > 0
  ) {

    const price =
      total / weight;


    price18Input.value =
      formatInputNumber(
        price
      );


    mazhaneInput.value =
      formatInputNumber(
        price * FACTOR
      );

  }

}


if (
  weightInput &&
  price18Input &&
  mazhaneInput &&
  totalPriceInput
) {

  weightInput.addEventListener(
    "input",
    function () {

      this.value =
        this.value.replace(
          /[^0-9۰-۹٠-٩.,]/g,
          ""
        );


      const weight =
        normalizeNumber(
          this.value
        );


      const price =
        normalizeNumber(
          price18Input.value
        );


      if (
        weight > 0 &&
        price > 0
      ) {

        totalPriceInput.value =
          formatInputNumber(
            weight * price
          );

      }

    }
  );


  price18Input.addEventListener(
    "input",
    function () {

      this.value =
        formatInputNumber(
          this.value
        );

      updateFromPrice18();

    }
  );


  mazhaneInput.addEventListener(
    "input",
    function () {

      this.value =
        formatInputNumber(
          this.value
        );

      updateFromMazhane();

    }
  );


  totalPriceInput.addEventListener(
    "input",
    function () {

      this.value =
        formatInputNumber(
          this.value
        );

      updateFromTotal();

    }
  );

}


/* ================= SAVE TRADE ================= */

const saveTradeButton =
  document.getElementById(
    "saveTrade"
  );


if (saveTradeButton) {

  saveTradeButton.addEventListener(
    "click",
    function () {

      const type =
        document.getElementById(
          "tradeType"
        ).value;


      const weight =
        normalizeNumber(
          weightInput.value
        );


      const price18 =
        normalizeNumber(
          price18Input.value
        );


      const mazhane =
        normalizeNumber(
          mazhaneInput.value
        );


      const totalPrice =
        normalizeNumber(
          totalPriceInput.value
        );


      if (weight <= 0) {

        alert(
          "وزن معامله را وارد کنید."
        );

        return;

      }


      if (price18 <= 0) {

        alert(
          "فی گرم ۱۸ را وارد کنید."
        );

        return;

      }


      if (totalPrice <= 0) {

        alert(
          "قیمت کل معامله را وارد کنید."
        );

        return;

      }


      const finalMazhane =
        mazhane > 0
          ? mazhane
          : price18 * FACTOR;


      const now =
        new Date();


      const trade = {

        id:
          Date.now() +
          Math.floor(
            Math.random() * 1000
          ),

        type,

        weight,

        price18,

        mazhane:
          finalMazhane,

        totalPrice,

        date:
          getDateKey(now),

        time:
          getTime(now),

        createdAt:
          now.toISOString()

      };


      trades.push(
        trade
      );


      saveTrades();


      weightInput.value = "";

      price18Input.value = "";

      mazhaneInput.value = "";

      totalPriceInput.value = "";


      renderAll();

      renderTodayTrades();

      renderHistory();

      showPage("trades");

    }
  );

}


/* ================= EDIT ================= */

function editTrade(id) {

  const trade =
    trades.find(
      item =>
        Number(item.id) ===
        Number(id)
    );


  if (!trade) {
    return;
  }


  editingTradeId =
    id;


  const editType =
    document.getElementById(
      "editType"
    );


  const editWeight =
    document.getElementById(
      "editWeight"
    );


  const editPrice18 =
    document.getElementById(
      "editPrice18"
    );


  const editMazhane =
    document.getElementById(
      "editMazhane"
    );


  const editTotalPrice =
    document.getElementById(
      "editTotalPrice"
    );


  if (
    !editType ||
    !editWeight ||
    !editPrice18 ||
    !editMazhane ||
    !editTotalPrice
  ) {
    return;
  }


  editType.value =
    trade.type;


  editWeight.value =
    formatInputNumber(
      trade.weight
    );


  editPrice18.value =
    formatInputNumber(
      trade.price18
    );


  editMazhane.value =
    formatInputNumber(
      trade.mazhane
    );


  editTotalPrice.value =
    formatInputNumber(
      trade.totalPrice
    );


  document.getElementById(
    "editModal"
  ).classList.add(
    "show"
  );

}


const closeModalButton =
  document.getElementById(
    "closeModal"
  );


if (closeModalButton) {

  closeModalButton.addEventListener(
    "click",
    function () {

      document.getElementById(
        "editModal"
      ).classList.remove(
        "show"
      );

    }
  );

}


const updateTradeButton =
  document.getElementById(
    "updateTrade"
  );


if (updateTradeButton) {

  updateTradeButton.addEventListener(
    "click",
    function () {

      const trade =
        trades.find(
          item =>
            Number(item.id) ===
            Number(editingTradeId)
        );


      if (!trade) {
        return;
      }


      const weight =
        normalizeNumber(
          document.getElementById(
            "editWeight"
          ).value
        );


      const price18 =
        normalizeNumber(
          document.getElementById(
            "editPrice18"
          ).value
        );


      const mazhane =
        normalizeNumber(
          document.getElementById(
            "editMazhane"
          ).value
        );


      const totalPrice =
        normalizeNumber(
          document.getElementById(
            "editTotalPrice"
          ).value
        );


      if (
        weight <= 0 ||
        price18 <= 0 ||
        totalPrice <= 0
      ) {

        alert(
          "اطلاعات معامله کامل نیست."
        );

        return;

      }


      trade.type =
        document.getElementById(
          "editType"
        ).value;


      trade.weight =
        weight;


      trade.price18 =
        price18;


      trade.mazhane =
        mazhane > 0
          ? mazhane
          : price18 * FACTOR;


      trade.totalPrice =
        totalPrice;


      saveTrades();


      document.getElementById(
        "editModal"
      ).classList.remove(
        "show"
      );


      renderAll();

      renderTodayTrades();

      renderHistory();

    }
  );

}


/* ================= DELETE ================= */

function deleteTrade(id) {

  const tradeToDelete =
    trades.find(
      trade =>
        Number(trade.id) ===
        Number(id)
    );


  if (!tradeToDelete) {
    return;
  }


  const ok =
    confirm(
      "آیا از حذف این معامله مطمئن هستید؟"
    );


  if (!ok) {
    return;
  }


  /*
   * تاریخ معامله قبل از حذف ذخیره می‌شود.
   */

  let deletedTradeDate =
    tradeToDelete.date;


  if (
    !deletedTradeDate &&
    tradeToDelete.createdAt
  ) {

    const createdDate =
      new Date(
        tradeToDelete.createdAt
      );


    if (
      !isNaN(
        createdDate.getTime()
      )
    ) {

      deletedTradeDate =
        getDateKey(
          createdDate
        );

    }

  }


  /*
   * حذف معامله
   */

  trades =
    trades.filter(
      trade =>
        Number(trade.id) !==
        Number(id)
    );


  saveTrades();


  /*
   * رندر بخش‌های عمومی
   */

  renderHome();

  renderTodayTrades();

  calculateDemo();


  /*
   * اگر هنوز معامله‌ای از همان تاریخ
   * باقی مانده باشد، همان پوشه باز می‌ماند.
   */

  const sameDateStillExists =
    deletedTradeDate &&
    trades.some(
      trade => {

        let tradeDate =
          trade.date;


        if (
          !tradeDate &&
          trade.createdAt
        ) {

          const d =
            new Date(
              trade.createdAt
            );


          if (
            !isNaN(
              d.getTime()
            )
          ) {

            tradeDate =
              getDateKey(d);

          }

        }


        return (
          tradeDate ===
          deletedTradeDate
        );

      }
    );


  if (
    sameDateStillExists
  ) {

    renderHistory(
      deletedTradeDate
    );

  }

  else {

    renderHistory();

  }

}


/* ================= SETTINGS ================= */

const factorInput =
  document.getElementById(
    "factorInput"
  );


if (factorInput) {

  factorInput.value =
    FACTOR;

}


const saveFactorButton =
  document.getElementById(
    "saveFactor"
  );


if (saveFactorButton) {

  saveFactorButton.addEventListener(
    "click",
    function () {

      const value =
        Number(
          factorInput.value
        );


      if (
        !value ||
        value <= 0
      ) {

        alert(
          "ضریب واردشده معتبر نیست."
        );

        return;

      }


      FACTOR =
        value;


      localStorage.setItem(
        "shayan_gold_factor",
        String(FACTOR)
      );


      renderAll();

      calculateDemo();


      alert(
        "ضریب با موفقیت ذخیره شد."
      );

    }
  );

}


/* ================= NAVIGATION ================= */

function showPage(pageId) {

  document
    .querySelectorAll(".page")
    .forEach(
      page =>
        page.classList.remove(
          "active"
        )
    );


  document
    .querySelectorAll(".nav-btn")
    .forEach(
      button =>
        button.classList.remove(
          "active"
        )
    );


  const page =
    document.getElementById(
      pageId
    );


  const navButton =
    document.querySelector(
      `.nav-btn[data-page="${pageId}"]`
    );


  if (page) {

    page.classList.add(
      "active"
    );

  }


  if (navButton) {

    navButton.classList.add(
      "active"
    );

  }


  if (pageId === "trades") {

    renderTodayTrades();

  }


  if (pageId === "history") {

    /*
     * renderHistory خودش وضعیت پوشه‌های
     * باز را از DOM قبلی حفظ می‌کند.
     */

    renderHistory();

  }


  if (pageId === "demo") {

    calculateDemo();

  }

}


document
  .querySelectorAll(".nav-btn")
  .forEach(
    button => {

      button.addEventListener(
        "click",
        function () {

          showPage(
            this.dataset.page
          );

        }
      );

    }
  );


/* ================= RENDER ALL ================= */

function renderAll() {

  renderHome();

  renderTodayTrades();

  renderHistory();

  calculateDemo();

}


renderAll();

showPage("home");