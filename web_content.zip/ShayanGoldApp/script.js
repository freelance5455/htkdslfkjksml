const DEFAULT_FACTOR = 4.3318;

let FACTOR =
  Number(localStorage.getItem("shayan_gold_factor")) ||
  DEFAULT_FACTOR;

let trades =
  JSON.parse(
    localStorage.getItem("shayan_gold_trades") || "[]"
  );

let editingTradeId = null;


/* =====================================================
   DATE
===================================================== */

function getPersianDate(date = new Date()) {

  return new Intl.DateTimeFormat(
    "fa-IR-u-ca-persian",
    {
      year: "numeric",
      month: "long",
      day: "numeric"
    }
  ).format(date);

}


function getDateKey(date = new Date()) {

  const y = date.getFullYear();

  const m = String(
    date.getMonth() + 1
  ).padStart(2, "0");

  const d = String(
    date.getDate()
  ).padStart(2, "0");

  return `${y}-${m}-${d}`;

}


function getTime(date = new Date()) {

  return date.toLocaleTimeString(
    "fa-IR",
    {
      hour: "2-digit",
      minute: "2-digit"
    }
  );

}


/* =====================================================
   NUMBER FORMAT
===================================================== */

function formatNumber(number) {

  return Number(number || 0)
    .toLocaleString(
      "en-US",
      {
        maximumFractionDigits: 3
      }
    );

}


function formatMoney(number) {

  return Number(number || 0)
    .toLocaleString(
      "en-US",
      {
        maximumFractionDigits: 0
      }
    );

}


/* =====================================================
   SAVE
===================================================== */

function saveTrades() {

  localStorage.setItem(
    "shayan_gold_trades",
    JSON.stringify(trades)
  );

}


/* =====================================================
   ACCOUNTING ENGINE
===================================================== */

function calculateLedger() {

  let position = 0;

  /*
    اگر Long باشیم:
    averageCost = میانگین قیمت خرید موجودی باقی‌مانده

    اگر Short باشیم:
    averageCost = میانگین قیمت فروش باز
  */

  let averageCost = 0;

  let realizedProfit = 0;

  let closedTrades = [];


  const sortedTrades =
    [...trades].sort(
      (a, b) =>
        Number(a.id) -
        Number(b.id)
    );


  sortedTrades.forEach(
    function(trade) {

      const qty =
        Number(trade.weight);

      const price =
        Number(trade.price18);


      if (
        !qty ||
        qty <= 0 ||
        !price ||
        price <= 0
      ) {

        return;

      }


      /* =================================================
         BUY
      ================================================= */

      if (trade.type === "buy") {


        /* -----------------------------------------------
           حالت Long
        ----------------------------------------------- */

        if (position > 0) {

          const oldQty =
            position;

          const newQty =
            oldQty + qty;


          averageCost =
            (
              (oldQty * averageCost) +
              (qty * price)
            ) / newQty;


          position =
            newQty;

          return;

        }


        /* -----------------------------------------------
           حالت صفر
        ----------------------------------------------- */

        if (position === 0) {

          position =
            qty;

          averageCost =
            price;

          return;

        }


        /* -----------------------------------------------
           حالت Short
        ----------------------------------------------- */

        if (position < 0) {

          const shortQty =
            Math.abs(position);


          const closeQty =
            Math.min(
              qty,
              shortQty
            );


          /*
             سود Short:

             مقدار بسته‌شده ×
             (قیمت فروش باز - قیمت خرید)
          */

          const pnl =
            closeQty *
            (
              averageCost -
              price
            );


          realizedProfit +=
            pnl;


          closedTrades.push({

            id:
              trade.id,

            dateKey:
              trade.dateKey,

            dateText:
              trade.dateText,

            time:
              trade.time,

            type:
              "short",

            weight:
              closeQty,

            openPrice:
              averageCost,

            closePrice:
              price,

            profit:
              pnl

          });


          position +=
            closeQty;


          const remainingBuy =
            qty - closeQty;


          /*
             اگر خرید بیشتر از Short باشد،
             مقدار اضافه تبدیل به Long می‌شود.
          */

          if (
            position === 0 &&
            remainingBuy > 0
          ) {

            position =
              remainingBuy;

            averageCost =
              price;

          }

        }

      }


      /* =================================================
         SELL
      ================================================= */

      else {


        /* -----------------------------------------------
           فروش از موجودی Long
        ----------------------------------------------- */

        if (position > 0) {

          const closeQty =
            Math.min(
              qty,
              position
            );


          /*
             سود Long:

             مقدار فروش ×
             (قیمت فروش - میانگین خرید)
          */

          const pnl =
            closeQty *
            (
              price -
              averageCost
            );


          realizedProfit +=
            pnl;


          closedTrades.push({

            id:
              trade.id,

            dateKey:
              trade.dateKey,

            dateText:
              trade.dateText,

            time:
              trade.time,

            type:
              "long",

            weight:
              closeQty,

            openPrice:
              averageCost,

            closePrice:
              price,

            profit:
              pnl

          });


          /*
             میانگین خرید در زمان فروش
             تغییر نمی‌کند.

             مثال:

             500 گرم
             میانگین 7,500,000

             فروش 300 گرم

             200 گرم باقی می‌ماند
             با همان میانگین 7,500,000
          */

          position -=
            closeQty;


          const remainingSell =
            qty - closeQty;


          /*
             اگر فروش بیشتر از موجودی باشد،
             مقدار اضافه وارد Short می‌شود.
          */

          if (
            position === 0 &&
            remainingSell > 0
          ) {

            position =
              -remainingSell;

            averageCost =
              price;

          }

        }


        /* -----------------------------------------------
           حالت صفر یا Short
        ----------------------------------------------- */

        else if (position <= 0) {


          /* شروع Short */

          if (position === 0) {

            position =
              -qty;

            averageCost =
              price;

          }


          /* افزایش Short */

          else {

            const oldShortQty =
              Math.abs(position);


            const newShortQty =
              oldShortQty + qty;


            /*
               میانگین وزنی قیمت فروش باز
            */

            averageCost =
              (
                (oldShortQty * averageCost) +
                (qty * price)
              ) / newShortQty;


            position =
              -newShortQty;

          }

        }

      }

    }
  );


  return {

    position,

    /*
      Long:
      فی میانگین موجودی باقی‌مانده

      Short:
      فی میانگین فروش باز
    */

    averageCost,

    realizedProfit,

    closedTrades

  };

}


/* =====================================================
   TODAY
===================================================== */

function isToday(trade) {

  return (
    trade.dateKey ===
    getDateKey()
  );

}


/* =====================================================
   HOME
===================================================== */

function renderHome() {

  document.getElementById(
    "todayDate"
  ).textContent =
    getPersianDate();


  const todayTrades =
    trades.filter(isToday);


  let bought = 0;

  let sold = 0;


  todayTrades.forEach(
    function(trade) {

      if (trade.type === "buy") {

        bought +=
          Number(trade.weight);

      }

      else {

        sold +=
          Number(trade.weight);

      }

    }
  );


  const ledger =
    calculateLedger();


  document.getElementById(
    "homeTradeCount"
  ).textContent =
    formatNumber(
      todayTrades.length
    );


  document.getElementById(
    "homeBought"
  ).textContent =
    formatNumber(bought)
    + " گرم";


  document.getElementById(
    "homeSold"
  ).textContent =
    formatNumber(sold)
    + " گرم";


  /*
    موجودی Long

    اگر Short داشته باشیم،
    موجودی واقعی خرید صفر است.
  */

  document.getElementById(
    "homeBalance"
  ).textContent =
    formatNumber(
      Math.max(ledger.position, 0)
    )
    + " گرم";


  /* =================================================
     میانگین موقعیت فعلی
  ================================================= */

  const homeAverage =
    document.getElementById(
      "homeAveragePrice"
    );


  if (ledger.position > 0) {

    /*
      موجودی خرید داریم
    */

    homeAverage.textContent =
      "فی میانگین موجودی: " +
      formatMoney(
        ledger.averageCost
      ) +
      " تومان";

  }

  else if (ledger.position < 0) {

    /*
      فروش باز داریم
    */

    homeAverage.textContent =
      "فی میانگین فروش باز: " +
      formatMoney(
        ledger.averageCost
      ) +
      " تومان";

  }

  else {

    homeAverage.textContent =
      "0 تومان";

  }


  renderSimpleTradeList(
    document.getElementById(
      "homeTrades"
    ),
    todayTrades
  );

}


/* =====================================================
   TRADES PAGE
===================================================== */

function renderTradesPage() {

  renderSimpleTradeList(
    document.getElementById(
      "todayTrades"
    ),
    trades.filter(isToday)
  );

}


/* =====================================================
   TRADE LIST
===================================================== */

function renderSimpleTradeList(
  container,
  list
) {

  container.innerHTML = "";


  if (!list.length) {

    container.innerHTML = `
      <div class="empty">
        هنوز معامله‌ای ثبت نشده است.
      </div>
    `;

    return;

  }


  const sorted =
    [...list].sort(
      (a, b) =>
        Number(b.id) -
        Number(a.id)
    );


  sorted.forEach(
    function(trade) {

      const item =
        document.createElement(
          "div"
        );


      item.className =
        "trade-item";


      const typeText =
        trade.type === "buy"
          ? "خرید"
          : "فروش";


      const typeClass =
        trade.type === "buy"
          ? "buy"
          : "sell";


      item.innerHTML = `

        <div class="trade-main">

          <div class="trade-type ${typeClass}">
            ${typeText}
          </div>

          <div>
            ${formatNumber(trade.weight)}
            گرم
          </div>

        </div>

        <div class="trade-details">

          <span>
            فی:
            ${formatMoney(trade.price18)}
            تومان
          </span>

          <span>
            مظنه:
            ${formatMoney(trade.mazhane)}
            تومان
          </span>

          <span>
            ${trade.time}
          </span>

        </div>

      `;


      container.appendChild(item);

    }
  );

}


/* =====================================================
   HISTORY
===================================================== */

function renderHistory() {

  const container =
    document.getElementById(
      "historyList"
    );


  container.innerHTML = "";


  if (!trades.length) {

    container.innerHTML = `
      <div class="empty">
        تاریخچه‌ای وجود ندارد.
      </div>
    `;

    return;

  }


  const groups = {};


  trades.forEach(
    function(trade) {

      if (!groups[trade.dateKey]) {

        groups[trade.dateKey] = {

          dateText:
            trade.dateText,

          trades: []

        };

      }


      groups[
        trade.dateKey
      ].trades.push(trade);

    }
  );


  const dates =
    Object.keys(groups)
      .sort()
      .reverse();


  dates.forEach(
    function(dateKey, index) {

      const group =
        groups[dateKey];


      const folder =
        document.createElement(
          "div"
        );


      folder.className =
        "history-folder";


      if (index === 0) {

        folder.classList.add(
          "open"
        );

      }


      const header =
        document.createElement(
          "button"
        );


      header.className =
        "folder-header";


      header.innerHTML = `

        <div class="folder-title">

          <span class="folder-icon">
            📁
          </span>

          <span>
            ${group.dateText}
          </span>

        </div>

        <span class="folder-count">

          ${formatNumber(
            group.trades.length
          )}
          معامله

        </span>

      `;


      header.addEventListener(
        "click",
        function() {

          folder.classList.toggle(
            "open"
          );

        }
      );


      folder.appendChild(header);


      const content =
        document.createElement(
          "div"
        );


      content.className =
        "folder-content";


      const sortedTrades =
        [...group.trades]
          .sort(
            (a, b) =>
              Number(b.id) -
              Number(a.id)
          );


      sortedTrades.forEach(
        function(trade) {

          const row =
            document.createElement(
              "div"
            );


          row.className =
            "history-trade";


          const typeText =
            trade.type === "buy"
              ? "خرید"
              : "فروش";


          const typeClass =
            trade.type === "buy"
              ? "buy"
              : "sell";


          row.innerHTML = `

            <div class="history-trade-top">

              <div class="trade-type ${typeClass}">
                ${typeText}
              </div>

              <div class="history-actions">

                <button
                  class="small-action edit-btn"
                  data-id="${trade.id}">
                  ✏️
                </button>

                <button
                  class="small-action delete-btn"
                  data-id="${trade.id}">
                  🗑️
                </button>

              </div>

            </div>

            <div class="history-trade-info">

              <div>

                <span>
                  وزن
                </span>

                <strong>
                  ${formatNumber(
                    trade.weight
                  )}
                  گرم
                </strong>

              </div>

              <div>

                <span>
                  فی گرم ۱۸
                </span>

                <strong>
                  ${formatMoney(
                    trade.price18
                  )}
                  تومان
                </strong>

              </div>

              <div>

                <span>
                  مظنه
                </span>

                <strong>
                  ${formatMoney(
                    trade.mazhane
                  )}
                  تومان
                </strong>

              </div>

            </div>

            <div class="history-time">
              ساعت ${trade.time}
            </div>

          `;


          row.querySelector(
            ".edit-btn"
          ).addEventListener(
            "click",
            function(e) {

              e.stopPropagation();

              openEditModal(
                trade.id
              );

            }
          );


          row.querySelector(
            ".delete-btn"
          ).addEventListener(
            "click",
            function(e) {

              e.stopPropagation();

              deleteTrade(
                trade.id
              );

            }
          );


          content.appendChild(row);

        }
      );


      folder.appendChild(content);

      container.appendChild(folder);

    }
  );

}


/* =====================================================
   DELETE
===================================================== */

function deleteTrade(id) {

  const trade =
    trades.find(
      item =>
        Number(item.id) ===
        Number(id)
    );


  if (!trade) return;


  const confirmed =
    confirm(
      `معامله ${
        trade.type === "buy"
          ? "خرید"
          : "فروش"
      } ${
        formatNumber(trade.weight)
      } گرم حذف شود؟`
    );


  if (!confirmed) return;


  trades =
    trades.filter(
      item =>
        Number(item.id) !==
        Number(id)
    );


  saveTrades();

  refreshAll();

}


/* =====================================================
   EDIT MODAL
===================================================== */

function openEditModal(id) {

  const trade =
    trades.find(
      item =>
        Number(item.id) ===
        Number(id)
    );


  if (!trade) return;


  editingTradeId = id;


  document.getElementById(
    "editType"
  ).value =
    trade.type;


  document.getElementById(
    "editWeight"
  ).value =
    trade.weight;


  document.getElementById(
    "editPrice18"
  ).value =
    trade.price18;


  document.getElementById(
    "editMazhane"
  ).value =
    trade.mazhane;


  document.getElementById(
    "editModal"
  ).classList.add("show");

}


document.getElementById(
  "closeModal"
).addEventListener(
  "click",
  function() {

    document.getElementById(
      "editModal"
    ).classList.remove("show");

    editingTradeId = null;

  }
);


/* =====================================================
   UPDATE TRADE
===================================================== */

document.getElementById(
  "updateTrade"
).addEventListener(
  "click",
  function() {

    if (!editingTradeId) return;


    const type =
      document.getElementById(
        "editType"
      ).value;


    const weight =
      Number(
        document.getElementById(
          "editWeight"
        ).value
      );


    const price18 =
      Number(
        document.getElementById(
          "editPrice18"
        ).value
      );


    let mazhane =
      Number(
        document.getElementById(
          "editMazhane"
        ).value
      );


    if (
      !weight ||
      weight <= 0 ||
      !price18 ||
      price18 <= 0
    ) {

      alert(
        "اطلاعات معامله را کامل وارد کن."
      );

      return;

    }


    const trade =
      trades.find(
        item =>
          Number(item.id) ===
          Number(editingTradeId)
      );


    if (!trade) return;


    trade.type =
      type;

    trade.weight =
      weight;

    trade.price18 =
      price18;


    if (!mazhane) {

      mazhane =
        price18 * FACTOR;

    }


    trade.mazhane =
      mazhane;


    saveTrades();


    document.getElementById(
      "editModal"
    ).classList.remove("show");


    editingTradeId = null;


    refreshAll();

  }
);


/* =====================================================
   ADD TRADE
===================================================== */

document.getElementById(
  "saveTrade"
).addEventListener(
  "click",
  function() {

    const type =
      document.getElementById(
        "tradeType"
      ).value;


    const weight =
      Number(
        document.getElementById(
          "weight"
        ).value
      );


    const price18 =
      Number(
        document.getElementById(
          "price18"
        ).value
      );


    let mazhane =
      Number(
        document.getElementById(
          "mazhane"
        ).value
      );


    if (
      !weight ||
      weight <= 0
    ) {

      alert(
        "وزن معامله را وارد کن."
      );

      return;

    }


    if (
      !price18 ||
      price18 <= 0
    ) {

      alert(
        "فی گرم ۱۸ را وارد کن."
      );

      return;

    }


    if (
      !mazhane ||
      mazhane <= 0
    ) {

      mazhane =
        price18 * FACTOR;

    }


    const now =
      new Date();


    trades.push({

      id:
        Date.now(),

      type,

      weight,

      price18,

      mazhane,

      dateKey:
        getDateKey(now),

      dateText:
        getPersianDate(now),

      time:
        getTime(now)

    });


    saveTrades();


    document.getElementById(
      "weight"
    ).value = "";

    document.getElementById(
      "price18"
    ).value = "";

    document.getElementById(
      "mazhane"
    ).value = "";


    document.getElementById(
      "livePrice"
    ).textContent =
      "0 تومان";


    document.getElementById(
      "liveMazhane"
    ).textContent =
      "0 تومان";


    refreshAll();

  }
);


/* =====================================================
   PRICE → MAZHANE
===================================================== */

document.getElementById(
  "price18"
).addEventListener(
  "input",
  function() {

    const price =
      Number(this.value);


    if (!price) {

      document.getElementById(
        "livePrice"
      ).textContent =
        "0 تومان";


      document.getElementById(
        "liveMazhane"
      ).textContent =
        "0 تومان";


      return;

    }


    const mazhane =
      price * FACTOR;


    document.getElementById(
      "mazhane"
    ).value =
      Math.round(mazhane);


    document.getElementById(
      "livePrice"
    ).textContent =
      formatMoney(price)
      + " تومان";


    document.getElementById(
      "liveMazhane"
    ).textContent =
      formatMoney(mazhane)
      + " تومان";

  }
);


/* =====================================================
   MAZHANE → PRICE
===================================================== */

document.getElementById(
  "mazhane"
).addEventListener(
  "input",
  function() {

    const mazhane =
      Number(this.value);


    if (!mazhane) return;


    const price =
      mazhane / FACTOR;


    document.getElementById(
      "price18"
    ).value =
      Math.round(price);


    document.getElementById(
      "livePrice"
    ).textContent =
      formatMoney(price)
      + " تومان";


    document.getElementById(
      "liveMazhane"
    ).textContent =
      formatMoney(mazhane)
      + " تومان";

  }
);


/* =====================================================
   REPORT
===================================================== */

function renderReport() {

  let bought = 0;

  let sold = 0;


  trades.forEach(
    function(trade) {

      if (
        trade.type === "buy"
      ) {

        bought +=
          Number(trade.weight);

      }

      else {

        sold +=
          Number(trade.weight);

      }

    }
  );


  const ledger =
    calculateLedger();


  document.getElementById(
    "totalBought"
  ).textContent =
    formatNumber(bought)
    + " گرم";


  document.getElementById(
    "totalSold"
  ).textContent =
    formatNumber(sold)
    + " گرم";


  /*
    اگر Short داشته باشیم،
    موجودی واقعی Long صفر است.
  */

  document.getElementById(
    "totalWeight"
  ).textContent =
    formatNumber(
      Math.max(ledger.position, 0)
    )
    + " گرم";


  document.getElementById(
    "tradeCount"
  ).textContent =
    formatNumber(
      trades.length
    );


  /* =================================================
     نمایش میانگین موقعیت فعلی
  ================================================= */

  const reportAverage =
    document.getElementById(
      "reportAveragePrice"
    );


  if (ledger.position > 0) {

    /*
      موجودی خرید داریم
    */

    reportAverage.textContent =
      "فی میانگین موجودی: " +
      formatMoney(
        ledger.averageCost
      ) +
      " تومان";

  }

  else if (ledger.position < 0) {

    /*
      فروش باز داریم
    */

    reportAverage.textContent =
      "فی میانگین فروش باز: " +
      formatMoney(
        ledger.averageCost
      ) +
      " تومان";

  }

  else {

    reportAverage.textContent =
      "0 تومان";

  }


  const pnl =
    document.getElementById(
      "realizedProfit"
    );


  pnl.textContent =
    (
      ledger.realizedProfit >= 0
        ? "+"
        : ""
    )
    +
    formatMoney(
      ledger.realizedProfit
    )
    +
    " تومان";


  if (
    ledger.realizedProfit > 0
  ) {

    pnl.className =
      "closed-profit";

  }

  else if (
    ledger.realizedProfit < 0
  ) {

    pnl.className =
      "closed-loss";

  }

  else {

    pnl.className = "";

  }


  renderClosedTrades(
    ledger.closedTrades
  );

}


/* =====================================================
   CLOSED TRADES
===================================================== */

function renderClosedTrades(list) {

  const container =
    document.getElementById(
      "closedTrades"
    );


  container.innerHTML = "";


  if (!list.length) {

    container.innerHTML = `
      <div class="empty">
        هنوز معامله بسته‌شده‌ای وجود ندارد.
      </div>
    `;

    return;

  }


  [...list]
    .reverse()
    .forEach(
      function(item) {

        const div =
          document.createElement(
            "div"
          );


        div.className =
          "closed-item";


        const positive =
          item.profit >= 0;


        div.innerHTML = `

          <div class="closed-top">

            <div class="closed-title">

              ${
                item.type === "long"
                  ? "بستن خرید"
                  : "بستن فروش"
              }

              ·

              ${formatNumber(
                item.weight
              )}

              گرم

            </div>


            <strong
              class="${
                positive
                  ? "closed-profit"
                  : "closed-loss"
              }">

              ${positive ? "+" : ""}

              ${formatMoney(
                item.profit
              )}

              تومان

            </strong>

          </div>


          <div class="closed-details">

            <span>
              قیمت مبنا:
              ${formatMoney(
                item.openPrice
              )}
              تومان
            </span>


            <span>
              قیمت بسته‌شدن:
              ${formatMoney(
                item.closePrice
              )}
              تومان
            </span>

          </div>


          <div class="closed-date">

            ${item.dateText}
            ·
            ${item.time}

          </div>

        `;


        container.appendChild(
          div
        );

      }
    );

}


/* =====================================================
   SETTINGS
===================================================== */

document.getElementById(
  "saveFactor"
).addEventListener(
  "click",
  function() {

    const value =
      Number(
        document.getElementById(
          "factorInput"
        ).value
      );


    if (
      !value ||
      value <= 0
    ) {

      alert(
        "ضریب نامعتبر است."
      );

      return;

    }


    FACTOR =
      value;


    localStorage.setItem(
      "shayan_gold_factor",
      FACTOR
    );


    alert(
      "ضریب با موفقیت ذخیره شد."
    );

  }
);


document.getElementById(
  "factorInput"
).value =
  FACTOR;


/* =====================================================
   NAVIGATION
===================================================== */

document.querySelectorAll(
  ".nav-btn"
).forEach(
  function(button) {

    button.addEventListener(
      "click",
      function() {

        const pageId =
          this.dataset.page;


        document.querySelectorAll(
          ".page"
        ).forEach(
          function(page) {

            page.classList.remove(
              "active"
            );

          }
        );


        document.getElementById(
          pageId
        ).classList.add(
          "active"
        );


        document.querySelectorAll(
          ".nav-btn"
        ).forEach(
          function(btn) {

            btn.classList.remove(
              "active"
            );

          }
        );


        this.classList.add(
          "active"
        );


        refreshAll();

      }
    );

  }
);


/* =====================================================
   REFRESH ALL
===================================================== */

function refreshAll() {

  renderHome();

  renderTradesPage();

  renderHistory();

  renderReport();

}


/* =====================================================
   START APP
===================================================== */

refreshAll();

