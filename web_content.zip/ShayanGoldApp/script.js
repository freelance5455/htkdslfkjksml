const DEFAULT_FACTOR = 4.3318;

let FACTOR =
  Number(
    localStorage.getItem("shayan_gold_factor")
  ) || DEFAULT_FACTOR;


let trades = [];

try {

  const savedTrades =
    localStorage.getItem("shayan_gold_trades");

  trades =
    savedTrades
      ? JSON.parse(savedTrades)
      : [];

  if (!Array.isArray(trades)) {
    trades = [];
  }

} catch (error) {

  trades = [];

}


let editingTradeId = null;


/* ================= DATE ================= */

function getPersianDate(date = new Date()) {

  return new Intl.DateTimeFormat(
    "fa-IR-u-ca-persian",
    {
      year: "numeric",
      month: "long",
      day: "numeric"
    }
  ).format(date);

}


function getDateKey(date = new Date()) {

  const y =
    date.getFullYear();

  const m =
    String(
      date.getMonth() + 1
    ).padStart(2, "0");

  const d =
    String(
      date.getDate()
    ).padStart(2, "0");

  return `${y}-${m}-${d}`;

}


function getTime(date = new Date()) {

  return date.toLocaleTimeString(
    "fa-IR",
    {
      hour: "2-digit",
      minute: "2-digit"
    }
  );

}


/* ================= NUMBERS ================= */

function normalizeNumber(value) {

  if (
    value === null ||
    value === undefined ||
    value === ""
  ) {
    return 0;
  }


  let text =
    String(value)
      .replace(/,/g, "")
      .replace(/\s/g, "");


  text =
    text.replace(
      /[۰-۹]/g,
      d =>
        "۰۱۲۳۴۵۶۷۸۹".indexOf(d)
    );


  text =
    text.replace(
      /[٠-٩]/g,
      d =>
        "٠١٢٣٤٥٦٧٨٩".indexOf(d)
    );


  return Number(text) || 0;

}


function formatNumber(number) {

  return Number(number || 0)
    .toLocaleString(
      "en-US",
      {
        maximumFractionDigits: 3
      }
    );

}


function formatMoney(number) {

  return Number(number || 0)
    .toLocaleString(
      "en-US",
      {
        maximumFractionDigits: 0
      }
    );

}


function formatInputNumber(value) {

  const number =
    normalizeNumber(value);

  if (!number) {
    return "";
  }

  return number.toLocaleString(
    "en-US",
    {
      maximumFractionDigits: 3
    }
  );

}


/* ================= STORAGE ================= */

function saveTrades() {

  localStorage.setItem(
    "shayan_gold_trades",
    JSON.stringify(trades)
  );

}


/* ================= LEDGER ================= */

function calculateLedger() {

  let position = 0;

  let averageCost = 0;

  let realizedProfit = 0;


  const sortedTrades =
    [...trades].sort(
      (a, b) =>
        new Date(a.createdAt).getTime() -
        new Date(b.createdAt).getTime()
    );


  for (const trade of sortedTrades) {

    const qty =
      Number(trade.weight) || 0;

    const price =
      Number(trade.price18) || 0;


    if (
      qty <= 0 ||
      price <= 0
    ) {
      continue;
    }


    /* ===== BUY ===== */

    if (trade.type === "buy") {

      if (position < 0) {

        const shortQty =
          Math.abs(position);

        const closeQty =
          Math.min(
            qty,
            shortQty
          );


        realizedProfit +=
          closeQty *
          (averageCost - price);


        position += closeQty;


        if (qty > closeQty) {

          const remaining =
            qty - closeQty;

          position = remaining;

          averageCost = price;

        } else if (position === 0) {

          averageCost = 0;

        }

      }

      else if (position > 0) {

        const oldQty =
          position;

        const newQty =
          oldQty + qty;


        averageCost =
          (
            oldQty * averageCost +
            qty * price
          ) / newQty;


        position =
          newQty;

      }

      else {

        position = qty;

        averageCost = price;

      }

    }


    /* ===== SELL ===== */

    else if (trade.type === "sell") {

      if (position > 0) {

        const closeQty =
          Math.min(
            position,
            qty
          );


        realizedProfit +=
          closeQty *
          (price - averageCost);


        position -= closeQty;


        if (qty > closeQty) {

          const remaining =
            qty - closeQty;

          position =
            -remaining;

          averageCost =
            price;

        }

        else if (position === 0) {

          averageCost = 0;

        }

      }

      else if (position < 0) {

        const oldShortQty =
          Math.abs(position);

        const newShortQty =
          oldShortQty + qty;


        averageCost =
          (
            oldShortQty * averageCost +
            qty * price
          ) / newShortQty;


        position =
          -newShortQty;

      }

      else {

        position =
          -qty;

        averageCost =
          price;

      }

    }

  }


  return {
    position,
    averageCost,
    realizedProfit
  };

}


/* ================= TRADE HTML ================= */

function createTradeHTML(trade) {

  return `

    <div class="trade-item">

      <div class="trade-main">

        <span>
          ${trade.type === "buy"
            ? "خرید"
            : "فروش"}
        </span>

        <span class="trade-type ${trade.type}">

          ${trade.type === "buy"
            ? "خرید"
            : "فروش"}

        </span>

      </div>


      <div class="trade-details">

        <span>
          وزن:
          ${formatNumber(trade.weight)}
          گرم
        </span>

        <span>
          فی:
          ${formatMoney(trade.price18)}
          تومان
        </span>

        <span>
          مظنه:
          ${formatMoney(trade.mazhane)}
          تومان
        </span>

        <span>
          کل:
          ${formatMoney(trade.totalPrice)}
          تومان
        </span>

        <span>
          ${trade.time}
        </span>

      </div>

    </div>

  `;

}


/* ================= HOME ================= */

function renderHome() {

  const today =
    getDateKey();


  const todayTrades =
    trades.filter(
      trade =>
        trade.date === today
    );


  let bought = 0;

  let sold = 0;


  todayTrades.forEach(
    trade => {

      if (trade.type === "buy") {

        bought +=
          Number(trade.weight) || 0;

      } else {

        sold +=
          Number(trade.weight) || 0;

      }

    }
  );


  const ledger =
    calculateLedger();


  const balance =
    Math.abs(ledger.position);


  const average =
    ledger.averageCost;


  const averageMazhane =
    average * FACTOR;


  document.getElementById(
    "todayDate"
  ).textContent =
    getPersianDate();


  document.getElementById(
    "homeTradeCount"
  ).textContent =
    formatNumber(todayTrades.length);


  document.getElementById(
    "homeBought"
  ).textContent =
    `${formatNumber(bought)} گرم`;


  document.getElementById(
    "homeSold"
  ).textContent =
    `${formatNumber(sold)} گرم`;


  document.getElementById(
    "homeBalance"
  ).textContent =
    `${formatNumber(balance)} گرم`;


  const averageLabel =
    document.getElementById(
      "homeAverageLabel"
    );


  if (ledger.position < 0) {

    averageLabel.textContent =
      "فی میانگین فروش باز";

  } else {

    averageLabel.textContent =
      "فی میانگین موجودی باقی‌مانده";

  }


  document.getElementById(
    "homeAveragePrice"
  ).textContent =
    `${formatMoney(average)} تومان`;


  document.getElementById(
    "homeAverageMazhane"
  ).textContent =
    `مظنه میانگین: ${formatMoney(averageMazhane)} تومان`;


  const profitElement =
    document.getElementById(
      "homeRealizedProfit"
    );


  profitElement.textContent =
    `${formatMoney(
      ledger.realizedProfit
    )} تومان`;


  profitElement.classList.remove(
    "closed-profit",
    "closed-loss"
  );


  if (ledger.realizedProfit > 0) {

    profitElement.classList.add(
      "closed-profit"
    );

  }

  else if (
    ledger.realizedProfit < 0
  ) {

    profitElement.classList.add(
      "closed-loss"
    );

  }


  renderTradeList(
    todayTrades,
    "homeTrades"
  );

}


/* ================= TODAY TRADES ================= */

function renderTodayTrades() {

  const today =
    getDateKey();


  const todayTrades =
    trades.filter(
      trade =>
        trade.date === today
    );


  renderTradeList(
    todayTrades,
    "todayTrades"
  );

}


/* ================= GENERIC LIST ================= */

function renderTradeList(
  list,
  elementId
) {

  const container =
    document.getElementById(
      elementId
    );


  if (!container) {
    return;
  }


  if (list.length === 0) {

    container.innerHTML =
      `<div class="empty">
        معامله‌ای ثبت نشده است.
      </div>`;

    return;

  }


  const sorted =
    [...list].sort(
      (a, b) =>
        new Date(b.createdAt).getTime() -
        new Date(a.createdAt).getTime()
    );


  container.innerHTML =
    sorted
      .map(
        trade =>
          createTradeHTML(trade)
      )
      .join("");

}


/* ================= HISTORY ================= */

function renderHistory() {

  const container =
    document.getElementById(
      "historyList"
    );


  if (!container) {
    return;
  }


  if (trades.length === 0) {

    container.innerHTML =
      `<div class="empty">
        هنوز معامله‌ای ثبت نشده است.
      </div>`;

    return;

  }


  const groups = {};


  trades.forEach(
    trade => {

      if (!groups[trade.date]) {
        groups[trade.date] = [];
      }

      groups[trade.date].push(
        trade
      );

    }
  );


  const dates =
    Object.keys(groups).sort(
      (a, b) =>
        b.localeCompare(a)
    );


  container.innerHTML =
    dates
      .map(date => {

        const list =
          [...groups[date]].sort(
            (a, b) =>
              new Date(
                b.createdAt
              ).getTime() -
              new Date(
                a.createdAt
              ).getTime()
          );


        const dateObject =
          new Date(
            list[0].createdAt
          );


        const persianDate =
          getPersianDate(
            dateObject
          );


        return `

          <div class="history-folder">

            <button
              class="folder-header"
              onclick="toggleFolder(this)"
            >

              <div class="folder-title">

                <span class="folder-icon">
                  📁
                </span>

                <span>
                  ${persianDate}
                </span>

              </div>


              <span class="folder-count">
                ${list.length} معامله
              </span>

            </button>


            <div class="folder-content">

              ${list
                .map(
                  trade =>
                    createHistoryTradeHTML(
                      trade
                    )
                )
                .join("")}

            </div>

          </div>

        `;

      })
      .join("");

}


function createHistoryTradeHTML(
  trade
) {

  return `

    <div class="history-trade">

      <div class="history-trade-top">

        <span class="trade-type ${trade.type}">
          ${trade.type === "buy"
            ? "خرید"
            : "فروش"}
        </span>


        <div class="history-actions">

          <button
            class="small-action"
            onclick="editTrade(${trade.id})"
            title="ویرایش"
          >
            ✎
          </button>


          <button
            class="small-action"
            onclick="deleteTrade(${trade.id})"
            title="حذف"
          >
            🗑
          </button>

        </div>

      </div>


      <div class="history-trade-info">

        <div>
          <span>وزن</span>
          <strong>
            ${formatNumber(trade.weight)}
            گرم
          </strong>
        </div>


        <div>
          <span>فی گرم ۱۸</span>
          <strong>
            ${formatMoney(trade.price18)}
          </strong>
        </div>


        <div>
          <span>مظنه</span>
          <strong>
            ${formatMoney(trade.mazhane)}
          </strong>
        </div>


        <div>
          <span>قیمت کل</span>
          <strong>
            ${formatMoney(trade.totalPrice)}
          </strong>
        </div>

      </div>


      <div class="history-time">

        ساعت معامله:
        ${trade.time}

      </div>

    </div>

  `;

}


function toggleFolder(button) {

  const folder =
    button.closest(
      ".history-folder"
    );


  if (folder) {

    folder.classList.toggle(
      "open"
    );

  }

}


/* ================= DEMO ================= */

function calculateDemo() {

  const current =
    calculateLedger();


  const currentPosition =
    current.position;


  const currentWeight =
    Math.abs(
      currentPosition
    );


  const currentAverage =
    current.averageCost;


  const currentStatus =
    document.getElementById(
      "demoCurrentStatus"
    );


  const currentWeightElement =
    document.getElementById(
      "demoCurrentWeight"
    );


  const currentAverageElement =
    document.getElementById(
      "demoCurrentAverage"
    );


  if (currentPosition > 0) {

    currentStatus.textContent =
      "موجودی خرید";

  }

  else if (currentPosition < 0) {

    currentStatus.textContent =
      "فروش باز";

  }

  else {

    currentStatus.textContent =
      "بدون موجودی";

  }


  currentWeightElement.textContent =
    `${formatNumber(
      currentWeight
    )} گرم`;


  currentAverageElement.textContent =
    `${formatMoney(
      currentAverage
    )} تومان`;


  const demoWeight =
    normalizeNumber(
      document.getElementById(
        "demoWeight"
      ).value
    );


  const demoPrice =
    normalizeNumber(
      document.getElementById(
        "demoPrice18"
      ).value
    );


  const demoType =
    document.getElementById(
      "demoType"
    ).value;


  const resultAverage =
    document.getElementById(
      "demoResultAverage"
    );


  const resultMazhane =
    document.getElementById(
      "demoResultMazhane"
    );


  const resultMessage =
    document.getElementById(
      "demoResultMessage"
    );


  if (
    demoWeight <= 0 ||
    demoPrice <= 0
  ) {

    resultAverage.textContent =
      "0 تومان";

    resultMazhane.textContent =
      "مظنه میانگین: 0 تومان";

    resultMessage.textContent =
      "وزن و فی معامله فرضی را وارد کنید.";

    resultMessage.className =
      "demo-result-message";

    return;

  }


  let simulatedPosition =
    currentPosition;


  let simulatedAverage =
    currentAverage;


  let simulatedRealized =
    0;


  /* ================= BUY DEMO ================= */

  if (demoType === "buy") {

    if (simulatedPosition < 0) {

      const shortQty =
        Math.abs(
          simulatedPosition
        );


      const closeQty =
        Math.min(
          demoWeight,
          shortQty
        );


      simulatedRealized =
        closeQty *
        (
          simulatedAverage -
          demoPrice
        );


      simulatedPosition +=
        closeQty;


      if (
        demoWeight >
        closeQty
      ) {

        const remaining =
          demoWeight -
          closeQty;


        simulatedPosition =
          remaining;


        simulatedAverage =
          demoPrice;

      }

      else if (
        simulatedPosition === 0
      ) {

        simulatedAverage = 0;

      }

    }

    else if (
      simulatedPosition > 0
    ) {

      const oldQty =
        simulatedPosition;


      const newQty =
        oldQty +
        demoWeight;


      simulatedAverage =
        (
          oldQty *
          simulatedAverage +
          demoWeight *
          demoPrice
        ) /
        newQty;


      simulatedPosition =
        newQty;

    }

    else {

      simulatedPosition =
        demoWeight;

      simulatedAverage =
        demoPrice;

    }

  }


  /* ================= SELL DEMO ================= */

  else {

    if (simulatedPosition > 0) {

      const closeQty =
        Math.min(
          simulatedPosition,
          demoWeight
        );


      simulatedRealized =
        closeQty *
        (
          demoPrice -
          simulatedAverage
        );


      simulatedPosition -=
        closeQty;


      if (
        demoWeight >
        closeQty
      ) {

        const remaining =
          demoWeight -
          closeQty;


        simulatedPosition =
          -remaining;


        simulatedAverage =
          demoPrice;

      }

      else if (
        simulatedPosition === 0
      ) {

        simulatedAverage = 0;

      }

    }

    else if (
      simulatedPosition < 0
    ) {

      const oldShortQty =
        Math.abs(
          simulatedPosition
        );


      const newShortQty =
        oldShortQty +
        demoWeight;


      simulatedAverage =
        (
          oldShortQty *
          simulatedAverage +
          demoWeight *
          demoPrice
        ) /
        newShortQty;


      simulatedPosition =
        -newShortQty;

    }

    else {

      simulatedPosition =
        -demoWeight;

      simulatedAverage =
        demoPrice;

    }

  }


  const simulatedMazhane =
    simulatedAverage *
    FACTOR;


  resultAverage.textContent =
    `${formatMoney(
      simulatedAverage
    )} تومان`;


  resultMazhane.textContent =
    `مظنه میانگین: ${formatMoney(
      simulatedMazhane
    )} تومان`;


  let statusText = "";


  if (
    simulatedPosition > 0
  ) {

    statusText =
      `بعد از این خرید، موجودی شما ${formatNumber(
        Math.abs(simulatedPosition)
      )} گرم با میانگین ${formatMoney(
        simulatedAverage
      )} تومان می‌شود.`;

  }

  else if (
    simulatedPosition < 0
  ) {

    statusText =
      `بعد از این فروش، فروش باز شما ${formatNumber(
        Math.abs(simulatedPosition)
      )} گرم با میانگین ${formatMoney(
        simulatedAverage
      )} تومان می‌شود.`;

  }

  else {

    statusText =
      "با این معامله موجودی باز شما صفر می‌شود.";

  }


  if (
    simulatedRealized !== 0
  ) {

    statusText +=
      ` سود/زیان این سناریو: ${formatMoney(
        simulatedRealized
      )} تومان.`;

  }


  resultMessage.textContent =
    statusText;


  resultMessage.className =
    "demo-result-message success";

}


/* ================= DEMO INPUTS ================= */

const demoWeightInput =
  document.getElementById(
    "demoWeight"
  );


const demoPriceInput =
  document.getElementById(
    "demoPrice18"
  );


const demoTypeInput =
  document.getElementById(
    "demoType"
  );


if (demoWeightInput) {

  demoWeightInput.addEventListener(
    "input",
    function () {

      this.value =
        this.value.replace(
          /[^0-9۰-۹٠-٩.,]/g,
          ""
        );

      calculateDemo();

    }
  );

}


if (demoPriceInput) {

  demoPriceInput.addEventListener(
    "input",
    function () {

      this.value =
        formatInputNumber(
          this.value
        );

      calculateDemo();

    }
  );

}


if (demoTypeInput) {

  demoTypeInput.addEventListener(
    "change",
    calculateDemo
  );

}


/* ================= TRADE INPUTS ================= */

const weightInput =
  document.getElementById(
    "weight"
  );


const price18Input =
  document.getElementById(
    "price18"
  );


const mazhaneInput =
  document.getElementById(
    "mazhane"
  );


const totalPriceInput =
  document.getElementById(
    "totalPrice"
  );


function updateFromPrice18() {

  const price =
    normalizeNumber(
      price18Input.value
    );


  const weight =
    normalizeNumber(
      weightInput.value
    );


  if (price > 0) {

    mazhaneInput.value =
      formatInputNumber(
        price * FACTOR
      );

  }


  if (
    price > 0 &&
    weight > 0
  ) {

    totalPriceInput.value =
      formatInputNumber(
        price * weight
      );

  }

}


function updateFromMazhane() {

  const mazhane =
    normalizeNumber(
      mazhaneInput.value
    );


  const weight =
    normalizeNumber(
      weightInput.value
    );


  if (mazhane > 0) {

    const price =
      mazhane / FACTOR;


    price18Input.value =
      formatInputNumber(
        price
      );


    if (weight > 0) {

      totalPriceInput.value =
        formatInputNumber(
          price * weight
        );

    }

  }

}


function updateFromTotal() {

  const total =
    normalizeNumber(
      totalPriceInput.value
    );


  const weight =
    normalizeNumber(
      weightInput.value
    );


  if (
    total > 0 &&
    weight > 0
  ) {

    const price =
      total / weight;


    price18Input.value =
      formatInputNumber(
        price
      );


    mazhaneInput.value =
      formatInputNumber(
        price * FACTOR
      );

  }

}


weightInput.addEventListener(
  "input",
  function () {

    this.value =
      this.value.replace(
        /[^0-9۰-۹٠-٩.,]/g,
        ""
      );


    const weight =
      normalizeNumber(
        this.value
      );


    const price =
      normalizeNumber(
        price18Input.value
      );


    if (
      weight > 0 &&
      price > 0
    ) {

      totalPriceInput.value =
        formatInputNumber(
          weight * price
        );

    }

  }
);


price18Input.addEventListener(
  "input",
  function () {

    this.value =
      formatInputNumber(
        this.value
      );

    updateFromPrice18();

  }
);


mazhaneInput.addEventListener(
  "input",
  function () {

    this.value =
      formatInputNumber(
        this.value
      );

    updateFromMazhane();

  }
);


totalPriceInput.addEventListener(
  "input",
  function () {

    this.value =
      formatInputNumber(
        this.value
      );

    updateFromTotal();

  }
);


/* ================= SAVE TRADE ================= */

document
  .getElementById("saveTrade")
  .addEventListener(
    "click",
    function () {

      const type =
        document.getElementById(
          "tradeType"
        ).value;


      const weight =
        normalizeNumber(
          weightInput.value
        );


      const price18 =
        normalizeNumber(
          price18Input.value
        );


      const mazhane =
        normalizeNumber(
          mazhaneInput.value
        );


      const totalPrice =
        normalizeNumber(
          totalPriceInput.value
        );


      if (weight <= 0) {

        alert(
          "وزن معامله را وارد کنید."
        );

        return;

      }


      if (price18 <= 0) {

        alert(
          "فی گرم ۱۸ را وارد کنید."
        );

        return;

      }


      if (totalPrice <= 0) {

        alert(
          "قیمت کل معامله را وارد کنید."
        );

        return;

      }


      const finalMazhane =
        mazhane > 0
          ? mazhane
          : price18 * FACTOR;


      const now =
        new Date();


      const trade = {

        id:
          Date.now() +
          Math.floor(
            Math.random() * 1000
          ),

        type,

        weight,

        price18,

        mazhane:
          finalMazhane,

        totalPrice,

        date:
          getDateKey(now),

        time:
          getTime(now),

        createdAt:
          now.toISOString()

      };


      trades.push(
        trade
      );


      saveTrades();


      weightInput.value = "";

      price18Input.value = "";

      mazhaneInput.value = "";

      totalPriceInput.value = "";


      renderAll();

      renderTodayTrades();

      renderHistory();

      showPage("trades");

    }
  );


/* ================= EDIT ================= */

function editTrade(id) {

  const trade =
    trades.find(
      item =>
        Number(item.id) ===
        Number(id)
    );


  if (!trade) {
    return;
  }


  editingTradeId =
    id;


  document.getElementById(
    "editType"
  ).value =
    trade.type;


  document.getElementById(
    "editWeight"
  ).value =
    formatInputNumber(
      trade.weight
    );


  document.getElementById(
    "editPrice18"
  ).value =
    formatInputNumber(
      trade.price18
    );


  document.getElementById(
    "editMazhane"
  ).value =
    formatInputNumber(
      trade.mazhane
    );


  document.getElementById(
    "editTotalPrice"
  ).value =
    formatInputNumber(
      trade.totalPrice
    );


  document.getElementById(
    "editModal"
  ).classList.add(
    "show"
  );

}


document
  .getElementById("closeModal")
  .addEventListener(
    "click",
    function () {

      document.getElementById(
        "editModal"
      ).classList.remove(
        "show"
      );

    }
  );


document
  .getElementById("updateTrade")
  .addEventListener(
    "click",
    function () {

      const trade =
        trades.find(
          item =>
            Number(item.id) ===
            Number(editingTradeId)
        );


      if (!trade) {
        return;
      }


      const weight =
        normalizeNumber(
          document.getElementById(
            "editWeight"
          ).value
        );


      const price18 =
        normalizeNumber(
          document.getElementById(
            "editPrice18"
          ).value
        );


      const mazhane =
        normalizeNumber(
          document.getElementById(
            "editMazhane"
          ).value
        );


      const totalPrice =
        normalizeNumber(
          document.getElementById(
            "editTotalPrice"
          ).value
        );


      if (
        weight <= 0 ||
        price18 <= 0 ||
        totalPrice <= 0
      ) {

        alert(
          "اطلاعات معامله کامل نیست."
        );

        return;

      }


      trade.type =
        document.getElementById(
          "editType"
        ).value;


      trade.weight =
        weight;


      trade.price18 =
        price18;


      trade.mazhane =
        mazhane > 0
          ? mazhane
          : price18 * FACTOR;


      trade.totalPrice =
        totalPrice;


      saveTrades();


      document.getElementById(
        "editModal"
      ).classList.remove(
        "show"
      );


      renderAll();

      renderTodayTrades();

      renderHistory();

    }
  );


/* ================= DELETE ================= */

function deleteTrade(id) {

  const ok =
    confirm(
      "آیا از حذف این معامله مطمئن هستید؟"
    );


  if (!ok) {
    return;
  }


  trades =
    trades.filter(
      trade =>
        Number(trade.id) !==
        Number(id)
    );


  saveTrades();


  renderAll();

  renderTodayTrades();

  renderHistory();

}


/* ================= SETTINGS ================= */

const factorInput =
  document.getElementById(
    "factorInput"
  );


factorInput.value =
  FACTOR;


document
  .getElementById("saveFactor")
  .addEventListener(
    "click",
    function () {

      const value =
        Number(
          factorInput.value
        );


      if (
        !value ||
        value <= 0
      ) {

        alert(
          "ضریب واردشده معتبر نیست."
        );

        return;

      }


      FACTOR =
        value;


      localStorage.setItem(
        "shayan_gold_factor",
        String(FACTOR)
      );


      renderAll();

      calculateDemo();


      alert(
        "ضریب با موفقیت ذخیره شد."
      );

    }
  );


/* ================= NAVIGATION ================= */

function showPage(pageId) {

  document
    .querySelectorAll(".page")
    .forEach(
      page =>
        page.classList.remove(
          "active"
        )
    );


  document
    .querySelectorAll(".nav-btn")
    .forEach(
      button =>
        button.classList.remove(
          "active"
        )
    );


  const page =
    document.getElementById(
      pageId
    );


  const navButton =
    document.querySelector(
      `.nav-btn[data-page="${pageId}"]`
    );


  if (page) {

    page.classList.add(
      "active"
    );

  }


  if (navButton) {

    navButton.classList.add(
      "active"
    );

  }


  if (pageId === "trades") {

    renderTodayTrades();

  }


  if (pageId === "history") {

    renderHistory();

  }


  if (pageId === "demo") {

    calculateDemo();

  }

}


document
  .querySelectorAll(".nav-btn")
  .forEach(
    button => {

      button.addEventListener(
        "click",
        function () {

          showPage(
            this.dataset.page
          );

        }
      );

    }
  );


/* ================= RENDER ALL ================= */

function renderAll() {

  renderHome();

  renderTodayTrades();

  renderHistory();

  calculateDemo();

}


renderAll();

showPage("home");