const DEFAULT_FACTOR = 4.3318;

let FACTOR =
  Number(localStorage.getItem("shayan_gold_factor")) ||
  DEFAULT_FACTOR;

let trades = JSON.parse(
  localStorage.getItem("shayan_gold_trades") || "[]"
);

let editingTradeId = null;


/* =========================
   DATE & TIME
========================= */

function getPersianDate(date = new Date()) {
  return new Intl.DateTimeFormat("fa-IR-u-ca-persian", {
    year: "numeric",
    month: "long",
    day: "numeric"
  }).format(date);
}

function getDateKey(date = new Date()) {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, "0");
  const d = String(date.getDate()).padStart(2, "0");

  return `${y}-${m}-${d}`;
}

function getTime(date = new Date()) {
  return date.toLocaleTimeString("fa-IR", {
    hour: "2-digit",
    minute: "2-digit"
  });
}


/* =========================
   FORMAT
========================= */

function formatNumber(number) {
  return Number(number || 0).toLocaleString("en-US", {
    maximumFractionDigits: 3
  });
}

function formatMoney(number) {
  return Number(number || 0).toLocaleString("en-US", {
    maximumFractionDigits: 0
  });
}


/* =========================
   STORAGE
========================= */

function saveTrades() {
  localStorage.setItem(
    "shayan_gold_trades",
    JSON.stringify(trades)
  );
}


/* =========================
   LEDGER
   Weighted Average Accounting
========================= */

function calculateLedger() {

  let position = 0;

  /*
    position > 0  = موجودی خرید / Long
    position < 0  = فروش باز / Short
  */

  let averageCost = 0;

  let realizedProfit = 0;

  const closedTrades = [];


  const sortedTrades = [...trades].sort(
    (a, b) => new Date(a.timestamp) - new Date(b.timestamp)
  );


  for (const trade of sortedTrades) {

    const qty = Number(trade.weight) || 0;
    const price = Number(trade.price18) || 0;


    /* =========================
       BUY
    ========================= */

    if (trade.type === "buy") {

      /*
        حالت اول:
        هیچ پوزیشن بازی نداریم
      */

      if (position === 0) {

        position = qty;
        averageCost = price;

        continue;
      }


      /*
        اگر فروش باز داشته باشیم
        خرید ابتدا فروش باز را می‌بندد
      */

      if (position < 0) {

        const shortQty = Math.abs(position);

        const closeQty = Math.min(qty, shortQty);


        // سود فروش باز
        const pnl =
          closeQty * (averageCost - price);

        realizedProfit += pnl;


        closedTrades.push({
          type: "short",
          weight: closeQty,
          openPrice: averageCost,
          closePrice: price,
          profit: pnl,
          timestamp: trade.timestamp
        });


        position += closeQty;


        /*
          اگر خرید بیشتر از مقدار فروش باز باشد،
          مقدار اضافه تبدیل به موجودی خرید می‌شود.
        */

        if (qty > shortQty) {

          const remainingBuy =
            qty - shortQty;

          position = remainingBuy;

          averageCost = price;
        }


        /*
          اگر فروش باز کامل بسته نشده باشد،
          میانگین فروش باز قبلی حفظ می‌شود.
        */

        continue;
      }


      /*
        اگر موجودی خرید داشته باشیم،
        خرید جدید با میانگین وزنی ترکیب می‌شود.
      */

      if (position > 0) {

        const oldQty = position;

        const newQty = oldQty + qty;


        averageCost =
          (
            (oldQty * averageCost) +
            (qty * price)
          ) / newQty;


        position = newQty;

        continue;
      }
    }


    /* =========================
       SELL
    ========================= */

    if (trade.type === "sell") {

      /*
        اگر موجودی خرید داشته باشیم،
        ابتدا موجودی را می‌فروشیم.
      */

      if (position > 0) {

        const closeQty =
          Math.min(qty, position);


        /*
          سود فروش موجودی
        */

        const pnl =
          closeQty * (price - averageCost);

        realizedProfit += pnl;


        closedTrades.push({
          type: "long",
          weight: closeQty,
          openPrice: averageCost,
          closePrice: price,
          profit: pnl,
          timestamp: trade.timestamp
        });


        position -= closeQty;


        /*
          اگر فروش بیشتر از موجودی باشد،
          مقدار اضافه تبدیل به فروش باز می‌شود.
        */

        if (qty > closeQty) {

          const remainingSell =
            qty - closeQty;

          position = -remainingSell;

          averageCost = price;
        }


        /*
          اگر هنوز موجودی باقی مانده باشد،
          میانگین همان میانگین قبلی است.
        */

        continue;
      }


      /*
        اگر هیچ پوزیشن بازی نداشته باشیم،
        فروش تبدیل به فروش باز می‌شود.
      */

      if (position === 0) {

        position = -qty;

        averageCost = price;

        continue;
      }


      /*
        اگر از قبل فروش باز داشته باشیم،
        فروش جدید با میانگین وزنی فروش باز ترکیب می‌شود.
      */

      if (position < 0) {

        const oldShortQty =
          Math.abs(position);

        const newShortQty =
          oldShortQty + qty;


        /*
          میانگین وزنی فروش باز
        */

        averageCost =
          (
            (oldShortQty * averageCost) +
            (qty * price)
          ) / newShortQty;


        position = -newShortQty;

        continue;
      }
    }
  }


  return {
    position,
    averageCost,
    realizedProfit,
    closedTrades
  };
}


/* =========================
   HOME
========================= */

function renderHome() {

  const todayKey = getDateKey();

  const todayTrades = trades.filter(
    trade => trade.dateKey === todayKey
  );


  let bought = 0;
  let sold = 0;


  todayTrades.forEach(trade => {

    if (trade.type === "buy") {
      bought += Number(trade.weight) || 0;
    }

    if (trade.type === "sell") {
      sold += Number(trade.weight) || 0;
    }

  });


  const ledger = calculateLedger();


  document.getElementById("todayDate").textContent =
    getPersianDate();


  document.getElementById("homeTradeCount").textContent =
    formatNumber(todayTrades.length);


  document.getElementById("homeBought").textContent =
    formatNumber(bought) + " گرم";


  document.getElementById("homeSold").textContent =
    formatNumber(sold) + " گرم";


  /*
    موجودی همیشه مقدار باز را نشان می‌دهد.
    
    Long 200g  -> 200g
    Short 200g -> 200g
  */

  document.getElementById("homeBalance").textContent =
    formatNumber(Math.abs(ledger.position)) +
    " گرم";


  /*
    میانگین موجودی خرید
    یا
    میانگین فروش باز
  */

  const homeAverage =
    document.getElementById("homeAveragePrice");


  if (ledger.position > 0) {

    homeAverage.textContent =
      "فی میانگین موجودی: " +
      formatMoney(ledger.averageCost) +
      " تومان";

  } else if (ledger.position < 0) {

    homeAverage.textContent =
      "فی میانگین فروش باز: " +
      formatMoney(ledger.averageCost) +
      " تومان";

  } else {

    homeAverage.textContent =
      "0 تومان";
  }


  renderTodayTrades();
}


/* =========================
   TODAY TRADES
========================= */

function renderTodayTrades() {

  const container =
    document.getElementById("homeTrades");

  if (!container) return;


  const todayKey = getDateKey();

  const todayTrades = trades
    .filter(trade => trade.dateKey === todayKey)
    .sort(
      (a, b) =>
        new Date(b.timestamp) -
        new Date(a.timestamp)
    );


  if (!todayTrades.length) {

    container.innerHTML = `
      <div class="empty-state">
        امروز معامله‌ای ثبت نشده است.
      </div>
    `;

    return;
  }


  container.innerHTML =
    todayTrades.map(trade => `

      <div class="trade-item">

        <div class="trade-main">

          <strong class="${trade.type === "buy"
            ? "buy-text"
            : "sell-text"}">

            ${trade.type === "buy"
              ? "خرید"
              : "فروش"}

          </strong>

          <span>
            ${formatNumber(trade.weight)} گرم
          </span>

        </div>


        <div class="trade-info">

          <span>
            ${formatMoney(trade.price18)}
            تومان
          </span>

          <span>
            ${trade.time}
          </span>

        </div>

      </div>

    `).join("");
}


/* =========================
   TRANSACTIONS
========================= */

function updateLiveConversion() {

  const price18 =
    Number(
      document.getElementById("price18").value
    ) || 0;


  const mazhane =
    price18 * FACTOR;


  document.getElementById("livePrice").textContent =
    formatMoney(price18);


  document.getElementById("liveMazhane").textContent =
    formatMoney(mazhane);


  const mazhaneInput =
    document.getElementById("mazhane");


  if (
    document.activeElement !== mazhaneInput
  ) {

    mazhaneInput.value =
      mazhane ? Math.round(mazhane) : "";
  }
}


function updateFromMazhane() {

  const mazhane =
    Number(
      document.getElementById("mazhane").value
    ) || 0;


  const price18 =
    mazhane / FACTOR;


  document.getElementById("liveMazhane").textContent =
    formatMoney(mazhane);


  document.getElementById("livePrice").textContent =
    formatMoney(price18);


  const priceInput =
    document.getElementById("price18");


  if (
    document.activeElement !== priceInput
  ) {

    priceInput.value =
      price18 ? Math.round(price18) : "";
  }
}


/* =========================
   SAVE TRADE
========================= */

function saveTrade() {

  const type =
    document.getElementById("tradeType").value;


  const weight =
    Number(
      document.getElementById("weight").value
    );


  const price18 =
    Number(
      document.getElementById("price18").value
    );


  const mazhane =
    Number(
      document.getElementById("mazhane").value
    ) || (price18 * FACTOR);


  if (
    !weight ||
    weight <= 0 ||
    !price18 ||
    price18 <= 0
  ) {

    alert("لطفاً وزن و قیمت را صحیح وارد کنید.");

    return;
  }


  const now = new Date();


  const trade = {

    id:
      Date.now().toString() +
      Math.random()
        .toString(36)
        .substring(2, 8),

    type,

    weight,

    price18,

    mazhane,

    dateKey:
      getDateKey(now),

    date:
      getPersianDate(now),

    time:
      getTime(now),

    timestamp:
      now.toISOString()
  };


  trades.push(trade);

  saveTrades();


  document.getElementById("weight").value = "";
  document.getElementById("price18").value = "";
  document.getElementById("mazhane").value = "";


  updateLiveConversion();

  renderAll();
}


/* =========================
   HISTORY
========================= */

function renderHistory() {

  const container =
    document.getElementById("historyList");

  if (!container) return;


  if (!trades.length) {

    container.innerHTML = `
      <div class="empty-state">
        هنوز معامله‌ای ثبت نشده است.
      </div>
    `;

    return;
  }


  const grouped = {};


  trades.forEach(trade => {

    if (!grouped[trade.dateKey]) {
      grouped[trade.dateKey] = [];
    }

    grouped[trade.dateKey].push(trade);
  });


  const dates =
    Object.keys(grouped).sort(
      (a, b) =>
        new Date(b) - new Date(a)
    );


  container.innerHTML =
    dates.map(dateKey => {

      const dateTrades =
        grouped[dateKey].sort(
          (a, b) =>
            new Date(b.timestamp) -
            new Date(a.timestamp)
        );


      const dateTitle =
        dateTrades[0]?.date ||
        dateKey;


      return `

        <div class="history-day">

          <div class="history-date">
            ${dateTitle}
          </div>


          <div class="history-trades">

            ${dateTrades.map(trade => `

              <div class="trade-item">

                <div class="trade-main">

                  <strong class="${trade.type === "buy"
                    ? "buy-text"
                    : "sell-text"}">

                    ${trade.type === "buy"
                      ? "خرید"
                      : "فروش"}

                  </strong>


                  <span>
                    ${formatNumber(trade.weight)}
                    گرم
                  </span>

                </div>


                <div class="trade-info">

                  <span>
                    فی:
                    ${formatMoney(trade.price18)}
                  </span>


                  <span>
                    ${trade.time}
                  </span>

                </div>


                <div class="trade-actions">

                  <button
                    onclick="openEditModal('${trade.id}')"
                  >
                    ✏️
                  </button>


                  <button
                    onclick="deleteTrade('${trade.id}')"
                  >
                    🗑️
                  </button>

                </div>

              </div>

            `).join("")}

          </div>

        </div>

      `;

    }).join("");
}


/* =========================
   DELETE
========================= */

function deleteTrade(id) {

  const ok =
    confirm("آیا از حذف این معامله مطمئن هستید؟");


  if (!ok) return;


  trades =
    trades.filter(
      trade => trade.id !== id
    );


  saveTrades();

  renderAll();
}


/* =========================
   EDIT MODAL
========================= */

function openEditModal(id) {

  const trade =
    trades.find(
      item => item.id === id
    );


  if (!trade) return;


  editingTradeId = id;


  document.getElementById("editType").value =
    trade.type;


  document.getElementById("editWeight").value =
    trade.weight;


  document.getElementById("editPrice18").value =
    trade.price18;


  document.getElementById("editMazhane").value =
    trade.mazhane;


  document
    .getElementById("editModal")
    .classList.add("show");
}


function closeEditModal() {

  editingTradeId = null;


  document
    .getElementById("editModal")
    .classList.remove("show");
}


function updateTrade() {

  if (!editingTradeId) return;


  const trade =
    trades.find(
      item => item.id === editingTradeId
    );


  if (!trade) return;


  const type =
    document.getElementById("editType").value;


  const weight =
    Number(
      document.getElementById("editWeight").value
    );


  const price18 =
    Number(
      document.getElementById("editPrice18").value
    );


  const mazhane =
    Number(
      document.getElementById("editMazhane").value
    ) || (price18 * FACTOR);


  if (
    !weight ||
    weight <= 0 ||
    !price18 ||
    price18 <= 0
  ) {

    alert("مقادیر وارد شده صحیح نیست.");

    return;
  }


  trade.type = type;
  trade.weight = weight;
  trade.price18 = price18;
  trade.mazhane = mazhane;


  saveTrades();

  closeEditModal();

  renderAll();
}


/* =========================
   REPORT
========================= */

function renderReport() {

  const ledger =
    calculateLedger();


  let totalBought = 0;
  let totalSold = 0;


  trades.forEach(trade => {

    if (trade.type === "buy") {

      totalBought +=
        Number(trade.weight) || 0;
    }


    if (trade.type === "sell") {

      totalSold +=
        Number(trade.weight) || 0;
    }

  });


  document.getElementById("totalBought").textContent =
    formatNumber(totalBought) +
    " گرم";


  document.getElementById("totalSold").textContent =
    formatNumber(totalSold) +
    " گرم";


  /*
    مقدار پوزیشن باز

    Long  = موجودی خرید
    Short = فروش باز
  */

  document.getElementById("totalWeight").textContent =
    formatNumber(Math.abs(ledger.position)) +
    " گرم";


  document.getElementById("tradeCount").textContent =
    formatNumber(trades.length);


  const reportAverage =
    document.getElementById("reportAveragePrice");


  if (ledger.position > 0) {

    reportAverage.textContent =
      "فی میانگین موجودی: " +
      formatMoney(ledger.averageCost) +
      " تومان";

  } else if (ledger.position < 0) {

    reportAverage.textContent =
      "فی میانگین فروش باز: " +
      formatMoney(ledger.averageCost) +
      " تومان";

  } else {

    reportAverage.textContent =
      "0 تومان";
  }


  const pnl =
    document.getElementById("realizedProfit");


  pnl.textContent =
    (ledger.realizedProfit >= 0
      ? "+"
      : "") +
    formatMoney(ledger.realizedProfit) +
    " تومان";


  if (ledger.realizedProfit > 0) {

    pnl.className =
      "closed-profit";

  } else if (ledger.realizedProfit < 0) {

    pnl.className =
      "closed-loss";

  } else {

    pnl.className = "";
  }


  renderClosedTrades(
    ledger.closedTrades
  );
}


/* =========================
   CLOSED TRADES
========================= */

function renderClosedTrades(closedTrades) {

  const container =
    document.getElementById("closedTrades");

  if (!container) return;


  if (!closedTrades.length) {

    container.innerHTML = `
      <div class="empty-state">
        هنوز معامله بسته‌شده‌ای وجود ندارد.
      </div>
    `;

    return;
  }


  container.innerHTML =
    closedTrades
      .slice()
      .reverse()
      .map(item => `

        <div class="trade-item">

          <div class="trade-main">

            <strong>
              ${item.type === "long"
                ? "خرید → فروش"
                : "فروش → خرید"}
            </strong>


            <span>
              ${formatNumber(item.weight)}
              گرم
            </span>

          </div>


          <div class="trade-info">

            <span>
              باز:
              ${formatMoney(item.openPrice)}
            </span>


            <span>
              بسته:
              ${formatMoney(item.closePrice)}
            </span>


            <span class="${
              item.profit >= 0
                ? "closed-profit"
                : "closed-loss"
            }">

              ${
                item.profit >= 0
                  ? "+"
                  : ""
              }

              ${formatMoney(item.profit)}

              تومان

            </span>

          </div>

        </div>

      `)
      .join("");
}


/* =========================
   SETTINGS
========================= */

function loadSettings() {

  const input =
    document.getElementById("factorInput");


  if (input) {

    input.value = FACTOR;
  }
}


function saveFactor() {

  const value =
    Number(
      document.getElementById("factorInput").value
    );


  if (
    !value ||
    value <= 0
  ) {

    alert("ضریب صحیح وارد کنید.");

    return;
  }


  FACTOR = value;


  localStorage.setItem(
    "shayan_gold_factor",
    FACTOR
  );


  updateLiveConversion();


  alert("ضریب با موفقیت ذخیره شد.");
}


/* =========================
   NAVIGATION
========================= */

function showPage(pageId) {

  document
    .querySelectorAll(".page")
    .forEach(page => {

      page.classList.remove("active");

    });


  const page =
    document.getElementById(pageId);


  if (page) {

    page.classList.add("active");
  }


  document
    .querySelectorAll(".nav-btn")
    .forEach(btn => {

      btn.classList.toggle(
        "active",
        btn.dataset.page === pageId
      );

    });
}


/* =========================
   RENDER ALL
========================= */

function renderAll() {

  renderHome();

  renderHistory();

  renderReport();
}


/* =========================
   EVENTS
========================= */

document.addEventListener(
  "DOMContentLoaded",
  function () {


    /* Navigation */

    document
      .querySelectorAll(".nav-btn")
      .forEach(btn => {

        btn.addEventListener(
          "click",
          function () {

            showPage(
              this.dataset.page
            );

          }
        );

      });


    /* Price -> Mazhane */

    const price18 =
      document.getElementById("price18");


    if (price18) {

      price18.addEventListener(
        "input",
        updateLiveConversion
      );
    }


    /* Mazhane -> Price */

    const mazhane =
      document.getElementById("mazhane");


    if (mazhane) {

      mazhane.addEventListener(
        "input",
        updateFromMazhane
      );
    }


    /* Save trade */

    const saveTradeBtn =
      document.getElementById("saveTrade");


    if (saveTradeBtn) {

      saveTradeBtn.addEventListener(
        "click",
        saveTrade
      );
    }


    /* Save factor */

    const saveFactorBtn =
      document.getElementById("saveFactor");


    if (saveFactorBtn) {

      saveFactorBtn.addEventListener(
        "click",
        saveFactor
      );
    }


    /* Update trade */

    const updateTradeBtn =
      document.getElementById("updateTrade");


    if (updateTradeBtn) {

      updateTradeBtn.addEventListener(
        "click",
        updateTrade
      );
    }


    /* Close modal */

    const closeModal =
      document.getElementById("closeModal");


    if (closeModal) {

      closeModal.addEventListener(
        "click",
        closeEditModal
      );
    }


    /* Initial */

    loadSettings();

    renderAll();

    updateLiveConversion();

  }
);


/* =========================
   GLOBAL FUNCTIONS
   For inline HTML onclick
========================= */

window.openEditModal =
  openEditModal;

window.closeEditModal =
  closeEditModal;

window.updateTrade =
  updateTrade;

window.deleteTrade =
  deleteTrade;

window.saveTrade =
  saveTrade;

window.saveFactor =
  saveFactor;

window.showPage =
  showPage;

