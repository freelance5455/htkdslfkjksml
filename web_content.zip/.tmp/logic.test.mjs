// scripts/logic.test.ts
import assert from "node:assert/strict";

// node_modules/mp4-muxer/build/mp4-muxer.mjs
var __accessCheck = (obj, member, msg) => {
  if (!member.has(obj))
    throw TypeError("Cannot " + msg);
};
var __privateGet = (obj, member, getter) => {
  __accessCheck(obj, member, "read from private field");
  return getter ? getter.call(obj) : member.get(obj);
};
var __privateAdd = (obj, member, value) => {
  if (member.has(obj))
    throw TypeError("Cannot add the same private member more than once");
  member instanceof WeakSet ? member.add(obj) : member.set(obj, value);
};
var __privateSet = (obj, member, value, setter) => {
  __accessCheck(obj, member, "write to private field");
  setter ? setter.call(obj, value) : member.set(obj, value);
  return value;
};
var __privateWrapper = (obj, member, setter, getter) => ({
  set _(value) {
    __privateSet(obj, member, value, setter);
  },
  get _() {
    return __privateGet(obj, member, getter);
  }
});
var __privateMethod = (obj, member, method) => {
  __accessCheck(obj, member, "access private method");
  return method;
};
var bytes = new Uint8Array(8);
var view = new DataView(bytes.buffer);
var u8 = (value) => {
  return [(value % 256 + 256) % 256];
};
var u16 = (value) => {
  view.setUint16(0, value, false);
  return [bytes[0], bytes[1]];
};
var i16 = (value) => {
  view.setInt16(0, value, false);
  return [bytes[0], bytes[1]];
};
var u24 = (value) => {
  view.setUint32(0, value, false);
  return [bytes[1], bytes[2], bytes[3]];
};
var u32 = (value) => {
  view.setUint32(0, value, false);
  return [bytes[0], bytes[1], bytes[2], bytes[3]];
};
var i32 = (value) => {
  view.setInt32(0, value, false);
  return [bytes[0], bytes[1], bytes[2], bytes[3]];
};
var u64 = (value) => {
  view.setUint32(0, Math.floor(value / 2 ** 32), false);
  view.setUint32(4, value, false);
  return [bytes[0], bytes[1], bytes[2], bytes[3], bytes[4], bytes[5], bytes[6], bytes[7]];
};
var fixed_8_8 = (value) => {
  view.setInt16(0, 2 ** 8 * value, false);
  return [bytes[0], bytes[1]];
};
var fixed_16_16 = (value) => {
  view.setInt32(0, 2 ** 16 * value, false);
  return [bytes[0], bytes[1], bytes[2], bytes[3]];
};
var fixed_2_30 = (value) => {
  view.setInt32(0, 2 ** 30 * value, false);
  return [bytes[0], bytes[1], bytes[2], bytes[3]];
};
var ascii = (text, nullTerminated = false) => {
  let bytes2 = Array(text.length).fill(null).map((_, i) => text.charCodeAt(i));
  if (nullTerminated)
    bytes2.push(0);
  return bytes2;
};
var last = (arr) => {
  return arr && arr[arr.length - 1];
};
var lastPresentedSample = (samples) => {
  let result = void 0;
  for (let sample of samples) {
    if (!result || sample.presentationTimestamp > result.presentationTimestamp) {
      result = sample;
    }
  }
  return result;
};
var intoTimescale = (timeInSeconds, timescale, round = true) => {
  let value = timeInSeconds * timescale;
  return round ? Math.round(value) : value;
};
var rotationMatrix = (rotationInDegrees) => {
  let theta = rotationInDegrees * (Math.PI / 180);
  let cosTheta = Math.cos(theta);
  let sinTheta = Math.sin(theta);
  return [
    cosTheta,
    sinTheta,
    0,
    -sinTheta,
    cosTheta,
    0,
    0,
    0,
    1
  ];
};
var IDENTITY_MATRIX = rotationMatrix(0);
var matrixToBytes = (matrix) => {
  return [
    fixed_16_16(matrix[0]),
    fixed_16_16(matrix[1]),
    fixed_2_30(matrix[2]),
    fixed_16_16(matrix[3]),
    fixed_16_16(matrix[4]),
    fixed_2_30(matrix[5]),
    fixed_16_16(matrix[6]),
    fixed_16_16(matrix[7]),
    fixed_2_30(matrix[8])
  ];
};
var deepClone = (x) => {
  if (!x)
    return x;
  if (typeof x !== "object")
    return x;
  if (Array.isArray(x))
    return x.map(deepClone);
  return Object.fromEntries(Object.entries(x).map(([key, value]) => [key, deepClone(value)]));
};
var isU32 = (value) => {
  return value >= 0 && value < 2 ** 32;
};
var box = (type, contents, children) => ({
  type,
  contents: contents && new Uint8Array(contents.flat(10)),
  children
});
var fullBox = (type, version, flags, contents, children) => box(
  type,
  [u8(version), u24(flags), contents ?? []],
  children
);
var ftyp = (details) => {
  let minorVersion = 512;
  if (details.fragmented)
    return box("ftyp", [
      ascii("iso5"),
      // Major brand
      u32(minorVersion),
      // Minor version
      // Compatible brands
      ascii("iso5"),
      ascii("iso6"),
      ascii("mp41")
    ]);
  return box("ftyp", [
    ascii("isom"),
    // Major brand
    u32(minorVersion),
    // Minor version
    // Compatible brands
    ascii("isom"),
    details.holdsAvc ? ascii("avc1") : [],
    ascii("mp41")
  ]);
};
var mdat = (reserveLargeSize) => ({ type: "mdat", largeSize: reserveLargeSize });
var free = (size) => ({ type: "free", size });
var moov = (tracks, creationTime, fragmented = false) => box("moov", null, [
  mvhd(creationTime, tracks),
  ...tracks.map((x) => trak(x, creationTime)),
  fragmented ? mvex(tracks) : null
]);
var mvhd = (creationTime, tracks) => {
  let duration = intoTimescale(Math.max(
    0,
    ...tracks.filter((x) => x.samples.length > 0).map((x) => {
      const lastSample = lastPresentedSample(x.samples);
      return lastSample.presentationTimestamp + lastSample.duration;
    })
  ), GLOBAL_TIMESCALE);
  let nextTrackId = Math.max(...tracks.map((x) => x.id)) + 1;
  let needsU64 = !isU32(creationTime) || !isU32(duration);
  let u32OrU64 = needsU64 ? u64 : u32;
  return fullBox("mvhd", +needsU64, 0, [
    u32OrU64(creationTime),
    // Creation time
    u32OrU64(creationTime),
    // Modification time
    u32(GLOBAL_TIMESCALE),
    // Timescale
    u32OrU64(duration),
    // Duration
    fixed_16_16(1),
    // Preferred rate
    fixed_8_8(1),
    // Preferred volume
    Array(10).fill(0),
    // Reserved
    matrixToBytes(IDENTITY_MATRIX),
    // Matrix
    Array(24).fill(0),
    // Pre-defined
    u32(nextTrackId)
    // Next track ID
  ]);
};
var trak = (track, creationTime) => box("trak", null, [
  tkhd(track, creationTime),
  mdia(track, creationTime)
]);
var tkhd = (track, creationTime) => {
  let lastSample = lastPresentedSample(track.samples);
  let durationInGlobalTimescale = intoTimescale(
    lastSample ? lastSample.presentationTimestamp + lastSample.duration : 0,
    GLOBAL_TIMESCALE
  );
  let needsU64 = !isU32(creationTime) || !isU32(durationInGlobalTimescale);
  let u32OrU64 = needsU64 ? u64 : u32;
  let matrix;
  if (track.info.type === "video") {
    matrix = typeof track.info.rotation === "number" ? rotationMatrix(track.info.rotation) : track.info.rotation;
  } else {
    matrix = IDENTITY_MATRIX;
  }
  return fullBox("tkhd", +needsU64, 3, [
    u32OrU64(creationTime),
    // Creation time
    u32OrU64(creationTime),
    // Modification time
    u32(track.id),
    // Track ID
    u32(0),
    // Reserved
    u32OrU64(durationInGlobalTimescale),
    // Duration
    Array(8).fill(0),
    // Reserved
    u16(0),
    // Layer
    u16(0),
    // Alternate group
    fixed_8_8(track.info.type === "audio" ? 1 : 0),
    // Volume
    u16(0),
    // Reserved
    matrixToBytes(matrix),
    // Matrix
    fixed_16_16(track.info.type === "video" ? track.info.width : 0),
    // Track width
    fixed_16_16(track.info.type === "video" ? track.info.height : 0)
    // Track height
  ]);
};
var mdia = (track, creationTime) => box("mdia", null, [
  mdhd(track, creationTime),
  hdlr(track.info.type === "video" ? "vide" : "soun"),
  minf(track)
]);
var mdhd = (track, creationTime) => {
  let lastSample = lastPresentedSample(track.samples);
  let localDuration = intoTimescale(
    lastSample ? lastSample.presentationTimestamp + lastSample.duration : 0,
    track.timescale
  );
  let needsU64 = !isU32(creationTime) || !isU32(localDuration);
  let u32OrU64 = needsU64 ? u64 : u32;
  return fullBox("mdhd", +needsU64, 0, [
    u32OrU64(creationTime),
    // Creation time
    u32OrU64(creationTime),
    // Modification time
    u32(track.timescale),
    // Timescale
    u32OrU64(localDuration),
    // Duration
    u16(21956),
    // Language ("und", undetermined)
    u16(0)
    // Quality
  ]);
};
var hdlr = (componentSubtype) => fullBox("hdlr", 0, 0, [
  ascii("mhlr"),
  // Component type
  ascii(componentSubtype),
  // Component subtype
  u32(0),
  // Component manufacturer
  u32(0),
  // Component flags
  u32(0),
  // Component flags mask
  ascii("mp4-muxer-hdlr", true)
  // Component name
]);
var minf = (track) => box("minf", null, [
  track.info.type === "video" ? vmhd() : smhd(),
  dinf(),
  stbl(track)
]);
var vmhd = () => fullBox("vmhd", 0, 1, [
  u16(0),
  // Graphics mode
  u16(0),
  // Opcolor R
  u16(0),
  // Opcolor G
  u16(0)
  // Opcolor B
]);
var smhd = () => fullBox("smhd", 0, 0, [
  u16(0),
  // Balance
  u16(0)
  // Reserved
]);
var dinf = () => box("dinf", null, [
  dref()
]);
var dref = () => fullBox("dref", 0, 0, [
  u32(1)
  // Entry count
], [
  url()
]);
var url = () => fullBox("url ", 0, 1);
var stbl = (track) => {
  const needsCtts = track.compositionTimeOffsetTable.length > 1 || track.compositionTimeOffsetTable.some((x) => x.sampleCompositionTimeOffset !== 0);
  return box("stbl", null, [
    stsd(track),
    stts(track),
    stss(track),
    stsc(track),
    stsz(track),
    stco(track),
    needsCtts ? ctts(track) : null
  ]);
};
var stsd = (track) => fullBox("stsd", 0, 0, [
  u32(1)
  // Entry count
], [
  track.info.type === "video" ? videoSampleDescription(
    VIDEO_CODEC_TO_BOX_NAME[track.info.codec],
    track
  ) : soundSampleDescription(
    AUDIO_CODEC_TO_BOX_NAME[track.info.codec],
    track
  )
]);
var videoSampleDescription = (compressionType, track) => box(compressionType, [
  Array(6).fill(0),
  // Reserved
  u16(1),
  // Data reference index
  u16(0),
  // Pre-defined
  u16(0),
  // Reserved
  Array(12).fill(0),
  // Pre-defined
  u16(track.info.width),
  // Width
  u16(track.info.height),
  // Height
  u32(4718592),
  // Horizontal resolution
  u32(4718592),
  // Vertical resolution
  u32(0),
  // Reserved
  u16(1),
  // Frame count
  Array(32).fill(0),
  // Compressor name
  u16(24),
  // Depth
  i16(65535)
  // Pre-defined
], [
  VIDEO_CODEC_TO_CONFIGURATION_BOX[track.info.codec](track),
  track.info.decoderConfig.colorSpace ? colr(track) : null
]);
var COLOR_PRIMARIES_MAP = {
  "bt709": 1,
  // ITU-R BT.709
  "bt470bg": 5,
  // ITU-R BT.470BG
  "smpte170m": 6
  // ITU-R BT.601 525 - SMPTE 170M
};
var TRANSFER_CHARACTERISTICS_MAP = {
  "bt709": 1,
  // ITU-R BT.709
  "smpte170m": 6,
  // SMPTE 170M
  "iec61966-2-1": 13
  // IEC 61966-2-1
};
var MATRIX_COEFFICIENTS_MAP = {
  "rgb": 0,
  // Identity
  "bt709": 1,
  // ITU-R BT.709
  "bt470bg": 5,
  // ITU-R BT.470BG
  "smpte170m": 6
  // SMPTE 170M
};
var colr = (track) => box("colr", [
  ascii("nclx"),
  // Colour type
  u16(COLOR_PRIMARIES_MAP[track.info.decoderConfig.colorSpace.primaries]),
  // Colour primaries
  u16(TRANSFER_CHARACTERISTICS_MAP[track.info.decoderConfig.colorSpace.transfer]),
  // Transfer characteristics
  u16(MATRIX_COEFFICIENTS_MAP[track.info.decoderConfig.colorSpace.matrix]),
  // Matrix coefficients
  u8((track.info.decoderConfig.colorSpace.fullRange ? 1 : 0) << 7)
  // Full range flag
]);
var avcC = (track) => track.info.decoderConfig && box("avcC", [
  // For AVC, description is an AVCDecoderConfigurationRecord, so nothing else to do here
  ...new Uint8Array(track.info.decoderConfig.description)
]);
var hvcC = (track) => track.info.decoderConfig && box("hvcC", [
  // For HEVC, description is a HEVCDecoderConfigurationRecord, so nothing else to do here
  ...new Uint8Array(track.info.decoderConfig.description)
]);
var vpcC = (track) => {
  if (!track.info.decoderConfig) {
    return null;
  }
  let decoderConfig = track.info.decoderConfig;
  if (!decoderConfig.colorSpace) {
    throw new Error(`'colorSpace' is required in the decoder config for VP9.`);
  }
  let parts = decoderConfig.codec.split(".");
  let profile = Number(parts[1]);
  let level = Number(parts[2]);
  let bitDepth = Number(parts[3]);
  let chromaSubsampling = 0;
  let thirdByte = (bitDepth << 4) + (chromaSubsampling << 1) + Number(decoderConfig.colorSpace.fullRange);
  let colourPrimaries = 2;
  let transferCharacteristics = 2;
  let matrixCoefficients = 2;
  return fullBox("vpcC", 1, 0, [
    u8(profile),
    // Profile
    u8(level),
    // Level
    u8(thirdByte),
    // Bit depth, chroma subsampling, full range
    u8(colourPrimaries),
    // Colour primaries
    u8(transferCharacteristics),
    // Transfer characteristics
    u8(matrixCoefficients),
    // Matrix coefficients
    u16(0)
    // Codec initialization data size
  ]);
};
var av1C = () => {
  let marker = 1;
  let version = 1;
  let firstByte = (marker << 7) + version;
  return box("av1C", [
    firstByte,
    0,
    0,
    0
  ]);
};
var soundSampleDescription = (compressionType, track) => box(compressionType, [
  Array(6).fill(0),
  // Reserved
  u16(1),
  // Data reference index
  u16(0),
  // Version
  u16(0),
  // Revision level
  u32(0),
  // Vendor
  u16(track.info.numberOfChannels),
  // Number of channels
  u16(16),
  // Sample size (bits)
  u16(0),
  // Compression ID
  u16(0),
  // Packet size
  fixed_16_16(track.info.sampleRate)
  // Sample rate
], [
  AUDIO_CODEC_TO_CONFIGURATION_BOX[track.info.codec](track)
]);
var esds = (track) => {
  let description = new Uint8Array(track.info.decoderConfig.description);
  return fullBox("esds", 0, 0, [
    // https://stackoverflow.com/a/54803118
    u32(58753152),
    // TAG(3) = Object Descriptor ([2])
    u8(32 + description.byteLength),
    // length of this OD (which includes the next 2 tags)
    u16(1),
    // ES_ID = 1
    u8(0),
    // flags etc = 0
    u32(75530368),
    // TAG(4) = ES Descriptor ([2]) embedded in above OD
    u8(18 + description.byteLength),
    // length of this ESD
    u8(64),
    // MPEG-4 Audio
    u8(21),
    // stream type(6bits)=5 audio, flags(2bits)=1
    u24(0),
    // 24bit buffer size
    u32(130071),
    // max bitrate
    u32(130071),
    // avg bitrate
    u32(92307584),
    // TAG(5) = ASC ([2],[3]) embedded in above OD
    u8(description.byteLength),
    // length
    ...description,
    u32(109084800),
    // TAG(6)
    u8(1),
    // length
    u8(2)
    // data
  ]);
};
var dOps = (track) => {
  let preskip = 3840;
  let gain = 0;
  const description = track.info.decoderConfig?.description;
  if (description) {
    if (description.byteLength < 18) {
      throw new TypeError("Invalid decoder description provided for Opus; must be at least 18 bytes long.");
    }
    const view2 = ArrayBuffer.isView(description) ? new DataView(description.buffer, description.byteOffset, description.byteLength) : new DataView(description);
    preskip = view2.getUint16(10, true);
    gain = view2.getInt16(14, true);
  }
  return box("dOps", [
    u8(0),
    // Version
    u8(track.info.numberOfChannels),
    // OutputChannelCount
    u16(preskip),
    u32(track.info.sampleRate),
    // InputSampleRate
    fixed_8_8(gain),
    // OutputGain
    u8(0)
    // ChannelMappingFamily
  ]);
};
var stts = (track) => {
  return fullBox("stts", 0, 0, [
    u32(track.timeToSampleTable.length),
    // Number of entries
    track.timeToSampleTable.map((x) => [
      // Time-to-sample table
      u32(x.sampleCount),
      // Sample count
      u32(x.sampleDelta)
      // Sample duration
    ])
  ]);
};
var stss = (track) => {
  if (track.samples.every((x) => x.type === "key"))
    return null;
  let keySamples = [...track.samples.entries()].filter(([, sample]) => sample.type === "key");
  return fullBox("stss", 0, 0, [
    u32(keySamples.length),
    // Number of entries
    keySamples.map(([index]) => u32(index + 1))
    // Sync sample table
  ]);
};
var stsc = (track) => {
  return fullBox("stsc", 0, 0, [
    u32(track.compactlyCodedChunkTable.length),
    // Number of entries
    track.compactlyCodedChunkTable.map((x) => [
      // Sample-to-chunk table
      u32(x.firstChunk),
      // First chunk
      u32(x.samplesPerChunk),
      // Samples per chunk
      u32(1)
      // Sample description index
    ])
  ]);
};
var stsz = (track) => fullBox("stsz", 0, 0, [
  u32(0),
  // Sample size (0 means non-constant size)
  u32(track.samples.length),
  // Number of entries
  track.samples.map((x) => u32(x.size))
  // Sample size table
]);
var stco = (track) => {
  if (track.finalizedChunks.length > 0 && last(track.finalizedChunks).offset >= 2 ** 32) {
    return fullBox("co64", 0, 0, [
      u32(track.finalizedChunks.length),
      // Number of entries
      track.finalizedChunks.map((x) => u64(x.offset))
      // Chunk offset table
    ]);
  }
  return fullBox("stco", 0, 0, [
    u32(track.finalizedChunks.length),
    // Number of entries
    track.finalizedChunks.map((x) => u32(x.offset))
    // Chunk offset table
  ]);
};
var ctts = (track) => {
  return fullBox("ctts", 0, 0, [
    u32(track.compositionTimeOffsetTable.length),
    // Number of entries
    track.compositionTimeOffsetTable.map((x) => [
      // Time-to-sample table
      u32(x.sampleCount),
      // Sample count
      u32(x.sampleCompositionTimeOffset)
      // Sample offset
    ])
  ]);
};
var mvex = (tracks) => {
  return box("mvex", null, tracks.map(trex));
};
var trex = (track) => {
  return fullBox("trex", 0, 0, [
    u32(track.id),
    // Track ID
    u32(1),
    // Default sample description index
    u32(0),
    // Default sample duration
    u32(0),
    // Default sample size
    u32(0)
    // Default sample flags
  ]);
};
var moof = (sequenceNumber, tracks) => {
  return box("moof", null, [
    mfhd(sequenceNumber),
    ...tracks.map(traf)
  ]);
};
var mfhd = (sequenceNumber) => {
  return fullBox("mfhd", 0, 0, [
    u32(sequenceNumber)
    // Sequence number
  ]);
};
var fragmentSampleFlags = (sample) => {
  let byte1 = 0;
  let byte2 = 0;
  let byte3 = 0;
  let byte4 = 0;
  let sampleIsDifferenceSample = sample.type === "delta";
  byte2 |= +sampleIsDifferenceSample;
  if (sampleIsDifferenceSample) {
    byte1 |= 1;
  } else {
    byte1 |= 2;
  }
  return byte1 << 24 | byte2 << 16 | byte3 << 8 | byte4;
};
var traf = (track) => {
  return box("traf", null, [
    tfhd(track),
    tfdt(track),
    trun(track)
  ]);
};
var tfhd = (track) => {
  let tfFlags = 0;
  tfFlags |= 8;
  tfFlags |= 16;
  tfFlags |= 32;
  tfFlags |= 131072;
  let referenceSample = track.currentChunk.samples[1] ?? track.currentChunk.samples[0];
  let referenceSampleInfo = {
    duration: referenceSample.timescaleUnitsToNextSample,
    size: referenceSample.size,
    flags: fragmentSampleFlags(referenceSample)
  };
  return fullBox("tfhd", 0, tfFlags, [
    u32(track.id),
    // Track ID
    u32(referenceSampleInfo.duration),
    // Default sample duration
    u32(referenceSampleInfo.size),
    // Default sample size
    u32(referenceSampleInfo.flags)
    // Default sample flags
  ]);
};
var tfdt = (track) => {
  return fullBox("tfdt", 1, 0, [
    u64(intoTimescale(track.currentChunk.startTimestamp, track.timescale))
    // Base Media Decode Time
  ]);
};
var trun = (track) => {
  let allSampleDurations = track.currentChunk.samples.map((x) => x.timescaleUnitsToNextSample);
  let allSampleSizes = track.currentChunk.samples.map((x) => x.size);
  let allSampleFlags = track.currentChunk.samples.map(fragmentSampleFlags);
  let allSampleCompositionTimeOffsets = track.currentChunk.samples.map((x) => intoTimescale(x.presentationTimestamp - x.decodeTimestamp, track.timescale));
  let uniqueSampleDurations = new Set(allSampleDurations);
  let uniqueSampleSizes = new Set(allSampleSizes);
  let uniqueSampleFlags = new Set(allSampleFlags);
  let uniqueSampleCompositionTimeOffsets = new Set(allSampleCompositionTimeOffsets);
  let firstSampleFlagsPresent = uniqueSampleFlags.size === 2 && allSampleFlags[0] !== allSampleFlags[1];
  let sampleDurationPresent = uniqueSampleDurations.size > 1;
  let sampleSizePresent = uniqueSampleSizes.size > 1;
  let sampleFlagsPresent = !firstSampleFlagsPresent && uniqueSampleFlags.size > 1;
  let sampleCompositionTimeOffsetsPresent = uniqueSampleCompositionTimeOffsets.size > 1 || [...uniqueSampleCompositionTimeOffsets].some((x) => x !== 0);
  let flags = 0;
  flags |= 1;
  flags |= 4 * +firstSampleFlagsPresent;
  flags |= 256 * +sampleDurationPresent;
  flags |= 512 * +sampleSizePresent;
  flags |= 1024 * +sampleFlagsPresent;
  flags |= 2048 * +sampleCompositionTimeOffsetsPresent;
  return fullBox("trun", 1, flags, [
    u32(track.currentChunk.samples.length),
    // Sample count
    u32(track.currentChunk.offset - track.currentChunk.moofOffset || 0),
    // Data offset
    firstSampleFlagsPresent ? u32(allSampleFlags[0]) : [],
    track.currentChunk.samples.map((_, i) => [
      sampleDurationPresent ? u32(allSampleDurations[i]) : [],
      // Sample duration
      sampleSizePresent ? u32(allSampleSizes[i]) : [],
      // Sample size
      sampleFlagsPresent ? u32(allSampleFlags[i]) : [],
      // Sample flags
      // Sample composition time offsets
      sampleCompositionTimeOffsetsPresent ? i32(allSampleCompositionTimeOffsets[i]) : []
    ])
  ]);
};
var mfra = (tracks) => {
  return box("mfra", null, [
    ...tracks.map(tfra),
    mfro()
  ]);
};
var tfra = (track, trackIndex) => {
  let version = 1;
  return fullBox("tfra", version, 0, [
    u32(track.id),
    // Track ID
    u32(63),
    // This specifies that traf number, trun number and sample number are 32-bit ints
    u32(track.finalizedChunks.length),
    // Number of entries
    track.finalizedChunks.map((chunk) => [
      u64(intoTimescale(chunk.startTimestamp, track.timescale)),
      // Time
      u64(chunk.moofOffset),
      // moof offset
      u32(trackIndex + 1),
      // traf number
      u32(1),
      // trun number
      u32(1)
      // Sample number
    ])
  ]);
};
var mfro = () => {
  return fullBox("mfro", 0, 0, [
    // This value needs to be overwritten manually from the outside, where the actual size of the enclosing mfra box
    // is known
    u32(0)
    // Size
  ]);
};
var VIDEO_CODEC_TO_BOX_NAME = {
  "avc": "avc1",
  "hevc": "hvc1",
  "vp9": "vp09",
  "av1": "av01"
};
var VIDEO_CODEC_TO_CONFIGURATION_BOX = {
  "avc": avcC,
  "hevc": hvcC,
  "vp9": vpcC,
  "av1": av1C
};
var AUDIO_CODEC_TO_BOX_NAME = {
  "aac": "mp4a",
  "opus": "Opus"
};
var AUDIO_CODEC_TO_CONFIGURATION_BOX = {
  "aac": esds,
  "opus": dOps
};
var Target = class {
};
var ArrayBufferTarget = class extends Target {
  constructor() {
    super(...arguments);
    this.buffer = null;
  }
};
var StreamTarget = class extends Target {
  constructor(options) {
    super();
    this.options = options;
    if (typeof options !== "object") {
      throw new TypeError("StreamTarget requires an options object to be passed to its constructor.");
    }
    if (options.onData) {
      if (typeof options.onData !== "function") {
        throw new TypeError("options.onData, when provided, must be a function.");
      }
      if (options.onData.length < 2) {
        throw new TypeError(
          "options.onData, when provided, must be a function that takes in at least two arguments (data and position). Ignoring the position argument, which specifies the byte offset at which the data is to be written, can lead to broken outputs."
        );
      }
    }
    if (options.chunked !== void 0 && typeof options.chunked !== "boolean") {
      throw new TypeError("options.chunked, when provided, must be a boolean.");
    }
    if (options.chunkSize !== void 0 && (!Number.isInteger(options.chunkSize) || options.chunkSize < 1024)) {
      throw new TypeError("options.chunkSize, when provided, must be an integer and not smaller than 1024.");
    }
  }
};
var FileSystemWritableFileStreamTarget = class extends Target {
  constructor(stream, options) {
    super();
    this.stream = stream;
    this.options = options;
    if (!(stream instanceof FileSystemWritableFileStream)) {
      throw new TypeError("FileSystemWritableFileStreamTarget requires a FileSystemWritableFileStream instance.");
    }
    if (options !== void 0 && typeof options !== "object") {
      throw new TypeError("FileSystemWritableFileStreamTarget's options, when provided, must be an object.");
    }
    if (options) {
      if (options.chunkSize !== void 0 && (!Number.isInteger(options.chunkSize) || options.chunkSize <= 0)) {
        throw new TypeError("options.chunkSize, when provided, must be a positive integer");
      }
    }
  }
};
var _helper;
var _helperView;
var Writer = class {
  constructor() {
    this.pos = 0;
    __privateAdd(this, _helper, new Uint8Array(8));
    __privateAdd(this, _helperView, new DataView(__privateGet(this, _helper).buffer));
    this.offsets = /* @__PURE__ */ new WeakMap();
  }
  /** Sets the current position for future writes to a new one. */
  seek(newPos) {
    this.pos = newPos;
  }
  writeU32(value) {
    __privateGet(this, _helperView).setUint32(0, value, false);
    this.write(__privateGet(this, _helper).subarray(0, 4));
  }
  writeU64(value) {
    __privateGet(this, _helperView).setUint32(0, Math.floor(value / 2 ** 32), false);
    __privateGet(this, _helperView).setUint32(4, value, false);
    this.write(__privateGet(this, _helper).subarray(0, 8));
  }
  writeAscii(text) {
    for (let i = 0; i < text.length; i++) {
      __privateGet(this, _helperView).setUint8(i % 8, text.charCodeAt(i));
      if (i % 8 === 7)
        this.write(__privateGet(this, _helper));
    }
    if (text.length % 8 !== 0) {
      this.write(__privateGet(this, _helper).subarray(0, text.length % 8));
    }
  }
  writeBox(box2) {
    this.offsets.set(box2, this.pos);
    if (box2.contents && !box2.children) {
      this.writeBoxHeader(box2, box2.size ?? box2.contents.byteLength + 8);
      this.write(box2.contents);
    } else {
      let startPos = this.pos;
      this.writeBoxHeader(box2, 0);
      if (box2.contents)
        this.write(box2.contents);
      if (box2.children) {
        for (let child of box2.children)
          if (child)
            this.writeBox(child);
      }
      let endPos = this.pos;
      let size = box2.size ?? endPos - startPos;
      this.seek(startPos);
      this.writeBoxHeader(box2, size);
      this.seek(endPos);
    }
  }
  writeBoxHeader(box2, size) {
    this.writeU32(box2.largeSize ? 1 : size);
    this.writeAscii(box2.type);
    if (box2.largeSize)
      this.writeU64(size);
  }
  measureBoxHeader(box2) {
    return 8 + (box2.largeSize ? 8 : 0);
  }
  patchBox(box2) {
    let endPos = this.pos;
    this.seek(this.offsets.get(box2));
    this.writeBox(box2);
    this.seek(endPos);
  }
  measureBox(box2) {
    if (box2.contents && !box2.children) {
      let headerSize = this.measureBoxHeader(box2);
      return headerSize + box2.contents.byteLength;
    } else {
      let result = this.measureBoxHeader(box2);
      if (box2.contents)
        result += box2.contents.byteLength;
      if (box2.children) {
        for (let child of box2.children)
          if (child)
            result += this.measureBox(child);
      }
      return result;
    }
  }
};
_helper = /* @__PURE__ */ new WeakMap();
_helperView = /* @__PURE__ */ new WeakMap();
var _target;
var _buffer;
var _bytes;
var _maxPos;
var _ensureSize;
var ensureSize_fn;
var ArrayBufferTargetWriter = class extends Writer {
  constructor(target) {
    super();
    __privateAdd(this, _ensureSize);
    __privateAdd(this, _target, void 0);
    __privateAdd(this, _buffer, new ArrayBuffer(2 ** 16));
    __privateAdd(this, _bytes, new Uint8Array(__privateGet(this, _buffer)));
    __privateAdd(this, _maxPos, 0);
    __privateSet(this, _target, target);
  }
  write(data) {
    __privateMethod(this, _ensureSize, ensureSize_fn).call(this, this.pos + data.byteLength);
    __privateGet(this, _bytes).set(data, this.pos);
    this.pos += data.byteLength;
    __privateSet(this, _maxPos, Math.max(__privateGet(this, _maxPos), this.pos));
  }
  finalize() {
    __privateMethod(this, _ensureSize, ensureSize_fn).call(this, this.pos);
    __privateGet(this, _target).buffer = __privateGet(this, _buffer).slice(0, Math.max(__privateGet(this, _maxPos), this.pos));
  }
};
_target = /* @__PURE__ */ new WeakMap();
_buffer = /* @__PURE__ */ new WeakMap();
_bytes = /* @__PURE__ */ new WeakMap();
_maxPos = /* @__PURE__ */ new WeakMap();
_ensureSize = /* @__PURE__ */ new WeakSet();
ensureSize_fn = function(size) {
  let newLength = __privateGet(this, _buffer).byteLength;
  while (newLength < size)
    newLength *= 2;
  if (newLength === __privateGet(this, _buffer).byteLength)
    return;
  let newBuffer = new ArrayBuffer(newLength);
  let newBytes = new Uint8Array(newBuffer);
  newBytes.set(__privateGet(this, _bytes), 0);
  __privateSet(this, _buffer, newBuffer);
  __privateSet(this, _bytes, newBytes);
};
var DEFAULT_CHUNK_SIZE = 2 ** 24;
var MAX_CHUNKS_AT_ONCE = 2;
var _target2;
var _sections;
var _chunked;
var _chunkSize;
var _chunks;
var _writeDataIntoChunks;
var writeDataIntoChunks_fn;
var _insertSectionIntoChunk;
var insertSectionIntoChunk_fn;
var _createChunk;
var createChunk_fn;
var _flushChunks;
var flushChunks_fn;
var StreamTargetWriter = class extends Writer {
  constructor(target) {
    super();
    __privateAdd(this, _writeDataIntoChunks);
    __privateAdd(this, _insertSectionIntoChunk);
    __privateAdd(this, _createChunk);
    __privateAdd(this, _flushChunks);
    __privateAdd(this, _target2, void 0);
    __privateAdd(this, _sections, []);
    __privateAdd(this, _chunked, void 0);
    __privateAdd(this, _chunkSize, void 0);
    __privateAdd(this, _chunks, []);
    __privateSet(this, _target2, target);
    __privateSet(this, _chunked, target.options?.chunked ?? false);
    __privateSet(this, _chunkSize, target.options?.chunkSize ?? DEFAULT_CHUNK_SIZE);
  }
  write(data) {
    __privateGet(this, _sections).push({
      data: data.slice(),
      start: this.pos
    });
    this.pos += data.byteLength;
  }
  flush() {
    if (__privateGet(this, _sections).length === 0)
      return;
    let chunks = [];
    let sorted = [...__privateGet(this, _sections)].sort((a, b) => a.start - b.start);
    chunks.push({
      start: sorted[0].start,
      size: sorted[0].data.byteLength
    });
    for (let i = 1; i < sorted.length; i++) {
      let lastChunk = chunks[chunks.length - 1];
      let section = sorted[i];
      if (section.start <= lastChunk.start + lastChunk.size) {
        lastChunk.size = Math.max(lastChunk.size, section.start + section.data.byteLength - lastChunk.start);
      } else {
        chunks.push({
          start: section.start,
          size: section.data.byteLength
        });
      }
    }
    for (let chunk of chunks) {
      chunk.data = new Uint8Array(chunk.size);
      for (let section of __privateGet(this, _sections)) {
        if (chunk.start <= section.start && section.start < chunk.start + chunk.size) {
          chunk.data.set(section.data, section.start - chunk.start);
        }
      }
      if (__privateGet(this, _chunked)) {
        __privateMethod(this, _writeDataIntoChunks, writeDataIntoChunks_fn).call(this, chunk.data, chunk.start);
        __privateMethod(this, _flushChunks, flushChunks_fn).call(this);
      } else {
        __privateGet(this, _target2).options.onData?.(chunk.data, chunk.start);
      }
    }
    __privateGet(this, _sections).length = 0;
  }
  finalize() {
    if (__privateGet(this, _chunked)) {
      __privateMethod(this, _flushChunks, flushChunks_fn).call(this, true);
    }
  }
};
_target2 = /* @__PURE__ */ new WeakMap();
_sections = /* @__PURE__ */ new WeakMap();
_chunked = /* @__PURE__ */ new WeakMap();
_chunkSize = /* @__PURE__ */ new WeakMap();
_chunks = /* @__PURE__ */ new WeakMap();
_writeDataIntoChunks = /* @__PURE__ */ new WeakSet();
writeDataIntoChunks_fn = function(data, position) {
  let chunkIndex = __privateGet(this, _chunks).findIndex((x) => x.start <= position && position < x.start + __privateGet(this, _chunkSize));
  if (chunkIndex === -1)
    chunkIndex = __privateMethod(this, _createChunk, createChunk_fn).call(this, position);
  let chunk = __privateGet(this, _chunks)[chunkIndex];
  let relativePosition = position - chunk.start;
  let toWrite = data.subarray(0, Math.min(__privateGet(this, _chunkSize) - relativePosition, data.byteLength));
  chunk.data.set(toWrite, relativePosition);
  let section = {
    start: relativePosition,
    end: relativePosition + toWrite.byteLength
  };
  __privateMethod(this, _insertSectionIntoChunk, insertSectionIntoChunk_fn).call(this, chunk, section);
  if (chunk.written[0].start === 0 && chunk.written[0].end === __privateGet(this, _chunkSize)) {
    chunk.shouldFlush = true;
  }
  if (__privateGet(this, _chunks).length > MAX_CHUNKS_AT_ONCE) {
    for (let i = 0; i < __privateGet(this, _chunks).length - 1; i++) {
      __privateGet(this, _chunks)[i].shouldFlush = true;
    }
    __privateMethod(this, _flushChunks, flushChunks_fn).call(this);
  }
  if (toWrite.byteLength < data.byteLength) {
    __privateMethod(this, _writeDataIntoChunks, writeDataIntoChunks_fn).call(this, data.subarray(toWrite.byteLength), position + toWrite.byteLength);
  }
};
_insertSectionIntoChunk = /* @__PURE__ */ new WeakSet();
insertSectionIntoChunk_fn = function(chunk, section) {
  let low = 0;
  let high = chunk.written.length - 1;
  let index = -1;
  while (low <= high) {
    let mid = Math.floor(low + (high - low + 1) / 2);
    if (chunk.written[mid].start <= section.start) {
      low = mid + 1;
      index = mid;
    } else {
      high = mid - 1;
    }
  }
  chunk.written.splice(index + 1, 0, section);
  if (index === -1 || chunk.written[index].end < section.start)
    index++;
  while (index < chunk.written.length - 1 && chunk.written[index].end >= chunk.written[index + 1].start) {
    chunk.written[index].end = Math.max(chunk.written[index].end, chunk.written[index + 1].end);
    chunk.written.splice(index + 1, 1);
  }
};
_createChunk = /* @__PURE__ */ new WeakSet();
createChunk_fn = function(includesPosition) {
  let start = Math.floor(includesPosition / __privateGet(this, _chunkSize)) * __privateGet(this, _chunkSize);
  let chunk = {
    start,
    data: new Uint8Array(__privateGet(this, _chunkSize)),
    written: [],
    shouldFlush: false
  };
  __privateGet(this, _chunks).push(chunk);
  __privateGet(this, _chunks).sort((a, b) => a.start - b.start);
  return __privateGet(this, _chunks).indexOf(chunk);
};
_flushChunks = /* @__PURE__ */ new WeakSet();
flushChunks_fn = function(force = false) {
  for (let i = 0; i < __privateGet(this, _chunks).length; i++) {
    let chunk = __privateGet(this, _chunks)[i];
    if (!chunk.shouldFlush && !force)
      continue;
    for (let section of chunk.written) {
      __privateGet(this, _target2).options.onData?.(
        chunk.data.subarray(section.start, section.end),
        chunk.start + section.start
      );
    }
    __privateGet(this, _chunks).splice(i--, 1);
  }
};
var FileSystemWritableFileStreamTargetWriter = class extends StreamTargetWriter {
  constructor(target) {
    super(new StreamTarget({
      onData: (data, position) => target.stream.write({
        type: "write",
        data,
        position
      }),
      chunked: true,
      chunkSize: target.options?.chunkSize
    }));
  }
};
var GLOBAL_TIMESCALE = 1e3;
var SUPPORTED_VIDEO_CODECS = ["avc", "hevc", "vp9", "av1"];
var SUPPORTED_AUDIO_CODECS = ["aac", "opus"];
var TIMESTAMP_OFFSET = 2082844800;
var FIRST_TIMESTAMP_BEHAVIORS = ["strict", "offset", "cross-track-offset"];
var _options;
var _writer;
var _ftypSize;
var _mdat;
var _videoTrack;
var _audioTrack;
var _creationTime;
var _finalizedChunks;
var _nextFragmentNumber;
var _videoSampleQueue;
var _audioSampleQueue;
var _finalized;
var _validateOptions;
var validateOptions_fn;
var _writeHeader;
var writeHeader_fn;
var _computeMoovSizeUpperBound;
var computeMoovSizeUpperBound_fn;
var _prepareTracks;
var prepareTracks_fn;
var _generateMpeg4AudioSpecificConfig;
var generateMpeg4AudioSpecificConfig_fn;
var _createSampleForTrack;
var createSampleForTrack_fn;
var _addSampleToTrack;
var addSampleToTrack_fn;
var _validateTimestamp;
var validateTimestamp_fn;
var _finalizeCurrentChunk;
var finalizeCurrentChunk_fn;
var _finalizeFragment;
var finalizeFragment_fn;
var _maybeFlushStreamingTargetWriter;
var maybeFlushStreamingTargetWriter_fn;
var _ensureNotFinalized;
var ensureNotFinalized_fn;
var Muxer = class {
  constructor(options) {
    __privateAdd(this, _validateOptions);
    __privateAdd(this, _writeHeader);
    __privateAdd(this, _computeMoovSizeUpperBound);
    __privateAdd(this, _prepareTracks);
    __privateAdd(this, _generateMpeg4AudioSpecificConfig);
    __privateAdd(this, _createSampleForTrack);
    __privateAdd(this, _addSampleToTrack);
    __privateAdd(this, _validateTimestamp);
    __privateAdd(this, _finalizeCurrentChunk);
    __privateAdd(this, _finalizeFragment);
    __privateAdd(this, _maybeFlushStreamingTargetWriter);
    __privateAdd(this, _ensureNotFinalized);
    __privateAdd(this, _options, void 0);
    __privateAdd(this, _writer, void 0);
    __privateAdd(this, _ftypSize, void 0);
    __privateAdd(this, _mdat, void 0);
    __privateAdd(this, _videoTrack, null);
    __privateAdd(this, _audioTrack, null);
    __privateAdd(this, _creationTime, Math.floor(Date.now() / 1e3) + TIMESTAMP_OFFSET);
    __privateAdd(this, _finalizedChunks, []);
    __privateAdd(this, _nextFragmentNumber, 1);
    __privateAdd(this, _videoSampleQueue, []);
    __privateAdd(this, _audioSampleQueue, []);
    __privateAdd(this, _finalized, false);
    __privateMethod(this, _validateOptions, validateOptions_fn).call(this, options);
    options.video = deepClone(options.video);
    options.audio = deepClone(options.audio);
    options.fastStart = deepClone(options.fastStart);
    this.target = options.target;
    __privateSet(this, _options, {
      firstTimestampBehavior: "strict",
      ...options
    });
    if (options.target instanceof ArrayBufferTarget) {
      __privateSet(this, _writer, new ArrayBufferTargetWriter(options.target));
    } else if (options.target instanceof StreamTarget) {
      __privateSet(this, _writer, new StreamTargetWriter(options.target));
    } else if (options.target instanceof FileSystemWritableFileStreamTarget) {
      __privateSet(this, _writer, new FileSystemWritableFileStreamTargetWriter(options.target));
    } else {
      throw new Error(`Invalid target: ${options.target}`);
    }
    __privateMethod(this, _prepareTracks, prepareTracks_fn).call(this);
    __privateMethod(this, _writeHeader, writeHeader_fn).call(this);
  }
  addVideoChunk(sample, meta, timestamp, compositionTimeOffset) {
    if (!(sample instanceof EncodedVideoChunk)) {
      throw new TypeError("addVideoChunk's first argument (sample) must be of type EncodedVideoChunk.");
    }
    if (meta && typeof meta !== "object") {
      throw new TypeError("addVideoChunk's second argument (meta), when provided, must be an object.");
    }
    if (timestamp !== void 0 && (!Number.isFinite(timestamp) || timestamp < 0)) {
      throw new TypeError(
        "addVideoChunk's third argument (timestamp), when provided, must be a non-negative real number."
      );
    }
    if (compositionTimeOffset !== void 0 && !Number.isFinite(compositionTimeOffset)) {
      throw new TypeError(
        "addVideoChunk's fourth argument (compositionTimeOffset), when provided, must be a real number."
      );
    }
    let data = new Uint8Array(sample.byteLength);
    sample.copyTo(data);
    this.addVideoChunkRaw(
      data,
      sample.type,
      timestamp ?? sample.timestamp,
      sample.duration,
      meta,
      compositionTimeOffset
    );
  }
  addVideoChunkRaw(data, type, timestamp, duration, meta, compositionTimeOffset) {
    if (!(data instanceof Uint8Array)) {
      throw new TypeError("addVideoChunkRaw's first argument (data) must be an instance of Uint8Array.");
    }
    if (type !== "key" && type !== "delta") {
      throw new TypeError("addVideoChunkRaw's second argument (type) must be either 'key' or 'delta'.");
    }
    if (!Number.isFinite(timestamp) || timestamp < 0) {
      throw new TypeError("addVideoChunkRaw's third argument (timestamp) must be a non-negative real number.");
    }
    if (!Number.isFinite(duration) || duration < 0) {
      throw new TypeError("addVideoChunkRaw's fourth argument (duration) must be a non-negative real number.");
    }
    if (meta && typeof meta !== "object") {
      throw new TypeError("addVideoChunkRaw's fifth argument (meta), when provided, must be an object.");
    }
    if (compositionTimeOffset !== void 0 && !Number.isFinite(compositionTimeOffset)) {
      throw new TypeError(
        "addVideoChunkRaw's sixth argument (compositionTimeOffset), when provided, must be a real number."
      );
    }
    __privateMethod(this, _ensureNotFinalized, ensureNotFinalized_fn).call(this);
    if (!__privateGet(this, _options).video)
      throw new Error("No video track declared.");
    if (typeof __privateGet(this, _options).fastStart === "object" && __privateGet(this, _videoTrack).samples.length === __privateGet(this, _options).fastStart.expectedVideoChunks) {
      throw new Error(`Cannot add more video chunks than specified in 'fastStart' (${__privateGet(this, _options).fastStart.expectedVideoChunks}).`);
    }
    let videoSample = __privateMethod(this, _createSampleForTrack, createSampleForTrack_fn).call(this, __privateGet(this, _videoTrack), data, type, timestamp, duration, meta, compositionTimeOffset);
    if (__privateGet(this, _options).fastStart === "fragmented" && __privateGet(this, _audioTrack)) {
      while (__privateGet(this, _audioSampleQueue).length > 0 && __privateGet(this, _audioSampleQueue)[0].decodeTimestamp <= videoSample.decodeTimestamp) {
        let audioSample = __privateGet(this, _audioSampleQueue).shift();
        __privateMethod(this, _addSampleToTrack, addSampleToTrack_fn).call(this, __privateGet(this, _audioTrack), audioSample);
      }
      if (videoSample.decodeTimestamp <= __privateGet(this, _audioTrack).lastDecodeTimestamp) {
        __privateMethod(this, _addSampleToTrack, addSampleToTrack_fn).call(this, __privateGet(this, _videoTrack), videoSample);
      } else {
        __privateGet(this, _videoSampleQueue).push(videoSample);
      }
    } else {
      __privateMethod(this, _addSampleToTrack, addSampleToTrack_fn).call(this, __privateGet(this, _videoTrack), videoSample);
    }
  }
  addAudioChunk(sample, meta, timestamp) {
    if (!(sample instanceof EncodedAudioChunk)) {
      throw new TypeError("addAudioChunk's first argument (sample) must be of type EncodedAudioChunk.");
    }
    if (meta && typeof meta !== "object") {
      throw new TypeError("addAudioChunk's second argument (meta), when provided, must be an object.");
    }
    if (timestamp !== void 0 && (!Number.isFinite(timestamp) || timestamp < 0)) {
      throw new TypeError(
        "addAudioChunk's third argument (timestamp), when provided, must be a non-negative real number."
      );
    }
    let data = new Uint8Array(sample.byteLength);
    sample.copyTo(data);
    this.addAudioChunkRaw(data, sample.type, timestamp ?? sample.timestamp, sample.duration, meta);
  }
  addAudioChunkRaw(data, type, timestamp, duration, meta) {
    if (!(data instanceof Uint8Array)) {
      throw new TypeError("addAudioChunkRaw's first argument (data) must be an instance of Uint8Array.");
    }
    if (type !== "key" && type !== "delta") {
      throw new TypeError("addAudioChunkRaw's second argument (type) must be either 'key' or 'delta'.");
    }
    if (!Number.isFinite(timestamp) || timestamp < 0) {
      throw new TypeError("addAudioChunkRaw's third argument (timestamp) must be a non-negative real number.");
    }
    if (!Number.isFinite(duration) || duration < 0) {
      throw new TypeError("addAudioChunkRaw's fourth argument (duration) must be a non-negative real number.");
    }
    if (meta && typeof meta !== "object") {
      throw new TypeError("addAudioChunkRaw's fifth argument (meta), when provided, must be an object.");
    }
    __privateMethod(this, _ensureNotFinalized, ensureNotFinalized_fn).call(this);
    if (!__privateGet(this, _options).audio)
      throw new Error("No audio track declared.");
    if (typeof __privateGet(this, _options).fastStart === "object" && __privateGet(this, _audioTrack).samples.length === __privateGet(this, _options).fastStart.expectedAudioChunks) {
      throw new Error(`Cannot add more audio chunks than specified in 'fastStart' (${__privateGet(this, _options).fastStart.expectedAudioChunks}).`);
    }
    let audioSample = __privateMethod(this, _createSampleForTrack, createSampleForTrack_fn).call(this, __privateGet(this, _audioTrack), data, type, timestamp, duration, meta);
    if (__privateGet(this, _options).fastStart === "fragmented" && __privateGet(this, _videoTrack)) {
      while (__privateGet(this, _videoSampleQueue).length > 0 && __privateGet(this, _videoSampleQueue)[0].decodeTimestamp <= audioSample.decodeTimestamp) {
        let videoSample = __privateGet(this, _videoSampleQueue).shift();
        __privateMethod(this, _addSampleToTrack, addSampleToTrack_fn).call(this, __privateGet(this, _videoTrack), videoSample);
      }
      if (audioSample.decodeTimestamp <= __privateGet(this, _videoTrack).lastDecodeTimestamp) {
        __privateMethod(this, _addSampleToTrack, addSampleToTrack_fn).call(this, __privateGet(this, _audioTrack), audioSample);
      } else {
        __privateGet(this, _audioSampleQueue).push(audioSample);
      }
    } else {
      __privateMethod(this, _addSampleToTrack, addSampleToTrack_fn).call(this, __privateGet(this, _audioTrack), audioSample);
    }
  }
  /** Finalizes the file, making it ready for use. Must be called after all video and audio chunks have been added. */
  finalize() {
    if (__privateGet(this, _finalized)) {
      throw new Error("Cannot finalize a muxer more than once.");
    }
    if (__privateGet(this, _options).fastStart === "fragmented") {
      for (let videoSample of __privateGet(this, _videoSampleQueue))
        __privateMethod(this, _addSampleToTrack, addSampleToTrack_fn).call(this, __privateGet(this, _videoTrack), videoSample);
      for (let audioSample of __privateGet(this, _audioSampleQueue))
        __privateMethod(this, _addSampleToTrack, addSampleToTrack_fn).call(this, __privateGet(this, _audioTrack), audioSample);
      __privateMethod(this, _finalizeFragment, finalizeFragment_fn).call(this, false);
    } else {
      if (__privateGet(this, _videoTrack))
        __privateMethod(this, _finalizeCurrentChunk, finalizeCurrentChunk_fn).call(this, __privateGet(this, _videoTrack));
      if (__privateGet(this, _audioTrack))
        __privateMethod(this, _finalizeCurrentChunk, finalizeCurrentChunk_fn).call(this, __privateGet(this, _audioTrack));
    }
    let tracks = [__privateGet(this, _videoTrack), __privateGet(this, _audioTrack)].filter(Boolean);
    if (__privateGet(this, _options).fastStart === "in-memory") {
      let mdatSize;
      for (let i = 0; i < 2; i++) {
        let movieBox2 = moov(tracks, __privateGet(this, _creationTime));
        let movieBoxSize = __privateGet(this, _writer).measureBox(movieBox2);
        mdatSize = __privateGet(this, _writer).measureBox(__privateGet(this, _mdat));
        let currentChunkPos = __privateGet(this, _writer).pos + movieBoxSize + mdatSize;
        for (let chunk of __privateGet(this, _finalizedChunks)) {
          chunk.offset = currentChunkPos;
          for (let { data } of chunk.samples) {
            currentChunkPos += data.byteLength;
            mdatSize += data.byteLength;
          }
        }
        if (currentChunkPos < 2 ** 32)
          break;
        if (mdatSize >= 2 ** 32)
          __privateGet(this, _mdat).largeSize = true;
      }
      let movieBox = moov(tracks, __privateGet(this, _creationTime));
      __privateGet(this, _writer).writeBox(movieBox);
      __privateGet(this, _mdat).size = mdatSize;
      __privateGet(this, _writer).writeBox(__privateGet(this, _mdat));
      for (let chunk of __privateGet(this, _finalizedChunks)) {
        for (let sample of chunk.samples) {
          __privateGet(this, _writer).write(sample.data);
          sample.data = null;
        }
      }
    } else if (__privateGet(this, _options).fastStart === "fragmented") {
      let startPos = __privateGet(this, _writer).pos;
      let mfraBox = mfra(tracks);
      __privateGet(this, _writer).writeBox(mfraBox);
      let mfraBoxSize = __privateGet(this, _writer).pos - startPos;
      __privateGet(this, _writer).seek(__privateGet(this, _writer).pos - 4);
      __privateGet(this, _writer).writeU32(mfraBoxSize);
    } else {
      let mdatPos = __privateGet(this, _writer).offsets.get(__privateGet(this, _mdat));
      let mdatSize = __privateGet(this, _writer).pos - mdatPos;
      __privateGet(this, _mdat).size = mdatSize;
      __privateGet(this, _mdat).largeSize = mdatSize >= 2 ** 32;
      __privateGet(this, _writer).patchBox(__privateGet(this, _mdat));
      let movieBox = moov(tracks, __privateGet(this, _creationTime));
      if (typeof __privateGet(this, _options).fastStart === "object") {
        __privateGet(this, _writer).seek(__privateGet(this, _ftypSize));
        __privateGet(this, _writer).writeBox(movieBox);
        let remainingBytes = mdatPos - __privateGet(this, _writer).pos;
        __privateGet(this, _writer).writeBox(free(remainingBytes));
      } else {
        __privateGet(this, _writer).writeBox(movieBox);
      }
    }
    __privateMethod(this, _maybeFlushStreamingTargetWriter, maybeFlushStreamingTargetWriter_fn).call(this);
    __privateGet(this, _writer).finalize();
    __privateSet(this, _finalized, true);
  }
};
_options = /* @__PURE__ */ new WeakMap();
_writer = /* @__PURE__ */ new WeakMap();
_ftypSize = /* @__PURE__ */ new WeakMap();
_mdat = /* @__PURE__ */ new WeakMap();
_videoTrack = /* @__PURE__ */ new WeakMap();
_audioTrack = /* @__PURE__ */ new WeakMap();
_creationTime = /* @__PURE__ */ new WeakMap();
_finalizedChunks = /* @__PURE__ */ new WeakMap();
_nextFragmentNumber = /* @__PURE__ */ new WeakMap();
_videoSampleQueue = /* @__PURE__ */ new WeakMap();
_audioSampleQueue = /* @__PURE__ */ new WeakMap();
_finalized = /* @__PURE__ */ new WeakMap();
_validateOptions = /* @__PURE__ */ new WeakSet();
validateOptions_fn = function(options) {
  if (typeof options !== "object") {
    throw new TypeError("The muxer requires an options object to be passed to its constructor.");
  }
  if (!(options.target instanceof Target)) {
    throw new TypeError("The target must be provided and an instance of Target.");
  }
  if (options.video) {
    if (!SUPPORTED_VIDEO_CODECS.includes(options.video.codec)) {
      throw new TypeError(`Unsupported video codec: ${options.video.codec}`);
    }
    if (!Number.isInteger(options.video.width) || options.video.width <= 0) {
      throw new TypeError(`Invalid video width: ${options.video.width}. Must be a positive integer.`);
    }
    if (!Number.isInteger(options.video.height) || options.video.height <= 0) {
      throw new TypeError(`Invalid video height: ${options.video.height}. Must be a positive integer.`);
    }
    const videoRotation = options.video.rotation;
    if (typeof videoRotation === "number" && ![0, 90, 180, 270].includes(videoRotation)) {
      throw new TypeError(`Invalid video rotation: ${videoRotation}. Has to be 0, 90, 180 or 270.`);
    } else if (Array.isArray(videoRotation) && (videoRotation.length !== 9 || videoRotation.some((value) => typeof value !== "number"))) {
      throw new TypeError(`Invalid video transformation matrix: ${videoRotation.join()}`);
    }
    if (options.video.frameRate !== void 0 && (!Number.isInteger(options.video.frameRate) || options.video.frameRate <= 0)) {
      throw new TypeError(
        `Invalid video frame rate: ${options.video.frameRate}. Must be a positive integer.`
      );
    }
  }
  if (options.audio) {
    if (!SUPPORTED_AUDIO_CODECS.includes(options.audio.codec)) {
      throw new TypeError(`Unsupported audio codec: ${options.audio.codec}`);
    }
    if (!Number.isInteger(options.audio.numberOfChannels) || options.audio.numberOfChannels <= 0) {
      throw new TypeError(
        `Invalid number of audio channels: ${options.audio.numberOfChannels}. Must be a positive integer.`
      );
    }
    if (!Number.isInteger(options.audio.sampleRate) || options.audio.sampleRate <= 0) {
      throw new TypeError(
        `Invalid audio sample rate: ${options.audio.sampleRate}. Must be a positive integer.`
      );
    }
  }
  if (options.firstTimestampBehavior && !FIRST_TIMESTAMP_BEHAVIORS.includes(options.firstTimestampBehavior)) {
    throw new TypeError(`Invalid first timestamp behavior: ${options.firstTimestampBehavior}`);
  }
  if (typeof options.fastStart === "object") {
    if (options.video) {
      if (options.fastStart.expectedVideoChunks === void 0) {
        throw new TypeError(`'fastStart' is an object but is missing property 'expectedVideoChunks'.`);
      } else if (!Number.isInteger(options.fastStart.expectedVideoChunks) || options.fastStart.expectedVideoChunks < 0) {
        throw new TypeError(`'expectedVideoChunks' must be a non-negative integer.`);
      }
    }
    if (options.audio) {
      if (options.fastStart.expectedAudioChunks === void 0) {
        throw new TypeError(`'fastStart' is an object but is missing property 'expectedAudioChunks'.`);
      } else if (!Number.isInteger(options.fastStart.expectedAudioChunks) || options.fastStart.expectedAudioChunks < 0) {
        throw new TypeError(`'expectedAudioChunks' must be a non-negative integer.`);
      }
    }
  } else if (![false, "in-memory", "fragmented"].includes(options.fastStart)) {
    throw new TypeError(`'fastStart' option must be false, 'in-memory', 'fragmented' or an object.`);
  }
  if (options.minFragmentDuration !== void 0 && (!Number.isFinite(options.minFragmentDuration) || options.minFragmentDuration < 0)) {
    throw new TypeError(`'minFragmentDuration' must be a non-negative number.`);
  }
};
_writeHeader = /* @__PURE__ */ new WeakSet();
writeHeader_fn = function() {
  __privateGet(this, _writer).writeBox(ftyp({
    holdsAvc: __privateGet(this, _options).video?.codec === "avc",
    fragmented: __privateGet(this, _options).fastStart === "fragmented"
  }));
  __privateSet(this, _ftypSize, __privateGet(this, _writer).pos);
  if (__privateGet(this, _options).fastStart === "in-memory") {
    __privateSet(this, _mdat, mdat(false));
  } else if (__privateGet(this, _options).fastStart === "fragmented") {
  } else {
    if (typeof __privateGet(this, _options).fastStart === "object") {
      let moovSizeUpperBound = __privateMethod(this, _computeMoovSizeUpperBound, computeMoovSizeUpperBound_fn).call(this);
      __privateGet(this, _writer).seek(__privateGet(this, _writer).pos + moovSizeUpperBound);
    }
    __privateSet(this, _mdat, mdat(true));
    __privateGet(this, _writer).writeBox(__privateGet(this, _mdat));
  }
  __privateMethod(this, _maybeFlushStreamingTargetWriter, maybeFlushStreamingTargetWriter_fn).call(this);
};
_computeMoovSizeUpperBound = /* @__PURE__ */ new WeakSet();
computeMoovSizeUpperBound_fn = function() {
  if (typeof __privateGet(this, _options).fastStart !== "object")
    return;
  let upperBound = 0;
  let sampleCounts = [
    __privateGet(this, _options).fastStart.expectedVideoChunks,
    __privateGet(this, _options).fastStart.expectedAudioChunks
  ];
  for (let n of sampleCounts) {
    if (!n)
      continue;
    upperBound += (4 + 4) * Math.ceil(2 / 3 * n);
    upperBound += 4 * n;
    upperBound += (4 + 4 + 4) * Math.ceil(2 / 3 * n);
    upperBound += 4 * n;
    upperBound += 8 * n;
  }
  upperBound += 4096;
  return upperBound;
};
_prepareTracks = /* @__PURE__ */ new WeakSet();
prepareTracks_fn = function() {
  if (__privateGet(this, _options).video) {
    __privateSet(this, _videoTrack, {
      id: 1,
      info: {
        type: "video",
        codec: __privateGet(this, _options).video.codec,
        width: __privateGet(this, _options).video.width,
        height: __privateGet(this, _options).video.height,
        rotation: __privateGet(this, _options).video.rotation ?? 0,
        decoderConfig: null
      },
      // The fallback contains many common frame rates as factors
      timescale: __privateGet(this, _options).video.frameRate ?? 57600,
      samples: [],
      finalizedChunks: [],
      currentChunk: null,
      firstDecodeTimestamp: void 0,
      lastDecodeTimestamp: -1,
      timeToSampleTable: [],
      compositionTimeOffsetTable: [],
      lastTimescaleUnits: null,
      lastSample: null,
      compactlyCodedChunkTable: []
    });
  }
  if (__privateGet(this, _options).audio) {
    __privateSet(this, _audioTrack, {
      id: __privateGet(this, _options).video ? 2 : 1,
      info: {
        type: "audio",
        codec: __privateGet(this, _options).audio.codec,
        numberOfChannels: __privateGet(this, _options).audio.numberOfChannels,
        sampleRate: __privateGet(this, _options).audio.sampleRate,
        decoderConfig: null
      },
      timescale: __privateGet(this, _options).audio.sampleRate,
      samples: [],
      finalizedChunks: [],
      currentChunk: null,
      firstDecodeTimestamp: void 0,
      lastDecodeTimestamp: -1,
      timeToSampleTable: [],
      compositionTimeOffsetTable: [],
      lastTimescaleUnits: null,
      lastSample: null,
      compactlyCodedChunkTable: []
    });
    if (__privateGet(this, _options).audio.codec === "aac") {
      let guessedCodecPrivate = __privateMethod(this, _generateMpeg4AudioSpecificConfig, generateMpeg4AudioSpecificConfig_fn).call(
        this,
        2,
        // Object type for AAC-LC, since it's the most common
        __privateGet(this, _options).audio.sampleRate,
        __privateGet(this, _options).audio.numberOfChannels
      );
      __privateGet(this, _audioTrack).info.decoderConfig = {
        codec: __privateGet(this, _options).audio.codec,
        description: guessedCodecPrivate,
        numberOfChannels: __privateGet(this, _options).audio.numberOfChannels,
        sampleRate: __privateGet(this, _options).audio.sampleRate
      };
    }
  }
};
_generateMpeg4AudioSpecificConfig = /* @__PURE__ */ new WeakSet();
generateMpeg4AudioSpecificConfig_fn = function(objectType, sampleRate, numberOfChannels) {
  let frequencyIndices = [96e3, 88200, 64e3, 48e3, 44100, 32e3, 24e3, 22050, 16e3, 12e3, 11025, 8e3, 7350];
  let frequencyIndex = frequencyIndices.indexOf(sampleRate);
  let channelConfig = numberOfChannels;
  let configBits = "";
  configBits += objectType.toString(2).padStart(5, "0");
  configBits += frequencyIndex.toString(2).padStart(4, "0");
  if (frequencyIndex === 15)
    configBits += sampleRate.toString(2).padStart(24, "0");
  configBits += channelConfig.toString(2).padStart(4, "0");
  let paddingLength = Math.ceil(configBits.length / 8) * 8;
  configBits = configBits.padEnd(paddingLength, "0");
  let configBytes = new Uint8Array(configBits.length / 8);
  for (let i = 0; i < configBits.length; i += 8) {
    configBytes[i / 8] = parseInt(configBits.slice(i, i + 8), 2);
  }
  return configBytes;
};
_createSampleForTrack = /* @__PURE__ */ new WeakSet();
createSampleForTrack_fn = function(track, data, type, timestamp, duration, meta, compositionTimeOffset) {
  let presentationTimestampInSeconds = timestamp / 1e6;
  let decodeTimestampInSeconds = (timestamp - (compositionTimeOffset ?? 0)) / 1e6;
  let durationInSeconds = duration / 1e6;
  let adjusted = __privateMethod(this, _validateTimestamp, validateTimestamp_fn).call(this, presentationTimestampInSeconds, decodeTimestampInSeconds, track);
  presentationTimestampInSeconds = adjusted.presentationTimestamp;
  decodeTimestampInSeconds = adjusted.decodeTimestamp;
  if (meta?.decoderConfig) {
    if (track.info.decoderConfig === null) {
      track.info.decoderConfig = meta.decoderConfig;
    } else {
      Object.assign(track.info.decoderConfig, meta.decoderConfig);
    }
  }
  let sample = {
    presentationTimestamp: presentationTimestampInSeconds,
    decodeTimestamp: decodeTimestampInSeconds,
    duration: durationInSeconds,
    data,
    size: data.byteLength,
    type,
    // Will be refined once the next sample comes in
    timescaleUnitsToNextSample: intoTimescale(durationInSeconds, track.timescale)
  };
  return sample;
};
_addSampleToTrack = /* @__PURE__ */ new WeakSet();
addSampleToTrack_fn = function(track, sample) {
  if (__privateGet(this, _options).fastStart !== "fragmented") {
    track.samples.push(sample);
  }
  const sampleCompositionTimeOffset = intoTimescale(sample.presentationTimestamp - sample.decodeTimestamp, track.timescale);
  if (track.lastTimescaleUnits !== null) {
    let timescaleUnits = intoTimescale(sample.decodeTimestamp, track.timescale, false);
    let delta = Math.round(timescaleUnits - track.lastTimescaleUnits);
    track.lastTimescaleUnits += delta;
    track.lastSample.timescaleUnitsToNextSample = delta;
    if (__privateGet(this, _options).fastStart !== "fragmented") {
      let lastTableEntry = last(track.timeToSampleTable);
      if (lastTableEntry.sampleCount === 1) {
        lastTableEntry.sampleDelta = delta;
        lastTableEntry.sampleCount++;
      } else if (lastTableEntry.sampleDelta === delta) {
        lastTableEntry.sampleCount++;
      } else {
        lastTableEntry.sampleCount--;
        track.timeToSampleTable.push({
          sampleCount: 2,
          sampleDelta: delta
        });
      }
      const lastCompositionTimeOffsetTableEntry = last(track.compositionTimeOffsetTable);
      if (lastCompositionTimeOffsetTableEntry.sampleCompositionTimeOffset === sampleCompositionTimeOffset) {
        lastCompositionTimeOffsetTableEntry.sampleCount++;
      } else {
        track.compositionTimeOffsetTable.push({
          sampleCount: 1,
          sampleCompositionTimeOffset
        });
      }
    }
  } else {
    track.lastTimescaleUnits = 0;
    if (__privateGet(this, _options).fastStart !== "fragmented") {
      track.timeToSampleTable.push({
        sampleCount: 1,
        sampleDelta: intoTimescale(sample.duration, track.timescale)
      });
      track.compositionTimeOffsetTable.push({
        sampleCount: 1,
        sampleCompositionTimeOffset
      });
    }
  }
  track.lastSample = sample;
  let beginNewChunk = false;
  if (!track.currentChunk) {
    beginNewChunk = true;
  } else {
    let currentChunkDuration = sample.presentationTimestamp - track.currentChunk.startTimestamp;
    if (__privateGet(this, _options).fastStart === "fragmented") {
      let mostImportantTrack = __privateGet(this, _videoTrack) ?? __privateGet(this, _audioTrack);
      const chunkDuration = __privateGet(this, _options).minFragmentDuration ?? 1;
      if (track === mostImportantTrack && sample.type === "key" && currentChunkDuration >= chunkDuration) {
        beginNewChunk = true;
        __privateMethod(this, _finalizeFragment, finalizeFragment_fn).call(this);
      }
    } else {
      beginNewChunk = currentChunkDuration >= 0.5;
    }
  }
  if (beginNewChunk) {
    if (track.currentChunk) {
      __privateMethod(this, _finalizeCurrentChunk, finalizeCurrentChunk_fn).call(this, track);
    }
    track.currentChunk = {
      startTimestamp: sample.presentationTimestamp,
      samples: []
    };
  }
  track.currentChunk.samples.push(sample);
};
_validateTimestamp = /* @__PURE__ */ new WeakSet();
validateTimestamp_fn = function(presentationTimestamp, decodeTimestamp, track) {
  const strictTimestampBehavior = __privateGet(this, _options).firstTimestampBehavior === "strict";
  const noLastDecodeTimestamp = track.lastDecodeTimestamp === -1;
  const timestampNonZero = decodeTimestamp !== 0;
  if (strictTimestampBehavior && noLastDecodeTimestamp && timestampNonZero) {
    throw new Error(
      `The first chunk for your media track must have a timestamp of 0 (received DTS=${decodeTimestamp}).Non-zero first timestamps are often caused by directly piping frames or audio data from a MediaStreamTrack into the encoder. Their timestamps are typically relative to the age of thedocument, which is probably what you want.

If you want to offset all timestamps of a track such that the first one is zero, set firstTimestampBehavior: 'offset' in the options.
`
    );
  } else if (__privateGet(this, _options).firstTimestampBehavior === "offset" || __privateGet(this, _options).firstTimestampBehavior === "cross-track-offset") {
    if (track.firstDecodeTimestamp === void 0) {
      track.firstDecodeTimestamp = decodeTimestamp;
    }
    let baseDecodeTimestamp;
    if (__privateGet(this, _options).firstTimestampBehavior === "offset") {
      baseDecodeTimestamp = track.firstDecodeTimestamp;
    } else {
      baseDecodeTimestamp = Math.min(
        __privateGet(this, _videoTrack)?.firstDecodeTimestamp ?? Infinity,
        __privateGet(this, _audioTrack)?.firstDecodeTimestamp ?? Infinity
      );
    }
    decodeTimestamp -= baseDecodeTimestamp;
    presentationTimestamp -= baseDecodeTimestamp;
  }
  if (decodeTimestamp < track.lastDecodeTimestamp) {
    throw new Error(
      `Timestamps must be monotonically increasing (DTS went from ${track.lastDecodeTimestamp * 1e6} to ${decodeTimestamp * 1e6}).`
    );
  }
  track.lastDecodeTimestamp = decodeTimestamp;
  return { presentationTimestamp, decodeTimestamp };
};
_finalizeCurrentChunk = /* @__PURE__ */ new WeakSet();
finalizeCurrentChunk_fn = function(track) {
  if (__privateGet(this, _options).fastStart === "fragmented") {
    throw new Error("Can't finalize individual chunks if 'fastStart' is set to 'fragmented'.");
  }
  if (!track.currentChunk)
    return;
  track.finalizedChunks.push(track.currentChunk);
  __privateGet(this, _finalizedChunks).push(track.currentChunk);
  if (track.compactlyCodedChunkTable.length === 0 || last(track.compactlyCodedChunkTable).samplesPerChunk !== track.currentChunk.samples.length) {
    track.compactlyCodedChunkTable.push({
      firstChunk: track.finalizedChunks.length,
      // 1-indexed
      samplesPerChunk: track.currentChunk.samples.length
    });
  }
  if (__privateGet(this, _options).fastStart === "in-memory") {
    track.currentChunk.offset = 0;
    return;
  }
  track.currentChunk.offset = __privateGet(this, _writer).pos;
  for (let sample of track.currentChunk.samples) {
    __privateGet(this, _writer).write(sample.data);
    sample.data = null;
  }
  __privateMethod(this, _maybeFlushStreamingTargetWriter, maybeFlushStreamingTargetWriter_fn).call(this);
};
_finalizeFragment = /* @__PURE__ */ new WeakSet();
finalizeFragment_fn = function(flushStreamingWriter = true) {
  if (__privateGet(this, _options).fastStart !== "fragmented") {
    throw new Error("Can't finalize a fragment unless 'fastStart' is set to 'fragmented'.");
  }
  let tracks = [__privateGet(this, _videoTrack), __privateGet(this, _audioTrack)].filter((track) => track && track.currentChunk);
  if (tracks.length === 0)
    return;
  let fragmentNumber = __privateWrapper(this, _nextFragmentNumber)._++;
  if (fragmentNumber === 1) {
    let movieBox = moov(tracks, __privateGet(this, _creationTime), true);
    __privateGet(this, _writer).writeBox(movieBox);
  }
  let moofOffset = __privateGet(this, _writer).pos;
  let moofBox = moof(fragmentNumber, tracks);
  __privateGet(this, _writer).writeBox(moofBox);
  {
    let mdatBox = mdat(false);
    let totalTrackSampleSize = 0;
    for (let track of tracks) {
      for (let sample of track.currentChunk.samples) {
        totalTrackSampleSize += sample.size;
      }
    }
    let mdatSize = __privateGet(this, _writer).measureBox(mdatBox) + totalTrackSampleSize;
    if (mdatSize >= 2 ** 32) {
      mdatBox.largeSize = true;
      mdatSize = __privateGet(this, _writer).measureBox(mdatBox) + totalTrackSampleSize;
    }
    mdatBox.size = mdatSize;
    __privateGet(this, _writer).writeBox(mdatBox);
  }
  for (let track of tracks) {
    track.currentChunk.offset = __privateGet(this, _writer).pos;
    track.currentChunk.moofOffset = moofOffset;
    for (let sample of track.currentChunk.samples) {
      __privateGet(this, _writer).write(sample.data);
      sample.data = null;
    }
  }
  let endPos = __privateGet(this, _writer).pos;
  __privateGet(this, _writer).seek(__privateGet(this, _writer).offsets.get(moofBox));
  let newMoofBox = moof(fragmentNumber, tracks);
  __privateGet(this, _writer).writeBox(newMoofBox);
  __privateGet(this, _writer).seek(endPos);
  for (let track of tracks) {
    track.finalizedChunks.push(track.currentChunk);
    __privateGet(this, _finalizedChunks).push(track.currentChunk);
    track.currentChunk = null;
  }
  if (flushStreamingWriter) {
    __privateMethod(this, _maybeFlushStreamingTargetWriter, maybeFlushStreamingTargetWriter_fn).call(this);
  }
};
_maybeFlushStreamingTargetWriter = /* @__PURE__ */ new WeakSet();
maybeFlushStreamingTargetWriter_fn = function() {
  if (__privateGet(this, _writer) instanceof StreamTargetWriter) {
    __privateGet(this, _writer).flush();
  }
};
_ensureNotFinalized = /* @__PURE__ */ new WeakSet();
ensureNotFinalized_fn = function() {
  if (__privateGet(this, _finalized)) {
    throw new Error("Cannot add new video or audio chunks after the file has been finalized.");
  }
};

// src/lib/timeline.ts
function seconds(ms, min = 0) {
  return Math.max(min, (Number.isFinite(ms) ? ms : 0) / 1e3);
}
function buildTimeline(project) {
  const timing = project.timing;
  const warnings = [];
  let cursor = 0;
  let hasAudio = false;
  const scenes = [];
  project.questions.forEach((question, index) => {
    const voice = Math.max(0, Math.min(1, timing.voiceVolume / 100));
    const clips = [];
    const combined = question.combinedAudioId ? project.media[question.combinedAudioId] : void 0;
    const questionAudio = question.questionAudioId ? project.media[question.questionAudioId] : void 0;
    const optionsAudio = question.optionsAudioId ? project.media[question.optionsAudioId] : void 0;
    const answerAudio = question.answerAudioId ? project.media[question.answerAudioId] : void 0;
    const useCombined = Boolean(timing.audioMode === "combined" && combined);
    let questionDuration = 0;
    let optionsDuration = 0;
    let optionsStart = 0;
    let thinkingStart = 0;
    if (useCombined && combined) {
      const combinedDuration = Math.max(0.2, combined.duration ?? 0);
      const split = Math.max(10, Math.min(95, timing.combinedSplit)) / 100;
      optionsStart = combinedDuration * split;
      questionDuration = optionsStart;
      optionsDuration = combinedDuration - optionsStart;
      thinkingStart = combinedDuration + seconds(timing.optionsHoldMs);
      clips.push({ id: `${question.id}_combined`, role: "question", mediaId: combined.id, start: 0, duration: combinedDuration, volume: voice });
      hasAudio = true;
    } else {
      questionDuration = questionAudio?.duration ?? seconds(timing.questionSilentMs, 0.8);
      optionsDuration = optionsAudio?.duration ?? seconds(timing.optionsSilentMs, 0.8);
      optionsStart = questionDuration + seconds(timing.questionHoldMs);
      thinkingStart = optionsStart + optionsDuration + seconds(timing.optionsHoldMs);
      if (questionAudio && questionAudio.duration) {
        clips.push({ id: `${question.id}_q`, role: "question", mediaId: questionAudio.id, start: 0, duration: questionAudio.duration, volume: voice });
        hasAudio = true;
      }
      if (optionsAudio && optionsAudio.duration) {
        clips.push({
          id: `${question.id}_o`,
          role: "options",
          mediaId: optionsAudio.id,
          start: optionsStart,
          duration: optionsAudio.duration,
          volume: voice
        });
        hasAudio = true;
      }
      if (!questionAudio?.["duration"]) {
        warnings.push(`\u0627\u0644\u0633\u0624\u0627\u0644 ${index + 1}: \u0644\u0627 \u064A\u0648\u062C\u062F \u0635\u0648\u062A \u0644\u0644\u0633\u0624\u0627\u0644 \u2014 \u0633\u064A\u064F\u0633\u062A\u062E\u062F\u0645 \u0648\u0642\u062A \u0642\u0631\u0627\u0621\u0629 \u0635\u0627\u0645\u062A.`);
      }
      if (!optionsAudio?.["duration"]) {
        warnings.push(`\u0627\u0644\u0633\u0624\u0627\u0644 ${index + 1}: \u0644\u0627 \u064A\u0648\u062C\u062F \u0635\u0648\u062A \u0644\u0644\u062E\u064A\u0627\u0631\u0627\u062A \u2014 \u0633\u064A\u064F\u0633\u062A\u062E\u062F\u0645 \u0648\u0642\u062A \u0635\u0627\u0645\u062A.`);
      }
    }
    const thinkSec = Math.max(1, Math.min(120, question.thinkSec || timing.defaultThinkSec));
    const revealStart = thinkingStart + thinkSec;
    const answerDuration = answerAudio?.duration ?? 0;
    if (answerAudio?.duration) hasAudio = true;
    const revealDuration = Math.max(seconds(question.revealHoldMs, 0.8), answerDuration + 0.25);
    if (answerAudio && answerAudio.duration) {
      clips.push({
        id: `${question.id}_a`,
        role: "answer",
        mediaId: answerAudio.id,
        start: revealStart,
        duration: answerAudio.duration,
        volume: voice
      });
    }
    const duration = revealStart + revealDuration + seconds(timing.nextHoldMs, 0);
    scenes.push({
      questionId: question.id,
      index,
      question,
      timings: {
        start: cursor,
        duration,
        optionsStart,
        thinkingStart,
        revealStart,
        revealDuration,
        end: cursor + duration
      },
      audio: clips
    });
    cursor += duration;
  });
  if (!hasAudio && project.questions.length > 0) {
    warnings.push("\u0644\u0627 \u062A\u0648\u062C\u062F \u0645\u0644\u0641\u0627\u062A \u0635\u0648\u062A\u064A\u0629 \u0645\u0631\u062A\u0628\u0637\u0629 \u0628\u0627\u0644\u0645\u0634\u0631\u0648\u0639. \u0633\u064A\u064F\u0635\u062F\u064E\u0651\u0631 \u0627\u0644\u0641\u064A\u062F\u064A\u0648 \u0628\u0635\u0648\u062A \u0635\u0627\u0645\u062A.");
  }
  return { scenes, totalDuration: cursor, hasAudio, warnings };
}
function sceneAt(timeline, time) {
  if (timeline.scenes.length === 0) return null;
  const clamped = Math.max(0, Math.min(timeline.totalDuration - 1e-3, time));
  for (const scene of timeline.scenes) {
    if (clamped >= scene.timings.start && clamped < scene.timings.end) {
      return { scene, local: clamped - scene.timings.start };
    }
  }
  const last2 = timeline.scenes[timeline.scenes.length - 1];
  return { scene: last2, local: Math.max(0, clamped - last2.timings.start) };
}
function phaseAt(scene, local) {
  if (local >= scene.timings.revealStart) return { key: "reveal", label: "\u0627\u0644\u0625\u062C\u0627\u0628\u0629 \u0627\u0644\u0635\u062D\u064A\u062D\u0629" };
  if (local >= scene.timings.thinkingStart) return { key: "thinking", label: "\u0648\u0642\u062A \u0627\u0644\u062A\u0641\u0643\u064A\u0631" };
  if (local >= scene.timings.optionsStart) return { key: "options", label: "\u0642\u0631\u0627\u0621\u0629 \u0627\u0644\u062E\u064A\u0627\u0631\u0627\u062A" };
  return { key: "question", label: "\u0642\u0631\u0627\u0621\u0629 \u0627\u0644\u0633\u0624\u0627\u0644" };
}

// src/lib/preflight.ts
function validateProject(project, options = {}) {
  const issues = [];
  const timing = project.timing;
  const requireAudio = options.requireAudio ?? timing.requireAudio;
  const available = options.availableMedia;
  if (!project.questions.length) {
    issues.push({ level: "error", message: "\u0644\u0627 \u064A\u0648\u062C\u062F \u0623\u064A \u0633\u0624\u0627\u0644 \u0641\u064A \u0627\u0644\u0645\u0634\u0631\u0648\u0639. \u0623\u0636\u0641 \u0633\u0624\u0627\u0644\u064B\u0627 \u0648\u0627\u062D\u062F\u064B\u0627 \u0639\u0644\u0649 \u0627\u0644\u0623\u0642\u0644 \u0642\u0628\u0644 \u0627\u0644\u062A\u0635\u062F\u064A\u0631." });
  }
  project.questions.forEach((question, index) => {
    const label = `\u0627\u0644\u0633\u0624\u0627\u0644 ${index + 1}`;
    if (!question.question.trim()) {
      issues.push({ level: "error", message: `${label}: \u0646\u0635 \u0627\u0644\u0633\u0624\u0627\u0644 \u0641\u0627\u0631\u063A.`, questionId: question.id, field: "question" });
    }
    if (!Array.isArray(question.options) || question.options.length !== 4) {
      issues.push({ level: "error", message: `${label}: \u064A\u062C\u0628 \u062A\u0648\u0641\u064A\u0631 \u0623\u0631\u0628\u0639\u0629 \u062E\u064A\u0627\u0631\u0627\u062A \u0628\u0627\u0644\u0636\u0628\u0637.`, questionId: question.id, field: "options" });
    } else {
      question.options.forEach((option, optionIndex) => {
        if (!option.trim()) {
          issues.push({
            level: "error",
            message: `${label}: \u0627\u0644\u062E\u064A\u0627\u0631 ${optionIndex + 1} \u0641\u0627\u0631\u063A.`,
            questionId: question.id,
            field: `option-${optionIndex}`
          });
        }
      });
    }
    if (!Number.isInteger(question.correct) || question.correct < 0 || question.correct > 3) {
      issues.push({
        level: "error",
        message: `${label}: \u0644\u0645 \u062A\u064F\u062D\u062F\u064E\u0651\u062F \u0625\u062C\u0627\u0628\u0629 \u0635\u062D\u064A\u062D\u0629 \u0648\u0627\u062D\u062F\u0629. \u062D\u062F\u0651\u062F \u0627\u0644\u062E\u064A\u0627\u0631 \u0627\u0644\u0635\u062D\u064A\u062D.`,
        questionId: question.id,
        field: "correct"
      });
    }
    if (!Number.isFinite(question.thinkSec) || question.thinkSec < 1) {
      issues.push({
        level: "warning",
        message: `${label}: \u0645\u062F\u0629 \u0627\u0644\u062A\u0641\u0643\u064A\u0631 \u0623\u0642\u0644 \u0645\u0646 \u062B\u0627\u0646\u064A\u0629\u060C \u0633\u064A\u064F\u0639\u062A\u0645\u062F \u062D\u062F \u0623\u062F\u0646\u0649 \u062B\u0627\u0646\u064A\u0629 \u0648\u0627\u062D\u062F\u0629.`,
        questionId: question.id,
        field: "thinkSec"
      });
    }
    if (timing.audioMode === "combined") {
      if (!question.combinedAudioId) {
        issues.push({
          level: requireAudio ? "error" : "warning",
          message: `${label}: \u0648\u0636\u0639 \xAB\u0645\u0644\u0641 \u0648\u0627\u062D\u062F\xBB \u0645\u062E\u062A\u0627\u0631 \u0644\u0643\u0646 \u0644\u0627 \u064A\u0648\u062C\u062F \u0645\u0644\u0641 \u0635\u0648\u062A \u0645\u0648\u062D\u0651\u062F. \u0633\u064A\u064F\u0633\u062A\u062E\u062F\u0645 \u0648\u0642\u062A \u0635\u0627\u0645\u062A.`,
          questionId: question.id,
          field: "combinedAudio"
        });
      }
    } else if (requireAudio && (!question.questionAudioId || !question.optionsAudioId)) {
      issues.push({
        level: "error",
        message: `${label}: \u0645\u0644\u0641 \u0635\u0648\u062A \u0627\u0644\u0633\u0624\u0627\u0644 \u0648\u0645\u0644\u0641 \u0635\u0648\u062A \u0627\u0644\u062E\u064A\u0627\u0631\u0627\u062A \u0645\u0637\u0644\u0648\u0628\u0627\u0646 \u0648\u0641\u0642 \u0625\u0639\u062F\u0627\u062F\u0627\u062A\u0643 \u0627\u0644\u062D\u0627\u0644\u064A\u0629.`,
        questionId: question.id,
        field: "audio-required"
      });
    } else if (!question.questionAudioId && !question.optionsAudioId) {
      issues.push({
        level: "warning",
        message: `${label}: \u0644\u0627 \u064A\u0648\u062C\u062F \u0635\u0648\u062A \u0644\u0644\u0633\u0624\u0627\u0644 \u0623\u0648 \u0627\u0644\u062E\u064A\u0627\u0631\u0627\u062A. \u0633\u064A\u064F\u0633\u062A\u062E\u062F\u0645 \u0648\u0642\u062A \u0642\u0631\u0627\u0621\u0629 \u0635\u0627\u0645\u062A \u0648\u0641\u0642 \u0627\u0644\u0625\u0639\u062F\u0627\u062F\u0627\u062A.`,
        questionId: question.id,
        field: "audio"
      });
    }
    const checks = [
      [question.questionAudioId, "\u0635\u0648\u062A \u0627\u0644\u0633\u0624\u0627\u0644"],
      [question.optionsAudioId, "\u0635\u0648\u062A \u0627\u0644\u062E\u064A\u0627\u0631\u0627\u062A"],
      [question.combinedAudioId, "\u0627\u0644\u0635\u0648\u062A \u0627\u0644\u0645\u0648\u062D\u0651\u062F"],
      [question.answerAudioId, "\u0635\u0648\u062A \u0627\u0644\u0625\u062C\u0627\u0628\u0629"],
      [question.imageId, "\u0635\u0648\u0631\u0629 \u0627\u0644\u0633\u0624\u0627\u0644"]
    ];
    for (const [id, role] of checks) {
      if (!id) continue;
      if (!project.media[id]) {
        issues.push({
          level: "error",
          message: `${label}: ${role} \u0645\u0631\u062A\u0628\u0637 \u0628\u0627\u0644\u0645\u0634\u0631\u0648\u0639 \u0644\u0643\u0646 \u0628\u064A\u0627\u0646\u0627\u062A\u0647 \u0645\u0641\u0642\u0648\u062F\u0629. \u0623\u0639\u062F \u0631\u0641\u0639 \u0627\u0644\u0645\u0644\u0641.`,
          questionId: question.id
        });
      } else if (available && !available.has(id)) {
        issues.push({
          level: "error",
          message: `${label}: ${role} (\xAB${project.media[id].name}\xBB) \u063A\u064A\u0631 \u0645\u062A\u0627\u062D \u0641\u064A \u0627\u0644\u062A\u062E\u0632\u064A\u0646 \u0627\u0644\u0645\u062D\u0644\u064A. \u0623\u0639\u062F \u0631\u0641\u0639\u0647 \u0623\u0648 \u0627\u0633\u062A\u0648\u0631\u062F \u0627\u0644\u0645\u0634\u0631\u0648\u0639 \u0643\u0627\u0645\u0644\u064B\u0627.`,
          questionId: question.id
        });
      }
    }
  });
  for (const [id, role] of [
    [project.timing.backgroundMusicId, "\u0627\u0644\u0645\u0648\u0633\u064A\u0642\u0649 \u0627\u0644\u062E\u0644\u0641\u064A\u0629"],
    [project.design.background.imageId, "\u062E\u0644\u0641\u064A\u0629 \u0627\u0644\u062A\u0635\u0645\u064A\u0645"],
    [project.design.brand.logoId, "\u0627\u0644\u0634\u0639\u0627\u0631"]
  ]) {
    if (!id) continue;
    if (!project.media[id]) {
      issues.push({ level: "warning", message: `${role}: \u0627\u0644\u0628\u064A\u0627\u0646\u0627\u062A \u0645\u0641\u0642\u0648\u062F\u0629 \u0645\u0646 \u0627\u0644\u0645\u0634\u0631\u0648\u0639 \u0648\u0633\u064A\u062A\u0645 \u062A\u062C\u0627\u0647\u0644\u0647\u0627.` });
    } else if (available && !available.has(id)) {
      issues.push({ level: "warning", message: `${role}: \u0627\u0644\u0645\u0644\u0641 \xAB${project.media[id].name}\xBB \u0644\u0645 \u064A\u0639\u062F \u0645\u062A\u0627\u062D\u064B\u0627 \u0648\u0633\u064A\u062A\u0645 \u062A\u062C\u0627\u0647\u0644\u0647.` });
    }
  }
  const width = project.exportSettings.width;
  const height = project.exportSettings.height;
  if (!Number.isFinite(width) || !Number.isFinite(height) || width < 256 || height < 256) {
    issues.push({ level: "error", message: "\u0623\u0628\u0639\u0627\u062F \u0627\u0644\u0641\u064A\u062F\u064A\u0648 \u063A\u064A\u0631 \u0635\u0627\u0644\u062D\u0629. \u0627\u0644\u062D\u062F \u0627\u0644\u0623\u062F\u0646\u0649 256 \u0628\u0643\u0633\u0644 \u0644\u0643\u0644 \u0628\u064F\u0639\u062F." });
  } else if (width % 2 !== 0 || height % 2 !== 0) {
    issues.push({ level: "error", message: "\u064A\u062C\u0628 \u0623\u0646 \u062A\u0643\u0648\u0646 \u0623\u0628\u0639\u0627\u062F \u0627\u0644\u0641\u064A\u062F\u064A\u0648 \u0623\u0631\u0642\u0627\u0645\u064B\u0627 \u0632\u0648\u062C\u064A\u0629 \u0644\u062A\u0631\u0645\u064A\u0632 H.264. \u0639\u062F\u0651\u0644 \u0627\u0644\u0639\u0631\u0636 \u0623\u0648 \u0627\u0644\u0627\u0631\u062A\u0641\u0627\u0639." });
  }
  if (width > 3840 || height > 3840) {
    issues.push({ level: "warning", message: "\u0627\u0644\u0623\u0628\u0639\u0627\u062F \u0643\u0628\u064A\u0631\u0629 \u062C\u062F\u064B\u0627 \u0648\u0642\u062F \u062A\u0641\u0634\u0644 \u0639\u0644\u0649 \u0627\u0644\u0647\u0648\u0627\u062A\u0641. \u064A\u064F\u0646\u0635\u062D \u0628\u0623\u0628\u0639\u0627\u062F 1080p \u0643\u062D\u062F \u0623\u0642\u0635\u0649." });
  }
  if (![24, 25, 30].includes(project.exportSettings.fps)) {
    issues.push({ level: "error", message: "\u0645\u0639\u062F\u0644 \u0627\u0644\u0625\u0637\u0627\u0631\u0627\u062A \u063A\u064A\u0631 \u0645\u062F\u0639\u0648\u0645. \u0627\u062E\u062A\u0631 24 \u0623\u0648 25 \u0623\u0648 30 \u0625\u0637\u0627\u0631\u064B\u0627 \u0641\u064A \u0627\u0644\u062B\u0627\u0646\u064A\u0629." });
  }
  const timeline = buildTimeline(project);
  if (timeline.totalDuration > 180) {
    issues.push({
      level: "warning",
      message: `\u0645\u062F\u0629 \u0627\u0644\u0641\u064A\u062F\u064A\u0648 ${Math.round(timeline.totalDuration)} \u062B\u0627\u0646\u064A\u0629. \u0642\u062F \u062A\u0633\u062A\u0647\u0644\u0643 \u0627\u0644\u0630\u0627\u0643\u0631\u0629 \u0639\u0644\u0649 \u0627\u0644\u0647\u0627\u062A\u0641\u061B \u0635\u062F\u0651\u0631 \u0639\u0644\u0649 \u062F\u0641\u0639\u0627\u062A \u0623\u0648 \u0639\u0644\u0649 \u0627\u0644\u0643\u0645\u0628\u064A\u0648\u062A\u0631.`
    });
  }
  if (timeline.totalDuration > 900) {
    issues.push({ level: "error", message: "\u062A\u062C\u0627\u0648\u0632\u062A \u0645\u062F\u0629 \u0627\u0644\u0641\u064A\u062F\u064A\u0648 15 \u062F\u0642\u064A\u0642\u0629\u060C \u0648\u0647\u064A \u062A\u062A\u062C\u0627\u0648\u0632 \u062D\u062F \u0627\u0644\u0623\u0645\u0627\u0646 \u0644\u0647\u0630\u0647 \u0627\u0644\u0646\u0633\u062E\u0629 \u0627\u0644\u0645\u062D\u0644\u064A\u0629." });
  }
  if (timeline.totalDuration < 1) {
    issues.push({ level: "warning", message: "\u0645\u062F\u0629 \u0627\u0644\u0641\u064A\u062F\u064A\u0648 \u0623\u0642\u0644 \u0645\u0646 \u062B\u0627\u0646\u064A\u0629 \u0648\u0627\u062D\u062F\u0629. \u0631\u0627\u062C\u0639 \u0625\u0639\u062F\u0627\u062F\u0627\u062A \u0627\u0644\u062A\u0648\u0642\u064A\u062A." });
  }
  return issues;
}

// src/lib/mp4validate.ts
var ascii2 = (view2, start, length) => {
  let out = "";
  for (let i = 0; i < length; i++) out += String.fromCharCode(view2.getUint8(start + i));
  return out;
};
function boxes(view2, start, end) {
  const result = [];
  let offset = start;
  while (offset + 8 <= end) {
    let size = view2.getUint32(offset);
    const type = ascii2(view2, offset + 4, 4);
    if (!/^[\x20-\x7e]{4}$/.test(type)) break;
    let header = 8;
    if (size === 1) {
      if (offset + 16 > end) break;
      const high = view2.getUint32(offset + 8);
      const low = view2.getUint32(offset + 12);
      size = high * 2 ** 32 + low;
      header = 16;
    }
    if (size === 0) size = end - offset;
    if (size < header || offset + size > end) {
      result.push({ type, start: offset, size: end - offset, contentStart: offset + header, contentEnd: end });
      break;
    }
    result.push({ type, start: offset, size, contentStart: offset + header, contentEnd: offset + size });
    offset += size;
  }
  return result;
}
var Mp4ValidationError = class extends Error {
  checks;
  constructor(message, checks) {
    super(message);
    this.name = "Mp4ValidationError";
    this.checks = checks;
  }
};
function inspectMp4(buffer) {
  const view2 = new DataView(buffer);
  const top = boxes(view2, 0, buffer.byteLength);
  const types = top.map((box2) => box2.type);
  const ftyp2 = top.find((box2) => box2.type === "ftyp");
  const brand = ftyp2 && ftyp2.contentEnd >= ftyp2.contentStart + 4 ? ascii2(view2, ftyp2.contentStart, 4) : null;
  const moov2 = top.find((box2) => box2.type === "moov");
  const mdat2 = top.find((box2) => box2.type === "mdat");
  let hasVideoTrack = false;
  let hasAudioTrack = false;
  let videoCodec = null;
  let audioCodec = null;
  let duration = 0;
  if (moov2) {
    const moovChildren = boxes(view2, moov2.contentStart, moov2.contentEnd);
    const mvhd2 = moovChildren.find((box2) => box2.type === "mvhd");
    if (mvhd2) {
      const version = view2.getUint8(mvhd2.contentStart);
      if (version === 1) {
        const timescale = view2.getUint32(mvhd2.contentStart + 20);
        const units = Number(view2.getBigUint64(mvhd2.contentStart + 24));
        duration = timescale ? units / timescale : 0;
      } else {
        const timescale = view2.getUint32(mvhd2.contentStart + 12);
        const units = view2.getUint32(mvhd2.contentStart + 16);
        duration = timescale ? units / timescale : 0;
      }
    }
    for (const trak2 of moovChildren.filter((box2) => box2.type === "trak")) {
      const trakChildren = boxes(view2, trak2.contentStart, trak2.contentEnd);
      const mdia2 = trakChildren.find((box2) => box2.type === "mdia");
      if (!mdia2) continue;
      const mdiaChildren = boxes(view2, mdia2.contentStart, mdia2.contentEnd);
      const hdlr2 = mdiaChildren.find((box2) => box2.type === "hdlr");
      const handler = hdlr2 ? ascii2(view2, hdlr2.contentStart + 8, 4) : "";
      const minf2 = mdiaChildren.find((box2) => box2.type === "minf");
      let codec = null;
      if (minf2) {
        const stbl2 = boxes(view2, minf2.contentStart, minf2.contentEnd).find((box2) => box2.type === "stbl");
        if (stbl2) {
          const stsd2 = boxes(view2, stbl2.contentStart, stbl2.contentEnd).find((box2) => box2.type === "stsd");
          if (stsd2) {
            const entries = boxes(view2, stsd2.contentStart + 8, stsd2.contentEnd);
            codec = entries[0]?.type ?? null;
          }
        }
      }
      if (handler === "vide" || codec === "avc1" || codec === "hvc1") {
        hasVideoTrack = true;
        videoCodec = codec ?? "unknown";
      }
      if (handler === "soun" || codec === "mp4a" || codec === "Opus") {
        hasAudioTrack = true;
        audioCodec = codec ?? "unknown";
      }
    }
  }
  const moovIndex = top.findIndex((box2) => box2.type === "moov");
  const mdatIndex = top.findIndex((box2) => box2.type === "mdat");
  return {
    size: buffer.byteLength,
    boxes: types,
    brand,
    hasMoov: Boolean(moov2),
    hasMdat: Boolean(mdat2),
    hasVideoTrack,
    hasAudioTrack,
    videoCodec,
    audioCodec,
    duration,
    fastStart: moovIndex >= 0 && mdatIndex >= 0 && moovIndex < mdatIndex
  };
}
async function validateMp4Blob(blob, expected) {
  const checks = [];
  if (!blob || blob.size === 0) {
    checks.push({ key: "size", label: "\u062D\u062C\u0645 \u0627\u0644\u0645\u0644\u0641", status: "fail", detail: "\u0627\u0644\u0645\u0644\u0641 \u0627\u0644\u0646\u0627\u062A\u062C \u0641\u0627\u0631\u063A." });
    throw new Mp4ValidationError("\u0641\u0634\u0644 \u0627\u0644\u062A\u062D\u0642\u0642: \u0627\u0644\u0645\u0644\u0641 \u0627\u0644\u0646\u0627\u062A\u062C \u0641\u0627\u0631\u063A.", checks);
  }
  const buffer = await blob.arrayBuffer();
  checks.push({ key: "size", label: "\u062D\u062C\u0645 \u0627\u0644\u0645\u0644\u0641", status: "pass", detail: `${(blob.size / 1024 / 1024).toFixed(2)} \u0645\u064A\u062C\u0627\u0628\u0627\u064A\u062A` });
  checks.push({
    key: "magic",
    label: "\u062A\u0648\u0642\u064A\u0639 MP4",
    status: /video\/mp4|video\/quicktime/.test(blob.type) || blob.size > 1024 ? "pass" : "fail",
    detail: `\u0646\u0648\u0639 \u0627\u0644\u0645\u0644\u0641: ${blob.type || "\u063A\u064A\u0631 \u0645\u0639\u0631\u0648\u0641"}`
  });
  let inspection;
  try {
    inspection = inspectMp4(buffer);
  } catch {
    checks.push({ key: "structure", label: "\u0628\u0646\u064A\u0629 \u0627\u0644\u0645\u0644\u0641", status: "fail", detail: "\u062A\u0639\u0630\u0651\u0631 \u0642\u0631\u0627\u0621\u0629 \u0628\u0646\u064A\u0629 MP4\u061B \u0627\u0644\u0645\u0644\u0641 \u063A\u064A\u0631 \u0635\u0627\u0644\u062D." });
    throw new Mp4ValidationError("\u0641\u0634\u0644 \u0627\u0644\u062A\u062D\u0642\u0642: \u062A\u0639\u0630\u0651\u0631\u062A \u0642\u0631\u0627\u0621\u0629 \u0628\u0646\u064A\u0629 \u0645\u0644\u0641 MP4 \u0627\u0644\u0646\u0627\u062A\u062C.", checks);
  }
  checks.push({
    key: "ftyp",
    label: "\u062A\u0631\u0648\u064A\u0633\u0629 ftyp",
    status: inspection.brand ? "pass" : "fail",
    detail: inspection.brand ? `\u0627\u0644\u0639\u0644\u0627\u0645\u0629: ${inspection.brand}` : "\u0644\u0627 \u062A\u0648\u062C\u062F \u062A\u0631\u0648\u064A\u0633\u0629 MP4."
  });
  checks.push({
    key: "moov",
    label: "\u0628\u064A\u0627\u0646\u0627\u062A moov",
    status: inspection.hasMoov && inspection.hasMdat ? "pass" : "fail",
    detail: inspection.hasMoov && inspection.hasMdat ? `\u0627\u0644\u0628\u0646\u064A\u0629: ${inspection.boxes.slice(0, 6).join(" \xB7 ")}` : "\u0623\u062D\u062F \u0635\u0646\u062F\u0648\u0642\u064A moov \u0623\u0648 mdat \u0645\u0641\u0642\u0648\u062F."
  });
  checks.push({
    key: "video-track",
    label: "\u0645\u0633\u0627\u0631 \u0627\u0644\u0641\u064A\u062F\u064A\u0648",
    status: inspection.hasVideoTrack ? "pass" : "fail",
    detail: inspection.videoCodec ? `\u0627\u0644\u062A\u0631\u0645\u064A\u0632: ${inspection.videoCodec}` : "\u0644\u0645 \u064A\u064F\u0639\u062B\u0631 \u0639\u0644\u0649 \u0645\u0633\u0627\u0631 \u0641\u064A\u062F\u064A\u0648."
  });
  checks.push({
    key: "audio-track",
    label: "\u0645\u0633\u0627\u0631 \u0627\u0644\u0635\u0648\u062A",
    status: inspection.hasAudioTrack ? "pass" : expected?.requireAudio ? "fail" : "warn",
    detail: inspection.audioCodec ? `\u0627\u0644\u062A\u0631\u0645\u064A\u0632: ${inspection.audioCodec}` : "\u0644\u0627 \u064A\u0648\u062C\u062F \u0645\u0633\u0627\u0631 \u0635\u0648\u062A\u064A \u062F\u0627\u062E\u0644 \u0627\u0644\u0645\u0644\u0641."
  });
  checks.push({
    key: "duration",
    label: "\u0627\u0644\u0645\u062F\u0629",
    status: inspection.duration > 0 ? "pass" : "fail",
    detail: inspection.duration > 0 ? `${inspection.duration.toFixed(2)} \u062B\u0627\u0646\u064A\u0629${expected ? ` (\u0627\u0644\u0645\u062A\u0648\u0642\u0639 ${expected.duration.toFixed(2)})` : ""}` : "\u0627\u0644\u0645\u062F\u0629 \u0635\u0641\u0631 \u0623\u0648 \u063A\u064A\u0631 \u0645\u0639\u0631\u0648\u0641\u0629."
  });
  if (expected && inspection.duration > 0 && Math.abs(inspection.duration - expected.duration) > Math.max(2, expected.duration * 0.15)) {
    checks.push({
      key: "duration-match",
      label: "\u0645\u0637\u0627\u0628\u0642\u0629 \u0627\u0644\u0645\u062F\u0629 \u0627\u0644\u0645\u062A\u0648\u0642\u0639\u0629",
      status: "warn",
      detail: `\u0627\u0644\u0645\u062F\u0629 \u0627\u0644\u0641\u0639\u0644\u064A\u0629 ${inspection.duration.toFixed(2)}\u062B \u0645\u0642\u0627\u0628\u0644 \u0627\u0644\u0645\u062A\u0648\u0642\u0639\u0629 ${expected.duration.toFixed(2)}\u062B.`
    });
  }
  if (typeof document !== "undefined" && typeof URL !== "undefined") {
    const url2 = URL.createObjectURL(blob);
    try {
      const video = document.createElement("video");
      video.preload = "metadata";
      video.src = url2;
      video.muted = true;
      const metadata = await new Promise((resolve, reject) => {
        const timer = window.setTimeout(() => reject(new Error("\u0627\u0646\u062A\u0647\u062A \u0645\u0647\u0644\u0629 \u0642\u0631\u0627\u0621\u0629 \u0628\u064A\u0627\u0646\u0627\u062A \u0627\u0644\u0641\u064A\u062F\u064A\u0648")), 12e3);
        video.onloadedmetadata = () => {
          window.clearTimeout(timer);
          resolve({ duration: video.duration, width: video.videoWidth, height: video.videoHeight });
        };
        video.onerror = () => {
          window.clearTimeout(timer);
          reject(new Error("\u0627\u0644\u0645\u062A\u0635\u0641\u062D \u0631\u0641\u0636 \u062A\u0634\u063A\u064A\u0644 \u0627\u0644\u0645\u0644\u0641 \u0627\u0644\u0646\u0627\u062A\u062C"));
        };
      });
      const dimsOk = !expected || metadata.width === expected.width && metadata.height === expected.height;
      checks.push({
        key: "playback",
        label: "\u0641\u062D\u0635 \u0627\u0644\u062A\u0634\u063A\u064A\u0644 \u0641\u064A \u0627\u0644\u0645\u062A\u0635\u0641\u062D",
        status: Number.isFinite(metadata.duration) && metadata.duration > 0 && dimsOk ? "pass" : "warn",
        detail: `\u0642\u0627\u0628\u0644 \u0644\u0644\u0642\u0631\u0627\u0621\u0629: ${metadata.width}\xD7${metadata.height} \xB7 ${Number.isFinite(metadata.duration) ? metadata.duration.toFixed(2) : "?"}\u062B`
      });
      if (expected && !dimsOk) {
        checks.push({
          key: "dimensions",
          label: "\u0645\u0637\u0627\u0628\u0642\u0629 \u0627\u0644\u0623\u0628\u0639\u0627\u062F",
          status: "warn",
          detail: `\u0627\u0644\u0623\u0628\u0639\u0627\u062F \u0627\u0644\u0641\u0639\u0644\u064A\u0629 ${metadata.width}\xD7${metadata.height} \u0645\u0642\u0627\u0628\u0644 ${expected.width}\xD7${expected.height}.`
        });
      }
    } catch {
      checks.push({
        key: "playback",
        label: "\u0641\u062D\u0635 \u0627\u0644\u062A\u0634\u063A\u064A\u0644 \u0641\u064A \u0627\u0644\u0645\u062A\u0635\u0641\u062D",
        status: "warn",
        detail: "\u062A\u0639\u0630\u0651\u0631 \u0639\u0644\u0649 \u0627\u0644\u0645\u062A\u0635\u0641\u062D \u0642\u0631\u0627\u0621\u0629 \u0628\u064A\u0627\u0646\u0627\u062A \u0627\u0644\u062A\u0634\u063A\u064A\u0644 \u062A\u0644\u0642\u0627\u0626\u064A\u064B\u0627\u061B \u062A\u062D\u0642\u0642 \u0645\u0646 \u0628\u0646\u064A\u0629 \u0627\u0644\u0645\u0633\u0627\u0631\u0627\u062A \u0623\u0639\u0644\u0627\u0647 \u0648\u0646\u0632\u0651\u0644 \u0627\u0644\u0645\u0644\u0641 \u0648\u062C\u0631\u0651\u0628\u0647."
      });
    } finally {
      videoCleanup(url2);
    }
  }
  const failing = checks.filter((check2) => check2.status === "fail");
  if (failing.length) {
    throw new Mp4ValidationError(`\u0641\u0634\u0644 \u0627\u0644\u062A\u062D\u0642\u0642 \u0645\u0646 \u0627\u0644\u0645\u0644\u0641 \u0627\u0644\u0646\u0627\u062A\u062C: ${failing.map((check2) => check2.label).join("\u060C ")}`, checks);
  }
  return { checks, inspection };
}
function videoCleanup(url2) {
  try {
    URL.revokeObjectURL(url2);
  } catch {
  }
}

// src/data/defaults.ts
var uid = (prefix = "id") => `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
var ASPECT_PRESETS = {
  vertical: { width: 1080, height: 1920, label: "\u0639\u0645\u0648\u062F\u064A", hint: "TikTok \xB7 Shorts \xB7 Reels" },
  landscape: { width: 1920, height: 1080, label: "\u0623\u0641\u0642\u064A", hint: "YouTube \xB7 \u0627\u0644\u0639\u0631\u0648\u0636" },
  square: { width: 1080, height: 1080, label: "\u0645\u0631\u0628\u0639", hint: "Instagram \xB7 Feed" },
  custom: { width: 1080, height: 1350, label: "\u0645\u062E\u0635\u0635", hint: "\u0623\u0628\u0639\u0627\u062F \u062D\u0633\u0628 \u0627\u062E\u062A\u064A\u0627\u0631\u0643" }
};
var QUALITY_BITRATES = {
  economy: 3e6,
  standard: 6e6,
  high: 1e7
};
function defaultDesign() {
  return {
    presetName: "\u0627\u0644\u0630\u0647\u0628\u064A \u0627\u0644\u0644\u064A\u0644\u064A",
    background: {
      kind: "gradient",
      colorA: "#0b0d12",
      colorB: "#1b1710",
      angle: 155,
      imageId: null,
      overlay: 62,
      glow: true,
      grid: true
    },
    typography: {
      font: "Tajawal",
      questionSize: 64,
      optionSize: 36,
      questionWeight: 700,
      optionWeight: 500,
      lineHeight: 1.35,
      align: "center",
      questionColor: "#FFFFFF",
      optionColor: "#EDEDF2"
    },
    options: {
      gap: 18,
      radius: 22,
      padding: 22,
      fill: "#FFFFFF",
      fillOpacity: 6,
      borderColor: "#FFFFFF",
      borderWidth: 1,
      shadow: true,
      letters: "arabic",
      correctColor: "#35D68B",
      dimOpacity: 45,
      showCheck: true
    },
    timer: {
      visible: true,
      style: "ring",
      position: "bottom",
      x: 50,
      y: 89,
      size: 100,
      color: "#E4C87B",
      trackColor: "#2A2A30"
    },
    content: {
      x: 50,
      y: 47,
      width: 86,
      showCard: true,
      showQuestionNumber: true
    },
    brand: {
      show: true,
      text: "QUIZ STUDIO",
      logoId: null,
      opacity: 85,
      showProgress: true
    },
    motion: {
      entrance: "rise",
      reveal: "glow",
      transition: "fade",
      speed: 1
    }
  };
}
function defaultTiming() {
  return {
    audioMode: "separate",
    combinedSplit: 55,
    questionHoldMs: 350,
    optionsHoldMs: 400,
    questionSilentMs: 3e3,
    optionsSilentMs: 3200,
    nextHoldMs: 500,
    defaultThinkSec: 8,
    requireAudio: false,
    voiceVolume: 100,
    musicVolume: 12,
    sfxVolume: 70,
    backgroundMusicId: null,
    sfxEnabled: true,
    showOptionLetters: true
  };
}
function defaultExport(aspect = "vertical") {
  const preset = ASPECT_PRESETS[aspect];
  return {
    aspect,
    width: preset.width,
    height: preset.height,
    fps: 30,
    quality: "standard",
    videoBitrate: QUALITY_BITRATES.standard,
    audioBitrate: 128e3,
    filename: "quiz-studio-video"
  };
}
function newEmptyQuestion(thinkSec = 8) {
  return {
    id: uid("q"),
    question: "",
    options: ["", "", "", ""],
    correct: -1,
    questionAudioId: null,
    optionsAudioId: null,
    combinedAudioId: null,
    answerAudioId: null,
    imageId: null,
    thinkSec,
    revealHoldMs: 1800
  };
}
function createBlankProject(name, aspect = "vertical") {
  return {
    version: 1,
    id: uid("project"),
    name: name.trim() || "\u0645\u0634\u0631\u0648\u0639 \u0628\u062F\u0648\u0646 \u0639\u0646\u0648\u0627\u0646",
    description: "",
    createdAt: Date.now(),
    updatedAt: Date.now(),
    isSample: false,
    questions: [newEmptyQuestion()],
    design: defaultDesign(),
    timing: defaultTiming(),
    exportSettings: defaultExport(aspect),
    media: {},
    designPresets: [
      { id: uid("preset"), name: "\u0627\u0644\u0630\u0647\u0628\u064A \u0627\u0644\u0644\u064A\u0644\u064A", design: defaultDesign() }
    ]
  };
}
function normalizeProject(raw) {
  if (!raw || typeof raw !== "object") throw new Error("\u0645\u0644\u0641 \u0627\u0644\u0645\u0634\u0631\u0648\u0639 \u063A\u064A\u0631 \u0635\u0627\u0644\u062D");
  const p = raw;
  if (!Array.isArray(p.questions)) throw new Error("\u0645\u0644\u0641 \u0627\u0644\u0645\u0634\u0631\u0648\u0639 \u0644\u0627 \u064A\u062D\u062A\u0648\u064A \u0639\u0644\u0649 \u0642\u0627\u0626\u0645\u0629 \u0623\u0633\u0626\u0644\u0629 \u0635\u0627\u0644\u062D\u0629");
  if (p.questions.length === 0) throw new Error("\u0645\u0644\u0641 \u0627\u0644\u0645\u0634\u0631\u0648\u0639 \u0644\u0627 \u064A\u062D\u062A\u0648\u064A \u0639\u0644\u0649 \u0623\u0633\u0626\u0644\u0629");
  const base = createBlankProject(typeof p.name === "string" ? p.name : "\u0645\u0634\u0631\u0648\u0639 \u0645\u0633\u062A\u0648\u0631\u062F");
  const project = {
    ...base,
    ...p,
    version: 1,
    id: typeof p.id === "string" ? p.id : base.id,
    name: typeof p.name === "string" && p.name.trim() ? p.name : "\u0645\u0634\u0631\u0648\u0639 \u0645\u0633\u062A\u0648\u0631\u062F",
    createdAt: typeof p.createdAt === "number" ? p.createdAt : Date.now(),
    updatedAt: Date.now(),
    isSample: false,
    design: deepMerge(base.design, p.design ?? {}),
    timing: deepMerge(base.timing, p.timing ?? {}),
    exportSettings: deepMerge(base.exportSettings, p.exportSettings ?? {}),
    media: p.media && typeof p.media === "object" ? p.media : {},
    designPresets: Array.isArray(p.designPresets) ? p.designPresets : base.designPresets,
    questions: p.questions.filter((q) => q && typeof q === "object").map((q, index) => {
      const candidate = q;
      return {
        ...newEmptyQuestion(),
        ...candidate,
        id: typeof candidate.id === "string" ? candidate.id : uid(`q${index + 1}`),
        question: typeof candidate.question === "string" ? candidate.question : "",
        options: Array.isArray(candidate.options) && candidate.options.length === 4 ? candidate.options.map((o) => typeof o === "string" ? o : String(o ?? "")) : ["", "", "", ""],
        correct: typeof candidate.correct === "number" ? candidate.correct : -1,
        thinkSec: Number.isFinite(candidate.thinkSec) ? Number(candidate.thinkSec) : 8,
        revealHoldMs: Number.isFinite(candidate.revealHoldMs) ? Number(candidate.revealHoldMs) : 1800
      };
    })
  };
  return project;
}
function deepMerge(base, extra) {
  if (typeof base !== "object" || base === null || Array.isArray(base)) {
    return extra === void 0 ? base : extra;
  }
  if (typeof extra !== "object" || extra === null || Array.isArray(extra)) return base;
  const output = { ...base };
  for (const [key, value] of Object.entries(extra)) {
    if (key in output) output[key] = deepMerge(output[key], value);
  }
  return output;
}

// scripts/logic.test.ts
var StubVideoChunk = class {
  type;
  timestamp;
  duration;
  byteLength;
  data;
  constructor(init) {
    this.type = init.type;
    this.timestamp = init.timestamp;
    this.duration = init.duration;
    this.data = init.data;
    this.byteLength = init.data.byteLength;
  }
  copyTo(target) {
    target.set(this.data);
  }
};
var StubAudioChunk = class extends StubVideoChunk {
};
globalThis.EncodedVideoChunk = StubVideoChunk;
globalThis.EncodedAudioChunk = StubAudioChunk;
var passed = 0;
var results = [];
function check(name, fn) {
  return (async () => {
    try {
      await fn();
      passed++;
      results.push(`PASS  ${name}`);
    } catch (error) {
      results.push(`FAIL  ${name}: ${error instanceof Error ? error.message : String(error)}`);
      throw error;
    }
  })();
}
function media(id, kind, duration) {
  return { id, name: `${id}.mp3`, type: kind === "audio" ? "audio/mpeg" : "image/png", size: 1e3, kind, duration, createdAt: Date.now() };
}
function fixtureProject() {
  const project = createBlankProject("\u0627\u062E\u062A\u0628\u0627\u0631 \u0645\u0646\u0637\u0642 \u0627\u0644\u062A\u0648\u0642\u064A\u062A");
  project.questions = [
    {
      ...newEmptyQuestion(8),
      id: "q1",
      question: "\u0633\u0624\u0627\u0644 \u0639\u0631\u0628\u064A \u0623\u0648\u0644\u061F",
      options: ["\u0627\u0644\u0631\u064A\u0627\u0636", "\u062C\u062F\u0629", "\u0645\u0643\u0629", "\u0627\u0644\u062F\u0645\u0627\u0645"],
      correct: 0,
      questionAudioId: "aq1",
      optionsAudioId: "ao1"
    },
    {
      ...newEmptyQuestion(5),
      id: "q2",
      question: "\u0633\u0624\u0627\u0644 \u062B\u0627\u0646\u064D\u061F",
      options: ["\u0623", "\u0628", "\u062C", "\u062F"],
      correct: 2,
      questionAudioId: "aq2",
      optionsAudioId: "ao2"
    }
  ];
  project.media = {
    aq1: media("aq1", "audio", 5),
    ao1: media("ao1", "audio", 7),
    aq2: media("aq2", "audio", 2.5),
    ao2: media("ao2", "audio", 3.5)
  };
  project.timing = {
    ...project.timing,
    audioMode: "separate",
    questionHoldMs: 400,
    optionsHoldMs: 300,
    nextHoldMs: 500,
    voiceVolume: 80
  };
  project.questions[0].revealHoldMs = 2e3;
  project.questions[1].revealHoldMs = 1200;
  return project;
}
async function main() {
  await check("\u0627\u0644\u062A\u0648\u0642\u064A\u062A \u064A\u064F\u062D\u0633\u0628 \u0645\u0646 \u0627\u0644\u0645\u062F\u0629 \u0627\u0644\u0641\u0639\u0644\u064A\u0629 \u0644\u0644\u0635\u0648\u062A \u0643\u0645\u0627 \u0641\u064A \u0627\u0644\u0645\u0639\u0627\u062F\u0644\u0629 \u0627\u0644\u0645\u062A\u0648\u0642\u0639\u0629", () => {
    const timeline = buildTimeline(fixtureProject());
    assert.equal(timeline.scenes.length, 2);
    const first = timeline.scenes[0].timings;
    assert.equal(Number(first.optionsStart.toFixed(2)), 5.4, "\u0628\u062F\u0627\u064A\u0629 \u0627\u0644\u062E\u064A\u0627\u0631\u0627\u062A = 5 + 0.4");
    assert.equal(Number(first.thinkingStart.toFixed(2)), 12.7, "\u0628\u062F\u0627\u064A\u0629 \u0627\u0644\u062A\u0641\u0643\u064A\u0631 = 5.4 + 7 + 0.3");
    assert.equal(Number(first.revealStart.toFixed(2)), 20.7, "\u0643\u0634\u0641 \u0627\u0644\u0625\u062C\u0627\u0628\u0629 = 12.7 + 8");
    assert.equal(Number(first.duration.toFixed(2)), 23.2, "\u0646\u0647\u0627\u064A\u0629 \u0627\u0644\u0645\u0634\u0647\u062F = 20.7 + 2 + 0.5");
    const second = timeline.scenes[1].timings;
    assert.equal(Number(second.start.toFixed(2)), 23.2, "\u064A\u0628\u062F\u0623 \u0627\u0644\u0645\u0634\u0647\u062F \u0627\u0644\u062B\u0627\u0646\u064A \u0628\u0639\u062F \u0627\u0644\u0623\u0648\u0644 \u0645\u0628\u0627\u0634\u0631\u0629");
    assert.equal(Number(timeline.totalDuration.toFixed(2)), 36.6);
    assert.equal(timeline.scenes[0].audio[1].start, 5.4, "\u0635\u0648\u062A \u0627\u0644\u062E\u064A\u0627\u0631\u0627\u062A \u064A\u0628\u062F\u0623 \u0645\u0639 \u0638\u0647\u0648\u0631\u0647\u0627");
    assert.equal(timeline.scenes[0].audio[0].volume, 0.8, "\u0645\u0633\u062A\u0648\u0649 \u0627\u0644\u0635\u0648\u062A \u064A\u062D\u062A\u0631\u0645 \u0627\u0644\u0625\u0639\u062F\u0627\u062F");
  });
  await check("\u0645\u062F\u0629 \u0635\u0627\u0645\u062A\u0629 \u0628\u062F\u064A\u0644\u0629 \u0639\u0646\u062F \u063A\u064A\u0627\u0628 \u0627\u0644\u0635\u0648\u062A", () => {
    const project = fixtureProject();
    project.questions = [{ ...project.questions[0], questionAudioId: null, optionsAudioId: null }];
    project.timing.questionSilentMs = 3e3;
    project.timing.optionsSilentMs = 3200;
    const scene = buildTimeline(project).scenes[0];
    assert.equal(Number(scene.timings.optionsStart.toFixed(2)), 3.4);
    assert.equal(Number(scene.timings.thinkingStart.toFixed(2)), 6.9);
  });
  await check("\u0648\u0636\u0639 \u0627\u0644\u0645\u0644\u0641 \u0627\u0644\u0645\u0648\u062D\u0651\u062F \u064A\u0642\u0633\u0651\u0645 \u0627\u0644\u0638\u0647\u0648\u0631 \u062D\u0633\u0628 \u0627\u0644\u0646\u0633\u0628\u0629", () => {
    const project = fixtureProject();
    project.timing.audioMode = "combined";
    project.timing.combinedSplit = 55;
    project.timing.optionsHoldMs = 300;
    project.questions = [{ ...project.questions[0], combinedAudioId: "ac1" }];
    project.media.ac1 = media("ac1", "audio", 10);
    const scene = buildTimeline(project).scenes[0];
    assert.equal(Number(scene.timings.optionsStart.toFixed(2)), 5.5);
    assert.equal(Number(scene.timings.thinkingStart.toFixed(2)), 10.3);
    assert.equal(scene.audio.length, 1);
  });
  await check("\u0627\u0644\u0645\u0624\u0642\u062A \u0648\u0645\u0631\u062D\u0644\u0629 \u0627\u0644\u0643\u0634\u0641 \u0645\u0646\u0637\u0642\u064A\u0627\u0646", () => {
    const project = fixtureProject();
    const scene = buildTimeline(project).scenes[0];
    assert.equal(phaseAt(scene, scene.timings.thinkingStart + 0.1).label, "\u0648\u0642\u062A \u0627\u0644\u062A\u0641\u0643\u064A\u0631");
    assert.equal(phaseAt(scene, scene.timings.revealStart + 0.1).label, "\u0627\u0644\u0625\u062C\u0627\u0628\u0629 \u0627\u0644\u0635\u062D\u064A\u062D\u0629");
    const at = sceneAt(buildTimeline(project), scene.timings.start + 0.2);
    assert.equal(at?.scene.questionId, "q1");
  });
  await check("\u0627\u0644\u0641\u062D\u0635 \u0627\u0644\u0645\u0633\u0628\u0642 \u064A\u0645\u0646\u0639 \u0627\u0644\u0633\u0624\u0627\u0644 \u0627\u0644\u0646\u0627\u0642\u0635 \u0648\u0627\u0644\u0625\u062C\u0627\u0628\u0629 \u0627\u0644\u063A\u0627\u0626\u0628\u0629", () => {
    const project = fixtureProject();
    project.questions[1].options[2] = "";
    project.questions[1].correct = -1;
    const issues = validateProject(project, { availableMedia: new Set(Object.keys(project.media)) });
    assert.ok(issues.some((issue) => issue.level === "error" && issue.message.includes("\u0627\u0644\u062E\u064A\u0627\u0631 3")));
    assert.ok(issues.some((issue) => issue.level === "error" && issue.message.includes("\u0625\u062C\u0627\u0628\u0629 \u0635\u062D\u064A\u062D\u0629")));
  });
  await check("\u0627\u0644\u0641\u062D\u0635 \u0627\u0644\u0645\u0633\u0628\u0642 \u064A\u0643\u062A\u0634\u0641 \u063A\u064A\u0627\u0628 \u0627\u0644\u0645\u0644\u0641 \u0645\u0646 \u0627\u0644\u062A\u062E\u0632\u064A\u0646", () => {
    const project = fixtureProject();
    const issues = validateProject(project, { availableMedia: /* @__PURE__ */ new Set(["aq2", "ao2"]) });
    assert.ok(issues.some((issue) => issue.level === "error" && issue.message.includes("\u063A\u064A\u0631 \u0645\u062A\u0627\u062D")));
  });
  await check("\u0627\u0633\u062A\u064A\u0631\u0627\u062F \u0645\u0634\u0631\u0648\u0639 \u063A\u064A\u0631 \u0635\u0627\u0644\u062D \u064A\u064F\u0631\u0641\u0636", () => {
    assert.throws(() => normalizeProject({ name: "\u0628\u0644\u0627 \u0623\u0633\u0626\u0644\u0629" }), /أسئلة/);
    assert.throws(() => normalizeProject(null), /غير صالح/);
  });
  await check("\u0628\u0646\u064A\u0629 \u0645\u0634\u0631\u0648\u0639 \u0645\u0633\u062A\u0648\u0631\u062F \u062F\u0645\u062C\u0647 \u0645\u0639 \u0627\u0644\u0625\u0639\u062F\u0627\u062F\u0627\u062A \u0627\u0644\u0627\u0641\u062A\u0631\u0627\u0636\u064A\u0629", () => {
    const source = fixtureProject();
    const raw = JSON.parse(JSON.stringify(source));
    delete raw.design.background.glow;
    const imported = normalizeProject(raw);
    assert.equal(imported.questions.length, 2);
    assert.equal(imported.design.background.glow, true);
    assert.equal(imported.questions[0].correct, 0);
  });
  await check("\u0642\u0627\u0631\u0626 MP4 \u064A\u0645\u064A\u0632 \u0627\u0644\u0645\u0633\u0627\u0631\u0627\u062A \u0648\u064A\u0642\u0631\u0623 \u0627\u0644\u0628\u0646\u064A\u0629", async () => {
    const target = new ArrayBufferTarget();
    const muxer = new Muxer({
      target,
      video: { codec: "avc", width: 720, height: 1280, frameRate: 25 },
      audio: { codec: "aac", numberOfChannels: 2, sampleRate: 48e3 },
      fastStart: "in-memory"
    });
    const avcC2 = new Uint8Array([1, 66, 0, 30, 255, 225, 0, 4, 103, 66, 0, 30, 1, 0, 4, 104, 206, 60, 128]);
    for (let i = 0; i < 10; i++) {
      const fakeVideoChunk = new StubVideoChunk({
        type: i === 0 ? "key" : "delta",
        timestamp: i * 4e4,
        duration: 4e4,
        data: new Uint8Array([0, 0, 0, 2, 9, 16])
      });
      muxer.addVideoChunk(fakeVideoChunk, {
        decoderConfig: { codec: "avc1.42E01E", description: avcC2 }
      });
    }
    for (let i = 0; i < 20; i++) {
      const fakeAudio = new StubAudioChunk({
        type: "key",
        timestamp: i * 2e4,
        duration: 2e4,
        data: new Uint8Array(512)
      });
      muxer.addAudioChunk(fakeAudio, {
        decoderConfig: { codec: "mp4a.40.2", sampleRate: 48e3, numberOfChannels: 2 }
      });
    }
    muxer.finalize();
    const inspection = inspectMp4(target.buffer);
    assert.equal(inspection.hasMoov, true);
    assert.equal(inspection.hasMdat, true);
    assert.equal(inspection.hasVideoTrack, true);
    assert.equal(inspection.hasAudioTrack, true);
    assert.equal(inspection.videoCodec, "avc1");
    assert.equal(inspection.audioCodec, "mp4a");
    const blob = new Blob([target.buffer], { type: "video/mp4" });
    const validation = await validateMp4Blob(blob, { duration: 0.4, width: 720, height: 1280, requireAudio: true });
    assert.ok(validation.checks.some((item) => item.key === "video-track" && item.status === "pass"));
    assert.ok(validation.checks.some((item) => item.key === "audio-track" && item.status === "pass"));
    assert.ok(!validation.checks.some((item) => item.key === "duration" && item.status === "fail"));
  });
  console.log(results.join("\n"));
  console.log(`
${passed}/${results.length} checks passed`);
}
main().catch(() => {
  console.log(results.join("\n"));
  process.exit(1);
});
