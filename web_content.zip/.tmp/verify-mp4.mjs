// scripts/verify-mp4.ts
import fs from "node:fs";

// src/lib/mp4validate.ts
var ascii = (view, start, length) => {
  let out = "";
  for (let i = 0; i < length; i++) out += String.fromCharCode(view.getUint8(start + i));
  return out;
};
function boxes(view, start, end) {
  const result = [];
  let offset = start;
  while (offset + 8 <= end) {
    let size = view.getUint32(offset);
    const type = ascii(view, offset + 4, 4);
    if (!/^[\x20-\x7e]{4}$/.test(type)) break;
    let header = 8;
    if (size === 1) {
      if (offset + 16 > end) break;
      const high = view.getUint32(offset + 8);
      const low = view.getUint32(offset + 12);
      size = high * 2 ** 32 + low;
      header = 16;
    }
    if (size === 0) size = end - offset;
    if (size < header || offset + size > end) {
      result.push({ type, start: offset, size: end - offset, contentStart: offset + header, contentEnd: end });
      break;
    }
    result.push({ type, start: offset, size, contentStart: offset + header, contentEnd: offset + size });
    offset += size;
  }
  return result;
}
function inspectMp4(buffer2) {
  const view = new DataView(buffer2);
  const top = boxes(view, 0, buffer2.byteLength);
  const types = top.map((box) => box.type);
  const ftyp = top.find((box) => box.type === "ftyp");
  const brand = ftyp && ftyp.contentEnd >= ftyp.contentStart + 4 ? ascii(view, ftyp.contentStart, 4) : null;
  const moov = top.find((box) => box.type === "moov");
  const mdat = top.find((box) => box.type === "mdat");
  let hasVideoTrack = false;
  let hasAudioTrack = false;
  let videoCodec = null;
  let audioCodec = null;
  let duration = 0;
  if (moov) {
    const moovChildren = boxes(view, moov.contentStart, moov.contentEnd);
    const mvhd = moovChildren.find((box) => box.type === "mvhd");
    if (mvhd) {
      const version = view.getUint8(mvhd.contentStart);
      if (version === 1) {
        const timescale = view.getUint32(mvhd.contentStart + 20);
        const units = Number(view.getBigUint64(mvhd.contentStart + 24));
        duration = timescale ? units / timescale : 0;
      } else {
        const timescale = view.getUint32(mvhd.contentStart + 12);
        const units = view.getUint32(mvhd.contentStart + 16);
        duration = timescale ? units / timescale : 0;
      }
    }
    for (const trak of moovChildren.filter((box) => box.type === "trak")) {
      const trakChildren = boxes(view, trak.contentStart, trak.contentEnd);
      const mdia = trakChildren.find((box) => box.type === "mdia");
      if (!mdia) continue;
      const mdiaChildren = boxes(view, mdia.contentStart, mdia.contentEnd);
      const hdlr = mdiaChildren.find((box) => box.type === "hdlr");
      const handler = hdlr ? ascii(view, hdlr.contentStart + 8, 4) : "";
      const minf = mdiaChildren.find((box) => box.type === "minf");
      let codec = null;
      if (minf) {
        const stbl = boxes(view, minf.contentStart, minf.contentEnd).find((box) => box.type === "stbl");
        if (stbl) {
          const stsd = boxes(view, stbl.contentStart, stbl.contentEnd).find((box) => box.type === "stsd");
          if (stsd) {
            const entries = boxes(view, stsd.contentStart + 8, stsd.contentEnd);
            codec = entries[0]?.type ?? null;
          }
        }
      }
      if (handler === "vide" || codec === "avc1" || codec === "hvc1") {
        hasVideoTrack = true;
        videoCodec = codec ?? "unknown";
      }
      if (handler === "soun" || codec === "mp4a" || codec === "Opus") {
        hasAudioTrack = true;
        audioCodec = codec ?? "unknown";
      }
    }
  }
  const moovIndex = top.findIndex((box) => box.type === "moov");
  const mdatIndex = top.findIndex((box) => box.type === "mdat");
  return {
    size: buffer2.byteLength,
    boxes: types,
    brand,
    hasMoov: Boolean(moov),
    hasMdat: Boolean(mdat),
    hasVideoTrack,
    hasAudioTrack,
    videoCodec,
    audioCodec,
    duration,
    fastStart: moovIndex >= 0 && mdatIndex >= 0 && moovIndex < mdatIndex
  };
}

// scripts/verify-mp4.ts
var file = process.argv[2] ?? "test-output/quiz-engine-test.mp4";
var buffer = fs.readFileSync(file);
var arrayBuffer = buffer.buffer.slice(buffer.byteOffset, buffer.byteOffset + buffer.byteLength);
var info = inspectMp4(arrayBuffer);
console.log(JSON.stringify({ file, bytes: buffer.length, ...info }, null, 2));
var ok = info.hasMoov && info.hasMdat && info.hasVideoTrack && info.hasAudioTrack && info.duration > 0 && info.videoCodec === "avc1";
console.log(ok ? "VERIFY_PASS" : "VERIFY_FAIL");
process.exit(ok ? 0 : 1);
