package com.starsup.demowallet;

import android.app.*;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.*;
import android.widget.*;
import android.text.InputType;
import org.json.*;
import java.text.*;
import java.util.*;

public class MainActivity extends Activity {
    final int navy = Color.rgb(7,27,51), teal = Color.rgb(22,184,166);
    final int ink = Color.rgb(27,42,58), muted = Color.rgb(112,128,144);
    android.content.SharedPreferences prefs;
    LinearLayout page, history;
    TextView balanceView, historyEmpty;
    boolean hidden = false;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("demo_wallet", MODE_PRIVATE);
        if (!prefs.contains("balance")) prefs.edit().putLong("balance", 25000000L).putString("pin","1234").apply();
        showPinGate();
    }
    void showPinGate() {
        EditText pin = new EditText(this);
        pin.setHint("Enter demo PIN (default 1234)");
        pin.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        new AlertDialog.Builder(this).setTitle("Demo Wallet access").setMessage("Local demo access only")
            .setView(pin).setCancelable(false)
            .setPositiveButton("Unlock", (d,w) -> {
                if (pin.getText().toString().equals(prefs.getString("pin","1234"))) render();
                else { toast("Incorrect demo PIN."); showPinGate(); }
            }).setNegativeButton("Exit", (d,w) -> finish()).show();
    }
    int dp(float v){ return (int)(v*getResources().getDisplayMetrics().density); }
    TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if(bold)t.setTypeface(null,Typeface.BOLD); return t;
    }
    GradientDrawable bg(int color, int radius) {
        GradientDrawable d=new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d;
    }
    LinearLayout column(){ LinearLayout l=new LinearLayout(this); l.setOrientation(1); return l; }
    LinearLayout row(){ LinearLayout l=new LinearLayout(this); l.setOrientation(0); l.setGravity(Gravity.CENTER_VERTICAL); return l; }
    void pad(View v,int a){v.setPadding(dp(a),dp(a),dp(a),dp(a));}
    void render() {
        ScrollView scroll=new ScrollView(this); scroll.setFillViewport(true);
        page=column(); page.setBackgroundColor(Color.rgb(246,249,252)); scroll.addView(page);
        LinearLayout header=column(); header.setBackground(bg(navy,0)); header.setPadding(dp(22),dp(24),dp(22),dp(26));
        TextView brand=text("DEMO WALLET",20,Color.WHITE,true); header.addView(brand);
        TextView tag=text("SIMULATION ONLY  •  NO REAL MONEY MOVES",10,Color.rgb(125,224,211),true);
        LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(-2,-2); tp.topMargin=dp(7); header.addView(tag,tp);
        TextView label=text("Available demo balance",13,Color.rgb(195,211,226),false);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-2,-2); lp.topMargin=dp(28); header.addView(label,lp);
        balanceView=text("",32,Color.WHITE,true); LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,-2); bp.topMargin=dp(5); header.addView(balanceView,bp);
        TextView eye=text("Tap balance to show / hide",11,Color.rgb(195,211,226),false);
        header.addView(eye); header.setOnClickListener(v->{hidden=!hidden; updateBalance();});
        page.addView(header); updateBalance();

        LinearLayout actions=column(); actions.setPadding(dp(18),dp(20),dp(18),dp(8));
        TextView actTitle=text("Quick actions",17,ink,true); actions.addView(actTitle);
        LinearLayout r1=row(); r1.setPadding(0,dp(12),0,dp(8));
        r1.addView(action("Send", "↗",()->transactionDialog("Transfer sent", "Recipient", -1)));
        r1.addView(action("Receive", "↙",()->transactionDialog("Money received", "Sender", 1)));
        LinearLayout r2=row();
        r2.addView(action("Add funds", "+",()->transactionDialog("Demo deposit", "Source", 1)));
        r2.addView(action("Withdraw", "−",()->transactionDialog("Demo withdrawal", "Destination", -1)));
        actions.addView(r1); actions.addView(r2); page.addView(actions);

        LinearLayout h=column(); h.setPadding(dp(20),dp(12),dp(20),dp(24));
        LinearLayout hr=row(); TextView ht=text("Recent transactions",17,ink,true); hr.addView(ht,new LinearLayout.LayoutParams(0,-2,1));
        TextView reset=text("Reset demo",12,teal,true); reset.setOnClickListener(v->confirmReset()); hr.addView(reset); h.addView(hr);
        history=column(); LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,-2); hp.topMargin=dp(12); h.addView(history,hp);
        page.addView(h); loadHistory();
        TextView footer=text("OFFLINE DEMO APP  •  Transactions are fictional and stored only on this phone.",10,muted,false);
        footer.setGravity(Gravity.CENTER); footer.setPadding(dp(18),dp(10),dp(18),dp(22)); page.addView(footer);
        setContentView(scroll);
    }
    void updateBalance(){ long b=prefs.getLong("balance",25000000L); balanceView.setText(hidden?"₦ ••••••••":naira(b)); }
    String naira(long kobo){return "₦"+String.format(Locale.US,"%,.2f",kobo/100.0);}
    View action(String title,String symbol,Runnable run){
        LinearLayout box=column(); box.setGravity(Gravity.CENTER); box.setBackground(bg(Color.WHITE,16));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(88),1); p.setMargins(dp(4),dp(3),dp(4),dp(3)); box.setLayoutParams(p);
        TextView ic=text(symbol,23,teal,true); ic.setGravity(Gravity.CENTER); box.addView(ic);
        TextView tx=text(title,13,ink,true); tx.setGravity(Gravity.CENTER); box.addView(tx);
        box.setOnClickListener(v->run.run()); return box;
    }
    void transactionDialog(String title,String party,int direction){
        LinearLayout form=column(); form.setPadding(dp(8),dp(4),dp(8),0);
        EditText amount=new EditText(this); amount.setHint("Amount in naira (e.g. 5000)");
        amount.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL); form.addView(amount);
        EditText name=new EditText(this); name.setHint(party+" name"); form.addView(name);
        EditText note=new EditText(this); note.setHint("Note (optional)"); form.addView(note);
        new AlertDialog.Builder(this).setTitle(title+" • DEMO").setView(form)
        .setNegativeButton("Cancel",null).setPositiveButton("Continue",(d,w)->{
            String raw=amount.getText().toString().trim(), who=name.getText().toString().trim();
            if(raw.isEmpty()||who.isEmpty()){toast("Enter an amount and a name.");return;}
            try{
                double val=Double.parseDouble(raw); if(val<=0||val>100000000){toast("Enter a valid amount.");return;}
                long k=Math.round(val*100); long bal=prefs.getLong("balance",25000000L);
                int sign=direction;
                if(sign<0 && k>bal){toast("Insufficient demo balance.");return;}
                prefs.edit().putLong("balance",bal+(sign*k)).apply();
                JSONObject item=new JSONObject(); item.put("title",title); item.put("party",who);
                item.put("note",note.getText().toString()); item.put("amount",k); item.put("direction",sign);
                item.put("date",new SimpleDateFormat("dd MMM yyyy, hh:mm a",Locale.getDefault()).format(new Date()));
                item.put("ref","DEMO"+(System.currentTimeMillis()%100000000));
                JSONArray arr; try{arr=new JSONArray(prefs.getString("history","[]"));}catch(Exception e){arr=new JSONArray();}
                arr.put(0,item); prefs.edit().putString("history",arr.toString()).apply();
                render(); receipt(item);
            }catch(Exception e){toast("Could not save this demo transaction.");}
        }).show();
    }
    void receipt(JSONObject o){
        String s="DEMO TRANSACTION RECEIPT\n\n"+o.optString("title")+"\nAmount: "+naira(o.optLong("amount"))+
        "\nName: "+o.optString("party")+"\nDate: "+o.optString("date")+"\nReference: "+o.optString("ref")+
        "\n\nNOT A BANK RECEIPT. NO REAL PAYMENT WAS MADE.";
        new AlertDialog.Builder(this).setTitle("Completed • DEMO ONLY").setMessage(s).setPositiveButton("Done",null).show();
    }
    void loadHistory(){
        history.removeAllViews(); JSONArray a;
        try{a=new JSONArray(prefs.getString("history","[]"));}catch(Exception e){a=new JSONArray();}
        if(a.length()==0){TextView empty=text("No demo transactions yet. Try a quick action above.",13,muted,false); empty.setPadding(0,dp(18),0,dp(18)); history.addView(empty); return;}
        for(int i=0;i<Math.min(a.length(),30);i++){
            JSONObject o=a.optJSONObject(i); if(o==null)continue;
            LinearLayout item=row(); item.setPadding(dp(12),dp(13),dp(12),dp(13)); item.setBackground(bg(Color.WHITE,12));
            LinearLayout left=column(); left.addView(text(o.optString("title"),14,ink,true));
            left.addView(text(o.optString("party")+"  •  "+o.optString("date"),10,muted,false));
            item.addView(left,new LinearLayout.LayoutParams(0,-2,1));
            boolean plus=o.optInt("direction")>0;
            TextView amount=text((plus?"+":"−")+naira(o.optLong("amount")),13,plus?Color.rgb(12,145,112):Color.rgb(197,75,75),true);
            item.addView(amount); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.bottomMargin=dp(7); history.addView(item,p);
            item.setOnClickListener(v->receipt(o));
        }
    }
    void confirmReset(){new AlertDialog.Builder(this).setTitle("Reset demo wallet?")
        .setMessage("This restores the sample balance to ₦250,000.00 and clears demo history.")
        .setNegativeButton("Cancel",null).setPositiveButton("Reset",(d,w)->{
            prefs.edit().putLong("balance",25000000L).putString("history","[]").apply(); hidden=false; render();
        }).show();}
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
}
