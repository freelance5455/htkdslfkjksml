# PalmPay-style Single Wallet Demo (Unofficial)

A single-account offline Android WebView demo. It is not affiliated with PalmPay and does not connect to real banks, payment rails, or accounts.

## Simulated transfer charges
- PalmPay currently advertises free transfers; this demo models a ₦0 provider transfer fee.
- A ₦50 stamp duty is simulated on outgoing electronic transfers of ₦10,000 and above.
- No stamp duty is added to incoming credits.
- VAT on transfer fees is ₦0 because the modeled provider transfer fee is ₦0.

Charges are shown separately in the demo receipt and transaction history. Confirm actual fees in the official PalmPay app before any real transaction.

Open `demo-wallet.html` in a browser, or build the Android project with Android Studio/Gradle.
