package com.zenmobile.browser

import android.annotation.SuppressLint
import android.app.Activity
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.ProgressBar

class MainActivity : Activity() {
    private lateinit var page: WebView
    private lateinit var shell: WebView
    private lateinit var progress: ProgressBar
    private var pageUrl: String = ""

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(28, 29, 35)
        window.navigationBarColor = Color.rgb(28, 29, 35)

        val root = FrameLayout(this)
        page = WebView(this).apply {
            setBackgroundColor(Color.TRANSPARENT)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.databaseEnabled = true
            settings.loadsImagesAutomatically = true
            settings.javaScriptCanOpenWindowsAutomatically = true
            settings.setSupportMultipleWindows(false)
            settings.mediaPlaybackRequiresUserGesture = true
            settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            settings.userAgentString = settings.userAgentString // Use the normal Android WebView UA.
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                    val uri = request.url
                    val scheme = uri.scheme?.lowercase()
                    if (scheme == "http" || scheme == "https") return false
                    // Do not silently send unknown/custom schemes to another app.
                    return true
                }
                override fun onPageStarted(view: WebView, url: String, favicon: android.graphics.Bitmap?) {
                    pageUrl = url
                    progress.visibility = View.VISIBLE
                    progress.progress = 20
                    updateShell(url, "")
                }
                override fun onPageFinished(view: WebView, url: String) {
                    pageUrl = url
                    progress.visibility = View.GONE
                    updateShell(url, view.title ?: "")
                }
            }
            webChromeClient = object : WebChromeClient() {
                override fun onProgressChanged(view: WebView, newProgress: Int) {
                    progress.progress = newProgress
                    progress.visibility = if (newProgress >= 100) View.GONE else View.VISIBLE
                }
                override fun onReceivedTitle(view: WebView, title: String?) { updateShell(pageUrl, title ?: "") }
            }
        }
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(page, true)
        root.addView(page, FrameLayout.LayoutParams(-1, -1))

        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progressTintList = android.content.res.ColorStateList.valueOf(Color.rgb(247,111,83))
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(Color.TRANSPARENT)
            elevation = 20f
        }
        val p = FrameLayout.LayoutParams(-1, dp(3), android.view.Gravity.TOP)
        root.addView(progress, p)

        shell = WebView(this).apply {
            setBackgroundColor(Color.TRANSPARENT)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = true
            settings.allowContentAccess = false
            addJavascriptInterface(NativeBridge(), "ZenNative")
            webViewClient = WebViewClient()
            loadUrl("file:///android_asset/index.html")
            elevation = 10f
        }
        root.addView(shell, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun updateShell(url: String, title: String) {
        if (!::shell.isInitialized || url.isBlank()) return
        val safeUrl = org.json.JSONObject.quote(url)
        val safeTitle = org.json.JSONObject.quote(title)
        shell.post { shell.evaluateJavascript("window.ZenPageChanged && window.ZenPageChanged($safeUrl,$safeTitle);", null) }
    }

    inner class NativeBridge {
        @android.webkit.JavascriptInterface
        fun openUrl(raw: String) {
            runOnUiThread {
                val uri = Uri.parse(raw)
                if (uri.scheme == "https" || uri.scheme == "http") {
                    pageUrl = raw
                    page.loadUrl(raw)
                }
            }
        }
        @android.webkit.JavascriptInterface
        fun reload() { runOnUiThread { if (pageUrl.isNotBlank()) page.reload() } }
    }

    override fun onBackPressed() {
        if (::page.isInitialized && page.canGoBack()) page.goBack()
        else if (::shell.isInitialized) shell.evaluateJavascript("window.ZenGoHome && window.ZenGoHome();", null)
        else super.onBackPressed()
    }

    override fun onPause() { if (::page.isInitialized) page.onPause(); if (::shell.isInitialized) shell.onPause(); super.onPause() }
    override fun onResume() { super.onResume(); if (::page.isInitialized) page.onResume(); if (::shell.isInitialized) shell.onResume() }
    override fun onDestroy() { if (::page.isInitialized) page.destroy(); if (::shell.isInitialized) shell.destroy(); super.onDestroy() }
}
