# Zen Mobile — Android WebView starter

This is a source project, not a prebuilt APK. It keeps the original Zen Mobile HTML home UI and uses a native Android WebView for actual website navigation, avoiding the iframe/new-tab failure path in the original HTML.

## Included
- Original-inspired Zen Mobile home screen, shortcuts, tab drawer, address field, progress line and shortcut editor.
- Zen Search UI using Brave Search as the current search backend (`https://search.brave.com/search`). Zen is the interface/brand here; this project does not claim to own or index a search engine.
- Website pages load in an Android WebView within the app. Common link navigation stays in the same WebView.
- JavaScript and DOM storage enabled for compatibility; HTTP-only navigation is rejected.

## Build
1. Install Android Studio and a compatible JDK (17 recommended).
2. Open this folder (`ZenAndroidProject`) in Android Studio.
3. Let Gradle sync and install the Android SDK platform required by `compileSdk = 35`.
4. Select a connected Android phone or emulator and press Run.

To build an APK from Android Studio: **Build → Build Bundle(s) / APK(s) → Build APK(s)**.

## Known limitations
- WebView is not Chromium Chrome. Some sites (including some login, payment, DRM, popup, or video flows) may restrict embedded browsers or behave differently.
- The shell and page layers are a prototype integration; page content is drawn behind the transparent original-style UI layer.
- Search results are served by Brave Search, not by an independent Zen-owned web index.
- This starter has no full multi-tab page-session isolation, download manager, extension API, ad blocker, or private-browsing mode yet.

## WebView notes
Android's WebView is a web rendering component and browser controls/navigation must be implemented by the app. See Android Developers' WebView guide: https://developer.android.com/develop/ui/views/layout/webapps/webview
