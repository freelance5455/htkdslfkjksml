#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
تنظیم آدرس سرور اختصاصی داخل برنامهٔ ترید یار (هر سه نسخهٔ HTML را یکجا اصلاح می‌کند)

استفاده:
    python3 set-server-url.py https://api.example.com
    python3 set-server-url.py https://api.example.com https://api2.example.com   (چند سرور)
    python3 set-server-url.py --clear                                            (حذف سرور اختصاصی)

بعد از اجرا، APK را دوباره بسازید (Build → Build APK) یا فایل HTML را منتشر کنید.
"""
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
FILES = [
    ROOT / "trad-yar-myket-fixed.html",
    ROOT / "myket-android" / "trad-yar-myket-fixed.html",
    ROOT / "myket-android" / "app" / "src" / "main" / "assets" / "index.html",
]
PATTERN = re.compile(r"(/\*OWN_SERVERS_BEGIN\*/)(.*?)(/\*OWN_SERVERS_END\*/)", re.S)


def normalize(url: str) -> str:
    url = url.strip().rstrip("/")
    if not re.fullmatch(r"https://[A-Za-z0-9.-]+(:\d+)?(/[A-Za-z0-9._~%/-]*)?", url):
        sys.exit(f"❌ آدرس نامعتبر است (باید با https:// شروع شود): {url}")
    return url


def main() -> None:
    args = sys.argv[1:]
    if not args:
        sys.exit(__doc__)
    urls = [] if args == ["--clear"] else [normalize(a) for a in args]
    literal = ",".join("'" + u + "'" for u in urls)

    done = 0
    for f in FILES:
        if not f.exists():
            print(f"⚠️  پیدا نشد (رد شد): {f.relative_to(ROOT)}")
            continue
        text = f.read_text(encoding="utf-8")
        if len(PATTERN.findall(text)) != 1:
            sys.exit(f"❌ نشانگر OWN_SERVERS در {f.name} پیدا نشد یا تکراری است.")
        f.write_text(PATTERN.sub(lambda m: m.group(1) + literal + m.group(3), text), encoding="utf-8")
        done += 1
        print(f"✅ {f.relative_to(ROOT)}")

    if urls:
        print(f"\nسرور اختصاصی تنظیم شد: {', '.join(urls)}")
    else:
        print("\nسرور اختصاصی حذف شد؛ برنامه فقط از سرورهای ابری قدیمی استفاده می‌کند.")
    print(f"{done} فایل به‌روز شد. حالا APK را دوباره بسازید.")


if __name__ == "__main__":
    main()
