#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
تنظیم آدرس سرور اختصاصی داخل برنامهٔ ترید یار (هر سه نسخهٔ HTML را یکجا اصلاح می‌کند)

استفاده:
    python3 set-server-url.py https://api.example.com
    python3 set-server-url.py https://api.example.com https://api2.example.com   (چند سرور)
    python3 set-server-url.py --fetch https://api.example.com --token TOKEN   (همهٔ سرورهای ثبت‌شده را داخل کد بنویس)
    python3 set-server-url.py --clear                                            (حذف سرور اختصاصی)

بعد از اجرا، APK را دوباره بسازید (Build → Build APK) یا فایل HTML را منتشر کنید.
"""
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
FILES = [
    ROOT / "trad-yar-myket-fixed.html",
    ROOT / "myket-android" / "trad-yar-myket-fixed.html",
    ROOT / "myket-android" / "app" / "src" / "main" / "assets" / "index.html",
]
TOKEN_PATTERN = re.compile(r"(/\*OWN_TOKEN_BEGIN\*/)(.*?)(/\*OWN_TOKEN_END\*/)", re.S)
PATTERN = re.compile(r"(/\*OWN_SERVERS_BEGIN\*/)(.*?)(/\*OWN_SERVERS_END\*/)", re.S)


def normalize(url: str) -> str:
    url = url.strip().rstrip("/")
    if re.fullmatch(r"http://\d{1,3}(\.\d{1,3}){3}(:\d+)?", url):
        print(f"⚠️  آدرس IP بدون HTTPS: {url} — اندروید ممکن است اتصال http را مسدود کند؛ بهتر است دامنه + HTTPS بگذارید.")
        return url
    if not re.fullmatch(r"https://[A-Za-z0-9.-]+(:\d+)?(/[A-Za-z0-9._~%/-]*)?", url):
        sys.exit(f"❌ آدرس نامعتبر است (https://دامنه یا http://IP:پورت): {url}")
    return url


def main() -> None:
    args = sys.argv[1:]
    token = ''
    if '--token' in args:
        i = args.index('--token')
        token = args[i + 1] if i + 1 < len(args) else ''
        if not re.fullmatch(r'[A-Za-z0-9]{16,128}', token):
            sys.exit('❌ توکن نامعتبر (فقط حروف و عدد، حداقل ۱۶ کاراکتر)')
        args = args[:i] + args[i + 2:]
    if not args:
        sys.exit(__doc__)
    if args[0] == "--fetch":
        import json, urllib.request
        if len(args) < 2:
            sys.exit("❌ آدرس سرور را بعد از --fetch بدهید")
        base = normalize(args[1])
        rq = urllib.request.Request(base + "/servers", headers={"x-tradyar-token": token})
        with urllib.request.urlopen(rq, timeout=20) as r:
            data = json.load(r)
        args = [base] + [s["url"] for s in data.get("servers", []) if s.get("url") and s["url"].rstrip("/") != base]
        print(f"📥 {len(args)} سرور از ثبت دائمی سرور دریافت شد")
    urls = [] if args == ["--clear"] else [normalize(a) for a in args]
    literal = ",".join("'" + u + "'" for u in urls)

    done = 0
    for f in FILES:
        if not f.exists():
            print(f"⚠️  پیدا نشد (رد شد): {f.relative_to(ROOT)}")
            continue
        text = f.read_text(encoding="utf-8")
        if len(PATTERN.findall(text)) != 1:
            sys.exit(f"❌ نشانگر OWN_SERVERS در {f.name} پیدا نشد یا تکراری است.")
        text = PATTERN.sub(lambda m: m.group(1) + literal + m.group(3), text)
        if TOKEN_PATTERN.search(text):
            text = TOKEN_PATTERN.sub(lambda m: m.group(1) + "'" + token + "'" + m.group(3), text)
        f.write_text(text, encoding="utf-8")
        done += 1
        print(f"✅ {f.relative_to(ROOT)}")

    if urls:
        print(f"\nسرور اختصاصی تنظیم شد: {', '.join(urls)}")
    else:
        print("\nسرور اختصاصی حذف شد؛ برنامه فقط از سرورهای ابری قدیمی استفاده می‌کند.")
    print(f"{done} فایل به‌روز شد. حالا APK را دوباره بسازید.")


if __name__ == "__main__":
    main()
