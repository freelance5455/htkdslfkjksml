package br.com.asavip.solucoes;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.webkit.ValueCallback;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.DownloadListener;
import android.content.Intent;
import android.net.Uri;
import android.view.View;
import android.widget.Toast;
import androidx.webkit.WebViewAssetLoader;
import androidx.webkit.WebViewAssetLoader.AssetsPathHandler;

public class MainActivity extends Activity {
 private WebView web;
 private ValueCallback<Uri[]> uploadCallback;
 private static final int PICK_FILE = 42;
 private final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
   .addPathHandler("/assets/", new AssetsPathHandler(this)).build();
 @Override public void onCreate(Bundle b) {
  super.onCreate(b);
  getWindow().setStatusBarColor(0xff11101b);
  getWindow().setNavigationBarColor(0xff11101b);
  web = new WebView(this); setContentView(web);
  WebSettings s=web.getSettings();
  s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setDatabaseEnabled(true);
  s.setAllowFileAccess(false); s.setAllowContentAccess(true);
  s.setJavaScriptCanOpenWindowsAutomatically(true);
  s.setSupportMultipleWindows(false);
  web.setWebViewClient(new WebViewClient() {
   @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
    return loader.shouldInterceptRequest(r.getUrl());
   }
   @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
    Uri u=r.getUrl();
    if ("appassets.androidplatform.net".equals(u.getHost())) return false;
    if ("https".equals(u.getScheme()) || "http".equals(u.getScheme())) {
     startActivity(new Intent(Intent.ACTION_VIEW,u));return true;
    }
    return false;
   }
  });
  web.setWebChromeClient(new WebChromeClient() {
   @Override public boolean onShowFileChooser(WebView w,ValueCallback<Uri[]> cb,FileChooserParams params) {
    if(uploadCallback!=null)uploadCallback.onReceiveValue(null);
    uploadCallback=cb;
    try { startActivityForResult(params.createIntent(),PICK_FILE);return true; }
    catch(Exception ex){uploadCallback=null;Toast.makeText(MainActivity.this,"Não foi possível abrir arquivos",Toast.LENGTH_SHORT).show();return false;}
   }
  });
  web.setDownloadListener((url,ua,disposition,mime,length)->{
   try { startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url))); }
   catch(Exception ex){Toast.makeText(this,"Exportação precisa de adaptação para Android",Toast.LENGTH_LONG).show();}
  });
  web.loadUrl("https://appassets.androidplatform.net/assets/index.html");
 }
 @Override protected void onActivityResult(int req,int result,Intent data){
  super.onActivityResult(req,result,data);
  if(req==PICK_FILE && uploadCallback!=null){
   uploadCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(result,data));uploadCallback=null;
  }
 }
 @Override public void onBackPressed(){if(web.canGoBack())web.goBack();else super.onBackPressed();}
 @Override protected void onDestroy(){web.destroy();super.onDestroy();}
}
