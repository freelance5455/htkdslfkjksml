// Comprueba el atlas de iconos Raven y que todo emoji/símbolo usado como icono tenga celda asignada.
const fs=require('fs'),h=fs.readFileSync(__dirname+'/index.html','utf8');let ok=0,bad=0;const T=(n,c)=>{c?ok++:(bad++,console.log('FALLA',n))};
const m=h.match(/const ICM=(\{.*?\}),ICN=(\d+),ICR=(\d+);/);T('mapa ICM presente',!!m);
const ICM=JSON.parse(m[1]),ICN=+m[2],ICR=+m[3];
const png=fs.readFileSync(__dirname+'/assets/icons/raven.png'),W=png.readUInt32BE(16),H=png.readUInt32BE(20);
T('atlas PNG válido',png.slice(1,4).toString()==='PNG');T('tamaño del atlas = celdas de 32 px',W===ICN*32&&H===ICR*32);
for(const k in ICM){const[c,r]=ICM[k];T('celda dentro del atlas '+k,c>=0&&c<ICN&&r>=0&&r<ICR)}
const cells=new Set(Object.values(ICM).map(v=>v.join()));T('hay iconos distintos ('+cells.size+')',cells.size>=60);
// símbolos que se dejan como texto (valoración ★, flechas y viñetas de interfaz)
const keep=new Set(['★','→','←','↩','↻','▸','▾','×','·','—','…']);
const body=h.replace(/<script id="icons">[\s\S]*?<\/script>/,'').replace(/\/\*[\s\S]*?\*\//g,'');
const re=/(?:[\u2190-\u21FF\u2300-\u23FF\u25A0-\u27BF\u2B00-\u2BFF]|[\u{1F300}-\u{1FAFF}])\uFE0F?/gu;const miss=new Set();
for(const x of body.match(re)||[]){const b=x.replace(/\uFE0F/g,'');if(!ICM[b]&&!keep.has(b))miss.add(b)}
T('todos los iconos de interfaz tienen celda (faltan: '+[...miss].join(' ')+')',miss.size===0);
T('el aro de cuchillas ya no comparte emoji con Ajustes',!/Aro de cuchillas[^}]*ic:'⚙️'/.test(h));
T('sw.js precachea el atlas',fs.readFileSync(__dirname+'/sw.js','utf8').includes('assets/icons/raven.png'));
console.log(ok,'ok',bad,'fallos');
