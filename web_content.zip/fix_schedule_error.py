from pathlib import Path
path = Path('/home/ubuntu/work-ops-panel/client/src/pages/Home.tsx')
text = path.read_text()
text = text.replace('{createSchedule.error && <p', '{createSchedule.error ? <p')
text = text.replace('Check the times and assigned account.</p>}</CardContent></Card>;', 'Check the times and assigned account.</p> : null}</CardContent></Card>;')
path.write_text(text)
