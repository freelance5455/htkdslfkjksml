SHOP FHARD SAIFNI — STARTER PROJECT
===================================

इस ZIP में क्या है?
- index.html: मोबाइल-फ्रेंडली shopping demo
- Customer tab: उत्पाद देखना, cart, demo order
- Admin tab: demo PIN 1234, products/price/stock बदलना, order status
- Delivery tab: demo orders की delivery status बदलना
- Reports tab: demo reports और JSON backup
- manifest.webmanifest + sw.js: hosted website पर installable PWA के लिए आधार
- Firebase config और Firestore rules के example files

महत्वपूर्ण सीमाएँ
-----------------
यह पहला FRONT-END DEMO है, live business system नहीं।
- Demo data सिर्फ उसी browser/device के local storage में सेव है।
- Demo PIN 1234 असली सुरक्षा नहीं है।
- Customer order दुकान/किसी server को नहीं भेजता।
- UPI विकल्प असली payment नहीं लेता।
- Cloud database, Firebase Auth, SMS OTP, push notifications, live sync,
  real delivery distance/rates, GST invoice, production backup और APK अभी जुड़े नहीं हैं।
- इस demo को असली ग्राहक/व्यक्तिगत डेटा के लिए इस्तेमाल न करें।

Android मोबाइल पर अभी कैसे देखें
-------------------------------
1. ZIP extract करें (Files app या ZIP extractor से)।
2. index.html को Chrome में खोलने की कोशिश करें। कुछ Android file managers
   local HTML पर JavaScript सीमित कर सकते हैं; ऐसी स्थिति में इसे online host करना होगा।
3. वेबसाइट को PWA की तरह install करने के लिए इसे HTTPS hosting पर publish करना होगा।
   फिर Chrome में website खोलें > ⋮ menu > Add to Home screen / Install app.

आगे live version बनाने के लिए
-----------------------------
1. Firebase Console पर नया project बनाएँ: https://console.firebase.google.com/
2. Authentication में Email/Password या Phone sign-in चालू करें।
3. Cloud Firestore बनाएँ और role-based Security Rules लागू करें।
4. Web app configuration प्राप्त करके firebase-config.example.js के placeholders बदलें।
5. Backend/Cloud Functions में order validation, stock decrement, delivery fee calculation,
   role checks, audit logs और payment verification implement करें।
6. UPI के लिए केवल QR दिखाना payment confirmation नहीं है; verified payment gateway
   या merchant payment integration लगाएँ।
7. Notifications, cloud backup, monitoring और security rules test करें।
8. तीन अलग-अलग role-based apps बनाएं/pack करें: Customer, Admin, Delivery.
   अभी ये तीनों views एक ही demo page में हैं, तीन independent production apps नहीं हैं.

मोबाइल से build करने का रास्ता
------------------------------
Firebase Studio: https://firebase.studio/
Official documentation: https://firebase.google.com/docs/studio/get-started-ai
Firebase Studio में browser से project prototype/preview किया जा सकता है, लेकिन
workspace availability और Android APK export/build विकल्प आपके account/session पर निर्भर हैं।
यह ZIP अपने project files के रूप में रखें और पहले hosted demo/preview चलाएँ।
केवल APK install करने के लिए इस ZIP पर tap करना पर्याप्त नहीं है।

Live cloud setup के official docs:
- Firebase Authentication: https://firebase.google.com/docs/auth
- Firebase Web Auth: https://firebase.google.com/docs/auth/web/start
- Firebase Hosting: https://firebase.google.com/docs/hosting
- Cloud Firestore security: https://firebase.google.com/docs/firestore/security/get-started

ब्रांड नाम: Shop Fhard Saifni
दायरा: भारत-भर में delivery का लक्ष्य; वास्तविक courier coverage/charges courier partner,
PIN code, parcel size/weight और distance के अनुसार तय होंगे।
भाषा: Hindi + English
पेमेंट लक्ष्य: Cash on Delivery + UPI
