/* ===== Wallpaper definitions ===== */
const WALLPAPERS = [
  { id: "GLOW_ORB", name: "Glow Orb", desc: "Your lock screen photo", bg: "#050508", image: "assets/glow-orb.jpg", clock: "#ffffff" },
  { id: "BLACK_AMOLED", name: "Black AMOLED", desc: "Pure black for AMOLED screens", bg: "#000000", clock: "#ffffff" },
  { id: "DARK_MINIMAL", name: "Dark Minimal", desc: "Soft dark minimal style", bg: "#0a0a0a", clock: "#e0e0e0" },
  { id: "DIGITAL_CLOCK", name: "Digital Clock", desc: "Classic digital green glow", bg: "#050505", clock: "#00ff88" },
  { id: "PLAIN_BLACK", name: "Plain Black", desc: "Simple pure black", bg: "#000000", clock: "#f5f5f5" },
  { id: "ONE_PIECE_SKULL", name: "One Piece Skull", desc: "Your photo wallpaper", bg: "#f2f2f2", image: "assets/one-piece-skull.jpg", clock: "#1a1a1a" }
];

/* Returns CSS background declarations for a wallpaper (color, plus photo if set). */
function wallpaperBackground(w) {
  if (w.image) {
    return `background-color:${w.bg};background-image:url(\"${w.image}\");background-size:cover;background-position:center;`;
  }
  return `background-color:${w.bg};background-image:none;`;
}

/* ===== Config ===== */
// One displayed minute reverses every selected number of real seconds.
const DEFAULT_REVERSE_SPEED_SECONDS = 3;
const ROLL_MS = 700;

/* ===== State ===== */
const state = {
  wallpaperId: localStorage.getItem("rtl_wallpaper") || null,
  setupDone: localStorage.getItem("rtl_setup_done") === "true",
  startHour: parseInt(localStorage.getItem("rtl_start_hour") || "6", 10),
  startMinute: parseInt(localStorage.getItem("rtl_start_minute") || "30", 10),
  reverseSpeedSeconds: Math.min(10, Math.max(1, parseInt(localStorage.getItem("rtl_reverse_speed") || String(DEFAULT_REVERSE_SPEED_SECONDS), 10))),
  running: false,
  paused: false,
  startTimestamp: null,
  baseTotalMinutes: null,
  pausedTotalMinutes: null,
  lastRenderedText: "",
  animating: { h1: false, h2: false, m1: false, m2: false }
};

let tickTimer = null;
let hintTimeout = null;

/* ===== DOM ===== */
const screens = {
  wallpaper: document.getElementById("screen-wallpaper"),
  setup: document.getElementById("screen-setup"),
  clock: document.getElementById("screen-clock")
};

const els = {
  grid: document.getElementById("wallpaper-grid"),
  btnApplyWallpaper: document.getElementById("btn-apply-wallpaper"),
  btnBack: document.getElementById("btn-back"),
  btnStart: document.getElementById("btn-start"),
  btnPause: document.getElementById("btn-pause"),
  btnReset: document.getElementById("btn-reset"),
  btnFullscreen: document.getElementById("btn-fullscreen"),
  reverseSpeed: document.getElementById("reverse-speed"),
  hourDisplay: document.getElementById("hour-display"),
  minDisplay: document.getElementById("min-display"),
  hourUp: document.getElementById("hour-up"),
  hourDown: document.getElementById("hour-down"),
  minUp: document.getElementById("min-up"),
  minDown: document.getElementById("min-down"),
  previewCard: document.getElementById("preview-card"),
  previewTime: document.getElementById("preview-time"),
  previewLabel: document.getElementById("preview-label"),
  statusDisplay: document.getElementById("status-display"),
  statusState: document.getElementById("status-state"),
  rollingClock: document.getElementById("rolling-clock"),
  lockTop: document.getElementById("lock-top"),
  lockDate: document.getElementById("lock-date"),
  clockLabel: document.getElementById("clock-label"),
  clockOffset: document.getElementById("clock-offset"),
  clockHint: document.getElementById("clock-hint"),
  clockBtnPause: document.getElementById("clock-btn-pause"),
  clockBtnReset: document.getElementById("clock-btn-reset")
};

const digitSlots = {
  h1: document.querySelector('.digit-slot[data-pos="h1"] .digit-wheel'),
  h2: document.querySelector('.digit-slot[data-pos="h2"] .digit-wheel'),
  m1: document.querySelector('.digit-slot[data-pos="m1"] .digit-wheel'),
  m2: document.querySelector('.digit-slot[data-pos="m2"] .digit-wheel')
};

/* ===== Helpers ===== */
function pad(n) {
  return String(((n % 100) + 100) % 100).padStart(2, "0");
}

function toTotalMinutes(h, m) {
  h = ((h % 24) + 24) % 24;
  m = ((m % 60) + 60) % 60;
  return h * 60 + m;
}

function formatFromTotal(total) {
  let t = ((total % 1440) + 1440) % 1440;
  const h = Math.floor(t / 60);
  const m = t % 60;
  return pad(h) + ":" + pad(m);
}

function totalToDigits(total) {
  let t = ((total % 1440) + 1440) % 1440;
  const h = Math.floor(t / 60);
  const m = t % 60;
  return {
    h1: Math.floor(h / 10),
    h2: h % 10,
    m1: Math.floor(m / 10),
    m2: m % 10
  };
}

function selectedTotalMinutes() {
  return toTotalMinutes(state.startHour, state.startMinute);
}

function getWallpaper() {
  return WALLPAPERS.find(w => w.id === state.wallpaperId) || WALLPAPERS[0];
}

function showScreen(name) {
  Object.values(screens).forEach(s => s.classList.remove("active"));
  screens[name].classList.add("active");
}

function saveStartTime() {
  localStorage.setItem("rtl_start_hour", String(state.startHour));
  localStorage.setItem("rtl_start_minute", String(state.startMinute));
}

/* ===== CORE TIME LOGIC =====
 * When reverse is not running → show real device time.
 * When running → reverse countdown (1 displayed minute every N real seconds).
 */
function getRealTotalMinutes() {
  const now = new Date();
  return now.getHours() * 60 + now.getMinutes();
}

function getCurrentTotalMinutes() {
  if (!state.running) return getRealTotalMinutes();          // Real time
  if (state.paused) return state.pausedTotalMinutes;
  const intervalMs = state.reverseSpeedSeconds * 1000;
  const elapsedMinutes = Math.floor((Date.now() - state.startTimestamp) / intervalMs);
  return state.baseTotalMinutes - elapsedMinutes;
}

/* ===== Rolling digit animation =====
 * Old digit rolls upward + fades out.
 * New digit rolls in from below + fades in.
 * 700ms cubic-bezier, independent per digit.
 */
function rollDigit(pos, newVal) {
  const wheel = digitSlots[pos];
  if (!wheel) return;

  // Prevent overlapping animations on same digit
  if (state.animating[pos]) {
    // Force clean state then set
    wheel.innerHTML = `<span class="digit current">${newVal}</span>`;
    state.animating[pos] = false;
    return;
  }

  const current = wheel.querySelector(".digit.current");
  if (!current) {
    wheel.innerHTML = `<span class="digit current">${newVal}</span>`;
    return;
  }

  if (current.textContent === String(newVal)) return;

  state.animating[pos] = true;

  // Outgoing digit
  const outgoing = current;
  outgoing.classList.remove("current");
  outgoing.classList.add("outgoing");

  // Incoming digit
  const incoming = document.createElement("span");
  incoming.className = "digit incoming";
  incoming.textContent = String(newVal);
  wheel.appendChild(incoming);

  // Double rAF ensures browser paints initial state before transition
  requestAnimationFrame(() => {
    requestAnimationFrame(() => {
      outgoing.classList.add("roll-out");
      incoming.classList.add("roll-in");
    });
  });

  const finish = () => {
    // Clean up to a single current digit
    wheel.innerHTML = `<span class="digit current">${newVal}</span>`;
    state.animating[pos] = false;
  };

  // Prefer transitionend, fallback to timeout
  let done = false;
  const onEnd = (e) => {
    if (e.propertyName !== "transform") return;
    if (done) return;
    done = true;
    incoming.removeEventListener("transitionend", onEnd);
    finish();
  };
  incoming.addEventListener("transitionend", onEnd);
  setTimeout(() => {
    if (!done) {
      done = true;
      finish();
    }
  }, ROLL_MS + 80);
}

function setDigitsImmediate(total) {
  const d = totalToDigits(total);
  ["h1", "h2", "m1", "m2"].forEach(pos => {
    const wheel = digitSlots[pos];
    if (!wheel) return;
    wheel.innerHTML = `<span class="digit current">${d[pos]}</span>`;
    state.animating[pos] = false;
  });
  state.lastRenderedText = formatFromTotal(total);
}

function setDigitsAnimated(total) {
  const text = formatFromTotal(total);
  if (text === state.lastRenderedText) return;
  state.lastRenderedText = text;

  const d = totalToDigits(total);
  ["h1", "h2", "m1", "m2"].forEach(pos => {
    rollDigit(pos, d[pos]);
  });
}

/* ===== UI update ===== */
function updateDisplay(animate) {
  const total = getCurrentTotalMinutes();
  const text = formatFromTotal(total);

  if (els.statusDisplay) els.statusDisplay.textContent = text;
  if (els.previewTime) els.previewTime.textContent = text;

  if (state.running && !state.paused) {
    if (els.statusState) els.statusState.textContent = `Running (1 min / ${state.reverseSpeedSeconds} sec)`;
    if (els.previewLabel) els.previewLabel.textContent = "REVERSE TIME • LIVE";
    if (els.clockOffset) els.clockOffset.textContent = "COUNTING DOWN";
  } else if (state.paused) {
    if (els.statusState) els.statusState.textContent = "Paused";
    if (els.previewLabel) els.previewLabel.textContent = "PAUSED";
    if (els.clockOffset) els.clockOffset.textContent = "PAUSED";
  } else {
    if (els.statusState) els.statusState.textContent = "Ready";
    if (els.previewLabel) els.previewLabel.textContent = "SELECTED START TIME";
    if (els.clockOffset) els.clockOffset.textContent = "READY";
  }

  if (animate) {
    setDigitsAnimated(total);
  } else {
    setDigitsImmediate(total);
  }

  if (els.btnStart) {
    els.btnStart.disabled = state.running && !state.paused;
    els.btnStart.textContent = (state.running && state.paused) ? "RESUME" : "START REVERSE";
  }
  if (els.btnPause) {
    els.btnPause.disabled = !state.running || state.paused;
  }
  if (els.clockBtnPause) {
    els.clockBtnPause.textContent = state.paused ? "RESUME" : (state.running ? "PAUSE" : "START");
  }
}

/* ===== Timer control ===== */
function startTicker() {
  stopTicker();
  tickTimer = setInterval(function clockTick() {
    // Always update: real time when idle, reverse time when running
    updateDisplay(true);
    // Keep date fresh
    if (els.lockDate) {
      els.lockDate.textContent = formatLockDate(new Date());
    }
  }, 1000);
}

function stopTicker() {
  if (tickTimer) {
    clearInterval(tickTimer);
    tickTimer = null;
  }
}

function startReverse() {
  if (state.running && !state.paused) return;

  if (state.paused) {
    state.baseTotalMinutes = state.pausedTotalMinutes;
    state.startTimestamp = Date.now();
    state.paused = false;
    state.pausedTotalMinutes = null;
  } else {
    state.baseTotalMinutes = selectedTotalMinutes();
    state.startTimestamp = Date.now();
    state.running = true;
    state.paused = false;
    state.pausedTotalMinutes = null;
  }

  startTicker();
  updateDisplay(false);
}

function pauseReverse() {
  if (!state.running || state.paused) return;
  state.pausedTotalMinutes = getCurrentTotalMinutes();
  state.paused = true;
  stopTicker();
  updateDisplay(false);
}

function resetReverse() {
  stopTicker();
  state.running = false;
  state.paused = false;
  state.startTimestamp = null;
  state.baseTotalMinutes = null;
  state.pausedTotalMinutes = null;
  state.lastRenderedText = "";
  updateDisplay(false);
}

/* ===== Wallpaper ===== */
function renderWallpaperGrid() {
  els.grid.innerHTML = "";
  WALLPAPERS.forEach(w => {
    const card = document.createElement("div");
    card.className = "wallpaper-card" + (state.wallpaperId === w.id ? " selected" : "");
    card.dataset.id = w.id;
    card.innerHTML = `
      <div class="wallpaper-preview" style="${wallpaperBackground(w)}">
        <div class="mini-time" style="color:${w.clock}">06:30</div>
        <div class="mini-label" style="color:${w.clock}">REVERSED</div>
      </div>
      <div class="wallpaper-footer">
        <div class="name">${w.name}</div>
        <div class="desc">${w.desc}</div>
      </div>
      <div class="check-badge">
        <svg viewBox="0 0 24 24" fill="none"><path d="M5 13l4 4L19 7"/></svg>
      </div>
    `;
    card.addEventListener("click", () => selectWallpaper(w.id));
    els.grid.appendChild(card);
  });
  els.btnApplyWallpaper.disabled = !state.wallpaperId;
}

function selectWallpaper(id) {
  state.wallpaperId = id;
  localStorage.setItem("rtl_wallpaper", id);
  renderWallpaperGrid();
  els.btnApplyWallpaper.disabled = false;
}

els.btnApplyWallpaper.addEventListener("click", () => {
  if (!state.wallpaperId) return;
  localStorage.setItem("rtl_setup_done", "true");
  state.setupDone = true;
  applyWallpaperToPreview();
  syncPickerUI();
  updateDisplay(false);
  showScreen("setup");
});

/* ===== Time Picker ===== */
function syncPickerUI() {
  els.hourDisplay.textContent = pad(state.startHour);
  els.minDisplay.textContent = pad(state.startMinute);
}

function changeHour(delta) {
  state.startHour = ((state.startHour + delta) % 24 + 24) % 24;
  saveStartTime();
  if (!state.running) state.lastRenderedText = "";
  syncPickerUI();
  updateDisplay(false);
}

function changeMinute(delta) {
  let m = state.startMinute + delta;
  if (m >= 60) {
    m = 0;
    state.startHour = (state.startHour + 1) % 24;
  } else if (m < 0) {
    m = 59;
    state.startHour = (state.startHour - 1 + 24) % 24;
  }
  state.startMinute = m;
  saveStartTime();
  if (!state.running) state.lastRenderedText = "";
  syncPickerUI();
  updateDisplay(false);
}

els.hourUp.addEventListener("click", () => changeHour(1));
els.hourDown.addEventListener("click", () => changeHour(-1));
els.minUp.addEventListener("click", () => changeMinute(1));
els.minDown.addEventListener("click", () => changeMinute(-1));

if (els.reverseSpeed) {
  els.reverseSpeed.value = String(state.reverseSpeedSeconds);
  els.reverseSpeed.addEventListener("change", () => {
    const nextSpeed = Math.min(10, Math.max(1, parseInt(els.reverseSpeed.value, 10) || DEFAULT_REVERSE_SPEED_SECONDS));
    // Preserve the currently displayed time when speed is changed mid-countdown.
    const current = getCurrentTotalMinutes();
    state.reverseSpeedSeconds = nextSpeed;
    localStorage.setItem("rtl_reverse_speed", String(nextSpeed));
    if (state.running && !state.paused) {
      state.baseTotalMinutes = current;
      state.startTimestamp = Date.now();
    } else if (state.paused) {
      state.pausedTotalMinutes = current;
    }
    updateDisplay(false);
  });
}

/* ===== Buttons ===== */
els.btnStart.addEventListener("click", startReverse);
els.btnPause.addEventListener("click", pauseReverse);
els.btnReset.addEventListener("click", resetReverse);
els.btnFullscreen.addEventListener("click", openClockScreen);
els.btnBack.addEventListener("click", () => showScreen("wallpaper"));

/* ===== Full-screen ===== */
function applyWallpaperToPreview() {
  const w = getWallpaper();
  els.previewCard.style.backgroundColor = w.bg;
  els.previewCard.style.backgroundImage = w.image ? `url("${w.image}")` : "none";
  els.previewCard.style.backgroundSize = "cover";
  els.previewCard.style.backgroundPosition = "center";
  els.previewTime.style.color = w.clock;
  els.previewLabel.style.color = w.clock;
}

const WEEKDAYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
function formatLockDate(d) {
  return `${WEEKDAYS[d.getDay()]}, ${d.getDate()} ${MONTHS[d.getMonth()]}`;
}

function openClockScreen() {
  const w = getWallpaper();
  screens.clock.style.backgroundColor = w.bg;
  screens.clock.style.backgroundImage = w.image ? `url("${w.image}")` : "none";
  screens.clock.style.backgroundSize = "cover";
  screens.clock.style.backgroundPosition = "center";
  const color = w.clock;

  document.querySelectorAll(".digit-slot, .colon").forEach(el => {
    el.style.color = color;
  });
  els.rollingClock.style.setProperty("--digit-color", color);
  els.clockLabel.style.color = color;
  els.clockLabel.style.opacity = "0.55";
  els.clockOffset.style.color = color;
  els.clockOffset.style.opacity = "0.4";
  els.clockHint.style.color = color;
  els.clockHint.style.opacity = "0.3";
  els.clockHint.classList.remove("hidden");

  els.lockTop.style.color = color;
  els.lockDate.textContent = formatLockDate(new Date());
  document.querySelectorAll(".clock-btn, .lock-shortcut").forEach(btn => {
    btn.style.color = color;
    btn.style.borderColor = color;
  });

  updateDisplay(false);
  showScreen("clock");

  // Best-effort immersive display in browsers that support the Fullscreen API.
  // A web app cannot forcibly remove Android's system status bar on every device.
  if (screens.clock.requestFullscreen && !document.fullscreenElement) {
    screens.clock.requestFullscreen().catch(() => {});
  }

  // Always run ticker so real time (or reverse) keeps updating
  startTicker();

  if (hintTimeout) clearTimeout(hintTimeout);
  hintTimeout = setTimeout(() => {
    els.clockHint.classList.add("hidden");
  }, 4000);
}

function exitClock() {
  setTorch(false);
  if (document.fullscreenElement && document.exitFullscreen) {
    document.exitFullscreen().catch(() => {});
  }
  showScreen("setup");
  updateDisplay(false);
}

els.clockBtnPause.addEventListener("click", (e) => {
  e.stopPropagation();
  if (state.paused) startReverse();
  else if (state.running) pauseReverse();
  else startReverse();
});

els.clockBtnReset.addEventListener("click", (e) => {
  e.stopPropagation();
  resetReverse();
});

/* Tap = pause/resume, long-press = exit */
function toggleClockPause() {
  if (state.paused) startReverse();
  else if (state.running) pauseReverse();
  else startReverse();
}

let suppressNextClick = false;
screens.clock.addEventListener("click", (e) => {
  if (e.target.closest(".clock-btn, .lock-shortcut")) return;
  if (suppressNextClick) {
    suppressNextClick = false;
    return;
  }
  toggleClockPause();
});

let longPressTimer = null;
function clearLongPress() {
  if (longPressTimer) {
    clearTimeout(longPressTimer);
    longPressTimer = null;
  }
}
function longPressExit() {
  suppressNextClick = true;
  exitClock();
}
screens.clock.addEventListener("touchstart", (e) => {
  if (e.target.closest(".clock-btn, .lock-shortcut")) return;
  longPressTimer = setTimeout(longPressExit, 600);
}, { passive: true });
screens.clock.addEventListener("touchend", clearLongPress);
screens.clock.addEventListener("touchmove", clearLongPress);
screens.clock.addEventListener("mousedown", (e) => {
  if (e.target.closest(".clock-btn, .lock-shortcut")) return;
  longPressTimer = setTimeout(longPressExit, 600);
});
screens.clock.addEventListener("mouseup", clearLongPress);
screens.clock.addEventListener("mouseleave", clearLongPress);

/* ===== Lock-screen shortcuts ===== */
const flashBtn = document.getElementById("shortcut-flash");
const camBtn = document.getElementById("shortcut-camera");
const camInput = document.getElementById("camera-input");
let torchStream = null;
let torchOn = false;

async function setTorch(on) {
  try {
    if (on) {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: { ideal: "environment" } }
      });
      const track = stream.getVideoTracks()[0];
      try {
        await track.applyConstraints({ advanced: [{ torch: true }] });
      } catch (err) {
        stream.getTracks().forEach(t => t.stop());
        throw err;
      }
      torchStream = stream;
      torchOn = true;
    } else {
      if (torchStream) torchStream.getTracks().forEach(t => t.stop());
      torchStream = null;
      torchOn = false;
    }
  } catch (err) {
    torchStream = null;
    torchOn = false;
    alert("Flashlight is not available on this device or browser. It needs HTTPS and a phone with torch support.");
  }
  flashBtn.classList.toggle("on", torchOn);
}

flashBtn.addEventListener("click", (e) => {
  e.stopPropagation();
  setTorch(!torchOn);
});

camBtn.addEventListener("click", (e) => {
  e.stopPropagation();
  camInput.click();
});

// Keep shortcut taps from triggering exit gestures or the long-press timer
[flashBtn, camBtn].forEach(btn => {
  ["touchstart", "mousedown"].forEach(ev =>
    btn.addEventListener(ev, (e) => e.stopPropagation(), { passive: true })
  );
});

/* ===== Init ===== */
function init() {
  renderWallpaperGrid();
  syncPickerUI();
  if (els.reverseSpeed) els.reverseSpeed.value = String(state.reverseSpeedSeconds);

  if (state.setupDone && state.wallpaperId) {
    applyWallpaperToPreview();
    updateDisplay(false);
    showScreen("setup");
  } else {
    state.wallpaperId = null;
    els.btnApplyWallpaper.disabled = true;
    showScreen("wallpaper");
  }
}

init();
