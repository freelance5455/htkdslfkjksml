EGY TARGET - Android Studio project (prototype wrapper)

This is an Android Studio source project, NOT a compiled APK.
Open this folder in Android Studio, allow Gradle sync, then choose:
Build > Build Bundle(s) / APK(s) > Build APK(s).

The generated APK will be under:
app/build/outputs/apk/debug/app-debug.apk

Prototype data is stored locally on the device/browser WebView storage.
This is not yet a production multi-branch cloud system.
