RD ALPHA - Vehicle Statistics & Analysis
========================================

CONTENTS
- index.html : Complete standalone app source (HTML, CSS and JavaScript)
- logo.jpg   : RD ALPHA logo asset

HOW TO RUN
1. Extract the ZIP file.
2. Open index.html in Chrome or another modern browser.
3. Enter the current prototype PIN: 2323.
4. Select Add Data, choose a year, enter monthly vehicle totals and save.

FEATURES
- English, Sinhala and Tamil interface
- Monthly total vehicle entry (2020 onwards, with future years)
- Dashboard with annual totals, monthly bars, highest/lowest months
- Year-to-year comparison with net difference and percentage
- Detailed yearly report, CSV export and browser Print / Save as PDF
- JSON backup and restore
- RD ALPHA green and lime-green theme

IMPORTANT LIMITATIONS
- This is a browser-based source prototype, not a compiled Android APK.
- Records are stored locally in the browser on the device. They are not automatically synced online or shared between devices.
- Download JSON backups regularly. Clearing browser data may erase locally stored records.
- PIN 2323 is a basic prototype gate, not secure authentication. Change it in index.html before any real deployment.
- For a production Android app, the source needs Android packaging, device testing, secure authentication and a proper backup/sync strategy.


PDF REPORT FIX (Android):
1. Extract the ZIP file.
2. Open index.html in Google Chrome (not inside a file preview app).
3. Sign in and open Reports.
4. Select the year, tap Generate report, then tap Print / PDF.
5. Chrome's print screen should open. Select "Save as PDF" and tap the PDF save icon.
6. If Chrome blocks the report window, allow pop-ups for the page and try again.

The PDF report opens in a separate print-ready page and includes the RD ALPHA logo.
This remains an offline/local browser prototype. It is not a compiled Android APK.


RD ALPHA MODARA update:
- Save button now validates all 12 monthly values and shows a clear error if browser storage is blocked.
- Open index.html directly in Google Chrome (not an in-app preview) and allow site storage.
- Keep regular JSON backups from the Backup tab.
