STUDY MATE AI - STARTER APP
============================

Files:
- index.html: app layout
- style.css: styling
- app.js: features and local storage
- manifest.json and sw.js: install/offline support
- icon.svg: app icon

Features currently working:
- Responsive dashboard / navigation
- Add subjects
- Create, check, and remove study goals
- Focus timer with 15/25/40/custom minutes, pause/reset
- Focus time tracked locally
- Recall practice saves question, your answer, reference answer locally
- Reading Lab speech-to-text (browser support varies)
- Compare detected reading to passage (rough word-position comparison)
- Passage read-aloud using browser text-to-speech
- Offline cache / installable web-app manifest

Limitations:
- AI Tutor is not yet connected to a live AI model; its chat is a demo response.
- Reading comparison is a rough text match, not an accurate pronunciation or fluency score.
- Mic support varies by browser and may require internet/permissions.

EASIEST PHONE INSTALL:
1. Upload the whole folder to a static web host (e.g. GitHub Pages, Netlify, or Cloudflare Pages).
2. Open the published HTTPS link in Chrome on Android.
3. Chrome menu > Add to Home screen / Install app.
The app can run locally in the browser and caches core files for offline use after first load.

Do not open index.html as a file if you need install/offline service worker features; serve it over HTTPS.
