Skin Ritual — Final Version 10

Features:
- Year-round calendar with a repeating 14-day routine
- Edit section names and step names/details for a selected date, future dates, or a chosen date range
- Drag steps on touchscreens or desktop, with Move Up/Move Down alternatives
- Add multiple custom steps in one go, choosing section and insertion position
- Multiple steps assigned to “Create a new section” are grouped into one new section
- Plan start date is saved in this browser/device
- Skip a date and add remarks
- Tick routine steps and use “Submit & Save This Day” to save checkbox progress
- Saves data in this browser/device using localStorage

To use: open index.html in a modern browser. For installable PWA/offline service-worker features, host the extracted folder on an HTTPS-enabled web host. This package is a web app, not an Android APK.
