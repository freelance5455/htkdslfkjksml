-- URE v2: citizens + shared wallet. Run once in Supabase > SQL Editor (after cloud-setup.sql).
-- ملاحظة: شغّل cloud-setup.sql الأول لو لسه ماشغلتوش.

create table if not exists public.ure_citizens (
  id text primary key,
  name text not null,
  role text,
  num text,
  joined text,
  created_at timestamptz not null default now()
);
alter table public.ure_citizens enable row level security;
drop policy if exists "citizens read" on public.ure_citizens;
create policy "citizens read" on public.ure_citizens for select to anon, authenticated using (true);
drop policy if exists "citizens insert" on public.ure_citizens;
create policy "citizens insert" on public.ure_citizens for insert to anon, authenticated with check (true);
drop policy if exists "citizens update admin" on public.ure_citizens;
create policy "citizens update admin" on public.ure_citizens for update to authenticated
  using (exists (select 1 from public.ure_admins a where a.user_id = auth.uid()))
  with check (exists (select 1 from public.ure_admins a where a.user_id = auth.uid()));
drop policy if exists "citizens delete admin" on public.ure_citizens;
create policy "citizens delete admin" on public.ure_citizens for delete to authenticated
  using (exists (select 1 from public.ure_admins a where a.user_id = auth.uid()));
grant select, insert on public.ure_citizens to anon;
grant select, insert, update, delete on public.ure_citizens to authenticated;

-- Wallet: everyone can READ balances; only listed admins can ADD money.
drop policy if exists "URE wallet admin read" on public.ure_wallet_ledger;
drop policy if exists "wallet read all" on public.ure_wallet_ledger;
create policy "wallet read all" on public.ure_wallet_ledger for select to anon, authenticated using (true);
grant select on public.ure_wallet_ledger to anon;

-- Only admins can delete news posts.
drop policy if exists "URE posts delete by admin" on public.ure_posts;
create policy "URE posts delete by admin" on public.ure_posts for delete to authenticated
  using (exists (select 1 from public.ure_admins a where a.user_id = auth.uid()));

-- بعد ما تعمل مستخدم الإدارة من Authentication > Users، انسخ الـ UUID بتاعه وشغّل:
-- insert into public.ure_admins (user_id) values ('ضع-الـUUID-هنا');
