require('dotenv').config();
const express = require('express');
const path = require('path');
const { AccessToken } = require('livekit-server-sdk');

const app = express();
app.use(express.json({ limit: '20kb' }));
app.use(express.static(path.join(__dirname, 'public')));

const { LIVEKIT_URL, LIVEKIT_API_KEY, LIVEKIT_API_SECRET } = process.env;

app.get('/api/health', (_req, res) => {
  res.json({ ok: true, service: 'Nmr voice server', livekitConfigured: Boolean(LIVEKIT_URL && LIVEKIT_API_KEY && LIVEKIT_API_SECRET) });
});

app.post('/api/token', async (req, res) => {
  try {
    if (!LIVEKIT_URL || !LIVEKIT_API_KEY || !LIVEKIT_API_SECRET) {
      return res.status(503).json({ error: 'إعدادات LiveKit غير مكتملة على السيرفر.' });
    }
    const room = String(req.body.room || 'nmr-main').trim();
    const identity = String(req.body.identity || '').trim();
    if (!/^[a-zA-Z0-9_-]{2,40}$/.test(room)) return res.status(400).json({ error: 'اسم الغرفة غير صالح.' });
    if (!identity || identity.length > 40) return res.status(400).json({ error: 'اكتب اسماً من 1 إلى 40 حرفاً.' });

    const token = new AccessToken(LIVEKIT_API_KEY, LIVEKIT_API_SECRET, {
      identity,
      ttl: '2h',
      name: identity
    });
    token.addGrant({ roomJoin: true, room, canPublish: true, canSubscribe: true, canPublishData: true });
    const jwt = await token.toJwt();
    res.set('Cache-Control', 'no-store');
    res.json({ token: jwt, serverUrl: LIVEKIT_URL, room });
  } catch (err) {
    console.error('Token error:', err.message);
    res.status(500).json({ error: 'تعذر إنشاء اتصال الغرفة حالياً.' });
  }
});

const port = Number(process.env.PORT || 3000);
app.listen(port, () => console.log(`Nmr server listening on port ${port}`));
