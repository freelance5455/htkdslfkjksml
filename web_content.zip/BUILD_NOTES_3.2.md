XGaming 3.2 UI Update

# XGaming 3.2 — Build & deployment notes

- Base: XGaming Project 3.0 / existing UI preserved.
- Android version: 3.2 (versionCode 31).
- The home-page top brand text is intentionally empty; the drawer branding remains unchanged.
- Game cover images are used as the main visual for cards/details.
- Game download fields are URL-only: APK / OBB / DATA.
- Android permissions are requested through the Android permission system; image selection uses the system document picker.
- Notifications use POST_NOTIFICATIONS on Android 13+ and can be controlled from the in-app notification settings.
- Backend stores games, images, downloads, announcements, complaints, and users in PostgreSQL.
- Admin can publish/edit/hide/show/delete games, manage cover images and links, view download statistics, and create announcements.

Build with Android Studio/Gradle because this environment does not include a Gradle executable or wrapper.
