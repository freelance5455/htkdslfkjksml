/* JOSTECH — MODÈLES DU LABO & MOTEUR SQL LOCAL */
const LAB_TEMPLATES = {
  web: [
    "<!DOCTYPE html>",
    "<html>",
    "<body style='background:#0f172a;color:#e2e8f0;font-family:sans-serif;padding:14px;'>",
    "  <h2 style='color:#38bdf8;'>Labo Web JOSTECH</h2>",
    "  <p id='msg'>Modifiez ce code et cliquez sur Exécuter !</p>",
    "  <button onclick=\"document.getElementById('msg').textContent='Bravo, JavaScript actif !'\">Tester JS</button>",
    "</body>",
    "</html>"
  ].join("\n"),
  js: [
    "// Calculez votre moyenne universitaire en JavaScript",
    "const notes = [15.5, 17, 14, 18.5];",
    "let somme = 0;",
    "for (let i = 0; i < notes.length; i++) {",
    "  somme += notes[i];",
    "}",
    "const moyenne = somme / notes.length;",
    "console.log('Notes :', notes);",
    "console.log('Moyenne :', moyenne.toFixed(2) + '/20');"
  ].join("\n"),
  sql: [
    "-- Base SQL locale (tables : etudiants, cours)",
    "SELECT nom, niveau, note FROM etudiants WHERE note >= 14 ORDER BY note DESC;"
  ].join("\n"),
  python: [
    "# Programme Python universitaire",
    "def factorielle(n):",
    "    if n <= 1: return 1",
    "    return n * factorielle(n - 1)",
    "",
    "for k in range(1, 7):",
    "    print(f'factorielle({k}) = {factorielle(k)}')"
  ].join("\n")
};

const SQL_DB = {
  etudiants: [
    { id: 1, nom: "Amina", niveau: 1, note: 16.5 },
    { id: 2, nom: "Mivumbi", niveau: 3, note: 18.0 },
    { id: 3, nom: "Kabila", niveau: 2, note: 12.5 },
    { id: 4, nom: "Sarah", niveau: 1, note: 15.0 }
  ],
  cours: [
    { id: 1, titre: "Informatique générale", niveau: 1 },
    { id: 2, titre: "Programmation Python & C", niveau: 2 },
    { id: 3, titre: "API REST & PWA", niveau: 3 }
  ]
};

function executeMiniSQL(rawSql) {
  const sql = rawSql.split("\n").filter(l => !l.trim().startsWith("--")).join(" ").replace(/;+\s*$/, "").trim();
  if (!sql) return "Aucune requête SQL détectée.";
  if (/^SHOW\s+TABLES$/i.test(sql)) return "Tables disponibles : " + Object.keys(SQL_DB).join(", ");

  const ins = sql.match(/^INSERT\s+INTO\s+(\w+)\s*\(([^)]+)\)\s*VALUES\s*\(([^)]+)\)/i);
  if (ins) {
    const t = ins[1].toLowerCase(); if (!SQL_DB[t]) return `Table '${t}' introuvable.`;
    const cols = ins[2].split(",").map(s => s.trim()), vals = ins[3].split(",").map(s => s.trim().replace(/^['"]|['"]$/g, ""));
    const obj = {}; cols.forEach((c, i) => { obj[c] = isNaN(vals[i]) ? vals[i] : Number(vals[i]); });
    SQL_DB[t].push(obj);
    return `1 ligne ajoutée dans '${t}'. Total : ${SQL_DB[t].length} lignes.`;
  }

  const sel = sql.match(/^SELECT\s+(.+?)\s+FROM\s+(\w+)(?:\s+WHERE\s+(.+?))?(?:\s+ORDER\s+BY\s+(\w+)(?:\s+(ASC|DESC))?)?$/i);
  if (!sel) return "Requête non reconnue. Essayez : SELECT * FROM etudiants WHERE note >= 14;";
  const [, colsRaw, tbl, whereRaw, ordCol, ordDir] = sel;
  const rows0 = SQL_DB[tbl.toLowerCase()]; if (!rows0) return `Table '${tbl}' inexistante.`;
  let rows = rows0.slice();
  if (whereRaw) {
    const wm = whereRaw.trim().match(/^(\w+)\s*(=|!=|>=|<=|>|<)\s*(.+)$/);
    if (!wm) return "Clause WHERE invalide (ex: note >= 14).";
    const f = wm[1], op = wm[2], v = wm[3].replace(/^['"]|['"]$/g, ""), num = !isNaN(v) ? Number(v) : v;
    rows = rows.filter(r => {
      const val = r[f];
      if (op === "=") return val == num; if (op === "!=") return val != num;
      if (op === ">=") return val >= num; if (op === "<=") return val <= num;
      if (op === ">") return val > num; if (op === "<") return val < num;
      return false;
    });
  }
  if (ordCol) rows.sort((a, b) => (a[ordCol] > b[ordCol] ? 1 : -1) * ((ordDir || "").toUpperCase() === "DESC" ? -1 : 1));
  if (!rows.length) return "(0 résultat)";
  const cols = colsRaw.trim() === "*" ? Object.keys(rows[0]) : colsRaw.split(",").map(s => s.trim());
  return [cols.join(" | "), "-".repeat(cols.join(" | ").length), ...rows.map(r => cols.map(c => r[c] !== undefined ? r[c] : "NULL").join(" | "))].join("\n");
}