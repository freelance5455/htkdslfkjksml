document.addEventListener("DOMContentLoaded", () => {

    let tableData = [];
    let originalData = [];
    let fileLoaded = false;
    let currentMode = "";
    let sumeazaActive = false;


    // =========================
    // ELEMENTE
    // =========================

    const fileInput = document.getElementById("fileInput");
    const tableBody = document.querySelector("#dataTable tbody");
    const dataTable = document.getElementById("dataTable");

    const btnProducere = document.getElementById("btnProducere");
    const btnDepozit = document.getElementById("btnDepozit");
    const btnReset = document.getElementById("btnReset");
    const btnSumeaza = document.getElementById("btnSumeaza");
    const btnPrint = document.getElementById("btnPrint");

    const toastContainer = document.getElementById("toastContainer");
    const totalsDiv = document.getElementById("totalsDiv");
    const depozitTotalDiv = document.getElementById("depozitTotal");

    const pasteText = document.getElementById("pasteText");
    const btnPaste = document.getElementById("btnPaste");
    const btnExtractText = document.getElementById("btnExtractText");
    const btnClearText = document.getElementById("btnClearText");
    const extractInfo = document.getElementById("extractInfo");

    const internetStatus = document.getElementById("internetStatus");
    const internetText = document.getElementById("internetText");


    // ============================================================
    // INTERNET STATUS
    // ============================================================

    function updateInternetStatus() {

        if (!internetStatus || !internetText) return;

        if (navigator.onLine) {

            internetStatus.classList.remove("offline");
            internetStatus.classList.add("online");

            internetText.textContent = "Online";

        } else {

            internetStatus.classList.remove("online");
            internetStatus.classList.add("offline");

            internetText.textContent = "Offline";
        }
    }


    // Verificare imediată la pornire
    updateInternetStatus();


    // Internet revenit
    window.addEventListener("online", () => {

        updateInternetStatus();

        showToast(
            "Conexiunea la internet a revenit.",
            "success"
        );

    });


    // Internet pierdut
    window.addEventListener("offline", () => {

        updateInternetStatus();

        showToast(
            "Conexiunea la internet a fost pierdută.",
            "danger"
        );

    });


    // =========================
    // TOAST
    // =========================

    function showToast(msg, type = "success") {

        if (!toastContainer) return;

        const t = document.createElement("div");

        t.className =
            "toast toast-" + type;

        let icon = "fa-info-circle";

        if (type === "success")
            icon = "fa-check-circle";

        if (type === "danger")
            icon = "fa-times-circle";

        t.innerHTML =
            `<i class="fa ${icon}"></i> ${msg}`;

        toastContainer.appendChild(t);

        requestAnimationFrame(() => {

            t.classList.add("show");

        });

        setTimeout(() => {

            t.classList.remove("show");

            setTimeout(() => {

                t.remove();

            }, 400);

        }, 3000);
    }


    // Dacă nu există internet la pornire
    if (!navigator.onLine) {

        setTimeout(() => {

            showToast(
                "SaltConfort are nevoie de internet pentru a funcționa.",
                "danger"
            );

        }, 500);
    }


    // =========================
    // CORECTARE NOMENCLATOR
    // =========================

    function cleanNomenclator(value) {

        return String(value || "")
            .trim()

            .replace(/cocos/gi, "cocos")

            .replace(
                /toppermemory/gi,
                "Topper Memory"
            )

            .replace(
                /topperlatex/gi,
                "Topper Latex"
            )

            .replace(
                /toppercocos/gi,
                "Topper Cocos"
            );
    }


    // =========================
    // CATEGORII
    // =========================

    function getCategory(nomenclator) {

        const l =
            String(nomenclator || "")
                .toLowerCase()
                .trim();


        if (
            l.includes("topper memory") ||
            l.includes("topper latex") ||
            l.includes("topper cocos") ||
            /\*\s*7(\D|$)/.test(l)
        ) {

            return "Spuma/Topper 7";
        }


        if (
            /p\.?\s*s\.?\s*\+?\s*(memory|mem)\b/i.test(l) ||
            /p\.?\s*s\.?\s*\+?\s*latex\b/i.test(l)
        ) {

            return "Pocket";
        }


        if (
            l.includes("cocos") &&
            !l.includes("topper") &&
            !/\*\s*(5|7|10|15|20)(\D|$)/.test(l)
        ) {

            return "Arcuri N86 Cocos";
        }


        if (
            [
                "ideal",
                "troia",
                "orient",
                "ocean",
                "pocket"
            ].some(k => l.includes(k))
        ) {

            return "Pocket";
        }


        if (
            ["super", "forte", "memory"].some(k => l.includes(k)) &&
            !l.includes("topper memory")
        ) {

            return "Arcuri N73";
        }


        if (
            ["clasic", "lux", "plus"].some(k => l.includes(k))
        ) {

            return "Arcuri N86";
        }


        if (/\*\s*5(\D|$)/.test(l)) {

            return "Spuma 5";
        }


        if (/\*\s*10(\D|$)/.test(l)) {

            return "Spuma 10";
        }


        if (/\*\s*15(\D|$)/.test(l)) {

            return "Spuma 15";
        }


        if (/\*\s*20(\D|$)/.test(l)) {

            return "Spuma 20";
        }


        return "Altele";
    }


    // =========================
    // DIMENSIUNE
    // =========================

    function getSize(nomenclator) {

        const match =
            String(nomenclator || "")
                .match(/(\d+(\.\d+)?)/);

        return match
            ? parseFloat(match[0])
            : 0;
    }


    // =========================
    // AFIȘARE TABEL
    // =========================

    function renderTable(data) {

        if (!data || data.length === 0) {

            tableBody.innerHTML =
                `<tr>
                    <td colspan="3">
                        Nu există date încă.
                    </td>
                </tr>`;

            dataTable.style.display = "none";

            totalsDiv.innerHTML = "";
            depozitTotalDiv.innerHTML = "";

            return;
        }


        dataTable.style.display = "table";


        if (currentMode === "producere") {

            dataTable.classList.add("producere");

            btnSumeaza.disabled = false;

        } else {

            dataTable.classList.remove("producere");

            btnSumeaza.disabled = true;
        }


        const thead =
            dataTable.querySelector("thead tr");


        if (currentMode === "producere") {

            thead.innerHTML = `
                <th>Nomenclator</th>
                <th>Cantitate</th>
            `;

        } else {

            thead.innerHTML = `
                <th>Client</th>
                <th>Nomenclator</th>
                <th>Cantitate</th>
            `;
        }


        tableBody.innerHTML = "";


        const categories = [

            "Pocket",
            "Arcuri N73",
            "Arcuri N86",
            "Arcuri N86 Cocos",
            "Spuma 5",
            "Spuma/Topper 7",
            "Spuma 10",
            "Spuma 15",
            "Spuma 20",
            "Altele"

        ];


        categories.forEach(category => {

            let filtered =
                data.filter(
                    d =>
                        getCategory(d.Nomenclator) === category
                );


            if (filtered.length === 0) return;


            if (category === "Spuma/Topper 7") {

                filtered.sort((a, b) => {

                    const aIs7 =
                        /\*\s*7(\D|$)/.test(
                            String(a.Nomenclator).toLowerCase()
                        );

                    const bIs7 =
                        /\*\s*7(\D|$)/.test(
                            String(b.Nomenclator).toLowerCase()
                        );

                    const aIsTopper =
                        /topper/i.test(a.Nomenclator);

                    const bIsTopper =
                        /topper/i.test(b.Nomenclator);


                    if (aIs7 && !bIs7) return -1;

                    if (!aIs7 && bIs7) return 1;

                    if (aIsTopper && !bIsTopper) return 1;

                    if (!aIsTopper && bIsTopper) return -1;


                    return (
                        getSize(a.Nomenclator) -
                        getSize(b.Nomenclator)
                    );
                });

            } else {

                filtered.sort(
                    (a, b) =>
                        getSize(a.Nomenclator) -
                        getSize(b.Nomenclator)
                );
            }


            const colspan =
                currentMode === "producere"
                    ? 2
                    : 3;


            tableBody.innerHTML += `
                <tr class="categoria-row">
                    <td colspan="${colspan}">
                        ${category}
                    </td>
                </tr>
            `;


            filtered.forEach(f => {

                if (currentMode === "producere") {

                    tableBody.innerHTML += `
                        <tr>
                            <td>${f.Nomenclator}</td>
                            <td>${f.Cant}</td>
                        </tr>
                    `;

                } else {

                    tableBody.innerHTML += `
                        <tr>
                            <td>${f.Client || ""}</td>
                            <td>${f.Nomenclator || ""}</td>
                            <td class="cant-depozit">
                                ${f.Cant || 0}
                            </td>
                        </tr>
                    `;
                }

            });

        });


        if (currentMode === "producere") {

            const total =
                data.reduce(
                    (sum, r) =>
                        sum + (Number(r.Cant) || 0),
                    0
                );

            totalsDiv.innerHTML =
                `Total: ${total}`;

            depozitTotalDiv.innerHTML = "";

        } else {

            totalsDiv.innerHTML = "";

            const totalDepozit =
                data.reduce(
                    (sum, r) =>
                        sum + (Number(r.Cant) || 0),
                    0
                );

            depozitTotalDiv.innerHTML =
                `Total Cantitate: ${totalDepozit}`;
        }
    }


    // ============================================================
    // EXCEL / CSV
    // ============================================================

    if (fileInput) {

        fileInput.addEventListener("change", e => {

            const file =
                e.target.files[0];

            if (!file) return;


            const reader =
                new FileReader();


            reader.onload = ev => {

                try {

                    const wb =
                        XLSX.read(
                            new Uint8Array(
                                ev.target.result
                            ),
                            { type: "array" }
                        );


                    const ws =
                        wb.Sheets[
                            wb.SheetNames[0]
                        ];


                    const jsonData =
                        XLSX.utils.sheet_to_json(
                            ws,
                            { defval: "" }
                        );


                    if (jsonData.length === 0) {

                        showToast(
                            "Fișier gol!",
                            "danger"
                        );

                        return;
                    }


                    tableData =
                        jsonData.map(r => ({

                            Data:
                                r["Data"] || "",

                            Repartizare:
                                r["Repartizare"] || "",

                            Client:
                                r["Client"] || "",

                            Nomenclator:
                                cleanNomenclator(
                                    r["Nomenclator"] || ""
                                ),

                            Cant:
                                Number(
                                    r["Cant"] ||
                                    r["Cantitate"] ||
                                    0
                                )
                        }));


                    originalData =
                        JSON.parse(
                            JSON.stringify(tableData)
                        );


                    fileLoaded = true;

                    currentMode = "";

                    sumeazaActive = false;


                    btnSumeaza.textContent =
                        "Sumează!";


                    btnSumeaza.classList.remove(
                        "btn-success"
                    );


                    btnSumeaza.classList.add(
                        "btn-danger"
                    );


                    btnSumeaza.disabled = true;


                    showToast(
                        "Fișier încărcat! Apasă Producere sau Depozit.",
                        "success"
                    );

                } catch (error) {

                    console.error(error);

                    showToast(
                        "Nu am putut citi fișierul!",
                        "danger"
                    );
                }
            };


            reader.readAsArrayBuffer(file);
        });
    }


    // ============================================================
    // GOOGLE LENS - LIPEȘTE
    // ============================================================

    if (btnPaste) {

        btnPaste.addEventListener(
            "click",
            async () => {

                try {

                    const text =
                        await navigator.clipboard.readText();


                    if (!text) {

                        showToast(
                            "Clipboard-ul este gol!",
                            "danger"
                        );

                        return;
                    }


                    pasteText.value = text;


                    showToast(
                        "Text lipit!",
                        "success"
                    );

                } catch (error) {

                    showToast(
                        "Nu pot accesa clipboard-ul. Lipește textul manual.",
                        "info"
                    );


                    if (pasteText) {
                        pasteText.focus();
                    }
                }
            }
        );
    }


    // ============================================================
    // GOOGLE LENS - EXTRAGERE
    // ============================================================

    function extractLensTable(text) {

        const result = [];


        if (!text || !text.trim()) {
            return result;
        }


        text = text
            .replace(/\r\n/g, "\n")
            .replace(/\r/g, "\n");


        const lines =
            text
                .split("\n")
                .map(line => line.trim())
                .filter(line => line !== "");


        let currentClient = "";


        const productRegex =
            /^\d+\s*\*\s*\d+(?:.*)?$/;


        for (let i = 0; i < lines.length; i++) {

            let line =
                lines[i].trim();


            if (!line) continue;


            const lower =
                line.toLowerCase();


            if (
                lower === "data" ||
                lower === "repartizare" ||
                lower === "client" ||
                lower === "nomenclator" ||
                lower === "cant" ||
                lower === "cant." ||
                lower === "cantitate" ||
                lower === "note!" ||
                lower.includes("nomenclator")
            ) {
                continue;
            }


            if (
                /^\d{1,2}[-./]\w+[-./]\d{2,4}$/i.test(line) ||
                /^\d{1,2}[-./]\d{1,2}[-./]\d{2,4}$/.test(line)
            ) {
                continue;
            }


            if (
                /^chișinău$/i.test(line) ||
                /^chisinau$/i.test(line)
            ) {
                continue;
            }


            if (line.includes("\t")) {

                const parts =
                    line
                        .split("\t")
                        .map(x => x.trim())
                        .filter(Boolean);


                const productIndex =
                    parts.findIndex(
                        p => productRegex.test(p)
                    );


                if (productIndex !== -1) {

                    const nomenclator =
                        cleanNomenclator(
                            parts[productIndex]
                        );


                    let quantity = 1;


                    if (
                        parts[productIndex + 1] &&
                        /^\d+(?:[.,]\d+)?$/.test(
                            parts[productIndex + 1]
                        )
                    ) {

                        quantity =
                            Number(
                                parts[productIndex + 1]
                                    .replace(",", ".")
                            );
                    }


                    if (productIndex > 0) {

                        const possibleClient =
                            parts[productIndex - 1];


                        if (
                            possibleClient &&
                            !/^\d/.test(
                                possibleClient
                            )
                        ) {
                            currentClient =
                                possibleClient;
                        }
                    }


                    result.push({

                        Data: "",

                        Repartizare: "",

                        Client: currentClient,

                        Nomenclator:
                            nomenclator,

                        Cant: quantity
                    });


                    continue;
                }
            }


            if (productRegex.test(line)) {

                const nomenclator =
                    cleanNomenclator(line);


                let quantity = 1;


                if (
                    i + 1 < lines.length &&
                    /^\d+(?:[.,]\d+)?$/.test(
                        lines[i + 1]
                    )
                ) {

                    quantity =
                        Number(
                            lines[i + 1]
                                .replace(",", ".")
                        );

                    i++;
                }


                result.push({

                    Data: "",

                    Repartizare: "",

                    Client: currentClient,

                    Nomenclator:
                        nomenclator,

                    Cant: quantity
                });


                continue;
            }


            if (
                line.length > 1 &&
                !/^\d+(?:[.,]\d+)?$/.test(line)
            ) {

                currentClient = line;
            }
        }


        return result;
    }


    // ============================================================
    // BUTON EXTRAGE TABEL
    // ============================================================

    if (btnExtractText) {

        btnExtractText.addEventListener(
            "click",
            () => {

                const text =
                    pasteText
                        ? pasteText.value
                        : "";


                if (!text.trim()) {

                    showToast(
                        "Lipește mai întâi textul din Google Lens!",
                        "danger"
                    );

                    return;
                }


                const extracted =
                    extractLensTable(text);


                if (extracted.length === 0) {

                    showToast(
                        "Nu am găsit produse în text!",
                        "danger"
                    );


                    if (extractInfo) {

                        extractInfo.innerHTML =
                            "Nu au fost găsite produse.";
                    }

                    return;
                }


                tableData = extracted;


                originalData =
                    JSON.parse(
                        JSON.stringify(extracted)
                    );


                fileLoaded = true;

                currentMode = "";

                sumeazaActive = false;


                btnSumeaza.textContent =
                    "Sumează!";


                btnSumeaza.classList.remove(
                    "btn-success"
                );


                btnSumeaza.classList.add(
                    "btn-danger"
                );


                btnSumeaza.disabled = true;


                dataTable.style.display =
                    "none";


                if (extractInfo) {

                    extractInfo.innerHTML = `
                        <span style="
                            color:#16a34a;
                            font-weight:600;
                        ">
                            ✓ Au fost extrase ${extracted.length}
                            produse. Apasă Producere sau Depozit.
                        </span>
                    `;
                }


                showToast(
                    `Extrase ${extracted.length} produse!`,
                    "success"
                );
            }
        );
    }


    // ============================================================
    // ȘTERGE TEXT
    // ============================================================

    if (btnClearText) {

        btnClearText.addEventListener(
            "click",
            () => {

                if (pasteText) {
                    pasteText.value = "";
                }


                if (extractInfo) {
                    extractInfo.innerHTML = "";
                }


                showToast(
                    "Textul a fost șters.",
                    "info"
                );
            }
        );
    }


    // ============================================================
    // PRODUCERE
    // ============================================================

    if (btnProducere) {

        btnProducere.addEventListener(
            "click",
            () => {

                if (
                    !fileLoaded ||
                    tableData.length === 0
                ) {

                    showToast(
                        "Întâi încarcă un fișier sau extrage textul din Google Lens!",
                        "danger"
                    );

                    return;
                }


                currentMode =
                    "producere";


                renderTable(tableData);


                showToast(
                    "Producere afișată!",
                    "success"
                );
            }
        );
    }


    // ============================================================
    // DEPOZIT
    // ============================================================

    if (btnDepozit) {

        btnDepozit.addEventListener(
            "click",
            () => {

                if (
                    !fileLoaded ||
                    tableData.length === 0
                ) {

                    showToast(
                        "Întâi încarcă un fișier sau extrage textul din Google Lens!",
                        "danger"
                    );

                    return;
                }


                currentMode =
                    "depozit";


                renderTable(tableData);


                showToast(
                    "Depozit afișat!",
                    "info"
                );
            }
        );
    }


    // ============================================================
    // SUMEAZĂ
    // ============================================================

    if (btnSumeaza) {

        btnSumeaza.addEventListener(
            "click",
            () => {

                if (currentMode !== "producere") {

                    showToast(
                        "Sumarea este disponibilă doar pentru Producere!",
                        "info"
                    );

                    return;
                }


                if (!sumeazaActive) {

                    const grouped = {};


                    tableData.forEach(r => {

                        const key =
                            r.Nomenclator;


                        if (grouped[key]) {

                            grouped[key] +=
                                Number(r.Cant) || 0;

                        } else {

                            grouped[key] =
                                Number(r.Cant) || 0;
                        }
                    });


                    tableData =
                        Object.entries(grouped)
                            .map(
                                ([Nomenclator, Cant]) => ({
                                    Nomenclator,
                                    Cant
                                })
                            );


                    sumeazaActive = true;


                    btnSumeaza.textContent =
                        "Original";


                    btnSumeaza.classList.remove(
                        "btn-danger"
                    );


                    btnSumeaza.classList.add(
                        "btn-success"
                    );


                    showToast(
                        "Valorile au fost sumate!",
                        "success"
                    );

                } else {

                    tableData =
                        JSON.parse(
                            JSON.stringify(originalData)
                        );


                    sumeazaActive = false;


                    btnSumeaza.textContent =
                        "Sumează!";


                    btnSumeaza.classList.remove(
                        "btn-success"
                    );


                    btnSumeaza.classList.add(
                        "btn-danger"
                    );


                    showToast(
                        "S-a revenit la valorile originale!",
                        "info"
                    );
                }


                renderTable(tableData);
            }
        );
    }


    // ============================================================
    // RESET
    // ============================================================

    if (btnReset) {

        btnReset.addEventListener(
            "click",
            () => {

                tableData = [];

                originalData = [];

                fileLoaded = false;

                currentMode = "";

                sumeazaActive = false;


                renderTable([]);


                if (fileInput) {
                    fileInput.value = "";
                }


                btnSumeaza.disabled = true;

                btnSumeaza.textContent =
                    "Sumează!";


                btnSumeaza.classList.remove(
                    "btn-success"
                );


                btnSumeaza.classList.add(
                    "btn-danger"
                );


                if (pasteText) {
                    pasteText.value = "";
                }


                if (extractInfo) {
                    extractInfo.innerHTML = "";
                }


                showToast(
                    "Tot a fost șters.",
                    "danger"
                );
            }
        );
    }


    // ============================================================
    // PRINT
    // ============================================================

    if (btnPrint) {

        btnPrint.addEventListener(
            "click",
            () => {

                if (
                    !fileLoaded ||
                    tableData.length === 0
                ) {

                    showToast(
                        "Întâi încarcă un fișier sau extrage textul!",
                        "danger"
                    );

                    return;
                }


                if (!currentMode) {

                    showToast(
                        "Alege Producere sau Depozit înainte de Print!",
                        "info"
                    );

                    return;
                }


                const printContent =
                    document.createElement("div");


                printContent.innerHTML = `

                    <h2 style="text-align:center;">
                        ${
                            currentMode === "producere"
                                ? "Producere"
                                : "Depozit"
                        }
                    </h2>

                    ${dataTable.outerHTML}

                    <div style="
                        margin-top:10px;
                        font-weight:700;
                        font-size:1rem;
                        text-align:center;
                    ">
                        ${
                            currentMode === "producere"
                                ? totalsDiv.innerHTML
                                : depozitTotalDiv.innerHTML
                        }
                    </div>
                `;


                const newWin =
                    window.open(
                        "",
                        "",
                        "width=900,height=700"
                    );


                if (!newWin) {

                    showToast(
                        "Fereastra de imprimare a fost blocată.",
                        "danger"
                    );

                    return;
                }


                newWin.document.write(`
                    <html>

                    <head>

                        <title>Print</title>

                        <link
                            href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css"
                            rel="stylesheet"
                        >

                        <style>

                            table {
                                width:auto;
                                border-collapse:collapse;
                            }

                            th,
                            td {
                                border:1px solid #333;
                                padding:4px;
                                text-align:left;
                            }

                            td.cant-depozit {
                                text-align:center;
                            }

                            .categoria-row {
                                background:#e2e8f0;
                                font-weight:700;
                            }

                        </style>

                    </head>

                    <body>

                        ${printContent.innerHTML}

                    </body>

                    </html>
                `);


                newWin.document.close();

                newWin.focus();


                setTimeout(() => {

                    newWin.print();

                    newWin.close();

                }, 300);
            }
        );
    }


    console.log(
        "SaltConfort script.js încărcat corect."
    );

});