자동 이미지 배틀 - Android Studio 프로젝트

중요: 이 ZIP은 APK 자체가 아니라 APK를 빌드할 수 있는 Android Studio 프로젝트입니다.

빌드 방법(컴퓨터의 Android Studio 필요):
1. ZIP 압축을 풉니다.
2. Android Studio에서 압축을 푼 AutoImageBattle 폴더를 엽니다.
3. Gradle Sync가 끝날 때까지 기다립니다. Android SDK Platform 35가 필요할 수 있습니다.
4. Build > Build Bundle(s) / APK(s) > Build APK(s)를 선택합니다.
5. 생성된 APK는 app/build/outputs/apk/debug/app-debug.apk 입니다.

HTML 게임은 app/src/main/assets/auto_image_battle_fixed.html에 들어 있습니다.
WebView에서 실행하며 파일 선택 기능을 연결해 두었습니다. 실제 기기에서 이미지 업로드 기능을 테스트하세요.
