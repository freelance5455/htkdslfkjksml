package com.example.hansha

import org.opencv.core.*
import org.opencv.imgproc.Imgproc
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

class Detector {
    private val tpl = arrayOfNulls<Mat>(4)
    private val SIZE = 36            // テンプレートの一辺(縮小画像px)
    private val THRESH = 0.70        // 一致度の閾値

    fun register(i: Int, gray: Mat, cx: Int, cy: Int) {
        val x = (cx - SIZE / 2).coerceIn(0, gray.cols() - SIZE)
        val y = (cy - SIZE / 2).coerceIn(0, gray.rows() - SIZE)
        tpl[i]?.release()
        tpl[i] = Mat(gray, Rect(x, y, SIZE, SIZE)).clone()
    }

    fun find(gray: Mat, i: Int): Point? {
        val t = tpl[i] ?: return null
        val res = Mat()
        Imgproc.matchTemplate(gray, t, res, Imgproc.TM_CCOEFF_NORMED)
        val m = Core.minMaxLoc(res)
        res.release()
        if (m.maxVal < THRESH) return null
        return Point(m.maxLoc.x + t.cols() / 2.0, m.maxLoc.y + t.rows() / 2.0)
    }

    // ゲーム側の照準線(キャラから伸びる直線)を検出し、先端側の点を返す
    fun aim(gray: Mat, c: Point, selfMask: Mat): Point? {
        val edges = Mat()
        Imgproc.Canny(gray, edges, 100.0, 200.0)
        val dil = Mat()
        Imgproc.dilate(selfMask, dil, Imgproc.getStructuringElement(Imgproc.MORPH_RECT, Size(9.0, 9.0)))
        edges.setTo(Scalar(0.0), dil)
        dil.release()
        val lines = Mat()
        Imgproc.HoughLinesP(edges, lines, 1.0, Math.PI / 180, 60, gray.cols() * 0.12, 10.0)
        edges.release()
        val near = gray.cols() * 0.06
        var best: Point? = null
        var bl = 0.0
        for (i in 0 until lines.rows()) {
            val l = lines.get(i, 0)
            val p1 = Point(l[0], l[1]); val p2 = Point(l[2], l[3])
            val d1 = hypot(p1.x - c.x, p1.y - c.y); val d2 = hypot(p2.x - c.x, p2.y - c.y)
            if (min(d1, d2) > near) continue
            val len = max(d1, d2)
            if (len > bl) { bl = len; best = if (d1 < d2) p2 else p1 }
        }
        lines.release()
        return best
    }
}
