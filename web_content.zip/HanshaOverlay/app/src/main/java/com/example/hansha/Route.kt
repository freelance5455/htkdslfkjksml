package com.example.hansha

import android.graphics.PointF
import android.graphics.RectF
import kotlin.math.hypot
import kotlin.math.min

object Route {
    // 壁での鏡面反射を n 回。貫通のみなので壁以外は無視
    fun compute(s: PointF, d: PointF, f: RectF, r: Float, n: Int): List<PointF> {
        val l = hypot(d.x, d.y)
        if (l < 1f) return emptyList()
        var dx = d.x / l; var dy = d.y / l
        var x = s.x; var y = s.y
        val out = arrayListOf(PointF(x, y))
        repeat(n + 1) {
            val tx = if (dx > 0) (f.right - r - x) / dx else if (dx < 0) (f.left + r - x) / dx else 1e9f
            val ty = if (dy > 0) (f.bottom - r - y) / dy else if (dy < 0) (f.top + r - y) / dy else 1e9f
            val t = min(tx, ty).coerceAtLeast(0f)
            x += dx * t; y += dy * t
            out.add(PointF(x, y))
            if (tx <= ty) dx = -dx
            if (ty <= tx) dy = -dy
        }
        return out
    }
}
