package com.example.hansha

import android.content.Context
import android.graphics.*
import android.view.View

class OverlayView(c: Context) : View(c) {
    @Volatile var pts: List<PointF> = emptyList()
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFF00FF.toInt(); strokeWidth = 8f; style = Paint.Style.STROKE
    }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFF00FF.toInt() }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textSize = 26f; textAlign = Paint.Align.CENTER
    }

    override fun onDraw(c: Canvas) {
        val p = pts
        if (p.size < 2) return
        for (i in 1 until p.size) c.drawLine(p[i - 1].x, p[i - 1].y, p[i].x, p[i].y, line)
        for (i in 1 until p.size - 1) {
            c.drawCircle(p[i].x, p[i].y, 20f, dot)
            c.drawText("$i", p[i].x, p[i].y + 9f, txt)
        }
    }
}
