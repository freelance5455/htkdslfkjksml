package com.example.hansha

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.graphics.PointF
import android.graphics.RectF
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.util.DisplayMetrics
import android.view.*
import android.widget.Button
import android.widget.LinearLayout
import org.opencv.android.OpenCVLoader
import org.opencv.android.Utils
import org.opencv.core.*
import org.opencv.imgproc.Imgproc

class CaptureService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var bg: Handler
    private val ui = Handler(Looper.getMainLooper())
    private val ht = HandlerThread("cap").apply { start() }
    private var proj: MediaProjection? = null
    private var reader: ImageReader? = null
    private var vd: VirtualDisplay? = null
    private lateinit var overlay: OverlayView
    private var panel: View? = null
    private val det = Detector()
    private var lastGray: Mat? = null
    @Volatile private var turn = 0
    @Volatile private var frozen = false
    @Volatile private var running = true
    private var sw = 0
    private var sh = 0
    private val S = 2                 // 画面収録の縮小率
    private val BOUNCES = 6

    // ★要調整: 盤面の範囲(画面に対する割合)
    private fun field() = RectF(sw * 0.03f, sh * 0.20f, sw * 0.97f, sh * 0.80f)

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i == null) return START_NOT_STICKY
        OpenCVLoader.initLocal()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("cap", "cap", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "cap").setContentTitle("反射オーバーレイ実行中")
            .setSmallIcon(android.R.drawable.ic_menu_view).build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)

        val code = i.getIntExtra("code", 0)
        val data = i.getParcelableExtra<Intent>("data") ?: return START_NOT_STICKY
        val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        bg = Handler(ht.looper)
        proj = mgr.getMediaProjection(code, data)
        proj!!.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, bg)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(dm)
        sw = dm.widthPixels; sh = dm.heightPixels
        val cw = sw / S; val chh = sh / S
        reader = ImageReader.newInstance(cw, chh, PixelFormat.RGBA_8888, 2)
        vd = proj!!.createVirtualDisplay("cap", cw, chh, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, bg)
        addOverlay(); addPanel()
        bg.post(object : Runnable {
            override fun run() {
                if (!running) return
                try { process() } catch (e: Exception) { }
                bg.postDelayed(this, 120)
            }
        })
        return START_NOT_STICKY
    }

    private fun conv(img: Image): Pair<Mat, Mat> {
        val p = img.planes[0]; val w = img.width; val h = img.height
        val pad = (p.rowStride - p.pixelStride * w) / p.pixelStride
        val bmp = Bitmap.createBitmap(w + pad, h, Bitmap.Config.ARGB_8888)
        bmp.copyPixelsFromBuffer(p.buffer)
        val rgba = Mat(); Utils.bitmapToMat(bmp, rgba); bmp.recycle()
        val sub = rgba.submat(0, h, 0, w)
        val gray = Mat(); Imgproc.cvtColor(sub, gray, Imgproc.COLOR_RGBA2GRAY)
        // 自分が描いたマゼンタ線を検出から除外するためのマスク
        val mask = Mat()
        Core.inRange(sub, Scalar(200.0, 0.0, 200.0, 0.0), Scalar(255.0, 80.0, 255.0, 255.0), mask)
        rgba.release()
        return Pair(gray, mask)
    }

    private fun process() {
        val img = reader?.acquireLatestImage() ?: return
        if (frozen) { img.close(); return }
        val (gray, mask) = try { conv(img) } finally { img.close() }
        val old = lastGray; lastGray = gray; old?.release()
        var pts: List<PointF> = emptyList()
        val c = det.find(gray, turn)
        if (c != null) {
            val a = det.aim(gray, c, mask)
            if (a != null) {
                val s = PointF((c.x * S).toFloat(), (c.y * S).toFloat())
                val d = PointF(((a.x - c.x) * S).toFloat(), ((a.y - c.y) * S).toFloat())
                pts = Route.compute(s, d, field(), sw * 0.035f, BOUNCES)
            }
        }
        mask.release()
        ui.post { overlay.pts = pts; overlay.invalidate() }
    }

    private fun lp(touch: Boolean, w: Int, h: Int): WindowManager.LayoutParams {
        var fl = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        if (!touch) fl = fl or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        return WindowManager.LayoutParams(w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, fl, PixelFormat.TRANSLUCENT)
    }

    private fun addOverlay() {
        overlay = OverlayView(this)
        wm.addView(overlay, lp(false, -1, -1))
    }

    private fun btn(t: String, f: () -> Unit) = Button(this).apply {
        text = t; textSize = 12f; minWidth = 0; minimumWidth = 0
        setPadding(10, 0, 10, 0); setOnClickListener { f() }
    }

    private fun addPanel() {
        val row1 = LinearLayout(this); val row2 = LinearLayout(this)
        val nums = listOf("①", "②", "③", "④")
        nums.forEachIndexed { i, s -> row1.addView(btn(s) { turn = i }) }
        nums.forEachIndexed { i, s -> row2.addView(btn("登$s") { startReg(i) }) }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(0xAA000000.toInt())
            addView(row1); addView(row2); addView(btn("終了") { stopSelf() })
        }
        panel = col
        val p = lp(true, -2, -2); p.gravity = Gravity.TOP or Gravity.END
        wm.addView(col, p)
    }

    // 登録: ゲーム画面上でキャラをタップ → その周辺を①〜④のテンプレートとして保存
    private fun startReg(i: Int) {
        frozen = true
        val v = View(this)
        v.setBackgroundColor(0x22FFFF00)
        v.setOnTouchListener { view, e ->
            if (e.action == MotionEvent.ACTION_DOWN) {
                val x = (e.rawX / S).toInt(); val y = (e.rawY / S).toInt()
                bg.post { lastGray?.let { det.register(i, it, x, y) }; frozen = false }
                wm.removeView(view)
            }
            true
        }
        wm.addView(v, lp(true, -1, -1))
    }

    override fun onDestroy() {
        running = false
        try { wm.removeView(overlay) } catch (e: Exception) { }
        try { panel?.let { wm.removeView(it) } } catch (e: Exception) { }
        vd?.release(); proj?.stop(); ht.quitSafely()
        super.onDestroy()
    }
}
