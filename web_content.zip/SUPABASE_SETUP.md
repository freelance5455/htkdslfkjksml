# إعداد سحابة Supabase لمنصة القائد التعليمية (مستر زاهر جمال)

يوضح هذا الدليل كيفية ربط منصة القائد التعليمية بمشروع **Supabase** لتخزين البيانات سحابياً والمصادقة الآمنة وحماية المحتوى عبر سياسات **Row Level Security (RLS)**.

---

## 1. إنشاء المشروع في Supabase
1. توجه إلى [https://supabase.com](https://supabase.com) وأنشئ حساباً أو سجل دخولك.
2. أنشئ مشروعاً جديداً باسم `alqaed-platform`.
3. انسخ كلاً من:
   - **Project URL** (مثل: `https://xyzproject.supabase.co`)
   - **anon / public API Key**

---

## 2. كود SQL لإنشاء الجداول وسياسات الأمان (RLS)

قم بفتح **SQL Editor** في لوحة تحكم Supabase والصق الكود التالي واضغط على **Run**:

```sql
-- تفعيل ملحق UUID
create extension if not exists "uuid-ossp";

-- جدول المستخدمين والطلاب (Profiles)
create table public.profiles (
  id uuid references auth.users on delete cascade primary key,
  full_name text not null,
  phone text unique not null,
  academic_stage text not null, -- 'أولى ثانوي', 'بكالوريا', 'تالتة ثانوي'
  role text not null default 'student', -- 'student' or 'admin'
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- جدول الكورسات (Courses)
create table public.courses (
  id text primary key,
  title text not null,
  subtitle text,
  description text,
  is_published boolean default true,
  grade_order integer not null,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- جدول المحاضرات (Lessons)
create table public.lessons (
  id text primary key,
  course_id text references public.courses(id) on delete cascade not null,
  title text not null,
  status text not null default 'لسه هتنزل', -- 'لسه هتنزل' or 'متاحة الآن'
  description text,
  video_url text,
  pdf_url text,
  is_published boolean default true,
  order_index integer default 1,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- جدول التنبيهات (Announcements)
create table public.announcements (
  id text primary key,
  title text not null,
  content text not null,
  date_string text not null,
  is_pinned boolean default false,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- تفعيل سياسات الأمان Row Level Security (RLS)
alter table public.profiles enable row level security;
alter table public.courses enable row level security;
alter table public.lessons enable row level security;
alter table public.announcements enable row level security;

-- 1. سياسات جدول Profiles
create policy "Users can read own profile"
  on public.profiles for select
  using (auth.uid() = id);

create policy "Admins can view all profiles"
  on public.profiles for select
  using (
    exists (
      select 1 from public.profiles
      where id = auth.uid() and role = 'admin'
    )
  );

-- 2. سياسات جدول الكورسات
create policy "Anyone can view published courses"
  on public.courses for select
  using (is_published = true);

create policy "Admins can insert, update, delete courses"
  on public.courses for all
  using (
    exists (
      select 1 from public.profiles
      where id = auth.uid() and role = 'admin'
    )
  );

-- 3. سياسات جدول المحاضرات
create policy "Anyone can view published lessons"
  on public.lessons for select
  using (is_published = true);

create policy "Admins can modify lessons"
  on public.lessons for all
  using (
    exists (
      select 1 from public.profiles
      where id = auth.uid() and role = 'admin'
    )
  );

-- 4. سياسات جدول التنبيهات
create policy "Anyone can view announcements"
  on public.announcements for select
  using (true);

create policy "Admins can modify announcements"
  on public.announcements for all
  using (
    exists (
      select 1 from public.profiles
      where id = auth.uid() and role = 'admin'
    )
  );

-- إدراج الكورسات الثلاثة المعتمدة فقط مع المحاضرة الأولى بحالة 'لسه هتنزل'
insert into public.courses (id, title, subtitle, description, is_published, grade_order)
values
  ('course_1', 'أولى ثانوي', 'الصف الأول الثانوي - مادة التاريخ', 'منصة القائد مع مستر زاهر جمال: تأسيس شامل لمنهج التاريخ وحل بنك الأسئلة.', true, 1),
  ('course_2', 'بكالوريا', 'مرحلة البكالوريا - مادة التاريخ', 'منصة القائد مع مستر زاهر جمال: تحليل عميق لأحداث التاريخ وربط نواتج التعلم.', true, 2),
  ('course_3', 'تالتة ثانوي', 'الصف الثالث الثانوي - مادة التاريخ', 'منصة القائد مع مستر زاهر جمال: رحلة الـ 60 درجة كاملة في الثانوية العامة.', true, 3)
on conflict (id) do nothing;

insert into public.lessons (id, course_id, title, status, description, is_published, order_index)
values
  ('lesson_1', 'course_1', 'المحاضرة الأولى', 'لسه هتنزل', 'سيتم رفع المحاضرة والمحتوى التعليمي قريباً بواسطة مستر زاهر جمال', true, 1),
  ('lesson_2', 'course_2', 'المحاضرة الأولى', 'لسه هتنزل', 'سيتم رفع المحاضرة والمحتوى التعليمي قريباً بواسطة مستر زاهر جمال', true, 1),
  ('lesson_3', 'course_3', 'المحاضرة الأولى', 'لسه هتنزل', 'سيتم رفع المحاضرة والمحتوى التعليمي قريباً بواسطة مستر زاهر جمال', true, 1)
on conflict (id) do nothing;
```

---

## 3. ربط التطبيق بـ Supabase
يمكنك كتابة الرابط ومفتاح الـ API في:
1. إما من داخل التطبيق: التوجه إلى **لوحة الإدارة** (رمز الدخول: `123456`) -> تبويب **سحابة Supabase** -> إدخال الـ URL والـ Key والضغط على حفظ.
2. أو من خلال ملف `.env`:
```env
SUPABASE_URL=https://your-project.supabase.co
SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```
