# 🍱 Maa Annapurna Tiffin Service - Supabase & Free Hosting Guide

Location: **Kunwar Singh Nagar** | Phone: **+91 9311155593**

---

## ⚡ Part 1: Supabase Free Cloud Database Setup (2 Minutes)

Supabase gives you a 100% free PostgreSQL cloud database with instant realtime synchronization across kitchen tablets, admin laptops, and delivery boy mobile phones.

### Step 1: Create Free Supabase Project
1. Go to **[https://supabase.com](https://supabase.com)** and sign in / sign up (Free).
2. Click **"New Project"**.
3. Enter:
   - **Name:** `Maa-Annapurna-Tiffin`
   - **Database Password:** (Set any strong password)
   - **Region:** `Central India (Mumbai)` or nearest.
4. Click **"Create new project"** and wait ~1 minute.

---

### Step 2: Run Table Setup Script in Supabase
1. In your Supabase project dashboard, open **SQL Editor** from the left navigation bar.
2. Click **"New query"**, paste the following SQL code, and click **RUN**:

```sql
-- ========================================================
-- Maa Annapurna Tiffin Service - Supabase Database Setup
-- ========================================================

-- 1. Create table for Tiffin Management application
CREATE TABLE IF NOT EXISTS public.tiffin_records (
  id TEXT PRIMARY KEY,
  user_id TEXT,
  data JSONB NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2. Enable Row Level Security (RLS)
ALTER TABLE public.tiffin_records ENABLE ROW LEVEL SECURITY;

-- 3. Create Public Access Policy (for Web Client App)
DROP POLICY IF EXISTS "Public access to tiffin records" ON public.tiffin_records;
CREATE POLICY "Public access to tiffin records" 
ON public.tiffin_records 
FOR ALL 
TO anon, authenticated 
USING (true) 
WITH CHECK (true);

-- 4. Enable Realtime updates across devices
ALTER PUBLICATION supabase_realtime ADD TABLE public.tiffin_records;
```

---

### Step 3: Connect Supabase in App
1. Go to Supabase Dashboard &rarr; **Project Settings (gear icon)** &rarr; **API**.
2. Copy these 2 values:
   - **Project URL** (e.g. `https://xxxxxxxxx.supabase.co`)
   - **Project API Keys** &rarr; `anon` `public` key (long string starting with `eyJhbGci...`)
3. Open your Tiffin Tracker App:
   - Click the **"⚡ Supabase"** button in the top header (or go to **Settings &rarr; Supabase Cloud**).
   - Paste your **Project URL** and **Anon Key**.
   - Click **"Save & Connect Supabase"**.
   - You will see the green badge: **"⚡ Supabase Live Connected"**!

---

## 🌐 Part 2: Free 1-Click Hosting Guide

This app is a high-performance web application (HTML/CSS/JS) and can be hosted completely free on any modern hosting provider:

### Option A: Vercel (Recommended - Fastest & 100% Free)
1. Go to **[https://vercel.com](https://vercel.com)** and sign in with GitHub or Email.
2. Drag and drop the `tiffin-tracker-app` folder directly onto the Vercel dashboard.
3. Click **Deploy**.
4. You will get a live HTTPS URL (e.g. `https://maa-annapurna-tiffin.vercel.app`) in 30 seconds!

### Option B: Netlify (Free Drag & Drop)
1. Go to **[https://app.netlify.com/drop](https://app.netlify.com/drop)**.
2. Drag and drop the `tiffin-tracker-app` folder into the browser.
3. Your website is immediately published with free SSL/HTTPS!

### Option C: GitHub Pages (100% Free)
1. Create a repository on GitHub (e.g. `tiffin-tracker-app`).
2. Push or upload these files.
3. Go to **Settings &rarr; Pages &rarr; Branch: main &rarr; Save**.
4. Your site is live at `https://<your-username>.github.io/tiffin-tracker-app`.

---

## 📱 Part 3: WhatsApp "Web Page Not Available" Fix

### Why did this error happen previously?
- Previously, the app used `window.open("https://wa.me/...")`.
- When opened in an Android WebView, mobile browser, or embedded script, `wa.me` performs a **302 Redirect** to `whatsapp://send?...`.
- Android WebViews cannot render `whatsapp://` URLs as HTML pages, so they throw the error:
  `net::ERR_UNKNOWN_URL_SCHEME ("Webpage not available")`.
- Additionally, popup blockers block `window.open` when called inside asynchronous callbacks.

### How it is fixed now:
1. **Universal HTTPS Link**: The app now uses `https://api.whatsapp.com/send?phone=...&text=...`. Because this is a standard HTTPS web URL, Android WebViews **never** crash with `ERR_UNKNOWN_URL_SCHEME`.
2. **Interactive Dispatch Dialog**:
   - 🚀 **"Open WhatsApp"**: Automatically launches WhatsApp safely via clean anchor intent.
   - 📱 **"Direct WhatsApp App"**: Direct link to installed WhatsApp application.
   - 📋 **"Copy Slip Text"**: 1-click fallback copy button. Even if any device has strict security restrictions, you can copy the full bill with 1 tap and paste it into WhatsApp.
   - **Full Preview Box**: You can preview the entire message before sending.
