// Study Dashboard for v2.9.47. Focuses on next actions and uses current clean-bank progress keys.
(function () {
  const GOAL_KEY = "engineeringReviewQuizDailyGoalV1";
  const DAILY_KEY = "engineeringReviewQuizDailyActivityV2CleanBank";
  const $ = id => document.getElementById(id);
  const goalInput = $("daily-goal-input");
  if (!goalInput) return;

  function readJSON(key, fallback) {
    try { return JSON.parse(localStorage.getItem(key)) ?? fallback; }
    catch { return fallback; }
  }
  function todayKey() {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`;
  }
  function setView(view) {
    document.querySelector(`.nav-button[data-view="${view}"]`)?.click();
  }
  function getQuestions() {
    // The app owns this array; expose it through a small accessor added below.
    return window.getEngineeringReviewQuestions?.() || [];
  }
  function render() {
    const goal = Math.max(1, Math.min(200, Number(goalInput.value) || 10));
    const savedGoal = Number(readJSON(GOAL_KEY, 10)) || 10;
    if (document.activeElement !== goalInput && Number(goalInput.value) !== savedGoal) goalInput.value = String(savedGoal);
    const activity = readJSON(DAILY_KEY, {});
    const done = activity.date === todayKey() ? Math.max(0, Number(activity.count) || 0) : 0;
    const currentGoal = Math.max(1, Math.min(200, Number(goalInput.value) || savedGoal || 10));
    const progress = readJSON("engineeringReviewQuizProgressV5CleanBank", {answered:0,correct:0,results:{}});
    const questions = getQuestions();
    const results = progress.results && typeof progress.results === "object" ? progress.results : {};
    const attempts = Object.entries(results).filter(([id]) => questions.some(q => q.id === id));
    const correct = attempts.filter(([, value]) => value === true).length;
    const answered = attempts.length;
    $("dashboard-date").textContent = new Date().toLocaleDateString(undefined, {weekday:"short", month:"short", day:"numeric"});
    $("daily-done").textContent = String(done);
    $("daily-goal-label").textContent = String(currentGoal);
    $("daily-goal-message").textContent = done >= currentGoal ? "Daily goal reached. Great work—keep going if you want." : `${Math.max(0,currentGoal-done)} more question${currentGoal-done===1?"":"s"} to reach today's goal.`;
    const fill = $("daily-goal-fill");
    fill.style.width = `${Math.min(100, done / currentGoal * 100)}%`;
    const track = fill.parentElement;
    track.setAttribute("aria-valuemax", String(currentGoal));
    track.setAttribute("aria-valuenow", String(Math.min(done,currentGoal)));
    $("dash-answered").textContent = String(answered);
    $("dash-correct").textContent = String(correct);
    const accuracyValue = answered ? Math.round(correct / answered * 100) : 0;
    $("dash-accuracy").textContent = answered ? `${accuracyValue}%` : "—";
    const accuracyCard = $("dash-accuracy").closest(".dashboard-metric-accuracy");
    if (accuracyCard) accuracyCard.style.setProperty("--accuracy", `${accuracyValue}%`);
    const unverifiedCount = questions.filter(q => q.answerVerified === false).length;
    $("dash-unverified").textContent = String(unverifiedCount);

    // Daily focus counters are derived from this browser's saved data only.
    const schedule = readJSON("engineeringReviewQuizSpacedReviewV1", {});
    const dueCount = questions.filter(q => schedule[q.id] && Number(schedule[q.id].dueAt) <= Date.now()).length;
    const missedCount = questions.filter(q => Object.prototype.hasOwnProperty.call(results, q.id) && results[q.id] === false).length;
    const dueCountEl = $("dashboard-due-count");
    const missedCountEl = $("dashboard-missed-count");
    const dueNote = $("dashboard-due-note");
    const missedNote = $("dashboard-missed-note");
    if (dueCountEl) dueCountEl.textContent = String(dueCount);
    if (missedCountEl) missedCountEl.textContent = String(missedCount);
    if (dueNote) dueNote.textContent = dueCount ? `${dueCount} question${dueCount === 1 ? " is" : "s are"} ready for spaced review.` : "Nothing is due right now. New review dates are set as you answer scoreable questions.";
    if (missedNote) missedNote.textContent = missedCount ? `${missedCount} question${missedCount === 1 ? " needs" : "s need"} another attempt.` : "No missed answers are recorded yet. Keep practicing to build your review history.";
    const dueButton = $("dashboard-review-due");
    const missedButton = $("dashboard-retry-missed");
    if (dueButton) dueButton.disabled = dueCount === 0;
    if (missedButton) missedButton.disabled = missedCount === 0;

    // Resume the last question opened, falling back to the first unanswered question.
    const savedQuestionId = (() => { try { return localStorage.getItem("engineeringReviewQuizLastQuestionV1") || ""; } catch { return ""; } })();
    const savedQuestion = questions.find(q => q.id === savedQuestionId);
    const firstUnanswered = questions.find(q => !Object.prototype.hasOwnProperty.call(results, q.id));
    const continueQuestion = savedQuestion || firstUnanswered || questions[0] || null;
    const continueTitle = $("dashboard-continue-title");
    const continueDescription = $("dashboard-continue-description");
    const continueButton = $("dashboard-continue-practice");
    if (continueTitle && continueDescription && continueButton) {
      if (!continueQuestion) {
        continueTitle.textContent = "Your question bank is empty";
        continueDescription.textContent = "Add or import reviewed questions before starting a study session.";
        continueButton.textContent = "Open Practice";
        continueButton.disabled = false;
      } else if (savedQuestion) {
        const topic = String(savedQuestion.category || savedQuestion.subject || "Practice question");
        const prompt = String(savedQuestion.prompt || "").replace(/\s+/g, " ").trim();
        continueTitle.textContent = `Last opened: ${topic}`;
        continueDescription.textContent = prompt.length > 130 ? `${prompt.slice(0, 127)}…` : (prompt || "Return to the last question you opened.");
        continueButton.textContent = "Return to last question →";
        continueButton.disabled = false;
      } else if (firstUnanswered) {
        continueTitle.textContent = "Ready for your next question";
        continueDescription.textContent = "Start with an unanswered question. Your selected answer is not saved until you submit it.";
        continueButton.textContent = "Start next question →";
        continueButton.disabled = false;
      } else {
        continueTitle.textContent = "Ready for a refresher";
        continueDescription.textContent = "Every question has a saved result. Open one again to review the method and formula.";
        continueButton.textContent = "Review a question →";
        continueButton.disabled = false;
      }
    }

    // Render a real subject overview from the question bank; no placeholder counts.
    const subjectCounts = new Map();
    questions.forEach(q => {
      const subject = String(q.subject || q.category || "General Engineering").trim() || "General Engineering";
      const row = subjectCounts.get(subject) || { total: 0, answered: 0, correct: 0 };
      row.total++;
      if (Object.prototype.hasOwnProperty.call(results, q.id)) {
        row.answered++;
        if (results[q.id] === true) row.correct++;
      }
      subjectCounts.set(subject, row);
    });
    const subjectGrid = $("dashboard-subject-grid");
    if (subjectGrid) {
      subjectGrid.replaceChildren();
      const entries = [...subjectCounts.entries()].sort((a,b) => a[0].localeCompare(b[0]));
      if (!entries.length) {
        const empty = document.createElement("p");
        empty.className = "muted small dashboard-empty-state";
        empty.textContent = "Your subject cards will appear here when questions are added to the bank.";
        subjectGrid.append(empty);
      } else {
        entries.forEach(([subject, data], index) => {
          const card = document.createElement("article");
          card.className = "dashboard-subject-card";
          const top = document.createElement("div"); top.className = "dashboard-subject-top";
          const icon = document.createElement("span"); icon.className = "dashboard-subject-icon"; icon.setAttribute("aria-hidden", "true");
          icon.textContent = ["∑", "⚙", "⌁", "◈", "△", "▦"][index % 6];
          const title = document.createElement("h3"); title.textContent = subject;
          const count = document.createElement("span"); count.className = "dashboard-subject-count"; count.textContent = `${data.total} question${data.total === 1 ? "" : "s"}`;
          top.append(icon, title); card.append(top, count);
          const track = document.createElement("div"); track.className = "dashboard-subject-track"; track.setAttribute("role", "progressbar"); track.setAttribute("aria-label", `${subject} answered progress`); track.setAttribute("aria-valuemin", "0"); track.setAttribute("aria-valuemax", String(data.total)); track.setAttribute("aria-valuenow", String(data.answered));
          const bar = document.createElement("span"); bar.style.width = `${data.total ? Math.min(100, data.answered / data.total * 100) : 0}%`; track.append(bar); card.append(track);
          const detail = document.createElement("p"); detail.className = "muted tiny"; detail.textContent = data.answered ? `${data.answered} of ${data.total} attempted · ${Math.round(data.correct / data.answered * 100)}% accuracy` : "Not started yet · ready when you are"; card.append(detail);
          const action = document.createElement("button"); action.type = "button"; action.className = "button button-secondary dashboard-subject-action"; action.textContent = "Explore subject";
          action.addEventListener("click", () => {
            const search = $("library-search"); if (search) search.value = subject;
            setView("practice"); search?.dispatchEvent(new Event("input", { bubbles: true }));
          });
          card.append(action); subjectGrid.append(card);
        });
      }
    }
    const completion = $("dashboard-bank-progress");
    if (completion) {
      const pct = questions.length ? Math.round(attempts.length / questions.length * 100) : 0;
      completion.textContent = questions.length ? `${attempts.length} of ${questions.length} questions have saved results (${pct}%).` : "Add questions to begin tracking your review progress.";
      const bar = $("dashboard-bank-fill"); if (bar) bar.style.width = `${pct}%`;
      const track = bar?.parentElement; if (track) { track.setAttribute("aria-valuemax", String(questions.length || 1)); track.setAttribute("aria-valuenow", String(attempts.length)); }
    }

    const byTopic = new Map();
    attempts.forEach(([id, result]) => {
      const q = questions.find(item => item.id === id);
      if (!q) return;
      const topic = String(q.category || q.subject || "Other");
      if (!byTopic.has(topic)) byTopic.set(topic, {total:0, correct:0});
      const row = byTopic.get(topic); row.total++; if (result === true) row.correct++;
    });
    const MIN_WEAK_TOPIC_ATTEMPTS = 3;
    const eligibleTopics = [...byTopic.entries()]
      .map(([topic, value]) => ({topic, ...value, accuracy:value.correct/value.total}))
      .filter(row => row.total >= MIN_WEAK_TOPIC_ATTEMPTS)
      .sort((a,b) => a.accuracy-b.accuracy || b.total-a.total);
    const weakest = eligibleTopics[0];
    const title = $("dashboard-recommendation-title");
    const detail = $("dashboard-recommendation");
    const suggested = $("dashboard-practice-suggested");
    if (weakest) {
      title.textContent = `Review ${weakest.topic}`;
      detail.textContent = `Your recorded accuracy here is ${Math.round(weakest.accuracy*100)}% (${weakest.correct} correct out of ${weakest.total} saved result${weakest.total===1?"":"s"}). This is the lowest-performing topic in your current history.`;
      suggested.textContent = "Practice this topic";
      suggested.onclick = () => {
        const q = questions.find(item => String(item.category || item.subject || "Other") === weakest.topic);
        if (q && window.openEngineeringReviewQuestion) {
          window.openEngineeringReviewQuestion(q.id);
          setView("practice");
        } else setView("practice");
      };
    } else {
      title.textContent = "Build your topic history";
      const hasSomeResults = byTopic.size > 0;
      detail.textContent = hasSomeResults
        ? `A topic needs at least ${MIN_WEAK_TOPIC_ATTEMPTS} saved attempts before it can be recommended as a weak area. Keep practicing to build a reliable comparison.`
        : "There are no saved answer results yet. Complete a few questions and the dashboard can identify a topic to review.";
      suggested.textContent = "Start Practice";
      suggested.onclick = () => setView("practice");
    }
  }
  goalInput.value = String(Math.max(1, Math.min(200, Number(readJSON(GOAL_KEY, 10)) || 10)));
  goalInput.addEventListener("change", () => {
    const value = Math.max(1, Math.min(200, Number(goalInput.value) || 10));
    goalInput.value = String(value);
    localStorage.setItem(GOAL_KEY, JSON.stringify(value));
    render();
  });
  document.querySelectorAll("[data-dashboard-view]").forEach(button => button.addEventListener("click", () => setView(button.dataset.dashboardView)));
  $("dashboard-continue-practice")?.addEventListener("click", () => {
    const questions = getQuestions();
    if (!questions.length) { setView("practice"); return; }
    let targetId = "";
    try { targetId = localStorage.getItem("engineeringReviewQuizLastQuestionV1") || ""; } catch {}
    let target = questions.find(q => q.id === targetId);
    if (!target) {
      const progress = readJSON("engineeringReviewQuizProgressV5CleanBank", { results: {} });
      const results = progress.results && typeof progress.results === "object" ? progress.results : {};
      target = questions.find(q => !Object.prototype.hasOwnProperty.call(results, q.id)) || questions[0];
    }
    setView("practice");
    if (target && window.openEngineeringReviewQuestion) window.openEngineeringReviewQuestion(target.id);
  });
  $("dashboard-review-due")?.addEventListener("click", () => $("review-due-button")?.click());
  $("dashboard-retry-missed")?.addEventListener("click", () => $("review-missed-button")?.click());
  window.renderStudyDashboard = render;
  render();
})();
