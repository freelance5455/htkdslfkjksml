# YOBRA Android starter project

This is a React + Vite starter with Firebase Authentication, Firestore feed posts, and likes. It is **not a finished production social network or a prebuilt APK**.

## Run in GitHub Codespaces
```bash
npm install
npm run dev -- --host 0.0.0.0
```
Open the forwarded port 5173 from the Codespaces Ports panel to preview.

## Build web files
```bash
npm run build
```

## Prepare Android wrapper
Capacitor Android requires Android SDK tooling and a compatible Java JDK. From an environment with those tools:
```bash
npm install
npx cap add android
npm run build
npx cap sync android
```
Open the generated `android/` folder in Android Studio to build an APK. This ZIP does not contain a compiled APK.

## Firebase checklist
- Confirm Email/Password is enabled in Firebase Authentication.
- Create Firestore if needed.
- Keep Firestore and Storage rules restrictive. Do not use public read/write rules.
- Before using the feed, configure authenticated rules that validate ownership and allowed fields.
- Chat, groups, follows, media uploads, Shorts playback, moderation, notifications, and production-ready privacy controls are not implemented.
- AI is intentionally not enabled.
- Never include Firebase service-account private keys in this client project.
