import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';
import { getStorage } from 'firebase/storage';
const firebaseConfig = {
  apiKey: "AIzaSyDatDiICspYMe3uvlz2hiajimqRh9nNTUc",
  authDomain: "yobra-77e20.firebaseapp.com",
  projectId: "yobra-77e20",
  storageBucket: "yobra-77e20.firebasestorage.app",
  messagingSenderId: "88505261385",
  appId: "1:88505261385:web:17ebf21b0b99de25be0e98",
  measurementId: "G-JYKNPKC6CQ"
};
const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);
export const storage = getStorage(app);