پروژه Android بازی ماشین‌سواری

این پروژه نسخه Android بازی HTML فعلی است و بازی را داخل WebView اجرا می‌کند.
ویژگی‌ها: گاز، ترمز، چپ، راست، جاده، موانع و امتیاز.
صفحه به صورت افقی و تمام‌صفحه اجرا می‌شود.

برای ساخت APK، پروژه را با Android Studio باز کنید و Build > Generate App Bundles or APKs > Generate APKs را بزنید.
یا از Gradle استفاده کنید: ./gradlew assembleDebug

توجه: این پوشه پروژه است، نه APK کامپایل‌شده. برای کامپایل به Android SDK و Gradle نیاز است.
