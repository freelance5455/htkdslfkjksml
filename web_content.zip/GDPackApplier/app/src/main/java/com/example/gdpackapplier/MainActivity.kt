package com.example.gdpackapplier

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.*
import androidx.documentfile.provider.DocumentFile
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("gd", MODE_PRIVATE) }
    private lateinit var srcLabel: TextView
    private lateinit var dstLabel: TextView
    private lateinit var logView: TextView
    private lateinit var newFiles: CheckBox

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 48, 32, 32) }
        srcLabel = TextView(this); dstLabel = TextView(this)
        newFiles = CheckBox(this).apply { text = "Also add files that aren't in the destination" }
        logView = TextView(this)
        fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }

        root.addView(btn("Pick your pack folder") { pick(1) })
        root.addView(srcLabel)
        root.addView(btn("Pick game textures folder") { pick(2) })
        root.addView(dstLabel)
        root.addView(newFiles)
        root.addView(btn("Apply pack") { run(false) })
        root.addView(btn("Restore vanilla") { run(true) })
        root.addView(ScrollView(this).apply { addView(logView) })
        setContentView(root)
        refreshLabels()
    }

    private fun pick(code: Int) = startActivityForResult(
        Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).addFlags(
            Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION), code)

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        val uri = data?.data ?: return
        if (res != RESULT_OK) return
        contentResolver.takePersistableUriPermission(uri,
            Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
        prefs.edit().putString(if (req == 1) "src" else "dst", uri.toString()).apply()
        refreshLabels()
    }

    private fun dir(key: String) = prefs.getString(key, null)
        ?.let { DocumentFile.fromTreeUri(this, Uri.parse(it)) }

    private fun refreshLabels() {
        srcLabel.text = "Pack: " + (dir("src")?.name ?: "not set")
        dstLabel.text = "Game: " + (dir("dst")?.name ?: "not set")
    }

    private fun log(s: String) = runOnUiThread { logView.append(s + "\n") }

    private fun copy(from: DocumentFile, to: DocumentFile) {
        contentResolver.openInputStream(from.uri)!!.use { i ->
            contentResolver.openOutputStream(to.uri, "wt")!!.use { o -> i.copyTo(o) }
        }
    }

    private fun run(restore: Boolean) {
        val src = dir("src"); val dst = dir("dst")
        if (dst == null || (!restore && src == null)) { log("Pick the folders first."); return }
        val addNew = newFiles.isChecked
        thread {
            try {
                val bak = dst.findFile("vanilla_backup") ?: dst.createDirectory("vanilla_backup")!!
                var n = 0
                if (restore) {
                    for (f in bak.listFiles()) {
                        val t = dst.findFile(f.name ?: continue) ?: continue
                        copy(f, t); n++
                    }
                    log("Restored $n file(s).")
                } else {
                    for (f in src!!.listFiles()) {
                        if (!f.isFile) continue
                        val name = f.name ?: continue
                        var t = dst.findFile(name)
                        if (t == null) {
                            if (!addNew) continue
                            t = dst.createFile("application/octet-stream", name) ?: continue
                        } else if (bak.findFile(name) == null) {
                            val keep = bak.createFile("application/octet-stream", name)
                            if (keep != null) copy(t, keep)   // back up the original once
                        }
                        copy(f, t); n++
                    }
                    log("Applied $n file(s).")
                }
            } catch (e: Exception) { log("Error: ${e.message}") }
        }
    }
}
