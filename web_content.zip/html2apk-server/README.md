# html2apk-server

Backend service that compiles HTML into a signed, installable Android APK.

## How it works

```
POST /api/build  ──►  job queue (concurrency-limited)
                        │
                        ▼
                 clone `template/` Android project
                 inject your HTML → app/src/main/assets/www/
                 inject config (app name, package id, version,
                 orientation, fullscreen, icon color) via -P flags
                        │
                        ▼
                 ./gradlew :app:assembleDebug
                 (aapt2 → javac → d8 → zipalign → debug-signed)
                        │
                        ▼
                 GET /api/jobs/:id/download ──► your-app.apk
```

Each APK is a native WebView wrapper around your HTML — offline-capable,
back-button aware, JS + DOM storage enabled.

## Quick start (Docker — recommended)

The Dockerfile installs JDK 17 + Android SDK + Gradle and pre-warms everything:

```bash
docker build -t html2apk-server .
docker run -p 3000:3000 -v html2apk-jobs:/app/jobs html2apk-server
```

First build in a fresh container takes ~1–3 min (Gradle warms up); subsequent
builds are ~20–40 s. Then open http://localhost:3000 for the test client, or:

```bash
curl -X POST http://localhost:3000/api/build   -H 'Content-Type: application/json'   -d '{
    "html": "<!DOCTYPE html><html><body><h1>Hi</h1></body></html>",
    "config": { "appName": "Hi App", "packageName": "com.example.hi", "versionName": "1.0" }
  }'
# → {"id":"job_...","status":"queued",...}

curl http://localhost:3000/api/jobs/job_...
# poll until "status":"done"

curl -OJ http://localhost:3000/api/jobs/job_.../download
```

Uploading a multi-file site instead of a single HTML string:

```bash
curl -X POST http://localhost:3000/api/build   -F 'config={"appName":"Site","packageName":"com.example.site"}'   -F 'files=@index.html' -F 'files=@style.css' -F 'files=@app.js'
```

## Local dev setup (no Docker)

1. JDK 17 (`java -version`)
2. Android SDK: install cmdline-tools, then
   `sdkmanager "platforms;android-34" "build-tools;34.0.0"`
3. `export ANDROID_HOME=~/Android/Sdk`
4. Generate the wrapper once: `cd template && gradle wrapper --gradle-version 8.7`
5. `npm install && npm start`

## API

| Endpoint | Description |
|---|---|
| `GET /api/health` | Server + SDK status |
| `POST /api/build` | Create job. JSON `{html, config}` or multipart `config` + `files[]` |
| `GET /api/jobs/:id` | Poll status: `queued → running → done/failed` |
| `GET /api/jobs/:id/log` | Full Gradle log |
| `GET /api/jobs/:id/download` | Download APK |

### config fields

| Field | Default | Notes |
|---|---|---|
| `appName` | — | required |
| `packageName` | — | required, e.g. `com.example.app` |
| `versionName` | `1.0` | |
| `versionCode` | `1` | |
| `orientation` | `unspecified` | `portrait` / `landscape` / `unspecified` |
| `fullscreen` | `false` | hides status bar |
| `iconColor` | `#4A90D9` | launcher icon background |

## Environment variables

| Var | Default | Purpose |
|---|---|---|
| `PORT` | `3000` | listen port |
| `BUILD_CONCURRENCY` | `1` | parallel Gradle builds (RAM-hungry) |
| `JOB_TTL_MS` | `1h` | how long APKs are kept |
| `JOBS_DIR` | `./jobs` | job workspace |
| `ANDROID_HOME` | — | Android SDK path |

## Production roadmap

- Swap in-memory queue for **BullMQ + Redis** (persistent, retryable jobs)
- Store APKs in **S3/GCS** instead of local disk; presigned download URLs
- **Release signing** with a real keystore instead of the debug key
- Per-package build cache: rebuilds with unchanged config are near-instant
- Auth + rate limiting (compiling APKs is CPU-expensive — cap per user)
- Horizontal scaling: builder workers as a separate service (the API just queues)
