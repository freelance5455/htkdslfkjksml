const path = require('path');
const fs = require('fs');
const express = require('express');
const multer = require('multer');
const { enqueue, jobs } = require('./builder');

const app = express();
const PORT = process.env.PORT || 3000;
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024, files: 30 },
});

app.use(express.json({ limit: '2mb' }));
app.use((req, res, next) => { // dev CORS
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Headers', 'Content-Type');
  res.header('Access-Control-Allow-Methods', 'GET,POST,OPTIONS');
  if (req.method === 'OPTIONS') return res.sendStatus(204);
  next();
});

function publicJob(job) {
  return {
    id: job.id,
    status: job.status, // queued | running | done | failed
    createdAt: job.createdAt,
    startedAt: job.startedAt,
    finishedAt: job.finishedAt,
    error: job.error,
    apk: job.apk ? { size: job.apk.size, name: (job.config.appName || 'app').replace(/\s+/g, '_') + '.apk' } : null,
  };
}

// Health check (also verifies SDK presence)
app.get('/api/health', (req, res) => {
  const sdk = process.env.ANDROID_HOME || process.env.ANDROID_SDK_ROOT;
  res.json({
    ok: true,
    androidHome: sdk || null,
    sdkDetected: !!(sdk && fs.existsSync(path.join(sdk, 'build-tools'))),
    queued: [...jobs.values()].filter(j => j.status === 'queued').length,
    running: [...jobs.values()].filter(j => j.status === 'running').length,
  });
});

// Create a build job.
// Either:  multipart form with field "config" (JSON string) + optional files[] (html/css/js)
// Or:       JSON body { html: "<!DOCTYPE html>...", config: {...} }
app.post('/api/build', upload.array('files', 30), (req, res) => {
  try {
    let config, html = null, files = null;
    if (req.is('multipart/form-data')) {
      config = JSON.parse(req.body.config || '{}');
      files = req.files && req.files.length ? req.files : null;
    } else {
      config = req.body.config || {};
      html = req.body.html || null;
    }
    const job = enqueue(html, files, config);
    res.status(202).json(publicJob(job));
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

app.get('/api/jobs/:id', (req, res) => {
  const job = jobs.get(req.params.id);
  if (!job) return res.status(404).json({ error: 'Job not found (or expired)' });
  res.json(publicJob(job));
});

app.get('/api/jobs/:id/log', (req, res) => {
  const job = jobs.get(req.params.id);
  if (!job) return res.status(404).json({ error: 'Job not found' });
  const log = path.join(__dirname, '..', 'jobs', job.id, 'build.log');
  if (!fs.existsSync(log)) return res.status(404).json({ error: 'No log yet' });
  res.type('text/plain').send(fs.readFileSync(log, 'utf8'));
});

app.get('/api/jobs/:id/download', (req, res) => {
  const job = jobs.get(req.params.id);
  if (!job || job.status !== 'done' || !job.apk) {
    return res.status(404).json({ error: 'APK not ready' });
  }
  res.download(job.apk.path, publicJob(job).apk.name);
});

// Tiny test client
app.use(express.static(path.join(__dirname, '..', 'public')));

app.listen(PORT, () => console.log('html2apk-server listening on http://localhost:' + PORT));
