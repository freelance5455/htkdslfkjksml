// Job manager: clones the Android template, injects user HTML + config,
// compiles with Gradle, and returns the signed APK path.
const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');

const ROOT = path.join(__dirname, '..');
const TEMPLATE_DIR = path.join(ROOT, 'template');
const JOBS_DIR = process.env.JOBS_DIR || path.join(ROOT, 'jobs');
const CONCURRENCY = parseInt(process.env.BUILD_CONCURRENCY || '1', 10);
const JOB_TTL_MS = parseInt(process.env.JOB_TTL_MS || String(60 * 60 * 1000), 10);

fs.mkdirSync(JOBS_DIR, { recursive: true });

const jobs = new Map(); // id -> job
let queue = [];
let running = 0;

const now = () => new Date().toISOString();

function validatePackageName(name) {
  return /^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+$/.test(name);
}

function sanitizeFileName(n) {
  return n.replace(/[^a-zA-Z0-9._-]/g, '_');
}

// ---------- template preparation ----------
function prepareJob(job) {
  const work = path.join(JOBS_DIR, job.id, 'work');
  fs.cpSync(TEMPLATE_DIR, work, { recursive: true });

  // 1. assets: single html string OR uploaded file set
  const www = path.join(work, 'app/src/main/assets/www');
  fs.mkdirSync(www, { recursive: true });
  if (job.html) {
    fs.writeFileSync(path.join(www, 'index.html'), job.html);
  } else if (job.files && job.files.length) {
    let hasIndex = false;
    for (const f of job.files) {
      const safe = sanitizeFileName(f.originalname);
      if (safe === 'index.html') hasIndex = true;
      fs.writeFileSync(path.join(www, safe), f.buffer);
    }
    if (!hasIndex) {
      const first = job.files.find(f => f.originalname.endsWith('.html'));
      if (!first) throw new Error('No .html file provided. Expected index.html');
      fs.writeFileSync(path.join(www, 'index.html'), first.buffer);
    }
  } else {
    throw new Error('No HTML provided');
  }

  // 2. launcher icon color
  const iconPath = path.join(work, 'app/src/main/res/drawable/ic_launcher.xml');
  let icon = fs.readFileSync(iconPath, 'utf8');
  icon = icon.replace(/__ICON_COLOR__/g, job.config.iconColor || '#4A90D9');
  fs.writeFileSync(iconPath, icon);

  return work;
}

// ---------- gradle ----------
function gradleArgs(job) {
  const c = job.config;
  const theme = c.fullscreen
    ? '@android:style/Theme.NoTitleBar.Fullscreen'
    : '@android:style/Theme.Material.Light.NoActionBar';
  return [
    ':app:assembleDebug', '--console=plain', '--stacktrace',
    '-PappId=' + c.packageName,
    '-PappName=' + c.appName,
    '-PversionName=' + (c.versionName || '1.0'),
    '-PversionCode=' + (c.versionCode || 1),
    '-Porientation=' + (c.orientation || 'unspecified'),
    '-PthemeRef=' + theme,
  ];
}

function runGradle(job, work) {
  return new Promise((resolve, reject) => {
    const isWin = process.platform === 'win32';
    const cmd = isWin ? 'gradlew.bat' : './gradlew';
    const args = gradleArgs(job);
    const child = spawn(cmd, args, {
      cwd: work,
      env: { ...process.env, ANDROID_HOME: process.env.ANDROID_HOME || process.env.ANDROID_SDK_ROOT },
    });

    let tail = [];
    const logFile = fs.createWriteStream(path.join(JOBS_DIR, job.id, 'build.log'));
    child.stdout.on('data', d => { logFile.write(d); tail.push(d.toString()); tail = tail.slice(-60); });
    child.stderr.on('data', d => { logFile.write(d); tail.push(d.toString()); tail = tail.slice(-60); });
    child.on('close', code => {
      logFile.end();
      if (code === 0) return resolve();
      reject(new Error('Gradle exited with code ' + code + '\n' + tail.join('').split('\n').slice(-15).join('\n')));
    });
    child.on('error', reject);
  });
}

// ---------- queue ----------
function enqueue(html, files, config) {
  if (!config.appName) throw new Error('config.appName is required');
  if (!validatePackageName(config.packageName || '')) {
    throw new Error('config.packageName must look like com.example.app (lowercase segments, at least 2)');
  }

  const id = 'job_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 8);
  const job = {
    id, status: 'queued', html, files,
    config: {
      orientation: 'unspecified', fullscreen: false,
      iconColor: '#4A90D9', versionName: '1.0', versionCode: 1,
      ...config,
    },
    createdAt: now(), startedAt: null, finishedAt: null,
    error: null, apk: null,
  };
  jobs.set(id, job);
  queue.push(id);
  pump();
  return job;
}

function pump() {
  while (running < CONCURRENCY && queue.length) {
    const id = queue.shift();
    running++;
    build(jobs.get(id)).finally(() => { running--; pump(); });
  }
}

async function build(job) {
  job.status = 'running';
  job.startedAt = now();
  try {
    const work = prepareJob(job);
    await runGradle(job, work);
    const out = path.join(work, 'app/build/outputs/apk/debug/app-debug.apk');
    if (!fs.existsSync(out)) throw new Error('APK not found at expected path');
    const dest = path.join(JOBS_DIR, job.id, 'app.apk');
    fs.copyFileSync(out, dest);
    fs.rmSync(work, { recursive: true, force: true }); // keep apk + log only
    job.apk = { path: dest, size: fs.statSync(dest).size };
    job.status = 'done';
  } catch (e) {
    job.status = 'failed';
    job.error = e.message;
  }
  job.finishedAt = now();
}

// ---------- cleanup ----------
setInterval(() => {
  const cutoff = Date.now() - JOB_TTL_MS;
  for (const [id, job] of jobs) {
    if (job.finishedAt && new Date(job.finishedAt).getTime() < cutoff) {
      fs.rmSync(path.join(JOBS_DIR, id), { recursive: true, force: true });
      jobs.delete(id);
    }
  }
}, 10 * 60 * 1000).unref();

module.exports = { enqueue, jobs, JOBS_DIR };
