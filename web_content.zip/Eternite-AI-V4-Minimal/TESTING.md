# Quick testing checklist

- `npm install` completes without errors
- `.env` contains `OPENAI_API_KEY`
- `npm start` prints the local URL
- `/api/health` returns `ok: true`
- Send a normal message
- Toggle Web
- Attach a PDF/TXT/DOCX/image
- Try Stop
- Try Regenerate / Copy / Read aloud
- Try Image mode
- Try dark mode and mobile width
