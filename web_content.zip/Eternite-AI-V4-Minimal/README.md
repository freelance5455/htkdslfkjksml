# Eternite AI V4 — Minimal AI UI

A major upgrade from the V1 starter.

## Included features

- ChatGPT/Gemini-style responsive chat interface
- Eternite branding/logo
- Sidebar with saved conversations
- Chat search
- New chat
- Temporary chat mode (not saved to browser history)
- Model selector: Smart / Pro / Max
- Streaming responses
- Stop generation
- Regenerate answer
- Copy answer
- Copy code blocks
- Read answer aloud
- Voice input (browser Speech Recognition)
- Web search toggle through the OpenAI Responses API
- File upload support through OpenAI Files API
- Image generation endpoint
- Light/dark mode
- Export chat to TXT
- Mobile responsive UI
- In-app Settings screen for entering/removing the API key
- Server-side runtime API key storage (not browser localStorage; cleared when server restarts)

## Setup

1. Install Node.js 18+.
2. Open a terminal in this folder.
3. Run:

```bash
npm install
```

4. Start the app.
5. Open **Settings** inside Eternite and enter your API key. The key is held in server memory.
6. Optionally, you can still put `OPENAI_API_KEY` in `.env` for server startup:

```env
OPENAI_API_KEY=your_real_key
OPENAI_MODEL=gpt-5.6-luna
```

7. Start:

```bash
npm start
```

8. Open:

http://localhost:3000

## Important

AI API calls are not free. Web search and image generation can also incur API usage charges depending on your provider/account.

The app is a custom assistant inspired by common AI-chat UX patterns; it is not an official ChatGPT or Gemini application and does not copy their proprietary branding.

## V2 → V3 ideas

- Real user accounts
- Database-backed history
- PWA / installable Android app
- Push notifications
- Better PDF/document preview
- Persistent file library
- Conversation folders
- Share links
- Admin dashboard
- Usage limits
- Multi-provider AI (OpenAI + Gemini + local models)
- Real-time voice conversation
- Image attachments directly in chat
- Code execution sandbox


## V3 UI
The interface has been redesigned from scratch with a cleaner modern AI-assistant layout, compact sidebar, model switcher, modern composer, quick actions, responsive mobile layout, and the existing V2 backend/settings functionality.


## V4 Minimal UI
A clean, startup-style AI interface: minimal top bar, three recent chats in the hidden sidebar, large empty welcome state, and a compact bottom composer with Search.
