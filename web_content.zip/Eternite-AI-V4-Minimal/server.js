require("dotenv").config();

const express = require("express");
const multer = require("multer");
const path = require("path");
const OpenAI = require("openai");

const app = express();
const PORT = process.env.PORT || 3000;
const MAX_MB = Number(process.env.MAX_UPLOAD_MB || 20);

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: MAX_MB * 1024 * 1024 }
});

let runtimeApiKey = process.env.OPENAI_API_KEY || "";

function getApiKey() {
  return runtimeApiKey;
}

function getClient() {
  const key = getApiKey();
  return key ? new OpenAI({ apiKey: key }) : null;
}

app.use(express.json({ limit: "12mb" }));
app.use(express.static(path.join(__dirname, "public")));

app.get("/api/health", (req, res) => {
  res.json({
    ok: true,
    name: "Eternite",
    version: "2.0.0",
    configured: Boolean(getApiKey())
  });
});

function normalizeMessages(messages) {
  if (!Array.isArray(messages)) return [];
  return messages
    .filter(m => m && ["user", "assistant"].includes(m.role))
    .slice(-40)
    .map(m => {
      const content = Array.isArray(m.content)
        ? m.content
        : [{ type: "input_text", text: String(m.content || "").slice(0, 16000) }];

      return {
        role: m.role,
        content: content.map(item => {
          if (item.type === "input_text") {
            return { type: "input_text", text: String(item.text || "").slice(0, 16000) };
          }
          if (item.type === "input_image" && typeof item.image_url === "string") {
            return { type: "input_image", image_url: item.image_url };
          }
          if (item.type === "input_file" && typeof item.file_id === "string") {
            return { type: "input_file", file_id: item.file_id };
          }
          return null;
        }).filter(Boolean)
      };
    });
}


app.get("/api/config", (req, res) => {
  res.json({
    configured: Boolean(getApiKey()),
    maskedKey: getApiKey()
      ? `${getApiKey().slice(0, 7)}…${getApiKey().slice(-4)}`
      : ""
  });
});

app.post("/api/config", (req, res) => {
  const key = String(req.body?.apiKey || "").trim();

  if (!key) {
    runtimeApiKey = "";
    return res.json({ configured: false, maskedKey: "" });
  }

  // Keep the key only in server memory. It is never written to a browser
  // localStorage value or to a project file.
  runtimeApiKey = key;

  res.json({
    configured: true,
    maskedKey: `${key.slice(0, 7)}…${key.slice(-4)}`
  });
});

app.post("/api/chat", async (req, res) => {
  try {
    if (!getApiKey()) {
      return res.status(500).json({ error: "OPENAI_API_KEY is missing. Create .env from .env.example." });
    }

    const { messages, webSearch = false, model } = req.body;
    const input = normalizeMessages(messages);

    if (!input.length) return res.status(400).json({ error: "No messages supplied." });

    const tools = webSearch ? [{ type: "web_search" }] : undefined;

    const response = await getClient().responses.create({
      model: model || process.env.OPENAI_MODEL || "gpt-5.6-luna",
      instructions: process.env.SYSTEM_PROMPT || "You are Eternite, a helpful AI assistant.",
      input,
      tools
    });

    res.json({
      id: response.id,
      answer: response.output_text || "I couldn't generate a response.",
      output: response.output || []
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: error?.message || "AI request failed." });
  }
});

app.post("/api/chat-stream", async (req, res) => {
  try {
    if (!getApiKey()) {
      return res.status(500).json({ error: "OPENAI_API_KEY is missing." });
    }

    const { messages, webSearch = false, model } = req.body;
    const input = normalizeMessages(messages);

    if (!input.length) return res.status(400).json({ error: "No messages supplied." });

    res.setHeader("Content-Type", "text/event-stream; charset=utf-8");
    res.setHeader("Cache-Control", "no-cache, no-transform");
    res.setHeader("Connection", "keep-alive");
    res.flushHeaders();

    const stream = await getClient().responses.create({
      model: model || process.env.OPENAI_MODEL || "gpt-5.6-luna",
      instructions: process.env.SYSTEM_PROMPT || "You are Eternite, a helpful AI assistant.",
      input,
      tools: webSearch ? [{ type: "web_search" }] : undefined,
      stream: true
    });

    for await (const event of stream) {
      if (event.type === "response.output_text.delta") {
        res.write(`data: ${JSON.stringify({ type: "delta", text: event.delta })}\n\n`);
      } else if (event.type === "response.web_search_call.searching") {
        res.write(`data: ${JSON.stringify({ type: "status", text: "Searching the web…" })}\n\n`);
      } else if (event.type === "response.completed") {
        res.write(`data: ${JSON.stringify({ type: "done" })}\n\n`);
      }
    }

    res.write("data: [DONE]\n\n");
    res.end();
  } catch (error) {
    console.error(error);
    try {
      res.write(`data: ${JSON.stringify({ type: "error", text: error?.message || "Stream failed." })}\n\n`);
      res.end();
    } catch {}
  }
});

app.post("/api/upload", upload.single("file"), async (req, res) => {
  try {
    if (!getApiKey()) {
      return res.status(500).json({ error: "OPENAI_API_KEY is missing." });
    }
    if (!req.file) return res.status(400).json({ error: "No file uploaded." });

    const allowed = new Set([
      "application/pdf",
      "text/plain",
      "text/markdown",
      "text/csv",
      "application/json",
      "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      "application/msword",
      "application/vnd.ms-excel"
    ]);

    const isImage = req.file.mimetype.startsWith("image/");
    if (!allowed.has(req.file.mimetype) && !isImage) {
      return res.status(415).json({ error: "Unsupported file type." });
    }

    const uploaded = await getClient().files.create({
      file: new File([req.file.buffer], req.file.originalname, { type: req.file.mimetype }),
      purpose: "user_data"
    });

    res.json({
      file_id: uploaded.id,
      filename: req.file.originalname,
      mime: req.file.mimetype,
      size: req.file.size
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: error?.message || "Upload failed." });
  }
});

app.post("/api/image", async (req, res) => {
  try {
    if (!getApiKey()) {
      return res.status(500).json({ error: "OPENAI_API_KEY is missing." });
    }
    const prompt = String(req.body?.prompt || "").trim();
    if (!prompt) return res.status(400).json({ error: "Prompt is required." });

    const result = await getClient().images.generate({
      model: "gpt-image-2",
      prompt,
      size: "1024x1024"
    });

    const b64 = result.data?.[0]?.b64_json;
    if (!b64) return res.status(502).json({ error: "Image API returned no image." });

    res.json({ dataUrl: `data:image/png;base64,${b64}` });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: error?.message || "Image generation failed." });
  }
});

app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.listen(PORT, () => {
  console.log(`Eternite AI V2 running on http://localhost:${PORT}`);
});
