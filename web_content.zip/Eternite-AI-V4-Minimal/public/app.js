const $ = s => document.querySelector(s);

const state = {
  chats: JSON.parse(localStorage.getItem("eternite_chats") || "[]"),
  messages: [],
  attachments: [],
  webSearch: false,
  model: localStorage.getItem("eternite_model") || "gpt-5.6-luna",
  temporary: false,
  controller: null,
  busy: false,
  id: crypto.randomUUID()
};

const messagesEl = $("#messages");
const welcome = $("#welcome");
const input = $("#input");
const chatList = $("#chatList");
const attachmentsEl = $("#attachments");
const sendBtn = $("#sendBtn");
const stopBtn = $("#stopBtn");

function esc(s){
  return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]));
}

function renderMarkdown(text){
  let s = esc(text);
  const blocks=[];
  s=s.replace(/```([\\w+-]*)\\n?([\\s\\S]*?)```/g,(_,lang,code)=>{
    const id="code"+blocks.length;
    blocks.push(`<pre><button class="code-copy" data-code="${encodeURIComponent(code)}">Copy</button><code>${code}</code></pre>`);
    return `@@CODE${blocks.length-1}@@`;
  });
  s=s.replace(/`([^`]+)`/g,"<code>$1</code>");
  s=s.replace(/\\*\\*(.+?)\\*\\*/g,"<strong>$1</strong>");
  s=s.replace(/\\*([^*]+)\\*/g,"<em>$1</em>");
  s=s.replace(/^### (.+)$/gm,"<h3>$1</h3>");
  s=s.replace(/^## (.+)$/gm,"<h2>$1</h2>");
  s=s.replace(/^# (.+)$/gm,"<h1>$1</h1>");
  s=s.replace(/\\n\\n/g,"</p><p>");
  s=s.replace(/\\n/g,"<br>");
  blocks.forEach((b,i)=>s=s.replace(`@@CODE${i}@@`,b));
  return `<p>${s}</p>`;
}

function toast(text){
  const t=$("#toast"); t.textContent=text; t.classList.add("show");
  clearTimeout(toast.timer); toast.timer=setTimeout(()=>t.classList.remove("show"),1800);
}

function setWelcome(show){
  welcome.style.display=show?"block":"none";
}

function addMessage(role, text, opts={}){
  const row=document.createElement("div");
  row.className=`message ${role}`;
  row.dataset.index=opts.index ?? "";
  if(role==="user"){
    row.innerHTML=`<div class="bubble">${renderMarkdown(text)}</div>`;
  }else{
    row.innerHTML=`
      <div class="avatar"><img src="/logo.png" alt=""></div>
      <div class="bubble">${renderMarkdown(text)}
        ${opts.actions!==false ? `<div class="message-actions">
          <button data-action="copy">Copy</button>
          <button data-action="regenerate">Regenerate</button>
          <button data-action="speak">Read aloud</button>
        </div>`:""}
      </div>`;
  }
  messagesEl.appendChild(row);
  decorateCode(row);
  $("#conversation").scrollTop=$("#conversation").scrollHeight;
  return row;
}

function decorateCode(row){
  row.querySelectorAll(".code-copy").forEach(btn=>{
    btn.onclick=async()=>{
      await navigator.clipboard.writeText(decodeURIComponent(btn.dataset.code));
      toast("Code copied");
    };
  });
}

function renderAll(){
  messagesEl.innerHTML="";
  setWelcome(state.messages.length===0);
  state.messages.forEach((m,i)=>addMessage(m.role,m.text,{index:i}));
}

function titleFor(messages){
  const u=messages.find(x=>x.role==="user");
  return (u?.text||"New chat").replace(/\\s+/g," ").slice(0,52);
}

function save(){
  if(state.temporary || !state.messages.length) return;
  state.chats=state.chats.filter(c=>c.id!==state.id);
  state.chats.unshift({id:state.id,title:titleFor(state.messages),messages:state.messages,updatedAt:Date.now()});
  state.chats=state.chats.slice(0,50);
  localStorage.setItem("eternite_chats",JSON.stringify(state.chats));
  renderChatList();
}

function renderChatList(){
  const q=$("#chatSearch").value.trim().toLowerCase();
  chatList.innerHTML="";
  state.chats.filter(c=>!q||c.title.toLowerCase().includes(q)).forEach(c=>{
    const b=document.createElement("button");
    b.className="chat-item"+(c.id===state.id?" active":"");
    b.innerHTML=`<span>◌</span><span>${esc(c.title)}</span>`;
    b.onclick=()=>loadChat(c.id);
    chatList.appendChild(b);
  });
}

function loadChat(id){
  const c=state.chats.find(x=>x.id===id); if(!c)return;
  state.id=id; state.messages=[...c.messages]; state.temporary=false; renderAll(); renderChatList();
  $("#sidebar").classList.remove("open");
}

function newChat(){
  state.id=crypto.randomUUID(); state.messages=[]; state.attachments=[]; state.temporary=false;
  renderAttachments(); renderAll(); renderChatList(); input.focus();
}

function renderAttachments(){
  attachmentsEl.innerHTML="";
  state.attachments.forEach((a,i)=>{
    const chip=document.createElement("div"); chip.className="file-chip";
    chip.innerHTML=`<span>📎 ${esc(a.filename)}</span><button>×</button>`;
    chip.querySelector("button").onclick=()=>{state.attachments.splice(i,1);renderAttachments()};
    attachmentsEl.appendChild(chip);
  });
}

async function uploadFile(file){
  const fd=new FormData(); fd.append("file",file);
  const res=await fetch("/api/upload",{method:"POST",body:fd});
  const data=await res.json();
  if(!res.ok)throw new Error(data.error||"Upload failed");
  state.attachments.push(data); renderAttachments();
}

$("#fileInput").onchange=async e=>{
  for(const f of e.target.files){
    try{await uploadFile(f);toast(`${f.name} attached`)}catch(err){toast(err.message)}
  }
  e.target.value="";
};

function inputContent(text){
  const content=[{type:"input_text",text}];
  state.attachments.forEach(a=>content.push({type:"input_file",file_id:a.file_id}));
  return content;
}

function apiMessages(){
  return state.messages.map(m=>({
    role:m.role,
    content:m.role==="user" && m.content ? m.content : [{type:"input_text",text:m.text}]
  }));
}

async function send(text){
  if(!text.trim()||state.busy)return;
  const user=text.trim();
  input.value=""; input.style.height="auto";
  state.messages.push({role:"user",text:user});
  const pendingAttachments=[...state.attachments];
  state.attachments=[]; renderAttachments(); setWelcome(false);

  const row=addMessage("assistant","",{actions:false});
  const bubble=row.querySelector(".bubble");
  bubble.innerHTML=`<div class="typing">Eternite is thinking…</div>`;
  state.busy=true; sendBtn.classList.add("hidden"); stopBtn.classList.remove("hidden");

  const controller=new AbortController(); state.controller=controller;

  try{
    const api=state.messages.map((m,i)=>{
      const isLatestUser = i === state.messages.length - 1 && m.role === "user";
      return {
        role:m.role,
        content:isLatestUser
          ? [{type:"input_text",text:m.text}, ...pendingAttachments.map(a=>({type:"input_file",file_id:a.file_id}))]
          : [{type:"input_text",text:m.text}]
      };
    });

    const res=await fetch("/api/chat-stream",{
      method:"POST",headers:{"Content-Type":"application/json"},
      body:JSON.stringify({messages:api,webSearch:state.webSearch,model:state.model}),
      signal:controller.signal
    });
    if(!res.ok){
      const d=await res.json().catch(()=>({}));
      throw new Error(d.error||"Request failed");
    }

    const reader=res.body.getReader(), decoder=new TextDecoder();
    let buffer="", answer="";
    bubble.innerHTML="";
    while(true){
      const {value,done}=await reader.read(); if(done)break;
      buffer+=decoder.decode(value,{stream:true});
      const parts=buffer.split("\\n\\n"); buffer=parts.pop();
      for(const part of parts){
        const line=part.split("\\n").find(x=>x.startsWith("data: "));
        if(!line)continue;
        const payload=line.slice(6);
        if(payload==="[DONE]")continue;
        const event=JSON.parse(payload);
        if(event.type==="delta"){answer+=event.text;bubble.innerHTML=renderMarkdown(answer);decorateCode(row)}
        if(event.type==="status"){bubble.innerHTML=`<div class="typing">${esc(event.text)}</div>`}
        if(event.type==="error")throw new Error(event.text);
        $("#conversation").scrollTop=$("#conversation").scrollHeight;
      }
    }
    state.messages.push({role:"assistant",text:answer||"No response."});
    row.remove(); addMessage("assistant",answer||"No response.",{index:state.messages.length-1});
    save();
  }catch(err){
    row.remove();
    if(err.name!=="AbortError") addMessage("assistant",`Error: ${err.message}`);
  }finally{
    state.busy=false; state.controller=null; stopBtn.classList.add("hidden"); sendBtn.classList.remove("hidden");
    input.focus();
  }
}

$("#composer").onsubmit=e=>{e.preventDefault();send(input.value)};
input.oninput=()=>{input.style.height="auto";input.style.height=Math.min(input.scrollHeight,180)+"px"};
input.onkeydown=e=>{
  if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();$("#composer").requestSubmit()}
};

$("#stopBtn").onclick=()=>state.controller?.abort();
$("#newChat").onclick=newChat;
$("#newTop").onclick=newChat;
$("#newChat").addEventListener("click",()=>$("#sidebar").classList.remove("open"));
$("#temporaryBtn").onclick=()=>{
  state.temporary=!state.temporary;
  $("#temporaryBtn").classList.toggle("active",state.temporary);
  toast(state.temporary ? "Temporary chat enabled" : "Temporary chat disabled");
};
$("#closeSidebar").onclick=()=>$("#sidebar").classList.remove("open");
$("#menuBtn").onclick=()=>$("#sidebar").classList.add("open");
$("#overlay").onclick=()=>$("#sidebar").classList.remove("open");
$("#chatSearch").oninput=renderChatList;

$("#themeBtn").onclick=()=>{
  document.body.classList.toggle("dark");
  localStorage.setItem("eternite_theme",document.body.classList.contains("dark")?"dark":"light");
};

$("#clearAllBtn").onclick=()=>{
  if(!confirm("Delete all saved chats?"))return;
  state.chats=[];localStorage.removeItem("eternite_chats");newChat();
};

$("#exportBtn").onclick=()=>{
  const text=state.messages.map(m=>`${m.role.toUpperCase()}\\n${m.text}`).join("\\n\\n");
  const blob=new Blob([text],{type:"text/plain"});
  const a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download="eternite-chat.txt";a.click();
  URL.revokeObjectURL(a.href);
};

$("#modelBtn").onclick=()=>$("#modelMenu").classList.toggle("open");
document.querySelectorAll("#modelMenu button").forEach(b=>{
  b.onclick=()=>{
    state.model=b.dataset.model;
    $("#modelName").textContent=b.querySelector("b").textContent;
    localStorage.setItem("eternite_model",state.model);
    $("#modelMenu").classList.remove("open");
  };
});

$("#webBtn").onclick=()=>{
  state.webSearch=!state.webSearch;
  $("#webBtn").classList.toggle("active",state.webSearch);
  $("#modeHint").textContent=state.webSearch?"Web search on":"Web search off";
  toast(state.webSearch?"Web search enabled":"Web search disabled");
};

$("#imageBtn").onclick=async()=>{
  const prompt=input.value.trim();
  if(!prompt){toast("Type an image prompt first");input.focus();return}
  input.value="";input.style.height="auto";
  addMessage("user","Create an image: "+prompt);
  state.busy=true;
  try{
    const res=await fetch("/api/image",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({prompt})});
    const d=await res.json();if(!res.ok)throw new Error(d.error||"Image failed");
    const row=addMessage("assistant","Image generated",{actions:false});
    row.querySelector(".bubble").innerHTML=`<p>Here is your image:</p><img src="${d.dataUrl}" style="max-width:100%;border-radius:14px;display:block">`;
  }catch(e){addMessage("assistant",`Image error: ${e.message}`)}
  finally{state.busy=false}
};

$("#voiceBtn").onclick=()=>{
  const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
  if(!SR){toast("Voice input is not supported in this browser");return}
  const r=new SR();r.lang=navigator.language||"en-IN";r.interimResults=true;
  r.onstart=()=>{$("#voiceBtn").classList.add("active");toast("Listening…")};
  r.onresult=e=>{input.value=Array.from(e.results).map(x=>x[0].transcript).join("");input.dispatchEvent(new Event("input"))};
  r.onend=()=>$("#voiceBtn").classList.remove("active");
  r.start();
};

messagesEl.onclick=e=>{
  const btn=e.target.closest("[data-action]"); if(!btn)return;
  const row=e.target.closest(".message"); const idx=Number(row.dataset.index);
  const msg=state.messages[idx];
  if(!msg)return;
  if(btn.dataset.action==="copy"){navigator.clipboard.writeText(msg.text);toast("Copied")}
  if(btn.dataset.action==="speak"){
    speechSynthesis.cancel();speechSynthesis.speak(new SpeechSynthesisUtterance(msg.text));
  }
  if(btn.dataset.action==="regenerate"){
    if(msg.role!=="assistant")return;
    const prev=state.messages[idx-1]; state.messages=state.messages.slice(0,idx);
    renderAll(); send(prev?.text||"");
  }
};

document.querySelectorAll(".quick-grid button").forEach(b=>b.onclick=()=>send(b.dataset.prompt));



// Minimal navigation
$("#menuBtn").onclick=()=>$("#sidebar").classList.add("open");
$("#closeSidebar").onclick=()=>$("#sidebar").classList.remove("open");
document.addEventListener("click",e=>{
  if(window.innerWidth<=760 && $("#sidebar").classList.contains("open") &&
     !$("#sidebar").contains(e.target) && !$("#menuBtn").contains(e.target)){
    $("#sidebar").classList.remove("open");
  }
});
$("#topMenu").onclick=()=>openSettings();

// Settings / API key
const settingsModal = $("#settingsModal");
const settingsStatus = $("#settingsStatus");
const connectionText = $("#connectionText");
const connectionSubtext = $("#connectionSubtext");
const apiKeyInput = $("#apiKeyInput");

function openSettings(){
  settingsModal.classList.remove("hidden");
  loadConfigStatus();
  apiKeyInput.focus();
}
function closeSettings(){
  settingsModal.classList.add("hidden");
  apiKeyInput.value="";
}
async function loadConfigStatus(){
  try{
    const res=await fetch("/api/config");
    const d=await res.json();
    settingsStatus.classList.remove("error");
    if(d.configured){
      settingsStatus.classList.add("connected");
      connectionText.textContent=`Connected • ${d.maskedKey}`;
      connectionSubtext.textContent="API key is active on the Eternite server.";
    }else{
      settingsStatus.classList.remove("connected");
      connectionText.textContent="Not connected";
      connectionSubtext.textContent="Enter your API key below to enable AI chat.";
    }
  }catch(e){
    settingsStatus.classList.add("error");
    connectionText.textContent="Server unavailable";
    connectionSubtext.textContent="Start the Eternite Node.js server and try again.";
  }
}
async function saveApiKey(){
  const key=apiKeyInput.value.trim();
  if(!key){toast("Enter an API key first");return}
  const btn=$("#saveKeyBtn");
  btn.disabled=true;btn.textContent="Saving…";
  try{
    const res=await fetch("/api/config",{
      method:"POST",headers:{"Content-Type":"application/json"},
      body:JSON.stringify({apiKey:key})
    });
    const d=await res.json();
    if(!res.ok)throw new Error(d.error||"Could not save key");
    apiKeyInput.value="";
    await loadConfigStatus();
    toast("API key saved");
  }catch(e){toast(e.message)}
  finally{btn.disabled=false;btn.textContent="Save & test connection"}
}
async function removeApiKey(){
  await fetch("/api/config",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({apiKey:""})});
  apiKeyInput.value="";
  await loadConfigStatus();
  toast("API key removed");
}

$("#settingsBtn").onclick=openSettings;
$("#settingsClose").onclick=closeSettings;
$("#saveKeyBtn").onclick=saveApiKey;
$("#removeKeyBtn").onclick=removeApiKey;
$("#showKeyBtn").onclick=()=>{
  const isPassword=apiKeyInput.type==="password";
  apiKeyInput.type=isPassword?"text":"password";
  $("#showKeyBtn").textContent=isPassword?"Hide":"Show";
};
settingsModal.addEventListener("click",e=>{if(e.target===settingsModal)closeSettings()});
document.addEventListener("keydown",e=>{if(e.key==="Escape"&&!settingsModal.classList.contains("hidden"))closeSettings()});

if(localStorage.getItem("eternite_theme")==="dark")document.body.classList.add("dark");
document.querySelector("#modelName").textContent=
  state.model==="gpt-5.6-sol"?"Eternite Max":state.model==="gpt-5.6-terra"?"Eternite Pro":"Eternite Smart";
renderChatList();
