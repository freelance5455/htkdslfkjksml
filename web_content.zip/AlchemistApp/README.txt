1. Установи Android Studio (бесплатно): developer.android.com/studio
2. File > Open > выбери эту папку (AlchemistApp). Дождись Gradle Sync.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK: app/build/outputs/apk/debug/app-debug.apk. Скинь на телефон и установи.
Игра лежит в app/src/main/assets/index.html, её можно править.
