# ANONYMOUX STUDIO 2.5.9 — Realtime Workspace & Pricing Recheck

Date: 2026-11-15

## Explore page retirement

- Removed Explore from the shared signed-in sidebar and the shared page-access tracking map.
- Retired `community.php`; old bookmarks now redirect to the dashboard rather than rendering a separate Explore page.

## Realtime workspace review

The production-default transport is `sdk-direct`: the browser loads `@decartai/sdk`, asks the authenticated PHP endpoint for a short-lived client token scoped to the selected model and current origin, then connects its camera stream directly to Decart. The permanent provider key remains server-side. The token endpoint now allows 30 requests per 10 minutes rather than 5, because the current Decart SDK requests a fresh token for every connect/reconnect attempt. Token lifetime remains 300 seconds and the model/origin restrictions remain.

The SDK event handler now processes Decart's documented `sessionEnded` event, including provider termination reasons such as session limits or insufficient provider credits, and restores the workspace controls/output state. The existing explicit stop and page-hide paths call the SDK disconnect method and stop local camera tracks.

### Important runtime boundary

A static source audit cannot prove camera permission, browser WebRTC/LiveKit connectivity, remote stream playback, or provider credentials. Test on the deployed HTTPS domain in current Android Chrome and desktop Chrome/Safari with a real Decart key. Verify start, first output frame, prompt update, camera switch, pause/resume, provider-side session end, manual stop, page navigation and reload. The direct SDK path is not represented in the app's legacy `realtime_sessions` ledger; therefore that table/dashboard is not a reliable source for SDK-direct session duration or usage.

## Pricing verified against provider documentation

Decart official pricing checked 2026-11-15: Lucy 2.5 and Lucy 2.6 realtime at 720p are US$0.02 per active generation second; Fast mode is US$0.04 per second where supported. Decart also states US$1 = 100 Decart provider credits. See https://docs.platform.decart.ai/getting-started/pricing.

Default ANONYMOUX credit packages are actively seeded when missing: 250 / ₦2,500, 600 / ₦6,000, 1,500 / ₦15,000, and 3,500 / ₦35,000, with no default bonus credits. This is a nominal ₦10 per ANONYMOUX credit; admin edits and bonus credits can change the effective rate.

The previously documented 6 credits/sec standard and 11 credits/sec Fast figures are candidates only. At nominal ₦10/credit they equal ₦60/sec and ₦110/sec. Simple FX break-even against Decart is ₦3,000/USD (standard) and ₦2,750/USD (Fast), before transaction fees and operating margin. They are not activated.

**No ANONYMOUX realtime wallet debit is currently enforced.** The shared billing layer only supports image and video. SDK-direct sessions do not have trusted server-side usage reconciliation in this build. The workspace now clearly discloses Decart provider rates and warns users that wallet balance is not a realtime spending limit. Do not advertise a platform realtime credit rate or sell realtime usage as credit-metered until trusted metering, atomic reserve/settle/refund, maximum-session limits, disconnect recovery and end-to-end billing tests are implemented.

## Verification

Static PHP syntax, JavaScript syntax, source regression checks and ZIP integrity are run for this build. These do not replace deployed browser/provider tests.
