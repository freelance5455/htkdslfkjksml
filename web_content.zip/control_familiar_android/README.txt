CONTROL FAMILIAR — PROYECTO ANDROID

Este ZIP es un proyecto Android Studio (fuente), no un APK ya compilado.

Incluye:
- La app de control de ingresos y gastos dentro de una WebView Android.
- El logo enviado por el usuario como icono de la app y recurso de marca.
- Almacenamiento local de los movimientos mediante localStorage del WebView.
- Funcionamiento sin conexión porque la interfaz está incluida dentro de la app.

Para generar el APK:
1. Abrir esta carpeta en Android Studio (versión reciente).
2. Instalar Android SDK Platform 35 cuando Android Studio lo solicite.
3. Esperar la sincronización de Gradle.
4. Elegir Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio generará app-debug.apk dentro de app/build/outputs/apk/debug/.

IMPORTANTE:
- El APK solo funciona en Android. No se puede instalar en el iPhone de tu esposa.
- Los datos quedan guardados en ese dispositivo. No hay sincronización entre teléfonos.
- Para compartir datos entre dos Android se necesita agregar un backend y autenticación.
- No se entrega un APK compilado en este archivo; es el proyecto preparado para compilar.
