require("dotenv").config();
const express = require("express");
const helmet = require("helmet");
const multer = require("multer");
const path = require("path");
const fs = require("fs");
const crypto = require("crypto");
const { spawn } = require("child_process");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const ROOT = path.resolve(__dirname, "..");
const PUBLIC = path.join(ROOT, "public");
const UPLOADS = path.join(__dirname, "uploads");
const OUTPUTS = path.join(__dirname, "outputs");
for (const d of [UPLOADS, OUTPUTS]) fs.mkdirSync(d, { recursive: true });
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "1mb" }));
app.use(express.static(PUBLIC));
app.use("/outputs", express.static(OUTPUTS, { maxAge: "1h" }));

const maxMb = Math.max(10, Number(process.env.MAX_UPLOAD_MB || 250));
const storage = multer.diskStorage({ destination: (_req,_file,cb)=>cb(null,UPLOADS), filename: (_req,file,cb)=>cb(null,crypto.randomUUID()+path.extname(file.originalname).slice(0,10)) });
const upload = multer({ storage, limits:{fileSize:maxMb*1024*1024,files:2}, fileFilter:(_req,file,cb)=>{
  const ok=file.fieldname==="video" ? file.mimetype.startsWith("video/") : file.fieldname==="music" ? file.mimetype.startsWith("audio/") : false;
  cb(ok?null:new Error("نوع ملف غير مدعوم."),ok);
}});
const jobs = new Map();
function run(cmd,args){return new Promise((resolve,reject)=>{const p=spawn(cmd,args);let err="";p.stderr.on("data",d=>{err+=d.toString();if(err.length>8000)err=err.slice(-8000)});p.on("error",e=>reject(new Error(cmd==="ffmpeg"?"FFmpeg غير مثبت على الخادم.":e.message)));p.on("close",c=>c===0?resolve():reject(new Error(err.slice(-1200)||`${cmd} failed`)))})}
function hasFfmpeg(){return new Promise(resolve=>{const p=spawn("ffmpeg",["-version"]);p.on("error",()=>resolve(false));p.on("close",c=>resolve(c===0))})}
function localUrl(file){const base=(process.env.PUBLIC_BASE_URL||`http://localhost:${PORT}`).replace(/\/$/,"");return `${base}/outputs/${path.basename(file)}`}
function safeText(s){return String(s||"").slice(0,80).replace(/\\/g,"\\\\").replace(/:/g,"\\:").replace(/'/g,"\\'").replace(/%/g,"\\%").replace(/\n/g," ").replace(/;/g,"\\;")}
function makeVideoFilter({ratio,style,speed,overlayText}){
 let f=[];
 if(ratio==="9:16") f.push("crop='if(gt(a,9/16),ih*9/16,iw)':'if(gt(a,9/16),ih,iw*16/9)'");
 else if(ratio==="16:9") f.push("crop='if(gt(a,16/9),ih*16/9,iw)':'if(gt(a,16/9),ih,iw*9/16)'");
 else if(ratio==="1:1") f.push("crop='min(iw,ih)':'min(iw,ih)'");
 if(style==="cinematic") f.push("eq=contrast=1.12:saturation=1.08:brightness=-0.015");
 if(style==="glitch") f.push("eq=contrast=1.2:saturation=1.45");
 if(style==="mono") f.push("hue=s=0");
 if(style==="vivid") f.push("eq=saturation=1.45:contrast=1.08");
 const sp=Math.max(.5,Math.min(2,Number(speed||1))); if(sp!==1) f.push(`setpts=${(1/sp).toFixed(4)}*PTS`);
 if(overlayText&&overlayText.trim()) f.push(`drawtext=text='${safeText(overlayText)}':fontcolor=white:fontsize=h/18:borderw=3:bordercolor=black:x=(w-text_w)/2:y=h*0.78`);
 f.push("scale=trunc(iw/2)*2:trunc(ih/2)*2");
 return f.join(",");
}
app.get("/api/health",async(_req,res)=>res.json({ok:true,aiProvider:process.env.AI_VIDEO_PROVIDER||"disabled",ffmpegAvailable:await hasFfmpeg()}));

/*
  Optional Fal queue API adapter:
  Set AI_VIDEO_PROVIDER=fal, FAL_API_KEY, FAL_MODEL_ID.
  FAL_EXTRA_JSON can contain model-specific fields as JSON. Prompt, aspect_ratio,
  and duration are provided by default; verify these fields against your chosen model.
*/
app.post("/api/generate",async(req,res)=>{
 const {prompt,style="cinematic",aspectRatio="9:16",duration=8,quality="720p"}=req.body||{};
 if(typeof prompt!=="string"||prompt.trim().length<4)return res.status(400).json({error:"اكتب وصفًا واضحًا للفيديو."});
 if(!["9:16","16:9","1:1"].includes(aspectRatio))return res.status(400).json({error:"مقاس الفيديو غير صالح."});
 if(![5,8,10].includes(Number(duration)))return res.status(400).json({error:"مدة الفيديو غير مدعومة."});
 const provider=(process.env.AI_VIDEO_PROVIDER||"disabled").toLowerCase();
 if(provider!=="fal")return res.status(503).json({error:"توليد AI غير موصّل. أضف FAL_API_KEY وFAL_MODEL_ID إلى ملف .env بعد اختيار موديل متوافق، ثم أعد تشغيل الخادم."});
 if(!process.env.FAL_API_KEY||!process.env.FAL_MODEL_ID)return res.status(503).json({error:"إعدادات Fal ناقصة: يلزم FAL_API_KEY وFAL_MODEL_ID."});
 let extra={};try{extra=JSON.parse(process.env.FAL_EXTRA_JSON||"{}")}catch{return res.status(500).json({error:"قيمة FAL_EXTRA_JSON ليست JSON صالحًا."})}
 const payload={...extra,prompt:prompt.trim(),aspect_ratio:aspectRatio,duration:Number(duration)};
 // Include a style hint in the prompt so it works with models that expose only a prompt field.
 const styleHint={football:"dynamic football edit, athletic movement, stadium lights",anime:"anime-inspired cinematic motion, expressive lighting",character:"stylized character edit, dramatic camera movement",cinematic:"cinematic lighting and camera movement",velocity:"dynamic velocity edit, energetic pacing",glitch:"neon glitch aesthetic, high contrast"}[style]||"cinematic";
 payload.prompt=`${payload.prompt}. Visual direction: ${styleHint}. Target quality: ${quality}.`;
 try{
  const r=await fetch(`https://queue.fal.run/${process.env.FAL_MODEL_ID}`,{method:"POST",headers:{"Authorization":`Key ${process.env.FAL_API_KEY}`,"Content-Type":"application/json"},body:JSON.stringify(payload)});
  const d=await r.json().catch(()=>({}));
  if(!r.ok)return res.status(502).json({error:d.detail||d.message||`فشل مزود التوليد (HTTP ${r.status}). راجع اسم الموديل والحقول المطلوبة.`});
  const id=d.request_id||d.requestId;
  if(!id&&!d.video?.url&&!d.video_url)return res.status(502).json({error:"المزوّد لم يُرجع request_id أو رابط فيديو معروفًا. راجع صيغة استجابة الموديل."});
  if(d.video?.url||d.video_url)return res.json({status:"completed",videoUrl:d.video?.url||d.video_url});
  const job={id,status:"processing",provider:"fal",modelId:process.env.FAL_MODEL_ID,statusUrl:d.status_url||null,responseUrl:d.response_url||null,createdAt:Date.now()};
  jobs.set(id,job);
  res.json({jobId:id,status:"processing"});
 }catch(e){res.status(502).json({error:"تعذر الاتصال بمزوّد الفيديو: "+e.message})}
});
app.get("/api/jobs/:id",async(req,res)=>{
 const job=jobs.get(req.params.id);
 if(!job)return res.status(404).json({error:"المهمة غير موجودة في ذاكرة الخادم. قد تكون انتهت جلسة الخادم."});
 if(job.status==="completed"||job.status==="failed")return res.json(job);
 if(job.provider!=="fal")return res.json(job);
 try{
  const statusUrl=job.statusUrl||`https://queue.fal.run/${job.modelId}/requests/${encodeURIComponent(job.id)}/status`;
  const sr=await fetch(statusUrl,{headers:{"Authorization":`Key ${process.env.FAL_API_KEY}`}});
  const sd=await sr.json().catch(()=>({}));
  if(!sr.ok)throw new Error(sd.detail||`status HTTP ${sr.status}`);
  const state=String(sd.status||sd.state||"IN_PROGRESS").toUpperCase();
  if(["FAILED","ERROR","CANCELLED"].includes(state)){job.status="failed";job.error=sd.error||sd.detail||"مهمة التوليد فشلت";return res.json(job)}
  if(["COMPLETED","SUCCEEDED","SUCCESS"].includes(state)){
   const responseUrl=job.responseUrl||`https://queue.fal.run/${job.modelId}/requests/${encodeURIComponent(job.id)}`;
   const rr=await fetch(responseUrl,{headers:{"Authorization":`Key ${process.env.FAL_API_KEY}`}});
   const rd=await rr.json().catch(()=>({}));
   if(!rr.ok)throw new Error(rd.detail||`response HTTP ${rr.status}`);
   const videoUrl=rd.video?.url||rd.video_url||rd.output?.video?.url||rd.output?.url||rd.videos?.[0]?.url;
   if(!videoUrl)throw new Error("اكتملت المهمة لكن لم يُعثر على رابط الفيديو في الاستجابة؛ راجع صيغة موديلك.");
   job.status="completed";job.videoUrl=videoUrl;job.completedAt=Date.now();
  }else job.status="processing";
  return res.json(job);
 }catch(e){return res.status(502).json({error:"تعذرت متابعة المهمة: "+e.message})}
});
app.post("/api/edit",upload.fields([{name:"video",maxCount:1},{name:"music",maxCount:1}]),async(req,res)=>{
 const video=req.files?.video?.[0],music=req.files?.music?.[0];
 if(!video){if(music)fs.unlink(music.path,()=>{});return res.status(400).json({error:"اختار ملف فيديو صالح."})}
 const output=path.join(OUTPUTS,`${crypto.randomUUID()}.mp4`);
 const ratio=["keep","9:16","16:9","1:1"].includes(req.body.aspectRatio)?req.body.aspectRatio:"keep";
 const style=["clean","cinematic","glitch","mono","vivid"].includes(req.body.style)?req.body.style:"clean";
 const start=Math.max(0,Number(req.body.trimStart||0)),end=Math.max(0,Number(req.body.trimEnd||0));
 if(end>0&&end<=start){fs.unlink(video.path,()=>{});if(music)fs.unlink(music.path,()=>{});return res.status(400).json({error:"نهاية القصّ يجب أن تكون أكبر من البداية."})}
 const filter=makeVideoFilter({ratio:ratio==="keep"?null:ratio,style,speed:req.body.speed,overlayText:req.body.overlayText});
 const args=["-y","-hide_banner","-i",video.path];
 if(music)args.push("-stream_loop","-1","-i",music.path);
 args.push("-ss",String(start));
 if(end>0)args.push("-t",String(end-start));
 args.push("-vf",filter,"-map","0:v:0");
 if(music){args.push("-map","1:a:0","-af","volume=0.85","-shortest");}
 else args.push("-map","0:a?");
 args.push("-c:v","libx264","-preset","veryfast","-crf","21","-pix_fmt","yuv420p","-c:a","aac","-b:a","192k","-movflags","+faststart",output);
 try{
  await run("ffmpeg",args);
  fs.unlink(video.path,()=>{});if(music)fs.unlink(music.path,()=>{});
  return res.json({status:"completed",videoUrl:localUrl(output),message:"اكتمل تصدير الفيديو."});
 }catch(e){
  fs.unlink(video.path,()=>{});if(music)fs.unlink(music.path,()=>{});fs.unlink(output,()=>{});
  return res.status(500).json({error:e.message||"تعذر تنفيذ المونتاج."});
 }
});
app.use((err,_req,res,_next)=>{
 if(err instanceof multer.MulterError&&err.code==="LIMIT_FILE_SIZE")return res.status(413).json({error:`حجم الملف أكبر من ${maxMb} ميجابايت.`});
 res.status(400).json({error:err.message||"طلب غير صالح."});
});
app.listen(PORT,()=>console.log(`EditForge AI v2.0 running at http://localhost:${PORT}`));
