# ANONYMOUX STUDIO 2.5.7 — build verification report

## Changes delivered in this repair build

- Public account registration always assigns `member`; the first public registrant can no longer become administrator.
- Added `tools-create-admin.php`, which is CLI-only, refuses to create a second administrator, and requires a password of at least 12 characters. The password can be supplied via `ANONYMOUX_ADMIN_PASSWORD` so it need not be placed in shell history.
- Updated signup messaging and deployment instructions with the first-admin provisioning and verified-account recovery commands.
- Improved the Tools & Tutorials admin list with visible tool logo thumbnails, while retaining tool CRUD, draft/publish, categories, search, bulk publish/draft/delete, official HTTPS links, compatibility fields, tutorial editing, attached media and resource relations.
- Refreshed responsive Tools directory surfaces, card backgrounds and action controls.
- Corrected deployment instructions to reflect the SQLite-only database requirement and added Nginx storage/config deny guidance.

## Automated checks

- PHP syntax: 82 PHP files passed `php -l` after the repair.
- JavaScript syntax: all JavaScript files under `assets/` passed `node --check`.
- Python regression suites passed:
  - Fish Audio Agent contract checks
  - Billing source checks
  - SQLite billing contract (3 tests)
  - Branding and voice integration checks
  - Tools & Tutorials admin regression checks
  - Resource migration/idempotency checks
  - Voice dashboard, voice flow and voice idempotency checks
  - New administrator-bootstrap security regression check
- ZIP integrity checked after packaging.

## Environment limitations — not represented as passed

This build container has PHP 8.4 but does not have `pdo_sqlite`, `pdo_mysql`, cURL or mbstring. Therefore it cannot execute the PHP database layer, apply migrations through PDO, perform live Flutterwave requests, or connect to Fish Audio/LiveKit. No provider credentials or production server were supplied. The existing Python SQLite contract tests exercise schema/query semantics but are not a substitute for the live PHP runtime.

## Required staging acceptance

1. Back up production `storage/workspace.sqlite` and uploaded files.
2. Enable `pdo_sqlite`, cURL, OpenSSL, JSON and fileinfo on the hosting PHP runtime.
3. Create/verify the site administrator through the CLI process; confirm a fresh public signup is only a member.
4. Verify Nginx/Apache blocks direct access to storage and private configuration.
5. Exercise the Tools directory and Admin → Tools & Tutorials: create, edit, upload a logo, publish, unpublish, search, filter categories, bulk action and remove records.
6. Test Fish Audio agent create/publish/text/voice/session-close and provider usage reconciliation on HTTPS.
7. Test Flutterwave in test mode, including duplicate signed webhook delivery and wallet idempotency.
8. Verify dashboard and studio flows on mobile and desktop.

**Release status:** Source-level repair and automated regression checks completed. Production readiness remains pending the staging acceptance steps above.
