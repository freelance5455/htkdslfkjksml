// Secure preload boundary. The current Gezeno web application does not need Node APIs.
// Keeping this file allows the application to be packaged as a native Electron desktop app
// without exposing Node integration to the page.
