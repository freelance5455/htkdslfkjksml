
const DEFAULTS={brand:'Gezeno Business Suite',subtitle:'Amazon • Flipkart • Meesho Marketplace Management',username:'gezeno',password:'gezeno123',phone:'+91 9711911391',businessGSTIN:'07AWMPM4029M1Z2'};
let storedCfg=null;try{storedCfg=JSON.parse(localStorage.getItem('gezenoConfig')||'null')}catch(e){storedCfg=null}
let cfg={invoiceFormat:'modern',ownerName:'Chander Mohan',address:'Delhi (Uttam Nagar)',phone:DEFAULTS.phone,email:'gezeno.official@gmail.com',gstin:DEFAULTS.businessGSTIN,businessGSTIN:DEFAULTS.businessGSTIN,logo:'',logoWidth:180,catalogHeaderMode:'brand',...DEFAULTS,...(storedCfg||{})};
// One-time login migration: old/broken demo credentials are replaced by the working Gezeno defaults.
if(cfg.authVersion!==2 || !String(cfg.username||'').trim() || !String(cfg.password||'')){cfg.username=DEFAULTS.username;cfg.password=DEFAULTS.password;cfg.authVersion=2;localStorage.setItem('gezenoConfig',JSON.stringify(cfg));}
if(cfg.username==='gezeno.owner'||cfg.password==='Gz@2026#01'){cfg.username=DEFAULTS.username;cfg.password=DEFAULTS.password;cfg.authVersion=2;localStorage.setItem('gezenoConfig',JSON.stringify(cfg));}
cfg.ownerName=String(cfg.ownerName||'Chander Mohan').trim();cfg.phone=String(cfg.phone||DEFAULTS.phone).trim();cfg.businessGSTIN=String(cfg.businessGSTIN||cfg.gstin||DEFAULTS.businessGSTIN).trim().toUpperCase();cfg.gstin=cfg.businessGSTIN;
const marketplaceSections={marketplaceListings:{label:'Marketplace Listings',fields:[['channel','Marketplace','select',['Amazon','Flipkart','Meesho','Other']],['sku','SKU'],['product','Product Name'],['marketplaceSku','Marketplace SKU'],['listingId','Listing ID'],['sellingPrice','Selling Price','number'],['commission','Commission %','number'],['shippingFee','Shipping Fee','number'],['status','Listing Status','select',['Draft','Active','Inactive','Suppressed']]]},marketplaceOrders:{label:'Marketplace Orders',fields:[['orderId','Marketplace Order ID'],['channel','Marketplace','select',['Amazon','Flipkart','Meesho','Other']],['date','Order Date','date'],['customer','Delivery Customer'],['sku','SKU'],['qty','Qty','number'],['sellingPrice','Selling Price (GST Incl.)','number'],['gstRate','GST Rate %','number'],['gstAmount','Sales GST','number'],['commission','Marketplace Fee (incl. GST)','number'],['feeGst','Fee GST','number'],['shippingFee','Shipping Fee','number'],['adsCost','Ads Cost','number'],['returnCost','Return Cost','number'],['otherCost','Other Order Cost','number'],['courier','Courier'],['awb','AWB / Tracking'],['status','Order Status','select',['New','Confirmed','Packed','Ready for Pickup','Picked Up','Shipped','Out for Delivery','Delivered','Cancelled','Returned']],['paymentStatus','Settlement Status','select',['Pending','Settled','Partial']]]},marketplaceSettlements:{label:'Settlements',fields:[['settlementId','Settlement ID'],['channel','Marketplace','select',['Amazon','Flipkart','Meesho','Other']],['fromDate','From Date','date'],['toDate','To Date','date'],['gross','Gross Sales (GST Incl.)','number'],['salesGst','Sales GST','number'],['fees','Marketplace Fees (GST Incl.)','number'],['feeGst','Fee GST','number'],['tcs','TCS','number'],['tds','TDS','number'],['refunds','Refunds','number'],['shipping','Shipping Charges','number'],['otherDeductions','Other Deductions','number'],['adjustments','Adjustments / Credits','number'],['netReceived','Actual Bank Received','number'],['receivedDate','Received Date','date'],['bankRef','Bank / UTR Reference'],['status','Status','select',['Pending','Reconciled','Mismatch']]]},marketplaceReturns:{label:'Returns & Refunds',fields:[['returnId','Return ID'],['channel','Marketplace','select',['Amazon','Flipkart','Meesho','Other']],['orderId','Order ID'],['date','Return Date','date'],['sku','SKU'],['qty','Qty','number'],['reason','Reason'],['refund','Refund Amount','number'],['reverseShipping','Reverse Shipping','number'],['status','Return Status','select',['Requested','Received','Refunded','Closed']],['loss','Loss Amount','number']]},marketplaceAds:{label:'Marketplace Ads',fields:[['channel','Marketplace','select',['Amazon','Flipkart','Meesho','Other']],['date','Date','date'],['campaign','Campaign'],['spend','Ad Spend','number'],['sales','Attributed Sales','number'],['orders','Attributed Orders','number'],['status','Status','select',['Running','Paused','Completed']]]}};
const sections={expenses:{label:'Expenses',fields:[['date','Expense Date','date'],['category','Category'],['amount','Amount','number'],['note','Note']]},vendors:{label:'Vendors',fields:[['name','Shop / Company Name'],['contact','Person Name'],['phone','Phone','tel'],['address','Full Address'],['city','City'],['state','State'],['pincode','PIN Code'],['gstin','GST Number'],['category','Category']]},products:{label:'Products',fields:[['image','Product Image','image'],['sku','SKU'],['name','Product Name'],['parentCategory','Category Group','parentcat'],['category','Category'],['vendor','Vendor'],['purchase','Purchase / Landed Cost','number'],['b2b','Marketplace Base Selling Price','number'],['mrp','MRP','number'],['hsn','HSN / SAC Code'],['gst','GST %','gst'],['stock','Stock','number'],['reorder','Reorder Level','number']]},invoices:{label:'GST Invoices',fields:[['invoiceNo','Invoice No.','auto'],['orderNo','Marketplace Order ID','order'],['marketplace','Marketplace','select',['Amazon','Flipkart','Meesho']],['customer','Delivery Customer','customer'],['date','Invoice Date','date'],['subtotal','Subtotal','number'],['discount','Discount','number'],['transport','Transport','number'],['gstAmount','GST Amount','number'],['total','Total','number'],['paidAmount','Paid Amount','number'],['dueAmount','Due Amount','number'],['status','Payment Status','select',['Pending','Partial','Paid','Cancelled']]]},stock:{label:'Inventory',fields:[['sku','SKU'],['product','Product'],['inStock','In Stock','number'],['reorder','Reorder Level','number'],['note','Note']]},purchases:{label:'Purchases',fields:[['poNo','PO No.','auto'],['vendor','Vendor','vendor'],['date','Purchase Date','date'],['subtotal','Subtotal','number'],['discount','Discount','number'],['transport','Transport','number'],['gstAmount','Purchase GST','number'],['total','Total Purchase','number'],['status','Status','select',['Ordered','Received','Partial','Cancelled']]]}};
Object.assign(sections,marketplaceSections);
let data=JSON.parse(localStorage.getItem('gezenoData')||'{}'),current='dashboard',editing=null;
// V103: Main business data is stored in the device's IndexedDB instead of localStorage.
// Android WebView/localStorage is typically limited to a few MB; IndexedDB is designed
// for much larger local datasets and survives app/browser restarts on the same device.
let deviceDB=null,deviceStorageReady=false,deviceSavePending=false,deviceStorageOpening=null;
function openDeviceDB(){
  if(deviceStorageOpening)return deviceStorageOpening;
  deviceStorageOpening=new Promise((resolve,reject)=>{
    try{
      if(!('indexedDB' in window)){reject(new Error('IndexedDB supported nahi hai'));return;}
      const req=indexedDB.open('GezenoDeviceDB',1);
      req.onupgradeneeded=()=>{const db=req.result;if(!db.objectStoreNames.contains('appData'))db.createObjectStore('appData');};
      req.onsuccess=()=>{deviceDB=req.result;resolve(db);};
      req.onerror=()=>reject(req.error||new Error('IndexedDB open failed'));
    }catch(e){reject(e)}
  });
  return deviceStorageOpening;
}
function idbGet(db,key){return new Promise((resolve,reject)=>{try{const r=db.transaction('appData','readonly').objectStore('appData').get(key);r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error)}catch(e){reject(e)}})}
function idbPut(db,key,value){return new Promise((resolve,reject)=>{try{const r=db.transaction('appData','readwrite').objectStore('appData').put(value,key);r.onsuccess=()=>resolve(true);r.onerror=()=>reject(r.error)}catch(e){reject(e)}})}
async function initDeviceStorage(){
  try{
    const db=await openDeviceDB();
    const saved=await idbGet(db,'gezenoData');
    if(saved && typeof saved==='object'){
      data=saved;
    }else{
      // First run after V102: migrate the existing localStorage dataset once.
      await idbPut(db,'gezenoData',data);
    }
    deviceStorageReady=true;
    // Free the old large localStorage payload only after IndexedDB has confirmed the write.
    try{localStorage.removeItem('gezenoData');}catch(e){}
    if(deviceSavePending){deviceSavePending=false;await idbPut(db,'gezenoData',data);}
    if(typeof applyBrand==='function')applyBrand();
    if(typeof ensureMarketplaceV6==='function')ensureMarketplaceV6();
    if(typeof show==='function' && document.getElementById('app')?.style.display!=='none')show(current);
    console.info('Gezeno: device storage active (IndexedDB)');
  }catch(e){
    console.error('Gezeno device storage init failed',e);
    // Keep the app usable with the legacy store if IndexedDB is unavailable.
    deviceStorageReady=false;
  }
}

for(const k in sections)if(!Array.isArray(data[k]))data[k]=[];
if(!Array.isArray(data.bankTransactions))data.bankTransactions=[];
if(!Array.isArray(data.reconUploads))data.reconUploads=[];
if(!Array.isArray(data.monthlyDumps))data.monthlyDumps=[];
if(!Array.isArray(data.reconRawRows))data.reconRawRows=[];
if(!Array.isArray(data.gstr1Records))data.gstr1Records=[];
if(!Array.isArray(data.gstr1Imports))data.gstr1Imports=[];
function cleanLegacyB2BDemo(){
  const demoCustomers=['Happy Kids Store','New Star Gift House','Kids World Stationery'];
  const demoOrders=['ORD-1001','ORD-1002','ORD-1003'];
  const demoInvoices=['INV-1001','INV-1002'];
  const demoReceipts=['REC-001','REC-002'];
  data.customers=(data.customers||[]).filter(x=>!demoCustomers.includes(x.name));
  data.orders=(data.orders||[]).filter(x=>!demoOrders.includes(x.orderNo));
  data.invoices=(data.invoices||[]).filter(x=>!demoInvoices.includes(x.invoiceNo));
  data.payments=(data.payments||[]).filter(x=>!demoReceipts.includes(x.receiptNo));
  localStorage.setItem('gezenoLegacyB2BCleanedV12','1');
}

function seed(){
  const seedKey='gezenoMarketplaceSeedV12';
  if(localStorage.getItem(seedKey))return;
  data.customers=[]; data.orders=[]; data.payments=[]; data.invoices=[];
  data.vendors=[{name:'Demo Toys Supplier',contact:'Amit',phone:'9811100101',address:'Sadar Bazaar',city:'Delhi',state:'Delhi',pincode:'110006',gstin:'07DEMOA1234F1Z1',category:'Toys'},{name:'Demo Electronics Supplier',contact:'Rakesh',phone:'9811100102',address:'Bhagirath Palace',city:'Delhi',state:'Delhi',pincode:'110006',gstin:'07DEMOB5678F1Z2',category:'Electronics'}];
  data.products=[
    {sku:'GZN-001',name:'Interactive Learning Book',category:'Learning Toys',parentCategory:'Toys',vendor:'Demo Toys Supplier',purchase:350,b2b:699,mrp:799,gst:5,stock:45,reorder:10},
    {sku:'GZN-002',name:'2-in-1 LCD Writing Pad',category:'Educational Toys',parentCategory:'Toys',vendor:'Demo Toys Supplier',purchase:120,b2b:249,mrp:299,gst:12,stock:70,reorder:15},
    {sku:'GZN-003',name:'Air Dry Clay Kit 12 Colors',category:'Arts & Crafts',parentCategory:'Toys',vendor:'Demo Toys Supplier',purchase:90,b2b:199,mrp:249,gst:5,stock:55,reorder:10},
    {sku:'GZN-004',name:'Kids Wireless Headphone',category:'Audio Accessories',parentCategory:'Electronics',vendor:'Demo Electronics Supplier',purchase:280,b2b:599,mrp:699,gst:18,stock:30,reorder:8},
    {sku:'GZN-005',name:'Mini Building Blocks Set',category:'Building Toys',parentCategory:'Toys',vendor:'Demo Toys Supplier',purchase:150,b2b:299,mrp:399,gst:12,stock:40,reorder:10}
  ];
  data.stock=data.products.map(p=>({sku:p.sku,product:p.name,inStock:p.stock,reorder:p.reorder,note:p.stock<=p.reorder?'Low Stock':'OK'}));
  data.purchases=[{poNo:'PO-1001',vendor:'Demo Toys Supplier',date:'2026-09-20',subtotal:5000,discount:0,transport:250,gstAmount:262.5,total:5512.5,status:'Received',items:[{sku:'GZN-001',name:'Interactive Learning Book',qty:10,rate:350},{sku:'GZN-002',name:'2-in-1 LCD Writing Pad',qty:20,rate:120}]},{poNo:'PO-1002',vendor:'Demo Electronics Supplier',date:'2026-09-24',subtotal:5600,discount:200,transport:300,gstAmount:972,total:6672,status:'Received',items:[{sku:'GZN-004',name:'Kids Wireless Headphone',qty:20,rate:280}]}];
  data.expenses=[{date:'2026-09-24',category:'Packaging',amount:850,note:'Marketplace packing material'},{date:'2026-09-26',category:'Transport',amount:450,note:'Inbound stock transport'}];
  data.marketplaceListings=[{channel:'Amazon',sku:'GZN-001',product:'Interactive Learning Book',marketplaceSku:'AMZ-GZN001',listingId:'B0AMZ001',sellingPrice:799,commission:12,shippingFee:65,status:'Active'},{channel:'Flipkart',sku:'GZN-002',product:'2-in-1 LCD Writing Pad',marketplaceSku:'FK-GZN002',listingId:'LST-FK002',sellingPrice:299,commission:14,shippingFee:55,status:'Active'},{channel:'Meesho',sku:'GZN-003',product:'Air Dry Clay Kit 12 Colors',marketplaceSku:'MS-GZN003',listingId:'LST-MS003',sellingPrice:249,commission:0,shippingFee:48,status:'Active'},{channel:'Amazon',sku:'GZN-004',product:'Kids Wireless Headphone',marketplaceSku:'AMZ-GZN004',listingId:'B0AMZ004',sellingPrice:699,commission:16,shippingFee:70,status:'Active'}];
  data.marketplaceOrders=[{orderId:'AMZ-5001',channel:'Amazon',date:'2026-09-28',customer:'Demo Amazon Buyer',sku:'GZN-001',qty:2,sellingPrice:1598,commission:191.76,shippingFee:130,adsCost:30,returnCost:0,courier:'Amazon Logistics',awb:'AMZAWB5001',status:'Delivered',paymentStatus:'Settled'},{orderId:'AMZ-5002',channel:'Amazon',date:'2026-09-29',customer:'Demo Amazon Buyer 2',sku:'GZN-004',qty:1,sellingPrice:699,commission:111.84,shippingFee:70,adsCost:15,returnCost:0,courier:'Delhivery',awb:'DEL5002',status:'Out for Delivery',paymentStatus:'Pending'},{orderId:'FK-5003',channel:'Flipkart',date:'2026-09-30',customer:'Demo Flipkart Buyer',sku:'GZN-002',qty:3,sellingPrice:897,commission:125.58,shippingFee:165,adsCost:12,returnCost:0,courier:'Ekart',awb:'EK5003',status:'Shipped',paymentStatus:'Pending'},{orderId:'MS-5004',channel:'Meesho',date:'2026-10-01',customer:'Demo Meesho Buyer',sku:'GZN-003',qty:2,sellingPrice:498,commission:0,shippingFee:96,adsCost:8,returnCost:96,courier:'Xpressbees',awb:'XB5004',status:'Returned',paymentStatus:'Partial'}];
  data.marketplaceSettlements=[{settlementId:'SET-AMZ-101',channel:'Amazon',fromDate:'2026-09-20',toDate:'2026-09-27',gross:18500,fees:2220,tcs:185,tds:92.5,refunds:500,shipping:1050,netReceived:14452.5,status:'Reconciled'},{settlementId:'SET-FK-101',channel:'Flipkart',fromDate:'2026-09-22',toDate:'2026-09-29',gross:12500,fees:1750,tcs:125,tds:62.5,refunds:300,shipping:750,netReceived:9512.5,status:'Reconciled'},{settlementId:'SET-MS-101',channel:'Meesho',fromDate:'2026-09-24',toDate:'2026-10-01',gross:8200,fees:0,tcs:82,tds:41,refunds:450,shipping:620,netReceived:7007,status:'Pending'}];
  data.marketplaceReturns=[{returnId:'RET-101',channel:'Meesho',orderId:'MS-5004',date:'2026-10-01',sku:'GZN-003',qty:2,reason:'Customer return',refund:498,reverseShipping:96,status:'Received',loss:186}];
  data.marketplaceAds=[{channel:'Amazon',date:'2026-09-28',campaign:'Learning Book Sponsored Ads',spend:300,sales:2200,orders:5,status:'Running'},{channel:'Flipkart',date:'2026-09-29',campaign:'Writing Pad Boost',spend:180,sales:1500,orders:6,status:'Running'},{channel:'Meesho',date:'2026-10-01',campaign:'Clay Kit Promotion',spend:120,sales:900,orders:4,status:'Completed'}];
  localStorage.setItem(seedKey,'1'); save();
}


function seedMarketplaceDemoV14(){
  const key='gezenoMarketplaceDemoV14';
  if(localStorage.getItem(key)) return;
  const demoOrders=[
    {orderId:'AMZ-DEMO-1001',channel:'Amazon',date:'2026-10-01',customer:'Demo Delivery Customer A',sku:'GZN-001',qty:2,sellingPrice:1598,commission:191.76,shippingFee:130,adsCost:30,returnCost:0,courier:'Amazon Logistics',awb:'AMZ-DEMO-A01',status:'Delivered',paymentStatus:'Settled'},
    {orderId:'AMZ-DEMO-1002',channel:'Amazon',date:'2026-10-02',customer:'Demo Delivery Customer B',sku:'GZN-004',qty:1,sellingPrice:699,commission:111.84,shippingFee:70,adsCost:15,returnCost:0,courier:'Delhivery',awb:'AMZ-DEMO-A02',status:'Shipped',paymentStatus:'Pending'},
    {orderId:'FK-DEMO-1003',channel:'Flipkart',date:'2026-10-02',customer:'Demo Delivery Customer C',sku:'GZN-002',qty:3,sellingPrice:897,commission:125.58,shippingFee:165,adsCost:12,returnCost:0,courier:'Ekart',awb:'FK-DEMO-F01',status:'Delivered',paymentStatus:'Settled'},
    {orderId:'FK-DEMO-1004',channel:'Flipkart',date:'2026-10-03',customer:'Demo Delivery Customer D',sku:'GZN-005',qty:2,sellingPrice:598,commission:83.72,shippingFee:110,adsCost:8,returnCost:0,courier:'Ekart',awb:'FK-DEMO-F02',status:'Out for Delivery',paymentStatus:'Pending'},
    {orderId:'MS-DEMO-1005',channel:'Meesho',date:'2026-10-03',customer:'Demo Delivery Customer E',sku:'GZN-003',qty:2,sellingPrice:498,commission:0,shippingFee:96,adsCost:8,returnCost:96,courier:'Xpressbees',awb:'MS-DEMO-M01',status:'Returned',paymentStatus:'Partial'},
    {orderId:'MS-DEMO-1006',channel:'Meesho',date:'2026-10-04',customer:'Demo Delivery Customer F',sku:'GZN-002',qty:1,sellingPrice:249,commission:0,shippingFee:45,adsCost:4,returnCost:0,courier:'Delhivery',awb:'MS-DEMO-M02',status:'Packed',paymentStatus:'Pending'}
  ];
  const existingIds=new Set((data.marketplaceOrders||[]).map(o=>o.orderId));
  data.marketplaceOrders=[...(data.marketplaceOrders||[]),...demoOrders.filter(o=>!existingIds.has(o.orderId))];
  const demoSets=[
    {settlementId:'SET-AMZ-DEMO-01',channel:'Amazon',fromDate:'2026-10-01',toDate:'2026-10-02',gross:2297,salesGst:182.72,fees:303.6,feeGst:46.37,tcs:22.97,tds:2.3,refunds:0,shipping:200,otherDeductions:0,adjustments:0,netReceived:1768.13,receivedDate:'2026-10-03',bankRef:'AMZ-UTR-DEMO-01',status:'Reconciled'},
    {settlementId:'SET-FK-DEMO-01',channel:'Flipkart',fromDate:'2026-10-02',toDate:'2026-10-03',gross:1495,salesGst:160.18,fees:209.3,feeGst:31.93,tcs:14.95,tds:1.5,refunds:0,shipping:275,otherDeductions:0,adjustments:0,netReceived:994.25,receivedDate:'2026-10-04',bankRef:'FK-UTR-DEMO-01',status:'Reconciled'},
    {settlementId:'SET-MS-DEMO-01',channel:'Meesho',fromDate:'2026-10-03',toDate:'2026-10-04',gross:747,salesGst:50.39,fees:0,feeGst:0,tcs:7.47,tds:.75,refunds:249,shipping:141,otherDeductions:0,adjustments:0,netReceived:348.78,receivedDate:'',bankRef:'',status:'Pending'}
  ];
  const existingSets=new Set((data.marketplaceSettlements||[]).map(x=>x.settlementId));
  data.marketplaceSettlements=[...(data.marketplaceSettlements||[]),...demoSets.filter(x=>!existingSets.has(x.settlementId))];
  const demoAds=[
    {channel:'Amazon',date:'2026-10-01',campaign:'Demo Sponsored Learning',spend:45,sales:300,orders:2,status:'Completed'},
    {channel:'Flipkart',date:'2026-10-02',campaign:'Demo Writing Pad Boost',spend:35,sales:250,orders:2,status:'Completed'},
    {channel:'Meesho',date:'2026-10-03',campaign:'Demo Clay Promotion',spend:25,sales:180,orders:1,status:'Completed'}
  ];
  data.marketplaceAds=[...(data.marketplaceAds||[]),...demoAds.filter(d=>!(data.marketplaceAds||[]).some(x=>x.channel===d.channel&&x.date===d.date&&x.campaign===d.campaign))];
  localStorage.setItem(key,'1'); save();
}

function seedReconBankDemo(){
 const key='gezenoReconBankDemoV1'; if(localStorage.getItem(key))return;
 const refs=new Set((data.bankTransactions||[]).map(x=>x.reference));
 const demo=[
  {date:'2026-10-03',description:'AMAZON SETTLEMENT AMZ-UTR-DEMO-01',reference:'AMZ-UTR-DEMO-01',credit:1768.13,debit:0,channel:'Amazon'},
  {date:'2026-10-04',description:'FLIPKART SETTLEMENT FK-UTR-DEMO-01',reference:'FK-UTR-DEMO-01',credit:994.25,debit:0,channel:'Flipkart'}
 ]; data.bankTransactions=[...(data.bankTransactions||[]),...demo.filter(x=>!refs.has(x.reference))]; localStorage.setItem(key,'1'); save();
}

function seedOriginalDummyFilesV29(){
  const seedKey='gezenoOriginalDummyFilesV29';
  if(localStorage.getItem(seedKey)) return;
  const sources=[{"marketplace":"Gezeno_Dummy_Marketplace_Files_2026_10","file":"Amazon_DUMMY_Payment-Settlement_2026-10.csv","type":"Payment / Settlement","content":"Settlement ID,From Date,To Date,Gross Sales,Sales GST,Marketplace Fees,Fee GST,TCS,TDS,Refunds,Shipping Charges,Other Deductions,Adjustments,Net Received,Received Date,Bank Ref,Status\r\nSET-AMZ-DUMMY-001,2026-10-01,2026-10-02,2778,424,341.76,61.52,27.78,13.89,0,130,20,0,2244.57,2026-10-04,AMZDUMMYUTR001,Reconciled\r\n"},{"marketplace":"Gezeno_Dummy_Marketplace_Files_2026_10","file":"Amazon_DUMMY_Bank-Statement_2026-10.csv","type":"Bank Statement","content":"Date,Description,Reference,Credit,Debit,Marketplace\r\n2026-10-04,Amazon Settlement Dummy,AMZDUMMYUTR001,2244.57,0,Amazon\r\n"},{"marketplace":"Gezeno_Dummy_Marketplace_Files_2026_10","file":"Amazon_DUMMY_Returns-RTO_2026-10.csv","type":"Returns / RTO","content":"Return ID,Order ID,Return Date,SKU,Qty,Reason,Refund Amount,Reverse Shipping,Status,Loss Amount\r\nRET-AMZ-DUMMY-001,AMZ-DUMMY-1002,2026-10-03,GZN-TOY-002,1,Customer return,799,40,Received,120\r\n"},{"marketplace":"Gezeno_Dummy_Marketplace_Files_2026_10","file":"Amazon_DUMMY_Orders_2026-10.csv","type":"Orders","content":"Order ID,Order Date,Customer,SKU,Product Name,Qty,Selling Price,Commission,Shipping Fee,Ads Cost,Return Cost,Courier,AWB,Status,Payment Status\r\nAMZ-DUMMY-1001,2026-10-01,Demo Amazon Buyer,GZN-SPK-001,Bluetooth Speaker,1,1180,150,50,20,0,Amazon Logistics,AMZDUMMY001,Delivered,Settled\r\nAMZ-DUMMY-1002,2026-10-02,Demo Amazon Buyer 2,GZN-TOY-002,Remote Car,2,1598,191.76,80,30,0,Delhivery,AMZDUMMY002,Shipped,Pending\r\n"},{"marketplace":"Gezeno_Dummy_Marketplace_Files_2026_10","file":"Amazon_DUMMY_GST-Tax_2026-10.csv","type":"GST / Tax","content":"Settlement ID,Order ID,Sales GST,Fee GST,TCS,TDS\r\nSET-AMZ-DUMMY-001,AMZ-DUMMY-1001,180,39.60,11.80,5.90\r\nSET-AMZ-DUMMY-001,AMZ-DUMMY-1002,244,21.92,15.98,7.99\r\n"},{"marketplace":"Gezeno_Dummy_Marketplace_Files_2026_10","file":"Amazon_DUMMY_Ads-Charges_2026-10.csv","type":"Ads / Charges","content":"Date,Campaign,Ad Spend,Attributed Sales,Attributed Orders,Status\r\n2026-10-01,Speaker Sponsored Demo,20,1180,1,Completed\r\n2026-10-02,Remote Car Demo,30,1598,2,Running\r\n"},{"marketplace":"Gezeno_Dummy_Marketplace_Files_2026_10","file":"Flipkart_DUMMY_Orders_2026-10.csv","type":"Orders","content":"Order ID,Order Date,Customer,SKU,Product Name,Qty,Selling Price,Commission,Shipping Fee,Ads Cost,Return Cost,Courier,AWB,Status,Payment Status\r\nFK-DUMMY-2001,2026-10-01,Demo Flipkart Buyer,GZN-PAD-003,Writing Pad,3,897,125.58,165,12,0,Ekart,FKDUMMY001,Delivered,Settled\r\nFK-DUMMY-2002,2026-10-03,Demo Flipkart Buyer 2,GZN-GAM-004,Board Game,1,999,139.86,70,18,0,Ekart,FKDUMMY002,Out for Delivery,Pending\r\n"},{"marketplace":"Gezeno_Dummy_Marketplace_Files_2026_10","file":"Flipkart_DUMMY_Bank-Statement_2026-10.csv","type":"Bank Statement","content":"Date,Description,Reference,Credit,Debit,Marketplace\r\n2026-10-05,Flipkart Settlement Dummy,FKDUMMYUTR001,1352.12,0,Flipkart\r\n"},{"marketplace":"Gezeno_Dummy_Marketplace_Files_2026_10","file":"Flipkart_DUMMY_Returns-RTO_2026-10.csv","type":"Returns / RTO","content":"Return ID,Order ID,Return Date,SKU,Qty,Reason,Refund Amount,Reverse Shipping,Status,Loss Amount\r\nRET-FK-DUMMY-001,FK-DUMMY-2001,2026-10-04,GZN-PAD-003,1,Damaged in transit,299,55,Refunded,85\r\n"},{"marketplace":"Gezeno_Dummy_Marketplace_Files_2026_10","file":"Flipkart_DUMMY_Payment-Settlement_2026-10.csv","type":"Payment / Settlement","content":"Settlement ID,From Date,To Date,Gross Sales,Sales GST,Marketplace Fees,Fee GST,TCS,TDS,Refunds,Shipping Charges,Other Deductions,Adjustments,Net Received,Received Date,Bank Ref,Status\r\nSET-FK-DUMMY-001,2026-10-01,2026-10-03,1896,289.22,265.44,47.78,18.96,9.48,0,235,15,0,1352.12,2026-10-05,FKDUMMYUTR001,Reconciled\r\n"},{"marketplace":"Gezeno_Dummy_Marketplace_Files_2026_10","file":"Flipkart_DUMMY_GST-Tax_2026-10.csv","type":"GST / Tax","content":"Settlement ID,Order ID,Sales GST,Fee GST,TCS,TDS\r\nSET-FK-DUMMY-001,FK-DUMMY-2001,136.83,30.83,8.97,4.49\r\nSET-FK-DUMMY-001,FK-DUMMY-2002,152.39,16.95,9.99,4.99\r\n"},{"marketplace":"Gezeno_Dummy_Marketplace_Files_2026_10","file":"Flipkart_DUMMY_Ads-Charges_2026-10.csv","type":"Ads / Charges","content":"Date,Campaign,Ad Spend,Attributed Sales,Attributed Orders,Status\r\n2026-10-01,Writing Pad Boost,12,897,3,Completed\r\n2026-10-03,Board Game Promotion,18,999,1,Running\r\n"},{"marketplace":"Gezeno_Dummy_Marketplace_Files_2026_10","file":"Meesho_DUMMY_Payment-Settlement_2026-10.csv","type":"Payment / Settlement","content":"Settlement ID,From Date,To Date,Gross Sales,Sales GST,Marketplace Fees,Fee GST,TCS,TDS,Refunds,Shipping Charges,Other Deductions,Adjustments,Net Received,Received Date,Bank Ref,Status\r\nSET-MS-DUMMY-001,2026-10-02,2026-10-04,1097,167.34,0,0,10.97,5.49,498,156,10,0,416.54,2026-10-06,MSDUMMYUTR001,Pending\r\n"},{"marketplace":"Gezeno_Dummy_Marketplace_Files_2026_10","file":"Meesho_DUMMY_Orders_2026-10.csv","type":"Orders","content":"Order ID,Order Date,Customer,SKU,Product Name,Qty,Selling Price,Commission,Shipping Fee,Ads Cost,Return Cost,Courier,AWB,Status,Payment Status\r\nMS-DUMMY-3001,2026-10-02,Demo Meesho Buyer,GZN-KIT-005,Clay Art Kit,2,498,0,96,8,96,Xpressbees,MSDUMMY001,Returned,Partial\r\nMS-DUMMY-3002,2026-10-04,Demo Meesho Buyer 2,GZN-ACC-006,Kids Accessories Set,1,599,0,60,10,0,Delhivery,MSDUMMY002,Shipped,Pending\r\n"},{"marketplace":"Gezeno_Dummy_Marketplace_Files_2026_10","file":"Meesho_DUMMY_GST-Tax_2026-10.csv","type":"GST / Tax","content":"Settlement ID,Order ID,Sales GST,Fee GST,TCS,TDS\r\nSET-MS-DUMMY-001,MS-DUMMY-3001,76,0,4.98,2.49\r\nSET-MS-DUMMY-001,MS-DUMMY-3002,91.34,0,5.99,3.00\r\n"},{"marketplace":"Gezeno_Dummy_Marketplace_Files_2026_10","file":"Meesho_DUMMY_Returns-RTO_2026-10.csv","type":"Returns / RTO","content":"Return ID,Order ID,Return Date,SKU,Qty,Reason,Refund Amount,Reverse Shipping,Status,Loss Amount\r\nRET-MS-DUMMY-001,MS-DUMMY-3001,2026-10-03,GZN-KIT-005,2,Customer return,498,96,Received,186\r\n"},{"marketplace":"Gezeno_Dummy_Marketplace_Files_2026_10","file":"Meesho_DUMMY_Bank-Statement_2026-10.csv","type":"Bank Statement","content":"Date,Description,Reference,Credit,Debit,Marketplace\r\n2026-10-06,Meesho Settlement Dummy,MSDUMMYUTR001,416.54,0,Meesho\r\n"},{"marketplace":"Gezeno_Dummy_Marketplace_Files_2026_10","file":"Meesho_DUMMY_Ads-Charges_2026-10.csv","type":"Ads / Charges","content":"Date,Campaign,Ad Spend,Attributed Sales,Attributed Orders,Status\r\n2026-10-02,Clay Kit Promotion,8,498,2,Completed\r\n2026-10-04,Accessories Boost,10,599,1,Running\r\n"}];
  sources.forEach(s=>{
    try{
      const rows=parseCSV(s.content);
      if(rows.length) storeRawImportRows(rows,s.marketplace,s.type,s.file,s.content);
    }catch(e){console.warn('Dummy source seed skipped',s.file,e)}
  });
  localStorage.setItem(seedKey,'1');
  save();
}

function repairOriginalSourceChannels(){
  data.reconSourceFiles=data.reconSourceFiles||[]; data.reconRawRows=data.reconRawRows||[];
  const channelFromFile=(file)=>{const s=String(file||'').toLowerCase();if(s.startsWith('amazon_'))return 'Amazon';if(s.startsWith('flipkart_'))return 'Flipkart';if(s.startsWith('meesho_'))return 'Meesho';return '';};
  data.reconSourceFiles.forEach(x=>{const ch=channelFromFile(x.file);if(ch)x.channel=ch;});
  data.reconRawRows.forEach(x=>{const ch=channelFromFile(x.file);if(ch)x.channel=ch;});
  const seen=new Set(); data.reconSourceFiles=data.reconSourceFiles.filter(x=>{x.key=`${x.channel||'All'}|${x.type||''}|${x.file||''}`;if(seen.has(x.key))return false;seen.add(x.key);return true;});
  save();
}
function removeSettlementDerivedOrders(){
  data.marketplaceOrders=data.marketplaceOrders||[];
  // Payment/Settlement files must never create standalone Order Center rows.
  // Keep payment data in marketplaceSettlements/reconRawRows; only enrich an
  // already-existing order imported from an actual Orders file.
  data.marketplaceOrders=data.marketplaceOrders.filter(o=>{
    const sk=String(o?.sourceKind||'').toLowerCase();
    const sf=String(o?.sourceFile||'').toLowerCase();
    const settlementOnly=sk.includes('settlement') || sf.includes('settlement');
    if(settlementOnly && !o?.orderImportSource && !o?.orderFileSource && !o?.isOrderRecord) return false;
    return true;
  });
}
function compactReconStorageForQuota(){
  // CSV/XLSX imports used to store the complete row object twice: once in the
  // original source file and again inside every reconRawRows item. On Android
  // WebView this can cross the ~5 MB localStorage quota very quickly.
  // Keep the exact original file content in reconSourceFiles and keep row
  // metadata/order links, but remove the duplicated per-row raw object.
  data.reconRawRows=(data.reconRawRows||[]).map(x=>{
    if(!x || typeof x!=='object') return x;
    const y={...x};
    delete y.raw;
    return y;
  });
  return data;
}
function save(){
  // Business/reconciliation data goes to IndexedDB on the device. This avoids the
  // small localStorage quota that caused imports such as Mar Order.xlsx to fail.
  if(deviceStorageReady && deviceDB){
    idbPut(deviceDB,'gezenoData',data).catch(e=>{
      console.error('Gezeno IndexedDB save failed',e);
      alert('Device storage me data save nahi ho pa raha. Device storage space check karke dobara try karein.\n\nTechnical: '+String(e?.message||e));
    });
  }else{
    deviceSavePending=true;
    // Temporary fallback only until IndexedDB initialization completes.
    try{localStorage.setItem('gezenoData',JSON.stringify(data));}
    catch(e){
      console.warn('Temporary localStorage fallback unavailable; IndexedDB initialization pending.',e);
      compactReconStorageForQuota();
    }
  }
  try{localStorage.setItem('gezenoConfig',JSON.stringify(cfg));}catch(e){console.error('Config save failed',e)}
  return true;
}
function applyBrand(){document.title=cfg.brand;document.getElementById('loginBrand').textContent=cfg.brand;document.getElementById('sideBrand').textContent=cfg.brand;document.getElementById('subtitle').textContent='';document.getElementById('subtitle').style.display='none';document.getElementById('userLabel').textContent='User: '+cfg.username}
function login(){const u=String(document.getElementById('loginUser').value||'').trim();const p=String(document.getElementById('loginPass').value||'');const configuredUser=String(cfg.username||DEFAULTS.username).trim();const configuredPass=String(cfg.password||DEFAULTS.password);const configuredOk=(u===configuredUser&&p===configuredPass);const defaultOk=(u===DEFAULTS.username&&p===DEFAULTS.password);if(configuredOk||defaultOk){if(defaultOk&&!configuredOk){cfg.username=DEFAULTS.username;cfg.password=DEFAULTS.password;cfg.authVersion=2;localStorage.setItem('gezenoConfig',JSON.stringify(cfg));}sessionStorage.setItem('gezenoLogged','1');document.getElementById('loginErr').textContent='';document.getElementById('login').style.display='none';document.getElementById('app').style.display='block';applyBrand();show('dashboard')}else document.getElementById('loginErr').textContent='Invalid username or password.'}
let authMode='create';
function openAuthModal(mode){authMode=mode;document.getElementById('authModal').classList.add('show');document.getElementById('authErr').textContent='';document.getElementById('authTitle').textContent=mode==='create'?'Create Password':'Forgot Password';document.getElementById('authHint').textContent=mode==='create'?'Set your login username and password.':'Verify your registered mobile number and GSTIN, then set a new password.';document.getElementById('createFields').style.display=mode==='create'?'block':'none';document.getElementById('forgotFields').style.display=mode==='forgot'?'block':'none';if(mode==='create'){document.getElementById('newUsername').value=cfg.username||'gezeno';document.getElementById('newPassword').value='';document.getElementById('confirmPassword').value='';}else{document.getElementById('recoveryPhone').value=cfg.phone||'';document.getElementById('recoveryGSTIN').value=cfg.businessGSTIN||cfg.gstin||'';document.getElementById('resetPassword').value='';document.getElementById('resetConfirmPassword').value='';}}
function openCreatePassword(){openAuthModal('create')}
function openForgotPassword(){openAuthModal('forgot')}
function closeAuthModal(){document.getElementById('authModal').classList.remove('show')}
function submitAuth(){const err=document.getElementById('authErr');if(authMode==='create'){const u=String(document.getElementById('newUsername').value||'').trim();const p=String(document.getElementById('newPassword').value||'');const c=String(document.getElementById('confirmPassword').value||'');if(!u||p.length<4){err.textContent='Username and a password of at least 4 characters are required.';return}if(p!==c){err.textContent='Passwords do not match.';return}cfg={...cfg,username:u,password:p,authVersion:2};localStorage.setItem('gezenoConfig',JSON.stringify(cfg));applyBrand();document.getElementById('loginUser').value=u;document.getElementById('loginPass').value='';document.getElementById('loginErr').textContent='Password created successfully. Please sign in.';closeAuthModal();}else{const phone=String(document.getElementById('recoveryPhone').value||'').replace(/\D/g,'');const gst=String(document.getElementById('recoveryGSTIN').value||'').trim().toUpperCase();const savedPhone=String(cfg.phone||'').replace(/\D/g,'');const savedGST=String(cfg.businessGSTIN||cfg.gstin||'').trim().toUpperCase();const p=String(document.getElementById('resetPassword').value||'');const c=String(document.getElementById('resetConfirmPassword').value||'');if(!savedPhone||!savedGST){err.textContent='Recovery details are not configured. Set Mobile Number and GSTIN in Settings first.';return}if(phone!==savedPhone||gst!==savedGST){err.textContent='Mobile number or GSTIN does not match.';return}if(p.length<4){err.textContent='Password must be at least 4 characters.';return}if(p!==c){err.textContent='Passwords do not match.';return}cfg={...cfg,password:p,authVersion:2};localStorage.setItem('gezenoConfig',JSON.stringify(cfg));document.getElementById('loginPass').value='';document.getElementById('loginErr').textContent='Password reset successfully. Please sign in.';closeAuthModal();}}
function logout(){sessionStorage.removeItem('gezenoLogged');if(typeof toggleMobileDrawer==='function')toggleMobileDrawer(false);document.getElementById('app').style.display='none';document.getElementById('login').style.display='flex';document.getElementById('loginPass').value=''}
function runGlobalOrderSearch(){const el=document.getElementById('globalOrderSearch');const q=String(el?.value||'').trim();if(!q){alert('Please enter an Order ID.');el?.focus();return}ensureMarketplaceV6();const needle=q.toLowerCase();const matches=(data.marketplaceOrders||[]).map((o,i)=>({o,i})).filter(x=>String(x.o.orderId||'').toLowerCase().includes(needle));if(!matches.length){alert('Order ID not found: '+q);return}const active=matches.find(x=>!x.o.dumpArchived);if(active){window.marketplaceGlobalSearch=q;window.marketplaceOrderSelected=active.i;window.marketplaceOrderTab=active.o.channel||'All';show('marketplaceControl');return}const archived=matches[0].o;window.marketplaceGlobalSearch='';window.dumpOrderQuery=q;window.dumpChannel=archived.channel||'All';window.dumpPeriod='All Data';window.dumpFrom='';window.dumpTo='';window.dumpDataActive=true;show('dataDump')}

function show(key){autoMoveOldOrdersToDump();if(key==='dataDump' && current!=='dataDump')window.dumpDataActive=false;current=key;document.querySelectorAll('.nav button').forEach(b=>b.classList.toggle('active',b.dataset.key===key));document.getElementById('title').textContent=key==='dashboard'?'Reconciliation Dashboard':key==='marketplace'?'Marketplace Hub':key==='marketplaceControl'?'Order Control Center':key==='csvCenter'?'File Upload':key==='reconciliation'?'Payment Reconciliation':key==='dataDump'?'Data Dump':key==='reports'?'Reports':key==='settings'?'Settings':key==='marketplaceProfit'?'Marketplace Profit':key==='pnlDashboard'?'Profit & Loss':key==='returnsDashboard'?'Returns & Refunds':key==='gstr1'?'GSTR-1 & GST Reports':sections[key]?.label||key;const globalSearch=document.querySelector('.global-order-search');if(globalSearch)globalSearch.style.display=(key==='marketplaceControl'||key==='settings')?'none':'';document.getElementById('content').innerHTML=key==='dashboard'?dashboard():key==='marketplace'?marketplaceDashboard():key==='marketplaceControl'?marketplaceControl():key==='csvCenter'?csvCenter():key==='reconciliation'?reconciliation():key==='dataDump'?dataDump():key==='reports'?reports():key==='settings'?settings():key==='calculator'?calculator():key==='marketplaceProfit'?marketplaceProfit():key==='pnlDashboard'?pnlDashboard():key==='returnsDashboard'?returnsDashboard():key==='gstr1'?gstr1Dashboard():table(key);if(sections[key])renderRows(key);if(key==='catalog')setTimeout(previewCatalog,0);if(key==='reconciliation')setTimeout(applyReconDetailVisibility,0);if(key==='calculator')setTimeout(()=>{ensurePricingSlabs();renderWeightSlabRows();renderMarketplaceChargeSummary();runMarketplaceCalc()},0)}
function marketplaceDashboard(){const channels=['Amazon','Flipkart','Meesho'];const rows=channels.map(ch=>{const os=data.marketplaceOrders.filter(o=>o.channel===ch),sales=os.reduce((a,o)=>a+Number(o.sellingPrice||0),0),fees=os.reduce((a,o)=>a+Number(o.commission||0)+Number(o.shippingFee||0)+Number(o.adsCost||0)+Number(o.returnCost||0),0),profit=os.reduce((a,o)=>{const p=data.products.find(x=>x.sku===o.sku);return a+Number(o.sellingPrice||0)-Number(p?.purchase||0)*Number(o.qty||0)-Number(o.commission||0)-Number(o.shippingFee||0)-Number(o.adsCost||0)-Number(o.returnCost||0)},0);return {ch,sales,fees,profit,count:os.length}});const totalSales=rows.reduce((a,r)=>a+r.sales,0),totalProfit=rows.reduce((a,r)=>a+r.profit,0),returns=data.marketplaceReturns.length,settled=data.marketplaceSettlements.reduce((a,x)=>a+Number(x.netReceived||0),0);return `<div class="reporthero"><h2>🛍 Gezeno Marketplace Hub</h2><div style="opacity:.9">Amazon • Flipkart • Meesho — unified seller management</div></div><div class="cards"><div class="card">Marketplace Sales<div class="num">₹${totalSales.toLocaleString('en-IN')}</div></div><div class="card">Estimated Profit<div class="num">₹${totalProfit.toLocaleString('en-IN')}</div></div><div class="card" role="button" tabindex="0" title="Open Order Control Center" onclick="show('marketplaceControl')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();show('marketplaceControl')}">Orders<div class="num">${data.marketplaceOrders.length}</div><div class="hint">Open Order Control Center →</div></div><div class="card">Settlements Received<div class="num">₹${settled.toLocaleString('en-IN')}</div></div></div><div class="panel"><h2>Marketplace Performance</h2><div style="overflow:auto"><table class="table"><thead><tr><th>Marketplace</th><th>Orders</th><th>Sales</th><th>Fees</th><th>Estimated Profit</th></tr></thead><tbody>${rows.map(r=>`<tr><td><b>${r.ch}</b></td><td>${r.count}</td><td>₹${r.sales.toLocaleString('en-IN')}</td><td>₹${r.fees.toLocaleString('en-IN')}</td><td><b>₹${r.profit.toLocaleString('en-IN')}</b></td></tr>`).join('')}</tbody></table></div></div><div class="cards" style="margin-top:16px"><div class="card">Active Listings<div class="num">${data.marketplaceListings.filter(x=>x.status==='Active').length}</div></div><div class="card">Returns<div class="num">${returns}</div></div><div class="card">Pending Settlements<div class="num">${data.marketplaceSettlements.filter(x=>x.status==='Pending').length}</div></div><div class="card">Ad Spend<div class="num">₹${data.marketplaceAds.reduce((a,x)=>a+Number(x.spend||0),0).toLocaleString('en-IN')}</div></div></div><div class="panel"><h2>How this works</h2><p class="hint">First maintain Products and Marketplace Listings. Then record/import marketplace orders, returns, ads and settlements. The Hub calculates channel-wise sales, fees and estimated profit. Live API sync can be connected later using marketplace seller API credentials.</p></div>`}
function dashboard(){
 const channels=['All','Amazon','Flipkart','Meesho'];
 const active=window.mainDashChannel||'All';
 const from=window.mainDashFrom||'';
 const to=window.mainDashTo||'';
 const inDate=(v)=>{const d=String(v||'').slice(0,10);return (!from||d>=from)&&(!to||d<=to)};
 const orders=(data.marketplaceOrders||[]).filter(o=>(active==='All'||o.channel===active)&&inDate(o.date));
 const activeVisible=(data.marketplaceOrders||[]).filter(o=>(active==='All'||o.channel===active)&&inDate(o.date)&&!o.dumpArchived&&normalizeDumpDate(o.date)>=financialYearStartISO(todayISO()));
 const archivedVisible=(data.marketplaceOrders||[]).filter(o=>(active==='All'||o.channel===active)&&inDate(o.date)&&(o.dumpArchived||normalizeDumpDate(o.date)<financialYearStartISO(todayISO())));
 const settlements=(data.marketplaceSettlements||[]).filter(x=>(active==='All'||x.channel===active)&&inDate(x.receivedDate||x.toDate||x.fromDate));
 const returns=(data.marketplaceReturns||[]).filter(x=>(active==='All'||x.channel===active)&&inDate(x.date));
 const ads=(data.marketplaceAds||[]).filter(x=>(active==='All'||x.channel===active)&&inDate(x.date));
 const bank=(data.bankTransactions||[]).filter(x=>(active==='All'||x.channel===active)&&inDate(x.date));
 const n=v=>Number(v||0);
 const gross=settlements.reduce((a,x)=>a+n(x.gross),0)||orders.reduce((a,x)=>a+n(x.sellingPrice)*Math.max(1,n(x.qty)||1),0);
 const salesGst=settlements.reduce((a,x)=>a+n(x.salesGst),0)||orders.reduce((a,x)=>a+n(x.gstAmount),0);
 const fees=settlements.reduce((a,x)=>a+n(x.fees),0)||orders.reduce((a,x)=>a+n(x.commission),0);
 const feeGst=settlements.reduce((a,x)=>a+n(x.feeGst),0)||orders.reduce((a,x)=>a+n(x.feeGst),0);
 const tcs=settlements.reduce((a,x)=>a+n(x.tcs),0),tds=settlements.reduce((a,x)=>a+n(x.tds),0),refunds=settlements.reduce((a,x)=>a+n(x.refunds),0),shipping=settlements.reduce((a,x)=>a+n(x.shipping),0)||orders.reduce((a,x)=>a+n(x.shippingFee),0);
 const other=settlements.reduce((a,x)=>a+n(x.otherDeductions)+n(x.adjustments),0);
 const adSpend=ads.reduce((a,x)=>a+n(x.spend),0)||orders.reduce((a,x)=>a+n(x.adsCost),0);
 const expected=settlements.reduce((a,x)=>a+n(x.gross)-n(x.fees)-n(x.tcs)-n(x.tds)-n(x.refunds)-n(x.shipping)-n(x.otherDeductions)+n(x.adjustments),0);
 const actual=settlements.reduce((a,x)=>a+n(x.netReceived),0);
 const bankCredit=bank.reduce((a,x)=>a+n(x.credit),0);
 const settlementDiff=settlements.reduce((a,x)=>a+(n(x.netReceived)-(n(x.gross)-n(x.fees)-n(x.tcs)-n(x.tds)-n(x.refunds)-n(x.shipping)-n(x.otherDeductions)+n(x.adjustments))),0);
 const bankMatched=bank.filter(x=>String(x.status||'').toLowerCase()==='matched').length;
 const mismatch=settlements.filter(x=>{const e=n(x.gross)-n(x.fees)-n(x.tcs)-n(x.tds)-n(x.refunds)-n(x.shipping)-n(x.otherDeductions)+n(x.adjustments);return Math.abs(n(x.netReceived)-e)>0.01}).length;
 const taxable=Math.max(0,gross-salesGst),netGst=salesGst-feeGst;
 const cogs=orders.reduce((a,o)=>{const p=data.products.find(x=>x.sku===o.sku);return a+n(p?.purchase)*Math.max(1,n(o.qty)||1)},0);
 const profit=taxable-cogs-Math.max(0,fees-feeGst)-Math.max(0,shipping)+0-adSpend-refunds-other;
 const fmt=v=>`₹${n(v).toLocaleString('en-IN',{minimumFractionDigits:0,maximumFractionDigits:2})}`;
 const card=(label,value,sub,cls='',targetOverride='')=>{return `<div class="finance-kpi ${cls}"><div class="label">${label}</div><div class="value">${value}</div><div class="hint">${sub}</div></div>`};
 const channelRows=['Amazon','Flipkart','Meesho'].map(ch=>{const os=(data.marketplaceOrders||[]).filter(o=>o.channel===ch&&inDate(o.date));const ss=(data.marketplaceSettlements||[]).filter(x=>x.channel===ch&&inDate(x.receivedDate||x.toDate||x.fromDate));const g=ss.reduce((a,x)=>a+n(x.gross),0)||os.reduce((a,x)=>a+n(x.sellingPrice)*Math.max(1,n(x.qty)||1),0);const r=ss.reduce((a,x)=>a+n(x.netReceived),0);const d=ss.reduce((a,x)=>a+(n(x.netReceived)-(n(x.gross)-n(x.fees)-n(x.tcs)-n(x.tds)-n(x.refunds)-n(x.shipping)-n(x.otherDeductions)+n(x.adjustments))),0);return `<tr><td><b>${ch}</b></td><td>${os.length}</td><td>${fmt(g)}</td><td>${fmt(ss.reduce((a,x)=>a+n(x.fees),0))}</td><td>${fmt(r)}</td><td>${fmt(d)}</td><td><span class="badge ${Math.abs(d)<0.01?'green':'red'}">${Math.abs(d)<0.01?'Matched':'Mismatch'}</span></td></tr>`}).join('');
 const recent=(data.reconUploads||[]).slice(-6).reverse().map(u=>`<div class="alertrow"><div><b>${esc(u.channel||'All')} • ${esc(u.type||'File')}</b><div class="hint">${esc(u.file||'')} • ${u.rows||0} rows</div></div><span class="badge green">Imported</span></div>`).join('');
 return `<div class="reporthero"><div style="display:flex;justify-content:space-between;gap:18px;align-items:center;flex-wrap:wrap"><div><h2>📊 Main Reconciliation Dashboard</h2><div style="opacity:.9">Complete marketplace money trail — Order → Settlement → Bank → GST → Profit</div></div><div class="quick"><button class="btn" onclick="show('reconciliation')">💳 Open Reconciliation</button><button class="btn" onclick="show('dataDump')">🗂 Open Data Dump</button><button class="btn secondary" onclick="show('csvCenter')">📥 Upload Files</button></div></div></div>
 <div class="panel"><div class="finance-filters"><label class="field"><span>Marketplace</span><select id="mainDashChannel">${channels.map(x=>`<option value="${x}" ${active===x?'selected':''}>${x==='All'?'All Marketplaces':x}</option>`).join('')}</select></label><label class="field"><span>From Date</span><input id="mainDashFrom" type="date" value="${esc(from)}"></label><label class="field"><span>To Date</span><input id="mainDashTo" type="date" value="${esc(to)}"></label><button class="btn" onclick="applyMainDashboardFilters()">Apply Filter</button><button class="btn secondary" onclick="window.mainDashChannel='All';window.mainDashFrom='';window.mainDashTo='';show('dashboard')">Reset</button></div></div>
 <div class="panel" style="margin-top:16px"><div class="finance-kpis dashboard-static-cards">${card('Active Orders',activeVisible.length,'Current FY • current dashboard filter','','marketplaceControl')}${card('Auto-Archived to Data Dump',archivedVisible.length,'Previous FY • current dashboard filter','good','dataDump')}${card('Order Center Window','Current Financial Year','Previous FY auto-archive rule','','marketplaceControl')}${card('Dump Records',archivedVisible.length,'Archived orders • current dashboard filter','','dataDump')}</div></div><div class="panel" style="margin-top:16px"><div class="pricing-section-title"><div><h3>⚡ Executive Profit Control</h3><span class="hint">One-screen control for sales, settlement, charges and profit health.</span></div><div class="quick"><button class="btn" onclick="show('calculator')">🧮 Price Calculator</button><button class="btn secondary" onclick="show('pnlDashboard')">📈 Open P&amp;L</button><button class="btn secondary" onclick="show('marketplaceSettlements')">💵 Settlements</button></div></div><div class="finance-kpis dashboard-static-cards">${card('Net Profit / Loss',fmt(profit),'After COGS, fees, shipping, ads & returns',profit>=0?'good':'bad')}${card('Profit Margin',gross?((profit/Math.max(1,taxable))*100).toFixed(1)+'%':'0.0%','Operating profit ÷ taxable sales',profit>=0?'good':'bad')}${card('Total Deductions',fmt(Math.max(0,gross-actual)),'Gross sales less actual received','warn')}${card('Reconciliation Health',mismatch?mismatch+' mismatch':'All matched','Settlement control',mismatch?'bad':'good')}</div></div><div class="finance-kpis dashboard-static-cards" style="margin-top:16px">${card('Gross Sales',fmt(gross),'GST inclusive')}${card('Sales GST',fmt(salesGst),'Output GST')}${card('Marketplace Fees',fmt(fees),'Fee GST '+fmt(feeGst))}${card('Expected Settlement',fmt(expected),'After deductions')}${card('Actual Received',fmt(actual),'Marketplace settlement','good')}${card('Bank Credits',fmt(bankCredit),'Uploaded bank statement')}${card('Settlement Difference',fmt(settlementDiff),mismatch+' mismatch settlements',Math.abs(settlementDiff)<0.01?'good':'bad')}${card('Actual Operating Profit',fmt(profit),'After COGS, fees, shipping, ads & returns',profit>=0?'good':'bad')}</div>
 <div class="cards dashboard-static-cards" style="margin-top:16px">${card('Taxable Sales',fmt(taxable),'Gross − Sales GST')}${card('Fee GST / ITC',fmt(feeGst),'Marketplace fee GST')}${card('TCS',fmt(tcs),'Track separately')}${card('TDS',fmt(tds),'Track separately')}${card('Refunds',fmt(refunds),'Settlement deductions')}${card('Shipping',fmt(shipping),'Marketplace shipping')}${card('Ads',fmt(adSpend),'Marketplace advertising')}${card('Other / Adjustments',fmt(other),'Other deductions + credits')}</div>
 <div class="dashgrid"><div class="panel" style="margin-top:0"><h2>Marketplace Comparison</h2><div style="overflow:auto"><table class="table"><thead><tr><th>Marketplace</th><th>Orders</th><th>Gross Sales</th><th>Fees</th><th>Received</th><th>Difference</th><th>Status</th></tr></thead><tbody>${channelRows}</tbody></table></div></div><div class="panel" style="margin-top:0"><h2>Reconciliation Health</h2><div class="alertbox ${mismatch?'danger':'ok'}"><b>${mismatch?mismatch+' settlement mismatch(es)':'All settlement amounts matched'}</b><div class="hint">Expected vs actual marketplace receipt</div></div><div class="alertbox ${Math.abs(settlementDiff)>0.01?'warn':'ok'}"><b>${fmt(settlementDiff)} net difference</b><div class="hint">Settlement reconciliation difference</div></div><div class="alertbox ${bankMatched?'ok':'warn'}"><b>${bankMatched} bank transaction(s) matched</b><div class="hint">Bank statement matching status</div></div><button class="btn secondary" onclick="show('reconciliation')">View full reconciliation →</button></div></div>
 <div class="dashgrid"><div class="panel" style="margin-top:0"><h2>₹-Level Accounting Summary</h2><table class="smalltable"><tbody><tr><td>Gross Sales</td><td style="text-align:right"><b>${fmt(gross)}</b></td></tr><tr><td>Less: Sales GST (informational component)</td><td style="text-align:right">${fmt(salesGst)}</td></tr><tr><td>Taxable Sales</td><td style="text-align:right"><b>${fmt(taxable)}</b></td></tr><tr><td>Less: Marketplace Fee (excluding Fee GST)</td><td style="text-align:right">${fmt(Math.max(0,fees-feeGst))}</td></tr><tr><td>Less: COGS</td><td style="text-align:right">${fmt(cogs)}</td></tr><tr><td>Less: Shipping + Ads + Returns + Other</td><td style="text-align:right">${fmt(shipping+adSpend+refunds+other)}</td></tr><tr><td><b>Operating Profit</b></td><td style="text-align:right"><b>${fmt(profit)}</b></td></tr></tbody></table></div><div class="panel" style="margin-top:0"><h2>Recent File Activity</h2>${recent||'<div class="hint">No reconciliation files uploaded yet.</div>'}<button class="btn" style="margin-top:10px" onclick="show('csvCenter')">Open File Center</button></div></div>`;
}
function applyMainDashboardFilters(){const ch=document.getElementById('mainDashChannel')?.value||'All';const m=document.getElementById('mainDashMonth')?.value||'';let f=document.getElementById('mainDashFrom')?.value||'',t=document.getElementById('mainDashTo')?.value||'';if(m){const [y,mo]=m.split('-').map(Number),last=new Date(y,mo,0).getDate();f=`${y}-${String(mo).padStart(2,'0')}-01`;t=`${y}-${String(mo).padStart(2,'0')}-${String(last).padStart(2,'0')}`;}if(!m&&!f&&!t){toast('Please select Month-wise or From + To Date first');return}if(!m&&((f&&!t)||(!f&&t))){toast('Please select both From and To Date');return}if(f&&t&&f>t){alert('From Date cannot be later than To Date.');return;}window.mainDashChannel=ch;window.mainDashMonth=m;window.mainDashFrom=f;window.mainDashTo=t;window.mainDashApplied=true;show('dashboard')}
function table(key){
 let s=sections[key];
 if(key==='marketplaceSettlements') return settlementsDashboard();
 return `<div class="panel"><div class="toolbar"><input class="search" id="search" placeholder="Search ${s.label}..." oninput="renderRows('${key}')"><button class="btn" onclick="openModal('${key}')">+ Add ${s.label.slice(0,-1)||s.label}</button></div><div style="overflow:auto"><table class="table"><thead><tr>${s.fields.map(f=>`<th>${f[1]}</th>`).join('')}${key==='orders'?'<th>Items / Charges</th>':''}${key==='purchases'?'<th>Products / Costs</th>':''}<th>Actions</th></tr></thead><tbody id="rows"></tbody></table></div></div>`}
function settlementMoney(v){return '₹'+num(v||0).toLocaleString('en-IN',{minimumFractionDigits:0,maximumFractionDigits:2});}
function settlementSelectionUpdate(){
 const n=window.settlementSelected?.size||0;
 document.querySelectorAll('[data-settlement-selection-count]').forEach(el=>el.textContent=n+' selected');
 const boxes=[...document.querySelectorAll('.settlement-select')];
 const all=boxes.length>0 && boxes.every(x=>x.checked);
 const head=document.getElementById('settlementSelectAll')||document.getElementById('settlementSelectAllTop'); if(head) head.checked=all;
}
function toggleSettlementSelection(i,checked){window.settlementSelected=window.settlementSelected||new Set();checked?window.settlementSelected.add(Number(i)):window.settlementSelected.delete(Number(i));settlementSelectionUpdate();}
function toggleAllSettlements(checked){window.settlementSelected=new Set();if(checked){document.querySelectorAll('.settlement-select').forEach(x=>window.settlementSelected.add(Number(x.dataset.index)));}document.querySelectorAll('.settlement-select').forEach(x=>x.checked=checked);settlementSelectionUpdate();}
function settlementRawMeta(s){
  const sid=String(s?.settlementId||'').trim();
  const sourceFile=String(s?.sourceFile||'').trim();
  const channel=String(s?.channel||'').trim();
  const raw=(data.reconRawRows||[]);
  const files=new Set();
  raw.forEach(r=>{
    const rr=r?.raw||r||{};
    const rid=String(r.settlementId||rr.settlementId||rr['Settlement ID']||rr['SettlementId']||rr['NEFT ID']||rr['NEFTID']||'').trim();
    const rf=String(r.file||r.sourceFile||rr.sourceFile||'').trim();
    const rc=String(r.channel||rr.channel||'').trim();
    if(rf && ((sid && rid===sid) || (sourceFile && rf===sourceFile) || (channel && rc===channel && sourceFile && rf===sourceFile))) files.add(rf);
  });
  if(sourceFile) files.add(sourceFile);
  return {sid,sourceFile,files,channel};
}
function permanentlyDeleteSettlementData(s){
  const meta=settlementRawMeta(s);
  const sid=meta.sid, channel=meta.channel;
  // IMPORTANT: deleting one settlement must never delete every settlement from the same source file.
  // Source-file history is kept; only the selected settlement's records are removed.
  data.reconDeletedSettlementIds=data.reconDeletedSettlementIds||{};
  if(sid) data.reconDeletedSettlementIds[`${channel}|${sid}`]=true;
  data.marketplaceSettlements=(data.marketplaceSettlements||[]).filter(x=>{
    if(x===s) return false;
    const xid=String(x.settlementId||'').trim();
    return !(sid && xid===sid && String(x.channel||'')===channel);
  });
  data.reconRawRows=(data.reconRawRows||[]).filter(r=>{
    const rr=r?.raw||r||{};
    const rid=String(r.settlementId||rr.settlementId||rr['Settlement ID']||rr['SettlementId']||rr['NEFT ID']||rr['NEFTID']||'').trim();
    const rc=String(r.channel||rr.channel||'').trim();
    return !(sid && rid===sid && (!channel || !rc || rc===channel));
  });
  // Do NOT remove reconSourceFiles/reconUploads here. They represent the original uploaded file,
  // not an individual settlement record. This prevents one settlement delete from deleting the whole file.
  return meta;
}
function deleteSelectedSettlements(){
  const ids=[...(window.settlementSelected||new Set())].map(Number).filter(i=>Number.isInteger(i)&&data.marketplaceSettlements?.[i]);
  if(!ids.length){alert('Please select at least one settlement to delete.');return;}
  const selected=ids.map(i=>data.marketplaceSettlements[i]);
  const labels=selected.map(s=>String(s.settlementId||'record')).join(', ');
  if(!confirm(`Delete ${selected.length} selected settlement file/record(s)?\n\n${labels}\n\nThe settlement records, linked imported rows and source-file entry will be removed. This cannot be undone.`))return;
  selected.forEach(permanentlyDeleteSettlementData);
  window.settlementSelected=new Set();
  save(); show('marketplaceSettlements'); toast(`${selected.length} settlement file/record(s) deleted successfully`);
}

function settlementsDashboard(){
 const all=data.marketplaceSettlements||[];
 const q=String(document.getElementById('settlementSearch')?.value||window.settlementSearch||'').trim().toLowerCase();
 const ch=document.getElementById('settlementChannel')?.value||window.settlementChannel||'All';
 const status=document.getElementById('settlementStatus')?.value||window.settlementStatus||'All';
 const filtered=all.map((s,i)=>({s,i})).filter(x=>{
  const s=x.s;
  if(ch!=='All'&&String(s.channel)!==ch)return false;
  if(status!=='All'&&String(s.status||'Pending')!==status)return false;
  if(q&&!JSON.stringify(s).toLowerCase().includes(q))return false;
  return true;
 });
 const gross=filtered.reduce((a,x)=>a+num(x.s.gross),0), fees=filtered.reduce((a,x)=>a+num(x.s.fees),0), received=filtered.reduce((a,x)=>a+num(x.s.netReceived),0), pending=filtered.filter(x=>String(x.s.status||'Pending')==='Pending').length;
 const reconciled=filtered.filter(x=>String(x.s.status||'')==='Reconciled').length, mismatch=filtered.filter(x=>String(x.s.status||'')==='Mismatch').length;
 window.settlementSelected=window.settlementSelected||new Set();
 return `<div class="reporthero"><h2>💵 Settlements Control Center</h2><div style="opacity:.9">Amazon • Flipkart • Meesho — settlement, payout and bank control dashboard</div></div>
 <div class="finance-kpis">
  <div class="finance-kpi"><div class="label">Total Settlements</div><div class="value">${filtered.length}</div><div class="hint">Current filtered view</div></div>
  <div class="finance-kpi"><div class="label">Gross Sales</div><div class="value">${settlementMoney(gross)}</div></div>
  <div class="finance-kpi"><div class="label">Marketplace Fees</div><div class="value">${settlementMoney(fees)}</div></div>
  <div class="finance-kpi good"><div class="label">Actual Received</div><div class="value">${settlementMoney(received)}</div></div>
  <div class="finance-kpi"><div class="label">Reconciled</div><div class="value">${reconciled}</div></div>
  <div class="finance-kpi ${mismatch?'bad':''}"><div class="label">Mismatch</div><div class="value">${mismatch}</div></div>
  <div class="finance-kpi ${pending?'orange':''}"><div class="label">Pending</div><div class="value">${pending}</div></div>
 </div>
 <div class="panel"><div class="toolbar" style="flex-wrap:wrap">
  <input class="search" id="settlementSearch" placeholder="Search Settlement ID / UTR / Marketplace" value="${esc(q)}" onkeydown="if(event.key==='Enter')applySettlementFilters()">
  <select id="settlementChannel"><option value="All" ${ch==='All'?'selected':''}>All Marketplaces</option><option value="Amazon" ${ch==='Amazon'?'selected':''}>Amazon</option><option value="Flipkart" ${ch==='Flipkart'?'selected':''}>Flipkart</option><option value="Meesho" ${ch==='Meesho'?'selected':''}>Meesho</option></select>
  <select id="settlementStatus"><option value="All" ${status==='All'?'selected':''}>All Status</option><option value="Reconciled" ${status==='Reconciled'?'selected':''}>Reconciled</option><option value="Mismatch" ${status==='Mismatch'?'selected':''}>Mismatch</option><option value="Pending" ${status==='Pending'?'selected':''}>Pending</option></select>
  <button class="btn" onclick="applySettlementFilters()">🔎 Apply</button><button class="btn secondary" onclick="window.settlementSearch='';window.settlementChannel='All';window.settlementStatus='All';window.settlementFiltersApplied=false;show('marketplaceSettlements')">Reset</button>
 </div></div>
 <div class="panel"><div class="toolbar" style="margin-bottom:10px;flex-wrap:wrap"><label style="display:flex;align-items:center;gap:7px;font-weight:700"><input id="settlementSelectAllTop" type="checkbox" onchange="toggleAllSettlements(this.checked)"> Select All</label><button class="btn secondary" onclick="toggleAllSettlements(false)">☐ Clear Selection</button><span data-settlement-selection-count class="hint">${window.settlementSelected.size} selected</span><button class="del" onclick="deleteSelectedSettlements()">🗑 Delete Selected</button><button class="btn secondary" onclick="openModal('marketplaceSettlements')">＋ Add Settlement</button></div>
 <div style="overflow:auto"><table class="table"><thead><tr><th><input id="settlementSelectAll" type="checkbox" onchange="toggleAllSettlements(this.checked)"></th><th>Settlement ID</th><th>Marketplace</th><th>Settlement Period</th><th>Gross Sales</th><th>Fees</th><th>TCS</th><th>TDS</th><th>Refunds</th><th>Actual Received</th><th>Received Date</th><th>Order ID</th><th>Status</th><th>Actions</th></tr></thead><tbody>${filtered.map(({s,i})=>`<tr><td><input class="settlement-select" data-index="${i}" type="checkbox" ${window.settlementSelected.has(i)?'checked':''} onchange="toggleSettlementSelection(this.dataset.index,this.checked)"></td><td><b>${esc(s.settlementId||'—')}</b></td><td>${esc(s.channel||'—')}</td><td><div style="min-width:150px;line-height:1.35"><b>${formatPeriod(s.fromDate,s.toDate)}</b><div class="hint" style="margin-top:3px">${s.fromDate&&s.toDate&&String(s.fromDate)===String(s.toDate)?'Single-day settlement':'Settlement date range'}</div></div></td><td>${settlementMoney(s.gross)}</td><td>${settlementMoney(s.fees)}</td><td>${settlementMoney(s.tcs)}</td><td>${settlementMoney(s.tds)}</td><td>${settlementMoney(s.refunds)}</td><td><b>${settlementMoney(s.netReceived)}</b></td><td>${formatDate(s.receivedDate)}</td><td>${(()=>{const ids=[...(s.items||[]).map(it=>String(it.orderId||'').trim()),String(s.orderId||'').trim()].filter(Boolean).filter((v,i,a)=>a.indexOf(v)===i);return ids.length?`<div style="display:flex;flex-direction:column;gap:3px;min-width:190px">${ids.map(id=>`<span><b>${esc(id)}</b></span>`).join('')}</div>`:'—'})()}</td><td><span class="badge ${s.status==='Reconciled'?'green':s.status==='Mismatch'?'red':'orange'}">${esc(s.status||'Pending')}</span></td><td class="actions"><button class="edit" onclick="openModal('marketplaceSettlements',${i})">Edit</button><button class="del" onclick="deleteSettlementRecord(${i})">Delete</button></td></tr>`).join('')||'<tr><td colspan="14" class="hint">No settlement records found.</td></tr>'}</tbody></table></div></div>`;
}
function applySettlementFilters(){window.settlementSearch=document.getElementById('settlementSearch')?.value||'';window.settlementChannel=document.getElementById('settlementChannel')?.value||'All';window.settlementStatus=document.getElementById('settlementStatus')?.value||'All';window.settlementFiltersApplied=Boolean(window.settlementSearch||window.settlementChannel!=='All'||window.settlementStatus!=='All');window.settlementSelected=new Set();show('marketplaceSettlements');}
function paymentTotalsForOrder(orderNo){let ord=data.orders.find(x=>x.orderNo===orderNo);if(!ord)return {total:0,paid:0,due:0,status:'Pending'};let total=Number(ord.total||0);let paid=data.payments.filter(x=>x.orderNo===orderNo && x.status!=='Pending').reduce((s,x)=>s+Number(x.amount||0),0);let due=Math.max(0,total-paid);let status=paid<=0?'Pending':due<=0?'Paid':'Partial';return {total,paid,due,status}}
function syncOrderPayment(orderNo,seedPaid=null){let ord=data.orders.find(x=>x.orderNo===orderNo);if(!ord)return;let linked=data.payments.filter(x=>x.orderNo===orderNo);if(seedPaid!==null && Number(seedPaid||0)>0 && !linked.length){data.payments.push({receiptNo:nextNo('REC','payments','receiptNo'),customer:ord.customer,date:ord.date||todayISO(),amount:Number(seedPaid||0),mode:'Order Payment',status:'Received',orderNo:ord.orderNo,source:'order-auto'});linked=data.payments.filter(x=>x.orderNo===orderNo)}let t=paymentTotalsForOrder(orderNo);ord.paidAmount=t.paid;ord.dueAmount=t.due;ord.payment=t.status;let inv=data.invoices.find(x=>x.orderNo===orderNo);if(inv){inv.paidAmount=t.paid;inv.dueAmount=t.due;inv.status=t.status}}
function syncAllPayments(){data.orders.forEach(x=>syncOrderPayment(x,Number(x.paidAmount||0)>0&&!data.payments.some(p=>p.orderNo===x.orderNo)?Number(x.paidAmount||0):null));data.invoices.forEach(inv=>{let ord=data.orders.find(x=>x.orderNo===inv.orderNo);if(ord){inv.paidAmount=Number(ord.paidAmount||0);inv.dueAmount=Number(ord.dueAmount||Math.max(0,Number(inv.total||0)-Number(ord.paidAmount||0)));inv.status=ord.payment}})} syncAllPayments();save();
function renderRows(key){let q=(document.getElementById('search')?.value||'').toLowerCase();let source=key==='stock'?data.products.map((p,i)=>({r:{sku:p.sku,product:p.name,inStock:Number(p.stock||0),reorder:Number(p.reorder||0),note:p.note||((Number(p.stock||0)<=0)?'Out of stock':Number(p.stock||0)<=Number(p.reorder||0)?'Reorder soon':'OK')},i})):data[key].map((r,i)=>({r,i}));let rows=source.filter(x=>JSON.stringify(x.r).toLowerCase().includes(q));document.getElementById('rows').innerHTML=rows.map(({r,i})=>`<tr>${sections[key].fields.map(f=>`<td>${f[2]==='image'?(r.image?`<img src="${r.image}" class="product-thumb" alt="Product">`:'<span class="image-placeholder">No image</span>'):f[2]==='date'?esc(formatDate(r[f[0]])):esc(r[f[0]]??'')}</td>`).join('')}${key==='orders'?`<td><b>${esc((r.items||[]).map(x=>`${x.name} × ${x.qty}`).join(', ')||'No products')}</b><br><span class="hint">Discount ₹${Number(r.discount||0).toLocaleString('en-IN')} • Transport ₹${Number(r.transport||0).toLocaleString('en-IN')} • GST ₹${Number(r.gstAmount||0).toLocaleString('en-IN')}</span></td>`:''}${key==='purchases'?`<td><b>${esc((r.items||[]).map(x=>`${x.name} × ${x.qty}`).join(', ')||'No products')}</b><br><span class="hint">Discount ₹${Number(r.discount||0).toLocaleString('en-IN')} • Transport ₹${Number(r.transport||0).toLocaleString('en-IN')} • GST ₹${Number(r.gstAmount||0).toLocaleString('en-IN')}</span></td>`:''}<td class="actions">${key==='invoices'?`<div class="invoice-actions"><button class="edit" onclick="openModal('${key}',${i})">Edit</button><button class="btn" onclick="downloadInvoice(${i})">Download PDF</button><button class="btn secondary" onclick="previewInvoice(${i})">Preview</button><button class="del" onclick="del('${key}',${i})">Delete</button></div>`:key==='stock'?`<button class="edit" onclick="openModal('products',${i})">Edit Product</button>`:`<button class="edit" onclick="openModal('${key}',${i})">Edit</button><button class="del" onclick="del('${key}',${i})">Delete</button>`}</td></tr>`).join('')||`<tr><td colspan="${sections[key].fields.length+(key==='orders'||key==='purchases'?2:1)}">No records found.</td></tr>`}
function esc(v){return String(v).replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]))}
function todayISO(){return new Date().toISOString().slice(0,10)}
function formatPeriod(from,to){const f=formatDate(from),t=formatDate(to);if(!f&&!t)return '—';if(f&&(!t||f===t))return f;if(!f)return t;return `${f} – ${t}`}
function formatDate(v){if(!v)return '';let s=String(v).trim();let m=null;if(/^\d{4}-\d{2}-\d{2}/.test(s)){m=s.match(/^(\d{4})-(\d{2})-(\d{2})/)}else if(/^\d{2}[-/]\d{2}[-/]\d{4}/.test(s)){m=s.match(/^(\d{2})[-\/](\d{2})[-\/](\d{4})/);if(m){let d=m[1],mo=m[2],y=m[3];m=[null,y,mo,d]}}if(m){const months=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];const y=m[1],mo=m[2],d=m[3];return `${d} ${months[Number(mo)-1]||mo} ${y}`}const dt=new Date(s);if(!Number.isNaN(dt.getTime())){return `${String(dt.getDate()).padStart(2,'0')} ${['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'][dt.getMonth()]} ${dt.getFullYear()}`}return s}
function nextNo(prefix,key,field){let nums=(data[key]||[]).map(x=>parseInt(String(x[field]||'').replace(/\D/g,''),10)).filter(Number.isFinite);let n=(nums.length?Math.max(...nums):0)+1;return `${prefix}-${String(n).padStart(4,'0')}`}
function customerOptions(selected){return `<option value="">Select customer</option>`+data.customers.map(x=>`<option value="${esc(x.name)}" ${x.name===selected?'selected':''}>${esc(x.name)}</option>`).join('')}
function productOptions(selected, allowOut=false){return `<option value="">Select product</option>`+data.products.filter(x=>allowOut||Number(x.stock||0)>0||x.sku===selected).map(x=>`<option value="${esc(x.sku)}" ${x.sku===selected?'selected':''}>${esc(x.name)} • Stock ${Number(x.stock||0)}</option>`).join('')}
function customerData(name){return data.customers.find(x=>x.name===name)||{}}
function gstOptions(selected){let v=selected===''||selected==null?5:Number(selected);return `<option value="5" ${v===5?'selected':''}>5%</option><option value="12" ${v===12?'selected':''}>12%</option><option value="18" ${v===18?'selected':''}>18%</option><option value="Custom" ${![5,12,18].includes(v)?'selected':''}>Custom</option>`}
function invoiceOrderChanged(){let no=document.getElementById('invoiceOrder')?.value||'';let o=data.orders.find(x=>x.orderNo===no)||{};let set=(n,v)=>{let el=document.querySelector('#form [name="'+n+'"]');if(el)el.value=v??''};if(o.orderNo){set('customer',o.customer);set('date',o.date||todayISO());set('subtotal',Number(o.subtotal||0).toFixed(2));set('discount',Number(o.discount||0).toFixed(2));set('transport',Number(o.transport||0).toFixed(2));set('gstAmount',Number(o.gstAmount||0).toFixed(2));set('total',Number(o.total||0).toFixed(2));let t=paymentTotalsForOrder(o.orderNo);set('paidAmount',Number(t.paid||0).toFixed(2));set('dueAmount',Number(t.due||0).toFixed(2));set('status',t.status||o.payment||'Pending');let box=document.getElementById('invoicePaymentInfo');if(box)box.innerHTML='<b>Payment Status:</b> '+esc(t.status)+' &nbsp; <b>Paid:</b> ₹'+Number(t.paid||0).toLocaleString('en-IN',{minimumFractionDigits:0,maximumFractionDigits:2})+' &nbsp; <b>Due:</b> ₹'+Number(t.due||0).toLocaleString('en-IN',{minimumFractionDigits:0,maximumFractionDigits:2});}else{['customer','date','subtotal','discount','transport','gstAmount','total','paidAmount','dueAmount'].forEach(n=>set(n,''));set('status','Pending');let box=document.getElementById('invoicePaymentInfo');if(box)box.textContent='Select an order to fetch invoice amount and payment status.';}}
function openInvoiceModal(index=null){editing={key:'invoices',index};let r=index===null?{}:data.invoices[index];document.getElementById('modalTitle').textContent=index===null?'New Invoice':'Edit Invoice';let selected=r.orderNo||'';document.getElementById('fields').innerHTML=`
<label class="field"><span>Invoice No.</span><input name="invoiceNo" readonly class="readonly" value="${esc(r.invoiceNo||nextNo('INV','invoices','invoiceNo'))}"><span class="auto-badge">Auto generated</span></label>
<label class="field"><span>Order No.</span><select name="orderNo" id="invoiceOrder" onchange="invoiceOrderChanged()">${orderOptions(selected)}</select></label>
<label class="field"><span>Delivery Customer</span><select name="customer" disabled>${customerOptions(r.customer||'')}</select></label>
<label class="field"><span>Invoice Date</span><input type="date" name="date" value="${esc(r.date||todayISO())}" readonly class="readonly"></label>
<label class="field"><span>Subtotal</span><input name="subtotal" type="number" readonly class="readonly" value="${Number(r.subtotal||0).toFixed(2)}"></label>
<label class="field"><span>Discount</span><input name="discount" type="number" readonly class="readonly" value="${Number(r.discount||0).toFixed(2)}"></label>
<label class="field"><span>Transport / Delivery (No GST)</span><input name="transport" type="number" readonly class="readonly" value="${Number(r.transport||0).toFixed(2)}"></label>
<label class="field"><span>GST Amount</span><input name="gstAmount" type="number" readonly class="readonly" value="${Number(r.gstAmount||0).toFixed(2)}"></label>
<label class="field"><span>Total</span><input name="total" type="number" readonly class="readonly" value="${Number(r.total||0).toFixed(2)}"></label>
<label class="field"><span>Paid Amount</span><input name="paidAmount" type="number" readonly class="readonly" value="${Number(r.paidAmount||0).toFixed(2)}"></label>
<label class="field"><span>Due Amount</span><input name="dueAmount" type="number" readonly class="readonly" value="${Number(r.dueAmount||0).toFixed(2)}"></label>
<label class="field"><span>Payment Status</span><select name="status" disabled><option>Pending</option><option>Partial</option><option>Paid</option></select></label>
<div class="field full"><div id="invoicePaymentInfo" class="format-card readonly">Select an order to fetch invoice amount and payment status.</div></div>`;document.getElementById('modal').classList.add('show');let sel=document.getElementById('invoiceOrder');if(sel)sel.value=selected;if(selected)invoiceOrderChanged();else if(r.customer){let c=document.querySelector('#form select[name="customer"]');if(c)c.value=r.customer;let st=document.querySelector('#form [name="status"]');if(st)st.value=r.status||'Pending';} }
function openOrderModal(index=null){editing={key:'orders',index};let r=index===null?{}:data.orders[index];document.getElementById('modalTitle').textContent=index===null?'New Order':'Edit Order';document.getElementById('fields').innerHTML=`
<label class="field"><span>Order No.</span><input name="orderNo" readonly class="readonly" value="${esc(r.orderNo||nextNo('ORD','orders','orderNo'))}"><span class="auto-badge">Auto generated</span></label>
<label class="field"><span>Customer</span><select name="customer" id="orderCustomer" onchange="fillCustomerInfo()">${customerOptions(r.customer||'')}</select></label>
<label class="field"><span>Order Date</span><input type="date" name="date" value="${esc(r.date||todayISO())}"></label>
<div class="field full"><span>Customer Billing Details</span><div id="customerInfo" class="format-card"></div></div>
<div class="field full"><span>Products</span><div id="orderItems"></div><button type="button" class="btn secondary" onclick="addOrderItem()">+ Add Product</button></div>
<label class="field"><span>Discount</span><input type="number" step="0.01" name="discount" value="${esc(r.discount||0)}" oninput="calcOrder()"></label>
<label class="field"><span>Transport / Delivery Charge (No GST)</span><input type="number" step="0.01" name="transport" value="${esc(r.transport||0)}" oninput="calcOrder()"></label>
<label class="field"><span>Tax Type</span><select name="taxType" onchange="calcOrder()"><option value="CGST_SGST">CGST + SGST</option><option value="IGST">IGST</option><option value="NONE">No GST</option></select></label>
<label class="field"><span>GST Amount</span><input type="number" step="0.01" name="gstAmount" value="${esc(r.gstAmount||0)}" readonly class="readonly"></label>
<div class="field"><span>CGST</span><input name="cgstAmount" type="number" readonly class="readonly" value="${Number(r.cgstAmount||0).toFixed(2)}"></div>
<div class="field"><span>SGST</span><input name="sgstAmount" type="number" readonly class="readonly" value="${Number(r.sgstAmount||0).toFixed(2)}"></div>
<div class="field"><span>IGST</span><input name="igstAmount" type="number" readonly class="readonly" value="${Number(r.igstAmount||0).toFixed(2)}"></div>
<label class="field"><span>Total</span><input type="number" step="0.01" name="total" value="${esc(r.total||0)}" readonly class="readonly"></label>
<label class="field"><span>Paid Amount</span><input type="number" step="0.01" name="paidAmount" value="${esc(r.paidAmount||0)}" oninput="calcOrder()"></label>
<label class="field"><span>Due Amount</span><input type="number" step="0.01" name="dueAmount" value="${esc(r.dueAmount||0)}" readonly class="readonly"></label>
<label class="field"><span>Order Status</span><select name="status"><option>Pending</option><option>Confirmed</option><option>Processing</option><option>Delivered</option><option>Cancelled</option></select></label>
<label class="field"><span>Payment Status</span><select name="payment"><option>Pending</option><option>Partial</option><option>Paid</option></select></label>`;
document.getElementById('modal').classList.add('show');let items=r.items||[{sku:'',qty:1,rate:0,gst:5}];document.getElementById('orderItems').innerHTML='';items.forEach(it=>addOrderItem(it));document.querySelector('[name=status]').value=r.status||'Pending';document.querySelector('[name=payment]').value=r.payment||'Pending';document.querySelector('[name=taxType]').value=r.taxType||'CGST_SGST';fillCustomerInfo();calcOrder();}
function addOrderItem(item={}){let wrap=document.getElementById('orderItems');let row=document.createElement('div');row.className='format-card orderitem';row.innerHTML=`<div class="grid"><label class="field"><span>Product</span><select class="oi-sku" onchange="productChanged(this)">${productOptions(item.sku||'')}</select></label><label class="field"><span>Qty</span><input class="oi-qty" type="number" min="1" value="${esc(item.qty||1)}" oninput="calcOrder()"></label><label class="field"><span>Rate</span><input class="oi-rate" type="number" step="0.01" value="${esc(item.rate||0)}" oninput="calcOrder()"></label><label class="field"><span>GST %</span><select class="oi-gst" onchange="calcOrder()">${gstOptions(item.gst??5)}</select></label><div class="field full"><button type="button" class="btn danger" onclick="this.closest('.orderitem').remove();calcOrder()">Remove Product</button></div></div>`;wrap.appendChild(row);if(!item.sku)row.querySelector('.oi-rate').value='0';}
function productChanged(sel){let p=data.products.find(x=>x.sku===sel.value);let row=sel.closest('.orderitem');if(p){if(Number(p.stock||0)<=0){alert('This product is out of stock and cannot be added.');sel.value='';return}row.querySelector('.oi-rate').value=p.b2b||0;row.querySelector('.oi-gst').value=String(p.gst||5)}calcOrder()}
function fillCustomerInfo(){let c=customerData(document.getElementById('orderCustomer')?.value);document.getElementById('customerInfo').innerHTML=c.name?`<b>${esc(c.name)}</b><br>${esc(c.address||'')}<br>${esc(c.city||'')}, ${esc(c.state||'')} - ${esc(c.pincode||'')}<br><b>GSTIN:</b> ${esc(c.gstin||'Not provided')}<br><b>Phone:</b> ${esc(c.phone||'')}`:'Select a customer to auto-fill billing details.'}
function calcOrder(){let rows=[...document.querySelectorAll('.orderitem')],subtotal=0,gst=0,items=[];rows.forEach(row=>{let sku=row.querySelector('.oi-sku')?.value,p=data.products.find(x=>x.sku===sku),qty=Number(row.querySelector('.oi-qty')?.value||0),rate=Number(row.querySelector('.oi-rate')?.value||0),g=Number(row.querySelector('.oi-gst')?.value||0);if(p&&qty>0){subtotal+=qty*rate;gst+=qty*rate*g/100;items.push({sku,name:p.name,qty,rate,gst:g,hsn:p.hsn||''})}});let discount=Number(document.querySelector('[name=discount]')?.value||0),transport=Number(document.querySelector('[name=transport]')?.value||0),taxType=document.querySelector('[name=taxType]')?.value||'CGST_SGST';if(taxType==='NONE')gst=0;let cgst=taxType==='CGST_SGST'?gst/2:0,sgst=taxType==='CGST_SGST'?gst/2:0,igst=taxType==='IGST'?gst:0,total=Math.max(0,subtotal-discount+transport+gst),paid=Number(document.querySelector('[name=paidAmount]')?.value||0),due=Math.max(0,total-paid);if(document.querySelector('[name=gstAmount]'))document.querySelector('[name=gstAmount]').value=gst.toFixed(2);if(document.querySelector('[name=cgstAmount]'))document.querySelector('[name=cgstAmount]').value=cgst.toFixed(2);if(document.querySelector('[name=sgstAmount]'))document.querySelector('[name=sgstAmount]').value=sgst.toFixed(2);if(document.querySelector('[name=igstAmount]'))document.querySelector('[name=igstAmount]').value=igst.toFixed(2);if(document.querySelector('[name=total]'))document.querySelector('[name=total]').value=total.toFixed(2);if(document.querySelector('[name=dueAmount]'))document.querySelector('[name=dueAmount]').value=due.toFixed(2);let ps=paid<=0?'Pending':due<=0?'Paid':'Partial';if(document.querySelector('[name=payment]'))document.querySelector('[name=payment]').value=ps;return {items,subtotal,discount,transport,gstAmount:gst,cgstAmount:cgst,sgstAmount:sgst,igstAmount:igst,taxType,total,paidAmount:paid,dueAmount:due,payment:ps};}

function purchaseProductOptions(selected){return `<option value="">Select product</option>`+data.products.map(x=>`<option value="${esc(x.sku)}" ${x.sku===selected?'selected':''}>${esc(x.name)} • Purchase ₹${Number(x.purchase||0).toLocaleString('en-IN')}</option>`).join('')}
function paymentOrderChanged(sel){let no=sel?.value||'',o=data.orders.find(x=>x.orderNo===no);let cust=document.querySelector('[name=customer]');let info=document.getElementById('paymentOrderInfo');let amount=document.querySelector('[name=amount]');if(!o){if(cust)cust.value='';if(info)info.textContent='Select an order to fetch current payment status.';if(amount)amount.value='';setPaymentStatusDisplay('Pending');return}let t=paymentTotalsForOrder(no);if(cust)cust.value=o.customer||'';if(info)info.innerHTML='<b>Current:</b> '+esc(t.status)+' &nbsp; <b>Total:</b> ₹'+Number(t.total||0).toLocaleString('en-IN',{minimumFractionDigits:0,maximumFractionDigits:2})+' &nbsp; <b>Paid:</b> ₹'+Number(t.paid||0).toLocaleString('en-IN',{minimumFractionDigits:0,maximumFractionDigits:2})+' &nbsp; <b>Due:</b> ₹'+Number(t.due||0).toLocaleString('en-IN',{minimumFractionDigits:0,maximumFractionDigits:2});if(amount){amount.max=Math.max(0,t.due).toFixed(2);if(Number(amount.value||0)>t.due)amount.value=t.due>0?t.due.toFixed(2):'0'}setPaymentStatusDisplay(t.status);paymentAmountChanged(amount)}
function setPaymentStatusDisplay(status){let s=document.getElementById('paymentStatusDisplay'),h=document.querySelector('input[type=hidden][name=status]');if(s)s.value=status||'Pending';if(h)h.value=status||'Pending'}
function paymentAmountChanged(input){let no=document.querySelector('[name=orderNo]')?.value||'',o=data.orders.find(x=>x.orderNo===no);if(!o){setPaymentStatusDisplay('Pending');return}let t=paymentTotalsForOrder(no),add=Math.max(0,Number(input?.value||0));if(add>t.due){add=t.due;if(input)input.value=add.toFixed(2)}let projectedPaid=t.paid+add,projectedDue=Math.max(0,t.total-projectedPaid),status=projectedPaid<=0?'Pending':projectedDue<=0?'Paid':'Partial';setPaymentStatusDisplay(status);let info=document.getElementById('paymentAmountInfo');if(info)info.innerHTML='<b>After this payment:</b> '+esc(status)+' &nbsp; Paid ₹'+Number(projectedPaid||0).toLocaleString('en-IN',{minimumFractionDigits:0,maximumFractionDigits:2})+' &nbsp; Due ₹'+Number(projectedDue||0).toLocaleString('en-IN',{minimumFractionDigits:0,maximumFractionDigits:2})}
function openPurchaseModal(index=null){editing={key:'purchases',index};let r=index===null?{}:data.purchases[index];document.getElementById('modalTitle').textContent=index===null?'New Purchase':'Edit Purchase';document.getElementById('fields').innerHTML=`
<label class="field"><span>PO No.</span><input name="poNo" readonly class="readonly" value="${esc(r.poNo||nextNo('PO','purchases','poNo'))}"><span class="auto-badge">Auto generated</span></label>
<label class="field"><span>Vendor / Supplier</span><select name="vendor" id="purchaseVendor">${vendorOptions(r.vendor||'')}</select></label>
<label class="field"><span>Purchase Date</span><input type="date" name="date" value="${esc(r.date||todayISO())}"></label>
<div class="field full"><span>Vendor Details</span><div id="vendorInfo" class="format-card readonly">Select vendor to see shop, person, address and GSTIN.</div></div>
<div class="field full"><span>Products</span><div id="purchaseItems"></div><button type="button" class="btn secondary" onclick="addPurchaseItem()">+ Add Product</button></div>
<label class="field"><span>Subtotal</span><input name="subtotal" type="number" readonly class="readonly" value="${Number(r.subtotal||0).toFixed(2)}"></label>
<label class="field"><span>Discount</span><input name="discount" type="number" step="0.01" value="${Number(r.discount||0)}" oninput="calcPurchase()"></label>
<label class="field"><span>Transport Amount</span><input name="transport" type="number" step="0.01" value="${Number(r.transport||0)}" oninput="calcPurchase()"></label>
<label class="field"><span>Purchase GST</span><input name="gstAmount" type="number" readonly class="readonly" value="${Number(r.gstAmount||0).toFixed(2)}"></label>
<label class="field"><span>Total Purchase</span><input name="total" type="number" readonly class="readonly" value="${Number(r.total||0).toFixed(2)}"></label>
<label class="field"><span>Status</span><select name="status"><option ${r.status==='Ordered'?'selected':''}>Ordered</option><option ${r.status==='Received'?'selected':''}>Received</option><option ${r.status==='Partial'?'selected':''}>Partial</option><option ${r.status==='Cancelled'?'selected':''}>Cancelled</option></select></label>`;document.getElementById('purchaseVendor').innerHTML=vendorOptions(r.vendor||'');document.getElementById('purchaseVendor').onchange=fillVendorInfo;fillVendorInfo();let items=r.items||[];if(items.length)items.forEach(addPurchaseItem);else addPurchaseItem();calcPurchase();document.getElementById('modal').classList.add('show')}
function fillVendorInfo(){let v=data.vendors.find(x=>x.name===document.getElementById('purchaseVendor')?.value)||{};document.getElementById('vendorInfo').innerHTML=v.name?`<b>${esc(v.name)}</b> • ${esc(v.contact||'')}<br>${esc(v.address||'')}<br>${esc(v.city||'')}${v.state?', '+esc(v.state):''}${v.pincode?' - '+esc(v.pincode):''}<br><b>GSTIN:</b> ${esc(v.gstin||'Not provided')}<br><b>Phone:</b> ${esc(v.phone||'')}`:((data.vendors||[]).length?'Select vendor to see shop, person, address and GSTIN.':'No vendor added. Add the vendor in Vendors master first.')}
function addPurchaseItem(item={}){let wrap=document.getElementById('purchaseItems');let row=document.createElement('div');row.className='format-card purchaseitem';row.innerHTML=`<div class="grid"><label class="field"><span>Product</span><select class="pi-sku" onchange="purchaseProductChanged(this)">${purchaseProductOptions(item.sku||'')}</select></label><label class="field"><span>Qty</span><input class="pi-qty" type="number" min="1" value="${esc(item.qty||1)}" oninput="calcPurchase()"></label><label class="field"><span>Purchase Rate</span><input class="pi-rate" type="number" step="0.01" value="${esc(item.rate||0)}" oninput="calcPurchase()"></label><label class="field"><span>GST %</span><select class="pi-gst" onchange="calcPurchase()">${gstOptions(item.gst??5)}</select></label><div class="field full"><button type="button" class="btn danger" onclick="this.closest('.purchaseitem').remove();calcPurchase()">Remove Product</button></div></div>`;wrap.appendChild(row);if(!item.sku)row.querySelector('.pi-rate').value='0';}
function purchaseProductChanged(sel){let p=data.products.find(x=>x.sku===sel.value),row=sel.closest('.purchaseitem');if(p){row.querySelector('.pi-rate').value=p.purchase||0;row.querySelector('.pi-gst').value=String(p.gst||5)}calcPurchase()}
function calcPurchase(){let subtotal=0,gst=0,items=[];document.querySelectorAll('.purchaseitem').forEach(row=>{let sku=row.querySelector('.pi-sku')?.value,p=data.products.find(x=>x.sku===sku),qty=Number(row.querySelector('.pi-qty')?.value||0),rate=Number(row.querySelector('.pi-rate')?.value||0),g=Number(row.querySelector('.pi-gst')?.value||0);if(p&&qty>0){let base=qty*rate;subtotal+=base;gst+=base*g/100;items.push({sku,name:p.name,qty,rate,gst:g})}});let discount=Number(document.querySelector('[name=discount]')?.value||0),transport=Number(document.querySelector('[name=transport]')?.value||0),total=Math.max(0,subtotal-discount+transport+gst);if(document.querySelector('[name=subtotal]'))document.querySelector('[name=subtotal]').value=subtotal.toFixed(2);if(document.querySelector('[name=gstAmount]'))document.querySelector('[name=gstAmount]').value=gst.toFixed(2);if(document.querySelector('[name=total]'))document.querySelector('[name=total]').value=total.toFixed(2);return {items,subtotal,discount,transport,gstAmount:gst,total}}
function defaultWeightSlabs(){return [
 {min:0,max:0.5,shipping:55,localShipping:55,zonalShipping:55,nationalShipping:55,pickPack:15,reverseShipping:45},
 {min:0.5,max:1,shipping:70,localShipping:70,zonalShipping:70,nationalShipping:70,pickPack:20,reverseShipping:60},
 {min:1,max:2,shipping:95,localShipping:95,zonalShipping:95,nationalShipping:95,pickPack:25,reverseShipping:80},
 {min:2,max:5,shipping:140,localShipping:140,zonalShipping:140,nationalShipping:140,pickPack:35,reverseShipping:120},
 {min:5,max:10,shipping:220,localShipping:220,zonalShipping:220,nationalShipping:220,pickPack:50,reverseShipping:180}
]}
function ensurePricingSlabs(){
 const rules=data.marketplaceFeeRules||{}; const base=defaultWeightSlabs();
 ['Amazon','Flipkart','Meesho'].forEach(ch=>{
  rules[ch]=rules[ch]||{};
  if(!Array.isArray(rules[ch].weightSlabs)||!rules[ch].weightSlabs.length) rules[ch].weightSlabs=base.map(x=>({...x}));
  rules[ch].weightSlabs=rules[ch].weightSlabs.map(x=>{
   const legacy=num(x.shipping);
   return {...x,shipping:num(x.shipping||x.localShipping||legacy),
    localShipping:num(x.localShipping??x.shipping??legacy),
    zonalShipping:num(x.zonalShipping??x.shipping??legacy),
    nationalShipping:num(x.nationalShipping??x.shipping??legacy)};
  });
 });
 data.marketplaceFeeRules=rules;
}
function getWeightSlab(channel,weight,type='shipping'){
 ensurePricingSlabs(); const arr=data.marketplaceFeeRules?.[channel]?.weightSlabs||[]; const w=Math.max(0,num(weight));
 let row=arr.find(x=>w>=num(x.min)&&w<=num(x.max));
 if(!row) row=arr.slice().sort((a,b)=>num(a.max)-num(b.max)).find(x=>w<=num(x.max))||arr[arr.length-1];
 if(!row) return 0; return num(row[type]);
}
function getShippingZone(){
 const z=String(document.getElementById('calcShippingZone')?.value||'local').toLowerCase();
 return ['local','zonal','national'].includes(z)?z:'local';
}
function getZoneShippingType(zone){return zone==='zonal'?'zonalShipping':zone==='national'?'nationalShipping':'localShipping';}
function getWeightSlabShipping(channel,weight,zone){
 const z=zone||getShippingZone(); const type=getZoneShippingType(z);
 const zoneValue=getWeightSlab(channel,weight,type);
 return zoneValue;
}
function renderWeightSlabRows(){
 ensurePricingSlabs();
 const summary=document.getElementById('weightSlabSummary');
 if(summary){summary.innerHTML=['Amazon','Flipkart','Meesho'].map(ch=>{const a=data.marketplaceFeeRules[ch].weightSlabs||[];const preview=a.slice(0,3).map(r=>`${num(r.min)}–${num(r.max)} kg`).join(' • ');const first=a[0]||{};return `<div class="slab-summary-card"><h4>${ch}</h4><div class="slab-count">${a.length} Slabs</div><div class="slab-preview">${preview||'No slabs'}</div><div class="slab-preview">Local ₹${num(first.localShipping??first.shipping)} • Zonal ₹${num(first.zonalShipping??first.shipping)} • National ₹${num(first.nationalShipping??first.shipping)}</div></div>`}).join('')}
}
function renderWeightSlabModalRows(ch){
 ensurePricingSlabs(); const tbody=document.getElementById('slabModalRows'); if(!tbody)return;
 const a=data.marketplaceFeeRules[ch].weightSlabs||[];
 tbody.innerHTML=a.map((r,i)=>`<tr>
 <td><b>${i+1}</b></td>
 <td><input class="slab-min" data-ch="${ch}" data-i="${i}" type="number" step="0.01" min="0" value="${num(r.min)}"></td>
 <td><input class="slab-max" data-ch="${ch}" data-i="${i}" type="number" step="0.01" min="0" value="${num(r.max)}"></td>
 <td><input class="slab-local" data-ch="${ch}" data-i="${i}" type="number" step="0.01" min="0" value="${num(r.localShipping??r.shipping)}"></td>
 <td><input class="slab-zonal" data-ch="${ch}" data-i="${i}" type="number" step="0.01" min="0" value="${num(r.zonalShipping??r.shipping)}"></td>
 <td><input class="slab-national" data-ch="${ch}" data-i="${i}" type="number" step="0.01" min="0" value="${num(r.nationalShipping??r.shipping)}"></td>
 <td><input class="slab-pick" data-ch="${ch}" data-i="${i}" type="number" step="0.01" min="0" value="${num(r.pickPack)}"></td>
 <td><input class="slab-reverse" data-ch="${ch}" data-i="${i}" type="number" step="0.01" min="0" value="${num(r.reverseShipping)}"></td>
 <td><button class="btn danger" onclick="removeWeightSlab('${ch}',${i});renderWeightSlabModalRows('${ch}')">Remove</button></td></tr>`).join('');
}
function ensureWeightSlabModal(){
 if(document.getElementById('weightSlabModal'))return;
 const d=document.createElement('div'); d.id='weightSlabModal'; d.className='slab-modal';
 d.innerHTML=`<div class="slab-dialog"><div class="slab-head"><div><h3>⚖️ Dynamic Weight Slab Manager</h3><div class="hint">Marketplace-wise shipping slabs set karein. Local / Zonal / National charges weight-wise set karein.</div></div><button type="button" class="btn secondary" onclick="closeWeightSlabPopup()">✕</button></div><div class="slab-toolbar"><label class="field"><span>Marketplace</span><select id="slabMarketplace" onchange="renderWeightSlabModalRows(this.value)"><option>Amazon</option><option>Flipkart</option><option>Meesho</option></select></label><button type="button" class="btn secondary" onclick="addWeightSlabFromPopup()">+ Add Slab</button><button type="button" class="btn secondary" onclick="resetSelectedWeightSlabs()">↺ Reset Marketplace</button></div><div class="slab-table-wrap"><table class="slab-table"><thead><tr><th>#</th><th>Min kg</th><th>Max kg</th><th>🚚 Local Shipping ₹</th><th>🚚 Zonal Shipping ₹</th><th>🚚 National Shipping ₹</th><th>Pick & Pack ₹</th><th>Reverse Shipping ₹</th><th>Action</th></tr></thead><tbody id="slabModalRows"></tbody></table></div><div class="alertbox ok slab-note">Example: 0–0.5 kg → first slab. 0.70 kg → 0.5–1 kg slab. Saved slabs calculator mein automatically apply honge.</div><div class="slab-actions"><button type="button" class="btn secondary" onclick="closeWeightSlabPopup()">Cancel</button><button type="button" class="btn" onclick="saveWeightSlabsFromPopup()">✓ Save & Apply</button></div></div>`;
 document.body.appendChild(d);
}
function openWeightSlabPopup(){ensureWeightSlabModal();ensurePricingSlabs();const ch=document.getElementById('calcChannel')?.value||'Amazon';document.getElementById('slabMarketplace').value=['Amazon','Flipkart','Meesho'].includes(ch)?ch:'Amazon';renderWeightSlabModalRows(document.getElementById('slabMarketplace').value);document.getElementById('weightSlabModal').classList.add('show')}
function closeWeightSlabPopup(){document.getElementById('weightSlabModal')?.classList.remove('show')}
function addWeightSlabFromPopup(){const ch=document.getElementById('slabMarketplace')?.value||'Amazon';addWeightSlab(ch);renderWeightSlabModalRows(ch)}
function resetSelectedWeightSlabs(){const ch=document.getElementById('slabMarketplace')?.value||'Amazon';data.marketplaceFeeRules[ch].weightSlabs=defaultWeightSlabs().map(x=>({...x}));renderWeightSlabModalRows(ch);toast(ch+' default slabs restored (Save & Apply to keep)')}
function saveWeightSlabsFromPopup(){const ch=document.getElementById('slabMarketplace')?.value||'Amazon';const a=data.marketplaceFeeRules[ch].weightSlabs||[];for(let i=0;i<a.length;i++){const get=cls=>num(document.querySelector(`.${cls}[data-ch="${ch}"][data-i="${i}"]`)?.value);a[i]={min:get('slab-min'),max:get('slab-max'),shipping:get('slab-local'),localShipping:get('slab-local'),zonalShipping:get('slab-zonal'),nationalShipping:get('slab-national'),pickPack:get('slab-pick'),reverseShipping:get('slab-reverse')}}a.sort((x,y)=>num(x.min)-num(y.min));save();renderWeightSlabRows();runMarketplaceCalc();closeWeightSlabPopup();toast(ch+' weight slabs saved and applied')}

function addWeightSlab(ch){ensurePricingSlabs();const a=data.marketplaceFeeRules[ch].weightSlabs||[];const last=a[a.length-1]||{max:0};const min=num(last.max);a.push({min,max:min+0.5,shipping:Math.max(0,num(last.shipping)+20),localShipping:Math.max(0,num(last.localShipping??last.shipping)+20),zonalShipping:Math.max(0,num(last.zonalShipping??last.shipping)+20),nationalShipping:Math.max(0,num(last.nationalShipping??last.shipping)+20),pickPack:Math.max(0,num(last.pickPack)+5),reverseShipping:Math.max(0,num(last.reverseShipping)+15)});renderWeightSlabRows();}
function removeWeightSlab(ch,i){ensurePricingSlabs();const a=data.marketplaceFeeRules[ch].weightSlabs||[];if(a.length<=1){toast('At least one weight slab is required');return}a.splice(i,1);renderWeightSlabRows();}
function saveWeightSlabs(){ensurePricingSlabs();['Amazon','Flipkart','Meesho'].forEach(ch=>{const rows=[...document.querySelectorAll(`#weightSlabRows input[data-ch="${ch}"]`)];const n=data.marketplaceFeeRules[ch].weightSlabs.length;for(let i=0;i<n;i++){const get=(cls)=>num(document.querySelector(`.${cls}[data-ch="${ch}"][data-i="${i}"]`)?.value);data.marketplaceFeeRules[ch].weightSlabs[i]={min:get('slab-min'),max:get('slab-max'),shipping:get('slab-local'),localShipping:get('slab-local'),zonalShipping:get('slab-zonal'),nationalShipping:get('slab-national'),pickPack:get('slab-pick'),reverseShipping:get('slab-reverse')}}data.marketplaceFeeRules[ch].weightSlabs.sort((a,b)=>num(a.min)-num(b.min));});save();runMarketplaceCalc();toast('Weight shipping slabs saved');}
function resetWeightSlabs(){ensurePricingSlabs();const base=defaultWeightSlabs();['Amazon','Flipkart','Meesho'].forEach(ch=>data.marketplaceFeeRules[ch].weightSlabs=base.map(x=>({...x})));save();renderWeightSlabRows();runMarketplaceCalc();toast('Default weight slabs restored');}

function renderMarketplaceChargeSummary(){const el=document.getElementById('marketplaceChargeSummary');if(!el)return;ensurePricingSlabs();el.innerHTML=['Amazon','Flipkart','Meesho'].map(ch=>{const r=data.marketplaceFeeRules[ch]||{};return `<div class="slab-summary-card"><h4>${ch}</h4><div class="slab-count">Commission ${num(r.referralPct)}% • Closing ₹${num(r.closingFee)}</div><div class="slab-preview">Shipping ₹${num(r.shippingFee)} • Ads ${num(r.adsPct)}% • Fee GST ${num(r.feeGstPct)}%</div><button class="btn secondary" style="margin-top:8px" onclick="openMarketplaceChargesPopup('${ch}')">Edit ${ch}</button></div>`}).join('')}
function ensureMarketplaceChargesModal(){if(document.getElementById('marketplaceChargesModal'))return;const d=document.createElement('div');d.id='marketplaceChargesModal';d.className='landed-modal';d.innerHTML=`<div class="landed-dialog" style="width:min(980px,95vw)"><div class="landed-head"><div><h3>⚙️ Marketplace Charges Manager</h3><div class="hint">Marketplace-wise charges set karein. Ye rules Price Calculator mein automatically apply honge.</div></div><button type="button" class="btn secondary" onclick="closeMarketplaceChargesPopup()">✕</button></div><div class="landed-grid"><label class="field"><span>Marketplace</span><select id="mcMarketplace" onchange="loadMarketplaceChargePopup()"><option>Amazon</option><option>Flipkart</option><option>Meesho</option></select></label><label class="field"><span>Referral / Commission %</span><input id="mcReferral" type="number" min="0" step="0.01"></label><label class="field"><span>Closing Fee ₹</span><input id="mcClosing" type="number" min="0" step="0.01"></label><label class="field"><span>Collection Fee %</span><input id="mcCollection" type="number" min="0" step="0.01"></label><label class="field"><span>Base / Forward Shipping ₹</span><input id="mcShipping" type="number" min="0" step="0.01"></label><label class="field"><span>Pick & Pack ₹</span><input id="mcPickPack" type="number" min="0" step="0.01"></label><label class="field"><span>Reverse Shipping ₹</span><input id="mcReverse" type="number" min="0" step="0.01"></label><label class="field"><span>Ads %</span><input id="mcAds" type="number" min="0" step="0.01"></label><label class="field"><span>Return Reserve %</span><input id="mcReturn" type="number" min="0" step="0.01"></label><label class="field"><span>Marketplace Fee GST %</span><input id="mcFeeGst" type="number" min="0" step="0.01"></label><label class="field"><span>TCS %</span><input id="mcTcs" type="number" min="0" step="0.01"></label><label class="field"><span>TDS %</span><input id="mcTds" type="number" min="0" step="0.01"></label><label class="field full"><span>Other Marketplace Charges ₹</span><input id="mcOther" type="number" min="0" step="0.01"></label></div><div class="alertbox ok">💡 Weight-based Forward Shipping, Pick & Pack aur Reverse Shipping ke detailed slabs <b>Dynamic Weight Slab Manager</b> mein manage honge. Yahan ke base amounts fallback/default hain.</div><div class="landed-actions"><button type="button" class="btn secondary" onclick="closeMarketplaceChargesPopup()">Cancel</button><button type="button" class="btn" onclick="saveMarketplaceChargesPopup()">✓ Save & Apply</button></div></div>`;document.body.appendChild(d)}
function loadMarketplaceChargePopup(){ensurePricingSlabs();const ch=document.getElementById('mcMarketplace')?.value||'Amazon',r=data.marketplaceFeeRules[ch]||{};const map={mcReferral:r.referralPct,mcClosing:r.closingFee,mcCollection:r.collectionPct,mcShipping:r.shippingFee,mcPickPack:r.pickPackFee||0,mcReverse:r.reverseShippingFee||0,mcAds:r.adsPct,mcReturn:r.returnReservePct,mcFeeGst:r.feeGstPct,mcTcs:r.tcsPct,mcTds:r.tdsPct,mcOther:r.otherFee};Object.entries(map).forEach(([id,v])=>{const e=document.getElementById(id);if(e)e.value=num(v)})}
function openMarketplaceChargesPopup(ch){ensureMarketplaceChargesModal();const m=document.getElementById('mcMarketplace');if(m)m.value=['Amazon','Flipkart','Meesho'].includes(ch)?ch:(document.getElementById('calcChannel')?.value||'Amazon');loadMarketplaceChargePopup();const modal=document.getElementById('marketplaceChargesModal');if(modal){modal.classList.add('show');modal.style.display='flex'}}
function closeMarketplaceChargesPopup(){const m=document.getElementById('marketplaceChargesModal');if(m){m.classList.remove('show');m.style.display='none'}}
function saveMarketplaceChargesPopup(){ensurePricingSlabs();const ch=document.getElementById('mcMarketplace')?.value||'Amazon',r=data.marketplaceFeeRules[ch]||{};Object.assign(r,{referralPct:num(document.getElementById('mcReferral')?.value),closingFee:num(document.getElementById('mcClosing')?.value),collectionPct:num(document.getElementById('mcCollection')?.value),shippingFee:num(document.getElementById('mcShipping')?.value),pickPackFee:num(document.getElementById('mcPickPack')?.value),reverseShippingFee:num(document.getElementById('mcReverse')?.value),adsPct:num(document.getElementById('mcAds')?.value),returnReservePct:num(document.getElementById('mcReturn')?.value),feeGstPct:num(document.getElementById('mcFeeGst')?.value),tcsPct:num(document.getElementById('mcTcs')?.value),tdsPct:num(document.getElementById('mcTds')?.value),otherFee:num(document.getElementById('mcOther')?.value)});data.marketplaceFeeRules[ch]=r;save();renderMarketplaceChargeSummary();runMarketplaceCalc();closeMarketplaceChargesPopup();toast(ch+' marketplace charges saved and applied')}

function ensureLandedCostModal(){if(document.getElementById('landedCostModal'))return;const d=document.createElement('div');d.id='landedCostModal';d.className='landed-modal';d.innerHTML=`<div class="landed-dialog"><div class="landed-head"><div><h3>🧮 Purchase / Landed Cost</h3><div class="hint">Product ko stock mein ready hone tak ke actual inward cost ko yahan capture karein.</div></div><button type="button" class="btn secondary" onclick="closeLandedCostPopup()">✕</button></div><div class="landed-grid"><label class="field"><span>Purchase Price</span><input id="lcPurchase" type="number" min="0" step="0.01" oninput="calcLandedCostPopup()"></label><label class="field"><span>Purchase Discount</span><input id="lcDiscount" type="number" min="0" step="0.01" oninput="calcLandedCostPopup()"></label><label class="field"><span>Inward Transport / Freight</span><input id="lcFreight" type="number" min="0" step="0.01" oninput="calcLandedCostPopup()"></label><label class="field"><span>Loading / Unloading</span><input id="lcLoading" type="number" min="0" step="0.01" oninput="calcLandedCostPopup()"></label><label class="field"><span>Inward Packaging</span><input id="lcPackaging" type="number" min="0" step="0.01" oninput="calcLandedCostPopup()"></label><label class="field"><span>Handling Charges</span><input id="lcHandling" type="number" min="0" step="0.01" oninput="calcLandedCostPopup()"></label><label class="field full"><span>Other Inward Cost</span><input id="lcOther" type="number" min="0" step="0.01" oninput="calcLandedCostPopup()"></label></div><div class="landed-total"><span><b>Final Landed Cost / Unit</b><div class="hint">Purchase − Discount + all inward costs</div></span><b id="lcTotal">₹0</b></div><div class="landed-actions"><button type="button" class="btn secondary" onclick="closeLandedCostPopup()">Cancel</button><button type="button" class="btn" onclick="saveLandedCostPopup()">✓ Save & Apply</button></div></div>`;document.body.appendChild(d)}
function landedVal(id){return Math.max(0,num(document.getElementById(id)?.value||0))}
function calcLandedCostPopup(){const total=Math.max(0,landedVal('lcPurchase')-landedVal('lcDiscount')+landedVal('lcFreight')+landedVal('lcLoading')+landedVal('lcPackaging')+landedVal('lcHandling')+landedVal('lcOther'));const e=document.getElementById('lcTotal');if(e)e.textContent=fmtPrice(total);return total}
function openLandedCostPopup(){ensureLandedCostModal();const p=(editing&&editing.key==='products'&&editing.index!==null)?(data.products[editing.index]||{}):{};const d=(editing&&editing.key==='products')?landedCostDraft:{};const set=(id,v)=>{const e=document.getElementById(id);if(e)e.value=num(v)};set('lcPurchase',d.purchaseBase??p.purchaseBase??p.purchase??0);set('lcDiscount',d.purchaseDiscount??p.purchaseDiscount??0);set('lcFreight',d.inboundFreight??p.inboundFreight??p.inboundCost??0);set('lcLoading',d.loadingCost??p.loadingCost??0);set('lcPackaging',d.inwardPackaging??p.inwardPackaging??p.packaging??0);set('lcHandling',d.handlingCost??p.handlingCost??0);set('lcOther',d.otherInwardCost??p.otherInwardCost??p.otherCost??0);calcLandedCostPopup();const m=document.getElementById('landedCostModal');if(m){m.classList.add('show');m.style.display='flex';setTimeout(()=>document.getElementById('lcPurchase')?.focus(),0)}}
function closeLandedCostPopup(){const m=document.getElementById('landedCostModal');if(m){m.classList.remove('show');m.style.display='none'}}
function saveLandedCostPopup(){const total=calcLandedCostPopup();const target=document.getElementById('productPurchaseCost');if(target)target.value=total.toFixed(2);landedCostDraft={purchaseBase:landedVal('lcPurchase'),purchaseDiscount:landedVal('lcDiscount'),inboundFreight:landedVal('lcFreight'),loadingCost:landedVal('lcLoading'),inwardPackaging:landedVal('lcPackaging'),handlingCost:landedVal('lcHandling'),otherInwardCost:landedVal('lcOther'),total};closeLandedCostPopup();toast('Landed Cost calculated and applied');}


// Reliable fallback for the Landed Cost Details button (works even if inline handlers are restricted).
document.addEventListener('click',function(e){
  const btn=e.target.closest?.('#productPurchaseCost + button');
  if(btn){e.preventDefault();e.stopPropagation();openLandedCostPopup();}
  if(e.target.id==='landedCostModal') closeLandedCostPopup();
});

function calculator(){
 const products=data.products||[];
 const first=products[0]||{};
 const safe=(v)=>Number.isFinite(Number(v))?Number(v):0;
 return `<div class="pricing-shell">
  <div class="pricing-hero"><div><div class="pricing-eyebrow">PROFESSIONAL PRICING CONTROL</div><h2>🧮 Marketplace Price Calculator</h2><p>Price a product safely across Amazon, Flipkart and Meesho — fees, GST, ads, returns, TCS/TDS and profit included.</p></div><div class="quick"><button class="btn secondary" onclick="show('products')">🧾 Product Master</button><button class="btn" onclick="resetPricingCalculator()">↺ Reset</button></div></div>
  <div class="panel pricing-input-panel"><div class="pricing-section-title"><div><h3>1. Product & Marketplace</h3><span class="hint">Use your actual landed cost and the marketplace fee rules below.</span></div></div>
   <div class="grid">
    <label class="field"><span>Product / SKU</span><select id="calcProduct" onchange="loadCalcProduct()">${products.length?products.map(x=>`<option value="${esc(x.sku)}">${esc(x.name||x.sku)} • ${esc(x.sku)}</option>`).join(''):'<option value="">No products</option>'}</select></label>
    <label class="field"><span>Marketplace</span><select id="calcChannel" onchange="runMarketplaceCalc()"><option>Amazon</option><option>Flipkart</option><option>Meesho</option></select></label>
    <label class="field"><span>Product / Landed Cost (before Input GST)</span><input id="calcPurchase" type="number" min="0" step="0.01" value="${safe(first.purchase)}" oninput="runMarketplaceCalc()"></label>
    <label class="field"><span>Product GST / Output GST %</span><input id="calcGst" type="number" min="0" step="0.01" value="${safe(first.gst||5)}" oninput="runMarketplaceCalc()"><small class="hint">Customer se collect hone wala product GST.</small></label>
    <label class="field"><span>Purchase Input GST %</span><input id="calcInputGst" type="number" min="0" step="0.01" value="${safe(first.gst||5)}" oninput="runMarketplaceCalc()"><small class="hint">Supplier invoice ka eligible ITC.</small></label>
    <label class="field"><span>Inbound Transport / Freight ₹</span><input id="calcTransport" type="number" min="0" step="0.01" value="${safe(first.inboundCost)}" oninput="runMarketplaceCalc()"></label>
    <label class="field"><span>Transport Input GST %</span><input id="calcTransportGst" type="number" min="0" step="0.01" value="${safe(first.transportGst||18)}" oninput="runMarketplaceCalc()"><small class="hint">Transport invoice par applicable GST / ITC.</small></label>
    <label class="field"><span>Marketplace Service GST %</span><input id="calcServiceGst" type="number" min="0" step="0.01" value="${safe((data.marketplaceFeeRules?.Amazon?.feeGstPct)||18)}" oninput="runMarketplaceCalc()"><small class="hint">Marketplace commission / service charges ka GST.</small></label>
    <label class="field"><span>Product Weight (kg)</span><input id="calcWeight" type="number" min="0" step="0.001" value="${safe(first.weight||first.weightKg)}" oninput="runMarketplaceCalc()"><small class="hint">Example: 0.35 kg → 0–0.5 kg slab</small></label>
    <label class="field"><span>🚚 Shipping Zone</span><select id="calcShippingZone" onchange="runMarketplaceCalc()"><option value="local">Local Shipping</option><option value="zonal">Zonal Shipping</option><option value="national">National Shipping</option></select><small class="hint">Selected zone ka weight-slab shipping calculator mein apply hoga.</small></label>
    <label class="field"><span>Current Selling Price (GST Incl.)</span><input id="calcSellInput" type="number" min="0" step="0.01" value="${safe(first.b2b||first.mrp)}" oninput="runMarketplaceCalc()"></label>
    <label class="field"><span>Comparison Quantity / Units</span><input id="calcQty" type="number" min="1" step="1" value="1" oninput="runMarketplaceCalc()"><small class="hint">Used for projected profit/loss comparison.</small></label>
   </div>
  </div>
  <div class="panel pricing-goal-panel"><div class="pricing-section-title"><div><h3>2. Profit Protection</h3><span class="hint">The calculator recommends the higher price when your profit target and margin target conflict.</span></div></div>
   <div class="grid">
    <label class="field"><span>Target Net Profit / Unit</span><input id="calcTargetProfit" type="number" min="0" step="0.01" value="50" oninput="runMarketplaceCalc()"></label>
    <label class="field"><span>Target Net Margin %</span><input id="calcMargin" type="number" min="0" max="90" step="0.1" value="20" oninput="runMarketplaceCalc()"></label>
   </div>
  </div>
  <div class="pricing-kpis">
   <div class="pricing-kpi safe"><span>🛡️ Minimum Safe Price</span><b id="calcBreakEven">₹0</b><small>Break-even: profit should not go negative</small></div>
   <div class="pricing-kpi recommended"><span>🎯 Recommended Price</span><b id="calcTargetPrice">₹0</b><small>Higher of target-profit and target-margin price</small></div>
   <div class="pricing-kpi actual"><span>🏷️ Current Price Profit</span><b id="calcNetProfit">₹0</b><small id="calcProfitStatus">Enter a selling price</small></div>
   <div class="pricing-kpi margin"><span>📈 Current Net Margin</span><b id="calcNetMargin">0.0%</b><small>After marketplace deductions and reserves</small></div>
  </div>
  <div id="calcPriceAlert" class="alertbox warn">Enter your current selling price to check whether the product is safe, low-margin or loss-making.</div>
  <div class="pricing-two-col">
   <div class="panel pricing-breakdown"><div class="pricing-section-title"><div><h3>💰 Price & Settlement Breakdown</h3><span class="hint">Shows where every ₹ of the selling price goes.</span></div></div><div id="calcBreakdown"></div></div>
   <div class="panel pricing-scenario"><div class="pricing-section-title"><div><h3>📊 Recommended Price Impact</h3><span class="hint">Compare current price with the safe recommendation.</span></div></div><div id="calcScenario"></div></div>
  </div>
  <div class="panel"><div class="pricing-section-title"><div><h3>🌐 Marketplace Profit Comparison</h3><span class="hint">Compare current selling price, profit/loss, margin and recommended price for each marketplace.</span></div></div><div class="profit-compare-toolbar"><b>Filter Marketplace:</b><button id="profitFilterAll" class="profit-filter-btn active" onclick="setProfitCompareFilter('All')">All</button><button id="profitFilterAmazon" class="profit-filter-btn" onclick="setProfitCompareFilter('Amazon')">Amazon</button><button id="profitFilterFlipkart" class="profit-filter-btn" onclick="setProfitCompareFilter('Flipkart')">Flipkart</button><button id="profitFilterMeesho" class="profit-filter-btn" onclick="setProfitCompareFilter('Meesho')">Meesho</button></div><div id="calcProfitCompareSummary" class="profit-compare-summary"></div><div style="overflow:auto"><table class="table profit-compare-table"><thead><tr><th>Marketplace</th><th>Current Price</th><th>Profit / Loss Unit</th><th>Projected Profit / Loss</th><th>Margin</th><th>Break-even</th><th>Recommended</th><th>Marketplace Charges</th><th>Result</th></tr></thead><tbody id="calcMarketplaceCompare"></tbody></table></div></div>
  <div class="panel"><div class="pricing-section-title"><div><h3>⚙ Marketplace Charges</h3><span class="hint">Selected marketplace ke saare charges ek professional popup se manage karein.</span></div><div class="quick"><button class="btn" onclick="openMarketplaceChargesPopup()">⚙️ Manage Marketplace Charges</button><button class="btn secondary" onclick="resetMarketplaceFeeRules()">↺ Reset Defaults</button></div></div><div id="marketplaceChargeSummary" class="slab-summary-grid"></div><div class="alertbox ok">Referral/Commission, Closing, Collection, Forward Shipping, Pick & Pack, Reverse Shipping, Ads, Return Reserve, Fee GST, TCS, TDS aur Other Charges yahan se control honge. Calculator automatically selected marketplace ke rules use karega.</div></div>
  <div class="panel"><div class="pricing-section-title"><div><h3>⚖️ Dynamic Weight Slab Manager</h3><span class="hint">Marketplace-wise weight slabs manage karein. Har weight slab mein Local, Zonal aur National shipping charge alag set karein.</span></div><button class="btn" onclick="openWeightSlabPopup()">⚙️ Manage Weight Slabs</button></div><div class="alertbox ok">🚚 Local Shipping • 🚚 Zonal Shipping • 🚚 National Shipping — selected zone ka charge Price Calculator mein automatically apply hoga. Purane slabs bhi safe rahenge.</div><div id="weightSlabSummary" class="slab-summary-grid"></div></div>
  <div class="panel"><div class="pricing-section-title"><div><h3>🚚 Weight-Based Cost Preview</h3><span class="hint">Live preview for the selected marketplace and product weight.</span></div></div><div id="calcWeightPreview" class="pricing-kpis"></div></div>
  </div>
  <div class="panel"><div class="pricing-section-title"><div><h3>📌 Important</h3><span class="hint">TCS/TDS are shown as cash-withheld deductions for conservative pricing. They are not automatically treated as operating expenses in your accounting P&L.</span></div></div><button class="btn" onclick="applyMarketplaceCalcToProduct()">Use Recommended Price in Product Master</button></div>
 </div>`;
}
function pricingModel(p,channel,sellingPrice){
 const r=(data.marketplaceFeeRules||{})[channel]||{}; ensurePricingSlabs(); const sp=Math.max(0,num(sellingPrice)); const gst=num(p?.gst); const outputGst=gst>0?sp*gst/(100+gst):0; const netSale=sp-outputGst;
 const purchase=num(p?.purchase),pack=num(p?.packaging),other=num(p?.otherCost),inbound=num(document.getElementById('calcTransport')?.value ?? p?.inboundCost),weight=num(p?.weight||p?.weightKg||document.getElementById('calcWeight')?.value);
 const inputGstRate=num(document.getElementById('calcInputGst')?.value ?? p?.gst); const transportGstRate=num(document.getElementById('calcTransportGst')?.value ?? p?.transportGst); const serviceGstRate=num(document.getElementById('calcServiceGst')?.value ?? r.feeGstPct);
 const purchaseInputGst=purchase*inputGstRate/100,transportInputGst=inbound*transportGstRate/100;
 const referral=sp*num(r.referralPct)/100,collection=sp*num(r.collectionPct)/100,ads=sp*num(r.adsPct)/100,returns=sp*num(r.returnReservePct)/100,tcs=sp*num(r.tcsPct)/100,tds=sp*num(r.tdsPct)/100;
 const shippingZone=getShippingZone(); const slabShipping=getWeightSlabShipping(channel,weight,shippingZone)||num(r.shippingFee),pickPack=getWeightSlab(channel,weight,'pickPack'),reverseShipping=getWeightSlab(channel,weight,'reverseShipping');
 const feeBase=referral+collection+num(r.closingFee)+slabShipping+pickPack+num(r.otherFee)+ads,feeGST=feeBase*serviceGstRate/100;
 const totalInputGst=purchaseInputGst+transportInputGst+feeGST; const netGstLiability=Math.max(0,outputGst-totalInputGst);
 const fixedCost=purchase+inbound+pack+other+feeBase+feeGST+returns+reverseShipping; const cashDeductions=fixedCost+tcs+tds; const profitAfterCash=netSale-cashDeductions; const profitAfterItc=profitAfterCash+totalInputGst; const accountingProfit=netSale-(purchase+inbound+pack+other+feeBase+returns+reverseShipping);
 return {sp,outputGst,netSale,purchase,pack,other,inbound,inputGstRate,transportGstRate,serviceGstRate,purchaseInputGst,transportInputGst,feeInputGst:feeGST,totalInputGst,netGstLiability,profitAfterItc,weight,shippingZone,referral,collection,closingFee,otherMarketplaceFee,ads,returns,tcs,tds,slabShipping,pickPack,reverseShipping,feeBase,feeGST,fixedCost,cashDeductions,profitAfterCash,accountingProfit,netMargin:sp?profitAfterItc/sp*100:0,totalCharges:purchase+pack+other+inbound+feeBase+feeGST+tcs+tds+returns+reverseShipping};
}
function solvePricing(p,channel,goalProfit=0,goalMargin=0){
 const test=(sp)=>pricingModel(p,channel,sp).profitAfterItc; let lo=0,hi=100;
 while(test(hi)<goalProfit && hi<10000000)hi*=2; for(let i=0;i<80;i++){const mid=(lo+hi)/2;if(test(mid)>=goalProfit)hi=mid;else lo=mid;} const profitPrice=hi;
 let marginPrice=profitPrice; if(goalMargin>0){lo=0;hi=Math.max(100,profitPrice*2);for(let i=0;i<80;i++){const mid=(lo+hi)/2;const m=pricingModel(p,channel,mid).netMargin;if(m>=goalMargin)hi=mid;else lo=mid;}marginPrice=hi;}
 lo=0;hi=Math.max(100,profitPrice*2);for(let i=0;i<80;i++){const mid=(lo+hi)/2;if(test(mid)>=0)hi=mid;else lo=mid;} const be=hi;
 return {breakEven:be,profitPrice,marginPrice,recommended:Math.max(profitPrice,marginPrice)};
}
function fmtPrice(v){return '₹'+num(v).toLocaleString('en-IN',{minimumFractionDigits:0,maximumFractionDigits:2});}
window.profitCompareFilter=window.profitCompareFilter||'All';
function setProfitCompareFilter(ch){window.profitCompareFilter=ch;['All','Amazon','Flipkart','Meesho'].forEach(x=>{const e=document.getElementById('profitFilter'+x);if(e)e.classList.toggle('active',x===ch)});runMarketplaceCalc();}
function renderProfitComparison(pp,targetProfit,targetMargin,sell,qty){
 const all=['Amazon','Flipkart','Meesho']; const filter=window.profitCompareFilter||'All'; const list=filter==='All'?all:[filter];
 const rows=list.map(c=>{const q=solvePricing(pp,c,targetProfit,targetMargin), current=pricingModel({...pp,weight:num(pp.weight)},c,sell), rec=pricingModel({...pp,weight:num(pp.weight)},c,q.recommended); const projected=current.profitAfterCash*qty; const status=sell<=0?'ENTER PRICE':current.profitAfterCash<0?'LOSS':sell<q.recommended?'LOW MARGIN':'PROFIT'; const cls=current.profitAfterCash<0?'loss-row':status==='PROFIT'?'best-profit':''; return {c,q,current,rec,projected,status,cls}});
 const profitable=rows.filter(x=>x.current.profitAfterCash>=0 && x.status!=='ENTER PRICE'); const best=profitable.length?profitable.reduce((a,b)=>a.current.profitAfterCash>b.current.profitAfterCash?a:b):null;
 const cmp=document.getElementById('calcMarketplaceCompare'); if(cmp)cmp.innerHTML=rows.map(x=>`<tr class="${x.cls}"><td><b>${x.c}</b>${best&&best.c===x.c?'<div class="profit-badge good" style="margin-top:4px">BEST CURRENT PROFIT</div>':''}</td><td>${fmtPrice(sell)}</td><td><b style="color:${x.current.profitAfterCash<0?'#b42318':'#067647'}">${x.status==='ENTER PRICE'?'—':x.current.profitAfterCash<0?'− ':''}${x.status==='ENTER PRICE'?'':fmtPrice(Math.abs(x.current.profitAfterCash))}</b></td><td><b style="color:${x.projected<0?'#b42318':'#067647'}">${x.status==='ENTER PRICE'?'—':x.projected<0?'− ':''}${x.status==='ENTER PRICE'?'':fmtPrice(Math.abs(x.projected))}</b></td><td>${x.status==='ENTER PRICE'?'—':x.current.netMargin.toFixed(1)+'%'}</td><td>${fmtPrice(x.q.breakEven)}</td><td>${fmtPrice(x.q.recommended)}</td><td>${fmtPrice(x.current.feeBase+x.current.feeGST+x.current.tcs+x.current.tds+x.current.returns+x.current.reverseShipping)}</td><td><span class="profit-badge ${x.status==='LOSS'?'bad':x.status==='PROFIT'?'good':x.status==='ENTER PRICE'?'warn':'warn'}">${x.status}</span></td></tr>`).join('');
 const summary=document.getElementById('calcProfitCompareSummary'); if(summary){const bestRec=rows.reduce((a,b)=>!a||b.q.recommended<a.q.recommended?b:a,null); const worst=rows.filter(x=>x.status!=='ENTER PRICE').reduce((a,b)=>!a||b.current.profitAfterCash<a.current.profitAfterCash?b:a,null); summary.innerHTML=`<div class="profit-summary-card ${best?'good':'bad'}"><span>Best Current Profit</span><b>${best?best.c+' • '+fmtPrice(best.current.profitAfterCash):'No profitable marketplace'}</b></div><div class="profit-summary-card info"><span>Lowest Recommended Price</span><b>${bestRec?bestRec.c+' • '+fmtPrice(bestRec.q.recommended):'—'}</b></div><div class="profit-summary-card ${worst&&worst.current.profitAfterCash<0?'bad':'good'}"><span>Current Loss Risk</span><b>${worst&&worst.current.profitAfterCash<0?worst.c+' • '+fmtPrice(Math.abs(worst.current.profitAfterCash))+' loss':'No current loss'}</b></div><div class="profit-summary-card info"><span>Units Compared</span><b>${qty.toLocaleString('en-IN')}</b></div>`}
}
function runMarketplaceCalc(){
 const p0=data.products.find(x=>x.sku===document.getElementById('calcProduct')?.value)||{}; const ch=document.getElementById('calcChannel')?.value||'Amazon';
 const pp={...p0,purchase:num(document.getElementById('calcPurchase')?.value),gst:num(document.getElementById('calcGst')?.value),weight:num(document.getElementById('calcWeight')?.value)};
 const targetProfit=Math.max(0,num(document.getElementById('calcTargetProfit')?.value)),targetMargin=Math.max(0,num(document.getElementById('calcMargin')?.value)),sell=Math.max(0,num(document.getElementById('calcSellInput')?.value)); const qty=Math.max(1,Math.floor(num(document.getElementById('calcQty')?.value)||1));
 const sol=solvePricing(pp,ch,targetProfit,targetMargin),actual=pricingModel(pp,ch,sell),rec=pricingModel(pp,ch,sol.recommended);
 const set=(id,v)=>{const e=document.getElementById(id);if(e)e.textContent=fmtPrice(v)}; set('calcBreakEven',sol.breakEven);set('calcTargetPrice',sol.recommended);set('calcNetProfit',actual.profitAfterItc);
 const m=document.getElementById('calcNetMargin');if(m)m.textContent=actual.netMargin.toFixed(1)+'%';
 const ps=document.getElementById('calcProfitStatus');if(ps)ps.textContent=sell<=0?'Enter a selling price':actual.profitAfterItc<0?'LOSS — price is below safe level':`Profit after eligible GST ITC ${fmtPrice(actual.profitAfterItc)} / unit`;
 const alert=document.getElementById('calcPriceAlert');if(alert){if(sell<=0){alert.className='alertbox warn';alert.innerHTML='Enter your current selling price to check the product.'}else if(actual.profitAfterItc<0){alert.className='alertbox danger';alert.innerHTML=`<b>⚠ LOSS ALERT:</b> Current price ${fmtPrice(sell)} is below the minimum safe price ${fmtPrice(sol.breakEven)}. Estimated cash loss: <b>${fmtPrice(Math.abs(actual.profitAfterItc))}</b> per unit.`}else if(sell<sol.recommended){alert.className='alertbox warn';alert.innerHTML=`<b>⚠ LOW PRICE:</b> Current price is profitable, but below your recommended price ${fmtPrice(sol.recommended)}. Current margin is ${actual.netMargin.toFixed(1)}%.`}else{alert.className='alertbox ok';alert.innerHTML=`<b>✓ PRICE SAFE:</b> Current price ${fmtPrice(sell)} meets your recommended target. Profit after eligible GST ITC: <b>${fmtPrice(actual.profitAfterItc)}</b> / unit.`}}
 const bd=document.getElementById('calcBreakdown');if(bd)bd.innerHTML=`<table class="smalltable"><tbody><tr><td>Customer Selling Price (GST Incl.)</td><td><b>${fmtPrice(sell)}</b></td></tr><tr><td>Output GST included</td><td>− ${fmtPrice(actual.outputGst)}</td></tr><tr><td>Net Sale Value</td><td><b>${fmtPrice(actual.netSale)}</b></td></tr><tr><td>Product / Landed Cost</td><td>− ${fmtPrice(actual.purchase)}</td></tr><tr><td>Purchase Input GST / ITC</td><td>+ ${fmtPrice(actual.purchaseInputGst)}</td></tr><tr><td>Inbound Transport / Freight</td><td>− ${fmtPrice(actual.inbound)}</td></tr><tr><td>Transport Input GST / ITC</td><td>+ ${fmtPrice(actual.transportInputGst)}</td></tr><tr><td>Landed Cost Components (already included above)</td><td><span class="hint">Purchase − Discount + Freight + Loading + Packaging + Handling + Other</span></td></tr><tr><td>Marketplace Fees + Shipping + Ads</td><td>− ${fmtPrice(actual.feeBase)}</td></tr><tr><td>GST on Marketplace Service</td><td>− ${fmtPrice(actual.feeGST)} <span class="hint">(Input ITC)</span></td></tr><tr><td>Total Input GST / ITC</td><td><b>+ ${fmtPrice(actual.totalInputGst)}</b></td></tr><tr><td>Estimated Net GST Liability</td><td><b>${fmtPrice(actual.netGstLiability)}</b> <span class="hint">Output GST − eligible ITC</span></td></tr><tr><td>Return Reserve</td><td>− ${fmtPrice(actual.returns)}</td></tr><tr><td>TCS + TDS (cash withheld)</td><td>− ${fmtPrice(actual.tcs+actual.tds)}</td></tr><tr><td>Estimated Cash Profit / Unit</td><td><b>${fmtPrice(actual.profitAfterCash)}</b></td></tr><tr><td><b>Profit after eligible GST ITC</b></td><td><b>${fmtPrice(actual.profitAfterItc)}</b></td></tr></tbody></table>`;
 const sc=document.getElementById('calcScenario');if(sc)sc.innerHTML=`<div class="pricing-scenario-row"><span>Minimum safe</span><b>${fmtPrice(sol.breakEven)}</b></div><div class="pricing-scenario-row"><span>Target-profit price</span><b>${fmtPrice(sol.profitPrice)}</b></div><div class="pricing-scenario-row"><span>Target-margin price</span><b>${fmtPrice(sol.marginPrice)}</b></div><div class="pricing-scenario-row highlight"><span>Recommended price</span><b>${fmtPrice(sol.recommended)}</b></div><div class="pricing-scenario-row"><span>Profit @ recommended</span><b>${fmtPrice(rec.profitAfterItc)}</b></div><div class="pricing-scenario-row"><span>Margin @ recommended</span><b>${rec.netMargin.toFixed(1)}%</b></div>`;
 renderProfitComparison(pp,targetProfit,targetMargin,sell,qty);['All','Amazon','Flipkart','Meesho'].forEach(x=>{const e=document.getElementById('profitFilter'+x);if(e)e.classList.toggle('active',x===(window.profitCompareFilter||'All'))});
}
function openMarketplaceServiceGstPopup(){
 const ch=document.getElementById('calcChannel')?.value||'Amazon',r=data.marketplaceFeeRules?.[ch]||{},baseRate=num(r.feeGstPct||18),manual=num(r.manualServiceGstAmount),adj=num(r.manualServiceGstAdjustment),has=Boolean(r.manualServiceGstEnabled);
 let d=document.getElementById('marketplaceServiceGstModal');
 if(!d){d=document.createElement('div');d.id='marketplaceServiceGstModal';d.className='landed-modal';document.body.appendChild(d)}
 d.innerHTML=`<div class="landed-dialog" style="width:min(720px,94vw)"><div class="landed-head"><div><h3>🧾 Marketplace Service GST — Manual Update</h3><div class="hint">${esc(ch)} ke service GST ko calculator mein separately control karein.</div></div><button type="button" class="btn secondary" onclick="closeMarketplaceServiceGstPopup()">✕</button></div><div class="landed-grid"><label class="field"><span>Marketplace</span><select id="msgstMarketplace" onchange="openMarketplaceServiceGstPopup()"><option ${ch==='Amazon'?'selected':''}>Amazon</option><option ${ch==='Flipkart'?'selected':''}>Flipkart</option><option ${ch==='Meesho'?'selected':''}>Meesho</option></select></label><label class="field"><span>Service GST Rate %</span><input id="msgstRate" type="number" min="0" step="0.01" value="${baseRate}"></label><label class="field"><span>Manual GST Amount / Unit ₹</span><input id="msgstAmount" type="number" min="0" step="0.01" value="${manual||0}"><small class="hint">0 = automatic fee × GST rate.</small></label><label class="field"><span>Manual Adjustment ₹</span><input id="msgstAdjustment" type="number" step="0.01" value="${adj||0}"><small class="hint">Positive/negative adjustment for settlement difference.</small></label></div><div class="alertbox ok" style="margin-top:12px"><b>Separate GST control</b><div class="hint">Product Output GST, Seller Purchase GST / ITC aur Marketplace Service GST alag calculate honge. Manual amount set hone par automatic service GST amount override hoga.</div></div><div class="landed-actions"><button type="button" class="btn secondary" onclick="clearMarketplaceServiceGstManual()">↺ Use Auto</button><button type="button" class="btn secondary" onclick="closeMarketplaceServiceGstPopup()">Cancel</button><button type="button" class="btn" onclick="saveMarketplaceServiceGstManual()">✓ Save & Apply</button></div></div>`;
 d.style.display='flex';
}
function closeMarketplaceServiceGstPopup(){const d=document.getElementById('marketplaceServiceGstModal');if(d)d.style.display='none'}
function saveMarketplaceServiceGstManual(){
 const ch=document.getElementById('msgstMarketplace')?.value||'Amazon';data.marketplaceFeeRules=data.marketplaceFeeRules||{};const r=data.marketplaceFeeRules[ch]||{};
 r.feeGstPct=Math.max(0,num(document.getElementById('msgstRate')?.value||18));r.manualServiceGstAmount=Math.max(0,num(document.getElementById('msgstAmount')?.value));r.manualServiceGstAdjustment=num(document.getElementById('msgstAdjustment')?.value);r.manualServiceGstEnabled=r.manualServiceGstAmount>0||Math.abs(r.manualServiceGstAdjustment)>0;data.marketplaceFeeRules[ch]=r;save();const active=document.getElementById('calcChannel')?.value||'Amazon';if(active===ch){const e=document.getElementById('calcServiceGst');if(e)e.value=r.feeGstPct||18}runMarketplaceCalc();closeMarketplaceServiceGstPopup();toast(ch+' Marketplace Service GST manual update applied')}
function clearMarketplaceServiceGstManual(){
 const ch=document.getElementById('msgstMarketplace')?.value||document.getElementById('calcChannel')?.value||'Amazon',r=data.marketplaceFeeRules?.[ch]||{};r.manualServiceGstAmount=0;r.manualServiceGstAdjustment=0;r.manualServiceGstEnabled=false;data.marketplaceFeeRules[ch]=r;save();closeMarketplaceServiceGstPopup();runMarketplaceCalc();toast(ch+' Service GST switched back to automatic')}

function loadCalcProduct(){const p=data.products.find(x=>x.sku===document.getElementById('calcProduct')?.value)||data.products[0];if(!p)return;document.getElementById('calcPurchase').value=num(p.purchase);document.getElementById('calcGst').value=num(p.gst);document.getElementById('calcWeight').value=num(p.weight||p.weightKg||0);document.getElementById('calcSellInput').value=num(p.b2b||p.mrp||0);runMarketplaceCalc();}
function resetPricingCalculator(){const p=data.products?.[0]||{};['calcPurchase','calcGst','calcSellInput'].forEach(id=>{const e=document.getElementById(id);if(e)e.value=0});const g=document.getElementById('calcGst');if(g)g.value=num(p.gst||18);const tp=document.getElementById('calcTargetProfit');if(tp)tp.value=50;const mg=document.getElementById('calcMargin');if(mg)mg.value=20;runMarketplaceCalc();}
function saveMarketplaceFeeRules(){ensurePricingSlabs();['Amazon','Flipkart','Meesho'].forEach(ch=>{const r={};['referralPct','closingFee','shippingFee','collectionPct','adsPct','returnReservePct','tcsPct','tdsPct','feeGstPct','otherFee'].forEach(k=>r[k]=num(document.getElementById(`fee_${ch}_${k}`)?.value));r.weightSlabs=data.marketplaceFeeRules[ch].weightSlabs;data.marketplaceFeeRules[ch]=r});save();show('calculator');toast('Marketplace fee rules saved');}
function resetMarketplaceFeeRules(){data.marketplaceFeeRules={Amazon:{referralPct:15,closingFee:20,shippingFee:55,collectionPct:1,adsPct:2.5,returnReservePct:2,tcsPct:1,tdsPct:.1,feeGstPct:18,otherFee:0},Flipkart:{referralPct:14,closingFee:20,shippingFee:50,collectionPct:1,adsPct:2,returnReservePct:2,tcsPct:1,tdsPct:.1,feeGstPct:18,otherFee:0},Meesho:{referralPct:0,closingFee:0,shippingFee:45,collectionPct:0,adsPct:1.5,returnReservePct:3,tcsPct:1,tdsPct:.1,feeGstPct:18,otherFee:0}};ensurePricingSlabs();save();show('calculator');toast('Default fee rules and weight slabs restored');}

function applyMarketplaceCalcToProduct(){const sku=document.getElementById('calcProduct')?.value,p=data.products.find(x=>x.sku===sku);if(!p)return;const target=document.getElementById('calcTargetPrice');const price=Number(String(target?.textContent||'').replace(/[₹,]/g,''));if(!Number.isFinite(price)||price<=0){alert('Calculate a valid recommended price first.');return}p.b2b=Math.round(price*100)/100;save();show('calculator');toast(`${p.name}: Marketplace Base Selling Price updated to ₹${p.b2b.toFixed(2)}`)}

function marketplaceProfitFor(p,channel,sellingPrice){const r=(data.marketplaceFeeRules||{})[channel]||{};const gst=num(p?.gst||0),sp=num(sellingPrice),outputGst=gst>0?sp*gst/(100+gst):0,netSale=sp-outputGst;const purchase=num(p?.purchase),pack=num(p?.packaging||0),other=num(p?.otherCost||0),inbound=num(p?.inboundCost||0);const referral=sp*num(r.referralPct)/100,collection=sp*num(r.collectionPct)/100,ads=sp*num(r.adsPct)/100,returns=sp*num(r.returnReservePct)/100,tcs=sp*num(r.tcsPct)/100,tds=sp*num(r.tdsPct)/100,feeBase=referral+collection+num(r.closingFee)+num(r.shippingFee)+num(r.otherFee)+ads,feeGST=feeBase*num(r.feeGstPct)/100;const netProfit=netSale-purchase-pack-other-inbound-feeBase-feeGST-tcs-tds-returns;return {sellingPrice:sp,outputGst,netSale,purchase,pack,other,inbound,referral,collection,ads,returns,tcs,tds,feeBase,feeGST,netProfit,netMargin:sp?netProfit/sp*100:0,totalCharges:purchase+pack+other+inbound+feeBase+feeGST+tcs+tds+returns};}
function solveMarketplacePrice(p,channel,targetProfit){const r=(data.marketplaceFeeRules||{})[channel]||{};const gst=num(p?.gst||0),purchase=num(p?.purchase),base=purchase+num(p?.packaging||0)+num(p?.otherCost||0)+num(p?.inboundCost||0)+num(r.closingFee)+num(r.shippingFee)+num(r.otherFee);const variable=1-(num(r.referralPct)+num(r.collectionPct)+num(r.adsPct)+num(r.returnReservePct)+num(r.tcsPct)+num(r.tdsPct))/100;const feeGstFactor=(num(r.referralPct)+num(r.collectionPct)+num(r.adsPct)+num(r.returnReservePct)+0)/100;const outputNetFactor=100/(100+gst);const denom=outputNetFactor-variable-feeGstFactor*num(r.feeGstPct)/100;return denom>0?(base+num(targetProfit))/denom:0;}
function loadCalcProduct(){const p=data.products.find(x=>x.sku===document.getElementById('calcProduct')?.value)||data.products[0];if(!p)return;document.getElementById('calcPurchase').value=num(p.purchase);document.getElementById('calcGst').value=num(p.gst);document.getElementById('calcSellInput').value=num(p.b2b||p.mrp||0);runMarketplaceCalc();}
function loadCalcProduct(){let p=data.products.find(x=>x.sku===document.getElementById('calcProduct')?.value)||data.products[0];if(!p)return;document.getElementById('calcPurchase').value=p.purchase||0;document.getElementById('calcGst').value=String(p.gst||5);if(document.getElementById('calcInputGst'))document.getElementById('calcInputGst').value=String(p.inputGst||p.gst||5);if(document.getElementById('calcPackaging'))document.getElementById('calcPackaging').value=p.packaging||0;if(document.getElementById('calcOther'))document.getElementById('calcOther').value=p.otherCost||0;if(document.getElementById('calcTransport'))document.getElementById('calcTransport').value=p.inboundCost||0;if(document.getElementById('calcTransportGst'))document.getElementById('calcTransportGst').value=String(p.transportGst||18);if(document.getElementById('calcServiceGst'))document.getElementById('calcServiceGst').value=String((data.marketplaceFeeRules?.[document.getElementById('calcChannel')?.value||'Amazon']?.feeGstPct)||18);if(document.getElementById('calcWeight'))document.getElementById('calcWeight').value=p.weight||p.weightKg||0;document.getElementById('calcSellInput').value=p.b2b||p.mrp||0;runMarketplaceCalc();renderWeightSlabRows();}

function runCalc(){let purchase=Number(document.getElementById('calcPurchase')?.value||0),margin=Number(document.getElementById('calcMargin')?.value||0);let sell=purchase*(1+margin/100);for(const [id,val] of [['calcBase',purchase],['calcLanded',purchase],['calcSell',sell]]){let el=document.getElementById(id);if(el)el.textContent='₹'+val.toLocaleString('en-IN',{minimumFractionDigits:0,maximumFractionDigits:2})}}
function applyCalcToProduct(){let sku=document.getElementById('calcProduct')?.value,p=data.products.find(x=>x.sku===sku);if(!p)return;let sellText=document.getElementById('calcSell')?.textContent||'0',sell=Number(sellText.replace(/[^0-9.]/g,''));p.b2b=Number(sell.toFixed(2));save();show('calculator');toast('B2B Sell Rate updated')}
function vendorOptions(selected){const vendors=Array.isArray(data.vendors)?data.vendors:[];return `<option value="">Select vendor</option>`+vendors.filter(v=>String(v.name||'').trim()).map(v=>`<option value="${esc(v.name)}" ${String(v.name)===String(selected||'')?'selected':''}>${esc(v.name)}${v.phone?' • '+esc(v.phone):''}</option>`).join('')}
function orderOptions(selected){return `<option value="">Select order (optional)</option>`+data.orders.map(x=>`<option value="${esc(x.orderNo)}" ${x.orderNo===selected?'selected':''}>${esc(x.orderNo)} • ${esc(x.customer)}</option>`).join('')}
let productImageDraft=''; let landedCostDraft={};
function handleProductImage(e){const file=e.target.files?.[0];if(!file)return;if(!['image/png','image/jpeg','image/webp'].includes(file.type)){alert('Only PNG, JPG or WEBP image allowed.');e.target.value='';return}if(file.size>2*1024*1024){alert('Product image must be under 2 MB.');e.target.value='';return}const reader=new FileReader();reader.onload=()=>{productImageDraft=reader.result;const p=document.getElementById('productImagePreview');if(p)p.innerHTML=`<img src="${productImageDraft}" class="product-preview" alt="Preview">`;};reader.readAsDataURL(file)}
function clearProductImage(){productImageDraft='';const p=document.getElementById('productImagePreview');if(p)p.innerHTML='<span class="hint">No image selected</span>';const f=document.getElementById('productImageFile');if(f)f.value='';}
function toggleCustomParentCategory(sel){const i=document.getElementById('customParentCategory');if(i){const show=sel.value==='__CUSTOM__';i.style.display=show?'block':'none';if(show)i.focus();}}
function fieldControl(f,value,key,index){let [name,label,type,opts]=f;let auto=type==='auto';let val=value??'';if(type==='date'&&!val)val=todayISO();if(key==='customers'&&name==='type'&&!val)val='B2B';if(key==='customers'&&name==='gstin'&&index===null)val=val||'';if(key==='customers'&&name==='type'&&index===null&&!val)val='Registered';if(key==='orders'&&name==='paidAmount'&&index===null)val=0;if(key==='orders'&&name==='dueAmount'&&index===null)val=Number(document.querySelector('[name=total]')?.value||0);if(key==='invoices'&&name==='paidAmount'&&index===null)val=0;if(key==='invoices'&&name==='dueAmount'&&index===null)val=0;if(auto&& !val){if(name==='orderNo')val=nextNo('ORD',key,'orderNo');if(name==='invoiceNo')val=nextNo('INV',key,'invoiceNo');if(name==='receiptNo')val=nextNo('REC',key,'receiptNo');if(name==='poNo')val=nextNo('PO',key,'poNo')}
 if(key==='products'&&name==='purchase'){const p=(index!==null&&data.products[index])||{};return `<div style="display:grid;grid-template-columns:1fr auto;gap:8px;align-items:center"><input type="number" name="purchase" id="productPurchaseCost" value="${num(p.purchase||val)}" min="0" step="0.01" readonly class="readonly"><button type="button" class="btn secondary" onclick="openLandedCostPopup()">🧮 Details</button></div><small class="hint">Click Details to enter Purchase/Landed Cost components.</small>`;}
 if(type==='parentcat'){const presets=['Toys','Games','Electronics','Stationery','Gifts','Accessories','Learning','Arts & Crafts','Other'];const isCustom=!!val&&!presets.includes(String(val));return `<div style="display:grid;gap:7px"><select name="${name}" onchange="toggleCustomParentCategory(this)"><option value="">Select parent category</option>${presets.map(x=>`<option value="${esc(x)}" ${x===String(val)&&!isCustom?'selected':''}>${esc(x)}</option>`).join('')}<option value="__CUSTOM__" ${isCustom?'selected':''}>+ Custom Parent Category</option></select><input name="customParentCategory" id="customParentCategory" value="${isCustom?esc(val):''}" placeholder="Enter custom parent category" style="display:${isCustom?'block':'none'}"></div>`;}
 if(type==='customer')return `<select name="${name}">${customerOptions(val)}</select>`;if(type==='customerType')return `<select name="${name}"><option value="Registered" ${String(val||'B2B')==='Registered'?'selected':''}>Registered</option><option value="Unregistered" ${String(val||'')==='Unregistered'?'selected':''}>Unregistered</option></select>`;
 if(type==='vendor')return `<select name="${name}">${vendorOptions(val)}</select>`;
 if(type==='order')return `<select name="${name}" onchange="paymentOrderChanged(this)">${orderOptions(val)}</select><div id="paymentOrderInfo" class="hint" style="margin-top:6px">Select an order to fetch current payment status.</div>`;
 if(key==='payments'&&name==='amount')return `<input type="number" name="${name}" value="${esc(val)}" min="0" step="0.01" oninput="paymentAmountChanged(this)"><div id="paymentAmountInfo" class="hint" style="margin-top:6px"></div>`;
 if(key==='payments'&&name==='status')return `<select id="paymentStatusDisplay" disabled><option value="Pending" ${String(val)==='Pending'?'selected':''}>Pending</option><option value="Partial" ${String(val)==='Partial'?'selected':''}>Partial</option><option value="Paid" ${String(val)==='Paid'?'selected':''}>Paid</option></select><input type="hidden" name="status" value="${esc(val||'Pending')}">`;
 if(type==='select')return `<select name="${name}">${opts.map(x=>`<option value="${esc(x)}" ${String(x)===String(val)?'selected':''}>${esc(x)}</option>`).join('')}</select>`; if(type==='gst')return `<select name="${name}">${gstOptions(val)}</select>`;
 let inputType=type==='date'?'date':type==='number'?'number':type==='tel'?'tel':'text';
 let readonly=auto?' readonly class="readonly"':'';let step=type==='number'?' step="0.01"':'';
 return `<input type="${inputType}" name="${name}" value="${esc(val)}"${readonly}${step}>${auto?'<span class="auto-badge">Auto generated</span>':''}`;
}
function openMarketplaceOrderEdit(index){
  if(!data.marketplaceOrders?.[index]) return;
  openModal('marketplaceOrders',index);
}
function removeMarketplaceOrder(index){
  const o=data.marketplaceOrders?.[index]; if(!o) return;
  const linkedSettlement=(data.marketplaceSettlements||[]).find(s=>String(s.settlementId||'')===String(o.settlementId||''));
  const msg=linkedSettlement
    ? `Remove order ${o.orderId}? The order will be removed, but settlement ${linkedSettlement.settlementId} will be kept for financial audit.`
    : `Remove order ${o.orderId}? This cannot be undone.`;
  if(!confirm(msg)) return;
  data.marketplaceOrders.splice(index,1);
  data.reconTaxFiles=(data.reconTaxFiles||[]).filter(x=>String(x.orderId||'')!==String(o.orderId||''));
  window.marketplaceOrderSelected=Math.max(0,Math.min(Number(window.marketplaceOrderSelected||0),data.marketplaceOrders.length-1));
  save(); show('marketplaceControl'); toast(`Order ${o.orderId} removed`);
}
function openModal(key,index=null){if(key==='orders'){openOrderModal(index);return}if(key==='purchases'){openPurchaseModal(index);return}if(key==='invoices'){openInvoiceModal(index);return}editing={key,index};let s=sections[key],r=index===null?{}:data[key][index];document.getElementById('modalTitle').textContent=index===null?'Add '+s.label.slice(0,-1):'Edit '+s.label.slice(0,-1);if(key==='products'){productImageDraft=r.image||'';landedCostDraft={};document.getElementById('fields').innerHTML=s.fields.map(f=>{if(f[2]==='image')return `<label class="field full"><span>Product Image</span><input id="productImageFile" type="file" accept="image/png,image/jpeg,image/webp" onchange="handleProductImage(event)"><div id="productImagePreview" class="product-image-box">${r.image?`<img src="${r.image}" class="product-preview" alt="Preview">`:'<span class="hint">No image selected</span>'}</div><button type="button" class="btn secondary" onclick="clearProductImage()">Remove Image</button><span class="hint">PNG/JPG/WEBP • Max 2 MB</span></label>`;return `<label class="field"><span>${f[1]}${f[2]==='auto'?' <span class="auto-badge">●</span>':''}</span>${fieldControl(f,r[f[0]],key,index)}</label>`}).join('');}else{document.getElementById('fields').innerHTML=s.fields.map(f=>`<label class="field"><span>${f[1]}${f[2]==='auto'?' <span class="auto-badge">●</span>':''}</span>${fieldControl(f,r[f[0]],key,index)}</label>`).join('');}const saveBtn=document.getElementById('modalSaveBtn');
if(saveBtn){
  const isProduct=key==='products';
  saveBtn.textContent=isProduct?'✓ Save Product':(index===null?'✓ Save':'✓ Update');
  saveBtn.classList.toggle('product-save-btn',isProduct);
  saveBtn.disabled=false;
}
document.getElementById('modal').classList.add('show')}
function closeModal(){document.getElementById('modal').classList.remove('show');editing=null}
document.getElementById('form').onsubmit=e=>{e.preventDefault();let target=editing.key,index=editing.index;if(target==='orders'){let old=index===null?null:data.orders[index];let calc=calcOrder();let o={orderNo:document.querySelector('[name=orderNo]').value||nextNo('ORD','orders','orderNo'),customer:document.querySelector('[name=customer]').value,date:document.querySelector('[name=date]').value||todayISO(),status:document.querySelector('[name=status]').value,items:calc.items,subtotal:calc.subtotal,discount:calc.discount,transport:calc.transport,gstAmount:calc.gstAmount,cgstAmount:calc.cgstAmount,sgstAmount:calc.sgstAmount,igstAmount:calc.igstAmount,taxType:calc.taxType,total:calc.total,paidAmount:calc.paidAmount,dueAmount:calc.dueAmount,payment:calc.payment};if(!o.customer||!o.items.length){alert('Customer and at least one in-stock product are required.');return}for(const it of o.items){let p=data.products.find(x=>x.sku===it.sku);let oldQty=old?.items?.filter(x=>x.sku===it.sku).reduce((a,x)=>a+Number(x.qty||0),0)||0;let available=Number(p?.stock||0)+oldQty;if(o.status!=='Cancelled'&&it.qty>available){alert(`${p.name} has only ${available} units available.`);return}}if(old?.items){old.items.forEach(it=>{let p=data.products.find(x=>x.sku===it.sku);if(p)p.stock=Number(p.stock||0)+Number(it.qty||0)})}if(o.status!=='Cancelled'){o.items.forEach(it=>{let p=data.products.find(x=>x.sku===it.sku);if(p)p.stock=Number(p.stock||0)-Number(it.qty||0)})}if(index===null)data.orders.push(o);else data.orders[index]=o;syncOrderPayment(o.orderNo,Number(o.paidAmount||0));let c=data.customers.find(x=>x.id===o.customer||x.name===o.customer)||{};let customerMeta={customerAddress:c.address||'',customerCity:c.city||'',customerState:c.state||'',customerPincode:c.pincode||'',customerGSTIN:c.gstin||c.GSTIN||'',customerPhone:c.phone||''};let vendorNames=[...new Set((o.items||[]).map(it=>(data.products.find(p=>p.sku===it.sku)||{}).vendor).filter(Boolean))];let primaryVendor=data.vendors.find(v=>v.name===vendorNames[0])||{};let supplierMeta={supplierName:vendorNames.join(' / '),supplierContact:vendorNames.length===1?(primaryVendor.contact||''):'',supplierPhone:vendorNames.length===1?(primaryVendor.phone||''):'',supplierAddress:vendorNames.length===1?(primaryVendor.address||''):'',supplierCity:vendorNames.length===1?(primaryVendor.city||''):'',supplierState:vendorNames.length===1?(primaryVendor.state||''):'',supplierPincode:vendorNames.length===1?(primaryVendor.pincode||''):'',supplierGSTIN:vendorNames.length===1?(primaryVendor.gstin||''):''};let inv=data.invoices.find(x=>x.orderNo===o.orderNo);if(!inv){data.invoices.push({invoiceNo:nextNo('INV','invoices','invoiceNo'),orderNo:o.orderNo,customer:o.customer,date:o.date,items:o.items,subtotal:o.subtotal,discount:o.discount,transport:o.transport,gstAmount:o.gstAmount,cgstAmount:o.cgstAmount,sgstAmount:o.sgstAmount,igstAmount:o.igstAmount,taxType:o.taxType,total:o.total,paidAmount:o.paidAmount,dueAmount:o.dueAmount,status:o.payment,...customerMeta,...supplierMeta})}else Object.assign(inv,{customer:o.customer,date:o.date,items:o.items,subtotal:o.subtotal,discount:o.discount,transport:o.transport,gstAmount:o.gstAmount,cgstAmount:o.cgstAmount,sgstAmount:o.sgstAmount,igstAmount:o.igstAmount,taxType:o.taxType,total:o.total,paidAmount:o.paidAmount,dueAmount:o.dueAmount,status:o.payment,...customerMeta,...supplierMeta});save();closeModal();show('orders');toast(index===null?'Order created and stock updated':'Order updated and stock recalculated');return}if(target==='invoices'){let orderNo=document.querySelector('[name="orderNo"]')?.value||'';let ord=data.orders.find(x=>x.orderNo===orderNo);if(!ord){alert('Please select an order. Invoice details and payment status are fetched from the selected order.');return}let t=paymentTotalsForOrder(orderNo);let inv={invoiceNo:document.querySelector('[name="invoiceNo"]').value||nextNo('INV','invoices','invoiceNo'),orderNo:ord.orderNo,customer:ord.customer,date:ord.date||todayISO(),items:ord.items||[],subtotal:Number(ord.subtotal||0),discount:Number(ord.discount||0),transport:Number(ord.transport||0),gstAmount:Number(ord.gstAmount||0),cgstAmount:Number(ord.cgstAmount||0),sgstAmount:Number(ord.sgstAmount||0),igstAmount:Number(ord.igstAmount||0),taxType:ord.taxType||'CGST_SGST',total:Number(ord.total||0),paidAmount:t.paid,dueAmount:t.due,status:t.status};if(index===null)data.invoices.push(inv);else data.invoices[index]=inv;ord.paidAmount=t.paid;ord.dueAmount=t.due;ord.payment=t.status;save();closeModal();show('invoices');toast(index===null?'Invoice created from order':'Invoice updated from order');return}if(target==='purchases'){let old=index===null?null:data.purchases[index];let calc=calcPurchase();let vendorName=document.querySelector('[name=vendor]')?.value||'';const realVendor=(data.vendors||[]).find(v=>String(v.name||'')===String(vendorName))||null;if(!realVendor||!calc.items.length){alert(!realVendor?'Please select a vendor from the Vendors master.':'Please add at least one product with quantity.');return}let o={poNo:document.querySelector('[name=poNo]').value||nextNo('PO','purchases','poNo'),vendor:vendorName,date:document.querySelector('[name=date]').value||todayISO(),items:calc.items,subtotal:calc.subtotal,discount:calc.discount,transport:calc.transport,gstAmount:calc.gstAmount,total:calc.total,status:document.querySelector('[name=status]').value||'Ordered',vendorContact:realVendor.contact||'',vendorPhone:realVendor.phone||'',vendorAddress:realVendor.address||'',vendorCity:realVendor.city||'',vendorState:realVendor.state||'',vendorPincode:realVendor.pincode||'',vendorGSTIN:realVendor.gstin||''};const stockAppliedStatuses=['Received','Partial'];if(old?.items && stockAppliedStatuses.includes(old.status)){old.items.forEach(it=>{let p=data.products.find(x=>x.sku===it.sku);if(p)p.stock=Math.max(0,Number(p.stock||0)-Number(it.qty||0))})}if(stockAppliedStatuses.includes(o.status)){o.items.forEach(it=>{let p=data.products.find(x=>x.sku===it.sku);if(p)p.stock=Number(p.stock||0)+Number(it.qty||0)})}if(index===null)data.purchases.push(o);else data.purchases[index]=o;data.products.forEach(p=>{let st=data.stock.find(x=>x.sku===p.sku);if(st)st.inStock=p.stock});save();closeModal();show('purchases');toast(index===null?'Purchase saved and stock updated':'Purchase updated and stock recalculated');return}let o={};new FormData(e.target).forEach((v,k)=>o[k]=v);if(target==='customers'){o.type=o.type==='Unregistered'?'Unregistered':'Registered';o.gstin=String(o.gstin||'').trim().toUpperCase();if(o.type==='Registered'&&!o.gstin){alert('GST Number is required for a Registered customer.');return;}if(o.type==='Registered'&&!/^\d{2}[A-Z0-9]{13}$/.test(o.gstin)){alert('Please enter a valid 15-character GSTIN for a Registered customer.');return;}if(o.type==='Unregistered')o.gstin='';}if(target==='products'){o.image=productImageDraft||((index!==null&&data.products[index]?.image)||'');let pc=String(o.parentCategory||'').trim();if(pc==='__CUSTOM__')pc=String(o.customParentCategory||'').trim();o.parentCategory=pc||'Other';delete o.customParentCategory;const oldP=index!==null?data.products[index]:{};const lc=(Object.keys(landedCostDraft).length?landedCostDraft:oldP);o.purchase=Number(o.purchase||lc.total||oldP.purchase||0);o.purchaseBase=Number(lc.purchaseBase||oldP.purchaseBase||o.purchase||0);o.purchaseDiscount=Number(lc.purchaseDiscount||oldP.purchaseDiscount||0);o.inboundFreight=Number(lc.inboundFreight||oldP.inboundFreight||0);o.loadingCost=Number(lc.loadingCost||oldP.loadingCost||0);o.inwardPackaging=Number(lc.inwardPackaging||oldP.inwardPackaging||0);o.handlingCost=Number(lc.handlingCost||oldP.handlingCost||0);o.otherInwardCost=Number(lc.otherInwardCost||oldP.otherInwardCost||0);o.inboundCost=o.inboundFreight;o.packaging=o.inwardPackaging;o.otherCost=o.otherInwardCost;landedCostDraft={};o.b2b=Number(o.b2b||0);o.mrp=Number(o.mrp||0);o.gst=o.gst==='Custom'?0:Number(o.gst||0);o.stock=Number(o.stock||0);o.reorder=Number(o.reorder||0);}if(target==='orders'&&index===null){o.orderNo=nextNo('ORD','orders','orderNo');o.date=o.date||todayISO();o.status=o.status||'Pending';o.payment=o.payment||'Pending'}if(target==='payments'){o.receiptNo=o.receiptNo||nextNo('REC','payments','receiptNo');o.date=o.date||todayISO();o.mode=o.mode||'UPI';let ord=data.orders.find(x=>x.orderNo===o.orderNo);if(!ord){alert('Please select an order for this payment.');return}let t=paymentTotalsForOrder(o.orderNo),amt=Math.max(0,Number(o.amount||0));if(amt<=0){alert('Please enter a payment amount greater than 0.');return}if(amt>t.due+0.0001){alert('Payment amount cannot be greater than the current due amount of ₹'+Number(t.due||0).toFixed(2));return}let projectedPaid=t.paid+amt,projectedDue=Math.max(0,t.total-projectedPaid);o.customer=ord.customer;o.status=projectedPaid<=0?'Pending':projectedDue<=0?'Paid':'Partial';}
 if(target==='marketplaceOrders'){
   const old=index===null?null:data.marketplaceOrders[index];
   const o={}; new FormData(e.target).forEach((v,k)=>o[k]=v);
   o.orderId=String(o.orderId||'').trim(); o.channel=o.channel||'Amazon'; o.date=o.date||todayISO(); o.qty=Number(o.qty||1);
   o.sellingPrice=Number(o.sellingPrice||0); o.gstRate=Number(o.gstRate||0); o.gstAmount=Number(o.gstAmount||0);
   o.commission=Number(o.commission||0); o.feeGst=Number(o.feeGst||0); o.shippingFee=Number(o.shippingFee||0); o.adsCost=Number(o.adsCost||0); o.returnCost=Number(o.returnCost||0); o.otherCost=Number(o.otherCost||0);
   if(!o.orderId){alert('Order ID is required.');return}
   const duplicate=data.marketplaceOrders.find((x,i)=>i!==index&&String(x.orderId||'').toLowerCase()===o.orderId.toLowerCase());
   if(duplicate){alert('This Order ID already exists. Please use a unique Order ID.');return}
   o.status=MP_STATUSES.includes(o.status)?o.status:'New'; o.paymentStatus=o.paymentStatus||'Pending';
   if(index===null)data.marketplaceOrders.push(o);else data.marketplaceOrders[index]={...old,...o};
   save();closeModal();window.marketplaceOrderSelected=index===null?data.marketplaceOrders.length-1:index;show('marketplaceControl');toast(index===null?'Marketplace order created':'Marketplace order updated');return;
 }
 if(target==='invoices'&&index===null){o.invoiceNo=nextNo('INV','invoices','invoiceNo');o.date=o.date||todayISO();o.status=o.status||'Pending'}if(target==='purchases'&&index===null){o.poNo=nextNo('PO','purchases','poNo');o.date=o.date||todayISO();o.status=o.status||'Ordered'}
 if(index===null)data[target].push(o);else data[target][index]=o;
 if(target==='payments' && o.orderNo){syncOrderPayment(o.orderNo);}
 if(target==='orders'){let inv=data.invoices.find(x=>x.orderNo===o.orderNo);if(inv){Object.assign(inv,{customer:o.customer,date:o.date,items:o.items,subtotal:o.subtotal,discount:o.discount,transport:o.transport,gstAmount:o.gstAmount,cgstAmount:o.cgstAmount,sgstAmount:o.sgstAmount,igstAmount:o.igstAmount,taxType:o.taxType,total:o.total});let t=paymentTotalsForOrder(o.orderNo);Object.assign(inv,{paidAmount:t.paid,dueAmount:t.due,status:t.status});}}
 save();closeModal();show(target);toast(index===null?'Record added automatically':'Record updated')};
function deleteSettlementRecord(i){
 const idx=Number(i);
 const s=(data.marketplaceSettlements||[])[idx];
 if(!s){alert('Settlement record not found. Please refresh the Settlements screen.');return;}
 const sid=String(s.settlementId||'').trim();
 const meta=settlementRawMeta(s);
 const files=[...meta.files];
 const fileText=files.length?`\n\nSource file(s): ${files.join(', ')}`:'';
 if(!confirm(`Delete settlement ${sid||'record'}?${fileText}\n\nSettlement record, linked imported rows and source-file entry will be removed. This action cannot be undone.`))return;
 permanentlyDeleteSettlementData(s);
 window.settlementSelected=new Set();
 save();
 show('marketplaceSettlements');
 toast(`Settlement ${sid||'record'} and linked file data deleted successfully`);
}

function del(key,i){if(key==='marketplaceSettlements'){deleteSettlementRecord(i);return;}if(!confirm('Delete this record? This action cannot be undone.'))return;if(key==='purchases'){let r=data.purchases[i];if(r?.status==='Received'){(r.items||[]).forEach(it=>{let p=data.products.find(x=>x.sku===it.sku);if(p)p.stock=Math.max(0,Number(p.stock||0)-Number(it.qty||0))})}}if(key==='orders'){let r=data.orders[i];if(r?.status!=='Cancelled'){(r.items||[]).forEach(it=>{let p=data.products.find(x=>x.sku===it.sku);if(p)p.stock=Number(p.stock||0)+Number(it.qty||0)})}data.invoices=data.invoices.filter(x=>x.orderNo!==r.orderNo);data.payments=data.payments.filter(x=>x.orderNo!==r.orderNo)}data[key].splice(i,1);save();show(key);toast('Record deleted and linked totals/stock updated')}
function reportMoney(n){return '₹'+Number(n||0).toLocaleString('en-IN',{minimumFractionDigits:0,maximumFractionDigits:2})}
function reportDate(v){return String(v||'').slice(0,10)}
function reportInRange(v,from,to){let d=reportDate(v);return (!from||d>=from)&&(!to||d<=to)}
function reportRows(headers,rows){return `<div class="panel"><div style="overflow:auto"><table class="table"><thead><tr>${headers.map(h=>`<th>${h}</th>`).join('')}</tr></thead><tbody>${rows.length?rows.map(r=>`<tr>${r.map(x=>`<td>${x}</td>`).join('')}</tr>`).join(''):`<tr><td colspan="${headers.length}">No data for selected period.</td></tr>`}</tbody></table></div></div>`}
function gstr1Dashboard(){
 const f=window.gstr1Filters||{month:'',from:'',to:'',applied:false};
 return `<div class="reporthero"><div style="display:flex;justify-content:space-between;gap:18px;align-items:center;flex-wrap:wrap"><div><h2>🧾 GST Reports</h2><div style="opacity:.9">GSTR-1 outward supplies report</div></div><div class="quick"><button class="btn secondary" onclick="show('pnlDashboard')">📈 Profit & Loss</button><button class="btn" onclick="show('reports')">📊 Reports</button></div></div></div><div class="panel"><h3>GST Report Filters</h3><div class="hint" style="margin-bottom:10px">Select the reporting month or date range, then click Apply Filter.</div><div class="finance-filters"><label class="field"><span>Month-wise</span><input id="gstMonthFilter" type="month" value="${esc(f.month||'')}"></label><label class="field"><span>From Date</span><input id="gstFromDate" type="date" value="${esc(f.from||'')}"></label><label class="field"><span>To Date</span><input id="gstToDate" type="date" value="${esc(f.to||'')}"></label><button class="btn" onclick="applyGSTR1Filters()">🔎 Apply Filter</button><button class="btn secondary" onclick="resetGSTR1Filters()">Reset & Lock Data</button></div></div><div id="gstr1DashboardOutput">${f.applied===true?gstr1Report():'<div class="panel"><div class="filter-lock-panel"><strong>🔒 GST report locked</strong><div class="hint">Select a month or From/To Date and click Apply Filter.</div></div></div>'}</div>`;
}
function gstr1StateCode(customer){
 const c=data.customers.find(x=>x.id===customer||x.name===customer)||{};
 const gstin=String(c.gstin||c.GSTIN||'').trim().toUpperCase();
 if(/^\\d{2}/.test(gstin)) return gstin.slice(0,2);
 const map={Andhra:'37',Arunachal:'12',Assam:'18',Bihar:'10',Chhattisgarh:'22',Delhi:'07',Goa:'30',Gujarat:'24',Haryana:'06','Himachal Pradesh':'02',Jharkhand:'20',Karnataka:'29',Kerala:'32','Madhya Pradesh':'23','Maharashtra':'27',Manipur:'14',Meghalaya:'17',Mizoram:'15',Nagaland:'13',Odisha:'21',Punjab:'03',Rajasthan:'08',Sikkim:'11','Tamil Nadu':'33',Telangana:'36',Tripura:'16','Uttar Pradesh':'09','Uttarakhand':'05','West Bengal':'19'};
 const st=String(c.state||'').trim(); return Object.keys(map).find(k=>st.toLowerCase().includes(k.toLowerCase()))?map[Object.keys(map).find(k=>st.toLowerCase().includes(k.toLowerCase()))]:'';
}
function gstr1TaxRows(orders){
 const out=[]; orders.forEach(o=>{const c=data.customers.find(x=>x.id===o.customer||x.name===o.customer)||{};const gstin=String(c.gstin||c.GSTIN||'').trim().toUpperCase();const pos=gstrPOSDisplay(gstr1StateCode(o.customer)||String(cfg.state||'').trim());const items=o.items||[];items.forEach(it=>{const base=Number(it.qty||0)*Number(it.rate||0);const tax=base*Number(it.gst||0)/100;const cg=o.taxType==='CGST_SGST'?tax/2:0,sg=o.taxType==='CGST_SGST'?tax/2:0,ig=o.taxType==='IGST'?tax:0;out.push({o,c,gstin,pos,it,base,tax,cg,sg,ig});});});return out;
}
function gstr1Report(){
 const from=document.getElementById('reportFrom')?.value||'',to=document.getElementById('reportTo')?.value||'';
 const orders=data.orders.filter(o=>reportInRange(o.date,from,to)&&String(o.status||'')!=='Cancelled');
 const rows=gstr1TaxRows(orders);
 const supplierCode=String(cfg.businessGSTIN||cfg.gstin||'').slice(0,2)||'';
 const getCustomer=o=>data.customers.find(x=>x.id===o.customer||x.name===o.customer)||{};
 const getGSTIN=o=>{const c=getCustomer(o);return String(c.type||'Registered')==='Unregistered'?'':String(c.gstin||c.GSTIN||'').trim().toUpperCase();};
 const getPOS=o=>gstr1StateCode(o.customer)||'';
 const taxable=o=>Math.max(0,Number(o.subtotal||0)-Number(o.discount||0));
 // GSTR-1 from Aug-2024: B2C Large = unregistered inter-state invoice value > Rs 1 lakh.
 // Table 7 B2C Others = all intra-state supplies to unregistered customers + inter-state invoices <= Rs 1 lakh, consolidated by POS/rate.
 const b2b=orders.filter(o=>!!getGSTIN(o));
 const b2cl=orders.filter(o=>!getGSTIN(o)&&o.taxType==='IGST'&&Number(o.total||0)>100000);
 const b2cOthers=orders.filter(o=>!getGSTIN(o)&&!b2cl.includes(o));
 const b2bRows=b2b.map(o=>{const c=getCustomer(o);return [esc(getGSTIN(o)),esc(c.name||o.customer||''),esc(o.invoiceNo||data.invoices.find(i=>i.orderNo===o.orderNo)?.invoiceNo||''),esc(o.date||''),esc(getPOS(o)),reportMoney(o.total),reportMoney(taxable(o)),reportMoney(o.cgstAmount),reportMoney(o.sgstAmount),reportMoney(o.igstAmount)];});
 const b2clRows=b2cl.map(o=>[esc(o.invoiceNo||data.invoices.find(i=>i.orderNo===o.orderNo)?.invoiceNo||''),esc(o.date||''),esc(getPOS(o)),reportMoney(o.total),reportMoney(taxable(o)),reportMoney(o.igstAmount)]);
 // Build Table 7 from individual line items, then consolidate by Place of Supply + GST rate + tax type.
 // This avoids assuming that every item in an order has the first item's GST rate.
 const b2cMap={}; const missingPos=[];
 b2cOthers.forEach(o=>{
   const pos=getPOS(o); const isIGST=o.taxType==='IGST';
   if(isIGST&&!pos){missingPos.push(o);return;}
   const effectivePos=pos||supplierCode;
   (o.items||[]).forEach(it=>{
     const rate=Number(it.gst||0); const base=Number(it.qty||0)*Number(it.rate||0);
     // Nil/exempt/non-GST supplies belong to the corresponding nil/exempt reporting, not Table 7 taxable supplies.
     if(rate<=0||base<=0)return;
     const tax=base*rate/100;
     const cg=!isIGST?tax/2:0, sg=!isIGST?tax/2:0, ig=isIGST?tax:0;
     const k=effectivePos+'|'+rate+'|'+(isIGST?'IGST':'CGST_SGST');
     if(!b2cMap[k])b2cMap[k]={pos:effectivePos,rate,taxable:0,cgst:0,sgst:0,igst:0,tax:0,invoiceCount:0,invoiceSet:new Set()};
     const x=b2cMap[k]; x.taxable+=base; x.cgst+=cg; x.sgst+=sg; x.igst+=ig; x.tax+=tax; x.invoiceSet.add(o.orderNo||o.invoiceNo||''); x.invoiceCount=x.invoiceSet.size;
   });
 });
 const b2cRows=Object.values(b2cMap).sort((a,b)=>String(a.pos).localeCompare(String(b.pos))||a.rate-b.rate).map(x=>[esc(x.pos),x.rate+'%',reportMoney(x.taxable),reportMoney(x.cgst),reportMoney(x.sgst),reportMoney(x.igst),reportMoney(x.tax),x.invoiceCount]);
 const hsnMap={};rows.forEach(r=>{const h=String(r.it.hsn||'').trim()||'NOT-ENTERED';const rate=Number(r.it.gst||0);const k=h+'|'+rate;if(!hsnMap[k])hsnMap[k]={hsn:h,rate,qty:0,taxable:0,tax:0};hsnMap[k].qty+=Number(r.it.qty||0);hsnMap[k].taxable+=r.base;hsnMap[k].tax+=r.tax;});
 const hsnRows=Object.values(hsnMap).map(x=>[esc(x.hsn),x.rate+'%',x.qty,reportMoney(x.taxable),reportMoney(x.tax/2),reportMoney(x.tax/2),reportMoney(x.tax)]);
 const missingHsn=rows.filter(r=>!String(r.it.hsn||'').trim()).length;
 const docs=orders.map(o=>[esc(o.invoiceNo||data.invoices.find(i=>i.orderNo===o.orderNo)?.invoiceNo||''),esc(o.date||''),'Invoice',esc(o.status||'')]);
 const totalSales=orders.reduce((a,o)=>a+Number(o.total||0),0),totalTax=orders.reduce((a,o)=>a+Number(o.gstAmount||0),0);
 const posWarning=missingPos.length?`<div class="alertbox warn"><b>Table 7 POS missing:</b> ${missingPos.length} inter-state B2C invoice(s) have no customer state/POS. Add the customer's State or GSTIN so the report can classify them correctly.</div>`:'';
 return `<div class="reporthero"><h2>GSTR-1 Outward Supplies Report</h2><div style="opacity:.9">Tax-period report prepared from Gezeno invoices/orders • ${esc(from||'All')} to ${esc(to||'All')}</div><div style="margin-top:10px;font-size:12px;opacity:.85">Table 7 is automatically consolidated by POS + GST rate. Review the data before statutory filing.</div></div><div class="reportkpis"><div class="rkpi"><div class="label">B2B INVOICES</div><div class="value">${b2b.length}</div></div><div class="rkpi"><div class="label">B2C LARGE</div><div class="value">${b2cl.length}</div></div><div class="rkpi"><div class="label">B2C OTHERS INVOICES</div><div class="value">${b2cOthers.length}</div></div><div class="rkpi"><div class="label">TABLE 7 CONSOLIDATED LINES</div><div class="value">${b2cRows.length}</div></div><div class="rkpi"><div class="label">GST</div><div class="value">${reportMoney(totalTax)}</div></div></div>${posWarning}${missingHsn?`<div class="alertbox warn"><b>HSN/SAC data missing:</b> ${missingHsn} item line(s) do not have HSN/SAC. Add HSN/SAC in Products master before relying on the HSN summary.</div>`:''}<div class="panel"><h3>Table 4A/4B/6B/6C — B2B</h3>${reportRows(['GSTIN','Recipient','Invoice No.','Date','POS','Invoice Value','Taxable Value','CGST','SGST','IGST'],b2bRows)}</div><div class="panel"><h3>Table 5A/5B — B2C Large (&gt; ₹1,00,000, inter-state)</h3>${reportRows(['Invoice No.','Date','POS','Invoice Value','Taxable Value','IGST'],b2clRows)}</div><div class="panel"><h3>Table 7 — B2C Others (automatic consolidated)</h3>${reportRows(['POS','Rate','Taxable Value','CGST','SGST','IGST','Total Tax','Invoices'],b2cRows)}</div><div class="panel"><h3>Table 12 — HSN-wise Summary</h3>${reportRows(['HSN/SAC','Rate','Qty','Taxable Value','CGST','SGST','Total Tax'],hsnRows)}</div><div class="panel"><h3>Table 13 — Documents Issued</h3>${reportRows(['Invoice No.','Date','Document Type','Status'],docs)}</div><div class="panel"><h3>Not currently populated</h3><div class="hint">Exports, credit/debit notes, amendments and ECO-specific tables require dedicated transaction fields that are not present in the current business data.</div></div>`;
}
function applyReportMonth(){
 const m=document.getElementById('reportMonth')?.value||'';
 if(!m)return;
 const [y,mo]=m.split('-').map(Number);
 const last=new Date(y,mo,0).getDate();
 document.getElementById('reportFrom').value=`${y}-${String(mo).padStart(2,'0')}-01`;
 document.getElementById('reportTo').value=`${y}-${String(mo).padStart(2,'0')}-${String(last).padStart(2,'0')}`;
}
function resetReportFilters(){
 ['reportMonth','reportFrom','reportTo'].forEach(id=>{const e=document.getElementById(id);if(e)e.value=''});
 const out=document.getElementById('reportOutput');if(out)out.innerHTML='<div class="filter-lock-panel"><div><strong>🔒 Report locked until a date filter is applied</strong>Select a month or From/To date, then tap Generate Report.</div></div>';
}
function applyGSTR1Filters(){
 const month=document.getElementById('gstMonthFilter')?.value||'';
 const from=document.getElementById('gstFromDate')?.value||'';
 const to=document.getElementById('gstToDate')?.value||'';
 if(!month&&!from&&!to){toast('Please select a reporting month or date range first');return}
 if(!month&&((from&&!to)||(!from&&to))){toast('Please select both From Date and To Date');return}
 if(!month&&from&&to&&from>to){toast('From Date cannot be after To Date');return}
 window.gstr1Filters={marketplace:document.getElementById('gstMarketplaceFilter')?.value||'All',state:document.getElementById('gstStateFilter')?.value||'All',rate:document.getElementById('gstRateFilter')?.value||'All',nature:document.getElementById('gstNatureFilter')?.value||'All',search:document.getElementById('gstSearch')?.value||'',month,from,to,applied:true};
 show('gstr1')
}
function resetGSTR1Filters(){window.gstr1Filters={marketplace:'All',state:'All',rate:'All',nature:'All',search:'',month:'',from:'',to:'',applied:false};show('gstr1')}
function generateReport(){
 const type=document.getElementById('reportType')?.value||'summary';
 const from=document.getElementById('reportFrom')?.value||'';
 const to=document.getElementById('reportTo')?.value||'';
 const marketplace=document.getElementById('reportMarketplace')?.value||'All';
 const inRange=d=>reportInRange(d,from,to);
 const channelMatch=o=>marketplace==='All'||String(o?.channel||o?.marketplace||o?.sourceMarketplace||'').trim().toLowerCase()===marketplace.toLowerCase();
 const orderRows=(data.marketplaceOrders||[]).filter(o=>inRange(o.date)&&String(o.status||'')!=='Cancelled'&&channelMatch(o));
 const settlementRows=(data.marketplaceSettlements||[]).filter(x=>inRange(x.receivedDate||x.toDate||x.fromDate)&&channelMatch(x));
 const returnRows=(data.marketplaceReturns||[]).filter(x=>inRange(x.date)&&channelMatch(x));
 const adRows=(data.marketplaceAds||[]).filter(x=>inRange(x.date)&&channelMatch(x));
 const legacyOrders=(data.orders||[]).filter(o=>inRange(o.date)&&String(o.status||'')!=='Cancelled'&&channelMatch(o));
 const orders=(data.marketplaceOrders||[]).length?orderRows:legacyOrders;
 const purchases=(data.purchases||[]).filter(p=>inRange(p.date)&&String(p.status||'')!=='Cancelled'&&(marketplace==='All'||channelMatch(p)));
 const payments=(data.payments||[]).filter(p=>inRange(p.date)&&String(p.status||'')!=='Pending'&&channelMatch(p));
 const money=v=>reportMoney(Number(v||0)); const qty=o=>Math.max(1,Number(o?.qty||1));
 const grossOrders=orders.reduce((a,o)=>a+Number(o.sellingPrice||o.total||0)*qty(o),0);
 const settlementGross=settlementRows.reduce((a,x)=>a+Number(x.gross||0),0);
 const gross=settlementGross||grossOrders;
 const salesGst=settlementRows.reduce((a,x)=>a+Number(x.salesGst||0),0)||orders.reduce((a,o)=>a+Number(o.gstAmount||0),0);
 const fees=settlementRows.reduce((a,x)=>a+Number(x.fees||0),0), feeGst=settlementRows.reduce((a,x)=>a+Number(x.feeGst||0),0);
 const tcs=settlementRows.reduce((a,x)=>a+Number(x.tcs||0),0), tds=settlementRows.reduce((a,x)=>a+Number(x.tds||0),0);
 const refunds=settlementRows.reduce((a,x)=>a+Number(x.refunds||0),0)+returnRows.reduce((a,x)=>a+Number(x.refund||x.amount||0),0);
 const shipping=settlementRows.reduce((a,x)=>a+Number(x.shipping||0),0)||orders.reduce((a,o)=>a+Number(o.shippingFee||o.shipping||0),0);
 const ads=adRows.reduce((a,x)=>a+Number(x.spend||x.amount||0),0)||orders.reduce((a,o)=>a+Number(o.adsCost||0),0);
 const expected=settlementRows.reduce((a,x)=>a+Number(x.gross||0)-Number(x.fees||0)-Number(x.tcs||0)-Number(x.tds||0)-Number(x.refunds||0)-Number(x.shipping||0)-Number(x.otherDeductions||0)+Number(x.adjustments||0),0);
 const actual=settlementRows.reduce((a,x)=>a+Number(x.netReceived||0),0);
 const bankCredit=(data.bankTransactions||[]).filter(x=>inRange(x.date)).reduce((a,x)=>a+Number(x.credit||0),0);
 const taxable=Math.max(0,gross-salesGst);
 const cogs=orders.reduce((a,o)=>{const p=data.products?.find(x=>x.sku===o.sku);return a+Number(p?.purchase||0)*qty(o)},0);
 const operatingProfit=taxable-cogs-Math.max(0,fees-feeGst)-shipping-ads-refunds;
 let html='';
 if(type==='summary'){
  html=`<div class="reportkpis"><div class="rkpi"><div class="label">GROSS SALES</div><div class="value">${money(gross)}</div></div><div class="rkpi"><div class="label">ORDERS</div><div class="value">${orders.length}</div></div><div class="rkpi"><div class="label">EXPECTED SETTLEMENT</div><div class="value">${money(expected)}</div></div><div class="rkpi"><div class="label">ACTUAL RECEIVED</div><div class="value">${money(actual)}</div></div><div class="rkpi"><div class="label">BANK CREDITS</div><div class="value">${money(bankCredit)}</div></div></div>`;
  html+=`<div class="reportgrid"><div class="reportmini"><h3>Marketplace Financial Summary</h3>${reportRows(['Metric','Amount'],[['Gross Sales',money(gross)],['Sales GST',money(salesGst)],['Taxable Sales',money(taxable)],['Marketplace Fees',money(fees)],['Fee GST / ITC',money(feeGst)],['TCS',money(tcs)],['TDS',money(tds)],['Refunds',money(refunds)],['Shipping',money(shipping)],['Ads',money(ads)],['Expected Settlement',money(expected)],['Actual Received',money(actual)],['Settlement Difference',money(actual-expected)],['Operating Profit',money(operatingProfit)]])}</div><div class="reportmini"><h3>Marketplace-wise</h3>${reportRows(['Marketplace','Orders','Sales','Fees','Received'],['Amazon','Flipkart','Meesho'].filter(ch=>marketplace==='All'||marketplace===ch).map(ch=>{const os=orders.filter(o=>o.channel===ch),ss=settlementRows.filter(x=>x.channel===ch);return [ch,os.length,money(ss.reduce((a,x)=>a+Number(x.gross||0),0)||os.reduce((a,o)=>a+Number(o.sellingPrice||o.total||0)*qty(o),0)),money(ss.reduce((a,x)=>a+Number(x.fees||0),0)),money(ss.reduce((a,x)=>a+Number(x.netReceived||0),0))]}))}</div></div>`;
 } else if(type==='sales') html=reportRows(['Order ID','Marketplace','Date','SKU','Qty','Selling Price','GST','Status'],orders.map(o=>[o.orderId||o.orderNo||'',o.channel||o.marketplace||'',o.date||'',o.sku||'',o.qty||1,money(Number(o.sellingPrice||o.total||0)*qty(o)),money(o.gstAmount),o.status||'']));
 else if(type==='purchase') html=reportRows(['PO No.','Date','Marketplace','Vendor','Total','GST','Status'],purchases.map(p=>[p.poNo||'',p.date||'',p.channel||p.marketplace||'',p.vendor||'',money(p.total),money(p.gstAmount),p.status||'']));
 else if(type==='payments') {
  if(settlementRows.length) html=reportRows(['Settlement ID','Marketplace','Settlement Date','Gross','Fees','TCS','TDS','Refunds','Shipping','Expected','Actual','UTR','Status'],settlementRows.map(x=>[x.settlementId||x.id||'',x.channel||'',x.receivedDate||x.toDate||x.fromDate||'',money(x.gross),money(x.fees),money(x.tcs),money(x.tds),money(x.refunds),money(x.shipping),money(Number(x.gross||0)-Number(x.fees||0)-Number(x.tcs||0)-Number(x.tds||0)-Number(x.refunds||0)-Number(x.shipping||0)-Number(x.otherDeductions||0)+Number(x.adjustments||0)),money(x.netReceived),x.utr||x.reference||'',x.status||'']));
  else html=reportRows(['Receipt','Date','Marketplace','Customer','Order','Mode','Amount','Status'],payments.map(p=>[p.receiptNo||'',p.date||'',p.channel||p.marketplace||'',p.customer||'',p.orderNo||'',p.mode||'',money(p.amount),p.status||'']));
 } else if(type==='dues') {
  html=reportRows(['Marketplace','Orders','Expected Settlement','Actual Received','Difference'],['Amazon','Flipkart','Meesho'].filter(ch=>marketplace==='All'||marketplace===ch).map(ch=>{const os=orders.filter(o=>o.channel===ch),ss=settlementRows.filter(x=>x.channel===ch);const e=ss.reduce((a,x)=>a+Number(x.gross||0)-Number(x.fees||0)-Number(x.tcs||0)-Number(x.tds||0)-Number(x.refunds||0)-Number(x.shipping||0)-Number(x.otherDeductions||0)+Number(x.adjustments||0),0),r=ss.reduce((a,x)=>a+Number(x.netReceived||0),0);return[ch,os.length,money(e),money(r),money(r-e)]}));
 } else if(type==='gst') html=reportRows(['Tax Component','Amount'],[['Sales GST',money(salesGst)],['Fee GST / ITC',money(feeGst)],['Net GST after Fee ITC',money(salesGst-feeGst)],['TCS',money(tcs)],['TDS',money(tds)]]);
 else if(type==='stock') {
  const products=(data.products||[]).filter(p=>marketplace==='All'||channelMatch(p)||(data.marketplaceListings||[]).some(l=>l.sku===p.sku&&String(l.channel||l.marketplace||'').toLowerCase()===marketplace.toLowerCase()));
  html=reportRows(['SKU','Product','Category','Vendor','Qty','Reorder','Stock Value','Status'],products.map(p=>[p.sku||'',p.name||'',p.category||'',p.vendor||'',p.stock||0,p.reorder||0,money(Number(p.stock||0)*Number(p.purchase||0)),Number(p.stock||0)<=Number(p.reorder||0)?'<span class="badge orange">Reorder</span>':'<span class="badge green">OK</span>']));
 } else if(type==='customers') html=reportRows(['Marketplace','Orders','Sales'],['Amazon','Flipkart','Meesho'].filter(ch=>marketplace==='All'||marketplace===ch).map(ch=>{const os=orders.filter(o=>o.channel===ch);return[ch,os.length,money(os.reduce((a,o)=>a+Number(o.sellingPrice||o.total||0)*qty(o),0))]}));
 else if(type==='vendors') {const map={};purchases.forEach(p=>{let k=p.vendor||'Unknown';map[k]=(map[k]||0)+Number(p.total||0)});html=reportRows(['Vendor','Marketplace','Purchases'],Object.entries(map).sort((a,b)=>b[1]-a[1]).map(x=>[x[0],marketplace,money(x[1])]));}
 else if(type==='gstr1') {
  const rows=[]; orders.forEach(o=>{hydrateOrderHSN(o);const c=(data.customers||[]).find(x=>x.id===o.customer||x.name===o.customer)||{};const gstin=String(c.gstin||c.GSTIN||'').trim();const pos=gstrPOSDisplay(gstr1StateCode(o.customer)||c.state||o.deliveryState||'');const hsn=[...new Set((o.items||[]).map(it=>resolveHSN(it)).filter(Boolean))].join(' | ');rows.push([gstin?'B2B':'B2C',o.invoiceNo||o.orderNo||o.orderId||'',o.date||'',c.name||o.customer||'',gstin,pos,hsn,money(o.total||o.sellingPrice),money(Math.max(0,Number(o.subtotal||0)-Number(o.discount||0))),money(o.cgstAmount),money(o.sgstAmount),money(o.igstAmount)]);});html=reportRows(['Section','Invoice No','Date','Customer','GSTIN','POS','HSN/SAC','Invoice Value','Taxable Value','CGST','SGST','IGST'],rows);}
 if(!html) html='<div class="alertbox warn"><b>No data found for this report.</b> Check the selected date range, Marketplace and imported files.</div>';
 document.getElementById('reportOutput').innerHTML=html; window.currentReport={type,from,to,marketplace,html};
}

function resolveHSN(item){
 const raw=item||{};
 const direct=String(raw.hsn||raw.hsnCode||raw.hsnSac||raw.hsn_sac||'').trim();
 if(direct)return direct;
 const sku=String(raw.sku||raw.productSku||'').trim();
 if(sku){const p=data.products.find(x=>String(x.sku||'')===sku);if(p)return String(p.hsn||p.hsnCode||p.hsnSac||p.hsn_sac||'').trim();}
 const name=String(raw.name||raw.product||'').trim();
 if(name){const p=data.products.find(x=>String(x.name||'').trim()===name);if(p)return String(p.hsn||p.hsnCode||p.hsnSac||p.hsn_sac||'').trim();}
 return '';
}
function hydrateOrderHSN(order){(order.items||[]).forEach(it=>{const h=resolveHSN(it);if(h)it.hsn=h;});return order;}

function exportCurrentReportCSV(){
 const type=document.getElementById('reportType')?.value||'summary',from=document.getElementById('reportFrom')?.value||'',to=document.getElementById('reportTo')?.value||'',marketplace=document.getElementById('reportMarketplace')?.value||'All';
 const inRange=d=>reportInRange(d,from,to); const channelMatch=o=>marketplace==='All'||String(o?.channel||o?.marketplace||o?.sourceMarketplace||'').trim().toLowerCase()===marketplace.toLowerCase();
 const orders=(data.marketplaceOrders||[]).filter(o=>inRange(o.date)&&o.status!=='Cancelled'&&channelMatch(o));
 const settlements=(data.marketplaceSettlements||[]).filter(x=>inRange(x.receivedDate||x.toDate||x.fromDate)&&channelMatch(x));
 const purchases=(data.purchases||[]).filter(p=>inRange(p.date,from,to)&&p.status!=='Cancelled'&&(marketplace==='All'||channelMatch(p)));
 const rows=[]; const q=o=>Math.max(1,Number(o?.qty||1));
 if(type==='sales') rows.push(['Order ID','Marketplace','Date','SKU','Qty','Selling Price','GST','Status'],...orders.map(o=>[o.orderId||o.orderNo||'',o.channel||o.marketplace||'',o.date||'',o.sku||'',o.qty||1,Number(o.sellingPrice||o.total||0)*q(o),Number(o.gstAmount||0),o.status||'']));
 else if(type==='purchase') rows.push(['PO No','Date','Marketplace','Vendor','GST','Total','Status'],...purchases.map(p=>[p.poNo||'',p.date||'',p.channel||p.marketplace||'',p.vendor||'',Number(p.gstAmount||0),Number(p.total||0),p.status||'']));
 else if(type==='payments') rows.push(['Settlement ID','Marketplace','Settlement Date','Gross','Fees','TCS','TDS','Refunds','Shipping','Expected','Actual','UTR','Status'],...settlements.map(x=>[x.settlementId||x.id||'',x.channel||'',x.receivedDate||x.toDate||x.fromDate||'',Number(x.gross||0),Number(x.fees||0),Number(x.tcs||0),Number(x.tds||0),Number(x.refunds||0),Number(x.shipping||0),Number(x.gross||0)-Number(x.fees||0)-Number(x.tcs||0)-Number(x.tds||0)-Number(x.refunds||0)-Number(x.shipping||0)-Number(x.otherDeductions||0)+Number(x.adjustments||0),Number(x.netReceived||0),x.utr||x.reference||'',x.status||'']));
 else if(type==='gstr1'){rows.push(['Section','Invoice No','Date','Customer','GSTIN','POS','HSN/SAC','Invoice Value','Taxable Value','CGST','SGST','IGST']);orders.forEach(o=>{hydrateOrderHSN(o);const c=(data.customers||[]).find(x=>x.id===o.customer||x.name===o.customer)||{};rows.push([String(c.gstin||c.GSTIN||'').trim()?'B2B':'B2C',o.invoiceNo||o.orderNo||o.orderId||'',o.date||'',c.name||o.customer||'',c.gstin||c.GSTIN||'',gstrPOSDisplay(gstr1StateCode(o.customer)||c.state||o.deliveryState||''),[...new Set((o.items||[]).map(it=>resolveHSN(it)).filter(Boolean))].join(' | '),Number(o.total||o.sellingPrice||0),Math.max(0,Number(o.subtotal||0)-Number(o.discount||0)),Number(o.cgstAmount||0),Number(o.sgstAmount||0),Number(o.igstAmount||0)]);});}
 else if(type==='gst'){const sg=orders.reduce((a,o)=>a+Number(o.gstAmount||0),0),fg=settlements.reduce((a,x)=>a+Number(x.feeGst||0),0);rows.push(['Tax Component','Amount'],['Sales GST',sg],['Fee GST / ITC',fg],['Net GST after Fee ITC',sg-fg],['TCS',settlements.reduce((a,x)=>a+Number(x.tcs||0),0)],['TDS',settlements.reduce((a,x)=>a+Number(x.tds||0),0)]);}
 else if(type==='stock'){rows.push(['SKU','Product','Category','Vendor','Qty','Reorder','Stock Value','Status'],...(data.products||[]).filter(p=>marketplace==='All'||channelMatch(p)||(data.marketplaceListings||[]).some(l=>l.sku===p.sku&&String(l.channel||l.marketplace||'').toLowerCase()===marketplace.toLowerCase())).map(p=>[p.sku||'',p.name||'',p.category||'',p.vendor||'',Number(p.stock||0),Number(p.reorder||0),Number(p.stock||0)*Number(p.purchase||0),Number(p.stock||0)<=Number(p.reorder||0)?'Reorder':'OK']));}
 else if(type==='customers') rows.push(['Marketplace','Orders','Sales'],...['Amazon','Flipkart','Meesho'].filter(ch=>marketplace==='All'||marketplace===ch).map(ch=>{const os=orders.filter(o=>o.channel===ch);return[ch,os.length,os.reduce((a,o)=>a+Number(o.sellingPrice||o.total||0)*q(o),0)]}));
 else if(type==='dues') rows.push(['Marketplace','Orders','Expected Settlement','Actual Received','Difference'],...['Amazon','Flipkart','Meesho'].filter(ch=>marketplace==='All'||marketplace===ch).map(ch=>{const ss=settlements.filter(x=>x.channel===ch),e=ss.reduce((a,x)=>a+Number(x.gross||0)-Number(x.fees||0)-Number(x.tcs||0)-Number(x.tds||0)-Number(x.refunds||0)-Number(x.shipping||0)-Number(x.otherDeductions||0)+Number(x.adjustments||0),0),r=ss.reduce((a,x)=>a+Number(x.netReceived||0),0);return[ch,orders.filter(o=>o.channel===ch).length,e,r,r-e]}));
 else rows.push(['Report','Marketplace','From','To'],[type,marketplace,from,to]);
 const csv=rows.map(r=>r.map(v=>`"${String(v??'').replaceAll('"','""')}"`).join(',')).join('\n');const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8'}));a.download=`gezeno-${type}-${marketplace.toLowerCase()}-report-${from||'all'}-${to||'all'}.csv`;a.click();
}

function printCurrentReport(){const el=document.getElementById('reportOutput');if(!el||!el.innerHTML){generateReport();}const w=window.open('','_blank');if(!w)return;w.document.write(`<html><head><title>Gezeno Report</title><style>body{font-family:Arial;padding:25px}table{width:100%;border-collapse:collapse}th,td{padding:8px;border:1px solid #ddd;text-align:left}.cards{display:flex;gap:15px}.card{border:1px solid #ddd;padding:15px;margin-bottom:15px}.num{font-size:22px;font-weight:bold}</style></head><body><h1>${esc(cfg.brand||'Gezeno')} Report</h1><p>${esc(document.getElementById('reportType')?.value||'summary')} | ${esc(document.getElementById('reportFrom')?.value||'')} to ${esc(document.getElementById('reportTo')?.value||'')}</p>${document.getElementById('reportOutput')?.innerHTML||''}</body></html>`);w.document.close();setTimeout(()=>w.print(),250)}
function premiumReportDashboard(){
 const from=document.getElementById('reportFrom')?.value||'',to=document.getElementById('reportTo')?.value||'';
 const orders=data.orders.filter(o=>reportInRange(o.date,from,to)&&String(o.status||'')!=='Cancelled');
 const purchases=data.purchases.filter(p=>reportInRange(p.date,from,to)&&String(p.status||'')!=='Cancelled');
 const payments=data.payments.filter(p=>reportInRange(p.date,from,to)&&String(p.status||'')!=='Pending');
 const sales=orders.reduce((a,o)=>a+Number(o.total||0),0), collection=payments.reduce((a,p)=>a+Number(p.amount||0),0), purchase=purchases.reduce((a,p)=>a+Number(p.total||0),0), due=orders.reduce((a,o)=>a+Math.max(0,Number(o.dueAmount||0)),0), gst=orders.reduce((a,o)=>a+Number(o.gstAmount||0),0);
 const marginBase=orders.reduce((sum,o)=>sum+(o.items||[]).reduce((z,it)=>{let p=data.products.find(x=>x.sku===it.sku);return z+Number(it.qty||0)*(Number(it.rate||0)-Number(p?.purchase||0))},0),0);
 const customerMap={},productMap={},vendorMap={}; orders.forEach(o=>{let k=o.customer||'Unknown';customerMap[k]=(customerMap[k]||0)+Number(o.total||0);(o.items||[]).forEach(it=>{let n=it.name||it.sku||'Product';productMap[n]=(productMap[n]||0)+Number(it.qty||0)})}); purchases.forEach(p=>{let k=p.vendor||'Unknown';vendorMap[k]=(vendorMap[k]||0)+Number(p.total||0)});
 const top=(m,money)=>Object.entries(m).sort((a,b)=>b[1]-a[1]).slice(0,5).map((x,i)=>`<div class="rankrow"><span><b>${i+1}.</b> ${esc(x[0])}</span><strong>${money?reportMoney(x[1]):Number(x[1]).toLocaleString('en-IN')}</strong></div>`).join('')||'<div class="hint">No data</div>';
 const low=data.products.filter(p=>Number(p.stock||0)<=Number(p.reorder||0)).slice(0,6);
 return `<div class="reporthero"><h2>Premium Business Intelligence</h2><div style="opacity:.9">Executive view of sales, collection, GST, purchases, margin and inventory.</div></div><div class="reportkpis"><div class="rkpi"><div class="label">NET SALES</div><div class="value">${reportMoney(sales)}</div></div><div class="rkpi"><div class="label">COLLECTION</div><div class="value">${reportMoney(collection)}</div></div><div class="rkpi"><div class="label">OUTSTANDING</div><div class="value">${reportMoney(due)}</div></div><div class="rkpi"><div class="label">PURCHASES</div><div class="value">${reportMoney(purchase)}</div></div><div class="rkpi"><div class="label">EST. GROSS MARGIN</div><div class="value">${reportMoney(marginBase)}</div></div></div><div class="cards"><div class="card">Orders<div class="num">${orders.length}</div></div><div class="card">Payments<div class="num">${payments.length}</div></div><div class="card">GST on Sales<div class="num">${reportMoney(gst)}</div></div><div class="card">Stock Units<div class="num">${data.products.reduce((a,p)=>a+Number(p.stock||0),0).toLocaleString('en-IN')}</div></div></div><div class="reportgrid"><div class="reportmini"><h3>🏆 Top Customers by Sales</h3>${top(customerMap,true)}</div><div class="reportmini"><h3>📦 Top Products by Qty</h3>${top(productMap,false)}</div><div class="reportmini"><h3>🏭 Vendor Purchase</h3>${top(vendorMap,true)}</div><div class="reportmini"><h3>⚠️ Stock Alerts</h3>${low.length?low.map(p=>`<div class="rankrow"><span>${esc(p.name)}</span><span class="reportbadge">${Number(p.stock||0)} / Reorder ${Number(p.reorder||0)}</span></div>`).join(''):'<div class="hint">All products are above reorder level.</div>'}</div></div>`;
}
function catalog(){
 const parents=[...new Set(data.products.map(p=>p.parentCategory||'Other').filter(Boolean))].sort();
 const cats=[...new Set(data.products.map(p=>p.category||'Uncategorized').filter(Boolean))].sort();
 return `<div class="reporthero"><h2>📖 Product Catalogue</h2><div style="opacity:.9">Premium share-ready catalogue in the same clean table style as your reference image.</div></div><div class="panel"><h2>Catalogue Filter</h2><div class="grid"><label class="field"><span>Parent Category</span><select id="catalogParent" onchange="refreshCatalogCategories()"><option value="">All Parent Categories</option>${parents.map(x=>`<option value="${esc(x)}">${esc(x)}</option>`).join('')}</select></label><label class="field"><span>Category</span><select id="catalogCategory" onchange="previewCatalog()"><option value="">All Categories</option>${cats.map(x=>`<option value="${esc(x)}">${esc(x)}</option>`).join('')}</select></label></div><div class="toolbar"><button class="btn" onclick="showCatalogPreview()">👁 Preview Catalogue</button><button class="btn" onclick="downloadCatalogPDF()">📥 Download PDF</button></div><div class="format-card"><b>Selected:</b> <span id="catalogSelection">All Parent Categories • All Categories</span><span class="hint" style="display:block;margin-top:5px">Tip: Product images, SKU, category and Base Selling Price will be included.</span></div><div id="catalogPreview" class="format-card"></div></div>`;
}
function refreshCatalogCategories(){const parent=document.getElementById('catalogParent')?.value||'';const cats=[...new Set(data.products.filter(p=>!parent||p.parentCategory===parent).map(p=>p.category||'Uncategorized').filter(Boolean))].sort();const s=document.getElementById('catalogCategory');if(s)s.innerHTML='<option value="">All Categories</option>'+cats.map(x=>`<option value="${esc(x)}">${esc(x)}</option>`).join('');previewCatalog();}
function catalogProducts(){const parent=document.getElementById('catalogParent')?.value||'',cat=document.getElementById('catalogCategory')?.value||'';return data.products.filter(p=>(!parent||p.parentCategory===parent)&&(!cat||p.category===cat));}
function catalogHTML(products){const parent=document.getElementById('catalogParent')?.value||'All Parent Categories',cat=document.getElementById('catalogCategory')?.value||'All Categories';const dateText=new Intl.DateTimeFormat('en-GB',{day:'2-digit',month:'short',year:'numeric'}).format(new Date()).replace(/ /g,'-');const logo=cfg.logo?`<img src="${cfg.logo}" style="width:${Math.min(180,Math.max(70,Number(cfg.logoWidth||180)))}px;max-height:76px;object-fit:contain">`:'';const brand=cfg.brand&&cfg.brand!=='Gezeno Business Suite'?cfg.brand:'Gezeno';const headerMode=['brand','logo','both'].includes(cfg.catalogHeaderMode)?cfg.catalogHeaderMode:'brand';const headerLeft=headerMode==='logo'&&logo?`<div class="brand-block logo-only"><div class="cat-logo">${logo}</div></div>`:headerMode==='both'&&logo?`<div class="brand-block"><div class="cat-logo">${logo}</div><div class="cat-brand">${esc(brand)}</div></div>`:`<div class="brand-block name-only"><div class="cat-brand">${esc(brand)}</div></div>`;return `<div class="catalog-sheet"><div class="cat-header">${headerLeft}<div class="cat-date">Date: ${dateText}</div></div><div class="cat-title">${esc(cat&&cat!=='All Categories'?cat:parent)}</div><div style="overflow:auto"><table class="table"><thead><tr><th style="width:7%">No.</th><th style="width:24%">Product</th><th style="width:49%">Detail</th><th style="width:20%">Price</th></tr></thead><tbody>${products.map((p,i)=>`<tr><td style="text-align:center;font-weight:700">${i+1}</td><td style="text-align:center">${p.image?`<img src="${p.image}" class="cat-pic">`:'<div class="cat-noimg">No image</div>'}</td><td><div class="cat-name">${esc(p.name)}</div><div class="cat-meta">SKU: ${esc(p.sku||'')}<br>Category: ${esc(p.category||'')}</div></td><td style="font-weight:800;font-size:16px">₹ ${Number(p.b2b||0).toLocaleString('en-IN')}</td></tr>`).join('')||'<tr><td colspan="4" style="text-align:center;padding:30px">No products found for this selection.</td></tr>'}</tbody></table></div></div>`}
function updateCatalogSelection(){const p=document.getElementById('catalogParent')?.value||'All Parent Categories',c=document.getElementById('catalogCategory')?.value||'All Categories';const el=document.getElementById('catalogSelection');if(el)el.textContent=`${p} • ${c}`;}
function previewCatalog(){const el=document.getElementById('catalogPreview');if(el)el.innerHTML=catalogHTML(catalogProducts());updateCatalogSelection();}
function showCatalogPreview(){const products=catalogProducts();if(!products.length){alert('No products found for selected category.');return}const el=document.getElementById('catalogFullPreview');if(el)el.innerHTML=catalogHTML(products);document.getElementById('catalogPreviewModal')?.classList.add('show');}
function closeCatalogPreview(){document.getElementById('catalogPreviewModal')?.classList.remove('show');}
async function downloadCatalogPDF(){const products=catalogProducts();if(!products.length){alert('No products found for selected category.');return}const payload={brand:cfg.brand||'Gezeno',logo:cfg.logo||'',logoWidth:cfg.logoWidth||180,headerMode:cfg.catalogHeaderMode||'brand',parentCategory:document.getElementById('catalogParent')?.value||'',category:document.getElementById('catalogCategory')?.value||'',products:products.map(p=>({name:p.name,sku:p.sku,category:p.category,parentCategory:p.parentCategory,image:p.image||'',price:Number(p.b2b||0),mrp:Number(p.mrp||0)}))};try{if(window.gezeno&&typeof window.gezeno.downloadCatalog==='function'){const r=await window.gezeno.downloadCatalog(payload);if(r?.ok){toast('Customer catalogue PDF saved successfully');}else if(!r?.canceled){alert('PDF download could not be completed. Please try again.');}return;}const printWin=window.open('', '_blank');if(!printWin){alert('Please allow pop-ups for Gezeno to create the catalogue PDF.');return;}const html=catalogHTML(products);printWin.document.open();printWin.document.write(`<!doctype html><html><head><meta charset=\"utf-8\"><title>${esc(cfg.brand&&cfg.brand!=='Gezeno Business Suite'?cfg.brand:'Gezeno')} Product Catalogue</title><style>@page{size:A4;margin:12mm}body{font-family:Arial,Segoe UI,sans-serif;margin:0;background:#fff}.catalog-sheet{max-width:none;margin:0}.catalog-sheet .cat-header{min-height:76px;border-bottom:2px solid #222;padding-bottom:12px;margin-bottom:16px}.catalog-sheet .cat-logo{width:90px;height:76px}.catalog-sheet .cat-logo img{max-width:90px!important;max-height:76px!important}.catalog-sheet .cat-brand{font-size:30px;font-weight:800}.catalog-sheet .cat-date{font-size:16px}.catalog-sheet .cat-title{font-size:28px;font-weight:800;margin:14px 0 18px}.catalog-sheet .cat-pic{width:125px;height:125px}.catalog-sheet .cat-noimg{width:125px;height:125px}.table{width:100%;border-collapse:collapse}.table th,.table td{border:1px solid #222}@media print{tr{page-break-inside:avoid}}</style></head><body>${html}</body></html>`);printWin.document.close();setTimeout(()=>{printWin.focus();printWin.print();},400);toast('Print dialog opened. Choose \"Save as PDF\" to save the catalogue.');}catch(err){alert('PDF download error: '+(err?.message||err));}}


function enrichInvoiceDetails(inv){
  if(!inv) return inv;
  const ord=data.orders.find(o=>o.orderNo===inv.orderNo);
  if(ord){
    if(!Number(inv.gstAmount||0)) inv.gstAmount=Number(ord.gstAmount||0);
    if(!inv.taxType) inv.taxType=ord.taxType||'CGST_SGST';
    if(!Number(inv.cgstAmount||0) && (inv.taxType||'CGST_SGST')==='CGST_SGST') inv.cgstAmount=Number(ord.cgstAmount||Number(inv.gstAmount||0)/2);
    if(!Number(inv.sgstAmount||0) && (inv.taxType||'CGST_SGST')==='CGST_SGST') inv.sgstAmount=Number(ord.sgstAmount||Number(inv.gstAmount||0)/2);
    if(!Number(inv.igstAmount||0) && (inv.taxType||'')==='IGST') inv.igstAmount=Number(ord.igstAmount||inv.gstAmount||0);
  }
  const taxType=inv.taxType||'CGST_SGST';
  if(taxType==='CGST_SGST'){
    if(!Number(inv.cgstAmount||0) && Number(inv.gstAmount||0)) inv.cgstAmount=Number(inv.gstAmount||0)/2;
    if(!Number(inv.sgstAmount||0) && Number(inv.gstAmount||0)) inv.sgstAmount=Number(inv.gstAmount||0)/2;
  } else if(taxType==='IGST' && !Number(inv.igstAmount||0)) inv.igstAmount=Number(inv.gstAmount||0);
  const customerName=inv.customer || ord?.customer || '';
  const c=data.customers.find(x=>x.id===customerName||x.name===customerName)||{};
  if(!inv.customerAddress) inv.customerAddress=c.address||'';
  if(!inv.customerCity) inv.customerCity=c.city||'';
  if(!inv.customerState) inv.customerState=c.state||'';
  if(!inv.customerPincode) inv.customerPincode=c.pincode||'';
  if(!inv.customerGSTIN) inv.customerGSTIN=c.gstin||c.GSTIN||'';
  if(!inv.customerPhone) inv.customerPhone=c.phone||'';
  // Invoice Supplier is the configured Brand only; no owner name and no product vendor.
  inv.supplierName = cfg.brand || 'Gezeno';
  inv.supplierContact = '';
  inv.supplierPhone = cfg.phone || '';
  inv.supplierAddress = cfg.address || '';
  inv.supplierCity = cfg.city || '';
  inv.supplierState = cfg.state || '';
  inv.supplierPincode = cfg.pincode || '';
  inv.supplierGSTIN = cfg.businessGSTIN || cfg.gstin || '';
  return inv;
}
function invoicePayload(inv){
  enrichInvoiceDetails(inv); save();
  return {invoice:inv,config:cfg,format:cfg.invoiceFormat||'modern'};
}
async function downloadInvoice(index){
  const inv=data.invoices[index];
  if(!inv){alert('Invoice not found.');return;}
  enrichInvoiceDetails(inv);
  try{
    if(window.gezeno&&typeof window.gezeno.downloadInvoice==='function'){
      const r=await window.gezeno.downloadInvoice(invoicePayload(inv));
      if(r?.ok){toast('Invoice PDF saved successfully');return;}
      if(r?.canceled)return;
      throw new Error(r?.error||'PDF could not be created');
    }
    const w=window.open('', '_blank');
    if(!w){alert('Please allow pop-ups to open the invoice.');return;}
    w.document.write(invoicePreviewHTML(inv));w.document.close();
    setTimeout(()=>{w.focus();w.print();},500);
  }catch(err){alert('Invoice PDF error: '+(err?.message||err));}
}
function invoicePreviewHTML(inv){
  const escHtml=v=>esc(v??'');
  const money=v=>{const n=Math.round((Number(v||0)+Number.EPSILON)*100)/100;return '₹'+n.toLocaleString('en-IN',{minimumFractionDigits:Number.isInteger(n)?0:2,maximumFractionDigits:2});};
  const taxType=inv.taxType||'CGST_SGST';
  const taxRows=taxType==='IGST'?`<div class="row"><span>IGST</span><span>${money(inv.igstAmount||inv.gstAmount)}</span></div>`:taxType==='NONE'?'':`<div class="row"><span>CGST</span><span>${money(inv.cgstAmount||0)}</span></div><div class="row"><span>SGST</span><span>${money(inv.sgstAmount||0)}</span></div>`;
  const addr=[inv.customerAddress,[inv.customerCity,inv.customerState].filter(Boolean).join(', '),inv.customerPincode].filter(Boolean).join('<br>');
  const saddr=[inv.supplierAddress,[inv.supplierCity,inv.supplierState].filter(Boolean).join(', '),inv.supplierPincode].filter(Boolean).join('<br>');
  return `<!doctype html><html><head><meta charset="utf-8"><title>${escHtml(inv.invoiceNo||'Invoice')}</title><style>@page{size:A4;margin:14mm}body{font-family:Arial,sans-serif;color:#17243a}.wrap{border:1px solid #dce6f2;padding:26px}.logo{text-align:center}.logo img{max-height:70px;object-fit:contain}.head{display:flex;justify-content:space-between;border-bottom:3px solid #1769d7;padding:10px 0 16px}.brand{font-size:28px;font-weight:800;color:#1769d7}.meta{display:grid;grid-template-columns:1fr 1fr;gap:20px;margin:20px 0}.box{padding:12px;background:#f7f9fc;border:1px solid #dce6f2}table{width:100%;border-collapse:collapse}th,td{padding:9px;border-bottom:1px solid #dce6f2;text-align:left}th{background:#1769d7;color:white}.total{margin-left:auto;width:280px;margin-top:18px}.row{display:flex;justify-content:space-between;padding:6px}.grand{font-weight:800;font-size:18px;border-top:2px solid #1769d7;margin-top:6px}</style></head><body><div class="wrap">${cfg.logo?`<div class="logo"><img src="${cfg.logo}" style="width:${Math.min(260,Math.max(120,Number(cfg.logoWidth||180)))}px"></div>`:''}<div class="head"><div><div class="brand">${escHtml(cfg.brand||'Gezeno Business Suite')}</div><div style="font-size:16px;font-weight:700;margin-top:5px">Contact: ${escHtml(cfg.phone||'')}</div><div>${cfg.email?escHtml(cfg.email):''}</div>${(cfg.businessGSTIN||cfg.gstin)?'<div>GSTIN: '+escHtml(cfg.businessGSTIN||cfg.gstin)+'</div>':''}</div><div><b>INVOICE</b><br>${escHtml(inv.invoiceNo||'')}<br>Date: ${escHtml(formatDate(inv.date||''))}</div></div><div class="meta"><div class="box"><b>Bill To / Customer</b><br><b>${escHtml(inv.customer||'')}</b><br>${addr}<br>GSTIN: ${escHtml(inv.customerGSTIN||'Not provided')}<br>Mobile: ${escHtml(inv.customerPhone||'Not provided')}</div><div class="box"><b>Supplier</b><br><b>${escHtml(cfg.brand||'Gezeno')}</b>${(cfg.address)?'<br>'+escHtml(cfg.address):''}${(cfg.city)?'<br>'+escHtml(cfg.city):''}${(cfg.state)?'<br>'+escHtml(cfg.state):''}${(cfg.pincode)?'<br>PIN: '+escHtml(cfg.pincode):''}${(cfg.phone)?'<br><b>Mobile:</b> '+escHtml(cfg.phone):''}${(cfg.email)?'<br><b>Email:</b> '+escHtml(cfg.email):''}${(cfg.businessGSTIN||cfg.gstin)?'<br><b>GSTIN:</b> '+escHtml(cfg.businessGSTIN||cfg.gstin):''}</div></div><table><thead><tr><th>Product</th><th>HSN/SAC</th><th>Qty</th><th>Rate</th><th>GST</th><th>Amount</th></tr></thead><tbody>${(inv.items||[]).map(it=>`<tr><td>${escHtml(it.name||it.sku||'')}</td><td>${escHtml(it.hsn||'')}</td><td>${escHtml(it.qty||0)}</td><td>${money(it.rate)}</td><td>${escHtml(it.gst||0)}%</td><td>${money(Number(it.qty||0)*Number(it.rate||0))}</td></tr>`).join('')}</tbody></table><div class="total"><div class="row"><span>Subtotal</span><span>${money(inv.subtotal??inv.total)}</span></div><div class="row"><span>Discount</span><span>- ${money(inv.discount)}</span></div><div class="row"><span>Transport / Delivery (No GST)</span><span>${money(inv.transport)}</span></div>${taxRows}<div class="row grand"><span>Total</span><span>${money(inv.total)}</span></div><div class="row"><span>Paid</span><span>${money(inv.paidAmount)}</span></div><div class="row"><span>Balance Due</span><span>${money(inv.dueAmount)}</span></div></div></div></body></html>`;
}
function previewInvoice(index){
  const inv=data.invoices[index];
  if(!inv){alert('Invoice not found.');return;}
  enrichInvoiceDetails(inv);save();
  const w=window.open('', '_blank');
  if(!w){alert('Please allow pop-ups to preview the invoice.');return;}
  w.document.write(invoicePreviewHTML(inv));w.document.close();
}

function settings(){
 const logo=cfg.logo?`<div class="product-image-box"><img src="${cfg.logo}" class="product-preview" alt="Brand logo"></div>`:'<div class="hint">No logo uploaded</div>';
 return `<div class="reporthero"><h2>⚙ Brand, Logo & Invoice Settings</h2><div style="opacity:.9">Set the brand details that will appear on product catalogues and invoices.</div></div>
 <div class="panel"><h2>Brand Details</h2><div class="settingrow">
 <label>Brand Name<input id="setBrand" value="${esc(cfg.brand||'Gezeno')}"></label>
 <label>Brand Owner / Proprietor<input id="setOwnerName" value="${esc(cfg.ownerName||'Chander Mohan')}"></label>
 
 <label>Phone<input id="setPhone" value="${esc(cfg.phone||'')}"></label>
 <label>Email<input id="setEmail" value="${esc(cfg.email||'')}"></label>
 <label>Address<input id="setAddress" value="${esc(cfg.address||'')}" placeholder="House / Street / Locality"></label>
 <label>City<input id="setCity" value="${esc(cfg.city||'')}" placeholder="City"></label>
 <label>State<input id="setState" value="${esc(cfg.state||'')}" placeholder="State"></label>
 <label>Pincode<input id="setPincode" value="${esc(cfg.pincode||'')}" placeholder="Pincode"></label>
 <label>Business GSTIN<input id="setGSTIN" value="${esc(cfg.businessGSTIN||cfg.gstin||'')}" placeholder="e.g. 07ABCDE1234F1Z5"></label>
 </div></div>
 <div class="panel"><h2>Catalogue / Invoice Logo</h2><div class="settingrow">
 <label>Logo Image<input id="logoFile" type="file" accept="image/png,image/jpeg,image/webp" onchange="handleLogoUpload(event)"><span class="hint">PNG/JPG/WEBP • Recommended 800 × 300 px • Max 2 MB</span></label>
 <label>Logo Display Width (px)<input id="setLogoWidth" type="number" min="120" max="260" value="${Number(cfg.logoWidth||180)}"><span class="hint">Used in invoices and product catalogues.</span></label>
 <label>Catalogue Header<select id="setCatalogHeaderMode"><option value="brand" ${((cfg.catalogHeaderMode||'brand')==='brand')?'selected':''}>Brand Name Only</option><option value="logo" ${cfg.catalogHeaderMode==='logo'?'selected':''}>Brand Logo Only</option><option value="both" ${cfg.catalogHeaderMode==='both'?'selected':''}>Brand Name + Logo</option></select><span class="hint">Choose Brand Name only, Logo only, or both in the catalogue header.</span></label>
 <div class="mobile-header-setting" style="grid-column:1/-1;border:1px solid #dce6f2;border-radius:12px;padding:16px;background:#fbfcfe">
  <div style="font-weight:800;font-size:16px;margin-bottom:4px">📱 Mobile App Header</div>
  <div class="hint" style="margin-bottom:12px">Login ke baad mobile app ke top header me kya dikhana hai, yahan separately choose karein. Catalogue Header setting se iska koi connection nahi hai.</div>
  <div style="display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px">
    <label style="display:flex;align-items:center;gap:9px;padding:12px;border:1px solid #dce6f2;border-radius:10px;background:#fff;cursor:pointer">
      <input type="radio" name="mobileHeaderDisplayMode" value="brand" ${((cfg.mobileHeaderMode||'brand')==='brand')?'checked':''}>
      <span><b>Brand Name</b><small style="display:block;color:#6b778c;margin-top:3px">Header me business/brand name show hoga.</small></span>
    </label>
    <label style="display:flex;align-items:center;gap:9px;padding:12px;border:1px solid #dce6f2;border-radius:10px;background:#fff;cursor:pointer">
      <input type="radio" name="mobileHeaderDisplayMode" value="logo" ${cfg.mobileHeaderMode==='logo'?'checked':''}>
      <span><b>Brand Logo</b><small style="display:block;color:#6b778c;margin-top:3px">Header me uploaded logo show hoga.</small></span>
    </label>
  </div>
  ${cfg.logo?`<div class="hint" style="margin-top:10px">Current logo available ✓</div>`:`<div class="hint" style="margin-top:10px">Logo mode ke liye pehle upar Logo Image upload karein.</div>`}
</div>
 </div>${logo}<div class="toolbar"><button class="btn secondary" onclick="removeLogo()">Remove Logo</button></div></div>
 <div class="panel"><h2>Login Settings</h2><div class="settingrow">
 <label>Username<input id="setUsername" value="${esc(cfg.username||'admin')}"></label>
 <label>Password<input id="setPassword" type="text" value="${esc(cfg.password||'gezeno123')}"></label>
 </div></div>
 <div class="toolbar"><button class="btn" onclick="saveSettings()">💾 Save Settings</button><button class="btn secondary" onclick="show('dashboard')">Cancel</button></div>`;
}
function handleLogoUpload(e){const f=e.target.files?.[0];if(!f)return;if(f.size>2*1024*1024){alert('Logo file must be 2 MB or smaller.');e.target.value='';return;}if(!['image/png','image/jpeg','image/webp'].includes(f.type)){alert('Please select PNG, JPG or WEBP logo.');e.target.value='';return;}const r=new FileReader();r.onload=()=>{const img=new Image();img.onload=()=>{cfg.logo=String(r.result);cfg.logoDimensions={width:img.naturalWidth,height:img.naturalHeight};save();show('settings');toast(`Logo uploaded: ${img.naturalWidth} × ${img.naturalHeight}px`)};img.src=r.result};r.readAsDataURL(f);}
function removeLogo(){cfg.logo='';cfg.logoDimensions=null;save();show('settings');toast('Logo removed');}
function saveSettings(){cfg={...cfg,brand:(document.getElementById('setBrand')?.value||'Gezeno').trim()||'Gezeno',ownerName:(document.getElementById('setOwnerName')?.value||'Chander Mohan').trim()||'Chander Mohan',subtitle:'',phone:(document.getElementById('setPhone')?.value||'').trim(),email:(document.getElementById('setEmail')?.value||'').trim(),address:(document.getElementById('setAddress')?.value||'').trim(),city:(document.getElementById('setCity')?.value||'').trim(),state:(document.getElementById('setState')?.value||'').trim(),pincode:(document.getElementById('setPincode')?.value||'').trim(),businessGSTIN:(document.getElementById('setGSTIN')?.value||'').trim().toUpperCase(),logoWidth:Math.min(260,Math.max(120,Number(document.getElementById('setLogoWidth')?.value||180))),catalogHeaderMode:(['brand','logo','both'].includes((document.getElementById('setCatalogHeaderMode')?.value||'brand').toLowerCase())?(document.getElementById('setCatalogHeaderMode')?.value||'brand').toLowerCase():'brand'),mobileHeaderMode:(['brand','logo'].includes((document.querySelector('input[name=\"mobileHeaderDisplayMode\"]:checked')?.value||'brand').toLowerCase())?(document.querySelector('input[name=\"mobileHeaderDisplayMode\"]:checked')?.value||'brand').toLowerCase():'brand'),username:(document.getElementById('setUsername')?.value||'gezeno').trim()||'gezeno',password:document.getElementById('setPassword')?.value||'gezeno123',authVersion:2};cfg.gstin=cfg.businessGSTIN;localStorage.setItem('gezenoConfig',JSON.stringify(cfg));applyBrand();show('settings');toast('Settings saved successfully');}


function pnlDashboard(){
 const f=window.pnlDashboardFilters||{channel:'All',month:'',from:'',to:'',applied:false};
 return `<div class="pnl-shell">
 <div class="pnl-hero"><div><div class="pnl-eyebrow">GEZENO • FINANCIAL CONTROL CENTER</div><h2>📈 Profit & Loss Dashboard</h2><p>Order amount → received → pending → cancelled → returns → actual realized profit</p></div><div class="pnl-hero-actions"><button class="btn" onclick="show('reconciliation')">💳 Reconciliation</button><button class="btn secondary" onclick="show('gstr1')">🧾 GST Reports</button></div></div>
 <div class="panel pnl-filter-panel"><div class="pnl-filter-title"><div><h3>Report Filters</h3><span class="hint">Select marketplace and date range to recalculate the dashboard.</span></div></div><div class="finance-filters"><label class="field"><span>Marketplace</span><select id="pnlChannel"><option ${f.channel==='All'?'selected':''}>All</option><option ${f.channel==='Amazon'?'selected':''}>Amazon</option><option ${f.channel==='Flipkart'?'selected':''}>Flipkart</option><option ${f.channel==='Meesho'?'selected':''}>Meesho</option></select></label><label class="field"><span>Month-wise</span><input id="pnlMonth" type="month" value="${esc(f.month||'')}"></label><label class="field"><span>From Date</span><input id="pnlFrom" type="date" value="${esc(f.from||'')}"></label><label class="field"><span>To Date</span><input id="pnlTo" type="date" value="${esc(f.to||'')}"></label><button class="btn" onclick="applyPnlDashboard()">🔎 Apply Filter</button><button class="btn secondary" onclick="window.pnlDashboardFilters={channel:'All',month:'',from:'',to:'',applied:false};show('pnlDashboard')">Reset & Lock Data</button></div></div>
 <div id="pnlDashboardBody">${pnlDashboardBody(f)}</div></div>`;
}
function pnlDashboardBody(f){
 if(f.applied!==true)return '<div class="panel"><div class="filter-lock-panel"><strong>🔒 Financial data locked</strong><div class="hint">Select Month-wise or From + To Date and tap Apply Filter.</div></div></div>';
 let orders=(data.marketplaceOrders||[]).filter(o=>!o.dumpArchived&&(!f.channel||f.channel==='All'||o.channel===f.channel)&&(!f.from||String(o.date)>=f.from)&&(!f.to||String(o.date)<=f.to));
 const settlements=(data.marketplaceSettlements||[]).filter(s=>(!f.channel||f.channel==='All'||s.channel===f.channel)&&(!f.from||reconSettlementDate(s)>=f.from)&&(!f.to||reconSettlementDate(s)<=f.to));
 const received=settlements.reduce((a,s)=>a+num(s.netReceived),0);
 const cancelled=orders.filter(o=>String(o.status)==='Cancelled');
 const returned=orders.filter(o=>String(o.status)==='Returned');
 const pending=orders.filter(o=>!['Cancelled','Returned','RTO'].includes(String(o.status))&&String(o.paymentStatus||'Pending')!=='Settled');
 const valid=orders.filter(o=>!['Cancelled','Returned','RTO'].includes(String(o.status)));
 const cogs=valid.reduce((a,o)=>{const p=data.products.find(x=>x.sku===o.sku)||{};return a+num(p.purchase)*Math.max(1,num(o.qty))},0);
 const charges=valid.reduce((a,o)=>a+num(o.commission)+num(o.shippingFee)+num(o.adsCost)+num(o.returnCost)+num(o.otherCost),0);
 const settled=valid.filter(o=>String(o.paymentStatus||'Pending')==='Settled');
 const settledCogs=settled.reduce((a,o)=>{const p=data.products.find(x=>x.sku===o.sku)||{};return a+num(p.purchase)*Math.max(1,num(o.qty))},0);
 const settledOther=settled.reduce((a,o)=>a+num(o.adsCost)+num(o.returnCost)+num(o.otherCost),0);
 const actualProfit=received-settledCogs-settledOther;
 const estimated=valid.reduce((a,o)=>a+num(o.sellingPrice),0)-cogs-charges;
 const sales=orders.reduce((a,o)=>a+num(o.sellingPrice),0);
 const pendingAmt=pending.reduce((a,o)=>a+num(o.sellingPrice),0);
 const cancelledAmt=cancelled.reduce((a,o)=>a+num(o.sellingPrice),0);
 const returnedAmt=returned.reduce((a,o)=>a+num(o.sellingPrice),0);
 const margin=received?actualProfit/received*100:0;
 const card=(label,value,hint,cls='')=>`<div class="pnl-kpi ${cls}"><div class="pnl-kpi-label">${label}</div><div class="pnl-kpi-value">${value}</div><div class="pnl-kpi-hint">${hint}</div></div>`;
 const statusCards=[['Total Orders',orders.length,'All selected orders',''],['Delivered',orders.filter(o=>o.status==='Delivered').length,'Successfully delivered','good'],['Pending / In Transit',pending.length,'Payment not settled','orange'],['Cancelled',cancelled.length,'Cancelled orders','bad'],['Returned',returned.length,'Returned orders','bad']];
 const byChannel=['Amazon','Flipkart','Meesho'].map(ch=>{const os=orders.filter(o=>o.channel===ch),s=os.reduce((a,o)=>a+num(o.sellingPrice),0),rc=settlements.filter(x=>x.channel===ch).reduce((a,x)=>a+num(x.netReceived),0),ca=os.filter(o=>o.status==='Cancelled'),re=os.filter(o=>o.status==='Returned'),pe=os.filter(o=>!['Cancelled','Returned','RTO'].includes(String(o.status))&&o.paymentStatus!=='Settled');return `<tr><td><b>${ch}</b></td><td>${os.length}</td><td>₹${s.toLocaleString('en-IN')}</td><td>₹${rc.toLocaleString('en-IN')}</td><td>₹${pe.reduce((a,o)=>a+num(o.sellingPrice),0).toLocaleString('en-IN')}</td><td>${ca.length}</td><td>${re.length}</td></tr>`}).join('');
 return `<div class="pnl-kpi-grid">${card('Total Order Amount',`₹${sales.toLocaleString('en-IN',{minimumFractionDigits:0})}`,'Gross order value')}${card('Actual Amount Received',`₹${received.toLocaleString('en-IN',{minimumFractionDigits:0})}`,'Marketplace settlements','good')}${card('Pending Amount',`₹${pendingAmt.toLocaleString('en-IN',{minimumFractionDigits:0})}`,'Unsettled active orders','orange')}${card('Cancelled Amount',`₹${cancelledAmt.toLocaleString('en-IN',{minimumFractionDigits:0})}`,'Cancelled order value','bad')}${card('Return Amount',`₹${returnedAmt.toLocaleString('en-IN',{minimumFractionDigits:0})}`,'Returned order value','bad')}${card('Actual Realized Profit',`₹${actualProfit.toLocaleString('en-IN',{minimumFractionDigits:0})}`,'Received − settled COGS − settled costs',actualProfit>=0?'good':'bad')}${card('Estimated Profit',`₹${estimated.toLocaleString('en-IN',{minimumFractionDigits:0})}`,'Active orders before settlement','')}${card('Profit Margin',`${margin.toFixed(2)}%`,'Realized profit / received',actualProfit>=0?'good':'bad')}</div>
 <div class="pnl-status-grid">${statusCards.map(x=>`<div class="pnl-status-card ${x[3]}"><div class="pnl-status-label">${x[0]}</div><div class="pnl-status-value">${x[1]}</div><div class="pnl-status-hint">${x[2]}</div></div>`).join('')}</div>
 <div class="pnl-two-col"><div class="panel"><div class="pnl-section-head"><div><h3>Marketplace-wise Financial Position</h3><span class="hint">Order value, actual receipt and outstanding amount</span></div></div><div style="overflow:auto"><table class="table"><thead><tr><th>Marketplace</th><th>Orders</th><th>Order Amount</th><th>Received</th><th>Pending</th><th>Cancelled</th><th>Returns</th></tr></thead><tbody>${byChannel||'<tr><td colspan="7">No data matches the selected filters.</td></tr>'}</tbody></table></div></div>
 <div class="panel pnl-profit-card"><div class="pnl-section-head"><div><h3>Actual Profit Bridge</h3><span class="hint">Only settled orders are treated as realized</span></div></div><div class="pnl-bridge"><div><span>Marketplace Receipt</span><b>₹${received.toLocaleString('en-IN',{minimumFractionDigits:0})}</b></div><div><span>Product Cost / COGS</span><b>− ₹${settledCogs.toLocaleString('en-IN',{minimumFractionDigits:0})}</b></div><div><span>Ads + Return + Other Cost</span><b>− ₹${settledOther.toLocaleString('en-IN',{minimumFractionDigits:0})}</b></div><div class="total"><span>Actual Realized Profit</span><b>₹${actualProfit.toLocaleString('en-IN',{minimumFractionDigits:0})}</b></div><div class="margin"><span>Realized Margin</span><b>${margin.toFixed(2)}%</b></div></div></div></div>
 <div class="panel"><div class="pnl-section-head"><div><h3>Profit Cost Breakdown</h3><span class="hint">Active order cost structure used for estimated profitability</span></div></div><div class="pnl-cost-grid"><div><span>Sales</span><b>₹${sales.toLocaleString('en-IN',{minimumFractionDigits:0})}</b></div><div><span>COGS</span><b>₹${cogs.toLocaleString('en-IN',{minimumFractionDigits:0})}</b></div><div><span>Marketplace + Shipping + Ads</span><b>₹${(valid.reduce((a,o)=>a+num(o.commission)+num(o.shippingFee)+num(o.adsCost),0)).toLocaleString('en-IN',{minimumFractionDigits:0})}</b></div><div><span>Return + Other Cost</span><b>₹${(valid.reduce((a,o)=>a+num(o.returnCost)+num(o.otherCost),0)).toLocaleString('en-IN',{minimumFractionDigits:0})}</b></div></div><div class="pnl-note">GST, TCS and TDS remain available in reconciliation/GST reports and are not double-counted here as operating expenses.</div></div>`;
}
function applyPnlDashboard(){const channel=document.getElementById('pnlChannel')?.value||'All',month=document.getElementById('pnlMonth')?.value||'';let from=document.getElementById('pnlFrom')?.value||'',to=document.getElementById('pnlTo')?.value||'';if(month){const [y,mo]=month.split('-').map(Number),last=new Date(y,mo,0).getDate();from=`${y}-${String(mo).padStart(2,'0')}-01`;to=`${y}-${String(mo).padStart(2,'0')}-${String(last).padStart(2,'0')}`;}if(!month&&!from&&!to){toast('Please select Month-wise or From + To Date first');return}if(!month&&((from&&!to)||(!from&&to))){toast('Please select both From and To Date');return}if(from&&to&&from>to){toast('From Date cannot be after To Date');return}window.pnlDashboardFilters={channel,month,from,to,applied:true};show('pnlDashboard');}

function returnsDashboard(){
 const rf=window.returnsDashboardFilters||{channel:'All',status:'All',month:'',from:'',to:'',search:'',applied:false};const allReturns=(data.marketplaceReturns||[]);const rs=rf.applied===true?allReturns.filter(r=>{const d=String(r.date||'').slice(0,10),q=String(rf.search||'').toLowerCase();return (rf.channel==='All'||r.channel===rf.channel)&&(rf.status==='All'||r.status===rf.status)&&(!rf.month||d.slice(0,7)===rf.month)&&(!rf.from||d>=rf.from)&&(!rf.to||d<=rf.to)&&(!q||JSON.stringify(r).toLowerCase().includes(q))}):[]; const channels=['Amazon','Flipkart','Meesho'];
 const totalRefund=rs.reduce((a,r)=>a+num(r.refund??r.refundAmount),0), reverse=rs.reduce((a,r)=>a+num(r.reverseShipping),0), loss=rs.reduce((a,r)=>a+num(r.loss??r.lossAmount),0), qty=rs.reduce((a,r)=>a+num(r.qty),0);
 const returnedOrders=new Set(rs.map(r=>String(r.orderId||'').trim()).filter(Boolean)).size;
 const pending=rs.filter(r=>['Requested','Received'].includes(String(r.status||''))).length;
 const refunded=rs.filter(r=>String(r.status||'')==='Refunded').length;
 const closed=rs.filter(r=>String(r.status||'')==='Closed').length;
 const filters=`<div class="panel"><div class="finance-filters"><label class="field"><span>Marketplace</span><select id="retCh"><option>All</option><option>Amazon</option><option>Flipkart</option><option>Meesho</option></select></label><label class="field"><span>Status</span><select id="retSt"><option>All</option><option>Requested</option><option>Received</option><option>Refunded</option><option>Closed</option></select></label><label class="field"><span>Month-wise</span><input id="retMonth" type="month" value="${esc(rf.month||'')}"></label><label class="field"><span>From Date</span><input id="retFrom" type="date" value="${esc(rf.from||'')}"></label><label class="field"><span>To Date</span><input id="retTo" type="date" value="${esc(rf.to||'')}"></label><label class="field" style="min-width:220px;flex:1"><span>Search Order / Return / SKU</span><input id="retSearch" placeholder="Search ID or SKU"></label><button class="btn" onclick="applyReturnsDashboard()">🔎 Apply Filter</button><button class="btn secondary" onclick="window.returnsDashboardFilters={channel:'All',status:'All',month:'',from:'',to:'',search:'',applied:false};show('returnsDashboard')">Reset & Lock Data</button></div></div>`;
 const kpi=(label,value,hint,cls='')=>`<div class="finance-kpi ${cls}"><div class="label">${label}</div><div class="value">${value}</div><div class="hint">${hint}</div></div>`;
 const cards=`<div class="finance-kpis">${kpi('Total Returns',rs.length,'Return cases')}${kpi('Returned Orders',returnedOrders,'Unique Order IDs')}${kpi('Return Qty',qty,'Units returned')}${kpi('Refund Amount','₹'+totalRefund.toLocaleString('en-IN',{minimumFractionDigits:0}),'Customer refunds','bad')}${kpi('Reverse Shipping','₹'+reverse.toLocaleString('en-IN',{minimumFractionDigits:0}),'Reverse logistics','bad')}${kpi('Return Loss','₹'+loss.toLocaleString('en-IN',{minimumFractionDigits:0}),'Direct return loss','bad')}${kpi('Pending Action',pending,'Requested + received')}${kpi('Refunded / Closed',refunded+' / '+closed,'Completed cases','good')}</div>`;
 const rows=channels.map(ch=>{const a=rs.filter(r=>r.channel===ch);const ref=a.reduce((x,r)=>x+num(r.refund??r.refundAmount),0),rv=a.reduce((x,r)=>x+num(r.reverseShipping),0),ls=a.reduce((x,r)=>x+num(r.loss??r.lossAmount),0);return `<tr><td><b>${ch}</b></td><td>${a.length}</td><td>${a.reduce((x,r)=>x+num(r.qty),0)}</td><td>₹${ref.toLocaleString('en-IN')}</td><td>₹${rv.toLocaleString('en-IN')}</td><td>₹${ls.toLocaleString('en-IN')}</td><td>${a.filter(r=>r.status==='Requested').length}</td><td>${a.filter(r=>r.status==='Refunded').length}</td></tr>`}).join('');
 return `<div class="reporthero"><div style="display:flex;justify-content:space-between;gap:18px;align-items:center;flex-wrap:wrap"><div><h2>↩ Returns & Refunds Control Center</h2><div style="opacity:.9">Professional marketplace return, refund, reverse-shipping and loss tracking</div></div><div class="quick"><button class="btn" onclick="show('marketplaceControl')">← Order Control</button><button class="btn secondary" onclick="show('pnlDashboard')">📈 Profit & Loss</button></div></div></div>${cards}${filters}<div class="panel"><h3>Marketplace-wise Return Performance</h3><div style="overflow:auto"><table class="table"><thead><tr><th>Marketplace</th><th>Returns</th><th>Qty</th><th>Refund</th><th>Reverse Shipping</th><th>Loss</th><th>Pending</th><th>Refunded</th></tr></thead><tbody>${rows||'<tr><td colspan="8" class="hint">No return data.</td></tr>'}</tbody></table></div></div><div class="panel"><h3>Return & Refund Register</h3><div style="overflow:auto"><table class="table"><thead><tr><th>Return ID</th><th>Order ID</th><th>Marketplace</th><th>Date</th><th>SKU</th><th>Qty</th><th>Reason</th><th>Refund</th><th>Reverse Shipping</th><th>Status</th><th>Loss</th></tr></thead><tbody>${rs.map(r=>`<tr><td><b>${esc(r.returnId||'-')}</b></td><td>${esc(r.orderId||'-')}</td><td>${esc(r.channel||'-')}</td><td>${formatDate(r.date)}</td><td>${esc(r.sku||'-')}</td><td>${num(r.qty)}</td><td>${esc(r.reason||'-')}</td><td>₹${num(r.refund??r.refundAmount).toLocaleString('en-IN')}</td><td>₹${num(r.reverseShipping).toLocaleString('en-IN')}</td><td><span class="badge ${r.status==='Refunded'||r.status==='Closed'?'green':r.status==='Requested'?'orange':'red'}">${esc(r.status||'-')}</span></td><td>₹${num(r.loss??r.lossAmount).toLocaleString('en-IN')}</td></tr>`).join('')||'<tr><td colspan="11" class="hint">No return records.</td></tr>'}</tbody></table></div></div><div class="panel"><h3>Return Financial Impact</h3><div class="finance-note"><b>Calculation:</b> Refund Amount + Reverse Shipping + Return Loss ko separately track kiya ja raha hai. Ye values Profit & Loss me return-related cost analysis ke liye available rahengi. GST figures ko bina source GST data ke invent nahi kiya jayega.</div></div>`;
}
function applyReturnsDashboard(){const ch=document.getElementById('retCh')?.value||'All',st=document.getElementById('retSt')?.value||'All',month=document.getElementById('retMonth')?.value||'';let from=document.getElementById('retFrom')?.value||'',to=document.getElementById('retTo')?.value||'',search=document.getElementById('retSearch')?.value||'';if(month){const [y,mo]=month.split('-').map(Number),last=new Date(y,mo,0).getDate();from=`${y}-${String(mo).padStart(2,'0')}-01`;to=`${y}-${String(mo).padStart(2,'0')}-${String(last).padStart(2,'0')}`;}if(!month&&!from&&!to){toast('Please select Month-wise or From + To Date first');return}if(!month&&((from&&!to)||(!from&&to))){toast('Please select both From and To Date');return}if(from&&to&&from>to){toast('From Date cannot be after To Date');return}window.returnsDashboardFilters={channel:ch,status:st,month,from,to,search,applied:true};show('returnsDashboard');}
function applyGSTR1Filters(){
 const month=document.getElementById('gstMonthFilter')?.value||'';
 const from=document.getElementById('gstFromDate')?.value||'';
 const to=document.getElementById('gstToDate')?.value||'';
 if(!month&&!from&&!to){toast('Please select a reporting month or date range first');return}
 if(!month&&((from&&!to)||(!from&&to))){toast('Please select both From Date and To Date');return}
 if(!month&&from&&to&&from>to){toast('From Date cannot be after To Date');return}
 window.gstr1Filters={marketplace:document.getElementById('gstMarketplaceFilter')?.value||'All',state:document.getElementById('gstStateFilter')?.value||'All',rate:document.getElementById('gstRateFilter')?.value||'All',nature:document.getElementById('gstNatureFilter')?.value||'All',search:document.getElementById('gstSearch')?.value||'',month,from,to,applied:true};
 show('gstr1')
}
function resetGSTR1Filters(){window.gstr1Filters={marketplace:'All',state:'All',rate:'All',nature:'All',search:'',month:'',from:'',to:'',applied:false};show('gstr1')}
function gstrCsvNum(v){const n=Number(v||0);if(!Number.isFinite(n))return '';const r=Math.round((n+Number.EPSILON)*100)/100;return Number.isInteger(r)?String(r):r.toFixed(2).replace(/0+$/,'').replace(/\.$/,'')}
function exportGSTR1CSV(){try{const all=Array.isArray(data.gstr1Records)?data.gstr1Records:[];const rs=gstr1FilterRows(all);const head=['Invoice No','Invoice Date','Marketplace','Supply Type','Note Type','GSTIN','POS','HSN/SAC','GST Rate','Taxable Value','IGST','CGST','SGST/UTGST','Cess','Invoice Value','Quantity','Customer','Source File'];const body=rs.map(x=>{const y=gstrNormalizeRecord({...x});const pos=gstrPOSDisplay(y.pos||y.stateCode||y.stateName);return [y.invoiceNo,y.invoiceDate,y.channel||inferGSTRMarketplace(y),y.supplyType,y.noteType,y.gstin,pos,y.hsn,gstrCsvNum(y.rate),gstrCsvNum(y.taxable),gstrCsvNum(y.igst),gstrCsvNum(y.cgst),gstrCsvNum(y.sgst),gstrCsvNum(y.cess),gstrCsvNum(y.invoiceValue),gstrCsvNum(y.qty),y.customer,y.sourceFile]});const csv='\uFEFF'+[head,...body].map(r=>r.map(v=>'\"'+String(v??'').replace(/\"/g,'\"\"')+'\"').join(',')).join('\r\n');const blob=new Blob([csv],{type:'text/csv;charset=utf-8'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download='Gezeno_GSTR1_Export.csv';document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),2000);toast(`GSTR-1 export successful: ${body.length} rows`)}catch(e){console.error('GSTR-1 export failed',e);alert('GSTR-1 export failed: '+(e?.message||e))}}

function reports(){return `<div class="toolbar" style="flex-wrap:wrap;align-items:end"><div class="field"><label>From Date</label><input id="reportFrom" type="date"></div><div class="field"><label>To Date</label><input id="reportTo" type="date"></div><div class="field"><label>Marketplace</label><select id="reportMarketplace" onchange="generateReport()"><option value="All">All Marketplaces</option><option value="Amazon">Amazon</option><option value="Flipkart">Flipkart</option><option value="Meesho">Meesho</option></select></div><div class="field"><label>Report Type</label><select id="reportType" onchange="generateReport()"><option value="summary">Premium Executive Dashboard</option><option value="sales">Sales Report</option><option value="purchase">Purchase Report</option><option value="payments">Payment & Collection</option><option value="dues">Customer Dues</option><option value="gst">GST Summary</option><option value="stock">Stock & Inventory</option><option value="customers">Customer-wise Sales</option><option value="vendors">Vendor-wise Purchase</option><option value="gstr1">GSTR-1 Outward Supplies</option></select></div><button class="btn" onclick="generateReport()">Generate Report</button><button class="btn secondary" onclick="exportCurrentReportCSV()">Export CSV</button><button class="btn secondary" onclick="printCurrentReport()">Print</button></div><div id="reportOutput"></div><div class="panel"><h2>🧾 GSTR-1 / GST Upload</h2><div class="hint">GSTR-1 Excel/CSV upload yahin se hoga. App invoice-wise outward supplies ko B2B/B2C/Credit-Debit Note/HSN/POS/GST ke saath store karega.</div><div class="toolbar" style="flex-wrap:wrap"><label class="btn">📤 Upload GSTR-1 File<input hidden type="file" accept=".csv,.txt,.xlsx,.xls,text/csv,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" onchange="importGSTR1File(this)"></label><button class="btn secondary" onclick="show('gstr1')">Open GST Dashboard →</button><button class="btn secondary" onclick="exportGSTR1CSV()">Export GSTR-1 Data</button></div><div class="hint">Upload data is used for reconciliation/reporting; GST portal filing is not submitted automatically.</div></div><div class="panel"><h2>Data Backup</h2><button class="btn" onclick="downloadBackup()">Export Backup</button> <button class="btn secondary" onclick="show('csvCenter')">Restore Backup → File Upload</button><div class="hint">All data-file import/upload actions are handled only from File Upload.</div></div><script>setTimeout(()=>{let t=new Date(),first=new Date(t.getFullYear(),t.getMonth(),1);document.getElementById('reportFrom').value=first.toISOString().slice(0,10);document.getElementById('reportTo').value=t.toISOString().slice(0,10);document.getElementById('reportMarketplace').value='All';document.getElementById('reportType').value='summary';document.getElementById('reportOutput').innerHTML=premiumReportDashboard()},0)<\/script>`}

function migrateBusinessData(){data.vendors=(data.vendors||[]).filter(v=>!/^Demo Vendor [ABC]$/i.test(String(v.name||'')));data.vendors.forEach(v=>{v.address=v.address||'';v.state=v.state||'Delhi';v.pincode=v.pincode||'';v.gstin=v.gstin||''});data.products.forEach(p=>{if(p.reorder==null)p.reorder=5;if(p.hsn==null)p.hsn='';if(p.image==null)p.image='';if(!p.parentCategory){let c=String(p.category||'').toLowerCase();p.parentCategory=c.includes('elect')?'Electronics':c.includes('station')?'Stationery':c.includes('art')||c.includes('clay')?'Arts & Crafts':c.includes('build')||c.includes('learning')?'Toys':'Other'}});data.purchases.forEach(p=>{if(p.items==null)p.items=[];if(p.subtotal==null)p.subtotal=Number(p.total||0);if(p.discount==null)p.discount=0;if(p.transport==null)p.transport=0;if(p.gstAmount==null)p.gstAmount=0});data.orders.forEach(o=>(o.items||[]).forEach(it=>{if(!it.hsn){let p=data.products.find(x=>x.sku===it.sku);if(p)it.hsn=p.hsn||''}}));data.invoices.forEach(inv=>{if(inv.items)inv.items.forEach(it=>{if(!it.hsn){let p=data.products.find(x=>x.sku===it.sku);if(p)it.hsn=p.hsn||''}});let ord=data.orders.find(o=>o.orderNo===inv.orderNo);if(ord){inv.taxType=inv.taxType||ord.taxType||'CGST_SGST';inv.gstAmount=Number(inv.gstAmount||ord.gstAmount||0);inv.cgstAmount=Number(inv.cgstAmount||ord.cgstAmount||(inv.taxType==='CGST_SGST'?inv.gstAmount/2:0));inv.sgstAmount=Number(inv.sgstAmount||ord.sgstAmount||(inv.taxType==='CGST_SGST'?inv.gstAmount/2:0));inv.igstAmount=Number(inv.igstAmount||ord.igstAmount||(inv.taxType==='IGST'?inv.gstAmount:0));}else{inv.taxType=inv.taxType||'CGST_SGST';if(inv.taxType==='CGST_SGST'){inv.cgstAmount=Number(inv.cgstAmount||Number(inv.gstAmount||0)/2);inv.sgstAmount=Number(inv.sgstAmount||Number(inv.gstAmount||0)/2)}else if(inv.taxType==='IGST')inv.igstAmount=Number(inv.igstAmount||inv.gstAmount||0)}inv.supplierName=cfg.brand||'Gezeno';inv.supplierContact='';inv.supplierPhone=cfg.phone||'';inv.supplierAddress=cfg.address||'';inv.supplierCity=cfg.city||'';inv.supplierState=cfg.state||'';inv.supplierPincode=cfg.pincode||'';inv.supplierGSTIN=cfg.businessGSTIN||cfg.gstin||''});save()}
function resetBusinessData(){if(!confirm('Reset business data and login settings?'))return;localStorage.removeItem('gezenoData');localStorage.removeItem('gezenoSeedV4');localStorage.removeItem('gezenoConfig');location.reload()}
function downloadBackup(){let a=document.createElement('a');a.href=URL.createObjectURL(new Blob([JSON.stringify({config:cfg,data:data},null,2)],{type:'application/json'}));a.download='gezeno-business-backup.json';a.click()}
function restoreBackup(e){let f=e.target.files[0];if(!f)return;let r=new FileReader();r.onload=()=>{try{let x=JSON.parse(r.result);if(x.data)data=x.data;if(x.config)cfg=x.config;save();applyBrand();show(current);toast('Backup restored')}catch{alert('Invalid backup file.')}};r.readAsText(f)}
function toast(t){let x=document.getElementById('toast');x.textContent=t;x.style.display='block';setTimeout(()=>x.style.display='none',1800)}
function normalizeDumpDate(v){
  const s=String(v??'').trim();
  if(!s)return '';
  let m=s.match(/^(\d{4})[-\/](\d{1,2})[-\/](\d{1,2})(?:[T\s]|$)/);
  if(m){const y=Number(m[1]),mo=Number(m[2]),d=Number(m[3]);if(mo>=1&&mo<=12&&d>=1&&d<=31)return `${y}-${String(mo).padStart(2,'0')}-${String(d).padStart(2,'0')}`;return ''}
  m=s.match(/^(\d{1,2})[-\/](\d{1,2})[-\/](\d{4})(?:[T\s]|$)/);
  if(m){const d=Number(m[1]),mo=Number(m[2]),y=Number(m[3]);if(mo>=1&&mo<=12&&d>=1&&d<=31)return `${y}-${String(mo).padStart(2,'0')}-${String(d).padStart(2,'0')}`;return ''}
  const d=new Date(s);if(Number.isNaN(d.getTime()))return '';
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
}
function monthKeyFromDate(v){return normalizeDumpDate(v).slice(0,7)}
function dumpDateInRange(v,from,to){const k=normalizeDumpDate(v);if(!from&&!to)return true;if(!k)return false;return (!from||k>=from)&&(!to||k<=to)}
function dumpRange(period,from,to){
  const p=String(period||'All Data');
  const today=normalizeDumpDate(todayISO());
  let f='',t=today;
  // Explicit From/To dates always take priority. This fixes the common case
  // where the user enters an Order Date range while the period dropdown is
  // still on All Data. The selected range is therefore never silently ignored.
  const explicitFrom=normalizeDumpDate(from||'');
  const explicitTo=normalizeDumpDate(to||'');
  if(explicitFrom||explicitTo){
    if(explicitFrom&&explicitTo&&explicitFrom>explicitTo)return {from:explicitTo,to:explicitFrom,swapped:true};
    return {from:explicitFrom,to:explicitTo,swapped:false,explicit:true};
  }
  if(p==='All Data'){return {from:'',to:''};}
  if(p==='Custom Date Range'){
    const cf=normalizeDumpDate(from||''),ct=normalizeDumpDate(to||'');
    if(cf&&ct&&cf>ct)return {from:ct,to:cf,swapped:true};
    return {from:cf,to:ct,swapped:false};
  }
  const d=new Date(today+'T00:00:00');
  if(p==='Week-wise'){
    const day=d.getDay();
    const diff=day===0?6:day-1;
    d.setDate(d.getDate()-diff);
    f=d.toISOString().slice(0,10);
  }else if(p==='Month-wise'){
    f=`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-01`;
  }else if(p==='Year-wise'){
    f=`${d.getFullYear()}-01-01`;
  }else{
    return {from:'',to:''};
  }
  return {from:f,to:t};
}
function dumpRowsForRange(from,to,channel){
  const chOk=x=>(!channel||channel==='All'||x.channel===channel||x.marketplace===channel);
  // Data Dump must show automatically on open. Treat every 90+ day order as archived
  // even if an older record was imported before the dumpArchived flag existed.
  const isArchived=o=>!!o.dumpArchived || normalizeDumpDate(o.date)<financialYearStartISO(todayISO());
  const orderIds=new Set((data.marketplaceOrders||[]).filter(o=>isArchived(o)&&chOk(o)&&dumpDateInRange(o.date,from,to)).map(o=>String(o.orderId)));
  const linked=(x)=>!!x?.orderId && orderIds.has(String(x.orderId));
  const inRange=(x)=>dumpDateInRange(x?.date||x?.receivedDate||x?.toDate||x?.fromDate,from,to);
  const orders=(data.marketplaceOrders||[]).filter(o=>isArchived(o)&&chOk(o)&&dumpDateInRange(o.date,from,to));
  return {
    orders:orders,
    settlements:(data.marketplaceSettlements||[]).filter(x=>chOk(x)&&(linked(x)||(!x.orderId&&inRange(x)))),
    returns:(data.marketplaceReturns||[]).filter(x=>chOk(x)&&(linked(x)||(!x.orderId&&inRange(x)))),
    ads:(data.marketplaceAds||[]).filter(x=>chOk(x)&&(linked(x)||(!x.orderId&&inRange(x)))),
    bank:(data.bankTransactions||[]).filter(x=>chOk(x)&&(linked(x)||(!x.orderId&&inRange(x)))),
    purchases:(data.purchases||[]).filter(x=>dumpDateInRange(x.date,from,to))
  };
}
function dumpSummary(d){
  const n=v=>Number(v||0);
  const sales=d.orders.reduce((a,o)=>a+n(o.sellingPrice)*Math.max(1,n(o.qty)),0);
  const gst=d.orders.reduce((a,o)=>a+n(o.gstAmount),0);
  const fees=d.orders.reduce((a,o)=>a+n(o.commission)+n(o.shippingFee)+n(o.adsCost)+n(o.returnCost)+n(o.otherCost),0);
  const received=d.settlements.reduce((a,x)=>a+n(x.netReceived),0);
  const bank=d.bank.reduce((a,x)=>a+n(x.credit),0);
  return {orders:d.orders.length,sales,gst,fees,received,bank,settlements:d.settlements.length,returns:d.returns.length,ads:d.ads.length,purchases:d.purchases.length};
}
function sourceFilesForRange(from,to,channel){
  const files=data.reconSourceFiles||[];
  const chFiles=files.filter(x=>(!channel||channel==='All'||x.channel===channel));
  if(!from&&!to)return chFiles;
  const raw=data.reconRawRows||[];
  const keys=new Set(raw.filter(x=>(!channel||channel==='All'||x.channel===channel)&&dumpDateInRange(x.date,from,to)).map(x=>x.file));
  return chFiles.filter(x=>keys.has(x.file));
}
function downloadOriginalSourceFile(key){
  const f=(data.reconSourceFiles||[]).find(x=>x.key===key);
  if(!f){alert('Original source file not found. Please re-import the file.');return;}
  const blob=new Blob([f.content],{type:'text/csv;charset=utf-8'}),a=document.createElement('a');
  a.href=URL.createObjectURL(blob);a.download=f.file||'Gezeno_Original.csv';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000);
}
function exportOriginalSourceFiles(period,channel,from,to){
  const r=dumpRange(period,from,to),files=sourceFilesForRange(r.from,r.to,channel);
  if(!files.length){alert('Is period/marketplace ke liye original source file available nahi hai. File ko dobara upload karein.');return;}
  const payload={software:'Gezeno Marketplace Reconciliation Suite',dumpType:period,marketplace:channel,range:r,generatedAt:new Date().toISOString(),originalFiles:files.map(x=>({file:x.file,channel:x.channel,type:x.type,importedAt:x.importedAt,format:x.format,exactFileContent:x.content}))};
  const blob=new Blob([JSON.stringify(payload,null,2)],{type:'application/json'}),a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=`Gezeno_Original_Files_${period.replace(/\s+/g,'_')}_${channel}.json`;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000);
}
function exportDataDumpRange(period,channel,from,to){const r=dumpRange(period,from,to),d=dumpRowsForRange(r.from,r.to,channel),s=dumpSummary(d),raw=rawRowsForRange(r.from,r.to,channel);const payload={software:'Gezeno Marketplace Reconciliation Suite',dumpType:period,marketplace:channel,range:r,generatedAt:new Date().toISOString(),orders:d.orders,settlements:d.settlements,returns:d.returns,ads:d.ads,bankTransactions:d.bank,purchases:d.purchases,originalImportedRows:raw,originalFiles:sourceFilesForRange(r.from,r.to,channel).map(x=>({file:x.file,channel:x.channel,type:x.type,importedAt:x.importedAt,format:x.format,exactFileContent:x.content})),summary:s,traceability:{originalRowCount:raw.length,sourceFiles:[...new Set(raw.map(x=>x.file))],note:'Exact original CSV/TXT file content is preserved along with original imported rows, source file, row number and linked IDs.'}};const blob=new Blob([JSON.stringify(payload,null,2)],{type:'application/json'}),a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=`Gezeno_Data_Dump_${period.replace(/\s+/g,'_')}_${channel}.json`;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000)}
function applyDumpFilter(){
  const m=String(document.getElementById('dumpMonth')?.value||'');
  const f=String(document.getElementById('dumpFrom')?.value||'');
  const t=String(document.getElementById('dumpTo')?.value||'');
  if(!m&&!f&&!t){toast('Please select Month-wise or From + To Date first');return}
  if(!m&&((f&&!t)||(!f&&t))){toast('Please select both From and To Date');return}
  if(f&&t&&f>t){alert('From Date cannot be later than To Date.');return}
  let from=f,to=t;
  if(m){
    const [y,mo]=m.split('-').map(Number),last=new Date(y,mo,0).getDate();
    from=`${y}-${String(mo).padStart(2,'0')}-01`;
    to=`${y}-${String(mo).padStart(2,'0')}-${String(last).padStart(2,'0')}`;
  }
  window.dumpMonth=m;
  window.dumpPeriod=(m?'Month-wise':'Custom Date Range');
  window.dumpChannel=document.getElementById('dumpChannel')?.value||'All';
  window.dumpFrom=from;
  window.dumpTo=to;
  window.dumpOrderQuery=document.getElementById('dumpOrderSearch')?.value.trim()||'';
  window.dumpDataActive=true;
  show('dataDump');
}
function dumpSingleOrderMatches(query,channel){
  const q=String(query||'').trim().toLowerCase();
  if(!q)return [];
  return (data.marketplaceOrders||[]).filter(o=>!!o.dumpArchived || normalizeDumpDate(o.date)<financialYearStartISO(todayISO())).filter(o=>{
    const id=String(o.orderId||'').toLowerCase();
    const ch=String(o.channel||o.marketplace||'').toLowerCase();
    return id.includes(q) && (!channel||channel==='All'||ch===String(channel).toLowerCase());
  });
}
function dumpSingleOrderData(order){
  const ch=order.channel||order.marketplace||'';
  const oid=String(order.orderId||'');
  const date=normalizeDumpDate(order.date||'');
  const raw=(data.reconRawRows||[]).filter(x=>String(x.orderId||'').toLowerCase()===oid.toLowerCase());
  const settlements=(data.marketplaceSettlements||[]).filter(x=>String(x.channel||x.marketplace||'')===String(ch)&&(
    String(x.orderId||'').toLowerCase()===oid.toLowerCase() ||
    (date && normalizeDumpDate(x.receivedDate||x.toDate||x.fromDate||'')===date)
  ));
  const returns=(data.marketplaceReturns||[]).filter(x=>String(x.channel||x.marketplace||'')===String(ch)&&String(x.orderId||x.orderID||'').toLowerCase()===oid.toLowerCase());
  const ads=(data.marketplaceAds||[]).filter(x=>String(x.channel||x.marketplace||'')===String(ch)&&String(x.orderId||x.orderID||'').toLowerCase()===oid.toLowerCase());
  const bank=(data.bankTransactions||[]).filter(x=>String(x.channel||x.marketplace||'')===String(ch)&&(
    String(x.orderId||'').toLowerCase()===oid.toLowerCase() || String(x.description||'').toLowerCase().includes(oid.toLowerCase()) || String(x.reference||'').toLowerCase().includes(String(order.awb||'').toLowerCase())
  ));
  const sales=Number(order.sellingPrice||0)*Number(order.qty||1);
  const commission=Number(order.commission||order.marketplaceFee||0);
  const shipping=Number(order.shippingFee||order.shipping||0);
  const adsCost=Number(order.adsCost||0);
  const returnCost=Number(order.returnCost||0);
  const other=Number(order.otherCost||0);
  const gst=Number(order.gstAmount||0);
  const cogs=Number(order.cogs||0);
  const feeGst=Number(order.feeGst||0);
  const tcs=Number(order.tcs||0),tds=Number(order.tds||0);
  const expected=Number(order.expectedSettlement||order.expected||sales-commission-shipping-adsCost-returnCost-other-feeGst-tcs-tds||0);
  const actual=settlements.reduce((a,x)=>a+Number(x.netReceived||x.actualPayout||0),0);
  const bankCredit=bank.reduce((a,x)=>a+Number(x.credit||0),0);
  const diff=(settlements.length?actual:0)-expected;
  const profit=sales-cogs-commission-shipping-adsCost-returnCost-other;
  return {ch,oid,raw,settlements,returns,ads,bank,sales,commission,shipping,adsCost,returnCost,other,gst,cogs,feeGst,tcs,tds,expected,actual,bankCredit,diff,profit};
}
function formatOriginalOrderFieldName(k){
  return String(k||'').replace(/_/g,' ').replace(/\b\w/g,m=>m.toUpperCase());
}
function renderOriginalOrderRows(rows){
  if(!rows||!rows.length) return '<div class="hint">Original order row not found.</div>';
  return rows.map((r,idx)=>{
    const raw=(r&&r.raw&&typeof r.raw==='object')?r.raw:{};
    const entries=Object.entries(raw);
    return `<div class="panel" style="margin:10px 0;border-left:3px solid #1d67c9;background:#fbfcfe">
      <div style="display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap;align-items:center;margin-bottom:8px">
        <div><b>Imported Order Row ${idx+1}</b></div>
        <div class="hint">File: ${esc(r.file||'')} &nbsp; • &nbsp; Row: ${esc(r.rowNumber||'')}</div>
      </div>
      <div style="overflow:auto"><table class="table"><thead><tr><th style="width:34%">Field</th><th>Value</th></tr></thead><tbody>
        ${entries.length?entries.map(([k,v])=>`<tr><td><b>${esc(formatOriginalOrderFieldName(k))}</b></td><td>${esc(v===null||v===undefined?'':(typeof v==='object'?JSON.stringify(v):String(v)))}</td></tr>`).join(''):'<tr><td colspan="2">No original fields found.</td></tr>'}
      </tbody></table></div>
    </div>`;
  }).join('');
}
function renderSingleOrderDump(query,channel){
  const matches=dumpSingleOrderMatches(query,channel);
  if(!String(query||'').trim())return '';
  if(!matches.length)return `<div class="panel"><h3>🔎 Single Order Search</h3><div class="hint">Order ID <b>${esc(query)}</b> nahi mila${channel&&channel!=='All'?' in '+esc(channel):''}.</div></div>`;
  return matches.map(o=>{const x=dumpSingleOrderData(o);return `<div class="panel" style="border-left:4px solid #1d67c9"><div style="display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap;align-items:center"><div><h3 style="margin:0">📦 Order ${esc(x.oid)}</h3><div class="hint">${esc(x.ch)} • ${esc(o.date||'')} • ${esc(o.status||'')} • ${esc(o.customer||'')}</div></div><button class="btn secondary" onclick="window.dumpOrderQuery='';window.dumpDataActive=false;show('dataDump')">Close</button></div><div class="cards"><div class="card">Gross Sale<div class="num">₹${x.sales.toLocaleString('en-IN')}</div></div><div class="card">Sales GST<div class="num">₹${x.gst.toLocaleString('en-IN')}</div></div><div class="card">Commission / Fees<div class="num">₹${(x.commission+x.feeGst).toLocaleString('en-IN')}</div></div><div class="card">Expected Settlement<div class="num">₹${x.expected.toLocaleString('en-IN')}</div></div><div class="card">Actual Received<div class="num">₹${x.actual.toLocaleString('en-IN')}</div></div><div class="card">Difference<div class="num">₹${x.diff.toLocaleString('en-IN')}</div></div><div class="card">Net Profit<div class="num">₹${x.profit.toLocaleString('en-IN')}</div></div></div><div style="overflow:auto"><table class="table"><thead><tr><th>Particular</th><th>Amount / Detail</th></tr></thead><tbody><tr><td>Product / SKU</td><td>${esc(o.productName||o.product||'')} / ${esc(o.sku||'')}</td></tr><tr><td>Qty × Selling Price</td><td>${Number(o.qty||1)} × ₹${Number(o.sellingPrice||0).toLocaleString('en-IN')}</td></tr><tr><td>Commission</td><td>₹${x.commission.toLocaleString('en-IN')}</td></tr><tr><td>Shipping / Logistics</td><td>₹${x.shipping.toLocaleString('en-IN')}</td></tr><tr><td>Ads</td><td>₹${x.adsCost.toLocaleString('en-IN')}</td></tr><tr><td>Return / RTO</td><td>₹${x.returnCost.toLocaleString('en-IN')}</td></tr><tr><td>Other Charges</td><td>₹${x.other.toLocaleString('en-IN')}</td></tr><tr><td>Fee GST</td><td>₹${x.feeGst.toLocaleString('en-IN')}</td></tr><tr><td>TCS / TDS</td><td>₹${x.tcs.toLocaleString('en-IN')} / ₹${x.tds.toLocaleString('en-IN')}</td></tr><tr><td>Settlement Records</td><td>${x.settlements.length}</td></tr><tr><td>Bank Credits</td><td>₹${x.bankCredit.toLocaleString('en-IN')}</td></tr><tr><td>Original Imported Rows</td><td>${x.raw.length}</td></tr></tbody></table></div><h4>Original Order Details</h4><div>${renderOriginalOrderRows(x.raw)}</div></div>`}).join('');
}

window.dumpSelectedOrderIds=window.dumpSelectedOrderIds||new Set();
function toggleDumpOrderSelection(id,checked){if(!window.dumpSelectedOrderIds)window.dumpSelectedOrderIds=new Set();id=String(id);if(checked)window.dumpSelectedOrderIds.add(id);else window.dumpSelectedOrderIds.delete(id);const c=document.querySelector('[data-dump-selection-count]');if(c)c.textContent=window.dumpSelectedOrderIds.size+' selected';}
function toggleAllDumpOrders(checked){if(!window.dumpSelectedOrderIds)window.dumpSelectedOrderIds=new Set();document.querySelectorAll('.dump-select').forEach(cb=>{cb.checked=checked;toggleDumpOrderSelection(cb.dataset.orderid,checked)});const c=document.querySelector('[data-dump-selection-count]');if(c)c.textContent=window.dumpSelectedOrderIds.size+' selected';}
function removeSelectedDumpOrders(){const ids=window.dumpSelectedOrderIds?Array.from(window.dumpSelectedOrderIds):[];if(!ids.length){alert('Please select at least one archived order.');return}if(!confirm('Remove '+ids.length+' selected archived order(s) from Data Dump? This cannot be undone.'))return;const set=new Set(ids);ensureMarketplaceV6();data.marketplaceOrders=(data.marketplaceOrders||[]).filter(o=>!set.has(String(o.orderId)));data.marketplaceSettlements=(data.marketplaceSettlements||[]).filter(x=>!set.has(String(x.orderId||'')));data.marketplaceReturns=(data.marketplaceReturns||[]).filter(x=>!set.has(String(x.orderId||'')));data.marketplaceAds=(data.marketplaceAds||[]).filter(x=>!set.has(String(x.orderId||'')));data.reconRawRows=(data.reconRawRows||[]).filter(x=>!set.has(String(x.orderId||x.raw?.['Order ID']||'')));window.dumpSelectedOrderIds=new Set();save();show('dataDump');}
function removeDumpOrder(id){window.dumpSelectedOrderIds=new Set([String(id)]);removeSelectedDumpOrders()}
function dataDump(){
  autoMoveOldOrdersToDump();
  const dumpDataActive=!!window.dumpDataActive;
  const channel=window.dumpChannel||'All';
  const period=window.dumpPeriod||'All Data';
  const month=window.dumpMonth||'';
  const from=window.dumpFrom||'';
  const to=window.dumpTo||'';
  const q=String(window.dumpOrderQuery||'').trim().toLowerCase();
  const range=dumpRange(period,from,to);
  const base=dumpRowsForRange(range.from,range.to,channel);
  let visible=base.orders;
  if(q) visible=visible.filter(o=>JSON.stringify(o).toLowerCase().includes(q));
  const n=v=>Number(v||0);
  const sales=visible.reduce((a,o)=>a+n(o.sellingPrice)*Math.max(1,n(o.qty)),0);
  const fees=visible.reduce((a,o)=>a+n(o.commission)+n(o.shippingFee)+n(o.adsCost)+n(o.returnCost)+n(o.otherCost),0);
  const gst=visible.reduce((a,o)=>a+n(o.gstAmount),0);
  const ids=new Set(visible.map(o=>String(o.orderId)));
  const settlements=base.settlements.filter(x=>!x.orderId||ids.has(String(x.orderId)));
  const returns=base.returns.filter(x=>!x.orderId||ids.has(String(x.orderId)));
  const ads=base.ads.filter(x=>!x.orderId||ids.has(String(x.orderId)));
  const bank=base.bank.filter(x=>!x.orderId||ids.has(String(x.orderId)));
  const raw=(data.reconRawRows||[]).filter(x=>ids.has(String(x.orderId||''))||(x.type==='Orders'&&visible.some(o=>String(o.orderId)===String(x.raw?.['Order ID']||''))));
  const received=settlements.reduce((a,x)=>a+n(x.netReceived),0), bankCredit=bank.reduce((a,x)=>a+n(x.credit),0);
  const archivedTotal=archivedMarketplaceOrders().filter(o=>!channel||channel==='All'||o.channel===channel).length;
  const activeTotal=activeMarketplaceOrders().length;
  const orderCards=visible.length?visible.map(o=>{
    const ss=settlements.filter(x=>String(x.orderId||'')===String(o.orderId));
    const rr=returns.filter(x=>String(x.orderId||'')===String(o.orderId));
    const aa=ads.filter(x=>String(x.orderId||'')===String(o.orderId));
    const bb=bank.filter(x=>String(x.orderId||'')===String(o.orderId));
    const actual=ss.reduce((a,x)=>a+n(x.netReceived),0);
    const expected=n(o.expectedSettlement||o.sellingPrice)-n(o.commission)-n(o.shippingFee)-n(o.adsCost)-n(o.returnCost)-n(o.otherCost)-n(o.tcs)-n(o.tds);
    const diff=actual-expected;
    const rraw=(data.reconRawRows||[]).filter(x=>String(x.orderId||'')===String(o.orderId)||String(x.raw?.['Order ID']||'')===String(o.orderId));
    return `<tr><td><input class="dump-select" data-orderid="${esc(o.orderId)}" type="checkbox" ${window.dumpSelectedOrderIds?.has(String(o.orderId))?'checked':''} onchange="toggleDumpOrderSelection(this.dataset.orderid,this.checked)" onclick="event.stopPropagation()"></td><td><b>${esc(o.orderId)}</b></td><td>${esc(o.channel)}</td><td>${esc(formatDate(o.date))}</td><td>₹${n(o.sellingPrice).toLocaleString('en-IN')}</td><td>₹${n(o.commission).toLocaleString('en-IN')}</td><td>₹${n(o.gstAmount).toLocaleString('en-IN')}</td><td>${ss.length}</td><td>₹${actual.toLocaleString('en-IN')}</td><td>₹${bb.reduce((a,x)=>a+n(x.credit),0).toLocaleString('en-IN')}</td><td><span class="badge ${Math.abs(diff)<0.01?'green':'red'}">₹${diff.toLocaleString('en-IN')}</span></td><td>${rr.length}/${aa.length}/${rraw.length}<br><span class="mini-muted">RTO/Ads/Raw</span></td><td><button class="btn" onclick="window.dumpOrderQuery='${esc(o.orderId)}';window.dumpDataActive=true;show('dataDump')">View</button><button class="del" onclick="event.stopPropagation();removeDumpOrder('${esc(o.orderId)}')">Remove</button></td></tr>`;
  }).join(''):'<tr><td colspan="13" class="hint">No archived orders match the selected filters.</td></tr>';
  const periodLabel=period==='Custom Date Range'&&range.from?`${range.from} → ${range.to||range.from}`:period;
  const dateHint=range.swapped?'From Date and To Date were reversed. The system corrected the order automatically.':'';
  return `<div class="reporthero"><div style="display:flex;justify-content:space-between;gap:18px;align-items:center;flex-wrap:wrap"><div><h2>🗄 DATA DUMP — ARCHIVE DASHBOARD</h2><div style="opacity:.9">Separate archive dashboard • 90+ day orders only • ${esc(periodLabel)}</div></div><div class="quick"><button class="btn" onclick="show('marketplaceControl')">← Order Center</button><button class="btn secondary" onclick="exportDataDumpRange('${esc(period)}','${esc(channel)}','${esc(range.from)}','${esc(range.to)}')">⬇ Export Selected Dump</button></div></div></div>
  <div class="panel"><div class="order-date-filter-row" style="display:flex;align-items:flex-end;gap:14px;flex-wrap:wrap;margin-top:0;padding:14px 16px;border:1px solid #e5e7eb;border-radius:12px;background:#f8fafc"><div><div class="hint" style="font-weight:700;margin-bottom:5px">Order Date Filter</div><div class="hint">Select the date range and click Apply Filter.</div></div><label class="field" style="min-width:180px"><span>Month-wise</span><input id="dumpMonth" type="month" value="${esc(month)}"></label><label class="field" style="min-width:180px"><span>From Date</span><input id="dumpFrom" type="date" value="${esc(from)}"></label><label class="field" style="min-width:180px"><span>To Date</span><input id="dumpTo" type="date" value="${esc(to)}"></label><label class="field"><span>Marketplace</span><select id="dumpChannel"><option ${channel==='All'?'selected':''}>All</option><option ${channel==='Amazon'?'selected':''}>Amazon</option><option ${channel==='Flipkart'?'selected':''}>Flipkart</option><option ${channel==='Meesho'?'selected':''}>Meesho</option></select></label><button class="btn" onclick="applyDumpFilter()">✓ Apply Filter</button><button class="btn secondary" onclick="window.dumpMonth='';window.dumpPeriod='All Data';window.dumpChannel='All';window.dumpFrom='';window.dumpTo='';window.dumpOrderQuery='';window.dumpDataActive=false;show('dataDump')">Reset &amp; Lock Data</button></div><div class="order-toolbar" style="margin-top:10px"><label class="field" style="min-width:240px;flex:1"><span>🔎 Single Order Search</span><input id="dumpOrderSearch" placeholder="Search Order ID" value="${esc(window.dumpOrderQuery||'')}" onkeydown="if(event.key==='Enter')applyDumpFilter()"></label></div><div class="hint">${esc(dateHint)} Select a month or enter both From Date and To Date, then click Apply Filter. The selected Order Date range will be applied to archived data.</div></div>
  <div id="dumpResults" style="display:${dumpDataActive?'block':'none'}">
  <div class="finance-kpis"><div class="finance-kpi"><div class="label">Archived Orders</div><div class="value">${visible.length}</div><div class="hint">Selected period • ${archivedTotal} total archived</div></div><div class="finance-kpi"><div class="label">Order Center Active</div><div class="value">${activeTotal}</div><div class="hint">0–89 days only</div></div><div class="finance-kpi"><div class="label">Archived Gross Sales</div><div class="value">₹${sales.toLocaleString('en-IN')}</div></div><div class="finance-kpi"><div class="label">Sales GST</div><div class="value">₹${gst.toLocaleString('en-IN')}</div></div><div class="finance-kpi"><div class="label">Marketplace Charges</div><div class="value">₹${fees.toLocaleString('en-IN')}</div></div><div class="finance-kpi good"><div class="label">Settlement Received</div><div class="value">₹${received.toLocaleString('en-IN')}</div></div><div class="finance-kpi"><div class="label">Bank Credit</div><div class="value">₹${bankCredit.toLocaleString('en-IN')}</div></div></div>
  ${renderSingleOrderDump(window.dumpOrderQuery||'',channel)}
  <div class="panel"><h3>📦 Archived Orders — ${esc(channel)} — ${esc(periodLabel)}</h3><div class="order-toolbar" style="margin-bottom:10px"><button class="btn secondary" type="button" onclick="toggleAllDumpOrders(true)">☑ Select All</button><button class="btn" type="button" onclick="toggleAllDumpOrders(false)">☐ Clear Selection</button><span data-dump-selection-count class="hint" style="min-width:90px">${window.dumpSelectedOrderIds?.size||0} selected</span><button class="del" type="button" onclick="removeSelectedDumpOrders()">🗑 Remove Selected</button></div><div style="overflow:auto"><table class="table"><thead><tr><th><input type="checkbox" title="Select all visible archived orders" onchange="toggleAllDumpOrders(this.checked)"></th><th>Order ID</th><th>Marketplace</th><th>Order Date</th><th>Sale</th><th>Commission</th><th>GST</th><th>Settlements</th><th>Received</th><th>Bank</th><th>Difference</th><th>Linked Data</th><th></th></tr></thead><tbody>${orderCards}</tbody></table></div></div>
  <div class="panel"><h3>🔗 Dump Reconciliation Summary</h3><div style="overflow:auto"><table class="table"><thead><tr><th>Data</th><th>Records</th><th>Amount / Status</th></tr></thead><tbody><tr><td>Orders / Sales</td><td>${visible.length}</td><td>₹${sales.toLocaleString('en-IN')}</td></tr><tr><td>Payment / Settlement</td><td>${settlements.length}</td><td>₹${received.toLocaleString('en-IN')} received</td></tr><tr><td>Ads / Charges</td><td>${ads.length}</td><td>Linked to archived orders</td></tr><tr><td>Bank Reconciliation</td><td>${bank.length}</td><td>₹${bankCredit.toLocaleString('en-IN')} credit</td></tr><tr><td>Original Imported Rows</td><td>${raw.length}</td><td>Source-level traceability</td></tr></tbody></table></div></div>
  </div>
  <div class="panel"><h3>🤖 Automatic Archive Status</h3><div class="hint">Rule: <b>Financial Year (1 April – 31 March)</b>. Financial year close hone ke baad previous FY ke orders automatically Order Center se hide hote hain aur Data Dump mein permanently available rehte hain. Data delete nahi hota.</div><div class="cards" style="margin-top:12px"><div class="card">Last Auto-Run<div class="num" style="font-size:14px">${esc(data.dumpAutomation?.lastRunAt||'Not run yet')}</div></div><div class="card">Moved in Last Run<div class="num">${n(data.dumpAutomation?.movedLastRun)}</div></div><div class="card">Rule<div class="num" style="font-size:16px">Previous FY</div></div></div></div>`;
}


function buildNavigation(){
 const groups=[
  {title:'MAIN',items:[['dashboard','🏠 Main Dashboard']]},{title:'RECONCILIATION',items:[['reconciliation','💰 Reconciliation Dashboard'],['pnlDashboard','📈 Profit & Loss'],['calculator','🧮 Price Calculator'],['returnsDashboard','↩ Returns & Refunds'],['dataDump','🗂 Data Dump'],['marketplaceControl','🛒 Order Control'],['marketplaceSettlements','💵 Settlements'],['marketplaceAds','📣 Ads / Charges']]},
  {title:'DATA & TAX',items:[['purchases','📦 Purchases'],['products','🧾 Products'],['vendors','🏭 Vendors'],['stock','📦 Inventory'],['gstr1','🧾 GSTR-1 & GST Reports'],['csvCenter','📥 File Upload'],['reports','📊 Reports']]},
  {title:'SYSTEM',items:[['settings','⚙ Settings']]}
 ];
 const nav=document.getElementById('nav');
 nav.innerHTML=groups.map(g=>`<div class="nav-group-title">${g.title}</div>`+g.items.map(([key,label])=>`<button type="button" data-key="${key}" onclick="show('${key}')">${label}</button>`).join('')).join('');
}
window.pnlDashboardFilters={channel:'All',from:'',to:''};window.dumpPeriod='All Data';window.dumpMonth='';window.dumpChannel='All';window.dumpFrom='';window.dumpTo='';window.dumpOrderQuery='';window.dumpDataActive=false;buildNavigation();
document.getElementById('loginUser').value=cfg.username||'';document.getElementById('loginPass').value='';cleanLegacyB2BDemo();seed();seedMarketplaceDemoV14();seedOriginalDummyFilesV29();
seedReconBankDemo();migrateBusinessData();syncAllPayments();repairOriginalSourceChannels();
removeSettlementDerivedOrders();
save();save();applyBrand();if(sessionStorage.getItem('gezenoLogged')==='1'){document.getElementById('login').style.display='none';document.getElementById('app').style.display='block';applyBrand();show('dashboard');if(typeof mobileShow==='function')mobileShow('dashboard')}


/* ===== Marketplace V6: connected order lifecycle + CSV + reconciliation ===== */
const MP_STATUSES=['New','Confirmed','Packed','Ready for Pickup','Picked Up','Shipped','Out for Delivery','Delivered','Cancelled','Returned'];
function addDaysISO(value,days){
  const k=normalizeDumpDate(value); if(!k)return '';
  const p=k.split('-').map(Number), d=new Date(p[0],p[1]-1,p[2]);
  d.setDate(d.getDate()+Number(days||0));
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
}
function financialYearStartISO(dateValue){
  const d=new Date(String(dateValue||todayISO())+'T00:00:00');
  if(Number.isNaN(d.getTime())) return '';
  const y=d.getFullYear(), m=d.getMonth()+1;
  const fyStartYear=m>=4?y:y-1;
  return `${fyStartYear}-04-01`;
}
function orderFinancialYear(orderDate){
  const d=normalizeDumpDate(orderDate); if(!d)return '';
  const y=Number(d.slice(0,4)), m=Number(d.slice(5,7));
  const start=m>=4?y:y-1;
  return `FY ${start}-${String(start+1).slice(-2)}`;
}
function autoMoveOldOrdersToDump(){
  data.marketplaceOrders=data.marketplaceOrders||[];
  const fyStart=financialYearStartISO(todayISO());
  let moved=0;
  data.marketplaceOrders.forEach(o=>{
    if(o.dumpArchived)return;
    const orderDate=normalizeDumpDate(o.date||'');
    if(!orderDate || !fyStart)return;
    // Indian financial year: 1 April to 31 March. Anything before the
    // current FY is automatically archived in Data Dump.
    if(orderDate<fyStart){
      o.dumpArchived=true;
      o.dumpArchivedAt=new Date().toISOString();
      o.dumpArchiveReason=`Automatically moved to Data Dump after financial year closed (${orderFinancialYear(orderDate)})`;
      o.dumpFinancialYear=orderFinancialYear(orderDate);
      moved++;
    }
  });
  data.dumpAutomation=data.dumpAutomation||{};
  data.dumpAutomation.lastRunAt=new Date().toISOString();
  data.dumpAutomation.movedLastRun=moved;
  data.dumpAutomation.rule='Previous Financial Year (1 April – 31 March)';
  data.dumpAutomation.currentFinancialYear=orderFinancialYear(todayISO());
  data.dumpAutomation.orderCenterWindow='Current Financial Year';
  if(moved){save();if(typeof toast==='function')setTimeout(()=>toast(`${moved} order(s) moved to Data Dump after financial year close`),0);}
  return moved;
}
function activeMarketplaceOrders(){const fyStart=financialYearStartISO(todayISO());return (data.marketplaceOrders||[]).filter(o=>!o.dumpArchived && (!fyStart || normalizeDumpDate(o.date)>=fyStart))}
function archivedMarketplaceOrders(){const fyStart=financialYearStartISO(todayISO());return (data.marketplaceOrders||[]).filter(o=>!!o.dumpArchived || (!!fyStart && normalizeDumpDate(o.date)<fyStart))}

function ensureMarketplaceV6(){
  data.marketplaceOrders=(data.marketplaceOrders||[]).map(o=>({...o,
    orderId:o.orderId||o.marketplaceOrderId||o.orderNo||nextNo('MP','marketplaceOrders','orderId'),
    channel:o.channel||'Amazon',customer:o.customer||'',sku:o.sku||'',qty:Number(o.qty||1),
    sellingPrice:Number(o.sellingPrice||o.orderAmount||0),gstRate:Number(o.gstRate||0),gstAmount:Number(o.gstAmount||o.salesGst||0),commission:Number(o.commission||o.marketplaceFee||0),feeGst:Number(o.feeGst||o.marketplaceFeeGst||0),
    shippingFee:Number(o.shippingFee||0),adsCost:Number(o.adsCost||0),returnCost:Number(o.returnCost||0),otherCost:Number(o.otherCost||0),
    courier:o.courier||'',awb:o.awb||'',pickupDate:o.pickupDate||'',shippedDate:o.shippedDate||'',
    outForDeliveryDate:o.outForDeliveryDate||'',deliveryDate:o.deliveryDate||'',cancelDate:o.cancelDate||'',
    status:MP_STATUSES.includes(o.status)?o.status:'New',paymentStatus:o.paymentStatus||'Pending',
    stockDeducted:!!o.stockDeducted,stockRestored:!!o.stockRestored,dumpArchived:!!o.dumpArchived,dumpArchivedAt:o.dumpArchivedAt||'',dumpEligibleDate:o.dumpEligibleDate||''
  }));
  data.marketplaceFeeRules=data.marketplaceFeeRules||{
    Amazon:{referralPct:15,closingFee:20,shippingFee:55,collectionPct:1,adsPct:2.5,returnReservePct:2,tcsPct:1,tdsPct:0.1,feeGstPct:18,otherFee:0},
    Flipkart:{referralPct:14,closingFee:20,shippingFee:50,collectionPct:1,adsPct:2,returnReservePct:2,tcsPct:1,tdsPct:0.1,feeGstPct:18,otherFee:0},
    Meesho:{referralPct:0,closingFee:0,shippingFee:45,collectionPct:0,adsPct:1.5,returnReservePct:3,tcsPct:1,tdsPct:0.1,feeGstPct:18,otherFee:0}
  };
  ['Amazon','Flipkart','Meesho'].forEach(ch=>{const r=data.marketplaceFeeRules[ch]||{};data.marketplaceFeeRules[ch]={referralPct:num(r.referralPct),closingFee:num(r.closingFee),shippingFee:num(r.shippingFee),collectionPct:num(r.collectionPct),adsPct:num(r.adsPct),returnReservePct:num(r.returnReservePct),tcsPct:num(r.tcsPct),tdsPct:num(r.tdsPct),feeGstPct:num(r.feeGstPct||18),otherFee:num(r.otherFee)}});
  ensurePricingSlabs();
  data.marketplaceSettlements=(data.marketplaceSettlements||[]).map(x=>({...x,
    settlementId:x.settlementId||x.settlement||nextNo('SET','marketplaceSettlements','settlementId'),
    channel:x.channel||'Amazon',gross:Number(x.gross||x.orderAmount||0),salesGst:Number(x.salesGst||x.gst||x.gstAmount||x.outputGst||0),fees:Number(x.fees||x.marketplaceFees||0),feeGst:Number(x.feeGst||x.feesGst||x.marketplaceFeeGst||x.commissionGst||0),
    tcs:Number(x.tcs||0),tds:Number(x.tds||0),refunds:Number(x.refunds||0),shipping:Number(x.shipping||x.shippingCharges||0),otherDeductions:Number(x.otherDeductions||x.otherDeduction||0),adjustments:Number(x.adjustments||x.adjustment||0),
    netReceived:Number(x.netReceived||x.actualPayout||x.payout||0),receivedDate:x.receivedDate||x.bankDate||'',bankRef:x.bankRef||x.utr||x.transactionRef||'',status:x.status||'Pending'
  }));
  save();
}
function mpInventoryAdjust(o, delta){
  const p=data.products.find(x=>String(x.sku||'')===String(o.sku||''));
  if(!p)return;
  p.stock=Math.max(0,Number(p.stock||0)+delta*Number(o.qty||0));
  let st=(data.stock||[]).find(x=>x.sku===p.sku); if(st)st.inStock=p.stock;
}
function updateMarketplaceStatus(index,newStatus){
  const o=data.marketplaceOrders[index]; if(!o)return;
  const old=o.status; if(old===newStatus)return;
  const fulfillment=['Packed','Ready for Pickup','Picked Up','Shipped','Out for Delivery','Delivered'];
  const returnish=['RTO','Returned','Cancelled'];
  if(fulfillment.includes(newStatus) && !o.stockDeducted){mpInventoryAdjust(o,-1);o.stockDeducted=true;o.stockRestored=false;}
  if(returnish.includes(newStatus) && o.stockDeducted && !o.stockRestored){mpInventoryAdjust(o,1);o.stockRestored=true;}
  const d=todayISO();
  if(newStatus==='Picked Up')o.pickupDate=o.pickupDate||d;
  if(newStatus==='Shipped')o.shippedDate=o.shippedDate||d;
  if(newStatus==='Out for Delivery')o.outForDeliveryDate=o.outForDeliveryDate||d;
  if(newStatus==='Delivered')o.deliveryDate=o.deliveryDate||d;
  if(newStatus==='Cancelled')o.cancelDate=o.cancelDate||d;
  o.status=newStatus; autoMoveOldOrdersToDump(); save(); show('marketplaceControl'); toast(`${o.orderId}: ${newStatus}`);
}
function csvEsc(v){const s=String(v??'');return /[",\n]/.test(s)?'"'+s.replace(/"/g,'""')+'"':s}
function downloadCSV(filename,headers,rows){const csv=[headers.join(','),...rows.map(r=>headers.map(h=>csvEsc(r[h]??'')).join(','))].join('\n');const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8'}));a.download=filename;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000)}
function parseCSV(text){
  text=String(text||'').replace(/^\uFEFF/,'');
  const firstLines=text.split(/\r?\n/).slice(0,5).join('\n');
  const commas=(firstLines.match(/,/g)||[]).length, tabs=(firstLines.match(/\t/g)||[]).length, semis=(firstLines.match(/;/g)||[]).length;
  const delimiter=tabs>commas&&tabs>=semis?'\t':semis>commas?';':',';
  const rows=[];let row=[],cell='',quote=false;
  for(let i=0;i<text.length;i++){const c=text[i],n=text[i+1];if(c==='"'){if(quote&&n==='"'){cell+='"';i++;}else quote=!quote;}else if(c===delimiter&&!quote){row.push(cell.trim());cell='';}else if((c==='\n'||c==='\r')&&!quote){if(c==='\r'&&n==='\n')i++;row.push(cell.trim());if(row.some(x=>x!==''))rows.push(row);row=[];cell='';}else cell+=c;}
  if(cell!==''||row.length){row.push(cell.trim());if(row.some(x=>x!==''))rows.push(row)}
  if(!rows.length)return[];const headers=rows[0].map(x=>String(x).trim());return rows.slice(1).map(r=>Object.fromEntries(headers.map((h,i)=>[h,r[i]??''])));
}
function normKey(k){return String(k||'').toLowerCase().replace(/^\uFEFF/,'').replace(/[^a-z0-9]/g,'')}
function pick(row,aliases,def=''){const m={};Object.keys(row).forEach(k=>m[normKey(k)]=row[k]);for(const a of aliases){const v=m[normKey(a)];if(v!==undefined&&String(v).trim()!=='')return v}return def}
function num(v){const n=Number(String(v??'').replace(/[,₹%]/g,''));return Number.isFinite(n)?n:0}
/* Gezeno amount display: preserve two decimal digits; hide only .00.
   A single decimal input such as 900.4 is treated as 900.04 per the requested display rule. */
(function(){
  const _nativeNumberToLocaleString=Number.prototype.toLocaleString;
  Number.prototype.toLocaleString=function(locales,options){
    if(locales==='en-IN' && this>=0 || locales==='en-IN' && this<0){
      const n=Number(this);
      if(Number.isFinite(n)){
        const raw=String(Math.abs(n));
        const parts=raw.split('.');
        let display=n;
        let specialOneDecimal=false;
        if(parts.length===2 && parts[1].length===1){
          specialOneDecimal=true;
        }
        const opts=Object.assign({},options||{}, {minimumFractionDigits:0, maximumFractionDigits:2});
        let out=_nativeNumberToLocaleString.call(n,'en-IN',opts);
        if(specialOneDecimal){
          const sign=n<0?'-':'';
          const intPart=Math.trunc(Math.abs(n)).toLocaleString('en-IN');
          out=sign+intPart+'.0'+parts[1];
        }
        return out;
      }
    }
    return _nativeNumberToLocaleString.call(this,locales,options);
  };
})();
/* Amount display rule: preserve two decimal digits when present, hide only .00.
   A single decimal digit is treated as the hundredths digit: 900.4 -> 900.04. */
(function(){
  const __toFixed=Number.prototype.toFixed;
  Number.prototype.toFixed=function(d){
    if(d===2){
      const s=String(this.valueOf());
      if(Number.isFinite(this.valueOf())){
        const a=s.split('.');
        if(a.length===1 || /^0+$/.test(a[1]||'')) return a[0];
        if((a[1]||'').length===1) return a[0]+'.0'+a[1];
      }
    }
    return __toFixed.call(this,d);
  };
  const __toLocaleString=Number.prototype.toLocaleString;
  Number.prototype.toLocaleString=function(locales,options){
    const n=this.valueOf();
    if(Number.isFinite(n)){
      const s=String(n), d=s.split('.')[1]||'';
      if(d.length===1){
        const adjusted=Number(s.split('.')[0]+'.0'+d);
        return __toLocaleString.call(adjusted,locales,options);
      }
    }
    return __toLocaleString.call(this,locales,options);
  };
})();
function normalizeMarketplaceStatus(v){const x=String(v||'').trim().toLowerCase();if(!x)return'New';if(/rto|return to origin|returntoporigin/.test(x))return'RTO';if(/return|returned|customer return/.test(x))return'Returned';if(/cancel|cancelled|canceled/.test(x))return'Cancelled';if(/delivered|complete|completed/.test(x))return'Delivered';if(/out for delivery|outfordelivery|ofd/.test(x))return'Out for Delivery';if(/picked|pickup|pick up/.test(x))return'Picked Up';if(/ship|dispatch|in transit|transit/.test(x))return'Shipped';if(/ready/.test(x))return'Ready for Pickup';if(/pack/.test(x))return'Packed';if(/confirm|accepted/.test(x))return'Confirmed';return MP_STATUSES.includes(v)?v:'New'}
function marketplaceFieldMap(channel){
  const common={
    id:['orderId','marketplaceOrderId','orderNo','orderNumber','orderID','order-id','amazonOrderId','amazonOrderID','orderItemId','orderItemID','subOrderNo','subOrderNum','subOrderNumber','sub_order_num','sub_order_number','flipkartOrderId','order_item_id'],
    date:['date','orderDate','orderDateTime','purchaseDate','orderCreationDate','orderDateUTC','createdAt','createdDate'],
    customer:['customer','customerName','buyerName','buyer','recipientName','shipToName','customer_name','buyer_name'],
    sku:['sku','sellerSku','sellerSKU','productSku','merchantSku','merchantSKU','merchant_sku','seller_sku','product_sku','fsn'],
    product:['product','productName','itemName','title','productTitle','listingTitle','itemTitle'],
    qty:['qty','quantity','itemQuantity','itemQty','units','orderQty','orderedQuantity','quantityOrdered'],
    selling:['sellingPrice','orderAmount','itemTotal','amount','itemPrice','itemPriceTotal','price','salePrice','selling_price','finalAmount','final_amount','totalAmount','totalPrice','invoiceAmount','customerPaidAmount'],
    commission:['commission','marketplaceFee','marketplaceFees','fees','referralFee','referralFees','commissionAmount','sellingFee'],
    shipping:['shippingFee','shipping','shippingCharges','shippingCharge','deliveryFee','logisticsFee','forwardShipping','forwardShippingFee'],
    ads:['adsCost','advertisingCost','adSpend','advertisingFee','marketingFee'],
    returns:['returnCost','reverseShipping','reverseShippingFee','returnShipping','returnFee'],
    courier:['courier','logisticsProvider','carrier','deliveryPartner','shippingProvider','fulfillmentProvider'],
    awb:['awb','trackingId','trackingNumber','trackingNo','trackingNumberId','awbNumber','shipmentId','tracking_id'],
    status:['status','orderStatus','order_status','itemStatus','shipmentStatus','deliveryStatus','currentStatus'],
    payment:['paymentStatus','settlementStatus','payment_status','paymentMode','paymentMethod'],
    address:['shippingAddress','shipToAddress','address','customerAddress','deliveryAddress','shipping_address'],
    city:['city','shippingCity','shipToCity'],state:['state','shippingState','shipToState'],pincode:['pincode','pinCode','postalCode','zipCode','shippingPincode'],phone:['phone','mobile','customerPhone','buyerPhone','contactNumber']
  };
  if(channel==='Amazon'){
    common.id.push('amazonOrderId','amazonOrderID');common.sku.push('sku1','merchantSku');common.selling.push('itemPrice','itemPriceTax','itemPriceTaxExcluded');common.status.push('orderStatus','itemStatus');common.awb.push('trackingNumber','carrierTrackingNumber');
  } else if(channel==='Flipkart'){
    common.id.push('orderItemId','order_item_id','orderId');common.sku.push('sellerSku','seller_sku','sku');common.selling.push('sellingPrice','finalAmount','customerPrice');common.awb.push('trackingId','trackingNumber');
  } else if(channel==='Meesho'){
    common.id.push('subOrderNum','subOrderNumber','sub_order_num','orderNumber');common.sku.push('sku','supplierSku','supplier_sku');common.selling.push('supplierPrice','finalAmount','productPrice','sellingPrice');common.awb.push('awbNumber','awb','trackingNumber');
  }
  return common;
}
function storeRawImportRows(rows,channel,type,fileName,fileContent){
  data.reconRawRows=data.reconRawRows||[];
  data.reconSourceFiles=data.reconSourceFiles||[];
  const now=new Date().toISOString();
  const sourceKey=`${channel}|${type}|${fileName}`;
  const source={key:sourceKey,channel,type,file:fileName,importedAt:now,content:String(fileContent||''),format:'CSV/TXT'};
  const sourceIndex=data.reconSourceFiles.findIndex(x=>x.key===sourceKey);
  if(sourceIndex>=0) data.reconSourceFiles[sourceIndex]=source; else data.reconSourceFiles.push(source);
  rows.forEach((r,i)=>{
    const orderId=String(pick(r,['orderId','orderID','orderNumber','amazonOrderId','amazonOrderID','orderItemId','order_item_id','subOrderNum','subOrderNumber','sub_order_num'],'')).trim();
    const settlementId=String(pick(r,['settlementId','settlement','settlementNumber','transactionId'],'')).trim();
    const date=String(pick(r,['date','orderDate','transactionDate','settlementDate','receivedDate','paymentDate','fromDate','toDate'],'')).trim();
    const key=`${channel}|${type}|${fileName}|${i}|${orderId}|${settlementId}`;
    const existing=data.reconRawRows.find(x=>x.key===key);
    const item={key,channel,type,file:fileName,rowNumber:i+1,importedAt:now,date,orderId,settlementId};
    if(existing)Object.assign(existing,item);else data.reconRawRows.push(item);
  });
}
function rawRowsForRange(from,to,channel){
  return (data.reconRawRows||[]).filter(d=>(!channel||channel==='All'||d.channel===channel)&&dumpDateInRange(d.date,from,to));
}
async function importFlipkartOrderWorkbook(input,channel){
  const f=input.files?.[0]; if(!f)return;
  try{
    const {sheets}=await readXlsxFile(f);
    if(channel!=='Flipkart') throw new Error('Ye Excel Order mapping abhi Flipkart ke liye enabled hai.');
    // Gezeno Flipkart export: Sales Report + Cash Back Report. Is format me "Orders" sheet nahi hoti.
    // Directly existing robust Sales/Cashback mapper ko use karein.
    const hasFlipkartSales=!!sheets.find(x=>String(x.name).trim().toLowerCase()==='sales report');
    const hasFlipkartCash=!!sheets.find(x=>String(x.name).trim().toLowerCase()==='cash back report');
    if(hasFlipkartSales || hasFlipkartCash){
      await importFlipkartWorkbook(input,channel);
      return;
    }
    const sheet=sheets.find(x=>String(x.name).trim().toLowerCase()==='orders') || sheets.find(x=>String(x.name).trim().toLowerCase().includes('order'));
    const rows=sheet?.rows||[];
    if(!rows.length) throw new Error('Flipkart Excel me Orders sheet/data rows nahi mile.');
    const aliases={
      orderId:['order_id','order id','orderId','orderid'], orderItemId:['order_item_id','order item id','orderItemId'],
      fulfilmentSource:['fulfilment_source','fulfillment_source'], fulfilmentType:['fulfilment_type','fulfillment_type'],
      date:['order_date','order date'], approvalDate:['order_approval_date','order approval date'], status:['order_item_status','order item status','status'],
      sku:['sku','seller sku'], fsn:['fsn'], product:['product_title','product title','product_title_description'], qty:['quantity','item quantity','qty'],
      deliveryPartner:['delivery_logistics_partner','delivery logistics partner'], pickupPartner:['pickup_logistics_partner','pickup logistics partner'],
      tracking:['delivery_tracking_id','delivery tracking id','tracking_id','tracking id'], cancellationDate:['order_cancellation_date'], cancellationReason:['cancellation_reason'], cancellationSubReason:['cancellation_sub_reason'],
      returnApprovalDate:['order_return_approval_date'], returnId:['return_id'], returnReason:['return_reason'], returnSubReason:['return_sub_reason'],
      dispatchSla:['procurement_dispatch_sla'], dispatchAfter:['dispatch_after_date'], dispatchBy:['dispatch_by_date'], readyDate:['order_ready_for_dispatch_on_date'], dispatchedDate:['dispatched_date'], dispatchBreached:['dispatch_sla_breached'],
      pickupReattempts:['seller_pickup_reattempts'], deliverySla:['delivery_sla'], deliverBy:['deliver_by_date'], deliveryDate:['order_delivery_date'], deliveryBreached:['delivery_sla_breached'],
      serviceCompletionDate:['order_service_completion_date'], serviceBy:['service_by_date'], serviceCompletionSla:['service_completion_sla'], serviceBreached:['service_sla_breached']
    };
    const norm=v=>String(v??'').trim().toLowerCase().replace(/[\s\-]+/g,'_');
    const headerMap={}; const headers=sheet.headers||Object.keys(rows[0]||{}); headers.forEach(h=>headerMap[norm(h)]=h);
    const pickA=(r,names,def='')=>{for(const n of names){const h=headerMap[norm(n)]; if(h && String(r[h]??'').trim()!=='') return r[h];} return def};
    data.marketplaceOrders=data.marketplaceOrders||[];
    data.reconSourceFiles=data.reconSourceFiles||[];
    const raw=JSON.stringify({workbook:f.name,sheet:sheet.name,headers,rows});
    storeRawImportRows(rows,'Flipkart','Flipkart Orders XLSX',f.name,raw);
    let added=0,updated=0,skipped=0;
    for(const r of rows){
      const id=String(pickA(r,aliases.orderId)).trim(); if(!id){skipped++;continue;}
      const sku=String(pickA(r,aliases.sku)).trim(); const qty=Math.max(1,num(pickA(r,aliases.qty,1)));
      const date=excelDate(pickA(r,aliases.date,'')); const rawStatus=String(pickA(r,aliases.status,'New')).trim();
      const status=normalizeMarketplaceStatus(rawStatus);
      let o=data.marketplaceOrders.find(x=>String(x.orderId)===id && x.channel==='Flipkart');
      if(!o){o={orderId:id,channel:'Flipkart',items:[],stockDeducted:false,stockRestored:false,isOrderRecord:true,orderImportSource:'Orders File'};data.marketplaceOrders.push(o);added++;}else{o.isOrderRecord=true;o.orderImportSource=o.orderImportSource||'Orders File';updated++;}
      Object.assign(o,{orderId:id,channel:'Flipkart',date,sku,product:String(pickA(r,aliases.product,'')),qty,fulfilmentSource:String(pickA(r,aliases.fulfilmentSource,'')),fulfilmentType:String(pickA(r,aliases.fulfilmentType,'')),orderItemId:String(pickA(r,aliases.orderItemId,'')),fsn:String(pickA(r,aliases.fsn,'')),status,paymentStatus:o.paymentStatus||'Pending',courier:String(pickA(r,aliases.deliveryPartner,'')),pickupCourier:String(pickA(r,aliases.pickupPartner,'')),awb:String(pickA(r,aliases.tracking,'')),orderApprovalDate:excelDate(pickA(r,aliases.approvalDate,'')),cancelDate:excelDate(pickA(r,aliases.cancellationDate,'')),cancellationReason:String(pickA(r,aliases.cancellationReason,'')),cancellationSubReason:String(pickA(r,aliases.cancellationSubReason,'')),returnApprovalDate:excelDate(pickA(r,aliases.returnApprovalDate,'')),returnId:String(pickA(r,aliases.returnId,'')),returnReason:String(pickA(r,aliases.returnReason,'')),returnSubReason:String(pickA(r,aliases.returnSubReason,'')),procurementDispatchSla:String(pickA(r,aliases.dispatchSla,'')),dispatchAfterDate:excelDate(pickA(r,aliases.dispatchAfter,'')),dispatchByDate:excelDate(pickA(r,aliases.dispatchBy,'')),readyForDispatchDate:excelDate(pickA(r,aliases.readyDate,'')),dispatchedDate:excelDate(pickA(r,aliases.dispatchedDate,'')),dispatchSlaBreached:String(pickA(r,aliases.dispatchBreached,'')),sellerPickupReattempts:num(pickA(r,aliases.pickupReattempts,0)),deliverySla:String(pickA(r,aliases.deliverySla,'')),deliverByDate:excelDate(pickA(r,aliases.deliverBy,'')),deliveryDate:excelDate(pickA(r,aliases.deliveryDate,'')),deliverySlaBreached:String(pickA(r,aliases.deliveryBreached,'')),serviceCompletionDate:excelDate(pickA(r,aliases.serviceCompletionDate,'')),serviceByDate:excelDate(pickA(r,aliases.serviceBy,'')),serviceCompletionSla:String(pickA(r,aliases.serviceCompletionSla,'')),serviceSlaBreached:String(pickA(r,aliases.serviceBreached,'')),items:[{sku,name:String(pickA(r,aliases.product,sku)),qty,amount:num(o.sellingPrice||0)}]});
      o.items=o.items||[]; if(!o.items.some(it=>String(it.sku||'')===sku)){o.items.push({sku,name:String(pickA(r,aliases.product,sku)),qty,amount:0});}
      if(['Cancelled','RTO','Returned'].includes(status)) o.returnStatus=status;
    }
    ensureMarketplaceV6(); autoMoveOldOrdersToDump(); save(); show('marketplaceControl');
    toast(`Flipkart Order Excel mapped: ${added} new, ${updated} updated${skipped?`, ${skipped} rows skipped`:''}`);
  }catch(e){alert('Flipkart Order Excel upload failed: '+e.message)} finally{input.value=''}
}

function importMarketplaceFile(input,channel){
  const f=input.files?.[0];if(!f)return;
  const reader=new FileReader();reader.onload=()=>{try{
    const rows=parseCSV(String(reader.result||''));if(!rows.length)throw new Error('CSV is empty');
    storeRawImportRows(rows,channel,'Orders',f.name,String(reader.result||''));
    const map=marketplaceFieldMap(channel);let added=0,updated=0,skipped=0;
    rows.forEach(r=>{
      const id=String(pick(r,map.id)).trim();if(!id){skipped++;return;}
      const existing=data.marketplaceOrders.find(x=>String(x.orderId)===id);
      const o=existing||{orderId:id,channel,items:[],stockDeducted:false,stockRestored:false,isOrderRecord:true,orderImportSource:'Orders File'};
      o.isOrderRecord=true;o.orderImportSource=o.orderImportSource||'Orders File';
      const qty=Math.max(1,num(pick(r,map.qty,1))), sku=String(pick(r,map.sku)).trim(), price=num(pick(r,map.selling,0));
      const itemKey=sku||String(pick(r,map.product,'Item'));
      const item=o.items.find(x=>String(x.sku||x.name)===itemKey);
      if(item){item.qty+=qty;item.amount+=price||0}else o.items.push({sku,name:pick(r,map.product,sku),qty,amount:price||0});
      const rawStatus=pick(r,map.status,'New'), status=normalizeMarketplaceStatus(rawStatus);
      Object.assign(o,{channel:channel||pick(r,['channel','marketplace'],'Amazon'),date:pick(r,map.date,todayISO()),customer:pick(r,map.customer),customerPhone:pick(r,map.phone),shippingAddress:pick(r,map.address),city:pick(r,map.city),state:pick(r,map.state),pincode:pick(r,map.pincode),sku:sku||o.sku||'',product:pick(r,map.product,o.product||''),qty:num(o.qty)+qty,sellingPrice:num(o.sellingPrice)+price,commission:num(o.commission)+num(pick(r,map.commission,0)),shippingFee:num(o.shippingFee)+num(pick(r,map.shipping,0)),adsCost:num(o.adsCost)+num(pick(r,map.ads,0)),returnCost:num(o.returnCost)+num(pick(r,map.returns,0)),courier:pick(r,map.courier,o.courier||''),awb:pick(r,map.awb,o.awb||''),status,paymentStatus:pick(r,map.payment,o.paymentStatus||'Pending')});
      if(!existing && ['Packed','Ready for Pickup','Picked Up','Shipped','Out for Delivery','Delivered'].includes(o.status)&&!o.stockDeducted){mpInventoryAdjust(o,-1);o.stockDeducted=true}
      if(existing && ['Cancelled','RTO','Returned'].includes(o.status)&&o.stockDeducted&&!o.stockRestored){mpInventoryAdjust(o,1);o.stockRestored=true}
      if(existing)updated++;else{data.marketplaceOrders.push(o);added++}
    });
    ensureMarketplaceV6();save();show('marketplaceControl');toast(`${channel}: ${added} new, ${updated} updated${skipped?`, ${skipped} rows skipped`:''}`)
  }catch(e){alert('CSV import failed: '+e.message)}finally{input.value=''}};reader.readAsText(f)
}
function excelDate(v){const x=String(v??'').trim();if(!x)return'';if(/^\d+(\.\d+)?$/.test(x)){const n=Number(x);if(n>20000&&n<80000){const d=new Date(Date.UTC(1899,11,30)+n*86400000);return d.toISOString().slice(0,10)}}return x.slice(0,10)}
async function browserReadXlsx(arrayBuffer){
  const b=new Uint8Array(arrayBuffer), dv=new DataView(arrayBuffer), td=new TextDecoder('utf-8');
  const u16=o=>dv.getUint16(o,true), u32=o=>dv.getUint32(o,true);
  let eocd=-1; for(let i=b.length-22;i>=Math.max(0,b.length-65558);i--){if(u32(i)===0x06054b50){eocd=i;break;}}
  if(eocd<0) throw new Error('Invalid XLSX: ZIP directory not found');
  const count=u16(eocd+10), cdOff=u32(eocd+16), entries={}; let o=cdOff;
  for(let i=0;i<count;i++){
    if(u32(o)!==0x02014b50) throw new Error('Invalid XLSX central directory');
    const method=u16(o+10), csize=u32(o+20), nlen=u16(o+28), elen=u16(o+30), clen=u16(o+32), loff=u32(o+42);
    const name=td.decode(b.slice(o+46,o+46+nlen)); entries[name]={method,csize,loff}; o+=46+nlen+elen+clen;
  }
  async function read(name){const e=entries[name];if(!e)throw new Error('Missing XLSX entry: '+name);const nlen=u16(e.loff+26),elen=u16(e.loff+28),start=e.loff+30+nlen+elen,raw=b.slice(start,start+e.csize);if(e.method===0)return raw;if(e.method!==8)throw new Error('Unsupported XLSX compression method');if(typeof DecompressionStream==='undefined')throw new Error('This browser cannot decompress XLSX files. Please use the Windows desktop app.');const ds=new DecompressionStream('deflate-raw');const ab=await new Response(new Blob([raw]).stream().pipeThrough(ds)).arrayBuffer();return new Uint8Array(ab)}
  const xmlText=async name=>td.decode(await read(name));
  const unesc=x=>{const t=document.createElement('textarea');t.innerHTML=String(x??'');return t.value};
  const ss=[]; if(entries['xl/sharedStrings.xml']){const doc=new DOMParser().parseFromString(await xmlText('xl/sharedStrings.xml'),'application/xml');doc.querySelectorAll('si').forEach(si=>ss.push(Array.from(si.querySelectorAll('t')).map(t=>t.textContent).join('')))}
  const wbDoc=new DOMParser().parseFromString(await xmlText('xl/workbook.xml'),'application/xml');
  const relDoc=entries['xl/_rels/workbook.xml.rels']?new DOMParser().parseFromString(await xmlText('xl/_rels/workbook.xml.rels'),'application/xml'):null;
  const relMap={}; if(relDoc) relDoc.querySelectorAll('Relationship').forEach(r=>{let t=r.getAttribute('Target')||'';if(t.startsWith('/'))t=t.slice(1);if(!t.startsWith('xl/'))t='xl/'+t;relMap[r.getAttribute('Id')]=t});
  const sheets=[];
  const sheetNodes=wbDoc.querySelectorAll('sheet');
  for(let si=0;si<sheetNodes.length;si++){
    const sh=sheetNodes[si];
    const name=sh.getAttribute('name')||'', path=relMap[sh.getAttribute('r:id')]; if(!path||!entries[path])continue;
    const doc=new DOMParser().parseFromString(await xmlText(path),'application/xml'), grid=[], rowEls=doc.querySelectorAll('sheetData > row'); let maxCol=0;
    for(let ri=0;ri<rowEls.length;ri++){
      const row=rowEls[ri], cells=[], cellNodes=row.getElementsByTagName('c');
      for(let ci=0;ci<cellNodes.length;ci++){
        const c=cellNodes[ci], ref=c.getAttribute('r')||'', m=ref.match(/^([A-Z]+)\d+$/); if(!m)continue;
        let col=0; const letters=m[1];
        for(let li=0;li<letters.length;li++)col=col*26+letters.charCodeAt(li)-64;
        col--; let v=''; const typ=c.getAttribute('t')||'', ve=c.getElementsByTagName('v')[0];
        if(typ==='inlineStr'){const ts=c.getElementsByTagName('t');let parts='';for(let ti=0;ti<ts.length;ti++)parts+=(ts[ti].textContent||'');v=parts;}
        else if(ve)v=ve.textContent||'';
        if(typ==='s')v=ss[Number(v)]??'';
        cells[col]=unesc(v); maxCol=Math.max(maxCol,col);
      }
      grid.push(cells);
    }
    const gridBeforeHeader=grid.map(r=>Array.isArray(r)?r.slice():r);
    const headers=(grid.shift()||[]).map(x=>String(x??'').trim()), objects=[];
    for(let ri=0;ri<grid.length;ri++){
      const r=grid[ri], obj={}; let nonEmpty=false;
      for(let hi=0;hi<headers.length;hi++){const h=headers[hi]; if(h){const val=r[hi]??'';obj[h]=val;if(String(val).trim()!=='')nonEmpty=true;}}
      if(nonEmpty)objects.push(obj);
    }
    // Keep the complete worksheet grid as well as the normalized rows. Some Flipkart
    // reports have title/meta rows before the actual header row; payment importer uses
    // rawGrid so the exact A/BG/BP column positions are never shifted or lost.
    sheets.push({name,rows:objects,headers,grid,rawGrid:gridBeforeHeader});
  }
  if(!sheets.length)throw new Error('No readable worksheets found'); return sheets;
}
async function readXlsxFile(file){return await new Promise((resolve,reject)=>{const r=new FileReader();r.onload=async()=>{try{const ab=r.result;const u8=new Uint8Array(ab);let bin='';for(let i=0;i<u8.length;i+=0x8000)bin+=String.fromCharCode(...u8.subarray(i,i+0x8000));const b64=btoa(bin);if(window.gezeno&&typeof window.gezeno.readXlsx==='function'){const out=await window.gezeno.readXlsx(b64);if(!out.ok)throw new Error(out.error||'XLSX read failed');resolve({sheets:out.sheets,base64:b64});}else{const sheets=await browserReadXlsx(ab);resolve({sheets,base64:b64});}}catch(e){reject(e)}};r.onerror=()=>reject(new Error('File read failed'));r.readAsArrayBuffer(file)})}
async function readXlsxFileGrid(file){return await new Promise((resolve,reject)=>{const r=new FileReader();r.onload=async()=>{try{const ab=r.result;const sheets=await browserReadXlsx(ab);resolve({sheets});}catch(e){reject(e)}};r.onerror=()=>reject(new Error('File read failed'));r.readAsArrayBuffer(file)})}
function fkNorm(v){return String(v??'').replace(/\r?\n/g,' ').replace(/\s+/g,' ').trim().toLowerCase().replace(/[^a-z0-9]+/g,'');}
function flipkartSettlementHeaderIndex(grid){
  const max=Math.min(grid.length,120);
  for(let i=0;i<max;i++){
    const vals=(grid[i]||[]).map(fkNorm);
    const hasOrder=vals.some(v=>v==='orderid'||v.includes('orderid'));
    const hasNeft=vals.some(v=>v==='neftid'||v.includes('neftid'));
    const hasBank=vals.some(v=>v.includes('banksettlementvalue'));
    if(hasOrder&&hasNeft&&(hasBank||vals.some(v=>v.includes('paymentdate'))))return i;
  }
  for(let i=0;i<max;i++){
    const vals=(grid[i]||[]).map(fkNorm);
    if(vals.some(v=>v==='orderid'||v.includes('orderid')) && vals.some(v=>v==='neftid'||v.includes('neftid')))return i;
  }
  return -1;
}
function flipkartSettlementRowsFromSheet(sh){
  const grid=sh?.rawGrid||sh?.grid||[];
  const hi=flipkartSettlementHeaderIndex(grid);
  if(hi<0)return [];
  const headers=(grid[hi]||[]).map(v=>String(v??'').trim());
  const out=[];
  // Flipkart's populated Orders report has a fixed column layout.  Use the
  // documented positions first so duplicate/long formula headers cannot cause
  // a fuzzy header match to select the wrong column.
  const fixed={
    // Exact Flipkart Orders.xlsx column positions (A=0).
    'NEFT ID':0,'Payment Date':2,'Bank Settlement Value (Rs.)':3,
    'Order ID':7,'Order item ID':8,'Sale Amount (Rs.)':9,'Total Offer Amount (Rs.)':10,
    'Marketplace Fee (Rs.)':13,'Taxes (Rs.)':14,'Offer Adjustments (Rs.)':15,
    'Protection Fund (Rs.)':16,'Refund (Rs.)':17,'Commission (Rs.)':21,'Fixed Fee (Rs.)':22,
    'Collection Fee (Rs.)':23,'Pick And Pack Fee (Rs.)':24,'Shipping Fee (Rs.)':25,
    'Reverse Shipping Fee (Rs.)':26,'TCS (Rs.)':36,'TDS (Rs.)':37,'GST on MP Fees (Rs.)':38,
    'Seller SKU':58,'Quantity':59,'Item Return Status':64,'Return Type':62,
    'Invoice ID':66,'Invoice Date':67
  };
  for(let ri=hi+1;ri<grid.length;ri++){
    const row=grid[ri]||[];
    const o={}; let nonEmpty=false;
    headers.forEach((h,i)=>{if(h){const v=row[i]??'';o[h]=v;if(String(v).trim()!=='')nonEmpty=true;}});
    // Add canonical fixed-position fields. These keys are deliberately unique
    // and are also consumed by rebuildFlipkartPaymentFromRaw().
    Object.entries(fixed).forEach(([name,i])=>{if(i<row.length)o[name]=row[i]??'';});
    const oid=String(o['Order ID']??'').trim(), sid=String(o['NEFT ID']??'').trim();
    if(nonEmpty && (oid||sid)){o.__rowNumber=hi+1+ri;o.__flipkartFixedMap=true;out.push(o);}
  }
  return out;
}
function fkGet(r,aliases,def=''){const map=r||{};const keys=Object.keys(map);const wanted=aliases.map(fkNorm);for(const k of keys){const nk=fkNorm(k);if(wanted.includes(nk))return map[k];}for(const k of keys){const nk=fkNorm(k);if(wanted.some(w=>w&&nk.includes(w)))return map[k];}return def;}
function importFlipkartSettlementWorkbook(input,channel){
  const f=input.files?.[0]; if(!f)return;
  readXlsxFileGrid(f).then(({sheets})=>{try{
    if(channel!=='Flipkart') throw new Error('This exact settlement mapping is for Flipkart.');
    // Prefer the actual Flipkart Orders worksheet. Never select GST_Details or
    // another auxiliary sheet just because it happens to contain similar fields.
    const orderedSheets=[...sheets.filter(x=>/^Orders$/i.test(String(x.name||''))),...sheets.filter(x=>!/^Orders$/i.test(String(x.name||'')))];
    const candidates=orderedSheets.map(sh=>({sh,rows:flipkartSettlementRowsFromSheet(sh)})).filter(x=>x.rows.length).sort((a,b)=>{
      const ao=/^Orders$/i.test(String(a.sh.name||''))?1:0, bo=/^Orders$/i.test(String(b.sh.name||''))?1:0;
      return bo-ao || b.rows.length-a.rows.length;
    });
    const hit=candidates[0];
    if(!hit){
      const names=sheets.map(x=>`${x.name}: ${(x.grid||[]).length} rows`).join(', ');
      throw new Error('Flipkart payment report me actual transaction rows nahi mile. Original populated .xlsx report select karein. Sheets checked: '+names);
    }
    const sh=hit.sh, rows=hit.rows;
    // The Flipkart payment workbook is a fixed-column template. A populated file
    // is mapped automatically; an empty/template-only file is rejected without
    // creating zero-value settlements.
    const validOrderRows=rows.filter(r=>{
      const oid=String(r['Order ID']||'').trim();
      const sale=num(r['Sale Amount (Rs.)']??r['Sale Amount']??0);
      const bank=num(r['Bank Settlement Value (Rs.)']??r['Bank Settlement Value']??0);
      return !!oid && (Math.abs(sale)>0.000001 || Math.abs(bank)>0.000001);
    });
    if(!validOrderRows.length) throw new Error('Flipkart payment template/empty report detect hua. Orders sheet me Order ID ke saath Sale Amount ya Bank Settlement Value wali transaction rows nahi hain. Populated payment settlement .xlsx upload karein.');
    data.marketplaceOrders=data.marketplaceOrders||[]; data.marketplaceSettlements=data.marketplaceSettlements||[]; data.marketplaceReturns=data.marketplaceReturns||[];
    // Re-uploading the same payment file must replace that file's prior imported
    // records instead of leaving stale/zero settlements behind. Other source files
    // remain untouched.
    const sourceFileName=String(f.name||'').trim();
    if(sourceFileName){
      data.marketplaceSettlements=data.marketplaceSettlements.filter(x=>!(String(x.channel)==='Flipkart'&&String(x.sourceFile||'')===sourceFileName));
      data.marketplaceOrders=data.marketplaceOrders.filter(x=>!(String(x.channel)==='Flipkart'&&String(x.sourceFile||'')===sourceFileName));
      data.marketplaceReturns=data.marketplaceReturns.filter(x=>!(String(x.channel)==='Flipkart'&&String(x.sourceFile||'')===sourceFileName));
      data.reconRawRows=(data.reconRawRows||[]).filter(x=>!(String(x.channel)==='Flipkart'&&/Payment.*Settlement/i.test(String(x.type||''))&&String(x.file||'')===sourceFileName));
      data.reconUploads=(data.reconUploads||[]).filter(x=>!(String(x.channel)==='Flipkart'&&/Payment.*Settlement/i.test(String(x.type||''))&&String(x.file||'')===sourceFileName));
    }
    // Remove only known development/demo Flipkart payment records. Never remove real uploaded records.
    data.marketplaceSettlements=data.marketplaceSettlements.filter(x=>!(String(x.channel)==='Flipkart' && (/^SET-FK-101$/i.test(String(x.settlementId||'')) || /dummy/i.test(String(x.sourceKind||'')))));
    data.marketplaceOrders=data.marketplaceOrders.filter(x=>!(String(x.channel)==='Flipkart' && (/^FK-5003$/i.test(String(x.orderId||'')) || /dummy/i.test(String(x.sourceKind||'')))));
    const groups={}; let orderAdded=0,orderUpdated=0,settlementAdded=0,settlementUpdated=0,returnAdded=0;
    const n=(r,a)=>num(fkGet(r,a,0)); const s=(r,a)=>String(fkGet(r,a,'')).trim(); const d=v=>excelDate(v)||'';
    for(const r of rows){
      const sid=s(r,['NEFT ID','NEFTID','Neft ID']);
      const oid=s(r,['Order ID','OrderID','order_id']);
      const orderItemId=s(r,['Order item ID','Order Item ID','OrderItemID']);
      if(!sid && !oid) continue;
      const paymentDate=d(fkGet(r,['Payment Date',' Payment Date']));
      const orderDate=d(fkGet(r,['Order Date','OrderDate']));
      const invoiceDate=d(fkGet(r,['Invoice Date','InvoiceDate']));
      const bankValue=n(r,['Bank Settlement Value (Rs.)','Bank Settlement Value']);
      const sale=n(r,['Sale Amount (Rs.)','Sale Amount']);
      const offer=n(r,['Total Offer Amount (Rs.)','Total Offer Amount','Offer Amount']);
      const myShare=n(r,['My share (Rs.)','My Share (Rs.)','My Share']);
      const customerAddons=n(r,['Customer Add-ons Amount (Rs.)','Customer Add-ons Amount']);
      const marketplaceFee=n(r,['Marketplace Fee (Rs.)','Marketplace Fee']);
      const taxes=n(r,['Taxes (Rs.)','Taxes']);
      const offerAdjustments=n(r,['Offer Adjustments (Rs.)','Offer Adjustments']);
      const protectionFund=n(r,['Protection Fund (Rs.)','Protection Fund']);
      const refund=n(r,['Refund (Rs.)','Refund']);
      const commission=n(r,['Commission (Rs.)','Commission']);
      const fixedFee=n(r,['Fixed Fee (Rs.)','Fixed Fee']);
      const collectionFee=n(r,['Collection Fee (Rs.)','Collection Fee']);
      const pickPack=n(r,['Pick And Pack Fee (Rs.)','Pick And Pack Fee']);
      const shippingFee=n(r,['Shipping Fee (Rs.)','Shipping Fee']);
      const reverseShipping=n(r,['Reverse Shipping Fee (Rs.)','Reverse Shipping Fee']);
      const noCostEmi=n(r,['No Cost Emi Fee Reimbursement(Rs.)','No Cost Emi Fee Reimbursement']);
      const installationFee=n(r,['Installation Fee (Rs.)','Installation Fee']);
      const techVisitFee=n(r,['Tech Visit Fee (Rs.)','Tech Visit Fee']);
      const uninstallFee=n(r,['Uninstallation & Packaging Fee (Rs.)','Uninstallation & Packaging Fee']);
      const addonRecovery=n(r,['Customer Add-ons Amount Recovery (Rs.)','Customer Add-ons Amount Recovery']);
      const franchiseFee=n(r,['Franchise Fee (Rs.)','Franchise Fee']);
      const shopsyMarketing=n(r,['Shopsy Marketing Fee (Rs.)','Shopsy Marketing Fee']);
      const productCancellation=n(r,['Product Cancellation Fee (Rs.)','Product Cancellation Fee']);
      const tcs=n(r,['TCS (Rs.)','TCS']);
      const tds=n(r,['TDS (Rs.)','TDS']);
      const feeGst=n(r,['GST on MP Fees (Rs.)','GST on MP Fees']);
      const discountInFee=n(r,['Discount in MP fees (Rs.)','Discount in MP fee']);
      const gstOnDiscount=n(r,['GST on Discount (Rs.)','GST on Discount']);
      const totalDiscountInFee=n(r,['Total Discount in MP Fee (Rs.)','Total Discount in MP Fee']);
      const offerAdjustmentTotal=n(r,['Offer Adjustment (Rs.)','Offer Adjustment']);
      const qty=n(r,['Quantity','Qty']);
      const sellerSku=s(r,['Seller SKU','SellerSKU','SKU']);
      const item={transactionType:'Order',orderId:oid,orderItemId,settlementId:sid,neftType:s(r,['Neft Type','NEFT Type']),postedDate:paymentDate,paymentDate,orderDate,invoiceDate,bankSettlementValue:bankValue,saleAmount:sale,totalOfferAmount:offer,myShare,customerAddonsAmount:customerAddons,marketplaceFee,taxes,offerAdjustments,protectionFund,refund,tier:s(r,['Tier']),commissionRate:n(r,['Commission Rate (%)','Commission Rate']),commission,fixedFee,collectionFee,pickAndPackFee:pickPack,shippingFee,reverseShippingFee:reverseShipping,noCostEmiFeeReimbursement:noCostEmi,installationFee,techVisitFee,uninstallationPackagingFee:uninstallFee,customerAddonsRecovery:addonRecovery,franchiseFee,shopsyMarketingFee:shopsyMarketing,productCancellationFee:productCancellation,tcs,tds,feeGst,offerAmountSettledAsDiscount:n(r,['Offer amount settled as Discount in MP Fee (Rs.)']),itemGstRate:n(r,['Item GST Rate (%)','Item GST Rate']),discountInMarketplaceFee:discountInFee,gstOnDiscount,totalDiscountInMarketplaceFee:totalDiscountInFee,offerAdjustmentTotal,sellerSku,sku:sellerSku,quantity:qty,productSubCategory:s(r,['Product Sub Category']),additionalInformation:s(r,['Additional Information']),returnType:s(r,['Return Type']),shopsyOrder:s(r,['Shopsy Order']),itemReturnStatus:s(r,['Item Return Status']),invoiceId:s(r,['Invoice ID']),raw:r,rowNumber:r.__rowNumber,principal:sale,tax:Math.abs(taxes),shipping:Math.abs(shippingFee)+Math.abs(reverseShipping),closingFee:Math.abs(fixedFee),fulfillmentShipping:Math.abs(pickPack),netPayout:bankValue};
      const g=groups[sid]||(groups[sid]={sid,rows:[],paymentDate:'',bankTotal:0,dates:[]});
      g.rows.push(item); g.bankTotal+=bankValue; if(!g.paymentDate&&paymentDate)g.paymentDate=paymentDate; if(orderDate)g.dates.push(orderDate);
      if(oid){
        const isReturn=/return|refund|cancel/i.test(`${item.itemReturnStatus} ${item.returnType}`) || refund<0;
        let o=data.marketplaceOrders.find(x=>String(x.orderId)===oid&&x.channel==='Flipkart');
        const feeBreakdown={commission,fixedFee,collectionFee,pickAndPackFee:pickPack,shippingFee,reverseShippingFee:reverseShipping,noCostEmiFeeReimbursement:noCostEmi,installationFee,techVisitFee,uninstallationPackagingFee:uninstallFee,customerAddonsRecovery:addonRecovery,franchiseFee,shopsyMarketingFee:shopsyMarketing,productCancellationFee:productCancellation,marketplaceFee,feeGst};
        const obj={orderId:oid,channel:'Flipkart',date:orderDate||paymentDate,customer:'',sku:item.sku,qty,sellingPrice:sale,gstAmount:Math.abs(taxes),taxableSale:Math.max(0,sale-Math.abs(taxes)),commission:Math.abs(commission),feeGst:Math.abs(feeGst),shippingFee:Math.abs(shippingFee)+Math.abs(reverseShipping),adsCost:0,returnCost:Math.abs(refund),otherCost:Math.max(0,Math.abs(marketplaceFee)-Math.abs(commission)-Math.abs(fixedFee)-Math.abs(collectionFee)-Math.abs(pickPack)-Math.abs(shippingFee)-Math.abs(reverseShipping)),courier:'Flipkart',awb:'',status:isReturn?'Returned':'Delivered',paymentStatus:'Settled',settlementId:sid,settlementNet:bankValue,bankSettlementValue:bankValue,neftType:item.neftType,neftId:sid,paymentDate,orderItemId,invoiceId:item.invoiceId,invoiceDate,productSubCategory:item.productSubCategory,returnType:item.returnType,itemReturnStatus:item.itemReturnStatus,tcs:Math.abs(tcs),tds:Math.abs(tds),feeBreakdown,flipkartSettlementId:sid,flipkartSettlementItem:item,sourceFile:f.name,sourceKind:'Flipkart Payment Settlement',originalImportedRow:r};
        if(o){Object.assign(o,obj);o.isOrderRecord=true;orderUpdated++;}else{ /* Payment file enriches only an existing Order Center order; it never creates one. */ }
        if(isReturn){const rid=`FK-${oid}-${orderItemId||'RETURN'}`;if(!data.marketplaceReturns.some(x=>x.returnId===rid)){data.marketplaceReturns.push({returnId:rid,orderId:oid,channel:'Flipkart',date:orderDate||paymentDate,sku:item.sku,qty:Math.abs(qty),reason:item.returnType||item.itemReturnStatus,refund:Math.abs(refund),reverseShipping:Math.abs(reverseShipping),status:item.itemReturnStatus||'Returned',loss:0,sourceFile:f.name});returnAdded++;}}
      }
    }
    Object.values(groups).forEach(g=>{
      const gross=g.rows.reduce((a,x)=>a+x.saleAmount,0), salesGst=g.rows.reduce((a,x)=>a+Math.abs(x.taxes),0), fees=g.rows.reduce((a,x)=>a+Math.abs(x.marketplaceFee),0), tcs=g.rows.reduce((a,x)=>a+Math.abs(x.tcs),0), tds=g.rows.reduce((a,x)=>a+Math.abs(x.tds),0), refunds=g.rows.reduce((a,x)=>a+Math.abs(x.refund),0), shipping=g.rows.reduce((a,x)=>a+Math.abs(x.shippingFee)+Math.abs(x.reverseShippingFee),0), feeGst=g.rows.reduce((a,x)=>a+Math.abs(x.feeGst),0), from=[...g.dates].sort()[0]||g.paymentDate, to=[...g.dates].sort().at(-1)||g.paymentDate;
      const obj={settlementId:g.sid,channel:'Flipkart',fromDate:from,toDate:to,gross,salesGst,fees,feeGst,tcs,tds,refunds,shipping,otherDeductions:0,adjustments:g.rows.reduce((a,x)=>a+x.offerAdjustments+x.offerAdjustmentTotal,0),netReceived:g.bankTotal,expected:g.bankTotal,actualReceived:g.bankTotal,receivedDate:g.paymentDate,bankRef:g.sid,status:'Reconciled',sourceKind:'Flipkart Payment Settlement',sourceFile:f.name,orderCount:g.rows.filter(x=>x.orderId).length,items:g.rows,difference:0,neftType:g.rows[0]?.neftType||'',reportSheet:sh.name};
      const st=data.marketplaceSettlements.find(x=>String(x.settlementId)===g.sid&&x.channel==='Flipkart');
      if(st){Object.assign(st,obj);settlementUpdated++;}else{data.marketplaceSettlements.push(obj);settlementAdded++;}
    });
    // Remove stale template/meta rows from older Flipkart payment imports.
    data.reconRawRows=(data.reconRawRows||[]).filter(x=>{
      if(String(x.channel)!=='Flipkart' || !/Payment.*Settlement/i.test(String(x.type||''))) return true;
      const rr=x.raw||{};
      const oid=String(fkGet(rr,['Order ID','OrderID','order_id'],'')).trim();
      return !!oid;
    });
    storeRawImportRows(rows,'Flipkart','Flipkart Payment Settlement',f.name,JSON.stringify({workbook:f.name,sheet:sh.name,rows}));
    data.reconUploads=[...(data.reconUploads||[]),{at:new Date().toLocaleString('en-IN'),channel:'Flipkart',type:'Payment / Settlement',file:f.name,rows:rows.length,sourceKind:'Flipkart Payment Settlement'}];
    ensureMarketplaceV6(); save(); show('reconciliation'); toast(`Flipkart Payment Report mapped: ${orderAdded} new orders, ${orderUpdated} updated, ${settlementAdded} settlements, ${rows.length} transaction rows.`);
  }catch(e){alert('Flipkart Payment Report mapping failed: '+e.message)}finally{input.value=''}}).catch(e=>{alert('Flipkart Payment Report upload failed: '+e.message);input.value=''})
}

function importFlipkartWorkbook(input,channel){const f=input.files?.[0];if(!f)return;readXlsxFile(f).then(({sheets})=>{try{
  const sales=(sheets.find(x=>String(x.name).trim().toLowerCase()==='sales report')||{}).rows||[];
  const cash=(sheets.find(x=>String(x.name).trim().toLowerCase()==='cash back report')||{}).rows||[];
  if(channel!=='Flipkart'||(!sales.length&&!cash.length))throw new Error('Flipkart workbook read ho gaya, lekin Sales Report / Cash Back Report me data rows nahi mile.');
  const raw=JSON.stringify({workbook:f.name,sheets:sheets.map(x=>({name:x.name,rows:x.rows}))});
  if(sales.length)storeRawImportRows(sales,channel,'Flipkart Sales Report',f.name,raw); if(cash.length)storeRawImportRows(cash,channel,'Flipkart Cash Back Report',f.name,raw);
  data.marketplaceOrders=data.marketplaceOrders||[]; data.marketplaceReturns=data.marketplaceReturns||[];
  const groups={}; let added=0,updated=0,retN=0;
  for(const r of sales){
    const oid=String(pick(r,['Order ID','OrderID','orderId'])).trim(); if(!oid)continue;
    const itemId=String(pick(r,['Order Item ID','OrderItemID'],'')).trim();
    const event=String(pick(r,['Event Type'],'Sale')).trim(); const sub=String(pick(r,['Event Sub Type'],'')).trim();
    const sign=/return|cancel|void/i.test(`${event} ${sub}`)?-1:1; const date=excelDate(pick(r,['Order Date','OrderDate'],''));
    const qty=num(pick(r,['Item Quantity','Quantity'],1))*sign;
    const invoice=Math.abs(num(pick(r,['Final Invoice Amount (Price after discount+Shipping Charges)','Final Invoice Amount','Buyer Invoice Amount','Invoice Amount'],0)))*sign;
    const taxable=Math.abs(num(pick(r,['Taxable Value (Final Invoice Amount -Taxes)','Taxable Value'],0)))*sign;
    const igst=Math.abs(num(pick(r,['IGST Amount'],0)))*sign, cgst=Math.abs(num(pick(r,['CGST Amount'],0)))*sign, sgst=Math.abs(num(pick(r,['SGST Amount (Or UTGST as applicable)','SGST Amount'],0)))*sign;
    const gst=igst+cgst+sgst; const tcs=Math.abs(num(pick(r,['Total TCS Deducted'],0)))*sign; const tds=Math.abs(num(pick(r,['TDS Amount'],0)))*sign;
    const sku=String(pick(r,['SKU'],'')).trim(), product=String(pick(r,['Product Title/Description'],'')).trim(), hsn=String(pick(r,['HSN Code','HSN'],'')).trim();
    const obj={orderId:oid,channel:'Flipkart',date:date||'',customer:'',sku,product,qty,sellingPrice:invoice,taxableSale:taxable,gstAmount:gst,igstAmount:igst,cgstAmount:cgst,sgstAmount:sgst,tcs,tds,shippingFee:Math.abs(num(pick(r,['Shipping Charges'],0)))*sign,commission:0,feeGst:0,adsCost:0,returnCost:sign<0?Math.abs(invoice):0,otherCost:0,status:sign<0?'Returned':'New',paymentStatus:'Pending',orderItemId:itemId,hsn,eventType:event,eventSubType:sub,orderType:String(pick(r,['Order Type'],'')),fulfilmentType:String(pick(r,['Fulfilment Type','Fulfillment Type'],'')),invoiceId:String(pick(r,['Buyer Invoice ID','Invoice ID'],'')),invoiceDate:excelDate(pick(r,['Buyer Invoice Date','Invoice Date'],'')),buyerInvoiceAmount:sign*Math.abs(num(pick(r,['Buyer Invoice Amount'],0))),priceBeforeDiscount:sign*num(pick(r,['Price before discount'],0)),totalDiscount:sign*num(pick(r,['Total Discount'],0)),sellerShare:sign*num(pick(r,['Seller Share'],0)),bankOfferShare:sign*num(pick(r,['Bank Offer Share'],0)),priceAfterDiscount:sign*num(pick(r,['Price after discount (Price before discount-Total discount)'],0)),billingPincode:String(pick(r,["Customer's Billing Pincode",'Billing Pincode'],'')),billingState:String(pick(r,["Customer's Billing State",'Billing State'],'')),deliveryPincode:String(pick(r,["Customer's Delivery Pincode",'Delivery Pincode'],'')),deliveryState:String(pick(r,["Customer's Delivery State",'Delivery State'],'')),items:[{orderItemId:itemId,sku,name:product,hsn,qty:Math.abs(qty),amount:Math.abs(invoice),eventType:event,eventSubType:sub}],sourceFile:f.name,sourceKind:'Flipkart Sales Report'};
    let o=groups[oid]; if(!o)o=groups[oid]=obj; else {o.qty+=qty;o.sellingPrice+=invoice;o.taxableSale+=taxable;o.gstAmount+=gst;o.igstAmount+=igst;o.cgstAmount+=cgst;o.sgstAmount+=sgst;o.tcs+=tcs;o.tds+=tds;o.shippingFee+=obj.shippingFee;o.returnCost+=obj.returnCost;o.items.push(...obj.items);if(sign<0)o.status='Returned';if(itemId)o.orderItemId=itemId;o.sku=o.sku||sku;o.product=o.product||product;o.hsn=o.hsn||hsn;o.invoiceId=o.invoiceId||obj.invoiceId;o.invoiceDate=o.invoiceDate||obj.invoiceDate;}
  }
  Object.values(groups).forEach(o=>{const ex=data.marketplaceOrders.find(x=>String(x.orderId)===String(o.orderId)&&x.channel==='Flipkart');if(ex){Object.assign(ex,o);updated++}else{data.marketplaceOrders.push(o);added++}});
  for(const r of cash){
    const oid=String(pick(r,['Order ID'],'')).trim(); if(!oid)continue; const itemId=String(pick(r,['Order Item ID'],'')).trim(); const doc=String(pick(r,['Document Type'],'')).trim(), sub=String(pick(r,['Document Sub Type'],'')).trim();
    const amt=num(pick(r,['Invoice Amount'],0)); const tax=num(pick(r,['IGST Amount'],0))+num(pick(r,['CGST Amount'],0))+num(pick(r,['SGST Amount (Or UTGST as applicable)'],0));
    const cb={orderId:oid,orderItemId:itemId,documentType:doc,documentSubType:sub,documentId:String(pick(r,['Credit Note ID/ Debit Note ID'],'')),invoiceAmount:amt,taxableValue:num(pick(r,['Taxable Value'],0)),igstAmount:num(pick(r,['IGST Amount'],0)),cgstAmount:num(pick(r,['CGST Amount'],0)),sgstAmount:num(pick(r,['SGST Amount (Or UTGST as applicable)'],0)),totalTcs:num(pick(r,['Total TCS Deducted'],0)),tdsAmount:num(pick(r,['TDS Amount'],0)),invoiceDate:excelDate(pick(r,['Invoice Date'],'')),deliveryState:String(pick(r,["Customer's Delivery State",'Delivery State'],'')),sourceFile:f.name};
    const o=data.marketplaceOrders.find(x=>String(x.orderId)===oid&&x.channel==='Flipkart'); if(o){o.cashBackRecords=o.cashBackRecords||[];o.cashBackRecords.push(cb);o.cashBackAmount=num(o.cashBackAmount)+amt;o.cashBackTax=num(o.cashBackTax)+tax;if(/debit|return|cancellation/i.test(`${doc} ${sub}`)){o.returnCost=num(o.returnCost)+Math.abs(amt);o.status='Returned';}}
    if(/return|cancellation/i.test(sub)){const rid=String(pick(r,['Credit Note ID/ Debit Note ID'],''))||`FK-RET-${oid}-${itemId}`;const rr={returnId:rid,channel:'Flipkart',orderId:oid,date:excelDate(pick(r,['Invoice Date'],'')),sku:'',qty:1,reason:`${doc} / ${sub}`,refund:Math.abs(amt),reverseShipping:0,status:'Received',loss:0,sourceFile:f.name};const ex=data.marketplaceReturns.find(x=>String(x.returnId)===rid);if(ex)Object.assign(ex,rr);else data.marketplaceReturns.push(rr);retN++;}
  }
  ensureMarketplaceV6();autoMoveOldOrdersToDump();save();show('marketplaceControl');toast(`Flipkart Sales Report mapped: ${added} new orders, ${updated} updated, ${retN} returns/cashback records linked. Payment Settlement file alag upload karke reconciliation complete karein.`);
}catch(e){alert('Flipkart Order Report mapping failed: '+e.message)}finally{input.value=''}}).catch(e=>{alert('Flipkart Excel upload failed: '+e.message);input.value=''})}

function importSettlementFile(input,channel){const f=input.files?.[0];if(!f)return;if(/\.xlsx?$/i.test(f.name)){if(channel==='Flipkart'){readXlsxFileGrid(f).then(({sheets})=>{const sh=sheets.find(x=>String(x.name).trim().toLowerCase()==='orders');const isSettlement=sh&&flipkartSettlementHeaderIndex(sh.grid||[])>=0;if(isSettlement)importFlipkartSettlementWorkbook(input,channel);else importFlipkartWorkbook(input,channel)}).catch(e=>{alert('Flipkart Excel upload failed: '+e.message);input.value=''});return}alert('Excel settlement mapping abhi Flipkart ke liye enabled hai. Amazon/Meesho ke liye CSV upload karein.');return}const reader=new FileReader();reader.onload=()=>{try{const rows=parseCSV(String(reader.result||''));if(!rows.length)throw new Error('CSV is empty');storeRawImportRows(rows,channel,'Payment / Settlement',f.name,String(reader.result||''));
// Generic marketplace settlement format: settlement-id / net-payout-amount style files (including Flipkart-exported CSV variants).
if(rows.some(r=>Object.prototype.hasOwnProperty.call(r,'settlement-id')) && rows.some(r=>Object.prototype.hasOwnProperty.call(r,'net-payout-amount'))){
 const groups={}; rows.forEach(r=>{const sid=String(r['settlement-id']||'').trim();if(!sid)return;(groups[sid]??=[]).push(r)});
 let added=0,updated=0; Object.entries(groups).forEach(([sid,rs])=>{const first=rs[0]||{};const sum=k=>rs.reduce((a,r)=>a+num(r[k]),0);const gross=sum('principal-amount')+sum('tax-amount')+sum('shipping-amount')+sum('shipping-tax-amount');const fees=Math.abs(sum('commission-fee'))+Math.abs(sum('fixed-closing-fee'))+Math.abs(sum('fulfillment-shipping-fee'));const tcs=Math.abs(sum('tcs-tax-deduction'));const tds=Math.abs(sum('tds-tax-deduction'));const net=sum('net-payout-amount');const dates=rs.map(r=>excelDate(r['posted-date']||r['settlement-start-date'])).filter(Boolean).sort();const from=excelDate(first['settlement-start-date']);const to=excelDate(first['settlement-end-date']);const received=excelDate(first['deposit-date']);const bankRef=String(first['settlement-id']||'').trim();const items=rs.map((r,ri)=>({transactionType:String(r['transaction-type']||'Order'),orderId:String(r['order-id']||r['merchant-order-id']||'').trim(),merchantOrderId:String(r['merchant-order-id']||'').trim(),postedDate:excelDate(r['posted-date']||''),sku:String(r['sku']||'').trim(),qty:num(r['quantity-purchased']),principal:num(r['principal-amount']),tax:num(r['tax-amount']),shipping:num(r['shipping-amount']),shippingTax:num(r['shipping-tax-amount']),commission:num(r['commission-fee']),closingFee:num(r['fixed-closing-fee']),fulfillmentShipping:num(r['fulfillment-shipping-fee']),tcs:num(r['tcs-tax-deduction']),tds:num(r['tds-tax-deduction']),netPayout:num(r['net-payout-amount']),raw:r,rowNumber:ri+2}));const x=data.marketplaceSettlements.find(z=>String(z.settlementId)===sid)||{settlementId:sid};Object.assign(x,{settlementId:sid,channel:channel||'Flipkart',fromDate:from||dates[0]||'',toDate:to||dates[dates.length-1]||'',gross,fees,tcs,tds,salesGst:sum('tax-amount'),feeGst:0,refunds:0,shipping:sum('shipping-amount')+sum('shipping-tax-amount'),otherDeductions:0,adjustments:0,netReceived:net,receivedDate:received,bankRef,status:'Reconciled',sourceKind:'Marketplace Settlement CSV',sourceFile:f.name,items});if(data.marketplaceSettlements.includes(x))updated++;else{data.marketplaceSettlements.push(x);added++}
// Build order-level records directly from the Flipkart settlement rows so Payment Reconciliation can search and display each order.
items.filter(it=>it.orderId&&String(it.transactionType).toLowerCase()==='order').forEach(it=>{let o=data.marketplaceOrders.find(z=>String(z.orderId)===it.orderId&&z.channel==='Flipkart');const grossLine=it.principal+it.tax+it.shipping+it.shippingTax;const commission=Math.abs(it.commission)+Math.abs(it.closingFee);const ship=Math.abs(it.fulfillmentShipping)+Math.abs(it.shipping)+Math.abs(it.shippingTax);const obj={orderId:it.orderId,channel:'Flipkart',date:it.postedDate||from||'',customer:'',sku:it.sku,qty:it.qty,sellingPrice:grossLine,gstAmount:it.tax,commission,feeGst:0,shippingFee:ship,adsCost:0,returnCost:0,otherCost:0,courier:'',awb:'',status:'Settled',paymentStatus:'Settled',settlementId:sid,settlementNet:it.netPayout,sourceFile:f.name,sourceKind:'Flipkart Settlement'};if(o){Object.assign(o,obj);o.isOrderRecord=true;}});});ensureMarketplaceV6();save();show('reconciliation');toast(`${channel}: ${added} settlement batches imported, ${updated} updated from ${f.name}`);input.value='';return;}
let added=0,updated=0;rows.forEach(r=>{const id=String(pick(r,['settlementId','settlement','settlementNumber','transactionId'])).trim();if(!id)return;const existing=data.marketplaceSettlements.find(x=>String(x.settlementId)===id);const x=existing||{settlementId:id,channel};Object.assign(x,{channel:channel||pick(r,['channel','marketplace'],'Amazon'),fromDate:pick(r,['fromDate','startDate','periodFrom']),toDate:pick(r,['toDate','endDate','periodTo']),gross:num(pick(r,['gross','grossSales','orderAmount','sales'])),fees:num(pick(r,['fees','marketplaceFees','commission','totalFees'])),tcs:num(pick(r,['tcs','tcsAmount'])),tds:num(pick(r,['tds','tdsAmount'])),salesGst:num(pick(r,['salesGst','gst','gstAmount','outputGst','outputGstAmount'])),feeGst:num(pick(r,['feeGst','feesGst','marketplaceFeeGst','commissionGst','feeGstAmount'])),refunds:num(pick(r,['refunds','refundAmount'])),shipping:num(pick(r,['shipping','shippingCharges'])),otherDeductions:num(pick(r,['otherDeductions','otherDeduction','otherCharges'])),adjustments:num(pick(r,['adjustments','adjustment','credits'])),netReceived:num(pick(r,['netReceived','actualPayout','payout','netAmount','bankReceived'])),receivedDate:pick(r,['receivedDate','bankDate','paymentDate']),bankRef:pick(r,['bankRef','utr','transactionRef','bankReference']),status:pick(r,['status'],'Pending')});if(existing)updated++;else{data.marketplaceSettlements.push(x);added++;}});ensureMarketplaceV6();autoMoveOldOrdersToDump();save();show('reconciliation');toast(`${channel}: ${added} settlements imported, ${updated} updated`)}catch(e){alert('Settlement CSV import failed: '+e.message)}finally{input.value=''}};reader.readAsText(f)}
function exportMarketplaceOrders(channel){const rows=activeMarketplaceOrders().filter(x=>!channel||x.channel===channel);const headers=['orderId','channel','date','customer','sku','qty','sellingPrice','gstRate','gstAmount','commission','feeGst','shippingFee','adsCost','returnCost','otherCost','courier','awb','status','paymentStatus','pickupDate','shippedDate','outForDeliveryDate','deliveryDate','cancelDate'];downloadCSV(`Gezeno_${channel||'Marketplace'}_Orders.csv`,headers,rows)}
function exportSettlements(channel){const rows=data.marketplaceSettlements.filter(x=>!channel||x.channel===channel);const headers=['settlementId','channel','fromDate','toDate','gross','salesGst','fees','feeGst','tcs','tds','refunds','shipping','otherDeductions','adjustments','netReceived','receivedDate','bankRef','status'];downloadCSV(`Gezeno_${channel||'Marketplace'}_Settlements.csv`,headers,rows)}
function exportProducts(){const headers=['sku','name','category','vendor','purchase','b2b','mrp','hsn','gst','stock','reorder'];downloadCSV('Gezeno_Products.csv',headers,data.products)}
function exportPurchases(){const headers=['poNo','vendor','date','status','sku','qty','rate','gst'];const rows=[];data.purchases.forEach(p=>(p.items||[]).forEach(it=>rows.push({...p,...it})));downloadCSV('Gezeno_Purchases.csv',headers,rows)}
function csvTemplate(type,channel){let headers=[];if(type==='orders')headers=['orderId','channel','date','customer','sku','qty','sellingPrice','commission','shippingFee','adsCost','returnCost','courier','awb','status','paymentStatus'];if(type==='settlements')headers=['settlementId','channel','fromDate','toDate','gross','salesGst','fees','feeGst','tcs','tds','refunds','shipping','otherDeductions','adjustments','netReceived','receivedDate','bankRef'];if(type==='products')headers=['sku','name','category','vendor','purchase','b2b','mrp','hsn','gst','stock','reorder'];if(type==='purchases')headers=['poNo','vendor','date','sku','qty','rate','gst','status'];const sample={};headers.forEach(h=>sample[h]=h==='channel'?(channel||'Amazon'):h==='status'?(type==='orders'?'New':'Ordered'):h==='paymentStatus'?'Pending':h==='qty'?'1':h==='gst'?'18':'');downloadCSV(`Gezeno_${channel||'All'}_${type}_Template.csv`,headers,[sample])}
function importProductsFile(input){const f=input.files?.[0];if(!f)return;const reader=new FileReader();reader.onload=()=>{try{const rows=parseCSV(String(reader.result||''));let n=0;rows.forEach(r=>{const sku=String(pick(r,['sku','sellerSku','productSku'])).trim();if(!sku)return;let p=data.products.find(x=>x.sku===sku);if(!p){p={sku};data.products.push(p)}Object.assign(p,{name:pick(r,['name','productName'],p.name||''),category:pick(r,['category'],p.category||'Other'),vendor:pick(r,['vendor','supplier'],p.vendor||''),purchase:num(pick(r,['purchase','purchaseRate'],p.purchase||0)),b2b:num(pick(r,['b2b','sellRate','sellingPrice'],p.b2b||0)),mrp:num(pick(r,['mrp'],p.mrp||0)),hsn:pick(r,['hsn','hsnSac'],p.hsn||''),gst:num(pick(r,['gst','gstRate'],p.gst||0)),stock:num(pick(r,['stock','quantity'],p.stock||0)),reorder:num(pick(r,['reorder','reorderLevel'],p.reorder||0))});n++});save();show('products');toast(`${n} product rows imported`)}catch(e){alert('Product CSV import failed: '+e.message)}finally{input.value=''}};reader.readAsText(f)}
function importPurchasesFile(input){const f=input.files?.[0];if(!f)return;const reader=new FileReader();reader.onload=()=>{try{const rows=parseCSV(String(reader.result||''));let n=0;rows.forEach(r=>{const po=String(pick(r,['poNo','purchaseNo','invoiceNo'])).trim()||nextNo('PO','purchases','poNo');let p=data.purchases.find(x=>x.poNo===po);const sku=pick(r,['sku','productSku']);const qty=num(pick(r,['qty','quantity'],1)),rate=num(pick(r,['rate','purchaseRate'])),gst=num(pick(r,['gst','gstRate']));const item={sku,name:data.products.find(x=>x.sku===sku)?.name||pick(r,['product','productName'],sku),qty,rate,gst};if(!p){p={poNo:po,vendor:pick(r,['vendor','supplier']),date:pick(r,['date','purchaseDate'],todayISO()),items:[],status:pick(r,['status'],'Ordered'),_csvStockApplied:false};data.purchases.push(p)}p.items=p.items||[];p.items.push(item);p.subtotal=(p.items||[]).reduce((a,x)=>a+num(x.qty)*num(x.rate),0);p.gstAmount=(p.items||[]).reduce((a,x)=>a+num(x.qty)*num(x.rate)*num(x.gst)/100,0);p.discount=num(pick(r,['discount'],p.discount||0));p.transport=num(pick(r,['transport'],p.transport||0));p.total=p.subtotal-p.discount+p.transport+p.gstAmount;if(['Received','Partial'].includes(p.status)&&!p._csvStockApplied){p.items.forEach(it=>{let prod=data.products.find(x=>x.sku===it.sku);if(prod)prod.stock=num(prod.stock)+num(it.qty)});p._csvStockApplied=true;}n++;});save();show('purchases');toast(`${n} purchase rows imported`)}catch(e){alert('Purchase CSV import failed: '+e.message)}finally{input.value=''}};reader.readAsText(f)}
function manualMarketplaceOrder(){
  const id=prompt('Marketplace Order ID:'); if(!id)return;
  const channel=prompt('Marketplace (Amazon / Flipkart / Meesho):','Amazon')||'Amazon';
  const sku=prompt('SKU:',''); if(!sku)return;
  const qty=Math.max(1,num(prompt('Quantity:','1'))); const price=num(prompt('Selling Amount:','0'));
  const customer=prompt('Customer Name:',''); const o={orderId:id,channel,date:todayISO(),customer,sku,qty,sellingPrice:price,commission:0,shippingFee:0,adsCost:0,returnCost:0,status:'New',paymentStatus:'Pending',items:[{sku,name:data.products.find(p=>p.sku===sku)?.name||sku,qty,amount:price}],stockDeducted:false,stockRestored:false};
  data.marketplaceOrders.push(o);save();show('marketplaceControl');toast('Marketplace order created: '+id)
}
function marketplaceOrderMarketBadge(ch){const cls=String(ch||'').toLowerCase();return `<span class="market-badge"><span class="market-dot ${cls}"></span>${esc(ch||'Other')}</span>`}
function marketplaceOrderProfit(o){const p=data.products.find(x=>x.sku===o.sku)||{};const revenue=num(o.sellingPrice);const cost=num(p.purchase)*Math.max(1,num(o.qty));const charges=num(o.commission)+num(o.shippingFee)+num(o.adsCost)+num(o.returnCost);const profit=revenue-cost-charges;return {revenue,cost,charges,profit,margin:revenue?profit/revenue*100:0}}
function marketplaceOrderTimeline(o){const steps=[['Order Received',o.date],['Confirmed',o.confirmedDate],['Packed',o.packedDate],['Ready for Pickup',o.readyForPickupDate],['Picked Up',o.pickupDate],['Shipped',o.shippedDate],['Out for Delivery',o.outForDeliveryDate],['Delivered',o.deliveryDate]];const current=MP_STATUSES.indexOf(o.status);const cancelled=['Cancelled','RTO','Returned'].includes(o.status);return `<div class="timeline">${steps.map((x,i)=>{const done=x[1]||(!cancelled&&current>=i);return done?`<div class="timeline-item"><b>${esc(x[0])}</b><br><span class="mini-muted">${x[1]?formatDate(x[1]):'Completed'}</span></div>`:''}).join('')}${cancelled?`<div class="timeline-item"><b>${esc(o.status)}</b><br><span class="mini-muted">${formatDate(o.cancelDate||o.returnDate||todayISO())}</span></div>`:''}</div>`}
function viewMarketplaceOrder(i){window.marketplaceOrderSelected=i;show('marketplaceControl')}
function closeMarketplaceOrderDetail(){window.marketplaceOrderSelected=-1;show('marketplaceControl')}
function updateMarketplaceOrderField(i,field,value){const o=data.marketplaceOrders[i];if(!o)return;o[field]=value;save();show('marketplaceControl');toast('Order updated')}
function printMarketplaceOrder(i){const o=data.marketplaceOrders[i];if(!o)return;const w=window.open('','_blank');if(!w){alert('Please allow pop-ups.');return}const p=data.products.find(x=>x.sku===o.sku)||{};w.document.write(`<html><head><title>Order ${esc(o.orderId)}</title><style>body{font-family:Arial;padding:28px;color:#17243a}h1{margin:0 0 8px}.box{border:1px solid #ddd;border-radius:10px;padding:15px;margin:12px 0}table{width:100%;border-collapse:collapse}td{padding:8px;border-bottom:1px solid #eee}</style></head><body><h1>Gezeno Marketplace Order</h1><div class="box"><b>Order ID:</b> ${esc(o.orderId)}<br><b>Marketplace:</b> ${esc(o.channel)}<br><b>Date:</b> ${esc(formatDate(o.date))}<br><b>Status:</b> ${esc(o.status)}</div><div class="box"><b>Customer</b><br>${esc(o.customer||'')}</div><table><tr><td>Product</td><td>${esc(p.name||o.sku)}</td></tr><tr><td>SKU</td><td>${esc(o.sku)}</td></tr><tr><td>Qty</td><td>${esc(o.qty)}</td></tr><tr><td>Amount</td><td>₹${num(o.sellingPrice).toLocaleString('en-IN')}</td></tr><tr><td>Courier / AWB</td><td>${esc(o.courier||'-')} / ${esc(o.awb||'-')}</td></tr></table></body></html>`);w.document.close();setTimeout(()=>w.print(),250)}
function orderSettlementRecord(o){
 const settlements=data.marketplaceSettlements||[];
 let s=settlements.find(x=>String(x.orderId||'')===String(o.orderId||''));
 let allocated=false;
 if(!s){
  s=settlements.find(x=>x.channel===o.channel && (!x.fromDate||o.date>=x.fromDate) && (!x.toDate||o.date<=x.toDate));
  if(s) allocated=true;
 }
 const gross=num(o.sellingPrice);
 const gst=num(o.gstAmount)||(o.gstRate?gross*num(o.gstRate)/(100+num(o.gstRate)):0);
 const taxable=num(o.taxableSale)||(gross-gst);
 const feeGst=num(o.feeGst);
 const commission=num(o.commission);
 const shipping=num(o.shippingFee);
 const ads=num(o.adsCost);
 const returnCost=num(o.returnCost);
 const other=num(o.otherCost);
 const explicitFees=['closingFee','collectionFee','fixedFee','logisticsFee','serviceFee','paymentGatewayFee','returnFee','rtoFee','cancellationFee','otherFee'].reduce((a,k)=>a+num(o[k]),0);
 const lineFees=commission+shipping+ads+returnCost+other+explicitFees+feeGst;
 const tcs=s?num(s.tcs):num(o.tcs);
 const tds=s?num(s.tds):num(o.tds);
 const refunds=s?num(s.refunds):num(o.refund);
 const adjustments=s?num(s.adjustments):num(o.adjustments);
 const expected=s&&s.expected!=null?num(s.expected):gross-lineFees-tcs-tds-refunds+adjustments;
 const actual=s?num(s.netReceived):num(o.actualReceived);
 const difference=s&&s.difference!=null?num(s.difference):(s?actual-expected:null);
 const feeTotal=s?num(s.fees):commission+feeGst+other;
 const residual=Math.max(0,feeTotal-(commission+feeGst+other));
 const bank=(data.bankTransactions||[]).find(b=>s&&String(b.reference||'').trim().toLowerCase()===String(s.bankRef||'').trim().toLowerCase());
 return {s,allocated,gross,gst,taxable,commission,feeGst,shipping,ads,returnCost,other,explicitFees,feeTotal,residual,tcs,tds,refunds,adjustments,expected,actual,difference,bank,cogs:num(o.cogs)||(data.products||[]).find(p=>p.sku===o.sku)?.purchase||0};
}
function showOrderSettlement(i){
 const o=data.marketplaceOrders?.[i]; if(!o)return;
 const x=orderSettlementRecord(o);
 const status=x.difference===null?'Pending':Math.abs(x.difference)<0.01?'Matched':x.difference<0?'Short Payment':'Extra Payment';
 const statusClass=status==='Matched'?'green':status==='Pending'?'orange':'red';
 let el=document.getElementById('orderSettlementModal');
 if(!el){el=document.createElement('div');el.id='orderSettlementModal';el.className='modal';document.body.appendChild(el);}
 const feeRows=[['Commission / Referral Fee',x.commission],['Closing / Collection / Fixed Fees',x.explicitFees],['Shipping / Logistics',x.shipping],['Ads / Promotion',x.ads],['Return / RTO / Cancellation',x.returnCost],['Other Order Cost',x.other],['Fee GST',x.feeGst],['Other Marketplace Fees',x.residual]].filter(r=>r[1]!==0);
 el.innerHTML=`<div class="dialog" style="width:min(920px,95vw)"><div style="display:flex;justify-content:space-between;gap:12px;align-items:center"><div><div class="mini-muted">${marketplaceOrderMarketBadge(o.channel)}</div><h2 style="margin:3px 0">Payment & Settlement — ${esc(o.orderId)}</h2><div class="hint">${x.allocated?'Settlement-level amount allocated to this order because the uploaded settlement has no Order ID.':'Direct order-to-settlement match.'}</div></div><button class="btn secondary" onclick="closeOrderSettlement()">✕ Close</button></div><div class="finance-kpis" style="margin-top:16px"><div class="finance-kpi"><div class="label">Gross Sale</div><div class="value">₹${x.gross.toLocaleString('en-IN')}</div></div><div class="finance-kpi"><div class="label">Sales GST</div><div class="value">₹${x.gst.toLocaleString('en-IN',{minimumFractionDigits:0})}</div></div><div class="finance-kpi"><div class="label">Total Fees / Charges</div><div class="value">₹${x.feeTotal.toLocaleString('en-IN',{minimumFractionDigits:0})}</div></div><div class="finance-kpi ${statusClass}"><div class="label">${status}</div><div class="value">${x.difference===null?'—':'₹'+Math.abs(x.difference).toLocaleString('en-IN',{minimumFractionDigits:0})}</div></div></div><div class="panel"><h3>1. Sale & GST</h3><table class="table"><tbody><tr><td>Gross Selling Price (GST Incl.)</td><td><b>₹${x.gross.toLocaleString('en-IN',{minimumFractionDigits:0})}</b></td></tr><tr><td>Taxable Sale</td><td>₹${x.taxable.toLocaleString('en-IN',{minimumFractionDigits:0})}</td></tr><tr><td>Output Sales GST</td><td>₹${x.gst.toLocaleString('en-IN',{minimumFractionDigits:0})}</td></tr></tbody></table></div><div class="panel"><h3>2. Marketplace Commission & All Charges</h3><table class="table"><tbody>${feeRows.map(r=>`<tr><td>${r[0]}</td><td>₹${r[1].toLocaleString('en-IN',{minimumFractionDigits:0})}</td></tr>`).join('')}<tr><th>Total Marketplace Charges</th><th>₹${x.feeTotal.toLocaleString('en-IN',{minimumFractionDigits:0})}</th></tr></tbody></table></div><div class="panel"><h3>3. Settlement Calculation</h3><table class="table"><tbody><tr><td>Gross Sale</td><td>₹${x.gross.toLocaleString('en-IN',{minimumFractionDigits:0})}</td></tr><tr><td>Less: Marketplace Charges</td><td>− ₹${x.feeTotal.toLocaleString('en-IN',{minimumFractionDigits:0})}</td></tr><tr><td>Less: TCS</td><td>− ₹${x.tcs.toLocaleString('en-IN',{minimumFractionDigits:0})}</td></tr><tr><td>Less: TDS</td><td>− ₹${x.tds.toLocaleString('en-IN',{minimumFractionDigits:0})}</td></tr><tr><td>Less: Refunds</td><td>− ₹${x.refunds.toLocaleString('en-IN',{minimumFractionDigits:0})}</td></tr><tr><td>Adjustments / Credits</td><td>+ ₹${x.adjustments.toLocaleString('en-IN',{minimumFractionDigits:0})}</td></tr><tr><th>Expected Settlement</th><th>₹${x.expected.toLocaleString('en-IN',{minimumFractionDigits:0})}</th></tr><tr><td>Actual Marketplace Settlement</td><td><b>${x.s?('₹'+x.actual.toLocaleString('en-IN',{minimumFractionDigits:0})):'Pending'}</b></td></tr><tr><th>Difference</th><th>${x.difference===null?'Pending':(x.difference===0?'₹0.00':(x.difference>0?'+ ':'− ')+'₹'+Math.abs(x.difference).toLocaleString('en-IN',{minimumFractionDigits:0}))}</th></tr></tbody></table></div><div class="panel"><h3>4. Bank Reconciliation</h3><table class="table"><tbody><tr><td>Settlement ID</td><td>${esc(x.s?.settlementId||'—')}</td></tr><tr><td>Settlement Date</td><td>${x.s?.receivedDate?formatDate(x.s.receivedDate):'—'}</td></tr><tr><td>UTR / Bank Reference</td><td>${esc(x.s?.bankRef||'—')}</td></tr><tr><td>Bank Credit</td><td>${x.bank?'₹'+num(x.bank.credit).toLocaleString('en-IN',{minimumFractionDigits:0}):'Not matched'}</td></tr><tr><td>Reconciliation Status</td><td><span class="badge ${statusClass}">${esc(status)}</span></td></tr></tbody></table></div><div class="panel"><h3>5. Order Profit</h3><table class="table"><tbody><tr><td>Gross Sales</td><td>₹${x.gross.toLocaleString('en-IN',{minimumFractionDigits:0})}</td></tr><tr><td>Product Cost / COGS</td><td>− ₹${x.cogs.toLocaleString('en-IN',{minimumFractionDigits:0})}</td></tr><tr><td>Marketplace Charges</td><td>− ₹${x.feeTotal.toLocaleString('en-IN',{minimumFractionDigits:0})}</td></tr><tr><th>Operating Profit*</th><th>₹${(x.gross-x.cogs-x.feeTotal).toLocaleString('en-IN',{minimumFractionDigits:0})}</th></tr></tbody></table><div class="hint">* GST/TCS/TDS are shown separately for tax/reconciliation visibility and are not double-counted as operating expenses.</div></div></div>`;
 el.classList.add('show');
}
function closeOrderSettlement(){document.getElementById('orderSettlementModal')?.classList.remove('show');}
function marketplaceOrderDetail(i){if(!Number.isInteger(i)||i<0)return `<div class="panel order-detail"><div class="detail-head"><div><h3 style="margin:0">Product / Order View</h3><div class="hint">Select an order to view its complete details.</div></div></div></div>`;const o=data.marketplaceOrders[i];if(!o)return `<div class="panel order-detail"><div class="hint">Select an order.</div></div>`;const p=data.products.find(x=>x.sku===o.sku)||{};const q=marketplaceOrderProfit(o);return `<div class="panel order-detail"><div class="detail-head"><button class="btn secondary" style="margin-left:auto;order:3" onclick="closeMarketplaceOrderDetail()">✕ Close</button><div><div class="mini-muted">Order ID</div><h2 style="margin:3px 0">${esc(o.orderId)}</h2><div class="mini-muted">${marketplaceOrderMarketBadge(o.channel)} &nbsp; ${formatDate(o.date)}</div></div><span class="badge ${o.status==='Delivered'?'green':['Cancelled','RTO','Returned'].includes(o.status)?'red':'orange'}">${esc(o.status)}</span></div><div class="detail-product"><div class="product-icon">📦</div><div><b>${esc(p.name||o.sku)}</b><div class="mini-muted">SKU: ${esc(o.sku)} • Qty: ${num(o.qty)}</div><div style="margin-top:4px;font-weight:800">₹${num(o.sellingPrice).toLocaleString('en-IN')}</div></div></div><div class="detail-tabs"><span class="detail-tab active">Order Details</span><span class="detail-tab">Customer</span><span class="detail-tab">Financials</span><span class="detail-tab">Timeline</span></div><div class="detail-grid"><div class="detail-item"><small>Payment</small><b>${esc(o.paymentType||'Marketplace')}</b></div><div class="detail-item"><small>Settlement</small><b>${esc(o.paymentStatus||'Pending')}</b></div><div class="detail-item"><small>Courier</small><b>${esc(o.courier||'-')}</b></div><div class="detail-item"><small>AWB / Tracking</small><b>${esc(o.awb||'-')}</b></div><div class="detail-item"><small>Pickup</small><b>${o.pickupDate?formatDate(o.pickupDate):'-'}</b></div><div class="detail-item"><small>Delivery</small><b>${o.deliveryDate?formatDate(o.deliveryDate):'-'}</b></div></div><h3 style="margin:15px 0 6px">Status Timeline</h3>${marketplaceOrderTimeline(o)}<div class="detail-actions"><button class="btn" onclick="showOrderSettlement(${i})">💰 Payment & Settlement</button><button class="btn" onclick="openMarketplaceOrderEdit(${i})">✏ Edit Order</button><button class="btn danger" onclick="removeMarketplaceOrder(${i})">🗑 Remove Order</button><button class="btn" onclick="printMarketplaceOrder(${i})">🖨 Print Order</button><button class="btn secondary" onclick="updateMarketplaceOrderField(${i},'awb',prompt('AWB / Tracking:',${JSON.stringify(o.awb||'')})||'')">🔗 Add Tracking</button><button class="btn secondary" onclick="updateMarketplaceStatus(${i},prompt('New status:',${JSON.stringify(o.status)})||${JSON.stringify(o.status)})">↻ Update Status</button><button class="btn secondary" onclick="alert('Invoice module available from Invoices. Order: ${esc(o.orderId)}')">▤ Invoice</button><button class="btn secondary" onclick="updateMarketplaceOrderField(${i},'courier',prompt('Courier:',${JSON.stringify(o.courier||'')})||'')">🚚 Courier</button><button class="btn secondary" onclick="updateMarketplaceOrderField(${i},'note',prompt('Order note:',${JSON.stringify(o.note||'')})||'')">📝 Note</button></div><div class="profit-box"><b>Profit Summary</b><div class="profit-row"><span>Selling Price</span><b>₹${q.revenue.toLocaleString('en-IN')}</b></div><div class="profit-row"><span>Product Cost</span><span>₹${q.cost.toLocaleString('en-IN')}</span></div><div class="profit-row"><span>Marketplace/Shipping/Ads/Return</span><span>₹${q.charges.toLocaleString('en-IN')}</span></div><div class="profit-row total"><span>Net Profit</span><span>₹${q.profit.toLocaleString('en-IN')}</span></div><div class="profit-row"><span>Margin</span><b>${q.margin.toFixed(2)}%</b></div></div></div>`}
function orderCenterOrderSearch(){const el=document.getElementById('omSearch');const q=String(el?.value||'').trim();if(!q){alert('Please enter an Order ID.');el?.focus();return}ensureMarketplaceV6();const needle=q.toLowerCase();const matches=(data.marketplaceOrders||[]).map((o,i)=>({o,i})).filter(x=>String(x.o.orderId||'').toLowerCase().includes(needle));if(!matches.length){alert('Order ID not found: '+q);return}const active=matches.find(x=>!x.o.dumpArchived);if(active){window.marketplaceGlobalSearch=q;window.marketplaceOrderSelected=active.i;window.marketplaceOrderTab=active.o.channel||'All';show('marketplaceControl');return}const archived=matches[0].o;window.dumpOrderQuery=q;window.dumpChannel=archived.channel||'All';window.dumpPeriod='All Data';window.dumpFrom='';window.dumpTo='';window.dumpDataActive=true;show('dataDump')}
function orderCenterCardFilter(type){window.orderCenterCardFilterType=type||'';window.marketplaceOrderSelected=-1;window.orderCenterSelectedIndices=new Set();show('marketplaceControl')}
function toggleMarketplaceOrderSelection(index,checked){if(!window.orderCenterSelectedIndices)window.orderCenterSelectedIndices=new Set();if(checked)window.orderCenterSelectedIndices.add(Number(index));else window.orderCenterSelectedIndices.delete(Number(index));updateOrderCenterSelectionUI()}
function updateOrderCenterSelectionUI(){const n=window.orderCenterSelectedIndices?.size||0;document.querySelectorAll('[data-om-selection-count]').forEach(el=>el.textContent=n?`${n} selected`:'' );const a=document.getElementById('omSelectAll');if(a){const boxes=[...document.querySelectorAll('.om-select')];a.checked=boxes.length>0&&boxes.every(b=>b.checked);a.indeterminate=boxes.some(b=>b.checked)&&!a.checked}}
function toggleAllMarketplaceOrders(checked){if(!window.orderCenterSelectedIndices)window.orderCenterSelectedIndices=new Set();const boxes=[...document.querySelectorAll('.om-select')];boxes.forEach(b=>{b.checked=checked;toggleMarketplaceOrderSelection(b.dataset.index,checked)});const c=document.getElementById('omSelectAll');if(c)c.checked=checked;}
function deleteSelectedMarketplaceOrders(){const set=window.orderCenterSelectedIndices||new Set();const indices=[...set].map(Number).filter(i=>Number.isInteger(i)&&data.marketplaceOrders[i]).sort((a,b)=>b-a);if(!indices.length){alert('Please select at least one order to delete.');return;}const ids=indices.map(i=>data.marketplaceOrders[i].orderId).join(', ');if(!confirm(`Delete ${indices.length} selected order(s)?\n\n${ids}\n\nThis action cannot be undone.`))return;indices.forEach(i=>{const o=data.marketplaceOrders[i];data.reconTaxFiles=(data.reconTaxFiles||[]).filter(x=>String(x.orderId||'')!==String(o.orderId||''));data.marketplaceOrders.splice(i,1);});window.orderCenterSelectedIndices=new Set();window.marketplaceOrderSelected=-1;save();show('marketplaceControl');toast(`${indices.length} order(s) deleted`)}
function orderCenterApplyDateFilters(){const m=String(document.getElementById('omMonth')?.value||''),f=String(document.getElementById('omFromDate')?.value||''),t=String(document.getElementById('omToDate')?.value||'');if(!m&&!f&&!t){toast('Please select Month-wise or From + To Date first');return}if(!m&&((f&&!t)||(!f&&t))){toast('Please select both From and To Date');return}if(f&&t&&f>t){alert('From Date To Date se bada nahi ho sakta.');return}let from=f,to=t;if(m){const [y,mo]=m.split('-').map(Number),last=new Date(y,mo,0).getDate();from=`${y}-${String(mo).padStart(2,'0')}-01`;to=`${y}-${String(mo).padStart(2,'0')}-${String(last).padStart(2,'0')}`;}window.orderCenterMonth=m;window.orderCenterFromDate=from;window.orderCenterToDate=to;window.orderCenterFilterApplied=true;window.orderCenterCardFilterType='';show('marketplaceControl');}
function orderCenterSyncFilterDates(){window.orderCenterFromDate=String(document.getElementById('omFromDate')?.value||window.orderCenterFromDate||'');window.orderCenterToDate=String(document.getElementById('omToDate')?.value||window.orderCenterToDate||'');}
function marketplaceControl(){ensureMarketplaceV6();const month=String(window.orderCenterMonth||'');const applied=window.orderCenterFilterApplied===true;const selected=Number.isInteger(window.marketplaceOrderSelected)?window.marketplaceOrderSelected:-1;const safeSelected=selected<0?-1:Math.min(selected,Math.max(0,data.marketplaceOrders.length-1));const q=(document.getElementById('omSearch')?.value||window.marketplaceGlobalSearch||'').toLowerCase();const ch=document.getElementById('omChannel')?.value||'All';const st=document.getElementById('omStatus')?.value||'All';const fromDate=String(document.getElementById('omFromDate')?.value||window.orderCenterFromDate||'');const toDate=String(document.getElementById('omToDate')?.value||window.orderCenterToDate||'');const from=fromDate?new Date(fromDate+'T00:00:00'):null;const to=toDate?new Date(toDate+'T23:59:59'):null;let rows=data.marketplaceOrders.map((o,i)=>({o,i})).filter(x=>applied&&!x.o.dumpArchived&&(ch==='All'||x.o.channel===ch)&&(st==='All'||x.o.status===st)&&(!month||String(x.o.date||'').slice(0,7)===month)&&(!from||new Date(x.o.date)>=from)&&(!to||new Date(x.o.date)<=to)&&JSON.stringify(x.o).toLowerCase().includes(q));const activeTab=window.marketplaceOrderTab||document.getElementById('omTabHidden')?.value||'All';if(activeTab!=='All')rows=rows.filter(x=>x.o.channel===activeTab);const cardFilter=window.orderCenterCardFilterType||'';if(cardFilter==='delivered')rows=rows.filter(x=>x.o.status==='Delivered');else if(cardFilter==='pending')rows=rows.filter(x=>['New','Confirmed','Packed','Ready for Pickup','Picked Up','Shipped','Out for Delivery'].includes(x.o.status));else if(cardFilter==='closed')rows=rows.filter(x=>['Cancelled','RTO'].includes(x.o.status));else if(cardFilter==='returns')rows=rows.filter(x=>x.o.status==='Returned');const active=applied?activeMarketplaceOrders().filter(o=>(!month||String(o.date||'').slice(0,7)===month)&&(!from||String(o.date||'')>=fromDate)&&(!to||String(o.date||'')<=toDate)&&(ch==='All'||o.channel===ch)&&(st==='All'||o.status===st)):[];const counts={total:active.length,delivered:active.filter(o=>o.status==='Delivered').length,pending:active.filter(o=>['New','Confirmed','Packed','Ready for Pickup','Picked Up','Shipped','Out for Delivery'].includes(o.status)).length,closed:active.filter(o=>['Cancelled','RTO'].includes(o.status)).length,returns:active.filter(o=>o.status==='Returned').length};const tabs=['All','Amazon','Flipkart','Meesho'];return `<div class="reporthero"><h2>🛒 Order Management</h2><div style="opacity:.9">Track current marketplace orders • Order Center keeps the current Indian Financial Year; previous financial years are automatically archived to Data Dump</div></div><div class="order-kpis"><div class="order-kpi ${cardFilter===""?"active-filter":""}" role="button" tabindex="0" title="Show all active orders" onclick="orderCenterCardFilter('')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();orderCenterCardFilter('')}"><div class="kpi-label">Total Orders</div><div class="kpi-value">${counts.total}</div></div><div class="order-kpi green ${cardFilter==='delivered'?'active-filter':''}" role="button" tabindex="0" title="Show delivered orders" onclick="orderCenterCardFilter('delivered')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();orderCenterCardFilter('delivered')}"><div class="kpi-label">Delivered</div><div class="kpi-value">${counts.delivered}</div></div><div class="order-kpi orange ${cardFilter==='pending'?'active-filter':''}" role="button" tabindex="0" title="Show pending / in-transit orders" onclick="orderCenterCardFilter('pending')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();orderCenterCardFilter('pending')}"><div class="kpi-label">Pending / In Transit</div><div class="kpi-value">${counts.pending}</div></div><div class="order-kpi red ${cardFilter==='closed'?'active-filter':''}" role="button" tabindex="0" title="Show cancelled orders" onclick="orderCenterCardFilter('closed')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();orderCenterCardFilter('closed')}"><div class="kpi-label">Cancelled / RTO</div><div class="kpi-value">${counts.closed}</div></div><div class="order-kpi purple ${cardFilter==='returns'?'active-filter':''}" role="button" tabindex="0" title="Show returned / refunded orders" onclick="orderCenterCardFilter('returns')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();orderCenterCardFilter('returns')}"><div class="kpi-label">Return / Refund</div><div class="kpi-value">${counts.returns}</div></div></div><div class="panel"><div class="order-toolbar"><button class="btn secondary" type="button" onclick="toggleAllMarketplaceOrders(true)">☑ Select All</button><button class="btn" type="button" onclick="toggleAllMarketplaceOrders(false)">☐ Clear Selection</button><span data-om-selection-count class="hint" style="min-width:90px"></span><button class="del" type="button" onclick="deleteSelectedMarketplaceOrders()">🗑 Remove Selected</button><select id="omChannel" onchange="orderCenterSyncFilterDates();window.orderCenterCardFilterType='';show('marketplaceControl')"><option value="All">All Marketplaces</option><option>Amazon</option><option>Flipkart</option><option>Meesho</option></select><select id="omStatus" onchange="orderCenterSyncFilterDates();window.orderCenterCardFilterType='';show('marketplaceControl')"><option value="All">All Status</option>${MP_STATUSES.map(s=>`<option>${s}</option>`).join('')}</select><input id="omSearch" class="order-search" placeholder="Search Order ID" value="${esc(q)}" onkeydown="if(event.key==='Enter')orderCenterOrderSearch()"><button class="btn" type="button" onclick="orderCenterSyncFilterDates();orderCenterOrderSearch()">🔎 Search</button><button class="btn secondary" type="button" onclick="window.orderCenterMonth='';window.orderCenterFromDate='';window.orderCenterToDate='';window.marketplaceGlobalSearch='';window.orderCenterFilterApplied=false;window.orderCenterCardFilterType='';show('marketplaceControl')">Reset Filters</button><button class="btn secondary" onclick="manualMarketplaceOrder()">＋ New Order</button></div><div class="order-date-filter-row" style="display:flex;align-items:flex-end;gap:14px;flex-wrap:wrap;margin-top:12px;padding:14px 16px;border:1px solid #e5e7eb;border-radius:12px;background:#f8fafc"><div><div class="hint" style="font-weight:700;margin-bottom:5px">Order Date Filter</div><div class="hint">Date range ko saamne select karke Apply karein</div></div><label class="field" style="min-width:180px"><span>Month-wise</span><input id="omMonth" type="month" value="${esc(month)}"></label><label class="field" style="min-width:180px"><span>From Date</span><input id="omFromDate" type="date" value="${esc(fromDate)}"></label><label class="field" style="min-width:180px"><span>To Date</span><input id="omToDate" type="date" value="${esc(toDate)}"></label><button class="btn" type="button" onclick="orderCenterApplyDateFilters()">✓ Apply Filter</button><button class="btn secondary" type="button" onclick="window.orderCenterMonth='';window.orderCenterFromDate='';window.orderCenterToDate='';window.orderCenterFilterApplied=false;window.orderCenterCardFilterType='';show('marketplaceControl')">Reset & Lock Data</button></div><div class="order-tabs">${tabs.map(t=>`<button class="order-tab ${activeTab===t?'active':''}" onclick="window.marketplaceOrderTab='${t}';document.getElementById('omTabHidden').value='${t}';show('marketplaceControl')">${t==='All'?'All Orders':t} (${t==='All'?counts.total:active.filter(o=>o.channel===t).length})</button>`).join('')}</div><input type="hidden" id="omTabHidden" value="${esc(activeTab)}"><div class="order-layout"><div class="order-table-wrap"><table class="table order-table"><thead><tr><th><input id="omSelectAll" type="checkbox" title="Select all visible orders" onchange="toggleAllMarketplaceOrders(this.checked)"></th><th>Order ID</th><th>Marketplace</th><th>Date</th><th>Product (SKU)</th><th>Qty</th><th>Amount</th><th>Status</th><th>AWB / Tracking</th><th>Actions</th></tr></thead><tbody>${rows.map(x=>{const o=x.o;const p=data.products.find(p=>p.sku===o.sku)||{};return `<tr class="${x.i===safeSelected?'order-row-selected':''}" onclick="viewMarketplaceOrder(${x.i})"><td><input class="om-select" data-index="${x.i}" type="checkbox" ${window.orderCenterSelectedIndices?.has(x.i)?'checked':''} onclick="event.stopPropagation()" onchange="toggleMarketplaceOrderSelection(this.dataset.index,this.checked)"></td><td><b>${esc(o.orderId)}</b><br><span class="mini-muted">${esc(o.customer||'')}</span></td><td>${marketplaceOrderMarketBadge(o.channel)}</td><td>${formatDate(o.date)}</td><td>${esc(p.name||o.sku)}<br><span class="mini-muted">${esc(o.sku)}</span></td><td>${num(o.qty)}</td><td><b>₹${num(o.sellingPrice).toLocaleString('en-IN')}</b></td><td><span class="badge ${o.status==='Delivered'?'green':['Cancelled','RTO','Returned'].includes(o.status)?'red':'orange'}">${esc(o.status)}</span></td><td>${esc(o.awb||'-')}<br><span class="mini-muted">${esc(o.courier||'')}</span></td><td><button class="edit" onclick="event.stopPropagation();viewMarketplaceOrder(${x.i})">View</button><button class="edit" onclick="event.stopPropagation();openMarketplaceOrderEdit(${x.i})">Edit</button><button class="del" onclick="event.stopPropagation();removeMarketplaceOrder(${x.i})">Remove</button></td></tr>`}).join('')||'<tr><td colspan="10" class="hint">No orders match the selected filters.</td></tr>'}</tbody></table></div>${marketplaceOrderDetail(safeSelected)}</div></div>`}
function csvCenter(){return `<div class="reporthero"><h2>📥 File Upload Center</h2><div style="opacity:.9">Amazon • Flipkart • Meesho — all marketplace data-file imports are handled from this single File Upload screen.</div></div><div class="panel"><div class="alertbox ok"><b>Centralized Upload:</b> Orders, Payment/Settlement, Products, Purchases aur Backup files yahin se upload/import honge. Kisi aur module mein direct data-file upload nahi hoga.</div></div>${['Amazon','Flipkart','Meesho'].map(ch=>`<div class="panel"><h2>${ch}</h2><div class="toolbar" style="flex-wrap:wrap"><label class="btn">📥 Upload Orders File<input hidden type="file" accept=".csv,.txt,text/csv,.xlsx,.xls,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" onchange="${ch==='Flipkart'?"(/\.xlsx?$/i.test(this.files?.[0]?.name||'')?importFlipkartOrderWorkbook(this,'Flipkart'):importMarketplaceFile(this,'Flipkart'))":"importMarketplaceFile(this,'${ch}')"}"></label><button class="btn secondary" onclick="csvTemplate('orders','${ch}')">Download Gezeno Template</button><button class="btn secondary" onclick="exportMarketplaceOrders('${ch}')">📤 Export Orders</button><label class="btn">💰 Upload Payment / Settlement File (Auto Map)<input hidden type="file" accept=".csv,.txt,.xlsx,.xls,text/csv,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" onchange="importSettlementFile(this,'${ch}')"></label><button class="btn secondary" onclick="csvTemplate('settlements','${ch}')">Settlement Template</button><span class="badge green">Auto Mapping: Order ID + Order Item ID + NEFT ID</span><button class="btn secondary" onclick="exportSettlements('${ch}')">Export Settlements</button></div><div class="hint">${ch} file processing is handled only from this File Upload Center.</div></div>`).join('')}<div class="panel"><h2>Purchase & Inventory CSV</h2><div class="toolbar" style="flex-wrap:wrap"><button class="btn secondary" onclick="csvTemplate('products')">Product Template</button><label class="btn">Upload Products File<input hidden type="file" accept=".csv,text/csv" onchange="importProductsFile(this)"></label><button class="btn secondary" onclick="exportProducts()">Export Products</button><button class="btn secondary" onclick="csvTemplate('purchases')">Purchase Template</button><label class="btn">Upload Purchases File<input hidden type="file" accept=".csv,text/csv" onchange="importPurchasesFile(this)"></label><button class="btn secondary" onclick="exportPurchases()">Export Purchases</button></div></div><div class="panel"><h2>Data Backup</h2><div class="toolbar" style="flex-wrap:wrap"><button class="btn" onclick="downloadBackup()">Export Backup</button><label class="btn secondary">Restore Backup File<input hidden type="file" accept="application/json" onchange="restoreBackup(event)"></label></div><div class="hint">Backup restore bhi isi File Upload Center se hoga.</div></div>`}
function getReconFilters(){
 const f=window.reconFilters||{};
 return {channel:f.channel||'All',month:f.month||'',from:f.from||'',to:f.to||'',status:f.status||'All',view:f.view||'dashboard',search:f.search||'',focus:f.focus||''};
}
function setReconFilters(){
 const channel=document.getElementById('reconChannel')?.value||'All';
 const monthRaw=String(document.getElementById('reconMonth')?.value||'').trim();
 const from=String(document.getElementById('reconFrom')?.value||'').trim();
 const to=String(document.getElementById('reconTo')?.value||'').trim();
 const month=/^\d{4}-(0[1-9]|1[0-2])$/.test(monthRaw)?monthRaw:'';
 if(!month){ alert('Please select a Month first. Reconciliation Dashboard data month select kiye bina show nahi hoga.'); return; }
 if(!month){ alert('Please select a Month first. Reconciliation Dashboard data month select kiye bina show nahi hoga.'); return; }
 if(monthRaw && !month){ alert('Invalid Month. Month select karein (YYYY-MM).'); return; }
 if(from && !/^\d{4}-\d{2}-\d{2}$/.test(from)){ alert('Invalid From Date.'); return; }
 if(to && !/^\d{4}-\d{2}-\d{2}$/.test(to)){ alert('Invalid To Date.'); return; }
 if(from && to && from>to){ alert('From Date To Date se bada nahi ho sakta.'); return; }
 window.reconFilters={
  channel, month, from, to,
  status:document.getElementById('reconStatus')?.value||'All',
  view:window.reconFilters?.view||'dashboard',
  search:document.getElementById('reconOrderSearch')?.value||''
 };
 window.reconFiltersApplied=true;
 show('reconciliation');
}
function setReconView(view){window.reconFilters={...getReconFilters(),view};show('reconciliation');}
function reconSettlementDate(s){
 const v=s && (s.receivedDate||s.paymentDate||s.settlementDate||s.toDate||s.fromDate||'');
 return String(v||'').trim().slice(0,10);
}
function reconDateMatch(s,from,to){
 const d=reconSettlementDate(s);
 return (!from || !d || d>=from) && (!to || !d || d<=to);
}
function reconGSTForSettlement(s){
 const orders=data.marketplaceOrders.filter(o=>o.channel===s.channel&&(!s.fromDate||String(o.date)>=String(s.fromDate))&&(!s.toDate||String(o.date)<=String(s.toDate)));
 let salesGst=Number(s.salesGst||s.gst||s.gstAmount||0), feeGst=Number(s.feeGst||0);
 if(!salesGst){ salesGst=orders.reduce((a,o)=>{ const explicit=Number(o.gstAmount||0); if(explicit)return a+explicit; const p=data.products.find(x=>x.sku===o.sku)||{}; const rate=Number(o.gstRate||p.gst||0), gross=Number(o.sellingPrice||0); return a+(rate?gross*rate/(100+rate):0); },0); }
 if(!feeGst){ feeGst=orders.reduce((a,o)=>{ if(Number(o.feeGst||0)) return a+Number(o.feeGst||0); const f=Number(o.commission||0); return a+(f?f*18/118:0); },0); }
 const taxableSales=Math.max(0,Number(s.gross||0)-salesGst), feeTaxable=Math.max(0,Number(s.fees||0)-feeGst);
 return {salesGst,feeGst,totalGst:salesGst+feeGst,taxableSales,feeTaxable,netGstBeforeOtherITC:salesGst-feeGst};
}
function reconBaseRows(){
 ensureMarketplaceV6();
 return data.marketplaceSettlements.map((s,i)=>{
  const isFlipkart=String(s.channel)==='Flipkart' && Array.isArray(s.items) && s.items.length;
  const expected=isFlipkart ? s.items.reduce((a,it)=>a+num(it.expectedSettlement),0) : Math.max(0,num(s.gross)-num(s.fees)-num(s.tcs)-num(s.tds)-num(s.refunds)-num(s.shipping)-num(s.otherDeductions)+num(s.adjustments));
  const actual=num(s.netReceived), diff=actual-expected;
  const channelOrders=data.marketplaceOrders.filter(o=>o.channel===s.channel&&(!s.fromDate||String(o.date)>=String(s.fromDate))&&(!s.toDate||String(o.date)<=String(s.toDate)));
  const orderGross=channelOrders.reduce((a,o)=>a+num(o.sellingPrice),0);
  const gst=reconGSTForSettlement(s);
  const status=Math.abs(diff)<0.01?'Matched':(s.status==='Pending'?'Pending':'Mismatch');
  s.expected=expected;s.difference=diff;s.status=status;
  return {s,i,expected,actual,diff,orderGross,orderCount:channelOrders.length,status,channel:s.channel,...gst};
 });
}
function reconUploadSummary(){
 const u=data.reconUploads||[]; return u.slice(-12).reverse();
}
function reconBankRows(){
 return (data.bankTransactions||[]).map((b,i)=>{const ref=String(b.reference||'').trim().toLowerCase();const match=(data.marketplaceSettlements||[]).find(s=>ref&&String(s.bankRef||'').trim().toLowerCase()===ref);const amount=num(b.credit||0)-num(b.debit||0);const diff=match?amount-num(match.netReceived):null;return {...b,i,amount,match,diff,status:match?(Math.abs(diff||0)<0.01?'Matched':'Mismatch'):'Unmatched'};});
}
function openFinanceCard(focus){
  window.reconFilters=window.reconFilters||{channel:'All',month:'',from:'',to:'',status:'All',view:'dashboard'};
  window.reconFilters.focus=focus||'';
  show('reconciliation');
}
function financeCard(label,value,sub='',cls='',focus=''){
  const click=focus?`openFinanceCard('${focus}')`:'';
  const key=focus?` role="button" tabindex="0" title="Open ${esc(label)} details" onclick="${click}" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();${click}}"`:' ';
  return `<div class="finance-kpi ${cls}"${key}><div class="label">${esc(label)}</div><div class="value">${value}</div>${sub?`<div class="hint">${sub}</div>`:''}</div>`;
}
function applyReconDetailVisibility(){ const root=document.getElementById('content'); if(!root)return; const kpi=root.querySelector('.finance-kpis'); if(!kpi)return; const visible=window.reconDetailsVisible===true; const children=[...root.children]; const idx=children.indexOf(kpi); children.slice(idx+1).forEach(el=>{if(el.classList.contains('panel'))el.style.display=visible?'':'none';}); }
function reconciliation(){
  purgeReconciliationDummyData();
  rebuildFlipkartPaymentFromRaw();
  normalizeFlipkartSettlementItems();
  const f=getReconFilters();
  const all=reconBaseRows();
  const search=String(f.search||'').trim().toLowerCase();
  const active=window.reconFiltersApplied===true && Boolean(f.month);
  let rows=all.filter(x=>{
    const s=x.s||{};
    if(f.channel!=='All' && x.channel!==f.channel) return false;
    if(f.month){ const m=reconSettlementDate(s).slice(0,7); if(m!==f.month) return false; }
    if(!reconDateMatch(s,f.from,f.to)) return false;
    if(f.status!=='All' && x.status!==f.status) return false;
    if(search){
      const hit=String(s.settlementId||'').toLowerCase().includes(search) || (s.items||[]).some(it=>String(it.orderId||'').toLowerCase().includes(search));
      if(!hit) return false;
    }
    return true;
  });
  const focus=f.focus||'';
  const focusMap={sales:x=>num(x.s.gross)!==0,expectedSettlement:x=>x.expected!==0,actualReceived:x=>x.actual!==0,settlementDifference:x=>Math.abs(x.diff)>0.01,fees:x=>num(x.s.fees)!==0,salesGst:x=>x.salesGst!==0,feeGst:x=>x.feeGst!==0,tcs:x=>num(x.s.tcs)!==0,tds:x=>num(x.s.tds)!==0,refunds:x=>num(x.s.refunds)!==0,shipping:x=>num(x.s.shipping)!==0};
  if(focus && focusMap[focus]) rows=rows.filter(focusMap[focus]);
  const totalExpected=rows.reduce((a,x)=>a+num(x.expected),0), totalActual=rows.reduce((a,x)=>a+num(x.actual),0), difference=totalActual-totalExpected;
  const totalGross=rows.reduce((a,x)=>a+num(x.s.gross),0), totalFees=rows.reduce((a,x)=>a+num(x.s.fees),0), totalTcs=rows.reduce((a,x)=>a+num(x.s.tcs),0), totalTds=rows.reduce((a,x)=>a+num(x.s.tds),0), totalRefunds=rows.reduce((a,x)=>a+num(x.s.refunds),0), totalShipping=rows.reduce((a,x)=>a+num(x.s.shipping),0), totalSalesGst=rows.reduce((a,x)=>a+num(x.salesGst),0), totalFeeGst=rows.reduce((a,x)=>a+num(x.feeGst),0);
  const detailRows=rows.flatMap(x=>{
    const items=Array.isArray(x.s.items)&&x.s.items.length?x.s.items:[{orderId:'',sku:'',principal:x.s.gross,expectedSettlement:x.expected}];
    return items.map(it=>({x,it}));
  });
  const bankRows=reconBankRows().filter(x=>(f.channel==='All'||!x.channel||x.channel===f.channel)&&(!f.from||String(x.date||'')>=f.from)&&(!f.to||String(x.date||'')<=f.to));
  const unmatched=bankRows.filter(x=>x.status==='Unmatched').length, bankMismatch=bankRows.filter(x=>x.status==='Mismatch').length;
  const tabs=`<div class="finance-tabs"><button class="finance-tab ${f.view==='pnl'?'':'active'}" onclick="setReconView('dashboard')">💰 Reconciliation Dashboard</button><button class="finance-tab ${f.view==='pnl'?'active':''}" onclick="setReconView('pnl')">📊 P&amp;L</button></div>`;
  const filters=`<div class="panel"><div class="finance-filters">
    <label class="field"><span>Marketplace</span><select id="reconChannel"><option value="All" ${f.channel==='All'?'selected':''}>All Marketplaces</option><option value="Amazon" ${f.channel==='Amazon'?'selected':''}>Amazon</option><option value="Flipkart" ${f.channel==='Flipkart'?'selected':''}>Flipkart</option><option value="Meesho" ${f.channel==='Meesho'?'selected':''}>Meesho</option></select></label>
    <label class="field"><span>Month <small style="opacity:.7">(Payment / Settlement Date)</small></span><select id="reconMonth"><option value="">Select Month</option>${[...new Set((data.marketplaceSettlements||[]).map(s=>reconSettlementDate(s).slice(0,7)).filter(Boolean))].sort().reverse().map(m=>`<option value="${m}" ${f.month===m?'selected':''}>${new Date(m+'-01T00:00:00').toLocaleDateString('en-IN',{month:'long',year:'numeric'})}</option>`).join('')}</select></label>
    <label class="field"><span>From Date</span><input id="reconFrom" type="date" value="${esc(f.from)}"></label><label class="field"><span>To Date</span><input id="reconTo" type="date" value="${esc(f.to)}"></label>
    <label class="field"><span>Order ID Search</span><input id="reconOrderSearch" type="search" placeholder="Search Order ID / Settlement ID" value="${esc(f.search||'')}" onkeydown="if(event.key==='Enter')setReconFilters()"></label>
    <label class="field"><span>Settlement Status</span><select id="reconStatus"><option value="All" ${f.status==='All'?'selected':''}>All Status</option><option value="Matched" ${f.status==='Matched'?'selected':''}>Matched</option><option value="Mismatch" ${f.status==='Mismatch'?'selected':''}>Mismatch</option><option value="Pending" ${f.status==='Pending'?'selected':''}>Pending</option></select></label>
    <button class="btn" onclick="setReconFilters()">🔎 Apply Filter</button><button class="btn secondary" onclick="window.reconFilters={channel:'All',month:'',from:'',to:'',status:'All',search:'',focus:'',view:'dashboard'};window.reconFiltersApplied=false;window.reconDetailsVisible=false;show('reconciliation')">Reset</button>
  </div></div>`;
  if(f.view==='pnl') return `<div class="reporthero"><h2>📊 Marketplace P&amp;L &amp; Reconciliation</h2><div style="opacity:.9">Amazon • Flipkart • Meesho — profitability and settlement control</div></div>${tabs}${filters}${reconciliationPnlBody(f)}`;
  if(!active) return `<div class="reporthero"><h2>🧾 Gezeno Marketplace Payment Reconciliation</h2><div style="opacity:.9">Original marketplace settlement → order-level expected vs actual → discrepancy control</div></div>${tabs}${filters}<div class="panel" style="margin-top:16px"><div class="alertbox warn"><b>Month select karke Apply Filter karein</b><div class="hint">Reconciliation Dashboard ka financial data tab tak show nahi hoga jab tak aap month select nahi karte.</div></div></div>`;
  if(!active) return `<div class="reporthero"><h2>🧾 Gezeno Marketplace Payment Reconciliation</h2><div style="opacity:.9">Original marketplace settlement → order-level expected vs actual → discrepancy control</div></div>${tabs}${filters}<div class="panel" style="margin-top:16px"><div class="alertbox warn"><b>Month select karke Apply Filter karein</b><div class="hint">Reconciliation Dashboard ka financial data tab tak show nahi hoga jab tak aap month select nahi karte.</div></div></div>`;
  window.reconDetailsVisible=active;
  const detailPanel=active?`<div class="panel"><h3>Order-wise Payment Reconciliation</h3><div class="hint" style="margin-bottom:10px">${f.month?'Selected month ke sabhi matching Order IDs yahan show honge. ':''}Flipkart ke liye original signed Excel values calculation source hain; negative deductions dobara subtract nahi kiye jaate.</div><div style="overflow:auto"><table class="table"><thead><tr><th>Order ID</th><th>Marketplace</th><th>Settlement ID</th><th>Sale</th><th>Marketplace Fee</th><th>Tax</th><th>TCS</th><th>TDS</th><th>Expected</th><th>Actual</th><th>Difference</th><th>Status</th></tr></thead><tbody>${detailRows.map(({x,it})=>{const expected=num(it.expectedSettlement||x.expected);const actual=itemsActualForDisplay(it,x);const d=actual===null?null:actual-expected;const st=d===null?'Pending':Math.abs(d)<.01?'Matched':'Mismatch';return `<tr><td><b>${esc(it.orderId||'—')}</b></td><td>${esc(x.channel)}</td><td>${esc(x.s.settlementId||'—')}</td><td>₹${num(it.principal||0).toLocaleString('en-IN',{minimumFractionDigits:0})}</td><td>₹${num(it.marketplaceFee||0).toLocaleString('en-IN',{minimumFractionDigits:0})}</td><td>₹${num(it.taxes||it.tax||0).toLocaleString('en-IN',{minimumFractionDigits:0})}</td><td>₹${num(it.tcs||0).toLocaleString('en-IN',{minimumFractionDigits:0})}</td><td>₹${num(it.tds||0).toLocaleString('en-IN',{minimumFractionDigits:0})}</td><td>₹${expected.toLocaleString('en-IN',{minimumFractionDigits:0})}</td><td>${actual===null?'Pending':'₹'+actual.toLocaleString('en-IN',{minimumFractionDigits:0})}</td><td>${d===null?'—':'₹'+d.toLocaleString('en-IN',{minimumFractionDigits:0})}</td><td><span class="badge ${st==='Matched'?'green':st==='Mismatch'?'red':'orange'}">${st}</span></td></tr>`}).join('')||'<tr><td colspan="12">No matching reconciliation records.</td></tr>'}</tbody></table></div></div>`:'';
  return `<div class="reporthero"><h2>🧾 Gezeno Marketplace Payment Reconciliation</h2><div style="opacity:.9">Original marketplace settlement → order-level expected vs actual → discrepancy control</div></div>${tabs}${filters}<div class="finance-kpis">${financeCard('Gross Sales',`₹${totalGross.toLocaleString('en-IN',{minimumFractionDigits:0})}`,'Settlement sales','','sales')}${financeCard('Expected Settlement',`₹${totalExpected.toLocaleString('en-IN',{minimumFractionDigits:0})}`,'Signed source calculation','','expectedSettlement')}${financeCard('Actual Received',`₹${totalActual.toLocaleString('en-IN',{minimumFractionDigits:0})}`,'Marketplace payout','good','actualReceived')}${financeCard('Difference',`₹${difference.toLocaleString('en-IN',{minimumFractionDigits:0})}`,'Actual − Expected',Math.abs(difference)>.01?'bad':'good','settlementDifference')}${financeCard('Fees',`₹${totalFees.toLocaleString('en-IN',{minimumFractionDigits:0})}`,'Marketplace fees','','fees')}${financeCard('Sales GST',`₹${totalSalesGst.toLocaleString('en-IN',{minimumFractionDigits:0})}`,'Output GST','','salesGst')}${financeCard('Fee GST / ITC',`₹${totalFeeGst.toLocaleString('en-IN',{minimumFractionDigits:0})}`,'Marketplace fee GST','','feeGst')}${financeCard('TCS',`₹${totalTcs.toLocaleString('en-IN',{minimumFractionDigits:0})}`,'Tax collection','','tcs')}${financeCard('TDS',`₹${totalTds.toLocaleString('en-IN',{minimumFractionDigits:0})}`,'Tax deduction','','tds')}${financeCard('Refunds',`₹${totalRefunds.toLocaleString('en-IN',{minimumFractionDigits:0})}`,'Refund/credit','','refunds')}${financeCard('Shipping',`₹${totalShipping.toLocaleString('en-IN',{minimumFractionDigits:0})}`,'Shipping charges','','shipping')}</div>${detailPanel}`;
}
function itemsActualForDisplay(it,x){ if(it && (it.netPayout!==undefined || it.bankSettlementValue!==undefined)) return num(it.netPayout!==undefined?it.netPayout:it.bankSettlementValue); if(x && x.s && x.s.items && x.s.items.length===1) return num(x.actual); return null; }

function reconciliationPnlBody(f){
 const applied=window.reconFiltersApplied===true;
 if(!applied) return '<div class="panel"><div class="hint">P&amp;L data dekhne ke liye Month / Date / Marketplace / Status / Search filter select karke Apply Filter dabayein.</div></div>';
 const channels=f.channel==='All'?['Amazon','Flipkart','Meesho']:[f.channel];
 const channelRows=channels.map(ch=>{
  const orders=data.marketplaceOrders.filter(o=>o.channel===ch&&(!f.month||String(o.date).slice(0,7)===f.month)&&(!f.from||String(o.date)>=f.from)&&(!f.to||String(o.date)<=f.to)&&(!f.status||f.status==='All'||(f.status==='Matched'&&String(o.paymentStatus||'')==='Settled')||(f.status==='Pending'&&String(o.paymentStatus||'')==='Pending')||(f.status==='Mismatch'&&String(o.paymentStatus||'')==='Partial')));
  const sales=orders.reduce((a,o)=>a+num(o.sellingPrice),0);
  const cogs=orders.reduce((a,o)=>{const p=data.products.find(x=>x.sku===o.sku)||{};return a+num(p.purchase)*Math.max(1,num(o.qty));},0);
  const marketplaceFees=orders.reduce((a,o)=>a+num(o.commission),0);
  const shipping=orders.reduce((a,o)=>a+num(o.shippingFee),0);
  const ads=orders.reduce((a,o)=>a+num(o.adsCost),0);
  const returns=orders.reduce((a,o)=>a+num(o.returnCost),0);
  const other=orders.reduce((a,o)=>a+num(o.otherCost),0);
  const profit=sales-cogs-marketplaceFees-shipping-ads-returns-other;
  const margin=sales?profit/sales*100:0;
  const settlement=data.marketplaceSettlements.filter(s=>s.channel===ch&&(!f.month||reconSettlementDate(s).slice(0,7)===f.month)&&reconDateMatch(s,f.from,f.to));
  const actualReceived=settlement.reduce((a,s)=>a+num(s.netReceived),0);
  const tcs=settlement.reduce((a,s)=>a+num(s.tcs),0),tds=settlement.reduce((a,s)=>a+num(s.tds),0);
  return {ch,orders:orders.length,sales,cogs,marketplaceFees,shipping,ads,returns,other,profit,margin,actualReceived,tcs,tds};
 });
 const totals=channelRows.reduce((a,r)=>{for(const k of ['orders','sales','cogs','marketplaceFees','shipping','ads','returns','other','profit','actualReceived','tcs','tds'])a[k]+=r[k];return a;},{orders:0,sales:0,cogs:0,marketplaceFees:0,shipping:0,ads:0,returns:0,other:0,profit:0,actualReceived:0,tcs:0,tds:0});
 totals.margin=totals.sales?totals.profit/totals.sales*100:0;
 return `<div class="finance-kpis">${financeCard('Sales',`₹${totals.sales.toLocaleString('en-IN')}`,'Order sales','','sales')}${financeCard('COGS / Product Cost',`₹${totals.cogs.toLocaleString('en-IN')}`,'Product cost','','cogs')}${financeCard('Marketplace + Shipping',`₹${(totals.marketplaceFees+totals.shipping).toLocaleString('en-IN')}`,'Fees and logistics','','fees')}${financeCard('Net Operating Profit',`₹${totals.profit.toLocaleString('en-IN')}`,'Click for profit details','good','profit')}${financeCard('Margin',`${totals.margin.toFixed(2)}%`,'Profit margin',totals.profit<0?'bad':'good','profit')}</div><div class="panel"><h3>Marketplace-wise P&L</h3><div style="overflow:auto"><table class="table"><thead><tr><th>Marketplace</th><th>Orders</th><th>Sales</th><th>COGS</th><th>Marketplace Fees</th><th>Shipping</th><th>Ads</th><th>Returns/RTO</th><th>Other</th><th>Net Profit</th><th>Margin</th><th>Settlement Received</th></tr></thead><tbody>${channelRows.map(r=>`<tr><td><b>${r.ch}</b></td><td>${r.orders}</td><td>₹${r.sales.toLocaleString('en-IN')}</td><td>₹${r.cogs.toLocaleString('en-IN')}</td><td>₹${r.marketplaceFees.toLocaleString('en-IN')}</td><td>₹${r.shipping.toLocaleString('en-IN')}</td><td>₹${r.ads.toLocaleString('en-IN')}</td><td>₹${r.returns.toLocaleString('en-IN')}</td><td>₹${r.other.toLocaleString('en-IN')}</td><td><b>₹${r.profit.toLocaleString('en-IN')}</b></td><td>${r.margin.toFixed(2)}%</td><td>₹${r.actualReceived.toLocaleString('en-IN')}</td></tr>`).join('')||'<tr><td colspan="12">No marketplace order data matches the selected filters.</td></tr>'}</tbody><tfoot><tr><th>All Selected</th><th>${totals.orders}</th><th>₹${totals.sales.toLocaleString('en-IN')}</th><th>₹${totals.cogs.toLocaleString('en-IN')}</th><th>₹${totals.marketplaceFees.toLocaleString('en-IN')}</th><th>₹${totals.shipping.toLocaleString('en-IN')}</th><th>₹${totals.ads.toLocaleString('en-IN')}</th><th>₹${totals.returns.toLocaleString('en-IN')}</th><th>₹${totals.other.toLocaleString('en-IN')}</th><th>₹${totals.profit.toLocaleString('en-IN')}</th><th>${totals.margin.toFixed(2)}%</th><th>₹${totals.actualReceived.toLocaleString('en-IN')}</th></tr></tfoot></table></div></div><div class="panel"><h3>Profit Breakdown</h3><div class="finance-kpis">${financeCard('Ads Cost',`₹${totals.ads.toLocaleString('en-IN')}`,'Advertising spend','','ads')}${financeCard('Returns Cost',`₹${totals.returns.toLocaleString('en-IN')}`,'Returns cost','','refunds')}${financeCard('Other Order Cost',`₹${totals.other.toLocaleString('en-IN')}`,'Other costs','','other')}${financeCard('TCS',`₹${totals.tcs.toLocaleString('en-IN')}`,'Tax collection','','tcs')}${financeCard('TDS',`₹${totals.tds.toLocaleString('en-IN')}`,'Tax deduction','','tds')}</div><div class="finance-note"><b>P&L treatment:</b> TCS/TDS are displayed for cash/reconciliation visibility but excluded from operating expense, because they are generally tax credits/withholdings rather than marketplace operating costs. GST on marketplace fees is also not automatically treated as an expense.</div></div>`;
}
function seedExactAMZ10001(){
 const key='gezenoExactAMZ10001V1'; if(localStorage.getItem(key)) return;
 data.marketplaceOrders=data.marketplaceOrders||[]; data.marketplaceSettlements=data.marketplaceSettlements||[]; data.bankTransactions=data.bankTransactions||[]; data.products=data.products||[];
 if(!data.products.some(p=>p.sku==='SPK-001')) data.products.push({sku:'SPK-001',name:'Bluetooth Speaker',category:'Electronics',parentCategory:'Electronics',vendor:'Demo Electronics Supplier',purchase:600,b2b:1180,mrp:1299,gst:18,stock:99,reorder:10});
 const order={orderId:'AMZ-10001',channel:'Amazon',date:'2026-10-04',customer:'Rahul Sharma',deliveryAddress:'Delhi',sku:'SPK-001',qty:1,sellingPrice:1180,gstRate:18,gstAmount:180,commission:150,feeGst:39.60,shippingFee:50,adsCost:0,returnCost:0,otherCost:20,courier:'Amazon Logistics',awb:'AMZ10001AWB',status:'Delivered',paymentStatus:'Settled',cogs:600,taxableSale:1000};
 const oi=data.marketplaceOrders.find(x=>x.orderId===order.orderId); if(oi) Object.assign(oi,order); else data.marketplaceOrders.push(order);
 const settlement={settlementId:'SET-AMZ-10001',channel:'Amazon',fromDate:'2026-10-04',toDate:'2026-10-04',gross:1180,salesGst:180,fees:259.60,feeTaxable:220,feeGst:39.60,tcs:10,tds:10,refunds:0,shipping:0,otherDeductions:0,adjustments:0,netReceived:900.40,receivedDate:'2026-10-04',bankRef:'AMZUTR987654',status:'Reconciled',expected:900.40,difference:0};
 const si=data.marketplaceSettlements.find(x=>x.settlementId===settlement.settlementId); if(si) Object.assign(si,settlement); else data.marketplaceSettlements.push(settlement);
 const bank={date:'2026-10-04',description:'AMAZON SETTLEMENT AMZUTR987654 — AMZ-10001',reference:'AMZUTR987654',credit:900.40,debit:0,channel:'Amazon'};
 const bi=data.bankTransactions.find(x=>String(x.reference||'')===bank.reference); if(bi) Object.assign(bi,bank); else data.bankTransactions.push(bank);
 data.reconTaxFiles=data.reconTaxFiles||[]; const ti=data.reconTaxFiles.find(x=>x.orderId==='AMZ-10001'); const tax={channel:'Amazon',file:'AMZ-10001-demo-tax.csv',uploadedAt:'04/10/2026 13:30',settlementId:'SET-AMZ-10001',orderId:'AMZ-10001',salesGst:180,feeGst:39.60,tcs:10,tds:10}; if(ti) Object.assign(ti,tax); else data.reconTaxFiles.push(tax);
 data.reconUploads=data.reconUploads||[]; if(!data.reconUploads.some(x=>x.file==='AMZ-10001-demo-order.csv')){ const at='04/10/2026 13:30'; data.reconUploads.push({at,channel:'Amazon',type:'Orders',file:'AMZ-10001-demo-order.csv',rows:1},{at,channel:'Amazon',type:'Payment / Settlement',file:'AMZ-10001-demo-payment.csv',rows:1},{at,channel:'Amazon',type:'GST / Tax',file:'AMZ-10001-demo-tax.csv',rows:1},{at,channel:'Amazon',type:'Bank Statement',file:'AMZ-10001-demo-bank.csv',rows:1}); }
 localStorage.setItem(key,'1'); save();
}
function seed90DayArchiveDemo(){
  if(localStorage.getItem('gezeno90DayDemoSeeded')==='1')return;
  data.marketplaceOrders=data.marketplaceOrders||[];data.marketplaceSettlements=data.marketplaceSettlements||[];data.marketplaceReturns=data.marketplaceReturns||[];data.marketplaceAds=data.marketplaceAds||[];data.bankTransactions=data.bankTransactions||[];data.reconRawRows=data.reconRawRows||[];
  const makeOrder=(id,ch,days,sku,product,price,commission,shipping,status)=>{
    const existing=data.marketplaceOrders.find(x=>x.orderId===id); if(existing) return existing;
    const date=addDaysISO(todayISO(),-days), gst=Math.round(price/1.18*0.18*100)/100, expected=Number(price)-Number(commission)-Number(shipping)-Number(gst*0.18);
    const o={orderId:id,channel:ch,date,customer:`Dummy ${ch} Buyer ${id.slice(-3)}`,sku,productName:product,qty:1,sellingPrice:price,gstRate:18,gstAmount:gst,commission,feeGst:Math.round(commission*.18*100)/100,shippingFee:shipping,adsCost:days%2?15:10,returnCost:status==='Returned'?60:0,otherCost:5,courier:ch==='Amazon'?'Amazon Logistics':ch==='Flipkart'?'Ekart':'Delhivery',awb:`${ch.slice(0,3).toUpperCase()}90${days}${id.slice(-2)}`,status,paymentStatus:days>=90?'Settled':'Pending',cogs:Math.round(price*.5),tcs:Math.round(price*.01*100)/100,tds:Math.round(price*.001*100)/100,expectedSettlement:Math.round(expected*100)/100};
    data.marketplaceOrders.push(o);
    const sid=`SET-90D-${id}`; const received=days>=90?o.expectedSettlement:0;
    data.marketplaceSettlements.push({settlementId:sid,orderId:id,channel:ch,fromDate:date,toDate:date,gross:price,salesGst:gst,fees:commission,feeGst:o.feeGst,tcs:o.tcs,tds:o.tds,refunds:o.returnCost,shipping:shipping,otherDeductions:o.otherCost,adjustments:0,netReceived:received,receivedDate:days>=90?addDaysISO(date,3):'',bankRef:days>=90?`UTR-${id}`:'',status:days>=90?'Reconciled':'Pending'});
    data.marketplaceAds.push({orderId:id,channel:ch,date,spend:o.adsCost,campaign:`${ch} Dummy Campaign`,status:'Completed'});
    if(status==='Returned')data.marketplaceReturns.push({orderId:id,channel:ch,date:addDaysISO(date,days>90?5:10),sku,qty:1,reason:'Dummy customer return',refundAmount:price,reverseShipping:60,status:'Received',lossAmount:60});
    if(days>=90)data.bankTransactions.push({orderId:id,date:addDaysISO(date,3),description:`${ch} Settlement ${id}`,reference:`UTR-${id}`,credit:received,debit:0,channel:ch,status:'Matched'});
    const file=`${ch}_DUMMY_90DAY_ORDERS.csv`;
    data.reconRawRows.push({key:`dummy90|${id}`,channel:ch,type:'Orders',file,rowNumber:data.reconRawRows.filter(x=>x.file===file).length+2,importedAt:new Date().toLocaleString('en-IN'),date,orderId:id,settlementId:sid,raw:{'Order ID':id,'Order Date':date,'Marketplace':ch,'SKU':sku,'Product Name':product,'Qty':1,'Selling Price':price,'Commission':commission,'Shipping':shipping,'GST':gst,'Status':status}});
    return o;
  };
  const demo=[
    ['AMZ-90D-091','Amazon',91,'GZN-SPK-001','Bluetooth Speaker',1180,150,50,'Delivered'],
    ['AMZ-90D-120','Amazon',120,'GZN-TOY-002','Remote Car',1598,192,80,'Returned'],
    ['AMZ-90D-60','Amazon',60,'GZN-GAM-004','Board Game',999,140,55,'Delivered'],
    ['FK-90D-090','Flipkart',90,'GZN-PAD-003','Writing Pad',897,126,60,'Delivered'],
    ['FK-90D-100','Flipkart',100,'GZN-KIT-005','Clay Art Kit',498,70,50,'Returned'],
    ['FK-90D-45','Flipkart',45,'GZN-ACC-006','Kids Accessories Set',599,84,45,'Shipped'],
    ['MS-90D-095','Meesho',95,'GZN-SPK-001','Bluetooth Speaker',799,0,65,'Delivered'],
    ['MS-90D-89','Meesho',89,'GZN-TOY-002','Remote Car',699,0,55,'Delivered'],
    ['MS-90D-15','Meesho',15,'GZN-PAD-003','Writing Pad',299,0,45,'Shipped']
  ];
  demo.forEach(x=>makeOrder(...x));
  localStorage.setItem('gezeno90DayDemoSeeded','1');save();
}
function isReconDummyOrder(o){const id=String(o?.orderId||'').toUpperCase();return /-DEMO-|^.*-DUMMY-| -90D-|AMZ-10001/.test(id.replace(/\s+/g,'')) || id.includes('-90D-') || id.startsWith('AMZ-DEMO') || id.startsWith('FK-DEMO') || id.startsWith('MS-DEMO') || id.startsWith('AMZ-DUMMY') || id.startsWith('FK-DUMMY') || id.startsWith('MS-DUMMY');}

function rebuildFlipkartPaymentFromRaw(){
  const rawRows=(data.reconRawRows||[]).filter(x=>{
    if(String(x.channel)!=='Flipkart' || !/Payment.*Settlement/i.test(String(x.type||'')) || !x.raw || typeof x.raw!=='object') return false;
    // Payment reconciliation is order-level. Ignore template/meta rows that only
    // contain NEFT/settlement information but have no Order ID. Such rows were
    // causing negative/zero ghost settlements after an empty Flipkart template upload.
    const rr=x.raw||{};
    const oid=String(fkGet(rr,['Order ID','OrderID','order_id'],'')).trim();
    return !!oid;
  });
  if(!rawRows.length)return;
  const groups={};
  const get=(r,aliases,def='')=>fkGet(r,aliases,def);
  const n=(r,a)=>num(get(r,a,0));
  const st=(r,a)=>String(get(r,a,'')).trim();
  const dt=v=>excelDate(v)||String(v||'').slice(0,10);
  rawRows.forEach(w=>{
    const r=w.raw||{};
    const oid=st(r,['Order ID','OrderID','order_id']);
    const sid=st(r,['NEFT ID','NEFTID','Neft ID']);
    if(!oid&&!sid)return;
    const deletedKey=`Flipkart|${sid}`;
    if(sid && data.reconDeletedSettlementIds && data.reconDeletedSettlementIds[deletedKey]) return;
    const item={orderId:oid,orderItemId:st(r,['Order item ID','Order Item ID','OrderItemID']),settlementId:sid,postedDate:dt(get(r,[' Payment Date','Payment Date'],'')),paymentDate:dt(get(r,[' Payment Date','Payment Date'],'')),orderDate:dt(get(r,['Order Date','OrderDate'],'')),sku:st(r,['Seller SKU','SellerSKU','SKU']),qty:n(r,['Quantity','Qty']),principal:n(r,['Sale Amount (Rs.)','Sale Amount']),tax:Math.abs(n(r,['Taxes (Rs.)','Taxes'])),shipping:Math.abs(n(r,['Shipping Fee (Rs.)','Shipping Fee']))+Math.abs(n(r,['Reverse Shipping Fee (Rs.)','Reverse Shipping Fee'])),commission:Math.abs(n(r,['Commission (Rs.)','Commission'])),closingFee:Math.abs(n(r,['Fixed Fee  (Rs.)','Fixed Fee (Rs.)','Fixed Fee'])),fulfillmentShipping:Math.abs(n(r,['Pick And Pack Fee (Rs.)','Pick And Pack Fee'])),tcs:Math.abs(n(r,['TCS (Rs.)','TCS'])),tds:Math.abs(n(r,['TDS (Rs.)','TDS'])),netPayout:n(r,['Bank Settlement Value (Rs.)','Bank Settlement Value']),saleAmount:n(r,['Sale Amount (Rs.)','Sale Amount']),taxes:Math.abs(n(r,['Taxes (Rs.)','Taxes'])),shippingFee:Math.abs(n(r,['Shipping Fee (Rs.)','Shipping Fee'])),reverseShippingFee:Math.abs(n(r,['Reverse Shipping Fee (Rs.)','Reverse Shipping Fee'])),marketplaceFee:Math.abs(n(r,['Marketplace Fee (Rs.)','Marketplace Fee'])),feeGst:Math.abs(n(r,['GST on MP Fees (Rs.)','GST on MP Fees'])),refund:Math.abs(n(r,['Refund (Rs.)','Refund'])),offerAdjustments:n(r,['Offer Adjustments (Rs.)','Offer Adjustments']),raw:r,rowNumber:w.rowNumber};
    const key=sid||('ROW-'+oid);
    const g=groups[key]||(groups[key]={sid,paymentDate:item.paymentDate,rows:[],dates:[]});
    g.rows.push(item); if(!g.paymentDate&&item.paymentDate)g.paymentDate=item.paymentDate; if(item.orderDate)g.dates.push(item.orderDate);
  });
  Object.values(groups).forEach(g=>{
    if(!g.sid)return;
    const gross=g.rows.reduce((a,x)=>a+x.principal,0), gst=g.rows.reduce((a,x)=>a+x.tax,0), fees=g.rows.reduce((a,x)=>a+x.marketplaceFee,0), feeGst=g.rows.reduce((a,x)=>a+x.feeGst,0), tcs=g.rows.reduce((a,x)=>a+x.tcs,0), tds=g.rows.reduce((a,x)=>a+x.tds,0), refunds=g.rows.reduce((a,x)=>a+x.refund,0), shipping=g.rows.reduce((a,x)=>a+x.shipping,0), net=g.rows.reduce((a,x)=>a+x.netPayout,0), from=[...g.dates].sort()[0]||g.paymentDate, to=[...g.dates].sort().at(-1)||g.paymentDate;
    const obj={settlementId:g.sid,channel:'Flipkart',fromDate:from,toDate:to,gross,salesGst:gst,fees,feeGst,tcs,tds,refunds,shipping,otherDeductions:0,adjustments:g.rows.reduce((a,x)=>a+x.offerAdjustments,0),netReceived:net,expected:net,actualReceived:net,receivedDate:g.paymentDate,bankRef:g.sid,status:'Reconciled',sourceKind:'Flipkart Payment Settlement',orderCount:g.rows.length,items:g.rows,difference:0};
    const existing=(data.marketplaceSettlements||[]).find(x=>String(x.channel)==='Flipkart'&&String(x.settlementId)===String(g.sid));
    if(existing)Object.assign(existing,obj); else (data.marketplaceSettlements=data.marketplaceSettlements||[]).push(obj);
  });
}

function normalizeFlipkartSettlementItems(){
  data.marketplaceSettlements=(data.marketplaceSettlements||[]).map(s=>{
    if(String(s.channel)!=='Flipkart' || !Array.isArray(s.items)) return s;
    let totalGross=0,totalTax=0,totalShipping=0,totalCommission=0,totalClosing=0,totalFulfillment=0,totalTcs=0,totalTds=0,totalNet=0,totalFees=0,totalRefund=0,totalAdjust=0;
    s.items=s.items.map(it=>{
      const raw=it.raw||it.originalImportedRow||{};
      // IMPORTANT: raw imported Flipkart row is the source of truth. Do not let an
      // older normalized 0 value override a real value from the Excel row.
      const get=(aliases,def='')=>{
        const rv=fkGet(raw,aliases,undefined);
        if(rv!==undefined && rv!==null && String(rv).trim()!=='') return rv;
        const direct=aliases.map(a=>it[a]).find(v=>v!==undefined&&v!==null&&String(v).trim()!=='');
        return direct!==undefined?direct:def;
      };
      const money=(aliases,def=0)=>num(get(aliases,def));
      const orderId=String(get(['Order ID','OrderID','order_id'],it.orderId||'')).trim();
      const sku=String(get(['Seller SKU','SellerSKU','SKU'],it.sku||'')).trim();
      const qty=money(['Quantity','Qty'],it.qty||0);
      const sale=money(['Sale Amount (Rs.)','Sale Amount'],it.saleAmount??it.principal??0);
      const tax=Math.abs(money(['Taxes (Rs.)','Taxes'],it.taxes??it.tax??0));
      const shipping=Math.abs(money(['Shipping Fee (Rs.)','Shipping Fee'],it.shippingFee??0))+Math.abs(money(['Reverse Shipping Fee (Rs.)','Reverse Shipping Fee'],it.reverseShippingFee??0));
      const commission=Math.abs(money(['Commission (Rs.)','Commission'],it.commission??0));
      const closing=Math.abs(money(['Fixed Fee  (Rs.)','Fixed Fee (Rs.)','Fixed Fee'],it.fixedFee??it.closingFee??0));
      const fulfillment=Math.abs(money(['Pick And Pack Fee (Rs.)','Pick And Pack Fee'],it.pickAndPackFee??it.fulfillmentShipping??0));
      const tcs=Math.abs(money(['TCS (Rs.)','TCS'],it.tcs??0));
      const tds=Math.abs(money(['TDS (Rs.)','TDS'],it.tds??0));
      const payout=money(['Bank Settlement Value (Rs.)','Bank Settlement Value'],it.bankSettlementValue??it.netPayout??0);
      const marketplaceFee=Math.abs(money(['Marketplace Fee (Rs.)','Marketplace Fee'],it.marketplaceFee??0));
      const feeGst=Math.abs(money(['GST on MP Fees (Rs.)','GST on MP Fees'],it.feeGst??0));
      const refund=Math.abs(money(['Refund (Rs.)','Refund'],it.refund??0));
      const adjustments=money(['Offer Adjustments (Rs.)','Offer Adjustments'],it.offerAdjustments??0);
      const signedFee=money(['Marketplace Fee (Rs.)','Marketplace Fee'],0);
      const signedTax=money(['Taxes (Rs.)','Taxes'],0);
      const signedTcs=money(['TCS (Rs.)','TCS'],0);
      const signedTds=money(['TDS (Rs.)','TDS'],0);
      const signedProtection=money(['Protection Fund (Rs.)','Protection Fund'],0);
      const signedRefund=money(['Refund (Rs.)','Refund'],0);
      // Flipkart stores deductions as negative amounts. Keep display amounts positive,
      // but calculate Expected Settlement from the ORIGINAL signed values.
      const expectedSettlement=sale+signedFee+signedTax+signedTcs+signedTds+signedProtection+signedRefund+adjustments;
      const postedDate=excelDate(get([' Payment Date','Payment Date'],it.postedDate||it.paymentDate||''))||it.postedDate||it.paymentDate||'';
      Object.assign(it,{orderId,sku,qty,principal:sale,tax,shipping,commission,closingFee:closing,fulfillmentShipping:fulfillment,tcs,tds,netPayout:payout,saleAmount:sale,taxes:tax,shippingFee:Math.abs(money(['Shipping Fee (Rs.)','Shipping Fee'],0)),reverseShippingFee:Math.abs(money(['Reverse Shipping Fee (Rs.)','Reverse Shipping Fee'],0)),marketplaceFee,feeGst,refund,offerAdjustments:adjustments,expectedSettlement,postedDate});
      totalGross+=sale; totalTax+=tax; totalShipping+=shipping; totalCommission+=commission; totalClosing+=closing; totalFulfillment+=fulfillment; totalTcs+=tcs; totalTds+=tds; totalNet+=payout; totalFees+=marketplaceFee; totalRefund+=refund; totalAdjust+=adjustments;
      return it;
    });
    // Rebuild settlement-level totals from the actual order rows so dashboard KPIs
    // cannot remain at stale zero values after a mapping update.
    if(s.items.length){
      s.gross=totalGross; s.salesGst=totalTax; s.fees=totalFees; s.feeGst=s.items.reduce((a,it)=>a+Math.abs(num(it.feeGst)),0);
      s.tcs=totalTcs; s.tds=totalTds; s.refunds=totalRefund; s.shipping=totalShipping; s.adjustments=totalAdjust;
      s.netReceived=totalNet; s.actualReceived=totalNet;
      s.expected=s.items.reduce((a,it)=>a+num(it.expectedSettlement),0);
      s.difference=s.actualReceived-s.expected;
      if(!s.orderCount) s.orderCount=s.items.filter(it=>String(it.orderId||'').trim()).length;
    }
    return s;
  });
  save();
}
function purgeReconciliationDummyData(){
  const done=localStorage.getItem('gezenoReconDummyCleanV59')==='1';
  const bad=(v)=>{const x=String(v||'').toUpperCase();return x.includes('DEMO')||x.includes('DUMMY')||x.includes('90D');};
  data.marketplaceSettlements=(data.marketplaceSettlements||[]).filter(x=>!bad(x.settlementId)&&!bad(x.bankRef));
  data.marketplaceOrders=(data.marketplaceOrders||[]).filter(x=>!isReconDummyOrder(x));
  data.marketplaceReturns=(data.marketplaceReturns||[]).filter(x=>!isReconDummyOrder(x)&&!bad(x.returnId)&&!bad(x.sourceFile));
  data.marketplaceAds=(data.marketplaceAds||[]).filter(x=>!bad(x.campaign)&&!bad(x.sourceFile));
  data.bankTransactions=(data.bankTransactions||[]).filter(x=>!bad(x.reference)&&!bad(x.description));
  data.reconUploads=(data.reconUploads||[]).filter(x=>!bad(x.file));
  data.reconRawRows=(data.reconRawRows||[]).filter(x=>!bad(x.file)&&!bad(x.key));
  data.reconTaxFiles=(data.reconTaxFiles||[]).filter(x=>!bad(x.file)&&!bad(x.settlementId)&&!bad(x.orderId));
  if(!done){ localStorage.setItem('gezenoReconDummyCleanV59','1'); save(); }
}
seedExactAMZ10001();
ensureMarketplaceV6();
seed90DayArchiveDemo();
autoMoveOldOrdersToDump();
purgeReconciliationDummyData();
normalizeFlipkartSettlementItems();
// Switch the large business dataset to device-local IndexedDB.
initDeviceStorage();

function calcProductGST(items){
  return (items||[]).reduce((sum,it)=>{
    const qty=Number(it.qty||0), rate=Number(it.rate||it.price||0);
    const taxable=qty*rate;
    const gst=Number(it.gstRate ?? it.taxRate ?? 0);
    return sum + taxable*Math.max(0,gst)/100;
  },0);
}

/* SEARCH_LAYOUT_FIX */
(function(){
  if(document.getElementById('search-layout-fix-runtime')) return;
  const st=document.createElement('style'); st.id='search-layout-fix-runtime';
  st.textContent='.search,.order-search,#settlementSearch,#reconOrderSearch,#retSearch,.global-order-search input{box-sizing:border-box;min-width:0;max-width:100%;}.search,.order-search,#settlementSearch,#reconOrderSearch,#retSearch{width:100%;overflow-x:auto;text-overflow:clip;}.global-order-search{min-width:0;max-width:100%;}.global-order-search input{overflow-x:auto;text-overflow:clip;}@media(max-width:700px){.toolbar .search{flex:1 1 100%;width:100%;}.order-toolbar .order-search{grid-column:1/-1;width:100%;}.global-order-search{width:100%;min-width:0;}.global-order-search input{flex:1 1 auto;width:auto;min-width:0;}.gst-search-field,.gst-search-field input,#settlementSearch,#reconOrderSearch,#retSearch{min-width:0;width:100%;box-sizing:border-box;}}';
  document.head.appendChild(st);
})();
