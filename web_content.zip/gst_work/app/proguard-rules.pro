# Gezeno Android project - no custom ProGuard rules required.
