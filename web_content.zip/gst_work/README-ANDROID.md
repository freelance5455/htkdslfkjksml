# Gezeno Android Studio Project

This project packages the supplied Gezeno marketplace calculator as an offline Android WebView app.

## Included branding
- Generated Gezeno app icon installed as the launcher icon in all standard Android densities.
- Generated Gezeno splash screen installed and shown for about 1.8 seconds at launch.
- No INTERNET permission is declared.

## Build
Open this folder in Android Studio, let Gradle sync, then:
Build > Build Bundle(s) / APK(s) > Build APK(s)

Debug APK:
`app/build/outputs/apk/debug/app-debug.apk`
