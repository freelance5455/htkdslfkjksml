# جدولي (Jadwali)

موقع ثابت (ملف واحد `index.html`) لترتيب الجدول الأسبوعي للمدرسة من الأحد إلى الخميس بدون تضارب.
لا يحتاج سيرفر ولا تثبيت، ويحفظ بيانات الإدخال في متصفح المستخدم فقط.

## النشر على GitHub Pages

1. ادخل إلى github.com وسجّل الدخول، ثم اضغط **New repository**.
2. اكتب اسماً للمستودع (مثلاً `jadwali`)، واختر **Public**، ثم **Create repository**.
3. اضغط **uploading an existing file**، واسحب إليه الملفات: `index.html` و`README.md` و`.nojekyll`، ثم **Commit changes**.
4. افتح **Settings** ثم **Pages**.
5. تحت **Build and deployment** اختر **Deploy from a branch**، والفرع `main`، والمجلد `/ (root)`، ثم **Save**.
6. بعد دقيقة أو اثنتين يظهر الرابط بأعلى صفحة Pages بالشكل `https://اسم-حسابك.github.io/jadwali/`.

ملاحظة: الخطوط تُحمَّل من Google Fonts، فتحتاج الصفحة اتصالاً بالإنترنت أول مرة.
