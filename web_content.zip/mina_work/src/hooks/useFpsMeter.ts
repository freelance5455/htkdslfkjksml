import { useState, useEffect, useRef } from 'react';

export interface FpsMetrics {
  fps: number;
  avgFps: number;
  minFps: number;
  maxFps: number;
  onePercentLow: number;
  frameTimeMs: number;
  stutterCount: number;
  history: number[];
  refreshRate: number;
}

export function useFpsMeter(active: boolean = true): FpsMetrics {
  const [metrics, setMetrics] = useState<FpsMetrics>({
    fps: 60,
    avgFps: 60,
    minFps: 60,
    maxFps: 60,
    onePercentLow: 58,
    frameTimeMs: 16.6,
    stutterCount: 0,
    history: Array(25).fill(60),
    refreshRate: 60,
  });

  const frameTimesRef = useRef<number[]>([]);
  const lastTimeRef = useRef<number>(performance.now());
  const rafIdRef = useRef<number | null>(null);
  const lastUpdateRef = useRef<number>(performance.now());
  const detectedMaxFpsRef = useRef<number>(60);
  const totalStuttersRef = useRef<number>(0);

  useEffect(() => {
    if (!active) {
      if (rafIdRef.current) {
        cancelAnimationFrame(rafIdRef.current);
        rafIdRef.current = null;
      }
      return;
    }

    lastTimeRef.current = performance.now();
    lastUpdateRef.current = performance.now();
    frameTimesRef.current = [];

    const loop = (timestamp: number) => {
      const delta = timestamp - lastTimeRef.current;
      lastTimeRef.current = timestamp;

      // Filter out abnormal suspension spikes (e.g. user switched tabs)
      if (delta > 0 && delta < 500) {
        frameTimesRef.current.push(delta);
        if (frameTimesRef.current.length > 90) {
          frameTimesRef.current.shift();
        }

        // Expected frame time based on recent performance
        const expected = 1000 / detectedMaxFpsRef.current;
        if (delta > expected * 1.5) {
          totalStuttersRef.current += 1;
        }
      }

      // Update state every 250ms to keep UI performant and fluid
      const elapsedSinceUpdate = timestamp - lastUpdateRef.current;
      if (elapsedSinceUpdate >= 250 && frameTimesRef.current.length >= 5) {
        lastUpdateRef.current = timestamp;

        const count = frameTimesRef.current.length;
        const totalDuration = frameTimesRef.current.reduce((a, b) => a + b, 0);
        const avgFrameTime = totalDuration / count;
        const instantFps = Math.max(1, Math.min(240, Math.round(1000 / avgFrameTime)));

        // Sort frame times to compute 1% low (99th percentile slowest frame)
        const sorted = [...frameTimesRef.current].sort((a, b) => a - b);
        const onePercentIdx = Math.max(0, Math.floor(sorted.length * 0.99) - 1);
        const worstFrameTime = sorted[onePercentIdx] || avgFrameTime;
        const onePercentLow = Math.max(1, Math.min(instantFps, Math.round(1000 / worstFrameTime)));

        const minObserved = Math.max(1, Math.round(1000 / sorted[sorted.length - 1]));
        const maxObserved = Math.min(240, Math.round(1000 / sorted[0]));

        if (maxObserved > detectedMaxFpsRef.current) {
          detectedMaxFpsRef.current = maxObserved;
        }

        // Quantize estimated display refresh rate to standard hardware buckets
        let refreshBucket = 60;
        if (detectedMaxFpsRef.current >= 135) refreshBucket = 144;
        else if (detectedMaxFpsRef.current >= 110) refreshBucket = 120;
        else if (detectedMaxFpsRef.current >= 80) refreshBucket = 90;
        else refreshBucket = 60;

        setMetrics((prev) => {
          const newHistory = [...prev.history.slice(1), instantFps];
          return {
            fps: instantFps,
            avgFps: Math.round(1000 / avgFrameTime),
            minFps: Math.min(prev.minFps === 60 && prev.fps === 60 ? minObserved : prev.minFps, minObserved),
            maxFps: Math.max(prev.maxFps, maxObserved),
            onePercentLow,
            frameTimeMs: Number(avgFrameTime.toFixed(1)),
            stutterCount: totalStuttersRef.current,
            history: newHistory,
            refreshRate: refreshBucket,
          };
        });
      }

      rafIdRef.current = requestAnimationFrame(loop);
    };

    rafIdRef.current = requestAnimationFrame(loop);

    return () => {
      if (rafIdRef.current) {
        cancelAnimationFrame(rafIdRef.current);
        rafIdRef.current = null;
      }
    };
  }, [active]);

  return metrics;
}
