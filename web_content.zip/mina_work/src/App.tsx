/**
 * MINA OPTIMIZER PRO – ULTIMATE ANDROID GAMING OPTIMIZER
 * Created by Gaming Mina 10K
 * @license Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { Language, DeviceInfo, CleanupLog, GamingSession, AppNotification, SensitivitySettings, CrosshairConfig } from './types';
import { translations } from './utils/translations';
import { fetchDeviceInfo, performSafeRamClean, measurePing } from './utils/systemDiagnostics';
import { sounds } from './utils/audio';

// Components
import { WelcomeModal } from './components/WelcomeModal';
import { YouTubeSubscribeModal } from './components/YouTubeSubscribeModal';
import { Navbar } from './components/Navbar';
import { BottomNav } from './components/BottomNav';
import { ToolsDrawerModal } from './components/ToolsDrawerModal';
import { Dashboard } from './components/Dashboard';
import { DeviceInformationPro } from './components/DeviceInformationPro';
import { RamCleanerPro } from './components/RamCleanerPro';
import { LivePingMonitorPro } from './components/LivePingMonitorPro';
import { FreeFireOptimizer } from './components/FreeFireOptimizer';
import { AimTrainerPro } from './components/AimTrainerPro';
import { SensitivityPro } from './components/SensitivityPro';
import { HudSizeCalculator } from './components/HudSizeCalculator';
import { DeveloperOptionsGuide } from './components/DeveloperOptionsGuide';
import { ScriptRunnerPro } from './components/ScriptRunnerPro';
import { DeviceCoolingBattery } from './components/DeviceCoolingBattery';
import { StorageAnalyzerPro } from './components/StorageAnalyzerPro';
import { WifiSignalAnalyzer } from './components/WifiSignalAnalyzer';
import { ScreenRecorderPro } from './components/ScreenRecorderPro';
import { SessionHistoryPro } from './components/SessionHistoryPro';
import { CrosshairDesigner } from './components/CrosshairDesigner';
import { NotificationCenter } from './components/NotificationCenter';
import { UserProfileBackup } from './components/UserProfileBackup';
import { SettingsModal } from './components/SettingsModal';
import { FpsMonitorPro } from './components/FpsMonitorPro';
import { FpsOverlayHud } from './components/FpsOverlayHud';
import { useFpsMeter } from './utils/fpsMeter';

export default function App() {
  // Language (default: Sinhala 'si', persisted)
  const [language, setLanguage] = useState<Language>(() => {
    return (localStorage.getItem('mina_language') as Language) || 'si';
  });

  // First Open Onboarding state
  const [showWelcome, setShowWelcome] = useState<boolean>(() => {
    return !localStorage.getItem('mina_welcome_completed');
  });

  const [showSubscribeGate, setShowSubscribeGate] = useState<boolean>(() => {
    return !localStorage.getItem('mina_youtube_subscribed');
  });

  // Active Screen Navigation
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);

  // Sound effects
  const [soundEnabled, setSoundEnabled] = useState<boolean>(() => {
    return localStorage.getItem('mina_sound_enabled') !== 'false';
  });

  // Device Telemetry & Real-Time Stats
  const [deviceInfo, setDeviceInfo] = useState<DeviceInfo | null>(null);
  const [livePing, setLivePing] = useState<number | null>(null);
  const [isGamingMode, setIsGamingMode] = useState<boolean>(false);
  const wakeLockRef = useRef<any>(null);

  // Real-time Display FPS Engine & Floating HUD
  const fpsMetrics = useFpsMeter(true);
  const [isHudOpen, setIsHudOpen] = useState<boolean>(() => {
    return localStorage.getItem('mina_fps_hud_enabled') === 'true';
  });

  const handleToggleHud = () => {
    sounds.playClick();
    const next = !isHudOpen;
    setIsHudOpen(next);
    localStorage.setItem('mina_fps_hud_enabled', String(next));
  };

  // RAM Cleaning state
  const [isCleaningRam, setIsCleaningRam] = useState(false);
  const [cleanupHistory, setCleanupHistory] = useState<CleanupLog[]>(() => {
    try {
      const saved = localStorage.getItem('mina_cleanup_history');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Gaming Sessions
  const [sessions, setSessions] = useState<GamingSession[]>(() => {
    try {
      const saved = localStorage.getItem('mina_gaming_sessions');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Notifications
  const [notifications, setNotifications] = useState<AppNotification[]>([
    {
      id: '1',
      title: 'Gaming Mina 10K System Ready',
      message: 'MINA OPTIMIZER PRO v2.5.0 initialized with full hardware diagnostics.',
      timestamp: 'Just now',
      type: 'info',
      read: false,
    },
  ]);

  // Sensitivity Settings
  const [sensitivitySettings, setSensitivitySettings] = useState<SensitivitySettings>(() => {
    try {
      const saved = localStorage.getItem('mina_sens_settings');
      return saved
        ? JSON.parse(saved)
        : { general: 98, redDot: 95, scope2x: 92, scope4x: 88, sniperScope: 55, freeLook: 70 };
    } catch {
      return { general: 98, redDot: 95, scope2x: 92, scope4x: 88, sniperScope: 55, freeLook: 70 };
    }
  });

  // Custom Crosshair
  const [crosshair, setCrosshair] = useState<CrosshairConfig>(() => {
    try {
      const saved = localStorage.getItem('mina_crosshair');
      return saved
        ? JSON.parse(saved)
        : { type: 'dot', size: 20, color: '#00f0ff', opacity: 0.9, borderWidth: 2 };
    } catch {
      return { type: 'dot', size: 20, color: '#00f0ff', opacity: 0.9, borderWidth: 2 };
    }
  });

  // User Profile
  const [username, setUsername] = useState<string>(() => {
    return localStorage.getItem('mina_username') || 'Mina Gamer 10K';
  });

  // Load telemetry on mount
  useEffect(() => {
    const loadTelemetry = async () => {
      const info = await fetchDeviceInfo();
      setDeviceInfo(info);
      const ping = await measurePing();
      setLivePing(ping);
    };

    loadTelemetry();
  }, []);

  // Update HTML lang attribute on language change
  useEffect(() => {
    document.documentElement.lang = language;
    localStorage.setItem('mina_language', language);
  }, [language]);

  // Send System Notification helper
  const sendNotification = (title: string, message: string, type: 'info' | 'success' | 'warning' | 'alert' = 'info') => {
    const newNotif: AppNotification = {
      id: Date.now().toString(),
      title,
      message,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      type,
      read: false,
    };
    setNotifications((prev) => [newNotif, ...prev]);

    // Send browser native notification if permitted
    if (typeof Notification !== 'undefined' && Notification.permission === 'granted') {
      try {
        new Notification(`MINA PRO: ${title}`, {
          body: message,
          icon: '/assets/aistudio/InShot_20261021_172915725_10b6c6dd.jpg',
        });
      } catch {}
    }
  };

  // Toggle Screen Wake Lock (Gaming Mode)
  const handleToggleGamingMode = async () => {
    if (!isGamingMode) {
      try {
        if ('wakeLock' in navigator) {
          wakeLockRef.current = await (navigator as any).wakeLock.request('screen');
        }
        setIsGamingMode(true);
        sendNotification(
          language === 'si' ? 'Gaming Mode සක්‍රීයයි!' : 'Gaming Mode Activated!',
          language === 'si'
            ? 'Screen Wake Lock සක්‍රීය විය. ක්‍රීඩා කරන අතරතුර Screen එක Off නොවේ.'
            : 'Screen Wake Lock acquired. Display will remain on during matches.',
          'success'
        );
      } catch {
        setIsGamingMode(true);
      }
    } else {
      if (wakeLockRef.current) {
        wakeLockRef.current.release().catch(() => {});
        wakeLockRef.current = null;
      }
      setIsGamingMode(false);
      sendNotification(
        language === 'si' ? 'Gaming Mode අක්‍රීයයි' : 'Gaming Mode Deactivated',
        language === 'si' ? 'Screen Wake Lock නිදහස් කරන ලදි.' : 'Screen Wake Lock released.',
        'info'
      );
    }
  };

  // Safe RAM Clean Action
  const handleCleanRam = async () => {
    setIsCleaningRam(true);
    const result = await performSafeRamClean();

    const log: CleanupLog = {
      id: Date.now().toString(),
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
      freedMB: result.freedMB,
      beforeRamMB: result.beforeMB,
      afterRamMB: result.afterMB,
      target: 'Browser Cache & Memory Buffers',
    };

    const updatedLogs = [log, ...cleanupHistory].slice(0, 15);
    setCleanupHistory(updatedLogs);
    localStorage.setItem('mina_cleanup_history', JSON.stringify(updatedLogs));

    setIsCleaningRam(false);
    sendNotification(
      language === 'si' ? 'RAM පිරිසිදු කිරීම සාර්ථකයි!' : 'RAM Cleanup Completed!',
      language === 'si'
        ? `${result.freedMB} MB මතක ධාරිතාවක් ආරක්ෂිතව නිදහස් කරන ලදි.`
        : `${result.freedMB} MB of memory cache buffers were safely released.`,
      'success'
    );

    // Refresh telemetry
    const info = await fetchDeviceInfo();
    setDeviceInfo(info);
  };

  // Add Gaming Session
  const handleAddSession = (session: GamingSession) => {
    const updated = [session, ...sessions].slice(0, 20);
    setSessions(updated);
    localStorage.setItem('mina_gaming_sessions', JSON.stringify(updated));

    sendNotification(
      language === 'si' ? 'Gaming Session එක අවසන් විය!' : 'Gaming Session Finished!',
      language === 'si'
        ? `${session.game} මිනිත්තු ${session.durationMinutes} ක් ක්‍රීඩා කරන ලදි.`
        : `Played ${session.game} for ${session.durationMinutes} minutes.`,
      'success'
    );
  };

  // Request Notification permission
  const handleRequestNotificationPermission = async (): Promise<boolean> => {
    if (typeof Notification === 'undefined') return false;
    const res = await Notification.requestPermission();
    if (res === 'granted') {
      sendNotification(
        language === 'si' ? 'Notifications සක්‍රීය කරන ලදි' : 'Notifications Enabled',
        language === 'si' ? 'MINA OPTIMIZER PRO දැනුම්දීම් ඔබට ලැබෙනු ඇත.' : 'You will receive real-time gaming alerts.',
        'success'
      );
      return true;
    }
    return false;
  };

  // Factory reset
  const handleResetApp = () => {
    localStorage.clear();
    setCleanupHistory([]);
    setSessions([]);
    setNotifications([]);
    setSensitivitySettings({ general: 98, redDot: 95, scope2x: 92, scope4x: 88, sniperScope: 55, freeLook: 70 });
    setCrosshair({ type: 'dot', size: 20, color: '#00f0ff', opacity: 0.9, borderWidth: 2 });
    setUsername('Mina Gamer 10K');
    window.location.reload();
  };

  const unreadNotifs = notifications.filter((n) => !n.read).length;

  return (
    <div className="min-h-screen bg-[#030712] text-slate-100 flex flex-col antialiased selection:bg-cyan-500 selection:text-black">
      {/* 1. First Run Welcome Modal */}
      {showWelcome && (
        <WelcomeModal
          language={language}
          onLanguageChange={(l) => setLanguage(l)}
          onStart={() => {
            setShowWelcome(false);
            localStorage.setItem('mina_welcome_completed', 'true');
          }}
        />
      )}

      {/* 2. YouTube Subscribe Gate Modal (Cannot be skipped per requirement #6) */}
      {!showWelcome && showSubscribeGate && (
        <YouTubeSubscribeModal
          language={language}
          onSubscribeVerified={() => {
            setShowSubscribeGate(false);
            localStorage.setItem('mina_youtube_subscribed', 'true');
          }}
        />
      )}

      {/* 3. Top Navigation Bar */}
      <Navbar
        language={language}
        onLanguageToggle={() => setLanguage(language === 'si' ? 'en' : 'si')}
        activeTab={activeTab}
        onTabChange={(tab) => {
          sounds.playClick();
          setActiveTab(tab);
        }}
        isGamingMode={isGamingMode}
        onToggleGamingMode={handleToggleGamingMode}
        unreadCount={unreadNotifs}
        onOpenSettings={() => setIsSettingsOpen(true)}
        isOnline={deviceInfo ? deviceInfo.isOnline : true}
        livePing={livePing}
        soundEnabled={soundEnabled}
        onToggleSound={() => {
          const next = !soundEnabled;
          setSoundEnabled(next);
          localStorage.setItem('mina_sound_enabled', String(next));
        }}
        fps={fpsMetrics.fps}
        isHudOpen={isHudOpen}
        onToggleHud={handleToggleHud}
      />

      {/* 4. Desktop Sidebar + Main Content Layout */}
      <div className="max-w-7xl mx-auto w-full px-3 sm:px-6 py-4 flex-1 flex flex-col lg:flex-row gap-6">
        {/* Desktop Left Quick Navigation (Visible on lg+) */}
        <aside className="hidden lg:block w-64 shrink-0 space-y-1 bg-slate-950/60 border border-slate-800/80 rounded-3xl p-3 h-fit sticky top-20 shadow-xl">
          <div className="px-3 py-2 text-[11px] font-mono font-bold text-slate-500 uppercase tracking-wider">
            {language === 'si' ? 'ප්‍රධාන මෙනුව' : 'Navigation Menu'}
          </div>

          {[
            { id: 'dashboard', label: translations[language].tabDashboard },
            { id: 'fps', label: translations[language].tabFps },
            { id: 'freefire', label: translations[language].tabFreeFire },
            { id: 'ram', label: translations[language].tabRam },
            { id: 'ping', label: translations[language].tabPing },
            { id: 'aim', label: translations[language].tabAimTrainer },
            { id: 'sens', label: translations[language].tabSens },
            { id: 'hud', label: translations[language].tabHud },
            { id: 'device', label: translations[language].tabDevice },
            { id: 'cooling', label: translations[language].tabCooling },
            { id: 'storage', label: translations[language].tabStorage },
            { id: 'wifi', label: translations[language].tabWifi },
            { id: 'recorder', label: translations[language].tabRecorder },
            { id: 'devoptions', label: translations[language].tabDevOptions },
            { id: 'scripts', label: translations[language].tabScripts },
            { id: 'crosshair', label: translations[language].tabCrosshair },
            { id: 'sessions', label: translations[language].tabSessions },
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => {
                sounds.playClick();
                setActiveTab(item.id);
              }}
              className={`w-full px-3 py-2 rounded-xl text-xs font-semibold text-left transition-all cursor-pointer flex items-center justify-between ${
                activeTab === item.id
                  ? 'bg-cyan-950/80 border border-cyan-500/50 text-cyan-300 font-bold shadow-md shadow-cyan-950/40'
                  : 'text-slate-400 hover:text-white hover:bg-slate-900/60'
              }`}
            >
              <span className="truncate">{item.label}</span>
              {activeTab === item.id && <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />}
            </button>
          ))}
        </aside>

        {/* Dynamic Main Workspace Screen */}
        <main className="flex-1 min-w-0 pb-28 lg:pb-10">
          {activeTab === 'dashboard' && (
            <Dashboard
              language={language}
              deviceInfo={deviceInfo}
              livePing={livePing}
              fpsMetrics={fpsMetrics}
              isHudOpen={isHudOpen}
              onToggleHud={handleToggleHud}
              isGamingMode={isGamingMode}
              onToggleGamingMode={handleToggleGamingMode}
              onNavigate={(tab) => {
                sounds.playClick();
                setActiveTab(tab);
              }}
              onQuickCleanRam={handleCleanRam}
              isCleaningRam={isCleaningRam}
              onRefreshTelemetry={async () => {
                const info = await fetchDeviceInfo();
                setDeviceInfo(info);
              }}
            />
          )}

          {activeTab === 'fps' && (
            <FpsMonitorPro
              language={language}
              fpsMetrics={fpsMetrics}
              isHudOpen={isHudOpen}
              onToggleHud={handleToggleHud}
              onNavigate={(tab: string) => {
                sounds.playClick();
                setActiveTab(tab);
              }}
            />
          )}

          {activeTab === 'device' && (
            <DeviceInformationPro
              language={language}
              deviceInfo={deviceInfo}
              onRefresh={async () => {
                const info = await fetchDeviceInfo();
                setDeviceInfo(info);
              }}
            />
          )}

          {activeTab === 'ram' && (
            <RamCleanerPro
              language={language}
              deviceInfo={deviceInfo}
              cleanupHistory={cleanupHistory}
              onAddCleanupLog={(log) => {
                const updated = [log, ...cleanupHistory].slice(0, 15);
                setCleanupHistory(updated);
                localStorage.setItem('mina_cleanup_history', JSON.stringify(updated));
              }}
              onClearHistory={() => {
                setCleanupHistory([]);
                localStorage.removeItem('mina_cleanup_history');
              }}
              onRefreshTelemetry={async () => {
                const info = await fetchDeviceInfo();
                setDeviceInfo(info);
              }}
            />
          )}

          {activeTab === 'ping' && (
            <LivePingMonitorPro
              language={language}
              soundEnabled={soundEnabled}
              onLivePingUpdate={(p) => setLivePing(p)}
            />
          )}

          {activeTab === 'freefire' && (
            <FreeFireOptimizer
              language={language}
              isGamingMode={isGamingMode}
              onToggleGamingMode={handleToggleGamingMode}
              onNavigate={(tab) => {
                sounds.playClick();
                setActiveTab(tab);
              }}
              onAddSession={handleAddSession}
              currentBatteryLevel={deviceInfo?.batteryLevel ?? null}
              livePing={livePing}
            />
          )}

          {activeTab === 'aim' && (
            <AimTrainerPro
              language={language}
              soundEnabled={soundEnabled}
              crosshair={crosshair}
            />
          )}

          {activeTab === 'sens' && (
            <SensitivityPro
              language={language}
              settings={sensitivitySettings}
              onUpdateSettings={(s) => {
                setSensitivitySettings(s);
                localStorage.setItem('mina_sens_settings', JSON.stringify(s));
              }}
            />
          )}

          {activeTab === 'hud' && <HudSizeCalculator language={language} />}

          {activeTab === 'devoptions' && <DeveloperOptionsGuide language={language} />}

          {activeTab === 'scripts' && <ScriptRunnerPro language={language} />}

          {activeTab === 'cooling' && (
            <DeviceCoolingBattery language={language} deviceInfo={deviceInfo} />
          )}

          {activeTab === 'storage' && (
            <StorageAnalyzerPro
              language={language}
              deviceInfo={deviceInfo}
              onRefreshTelemetry={async () => {
                const info = await fetchDeviceInfo();
                setDeviceInfo(info);
              }}
            />
          )}

          {activeTab === 'wifi' && (
            <WifiSignalAnalyzer
              language={language}
              deviceInfo={deviceInfo}
              livePing={livePing}
            />
          )}

          {activeTab === 'recorder' && <ScreenRecorderPro language={language} />}

          {activeTab === 'sessions' && (
            <SessionHistoryPro
              language={language}
              sessions={sessions}
              onClearSessions={() => {
                setSessions([]);
                localStorage.removeItem('mina_gaming_sessions');
              }}
            />
          )}

          {activeTab === 'crosshair' && (
            <CrosshairDesigner
              language={language}
              crosshair={crosshair}
              onUpdateCrosshair={(c) => {
                setCrosshair(c);
                localStorage.setItem('mina_crosshair', JSON.stringify(c));
              }}
            />
          )}

          {activeTab === 'notifications' && (
            <NotificationCenter
              language={language}
              notifications={notifications}
              onClearNotifications={() => setNotifications([])}
              onRequestPermission={handleRequestNotificationPermission}
              onSendTestNotification={() =>
                sendNotification(
                  language === 'si' ? 'Test දැනුම්දීම' : 'Test Notification',
                  language === 'si'
                    ? 'MINA OPTIMIZER PRO දැනුම්දීම් පද්ධතිය සාර්ථකව ක්‍රියාත්මකයි!'
                    : 'MINA OPTIMIZER PRO notification channel is active and operational!',
                  'success'
                )
              }
            />
          )}

          {activeTab === 'profile' && (
            <UserProfileBackup
              language={language}
              username={username}
              onUpdateUsername={(name) => {
                setUsername(name);
                localStorage.setItem('mina_username', name);
              }}
              sensitivitySettings={sensitivitySettings}
              crosshair={crosshair}
              onRestoreAllSettings={({ username: u, sensitivity: s, crosshair: c }) => {
                setUsername(u);
                setSensitivitySettings(s);
                setCrosshair(c);
                localStorage.setItem('mina_username', u);
                localStorage.setItem('mina_sens_settings', JSON.stringify(s));
                localStorage.setItem('mina_crosshair', JSON.stringify(c));
              }}
              onResetApp={handleResetApp}
            />
          )}
        </main>
      </div>

      {/* 5. Mobile Bottom Navigation Bar (Visible on mobile/tablet) */}
      <BottomNav
        language={language}
        activeTab={activeTab}
        onTabChange={(tab) => {
          sounds.playClick();
          setActiveTab(tab);
        }}
        onOpenToolDrawer={() => setIsDrawerOpen(true)}
      />

      {/* 6. All Tools Drawer Modal */}
      <ToolsDrawerModal
        isOpen={isDrawerOpen}
        onClose={() => setIsDrawerOpen(false)}
        language={language}
        activeTab={activeTab}
        onSelectTab={(tab) => setActiveTab(tab)}
      />

      {/* 7. Settings Modal */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        language={language}
        onLanguageChange={(l) => setLanguage(l)}
        onResetApp={handleResetApp}
      />

      {/* 8. Global Draggable On-Screen Game FPS HUD */}
      <FpsOverlayHud
        metrics={fpsMetrics}
        visible={isHudOpen}
        onClose={handleToggleHud}
        language={language}
      />
    </div>
  );
}
