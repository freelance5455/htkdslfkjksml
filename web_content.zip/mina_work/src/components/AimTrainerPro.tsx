import React, { useState, useEffect, useRef } from 'react';
import { translations } from '../utils/translations';
import { Language, CrosshairConfig } from '../types';
import { sounds } from '../utils/audio';
import confetti from 'canvas-confetti';
import {
  Target,
  Zap,
  Play,
  RotateCcw,
  Crosshair as CrosshairIcon,
  Flame,
  Award,
  ShieldCheck,
  ChevronUp,
} from 'lucide-react';

interface AimTrainerProProps {
  language: Language;
  soundEnabled: boolean;
  crosshair: CrosshairConfig;
}

export const AimTrainerPro: React.FC<AimTrainerProProps> = ({
  language,
  soundEnabled,
  crosshair,
}) => {
  const t = translations[language];

  // Training Modes
  const [mode, setMode] = useState<'moving' | 'drag' | 'reaction' | 'tracking'>('moving');
  const [difficulty, setDifficulty] = useState<'easy' | 'pro' | 'esports'>('pro');

  // Stats
  const [hits, setHits] = useState(0);
  const [misses, setMisses] = useState(0);
  const [score, setScore] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [timeLeft, setTimeLeft] = useState(30);

  // Mode 1: Moving Target state
  const [targetPos, setTargetPos] = useState({ x: 50, y: 50, size: 40 });
  const [targetType, setTargetType] = useState<'head' | 'body'>('head');

  // Mode 2: Drag Headshot state
  const [dragState, setDragState] = useState<'idle' | 'dragging' | 'result'>('idle');
  const [dragStartY, setDragStartY] = useState<number | null>(null);
  const [dragStartTime, setDragStartTime] = useState<number>(0);
  const [dragFeedback, setDragFeedback] = useState<string>('');
  const [isHeadshot, setIsHeadshot] = useState<boolean>(false);

  // Mode 3: Reaction Time test state
  const [reactionState, setReactionState] = useState<'idle' | 'waiting' | 'ready' | 'result'>('idle');
  const [reactionStartTime, setReactionStartTime] = useState(0);
  const [reactionResultMs, setReactionResultMs] = useState<number | null>(null);

  // Timer countdown
  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (isPlaying && timeLeft > 0) {
      timer = setInterval(() => {
        setTimeLeft((prev) => {
          if (prev <= 1) {
            setIsPlaying(false);
            sounds.playCleanSuccess();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [isPlaying, timeLeft]);

  // Moving Target Position Randomizer
  const randomizeTarget = () => {
    const margin = 15;
    const x = Math.floor(Math.random() * (100 - margin * 2)) + margin;
    const y = Math.floor(Math.random() * (100 - margin * 2)) + margin;
    const isHead = Math.random() > 0.4;
    const size = isHead ? (difficulty === 'esports' ? 26 : difficulty === 'pro' ? 34 : 44) : 55;
    setTargetPos({ x, y, size });
    setTargetType(isHead ? 'head' : 'body');
  };

  // Start Training Session
  const startSession = () => {
    sounds.playClick();
    setHits(0);
    setMisses(0);
    setScore(0);
    setTimeLeft(30);
    setIsPlaying(true);
    randomizeTarget();
  };

  // Reset Session
  const resetSession = () => {
    sounds.playClick();
    setIsPlaying(false);
    setHits(0);
    setMisses(0);
    setScore(0);
    setTimeLeft(30);
    setDragState('idle');
    setReactionState('idle');
  };

  // Click Target in Moving Target Mode
  const handleTargetClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!isPlaying) return;

    if (targetType === 'head') {
      sounds.playHeadshot();
      setHits((h) => h + 1);
      setScore((s) => s + (difficulty === 'esports' ? 300 : difficulty === 'pro' ? 200 : 100));
    } else {
      sounds.playBodyHit();
      setHits((h) => h + 1);
      setScore((s) => s + 50);
    }
    randomizeTarget();
  };

  // Miss click in training area
  const handleAreaMiss = () => {
    if (!isPlaying) return;
    sounds.playBodyHit();
    setMisses((m) => m + 1);
  };

  // Drag Headshot Flick Handlers
  const handleDragTouchStart = (e: React.TouchEvent | React.MouseEvent) => {
    const clientY = 'touches' in e ? e.touches[0].clientY : e.clientY;
    setDragStartY(clientY);
    setDragStartTime(performance.now());
    setDragState('dragging');
  };

  const handleDragTouchEnd = (e: React.TouchEvent | React.MouseEvent) => {
    if (dragState !== 'dragging' || dragStartY === null) return;
    const clientY = 'changedTouches' in e ? e.changedTouches[0].clientY : e.clientY;
    const deltaY = dragStartY - clientY; // upward drag is positive delta
    const elapsedMs = performance.now() - dragStartTime;

    const dragSpeed = deltaY / Math.max(1, elapsedMs); // pixels per ms

    if (deltaY > 60 && dragSpeed > 0.45) {
      // Perfect Drag Headshot!
      sounds.playHeadshot();
      setIsHeadshot(true);
      setDragFeedback(language === 'si' ? 'නියමයි! PERFECT DRAG HEADSHOT' : 'PERFECT DRAG HEADSHOT!');
      setHits((h) => h + 1);
      setScore((s) => s + 250);
      try {
        confetti({ particleCount: 30, spread: 45, origin: { y: 0.6 } });
      } catch {}
    } else if (deltaY > 20) {
      // Body Hit - Drag was too weak/slow
      sounds.playBodyHit();
      setIsHeadshot(false);
      setDragFeedback(language === 'si' ? 'Body Hit - තව වේගයෙන් උඩට Drag කරන්න' : 'Body Hit - Drag faster upwards!');
      setHits((h) => h + 1);
      setScore((s) => s + 60);
    } else {
      sounds.playBodyHit();
      setIsHeadshot(false);
      setDragFeedback(language === 'si' ? 'Missed - Drag එක මදි' : 'Missed - Drag distance insufficient');
      setMisses((m) => m + 1);
    }

    setDragState('result');
    setDragStartY(null);
  };

  // Reaction Time Test Logic
  const startReactionTest = () => {
    sounds.playClick();
    setReactionState('waiting');
    setReactionResultMs(null);

    const randomDelay = Math.floor(Math.random() * 2500) + 1500;
    setTimeout(() => {
      setReactionState('ready');
      setReactionStartTime(performance.now());
    }, randomDelay);
  };

  const handleReactionClick = () => {
    if (reactionState === 'waiting') {
      sounds.playBodyHit();
      setReactionState('idle');
      alert(t.reactionTooEarly);
    } else if (reactionState === 'ready') {
      const reactionTime = Math.round(performance.now() - reactionStartTime);
      sounds.playHeadshot();
      setReactionResultMs(reactionTime);
      setReactionState('result');
      if (reactionTime < 220) {
        try {
          confetti({ particleCount: 40, spread: 50 });
        } catch {}
      }
    }
  };

  // Calculate Accuracy
  const totalShots = hits + misses;
  const accuracy = totalShots > 0 ? Math.round((hits / totalShots) * 100) : 100;

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-white font-gaming flex items-center gap-2">
            <Target className="w-6 h-6 text-red-500" />
            <span>{t.aimTrainerTitle}</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            {language === 'si'
              ? 'Free Fire Drag Headshot & Moving Target ප්‍රායෝගික පුහුණු සිමියුලේටරය'
              : 'Interactive Drag Headshot flick & moving target reflex training simulator'}
          </p>
        </div>

        {/* Mode Selector */}
        <div className="flex flex-wrap gap-1.5 p-1 rounded-2xl bg-slate-900 border border-slate-800">
          <button
            onClick={() => {
              sounds.playClick();
              setMode('moving');
              resetSession();
            }}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
              mode === 'moving' ? 'bg-red-600 text-white font-bold shadow-md' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            {t.movingTargetMode}
          </button>
          <button
            onClick={() => {
              sounds.playClick();
              setMode('drag');
              resetSession();
            }}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
              mode === 'drag' ? 'bg-cyan-500 text-slate-950 font-bold shadow-md' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            {t.dragHeadshotMode}
          </button>
          <button
            onClick={() => {
              sounds.playClick();
              setMode('reaction');
              resetSession();
            }}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
              mode === 'reaction' ? 'bg-amber-500 text-slate-950 font-bold shadow-md' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            {t.reactionTestMode}
          </button>
        </div>
      </div>

      {/* Stats Bar */}
      <div className="grid grid-cols-4 gap-2.5">
        <div className="p-3 rounded-2xl bg-slate-900 border border-slate-800 text-center">
          <div className="text-[10px] text-slate-400 font-mono uppercase">{t.accuracy}</div>
          <div className="text-lg font-black font-gaming text-cyan-400 tabular-nums mt-0.5">
            {accuracy}%
          </div>
        </div>
        <div className="p-3 rounded-2xl bg-slate-900 border border-slate-800 text-center">
          <div className="text-[10px] text-slate-400 font-mono uppercase">{t.totalHits}</div>
          <div className="text-lg font-black font-gaming text-emerald-400 tabular-nums mt-0.5">
            {hits}
          </div>
        </div>
        <div className="p-3 rounded-2xl bg-slate-900 border border-slate-800 text-center">
          <div className="text-[10px] text-slate-400 font-mono uppercase">{t.missedShots}</div>
          <div className="text-lg font-black font-gaming text-red-400 tabular-nums mt-0.5">
            {misses}
          </div>
        </div>
        <div className="p-3 rounded-2xl bg-slate-900 border border-slate-800 text-center">
          <div className="text-[10px] text-slate-400 font-mono uppercase">{t.score}</div>
          <div className="text-lg font-black font-gaming text-amber-400 tabular-nums mt-0.5">
            {score}
          </div>
        </div>
      </div>

      {/* Difficulty and Session Controls */}
      <div className="flex flex-wrap items-center justify-between gap-3 p-3.5 rounded-2xl bg-slate-900 border border-slate-800">
        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-400 font-mono">{t.difficulty}:</span>
          <div className="flex gap-1">
            {(['easy', 'pro', 'esports'] as const).map((diff) => (
              <button
                key={diff}
                onClick={() => {
                  sounds.playClick();
                  setDifficulty(diff);
                }}
                className={`px-2.5 py-1 rounded-lg text-xs font-semibold capitalize transition-all cursor-pointer ${
                  difficulty === diff
                    ? 'bg-slate-800 text-cyan-300 border border-cyan-500/40'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {diff === 'easy' ? t.easy : diff === 'pro' ? t.pro : t.esports}
              </button>
            ))}
          </div>
        </div>

        <div className="flex items-center gap-2">
          {mode === 'moving' && (
            <div className="text-xs font-mono px-3 py-1 rounded-lg bg-slate-950 border border-slate-800 text-slate-300">
              <span className="text-slate-500">TIME:</span> <strong className="tabular-nums text-white">{timeLeft}s</strong>
            </div>
          )}

          {mode === 'moving' && !isPlaying ? (
            <button
              onClick={startSession}
              className="px-4 py-1.5 rounded-xl bg-gradient-to-r from-red-600 to-orange-600 text-white font-gaming font-bold text-xs flex items-center gap-1.5 shadow-md shadow-red-950/50 cursor-pointer hover:brightness-110"
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              <span>{t.startTraining}</span>
            </button>
          ) : mode === 'moving' && isPlaying ? (
            <button
              onClick={resetSession}
              className="px-4 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs flex items-center gap-1.5 cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>{language === 'si' ? 'නවත්වන්න' : 'Stop'}</span>
            </button>
          ) : null}
        </div>
      </div>

      {/* TRAINING SIMULATOR CANVAS VIEWPORT */}
      {mode === 'moving' && (
        <div
          onClick={handleAreaMiss}
          className="relative w-full h-80 sm:h-96 rounded-3xl bg-slate-950 border border-cyan-500/30 overflow-hidden cursor-crosshair select-none shadow-2xl gaming-grid-bg"
        >
          {/* Active target */}
          {isPlaying ? (
            <div
              onClick={handleTargetClick}
              style={{
                left: `${targetPos.x}%`,
                top: `${targetPos.y}%`,
                width: `${targetPos.size}px`,
                height: `${targetPos.size}px`,
                transform: 'translate(-50%, -50%)',
              }}
              className={`absolute rounded-full cursor-pointer transition-all duration-100 flex items-center justify-center shadow-lg active:scale-95 ${
                targetType === 'head'
                  ? 'bg-gradient-to-r from-red-600 to-red-500 border-2 border-white shadow-red-500/50'
                  : 'bg-gradient-to-r from-orange-500 to-amber-500 border-2 border-slate-900 shadow-orange-500/40'
              }`}
            >
              {targetType === 'head' ? (
                <div className="w-2.5 h-2.5 rounded-full bg-white animate-ping" />
              ) : (
                <CrosshairIcon className="w-4 h-4 text-slate-950" />
              )}
            </div>
          ) : (
            <div className="absolute inset-0 flex flex-col items-center justify-center p-6 text-center bg-black/40 backdrop-blur-xs">
              <Target className="w-12 h-12 text-red-500 mb-3 animate-pulse" />
              <h3 className="font-gaming font-bold text-lg text-white mb-1">
                {language === 'si' ? 'Moving Target පුහුණුව අරඹන්න' : 'Start Moving Target Session'}
              </h3>
              <p className="text-xs text-slate-400 max-w-sm mb-4">
                {language === 'si'
                  ? 'රතු පාට Head Target මත ක්ලික් කර Headshot නිරවද්‍යතාව වැඩි දියුණු කරගන්න'
                  : 'Tap moving targets rapidly to build muscle memory and crosshair discipline'}
              </p>
              <button
                onClick={startSession}
                className="py-3 px-6 rounded-2xl bg-gradient-to-r from-red-600 to-orange-500 text-white font-gaming font-bold text-sm shadow-xl shadow-red-950/50 hover:brightness-110 active:scale-95 cursor-pointer"
              >
                {t.startTraining}
              </button>
            </div>
          )}

          {/* Subtitle bottom info */}
          <div className="absolute bottom-3 left-4 right-4 flex items-center justify-between text-[11px] text-slate-500 font-mono pointer-events-none">
            <span>Red = Headshot (+200 pts) · Orange = Body (+50 pts)</span>
            <span>Target Size: {targetPos.size}px</span>
          </div>
        </div>
      )}

      {/* MODE 2: DRAG HEADSHOT SIMULATOR */}
      {mode === 'drag' && (
        <div className="relative w-full h-96 rounded-3xl bg-slate-950 border border-cyan-500/30 overflow-hidden select-none p-5 flex flex-col justify-between shadow-2xl gaming-grid-bg">
          {/* Target Enemy Character Zone */}
          <div className="flex flex-col items-center">
            <div
              className={`w-16 h-16 rounded-full border-2 flex items-center justify-center transition-all ${
                isHeadshot
                  ? 'bg-red-600/30 border-red-500 shadow-xl shadow-red-500/40 scale-110'
                  : 'bg-slate-900 border-slate-700'
              }`}
            >
              <span className="font-gaming text-xs font-bold text-red-400">HEAD</span>
            </div>
            <div className="w-20 h-24 rounded-2xl bg-slate-900/80 border border-slate-800 -mt-2 flex items-center justify-center">
              <span className="text-[10px] text-slate-500 font-mono">BODY</span>
            </div>

            {/* Drag feedback */}
            {dragFeedback && (
              <div
                className={`mt-3 px-4 py-1.5 rounded-full font-gaming font-bold text-xs tracking-wider animate-bounce ${
                  isHeadshot
                    ? 'bg-red-950 border border-red-500 text-red-400 shadow-lg shadow-red-500/20'
                    : 'bg-slate-900 border border-slate-700 text-slate-300'
                }`}
              >
                {dragFeedback}
              </div>
            )}
          </div>

          {/* Instructions */}
          <div className="text-center text-xs text-slate-400">
            <div className="flex items-center justify-center gap-1.5 text-cyan-400 font-semibold mb-1">
              <ChevronUp className="w-4 h-4 animate-bounce" />
              <span>{t.dragInstructions}</span>
            </div>
            <p className="text-[11px] text-slate-500">
              {language === 'si'
                ? 'පහළ Fire Button එක ස්පර්ශ කර වේගයෙන් උඩට Drag කරන්න (Quick upward flick).'
                : 'Touch and flick the fire button upward with high acceleration.'}
            </p>
          </div>

          {/* Interactive Virtual Fire Button */}
          <div className="flex justify-center pb-2">
            <div
              onTouchStart={handleDragTouchStart}
              onTouchEnd={handleDragTouchEnd}
              onMouseDown={handleDragTouchStart}
              onMouseUp={handleDragTouchEnd}
              className={`w-20 h-20 sm:w-24 sm:h-24 rounded-full border-4 flex flex-col items-center justify-center transition-all cursor-pointer select-none active:scale-95 ${
                dragState === 'dragging'
                  ? 'bg-orange-500 border-white text-slate-950 scale-105 shadow-2xl shadow-orange-500/50'
                  : 'bg-gradient-to-tr from-orange-600 to-amber-500 border-amber-300/80 text-white shadow-xl shadow-orange-600/30'
              }`}
            >
              <Flame className="w-6 h-6 fill-current" />
              <span className="text-[9px] font-black font-gaming tracking-wider uppercase mt-0.5">
                DRAG FIRE
              </span>
            </div>
          </div>
        </div>
      )}

      {/* MODE 3: REACTION TIME TEST */}
      {mode === 'reaction' && (
        <div
          onClick={handleReactionClick}
          className={`relative w-full h-80 sm:h-96 rounded-3xl border transition-all duration-200 overflow-hidden flex flex-col items-center justify-center p-6 text-center select-none cursor-pointer shadow-2xl ${
            reactionState === 'waiting'
              ? 'bg-red-950/90 border-red-500 text-red-200'
              : reactionState === 'ready'
              ? 'bg-emerald-600 border-emerald-300 text-slate-950'
              : 'bg-slate-900 border-slate-800 text-white'
          }`}
        >
          {reactionState === 'idle' && (
            <div>
              <Zap className="w-12 h-12 text-amber-400 mx-auto mb-3" />
              <h3 className="font-gaming font-black text-xl mb-2">
                {language === 'si' ? 'Reaction Time පරික්ෂාව' : 'Reaction Time Reflex Test'}
              </h3>
              <p className="text-xs text-slate-400 max-w-sm mb-5">
                {t.reactionReady}
              </p>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  startReactionTest();
                }}
                className="py-3 px-6 rounded-2xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-gaming font-bold text-sm shadow-xl shadow-amber-950/40 cursor-pointer"
              >
                {language === 'si' ? 'ආරම්භ කරන්න' : 'Start Test'}
              </button>
            </div>
          )}

          {reactionState === 'waiting' && (
            <div>
              <h2 className="text-2xl sm:text-3xl font-black font-gaming text-red-400 uppercase tracking-widest animate-pulse">
                {language === 'si' ? 'රැඳී සිටින්න...' : 'WAIT FOR GREEN...'}
              </h2>
              <p className="text-xs text-red-300/80 mt-2">
                {language === 'si' ? 'කොළ පාට වන තුරු තිරය ස්පර්ශ නොකරන්න' : 'Do not click yet'}
              </p>
            </div>
          )}

          {reactionState === 'ready' && (
            <div>
              <h2 className="text-4xl sm:text-5xl font-black font-gaming text-slate-950 uppercase tracking-widest animate-bounce">
                {language === 'si' ? 'දැන් TAP කරන්න!' : 'TAP NOW!'}
              </h2>
            </div>
          )}

          {reactionState === 'result' && (
            <div>
              <Award className="w-12 h-12 text-cyan-400 mx-auto mb-2" />
              <div className="text-xs text-slate-400 font-mono uppercase">{t.yourReactionTime}</div>
              <div className="text-5xl sm:text-6xl font-black font-gaming text-white tabular-nums my-2">
                {reactionResultMs} <span className="text-xl text-slate-400 font-sans">ms</span>
              </div>
              <div className="text-xs text-emerald-400 font-semibold mb-5">
                {reactionResultMs && reactionResultMs < 200
                  ? 'eSports Godlike Reflexes!'
                  : reactionResultMs && reactionResultMs < 260
                  ? 'Pro Competitive Reflexes!'
                  : 'Average Reflexes - Keep Practicing'}
              </div>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  startReactionTest();
                }}
                className="py-2.5 px-6 rounded-xl bg-cyan-500 text-slate-950 font-gaming font-bold text-xs shadow-lg shadow-cyan-950/50 cursor-pointer"
              >
                {language === 'si' ? 'නැවත පරීක්ෂා කරන්න' : 'Test Again'}
              </button>
            </div>
          )}
        </div>
      )}

      {/* Fair Play Notice */}
      <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 flex items-start gap-3 text-xs text-slate-400">
        <ShieldCheck className="w-4 h-4 text-cyan-400 mt-0.5 shrink-0" />
        <span>{t.aimTrainerNotice}</span>
      </div>
    </div>
  );
};
