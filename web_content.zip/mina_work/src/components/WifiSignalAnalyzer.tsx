import React, { useState } from 'react';
import { translations } from '../utils/translations';
import { Language, DeviceInfo } from '../types';
import { sounds } from '../utils/audio';
import { runDownloadSpeedTest } from '../utils/systemDiagnostics';
import {
  Wifi,
  Activity,
  ArrowDown,
  Play,
  RotateCw,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
} from 'lucide-react';

interface WifiSignalAnalyzerProps {
  language: Language;
  deviceInfo: DeviceInfo | null;
  livePing: number | null;
}

export const WifiSignalAnalyzer: React.FC<WifiSignalAnalyzerProps> = ({
  language,
  deviceInfo,
  livePing,
}) => {
  const t = translations[language];

  const [testing, setTesting] = useState(false);
  const [progress, setProgress] = useState(0);
  const [speedResultMbps, setSpeedResultMbps] = useState<number | null>(null);

  const handleStartSpeedTest = async () => {
    sounds.playClick();
    setTesting(true);
    setProgress(10);
    setSpeedResultMbps(null);

    const speed = await runDownloadSpeedTest((p) => setProgress(p));
    setSpeedResultMbps(speed);
    setTesting(false);
    sounds.playCleanSuccess();
  };

  const isOnline = deviceInfo ? deviceInfo.isOnline : true;

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div>
        <h1 className="text-xl sm:text-2xl font-black text-white font-gaming flex items-center gap-2">
          <Wifi className="w-6 h-6 text-cyan-400" />
          <span>{t.wifiTitle}</span>
        </h1>
        <p className="text-xs text-slate-400 mt-1">
          {language === 'si'
            ? 'ජාල සම්බන්ධතාව, වේගය සහ Free Fire Gaming Ping ස්ථායිතාව පරීක්ෂා කිරීම'
            : 'Bandwidth throughput, roundtrip latency, and signal stability analyzer'}
        </p>
      </div>

      {/* Network Overview Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800">
          <div className="text-[10px] text-slate-400 font-mono uppercase">{t.connectionType}</div>
          <div className="text-lg font-black font-gaming text-cyan-400 mt-0.5">
            {deviceInfo?.networkType || 'Wi-Fi / 4G LTE'}
          </div>
          <div className="text-[11px] text-slate-500 font-mono mt-1">
            Status: {isOnline ? 'Connected' : 'Offline'}
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800">
          <div className="text-[10px] text-slate-400 font-mono uppercase">Downlink Bandwidth</div>
          <div className="text-lg font-black font-gaming text-emerald-400 mt-0.5">
            {deviceInfo?.downlinkMbps} Mbps
          </div>
          <div className="text-[11px] text-slate-500 font-mono mt-1">
            Browser Network API
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800">
          <div className="text-[10px] text-slate-400 font-mono uppercase">Roundtrip Latency</div>
          <div className="text-lg font-black font-gaming text-white mt-0.5 tabular-nums">
            {livePing !== null ? `${livePing} ms` : 'Testing...'}
          </div>
          <div className="text-[11px] text-slate-500 font-mono mt-1">
            Real Server Ping
          </div>
        </div>
      </div>

      {/* Speed Test Card */}
      <div className="bg-slate-900 border border-cyan-500/30 rounded-3xl p-6 sm:p-8 text-center relative overflow-hidden shadow-2xl">
        <div className="relative mx-auto w-40 h-40 sm:w-48 sm:h-48 flex items-center justify-center mb-6">
          <div className="w-full h-full rounded-full border-4 border-slate-800 border-t-cyan-400 flex flex-col items-center justify-center shadow-lg">
            <ArrowDown className={`w-8 h-8 text-cyan-400 mb-1 ${testing ? 'animate-bounce' : ''}`} />
            <div className="text-3xl sm:text-4xl font-black font-gaming text-white tabular-nums">
              {testing ? `${progress}%` : speedResultMbps !== null ? speedResultMbps : '--'}
            </div>
            <div className="text-[11px] text-slate-400 font-mono uppercase mt-0.5">
              {testing ? 'Testing...' : 'Mbps'}
            </div>
          </div>
        </div>

        <button
          onClick={handleStartSpeedTest}
          disabled={testing}
          className={`py-3.5 px-8 rounded-2xl font-gaming font-bold text-sm sm:text-base flex items-center justify-center gap-2 mx-auto shadow-xl transition-all cursor-pointer ${
            testing
              ? 'bg-slate-800 text-cyan-400 border border-cyan-500/40 animate-pulse'
              : 'bg-gradient-to-r from-cyan-400 via-blue-500 to-cyan-500 text-slate-950 shadow-cyan-500/30 hover:brightness-110 active:scale-95'
          }`}
        >
          {testing ? <RotateCw className="w-4 h-4 animate-spin" /> : <Play className="w-4 h-4 fill-current" />}
          <span>{testing ? t.testingSpeed : t.testSpeedNow}</span>
        </button>

        {speedResultMbps !== null && (
          <div className="mt-5 p-3 rounded-xl bg-slate-950 border border-slate-800 inline-flex items-center gap-2 text-xs text-emerald-400">
            <CheckCircle2 className="w-4 h-4" />
            <span>
              {speedResultMbps > 10
                ? 'High-Speed Connection: Excellent for 60-120 FPS Free Fire matches!'
                : 'Moderate Speed: Sufficient for online gaming, keep background streaming closed.'}
            </span>
          </div>
        )}
      </div>

      {/* Network Troubleshooting Tips */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 shadow-lg">
        <h2 className="font-gaming font-bold text-sm text-slate-200 mb-3 flex items-center gap-2">
          <Activity className="w-4 h-4 text-cyan-400" />
          <span>{language === 'si' ? 'Free Fire සඳහා Network Troubleshooting' : 'Network Troubleshooting Tips'}</span>
        </h2>

        <ul className="space-y-2 text-xs text-slate-300">
          <li className="flex items-start gap-2">
            <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400 mt-0.5 shrink-0" />
            <span>
              {language === 'si'
                ? 'Wi-Fi භාවිත කරන්නේ නම් 5GHz Band එකට සම්බන්ධ වන්න. 2.4GHz Band එකෙහි Bluetooth සහ අසල්වැසි රවුටර් නිසා Packet Loss වැඩි වේ.'
                : 'Connect to 5GHz Wi-Fi bands whenever available to avoid 2.4GHz interference from Bluetooth.'}
            </span>
          </li>
          <li className="flex items-start gap-2">
            <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400 mt-0.5 shrink-0" />
            <span>
              {language === 'si'
                ? 'Cloudflare 1.1.1.1 හෝ Google 8.8.8.8 Private DNS එක Phone Settings තුළින් Enable කිරීමෙන් DNS Lookup වේගවත් වේ.'
                : 'Setting 1.1.1.1 (one.one.one.one) or dns.google in Android Private DNS speeds up server address resolution.'}
            </span>
          </li>
        </ul>
      </div>

      {/* Sensor Notice */}
      <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 flex items-start gap-3 text-xs text-slate-400">
        <ShieldCheck className="w-4 h-4 text-cyan-400 mt-0.5 shrink-0" />
        <span>
          {language === 'si'
            ? 'සටහන: Wi-Fi RSSI (dBm Signal Strength) සඳහා Android 10+ හි Location & Coarse Sensor Permission අවශ්‍ය වන බැවින් මෙහි Network Downlink Bandwidth මඟින් සැබෑ වේගය සනාථ කෙරේ.'
            : 'Authentic Telemetry: Raw dBm signal strength is sandboxed on Android 10+ without precise location toggles; actual throughput is verified via real payload transfer.'}
        </span>
      </div>
    </div>
  );
};
