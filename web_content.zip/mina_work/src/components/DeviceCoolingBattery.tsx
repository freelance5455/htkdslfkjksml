import React from 'react';
import { translations } from '../utils/translations';
import { Language, DeviceInfo } from '../types';
import {
  ThermometerSnowflake,
  Battery,
  BatteryCharging,
  AlertTriangle,
  CheckCircle2,
  ShieldCheck,
  Flame,
  Wind,
  Info,
} from 'lucide-react';

interface DeviceCoolingBatteryProps {
  language: Language;
  deviceInfo: DeviceInfo | null;
}

export const DeviceCoolingBattery: React.FC<DeviceCoolingBatteryProps> = ({
  language,
  deviceInfo,
}) => {
  const t = translations[language];

  const hasBattery = deviceInfo && deviceInfo.batteryLevel !== null;
  const batteryPct = hasBattery ? deviceInfo.batteryLevel : null;
  const isCharging = deviceInfo ? deviceInfo.isCharging : false;

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div>
        <h1 className="text-xl sm:text-2xl font-black text-white font-gaming flex items-center gap-2">
          <ThermometerSnowflake className="w-6 h-6 text-cyan-400" />
          <span>{t.coolingTitle}</span>
        </h1>
        <p className="text-xs text-slate-400 mt-1">
          {language === 'si'
            ? 'Battery තත්ත්වය, Charging වේගය සහ ක්‍රීඩා තාප පාලනය (සැබෑ දත්ත පමණි)'
            : 'Battery health, charging telemetry, and thermal preservation tips'}
        </p>
      </div>

      {/* Main Battery & Thermal Status Card */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Battery Telemetry */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <span className="text-xs font-gaming font-bold text-slate-300">
                {t.batteryHealth}
              </span>
              <span className={`text-xs font-mono font-bold ${hasBattery ? 'text-emerald-400' : 'text-amber-400'}`}>
                {hasBattery ? 'Live Hardware Sensor' : 'API Protected by OS'}
              </span>
            </div>

            {hasBattery ? (
              <>
                <div className="flex items-center gap-4 mb-5">
                  <div className="w-16 h-16 rounded-2xl bg-amber-950/60 border border-amber-500/40 flex items-center justify-center text-amber-400">
                    {isCharging ? <BatteryCharging className="w-9 h-9 animate-pulse" /> : <Battery className="w-9 h-9" />}
                  </div>
                  <div>
                    <div className="text-4xl font-black font-gaming text-white tabular-nums">
                      {batteryPct}%
                    </div>
                    <div className="text-xs text-amber-300 font-mono mt-0.5">
                      {isCharging ? t.charging : t.discharging}
                    </div>
                  </div>
                </div>

                {/* Progress Bar */}
                <div className="w-full bg-slate-950 h-2.5 rounded-full overflow-hidden mb-4 border border-slate-800">
                  <div
                    className="bg-gradient-to-r from-amber-500 to-emerald-500 h-full rounded-full transition-all duration-500"
                    style={{ width: `${batteryPct}%` }}
                  />
                </div>
              </>
            ) : (
              <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 mb-4 text-xs text-slate-400">
                <div className="font-semibold text-amber-400 mb-1 flex items-center gap-1.5">
                  <Info className="w-4 h-4" />
                  <span>
                    {language === 'si' ? 'Battery API අවසර නොමැත' : 'Battery API Not Exposed'}
                  </span>
                </div>
                <span>
                  {language === 'si'
                    ? 'ඔබගේ Browser / OS ආරක්ෂණ ප්‍රතිපත්තිය මඟින් Battery API තොරතුරු ලබාදීම අවහිර කර ඇත. කිසිදු ව්‍යාජ අගයක් පෙන්වනු නොලැබේ.'
                    : 'Your browser sandbox restricts battery telemetry to protect fingerprinting privacy. No fabricated values are shown.'}
                </span>
              </div>
            )}
          </div>

          <div className="text-[11px] text-slate-400 font-mono space-y-1">
            <div className="flex justify-between">
              <span>Power Source:</span>
              <span className="text-slate-200">
                {hasBattery ? (isCharging ? 'AC Adapter / USB Fast Charge' : 'Internal Battery') : 'Sensor Protected'}
              </span>
            </div>
            <div className="flex justify-between">
              <span>Telemetry Mode:</span>
              <span className="text-emerald-400">Verified Authentic Only</span>
            </div>
          </div>
        </div>

        {/* Thermal State Card */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <span className="text-xs font-gaming font-bold text-slate-300">
                {t.thermalStatus}
              </span>
              <span className="text-xs font-mono text-cyan-400">
                Hardware Thermistor
              </span>
            </div>

            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 mb-4 text-xs text-slate-300 leading-relaxed">
              <div className="font-semibold text-cyan-300 mb-1 flex items-center gap-1.5">
                <ThermometerSnowflake className="w-4 h-4 text-cyan-400" />
                <span>
                  {language === 'si' ? 'තාප තොරතුරු සත්‍යතාව' : 'Thermal Sensor Disclosure'}
                </span>
              </div>
              <p>
                {language === 'si'
                  ? 'Android OS මඟින් SoC CPU/Battery Thermistor දත්ත සෘජුවම ලබාගැනීම Root හෝ OEM Hardware Drivers වලට පමණක් සීමා කර ඇත. එබැවින් ව්‍යාජ උෂ්ණත්ව අගයන් (Fake Celsius) පෙන්වීම ප්‍රතික්ෂේප කර ඇත.'
                  : 'Android system security restricts raw SoC thermistor readings to root and OEM drivers. We strictly refuse to show fake Celsius numbers.'}
              </p>
            </div>
          </div>

          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-[11px] text-slate-400">
            {language === 'si'
              ? 'අවවාදය: Phone එක Charge වන අතරතුර Free Fire ක්‍රීඩා කිරීමෙන් වළකින්න. එය සැබවින්ම බැටරිය රත් කරයි.'
              : 'Best Practice: Do not game while charging to prevent real thermal degradation.'}
          </div>
        </div>
      </div>

      {/* Gaming Cooling Tips */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 shadow-lg">
        <h2 className="font-gaming font-bold text-sm text-slate-200 mb-4 flex items-center gap-2">
          <Wind className="w-4 h-4 text-cyan-400" />
          <span>{t.coolingTipsTitle}</span>
        </h2>

        <div className="space-y-2.5">
          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800/80 flex items-start gap-3 text-xs">
            <CheckCircle2 className="w-4 h-4 text-cyan-400 mt-0.5 shrink-0" />
            <span className="text-slate-300">{t.coolingTip1}</span>
          </div>
          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800/80 flex items-start gap-3 text-xs">
            <CheckCircle2 className="w-4 h-4 text-cyan-400 mt-0.5 shrink-0" />
            <span className="text-slate-300">{t.coolingTip2}</span>
          </div>
          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800/80 flex items-start gap-3 text-xs">
            <CheckCircle2 className="w-4 h-4 text-cyan-400 mt-0.5 shrink-0" />
            <span className="text-slate-300">{t.coolingTip3}</span>
          </div>
        </div>
      </div>

      {/* Safety & Battery Health Notice */}
      <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 flex items-start gap-3 text-xs text-slate-400">
        <ShieldCheck className="w-4 h-4 text-cyan-400 mt-0.5 shrink-0" />
        <span>
          {language === 'si'
            ? '100% අවංක දත්ත: ඔබගේ දුරකථනයේ සංවේදක වලින් සත්‍යවශයෙන්ම කියවිය හැකි දත්ත පමණක් මෙහි ඉදිරිපත් කෙරේ.'
            : 'Integrity: We only display legitimate sensor telemetry and explicitly state when APIs are restricted by the OS.'}
        </span>
      </div>
    </div>
  );
};
