import React, { useState, useEffect } from 'react';
import { translations } from '../utils/translations';
import { Language, GamingSession } from '../types';
import { sounds } from '../utils/audio';
import {
  Flame,
  Zap,
  Play,
  Square,
  Clock,
  Battery,
  ShieldAlert,
  Sparkles,
  ExternalLink,
  Sliders,
  Maximize2,
  CheckCircle2,
  AlertTriangle,
} from 'lucide-react';

interface FreeFireOptimizerProps {
  language: Language;
  isGamingMode: boolean;
  onToggleGamingMode: () => void;
  onNavigate: (tab: string) => void;
  onAddSession: (session: GamingSession) => void;
  currentBatteryLevel: number | null;
  livePing: number | null;
}

export const FreeFireOptimizer: React.FC<FreeFireOptimizerProps> = ({
  language,
  isGamingMode,
  onToggleGamingMode,
  onNavigate,
  onAddSession,
  currentBatteryLevel,
  livePing,
}) => {
  const t = translations[language];

  // Gaming Session Timer
  const [sessionActive, setSessionActive] = useState(false);
  const [sessionSeconds, setSessionSeconds] = useState(0);
  const [sessionStartBattery, setSessionStartBattery] = useState<number | null>(null);
  const [selectedGame, setSelectedGame] = useState<'Free Fire' | 'Free Fire MAX'>('Free Fire');

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (sessionActive) {
      interval = setInterval(() => {
        setSessionSeconds((prev) => prev + 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [sessionActive]);

  const handleStartSession = () => {
    sounds.playClick();
    setSessionActive(true);
    setSessionSeconds(0);
    setSessionStartBattery(currentBatteryLevel);
  };

  const handleStopSession = () => {
    sounds.playCleanSuccess();
    setSessionActive(false);

    const durationMin = Math.max(1, Math.round(sessionSeconds / 60));
    const newSession: GamingSession = {
      id: Date.now().toString(),
      startTime: new Date(Date.now() - sessionSeconds * 1000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      endTime: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      durationMinutes: durationMin,
      startBattery: sessionStartBattery,
      endBattery: currentBatteryLevel,
      game: selectedGame,
      avgPing: livePing ?? 0,
    };

    onAddSession(newSession);
  };

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const launchGame = (packageName: string, playStoreUrl: string) => {
    sounds.playClick();
    try {
      window.location.href = `intent://#Intent;package=${packageName};end`;
    } catch {
      window.location.href = playStoreUrl;
    }
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div>
        <h1 className="text-xl sm:text-2xl font-black text-white font-gaming flex items-center gap-2">
          <Flame className="w-6 h-6 text-orange-500 fill-current" />
          <span>{t.ffTitle}</span>
        </h1>
        <p className="text-xs text-slate-400 mt-1">
          {language === 'si'
            ? 'Free Fire සහ Free Fire MAX සඳහා විශේෂිත ක්‍රීඩා සැකසුම් සහ සැසි කළමනාකරණය'
            : 'Pro gaming configurations, session tracker, and battery preservation'}
        </p>
      </div>

      {/* Game Launcher Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {/* Free Fire Standard */}
        <div className="rounded-2xl bg-gradient-to-br from-slate-900 to-slate-950 border border-orange-500/30 p-5 shadow-xl flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-orange-950 text-orange-400 border border-orange-500/30">
                CLASSIC EDITION
              </span>
              <span className="text-xs text-slate-400 font-mono">com.dts.freefireth</span>
            </div>
            <h3 className="font-gaming font-black text-lg text-white mb-1">
              Garena Free Fire
            </h3>
            <p className="text-xs text-slate-400 mb-4">
              {language === 'si'
                ? 'Standard version - Low & Mid range දුරකථන සඳහා සුමට ක්‍රීඩා අත්දැකීමක්'
                : 'Optimized for low-to-mid range devices with smooth 60 FPS performance'}
            </p>
          </div>
          <button
            onClick={() =>
              launchGame(
                'com.dts.freefireth',
                'https://play.google.com/store/apps/details?id=com.dts.freefireth'
              )
            }
            className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-orange-500 to-red-600 text-white font-gaming font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg shadow-orange-500/20 hover:brightness-110 active:scale-[0.98] transition-all cursor-pointer"
          >
            <Play className="w-4 h-4 fill-current" />
            <span>{t.launchFF}</span>
            <ExternalLink className="w-3.5 h-3.5 ml-auto opacity-70" />
          </button>
        </div>

        {/* Free Fire MAX */}
        <div className="rounded-2xl bg-gradient-to-br from-slate-900 to-slate-950 border border-cyan-500/30 p-5 shadow-xl flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-cyan-950 text-cyan-400 border border-cyan-500/30">
                ULTRA HD EDITION
              </span>
              <span className="text-xs text-slate-400 font-mono">com.dts.freefiremax</span>
            </div>
            <h3 className="font-gaming font-black text-lg text-white mb-1">
              Free Fire MAX
            </h3>
            <p className="text-xs text-slate-400 mb-4">
              {language === 'si'
                ? 'Ultra HD graphics සහ 360 Lobby සහිත ඉහළ ග්‍රැෆික්ස් සංස්කරණය'
                : 'High fidelity textures, realistic bullet physics, and dynamic shadows'}
            </p>
          </div>
          <button
            onClick={() =>
              launchGame(
                'com.dts.freefiremax',
                'https://play.google.com/store/apps/details?id=com.dts.freefiremax'
              )
            }
            className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-cyan-400 to-blue-600 text-slate-950 font-gaming font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg shadow-cyan-500/20 hover:brightness-110 active:scale-[0.98] transition-all cursor-pointer"
          >
            <Play className="w-4 h-4 fill-current" />
            <span>{t.launchFFMax}</span>
            <ExternalLink className="w-3.5 h-3.5 ml-auto opacity-70" />
          </button>
        </div>
      </div>

      {/* Gaming Session Timer */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-5">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-cyan-950 border border-cyan-500/40 text-cyan-400">
              <Clock className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-gaming font-bold text-base text-white">
                {t.sessionTimer}
              </h2>
              <span className="text-xs text-slate-400">
                {language === 'si'
                  ? 'ක්‍රීඩා කාලය, බැටරි වැයවීම සහ Ping වාර්තා කරන්න'
                  : 'Track gameplay duration, battery drain, and network stability'}
              </span>
            </div>
          </div>

          {/* Game Selector for session */}
          <div className="flex items-center gap-1.5 p-1 rounded-xl bg-slate-950 border border-slate-800">
            <button
              onClick={() => setSelectedGame('Free Fire')}
              className={`px-3 py-1 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                selectedGame === 'Free Fire' ? 'bg-orange-600 text-white' : 'text-slate-400'
              }`}
            >
              FF Standard
            </button>
            <button
              onClick={() => setSelectedGame('Free Fire MAX')}
              className={`px-3 py-1 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                selectedGame === 'Free Fire MAX' ? 'bg-cyan-500 text-slate-950' : 'text-slate-400'
              }`}
            >
              FF MAX
            </button>
          </div>
        </div>

        {/* Live Timer Display */}
        <div className="text-center py-4 bg-slate-950/80 rounded-2xl border border-slate-850 mb-5">
          <div className="text-5xl sm:text-6xl font-black font-gaming text-white tabular-nums tracking-widest">
            {formatTime(sessionSeconds)}
          </div>
          <div className="text-xs text-cyan-400 font-mono mt-1">
            {sessionActive ? t.sessionRunning : (language === 'si' ? 'සැසිය ආරම්භ කිරීමට සූදානම්' : 'Ready to start match')}
          </div>
        </div>

        {/* Start / Stop Session Action */}
        <div className="flex gap-3">
          {!sessionActive ? (
            <button
              onClick={handleStartSession}
              className="flex-1 py-3 px-4 rounded-xl bg-gradient-to-r from-emerald-500 to-cyan-500 text-slate-950 font-gaming font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg shadow-emerald-950/40 hover:brightness-110 active:scale-[0.98] transition-all cursor-pointer"
            >
              <Play className="w-4 h-4 fill-current" />
              <span>{t.startSession}</span>
            </button>
          ) : (
            <button
              onClick={handleStopSession}
              className="flex-1 py-3 px-4 rounded-xl bg-red-600 hover:bg-red-700 text-white font-gaming font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg shadow-red-950/50 active:scale-[0.98] transition-all cursor-pointer"
            >
              <Square className="w-4 h-4 fill-current" />
              <span>{t.stopSession}</span>
            </button>
          )}

          <button
            onClick={onToggleGamingMode}
            className={`px-4 py-3 rounded-xl text-xs font-bold font-gaming flex items-center gap-2 border transition-all cursor-pointer ${
              isGamingMode
                ? 'bg-cyan-950 border-cyan-500 text-cyan-300'
                : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200'
            }`}
          >
            <Zap className={`w-4 h-4 ${isGamingMode ? 'text-cyan-400 fill-current' : ''}`} />
            <span>Wake Lock</span>
          </button>
        </div>
      </div>

      {/* Pro Gaming Performance Tips */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 shadow-lg">
        <h2 className="font-gaming font-bold text-sm text-slate-200 mb-4 flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-cyan-400" />
          <span>{t.ffTips}</span>
        </h2>

        <div className="space-y-3">
          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800/80 flex items-start gap-3 text-xs">
            <CheckCircle2 className="w-4 h-4 text-cyan-400 mt-0.5 shrink-0" />
            <div>
              <span className="font-bold text-slate-200">{t.tip1}</span>
            </div>
          </div>
          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800/80 flex items-start gap-3 text-xs">
            <CheckCircle2 className="w-4 h-4 text-cyan-400 mt-0.5 shrink-0" />
            <div>
              <span className="font-bold text-slate-200">{t.tip2}</span>
            </div>
          </div>
          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800/80 flex items-start gap-3 text-xs">
            <CheckCircle2 className="w-4 h-4 text-cyan-400 mt-0.5 shrink-0" />
            <div>
              <span className="font-bold text-slate-200">{t.tip3}</span>
            </div>
          </div>
          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800/80 flex items-start gap-3 text-xs">
            <AlertTriangle className="w-4 h-4 text-amber-400 mt-0.5 shrink-0" />
            <div>
              <span className="font-bold text-amber-300">{t.tip4}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Shortcuts to Sens and HUD */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <button
          onClick={() => {
            sounds.playClick();
            onNavigate('sens');
          }}
          className="p-4 rounded-2xl bg-slate-900 border border-slate-800 hover:border-cyan-500/50 flex items-center justify-between transition-all cursor-pointer text-left"
        >
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-slate-950 text-cyan-400">
              <Sliders className="w-5 h-5" />
            </div>
            <div>
              <div className="font-gaming font-bold text-sm text-white">{t.tabSens}</div>
              <div className="text-xs text-slate-400">Drag Headshot & Scope presets</div>
            </div>
          </div>
        </button>

        <button
          onClick={() => {
            sounds.playClick();
            onNavigate('hud');
          }}
          className="p-4 rounded-2xl bg-slate-900 border border-slate-800 hover:border-amber-500/50 flex items-center justify-between transition-all cursor-pointer text-left"
        >
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-slate-950 text-amber-400">
              <Maximize2 className="w-5 h-5" />
            </div>
            <div>
              <div className="font-gaming font-bold text-sm text-white">{t.tabHud}</div>
              <div className="text-xs text-slate-400">Fire button size calculator</div>
            </div>
          </div>
        </button>
      </div>

      {/* Safety & Fair-Play Compliance Notice */}
      <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 flex items-start gap-3 text-xs text-slate-400">
        <ShieldAlert className="w-4 h-4 text-cyan-400 mt-0.5 shrink-0" />
        <span>
          {language === 'si'
            ? 'නීතිමය ආරක්ෂණ නිවේදනය: මෙම App එක Free Fire සේවා කොන්දේසි (Terms of Service) වලට සම්පූර්ණයෙන්ම අනුකූල වේ. ක්‍රීඩාවට අනවසර Injection, Mod files හෝ Auto Aim ලබා නොදේ. ඔබගේ Game Account එක 100% ආරක්ෂිතයි.'
            : 'Fair Play Policy: Strictly compliant with Garena Free Fire terms. No unauthorized memory modifications or cheat scripts. 100% Ban-Safe.'}
        </span>
      </div>
    </div>
  );
};
