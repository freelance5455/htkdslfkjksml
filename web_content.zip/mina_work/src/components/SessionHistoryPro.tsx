import React from 'react';
import { translations } from '../utils/translations';
import { Language, GamingSession } from '../types';
import { sounds } from '../utils/audio';
import {
  History,
  Trash2,
  Clock,
  Battery,
  Flame,
  Activity,
  Award,
} from 'lucide-react';

interface SessionHistoryProProps {
  language: Language;
  sessions: GamingSession[];
  onClearSessions: () => void;
}

export const SessionHistoryPro: React.FC<SessionHistoryProProps> = ({
  language,
  sessions,
  onClearSessions,
}) => {
  const t = translations[language];

  const totalMinutes = sessions.reduce((acc, s) => acc + s.durationMinutes, 0);

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-white font-gaming flex items-center gap-2">
            <History className="w-6 h-6 text-cyan-400" />
            <span>{t.sessionTitle}</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            {language === 'si'
              ? 'ක්‍රීඩා කළ කාලය, බැටරි වැයවීම සහ සාමාන්‍ය Ping වාර්තා'
              : 'Logged gameplay matches with battery consumption analysis'}
          </p>
        </div>

        {sessions.length > 0 && (
          <button
            onClick={() => {
              sounds.playClick();
              onClearSessions();
            }}
            className="self-start sm:self-auto px-3.5 py-1.5 rounded-xl bg-slate-900 border border-slate-800 text-xs text-slate-400 hover:text-red-400 flex items-center gap-1.5 transition-all cursor-pointer"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>{t.clearSessions}</span>
          </button>
        )}
      </div>

      {/* Aggregate Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800">
          <div className="text-[10px] text-slate-400 font-mono uppercase">Total Sessions</div>
          <div className="text-2xl font-black font-gaming text-cyan-400 mt-0.5 tabular-nums">
            {sessions.length}
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800">
          <div className="text-[10px] text-slate-400 font-mono uppercase">Total Play Time</div>
          <div className="text-2xl font-black font-gaming text-emerald-400 mt-0.5 tabular-nums">
            {totalMinutes} min
          </div>
        </div>

        <div className="col-span-2 sm:col-span-1 p-4 rounded-2xl bg-slate-900 border border-slate-800">
          <div className="text-[10px] text-slate-400 font-mono uppercase">Favorite Game</div>
          <div className="text-lg font-bold font-gaming text-amber-400 mt-1 truncate">
            {sessions.length > 0 ? sessions[0].game : 'Free Fire'}
          </div>
        </div>
      </div>

      {/* Sessions List */}
      <div className="space-y-3">
        {sessions.length === 0 ? (
          <div className="bg-slate-900/60 border border-slate-800 rounded-3xl p-10 text-center text-slate-500 font-mono text-xs">
            <Clock className="w-8 h-8 mx-auto mb-2 opacity-50" />
            <span>{t.noSessions}</span>
          </div>
        ) : (
          sessions.map((session) => {
            const batteryDrain =
              session.startBattery !== null && session.endBattery !== null
                ? Math.max(0, session.startBattery - session.endBattery)
                : null;

            return (
              <div
                key={session.id}
                className="p-4 sm:p-5 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-lg"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-center text-orange-400 shrink-0">
                    <Flame className="w-5 h-5 fill-current" />
                  </div>
                  <div>
                    <div className="font-gaming font-bold text-sm text-white flex items-center gap-2">
                      <span>{session.game} Match</span>
                      <span className="text-[10px] font-mono px-2 py-0.5 bg-slate-950 rounded text-cyan-400 border border-slate-800">
                        {session.durationMinutes} min
                      </span>
                    </div>
                    <div className="text-xs text-slate-400 font-mono mt-0.5">
                      {session.startTime} - {session.endTime}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-4 text-xs font-mono">
                  {batteryDrain !== null && (
                    <div className="flex items-center gap-1.5 text-amber-400">
                      <Battery className="w-4 h-4" />
                      <span>-{batteryDrain}% Battery</span>
                    </div>
                  )}

                  <div className="flex items-center gap-1.5 text-emerald-400">
                    <Activity className="w-4 h-4" />
                    <span>~{session.avgPing} ms</span>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
