import React from 'react';
import { translations } from '../utils/translations';
import { Language } from '../types';
import { sounds } from '../utils/audio';
import { Globe, Settings, Bell, Zap, Wifi, Volume2, VolumeX, Gauge } from 'lucide-react';

interface NavbarProps {
  language: Language;
  onLanguageToggle: () => void;
  activeTab: string;
  onTabChange: (tab: string) => void;
  isGamingMode: boolean;
  onToggleGamingMode: () => void;
  unreadCount: number;
  onOpenSettings: () => void;
  isOnline: boolean;
  livePing: number | null;
  soundEnabled: boolean;
  onToggleSound: () => void;
  fps: number;
  isHudOpen: boolean;
  onToggleHud: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  language,
  onLanguageToggle,
  activeTab,
  onTabChange,
  isGamingMode,
  onToggleGamingMode,
  unreadCount,
  onOpenSettings,
  isOnline,
  livePing,
  soundEnabled,
  onToggleSound,
  fps,
  isHudOpen,
  onToggleHud,
}) => {
  const t = translations[language];

  return (
    <header className="sticky top-0 z-40 bg-slate-950/90 backdrop-blur-xl border-b border-cyan-500/20 px-3 sm:px-6 py-2.5 transition-colors">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-2 sm:gap-4">
        {/* Brand Zone: Official Logo + Name */}
        <div 
          onClick={() => onTabChange('dashboard')}
          className="flex items-center gap-2.5 cursor-pointer shrink-0 select-none group"
        >
          <div className="relative w-9 h-9 sm:w-10 sm:h-10 rounded-full p-0.5 bg-gradient-to-tr from-cyan-400 via-blue-500 to-red-500 shadow-md shadow-cyan-500/30 group-hover:scale-105 transition-transform">
            <img
              src="/assets/aistudio/InShot_20261021_172915725_10b6c6dd.jpg"
              alt="Mina Logo"
              className="w-full h-full object-cover rounded-full"
            />
          </div>
          <div className="flex flex-col">
            <div className="flex items-center gap-1.5">
              <span className="font-gaming font-black text-sm sm:text-base tracking-wider text-white">
                MINA <span className="text-cyan-400">OPTIMIZER</span>
              </span>
              <span className="text-[9px] font-bold px-1.5 py-0.2 bg-cyan-500 text-slate-950 rounded uppercase tracking-wider">
                PRO
              </span>
            </div>
            <span className="text-[10px] text-slate-400 font-mono -mt-0.5 hidden sm:inline">
              Gaming Mina 10K Official
            </span>
          </div>
        </div>

        {/* Live Network, FPS & Gaming Indicator (Desktop & Tablet) */}
        <div className="hidden lg:flex items-center gap-3 text-xs font-mono text-slate-400">
          {/* Live Real-Time FPS Chip */}
          <button
            onClick={() => {
              sounds.playClick();
              onToggleHud();
            }}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg border transition-all cursor-pointer ${
              isHudOpen
                ? 'bg-cyan-950/80 border-cyan-400 text-cyan-300 shadow-sm shadow-cyan-500/30'
                : 'bg-slate-900 border-slate-800 hover:border-cyan-500/50 text-slate-300'
            }`}
            title="Toggle Floating Game FPS HUD"
          >
            <Gauge className="w-3.5 h-3.5 text-cyan-400 animate-pulse" />
            <span className="tabular-nums font-bold text-white">{fps}</span>
            <span className="text-[10px] text-cyan-400 font-bold">FPS</span>
          </button>

          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-800">
            <Wifi className={`w-3.5 h-3.5 ${isOnline ? 'text-cyan-400' : 'text-red-400'}`} />
            <span className="tabular-nums text-slate-200 font-bold">
              {livePing !== null ? `${livePing} ms` : 'Testing...'}
            </span>
            <span className="text-[10px] text-slate-500">PING</span>
          </div>

          <button
            onClick={onToggleGamingMode}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg border transition-all cursor-pointer ${
              isGamingMode
                ? 'bg-cyan-950/60 border-cyan-500 text-cyan-300 shadow-sm shadow-cyan-500/20'
                : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200'
            }`}
          >
            <Zap className={`w-3.5 h-3.5 ${isGamingMode ? 'text-cyan-400 animate-pulse' : ''}`} />
            <span>{isGamingMode ? t.gamingModeActive : t.gamingModeInactive}</span>
          </button>
        </div>

        {/* Actions Zone: Language Switcher, Sound, Notifications, Settings */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* Mobile & Compact FPS quick badge */}
          <button
            onClick={() => {
              sounds.playClick();
              onTabChange('fps');
            }}
            className="flex lg:hidden items-center gap-1 px-2 py-1 rounded-lg bg-cyan-950/70 border border-cyan-500/40 text-cyan-300 text-xs font-mono font-bold cursor-pointer"
            title="Open FPS Monitor"
          >
            <Gauge className="w-3 h-3 text-cyan-400 animate-pulse" />
            <span className="tabular-nums">{fps}</span>
            <span className="text-[9px] text-cyan-400/80">FPS</span>
          </button>

          {/* Sound Toggle */}
          <button
            onClick={onToggleSound}
            className="w-8 h-8 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 hover:text-cyan-400 flex items-center justify-center transition-colors cursor-pointer"
            title={soundEnabled ? 'Mute Sounds' : 'Enable Sounds'}
          >
            {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4 text-slate-500" />}
          </button>

          {/* Language Switcher */}
          <button
            onClick={() => {
              sounds.playClick();
              onLanguageToggle();
            }}
            className="px-2.5 py-1.5 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 text-slate-200 text-xs font-medium flex items-center gap-1.5 transition-colors cursor-pointer"
            title="Change Language"
          >
            <Globe className="w-3.5 h-3.5 text-cyan-400" />
            <span className="font-semibold">{language === 'si' ? 'සිං' : 'EN'}</span>
          </button>

          {/* Notification Center Trigger */}
          <button
            onClick={() => {
              sounds.playClick();
              onTabChange('notifications');
            }}
            className="relative w-8 h-8 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 hover:text-cyan-400 flex items-center justify-center transition-colors cursor-pointer"
            title="Notifications"
          >
            <Bell className="w-4 h-4" />
            {unreadCount > 0 && (
              <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-cyan-500 text-slate-950 text-[10px] font-bold flex items-center justify-center">
                {unreadCount}
              </span>
            )}
          </button>

          {/* Settings Trigger */}
          <button
            onClick={() => {
              sounds.playClick();
              onOpenSettings();
            }}
            className="w-8 h-8 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 hover:text-cyan-400 flex items-center justify-center transition-colors cursor-pointer"
            title="Settings"
          >
            <Settings className="w-4 h-4" />
          </button>
        </div>
      </div>
    </header>
  );
};
