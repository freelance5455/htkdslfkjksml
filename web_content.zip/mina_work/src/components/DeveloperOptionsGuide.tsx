import React, { useState } from 'react';
import { translations } from '../utils/translations';
import { Language } from '../types';
import { sounds } from '../utils/audio';
import {
  BookOpen,
  Settings,
  AlertTriangle,
  CheckCircle2,
  Sparkles,
  Zap,
  ShieldAlert,
  Smartphone,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';

interface DeveloperOptionsGuideProps {
  language: Language;
}

export const DeveloperOptionsGuide: React.FC<DeveloperOptionsGuideProps> = ({ language }) => {
  const t = translations[language];
  const [expandedSection, setExpandedSection] = useState<number | null>(1);

  const toggleSection = (idx: number) => {
    sounds.playClick();
    setExpandedSection(expandedSection === idx ? null : idx);
  };

  const steps = [
    {
      id: 1,
      title: t.devStep1Title,
      summary: language === 'si' ? 'Settings -> About Phone -> 7 Taps on Build Number' : 'Enable Developer Options via 7 taps',
      content: t.devStep1Desc,
      recommended: 'Enabled',
      badge: 'Step 1',
    },
    {
      id: 2,
      title: t.devStep2Title,
      summary: language === 'si' ? 'Window, Transition, Animator Scales 0.5x හෝ Off' : 'Set Animation Scales to 0.5x or Off',
      content: t.devStep2Desc,
      recommended: '0.5x or 0x (Off)',
      badge: 'Zero Lag',
    },
    {
      id: 3,
      title: t.devStep3Title,
      summary: language === 'si' ? 'Free Fire 90Hz / 120Hz Refresh Rate සක්‍රීය කිරීම' : 'Force Peak Refresh Rate for 90/120 FPS',
      content: t.devStep3Desc,
      recommended: 'Enabled (On supported devices)',
      badge: 'Smooth FPS',
    },
    {
      id: 4,
      title: t.devStep4Title,
      summary: language === 'si' ? 'Background Apps සීමා කිරීම (RAM Optimization)' : 'Limit background apps to 2 or 3',
      content: t.devStep4Desc,
      recommended: 'At most 2 or 3 processes',
      badge: 'RAM Saver',
    },
    {
      id: 5,
      title: language === 'si' ? '5. HW Overlays අක්‍රීය කිරීම (Disable HW Overlays)' : '5. Disable HW Overlays',
      summary: language === 'si' ? 'Screen Compositing සඳහා GPU සෘජුවම භාවිත කිරීම' : 'Direct GPU hardware composition',
      content: language === 'si'
        ? 'Always use GPU for screen compositing. මෙයින් CPU එක මත ඇති බර අඩු වී Free Fire FPS ස්ථායී (stable) වේ.'
        : 'Forces the system to use the GPU for screen compositing instead of the CPU, preventing rendering stutters.',
      recommended: 'Enable (Turn ON)',
      badge: 'GPU Direct',
    },
    {
      id: 6,
      title: language === 'si' ? '6. Show Refresh Rate (Real FPS Display)' : '6. Show Refresh Rate Indicator',
      summary: language === 'si' ? 'තිරයේ ඉහළ කොණේ සැබෑ Screen Refresh Rate එක පෙන්වීම' : 'Shows live display frame rate in upper corner',
      content: language === 'si'
        ? 'ඔබගේ Screen එක සැබෑවටම 90Hz හෝ 120Hz ක්‍රියාත්මක වන්නේදැයි බලා ගැනීමට මෙය සක්‍රීය කළ හැක.'
        : 'Displays current display refresh rate in the upper left corner to verify whether 90Hz/120Hz is active.',
      recommended: 'Optional',
      badge: 'Telemetry',
    },
  ];

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div>
        <h1 className="text-xl sm:text-2xl font-black text-white font-gaming flex items-center gap-2">
          <BookOpen className="w-6 h-6 text-cyan-400" />
          <span>{t.devGuideTitle}</span>
        </h1>
        <p className="text-xs text-slate-400 mt-1">
          {language === 'si'
            ? 'Android පද්ධතියේ සැඟවුණු Developer Options නිවැරදිව සකස් කර Game එක උපරිම වේගවත් කරගන්න'
            : 'Official manual optimization manual for Android Developer Options and input response'}
        </p>
      </div>

      {/* Warning Box */}
      <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-red-950/80 via-slate-900 to-slate-900 border border-red-500/40 shadow-xl">
        <div className="flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-red-400 shrink-0 mt-0.5" />
          <div>
            <h3 className="text-xs sm:text-sm font-bold text-red-300 font-gaming">
              {language === 'si' ? 'වැදගත් අනතුරු ඇඟවීම (Safety Warning)' : 'Important Safety Warning'}
            </h3>
            <p className="text-xs text-slate-300 mt-1 leading-relaxed">
              {t.devWarning}
            </p>
            <p className="text-[11px] text-red-300/80 mt-1 font-mono">
              {language === 'si'
                ? '• "Force 4x MSAA" ක්‍රියාත්මක නොකරන්න - එය Battery එක දැඩි ලෙස රත් කරයි.'
                : '• Do NOT enable "Force 4x MSAA" on mid-range phones as it causes heavy thermal heating.'}
            </p>
          </div>
        </div>
      </div>

      {/* Accordion Steps List */}
      <div className="space-y-3">
        {steps.map((step) => {
          const isExpanded = expandedSection === step.id;
          return (
            <div
              key={step.id}
              className={`rounded-2xl border transition-all overflow-hidden ${
                isExpanded
                  ? 'bg-slate-900 border-cyan-500/40 shadow-xl shadow-cyan-950/30'
                  : 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
              }`}
            >
              <button
                onClick={() => toggleSection(step.id)}
                className="w-full p-4 sm:p-5 flex items-center justify-between text-left cursor-pointer"
              >
                <div className="flex items-center gap-3">
                  <span className="w-8 h-8 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-center font-gaming font-bold text-cyan-400 text-xs shrink-0">
                    {step.id}
                  </span>
                  <div>
                    <h3 className="font-gaming font-bold text-sm text-white">
                      {step.title}
                    </h3>
                    <p className="text-xs text-slate-400 font-mono mt-0.5">
                      {step.summary}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-500/30 hidden sm:inline">
                    {step.badge}
                  </span>
                  {isExpanded ? (
                    <ChevronUp className="w-4 h-4 text-slate-400" />
                  ) : (
                    <ChevronDown className="w-4 h-4 text-slate-400" />
                  )}
                </div>
              </button>

              {isExpanded && (
                <div className="px-5 pb-5 pt-1 border-t border-slate-800/60 text-xs space-y-3">
                  <p className="text-slate-300 leading-relaxed">
                    {step.content}
                  </p>
                  <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                    <span className="text-slate-400 font-mono">
                      {language === 'si' ? 'නිර්දේශිත අගය:' : 'Recommended Configuration:'}
                    </span>
                    <span className="font-mono font-bold text-emerald-400">
                      {step.recommended}
                    </span>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Safety Notice */}
      <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 flex items-start gap-3 text-xs text-slate-400">
        <ShieldAlert className="w-4 h-4 text-cyan-400 mt-0.5 shrink-0" />
        <span>{t.devNotice}</span>
      </div>
    </div>
  );
};
