import React from 'react';
import { translations } from '../utils/translations';
import { Language, DeviceInfo } from '../types';
import { sounds } from '../utils/audio';
import {
  Zap,
  Activity,
  Cpu,
  BatteryCharging,
  Battery,
  HardDrive,
  Flame,
  Target,
  Sliders,
  Maximize2,
  Video,
  Wifi,
  Terminal,
  ShieldCheck,
  ChevronRight,
  Sparkles,
  RotateCw,
  Gauge,
  Layers,
} from 'lucide-react';
import { FpsMetrics } from '../utils/fpsMeter';

interface DashboardProps {
  language: Language;
  deviceInfo: DeviceInfo | null;
  livePing: number | null;
  fpsMetrics: FpsMetrics;
  isHudOpen: boolean;
  onToggleHud: () => void;
  isGamingMode: boolean;
  onToggleGamingMode: () => void;
  onNavigate: (tab: string) => void;
  onQuickCleanRam: () => void;
  isCleaningRam: boolean;
  onRefreshTelemetry: () => void;
}

export const Dashboard: React.FC<DashboardProps> = ({
  language,
  deviceInfo,
  livePing,
  fpsMetrics,
  isHudOpen,
  onToggleHud,
  isGamingMode,
  onToggleGamingMode,
  onNavigate,
  onQuickCleanRam,
  isCleaningRam,
  onRefreshTelemetry,
}) => {
  const t = translations[language];

  const hasBattery = deviceInfo && deviceInfo.batteryLevel !== null;
  const batteryPct = hasBattery ? deviceInfo.batteryLevel : null;
  const isCharging = deviceInfo ? deviceInfo.isCharging : false;

  return (
    <div className="space-y-5 pb-8">
      {/* Hero Banner: Gaming Mina 10K Logo & Official Branding */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-slate-950 via-slate-900 to-slate-950 border border-cyan-500/30 p-5 sm:p-7 shadow-2xl shadow-cyan-950/40">
        <div className="absolute -top-16 -left-16 w-48 h-48 bg-cyan-500/15 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-16 -right-16 w-48 h-48 bg-blue-600/15 rounded-full blur-3xl pointer-events-none" />

        <div className="relative flex flex-col md:flex-row items-center justify-between gap-5 text-center md:text-left">
          <div className="flex flex-col sm:flex-row items-center gap-4">
            {/* Official Logo */}
            <div className="relative w-24 h-24 sm:w-28 sm:h-28 rounded-full p-1 bg-gradient-to-tr from-cyan-400 via-blue-500 to-red-500 shadow-xl shadow-cyan-500/30 shrink-0">
              <img
                src="/assets/aistudio/InShot_20261021_172915725_10b6c6dd.jpg"
                alt="Gaming Mina 10K"
                className="w-full h-full object-cover rounded-full"
              />
            </div>

            <div>
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-950/70 border border-cyan-500/30 text-[11px] font-semibold text-cyan-300 mb-2">
                <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
                <span>By Gaming Mina 10K</span>
              </div>
              <h1 className="text-2xl sm:text-3xl lg:text-4xl font-black text-white font-gaming tracking-tight">
                MINA OPTIMIZER <span className="text-cyan-400">PRO</span>
              </h1>
              <p className="text-xs sm:text-sm text-slate-300 max-w-lg mt-1 font-medium">
                {language === 'si'
                  ? 'Garena Free Fire & Free Fire MAX සඳහා වන සම්පූර්ණ Android Gaming Performance Optimizer'
                  : 'Ultimate Android Gaming Performance Utility for Free Fire & Free Fire MAX'}
              </p>
            </div>
          </div>

          {/* Gaming Mode Action Card */}
          <div className="w-full md:w-auto bg-slate-900/90 border border-cyan-500/30 rounded-2xl p-4 flex flex-col items-center sm:items-end gap-3 shrink-0">
            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold text-slate-300">{t.gamingMode}</span>
              <span
                className={`text-[10px] font-mono px-2 py-0.5 rounded font-bold ${
                  isGamingMode ? 'bg-cyan-500 text-slate-950' : 'bg-slate-800 text-slate-400'
                }`}
              >
                {isGamingMode ? 'ACTIVE' : 'OFF'}
              </span>
            </div>
            <button
              onClick={() => {
                sounds.playCleanSuccess();
                onToggleGamingMode();
              }}
              className={`w-full sm:w-auto px-5 py-2.5 rounded-xl font-gaming font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition-all cursor-pointer ${
                isGamingMode
                  ? 'bg-gradient-to-r from-cyan-400 to-blue-500 text-slate-950 shadow-lg shadow-cyan-500/30'
                  : 'bg-slate-800 hover:bg-slate-750 text-cyan-400 border border-cyan-500/30'
              }`}
            >
              <Zap className={`w-4 h-4 ${isGamingMode ? 'fill-current' : ''}`} />
              <span>{isGamingMode ? t.disableGamingMode : t.enableGamingMode}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Free Fire Quick Launcher Shortcuts */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
        <div
          onClick={() => {
            sounds.playClick();
            onNavigate('freefire');
          }}
          className="group relative overflow-hidden rounded-2xl bg-gradient-to-br from-slate-950 to-slate-900 border border-orange-500/30 p-4 flex items-center justify-between cursor-pointer hover:border-orange-500/60 transition-all shadow-lg"
        >
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-orange-950/80 border border-orange-500/50 flex items-center justify-center text-orange-400 group-hover:scale-105 transition-transform">
              <Flame className="w-6 h-6 fill-current" />
            </div>
            <div>
              <div className="text-sm font-bold text-white font-gaming flex items-center gap-2">
                <span>Free Fire Standard</span>
                <span className="text-[10px] bg-orange-500/20 text-orange-300 px-1.5 py-0.2 rounded font-mono">FF</span>
              </div>
              <div className="text-xs text-slate-400">
                {language === 'si' ? 'Game Shortcut & Optimizer' : 'Launch & Optimize Game'}
              </div>
            </div>
          </div>
          <div className="w-8 h-8 rounded-full bg-slate-900 border border-slate-800 flex items-center justify-center text-orange-400 group-hover:translate-x-1 transition-transform">
            <ChevronRight className="w-4 h-4" />
          </div>
        </div>

        <div
          onClick={() => {
            sounds.playClick();
            onNavigate('freefire');
          }}
          className="group relative overflow-hidden rounded-2xl bg-gradient-to-br from-slate-950 to-slate-900 border border-cyan-500/30 p-4 flex items-center justify-between cursor-pointer hover:border-cyan-500/60 transition-all shadow-lg"
        >
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-cyan-950/80 border border-cyan-500/50 flex items-center justify-center text-cyan-400 group-hover:scale-105 transition-transform">
              <Flame className="w-6 h-6 fill-current" />
            </div>
            <div>
              <div className="text-sm font-bold text-white font-gaming flex items-center gap-2">
                <span>Free Fire MAX</span>
                <span className="text-[10px] bg-cyan-500/20 text-cyan-300 px-1.5 py-0.2 rounded font-mono">MAX</span>
              </div>
              <div className="text-xs text-slate-400">
                {language === 'si' ? 'Ultra HD Graphic Optimization' : 'Ultra HD Graphics Mode'}
              </div>
            </div>
          </div>
          <div className="w-8 h-8 rounded-full bg-slate-900 border border-slate-800 flex items-center justify-center text-cyan-400 group-hover:translate-x-1 transition-transform">
            <ChevronRight className="w-4 h-4" />
          </div>
        </div>
      </div>

      {/* Real-time Hardware Telemetry Cards Grid */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-sm font-semibold text-slate-300 uppercase tracking-wider font-mono flex items-center gap-2">
            <span>{t.quickStats}</span>
            <span className="text-cyan-400 text-xs font-normal font-sans">
              · {deviceInfo ? `${deviceInfo.brand} ${deviceInfo.model}` : 'Detecting...'}
            </span>
          </h2>
          <button
            onClick={() => {
              sounds.playClick();
              onRefreshTelemetry();
            }}
            className="text-xs text-slate-400 hover:text-cyan-400 flex items-center gap-1 cursor-pointer transition-colors"
          >
            <RotateCw className="w-3 h-3" />
            <span>{language === 'si' ? 'Refresh' : 'Refresh'}</span>
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
          {/* Live Real-Time FPS Card */}
          <div
            onClick={() => {
              sounds.playClick();
              onNavigate('fps');
            }}
            className="group bg-slate-900/80 hover:bg-slate-900 border border-slate-800 hover:border-cyan-400/60 rounded-2xl p-4 transition-all cursor-pointer shadow-md col-span-2 sm:col-span-1"
          >
            <div className="flex items-center justify-between mb-2">
              <div className="w-8 h-8 rounded-xl bg-cyan-950/70 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
                <Gauge className="w-4 h-4 animate-pulse" />
              </div>
              <span className="text-[10px] font-mono text-cyan-400 font-bold">
                {fpsMetrics.refreshRate}Hz REAL
              </span>
            </div>
            <div className="text-xl sm:text-2xl font-black font-gaming text-cyan-400 tabular-nums flex items-baseline gap-1">
              <span>{fpsMetrics.fps}</span>
              <span className="text-xs text-slate-400 font-mono font-normal">FPS</span>
            </div>
            <div className="text-xs text-slate-300 mt-0.5">{t.liveFps}</div>
            <div className="text-[11px] text-cyan-400/90 font-mono mt-2 truncate">
              {fpsMetrics.frameTimeMs}ms · 1%L {fpsMetrics.onePercentLow}
            </div>
          </div>

          {/* RAM Telemetry Card */}
          <div
            onClick={() => {
              sounds.playClick();
              onNavigate('ram');
            }}
            className="group bg-slate-900/80 hover:bg-slate-900 border border-slate-800 hover:border-cyan-500/50 rounded-2xl p-4 transition-all cursor-pointer shadow-md"
          >
            <div className="flex items-center justify-between mb-2">
              <div className="w-8 h-8 rounded-xl bg-cyan-950/70 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
                <Cpu className="w-4 h-4" />
              </div>
              <span className="text-[10px] font-mono text-cyan-400 font-bold">
                {typeof deviceInfo?.usedRamMB === 'number' ? `${deviceInfo.ramUsagePercent}%` : 'REAL'}
              </span>
            </div>
            <div className="text-xl sm:text-2xl font-black font-gaming text-white tabular-nums">
              {deviceInfo?.totalRamGB}
            </div>
            <div className="text-xs text-slate-400 mt-0.5">{t.ramUsage}</div>
            <div className="text-[11px] text-slate-500 font-mono mt-2 truncate">
              {typeof deviceInfo?.usedRamMB === 'number' ? `${deviceInfo.usedRamMB} MB Used` : 'Heap Query Ready'}
            </div>
          </div>

          {/* Live Ping Card */}
          <div
            onClick={() => {
              sounds.playClick();
              onNavigate('ping');
            }}
            className="group bg-slate-900/80 hover:bg-slate-900 border border-slate-800 hover:border-emerald-500/50 rounded-2xl p-4 transition-all cursor-pointer shadow-md"
          >
            <div className="flex items-center justify-between mb-2">
              <div className="w-8 h-8 rounded-xl bg-emerald-950/70 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
                <Activity className="w-4 h-4" />
              </div>
              <span className="text-[10px] font-mono text-emerald-400 font-bold uppercase">
                {livePing !== null ? (livePing < 60 ? 'OPTIMAL' : livePing < 120 ? 'STABLE' : 'HIGH') : 'REAL TIME'}
              </span>
            </div>
            <div className="text-xl sm:text-2xl font-black font-gaming text-white tabular-nums flex items-baseline gap-1">
              <span>{livePing !== null ? livePing : '--'}</span>
              <span className="text-xs text-slate-400 font-sans font-normal">ms</span>
            </div>
            <div className="text-xs text-slate-400 mt-0.5">{t.livePing}</div>
            <div className="text-[11px] text-emerald-400/90 font-mono mt-2 truncate">
              {deviceInfo?.networkType || '4G/Wi-Fi'}
            </div>
          </div>

          {/* Battery Status Card */}
          <div
            onClick={() => {
              sounds.playClick();
              onNavigate('cooling');
            }}
            className="group bg-slate-900/80 hover:bg-slate-900 border border-slate-800 hover:border-amber-500/50 rounded-2xl p-4 transition-all cursor-pointer shadow-md"
          >
            <div className="flex items-center justify-between mb-2">
              <div className="w-8 h-8 rounded-xl bg-amber-950/70 border border-amber-500/30 flex items-center justify-center text-amber-400">
                {isCharging ? <BatteryCharging className="w-4 h-4" /> : <Battery className="w-4 h-4" />}
              </div>
              <span className="text-[10px] font-mono text-amber-400 font-bold">
                {hasBattery ? (isCharging ? 'CHARGING' : 'BATTERY') : 'SENSOR'}
              </span>
            </div>
            <div className="text-xl sm:text-2xl font-black font-gaming text-white tabular-nums">
              {hasBattery ? `${batteryPct}%` : 'Protected'}
            </div>
            <div className="text-xs text-slate-400 mt-0.5">{t.batteryStatus}</div>
            <div className="text-[11px] text-amber-400/90 font-mono mt-2 truncate">
              {hasBattery ? (isCharging ? 'AC Powered' : 'Discharging') : 'Sandbox Protected'}
            </div>
          </div>

          {/* Storage Telemetry Card */}
          <div
            onClick={() => {
              sounds.playClick();
              onNavigate('storage');
            }}
            className="group bg-slate-900/80 hover:bg-slate-900 border border-slate-800 hover:border-purple-500/50 rounded-2xl p-4 transition-all cursor-pointer shadow-md"
          >
            <div className="flex items-center justify-between mb-2">
              <div className="w-8 h-8 rounded-xl bg-purple-950/70 border border-purple-500/30 flex items-center justify-center text-purple-400">
                <HardDrive className="w-4 h-4" />
              </div>
              <span className="text-[10px] font-mono text-purple-400 font-bold">
                {deviceInfo?.storageAvailableGB !== 'N/A' ? `${deviceInfo?.storageAvailableGB} GB FREE` : 'STORAGE'}
              </span>
            </div>
            <div className="text-xl sm:text-2xl font-black font-gaming text-white tabular-nums">
              {deviceInfo?.storageQuotaGB !== 'N/A' ? `${deviceInfo?.storageQuotaGB} GB` : 'System Quota'}
            </div>
            <div className="text-xs text-slate-400 mt-0.5">{t.storageUsage}</div>
            <div className="text-[11px] text-purple-400/90 font-mono mt-2 truncate">
              {deviceInfo?.storageUsedGB !== 'N/A' ? `${deviceInfo?.storageUsedGB} GB Used` : 'Protected Sandbox'}
            </div>
          </div>
        </div>
      </div>

      {/* Real-time FPS & Floating Game HUD Engine Banner */}
      <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-slate-950 via-slate-900 to-cyan-950/50 border border-cyan-500/40 shadow-xl flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-4 text-center sm:text-left w-full md:w-auto">
          <div className="w-12 h-12 rounded-2xl bg-cyan-500/20 border border-cyan-500/50 flex items-center justify-center text-cyan-400 shrink-0">
            <Gauge className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap justify-center sm:justify-start">
              <h3 className="font-gaming font-bold text-sm sm:text-base text-white">
                {language === 'si' ? 'සජීවී FPS Game HUD & Display Engine' : 'Live FPS Game HUD & Display Engine'}
              </h3>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 font-bold">
                {fpsMetrics.fps} FPS · {fpsMetrics.refreshRate}Hz
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              {language === 'si'
                ? 'ඕනෑම Screen එකක් මත පාවෙන (Floating) FPS Overlay එකක් තබාගෙන Frame Drops නිරීක්ෂණය කරන්න'
                : 'Keep a floating on-screen FPS counter over games, sensitivity tests & HUD training'}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto shrink-0">
          <button
            onClick={() => {
              sounds.playClick();
              onToggleHud();
            }}
            className={`flex-1 sm:flex-none px-4 py-2.5 rounded-xl font-gaming font-bold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer ${
              isHudOpen
                ? 'bg-cyan-500 text-slate-950 shadow-lg shadow-cyan-500/30'
                : 'bg-slate-800 hover:bg-slate-750 text-cyan-400 border border-cyan-500/30'
            }`}
          >
            <Layers className="w-4 h-4" />
            <span>{isHudOpen ? (language === 'si' ? 'HUD සක්‍රීයයි' : 'HUD Active') : (language === 'si' ? 'Floating HUD පෙන්වන්න' : 'Show Floating HUD')}</span>
          </button>

          <button
            onClick={() => {
              sounds.playClick();
              onNavigate('fps');
            }}
            className="flex-1 sm:flex-none px-4 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-850 text-slate-200 border border-slate-700 font-gaming font-bold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
          >
            <span>{language === 'si' ? 'සම්පූර්ණ FPS Monitor' : 'Full FPS Monitor'}</span>
            <ChevronRight className="w-3.5 h-3.5 text-cyan-400" />
          </button>
        </div>
      </div>

      {/* One-Tap Quick Safe RAM Clean Action */}
      <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-slate-900 via-slate-900 to-cyan-950/40 border border-cyan-500/30 flex flex-col sm:flex-row items-center justify-between gap-4 shadow-xl">
        <div className="flex items-center gap-3.5 text-center sm:text-left">
          <div className="w-11 h-11 rounded-2xl bg-cyan-500/20 border border-cyan-500/50 flex items-center justify-center text-cyan-400 shrink-0">
            <Cpu className="w-6 h-6" />
          </div>
          <div>
            <h3 className="font-gaming font-bold text-sm sm:text-base text-white">
              {language === 'si' ? 'ක්ෂණික RAM ආරක්ෂිත පිරිසිදු කිරීම' : 'One-Tap Safe RAM Optimization'}
            </h3>
            <p className="text-xs text-slate-400">
              {language === 'si'
                ? 'Heap caches සහ background memory ආරක්ෂිතව මුදා හරී'
                : 'Safely releases unused browser buffers and heap cache'}
            </p>
          </div>
        </div>

        <button
          onClick={() => {
            sounds.playClick();
            onQuickCleanRam();
          }}
          disabled={isCleaningRam}
          className={`w-full sm:w-auto px-6 py-2.5 rounded-xl font-gaming font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition-all cursor-pointer shrink-0 ${
            isCleaningRam
              ? 'bg-slate-800 text-cyan-400 border border-cyan-500/50 animate-pulse'
              : 'bg-gradient-to-r from-cyan-400 to-blue-600 text-slate-950 hover:brightness-110 shadow-lg shadow-cyan-500/20 active:scale-[0.98]'
          }`}
        >
          <Sparkles className="w-4 h-4" />
          <span>{isCleaningRam ? t.cleaning : t.cleanRamNow}</span>
        </button>
      </div>

      {/* Quick Tools Grid */}
      <div>
        <h2 className="text-sm font-semibold text-slate-300 uppercase tracking-wider font-mono mb-3">
          {t.quickActions}
        </h2>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5">
          {[
            { id: 'aim', label: t.tabAimTrainer, icon: Target, color: 'text-red-400', border: 'hover:border-red-500/40' },
            { id: 'sens', label: t.tabSens, icon: Sliders, color: 'text-cyan-400', border: 'hover:border-cyan-500/40' },
            { id: 'hud', label: t.tabHud, icon: Maximize2, color: 'text-amber-400', border: 'hover:border-amber-500/40' },
            { id: 'recorder', label: t.tabRecorder, icon: Video, color: 'text-emerald-400', border: 'hover:border-emerald-500/40' },
            { id: 'scripts', label: t.tabScripts, icon: Terminal, color: 'text-purple-400', border: 'hover:border-purple-500/40' },
            { id: 'wifi', label: t.tabWifi, icon: Wifi, color: 'text-blue-400', border: 'hover:border-blue-500/40' },
          ].map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                onClick={() => {
                  sounds.playClick();
                  onNavigate(item.id);
                }}
                className={`p-3.5 rounded-2xl bg-slate-900/80 border border-slate-800 ${item.border} flex flex-col items-center text-center gap-2 transition-all hover:bg-slate-850 cursor-pointer group`}
              >
                <div className={`p-2.5 rounded-xl bg-slate-950 border border-slate-800 ${item.color} group-hover:scale-110 transition-transform`}>
                  <Icon className="w-5 h-5" />
                </div>
                <span className="text-xs font-semibold text-slate-200 line-clamp-1">
                  {item.label}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Real Native Notice banner */}
      <div className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800/80 flex items-center gap-3 text-xs text-slate-400">
        <ShieldCheck className="w-4 h-4 text-cyan-400 shrink-0" />
        <span>
          {language === 'si'
            ? '100% සත්‍ය තොරතුරු පමණි: කිසිදු ව්‍යාජ (Fake) අගයක් හෝ අනුමාන කිරීමක් මෙහි ඇතුළත් කර නැත. ලබාගත හැකි සැබෑ දත්ත පමණක් පෙන්වයි.'
            : '100% Authentic Telemetry: Only real hardware and network values are displayed without any fabricated numbers.'}
        </span>
      </div>
    </div>
  );
};
