import React from 'react';
import { translations } from '../utils/translations';
import { Language } from '../types';
import { sounds } from '../utils/audio';
import { Play, Globe, ShieldCheck } from 'lucide-react';

interface WelcomeModalProps {
  language: Language;
  onLanguageChange: (lang: Language) => void;
  onStart: () => void;
}

export const WelcomeModal: React.FC<WelcomeModalProps> = ({
  language,
  onLanguageChange,
  onStart,
}) => {
  const t = translations[language];

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto p-4 sm:p-6 bg-black/85 backdrop-blur-md flex items-center justify-center">
      <div className="w-full max-w-lg my-auto max-h-[90vh] overflow-y-auto bg-slate-900/95 border border-cyan-500/30 rounded-3xl p-5 sm:p-8 shadow-2xl shadow-cyan-950/50 text-center relative">
        {/* Neon Glow backdrop */}
        <div className="absolute -top-24 -left-24 w-52 h-52 bg-cyan-500/20 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 -right-24 w-52 h-52 bg-blue-600/20 rounded-full blur-3xl pointer-events-none" />

        {/* Official Logo */}
        <div className="relative mx-auto w-28 h-28 sm:w-32 sm:h-32 rounded-full p-1 bg-gradient-to-tr from-cyan-500 via-blue-500 to-red-500 shadow-xl shadow-cyan-500/20 mb-5">
          <img
            src="/assets/aistudio/InShot_20261021_172915725_10b6c6dd.jpg"
            alt="Gaming Mina 10K Logo"
            className="w-full h-full object-cover rounded-full"
          />
        </div>

        {/* Title */}
        <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-white font-gaming mb-1">
          MINA OPTIMIZER <span className="text-cyan-400">PRO</span>
        </h1>
        <p className="text-xs sm:text-sm text-cyan-300/80 font-medium mb-2">
          {t.appSubtitle}
        </p>
        <p className="text-xs text-slate-400 max-w-md mx-auto mb-6">
          {t.welcomeSubtitle}
        </p>

        {/* Language Selection */}
        <div className="bg-slate-950/80 border border-slate-800 rounded-2xl p-4 mb-6">
          <div className="flex items-center justify-center gap-2 text-xs font-semibold text-slate-300 mb-3">
            <Globe className="w-4 h-4 text-cyan-400" />
            <span>{t.selectLanguage}</span>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <button
              onClick={() => {
                sounds.playClick();
                onLanguageChange('si');
              }}
              className={`py-3 px-4 rounded-xl text-xs sm:text-sm font-semibold transition-all ${
                language === 'si'
                  ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-slate-950 font-bold shadow-lg shadow-cyan-500/25 scale-[1.02]'
                  : 'bg-slate-900 text-slate-300 hover:bg-slate-800 border border-slate-800'
              }`}
            >
              සිංහල (Sinhala)
            </button>
            <button
              onClick={() => {
                sounds.playClick();
                onLanguageChange('en');
              }}
              className={`py-3 px-4 rounded-xl text-xs sm:text-sm font-semibold transition-all ${
                language === 'en'
                  ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-slate-950 font-bold shadow-lg shadow-cyan-500/25 scale-[1.02]'
                  : 'bg-slate-900 text-slate-300 hover:bg-slate-800 border border-slate-800'
              }`}
            >
              English
            </button>
          </div>
        </div>

        {/* Security / Safe notice */}
        <div className="flex items-center justify-center gap-2 text-[11px] text-slate-400 mb-6">
          <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>100% Safe · No Root Required · Anti-Ban Compliant</span>
        </div>

        {/* Start Button */}
        <button
          onClick={() => {
            sounds.playCleanSuccess();
            onStart();
          }}
          className="w-full py-3.5 px-6 rounded-2xl bg-gradient-to-r from-cyan-400 via-blue-500 to-cyan-500 text-slate-950 font-bold text-sm sm:text-base flex items-center justify-center gap-2 shadow-lg shadow-cyan-500/30 hover:brightness-110 active:scale-[0.98] transition-all cursor-pointer font-gaming tracking-wide"
        >
          <Play className="w-5 h-5 fill-current" />
          <span>{t.welcomeStart}</span>
        </button>
      </div>
    </div>
  );
};
