import React, { useState } from 'react';
import { translations } from '../utils/translations';
import { Language, DeviceInfo, CleanupLog } from '../types';
import { sounds } from '../utils/audio';
import { performSafeRamClean } from '../utils/systemDiagnostics';
import confetti from 'canvas-confetti';
import {
  Cpu,
  Sparkles,
  ShieldCheck,
  History,
  Trash2,
  CheckCircle2,
  Clock,
  Info,
} from 'lucide-react';

interface RamCleanerProProps {
  language: Language;
  deviceInfo: DeviceInfo | null;
  cleanupHistory: CleanupLog[];
  onAddCleanupLog: (log: CleanupLog) => void;
  onClearHistory: () => void;
  onRefreshTelemetry: () => void;
}

export const RamCleanerPro: React.FC<RamCleanerProProps> = ({
  language,
  deviceInfo,
  cleanupHistory,
  onAddCleanupLog,
  onClearHistory,
  onRefreshTelemetry,
}) => {
  const t = translations[language];
  const [isCleaning, setIsCleaning] = useState(false);
  const [lastResult, setLastResult] = useState<{
    freedMB: number;
    beforeMB: number;
    afterMB: number;
    cachesDeleted: number;
  } | null>(null);

  const handleCleanRam = async () => {
    sounds.playClick();
    setIsCleaning(true);
    setLastResult(null);

    const result = await performSafeRamClean();

    const log: CleanupLog = {
      id: Date.now().toString(),
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
      freedMB: result.freedMB,
      beforeRamMB: result.beforeMB,
      afterRamMB: result.afterMB,
      target: result.cachesDeleted > 0 ? `${result.cachesDeleted} Cache Buckets` : 'Heap Defragmentation',
    };

    onAddCleanupLog(log);
    setLastResult(result);
    setIsCleaning(false);
    sounds.playCleanSuccess();

    try {
      confetti({
        particleCount: 50,
        spread: 50,
        origin: { y: 0.7 },
        colors: ['#00f0ff', '#3b82f6'],
      });
    } catch {
      // Ignored
    }

    onRefreshTelemetry();
  };

  const hasHeap = deviceInfo && typeof deviceInfo.usedRamMB === 'number';
  const usedMB = hasHeap ? (deviceInfo.usedRamMB as number) : null;
  const availMB = hasHeap ? (deviceInfo.availableRamMB as number) : null;
  const ramPercent = hasHeap ? deviceInfo.ramUsagePercent : null;

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div>
        <h1 className="text-xl sm:text-2xl font-black text-white font-gaming flex items-center gap-2">
          <Cpu className="w-6 h-6 text-cyan-400" />
          <span>{t.ramCleanerTitle}</span>
        </h1>
        <p className="text-xs text-slate-400 mt-1">
          {language === 'si'
            ? 'ආරක්ෂිත RAM Heap Cache පිරිසිදු කිරීම සහ මතක නිදහස් කිරීමේ පද්ධතිය (සැබෑ දත්ත පමණි)'
            : 'Safe memory cache purge and heap defragmentation'}
        </p>
      </div>

      {/* Main RAM Gauge Card */}
      <div className="bg-slate-900 border border-cyan-500/30 rounded-3xl p-6 sm:p-8 text-center relative overflow-hidden shadow-2xl">
        <div className="absolute -top-24 -left-24 w-52 h-52 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />

        {/* Circular RAM Usage Representation */}
        <div className="relative mx-auto w-44 h-44 sm:w-52 sm:h-52 flex items-center justify-center mb-6">
          <svg className="w-full h-full -rotate-90 transform" viewBox="0 0 100 100">
            {/* Background track */}
            <circle
              cx="50"
              cy="50"
              r="40"
              className="text-slate-800"
              strokeWidth="8"
              stroke="currentColor"
              fill="transparent"
            />
            {/* Progress circle */}
            <circle
              cx="50"
              cy="50"
              r="40"
              className="text-cyan-400 transition-all duration-700"
              strokeWidth="8"
              strokeDasharray={2 * Math.PI * 40}
              strokeDashoffset={2 * Math.PI * 40 * (1 - (ramPercent || 20) / 100)}
              strokeLinecap="round"
              stroke="currentColor"
              fill="transparent"
            />
          </svg>

          {/* Center text */}
          <div className="absolute flex flex-col items-center">
            <span className="text-3xl sm:text-4xl font-black font-gaming text-white tabular-nums">
              {ramPercent !== null ? `${ramPercent}%` : 'REAL'}
            </span>
            <span className="text-xs text-slate-400 font-mono uppercase tracking-wider">
              {t.ramUsage}
            </span>
            <span className="text-[11px] text-cyan-400 font-mono mt-0.5">
              {usedMB !== null ? `${usedMB} MB Used` : 'Heap Query Ready'}
            </span>
          </div>
        </div>

        {/* Telemetry Numbers row */}
        <div className="grid grid-cols-3 gap-2 max-w-md mx-auto mb-6 text-center">
          <div className="p-3 rounded-2xl bg-slate-950/80 border border-slate-800">
            <div className="text-[10px] text-slate-500 font-mono uppercase">{t.totalRam}</div>
            <div className="text-base font-bold text-white font-gaming mt-0.5 truncate">
              {deviceInfo?.totalRamGB}
            </div>
          </div>
          <div className="p-3 rounded-2xl bg-slate-950/80 border border-slate-800">
            <div className="text-[10px] text-slate-500 font-mono uppercase">{t.usedRam}</div>
            <div className="text-base font-bold text-cyan-400 font-gaming mt-0.5">
              {usedMB !== null ? `${usedMB} MB` : 'Real'}
            </div>
          </div>
          <div className="p-3 rounded-2xl bg-slate-950/80 border border-slate-800">
            <div className="text-[10px] text-slate-500 font-mono uppercase">{t.availableRam}</div>
            <div className="text-base font-bold text-emerald-400 font-gaming mt-0.5">
              {availMB !== null ? `${availMB} MB` : 'Available'}
            </div>
          </div>
        </div>

        {/* Safe Clean Action Button */}
        <button
          onClick={handleCleanRam}
          disabled={isCleaning}
          className={`w-full max-w-md py-4 px-8 rounded-2xl font-gaming font-black text-sm sm:text-base flex items-center justify-center gap-2 mx-auto transition-all cursor-pointer shadow-xl ${
            isCleaning
              ? 'bg-slate-800 text-cyan-400 border border-cyan-500/50 animate-pulse'
              : 'bg-gradient-to-r from-cyan-400 via-blue-500 to-cyan-500 text-slate-950 shadow-cyan-500/30 hover:brightness-110 active:scale-[0.98]'
          }`}
        >
          <Sparkles className="w-5 h-5 fill-current" />
          <span>{isCleaning ? t.cleaning : t.cleanRamNow}</span>
        </button>

        {/* Safe notice explanation */}
        <p className="text-[11px] text-slate-400 max-w-md mx-auto mt-4 leading-relaxed">
          {t.ramCleanNotice}
        </p>
      </div>

      {/* Clean Result Modal / Banner if just cleaned */}
      {lastResult && (
        <div className="p-5 rounded-2xl bg-gradient-to-r from-emerald-950/80 via-slate-900 to-cyan-950/80 border border-emerald-500/40 flex flex-col sm:flex-row items-center justify-between gap-4 shadow-xl">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 border border-emerald-500/50 flex items-center justify-center text-emerald-400 shrink-0">
              <CheckCircle2 className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-gaming font-bold text-white text-base">
                {t.ramCleanedSuccess}
              </h3>
              <p className="text-xs text-slate-300">
                {lastResult.freedMB > 0 ? (
                  <>
                    {t.freedMemory}: <strong className="text-emerald-400">+{lastResult.freedMB} MB</strong> · Before: {lastResult.beforeMB} MB → After: {lastResult.afterMB} MB
                  </>
                ) : (
                  <span>CacheStorage Buckets purged ({lastResult.cachesDeleted} buckets cleared)</span>
                )}
              </p>
            </div>
          </div>
          <span className="text-xs font-mono px-3 py-1 bg-emerald-950 text-emerald-300 rounded-full border border-emerald-500/30">
            Purged
          </span>
        </div>
      )}

      {/* Cleanup History Log */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 shadow-lg">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <History className="w-4 h-4 text-cyan-400" />
            <h2 className="font-gaming font-bold text-sm text-slate-200">
              {t.cleanupHistory}
            </h2>
          </div>
          {cleanupHistory.length > 0 && (
            <button
              onClick={() => {
                sounds.playClick();
                onClearHistory();
              }}
              className="text-xs text-slate-400 hover:text-red-400 flex items-center gap-1 cursor-pointer transition-colors"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>{language === 'si' ? 'හිස් කරන්න' : 'Clear Log'}</span>
            </button>
          )}
        </div>

        {cleanupHistory.length === 0 ? (
          <div className="text-center py-6 text-xs text-slate-500 font-mono">
            {t.noHistory}
          </div>
        ) : (
          <div className="space-y-2">
            {cleanupHistory.slice(0, 6).map((log) => (
              <div
                key={log.id}
                className="flex items-center justify-between p-3 rounded-xl bg-slate-950/70 border border-slate-800/80 text-xs"
              >
                <div className="flex items-center gap-2.5">
                  <Clock className="w-3.5 h-3.5 text-slate-400" />
                  <span className="text-slate-300 font-medium">{log.timestamp}</span>
                  <span className="text-[11px] text-slate-500 font-mono">({log.target})</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="font-mono text-emerald-400 font-bold">
                    {log.freedMB > 0 ? `+${log.freedMB} MB` : 'Purged'}
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Anti-Fake Policy Banner */}
      <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 flex items-start gap-3 text-xs text-slate-400">
        <ShieldCheck className="w-4 h-4 text-cyan-400 mt-0.5 shrink-0" />
        <span>
          {language === 'si'
            ? 'සත්‍ය දත්ත පමණි: මෙම RAM Cleaner එක මඟින් සැබෑවටම Browser Cache ඉවත් කරනු ලැබේ. Hardware RAM වැඩි කළ බවට ව්‍යාජ ප්‍රතිඵල පෙන්වන්නේ නැත.'
            : 'Integrity Notice: Unused heap buffers and cache buckets are genuinely dropped. No fabricated RAM results.'}
        </span>
      </div>
    </div>
  );
};
