import React, { useState, useEffect, useRef } from 'react';
import { translations } from '../utils/translations';
import { Language } from '../types';
import { FpsMetrics } from '../utils/fpsMeter';
import { sounds } from '../utils/audio';
import {
  Activity,
  Zap,
  Gauge,
  Sparkles,
  Layers,
  Flame,
  Play,
} from 'lucide-react';

interface FpsMonitorProProps {
  language: Language;
  fpsMetrics: FpsMetrics;
  isHudOpen: boolean;
  onToggleHud: () => void;
  onNavigate: (tab: string) => void;
}

export const FpsMonitorPro: React.FC<FpsMonitorProProps> = ({
  language,
  fpsMetrics,
  isHudOpen,
  onToggleHud,
  onNavigate,
}) => {
  const t = translations[language];

  // Stress test states
  const [isStressTesting, setIsStressTesting] = useState(false);
  const [stressTimeLeft, setStressTimeLeft] = useState(0);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const stressRafRef = useRef<number | null>(null);

  // Run a genuine 10-second canvas render stress test to measure real frame drops
  const runStressTest = () => {
    sounds.playClick();
    setIsStressTesting(true);
    setStressTimeLeft(10);

    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Create 350 moving particles
    const particles = Array.from({ length: 350 }, () => ({
      x: Math.random() * canvas.width,
      y: Math.random() * canvas.height,
      vx: (Math.random() - 0.5) * 6,
      vy: (Math.random() - 0.5) * 6,
      radius: Math.random() * 3 + 1,
      color: `hsl(${Math.random() * 60 + 170}, 100%, 50%)`,
    }));

    let startTime = performance.now();

    const render = (now: number) => {
      const elapsed = (now - startTime) / 1000;
      const remaining = Math.max(0, 10 - Math.floor(elapsed));
      setStressTimeLeft(remaining);

      if (remaining <= 0) {
        setIsStressTesting(false);
        sounds.playCleanSuccess();
        return;
      }

      ctx.fillStyle = 'rgba(10, 15, 30, 0.25)';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      for (let p of particles) {
        p.x += p.vx;
        p.y += p.vy;
        if (p.x < 0 || p.x > canvas.width) p.vx *= -1;
        if (p.y < 0 || p.y > canvas.height) p.vy *= -1;

        ctx.beginPath();
        ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
        ctx.fillStyle = p.color;
        ctx.shadowColor = p.color;
        ctx.shadowBlur = 8;
        ctx.fill();
      }

      stressRafRef.current = requestAnimationFrame(render);
    };

    stressRafRef.current = requestAnimationFrame(render);
  };

  useEffect(() => {
    return () => {
      if (stressRafRef.current) cancelAnimationFrame(stressRafRef.current);
    };
  }, []);

  const getStatusColor = (fps: number) => {
    if (fps >= 90) return 'text-cyan-400';
    if (fps >= 55) return 'text-emerald-400';
    if (fps >= 35) return 'text-amber-400';
    return 'text-red-400';
  };

  // Sparkline points
  const maxVal = Math.max(60, fpsMetrics.refreshRate);
  const sparkWidth = 400;
  const sparkHeight = 80;
  const points = fpsMetrics.history.map((val, idx) => {
    const x = (idx / (fpsMetrics.history.length - 1)) * sparkWidth;
    const y = sparkHeight - (val / maxVal) * sparkHeight;
    return `${x.toFixed(1)},${y.toFixed(1)}`;
  }).join(' ');

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-5 rounded-2xl bg-slate-900 border border-cyan-500/30 shadow-xl">
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-2xl bg-cyan-950 border border-cyan-500/40 flex items-center justify-center text-cyan-400 shrink-0">
            <Activity className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl sm:text-2xl font-black font-gaming text-white">
                {language === 'si' ? 'සජීවී FPS & Display Monitor' : 'Live FPS & Display Monitor'}
              </h1>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-500 text-slate-950 font-bold uppercase">
                REAL TIME
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              {language === 'si'
                ? 'Device එකේ Screen Refresh Rate සහ Frame Rate සැබෑවටම තත්පරයෙන් තත්පරය මැනීම'
                : 'Real hardware requestAnimationFrame telemetry with 1% Low & Frame Time analysis'}
            </p>
          </div>
        </div>

        {/* Floating HUD toggle */}
        <button
          onClick={() => {
            sounds.playClick();
            onToggleHud();
          }}
          className={`px-4 py-2.5 rounded-xl font-gaming font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition-all cursor-pointer ${
            isHudOpen
              ? 'bg-cyan-500 text-slate-950 shadow-lg shadow-cyan-500/30'
              : 'bg-slate-800 hover:bg-slate-750 text-cyan-400 border border-cyan-500/30'
          }`}
        >
          <Layers className="w-4 h-4" />
          <span>
            {isHudOpen
              ? (language === 'si' ? 'Floating HUD සක්‍රීයයි' : 'Floating HUD Active')
              : (language === 'si' ? 'Floating HUD ක්‍රියාත්මක කරන්න' : 'Enable Floating HUD')}
          </span>
        </button>
      </div>

      {/* Main Gauge & Big Metrics */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Big Live FPS Card */}
        <div className="lg:col-span-2 rounded-3xl bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 border border-cyan-500/30 p-6 flex flex-col justify-between shadow-2xl relative overflow-hidden">
          <div className="flex items-center justify-between mb-4">
            <span className="text-xs font-mono text-slate-400 uppercase tracking-wider flex items-center gap-2">
              <Gauge className="w-4 h-4 text-cyan-400" />
              <span>{language === 'si' ? 'වත්මන් Frame Rate' : 'Current Frame Rate'}</span>
            </span>
            <span className="text-xs font-mono px-2.5 py-1 rounded-full bg-cyan-950 border border-cyan-500/30 text-cyan-300 font-bold">
              {fpsMetrics.refreshRate} Hz Display
            </span>
          </div>

          <div className="flex flex-col sm:flex-row items-baseline sm:items-center justify-between gap-4 py-4">
            <div className="flex items-baseline gap-3">
              <span className={`text-6xl sm:text-7xl font-black font-gaming tracking-tight tabular-nums ${getStatusColor(fpsMetrics.fps)}`}>
                {fpsMetrics.fps}
              </span>
              <div className="flex flex-col">
                <span className="text-base sm:text-lg font-mono font-bold text-slate-300">FPS</span>
                <span className="text-xs text-slate-400 font-mono">
                  {fpsMetrics.fps >= 55 ? 'PERFECT FOR FREE FIRE' : 'DROPS DETECTED'}
                </span>
              </div>
            </div>

            <div className="flex flex-col items-start sm:items-end">
              <span className="text-xs text-slate-400 font-mono">{language === 'si' ? 'Frame Time' : 'Frame Time'}</span>
              <span className="text-2xl font-black font-gaming text-white tabular-nums">
                {fpsMetrics.frameTimeMs} <span className="text-sm font-normal text-slate-400">ms</span>
              </span>
              <span className="text-[11px] text-cyan-400 font-mono">
                Target: {(1000 / fpsMetrics.refreshRate).toFixed(1)} ms
              </span>
            </div>
          </div>

          {/* Real-time Waveform Canvas/SVG */}
          <div className="mt-4 pt-4 border-t border-slate-800">
            <div className="flex items-center justify-between text-xs font-mono text-slate-400 mb-2">
              <span>{language === 'si' ? 'සජීවී Frame Rate තරංගය' : 'Real-time FPS Waveform'}</span>
              <span>Min: {fpsMetrics.minFps} / Max: {fpsMetrics.maxFps}</span>
            </div>
            <div className="h-20 w-full bg-black/40 rounded-xl p-2 border border-slate-800/80 relative overflow-hidden">
              <svg className="w-full h-full overflow-visible" preserveAspectRatio="none" viewBox={`0 0 ${sparkWidth} ${sparkHeight}`}>
                <polyline
                  fill="none"
                  stroke="#00f0ff"
                  strokeWidth="2.5"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  points={points}
                />
              </svg>
            </div>
          </div>
        </div>

        {/* Telemetry Breakdown Cards */}
        <div className="space-y-3">
          {/* 1% Low FPS */}
          <div className="rounded-2xl bg-slate-900 border border-slate-800 p-4 shadow-lg">
            <div className="text-xs text-slate-400 font-mono">{language === 'si' ? '1% Low Frame Rate' : '1% Low Frame Rate'}</div>
            <div className="text-2xl font-black font-gaming text-cyan-300 tabular-nums mt-1">
              {fpsMetrics.onePercentLow} <span className="text-xs font-normal text-slate-400">FPS</span>
            </div>
            <div className="text-[11px] text-slate-500 mt-1">
              {language === 'si'
                ? 'ක්‍රීඩාවේදී Stutter හෝ Lag ඇතිවීම මනින ජාත්‍යන්තර ප්‍රමිතිය'
                : 'Key gaming metric for micro-stutters and frame spikes'}
            </div>
          </div>

          {/* Average FPS */}
          <div className="rounded-2xl bg-slate-900 border border-slate-800 p-4 shadow-lg">
            <div className="text-xs text-slate-400 font-mono">{language === 'si' ? 'සාමාන්‍ය FPS (Average)' : 'Average FPS'}</div>
            <div className="text-2xl font-black font-gaming text-white tabular-nums mt-1">
              {fpsMetrics.avgFps} <span className="text-xs font-normal text-slate-400">FPS</span>
            </div>
            <div className="text-[11px] text-slate-500 mt-1">
              {language === 'si' ? 'මෑත තත්පර තුළ ස්ථාවර මට්ටම' : 'Sustained throughput over sample window'}
            </div>
          </div>

          {/* Stutter Count */}
          <div className="rounded-2xl bg-slate-900 border border-slate-800 p-4 shadow-lg">
            <div className="text-xs text-slate-400 font-mono">{language === 'si' ? 'Frame Drops / Stutters' : 'Frame Drops / Stutters'}</div>
            <div className="text-2xl font-black font-gaming text-amber-400 tabular-nums mt-1">
              {fpsMetrics.stutterCount} <span className="text-xs font-normal text-slate-400">Events</span>
            </div>
            <div className="text-[11px] text-slate-500 mt-1">
              {language === 'si' ? '1.5x වඩා ප්‍රමාද වූ frames ගණන' : 'Frames taking >1.5x expected frame time'}
            </div>
          </div>
        </div>
      </div>

      {/* Free Fire & Free Fire MAX Recommended Display Settings */}
      <div className="p-5 rounded-2xl bg-gradient-to-r from-slate-900 via-slate-900 to-cyan-950/40 border border-cyan-500/30 shadow-xl">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-xl bg-orange-950/80 border border-orange-500/40 flex items-center justify-center text-orange-400">
            <Flame className="w-5 h-5 fill-current" />
          </div>
          <div>
            <h3 className="font-gaming font-bold text-base text-white">
              {language === 'si' ? 'Free Fire සඳහා නිර්දේශිත FPS සැකසුම්' : 'Recommended In-Game FPS Settings'}
            </h3>
            <p className="text-xs text-slate-400">
              {language === 'si'
                ? 'ඔබගේ Screen Refresh Rate එකට අනුව Free Fire Settings සකස් කර ගන්න'
                : 'Optimal Free Fire & FF MAX in-game graphics for zero frame drops'}
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800">
            <div className="text-xs font-bold text-cyan-400 font-gaming mb-1">High FPS Mode</div>
            <div className="text-sm font-semibold text-white">
              {fpsMetrics.refreshRate >= 90 ? 'High / Ultra (90-120 FPS)' : 'Normal / High (60 FPS)'}
            </div>
            <div className="text-[11px] text-slate-400 mt-1">
              {fpsMetrics.refreshRate >= 90
                ? (language === 'si' ? 'ඔබගේ 90Hz/120Hz display එක High FPS සඳහා සහය දක්වයි' : 'High refresh rate detected and supported')
                : (language === 'si' ? '60Hz ස්ථාවර Display සඳහා High FPS යොදන්න' : 'Standard 60Hz display')}
            </div>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800">
            <div className="text-xs font-bold text-orange-400 font-gaming mb-1">Free Fire Graphics</div>
            <div className="text-sm font-semibold text-white">
              {fpsMetrics.avgFps >= 58 ? 'Standard or Ultra' : 'Smooth (Best Stability)'}
            </div>
            <div className="text-[11px] text-slate-400 mt-1">
              {fpsMetrics.avgFps >= 58
                ? (language === 'si' ? 'Frame drops නොමැතිව Ultra ක්‍රියාත්මක කළ හැක' : 'Can sustain ultra graphics')
                : (language === 'si' ? 'Smooth යෙදීමෙන් FPS අඩුවීම වළක්වන්න' : 'Smooth prevents thermal throttling')}
            </div>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800">
            <div className="text-xs font-bold text-emerald-400 font-gaming mb-1">Shadows & V-Sync</div>
            <div className="text-sm font-semibold text-white">OFF (Recommended)</div>
            <div className="text-[11px] text-slate-400 mt-1">
              {language === 'si'
                ? 'Shadows Off කිරීමෙන් 10-15% කින් frame rate වැඩිවේ'
                : 'Disabling shadows reduces GPU load by 15%'}
            </div>
          </div>
        </div>
      </div>

      {/* Real Canvas Render Stress Test */}
      <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-4">
          <div>
            <h3 className="font-gaming font-bold text-base text-white flex items-center gap-2">
              <Zap className="w-4 h-4 text-cyan-400" />
              <span>{language === 'si' ? 'තත්පර 10 සැබෑ Render Stress Test' : '10-Second Hardware Render Stress Test'}</span>
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              {language === 'si'
                ? 'GPU එකට සැබෑ Canvas Particles බරක් ලබා දී Frame Drop ඇතිවේදැයි සැබෑවටම පරීක්ෂා කරයි'
                : 'Spawns 350 moving glow particles to test your hardware frame stability under stress'}
            </p>
          </div>

          <button
            onClick={runStressTest}
            disabled={isStressTesting}
            className={`px-4 py-2 rounded-xl font-gaming font-bold text-xs flex items-center gap-2 cursor-pointer transition-all ${
              isStressTesting
                ? 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/40 animate-pulse'
                : 'bg-cyan-500 text-slate-950 hover:bg-cyan-400 shadow-lg shadow-cyan-500/20'
            }`}
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            <span>
              {isStressTesting
                ? (language === 'si' ? `පරීක්ෂා වෙමින්... (${stressTimeLeft}s)` : `Testing... (${stressTimeLeft}s)`)
                : (language === 'si' ? 'පරීක්ෂාව අරඹන්න' : 'Start Stress Test')}
            </span>
          </button>
        </div>

        {/* Live Canvas Box */}
        <div className="relative w-full h-44 rounded-xl bg-slate-950 border border-slate-800 overflow-hidden flex items-center justify-center">
          <canvas
            ref={canvasRef}
            width={700}
            height={176}
            className="w-full h-full object-cover"
          />
          {!isStressTesting && (
            <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/60 pointer-events-none p-4 text-center">
              <Sparkles className="w-8 h-8 text-cyan-400/80 mb-2" />
              <p className="text-xs text-slate-300 font-medium">
                {language === 'si'
                  ? 'Stress Test එක ක්‍රියාත්මක කර real-time FPS ප්‍රතිචාරය පරීක්ෂා කරන්න'
                  : 'Click Start Stress Test to measure real frame rate under particle rendering load'}
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
