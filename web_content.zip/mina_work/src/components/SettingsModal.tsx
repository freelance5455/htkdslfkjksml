import React, { useState } from 'react';
import { translations } from '../utils/translations';
import { Language } from '../types';
import { sounds } from '../utils/audio';
import {
  X,
  Globe,
  Settings,
  Bell,
  Info,
  ShieldCheck,
  ExternalLink,
  RotateCcw,
  Sparkles,
  Bug,
  HelpCircle,
  Youtube,
  CheckCircle2,
} from 'lucide-react';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
  onLanguageChange: (lang: Language) => void;
  onResetApp: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  language,
  onLanguageChange,
  onResetApp,
}) => {
  if (!isOpen) return null;
  const t = translations[language];

  const [activeTab, setActiveTab] = useState<'general' | 'permissions' | 'about' | 'privacy'>('general');
  const [checkingUpdate, setCheckingUpdate] = useState(false);
  const [updateMessage, setUpdateMessage] = useState<string | null>(null);

  const handleCheckUpdate = () => {
    sounds.playClick();
    setCheckingUpdate(true);
    setUpdateMessage(null);
    setTimeout(() => {
      setCheckingUpdate(false);
      setUpdateMessage(
        language === 'si'
          ? 'ඔබ භාවිත කරන්නේ නවතම Version 2.5.0 Pro Gaming Edition ය. නව Updates නොමැත.'
          : 'You are running the latest Mina Optimizer Pro v2.5.0. No pending updates.'
      );
      sounds.playCleanSuccess();
    }, 1000);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto p-3 sm:p-4 bg-black/85 backdrop-blur-md flex items-center justify-center">
      <div className="w-full max-w-xl my-auto bg-slate-900 border border-cyan-500/30 rounded-3xl shadow-2xl flex flex-col max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <Settings className="w-5 h-5 text-cyan-400" />
            <h2 className="font-gaming font-bold text-base sm:text-lg text-white">
              {t.settingsTitle}
            </h2>
          </div>
          <button
            onClick={() => {
              sounds.playClick();
              onClose();
            }}
            className="w-8 h-8 rounded-full bg-slate-850 hover:bg-slate-800 text-slate-300 flex items-center justify-center cursor-pointer transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Sub-navigation tabs */}
        <div className="flex border-b border-slate-800 bg-slate-950 px-4 gap-2 overflow-x-auto">
          {[
            { id: 'general', label: language === 'si' ? 'සාමාන්‍ය (General)' : 'General' },
            { id: 'permissions', label: language === 'si' ? 'අවසර (Permissions)' : 'Permissions' },
            { id: 'about', label: t.aboutApp },
            { id: 'privacy', label: t.privacyPolicy },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => {
                sounds.playClick();
                setActiveTab(tab.id as any);
              }}
              className={`py-3 px-3 text-xs font-semibold whitespace-nowrap border-b-2 transition-all cursor-pointer ${
                activeTab === tab.id
                  ? 'border-cyan-400 text-cyan-300 font-bold'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Tab Content Body */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-5 text-xs">
          {activeTab === 'general' && (
            <div className="space-y-5">
              {/* Language Switch */}
              <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="font-gaming font-bold text-slate-200 flex items-center gap-2">
                    <Globe className="w-4 h-4 text-cyan-400" />
                    <span>{t.appLanguage}</span>
                  </span>
                  <span className="text-[11px] font-mono text-cyan-400 font-bold">
                    {language === 'si' ? 'සිංහල' : 'English'}
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <button
                    onClick={() => {
                      sounds.playClick();
                      onLanguageChange('si');
                    }}
                    className={`py-2.5 px-3 rounded-xl font-semibold text-center border transition-all cursor-pointer ${
                      language === 'si'
                        ? 'bg-cyan-500 text-slate-950 border-cyan-400 font-bold shadow-md shadow-cyan-950/50'
                        : 'bg-slate-900 text-slate-300 border-slate-800 hover:bg-slate-800'
                    }`}
                  >
                    සිංහල (Sinhala)
                  </button>
                  <button
                    onClick={() => {
                      sounds.playClick();
                      onLanguageChange('en');
                    }}
                    className={`py-2.5 px-3 rounded-xl font-semibold text-center border transition-all cursor-pointer ${
                      language === 'en'
                        ? 'bg-cyan-500 text-slate-950 border-cyan-400 font-bold shadow-md shadow-cyan-950/50'
                        : 'bg-slate-900 text-slate-300 border-slate-800 hover:bg-slate-800'
                    }`}
                  >
                    English
                  </button>
                </div>
              </div>

              {/* Theme information */}
              <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                <div>
                  <div className="font-gaming font-bold text-slate-200">{t.theme}</div>
                  <div className="text-[11px] text-slate-400 mt-0.5">
                    {t.darkNeon} (OLED Ultra-Black + Cyber Cyan)
                  </div>
                </div>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-950 text-cyan-400 border border-cyan-500/30">
                  Fixed Dark
                </span>
              </div>

              {/* Update Checker */}
              <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="font-gaming font-bold text-slate-200">
                      {language === 'si' ? 'App යාවත්කාලීන පරීක්ෂාව' : 'Software Updates'}
                    </div>
                    <div className="text-[11px] text-slate-400">{t.appVersion}</div>
                  </div>
                  <button
                    onClick={handleCheckUpdate}
                    disabled={checkingUpdate}
                    className="px-3.5 py-1.5 rounded-xl bg-slate-900 border border-slate-700 hover:border-cyan-500 text-cyan-300 font-semibold cursor-pointer transition-colors"
                  >
                    {checkingUpdate ? 'Checking...' : (language === 'si' ? 'පරීක්ෂා කරන්න' : 'Check for Updates')}
                  </button>
                </div>

                {updateMessage && (
                  <div className="p-2.5 rounded-xl bg-emerald-950/60 border border-emerald-500/30 text-emerald-300 text-[11px] flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 shrink-0" />
                    <span>{updateMessage}</span>
                  </div>
                )}
              </div>
            </div>
          )}

          {activeTab === 'permissions' && (
            <div className="space-y-3">
              <p className="text-slate-300 leading-relaxed mb-3">
                {language === 'si'
                  ? 'MINA OPTIMIZER PRO ක්‍රියාත්මක වීමට අවශ්‍ය අවසර පමණක් භාවිත කරයි. කිසිදු අනවශ්‍ය අවසරයක් ඉල්ලනු නොලැබේ.'
                  : 'MINA OPTIMIZER PRO only utilizes legitimate hardware & sensor APIs. Unnecessary permissions are never requested.'}
              </p>

              {[
                { name: 'Notifications', status: 'Granted / Prompted', reason: 'RAM Cleanup & Ping completed alerts' },
                { name: 'Wake Lock (Screen Keep-On)', status: 'Standard Web API', reason: 'Prevents screen dimming during Free Fire rank gameplay' },
                { name: 'Media Devices (Display & Mic)', status: 'User Prompted', reason: 'Used strictly when user explicitly initiates Screen Recording' },
                { name: 'Network State', status: 'Standard Web API', reason: 'Queries online/offline status and roundtrip latency' },
                { name: 'Storage Estimate', status: 'Quota API', reason: 'Measures browser cache usage and quota allocations' },
              ].map((perm, idx) => (
                <div key={idx} className="p-3.5 rounded-xl bg-slate-950 border border-slate-800">
                  <div className="flex items-center justify-between font-gaming font-bold text-slate-200">
                    <span>{perm.name}</span>
                    <span className="text-[10px] font-mono text-cyan-400">{perm.status}</span>
                  </div>
                  <div className="text-[11px] text-slate-400 mt-0.5">{perm.reason}</div>
                </div>
              ))}
            </div>
          )}

          {activeTab === 'about' && (
            <div className="space-y-4 text-center">
              {/* Official Logo */}
              <div className="mx-auto w-24 h-24 rounded-full p-1 bg-gradient-to-tr from-cyan-400 via-blue-500 to-red-500 shadow-xl shadow-cyan-500/20">
                <img
                  src="/assets/aistudio/InShot_20261021_172915725_10b6c6dd.jpg"
                  alt="Gaming Mina 10K Logo"
                  className="w-full h-full object-cover rounded-full"
                />
              </div>

              <div>
                <h3 className="font-gaming font-black text-lg text-white">
                  MINA OPTIMIZER PRO
                </h3>
                <p className="text-xs text-cyan-300 font-mono font-medium">
                  Created by Gaming Mina 10K
                </p>
                <p className="text-[11px] text-slate-400 mt-2 max-w-md mx-auto leading-relaxed">
                  {language === 'si'
                    ? 'මෙම Application එක විශේෂයෙන් Garena Free Fire සහ Free Fire MAX ක්‍රීඩකයන්ගේ Gaming Performance, Sensitivity, Live Ping සහ Device Ergonomics ප්‍රශස්ත කිරීම සඳහා නිර්මාණය කරන ලදි.'
                    : 'Engineered specifically for Garena Free Fire and Free Fire MAX competitors to maximize touch sensitivity, stabilize ping, and optimize system buffers.'}
                </p>
              </div>

              {/* YouTube Link */}
              <a
                href={t.youtubeUrl}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-2 py-2.5 px-5 rounded-2xl bg-red-600 hover:bg-red-500 text-white font-gaming font-bold text-xs shadow-lg shadow-red-950/50 cursor-pointer transition-all"
              >
                <Youtube className="w-4 h-4 fill-current" />
                <span>YouTube @Gaming Mina 10K</span>
                <ExternalLink className="w-3.5 h-3.5 ml-1" />
              </a>

              <div className="text-[11px] text-slate-500 font-mono pt-3">
                {t.appVersion} · Build 2026.10
              </div>
            </div>
          )}

          {activeTab === 'privacy' && (
            <div className="space-y-3 leading-relaxed text-slate-300">
              <h3 className="font-gaming font-bold text-sm text-white">
                {t.privacyPolicy}
              </h3>
              <p>{t.privacyText}</p>
              <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 text-[11px] text-slate-400 space-y-1.5">
                <div>• Zero external telemetry or analytics trackers.</div>
                <div>• Zero third-party ad networks or background tracking.</div>
                <div>• All diagnostic computations remain strictly sandboxed in your browser memory.</div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800 bg-slate-950/80 flex justify-end">
          <button
            onClick={() => {
              sounds.playClick();
              onClose();
            }}
            className="py-2 px-5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-gaming font-bold text-xs cursor-pointer"
          >
            {t.close}
          </button>
        </div>
      </div>
    </div>
  );
};
