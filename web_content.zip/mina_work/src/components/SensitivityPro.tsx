import React, { useState } from 'react';
import { translations } from '../utils/translations';
import { Language, SensitivitySettings } from '../types';
import { sounds } from '../utils/audio';
import {
  Sliders,
  Copy,
  RotateCcw,
  Save,
  Check,
  ShieldAlert,
  Sparkles,
  BookOpen,
} from 'lucide-react';

interface SensitivityProProps {
  language: Language;
  settings: SensitivitySettings;
  onUpdateSettings: (settings: SensitivitySettings) => void;
}

export const SensitivityPro: React.FC<SensitivityProProps> = ({
  language,
  settings,
  onUpdateSettings,
}) => {
  const t = translations[language];
  const [copied, setCopied] = useState(false);
  const [activePreset, setActivePreset] = useState<string>('headshot');

  const presets: Record<string, { name: string; desc: string; values: SensitivitySettings }> = {
    headshot: {
      name: t.presetHeadshot,
      desc: language === 'si' ? 'Drag Headshot සඳහා උපරිම General සහ Red Dot' : 'High sensitivity for effortless upward drag headshots',
      values: { general: 98, redDot: 95, scope2x: 92, scope4x: 88, sniperScope: 55, freeLook: 70 },
    },
    balanced: {
      name: t.presetBalanced,
      desc: language === 'si' ? 'Recoil පාලනය සහ මිඩ්-රේන්ජ් වෙඩි තැබීම් සඳහා' : 'Balanced spray recoil control for mid-range fights',
      values: { general: 88, redDot: 82, scope2x: 78, scope4x: 72, sniperScope: 50, freeLook: 65 },
    },
    lowEnd: {
      name: t.presetLowEnd,
      desc: language === 'si' ? '2GB - 4GB RAM දුරකථන සඳහා Max Sensitivity' : 'Max 100 sensitivity to compensate for touch latency on budget screens',
      values: { general: 100, redDot: 100, scope2x: 95, scope4x: 92, sniperScope: 60, freeLook: 80 },
    },
    esports: {
      name: t.presetEsports,
      desc: language === 'si' ? 'තරඟාවලි සහ නිවැරදි Sniper Aiming සඳහා' : 'Tournament grade precision for fast scope switching',
      values: { general: 95, redDot: 90, scope2x: 86, scope4x: 80, sniperScope: 45, freeLook: 60 },
    },
  };

  const handleApplyPreset = (key: string) => {
    sounds.playClick();
    setActivePreset(key);
    onUpdateSettings(presets[key].values);
  };

  const handleSliderChange = (key: keyof SensitivitySettings, val: number) => {
    setActivePreset('custom');
    onUpdateSettings({ ...settings, [key]: val });
  };

  const handleCopy = () => {
    sounds.playCleanSuccess();
    const text = `MINA OPTIMIZER PRO - Free Fire Sensitivity:\n` +
      `General: ${settings.general}\n` +
      `Red Dot: ${settings.redDot}\n` +
      `2X Scope: ${settings.scope2x}\n` +
      `4X Scope: ${settings.scope4x}\n` +
      `Sniper Scope: ${settings.sniperScope}\n` +
      `Free Look: ${settings.freeLook}`;

    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleReset = () => {
    sounds.playClick();
    handleApplyPreset('headshot');
  };

  const fields: { key: keyof SensitivitySettings; label: string; desc: string }[] = [
    { key: 'general', label: t.generalSens, desc: 'Camera view rotation speed & drag response' },
    { key: 'redDot', label: t.redDotSens, desc: 'Aiming with iron sights and red dot reflex' },
    { key: 'scope2x', label: t.scope2xSens, desc: 'Medium range 2X scope tracking' },
    { key: 'scope4x', label: t.scope4xSens, desc: 'Long range 4X precision tracking' },
    { key: 'sniperScope', label: t.sniperScopeSens, desc: 'AWM, Kar98k, M82B sniper control' },
    { key: 'freeLook', label: t.freeLookSens, desc: 'Eye button quick 360 look around' },
  ];

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-white font-gaming flex items-center gap-2">
            <Sliders className="w-6 h-6 text-cyan-400" />
            <span>{t.sensTitle}</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            {language === 'si'
              ? 'Free Fire Drag Headshot සඳහා උපරිම ප්‍රශස්ත සංවේදීතා සැකසුම්'
              : 'Competitive sensitivity calibrations for Free Fire and Free Fire MAX'}
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleCopy}
            className="px-4 py-2 rounded-xl bg-slate-900 border border-slate-800 hover:border-cyan-500/50 text-xs text-cyan-300 font-semibold flex items-center gap-1.5 transition-all cursor-pointer"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? (language === 'si' ? 'Copy විය!' : 'Copied!') : t.copySettings}</span>
          </button>
          <button
            onClick={handleReset}
            className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-white transition-all cursor-pointer"
            title={t.resetSens}
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Preset Selection Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        {Object.entries(presets).map(([key, preset]) => {
          const isSelected = activePreset === key;
          return (
            <button
              key={key}
              onClick={() => handleApplyPreset(key)}
              className={`p-4 rounded-2xl border text-left transition-all cursor-pointer flex flex-col justify-between ${
                isSelected
                  ? 'bg-cyan-950/80 border-cyan-500 shadow-lg shadow-cyan-950/50'
                  : 'bg-slate-900/80 border-slate-800 hover:border-slate-700'
              }`}
            >
              <div>
                <div className="flex items-center justify-between mb-1">
                  <span className={`text-xs font-gaming font-bold ${isSelected ? 'text-cyan-300' : 'text-slate-200'}`}>
                    {preset.name}
                  </span>
                  {isSelected && <Sparkles className="w-3.5 h-3.5 text-cyan-400" />}
                </div>
                <p className="text-[11px] text-slate-400 leading-relaxed">
                  {preset.desc}
                </p>
              </div>
              <div className="mt-3 text-[10px] font-mono text-cyan-400 font-bold">
                General: {preset.values.general} · Red Dot: {preset.values.redDot}
              </div>
            </button>
          );
        })}
      </div>

      {/* Sensitivity Sliders Card */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-7 shadow-xl">
        <div className="space-y-5">
          {fields.map(({ key, label, desc }) => {
            const val = settings[key];
            return (
              <div key={key} className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-xs sm:text-sm font-bold text-slate-100 font-gaming">
                      {label}
                    </span>
                    <span className="text-[11px] text-slate-500 ml-2 hidden sm:inline">
                      {desc}
                    </span>
                  </div>
                  <span className="text-sm font-mono font-bold text-cyan-400 tabular-nums">
                    {val}
                  </span>
                </div>

                <div className="flex items-center gap-3">
                  <input
                    type="range"
                    min="0"
                    max="100"
                    value={val}
                    onChange={(e) => handleSliderChange(key, Number(e.target.value))}
                    className="w-full h-2 rounded-lg bg-slate-950 appearance-none cursor-pointer accent-cyan-400 focus:outline-none"
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Sensitivity Application Guide */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 shadow-lg">
        <div className="flex items-center gap-2 mb-3">
          <BookOpen className="w-4 h-4 text-cyan-400" />
          <h2 className="font-gaming font-bold text-sm text-slate-200">
            {language === 'si' ? 'Game එකට Sensitivity දාන ආකාරය' : 'How to Apply in Free Fire'}
          </h2>
        </div>

        <ol className="list-decimal list-inside space-y-1.5 text-xs text-slate-300">
          <li>{language === 'si' ? 'Free Fire Game එක Open කර ඉහළ දකුණු කෙළවරේ Settings (Gear icon) එක ඔබන්න.' : 'Open Free Fire and tap the Settings gear icon in the top right corner.'}</li>
          <li>{language === 'si' ? 'වම් පස මෙනුවෙන් "Sensitivity" තෝරන්න.' : 'Navigate to the "Sensitivity" tab on the left menu.'}</li>
          <li>{language === 'si' ? 'ඉහත ලබාදී ඇති අගයන් ඒ ආකාරයෙන්ම Slider මඟින් සකස් කර ගන්න.' : 'Manually adjust each slider to match the optimal values displayed above.'}</li>
          <li>{language === 'si' ? 'Training Ground එකට ගොස් Drag Headshot පුහුණු වන්න.' : 'Enter Training Grounds to dial in your muscle memory.'}</li>
        </ol>
      </div>

      {/* Safety Notice */}
      <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 flex items-start gap-3 text-xs text-slate-400">
        <ShieldAlert className="w-4 h-4 text-cyan-400 mt-0.5 shrink-0" />
        <span>{t.sensNotice}</span>
      </div>
    </div>
  );
};
