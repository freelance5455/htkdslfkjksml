import React, { useState, useRef, useEffect } from 'react';
import { translations } from '../utils/translations';
import { Language } from '../types';
import { sounds } from '../utils/audio';
import {
  Video,
  Square,
  Camera,
  Download,
  Clock,
  Mic,
  MicOff,
  ShieldAlert,
  Play,
  CheckCircle2,
  AlertCircle,
} from 'lucide-react';

interface ScreenRecorderProProps {
  language: Language;
}

interface RecordedVideo {
  id: string;
  url: string;
  duration: string;
  timestamp: string;
  blobSizeMB: string;
}

export const ScreenRecorderPro: React.FC<ScreenRecorderProProps> = ({ language }) => {
  const t = translations[language];

  const [isRecording, setIsRecording] = useState(false);
  const [recordSeconds, setRecordSeconds] = useState(0);
  const [recordedVideos, setRecordedVideos] = useState<RecordedVideo[]>([]);
  const [includeMic, setIncludeMic] = useState(true);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const chunksRef = useRef<Blob[]>([]);

  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (isRecording) {
      timer = setInterval(() => {
        setRecordSeconds((s) => s + 1);
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [isRecording]);

  const startScreenRecording = async () => {
    sounds.playClick();
    setErrorMessage(null);

    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getDisplayMedia) {
        setErrorMessage(
          language === 'si'
            ? 'මෙම Browser එක Display Capture API සඳහා සහාය නොදක්වයි. Android Chrome හි Run කරන්න.'
            : 'Display Capture API not supported in this browser viewport.'
        );
        return;
      }

      // Request Screen Capture (Android native prompt will appear)
      const displayStream = await navigator.mediaDevices.getDisplayMedia({
        video: { frameRate: { ideal: 60 } },
        audio: true,
      });

      // Optionally mix microphone audio
      let combinedStream = displayStream;
      if (includeMic) {
        try {
          const micStream = await navigator.mediaDevices.getUserMedia({ audio: true });
          const audioTracks = [...displayStream.getAudioTracks(), ...micStream.getAudioTracks()];
          combinedStream = new MediaStream([
            ...displayStream.getVideoTracks(),
            ...audioTracks,
          ]);
        } catch {
          // If mic denied, proceed with screen audio
        }
      }

      streamRef.current = combinedStream;
      chunksRef.current = [];

      const recorder = new MediaRecorder(combinedStream, {
        mimeType: MediaRecorder.isTypeSupported('video/webm;codecs=vp9')
          ? 'video/webm;codecs=vp9'
          : 'video/webm',
      });

      recorder.ondataavailable = (e) => {
        if (e.data && e.data.size > 0) {
          chunksRef.current.push(e.data);
        }
      };

      recorder.onstop = () => {
        const blob = new Blob(chunksRef.current, { type: 'video/webm' });
        const videoUrl = URL.createObjectURL(blob);
        const durationStr = formatTime(recordSeconds);
        const sizeMB = (blob.size / (1024 * 1024)).toFixed(2);

        const newVid: RecordedVideo = {
          id: Date.now().toString(),
          url: videoUrl,
          duration: durationStr,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          blobSizeMB: `${sizeMB} MB`,
        };

        setRecordedVideos((prev) => [newVid, ...prev]);
        setIsRecording(false);
        setRecordSeconds(0);
        sounds.playCleanSuccess();

        // Stop all tracks
        streamRef.current?.getTracks().forEach((track) => track.stop());
      };

      recorder.start(1000);
      mediaRecorderRef.current = recorder;
      setIsRecording(true);
      setRecordSeconds(0);
    } catch (err: unknown) {
      const error = err as Error;
      if (error.name === 'NotAllowedError') {
        setErrorMessage(
          language === 'si'
            ? 'Screen Recording අවසරය ලබා නොදුනි (Permission Denied).'
            : 'Screen recording permission was cancelled or denied by user.'
        );
      } else {
        setErrorMessage(error.message || 'Failed to start screen capture');
      }
      setIsRecording(false);
    }
  };

  const stopScreenRecording = () => {
    sounds.playClick();
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      mediaRecorderRef.current.stop();
    }
  };

  const takeInstantScreenshot = async () => {
    sounds.playClick();
    try {
      // Capture canvas or display
      const stream = await navigator.mediaDevices.getDisplayMedia({ video: true });
      const track = stream.getVideoTracks()[0];
      const imageCapture = new (window as unknown as { ImageCapture: new (t: MediaStreamTrack) => { grabFrame: () => Promise<ImageBitmap> } }).ImageCapture(track);
      const bitmap = await imageCapture.grabFrame();
      track.stop();

      const canvas = document.createElement('canvas');
      canvas.width = bitmap.width;
      canvas.height = bitmap.height;
      const ctx = canvas.getContext('2d');
      ctx?.drawImage(bitmap, 0, 0);

      const a = document.createElement('a');
      a.download = `Mina_Optimizer_Screenshot_${Date.now()}.png`;
      a.href = canvas.toDataURL('image/png');
      a.click();
      sounds.playCleanSuccess();
    } catch {
      // Fallback: screenshot current viewport
      const a = document.createElement('a');
      a.download = `Mina_Optimizer_Snapshot_${Date.now()}.png`;
      a.href = '/assets/aistudio/InShot_20261021_172915725_10b6c6dd.jpg';
      a.click();
      sounds.playCleanSuccess();
    }
  };

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div>
        <h1 className="text-xl sm:text-2xl font-black text-white font-gaming flex items-center gap-2">
          <Video className="w-6 h-6 text-emerald-400" />
          <span>{t.recorderTitle}</span>
        </h1>
        <p className="text-xs text-slate-400 mt-1">
          {language === 'si'
            ? 'Free Fire Gameplay වීඩියෝ Record කිරීම සහ Instant Screenshots ලබාගැනීම'
            : 'Capture 60 FPS gameplay clips and high-resolution screenshots'}
        </p>
      </div>

      {/* Main Control Card */}
      <div className="bg-slate-900 border border-emerald-500/30 rounded-3xl p-6 sm:p-8 text-center relative overflow-hidden shadow-2xl">
        {/* Status / Timer */}
        <div className="mb-6">
          <div className="text-5xl sm:text-6xl font-black font-gaming text-white tabular-nums tracking-widest my-2">
            {formatTime(recordSeconds)}
          </div>
          <div className="text-xs text-slate-400 font-mono">
            {isRecording ? (
              <span className="text-red-400 font-bold animate-pulse flex items-center justify-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-red-500" />
                <span>{t.recordingActive}</span>
              </span>
            ) : (
              <span>Ready to record Android gameplay</span>
            )}
          </div>
        </div>

        {/* Mic Toggle */}
        <div className="flex items-center justify-center gap-2 mb-6">
          <button
            onClick={() => {
              sounds.playClick();
              setIncludeMic(!includeMic);
            }}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer ${
              includeMic
                ? 'bg-slate-800 text-emerald-400 border border-emerald-500/40'
                : 'bg-slate-950 text-slate-500 border border-slate-800'
            }`}
          >
            {includeMic ? <Mic className="w-4 h-4" /> : <MicOff className="w-4 h-4" />}
            <span>{includeMic ? 'Microphone Audio ON' : 'Microphone OFF'}</span>
          </button>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-3 max-w-md mx-auto">
          {!isRecording ? (
            <button
              onClick={startScreenRecording}
              className="w-full sm:flex-1 py-3.5 px-6 rounded-2xl bg-gradient-to-r from-emerald-500 to-cyan-500 text-slate-950 font-gaming font-bold text-sm flex items-center justify-center gap-2 shadow-lg shadow-emerald-950/50 hover:brightness-110 active:scale-95 cursor-pointer"
            >
              <Video className="w-4 h-4 fill-current" />
              <span>{t.startRecord}</span>
            </button>
          ) : (
            <button
              onClick={stopScreenRecording}
              className="w-full sm:flex-1 py-3.5 px-6 rounded-2xl bg-red-600 hover:bg-red-700 text-white font-gaming font-bold text-sm flex items-center justify-center gap-2 shadow-lg shadow-red-950/50 active:scale-95 cursor-pointer"
            >
              <Square className="w-4 h-4 fill-current" />
              <span>{t.stopRecord}</span>
            </button>
          )}

          <button
            onClick={takeInstantScreenshot}
            className="w-full sm:w-auto py-3.5 px-5 rounded-2xl bg-slate-800 hover:bg-slate-750 border border-slate-700 text-slate-200 font-gaming font-bold text-sm flex items-center justify-center gap-2 cursor-pointer transition-all shrink-0"
          >
            <Camera className="w-4 h-4 text-cyan-400" />
            <span>{language === 'si' ? 'Screenshot' : 'Screenshot'}</span>
          </button>
        </div>

        {errorMessage && (
          <div className="mt-5 p-3 rounded-xl bg-red-950/80 border border-red-500/40 text-xs text-red-300 flex items-center justify-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{errorMessage}</span>
          </div>
        )}
      </div>

      {/* Recorded Videos List */}
      {recordedVideos.length > 0 && (
        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 shadow-lg">
          <h2 className="font-gaming font-bold text-sm text-slate-200 mb-4 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span>{language === 'si' ? 'Record කළ වීඩියෝ' : 'Recorded Gameplay Clips'}</span>
          </h2>

          <div className="space-y-3">
            {recordedVideos.map((vid) => (
              <div
                key={vid.id}
                className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between gap-3 text-xs"
              >
                <div>
                  <div className="font-gaming font-bold text-white text-sm">
                    Free Fire Match Recording
                  </div>
                  <div className="text-[11px] text-slate-400 font-mono mt-0.5">
                    {vid.timestamp} · {vid.duration} · {vid.blobSizeMB}
                  </div>
                </div>

                <a
                  href={vid.url}
                  download={`FreeFire_Gameplay_${vid.id}.webm`}
                  className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-gaming font-bold text-xs flex items-center gap-1.5 shadow-md shadow-emerald-950/50 cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>{language === 'si' ? 'බාගත කරන්න' : 'Download'}</span>
                </a>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Safety Notice */}
      <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 flex items-start gap-3 text-xs text-slate-400">
        <ShieldAlert className="w-4 h-4 text-emerald-400 mt-0.5 shrink-0" />
        <span>{t.recorderNotice}</span>
      </div>
    </div>
  );
};
