import React, { useState, useRef, useEffect } from 'react';
import { translations } from '../utils/translations';
import { Language } from '../types';
import { sounds } from '../utils/audio';
import { measurePing, performSafeRamClean } from '../utils/systemDiagnostics';
import {
  Terminal,
  Play,
  Square,
  Trash2,
  CheckCircle2,
  AlertCircle,
  ShieldCheck,
  Cpu,
  Activity,
  HardDrive,
  Volume2,
} from 'lucide-react';

interface ScriptRunnerProProps {
  language: Language;
}

interface ScriptItem {
  id: string;
  name: string;
  desc: string;
  permissions: string;
  icon: React.ElementType;
}

export const ScriptRunnerPro: React.FC<ScriptRunnerProProps> = ({ language }) => {
  const t = translations[language];

  const [selectedScript, setSelectedScript] = useState<string>('dns');
  const [isRunning, setIsRunning] = useState<boolean>(false);
  const [logs, setLogs] = useState<string[]>([
    '[INIT] MINA Advanced Diagnostic Engine v2.5 initialized.',
    '[STATUS] Ready to execute safe diagnostic scripts.',
    '[NOTE] All scripts run within secure client sandbox. Root commands excluded.',
  ]);

  const abortControllerRef = useRef<boolean>(false);
  const consoleBottomRef = useRef<HTMLDivElement>(null);

  const scripts: ScriptItem[] = [
    {
      id: 'dns',
      name: t.script1Name,
      desc: t.script1Desc,
      permissions: 'Network Access',
      icon: Activity,
    },
    {
      id: 'heap',
      name: t.script2Name,
      desc: t.script2Desc,
      permissions: 'Memory Buffer',
      icon: Cpu,
    },
    {
      id: 'touch',
      name: t.script3Name,
      desc: t.script3Desc,
      permissions: 'Input Sampling',
      icon: Terminal,
    },
    {
      id: 'gpu',
      name: t.script4Name,
      desc: t.script4Desc,
      permissions: 'WebGL Context',
      icon: HardDrive,
    },
    {
      id: 'audio',
      name: t.script5Name,
      desc: t.script5Desc,
      permissions: 'Audio Output',
      icon: Volume2,
    },
  ];

  useEffect(() => {
    consoleBottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [logs]);

  const appendLog = (msg: string) => {
    const time = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    setLogs((prev) => [...prev, `[${time}] ${msg}`]);
  };

  const runScript = async () => {
    sounds.playClick();
    setIsRunning(true);
    abortControllerRef.current = false;

    const current = scripts.find((s) => s.id === selectedScript);
    appendLog(`>>> STARTING SCRIPT: ${current?.name}`);
    appendLog(`>>> PERMISSION CHECK: ${current?.permissions} GRANTED.`);

    if (selectedScript === 'dns') {
      appendLog('Connecting to global CDN gateway...');
      const p1 = await measurePing();
      if (abortControllerRef.current) return;
      appendLog(p1 !== null ? `Probe 1 Roundtrip: ${p1}ms` : 'Probe 1: Direct socket response timeout');

      await new Promise((r) => setTimeout(r, 400));
      if (abortControllerRef.current) return;
      const p2 = await measurePing();
      appendLog(p2 !== null ? `Probe 2 Roundtrip: ${p2}ms` : 'Probe 2: Direct socket response timeout');

      await new Promise((r) => setTimeout(r, 400));
      if (abortControllerRef.current) return;
      const p3 = await measurePing();
      appendLog(p3 !== null ? `Probe 3 Roundtrip: ${p3}ms` : 'Probe 3: Direct socket response timeout');

      const valid = [p1, p2, p3].filter((p): p is number => p !== null);
      if (valid.length > 0) {
        const avg = Math.round(valid.reduce((a, b) => a + b, 0) / valid.length);
        appendLog(`[REAL DATA] Average Real Ping: ${avg}ms (Calculated from ${valid.length} real network requests)`);
      } else {
        appendLog('[NOTICE] Network connection sandboxed or host unreachable.');
      }
    } else if (selectedScript === 'heap') {
      appendLog('Triggering safe CacheStorage purge and heap analysis...');
      const cleanResult = await performSafeRamClean();
      if (abortControllerRef.current) return;
      appendLog(`Cache Buckets Deleted: ${cleanResult.cachesDeleted}`);
      appendLog(`JS Heap Before: ${cleanResult.beforeMB} MB`);
      appendLog(`JS Heap After: ${cleanResult.afterMB} MB`);
      appendLog(`[REAL DATA] Memory Freed: ${cleanResult.freedMB} MB`);
    } else if (selectedScript === 'touch') {
      appendLog('Reading hardware input sampling characteristics...');
      await new Promise((r) => setTimeout(r, 300));
      if (abortControllerRef.current) return;
      appendLog(`Max Multi-Touch Points: ${navigator.maxTouchPoints || 1}`);
      appendLog(`Device Pixel Ratio (DPR): ${window.devicePixelRatio}x`);
      appendLog(`Hardware Concurrency: ${navigator.hardwareConcurrency || 'Unavailable'} logical cores`);
      appendLog(`Pointer Event Support: ${'PointerEvent' in window ? 'Active' : 'Basic Touch'}`);
      appendLog('[REAL DATA] Hardware input characteristics queried directly from browser/OS.');
    } else if (selectedScript === 'gpu') {
      appendLog('Initializing real WebGL rendering context...');
      const canvas = document.createElement('canvas');
      const gl = canvas.getContext('webgl') || canvas.getContext('experimental-webgl');
      if (gl && gl instanceof WebGLRenderingContext) {
        const dbg = gl.getExtension('WEBGL_debug_renderer_info');
        const vendor = dbg ? gl.getParameter(dbg.UNMASKED_VENDOR_WEBGL) : 'Standard WebGL';
        const renderer = dbg ? gl.getParameter(dbg.UNMASKED_RENDERER_WEBGL) : 'Standard Renderer';
        appendLog(`GPU Vendor: ${vendor}`);
        appendLog(`GPU Renderer: ${renderer}`);
        appendLog(`Max Texture Size: ${gl.getParameter(gl.MAX_TEXTURE_SIZE)}px`);
        appendLog(`Max Vertex Attributes: ${gl.getParameter(gl.MAX_VERTEX_ATTRIBS)}`);
        appendLog('[REAL DATA] WebGL 3D hardware pipeline validated directly from GPU context.');
      } else {
        appendLog('[NOTICE] WebGL context hardware acceleration not available in this environment.');
      }
    } else if (selectedScript === 'audio') {
      appendLog('Initializing Web Audio API engine...');
      try {
        const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
        if (AudioCtx) {
          const ctx = new AudioCtx();
          appendLog(`Audio Sample Rate: ${ctx.sampleRate} Hz`);
          appendLog(`Audio State: ${ctx.state}`);
          appendLog(`Base Latency: ${ctx.baseLatency ? (ctx.baseLatency * 1000).toFixed(1) + 'ms' : 'Hardware Direct'}`);
          sounds.playClick();
          ctx.close();
          appendLog('[REAL DATA] Low-latency game sound driver verified directly.');
        } else {
          appendLog('[NOTICE] Web Audio API unsupported on this browser.');
        }
      } catch (err: unknown) {
        appendLog(`Audio probe notice: ${err instanceof Error ? err.message : 'Protected'}`);
      }
    }

    sounds.playCleanSuccess();
    setIsRunning(false);
  };

  const stopScript = () => {
    sounds.playBodyHit();
    abortControllerRef.current = true;
    setIsRunning(false);
    appendLog('[ABORT] Script terminated by user.');
  };

  const clearConsole = () => {
    sounds.playClick();
    setLogs(['[CLEARED] Console output reset.']);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div>
        <h1 className="text-xl sm:text-2xl font-black text-white font-gaming flex items-center gap-2">
          <Terminal className="w-6 h-6 text-purple-400" />
          <span>{t.scriptRunnerTitle}</span>
        </h1>
        <p className="text-xs text-slate-400 mt-1">
          {language === 'si'
            ? 'ආරක්ෂිත Client-Side Hardware සහ Network Diagnostics ක්‍රියාත්මක කරන පද්ධතිය'
            : 'Safe diagnostic execution terminal without risky root commands'}
        </p>
      </div>

      {/* Script Selection & Details */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Script List */}
        <div className="space-y-2">
          {scripts.map((script) => {
            const Icon = script.icon;
            const isSelected = selectedScript === script.id;
            return (
              <button
                key={script.id}
                onClick={() => {
                  sounds.playClick();
                  setSelectedScript(script.id);
                }}
                className={`w-full p-3.5 rounded-2xl border text-left transition-all cursor-pointer flex items-center gap-3 ${
                  isSelected
                    ? 'bg-purple-950/80 border-purple-500 shadow-lg shadow-purple-950/40 text-purple-200'
                    : 'bg-slate-900/80 border-slate-800 hover:border-slate-700 text-slate-300'
                }`}
              >
                <div
                  className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                    isSelected ? 'bg-purple-500 text-slate-950' : 'bg-slate-950 text-purple-400'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                </div>
                <div className="truncate">
                  <div className="text-xs font-gaming font-bold truncate text-white">
                    {script.name}
                  </div>
                  <div className="text-[10px] text-slate-500 font-mono">
                    Perm: {script.permissions}
                  </div>
                </div>
              </button>
            );
          })}
        </div>

        {/* Script Details & Execution Controls */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-6 flex flex-col justify-between shadow-xl">
          <div>
            <div className="flex items-center justify-between mb-3">
              <span className="text-[10px] font-mono uppercase px-2.5 py-0.5 rounded bg-purple-950 text-purple-300 border border-purple-500/30">
                Safe Diagnostic Sandbox
              </span>
              <span className="text-xs text-emerald-400 font-mono flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>Non-Destructive</span>
              </span>
            </div>

            {scripts.find((s) => s.id === selectedScript) && (
              <>
                <h2 className="text-lg font-bold font-gaming text-white mb-1">
                  {scripts.find((s) => s.id === selectedScript)?.name}
                </h2>
                <p className="text-xs text-slate-300 leading-relaxed mb-4">
                  {scripts.find((s) => s.id === selectedScript)?.desc}
                </p>
              </>
            )}

            <div className="p-3 rounded-xl bg-slate-950 border border-slate-850 text-xs text-slate-400 font-mono mb-4">
              Requires: <strong className="text-purple-300">{scripts.find((s) => s.id === selectedScript)?.permissions}</strong> (Safe standard web sandbox permission)
            </div>
          </div>

          <div className="flex gap-3">
            {!isRunning ? (
              <button
                onClick={runScript}
                className="flex-1 py-3 px-5 rounded-xl bg-gradient-to-r from-purple-500 to-indigo-600 text-white font-gaming font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg shadow-purple-950/50 hover:brightness-110 active:scale-95 cursor-pointer"
              >
                <Play className="w-4 h-4 fill-current" />
                <span>{t.runScript}</span>
              </button>
            ) : (
              <button
                onClick={stopScript}
                className="flex-1 py-3 px-5 rounded-xl bg-red-600 hover:bg-red-700 text-white font-gaming font-bold text-xs sm:text-sm flex items-center justify-center gap-2 active:scale-95 cursor-pointer"
              >
                <Square className="w-4 h-4 fill-current" />
                <span>{t.stopScript}</span>
              </button>
            )}

            <button
              onClick={clearConsole}
              className="px-4 py-3 rounded-xl bg-slate-950 hover:bg-slate-800 border border-slate-800 text-xs text-slate-400 hover:text-white flex items-center gap-1.5 cursor-pointer"
            >
              <Trash2 className="w-4 h-4" />
              <span>{t.clearConsole}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Terminal Output Console */}
      <div className="bg-slate-950 border border-purple-500/30 rounded-2xl p-4 font-mono text-xs shadow-2xl overflow-hidden">
        <div className="flex items-center justify-between pb-2 mb-3 border-b border-slate-800 text-slate-400 text-[11px]">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-red-500" />
            <span className="w-2.5 h-2.5 rounded-full bg-amber-500" />
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
            <span className="ml-2 font-bold text-slate-300">{t.scriptConsole}</span>
          </div>
          <span className="text-[10px] text-purple-400">bash / zsh simulated sandbox</span>
        </div>

        <div className="h-56 overflow-y-auto space-y-1 text-slate-300">
          {logs.map((log, index) => {
            const isSuccess = log.includes('[SUCCESS]');
            const isError = log.includes('[ERROR]') || log.includes('[ABORT]');
            const isCmd = log.includes('>>>');
            return (
              <div
                key={index}
                className={`leading-relaxed ${
                  isSuccess
                    ? 'text-emerald-400 font-bold'
                    : isError
                    ? 'text-red-400 font-bold'
                    : isCmd
                    ? 'text-cyan-400 font-semibold'
                    : 'text-slate-300'
                }`}
              >
                {log}
              </div>
            );
          })}
          <div ref={consoleBottomRef} />
        </div>
      </div>

      {/* Safety Notice */}
      <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 flex items-start gap-3 text-xs text-slate-400">
        <ShieldCheck className="w-4 h-4 text-purple-400 mt-0.5 shrink-0" />
        <span>{t.scriptNotice}</span>
      </div>
    </div>
  );
};
