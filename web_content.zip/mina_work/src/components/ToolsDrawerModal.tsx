import React from 'react';
import { translations } from '../utils/translations';
import { Language } from '../types';
import { sounds } from '../utils/audio';
import {
  X,
  LayoutDashboard,
  Smartphone,
  Cpu,
  Activity,
  Gauge,
  Flame,
  Target,
  Sliders,
  Maximize2,
  BookOpen,
  Terminal,
  ThermometerSnowflake,
  HardDrive,
  Wifi,
  Video,
  History,
  Crosshair,
  Bell,
  User,
} from 'lucide-react';

interface ToolsDrawerModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
  activeTab: string;
  onSelectTab: (tab: string) => void;
}

export const ToolsDrawerModal: React.FC<ToolsDrawerModalProps> = ({
  isOpen,
  onClose,
  language,
  activeTab,
  onSelectTab,
}) => {
  if (!isOpen) return null;
  const t = translations[language];

  const tools = [
    { id: 'dashboard', name: t.tabDashboard, icon: LayoutDashboard, category: 'Core' },
    { id: 'fps', name: t.tabFps, icon: Gauge, category: 'Hardware' },
    { id: 'device', name: t.tabDevice, icon: Smartphone, category: 'Hardware' },
    { id: 'ram', name: t.tabRam, icon: Cpu, category: 'Hardware' },
    { id: 'ping', name: t.tabPing, icon: Activity, category: 'Network' },
    { id: 'wifi', name: t.tabWifi, icon: Wifi, category: 'Network' },
    { id: 'freefire', name: t.tabFreeFire, icon: Flame, category: 'Gaming' },
    { id: 'aim', name: t.tabAimTrainer, icon: Target, category: 'Gaming' },
    { id: 'sens', name: t.tabSens, icon: Sliders, category: 'Gaming' },
    { id: 'hud', name: t.tabHud, icon: Maximize2, category: 'Gaming' },
    { id: 'crosshair', name: t.tabCrosshair, icon: Crosshair, category: 'Gaming' },
    { id: 'devoptions', name: t.tabDevOptions, icon: BookOpen, category: 'System' },
    { id: 'scripts', name: t.tabScripts, icon: Terminal, category: 'System' },
    { id: 'cooling', name: t.tabCooling, icon: ThermometerSnowflake, category: 'Hardware' },
    { id: 'storage', name: t.tabStorage, icon: HardDrive, category: 'Hardware' },
    { id: 'recorder', name: t.tabRecorder, icon: Video, category: 'Media' },
    { id: 'sessions', name: t.tabSessions, icon: History, category: 'Stats' },
    { id: 'notifications', name: t.tabNotifications, icon: Bell, category: 'System' },
    { id: 'profile', name: t.tabProfile, icon: User, category: 'User' },
  ];

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto flex items-end sm:items-center justify-center bg-black/80 backdrop-blur-sm p-0 sm:p-4">
      <div className="w-full sm:max-w-2xl bg-slate-900 border-t sm:border border-cyan-500/30 rounded-t-3xl sm:rounded-3xl max-h-[85vh] flex flex-col shadow-2xl overflow-hidden my-auto">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="font-gaming font-bold text-base sm:text-lg text-white">
              {language === 'si' ? 'සියලුම Gaming මෙවලම්' : 'All Gaming Utilities'}
            </span>
            <span className="text-xs px-2 py-0.5 rounded bg-cyan-950 text-cyan-400 font-mono">
              {tools.length} Tools
            </span>
          </div>
          <button
            onClick={() => {
              sounds.playClick();
              onClose();
            }}
            className="w-8 h-8 rounded-full bg-slate-800 text-slate-300 hover:text-white flex items-center justify-center cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tools Grid */}
        <div className="p-4 sm:p-5 overflow-y-auto grid grid-cols-2 sm:grid-cols-3 gap-2.5">
          {tools.map((tool) => {
            const Icon = tool.icon;
            const isActive = activeTab === tool.id;
            return (
              <button
                key={tool.id}
                onClick={() => {
                  sounds.playClick();
                  onSelectTab(tool.id);
                  onClose();
                }}
                className={`flex items-center gap-3 p-3 rounded-2xl border text-left transition-all cursor-pointer ${
                  isActive
                    ? 'bg-cyan-950/80 border-cyan-500 text-cyan-300 shadow-md shadow-cyan-500/20'
                    : 'bg-slate-950/60 border-slate-800/80 hover:border-slate-700 text-slate-300 hover:bg-slate-800/60'
                }`}
              >
                <div
                  className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                    isActive ? 'bg-cyan-500 text-slate-950' : 'bg-slate-900 text-cyan-400'
                  }`}
                >
                  <Icon className="w-5 h-5" />
                </div>
                <div className="truncate">
                  <div className="text-xs font-semibold truncate text-slate-100">{tool.name}</div>
                  <div className="text-[10px] text-slate-500 font-mono">{tool.category}</div>
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
