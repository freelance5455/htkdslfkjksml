import React from 'react';
import { translations } from '../utils/translations';
import { Language, CrosshairConfig } from '../types';
import { sounds } from '../utils/audio';
import {
  Crosshair,
  RotateCcw,
  Sparkles,
  ShieldCheck,
  Check,
} from 'lucide-react';

interface CrosshairDesignerProps {
  language: Language;
  crosshair: CrosshairConfig;
  onUpdateCrosshair: (crosshair: CrosshairConfig) => void;
}

export const CrosshairDesigner: React.FC<CrosshairDesignerProps> = ({
  language,
  crosshair,
  onUpdateCrosshair,
}) => {
  const t = translations[language];

  const shapes = [
    { id: 'dot', label: 'Minimal Dot' },
    { id: 'classic', label: 'Classic Cross' },
    { id: 'circleDot', label: 'Circle & Dot' },
    { id: 'chevron', label: 'Tactical Chevron' },
    { id: 'sniper', label: 'Sniper Hollow' },
    { id: 'diamond', label: 'Diamond Reticle' },
  ] as const;

  const colors = [
    { id: '#00f0ff', name: 'Cyan Neon' },
    { id: '#10b981', name: 'Emerald' },
    { id: '#ef4444', name: 'Laser Red' },
    { id: '#f59e0b', name: 'Amber' },
    { id: '#ffffff', name: 'Pure White' },
    { id: '#a855f7', name: 'Violet' },
  ];

  const handleReset = () => {
    sounds.playClick();
    onUpdateCrosshair({
      type: 'dot',
      size: 20,
      color: '#00f0ff',
      opacity: 0.9,
      borderWidth: 2,
    });
  };

  const renderReticle = () => {
    const { type, size, color, opacity, borderWidth } = crosshair;
    const style: React.CSSProperties = { opacity };

    switch (type) {
      case 'dot':
        return (
          <div
            style={{
              width: `${size / 2}px`,
              height: `${size / 2}px`,
              backgroundColor: color,
              boxShadow: `0 0 10px ${color}`,
              ...style,
            }}
            className="rounded-full"
          />
        );

      case 'classic':
        return (
          <div style={{ width: `${size * 2}px`, height: `${size * 2}px`, ...style }} className="relative">
            {/* Horizontal line */}
            <div
              style={{
                height: `${borderWidth}px`,
                backgroundColor: color,
                boxShadow: `0 0 8px ${color}`,
              }}
              className="absolute top-1/2 left-0 right-0 -translate-y-1/2"
            />
            {/* Vertical line */}
            <div
              style={{
                width: `${borderWidth}px`,
                backgroundColor: color,
                boxShadow: `0 0 8px ${color}`,
              }}
              className="absolute left-1/2 top-0 bottom-0 -translate-x-1/2"
            />
            {/* Center dot */}
            <div
              style={{ width: `${borderWidth * 2}px`, height: `${borderWidth * 2}px`, backgroundColor: color }}
              className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 rounded-full"
            />
          </div>
        );

      case 'circleDot':
        return (
          <div
            style={{
              width: `${size * 1.8}px`,
              height: `${size * 1.8}px`,
              borderColor: color,
              borderWidth: `${borderWidth}px`,
              boxShadow: `0 0 10px ${color}`,
              ...style,
            }}
            className="rounded-full border flex items-center justify-center"
          >
            <div
              style={{ width: `${borderWidth * 2}px`, height: `${borderWidth * 2}px`, backgroundColor: color }}
              className="rounded-full"
            />
          </div>
        );

      case 'chevron':
        return (
          <div style={{ width: `${size * 1.5}px`, height: `${size * 1.5}px`, ...style }} className="flex flex-col items-center justify-center">
            <div
              style={{
                width: `${size}px`,
                height: `${size}px`,
                borderLeft: `${borderWidth * 1.5}px solid ${color}`,
                borderBottom: `${borderWidth * 1.5}px solid ${color}`,
                transform: 'rotate(-45deg)',
                boxShadow: `0 0 8px ${color}`,
              }}
            />
          </div>
        );

      case 'diamond':
        return (
          <div
            style={{
              width: `${size * 1.4}px`,
              height: `${size * 1.4}px`,
              borderColor: color,
              borderWidth: `${borderWidth}px`,
              transform: 'rotate(45deg)',
              boxShadow: `0 0 10px ${color}`,
              ...style,
            }}
            className="border flex items-center justify-center"
          >
            <div
              style={{ width: `${borderWidth * 2}px`, height: `${borderWidth * 2}px`, backgroundColor: color }}
              className="rounded-full"
            />
          </div>
        );

      default:
        return (
          <div
            style={{
              width: `${size * 1.6}px`,
              height: `${size * 1.6}px`,
              borderColor: color,
              borderWidth: `${borderWidth}px`,
              boxShadow: `0 0 10px ${color}`,
              ...style,
            }}
            className="rounded-full border flex items-center justify-center"
          >
            <div style={{ width: '40%', height: '1px', backgroundColor: color }} className="absolute" />
            <div style={{ height: '40%', width: '1px', backgroundColor: color }} className="absolute" />
          </div>
        );
    }
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-white font-gaming flex items-center gap-2">
            <Crosshair className="w-6 h-6 text-cyan-400" />
            <span>{t.crosshairTitle}</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            {language === 'si'
              ? 'Aim Trainer සහ Reflex පුහුණුව සඳහා Custom Reticle නිර්මාණය කරන්න'
              : 'Design custom precision reticles for in-app muscle memory training'}
          </p>
        </div>

        <button
          onClick={handleReset}
          className="self-start sm:self-auto p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-white transition-all cursor-pointer"
          title="Reset Crosshair"
        >
          <RotateCcw className="w-4 h-4" />
        </button>
      </div>

      {/* Crosshair Interactive Canvas Preview */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 flex flex-col items-center justify-center relative overflow-hidden shadow-2xl">
        <div className="text-xs text-slate-400 font-mono mb-4">{t.preview}</div>

        <div className="relative w-full max-w-md h-64 sm:h-72 rounded-2xl bg-slate-950 border border-cyan-500/20 overflow-hidden flex items-center justify-center select-none gaming-grid-bg shadow-inner">
          {/* Subtle concentric training rings */}
          <div className="w-48 h-48 rounded-full border border-slate-800/80 pointer-events-none absolute" />
          <div className="w-32 h-32 rounded-full border border-slate-800/60 pointer-events-none absolute" />
          <div className="w-16 h-16 rounded-full border border-slate-800/40 pointer-events-none absolute" />

          {/* Rendered Reticle */}
          {renderReticle()}
        </div>
      </div>

      {/* Shape Selector */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg space-y-3">
        <span className="text-xs font-gaming font-bold text-slate-200">
          {t.crosshairShape}
        </span>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
          {shapes.map((s) => (
            <button
              key={s.id}
              onClick={() => {
                sounds.playClick();
                onUpdateCrosshair({ ...crosshair, type: s.id });
              }}
              className={`p-3 rounded-xl text-xs font-semibold text-center border transition-all cursor-pointer ${
                crosshair.type === s.id
                  ? 'bg-cyan-950 border-cyan-500 text-cyan-300 font-bold shadow-md shadow-cyan-950/40'
                  : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200'
              }`}
            >
              {s.label}
            </button>
          ))}
        </div>
      </div>

      {/* Color & Size Controls */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Colors */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-3">
          <span className="text-xs font-gaming font-bold text-slate-200">
            {t.crosshairColor}
          </span>
          <div className="flex flex-wrap gap-2.5">
            {colors.map((c) => (
              <button
                key={c.id}
                onClick={() => {
                  sounds.playClick();
                  onUpdateCrosshair({ ...crosshair, color: c.id });
                }}
                style={{ backgroundColor: c.id }}
                className={`w-9 h-9 rounded-xl flex items-center justify-center transition-transform cursor-pointer ${
                  crosshair.color === c.id ? 'scale-110 ring-2 ring-white shadow-lg' : 'opacity-80 hover:opacity-100'
                }`}
                title={c.name}
              >
                {crosshair.color === c.id && <Check className="w-4 h-4 text-black stroke-[3]" />}
              </button>
            ))}
          </div>
        </div>

        {/* Sliders */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4">
          <div className="space-y-1">
            <div className="flex justify-between text-xs font-semibold text-slate-300">
              <span>{t.crosshairSize}</span>
              <span className="font-mono text-cyan-400">{crosshair.size}px</span>
            </div>
            <input
              type="range"
              min="10"
              max="45"
              value={crosshair.size}
              onChange={(e) => onUpdateCrosshair({ ...crosshair, size: parseInt(e.target.value) })}
              className="w-full h-2 rounded-lg bg-slate-950 appearance-none cursor-pointer accent-cyan-400"
            />
          </div>

          <div className="space-y-1">
            <div className="flex justify-between text-xs font-semibold text-slate-300">
              <span>{t.crosshairOpacity}</span>
              <span className="font-mono text-cyan-400">{Math.round(crosshair.opacity * 100)}%</span>
            </div>
            <input
              type="range"
              min="0.3"
              max="1.0"
              step="0.05"
              value={crosshair.opacity}
              onChange={(e) => onUpdateCrosshair({ ...crosshair, opacity: parseFloat(e.target.value) })}
              className="w-full h-2 rounded-lg bg-slate-950 appearance-none cursor-pointer accent-cyan-400"
            />
          </div>
        </div>
      </div>

      {/* Safety Notice */}
      <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 flex items-start gap-3 text-xs text-slate-400">
        <ShieldCheck className="w-4 h-4 text-cyan-400 mt-0.5 shrink-0" />
        <span>{t.crosshairNotice}</span>
      </div>
    </div>
  );
};
