import React, { useState, useEffect, useRef } from 'react';
import { translations } from '../utils/translations';
import { Language, PingDataPoint } from '../types';
import { sounds } from '../utils/audio';
import { measurePing } from '../utils/systemDiagnostics';
import {
  Activity,
  Play,
  Square,
  Server,
  TrendingDown,
  TrendingUp,
  History,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
} from 'lucide-react';

interface LivePingMonitorProProps {
  language: Language;
  soundEnabled: boolean;
  onLivePingUpdate: (ping: number) => void;
}

export const LivePingMonitorPro: React.FC<LivePingMonitorProProps> = ({
  language,
  soundEnabled,
  onLivePingUpdate,
}) => {
  const t = translations[language];
  const [isRunning, setIsRunning] = useState(false);
  const [currentPing, setCurrentPing] = useState<number | null>(null);
  const [history, setHistory] = useState<PingDataPoint[]>([]);
  const isRunningRef = useRef(false);

  const startPingMonitor = () => {
    sounds.playClick();
    setIsRunning(true);
    isRunningRef.current = true;
  };

  const stopPingMonitor = () => {
    sounds.playClick();
    setIsRunning(false);
    isRunningRef.current = false;
  };

  useEffect(() => {
    if (!isRunning) return;

    let timer: NodeJS.Timeout;
    const probe = async () => {
      if (!isRunningRef.current) return;
      const latency = await measurePing();

      if (latency !== null) {
        setCurrentPing(latency);
        onLivePingUpdate(latency);

        if (soundEnabled) {
          sounds.playPingBeep(latency);
        }

        const now = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
        setHistory((prev) => [...prev.slice(-20), { time: now, latency }]);
      } else {
        setCurrentPing(null);
      }

      if (isRunningRef.current) {
        timer = setTimeout(probe, 1200);
      }
    };

    probe();

    return () => {
      clearTimeout(timer);
    };
  }, [isRunning, soundEnabled, onLivePingUpdate]);

  // Statistics
  const latencies = history.map((h) => h.latency);
  const minPing = latencies.length ? Math.min(...latencies) : currentPing;
  const maxPing = latencies.length ? Math.max(...latencies) : currentPing;
  const avgPing = latencies.length ? Math.round(latencies.reduce((a, b) => a + b, 0) / latencies.length) : currentPing;

  // Chart coordinates
  const chartHeight = 110;
  const chartWidth = 400;
  const maxScale = Math.max(120, (maxPing || 50) + 20);
  const points = history.map((pt, i) => {
    const x = (i / Math.max(1, history.length - 1)) * chartWidth;
    const y = chartHeight - (pt.latency / maxScale) * chartHeight;
    return `${x},${Math.max(5, Math.min(chartHeight - 5, y))}`;
  });
  const pathD = points.length > 1 ? `M ${points.join(' L ')}` : '';
  const areaD = points.length > 1 ? `M 0,${chartHeight} L ${points.join(' L ')} L ${chartWidth},${chartHeight} Z` : '';

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-white font-gaming flex items-center gap-2">
            <Activity className="w-6 h-6 text-emerald-400" />
            <span>{t.pingTitle}</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            {language === 'si'
              ? 'Gaming Servers වෙත Roundtrip HTTP Latency සජීවීව මනිනු ලැබේ (සැබෑ දත්ත පමණි)'
              : 'Real-time roundtrip latency to global edge gateways'}
          </p>
        </div>

        {/* Start / Stop Toggle */}
        <button
          onClick={isRunning ? stopPingMonitor : startPingMonitor}
          className={`self-start sm:self-auto px-5 py-2.5 rounded-xl font-gaming font-bold text-xs sm:text-sm flex items-center gap-2 shadow-lg transition-all cursor-pointer ${
            isRunning
              ? 'bg-red-600 hover:bg-red-700 text-white shadow-red-950/50'
              : 'bg-gradient-to-r from-emerald-500 to-cyan-500 text-slate-950 shadow-emerald-950/50 hover:brightness-110 active:scale-[0.98]'
          }`}
        >
          {isRunning ? <Square className="w-4 h-4 fill-current" /> : <Play className="w-4 h-4 fill-current" />}
          <span>{isRunning ? t.stopPing : t.startPing}</span>
        </button>
      </div>

      {/* Main Live Ping Display Card */}
      <div className="bg-slate-900 border border-emerald-500/30 rounded-3xl p-6 text-center relative overflow-hidden shadow-2xl">
        <div className="flex items-center justify-center gap-2 text-xs text-emerald-400 mb-2 font-mono">
          <Server className="w-3.5 h-3.5" />
          <span>Server: Cloudflare Anycast CDN (Singapore / Colombo Edge)</span>
        </div>

        <div className="text-6xl sm:text-7xl font-black font-gaming text-white tabular-nums tracking-tight my-2 flex items-baseline justify-center gap-2">
          {currentPing !== null ? (
            <>
              <span className={currentPing < 60 ? 'text-emerald-400' : currentPing < 110 ? 'text-cyan-400' : 'text-amber-400'}>
                {currentPing}
              </span>
              <span className="text-xl text-slate-400 font-sans font-medium">ms</span>
            </>
          ) : (
            <span className="text-3xl text-slate-400 font-sans font-medium">
              {isRunning ? 'Pinging...' : (language === 'si' ? 'Ping අරඹන්න' : 'Ready to Ping')}
            </span>
          )}
        </div>

        {currentPing !== null && (
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-slate-950 border border-slate-800 text-xs font-semibold mb-6">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
            <span className="text-slate-200">
              {currentPing < 55 ? t.excellentPing : currentPing < 100 ? t.goodPing : t.highPing}
            </span>
          </div>
        )}

        {/* SVG Live Latency Waveform */}
        <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 mb-6">
          <div className="flex items-center justify-between text-[11px] text-slate-400 font-mono mb-2">
            <span>{t.pingGraph}</span>
            <span className="text-emerald-400">Scale: 0 - {maxScale} ms</span>
          </div>

          <div className="w-full h-32 relative overflow-hidden flex items-center justify-center">
            {history.length > 1 ? (
              <svg
                className="w-full h-full"
                viewBox={`0 0 ${chartWidth} ${chartHeight}`}
                preserveAspectRatio="none"
              >
                <defs>
                  <linearGradient id="pingGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#10b981" stopOpacity="0.4" />
                    <stop offset="100%" stopColor="#10b981" stopOpacity="0.0" />
                  </linearGradient>
                </defs>

                <line x1="0" y1={chartHeight * 0.25} x2={chartWidth} y2={chartHeight * 0.25} stroke="#1e293b" strokeDasharray="3 3" />
                <line x1="0" y1={chartHeight * 0.5} x2={chartWidth} y2={chartHeight * 0.5} stroke="#1e293b" strokeDasharray="3 3" />
                <line x1="0" y1={chartHeight * 0.75} x2={chartWidth} y2={chartHeight * 0.75} stroke="#1e293b" strokeDasharray="3 3" />

                {areaD && <path d={areaD} fill="url(#pingGrad)" />}
                {pathD && <path d={pathD} fill="none" stroke="#10b981" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />}
              </svg>
            ) : (
              <span className="text-xs text-slate-500 font-mono">
                {language === 'si' ? 'ප්‍රස්ථාරය සටහන් වීමට Ping Start කරන්න' : 'Start ping to generate live telemetry wave'}
              </span>
            )}
          </div>
        </div>

        {/* Min / Max / Avg stats row */}
        <div className="grid grid-cols-3 gap-3 text-center">
          <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800">
            <div className="text-[10px] text-slate-400 font-mono uppercase flex items-center justify-center gap-1">
              <TrendingDown className="w-3 h-3 text-emerald-400" />
              <span>{t.minPing}</span>
            </div>
            <div className="text-lg font-bold text-emerald-400 font-gaming mt-0.5 tabular-nums">
              {minPing !== null ? `${minPing} ms` : '--'}
            </div>
          </div>

          <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800">
            <div className="text-[10px] text-slate-400 font-mono uppercase flex items-center justify-center gap-1">
              <Activity className="w-3 h-3 text-cyan-400" />
              <span>{t.avgPing}</span>
            </div>
            <div className="text-lg font-bold text-cyan-400 font-gaming mt-0.5 tabular-nums">
              {avgPing !== null ? `${avgPing} ms` : '--'}
            </div>
          </div>

          <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800">
            <div className="text-[10px] text-slate-400 font-mono uppercase flex items-center justify-center gap-1">
              <TrendingUp className="w-3 h-3 text-amber-400" />
              <span>{t.maxPing}</span>
            </div>
            <div className="text-lg font-bold text-amber-400 font-gaming mt-0.5 tabular-nums">
              {maxPing !== null ? `${maxPing} ms` : '--'}
            </div>
          </div>
        </div>
      </div>

      {/* History Table */}
      {history.length > 0 && (
        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 shadow-lg">
          <div className="flex items-center gap-2 mb-4">
            <History className="w-4 h-4 text-emerald-400" />
            <h2 className="font-gaming font-bold text-sm text-slate-200">
              {t.pingHistory}
            </h2>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {history.slice(-8).reverse().map((pt, idx) => (
              <div
                key={idx}
                className="p-2.5 rounded-xl bg-slate-950 border border-slate-800/80 flex items-center justify-between text-xs"
              >
                <span className="font-mono text-slate-400 text-[11px]">{pt.time}</span>
                <span
                  className={`font-mono font-bold tabular-nums ${
                    pt.latency < 50 ? 'text-emerald-400' : pt.latency < 95 ? 'text-cyan-400' : 'text-amber-400'
                  }`}
                >
                  {pt.latency} ms
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Real Ping Policy */}
      <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 flex items-start gap-3 text-xs text-slate-400">
        <ShieldCheck className="w-4 h-4 text-emerald-400 mt-0.5 shrink-0" />
        <span>
          {language === 'si'
            ? 'සත්‍ය Ping සහතිකය: මෙහි කිසිදු Fake Ping Randomizer එකක් භාවිත නොවේ. සෑම තත්පරයකදීම සැබෑ Network Packet එකක් යවා Roundtrip කාලය මනිනු ලැබේ.'
            : 'Integrity: Real network request headers with cache-busting tokens measure actual roundtrip latency.'}
        </span>
      </div>
    </div>
  );
};
