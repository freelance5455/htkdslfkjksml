import React, { useState } from 'react';
import { translations } from '../utils/translations';
import { Language, AppNotification } from '../types';
import { sounds } from '../utils/audio';
import {
  Bell,
  Trash2,
  CheckCircle2,
  AlertTriangle,
  Info,
  ShieldCheck,
  Send,
} from 'lucide-react';

interface NotificationCenterProps {
  language: Language;
  notifications: AppNotification[];
  onClearNotifications: () => void;
  onRequestPermission: () => Promise<boolean>;
  onSendTestNotification: () => void;
}

export const NotificationCenter: React.FC<NotificationCenterProps> = ({
  language,
  notifications,
  onClearNotifications,
  onRequestPermission,
  onSendTestNotification,
}) => {
  const t = translations[language];
  const [permissionState, setPermissionState] = useState<string>(
    typeof Notification !== 'undefined' ? Notification.permission : 'default'
  );

  const handleRequest = async () => {
    sounds.playClick();
    const granted = await onRequestPermission();
    setPermissionState(granted ? 'granted' : 'denied');
    if (granted) sounds.playCleanSuccess();
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-white font-gaming flex items-center gap-2">
            <Bell className="w-6 h-6 text-cyan-400" />
            <span>{t.notifTitle}</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            {language === 'si'
              ? 'RAM Cleanup, Ping Alerts, Battery Warnings සහ Gaming Sessions පිළිබඳ දැනුම්දීම්'
              : 'Android System notifications & in-app telemetry dispatch logs'}
          </p>
        </div>

        <div className="flex items-center gap-2">
          {notifications.length > 0 && (
            <button
              onClick={() => {
                sounds.playClick();
                onClearNotifications();
              }}
              className="px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800 text-xs text-slate-400 hover:text-red-400 flex items-center gap-1.5 transition-all cursor-pointer"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>{t.clearNotifs}</span>
            </button>
          )}
        </div>
      </div>

      {/* Permission Request Banner */}
      <div className="p-5 rounded-3xl bg-slate-900 border border-slate-800 shadow-xl flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-3.5 text-center sm:text-left">
          <div className="w-12 h-12 rounded-2xl bg-cyan-950 border border-cyan-500/40 flex items-center justify-center text-cyan-400 shrink-0">
            <Bell className="w-6 h-6" />
          </div>
          <div>
            <div className="font-gaming font-bold text-sm sm:text-base text-white">
              {language === 'si' ? 'Android System Push Notifications' : 'Android System Notifications'}
            </div>
            <div className="text-xs text-slate-400 mt-0.5">
              Status:{' '}
              <span
                className={`font-mono font-bold uppercase ${
                  permissionState === 'granted'
                    ? 'text-emerald-400'
                    : permissionState === 'denied'
                    ? 'text-red-400'
                    : 'text-amber-400'
                }`}
              >
                {permissionState}
              </span>
            </div>
          </div>
        </div>

        <div className="flex gap-2 w-full sm:w-auto">
          {permissionState !== 'granted' && (
            <button
              onClick={handleRequest}
              className="flex-1 sm:flex-none py-2.5 px-4 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-gaming font-bold text-xs flex items-center justify-center gap-1.5 shadow-md shadow-cyan-950/40 cursor-pointer"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>{t.enablePushNotif}</span>
            </button>
          )}

          <button
            onClick={() => {
              sounds.playClick();
              onSendTestNotification();
            }}
            className="flex-1 sm:flex-none py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-gaming font-semibold flex items-center justify-center gap-1.5 cursor-pointer"
          >
            <Send className="w-3.5 h-3.5 text-cyan-400" />
            <span>{language === 'si' ? 'Test Notification එකක් යවන්න' : 'Send Test Alert'}</span>
          </button>
        </div>
      </div>

      {/* Notifications List */}
      <div className="space-y-3">
        {notifications.length === 0 ? (
          <div className="bg-slate-900/60 border border-slate-800 rounded-3xl p-10 text-center text-slate-500 font-mono text-xs">
            <Bell className="w-8 h-8 mx-auto mb-2 opacity-50" />
            <span>{t.noNotifs}</span>
          </div>
        ) : (
          notifications.map((notif) => {
            const isAlert = notif.type === 'alert' || notif.type === 'warning';
            return (
              <div
                key={notif.id}
                className={`p-4 rounded-2xl border transition-all flex items-start gap-3.5 ${
                  isAlert
                    ? 'bg-amber-950/30 border-amber-500/40 text-amber-200'
                    : 'bg-slate-900 border-slate-800 text-slate-200'
                }`}
              >
                <div
                  className={`p-2 rounded-xl shrink-0 ${
                    isAlert ? 'bg-amber-900/40 text-amber-400' : 'bg-slate-950 text-cyan-400'
                  }`}
                >
                  {isAlert ? <AlertTriangle className="w-4 h-4" /> : <Info className="w-4 h-4" />}
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-2">
                    <h3 className="font-gaming font-bold text-sm text-white truncate">
                      {notif.title}
                    </h3>
                    <span className="text-[10px] text-slate-500 font-mono shrink-0">
                      {notif.timestamp}
                    </span>
                  </div>
                  <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                    {notif.message}
                  </p>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Safety Notice */}
      <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 flex items-start gap-3 text-xs text-slate-400">
        <ShieldCheck className="w-4 h-4 text-cyan-400 mt-0.5 shrink-0" />
        <span>
          {language === 'si'
            ? 'සටහන: මෙම පද්ධතිය මඟින් ක්‍රියාත්මක වන්නේ App එකේ සත්‍ය සිදුවීම් සඳහා වන Notifications පමණි. අනවශ්‍ය Spams හෝ දැන්වීම් කිසිවිටෙකත් නොඑවනු ලැබේ.'
            : 'Integrity: Notifications are triggered purely for real in-app events (RAM clean, session starts, battery warnings). No advertising spam.'}
        </span>
      </div>
    </div>
  );
};
