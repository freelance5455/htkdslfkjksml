import React from 'react';
import { translations } from '../utils/translations';
import { Language, DeviceInfo } from '../types';
import { sounds } from '../utils/audio';
import {
  Smartphone,
  Cpu,
  Monitor,
  Activity,
  HardDrive,
  Battery,
  Wifi,
  Layers,
  Sparkles,
  ShieldCheck,
  RotateCw,
} from 'lucide-react';

interface DeviceInformationProProps {
  language: Language;
  deviceInfo: DeviceInfo | null;
  onRefresh: () => void;
}

export const DeviceInformationPro: React.FC<DeviceInformationProProps> = ({
  language,
  deviceInfo,
  onRefresh,
}) => {
  const t = translations[language];

  if (!deviceInfo) {
    return (
      <div className="flex items-center justify-center p-12 text-center text-slate-400">
        <div className="animate-spin w-8 h-8 border-2 border-cyan-400 border-t-transparent rounded-full mb-3" />
        <span className="font-mono text-sm ml-3">Querying Hardware APIs...</span>
      </div>
    );
  }

  const sections = [
    {
      title: language === 'si' ? 'උපාංග සහ පද්ධති තොරතුරු (Device & OS)' : 'Device & OS',
      icon: Smartphone,
      color: 'text-cyan-400',
      items: [
        { label: t.deviceBrand, value: deviceInfo.brand },
        { label: t.deviceModel, value: deviceInfo.model },
        { label: t.platform, value: deviceInfo.platform },
        { label: 'Android / OS Version', value: deviceInfo.androidVersion },
        { label: 'Multi-Touch Support', value: `${deviceInfo.touchPoints} Touch Points` },
      ],
    },
    {
      title: language === 'si' ? 'තිරය සහ ග්‍රැෆික්ස් (Display & GPU)' : 'Display & GPU',
      icon: Monitor,
      color: 'text-blue-400',
      items: [
        { label: t.screenResolution, value: deviceInfo.screenResolution },
        { label: t.screenDensity, value: `${deviceInfo.screenDensity}x DPR` },
        { label: t.refreshRate, value: `${deviceInfo.refreshRate} Hz (Live Measured)` },
        { label: t.gpuVendor, value: deviceInfo.gpuVendor },
        { label: t.gpuRenderer, value: deviceInfo.gpuRenderer },
      ],
    },
    {
      title: language === 'si' ? 'ප්‍රොසෙසරය සහ මතකය (CPU & RAM)' : 'Processor & RAM',
      icon: Cpu,
      color: 'text-emerald-400',
      items: [
        { label: t.cpuCores, value: `${deviceInfo.cpuCores} Logical Cores` },
        { label: t.totalRam, value: `${deviceInfo.totalRamGB} GB` },
        { label: t.usedRam, value: `${deviceInfo.usedRamMB} MB (${deviceInfo.ramUsagePercent}%)` },
        { label: t.availableRam, value: `${deviceInfo.availableRamMB} MB` },
      ],
    },
    {
      title: language === 'si' ? 'ජාලය සහ බැටරිය (Network & Battery)' : 'Network & Battery',
      icon: Wifi,
      color: 'text-amber-400',
      items: [
        { label: 'Network Effective Type', value: deviceInfo.networkType },
        { label: 'Downlink Speed', value: `${deviceInfo.downlinkMbps} Mbps` },
        { label: 'Network RTT Latency', value: `${deviceInfo.rttMs} ms` },
        {
          label: t.batteryStatus,
          value: deviceInfo.batteryLevel !== null
            ? `${deviceInfo.batteryLevel}% (${deviceInfo.isCharging ? 'Charging' : 'Discharging'})`
            : 'Battery Sensor Protected',
        },
        {
          label: 'Storage Available',
          value: deviceInfo.storageAvailableGB !== 'N/A'
            ? `${deviceInfo.storageAvailableGB} GB Free / ${deviceInfo.storageQuotaGB} GB Total`
            : 'Protected System Sandbox',
        },
      ],
    },
  ];

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-white font-gaming flex items-center gap-2">
            <Smartphone className="w-6 h-6 text-cyan-400" />
            <span>{t.deviceInfoTitle}</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            {language === 'si'
              ? 'ඔබගේ දුරකථනයේ සැබෑ Hardware සහ System Metrics'
              : 'Direct hardware queries via WebGL, Navigator, and Battery APIs'}
          </p>
        </div>

        <button
          onClick={() => {
            sounds.playClick();
            onRefresh();
          }}
          className="self-start sm:self-auto px-4 py-2 rounded-xl bg-slate-900 border border-slate-800 hover:border-cyan-500/40 text-xs text-cyan-300 font-semibold flex items-center gap-2 transition-all cursor-pointer"
        >
          <RotateCw className="w-3.5 h-3.5" />
          <span>{language === 'si' ? 'නැවත පරීක්ෂා කරන්න' : 'Re-scan Telemetry'}</span>
        </button>
      </div>

      {/* Grid of Telemetry Sections */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {sections.map((section, idx) => {
          const Icon = section.icon;
          return (
            <div
              key={idx}
              className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 shadow-lg"
            >
              <div className="flex items-center gap-2.5 mb-4 pb-3 border-b border-slate-800/80">
                <div className={`p-2 rounded-xl bg-slate-950 border border-slate-800 ${section.color}`}>
                  <Icon className="w-4 h-4" />
                </div>
                <h2 className="font-gaming font-bold text-sm text-slate-200">
                  {section.title}
                </h2>
              </div>

              <div className="space-y-3">
                {section.items.map((item, itemIdx) => (
                  <div
                    key={itemIdx}
                    className="flex items-center justify-between text-xs py-1.5 border-b border-slate-850/50 last:border-none"
                  >
                    <span className="text-slate-400 font-medium">{item.label}</span>
                    <span className="font-mono text-slate-100 font-semibold text-right truncate max-w-[200px]">
                      {item.value}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>

      {/* Raw User Agent disclosure */}
      <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 text-xs">
        <div className="font-mono text-slate-400 mb-1 font-semibold flex items-center gap-1.5">
          <Layers className="w-3.5 h-3.5 text-cyan-400" />
          <span>System User-Agent String:</span>
        </div>
        <div className="font-mono text-[11px] text-slate-500 break-all select-all">
          {deviceInfo.userAgent}
        </div>
      </div>

      {/* Authentic Data Guarantee */}
      <div className="p-4 rounded-2xl bg-cyan-950/30 border border-cyan-500/20 flex items-start gap-3 text-xs text-slate-300">
        <ShieldCheck className="w-4 h-4 text-cyan-400 mt-0.5 shrink-0" />
        <div>
          <span className="font-bold text-cyan-300">
            {language === 'si' ? '100% සත්‍ය තොරතුරු සහතික කෙරේ: ' : 'Authentic Hardware Guarantee: '}
          </span>
          <span>
            {language === 'si'
              ? 'මෙහි කිසිදු අනුමාන කළ හෝ Fake දත්ත ඇතුළත් නොවේ. ආරක්ෂක සීමාවන් හේතුවෙන් ලබාගත නොහැකි විශේෂිත Sensor දත්ත තිබේ නම් ඒවා "Protected" ලෙස සටහන් වේ.'
              : 'All metrics reflect genuine values reported by your device sandbox without simulated inflation.'}
          </span>
        </div>
      </div>
    </div>
  );
};
