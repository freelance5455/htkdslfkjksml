import React, { useState } from 'react';
import { translations } from '../utils/translations';
import { Language, DeviceInfo } from '../types';
import { sounds } from '../utils/audio';
import {
  HardDrive,
  Trash2,
  ShieldCheck,
  CheckCircle2,
  Folder,
  Image,
  Video,
  Download,
  AlertTriangle,
  Info,
} from 'lucide-react';

interface StorageAnalyzerProProps {
  language: Language;
  deviceInfo: DeviceInfo | null;
  onRefreshTelemetry: () => void;
}

export const StorageAnalyzerPro: React.FC<StorageAnalyzerProProps> = ({
  language,
  deviceInfo,
  onRefreshTelemetry,
}) => {
  const t = translations[language];
  const [clearingCache, setClearingCache] = useState(false);
  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [clearedSuccess, setClearedSuccess] = useState(false);

  const handleConfirmClear = async () => {
    sounds.playClick();
    setShowConfirmModal(false);
    setClearingCache(true);

    try {
      if ('caches' in window) {
        const keys = await caches.keys();
        for (const k of keys) {
          await caches.delete(k);
        }
      }
    } catch {}

    await new Promise((r) => setTimeout(r, 600));
    setClearingCache(false);
    setClearedSuccess(true);
    sounds.playCleanSuccess();
    onRefreshTelemetry();
    setTimeout(() => setClearedSuccess(false), 3000);
  };

  const hasStorageData = deviceInfo && deviceInfo.storageQuotaGB !== 'N/A';
  const totalGB = hasStorageData ? Number(deviceInfo.storageQuotaGB) : null;
  const usedGB = hasStorageData ? Number(deviceInfo.storageUsedGB) : null;
  const freeGB = hasStorageData ? Number(deviceInfo.storageAvailableGB) : null;
  const usedPercent = (totalGB && usedGB && totalGB > 0) ? Math.min(100, Math.round((usedGB / totalGB) * 100)) : 0;

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div>
        <h1 className="text-xl sm:text-2xl font-black text-white font-gaming flex items-center gap-2">
          <HardDrive className="w-6 h-6 text-purple-400" />
          <span>{t.storageTitle}</span>
        </h1>
        <p className="text-xs text-slate-400 mt-1">
          {language === 'si'
            ? 'Device Storage Quota සහ ආරක්ෂිත ගබඩා විශ්ලේෂණය (සැබෑ දත්ත පමණි)'
            : 'Device storage quota analysis and safe cached data management'}
        </p>
      </div>

      {/* Main Storage Bar Card */}
      <div className="bg-slate-900 border border-purple-500/30 rounded-3xl p-6 sm:p-8 shadow-xl">
        {hasStorageData && totalGB !== null && usedGB !== null && freeGB !== null ? (
          <>
            <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-2 mb-4">
              <div>
                <div className="text-xs text-slate-400 font-mono uppercase">{t.usedStorage}</div>
                <div className="text-3xl sm:text-4xl font-black font-gaming text-white tabular-nums">
                  {usedGB.toFixed(2)} GB <span className="text-lg text-slate-400 font-normal">/ {totalGB.toFixed(2)} GB</span>
                </div>
              </div>
              <div className="text-sm font-mono text-emerald-400 font-bold">
                {freeGB.toFixed(2)} GB {language === 'si' ? 'ඉතිරිව ඇත' : 'Available'} ({100 - usedPercent}%)
              </div>
            </div>

            {/* Progress Bar */}
            <div className="w-full h-3 rounded-full bg-slate-950 overflow-hidden flex border border-slate-800 mb-6">
              <div
                style={{ width: `${Math.max(2, usedPercent)}%` }}
                className="bg-gradient-to-r from-purple-500 to-cyan-500 h-full transition-all duration-500"
              />
            </div>

            <div className="grid grid-cols-2 gap-3 text-xs mb-6">
              <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800">
                <div className="text-slate-400 font-mono text-[10px]">Browser Allocated Storage</div>
                <div className="font-bold text-white font-gaming text-base mt-0.5">{totalGB.toFixed(2)} GB</div>
              </div>
              <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800">
                <div className="text-slate-400 font-mono text-[10px]">Current Usage</div>
                <div className="font-bold text-cyan-400 font-gaming text-base mt-0.5">{usedGB.toFixed(2)} GB</div>
              </div>
            </div>
          </>
        ) : (
          <div className="p-5 rounded-2xl bg-slate-950 border border-slate-800 text-xs text-slate-300 mb-6">
            <div className="flex items-center gap-2 font-bold text-amber-400 mb-1">
              <Info className="w-4 h-4" />
              <span>{language === 'si' ? 'Storage Quota API අවසර සීමා කර ඇත' : 'Storage Quota API Not Exposed'}</span>
            </div>
            <p className="leading-relaxed text-slate-400">
              {language === 'si'
                ? 'ඔබගේ Browser එක මඟින් Storage Quota කියවීමට අවසර ලබා දී නොමැත. බොරු Storage අගයන් (Fake Gigabytes) පෙන්වීම ප්‍රතික්ෂේප කර ඇත.'
                : 'Your current browser security policy restricts the StorageManager estimate API. No fake gigabyte numbers are rendered.'}
            </p>
          </div>
        )}

        {/* Clear Cache Action Button */}
        <div className="pt-4 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-xs text-slate-400 max-w-md">
            {language === 'si'
              ? 'අනවශ්‍ය Temporary CacheStorage buckets ඉවත් කිරීම මඟින් Free Fire සඳහා ඉඩ සකසා ගන්න.'
              : 'Safely purging temporary browser cache buckets frees memory without modifying personal user files.'}
          </p>

          <button
            onClick={() => {
              sounds.playClick();
              setShowConfirmModal(true);
            }}
            disabled={clearingCache}
            className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-750 text-purple-300 border border-purple-500/40 text-xs font-gaming font-bold flex items-center justify-center gap-2 cursor-pointer transition-all shrink-0"
          >
            <Trash2 className="w-4 h-4" />
            <span>{clearingCache ? 'Clearing...' : t.clearAppCache}</span>
          </button>
        </div>

        {clearedSuccess && (
          <div className="mt-4 p-3 rounded-xl bg-emerald-950 border border-emerald-500/40 text-xs text-emerald-300 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>
              {language === 'si' ? 'තාවකාලික Cache සාර්ථකව පිරිසිදු කරන ලදි!' : 'Temporary application cache successfully purged!'}
            </span>
          </div>
        )}
      </div>

      {/* Confirmation Modal */}
      {showConfirmModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="w-full max-w-sm rounded-3xl bg-slate-900 border border-purple-500/40 p-6 text-center shadow-2xl">
            <AlertTriangle className="w-12 h-12 text-amber-400 mx-auto mb-3" />
            <h3 className="font-gaming font-bold text-lg text-white mb-2">
              {language === 'si' ? 'Cache පිරිසිදු කිරීමට අවසරද?' : 'Confirm Cache Purge'}
            </h3>
            <p className="text-xs text-slate-300 mb-6 leading-relaxed">
              {language === 'si'
                ? 'මෙය තාවකාලික Application Cache ගොනු පමණක් ඉවත් කරනු ඇත. ඔබගේ කිසිදු පෞද්ගලික ඡායාරූපයක් හෝ ගොනුවක් මකා දැමෙන්නේ නැත.'
                : 'This only removes temporary browser application caches. No personal photos, downloads, or documents will be touched.'}
            </p>
            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={() => setShowConfirmModal(false)}
                className="py-2.5 rounded-xl bg-slate-800 text-slate-300 text-xs font-semibold hover:bg-slate-750 cursor-pointer"
              >
                {language === 'si' ? 'අවලංගු කරන්න' : 'Cancel'}
              </button>
              <button
                onClick={handleConfirmClear}
                className="py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold font-gaming cursor-pointer"
              >
                {language === 'si' ? 'ඔව්, පිරිසිදු කරන්න' : 'Yes, Purge'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Safety Notice */}
      <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 flex items-start gap-3 text-xs text-slate-400">
        <ShieldCheck className="w-4 h-4 text-purple-400 mt-0.5 shrink-0" />
        <span>{t.storageSafe}</span>
      </div>
    </div>
  );
};
