import React from 'react';
import { translations } from '../utils/translations';
import { Language } from '../types';
import { sounds } from '../utils/audio';
import { LayoutDashboard, Cpu, Activity, Target, Flame, Grid } from 'lucide-react';

interface BottomNavProps {
  language: Language;
  activeTab: string;
  onTabChange: (tab: string) => void;
  onOpenToolDrawer: () => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  language,
  activeTab,
  onTabChange,
  onOpenToolDrawer,
}) => {
  const t = translations[language];

  const items = [
    { id: 'dashboard', label: t.tabDashboard, icon: LayoutDashboard },
    { id: 'ram', label: t.tabRam, icon: Cpu },
    { id: 'ping', label: t.tabPing, icon: Activity },
    { id: 'aim', label: 'Aim Pro', icon: Target },
    { id: 'freefire', label: 'FF Opt', icon: Flame },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-slate-950/95 backdrop-blur-xl border-t border-cyan-500/20 px-2 py-1.5 lg:hidden">
      <div className="grid grid-cols-6 items-center">
        {items.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => {
                sounds.playClick();
                onTabChange(item.id);
              }}
              className={`flex flex-col items-center justify-center py-1 transition-all cursor-pointer ${
                isActive ? 'text-cyan-400 font-bold' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <div
                className={`p-1 rounded-xl transition-all ${
                  isActive ? 'bg-cyan-950/80 shadow-sm shadow-cyan-500/20' : ''
                }`}
              >
                <Icon className={`w-5 h-5 ${isActive ? 'stroke-[2.5]' : 'stroke-2'}`} />
              </div>
              <span className="text-[10px] tracking-tight mt-0.5 truncate max-w-[55px]">
                {item.label}
              </span>
            </button>
          );
        })}

        {/* All Tools drawer trigger */}
        <button
          onClick={() => {
            sounds.playClick();
            onOpenToolDrawer();
          }}
          className={`flex flex-col items-center justify-center py-1 transition-all cursor-pointer ${
            activeTab === 'more' ? 'text-cyan-400 font-bold' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <div className="p-1 rounded-xl">
            <Grid className="w-5 h-5" />
          </div>
          <span className="text-[10px] tracking-tight mt-0.5 truncate max-w-[55px]">
            {language === 'si' ? 'සියල්ල' : 'More'}
          </span>
        </button>
      </div>
    </nav>
  );
};
