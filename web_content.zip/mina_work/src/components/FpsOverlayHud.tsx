import React, { useState, useRef } from 'react';
import { FpsMetrics } from '../utils/fpsMeter';
import { sounds } from '../utils/audio';
import { X, Minimize2, Maximize2, Zap } from 'lucide-react';

interface FpsOverlayHudProps {
  metrics: FpsMetrics;
  visible: boolean;
  onClose: () => void;
  language: 'si' | 'en';
}

export const FpsOverlayHud: React.FC<FpsOverlayHudProps> = ({
  metrics,
  visible,
  onClose,
  language,
}) => {
  const [minimized, setMinimized] = useState(false);
  const [position, setPosition] = useState<{ x: number; y: number }>({ x: 16, y: 70 });

  const isDraggingRef = useRef(false);
  const dragStartRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const initialPosRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });

  if (!visible) return null;

  const handlePointerDown = (e: React.PointerEvent) => {
    isDraggingRef.current = true;
    dragStartRef.current = { x: e.clientX, y: e.clientY };
    initialPosRef.current = { ...position };
    (e.target as HTMLElement).setPointerCapture(e.pointerId);
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!isDraggingRef.current) return;
    const dx = e.clientX - dragStartRef.current.x;
    const dy = e.clientY - dragStartRef.current.y;

    const maxX = Math.max(10, window.innerWidth - (minimized ? 110 : 200));
    const maxY = Math.max(10, window.innerHeight - (minimized ? 40 : 160));

    setPosition({
      x: Math.min(maxX, Math.max(10, initialPosRef.current.x + dx)),
      y: Math.min(maxY, Math.max(10, initialPosRef.current.y + dy)),
    });
  };

  const handlePointerUp = (e: React.PointerEvent) => {
    isDraggingRef.current = false;
    try {
      (e.target as HTMLElement).releasePointerCapture(e.pointerId);
    } catch {}
  };

  // Color code based on frame rate
  const getFpsColor = (fps: number) => {
    if (fps >= 90) return { text: 'text-cyan-400', border: 'border-cyan-500/60', bg: 'bg-cyan-950/90', glow: 'shadow-cyan-500/30' };
    if (fps >= 55) return { text: 'text-emerald-400', border: 'border-emerald-500/60', bg: 'bg-emerald-950/90', glow: 'shadow-emerald-500/30' };
    if (fps >= 35) return { text: 'text-amber-400', border: 'border-amber-500/60', bg: 'bg-amber-950/90', glow: 'shadow-amber-500/30' };
    return { text: 'text-red-400', border: 'border-red-500/60', bg: 'bg-red-950/90', glow: 'shadow-red-500/30' };
  };

  const colors = getFpsColor(metrics.fps);

  // SVG sparkline path
  const maxVal = Math.max(60, metrics.refreshRate);
  const minVal = 0;
  const sparkWidth = 140;
  const sparkHeight = 28;
  const points = metrics.history.map((val, idx) => {
    const x = (idx / (metrics.history.length - 1)) * sparkWidth;
    const y = sparkHeight - ((val - minVal) / (maxVal - minVal)) * sparkHeight;
    return `${x.toFixed(1)},${y.toFixed(1)}`;
  }).join(' ');

  return (
    <div
      style={{
        position: 'fixed',
        left: `${position.x}px`,
        top: `${position.y}px`,
        zIndex: 9999,
      }}
      className={`select-none touch-none rounded-2xl backdrop-blur-md border ${colors.border} ${colors.bg} shadow-2xl ${colors.glow} transition-all duration-75`}
    >
      {/* Drag handle header */}
      <div
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        className="px-3 py-1.5 flex items-center justify-between gap-2 cursor-grab active:cursor-grabbing border-b border-white/10"
      >
        <div className="flex items-center gap-1.5 pointer-events-none">
          <Zap className="w-3.5 h-3.5 text-cyan-400 animate-pulse" />
          <span className="text-[10px] font-mono font-bold tracking-wider text-slate-300">
            MINA FPS HUD
          </span>
          <span className="text-[9px] font-mono px-1 rounded bg-black/40 text-cyan-300">
            {metrics.refreshRate}Hz
          </span>
        </div>

        <div className="flex items-center gap-1">
          <button
            onClick={() => {
              sounds.playClick();
              setMinimized(!minimized);
            }}
            className="w-5 h-5 rounded flex items-center justify-center text-slate-400 hover:text-white transition-colors cursor-pointer"
            title={minimized ? 'Expand' : 'Minimize'}
          >
            {minimized ? <Maximize2 className="w-3 h-3" /> : <Minimize2 className="w-3 h-3" />}
          </button>
          <button
            onClick={() => {
              sounds.playClick();
              onClose();
            }}
            className="w-5 h-5 rounded flex items-center justify-center text-slate-400 hover:text-red-400 transition-colors cursor-pointer"
            title="Close FPS HUD"
          >
            <X className="w-3 h-3" />
          </button>
        </div>
      </div>

      {/* Body */}
      {minimized ? (
        <div 
          onPointerDown={handlePointerDown}
          onPointerMove={handlePointerMove}
          onPointerUp={handlePointerUp}
          className="px-3 py-1.5 flex items-baseline gap-1.5 cursor-grab active:cursor-grabbing"
        >
          <span className={`text-2xl font-black font-gaming tabular-nums ${colors.text}`}>
            {metrics.fps}
          </span>
          <span className="text-[10px] font-mono text-slate-400 font-bold">FPS</span>
          <span className="text-[10px] font-mono text-slate-500 tabular-nums ml-1">
            {metrics.frameTimeMs}ms
          </span>
        </div>
      ) : (
        <div className="p-3 space-y-2 w-48">
          {/* Main FPS display */}
          <div className="flex items-baseline justify-between">
            <div className="flex items-baseline gap-1">
              <span className={`text-3xl font-black font-gaming tabular-nums ${colors.text}`}>
                {metrics.fps}
              </span>
              <span className="text-xs font-mono font-bold text-slate-400">FPS</span>
            </div>
            <div className="text-right">
              <div className="text-[10px] font-mono text-slate-400">{language === 'si' ? 'Frame Time' : 'Frame Time'}</div>
              <div className="text-xs font-mono font-bold text-slate-200 tabular-nums">
                {metrics.frameTimeMs} ms
              </div>
            </div>
          </div>

          {/* Real-time Waveform Sparkline */}
          <div className="h-7 w-full bg-black/40 rounded-lg p-1 overflow-hidden relative border border-white/5">
            <svg className="w-full h-full overflow-visible" preserveAspectRatio="none" viewBox={`0 0 ${sparkWidth} ${sparkHeight}`}>
              <polyline
                fill="none"
                stroke={metrics.fps >= 55 ? '#00f0ff' : '#f59e0b'}
                strokeWidth="1.75"
                strokeLinecap="round"
                strokeLinejoin="round"
                points={points}
              />
            </svg>
          </div>

          {/* Sub metrics: 1% Low & Avg */}
          <div className="grid grid-cols-2 gap-1.5 pt-1 border-t border-white/10 text-[10px] font-mono">
            <div className="bg-black/30 p-1.5 rounded-lg">
              <div className="text-slate-400">1% Low</div>
              <div className="font-bold text-cyan-300 tabular-nums">{metrics.onePercentLow} FPS</div>
            </div>
            <div className="bg-black/30 p-1.5 rounded-lg">
              <div className="text-slate-400">Avg FPS</div>
              <div className="font-bold text-slate-200 tabular-nums">{metrics.avgFps} FPS</div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
