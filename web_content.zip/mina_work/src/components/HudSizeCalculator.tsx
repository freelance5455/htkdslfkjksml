import React, { useState } from 'react';
import { translations } from '../utils/translations';
import { Language } from '../types';
import { sounds } from '../utils/audio';
import {
  Maximize2,
  Smartphone,
  Sparkles,
  RotateCcw,
  Flame,
  Info,
  CheckCircle2,
} from 'lucide-react';

interface HudSizeCalculatorProps {
  language: Language;
}

export const HudSizeCalculator: React.FC<HudSizeCalculatorProps> = ({ language }) => {
  const t = translations[language];

  const [screenInches, setScreenInches] = useState<number>(6.5);
  const [clawType, setClawType] = useState<'2finger' | '3finger' | '4finger'>('2finger');
  const [fireButtonSize, setFireButtonSize] = useState<number>(50);

  // Compute calculated suggested fire button size
  const calculateSuggestedSize = () => {
    // Smaller screens (<6.0") need a slightly smaller button (44-48%) to leave vertical drag room
    // Large screens (6.7"+) can use (52-58%)
    let base = 50;
    if (screenInches < 6.0) base = 44;
    else if (screenInches <= 6.3) base = 48;
    else if (screenInches <= 6.6) base = 52;
    else base = 56;

    if (clawType === '3finger') base -= 4;
    if (clawType === '4finger') base -= 6;
    return base;
  };

  const suggestedSize = calculateSuggestedSize();

  const handleApplySuggested = () => {
    sounds.playCleanSuccess();
    setFireButtonSize(suggestedSize);
  };

  const handleReset = () => {
    sounds.playClick();
    setScreenInches(6.5);
    setClawType('2finger');
    setFireButtonSize(50);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-white font-gaming flex items-center gap-2">
            <Maximize2 className="w-6 h-6 text-amber-400" />
            <span>{t.hudTitle}</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            {language === 'si'
              ? 'ඔබගේ Screen ප්‍රමාණය සහ ඇඟිලි ග්‍රහණය (Claw Grip) අනුව වඩාත්ම නිවැරදි Fire Button Size ගණනය කිරීම'
              : 'Calculate optimal fire button dimensions for drag distance and ergonomics'}
          </p>
        </div>

        <button
          onClick={handleReset}
          className="self-start sm:self-auto p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-white transition-all cursor-pointer"
          title="Reset HUD"
        >
          <RotateCcw className="w-4 h-4" />
        </button>
      </div>

      {/* Control Inputs */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Screen Size Selector */}
        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-xs font-gaming font-bold text-slate-200 flex items-center gap-2">
              <Smartphone className="w-4 h-4 text-cyan-400" />
              <span>{t.screenSizeInch}</span>
            </span>
            <span className="font-mono text-cyan-400 font-bold text-sm">
              {screenInches.toFixed(1)}"
            </span>
          </div>

          <input
            type="range"
            min="5.0"
            max="7.2"
            step="0.1"
            value={screenInches}
            onChange={(e) => setScreenInches(parseFloat(e.target.value))}
            className="w-full h-2 rounded-lg bg-slate-950 appearance-none cursor-pointer accent-cyan-400"
          />

          <div className="flex justify-between text-[11px] font-mono text-slate-500">
            <span>5.0" (Compact)</span>
            <span>6.5" (Standard)</span>
            <span>7.2" (Max)</span>
          </div>
        </div>

        {/* Claw Type Selector */}
        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
          <span className="text-xs font-gaming font-bold text-slate-200">
            {t.clawType}
          </span>

          <div className="grid grid-cols-3 gap-2">
            {[
              { id: '2finger', label: t.twoFinger },
              { id: '3finger', label: t.threeFinger },
              { id: '4finger', label: t.fourFinger },
            ].map((claw) => (
              <button
                key={claw.id}
                onClick={() => {
                  sounds.playClick();
                  setClawType(claw.id as '2finger' | '3finger' | '4finger');
                }}
                className={`py-2 px-3 rounded-xl text-xs font-semibold text-center transition-all cursor-pointer ${
                  clawType === claw.id
                    ? 'bg-amber-500 text-slate-950 font-bold shadow-md shadow-amber-950/40'
                    : 'bg-slate-950 text-slate-400 hover:text-slate-200 border border-slate-800'
                }`}
              >
                {claw.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Suggested Fire Button Recommendation Card */}
      <div className="p-5 sm:p-6 rounded-3xl bg-gradient-to-r from-amber-950/60 via-slate-900 to-slate-900 border border-amber-500/30 flex flex-col sm:flex-row items-center justify-between gap-5 shadow-xl">
        <div className="flex items-center gap-4 text-center sm:text-left">
          <div className="w-14 h-14 rounded-2xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400 shrink-0">
            <Flame className="w-8 h-8 fill-current" />
          </div>
          <div>
            <div className="text-xs text-amber-400 font-mono font-bold uppercase tracking-wider">
              {t.suggestedSize}
            </div>
            <div className="text-3xl sm:text-4xl font-black font-gaming text-white tabular-nums my-0.5">
              {suggestedSize}%
            </div>
            <p className="text-xs text-slate-300 max-w-md">
              {t.suggestedReason}
            </p>
          </div>
        </div>

        <button
          onClick={handleApplySuggested}
          className="w-full sm:w-auto px-6 py-3 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 text-slate-950 font-gaming font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg shadow-amber-950/50 hover:brightness-110 active:scale-95 transition-all cursor-pointer shrink-0"
        >
          <Sparkles className="w-4 h-4 fill-current" />
          <span>{language === 'si' ? 'යෝජිත Size එක දාන්න' : 'Apply Suggested'}</span>
        </button>
      </div>

      {/* Live Interactive HUD Preview Canvas */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-6 shadow-xl">
        <div className="flex items-center justify-between mb-4">
          <div className="text-xs font-gaming font-bold text-slate-200">
            {language === 'si' ? 'HUD පෙරදසුන (Interactive HUD Preview)' : 'Interactive Custom HUD Layout Simulator'}
          </div>
          <div className="text-xs font-mono text-cyan-400">
            Current Button Size: <strong className="text-white">{fireButtonSize}%</strong>
          </div>
        </div>

        {/* Scaled Phone Screen Preview Frame */}
        <div className="relative w-full h-72 sm:h-80 rounded-2xl bg-slate-950 border-2 border-slate-800 overflow-hidden select-none p-4 gaming-grid-bg">
          {/* Virtual Center Crosshair */}
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 pointer-events-none opacity-40">
            <div className="w-6 h-6 rounded-full border border-cyan-400 flex items-center justify-center">
              <div className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
            </div>
          </div>

          {/* Left Joystick Simulator */}
          <div className="absolute bottom-6 left-6 w-20 h-20 rounded-full border-2 border-slate-700/60 flex items-center justify-center pointer-events-none opacity-60">
            <div className="w-8 h-8 rounded-full bg-slate-800 border border-slate-600" />
          </div>

          {/* Right Action buttons (Jump, Crouch, Prone) */}
          <div className="absolute bottom-28 right-8 flex flex-col gap-2 pointer-events-none opacity-60">
            <div className="w-10 h-10 rounded-full bg-slate-900 border border-slate-700 flex items-center justify-center text-[10px] text-slate-400 font-mono">
              JUMP
            </div>
            <div className="w-10 h-10 rounded-full bg-slate-900 border border-slate-700 flex items-center justify-center text-[10px] text-slate-400 font-mono">
              CROUCH
            </div>
          </div>

          {/* Scaled Virtual Fire Button (Positioned at bottom right) */}
          <div
            style={{
              width: `${Math.round(40 + (fireButtonSize / 100) * 55)}px`,
              height: `${Math.round(40 + (fireButtonSize / 100) * 55)}px`,
            }}
            className="absolute bottom-6 right-6 rounded-full bg-gradient-to-tr from-amber-600 to-orange-500 border-2 border-amber-300 shadow-xl shadow-amber-500/30 flex flex-col items-center justify-center text-white cursor-pointer transition-all duration-150 active:scale-95"
          >
            <Flame className="w-5 h-5 fill-current" />
            <span className="text-[8px] font-gaming font-black">{fireButtonSize}%</span>
          </div>

          <div className="absolute top-3 left-4 text-[10px] text-slate-500 font-mono">
            Aspect: 20:9 Wide Display Simulator
          </div>
        </div>

        {/* Fire Button Size Slider */}
        <div className="mt-5 space-y-2">
          <div className="flex items-center justify-between text-xs font-semibold text-slate-300">
            <span>{t.fireButtonSize}</span>
            <span className="font-mono text-amber-400 font-bold">{fireButtonSize}%</span>
          </div>
          <input
            type="range"
            min="20"
            max="100"
            value={fireButtonSize}
            onChange={(e) => setFireButtonSize(parseInt(e.target.value))}
            className="w-full h-2 rounded-lg bg-slate-950 appearance-none cursor-pointer accent-amber-400"
          />
        </div>
      </div>

      {/* HUD Pro Tips */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 shadow-lg">
        <div className="flex items-center gap-2 mb-3">
          <Info className="w-4 h-4 text-cyan-400" />
          <h2 className="font-gaming font-bold text-sm text-slate-200">
            {language === 'si' ? 'HUD Button ස්ථානගත කිරීමේ රහස්' : 'HUD Button Placement Tips'}
          </h2>
        </div>

        <ul className="space-y-2 text-xs text-slate-300">
          <li className="flex items-start gap-2">
            <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400 mt-0.5 shrink-0" />
            <span>
              {language === 'si'
                ? 'Fire Button එක තිරයේ ඉතා පහළට නොව මදක් ඉහළට වන්නට (Bottom 20% සීමාවේ) තබන්න. එවිට මාපටැඟිල්ල ඉහළට Drag කිරීමට උපරිම ඉඩ ලැබේ.'
                : 'Do not pin the fire button too low on the bezel; leave at least 20% vertical runway above the button for full drag stroke.'}
            </span>
          </li>
          <li className="flex items-start gap-2">
            <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400 mt-0.5 shrink-0" />
            <span>
              {language === 'si'
                ? 'Button Size එක 65% ට වඩා විශාල කළ විට Drag Drag කිරීමට ඇති ඉඩ අඩුවේ. එබැවින් 45% - 55% අතර අගයක් වඩාත් සුදුසුය.'
                : 'Buttons larger than 65% reduce upward swipe runway and cause body shots. 48-54% is the global eSports standard.'}
            </span>
          </li>
        </ul>
      </div>

      {/* Safety Notice */}
      <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 flex items-start gap-3 text-xs text-slate-400">
        <Info className="w-4 h-4 text-amber-400 mt-0.5 shrink-0" />
        <span>{t.hudNotice}</span>
      </div>
    </div>
  );
};
