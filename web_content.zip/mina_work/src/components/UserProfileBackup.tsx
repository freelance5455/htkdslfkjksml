import React, { useState } from 'react';
import { translations } from '../utils/translations';
import { Language, SensitivitySettings, CrosshairConfig } from '../types';
import { sounds } from '../utils/audio';
import confetti from 'canvas-confetti';
import {
  User,
  Download,
  Upload,
  RotateCcw,
  Save,
  CheckCircle2,
  AlertTriangle,
  ShieldCheck,
} from 'lucide-react';

interface UserProfileBackupProps {
  language: Language;
  username: string;
  onUpdateUsername: (name: string) => void;
  sensitivitySettings: SensitivitySettings;
  crosshair: CrosshairConfig;
  onRestoreAllSettings: (data: { username: string; sensitivity: SensitivitySettings; crosshair: CrosshairConfig }) => void;
  onResetApp: () => void;
}

export const UserProfileBackup: React.FC<UserProfileBackupProps> = ({
  language,
  username,
  onUpdateUsername,
  sensitivitySettings,
  crosshair,
  onRestoreAllSettings,
  onResetApp,
}) => {
  const t = translations[language];

  const [inputName, setInputName] = useState(username);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [showResetConfirm, setShowResetConfirm] = useState(false);

  const handleSaveName = () => {
    sounds.playCleanSuccess();
    onUpdateUsername(inputName.trim() || 'Gamer Mina');
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2000);
  };

  const handleExportBackup = () => {
    sounds.playCleanSuccess();
    const backupData = {
      version: '2.5.0',
      timestamp: new Date().toISOString(),
      appName: 'MINA OPTIMIZER PRO',
      developer: 'Gaming Mina 10K',
      username: inputName,
      sensitivity: sensitivitySettings,
      crosshair,
    };

    const blob = new Blob([JSON.stringify(backupData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Mina_Optimizer_Backup_${Date.now()}.json`;
    a.click();

    try {
      confetti({ particleCount: 30, spread: 40 });
    } catch {}
  };

  const handleImportBackup = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const json = JSON.parse(event.target?.result as string);
        if (json.sensitivity && json.crosshair) {
          onRestoreAllSettings({
            username: json.username || 'Gamer Mina',
            sensitivity: json.sensitivity,
            crosshair: json.crosshair,
          });
          setInputName(json.username || 'Gamer Mina');
          sounds.playCleanSuccess();
          alert(language === 'si' ? 'Settings සාර්ථකව Restore කරන ලදි!' : 'Settings successfully restored!');
        } else {
          alert('Invalid backup file structure.');
        }
      } catch {
        alert('Failed to parse JSON backup file.');
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div>
        <h1 className="text-xl sm:text-2xl font-black text-white font-gaming flex items-center gap-2">
          <User className="w-6 h-6 text-cyan-400" />
          <span>{t.profileTitle}</span>
        </h1>
        <p className="text-xs text-slate-400 mt-1">
          {language === 'si'
            ? 'ක්‍රීඩක ගිණුම, Sensitivity සහ App Settings Backup & Restore කිරීම'
            : 'Player profile identity and configuration JSON export & restore'}
        </p>
      </div>

      {/* User Identity Card */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-xl flex flex-col sm:flex-row items-center gap-6">
        {/* Official Logo Avatar */}
        <div className="relative w-24 h-24 rounded-full p-1 bg-gradient-to-tr from-cyan-400 via-blue-500 to-red-500 shadow-xl shadow-cyan-500/20 shrink-0">
          <img
            src="/assets/aistudio/InShot_20261021_172915725_10b6c6dd.jpg"
            alt="Mina Logo"
            className="w-full h-full object-cover rounded-full"
          />
        </div>

        {/* Name input */}
        <div className="flex-1 w-full space-y-3">
          <label className="text-xs font-gaming font-bold text-slate-300 block">
            {t.username}
          </label>
          <div className="flex flex-col sm:flex-row gap-2">
            <input
              type="text"
              value={inputName}
              onChange={(e) => setInputName(e.target.value)}
              placeholder="e.g. Mina_Pro_FF"
              className="flex-1 py-2.5 px-4 rounded-xl bg-slate-950 border border-slate-800 text-white font-gaming text-sm focus:outline-none focus:border-cyan-500 transition-colors"
            />
            <button
              onClick={handleSaveName}
              className="py-2.5 px-5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-gaming font-bold text-xs flex items-center justify-center gap-1.5 shadow-md shadow-cyan-950/40 cursor-pointer transition-all"
            >
              <Save className="w-4 h-4" />
              <span>{saveSuccess ? (language === 'si' ? 'සුරැකිණි!' : 'Saved!') : t.saveProfile}</span>
            </button>
          </div>
          <p className="text-[11px] text-slate-500 font-mono">
            {language === 'si'
              ? 'ක්‍රීඩක නාමය ඔබගේ Device එක තුළ සුරැකී පවතී.'
              : 'Stored securely on local storage.'}
          </p>
        </div>
      </div>

      {/* Backup & Restore Controls */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {/* Export Backup */}
        <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 flex flex-col justify-between shadow-lg">
          <div>
            <div className="w-10 h-10 rounded-xl bg-cyan-950 border border-cyan-500/40 flex items-center justify-center text-cyan-400 mb-3">
              <Download className="w-5 h-5" />
            </div>
            <h3 className="font-gaming font-bold text-white text-base mb-1">
              {t.exportBackup}
            </h3>
            <p className="text-xs text-slate-400 mb-5 leading-relaxed">
              {language === 'si'
                ? 'ඔබගේ සියලු Sensitivity අගයන්, Crosshair සැකසුම් සහ Profile දත්ත JSON ගොනුවක් ලෙස Phone එකට Save කරගන්න.'
                : 'Export all sensitivity parameters, custom crosshairs, and profiles as a backup JSON file.'}
            </p>
          </div>

          <button
            onClick={handleExportBackup}
            className="w-full py-3 px-4 rounded-xl bg-slate-800 hover:bg-slate-750 text-cyan-300 border border-cyan-500/30 font-gaming font-bold text-xs flex items-center justify-center gap-2 cursor-pointer transition-all"
          >
            <Download className="w-4 h-4" />
            <span>{language === 'si' ? 'Backup ගොනුව බාගත කරන්න' : 'Download JSON Backup'}</span>
          </button>
        </div>

        {/* Restore Backup */}
        <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 flex flex-col justify-between shadow-lg">
          <div>
            <div className="w-10 h-10 rounded-xl bg-emerald-950 border border-emerald-500/40 flex items-center justify-center text-emerald-400 mb-3">
              <Upload className="w-5 h-5" />
            </div>
            <h3 className="font-gaming font-bold text-white text-base mb-1">
              {t.importBackup}
            </h3>
            <p className="text-xs text-slate-400 mb-5 leading-relaxed">
              {language === 'si'
                ? 'කලින් Save කරගත් Backup JSON ගොනුවක් තෝරා සියලු සැකසුම් නැවත ලබාගන්න.'
                : 'Restore previously exported configuration settings from your storage.'}
            </p>
          </div>

          <label className="w-full py-3 px-4 rounded-xl bg-slate-800 hover:bg-slate-750 text-emerald-300 border border-emerald-500/30 font-gaming font-bold text-xs flex items-center justify-center gap-2 cursor-pointer transition-all text-center">
            <Upload className="w-4 h-4" />
            <span>{language === 'si' ? 'ගොනුවක් තෝරන්න (Select JSON)' : 'Choose JSON File'}</span>
            <input
              type="file"
              accept=".json"
              onChange={handleImportBackup}
              className="hidden"
            />
          </label>
        </div>
      </div>

      {/* Complete Reset Button */}
      <div className="p-5 rounded-2xl bg-slate-950 border border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div>
          <div className="text-sm font-gaming font-bold text-white">{t.resetApp}</div>
          <div className="text-xs text-slate-400">
            {language === 'si'
              ? 'සියලු දත්ත මකා මුල් තත්ත්වයට පත් කරයි'
              : 'Resets all local caches, custom sensitivities, and session records.'}
          </div>
        </div>

        <button
          onClick={() => {
            sounds.playClick();
            setShowResetConfirm(true);
          }}
          className="w-full sm:w-auto px-4 py-2 rounded-xl bg-red-950/60 border border-red-500/40 text-red-300 hover:bg-red-900/60 text-xs font-semibold cursor-pointer transition-colors"
        >
          {language === 'si' ? 'සම්පූර්ණ Reset කරන්න' : 'Factory Reset'}
        </button>
      </div>

      {/* Reset Confirmation Dialog */}
      {showResetConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="w-full max-w-sm rounded-3xl bg-slate-900 border border-red-500/40 p-6 text-center shadow-2xl">
            <AlertTriangle className="w-12 h-12 text-red-400 mx-auto mb-3" />
            <h3 className="font-gaming font-bold text-lg text-white mb-2">
              {language === 'si' ? 'App එක Reset කිරීමට තහවුරු කරන්න' : 'Confirm App Reset'}
            </h3>
            <p className="text-xs text-slate-300 mb-6 leading-relaxed">
              {language === 'si'
                ? 'මෙයින් ඔබගේ සියලු Sensitivity සැකසුම්, Crosshairs සහ Session History මකා දමනු ඇත. ඉදිරියට යාමට අවශ්‍යද?'
                : 'This will clear all saved settings, sessions, and custom sensitivities.'}
            </p>
            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={() => setShowResetConfirm(false)}
                className="py-2.5 rounded-xl bg-slate-800 text-slate-300 text-xs font-semibold hover:bg-slate-750 cursor-pointer"
              >
                {language === 'si' ? 'නැත' : 'Cancel'}
              </button>
              <button
                onClick={() => {
                  sounds.playClick();
                  setShowResetConfirm(false);
                  onResetApp();
                }}
                className="py-2.5 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-bold font-gaming cursor-pointer"
              >
                {language === 'si' ? 'ඔව්, Reset කරන්න' : 'Confirm Reset'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Safety Notice */}
      <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 flex items-start gap-3 text-xs text-slate-400">
        <ShieldCheck className="w-4 h-4 text-cyan-400 mt-0.5 shrink-0" />
        <span>
          {language === 'si'
            ? 'පෞද්ගලිකත්ව සහතිකය: සියලු Backup දත්ත ඔබගේම Device එක තුළ පමණක් ගබඩා වේ. කිසිදු බාහිර සේවාදායකයකට (Cloud Server) දත්ත යවනු නොලැබේ.'
            : 'Privacy Assurance: Backup files are stored 100% locally on your file system without cloud telemetries.'}
        </span>
      </div>
    </div>
  );
};
