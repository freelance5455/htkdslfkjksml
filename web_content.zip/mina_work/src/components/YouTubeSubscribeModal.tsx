import React, { useState } from 'react';
import { translations } from '../utils/translations';
import { Language } from '../types';
import { sounds } from '../utils/audio';
import confetti from 'canvas-confetti';
import { Youtube, Bell, ExternalLink, CheckCircle2, AlertCircle } from 'lucide-react';

interface YouTubeSubscribeModalProps {
  language: Language;
  onSubscribeVerified: () => void;
}

export const YouTubeSubscribeModal: React.FC<YouTubeSubscribeModalProps> = ({
  language,
  onSubscribeVerified,
}) => {
  const t = translations[language];
  const [clickedSubscribe, setClickedSubscribe] = useState(false);
  const [showBellHint, setShowBellHint] = useState(false);

  const handleOpenChannel = () => {
    sounds.playClick();
    setClickedSubscribe(true);
    // Open official YouTube Channel
    window.open(t.youtubeUrl, '_blank', 'noopener,noreferrer');
  };

  const handleContinue = () => {
    if (!clickedSubscribe) {
      sounds.playBodyHit();
      // Require clicking subscribe button first
      return;
    }
    sounds.playCleanSuccess();
    try {
      confetti({
        particleCount: 70,
        spread: 60,
        origin: { y: 0.6 },
        colors: ['#00f0ff', '#3b82f6', '#ff0033'],
      });
    } catch {
      // Ignored if canvas-confetti is not loaded
    }
    onSubscribeVerified();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto p-4 sm:p-6 bg-black/90 backdrop-blur-md flex items-center justify-center">
      <div className="w-full max-w-md my-auto max-h-[90vh] overflow-y-auto bg-slate-900 border border-red-500/30 rounded-3xl p-5 sm:p-8 shadow-2xl shadow-red-950/40 text-center relative">
        {/* Glow */}
        <div className="absolute -top-20 -right-20 w-44 h-44 bg-red-600/20 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-20 -left-20 w-44 h-44 bg-cyan-600/20 rounded-full blur-3xl pointer-events-none" />

        {/* Official Gaming Mina 10K Logo */}
        <div className="relative mx-auto w-24 h-24 sm:w-28 sm:h-28 rounded-full p-1 bg-gradient-to-tr from-red-600 via-orange-500 to-cyan-500 shadow-xl shadow-red-600/25 mb-4">
          <img
            src="/assets/aistudio/InShot_20261021_172915725_10b6c6dd.jpg"
            alt="Gaming Mina 10K Logo"
            className="w-full h-full object-cover rounded-full"
          />
        </div>

        {/* Badge */}
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-red-950/80 border border-red-500/40 text-red-400 text-xs font-semibold mb-3">
          <Youtube className="w-3.5 h-3.5 fill-current" />
          <span>Official Gaming Mina 10K Channel</span>
        </div>

        {/* Title */}
        <h2 className="text-xl sm:text-2xl font-black text-white font-gaming mb-2">
          {t.subscribeRequired}
        </h2>
        <p className="text-xs sm:text-sm text-slate-300 leading-relaxed mb-6">
          {t.subscribeDescription}
        </p>

        {/* YouTube Subscribe Button */}
        <div className="space-y-3 mb-6">
          <a
            href={t.youtubeUrl}
            target="_blank"
            rel="noopener noreferrer"
            onClick={() => {
              sounds.playClick();
              setClickedSubscribe(true);
            }}
            className={`w-full py-3.5 px-5 rounded-2xl flex items-center justify-center gap-3 text-sm sm:text-base font-bold transition-all shadow-lg cursor-pointer ${
              clickedSubscribe
                ? 'bg-slate-800 text-slate-200 border border-emerald-500/50 hover:bg-slate-750'
                : 'bg-gradient-to-r from-red-600 to-red-700 text-white shadow-red-600/30 hover:brightness-110 active:scale-[0.98]'
            }`}
          >
            <Youtube className="w-5 h-5 fill-current" />
            <span>{t.subscribeBtn}</span>
            <ExternalLink className="w-4 h-4 ml-auto" />
          </a>

          {/* Bell hint trigger */}
          <button
            onClick={() => {
              sounds.playClick();
              setShowBellHint(!showBellHint);
            }}
            className="w-full py-2.5 px-4 rounded-xl bg-slate-950/80 border border-slate-800 hover:border-slate-700 text-xs text-amber-300 flex items-center justify-center gap-2 cursor-pointer transition-colors"
          >
            <Bell className="w-4 h-4 text-amber-400 animate-bounce" />
            <span>{t.bellNotificationHint}</span>
          </button>
        </div>

        {/* Notification Bell Explainer Popup */}
        {showBellHint && (
          <div className="p-3 mb-5 rounded-xl bg-amber-950/40 border border-amber-500/30 text-left text-xs text-amber-200/90 leading-relaxed">
            <div className="font-semibold text-amber-300 mb-1 flex items-center gap-1.5">
              <Bell className="w-3.5 h-3.5" />
              <span>
                {language === 'si' ? 'All Notifications සක්‍රීය කිරීම:' : 'Turn On All Notifications:'}
              </span>
            </div>
            {language === 'si'
              ? 'YouTube Channel එකේ Subscribe කළ පසු අසල ඇති සීනුව (Bell Icon) ක්ලික් කර "All" තෝරන්න. එවිට නවතම Free Fire Sensitivity & Config වීඩියෝ ඔබට සැණින් ලැබෙනු ඇත.'
              : 'After subscribing on YouTube, tap the Bell icon next to the subscribe button and choose "All" to receive every Free Fire optimization guide and sensitivity drop.'}
          </div>
        )}

        {/* Status message */}
        {!clickedSubscribe ? (
          <div className="flex items-center justify-center gap-1.5 text-xs text-slate-400 mb-5">
            <AlertCircle className="w-3.5 h-3.5 text-amber-400" />
            <span>
              {language === 'si'
                ? 'ඉදිරියට යාමට පෙර Subscribe බොත්තම ක්ලික් කරන්න.'
                : 'Click the Subscribe button above to proceed.'}
            </span>
          </div>
        ) : (
          <div className="flex items-center justify-center gap-1.5 text-xs text-emerald-400 mb-5">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span>{t.subscribedVerified}</span>
          </div>
        )}

        {/* Continue Button (Skip button is strictly excluded per requirement) */}
        <button
          onClick={handleContinue}
          disabled={!clickedSubscribe}
          className={`w-full py-3.5 px-6 rounded-2xl font-gaming font-bold text-sm sm:text-base flex items-center justify-center gap-2 transition-all ${
            clickedSubscribe
              ? 'bg-gradient-to-r from-cyan-400 via-blue-500 to-cyan-500 text-slate-950 shadow-lg shadow-cyan-500/30 hover:brightness-110 active:scale-[0.98] cursor-pointer'
              : 'bg-slate-800 text-slate-500 cursor-not-allowed opacity-60'
          }`}
        >
          <span>{t.continueToDashboard}</span>
        </button>
      </div>
    </div>
  );
};
