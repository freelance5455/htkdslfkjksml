export type Language = 'si' | 'en';

export interface DeviceInfo {
  brand: string;
  model: string;
  platform: string;
  androidVersion: string;
  userAgent: string;
  screenResolution: string;
  screenDensity: number;
  refreshRate: number;
  cpuCores: number;
  gpuVendor: string;
  gpuRenderer: string;
  totalRamGB: number | string;
  usedRamMB: number | string;
  availableRamMB: number | string;
  ramUsagePercent: number;
  touchPoints: number;
  isOnline: boolean;
  networkType: string;
  downlinkMbps: number | string;
  rttMs: number | string;
  batteryLevel: number | null;
  isCharging: boolean | null;
  storageQuotaGB: number | string;
  storageUsedGB: number | string;
  storageAvailableGB: number | string;
}

export interface PingDataPoint {
  time: string;
  latency: number;
}

export interface CleanupLog {
  id: string;
  timestamp: string;
  freedMB: number;
  beforeRamMB: number;
  afterRamMB: number;
  target: string;
}

export interface GamingSession {
  id: string;
  startTime: string;
  endTime: string;
  durationMinutes: number;
  startBattery: number | null;
  endBattery: number | null;
  game: 'Free Fire' | 'Free Fire MAX' | 'Custom';
  avgPing: number;
}

export interface AppNotification {
  id: string;
  title: string;
  message: string;
  timestamp: string;
  type: 'info' | 'success' | 'warning' | 'alert';
  read: boolean;
}

export interface SensitivitySettings {
  general: number;
  redDot: number;
  scope2x: number;
  scope4x: number;
  sniperScope: number;
  freeLook: number;
}

export interface CrosshairConfig {
  type: 'dot' | 'classic' | 'circleDot' | 'chevron' | 'sniper' | 'diamond';
  size: number;
  color: string;
  opacity: number;
  borderWidth: number;
}
