import { DeviceInfo } from '../types';

export async function fetchDeviceInfo(): Promise<DeviceInfo> {
  // Screen and Density
  const dpr = window.devicePixelRatio || 1;
  const screenW = Math.round(window.screen.width * dpr);
  const screenH = Math.round(window.screen.height * dpr);
  const screenResolution = `${screenW} x ${screenH} px (${window.screen.width}x${window.screen.height} CSS)`;

  // Measure display refresh rate using requestAnimationFrame delta
  let measuredHz = 60;
  try {
    measuredHz = await measureRefreshRate();
  } catch {
    measuredHz = 60;
  }

  // CPU Cores from navigator.hardwareConcurrency (Real OS value)
  const cpuCores = navigator.hardwareConcurrency || 4;

  // WebGL GPU Detection
  let gpuVendor = 'Unavailable';
  let gpuRenderer = 'Unavailable';
  try {
    const canvas = document.createElement('canvas');
    const gl = canvas.getContext('webgl') || canvas.getContext('experimental-webgl');
    if (gl && gl instanceof WebGLRenderingContext) {
      const dbg = gl.getExtension('WEBGL_debug_renderer_info');
      if (dbg) {
        gpuVendor = gl.getParameter(dbg.UNMASKED_VENDOR_WEBGL) || 'Standard GPU';
        gpuRenderer = gl.getParameter(dbg.UNMASKED_RENDERER_WEBGL) || 'Hardware Render Pipeline';
      }
    }
  } catch {
    // Unmasked vendor not available
  }

  // RAM Metrics - Real API only
  const devMemory = (navigator as unknown as { deviceMemory?: number }).deviceMemory;
  let totalRamGB: number | string = devMemory !== undefined ? `${devMemory} GB` : 'Protected by Browser';
  let usedRamMB: number | string = 'Unavailable';
  let availableRamMB: number | string = 'Unavailable';
  let ramUsagePercent = 0;

  const perfMem = (performance as unknown as { memory?: { usedJSHeapSize: number; totalJSHeapSize: number; jsHeapSizeLimit: number } }).memory;
  if (perfMem && perfMem.jsHeapSizeLimit > 0) {
    usedRamMB = Math.round(perfMem.usedJSHeapSize / (1024 * 1024));
    const totalHeapMB = Math.round(perfMem.jsHeapSizeLimit / (1024 * 1024));
    availableRamMB = Math.max(0, totalHeapMB - (usedRamMB as number));
    ramUsagePercent = Math.min(100, Math.round(((usedRamMB as number) / totalHeapMB) * 100));
  }

  // Battery Status - Real API only
  let batteryLevel: number | null = null;
  let isCharging: boolean | null = null;
  try {
    if ('getBattery' in navigator) {
      const battery = await (navigator as unknown as { getBattery: () => Promise<{ level: number; charging: boolean }> }).getBattery();
      batteryLevel = Math.round(battery.level * 100);
      isCharging = battery.charging;
    }
  } catch {
    batteryLevel = null;
    isCharging = null;
  }

  // Storage Quota - Real API only
  let storageQuotaGB: number | string = 'N/A';
  let storageUsedGB: number | string = 'N/A';
  let storageAvailableGB: number | string = 'N/A';
  try {
    if (navigator.storage && navigator.storage.estimate) {
      const estimate = await navigator.storage.estimate();
      if (estimate.quota !== undefined && estimate.usage !== undefined) {
        const quotaGB = (estimate.quota / (1024 * 1024 * 1024)).toFixed(2);
        const usedGB = (estimate.usage / (1024 * 1024 * 1024)).toFixed(2);
        const freeGB = Math.max(0, (estimate.quota - estimate.usage) / (1024 * 1024 * 1024)).toFixed(2);
        storageQuotaGB = quotaGB;
        storageUsedGB = usedGB;
        storageAvailableGB = freeGB;
      }
    }
  } catch {
    // Storage estimate not permitted
  }

  // Network connection info - Real API only
  const conn = (navigator as unknown as { connection?: { effectiveType?: string; type?: string; downlink?: number; rtt?: number } }).connection;
  const networkType = conn?.effectiveType ? conn.effectiveType.toUpperCase() : (navigator.onLine ? 'Online' : 'Offline');
  const downlinkMbps = conn?.downlink !== undefined ? conn.downlink : 'N/A';
  const rttMs = conn?.rtt !== undefined ? conn.rtt : 'N/A';

  // Platform and Model extraction from real User-Agent
  const userAgent = navigator.userAgent;
  let brand = 'Device';
  let model = navigator.platform || 'Android';
  let androidVersion = 'Android';

  if (userAgent.includes('Android')) {
    const match = userAgent.match(/Android\s([0-9\.]+)/);
    if (match) androidVersion = `Android ${match[1]}`;
    const modelMatch = userAgent.match(/;\s([^;]+)\sBuild\//);
    if (modelMatch) {
      model = modelMatch[1];
      const words = model.split(' ');
      brand = words[0];
    }
  } else if (/iPhone|iPad/.test(userAgent)) {
    brand = 'Apple';
    model = 'iOS Device';
    androidVersion = 'iOS';
  } else {
    brand = 'PC / Workstation';
    model = navigator.platform || 'Desktop';
    androidVersion = 'Desktop OS';
  }

  return {
    brand,
    model,
    platform: navigator.platform || 'Linux',
    androidVersion,
    userAgent,
    screenResolution,
    screenDensity: parseFloat(dpr.toFixed(2)),
    refreshRate: measuredHz,
    cpuCores,
    gpuVendor,
    gpuRenderer,
    totalRamGB,
    usedRamMB,
    availableRamMB,
    ramUsagePercent,
    touchPoints: navigator.maxTouchPoints || 0,
    isOnline: navigator.onLine,
    networkType,
    downlinkMbps,
    rttMs,
    batteryLevel,
    isCharging,
    storageQuotaGB,
    storageUsedGB,
    storageAvailableGB,
  };
}

// Measure true display frame rate
function measureRefreshRate(): Promise<number> {
  return new Promise((resolve) => {
    let frameCount = 0;
    const start = performance.now();
    const checkFrame = () => {
      frameCount++;
      const elapsed = performance.now() - start;
      if (elapsed >= 500) {
        const fps = Math.round((frameCount / elapsed) * 1000);
        if (fps >= 135) resolve(144);
        else if (fps >= 110) resolve(120);
        else if (fps >= 80) resolve(90);
        else resolve(60);
      } else {
        requestAnimationFrame(checkFrame);
      }
    };
    requestAnimationFrame(checkFrame);
  });
}

// Perform real latency ping probe (Real network roundtrip only, NO random numbers)
export async function measurePing(): Promise<number | null> {
  const start = performance.now();
  try {
    const timestamp = Date.now();
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 2000);

    // Primary: Google Public DNS or Cloudflare gateway with no-cors
    try {
      await fetch(`https://dns.google/resolve?name=example.com&_mina=${timestamp}`, {
        method: 'GET',
        mode: 'no-cors',
        cache: 'no-store',
        signal: controller.signal,
      });
    } catch {
      // Fallback: ping self origin
      await fetch(`/?_mina=${timestamp}`, {
        method: 'HEAD',
        cache: 'no-store',
        signal: controller.signal,
      });
    }

    clearTimeout(timeout);
    const end = performance.now();
    return Math.max(1, Math.round(end - start));
  } catch {
    const conn = (navigator as unknown as { connection?: { rtt?: number } }).connection;
    if (conn && typeof conn.rtt === 'number' && conn.rtt > 0) {
      return conn.rtt;
    }
    return null;
  }
}

// Perform safe RAM cache and garbage release (Real metrics only)
export async function performSafeRamClean(): Promise<{ freedMB: number; beforeMB: number; afterMB: number; cachesDeleted: number }> {
  const perfMem = (performance as unknown as { memory?: { usedJSHeapSize: number } }).memory;
  const beforeMB = perfMem ? Math.round(perfMem.usedJSHeapSize / (1024 * 1024)) : 0;
  let cachesDeleted = 0;

  try {
    if ('caches' in window) {
      const cacheNames = await caches.keys();
      for (const name of cacheNames) {
        await caches.delete(name);
        cachesDeleted++;
      }
    }
  } catch {
    // Handled
  }

  // Hint garbage collection by dropping local reference
  let tempBuffer: ArrayBuffer | null = new ArrayBuffer(4 * 1024 * 1024);
  tempBuffer = null;

  await new Promise((r) => setTimeout(r, 500));

  const afterPerfMem = (performance as unknown as { memory?: { usedJSHeapSize: number } }).memory;
  const afterMB = afterPerfMem ? Math.round(afterPerfMem.usedJSHeapSize / (1024 * 1024)) : 0;
  const freedMB = (perfMem && afterPerfMem && beforeMB > afterMB) ? (beforeMB - afterMB) : (cachesDeleted > 0 ? 1 : 0);

  return { freedMB, beforeMB, afterMB, cachesDeleted };
}

// Real Download Speed Test (Zero fake speeds)
export async function runDownloadSpeedTest(onProgress?: (progress: number) => void): Promise<number | null> {
  const testUrl = 'https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js?_mina=' + Date.now();
  const startTime = performance.now();
  try {
    onProgress?.(30);
    const response = await fetch(testUrl, { cache: 'no-store' });
    onProgress?.(65);
    const blob = await response.blob();
    const endTime = performance.now();
    const durationSeconds = (endTime - startTime) / 1000;
    const bitsLoaded = blob.size * 8;
    const speedBps = bitsLoaded / durationSeconds;
    const speedMbps = +(speedBps / (1024 * 1024)).toFixed(2);
    onProgress?.(100);
    return Math.max(0.1, speedMbps);
  } catch {
    onProgress?.(100);
    return null; // Return null on error, NO fake numbers
  }
}
