# MINA OPTIMIZER PRO – Android APK Build

මෙම project එක Google AI Studio එකෙන් ලැබුණු React + TypeScript web app එක Capacitor හරහා Android app එකක් ලෙස package කිරීමට සකස් කර ඇත.

## APK එක ගැන
- මෙය දැනටමත් APK එකක් නොවේ.
- APK එක build කිරීම සඳහා Node.js, Java 21 සහ Android SDK අවශ්‍ය වේ.
- `.github/workflows/build-android-apk.yml` GitHub Actions workflow එක Android debug APK එක build කර Artifact එකක් ලෙස ලබා දෙයි.

## GitHub හරහා build කිරීම
1. මෙම ZIP එක unzip කර GitHub repository එකකට සියලුම files upload කරන්න.
2. Repository එකේ `Actions` tab එකට යන්න.
3. `Build MINA OPTIMIZER PRO APK` workflow එක තෝරන්න.
4. `Run workflow` ඔබන්න.
5. Build එක සාර්ථක වුණාම workflow run එකේ `Artifacts` යටතේ `Mina_Optimizer_Pro-debug-apk` download කරන්න.
6. ZIP artifact එක ඇතුළේ `app-debug.apk` ඇත.

## වැදගත් සීමා
- මෙය debug APK එකකි; Play Store release/signing සඳහා වෙනම release keystore එකක් අවශ්‍යයි.
- Web app එකේ ඇති සියලුම විශේෂාංග Android native hardware access ලබාගන්නා බව මෙයින් තහවුරු නොවේ. RAM cleanup, FPS overlay, screen recording, system settings වැනි දේවල් සඳහා native Android implementation සහ runtime permissions අවශ්‍ය විය හැක.
- YouTube Subscribe button එකෙන් channel එක විවෘත කළ හැක. නිල, අවසරලත් YouTube verification integration එකක් නොමැතිව සැබෑ subscription එක තහවුරු කළ නොහැක.
- Gemini API key හෝ වෙනත් රහස් key එකක් source code එකට commit නොකරන්න.
