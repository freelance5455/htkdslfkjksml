@echo off
REM ==========================================================================
REM Builds the Android installer (JCMS-FamilyCourt1-2.0.0-release.apk).
REM Needs on this PC: Node.js 20+, JDK 21 and the Android SDK (both come with
REM Android Studio) and internet access (first build downloads Gradle + libraries).
REM Output: the "dist" folder.  See ANDROID_GUIDE.md.
REM ==========================================================================
cd /d "%~dp0"
where node >nul 2>nul || (echo Node.js is not installed. Get the LTS version from https://nodejs.org & pause & exit /b 1)
if "%ANDROID_HOME%"=="" if "%ANDROID_SDK_ROOT%"=="" (
  if exist "%LOCALAPPDATA%\Android\Sdk" (set "ANDROID_HOME=%LOCALAPPDATA%\Android\Sdk") else (echo Android SDK not found. Install Android Studio first - see ANDROID_GUIDE.md & pause & exit /b 1)
)
if "%JAVA_HOME%"=="" if exist "%ProgramFiles%\Android\Android Studio\jbr" set "JAVA_HOME=%ProgramFiles%\Android\Android Studio\jbr"
echo.
echo [1/4] Installing dependencies...
call npm install || (echo npm install failed - see ANDROID_GUIDE.md, Troubleshooting & pause & exit /b 1)
echo.
echo [2/4] Checking the application code is unmodified...
call node verify\unmodified.js || (pause & exit /b 1)
echo.
echo [3/4] Building web assets...
call npm run build:web || (pause & exit /b 1)
call npx cap sync android || (pause & exit /b 1)
echo.
echo [4/4] Building the APK (a few minutes the first time)...
pushd android
call gradlew.bat assembleRelease || (popd & echo Build failed - see ANDROID_GUIDE.md, Troubleshooting & pause & exit /b 1)
popd
if not exist dist mkdir dist
copy /y "android\app\build\outputs\apk\release\*.apk" dist\ >nul
echo.
echo Done. Opening the dist folder...
start "" "%~dp0dist"
pause
