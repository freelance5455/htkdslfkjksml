# JCMS Family Court 1 - Android installer (APK)

This is the **same JCMS application** (dashboard, case registry, dispositions, Data Check, the three OCA reports,
export/merge) packaged as a standalone Android app. The application code in `app/` (`lib/`, `public/`, `templates/`)
is **byte-for-byte the code from `jcms.zip`** - `node verify/unmodified.js` proves it. Only the "shell" around it
changed, because a phone has no Node.js:

| Windows build | Android build |
|---|---|
| Electron window + Express server on 127.0.0.1 | Android WebView + a small in-app router running the **same `lib/app.js`** |
| `better-sqlite3` file in `%APPDATA%\JCMS Family Court 1\` | SQLite (sql.js/WASM), the **same official file format** (`jcms_snapshot` table), kept in the app's private storage |
| Reports/exports save to the Downloads folder | Reports/exports open the Android **share sheet** (Save to Drive/Files, open in Excel, send, print) |
| Needs nothing else installed | Needs nothing else installed (works fully offline) |

Like the Windows installer, **the APK never contains case data**. A new install starts empty; load the court's
database from inside the app (Part C).

---
## Part A - Build the APK (pick ONE way)

### A1. In the cloud with GitHub (no software to install)
1. Create a **private** GitHub repository and upload this whole folder (`ANDROID_GUIDE.md`, `android/`, `app/`, `src/`, ...).
2. Open the repository's **Actions** tab -> **Build JCMS APK** -> **Run workflow**.
3. When it turns green (about 5-10 minutes), open the run and download the artifact **JCMS-FamilyCourt1-apk**.
   Inside is `JCMS-FamilyCourt1-2.0.0-release.apk`.

### A2. On your Windows PC
1. Install **Node.js LTS** (https://nodejs.org) and **Android Studio** (https://developer.android.com/studio) - accept the defaults;
   Android Studio brings the Android SDK and the JDK. (If Android Studio asks, let it install "Android SDK Platform 36".)
2. Unzip this package, double-click **BUILD APK.bat**. The first build downloads Gradle and the Android libraries.
3. The APK appears in `dist\`.

### A3. In Android Studio
Run `npm install` and `npm run sync` once in this folder, then **File -> Open** the `android` folder and choose
**Build -> Generate Signed App Bundle / APK -> APK**, or simply run `./gradlew assembleRelease` in `android/`.

Linux/macOS: `./build-apk.sh`. Requirements: Node 20+, **JDK 21**, Android SDK (`ANDROID_HOME`).

## Part B - Install on the phone/tablet
1. Copy the APK to the device (USB cable, Google Drive, Bluetooth, e-mail to yourself...).
2. Tap the file. Android will ask to allow installs from that source (**Settings -> Install unknown apps** for the app you
   used, e.g. Files or Chrome) - allow it once, then tap **Install**. If Play Protect says "unknown developer" choose
   **Install anyway** (normal for an internal tool; the APK is not on the Play Store).
3. Open **JCMS Family Court 1**. Requires Android 7.0 or newer.

## Part C - Load the court's database and set up
1. In the app open **Settings & Data**.
2. Use **Merge another JCMS database** and choose `jcms_family_court.sqlite3` (put a copy of the file on the device first).
   The app should report 201 cases added. (It is the same merge used between the Civil/SP and Criminal PCs, so you can
   also bring in updates later without losing anything.)
3. Enter the Presiding Judge, Branch Clerk and Executive Judge names, **Save**.
4. Try **OCA Reports -> Preview -> Download .xlsx**: the Android share sheet opens; choose **Save to Drive/Files** or open it in Excel.
5. Close the app completely and reopen it: cases and names must still be there.

## Day-to-day notes
* **Where is the data?** In the app's private storage on that device only. It does not sync anywhere. Rolling backups
  (every 30 minutes of use, last 48) are kept in the app exactly as in the Windows build.
* **Take your own copy regularly:** **Settings & Data -> Download database (.sqlite3)**, then share it to Drive/USB. That file
  also opens in the Windows JCMS. *Uninstalling the app or "Clear storage" deletes the app's data* - export first.
* **Cloud backup is switched off** (`allowBackup=false`) on purpose, so confidential case records are not copied into a
  personal Google account. Moving to another phone = export the database, install the APK there, merge it.
* **Updating:** raise `versionCode`/`versionName` in `android/app/build.gradle` (e.g. 20001 / "2.0.1"), rebuild and install
  the new APK over the old one - data is kept. This only works because every build is signed with the same key
  (`android/jcms-release.keystore`). **Keep that file safe**: if you lose it, new APKs cannot update the installed app
  (you would have to export, uninstall, reinstall, merge). For wider distribution, create your own keystore and set
  `JCMS_KEYSTORE`, `JCMS_KEYSTORE_PASSWORD`, `JCMS_KEY_ALIAS`, `JCMS_KEY_PASSWORD` (as GitHub secrets in A1); the bundled
  key's password is in `app/build.gradle` and is meant for internal installs only.
* **Not carried over (desktop-only):** the `.bat` helpers, `tools/*.js`, `JCMS_HOST` (LAN sharing) and `JCMS_DB_PATH`.
  Use Merge/Export (above) to combine devices.
* **Network:** the app makes no network connections. (Android requires the INTERNET permission for any WebView app; if you
  want it removed, delete that line in `android/app/src/main/AndroidManifest.xml` and rebuild.)

## What was verified, and what was not
Verified in this build environment (`npm run verify`; needs the original jcms.zip extracted and `JCMS_ORIGINAL_DIR` set,
see `verify/common.js`):
* `unmodified` - all 13 application files identical to the original package.
* `api-parity` - the original `test/api-test.js` assertions (201 cases, 133 pending, create/edit/dispose/revive, Data Check,
  three OCA reports, CSV audit, SQLite export + re-import) pass on the in-app server, output identical to the Windows build.
* `report-parity` - SDIR, Docket Inventory Form and Monthly Report (MRC): **6,911 cells identical** (values, number formats,
  fills, bold) to the Windows build, plus identical audit CSVs.
* `ui-parity` - the original dashboard scenario (stats, registry filters, case modal, history/edit, add case, attention,
  report previews, Data Check, raffle dates, settings) passes with no page errors, including all report/export downloads.
* `persistence` - fresh install starts empty; imported data, edits, settings and deletions survive an app restart.

**Not verified here:** the APK itself was **not compiled or run on a device** - the build environment had no access to the
Android SDK/Gradle download servers. The Android-specific parts (Capacitor shell, share sheet, file picker, icon/splash)
are standard Capacitor 8 and are exercised the first time you build. If anything fails on the first build or on the
device, see Troubleshooting.

## Troubleshooting
* **`SDK location not found`** - set `ANDROID_HOME` (Windows default `%LOCALAPPDATA%\Android\Sdk`) or create
  `android/local.properties` with `sdk.dir=C\:\\Users\\YOU\\AppData\\Local\\Android\\Sdk`.
* **`Unsupported class file major version` / Java errors** - Capacitor 8 needs **JDK 21** (Android Studio's bundled JDK is fine).
* **`Failed to install the following Android SDK packages`** - open Android Studio -> SDK Manager and install
  *Android SDK Platform 36* and *Build-Tools*; accept licences (`sdkmanager --licenses`).
* **Download/Share does nothing** - the file is first written to the app cache, then the share sheet opens; if you cancel the
  sheet nothing is saved. Try again and pick *Save to Drive/Files*.
* **Import (Merge) can't see the file** - choose it through "Browse"/"Files"; the picker may hide `.sqlite3` files from
  Drive - copy it to the phone's Downloads first.
* **Layout looks cramped on a phone** - the dashboard's own responsive layout is used unchanged; a tablet or landscape
  mode gives the roomiest view.
* **Re-running the checks** - `npm install`, then `JCMS_ORIGINAL_DIR=/path/to/extracted/jcms npm run verify`.

## How it works (for maintainers)
`scripts/build-web.js` bundles the original `lib/` with esbuild into `www/jcms-core.js`, swapping four Node pieces for
in-app equivalents (`src/shims/`): `express` -> small router, `better-sqlite3` -> sql.js adapter, `fs` -> virtual files
persisted in IndexedDB, `exceljs` -> its official browser build (+ template read). `src/client.js` routes the dashboard's
`fetch('/api/...')` calls to that router and sends file downloads to the Android share sheet. `www/` = original
`app/public/` + `jcms-core.js`; Capacitor copies it into the APK (`npx cap sync android`).
