# JCMS Family Court 1 - Android (APK) build
Standalone Android installer for the unmodified JCMS application (RTC Family Court 1, Tagbilaran City).

* **Build + install + database loading:** see **ANDROID_GUIDE.md**
* Quick build (Windows): double-click **BUILD APK.bat** - output in `dist\`
* Quick build (cloud): push to a private GitHub repo, run the **Build JCMS APK** workflow
* The original application code is in `app/` (verified identical to jcms.zip with `node verify/unmodified.js`)

> JCMS is a caseload-monitoring tool only. It does not replace the official records; every report must be reviewed, printed and signed by the responsible officers. This package contains no case data - keep exported databases within the office.
