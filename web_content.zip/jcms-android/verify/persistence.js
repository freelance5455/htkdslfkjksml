// Close-and-reopen test: data written through the app must survive an app restart (new WebView process),
// and a brand-new install must start with an empty, working database (same as the Windows installer).
'use strict';
require('fake-indexeddb/auto');
const assert = require('assert');
const { OFFICIAL_DB, seedIDB } = require('./common'); const { loadApp } = require('./vmenv');
const J = async (app, m, p, b) => { const r = await app.fetch('https://localhost' + p, { method: m, headers: b ? { 'Content-Type': 'application/json' } : {}, body: b ? JSON.stringify(b) : undefined }); const t = await r.text(); let d; try { d = JSON.parse(t); } catch { d = t; } return { s: r.status, d }; };
(async () => {
  // 1. fresh install: no database yet
  await seedIDB(globalThis.indexedDB, null);
  let app = loadApp();
  let r = await J(app, 'GET', '/api/bootstrap'); assert.strictEqual(r.d.cases, 0); assert.strictEqual(r.d.db, 'jcms_family_court.sqlite3');
  r = await J(app, 'GET', '/api/stats'); assert.strictEqual(r.s, 200);
  console.log('fresh install: empty database, dashboard API works');
  // 2. import the official database through the Settings > import path
  const fs = require('fs');
  const imp = await app.fetch('https://localhost/api/import/sqlite', { method: 'POST', headers: { 'Content-Type': 'application/octet-stream' }, body: fs.readFileSync(OFFICIAL_DB) });
  const ij = await imp.json(); assert.strictEqual(ij.added, 201); assert.strictEqual(ij.total, 201);
  console.log('import of official database through the app:', JSON.stringify({ added: ij.added, total: ij.total }));
  // 3. edit, save settings, delete
  r = await J(app, 'POST', '/api/cases', { caseNo: 'PERSIST-1', title: 'A v. B', type: 'CV', category: 'Custody', filed: '2026-10-01', staff: 'Thalia Ursos' }); assert.strictEqual(r.s, 201); const id = r.d.case.id;
  r = await J(app, 'PUT', '/api/settings', { presidingJudge: 'Hon. Test Judge' }); assert.strictEqual(r.s, 200);
  r = await J(app, 'GET', '/api/cases?q=A%20v.%20B'); assert.strictEqual(r.d.total, 1);
  // 4. "kill the app" and start a new instance on the same storage
  app = loadApp();
  r = await J(app, 'GET', '/api/bootstrap'); assert.strictEqual(r.d.cases, 202); assert.strictEqual(r.d.settings.presidingJudge, 'Hon. Test Judge');
  r = await J(app, 'GET', '/api/cases/' + id); assert.strictEqual(r.d.case.caseNo, 'PERSIST-1');
  r = await J(app, 'DELETE', '/api/cases/' + id); assert.strictEqual(r.s, 200);
  app = loadApp();
  r = await J(app, 'GET', '/api/bootstrap'); assert.strictEqual(r.d.cases, 201);
  // 5. a delete stays deleted when an older copy is merged back (tombstone), backups were written
  const exp = Buffer.from(await (await app.fetch('https://localhost/api/export/sqlite')).arrayBuffer()); assert.strictEqual(exp.slice(0, 15).toString(), 'SQLite format 3');
  console.log('PERSISTENCE PASSED: data, settings and deletions survive restarts; export is a valid SQLite file (' + exp.length + ' bytes)');
})().catch(e => { console.error('FAIL', e); process.exit(1); });
