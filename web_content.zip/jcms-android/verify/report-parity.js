// Cell-by-cell comparison of the three OCA reports: original Node build vs Android in-app build.
'use strict';
require('fake-indexeddb/auto');
const fs = require('fs'); const path = require('path'); const os = require('os'); const assert = require('assert');
const ExcelJS = require('exceljs');
const { root, ORIGINAL, OFFICIAL_DB, seedIDB } = require('./common'); const { loadApp } = require('./vmenv');
const origLib = path.join(ORIGINAL, 'lib');
(async () => {
  await seedIDB(globalThis.indexedDB, OFFICIAL_DB);
  const app = loadApp();
  const tmp = path.join(os.tmpdir(), 'rp_' + Date.now() + '.sqlite3'); fs.copyFileSync(OFFICIAL_DB, tmp);
  const { Store } = require(origLib + '/store'); const R = require(origLib + '/reports');
  const store = new Store(tmp);
  const dump = async buf => { const wb = new ExcelJS.Workbook(); await wb.xlsx.load(buf); const o = [];
    wb.eachSheet(ws => ws.eachRow({ includeEmpty: false }, (row, r) => row.eachCell({ includeEmpty: false }, (c, n) => {
      const v = c.value && typeof c.value === 'object' ? JSON.stringify(c.value) : c.value;
      o.push([ws.name, r, n, v, c.numFmt, c.fill && c.fill.fgColor && c.fill.fgColor.argb, c.font && c.font.bold].join('|')); }))); return o; };
  let total = 0;
  for (const [t, q] of [['sdir', { year: '2026', half: '2' }], ['yearly', { year: '2026' }], ['mrc', { year: '2026', month: '9' }]]) {
    const o = await R.generate(t, store.cases, store.settings, { type: t, ...q });
    const a = await dump(Buffer.from(await o.wb.xlsx.writeBuffer()));
    const qs = new URLSearchParams({ type: t, ...q }).toString();
    const r = await app.fetch('https://localhost/api/reports/download?' + qs); assert.strictEqual(r.status, 200);
    assert.strictEqual(r.headers.get('content-disposition'), `attachment; filename="${o.filename}"`);
    const b = await dump(Buffer.from(await r.arrayBuffer()));
    assert.strictEqual(a.length, b.length, t + ': cell count'); a.forEach((x, i) => assert.strictEqual(x, b[i], `${t}: cell ${i}`));
    const ca = R.auditCsv(o.audit); const cb = Buffer.from(await (await app.fetch('https://localhost/api/reports/audit?' + qs)).arrayBuffer());
    assert(Buffer.from('\ufeff' + ca, 'utf8').equals(cb), t + ' audit csv (bytes, incl. BOM)');
    console.log(`${t}: ${a.length} cells + audit CSV identical to the Windows build`); total += a.length;
  }
  console.log('REPORT PARITY PASSED (' + total + ' cells)'); store.close();
})().catch(e => { console.error('FAIL', e); process.exit(1); });
