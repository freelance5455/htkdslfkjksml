// Proves the application code packaged in the APK is byte-for-byte the code from jcms.zip
// (lib/, public/, templates/): nothing in the functionality was modified.
'use strict';
const fs = require('fs'); const path = require('path'); const crypto = require('crypto');
const man = require('./original-sha256.json'); const app = path.join(__dirname, '..', 'app');
let bad = 0;
for (const [f, h] of Object.entries(man)) {
  const p = path.join(app, f); const got = fs.existsSync(p) ? crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex') : 'MISSING';
  if (got !== h) { bad++; console.error('CHANGED:', f); }
}
const walk = d => fs.readdirSync(d, { withFileTypes: true }).flatMap(e => e.isDirectory() ? walk(path.join(d, e.name)) : [path.join(d, e.name)]);
const extra = ['lib', 'public', 'templates'].flatMap(d => walk(path.join(app, d))).map(p => path.relative(app, p).split(path.sep).join('/')).filter(f => !man[f]);
extra.forEach(f => { bad++; console.error('EXTRA FILE:', f); });
if (bad) { console.error('FAIL: application files differ from the original package'); process.exit(1); }
console.log(`UNMODIFIED: all ${Object.keys(man).length} application files (lib/, public/, templates/) are identical to the original jcms.zip`);
