// Runs the ORIGINAL test/api-test.js assertions (201 cases, 133 pending, create/edit/dispose/revive,
// data check, all 3 OCA reports as .xlsx, CSV audit, SQLite export + re-import) against the Android
// build's in-app server instead of Express + better-sqlite3.
'use strict';
require('fake-indexeddb/auto');
const fs = require('fs'); const vm = require('vm'); const path = require('path'); const assert = require('assert');
const { root, ORIGINAL, OFFICIAL_DB, seedIDB } = require('./common');

(async () => {
  await seedIDB(globalThis.indexedDB, OFFICIAL_DB);
  // Run the bundle in a fresh context that, like the Android WebView, has no Node `process`/`require`.
  const ctx = vm.createContext({ console, setTimeout, clearTimeout, setInterval, clearInterval, queueMicrotask, structuredClone,
    indexedDB: globalThis.indexedDB, IDBKeyRange: globalThis.IDBKeyRange, TextEncoder, TextDecoder, URL, URLSearchParams, Response, Headers, Blob, atob, btoa,
    navigator: {}, document: { addEventListener() {}, createElement() { return {}; } }, location: { href: 'https://localhost/', origin: 'https://localhost' } });
  ctx.window = ctx; ctx.self = ctx;
  vm.runInContext(fs.readFileSync(path.join(root, 'www', 'jcms-core.js'), 'utf8'), ctx, { filename: 'jcms-core.js' });
  const appFetch = ctx.fetch;
  const base = 'https://localhost';
  const src = fs.readFileSync(path.join(ORIGINAL, 'test', 'api-test.js'), 'utf8');
  const a = src.indexOf('  try {\n', src.indexOf('const j = async')); const b = src.indexOf("    console.log('API TESTS PASSED');");
  const body = src.slice(a + 8, b) + "    console.log('API TESTS PASSED (Android in-app server)');";
  const E = require(path.join(root, 'app', 'lib', 'engine'));
  const AsyncFunction = Object.getPrototypeOf(async function () {}).constructor;
  const j = async (m, p, bd) => { const r = await appFetch(base + p, { method: m, headers: bd ? { 'Content-Type': 'application/json' } : {}, body: bd ? JSON.stringify(bd) : undefined }); const t = await r.text(); let d; try { d = JSON.parse(t); } catch { d = t; } return { s: r.status, d }; };
  await new AsyncFunction('assert', 'base', 'fetch', 'j', 'Buffer', 'E', body)(assert, base, appFetch, j, Buffer, E);
})().catch(e => { console.error('FAIL', e); process.exit(1); });
