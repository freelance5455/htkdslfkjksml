'use strict';
const fs = require('fs'); const path = require('path');
const root = path.join(__dirname, '..');
// The parity tests compare this build with the ORIGINAL Windows/Node build and use the court's database.
// Neither is shipped in this package: extract jcms.zip somewhere and set JCMS_ORIGINAL_DIR to its inner "jcms" folder
// (the one containing package.json, lib/ and data/). JCMS_OFFICIAL_DB can point at a different database file.
const ORIGINAL = process.env.JCMS_ORIGINAL_DIR || path.join(root, '..', 'jcms', 'jcms');
const OFFICIAL_DB = process.env.JCMS_OFFICIAL_DB || path.join(ORIGINAL, 'data', 'jcms_family_court.sqlite3');

// Put the official database where the app looks for it (IndexedDB), as if it had been imported earlier.
async function seedIDB(IDB, dbFile) {
  await new Promise((resolve, reject) => {
    const open = IDB.open('jcms-family-court-1', 1);
    open.onupgradeneeded = () => open.result.createObjectStore('files');
    open.onsuccess = () => {
      if (!dbFile) return resolve();
      const tx = open.result.transaction('files', 'readwrite');
      tx.objectStore('files').put(new Uint8Array(fs.readFileSync(dbFile)), '/data/jcms_family_court.sqlite3');
      tx.oncomplete = () => { open.result.close(); resolve(); }; tx.onerror = () => reject(tx.error);
    };
    open.onerror = () => reject(open.error);
  });
}
module.exports = { root, ORIGINAL, OFFICIAL_DB, seedIDB };
