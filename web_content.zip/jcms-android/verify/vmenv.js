'use strict';
// Loads www/jcms-core.js into a context that behaves like the Android WebView (no Node process/require)
const fs = require('fs'); const vm = require('vm'); const path = require('path');
const { root } = require('./common');
function loadApp() {
  const ctx = vm.createContext({ console, setTimeout, clearTimeout, setInterval, clearInterval, queueMicrotask, structuredClone,
    indexedDB: globalThis.indexedDB, IDBKeyRange: globalThis.IDBKeyRange, TextEncoder, TextDecoder, URL, URLSearchParams, Response, Headers, Blob, atob, btoa,
    navigator: {}, document: { addEventListener() {}, createElement() { return {}; } }, location: { href: 'https://localhost/', origin: 'https://localhost' } });
  ctx.window = ctx; ctx.self = ctx;
  vm.runInContext(fs.readFileSync(path.join(root, 'www', 'jcms-core.js'), 'utf8'), ctx, { filename: 'jcms-core.js' });
  return ctx;
}
module.exports = { loadApp };
