// Drives the ORIGINAL dashboard (index.html + app.js, as packaged in www/) in jsdom against the Android
// build's in-app server (no Express, no better-sqlite3), on a copy of the official database.
// Same scenario as the Windows build's test/ui-test.js, plus the download/share path used on Android.
'use strict';
require('fake-indexeddb/auto');
const fs = require('fs'); const path = require('path'); const assert = require('assert');
const { JSDOM, VirtualConsole, requestInterceptor } = require('jsdom');
const { root, OFFICIAL_DB, seedIDB } = require('./common');
const www = path.join(root, 'www');
const sleep = ms => new Promise(r => setTimeout(r, ms));
const ctype = f => (/\.js$/.test(f) ? 'application/javascript' : /\.png$/.test(f) ? 'image/png' : 'text/html');
const serveWww = requestInterceptor(req => { const u = new URL(req.url); if (u.origin !== 'https://localhost') return;
  const f = path.join(www, u.pathname === '/' ? 'index.html' : u.pathname);
  return fs.existsSync(f) ? new Response(fs.readFileSync(f), { headers: { 'Content-Type': ctype(f) } }) : new Response('', { status: 404 }); });
(async () => {
  await seedIDB(globalThis.indexedDB, OFFICIAL_DB);
  const errors = []; const downloads = [];
  const vc = new VirtualConsole(); vc.on('jsdomError', e => errors.push('jsdomError: ' + e.message + ' ' + (e.detail || '') + ' ' + String(e.stack).split('\n').slice(1, 6).join(' / '))); vc.on('error', e => errors.push('console.error: ' + e));
  try {
    const dom = await JSDOM.fromURL('https://localhost/', { runScripts: 'dangerously', resources: { interceptors: [serveWww] }, pretendToBeVisual: true, virtualConsole: vc,
      beforeParse(w) {
        w.indexedDB = globalThis.indexedDB; w.IDBKeyRange = globalThis.IDBKeyRange; w.Response = Response; w.Headers = Headers; w.TextEncoder = TextEncoder; w.TextDecoder = TextDecoder;
        w.structuredClone = structuredClone; w.queueMicrotask = queueMicrotask; w.fetch = (u, o) => fetch(u, o);
        w.confirm = () => true; w.alert = m => errors.push('alert: ' + m); w.scrollTo = () => {}; w.Element.prototype.scrollIntoView = () => {};
        w.URL.createObjectURL = () => 'blob:jcms-test'; w.URL.revokeObjectURL = () => {};
        // jsdom cannot perform a real blob download: record it instead (Chromium/Android WebView use Share, see src/client.js)
        const click0 = w.HTMLAnchorElement.prototype.click;
        w.HTMLAnchorElement.prototype.click = function () { if (this.href.startsWith('blob:')) { downloads.push({ name: this.download, size: this.__size }); return; } return click0.call(this); };
        const Blob0 = w.Blob; w.Blob = function (parts, o) { const b = new Blob0(parts, o); b.__bytes = parts.reduce((n, p) => n + p.byteLength, 0); return b; }; w.Blob.prototype = Blob0.prototype;
        const cu = w.URL.createObjectURL; w.URL.createObjectURL = blob => { w.__lastSize = blob.__bytes; return cu(blob); };
        const ce = w.document.createElement.bind(w.document); w.document.createElement = t => { const el = ce(t); if (t === 'a') Object.defineProperty(el, '__size', { get: () => w.__lastSize }); return el; };
      } });
    const w = dom.window, $ = s => w.document.querySelector(s), $$ = s => [...w.document.querySelectorAll(s)];
    const snap = async () => JSON.parse(await (await w.fetch('/api/export/json')).text());
    const wait = async (cond, label, ms = 8000) => { const t0 = Date.now(); while (Date.now() - t0 < ms) { if (await cond()) return; await sleep(60); } throw new Error('timeout waiting for: ' + label); };
    const click = el => el.dispatchEvent(new w.MouseEvent('click', { bubbles: true, cancelable: true }));

    await wait(() => $$('#stats .stat').length === 8, 'dashboard stats');
    console.log('1. dashboard: stats =', $$('#stats .stat').map(e => e.querySelector('.l').textContent + '=' + e.querySelector('.v').textContent).join(' | '));
    assert.strictEqual($('#stats .stat .v').textContent, '133');
    assert($$('#dAtt .ribbon').length === 8); assert($('#dTrend svg')); assert($('#derivedBanner .banner'));
    console.log('   attention ribbons:', $$('#dAtt .ribbon').length, '| staff bars:', $$('#dStaff .bar').length, '| upcoming rows:', $$('#dUp tbody tr').length, '| derived banner shown, chart svg ok');

    click($$('#tabs button')[1]); await wait(() => $$('#rbody tr.click').length > 0, 'registry rows');
    console.log('2. registry: rows =', $$('#rbody tr.click').length, '| info:', $('#rinfo').textContent);
    $('#rfilter').value = 'overdue'; $('#rfilter').dispatchEvent(new w.Event('change')); const st = await (await w.fetch('/api/stats')).json(); await wait(() => new RegExp('^' + st.overdue + ' case').test($('#rinfo').textContent), 'overdue filter (' + st.overdue + ')');
    $('#rfilter').value = 'closed'; $('#rfilter').dispatchEvent(new w.Event('change')); await wait(() => /68 case/.test($('#rinfo').textContent), 'closed filter');
    console.log('   overdue filter ->', st.overdue, '(matches the dashboard), closed filter ->', $('#rinfo').textContent);
    $('#rfilter').value = 'open'; $('#rfilter').dispatchEvent(new w.Event('change')); await sleep(300); $('#rq').value = '31042-2025'; $('#rq').dispatchEvent(new w.Event('input')); await wait(() => $$('#rbody tr.click').length === 1, 'search');

    click($('#rbody tr.click')); await wait(() => $('#ov').classList.contains('on') && $('#mBody').innerHTML.length > 200, 'modal');
    console.log('3. modal:', $('#mTitle').textContent.slice(0, 60), '| overview has report fields:', /Fields used in the OCA reports/.test($('#mBody').textContent));
    for (const t of ['hi', 'ed', 'di']) { click($(`#mTabs button[data-t="${t}"]`)); assert($('#mBody').innerHTML.length > 100, 'tab ' + t); }
    click($('#mTabs button[data-t="hi"]')); $('#hText').value = 'Order (Pre-trial reset to November 12, 2026)'; $('#hDate').value = '2026-10-03'; click($('#hAdd'));
    await wait(() => /November 12, 2026/.test($('#mBody').textContent), 'history entry added');
    click($('#mTabs button[data-t="ed"]')); $('#ed-remarks').value = 'UI test remark'; click($('#edSave'));
    await wait(async () => (await snap()).cases.find(c => c.caseNo === '31042-2025').remarks === 'UI test remark', 'edit saved');
    console.log('   history add + edit save work (persisted to the database)');
    click($('#mClose'));

    click($$('#tabs button')[2]); await wait(() => $('#new-caseNo'), 'add form');
    $('#new-caseNo').value = 'UI-TEST-1'; $('#new-title').value = 'UI Test v. Test'; $('#new-filed').value = '2026-10-01'; $('#new-type').value = 'SP'; $('#new-category').value = 'Guardianship';
    click($('#addSave')); await wait(async () => (await snap()).cases.some(c => c.caseNo === 'UI-TEST-1'), 'case created');
    console.log('4. add case form saved ->', (await snap()).cases.length, 'cases');
    click($('#mClose'));

    click($$('#tabs button')[3]); await wait(() => $$('#attList .ribbon').length > 5, 'attention list');
    console.log('5. attention:', $$('#attList .ribbon').length, 'cases');

    click($$('#tabs button')[4]); await wait(() => $$('#repCards .card').length === 3, 'report cards');
    for (const t of ['sdir', 'yearly', 'mrc']) { click($(`[data-act="preview"][data-t="${t}"]`)); await wait(() => new RegExp(t === 'sdir' ? 'Semestral' : t === 'yearly' ? 'Docket Inventory Form' : 'Monthly Report').test($('#repPreview').textContent), 'preview ' + t); console.log('6. report preview ok:', t, '|', $('#repPreview h3').textContent.slice(0, 70), '| warnings box:', !!$('#repPreview .warnbox')); }
    assert($$('#repPreview table').length >= 2, 'mrc tables');
    for (const [act, t, ext] of [['download', 'sdir', '.xlsx'], ['download', 'yearly', '.xlsx'], ['download', 'mrc', '.xlsx'], ['audit', 'sdir', '.csv'], ['trace', 'mrc', '.csv']]) {
      const n = downloads.length; click($(`[data-act="${act}"][data-t="${t}"]`)); await wait(() => downloads.length > n, 'download ' + act + ' ' + t);
      const d = downloads[downloads.length - 1]; assert(d.name.endsWith(ext) && d.size > 500, 'bad download ' + JSON.stringify(d)); console.log('   download ->', d.name, d.size + ' bytes');
    }

    click($$('#tabs button')[5]); await wait(() => $$('#chkBody .card').length === 5 && $('#chkBody table'), 'data check');
    console.log('7. data check cards:', $$('#chkBody .card h3').map(h => h.textContent.replace(/\s+/g, ' ').trim()).join(' | '));
    const before = (await snap()).cases.filter(c => c.dateRaffled).length; click($('#rfSave')); await wait(async () => (await snap()).cases.filter(c => c.dateRaffled).length > before, 'raffle saved');
    console.log('   raffle dates saved for', (await snap()).cases.filter(c => c.dateRaffled).length, 'cases (visible batch)');

    click($$('#tabs button')[6]); await wait(() => $('#setSave'), 'settings');
    $('#s-presidingJudge').value = 'JUDGE TEST NAME'; click($('#setSave')); await wait(async () => (await snap()).settings.presidingJudge === 'JUDGE TEST NAME', 'settings saved');
    console.log('8. settings saved; export links:', $$('#setBody a.btn').map(a => a.getAttribute('href')).join(', '));
    for (const a of $$('#setBody a.btn')) { const n = downloads.length; click(a); await wait(() => downloads.length > n, 'export ' + a.getAttribute('href')); console.log('   export ->', downloads[downloads.length - 1].name, downloads[downloads.length - 1].size + ' bytes'); }
    if (errors.length) throw new Error('Page errors:\n' + errors.join('\n'));
    console.log('UI TESTS PASSED (no page errors)');
    w.close();
    console.log('UI PARITY PASSED (Android build)');
  } catch (e) { console.error('FAIL:', e.message); if (errors.length) console.error(errors.join('\n')); process.exitCode = 1; }
  finally { setTimeout(() => process.exit(), 200); }
})();
