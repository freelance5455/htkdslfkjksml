'use strict';
const { spawnSync } = require('child_process'); const path = require('path'); const fs = require('fs');
const { OFFICIAL_DB, ORIGINAL } = require('./common');
let fail = 0;
for (const t of ['unmodified', 'persistence', 'api-parity', 'report-parity', 'ui-parity']) {
  if (t !== 'unmodified' && !fs.existsSync(OFFICIAL_DB)) { console.log(`\n== ${t}: SKIPPED (extract jcms.zip and set JCMS_ORIGINAL_DIR=<path to its inner jcms folder>)`); continue; }
  console.log(`\n== ${t}`);
  const r = spawnSync(process.execPath, [path.join(__dirname, t + '.js')], { stdio: ['ignore', 'pipe', 'inherit'], env: process.env, encoding: 'utf8' });
  const lines = r.stdout.trim().split('\n'); console.log(lines.slice(-3).join('\n'));
  if (r.status !== 0) fail++;
}
console.log(fail ? `\n${fail} SUITE(S) FAILED` : '\nALL VERIFICATION SUITES PASSED'); process.exit(fail ? 1 : 0);
