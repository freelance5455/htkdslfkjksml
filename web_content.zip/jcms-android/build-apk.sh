#!/usr/bin/env bash
# Builds the standalone installer (APK) on Linux/macOS. Needs: Node.js 20+, JDK 21, Android SDK (ANDROID_HOME set).
set -euo pipefail
cd "$(dirname "$0")"
command -v node >/dev/null || { echo "Node.js is not installed (https://nodejs.org)"; exit 1; }
command -v java >/dev/null || { echo "JDK 21 is not installed"; exit 1; }
[ -n "${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}" ] || { echo "Set ANDROID_HOME to your Android SDK folder (installed with Android Studio)"; exit 1; }
echo "[1/4] Installing dependencies..."; npm ci || npm install
echo "[2/4] Checking the application code is unmodified..."; node verify/unmodified.js
echo "[3/4] Building web assets..."; npm run build:web && npx cap sync android
echo "[4/4] Building the APK (first build downloads Gradle + Android libraries)..."
(cd android && chmod +x gradlew && ./gradlew assembleRelease)
mkdir -p dist && cp android/app/build/outputs/apk/release/*.apk dist/
echo; echo "Done:"; ls -1 dist/*.apk
