package ph.gov.judiciary.rtcfamilycourt1.jcms;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
