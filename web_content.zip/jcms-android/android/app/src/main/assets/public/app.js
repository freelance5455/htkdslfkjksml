'use strict';
/* JCMS dashboard - works on the official case model (camelCase record). */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, m => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[m]));
const MON = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
const isISO = s => /^\d{4}-\d{2}-\d{2}$/.test(s || '');
const fmtD = s => (isISO(s) ? `${+s.slice(8)} ${MON[+s.slice(5, 7) - 1]} ${s.slice(0, 4)}` : '');
let B = {};            // bootstrap data
let cur = null;        // case currently open in the modal
let curTab = 'ov';
let activeView = 'dash';
const R = { page: 1, q: '', filter: 'open', type: '', status: '', staff: '', sort: 'due' };

function toast(msg, err) {
  const t = $('#toast'); t.textContent = msg; t.className = 'toast on' + (err ? ' err' : '');
  clearTimeout(toast.t); toast.t = setTimeout(() => { t.className = 'toast'; }, err ? 6000 : 3000);
}
async function api(path, opts = {}) {
  const init = { method: opts.method || 'GET', headers: {} };
  if (opts.json !== undefined) { init.headers['Content-Type'] = 'application/json'; init.body = JSON.stringify(opts.json); }
  if (opts.body !== undefined) { init.headers['Content-Type'] = 'application/octet-stream'; init.body = opts.body; }
  const r = await fetch(path, init); const t = await r.text(); let d; try { d = JSON.parse(t); } catch (e) { d = t; }
  if (!r.ok) throw new Error((d && d.error) || `Request failed (${r.status})`);
  return d;
}
const guard = fn => async (...a) => { try { return await fn(...a); } catch (e) { toast(e.message, true); } };
const today = () => B.today || new Date().toISOString().slice(0, 10);

/* ------------------------------------------------------------------ nav */
const LOADERS = { dash: () => loadDash(), reg: () => loadReg(), add: () => renderAdd(), att: () => loadAtt(), rep: () => renderReports(), chk: () => loadChk(), set: () => renderSettings() };
function show(v) {
  activeView = v;
  $$('section.view').forEach(s => s.classList.toggle('on', s.id === 'v-' + v));
  $$('#tabs button').forEach(b => b.classList.toggle('on', b.dataset.v === v));
  guard(LOADERS[v])(); window.scrollTo(0, 0);
}
document.addEventListener('click', e => {
  const t = e.target.closest('#tabs button'); if (t) return show(t.dataset.v);
  const g = e.target.closest('[data-go]'); if (g) return show(g.dataset.go);
  const o = e.target.closest('[data-open]'); if (o) return guard(openCase)(o.dataset.open);
  const n = e.target.closest('[data-nav]'); if (n) { const o2 = JSON.parse(n.dataset.nav); return goReg(o2); }
});
function goReg(o) {
  Object.assign(R, { page: 1, q: '', type: '', status: '', staff: '', filter: 'open', sort: 'due' }, o);
  $('#rq').value = R.q; $('#rfilter').value = R.filter; $('#rtype').value = R.type; $('#rstatus').value = R.status; $('#rstaff').value = R.staff; $('#rsort').value = R.sort;
  show('reg');
}
function tick() {
  const n = new Date();
  $('#clock').textContent = `${n.toLocaleDateString('en-PH', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}  ${n.toLocaleTimeString('en-PH', { hour: '2-digit', minute: '2-digit' })}`;
}

/* ------------------------------------------------------------ dashboard */
const badgeFor = r => {
  if (r.overdue) return `<span class="badge b-bad">Overdue ${-r.daysToDue}d</span>`;
  if (r.dueSoon) return `<span class="badge b-warn">${r.daysToDue === 0 ? 'Due today' : 'Due in ' + r.daysToDue + 'd'}</span>`;
  if (r.decisionAlert) return '<span class="badge b-warn">Decision deadline</span>';
  return `<span class="badge b-slate">${esc(r.priority)}</span>`;
};
function ribbon(r) {
  const cls = r.overdue || (r.reasons || []).some(x => /passed/.test(x)) ? 'bad' : (r.dueSoon || r.decisionAlert || r.priority === 'Urgent' ? 'warn' : 'ok');
  return `<div class="ribbon ${cls}" data-open="${esc(r.id)}"><div><span class="no">${esc(r.caseNo)}</span> <span class="badge t-${esc(r.type)}">${esc(r.type)}</span>
    <div class="ti">${esc(r.title)}</div><div class="su">${esc(r.status)} - ${esc(r.next || 'no next action set')}${r.staff ? ' - ' + esc(r.staff) : ''}</div></div>
    <div class="rt">${badgeFor(r)}<div class="su">${r.due ? fmtD(r.due) : ''}</div></div></div>`;
}
const bars = (items, max, fmt) => items.map(([n, v, extra]) => `<div class="bar"><div class="n" title="${esc(n)}">${esc(n)}</div><div class="t"><div class="fl" style="width:${max ? v / max * 100 : 0}%"></div></div><div class="c">${fmt ? fmt(v, extra) : v}</div></div>`).join('');

async function loadDash() {
  const [s, att] = await Promise.all([api('/api/stats'), api('/api/attention?limit=8')]);
  const cards = [
    ['Total pending', s.totalPending, '', { filter: 'open' }], ['For hearing', s.forHearing, '', { status: 'For Hearing' }],
    ['For resolution', s.forResolution, '', { status: 'For Resolution' }], ['Awaiting compliance', s.awaitingCompliance, '', { status: 'Awaiting Compliance' }],
    ['New', s.newCases, '', { status: 'New' }], ['Overdue actions', s.overdue, 'bad', { filter: 'overdue' }],
    [`Due in ${s.alertDays} days`, s.dueSoon, 'warn', { filter: 'dueSoon' }], ['Decision deadlines', s.decisionAlerts, s.decisionAlerts ? 'warn' : '', { filter: 'attention' }],
  ];
  $('#stats').innerHTML = cards.map(([l, v, c, nav]) => `<div class="stat ${c}" data-nav='${JSON.stringify(nav)}'><div class="l">${esc(l)}</div><div class="v">${v}</div></div>`).join('');
  $('#derivedBanner').innerHTML = s.derivedClosed ? `<div class="banner" data-go="chk"><b>${s.derivedClosed} case(s)</b> are treated as archived/transferred because their history says so while their status still reads pending. They are excluded from the pending totals. Click to review in Data Check.</div>` : '';
  $('#dAtt').innerHTML = att.rows.length ? att.rows.map(ribbon).join('') : '<div class="empty">Nothing is currently flagged.</div>';
  const pt = s.pendingByType, tmax = Math.max(1, pt.CR, pt.CV, pt.SP);
  $('#dType').innerHTML = bars([['Criminal (CR)', pt.CR], ['Civil (CV)', pt.CV], ['Special Proceedings (SP)', pt.SP]], tmax);
  const smax = Math.max(1, ...s.byStaff.map(x => x.pending));
  $('#dStaff').innerHTML = bars(s.byStaff.map(x => [x.name, x.pending, x.overdue]), smax, (v, o) => `${v}${o ? ` <span style="color:var(--bad)">(${o} od)</span>` : ''}`);
  const lab = ['< 1 yr', '1-2 yrs', '2-3 yrs', '3-4 yrs', '4-5 yrs', '5-6 yrs', '6-7 yrs', '7-8 yrs', '8-9 yrs', '9-10 yrs', '10+ yrs'];
  const amax = Math.max(1, ...s.aging);
  $('#dAge').innerHTML = bars(s.aging.map((v, i) => [lab[i], v]).filter(x => x[1] > 0), amax);
  $('#upTitle').textContent = `Upcoming hearings / actions (next ${s.alertDays} days)`;
  $('#dUp').innerHTML = s.upcoming.length ? `<table class="t"><thead><tr><th>Date</th><th>Case</th><th>Next action</th><th>Staff</th></tr></thead><tbody>${s.upcoming.map(u =>
    `<tr class="click" data-open="${esc(u.id)}"><td>${fmtD(u.due)}</td><td><b>${esc(u.caseNo)}</b> <span class="badge t-${esc(u.type)}">${esc(u.type)}</span><br><span style="color:var(--soft)">${esc(u.title)}</span></td><td>${esc(u.next)}</td><td>${esc(u.staff)}</td></tr>`).join('')}</tbody></table>` : '<div class="empty">No hearings or actions are scheduled in this window.</div>';
  $('#dTrend').innerHTML = trendSvg(s.trend);
  setCount('attCount', s.attention);
}
function setCount(id, n) { const el = $('#' + id); el.textContent = n; el.style.display = n ? 'inline' : 'none'; }
function trendSvg(t) {
  const max = Math.max(1, ...t.map(x => Math.max(x.filed, x.disposed))), W = 520, H = 190, bw = 14, gap = (W - 30) / t.length;
  let o = `<svg viewBox="0 0 ${W} ${H + 28}" style="width:100%;height:auto" role="img" aria-label="Filed versus disposed per month">`;
  t.forEach((m, i) => {
    const x = 20 + i * gap, h1 = m.filed / max * (H - 24), h2 = m.disposed / max * (H - 24);
    o += `<rect x="${x}" y="${H - h1}" width="${bw}" height="${h1}" fill="#1B3A66"><title>${m.label}: ${m.filed} filed</title></rect>`;
    o += `<rect x="${x + bw + 1}" y="${H - h2}" width="${bw}" height="${h2}" fill="#C9A227"><title>${m.label}: ${m.disposed} disposed</title></rect>`;
    if (m.filed) o += `<text x="${x + bw / 2}" y="${H - h1 - 3}" font-size="9" text-anchor="middle" fill="#1B3A66">${m.filed}</text>`;
    if (m.disposed) o += `<text x="${x + bw * 1.5 + 1}" y="${H - h2 - 3}" font-size="9" text-anchor="middle" fill="#8F7112">${m.disposed}</text>`;
    o += `<text x="${x + bw}" y="${H + 14}" font-size="9" text-anchor="middle" fill="#555B66">${m.label}</text>`;
  });
  return o + `<text x="20" y="${H + 26}" font-size="10" fill="#1B3A66">&#9632; Filed</text><text x="80" y="${H + 26}" font-size="10" fill="#8F7112">&#9632; Disposed</text></svg>`;
}

/* ------------------------------------------------------------- registry */
async function loadReg() {
  const closedStatus = B.closedStatuses.includes(R.status);
  const p = new URLSearchParams({ q: R.q, filter: closedStatus ? 'all' : R.filter, type: R.type, status: R.status, staff: R.staff, sort: R.sort, page: R.page, pageSize: 100 });
  const d = await api('/api/cases?' + p);
  $('#rbody').innerHTML = d.rows.length ? d.rows.map(r => {
    const next = r.closed ? `<span class="badge b-slate">${esc(r.closeKind || 'Closed')}</span> ${fmtD(r.closeDate)}`
      : (!r.due ? '<span class="badge b-slate">no date</span>' : `${fmtD(r.due)} ${r.overdue ? `<span class="badge b-bad">overdue ${-r.daysToDue}d</span>` : r.dueSoon ? `<span class="badge b-warn">${r.daysToDue === 0 ? 'today' : 'in ' + r.daysToDue + 'd'}</span>` : ''}`);
    return `<tr class="click ${r.closed ? 'cl' : r.overdue ? 'od' : r.dueSoon ? 'ds' : ''}" data-open="${esc(r.id)}"><td><b>${esc(r.caseNo)}</b></td><td><span class="badge t-${esc(r.type)}">${esc(r.type)}</span></td>
      <td><b>${esc(r.title)}</b><br><span style="color:var(--soft)">${esc((r.category || '').slice(0, 110))}</span></td><td>${esc(r.status)}${r.closeDerived ? '<br><span class="badge b-blue">per history</span>' : ''}</td><td>${esc(r.staff)}</td><td>${esc(r.next)}</td><td>${next}</td><td>${fmtD(r.last)}</td></tr>`;
  }).join('') : '<tr><td colspan="8" class="empty">No cases match these filters.</td></tr>';
  const pages = Math.max(1, Math.ceil(d.total / d.pageSize));
  $('#rinfo').textContent = `${d.total} case(s) - page ${d.page} of ${pages}`;
  $('#rprev').disabled = d.page <= 1; $('#rnext').disabled = d.page >= pages;
}
function bindRegistry() {
  let t; $('#rq').addEventListener('input', e => { clearTimeout(t); t = setTimeout(() => { R.q = e.target.value; R.page = 1; guard(loadReg)(); }, 250); });
  for (const [id, k] of [['rfilter', 'filter'], ['rtype', 'type'], ['rstatus', 'status'], ['rstaff', 'staff'], ['rsort', 'sort']]) $('#' + id).addEventListener('change', e => { R[k] = e.target.value; R.page = 1; guard(loadReg)(); });
  $('#rprev').onclick = () => { R.page--; guard(loadReg)(); }; $('#rnext').onclick = () => { R.page++; guard(loadReg)(); };
}

/* ----------------------------------------------------------- case forms */
const GROUPS = () => [
  ['Case identification', false, [['caseNo', 'Case number *', 'text'], ['type', 'Case type *', 'sel', B.types.map(t => [t, { CR: 'Criminal (CR)', CV: 'Civil (CV)', SP: 'Special Proceedings (SP)' }[t]])], ['filed', 'Date filed *', 'date'], ['priority', 'Priority', 'sel', B.priorities.map(p => [p, p])],
    ['title', 'Case title *', 'text', 's2'], ['category', 'Nature / offense / cause of action', 'text', 's2'], ['parties', 'Other parties / notes', 'text', 's2'], ['staff', 'Assigned staff', 'list']]],
  ['Status and schedule', false, [['status', 'Status', 'sel', B.statuses.map(s => [s, s])], ['due', 'Next hearing / action date', 'date'], ['next', 'Next action', 'text', 's2'], ['last', 'Last action date', 'date'], ['remarks', 'Remarks', 'area', 's4']]],
  ['Decision deadline', false, [['submitted', 'Date submitted for decision / resolution', 'date'], ['decisionDue', 'Decision due date', 'date', '', 'Blank = 90 days from submission (Const. Art. VIII, Sec. 15).'], ['deadlineSource', 'Rule / basis for the deadline', 'text', 's2']]],
  ['OCA report fields', true, [['civilClassification', 'Civil classification (SDIR section)', 'sel', [['', 'Automatic (CV = Ordinary, SP = Special Proc.)'], ...B.civilClasses.map(c => [c, c])]], ['dateRaffled', 'Date raffled', 'date'], ['dateArraignment', 'Date of arraignment', 'date'],
    ['datePreTrial', 'Date of pre-trial', 'date'], ['dateInitialTrial', 'Date of initial trial', 'date'], ['courtAction', 'Court action taken (blank = latest history entry)', 'text', 's2'], ['courtActionDate', 'Date of that action', 'date'],
    ['mrcNature', 'Monthly Report category', 'sel', [['', 'Automatic'], ...Object.entries(B.natureLabels)]]]],
  ['Disposition fields (normally set on the Disposition tab)', true, [['dispositionType', 'Disposition type', 'sel', [['', '-'], ...B.dispositions.map(d => [d, d === 'Compromise/JDR' ? 'Non-merits (compromise / JDR / plea bargain / procedural dismissal)' : d])]], ['terminated', 'Date terminated', 'date'], ['dateDisposed', 'Date decided / resolved', 'date'], ['dateArchived', 'Date archived', 'date'],
    ['dateTransferred', 'Date transferred', 'date'], ['transferredTo', 'Transferred to', 'text', 's2'], ['dateReinstated', 'Date revived / reinstated', 'date']]],
  ['Incident / motion tracking', true, [['incident', 'Incident / motion', 'text', 's2'], ['incidentType', 'Type', 'text'], ['incidentStatus', 'Incident status', 'sel', [['', '-'], ...B.incidentStatuses.map(s => [s, s])]], ['incidentDate', 'Incident date', 'date'], ['incidentDue', 'Incident due', 'date'], ['prayer', 'Prayer', 'text', 's2'], ['incidentSource', 'Source', 'text']]],
];
function formHTML(c, idp) {
  const row = f => {
    const [k, label, kind, a, b] = f;
    const span = typeof a === 'string' ? a : '';           // 's2' / 's4' / ''
    const options = Array.isArray(a) ? a : null;
    const hint = (kind === 'date' && typeof b === 'string' && b) ? b : (typeof b === 'string' && !Array.isArray(a) ? b : '');
    const id = `${idp}-${k}`, v = c[k] == null ? '' : c[k];
    let input;
    if (kind === 'sel') input = `<select id="${id}">${options.map(([val, lb]) => `<option value="${esc(val)}"${String(v) === String(val) ? ' selected' : ''}>${esc(lb)}</option>`).join('')}</select>`;
    else if (kind === 'area') input = `<textarea id="${id}" rows="3">${esc(v)}</textarea>`;
    else if (kind === 'list') input = `<input type="text" id="${id}" list="${idp}-staffs" value="${esc(v)}"><datalist id="${idp}-staffs">${(B.staff || []).map(s => `<option value="${esc(s)}">`).join('')}</datalist>`;
    else input = `<input type="${kind}" id="${id}" value="${esc(v)}">`;
    return `<div class="f ${span}"><label for="${id}">${esc(label)}</label>${input}${hint ? `<span class="hint">${esc(hint)}</span>` : ''}</div>`;
  };
  return GROUPS().map(([title, fold, fields]) => fold
    ? `<details class="fold form"><summary>${esc(title)}</summary><div class="g">${fields.map(row).join('')}</div></details>`
    : `<div class="form"><h3>${esc(title)}</h3><div class="g">${fields.map(row).join('')}</div></div>`).join('');
}
function readForm(idp) {
  const o = {};
  for (const [, , fields] of GROUPS()) for (const f of fields) { const el = $(`#${idp}-${f[0]}`); if (el) o[f[0]] = el.value; }
  o.hearing = o.due;                                          // official data keeps hearing = next action date
  return o;
}

function renderAdd() {
  const c = { type: 'CR', status: 'New', priority: 'Medium', last: today() };
  $('#addForm').innerHTML = formHTML(c, 'new') + `<div class="tools"><button class="btn gold" id="addSave">Save case</button><button class="btn sec" id="addClear">Clear</button></div>`;
  $('#addSave').onclick = guard(async () => {
    const d = await api('/api/cases', { method: 'POST', json: readForm('new') });
    toast(`Case ${d.case.caseNo} saved.`); renderAdd(); openCase(d.case.id);
  });
  $('#addClear').onclick = renderAdd;
}

/* ---------------------------------------------------------- case modal */
async function openCase(id, tab) {
  cur = await api('/api/cases/' + id);
  $('#ov').classList.add('on'); mTab(tab || 'ov');
}
function closeModal() { $('#ov').classList.remove('on'); cur = null; }
function refreshBehind() { if (activeView === 'dash') loadDash(); else if (activeView === 'reg') loadReg(); else if (activeView === 'att') loadAtt(); else if (activeView === 'chk') loadChk(); }
const srcBadge = s => s === 'record' ? '<span class="badge b-ok">recorded</span>' : s === 'history' ? '<span class="badge b-blue">from history</span>' : '<span class="badge b-slate">not yet</span>';

function mTab(t) {
  curTab = t;
  $$('#mTabs button').forEach(b => b.classList.toggle('on', b.dataset.t === t));
  const c = cur.case, dv = cur.derived;
  $('#mTitle').textContent = `${c.caseNo} - ${c.title}`;
  $('#mSub').innerHTML = `${esc(c.type)} - ${esc(c.status)}${dv.closure.closed ? ' - ' + esc(dv.closure.kind) + ' ' + fmtD(dv.closure.date) : ''}`;
  const body = $('#mBody');
  if (t === 'ov') body.innerHTML = tabOverview();
  else if (t === 'hi') { body.innerHTML = tabHistory(); bindHistory(); }
  else if (t === 'ed') { body.innerHTML = formHTML(c, 'ed') + `<div class="tools"><button class="btn gold" id="edSave">Save changes</button></div>`; $('#edSave').onclick = guard(async () => { await api('/api/cases/' + c.id, { method: 'PUT', json: readForm('ed') }); toast('Saved.'); await openCase(c.id, 'ed'); refreshBehind(); }); }
  else { body.innerHTML = tabDispose(); bindDispose(); }
}
function tabOverview() {
  const c = cur.case, dv = cur.derived, m = dv.milestones, u = dv.urgency;
  const kv = (k, v) => `<div><div class="k">${esc(k)}</div><div class="v">${v || '<span style="color:var(--soft)">-</span>'}</div></div>`;
  const ms = (label, x) => kv(label, x.v ? `${fmtD(x.v)} ${srcBadge(x.src)}` : srcBadge(''));
  const reasons = (u.reasons || []).map(r => `<span class="badge ${/overdue|passed/i.test(r) ? 'b-bad' : 'b-warn'}">${esc(r)}</span>`).join('');
  const lc = dv.lifecycle;
  return `<div class="chips"><span class="badge t-${esc(c.type)}">${esc(c.type)}</span><span class="badge b-slate">${esc(c.status)}</span><span class="badge b-slate">${esc(c.priority)}</span>${reasons}</div>
  <div class="kv">${kv('Nature / offense', esc(c.category))}${kv('Date filed', fmtD(c.filed))}${kv('Assigned staff', esc(c.staff))}${kv('Next action', esc(c.next))}${kv('Next hearing / due', fmtD(c.due))}${kv('Last action', fmtD(c.last))}
  ${kv('Decision due', fmtD(dv.decisionDue))}${kv('Other parties', esc(c.parties))}${kv('Remarks', esc(c.remarks))}</div>
  <h3>Fields used in the OCA reports</h3>
  <div class="kv">${kv('Date raffled', c.dateRaffled ? fmtD(c.dateRaffled) + ' ' + srcBadge('record') : srcBadge(''))}${c.type === 'CR' ? ms('Arraignment', m.arraignment) : kv('Civil section', esc(dv.civilSection))}${ms('Pre-trial', m.preTrial)}${ms('Initial trial', m.initialTrial)}${ms('Submitted for decision', m.submitted)}
  ${kv('Monthly Report category', `${esc(dv.nature.label)} <span class="badge ${dv.nature.review ? 'b-warn' : 'b-ok'}">${dv.nature.review ? 'please confirm' : esc(dv.nature.rule)}</span>`)}</div>
  ${c.type !== 'CR' ? `<div class="kv">${kv('Civil group (SDIR / Item XII)', `${esc(dv.civilSection)} <span class="badge b-slate">${esc(dv.civilRule)}</span>`)}</div>` : ''}
  ${dv.closure.closed ? `<div class="warnbox"><b>${esc(dv.closure.kind)}</b> on ${fmtD(dv.closure.date)}${dv.closure.to ? ' to ' + esc(dv.closure.to) : ''} (${dv.closure.derived ? 'from the history log - status still reads ' + esc(c.status) : 'recorded'}).
    ${dv.dispositionMode ? `<br>Monthly Report: <b>${dv.dispositionMode.mode === 'E21' ? 'III-A (E21) - decided on the merits' : 'III-B (E22) - non-merits final disposition'}</b> - ${esc(dv.dispositionMode.reason)}${dv.dispositionMode.review ? ' <span class="badge b-warn">please confirm</span>' : ''}${dv.dispositionMode.evidence ? `<br><i style="color:var(--soft)">${esc(dv.dispositionMode.evidence)}</i>` : ''}` : ''}</div>` : ''}
  ${(lc.closures.length || lc.revivals.length) ? `<h3>Archive / disposition timeline</h3><ul>${lc.closures.map(x => `<li>${esc(x.kind)} - ${fmtD(x.date)} <i>(${esc(x.source)})</i></li>`).join('')}${lc.revivals.map(x => `<li>Revived - ${fmtD(x.date)} <i>(${esc(x.source)})</i></li>`).join('')}</ul>` : ''}`;
}
function tabHistory() {
  const items = [...cur.history].reverse();
  return `<div class="row"><div class="f" style="flex:0 0 150px"><label>Date</label><input type="date" id="hDate" value="${today()}"></div><div class="f" style="flex:3 1 300px"><label>Order / action (this updates the last-action date)</label><input type="text" id="hText" placeholder="e.g. Order (Pre-trial is set on November 5, 2026)"></div><button class="btn gold sm" id="hAdd" style="margin-bottom:2px">Add entry</button></div>
  <div class="tl">${items.map(h => `<div class="it"><div class="d">${fmtD(h.date) || 'undated'}</div><div class="x">${esc(h.text)}</div></div>`).join('') || '<div class="empty">No history yet.</div>'}</div>`;
}
function bindHistory() {
  $('#hAdd').onclick = guard(async () => {
    await api(`/api/cases/${cur.case.id}/history`, { method: 'POST', json: { date: $('#hDate').value, text: $('#hText').value } });
    toast('Entry added.'); await openCase(cur.case.id, 'hi'); refreshBehind();
  });
}
function tabDispose() {
  const c = cur.case, cl = cur.derived.closure;
  const del = `<hr style="border:0;border-top:1px solid var(--line);margin:18px 0"><button class="btn red sm" id="dDel">Delete this case record</button>`;
  if (cl.closed) return `<div class="warnbox"><b>${esc(cl.kind)}</b> on ${fmtD(cl.date)}${cl.to ? ' to ' + esc(cl.to) : ''}. To correct the date or type, use the Edit tab.</div>
    <h3>Revive / reinstate on the docket</h3><div class="row"><div class="f" style="flex:0 0 160px"><label>Date of revival order</label><input type="date" id="dRevDate" value="${today()}"></div><button class="btn gold sm" id="dRev" style="margin-bottom:2px">Revive case</button></div>${del}`;
  return `<h3>Close this case on the docket</h3><div class="row"><div class="f"><label>Disposition</label><select id="dKind">${B.dispositions.map(d => `<option value="${esc(d)}">${esc(d === 'Compromise/JDR' ? 'Non-merits: compromise / JDR / plea bargain / procedural dismissal' : d === 'Decided/Resolved' ? 'Decided / resolved on the merits' : d)}</option>`).join('')}</select></div>
    <div class="f"><label>Date</label><input type="date" id="dDate" value="${today()}"></div><div class="f" id="dToWrap" style="display:none"><label>Transferred to</label><input type="text" id="dTo" placeholder="e.g. RTC Branch 3"></div></div>
    <div class="f"><label>History entry (optional - a default is used if blank)</label><input type="text" id="dNote" placeholder="e.g. Decision issued (accused pleaded guilty through plea bargaining)"></div>
    <p style="font-size:12.5px;color:var(--soft)">Decided and non-merits dispositions set the status to Terminated; Archived and Transferred set their own. On the Monthly Report, only a true merits decision is III-A (E21); plea bargaining, compromise/JDR and procedural dismissals are III-B (E22). All leave the pending count and appear in the matching OCA report section.</p>
    <button class="btn gold" id="dGo">Apply disposition</button>${del}`;
}
function bindDispose() {
  const id = cur.case.id;
  if ($('#dKind')) { $('#dKind').onchange = e => { $('#dToWrap').style.display = e.target.value === 'Transferred' ? 'flex' : 'none'; }; }
  if ($('#dGo')) $('#dGo').onclick = guard(async () => { await api(`/api/cases/${id}/dispose`, { method: 'POST', json: { kind: $('#dKind').value, date: $('#dDate').value, to: $('#dTo').value, note: $('#dNote').value } }); toast('Disposition recorded.'); await openCase(id, 'ov'); refreshBehind(); });
  if ($('#dRev')) $('#dRev').onclick = guard(async () => { await api(`/api/cases/${id}/reinstate`, { method: 'POST', json: { date: $('#dRevDate').value } }); toast('Case revived.'); await openCase(id, 'ov'); refreshBehind(); });
  $('#dDel').onclick = guard(async () => { if (!confirm('Delete this case record permanently? Use Disposition instead if the case was simply closed.')) return; await api('/api/cases/' + id, { method: 'DELETE' }); toast('Case deleted.'); closeModal(); refreshBehind(); });
}

/* ------------------------------------------------------------ attention */
async function loadAtt() {
  const d = await api('/api/attention?limit=300');
  $('#attNote').textContent = `Open cases that are overdue, due within ${B.settings.alertDays} days, past/near a decision deadline, or marked Urgent - most urgent first.`;
  $('#attList').innerHTML = d.rows.length ? d.rows.map(r => `${ribbon(r)}<div style="margin:-3px 0 9px 8px">${(r.reasons || []).map(x => `<span class="badge ${/overdue|passed/i.test(x) ? 'b-bad' : 'b-warn'}" style="margin-right:4px">${esc(x)}</span>`).join('')}</div>`).join('') : '<div class="empty">The docket is current - nothing needs immediate attention.</div>';
  setCount('attCount', d.count);
}

/* -------------------------------------------------------------- reports */
const nowD = new Date();
function repField(type, name, label, kind, value, hint) { return `<div class="f"><label>${label}</label><input type="${kind}" data-r="${type}" name="${name}" value="${esc(value == null ? '' : value)}">${hint ? `<span class="hint">${hint}</span>` : ''}</div>`; }
function repSelect(type, name, label, opts, value) { return `<div class="f"><label>${label}</label><select data-r="${type}" name="${name}">${opts.map(([v, l]) => `<option value="${v}"${String(v) === String(value) ? ' selected' : ''}>${l}</option>`).join('')}</select></div>`; }
function repCheck(type, name, label, on) { return `<label style="font-size:12.5px;display:block;margin:2px 0"><input type="checkbox" data-r="${type}" name="${name}"${on ? ' checked' : ''}> ${label}</label>`; }
function repButtons(type) { return `<div class="tools" style="margin:10px 0 0"><button class="btn sec sm" data-act="preview" data-t="${type}">Preview</button><button class="btn gold sm" data-act="download" data-t="${type}">Download .xlsx</button><button class="btn sec sm" data-act="audit" data-t="${type}">Derived values (CSV)</button><button class="btn sec sm" data-act="trace" data-t="${type}">Case-by-case trace (CSV)</button></div>`; }

function renderReports() {
  const y = nowD.getFullYear(), half = nowD.getMonth() < 6 ? '1' : '2';
  const prev = nowD.getDate() <= 10 ? new Date(y, nowD.getMonth() - 1, 1) : new Date(y, nowD.getMonth(), 1);
  $('#repCards').innerHTML = `
  <div class="card"><h3>Semestral Docket Inventory Report (SDIR)</h3><div class="d">Pending cases by section, cases disposed during the semester (decided, archived, transferred), and the joint certification.</div>
    <div class="row">${repField('sdir', 'year', 'Year', 'number', y)}${repSelect('sdir', 'half', 'Semester', [['1', 'January - June'], ['2', 'July - December']], half)}</div>
    <div class="row">${repField('sdir', 'invFrom', 'Inventory conducted from', 'date')}${repField('sdir', 'invTo', 'to', 'date')}${repField('sdir', 'signDate', 'Date of oath (optional)', 'date')}</div>
    ${repCheck('sdir', 'highlight', 'Highlight derived / unrecorded cells', true)}${repCheck('sdir', 'assumeRaffled', 'Use the date filed when no raffle date is recorded', false)}${repButtons('sdir')}</div>
  <div class="card"><h3>Docket Inventory Form (semestral)</h3><div class="d">The standard per-case-type version: one sheet each for Criminal, Civil, Special Proceedings and Other cases, plus the last page with the joint certification.</div>
    <div class="row">${repField('yearly', 'year', 'Year', 'number', y)}${repSelect('yearly', 'mode', 'Semester', [['h1', 'January - June'], ['h2', 'July - December']], half === '1' ? 'h1' : 'h2')}</div>
    <div class="row">${repField('yearly', 'invFrom', 'Inventory conducted from', 'date')}${repField('yearly', 'invTo', 'to', 'date')}${repField('yearly', 'signDate', 'Date of oath (optional)', 'date')}</div>
    ${repCheck('yearly', 'highlight', 'Highlight derived / unrecorded cells', true)}${repCheck('yearly', 'assumeRaffled', 'Use the date filed when no raffle date is recorded', false)}${repButtons('yearly')}</div>
  <div class="card"><h3>Monthly Report of Cases (SC Form MRC-RTC-FC)</h3><div class="d">Your official 6-page form, filled from the case records: case flow by nature, cases submitted for decision, aging, orders issued.</div>
    <div class="row">${repSelect('mrc', 'month', 'Month', MONTHS.map((m, i) => [i + 1, m]), prev.getMonth() + 1)}${repField('mrc', 'year', 'Year', 'number', prev.getFullYear())}${repField('mrc', 'signDate', 'Date of oath (optional)', 'date')}</div>
    ${repCheck('mrc', 'highlight', 'Highlight derived / manual-entry cells', true)}${repCheck('mrc', 'zeroManual', 'Fill manual-entry items with 0 instead of leaving them blank', false)}${repButtons('mrc')}</div>`;
}
function repQuery(type) {
  const p = new URLSearchParams({ type });
  $$(`[data-r="${type}"]`).forEach(el => { if (el.type === 'checkbox') p.set(el.name, el.checked ? '1' : '0'); else if (el.value) p.set(el.name, el.value); });
  return p.toString();
}
document.addEventListener('click', e => {
  const b = e.target.closest('[data-act]'); if (!b) return;
  const t = b.dataset.t, q = repQuery(t);
  if (b.dataset.act === 'preview') return guard(previewReport)(t, q);
  const a = document.createElement('a'); a.href = `/api/reports/${b.dataset.act === 'audit' ? 'audit' : b.dataset.act === 'trace' ? 'trace' : 'download'}?${q}`; a.download = ''; document.body.appendChild(a); a.click(); a.remove();
});
async function previewReport(type, q) {
  $('#repPreview').innerHTML = '<div class="empty">Preparing preview...</div>';
  const d = await api('/api/reports/preview?' + q); const s = d.summary;
  let h = `<div class="panel"><h3>${esc(s.report)} - ${esc(s.period)}</h3>`;
  if (d.warnings.length) h += `<div class="warnbox"><b>Please review before printing:</b><ul>${d.warnings.map(w => `<li>${esc(w)}</li>`).join('')}</ul></div>`;
  if (s.sections) {
    h += `<table class="t mini" style="max-width:520px"><thead><tr><th>Section</th><th>Cases</th></tr></thead><tbody>${s.sections.map(x => `<tr><td>${esc(x.name)}</td><td>${x.count}</td></tr>`).join('')}</tbody></table>
    <p style="margin-top:8px"><b>Pending:</b> ${s.totalPending} &nbsp; <b>Disposed in period:</b> ${s.totalDisposed}</p>`;
  } else {
    const flow = (title, o) => {
      const rows = [['I. Pending at beginning', 'begin'], ['II-A-1 New cases filed', 'newOrig'], ['II-B Revived', 'revived'], ['III-A (E21) Decided / resolved on the merits', 'merits'], ['III-B (E22) Compromise, JDR, plea bargaining and other non-merits final dispositions', 'compromise'], ['III-C Archived', 'archived'], ['III-D Transferred', 'transferred'], ['IV. Pending at end of month', 'end']];
      return `<h3 style="margin-top:12px">${title}</h3><div style="overflow:auto"><table class="t mini"><thead><tr><th>Item</th>${o.columns.map(c => `<th>${esc(c.label)}</th>`).join('')}<th>Total</th></tr></thead><tbody>${rows.map(([l, k]) => `<tr><td>${l}</td>${o.columns.map(c => `<td>${c[k]}</td>`).join('')}<td><b>${o.totals[k]}</b></td></tr>`).join('')}</tbody></table></div>`;
    };
    h += flow('Page 1 - Criminal cases', s.criminal) + flow('Page 2 - Civil cases', s.civil);
    const rc = s.reconciliation, x12 = rc.itemXII;
    h += `<h3 style="margin-top:12px">Reconciliation <span class="badge ${rc.ok ? 'b-ok' : 'b-bad'}">${rc.ok ? 'balanced' : 'DOES NOT BALANCE'}</span></h3>
    <table class="t mini" style="max-width:640px"><thead><tr><th>Item XII - pending at month end</th><th>Criminal</th><th>Ordinary civil</th><th>Special civil</th><th>Special proc.</th><th>Other civil</th><th>Total</th></tr></thead>
    <tbody><tr><td>Aging total</td><td>${x12.criminal}</td><td>${x12.ordinaryCivil}</td><td>${x12.specialCivil}</td><td>${x12.specialProceedings}</td><td>${x12.otherCivil}</td><td><b>${rc.agingTotal}</b></td></tr>
    <tr><td>Pages 1-2 pending at end (item IV)</td><td colspan="5"></td><td><b>${rc.pendingTotal}</b></td></tr></tbody></table>
    <p style="font-size:12px;color:var(--soft)">The report is never forced to balance: item IV on Pages 1-2 must equal the Item XII total, and beginning + added - deducted must equal the end figure for criminal and civil separately.</p>`;
    const o = s.orders;
    h += `<p style="margin-top:10px"><b>Page 3:</b> ${s.submittedWithin} case(s) submitted for decision this month; ${s.submittedPrevious} previously reported and still undecided.<br>
    <b>Page 4 (from history entries):</b> warrants of arrest issued ${o.warrantsIssued}, recalled ${o.warrantsRecalled}; TPO issued ${o.tpoIssued}, PPO issued ${o.ppoIssued}.</p>
    <div class="warnbox"><b>Enter by hand (not tracked in JCMS):</b><ul>${s.manual.map(m => `<li>${esc(m)}</li>`).join('')}</ul>${s.suggestions.detentionCases.length ? `<p>Suggestion for item V (detention): the history log shows ${s.suggestions.detentionCases.length} pending criminal case(s) whose latest custody entry is a commitment/detention. Verify against the jail records.</p>` : ''}</div>`;
  }
  h += `<p style="font-size:12.5px;color:var(--soft)">${d.derivedCount} value(s) were derived from history entries or assumed - listed in the audit CSV.</p></div>`;
  $('#repPreview').innerHTML = h;
  $('#repPreview').scrollIntoView({ behavior: 'smooth' });
}

/* ----------------------------------------------------------- data check */
const KIND_INFO = {
  closure: ['Archived / transferred per history', 'History shows an archive or transfer order, but the status still reads pending. Applying records the disposition and status.'],
  disposition: ['Terminated cases without a disposition type', 'Records "Decided/Resolved" (or Compromise/JDR) and the disposition date from the termination date.'],
  milestone: ['Arraignment / pre-trial / trial / submission dates found in history', 'Copies real events ("Arraignment held") into the case fields. Scheduling orders are never used.'],
  revival: ['Revival ordered per history', 'Records the revival date for a previously archived case.'],
  staff: ['Staff name spellings', 'Standardizes variants such as "Thalia" / "THALIA URSOS" to one name.'],
};
async function loadChk() {
  $('#chkBody').innerHTML = '<div class="empty">Checking the records...</div>';
  const [d, rf] = await Promise.all([api('/api/datacheck'), api('/api/raffle/missing')]);
  setCount('chkCount', d.summary.review);
  const byKind = k => d.items.filter(i => i.kind === k && i.level === 'apply');
  let h = `<p style="color:var(--soft);font-size:12.5px;margin-top:-4px">Reports only use what the records and their history support. These suggestions fill gaps from the history log; nothing is written until you press Apply.</p><div class="cards3">`;
  for (const [k, [title, desc]] of Object.entries(KIND_INFO)) {
    const items = byKind(k);
    h += `<div class="card"><h3>${esc(title)} <span class="badge ${items.length ? 'b-warn' : 'b-ok'}">${items.length}</span></h3><div class="d">${esc(desc)}</div>
      ${items.slice(0, 4).map(i => `<div style="font-size:12px;margin-bottom:3px"><a href="#" data-open="${esc(i.caseId)}"><b>${esc(i.caseNo)}</b></a> - ${esc(i.message.slice(0, 200))}</div>`).join('')}${items.length > 4 ? `<div style="font-size:12px;color:var(--soft)">...and ${items.length - 4} more</div>` : ''}
      ${items.length ? `<button class="btn gold sm" data-apply="${k}" style="margin-top:8px">Apply ${items.length}</button>` : ''}</div>`;
  }
  h += '</div>';
  const review = d.items.filter(i => i.level === 'review');
  h += `<h3>Needs your decision (${review.length})</h3>` + (review.length ? `<div style="overflow:auto"><table class="t"><thead><tr><th>Case</th><th>Issue</th><th></th></tr></thead><tbody>${review.map(i => `<tr><td><b>${esc(i.caseNo)}</b> <span class="badge t-${esc(i.type)}">${esc(i.type)}</span></td><td>${esc(i.message)}</td><td><button class="btn sec sm" data-open="${esc(i.caseId)}">Open</button></td></tr>`).join('')}</tbody></table></div>` : '<div class="empty">Nothing to review.</div>');
  h += `<h3 style="margin-top:20px">Raffle dates (${rf.count} case(s) without one)</h3><p style="color:var(--soft);font-size:12.5px">The SDIR and Docket Inventory need the date raffled. JCMS cannot know it, so the box below is pre-filled with the filing date as a starting point - correct any that differ, then save.</p>`;
  if (rf.rows.length) {
    h += `<div class="tools"><button class="btn gold sm" id="rfSave">Save raffle dates</button><span style="font-size:12px;color:var(--soft)">showing ${Math.min(rf.rows.length, 150)} of ${rf.count}</span></div><div style="overflow:auto;max-height:420px"><table class="t"><thead><tr><th>Case</th><th>Title</th><th>Filed</th><th>Date raffled</th></tr></thead><tbody>${rf.rows.slice(0, 150).map(r => `<tr><td><b>${esc(r.caseNo)}</b></td><td>${esc(r.title)}</td><td>${fmtD(r.filed)}</td><td><input type="date" data-rf="${esc(r.id)}" value="${esc(r.filed)}" min="${esc(r.filed)}"></td></tr>`).join('')}</tbody></table></div>`;
  } else h += '<div class="empty">Every case has a raffle date.</div>';
  $('#chkBody').innerHTML = h;
  $$('[data-apply]').forEach(b => b.onclick = guard(async () => {
    if (!confirm(`Write these ${KIND_INFO[b.dataset.apply][0].toLowerCase()} onto the case records?`)) return;
    const r = await api('/api/datacheck/apply', { method: 'POST', json: { kinds: [b.dataset.apply] } });
    toast(`Updated ${r.cases} case(s).`); loadChk(); boot2();
  }));
  if ($('#rfSave')) $('#rfSave').onclick = guard(async () => {
    const entries = $$('[data-rf]').map(i => ({ id: i.dataset.rf, date: i.value })).filter(e => e.date);
    if (!confirm(`Record raffle dates for ${entries.length} case(s)?`)) return;
    const r = await api('/api/raffle/apply', { method: 'POST', json: { entries } }); toast(`Saved ${r.updated} raffle date(s).`); loadChk();
  });
}

/* ------------------------------------------------------ settings & data */
const SET_FIELDS = [['courtName', 'Court name (screen)', 'text', 's2'], ['courtStation', 'Court and station (on reports)', 'text', 's2'], ['branchNumber', 'Branch number', 'text'], ['cityMunicipality', 'City / municipality', 'text'], ['province', 'Province', 'text'], ['region', 'Region', 'text'],
  ['presidingJudge', 'Presiding Judge (full name)', 'text', 's2'], ['judgeDesignation', 'Designation', 'text'], ['branchClerk', 'Branch Clerk of Court', 'text', 's2'], ['administeringOfficer', 'Executive Judge / administering officer', 'text', 's2'],
  ['alertDays', 'Alert window (days)', 'number'], ['staleDays', 'Flag if no action for (days)', 'number'], ['reportPaper', 'Report paper size', 'sel'], ['reportFooter', 'Footer note', 'text', 's4']];
function renderSettings() {
  const s = B.settings;
  const f = ([k, l, kind, sp]) => `<div class="f ${sp || ''}"><label>${l}</label>${kind === 'sel' ? `<select id="s-${k}">${['Folio', 'Legal', 'Letter', 'A4'].map(o => `<option${s[k] === o ? ' selected' : ''}>${o}</option>`).join('')}</select>` : `<input type="${kind}" id="s-${k}" value="${esc(s[k])}">`}</div>`;
  $('#setBody').innerHTML = `<div class="form"><h3>Court and report details</h3><div class="g">${SET_FIELDS.map(f).join('')}</div><div class="tools" style="margin-top:12px"><button class="btn gold" id="setSave">Save settings</button></div></div>
  <div class="form"><h3>Database</h3><p style="font-size:13px">Working file: <b>${esc(B.db)}</b> - ${B.cases} case(s). It is the official JCMS database format, saved automatically after every change, with rolling backups in the <code>backups</code> folder next to it.</p>
  <div class="tools"><a class="btn sec" href="/api/export/sqlite">Download database (.sqlite3)</a><a class="btn sec" href="/api/export/csv">Export cases (CSV)</a><a class="btn sec" href="/api/export/json">Export snapshot (JSON)</a></div></div>
  <div class="form"><h3>Merge another JCMS database</h3><p style="font-size:13px">Bring in the cases from the other PC's database file (for example the criminal-case PC). Cases are matched by record, then by type and case number; the newer entry wins and history entries are combined. Nothing is deleted.</p>
  <div class="tools"><input type="file" id="impFile" accept=".sqlite3,.sqlite,.db"><button class="btn gold sm" id="impGo">Merge file</button></div><div id="impOut"></div></div>`;
  $('#setSave').onclick = guard(async () => {
    const o = {}; SET_FIELDS.forEach(([k]) => { o[k] = $('#s-' + k).value; });
    B.settings = await api('/api/settings', { method: 'PUT', json: o }); applyBrand(); toast('Settings saved.');
  });
  $('#impGo').onclick = guard(async () => {
    const f = $('#impFile').files[0]; if (!f) return toast('Choose a database file first.', true);
    if (!confirm(`Merge "${f.name}" into this database? A backup is made automatically.`)) return;
    const r = await api('/api/import/sqlite', { method: 'POST', body: await f.arrayBuffer() });
    $('#impOut').innerHTML = `<div class="warnbox">Merged: ${r.added} added, ${r.updated} updated, ${r.unchanged} unchanged. Total cases now ${r.total}.${r.sameCaseDifferentId.length ? ' Same case entered on both PCs: ' + esc(r.sameCaseDifferentId.join(', ')) + '.' : ''}</div>`;
    boot2();
  });
}

/* ----------------------------------------------------------------- boot */
function applyBrand() {
  const s = B.settings;
  $('#courtLine').textContent = s.courtName || '';
  $('#foot').textContent = s.reportFooter || '';
  $('#dbline').textContent = `${B.db} - ${B.cases} cases`;
}
async function boot2() {
  B = await api('/api/bootstrap'); applyBrand();
  $('#rstatus').innerHTML = '<option value="">Any status</option>' + B.statuses.map(s => `<option>${esc(s)}</option>`).join('');
  $('#rstaff').innerHTML = '<option value="">Any staff</option>' + B.staff.map(s => `<option>${esc(s)}</option>`).join('');
  $('#rstatus').value = R.status; $('#rstaff').value = R.staff;
}
(async function init() {
  try {
    await boot2(); bindRegistry(); tick(); setInterval(tick, 30000);
    $('#mClose').onclick = closeModal; $('#ov').addEventListener('click', e => { if (e.target.id === 'ov') closeModal(); });
    document.addEventListener('keydown', e => { if (e.key === 'Escape') closeModal(); });
    $('#mTabs').addEventListener('click', e => { const b = e.target.closest('button'); if (b && cur) mTab(b.dataset.t); });
    await loadDash();
    api('/api/datacheck').then(d => setCount('chkCount', d.summary.review)).catch(() => {});
  } catch (e) { toast('Could not reach the JCMS server: ' + e.message, true); }
})();
