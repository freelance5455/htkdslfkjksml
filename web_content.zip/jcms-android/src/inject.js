export { Buffer } from 'buffer';
export const process = { env: {}, versions: {}, version: '', browser: true, platform: 'android', nextTick: (fn, ...a) => queueMicrotask(() => fn(...a)), cwd: () => '/', argv: [] };
