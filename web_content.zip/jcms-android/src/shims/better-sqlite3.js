// ============================================================================
// better-sqlite3 compatible adapter on top of sql.js (SQLite compiled to WASM).
// Implements exactly the API surface lib/store.js uses: new Database(path, opts),
// pragma, exec, prepare().get/all/run, transaction(fn), close. The database
// file is the same official SQLite format; every committed change is written
// back to the virtual file (and so to persistent storage) immediately.
// ============================================================================
const vfs = require('./vfs');
let SQL = null;
const setSQL = s => { SQL = s; };

class Statement {
  constructor(owner, sql) { this.o = owner; this.sql = sql; }
  get(...p) { const s = this.o.db.prepare(this.sql); try { if (p.length) s.bind(p); return s.step() ? s.getAsObject() : undefined; } finally { s.free(); } }
  all(...p) { const s = this.o.db.prepare(this.sql); const out = []; try { if (p.length) s.bind(p); while (s.step()) out.push(s.getAsObject()); } finally { s.free(); } return out; }
  run(...p) { this.o._guardWrite(); this.o.db.run(this.sql, p); const changes = this.o.db.getRowsModified(); this.o._persist(); return { changes }; }
}

class Database {
  constructor(file, opts = {}) {
    if (!SQL) throw new Error('SQLite engine not initialised');
    this.name = file; this.readonly = !!opts.readonly; this.depth = 0;
    const bytes = vfs.__raw(file);
    if (!bytes && opts.fileMustExist) throw new Error('unable to open database file');
    this.db = bytes ? new SQL.Database(bytes) : new SQL.Database();
    this.open = true;
  }
  _guardWrite() { if (this.readonly) throw new Error('attempt to write a readonly database'); }
  _persist() { if (this.depth === 0 && !this.readonly) vfs.writeFileSync(this.name, this.db.export()); }
  pragma(s) { try { this.db.exec('PRAGMA ' + s); } catch (e) { /* journal/synchronous modes have no meaning in memory */ } }
  exec(sql) { this._guardWrite(); this.db.exec(sql); this._persist(); return this; }
  prepare(sql) { return new Statement(this, sql); }
  transaction(fn) {
    return (...args) => {
      this._guardWrite(); this.db.exec('BEGIN'); this.depth++;
      let r;
      try { r = fn(...args); this.db.exec('COMMIT'); }
      catch (e) { try { this.db.exec('ROLLBACK'); } catch (x) { /* already rolled back */ } this.depth--; throw e; }
      this.depth--; this._persist(); return r;
    };
  }
  close() { if (!this.open) return; this.open = false; this.db.close(); }
}
Database.setSQL = setSQL;
module.exports = Database;
