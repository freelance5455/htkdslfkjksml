// ============================================================================
// Virtual file system used by the unmodified server-side code (lib/store.js and
// lib/app.js call fs.* exactly as they do on Windows). Files under /data are
// persisted to IndexedDB so the database survives app restarts.
// ============================================================================
const { Buffer } = require('buffer');

const files = new Map();          // path -> Uint8Array
const dirty = new Set();          // paths to write on next flush
const removed = new Set();        // paths to delete on next flush
const PERSIST_PREFIX = '/data/';
const DB_NAME = 'jcms-family-court-1', STORE = 'files';

let idbOpen = null;
function openIDB() {
  if (idbOpen) return idbOpen;
  idbOpen = new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, 1);
    req.onupgradeneeded = () => req.result.createObjectStore(STORE);
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
  return idbOpen;
}

const norm = p => {
  const parts = []; for (const s of String(p).split('/')) { if (!s || s === '.') continue; if (s === '..') parts.pop(); else parts.push(s); }
  return '/' + parts.join('/');
};
const enoent = (p, op) => { const e = new Error(`ENOENT: no such file or directory, ${op} '${p}'`); e.code = 'ENOENT'; return e; };
const touch = p => { if (p.startsWith(PERSIST_PREFIX)) { dirty.add(p); removed.delete(p); } };

let flushChain = Promise.resolve();
const doFlush = () => fs.__flushNow();

const fs = {
  // ---- persistence (not part of Node's fs) -------------------------------
  async __load() {
    const db = await openIDB();
    await new Promise((resolve, reject) => {
      const tx = db.transaction(STORE, 'readonly');
      const cur = tx.objectStore(STORE).openCursor();
      cur.onsuccess = () => { const c = cur.result; if (c) { files.set(c.key, new Uint8Array(c.value)); c.continue(); } };
      tx.oncomplete = resolve; tx.onerror = () => reject(tx.error);
    });
  },
  __flush() { flushChain = flushChain.then(doFlush, doFlush); return flushChain; },
  async __flushNow() {
    if (!dirty.size && !removed.size) return;
    const puts = [...dirty].filter(p => files.has(p)).map(p => [p, files.get(p).slice()]);
    const dels = [...removed];
    dirty.clear(); removed.clear();
    const db = await openIDB();
    await new Promise((resolve, reject) => {
      const tx = db.transaction(STORE, 'readwrite'); const st = tx.objectStore(STORE);
      for (const [p, b] of puts) st.put(b, p);
      for (const p of dels) st.delete(p);
      tx.oncomplete = resolve; tx.onerror = () => reject(tx.error); tx.onabort = () => reject(tx.error);
    });
  },
  __seed(p, bytes) { files.set(norm(p), bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes)); },
  __raw(p) { return files.get(norm(p)); },

  // ---- the subset of Node's fs that JCMS uses -----------------------------
  mkdirSync() { /* directories are implicit */ },
  existsSync(p) { return files.has(norm(p)); },
  readFileSync(p, enc) {
    const b = files.get(norm(p)); if (!b) throw enoent(p, 'open');
    const buf = Buffer.from(b.buffer, b.byteOffset, b.byteLength);
    return enc ? buf.toString(enc) : Buffer.from(buf);
  },
  writeFileSync(p, data) {
    p = norm(p);
    const b = typeof data === 'string' ? Buffer.from(data, 'utf8') : data;
    files.set(p, new Uint8Array(b.buffer ? b.buffer.slice(b.byteOffset, b.byteOffset + b.byteLength) : b)); touch(p);
  },
  copyFileSync(src, dest) { const b = files.get(norm(src)); if (!b) throw enoent(src, 'copyfile'); dest = norm(dest); files.set(dest, b.slice()); touch(dest); },
  readdirSync(dir) {
    dir = norm(dir); const pre = dir === '/' ? '/' : dir + '/'; const out = new Set();
    for (const p of files.keys()) if (p.startsWith(pre)) out.add(p.slice(pre.length).split('/')[0]);
    return [...out];
  },
  unlinkSync(p) { p = norm(p); if (!files.delete(p)) throw enoent(p, 'unlink'); if (p.startsWith(PERSIST_PREFIX)) { removed.add(p); dirty.delete(p); } },
  unlink(p, cb) { try { fs.unlinkSync(p); } catch (e) { return cb && cb(e); } cb && cb(null); },
  rmSync(p, o) { try { fs.unlinkSync(p); } catch (e) { if (!(o && o.force)) throw e; } },
  statSync(p) { const b = files.get(norm(p)); if (!b) throw enoent(p, 'stat'); return { size: b.byteLength, isFile: () => true, isDirectory: () => false }; },
};
module.exports = fs;
