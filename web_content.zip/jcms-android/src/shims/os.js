module.exports = { tmpdir: () => '/tmp', EOL: '\n', platform: () => 'android' };
