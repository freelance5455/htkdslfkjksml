// ============================================================================
// Minimal Express-compatible router that runs inside the app. It implements
// exactly what lib/app.js uses: app.use/get/post/put/delete, route params,
// req.query/body/params, express.json/raw/static, error middleware and the
// res.status/json/send/setHeader/download/write/end API (res is also a stream
// so ExcelJS can write the .xlsx straight into it).
// ============================================================================
const { Buffer } = require('buffer');
const vfs = require('./vfs');

class Emitter {
  constructor() { this._l = {}; }
  on(e, f) { (this._l[e] = this._l[e] || []).push(f); return this; }
  addListener(e, f) { return this.on(e, f); }
  prependListener(e, f) { (this._l[e] = this._l[e] || []).unshift(f); return this; }
  once(e, f) { const w = (...a) => { this.removeListener(e, w); f.apply(this, a); }; w.listener = f; return this.on(e, w); }
  removeListener(e, f) { this._l[e] = (this._l[e] || []).filter(x => x !== f && x.listener !== f); return this; }
  off(e, f) { return this.removeListener(e, f); }
  removeAllListeners(e) { if (e) delete this._l[e]; else this._l = {}; return this; }
  listeners(e) { return (this._l[e] || []).slice(); }
  listenerCount(e) { return (this._l[e] || []).length; }
  emit(e, ...a) { const ls = this.listeners(e); ls.forEach(f => f.apply(this, a)); return ls.length > 0; }
}

class Response extends Emitter {
  constructor() { super(); this.statusCode = 200; this.headers = {}; this.chunks = []; this.writableEnded = false; this.finished = false; }
  status(n) { this.statusCode = n; return this; }
  setHeader(k, v) { this.headers[String(k).toLowerCase()] = String(v); return this; }
  set(k, v) { return this.setHeader(k, v); }
  getHeader(k) { return this.headers[String(k).toLowerCase()]; }
  write(chunk) { if (chunk != null) this.chunks.push(typeof chunk === 'string' ? Buffer.from(chunk) : Buffer.from(chunk)); return true; }
  end(chunk) {
    if (this.writableEnded) return this;
    if (chunk != null) this.write(chunk);
    this.writableEnded = this.finished = true;
    queueMicrotask(() => { this.emit('finish'); this.emit('close'); });
    return this;
  }
  json(obj) { if (!this.getHeader('content-type')) this.setHeader('Content-Type', 'application/json; charset=utf-8'); return this.end(JSON.stringify(obj)); }
  send(body) {
    if (body == null) return this.end();
    if (typeof body === 'object' && !Buffer.isBuffer(body) && !(body instanceof Uint8Array)) return this.json(body);
    if (!this.getHeader('content-type')) this.setHeader('Content-Type', typeof body === 'string' ? 'text/html; charset=utf-8' : 'application/octet-stream');
    return this.end(body);
  }
  download(file, name, cb) {
    try { const b = vfs.readFileSync(file); this.setHeader('Content-Type', 'application/octet-stream'); this.setHeader('Content-Disposition', `attachment; filename="${name}"`); this.end(b); cb && cb(); }
    catch (e) { cb && cb(e); this.status(404).end(); }
  }
  get body() { return Buffer.concat(this.chunks); }
}

const compile = p => {
  const keys = []; const re = new RegExp('^' + p.replace(/\/+$/, '').replace(/:([A-Za-z0-9_]+)/g, (m, k) => { keys.push(k); return '([^/]+)'; }) + '/?$');
  return { re, keys };
};

function express() {
  const stack = [];
  const app = {
    disable() { return app; },
    use(a, ...rest) { const prefix = typeof a === 'string' ? a : null; const fns = prefix ? rest : [a, ...rest]; for (const fn of fns) stack.push({ prefix, fn }); return app; },
    handle: null,
  };
  for (const m of ['get', 'post', 'put', 'delete']) {
    app[m] = (p, ...fns) => { const c = compile(p); for (const fn of fns) stack.push({ method: m.toUpperCase(), route: c, fn }); return app; };
  }
  app.handle = (req, res) => new Promise(resolve => {
    res.once('finish', resolve);
    let i = 0;
    const next = err => {
      while (i < stack.length) {
        const l = stack[i++];
        if (l.method && l.method !== req.method) continue;
        if (l.prefix && !(req.path === l.prefix || req.path.startsWith(l.prefix + '/'))) continue;
        if (l.route) { const m = l.route.re.exec(req.path); if (!m) continue; req.params = {}; l.route.keys.forEach((k, n) => { req.params[k] = decodeURIComponent(m[n + 1]); }); }
        const isErr = l.fn.length === 4;
        if (err && !isErr) continue;
        if (!err && isErr) continue;
        try { const r = isErr ? l.fn(err, req, res, next) : l.fn(req, res, next); if (r && r.catch) r.catch(next); } catch (e) { next(e); }
        return;
      }
      if (err) { res.status(500).json({ error: err.message }); }
      else if (!res.finished) res.status(404).json({ error: 'Not found: ' + req.method + ' ' + req.path });
    };
    next();
  });
  return app;
}

express.json = () => (req, res, next) => {
  if (/json/i.test(req.headers['content-type'] || '') && req.rawBody && req.rawBody.length) {
    try { req.body = JSON.parse(Buffer.from(req.rawBody).toString('utf8')); } catch (e) { return res.status(400).json({ error: 'Invalid JSON body' }); }
  }
  next();
};
express.raw = () => (req, res, next) => { if (req.rawBody && req.rawBody.length) req.body = Buffer.from(req.rawBody); next(); };
express.static = () => (req, res, next) => next();   // the web files are served by the Android asset loader

express.Response = Response;
module.exports = express;
