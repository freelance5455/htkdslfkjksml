// ExcelJS: the official browser build, with Workbook.xlsx.readFile() (used by the MRC
// report to open templates/MRC-FAMILY.xlsx) reading from the bundled virtual file.
const ExcelJS = require('../../node_modules/exceljs/dist/exceljs.min.js');
const fs = require('./vfs');
const proto = Object.getPrototypeOf(new ExcelJS.Workbook().xlsx);
proto.readFile = async function (filename) { return this.load(fs.readFileSync(filename)); };
module.exports = ExcelJS;
