// ============================================================================
// Glue between the unmodified dashboard (public/app.js) and the in-app server:
//  * fetch('/api/...')  -> core.handle()
//  * links to /api/... (report downloads, exports) -> saved/shared through the
//    Android share sheet (Save to Drive / Files, open in Excel, send, print...)
// ============================================================================
const core = require('./core');
const { Capacitor } = require('@capacitor/core');
const { Filesystem, Directory } = require('@capacitor/filesystem');
const { Share } = require('@capacitor/share');

const origFetch = window.fetch ? window.fetch.bind(window) : null;
window.fetch = async function (input, init = {}) {
  const raw = typeof input === 'string' ? input : (input && input.url) || String(input);
  const u = new URL(raw, window.location.href);
  if (u.origin !== window.location.origin || !u.pathname.startsWith('/api/')) return origFetch(input, init);
  const headers = {}; new Headers(init.headers || {}).forEach((v, k) => { headers[k] = v; });
  let body = init.body;
  if (body != null) {
    if (typeof body === 'string') body = new TextEncoder().encode(body);
    else if (body instanceof ArrayBuffer) body = new Uint8Array(body);
    else if (ArrayBuffer.isView(body)) body = new Uint8Array(body.buffer, body.byteOffset, body.byteLength);
    else if (typeof Blob !== 'undefined' && body instanceof Blob) body = new Uint8Array(await body.arrayBuffer());
  }
  const r = await core.handle(init.method || 'GET', u.pathname + u.search, headers, body);
  return new Response(r.body, { status: r.status, headers: r.headers });
};

const toB64 = bytes => { let s = ''; for (let i = 0; i < bytes.length; i += 0x8000) s += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000)); return btoa(s); };
const safeName = n => String(n || 'download').replace(/[\\/:*?"<>|]+/g, '_');
const nameFrom = cd => { const m = /filename\*?=(?:UTF-8'')?"?([^";]+)"?/i.exec(cd || ''); return m ? decodeURIComponent(m[1]) : ''; };

async function deliver(name, bytes, type) {
  name = safeName(name);
  if (Capacitor.isNativePlatform()) {
    const file = await Filesystem.writeFile({ path: 'jcms-share/' + name, data: toB64(bytes), directory: Directory.Cache, recursive: true });
    await Share.share({ title: name, dialogTitle: 'Save or share ' + name, url: file.uri });
    return;
  }
  const a = document.createElement('a');                       // plain browser (testing / desktop)
  a.href = URL.createObjectURL(new Blob([bytes], { type: type || 'application/octet-stream' })); a.download = name;
  document.body.appendChild(a); a.click(); a.remove();
}

document.addEventListener('click', async ev => {
  const a = ev.target && ev.target.closest ? ev.target.closest('a[href]') : null;
  const href = a && a.getAttribute('href');
  if (!href || !href.startsWith('/api/')) return;
  ev.preventDefault(); ev.stopPropagation();
  try {
    const r = await window.fetch(href);
    if (!r.ok) { let m = ''; try { m = (await r.json()).error; } catch (e) { /* not json */ } throw new Error(m || 'Request failed (' + r.status + ')'); }
    await deliver(nameFrom(r.headers.get('content-disposition')) || a.download || 'download', new Uint8Array(await r.arrayBuffer()), r.headers.get('content-type'));
  } catch (e) {
    if (e && /cancel|dismiss/i.test(String(e.message))) return;  // share sheet closed by the user
    alert('Could not create the file: ' + e.message);
  }
}, true);

window.JCMS = { handle: core.handle, init: core.init, deliver };
core.init().catch(e => console.error('JCMS init failed', e));
