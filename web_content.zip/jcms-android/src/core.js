// ============================================================================
// JCMS core for Android: runs the ORIGINAL lib/store.js + lib/app.js (the same
// code as the Windows/Electron build) inside the app, behind a tiny in-process
// "server" (handle()). No network, no Node.js: everything is local and offline.
// ============================================================================
const { Buffer } = require('buffer');
const vfs = require('./shims/vfs');
const Database = require('./shims/better-sqlite3');
const express = require('./shims/express');
const initSqlJs = require('../node_modules/sql.js/dist/sql-wasm.js');
const assets = require('./generated/assets');
const { Store } = require('../app/lib/store');
const { createApp } = require('../app/lib/app');

const DB_PATH = '/data/jcms_family_court.sqlite3';       // same file name as the Windows build
const b64 = s => Uint8Array.from(atob(s), c => c.charCodeAt(0));

let store = null, app = null, ready = null;
function init() {
  if (!ready) ready = (async () => {
    try { if (navigator.storage && navigator.storage.persist) await navigator.storage.persist(); } catch (e) { /* best effort */ }
    await vfs.__load();
    Database.setSQL(await initSqlJs({ wasmBinary: b64(assets.SQL_WASM_B64) }));
    vfs.__seed('/app/templates/MRC-FAMILY.xlsx', b64(assets.TEMPLATE_B64));
    store = new Store(DB_PATH);
    app = createApp(store);
    await vfs.__flush();
  })();
  return ready;
}

async function handle(method, url, headers = {}, body) {
  await init();
  const u = new URL(url, 'https://localhost');
  const h = {}; for (const k of Object.keys(headers)) h[k.toLowerCase()] = headers[k];
  const req = { method: String(method).toUpperCase(), path: u.pathname, url: u.pathname + u.search, headers: h,
    query: Object.fromEntries(u.searchParams), body: {}, params: {}, rawBody: body };
  const res = new express.Response();
  await app.handle(req, res);
  await vfs.__flush();                      // the change is on persistent storage before the UI is told it succeeded
  return { status: res.statusCode, headers: res.headers, body: res.body };
}

module.exports = { init, handle, Buffer, __vfs: vfs };
