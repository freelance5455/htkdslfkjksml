#!/usr/bin/env python3
"""Regenerates the Android launcher icons + splash screens from app/public/assets/court-seal.png."""
import os, glob
from PIL import Image, ImageDraw
root = os.path.join(os.path.dirname(__file__), '..')
res = os.path.join(root, 'android/app/src/main/res')
seal = Image.open(os.path.join(root, 'app/public/assets/court-seal.png')).convert('RGBA')
seal = seal.crop(seal.getchannel('A').point(lambda a: 255 if a > 8 else 0).getbbox())   # trim transparent margin
# also trim the white margin around the ring
g = seal.convert('L').point(lambda v: 255 if v < 245 else 0); seal = seal.crop(g.getbbox())
def fit(img, d): return img.resize((d, d), Image.LANCZOS)
dens = {'mdpi': 1, 'hdpi': 1.5, 'xhdpi': 2, 'xxhdpi': 3, 'xxxhdpi': 4}
for n, f in dens.items():
    d = f'{res}/mipmap-{n}'
    # adaptive foreground (108dp canvas, seal inside the 66dp safe zone)
    S = int(108 * f); fg = Image.new('RGBA', (S, S), (0, 0, 0, 0)); sd = int(S * 0.60); fg.alpha_composite(fit(seal, sd), ((S - sd) // 2, (S - sd) // 2)); fg.save(f'{d}/ic_launcher_foreground.png')
    # legacy icons (48dp): white rounded square / white circle
    L = int(48 * f)
    sq = Image.new('RGBA', (L, L), (0, 0, 0, 0)); ImageDraw.Draw(sq).rounded_rectangle([0, 0, L - 1, L - 1], radius=int(L * 0.2), fill=(255, 255, 255, 255)); sd = int(L * 0.86); sq.alpha_composite(fit(seal, sd), ((L - sd) // 2, (L - sd) // 2)); sq.save(f'{d}/ic_launcher.png')
    rd = Image.new('RGBA', (L, L), (0, 0, 0, 0)); ImageDraw.Draw(rd).ellipse([0, 0, L - 1, L - 1], fill=(255, 255, 255, 255)); sd = int(L * 0.9); rd.alpha_composite(fit(seal, sd), ((L - sd) // 2, (L - sd) // 2)); rd.save(f'{d}/ic_launcher_round.png')
for p in glob.glob(f'{res}/drawable*/splash.png'):
    w, h = Image.open(p).size; im = Image.new('RGB', (w, h), (246, 244, 238)); sd = int(min(w, h) * 0.38)
    im.paste(fit(seal, sd), ((w - sd) // 2, (h - sd) // 2), fit(seal, sd)); im.save(p)
print('icons + splash regenerated')
