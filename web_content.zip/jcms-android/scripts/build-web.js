// Builds www/ (the web assets packaged inside the APK):
//   app/public/*  : the ORIGINAL dashboard, unchanged (only a <script> tag is added to index.html)
//   jcms-core.js  : the ORIGINAL lib/ code + in-app SQLite/Express/ExcelJS, bundled
'use strict';
const fs = require('fs'); const path = require('path'); const esbuild = require('esbuild');
const root = path.join(__dirname, '..'); const R = (...p) => path.join(root, ...p);

fs.mkdirSync(R('src/generated'), { recursive: true });
fs.writeFileSync(R('src/generated/assets.js'),
  `exports.SQL_WASM_B64 = '${fs.readFileSync(R('node_modules/sql.js/dist/sql-wasm.wasm')).toString('base64')}';\n` +
  `exports.TEMPLATE_B64 = '${fs.readFileSync(R('app/templates/MRC-FAMILY.xlsx')).toString('base64')}';\n`);

const alias = { express: 'src/shims/express.js', 'better-sqlite3': 'src/shims/better-sqlite3.js', fs: 'src/shims/vfs.js', os: 'src/shims/os.js',
  exceljs: 'src/shims/exceljs.js', path: 'node_modules/path-browserify/index.js' };
const plugin = {
  name: 'jcms',
  setup(b) {
    b.onResolve({ filter: /^(express|better-sqlite3|fs|os|path|exceljs)$/ }, a => ({ path: R(alias[a.path]) }));
    // sql.js has Node-only branches (never executed in the WebView): give them an empty module
    b.onResolve({ filter: /^node:/ }, () => ({ path: R('src/shims/empty.js') }));
    // lib/*.js use __dirname for the template / static paths: give each file its logical location in the virtual /app tree
    b.onLoad({ filter: /app[\\/]lib[\\/].*\.js$/ }, a => {
      const rel = path.relative(R('app'), path.dirname(a.path)).split(path.sep).join('/');
      return { contents: `var __dirname=${JSON.stringify('/app/' + rel)};\n` + fs.readFileSync(a.path, 'utf8'), loader: 'js' };
    });
  },
};

fs.rmSync(R('www'), { recursive: true, force: true }); fs.mkdirSync(R('www'), { recursive: true });
esbuild.build({
  entryPoints: [R('src/client.js')], bundle: true, format: 'iife', platform: 'browser', target: 'es2020', minify: true, legalComments: 'none',
  outfile: R('www/jcms-core.js'), inject: [R('src/inject.js')], define: { global: 'globalThis' }, plugins: [plugin], logLevel: 'warning',
}).then(() => {
  fs.cpSync(R('app/public'), R('www'), { recursive: true });
  const f = R('www/index.html'); let h = fs.readFileSync(f, 'utf8');
  if (!/<script[^>]+src="\/?app\.js"/.test(h)) throw new Error('index.html: app.js script tag not found');
  h = h.replace(/(<script[^>]+src="\/?app\.js")/, '<script src="/jcms-core.js"></script>\n$1');
  fs.writeFileSync(f, h);
  console.log('www/ built:', fs.readdirSync(R('www')).join(', '), '| jcms-core.js', (fs.statSync(R('www/jcms-core.js')).size / 1024 | 0) + ' KB');
}).catch(e => { console.error(e); process.exit(1); });
