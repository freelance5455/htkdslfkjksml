# ANONYMOUX STUDIO 2.5.2 — Upgrade and deployment notes

## Important

This is a corrective source archive, not a claim of verified live-provider or InfinityFree compatibility. Review `PRODUCTION_REPAIR_REPORT_2.5.2.md` before production deployment.

## Before uploading

1. Put the application into maintenance mode if currently live.
2. Back up the complete current application directory.
3. Make a separate copy of `storage/workspace.sqlite`.
4. Back up the complete `storage/` directory, including user media.
5. Keep the live `config.local.php` outside the ZIP and do not overwrite it.
6. Preserve the existing encryption secret. Replacing it can make encrypted provider keys unreadable.

## Upgrade

1. Extract the ZIP locally.
2. Upload the application files to the existing application directory.
3. Do not upload the example configuration over `config.local.php`.
4. Do not delete or replace `storage/workspace.sqlite`.
5. Keep storage directories private and writable by PHP.
6. Configure the canonical HTTPS URL in the private `config.local.php`:
   `canonical_base_url` must be the exact HTTPS origin and application base path.
7. If the host is behind a reverse proxy, add only the actual trusted proxy IP addresses to `trusted_proxy_ips`. Otherwise leave it empty.
8. Enable `pdo_sqlite`, `fileinfo`, `openssl`, and `curl` in the PHP runtime as required.
9. Load the application and verify the Admin → System diagnostics before opening it to users.

The `credit_operations` table is created lazily by the billing service and does not delete or rewrite existing wallet balances or ledger rows.

## Configure Image and Video prices

1. Sign in as an administrator.
2. Open Admin → Models.
3. Set Image generation credits and Video generation credits.
4. Save the prices.
5. Submit a test only after confirming the configured prices against the current Decart account pricing and the intended business markup.

New Image and Video generation is blocked until both prices are configured. Existing voice wallet balances are not changed by this upgrade.

## Provider configuration

- Decart permanent API keys must remain server-side, preferably in the existing encrypted admin key vault or private configuration.
- Fish Audio, Magic Hour and Flutterwave credentials must remain in their existing secure configuration areas.
- Do not paste provider secrets into frontend JavaScript or public files.
- The ZIP contains no production credentials or live database contents.

## Hosting capability requirements

At minimum, verify:
- PHP version supported by the source (PHP 8+ recommended).
- PDO SQLite (`pdo_sqlite`).
- Fileinfo.
- OpenSSL.
- cURL for external HTTP provider calls.
- HTTPS.
- Writable private `storage/` directory.
- Upload and POST limits sufficient for the selected media.
- Outbound HTTPS connections to each provider.

InfinityFree support for every required extension, outbound provider request, request size and execution duration must be tested on the actual hosting account. `.htaccess` protection only applies when the server honors Apache-compatible per-directory rules.

## Test commands

From the application root on a compatible PHP host:

```sh
php -l app/bootstrap.php
php tests/smoke.php
python3 tests/billing_sqlite_contract_check.py
python3 tests/billing_source_check.py
```

The full packaged regression scripts are in `tests/`. The billing SQL contract test uses Python SQLite and does not replace PHP PDO concurrency tests or live provider acceptance tests.
