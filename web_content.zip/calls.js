/* Sesli / görüntülü arama (WebRTC).
   Sinyalleşme BroadcastChannel ile yapılır: aynı tarayıcıdaki sekmeler/hesaplar arasında çalışır.
   Farklı cihazlar arasında arama için bir sinyal sunucusu (WebSocket) gerekir. */
(function () {
  'use strict';
  var A = window.App;
  if (!A) return;
  if (!window.BroadcastChannel || !window.RTCPeerConnection) {
    A.call = function () { A.toast('Bu tarayıcı aramaları desteklemiyor.', 'error'); };
    return;
  }
  var bc = new BroadcastChannel('bff-calls');
  var ICE = { iceServers: [{ urls: 'stun:stun.l.google.com:19302' }] };
  var st = null, ui = null;

  function myId() { var u = A.me(); return u ? u.id : null; }
  function post(m) { m.callId = st ? st.id : m.callId; m.from = myId(); bc.postMessage(m); }
  function media(video) {
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) return Promise.reject(new Error('Mikrofon/kamera bu tarayıcıda kullanılamıyor (https veya localhost gerekir).'));
    return navigator.mediaDevices.getUserMedia({ audio: true, video: !!video }).catch(function () {
      throw new Error(video ? 'Kamera ve mikrofon izni verilmedi.' : 'Mikrofon izni verilmedi.');
    });
  }

  /* ---- arayüz ---- */
  function showUI() {
    if (ui) return;
    var f = A.friendById(st.peer) || { name: 'Bilinmeyen', id: st.peer };
    ui = document.createElement('div');
    ui.className = 'fixed inset-0 z-[60] bg-background text-foreground flex flex-col';
    ui.innerHTML =
      '<video id="c-remote" autoplay playsinline class="absolute inset-0 w-full h-full object-cover bg-black hidden"></video>' +
      '<video id="c-local" autoplay playsinline muted class="absolute top-4 right-4 z-10 w-24 h-32 rounded-2xl object-cover bg-black border border-border hidden"></video>' +
      '<div class="relative z-10 flex-1 flex flex-col items-center justify-center text-center px-6">' +
      '<img src="' + A.avatar(f) + '" id="c-av" class="size-28 rounded-full object-cover ring-4 ring-primary mb-4" alt="" />' +
      '<h2 id="call-name" class="font-heading text-2xl font-extrabold">' + A.esc(f.name) + '</h2>' +
      '<p id="call-status" class="text-sm font-bold text-muted-foreground mt-1"></p></div>' +
      '<div id="c-actions" class="relative z-10 pb-10 px-6 flex items-center justify-center gap-5"></div>';
    document.body.appendChild(ui);
  }
  function btn(id, icon, cls, label) {
    return '<button type="button" id="' + id + '" aria-label="' + label + '" class="size-16 rounded-full ' + cls + ' flex items-center justify-center shadow-lg active:scale-95 transition"><iconify-icon icon="' + icon + '" width="28" height="28"></iconify-icon></button>';
  }
  function paint() {
    if (!ui || !st) return;
    var q = function (s) { return ui.querySelector(s); };
    var status = { ringing: 'Aranıyor…', incoming: (st.video ? 'Görüntülü' : 'Sesli') + ' arama geliyor…', connecting: 'Bağlanıyor…', connected: '' }[st.state] || '';
    q('#call-status').textContent = st.state === 'connected' ? A.fmtDur((Date.now() - st.start) / 1000) : status;
    var showVideo = st.video && st.state === 'connected';
    q('#c-remote').classList.toggle('hidden', !showVideo);
    q('#c-local').classList.toggle('hidden', !(st.video && st.local));
    q('#c-av').classList.toggle('hidden', showVideo);
    var acts = q('#c-actions');
    var key = st.state + (st.muted ? 'm' : '') + (st.camOff ? 'c' : '');
    if (acts.getAttribute('data-key') === key) return;
    acts.setAttribute('data-key', key);
    if (st.state === 'incoming') {
      acts.innerHTML = btn('c-reject', 'solar:phone-bold', 'bg-destructive text-primary-foreground', 'Reddet') + btn('c-accept', st.video ? 'solar:videocamera-record-bold' : 'solar:phone-bold', 'bg-accent text-accent-foreground', 'Cevapla');
      q('#c-reject').onclick = function () { post({ t: 'reject', to: st.peer }); cleanup(); };
      q('#c-accept').onclick = accept;
    } else {
      acts.innerHTML = btn('c-mic', 'solar:microphone-3-bold', st.muted ? 'bg-destructive text-primary-foreground' : 'bg-input border border-border', 'Mikrofon') +
        (st.video ? btn('c-cam', 'solar:camera-minimalistic-bold', st.camOff ? 'bg-destructive text-primary-foreground' : 'bg-input border border-border', 'Kamera') : '') +
        btn('c-end', 'solar:phone-bold', 'bg-destructive text-primary-foreground', 'Aramayı bitir');
      q('#c-end').onclick = function () { hangup('local'); };
      q('#c-mic').onclick = function () {
        st.muted = !st.muted;
        (st.local ? st.local.getAudioTracks() : []).forEach(function (t) { t.enabled = !st.muted; });
        paint();
      };
      var cam = q('#c-cam');
      if (cam) cam.onclick = function () {
        st.camOff = !st.camOff;
        (st.local ? st.local.getVideoTracks() : []).forEach(function (t) { t.enabled = !st.camOff; });
        paint();
      };
    }
  }
  function attachLocal() {
    if (!ui || !st || !st.local) return;
    ui.querySelector('#c-local').srcObject = st.local;
  }

  /* ---- yaşam döngüsü ---- */
  function cleanup() {
    if (!st) return;
    clearInterval(st.tick); clearTimeout(st.timeout);
    try { if (st.pc) st.pc.close(); } catch (e) {}
    if (st.local) st.local.getTracks().forEach(function (t) { t.stop(); });
    st = null;
    if (ui && ui.parentNode) ui.parentNode.removeChild(ui);
    ui = null;
  }
  function logCall(peer, text, video) {
    A.sendMsg(peer, { type: 'call', text: text, video: !!video });
  }
  function hangup(why) {
    if (!st) return;
    var s = st;
    if (why === 'local') post({ t: 'end', to: s.peer });
    if (s.role === 'caller') {
      var kind = s.video ? 'Görüntülü arama' : 'Sesli arama';
      if (s.state === 'connected') logCall(s.peer, kind + ' • ' + A.fmtDur((Date.now() - s.start) / 1000), s.video);
      else if (why === 'local') logCall(s.peer, 'İptal edilen ' + kind.toLowerCase(), s.video);
      else if (why === 'rejected') logCall(s.peer, kind + ' reddedildi', s.video);
      else logCall(s.peer, 'Cevapsız ' + kind.toLowerCase(), s.video);
    }
    cleanup();
  }
  function makePC() {
    var pc = new RTCPeerConnection(ICE);
    st.pc = pc; st.pending = [];
    st.local.getTracks().forEach(function (t) { pc.addTrack(t, st.local); });
    pc.onicecandidate = function (e) { if (e.candidate) post({ t: 'ice', to: st.peer, cand: e.candidate.toJSON ? e.candidate.toJSON() : e.candidate }); };
    pc.ontrack = function (e) { if (ui) ui.querySelector('#c-remote').srcObject = e.streams[0]; };
    pc.onconnectionstatechange = function () {
      if (!st) return;
      if (pc.connectionState === 'connected' && st.state !== 'connected') {
        st.state = 'connected'; st.start = Date.now(); clearTimeout(st.timeout);
        st.tick = setInterval(paint, 1000); paint();
      } else if (pc.connectionState === 'failed') { A.toast('Bağlantı kurulamadı.', 'error'); hangup('local'); }
    };
    return pc;
  }
  function flush() {
    var pc = st.pc;
    st.pending.splice(0).forEach(function (c) { pc.addIceCandidate(c).catch(function () {}); });
  }

  function accept() {
    if (!st) return;
    var s = st;
    media(s.video).then(function (stream) {
      if (st !== s) { stream.getTracks().forEach(function (t) { t.stop(); }); return; }
      s.local = stream; s.state = 'connecting'; clearTimeout(s.timeout);
      makePC(); attachLocal(); paint();
      post({ t: 'accept', to: s.peer });
    }).catch(function (e) { A.toast(e.message, 'error'); post({ t: 'reject', to: s.peer }); cleanup(); });
  }

  function start(friendId, video) {
    if (st) { A.toast('Zaten bir aramadasın.', 'error'); return; }
    var f = A.friendById(friendId);
    if (!f) return;
    if (!f.linked) { A.toast(f.name + ' kayıtlı kullanıcı olmadığı için aranamaz.', 'error'); return; }
    if (!f.online) { A.toast(f.name + ' şu an çevrimdışı.', 'error'); return; }
    media(video).then(function (stream) {
      if (st) { stream.getTracks().forEach(function (t) { t.stop(); }); return; }
      st = { id: A.rid(), peer: friendId, video: !!video, role: 'caller', state: 'ringing', local: stream };
      showUI(); attachLocal(); paint();
      post({ t: 'invite', to: friendId, video: !!video });
      st.timeout = setTimeout(function () { if (st && st.state === 'ringing') { post({ t: 'end', to: st.peer }); hangup('timeout'); A.toast('Cevap verilmedi.', 'error'); } }, 30000);
    }).catch(function (e) { A.toast(e.message, 'error'); });
  }

  /* ---- gelen sinyaller ---- */
  bc.onmessage = function (ev) {
    var m = ev.data, me = myId();
    if (!me || !m || m.to !== me) return;
    if (m.t === 'invite') {
      if (st) { bc.postMessage({ t: 'reject', callId: m.callId, from: me, to: m.from }); return; }
      if (!A.friendById(m.from)) return;
      st = { id: m.callId, peer: m.from, video: !!m.video, role: 'callee', state: 'incoming' };
      showUI(); paint();
      st.timeout = setTimeout(function () { if (st && st.state === 'incoming') { post({ t: 'reject', to: st.peer }); cleanup(); } }, 30000);
      return;
    }
    if (!st || m.callId !== st.id) return;
    if (m.t === 'accept' && st.role === 'caller') {
      st.state = 'connecting'; clearTimeout(st.timeout); paint();
      var pc = makePC();
      pc.createOffer().then(function (o) { return pc.setLocalDescription(o).then(function () { post({ t: 'offer', to: st.peer, sdp: { type: o.type, sdp: o.sdp } }); }); })
        .catch(function () { hangup('local'); });
    } else if (m.t === 'offer' && st.role === 'callee' && st.pc) {
      var p = st.pc;
      p.setRemoteDescription(m.sdp).then(function () { flush(); return p.createAnswer(); })
        .then(function (a) { return p.setLocalDescription(a).then(function () { post({ t: 'answer', to: st.peer, sdp: { type: a.type, sdp: a.sdp } }); }); })
        .catch(function () { hangup('local'); });
    } else if (m.t === 'answer' && st.role === 'caller' && st.pc) {
      st.pc.setRemoteDescription(m.sdp).then(flush).catch(function () {});
    } else if (m.t === 'ice' && st.pc) {
      if (st.pc.remoteDescription) st.pc.addIceCandidate(m.cand).catch(function () {}); else st.pending.push(m.cand);
    } else if (m.t === 'reject') {
      if (st.role === 'caller') { A.toast(A.friendById(st.peer) ? A.friendById(st.peer).name + ' aramayı reddetti.' : 'Arama reddedildi.', 'error'); hangup('rejected'); }
    } else if (m.t === 'end') {
      if (st.role === 'caller') hangup('remote'); else cleanup();
    }
  };
  window.addEventListener('beforeunload', function () { if (st) post({ t: 'end', to: st.peer }); });

  A.call = start;
})();
