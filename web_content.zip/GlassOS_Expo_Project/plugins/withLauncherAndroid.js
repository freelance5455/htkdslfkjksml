const { withAndroidManifest } = require('@expo/config-plugins');

// GlassOS is deliberately offline-first. Remove INTERNET and network-state
// permissions from the final merged app manifest so this build cannot make
// outbound network requests. Android system settings remain user-controlled.
module.exports = function withLauncherAndroid(config) {
  return withAndroidManifest(config, config => {
    const manifest = config.modResults.manifest;
    const blocked = new Set([
      'android.permission.INTERNET',
      'android.permission.ACCESS_NETWORK_STATE',
      'android.permission.ACCESS_WIFI_STATE'
    ]);
    manifest['uses-permission'] = (manifest['uses-permission'] || []).filter(item => !blocked.has(item.$?.['android:name']));
    // tools:node=remove also blocks these permissions if a transitive Android
    // library attempts to add them during the manifest merge.
    manifest.$ = manifest.$ || {};
    manifest.$['xmlns:tools'] = 'http://schemas.android.com/tools';
    manifest['uses-permission'] = manifest['uses-permission'] || [];
    for (const name of blocked) manifest['uses-permission'].push({ $: { 'android:name': name, 'tools:node': 'remove' } });
    const app = manifest.application?.[0];
    if (!app) return config;
    app.$ = app.$ || {};
    app.$['android:allowBackup'] = 'false';
    app.$['android:usesCleartextTraffic'] = 'false';
    const activity = (app.activity || []).find(a => a.$?.['android:name'] === '.MainActivity') ||
      (app.activity || []).find(a => a.$?.['android:name']?.endsWith('MainActivity'));
    if (activity) {
      activity['intent-filter'] = activity['intent-filter'] || [];
      const hasHome = activity['intent-filter'].some(f => (f.category || []).some(c => c.$?.['android:name'] === 'android.intent.category.HOME'));
      if (!hasHome) activity['intent-filter'].push({
        action: [{ $: { 'android:name': 'android.intent.action.MAIN' } }],
        category: [
          { $: { 'android:name': 'android.intent.category.HOME' } },
          { $: { 'android:name': 'android.intent.category.DEFAULT' } }
        ]
      });
    }
    return config;
  });
};
