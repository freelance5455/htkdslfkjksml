# GlassOS — Offline-first Expo Android Launcher

GlassOS is a clean Expo SDK 54 / React Native rebuild, using the uploaded Comet Launcher V6.1.3 APK only as a reference for feature direction. It is **not** a repackaged or modified Comet APK and does not contain Comet's proprietary compiled implementation.

## What is included in this build

- Expo Router + React Native TypeScript app branded **GlassOS**.
- Video-inspired customizable home screen with oversized clock/date, glass widgets, searchable app grid, customizable dock, and a floating customization/control-center sheet.
- Native app library: queries Android launchable apps and launches selected apps.
- Control center shortcuts to Android Wi-Fi, Bluetooth, display, sound, battery, and default-app settings. These open Android's own panels; they do not bypass system restrictions or silently toggle protected settings.
- Liquid Glass appearance controls: opacity, corner radius, accent color, icon size, grid columns, app labels, and selectable wallpaper palettes.
- Android floating volume panel shown by the opt-in accessibility service when hardware volume keys are pressed. It supports a native slider for media volume.
- Android overlay, write-settings, accessibility, and default-Home settings entry points.
- Android HOME intent filter so GlassOS can be selected as the Home app.
- Offline-first manifest policy: removes Internet and network-state permissions and adds manifest-merger removal directives for those permissions.
- No assistant, Comet login, remote store, analytics, cloud API, live weather, or remote update integration in this source project.

## Original APK inspection

The uploaded Comet APK is a native Android application using Kotlin/Jetpack Compose, not an Expo app. Static inspection of its DEX/resources found Comet AI classes and remote AI endpoints, store/update/Discord URLs, a statistics component, and a description stating that prompts, timestamps, battery information, and local weather are sent for AI responses. Static strings do not establish which endpoints are called at runtime. GlassOS is therefore a clean rebuild rather than a claim that the original APK has been sanitized.

## Requirements

- Node.js LTS (Node 20+ recommended)
- JDK 17
- Android Studio and Android SDK / platform tools
- Android device or emulator

## Install and build

```bash
npm install
npx expo prebuild --platform android --clean
npx expo run:android
```

Use a custom native development/build APK. **Expo Go is not supported** because GlassOS includes a local Kotlin Expo module, a launcher HOME intent, an accessibility service, and an overlay.

## Permission setup on Android

1. Install the development build.
2. Open GlassOS → Settings.
3. Grant **Display over other apps** to enable the floating volume panel.
4. Optionally enable **GlassOS volume controls** under Android Accessibility settings. The service only handles volume-key events and shows the GlassOS volume panel; Android requires this to be enabled manually.
5. Choose GlassOS under Android Default Home app settings.
6. Optionally grant Modify System Settings if you later add a feature that needs it; the current app does not silently change protected settings.

## Offline verification

The config plugin removes `INTERNET`, `ACCESS_NETWORK_STATE`, and `ACCESS_WIFI_STATE` from the app manifest and inserts `tools:node="remove"` merge directives so transitive libraries cannot re-add them silently. After prebuild/build, inspect the merged manifest as an additional check. The app's code has no network client calls. Android system settings panels may themselves access network when the user opens them; those are external system apps, not GlassOS.

```bash
npm run check:offline
```

## Video-inspired launcher additions

- Control-center sheet with Wi-Fi, Bluetooth, display, sound, battery, and Home settings shortcuts.
- Customization panel for wallpaper palettes, widget visibility, icon size, grid columns, app labels, glass opacity, corner radius, and accent color.
- Widget controls for clock, date, weather placeholder, and calendar placeholder.
- Standalone `index.html` browser preview with interactive wallpaper and appearance controls.

## Known limitations / not claimed as complete

- This is a launcher foundation, not a full replacement for every feature of Comet. No proprietary Comet source was available.
- App icons currently use local initial-letter tiles rather than extracting package icons.
- Wallpaper choices currently change GlassOS's own background palette; they do not set Android's system wallpaper.
- Widget controls are launcher cards/placeholders, not Android AppWidgetHost integrations. Live weather/calendar data is not connected.
- The control center is an in-app sheet, not a replacement for Android's protected notification shade or Quick Settings.
- Lock-screen customization in the video is not implemented as a system lock-screen replacement.
- Android's protected quick settings cannot be toggled directly by an ordinary app; shortcuts open the official Settings panels.
- Android overlay/accessibility behavior varies by OEM and must be tested on the target phone.
- A successful Gradle build and physical-device test are required before treating any APK as release-ready.
