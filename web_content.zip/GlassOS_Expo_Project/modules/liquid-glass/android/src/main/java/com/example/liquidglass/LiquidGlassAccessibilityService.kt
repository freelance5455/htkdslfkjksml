package com.example.liquidglass

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.KeyEvent
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView

class LiquidGlassAccessibilityService : AccessibilityService() {
  private var wm: WindowManager? = null
  private var panel: android.view.View? = null
  private val handler = Handler(Looper.getMainLooper())
  private val hide = Runnable { removePanel() }
  override fun onServiceConnected() { super.onServiceConnected(); wm = getSystemService(WINDOW_SERVICE) as WindowManager }
  override fun onKeyEvent(event: KeyEvent): Boolean {
    if (event.action != KeyEvent.ACTION_DOWN || (event.keyCode != KeyEvent.KEYCODE_VOLUME_UP && event.keyCode != KeyEvent.KEYCODE_VOLUME_DOWN)) return false
    val audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
    audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, if (event.keyCode == KeyEvent.KEYCODE_VOLUME_UP) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER, 0)
    handler.post { showPanel() }; return true
  }
  private fun showPanel() {
    if (!android.provider.Settings.canDrawOverlays(this)) return
    removePanel()
    val audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
    val p = getSharedPreferences("glass_prefs", Context.MODE_PRIVATE)
    val opacity = p.getInt("glass_alpha", 82).coerceIn(20, 100)
    val radius = p.getInt("glass_radius", 28).coerceIn(8, 48)
    val accent = p.getInt("glass_color", Color.WHITE)
    val width = p.getInt("volume_width", 260).coerceIn(180, 340)
    val density = resources.displayMetrics.density
    val root = LinearLayout(this).apply {
      orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(24, 14, 24, 14)
      background = GradientDrawable().apply { setColor(Color.argb((opacity * 2.1f).toInt().coerceIn(40, 220), 35, 43, 61)); cornerRadius = radius * density; setStroke(1, 0x66FFFFFF) }
    }
    root.addView(TextView(this).apply { text = "◖  Volume"; textSize = 14f; setTextColor(accent); gravity = Gravity.CENTER })
    root.addView(SeekBar(this).apply {
      max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC); progress = audio.getStreamVolume(AudioManager.STREAM_MUSIC)
      progressTintList = android.content.res.ColorStateList.valueOf(accent); thumbTintList = android.content.res.ColorStateList.valueOf(accent)
      setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s: SeekBar?, value: Int, fromUser: Boolean) { if (fromUser) audio.setStreamVolume(AudioManager.STREAM_MUSIC, value, 0) }
        override fun onStartTrackingTouch(s: SeekBar?) {}; override fun onStopTrackingTouch(s: SeekBar?) {}
      })
    }, LinearLayout.LayoutParams((width * density).toInt(), 42))
    val params = WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = 110 }
    try { wm?.addView(root, params); panel = root; handler.removeCallbacks(hide); handler.postDelayed(hide, 2300) } catch (_: Exception) { panel = null }
  }
  private fun removePanel() { panel?.let { try { wm?.removeView(it) } catch (_: Exception) {} }; panel = null }
  override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
  override fun onInterrupt() {}
  override fun onDestroy() { handler.removeCallbacksAndMessages(null); removePanel(); super.onDestroy() }
}
