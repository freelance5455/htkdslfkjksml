package com.example.liquidglass

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.content.pm.PackageManager
import expo.modules.kotlin.modules.Module
import expo.modules.kotlin.modules.ModuleDefinition

class LiquidGlassModule : Module() {
  override fun definition() = ModuleDefinition {
    Name("LiquidGlass")
    Function("getPermissionStatus") {
      val context = appContext.reactContext ?: return@Function mapOf("overlay" to false, "writeSettings" to false, "accessibility" to false)
      val enabled = Settings.Secure.getString(context.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES).orEmpty()
      mapOf(
        "overlay" to Settings.canDrawOverlays(context),
        "writeSettings" to Settings.System.canWrite(context),
        "accessibility" to enabled.contains(context.packageName + "/com.example.liquidglass.LiquidGlassAccessibilityService", ignoreCase = true)
      )
    }
    Function("getAppearanceSettings") {
      val c = appContext.reactContext ?: return@Function mapOf("opacity" to 82, "radius" to 28, "width" to 260, "accent" to "#FFFFFF")
      val prefs = c.getSharedPreferences("glass_prefs", android.content.Context.MODE_PRIVATE)
      val color = prefs.getInt("glass_color", android.graphics.Color.WHITE)
      mapOf(
        "opacity" to prefs.getInt("glass_alpha", 82),
        "radius" to prefs.getInt("glass_radius", 28),
        "width" to prefs.getInt("volume_width", 260),
        "accent" to String.format("#%06X", 0xFFFFFF and color)
      )
    }
    Function("requestOverlayPermission") {
      val c = appContext.currentActivity ?: return@Function
      if (!Settings.canDrawOverlays(c)) c.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${c.packageName}")))
    }
    Function("requestWriteSettingsPermission") {
      val c = appContext.currentActivity ?: return@Function
      if (!Settings.System.canWrite(c)) c.startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${c.packageName}")))
    }
    Function("openHomeSettings") { appContext.currentActivity?.startActivity(Intent("android.settings.HOME_SETTINGS")) }
    Function("openAccessibilitySettings") { appContext.currentActivity?.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
    Function("openWifiSettings") { appContext.currentActivity?.startActivity(Intent(Settings.ACTION_WIFI_SETTINGS)) }
    Function("openBluetoothSettings") { appContext.currentActivity?.startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) }
    Function("openDisplaySettings") { appContext.currentActivity?.startActivity(Intent(Settings.ACTION_DISPLAY_SETTINGS)) }
    Function("openSoundSettings") { appContext.currentActivity?.startActivity(Intent(Settings.ACTION_SOUND_SETTINGS)) }
    Function("openBatterySettings") { appContext.currentActivity?.startActivity(Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)) }
    Function("openDefaultAppsSettings") {
      val c = appContext.currentActivity ?: return@Function
      try { c.startActivity(Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS)) }
      catch (_: Exception) { c.startActivity(Intent("android.settings.HOME_SETTINGS")) }
    }
    Function("getInstalledApps") {
      val c = appContext.reactContext ?: return@Function emptyList<Map<String, String>>()
      val pm = c.packageManager
      val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
      pm.queryIntentActivities(query, PackageManager.MATCH_ALL)
        .mapNotNull { info ->
          val pkg = info.activityInfo?.packageName ?: return@mapNotNull null
          if (pkg == c.packageName) return@mapNotNull null
          mapOf("packageName" to pkg, "name" to info.loadLabel(pm).toString(), "activityName" to (info.activityInfo?.name ?: ""))
        }
        .distinctBy { it["packageName"] }
        .sortedBy { it["name"]?.lowercase() }
    }
    Function("launchApp") { packageName: String ->
      val c = appContext.currentActivity ?: return@Function false
      val intent = c.packageManager.getLaunchIntentForPackage(packageName) ?: return@Function false
      intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
      c.startActivity(intent)
      true
    }
    Function("saveAppearanceSettings") { settings: Map<String, Any> ->
      val c = appContext.reactContext ?: return@Function
      val prefs = c.getSharedPreferences("glass_prefs", android.content.Context.MODE_PRIVATE)
      val accent = (settings["accent"] as? String ?: "#FFFFFF").removePrefix("#").toLongOrNull(16)?.toInt() ?: -1
      prefs.edit()
        .putInt("glass_alpha", ((settings["opacity"] as? Number)?.toInt() ?: 82).coerceIn(20, 100))
        .putInt("glass_radius", ((settings["radius"] as? Number)?.toInt() ?: 28).coerceIn(8, 48))
        .putInt("volume_width", ((settings["width"] as? Number)?.toInt() ?: 260).coerceIn(180, 340))
        .putInt("glass_color", (accent or (0xFF shl 24)))
        .apply()
    }
  }
}
