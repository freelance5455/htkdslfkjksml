import { requireNativeModule } from 'expo-modules-core';

export type PermissionStatus = { overlay: boolean; writeSettings: boolean; accessibility: boolean };
export type AppearanceSettings = { opacity: number; radius: number; width: number; accent: string };
export type InstalledApp = { packageName: string; name: string; activityName: string };
type LiquidGlassNative = {
  getPermissionStatus(): PermissionStatus;
  getAppearanceSettings(): AppearanceSettings;
  requestOverlayPermission(): void;
  requestWriteSettingsPermission(): void;
  openHomeSettings(): void;
  openAccessibilitySettings(): void;
  saveAppearanceSettings(settings: AppearanceSettings): void;
  getInstalledApps(): InstalledApp[];
  launchApp(packageName: string): boolean;
  openWifiSettings(): void;
  openBluetoothSettings(): void;
  openDisplaySettings(): void;
  openSoundSettings(): void;
  openBatterySettings(): void;
  openDefaultAppsSettings(): void;
};
export default requireNativeModule<LiquidGlassNative>('LiquidGlass');
