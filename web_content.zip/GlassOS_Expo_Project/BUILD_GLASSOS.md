# Build GlassOS Android APK

This is the GlassOS offline-first Android launcher source project. It is a clean rebuild, not a repackaged copy of Comet or the LiquidGlass demo APK.

## Build requirements
- Node.js 20 or newer
- JDK 17
- Android Studio with Android SDK + platform tools installed
- An Android device or emulator

## Build a debug APK

From this folder:

```bash
npm install
npx expo prebuild --platform android --clean
cd android
./gradlew assembleDebug
```

APK output:

```text
android/app/build/outputs/apk/debug/app-debug.apk
```

Install on a connected device:

```bash
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

## Project status and permissions

The project includes the GlassOS app UI, the supplied G artwork as app/adaptive icon, local app listing/launching, appearance controls, a native volume overlay flow, and Android settings entry points. Android overlay and accessibility capabilities require the user to grant the relevant special permissions in Android Settings. GlassOS cannot silently enable them.

The project is not yet a verified release build. Run the build, inspect the merged Android manifest, and test on the target phone before relying on the launcher or volume overlay. `npm run check:offline` validates the generated source manifest after prebuild; inspect the packaged manifest too before release.
