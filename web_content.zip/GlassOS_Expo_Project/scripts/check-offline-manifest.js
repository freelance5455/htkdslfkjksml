// Run after `npx expo prebuild` and optionally after Gradle manifest merge.
const fs = require('fs');
const path = require('path');
const appManifest = path.join('android', 'app', 'src', 'main', 'AndroidManifest.xml');
if (!fs.existsSync(appManifest)) {
  console.error('Run `npx expo prebuild --platform android` first.');
  process.exit(2);
}
const blocked = new Set([
  'android.permission.INTERNET',
  'android.permission.ACCESS_NETWORK_STATE',
  'android.permission.ACCESS_WIFI_STATE'
]);
function activeBlockedPermissions(xml) {
  const tags = xml.match(/<uses-permission(?:-sdk-\d+)?\b[^>]*>/g) || [];
  return tags.filter(tag => {
    const name = (tag.match(/android:name="([^"]+)"/) || [])[1];
    return blocked.has(name) && !/tools:node="remove"/.test(tag);
  }).map(tag => (tag.match(/android:name="([^"]+)"/) || [])[1]);
}
const sourceXml = fs.readFileSync(appManifest, 'utf8');
const sourceFound = activeBlockedPermissions(sourceXml);
if (sourceFound.length) {
  console.error('Active network permissions remain in app manifest:', [...new Set(sourceFound)].join(', '));
  process.exit(1);
}
const buildRoots = [
  path.join('android', 'app', 'build', 'intermediates', 'merged_manifests'),
  path.join('android', 'app', 'build', 'intermediates', 'packaged_manifests')
];
function walk(dir) {
  if (!fs.existsSync(dir)) return [];
  return fs.readdirSync(dir, { withFileTypes: true }).flatMap(entry => {
    const full = path.join(dir, entry.name);
    return entry.isDirectory() ? walk(full) : entry.name === 'AndroidManifest.xml' ? [full] : [];
  });
}
const merged = buildRoots.flatMap(walk);
for (const file of merged) {
  const found = activeBlockedPermissions(fs.readFileSync(file, 'utf8'));
  if (found.length) {
    console.error(`Network permissions found in merged manifest ${file}:`, [...new Set(found)].join(', '));
    process.exit(1);
  }
}
console.log(`Offline manifest check passed. Checked app manifest${merged.length ? ` and ${merged.length} merged/packaged manifest(s)` : ''}.`);
