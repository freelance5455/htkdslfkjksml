# NexaDev — protótipo beta

Uma primeira versão responsiva do NexaDev com uma identidade visual inspirada no ambiente de desenvolvimento do Visual Studio Code: fundo grafite, painéis escuros, azul de destaque e detalhes verdes.

## O que funciona nesta versão
- Navegação entre Visão geral, Projetos, Comunidade, Trilhas e Perfil.
- Criar projetos e publicar conversas na comunidade.
- Curtir projetos e publicações.
- Editar perfil.
- Filtrar projetos por texto.
- Marcar etapas de aprendizado como concluídas.
- Salvar dados no armazenamento local do navegador.
- Layout adaptável para celular e computador.
- Estrutura PWA inicial para instalação pelo navegador e cache básico.

## Como testar
1. Extraia todos os arquivos para uma pasta.
2. Abra `index.html` no navegador para testar as funções básicas.
3. Para testar a instalação PWA/offline, publique os arquivos em um host HTTPS ou rode um servidor local. Service workers não funcionam de forma confiável ao abrir `file://`.

## Importante
Esta é uma demonstração front-end. Os dados ficam no navegador do dispositivo e não sincronizam entre pessoas. Login real, banco de dados, chat ao vivo, segurança, backend e publicação em loja Android ainda precisam ser implementados. Para virar um aplicativo Android nativo, a próxima etapa pode usar Capacitor com este front-end e um backend.


## Atualização: animações e planos NexaDev
- Transições suaves ao trocar de abas e interações dos botões.
- Apenas a primeira etapa das trilhas fica aberta para usuários gratuitos.
- Planos demonstrativos NexaPro e NexaDEV'R desbloqueiam as outras etapas.
- Ao ativar um plano de demonstração, um selo aparece ao lado do avatar no perfil.
- Perfil reorganizado com foto/monograma, nome e selo centralizados.
- Os planos são simulados: não há cobrança real nem validação de pagamento.


## Atualização v3: glass UI e checkout
- Interface com glassmorphism, fundos em camadas e painéis translúcidos inspirados nas referências enviadas.
- Barra de navegação inferior no celular, com indicador circular que desliza entre as abas.
- Marca Nexa com símbolo geométrico próprio no canto superior esquerdo.
- Planos com tipografia e espaçamento maiores para evitar textos cortados.
- Tela de checkout demonstrativa com Pix, cartão e boleto.
- O checkout não processa pagamentos reais; nunca informe dados bancários reais neste protótipo.
