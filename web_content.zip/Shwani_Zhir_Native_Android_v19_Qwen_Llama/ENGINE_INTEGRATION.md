# Native inference integration — implemented source path

Pinned llama.cpp release: `b4510`.

## Android build
- CMake FetchContent clones llama.cpp and its `ggml` submodule.
- Builds CPU-only for `arm64-v8a` with `GGML_NATIVE=OFF`, `GGML_OPENMP=OFF`, `GGML_LLAMAFILE=OFF`, and no OpenSSL dependency.
- Produces `libshwani_llama.so` and exposes JNI methods through `LlamaEngine.kt`.

## Runtime flow
1. DownloadManager downloads the public Qwen2.5-0.5B-Instruct Q4_K_M GGUF file.
2. Kotlin checks that DownloadManager reports success and the file is present.
3. Before native load, Kotlin streams SHA-256 and compares the published digest.
4. JNI loads the model with mmap, CPU-only, 2048 context, 256 batch, and 4 threads.
5. The WebView bridge passes the question plus locally retrieved flock/document context to JNI.
6. JNI applies the model's GGUF chat template (ChatML fallback), tokenizes, decodes, samples up to 320 tokens, and returns the text.

## Deliberate limitations
- Generation is a single background task and returns the complete answer (not token streaming).
- Only one request can run at a time.
- No model or prompt telemetry is sent to any remote service.
- CPU-only is the compatibility baseline; GPU/NPU offload is not enabled.
- The code still requires a real Android NDK build and device validation. Do not call the integration verified until Gradle/CMake builds and on-device offline tests pass.
