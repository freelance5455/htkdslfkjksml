plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.shwanizhir.app"
    compileSdk = 36
    ndkVersion = "27.2.12479018"

    defaultConfig {
        applicationId = "com.shwanizhir.app"
        minSdk = 28
        targetSdk = 35
        versionCode = 19
        versionName = "3.1.0-native-beta"
        ndk { abiFilters += listOf("arm64-v8a") }
        externalNativeBuild {
            cmake {
                cppFlags += listOf("-std=c++17")
            }
        }
    }

    externalNativeBuild {
        cmake {
            path = file("src/main/cpp/CMakeLists.txt")
            version = "3.22.1"
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.webkit:webkit:1.12.1")
    implementation("androidx.activity:activity-ktx:1.10.1")
    implementation("androidx.core:core-ktx:1.16.0")
}

// Build/bundle PDF.js and Mammoth into app assets before Android packaging.
// Node.js + npm are required on the build computer; no user documents are uploaded.
val npmInstallWeb by tasks.registering(Exec::class) {
    workingDir(rootProject.projectDir)
    commandLine("npm", "--prefix", "web", "install", "--no-audit", "--no-fund")
}
val buildWebAssets by tasks.registering(Exec::class) {
    dependsOn(npmInstallWeb)
    workingDir(rootProject.projectDir)
    commandLine("npm", "--prefix", "web", "run", "build")
}
tasks.named("preBuild").configure { dependsOn(buildWebAssets) }
tasks.configureEach {
    if (name.startsWith("configureCMake")) dependsOn(buildWebAssets)
}
