// Document parsers run locally in the WebView. Native Android inference is exposed
// through the ShwaniNative JavaScript bridge and backed by llama.cpp (JNI).
window.shwaniLoadPdfLibrary = async function () {
  const pdfjs = await import('pdfjs-dist/legacy/build/pdf.mjs');
  const workerUrl = await import('pdfjs-dist/legacy/build/pdf.worker.mjs?url');
  pdfjs.GlobalWorkerOptions.workerSrc = workerUrl.default;
  return pdfjs;
};
window.shwaniExtractDocx = async function (file) {
  const mammothModule = await import('mammoth/mammoth.browser');
  const mammoth = mammothModule.default || mammothModule;
  const result = await mammoth.extractRawText({ arrayBuffer: await file.arrayBuffer() });
  return result.value || '';
};
window.shwaniCreateLocalModel = async function () {
  throw new Error('On Android, use the native llama.cpp engine. WebLLM is intentionally not used in Android WebView.');
};
