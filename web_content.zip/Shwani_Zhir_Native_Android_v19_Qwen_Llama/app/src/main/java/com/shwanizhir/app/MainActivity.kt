package com.shwanizhir.app

import android.annotation.SuppressLint
import android.app.Activity
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.webkit.WebViewAssetLoader
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.security.MessageDigest
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private lateinit var modelManager: ModelManager
    private val worker = Executors.newSingleThreadExecutor()
    @Volatile private var engineState = "NOT_LOADED"
    @Volatile private var engineMessage = "مۆدێل هێشتا بار نەکراوە."
    @Volatile private var generationState = "IDLE"
    @Volatile private var generationResult = ""
    @Volatile private var generationError = ""
    @Volatile private var engine: LlamaEngine? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        modelManager = ModelManager(this)
        webView = WebView(this)
        setContentView(webView)

        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            allowFileAccess = false
            allowContentAccess = true
            setSupportZoom(false)
            builtInZoomControls = false
        }
        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest) =
                assetLoader.shouldInterceptRequest(request.url)
        }
        webView.webChromeClient = WebChromeClient()
        webView.addJavascriptInterface(NativeBridge(), "ShwaniNative")
        webView.loadUrl("https://appassets.androidplatform.net/assets/www/index.html")
    }

    private fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        FileInputStream(file).use { input ->
            val buffer = ByteArray(1024 * 1024)
            while (true) {
                val count = input.read(buffer)
                if (count < 0) break
                digest.update(buffer, 0, count)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    inner class NativeBridge {
        @JavascriptInterface fun isNativeApp(): Boolean = true
        @JavascriptInterface fun startModelDownload(): String = try {
            val id = modelManager.start()
            JSONObject().put("ok", true).put("id", id).toString()
        } catch (e: Exception) {
            JSONObject().put("ok", false).put("error", e.message ?: "download error").toString()
        }
        @JavascriptInterface fun modelStatus(): String = modelManager.status().toString()
        @JavascriptInterface fun modelPath(): String = modelManager.modelPath()
        @JavascriptInterface fun modelSha256(): String = ModelManager.EXPECTED_SHA256

        @JavascriptInterface fun startModelLoad(): String {
            if (engineState == "READY" || engineState == "LOADING") return JSONObject()
                .put("ok", true).put("state", engineState).toString()
            val path = modelManager.modelPath()
            if (path.isBlank()) return JSONObject().put("ok", false).put("error", "لم يكتمل تنزيل النموذج بعد.").toString()
            engineState = "LOADING"
            engineMessage = "التحقق من سلامة النموذج ثم تحميله..."
            worker.execute {
                try {
                    val file = File(path)
                    if (!file.isFile || file.length() < ModelManager.MIN_MODEL_BYTES) throw IllegalStateException("ملف النموذج ناقص أو غير موجود.")
                    val actualHash = sha256(file)
                    if (!actualHash.equals(ModelManager.EXPECTED_SHA256, ignoreCase = true)) {
                        file.delete()
                        throw IllegalStateException("فشل فحص SHA-256؛ حُذف الملف التالف. أعد تنزيل النموذج.")
                    }
                    val native = LlamaEngine()
                    val error = native.nativeLoadModel(file.absolutePath)
                    if (error.isNotBlank()) throw IllegalStateException(error)
                    engine = native
                    engineState = "READY"
                    engineMessage = "نموذج Qwen2.5 0.5B جاهز للعمل محليًا."
                } catch (e: Throwable) {
                    engineState = "ERROR"
                    engineMessage = e.message ?: e.javaClass.simpleName
                }
            }
            return JSONObject().put("ok", true).put("state", "LOADING").toString()
        }

        @JavascriptInterface fun engineStatus(): String = JSONObject()
            .put("state", engineState).put("message", engineMessage).toString()

        @JavascriptInterface fun startGeneration(prompt: String): String {
            if (engineState != "READY" || engine == null) return JSONObject()
                .put("ok", false).put("error", "نموذج الذكاء الاصطناعي غير جاهز.").toString()
            if (generationState == "GENERATING") return JSONObject()
                .put("ok", false).put("error", "هناك سؤال آخر قيد المعالجة.").toString()
            if (prompt.length > 18000) return JSONObject()
                .put("ok", false).put("error", "السؤال والسياق طويلان جدًا؛ اختصرهما.").toString()
            generationState = "GENERATING"
            generationResult = ""
            generationError = ""
            val activeEngine = engine ?: return JSONObject().put("ok", false).put("error", "المحرك غير متاح.").toString()
            worker.execute {
                try {
                    val answer = activeEngine.nativeGenerate(prompt)
                    if (answer.isBlank()) throw IllegalStateException("لم يُنتج النموذج إجابة.")
                    generationResult = answer
                    generationState = "DONE"
                } catch (e: Throwable) {
                    generationError = e.message ?: e.javaClass.simpleName
                    generationState = "ERROR"
                }
            }
            return JSONObject().put("ok", true).put("state", "GENERATING").toString()
        }

        @JavascriptInterface fun generationStatus(): String = JSONObject()
            .put("state", generationState).put("result", generationResult).put("error", generationError).toString()

        @JavascriptInterface fun showToast(message: String) {
            runOnUiThread { Toast.makeText(this@MainActivity, message.take(160), Toast.LENGTH_SHORT).show() }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        try { engine?.nativeUnload() } catch (_: Throwable) { }
        engine = null
        worker.shutdownNow()
        if (::webView.isInitialized) webView.destroy()
        super.onDestroy()
    }
}
