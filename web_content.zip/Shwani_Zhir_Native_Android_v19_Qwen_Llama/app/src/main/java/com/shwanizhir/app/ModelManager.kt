package com.shwanizhir.app

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Environment
import org.json.JSONObject
import java.io.File

/** Downloads the public GGUF weights only. Prompts and flock data are never uploaded. */
class ModelManager(private val context: Context) {
    companion object {
        const val MODEL_FILE = "qwen2.5-0.5b-instruct-q4_k_m.gguf"
        const val MODEL_URL = "https://huggingface.co/Qwen/Qwen2.5-0.5B-Instruct-GGUF/resolve/main/qwen2.5-0.5b-instruct-q4_k_m.gguf"
        const val EXPECTED_SHA256 = "74a4da8c9fdbcd15bd1f6d01d621410d31c6fc00986f5eb687824e7b93d7a9db"
        const val MIN_MODEL_BYTES = 100_000_000L
    }

    private val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
    private val prefs = context.getSharedPreferences("model_download", Context.MODE_PRIVATE)
    private val modelFile: File get() = File(context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), MODEL_FILE)

    @Synchronized fun start(): Long {
        val oldId = prefs.getLong("id", -1L)
        if (oldId > 0) {
            val old = query(oldId)
            if (old.optString("state") == "RUNNING" || old.optString("state") == "PENDING" || old.optString("state") == "PAUSED") return oldId
            if (old.optString("state") == "DOWNLOADED") return oldId
        }
        // A failed/incomplete previous file must not be mistaken for a completed model.
        if (modelFile.exists()) modelFile.delete()
        modelFile.parentFile?.mkdirs()
        val req = DownloadManager.Request(Uri.parse(MODEL_URL))
            .setTitle("Şwani Zhîr — Qwen2.5 0.5B")
            .setDescription("Downloading the offline AI model (about 491 MB)")
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setAllowedOverMetered(true)
            .setAllowedOverRoaming(false)
            .setDestinationInExternalFilesDir(context, Environment.DIRECTORY_DOWNLOADS, MODEL_FILE)
        val id = dm.enqueue(req)
        prefs.edit().putLong("id", id).apply()
        return id
    }

    fun status(): JSONObject = query(prefs.getLong("id", -1L))

    fun query(id: Long): JSONObject {
        val out = JSONObject()
        if (id <= 0) return out.put("state", "NOT_STARTED")
        val c = dm.query(DownloadManager.Query().setFilterById(id))
        c.use {
            if (!it.moveToFirst()) return out.put("state", "NOT_FOUND")
            val status = it.getInt(it.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
            val total = it.getLong(it.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES))
            val soFar = it.getLong(it.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR))
            val reason = it.getInt(it.getColumnIndexOrThrow(DownloadManager.COLUMN_REASON))
            var state = when (status) {
                DownloadManager.STATUS_PENDING -> "PENDING"
                DownloadManager.STATUS_RUNNING -> "RUNNING"
                DownloadManager.STATUS_PAUSED -> "PAUSED"
                DownloadManager.STATUS_SUCCESSFUL -> "DOWNLOADED"
                DownloadManager.STATUS_FAILED -> "FAILED"
                else -> "UNKNOWN"
            }
            if (state == "DOWNLOADED" && (!modelFile.exists() || modelFile.length() < MIN_MODEL_BYTES)) state = "FAILED"
            out.put("state", state).put("total", total).put("bytes", soFar).put("reason", reason)
            out.put("percent", if (total > 0) (soFar * 100 / total).toInt() else 0)
            if (state == "DOWNLOADED") out.put("path", modelFile.absolutePath)
        }
        return out
    }

    fun modelPath(): String = if (modelFile.exists() && modelFile.length() >= MIN_MODEL_BYTES) modelFile.absolutePath else ""
}
