package com.shwanizhir.app

/** JNI facade for the pinned llama.cpp b4510 native library. */
class LlamaEngine {
    external fun nativeLoadModel(path: String): String
    external fun nativeGenerate(prompt: String): String
    external fun nativeUnload()

    companion object {
        init { System.loadLibrary("shwani_llama") }
    }
}
