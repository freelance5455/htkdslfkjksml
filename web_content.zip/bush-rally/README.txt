Bush Rally

Open index.html in any browser (Chrome, Firefox, Safari). Works offline.
Saved coins and unlocked levels stay on your device.
