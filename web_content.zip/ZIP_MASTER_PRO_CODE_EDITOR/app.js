const editor=document.getElementById('editor'), lineNumbers=document.getElementById('lineNumbers');
const fileName=document.getElementById('fileName'), dirty=document.getElementById('dirty'), language=document.getElementById('language');
const fileInput=document.getElementById('fileInput'), toastBox=document.getElementById('toast');
let currentName='index.html', savedValue='', toastTimer;
const starter=`<!doctype html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>صفحتي الأولى</title>
  <style>
    body { font-family: sans-serif; padding: 30px; }
    h1 { color: #168f78; }
  </style>
</head>
<body>
  <h1>مرحباً بك!</h1>
  <p>ابدأ بكتابة مشروعك هنا.</p>
</body>
</html>`;
editor.value=starter;savedValue=starter;
function toast(message){toastBox.textContent=message;toastBox.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>toastBox.classList.remove('show'),2100)}
function updateLines(){const count=editor.value.split('\\n').length;lineNumbers.textContent=Array.from({length:count},(_,i)=>i+1).join('\\n');lineNumbers.scrollTop=editor.scrollTop;dirty.textContent=editor.value!==savedValue?'●':'';document.getElementById('status').textContent=editor.value!==savedValue?'تعديلات غير محفوظة':'جاهز';updateCursor()}
function updateCursor(){const before=editor.value.slice(0,editor.selectionStart),lines=before.split('\\n');document.getElementById('cursorPos').textContent=`سطر ${lines.length} · عمود ${lines[lines.length-1].length+1}`}
editor.addEventListener('input',updateLines);editor.addEventListener('click',updateCursor);editor.addEventListener('keyup',updateCursor);editor.addEventListener('scroll',()=>lineNumbers.scrollTop=editor.scrollTop);
editor.addEventListener('keydown',e=>{if(e.key==='Tab'){e.preventDefault();const a=editor.selectionStart,b=editor.selectionEnd;editor.setRangeText('  ',a,b,'end');updateLines()}if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='s'){e.preventDefault();saveFile()}});
function extension(name){return (name.split('.').pop()||'').toLowerCase()}
function setLanguage(name){const ext=extension(name);language.value=({html:'html',htm:'html',css:'css',js:'javascript',mjs:'javascript',json:'json'})[ext]||'text'}
function saveFile(){const blob=new Blob([editor.value],{type:'text/plain;charset=utf-8'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=currentName;a.click();URL.revokeObjectURL(url);savedValue=editor.value;updateLines();toast('تم تجهيز الملف للحفظ')}
document.getElementById('saveBtn').addEventListener('click',saveFile);
document.getElementById('openBtn').addEventListener('click',()=>fileInput.click());
fileInput.addEventListener('change',async()=>{const file=fileInput.files&&fileInput.files[0];if(!file)return;try{editor.value=await file.text();currentName=file.name;fileName.textContent=currentName;setLanguage(currentName);savedValue=editor.value;updateLines();toast('تم فتح '+currentName)}catch(e){toast('تعذر قراءة الملف')}fileInput.value=''});
document.getElementById('newBtn').addEventListener('click',()=>{if(editor.value!==savedValue&&!confirm('لديك تعديلات غير محفوظة. إنشاء ملف جديد؟'))return;editor.value='';currentName='untitled.txt';fileName.textContent=currentName;language.value='text';savedValue='';updateLines();editor.focus()});
document.getElementById('language').addEventListener('change',()=>toast('اللغة: '+language.options[language.selectedIndex].text));
const panel=document.getElementById('previewPanel');
function preview(){if(language.value!=='html'){toast('المعاينة متاحة لملفات HTML فقط');return}document.getElementById('previewFrame').srcdoc=editor.value;panel.hidden=false;panel.scrollIntoView({behavior:'smooth',block:'start'})}
document.getElementById('previewBtn').addEventListener('click',preview);document.getElementById('closePreview').addEventListener('click',()=>panel.hidden=true);
document.getElementById('filesNav').addEventListener('click',()=>fileInput.click());
document.getElementById('homeNav').addEventListener('click',()=>toast('أضف هذا الزر إلى شاشة ZIP MASTER PRO الرئيسية'));
document.getElementById('settingsNav').addEventListener('click',()=>toast('الإعدادات الأساسية: محرر محلي دون إنترنت'));
document.getElementById('menuBtn').addEventListener('click',()=>toast('محرر الأكواد — إصدار محلي'));
updateLines();setLanguage(currentName);
