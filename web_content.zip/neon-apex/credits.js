'use strict';
/* NEON APEX — developer credits (standalone file, loaded after script.js).
   Adds a DEVELOPERS button to the main menu and the pause menu; it opens a panel where each developer's
   name is a link to their Instagram profile. To add or remove a developer, edit the DEVS list below.
   It does not touch gameplay: if this file fails, the game still runs. */
(()=>{
const DEVS=[
  {name:'abdel.azizbn',     url:'https://www.instagram.com/abdel.azizbn/'},
  {name:'i.__.m.__.a.__.n', url:'https://www.instagram.com/i.__.m.__.a.__.n/'}
];

try{
  const css=`
#devs{position:fixed;inset:0;z-index:40;display:flex;justify-content:center;align-items:center;background:rgba(5,9,40,.8);
  padding:env(safe-area-inset-top,0px) env(safe-area-inset-right,0px) env(safe-area-inset-bottom,0px) env(safe-area-inset-left,0px)}
.dvp{width:min(420px,92vw);max-height:calc(100% - 12px);overflow-y:auto;touch-action:pan-y;background:rgba(8,14,56,.96);border:1px solid #6f86ff;
  box-shadow:0 0 30px rgba(111,134,255,.45);padding:18px 18px 16px;display:flex;flex-direction:column;gap:12px}
.dvp h3{font-size:22px;font-style:italic;font-weight:900;color:#ffe83a;letter-spacing:.04em}
.dvp p{font-size:12px;color:#8fa3ec;max-width:none;line-height:1.5}
.dvl{display:flex;flex-direction:column;gap:10px}
.dva{display:flex;align-items:center;gap:14px;padding:14px 16px;border:1px solid #6f86ff;color:#fff;text-decoration:none;
  background:linear-gradient(90deg,rgba(40,232,255,.1),transparent);touch-action:manipulation;transition:border-color .15s,box-shadow .15s}
.dva:hover,.dva:focus-visible{border-color:#28e8ff;box-shadow:0 0 18px rgba(40,232,255,.45);outline:none}
.dva svg{flex:none;width:26px;height:26px;fill:none;stroke:#ff3fd0;stroke-width:2;stroke-linecap:round;filter:drop-shadow(0 0 4px #ff3fd0)}
.dva b{font-size:16px;word-break:break-all}.dva small{display:block;margin-top:2px;letter-spacing:.2em;font-size:9px;color:#28e8ff}
.dvp .btn{align-self:stretch;text-align:center;padding:12px}
@media(max-height:520px){.dvp{padding:12px 14px;gap:8px}.dvp h3{font-size:18px}.dva{padding:10px 14px}}`;
  const st=document.createElement('style');st.textContent=css;document.head.appendChild(st);

  const ov=document.createElement('section');ov.id='devs';ov.hidden=true;
  const box=document.createElement('div');box.className='dvp';
  const h=document.createElement('h3');h.textContent='DEVELOPERS';
  const p=document.createElement('p');p.textContent='Tap a name to open the developer\'s Instagram.';
  const list=document.createElement('div');list.className='dvl';
  for(const d of DEVS){
    const a=document.createElement('a');a.className='dva';a.href=d.url;a.target='_blank';a.rel='noopener noreferrer';
    a.innerHTML='<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.2" cy="6.8" r=".6"/></svg>';
    const t=document.createElement('span'),b=document.createElement('b'),s=document.createElement('small');
    b.textContent='@'+d.name;s.textContent='INSTAGRAM';t.append(b,s);a.appendChild(t);list.appendChild(a)}
  const x=document.createElement('button');x.className='btn alt';x.textContent='CLOSE';
  box.append(h,p,list,x);ov.appendChild(box);document.body.appendChild(ov);

  const open=()=>{ov.hidden=false;x.focus({preventScroll:true})},close=()=>{ov.hidden=true};
  x.addEventListener('click',close);
  ov.addEventListener('pointerdown',e=>{if(e.target===ov)close()});          // tap outside the panel closes it
  // while open, keep game hotkeys (Space/Enter start, Esc pause, R restart, M mute) away from the game
  addEventListener('keydown',e=>{if(ov.hidden)return;e.stopImmediatePropagation();if(e.code==='Escape'){e.preventDefault();close()}},true);

  const mk=parent=>{if(!parent)return;const b=document.createElement('button');b.className='btn alt';b.textContent='DEVELOPERS';b.addEventListener('click',open);
    (parent.classList.contains('btnrow')?parent:parent).appendChild(b)};
  mk(document.querySelector('#menu .btnrow'));mk(document.getElementById('pause'));
}catch(err){console.error('[NEON APEX] credits module failed to start; the game continues without it',err)}
})();
