'use strict';
/* NEON APEX — progression: XP, levels, personal records, lifetime stats.
   Optional module, loaded after script.js. It only listens to the NA event bus (start / tick / nearmiss / crash / over)
   and reads G; it never changes gameplay. If it fails to initialise, the base game is unaffected.
   Storage: 'na_prog_v1' (progress) and 'na_settings_v1' (shared settings, key "progress"). */
(()=>{
let S,run,enabled=true,dirty=false,lastSave=0;
const KEY='na_prog_v1',SET='na_settings_v1',MAXLV=50,M_PER_XP=40,XP_NEAR=5,SCORE_PER_XP=400;
const need=l=>Math.round(120*Math.pow(l,1.35));                 // XP required to go from level l to l+1
const nz=(v,mx=1e12)=>typeof v==='number'&&isFinite(v)&&v>=0?Math.min(v,mx):0;
const $$=id=>document.getElementById(id);

/* ---------- persistence (invalid / missing / outdated data falls back to defaults) ---------- */
const fresh=()=>({v:1,level:1,xp:0,totalXP:0,rec:{dist:0,speed:0,score:0,clean:0},tot:{dist:0,runs:0,crashes:0,near:0,time:0}});
function sanitize(j){const d=fresh();if(!j||typeof j!=='object'||j.v!==1)return d;
  d.level=Math.min(MAXLV,Math.max(1,Math.floor(nz(j.level)||1)));d.xp=Math.floor(nz(j.xp,1e9));d.totalXP=Math.floor(nz(j.totalXP,1e12));
  if(d.level>=MAXLV)d.xp=0;else if(d.xp>=need(d.level))d.xp=need(d.level)-1;
  for(const k in d.rec)d.rec[k]=nz((j.rec||{})[k]);for(const k in d.tot)d.tot[k]=nz((j.tot||{})[k]);return d}
function load(){try{return sanitize(JSON.parse(localStorage.getItem(KEY)))}catch(e){console.warn('[NEON APEX] progress save unreadable, starting fresh',e);return fresh()}}
function save(){dirty=false;lastSave=performance.now();try{localStorage.setItem(KEY,JSON.stringify(S))}catch(e){console.warn('[NEON APEX] could not save progress',e)}}
function readSet(){try{const j=JSON.parse(localStorage.getItem(SET));return j&&typeof j==='object'?j:{}}catch(e){return{}}}
function setEnabled(b){enabled=!!b;const j=readSet();j.progress=enabled;try{localStorage.setItem(SET,JSON.stringify(j))}catch(e){console.warn('[NEON APEX] could not save settings',e)}
  if(!enabled&&run.active)run.active=false}                        // stop tracking immediately; nothing from a half-run is awarded

/* ---------- run tracking ---------- */
const newRun=()=>({active:false,lastDist:0,acc:0,clean:0,bestClean:0,xpGain:0,crashes:0,near:0,time:0,score:0,top:0,lv0:1});
function begin(){run=newRun();run.lv0=S.level;run.active=enabled}
function snap(){run.score=G.score;run.top=Math.max(run.top,G.top)}

/* ---------- XP ---------- */
let leveled=0;
function gain(n){if(!enabled||n<=0)return;
  S.xp+=n;S.totalXP+=n;run.xpGain+=n;dirty=true;
  while(S.level<MAXLV&&S.xp>=need(S.level)){S.xp-=need(S.level);S.level++;leveled=S.level}
  if(S.level>=MAXLV)S.xp=0;
  paint();if(leveled){levelUp(leveled);leveled=0;save()}}
function levelUp(l){const e=$$('lvup');if(e){e.textContent='LEVEL UP · LV '+l;e.classList.remove('on');void e.offsetWidth;e.classList.add('on')}
  try{if(A.c&&!A.m){A.blip(880);setTimeout(()=>A.blip(1320),120)}}catch(err){console.warn('[NEON APEX] level-up sound failed',err)}}

/* ---------- HUD (DOM is touched only when a displayed value changes) ---------- */
const shown={};
function setTxt(id,t){const e=$$(id);if(e&&shown[id]!==t){shown[id]=t;e.textContent=t}}
function setW(id,p){const e=$$(id);if(e&&shown[id]!==p){shown[id]=p;e.style.width=p+'%'}}
function paint(){const mx=S.level>=MAXLV,nd=need(S.level),p=mx?100:Math.floor(S.xp/nd*100),xt=mx?'MAX':S.xp+' / '+nd+' XP';
  setTxt('lvn',S.level);setTxt('mlvn',S.level);setW('lvf',p);setW('mlvf',p);setTxt('lvxp',xt);setTxt('mlvxp',xt)}

/* ---------- end of run: records, stats, bonus XP, game-over summary ---------- */
const RN={dist:'LONGEST DISTANCE',speed:'TOP SPEED',score:'HIGH SCORE',clean:'LONGEST CLEAN DRIVE'};
const fmt={dist:v=>(v/1000).toFixed(2)+' km',speed:v=>Math.round(v)+' km/h',score:v=>String(Math.floor(v)).padStart(6,'0'),clean:v=>(v/1000).toFixed(2)+' km'};
function finish(completed){
  if(!run||!run.active)return;run.active=false;
  gain(Math.floor(run.score/SCORE_PER_XP));                        // end-of-run score bonus, paid once because run.active is now false
  const vals={dist:run.lastDist,speed:run.top*3.6,score:run.score,clean:run.bestClean},news=[];
  for(const k in vals){const v=Math.floor(vals[k]);if(v>S.rec[k]){if(S.rec[k]>0)news.push(k);S.rec[k]=v}}   // first-ever value is a baseline, not an "NEW RECORD"
  if(completed)S.tot.runs++;
  dirty=true;save();paint();
  if(completed)summary(news)}
function summary(news){const e=$$('recs');if(!e)return;
  const lv=S.level>run.lv0?` · <span class="rec">LEVEL ${run.lv0} → ${S.level}</span>`:'';
  let h=`<b>+${run.xpGain} XP</b> · LV ${S.level}${lv}`;
  for(const k of news)h+=`<br><span class="rec">NEW RECORD</span> ${RN[k]} · <b>${fmt[k](S.rec[k])}</b>`;
  e.innerHTML=h}

/* ---------- event handlers (registered only after a successful init) ---------- */
function wire(){
NA.on('start',()=>{if(run&&run.active)finish(false);const e=$$('recs');if(e)e.textContent='';begin()});
NA.on('tick',dt=>{if(!run||!run.active||G.state!=='playing')return;
  const d=G.dist-run.lastDist;
  if(d>0){run.lastDist=G.dist;S.tot.dist+=d;run.clean+=d;if(run.clean>run.bestClean)run.bestClean=run.clean;
    run.acc+=d;let n=0;while(run.acc>=M_PER_XP){run.acc-=M_PER_XP;n++}if(n)gain(n)}
  S.tot.time+=dt;run.time+=dt;snap();dirty=true;
  if(performance.now()-lastSave>5000)save()});
NA.on('nearmiss',()=>{if(!run||!run.active)return;run.near++;S.tot.near++;gain(XP_NEAR)});
NA.on('crash',()=>{if(!run||!run.active)return;run.crashes++;S.tot.crashes++;run.clean=0;snap();dirty=true});
NA.on('over',()=>{if(!run||!run.active)return;snap();finish(true)});            // a repeated 'over' is ignored and keeps the summary
addEventListener('pagehide',()=>{if(dirty)save()});
document.addEventListener('visibilitychange',()=>{if(document.hidden&&dirty)save()})}

/* ---------- init ---------- */
try{
  S=load();run=newRun();enabled=readSet().progress!==false;paint();wire();
  window.NAProg={get state(){return S},get run(){return run},get enabled(){return enabled},setEnabled,need,save,
    stats(){return{level:S.level,xp:S.xp,next:S.level>=MAXLV?0:need(S.level),totalXP:S.totalXP,records:{...S.rec},totals:{...S.tot}}}};
}catch(err){console.error('[NEON APEX] progress module failed to start; the base game continues without it',err);window.NAProg=null}
})();
