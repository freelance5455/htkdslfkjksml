'use strict';
/* NEON APEX — HTML/CSS/vanilla JS + Three.js r128 (global THREE from CDN).
   Sections: utils · city chunks · vehicles · audio · game state/physics · camera/HUD · main loop. */
const S=150,W=24,RAD=2,FOG=0x1a3a9e,NT=14,PI2=Math.PI*2;
const $=id=>document.getElementById(id),rs=(a,b)=>a+Math.random()*(b-a),clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const rng32=s=>()=>{s=s+0x6D2B79F5|0;let t=Math.imul(s^s>>>15,1|s);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296};
const PAL=[0xff3fd0,0x28e8ff,0xffd23a,0xb455ff,0xff7a2a],TINT=[0x4a6bff,0x7a4cff,0x2fa8ff,0x5a5cff,0xb04cff];

/* ---------- event bus for optional modules (progress.js ...). A failing handler is logged and, after 3 errors, removed; it never breaks the game ---------- */
const NA={h:{},on(e,f){(this.h[e]||(this.h[e]=[])).push(f)},emit(e,a){const l=this.h[e];if(!l)return;
  for(const f of l.slice()){try{f(a)}catch(err){console.error('[NEON APEX] module error in "'+e+'":',err);
    if((f.err=(f.err||0)+1)>=3){l.splice(l.indexOf(f),1);console.error('[NEON APEX] handler for "'+e+'" disabled after repeated errors')}}}}};

/* ---------- renderer / scene ---------- */
const renderer=new THREE.WebGLRenderer({canvas:$('c'),antialias:true});
renderer.setPixelRatio(Math.min(devicePixelRatio,1.75));
const scene=new THREE.Scene();scene.fog=new THREE.FogExp2(FOG,.0052);
const cam=new THREE.PerspectiveCamera(62,1,.3,900);
const fxc=$('fx'),fxg=fxc.getContext('2d');
function resize(){renderer.setSize(innerWidth,innerHeight,false);cam.aspect=innerWidth/innerHeight;cam.updateProjectionMatrix();fxc.width=innerWidth;fxc.height=innerHeight}
addEventListener('resize',resize);resize();

/* ---------- procedural textures ---------- */
function tex(w,h,draw,rep){const c=document.createElement('canvas');c.width=w;c.height=h;draw(c.getContext('2d'),w,h);
  const t=new THREE.CanvasTexture(c);if(rep)t.wrapS=t.wrapT=THREE.RepeatWrapping;t.anisotropy=4;return t}
scene.background=tex(2,256,(g,w,h)=>{const gr=g.createLinearGradient(0,0,0,h);gr.addColorStop(0,'#040932');gr.addColorStop(.5,'#1a3a9e');gr.addColorStop(1,'#1a3a9e');g.fillStyle=gr;g.fillRect(0,0,w,h)});
const winTex=tex(256,512,(g)=>{g.fillStyle='#2a2a2a';g.fillRect(0,0,256,512);
  for(let i=0;i<4;i++)for(let j=0;j<8;j++){const l=Math.random(),v=90+l*300|0;g.fillStyle=l<.5?`rgb(${v},${v},${v+10})`:'#101010';g.fillRect(i*64+14,j*64+14,36,36)}},1);
const signTex=tex(512,256,(g)=>{g.strokeStyle=g.fillStyle=g.shadowColor='#fff';g.shadowBlur=10;g.lineWidth=7;
  for(let i=0;i<4;i++){const x=i*128+14;g.strokeRect(x,14,100,228);
    if(i==0)for(let k=0;k<6;k++)g.fillRect(x+16,34+k*34,68,14);
    if(i==1)for(let k=0;k<5;k++)g.fillRect(x+14+k*17,30,8,196);
    if(i==2){g.strokeRect(x+14,30,72,196);for(let k=0;k<4;k++)g.fillRect(x+30,50+k*42,40,16)}
    if(i==3)for(let k=0;k<4;k++)g.fillRect(x+14,30+k*54,72,34)}});
const poolTex=tex(64,64,(g)=>{const r=g.createRadialGradient(32,32,0,32,32,32);r.addColorStop(0,'rgba(255,255,255,.55)');r.addColorStop(1,'rgba(255,255,255,0)');g.fillStyle=r;g.fillRect(0,0,64,64)});
const add={blending:THREE.AdditiveBlending,transparent:true,depthWrite:false,vertexColors:true};
const M={bld:new THREE.MeshBasicMaterial({map:winTex,vertexColors:true}),
  solid:new THREE.MeshBasicMaterial({vertexColors:true}),
  glow:new THREE.MeshBasicMaterial({vertexColors:true,side:THREE.DoubleSide}),
  sign:new THREE.MeshBasicMaterial({map:signTex,side:THREE.DoubleSide,...add}),
  pool:new THREE.MeshBasicMaterial({map:poolTex,...add})};

/* ---------- geometry builder: merges quads/boxes into ONE mesh (few draw calls) ---------- */
class B{
  constructor(){this.p=[];this.c=[];this.u=[]}
  q(a,b,c,d,col,sh,uv){const k=new THREE.Color(col).multiplyScalar(sh||1),t=uv||[0,0,1,0,1,1,0,1];
    for(const i of[0,1,2,0,2,3]){this.p.push(...[a,b,c,d][i]);this.c.push(k.r,k.g,k.b);this.u.push(t[2*i],t[2*i+1])}}
  box(x0,y0,z0,x1,y1,z1,col,su=0,sv=0,ou=0,ov=0){const h=y1-y0,w=x1-x0,d=z1-z0,f=(a)=>su?[ou,ov,ou+a*su,ov,ou+a*su,ov+h*sv,ou,ov+h*sv]:null;
    this.q([x1,y0,z1],[x1,y0,z0],[x1,y1,z0],[x1,y1,z1],col,.65,f(d));
    this.q([x0,y0,z0],[x0,y0,z1],[x0,y1,z1],[x0,y1,z0],col,.65,f(d));
    this.q([x0,y0,z1],[x1,y0,z1],[x1,y1,z1],[x0,y1,z1],col,.8,f(w));
    this.q([x1,y0,z0],[x0,y0,z0],[x0,y1,z0],[x1,y1,z0],col,.8,f(w));
    this.q([x0,y1,z1],[x1,y1,z1],[x1,y1,z0],[x0,y1,z0],col,1,su?Array(8).fill(.01):null)}
  flat(x0,z0,x1,z1,y,col){this.q([x0,y,z1],[x1,y,z1],[x1,y,z0],[x0,y,z0],col,1)}
  qo(a,b,c,d,col,sh){const ux=b[0]-a[0],uy=b[1]-a[1],uz=b[2]-a[2],vx=c[0]-a[0],vy=c[1]-a[1],vz=c[2]-a[2],m=this.m,
    n=[uy*vz-uz*vy,uz*vx-ux*vz,ux*vy-uy*vx],f=[(a[0]+c[0])/2-m[0],(a[1]+c[1])/2-m[1],(a[2]+c[2])/2-m[2]];
    n[0]*f[0]+n[1]*f[1]+n[2]*f[2]<0?this.q(a,d,c,b,col,sh):this.q(a,b,c,d,col,sh)}
  pr(r0,y0,r1,y1,col){const c=(r,y)=>[[r[0],y,r[3]],[r[2],y,r[3]],[r[2],y,r[1]],[r[0],y,r[1]]],p=c(r0,y0),t=c(r1,y1);   // r=[x0,z0,x1,z1]
    this.m=[(r0[0]+r0[2])/2,(y0+y1)/2,(r0[1]+r0[3])/2];
    for(let i=0;i<4;i++){const j=(i+1)%4;this.qo(p[i],p[j],t[j],t[i],col,i%2?.62:.84)}this.qo(t[0],t[1],t[2],t[3],col,1.08)}
  mesh(mat,ro=0){if(!this.p.length)return null;const g=new THREE.BufferGeometry();
    g.setAttribute('position',new THREE.Float32BufferAttribute(this.p,3));g.setAttribute('color',new THREE.Float32BufferAttribute(this.c,3));
    g.setAttribute('uv',new THREE.Float32BufferAttribute(this.u,2));g.computeBoundingSphere();
    const m=new THREE.Mesh(g,mat);m.renderOrder=ro;return m}
}

/* ---------- city: infinite street grid streamed in chunks ----------
   Chunk (cx,cz): block [x0..x1]x[z0..z1]; streets (width W) run along x=cx*S and z=cz*S.
   Wet-road reflections: neon/buildings are mirrored under a semi-transparent ground plane. */
function makeChunk(cx,cz){
  const R=rng32(cx*73856093^cz*19349663^7),r=(a,b)=>a+R()*(b-a);
  const x0=cx*S+W/2,z0=cz*S+W/2,x1=(cx+1)*S-W/2,z1=(cz+1)*S-W/2,X=cx*S,Z=cz*S;
  const base=new B(),bl=new B(),sg=new B(),gl=new B(),pl=new B(),circles=[];
  base.box(x0,0,z0,x1,.3,z1,0x2a3f9a);                       // sidewalk slab = solid block
  const edge=(cx+cz)&1?PAL[0]:PAL[1];
  for(const s of[-1,1]){base.flat(X+s*10.6-.18,z0,X+s*10.6+.18,z1,.03,edge);base.flat(x0,Z+s*10.6-.18,x1,Z+s*10.6+.18,.03,edge)}
  for(let t=z0+4;t<z1-8;t+=10)base.flat(X-.15,t,X+.15,t+4,.03,0xdde8ff);
  for(let t=x0+4;t<x1-8;t+=10)base.flat(t,Z-.15,t+4,Z+.15,.03,0xdde8ff);
  for(let t=-W/2+1.5;t<W/2-2;t+=2.8){                         // zebra crossings
    for(const[a,b]of[[z0+1,z0+4.5],[z1-4.5,z1-1]])base.flat(X+t,a,X+t+1.4,b,.04,0xe8f0ff);
    for(const[a,b]of[[x0+1,x0+4.5],[x1-4.5,x1-1]])base.flat(a,Z+t,b,Z+t+1.4,.04,0xe8f0ff)}
  const P=(ax,f,a,y)=>ax=='z'?[a,y,f]:[f,y,a];
  const face=(b,ax,f,a0,a1,y0,y1,col,uv)=>b.q(P(ax,f,a0,y0),P(ax,f,a1,y0),P(ax,f,a1,y1),P(ax,f,a0,y1),col,1,uv);
  const mx=r(.4,.6)*(x1-x0)+x0,mz=r(.4,.6)*(z1-z0)+z0,g=3;
  for(const l of[[x0+2,z0+2,mx-g,mz-g],[mx+g,z0+2,x1-2,mz-g],[x0+2,mz+g,mx-g,z1-2],[mx+g,mz+g,x1-2,z1-2]]){
    const h=R()<.25?r(8,16):r(25,105),a0=l[0]+r(0,4),b0=l[1]+r(0,4),a1=l[2]-r(0,4),b1=l[3]-r(0,4),t=TINT[R()*5|0];
    bl.box(a0,.3,b0,a1,h,b1,t,1/12,1/28,R(),R());
    if(h>40)bl.box(a0+6,h,b0+6,a1-6,h+r(6,16),b1-6,t,1/12,1/28,R(),R());
    for(const[ax,f,c,w,near,sd]of[['z',b0-.3,(a0+a1)/2,a1-a0,b0-z0<6,z0-7],['z',b1+.3,(a0+a1)/2,a1-a0,z1-b1<6,z1+7],
                                    ['x',a0-.3,(b0+b1)/2,b1-b0,a0-x0<6,x0-7],['x',a1+.3,(b0+b1)/2,b1-b0,x1-a1<6,x1+7]]){
      if(!near)continue;
      face(gl,ax,f,c-w*.45,c+w*.45,3,3.4,PAL[R()*5|0]);        // neon base strip
      for(let k=R()*2+1|0;k>0;k--){                            // neon signs + light pool on the road
        const w2=r(3,5),h2=Math.min(r(9,20),h*.7),a=c+r(-w/3,w/3),y=r(3,Math.max(3.5,h-h2-1)),col=PAL[R()*5|0],i=R()*4|0;
        face(sg,ax,f,a-w2/2,a+w2/2,y,y+h2,col,[i/4,0,(i+1)/4,0,(i+1)/4,1,i/4,1]);
        const px=ax=='z'?a:sd,pz=ax=='z'?sd:a;pl.flat(px-8,pz-8,px+8,pz+8,.06,col)}}
  }
  const lamp=(px,pz,dx,dz)=>{const c=[0xffd9a0,0x9fd8ff,PAL[0]][R()*3|0],ex=px+dx*2.8,ez=pz+dz*2.8;
    base.box(px-.15,.3,pz-.15,px+.15,9,pz+.15,0x161b3c);
    base.box(Math.min(px,ex)-.1,8.8,Math.min(pz,ez)-.1,Math.max(px,ex)+.1,9,Math.max(pz,ez)+.1,0x161b3c);
    gl.box(ex-.5,8.7,ez-.5,ex+.5,8.85,ez+.5,c);pl.flat(ex+dx*.7-7,ez+dz*.7-7,ex+dx*.7+7,ez+dz*.7+7,.07,c)};
  for(let t=18;t<S-W-30;t+=44){lamp(x0+.8,z0+t,-1,0);lamp(x1-.8,z0+t+22,1,0);lamp(x0+t,z0+.8,0,-1);lamp(x0+t+22,z1-.8,0,1)}
  if(R()<.6){const bx=X+(R()<.5?-6:6)+r(-2,2),bz=r(z0+25,z1-25);       // road barrier obstacle
    base.box(bx-2,0,bz-.4,bx+2,1.1,bz+.4,0xff7a14);gl.box(bx-2,1.1,bz-.45,bx+2,1.3,bz+.45,0xffffff);
    for(const o of[-1.3,0,1.3])circles.push({x:bx+o,z:bz,r:1.1});pl.flat(bx-6,bz-6,bx+6,bz+6,.06,PAL[4])}
  const grp=new THREE.Group();
  const put=(b,mat,ro,mir)=>{const m=b.mesh(mat,ro);if(!m)return;grp.add(m);
    if(mir){const k=new THREE.Mesh(m.geometry,mat);k.scale.y=-1;k.renderOrder=mat===M.sign?1:0;grp.add(k)}};
  put(base,M.solid,0,0);put(bl,M.bld,0,1);put(gl,M.glow,0,1);put(sg,M.sign,10,1);put(pl,M.pool,6,0);
  return{cx,cz,grp,box:[x0,z0,x1,z1],circles}}

const chunks=new Map();
function updateChunks(all){
  const pcx=Math.floor(G.x/S),pcz=Math.floor(G.z/S);let n=0;
  for(let i=-RAD;i<=RAD;i++)for(let j=-RAD;j<=RAD;j++){const k=(pcx+i)+','+(pcz+j);
    if(!chunks.has(k)&&(all||n<2)){const c=makeChunk(pcx+i,pcz+j);scene.add(c.grp);chunks.set(k,c);n++}}
  for(const[k,c]of chunks)if(Math.abs(c.cx-pcx)>RAD+1||Math.abs(c.cz-pcz)>RAD+1){
    scene.remove(c.grp);c.grp.traverse(o=>o.geometry&&o.geometry.dispose());chunks.delete(k)}}

const roadTex=tex(256,256,(g)=>{g.fillStyle='#0b1a55';g.fillRect(0,0,256,256);
  for(let i=0;i<9;i++){g.fillStyle=`rgba(${20+i*4},${40+i*5},${110+i*6},.5)`;g.fillRect(Math.random()*200,Math.random()*200,20+Math.random()*60,20+Math.random()*60)}
  for(let i=0;i<500;i++){g.fillStyle='rgba(120,150,255,.12)';g.fillRect(Math.random()*256,Math.random()*256,1,1)}
  g.fillStyle='rgba(60,90,200,.55)';g.fillRect(0,0,256,1.5);g.fillRect(0,0,1.5,256);g.fillRect(0,127,256,1);
  g.globalCompositeOperation='destination-out';
  for(let i=0;i<7;i++){const x=50+Math.random()*156,y=50+Math.random()*156,r=g.createRadialGradient(x,y,0,x,y,40);r.addColorStop(0,'rgba(0,0,0,.45)');r.addColorStop(1,'rgba(0,0,0,0)');g.fillStyle=r;g.fillRect(x-40,y-40,80,80)}},1);
roadTex.repeat.set(40,40);
const ground=new THREE.Mesh(new THREE.PlaneGeometry(1400,1400).rotateX(-Math.PI/2),
  new THREE.MeshBasicMaterial({map:roadTex,transparent:true,opacity:.68,depthWrite:false}));
ground.renderOrder=5;scene.add(ground);

/* ---------- vehicles ---------- */
function buildCar(body,van){
  const b=new B(),g=new B(),h=van?1:0;
  b.box(-.95,.3,-1.4,.95,.8,2.2,body);b.box(-.9,.3,-2.2,.9,.6,-1.4,body);          // body + nose
  b.box(-.75,.8,.1,.75,1.25+h,1.5,0x0b1648);b.box(-.7,1.25+h,.2,.7,1.3+h,1.4,body); // glass cabin + roof
  b.box(-1,1.15,1.95,1,1.22,2.25,0x08102a);b.box(-.8,.8,2,-.7,1.15,2.1,0x08102a);b.box(.7,.8,2,.8,1.15,2.1,0x08102a); // spoiler
  for(const s of[-1,1])for(const z of[-1.3,1.4])b.box(s>0?.9:-1.1,0,z-.4,s>0?1.1:-.9,.7,z+.4,0x07091a);                  // wheels
  g.box(-.8,.55,2.2,.8,.68,2.24,0xff2a4a);g.box(-.8,.5,-2.24,-.4,.6,-2.2,0xbff4ff);g.box(.4,.5,-2.24,.8,.6,-2.2,0xbff4ff);g.box(-.9,.12,-2,.9,.16,2,body===0xffc21a?0xff3fd0:0x28e8ff);
  const grp=new THREE.Group();grp.add(b.mesh(M.solid),g.mesh(M.glow));return grp}
function mirrorOf(g){const m=g.clone();m.scale.y=-1;m.rotation.order='YXZ';g.rotation.order='YXZ';return m}

/* Detailed player car: sculpted body (tapered prisms), glass + interior, 4 real round wheels (tyre, sidewall, spokes,
   hub, disc, caliper), wing, diffuser, exhausts, separate LED head/tail/brake/reverse lights. Body (bodyG) rolls/pitches
   on springs while wheels stay on the road. A second instance (scale.y=-1) is the wet-road reflection. */
const PM=c=>new THREE.MeshBasicMaterial({color:c}),mats={tail:PM(0x7a1020),rev:PM(0x111111),tire:PM(0x0b0d1a),side:PM(0x1c2240),rim:PM(0x1a2040),
  spoke:PM(0xdfe6ff),disc:PM(0x707a9c),cal:PM(0xff2a3a),hub:PM(0xdfe6ff),glass:new THREE.MeshBasicMaterial({vertexColors:true,transparent:true,opacity:.55,depthWrite:false})};
const gTire=new THREE.CylinderGeometry(.36,.36,.26,24).rotateZ(Math.PI/2),gSide=new THREE.TorusGeometry(.3,.055,8,24).rotateY(Math.PI/2),
  gRim=new THREE.CylinderGeometry(.25,.25,.28,20).rotateZ(Math.PI/2),gDisc=new THREE.CylinderGeometry(.2,.2,.03,20).rotateZ(Math.PI/2),
  gSpoke=new THREE.BoxGeometry(.03,.46,.06),gHub=new THREE.CylinderGeometry(.06,.06,.3,10).rotateZ(Math.PI/2),gCal=new THREE.BoxGeometry(.07,.13,.16);
function wheel(side,z){const piv=new THREE.Group(),spin=new THREE.Group(),o=side*.16,add=(g,m,x)=>{const e=new THREE.Mesh(g,m);e.position.x=x||0;spin.add(e);return e};
  piv.position.set(side*.93,.36,z);piv.add(spin);add(gTire,mats.tire);add(gSide,mats.side,o*.85);add(gSide,mats.side,-o*.85);add(gRim,mats.rim,o*.1);add(gHub,mats.hub,o*.1);
  for(let k=0;k<3;k++){const e=add(gSpoke,mats.spoke,o*.95);e.rotation.x=k*Math.PI/3}
  add(gDisc,mats.disc,-o*.45);const c=new THREE.Mesh(gCal,mats.cal);c.position.set(-o*.45,.2,0);piv.add(c);return{piv,spin}}
function buildPlayer(real){
  const P=0xffc21a,D=0x0c1024,C=0x171b30,AC=0xff6a14,b=new B(),g=new B(),gl2=new B(),tl=new B(),rv=new B(),gs=new B();
  b.pr([-.95,-2.2,.95,2.2],.28,[-.9,-2,.9,2.15],.72,P);                       // lower body
  b.pr([-.9,-2,.9,-.3],.72,[-.78,-1.75,.78,-.3],.84,P);                         // hood
  b.pr([-.9,1.6,.9,2.15],.72,[-.82,1.65,.82,2.1],.86,P);                        // trunk deck
  b.box(-.1,.84,-1.7,.1,.855,-.4,AC);b.box(-.45,.84,-1.2,-.3,.855,-.7,D);b.box(.3,.84,-1.2,.45,.855,-.7,D);b.box(-.3,.62,-2.18,.3,.7,-2.1,D);   // stripe, hood vents, air intake
  b.box(-1,.2,-2.35,1,.28,-1.95,C);b.box(-.5,.34,-2.19,.5,.5,-2.1,D);        // splitter, grille
  b.pr([-.6,.35,.6,1.2],1.28,[-.58,.38,.58,1.18],1.31,P);b.box(-.1,1.31,.4,.1,1.315,1.2,AC);   // roof + stripe
  gs.pr([-.85,-.3,.85,1.7],.72,[-.62,.35,.62,1.25],1.28,0x7fb2ff);      // glass cabin (windshield, side, rear)
  b.box(-.6,.72,-.1,.6,.95,.25,D);b.box(-.55,.72,.65,-.15,1.12,.95,C);b.box(.15,.72,.65,.55,1.12,.95,C);b.box(-.45,.92,.02,-.15,1.0,.08,0x303858);   // dash, seats, wheel
  for(const s of[-1,1]){const x0=s>0?.935:-.945,x1=s>0?.945:-.935;
    b.box(x0,.34,-.1,x1,.72,-.08,D);b.box(x0,.34,1,x1,.72,1.02,D);b.box(x0,.34,-.1,x1,.355,1.02,D);b.box(x0,.58,.4,x1,.62,.6,0xcfd8ff);   // door seams + handle
    b.box(s>0?.9:-1.05,.95,.1,s>0?1.05:-.9,1.03,.3,P);                                                                                    // mirror
    b.box(s>0?.93:-1,.2,-1.2,s>0?1:-.93,.42,1.5,C);b.box(s>0?.84:-1.08,.64,-1.85,s>0?1.08:-.84,.78,-.85,P);b.box(s>0?.84:-1.08,.64,.9,s>0?1.08:-.84,.78,1.9,P);  // skirts, flares
    b.box(s*.58-.04,.85,1.95,s*.58+.04,1.2,2.05,D);b.box(s>0?.98:-1.02,1.1,1.75,s>0?1.02:-.98,1.35,2.35,P);                                  // wing supports + end plates
    b.box(s*.55-.1,.3,2.2,s*.55+.1,.42,2.38,0xcfd8ff);b.box(s*.55-.07,.33,2.37,s*.55+.07,.39,2.39,0x000000);                              // exhausts
    g.box(s*.82-.15,.5,-2.17,s*.82+.15,.56,-2.1,0xbff4ff);g.box(s*.7-.15,.58,-2.1,s*.7+.15,.6,-2.05,0xffffff);g.box(s>0?.8:-.9,.4,-2.1,s>0?.9:-.8,.46,-2,0xffa020);   // LED head, DRL, indicator
    for(let k=0;k<2;k++)tl.box(s*(.5+k*.22)-.09,.6,2.15,s*(.5+k*.22)+.09,.7,2.2,0xffffff);rv.box(s*.38-.05,.5,2.19,s*.38+.05,.56,2.22,0xffffff)}
  b.box(-1,1.2,1.78,1,1.26,2.3,C);b.box(-.9,1.26,1.9,.9,1.265,2,AC);b.box(-.8,.2,2.05,.8,.45,2.3,C);b.box(-.25,.5,2.2,.25,.62,2.22,0xf2f2ff);  // wing, diffuser, plate
  for(let k=0;k<5;k++)b.box(-.6+k*.3,.2,2.1,-.57+k*.3,.45,2.32,0x3a4270);                                                                   // diffuser fins
  tl.box(-.3,.62,2.15,.3,.66,2.2,0xffffff);g.box(-.9,.12,-2,.9,.16,2,0xff3fd0);                                                            // tail bar, underglow strip
  const root=new THREE.Group(),bodyG=new THREE.Group(),m=(bb,mt,ro)=>{const e=bb.mesh(mt,ro);e&&bodyG.add(e)};
  m(b,M.solid);m(g,M.glow);m(tl,mats.tail);m(rv,mats.rev);m(gs,mats.glass,3);root.add(bodyG);
  const w=[wheel(-1,-1.35),wheel(1,-1.35),wheel(-1,1.4),wheel(1,1.4)];w.forEach(x=>root.add(x.piv));
  if(real){const pb=new B();pb.flat(-3.2,-3.6,3.2,3.6,.05,0xff3fd0);pb.flat(-3.5,-24,3.5,-2.2,.05,0x2c4266);pb.flat(-2,2.4,2,6,.05,0x401018);root.add(pb.mesh(M.pool))}
  return{root,bodyG,w}}
const pl=buildPlayer(true),plM=buildPlayer(false),player=pl.root,playerM=plM.root;playerM.scale.y=-1;scene.add(player,playerM);
const shadow=new THREE.Mesh(new THREE.PlaneGeometry(3.4,6).rotateX(-Math.PI/2),new THREE.MeshBasicMaterial({map:poolTex,color:0,transparent:true,opacity:1,depthWrite:false}));
shadow.renderOrder=7;scene.add(shadow);
const SP={p:{p:0,v:0},r:{p:0,v:0},y:{p:0,v:0}};                       // suspension springs (pitch, roll, heave)
const spr=(s,t,dt)=>{s.v+=((t-s.p)*90-s.v*9)*dt;s.p+=s.v*dt;return s.p};
function pose(c,x,y,z,th,pit,rol){c.root.position.set(x,0,z);c.root.rotation.y=th;c.bodyG.position.y=y;c.bodyG.rotation.set(pit,0,rol);
  const sa=G.steer*.45;c.w.forEach((w,i)=>{if(i<2)w.piv.rotation.y=sa;w.spin.rotation.x=G.wa})}

/* ---------- particles: sparks + tyre smoke (one Points object, pooled) ---------- */
const NP=320,pg=new THREE.BufferGeometry(),pP=new Float32Array(NP*3),pC=new Float32Array(NP*3),pV=new Float32Array(NP*3),pB=new Float32Array(NP*3),pL=new Float32Array(NP),pM=new Float32Array(NP).fill(1),pG=new Float32Array(NP);let pIdx=0;
pg.setAttribute('position',new THREE.BufferAttribute(pP,3));pg.setAttribute('color',new THREE.BufferAttribute(pC,3));
const pts=new THREE.Points(pg,new THREE.PointsMaterial({size:1.1,map:poolTex,vertexColors:true,transparent:true,blending:THREE.AdditiveBlending,depthWrite:false}));pts.frustumCulled=false;scene.add(pts);
function emit(x,y,z,vx,vy,vz,r,g,b,life,grav){const i=pIdx++%NP;pP[i*3]=x;pP[i*3+1]=y;pP[i*3+2]=z;pV[i*3]=vx;pV[i*3+1]=vy;pV[i*3+2]=vz;pB[i*3]=r;pB[i*3+1]=g;pB[i*3+2]=b;pL[i]=pM[i]=life;pG[i]=grav}
function updParticles(dt){for(let i=0;i<NP;i++){const j=i*3;if(pL[i]<=0){pC[j]=pC[j+1]=pC[j+2]=0;continue}pL[i]-=dt;const f=Math.max(0,pL[i]/pM[i]);
  pV[j+1]-=pG[i]*dt;pP[j]+=pV[j]*dt;pP[j+1]=Math.max(.05,pP[j+1]+pV[j+1]*dt);pP[j+2]+=pV[j+2]*dt;pC[j]=pB[j]*f;pC[j+1]=pB[j+1]*f;pC[j+2]=pB[j+2]*f}
  pg.attributes.position.needsUpdate=pg.attributes.color.needsUpdate=true}
function sparks(o,s){const x=G.x-Math.sin(G.th)*o,z=G.z-Math.cos(G.th)*o;for(let i=0;i<Math.min(14,s);i++)emit(x,.5,z,rs(-6,6),rs(1,5),rs(-6,6),1,.7,.25,.5,12)}

const traffic=[];
for(let i=0;i<NT;i++){const g=buildCar([0x8a2be2,0x20c8ff,0xf2f2ff,0xff4a6a,0xffd23a][i%5],i%4==3),m=g.clone();m.scale.y=-1;scene.add(g,m);traffic.push({g,m,hit:0,nm:0})}
function syncT(t){t.x=t.ax=='z'?t.line:t.pos;t.z=t.ax=='z'?t.pos:t.line;t.vx=t.ax=='z'?0:t.dir*t.sp;t.vz=t.ax=='z'?t.dir*t.sp:0}
function respawn(t){t.ax=Math.random()<.5?'z':'x';t.dir=Math.random()<.5?1:-1;t.sp=rs(12,26);
  const i=Math.round(((t.ax=='z'?G.x:G.z)+rs(-250,250))/S);t.line=i*S+(t.ax=='z'?-t.dir:t.dir)*6;   // right-hand traffic lanes
  t.pos=(t.ax=='z'?G.z:G.x)+(Math.random()<.5?-1:1)*rs(90,340);t.hit=0;t.nm=0;
  t.th=t.ax=='z'?(t.dir>0?Math.PI:0):(t.dir>0?-Math.PI/2:Math.PI/2);syncT(t)}
function updTraffic(dt){for(const t of traffic){
  if(t.hit>0){t.hit-=dt;t.x+=t.hvx*dt;t.z+=t.hvz*dt;t.th+=t.spin*dt;if(t.hit<=0)respawn(t)}
  else{t.pos+=t.dir*t.sp*dt;syncT(t);t.nm-=dt;if(Math.hypot(t.x-G.x,t.z-G.z)>430)respawn(t)}
  t.g.position.set(t.x,0,t.z);t.g.rotation.y=t.th;t.m.position.set(t.x,0,t.z);t.m.rotation.y=t.th}}

/* ---------- audio (all synthesized, no files) ---------- */
const A={c:null,m:false,
  init(){if(this.c)return;const c=this.c=new(window.AudioContext||window.webkitAudioContext)();
    this.g=c.createGain();this.g.gain.value=this.m?0:1;this.g.connect(c.destination);
    const o=this.o=c.createOscillator(),o2=this.o2=c.createOscillator(),f=this.f=c.createBiquadFilter(),eg=this.eg=c.createGain();
    o.type='sawtooth';o2.type='square';f.type='lowpass';eg.gain.value=0;o.connect(f);o2.connect(f);f.connect(eg);eg.connect(this.g);o.start();o2.start();
    const nb=this.nb=c.createBuffer(1,c.sampleRate,c.sampleRate),d=nb.getChannelData(0);for(let i=0;i<d.length;i++)d[i]=Math.random()*2-1;
    const s=c.createBufferSource(),bp=c.createBiquadFilter(),sg=this.sg=c.createGain();s.buffer=nb;s.loop=true;bp.type='bandpass';bp.frequency.value=1900;sg.gain.value=0;
    s.connect(bp);bp.connect(sg);sg.connect(this.g);s.start()},
  engine(v,thr,slip,on){if(!this.c)return;const t=this.c.currentTime,mx=[14,26,38,50,62,90];let g=0;while(g<5&&v>mx[g])g++;
    const rpm=.3+.7*clamp((v-(g?mx[g-1]:0))/(mx[g]-(g?mx[g-1]:0)),0,1),fr=50+rpm*130;
    this.o.frequency.setTargetAtTime(fr,t,.05);this.o2.frequency.setTargetAtTime(fr*.5,t,.05);this.f.frequency.setTargetAtTime(400+rpm*1600,t,.05);
    this.eg.gain.setTargetAtTime(on?.05+.07*thr:0,t,.1);this.sg.gain.setTargetAtTime(on?clamp(slip-.15,0,1)*.14:0,t,.05)},
  hit(p){if(!this.c)return;const c=this.c,t=c.currentTime,s=c.createBufferSource(),g=c.createGain(),f=c.createBiquadFilter(),o=c.createOscillator();
    s.buffer=this.nb;f.type='lowpass';f.frequency.value=900;g.gain.setValueAtTime(.6*p,t);g.gain.exponentialRampToValueAtTime(.001,t+.45);
    s.connect(f);f.connect(g);g.connect(this.g);s.start(t);s.stop(t+.5);o.frequency.setValueAtTime(90,t);o.frequency.exponentialRampToValueAtTime(30,t+.3);
    o.connect(g);o.start(t);o.stop(t+.5)},
  blip(fr){if(!this.c)return;const c=this.c,t=c.currentTime,o=c.createOscillator(),g=c.createGain();o.type='square';o.frequency.value=fr;
    g.gain.setValueAtTime(.08,t);g.gain.exponentialRampToValueAtTime(.001,t+.15);o.connect(g);g.connect(this.g);o.start(t);o.stop(t+.16)},
  mute(){this.m=!this.m;if(this.g)this.g.gain.value=this.m?0:1;$('mbtn').textContent=this.m?'SOUND OFF':'SOUND ON'}};

/* ---------- game state & physics ---------- */
let best=0;try{best=+localStorage.getItem('na_best')||0}catch(e){}
const G={state:'menu',x:6,z:60,th:0,cth:0,vx:0,vz:0,yaw:0,steer:0,lives:3,score:0,dist:0,top:0,inv:0,shake:0,sc:0,pitch:0,slip:0,vf:0,af:0,wa:0,braking:0};
const K={},keymap={KeyW:'up',ArrowUp:'up',KeyS:'down',ArrowDown:'down',KeyA:'left',ArrowLeft:'left',KeyD:'right',ArrowRight:'right',Space:'space'};
const pad=n=>String(Math.floor(n)).padStart(6,'0');
function toast(t){const e=$('toast');e.textContent=t;e.classList.remove('on');void e.offsetWidth;e.classList.add('on')}
function show(){$('menu').hidden=G.state!=='menu';$('hud').hidden=G.state==='menu';$('pause').hidden=G.state!=='paused';$('over').hidden=G.state!=='over';window.TC&&TC.sync()}
function reset(){Object.assign(G,{x:6,z:60,th:0,cth:0,vx:0,vz:0,yaw:0,steer:0,lives:3,score:0,dist:0,top:0,inv:0,shake:0,sc:0,pitch:0,vf:0,af:0});traffic.forEach(respawn)}
function startGame(){A.init();A.blip(660);reset();G.state='playing';NA.emit('start');show()}
function restart(){A.init();A.blip(660);reset();G.state='playing';NA.emit('start');show()}
function togglePause(){if(G.state==='playing')G.state='paused';else if(G.state==='paused')G.state='playing';else return;A.blip(440);show()}
function gameOver(){G.state='over';if(G.score>best){best=G.score;try{localStorage.setItem('na_best',best)}catch(e){}}
  $('final').innerHTML=`Score ${pad(G.score)} · Distance ${(G.dist/1000).toFixed(2)} km<br>Top speed ${Math.round(G.top*3.6)} km/h · Best ${pad(best)}`;NA.emit('over');show()}
function crash(s){G.lives--;NA.emit('crash');G.inv=1.8;G.shake=Math.min(1,s/20);A.hit(Math.min(1,s/18));G.vx*=.5;G.vz*=.5;
  const f=$('flash');f.classList.add('on');setTimeout(()=>f.classList.remove('on'),60);if(G.lives<=0)gameOver()}

/* push the car out of an obstacle along normal n (pointing at the car); bounce, steer-kick, crash if hard */
function bump(nx,nz,depth,o,ovx,ovz){
  G.x+=nx*depth;G.z+=nz*depth;const vn=(G.vx-ovx)*nx+(G.vz-ovz)*nz;
  if(vn<0){G.vx-=1.2*vn*nx;G.vz-=1.2*vn*nz;G.vx*=.99;G.vz*=.99;G.yaw-=o*(nx*Math.cos(G.th)-nz*Math.sin(G.th))*-vn*.04;
    const s=-vn;if(s>2)sparks(o,s);if(s>9&&G.inv<=0)crash(s);else if(s>2&&G.sc<=0){A.hit(.25);G.sc=.2;G.shake=Math.max(G.shake,.15)}}
  return Math.max(0,-vn)}
function collide(){
  const pcx=Math.floor(G.x/S),pcz=Math.floor(G.z/S),near=[];
  for(let i=-1;i<=1;i++)for(let j=-1;j<=1;j++){const c=chunks.get((pcx+i)+','+(pcz+j));if(c)near.push(c)}
  for(const o of[-1.4,0,1.4]){
    for(const c of near){
      let px=G.x-Math.sin(G.th)*o,pz=G.z-Math.cos(G.th)*o,b=c.box,dx=px-clamp(px,b[0],b[2]),dz=pz-clamp(pz,b[1],b[3]),d=Math.hypot(dx,dz);
      if(d<1.05&&d>1e-4)bump(dx/d,dz/d,1.05-d,o,0,0);
      for(const q of c.circles){px=G.x-Math.sin(G.th)*o;pz=G.z-Math.cos(G.th)*o;dx=px-q.x;dz=pz-q.z;d=Math.hypot(dx,dz);
        if(d<1.05+q.r&&d>1e-4)bump(dx/d,dz/d,1.05+q.r-d,o,0,0)}}
    for(const t of traffic){if(t.hit>0)continue;
      for(const k of[-1.4,0,1.4]){const px=G.x-Math.sin(G.th)*o,pz=G.z-Math.cos(G.th)*o,tx=t.x-Math.sin(t.th)*k,tz=t.z-Math.cos(t.th)*k,
        dx=px-tx,dz=pz-tz,d=Math.hypot(dx,dz);
        if(d<2.1&&d>1e-4){const s=bump(dx/d,dz/d,2.1-d,o,t.vx,t.vz);t.hit=1.6;t.spin=rs(-4,4);
          t.hvx=t.vx-dx/d*Math.max(s,4)*.9+G.vx*.3;t.hvz=t.vz-dz/d*Math.max(s,4)*.9+G.vz*.3;if(s>9)toast('CRASH');break}}}}}

function step(dt){
  const live=G.state==='playing',k=live?K:{},thr=k.up?1:0,brk=k.down?1:0,st=clamp((k.left?1:0)-(k.right?1:0)+(live&&window.TC?TC.steer():0),-1.5,1.5);
  const fx=-Math.sin(G.th),fz=-Math.cos(G.th),rx=Math.cos(G.th),rz=-Math.sin(G.th);
  let vf=G.vx*fx+G.vz*fz,vl=G.vx*rx+G.vz*rz;
  if(thr){vf+=(vf<-1?45:21*Math.max(0,1-(vf/66)**2))*dt}
  if(brk){vf=vf>1?vf-42*dt:Math.max(-12,vf-14*dt)}
  if(!thr&&!brk)vf-=Math.sign(vf)*Math.min(Math.abs(vf),(2+vf*vf*.0006)*dt);
  if(k.space)vf-=Math.sign(vf)*Math.min(Math.abs(vf),9*dt);
  G.steer+=(st-G.steer)*Math.min(1,9*dt);
  const av=Math.abs(vf),sf=Math.min(1,av/8)/(1+(av/45)**2*1.2);
  G.th+=(G.steer*1.9*sf*(vf<0?-1:1)*(k.space?1.35:1)+G.yaw)*dt;G.yaw*=Math.exp(-3*dt);
  vl*=Math.exp(-(k.space?1.6:7.5)*dt);
  G.vx=fx*vf+rx*vl;G.vz=fz*vf+rz*vl;                       // recompose with OLD basis → natural drift
  G.x+=G.vx*dt;G.z+=G.vz*dt;
  const sp=Math.hypot(G.vx,G.vz);G.slip=Math.abs(vl)/(sp+1);G.top=Math.max(G.top,sp);G.inv-=dt;G.sc-=dt;
  if(live){collide();
    G.dist+=sp*dt;G.score+=sp*dt*.5;NA.emit('tick',dt);
    if(Math.abs(vl)>4&&sp>18)G.score+=Math.abs(vl)*dt*10;                         // drift bonus
    for(const t of traffic)if(!t.hit&&t.nm<=0&&sp>22&&Math.hypot(t.x-G.x,t.z-G.z)<4.6){t.nm=3;G.score+=100;NA.emit('nearmiss');toast('NEAR MISS +100')}}
  const yr=G.steer*1.9*sf*(vf<0?-1:1)*(k.space?1.35:1),af=(vf-G.vf)/Math.max(dt,.001);G.vf=vf;G.af+=(af-G.af)*Math.min(1,10*dt);
  G.braking=((brk&&vf>1)||(k.space&&vf>1))?1:0;G.wa-=vf/.36*dt;                      // wheel angle follows real speed
  const pit=spr(SP.p,clamp(G.af*.0012,-.07,.07),dt),rol=spr(SP.r,clamp(-yr*vf*.0016,-.12,.12),dt),
    hv=spr(SP.y,(Math.sin(G.dist*.9)*.5+Math.sin(G.dist*2.1+1)*.5)*.03*Math.min(1,sp/25)-G.af*.0006,dt);
  mats.tail.color.setHex(G.braking?0xff2040:0x7a1020);mats.rev.color.setHex(vf<-.5?0xffffff:0x111111);
  player.visible=playerM.visible=!(G.inv>0&&((G.inv*10|0)&1));
  pose(pl,G.x,hv,G.z,G.th,pit,rol);pose(plM,G.x,hv,G.z,G.th,pit,rol);shadow.position.set(G.x,.045,G.z);shadow.rotation.y=G.th;
  if(live&&((G.slip>.3&&sp>15)||(G.braking&&vf>25)||(k.space&&sp>15)))for(const q of[-1,1])
    emit(G.x-fx*1.4+rx*q*.93,.25,G.z-fz*1.4+rz*q*.93,rs(-1,1),rs(.5,1.5),rs(-1,1),.55,.6,.85,.9,0)}

/* ---------- camera: heading follow, steer shift + look-ahead, bank, accel/brake response, speed FOV, vibration, anti-clipping ---------- */
let T=0,mb=1;const CS={s:0,r:0,a:0};
function camUpdate(dt){
  const sp=Math.hypot(G.vx,G.vz),d=((G.th-G.cth+Math.PI)%PI2+PI2)%PI2-Math.PI,kd=1-Math.exp(-5*dt);
  G.cth+=d*(1-Math.exp(-(4+sp*.03)*dt));
  mb=G.state==='menu'?Math.min(1,mb+dt*2):Math.max(0,mb-dt*1.1);
  CS.s+=(G.steer*Math.min(1,sp/30)-CS.s)*kd;CS.r+=(CS.s*.06-CS.r)*kd;CS.a+=(clamp(G.af*.0016,-.12,.12)-CS.a)*kd;
  const fx=-Math.sin(G.cth),fz=-Math.cos(G.cth),rx=-fz,rz=fx,back=7.6+sp*.045+CS.a*14,sh=G.shake*.6,vib=Math.max(0,sp-45)/30*.012;
  let px=G.x-fx*back-rx*CS.s*1.4,py=3.1+sp*.008-CS.a*4+SP.y.p*.6+Math.sin(T*53)*vib,pz=G.z-fz*back-rz*CS.s*1.4,
      lx=G.x+fx*10+rx*CS.s*4.5,ly=1.2,lz=G.z+fz*10+rz*CS.s*4.5,fov=60+Math.min(sp*3.6,240)/240*22+CS.a*40,roll=CS.r*(1-mb);
  if(mb>0){                                              // title-screen camera: 3/4 view, car on the right
    const mx=G.x+6.5+Math.sin(T*.3)*1.5,mz=G.z-7.5,dx=G.x-mx,dz=G.z-mz,l=Math.hypot(dx,dz),tx=G.x-(-dz/l)*3.4,tz=G.z-(dx/l)*3.4;
    px+=(mx-px)*mb;py+=(2.2-py)*mb;pz+=(mz-pz)*mb;lx+=(tx-lx)*mb;ly+=(.9-ly)*mb;lz+=(tz-lz)*mb;fov+=(50-fov)*mb}
  for(const c of chunks.values()){const b=c.box;if(px>b[0]-.8&&px<b[2]+.8&&pz>b[1]-.8&&pz<b[3]+.8){   // never clip into buildings
    const o=[px-b[0]+.8,b[2]+.8-px,pz-b[1]+.8,b[3]+.8-pz],m=Math.min(o[0],o[1],o[2],o[3]);
    if(m===o[0])px=b[0]-.8;else if(m===o[1])px=b[2]+.8;else if(m===o[2])pz=b[1]-.8;else pz=b[3]+.8}}
  const cl=Math.hypot(lx-px,lz-pz)||1,cx=(lx-px)/cl,cz=(lz-pz)/cl,sr=Math.sin(roll);
  cam.up.set(cz*sr,Math.cos(roll),-cx*sr);                // bank toward the inside of the turn
  cam.position.set(px+(Math.random()-.5)*sh,py+(Math.random()-.5)*sh,pz+(Math.random()-.5)*sh);cam.lookAt(lx,ly,lz);
  cam.fov=fov;cam.updateProjectionMatrix();G.shake*=Math.exp(-4*dt);
  ground.position.set(G.x,0,G.z);roadTex.offset.set((G.x/35)%1,(-G.z/35)%1)}   // road texture stays fixed in the world

/* ---------- HUD ---------- */
const lifeEls=document.querySelectorAll('#lives u');
function hud(){$('speed').classList.toggle('brk',!!G.braking);const kmh=Math.hypot(G.vx,G.vz)*3.6;$('spd').textContent=Math.round(kmh);$('barf').style.width=Math.min(100,kmh/230*100)+'%';
  $('score').textContent=pad(G.score);$('best').textContent=pad(Math.max(best,G.score));lifeEls.forEach((e,i)=>e.classList.toggle('off',i>=G.lives))}

/* ---------- input & UI wiring ---------- */
addEventListener('keydown',e=>{if(keymap[e.code]){K[keymap[e.code]]=1;e.preventDefault()}if(e.repeat)return;
  if(e.code==='Escape'||e.code==='KeyP')togglePause();
  else if(e.code==='KeyR'&&G.state!=='menu')restart();
  else if(e.code==='KeyM')A.mute();
  else if((e.code==='Enter'||e.code==='Space')&&G.state==='menu')startGame();
  else if(e.code==='Enter'&&G.state==='over')restart()});
addEventListener('keyup',e=>{if(keymap[e.code])K[keymap[e.code]]=0});
addEventListener('blur',()=>{for(const k in K)K[k]=0;togglePauseIfPlaying()});
document.addEventListener('visibilitychange',()=>{if(document.hidden)togglePauseIfPlaying()});
function togglePauseIfPlaying(){if(G.state==='playing')togglePause()}
$('start').onclick=startGame;$('resume').onclick=togglePause;$('restart1').onclick=restart;$('restart2').onclick=restart;
$('pbtn').onclick=togglePause;$('mbtn').onclick=()=>{A.init();A.mute()};

/* ---------- main loop ---------- */
traffic.forEach(respawn);updateChunks(true);show();
let last=performance.now();
function loop(now){requestAnimationFrame(loop);const dt=Math.min(.033,(now-last)/1000);last=now;
  if(G.state!=='paused'){T+=dt;if(G.state!=='menu')step(dt);else{player.position.set(G.x,0,G.z);playerM.position.set(G.x,0,G.z)}
    updTraffic(dt);updParticles(dt);updateChunks(false)}
  A.engine(Math.hypot(G.vx,G.vz),K.up&&G.state==='playing'?1:0,G.slip,G.state==='playing');
  camUpdate(G.state==='paused'?0:dt);hud();speedLines();renderer.render(scene,cam)}
function speedLines(){const w=fxc.width,h=fxc.height,kmh=Math.hypot(G.vx,G.vz)*3.6;fxg.clearRect(0,0,w,h);if(kmh<110||G.state!=='playing')return;
  const a=Math.min(.45,(kmh-110)/220),R=Math.hypot(w,h)/2;fxg.strokeStyle=`rgba(170,200,255,${a})`;fxg.lineWidth=1.5;fxg.beginPath();   // edge-only streaks
  for(let i=0;i<26;i++){const an=i*2.39996,ph=(i*.618+T*(1.5+kmh/150))%1,r0=R*(.62+.35*ph),r1=r0+R*.1*(.4+ph);
    fxg.moveTo(w/2+Math.cos(an)*r0,h*.46+Math.sin(an)*r0);fxg.lineTo(w/2+Math.cos(an)*r1,h*.46+Math.sin(an)*r1)}fxg.stroke()}
requestAnimationFrame(loop);
