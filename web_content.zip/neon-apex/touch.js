'use strict';
/* NEON APEX — mobile controls, controls editor, landscape/fullscreen helpers.
   Loaded after script.js; uses its globals: K (input), G (state), $, clamp, resize, togglePause. */
(()=>{
const KEY='na_controls_v1',clone=o=>JSON.parse(JSON.stringify(o));
const DEF={mode:'buttons',sens:1,dead:.12,c:{            // x,y = centre as fraction of safe area; s = size as fraction of the short screen side; o = opacity
  left:{x:.09,y:.80,s:.26,o:.8},right:{x:.26,y:.80,s:.26,o:.8},joy:{x:.15,y:.70,s:.44,o:.8},
  gas:{x:.91,y:.72,s:.30,o:.85},brake:{x:.76,y:.82,s:.24,o:.8},drift:{x:.88,y:.36,s:.17,o:.75}}};
const KEYS={gas:'up',brake:'down',drift:'space'},NAMES={left:'STEER LEFT',right:'STEER RIGHT',joy:'JOYSTICK',gas:'ACCELERATE',brake:'BRAKE',drift:'DRIFT'};
const ICON={left:'<svg viewBox="0 0 24 24"><path d="M15 4 7 12l8 8"/></svg>',right:'<svg viewBox="0 0 24 24"><path d="M9 4l8 8-8 8"/></svg>'},LABEL={gas:'GAS',brake:'BRAKE',drift:'DRIFT'};
const num=(v,a,b,d)=>v!=null&&isFinite(v)?clamp(+v,a,b):d;
function sanitize(j){const d=clone(DEF);if(!j||typeof j!=='object')return d;
  d.mode=j.mode==='joystick'?'joystick':'buttons';d.sens=num(j.sens,.5,1.5,d.sens);d.dead=num(j.dead,0,.4,d.dead);
  for(const id in d.c){const s=(j.c||{})[id]||{},c=d.c[id];c.x=num(s.x,0,1,c.x);c.y=num(s.y,0,1,c.y);c.s=num(s.s,.12,.5,c.s);c.o=num(s.o,.2,1,c.o)}return d}
let cfg;try{cfg=sanitize(JSON.parse(localStorage.getItem(KEY)))}catch(e){cfg=clone(DEF)}
const store=()=>{try{localStorage.setItem(KEY,JSON.stringify(cfg))}catch(e){}};

let cur=cfg,draft=null,editing=false,sel='gas',drag=null,joyId=null,jx=0;
let touch=matchMedia('(pointer:coarse)').matches||/[?&]touch=1/.test(location.search);
const layer=$('tcl'),els={},held={left:new Set(),right:new Set(),gas:new Set(),brake:new Set(),drift:new Set()};

/* ---------- build controls ---------- */
for(const id in NAMES){const e=document.createElement('div');e.className='tc tc-'+id;
  e.innerHTML=ICON[id]||(id==='joy'?'<i></i>':`<span>${LABEL[id]}</span>`);layer.appendChild(e);els[id]=e;bind(e,id)}
layer.addEventListener('contextmenu',e=>e.preventDefault());

function bind(e,id){
  e.addEventListener('pointerdown',ev=>{ev.preventDefault();
    if(editing){const r=e.getBoundingClientRect();drag={id,pid:ev.pointerId,ox:ev.clientX-(r.left+r.width/2),oy:ev.clientY-(r.top+r.height/2)};
      sel=id;try{e.setPointerCapture(ev.pointerId)}catch(_){}ui();return}
    if(G.state!=='playing')return;
    try{e.setPointerCapture(ev.pointerId)}catch(_){}
    e.classList.add('dn');
    if(id==='joy'){joyId=ev.pointerId;joyMove(ev)}else{held[id].add(ev.pointerId);if(KEYS[id])K[KEYS[id]]=1}});
  e.addEventListener('pointermove',ev=>{
    if(editing){if(drag&&drag.id===id&&drag.pid===ev.pointerId)dragTo(ev);return}
    if(id==='joy')joyMove(ev)});
  const end=ev=>{
    if(editing){if(drag&&drag.pid===ev.pointerId)drag=null;return}
    if(id==='joy'){if(ev.pointerId===joyId)joyEnd()}
    else if(held[id].delete(ev.pointerId)&&!held[id].size){e.classList.remove('dn');if(KEYS[id])K[KEYS[id]]=0}};
  for(const t of['pointerup','pointercancel','lostpointercapture'])e.addEventListener(t,end)}

/* ---------- virtual joystick (steering axis only) ---------- */
function joyMove(ev){if(ev.pointerId!==joyId)return;
  const e=els.joy,r=e.getBoundingClientRect(),R=r.width/2;
  let vx=(ev.clientX-r.left-R)/(R*.8),vy=(ev.clientY-r.top-R)/(R*.8);const l=Math.hypot(vx,vy);if(l>1){vx/=l;vy/=l}
  e.firstChild.style.transform=`translate(${vx*R*.5}px,${vy*R*.5}px)`;
  const a=Math.abs(vx),d=cur.dead;jx=a<d?0:Math.sign(vx)*(a-d)/(1-d)}
function joyEnd(){joyId=null;jx=0;els.joy.classList.remove('dn');els.joy.firstChild.style.transform=''}

/* steering value for the game: +1 = left, -1 = right (same convention as the keyboard) */
function steer(){const v=cur.mode==='joystick'?-jx:(held.left.size?1:0)-(held.right.size?1:0);return v*cur.sens}
function release(){for(const id in KEYS)if(held[id].size){held[id].clear();K[KEYS[id]]=0}
  held.left.clear();held.right.clear();joyEnd();for(const id in els)els[id].classList.remove('dn')}

/* ---------- responsive layout (safe-area aware, resolution independent) ---------- */
const probe=document.createElement('div');
probe.style.cssText='position:fixed;left:0;top:0;width:0;height:0;visibility:hidden;pointer-events:none;padding:env(safe-area-inset-top,0px) env(safe-area-inset-right,0px) env(safe-area-inset-bottom,0px) env(safe-area-inset-left,0px)';
document.body.appendChild(probe);
function safe(){const s=getComputedStyle(probe),t=parseFloat(s.paddingTop)||0,r=parseFloat(s.paddingRight)||0,b=parseFloat(s.paddingBottom)||0,l=parseFloat(s.paddingLeft)||0;
  return{l,t,w:Math.max(1,innerWidth-l-r),h:Math.max(1,innerHeight-t-b)}}
const vis=id=>id==='joy'?cur.mode==='joystick':cur.mode==='buttons'||!(id==='left'||id==='right');
function layout(){const sa=safe(),m=Math.min(innerWidth,innerHeight);
  for(const id in els){const e=els[id],c=cur.c[id],on=vis(id);e.hidden=!on;if(!on)continue;
    const px=Math.round(c.s*m),hw=px/2,x=sa.l+clamp(c.x*sa.w,hw,sa.w-hw),y=sa.t+clamp(c.y*sa.h,hw,sa.h-hw),st=e.style;
    st.width=st.height=px+'px';st.left=Math.round(x-hw)+'px';st.top=Math.round(y-hw)+'px';st.opacity=c.o;st.fontSize=Math.max(9,px*.17)+'px';
    e.classList.toggle('pick',editing&&id===sel)}}
function dragTo(ev){const sa=safe(),c=cur.c[drag.id],hw=c.s*Math.min(innerWidth,innerHeight)/2;
  c.x=(clamp(ev.clientX-drag.ox,sa.l+hw,sa.l+sa.w-hw)-sa.l)/sa.w;c.y=(clamp(ev.clientY-drag.oy,sa.t+hw,sa.t+sa.h-hw)-sa.t)/sa.h;layout()}
function sync(){layer.classList.toggle('on',editing||(touch&&G.state!=='menu'));layer.classList.toggle('edit',editing);
  if(G.state!=='playing')release();layout()}

/* ---------- controls & HUD editor ---------- */
function ui(){const c=cur.c[sel];$('cname').textContent=NAMES[sel];
  $('csize').value=Math.round(c.s*100);$('calpha').value=Math.round(c.o*100);$('csens').value=Math.round(cur.sens*100);$('cdead').value=Math.round(cur.dead*100);
  $('csizev').textContent=$('csize').value+'%';$('calphav').textContent=$('calpha').value+'%';$('csensv').textContent=$('csens').value+'%';$('cdeadv').textContent=$('cdead').value+'%';
  document.querySelectorAll('#cmode button').forEach(b=>b.classList.toggle('on',b.dataset.m===cur.mode));
  $('cdeadrow').hidden=cur.mode!=='joystick';layout()}
function fixSel(){if(!vis(sel))sel=cur.mode==='joystick'?'joy':'left'}
function openEd(){draft=clone(cfg);cur=draft;editing=true;drag=null;release();fixSel();$('cfg').hidden=false;sync();ui()}
function closeEd(save){if(save){cfg=draft;store()}cur=cfg;draft=null;editing=false;drag=null;$('cfg').hidden=true;sync()}
$('csize').oninput=e=>{cur.c[sel].s=e.target.value/100;ui()};
$('calpha').oninput=e=>{cur.c[sel].o=e.target.value/100;ui()};
$('csens').oninput=e=>{cur.sens=e.target.value/100;ui()};
$('cdead').oninput=e=>{cur.dead=e.target.value/100;ui()};
document.querySelectorAll('#cmode button').forEach(b=>b.onclick=()=>{cur.mode=b.dataset.m;fixSel();ui()});
$('csave').onclick=()=>closeEd(true);$('ccancel').onclick=()=>closeEd(false);
$('creset').onclick=()=>{cur=draft=clone(DEF);fixSel();ui()};
$('ctlbtn').onclick=$('ctlp').onclick=openEd;
addEventListener('keydown',e=>{if(editing){e.stopImmediatePropagation();if(e.code==='Escape')closeEd(false)}},true);   // keep game hotkeys out of the editor

/* ---------- landscape, rotate message, fullscreen ---------- */
function orient(){if(touch&&innerHeight>innerWidth&&G.state==='playing')togglePause()}      // auto-pause behind the rotate message
function setTouch(v){touch=v;document.body.classList.toggle('touch',v);sync();orient()}
const de=document.documentElement,fsOK=!!(de.requestFullscreen||de.webkitRequestFullscreen),isFs=()=>!!(document.fullscreenElement||document.webkitFullscreenElement);
const goFull=()=>{if(!fsOK||isFs())return Promise.resolve();return Promise.resolve((de.requestFullscreen||de.webkitRequestFullscreen).call(de)).catch(()=>{})};
const lockLand=()=>{try{const o=screen.orientation;if(o&&o.lock)o.lock('landscape').catch(()=>{})}catch(e){}};   // Chrome allows this only in fullscreen / installed PWA
const toggleFs=()=>isFs()?(document.exitFullscreen||document.webkitExitFullscreen).call(document):goFull().then(lockLand);
function fsLabel(){$('fsbtn').textContent=isFs()?'EXIT':'FULL';$('fsmenu').textContent=isFs()?'EXIT FULLSCREEN':'FULLSCREEN';setTimeout(()=>{resize();layout()},100)}
$('fsbtn').hidden=$('fsmenu').hidden=!fsOK;$('fsbtn').onclick=$('fsmenu').onclick=toggleFs;
for(const ev of['fullscreenchange','webkitfullscreenchange'])document.addEventListener(ev,fsLabel);
$('start').addEventListener('click',()=>{if(touch)goFull().then(lockLand)});          // needs a user gesture
addEventListener('resize',()=>{layout();orient()});
addEventListener('orientationchange',()=>setTimeout(()=>{resize();layout();orient()},250));
addEventListener('blur',release);document.addEventListener('visibilitychange',()=>{if(document.hidden)release()});
addEventListener('touchstart',()=>{if(!touch)setTouch(true)},{once:true,passive:true});     // WebViews that misreport pointer:coarse

window.TC={steer,sync};
document.body.classList.toggle('touch',touch);sync();orient();
})();
