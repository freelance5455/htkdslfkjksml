# NEON APEX — handoff

## Status: Checkpoint 2 — A+B plus standalone credits.js (DEVELOPERS panel, Instagram links; edit DEVS list). Tests: progress 34/34, credits 18/18 (headless, THREE stubbed). Earlier: Checkpoint 1 — A (XP/levels) + B (records/stats) DONE and tested (34/34 headless checks, THREE stubbed)
- Backup of untouched originals: `../neon-apex-BACKUP-original/` (outside the working dir, never loaded by the game).
- Working copy: `neon-apex/`. Modified originals: script.js (NA event bus + 6 one-line hooks), index.html (level HUD, #lvup, #recs, progress.js tag), style.css (appended block). touch.js untouched. New: progress.js, credits.js (loaded after progress.js; adds DEVELOPERS button to menu + pause; index.html only gained its script tag).
- Static checks: `node --check` passes on script.js and touch.js.
- Tested in Chromium with a Proxy stub for THREE (logic/UI/storage only). NOT tested: real 3D rendering, real touch devices, audio. Test script: /home/claude/test/run_tests.py (not shipped).
- Hooks: `NA.on/emit` events start|tick|nearmiss|crash|over. Storage: `na_prog_v1`, `na_settings_v1` ({progress:bool}; ghost etc. to be added by later modules, merge don't overwrite).

## Architecture (verified by reading the code)
- index.html loads: three.js r128 (CDN, fallback `assets/vendor/three.min.js` — **file missing**), then script.js, then touch.js.
- script.js (global scope, 'use strict'): state `G` (state: menu|playing|paused|over; x,z,th,vx,vz,lives,score,dist,top,inv...), input `K`, `A` audio, `traffic`, `chunks`, `step(dt)`, `collide()`, `crash(s)`, `bump()`, `gameOver()`, `reset()`, `startGame()`, `restart()`, `togglePause()`, `show()`, `hud()`, `toast()`, `loop()`.
- touch.js (IIFE): exposes `window.TC={steer,sync}`; storage key `na_controls_v1`. Existing key `na_best`.
- Existing events: crash (lives--), near miss (+100 in step), game over, pause/resume, start/restart. No crash counter other than lives; no time/checkpoint concept.
- Car: procedural `buildPlayer()` (body color 0xffc21a, wing, wheels, underglow strip 0xff3fd0); materials shared via `M.solid`/`mats`.

## Risks
1. three.js fallback path missing → black screen if CDN blocked.
2. Everything is global/non-module; new modules must load between script.js and touch.js or after, and hook via wrappers, not rewrites.
3. `show()` is the single UI-state switch; new menus must integrate with it and with `G.state` so keys/touch don't leak.
4. Spacebar/Enter on menu starts the game — new overlays must stop propagation.

## Plan (dependency order)
- [ ] 0 Restore/verify original (needs three.js file or CDN)
- [x] A XP/levels  [x] B records  [ ] C missions  [ ] D achievements
- [ ] E progress UI  [ ] F garage  [ ] G modes  [ ] H orbs/checkpoints/multipliers  [ ] I ghost
- [ ] Final regression + delivery

## Next exact task
C daily missions in a new `missions.js` (listen to NA events; key `na_missions_v1`, date-seeded by local YYYY-MM-DD, 4 missions; reward XP via `NAProg` — add a public `NAProg.award(n)` that respects the enabled flag), then D achievements. Still blocked for real rendering tests: `assets/vendor/three.min.js` missing.
