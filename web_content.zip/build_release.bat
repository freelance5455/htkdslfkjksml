@echo off
setlocal
cd /d "%~dp0"
if not exist "gradlew.bat" (
  echo Gradle wrapper not found.
  echo Open this folder in Android Studio and let it sync, then run Build > Generate App Bundles or APKs > Generate APKs.
  exit /b 1
)
call gradlew.bat :app:assembleRelease
if errorlevel 1 exit /b %errorlevel%
echo.
echo Signed APK created at:
echo app\build\outputs\apk\release\app-release.apk
