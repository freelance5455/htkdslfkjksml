# ANJO DA GUARDA — ESTADO DO PROJETO

## REGRA PRINCIPAL
Continuar o projeto existente.
Não recriar funcionalidades.
Não remover funcionalidades existentes.
Não alterar o logo atual.
Código atual é a fonte de verdade.
Mobile-first.
Não inventar dados.

## STACK ATUAL
HTML/CSS/JavaScript.
Ambiente DEV.
localStorage como persistência atual.
Mídias locais/simuladas.
Pagamentos simulados.
Sem backend real ainda.

## ETAPA 1 — PROFISSIONAL
CONCLUÍDA E TESTADA.

Implementado:
- cadastro profissional
- selfie oficial
- categorias no cadastro
- documentos e status
- reenvio de documentos
- aprovação/rejeição
- suspensão/reativação
- perfil
- cartão digital
- visualização pelo anfitrião
- privacidade de documentos
- ocorrências
- auditoria
- testes de regressão

Pendências conhecidas:
- QR Code ainda é placeholder
- documentos não são obrigatórios no DEV

## ETAPA 2 — IMÓVEL
CONCLUÍDA E TESTADA.

Implementado:
- cadastro completo do imóvel (endereço, CEP, tipo, bairro/cidade/estado, quartos, banheiros, camas, capacidade, metragem opcional, acesso, condomínio, observações)
- ambientes individuais (roomsService.js) com fotos e vídeo
- inventário vinculado ao imóvel (inventoryService.js), 7 estados: NOVO/BOM/REGULAR/DANIFICADO/NAO_FUNCIONA/NAO_TESTADO/NAO_APLICAVEL
- checklist reutilizável (checklistService.js), gerado dinamicamente de ambientes+inventário, executado por serviço na pré-vistoria (execucao.html)
- Termo de Intermediação e Responsabilidades (legal.js) com aceite versionado (termsService.js: usuário, nome, CPF, data/hora, versão)
- snapshot do imóvel estendido em cada serviço publicado (inclui CEP/tipo/metragem/acesso/condomínio + resumo de ambientes/inventário)
- auditoria de criação/edição de imóvel, ambientes, inventário, checklist e aceite do termo
- testes de regressão das Etapas 1-3 (pagamento, deslocamento/chegada, chat, disputas) sem quebras

Pendências conhecidas:
- mídias de ambientes/inventário em base64/localStorage (sem storage externo, por decisão de escopo DEV)

## ETAPA 3 — PRÉ-VISTORIA
Depois da Etapa 2:
- chegada do profissional
- pré-vistoria obrigatória
- vídeo obrigatório
- checklist comparativo
- fotos/evidências
- GPS
- data/hora
- registro de divergências
- bloquear "Iniciar serviço" até concluir pré-vistoria

## ETAPA 4 — EXECUÇÃO
Depois da Etapa 3:
- iniciar serviço
- acompanhamento
- pós-vistoria
- evidências antes/depois
- conclusão
- divergências
- severidade
- bloqueios configuráveis
- auditoria

## ETAPA 5 — FINANCEIRO
Depois da Etapa 4:
- comissão da plataforma por categoria
- faxina
- pequenos reparos
- roupa de cama/enxoval
- percentual e/ou valor fixo
- histórico de alterações
- comissão congelada no serviço aceito
- separação:
  valor do anfitrião
  valor do profissional
  comissão da plataforma

## ETAPA 6 — AUDITORIA E REGRESSÃO
- testes completos
- permissões
- privacidade
- auditoria
- estados
- correções
- preparação para backend

## REGRAS DE NEGÓCIO
- Profissional não é funcionário/colaborador.
- Anfitrião deve fornecer informações verdadeiras.
- Alterações importantes devem ser registradas.
- Chat da plataforma é canal oficial.
- Não expor certidão criminal ao anfitrião.
- RG somente quando operacionalmente necessário.
- Evidências devem ficar vinculadas ao serviço.
- Dados importantes devem possuir histórico/auditoria.
- Contratos/serviços aceitos devem congelar seus dados relevantes.

## FERRAMENTAS DEV
- Painel Admin > "Limpar dados de teste" (js/services/devToolsService.js): exclui definitivamente users/properties/property_rooms/property_inventory/property_checklist_runs/providers/service_requests/interests/availability/chat_messages/contact_violations/reviews/payments/evidences/occurrences/disputes/notifications/term_acceptances/audit_logs + seus contadores _seq_*, e a sessão ativa.
- Preserva a(s) conta(s) com tipo_usuario 'administrador' na tabela users.
- Não apaga service_categories (catálogo fixo, se auto-restaura via seed).
- Bloqueada por APP_CONFIG.ENV !== 'prod' (lança exceção e some da UI em prod).
- Exige dupla confirmação (confirm + digitar "EXCLUIR") e avisa que é irreversível.
- Registra a própria limpeza em audit_logs (acao: 'limpeza_dados_teste').

## CORREÇÕES — ESTOURO DE COTA DO LOCALSTORAGE (mídia em base64)
Causa raiz identificada: fotos/vídeos convertidos para base64 sem compressão podiam
estourar a cota do localStorage do navegador (poucos MB), gerando erro genérico
("QuotaExceededError") em pontos que pareciam travados sem explicação.

- js/db.js: `_salvar` agora detecta erro de cota entre navegadores e lança mensagem
  clara em pt-BR ("Armazenamento local cheio... tente um vídeo mais curto ou uma
  foto de menor resolução") em vez do erro nativo do browser.
- js/config.js: novo `APP_CONFIG.LIMITES_ARQUIVO` (VIDEO_MAX_MB: 8, DOCUMENTO_MAX_MB: 5,
  FOTO_MAX_DIMENSAO_PX: 1280, FOTO_QUALIDADE: 0.72).
- js/utils.js: novas funções `comprimirImagem(file)` (redimensiona/compacta fotos via
  canvas para JPEG antes de virar base64; PDFs passam direto) e
  `validarTamanhoArquivo(file, maxMB)` (checagem de tamanho antes de ler o arquivo).
- js/pages/cadastro.js: selfie e documentos-foto do profissional agora passam por
  `comprimirImagem`; documentos em PDF são validados por tamanho (`DOCUMENTO_MAX_MB`)
  antes de serem lidos. Corrige: erro ao concluir cadastro do profissional mesmo com
  o perfil sendo criado (pendente de aprovação) sem redirecionar para a tela inicial.
- js/auth.js (`Auth.signUp`): criação de provider, envio de cada documento, criação de
  sessão e registro de auditoria agora são etapas isoladas (try/catch) — falha em
  qualquer uma delas (ex.: estouro de cota numa mídia) NUNCA mais bloqueia a conclusão
  do cadastro do usuário/profissional (documentos não são obrigatórios em DEV). Em
  caso de falha pontual, `usuario._avisos` traz uma mensagem orientando reenvio depois
  pelo perfil; o cadastro sempre conclui e redireciona.
- js/pages/execucao.js: vídeo da vistoria de entrada e de saída agora valida tamanho
  (`VIDEO_MAX_MB`) antes de tentar ler/salvar, evitando o comportamento de "clicar em
  concluir e não avançar" quando o vídeo era grande demais para a cota do navegador.
- js/pages/admin.js: cada documento pendente de aprovação agora tem link "Ver foto"/
  "Ver PDF" (abre o arquivo base64 em nova aba), reaproveitando o padrão já usado em
  documentos-profissional.html — permite ao administrador visualizar o documento
  enviado (imagem ou PDF) antes de aprovar/rejeitar.

Testado via harness Node (`vm` + localStorage simulado, inclusive com cota
artificialmente pequena para forçar estouro): cadastro do profissional conclui e
redireciona normalmente tanto no caminho feliz quanto sob estouro de cota (com aviso).
`node --check` OK em todos os arquivos JS alterados.

## FUTURO
- Backend
- PostgreSQL
- autenticação segura
- storage externo
- pagamentos reais
- notificações
- WebSocket
- QR Code real
- documentos obrigatórios em produção