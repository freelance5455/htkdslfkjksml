// قاعدة بيانات الجدول الدوري: العناصر الـ118
const all = [[1,"H","الهيدروجين","1.008","غاز","nonmetal",1,1,"العنصر الهيدروجين (H)، العدد الذري 1. من عناصر الجدول الدوري.","—"],[2,"He","الهيليوم","4.0026","غاز","noble",18,1,"العنصر الهيليوم (He)، العدد الذري 2. من عناصر الجدول الدوري.","—"],[3,"Li","الليثيوم","6.94","صلب","alkali",1,2,"العنصر الليثيوم (Li)، العدد الذري 3. من عناصر الجدول الدوري.","—"],[4,"Be","البيريليوم","9.0122","صلب","alkaline",2,2,"العنصر البيريليوم (Be)، العدد الذري 4. من عناصر الجدول الدوري.","—"],[5,"B","البورون","10.81","صلب","metalloid",13,2,"العنصر البورون (B)، العدد الذري 5. من عناصر الجدول الدوري.","—"],[6,"C","الكربون","12.011","صلب","nonmetal",14,2,"العنصر الكربون (C)، العدد الذري 6. من عناصر الجدول الدوري.","—"],[7,"N","النيتروجين","14.007","غاز","nonmetal",15,2,"العنصر النيتروجين (N)، العدد الذري 7. من عناصر الجدول الدوري.","—"],[8,"O","الأكسجين","15.999","غاز","nonmetal",16,2,"العنصر الأكسجين (O)، العدد الذري 8. من عناصر الجدول الدوري.","—"],[9,"F","الفلور","18.998","غاز","halogen",17,2,"العنصر الفلور (F)، العدد الذري 9. من عناصر الجدول الدوري.","—"],[10,"Ne","النيون","20.180","غاز","noble",18,2,"العنصر النيون (Ne)، العدد الذري 10. من عناصر الجدول الدوري.","—"],[11,"Na","الصوديوم","22.990","صلب","alkali",1,3,"العنصر الصوديوم (Na)، العدد الذري 11. من عناصر الجدول الدوري.","—"],[12,"Mg","المغنيسيوم","24.305","صلب","alkaline",2,3,"العنصر المغنيسيوم (Mg)، العدد الذري 12. من عناصر الجدول الدوري.","—"],[13,"Al","الألومنيوم","26.982","صلب","post",13,3,"العنصر الألومنيوم (Al)، العدد الذري 13. من عناصر الجدول الدوري.","—"],[14,"Si","السيليكون","28.085","صلب","metalloid",14,3,"العنصر السيليكون (Si)، العدد الذري 14. من عناصر الجدول الدوري.","—"],[15,"P","الفوسفور","30.974","صلب","nonmetal",15,3,"العنصر الفوسفور (P)، العدد الذري 15. من عناصر الجدول الدوري.","—"],[16,"S","الكبريت","32.06","صلب","nonmetal",16,3,"العنصر الكبريت (S)، العدد الذري 16. من عناصر الجدول الدوري.","—"],[17,"Cl","الكلور","35.45","غاز","halogen",17,3,"العنصر الكلور (Cl)، العدد الذري 17. من عناصر الجدول الدوري.","—"],[18,"Ar","الأرجون","39.948","غاز","noble",18,3,"العنصر الأرجون (Ar)، العدد الذري 18. من عناصر الجدول الدوري.","—"],[19,"K","البوتاسيوم","39.098","صلب","alkali",1,4,"العنصر البوتاسيوم (K)، العدد الذري 19. من عناصر الجدول الدوري.","—"],[20,"Ca","الكالسيوم","40.078","صلب","alkaline",2,4,"العنصر الكالسيوم (Ca)، العدد الذري 20. من عناصر الجدول الدوري.","—"],[21,"Sc","السكانديوم","44.956","صلب","transition",3,4,"العنصر السكانديوم (Sc)، العدد الذري 21. من عناصر الجدول الدوري.","—"],[22,"Ti","التيتانيوم","47.867","صلب","transition",4,4,"العنصر التيتانيوم (Ti)، العدد الذري 22. من عناصر الجدول الدوري.","—"],[23,"V","الفاناديوم","50.942","صلب","transition",5,4,"العنصر الفاناديوم (V)، العدد الذري 23. من عناصر الجدول الدوري.","—"],[24,"Cr","الكروم","51.996","صلب","transition",6,4,"العنصر الكروم (Cr)، العدد الذري 24. من عناصر الجدول الدوري.","—"],[25,"Mn","المنغنيز","54.938","صلب","transition",7,4,"العنصر المنغنيز (Mn)، العدد الذري 25. من عناصر الجدول الدوري.","—"],[26,"Fe","الحديد","55.845","صلب","transition",8,4,"العنصر الحديد (Fe)، العدد الذري 26. من عناصر الجدول الدوري.","—"],[27,"Co","الكوبالت","58.933","صلب","transition",9,4,"العنصر الكوبالت (Co)، العدد الذري 27. من عناصر الجدول الدوري.","—"],[28,"Ni","النيكل","58.693","صلب","transition",10,4,"العنصر النيكل (Ni)، العدد الذري 28. من عناصر الجدول الدوري.","—"],[29,"Cu","النحاس","63.546","صلب","transition",11,4,"العنصر النحاس (Cu)، العدد الذري 29. من عناصر الجدول الدوري.","—"],[30,"Zn","الزنك","65.38","صلب","transition",12,4,"العنصر الزنك (Zn)، العدد الذري 30. من عناصر الجدول الدوري.","—"],[31,"Ga","الغاليوم","69.723","صلب","post",13,4,"العنصر الغاليوم (Ga)، العدد الذري 31. من عناصر الجدول الدوري.","—"],[32,"Ge","الجرمانيوم","72.630","صلب","metalloid",14,4,"العنصر الجرمانيوم (Ge)، العدد الذري 32. من عناصر الجدول الدوري.","—"],[33,"As","الزرنيخ","74.922","صلب","metalloid",15,4,"العنصر الزرنيخ (As)، العدد الذري 33. من عناصر الجدول الدوري.","—"],[34,"Se","السيلينيوم","78.971","صلب","nonmetal",16,4,"العنصر السيلينيوم (Se)، العدد الذري 34. من عناصر الجدول الدوري.","—"],[35,"Br","البروم","79.904","سائل","halogen",17,4,"العنصر البروم (Br)، العدد الذري 35. من عناصر الجدول الدوري.","—"],[36,"Kr","الكريبتون","83.798","غاز","noble",18,4,"العنصر الكريبتون (Kr)، العدد الذري 36. من عناصر الجدول الدوري.","—"],[37,"Rb","الروبيديوم","85.468","صلب","alkali",1,5,"العنصر الروبيديوم (Rb)، العدد الذري 37. من عناصر الجدول الدوري.","—"],[38,"Sr","السترونشيوم","87.62","صلب","alkaline",2,5,"العنصر السترونشيوم (Sr)، العدد الذري 38. من عناصر الجدول الدوري.","—"],[39,"Y","الإيتريوم","88.906","صلب","transition",3,5,"العنصر الإيتريوم (Y)، العدد الذري 39. من عناصر الجدول الدوري.","—"],[40,"Zr","الزركونيوم","91.224","صلب","transition",4,5,"العنصر الزركونيوم (Zr)، العدد الذري 40. من عناصر الجدول الدوري.","—"],[41,"Nb","النيوبيوم","92.906","صلب","transition",5,5,"العنصر النيوبيوم (Nb)، العدد الذري 41. من عناصر الجدول الدوري.","—"],[42,"Mo","الموليبدينوم","95.95","صلب","transition",6,5,"العنصر الموليبدينوم (Mo)، العدد الذري 42. من عناصر الجدول الدوري.","—"],[43,"Tc","التكنيتيوم","98","صلب","transition",7,5,"العنصر التكنيتيوم (Tc)، العدد الذري 43. من عناصر الجدول الدوري.","—"],[44,"Ru","الروثينيوم","101.07","صلب","transition",8,5,"العنصر الروثينيوم (Ru)، العدد الذري 44. من عناصر الجدول الدوري.","—"],[45,"Rh","الروديوم","102.91","صلب","transition",9,5,"العنصر الروديوم (Rh)، العدد الذري 45. من عناصر الجدول الدوري.","—"],[46,"Pd","البلاديوم","106.42","صلب","transition",10,5,"العنصر البلاديوم (Pd)، العدد الذري 46. من عناصر الجدول الدوري.","—"],[47,"Ag","الفضة","107.868","صلب","transition",11,5,"العنصر الفضة (Ag)، العدد الذري 47. من عناصر الجدول الدوري.","—"],[48,"Cd","الكادميوم","112.414","صلب","transition",12,5,"العنصر الكادميوم (Cd)، العدد الذري 48. من عناصر الجدول الدوري.","—"],[49,"In","الإنديوم","114.818","صلب","post",13,5,"العنصر الإنديوم (In)، العدد الذري 49. من عناصر الجدول الدوري.","—"],[50,"Sn","القصدير","118.710","صلب","post",14,5,"العنصر القصدير (Sn)، العدد الذري 50. من عناصر الجدول الدوري.","—"],[51,"Sb","الأنتيمون","121.760","صلب","metalloid",15,5,"العنصر الأنتيمون (Sb)، العدد الذري 51. من عناصر الجدول الدوري.","—"],[52,"Te","التيلوريوم","127.60","صلب","metalloid",16,5,"العنصر التيلوريوم (Te)، العدد الذري 52. من عناصر الجدول الدوري.","—"],[53,"I","اليود","126.904","صلب","halogen",17,5,"العنصر اليود (I)، العدد الذري 53. من عناصر الجدول الدوري.","—"],[54,"Xe","الزينون","131.293","غاز","noble",18,5,"العنصر الزينون (Xe)، العدد الذري 54. من عناصر الجدول الدوري.","—"],[55,"Cs","السيزيوم","132.905","صلب","alkali",1,6,"العنصر السيزيوم (Cs)، العدد الذري 55. من عناصر الجدول الدوري.","—"],[56,"Ba","الباريوم","137.327","صلب","alkaline",2,6,"العنصر الباريوم (Ba)، العدد الذري 56. من عناصر الجدول الدوري.","—"],[57,"La","اللانثانوم","138.905","صلب","lanth",3,6,"العنصر اللانثانوم (La)، العدد الذري 57. من عناصر الجدول الدوري.","—"],[58,"Ce","السيريوم","140.116","صلب","lanth",4,8,"العنصر السيريوم (Ce)، العدد الذري 58. من عناصر الجدول الدوري.","—"],[59,"Pr","البراسيوديميوم","140.908","صلب","lanth",5,8,"العنصر البراسيوديميوم (Pr)، العدد الذري 59. من عناصر الجدول الدوري.","—"],[60,"Nd","النيوديميوم","144.242","صلب","lanth",6,8,"العنصر النيوديميوم (Nd)، العدد الذري 60. من عناصر الجدول الدوري.","—"],[61,"Pm","البروميثيوم","145","صلب","lanth",7,8,"العنصر البروميثيوم (Pm)، العدد الذري 61. من عناصر الجدول الدوري.","—"],[62,"Sm","الساماريوم","150.36","صلب","lanth",8,8,"العنصر الساماريوم (Sm)، العدد الذري 62. من عناصر الجدول الدوري.","—"],[63,"Eu","اليوروبيوم","151.964","صلب","lanth",9,8,"العنصر اليوروبيوم (Eu)، العدد الذري 63. من عناصر الجدول الدوري.","—"],[64,"Gd","الغادولينيوم","157.25","صلب","lanth",10,8,"العنصر الغادولينيوم (Gd)، العدد الذري 64. من عناصر الجدول الدوري.","—"],[65,"Tb","التيربيوم","158.925","صلب","lanth",11,8,"العنصر التيربيوم (Tb)، العدد الذري 65. من عناصر الجدول الدوري.","—"],[66,"Dy","الديسبروسيوم","162.500","صلب","lanth",12,8,"العنصر الديسبروسيوم (Dy)، العدد الذري 66. من عناصر الجدول الدوري.","—"],[67,"Ho","الهولميوم","164.930","صلب","lanth",13,8,"العنصر الهولميوم (Ho)، العدد الذري 67. من عناصر الجدول الدوري.","—"],[68,"Er","الإربيوم","167.259","صلب","lanth",14,8,"العنصر الإربيوم (Er)، العدد الذري 68. من عناصر الجدول الدوري.","—"],[69,"Tm","الثوليوم","168.934","صلب","lanth",15,8,"العنصر الثوليوم (Tm)، العدد الذري 69. من عناصر الجدول الدوري.","—"],[70,"Yb","الإيتربيوم","173.045","صلب","lanth",16,8,"العنصر الإيتربيوم (Yb)، العدد الذري 70. من عناصر الجدول الدوري.","—"],[71,"Lu","اللوتيتيوم","174.967","صلب","lanth",17,8,"العنصر اللوتيتيوم (Lu)، العدد الذري 71. من عناصر الجدول الدوري.","—"],[72,"Hf","الهافنيوم","178.49","صلب","transition",4,6,"العنصر الهافنيوم (Hf)، العدد الذري 72. من عناصر الجدول الدوري.","—"],[73,"Ta","التنتالوم","180.948","صلب","transition",5,6,"العنصر التنتالوم (Ta)، العدد الذري 73. من عناصر الجدول الدوري.","—"],[74,"W","التنغستن","183.84","صلب","transition",6,6,"العنصر التنغستن (W)، العدد الذري 74. من عناصر الجدول الدوري.","—"],[75,"Re","الرينيوم","186.207","صلب","transition",7,6,"العنصر الرينيوم (Re)، العدد الذري 75. من عناصر الجدول الدوري.","—"],[76,"Os","الأوزميوم","190.23","صلب","transition",8,6,"العنصر الأوزميوم (Os)، العدد الذري 76. من عناصر الجدول الدوري.","—"],[77,"Ir","الإيريديوم","192.217","صلب","transition",9,6,"العنصر الإيريديوم (Ir)، العدد الذري 77. من عناصر الجدول الدوري.","—"],[78,"Pt","البلاتين","195.084","صلب","transition",10,6,"العنصر البلاتين (Pt)، العدد الذري 78. من عناصر الجدول الدوري.","—"],[79,"Au","الذهب","196.967","صلب","transition",11,6,"العنصر الذهب (Au)، العدد الذري 79. من عناصر الجدول الدوري.","—"],[80,"Hg","الزئبق","200.592","سائل","transition",12,6,"العنصر الزئبق (Hg)، العدد الذري 80. من عناصر الجدول الدوري.","—"],[81,"Tl","الثاليوم","204.38","صلب","post",13,6,"العنصر الثاليوم (Tl)، العدد الذري 81. من عناصر الجدول الدوري.","—"],[82,"Pb","الرصاص","207.2","صلب","post",14,6,"العنصر الرصاص (Pb)، العدد الذري 82. من عناصر الجدول الدوري.","—"],[83,"Bi","البزموت","208.980","صلب","post",15,6,"العنصر البزموت (Bi)، العدد الذري 83. من عناصر الجدول الدوري.","—"],[84,"Po","البولونيوم","209","صلب","post",16,6,"العنصر البولونيوم (Po)، العدد الذري 84. من عناصر الجدول الدوري.","—"],[85,"At","الأستاتين","210","صلب","halogen",17,6,"العنصر الأستاتين (At)، العدد الذري 85. من عناصر الجدول الدوري.","—"],[86,"Rn","الرادون","222","غاز","noble",18,6,"العنصر الرادون (Rn)، العدد الذري 86. من عناصر الجدول الدوري.","—"],[87,"Fr","الفرانسيوم","223","صلب","alkali",1,7,"العنصر الفرانسيوم (Fr)، العدد الذري 87. من عناصر الجدول الدوري.","—"],[88,"Ra","الراديوم","226","صلب","alkaline",2,7,"العنصر الراديوم (Ra)، العدد الذري 88. من عناصر الجدول الدوري.","—"],[89,"Ac","الأكتينيوم","227","صلب","act",3,7,"العنصر الأكتينيوم (Ac)، العدد الذري 89. من عناصر الجدول الدوري.","—"],[90,"Th","الثوريوم","232.038","صلب","act",4,9,"العنصر الثوريوم (Th)، العدد الذري 90. من عناصر الجدول الدوري.","—"],[91,"Pa","البروتكتينيوم","231.036","صلب","act",5,9,"العنصر البروتكتينيوم (Pa)، العدد الذري 91. من عناصر الجدول الدوري.","—"],[92,"U","اليورانيوم","238.029","صلب","act",6,9,"العنصر اليورانيوم (U)، العدد الذري 92. من عناصر الجدول الدوري.","—"],[93,"Np","النبتونيوم","237","صلب","act",7,9,"العنصر النبتونيوم (Np)، العدد الذري 93. من عناصر الجدول الدوري.","—"],[94,"Pu","البلوتونيوم","244","صلب","act",8,9,"العنصر البلوتونيوم (Pu)، العدد الذري 94. من عناصر الجدول الدوري.","—"],[95,"Am","الأمريسيوم","243","صلب","act",9,9,"العنصر الأمريسيوم (Am)، العدد الذري 95. من عناصر الجدول الدوري.","—"],[96,"Cm","الكوريوم","247","صلب","act",10,9,"العنصر الكوريوم (Cm)، العدد الذري 96. من عناصر الجدول الدوري.","—"],[97,"Bk","البركيليوم","247","صلب","act",11,9,"العنصر البركيليوم (Bk)، العدد الذري 97. من عناصر الجدول الدوري.","—"],[98,"Cf","الكاليفورنيوم","251","صلب","act",12,9,"العنصر الكاليفورنيوم (Cf)، العدد الذري 98. من عناصر الجدول الدوري.","—"],[99,"Es","الأينشتاينيوم","252","صلب","act",13,9,"العنصر الأينشتاينيوم (Es)، العدد الذري 99. من عناصر الجدول الدوري.","—"],[100,"Fm","الفرميوم","257","صلب","act",14,9,"العنصر الفرميوم (Fm)، العدد الذري 100. من عناصر الجدول الدوري.","—"],[101,"Md","المندليفيوم","258","صلب","act",15,9,"العنصر المندليفيوم (Md)، العدد الذري 101. من عناصر الجدول الدوري.","—"],[102,"No","النوبليوم","259","صلب","act",16,9,"العنصر النوبليوم (No)، العدد الذري 102. من عناصر الجدول الدوري.","—"],[103,"Lr","اللورنسيوم","266","صلب","act",17,9,"العنصر اللورنسيوم (Lr)، العدد الذري 103. من عناصر الجدول الدوري.","—"],[104,"Rf","الرذرفورديوم","267","صلب","transition",4,7,"العنصر الرذرفورديوم (Rf)، العدد الذري 104. من عناصر الجدول الدوري.","—"],[105,"Db","الدوبنيوم","268","صلب","transition",5,7,"العنصر الدوبنيوم (Db)، العدد الذري 105. من عناصر الجدول الدوري.","—"],[106,"Sg","السيبورغيوم","269","صلب","transition",6,7,"العنصر السيبورغيوم (Sg)، العدد الذري 106. من عناصر الجدول الدوري.","—"],[107,"Bh","البوهريوم","270","صلب","transition",7,7,"العنصر البوهريوم (Bh)، العدد الذري 107. من عناصر الجدول الدوري.","—"],[108,"Hs","الهاسيوم","277","صلب","transition",8,7,"العنصر الهاسيوم (Hs)، العدد الذري 108. من عناصر الجدول الدوري.","—"],[109,"Mt","المايتنريوم","278","صلب","unknown",9,7,"العنصر المايتنريوم (Mt)، العدد الذري 109. من عناصر الجدول الدوري.","—"],[110,"Ds","الدارمشتاتيوم","281","صلب","unknown",10,7,"العنصر الدارمشتاتيوم (Ds)، العدد الذري 110. من عناصر الجدول الدوري.","—"],[111,"Rg","الرونتجينيوم","282","صلب","unknown",11,7,"العنصر الرونتجينيوم (Rg)، العدد الذري 111. من عناصر الجدول الدوري.","—"],[112,"Cn","الكوبرنيسيوم","285","صلب","unknown",12,7,"العنصر الكوبرنيسيوم (Cn)، العدد الذري 112. من عناصر الجدول الدوري.","—"],[113,"Nh","النيهونيوم","286","صلب","unknown",13,7,"العنصر النيهونيوم (Nh)، العدد الذري 113. من عناصر الجدول الدوري.","—"],[114,"Fl","الفليروفيوم","289","صلب","unknown",14,7,"العنصر الفليروفيوم (Fl)، العدد الذري 114. من عناصر الجدول الدوري.","—"],[115,"Mc","الموسكوفيوم","290","صلب","unknown",15,7,"العنصر الموسكوفيوم (Mc)، العدد الذري 115. من عناصر الجدول الدوري.","—"],[116,"Lv","الليفرموريوم","293","صلب","unknown",16,7,"العنصر الليفرموريوم (Lv)، العدد الذري 116. من عناصر الجدول الدوري.","—"],[117,"Ts","التينيسين","294","صلب","halogen",17,7,"العنصر التينيسين (Ts)، العدد الذري 117. من عناصر الجدول الدوري.","—"],[118,"Og","الأوغانيسون","294","غاز","noble",18,7,"العنصر الأوغانيسون (Og)، العدد الذري 118. من عناصر الجدول الدوري.","—"]];
const categoryColors = { nonmetal:'#45e0d0', alkali:'#ffa06a', alkaline:'#ffd06a', transition:'#57be9b', metalloid:'#a88cff', noble:'#5793ff', halogen:'#f472b6', post:'#94a3b8', lanth:'#c084fc', act:'#fb923c', unknown:'#64748b' };
const categoryNames = {nonmetal:'لافلز',alkali:'فلز قلوي',alkaline:'فلز قلوي ترابي',transition:'فلز انتقالي',metalloid:'شبه فلز',noble:'غاز نبيل',halogen:'هالوجين',post:'فلز بعد انتقالي',lanth:'لانثانيد',act:'أكتينيد',unknown:'خواص غير مؤكدة'};
function renderPeriodic(query='') {
 const grid=document.getElementById('periodicGrid'); if(!grid)return; grid.innerHTML='';
 for(let r=1;r<=9;r++){ for(let c=1;c<=18;c++){
  const el=all.find(x=>x[7]===r && x[6]===c);
  if(!el){const blank=document.createElement('div');blank.className='element empty';grid.append(blank);continue;}
  const match=!query||[el[1],el[2],String(el[0]),categoryNames[el[5]]].some(v=>v.toLowerCase().includes(query.toLowerCase()));
  const b=document.createElement('button');b.className=`element ${el[5]} ${el[0]===1?'selected':''}`;b.style.opacity=match?'1':'.16';
  b.innerHTML=`<span class="num">${el[0]}</span><strong>${el[1]}</strong><small>${el[2]}</small>`;b.title=`${el[2]} (${el[1]})`;b.addEventListener('click',()=>selectElement(el));grid.append(b);
 }}
}
function shellConfig(z){const orbitals=[[1,0,2],[2,0,2],[2,1,6],[3,0,2],[3,1,6],[4,0,2],[3,2,10],[4,1,6],[5,0,2],[4,2,10],[5,1,6],[6,0,2],[4,3,14],[5,2,10],[6,1,6],[7,0,2],[5,3,14],[6,2,10],[7,1,6]];const shells=[0,0,0,0,0,0,0];let left=z;for(const [n,l,cap] of orbitals){const take=Math.min(left,cap);shells[n-1]+=take;left-=take;if(!left)break;}return shells.filter(v=>v>0).join('، ');}
function selectElement(e){document.querySelectorAll('.element').forEach(x=>x.classList.remove('selected'));const btn=[...document.querySelectorAll('.element')].find(x=>x.querySelector('strong')?.textContent===e[1]);if(btn)btn.classList.add('selected');
 const set=(id,val)=>{const x=document.getElementById(id);if(x)x.textContent=val;};set('elSymbol',e[1]);set('elName',e[2]);set('elNumber','العدد الذري '+e[0]);set('elMass',e[3]);set('elState',e[4]);set('elGroup',e[6]>=8?'السلسلة '+(e[6]===8?'اللانثانيدات':'الأكتينيدات'):e[6]);set('elCategory',categoryNames[e[5]]||'عنصر');set('elConfig',shellConfig(e[0]));set('elNote',e[8]);}
function initPeriodic(){renderPeriodic();document.getElementById('elementSearch')?.addEventListener('input',e=>renderPeriodic(e.target.value.trim()));const legend=document.getElementById('legend');if(legend)legend.innerHTML=Object.entries(categoryNames).map(([c,n])=>`<span><i style="background:${categoryColors[c]}"></i>${n}</span>`).join('');}

// Tools
const atomic = {"H":1.008,"He":4.0026,"Li":6.94,"Be":9.0122,"B":10.81,"C":12.011,"N":14.007,"O":15.999,"F":18.998,"Ne":20.18,"Na":22.99,"Mg":24.305,"Al":26.982,"Si":28.085,"P":30.974,"S":32.06,"Cl":35.45,"Ar":39.948,"K":39.098,"Ca":40.078,"Sc":44.956,"Ti":47.867,"V":50.942,"Cr":51.996,"Mn":54.938,"Fe":55.845,"Co":58.933,"Ni":58.693,"Cu":63.546,"Zn":65.38,"Ga":69.723,"Ge":72.63,"As":74.922,"Se":78.971,"Br":79.904,"Kr":83.798,"Rb":85.468,"Sr":87.62,"Y":88.906,"Zr":91.224,"Nb":92.906,"Mo":95.95,"Tc":98.0,"Ru":101.07,"Rh":102.91,"Pd":106.42,"Ag":107.868,"Cd":112.414,"In":114.818,"Sn":118.71,"Sb":121.76,"Te":127.6,"I":126.904,"Xe":131.293,"Cs":132.905,"Ba":137.327,"La":138.905,"Ce":140.116,"Pr":140.908,"Nd":144.242,"Pm":145.0,"Sm":150.36,"Eu":151.964,"Gd":157.25,"Tb":158.925,"Dy":162.5,"Ho":164.93,"Er":167.259,"Tm":168.934,"Yb":173.045,"Lu":174.967,"Hf":178.49,"Ta":180.948,"W":183.84,"Re":186.207,"Os":190.23,"Ir":192.217,"Pt":195.084,"Au":196.967,"Hg":200.592,"Tl":204.38,"Pb":207.2,"Bi":208.98,"Po":209.0,"At":210.0,"Rn":222.0,"Fr":223.0,"Ra":226.0,"Ac":227.0,"Th":232.038,"Pa":231.036,"U":238.029,"Np":237.0,"Pu":244.0,"Am":243.0,"Cm":247.0,"Bk":247.0,"Cf":251.0,"Es":252.0,"Fm":257.0,"Md":258.0,"No":259.0,"Lr":266.0,"Rf":267.0,"Db":268.0,"Sg":269.0,"Bh":270.0,"Hs":277.0,"Mt":278.0,"Ds":281.0,"Rg":282.0,"Cn":285.0,"Nh":286.0,"Fl":289.0,"Mc":290.0,"Lv":293.0,"Ts":294.0,"Og":294.0};

function calculateMolarMass(formula) {
  formula = formula.replace(/\s/g, '');
  let total = 0;
  const regex = /([A-Z][a-z]?)(\d*)/g;
  let match;
  while ((match = regex.exec(formula)) !== null) {
    const element = match[1];
    const count = parseInt(match[2]) || 1;
    if (atomic[element]) total += atomic[element] * count;
    else return null;
  }
  return total > 0 ? total.toFixed(3) : null;
}

function initTools() {
  const massBtn = document.getElementById('massBtn');
  if (massBtn) {
    massBtn.addEventListener('click', () => {
      const formula = document.getElementById('formulaInput')?.value.trim() || '';
      const result = calculateMolarMass(formula);
      const el = document.getElementById('massResult');
      if (el) {
        if (result) {
          el.textContent = `الكتلة المولية ≈ ${result} جم/مول`;
          el.style.color = 'var(--cyan)';
        } else {
          el.textContent = 'صيغة غير مدعومة أو غير صحيحة';
          el.style.color = '#ff6b6b';
        }
      }
    });
  }

  function convert() {
    const v = Number(document.getElementById('unitValue')?.value) || 0;
    const t = document.getElementById('unitType')?.value;
    const map = {
      'g-mg': [v * 1000, 'ملليجرام'], 'mg-g': [v / 1000, 'جرام'],
      'l-ml': [v * 1000, 'ملليلتر'], 'ml-l': [v / 1000, 'لتر'],
      'c-k': [v + 273.15, 'كلفن'], 'k-c': [v - 273.15, '°C'],
      'mol-mmol': [v * 1000, 'ملي مول']
    };
    const [n, u] = map[t] || [v, ''];
    const res = document.getElementById('unitResult');
    if (res) res.textContent = `${Number(n.toFixed(4))} ${u}`;
  }
  document.getElementById('unitValue')?.addEventListener('input', convert);
  document.getElementById('unitType')?.addEventListener('change', convert);
  convert();

  document.getElementById('phRange')?.addEventListener('input', e => {
    const v = Number(e.target.value);
    const valEl = document.getElementById('phValue');
    if (valEl) valEl.textContent = v.toFixed(1);
    const result = document.getElementById('phResult');
    const visual = document.getElementById('phVisual');
    let color, text;
    if (v < 3) { color = '#ff4444'; text = 'حمضي قوي'; }
    else if (v < 7) { color = '#ff8844'; text = 'حمضي'; }
    else if (v === 7) { color = '#44ff88'; text = 'متعادل'; }
    else if (v < 11) { color = '#4488ff'; text = 'قاعدي'; }
    else { color = '#8844ff'; text = 'قاعدي قوي'; }
    if (result) result.textContent = text;
    if (visual) {
      visual.style.background = `linear-gradient(90deg, ${color}, transparent)`;
      visual.style.height = '8px';
      visual.style.borderRadius = '4px';
      visual.style.margin = '10px 0';
    }
  });
  document.getElementById('phRange')?.dispatchEvent(new Event('input'));

  document.getElementById('molarityBtn')?.addEventListener('click', () => {
    const molarMass = Number(document.getElementById('molarMassInput')?.value);
    const mass = Number(document.getElementById('massInput')?.value);
    const volume = Number(document.getElementById('volumeInput')?.value) || 1;
    const result = document.getElementById('molarityResult');
    if (result) {
      if (molarMass > 0 && mass > 0 && volume > 0) {
        const moles = mass / molarMass;
        const molarity = moles / volume;
        result.textContent = `المولارية ≈ ${molarity.toFixed(3)} مول/لتر`;
        result.style.color = 'var(--cyan)';
      } else {
        result.textContent = 'أدخل قيمًا صحيحة';
        result.style.color = '#ff6b6b';
      }
    }
  });
}

// Quiz
const quizQuestions = [
  { q: 'ما هو العدد الذري للهيدروجين؟', options: ['1', '2', '6', '8'], correct: 0 },
  { q: 'أي عنصر يشكل معظم الغلاف الجوي للأرض؟', options: ['الأكسجين', 'النيتروجين', 'ثاني أكسيد الكربون', 'الهيدروجين'], correct: 1 },
  { q: 'ما هي صيغة الماء الكيميائية؟', options: ['H2O', 'CO2', 'NaCl', 'O2'], correct: 0 },
  { q: 'أي من التالي فلز قلوي؟', options: ['الحديد', 'الصوديوم', 'الكلور', 'الكربون'], correct: 1 },
  { q: 'ما قيمة pH للماء النقي تقريبًا؟', options: ['0', '7', '14', '1'], correct: 1 }
];

let currentQuestion = 0, score = 0, quizActive = false;

function showQuestion() {
  if (currentQuestion >= quizQuestions.length) { endQuiz(); return; }
  const q = quizQuestions[currentQuestion];
  document.getElementById('quizProgress').textContent = `السؤال ${currentQuestion + 1} من ${quizQuestions.length}`;
  document.getElementById('quizQuestion').textContent = q.q;
  document.getElementById('quizFeedback').textContent = '';
  document.getElementById('nextQuizBtn').style.display = 'none';
  const optionsDiv = document.getElementById('quizOptions');
  optionsDiv.innerHTML = '';
  q.options.forEach((opt, i) => {
    const btn = document.createElement('button');
    btn.className = 'quiz-option';
    btn.textContent = opt;
    btn.addEventListener('click', () => checkAnswer(i));
    optionsDiv.append(btn);
  });
}

function checkAnswer(selected) {
  if (!quizActive) return;
  const q = quizQuestions[currentQuestion];
  const options = document.querySelectorAll('.quiz-option');
  options.forEach(btn => btn.disabled = true);
  if (selected === q.correct) {
    score++;
    options[selected].classList.add('correct');
    document.getElementById('quizFeedback').textContent = '✓ إجابة صحيحة!';
    document.getElementById('quizFeedback').style.color = '#44ff88';
  } else {
    options[selected].classList.add('wrong');
    options[q.correct].classList.add('correct');
    document.getElementById('quizFeedback').textContent = '✗ إجابة خاطئة';
    document.getElementById('quizFeedback').style.color = '#ff6b6b';
  }
  document.getElementById('nextQuizBtn').style.display = 'inline-block';
  quizActive = false;
}

function endQuiz() {
  document.getElementById('quizCard').style.display = 'none';
  document.getElementById('quizScore').style.display = 'block';
  document.getElementById('finalScore').textContent = score;
  const msg = score >= 4 ? 'ممتاز! أنت عالم كيمياء صغير 🌟' : score >= 2 ? 'جيد جدًا، استمر في التعلم!' : 'حاول مرة أخرى، ستتحسن!';
  document.getElementById('scoreMessage').textContent = msg;
}

function initQuiz() {
  document.getElementById('startQuizBtn')?.addEventListener('click', () => {
    currentQuestion = 0; score = 0; quizActive = true;
    document.getElementById('startQuizBtn').style.display = 'none';
    document.getElementById('quizScore').style.display = 'none';
    document.getElementById('quizCard').style.display = 'block';
    showQuestion();
  });
  document.getElementById('nextQuizBtn')?.addEventListener('click', () => {
    currentQuestion++; quizActive = true; showQuestion();
  });
  document.getElementById('restartQuizBtn')?.addEventListener('click', () => {
    currentQuestion = 0; score = 0; quizActive = true;
    document.getElementById('quizScore').style.display = 'none';
    document.getElementById('quizCard').style.display = 'block';
    showQuestion();
  });
}

// Branches
const branchInfo = {
  organic: ['الكيمياء العضوية', 'تدرس مركبات الكربون مثل الهيدروكربونات والكحولات والبوليمرات.', 'من تطبيقاتها: الأدوية والمواد البلاستيكية والوقود.'],
  inorganic: ['الكيمياء غير العضوية', 'تتناول الفلزات والأملاح والمعادن والمعقدات.', 'من تطبيقاتها: المواد والسيراميك واستخلاص المعادن.'],
  physical: ['الكيمياء الفيزيائية', 'تربط الفيزياء بالكيمياء مثل الديناميكا الحرارية والحركية.', 'تفسر سرعة التفاعلات وانتقال الطاقة.'],
  analytical: ['الكيمياء التحليلية', 'تحديد مكونات العينات وقياس كمياتها بدقة.', 'تستخدم في مراقبة الجودة والبيئة والأغذية.'],
  biochem: ['الكيمياء الحيوية', 'دراسة الجزيئات والعمليات داخل الكائنات الحية.', 'تتصل بالطب والوراثة والتغذية.'],
  environment: ['الكيمياء البيئية', 'دراسة المواد الكيميائية في الهواء والماء والتربة.', 'تدعم فهم التلوث ومعالجة المياه.']
};

function initBranches() {
  document.querySelectorAll('.branch-card').forEach(card => {
    card.addEventListener('click', () => {
      const d = branchInfo[card.dataset.branch];
      const box = document.getElementById('branchDetails');
      if (box && d) {
        box.innerHTML = `<span class="pill">دليل الفروع</span><h3>${d[0]}</h3><p>${d[1]}</p><p><b>مجالات التطبيق:</b> ${d[2]}</p>`;
        document.querySelectorAll('.branch-card').forEach(c => c.classList.remove('active'));
        card.classList.add('active');
      }
    });
  });
}

function initLab(){
 const compounds=[
  {f:'H₂O',name:'الماء',kind:'مركب شائع',color:'#38bdf8',desc:'مركب قطبي يتكون من الهيدروجين والأكسجين.'},
  {f:'NaCl',name:'كلوريد الصوديوم',kind:'ملح',color:'#cbd5e1',desc:'مركب أيوني معروف باسم ملح الطعام.'},
  {f:'CO₂',name:'ثاني أكسيد الكربون',kind:'أكسيد',color:'#94a3b8',desc:'غاز يدخل في دورة الكربون.'},
  {f:'NaHCO₃',name:'بيكربونات الصوديوم',kind:'ملح',color:'#e2e8f0',desc:'مركب يُدرس ضمن تفاعلات الأحماض والكربونات.'},
  {f:'CH₃COOH',name:'حمض الأسيتيك',kind:'حمض ضعيف',color:'#fbbf24',desc:'حمض عضوي بسيط.'},
  {f:'HCl',name:'حمض الهيدروكلوريك',kind:'حمض',color:'#fb7185',desc:'مثال تعليمي على الأحماض؛ يُعرض هنا كنموذج رمزي فقط.'},
  {f:'NaOH',name:'هيدروكسيد الصوديوم',kind:'قاعدة',color:'#a78bfa',desc:'مثال تعليمي على القواعد؛ لا توجد إرشادات تعامل عملي.'},
  {f:'H₂SO₄',name:'حمض الكبريتيك',kind:'حمض',color:'#f97316',desc:'يظهر في المعادلات التعليمية النظرية فقط.'},
  {f:'KNO₃',name:'نترات البوتاسيوم',kind:'ملح',color:'#86efac',desc:'صيغة كيميائية للتعرف على الأملاح.'},
  {f:'CaCO₃',name:'كربونات الكالسيوم',kind:'كربونات',color:'#f1f5f9',desc:'مركب يوجد في الحجر الجيري والطباشير.'}
 ];
 const reactions={
  'HCl|NaOH':{eq:'HCl + NaOH → NaCl + H₂O',name:'تعادل حمض وقاعدة',desc:'يتحد الحمض والقاعدة في نموذج التعادل لينتج ملح وماء. المعادلة موزونة.'},
  'NaOH|HCl':{eq:'HCl + NaOH → NaCl + H₂O',name:'تعادل حمض وقاعدة',desc:'يتحد الحمض والقاعدة في نموذج التعادل لينتج ملح وماء. المعادلة موزونة.'},
  'CH₃COOH|NaHCO₃':{eq:'CH₃COOH + NaHCO₃ → CH₃COONa + H₂O + CO₂',name:'تفاعل حمض مع بيكربونات',desc:'يوضح النموذج تكوّن ملح وماء وثاني أكسيد الكربون. المعادلة موزونة.'},
  'NaHCO₃|CH₃COOH':{eq:'CH₃COOH + NaHCO₃ → CH₃COONa + H₂O + CO₂',name:'تفاعل حمض مع بيكربونات',desc:'يوضح النموذج تكوّن ملح وماء وثاني أكسيد الكربون. المعادلة موزونة.'},
  'H₂SO₄|NaOH':{eq:'H₂SO₄ + 2NaOH → Na₂SO₄ + 2H₂O',name:'تعادل حمض ثنائي البروتون',desc:'نموذج نظري يوضح معاملات الموازنة عند التعادل الكامل.'},
  'NaOH|H₂SO₄':{eq:'H₂SO₄ + 2NaOH → Na₂SO₄ + 2H₂O',name:'تعادل حمض ثنائي البروتون',desc:'نموذج نظري يوضح معاملات الموازنة عند التعادل الكامل.'}
 };
 const a=document.getElementById('compoundA'),b=document.getElementById('compoundB');
 if(a&&b){const opts=compounds.map(c=>`<option value="${c.f}">${c.name} — ${c.f}</option>`).join('');a.innerHTML=opts;b.innerHTML=opts;b.selectedIndex=1;}
 const updateInfo=(sel,id)=>{const c=compounds.find(x=>x.f===sel?.value),el=document.getElementById(id);if(el&&c)el.textContent=`${c.name} • ${c.kind}: ${c.desc}`;};
 a?.addEventListener('change',()=>updateInfo(a,'compoundAInfo'));b?.addEventListener('change',()=>updateInfo(b,'compoundBInfo'));updateInfo(a,'compoundAInfo');updateInfo(b,'compoundBInfo');
 document.querySelectorAll('[data-vessel]').forEach(v=>v.addEventListener('click',()=>{document.querySelectorAll('[data-vessel]').forEach(x=>x.classList.remove('active'));v.classList.add('active');const label=document.getElementById('vesselLabel');if(label)label.textContent='الأداة المختارة: '+v.dataset.vessel;}));
 const mix=document.getElementById('mixBtn');mix?.addEventListener('click',()=>{const x=a?.value,y=b?.value,out=document.getElementById('reactionOutput'),liq=document.getElementById('labLiquid'),bubble=document.getElementById('bubbles');if(!out)return;const r=reactions[x+'|'+y];if(r){out.innerHTML=`<div class="reaction-success"><span class="pill">محاكاة مكتملة</span><h3>${r.name}</h3><div class="equation">${r.eq}</div><p>${r.desc}</p><small>هذه نتيجة نموذج تعليمي، وليست وصفة أو تعليمات لتجربة حقيقية.</small></div>`;if(liq)liq.style.background='linear-gradient(180deg,#60a5fa,#22c55e)';if(bubble){bubble.classList.remove('animate');void bubble.offsetWidth;bubble.classList.add('animate');}}else{out.innerHTML='<div class="reaction-note"><h3>لا توجد نتيجة موثقة في مكتبة المحاكاة</h3><p>لم يتم افتراض نواتج من تلقاء أنفسنا. جرّب زوجًا من الأمثلة التعليمية المتاحة أو استخدم أداة موازنة المعادلات.</p></div>';if(liq)liq.style.background='linear-gradient(180deg,#64748b,#334155)';}});
 document.getElementById('clearLabBtn')?.addEventListener('click',()=>{const liqReset=document.getElementById('labLiquid');if(a)a.selectedIndex=0;if(b)b.selectedIndex=1;updateInfo(a,'compoundAInfo');updateInfo(b,'compoundBInfo');const out=document.getElementById('reactionOutput');if(out)out.innerHTML='<p class="muted">اختر مركبين ثم اضغط «امزج افتراضياً» لعرض المحاكاة.</p>';if(liqReset)liqReset.style.background='linear-gradient(180deg,#38bdf8,#0d9488)';});
 document.getElementById('phDemoBtn')?.addEventListener('click',()=>{const liquid=document.getElementById('labLiquid')||document.getElementById('liquid');if(liquid){liquid.style.background='linear-gradient(180deg,#a78bfa,#3b82f6)';setTimeout(()=>liquid.style.background='linear-gradient(180deg,#38bdf8,#0d9488)',1400);}});
 document.getElementById('atomDemoBtn')?.addEventListener('click',()=>{const v=document.getElementById('moleculeVisual');if(v)v.innerHTML='<div class="atom-orbit"><i></i><b>+</b></div>';});
}

// Theme (global)
document.getElementById('themeBtn')?.addEventListener('click', () => {
  document.body.classList.toggle('light');
  const btn = document.getElementById('themeBtn');
  if (btn) btn.textContent = document.body.classList.contains('light') ? '☀️' : '🌙';
});

// Init based on page
document.addEventListener('DOMContentLoaded', () => {
  if (document.getElementById('periodicGrid')) initPeriodic();
  if (document.getElementById('massBtn')) initTools();
  if (document.getElementById('startQuizBtn')) initQuiz();
  if (document.querySelector('.branch-card')) initBranches();
  if (document.getElementById('compoundA') || document.getElementById('phDemoBtn')) initLab();
});
