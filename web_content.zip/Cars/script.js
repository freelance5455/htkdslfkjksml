
"use strict";

(() => {
  const $ = (id) => document.getElementById(id);

  const canvas = $("gameCanvas");
  const ctx = canvas.getContext("2d");

  if (!ctx) {
    alert("Impossible de lancer le jeu : canvas non pris en charge.");
    return;
  }

  const homeScreen = $("homeScreen");
  const pauseScreen = $("pauseScreen");
  const gameOverScreen = $("gameOverScreen");

  const speedDisplay = $("speed");
  const scoreDisplay = $("score");
  const bestDisplay = $("best");
  const finalScoreDisplay = $("finalScore");
  const recordMessage = $("recordMessage");

  const startBtn = $("startBtn");
  const pauseBtn = $("pauseBtn");
  const resumeBtn = $("resumeBtn");
  const restartBtn = $("restartBtn");
  const againBtn = $("againBtn");
  const leftBtn = $("leftBtn");
  const rightBtn = $("rightBtn");
  const turboBtn = $("turboBtn");

  let W = 0;
  let H = 0;
  let dpr = 1;

  let state = "home";
  let lastTime = 0;
  let elapsed = 0;
  let score = 0;
  let distance = 0;
  let speed = 0;
  let roadOffset = 0;
  let spawnTimer = 0;
  let playerX = 0;
  let best = loadBest();
  let traffic = [];
  let particles = [];

  const keys = {
    left: false,
    right: false,
    turbo: false
  };

  const colors = [
    "#ff405b",
    "#f5c842",
    "#b86cff",
    "#f2f5ff",
    "#ff8b35",
    "#36e0ba"
  ];

  function loadBest() {
    try {
      return Number(localStorage.getItem("turboRacingBest")) || 0;
    } catch (e) {
      return 0;
    }
  }

  function saveBest() {
    try {
      localStorage.setItem("turboRacingBest", String(best));
    } catch (e) {
      // Le jeu continue même si le stockage est indisponible.
    }
  }

  function resizeCanvas() {
    const rect = canvas.getBoundingClientRect();

    W = Math.max(1, rect.width);
    H = Math.max(1, rect.height);
    dpr = Math.min(window.devicePixelRatio || 1, 2);

    canvas.width = Math.round(W * dpr);
    canvas.height = Math.round(H * dpr);

    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    playerX = clamp(playerX || 0, -0.8, 0.8);

    draw();
  }

  function clamp(value, min, max) {
    return Math.max(min, Math.min(max, value));
  }

  function random(min, max) {
    return Math.random() * (max - min) + min;
  }

  // Dessine un rectangle arrondi compatible avec les anciens Android.
  function roundedRect(x, y, w, h, r, color) {
    r = Math.min(r, Math.abs(w) / 2, Math.abs(h) / 2);

    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.lineTo(x + w - r, y);
    ctx.quadraticCurveTo(x + w, y, x + w, y + r);
    ctx.lineTo(x + w, y + h - r);
    ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
    ctx.lineTo(x + r, y + h);
    ctx.quadraticCurveTo(x, y + h, x, y + h - r);
    ctx.lineTo(x, y + r);
    ctx.quadraticCurveTo(x, y, x + r, y);
    ctx.closePath();

    ctx.fillStyle = color;
    ctx.fill();
  }

  function roadAt(t) {
    const horizon = H * 0.27;
    const bottom = H * 1.08;
    const p = clamp(t, 0, 1);
    const curve = Math.sin(distance * 0.0008 + p * 2.8) * W * 0.055;

    return {
      y: horizon + (bottom - horizon) * p,
      center: W / 2 + curve * p,
      half: W * (0.045 + 0.43 * p)
    };
  }

  function drawBackground() {
    const sky = ctx.createLinearGradient(0, 0, 0, H);
    sky.addColorStop(0, "#102d52");
    sky.addColorStop(0.5, "#2786a1");
    sky.addColorStop(1, "#7bbda6");

    ctx.fillStyle = sky;
    ctx.fillRect(0, 0, W, H);

    // Soleil et halo
    const sunX = W * 0.75;
    const sunY = H * 0.19;
    const sunR = Math.max(15, W * 0.055);

    const glow = ctx.createRadialGradient(
      sunX, sunY, 2, sunX, sunY, sunR * 2.4
    );
    glow.addColorStop(0, "rgba(255,242,184,0.9)");
    glow.addColorStop(1, "rgba(255,242,184,0)");

    ctx.fillStyle = glow;
    ctx.fillRect(sunX - sunR * 2.5, sunY - sunR * 2.5,
                 sunR * 5, sunR * 5);

    ctx.beginPath();
    ctx.arc(sunX, sunY, sunR, 0, Math.PI * 2);
    ctx.fillStyle = "#fff0b0";
    ctx.fill();

    // Montagnes lointaines
    ctx.fillStyle = "#365e78";
    ctx.beginPath();
    ctx.moveTo(0, H * 0.39);
    for (let i = 0; i <= 10; i++) {
      const x = W * i / 10;
      const y = H * (0.20 + (i % 3) * 0.055);
      ctx.lineTo(x, y);
    }
    ctx.lineTo(W, H * 0.43);
    ctx.lineTo(W, H * 0.5);
    ctx.lineTo(0, H * 0.5);
    ctx.closePath();
    ctx.fill();

    // Végétation
    ctx.fillStyle = "#1c6a54";
    ctx.fillRect(0, H * 0.37, W, H * 0.63);

    for (let i = 0; i < 24; i++) {
      const x = (i / 24) * W;
      const y = H * (0.36 + (i % 4) * 0.018);
      const size = W * (0.025 + (i % 3) * 0.008);

      ctx.fillStyle = i % 2 ? "#174e43" : "#28745a";
      ctx.beginPath();
      ctx.moveTo(x - size, y + size * 2);
      ctx.lineTo(x, y - size);
      ctx.lineTo(x + size, y + size * 2);
      ctx.closePath();
      ctx.fill();
    }
  }

  function drawRoad() {
    const horizon = H * 0.27;
    const bottom = H * 1.08;
    const topHalf = W * 0.045;
    const bottomHalf = W * 0.43;
    const topCenter = W / 2;
    const bottomCenter = roadAt(1).center;

    // Bords extérieurs
    ctx.beginPath();
    ctx.moveTo(topCenter - topHalf, horizon);
    ctx.lineTo(topCenter + topHalf, horizon);
    ctx.lineTo(bottomCenter + bottomHalf + 14, bottom);
    ctx.lineTo(bottomCenter - bottomHalf - 14, bottom);
    ctx.closePath();
    ctx.fillStyle = "#d8e0e5";
    ctx.fill();

    // Asphalte
    ctx.beginPath();
    ctx.moveTo(topCenter - topHalf, horizon);
    ctx.lineTo(topCenter + topHalf, horizon);
    ctx.lineTo(bottomCenter + bottomHalf, bottom);
    ctx.lineTo(bottomCenter - bottomHalf, bottom);
    ctx.closePath();

    const asphalt = ctx.createLinearGradient(0, horizon, 0, H);
    asphalt.addColorStop(0, "#48535f");
    asphalt.addColorStop(1, "#1a202a");
    ctx.fillStyle = asphalt;
    ctx.fill();

    // Bandes rouges et blanches sur les côtés
    const stripeCount = 22;

    for (let i = 0; i < stripeCount; i++) {
      const t1 = i / stripeCount;
      const t2 = (i + 1) / stripeCount;
      const a = roadAt(t1);
      const b = roadAt(t2);
      const color = (i + Math.floor(roadOffset / 35)) % 2
        ? "#f3f4f5" : "#ef394d";

      ctx.fillStyle = color;

      ctx.beginPath();
      ctx.moveTo(a.center - a.half, a.y);
      ctx.lineTo(a.center - a.half + 3, a.y);
      ctx.lineTo(b.center - b.half - 3, b.y);
      ctx.lineTo(b.center - b.half - 3, b.y);
      ctx.closePath();
      ctx.fill();

      ctx.beginPath();
      ctx.moveTo(a.center + a.half - 3, a.y);
      ctx.lineTo(a.center + a.half, a.y);
      ctx.lineTo(b.center + b.half + 3, b.y);
      ctx.lineTo(b.center + b.half + 3, b.y);
      ctx.closePath();
      ctx.fill();
    }

    // Lignes de séparation des voies
    for (let lane = 1; lane <= 2; lane++) {
      for (let i = 0; i < 16; i++) {
        const phase = (i / 16 + (roadOffset % 100) / 100) % 1;
        const t1 = phase;
        const t2 = Math.min(1, phase + 0.027 + phase * 0.035);

        if (t2 <= t1) continue;

        const a = roadAt(t1);
        const b = roadAt(t2);

        const x1 = a.center - a.half + (2 * a.half * lane / 3);
        const x2 = b.center - b.half + (2 * b.half * lane / 3);
        const width = 1 + t1 * 5;

        ctx.strokeStyle = "rgba(255,255,255,0.82)";
        ctx.lineWidth = width;
        ctx.beginPath();
        ctx.moveTo(x1, a.y);
        ctx.lineTo(x2, b.y);
        ctx.stroke();
      }
    }
  }

  function drawCar(x, y, width, height, color, isPlayer) {
    ctx.save();
    ctx.translate(x, y);

    const tilt = isPlayer
      ? (keys.left ? -0.08 : keys.right ? 0.08 : 0)
      : 0;

    ctx.rotate(tilt);

    // Ombre
    ctx.fillStyle = "rgba(0,0,0,0.4)";
    ctx.beginPath();
    ctx.ellipse(0, height * 0.42, width * 0.65, height * 0.12,
                0, 0, Math.PI * 2);
    ctx.fill();

    // Pneus
    const tireW = width * 0.17;
    const tireH = height * 0.24;

    roundedRect(-width * 0.52, -height * 0.25,
                tireW, tireH, 3, "#080c12");
    roundedRect(width * 0.35, -height * 0.25,
                tireW, tireH, 3, "#080c12");
    roundedRect(-width * 0.52, height * 0.18,
                tireW, tireH, 3, "#080c12");
    roundedRect(width * 0.35, height * 0.18,
                tireW, tireH, 3, "#080c12");

    // Carrosserie
    const body = ctx.createLinearGradient(-width / 2, 0, width / 2, 0);
    body.addColorStop(0, shadeColor(color, -35));
    body.addColorStop(0.5, color);
    body.addColorStop(1, shadeColor(color, -20));

    roundedRect(-width * 0.42, -height * 0.5,
                width * 0.84, height, width * 0.17, body);

    // Pare-brise
    ctx.beginPath();
    ctx.moveTo(-width * 0.29, -height * 0.16);
    ctx.lineTo(-width * 0.21, -height * 0.37);
    ctx.lineTo(width * 0.21, -height * 0.37);
    ctx.lineTo(width * 0.29, -height * 0.16);
    ctx.closePath();

    ctx.fillStyle = "#a9e5f2";
    ctx.fill();

    // Vitre avant / cockpit
    ctx.beginPath();
    ctx.moveTo(-width * 0.29, height * 0.05);
    ctx.lineTo(-width * 0.20, -height * 0.12);
    ctx.lineTo(width * 0.20, -height * 0.12);
    ctx.lineTo(width * 0.29, height * 0.05);
    ctx.closePath();
    ctx.fillStyle = "#162b3f";
    ctx.fill();

    // Reflets
    ctx.strokeStyle = "rgba(255,255,255,0.65)";
    ctx.lineWidth = Math.max(1, width * 0.025);
    ctx.beginPath();
    ctx.moveTo(-width * 0.28, height * 0.2);
    ctx.lineTo(-width * 0.22, height * 0.39);
    ctx.stroke();

    // Phares
    roundedRect(-width * 0.34, -height * 0.43,
                width * 0.19, height * 0.07, 2, "#eaffff");
    roundedRect(width * 0.15, -height * 0.43,
                width * 0.19, height * 0.07, 2, "#eaffff");

    // Feux arrière
    roundedRect(-width * 0.34, height * 0.38,
                width * 0.18, height * 0.06, 2, "#ff263c");
    roundedRect(width * 0.16, height * 0.38,
                width * 0.18, height * 0.06, 2, "#ff263c");

    // Aileron de la voiture du joueur
    if (isPlayer) {
      ctx.fillStyle = "#111720";
      ctx.fillRect(-width * 0.38, height * 0.20,
                   width * 0.76, height * 0.045);
    }

    ctx.restore();
  }

  function shadeColor(hex, amount) {
    const clean = hex.replace("#", "");
    const num = parseInt(clean, 16);

    if (Number.isNaN(num)) return hex;

    const r = clamp((num >> 16) + amount, 0, 255);
    const g = clamp(((num >> 8) & 255) + amount, 0, 255);
    const b = clamp((num & 255) + amount, 0, 255);

    return "#" + [r, g, b]
      .map(v => Math.round(v).toString(16).padStart(2, "0"))
      .join("");
  }

  function spawnTraffic() {
    const lane = Math.floor(Math.random() * 3) - 1;

    traffic.push({
      lane: lane,
      t: 0.02,
      color: colors[Math.floor(Math.random() * colors.length)],
      speed: random(0.18, 0.36),
      passed: false
    });
  }

  function drawTraffic() {
    // Les voitures les plus éloignées sont dessinées en premier.
    const sorted = traffic.slice().sort((a, b) => a.t - b.t);

    for (const car of sorted) {
      const p = clamp(car.t, 0, 1);
      const road = roadAt(p);
      const x = road.center + road.half * car.lane * 0.61;
      const width = 12 + p * W * 0.10;
      const height = width * 1.55;

      drawCar(x, road.y, width, height, car.color, false);
    }
  }

  function drawPlayer() {
    const road = roadAt(0.88);
    const x = road.center + playerX * road.half * 0.82;
    const width = clamp(W * 0.14, 42, 88);
    const height = width * 1.55;
    const y = H * 0.82;

    // Effet lumineux du turbo
    if (keys.turbo && state === "playing") {
      ctx.save();
      ctx.globalAlpha = 0.7;
      ctx.fillStyle = "#00d9ff";
      ctx.beginPath();
      ctx.moveTo(x - width * 0.19, y + height * 0.38);
      ctx.lineTo(x, y + height * 0.95 + random(0, 12));
      ctx.lineTo(x + width * 0.19, y + height * 0.38);
      ctx.closePath();
      ctx.fill();
      ctx.restore();
    }

    drawCar(x, y, width, height, "#00bfff", true);
  }

  function drawParticles() {
    for (const p of particles) {
      ctx.globalAlpha = clamp(p.life, 0, 1);
      ctx.fillStyle = p.color;
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.globalAlpha = 1;
  }

  function draw() {
    if (!W || !H) return;

    ctx.clearRect(0, 0, W, H);

    drawBackground();
    drawRoad();
    drawTraffic();
    drawParticles();
    drawPlayer();

    // Vignettage léger
    const vignette = ctx.createRadialGradient(
      W / 2, H / 2, H * 0.15,
      W / 2, H / 2, H * 0.8
    );
    vignette.addColorStop(0, "rgba(0,0,0,0)");
    vignette.addColorStop(1, "rgba(0,0,0,0.25)");

    ctx.fillStyle = vignette;
    ctx.fillRect(0, 0, W, H);
  }

  function resetGame() {
    score = 0;
    distance = 0;
    speed = 0;
    roadOffset = 0;
    spawnTimer = 0.5;
    elapsed = 0;
    playerX = 0;
    traffic = [];
    particles = [];

    keys.left = false;
    keys.right = false;
    keys.turbo = false;
    turboBtn.classList.remove("active");

    updateHUD();
  }

  function startGame() {
    resetGame();
    state = "playing";

    homeScreen.classList.add("hidden");
    pauseScreen.classList.add("hidden");
    gameOverScreen.classList.add("hidden");

    pauseBtn.textContent = "Ⅱ";
    lastTime = performance.now();
    draw();
  }

  function pauseGame() {
    if (state === "playing") {
      state = "paused";
      keys.left = false;
      keys.right = false;
      keys.turbo = false;
      turboBtn.classList.remove("active");
      pauseScreen.classList.remove("hidden");
      pauseBtn.textContent = "▶";
    } else if (state === "paused") {
      resumeGame();
    }
  }

  function resumeGame() {
    if (state !== "paused") return;

    state = "playing";
    pauseScreen.classList.add("hidden");
    pauseBtn.textContent = "Ⅱ";
    lastTime = performance.now();
  }

  function endGame() {
    if (state !== "playing") return;

    state = "over";
    keys.left = false;
    keys.right = false;
    keys.turbo = false;
    turboBtn.classList.remove("active");

    const previousBest = best;

    if (score > best) {
      best = score;
      saveBest();
    }

    finalScoreDisplay.textContent = Math.floor(score).toLocaleString("fr-FR");
    recordMessage.textContent = score > previousBest
      ? "🏆 Nouveau record ! Félicitations !"
      : "Continue pour battre ton record !";

    gameOverScreen.classList.remove("hidden");
    updateHUD();
  }

  function updateHUD() {
    speedDisplay.textContent = Math.round(speed);
    scoreDisplay.textContent = Math.floor(score).toLocaleString("fr-FR");
    bestDisplay.textContent = best.toLocaleString("fr-FR");
  }

  function createCrashParticles() {
    const road = roadAt(0.88);
    const x = road.center + playerX * road.half * 0.82;
    const y = H * 0.82;

    for (let i = 0; i < 28; i++) {
      particles.push({
        x: x,
        y: y,
        vx: random(-150, 150),
        vy: random(-180, 100),
        size: random(2, 6),
        life: 1,
        color: Math.random() > 0.5 ? "#ffb52e" : "#ff4a35"
      });
    }
  }

  function update(dt) {
    if (state !== "playing") return;

    elapsed += dt;

    const turboOn = keys.turbo;
    const targetSpeed = turboOn ? 245 : 150;

    speed += (targetSpeed - speed) * Math.min(1, dt * 2.4);

    distance += speed * dt;
    roadOffset += speed * dt * 1.6;

    const steer = (keys.right ? 1 : 0) - (keys.left ? 1 : 0);
    playerX += steer * dt * (turboOn ? 1.45 : 1.15);
    playerX = clamp(playerX, -0.94, 0.94);

    score += speed * dt * 0.08;

    spawnTimer -= dt;

    const spawnInterval = Math.max(0.52, 1.15 - elapsed * 0.006);

    if (spawnTimer <= 0) {
      spawnTraffic();
      spawnTimer = spawnInterval;
    }

    for (const car of traffic) {
      car.t += dt * (0.15 + speed / 500 + car.speed);

      if (!car.passed && car.t > 0.88) {
        const laneDifference = Math.abs(playerX - car.lane * 0.61);

        if (laneDifference < 0.29) {
          createCrashParticles();
          endGame();
          break;
        }

        car.passed = true;
        score += 50;
      }
    }

    traffic = traffic.filter(car => car.t < 1.18);

    for (const p of particles) {
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.vy += 240 * dt;
      p.life -= dt * 1.7;
    }

    particles = particles.filter(p => p.life > 0);

    updateHUD();
  }

  function loop(timestamp) {
    if (!lastTime) lastTime = timestamp;

    // Évite les grands sauts après un changement d'application.
    const dt = Math.min((timestamp - lastTime) / 1000, 0.04);
    lastTime = timestamp;

    update(dt);
    draw();

    requestAnimationFrame(loop);
  }

  function setControl(name, value) {
    keys[name] = value;

    if (name === "turbo") {
      turboBtn.classList.toggle("active", value);
    }
  }

  function bindHoldButton(button, keyName) {
    button.addEventListener("pointerdown", (event) => {
      event.preventDefault();
      setControl(keyName, true);

      try {
        button.setPointerCapture(event.pointerId);
      } catch (e) {
        // Capture non nécessaire sur les navigateurs qui ne la prennent pas en charge.
      }
    });

    const release = (event) => {
      if (event) event.preventDefault();
      setControl(keyName, false);
    };

    button.addEventListener("pointerup", release);
    button.addEventListener("pointercancel", release);
    button.addEventListener("lostpointercapture", release);
    button.addEventListener("contextmenu", (event) => event.preventDefault());
  }

  startBtn.addEventListener("click", startGame);
  againBtn.addEventListener("click", startGame);
  restartBtn.addEventListener("click", startGame);
  pauseBtn.addEventListener("click", pauseGame);
  resumeBtn.addEventListener("click", resumeGame);

  bindHoldButton(leftBtn, "left");
  bindHoldButton(rightBtn, "right");
  bindHoldButton(turboBtn, "turbo");

  document.addEventListener("keydown", (event) => {
    const key = event.key.toLowerCase();

    if (["arrowleft", "arrowright", "arrowup", " ", "a", "d", "p", "escape"].includes(key)) {
      event.preventDefault();
    }

    if (key === "arrowleft" || key === "a") setControl("left", true);
    if (key === "arrowright" || key === "d") setControl("right", true);
    if (key === "arrowup" || key === " ") setControl("turbo", true);

    if ((key === "p" || key === "escape") && !event.repeat) {
      pauseGame();
    }

    if (key === "enter" && (state === "home" || state === "over")) {
      startGame();
    }
  });

  document.addEventListener("keyup", (event) => {
    const key = event.key.toLowerCase();

    if (key === "arrowleft" || key === "a") setControl("left", false);
    if (key === "arrowright" || key === "d") setControl("right", false);
    if (key === "arrowup" || key === " ") setControl("turbo", false);
  });

  window.addEventListener("blur", () => {
    keys.left = false;
    keys.right = false;
    keys.turbo = false;
    turboBtn.classList.remove("active");
  });

  document.addEventListener("visibilitychange", () => {
    if (document.hidden && state === "playing") {
      pauseGame();
    }
  });

  window.addEventListener("resize", resizeCanvas);

  // Initialisation et lancement permanent de la boucle de rendu.
  bestDisplay.textContent = best.toLocaleString("fr-FR");
  resetGame();
  resizeCanvas();
  requestAnimationFrame(loop);
})();
