# ULTRAMAN MEGA: THE RISING ALIEN — Android Project

This is an Android Studio project that packages the supplied HTML game
inside a local WebView.

## Requirements
- Android Studio
- Android SDK / Build Tools
- JDK compatible with Android Gradle Plugin 8.6.1

## Build
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Select `app`.
4. Build > Build APK(s).
5. The debug APK will be under:
   `app/build/outputs/apk/debug/`

## App behavior
- Landscape orientation is locked.
- Fullscreen immersive mode is enabled.
- The game is loaded from `app/src/main/assets/index.html`.
- No game assets are downloaded from the internet.
- JavaScript and DOM storage are enabled for the HTML game.

## Important
This project packages the current HTML version as-is. It does not turn
the Canvas game into native Android rendering; it uses Android WebView.
