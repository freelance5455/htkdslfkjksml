# iOS-Style Home Launcher (single-file bundle)

A simple Android HOME launcher built with Kotlin and Jetpack Compose.

## Features

- Real Android HOME activity with `ACTION_MAIN` + `CATEGORY_HOME`.
- Loads all launchable apps via `PackageManager`.
- 4 columns × 6 rows paged app grid.
- Fixed 4-app dock with translucent rounded background.
- System wallpaper behind the UI via `WallpaperManager`.
- Search pill + swipe-down search overlay.
- Long-press bottom sheet: App info, Uninstall (if allowed), Add/Remove dock.
- Default-launcher banner using `RoleManager` (API 29+), falling back to
  `Settings.ACTION_HOME_SETTINGS`.
- Light/dark theme follows system.
- No Apple trademarks, fonts, or copyrighted assets.

## Unpack this bundle

Save this file as `ios-launcher-project.md`, then run from the project root:

```bash
python3 - <<'PY'
import re, os
src = open("ios-launcher-project.md", encoding="utf-8").read()
# Grab everything between the outer ```markdown ... ``` fences
m = re.search(r"```markdown\n(.*)\n```", src, re.S)
body = m.group(1) if m else src
parts = re.split(r"^=== FILE: (.+?) ===$", body, flags=re.M)
# parts = [preamble, path1, content1, path2, content2, ...]
for i in range(1, len(parts), 2):
    path = parts[i].strip()
    content = parts[i+1].lstrip("\n")
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)
    print("wrote", path)
PY
```

Then:

```bash
gradle wrapper --gradle-version 8.14.3   # one-time, or open in Android Studio
./gradlew :app:assembleDebug
```

## Build

- JDK 17
- Android Studio (Narwhal or newer)
- AGP 8.13.2, Kotlin 2.3.10, Compose BOM 2026.08.00

## Set as default launcher

1. Launch the app once. A banner will appear: tap **Set**.
2. Or open **Settings → Apps → Default apps → Home app**, choose **Home**.

## Package visibility note

`QUERY_ALL_PACKAGES` is included for personal/sideloaded use. It is restricted
on Google Play. For Play Store distribution, remove it and rely on the
`<queries>` element plus any needed allowlists.