package com.example.ioslauncher.data

import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import com.example.ioslauncher.model.AppInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import java.util.concurrent.ConcurrentHashMap

class AppRepository(private val context: Context) {

    private val packageManager: PackageManager = context.packageManager
    private val iconCache = ConcurrentHashMap<String, ImageBitmap>()

    suspend fun loadApps(): List<AppInfo> = withContext(Dispatchers.IO) {
        val launcherIntent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }

        val resolveInfos = packageManager.queryIntentActivities(launcherIntent, 0)

        coroutineScope {
            resolveInfos
                .asSequence()
                .filter { it.activityInfo != null }
                .filter { it.activityInfo.packageName != context.packageName }
                .distinctBy { it.activityInfo.packageName }
                .map { resolveInfo ->
                    async {
                        val activityInfo = resolveInfo.activityInfo
                        if (activityInfo == null) null
                        else buildAppInfo(resolveInfo, activityInfo)
                    }
                }
                .toList()
                .awaitAll()
                .filterNotNull()
                .sortedBy { it.label.lowercase() }
        }
    }

    private fun buildAppInfo(
        resolveInfo: ResolveInfo,
        activityInfo: ActivityInfo
    ): AppInfo {
        val packageName = activityInfo.packageName
        val label = resolveInfo.loadLabel(packageManager).toString()
        val flags = activityInfo.applicationInfo.flags

        val canUninstall =
            (flags and ApplicationInfo.FLAG_SYSTEM) == 0 ||
                (flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0

        val icon = iconCache[packageName]
            ?: loadIcon(packageName)?.also { iconCache[packageName] = it }

        return AppInfo(
            packageName = packageName,
            label = label,
            icon = icon,
            canUninstall = canUninstall
        )
    }

    private fun loadIcon(packageName: String): ImageBitmap? {
        return try {
            packageManager
                .getApplicationIcon(packageName)
                .toBitmap(width = 144, height = 144)
                .asImageBitmap()
        } catch (_: Exception) {
            null
        }
    }
}


