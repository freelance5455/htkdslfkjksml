package com.example.ioslauncher

import android.app.role.RoleManager
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ioslauncher.ui.HomeScreen
import com.example.ioslauncher.ui.LauncherViewModel
import com.example.ioslauncher.ui.theme.LauncherTheme

class MainActivity : ComponentActivity() {

    private val viewModel: LauncherViewModel by viewModels()

    private val roleLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        viewModel.checkDefaultLauncher()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            LauncherTheme {
                val uiState by viewModel.uiState.collectAsStateWithLifecycle()

                HomeScreen(
                    uiState = uiState,
                    onLaunch = viewModel::launchApp,
                    onOpenAppInfo = viewModel::openAppInfo,
                    onUninstall = viewModel::uninstallApp,
                    onToggleDock = viewModel::toggleDock,
                    onSearchQueryChange = viewModel::onSearchQueryChange,
                    onRequestDefault = ::requestDefaultLauncher
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.checkDefaultLauncher()
    }

    private fun requestDefaultLauncher() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val roleManager = getSystemService(RoleManager::class.java)
            if (roleManager != null && roleManager.isRoleAvailable(RoleManager.ROLE_HOME)) {
                roleLauncher.launch(roleManager.createRequestRoleIntent(RoleManager.ROLE_HOME))
                return
            }
        }

        val homeSettingsIntent = Intent(Settings.ACTION_HOME_SETTINGS)
        if (homeSettingsIntent.resolveActivity(packageManager) != null) {
            startActivity(homeSettingsIntent)
        } else {
            startActivity(Intent(Settings.ACTION_SETTINGS))
        }
    }
}


