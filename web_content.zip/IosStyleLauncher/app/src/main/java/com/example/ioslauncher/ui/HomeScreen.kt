package com.example.ioslauncher.ui

import android.app.WallpaperManager
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import com.example.ioslauncher.model.AppInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.ceil
import kotlin.math.max

private const val ROWS = 6
private const val COLUMNS = 4
private const val APPS_PER_PAGE = ROWS * COLUMNS

@Composable
fun HomeScreen(
    uiState: LauncherUiState,
    onLaunch: (AppInfo) -> Unit,
    onOpenAppInfo: (AppInfo) -> Unit,
    onUninstall: (AppInfo) -> Unit,
    onToggleDock: (AppInfo) -> Unit,
    onSearchQueryChange: (String) -> Unit,
    onRequestDefault: () -> Unit
) {
    val context = LocalContext.current
    var searchVisible by rememberSaveable { mutableStateOf(false) }
    var selectedApp by remember { mutableStateOf<AppInfo?>(null) }

    val gridApps = remember(uiState.allApps, uiState.dockApps) {
        uiState.allApps.filter { app ->
            uiState.dockApps.none { it.packageName == app.packageName }
        }
    }

    val pageApps = remember(gridApps) { gridApps.chunked(APPS_PER_PAGE) }
    val pageCount = max(1, ceil(gridApps.size / APPS_PER_PAGE.toFloat()).toInt())
    val pagerState = rememberPagerState(pageCount = { pageCount })

    LaunchedEffect(pageCount) {
        if (pagerState.currentPage > pageCount - 1) {
            pagerState.scrollToPage(pageCount - 1)
        }
    }

    LaunchedEffect(uiState.error) {
        uiState.error?.let { msg ->
            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {

        WallpaperBackground()

        Column(
            modifier = Modifier
                .fillMaxSize()
                .systemBarsPadding()
        ) {
            if (!uiState.isDefaultLauncher) {
                DefaultLauncherBanner(onRequestDefault = onRequestDefault)
            }

            var dragAccumulator by remember { mutableFloatStateOf(0f) }

            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .pointerInput(Unit) {
                        detectVerticalDragGestures(
                            onDragEnd = {
                                if (dragAccumulator > 80f) searchVisible = true
                                dragAccumulator = 0f
                            },
                            onDragCancel = { dragAccumulator = 0f }
                        ) { change, dragAmount ->
                            if (dragAmount > 0f) dragAccumulator += dragAmount
                            change.consume()
                        }
                    }
            ) {
                HorizontalPager(
                    state = pagerState,
                    modifier = Modifier.fillMaxSize()
                ) { page ->
                    AppGridPage(
                        apps = pageApps.getOrElse(page) { emptyList() },
                        onLaunch = onLaunch,
                        onLongPress = { app -> selectedApp = app }
                    )
                }
            }

            PageIndicator(
                pageCount = pageCount,
                currentPage = pagerState.currentPage
            )

            SearchPill(onClick = { searchVisible = true })

            Dock(
                apps = uiState.dockApps,
                onLaunch = onLaunch,
                onLongPress = { app -> selectedApp = app }
            )
        }

        if (searchVisible) {
            SearchOverlay(
                allApps = uiState.allApps,
                query = uiState.searchQuery,
                onQueryChange = onSearchQueryChange,
                onLaunch = { app ->
                    onLaunch(app)
                    searchVisible = false
                    onSearchQueryChange("")
                },
                onDismiss = {
                    searchVisible = false
                    onSearchQueryChange("")
                }
            )
        }

        selectedApp?.let { app ->
            AppActionSheet(
                app = app,
                isInDock = uiState.dockApps.any { it.packageName == app.packageName },
                onDismiss = { selectedApp = null },
                onOpenAppInfo = {
                    onOpenAppInfo(app)
                    selectedApp = null
                },
                onUninstall = {
                    onUninstall(app)
                    selectedApp = null
                },
                onToggleDock = {
                    onToggleDock(app)
                    selectedApp = null
                }
            )
        }
    }
}

@Composable
private fun AppGridPage(
    apps: List<AppInfo>,
    onLaunch: (AppInfo) -> Unit,
    onLongPress: (AppInfo) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
        repeat(ROWS) { row ->
            Row(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                repeat(COLUMNS) { column ->
                    val index = row * COLUMNS + column
                    val app = apps.getOrNull(index)
                    Box(
                        modifier = Modifier.weight(1f),
                        contentAlignment = Alignment.Center
                    ) {
                        if (app != null) {
                            AppIcon(
                                app = app,
                                showLabel = true,
                                onClick = { onLaunch(app) },
                                onLongClick = { onLongPress(app) }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SearchPill(onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 56.dp, vertical = 6.dp)
            .height(36.dp)
            .background(
                color = Color.White.copy(alpha = 0.18f),
                shape = RoundedCornerShape(18.dp)
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = Icons.Default.Search,
            contentDescription = "Search",
            tint = Color.White.copy(alpha = 0.8f),
            modifier = Modifier.size(18.dp)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = "Search",
            color = Color.White.copy(alpha = 0.8f),
            fontSize = 14.sp
        )
    }
}

@Composable
private fun DefaultLauncherBanner(onRequestDefault: () -> Unit) {
    Surface(
        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.92f),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Set as default home",
                modifier = Modifier.weight(1f),
                style = MaterialTheme.typography.bodyMedium
            )
            TextButton(onClick = onRequestDefault) {
                Text("Set")
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AppActionSheet(
    app: AppInfo,
    isInDock: Boolean,
    onDismiss: () -> Unit,
    onOpenAppInfo: () -> Unit,
    onUninstall: () -> Unit,
    onToggleDock: () -> Unit
) {
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 24.dp, vertical = 16.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                AppIconImage(app = app, size = 48.dp)
                Spacer(modifier = Modifier.width(12.dp))
                Text(
                    text = app.label,
                    style = MaterialTheme.typography.titleMedium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            SheetAction(text = "App info", onClick = onOpenAppInfo)
            if (app.canUninstall) {
                SheetAction(text = "Uninstall", onClick = onUninstall)
            }
            SheetAction(
                text = if (isInDock) "Remove from dock" else "Add to dock",
                onClick = onToggleDock
            )

            Spacer(modifier = Modifier.height(8.dp))
        }
    }
}

@Composable
private fun SheetAction(text: String, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = text, style = MaterialTheme.typography.bodyLarge)
    }
}

@Composable
private fun WallpaperBackground() {
    val context = LocalContext.current

    val wallpaper by produceState<ImageBitmap?>(initialValue = null) {
        value = withContext(Dispatchers.IO) {
            try {
                WallpaperManager.getInstance(context)
                    .drawable
                    ?.toBitmap()
                    ?.asImageBitmap()
            } catch (_: Exception) {
                null
            }
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        wallpaper?.let { bitmap ->
            Image(
                bitmap = bitmap,
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
        } ?: Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(Color(0xFF1C1C2E), Color(0xFF0B0B12))
                    )
                )
        )

        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.15f))
        )
    }
}


