package com.example.ioslauncher.ui

import android.app.Application
import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ioslauncher.data.AppRepository
import com.example.ioslauncher.model.AppInfo
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class LauncherUiState(
    val allApps: List<AppInfo> = emptyList(),
    val dockApps: List<AppInfo> = emptyList(),
    val isLoading: Boolean = true,
    val isDefaultLauncher: Boolean = false,
    val searchQuery: String = "",
    val error: String? = null
)

class LauncherViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = AppRepository(application)
    private val prefs = application.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    private val _uiState = MutableStateFlow(LauncherUiState())
    val uiState: StateFlow<LauncherUiState> = _uiState.asStateFlow()

    init {
        refreshApps()
        checkDefaultLauncher()
    }

    fun refreshApps() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null) }
            try {
                val apps = repository.loadApps()
                val savedDock = loadDockPackages()
                val dockInitialized = prefs.getBoolean(KEY_DOCK_INITIALIZED, false)

                val dockPackages = if (!dockInitialized) {
                    apps.take(DOCK_SIZE).map { it.packageName }.also { packages ->
                        saveDockPackages(packages)
                        prefs.edit().putBoolean(KEY_DOCK_INITIALIZED, true).apply()
                    }
                } else {
                    savedDock.filter { p -> apps.any { it.packageName == p } }
                }

                val dockApps = dockPackages.mapNotNull { p ->
                    apps.firstOrNull { it.packageName == p }
                }

                _uiState.update {
                    it.copy(allApps = apps, dockApps = dockApps, isLoading = false)
                }
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(isLoading = false, error = e.message ?: "Unable to load installed apps")
                }
            }
        }
    }

    fun checkDefaultLauncher() {
        _uiState.update { it.copy(isDefaultLauncher = isDefaultLauncher()) }
    }

    fun toggleDock(app: AppInfo) {
        val current = _uiState.value.dockApps
        val updated = if (current.any { it.packageName == app.packageName }) {
            current.filterNot { it.packageName == app.packageName }
        } else {
            if (current.size >= DOCK_SIZE) return
            current + app
        }
        saveDockPackages(updated.map { it.packageName })
        _uiState.update { it.copy(dockApps = updated) }
    }

    fun launchApp(app: AppInfo) {
        val context = getApplication<Application>()
        val intent = context.packageManager.getLaunchIntentForPackage(app.packageName)
        if (intent == null) {
            _uiState.update { it.copy(error = "No launch intent for ${app.label}") }
            return
        }
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            context.startActivity(intent)
        } catch (e: Exception) {
            _uiState.update { it.copy(error = e.message ?: "Unable to launch ${app.label}") }
        }
    }

    fun openAppInfo(app: AppInfo) {
        val context = getApplication<Application>()
        val intent = Intent(
            Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
            Uri.parse("package:${app.packageName}")
        ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            context.startActivity(intent)
        } catch (e: Exception) {
            _uiState.update { it.copy(error = e.message ?: "Unable to open app info") }
        }
    }

    fun uninstallApp(app: AppInfo) {
        val context = getApplication<Application>()
        val intent = Intent(
            Intent.ACTION_DELETE,
            Uri.parse("package:${app.packageName}")
        ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            context.startActivity(intent)
        } catch (e: Exception) {
            _uiState.update { it.copy(error = e.message ?: "Unable to uninstall ${app.label}") }
        }
    }

    fun onSearchQueryChange(query: String) {
        _uiState.update { it.copy(searchQuery = query) }
    }

    private fun isDefaultLauncher(): Boolean {
        val context = getApplication<Application>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val rm = context.getSystemService(RoleManager::class.java)
            if (rm != null && rm.isRoleAvailable(RoleManager.ROLE_HOME)) {
                return rm.isRoleHeld(RoleManager.ROLE_HOME)
            }
        }
        val homeIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        val resolveInfo = context.packageManager.resolveActivity(
            homeIntent, PackageManager.MATCH_DEFAULT_ONLY
        )
        return resolveInfo?.activityInfo?.packageName == context.packageName
    }

    private fun loadDockPackages(): List<String> {
        val raw = prefs.getString(KEY_DOCK_PACKAGES, null) ?: return emptyList()
        if (raw.isBlank()) return emptyList()
        return raw.split(SEPARATOR)
    }

    private fun saveDockPackages(packages: List<String>) {
        prefs.edit()
            .putString(KEY_DOCK_PACKAGES, packages.joinToString(SEPARATOR))
            .apply()
    }

    companion object {
        private const val PREFS_NAME = "launcher_prefs"
        private const val KEY_DOCK_PACKAGES = "dock_packages"
        private const val KEY_DOCK_INITIALIZED = "dock_initialized"
        private const val SEPARATOR = "|"
        private const val DOCK_SIZE = 4
    }
}


