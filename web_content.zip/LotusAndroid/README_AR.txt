تطبيق لوتس - مشروع Android

هذا المشروع يحول نسخة HTML/CSS/JavaScript الخاصة بلوتس إلى تطبيق Android باستخدام WebView.

للبناء على الهاتف:
1) فك ضغط LotusAndroid.zip.
2) افتح المجلد في بيئة Android/Gradle تدعم Android Gradle Plugin 8.6.1.
3) نفّذ Gradle task: :app:assembleDebug
4) ستجد APK في: app/build/outputs/apk/debug/app-debug.apk

اسم التطبيق: لوتس
Application ID: com.lotus.market
