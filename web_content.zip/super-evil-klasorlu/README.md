# SUPER EVIL — klasörlü kaynak

**Direkt oynamak için:** `super-kahraman.html` dosyasını aç (iPad/Safari dahil, tek dosya, internet gerekir: three.js CDN).

## Klasörler (`js/`)
| Klasör | İçindekiler |
|---|---|
| `cekirdek/` | oyun çekirdeği, olay sistemi, ayarlar, fizik, gökyüzü/mevsim, ana döngü (`main.js`), `entermode.js` |
| `sehir/` | şehir üretimi (cg_*, world_*, types_*), bölgeler, köprü, ağaçlar, iç mekân, asansör, haritalar |
| `yikim/` | yıkım, yeniden inşa, enkaz, parçalar, rüzgâr türbini |
| `npc/` | insanlar (npc, npclife), konuşma, acil durum, polis, gore, uzay insanları |
| `hikaye/` | hikâye modu, Mısır adası, ejderha dağı + ejderha, UFO, uzay/ay, deniz |
| `karakter/` | karakter modelleri (chars, vipkit, vipchars_a-d: VIP/Mythic/ALTIN Mega/Neon Ejderha), animasyon, menü 3B |
| `guc/` | güçler (yumruk, lazer, ateş, dondurma, mythic, **lavabreath.js** = Neon Ejderha lav nefesi) |
| `arac/` | arabalar, trafik, sürüş |
| `ses/` | ses motoru (audio, audio2, audio3) |
| `efekt/` | parçacık efektleri |
| `arayuz/` | menü, mağaza, profil, başarımlar/unvanlar, ekonomi, reklam, ayarlar |
| `dil/` | 13 dilin çeviri dosyaları |
| `css/` | stil dosyaları |

## Çalıştırma / derleme
- Geliştirme: klasörde `python3 -m http.server` → tarayıcıda `index.html` (dosyalar `yukleme_sirasi.txt` sırasıyla yüklenir).
- **Sıra önemlidir** (klasik script'ler aynı global alanı paylaşır). Yeni dosya eklerken `yukleme_sirasi.txt` ve `index.html` içindeki sıraya ekle.
- Tek dosyaya derle: `python3 build_single.py` → `super-kahraman.html`.
