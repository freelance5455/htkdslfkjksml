"use strict";
/* ===== MYTHIC GÜÇLER: Zaman Durdur (Kronos) · Ruh Hasadı (Nekro) · Gezegen Çarpması (Kozmos) · Mor Alev Nefesi · Mor Cehennem Sütunları =====
   Mor ateş animasyonlu güçler: violet, hellfire. Sahiplik: Game.Premium.hasPower (kostüm satın alınca kendi gücü gelir; violet/hellfire coin ile). */
(function(){
const A=Game.input.actions, H=Game.H, hero=Game.heroObj, D=Game.D, NPC=Game.NPC, Cars=Game.Cars, FX=Game.FX, P=Game.P, U=Game.U, W=Game.W, au=()=>Game.audio, rs=U.rs, PR=()=>Game.Premium;
const IDS=["chrono","reap","planet","violet","hellfire"], CD={chrono:55,reap:50,planet:45,violet:30,hellfire:38}, cd={chrono:0,reap:0,planet:0,violet:0,hellfire:0}, prev={}, btn={}, wrap={};
const TAU=Math.PI*2, R=(a,b)=>a+Math.random()*(b-a), AD=THREE.AdditiveBlending, V3=THREE.Vector3;
const gY=(x,z)=>Math.max(W.WATER_Y,W.terrainH?W.terrainH(x,z):W.surfaceAt(x,z,60));
const npcPos=n=>n.body?n.body.position:{x:n.x,y:n.y+.95*(NPC.scale||1.3),z:n.z};
/* mor ateş parçacıkları */
const PF=(x,y,z,vx,vy,vz,life,s0,s1,al,gr)=>FX.E(true,x,y,z,vx,vy,vz,life,s0,s1,[1,.86,1],[.45,.07,.9],al==null?.85:al,gr==null?-1.4:gr,.95);
const PW=(x,y,z,vx,vy,vz,life,s0,s1,al)=>FX.E(true,x,y,z,vx,vy,vz,life,s0,s1,[.95,.7,1],[.6,.2,1],al==null?.8:al,0,.97);
const PS=(x,y,z,vx,vy,vz,life,s0,s1)=>FX.E(false,x,y,z,vx,vy,vz,life,s0,s1,[.18,.05,.32],[.06,.02,.12],.5,-.3,.98);
function shakeNear(x,y,z,amt,range){ const d=Math.hypot(x-hero.position.x,y-hero.position.y,z-hero.position.z); if(d<range) Game.shakeAdd(amt*(1-d/range)); }
function canvasTex(w,h,fn){ const c=document.createElement("canvas"); c.width=w; c.height=h; fn(c.getContext("2d"),w,h); return new THREE.CanvasTexture(c); }
function mkRing(col,op){ const m=new THREE.Mesh(new THREE.TorusGeometry(1,.035,6,48),new THREE.MeshBasicMaterial({color:col,transparent:true,opacity:op||1,depthWrite:false,blending:AD})); m.rotation.x=Math.PI/2; m.visible=false; m.frustumCulled=false; scene.add(m); return m; }
function aim(maxL){ const c=camera.position, L=Game.lookV; const r=D.ray(c.x,c.y,c.z,L.x,L.y,L.z,maxL||260); if(r.kind==="none"){ const p=hero.position, fx=Game.heroFwd.x, fz=Game.heroFwd.z, x=p.x+fx*55, z=p.z+fz*55; r.x=x; r.z=z; r.y=W.surfaceAt(x,z,p.y); r.kind="ground"; r.fake=true; } return r; }
function igniteSphere(x,y,z,r,chance){ for(const e of Game.buildings){ const t=e.tier; if(!t||e.h<=0) continue; if(Math.hypot(e.x-x,e.z-z)>r+Math.max(e.hw,e.hd)) continue; for(const c of t.chunks){ if(!c.alive||Math.random()>chance) continue; if(Math.hypot(c.x-x,c.y-y,c.z-z)<r) D.ignite(c); } } }
let fxEl=null;
function flash(op,dur,col){ try{ if(!fxEl){ fxEl=document.getElementById("novaFx"); if(!fxEl){ fxEl=document.createElement("div"); fxEl.id="novaFx"; document.body.appendChild(fxEl); } } fxEl.style.background=col||"radial-gradient(circle at 50% 50%,#fff 0%,#f1c8ff 35%,#8a2cff 80%)"; fxEl.style.transition="none"; fxEl.style.opacity=op; void fxEl.offsetWidth; fxEl.style.transition="opacity "+dur+"s ease-out"; fxEl.style.opacity=0; }catch(e){} }
function cdUI(n){ const b=btn[n]||(btn[n]=document.querySelector('.act[data-act="'+n+'"]')); if(!b) return; const f=Math.max(0,cd[n]/CD[n]); b.style.setProperty("--cd",f.toFixed(3)); b.classList.toggle("cd",f>0); const w=wrap[n]||(wrap[n]=b.parentNode); if(w&&w.classList) w.classList.toggle("cd",f>0); }
function setOn(n,on){ const b=btn[n]||(btn[n]=document.querySelector('.act[data-act="'+n+'"]')); const w=b&&(wrap[n]||(wrap[n]=b.parentNode)); if(w&&w.classList) w.classList.toggle("on",!!on); }
const api=Game.Mythic={IDS,CD,cd,breathing:false,active:()=>CH.on||RP.on||PL.ph>0||VB.on||HF.on};

/* ================= ZAMAN DURDUR (Kronos) ================= */
const CH={on:false,t:0,dur:8,ph:0}; let chRing=null,chRing2=null,chEl=null;
function castChrono(){ cd.chrono=CD.chrono; CH.on=true; CH.t=0; CH.ph=0; Game.tsTarget=.012; Game.act("timeslow",1.6);
  chEl=chEl||document.getElementById("slowFx"); if(chEl){ chEl.classList.add("on"); chEl.classList.add("chrono"); } if(au()&&au().slow) au().slow(true);
  chRing=chRing||mkRing(0xffe08a,.95); chRing2=chRing2||mkRing(0xb98bff,.8); chRing.visible=chRing2.visible=true; flash(.55,.9,"radial-gradient(circle at 50% 50%,#fff6d0 0%,#caa6ff 55%,#3a1580 100%)"); Game.shakeAdd(.5);
  const p=hero.position; for(let i=0;i<48;i++){ const a=i/48*TAU; PW(p.x+Math.cos(a)*2,p.y,p.z+Math.sin(a)*2,Math.cos(a)*10,R(-1,3),Math.sin(a)*10,1.2,.9,.4,.9); } }
function endChrono(quiet){ if(!CH.on) return; CH.on=false; Game.tsTarget=1; if(chEl){ chEl.classList.remove("on"); chEl.classList.remove("chrono"); } if(au()&&au().slow) au().slow(false);
  if(chRing) chRing.visible=chRing2.visible=false; if(quiet) return; const p=hero.position; flash(.4,.7,"radial-gradient(circle at 50% 50%,#fff 0%,#e7d3ff 45%,#6a2cd0 100%)"); if(au()) au().boom(p.x,p.y,p.z); Game.shakeAdd(1.1);
  for(let i=0;i<60;i++){ const a=i/60*TAU; PW(p.x,p.y+.5,p.z,Math.cos(a)*30,R(-1,4),Math.sin(a)*30,.9,1.2,.5,.9); } }
function updChrono(raw){ if(!CH.on) return; CH.t+=raw; const t=CH.t, p=hero.position;
  if(Game.tsTarget>.012) Game.tsTarget=.012;
  const k=Math.min(1,t/.8), e=1-Math.pow(1-k,3), r1=4+130*e, f=t<.8?1-k*.9:.1+.1*Math.sin(t*5);
  chRing.position.set(p.x,gY(p.x,p.z)+.5,p.z); chRing2.position.copy(chRing.position); chRing.scale.set(r1,r1,1); chRing2.scale.set(r1*.82,r1*.82,1); chRing.material.opacity=f; chRing2.material.opacity=f*.8; chRing.rotation.z+=raw*.9; chRing2.rotation.z-=raw*1.3;
  if(t<.8===false){ chRing.visible=chRing2.visible=false; }
  /* donmuş zamanda asılı kalan altın tozlar (zaman yavaşken parçacık da yavaş) */
  for(let i=0;i<3;i++){ const a=Math.random()*TAU, d=R(5,60); PW(p.x+Math.cos(a)*d,p.y+R(-2,16),p.z+Math.sin(a)*d,0,R(.2,1.2),0,R(2.5,5),R(.5,1),.1,.75); }
  if(t>=CH.dur-1.2&&t<CH.dur-1.2+raw*1.5&&au()&&au().slow) au().slow(false);
  if(t>=CH.dur) endChrono(); }

/* ================= RUH HASADI (Nekro) ================= */
const RP={on:false,t:0,x:0,z:0,id:0,souls:[]}; let rpRing=null,rpRing2=null; const RPR=88, RPT=1.5;
function castReap(){ cd.reap=CD.reap; RP.on=true; RP.t=0; RP.id++; RP.x=hero.position.x; RP.z=hero.position.z; Game.act("lightning",1.3);
  rpRing=rpRing||mkRing(0xb44cff,.95); rpRing2=rpRing2||mkRing(0xf0d0ff,.7); rpRing.visible=rpRing2.visible=true; flash(.4,.9,"radial-gradient(circle at 50% 50%,#1a0638 0%,#6a1fd0 60%,#d9a8ff 100%)"); if(au()){ au().boom(RP.x,hero.position.y,RP.z); if(au().spirit) au().spirit(RP.x,hero.position.y,RP.z); } Game.shakeAdd(.8); }
function spawnSoul(x,y,z){ if(RP.souls.length>70) return; RP.souls.push({x,y,z,vx:R(-3,3),vy:R(5,9),vz:R(-3,3),t:0,tt:R(.45,.95)}); }
function updReap(dt,raw){ const hp=hero.position;
  if(RP.on){ RP.t+=dt; const k=Math.min(1,RP.t/RPT), Rr=8+RPR*k*(2-k), y=gY(RP.x,RP.z)+.5;
    rpRing.position.set(RP.x,y,RP.z); rpRing2.position.copy(rpRing.position); rpRing.scale.set(Rr,Rr,1); rpRing2.scale.set(Rr*.9,Rr*.9,1); rpRing.material.opacity=.95*(1-k*.7); rpRing2.material.opacity=.7*(1-k); rpRing.rotation.z+=dt*2; rpRing2.rotation.z-=dt*2.6;
    for(let i=0;i<26;i++){ const a=Math.random()*TAU; PF(RP.x+Math.cos(a)*Rr,y+.3,RP.z+Math.sin(a)*Rr,0,R(5,13),0,R(.6,1.1),R(1.2,2),.2,.9,-1); }
    for(const n of NPC.list){ if(!n.vis||n.st==="gone"||n._rp===RP.id) continue; const p=npcPos(n); if(Math.hypot(p.x-RP.x,p.z-RP.z)>Rr) continue; n._rp=RP.id;
      if(n.dead){ spawnSoul(p.x,p.y+.8,p.z); PW(p.x,p.y+.5,p.z,0,3,0,.6,2,.3); NPC.vanish(n); continue; }
      NPC.hit(n,0,4,0,"soul"); NPC.hurt(n,2,"soul"); spawnSoul(p.x,p.y+1,p.z); PW(p.x,p.y+.8,p.z,0,2,0,.5,2.4,.3); }
    shakeNear(RP.x,y,RP.z,.25*(1-k),90);
    if(RP.t>=RPT){ RP.on=false; rpRing.visible=rpRing2.visible=false; } }
  /* ruhlar: yükselir, sonra kahramana akar */
  for(let i=RP.souls.length-1;i>=0;i--){ const s=RP.souls[i]; s.t+=dt;
    if(s.t<s.tt){ s.vy*=.985; s.x+=s.vx*dt; s.y+=s.vy*dt; s.z+=s.vz*dt; }
    else { const tx=hp.x, ty=hp.y+1.3, tz=hp.z, dx=tx-s.x, dy=ty-s.y, dz=tz-s.z, d=Math.hypot(dx,dy,dz)||1, sp=Math.min(95,30+(s.t-s.tt)*140), ax=dx/d*sp, ay=dy/d*sp, az=dz/d*sp, k=1-Math.exp(-dt*9);
      s.vx+=(ax-s.vx)*k; s.vy+=(ay-s.vy)*k; s.vz+=(az-s.vz)*k; s.x+=s.vx*dt; s.y+=s.vy*dt; s.z+=s.vz*dt;
      if(d<1.8||s.t>s.tt+3.5){ RP.souls.splice(i,1); PW(tx,ty,tz,R(-2,2),R(-1,3),R(-2,2),.5,2,.4,.9); if(Game.Hp&&Game.Hp.heal) Game.Hp.heal(4); continue; } }
    PW(s.x+R(-.15,.15),s.y+R(-.15,.15),s.z+R(-.15,.15),R(-.5,.5),R(-.5,.5),R(-.5,.5),R(.35,.6),1.3,.2,.9); FX.E(true,s.x,s.y,s.z,0,0,0,.2,.9,.5,[1,1,1],[.9,.7,1],.9,0,1); } }

/* ================= GEZEGEN ÇARPMASI (Kozmos) ================= */
const PL={ph:0,t:0,x:0,y:0,z:0,sx:0,sy:0,sz:0,hit:0,id:0,Rr:0,cars:new Set(),fall:2.7}; let plG=null,plBody=null,plRing3=null,plGlow=null,plTg=null,plTg2=null,plShock=null; const PLR=21;
function ensurePL(){ if(plG) return; plG=new THREE.Group(); plG.visible=false;
  const tex=canvasTex(512,256,(q,w,h)=>{ const g=q.createLinearGradient(0,0,0,h); g.addColorStop(0,"#2a0f6a"); g.addColorStop(.5,"#7a2cc8"); g.addColorStop(1,"#3a1480"); q.fillStyle=g; q.fillRect(0,0,w,h);
    const cols=["#ff7ad9","#ffd36a","#b98bff","#5a2aa8","#ff9be8","#2a0f6a"]; for(let i=0;i<46;i++){ const y=Math.random()*h, th=4+Math.random()*20; q.fillStyle=cols[(Math.random()*cols.length)|0]; q.globalAlpha=.25+Math.random()*.4; q.beginPath(); q.moveTo(0,y); for(let x=0;x<=w;x+=32) q.lineTo(x,y+Math.sin(x*.03+i)*5); for(let x=w;x>=0;x-=32) q.lineTo(x,y+th+Math.sin(x*.025+i*2)*5); q.fill(); }
    q.globalAlpha=1; for(let i=0;i<5;i++){ const x=Math.random()*w, y=h*(.25+Math.random()*.5), r=14+Math.random()*26, rg=q.createRadialGradient(x,y,0,x,y,r); rg.addColorStop(0,"rgba(255,230,250,.55)"); rg.addColorStop(1,"rgba(120,40,200,0)"); q.fillStyle=rg; q.fillRect(x-r,y-r,r*2,r*2); } });
  plBody=new THREE.Mesh(new THREE.SphereGeometry(1,28,20),new THREE.MeshBasicMaterial({map:tex,color:0xffffff})); plBody.frustumCulled=false; plG.add(plBody);
  const rt=canvasTex(256,256,(q,w,h)=>{ const cx=w/2; for(let i=0;i<60;i++){ const r=cx*(.62+i/60*.38), a=.2+Math.random()*.5; q.strokeStyle=i%7<3?"rgba(255,220,140,"+a+")":"rgba(220,170,255,"+a+")"; q.lineWidth=1.4+Math.random()*2.4; q.beginPath(); q.arc(cx,cx,r*.98,0,TAU); q.stroke(); } });
  plRing3=new THREE.Mesh(new THREE.PlaneGeometry(2,2),new THREE.MeshBasicMaterial({map:rt,transparent:true,depthWrite:false,side:THREE.DoubleSide,blending:AD})); plRing3.rotation.x=-Math.PI/2+.5; plRing3.scale.setScalar(2.6); plRing3.frustumCulled=false; plG.add(plRing3);
  const gl=canvasTex(128,128,(q,w,h)=>{ const g=q.createRadialGradient(64,64,10,64,64,64); g.addColorStop(0,"rgba(255,200,255,.9)"); g.addColorStop(.4,"rgba(160,70,255,.45)"); g.addColorStop(1,"rgba(80,20,200,0)"); q.fillStyle=g; q.fillRect(0,0,w,h); });
  plGlow=new THREE.Sprite(new THREE.SpriteMaterial({map:gl,transparent:true,blending:AD,depthWrite:false})); plGlow.scale.setScalar(4); plGlow.frustumCulled=false; plG.add(plGlow);
  scene.add(plG); plTg=mkRing(0xff7ae0,.9); plTg2=mkRing(0xffe08a,.8); plShock=mkRing(0xe9c4ff,.95); }
function castPlanet(){ cd.planet=CD.planet; ensurePL(); const r=aim(340), f=Game.heroFwd, l=Math.hypot(f.x,f.z)||1; PL.ph=1; PL.t=0; PL.x=r.x; PL.z=r.z; PL.y=Math.max(r.y,gY(r.x,r.z)); PL.id++; PL.cars.clear(); PL.hit=0;
  PL.sx=PL.x-f.x/l*150; PL.sz=PL.z-f.z/l*150; PL.sy=PL.y+330; Game.act("meteor",1.6); if(au()) au().whoosh(); NPC.alert(PL.x,PL.z,170,PL.x,PL.z); flash(.2,.5,"#3a1480"); }
function updPlanet(dt){ if(!PL.ph) return; ensurePL(); PL.t+=dt; const t=PL.t;
  if(PL.ph===1){ const u=Math.min(1,t/PL.fall), e=Math.pow(u,2.1), x=PL.sx+(PL.x-PL.sx)*e, y=PL.sy+(PL.y+PLR*.5-PL.sy)*e, z=PL.sz+(PL.z-PL.sz)*e, sc=PLR*(.55+.45*e);
    plG.visible=true; plG.position.set(x,y,z); plBody.scale.setScalar(sc); plBody.rotation.y+=dt*.8; plRing3.scale.setScalar(sc*2.6); plRing3.rotation.z+=dt*.25; plGlow.scale.setScalar(sc*5); plGlow.material.opacity=.7+.3*Math.sin(t*14);
    const ty=PL.y+.4, ts=44-30*u+Math.sin(t*16)*1.5; plTg.visible=plTg2.visible=true; plTg.position.set(PL.x,ty,PL.z); plTg2.position.copy(plTg.position); plTg.scale.set(ts,ts,1); plTg2.scale.set(ts*.55,ts*.55,1); plTg.rotation.z+=dt*3; plTg2.rotation.z-=dt*4; plTg.material.opacity=.55+.4*Math.sin(t*18); plTg2.material.opacity=.5+.35*Math.sin(t*18+1.5);
    const dx=PL.x-PL.sx, dz=PL.z-PL.sz, dy=PL.y-PL.sy, dl=Math.hypot(dx,dy,dz)||1;
    for(let i=0;i<14;i++){ const a=Math.random()*TAU, b=Math.random()*Math.PI-1.57, q=sc*R(.5,1.1); PF(x+Math.cos(a)*Math.cos(b)*q-dx/dl*sc*R(.2,1.6),y+Math.sin(b)*q-dy/dl*sc*R(.2,1.6),z+Math.sin(a)*Math.cos(b)*q-dz/dl*sc*R(.2,1.6),-dx/dl*R(20,50),-dy/dl*R(20,50),-dz/dl*R(20,50),R(.5,1.1),R(3,6)*(.5+e),R(.5,1),.8,0); }
    if(Math.random()<.5) PS(x-dx/dl*sc,y-dy/dl*sc,z-dz/dl*sc,0,0,0,1.6,sc*.3,sc*.9);
    shakeNear(PL.x,PL.y,PL.z,.25*u*u,260);
    if(u>=1){ PL.ph=2; PL.t=0; PL.hit=0; PL.Rr=0; plG.visible=false; plTg.visible=plTg2.visible=false; const x2=PL.x, y2=PL.y, z2=PL.z;
      if(au()){ au().boom(x2,y2,z2); au().crash&&au().crash(x2,y2,z2); } flash(.9,1.4,"radial-gradient(circle at 50% 50%,#fff 0%,#f1c8ff 30%,#8a2cff 85%)"); Game.shakeAdd(2.4);
      D.damageSphere(x2,y2+3,z2,48,3,80,true); Game.radial(x2,y2,z2,150,76,"boom"); igniteSphere(x2,y2+8,z2,48,.4);
      for(let i=0;i<110;i++){ const a=Math.random()*TAU, v=R(14,60); PF(x2,y2+R(0,6),z2,Math.cos(a)*v,R(8,48),Math.sin(a)*v,R(.8,1.8),R(2.5,6),R(.4,1.4),.9,5); }
      FX.shock(x2,y2+1,z2,80,60); FX.dust(x2,y2+1,z2,70,34); FX.fire(x2,y2,z2,50,0,8,0,5); FX.glow(x2,y2+8,z2,70,[.95,.7,1],.4); } return; }
  const T2=2.1, k=Math.min(1,t/T2), e=1-Math.pow(1-k,2.3), Rr=e*165, fade=1-k, x=PL.x, y=PL.y, z=PL.z; PL.Rr=Rr;
  plShock.visible=true; plShock.position.set(x,y+.5,z); plShock.scale.set(Rr+.1,Rr+.1,1); plShock.material.opacity=.9*fade;
  for(let i=0;i<24;i++){ const a=Math.random()*TAU; PF(x+Math.cos(a)*Rr*R(.94,1),y+R(.5,7),z+Math.sin(a)*Rr*R(.94,1),Math.cos(a)*18,R(2,12),Math.sin(a)*18,R(.5,1),R(3,6),.5,.8,3); }
  if(Math.random()<.6){ const a=Math.random()*TAU; PS(x+Math.cos(a)*Rr*.9,y+3,z+Math.sin(a)*Rr*.9,Math.cos(a)*14,R(3,10),Math.sin(a)*14,2.2,4,10); }
  PL.hit-=dt; if(PL.hit<=0){ PL.hit=.09; D.damageSphere(x,y+4,z,Math.min(70,Rr),2.2*(1-e*.55),50,true); }
  for(const n of NPC.list){ if(!n.vis||n.st==="gone"||n.plId===PL.id) continue; const p=npcPos(n), dx=p.x-x, dz=p.z-z, d=Math.hypot(dx,dz); if(d>Rr) continue; n.plId=PL.id; const l=d||1; NPC.hit(n,dx/l*56,20,dz/l*56,"boom"); if(n.vis) NPC.char(n); }
  Cars.query(x,z,Rr,(kd,i,px,pz)=>{ const key=kd+i; if(PL.cars.has(key)) return; PL.cars.add(key); const dx=px-x, dz=pz-z, l=Math.hypot(dx,dz)||1; Cars.hit(kd,i,dx/l*46,17,dz/l*46,7); Cars.burn(kd,i); });
  shakeNear(x,y,z,.7*fade,320);
  if(t>=T2){ PL.ph=0; plShock.visible=false; } }

/* ================= MOR ALEV NEFESİ (mor ateş) ================= */
const VB={on:false,t:0,dur:6,hit:0}; const mouth=new V3(), pt=new V3();
function inCone(p,o,L,range,th,pad){ const dx=p.x-o.x, dy=p.y-o.y, dz=p.z-o.z, t=dx*L.x+dy*L.y+dz*L.z; if(t<-pad||t>range+pad) return false; const px=dx-L.x*t, py=dy-L.y*t, pz=dz-L.z*t, r=Math.hypot(px,py,pz); return r<=pad+Math.max(0,t)*th; }
function castViolet(){ cd.violet=CD.violet; VB.on=true; VB.t=0; VB.hit=0; api.breathing=true; Game.act("lightning",.5); if(au()){ au().whoosh(); au().loop("fire",true); } flash(.25,.5,"radial-gradient(circle,#fff0ff 0%,#8a2cff 100%)"); setOn("violet",true); }
function endViolet(){ if(!VB.on) return; VB.on=false; api.breathing=false; if(au()) au().loop("fire",false); setOn("violet",false); }
function updViolet(dt){ if(!VB.on) return; VB.t+=dt; const L=Game.lookV, range=34, th=.34; mouth.set(hero.position.x,hero.position.y+.5,hero.position.z).addScaledVector(L,1.4); if(Game.settings.cam==="1p"){ mouth.copy(camera.position).addScaledVector(L,1.2); mouth.y-=.35; }
  for(let i=0;i<12;i++){ const sp=24+Math.random()*12, jx=rs()*th*sp*1.1, jy=rs()*th*sp*1.1, jz=rs()*th*sp*1.1;
    PF(mouth.x,mouth.y,mouth.z,L.x*sp+jx+H.vel.x*.5,L.y*sp+jy+H.vel.y*.5,L.z*sp+jz+H.vel.z*.5,R(.5,1.1),R(.9,1.5),R(2.4,4.4),.88,-1.2); }
  if(Math.random()<.6) PS(mouth.x+L.x*8,mouth.y+L.y*8+1,mouth.z+L.z*8,L.x*6+rs()*3,2+Math.random()*3,L.z*6+rs()*3,1.8,1.6,5);
  if(Math.random()<.5) FX.spark(mouth.x+L.x*R(4,24),mouth.y+L.y*R(4,24),mouth.z+L.z*R(4,24),1,8,[.9,.6,1]);
  VB.hit-=dt; const doHit=VB.hit<=0; if(doHit) VB.hit=.12;
  for(const n of NPC.list){ if(!n.vis||n.dead&&!n.body) continue; const p=npcPos(n); if(!inCone(p,mouth,L,range,th,1.5)) continue; NPC.burn(n); if(doHit&&!n.dead){ n.vbt=(n.vbt||0)+.12; if(n.vbt>.9){ n.vbt=0; NPC.hit(n,L.x*8,6,L.z*8,"boom"); } } }
  if(doHit){ Cars.query(mouth.x,mouth.z,range+3,(k,i,px,pz)=>{ pt.set(px,.9,pz); if(inCone(pt,mouth,L,range,th,2.6)){ Cars.burn(k,i); } });
    if(Game.Sea) Game.Sea.breath(mouth.x,mouth.y,mouth.z,L,range,th,true,.12);
    for(const e of Game.buildings){ const t=e.tier; if(!t||e.h<=0) continue; const dx=Math.max(Math.abs(mouth.x-e.x)-e.hw,0), dz=Math.max(Math.abs(mouth.z-e.z)-e.hd,0); if(dx*dx+dz*dz>range*range) continue;
      for(const c of t.chunks){ if(!c.alive) continue; pt.set(c.x,c.y,c.z); if(!inCone(pt,mouth,L,range,th,Math.max(c.sx,c.sy,c.sz)*.6)) continue; D.dmg(c,.16,L.x*6,L.y*6+1,L.z*6); if(Math.random()<.5) D.ignite(c); } }
    NPC.noise&&NPC.noise(mouth.x,mouth.z,45); }
  if(VB.t>=VB.dur) endViolet(); }

/* ================= MOR CEHENNEM SÜTUNLARI (mor ateş) ================= */
const HF={on:false,t:0,n:0,x:0,z:0,fx:0,fz:1,id:0,pil:[]}; let hfTex=null; const HFH=64, HFN=9;
function ensureHF(){ if(hfTex) return; hfTex=canvasTex(256,256,(q,w,h)=>{ q.clearRect(0,0,w,h); for(let i=0;i<190;i++){ const x=Math.random()*w, y=Math.random()*h, l=24+Math.random()*70, c=Math.random(); q.strokeStyle=c<.3?"rgba(255,235,255,.6)":c<.65?"rgba(210,120,255,.55)":"rgba(120,40,230,.5)"; q.lineWidth=2+Math.random()*7; q.beginPath(); q.moveTo(x,y); q.quadraticCurveTo(x+(Math.random()-.5)*14,y-l*.5,x+(Math.random()-.5)*10,y-l); q.stroke(); } });
  hfTex.wrapS=hfTex.wrapT=THREE.RepeatWrapping; hfTex.repeat.set(2,2); }
function mkPillar(){ const g=new THREE.Group(), a=new THREE.Mesh(new THREE.CylinderGeometry(1,.55,1,18,1,true),new THREE.MeshBasicMaterial({map:hfTex,transparent:true,blending:AD,depthWrite:false,side:THREE.DoubleSide,opacity:.95})), b=new THREE.Mesh(new THREE.CylinderGeometry(.55,.3,1,14,1,true),new THREE.MeshBasicMaterial({color:0xfff0ff,transparent:true,blending:AD,depthWrite:false,side:THREE.DoubleSide,opacity:.55}));
  a.frustumCulled=b.frustumCulled=false; g.add(a); g.add(b); g.visible=false; scene.add(g); return {g,a,b,ring:mkRing(0xc060ff,.9),on:false,t:0,x:0,z:0,gy:0,id:0,hit:0}; }
function castHell(){ cd.hellfire=CD.hellfire; ensureHF(); const f=Game.heroFwd, l=Math.hypot(f.x,f.z)||1, p=hero.position; HF.on=true; HF.t=0; HF.n=0; HF.fx=f.x/l; HF.fz=f.z/l; HF.x=p.x; HF.z=p.z; HF.id++; Game.act("quake",1.3); if(au()) au().whoosh(); flash(.2,.5,"radial-gradient(circle,#fff0ff 0%,#6a1fd0 100%)"); }
function spawnPillar(i){ ensureHF(); let pl=HF.pil.find(o=>!o.on); if(!pl){ pl=mkPillar(); HF.pil.push(pl); } const lat=Math.sin(i*1.3)*7, d=18+i*14, x=HF.x+HF.fx*d+HF.fz*lat, z=HF.z+HF.fz*d-HF.fx*lat; pl.on=true; pl.t=-.55; pl.x=x; pl.z=z; pl.gy=gY(x,z); pl.id=HF.id; pl.hit=0; pl.ring.visible=true; pl.ring.position.set(x,pl.gy+.4,z); pl.ring.scale.set(10,10,1); }
function updHell(dt){ if(HF.on){ HF.t+=dt; while(HF.n<HFN&&HF.t>=HF.n*.22){ spawnPillar(HF.n); HF.n++; } if(HF.n>=HFN&&HF.t>HFN*.22+.1) HF.on=false; }
  for(const pl of HF.pil){ if(!pl.on) continue; pl.t+=dt; const t=pl.t;
    if(t<0){ const k=1+t/.55; pl.ring.visible=true; pl.ring.scale.set(11-5*k,11-5*k,1); pl.ring.rotation.z+=dt*4; pl.ring.material.opacity=.4+.5*k; for(let i=0;i<3;i++){ const a=Math.random()*TAU; PF(pl.x+Math.cos(a)*7,pl.gy+.4,pl.z+Math.sin(a)*7,-Math.cos(a)*6,R(2,6),-Math.sin(a)*6,.5,1.1,.3,.7,-1); } continue; }
    const dur=1.7, k=t/dur, up=Math.min(1,t/.22), dn=t>dur-.45?Math.max(0,(dur-t)/.45):1, h=HFH*up*dn, w=(5.2+Math.sin(t*9)*.5)*(.45+.55*dn);
    pl.g.visible=true; pl.g.position.set(pl.x,pl.gy-1,pl.z); pl.a.scale.set(w,Math.max(.1,h),w); pl.a.position.y=h/2; pl.b.scale.set(w*.6,Math.max(.1,h*.92),w*.6); pl.b.position.y=h*.46; pl.a.rotation.y+=dt*3; pl.b.rotation.y-=dt*4.5; hfTex.offset.y-=dt*.35/6; pl.ring.visible=true; pl.ring.scale.set(10+t*8,10+t*8,1); pl.ring.material.opacity=Math.max(0,.9-t*.9);
    for(let i=0;i<8;i++){ const yy=R(0,h), a=Math.random()*TAU, rr=R(0,w*.9); PF(pl.x+Math.cos(a)*rr,pl.gy+yy,pl.z+Math.sin(a)*rr,Math.cos(a)*R(1,5),R(8,22),Math.sin(a)*R(1,5),R(.5,1),R(1.6,3.2),R(.3,1),.8,-1); }
    if(Math.random()<.5) PS(pl.x+rs()*6,pl.gy+h*R(.5,1),pl.z+rs()*6,rs()*3,R(4,9),rs()*3,2.2,3,8);
    if(t<.12&&pl.hit===0){ pl.hit=1; if(au()) au().boom(pl.x,pl.gy,pl.z); FX.shock(pl.x,pl.gy+1,pl.z,34,26); FX.dust(pl.x,pl.gy+1,pl.z,22,14); shakeNear(pl.x,pl.gy,pl.z,1.2,200); Game.radial(pl.x,pl.gy+1,pl.z,16,36,"boom"); NPC.alert(pl.x,pl.z,100,pl.x,pl.z); }
    pl.hit2=(pl.hit2||0)-dt; if(pl.hit2<=0){ pl.hit2=.12; D.damageSphere(pl.x,pl.gy+h*.35,pl.z,11,.7*dn,36,true); igniteSphere(pl.x,pl.gy+12,pl.z,12,.25);
      for(const n of NPC.list){ if(!n.vis||n.st==="gone") continue; const p=npcPos(n); if(Math.hypot(p.x-pl.x,p.z-pl.z)>w+1.2||p.y>pl.gy+h) continue; if(n.hfId!==pl.id+":"+pl.x){ n.hfId=pl.id+":"+pl.x; NPC.hit(n,rs()*10,34,rs()*10,"boom"); if(n.vis) NPC.burn(n); } else if(n.body&&!n.dead&&false){} }
      Cars.query(pl.x,pl.z,w+3,(kd,i,px,pz)=>{ const key=kd+i+":"+pl.id+":"+pl.x; if(pl.cs===undefined) pl.cs=new Set(); if(pl.cs.has(key)) return; pl.cs.add(key); Cars.hit(kd,i,rs()*14,22,rs()*14,6); Cars.burn(kd,i); }); }
    if(t>=dur){ pl.on=false; pl.g.visible=false; pl.ring.visible=false; pl.cs=undefined; pl.hit2=0; FX.fire(pl.x,pl.gy,pl.z,10,0,4,0,2); } } }

/* ================= ana güncelleme ================= */
function tryCast(n,fn){ const down=A[n]&&!prev[n]; prev[n]=A[n]; if(!down||Game.mode!=="play") return; if(Game.Void&&Game.Void.on) return; if(!PR().hasPower(n)){ if(Game.toast) Game.toast("prem_locked",2600); return; } if(cd[n]>0) return; fn(); }
Game.updaters.push((dt0,time,raw)=>{ const rw=raw||dt0, dt=dt0;
  if(Game.mode!=="play"){ if(CH.on||VB.on) resetP4(); return; }
  for(const n of IDS){ if(cd[n]>0) cd[n]=Math.max(0,cd[n]-rw); cdUI(n); }
  if(!(Game.Void&&Game.Void.on)){ tryCast("chrono",castChrono); tryCast("reap",castReap); tryCast("planet",castPlanet); tryCast("violet",castViolet); tryCast("hellfire",castHell); } else for(const n of IDS) prev[n]=A[n];
  setOn("chrono",CH.on); setOn("reap",RP.on); setOn("planet",PL.ph>0); setOn("hellfire",HF.on);
  updChrono(rw); updReap(dt,rw); updPlanet(dt); updViolet(rw); updHell(dt); });
function resetP4(){ for(const n of IDS){ cd[n]=0; setOn(n,false); cdUI(n); } endChrono(true); RP.on=false; RP.souls.length=0; if(rpRing) rpRing.visible=rpRing2.visible=false; PL.ph=0; if(plG) plG.visible=false; if(plTg) plTg.visible=plTg2.visible=plShock.visible=false; endViolet(); HF.on=false; for(const pl of HF.pil){ pl.on=false; pl.g.visible=false; pl.ring.visible=false; pl.cs=undefined; } }
const rp3=Game.resetPowers3; Game.resetPowers3=function(){ if(rp3) rp3(); resetP4(); };
const rp2=Game.resetPowers2; Game.resetPowers2=function(){ if(rp2) rp2(); resetP4(); }; Game.resetPowers4=resetP4;
})();
