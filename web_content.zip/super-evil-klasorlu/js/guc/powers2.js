"use strict";
/* ===== 5 YENİ GÜÇ: Meteor Yağmuru, Zincir Şimşek, Yerçekimi Kuyusu, Zamanı Yavaşlat, Deprem Darbesi (bekleme halkalı) ===== */
(function(){
const A=Game.input.actions, H=Game.H, hero=Game.heroObj, D=Game.D, NPC=Game.NPC, Cars=Game.Cars, FX=Game.FX, P=Game.P, U=Game.U, W=Game.W, au=()=>Game.audio, on=n=>Game.powersOn[n]!==false, rs=U.rs;
const CD={meteor:14,lightning:4,gravity:18,timeslow:22,quake:10}, cd={meteor:0,lightning:0,gravity:0,timeslow:0,quake:0}, prev={}, btn={};
const camV=new THREE.Vector3(), tmpV=new THREE.Vector3(), rr={};
Game.ts=1; Game.tsTarget=1;
function cdUI(n){ const b=btn[n]||(btn[n]=document.querySelector('.act[data-act="'+n+'"]')); if(!b) return; const f=Math.max(0,cd[n]/CD[n]); b.style.setProperty("--cd",f.toFixed(3)); b.classList.toggle("cd",f>0); }
function aim(maxL){ const c=camera.position, L=Game.lookV; const r=D.ray(c.x,c.y,c.z,L.x,L.y,L.z,maxL||260); if(r.kind==="none"){ // hedef yok: kahramanın önündeki zemin
    const p=hero.position, fx=Game.heroFwd.x, fz=Game.heroFwd.z, x=p.x+fx*55, z=p.z+fz*55; r.x=x; r.z=z; r.y=W.surfaceAt(x,z,p.y); r.kind="ground"; r.fake=true; } return r; }
function handPos(o){ hero.updateMatrixWorld(true); o.set(.4,.3,.6); hero.localToWorld(o); return o; }
function igniteSphere(x,y,z,r,chance){ for(const e of Game.buildings){ const t=e.tier; if(!t||e.h<=0) continue; if(Math.hypot(e.x-x,e.z-z)>r+Math.max(e.hw,e.hd)) continue; for(const c of t.chunks){ if(!c.alive||Math.random()>chance) continue; if(Math.hypot(c.x-x,c.y-y,c.z-z)<r) D.ignite(c); } } }
function shakeNear(x,y,z,amt,range){ const d=Math.hypot(x-hero.position.x,y-hero.position.y,z-hero.position.z); if(d<range) Game.shakeAdd(amt*(1-d/range)); }

/* ---------------- METEOR YAĞMURU ---------------- */
const MET=[], metQ=[]; let metMark=null, metT=0;
const mGeo=new THREE.SphereGeometry(1,10,8), mMat=new THREE.MeshStandardMaterial({color:0x4a2d1c,emissive:0xff5a14,emissiveIntensity:1.8,roughness:.9});
const mkRing=(col,op)=>{ const m=new THREE.Mesh(new THREE.TorusGeometry(1,.04,6,40),new THREE.MeshBasicMaterial({color:col,transparent:true,opacity:op||1,depthWrite:false,blending:THREE.AdditiveBlending})); m.rotation.x=Math.PI/2; m.visible=false; m.frustumCulled=false; scene.add(m); return m; };
metMark=mkRing(0xff7a2a,.8);
function castMeteor(){ const r=aim(300); metMark.position.set(r.x,r.y+.4,r.z); metMark.userData={x:r.x,y:r.y,z:r.z}; metMark.visible=true; metT=0; Game.act("meteor",1.4); if(au()) au().whoosh();
  const n=14; for(let i=0;i<n;i++){ const a=Math.random()*6.283, d=Math.sqrt(Math.random())*(i<3?4:42); metQ.push({t:.55+i*.2+Math.random()*.12,x:r.x+Math.cos(a)*d,z:r.z+Math.sin(a)*d,y:r.y}); } }
function spawnMeteor(q){ let m=MET.find(o=>!o.on); if(!m){ if(MET.length>=14) return; const mesh=new THREE.Mesh(mGeo,mMat); mesh.castShadow=false; mesh.frustumCulled=false; scene.add(mesh); m={mesh,on:false,x:0,y:0,z:0,vx:0,vy:0,vz:0,r:1}; MET.push(m); }
  const dx=.35, dz=.2, dy=-1, l=Math.hypot(dx,dy,dz), sp=96; m.vx=dx/l*sp; m.vy=dy/l*sp; m.vz=dz/l*sp; const T=190/Math.abs(m.vy); m.x=q.x-m.vx*T; m.y=q.y-m.vy*T; m.z=q.z-m.vz*T; m.r=1.3+Math.random()*1.1; m.on=true; m.mesh.visible=true; m.mesh.scale.setScalar(m.r); if(au()) au().whoosh(); }
function meteorImpact(x,y,z,water){
  if(water){ Game.splash(x,z,6); FX.smoke(x,y+1,z,10,2); shakeNear(x,y,z,.5,160); return; }
  D.damageSphere(x,y,z,12,1.5,36); Game.radial(x,y,z,26,40,"boom"); igniteSphere(x,y,z,13,.5);
  FX.fire(x,y+1,z,30,0,8,0,3.6); FX.spark(x,y+1,z,34,24); FX.dust(x,y+.5,z,22,10); FX.shock(x,y+.3,z,26,24); FX.glow(x,y+2,z,18,[1,.7,.3],.28); FX.smoke(x,y+2,z,8,2.4);
  if(au()) au().boom(x,y,z); shakeNear(x,y,z,1.1,150); NPC.alert(x,z,90,x,z); }
function updMeteor(dt){
  for(let i=metQ.length-1;i>=0;i--){ const q=metQ[i]; q.t-=dt; if(q.t<=0){ metQ.splice(i,1); spawnMeteor(q); } }
  if(metMark.visible){ metT+=dt; const s=3+Math.sin(metT*9)*.4+Math.max(0,3-metT*3)*2; metMark.scale.set(46,46,1); metMark.visible=metQ.length>0||MET.some(m=>m.on); metMark.material.opacity=.5+.3*Math.sin(metT*10); }
  for(const m of MET){ if(!m.on) continue; const sx=m.vx*dt, sy=m.vy*dt, sz=m.vz*dt, L=Math.hypot(sx,sy,sz), dxn=sx/L, dyn=sy/L, dzn=sz/L;
    const r=D.ray(m.x,m.y,m.z,dxn,dyn,dzn,L+m.r*.6);
    FX.fire(m.x,m.y,m.z,3,-m.vx*.1,-m.vy*.1,-m.vz*.1,m.r*1.4); if(Math.random()<.5) FX.smoke(m.x,m.y,m.z,1,1.4); FX.glow(m.x,m.y,m.z,m.r*4.5,[1,.55,.2],.06);
    if(r.kind!=="none"&&r.t<=L+m.r*.6){ m.on=false; m.mesh.visible=false; meteorImpact(r.x,r.y,r.z,r.kind==="water"); continue; }
    m.x+=sx; m.y+=sy; m.z+=sz; m.mesh.position.set(m.x,m.y,m.z); m.mesh.rotation.x+=dt*3; m.mesh.rotation.z+=dt*2;
    if(m.y<W.WATER_Y-1){ m.on=false; m.mesh.visible=false; meteorImpact(m.x,W.WATER_Y,m.z,true); } } }

/* ---------------- ZİNCİR ŞİMŞEK ---------------- */
const BN=220, bMat=new THREE.MeshBasicMaterial({color:0xffffff}), gMat=new THREE.MeshBasicMaterial({color:0x7fc4ff,transparent:true,opacity:.45,blending:THREE.AdditiveBlending,depthWrite:false});
const bCore=new THREE.InstancedMesh(new THREE.BoxGeometry(1,1,1),bMat,BN), bGlow=new THREE.InstancedMesh(new THREE.BoxGeometry(1,1,1),gMat,BN); [bCore,bGlow].forEach(m=>{ m.frustumCulled=false; m.count=0; scene.add(m); });
const bolts=[], qA=new THREE.Quaternion(), UPv=new THREE.Vector3(0,1,0), dumB=new THREE.Object3D(), dirB=new THREE.Vector3();
function addBolt(a,b){ bolts.push({a:{x:a.x,y:a.y,z:a.z},b:{x:b.x,y:b.y,z:b.z},life:.42,max:.42,seed:Math.random()*100}); }
function updBolts(dt){ let n=0;
  for(let i=bolts.length-1;i>=0;i--){ const bo=bolts[i]; bo.life-=dt; if(bo.life<=0){ bolts.splice(i,1); continue; } const k=bo.life/bo.max, fl=.55+.45*Math.sin(bo.life*90+bo.seed), segs=14;
    const dx=bo.b.x-bo.a.x, dy=bo.b.y-bo.a.y, dz=bo.b.z-bo.a.z, L=Math.hypot(dx,dy,dz)||1, ux=dx/L, uy=dy/L, uz=dz/L; let px=ux*0, nx=-uz, nz=ux, nl=Math.hypot(nx,nz)||1; nx/=nl; nz/=nl; const mx=uy*nz*0, jit=Math.min(3.5,L*.06);
    let prev=bo.a, seed=((bo.life*40)|0)+bo.seed;
    for(let s=1;s<=segs&&n<BN;s++){ const t=s/segs; let q={x:bo.a.x+dx*t,y:bo.a.y+dy*t,z:bo.a.z+dz*t}; if(s<segs){ const j1=Math.sin(seed*12.9+s*78.2)*jit, j2=Math.sin(seed*3.7+s*45.1)*jit; q.x+=nx*j1; q.z+=nz*j1; q.y+=j2*.7; }
      dirB.set(q.x-prev.x,q.y-prev.y,q.z-prev.z); const l=dirB.length()||.01; dirB.multiplyScalar(1/l); qA.setFromUnitVectors(UPv,dirB);
      const w=.16*k*fl+.03; dumB.position.set((q.x+prev.x)/2,(q.y+prev.y)/2,(q.z+prev.z)/2); dumB.quaternion.copy(qA); dumB.scale.set(w,l,w); dumB.updateMatrix(); bCore.setMatrixAt(n,dumB.matrix);
      dumB.scale.set(w*5,l,w*5); dumB.updateMatrix(); bGlow.setMatrixAt(n,dumB.matrix); n++; prev=q; } }
  bCore.count=bGlow.count=n; bCore.instanceMatrix.needsUpdate=bGlow.instanceMatrix.needsUpdate=true; }
function castLightning(){ cd.lightning=CD.lightning; Game.act("lightning",.9); const o=handPos(new THREE.Vector3()), c=camera.position, L=Game.lookV, hit=new Set();
  const cands=[]; for(const n of NPC.list){ if(!n.vis||n.st==="gone"||n.dead&&!n.body) continue; const p=n.body?n.body.position:{x:n.x,y:n.y+.95*(NPC.scale||1.3),z:n.z}; cands.push({k:"n",n,x:p.x,y:p.y,z:p.z}); }
  Cars.query(o.x,o.z,140,(kd,i,px,pz)=>{ cands.push({k:"c",kd,i,x:px,y:1,z:pz}); });
  let first=null, bs=1e9; for(const e of cands){ const vx=e.x-c.x, vy=e.y-c.y, vz=e.z-c.z, t=vx*L.x+vy*L.y+vz*L.z; if(t<3||t>110) continue; const off=Math.sqrt(Math.max(0,vx*vx+vy*vy+vz*vz-t*t)); if(off<t*.22+3&&off<bs){ bs=off; first=e; } }
  let from=o, cur=first; const r=aim(200);
  if(!cur){ strikeGround(from,r); if(au()) au().zap(); return; }
  for(let j=0;j<9&&cur;j++){ hit.add(cur); const tp={x:cur.x,y:cur.y+.6,z:cur.z}; addBolt(from,tp); zapEntity(cur,from);
    let nxt=null, bd=22*22; for(const e of cands){ if(hit.has(e)) continue; const dx=e.x-cur.x, dy=e.y-cur.y, dz=e.z-cur.z, d=dx*dx+dy*dy+dz*dz; if(d<bd){ bd=d; nxt=e; } }
    from=tp; cur=nxt; if(!cur){ const g={x:tp.x,y:W.surfaceAt(tp.x,tp.z,tp.y),z:tp.z}; if(Math.random()<.7) { addBolt(tp,g); } D.damageSphere(tp.x,tp.y,tp.z,6,.9,16); } }
  FX.glow(o.x,o.y,o.z,6,[.7,.9,1],.15); if(au()) au().zap(); Game.shakeAdd(.35); }
function zapEntity(e,from){ const dx=e.x-from.x, dz=e.z-from.z, l=Math.hypot(dx,dz)||1;
  if(e.k==="n"){ NPC.hit(e.n,dx/l*7,10,dz/l*7,"laser"); NPC.char(e.n); FX.spark(e.x,e.y,e.z,10,9,[.7,.9,1]); }
  else { Cars.hit(e.kd,e.i,dx/l*10,13,dz/l*10,7); Cars.burn(e.kd,e.i); FX.spark(e.x,e.y,e.z,14,12,[.7,.9,1]); }
  FX.glow(e.x,e.y+.5,e.z,5,[.7,.9,1],.14); NPC.alert(e.x,e.z,40,e.x,e.z); }
function strikeGround(from,r){ const g={x:r.x,y:r.y,z:r.z}; const top={x:r.x+rs()*6,y:r.y+90,z:r.z+rs()*6}; addBolt(top,g); addBolt(from,g);
  D.damageSphere(g.x,g.y+1,g.z,7,1.4,24); Game.radial(g.x,g.y,g.z,12,22,"boom"); igniteSphere(g.x,g.y+1,g.z,6,.35); FX.spark(g.x,g.y+.5,g.z,26,18,[.7,.9,1]); FX.glow(g.x,g.y+1,g.z,12,[.8,.92,1],.2); FX.dust(g.x,g.y+.3,g.z,8,4); if(au()) au().boom(g.x,g.y,g.z); }

/* ---------------- YERÇEKİMİ KUYUSU ---------------- */
const GR={on:false,t:0,x:0,y:0,z:0,dur:5.6,hit:0}; let gSphere=null, gRing1=null, gRing2=null;
function ensureGravVis(){ if(gSphere) return; gSphere=new THREE.Mesh(new THREE.SphereGeometry(1,20,14),new THREE.MeshBasicMaterial({color:0x000000})); gSphere.visible=false; gSphere.frustumCulled=false; scene.add(gSphere);
  gRing1=mkRing(0xb36bff,.85); gRing2=mkRing(0xff9a3c,.7); gRing2.rotation.x=Math.PI/2+.5; }
function castGravity(){ cd.gravity=CD.gravity; const r=aim(150); GR.on=true; GR.t=0; GR.x=r.x; GR.z=r.z; GR.y=Math.max(r.y,W.surfaceAt(r.x,r.z,r.y))+8; GR.hit=0; ensureGravVis(); Game.act("gravity",1.3); if(au()) au().whoosh(); }
function updGravity(dt){ if(!GR.on) return; ensureGravVis(); GR.t+=dt; const t=GR.t, k=Math.min(1,t/.5)*(t>GR.dur-.5?Math.max(0,(GR.dur-t)/.5):1), R=48;
  gSphere.visible=gRing1.visible=gRing2.visible=true; gSphere.position.set(GR.x,GR.y,GR.z); gSphere.scale.setScalar(3.6*k+.01); gRing1.position.copy(gSphere.position); gRing2.position.copy(gSphere.position);
  gRing1.scale.set(8*k+.1,8*k+.1,1); gRing2.scale.set(11*k+.1,11*k+.1,1); gRing1.rotation.z+=dt*4; gRing2.rotation.z-=dt*3;
  for(let i=0;i<4;i++){ const a=Math.random()*6.283, rad=10+Math.random()*16, sp=-(8+Math.random()*10); FX.E(true,GR.x+Math.cos(a)*rad,GR.y+rs()*3,GR.z+Math.sin(a)*rad,-Math.cos(a)*sp*-1+Math.sin(a)*12,rs()*2,-Math.sin(a)*sp*-1-Math.cos(a)*12,.9,.7,.1,[.7,.4,1],[.2,.1,.5],.9,0,.97); }
  GR.hit-=dt; const doHit=GR.hit<=0; if(doHit) GR.hit=.3;
  for(const n of NPC.list){ if(!n.vis||n.st==="gone") continue; const p=n.body?n.body.position:{x:n.x,y:n.y+.95*(NPC.scale||1.3),z:n.z}; const dx=GR.x-p.x, dy=GR.y-p.y, dz=GR.z-p.z, d=Math.hypot(dx,dy,dz); if(d>R||d<1) continue;
    if(!n.body||n.st==="held"){ if(doHit&&n.st!=="held") NPC.hit(n,dx/d*10,8,dz/d*10,"gravity"); continue; } const b=n.body, a=(55+40*(1-d/R))*k*dt; b.velocity.x+=dx/d*a; b.velocity.y+=dy/d*a+(P&&P.G0||14)*dt*.9; b.velocity.z+=dz/d*a; b.velocity.x*=.995; b.velocity.z*=.995; if(d<5){ b.velocity.x*=.9; b.velocity.z*=.9; } }
  if(doHit) Cars.query(GR.x,GR.z,R,(kd,i,px,pz,d)=>{ const dx=GR.x-px, dz=GR.z-pz, l=Math.hypot(dx,dz)||1; Cars.hit(kd,i,dx/l*22,9,dz/l*22,5); });
  if(P&&P.pool) for(const r of P.pool){ if(!r.on||!r.body) continue; const b=r.body, p=b.position, dx=GR.x-p.x, dy=GR.y-p.y, dz=GR.z-p.z, d=Math.hypot(dx,dy,dz); if(d>R*1.4||d<.5) continue; const a=(50+30*(1-d/(R*1.4)))*k*dt; b.velocity.x+=dx/d*a; b.velocity.y+=dy/d*a+26*dt*.95; b.velocity.z+=dz/d*a; if(b.wakeUp) b.wakeUp(); if(d<3&&Math.random()<dt*6){ r.fade=1; } }
  if(doHit) D.damageSphere(GR.x,GR.y,GR.z,17,.16*(1+t*.5),7,true);
  if(t>=GR.dur){ GR.on=false; gSphere.visible=gRing1.visible=gRing2.visible=false; const x=GR.x,y=GR.y,z=GR.z;
    D.damageSphere(x,y,z,24,1.8,36); Game.radial(x,y,z,50,48,"boom"); igniteSphere(x,y,z,18,.3); FX.shock(x,y,z,60,34); FX.fire(x,y,z,34,0,6,0,3.5); FX.spark(x,y,z,40,26,[.8,.6,1]); FX.glow(x,y,z,26,[.8,.6,1],.3); if(au()) au().boom(x,y,z); shakeNear(x,y,z,1.4,170); } }

/* ---------------- ZAMANI YAVAŞLAT ---------------- */
const TS={on:false,t:0,dur:6}; let tsEl=null;
function castSlow(){ cd.timeslow=CD.timeslow; TS.on=true; TS.t=0; Game.tsTarget=.2; Game.act("timeslow",1.2); tsEl=tsEl||document.getElementById("slowFx"); if(tsEl) tsEl.classList.add("on"); if(au()&&au().slow) au().slow(true); }
function updSlow(dt){ if(TS.on){ TS.t+=dt; if(TS.t>=TS.dur){ TS.on=false; Game.tsTarget=1; if(tsEl) tsEl.classList.remove("on"); if(au()&&au().slow) au().slow(false); } }
  Game.ts+=(Game.tsTarget-Game.ts)*(1-Math.exp(-6*dt)); if(Math.abs(Game.ts-Game.tsTarget)<.005) Game.ts=Game.tsTarget; }

/* ---------------- DEPREM DARBESİ ---------------- */
const QK={ph:0,t:0,x:0,z:0,y:0,w:-1}; let qRing=null, qRing2=null;
function castQuake(){ cd.quake=CD.quake; QK.ph=1; QK.t=0; Game.act("quake",1.5); if(H.flying&&H.alt>8){ QK.ph=2; QK.t=0; H.flying=false; H.vel.set(0,-130,0); } else if(H.grounded){ H.vel.y=17; } else { QK.ph=2; H.vel.y=-130; } if(au()) au().whoosh(); }
function band(x,z,r,amt){ for(const e of Game.buildings){ const t=e.tier; if(!t||e.h<=0) continue; const dd=Math.hypot(e.x-x,e.z-z)-Math.max(e.hw,e.hd)*1.5; if(dd>r+8) continue;
    for(const c of t.chunks){ if(!c.alive) continue; const d=Math.hypot(c.x-x,c.z-z); if(Math.abs(d-r)>9) continue; const l=d||1; D.dmg(c,amt*(1-Math.min(1,d/90)*.6),(c.x-x)/l*14,7,(c.z-z)/l*14); } } }
function quakeImpact(){ QK.ph=3; QK.t=0; QK.x=hero.position.x; QK.z=hero.position.z; QK.y=hero.position.y-1.26; QK.w=0; qRing=qRing||mkRing(0xffc27a,.9); qRing2=qRing2||mkRing(0xffffff,.6); qRing.visible=qRing2.visible=true; qRing.position.set(QK.x,QK.y+.3,QK.z); qRing2.position.copy(qRing.position);
  D.damageSphere(QK.x,QK.y+1,QK.z,22,1.4,34); Game.radial(QK.x,QK.y,QK.z,55,52,"boom"); FX.shock(QK.x,QK.y+.5,QK.z,60,40); FX.dust(QK.x,QK.y+.5,QK.z,50,18); FX.spark(QK.x,QK.y+.5,QK.z,30,24); Game.shakeAdd(1.6); if(au()){ au().boom(QK.x,QK.y,QK.z); if(au().quake) au().quake(); } NPC.alert(QK.x,QK.z,150,QK.x,QK.z); }
function updQuake(dt){
  if(QK.ph===1){ QK.t+=dt; if(QK.t>.32&&!H.flying){ QK.ph=2; QK.t=0; H.vel.set(0,-130,0); } else if(QK.t>2){ QK.ph=0; } }
  else if(QK.ph===2){ QK.t+=dt; H.vel.x=H.vel.z=0; if(H.vel.y>-100&&!H.grounded) H.vel.y=-130; if(H.grounded&&QK.t>.05||QK.t>3){ if(H.grounded) quakeImpact(); else QK.ph=0; } }
  else if(QK.ph===3){ QK.t+=dt; const r=QK.t*68, k=1-QK.t/1.25; if(k<=0){ QK.ph=0; qRing.visible=qRing2.visible=false; return; }
    qRing.scale.set(r+.1,r+.1,1); qRing2.scale.set(r*.82+.1,r*.82+.1,1); qRing.material.opacity=.9*k; qRing2.material.opacity=.6*k;
    for(let i=0;i<10;i++){ const a=Math.random()*6.283; FX.dust(QK.x+Math.cos(a)*r,QK.y+.5,QK.z+Math.sin(a)*r,1,2.5); } if(Math.random()<.6){ const a=Math.random()*6.283; FX.spark(QK.x+Math.cos(a)*r,QK.y+.6,QK.z+Math.sin(a)*r,2,8); }
    if(((QK.t*14)|0)!==(((QK.t-dt)*14)|0)) band(QK.x,QK.z,r,.9); Game.shakeAdd(.5*k); } }

/* ---------------- ana güncelleme ---------------- */
function tryCast(n,fn){ if(A[n]&&!prev[n]&&on(n)&&cd[n]<=0&&Game.mode==="play"){ cd[n]=CD[n]; fn(); } prev[n]=A[n]; }
Game.updaters.push((dt0,time,raw)=>{ const dt=raw||dt0;
  if(Game.mode!=="play"){ if(tsEl) tsEl.classList.remove("on"); TS.on=false; Game.tsTarget=1; Game.ts=1; return; }
  for(const n in cd){ if(cd[n]>0) cd[n]=Math.max(0,cd[n]-dt); cdUI(n); }
  tryCast("meteor",castMeteor); tryCast("lightning",castLightning); tryCast("gravity",castGravity); tryCast("timeslow",castSlow); tryCast("quake",castQuake);
  updSlow(dt); const w=dt0; updMeteor(w); updBolts(dt); updGravity(w); updQuake(dt); });
Game.resetPowers2=function(){ for(const n in cd) cd[n]=0; TS.on=false; Game.tsTarget=Game.ts=1; GR.on=false; QK.ph=0; metQ.length=0; for(const m of MET){ m.on=false; m.mesh.visible=false; } bolts.length=0; };
})();
