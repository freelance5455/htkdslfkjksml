"use strict";
/* ===== PREMİUM GÜÇLER: Karadelik, Yörünge Saldırısı, Ateş Kasırgası, Güneş Patlaması, Tsunami + VOID modu (20 sn; Gölge / Toz tek atımlık butonlar) ===== */
(function(){
const A=Game.input.actions, H=Game.H, hero=Game.heroObj, D=Game.D, NPC=Game.NPC, Cars=Game.Cars, FX=Game.FX, P=Game.P, U=Game.U, W=Game.W, au=()=>Game.audio, rs=U.rs, PR=()=>Game.Premium;
const CD={blackhole:30,orbital:26,tornado:28,nova:34,tsunami:40,void:60}, CDV={shadow:1.2,dust:2.4}, cd={blackhole:0,orbital:0,tornado:0,nova:0,tsunami:0,void:0,shadow:0,dust:0}, prev={}, btn={};
const TAU=Math.PI*2, R=(a,b)=>a+Math.random()*(b-a), AD=THREE.AdditiveBlending, V3=THREE.Vector3;
const hud=$("hud"), tmpV=new V3();
function cdUI(n){ const b=btn[n]||(btn[n]=document.querySelector('.act[data-act="'+n+'"]')); if(!b) return; const m=CD[n]||CDV[n], f=Math.max(0,cd[n]/m); b.style.setProperty("--cd",f.toFixed(3)); b.classList.toggle("cd",f>0); }
function aim(maxL){ const c=camera.position, L=Game.lookV; const r=D.ray(c.x,c.y,c.z,L.x,L.y,L.z,maxL||260); if(r.kind==="none"){ const p=hero.position, fx=Game.heroFwd.x, fz=Game.heroFwd.z, x=p.x+fx*55, z=p.z+fz*55; r.x=x; r.z=z; r.y=W.surfaceAt(x,z,p.y); r.kind="ground"; r.fake=true; } return r; }
function handPos(o){ hero.updateMatrixWorld(true); o.set(.4,.3,.6); hero.localToWorld(o); return o; }
function igniteSphere(x,y,z,r,chance){ for(const e of Game.buildings){ const t=e.tier; if(!t||e.h<=0) continue; if(Math.hypot(e.x-x,e.z-z)>r+Math.max(e.hw,e.hd)) continue; for(const c of t.chunks){ if(!c.alive||Math.random()>chance) continue; if(Math.hypot(c.x-x,c.y-y,c.z-z)<r) D.ignite(c); } } }
function shakeNear(x,y,z,amt,range){ const d=Math.hypot(x-hero.position.x,y-hero.position.y,z-hero.position.z); if(d<range) Game.shakeAdd(amt*(1-d/range)); }
function mkRing(col,op){ const m=new THREE.Mesh(new THREE.TorusGeometry(1,.035,6,48),new THREE.MeshBasicMaterial({color:col,transparent:true,opacity:op||1,depthWrite:false,blending:AD})); m.rotation.x=Math.PI/2; m.visible=false; m.frustumCulled=false; scene.add(m); return m; }
function canvasTex(w,h,fn){ const c=document.createElement("canvas"); c.width=w; c.height=h; fn(c.getContext("2d"),w,h); const t=new THREE.CanvasTexture(c); return t; }
const gY=(x,z)=>Math.max(W.WATER_Y,W.terrainH?W.terrainH(x,z):W.surfaceAt(x,z,60));
let fxEl=null;
function flash(op,dur,col){ try{ if(!fxEl){ fxEl=document.getElementById("novaFx"); if(!fxEl){ fxEl=document.createElement("div"); fxEl.id="novaFx"; document.body.appendChild(fxEl); } } fxEl.style.background=col||"radial-gradient(circle at 50% 50%,#fff 0%,#fff6c8 35%,#ffb23a 80%)"; fxEl.style.transition="none"; fxEl.style.opacity=op; void fxEl.offsetWidth; fxEl.style.transition="opacity "+dur+"s ease-out"; fxEl.style.opacity=0; }catch(e){} }

/* ================= KARADELİK ================= */
const BH={on:false,t:0,x:0,y:0,z:0,dur:9,hit:0}; let bhG=null,bhCore,bhTilt,bhD1,bhD2,bhRing;
function ensureBH(){ if(bhG) return; bhG=new THREE.Group(); bhG.visible=false;
  bhCore=new THREE.Mesh(new THREE.SphereGeometry(1,28,20),new THREE.MeshBasicMaterial({color:0x000000})); bhCore.frustumCulled=false; bhG.add(bhCore);
  const dtex=canvasTex(512,512,(q,w,h)=>{ q.clearRect(0,0,w,h); const cx=w/2;
    for(let i=0;i<1000;i++){ const a=Math.random()*TAU, r0=.3+Math.pow(Math.random(),1.3)*.7, len=.12+Math.random()*.55, t=(r0-.3)/.7, col=t<.25?"255,244,200":t<.55?"255,170,60":t<.8?"255,90,40":"160,70,255"; q.strokeStyle="rgba("+col+","+(.2+Math.random()*.5).toFixed(2)+")"; q.lineWidth=1+Math.random()*3; q.beginPath(); q.arc(cx,cx,r0*cx,a,a+len); q.stroke(); }
    const gr=q.createRadialGradient(cx,cx,cx*.28,cx,cx,cx); gr.addColorStop(0,"rgba(255,255,255,0)"); gr.addColorStop(.12,"rgba(255,235,170,.6)"); gr.addColorStop(.5,"rgba(255,120,40,.22)"); gr.addColorStop(1,"rgba(120,40,200,0)"); q.fillStyle=gr; q.fillRect(0,0,w,h); });
  const dm=new THREE.MeshBasicMaterial({map:dtex,transparent:true,blending:AD,depthWrite:false,side:THREE.DoubleSide});
  bhTilt=new THREE.Group(); bhTilt.rotation.x=.42; bhG.add(bhTilt);
  bhD1=new THREE.Mesh(new THREE.PlaneGeometry(2,2),dm); bhD1.rotation.x=-Math.PI/2; bhD1.frustumCulled=false; bhTilt.add(bhD1);
  const dm2=new THREE.MeshBasicMaterial({map:dtex,transparent:true,blending:AD,depthWrite:false,side:THREE.DoubleSide,opacity:.7});
  bhD2=new THREE.Mesh(new THREE.PlaneGeometry(2,2),dm2); bhD2.rotation.x=-Math.PI/2; bhD2.scale.setScalar(.7); bhD2.position.y=.04; bhD2.frustumCulled=false; bhTilt.add(bhD2);
  const rt=canvasTex(256,256,(q,w,h)=>{ const cx=w/2, gr=q.createRadialGradient(cx,cx,cx*.4,cx,cx,cx); gr.addColorStop(0,"rgba(255,230,170,0)"); gr.addColorStop(.46,"rgba(255,230,170,0)"); gr.addColorStop(.62,"rgba(255,240,200,.95)"); gr.addColorStop(.74,"rgba(255,140,60,.4)"); gr.addColorStop(1,"rgba(120,50,200,0)"); q.fillStyle=gr; q.fillRect(0,0,w,h); });
  bhRing=new THREE.Sprite(new THREE.SpriteMaterial({map:rt,transparent:true,blending:AD,depthWrite:false})); bhRing.frustumCulled=false; bhG.add(bhRing);
  scene.add(bhG); }
function castBH(){ cd.blackhole=CD.blackhole; const r=aim(170); BH.on=true; BH.t=0; BH.x=r.x; BH.z=r.z; BH.y=Math.max(r.y,W.surfaceAt(r.x,r.z,r.y))+15; BH.hit=0; ensureBH(); Game.act("gravity",1.6); if(au()) au().whoosh(); flash(.25,.5,"#2a0a50"); }
function updBH(dt){ if(!BH.on) return; ensureBH(); BH.t+=dt; const t=BH.t, k=Math.min(1,t/.9)*(t>BH.dur-.7?Math.max(0,(BH.dur-t)/.7):1), Rg=105, S=4.6*k+.01;
  bhG.visible=true; bhG.position.set(BH.x,BH.y,BH.z); bhCore.scale.setScalar(S); bhTilt.scale.setScalar(S*5.2); bhD1.rotation.z+=dt*2.2; bhD2.rotation.z-=dt*3.4; bhRing.scale.setScalar(S*8.2);
  for(let i=0;i<7;i++){ const a=Math.random()*TAU, rad=R(12,62)*k+4, y=rs()*rad*.22; FX.E(true,BH.x+Math.cos(a)*rad,BH.y+y,BH.z+Math.sin(a)*rad,-Math.cos(a)*24-Math.sin(a)*28,-y*.4,-Math.sin(a)*24+Math.cos(a)*28,R(.9,1.6),R(1.2,2.2),.15,[1,.7,.35],[.45,.15,.9],.8,0,.985); }
  BH.hit-=dt; const doHit=BH.hit<=0; if(doHit) BH.hit=.25;
  for(const n of NPC.list){ if(!n.vis||n.st==="gone") continue; const p=n.body?n.body.position:{x:n.x,y:n.y+.95*(NPC.scale||1.3),z:n.z}; const dx=BH.x-p.x, dy=BH.y-p.y, dz=BH.z-p.z, d=Math.hypot(dx,dy,dz); if(d>Rg||d<.5) continue;
    if(d<S*1.15){ FX.E(true,p.x,p.y,p.z,0,0,0,.35,2,.2,[1,.8,.5],[.5,.2,1],.8,0,1); NPC.vanish(n); continue; }
    if(!n.body||n.st==="held"){ if(doHit&&n.st!=="held") NPC.hit(n,dx/d*16,9,dz/d*16,"gravity"); continue; }
    const b=n.body, a=(75+95*(1-d/Rg))*k*dt; b.velocity.x+=(dx/d-dz/d*.45)*a; b.velocity.y+=dy/d*a+30*dt*.9; b.velocity.z+=(dz/d+dx/d*.45)*a; b.velocity.x*=.996; b.velocity.z*=.996; }
  if(doHit){ Cars.query(BH.x,BH.z,Rg,(kd,i,px,pz,d)=>{ const dx=BH.x-px, dz=BH.z-pz, l=Math.hypot(dx,dz)||1; Cars.hit(kd,i,dx/l*30,11,dz/l*30,5); });
    const RB=Rg*.8; for(const e of Game.buildings){ const t=e.tier; if(!t||e.h<=0) continue; if(Math.hypot(e.x-BH.x,e.z-BH.z)-Math.max(e.hw,e.hd)>RB) continue;
      for(const c of t.chunks){ if(!c.alive) continue; const dx=BH.x-c.x, dy=BH.y-c.y, dz=BH.z-c.z, d=Math.hypot(dx,dy,dz); if(d>RB||d<1) continue; D.dmg(c,(.12+.55*(1-d/RB))*k,dx/d*22,dy/d*22+6,dz/d*22); } }
    D.damageSphere(BH.x,BH.y,BH.z,22,.45*k,14,true); }
  if(P&&P.pool) for(const r of P.pool){ if(!r.on||!r.body) continue; const b=r.body, p=b.position, dx=BH.x-p.x, dy=BH.y-p.y, dz=BH.z-p.z, d=Math.hypot(dx,dy,dz); if(d>Rg*1.5||d<.5) continue; const a=(70+60*(1-d/(Rg*1.5)))*k*dt; b.velocity.x+=(dx/d-dz/d*.5)*a; b.velocity.y+=dy/d*a+30*dt*.95; b.velocity.z+=(dz/d+dx/d*.5)*a; if(b.wakeUp) b.wakeUp(); if(d<S*1.3) r.fade=1; }
  shakeNear(BH.x,BH.y,BH.z,.3*k,220);
  if(t>=BH.dur){ BH.on=false; bhG.visible=false; const x=BH.x,y=BH.y,z=BH.z;
    D.damageSphere(x,y,z,40,2.4,52); Game.radial(x,y,z,85,60,"boom"); igniteSphere(x,y,z,30,.3); FX.shock(x,y,z,80,42); FX.fire(x,y,z,40,0,6,0,4); FX.spark(x,y,z,50,30,[.8,.6,1]); FX.glow(x,y,z,44,[.8,.6,1],.34); if(au()) au().boom(x,y,z); shakeNear(x,y,z,1.8,260); flash(.7,1,"#c9a8ff"); } }

/* ================= YÖRÜNGE SALDIRISI ================= */
const OR={ph:0,t:0,x:0,y:0,z:0,fx:0,fz:1,hit:0,bl:0,cx:0,cz:0}; let orB=null,orG=null,orR1=null,orR2=null;
function ensureOR(){ if(orB) return; const mk=(col,op)=>{ const m=new THREE.Mesh(new THREE.CylinderGeometry(1,1,1,20,1,true),new THREE.MeshBasicMaterial({color:col,transparent:true,opacity:op,blending:AD,depthWrite:false,side:THREE.DoubleSide})); m.visible=false; m.frustumCulled=false; scene.add(m); return m; };
  orB=mk(0xfff2e0,.95); orG=mk(0xff4a2a,.5); orR1=mkRing(0xff3a2a,.9); orR2=mkRing(0xffb02e,.85); }
function castOR(){ cd.orbital=CD.orbital; ensureOR(); const r=aim(420), f=Game.heroFwd, l=Math.hypot(f.x,f.z)||1; OR.ph=1; OR.t=0; OR.x=r.x; OR.z=r.z; OR.y=r.y; OR.fx=f.x/l; OR.fz=f.z/l; OR.hit=0; OR.bl=0; Game.act("meteor",1.4); if(au()) au().whoosh(); }
function orBeamAt(cx,cz,rc,gr,op){ const y=gY(cx,cz), H2=900; orB.visible=orG.visible=true; orB.position.set(cx,y+H2/2,cz); orB.scale.set(rc,H2,rc); orG.position.set(cx,y+H2/2,cz); orG.scale.set(rc*gr,H2,rc*gr); orG.material.opacity=op; return y; }
function updOR(dt){ if(!OR.ph) return; ensureOR(); OR.t+=dt; const t=OR.t;
  if(OR.ph===1){ const y=gY(OR.x,OR.z)+.4, k=Math.min(1,t/1.7); orR1.visible=orR2.visible=true; orR1.position.set(OR.x,y,OR.z); orR2.position.set(OR.x,y,OR.z);
    const s1=36-24*k+Math.sin(t*14)*1.2; orR1.scale.set(s1,s1,1); orR2.scale.set(s1*.55,s1*.55,1); orR1.rotation.z+=dt*3; orR2.rotation.z-=dt*4; orR1.material.opacity=.5+.4*Math.sin(t*16); orR2.material.opacity=.5+.35*Math.sin(t*16+1.5);
    orBeamAt(OR.x,OR.z,.18+k*.25,2.2,.18+.18*k); orB.material.opacity=.35+.4*k;
    if(Math.random()<dt*20) FX.E(true,OR.x+rs()*30,y+.5,OR.z+rs()*30,0,R(3,9),0,.8,.8,.2,[1,.4,.2],[1,.1,.05],.7,0,.97);
    if(t>=1.7){ OR.ph=2; OR.t=0; OR.hit=0; OR.bl=0; if(au()) au().boom(OR.x,y,OR.z); flash(.45,.5,"#ffd9c0"); } return; }
  const T2=3.0, k=t/T2, run=Math.min(1,t/T2)*72, cx=OR.x+OR.fx*run, cz=OR.z+OR.fz*run, fade=t>T2-.35?Math.max(0,(T2-t)/.35):1, rc=(3.2+Math.sin(t*30)*.35)*Math.min(1,t/.2+.4)*(.4+.6*fade);
  const y=orBeamAt(cx,cz,rc,2.7,.5*fade); orB.material.opacity=.95*fade; orR1.position.set(cx,y+.4,cz); orR2.position.set(cx,y+.4,cz); const s1=26+Math.sin(t*20)*2; orR1.scale.set(s1,s1,1); orR2.scale.set(s1*.6,s1*.6,1); orR1.rotation.z+=dt*5; orR2.rotation.z-=dt*6;
  OR.hit-=dt; if(OR.hit<=0){ OR.hit=.07; D.damageSphere(cx,y+2,cz,16,1.7,40,true); }
  OR.bl-=dt; if(OR.bl<=0){ OR.bl=.22; Game.radial(cx,y,cz,28,40,"boom"); igniteSphere(cx,y+2,cz,15,.45); FX.shock(cx,y+.5,cz,14,22); if(au()) au().boom(cx,y,cz); NPC.alert(cx,cz,120,cx,cz); }
  for(let i=0;i<9;i++){ const a=Math.random()*TAU, rd=R(0,9); FX.E(true,cx+Math.cos(a)*rd,y+R(0,5),cz+Math.sin(a)*rd,Math.cos(a)*R(8,18),R(8,26),Math.sin(a)*R(8,18),R(.4,.9),R(2.4,4),.3,[1,.85,.5],[1,.22,.05],.9,-2,.95); }
  FX.dust(cx,y+1,cz,4,10); FX.spark(cx,y+1,cz,6,28); FX.glow(cx,y+3,cz,26,[1,.7,.4],.1); if(Math.random()<.5) FX.E(false,cx+rs()*8,y+R(2,40),cz+rs()*8,0,R(6,14),0,2,4,9,[.15,.1,.08],[.3,.26,.24],.5,-.4,.98); shakeNear(cx,y,cz,.9*fade,200);
  if(t>=T2){ OR.ph=0; orB.visible=orG.visible=orR1.visible=orR2.visible=false; D.damageSphere(cx,y,cz,36,2.2,55); Game.radial(cx,y,cz,70,58,"boom"); igniteSphere(cx,y,cz,26,.4); FX.shock(cx,y+1,cz,60,38); FX.fire(cx,y,cz,40,0,8,0,4.5); FX.glow(cx,y+4,cz,40,[1,.8,.5],.3); FX.dust(cx,y+1,cz,30,16); if(au()) au().boom(cx,y,cz); shakeNear(cx,y,cz,1.6,260); flash(.5,.8,"#ffe0c0"); } }

/* ================= ATEŞ KASIRGASI ================= */
const TN={on:false,t:0,x:0,z:0,ang:0,dur:11,hit:0,seed:0}; let tnG=null,tnA,tnB,tnA0,tnB0,tnTexA,tnTexB; const TNH=78;
function ensureTN(){ if(tnG) return; tnG=new THREE.Group(); tnG.visible=false;
  tnTexA=canvasTex(256,256,(q,w,h)=>{ q.clearRect(0,0,w,h); for(let i=0;i<170;i++){ const x=Math.random()*w, y=Math.random()*h, l=20+Math.random()*60, c=Math.random(); q.strokeStyle=c<.35?"rgba(255,240,150,.55)":c<.7?"rgba(255,150,40,.5)":"rgba(230,60,20,.45)"; q.lineWidth=2+Math.random()*6; q.beginPath(); q.moveTo(x,y); q.quadraticCurveTo(x+l*.5,y-8+Math.random()*16,x+l,y+(Math.random()-.5)*14); q.stroke(); } });
  tnTexB=canvasTex(256,256,(q,w,h)=>{ q.clearRect(0,0,w,h); for(let i=0;i<120;i++){ const x=Math.random()*w, y=Math.random()*h, l=30+Math.random()*70; q.strokeStyle="rgba("+(10+Math.random()*25|0)+","+(6+Math.random()*10|0)+",4,"+(.35+Math.random()*.4).toFixed(2)+")"; q.lineWidth=4+Math.random()*9; q.beginPath(); q.moveTo(x,y); q.lineTo(x+l,y+(Math.random()-.5)*10); q.stroke(); } });
  for(const t of [tnTexA,tnTexB]){ t.wrapS=t.wrapT=THREE.RepeatWrapping; t.repeat.set(3,2); }
  const gA=new THREE.CylinderGeometry(24,3,TNH,32,12,true), gB=new THREE.CylinderGeometry(15,2,TNH*.94,24,10,true);
  tnA=new THREE.Mesh(gA,new THREE.MeshBasicMaterial({map:tnTexA,transparent:true,blending:AD,depthWrite:false,side:THREE.DoubleSide,opacity:.95}));
  tnB=new THREE.Mesh(gB,new THREE.MeshBasicMaterial({map:tnTexB,transparent:true,depthWrite:false,side:THREE.DoubleSide,opacity:.8}));
  tnA.frustumCulled=tnB.frustumCulled=false; tnA.position.y=TNH/2; tnB.position.y=TNH*.47; tnG.add(tnB); tnG.add(tnA); scene.add(tnG);
  tnA0=gA.attributes.position.array.slice(); tnB0=gB.attributes.position.array.slice(); }
function castTN(){ cd.tornado=CD.tornado; ensureTN(); const r=aim(150), f=Game.heroFwd; TN.on=true; TN.t=0; TN.x=r.x; TN.z=r.z; TN.ang=Math.atan2(f.x,f.z); TN.hit=0; Game.act("lightning",1.2); if(au()) au().whoosh(); }
function wobble(m,base,t,ph){ const pa=m.geometry.attributes.position, a=pa.array; for(let i=0;i<a.length;i+=3){ const y=base[i+1]+TNH/2, kk=y/TNH; a[i]=base[i]+Math.sin(t*1.9+y*.085+ph)*kk*kk*9; a[i+2]=base[i+2]+Math.cos(t*1.5+y*.07+ph)*kk*kk*9; } pa.needsUpdate=true; }
function updTN(dt){ if(!TN.on) return; ensureTN(); TN.t+=dt; const t=TN.t, k=Math.min(1,t/1.2)*(t>TN.dur-1.4?Math.max(0,(TN.dur-t)/1.4):1);
  TN.ang+=Math.sin(t*.8)*.5*dt; const sp=8.5; TN.x+=Math.sin(TN.ang)*sp*dt; TN.z+=Math.cos(TN.ang)*sp*dt; const gy=gY(TN.x,TN.z), x=TN.x, z=TN.z;
  tnG.visible=true; tnG.position.set(x,gy-1,z); tnG.scale.set(.25+.75*k,.3+.7*k,.25+.75*k); tnA.rotation.y+=dt*3.6; tnB.rotation.y-=dt*5; tnTexA.offset.y-=dt*.9; tnTexB.offset.y-=dt*.6; wobble(tnA,tnA0,t,0); wobble(tnB,tnB0,t,1.7);
  for(let i=0;i<11;i++){ const yy=R(0,TNH*.95)*k, kk=yy/TNH, rad=(3+21*kk)*R(.55,1.05)*(.25+.75*k), a=t*5+yy*.11+Math.random()*.6, cs=Math.cos(a), sn=Math.sin(a), wx=Math.sin(t*1.9+yy*.085)*kk*kk*9, wz=Math.cos(t*1.5+yy*.07)*kk*kk*9;
    FX.E(true,x+cs*rad+wx,gy+yy,z+sn*rad+wz,-sn*16,R(2,8),cs*16,R(.5,.95),R(2.4,4)*(.4+kk),.4,[1,.75,.3],[.9,.15,.02],.8,-1,.96); }
  if(Math.random()<dt*12) FX.E(false,x+rs()*16,gy+TNH*.9*k,z+rs()*16,rs()*5,R(3,6),rs()*5,2.4,5,13,[.12,.09,.07],[.3,.27,.25],.55,-.3,.98);
  if(Math.random()<dt*30) FX.E(false,x+rs()*8,gy+1,z+rs()*8,rs()*8,R(2,5),rs()*8,1.1,2,6,[.5,.45,.4],[.35,.32,.3],.5,-1,.95);
  TN.hit-=dt; const doHit=TN.hit<=0; if(doHit) TN.hit=.3; const Rp=40*(.4+.6*k);
  for(const n of NPC.list){ if(!n.vis||n.st==="gone") continue; const p=n.body?n.body.position:{x:n.x,y:n.y+.95*(NPC.scale||1.3),z:n.z}; const dx=x-p.x, dz=z-p.z, d=Math.hypot(dx,dz); if(d>Rp||Math.abs(p.y-gy)>TNH) continue;
    if(!n.body||n.st==="held"){ if(doHit&&n.st!=="held"){ NPC.hit(n,dx/(d||1)*14-dz/(d||1)*18,15,dz/(d||1)*14+dx/(d||1)*18,"boom"); } continue; }
    const b=n.body, a=(60+40*(1-d/Rp))*k*dt, ux=dx/(d||1), uz=dz/(d||1); b.velocity.x+=(ux*.7-uz*1.1)*a; b.velocity.z+=(uz*.7+ux*1.1)*a; b.velocity.y+=(36*k)*dt+((p.y-gy)<TNH*.8?18*dt:-10*dt); if(!n.burntT||n.burntT<TN.t-4){ n.burntT=TN.t; NPC.char(n); } }
  if(doHit){ Cars.query(x,z,Rp,(kd,i,px,pz,d)=>{ const dx=x-px, dz=z-pz, l=Math.hypot(dx,dz)||1; Cars.hit(kd,i,(dx/l*.7-dz/l*1.1)*16,13,(dz/l*.7+dx/l*1.1)*16,5); Cars.burn(kd,i); });
    igniteSphere(x,gy+10,z,22*(.4+.6*k),.3); D.damageSphere(x,gy+8,z,17*(.4+.6*k),.4,24,true); NPC.alert(x,z,90,x,z); }
  if(P&&P.pool) for(const r of P.pool){ if(!r.on||!r.body) continue; const b=r.body, p=b.position, dx=x-p.x, dz=z-p.z, d=Math.hypot(dx,dz); if(d>Rp*1.2||p.y-gy>TNH) continue; const a=(55+30*(1-d/(Rp*1.2)))*k*dt, ux=dx/(d||1), uz=dz/(d||1); b.velocity.x+=(ux*.7-uz*1.2)*a; b.velocity.z+=(uz*.7+ux*1.2)*a; b.velocity.y+=34*dt*k; if(b.wakeUp) b.wakeUp(); }
  shakeNear(x,gy,z,.35*k,160);
  if(t>=TN.dur){ TN.on=false; tnG.visible=false; FX.fire(x,gy+4,z,30,0,6,0,3.5); FX.smoke(x,gy+8,z,8,3); } }

/* ================= GÜNEŞ PATLAMASI ================= */
const NV={ph:0,t:0,x:0,y:0,z:0,Rr:0,hit:0,ig:0,id:0,cars:new Set()}; let nvSun=null,nvSh1,nvSh2,nvRing,nvGlow; const NVR=150;
function ensureNV(){ if(nvSun) return; const gl=canvasTex(128,128,(q,w,h)=>{ const g=q.createRadialGradient(64,64,0,64,64,64); g.addColorStop(0,"rgba(255,255,230,1)"); g.addColorStop(.3,"rgba(255,210,90,.75)"); g.addColorStop(.7,"rgba(255,120,30,.25)"); g.addColorStop(1,"rgba(255,80,10,0)"); q.fillStyle=g; q.fillRect(0,0,w,h); });
  nvSun=new THREE.Mesh(new THREE.SphereGeometry(1,24,18),new THREE.MeshBasicMaterial({color:0xfff2b8})); nvSun.visible=false; nvSun.frustumCulled=false; scene.add(nvSun);
  nvGlow=new THREE.Sprite(new THREE.SpriteMaterial({map:gl,transparent:true,blending:AD,depthWrite:false})); nvGlow.visible=false; nvGlow.frustumCulled=false; scene.add(nvGlow);
  nvSh1=new THREE.Mesh(new THREE.SphereGeometry(1,28,20),new THREE.MeshBasicMaterial({color:0xfff0b0,transparent:true,opacity:.5,blending:AD,depthWrite:false,side:THREE.DoubleSide})); nvSh2=new THREE.Mesh(new THREE.SphereGeometry(1,28,20),new THREE.MeshBasicMaterial({color:0xff7a22,transparent:true,opacity:.3,blending:AD,depthWrite:false,side:THREE.DoubleSide}));
  for(const m of [nvSh1,nvSh2]){ m.visible=false; m.frustumCulled=false; scene.add(m); } nvRing=mkRing(0xfff0a0,.95); }
function castNV(){ cd.nova=CD.nova; ensureNV(); NV.ph=1; NV.t=0; NV.id++; NV.cars.clear(); NV.ig=0; Game.act("meteor",1.3); if(au()) au().whoosh(); }
function updNV(dt){ if(!NV.ph) return; ensureNV(); NV.t+=dt; const t=NV.t;
  if(NV.ph===1){ const k=Math.min(1,t/1.15), e=k*k*(3-2*k), p=hero.position; NV.x=p.x; NV.y=p.y+4.2; NV.z=p.z; const rr=.5+4.2*e+Math.sin(t*30)*.12;
    nvSun.visible=nvGlow.visible=true; nvSun.position.set(NV.x,NV.y,NV.z); nvSun.scale.setScalar(rr); nvGlow.position.copy(nvSun.position); nvGlow.scale.setScalar(rr*5.5);
    for(let i=0;i<10;i++){ const a=Math.random()*TAU, b=Math.random()*TAU-1.57, d=R(10,26)*(1-.4*e); FX.E(true,NV.x+Math.cos(a)*Math.cos(b)*d,NV.y+Math.sin(b)*d,NV.z+Math.sin(a)*Math.cos(b)*d,-Math.cos(a)*Math.cos(b)*d*1.4,-Math.sin(b)*d*1.4,-Math.sin(a)*Math.cos(b)*d*1.4,.7,1.6,.2,[1,.9,.5],[1,.4,.1],.85,0,.97); }
    shakeNear(NV.x,NV.y,NV.z,.25*e,40);
    if(t>=1.15){ NV.ph=2; NV.t=0; NV.Rr=0; NV.hit=0; nvSh1.visible=nvSh2.visible=true; flash(1,1.4); if(au()) au().boom(NV.x,NV.y,NV.z); FX.glow(NV.x,NV.y,NV.z,60,[1,.95,.7],.4); Game.shakeAdd(1.8); } return; }
  const T2=1.9, k=Math.min(1,t/T2), e=1-Math.pow(1-k,2.4), Rr=e*NVR, x=NV.x, y=NV.y, z=NV.z, fade=1-k, gy=gY(x,z);
  nvSh1.position.set(x,y,z); nvSh2.position.set(x,y,z); nvSh1.scale.setScalar(Rr+.1); nvSh2.scale.setScalar(Rr*.86+.1); nvSh1.material.opacity=.5*fade; nvSh2.material.opacity=.32*fade; nvSun.scale.setScalar(Math.max(.01,4.7*(1-k*1.6))); nvGlow.scale.setScalar(Math.max(.01,26*(1-k))); if(k>.62) nvSun.visible=false;
  nvRing.visible=true; nvRing.position.set(x,gy+.5,z); nvRing.scale.set(Rr+.1,Rr+.1,1); nvRing.material.opacity=.9*fade;
  for(let i=0;i<26;i++){ const a=Math.random()*TAU; FX.E(true,x+Math.cos(a)*Rr*R(.94,1),gy+R(.5,6),z+Math.sin(a)*Rr*R(.94,1),Math.cos(a)*22,R(2,12),Math.sin(a)*22,R(.5,1),R(3,6),.5,[1,.9,.55],[1,.3,.05],.8,4,.96); }
  if(Math.random()<.7){ const a=Math.random()*TAU; FX.E(false,x+Math.cos(a)*Rr*.9,gy+3,z+Math.sin(a)*Rr*.9,Math.cos(a)*14,R(3,10),Math.sin(a)*14,2,4,10,[.25,.2,.16],[.4,.36,.33],.5,-.5,.97); }
  NV.hit-=dt; if(NV.hit<=0){ NV.hit=.08; D.damageSphere(x,y,z,Rr,2.4*(1-e*.5),48,true); }
  NV.ig-=dt; if(NV.ig<=0){ NV.ig=.25; igniteSphere(x,y,z,Rr,.1); }
  for(const n of NPC.list){ if(!n.vis||n.st==="gone"||n.nvId===NV.id) continue; const p=n.body?n.body.position:{x:n.x,y:n.y,z:n.z}, dx=p.x-x, dz=p.z-z, d=Math.hypot(dx,dz); if(d>Rr) continue; n.nvId=NV.id; const l=d||1; NPC.hit(n,dx/l*58,18,dz/l*58,"boom"); if(n.vis) NPC.char(n); }
  Cars.query(x,z,Rr,(kd,i,px,pz,d)=>{ const key=kd+i; if(NV.cars.has(key)) return; NV.cars.add(key); const dx=px-x, dz=pz-z, l=Math.hypot(dx,dz)||1; Cars.hit(kd,i,dx/l*44,16,dz/l*44,7); Cars.burn(kd,i); });
  shakeNear(x,y,z,.6*fade,300);
  if(t>=T2){ NV.ph=0; nvSh1.visible=nvSh2.visible=nvRing.visible=nvSun.visible=nvGlow.visible=false; } }

/* ================= TSUNAMİ ================= */
const TS={on:false,t:0,x:0,z:0,fx:0,fz:1,hit:0,id:0,set:new Set(),dur:5.4}; let tsM=null,tsGeo=null; const PROF=[[-34,0],[-26,7],[-17,19],[-9,31],[-2,40],[3.5,43],[7.5,36],[9.5,22],[10.5,8],[11,0]], WS=36, WWD=170, TSV=60;
function ensureTS(){ if(tsM) return; const np=PROF.length, nv=np*(WS+1), pos=new Float32Array(nv*3), col=new Float32Array(nv*3), idx=[];
  for(let i=0;i<np;i++) for(let j=0;j<=WS;j++){ const v=i*(WS+1)+j, k=Math.pow(PROF[i][1]/43,3); col[v*3]=.1+.9*k; col[v*3+1]=.46+.54*k; col[v*3+2]=.8+.2*k; }
  for(let i=0;i<np-1;i++) for(let j=0;j<WS;j++){ const a=i*(WS+1)+j, b=a+1, c=a+WS+1, d=c+1; idx.push(a,c,b,b,c,d); }
  tsGeo=new THREE.BufferGeometry(); tsGeo.setAttribute("position",new THREE.BufferAttribute(pos,3)); tsGeo.setAttribute("color",new THREE.BufferAttribute(col,3)); tsGeo.setIndex(idx);
  tsM=new THREE.Mesh(tsGeo,new THREE.MeshBasicMaterial({vertexColors:true,transparent:true,opacity:.92,side:THREE.DoubleSide})); tsM.frustumCulled=false; tsM.visible=false; scene.add(tsM); }
function castTS(){ cd.tsunami=CD.tsunami; ensureTS(); const f=Game.heroFwd, l=Math.hypot(f.x,f.z)||1, p=hero.position; TS.on=true; TS.t=0; TS.fx=f.x/l; TS.fz=f.z/l; TS.x=p.x+TS.fx*26; TS.z=p.z+TS.fz*26; TS.hit=0; TS.id++; TS.set.clear(); Game.act("quake",1.4); if(au()) au().whoosh(); }
function updTS(dt){ if(!TS.on) return; ensureTS(); TS.t+=dt; const t=TS.t, rise=Math.min(1,t/.9), re=rise*rise*(3-2*rise), fade=t>TS.dur-.9?Math.max(0,(TS.dur-t)/.9):1, fx=TS.fx, fz=TS.fz, rx=fz, rz=-fx, wd=WWD*(.5+.5*Math.min(1,t/1.5));
  TS.x+=fx*TSV*dt; TS.z+=fz*TSV*dt; const gy=gY(TS.x,TS.z)-1.5, pa=tsGeo.attributes.position.array;
  for(let i=0;i<PROF.length;i++){ const hk=PROF[i][1]/43; for(let j=0;j<=WS;j++){ const v=(i*(WS+1)+j)*3, lx=(j/WS-.5)*wd, wv=Math.sin(j*.9+t*5.5+i)*2.2*hk+Math.sin(j*.37-t*3)*3*hk;
      pa[v]=lx; pa[v+1]=Math.max(0,PROF[i][1]*re*fade*(1+.05*Math.sin(j*.6+t*4))+wv*re*fade); pa[v+2]=PROF[i][0]+Math.sin(j*.5+t*3)*1.5*hk; } }
  tsGeo.attributes.position.needsUpdate=true; tsM.visible=true; tsM.position.set(TS.x,gy,TS.z); tsM.rotation.y=Math.atan2(fx,fz); tsM.material.opacity=.92;
  const crestH=43*re*fade;
  for(let i=0;i<16;i++){ const lx=(Math.random()-.5)*wd, cf=R(1,9), px=TS.x+rx*lx+fx*cf, pz=TS.z+rz*lx+fz*cf;
    FX.E(false,px,gy+crestH*R(.6,1),pz,fx*R(16,30),R(2,10),fz*R(16,30),R(.7,1.3),R(1.6,3),R(4,7),[.95,.98,1],[.7,.85,1],.7,10,.97); }
  for(let i=0;i<8;i++){ const lx=(Math.random()-.5)*wd, f2=R(-30,-4), px=TS.x+rx*lx+fx*f2, pz=TS.z+rz*lx+fz*f2; FX.E(true,px,gy+R(2,PROF[3][1])*re,pz,fx*R(6,14),R(1,6),fz*R(6,14),R(.6,1),R(2.4,4),R(5,8),[.8,.92,1],[.55,.75,1],.3,2,.96); }
  TS.hit-=dt; if(TS.hit<=0){ TS.hit=.1; for(let lx=-wd/2+8;lx<=wd/2-8;lx+=16){ const px=TS.x+rx*lx+fx*2, pz=TS.z+rz*lx+fz*2; D.damageSphere(px,gy+14,pz,18,.65*fade,36,true); } NPC.alert(TS.x,TS.z,120,TS.x,TS.z); }
  const inSlab=(px,pz,f0,f1)=>{ const dx=px-TS.x, dz=pz-TS.z, fo=dx*fx+dz*fz, la=dx*rx+dz*rz; return fo>f0&&fo<f1&&Math.abs(la)<wd/2; };
  for(const n of NPC.list){ if(!n.vis||n.st==="gone") continue; const p=n.body?n.body.position:{x:n.x,y:n.y,z:n.z}; if(!inSlab(p.x,p.z,-22,12)) continue;
    if(n.tsId!==TS.id){ n.tsId=TS.id; NPC.hit(n,fx*34,13,fz*34,"boom"); } else if(n.body){ n.body.velocity.x+=fx*90*dt; n.body.velocity.z+=fz*90*dt; if(n.body.velocity.y<2) n.body.velocity.y+=8*dt; } }
  Cars.query(TS.x,TS.z,wd/2+12,(kd,i,px,pz,d)=>{ if(!inSlab(px,pz,-22,12)) return; const key=kd+i; if(TS.set.has(key)) return; TS.set.add(key); Cars.hit(kd,i,fx*36,10,fz*36,6); });
  if(P&&P.pool) for(const r of P.pool){ if(!r.on||!r.body) continue; const b=r.body, p=b.position; if(!inSlab(p.x,p.z,-24,14)) continue; b.velocity.x+=fx*80*dt; b.velocity.z+=fz*80*dt; if(b.wakeUp) b.wakeUp(); }
  shakeNear(TS.x,gy,TS.z,.55*fade,220);
  if(t>=TS.dur){ TS.on=false; tsM.visible=false; } }

/* ================= VOID MODU ================= */
const VD={on:false,t:0,dur:20,q:[],balls:[],jobs:[]}; let vdTi=null; const vdFrom=new V3();
function setVdTimer(f){ if(!vdTi) vdTi=document.querySelector("#voidT i"); if(vdTi) vdTi.style.transform="scaleX("+Math.max(0,f).toFixed(3)+")"; }
function castVoid(){ cd.void=CD.void; VD.on=true; VD.t=0; hud.classList.add("voidm"); for(const k in A) if(k!=="fly") A[k]=false; document.querySelectorAll(".act.down").forEach(b=>b.classList.remove("down")); cd.shadow=cd.dust=0; setVdTimer(1);
  Game.act("meteor",1.1); if(au()) au().boom(hero.position.x,hero.position.y,hero.position.z); flash(.6,1.3,"radial-gradient(circle at 50% 50%,#000 0%,#1c0838 60%,#3a1470 100%)"); Game.toast("v_on",2800);
  const p=hero.position; for(let i=0;i<60;i++){ const a=i/60*TAU; FX.E(false,p.x+Math.cos(a)*2,p.y,p.z+Math.sin(a)*2,Math.cos(a)*16,R(1,5),Math.sin(a)*16,1.4,1.4,4,[.03,0,.06],[0,0,0],.9,-.3,.94); FX.E(true,p.x+Math.cos(a)*2,p.y+.5,p.z+Math.sin(a)*2,Math.cos(a)*22,R(1,6),Math.sin(a)*22,.8,1.2,.2,[.7,.5,1],[.2,.1,.5],.8,0,.95); } }
function endVoid(quiet){ if(!VD.on) return; VD.on=false; hud.classList.remove("voidm"); if(!quiet) Game.toast("v_off",2200); }
function targetPos(n,o){ if(n.body){ const p=n.body.position; return o.set(p.x,p.y+.2,p.z); } return o.set(n.x,n.y+.95*(NPC.scale||1.3),n.z); }
function castShadow(){ const L=Game.lookV, c=camera.position, h=hero.position, cand=[];
  for(const n of NPC.list){ if(!n.vis||n.dead||n.st==="gone"||n.st==="shade"||n.st==="held"||n.st==="burn"||n.frozen) continue; targetPos(n,tmpV); const dx=tmpV.x-h.x, dy=tmpV.y-h.y, dz=tmpV.z-h.z, d=Math.hypot(dx,dy,dz); if(d>85) continue; const vx=tmpV.x-c.x, vy=tmpV.y-c.y, vz=tmpV.z-c.z, vl=Math.hypot(vx,vy,vz)||1, dot=(vx*L.x+vy*L.y+vz*L.z)/vl; cand.push({n,s:d-40*Math.max(0,dot)}); }
  if(!cand.length){ Game.toast("v_nonpc",1800); return; }
  cd.shadow=CDV.shadow; cand.sort((a,b)=>a.s-b.s); handPos(vdFrom); Game.act("lightning",.8); if(au()) au().whoosh();
  const cnt=Math.min(4,cand.length); for(let i=0;i<cnt;i++) VD.q.push({n:cand[i].n,u:-i*.12,fx:vdFrom.x,fy:vdFrom.y,fz:vdFrom.z}); }
function updShadowQ(dt){ for(let i=VD.q.length-1;i>=0;i--){ const e=VD.q[i]; e.u+=dt/.3; if(e.u<0) continue; const n=e.n; if(!n.vis||n.st==="gone"){ VD.q.splice(i,1); continue; } targetPos(n,tmpV); const u=Math.min(1,e.u), x=e.fx+(tmpV.x-e.fx)*u, y=e.fy+(tmpV.y-e.fy)*u+Math.sin(u*Math.PI)*1.2, z=e.fz+(tmpV.z-e.fz)*u;
    for(let k=0;k<3;k++){ FX.E(false,x+rs()*.5,y+rs()*.5,z+rs()*.5,rs()*2,rs()*2,rs()*2,.5,.9,.3,[.02,0,.05],[0,0,0],.9,0,.95); FX.E(true,x+rs()*.4,y+rs()*.4,z+rs()*.4,rs()*2,rs()*2,rs()*2,.4,.7,.1,[.75,.55,1],[.2,.1,.5],.9,0,.95); }
    if(e.u>=1){ VD.q.splice(i,1); if(NPC.shadow(n)){ Game.addScore&&Game.addScore(40); if(au()) au().whoosh(); } } } }
const BALLS=[]; function mkBall(){ const g=new THREE.Group(), core=new THREE.Mesh(new THREE.SphereGeometry(1,20,14),new THREE.MeshBasicMaterial({color:0x000000}));
  const gl=canvasTex(64,64,(q,w,h)=>{ const gr=q.createRadialGradient(32,32,2,32,32,32); gr.addColorStop(0,"rgba(190,150,255,.9)"); gr.addColorStop(.5,"rgba(110,50,230,.35)"); gr.addColorStop(1,"rgba(60,10,160,0)"); q.fillStyle=gr; q.fillRect(0,0,w,h); });
  const halo=new THREE.Sprite(new THREE.SpriteMaterial({map:gl,transparent:true,blending:AD,depthWrite:false})); halo.scale.setScalar(5.2); g.add(core); g.add(halo); const sats=[];
  for(let i=0;i<3;i++){ const s=new THREE.Mesh(new THREE.SphereGeometry(.3,8,6),new THREE.MeshBasicMaterial({color:0xe6d6ff})); g.add(s); sats.push(s); }
  g.visible=false; g.frustumCulled=false; scene.add(g); return {g,core,halo,sats,on:false}; }
function findBuilding(r){ if(r.kind==="chunk"&&r.chunk&&r.chunk.t&&r.chunk.t.bl) return {bl:r.chunk.t.bl,x:r.x,y:r.y,z:r.z};
  let best=null, bd=1e9; for(const e of Game.buildings){ const t=e.tier; if(!t||e.h<=0||!t.bl) continue; const dx=Math.max(Math.abs(r.x-e.x)-e.hw,0), dz=Math.max(Math.abs(r.z-e.z)-e.hd,0), d=Math.hypot(dx,dz); if(d<bd&&d<22){ bd=d; best={bl:t.bl,x:e.x,y:Math.max(2,e.h*.5),z:e.z}; } } return best; }
function castDust(){ const r=aim(330), b=findBuilding(r); if(!b){ Game.toast("v_nobld",1800); return; } cd.dust=CDV.dust; Game.act("punch",.55,1); if(au()) au().whoosh();
  VD.balls.push({t:-.22,tx:b.x,ty:b.y,tz:b.z,bl:b.bl,sx:0,sy:0,sz:0,u:0,len:1,mesh:null}); }
function startDust(bl,x,y,z){ const list=[]; let maxD=1; for(const tier of bl.tiers){ for(const c of tier.chunks){ if(!c.alive) continue; const d=Math.hypot(c.x-x,(c.y-y)*.7,c.z-z); list.push({c,d}); if(d>maxD) maxD=d; } }
  if(!list.length) return; list.sort((a,b)=>a.d-b.d); const sp=Math.max(14,maxD/2.1); VD.jobs.push({list,t:0,dk:0,ki:0,sp,lag:sp*.55,x,y,z,pp:Math.min(1,320/list.length),maxD}); if(au()) au().collapse(x,y,z,1); }
function darken(c){ const hp=c.hp===undefined?1:c.hp; D.dmg(c,Math.min(.5,Math.max(0,hp-.25)),0,0,0); }
function killDust(c,pp){ D.killSilent(c); const sp=Math.max(c.sx,c.sz); FX.E(false,c.x,c.y,c.z,rs()*4,R(1,4),rs()*4,R(1.4,2.4),R(1,2)*Math.min(2.5,sp*.35+.4),R(3,6)*Math.min(2,sp*.3+.5),[.4,.32,.5],[.16,.12,.2],.55,-.6,.95);
  if(Math.random()<pp) FX.E(true,c.x+rs()*c.sx*.7,c.y+rs()*c.sy*.5,c.z+rs()*c.sz*.7,rs()*3,R(3,10),rs()*3,R(1,2),R(.5,1.1),.1,[.85,.7,1],[.3,.15,.65],.85,-.7,.97); }
function updJobs(dt){ for(let i=VD.jobs.length-1;i>=0;i--){ const j=VD.jobs[i]; j.t+=dt; const front=j.t*j.sp, L=j.list;
    while(j.dk<L.length&&L[j.dk].d<=front){ if(L[j.dk].c.alive) darken(L[j.dk].c); j.dk++; }
    let n=0; while(j.ki<L.length&&L[j.ki].d<=front-j.lag&&n<90){ if(L[j.ki].c.alive) killDust(L[j.ki].c,j.pp); j.ki++; n++; }
    if(((j.t*5)|0)!==(((j.t-dt)*5)|0)&&au()) au().collapse(j.x,j.y,j.z,.6);
    shakeNear(j.x,j.y,j.z,.35,140);
    if(j.ki>=L.length){ FX.cloud(j.x,j.y,j.z,10,Math.min(40,j.maxD),5,[.42,.34,.52]); VD.jobs.splice(i,1); } } }
function impactBall(b){ const x=b.tx, y=b.ty, z=b.tz; for(let i=0;i<48;i++){ const a=i/48*TAU; FX.E(true,x,y,z,Math.cos(a)*26,R(-2,6),Math.sin(a)*26,.7,2,.3,[.8,.6,1],[.25,.1,.6],.85,0,.95); }
  for(let i=0;i<20;i++) FX.E(false,x+rs()*3,y+rs()*3,z+rs()*3,rs()*14,rs()*14,rs()*14,1.6,2,6,[.05,0,.1],[0,0,0],.7,0,.95); FX.glow(x,y,z,30,[.6,.4,1],.3); if(au()) au().boom(x,y,z); Game.shakeAdd(.9); startDust(b.bl,x,y,z); Game.addScore&&Game.addScore(300); }
function updBalls(dt,time){ for(let i=VD.balls.length-1;i>=0;i--){ const b=VD.balls[i]; b.t+=dt; if(b.t<0) continue;
    if(!b.mesh){ b.mesh=BALLS.find(o=>!o.on); if(!b.mesh){ b.mesh=mkBall(); BALLS.push(b.mesh); } b.mesh.on=true; b.mesh.g.visible=true; handPos(tmpV); b.sx=tmpV.x; b.sy=tmpV.y; b.sz=tmpV.z; const dx=b.tx-b.sx, dy=b.ty-b.sy, dz=b.tz-b.sz; b.len=Math.hypot(dx,dy,dz)||1; b.u=0; }
    b.u+=70*dt/b.len; const u=Math.min(1,b.u), x=b.sx+(b.tx-b.sx)*u, y=b.sy+(b.ty-b.sy)*u+Math.sin(u*Math.PI)*Math.min(6,b.len*.06), z=b.sz+(b.tz-b.sz)*u, m=b.mesh, pu=1+.14*Math.sin(time*22);
    m.g.position.set(x,y,z); m.core.scale.setScalar(1.35*pu); m.halo.scale.setScalar(5.2*pu); m.sats.forEach((s,k)=>{ const a=time*7+k*2.09, r=2.1+.3*Math.sin(time*5+k); s.position.set(Math.cos(a)*r,Math.sin(a*1.3+k)*r*.7,Math.sin(a)*r); });
    for(let k=0;k<4;k++){ FX.E(false,x+rs()*1.2,y+rs()*1.2,z+rs()*1.2,rs()*3,rs()*3,rs()*3,.6,1.3,.3,[.03,0,.06],[0,0,0],.8,0,.95); FX.E(true,x+rs()*1,y+rs()*1,z+rs()*1,rs()*3,rs()*3,rs()*3,.45,.9,.1,[.75,.55,1],[.25,.1,.6],.85,0,.95); }
    if(u>=1){ m.on=false; m.g.visible=false; VD.balls.splice(i,1); impactBall(b); } } }
function updVoid(dt,time){ if(VD.on){ VD.t+=dt; setVdTimer(1-VD.t/VD.dur); const p=hero.position;
      if(Math.random()<dt*40) FX.E(false,p.x+rs()*1.8,p.y+R(-1,2.4),p.z+rs()*1.8,rs()*2,R(1,3),rs()*2,1.1,.8,2.2,[.03,0,.06],[0,0,0],.7,-.4,.96);
      if(Math.random()<dt*16) FX.E(true,p.x+rs()*1.6,p.y+R(-.8,2.4),p.z+rs()*1.6,rs()*1.5,R(1,3),rs()*1.5,.8,.5,.1,[.7,.5,1],[.2,.1,.5],.8,-.4,.96);
      if(VD.t>=VD.dur) endVoid(); }
  updShadowQ(dt); updBalls(dt,time); updJobs(dt); }

/* ================= ana güncelleme ================= */
function tryCast(n,fn){ const down=A[n]&&!prev[n]; prev[n]=A[n]; if(!down||Game.mode!=="play"||VD.on) return; if(!PR().hasPower(n)||cd[n]>0) return; fn(); }
function tryVoidBtn(n,fn){ const down=A[n]&&!prev[n]; prev[n]=A[n]; if(!down||Game.mode!=="play"||!VD.on||cd[n]>0) return; fn(); }
Game.updaters.push((dt0,time,raw)=>{ const dt=raw||dt0;
  if(Game.mode!=="play"){ return; }
  for(const n in cd){ if(cd[n]>0) cd[n]=Math.max(0,cd[n]-dt); cdUI(n); }
  tryCast("blackhole",castBH); tryCast("orbital",castOR); tryCast("tornado",castTN); tryCast("nova",castNV); tryCast("tsunami",castTS); tryCast("void",castVoid); tryVoidBtn("shadow",castShadow); tryVoidBtn("dust",castDust);
  const w=dt0; updBH(w); updOR(w); updTN(w); updNV(w); updTS(w); updVoid(w,time); });
function resetP3(){ for(const n in cd) cd[n]=0; BH.on=false; if(bhG) bhG.visible=false; OR.ph=0; if(orB) orB.visible=orG.visible=orR1.visible=orR2.visible=false; TN.on=false; if(tnG) tnG.visible=false; NV.ph=0; if(nvSun) nvSun.visible=nvGlow.visible=nvSh1.visible=nvSh2.visible=nvRing.visible=false; TS.on=false; if(tsM) tsM.visible=false;
  endVoid(true); VD.q.length=0; VD.jobs.length=0; for(const b of VD.balls) if(b.mesh){ b.mesh.on=false; b.mesh.g.visible=false; } VD.balls.length=0; }
const rp2=Game.resetPowers2; Game.resetPowers2=function(){ if(rp2) rp2(); resetP3(); }; Game.resetPowers3=resetP3; Game.Void=VD;
})();
