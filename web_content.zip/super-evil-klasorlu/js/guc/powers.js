"use strict";
/* ===== GÜÇLER: yumruk, boğazlama, alkış, lazer, dondurma, ateş ===== */
(function(){
const A=Game.input.actions, H=Game.H, hero=Game.heroObj, D=Game.D, NPC=Game.NPC, Cars=Game.Cars, FX=Game.FX, U=Game.U, au=()=>Game.audio, on=n=>Game.powersOn[n]!==false;
const eye=new THREE.Vector3(), hit=new THREE.Vector3(), d2=new THREE.Vector3(), mouth=new THREE.Vector3(), pt=new THREE.Vector3(), dd=new THREE.Vector3(), UP=new THREE.Vector3(0,1,0), cp=new THREE.Vector3();
const beamMat=new THREE.MeshBasicMaterial({color:0xff4a10}), glowMat=new THREE.MeshBasicMaterial({color:0xff6a30,transparent:true,opacity:.35,blending:THREE.AdditiveBlending,depthWrite:false});
const beam=new THREE.Mesh(new THREE.CylinderGeometry(.07,.07,1,8),beamMat), glow=new THREE.Mesh(new THREE.CylinderGeometry(.22,.22,1,8),glowMat);
beam.visible=glow.visible=false; beam.frustumCulled=glow.frustumCulled=false; scene.add(beam,glow);
const ringMat=new THREE.MeshBasicMaterial({color:0x9fe8ff,transparent:true,depthWrite:false}), ring=new THREE.Mesh(new THREE.TorusGeometry(1,.05,8,48),ringMat);
ring.rotation.x=Math.PI/2; ring.visible=false; scene.add(ring);
const sonicMat=new THREE.MeshBasicMaterial({color:0xffffff,transparent:true,depthWrite:false}), sonic=new THREE.Mesh(new THREE.TorusGeometry(1,.03,8,48),sonicMat); sonic.rotation.x=Math.PI/2; sonic.visible=false; scene.add(sonic);
let pPrev=false, cPrev=false, kPrev=false, cdP=0, cdK=0, clapT=-1, sonT=-1, bPrev=false, held=null, laserOn=false, brOn=null;
const rs=U.rs;
Game.shakeAdd=v=>{ H.shake=Math.max(H.shake,v); };

function dirNow(){ if(H.flying) return dd.copy(Game.lookV); dd.set(Game.lookV.x,0,Game.lookV.z); if(dd.lengthSq()<1e-4) dd.set(0,0,1); return dd.normalize(); }
function inCone(p,m,d,range,tanH,pad){ const vx=p.x-m.x,vy=p.y-m.y,vz=p.z-m.z, t=vx*d.x+vy*d.y+vz*d.z; if(t<0||t>range) return false; const l2=vx*vx+vy*vy+vz*vz-t*t; const w=t*tanH+(pad||1.2); return l2<w*w; }
const NSC=Game.NPC.scale||1.3, npcPos=n=>n.body?n.body.position:{x:n.x,y:n.y+.95*NSC,z:n.z};

/* lv: 0 = normal yumruk, 0..1 = şarjlı yumruk (basılı tutup bırakınca): menzil, hasar, savurma, şok dalgası ve sarsıntı büyür */
function doPunch(lv){ lv=lv||0; cdP=.42+lv*.75; Game.act("punch",.4+lv*.35,Game.nextPunchSide()); const d=dirNow().clone(); pt.copy(hero.position).addScaledVector(d,3.8+lv*4); pt.y+=.2;
  H.vel.addScaledVector(d,10+lv*42); Game.shakeAdd(.45+lv*1.5); FX.spark(pt.x,pt.y,pt.z,16+Math.round(lv*44),10+lv*16); FX.dust(pt.x,pt.y,pt.z,8+Math.round(lv*24),3+lv*5); FX.glow(pt.x,pt.y,pt.z,4+lv*12,[1,.8-lv*.3,.5-lv*.3],.14+lv*.2); if(au()){ au().punch(); if(lv>0&&au().chargeHit) au().chargeHit(lv); }
  if(held&&held.st==="held"){ NPC.release(held,d.x*(48+lv*60),9+lv*8,d.z*(48+lv*60)); held=null; return; }
  if(Game.Lift&&Game.Lift.active){ Game.Lift.throwIt(d); return; }
  const rr=lv*10;
  D.damageSphere(pt.x,pt.y,pt.z,4.4+rr,1.2+lv*2.6,28+lv*60);
  const nr=4.6+rr, nk=1+lv*1.9;
  for(const n of NPC.list){ if(!n.vis) continue; const p=npcPos(n); if(Math.hypot(p.x-pt.x,p.y-pt.y,p.z-pt.z)<nr) NPC.hit(n,d.x*32*nk,(8+Math.max(0,d.y)*10)*(1+lv*.8),d.z*32*nk,"punch"); }
  Cars.query(pt.x,pt.z,5.5+rr,(k,i)=>{ Cars.hit(k,i,d.x*30*(1+lv*2.2),7+lv*9,d.z*30*(1+lv*2.2),5+lv*7); }); if(Game.Sea) Game.Sea.punch(pt.x,pt.y,pt.z,5+rr,d.x,d.y,d.z); if(Game.Police&&Game.Police.punch) Game.Police.punch(pt.x,pt.y,pt.z,5.5+rr); NPC.alert(pt.x,pt.z,40+lv*50,pt.x,pt.z);
  if(lv>.3){ FX.shock(pt.x,Math.max(.4,pt.y-1),pt.z,26+lv*46,14+lv*16); FX.dust(pt.x,.4,pt.z,10+Math.round(lv*20),5+lv*8); if(lv>.65&&Game.radial) Game.radial(pt.x,pt.y,pt.z,10+lv*26,28+lv*34,"boom"); if(au()&&au().boom&&lv>.5) au().boom(pt.x,pt.y,pt.z); } }
/* ---- şarj: yumruk tuşunu basılı tutunca (0.3 sn sonra) güç toplanır; bırakınca şarjlı yumruk ---- */
const PC={hold:0,lv:0,on:false,step:0,tick:0,btn:null,cs:0,last:""};
function chargeUpdate(dt){ if(!PC.btn) PC.btn=document.querySelector('.act[data-act="punch"]');
  const down=A.punch&&on("punch")&&Game.mode==="play";
  if(down&&!pPrev&&cdP<=0){ doPunch(0); PC.hold=0; PC.lv=0; PC.on=false; PC.step=0; pPrev=true; return; }
  if(down){ if(!pPrev) PC.hold=0; PC.hold+=dt;
    if(PC.hold>.32){ if(!PC.on){ PC.on=true; PC.step=0; if(au()&&au().charge) au().charge(0); }
      PC.lv=Math.min(1,(PC.hold-.32)/1.6); const p=hero.position, fx=p.x+dirNow().x*1.1, fz=p.z+dirNow().z*1.1, fy=p.y+(H.flying?-.1:.15);
      Game.shakeAdd(.03+PC.lv*.16);
      PC.tick-=dt; if(PC.tick<=0){ PC.tick=.05; FX.glow(fx,fy,fz,1.4+PC.lv*5,[1,.75-PC.lv*.35,.35-PC.lv*.25],.1);
        const a=Math.random()*6.283, r=2.2+PC.lv*1.6; FX.spark(fx+Math.cos(a)*r,fy+(Math.random()-.3)*r,fz+Math.sin(a)*r,1+Math.round(PC.lv*2),2+PC.lv*3,[1,.7,.3]); if(PC.lv>.35&&Math.random()<.5) FX.dust(p.x,p.y-1.4,p.z,2,2+PC.lv*3); }
      const st=Math.floor(PC.lv*3+1e-6); if(st>PC.step){ PC.step=st; FX.ring&&FX.ring(p.x,p.y-1,p.z,5+st*2,3+st,1.2); Game.shakeAdd(.35+st*.15); if(au()&&au().charge) au().charge(PC.lv); }
      if(au()&&au().charge){ PC.cs-=dt; if(PC.cs<=0){ PC.cs=.14; au().charge(PC.lv,true); } } } }
  else { if(PC.on){ if(PC.lv>=.08) doPunch(PC.lv); PC.on=false; } PC.hold=0; PC.lv=0; PC.step=0; }
  { const v=PC.on?PC.lv.toFixed(2):"0"; if(v!==PC.last){ PC.last=v; document.documentElement.style.setProperty("--pc",v); } } if(PC.btn&&PC.btn.classList) PC.btn.classList.toggle("hold",PC.on); try{ document.body.classList.toggle("pcharge",PC.on); }catch(e){}
  pPrev=!!down; }
Game.punchCharge=PC;
function doClap(){ cdK=1; clapT=0; Game.act("clap",1); ring.position.copy(hero.position); ring.position.y=Math.max(1,hero.position.y-.8); Game.shakeAdd(.9);
  const p=hero.position; Game.radial(p.x,p.y,p.z,36,46,"clap"); D.damageSphere(p.x,p.y,p.z,15,.6,18); FX.shock(p.x,p.y-.5,p.z,50,26); FX.dust(p.x,.4,p.z,24,10); NPC.alert(p.x,p.z,80,p.x,p.z); if(au()) au().boom(p.x,p.y,p.z); }
function tryChoke(){ const d=dirNow(), p=hero.position, n=NPC.nearest(p.x,p.y,p.z,10,d.x,d.z,.15), LFt=Game.Lift, c=LFt?LFt.probe(d):null; let nd=1e9; if(n){ const q=npcPos(n); nd=Math.hypot(q.x-p.x,q.y-p.y,q.z-p.z); }
  if(c&&c.dist<nd-1.5&&LFt.grab(c)) return;
  if(n&&NPC.grab(n)){ held=n; FX.spark(n.x,n.y+1.4*NSC,n.z,6,3,[1,.7,.5]); if(au()) au().thud(n.x,n.y+1,n.z); NPC.alert(n.x,n.z,30,n.x,n.z); } else if(c) LFt.grab(c); }

function laser(dt,time){
  const q=hero.position; cp.copy(camera.position); const L=Game.lookV; const r=D.ray(cp.x,cp.y,cp.z,L.x,L.y,L.z,400); let bt=r.t, tgt=null, tk=null, ti=-1;
  for(const n of NPC.list){ if(!n.vis||n.dead&&!n.body) continue; const p=npcPos(n), wx=p.x-cp.x,wy=p.y-cp.y,wz=p.z-cp.z, t=wx*L.x+wy*L.y+wz*L.z; if(t<4||t>=bt) continue; if(wx*wx+wy*wy+wz*wz-t*t<1.3){ bt=t; tgt=n; tk="n"; } }
  Cars.query(cp.x,cp.z,200,(k,i,px,pz)=>{ const wx=px-cp.x,wy=.9-cp.y,wz=pz-cp.z, t=wx*L.x+wy*L.y+wz*L.z; if(t<4||t>=bt) return; if(wx*wx+wy*wy+wz*wz-t*t<5){ bt=t; tgt={k,i}; tk="c"; } });
  if(Game.Sea){ const sr=Game.Sea.ray(cp.x,cp.y,cp.z,L.x,L.y,L.z,bt); if(sr){ bt=sr.t; tgt=sr.e; tk="s"; } }
  hit.set(cp.x+L.x*bt,cp.y+L.y*bt,cp.z+L.z*bt); hero.updateMatrixWorld(true); eye.set(0,.94,.19); hero.localToWorld(eye); if(Game.settings.cam==="1p") eye.set(cp.x+L.x*.9,cp.y-.3+L.y*.9,cp.z+L.z*.9);
  d2.subVectors(hit,eye); const len=Math.max(.5,d2.length()); d2.multiplyScalar(1/len);
  const col=CHARS[Game.char].laser; beamMat.color.setHex(col); glowMat.color.setHex(col); const w=1+Math.sin(time*50)*.25;
  beam.position.copy(eye).addScaledVector(d2,len/2); beam.quaternion.setFromUnitVectors(UP,d2); beam.scale.set(w,len,w); glow.position.copy(beam.position); glow.quaternion.copy(beam.quaternion); glow.scale.set(w*1.1,len,w*1.1);
  const c3=[((col>>16)&255)/255,((col>>8)&255)/255,(col&255)/255]; FX.glow(hit.x,hit.y,hit.z,2.4+Math.random(),c3,.07); FX.spark(hit.x,hit.y,hit.z,3,7,c3);
  if(tk==="n"){ const gore=Game.Gore.on(); if(!tgt.dead||(gore&&tgt.body)){ tgt.lz=(tgt.lz||0)+dt; FX.fire(hit.x,hit.y,hit.z,2,0,1,0,.8);
      if(gore){ if(tgt.lz>.14){ tgt.lz=0; if(!NPC.cutAt(tgt,hit,d2)&&!tgt.dead){ NPC.hit(tgt,d2.x*6,3,d2.z*6,"laser"); NPC.char(tgt); } } }
      else if(!tgt.dead&&tgt.lz>.3){ NPC.hit(tgt,d2.x*6,3,d2.z*6,"laser"); NPC.char(tgt); tgt.lz=0; } } }
  else if(tk==="s"){ Game.Sea.laser(tgt,dt,hit); }
  else if(tk==="c"){ Cars.burn(tgt.k,tgt.i); FX.fire(hit.x,hit.y,hit.z,2,0,2,0,1); }
  else if(r.kind==="chunk"){ const c=r.chunk; if(Math.random()<dt*14) FX.smoke(hit.x,hit.y,hit.z,1,.8); D.dmg(c,dt*1.5,d2.x*7,d2.y*7,d2.z*7); if(Math.random()<dt*2) D.ignite(c); }
  else if(r.kind==="ground"){ if(Math.random()<dt*10) FX.smoke(hit.x,.3,hit.z,1,.7); }
  if(Math.random()<dt*3) NPC.noise(hit.x,hit.z,45); }

function breath(kind,dt){ // "ice" | "fire"
  const fire=kind==="fire", range=fire?20:24, th=fire?.36:.42, L=Game.lookV; mouth.set(hero.position.x,hero.position.y+.5,hero.position.z).addScaledVector(L,1.4); if(Game.settings.cam==="1p"){ mouth.copy(camera.position).addScaledVector(L,1.2); mouth.y-=.35; }
  for(let i=0;i<(fire?7:5);i++){ const sp=fire?16+Math.random()*7:18+Math.random()*8, jx=rs()*th*sp*.9, jy=rs()*th*sp*.9, jz=rs()*th*sp*.9;
    if(fire) FX.fire(mouth.x,mouth.y,mouth.z,1,L.x*sp+jx+H.vel.x*.5,L.y*sp+jy+H.vel.y*.5,L.z*sp+jz+H.vel.z*.5,2.2); else FX.ice(mouth.x,mouth.y,mouth.z,1,1,L.x*sp+jx,L.y*sp+jy,L.z*sp+jz); }
  for(const n of NPC.list){ if(!n.vis||n.dead&&!n.body) continue; const p=npcPos(n); if(inCone(p,mouth,L,range,th,1.4)){ if(fire) NPC.burn(n); else NPC.freeze(n); } }
  Cars.query(mouth.x,mouth.z,range+3,(k,i,px,pz)=>{ pt.set(px,.9,pz); if(inCone(pt,mouth,L,range,th,2.4)){ if(fire) Cars.burn(k,i); else Cars.freeze(k,i); } });
  if(Game.Sea) Game.Sea.breath(mouth.x,mouth.y,mouth.z,L,range,th,fire,dt);
  for(const e of Game.buildings){ const t=e.tier; if(!t||e.h<=0) continue; const dx=Math.max(Math.abs(mouth.x-e.x)-e.hw,0), dz=Math.max(Math.abs(mouth.z-e.z)-e.hd,0); if(dx*dx+dz*dz>range*range) continue;
    for(const c of t.chunks){ if(!c.alive) continue; pt.set(c.x,c.y,c.z); if(!inCone(pt,mouth,L,range,th,Math.max(c.sx,c.sy,c.sz)*.6)) continue;
      if(fire){ if(Math.random()<dt*3) D.ignite(c); } else D.freezeChunk(c,dt*.8); } }
  if(fire&&Math.random()<dt*2) NPC.noise(mouth.x,mouth.z,40); }

Game.updaters.push(Object.assign((dt0,time,raw)=>{ const dt=raw||dt0;
  if(Game.mode!=="play"){ if(PC.on||PC.hold){ PC.on=false; PC.hold=0; PC.lv=0; try{ document.body.classList.remove("pcharge"); document.documentElement.style.setProperty("--pc","0"); PC.last="0"; }catch(e){} } beam.visible=glow.visible=ring.visible=sonic.visible=false; if(laserOn||brOn){ laserOn=false; brOn=null; if(au()) au().stopLoops(); } return; }
  cdP-=dt; cdK-=dt;
  const mf=!!(CHARS[Game.char]&&CHARS[Game.char].mouthFire), wantLaser=A.laser&&on("laser")&&!mf, wantBr=(A.freeze&&on("freeze"))?"ice":(A.fire&&on("fire"))?"fire":null;
  Game.aimFace=(wantLaser||(mf&&A.laser&&on("laser"))||wantBr||A.punch||A.choke)?Math.atan2(Game.lookV.x,Game.lookV.z):null;
  chargeUpdate(dt);
  if(A.clap&&!kPrev&&cdK<=0&&on("clap")) doClap(); kPrev=A.clap;
  const LF=Game.Lift; if(A.choke&&on("choke")){ if(!cPrev&&!held&&!(LF&&LF.active)) tryChoke(); } else { if(held){ const n=held; held=null; if(n.st==="held"){ const dv=dirNow(); NPC.release(n,H.vel.x*.5+dv.x*3,2,H.vel.z*.5+dv.z*3); } } if(LF&&LF.active) LF.drop(); } cPrev=A.choke;
  if(held){ if(held.st!=="held"){ held=null; } else { const d=dirNow(), n=held; n.hx=hero.position.x+d.x*1.7; n.hy=hero.position.y+1.5*NSC+Math.sin(time*9)*.04; n.hz=hero.position.z+d.z*1.7; n.ang=Math.atan2(-d.x,-d.z); const SN=Game.SpaceNPC, sr=SN?SN.tick(n,dt,time):0;
      if(sr===2){ held=null; } else { if(!sr) n.hp-=dt*.16;
      if(n.hp<=0&&!n.dead){ n.dead=true; Game.Gore.hit(n.hx,n.hy-.3,n.hz,0,-1,0,.5); held=null; NPC.release(n,0,-1,0); } if(sr!==1&&Math.random()<dt*20) FX.spark(n.hx,n.hy-.1,n.hz,1,1.5,[1,.6,.4]); } } }
  beam.visible=glow.visible=wantLaser; if(wantLaser) laser(dt,time);
  if(wantLaser!==laserOn){ laserOn=wantLaser; if(au()) au().loop("laser",laserOn); }
  if(wantBr) breath(wantBr,dt); if(wantBr!==brOn){ brOn=wantBr; if(au()){ au().loop("fire",brOn==="fire"); au().loop("ice",brOn==="ice"); } }
  if(clapT>=0){ clapT+=dt; const s=1+clapT*68; ring.visible=clapT<.6; ring.scale.set(s,s,1); ringMat.opacity=Math.max(0,1-clapT/.6); if(clapT>=.6) clapT=-1; }
  if(H.boost&&!bPrev&&H.speed>40){ sonT=0; sonic.position.copy(hero.position); FX.shock(hero.position.x,hero.position.y,hero.position.z,30,20); Game.shakeAdd(.6); } bPrev=H.boost;
  if(sonT>=0){ sonT+=dt; const s=3+sonT*120; sonic.visible=sonT<.5; sonic.scale.set(s,s,s); sonic.rotation.x=Math.PI/2; sonicMat.opacity=Math.max(0,1-sonT/.5); if(sonT>=.5) sonT=-1; }
  if(au()) au().wind(Game.Mounted&&Game.Mounted()?Game.Mounted().wind:(H.flying?H.speed*(1-H.sp):0));
},{__menu:true}));
Game.dropHeld=()=>{ if(held&&held.st==="held") NPC.release(held,0,0,0); held=null; if(Game.Lift&&Game.Lift.active) Game.Lift.drop(); };
})();
