"use strict";
/* ===== LAV NEFESİ: Neon Ejderha (CHARS.neondrake.mouthFire) için göz lazeri yerine AĞIZDAN LAV ATEŞİ =====
   Ateş/lazer tuşu basılıyken; aynı tuş göz lazeri yerine bu modülü çalıştırır (powers.js: wantLaser=false). Koni içindeki her şeyi yakar,
   binaları kırar+tutuşturur, yere çarpan lav sıçrar. */
(function(){
const A=Game.input.actions, H=Game.H, hero=Game.heroObj, D=Game.D, NPC=Game.NPC, Cars=Game.Cars, FX=Game.FX, U=Game.U, au=()=>Game.audio, on=n=>Game.powersOn[n]!==false;
const V3=THREE.Vector3, mouth=new V3(), pt=new V3(), R=(a,b)=>a+Math.random()*(b-a), rs=U.rs;
const npcPos=n=>n.body?n.body.position:{x:n.x,y:n.y+.95*(NPC.scale||1.3),z:n.z};
function inCone(p,m,d,range,tanH,pad){ const vx=p.x-m.x,vy=p.y-m.y,vz=p.z-m.z, t=vx*d.x+vy*d.y+vz*d.z; if(t<0||t>range) return false; const l2=vx*vx+vy*vy+vz*vz-t*t; const w=t*tanH+(pad||1.2); return l2<w*w; }
function igniteSphere(x,y,z,r,chance){ for(const e of Game.buildings){ const t=e.tier; if(!t||e.h<=0) continue; if(Math.hypot(e.x-x,e.z-z)>r+Math.max(e.hw,e.hd)) continue; for(const c of t.chunks){ if(!c.alive||Math.random()>chance) continue; if(Math.hypot(c.x-x,c.y-y,c.z-z)<r) D.ignite(c); } } }
const RANGE=30, TH=.3;
const st={on:false,hit:0,aS:0,aG:0,aK:0,aM:0,aP:0,t:0,mx:0,my:0,mz:0,hx:0,hy:0,hz:0,hasHit:false,ticks:0};
const api=Game.LavaBreath={ get active(){ return st.on; }, st, range:RANGE };

function mouthPos(){ const L=Game.lookV, m=Game.model, ex=m&&m.userData&&m.userData.extra&&m.userData.extra.mouth;
  if(Game.settings.cam==="1p"){ mouth.copy(camera.position).addScaledVector(L,1.2); mouth.y-=.35; return; }
  if(ex){ hero.updateMatrixWorld(true); ex.getWorldPosition(mouth); }
  else mouth.set(hero.position.x,hero.position.y+.5,hero.position.z).addScaledVector(L,1.4);
  /* ağız bakış yönünün önünde dursun (uçarken kafa eğimi geç kalabilir) */
  const dx=mouth.x-hero.position.x, dy=mouth.y-hero.position.y, dz=mouth.z-hero.position.z; if(dx*L.x+dy*L.y+dz*L.z<.5) mouth.set(hero.position.x,hero.position.y+.5,hero.position.z).addScaledVector(L,1.4); }

function emit(dt){ const L=Game.lookV, vx=H.vel.x*.5, vy=H.vel.y*.5, vz=H.vel.z*.5;
  st.aS+=dt*760; st.aG+=dt*190; st.aK+=dt*70; st.aM+=dt*26; let n=0;
  while(st.aS>=1&&n++<60){ st.aS--; const sp=R(26,38), j=TH*sp*.8;   /* ana akım: sıcak beyaz-sarı -> turuncu -> kızıl */
    FX.E(true,mouth.x,mouth.y,mouth.z,L.x*sp+rs()*j+vx,L.y*sp+rs()*j+vy,L.z*sp+rs()*j+vz,R(.45,.85),R(.9,1.3),R(2.2,3.4),[1,.95,.6],[1,.28,.03],.9,2.5,.96); }
  n=0; while(st.aG>=1&&n++<20){ st.aG--; const sp=R(16,30), j=TH*sp*1.6;  /* lav damlaları: kavis çizip düşer */
    FX.E(false,mouth.x,mouth.y,mouth.z,L.x*sp+rs()*j+vx,L.y*sp+rs()*j+3+vy,L.z*sp+rs()*j+vz,R(1.1,1.9),R(.5,.8),R(.7,1.1),[1,.5,.08],[.22,.03,0],.92,17,.995); }
  n=0; while(st.aK>=1&&n++<10){ st.aK--; const sp=R(20,40);   /* neon sarı kıvılcımlar */
    FX.E(true,mouth.x,mouth.y,mouth.z,L.x*sp+rs()*9,L.y*sp+rs()*9,L.z*sp+rs()*9,R(.35,.8),R(.25,.45),.04,[1,.96,.25],[1,.55,.05],1,9,.97); }
  n=0; while(st.aM>=1&&n++<6){ st.aM--; FX.smoke(mouth.x+L.x*R(3,12),mouth.y+L.y*R(3,12)+1,mouth.z+L.z*R(3,12),1,1.1); }
  FX.glow(mouth.x,mouth.y,mouth.z,1.7+Math.random()*.6,[1,.55,.12],.08); }

function strike(dt){ const L=Game.lookV, r=D.ray(mouth.x,mouth.y,mouth.z,L.x,L.y,L.z,RANGE); st.hasHit=r.kind!=="none"&&r.t<RANGE;
  if(st.hasHit){ st.hx=mouth.x+L.x*r.t; st.hy=mouth.y+L.y*r.t; st.hz=mouth.z+L.z*r.t;
    st.aP+=dt*60; let k=0; while(st.aP>=1&&k++<4){ st.aP--; FX.E(true,st.hx,st.hy,st.hz,rs()*10,R(2,9),rs()*10,R(.4,.9),R(.8,1.5),.2,[1,.8,.3],[.8,.1,.0],.85,16,.96); }
    if(Math.random()<dt*14) FX.fire(st.hx,st.hy,st.hz,1,0,1.5,0,1.4); FX.glow(st.hx,st.hy+.2,st.hz,3.2+Math.random(),[1,.5,.08],.08); }
  st.hit-=dt; if(st.hit>0) return; st.hit=.12; st.ticks++;
  for(const n of NPC.list){ if(!n.vis||n.dead&&!n.body) continue; const p=npcPos(n); if(!inCone(p,mouth,L,RANGE,TH,1.5)) continue; NPC.burn(n);
    if(!n.dead){ n.lvt=(n.lvt||0)+.12; if(n.lvt>.55){ n.lvt=0; NPC.hit(n,L.x*9,6,L.z*9,"boom"); } } }
  Cars.query(mouth.x,mouth.z,RANGE+3,(k,i,px,pz)=>{ pt.set(px,.9,pz); if(inCone(pt,mouth,L,RANGE,TH,2.6)) Cars.burn(k,i); });
  if(Game.Sea) Game.Sea.breath(mouth.x,mouth.y,mouth.z,L,RANGE,TH,true,.12);
  for(const e of Game.buildings){ const t=e.tier; if(!t||e.h<=0) continue; const dx=Math.max(Math.abs(mouth.x-e.x)-e.hw,0), dz=Math.max(Math.abs(mouth.z-e.z)-e.hd,0); if(dx*dx+dz*dz>RANGE*RANGE) continue;
    for(const c of t.chunks){ if(!c.alive) continue; pt.set(c.x,c.y,c.z); if(!inCone(pt,mouth,L,RANGE,TH,Math.max(c.sx,c.sy,c.sz)*.6)) continue; D.dmg(c,.2,L.x*6,L.y*6+1,L.z*6); if(Math.random()<.55) D.ignite(c); } }
  if(st.hasHit){ D.damageSphere(st.hx,st.hy,st.hz,2.6,.35,14,true); igniteSphere(st.hx,st.hy,st.hz,3,.22); }
  if(NPC.noise) NPC.noise(mouth.x,mouth.z,45); }

function stop(){ if(!st.on) return; st.on=false; if(au()) au().loop("fire",false); }
Game.updaters.push((dt0,time,raw)=>{ const dt=Math.min(.05,raw||dt0);
  const mf=Game.mode==="play"&&CHARS[Game.char]&&CHARS[Game.char].mouthFire;
  if(!mf||!A.laser||!on("laser")){ stop(); return; }
  if(!st.on){ st.on=true; st.hit=0; st.t=0; if(au()){ au().loop("fire",true); if(au().whoosh) au().whoosh(); } }
  st.t+=dt; mouthPos(); emit(dt); strike(dt); Game.shakeAdd&&Game.shakeAdd(.05); });
})();
