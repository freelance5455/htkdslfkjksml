"use strict";
/* ===== v8 yeni metinler: bölgeler (mahalle / merkez / kasaba), Mısır adası, ağaç kırma. Önce tr+en; diğer diller İngilizceye düşer. ===== */
(function(){
const X={
tr:{d_core:"Şehir Merkezi",d_biz:"İş Merkezi",d_old:"Eski Çarşı",d_ind:"Sanayi Bölgesi",d_apt:"Apartman Mahallesi",d_mod:"Modern Mahalle",d_row:"Sıra Ev Mahallesi",d_villa:"Villa Mahallesi",d_cot:"Eski Mahalle",d_gar:"Banliyö Mahallesi",d_grn:"Park Bölgesi",d_town:"Kasaba",d_farm:"Tarım Alanı",d_forest:"Orman / Göl",
 t_tree:"Ağaç kırıldı!",t_camel:"Devenin ruhu göğe yükseldi…",t_pharaoh:"Firavun heykeli çatladı! Gözleri kızarıyor…",t_pharaoh2:"Heykelin gözleri patladı!"},
en:{d_core:"Downtown",d_biz:"Business District",d_old:"Old Town",d_ind:"Industrial Zone",d_apt:"Apartment Quarter",d_mod:"Modern Quarter",d_row:"Terrace Houses",d_villa:"Villa District",d_cot:"Old Neighbourhood",d_gar:"Suburb",d_grn:"Park District",d_town:"Town",d_farm:"Farmland",d_forest:"Forest / Lake",
 t_tree:"Tree broken!",t_camel:"The camel's spirit rises to the sky…",t_pharaoh:"The pharaoh statue cracked! Its eyes glow red…",t_pharaoh2:"The statue's eyes exploded!"}
};
for(const k in X) Object.assign(LANGS[k],X[k]);
})();
