"use strict";
/* ===== v2 ek metinler (7 dil) ===== */
(function(){
const X={
tr:{chars:"Karakterler",powers:"Güçler",colors:"Renkler",select:"Seç",selected:"Seçili",on:"Açık",off:"Kapalı",isnew:"YENİ",rotate:"Lütfen cihazı yatay çevirin",resume:"Devam et",mainmenu:"Ana menü",paused:"Duraklatıldı",default:"Varsayılan",
c_classic:"Klasik Kahraman",c_pharaoh:"Firavun",c_poseidon:"Poseidon",c_zeus:"Zeus",
p_fly:"Uçuş",p_punch:"Yumruk",p_choke:"Boğazlama",p_clap:"Alkış",p_laser:"Lazer",p_freeze:"Dondurma",p_fire:"Ateş",
q_fly:"Havalan; joystick'i sonuna itince ses hızını aş.",q_punch:"Yakındaki her şeyi parçala.",q_choke:"En yakın kişiyi havaya kaldır. Yumrukla fırlat.",q_clap:"Şok dalgasıyla insanları ve arabaları savur.",q_laser:"Gözlerinden yakıcı ışın.",q_freeze:"Buz soluğu: her şeyi dondurur, dondurulanlar kırılır.",q_fire:"Alev soluğu: yakar, binalara yayılır."},
en:{chars:"Characters",powers:"Powers",colors:"Colors",select:"Select",selected:"Selected",on:"On",off:"Off",isnew:"NEW",rotate:"Please rotate your device to landscape",resume:"Resume",mainmenu:"Main menu",paused:"Paused",default:"Default",
c_classic:"Classic Hero",c_pharaoh:"Pharaoh",c_poseidon:"Poseidon",c_zeus:"Zeus",
p_fly:"Flight",p_punch:"Punch",p_choke:"Chokehold",p_clap:"Clap",p_laser:"Laser",p_freeze:"Freeze",p_fire:"Fire",
q_fly:"Take off; push the stick fully to break the sound barrier.",q_punch:"Smash everything close by.",q_choke:"Lift the nearest person. Punch to throw.",q_clap:"A shockwave that hurls people and cars.",q_laser:"A burning beam from your eyes.",q_freeze:"Icy breath: freezes everything, frozen things shatter.",q_fire:"Fire breath: burns and spreads across buildings."},
de:{chars:"Charaktere",powers:"Kräfte",colors:"Farben",select:"Wählen",selected:"Gewählt",on:"An",off:"Aus",isnew:"NEU",rotate:"Bitte Gerät ins Querformat drehen",resume:"Weiter",mainmenu:"Hauptmenü",paused:"Pausiert",default:"Standard",
c_classic:"Klassischer Held",c_pharaoh:"Pharao",c_poseidon:"Poseidon",c_zeus:"Zeus",
p_fly:"Flug",p_punch:"Schlag",p_choke:"Würgegriff",p_clap:"Klatschen",p_laser:"Laser",p_freeze:"Einfrieren",p_fire:"Feuer",
q_fly:"Abheben; Stick ganz drücken für Überschall.",q_punch:"Zerschmettere alles in der Nähe.",q_choke:"Hebe die nächste Person hoch. Schlag wirft sie.",q_clap:"Eine Druckwelle schleudert Menschen und Autos weg.",q_laser:"Ein brennender Strahl aus den Augen.",q_freeze:"Eisatem: friert alles ein, Eingefrorenes zerbricht.",q_fire:"Feueratem: verbrennt und greift auf Gebäude über."},
ar:{chars:"الشخصيات",powers:"القوى",colors:"الألوان",select:"اختر",selected:"مختار",on:"مفعّل",off:"متوقف",isnew:"جديد",rotate:"يرجى تدوير الجهاز بشكل أفقي",resume:"متابعة",mainmenu:"القائمة الرئيسية",paused:"متوقف مؤقتًا",default:"افتراضي",
c_classic:"البطل الكلاسيكي",c_pharaoh:"الفرعون",c_poseidon:"بوسيدون",c_zeus:"زيوس",
p_fly:"الطيران",p_punch:"لكمة",p_choke:"الخنق",p_clap:"التصفيق",p_laser:"الليزر",p_freeze:"التجميد",p_fire:"النار",
q_fly:"حلّق؛ ادفع العصا بالكامل لتخترق حاجز الصوت.",q_punch:"حطّم كل ما حولك.",q_choke:"ارفع أقرب شخص. اللكمة ترميه.",q_clap:"موجة صدمة تقذف الناس والسيارات.",q_laser:"شعاع حارق من عينيك.",q_freeze:"نفَس جليدي يجمّد كل شيء ويتحطم المجمّد.",q_fire:"نفَس ناري يحرق ويمتد إلى المباني."},
fr:{chars:"Personnages",powers:"Pouvoirs",colors:"Couleurs",select:"Choisir",selected:"Choisi",on:"Actif",off:"Inactif",isnew:"NOUVEAU",rotate:"Veuillez tourner l'appareil en mode paysage",resume:"Reprendre",mainmenu:"Menu principal",paused:"En pause",default:"Défaut",
c_classic:"Héros classique",c_pharaoh:"Pharaon",c_poseidon:"Poséidon",c_zeus:"Zeus",
p_fly:"Vol",p_punch:"Coup de poing",p_choke:"Étranglement",p_clap:"Claquement",p_laser:"Laser",p_freeze:"Gel",p_fire:"Feu",
q_fly:"Décolle ; pousse le stick à fond pour passer le mur du son.",q_punch:"Fracasse tout ce qui est proche.",q_choke:"Soulève la personne la plus proche. Un coup la projette.",q_clap:"Une onde de choc projette gens et voitures.",q_laser:"Un rayon brûlant sorti des yeux.",q_freeze:"Souffle glacé : gèle tout, le gelé se brise.",q_fire:"Souffle de feu : brûle et gagne les bâtiments."},
ko:{chars:"캐릭터",powers:"능력",colors:"색상",select:"선택",selected:"선택됨",on:"켜짐",off:"꺼짐",isnew:"신규",rotate:"기기를 가로로 돌려 주세요",resume:"계속",mainmenu:"메인 메뉴",paused:"일시정지",default:"기본",
c_classic:"클래식 히어로",c_pharaoh:"파라오",c_poseidon:"포세이돈",c_zeus:"제우스",
p_fly:"비행",p_punch:"펀치",p_choke:"목 조르기",p_clap:"박수",p_laser:"레이저",p_freeze:"냉동",p_fire:"불",
q_fly:"날아오르기. 스틱을 끝까지 밀면 음속을 돌파합니다.",q_punch:"가까운 모든 것을 부숩니다.",q_choke:"가장 가까운 사람을 들어 올립니다. 펀치로 던집니다.",q_clap:"충격파로 사람과 자동차를 날립니다.",q_laser:"눈에서 나오는 불타는 광선.",q_freeze:"얼음 숨결: 모든 것을 얼리고 언 것은 부서집니다.",q_fire:"불꽃 숨결: 태우고 건물로 번집니다."},
ja:{chars:"キャラクター",powers:"能力",colors:"カラー",select:"選ぶ",selected:"選択中",on:"オン",off:"オフ",isnew:"新",rotate:"端末を横向きにしてください",resume:"再開",mainmenu:"メインメニュー",paused:"一時停止",default:"標準",
c_classic:"クラシックヒーロー",c_pharaoh:"ファラオ",c_poseidon:"ポセイドン",c_zeus:"ゼウス",
p_fly:"飛行",p_punch:"パンチ",p_choke:"首絞め",p_clap:"拍手",p_laser:"レーザー",p_freeze:"凍結",p_fire:"炎",
q_fly:"飛び立つ。スティックを最大に倒すと音速を超える。",q_punch:"近くのものを粉砕する。",q_choke:"最も近い人を持ち上げる。パンチで投げる。",q_clap:"衝撃波で人と車を吹き飛ばす。",q_laser:"目から放つ灼熱の光線。",q_freeze:"氷の息：すべてを凍らせ、凍ったものは砕ける。",q_fire:"炎の息：燃やし、建物に燃え広がる。"}
};
for(const k in X) Object.assign(LANGS[k],X[k]);
})();
