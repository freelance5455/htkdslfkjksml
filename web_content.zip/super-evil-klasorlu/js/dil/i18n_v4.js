"use strict";
/* ===== v4 ek metinler (7 dil): Ultra grafik, kamera, +18 sansür, haritalar ===== */
(function(){
const X={
tr:{ultra:"Ultra",ultra_hint:"Sinematik hava, ışık huzmeleri, film efekti. iPad'i yorabilir.",camera:"Kamera",cam3p:"Arkadan",cam1p:"Göz görüşü",cam_t3:"Kamera: arkadan bakış",cam_t1:"Kamera: göz görüşü",
censor:"+18 Sansür",censor_on:"Açık: kan, parçalanma ve vahşet efektleri kapalı.",censor_off:"Kapalı: kan, kesme ve parçalama efektleri açık (+18).",censor_warn:"+18: Bu seçenek kan ve şiddet içerir. 18 yaş ve üzeriysen devam et.",
maps:"Haritalar",maps_note:"Harita değişince oyun yeniden yüklenir.",map_sel:"Seçili",map_go:"Seç",
map_metro:"Metropol",map_suburb:"Banliyö",map_downtown:"Gökdelen Merkezi",map_desert:"Çöl Şehri",map_snow:"Karlı Şehir",map_neon:"Neon Gece",map_ruins:"Yıkık Şehir",
md_metro:"Dengeli şehir: gökdelenler, parklar, hastane, okul ve karakol.",md_suburb:"Alçak evler, bahçeler ve geniş sokaklar. Sakin ve açık.",md_downtown:"Sık gökdelenler, gün batımı ışığı. Yıkmak için ideal.",md_desert:"Kuru, sıcak ve sarı. Toz ve uzak ufuk sisi.",md_snow:"Her yer karla kaplı; kar yağıyor, hava soğuk mavi.",md_neon:"Mor-pembe gece, parlayan neon ışıklar.",md_ruins:"Savaştan kalma harabe: yıkık binalar, duman, kül yağışı."},
en:{ultra:"Ultra",ultra_hint:"Cinematic atmosphere, light shafts, film look. Can be heavy on iPad.",camera:"Camera",cam3p:"Behind",cam1p:"First person",cam_t3:"Camera: third person",cam_t1:"Camera: first person",
censor:"18+ Censorship",censor_on:"On: blood, dismemberment and gore effects are hidden.",censor_off:"Off: blood, cutting and dismemberment effects are enabled (18+).",censor_warn:"18+: This option contains blood and violence. Continue only if you are 18 or older.",
maps:"Maps",maps_note:"The game reloads when the map changes.",map_sel:"Selected",map_go:"Select",
map_metro:"Metropolis",map_suburb:"Suburbs",map_downtown:"Skyscraper District",map_desert:"Desert City",map_snow:"Snow City",map_neon:"Neon Night",map_ruins:"Ruined City",
md_metro:"Balanced city: skyscrapers, parks, hospital, school and police.",md_suburb:"Low houses, gardens and wide streets. Calm and open.",md_downtown:"Dense towers in sunset light. Perfect for demolition.",md_desert:"Dry, hot and golden. Dust and a hazy horizon.",md_snow:"Everything under snow; it is snowing, the air is cold blue.",md_neon:"A purple-pink night with glowing neon.",md_ruins:"A war-torn wasteland: collapsed buildings, smoke, falling ash."},
de:{ultra:"Ultra",ultra_hint:"Filmische Atmosphäre, Lichtstrahlen, Kino-Look. Kann das iPad stark belasten.",camera:"Kamera",cam3p:"Von hinten",cam1p:"Ego-Perspektive",cam_t3:"Kamera: von hinten",cam_t1:"Kamera: Ego-Perspektive",
censor:"18+ Zensur",censor_on:"An: Blut, Zerstückelung und Gore-Effekte sind ausgeblendet.",censor_off:"Aus: Blut-, Schnitt- und Zerstückelungseffekte aktiv (18+).",censor_warn:"18+: Diese Option enthält Blut und Gewalt. Nur fortfahren, wenn du mindestens 18 bist.",
maps:"Karten",maps_note:"Beim Kartenwechsel wird das Spiel neu geladen.",map_sel:"Gewählt",map_go:"Wählen",
map_metro:"Metropole",map_suburb:"Vorort",map_downtown:"Wolkenkratzer-Viertel",map_desert:"Wüstenstadt",map_snow:"Schneestadt",map_neon:"Neon-Nacht",map_ruins:"Zerstörte Stadt",
md_metro:"Ausgewogene Stadt: Hochhäuser, Parks, Krankenhaus, Schule und Polizei.",md_suburb:"Niedrige Häuser, Gärten und breite Straßen. Ruhig und offen.",md_downtown:"Dichte Türme im Abendlicht. Ideal zum Zerstören.",md_desert:"Trocken, heiß und golden. Staub und dunstiger Horizont.",md_snow:"Alles unter Schnee; es schneit, die Luft ist kaltblau.",md_neon:"Eine lila-rosa Nacht mit leuchtendem Neon.",md_ruins:"Kriegsruine: eingestürzte Gebäude, Rauch, Ascheregen."},
ar:{ultra:"فائق",ultra_hint:"أجواء سينمائية وأشعة ضوء ومظهر فيلم. قد يكون ثقيلاً على الآيباد.",camera:"الكاميرا",cam3p:"من الخلف",cam1p:"منظور الشخص الأول",cam_t3:"الكاميرا: من الخلف",cam_t1:"الكاميرا: منظور الشخص الأول",
censor:"رقابة +18",censor_on:"مفعّلة: الدماء والتقطيع والعنف مخفية.",censor_off:"معطّلة: تأثيرات الدماء والقطع والتمزيق مفعّلة (+18).",censor_warn:"+18: يحتوي هذا الخيار على دماء وعنف. تابع فقط إذا كان عمرك 18 عاماً أو أكثر.",
maps:"الخرائط",maps_note:"تتم إعادة تحميل اللعبة عند تغيير الخريطة.",map_sel:"محددة",map_go:"اختر",
map_metro:"المدينة الكبرى",map_suburb:"الضواحي",map_downtown:"حي ناطحات السحاب",map_desert:"مدينة الصحراء",map_snow:"مدينة الثلج",map_neon:"ليل النيون",map_ruins:"مدينة مدمّرة",
md_metro:"مدينة متوازنة: ناطحات سحاب وحدائق ومستشفى ومدرسة وشرطة.",md_suburb:"منازل منخفضة وحدائق وشوارع واسعة. هادئة ومفتوحة.",md_downtown:"أبراج كثيفة في ضوء الغروب. مثالية للهدم.",md_desert:"جافة وحارة وذهبية. غبار وأفق ضبابي.",md_snow:"كل شيء تحت الثلج؛ الثلج يتساقط والهواء أزرق بارد.",md_neon:"ليل بنفسجي وردي مع أضواء نيون متوهجة.",md_ruins:"أرض خراب بعد الحرب: مبانٍ منهارة ودخان ورماد متساقط."},
fr:{ultra:"Ultra",ultra_hint:"Atmosphère cinématographique, rayons de lumière, rendu film. Peut être lourd sur iPad.",camera:"Caméra",cam3p:"De dos",cam1p:"Vue subjective",cam_t3:"Caméra : vue de dos",cam_t1:"Caméra : vue subjective",
censor:"Censure 18+",censor_on:"Activée : sang, démembrement et effets gore masqués.",censor_off:"Désactivée : effets de sang, de découpe et de démembrement actifs (18+).",censor_warn:"18+ : cette option contient du sang et de la violence. Continue seulement si tu as 18 ans ou plus.",
maps:"Cartes",maps_note:"Le jeu se recharge quand la carte change.",map_sel:"Choisie",map_go:"Choisir",
map_metro:"Métropole",map_suburb:"Banlieue",map_downtown:"Quartier des gratte-ciel",map_desert:"Ville du désert",map_snow:"Ville enneigée",map_neon:"Nuit néon",map_ruins:"Ville en ruines",
md_metro:"Ville équilibrée : gratte-ciel, parcs, hôpital, école et police.",md_suburb:"Maisons basses, jardins et larges rues. Calme et ouvert.",md_downtown:"Tours serrées sous la lumière du couchant. Idéal pour tout démolir.",md_desert:"Sec, chaud et doré. Poussière et horizon brumeux.",md_snow:"Tout est sous la neige ; il neige, l'air est d'un bleu glacé.",md_neon:"Une nuit violet-rose aux néons éclatants.",md_ruins:"Un champ de ruines : bâtiments effondrés, fumée, pluie de cendres."},
ko:{ultra:"울트라",ultra_hint:"영화 같은 분위기, 빛줄기, 필름 효과. iPad에서는 무거울 수 있습니다.",camera:"카메라",cam3p:"뒤에서",cam1p:"1인칭",cam_t3:"카메라: 3인칭",cam_t1:"카메라: 1인칭",
censor:"18+ 검열",censor_on:"켜짐: 피, 신체 절단, 잔혹 효과가 숨겨집니다.",censor_off:"꺼짐: 피, 절단, 신체 파괴 효과가 활성화됩니다 (18+).",censor_warn:"18+: 이 옵션에는 피와 폭력이 포함됩니다. 만 18세 이상만 계속하세요.",
maps:"맵",maps_note:"맵을 바꾸면 게임이 다시 로드됩니다.",map_sel:"선택됨",map_go:"선택",
map_metro:"대도시",map_suburb:"교외",map_downtown:"마천루 지구",map_desert:"사막 도시",map_snow:"눈의 도시",map_neon:"네온 나이트",map_ruins:"폐허 도시",
md_metro:"균형 잡힌 도시: 고층 빌딩, 공원, 병원, 학교, 경찰서.",md_suburb:"낮은 주택, 정원, 넓은 거리. 조용하고 탁 트임.",md_downtown:"노을빛 속 빽빽한 빌딩. 부수기에 최고.",md_desert:"건조하고 뜨겁고 황금빛. 먼지와 뿌연 지평선.",md_snow:"모든 것이 눈에 덮여 있고 눈이 내립니다. 차가운 푸른 공기.",md_neon:"빛나는 네온의 보라-분홍빛 밤.",md_ruins:"전쟁의 폐허: 무너진 건물, 연기, 떨어지는 재."},
ja:{ultra:"ウルトラ",ultra_hint:"映画のような大気、光の筋、フィルム効果。iPadでは重くなることがあります。",camera:"カメラ",cam3p:"背後から",cam1p:"一人称",cam_t3:"カメラ：三人称",cam_t1:"カメラ：一人称",
censor:"18+ 検閲",censor_on:"オン：流血・切断・残虐表現は非表示です。",censor_off:"オフ：流血・切断・破壊表現が有効です（18+）。",censor_warn:"18+：このオプションには流血と暴力表現が含まれます。18歳以上の方のみ続けてください。",
maps:"マップ",maps_note:"マップを変更するとゲームが再読み込みされます。",map_sel:"選択中",map_go:"選ぶ",
map_metro:"大都市",map_suburb:"郊外",map_downtown:"摩天楼地区",map_desert:"砂漠の街",map_snow:"雪の街",map_neon:"ネオンナイト",map_ruins:"廃墟の街",
md_metro:"バランスの良い街：高層ビル、公園、病院、学校、警察署。",md_suburb:"低い家々、庭、広い道。静かで開放的。",md_downtown:"夕焼けに染まる密集した高層ビル。破壊に最適。",md_desert:"乾いて暑い黄金色。砂ぼこりとかすむ地平線。",md_snow:"すべてが雪に覆われ、雪が降っています。冷たい青の空気。",md_neon:"輝くネオンの紫ピンクの夜。",md_ruins:"戦火の廃墟：崩れた建物、煙、降り注ぐ灰。"}
};
for(const k in X) Object.assign(LANGS[k],X[k]);
})();
