"use strict";
/* ===== Ejderha Dağı + UFO metinleri: [tr,en,de,ar,fr,ko,ja,ru,es,zh,pt,it,hi] ===== */
Game.L10({
z_dragon:["Ejderha Dağı","Dragon Mountain","Drachenberg","جبل التنين","Montagne du Dragon","용의 산","ドラゴン山","Драконья гора","Montaña del Dragón","龙山","Montanha do Dragão","Montagna del Drago","ड्रैगन पर्वत"],
t_dragon_wake:["Ejderha uyandı!","The dragon awakens!","Der Drache erwacht!","استيقظ التنين!","Le dragon se réveille !","용이 깨어났다!","ドラゴンが目覚めた！","Дракон проснулся!","¡El dragón despierta!","巨龙苏醒了！","O dragão despertou!","Il drago si risveglia!","ड्रैगन जाग गया!"],
t_dragon_dead:["Ejderha yenildi! Hazine senin!","Dragon slain! The hoard is yours!","Drache besiegt! Der Schatz gehört dir!","هُزم التنين! الكنز لك!","Dragon vaincu ! Le trésor est à toi !","용 처치! 보물은 네 것이다!","ドラゴン討伐！宝は君のものだ！","Дракон повержен! Сокровища твои!","¡Dragón derrotado! ¡El tesoro es tuyo!","击败巨龙！宝藏归你！","Dragão derrotado! O tesouro é seu!","Drago sconfitto! Il tesoro è tuo!","ड्रैगन हारा! खज़ाना तुम्हारा!"],
t_chest:["Hazine sandığı!","Treasure chest!","Schatztruhe!","صندوق كنز!","Coffre au trésor !","보물 상자!","宝箱！","Сундук с сокровищами!","¡Cofre del tesoro!","宝箱！","Baú do tesouro!","Forziere del tesoro!","खज़ाने का संदूक!"],
t_ufo:["Bir UFO yaklaşıyor!","A UFO is approaching!","Ein UFO nähert sich!","جسم طائر مجهول يقترب!","Un OVNI approche !","UFO가 다가온다!","UFOが接近中！","Приближается НЛО!","¡Se acerca un OVNI!","发现不明飞行物！","Um OVNI se aproxima!","Un UFO si avvicina!","एक UFO पास आ रहा है!"],
t_ufo_down:["UFO düşürüldü!","UFO shot down!","UFO abgeschossen!","تم إسقاط الجسم الطائر!","OVNI abattu !","UFO 격추!","UFO撃墜！","НЛО сбит!","¡OVNI derribado!","击落不明飞行物！","OVNI abatido!","UFO abbattuto!","UFO मार गिराया!"],
t_ufo_gone:["UFO uzaklaştı...","The UFO flew away...","Das UFO ist davongeflogen...","ابتعد الجسم الطائر...","L’OVNI s’est éloigné...","UFO가 사라졌다...","UFOは去っていった…","НЛО улетел…","El OVNI se alejó...","不明飞行物飞走了…","O OVNI foi embora...","L’UFO si è allontanato...","UFO चला गया…"]
});
