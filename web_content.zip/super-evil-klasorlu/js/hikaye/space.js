"use strict";
/* ===== UZAY: yükseldikçe atmosfer incelir, gökyüzü kararır, gezegen/yıldız/bulutsu (sky shader), göktaşı kuşağı, akan yıldızlar, yer çekimi azalır ===== */
Game.Space=(function(){
  const SU=Game.skyU, H=Game.H, hero=Game.heroObj, T=Game.tod, FX=Game.FX, D=Game.D;
  /* --- göktaşı kuşağı (tek InstancedMesh) --- */
  const N=260, ast=[], rnd=(()=>{ let s=90210; return ()=>{ s=(s*1664525+1013904223)>>>0; return s/4294967296; }; })();
  const ig=new THREE.IcosahedronGeometry(1,1), pa=ig.attributes.position; for(let i=0;i<pa.count;i++){ const x=pa.getX(i), y=pa.getY(i), z=pa.getZ(i), k=1+(Math.sin(x*5.1+y*3.7)*Math.cos(z*4.3+x*2.1))*.28+(Math.sin(y*9.3+z*7.7))*.1; pa.setXYZ(i,x*k,y*k*.85,z*k); }
  if(ig.computeVertexNormals) ig.computeVertexNormals();
  const am=new THREE.MeshStandardMaterial({color:0x8a8178,roughness:.95,metalness:.05,flatShading:true}), mesh=new THREE.InstancedMesh(ig,am,N); mesh.frustumCulled=false; mesh.visible=false; mesh.castShadow=false; scene.add(mesh);
  const col=new THREE.Color(), dum=new THREE.Object3D();
  for(let i=0;i<N;i++){ const r=4*Math.pow(10,rnd()*1.0), a=rnd()*6.283, d=Math.sqrt(rnd())*7500; ast.push({x:Math.cos(a)*d,y:3800+Math.pow(rnd(),1.6)*24000,z:Math.sin(a)*d,r,rx:rnd()*6,ry:rnd()*6,sx:(rnd()-.5)*.25,sy:(rnd()-.5)*.25,alive:true,hp:r});
    const g=.45+rnd()*.35, tint=rnd(); col.setRGB(g*(1+tint*.25),g*(1-tint*.05),g*(1-tint*.2)); mesh.setColorAt(i,col); }
  if(mesh.instanceColor) mesh.instanceColor.needsUpdate=true;
  function writeAst(i,time){ const a=ast[i]; dum.position.set(a.x,a.y,a.z); dum.rotation.set(a.rx+a.sx*time,a.ry+a.sy*time,0); const s=a.alive?a.r:0; dum.scale.set(s,s,s); dum.updateMatrix(); mesh.setMatrixAt(i,dum.matrix); }
  /* --- akan yıldızlar / meteorlar --- */
  const NM=28, mm=new THREE.InstancedMesh(new THREE.BoxGeometry(1,1,1),new THREE.MeshBasicMaterial({color:0xffd9a8,transparent:true,opacity:.9,blending:THREE.AdditiveBlending,depthWrite:false}),NM); mm.frustumCulled=false; mm.count=0; scene.add(mm);
  const sm=[], UPv=new THREE.Vector3(0,1,0), dv=new THREE.Vector3(), qq=new THREE.Quaternion(); let spawnT=0;
  function spawnMeteor(){ const c=camera.position, a=Math.random()*6.283, e=(Math.random()-.3)*1.2, R=500+Math.random()*900;
    const px=c.x+Math.cos(a)*Math.cos(e)*R, py=c.y+Math.sin(e)*R, pz=c.z+Math.sin(a)*Math.cos(e)*R, b=a+Math.PI/2+(Math.random()-.5)*1.2, sp=500+Math.random()*700, up=(Math.random()-.5)*.6;
    sm.push({x:px,y:py,z:pz,vx:Math.cos(b)*sp,vy:up*sp,vz:Math.sin(b)*sp,life:1.2+Math.random()*1.4,max:0,len:60+Math.random()*120,w:.8+Math.random()*1.6}); sm[sm.length-1].max=sm[sm.length-1].life; }
  function updMeteors(dt,k){ spawnT-=dt; if(k>.3&&spawnT<=0&&sm.length<NM){ spawnT=.12+Math.random()*.4*(1.2-k); spawnMeteor(); }
    let n=0; for(let i=sm.length-1;i>=0;i--){ const m=sm[i]; m.life-=dt; if(m.life<=0){ sm.splice(i,1); continue; } m.x+=m.vx*dt; m.y+=m.vy*dt; m.z+=m.vz*dt; }
    for(const m of sm){ if(n>=NM) break; const f=Math.min(1,m.life/m.max*3)*Math.min(1,(m.max-m.life)*5); dv.set(m.vx,m.vy,m.vz).normalize(); qq.setFromUnitVectors(UPv,dv); dum.position.set(m.x-dv.x*m.len*.5,m.y-dv.y*m.len*.5,m.z-dv.z*m.len*.5); dum.quaternion.copy(qq); dum.scale.set(m.w*f,m.len*f,m.w*f); dum.updateMatrix(); mm.setMatrixAt(n++,dum.matrix); }
    mm.count=n; mm.instanceMatrix.needsUpdate=true; dum.quaternion.set(0,0,0,1); }
  const api={
    t:0, hit(x,y,z,r){ if(!mesh.visible) return 0; let c=0; for(let i=0;i<N;i++){ const a=ast[i]; if(!a.alive) continue; const d=Math.hypot(a.x-x,a.y-y,a.z-z); if(d<r+a.r){ a.alive=false; c++; FX.spark(a.x,a.y,a.z,40,Math.min(40,a.r*2+10),[1,.8,.5]); FX.dust(a.x,a.y,a.z,24,Math.min(30,a.r),[.6,.55,.5]); FX.glow(a.x,a.y,a.z,Math.min(30,a.r*2.5),[1,.8,.5],.3); if(Game.audio) Game.audio.boom(a.x,a.y,a.z); writeAst(i,0); } } if(c) mesh.instanceMatrix.needsUpdate=true; return c; },
    reset(){ for(const a of ast) a.alive=true; }
  };
  if(D&&D.damageSphere){ const orig=D.damageSphere; D.damageSphere=function(x,y,z,r){ if(y>3000) api.hit(x,y,z,r); return orig.apply(D,arguments); }; }
  let lastG=1, state=0, tAcc=0;
  Game.updaters.push((dt0,time,raw)=>{ const dt=raw||dt0, play=Game.mode==="play"; const y=play?hero.position.y:0, t=play?H.sp:0; api.t=t; SU.space.value=t;
    const g=1-.9*t; H.gscale=g; if(Math.abs(g-lastG)>.02){ lastG=g; if(Game.P) Game.P.setGravity(g); }
    /* ışık ve sis */
    const night=Game.night||0; scene.fog.density=.0013*(1+night*.8)*(1-t)*((Game.MAP&&Game.MAP.fogK)||1)*(Game.ultra?1.2:1); hemi.intensity=(T.hB||.5)*(1-.6*t); sun.intensity=(T.sB||1)*(1+.35*t);
    mesh.visible=y>2400; if(mesh.visible){ tAcc+=dt; for(let i=0;i<N;i++){ const a=ast[i]; if(!a.alive) continue; if(Math.abs(a.y-y)>1200&&((i+(time*4|0))%6)) continue; writeAst(i,time); } mesh.instanceMatrix.needsUpdate=true; }
    updMeteors(dt,t);
    if(play&&t>.2){ // göktaşı çarpışması
      for(let i=0;i<N;i++){ const a=ast[i]; if(!a.alive) continue; const dx=hero.position.x-a.x, dy=hero.position.y-a.y, dz=hero.position.z-a.z, d2=dx*dx+dy*dy+dz*dz, rr=a.r+1.6; if(d2<rr*rr){ const d=Math.sqrt(d2)||1, nx=dx/d, ny=dy/d, nz=dz/d, vn=H.vel.x*nx+H.vel.y*ny+H.vel.z*nz; hero.position.x=a.x+nx*rr; hero.position.y=a.y+ny*rr; hero.position.z=a.z+nz*rr;
          if(vn<0){ H.vel.x-=nx*vn*1.4; H.vel.y-=ny*vn*1.4; H.vel.z-=nz*vn*1.4; if(-vn>20){ Game.shakeAdd(Math.min(1,-vn/200)); FX.spark(hero.position.x,hero.position.y,hero.position.z,12,10,[1,.85,.6]); if(Game.audio) Game.audio.thud(hero.position.x,hero.position.y,hero.position.z); } } } } }
    /* bölge geçiş bildirimleri */
    if(play){ if(state===0&&t>.85){ state=1; Game.toast("t_space",3200); } else if(state===1&&t<.45){ state=0; Game.toast("t_earth",2600); } } else state=t>.85?1:0;
  });
  return api;
})();
