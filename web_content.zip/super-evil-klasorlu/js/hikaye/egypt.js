"use strict";
/* ===== MISIR ADASI ETKİLEŞİMİ: develer kırılınca ruh çıkıp yükselerek kaybolur; firavun heykeli çatlar, gözleri kızarır ve patlar; iskele/cadde meşaleleri ===== */
(function(){
const E=Game.Egypt; if(!E||!E.camelMesh) return;
const FX=Game.FX, SH=Game.Shards, au=()=>Game.audio, C=Game.CG.C, AX=E.AX, AZ=E.AZ, o3=new THREE.Object3D(), R=(a,b)=>a+Math.random()*(b-a);
const CAM=[C("#caa05a"),C("#b58a45"),C("#8f6a30"),C("#b3302a"),C("#e8c14a"),C("#d9bd80")], STN=[C("#d9bf88"),C("#c4a46a"),C("#b59a62"),C("#e8d4a0")], EMB=[C("#ff8a2a"),C("#ff4a10"),C("#ffc040"),C("#3a2418")];
const camDist=(x,z)=>Math.hypot(x-camera.position.x,z-camera.position.z);

/* ---------- develer + ruhlar ---------- */
const GN=6, ghosts=[];
for(let i=0;i<GN;i++){ const m=new THREE.Mesh(E.camelGeo,new THREE.MeshBasicMaterial({color:0xbfe6ff,transparent:true,opacity:0,blending:THREE.AdditiveBlending,depthWrite:false})); m.visible=false; m.frustumCulled=false; m.renderOrder=7; scene.add(m); ghosts.push({m,t:-1,x:0,y:0,z:0,yaw:0,s:1}); }
const GD=3.6;
function breakCamel(c,dx,dz){ if(!c.alive) return; c.alive=false; const im=E.camelMesh; o3.position.set(c.x,c.gy,c.z); o3.rotation.set(0,0,0); o3.scale.setScalar(.0001); o3.updateMatrix(); im.setMatrixAt(c.i,o3.matrix); im.instanceMatrix.needsUpdate=true;
  const x=c.x, z=c.z, y=c.gy+2.6, l=Math.hypot(dx,dz)||1; dx/=l; dz/=l;
  SH.burst(x,y,z,34,{sp:7,up:7,size:[.22,.7],cols:CAM,life:[3,6],grav:15,spread:1.0,dir:[dx,dz,3]});
  SH.burst(x,y+1,z,14,{sp:4,up:4,size:[.08,.2],cols:[C("#f3e2b0"),C("#ffffff")],life:[2,4],grav:10,spread:.8});
  FX.dust(x,y,z,14,5,[.78,.66,.45]); FX.cloud(x,c.gy+1,z,6,5,2.5,[.8,.7,.5]); FX.spark(x,y,z,10,6,[.8,.92,1]);
  if(au()){ if(au().camelBreak) au().camelBreak(x,y,z); if(au().spirit) au().spirit(x,y,z); }
  const g=ghosts.find(q=>q.t<0)||ghosts[0]; g.t=0; g.x=x; g.y=c.gy; g.z=z; g.yaw=c.yaw; g.s=c.s; g.m.visible=true; FX.glow(x,y+1,z,6,[.75,.92,1],.3);
  if(Game.toast) Game.toast("t_camel",2600); }
function updGhosts(dt){ for(const g of ghosts){ if(g.t<0) continue; g.t+=dt; const k=g.t/GD;
    if(k>=1){ g.t=-1; g.m.visible=false; FX.glow(g.x,g.y+9,g.z,5,[.8,.95,1],.35); continue; }
    const e=1-(1-k)*(1-k), y=g.y+.6+7.8*e, sw=Math.sin(g.t*2.2)*.45, a=Math.min(1,g.t/.25)*(k<.5?1:1-(k-.5)/.5)*.62;
    g.m.position.set(g.x+sw,y,g.z+Math.cos(g.t*1.7)*.35); g.m.rotation.set(0,g.yaw+g.t*.9,0); g.m.scale.set(g.s*(1+.08*k),g.s*(1+.4*k),g.s*(1+.08*k)); g.m.material.opacity=a;
    for(let i=0;i<2;i++) FX.E(true,g.x+sw+R(-.9,.9),y+R(1,4.2),g.z+R(-.9,.9),R(-.2,.2),R(.8,1.8),R(-.2,.2),.9,.9,.2,[.75,.92,1],[.4,.6,1],.5,0,.97); } }

/* ---------- firavun heykelleri ---------- */
const TC=[0,.45,.9], T_GLOW=1.5, T_BOOM=3.8, EYE0=[.94,.9,.78], EYE1=[1,.07,.03];
const eyeW=(st,k)=>{ const e=st.eyeLocal[k], cy=Math.cos(st.yaw), sy=Math.sin(st.yaw); return [st.x+e[0]*cy+e[2]*sy, st.gy+e[1], st.z-e[0]*sy+e[2]*cy]; };
const lw=(st,lx,ly,lz)=>{ const cy=Math.cos(st.yaw), sy=Math.sin(st.yaw); return [st.x+lx*cy+lz*sy, st.gy+ly, st.z-lx*sy+lz*cy]; };
function crackStart(st){ st.state=1; st.t=0; st.glowCd=0; st.eyeSnd=false;
  for(const p of [[0,21,2.5],[0,15,2.2],[-4.5,12,1.6],[4.5,12,1.6],[2.4,8.2,4]]){ const w=lw(st,p[0],p[1],p[2]); SH.burst(w[0],w[1],w[2],9,{sp:5,up:5,size:[.12,.4],cols:STN,life:[2.5,4.5],grav:15,spread:.8}); FX.dust(w[0],w[1],w[2],7,4,[.8,.7,.5]); }
  if(au()&&au().stoneCrack) au().stoneCrack(st.x,st.gy+14,st.z); if(Game.shakeAdd) Game.shakeAdd(.7); if(Game.toast) Game.toast("t_pharaoh",3200);
  if(Game.NPC&&Game.NPC.alert) Game.NPC.alert(st.x,st.z,60,st.x,st.z); }
function explode(st){ st.state=3; st.t=0; st.smoke=16; st.eyes.forEach(m=>m.visible=false); st.sockets.forEach(m=>m.visible=true);
  for(let k=0;k<2;k++){ const w=eyeW(st,k), fx=Math.sin(st.yaw), fz=Math.cos(st.yaw);
    FX.fire(w[0],w[1],w[2],26,fx*3,3,fz*3,2.6); FX.glow(w[0],w[1],w[2],9,[1,.4,.1],.35); FX.spark(w[0],w[1],w[2],34,20,[1,.55,.2]);
    for(let i=0;i<24;i++){ const a=Math.random()*6.283; FX.E(true,w[0],w[1],w[2],Math.cos(a)*12,R(-3,3),Math.sin(a)*12,.7,1.6,5,[1,.5,.15],[.6,.1,0],.55,0,.93); }
    SH.burst(w[0],w[1],w[2],22,{sp:9,up:6,size:[.12,.4],cols:STN,life:[3,5],grav:16,spread:.3,dir:[fx,fz,6]});
    SH.burst(w[0],w[1],w[2],22,{sp:8,up:7,size:[.06,.14],cols:EMB,life:[1.2,2.4],grav:9,spread:.3,dir:[fx,fz,5]});
    if(au()&&au().boom) au().boom(w[0],w[1],w[2]); }
  if(au()&&au().stoneCrack) au().stoneCrack(st.x,st.gy+21,st.z); if(Game.shakeAdd) Game.shakeAdd(Math.max(.25,1.2*(1-Math.min(1,camDist(st.x,st.z)/160))));
  const w=eyeW(st,0); if(Game.radial) Game.radial(st.x,w[1],st.z+Math.cos(st.yaw)*4,16,24,"boom"); if(Game.NPC&&Game.NPC.alert) Game.NPC.alert(st.x,st.z,110,st.x,st.z);
  if(Game.toast) Game.toast("t_pharaoh2",3200); }
function updStatue(st,dt){ if(st.state===0) return; st.t+=dt; const t=st.t;
  if(st.state===1||st.state===2){
    for(let i=0;i<3;i++){ const m=st.cracks[i]; if(t>=TC[i]){ m.visible=true; m.material.opacity=Math.min(.92,(t-TC[i])/.5); if(!st["c"+i]&&i>0){ st["c"+i]=true; const p=i===1?[-4.5,12,1.6]:[2.4,8.2,3]; const w=lw(st,p[0],p[1],p[2]); SH.burst(w[0],w[1],w[2],7,{sp:4,up:3,size:[.1,.3],cols:STN,life:[2,4],grav:15,spread:.6}); FX.dust(w[0],w[1],w[2],5,3,[.8,.7,.5]); if(au()&&au().stoneCrack) au().stoneCrack(w[0],w[1],w[2]); } } }
    if(t>=T_GLOW){ if(st.state===1){ st.state=2; if(au()&&au().eyeCharge&&camDist(st.x,st.z)<260) au().eyeCharge(); }
      const k=Math.min(1,(t-T_GLOW)/(T_BOOM-T_GLOW)), pulse=1+.3*Math.sin(t*18)*k;
      st.eyes.forEach(m=>{ m.material.color.setRGB(EYE0[0]+(EYE1[0]-EYE0[0])*k,EYE0[1]+(EYE1[1]-EYE0[1])*k,EYE0[2]+(EYE1[2]-EYE0[2])*k); m.scale.set(pulse,pulse,1+k*.6); });
      st.glowCd-=dt; if(st.glowCd<=0){ st.glowCd=.07; for(let e=0;e<2;e++){ const w=eyeW(st,e); FX.glow(w[0],w[1],w[2],1.2+2.6*k,[1,.15,.05],.12); if(Math.random()<k) FX.spark(w[0],w[1],w[2],2,3+4*k,[1,.4,.1]); } }
      if(Game.shakeAdd&&camDist(st.x,st.z)<90&&Math.random()<.4) Game.shakeAdd(.08+.14*k);
      if(t>=T_BOOM) explode(st); } }
  else if(st.state===3&&st.smoke>0){ st.smoke-=dt; st.sm=(st.sm||0)-dt; if(st.sm<=0){ st.sm=.22; for(let e=0;e<2;e++){ const w=eyeW(st,e); FX.smoke(w[0],w[1]-.2,w[2],1,.45); } } } }

/* ---------- vuruş kancası ---------- */
Game.hitHooks.push((x,y,z,r,amt,speed)=>{ if(Math.hypot(x-AX,z-AZ)>230) return;
  if(amt>=.6){ for(const c of E.camels){ if(!c.alive) continue; const dh=Math.hypot(c.x-x,c.z-z), dv=(y-(c.gy+2.6))*.6; if(Math.hypot(dh,dv)-1.7<r) breakCamel(c,c.x-x,c.z-z); } }
  if(amt>=.9&&(speed>=20||amt>=1.2)){ for(const st of E.statues){ if(st.state!==0) continue; const dx=Math.max(Math.abs(x-st.x)-st.hw,0), dz=Math.max(Math.abs(z-st.z)-st.hd,0), dy=y<st.gy?st.gy-y:(y>st.gy+st.h?y-st.gy-st.h:0); if(dx*dx+dz*dz+dy*dy<=r*r) crackStart(st); } } });
E.breakCamel=breakCamel; E.crackStart=crackStart;

/* ---------- meşale / ateş kâseleri (yakındayken alev parçacığı) ---------- */
let bt=0;
Game.updaters.push((dt)=>{ updGhosts(dt); for(const st of E.statues) updStatue(st,dt);
  bt-=dt; if(bt<=0){ bt=.11; const c=camera.position; if(Math.hypot(c.x-AX,c.z-AZ)<260){ for(const b of E.braziers){ if(Math.abs(b.x-c.x)>90||Math.abs(b.z-c.z)>90) continue; FX.fire(b.x,b.y,b.z,1,0,.5,0,.8); } } } });
})();
