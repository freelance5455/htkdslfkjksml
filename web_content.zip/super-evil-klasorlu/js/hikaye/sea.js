"use strict";
/* ===== DENİZ & HAVA TRAFİĞİ: gemiler (şerit), jet skiler (daire/slalom), uçak & helikopterler (döngü); vurulunca yanar/donar/batar/düşer, elle kaldırılır ===== */
Game.Sea=(function(){
const W=Game.W, FX=Game.FX, P=Game.P, D=Game.D, KIT=Game.SeaKit, WY=W.WATER_Y, H=Game.H, hero=Game.heroObj, au=()=>Game.audio;
const rs=()=>Math.random()-.5, R=(a,b)=>a+Math.random()*(b-a), clamp=(v,a,b)=>v<a?a:v>b?b:v, TAU=Math.PI*2;
const aDiff=(a,b)=>{ let d=a-b; while(d>Math.PI) d-=TAU; while(d<-Math.PI) d+=TAU; return d; };
/* tür tablosu: c s=gemi j=jet ski a=hava; d=[yarı genişlik, su üstü yükseklik, su altı derinlik, yarı boy]; mass: itme/kaldırma ağırlığı; exp: patlama ölçeği; pts: puan; burnT: yanarak yok olma süresi */
const KD={
  cargo:  {c:"s",spd:[8,10],  hp:4,d:[4.6,9,4,23],  w:1.1,mass:5,exp:1.2,pts:400,burnT:11,dc:["red","navy","grey","white"],n:1,var:2},
  tanker: {c:"s",spd:[7,9],   hp:4,d:[5.2,8,4,27],  w:1.2,mass:5,exp:2.4,pts:500,burnT:6, dc:["grey","dgrey","red","black"],n:1,var:1},
  ferry:  {c:"s",spd:[10,12], hp:3,d:[4.8,12,3,16], w:1,  mass:3,exp:1.2,pts:350,burnT:8, dc:["white","blue","grey","red"],n:1,var:1},
  yacht:  {c:"s",spd:[11,14], hp:2,d:[2.6,6,2,8],   w:.7, mass:1,exp:.7, pts:200,burnT:4, dc:["white","off","navy","teal"],n:1,var:1},
  fishing:{c:"s",spd:[5,7],   hp:2,d:[2.6,6,2,7],   w:.6, mass:1,exp:.6, pts:150,burnT:4, dc:["red","white","dgrey","yellow"],n:1,var:1},
  sail:   {c:"s",spd:[4,6],   hp:2,d:[1.8,10,2,6],  w:.5, mass:1,exp:.5, pts:150,burnT:3, dc:["white","off","blue"],n:1,var:1},
  jetski: {c:"j",spd:[16,22], hp:1,d:[.7,1.6,.5,1.9],w:.35,mass:.3,exp:.5,pts:120,burnT:2, dc:["red","yellow","black","white"],n:1,var:3},
  airliner:{c:"a",spd:[72,82],hp:1,d:[21,5,3,22],  w:0, mass:6,exp:3,  pts:600,burnT:3.5,dc:["white","off","grey","navy"],n:1,var:1},
  prop:   {c:"a",spd:[42,50], hp:1,d:[7.5,3,1.2,5.5],w:0,mass:1,exp:1.2,pts:300,burnT:2,dc:["yellow","white","red","dgrey"],n:1,var:1},
  fighter:{c:"a",spd:[115,135],hp:1,d:[5,2,1.5,8.5],w:0,mass:1.5,exp:1.4,pts:450,burnT:2,dc:["grey","dgrey","black","orange"],n:1,var:1},
  heli:   {c:"a",spd:[24,30], hp:1,d:[5,2.4,1.8,9], w:0, mass:1,exp:1.1,pts:350,burnT:1.6,dc:["red","white","blue","dark"],n:1,var:3}
};
for(const k in KD){ const K=KD[k]; K.rr=Math.max(K.d[0],K.d[3])+10; }
/* ---------- yollar ---------- */
const LC={x:300,z:0}, LA=900, LB=600;                 // gemi şeridi: şehir + köprü + adalar etrafında büyük elips
const PATH={
  ship(e,u,o){ const a=LA+e.lane, b=LB+e.lane; o.x=LC.x+a*Math.cos(u); o.z=LC.z+b*Math.sin(u); o.y=0; },
  ski(e,u,o){ o.x=e.cx+e.rx*Math.cos(u)+7*Math.sin(3.3*u+e.ph); o.z=e.cz+e.rz*Math.sin(u)+6*Math.cos(2.7*u+e.ph); o.y=0; },
  airliner(e,u,o){ o.x=100+1900*Math.cos(u); o.z=1500*Math.sin(u); o.y=e.alt+40*Math.sin(u*2+e.ph); },
  fighter(e,u,o){ o.x=200+2200*Math.cos(u); o.z=1700*Math.sin(u*1.5+e.ph); o.y=e.alt+130*Math.sin(u*2.3+e.ph); },
  prop(e,u,o){ o.x=1050*Math.cos(u); o.z=1050*Math.sin(u); o.y=e.alt+28*Math.sin(u*3+e.ph); },
  heli(e,u,o){ o.x=e.cx+e.rx*Math.cos(u); o.z=e.cz+e.rx*Math.sin(u); o.y=e.alt+10*Math.sin(u*2.4+e.ph); }
};
/* ---------- iz dokusu (V biçimli köpük) ---------- */
const wakeTex=(()=>{ const c=document.createElement("canvas"); c.width=128; c.height=256; const g=c.getContext("2d"); let sd=7; const rnd=()=>(sd=(sd*16807)%2147483647)/2147483647;
  for(let y=0;y<256;y++){ const k=y/256, a=(1-k)*(1-k), half=5+k*56;
    g.fillStyle="rgba(255,255,255,"+(a*.55).toFixed(3)+")"; g.fillRect(64-3-k*4,y,6+k*8,1);
    for(const s of [-1,1]){ g.fillStyle="rgba(255,255,255,"+(a*.8).toFixed(3)+")"; g.fillRect(64+s*half-2.2,y,4.4,1); } }
  for(let i=0;i<1100;i++){ const k=rnd(), half=5+k*56, x=64+(rnd()*2-1)*half; g.fillStyle="rgba(255,255,255,"+((1-k)*.4*rnd()).toFixed(3)+")"; g.fillRect(x,k*256,1+rnd()*2.4,1+rnd()*2.4); }
  const t=new THREE.CanvasTexture(c); return t; })();
const wakeGeo=new THREE.PlaneGeometry(1,1);
const slGeo=(()=>{ const g=new THREE.CylinderGeometry(.12,1,1,18,1,true); g.translate(0,-.5,0); return g; })();
/* ---------- varlıklar ---------- */
const ents=[], queue=[], UPV=new THREE.Vector3(0,-1,0), qv=new THREE.Quaternion(), dv=new THREE.Vector3();
let T=0, ready=false, hornT=20;
const tO={x:0,y:0,z:0}, tO2={x:0,y:0,z:0};
function counts(){ const q=Game.quality||"medium", f=q==="low"?0:q==="medium"?1:2;
  return {ship:[4,6,8][f],ski:[3,5,7][f],air:[["airliner","fighter","heli","heli"],["airliner","fighter","prop","heli","heli","heli"],["airliner","airliner","fighter","fighter","prop","heli","heli","heli"]][f]}; }
const SHIPS=["tanker","yacht","cargo","sail","ferry","fishing","cargo","yacht"];
function build(kind,opts){ const K=KD[kind], g=KIT.make(kind,(Math.random()*K.var)|0), ud=g.userData; scene.add(g); g.visible=false;
  const e=Object.assign({kind,K,g,ud,mat:ud.mats[0],st:"cruise",hp:K.hp,x:0,y:0,z:0,yaw:0,pit:0,rol:0,vx:0,vy:0,vz:0,wx:0,wy:0,wz:0,u:0,dir:1,spd:0,spd0:0,ox:0,oz:0,lane:0,cx:0,cz:0,rx:0,rz:0,alt:0,ph:Math.random()*6.28,
    burning:false,dead:false,bt:0,frozen:false,fT:0,t:0,swa:0,swT:0,yr:0,wg:null,wm:null,sp:0,rc:0,pc:0,lz:0,cT:0,thrown:false,wp:{x:0,y:0,z:0},sl:null,pf:PATH.ship,id:ents.length,tcol:[1,1,1]},opts);
  if(K.c!=="a"){ const wm=new THREE.MeshBasicMaterial({map:wakeTex,transparent:true,opacity:.6,depthWrite:false,side:THREE.DoubleSide,polygonOffset:true,polygonOffsetFactor:-2,polygonOffsetUnits:-2}), m=new THREE.Mesh(wakeGeo,wm); m.rotation.x=Math.PI/2; m.frustumCulled=false; m.renderOrder=2;
    const len=(K.d[3]*2+8)*(K.c==="j"?5:3.2), wid=Math.max(3,K.d[0]*2)*(K.c==="j"?5.5:5); m.scale.set(wid,len,1); m.position.z=-K.d[3]*.75-len/2+K.d[3]*.9; e.wm=wm; const wg=new THREE.Group(); wg.add(m); wg.visible=false; scene.add(wg); e.wg=wg; }
  if(kind==="heli"){ const mat=new THREE.MeshBasicMaterial({color:0xfff2cc,transparent:true,opacity:.0,blending:THREE.AdditiveBlending,depthWrite:false,side:THREE.DoubleSide,fog:false}), cone=new THREE.Mesh(slGeo,mat); cone.frustumCulled=false; cone.visible=false; scene.add(cone); e.sl={cone,mat,tx:0,tz:0}; }
  ents.push(e); return e; }
function setup(e,i,n){ const K=e.K; e.spd0=R(K.spd[0],K.spd[1]); e.spd=e.spd0;
  if(K.c==="s"){ e.pf=PATH.ship; e.lane=-26+i*8; e.dir=i%2?-1:1; e.u=(i/Math.max(1,n))*TAU+R(0,.6); }
  else if(K.c==="j"){ e.pf=PATH.ski; e.dir=Math.random()<.5?-1:1; e.rx=R(40,90); e.rz=R(32,66); e.u=R(0,TAU); const c=skiCenter(e); e.cx=c.x; e.cz=c.z; }
  else if(e.kind==="airliner"){ e.pf=PATH.airliner; e.alt=R(310,400); e.dir=i%2?-1:1; e.u=R(0,TAU); }
  else if(e.kind==="fighter"){ e.pf=PATH.fighter; e.alt=R(450,520); e.dir=i%2?-1:1; e.u=R(0,TAU); }
  else if(e.kind==="prop"){ e.pf=PATH.prop; e.alt=R(170,210); e.dir=1; e.u=R(0,TAU); }
  else { e.pf=PATH.heli; e.dir=i%2?-1:1; e.u=R(0,TAU); const v=[[0,0,260,285],[0,0,480,115],[700,17,200,95]][e.hi%3]; e.cx=v[0]; e.cz=v[1]; e.rx=v[2]; e.alt=v[3]; }
  e.g.visible=true; if(e.wg) e.wg.visible=true; snap(e); }
/* jet ski merkezi: şehir sahilinin açığında, köprü/ada/şeritlerden uzak */
function skiCenter(e){ const rr=Math.max(e.rx,e.rz)+25;
  for(let tries=0;tries<80;tries++){ const a=R(0,TAU), d=R(540,700), x=Math.cos(a)*d, z=Math.sin(a)*d; if(x>250&&x<700&&Math.abs(z-17)<rr+25) continue; let ok=true;
    for(const I of W.islands){ if(Math.hypot(x-I.x,z-I.z)<I.R+rr+30) ok=false; }
    for(let k=0;k<8&&ok;k++){ const aa=k/8*TAU; if(W.terrainH(x+Math.cos(aa)*rr,z+Math.sin(aa)*rr)>WY-1) ok=false; } if(ok&&W.terrainH(x,z)<WY-2) return {x,z}; }
  return {x:-300,z:600}; }
function snap(e){ e.pf(e,e.u,tO); e.x=tO.x; e.z=tO.z; e.y=e.K.c==="a"?tO.y:WY+.15; e.ox=e.oz=0; e.pf(e,e.u+.003,tO2); e.yaw=Math.atan2((tO2.x-tO.x)*e.dir,(tO2.z-tO.z)*e.dir); sync(e); }
function sync(e){ const g=e.g; if(!(e.pit===e.pit)) e.pit=0; if(!(e.rol===e.rol)) e.rol=0; if(!(e.yaw===e.yaw)) e.yaw=0; /* NaN koruması: bozuk eğim/yalpa aracı görünmez yapar */ g.position.set(e.x,e.y,e.z); g.rotation.set(e.pit,e.yaw,e.rol,"YXZ"); }
function respawn(e){ const K=e.K, hp=hero.position; e.hp=K.hp; e.st="cruise"; e.burning=false; e.dead=false; e.bt=0; e.frozen=false; e.thrown=false; e.vx=e.vy=e.vz=0; e.wx=e.wy=e.wz=0; e.swa=0; e.pit=e.rol=0; e.mat.color.setRGB(1,1,1);
  for(let k=0;k<12;k++){ e.u=R(0,TAU); e.pf(e,e.u,tO); if(Math.hypot(tO.x-hp.x,tO.z-hp.z)>(K.c==="a"?700:420)) break; } e.spd=K.c==="a"?e.spd0:0; e.g.visible=true; if(e.wg) e.wg.visible=true; snap(e); }
/* ---------- yardımcılar ---------- */
function boxD(e,x,y,z,pad){ const d=e.K.d, cy=Math.cos(e.yaw), sy=Math.sin(e.yaw), rx=x-e.x, rz=z-e.z, lx=rx*cy-rz*sy, lz=rx*sy+rz*cy, ly=y-e.y;
  const dx=Math.max(Math.abs(lx)-d[0]-pad,0), dy=Math.max((ly>0?ly-d[1]:-ly-d[2])-pad,0), dz=Math.max(Math.abs(lz)-d[3]-pad,0); return Math.sqrt(dx*dx+dy*dy+dz*dz); }
function rndPt(e,o){ const d=e.K.d, lx=rs()*d[0]*1.6, ly=R(-d[2]*.2,d[1]*.8), lz=rs()*d[3]*1.5, cy=Math.cos(e.yaw), sy=Math.sin(e.yaw); o.x=e.x+lx*cy+lz*sy; o.y=e.y+ly; o.z=e.z-lx*sy+lz*cy; return o; }
const ap=new Object({x:0,y:0,z:0});
const alive=e=>e.st==="cruise"||e.st==="fly"||e.st==="fall"||e.st==="held";
function tint(e,r,g,b){ e.mat.color.setRGB(r,g,b); }
function boomFx(x,y,z,s){ FX.fire(x,y,z,Math.round(26*s),0,5*s,0,2+s); FX.spark(x,y,z,Math.round(22*s),14+8*s); FX.cloud(x,y,z,Math.round(5*s),5*s,3+2*s); FX.smoke(x,y+1,z,Math.round(6*s),1+s); FX.shock(x,y,z,Math.round(14*s),16+10*s); FX.glow(x,y,z,10*s,[1,.8,.4],.4);
  if(au()) au().boom(x,y,z); const hp=hero.position, dh=Math.hypot(x-hp.x,y-hp.y,z-hp.z); Game.shakeAdd&&Game.shakeAdd(clamp(1.1*s*(1-dh/(450+300*s)),0,1.2)); }
function debris(e,x,y,z,n,vs){ const K=e.K, cols=K.dc; for(let i=0;i<n;i++){ const c=KIT.C[cols[i%cols.length]]||KIT.C.grey, fr=e.frozen?1:0;
    P.spawnDebris({x:x+rs()*K.d[0]*1.6,y:y+rs()*K.d[1],z:z+rs()*K.d[3]*.8,sx:R(.8,2.6),sy:R(.5,1.8),sz:R(.8,3),r:c[0],g:c[1],b:c[2],burn:fr?0:(Math.random()<.5?.6:0),frost:fr},rs()*22*vs,R(6,24)*vs,rs()*22*vs); } }
function addScore(e){ if(Game.addScore&&Game.mode==="play") Game.addScore(e.K.pts); }
/* ---------- yıkım ---------- */
function crash(e,type,x,y,z){ const K=e.K, s=K.exp; e.st="wreck"; e.g.visible=false; if(e.wg) e.wg.visible=false; if(e.sl) e.sl.cone.visible=false; e.t=type==="water"?6:K.c==="a"?16:10; e.wp.x=x; e.wp.y=y; e.wp.z=z; e.burning=false;
  if(type==="water"){ Game.splash(x,z,Math.min(6,1.5+s*1.3)); FX.cloud(x,WY+1,z,3,6,3,[.85,.9,.95]); if(!e.frozen) boomFx(x,WY+.8,z,s*.45); else FX.ice(x,WY+1,z,30,9); debris(e,x,WY+1,z,Math.round(5+s*2),.6); }
  else if(e.frozen){ FX.ice(x,y+1,z,Math.round(40*s),12); FX.shock(x,y,z,12,18); FX.dust(x,y,z,10,5,[.8,.9,1]); if(au()) au().crashMetal&&au().crashMetal(); D.damageSphere(x,y,z,4+s*3,.6,16); debris(e,x,y,z,Math.round(10+s*5),1.1); }
  else { boomFx(x,y,z,s); D.damageSphere(x,y,z,6+s*5,.95,24+s*6); Game.radial&&Game.radial(x,y,z,10+s*7,18+s*6,"boom"); debris(e,x,y,z,Math.round(8+s*6),1); }
  addScore(e); }
function destroy(e,how,vx,vy,vz){ if(e.dead) return; const K=e.K; e.dead=true; e.burning=true; e.bt=0; e.thrown=false; addScore(e);
  if(K.c==="a"){ e.st="fall"; e.vx+=(vx||0)*.5; e.vy+=(vy||0)*.4; e.vz+=(vz||0)*.5; e.wz=(Math.random()<.5?-1:1)*R(1.5,3.2); e.wy=rs()*.8; e.fire=true; FX.fire(e.x,e.y,e.z,10,0,2,0,2); FX.spark(e.x,e.y,e.z,10,10); if(au()) au().boom(e.x,e.y,e.z); return; }
  if(e.frozen){ shatter(e); return; }
  const s=K.exp*(K.c==="j"?.8:.75); boomFx(e.x,e.y+K.d[1]*.4,e.z,s); debris(e,e.x,e.y+2,e.z,Math.round(4+K.exp*3),.9);
  if(K.exp>=2){ boomFx(e.x,e.y+4,e.z,s*1.1); D.damageSphere(e.x,e.y+4,e.z,26,.8,20); Game.radial&&Game.radial(e.x,e.y+4,e.z,40,28,"boom"); FX.fire(e.x,e.y+3,e.z,60,0,8,0,4); }
  e.st="sink"; e.sk=0; e.sdir=Math.random()<.5?-1:1; if(vx!==undefined){ e.vx=vx*.2; e.vz=vz*.2; } }
function shatter(e){ const K=e.K; FX.ice(e.x,e.y+K.d[1]*.5,e.z,Math.round(36+K.exp*20),10+K.exp*3); FX.shock(e.x,e.y+2,e.z,10,14); FX.dust(e.x,e.y+2,e.z,8,4,[.8,.92,1]); if(au()) au().glass&&au().glass(.8); debris(e,e.x,e.y+2,e.z,Math.round(8+K.exp*5),1); addScore(e);
  e.st="gone"; e.dead=true; e.g.visible=false; if(e.wg) e.wg.visible=false; e.t=R(40,60); e.burning=false; if(e.sl) e.sl.cone.visible=false; }
function ignite(e){ if(e.burning||e.dead) return; if(e.frozen){ e.frozen=false; tint(e,1,1,1); FX.ice(e.x,e.y+2,e.z,10,4); } e.burning=true; e.bt=0; }
function freeze(e){ if(e.dead||e.frozen||!alive(e)) return; if(e.burning){ e.burning=false; tint(e,1,1,1); } e.frozen=true; e.fT=26; tint(e,.55,.82,1); FX.ice(e.x,e.y+e.K.d[1]*.5,e.z,12+e.K.exp*6,e.K.d[3]*.5);
  if(e.K.c==="a"&&e.st==="cruise"){ e.st="fall"; e.dead=true; e.wz=(Math.random()<.5?-1:1)*R(.6,1.4); e.fire=false; } }
function hit(e,pw,vx,vy,vz,src){ if(!alive(e)&&e.st!=="sink") return; if(e.dead&&e.st==="sink") return; if(e.frozen&&pw>=.9){ shatter(e); return; } const K=e.K, hp0=e.hp; e.hp-=pw;
  FX.spark(e.x,e.y+K.d[1]*.5,e.z,10,10); FX.dust(e.x,e.y+K.d[1]*.5,e.z,4,3);
  if(e.hp<=0){ destroy(e,src,vx,vy,vz); return; }
  if(K.c!=="a"){ e.swa=Math.min(.35,e.swa+.08+pw*.06); const k=1/Math.max(.3,K.mass); e.ox+=vx*.18*k; e.oz+=vz*.18*k;
    if(K.mass<=1.2&&e.st==="cruise"){ e.st="fly"; e.thrown=true; e.vx=vx*.8; e.vy=Math.max(8,vy); e.vz=vz*.8; e.wz=rs()*5; e.wx=rs()*3; e.wy=rs()*3; } } }
/* ---------- sıçrayış, çarpışma, batma ---------- */
function waterLand(e){ const K=e.K, vs=Math.max(0,-e.vy), sc=Math.min(5,.5+vs*.07*Math.max(.5,K.w)); Game.splash(e.x,e.z,sc); for(let i=0;i<4;i++) Game.splash(e.x+rs()*K.d[0]*3,e.z+rs()*K.d[3]*1.6,sc*.5);
  if(K.c==="a"){ crash(e,"water",e.x,WY,e.z); return; }
  let dmg=(vs>34?2.2:vs>20?1.1:vs>12?.5:0)+(e.thrown?.8:0); if(K.c==="j"&&vs>16) dmg=9; e.thrown=false; e.hp-=dmg;
  if(e.hp<=0){ e.y=WY+.15; e.vx*=.3; e.vz*=.3; destroy(e,"fall",e.vx,0,e.vz); return; }
  e.st="cruise"; e.y=WY+.15; e.vy=0; e.pit=0; e.rol=0; e.swa=Math.min(.5,.12+vs*.01); e.spd=Math.min(Math.hypot(e.vx,e.vz),e.spd0); e.vx=e.vy=e.vz=0; e.wx=e.wy=e.wz=0; relane(e); }
/* suya düşen/kalkan gemiyi en yakın şerit noktasına bağla; sapma yumuşakça kapanır (gemi geri döner) */
function relane(e){ const K=e.K; let u;
  if(K.c==="s"){ u=Math.atan2((e.z-LC.z)/(LB+e.lane),(e.x-LC.x)/(LA+e.lane)); } else { u=Math.atan2((e.z-e.cz)/e.rz,(e.x-e.cx)/e.rx); }
  e.u=u; e.pf(e,u,tO); e.ox=e.x-tO.x; e.oz=e.z-tO.z; }
function land(e,x,y,z){ crash(e,"ground",x,Math.max(y,W.terrainH(x,z)+1),z); }
function ballistic(e,dt){ const K=e.K, air=K.c==="a", ox=e.x, oy=e.y, oz=e.z;
  if(air&&e.dead){ e.vy-=18*dt; const k=Math.pow(.992,dt*60); e.vx*=k; e.vz*=k; e.pit=Math.min(1.2,e.pit+dt*.6); } else e.vy-=(Game.P&&Game.P.G0||14)*dt;
  e.x+=e.vx*dt; e.y+=e.vy*dt; e.z+=e.vz*dt; e.yaw+=e.wy*dt; e.rol+=e.wz*dt; if(!air||!e.dead) e.pit+=e.wx*dt; if(e.fire){ /* kalan hız yönüne bak */ const hs=Math.hypot(e.vx,e.vz); if(hs>8) e.yaw+=aDiff(Math.atan2(e.vx,e.vz),e.yaw)*(1-Math.exp(-dt*1.5)); }
  const sp=Math.hypot(e.vx,e.vy,e.vz);
  if(sp>6){ const L=sp*dt+K.d[3]*.5, r=D.ray(ox,oy,oz,e.vx/sp,e.vy/sp,e.vz/sp,L); if(r.kind==="chunk"&&r.t<L){ const hx=ox+e.vx/sp*r.t, hy=oy+e.vy/sp*r.t, hz=oz+e.vz/sp*r.t; if(e.frozen||air||sp>16||K.exp>=1){ land(e,hx,hy,hz); return; } } }
  const bottom=e.y-K.d[2], sa=W.surfaceAt(e.x,e.z,bottom+.5);
  if(bottom<=sa){ if(W.terrainH(e.x,e.z)<WY-.05&&sa<=WY+.01){ waterLand(e); } else { if(!air&&sp<5&&!e.thrown){ e.y=sa+K.d[2]; e.vx=e.vy=e.vz=0; } else land(e,e.x,sa,e.z); } }
  if(e.fire&&Math.random()<dt*40){ FX.smoke(e.x,e.y,e.z,1,1.5); FX.fire(e.x,e.y,e.z,1,0,1,0,1.6); } }
function sinking(e,dt){ const K=e.K, big=K.c==="s"; e.sk+=dt*(K.c==="j"?.55:big?.08:.12); const k=e.sk;
  e.rol+=(e.sdir*(.6+k*1.1)-e.rol)*(1-Math.exp(-dt*.8)); e.pit+=((e.sdir>0?.35:-.5)*Math.min(1,k*1.5)-e.pit)*(1-Math.exp(-dt*.6));
  e.y-=(.25+k*k*(K.c==="j"?6:big?12:9))*dt; e.x+=e.vx*dt; e.z+=e.vz*dt; e.vx*=Math.exp(-dt*.6); e.vz*=Math.exp(-dt*.6);
  if(Math.random()<dt*14&&e.y+K.d[1]>WY){ rndPt(e,ap); FX.fire(ap.x,Math.max(ap.y,WY+.5),ap.z,1,0,2,0,1+K.exp*.4); FX.smoke(ap.x,ap.y+1,ap.z,1,1+K.exp*.4); }
  if(Math.random()<dt*8){ FX.E(false,e.x+rs()*K.d[0]*2,WY+.2,e.z+rs()*K.d[3],0,1.5,0,1.2,.8,3.2,[.9,.95,1],[.7,.85,1],.4,0,.96); }
  if(e.sk>.18&&Math.random()<dt*3) Game.splash&&Game.splash(e.x+rs()*K.d[0]*2,e.z+rs()*K.d[3],.5);
  if(e.y+K.d[1]<WY-1.5){ e.st="gone"; e.g.visible=false; if(e.wg) e.wg.visible=false; e.t=R(45,70); e.burning=false; Game.splash&&Game.splash(e.x,e.z,Math.min(4,1+K.exp)); } }
/* ---------- ana döngü ---------- */
function follow(e,dt){ const K=e.K, c=K.c, ox=e.x, oy=e.y, oz=e.z;
  let tgt=e.spd0; if(e.frozen) tgt=0; else if(e.burning&&c==="s") tgt*=.45; else if(e.burning&&c==="j") tgt*=.6; e.spd+=(tgt-e.spd)*(1-Math.exp(-dt*(e.frozen?1.6:.3)));
  e.pf(e,e.u,tO); e.pf(e,e.u+.003,tO2); const ddx=(tO2.x-tO.x)*e.dir, ddz=(tO2.z-tO.z)*e.dir, ddy=(tO2.y-tO.y)*e.dir, hl=Math.max(1e-3,Math.hypot(ddx,ddz)), ds=Math.hypot(hl,ddy)/.003;
  e.u+=e.dir*e.spd*dt/ds; e.pf(e,e.u,tO);
  let nx=tO.x, nz=tO.z, nyaw=Math.atan2(ddx,ddz);
  if(e.ox||e.oz){ const k=Math.exp(-dt*.2); e.ox*=k; e.oz*=k; nx+=e.ox; nz+=e.oz; if(Math.abs(e.ox)+Math.abs(e.oz)<.3) e.ox=e.oz=0; else nyaw=Math.atan2(tO.x+ddx/hl*45-nx,tO.z+ddz/hl*45-nz); }
  const oyaw=e.yaw; e.yaw+=aDiff(nyaw,e.yaw)*(1-Math.exp(-dt*(c==="a"?6:c==="j"?5:2))); const yr=aDiff(e.yaw,oyaw)/Math.max(dt,1e-3); e.yr+=(yr-e.yr)*(1-Math.exp(-dt*4));
  e.x=nx; e.z=nz; let tp=0, tr=0;
  if(c==="a"){ e.y=tO.y; tp=-Math.atan2(ddy,hl)*.9; tr=-clamp(Math.atan(e.spd*e.yr/(e.kind==="fighter"?10:15)),-.95,.95); const k=1-Math.exp(-dt*3); e.pit+=(tp-e.pit)*k; e.rol+=(tr-e.rol)*k; }
  else if(c==="j"){ const sp=e.spd/20; e.y=WY+.2+Math.abs(Math.sin(T*9+e.ph))*.1*sp+.04*Math.sin(T*5+e.ph); const k=1-Math.exp(-dt*5); e.pit+=(-.1*sp+.04*Math.sin(T*7+e.ph)-e.pit)*k; e.rol+=(-clamp(e.yr*e.spd*.05,-.55,.55)+.03*Math.sin(T*4+e.ph)-e.rol)*k; }
  else { const S=K.mass>=3?1:2.4; e.swT+=dt*2.8; e.swa*=Math.exp(-dt*.45); e.y=WY+.15+Math.sin(T*.8+e.ph)*.06*S+e.swa*Math.sin(e.swT*.9)*1.2; const k=1-Math.exp(-dt*2);
    e.pit+=(Math.sin(T*.55+e.ph)*.012*S+e.swa*.6*Math.cos(e.swT)-e.pit)*k; e.rol+=(clamp(e.yr*e.spd*.02,-.1,.1)+Math.sin(T*.7+e.ph*2)*.016*S+e.swa*Math.sin(e.swT)-e.rol)*k; }
  const idt=1/Math.max(dt,1e-3); e.vx=(e.x-ox)*idt; e.vy=(e.y-oy)*idt; e.vz=(e.z-oz)*idt; }
function effects(e,dt,near,hp){ const K=e.K, c=K.c;
  for(const s of e.ud.spin){ s.m.rotation[s.axis]+=s.rate*dt*(e.st==="wreck"?0:1); }
  for(const l of e.ud.lights){ const strobe=l.t===1||(l.t===2&&e.kind==="heli"); l.m.visible=!strobe||((T*(l.t===1?.9:1.1)+e.id*.37)%1)<.1; }
  if(e.ud.disc) e.ud.disc.visible=e.st!=="held"||true;
  if(near){
    if(c==="a"&&e.st==="cruise"){ const hf=Math.sin(e.yaw), hc=Math.cos(e.yaw);
      if((e.kind==="airliner"||e.kind==="fighter")&&e.y>250){ e.cT-=dt; if(e.cT<=0){ e.cT=.14; const n=e.kind==="airliner"?[-1,1]:[0], sd=e.kind==="airliner"?K.d[0]*.34:0;
          for(const sgn of n){ const px=e.x-hf*K.d[3]*.75+hc*sgn*sd, pz=e.z-hc*K.d[3]*.75-hf*sgn*sd; FX.E(false,px,e.y,pz,0,0,0,4.5,1.6,e.kind==="airliner"?15:10,[1,1,1],[.9,.94,1],.22,0,.996); } } }
      if(e.kind==="fighter"&&e.ud.burner){ const b=e.ud.burner, px=e.x+b[0]*hc+b[2]*hf, pz=e.z-b[0]*hf+b[2]*hc; FX.glow(px-hf*1.2,e.y,pz-hc*1.2,2.6,[1,.62,.2],.05); }
      if(e.kind==="heli"&&e.sl) searchlight(e,dt); }
    else if(c!=="a"&&(e.st==="cruise")&&e.spd>3){ e.sp-=dt; const hf=Math.sin(e.yaw), hc=Math.cos(e.yaw), ws=Math.cos(e.yaw), wz=-Math.sin(e.yaw);
      if(e.sp<=0){ e.sp=c==="j"?.05:.2+K.w*.04; const bx=e.x+hf*K.d[3]*.85, bz=e.z+hc*K.d[3]*.85, k=Math.min(1,e.spd/10);
        for(const sgn of [-1,1]) FX.E(false,bx,WY+.3,bz,ws*sgn*(1.5+K.w*1.4)+hf*e.spd*.2,R(.8,2)+K.w,wz*sgn*(1.5+K.w*1.4)+hc*e.spd*.2,.7,.4*(c==="j"?.6:1)*(1+K.w*.6),1.4*(1+K.w),[1,1,1],[.85,.93,1],.5*k,7,.96);
        if(c==="j"){ const sx=e.x-hf*K.d[3]*.9, sz=e.z-hc*K.d[3]*.9; for(let i=0;i<2;i++) FX.E(false,sx,WY+.4,sz,-hf*e.spd*.15+rs()*2,R(3.5,6),-hc*e.spd*.15+rs()*2,.85,.5,1.4,[1,1,1],[.8,.9,1],.55,14,.96); } } }
  }
  if(e.wg){ const on=(e.st==="cruise"||e.st==="sink")&&e.g.visible; e.wg.visible=on; if(on){ e.wg.position.set(e.x,WY+.07,e.z); e.wg.rotation.y=e.yaw; e.wm.opacity=clamp(e.spd/10,0,1)*.62*(e.st==="sink"?.4:1); } }
  if(e.burning&&alive(e)||e.burning&&e.st==="sink"){ e.bt+=dt; const n=Math.min(4,Math.ceil(dt*60*(K.exp+.6)*.22)); for(let i=0;i<n;i++){ rndPt(e,ap); FX.fire(ap.x,ap.y,ap.z,1,e.vx*.3,2,e.vz*.3,1+K.exp*.45); if(Math.random()<.35) FX.smoke(ap.x,ap.y+1,ap.z,1,1+K.exp*.4); }
    const kk=Math.max(.16,1-e.bt*.18); if(!e.frozen) tint(e,kk,kk*.95,kk*.9); if(!e.dead&&e.bt>K.burnT) destroy(e,"burn"); } }
function searchlight(e,dt){ const s=e.sl, on=(Game.night||0)>.28&&e.st==="cruise"; s.cone.visible=on; if(!on) return;
  const hf=Math.sin(e.yaw), hc=Math.cos(e.yaw), tx=e.x+hf*50+Math.sin(T*.7+e.ph)*30, tz=e.z+hc*50+Math.cos(T*.5+e.ph)*30, ty=W.surfaceAt(tx,tz,e.y);
  const sx=e.x+hf*2, sy=e.y-1.2, sz=e.z+hc*2; dv.set(tx-sx,ty-sy,tz-sz); const L=dv.length(); dv.multiplyScalar(1/L); qv.setFromUnitVectors(UPV,dv); s.cone.quaternion.copy(qv); s.cone.position.set(sx,sy,sz); s.cone.scale.set(Math.max(4,L*.09),L,Math.max(4,L*.09)); s.mat.opacity=.1*Math.min(1,((Game.night||0)-.28)*4);
  FX.glow(tx,ty+.3,tz,12,[1,.95,.78],.05); }
function solid(e,hp){ const d=e.K.d, cy=Math.cos(e.yaw), sy=Math.sin(e.yaw), rx=hp.x-e.x, rz=hp.z-e.z, lx=rx*cy-rz*sy, lz=rx*sy+rz*cy, ly=hp.y-e.y, pad=1.5;
  const px=d[0]+pad-Math.abs(lx), py=(ly>0?d[1]:d[2])+pad-Math.abs(ly), pz=d[3]+pad-Math.abs(lz); if(px<=0||py<=0||pz<=0) return;
  let nx=0,ny=0,nz=0,amt; if(px<=py&&px<=pz){ nx=Math.sign(lx)||1; amt=px; } else if(py<=pz){ ny=Math.sign(ly)||1; amt=py; } else { nz=Math.sign(lz)||1; amt=pz; }
  const wx=nx*cy+nz*sy, wz=-nx*sy+nz*cy; hp.x+=wx*amt; hp.y+=ny*amt; hp.z+=wz*amt; const vn=H.vel.x*wx+H.vel.y*ny+H.vel.z*wz; if(vn<0){ H.vel.x-=wx*vn; H.vel.y-=ny*vn; H.vel.z-=wz*vn; } }
function heroContact(e,hp){ const K=e.K, hs=H.speed;
  if(hs>=34){ if(e.rc>0) return; e.rc=.6; const v=H.vel, pw=K.c==="a"?9:(hs-28)/20+.5; hit(e,pw,v.x*.6,v.y*.4+4,v.z*.6,"ram"); FX.spark(hp.x,hp.y,hp.z,16,14); FX.dust(hp.x,hp.y,hp.z,6,4); Game.shakeAdd&&Game.shakeAdd(.6); if(au()) au().smash&&au().smash(.6); const k=K.c==="a"?.75:K.mass>=3?.5:.7; H.vel.multiplyScalar(k); }
  else solid(e,hp); }
Game.updaters.push((dt0,time,raw)=>{ const dt=Math.min(.05,dt0||0); T=time!==undefined?time:T+dt; if(!dt) return;
  if(!ready){ if(queue.length){ const job=queue.shift(); job(); } else ready=true; }
  const hp=hero.position, play=Game.mode==="play", held=Game.Lift&&Game.Lift.held;
  hornT-=dt;
  for(const e of ents){ if(e.rc>0) e.rc-=dt; if(e.pc>0) e.pc-=dt; const dx=hp.x-e.x, dz=hp.z-e.z, d2=dx*dx+dz*dz, near=d2<1500*1500; let draw=true;
    switch(e.st){
      case "cruise": if(e.ctl) e.ctl(e,dt); else follow(e,dt); if(e.frozen){ e.fT-=dt; if(e.fT<=0){ e.frozen=false; tint(e,1,1,1); FX.ice(e.x,e.y+2,e.z,8,3); } } break;
      case "held": break;
      case "fly": case "fall": ballistic(e,dt); break;
      case "sink": sinking(e,dt); break;
      case "wreck": e.t-=dt; if(Math.random()<dt*(e.t>0?10:0)){ FX.fire(e.wp.x+rs()*4,e.wp.y,e.wp.z+rs()*4,1,0,2,0,1.6); FX.smoke(e.wp.x+rs()*3,e.wp.y+1,e.wp.z+rs()*3,1,1.6); } if(e.t<=-3||e.wp.y<WY+.1&&e.t<=0){ e.st="gone"; e.t=R(30,50); } draw=false; break;
      case "gone": e.t-=dt; if(e.pol){ e.t=1e9; } else if(e.t<=0&&!(Game.Lift&&Game.Lift.target===e)) respawn(e); draw=false; break; }
    if(draw&&e.st!=="gone"){ sync(e); effects(e,dt,near,hp); }
    if(play&&alive(e)&&e.st!=="held"&&!(held&&Game.Lift.target===e)&&d2<(e.K.rr+6)*(e.K.rr+6)&&!(Game.Mounted&&Game.Mounted())){ if(boxD(e,hp.x,hp.y,hp.z,0)<1.4) heroContact(e,hp); }
    if(play&&e.st==="cruise"&&e.K.c==="a"&&near&&d2<90*90&&hornT<=0&&Math.abs(H.speed)>0&&au()){ /* yakından geçen uçak: kısa vuuuş */ hornT=6; if(au().whoosh) au().whoosh(); }
  } });
/* ---------- dış API ---------- */
function ray(ox,oy,oz,dx,dy,dz,maxT){ let best=null, bt=maxT;
  for(const e of ents){ if(!alive(e)||e.st==="held") continue; const ex=e.x-ox, ez=e.z-oz; if(ex*ex+ez*ez>(maxT+e.K.rr)*(maxT+e.K.rr)) continue;
    const d=e.K.d, cy=Math.cos(e.yaw), sy=Math.sin(e.yaw), rx=ox-e.x, rz=oz-e.z, ly=oy-e.y, lox=rx*cy-rz*sy, loz=rx*sy+rz*cy, ldx=dx*cy-dz*sy, ldz=dx*sy+dz*cy, pad=.6;
    const mn=[-d[0]-pad,-d[2]-pad,-d[3]-pad], mx=[d[0]+pad,d[1]+pad,d[3]+pad], o=[lox,ly,loz], v=[ldx,dy,ldz]; let t0=0,t1=bt,ok=true;
    for(let a=0;a<3&&ok;a++){ if(Math.abs(v[a])<1e-6){ if(o[a]<mn[a]||o[a]>mx[a]) ok=false; } else { let ta=(mn[a]-o[a])/v[a], tb=(mx[a]-o[a])/v[a]; if(ta>tb){ const q=ta; ta=tb; tb=q; } t0=Math.max(t0,ta); t1=Math.min(t1,tb); if(t0>t1) ok=false; } }
    if(ok&&t0<bt&&t0>=0){ bt=t0; best=e; } }
  return best?{t:bt,e:best}:null; }
function laser(e,dt,hitP){ if(!alive(e)) return; e.lz+=dt; FX.fire(hitP.x,hitP.y,hitP.z,1,0,2,0,1.2); if(e.lz>.3&&!e.burning) ignite(e); if(e.frozen&&e.lz>.5) { shatter(e); return; }
  e.hp-=dt*(e.K.c==="s"?.55:1.6); if(e.hp<=0) destroy(e,"laser"); }
function breath(mx,my,mz,L,range,th,fire,dt){ for(const e of ents){ if(!alive(e)||e.st==="held") continue; const vx=e.x-mx, vy=e.y-my, vz=e.z-mz, t=vx*L.x+vy*L.y+vz*L.z; if(t<-e.K.rr*.4||t>range+e.K.rr*.5) continue;
    const l2=vx*vx+vy*vy+vz*vz-t*t, w=Math.max(0,t)*th+e.K.rr*.55; if(l2>w*w) continue; if(fire) ignite(e); else freeze(e); } }
function punch(x,y,z,r,dx,dy,dz){ let n=0; for(const e of ents){ if(!alive(e)||e.st==="held"||e.pc>0) continue; if(boxD(e,x,y,z,0)>r) continue; e.pc=.35; n++; const K=e.K, pw=K.c==="s"&&K.mass>=3?.9:1.2, f=34/Math.max(.5,Math.sqrt(K.mass)); hit(e,pw,dx*f,dy*f*.4,dz*f,"punch"); if(au()) au().smash&&au().smash(.5); } return n; }
function radialHit(x,y,z,r,speed,kind){ let c=0; for(const e of ents){ if(!alive(e)||e.st==="held") continue; const dd=boxD(e,x,y,z,0); if(dd>r) continue; const K=e.K, pw=speed*(1-dd/r*.7); if(pw<8) continue; c++;
    let nx=e.x-x, nz=e.z-z; const nl=Math.hypot(nx,nz)||1; nx/=nl; nz/=nl;
    if(K.c==="a"){ if(pw>=22){ hit(e,3,nx*pw*.5,pw*.2,nz*pw*.5,kind); } else { e.swa=.2; e.yr+=rs()*.5; } }
    else { hit(e,pw/34,nx*pw*.6,pw*.15,nz*pw*.6,kind); } }
  return c; }
{ const r0=Game.radial; Game.radial=function(x,y,z,r,speed,kind){ let c=r0?r0.apply(this,arguments):0; if(Game.Sea) c+=radialHit(x,y,z,r,speed,kind); return c; }; }
/* kaldırma kancaları */
function nearest(x,y,z,reach){ let best=null, bd=reach; for(const e of ents){ if(e.st!=="cruise"&&e.st!=="fly"&&e.st!=="fall") continue; const dx=x-e.x, dz=z-e.z, rr=e.K.rr+reach; if(dx*dx+dz*dz>rr*rr) continue; const d=boxD(e,x,y,z,0); if(d<bd){ bd=d; best=e; } } return best?{e:best,dist:bd}:null; }
function grab(e){ if(!alive(e)||e.st==="held") return false; e.st="held"; e.thrown=false; e.vx=e.vy=e.vz=0; e.wx=e.wy=e.wz=0; e.spd=0; if(e.wg) e.wg.visible=false; if(e.K.c==="a"&&!e.dead){ e.hp=e.hp; } return true; }
function place(e,x,y,z,yaw,pit,rol){ e.x=x; e.y=y; e.z=z; e.yaw=yaw; e.pit=pit; e.rol=rol; sync(e); }
function release(e,vx,vy,vz,thrown){ if(e.st!=="held") return; e.st="fly"; e.vx=vx; e.vy=vy; e.vz=vz; e.thrown=!!thrown; e.wx=rs()*(thrown?2:.6); e.wy=rs()*(thrown?3:.5); e.wz=rs()*(thrown?4:.8); e.spd=0; if(e.K.c==="a"){ e.dead=true; e.burning=e.burning; e.fire=false; } }
function list(){ return ents; }
/* sahne kurulumu: modeller kare kare sıraya alınır (açılışta donma yok) */
function init(){ const C=counts(); let hi=0;
  C.ship&&SHIPS.slice(0,C.ship).forEach((k,i)=>queue.push(()=>{ const e=build(k,{}); setup(e,i,C.ship); }));
  for(let i=0;i<C.ski;i++) queue.push(()=>{ const e=build("jetski",{}); setup(e,i,C.ski); });
  C.air.forEach((k,i)=>queue.push(()=>{ const e=build(k,{hi:k==="heli"?hi++:0}); setup(e,i,C.air.length); })); }
init();
const polHelis=[]; for(let i=0;i<2;i++) queue.push(()=>{ const e=build("heli",{hi:0,pol:true,st:"gone",t:1e9}); e.spd0=34; e.spd=0; e.g.visible=false; if(e.sl) e.sl.cone.visible=false; e.hp=3; e.ptint=[.52,.68,1]; e.mat.color.setRGB(.52,.68,1); polHelis.push(e); });
function revive(e,x,y,z,yaw){ const K=e.K; e.hp=3; e.st="cruise"; e.burning=false; e.dead=false; e.bt=0; e.frozen=false; e.thrown=false; e.fire=false; e.vx=e.vy=e.vz=0; e.wx=e.wy=e.wz=0; e.swa=0; e.pit=e.rol=0; e.rc=0; e.lz=0; e.t=0; const c=e.ptint||[1,1,1]; e.mat.color.setRGB(c[0],c[1],c[2]);
  e.x=x; e.y=y; e.z=z; e.yaw=yaw||0; e.g.visible=true; if(e.wg) e.wg.visible=false; sync(e); }
function hideE(e){ e.st="gone"; e.t=1e9; e.g.visible=false; e.ctl=null; if(e.sl) e.sl.cone.visible=false; }
return {polHelis,revive,hideE,crash,ents,list,boxD,ray,laser,breath,punch,nearest,grab,place,release,hit,destroy,ignite,freeze,shatter,sync,KD,debug:{ready:()=>ready,queue}};
})();
