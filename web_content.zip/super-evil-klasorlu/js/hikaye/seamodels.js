"use strict";
/* ===== DENİZ & HAVA ARAÇ MODELLERİ: kargo/tanker/feribot/yat/balıkçı/yelkenli/jetski + yolcu uçağı/pervaneli/savaş uçağı/helikopter =====
   Eksenler: +z ileri, +y yukarı, x yanlar; su çizgisi y=0. Hepsi köşe renkli tek ağ (parça parça döner kısımlar ayrı ağ). */
Game.SeaKit=(function(){
  const GK=Game.CarKit.GK, hex=GK.hex, MB=GK.MB, box=GK.box, bar=GK.bar, loft=GK.loft, S=GK.S, part=GK.part, finish=GK.finish, WH=[1,1,1];
  const C={white:hex("#eef1f5"),off:hex("#d3d8df"),grey:hex("#8b929c"),dgrey:hex("#4a505a"),dark:hex("#1e2530"),black:hex("#14161a"),red:hex("#b3262e"),navy:hex("#16315c"),blue:hex("#2f6fb8"),teal:hex("#1f8a8a"),yellow:hex("#f0c020"),orange:hex("#e8741c"),green:hex("#2f7d46"),dgreen:hex("#24523a"),glass:hex("#0c1a2a"),wood:hex("#a9743f"),rust:hex("#7c3a22"),sky:hex("#6ec1ff")};
  const BOXC=["#c0392b","#2e86c1","#27ae60","#f1c40f","#e67e22","#7f8c8d","#8e44ad","#ecf0f1","#16a085","#a93226"].map(hex);
  const pick=a=>a[(Math.random()*a.length)|0];
  /* z ekseni boyunca tüp: istasyon {z,rx,ry,cx,cy,c} */
  function tubeZ(b,st,seg,caps,color){ const pos=[],idx=[],n=st.length;
    for(let i=0;i<n;i++){ const s=st[i]; for(let j=0;j<seg;j++){ const a=j/seg*6.28319; pos.push((s.cx||0)+s.rx*Math.cos(a),(s.cy||0)+s.ry*Math.sin(a),s.z); } }
    for(let i=0;i<n-1;i++) for(let j=0;j<seg;j++){ const j2=(j+1)%seg, a=i*seg+j,b2=i*seg+j2,c=(i+1)*seg+j2,d=(i+1)*seg+j; idx.push(a,b2,c,a,c,d); }
    if(caps!==false) for(const si of [0,n-1]){ const s=st[si], base=pos.length/3; pos.push(s.cx||0,s.cy||0,s.z); for(let j=0;j<seg;j++){ const a=j/seg*6.28319; pos.push((s.cx||0)+s.rx*Math.cos(a),(s.cy||0)+s.ry*Math.sin(a),s.z); } for(let j=0;j<seg;j++) idx.push(base,base+1+j,base+1+(j+1)%seg); }
    const start=b.c.length; part(b,pos,idx,color||WH);
    for(let i=0;i<n;i++) if(st[i].c) for(let j=0;j<seg;j++){ const o=start+(i*seg+j)*3; b.c[o]=st[i].c[0]; b.c[o+1]=st[i].c[1]; b.c[o+2]=st[i].c[2]; } }
  const TS=(z,rx,ry,cx,cy,c)=>({z,rx,ry,cx,cy,c});
  /* dışbükey çokgen prizma: axis y -> (u,v)=(x,z); x -> (z,y); z -> (x,y) */
  function extrude(b,poly,axis,off,th,color){ const n=poly.length, pos=[], idx=[];
    const P=(u,v,w)=>axis==="y"?[u,w,v]:axis==="x"?[w,v,u]:[u,v,w];
    for(const w of [off-th/2,off+th/2]) for(const q of poly){ const p=P(q[0],q[1],w); pos.push(p[0],p[1],p[2]); }
    for(let k=1;k<n-1;k++){ idx.push(0,k,k+1); idx.push(n,n+k+1,n+k); }
    for(let k=0;k<n;k++){ const k2=(k+1)%n; idx.push(k,k2,n+k2,k,n+k2,n+k); }
    part(b,pos,idx,color); }
  const mirrorX=poly=>poly.map(p=>[-p[0],p[1]]).reverse();
  /* gövde: istasyon {z,hw,yb,yt} (yb: alt, yt: üst) */
  const hull=(b,zs,hws,ybs,yts,y0,y1,color,top)=>{ loft(b,zs.map((z,i)=>{ const yt=Math.min(y1,Math.max(yts[i],y0+.1)), yb=Math.min(Math.max(y0,ybs[i]),yt-.08); return S(z,hws[i],yb,yt,top||.9); }),color); };
  function windowsRow(b,x,y,z0,z1,n,w,h,col){ const st=(z1-z0)/n; for(let i=0;i<n;i++) for(const sx of [-1,1]) box(b,sx*x,y,z0+st*(i+.5),.1,h,w,col||C.glass); }
  /* ---------- gemiler ---------- */
  function cargo(b){ const L=44, zs=[-22,-20,-8,10,17,20.5,22.5], hw=[3.2,4.1,4.1,4.1,3.2,1.8,.25], yb=[-2.6,-3.2,-3.2,-3.2,-2.4,-1.2,.6], yt=[3.2,3.2,3.2,3.3,3.5,3.9,4.3];
    hull(b,zs,hw,yb,yt,-4,0,C.red,.94); hull(b,zs,hw.map(v=>v*1.01),yb,yt,0,9,C.navy,1); hull(b,zs,hw.map(v=>v*.99),yt.map(v=>v-.08),yt.map(v=>v+.06),-1,9,C.dgrey,1);
    box(b,0,.18,-9,8.3,.2,26,C.black);
    for(let c=-1;c<=1;c++) for(let k=0;k<10;k++){ const h=1+((Math.random()*3)|0), z=-11+k*2.7; if(Math.random()<.08) continue; for(let s=0;s<h;s++) box(b,c*2.65,3.35+1.3+s*2.6,z,2.45,2.5,2.55,pick(BOXC)); }
    box(b,0,3.3+3.4,-17,7.4,6.6,5.2,C.white); box(b,0,3.3+7,-16.8,8.8,.5,3.2,C.off); box(b,0,3.3+8.3,-16.8,6.6,2.0,3.0,C.white); box(b,0,3.3+8.5,-15.25,6.4,1.1,.12,C.glass);
    for(let r=0;r<3;r++) box(b,0,3.3+2+r*1.9,-14.35,6.4,.8,.12,C.glass);
    box(b,0,3.3+11.2,-19.3,2.6,3.2,2.8,C.red); box(b,0,3.3+13.0,-19.3,2.8,.4,3.0,C.black); bar(b,[0,3.3+9.3,-16.8],[0,3.3+13.6,-16.8],.18,C.grey);
    for(const z of [-5,3,11]){ bar(b,[-3.8,3.4,z],[-3.8,5.2,z],.18,C.yellow); bar(b,[3.8,3.4,z],[3.8,5.2,z],.18,C.yellow); } return {r:25,hh:7}; }
  function tanker(b){ const zs=[-26,-24,-10,12,20,24.5,26.5], hw=[3.6,4.9,4.9,4.9,3.8,2.2,.3], yb=[-2.8,-3.5,-3.5,-3.5,-2.6,-1.3,.6], yt=[2.6,2.6,2.6,2.7,2.9,3.4,3.9];
    hull(b,zs,hw,yb,yt,-4,0,C.rust,.95); hull(b,zs,hw.map(v=>v*1.01),yb,yt,0,9,C.black,1); hull(b,zs,hw.map(v=>v*.99),yt.map(v=>v-.08),yt.map(v=>v+.06),-1,9,C.dgreen,1);
    for(const sx of [-1,1]) bar(b,[sx*.9,3.2,-12],[sx*.9,3.2,20],.32,C.grey);
    for(let k=0;k<7;k++){ const z=-11+k*4.4; box(b,0,3.0,z,7.6,.35,.3,C.grey); box(b,-2.6,3.05,z+2.2,2.3,.4,2.3,C.dgrey); box(b,2.6,3.05,z+2.2,2.3,.4,2.3,C.dgrey); }
    box(b,0,2.7+3,-22,7.8,6,5.4,C.white); box(b,0,2.7+6.4,-21.8,8.8,.5,3.4,C.off); box(b,0,2.7+7.6,-21.8,6.6,1.8,3,C.white); box(b,0,2.7+7.8,-20.25,6.4,1,.12,C.glass); box(b,0,2.7+2.4,-19.3,6.4,.8,.12,C.glass); box(b,0,2.7+4.2,-19.3,6.4,.8,.12,C.glass);
    box(b,0,2.7+10,-24.4,2.6,2.8,2.6,C.orange); box(b,0,2.7+11.5,-24.4,2.8,.4,2.8,C.black); bar(b,[0,2.7+8.5,-21.8],[0,2.7+12.4,-21.8],.18,C.grey); bar(b,[0,3.2,20],[0,7.6,20],.2,C.grey); return {r:29,hh:7}; }
  function ferry(b){ const zs=[-15,-13.5,-4,8,12,14.4,15.8], hw=[3.2,4.2,4.2,4.2,3.4,1.9,.3], yb=[-1.6,-2.0,-2.0,-2.0,-1.5,-.7,.4], yt=[2.4,2.4,2.4,2.5,2.7,3.1,3.5];
    hull(b,zs,hw,yb,yt,-3,0,C.navy,.94); hull(b,zs,hw.map(v=>v*1.01),yb,yt,0,9,C.white,1); hull(b,zs,hw.map(v=>v*1.02),yb,yt.map(()=>.7),0,.7,C.blue,1); hull(b,zs,hw.map(v=>v*.99),yt.map(v=>v-.06),yt.map(v=>v+.05),-1,9,C.grey,1);
    box(b,0,2.5+1.1,-1,6.6,2.2,19.5,C.white); windowsRow(b,3.32,2.5+1.2,-10.2,8.2,12,1.1,.8); box(b,0,2.5+2.5,-.8,5.8,.35,17,C.off);
    box(b,0,2.5+3.8,-1.6,5.6,2.2,13,C.white); windowsRow(b,2.82,2.5+3.9,-7.6,4.4,9,1,.8); box(b,0,2.5+5.2,-2.4,5.9,.3,9,C.off);
    box(b,0,2.5+6.3,.6,4.6,2,6.5,C.white); box(b,0,2.5+6.5,3.9,4.5,1.0,.12,C.glass); box(b,0,2.5+8,-5.8,2.3,3.0,2.6,C.red); box(b,0,2.5+9.7,-5.8,2.5,.35,2.8,C.black); bar(b,[0,2.5+7.2,1],[0,2.5+10.5,1],.14,C.grey); box(b,0,2.5+10.5,1,.1,.5,2,C.grey);
    for(const sx of [-1,1]) for(let k=0;k<3;k++) box(b,sx*2.9,2.5+4.7,-5+k*2.6,.9,.7,2.2,C.orange); return {r:17,hh:12}; }
  function yacht(b){ const zs=[-7,-6.2,-1,3,5.6,6.9,7.4], hw=[1.8,2.1,2.1,1.9,1.2,.5,.1], yb=[-.55,-.8,-.8,-.7,-.45,-.1,.3], yt=[.95,.95,.95,1.0,1.2,1.35,1.5];
    hull(b,zs,hw,yb,yt,-1,0,C.navy,.94); hull(b,zs,hw.map(v=>v*1.01),yb,yt,0,5,C.white,1); hull(b,zs,hw.map(v=>v*.98),yt.map(v=>v-.05),yt.map(v=>v+.04),-1,5,C.wood,1);
    box(b,0,1.0+.75,-1.8,2.9,1.5,5.6,C.white); box(b,0,1.0+1.0,-1.8,3.0,.5,4.8,C.glass); box(b,0,1.0+1.7,-2.4,2.5,.18,4.2,C.off); box(b,0,1.0+2.3,-2.6,2.0,1.0,2.6,C.white); box(b,0,1.0+2.45,-1.25,1.9,.55,.1,C.glass);
    bar(b,[0,1.0+2.8,-3.4],[0,1.0+5.2,-3.4],.1,C.grey); box(b,0,1.0+5.4,-3.4,.7,.3,.7,C.dgrey); box(b,0,.5+1,2.8,1.6,.1,2.6,C.sky); return {r:8,hh:6}; }
  function fishing(b){ const zs=[-6,-5.4,-1,3,4.8,5.8,6.2], hw=[1.5,1.9,1.9,1.7,1.0,.45,.1], yb=[-.8,-1.0,-1.0,-.9,-.6,-.2,.3], yt=[.9,.9,.9,1.0,1.3,1.6,1.9];
    hull(b,zs,hw,yb,yt,-1.2,0,C.rust,.94); hull(b,zs,hw.map(v=>v*1.01),yb,yt,0,5,pick([C.blue,C.red,C.teal]),1); hull(b,zs,hw.map(v=>v*.98),yt.map(v=>v-.05),yt.map(v=>v+.04),-1,5,C.dgrey,1);
    box(b,0,1+1.1,2.2,2.4,2.2,2.6,C.white); box(b,0,1+1.6,3.55,2.3,.8,.1,C.glass); box(b,0,1+2.4,2.2,2.7,.2,2.9,C.off);
    bar(b,[0,1,-1.2],[0,6.2,-1.2],.14,C.grey); bar(b,[0,5.0,-1.2],[0,3.2,-5.2],.08,C.grey); bar(b,[0,4.2,-1.2],[0,1.2,-4.6],.07,C.dgrey);
    box(b,.6,1.35,-3.4,1.3,.6,1.7,C.orange); box(b,-.7,1.3,-4.4,1,.5,1.2,C.yellow); return {r:7,hh:6}; }
  function sail(b){ const zs=[-4.4,-3.8,-.8,2,3.8,4.4], hw=[1.1,1.25,1.25,1.0,.4,.08], yb=[-.55,-.7,-.7,-.55,-.2,.2], yt=[.55,.55,.55,.6,.8,1];
    hull(b,zs,hw,yb,yt,-1,0,C.red,.94); hull(b,zs,hw.map(v=>v*1.01),yb,yt,0,5,C.white,1); hull(b,zs,hw.map(v=>v*.98),yt.map(v=>v-.04),yt.map(v=>v+.03),-1,5,C.wood,1);
    box(b,0,.55+.4,-1.6,1.4,.8,2.4,C.white); box(b,0,.55+.5,-.3,1.2,.3,.1,C.glass); bar(b,[0,.5,.6],[0,9.4,.6],.12,C.grey);
    const sc=pick([C.white,C.white,C.off,hex("#ffd9a0")]); extrude(b,[[-.3,1.2],[-.3,8.9],[-3.9,1.4]],"x",0,.07,sc); extrude(b,[[1.0,1.2],[1.0,8.4],[3.9,1.0]],"x",0,.07,C.red); bar(b,[0,1.25,-.3],[0,1.4,-3.9],.1,C.grey); return {r:6,hh:10}; }
  function jetski(b){ const col=pick([C.red,C.yellow,C.blue,C.green,C.orange]);
    loft(b,[S(-1.4,.3,-.12,.28,.7),S(-.9,.36,-.22,.4,.85),S(0,.4,-.22,.46,.85),S(.9,.36,-.18,.42,.8),S(1.5,.14,-.05,.38,.7),S(1.7,.02,.15,.4,.7)],col);
    loft(b,[S(-1.4,.28,-.2,-.08,.9),S(0,.38,-.26,-.06,.9),S(1.4,.12,-.1,0,.9)],C.dark);
    box(b,0,.5,-.45,.4,.16,1.2,C.black); extrude(b,[[-.28,.2],[.28,.2],[.2,.78],[-.2,.78]],"z",.7,.05,C.glass); bar(b,[-.34,.62,.78],[.34,.62,.78],.07,C.black);
    box(b,0,.98,-.35,.34,.52,.26,pick([C.orange,C.white,C.navy])); box(b,0,1.36,-.35,.2,.2,.2,hex("#e8b896")); box(b,0,1.42,-.35,.26,.14,.28,C.white);
    box(b,-.2,.88,.0,.1,.1,.55,hex("#e8b896")); box(b,.2,.88,.0,.1,.1,.55,hex("#e8b896")); box(b,-.2,.55,-.45,.12,.5,.14,C.dark); box(b,.2,.55,-.45,.12,.5,.14,C.dark); return {r:2.2,hh:1.6}; }
  /* ---------- uçaklar ---------- */
  function airliner(b){ const fin=pick([C.red,C.blue,C.teal,C.green,C.orange]);
    tubeZ(b,[TS(-19,.3,.3,0,1.5),TS(-15.5,1.0,1.05,0,1.0),TS(-8,1.95,2.0,0,.2),TS(8,2.0,2.05,0,0),TS(14.5,1.7,1.75,0,-.05),TS(18,.9,.95,0,-.2,C.off),TS(19.7,.12,.14,0,-.3,C.dgrey)],14,true,C.white);
    tubeZ(b,[TS(-19,.3,.3,0,1.5,C.grey),TS(-15.5,1.0,1.05,0,1.0,C.grey)],14,false,C.grey);
    for(const sx of [-1,1]) for(let k=0;k<18;k++) box(b,sx*1.84,.85,-11+k*1.25,.09,.4,.5,C.glass);
    extrude(b,[[1.8,4.8],[1.8,-3.2],[17.5,-9.6],[17.5,-6.6]],"y",-.9,.34,C.off); extrude(b,mirrorX([[1.8,4.8],[1.8,-3.2],[17.5,-9.6],[17.5,-6.6]]),"y",-.9,.34,C.off);
    for(const sx of [-1,1]){ tubeZ(b,[TS(4.6,1.05,1.05,sx*6.6,-1.9,C.dgrey),TS(3.9,1.15,1.15,sx*6.6,-1.9,C.grey),TS(-1.2,1.1,1.1,sx*6.6,-1.9,C.off),TS(-2.2,.7,.7,sx*6.6,-1.9,C.dgrey)],12,true,C.off); }
    extrude(b,[[-19,1.2],[-12.8,1.6],[-17.2,9.6],[-19.8,9.6]],"x",0,.42,fin); extrude(b,[[.3,-16],[.3,-19.2],[7.6,-21.4],[7.6,-19.4]],"y",1.9,.22,C.off); extrude(b,mirrorX([[.3,-16],[.3,-19.2],[7.6,-21.4],[7.6,-19.4]]),"y",1.9,.22,C.off); return {r:21,hh:7,lights:[[-17.4,9.8,-19.4,1],[-17.5,-.9,-9.4,2],[17.5,-.9,-9.4,3],[0,2.2,-2,1]],gear:0}; }
  function prop(b){ const cc=pick([C.yellow,C.red,C.blue,C.orange]);
    tubeZ(b,[TS(-4.8,.14,.16,0,.55),TS(-3,.42,.5,0,.4),TS(-.6,.68,.72,0,.1),TS(1.6,.64,.68,0,.08),TS(2.7,.5,.5,0,0),TS(3.0,.12,.12,0,0,C.dark)],10,true,C.white);
    tubeZ(b,[TS(-.6,.7,.74,0,.1,cc),TS(1.6,.66,.7,0,.08,cc)],10,false,cc);
    box(b,0,.78,.4,1.1,.55,1.3,C.glass); extrude(b,[[.6,1.6],[.6,-.2],[7,-.5],[7,.7]],"y",.62,.16,cc); extrude(b,mirrorX([[.6,1.6],[.6,-.2],[7,-.5],[7,.7]]),"y",.62,.16,cc);
    extrude(b,[[-4.9,.5],[-3.2,.5],[-4.5,2.9],[-5.2,2.9]],"x",0,.14,cc); extrude(b,[[.2,-4.0],[.2,-5.1],[2.4,-5.2],[2.4,-4.2]],"y",.55,.1,C.off); extrude(b,mirrorX([[.2,-4.0],[.2,-5.1],[2.4,-5.2],[2.4,-4.2]]),"y",.55,.1,C.off);
    for(const sx of [-1,1]){ bar(b,[sx*.5,-.3,.8],[sx*.6,-.9,.8],.07,C.dark); box(b,sx*.6,-1.0,.8,.18,.45,.45,C.black); } bar(b,[0,-.3,2.4],[0,-.9,2.4],.07,C.dark); box(b,0,-1.0,2.4,.12,.4,.4,C.black); return {r:7.5,hh:3,lights:[[7,.6,-.2,2],[-7,.6,-.2,3],[0,2.9,-4.9,1]],prop:{z:3.05,y:0,n:2,len:1.7}}; }
  function fighter(b){ const gc=C.dgrey;
    tubeZ(b,[TS(-7,.36,.34,0,0,C.dark),TS(-5.4,.62,.55,0,0),TS(-1,.82,.62,0,.1),TS(3.2,.62,.46,0,0),TS(6.4,.28,.22,0,-.05),TS(7.8,.05,.05,0,-.05,C.dark)],10,true,gc);
    extrude(b,[[.7,3],[.7,-5],[7.4,-6.6],[6.2,-.6]],"y",-.05,.2,C.grey); extrude(b,mirrorX([[.7,3],[.7,-5],[7.4,-6.6],[6.2,-.6]]),"y",-.05,.2,C.grey);
    for(const sx of [-1,1]){ extrude(b,[[-5.4,.4],[-3,.4],[-4.1,2.8],[-5.4,3.0]],"x",sx*.8,.16,C.dgrey); box(b,sx*.95,.25,1.8,.6,.55,2.4,C.dark); extrude(b,sx>0?[[.4,-6],[.4,-7.1],[3,-7.4],[2.6,-6.3]]:mirrorX([[.4,-6],[.4,-7.1],[3,-7.4],[2.6,-6.3]]),"y",.0,.14,C.grey); }
    box(b,0,.78,2.6,.7,.4,1.8,C.glass); box(b,0,.7,1.4,.9,.35,.9,C.glass); tubeZ(b,[TS(-7,.34,.32,0,0,C.black),TS(-7.8,.26,.24,0,0,C.orange)],8,true,C.orange); return {r:8.5,hh:3,lights:[[7.4,0,-6.6,2],[-7.4,0,-6.6,3]],burner:[0,0,-7.9]}; }
  function heli(b){ const cc=pick([C.white,C.blue,C.red,C.yellow]);
    tubeZ(b,[TS(-3.4,.22,.34,0,.45),TS(-2.8,.7,.9,0,.1),TS(-.8,.95,1.12,0,0),TS(1.6,.92,1.1,0,-.05),TS(2.5,.55,.65,0,-.2),TS(2.85,.14,.2,0,-.3,C.grey)],12,true,cc);
    tubeZ(b,[TS(-2.6,.34,.38,0,.45),TS(-6,.2,.24,0,.55),TS(-9.2,.1,.13,0,.62)],8,true,cc); extrude(b,[[-8,.55],[-9.4,.55],[-9.9,2.3],[-8.7,2.2]],"x",0,.14,C.red); extrude(b,[[.2,-7.2],[.2,-8.6],[2.3,-8.9],[2.3,-7.6]],"y",.6,.1,cc); extrude(b,mirrorX([[.2,-7.2],[.2,-8.6],[2.3,-8.9],[2.3,-7.6]]),"y",.6,.1,cc);
    box(b,0,.28,1.95,1.3,.72,1.25,C.glass); for(const sx of [-1,1]){ box(b,sx*.94,.2,-.5,.1,.8,1.6,C.glass); box(b,sx*.94,.2,1.0,.1,.8,.9,C.glass); }
    box(b,0,1.25,-.4,1.2,.4,1.4,C.dgrey); bar(b,[0,1.1,-.4],[0,1.9,-.4],.2,C.dark); box(b,0,1.28,.2,.9,.14,.3,C.red);
    for(const sx of [-1,1]){ bar(b,[sx*1.15,-1.55,-2.0],[sx*1.15,-1.5,2.4],.1,C.dark); bar(b,[sx*1.15,-1.55,2.4],[sx*1.15,-1.2,2.8],.09,C.dark); bar(b,[sx*1.05,-.9,-.9],[sx*1.15,-1.55,-.9],.09,C.dark); bar(b,[sx*1.05,-.9,.9],[sx*1.15,-1.55,.9],.09,C.dark); }
    return {r:8,hh:3,lights:[[0,1.35,.2,2],[0,.9,-9,1]],rotor:{y:1.95,n:2,len:6.6},tail:{y:.62,z:-9.2,len:1.5}}; }
  const MODELS={cargo,tanker,ferry,yacht,fishing,sail,jetski,airliner,prop,fighter,heli};
  /* spin parçaları: ana rotor + kuyruk rotoru + pervane (ayrı ağ; döndürülür) */
  function spinGeo(kind,spec){ const b=MB();
    if(kind==="rotor"){ for(let k=0;k<spec.n;k++){ const a=k/spec.n*Math.PI*2; bar(b,[0,0,0],[Math.cos(a)*spec.len,0,Math.sin(a)*spec.len],.22,C.dark); } box(b,0,.05,0,.5,.3,.5,C.grey); }
    else if(kind==="tail"){ for(let k=0;k<2;k++){ const a=k*Math.PI; bar(b,[0,0,0],[0,Math.cos(a)*spec.len,Math.sin(a)*spec.len],.14,C.dark); } box(b,0,0,0,.14,.3,.3,C.grey); }
    else if(kind==="prop"){ for(let k=0;k<spec.n;k++){ const a=k*Math.PI*2/spec.n; bar(b,[0,0,0],[Math.cos(a)*spec.len,Math.sin(a)*spec.len,0],.13,C.dark); } box(b,0,0,.1,.3,.3,.4,C.red); }
    return finish(b); }
  const lightGeo=new THREE.BoxGeometry(.5,.5,.5), LC=[0xffffff,0xffffff,0xff2a2a,0x2aff5a];
  const GC={};
  /* geometri kind+variant başına bir kez kurulur; her araç kendi malzemesini (renk tonu, yanma, buz) taşır */
  function make(kind,variant){ const key=kind+"#"+(variant|0); let rec=GC[key]; if(!rec){ const b=MB(), info=MODELS[kind](b); rec=GC[key]={geo:finish(b),info,spin:{}}; }
    const info=rec.info, g=new THREE.Group();
    const mat=Game.noSnow(new THREE.MeshStandardMaterial({vertexColors:true,roughness:.55,metalness:.12})); const m=new THREE.Mesh(rec.geo,mat); m.castShadow=false; g.add(m); g.userData={kind,r:info.r,hh:info.hh,mats:[mat],body:m,spin:[],lights:[],burner:info.burner||null};
    const addSpin=(k,spec,pos,axisRot,rate)=>{ const sg=rec.spin[k]||(rec.spin[k]=spinGeo(k,spec)), sm=new THREE.Mesh(sg,mat); sm.position.set(pos[0],pos[1],pos[2]); if(axisRot) sm.rotation.order="YXZ"; g.add(sm); g.userData.spin.push({m:sm,axis:k==="rotor"?"y":k==="tail"?"x":"z",rate}); };
    if(info.rotor) addSpin("rotor",info.rotor,[0,info.rotor.y,-.4],false,38); if(info.tail) addSpin("tail",info.tail,[.28,info.tail.y,info.tail.z],false,60); if(info.prop) addSpin("prop",info.prop,[0,info.prop.y,info.prop.z],false,55);
    if(info.rotor){ const disc=new THREE.Mesh(new THREE.CircleGeometry(info.rotor.len,22),new THREE.MeshBasicMaterial({color:0xdde6ee,transparent:true,opacity:.1,depthWrite:false,side:THREE.DoubleSide})); disc.rotation.x=-Math.PI/2; disc.position.set(0,info.rotor.y+.02,-.4); g.add(disc); g.userData.disc=disc; }
    if(info.lights) for(const L of info.lights){ const lm=new THREE.Mesh(lightGeo,new THREE.MeshBasicMaterial({color:LC[L[3]]})); lm.position.set(L[0],L[1],L[2]); lm.scale.setScalar(kind==="airliner"?1.1:.6); g.add(lm); g.userData.lights.push({m:lm,t:L[3]}); }
    return g; }
  return {make,MODELS,list:Object.keys(MODELS),C};
})();
