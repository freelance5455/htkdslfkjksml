"use strict";
/* ===== ANTİK ADA (Mısır) v8: piramitler, sfenks, tapınak + pilon + sfenks caddesi, firavun heykelleri, köy/pazar, vaha + kanal, iskele,
   yarım kalmış piramit şantiyesi, harabeler, mastabalar, deve sürüsü. Etkileşim (deve/heykel kırma) egypt.js içinde. ===== */
(function(){
const CG=Game.CG, W=Game.W, fbox=CG.fbox, rbox=CG.rbox, L=CG.lists, rnd=CG.rnd, pick=CG.pick, TAU=Math.PI*2, B=Game.buildings;
const AI=W.islands.find(i=>i.id==="ancient"), AX=AI.x, AZ=AI.z;
const gh=(x,z)=>W.terrainH(x,z), dry=(x,z)=>W.terrainH(x,z)>-.5, solid=(x,z,hw,hd,h,y0)=>B.push({x,z,hw,hd,h,y0:y0||0});
function maxH(x,z,hw,hd){ let m=-99; for(let i=-1;i<=1;i+=.5) for(let j=-1;j<=1;j+=.5) m=Math.max(m,gh(x+i*hw,z+j*hd)); return Math.max(0,m); }
const E=Game.Egypt={AX,AZ,camels:[],statues:[],braziers:[],walk:{rings:[],paths:[]}};
const upd=Game.islandUpdaters||(Game.islandUpdaters=[]);
const used=[], mark=(u,v,r)=>used.push([AX+u,AZ+v,r]), free=(x,z,r)=>{ for(const q of used) if(Math.hypot(q[0]-x,q[1]-z)<q[2]+r) return false; return true; };
const SAND="#e4cc96", SAND2="#d8c28a", SAND3="#cdb27a", STONE="#c9b07a", GOLD="#e8c14a", BLUE="#2a5db0", DARKW="#5e4126";

/* ---------- hiyeroglif şeritleri (tuval çizimi; yazı tipi gerekmez) ---------- */
function glyph(q,k,x,y,s){ q.save(); q.translate(x,y); q.lineWidth=Math.max(1.5,s*.07); q.beginPath();
  switch(k%9){
    case 0: q.moveTo(-s*.45,0); q.quadraticCurveTo(0,-s*.4,s*.45,0); q.quadraticCurveTo(0,s*.3,-s*.45,0); q.stroke(); q.beginPath(); q.arc(0,-.02*s,s*.13,0,TAU); q.fill(); q.beginPath(); q.moveTo(-s*.1,s*.1); q.lineTo(-s*.15,s*.45); q.moveTo(s*.05,s*.1); q.quadraticCurveTo(s*.3,s*.3,s*.1,s*.5); q.stroke(); break;
    case 1: q.arc(0,-s*.22,s*.17,0,TAU); q.moveTo(0,-s*.05); q.lineTo(0,s*.45); q.moveTo(-s*.25,s*.08); q.lineTo(s*.25,s*.08); q.stroke(); break;
    case 2: for(let i=0;i<3;i++){ const yy=-s*.25+i*s*.25; q.moveTo(-s*.4,yy); q.lineTo(-s*.2,yy-s*.1); q.lineTo(0,yy+s*.1); q.lineTo(s*.2,yy-s*.1); q.lineTo(s*.4,yy); } q.stroke(); break;
    case 3: q.ellipse(0,s*.05,s*.3,s*.18,-.2,0,TAU); q.moveTo(s*.28,-s*.05); q.lineTo(s*.4,-s*.3); q.lineTo(s*.2,-s*.12); q.moveTo(-s*.1,s*.2); q.lineTo(-s*.1,s*.42); q.moveTo(s*.05,s*.2); q.lineTo(s*.05,s*.42); q.stroke(); break;
    case 4: q.arc(0,0,s*.22,0,TAU); q.moveTo(-s*.45,s*.3); q.quadraticCurveTo(0,-s*.55,s*.45,s*.3); q.stroke(); q.beginPath(); q.arc(0,0,s*.1,0,TAU); q.fill(); break;
    case 5: q.ellipse(0,0,s*.22,s*.3,0,0,TAU); for(const sg of [-1,1]) for(let i=0;i<3;i++){ q.moveTo(sg*s*.2,-s*.15+i*s*.15); q.lineTo(sg*s*.42,-s*.25+i*s*.2); } q.moveTo(0,-s*.3); q.lineTo(0,s*.3); q.stroke(); break;
    case 6: q.ellipse(0,0,s*.1,s*.42,0,0,TAU); q.moveTo(0,-s*.4); q.lineTo(0,s*.5); for(let i=0;i<4;i++){ q.moveTo(0,-s*.25+i*s*.15); q.lineTo(s*.1,-s*.32+i*s*.15); } q.stroke(); break;
    case 7: q.moveTo(0,-s*.45); q.lineTo(0,s*.4); q.moveTo(0,s*.4); q.lineTo(-s*.14,s*.5); q.moveTo(0,s*.4); q.lineTo(s*.14,s*.5); q.moveTo(-s*.12,-s*.45); q.lineTo(s*.12,-s*.45); q.lineTo(s*.12,-s*.25); q.stroke(); break;
    default: q.moveTo(-s*.4,s*.35); q.lineTo(0,-s*.4); q.lineTo(s*.4,s*.35); q.closePath(); q.stroke(); q.beginPath(); q.moveTo(-s*.2,s*.05); q.lineTo(s*.2,s*.05); q.stroke(); }
  q.restore(); }
const hMat={}, hGeo={};
function hiero(w,h,seed,x,y,z,ry,bg,fg){ const key=Math.round(w*4)+"x"+Math.round(h*4)+"s"+seed+(bg||""); let m=hMat[key];
  if(!m){ const c=document.createElement("canvas"); c.width=256; c.height=Math.max(32,Math.round(256*h/w)); const q=c.getContext("2d"); q.fillStyle=bg||"#d9c18a"; q.fillRect(0,0,c.width,c.height);
    q.strokeStyle=fg||"#4a3320"; q.fillStyle=fg||"#4a3320"; q.lineWidth=3; q.strokeRect(3,3,c.width-6,c.height-6); q.beginPath(); q.moveTo(3,c.height*.14); q.lineTo(c.width-3,c.height*.14); q.moveTo(3,c.height*.86); q.lineTo(c.width-3,c.height*.86); q.stroke();
    const cell=c.height*.62, n=Math.max(1,Math.floor(c.width/(cell*1.12))); let s=seed*9301+49297; const rd=()=>{ s=(s*9301+49297)%233280; return s/233280; };
    for(let i=0;i<n;i++) glyph(q,Math.floor(rd()*9),(i+.5)*c.width/n,c.height*.5,cell);
    const t=new THREE.CanvasTexture(c); t.anisotropy=4; m=hMat[key]=CG.std({map:t,roughness:.95,polygonOffset:true,polygonOffsetFactor:-2,polygonOffsetUnits:-2}); }
  const gk=Math.round(w*10)+"_"+Math.round(h*10), g=hGeo[gk]||(hGeo[gk]=new THREE.PlaneGeometry(w,h)), mesh=new THREE.Mesh(g,m); mesh.position.set(x,y,z); mesh.rotation.y=ry||0; mesh.receiveShadow=true; scene.add(mesh); return mesh; }
/* yıkılabilir kabuğun bir yan yüzündeki her panele hiyeroglif şeridi (panel yıkılınca şerit de gider) */
function hieroWall(t,side,h,y,seed){ if(!t||!t.pan) return; t.walls[0].forEach((id,i)=>{ const p=t.pan[i]; if(!p||p.s!==side) return; const c=Game.D.chunks[id], off=.09, w=(side===0||side===2)?p.sx:p.sz;
    const x=p.cx+(side===1?p.sx/2+off:side===3?-p.sx/2-off:0), z=p.cz+(side===0?p.sz/2+off:side===2?-p.sz/2-off:0), ry=side===0?0:side===2?Math.PI:side===1?Math.PI/2:-Math.PI/2;
    CG.attach(c,hiero(w,h,seed+i,x,y,z,ry)); }); }

/* ---------- piramitler ---------- */
const pyramid=(px,pz,w0,n,tier,Tn,door,doorW,roofRh,y0)=>{ const bl=CG.bl(); for(let i=0;i<n;i++){ const w=w0-i*tier;
    CG.tier(bl,{x:px,z:pz,w,d:w,y0:(y0||0)+i*4,h:4,LH:4,T:Tn,style:"n",tint:i&1?"#eed9a8":"#e4cc96",kind:"tomb",door:i===0?door:undefined,doorW:doorW||3.4,ic:"#d9c18a",fc:"#b59a62",cc:"#cdb27a",roof:i===n-1?"hip":"none",roofCol:GOLD,rh:roofRh||6}); } return bl; };
pyramid(AX,AZ-5,68,15,4,2.4,0,5,9); mark(0,-5,50);
pyramid(AX-62,AZ-12,28,6,4,1.6,0,3.4,5); mark(-62,-12,22);
pyramid(AX+66,AZ+6,24,5,4,1.6,0,3.4,5); mark(66,6,20);

/* ---------- tapınak + avlu ---------- */
{ const tx=AX, tz=AZ+58, A=CG.F(tx,tz), bl=CG.bl();
  fbox(A,tx,0,tz+4,38,.35,30,SAND2);
  const t=CG.tier(bl,{x:tx,z:tz,w:28,d:14,y0:.35,h:8,LH:8,T:1.2,style:"n",tint:"#efdcae",kind:"tomb",door:0,doorW:3.6,ic:"#d9c18a",fc:"#b59a62",cc:SAND3,roof:"flat",slabCol:SAND2,parCol:SAND3});
  hieroWall(t,0,3.2,5.6,11); hieroWall(t,1,3.2,5.6,41); hieroWall(t,3,3.2,5.6,71);
  for(let k=0;k<6;k++){ const x=tx+(k<3?-1:1)*(2.7+Math.abs((k%3))*5.4), AA=CG.F(x,tz+9); CG.cyl(AA,x,.35,tz+9.2,1.0,.88,8.2,12,"#ecd9a8",true); fbox(AA,x,.35,tz+9.2,2.5,.5,2.5,SAND3); fbox(AA,x,8.5,tz+9.2,2.5,.5,2.5,SAND3); }
  fbox(A,tx,8.95,tz+9.2,34,.9,3,SAND2); fbox(A,tx,9.85,tz+9.2,34.6,.35,3.6,GOLD);
  CG.sign("TEMPLE OF RA",11,1.5,BLUE,"#ffd23f",tx,9.4,tz+10.76,0);
  for(const s of [-1,1]){ const ox=tx+s*24, oz=tz+10, AA=CG.F(ox,oz); fbox(AA,ox,0,oz,5,.8,5,"#c49a4e"); CG.cyl(AA,ox,.8,oz,2.3,1.4,24,4,"#d9b66b",true); CG.cyl(AA,ox,24.8,oz,1.4,0,2.8,4,GOLD); solid(ox,oz,2.6,2.6,28);
    const sx=tx+s*17, sz=tz+13; fbox(AA,sx,0,sz,2.6,1.2,2.6,"#c49a4e"); fbox(AA,sx,1.2,sz,1.4,3.3,.9,"#2a2d33"); fbox(AA,sx,4.5,sz,1.0,1.1,.9,"#2a2d33"); fbox(AA,sx,5.0,sz+.9,.6,.55,1.1,"#2a2d33"); fbox(AA,sx-.28,5.4,sz,.2,1.1,.3,"#2a2d33"); fbox(AA,sx+.28,5.4,sz,.2,1.1,.3,"#2a2d33"); fbox(AA,sx,3.6,sz+.1,1.4,.35,1.0,GOLD); solid(sx,sz,1.4,1.4,6.6); }
  fbox(A,tx,.35,tz+17,6,.05,12,"#b59a62");
  mark(0,62,44); }
/* pazar kulübeleri (tapınak ile piramit arası) */
for(const [x,z,tx] of [[AX-14,AZ+40,"#e8d2a0"],[AX+14,AZ+40,"#d9b88a"],[AX-24,AZ+37,"#e8c8a0"],[AX+24,AZ+37,"#cfe0b0"]]){ const bl=CG.bl(); CG.tier(bl,{x,z,w:5.4,d:5.4,y0:0,h:4,LH:4,T:.45,style:"b",tint:tx,kind:"shop",door:0,doorW:2.3,ic:"#fff3e0",fc:"#caa27a",cc:"#fffaf0",roof:"hip",roofCol:pick(["#2a5db0","#c0392b","#2e9d5a","#d9a441"]),rh:2.4}); }

/* ---------- sfenks ---------- */
{ const sx=AX+44, sz=AZ-32, A=CG.F(sx,sz), SC="#dcb866", SD="#c49a4e", SB=BLUE, SG=GOLD;
  fbox(A,sx,0,sz,7.4,.8,19,"#c9a65a"); fbox(A,sx,.8,sz-1,5.6,3.4,13,SC); fbox(A,sx,.8,sz-5.4,6.4,4.4,4.2,SD); fbox(A,sx,.8,sz+6.2,5,4.9,3.8,SC); fbox(A,sx-1.55,.8,sz+9.6,1.6,1.2,5,SC); fbox(A,sx+1.55,.8,sz+9.6,1.6,1.2,5,SC);
  fbox(A,sx,5.7,sz+7.5,3.6,3.8,3.6,SC); fbox(A,sx-2.1,5.7,sz+7.5,.9,5,3.2,SB); fbox(A,sx+2.1,5.7,sz+7.5,.9,5,3.2,SB); fbox(A,sx,9.5,sz+7.4,4.8,.8,4.2,SG); fbox(A,sx,5.3,sz+7.4,3.2,.5,3.0,SB);
  fbox(A,sx-.8,7.4,sz+9.35,.7,.4,.2,"#222"); fbox(A,sx+.8,7.4,sz+9.35,.7,.4,.2,"#222"); fbox(A,sx,6.7,sz+9.45,.7,1.3,.4,SD); fbox(A,sx,5.9,sz+9.3,1.3,.35,.2,"#9a7440"); fbox(A,sx,4.9,sz+9.7,.5,1.2,.4,SB);
  for(let k=0;k<4;k++) fbox(A,sx,1.4+k*.9,sz-3,5.7,.35,10.4,k&1?SB:SC);
  solid(sx,sz+1,3.9,10.2,11); mark(44,-32,16); }

/* ---------- PİLON KAPISI + sfenks caddesi ---------- */
{ const pv=AZ+94, A=CG.F(AX,pv);
  fbox(A,AX,0,pv+6,10,.14,66,SAND3);                                           // cadde (kapıdan denize)
  fbox(A,AX,0,AZ+78,10,.14,16,SAND3);                                          // kapıdan tapınağa
  for(const s of [-1,1]){ const tx=AX+s*17, AA=CG.F(tx,pv);
    fbox(AA,tx,0,pv,12.6,.6,7.4,SAND3); fbox(AA,tx,.6,pv,11.4,14,6.2,SAND2); fbox(AA,tx,14.6,pv,10.2,5.6,5.4,SAND); fbox(AA,tx,20.2,pv,10.8,.9,5.8,GOLD);
    for(const sz of [-1,1]) fbox(AA,tx+sz*4.6,.6,pv+3.15,.5,15,.12,STONE);
    hiero(9.4,8.4,31+s*7,tx,8.1,pv+3.14,0); hiero(9.4,8.4,52+s*5,tx,8.1,pv-3.14,Math.PI);
    solid(tx,pv,6.3,3.7,21);
    // bayrak direkleri
    for(const fx of [-4.4,4.4]){ fbox(AA,tx+fx,20.5,pv+3.3,.3,9,.3,"#5e4126"); fbox(AA,tx+fx+.9,26.6,pv+3.3,1.7,2.4,.08,s>0?BLUE:"#c0392b"); } }
  fbox(A,AX,12.6,pv,22.8,2.6,6.2,SAND2); fbox(A,AX,15.2,pv,24,.9,6.6,GOLD); solid(AX,pv,10.8,3.1,15.8,12.6);
  CG.sign("RA",5,1.5,BLUE,"#ffd23f",AX,13.9,pv+3.2,0);
  mark(0,94,32);
  // ram başlı sfenks sıraları + meşaleler
  const ram=(x,z,face)=>{ const AA=CG.F(x,z), f=face, sx=(a,b)=>f>0?[a,b]:[-a,b]; // f: yüzün baktığı yön (+x / -x) -> uzunluk x ekseninde
    const P=(dx,dz)=>[x+dx*f,z+dz]; const bx=(dx,y,dz,w,h,d,c)=>{ const p=P(dx,dz); fbox(AA,p[0],y,p[1],d,h,w,c); };
    bx(0,0,0,2.2,.5,4.8,SAND3); bx(0,.5,0,1.9,1.3,4.0,"#d6b868"); bx(1.6,.5,.55,.55,.45,.7,SAND); bx(1.6,.5,-.55,.55,.45,.7,SAND);
    bx(2.0,1.4,0,1.3,1.4,1.4,"#d6b868"); bx(2.55,1.45,0,.6,.9,.8,"#c49a4e"); bx(2.0,2.8,0,1.5,.22,1.5,GOLD); bx(1.65,2.1,.78,.3,.5,.22,"#8a6a30"); bx(1.65,2.1,-.78,.3,.5,.22,"#8a6a30"); bx(2.74,1.9,.2,.1,.18,.18,"#222"); bx(2.74,1.9,-.2,.1,.18,.18,"#222"); };
  for(let i=0;i<6;i++){ const z=AZ+106+i*8.5; ram(AX-8.2,z,1); ram(AX+8.2,z,-1);
    for(const s of [-1,1]){ const bx=AX+s*12.4; if(i%2===0){ const AA=CG.F(bx,z); fbox(AA,bx,0,z,1.2,1.0,1.2,SAND3); fbox(AA,bx,1.0,z,.9,.35,.9,"#3a2a18"); fbox(AA,bx,1.35,z,.7,.45,.7,"#ff7a1a"); E.braziers.push({x:bx,y:1.9,z}); } } }
  for(const s of [-1,1]) for(let i=0;i<3;i++){ const x=AX+s*7, z=AZ+76+i*6, AA=CG.F(x,z); fbox(AA,x,0,z,1.2,1.0,1.2,SAND3); fbox(AA,x,1.0,z,.9,.35,.9,"#3a2a18"); fbox(AA,x,1.35,z,.7,.45,.7,"#ff7a1a"); E.braziers.push({x,y:1.9,z}); }
  // alçak duvarlar (caddenin iki yanı) hiyeroglifli
  for(const s of [-1,1]) for(let i=0;i<2;i++){ const z=AZ+112+i*20, x=AX+s*15, AA=CG.F(x,z); fbox(AA,x,0,z,1.2,2.2,16,SAND2); fbox(AA,x,2.2,z,1.6,.3,16.4,SAND3); hiero(15.6,1.5,90+i*3+s,x-s*.62,1.2,z,s>0?-Math.PI/2:Math.PI/2); hiero(15.6,1.5,95+i*3+s,x+s*.62,1.2,z,s>0?Math.PI/2:-Math.PI/2); }
  E.walk.paths.push([[AX,AZ+112],[AX,AZ+104],[AX,AZ+96],[AX,AZ+88],[AX,AZ+80],[AX,AZ+74]]); }

/* ---------- FİRAVUN HEYKELLERİ (oturan dev heykel; çatlar, gözler kızarır ve patlar) ---------- */
function pharaohRig(){ const r=CG.rig(), SS="#d9bf88", SD="#c4a46a", FC="#d3a870";
  r.box(0,.8,0,15,1.6,17,SD); r.box(0,3.6,-.6,11,4,11,SS); r.box(0,11,-5.0,10,10.8,2.6,SS); r.box(0,16.6,-5.0,6,.8,2.8,GOLD);
  for(const s of [-1,1]){ r.box(s*2.4,6.9,2.0,3.4,2.4,8.4,SS); r.box(s*2.4,4.1,6.2,2.8,5,2.8,SD); r.box(s*2.4,2.0,7.7,3,.8,4.6,SD); r.box(s*2.4,6.9,6.1,2.8,.5,.6,GOLD);
    r.box(s*4.9,12.8,-.2,1.9,7.8,2.4,SS); r.bar(s*4.9,9.2,.4,s*3.2,8.5,5.4,1.7,SS,1.7); r.box(s*3.0,8.5,5.9,1.8,.8,2.0,SD); }
  r.box(0,12.4,-.4,8,10.6,4.4,SS); r.box(0,16.6,1.82,6,1.6,.5,GOLD); r.box(0,16.6,2.07,5,1.0,.3,BLUE); r.box(0,7.0,3.2,5.6,1.0,6.4,SS); r.box(0,8.0,-.4,8.4,.8,4.8,GOLD);
  for(let k=0;k<5;k++) r.box(0,7.0,1.2+k*1.3,5.7,1.05,.35,GOLD);
  r.box(0,18.2,-.2,2.8,1.2,2.8,SD); r.box(0,20.6,.3,3.8,4.0,3.6,FC);
  r.box(0,22.9,-.3,5.2,2.2,5.6,BLUE); for(const s of [-1,1]) r.box(s*2.55,19.4,.6,1.0,4.6,3.0,BLUE); for(let k=0;k<4;k++) r.box(0,24.02,-2+k*1.3,5.2,.12,.5,GOLD);
  r.box(0,22.3,2.05,4.0,.5,.3,GOLD); r.box(0,23.0,2.35,.5,1.2,.4,GOLD); r.ball(0,23.7,2.35,.3,.35,.3,GOLD,6); r.box(0,17.9,1.95,.7,2.4,.7,BLUE);
  r.box(0,20.5,2.3,.7,1.3,.9,"#c89a60"); r.box(0,19.4,2.12,1.5,.22,.25,"#2a2018"); for(const s of [-1,1]){ r.box(s*1.0,21.65,2.12,1.3,.22,.25,GOLD); r.box(s*1.0,21.1,2.1,1.2,.65,.25,"#2a2018"); }
  return r; }
const crackRig=(pts,z,rg)=>{ for(let i=0;i<pts.length-1;i++) rg.bar(pts[i][0],pts[i][1],pts[i][2]===undefined?z:pts[i][2],pts[i+1][0],pts[i+1][1],pts[i+1][2]===undefined?z:pts[i+1][2],.17,"#14100c",.14); };
function mkStatue(x,z,yaw){ const gy=maxH(x,z,8,9), g=new THREE.Group(); g.position.set(x,gy,z); g.rotation.y=yaw||0; scene.add(g);
  { const A=CG.F(x,z); fbox(A,x,gy-3,z,15,3.2,17,"#c4a46a"); }          // zemine gömülü kaide (kum tepeciklerine karşı)
  const main=pharaohRig().mesh(CG.std({vertexColors:true,roughness:.85,metalness:.05})); g.add(main);
  const st={x,z,gy,yaw:yaw||0,s:1,g,main,state:0,t:0,eyes:[],sockets:[],cracks:[],hw:8,hd:9.2,h:25,eyeLocal:[[-1,21.1,2.25],[1,21.1,2.25]]};
  const eyeGeo=new THREE.BoxGeometry(.85,.42,.34);
  for(const e of st.eyeLocal){ const m=new THREE.Mesh(eyeGeo,new THREE.MeshBasicMaterial({color:0xf0e6c8})); m.position.set(e[0],e[1],e[2]); g.add(m); st.eyes.push(m); }
  const sockGeo=new THREE.BoxGeometry(1.15,.72,.5), sockMat=new THREE.MeshBasicMaterial({color:0x0c0806});
  for(const e of st.eyeLocal){ const m=new THREE.Mesh(sockGeo,sockMat); m.position.set(e[0],e[1],e[2]-.05); m.visible=false; g.add(m); st.sockets.push(m); }
  const stages=[ (rg)=>{ crackRig([[.4,22.95],[-.1,22.2],[.5,21.7],[-.5,21.1],[.2,20.2],[-.3,19.4]],2.18,rg); crackRig([[-1.0,21.1],[-1.9,20.4],[-2.2,19.6]],2.18,rg); crackRig([[-2,17.5],[-1,16.2],[-1.6,15],[-.4,13.6],[-1.1,12.2],[0,10.8],[-.7,9.4]],1.86,rg); crackRig([[-1,16.2],[1.2,15.4],[2.4,14.2]],1.86,rg); },
    (rg)=>{ crackRig([[4.9,16.6],[4.95,14.6],[4.8,12.2],[4.95,9.4]],1.05,rg); crackRig([[-4.9,16.4],[-4.8,13.6],[-4.95,10.6]],1.05,rg); crackRig([[1.6,16.8],[2.4,15],[1.7,13.2],[2.6,11.4],[2.0,9.6]],1.86,rg); crackRig([[3.4,15.0],[4.6,14.0]],1.86,rg); },
    (rg)=>{ crackRig([[2.4,8.16,-1.4],[2.0,8.16,1.4],[2.8,8.16,3.6],[2.2,8.16,6.0]],0,rg); crackRig([[-2.4,8.16,-1.2],[-2.9,8.16,1.6],[-2.1,8.16,4.0]],0,rg); crackRig([[-2.55,22.9,2.9],[-2.62,20.6,2.1],[-2.6,18.0,1.9]],0,rg);
      for(let k=0;k<3;k++) crackRig([[-2.6+k*2.6,24.04,-2.6],[-2.4+k*2.6,24.04,-.6],[-2.8+k*2.6,24.04,1.6]],0,rg); } ];
  stages.forEach((fn,i)=>{ const rg=CG.rig(); fn(rg); const m=rg.mesh(new THREE.MeshBasicMaterial({color:0x14100c,transparent:true,opacity:0,depthWrite:false}),{noShadow:true}); m.visible=false; g.add(m); st.cracks.push(m); });
  solid(x,z,st.hw,st.hd,st.h);
  E.statues.push(st); return st; }
mkStatue(AX-36,AZ+90,0); mkStatue(AX+36,AZ+90,0); mark(-36,90,14); mark(36,90,14);

/* ---------- köy (kuyu çevresinde 9 kerpiç ev) + pazar tezgâhları ---------- */
{ const vx=AX-58, vz=AZ+72; mark(-58,72,32);
  const AA=CG.F(vx,vz); CG.disc(AA,vx,.1,vz,22,28,"#d4bd84"); CG.disc(AA,vx,.12,vz,5.4,18,"#b89c64");
  CG.cyl(AA,vx,0,vz,1.5,1.4,1.1,10,"#a89868",true); CG.cyl(AA,vx,.9,vz,1.2,1.2,.3,10,"#2fb5d6",true); fbox(AA,vx-1.35,0,vz,.2,3,.2,DARKW); fbox(AA,vx+1.35,0,vz,.2,3,.2,DARKW); fbox(AA,vx,3,vz,3,.2,.3,DARKW); fbox(AA,vx,2.0,vz,.35,.4,.35,"#8a6a30");
  const hs=[]; for(let i=0;i<9;i++){ const a=i/9*TAU+.2, rr=19+((i*7)%3), x=vx+Math.cos(a)*rr, z=vz+Math.sin(a)*rr; if(!dry(x,z)) continue; if(E.statues.some(q=>Math.hypot(q.x-x,q.z-z)<21)) continue; hs.push([x,z,a]); }
  hs.forEach(([x,z,a],i)=>{ const dx=vx-x, dz=vz-z, door=Math.abs(dx)>Math.abs(dz)?(dx>0?1:3):(dz>0?0:2), w=6+(i%3), d=6+((i+1)%2)*1.2, y0=maxH(x,z,w/2,d/2), bl=CG.bl(), tint=pick(["#e8d0a0","#e2c690","#dcc08a","#eed9b0","#d9c098"]);
    CG.tier(bl,{x,z,w,d,y0,h:4,LH:4,T:.5,style:"n",tint,kind:"house",door,doorW:2.2,ic:"#f3e6c8",fc:"#caa27a",cc:"#fffaf0",roof:i%3===0?"hip":"flat",roofCol:"#c0903c",rh:2,slabCol:SAND2,parCol:SAND3});
    if(i%2===0) CG.tier(bl,{x,z,w:w-1.4,d:d-1.4,y0:y0+4,h:3.6,LH:3.6,T:.4,style:"n",tint,kind:"house",ic:"#f3e6c8",fc:"#caa27a",cc:"#fffaf0",roof:"flat",slabCol:SAND2,parCol:SAND3});
    const px=x+Math.cos(a)*(w/2+1.4), pz=z+Math.sin(a)*(d/2+1.4); CG.cyl(CG.F(px,pz),px,0,pz,.5,.35,.9,8,"#b8683a",true); });
  // tezgâhlar
  for(let i=0;i<6;i++){ const a=i/6*TAU+.5, x=vx+Math.cos(a)*9.5, z=vz+Math.sin(a)*9.5, A2=CG.F(x,z), c1=pick(["#c0392b","#2a5db0","#2e9d5a","#d9a441","#8e44ad"]), c2="#f4efe2", yaw=a+Math.PI/2;
    for(const [ox,oz] of [[-1.5,-1.1],[1.5,-1.1],[-1.5,1.1],[1.5,1.1]]){ const px=x+ox*Math.cos(yaw)+oz*Math.sin(yaw), pz=z-ox*Math.sin(yaw)+oz*Math.cos(yaw); fbox(A2,px,0,pz,.14,oz<0?2.7:2.2,.14,DARKW); }
    for(let k=0;k<4;k++){ const f0=-1.5+k*.75, f1=f0+.75, cc=k&1?c2:c1; const P=(ox,y,oz)=>[x+ox*Math.cos(yaw)+oz*Math.sin(yaw),y,z-ox*Math.sin(yaw)+oz*Math.cos(yaw)]; CG.quad(A2,P(f0,2.7,-1.2),P(f1,2.7,-1.2),P(f1,2.2,1.3),P(f0,2.2,1.3),cc); CG.quad(A2,P(f0,2.7,-1.2),P(f0,2.2,1.3),P(f1,2.2,1.3),P(f1,2.7,-1.2),CG.shd(CG.co(cc),.7)); }
    rbox(A2,x,.7,z,2.8,.14,1.2,-yaw+Math.PI/2,0,"#8a6038"); rbox(A2,x,.1,z,2.6,.6,1.1,-yaw+Math.PI/2,0,"#6e4c2a");
    for(let k=0;k<4;k++){ const ox=-.9+k*.6, P=[x+ox*Math.cos(yaw),.85,z-ox*Math.sin(yaw)]; CG.ball(A2,P[0],P[1]+.12,P[2],.2,pick(["#e8553a","#f4c542","#7bbd3a","#c0392b"]),6); } }
  // hayvan yemi / küpler / çuvallar
  for(let i=0;i<8;i++){ const a=rnd()*TAU, rr=25+rnd()*8, x=vx+Math.cos(a)*rr, z=vz+Math.sin(a)*rr; if(!dry(x,z)) continue; const A2=CG.F(x,z); if(i&1){ CG.cyl(A2,x,0,z,.55,.4,1.1,8,"#b8683a",true); CG.cyl(A2,x+1,0,z+.4,.4,.3,.8,8,"#a85a2e",true); } else { fbox(A2,x,0,z,1.6,.9,1.0,"#d9c88a"); fbox(A2,x+.2,.9,z,1.1,.7,.9,"#cdb87a"); } }
  for(let i=0;i<7;i++){ const a=i/7*TAU+.6, rr=34, x=vx+Math.cos(a)*rr, z=vz+Math.sin(a)*rr; if(dry(x,z)) CG.palm(x,z,.9+rnd()*.5); }
  E.walk.rings.push({cx:vx,cz:vz,r:12,n:12}); E.walk.paths.push([[vx-12,vz+4],[vx-26,vz+18],[vx-34,vz+34],[vx-40,vz+48]]);
  E.village={x:vx,z:vz}; }

/* ---------- vaha + kanal + sazlık ---------- */
{ const ox=AX-44, oz=AZ+22, A=CG.F(ox,oz), T=CG.T(ox,oz); mark(-44,22,18);
  CG.disc(A,ox,.05,oz,15,26,"#7bbd5a"); CG.disc(T,ox,.1,oz,10,26,"#2fb5d6"); CG.disc(A,ox,.07,oz,12,26,"#d9c88a",10);
  for(let i=0;i<13;i++){ const a=i/13*TAU+.3, r=12.5+rnd()*4; CG.palm(ox+Math.cos(a)*r,oz+Math.sin(a)*r,.9+rnd()*.6); }
  for(let i=0;i<7;i++){ const a=i/7*TAU, r=13.5+rnd(); CG.rock(ox+Math.cos(a)*r,oz+Math.sin(a)*r,.5+rnd()*.7); }
  // kanal: oyuk (x −) yönüne, batı kıyısına doğru hafif kıvrımlı
  let px=ox-9, pz=oz+1; const W0=5.6;
  for(let i=0;i<9;i++){ const nx=px-9+0, nz=pz+Math.sin(i*.8)*2.2, dx=nx-px, dz=nz-pz, len=Math.hypot(dx,dz)+1.2, yaw=Math.atan2(dx,dz), mx=(px+nx)/2, mz=(pz+nz)/2;
    rbox(CG.T(mx,mz),mx,.04,mz,W0,.1,len,yaw,0,"#2fb5d6"); rbox(CG.F(mx,mz),mx,.0,mz,W0+2.4,.06,len,yaw,0,"#d9c88a");
    for(let k=0;k<3;k++) for(const s of [-1,1]){ const rx=mx+Math.cos(yaw)*s*(W0/2+.9)+rnd()*.6, rz=mz-Math.sin(yaw)*s*(W0/2+.9)+rnd()*.6, AA=CG.F(rx,rz); for(let q=0;q<4;q++){ const qx=rx+(rnd()-.5)*1.2, qz=rz+(rnd()-.5)*1.2; CG.cyl(AA,qx,0,qz,.05,.02,1.5+rnd()*.9,4,"#5f9a3c"); CG.cyl(AA,qx,1.4+rnd()*.5,qz,.09,.06,.35,5,"#6b4a2a"); } }
    px=nx; pz=nz; }
  E.walk.paths.push([[ox+8,oz+6],[ox+14,oz+22],[ox+22,oz+34]]); }

/* ---------- İSKELE + yelkenliler (güney kıyı, caddenin sonu) ---------- */
{ const SX=AX, SZ=AZ+150, LEN=44, yaw=0, A=CG.F(SX,SZ+22);
  for(let i=0;i<LEN;i++){ const cz=SZ+i+.5; rbox(CG.F(SX,cz),SX,.2,cz,7.2,.3,1.02,yaw,0,i&1?"#9a7048":"#8a6038"); }
  for(let i=0;i<=LEN;i+=4) for(const s of [-1,1]){ const px=SX+s*3.4, pz=SZ+i, AA=CG.F(px,pz); fbox(AA,px,-5,pz,.4,6.2,.4,"#5e4126"); if(i<LEN) CG.beam(AA,px,1.0,pz,px,1.0,pz+4,.12,"#d9d2c0",.12); fbox(AA,px,.35,pz,.2,.75,.2,"#d9d2c0"); }
  { const ez=SZ+LEN; CG.rbox(CG.F(SX,ez),SX,.2,ez+3,14,.3,8,0,0,"#8a6038"); for(const s of [-1,1]) CG.cyl(CG.F(SX+s*6,ez+6),SX+s*6,0,ez+6,.35,.35,2.2,8,"#5e4126",true); }
  const prev=W.bridge.deckAt; W.bridge.deckAt=function(x,z){ const a=prev?prev(x,z):null; const u=z-SZ, v=x-SX; const b=(u>=-.5&&u<=LEN+7&&Math.abs(v)<=(u>LEN-1?7:3.6))?.35:null; return a===null?b:(b===null?a:Math.max(a,b)); };
  const boat=(bx,bz,flip,col)=>{ const AA=CG.F(bx,bz), by=-.9, sg=flip?-1:1;
    CG.beam(AA,bx,by,bz-5,bx,by,bz+5.4,2.3,"#f4f1ea",1.2); CG.beam(AA,bx,by+.7,bz-5,bx,by+.7,bz+5.4,2.5,col,.25); CG.beam(AA,bx,by,bz+5.4,bx,by+.2,bz+7.2,1.1,"#f4f1ea",1.0);
    fbox(AA,bx,by+.65,bz,.3,10.5,.3,"#c9ced6"); CG.beam(AA,bx,by+2.2,bz,bx,by+2.2,bz-3.8,.14,"#8a6038");
    const f=[bx,by+3,bz], g=[bx+sg*0,by+10.5,bz], h=[bx,by+3,bz-3.8]; CG.tri(AA,f,g,h,CG.co("#f4f1ea")); CG.tri(AA,f,h,g,CG.co("#e8e1d2")); };
  boat(SX-6.2,SZ+LEN-8,false,"#2a63c9"); boat(SX+6.2,SZ+LEN-3,false,"#c0392b");
  for(let i=8;i<LEN;i+=14) for(const s of [-1,1]) CG.lamp(SX+s*3.2,SZ+i,-s,0);
  mark(0,170,22); Game.pierEg={x:SX,z:SZ,len:LEN}; }

/* ---------- yarım kalmış piramit şantiyesi (doğu) ---------- */
{ const cx=AX+64, cz=AZ+62; mark(64,62,28);
  pyramid(cx,cz,30,3,4,1.6,0,3,3,0);
  const A=CG.F(cx,cz);
  for(let i=0;i<22;i++){ const t=i/21; rbox(A,cx-16-t*18+0,.0+t*11.5+.2,cz+8-t*6,.6,.5,2.6,Math.PI/2,0,i&1?"#8a6038":"#9a7048"); }            // rampa
  rbox(A,cx-26,5.8,cz+5,38,.4,2.8,Math.atan2(-6,-18)*0+Math.PI/2,-.0,"#7a5a38");
  for(let i=0;i<6;i++){ const x=cx-20+i*4.6, z=cz+14, AA=CG.F(x,z); fbox(AA,x,0,z,.35,9-i*.8,.35,"#7a5a38"); if(i<5) CG.beam(AA,x,8-i*.8,z,x+4.6,7.2-i*.8,z,.22,"#8a6a40"); CG.beam(AA,x,3,z,x+(i<5?4.6:0),3,z-(i<5?0:3),.18,"#8a6a40"); }
  for(let i=0;i<10;i++){ const a=rnd()*TAU, rr=20+rnd()*10, x=cx+Math.cos(a)*rr, z=cz+Math.sin(a)*rr, AA=CG.F(x,z); if(!dry(x,z)) continue; const w=1.2+rnd()*1.2; fbox(AA,x,0,z,w,w*.8,w*1.1,pick([SAND2,SAND3,STONE])); if(rnd()<.5) fbox(AA,x+.2,w*.8,z,w*.8,w*.7,w*.9,SAND2); }
  for(let i=0;i<4;i++){ const a=i/4*TAU+.4, x=cx-6+Math.cos(a)*34*0.0-24+i*0, z=cz+26+i*0; }
  // çadırlar + kamp ateşi
  for(let i=0;i<4;i++){ const x=cx-30+i*5.5, z=cz+30-((i*3)%4), AA=CG.F(x,z), c1=pick(["#c9a56a","#e8d0a0","#b88a50","#d9b88a"]);
    CG.stripeCone(AA,x,0,z,2.8,.15,3.4,4,c1,CG.shd(CG.co(c1),.8)); fbox(AA,x,0,z+2.6,1.2,.04,.8,"#3a2a18"); }
  { const x=cx-17, z=cz+33, AA=CG.F(x,z); for(let k=0;k<8;k++){ const a=k/8*TAU; fbox(AA,x+Math.cos(a)*1.1,0,z+Math.sin(a)*1.1,.45,.35,.45,"#8b8d8f"); } fbox(AA,x,0,z,.9,.3,.9,"#3a2a18"); fbox(AA,x,.3,z,.5,.35,.5,"#ff7a1a"); E.braziers.push({x,y:.8,z}); }
  E.walk.paths.push([[cx-34,cz+30],[cx-26,cz+36],[cx-14,cz+40]]); }

/* ---------- harabeler (kuzeydoğu) ve mastabalar (kuzeybatı) ---------- */
{ const rx=AX+86, rz=AZ-56; mark(86,-56,22);
  for(let i=0;i<12;i++){ const a=i/12*TAU, rr=9+((i*5)%3)*2, x=rx+Math.cos(a)*rr, z=rz+Math.sin(a)*rr, AA=CG.F(x,z); if(!dry(x,z)) continue; const h=2+((i*7)%5)*1.7, down=i%4===1;
    if(down){ const yaw=a+1; CG.rbox(AA,x,.8,z,1.9,1.8,6+((i*3)%3),yaw,0,SAND); CG.cyl(AA,x+Math.sin(yaw)*5,0,z+Math.cos(yaw)*5,.9,.9,.7,10,"#e0cd9a",true); }
    else { CG.cyl(AA,x,0,z,1.0,.88,h,10,"#ecd9a8",true); fbox(AA,x,0,z,2.4,.5,2.4,SAND3); if(h>5.5) fbox(AA,x,h,z,2.4,.5,2.4,SAND3); } }
  { const AA=CG.F(rx,rz); fbox(AA,rx-3.4,0,rz,1.5,5.4,1.5,SAND); fbox(AA,rx+3.4,0,rz,1.5,5.4,1.5,SAND); fbox(AA,rx-2.2,5.4,rz,5.6,1.1,1.8,SAND2); fbox(AA,rx,3.2,rz+7,5,2.6,.9,SAND); }
  for(let i=0;i<10;i++){ const a=rnd()*TAU, rr=3+rnd()*16, x=rx+Math.cos(a)*rr, z=rz+Math.sin(a)*rr, AA=CG.F(x,z); if(!dry(x,z)) continue; const w=.9+rnd()*1.4; fbox(AA,x,0,z,w,w*.7,w,pick([SAND2,SAND3,STONE])); } }
{ mark(-62,-60,26);
  for(let i=0;i<7;i++){ const x=AX-82+(i%4)*17+((i*5)%3)*2, z=AZ-52-Math.floor(i/4)*17-((i*3)%2)*3, w=9+((i*7)%4)*2, d=7+((i*3)%3)*2, h=3+((i*5)%3), y0=maxH(x,z,w/2,d/2), AA=CG.F(x,z); if(!dry(x,z)) continue;
    fbox(AA,x,y0-2,z,w,h+2,d,SAND2); fbox(AA,x,y0+h,z,w-1.4,1.2,d-1.4,SAND); fbox(AA,x,y0+h+1.2,z,w-3.2,.8,d-3.2,SAND3); fbox(AA,x,y0,z+d/2+.04,2,2.3,.12,"#3a2a1c"); hiero(w-1.6,1.1,120+i,x,y0+h-.9,z+d/2+.08,0); } }

/* ---------- palmiye + kaya serpiştirme (yapılardan uzak) ---------- */
for(let i=0,n=0;i<900&&n<90;i++){ const a=rnd()*TAU, r=45+rnd()*95, x=AX+Math.cos(a)*r, z=AZ+Math.sin(a)*r; if(!dry(x,z)) continue; if(!free(x,z,5)) continue; if(i%3===0) CG.rock(x,z,.7+rnd()*2); else CG.palm(x,z,.8+rnd()*.55); n++; mark(x-AX,z-AZ,2.5); }
/* ---------- deve sürüsü (kırılabilir; egypt.js yönetir) ---------- */
const camelCand=[[-44,40],[-40,44],[-52,37],[-62,106],[-54,110],[22,50],[27,54],[-6,126],[34,112],[-34,114],[60,28],[70,-22]];
E.camelSpots=camelCand.map(c=>[AX+c[0],AZ+c[1]]).filter(c=>dry(c[0],c[1]));
function camelRig(){ const r=CG.rig(), C1="#caa05a", C2="#b58a45", D="#8f6a30", BL="#b3302a", GD="#e8c14a";
  for(const sx of [-.5,.5]) for(const [sz,bz] of [[1.05,.15],[-1.15,-.2]]){ r.bar(sx,2.3,sz,sx,1.1,sz+bz,.38,C2,.38); r.bar(sx,1.1,sz+bz,sx,.1,sz+bz*.5,.26,D,.26); r.box(sx,.08,sz+bz*.5+.05,.34,.16,.46,"#4a3520"); }
  r.ball(0,2.75,0,.84,.8,1.95,C1,10); r.ball(0,3.7,-.2,.46,.62,.62,C2,8); r.box(0,3.55,.45,1.4,.16,1.7,BL); r.box(0,3.48,.45,1.5,.06,1.8,GD); r.box(0,3.62,.45,1.18,.1,1.5,"#2a5db0");
  r.bar(0,3.1,1.5,0,4.55,2.15,.44,C1,.52); r.bar(0,4.55,2.15,0,4.9,2.6,.4,C1,.42); r.ball(0,5.0,2.9,.3,.34,.56,C1,8); r.box(0,4.82,3.3,.3,.27,.32,C2);
  r.box(-.2,5.35,2.68,.1,.24,.1,D); r.box(.2,5.35,2.68,.1,.24,.1,D); r.box(-.24,5.05,3.05,.1,.1,.1,"#201810"); r.box(.24,5.05,3.05,.1,.1,.1,"#201810"); r.bar(0,2.95,-1.8,0,1.5,-1.95,.13,D,.13);
  r.box(.9,3.0,-.5,.5,.8,.8,"#6b4a2a"); r.box(-.9,3.0,-.5,.5,.8,.8,"#6b4a2a"); return r; }
E.camelGeo=camelRig().geo();
E.camelMat=CG.std({vertexColors:true,roughness:.9,metalness:0});
{ const n=E.camelSpots.length, im=new THREE.InstancedMesh(E.camelGeo,E.camelMat,Math.max(1,n)), o=new THREE.Object3D(); im.frustumCulled=false; im.castShadow=true; im.receiveShadow=true;
  E.camelSpots.forEach((c,i)=>{ const yaw=rnd()*TAU, s=.95+rnd()*.17, gy=Math.max(0,gh(c[0],c[1])); const cm={i,x:c[0],z:c[1],gy,yaw,s,alive:true}; E.camels.push(cm);
    o.position.set(c[0],gy,c[1]); o.rotation.set(0,yaw,0); o.scale.setScalar(s); o.updateMatrix(); im.setMatrixAt(i,o.matrix); const k=.86+rnd()*.28; im.setColorAt(i,new THREE.Color(k,k*(.94+rnd()*.1),k*.9)); });
  im.instanceMatrix.needsUpdate=true; if(im.instanceColor) im.instanceColor.needsUpdate=true; if(!n) im.count=0; scene.add(im); E.camelMesh=im; }
/* NPC yürüyüş ağı: dış halka (R=118) */
E.walk.rings.unshift({cx:AX,cz:AZ,r:118,n:48});
})();
