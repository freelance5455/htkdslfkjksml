"use strict";
/* ===== AY: uzayda ulaşılabilir dev gök cismi. Kraterli prosedürel yüzey (üç-düzlemli bump), ay yer çekimi, bayrak, iniş aracı, kayalar ===== */
Game.Moon=(function(){
  const H=Game.H, hero=Game.heroObj, FX=Game.FX, SU=Game.skyU;
  const C={x:4300,y:11800,z:-8400}, R=2300, TOP=C.y+R, R2=R*R, HIP=1.26, LUNAR_G=.165;
  let seed=987654321; const rnd=()=>{ seed=(seed*1664525+1013904223)>>>0; return seed/4294967296; };
  /* ---- yükseklik dokusu: kraterler + çok oktavlı değer gürültüsü (sarmalı, döşenebilir) ---- */
  function heightTex(){ const S=1024, h=new Float32Array(S*S);
    for(const [g,a] of [[8,.5],[16,.28],[32,.14],[64,.08]]){ const lat=new Float32Array(g*g); for(let i=0;i<lat.length;i++) lat[i]=rnd();
      for(let y=0;y<S;y++){ const fy=y/S*g, y0=Math.floor(fy), ty=fy-y0, sy=ty*ty*(3-2*ty), ya=y0%g, yb=(y0+1)%g;
        for(let x=0;x<S;x++){ const fx=x/S*g, x0=Math.floor(fx), tx=fx-x0, sx=tx*tx*(3-2*tx), xa=x0%g, xb=(x0+1)%g;
          const v=(lat[ya*g+xa]*(1-sx)+lat[ya*g+xb]*sx)*(1-sy)+(lat[yb*g+xa]*(1-sx)+lat[yb*g+xb]*sx)*sy; h[y*S+x]+=v*a; } } }
    const crater=(cx,cy,r,A)=>{ const m=Math.ceil(r*1.9); for(let dy=-m;dy<=m;dy++) for(let dx=-m;dx<=m;dx++){ const d=Math.hypot(dx,dy)/r; if(d>1.9) continue;
        const Rm=A*.3; let v; if(d<1){ const d2=d*d; v=-A*(1-d2)*(1-d2)+Rm*d2*d2*d2+A*.08; } else v=Rm*Math.exp(-((d-1)/.22)*((d-1)/.22))+A*.08*Math.exp(-(d-1)*2.5);
        const x=((cx+dx)%S+S)%S, y=((cy+dy)%S+S)%S; h[y*S+x]+=v; } };
    for(let i=0;i<70;i++) crater(rnd()*S|0,rnd()*S|0,28+rnd()*70,.36+rnd()*.2);
    for(let i=0;i<260;i++) crater(rnd()*S|0,rnd()*S|0,9+rnd()*26,.2+rnd()*.14);
    for(let i=0;i<900;i++) crater(rnd()*S|0,rnd()*S|0,2.5+rnd()*7,.1+rnd()*.1);
    let lo=1e9,hi=-1e9; for(let i=0;i<h.length;i++){ if(h[i]<lo) lo=h[i]; if(h[i]>hi) hi=h[i]; }
    const c=Game.CG.cnv(S,S), q=c.getContext("2d"), im=q.createImageData(S,S), k=255/(hi-lo||1);
    for(let i=0;i<h.length;i++){ const v=Math.max(0,Math.min(255,(h[i]-lo)*k))|0; im.data[i*4]=v; im.data[i*4+1]=v; im.data[i*4+2]=v; im.data[i*4+3]=255; }
    q.putImageData(im,0,0); const t=new THREE.CanvasTexture(c); t.wrapS=t.wrapT=THREE.RepeatWrapping; return t; }
  const VS="varying vec3 vRel; varying vec3 vN; void main(){ vRel=position; vN=normalize(normal); vec4 w=modelMatrix*vec4(position,1.); gl_Position=projectionMatrix*viewMatrix*w; }";
  const FS=[
"uniform sampler2D tx; uniform vec3 L; uniform vec3 camRel; uniform float alpha;",
"varying vec3 vRel; varying vec3 vN;",
"float tri(vec3 p,vec3 n,float s){ vec3 w=pow(abs(n),vec3(3.)); w/=(w.x+w.y+w.z); return texture2D(tx,p.zy*s).r*w.x+texture2D(tx,p.xz*s).r*w.y+texture2D(tx,p.xy*s).r*w.z; }",
"void main(){",
"  vec3 n=normalize(vN); vec3 rel=vRel; float d=length(vRel-camRel);",
"  float f1=1.-smoothstep(4000.,12000.,d), f2=1.-smoothstep(500.,3200.,d), f3=1.-smoothstep(40.,380.,d);",
"  float h0=tri(rel,n,.00019), h1=tri(rel,n,.0017), h2=tri(rel,n,.0125), h3=tri(rel,n,.095);",
"  float Hh=h0*46.+h1*14.*f1+h2*3.2*f2+h3*.8*f3;",
"  vec3 sx=dFdx(vRel), sy=dFdy(vRel); vec3 R1=cross(sy,n), R2=cross(n,sx); float det=dot(sx,R1);",
"  vec3 g=sign(det)*(dFdx(Hh)*R1+dFdy(Hh)*R2); vec3 n2=normalize(abs(det)*n-g);",
"  float mare=smoothstep(.44,.6,tri(rel,n,.00006)*.7+h0*.3);",
"  vec3 alb=mix(vec3(.64,.62,.59),vec3(.38,.375,.38),mare*.8);",
"  alb*=.72+.55*h1+.0*h2; alb*=.88+.24*h3*f3+.24*h2*f2*.6; alb=mix(alb,alb*vec3(1.04,1.0,.94),.5);",
"  float lam=max(0.,(dot(n2,L)+.06)/1.06); float lam0=max(0.,dot(n,L));",
"  vec3 col=alb*(vec3(1.18,1.12,1.02)*lam+vec3(.055,.065,.09)+vec3(.02)*(1.-lam0));",
"  float rim=pow(1.-max(dot(n,normalize(camRel-vRel)),0.),3.); col+=vec3(.05,.06,.08)*rim*lam0;",
"  gl_FragColor=vec4(col,alpha);",
"  #include <tonemapping_fragment>",
"  #include <encodings_fragment>",
"}"].join("\n");
  const U={tx:{value:null},L:{value:new THREE.Vector3(.5,.7,.4).normalize()},camRel:{value:new THREE.Vector3()},alpha:{value:0}};
  const tex=heightTex(); U.tx.value=tex;
  const mat=new THREE.ShaderMaterial({uniforms:U,vertexShader:VS,fragmentShader:FS,transparent:true,depthWrite:true,fog:false,extensions:{derivatives:true}});
  const mesh=new THREE.Mesh(new THREE.SphereGeometry(R,176,108),mat); mesh.position.set(C.x,C.y,C.z); mesh.frustumCulled=false; mesh.visible=false; mesh.renderOrder=-1; scene.add(mesh);
  /* ---- yüzey nesneleri: kaya sürüsü, bayrak, iniş aracı. Kutupta (TOP) ve çevresinde, küre normaline hizalı ---- */
  const UPV=new THREE.Vector3(0,1,0), nv=new THREE.Vector3(), qv=new THREE.Quaternion(), dum=new THREE.Object3D();
  const surf=(ox,oz)=>{ const d2=ox*ox+oz*oz, y=C.y+Math.sqrt(Math.max(0,R2-d2)); return {x:C.x+ox,y,z:C.z+oz,nx:ox/R,ny:Math.sqrt(Math.max(0,1-d2/R2)),nz:oz/R}; };
  const props=new THREE.Group(); scene.add(props); props.visible=false;
  { const ig=new THREE.IcosahedronGeometry(1,1); if(ig.attributes&&ig.attributes.position){ const pa=ig.attributes.position; for(let i=0;i<pa.count;i++){ const x=pa.getX(i),y=pa.getY(i),z=pa.getZ(i), k=1+Math.sin(x*4.7+y*3.3)*Math.cos(z*5.1+x*2.3)*.3; pa.setXYZ(i,x*k,y*k*.7,z*k); } if(ig.computeVertexNormals) ig.computeVertexNormals(); }
    const N=420, rocks=new THREE.InstancedMesh(ig,new THREE.MeshStandardMaterial({color:0x8a857f,roughness:1,metalness:0,flatShading:true}),N); rocks.frustumCulled=false; const col=new THREE.Color();
    for(let i=0;i<N;i++){ const rr=Math.sqrt(rnd())*620, a=rnd()*6.2832, s=surf(Math.cos(a)*rr,Math.sin(a)*rr), sc=i<14?5+rnd()*8:i<90?1.4+rnd()*3:.35+rnd()*1.2;
      nv.set(s.nx,s.ny,s.nz); qv.setFromUnitVectors(UPV,nv); dum.position.set(s.x,s.y-sc*.18,s.z); dum.quaternion.copy(qv); dum.rotateY&&dum.rotateY(rnd()*6.28); dum.scale.set(sc*(.8+rnd()*.5),sc*(.6+rnd()*.5),sc*(.8+rnd()*.5)); dum.updateMatrix(); rocks.setMatrixAt(i,dum.matrix);
      const g=.5+rnd()*.3; col.setRGB(g,g*.97,g*.93); rocks.setColorAt(i,col); }
    props.add(rocks);
    /* bayrak: direk + seçili dilin ülke bayrağı (dil değişince güncellenir; Ay'da yalnızca bu bayrak var) */
    const fs=surf(14,-9), fg=new THREE.Group(); fg.position.set(fs.x,fs.y,fs.z); nv.set(fs.nx,fs.ny,fs.nz); fg.quaternion.copy(qv.setFromUnitVectors(UPV,nv));
    const cv=Game.CG.cnv(360,240), q=cv.getContext("2d"); q.fillStyle="#9aa0a8"; q.fillRect(0,0,360,240);
    const ft=new THREE.CanvasTexture(cv), fm=new THREE.Mesh(new THREE.PlaneGeometry(4.5,3),new THREE.MeshBasicMaterial({map:ft,side:THREE.DoubleSide})); fm.position.set(2.45,6.7,0); fg.add(fm);
    const imgs={}; let shown="";
    const paintFlag=function(code){ if(!code||code===shown) return; shown=code; const F=Game.Flags; if(!F||!F.moonSvg||typeof Image==="undefined") return;
      const draw=im=>{ if(shown!==code) return; try{ q.drawImage(im,0,0,360,240); ft.needsUpdate=true; }catch(e){} };
      if(imgs[code]){ if(imgs[code].complete&&imgs[code].naturalWidth) draw(imgs[code]); return; }
      const im=new Image(); imgs[code]=im; im.onload=()=>draw(im); im.onerror=()=>{ shown=""; delete imgs[code]; }; im.src="data:image/svg+xml;charset=utf-8,"+encodeURIComponent(F.moonSvg(code)); };
    props.userData.paintFlag=paintFlag;   /* bayrak ilk kez Ay görününce boyanır (yüklemede Image/SVG işi yok) */
    const pole=new THREE.Mesh(new THREE.CylinderGeometry(.07,.07,9.2,8),new THREE.MeshStandardMaterial({color:0xcfd4da,metalness:.8,roughness:.3})); pole.position.y=4.6; fg.add(pole); const ball=new THREE.Mesh(new THREE.SphereGeometry(.17,8,6),new THREE.MeshStandardMaterial({color:0xffcc33,metalness:.9,roughness:.25})); ball.position.y=9.3; fg.add(ball);
    props.add(fg); props.userData.flag=fm;
    /* iniş aracı: altın folyo gövde, dört bacak, anten */
    const ls=surf(-46,-30), lg=new THREE.Group(); lg.position.set(ls.x,ls.y,ls.z); nv.set(ls.nx,ls.ny,ls.nz); lg.quaternion.copy(qv.setFromUnitVectors(UPV,nv)); lg.rotation.y=.7;
    const gold=new THREE.MeshStandardMaterial({color:0xd8a93a,metalness:.85,roughness:.35}), steel=new THREE.MeshStandardMaterial({color:0xb9bfc8,metalness:.8,roughness:.4}), dk=new THREE.MeshStandardMaterial({color:0x2a2d33,roughness:.6});
    const part=(g,m,x,y,z,rx,ry,rz)=>{ const o=new THREE.Mesh(g,m); o.position.set(x,y,z); if(rx||ry||rz) o.rotation.set(rx||0,ry||0,rz||0); lg.add(o); return o; };
    part(new THREE.CylinderGeometry(2.6,3.1,2.6,8),gold,0,4.4,0); part(new THREE.CylinderGeometry(2.2,2.2,2.4,8),steel,0,6.6,0); part(new THREE.SphereGeometry(1.5,10,8),dk,0,8.4,0.4);
    part(new THREE.BoxGeometry(1.1,1.5,.3),dk,0,6.5,2.25); part(new THREE.CylinderGeometry(.02,.02,3,5),steel,.9,9.2,-.6); part(new THREE.CylinderGeometry(1.0,.2,.35,10),steel,-1.4,9.4,-.4,.5,0,.3);
    for(let i=0;i<4;i++){ const a=i*Math.PI/2+Math.PI/4, lx=Math.cos(a)*3.5, lz=Math.sin(a)*3.5; part(new THREE.CylinderGeometry(.12,.12,4.6,5),steel,lx*.78,2.5,lz*.78,Math.sin(a)*.5,0,-Math.cos(a)*.5); part(new THREE.CylinderGeometry(.9,1.1,.18,8),steel,lx*1.2,.1,lz*1.2); }
    props.add(lg); }
  /* ---- fizik kancaları (hero.js zemin hesabı) ---- */
  const api={ C,R,TOP, alt:99999, near:false, landed:false, over(x,z){ const dx=x-C.x, dz=z-C.z; return dx*dx+dz*dz<R2; },
    /* üst yarıküre yüzey yüksekliği; ayaklar (fy) yüzeyin üstünde ya da en fazla 3 m gömülüyse yüzeyi döner */
    floor(x,z,fy,vy){ const dx=x-C.x, dz=z-C.z, d2=dx*dx+dz*dz; if(d2>=R2||fy<C.y) return null; const y=C.y+Math.sqrt(R2-d2); if(fy>=y-3&&vy<=1.5) return y; return null; } };
  /* ---- güncelleme ---- */
  let toldNear=false, toldLand=false, gBlend=0, shakeT=0;
  Game.updaters.push((dt0,time,raw)=>{ const dt=raw||dt0||.016, play=Game.mode==="play"; const sp=play?H.sp:0;
    const vis=play&&sp>.02; if(mesh.visible!==vis){ mesh.visible=vis; props.visible=vis; } if(!vis){ api.alt=99999; api.near=false; gBlend=0; toldNear=false; toldLand=false; return; }
    const p=hero.position, dx=p.x-C.x, dy=p.y-C.y, dz=p.z-C.z, d=Math.sqrt(dx*dx+dy*dy+dz*dz), alt=d-R; api.alt=alt; api.near=alt<900;
    U.alpha.value=Math.max(0,Math.min(1,(sp-.02)/.35)); U.camRel.value.set(camera.position.x-C.x,camera.position.y-C.y,camera.position.z-C.z);
    const sd=SU.sunDir.value, ly=Math.max(sd.y,.32), ll=Math.hypot(sd.x,ly,sd.z)||1; U.L.value.set(sd.x/ll,ly/ll,sd.z/ll);
    /* küre çarpışması (yan/alt yüzeyler ve yüksek hız): içeri girdiyse dışarı it, içeri doğru hızı sil */
    if(d<R+HIP&&d>1){ const nx=dx/d, ny=dy/d, nz=dz/d, v=H.vel, vn=v.x*nx+v.y*ny+v.z*nz;
      p.x=C.x+nx*(R+HIP); p.y=C.y+ny*(R+HIP); p.z=C.z+nz*(R+HIP);
      if(vn<0){ v.x-=nx*vn; v.y-=ny*vn; v.z-=nz*vn; if(-vn>28){ Game.shakeAdd&&Game.shakeAdd(Math.min(.9,-vn/250)); FX.dust(p.x,p.y-HIP,p.z,10,Math.min(6,-vn*.08),[.7,.68,.64]); if(Game.audio) Game.audio.thud(p.x,p.y,p.z); } }
      if(ny>.45) H.grounded=true; }
    /* ay yer çekimi: yüzeye yaklaştıkça uzay (0.1) → ay (0.165) */
    const gt=Math.max(0,Math.min(1,1-alt/260)); gBlend+=(gt-gBlend)*(1-Math.exp(-4*dt)); if(gBlend>.01) H.gscale=H.gscale+(LUNAR_G-H.gscale)*gBlend;
    if(!toldNear&&alt<1400){ toldNear=true; Game.toast&&Game.toast("t_moon",3800); }
    if(H.grounded&&alt<8&&!toldLand){ toldLand=true; api.landed=true; Game.toast&&Game.toast("t_moonland",4200); }
    /* tozlu adımlar: ayakta yürürken toz bulutu */
    if(H.grounded&&alt<6&&H.hv>2){ shakeT-=dt; if(shakeT<=0){ shakeT=.16; FX.dust(p.x,p.y-HIP+.1,p.z,2,1.6,[.72,.7,.66]); } }
    const fl=props.userData.flag; if(fl) fl.rotation.y=Math.sin(time*.8)*.08; if(props.userData.paintFlag){ try{ props.userData.paintFlag(currentLang); }catch(e){} } });
  api.reset=()=>{ toldNear=false; toldLand=false; api.landed=false; gBlend=0; };
  return api;
})();
