"use strict";
/* ===== UFO: yalnızca uzayda, çok nadir. Uzaya her çıkışta küçük bir şansla (5 dk bekleme) belirir; kahramanın çevresinde döner, ara sıra plazma atar.
   Vurulursa/çarpılırsa patlar (400 coin). Uzaktan kaçar: kahraman atmosfere inerse veya 100 sn sonra uzaklaşır. ===== */
Game.UFO=(function(){
  const W=Game.W, CG=Game.CG, FX=Game.FX, D=Game.D, H=Game.H, hero=Game.heroObj, Ev=Game.Ev, au=()=>Game.audio, TAU=Math.PI*2;
  const clamp=(v,a,b)=>v<a?a:v>b?b:v, rr=(a,b)=>a+Math.random()*(b-a);
  const api={active:false,hp:0,max:12,chance:.1,cooldown:300,stats:{spawned:0,downed:0},bolts:[],pos:{x:0,y:0,z:0}};
  const root=new THREE.Group(); root.visible=false; scene.add(root);
  const mc=h=>CG.co(h), sh=(c,k)=>({r:Math.min(1,c.r*k),g:Math.min(1,c.g*k),b:Math.min(1,c.b*k)});
  const hullMat=CG.std({vertexColors:true,roughness:.28,metalness:.85,flatShading:true});
  const glowMat=new THREE.MeshBasicMaterial({vertexColors:true});
  const domeMat=new THREE.MeshStandardMaterial({color:0x8fe9ff,roughness:.1,metalness:.2,transparent:true,opacity:.5,emissive:new THREE.Color(0x1d6a7a),emissiveIntensity:.6});
  /* gövde: yassı disk + üst/alt kabuk + halka + ayaklar */
  { const R=CG.rig(); R.ball(0,0,0,13,2.6,13,mc("#b9c2cc"),16); R.ball(0,-1.4,0,8.5,2.2,8.5,mc("#8d98a4"),14); R.cyl(0,.2,0,13.2,13.2,.9,24,mc("#5f6a76"),null,true); R.cyl(0,-2.6,0,3.4,2.6,1.6,12,mc("#46505c"));
    for(let k=0;k<3;k++){ const a=k/3*TAU+.5, x=Math.cos(a)*6.4, z=Math.sin(a)*6.4; R.bar(x,-2.4,z,x*1.3,-5.2,z*1.3,.5,mc("#46505c"),.5); R.ball(x*1.3,-5.4,z*1.3,1.1,.45,1.1,mc("#2f3640"),6); }
    const m=R.mesh(hullMat,{noShadow:true}); m.frustumCulled=false; root.add(m); }
  const dome=new THREE.Mesh(new THREE.SphereGeometry(5.4,14,8,0,TAU,0,Math.PI/2),domeMat); dome.position.y=1.5; dome.scale.set(1,.85,1); root.add(dome);
  { const R=CG.rig(); R.ball(0,2.8,0,1.5,1.9,1.5,{r:.35,g:.9,b:.35},8); R.ball(-.5,3.3,1,.4,.55,.3,{r:0,g:0,b:0},5); R.ball(.5,3.3,1,.4,.55,.3,{r:0,g:0,b:0},5); const m=R.mesh(hullMat,{noShadow:true}); m.frustumCulled=false; root.add(m); }
  const ring=new THREE.Group(); root.add(ring);
  { const R=CG.rig(), cols=[{r:.2,g:1,b:1},{r:1,g:.25,b:.9},{r:1,g:.95,b:.3}]; for(let k=0;k<18;k++){ const a=k/18*TAU; R.box(Math.cos(a)*12.6,.2,Math.sin(a)*12.6,1.1,.9,1.1,cols[k%3],{ry:-a}); } const m=R.mesh(glowMat,{noShadow:true}); m.frustumCulled=false; ring.add(m); }
  const g={ang:rr(0,TAU),R:280,spin:0,t:0,life:0,shootT:3,vx:0,vy:0,vz:0,flee:false,lastSpawn:-999,wasSpace:false,time:0};
  const spawnPos=()=>{ const a=rr(0,TAU); return {x:hero.position.x+Math.cos(a)*900,y:hero.position.y+rr(-120,160),z:hero.position.z+Math.sin(a)*900}; };
  function spawn(force){ if(api.active) return false; const p=spawnPos(); api.pos=p; api.active=true; api.hp=api.max; root.visible=true; g.life=0; g.flee=false; g.shootT=rr(4,6); g.ang=Math.atan2(p.z-hero.position.z,p.x-hero.position.x); g.R=rr(240,330); g.vx=g.vy=g.vz=0; g.lastSpawn=g.time; api.stats.spawned++;
    Game.toast&&Game.toast("t_ufo",3800); Ev.emit("ufoSpawn"); return true; }
  api.spawn=spawn;
  function vanish(){ api.active=false; root.visible=false; api.bolts.length=0; }
  function boom(){ const p=api.pos; FX.fire(p.x,p.y,p.z,40,0,6,0,6); FX.E(true,p.x,p.y,p.z,0,0,0,.6,18,40,[.7,1,1],[.2,.6,1],.9,0,1); FX.shock&&FX.shock(p.x,p.y,p.z,24,40); FX.spark(p.x,p.y,p.z,60,60,[.6,1,1]);
    for(let i=0;i<40;i++) FX.E(true,p.x+rr(-8,8),p.y+rr(-3,3),p.z+rr(-8,8),rr(-30,30),rr(-30,30),rr(-30,30),rr(.8,1.8),rr(.6,1.2),.1,[.4,1,.9],[.6,.2,1],1,0,.98);
    if(au()&&au().boom) au().boom(hero.position.x,hero.position.y,hero.position.z,true); if(Game.shakeAdd) Game.shakeAdd(.45); }
  function down(){ if(!api.active) return; boom(); api.stats.downed++; Game.Eco&&Game.Eco.add(400,"ufo",api.pos.x,api.pos.z); Game.toast&&Game.toast("t_ufo_down",3600); Ev.emit("ufoDown"); vanish(); }
  function hurt(d){ if(!api.active) return false; api.hp-=d; FX.spark(api.pos.x,api.pos.y,api.pos.z,14,14,[.6,1,1]); if(au()&&au().metalHit) au().metalHit(api.pos.x,api.pos.y,api.pos.z); if(api.hp<=0){ down(); return true; } return false; }
  api.hurt=hurt;
  if(D&&D.damageSphere){ const o=D.damageSphere; D.damageSphere=function(x,y,z,r,amt,speed){ const n=o.apply(this,arguments); if(api.active){ const p=api.pos, dx=x-p.x, dy=y-p.y, dz=z-p.z, rr2=r+13; if(dx*dx+dy*dy+dz*dz<rr2*rr2) hurt(clamp(amt*(.6+(speed||10)*.012),.05,3)); } return n; }; }
  Game.updaters.push((dt0,time,raw)=>{ const dt=Math.min(dt0,.05); g.time+=raw?Math.min(raw,.05):dt; const play=Game.mode==="play", sp=(Game.Space&&Game.Space.t)||0, inSpace=play&&sp>.85;
    /* uzaya çıkış: nadir doğma */
    if(inSpace&&!g.wasSpace){ if(!api.active&&g.time-g.lastSpawn>api.cooldown&&Math.random()<api.chance) spawn(); } g.wasSpace=inSpace;
    if(!api.active) return;
    g.life+=dt; const hp=hero.position, p=api.pos;
    if(!play||sp<.5||g.life>100&&!g.flee){ if(!g.flee&&play){ g.flee=true; Game.toast&&Game.toast("t_ufo_gone",2600); } else if(!play){ vanish(); return; } }
    /* hareket: kahramanın çevresinde yörünge; kaçarken yukarı/uzağa */
    let tx,ty,tz, spd=95;
    if(g.flee){ const dx=p.x-hp.x, dz=p.z-hp.z, l=Math.hypot(dx,dz)||1; tx=p.x+dx/l*900; ty=p.y+260; tz=p.z+dz/l*900; spd=260; if(Math.hypot(p.x-hp.x,p.y-hp.y,p.z-hp.z)>2200){ vanish(); return; } }
    else { g.ang+=dt*(75/g.R); tx=hp.x+Math.cos(g.ang)*g.R; tz=hp.z+Math.sin(g.ang)*g.R; ty=hp.y+Math.sin(g.ang*1.7)*70+25;
      /* kahraman çok yaklaşırsa geri çekilir */
      const d0=Math.hypot(p.x-hp.x,p.y-hp.y,p.z-hp.z); if(d0<90){ const dx=p.x-hp.x, dy=p.y-hp.y, dz=p.z-hp.z, l=d0||1; tx=p.x+dx/l*200; ty=p.y+dy/l*200; tz=p.z+dz/l*200; spd=150; } }
    const dx=tx-p.x, dy=ty-p.y, dz=tz-p.z, dl=Math.hypot(dx,dy,dz)||1, want=Math.min(spd,dl*1.1), k=1-Math.exp(-dt*2.2);
    g.vx+=(dx/dl*want-g.vx)*k; g.vy+=(dy/dl*want-g.vy)*k; g.vz+=(dz/dl*want-g.vz)*k; p.x+=g.vx*dt; p.y+=g.vy*dt; p.z+=g.vz*dt;
    root.position.set(p.x,p.y,p.z); g.spin+=dt*.9; root.rotation.y=g.spin; ring.rotation.y=-g.spin*2.4; root.rotation.x=clamp(g.vz*.0014,-.22,.22); root.rotation.z=clamp(-g.vx*.0014,-.22,.22);
    /* alt ışıltı */
    if(Math.random()<.6) FX.E(true,p.x+rr(-2,2),p.y-3.2,p.z+rr(-2,2),0,-rr(2,6),0,.5,3,.5,[.4,1,.9],[.2,.5,1],.7,0,1);
    /* plazma atışı */
    g.shootT-=dt; if(!g.flee&&g.shootT<=0){ g.shootT=rr(3.4,5.2); const d=Math.hypot(hp.x-p.x,hp.y-p.y,hp.z-p.z); if(d<520&&Game.Hp&&!Game.Hp.dead){ const t0=d/150, ax=hp.x+(H.vel?H.vel.x:0)*t0*.8-p.x, ay=hp.y+(H.vel?H.vel.y:0)*t0*.8-p.y, az=hp.z+(H.vel?H.vel.z:0)*t0*.8-p.z, l=Math.hypot(ax,ay,az)||1;
      if(api.bolts.length<5) api.bolts.push({x:p.x,y:p.y-2,z:p.z,vx:ax/l*150,vy:ay/l*150,vz:az/l*150,life:4.5}); if(au()&&au().zap) au().zap(); } }
    for(let i=api.bolts.length-1;i>=0;i--){ const b=api.bolts[i]; b.life-=dt; b.x+=b.vx*dt; b.y+=b.vy*dt; b.z+=b.vz*dt; FX.E(true,b.x,b.y,b.z,0,0,0,.3,3.2,1,[.4,1,.5],[.1,.8,.4],.9,0,1);
      const hx=hp.x-b.x, hy=hp.y-b.y, hz=hp.z-b.z; if(hx*hx+hy*hy+hz*hz<12){ if(Game.Hp&&Game.Hp.hurt) Game.Hp.hurt(8,b.x,b.y,b.z,"ufo"); FX.spark(b.x,b.y,b.z,14,12,[.5,1,.6]); api.bolts.splice(i,1); continue; } if(b.life<=0) api.bolts.splice(i,1); }
    /* hızlı çarpma */
    if(play&&!g.flee&&H.vel){ const hv=H.vel.length(), d=Math.hypot(hp.x-p.x,hp.y-p.y,hp.z-p.z); if(hv>40&&d<15) hurt(hv>90?6:3); }
  });
  api.root=root; api.ready=true; api.g=g;
  return api; })();
