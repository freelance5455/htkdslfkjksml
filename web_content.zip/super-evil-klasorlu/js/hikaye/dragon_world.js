"use strict";
/* ===== EJDERHA DAĞI (dünya katmanı): yerleşim verisi, mağara/ini çarpışma kutuları, orman ve kayalar. Görseller + ejderha: dragon.js =====
   Arazi world_core.js'de ("mount" adası + düzleştirilmiş teraslar). Burada: 3 mağara salonu (AABB duvar/tavan), ejderha inini çevreleyen kaya duvar yayı,
   yamaçlara çam/meşe ormanı. Kendi tohumlu rastgele sayı üreteci kullanılır: şehir/ada üretimini (CG.rnd) hiç kaydırmaz. */
Game.DragonWorld=(function(){
  const W=Game.W, CG=Game.CG, B=Game.buildings, L=CG.lists, I=W.islands[3];
  let sd=48151; const rnd=()=>(sd=(sd*16807)%2147483647)/2147483647;
  const DW={island:I,halls:[],lair:null,walls:[],trees:0,rocks:0};
  /* mağara salonu: yerel eksen u (ağızdan dışarı), v (yan). Ağız ana eksene hizalanır → duvarlar eksen-hizalı kutular */
  const HALL={U0:-7,U1:16,UF:19,VW:6,VT:9,VM:3.5,IH:10,TOP:14.5,MH:7.5};
  function box(x0,z0,x1,z1,y0,y1,tag){ const e={x:(x0+x1)/2,z:(z0+z1)/2,hw:(x1-x0)/2,hd:(z1-z0)/2,h:y1,y0:y0,rock:tag||1}; B.push(e); return e; }
  for(const f of W.mountFlats){
    if(f.kind==="cave"){
      const ox=Math.cos(f.a), oz=Math.sin(f.a); let fx=0, fz=0; if(Math.abs(ox)>Math.abs(oz)) fx=ox>0?1:-1; else fz=oz>0?1:-1;
      const rx=-fz, rz=fx, h=f.h, hall={cx:f.x,cz:f.z,H:h,fx,fz,rx,rz,boxes:[],chest:null,id:DW.halls.length,r:f.r};
      const P=(u,v)=>[f.x+fx*u+rx*v, f.z+fz*u+rz*v];
      const R=(u0,u1,v0,v1,y0,y1)=>{ const a=P(u0,v0), b=P(u1,v1), e=box(Math.min(a[0],b[0]),Math.min(a[1],b[1]),Math.max(a[0],b[0]),Math.max(a[1],b[1]),y0,y1); hall.boxes.push(e); return e; };
      const wy0=h-10, wy1=h+13;
      R(HALL.U0,HALL.U1,-HALL.VT,-HALL.VW,wy0,wy1);              // sol duvar
      R(HALL.U0,HALL.U1,HALL.VW,HALL.VT,wy0,wy1);                // sağ duvar
      R(HALL.U0,HALL.U0+3,-HALL.VT,HALL.VT,wy0,wy1);             // arka duvar
      R(HALL.U0,HALL.U1,-HALL.VT,HALL.VT,h+HALL.IH,h+HALL.TOP);  // tavan
      R(HALL.U1,HALL.UF,-HALL.VT,-HALL.VM,wy0,wy1);              // ön sütun (sol)
      R(HALL.U1,HALL.UF,HALL.VM,HALL.VT,wy0,wy1);                // ön sütun (sağ)
      R(HALL.U1,HALL.UF,-HALL.VM,HALL.VM,h+HALL.MH,h+HALL.TOP);  // alın (kapı üstü)
      hall.P=P; hall.sx=HALL; DW.halls.push(hall);
    } else if(f.kind==="lair"){
      const ox=Math.cos(f.a), oz=Math.sin(f.a), lair={x:f.x,z:f.z,H:f.h,a:f.a,ox,oz,r:f.r,fx:ox,fz:oz,top:4.4,pileR:14};
      DW.lair=lair;
      /* kaya duvar yayı: ağzın (a) tersi tarafta ~220°; her top bir AABB */
      const RR=f.r-3, span=2*Math.PI-3.5, n=Math.floor(span*RR/6.2);
      for(let i=0;i<=n;i++){ const ang=f.a+1.75+span*i/n, x=f.x+Math.cos(ang)*RR, z=f.z+Math.sin(ang)*RR, s=4.8+rnd()*2.2, hh=16+rnd()*7;
        const e=box(x-3.9,z-3.9,x+3.9,z+3.9,f.h-9,f.h+hh*.8,2); DW.walls.push({x,z,s,hh,ang,e}); }
    }
  }
  /* orman: yamaçlarda, teraslardan uzakta, çok dik olmayan yerlerde. Alçakta meşe, yüksekte çam */
  const flats=W.mountFlats, tooNear=(x,z)=>{ for(const f of flats) if(Math.hypot(x-f.x,z-f.z)<f.r+(f.kind==="lair"?16:13)) return true; return false; };
  const slopeOK=(x,z,h,m)=>Math.abs(W.terrainH(x+3,z)-h)/3<m&&Math.abs(W.terrainH(x,z+3)-h)/3<m;
  for(let i=0,n=0;i<5200&&n<430;i++){ const a=rnd()*6.2832, r=Math.sqrt(rnd())*I.R*.98, x=I.x+Math.cos(a)*r, z=I.z+Math.sin(a)*r, h=W.terrainH(x,z);
    if(h<2.2||h>52||tooNear(x,z)||!slopeOK(x,z,h,.95)) continue;
    /* ormanlar öbek öbek: gürültüyle seyrelt */
    const g=W.noise(x*.7+11,z*.7-5); if(g<-.18&&rnd()<.85) continue;
    const type=h>16?(rnd()<.8?1:0):(rnd()<.55?0:(rnd()<.5?3:1));
    L.trees.push([x,z,(h>40?.75:.95)+rnd()*.75,type]); n++; DW.trees=n; }
  for(let i=0,n=0;i<1500&&n<70;i++){ const a=rnd()*6.2832, r=Math.sqrt(rnd())*I.R*.9, x=I.x+Math.cos(a)*r, z=I.z+Math.sin(a)*r, h=W.terrainH(x,z);
    if(h<10||tooNear(x,z)) continue; L.rocks.push([x,z,1.6+rnd()*3.2,rnd()*6.28]); n++; DW.rocks=n; }
  return DW; })();
