"use strict";
/* ===== ADALAR: Tropik Ada (deniz feneri, plaj kulübeleri, iskele, palmiyeler); Antik Ada egypt_world.js içinde ===== */
(function(){
const CG=Game.CG, W=Game.W, fbox=CG.fbox, pbox=CG.pbox, L=CG.lists, rnd=CG.rnd, pick=CG.pick, TAU=Math.PI*2, B=Game.buildings;
const gh=(x,z)=>W.terrainH(x,z), solid=(x,z,hw,hd,h,y0)=>B.push({x,z,hw,hd,h,y0:y0||0});
const TI=W.islands.find(i=>i.id==="tropic"), AI=W.islands.find(i=>i.id==="ancient");
function maxH(x,z,hw,hd){ let m=-99; for(let i=-1;i<=1;i+=.5) for(let j=-1;j<=1;j+=.5) m=Math.max(m,gh(x+i*hw,z+j*hd)); return m; }
const root=new THREE.Group(); scene.add(root);
const upd=[]; Game.islandUpdaters=upd;

/* =============================== TROPİK ADA =============================== */
const PHI=-Math.PI/4;                                  // iskele yönü (şehre doğru)
const UX=Math.cos(PHI), UZ=Math.sin(PHI), PX=-UZ, PZ=UX;     // u: iskele yönü, p: dik
{ // ---- deniz feneri (yıkılabilir, kademeli kule) ----
  const lx=TI.x+2, lz=TI.z-2, y0=maxH(lx,lz,6,6)+.15, A=CG.F(lx,lz), bl=CG.bl();
  fbox(A,lx,y0-10,lz,12.4,10.1,12.4,"#8b8d92"); fbox(A,lx,y0-.05,lz,11.4,.2,11.4,"#b9bcc2");
  for(let k=0;k<3;k++) fbox(A,lx,y0-.6+k*.2,lz+6.4+(2-k)*.9,5-k*.4,.2+0*k,1.1,"#aeb2b8");
  const cols=["#f6f1e7","#d6382e"], sizes=[9.2,8.6,8,7.4,6.8]; let y=y0;
  sizes.forEach((w,i)=>{ CG.tier(bl,{x:lx,z:lz,w,d:w,y0:y,h:6,LH:6,T:.7,style:"p",tint:cols[i%2],kind:"house",door:i===0?0:undefined,doorW:2.6,ic:"#efe8d8",fc:"#b69668",cc:"#f4efe4",roof:"none",
      doorDeco:i===0?(A2,p,tt,dg)=>CG.canopy(A2,p,dg,"#d6382e",3.5):undefined}); y+=6; });
  CG.tier(bl,{x:lx,z:lz,w:8.2,d:8.2,y0:y,h:1.2,LH:1.2,T:.5,style:"p",tint:"#2a2d33",kind:"house",ic:"#555a64",fc:"#3a3d44",roof:"flat",slabCol:"#3a3d44",parCol:"#d6382e"}); y+=1.2+.5;
  const lan=CG.tier(bl,{x:lx,z:lz,w:4.6,d:4.6,y0:y,h:3.6,LH:3.6,T:.35,style:"g",tint:"#fff1b8",kind:"house",ic:"#fff6d8",fc:"#caa27a",cc:"#fff2c8",roof:"hip",roofCol:"#d6382e",rh:3,
    props:(top,A2)=>{ pbox(A2,lx,top,lz,.16,3.2,.16,"#c9ced6"); pbox(A2,lx,top+3.2,lz,.7,.7,.7,"#ffd23f"); return top+4; }});
  CG.doorSign(bl.tiers[0],"LIGHTHOUSE",5,1,"#d6382e","#fff",4.4);
  // dönen fener ışığı (gece görünür)
  const beamMat=new THREE.MeshBasicMaterial({color:0xfff0b0,transparent:true,opacity:0,depthWrite:false,blending:THREE.AdditiveBlending,side:THREE.DoubleSide});
  const r=CG.rig(); r.cyl(0,0,24,.7,6,48,10,"#fff0b0",{rx:Math.PI/2},false); r.cyl(0,0,-24,.7,6,48,10,"#fff0b0",{rx:-Math.PI/2},false);
  const bm=r.mesh(beamMat,{noShadow:true}); bm.position.set(lx,y+1.8,lz); bm.visible=false; root.add(bm);
  upd.push((dt,t)=>{ const nt=Game.night||0; bm.visible=nt>.15; beamMat.opacity=nt*.28; bm.rotation.y=t*.7; });
  Game.lighthouse={x:lx,z:lz,y:y+1.8};
  for(const [sx,sz] of [[-1,-1],[1,-1],[-1,1],[1,1]]) CG.rock(lx+sx*8.2,lz+sz*7.6,1.2+rnd()*1.2);
}
{ // ---- plaj kulübeleri + şemsiyeler + voleybol ----
  const cx=TI.x, cz=TI.z, A0=CG.F(cx+60,cz-60);
  const hut=(a,r,txt,k)=>{ const x=cx+Math.cos(a)*r, z=cz+Math.sin(a)*r, dx=Math.cos(a), dz=Math.sin(a), door=Math.abs(dx)>Math.abs(dz)?(dx>0?1:3):(dz>0?0:2), A=CG.F(x,z);
    const rc=pick(["#b88a3a","#c9a24a","#a9792f"]), bl=CG.bl();
    const t=CG.tier(bl,{x,z,w:5.4,d:5.4,y0:0,h:4,LH:4,T:.45,style:"b",tint:pick(["#f0d9a8","#e9b88a","#cfe0b0","#f2c4b0","#bfe0e8"]),kind:"shop",door,doorW:2.2,ic:"#fff3e0",fc:"#caa27a",cc:"#fffaf0",roof:"hip",roofCol:rc,rh:2.8,
      doorDeco:(A2,p,tt,dg)=>CG.canopy(A2,p,dg,pick(["#e0407a","#2a9d8f","#ff8a3c","#4a7bc8"]),3.35)});
    if(txt) CG.doorSign(t,txt,3.8,.8,"#2a1f14","#ffd23f",3.62);
    const ox=x+dx*7.5, oz=z+dz*7.5, c1=pick(["#e63946","#2a9d8f","#ffd23f","#4a7bc8"]);
    CG.cyl(A,ox,0,oz,.07,.07,2.7,6,"#e8e8e8"); CG.stripeCone(A,ox,2.55,oz,2.1,.1,.75,10,c1,"#f8f8f8");
    fbox(A,ox+1.5,0,oz+1.5,.8,.2,1.9,"#f8f8f8"); fbox(A,ox-1.6,0,oz+1.2,.8,.2,1.9,c1);
    return t; };
  [[.55,"TIKI BAR"],[.95,"SURF"],[1.35,"ICE"],[-.55,"SNACKS"],[-.95,"DIVE"],[-1.4,"SHOP"]].forEach((e,i)=>hut(PHI+e[0]*(i%2?1:1),86+(i%2)*3,e[1]));
  // voleybol sahası
  { const a=PHI+2.35, x=cx+Math.cos(a)*86, z=cz+Math.sin(a)*86, A=CG.F(x,z); fbox(A,x,0,z,11,.05,18,"#f2e3b0");
    fbox(A,x-5.2,0,z,.22,2.6,.22,"#d9d9de"); fbox(A,x+5.2,0,z,.22,2.6,.22,"#d9d9de"); fbox(A,x,1.9,z,10.4,.9,.06,"#f4f4f4"); fbox(A,x,.06,z,11,.04,.12,"#ffffff"); }
}
{ // ---- iskele + tekne ----
  const SX=TI.x+UX*96, SZ=TI.z+UZ*96, LEN=50, A=CG.F(SX+UX*25,SZ+UZ*25), yaw=Math.atan2(UX,UZ);
  for(let i=0;i<LEN;i++){ const cx=SX+UX*(i+.5), cz=SZ+UZ*(i+.5); CG.rbox(CG.F(cx,cz),cx,.2,cz,3.7,.3,1.02,yaw,0,i&1?"#9a7048":"#8a6038"); }
  for(let i=0;i<=LEN;i+=4) for(const s of [-1,1]){ const px=SX+UX*i+PX*s*1.7, pz=SZ+UZ*i+PZ*s*1.7, AA=CG.F(px,pz); fbox(AA,px,-5,pz,.4,6.2,.4,"#5e4126"); if(i<LEN) CG.beam(AA,px,1.0,pz,px+UX*4,1.0,pz+UZ*4,.12,"#d9d2c0",.12); fbox(AA,px,.35,pz,.2,.75,.2,"#d9d2c0"); }
  for(let i=6;i<=LEN-4;i+=14) for(const s of [-1,1]) CG.lamp(SX+UX*i+PX*s*1.6,SZ+UZ*i+PZ*s*1.6,-PX*s,-PZ*s);
  // iskele sonu: platform + fener
  { const ex=SX+UX*LEN, ez=SZ+UZ*LEN, AA=CG.F(ex,ez); CG.rbox(AA,ex+UX*2,.2,ez+UZ*2,7,.3,6,yaw,0,"#8a6038"); CG.cyl(AA,ex+UX*4.6,0,ez+UZ*4.6,.35,.35,2.2,8,"#5e4126",true); }
  const prev=W.bridge.deckAt; W.bridge.deckAt=function(x,z){ const a=prev?prev(x,z):null; const dx=x-SX, dz=z-SZ, u=dx*UX+dz*UZ, v=dx*PX+dz*PZ; const b=(u>=-.5&&u<=LEN+5&&Math.abs(v)<=(u>LEN?3.6:1.85))?.35:null; return a===null?b:(b===null?a:Math.max(a,b)); };
  Game.pier={x:SX,z:SZ,ux:UX,uz:UZ,len:LEN};
  // demirli yelkenli
  { const bx=SX+UX*32+PX*-5.2, bz=SZ+UZ*32+PZ*-5.2, AA=CG.F(bx,bz), by=-.9;
    CG.beam(AA,bx-UX*5,by,bz-UZ*5,bx+UX*5.4,by,bz+UZ*5.4,2.5,"#f4f6fa",1.3); CG.beam(AA,bx-UX*5,by+.7,bz-UZ*5,bx+UX*5.4,by+.7,bz+UZ*5.4,2.7,"#2a63c9",.25);
    CG.beam(AA,bx+UX*5.4,by,bz+UZ*5.4,bx+UX*7.2,by+.2,bz+UZ*7.2,1.2,"#f4f6fa",1.1);
    fbox(AA,bx,by+.65,bz,.3,10.5,.3,"#c9ced6"); CG.beam(AA,bx,by+2.2,bz,bx-UX*3.8,by+2.2,bz-UZ*3.8,.14,"#8a6038");
    const f=[bx,by+3,bz], g=[bx,by+10.5,bz], h=[bx-UX*3.6,by+3,bz-UZ*3.6], c=CG.co("#f4f1ea"), c2=CG.co("#e8e1d2");
    CG.tri(AA,f,g,h,c); CG.tri(AA,f,h,g,c2); }
}
{ // ---- palmiye, ağaç, kaya ----
  const cx=TI.x, cz=TI.z; let n=0;
  for(let i=0;i<500&&n<120;i++){ const a=rnd()*TAU, r=18+rnd()*84, x=cx+Math.cos(a)*r, z=cz+Math.sin(a)*r; if(gh(x,z)<.05) continue;
    const da=Math.abs(((a-PHI+Math.PI*3)%TAU)-Math.PI); if(r>80&&da>2.7) continue;                                           // iskele yolu boş
    if(Math.hypot(x-(TI.x+2),z-(TI.z-2))<11) continue; let near=false; for(let k=0;k<L.palms.length;k++){ const p=L.palms[k]; if(Math.hypot(p[0]-x,p[1]-z)<3.2){ near=true; break; } } if(near) continue;
    CG.palm(x,z,.85+rnd()*.7); n++; }
  for(let i=0,m=0;i<400&&m<46;i++){ const a=rnd()*TAU, r=16+rnd()*58, x=cx+Math.cos(a)*r, z=cz+Math.sin(a)*r; if(gh(x,z)<1.2||Math.hypot(x-(TI.x+2),z-(TI.z-2))<12) continue; CG.tree(x,z,.9+rnd()*.7,rnd()<.4?1:0); m++; }
  for(let i=0,m=0;i<300&&m<26;i++){ const a=rnd()*TAU, r=22+rnd()*84, x=cx+Math.cos(a)*r, z=cz+Math.sin(a)*r; if(gh(x,z)<-.3||Math.hypot(x-(TI.x+2),z-(TI.z-2))<12) continue; CG.rock(x,z,.7+rnd()*(r<80?2.6:1.2)); m++; }
}

/* ANTİK ADA (Mısır): egypt_world.js içinde */
Game.updaters.push((dt,t)=>{ for(const f of upd) f(dt,t); });
})();
