"use strict";
/* ===== EJDERHA DAĞI (çalışma zamanı): mağara salonları + hazine sandıkları, ejderha ini (altın yığını, kaya duvar), uyuyan ejderha modeli ve davranışı.
   Ejderha: uyur (nefes alır, burnundan duman) → vurulur/yüksek hızla yaklaşılırsa uyanır → boynunu kaldırır, kanat açar, kükrer, ateş püskürtür / ateş topu atar →
   canı biterse yıkılır (800 coin), 10 dk sonra (oyuncu uzaktayken) yeniden uyur. Hasar: D.damageSphere (yumruk, güç, patlama, fırlatılan araba...). ===== */
Game.Dragon=(function(){
  const W=Game.W, CG=Game.CG, DW=Game.DragonWorld, FX=Game.FX, D=Game.D, H=Game.H, hero=Game.heroObj, Ev=Game.Ev, au=()=>Game.audio, I=DW.island;
  const clamp=(v,a,b)=>v<a?a:v>b?b:v, lerp=(a,b,t)=>a+(b-a)*t, sm01=x=>{ x=clamp(x,0,1); return x*x*(3-2*x); }, rr=(a,b)=>a+Math.random()*(b-a), TAU=Math.PI*2;
  const hash=(a,b,c)=>{ const q=Math.sin(a*127.1+b*311.7+c*74.7)*43758.5453; return q-Math.floor(q); };
  const api={st:"sleep",hp:36,max:36,fireballs:[],stats:{woke:0,slain:0,chests:0,gold:0},halls:DW.halls,lair:DW.lair,ready:false};
  if(!DW.lair) return api;
  const lair=DW.lair, root=new THREE.Group(); scene.add(root);
  const rockMat=CG.std({vertexColors:true,roughness:.96,metalness:0,flatShading:true});
  const goldMat=CG.std({vertexColors:true,roughness:.28,metalness:.88,emissive:new THREE.Color(0x6b4600),emissiveIntensity:.5,flatShading:true});
  const dragMat=CG.std({vertexColors:true,roughness:.55,metalness:.22,flatShading:true});
  const glowMat=new THREE.MeshBasicMaterial({vertexColors:true});
  const woodMat=CG.std({vertexColors:true,roughness:.8,metalness:.05,flatShading:true});
  const C=h=>CG.co(h), sh=(c,k)=>({r:Math.min(1,c.r*k),g:Math.min(1,c.g*k),b:Math.min(1,c.b*k)});
  const ROCKS=["#7b756c","#6b665e","#8a8479","#5e5a54","#857d70"].map(C), MOSS=C("#66784e"), GOLDS=["#f2c230","#e0a81c","#ffd95a","#c98d12","#f7d46a"].map(C);
  /* ---- düşük poligonlu pürüzlü küre (kaya / altın / pul) ---- */
  function lump(R,cx,cy,cz,rx,ry,rz,base,seed,seg,rows,jit){ seg=seg||8; rows=rows||5; jit=jit==null?.26:jit;
    const pt=(i,j)=>{ const a=i/seg*TAU, b=j/rows*Math.PI, k=1+(hash(i%seg,j,seed)-.5)*2*jit*((j===0||j===rows)?0:1); return [cx+Math.cos(a)*Math.sin(b)*rx*k, cy+Math.cos(b)*ry*k, cz+Math.sin(a)*Math.sin(b)*rz*k]; };
    for(let j=0;j<rows;j++) for(let i=0;i<seg;i++){ const p00=pt(i,j), p10=pt(i+1,j), p01=pt(i,j+1), p11=pt(i+1,j+1), up=1-j/rows, c=sh(base,.6+.5*up*(.75+.5*hash(i,j,seed+9)));
      if(j===0) R.tri(p00,p01,p11,c); else if(j===rows-1) R.tri(p00,p01,p10,c); else R.quad(p00,p01,p11,p10,c); } }
  const rockC=s=>ROCKS[Math.floor(hash(s,3,1)*ROCKS.length)];
  const fin=(R,mat,shadow,cull)=>{ const m=R.mesh(mat,{noShadow:!shadow}); m.frustumCulled=!!cull; return m; };

  /* =============================== MAĞARA SALONLARI =============================== */
  const chests=[];
  function buildChest(parent,x,y,z,yaw,hall){
    const g=new THREE.Group(); g.position.set(x,y,z); g.rotation.y=yaw; parent.add(g);
    const b=CG.rig(); b.box(0,.55,0,2.4,1.1,1.5,"#6b4423"); b.box(0,.1,0,2.5,.25,1.6,"#c99a2e"); b.box(0,1.02,0,2.5,.12,1.6,"#c99a2e"); for(const sx of[-1,1]) b.box(sx*.95,.55,0,.22,1.15,1.62,"#d8ad3a"); b.box(0,.75,.78,.4,.45,.14,"#f2c230");
    g.add(fin(b,woodMat,true,true));
    const lid=new THREE.Group(); lid.position.set(0,1.1,-.75); g.add(lid);
    const l=CG.rig(); l.box(0,.22,.75,2.4,.4,1.5,"#7a4e28"); l.box(0,.46,.75,2.2,.16,1.3,"#6b4423"); l.box(0,.4,.75,2.5,.1,1.55,"#c99a2e"); for(const sx of[-1,1]) l.box(sx*.95,.3,.75,.22,.6,1.56,"#d8ad3a");
    lid.add(fin(l,woodMat,true,true));
    const gl=CG.rig(); gl.box(0,.04,0,2.1,.06,1.2,{r:1,g:.85,b:.35}); const glow=gl.mesh(glowMat,{noShadow:true}); glow.position.set(0,1.08,0); glow.visible=false; g.add(glow);
    const c={x,z,y,g,lid,glow,open:0,opened:false,cool:0,hall,amt:150}; chests.push(c); return c; }
  function buildHall(hl){
    const R=CG.rig(), G=new THREE.Group(); root.add(G); const P=hl.P, H0=hl.H, fx=hl.fx, fz=hl.fz, rx=hl.rx, rz=hl.rz, id=hl.id*17+3;
    for(const e of hl.boxes) R.box(e.x,(e.y0+e.h)/2,e.z,e.hw*2,e.h-e.y0,e.hd*2,"#4b463f");
    const L=(u,v,y,a,b,c,seed,base)=>{ const p=P(u,v); lump(R,p[0],y,p[1],a,b,c,base||rockC(seed+id),seed+id,8,5,.3); };
    for(let u=-5,k=0;u<=14.5;u+=4.4,k++) for(const s of[-1,1]){ L(u,s*7.6,H0+4.6,3.7,7.4,3.6,k*2+(s>0?1:0)); if(k%2===0) L(u+1,s*8.8,H0+10.5,3.6,4.2,3.4,k+40,MOSS); }
    for(let u=-5,k=0;u<=15;u+=5,k++) for(let v=-6,j=0;v<=6.1;v+=6,j++) L(u,v,H0+12.6,4.6,3.7,4.6,k*5+j+80,j===1&&k%2?MOSS:null);
    L(3,0,H0+15.5,8,4.4,8,130,MOSS); L(-3,-2,H0+17,5.5,4.5,5.5,131); L(8,3,H0+16,5.5,3.8,5.5,132,MOSS);
    for(const s of[-1,1]){ L(17.7,s*6.4,H0+6.2,3.4,7.8,3.4,150+s); L(17.5,s*3.9,H0+7.4,1.5,1.8,1.5,160+s); L(17.6,s*2.2,H0+9.9,2.6,2.8,2.8,170+s); L(15,s*10,H0-3,4.8,6,4.8,180+s); L(-6,s*7,H0+2,4,7,4,190+s); }
    L(17.8,0,H0+11.3,3,3,3.6,200); L(-8,0,H0+6,5,9,8,210);
    const fs=(a,b)=>[Math.abs(fx)*a+Math.abs(rx)*b, Math.abs(fz)*a+Math.abs(rz)*b], fp=P(4.5,0), sz=fs(23,12); R.box(fp[0],H0+.1,fp[1],sz[0],.2,sz[1],"#5b5348");
    /* altın yığınları + mücevher */
    const GR=CG.rig(); for(let i=0;i<26;i++){ const side=i%2?1:-1, u=-4+hash(i,1,id)*8, v=side*(2.4+hash(i,2,id)*2.8), p=P(u,v); lump(GR,p[0],H0+.4+hash(i,3,id)*.6,p[1],.9+hash(i,4,id)*.9,.55+hash(i,5,id)*.5,.9+hash(i,6,id)*.9,GOLDS[i%5],i+id,6,3,.22); }
    const gp=P(-4.5,0); lump(GR,gp[0],H0+.8,gp[1],3.2,1.5,3.2,GOLDS[2],id+7,7,4,.2);
    const gems=[{r:.9,g:.1,b:.2},{r:.15,g:.35,b:.95},{r:.1,g:.8,b:.35},{r:.8,g:.2,b:.9}], GM=CG.rig();
    for(let i=0;i<8;i++){ const p=P(-5+hash(i,8,id)*7,(hash(i,9,id)-.5)*7), c=gems[i%4]; GM.box(p[0],H0+.5+hash(i,3,id)*.7,p[1],.4,.5,.4,c,{ry:i,rx:.5}); }
    G.add(fin(R,rockMat,true,true)); G.add(fin(GR,goldMat,false,true)); G.add(fin(GM,glowMat,false,true));
    /* kristaller (parlayan) */
    const K=CG.rig(), kc=[{r:.55,g:.3,b:1},{r:.25,g:.85,b:1},{r:.9,g:.35,b:1}];
    for(let i=0;i<9;i++){ const v=(i%2?1:-1)*(4+hash(i,1,id+5)*1.4), u=-5+hash(i,2,id+5)*18, p=P(u,v), hgt=1.4+hash(i,3,id+5)*2.4, c=kc[i%3]; K.cyl(p[0],H0+hgt*.5,p[1],.5,0,hgt,5,c,{rx:(hash(i,4,id)-.5)*.5,rz:(hash(i,5,id)-.5)*.5}); }
    G.add(fin(K,glowMat,false,true));
    const cp=P(-1.8,0); buildChest(G,cp[0],H0+.05,cp[1],Math.atan2(fx,fz),hl);
  }
  for(const hl of DW.halls) buildHall(hl);

  /* =============================== İN: kaya duvar yayı + altın yığını =============================== */
  { const R=CG.rig(), GR=CG.rig(), GM=CG.rig(), H0=lair.H;
    DW.walls.forEach((w,i)=>{ lump(R,w.x,H0+w.hh*.38-1,w.z,w.s*1.15,w.hh*.62,w.s*1.15,rockC(i*3),i*3,8,5,.3); lump(R,w.x+Math.cos(w.ang+1.6)*2,H0+w.hh*.82,w.z+Math.sin(w.ang+1.6)*2,w.s*.8,w.hh*.3,w.s*.8,i%3===0?MOSS:rockC(i*3+1),i*3+1,7,4,.3); });
    lump(R,lair.x,H0-5,lair.z,lair.r+2,5,lair.r+2,C("#5f5a52"),900,14,3,.05);
    /* altın yığını: dairesel tepecik, çok sayıda küçük pürüzlü parça */
    const PR=lair.pileR, prof=r=>lair.top*Math.max(0,1-Math.pow(r/PR,2));
    for(let i=0;i<240;i++){ const a=hash(i,1,5)*TAU, r=Math.sqrt(hash(i,2,5))*PR, x=lair.x+Math.cos(a)*r, z=lair.z+Math.sin(a)*r, s=1.2+hash(i,3,5)*1.7;
      lump(GR,x,H0+prof(r)-.45+hash(i,4,5)*.5,z,s,s*.55,s,GOLDS[i%5],i,6,3,.22); }
    for(let i=0;i<14;i++){ const a=hash(i,6,7)*TAU, r=Math.sqrt(hash(i,7,7))*PR*.9, x=lair.x+Math.cos(a)*r, z=lair.z+Math.sin(a)*r, c=[{r:.95,g:.1,b:.15},{r:.15,g:.4,b:1},{r:.1,g:.85,b:.4},{r:.85,g:.25,b:.95}][i%4];
      GM.box(x,H0+prof(r)+.2,z,.7,.9,.7,c,{ry:i*.9,rx:.4,rz:.3}); }
    for(let i=0;i<5;i++){ const a=hash(i,9,3)*TAU, r=PR*(.55+hash(i,2,3)*.35), x=lair.x+Math.cos(a)*r, z=lair.z+Math.sin(a)*r; GR.box(x,H0+prof(r)+.5,z,2,1.1,1.4,"#d6a52c",{ry:a,rz:.35}); GR.box(x,H0+prof(r)+1.1,z,2.1,.3,1.5,"#8a5a1c",{ry:a,rz:.35}); }
    root.add(fin(R,rockMat,true,true)); root.add(fin(GR,goldMat,false,true)); root.add(fin(GM,glowMat,false,true)); }

  /* =============================== EJDERHA MODELİ =============================== */
  const SC=["#8f1d1d","#7a1818","#a32424","#6e1414"].map(C), BELLY=C("#d79a3b"), BONE=C("#e7dcc2"), MEMB=["#5e1212","#6e1818","#511010"].map(C), DK=C("#3a0a0a");
  const dragon=new THREE.Group(); dragon.position.set(lair.x,lair.H+lair.top,lair.z); dragon.rotation.y=Math.atan2(lair.ox,lair.oz); root.add(dragon);
  const body=new THREE.Group(); dragon.add(body);
  const scl=(R,x,y,z,a,b,c,i,seed)=>lump(R,x,y,z,a,b,c,SC[i%4],seed,9,5,.2);
  { const R=CG.rig();
    scl(R,0,3.6,0,4.1,3.3,6.4,0,1); lump(R,0,2.3,.4,3.3,2,5.6,BELLY,2,8,4,.12); scl(R,0,3.4,-6.2,4.3,3.3,4.6,1,3); scl(R,0,3.8,5,3.7,3.2,3.7,2,4);
    for(const s of[-1,1]){ scl(R,s*3,2.2,-5.8,1.8,2.2,2.6,3,5+s); lump(R,s*3.1,.55,-4.2,1.5,.7,2.4,SC[1],7+s,7,3,.12); for(let k=-1;k<=1;k++) R.cyl(s*3.1+k*.65,.5,-6.4,.24,0,.9,5,BONE,{rx:Math.PI/2});
      scl(R,s*2.8,2.1,6.2,1.3,2.1,1.6,2,9+s); lump(R,s*2.9,.7,9.2,1.2,.8,3.1,SC[0],11+s,7,3,.12); for(let k=-1;k<=1;k++) R.cyl(s*2.9+k*.5,.55,12.5,.2,0,.85,5,BONE,{rx:Math.PI/2}); }
    for(let k=0;k<15;k++){ const z=7-k*1.15, y=6.9-.02*z*z+(k===0?-.3:0); R.cyl(0,y+.55,z,.55-k*.012,0,1.5+Math.sin(k*.8)*.35,5,BONE); }
    body.add(fin(R,dragMat,true,false)); }
  /* boyun: 3 iç içe segment (pozitif rx = aşağı) + baş + çene */
  const neck=[], mkNeck=(parent,x,y,z,len,r0,r1,col)=>{ const g=new THREE.Group(); g.position.set(x,y,z); parent.add(g); const R=CG.rig(); lump(R,0,0,len*.5,r0,r0*1.05,len*.58,SC[col%4],20+col,8,5,.16);
    for(let k=0;k<2;k++) R.cyl(0,r0*.95+.15,len*(.25+k*.4),.34,0,1.1,5,BONE); lump(R,0,-r0*.45,len*.5,r0*.7,r0*.5,len*.45,BELLY,30+col,6,3,.1); g.add(fin(R,dragMat,true,false)); neck.push(g); return g; };
  const n1=mkNeck(body,0,4.6,6.9,3.1,1.7,1.5,0), n2=mkNeck(n1,0,0,3.05,3,1.45,1.3,1), n3=mkNeck(n2,0,0,2.95,2.8,1.25,1.1,2);
  const head=new THREE.Group(); head.position.set(0,0,2.75); n3.add(head);
  const jaw=new THREE.Group(); jaw.position.set(0,-.55,.5); head.add(jaw);
  const eyeG=new THREE.Group(); head.add(eyeG);
  const anchors={ nose:new THREE.Object3D(), mouth:new THREE.Object3D(), eyeL:new THREE.Object3D(), eyeR:new THREE.Object3D() };
  anchors.nose.position.set(0,.2,4.3); anchors.mouth.position.set(0,-.35,4.4); anchors.eyeL.position.set(-.85,.55,1.8); anchors.eyeR.position.set(.85,.55,1.8); for(const k in anchors) head.add(anchors[k]);
  { const R=CG.rig(); lump(R,0,0,1.2,1.55,1.3,2.3,SC[0],40,9,5,.14); lump(R,0,-.15,3.3,1.05,.85,1.8,SC[2],41,8,4,.12); lump(R,0,.45,1.9,1.3,.55,1.6,SC[1],42,7,3,.1);
    for(const s of[-1,1]){ R.cyl(s*.9,1.55,-.55,.38,.02,3.1,6,BONE,{rx:-1.1,rz:-s*.25}); R.cyl(s*1.45,.1,.1,.2,0,1.4,5,BONE,{rz:-s*1.2,rx:-.5}); R.box(s*.75,.85,1.55,.9,.22,.7,SC[3]); for(let k=0;k<4;k++) R.cyl(s*.62,-.6,2.2+k*.55,.12,0,.5,4,"#f2ead6",{rx:Math.PI}); R.box(s*.38,.28,4.45,.18,.1,.2,DK); }
    head.add(fin(R,dragMat,true,false));
    const J=CG.rig(); lump(J,0,-.3,1.7,.95,.38,2.2,SC[1],43,8,3,.1); lump(J,0,-.55,.3,.8,.5,.9,BELLY,44,7,3,.1); for(const s of[-1,1]) for(let k=0;k<4;k++) J.cyl(s*.58,.05,1.2+k*.55,.12,0,.45,4,"#f2ead6"); J.box(0,-.55,3.5,.4,.3,.6,BELLY);
    jaw.add(fin(J,dragMat,true,false));
    const E=CG.rig(); for(const s of[-1,1]) E.box(s*.85,.55,1.8,.5,.14,.7,{r:1,g:.82,b:.2},{ry:s*.35}); const em=E.mesh(glowMat,{noShadow:true}); em.frustumCulled=false; eyeG.add(em);
    const Q=CG.rig(); for(const s of[-1,1]) Q.box(s*.85,.5,1.8,.55,.06,.75,DK,{ry:s*.35}); const lids=Q.mesh(dragMat,{noShadow:true}); lids.frustumCulled=false; head.add(lids); head.userData.lids=lids; }
  eyeG.scale.y=0.001;
  /* kuyruk: 10 segment, her biri bir öncekinin çocuğu (kıvrık) */
  const tail=[]; { let par=body, px=0, py=3.2, pz=-9.4; for(let i=0;i<10;i++){ const len=2.8, r=Math.max(.28,2.5*Math.pow(1-i/11,.9)), g=new THREE.Group(); g.position.set(px,py,pz); par.add(g);
      const R=CG.rig(); lump(R,0,0,-len*.5,r,r*.95,len*.62,SC[i%4],60+i,8,4,.14); if(i<9) R.cyl(0,r*.9+.1,-len*.5,Math.max(.15,r*.3),0,Math.max(.6,r*.8),4,BONE);
      if(i===9){ R.box(0,0,-len-.6,.2,.9,2.4,SC[0],{ry:.4}); R.box(0,0,-len-.6,.2,.9,2.4,SC[0],{ry:-.4}); R.cyl(0,0,-len-1.5,.7,0,1.8,4,BONE,{rx:-Math.PI/2}); }
      g.add(fin(R,dragMat,true,false)); g.rotation.y=i===0?.12:.34; g.rotation.x=i===0?-.05:.02; tail.push(g); par=g; px=0; py=0; pz=-len; } }
  /* kanatlar */
  const wings=[]; for(const s of[-1,1]){ const g=new THREE.Group(); g.position.set(s*3,6.4,3.3); body.add(g); const R=CG.rig();
    const S0=[0,0,.5], Wr=[s*4.5,2.2,.2], H0=[s*9.5,1,-.5], Fa=[s*12.5,-.6,-3.8], Fb=[s*11.2,-1.2,-8.2], Fc=[s*8.5,-1.6,-11.2], A=[0,-.5,-7.5], Cc=[s*4.2,0,-4.5], ring=[S0,Wr,H0,Fa,Fb,Fc,A];
    for(let i=0;i<ring.length;i++){ const a=ring[i], b=ring[(i+1)%ring.length], c=MEMB[i%3]; R.tri(Cc,a,b,c); R.tri(Cc,b,a,sh(c,.8)); }
    R.bar(0,0,.3,Wr[0],Wr[1],Wr[2],.6,SC[0],.6); R.bar(Wr[0],Wr[1],Wr[2],H0[0],H0[1],H0[2],.42,SC[1],.42); for(const F of[Fa,Fb,Fc]) R.bar(H0[0],H0[1],H0[2],F[0],F[1],F[2],.24,DK,.24); R.cyl(H0[0],H0[1]+.3,H0[2],.3,0,1.2,5,BONE);
    g.add(fin(R,dragMat,true,false)); wings.push({g,s}); }
  const aim={ n1:0,n2:0,n3:0 }, pose={ aw:0, wo:0, jaw:0, eyes:0, roar:0, hurt:0, die:0 };
  const mw=new THREE.Vector3(), tmp=new THREE.Vector3();
  /* ileri kinematik (sahne grafiğinden bağımsız): baş/ağız/burun/göz dünya konumu = boyun zinciri + gövde + ejderha dönüşü */
  const rotE=(p,r)=>{ let x=p[0], y=p[1], z=p[2], c=Math.cos(r.z), s=Math.sin(r.z), x1=x*c-y*s, y1=x*s+y*c; x=x1; y=y1; c=Math.cos(r.y); s=Math.sin(r.y); x1=x*c+z*s; let z1=-x*s+z*c; x=x1; z=z1; c=Math.cos(r.x); s=Math.sin(r.x); y1=y*c-z*s; z1=y*s+z*c; return [x,y1,z1]; };
  const addP=(p,q)=>[p[0]+q.x,p[1]+q.y,p[2]+q.z];
  const wp=(o,v)=>{ v=v||mw; let p=o===head?[0,0,1.6]:[o.position.x,o.position.y,o.position.z];
    p=addP(rotE(p,head.rotation),head.position); p=addP(rotE(p,n3.rotation),n3.position); p=addP(rotE(p,n2.rotation),n2.position); p=addP(rotE(p,n1.rotation),n1.position);
    p=addP(rotE(p,dragon.rotation),dragon.position); v.x=p[0]; v.y=p[1]; v.z=p[2]; return v; };

  /* =============================== DAVRANIŞ =============================== */
  const yaw0=Math.atan2(lair.ox,lair.oz), sY=Math.sin(yaw0), cY=Math.cos(yaw0), cx0=lair.x, cz0=lair.z, cy0=lair.H+lair.top;
  const world=(lx,ly,lz)=>[cx0+lx*cY+lz*sY, cy0+ly, cz0-lx*sY+lz*cY];
  const hp3=new THREE.Vector3(), nose=new THREE.Vector3(), mouth=new THREE.Vector3(), eL=new THREE.Vector3(), eR=new THREE.Vector3();
  let near=false, t=0, calmT=0, wakeT=0, atkCd=2, breath=0, breathTick=0, lastHit=-99, deadT=0, snoreT=2, smokeT=0, glintT=0, lootT=0, roarT=0, flame=false;
  const spheres=()=>{ const h=hp3; return [ [...world(0,4.6,0),8.6], [...world(0,4.8,5.6),4.6], [...world(0,4,-6.4),5], [h.x,h.y,h.z,3.3], [...world(0,3,-14),3.6] ]; };
  api.headPos=()=>({x:hp3.x,y:hp3.y,z:hp3.z});
  api.bodyPos=()=>({x:cx0,y:cy0+4,z:cz0});
  function wake(by){ if(api.st==="dying"||api.st==="dead") return false; if(api.st==="sleep"||api.st==="calm"){ api.st="wake"; wakeT=0; roarT=0; api.stats.woke++; Ev.emit("dragonWake",by); Game.toast&&Game.toast("t_dragon_wake",3600); } lastHit=t; return true; }
  api.wake=wake;
  function hurt(d,x,y,z){ if(api.st==="dying"||api.st==="dead") return false; wake("hit"); api.hp-=d; pose.hurt=1; FX.spark(x,y,z,10,9,[1,.6,.2]); if(au()&&au().thud) au().thud(x,y,z);
    if(api.hp<=0){ api.hp=0; die(); return true; } return false; }
  api.hurt=hurt;
  function die(){ api.st="dying"; deadT=0; api.stats.slain++; flame=false; breath=0; if(au()&&au().roar) au().roar(hp3.x,hp3.y,hp3.z,1.6); if(Game.shakeAdd) Game.shakeAdd(.7); }
  function finishDeath(){ api.st="dead"; deadT=0; const p=api.bodyPos(); Game.Eco&&Game.Eco.add(800,"dragon",p.x,p.z); Game.toast&&Game.toast("t_dragon_dead",4200); Ev.emit("dragonSlain");
    for(let i=0;i<60;i++) FX.E(true,p.x+rr(-9,9),p.y+rr(1,7),p.z+rr(-9,9),rr(-5,5),rr(6,18),rr(-5,5),rr(.8,1.8),rr(.5,1),.1,[1,.85,.3],[1,.5,.1],1,14,.97); if(au()&&au().coin) au().coin(1); }
  function reset(){ api.st="sleep"; api.hp=api.max; pose.die=0; pose.aw=0; pose.wo=0; pose.eyes=0; dragon.scale.set(1,1,1); dragon.position.y=cy0; for(const c of chests){ c.opened=false; c.cool=0; } }
  api.reset=reset;
  /* hasar kancası */
  if(D&&D.damageSphere){ const o=D.damageSphere; api.rawDamage=o; D.damageSphere=function(x,y,z,r,amt,speed,quiet){ const n=o.apply(this,arguments);
      if(near&&api.st!=="dead"&&api.st!=="dying"){ const S=spheres(); for(const s of S){ const dx=x-s[0], dy=y-s[1], dz=z-s[2], rr2=r+s[3]; if(dx*dx+dy*dy+dz*dz<rr2*rr2){ hurt(clamp(amt*(.6+(speed||10)*.012),.05,2.5),x,y,z); break; } } }
      return n; }; }
  /* ateş topu */
  function shoot(from,tx,ty,tz){ if(api.fireballs.length>=4) return; const dx=tx-from.x, dy=ty-from.y, dz=tz-from.z, l=Math.hypot(dx,dy,dz)||1, sp=64; api.fireballs.push({x:from.x,y:from.y,z:from.z,vx:dx/l*sp,vy:dy/l*sp,vz:dz/l*sp,life:5});
    if(au()&&au().roar) au().roar(from.x,from.y,from.z,.6); if(au()&&au().flame) au().flame(from.x,from.y,from.z); FX.E(true,from.x,from.y,from.z,0,0,0,.4,5,9,[1,.7,.2],[1,.3,.05],.9,0,1); }
  function explode(f){ const o=api.rawDamage||D.damageSphere; FX.fire(f.x,f.y,f.z,26,0,5,0,3.2); FX.shock&&FX.shock(f.x,f.y,f.z,10,16); FX.spark(f.x,f.y,f.z,22,18,[1,.7,.3]); FX.dust(f.x,f.y,f.z,10,6,[.5,.45,.4]);
    if(au()) { au().boom&&au().boom(f.x,f.y,f.z,false); }
    o.call(D,f.x,f.y,f.z,9,.7,22,true);
    const dx=hero.position.x-f.x, dy=hero.position.y-f.y, dz=hero.position.z-f.z, d=Math.hypot(dx,dy,dz); if(d<9&&Game.Hp&&Game.Hp.hurt) Game.Hp.hurt(16*(1-d/14),f.x,f.y,f.z,"dragon");
    if(Game.shakeAdd&&d<90) Game.shakeAdd(.35*(1-d/90)); if(d<12&&H&&H.vel){ const k=18/Math.max(1,d); H.vel.x+=dx/Math.max(.5,d)*k; H.vel.y+=Math.abs(dy)/Math.max(.5,d)*k*.6+4; H.vel.z+=dz/Math.max(.5,d)*k; } }
  function stepBalls(dt){ const B=api.fireballs; for(let i=B.length-1;i>=0;i--){ const f=B[i]; f.life-=dt; f.x+=f.vx*dt; f.y+=f.vy*dt; f.z+=f.vz*dt;
      FX.E(true,f.x,f.y,f.z,rr(-1,1),rr(-1,1),rr(-1,1),.25,4.2,7,[1,.75,.25],[1,.3,.05],.9,0,1); if(Math.random()<.7) FX.fire(f.x,f.y,f.z,1,0,0,0,1.6);
      const hx=hero.position.x-f.x, hy=hero.position.y-f.y, hz=hero.position.z-f.z, hit=hx*hx+hy*hy+hz*hz<14, gnd=f.y<W.surfaceAt(f.x,f.z,f.y)+.6;
      if(hit||gnd||f.life<=0){ explode(f); B.splice(i,1); } } }
  /* uzun ateş soluğu: ağızdan hedefe koni; kahramana saniyede ~14 hasar */
  function breathe(dt,tx,ty,tz){ wp(anchors.mouth,mouth); const dx=tx-mouth.x, dy=ty-mouth.y, dz=tz-mouth.z, l=Math.hypot(dx,dy,dz)||1, ux=dx/l, uy=dy/l, uz=dz/l;
    for(let k=0;k<7;k++){ const sp=rr(26,44); FX.E(true,mouth.x,mouth.y,mouth.z,ux*sp+rr(-3,3),uy*sp+rr(-3,3),uz*sp+rr(-3,3),rr(.5,.95),rr(1.2,2),rr(5,9),[1,.78,.3],[.9,.15,.03],.75,-2,.985); }
    if(Math.random()<.5) FX.E(false,mouth.x+ux*6,mouth.y+uy*6,mouth.z+uz*6,ux*14+rr(-2,2),uy*14+3,uz*14+rr(-2,2),rr(1,1.8),rr(1.5,2.5),rr(6,10),[.22,.2,.2],[.38,.36,.34],.45,-1,.98);
    breathTick-=dt; if(breathTick<=0){ breathTick=.2; const hx=hero.position.x-mouth.x, hy=hero.position.y-mouth.y, hz=hero.position.z-mouth.z, hd=Math.hypot(hx,hy,hz), dot=(hx*ux+hy*uy+hz*uz)/(hd||1);
      if(hd<56&&dot>.9&&Game.Hp&&Game.Hp.hurt) Game.Hp.hurt(2.8,mouth.x,mouth.y,mouth.z,"dragon");
      const o=api.rawDamage||D.damageSphere; o.call(D,mouth.x+ux*Math.min(hd,26),mouth.y+uy*Math.min(hd,26),mouth.z+uz*Math.min(hd,26),5,.12,12,true); } }

  function updatePose(dt){
    const aw=api.st==="sleep"||api.st==="calm"?0:(api.st==="dying"||api.st==="dead"?.25:1), wo=api.st==="dying"||api.st==="dead"?1:(api.st==="angry"?(breath>0||roarT>0?.95:.45):(api.st==="wake"?sm01(wakeT/1.6)*.7:0));
    const k=1-Math.exp(-dt*(aw>pose.aw?2.2:1.6)), kw=1-Math.exp(-dt*2.6);
    pose.aw+=(aw-pose.aw)*k; pose.wo+=(wo-pose.wo)*kw; pose.eyes+=((api.st==="dying"||api.st==="dead"||aw<.5?0:1)-pose.eyes)*(1-Math.exp(-dt*5)); pose.hurt=Math.max(0,pose.hurt-dt*3.2);
    const roar=roarT>0?Math.sin(clamp(1-roarT/1.7,0,1)*Math.PI):0; pose.roar+=(roar-pose.roar)*(1-Math.exp(-dt*10));
    const jawT=Math.max(pose.roar,breath>0?.85:0,api.st==="dying"?.5:0), kj=1-Math.exp(-dt*9); pose.jaw+=(jawT-pose.jaw)*kj;
    /* bakış: kahramana doğru boyun yönü (gövde yerel çerçevede) */
    let yawT=0; if(api.st==="angry"||api.st==="wake"){ const dx=hero.position.x-cx0, dz=hero.position.z-cz0, lx=dx*cY-dz*sY, lz=dx*sY+dz*cY; yawT=clamp(Math.atan2(lx,lz),-1.15,1.15); }
    aim.n1+=(yawT*.38-aim.n1)*(1-Math.exp(-dt*2.5)); aim.n2+=(yawT*.34-aim.n2)*(1-Math.exp(-dt*2.5)); aim.n3+=(yawT*.28-aim.n3)*(1-Math.exp(-dt*2.5));
    const A=sm01(pose.aw), br=Math.sin(t*(1.15+A*1.8)), sway=Math.sin(t*.6);
    n1.rotation.x=lerp(.75,-.42,A)-pose.roar*.12+br*.012; n2.rotation.x=lerp(.45,-.26,A)-pose.roar*.1; n3.rotation.x=lerp(-.55,.42,A)-pose.roar*.55; head.rotation.x=lerp(-.4,.28,A)-pose.roar*.2;
    n1.rotation.y=aim.n1; n2.rotation.y=aim.n2; n3.rotation.y=aim.n3+Math.sin(t*.9)*.02*A; jaw.rotation.x=.04+pose.jaw*.85;
    eyeG.scale.y=Math.max(.001,pose.eyes); eyeG.visible=pose.eyes>.03; head.userData.lids.visible=pose.eyes<.5;
    const s=1+.022*br*(1-A*.3)+pose.hurt*.035, die=api.st==="dying"||api.st==="dead"; body.scale.set(1+(pose.hurt*.02),s,1);
    for(const w of wings){ const o=sm01(pose.wo), flap=(api.st==="angry"&&(breath>0||roarT>0)?Math.sin(t*7)*.22:Math.sin(t*2.2)*.04*A)*o; w.g.scale.x=lerp(.26,1,o); w.g.rotation.z=w.s*(lerp(1.28,.1,o)+flap); w.g.rotation.y=w.s*lerp(.7,0,o); w.g.rotation.x=-.05*A; }
    for(let i=0;i<tail.length;i++){ tail[i].rotation.y=(i===0?.12:.34)+Math.sin(t*(.7+A*1.4)+i*.55)*(.025+A*.05)*(die?0:1); }
    dragon.position.y=cy0-(api.st==="dead"?Math.min(1.8,deadT*.15):0); dragon.rotation.z=die?Math.min(.12,(api.st==="dead"?1:deadT/3)*.12):0;
  }
  function updateWorldPos(){ wp(head,hp3); }
  const cdTick=(dt)=>{ for(const c of chests){ if(c.cool>0) c.cool-=dt; } };
  function updateChests(dt){ const hp=hero.position, play=Game.mode==="play";
    for(const c of chests){ const dxz=Math.hypot(hp.x-c.x,hp.z-c.z), dy=Math.abs(hp.y-c.y-1.2);
      if(play&&!c.opened&&c.cool<=0&&dxz<3.4&&dy<4){ c.opened=true; c.cool=600; api.stats.chests++; const p=c.g.position; Game.Eco&&Game.Eco.add(c.amt,"chest",c.x,c.z); Game.toast&&Game.toast("t_chest",2600); if(au()){ au().chest&&au().chest(0); setTimeout(()=>{ au()&&au().chest&&au().chest(1); },280); }
        for(let i=0;i<24;i++) FX.E(true,p.x,p.y+1.4,p.z,rr(-4,4),rr(4,10),rr(-4,4),rr(.7,1.3),rr(.4,.8),.1,[1,.9,.4],[1,.55,.1],1,12,.97); Ev.emit("chestOpened",c); }
      if(c.opened&&c.cool<=0&&dxz>14){ c.opened=false; }
      const tgt=c.opened?1:0; c.open+=(tgt-c.open)*(1-Math.exp(-dt*5)); c.lid.rotation.x=-c.open*1.25; c.glow.visible=c.open>.2; } }

  Game.updaters.push((dt0,time,raw)=>{
    const dt=Math.min(dt0,.05), play=Game.mode==="play"||Game.mode==="menu";
    const dxl=hero.position.x-I.x, dzl=hero.position.z-I.z, dist=Math.hypot(dxl,dzl);
    near=play&&dist<I.R+520&&hero.position.y<2500; root.visible=near; api.near=near; if(!near) return;
    t+=dt; api.t=t; cdTick(dt); updateWorldPos();
    const hv=H.vel?H.vel.length():0, dHead=Math.hypot(hero.position.x-hp3.x,hero.position.y-hp3.y,hero.position.z-hp3.z), dBody=Math.hypot(hero.position.x-cx0,hero.position.z-cz0);
    const act=Game.mode==="play"&&!(Game.Hp&&Game.Hp.dead);
    if(api.st==="sleep"){ api.hp=Math.min(api.max,api.hp+dt*2);
      if(act&&dBody<34&&hv>34&&Math.abs(hero.position.y-cy0)<30) wake("noise");
      /* horultu: yakında burun dumanı + ses */
      smokeT-=dt; if(smokeT<=0){ smokeT=rr(1.2,1.9); wp(anchors.nose,nose); FX.E(false,nose.x,nose.y,nose.z,rr(-.4,.4),rr(.8,1.6),rr(-.4,.4),rr(2.6,3.6),.5,2.6,[.5,.5,.52],[.68,.68,.7],.38,-.2,.985); }
      snoreT-=dt; if(snoreT<=0){ snoreT=rr(3.4,5); if(au()&&au().snore&&dHead<160) au().snore(hp3.x,hp3.y,hp3.z); }
      /* altın yığını: üstünde yürüyen coin toplar, ejderhayı uyandırma riski */
      if(act&&H.grounded&&dBody<lair.pileR*.85&&Math.abs(hero.position.y-(cy0+1))<4){ lootT-=dt; if(lootT<=0){ lootT=1; api.stats.gold++; Game.Eco&&Game.Eco.add(8,"gold",hero.position.x,hero.position.z); if(Math.random()<.07) wake("loot"); } } else lootT=Math.min(lootT,1); }
    else if(api.st==="wake"){ wakeT+=dt; if(wakeT>1.5&&roarT<=0&&wakeT<1.6){ roarT=1.7; if(au()&&au().roar) au().roar(hp3.x,hp3.y,hp3.z,1.2); if(Game.shakeAdd) Game.shakeAdd(.35); } if(roarT>0) roarT-=dt; if(wakeT>3.3){ api.st="angry"; atkCd=1.2; } }
    else if(api.st==="angry"){ if(roarT>0) roarT-=dt; atkCd-=dt; calmT=(t-lastHit>26&&dHead>110)||dBody>360?calmT+dt:0;
      if(breath>0){ breath-=dt; breathe(dt,hero.position.x,hero.position.y+.4,hero.position.z); if(breath<=0){ flame=false; atkCd=rr(2.2,3.4); } }
      else if(atkCd<=0&&act){ if(dHead<54){ breath=1.9; flame=true; breathTick=0; if(au()&&au().flame) au().flame(hp3.x,hp3.y,hp3.z); }
        else if(dHead<230){ wp(anchors.mouth,mouth); const tt=dHead/64; shoot(mouth,hero.position.x+(H.vel?H.vel.x:0)*tt*.7,hero.position.y+(H.vel?H.vel.y:0)*tt*.4,hero.position.z+(H.vel?H.vel.z:0)*tt*.7); atkCd=rr(3.2,5); }
        else atkCd=1.2; }
      if(calmT>5){ api.st="calm"; calmT=0; breath=0; } }
    else if(api.st==="calm"){ calmT+=dt; if(calmT>3.2){ api.st="sleep"; calmT=0; } if(act&&dBody<34&&hv>34) wake("noise"); }
    else if(api.st==="dying"){ deadT+=dt; if(Math.random()<dt*14){ const p=world(rr(-4,4),rr(2,7),rr(-8,8)); FX.fire(p[0],p[1],p[2],3,0,3,0,2.2); if(Math.random()<.3) FX.smoke(p[0],p[1],p[2],1,2); } if(deadT>4.2) finishDeath(); }
    else if(api.st==="dead"){ deadT+=dt; if(deadT>600&&dist>I.R+260) reset(); }
    stepBalls(dt); updatePose(dt);
    /* hazine ışıltıları (altın yığını) */
    glintT-=dt; if(glintT<=0){ glintT=rr(.08,.22); const a=Math.random()*TAU, r=Math.sqrt(Math.random())*lair.pileR*.9; FX.E(true,cx0+Math.cos(a)*r,cy0+lair.top*(1-r*r/(lair.pileR*lair.pileR))+.3,cz0+Math.sin(a)*r,0,rr(.4,1.2),0,rr(.5,.9),rr(.5,1.1),.05,[1,.92,.5],[1,.7,.2],.9,0,1); }
    if(pose.eyes>.4){ wp(anchors.eyeL,eL); wp(anchors.eyeR,eR); FX.E(true,eL.x,eL.y,eL.z,0,0,0,.08,1.1,.9,[1,.5,.1],[1,.2,.05],.9,0,1); FX.E(true,eR.x,eR.y,eR.z,0,0,0,.08,1.1,.9,[1,.5,.1],[1,.2,.05],.9,0,1); }
    if(pose.hurt>.5&&Math.random()<.5) FX.smoke(hp3.x,hp3.y,hp3.z,1,1);
    updateChests(dt);
    /* hızlı çarpma: ejderhaya yüksek hızla çarpan kahraman hasar verir */
    if(act&&hv>58&&api.st!=="dead"&&api.st!=="dying"){ for(const s of spheres()){ const dx=hero.position.x-s[0], dy=hero.position.y-s[1], dz=hero.position.z-s[2]; if(dx*dx+dy*dy+dz*dz<(s[3]+1.2)*(s[3]+1.2)){ if(t-lastHit>.5){ hurt(hv>90?2.6:1.4,hero.position.x,hero.position.y,hero.position.z); H.vel.multiplyScalar(.78); } break; } } }
    hv0=hv; if(act) solidPush(); else hasPrev=false;
  });
  /* ---- katı gövde: kahraman ejderhanın içinden geçemez (hızlı uçuşta da: yol-küre kesişimi). Hasar, yukarıdaki hızlı-çarpma bloğunda. ---- */
  const solids=()=>{ const S=[ [...world(0,4.6,0),8.6], [...world(0,4.8,5.6),4.8], [...world(0,4,-6.4),5.2], [hp3.x,hp3.y,hp3.z,3.6], [...world(0,3,-14),3.8], [...world(0,2.6,-19),3], [...world(0,2.2,-24),2.3], [...world(0,1.8,-29),1.7] ];
    const cn=world(0,6.8,6.5); for(let i=1;i<=3;i++){ const k=i/4; S.push([cn[0]+(hp3.x-cn[0])*k,cn[1]+(hp3.y-cn[1])*k,cn[2]+(hp3.z-cn[2])*k,3.1-k*.3]); }
    if(pose.wing!==undefined||true){ for(const sd of [-1,1]){ S.push([...world(sd*7,6.2,2.5),3.2]); } } return S; };
  const prevH=new THREE.Vector3(); let hasPrev=false;
  function solidPush(){ const p=hero.position, Rh=1.05; if(!hasPrev){ prevH.copy(p); hasPrev=true; return; }
    if(Math.hypot(p.x-prevH.x,p.y-prevH.y,p.z-prevH.z)>300){ prevH.copy(p); return; }
    const S=solids(); let hit=false;
    for(const s of S){ const R=s[3]+Rh; const dx=p.x-prevH.x, dy=p.y-prevH.y, dz=p.z-prevH.z, fx=prevH.x-s[0], fy=prevH.y-s[1], fz=prevH.z-s[2];
      const a=dx*dx+dy*dy+dz*dz, b=2*(fx*dx+fy*dy+fz*dz), c=fx*fx+fy*fy+fz*fz-R*R; let nx,ny,nz,placed=false;
      if(c>0&&a>1e-9){ const disc=b*b-4*a*c; if(disc>=0){ const tt=(-b-Math.sqrt(disc))/(2*a); if(tt>=0&&tt<=1){ p.set(prevH.x+dx*tt,prevH.y+dy*tt,prevH.z+dz*tt); nx=p.x-s[0]; ny=p.y-s[1]; nz=p.z-s[2]; placed=true; } } }
      if(!placed){ const ex=p.x-s[0], ey=p.y-s[1], ez=p.z-s[2], d2=ex*ex+ey*ey+ez*ez; if(d2<R*R){ nx=ex; ny=ey; nz=ez; placed=true; } }
      if(!placed) continue; let l=Math.hypot(nx,ny,nz); if(l<1e-6){ nx=0; ny=1; nz=0; l=1; } nx/=l; ny/=l; nz/=l;
      p.set(s[0]+nx*R,s[1]+ny*R,s[2]+nz*R); hit=true;
      if(H.vel){ const vn=H.vel.x*nx+H.vel.y*ny+H.vel.z*nz; if(vn<0){ H.vel.x-=nx*vn*1.15; H.vel.y-=ny*vn*1.15; H.vel.z-=nz*vn*1.15; } } }
    if(hit&&Game.shakeAdd&&hv0>40) Game.shakeAdd(Math.min(.5,hv0/260));
    prevH.copy(p); }
  let hv0=0;
  api.solids=solids;
  api.ready=true; api.root=root; api.chests=chests; api.dragon=dragon; api.pose=pose; api.parts={n1,n2,n3,head,jaw,wings,tail,body,anchors};
  return api; })();
