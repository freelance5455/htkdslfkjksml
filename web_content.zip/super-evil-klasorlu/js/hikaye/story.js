"use strict";
/* ===== HİKAYE MODU: 14 görevlik yönlendirmeli senaryo. Menüde Başla'nın altındaki HİKAYE düğmesiyle başlar; ilerleme kaydedilir.
   Görev ilerlemesi oyun olaylarından (Game.Ev) ve anlık durumdan (yükseklik, hız, arama seviyesi, ada, uzay) okunur. Ödül: coin. Alt yazı anlatımı 13 dilde. ===== */
Game.Story=(function(){
  const H=Game.H, hero=Game.heroObj, Ev=Game.Ev, W=Game.W, $=id=>document.getElementById(id);
  const clamp=(v,a,b)=>v<a?a:v>b?b:v;
  const api={on:false,i:0,st:"off",cnt:0,t:0,replay:false,done:false,stats:{completed:0}};
  const police=()=>Game.Police, dragon=()=>Game.Dragon;
  const isl=W.islands[3], city={x:0,z:0};
  const lairT=()=>{ const l=Game.DragonWorld&&Game.DragonWorld.lair; return l?{x:l.x,z:l.z,y:l.H}:{x:isl.x,z:isl.z}; };
  const dragonAwake=()=>{ const d=dragon(); return !!d&&d.st!=="sleep"&&d.st!=="calm"; };
  /* görev tanımları: k = metin anahtarı, goal, prog() → mevcut değer, ev = sayılan olay, target() = ok/mesafe hedefi */
  const MS=[
    {k:"m01",goal:150,unit:" m",prog:()=>H.alt||0,reward:60},
    {k:"m02",goal:70,unit:" m/s",prog:()=>H.speed||0,reward:60},
    {k:"m03",goal:2,ev:"building",reward:100},
    {k:"m04",goal:8,ev:"npcHit",reward:80},
    {k:"m05",goal:4,ev:"carDestroyed",reward:80},
    {k:"m06",goal:2,unit:"★",prog:()=>police()?police().stars:0,needPolice:true,reward:120},
    {k:"m07",goal:1,prog:()=>police()&&police().stars===0?1:0,needPolice:true,armed:true,reward:150,binary:true},
    {k:"m08",goal:5,ev:"building",reward:120},
    {k:"m09",goal:1,prog:()=>Math.hypot(hero.position.x-isl.x,hero.position.z-isl.z)<isl.R+30?1:0,target:lairT,reward:150,binary:true},
    {k:"m10",goal:1,ev:"chestOpened",target:lairT,reward:100},
    {k:"m11",goal:1,ev:"dragonWake",prog:()=>dragonAwake()?1:0,target:lairT,reward:100,binary:true},
    {k:"m12",goal:1,ev:"dragonSlain",prog:()=>{ const d=dragon(); return d&&(d.st==="dying"||d.st==="dead")?1:0; },target:lairT,reward:300,binary:true},
    {k:"m13",goal:1,prog:()=>(H.sp||0)>.85?1:0,reward:200,binary:true},
    {k:"m14",goal:3,ev:"building",target:()=>city,reward:1500,final:true}
  ];
  api.missions=MS;
  /* ---- arayüz ---- */
  let el=null, elLine=null, built=false, lineQ=[], lineT=0, lineOn=false, skipT=0;
  function build(){ if(built) return; const hud=$("hud"); if(!hud) return; built=true;
    el=document.createElement("div"); el.id="story";
    el.innerHTML='<div class="sth"><span id="stCh"></span><span id="stRw"></span></div><div class="stt" id="stT" dir="auto"></div><div class="sto" id="stO" dir="auto"></div><div class="stbar"><i id="stFill"></i></div><div class="stf"><span id="stCnt"></span><span id="stDist"><em id="stArrow">▲</em><u id="stKm"></u></span><button id="stSkip" type="button" hidden></button></div>';
    hud.appendChild(el); elLine=document.createElement("div"); elLine.id="storyLine"; hud.appendChild(elLine);
    const sk=$("stSkip"); if(sk) sk.onclick=()=>{ if(api.st==="run"){ if(Game.audio) Game.audio.click(); next(true); } }; }
  const tx=k=>t(k);
  const fmt=(s,o)=>s.replace(/\{(\w+)\}/g,(m,k)=>o[k]!==undefined?o[k]:m);
  function showLine(txt,dur){ if(!elLine) return; lineQ.push({txt,dur:dur||Math.max(3.2,2+txt.length*.055)}); if(!lineOn) pumpLine(); }
  function pumpLine(){ const q=lineQ.shift(); if(!q){ lineOn=false; if(elLine) elLine.classList.remove("on"); return; } lineOn=true;
    try{ elLine.innerHTML=""; const d=document.createElement("div"); d.className="sl"; d.setAttribute("dir","auto"); const b=document.createElement("b"); b.textContent=tx("st_voice")+":"; const s=document.createElement("span"); s.textContent=q.txt; d.appendChild(b); d.appendChild(s); elLine.appendChild(d); elLine.classList.add("on"); }catch(e){}
    lineT=q.dur; }
  const say=k=>showLine(tx(k));
  function ui(){ if(!built||!el) return; const m=MS[api.i]; if(!m) return; $("stCh").textContent=fmt(tx("st_ch"),{n:api.i+1,m:MS.length}); $("stRw").textContent="+"+rewardOf(m); $("stCnt").textContent=""; lastTxt=""; $("stFill").style.width="0%"; $("stT").textContent=tx("st_"+m.k+"t"); $("stO").textContent=tx("st_"+m.k+"o"); }
  const rewardOf=m=>Math.round(m.reward*(api.replay?.4:1));
  /* ---- akış ---- */
  function startMission(i){ api.i=i; api.st="run"; api.cnt=0; api.t=0; skipT=0; api.armed=false; lastTxt=""; const m=MS[i]; if(!m){ finish(); return; }
    store.set("story_i",String(i)); ui();
    if(m.needPolice&&!(Game.settings&&Game.settings.police)){ Game.toast&&Game.toast("st_skip_police",3200); next(true); return; }
    if(m.armed&&police()&&police().stars>0) api.armed=true;
    /* anlık durumdan zaten sağlanmış olabilecek görevler (ör. ejderha zaten uyanık/ölü) */
    if(i===0) { say("st_p1"); say("st_p2"); } say("st_"+m.k+"l");
    Ev.emit("storyMission",i); }
  function progress(){ const m=MS[api.i]; if(!m) return 0; let v=m.prog?m.prog():0; if(m.ev) v=Math.max(v,api.cnt); if(m.binary) v=v>=m.goal?m.goal:0; return v; }
  function complete(){ const m=MS[api.i]; api.st="gap"; api.t=0; const r=rewardOf(m); if(Game.Eco) Game.Eco.add(r,"story",hero.position.x,hero.position.z); Game.toast&&Game.toast("st_done",2600); if(Game.audio){ Game.audio.buy&&Game.audio.buy(); } api.stats.completed++; Ev.emit("storyDone",api.i,r);
    if(m.final){ finishSoon=true; } }
  let finishSoon=false;
  function next(skipped){ if(api.i+1>=MS.length){ finish(); return; } startMission(api.i+1); }
  function finish(){ api.st="end"; api.t=0; api.done=true; store.set("story_done","1"); store.set("story_i","0"); Game.toast&&Game.toast("st_end",4200); say("st_e1"); say("st_e2"); Ev.emit("storyEnd");
    if(el) el.classList.remove("on"); }
  api.begin=function(){ build(); const done=store.get("story_done","0")==="1"; let i=parseInt(store.get("story_i","0"),10)||0; api.replay=done; if(i<0||i>=MS.length) i=0; api.on=true; finishSoon=false; api.done=false; lineQ.length=0; lineOn=false; startMission(i); if(el) el.classList.add("on"); };
  api.off=function(){ api.on=false; api.st="off"; if(el) el.classList.remove("on"); if(elLine) elLine.classList.remove("on"); lineQ.length=0; lineOn=false; };
  api.skip=()=>{ if(api.on&&api.st==="run") next(true); };
  /* ---- olaylar ---- */
  for(const e of ["building","npcHit","carDestroyed","chestOpened","dragonWake","dragonSlain"]) Ev.on(e,()=>{ if(api.on&&api.st==="run"){ const m=MS[api.i]; if(m&&m.ev===e) api.cnt++; } });
  /* ---- güncelleme ---- */
  const dv=new THREE.Vector3(); let uiT=0, lastTxt="";
  Game.updaters.push((dt0,time,raw)=>{ const dt=Math.min(raw||dt0,.1); const play=Game.mode==="play"; if(el) el.classList.toggle("on",api.on&&play&&api.st!=="end"&&api.st!=="off");
    if(!api.on||!play) return; api.t+=dt;
    if(lineOn){ lineT-=dt; if(lineT<=0) pumpLine(); }
    if(api.st==="gap"){ if(api.t>3.4){ if(finishSoon){ finishSoon=false; finish(); } else next(false); } return; }
    if(api.st==="end"){ if(api.t>9) api.off(); return; }
    if(api.st!=="run") return;
    const m=MS[api.i]; if(!m) return; skipT+=dt;
    let v=progress(); if(m.armed){ const s=police()?police().stars:0; if(s>0) api.armed=true; v=(s===0&&(api.armed||api.t>2))?1:0; }
    if(v>=m.goal){ complete(); return; }
    uiT-=dt; if(uiT<=0){ uiT=.15; const f=clamp(v/m.goal,0,1); $("stFill").style.width=(f*100).toFixed(0)+"%";
      const cnt=m.binary?"":(m.prog&&!m.ev?Math.floor(v)+"/"+m.goal+(m.unit||""):Math.floor(v)+"/"+m.goal); if(cnt!==lastTxt){ lastTxt=cnt; $("stCnt").textContent=cnt; }
      const tg=m.target?m.target():null, d=$("stDist"); if(tg){ const dx=tg.x-hero.position.x, dz=tg.z-hero.position.z, dist=Math.hypot(dx,dz); d.style.display=""; $("stKm").textContent=dist>=1000?(dist/1000).toFixed(1)+" km":Math.round(dist)+" m";
        let yc=0; try{ if(camera.getWorldDirection){ camera.getWorldDirection(dv); yc=Math.atan2(dv.x,dv.z); } }catch(e){} const rel=-(Math.atan2(dx,dz)-yc); $("stArrow").style.transform="rotate("+(rel*57.2958).toFixed(0)+"deg)"; } else d.style.display="none";
      const sk=$("stSkip"); if(sk){ const show=skipT>75; if(sk.hidden===show){ sk.hidden=!show; if(show) sk.textContent="⏭ "+tx("st_skip"); } } } });
  api.ready=true; return api; })();
