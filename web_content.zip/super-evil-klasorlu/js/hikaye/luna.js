"use strict";
/* ===== LUNA PARK (doğu adası): giriş kapısı, çeşme, dönme dolap, atlı karınca, korsan gemisi, hız treni, serbest düşüş kulesi, dükkânlar, korku evi ===== */
(function(){
const CG=Game.CG, W=Game.W, fbox=CG.fbox, pbox=CG.pbox, C=CG.C, L=CG.lists, rnd=CG.rnd, pick=CG.pick, TAU=Math.PI*2, B=Game.buildings;
const IX=700, IZ=17, F=(x,z)=>CG.F(x,z);
const solid=(x,z,hw,hd,h,y0)=>B.push({x,z,hw,hd,h,y0:y0||0,park:true});
Game.rides=[];
const root=new THREE.Group(); scene.add(root);
const bulbMat=new THREE.MeshBasicMaterial({vertexColors:true}); CG.bulbMat=bulbMat;
const bulbs=CG.rig();                 // statik ampuller (gece parlar)
const BC=["#ffd23f","#ff5d8f","#5de0ff","#7dff7a","#ffffff","#ff9a3c"];
const bulb=(x,y,z,c,s)=>bulbs.box(x,y,z,s||.32,s||.32,s||.32,c||"#ffd23f");
function posts(x0,z0,x1,z1,n,y,c){ for(let i=0;i<=n;i++){ const t=i/n; bulb(x0+(x1-x0)*t,y,z0+(z1-z0)*t,c||BC[i%BC.length]); } }

/* ---------------- ZEMİN: gezinti yolu, çeşme meydanı, ride yolları ---------------- */
const TILE=["#e9dab2","#dccb9c"];
for(let i=0;i<27;i++) for(let j=0;j<2;j++){ const x=606+i*5+2.5, z=IZ-5+j*5+2.5; fbox(F(x,z),x,0,z,5,.07,5,TILE[(i+j)&1]); }
const edge=(x,z,w,d)=>fbox(F(x,z),x,0,z,w,.09,d,"#b8884d");
edge(676,IZ-5.3,140,.5); edge(676,IZ+5.3,140,.5);
function path(x0,z0,x1,z1,w){ const n=Math.max(1,Math.round(Math.hypot(x1-x0,z1-z0)/5)); for(let i=0;i<n;i++){ const t=(i+.5)/n, x=x0+(x1-x0)*t, z=z0+(z1-z0)*t, alongX=Math.abs(x1-x0)>Math.abs(z1-z0), l=Math.hypot(x1-x0,z1-z0)/n;
    fbox(F(x,z),x,0,z,alongX?l+.02:w,.07,alongX?w:l+.02,TILE[i&1]); } }
CG.disc(F(IX,IZ),IX,.09,IZ,17.5,40,"#e2d2ab",11); CG.disc(F(IX,IZ),IX,.1,IZ,14.2,40,"#b84a3a",13.6); CG.disc(F(IX,IZ),IX,.1,IZ,12.6,40,"#f2f2f2",12.2);
path(700,12,700,-22,6); path(650,12,650,-4,6); path(655,22,655,46,6); path(700,22,700,50,6); path(745,22,745,42,6);


/* ---------------- GİRİŞ KAPISI ---------------- */
{ const x=612, A=F(x,IZ);
  for(const s of [-1,1]){ const z=IZ+s*8.4; for(let k=0;k<6;k++) CG.cyl(A,x,k*2.2,z,1.55,1.55,2.2,12,k%2?"#e63946":"#f8f8f8",k===5);
    CG.cyl(A,x,13.2,z,2.0,.15,3,12,"#ffd23f"); CG.ball(A,x,16.4,z,.5,"#ff5d8f",8); solid(x,z,1.7,1.7,13.2);
    for(let k=0;k<6;k++){ bulb(x-1.6,k*2.2+1.1,z,BC[k%6],.28); bulb(x+1.6,k*2.2+1.1,z,BC[(k+2)%6],.28); } }
  fbox(A,x,9.8,IZ,1.5,4.2,18.4,"#2a2f5c"); fbox(A,x,13.8,IZ,1.9,.4,18.8,"#ffd23f");
  const sg1=CG.sign("LUNA PARK",15.4,3.5,"#2a2f5c","#ffd23f",x-.8,11.9,IZ,-Math.PI/2), sg2=CG.sign("LUNA PARK",15.4,3.5,"#2a2f5c","#ffd23f",x+.8,11.9,IZ,Math.PI/2);
  posts(x-.9,IZ-8.8,x-.9,IZ+8.8,36,9.55,null); posts(x-.9,IZ-8.8,x-.9,IZ+8.8,36,14.2,null);
  // yıldız süsleri
  for(const s of [-1,0,1]){ pbox(A,x,14.2,IZ+s*6,.5,2.2,.5,"#ff5d8f"); pbox(A,x,14.2,IZ+s*6,.5,.5,2.2,"#ff5d8f"); }
  CG.flag(x,IZ-12,"#e63946"); CG.flag(x,IZ+12,"#2a63c9"); }

/* ---------------- ÇEŞME ---------------- */
const fountain=(function(){ const A=F(IX,IZ), T=CG.T(IX,IZ), N=24, R=10;
  for(let i=0;i<N;i++){ const a0=i/N*TAU, a1=(i+1)/N*TAU, x0=IX+Math.cos(a0)*R, z0=IZ+Math.sin(a0)*R, x1=IX+Math.cos(a1)*R, z1=IZ+Math.sin(a1)*R;
    CG.beam(A,x0,.45,z0,x1,.45,z1,1.1,"#cfd3d9",.9); }
  CG.disc(T,IX,.5,IZ,9.8,32,"#4aaee8"); CG.disc(A,IX,.05,IZ,10.2,32,"#9aa3ad");
  CG.cyl(A,IX,0,IZ,2.6,1.7,1.6,14,"#c9ccd2",true); CG.cyl(A,IX,1.6,IZ,3.6,.7,.9,16,"#d8dbe0",true); CG.cyl(A,IX,2.5,IZ,.9,.6,2.8,10,"#c9ccd2",true); CG.cyl(A,IX,5.3,IZ,2.4,.5,.6,14,"#d8dbe0",true); CG.ball(A,IX,6.3,IZ,.55,"#ffd23f",8);
  solid(IX,IZ,3.6,3.6,6.4);
  // su fışkırması: küçük damlalar
  const N2=64, geo=new THREE.SphereGeometry(.16,5,4), mat=new THREE.MeshStandardMaterial({color:0xcfefff,roughness:.2,metalness:.1,transparent:true,opacity:.8,emissive:0x2a6fa8,emissiveIntensity:.4});
  const im=new THREE.InstancedMesh(geo,mat,N2); im.frustumCulled=false; root.add(im); const o=new THREE.Object3D(), d=[]; for(let i=0;i<N2;i++) d.push({a:rnd()*TAU,ph:rnd(),sp:.35+rnd()*.25,r:2.8+rnd()*5.8,hh:3+rnd()*2.6});
  return {update(dt,t){ for(let i=0;i<N2;i++){ const e=d[i], p=((t*e.sp+e.ph)%1), x=IX+Math.cos(e.a)*e.r*p, z=IZ+Math.sin(e.a)*e.r*p, y=Math.max(.5,6.2+e.hh*4*p*(1-p)*1.4-p*p*5.8); o.position.set(x,y,z); o.scale.setScalar(.7+.5*(1-p)); o.updateMatrix(); im.setMatrixAt(i,o.matrix); } im.instanceMatrix.needsUpdate=true; }}; })();

/* ---------------- DÖNME DOLAP ---------------- */
const wheel=(function(){ const WX=700, WZ=-30, WR=23, WH=28, A=F(WX,WZ), g=new THREE.Group(); g.position.set(WX,WH,WZ); root.add(g);
  for(const zz of [-3.4,3.4]){ const z=WZ+zz;
    for(const s of [-1,1]){ CG.beam(A,WX+s*15.5,0,z,WX+s*1.3,WH-.4,z,.95,"#eef1f6",.95); CG.beam(A,WX+s*12,0,z,WX+s*.4,WH-3,z,.5,"#c9ced6",.5); }
    CG.beam(A,WX-15.5,2.2,z,WX+15.5,2.2,z,.45,"#aab0b8"); }
  CG.beam(A,WX,WH,WZ-4,WX,WH,WZ+4,.8,"#d63a3a"); fbox(A,WX-15.5,0,WZ,2.4,.5,9,"#8d939b"); fbox(A,WX+15.5,0,WZ,2.4,.5,9,"#8d939b");
  solid(WX-14,WZ,2.2,5.2,12); solid(WX+14,WZ,2.2,5.2,12); solid(WX,WZ,1.8,4.8,WH+2.2,WH-2.4);
  const rg=CG.rig(), bg=CG.rig(), N=32;
  for(const zz of [-2.6,2.6]){ for(let i=0;i<N;i++){ const a0=i/N*TAU, a1=(i+1)/N*TAU, c=i%2?"#ff5d8f":"#f4f6fa"; rg.bar(Math.cos(a0)*WR,Math.sin(a0)*WR,zz,Math.cos(a1)*WR,Math.sin(a1)*WR,zz,.55,c);
      bg.box(Math.cos(a0)*WR,Math.sin(a0)*WR,zz+(zz>0?.35:-.35),.34,.34,.34,BC[i%BC.length]); }
    for(let i=0;i<16;i++){ const a0=i/16*TAU, a1=(i+1)/16*TAU, r=WR*.46; rg.bar(Math.cos(a0)*r,Math.sin(a0)*r,zz,Math.cos(a1)*r,Math.sin(a1)*r,zz,.4,"#9fe7ff"); }
    for(let i=0;i<16;i++){ const a=i/16*TAU; rg.bar(0,0,zz,Math.cos(a)*WR,Math.sin(a)*WR,zz,.28,i%2?"#e8ecf2":"#c9ced6"); } }
  for(let i=0;i<N;i++){ const a=i/N*TAU; rg.bar(Math.cos(a)*WR,Math.sin(a)*WR,-2.6,Math.cos(a)*WR,Math.sin(a)*WR,2.6,.3,"#c9ced6"); }
  rg.cyl(0,0,0,1.5,1.5,6.4,12,"#d63a3a",{rx:Math.PI/2});
  for(let i=0;i<16;i++){ const a=i/16*TAU; bg.box(Math.cos(a)*WR*.46,Math.sin(a)*WR*.46,2.95,.3,.3,.3,BC[(i+3)%BC.length]); bg.box(Math.cos(a)*WR*.46,Math.sin(a)*WR*.46,-2.95,.3,.3,.3,BC[(i+3)%BC.length]); }
  const wm=rg.mesh(), wb=bg.mesh(bulbMat,{noShadow:true}); g.add(wm); g.add(wb);
  // gondollar
  const GC=["#e63946","#2a63c9","#ffd23f","#2e9d5a","#ff8a3c","#9b5de5"], gGeo=GC.map(c=>{ const r=CG.rig(); r.box(0,-1.9,0,3.0,1.7,2.4,c); r.box(0,-1.95,1.25,2.7,1.1,.1,"#bfe3ff"); r.box(0,-1.95,-1.25,2.7,1.1,.1,"#bfe3ff"); r.box(0,-.92,0,3.3,.28,2.7,"#f4f6fa"); r.box(0,-.4,0,.18,1.1,.18,"#c9ced6"); r.box(0,-2.8,0,2.8,.2,2.2,"#555a64"); r.box(1.55,-1.3,0,.08,.12,2.6,"#ffd23f"); r.box(-1.55,-1.3,0,.08,.12,2.6,"#ffd23f"); return r.geo(); });
  const gs=[]; for(let i=0;i<16;i++){ const a=i/16*TAU*1, gr=new THREE.Group(), m=new THREE.Mesh(gGeo[i%6],CG.rigMat); m.castShadow=true; m.receiveShadow=true; m.frustumCulled=false; gr.add(m); gr.position.set(Math.cos(i/16*TAU)*WR,Math.sin(i/16*TAU)*WR,0); g.add(gr); gs.push(gr); }
  let ang=0; return {x:WX,z:WZ,r:WR+3,update(dt){ ang-=dt*.11; g.rotation.z=ang; for(const q of gs) q.rotation.z=-ang; }}; })();

/* ---------------- ATLI KARINCA ---------------- */
const carousel=(function(){ const CX=650, CZ=-8, A=F(CX,CZ), g=new THREE.Group(); g.position.set(CX,.5,CZ); root.add(g);
  CG.cyl(A,CX,0,CZ,10,10,.5,24,"#e6dcc6",true); CG.cyl(A,CX,0,CZ,10.6,10.6,.25,24,"#a67c52",true); solid(CX,CZ,9.6,9.6,13,0);
  for(let i=0;i<8;i++){ const a=i/8*TAU+TAU/16; CG.ball(A,CX+Math.cos(a)*11.5,.8,CZ+Math.sin(a)*11.5,.9,"#2e8b3c",6,1.2); CG.cyl(A,CX+Math.cos(a)*11.5,0,CZ+Math.sin(a)*11.5,.5,.5,.5,6,"#a0522d"); }
  const r=CG.rig(), bg=CG.rig();
  r.cyl(0,.15,0,8.6,8.6,.3,24,"#9a5b3a"); r.cyl(0,.32,0,8.6,8.6,.06,24,"#d9a441",null,false); r.cyl(0,4.4,0,1.5,1.5,8.4,14,"#f4e3c3");
  for(let i=0;i<3;i++) r.cyl(0,1+i*3,0,1.6,1.6,.55,14,"#d63a3a");
  r.cyl(0,8.6,0,9.6,9.6,.7,28,"#ffd23f"); r.stripeCone(0,10.7,0,9.5,1.2,3.5,20,"#e63946","#f8f8f8"); r.ball(0,12.9,0,.85,.85,.85,"#ffd23f",8); r.box(0,14.3,0,.12,2.2,.12,"#c9ced6"); r.box(.6,14.9,0,1.2,.7,.05,"#e63946");
  for(let i=0;i<24;i++){ const a=i/24*TAU; bg.box(Math.cos(a)*9.6,8.1,Math.sin(a)*9.6,.3,.3,.3,BC[i%BC.length]); bg.box(Math.cos(a)*9.6,9.2,Math.sin(a)*9.6,.28,.28,.28,BC[(i+2)%BC.length]); }
  for(let i=0;i<8;i++){ const a=i/8*TAU, rr=7.6; r.box(Math.cos(a)*rr*.5,4.8,Math.sin(a)*rr*.5,.5,5,.05,["#ffe5a0","#ffc9de"][i&1],{ry:-a+Math.PI/2}); }
  g.add(r.mesh()); g.add(bg.mesh(bulbMat,{noShadow:true}));
  const HC=[["#f4f1ea","#e63946"],["#8a5a32","#2a63c9"],["#2b2b30","#ffd23f"],["#e8c27a","#9b5de5"],["#9aa1a8","#2e9d5a"],["#f5b6c8","#ff8a3c"]];
  const hGeo=HC.map(([c,sd])=>{ const h=CG.rig(), dk="#3a2a22";
    h.box(0,0,0,.72,.76,1.7,c); h.box(0,.5,.85,.4,.95,.42,c,{rx:-.55}); h.box(0,1.05,1.3,.34,.42,.78,c,{rx:.5}); h.box(-.1,1.38,1.0,.1,.22,.1,c); h.box(.1,1.38,1.0,.1,.22,.1,c);
    h.box(0,.82,.55,.12,.7,.4,dk,{rx:-.5}); h.box(0,.1,-.98,.14,.8,.2,dk,{rx:.4}); h.box(0,.47,0,.6,.1,.7,sd); h.box(0,.2,.45,.8,.06,.12,"#ffd23f");
    for(const sx of [-.23,.23]){ h.box(sx,-.55,-.62,.18,.78,.2,c); h.box(sx,-.45,.78,.18,.78,.2,c,{rx:-.7}); }
    h.box(0,3.6,0,.12,8.2,.12,"#ffd23f"); return h.geo(); });
  const hs=[]; const ring=(n,rr,off)=>{ for(let i=0;i<n;i++){ const a=i/n*TAU+off, gr=new THREE.Group(), m=new THREE.Mesh(hGeo[(i+(rr>5?0:2))%6],CG.rigMat); m.castShadow=true; m.frustumCulled=false; gr.add(m); gr.position.set(Math.cos(a)*rr,1.6,Math.sin(a)*rr); gr.rotation.y=-a; g.add(gr); hs.push({gr,a,b:0}); } };
  ring(10,6.4,0); ring(6,3.7,.3);
  return {x:CX,z:CZ,r:12,update(dt,t){ g.rotation.y+=dt*.55; for(const h of hs) h.gr.position.y=1.5+.6*(.5+.5*Math.sin(t*2.2+h.a*3)); }}; })();

/* ---------------- KORSAN GEMİSİ ---------------- */
const ship=(function(){ const SX=655, SZ=50, PH=15.5, LEN=12.5, A=F(SX,SZ), g=new THREE.Group(); g.position.set(SX,PH,SZ); root.add(g);
  for(const zz of [-4.4,4.4]){ const z=SZ+zz; for(const s of [-1,1]){ CG.beam(A,SX+s*9.5,0,z,SX+s*.5,PH+.4,z,.8,"#d94f4f",.8); fbox(A,SX+s*9.5,0,z,2,.4,2,"#8d939b"); } CG.beam(A,SX-9.5,3,z,SX+9.5,3,z,.3,"#c9ced6"); }
  CG.beam(A,SX,PH,SZ-5.2,SX,PH,SZ+5.2,.7,"#ffd23f"); solid(SX-9,SZ,1.6,5.6,7); solid(SX+9,SZ,1.6,5.6,7); solid(SX,SZ,1.2,5.6,PH+1.4,PH-1.6);
  fbox(A,SX,0,SZ,14,.3,7,"#bfa27a"); 
  const r=CG.rig(), bg=CG.rig();
  r.bar(0,0,-1.6,0,-LEN+1,-1.6,.22,"#ffd23f"); r.bar(0,0,1.6,0,-LEN+1,1.6,.22,"#ffd23f"); r.box(0,-.05,0,.3,.3,5.2,"#ffd23f");
  const hy=-LEN;                                   // gemi güvertesi merkezi
  r.box(0,hy-.7,0,12.2,1.0,3.6,"#6d3f22"); r.box(0,hy+.25,0,12.8,.9,4.3,"#8a5030"); r.box(0,hy+.78,0,12.8,.18,4.3,"#e8d9b8");
  r.box(7.0,hy+.7,0,3.2,.8,3.2,"#8a5030",{rz:.7}); r.box(-7.0,hy+.7,0,3.2,.8,3.2,"#8a5030",{rz:-.7});
  r.box(0,hy+1.05,2.1,12.6,.5,.14,"#e63946"); r.box(0,hy+1.05,-2.1,12.6,.5,.14,"#e63946");
  r.box(0,hy+.5,2.16,12.6,.12,.1,"#ffd23f"); r.box(0,hy+.5,-2.16,12.6,.12,.1,"#ffd23f");
  r.ball(8.5,hy+2.1,0,.75,.6,.6,"#2e9d5a",8); r.box(9.2,hy+1.9,0,.8,.28,.5,"#2e9d5a"); r.box(8.9,hy+2.45,.28,.12,.22,.12,"#fff"); r.box(8.9,hy+2.45,-.28,.12,.22,.12,"#fff");
  r.box(-8.2,hy+1.9,0,.4,1.8,1.4,"#ffd23f",{rz:.5});
  r.box(0,hy+3.0,0,.3,4.2,.3,"#5c4630"); r.box(0,hy+4.2,0,.1,.1,3.2,"#5c4630"); r.box(.6,hy+4.5,0,.05,1.9,3.0,"#f4f1ea");
  for(const sx of [-4,-1.4,1.4,4]){ r.box(sx,hy+1.12,0,.7,.14,3.2,"#f2d6a0"); r.box(sx,hy+1.45,.0,.14,.6,3.2,"#c0392b"); }
  for(let i=0;i<14;i++) bg.box(-6+i*.92,hy+1.35,2.2,.2,.2,.2,BC[i%BC.length]);
  for(let i=0;i<14;i++) bg.box(-6+i*.92,hy+1.35,-2.2,.2,.2,.2,BC[(i+3)%BC.length]);
  g.add(r.mesh()); g.add(bg.mesh(bulbMat,{noShadow:true}));
  return {x:SX,z:SZ,r:12,update(dt,t){ const e=Math.pow(Math.sin(Math.PI*((t%44)/44)),2); g.rotation.z=e*.98*Math.sin(t*.92); }}; })();

/* ---------------- HIZ TRENİ ---------------- */
const coaster=(function(){ const CX=767, CZ=17, A=F(CX,CZ);
  const CP=[[-18,9,1.4],[-18,2,1.4],[-18,-8,1.6],[-17,-16,7],[-11,-20,17],[-3,-20,26],[6,-18,14],[13,-14,3],[19,-6,11],[20,4,15],[17,13,6],[10,17,2.5],[2,19,10],[-6,17,12],[-13,14,5],[-18,11,2]];
  const n=CP.length, cr=(p0,p1,p2,p3,t)=>.5*((2*p1)+(-p0+p2)*t+(2*p0-5*p1+4*p2-p3)*t*t+(-p0+3*p1-3*p2+p3)*t*t*t);
  const dense=[], cpIdx=[]; for(let i=0;i<n;i++){ cpIdx.push(dense.length); const p0=CP[(i+n-1)%n],p1=CP[i],p2=CP[(i+1)%n],p3=CP[(i+2)%n]; for(let k=0;k<40;k++){ const t=k/40; dense.push([CX+cr(p0[0],p1[0],p2[0],p3[0],t),Math.max(1.2,cr(p0[2],p1[2],p2[2],p3[2],t)),CZ+cr(p0[1],p1[1],p2[1],p3[1],t)]); } }
  const cum=[0]; for(let i=1;i<=dense.length;i++){ const a=dense[i-1], b=dense[i%dense.length]; cum.push(cum[i-1]+Math.hypot(b[0]-a[0],b[1]-a[1],b[2]-a[2])); }
  const TOT=cum[dense.length], SP=1.5, M=Math.round(TOT/SP), S=[], dS=TOT/M;
  let j=0; for(let i=0;i<M;i++){ const s=i*dS; while(cum[j+1]<s) j++; const f=(s-cum[j])/(cum[j+1]-cum[j]||1), a=dense[j], b=dense[(j+1)%dense.length]; S.push([a[0]+(b[0]-a[0])*f,a[1]+(b[1]-a[1])*f,a[2]+(b[2]-a[2])*f]); }
  const cpS=cpIdx.map(i=>cum[i]);
  const at=(s)=>{ s=((s%TOT)+TOT)%TOT; const f=s/dS, i=Math.floor(f)%M, t=f-Math.floor(f), a=S[i], b=S[(i+1)%M]; return [a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t,a[2]+(b[2]-a[2])*t]; };
  // raylar
  for(let i=0;i<M;i++){ const a=S[i], b=S[(i+1)%M], dx=b[0]-a[0], dz=b[2]-a[2], hl=Math.hypot(dx,dz)||1, nx=-dz/hl, nz=dx/hl, AA=F(a[0],a[2]);
    CG.beam(AA,a[0],a[1]-.5,a[2],b[0],b[1]-.5,b[2],.34,"#d63a3a",.36);
    for(const s of [-1,1]) CG.beam(AA,a[0]+nx*.68*s,a[1],a[2]+nz*.68*s,b[0]+nx*.68*s,b[1],b[2]+nz*.68*s,.15,"#e8ecf2",.15);
    if(i%2===0) CG.beam(AA,a[0]+nx*.7,a[1]-.2,a[2]+nz*.7,a[0]-nx*.7,a[1]-.2,a[2]-nz*.7,.12,"#8a8f98",.1);
    if(s2(i)&&a[1]>2.2){ fbox(AA,a[0],0,a[2],.5,a[1]-.7,.5,"#f4f4f4"); if(a[1]>7){ CG.beam(AA,a[0]+nx*1.6,0,a[2]+nz*1.6,a[0],a[1]-.7,a[2],.3,"#d9dde2"); CG.beam(AA,a[0]-nx*1.6,0,a[2]-nz*1.6,a[0],a[1]-.7,a[2],.3,"#d9dde2"); solid(a[0],a[2],.9,.9,a[1]-.5); } fbox(AA,a[0],0,a[2],1.1,.2,1.1,"#8d939b"); } }
  function s2(i){ return i%5===0; }
  // lift zinciri
  { const i0=Math.round(cpS[2]/dS), i1=Math.round(cpS[5]/dS); for(let i=i0;i<i1;i++){ const a=S[i], b=S[i+1], AA=F(a[0],a[2]); CG.beam(AA,a[0],a[1]-.14,a[2],b[0],b[1]-.14,b[2],.14,"#2a2d33",.1); } }
  // istasyon
  { const x=CX-18, A2=F(x,CZ); fbox(A2,x,0,CZ,10,.4,19,"#9aa0a8"); fbox(A2,x,.4,CZ-.0,.05,.02,19,"#ffd23f");
    for(const sx of [-4.4,4.4]) for(const sz of [-9,9]) fbox(A2,x+sx,.4,CZ+sz,.5,4.4,.5,"#e0407a");
    fbox(A2,x,4.8,CZ,11,.35,20,"#e0407a"); fbox(A2,x,5.15,CZ,9,.3,18,"#ffd23f");
    for(let k=0;k<=18;k+=2) bulb(x-5.6,4.65,CZ-9+k,BC[k%6],.3);
    CG.sign("SUPER COASTER",10,2,"#e0407a","#fff",x-5.7,6.9,CZ,-Math.PI/2); }
  // vagonlar
  const CC=["#e63946","#ffd23f","#2a63c9","#2e9d5a"], cars=[], carGeo=CC.map((c,k)=>{ const r=CG.rig(); r.box(0,.28,0,1.6,.5,2.5,c); r.box(0,.62,1.0,1.5,.3,.7,"#f4f6fa"); r.box(0,.95,-.6,1.4,.8,.2,c); r.box(0,.82,.2,1.4,.18,.9,"#2a2d33"); r.box(0,1.0,.55,1.2,.1,.1,"#c9ced6");
    for(const sx of [-.82,.82]){ r.box(sx,.05,-.8,.12,.4,.4,"#2a2d33"); r.box(sx,.05,.8,.12,.4,.4,"#2a2d33"); }
    if(k===0){ r.box(0,.4,1.45,1.3,.45,.5,c,{rx:.35}); r.box(0,.55,1.7,1.0,.2,.3,"#f4f6fa"); } return r.geo(); });
  for(let i=0;i<4;i++){ const m=new THREE.Mesh(carGeo[i],CG.rigMat); m.castShadow=true; m.frustumCulled=false; m.rotation.order="YXZ"; root.add(m); cars.push(m); }
  let s=cpS[2]-2, v=4.2; const g=9.8, HP=26;
  const place=(m,ss)=>{ const p=at(ss), q=at(ss+.9), r=at(ss-.9), dx=q[0]-r[0], dy=q[1]-r[1], dz=q[2]-r[2]; m.position.set(p[0],p[1]+.3,p[2]); m.rotation.y=Math.atan2(dx,dz); m.rotation.x=-Math.atan2(dy,Math.hypot(dx,dz)); };
  function speed(ss){ const p=at(ss), ph=((ss%TOT)+TOT)%TOT; if(ph<cpS[5]) return 4.4; let ve=Math.sqrt(Math.max(0,2*g*.5*(HP-p[1]))+9); ve=Math.max(5.5,ve); if(ph>cpS[13]) ve=Math.min(ve,4.4+(TOT-ph)*.55); return Math.max(4.4,ve); }
  return {x:CX,z:CZ,r:30,update(dt){ s+=speed(s)*dt; if(s>=TOT) s-=TOT; for(let i=0;i<4;i++) place(cars[i],s-i*2.9); }}; })();

/* ---------------- SERBEST DÜŞÜŞ KULESİ ---------------- */
const drop=(function(){ const DX=768, DZ=-34, TH=54, A=F(DX,DZ);
  for(const sx of [-1.8,1.8]) for(const sz of [-1.8,1.8]){ fbox(A,DX+sx,0,DZ+sz,.55,TH,.55,"#eef0f4"); }
  for(let y=6;y<TH;y+=6){ for(const s of [-1.8,1.8]){ fbox(A,DX,y,DZ+s,3.6,.28,.28,"#d63a3a"); fbox(A,DX+s,y,DZ,.28,.28,3.6,"#d63a3a"); } }
  fbox(A,DX,0,DZ,10,.6,10,"#555a64"); fbox(A,DX,.6,DZ,4,.35,4,"#ffd23f"); fbox(A,DX,TH,DZ,5.4,2.6,5.4,"#d63a3a"); fbox(A,DX,TH+2.6,DZ,3,.8,3,"#ffd23f"); fbox(A,DX,TH+3.4,DZ,.25,6,.25,"#c9ced6");
  solid(DX,DZ,2.8,2.8,TH+3);
  for(const s of [0,1,2,3]){ const a=s*Math.PI/2, x=DX+Math.sin(a)*2.75, z=DZ+Math.cos(a)*2.75; CG.sign("DROP",4.4,1.5,"#1a1d3a","#ffd23f",x,TH+1.3,z,a); }
  const bg=CG.rig(); for(let y=3;y<TH;y+=3) for(const sx of [-2.1,2.1]) for(const sz of [-2.1,2.1]) bg.box(DX+sx,y,DZ+sz,.3,.3,.3,BC[(y/3|0)%6]); bg.box(DX,TH+9.6,DZ,.5,.5,.5,"#ff2a2a"); const bm=bg.mesh(bulbMat,{noShadow:true}); root.add(bm);
  const r=CG.rig(); for(const s of [-1,1]){ r.box(0,0,s*3,6.6,.4,.4,"#f2c14e"); r.box(s*3,0,0,.4,.4,6.6,"#f2c14e"); }
  for(let k=0;k<4;k++){ const a=k*Math.PI/2, ox=Math.sin(a), oz=Math.cos(a); for(const dd of [-1.1,0,1.1]){ const px=ox*2.3+oz*dd, pz=oz*2.3-ox*dd; r.box(px,.35,pz,.8,.2,.8,"#d63a3a",{ry:a}); r.box(ox*2.65+oz*dd,.85,oz*2.65-ox*dd,.8,.9,.12,"#d63a3a",{ry:a}); r.box(px,-.35,pz,.3,.8,.3,"#2a63c9"); r.box(ox*1.95+oz*dd,.55,oz*1.95-ox*dd,.5,.1,.5,"#c9ced6"); } }
  const gm=r.mesh(); gm.position.set(DX,2.5,DZ); root.add(gm);
  let t=0; const Y0=2.4, Y1=47.5, G=9.8, yF=14, vF=Math.sqrt(2*G*(Y1-yF)), tF=vF/G, aB=vF*vF/(2*(yF-Y0)), tB=vF/aB;
  const T1=3, T2=10, T3=2.4, T4=tF, T5=tB, T6=3, TT=T1+T2+T3+T4+T5+T6;
  return {x:DX,z:DZ,r:12,update(dt){ t=(t+dt)%TT; let y=Y0, q=t;
    if(q<T1) y=Y0; else if((q-=T1)<T2){ const k=q/T2, e=k*k*(3-2*k); y=Y0+(Y1-Y0)*e; } else if((q-=T2)<T3) y=Y1+Math.sin(q*9)*.12; else if((q-=T3)<T4){ y=Y1-.5*G*q*q; } else if((q-=T4)<T5){ y=yF-vF*q+.5*aB*q*q; } else y=Y0;
    gm.position.y=Math.max(Y0,y); }}; })();

/* ---------------- DÜKKÂNLAR (yıkılabilir) ---------------- */
function stall(x,z,face,txt,tint,rc,sbg,sfg,kind){ const bl=CG.bl(), s=face===0?1:-1, zz=z+s*(2.5+.4+.07);
  const t=CG.tier(bl,{x,z,w:6.4,d:5,y0:0,h:4,LH:4,T:.4,style:"s",tint,kind:kind||"shop",door:face,doorW:2.4,ic:"#fff3e0",fc:"#caa27a",cc:"#fffaf0",roof:"hip",roofCol:rc,rh:2.2,
    doorDeco:(A2,p,tt,dg)=>CG.canopy(A2,p,dg,rc,3.35),
    props:(top,A2)=>{ pbox(A2,x-2.9,4.3,zz,.14,1.6,.14,"#d9d9de"); pbox(A2,x+2.9,4.3,zz,.14,1.6,.14,"#d9d9de"); return top; }});
  if(t.prop) CG.attach(t.prop,CG.sign(txt,5.4,1.15,sbg,sfg,x,5.1,zz,face===0?0:Math.PI));
  CG.lamp(x+3.8,z+s*3.4,0,s);
  return t; }
const ST=[["TICKETS","#ffe08a","#e63946","#a21c28","#fff","shop"],["ICE CREAM","#ffd6e8","#ff5d8f","#ff5d8f","#fff","shop"],["POPCORN","#fff3c4","#ffb703","#d62828","#fff","shop"],["CANDY","#e6d5ff","#9b5de5","#7b3fc4","#fff","shop"],
  ["BURGER","#ffd8b0","#d62828","#b5651d","#fff","shop"],["PIZZA","#ffe1c4","#2e9d5a","#2e9d5a","#fff","shop"],["TOYS","#cfe8ff","#2a63c9","#2a63c9","#ffd23f","shop"],["ARCADE","#d8d0ff","#1a1d3a","#1a1d3a","#7dff7a","arcade"],["DONUTS","#ffd1dc","#e0407a","#e0407a","#fff","shop"],["HOT DOG","#ffe9b0","#e63946","#e63946","#ffd23f","shop"],["GAMES","#d0f5e8","#00a896","#00a896","#fff","arcade"],["LEMONADE","#fff6a8","#ffd23f","#e9a800","#fff","shop"]];
{ const north=[618,626,634,642,662,670,678,722,730], south=[618,626,634,642,664,672,680,722,730]; let k=0;
  north.forEach(x=>{ const d=ST[k++%ST.length]; stall(x,IZ-7.5,0,d[0],d[1],d[2],d[3],d[4],d[5]); });
  south.forEach(x=>{ const d=ST[k++%ST.length]; stall(x,IZ+7.5,2,d[0],d[1],d[2],d[3],d[4],d[5]); }); }

/* ---------------- ÇARPIŞAN ARABALAR SALONU ve KORKU EVİ ---------------- */
{ const bx=700, bz=64, bl=CG.bl(); const A=F(bx,bz); fbox(A,bx,0,bz,32,.08,26,"#9aa0a8");
  const t=CG.tier(bl,{x:bx,z:bz,w:26,d:18,y0:0,h:8,LH:8,style:"s",tint:"#ffd9a0",kind:"arcade",door:2,doorW:6,ic:"#2a2d5c",fc:"#7a4bd6",cc:"#1a1d3a",roof:"flat",slabCol:"#e0407a",
    doorDeco:(A2,p,tt,dg)=>CG.canopy(A2,p,dg,"#e0407a",3.8),
    props:(top,A2)=>{ for(let i=-3;i<=3;i++) pbox(A2,bx+i*3.4,top+.3,bz+9.2,1.1,2.4+(i&1)*1.3,.5,["#ff5d8f","#ffd23f","#5de0ff","#7dff7a"][(i+3)&3]); pbox(A2,bx,top+.4,bz,20,.8,.6,"#ffd23f"); return top+1; }});
  CG.doorSign(t,"BUMPER CARS",9,1.7,"#e0407a","#fff",5.6);
  if(t.prop) CG.attach(t.prop,CG.sign("BUMPER CARS",14,3,"#1a1d3a","#ffd23f",bx,12.6,bz-9.4,Math.PI));
  CG.lamp(bx-10,bz-10.5,0,-1); CG.lamp(bx+10,bz-10.5,0,-1); }
{ const hx=745, hz=54, bl=CG.bl(); const A=F(hx,hz); fbox(A,hx,0,hz,24,.07,22,"#6a6f78");
  const t=CG.tier(bl,{x:hx,z:hz,w:16,d:13,y0:0,h:12,LH:6,style:"w",tint:"#8c7aa6",kind:"haunted",door:2,doorW:3.6,ic:"#2c2438",fc:"#3a2f2a",cc:"#1d1824",roof:"gable",roofCol:"#2b2233",rh:6,
    doorDeco:(A2,p,tt,dg)=>CG.canopy(A2,p,dg,"#4b2c6b",3.5)});
  CG.doorSign(t,"HAUNTED",6.4,1.3,"#1d1824","#7dff7a",5.4);
  const t2=CG.tier(bl,{x:hx+5,z:hz+1,w:5,d:5,y0:12,h:6,LH:6,style:"w",tint:"#7a6896",kind:"haunted",ic:"#2c2438",fc:"#3a2f2a",roof:"hip",roofCol:"#2b2233",rh:5});
  for(let i=0;i<6;i++) CG.tree(hx-11+(i&1)*22,hz-8+i*3.2,.8,1);
  for(const sx of [-1,1]) for(let k=0;k<4;k++) fbox(A,hx+sx*8.4,0,hz-9+k*2.8,.18,1.5,.18,"#2a2d33");
  for(let k=0;k<6;k++){ bulb(hx-6+k*2.4,3.6,hz-6.6,"#7dff7a",.3); } }

/* ---------------- SÜSLER: ağaçlar, lambalar, banklar, balonlar, ışık çelenkleri ---------------- */
for(const x of [626,646,666,726,742]) for(const s of [-1,1]){ CG.lamp(x,IZ+s*5.6,0,-s); }
for(let i=0;i<22;i++){ const a=i/22*TAU, r=94+rnd()*3; const x=IX+Math.cos(a)*r, z=IZ+Math.sin(a)*r; if(W.terrainH(x,z)>=0) (i%3===0?CG.tree(x,z,1.05,0):CG.palm(x,z)); }
for(const [x,z] of [[640,-26],[690,-18],[716,-8],[670,28],[690,40],[716,36],[612,40],[612,-6],[770,-12],[790,58],[720,86],[672,84],[634,64],[626,-30],[746,-22]]){ if(Math.hypot(x-IX,z-IZ)<96) CG.palm(x,z); }
for(const x of [650,676,724,736]) for(const s of [-1,1]){ const A=F(x,IZ+s*4.4); fbox(A,x,.07,IZ+s*4.4,1.8,.1,.55,"#8a5030"); fbox(A,x,.5,IZ+s*4.8,1.8,.6,.12,"#8a5030"); fbox(A,x-.8,.07,IZ+s*4.4,.12,.45,.5,"#3b3f46"); fbox(A,x+.8,.07,IZ+s*4.4,.12,.45,.5,"#3b3f46"); }
// balon demetleri
for(const [bx,bz] of [[640,IZ+3],[716,IZ-3.4],[684,IZ-4]]){ const A=F(bx,bz); fbox(A,bx,0,bz,.15,2.2,.15,"#cccccc"); for(let k=0;k<9;k++){ const a=k/9*TAU, rr=.6+(k%3)*.45, h=3.4+(k%4)*.55; CG.ball(A,bx+Math.cos(a)*rr,h,bz+Math.sin(a)*rr,.5,["#ff3b5c","#ffd23f","#3b8cff","#4be07a","#b36bff"][k%5],8,1.2); fbox(A,bx+Math.cos(a)*rr*.5,2.2,bz+Math.sin(a)*rr*.5,.03,h-2.7,.03,"#ddd"); } }
// ışık çelenkleri (festoon)
for(const x of [626,646,666,726]){ for(const s of [-1,1]){ const A=F(x,IZ+s*5.6); fbox(A,x,0,IZ+s*5.6,.22,9,.22,"#3b4047"); }
  for(let i=0;i<=14;i++){ const t=i/14, z=IZ-5.6+11.2*t, y=9-1.4*4*t*(1-t); bulb(x,y,z,BC[(i+((x/10)|0))%6],.3); } }
for(let i=0;i<=40;i++){ const t=i/40; bulb(646+t*80-0,8.6+Math.sin(t*TAU*4)*.15,IZ-5.6,BC[i%6],.26); }
{ const bm=bulbs.mesh(bulbMat,{noShadow:true}); root.add(bm); }

/* ---------------- ANİMASYON GÜNCELLEMESİ ---------------- */
const rides=[fountain,wheel,carousel,ship,coaster,drop]; Game.rides=rides;
Game.updaters.push((dt,time)=>{ const cam=camera.position; if(Math.hypot(cam.x-IX,cam.z-IZ)>420&&cam.y<900) return;
  const nt=Game.night||0; bulbMat.color.setScalar(.75+nt*2.6);
  for(const r of rides) r.update(dt,time); });
})();
