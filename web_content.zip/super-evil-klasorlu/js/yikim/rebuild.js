"use strict";
/* ===== YENİDEN İNŞA: yıkılan bina, oyuncu uzaklaşınca bir süre sonra kat kat yeniden yükselir ===== */
Game.Rebuild=(function(){
  const D=Game.D, Ev=Game.Ev, TICK=.22;
  const touched=new Map(), jobs=[], api={delay:150,far:165,stats:{done:0,chunks:0},touched,jobs};
  let tm=0, acc=0, scan=0;
  const total=bl=>{ if(bl.tot===undefined){ let n=0; for(const t of bl.tiers) n+=t.chunks.length; bl.tot=n; } return bl.tot; };
  const mark=c=>{ const bl=c.t&&c.t.bl; if(!bl) return; touched.set(bl,tm); bl.dead=(bl.dead||0); };
  /* her yıkımı say: %55'i gidince "bina yıkıldı" olayı (bir kez) */
  function counted(c){ const bl=c.t&&c.t.bl; if(!bl) return; bl.dead=(bl.dead||0)+1; const T=total(bl); if(!bl.paid&&T>0&&bl.dead/T>=.55){ bl.paid=true; const e=bl.tiers[0]&&bl.tiers[0].entry; Ev.emit("building",bl,c.x,c.z); } }
  for(const nm of ["kill","killSilent","startFall"]){ const o=D[nm]; D[nm]=function(c){ const was=c&&c.alive; const r=o.apply(this,arguments); if(was&&c&&!c.alive){ mark(c); counted(c); } return r; }; }
  const order=bl=>{ const gs=new Map(); bl.tiers.forEach((t,ti)=>{ for(const c of t.chunks){ const L=c===t.prop?9999:(c.L||0), key=ti*10000+L; let a=gs.get(key); if(!a) gs.set(key,a=[]); a.push(c); } });
    return [...gs.keys()].sort((a,b)=>a-b).map(k=>gs.get(k)); };
  const hero=()=>Game.heroObj?Game.heroObj.position:null;
  function farFrom(bl){ const h=hero(), c=camera.position; const t0=bl.tiers[0]; if(!t0) return false; const x=t0.x, z=t0.z;
    if(h&&Math.hypot(h.x-x,h.z-z)<api.far&&h.y<900) return false; if(Math.hypot(c.x-x,c.z-z)<api.far*.9&&c.y<900) return false; return true; }
  function heroInside(cs){ const h=hero(); if(!h) return false; for(const c of cs){ const b=c.bx; if(!b) continue; for(let k=0;k<b.length;k+=6) if(h.x>b[k]-2.2&&h.x<b[k+3]+2.2&&h.z>b[k+2]-2.2&&h.z<b[k+5]+2.2&&h.y>b[k+1]-3&&h.y<b[k+4]+3) return true; } return false; }
  function busy(bl){ for(const t of bl.tiers) for(const c of t.chunks) if(c.fall||c.pend>=0) return true; return false; }
  api.start=function(bl){ if(!bl||jobs.some(j=>j.bl===bl)) return; touched.delete(bl); jobs.push({bl,groups:order(bl),gi:0,w:0}); };
  api.step=function(dt){ tm+=dt; scan-=dt; acc-=dt;
    if(scan<=0){ scan=1.2; if(Game.mode==="play") for(const [bl,last] of touched){ if(tm-last>api.delay&&farFrom(bl)&&jobs.length<4) api.start(bl); } }
    if(acc>0) return; acc=TICK;
    for(let k=jobs.length-1;k>=0;k--){ const j=jobs[k]; if(!farFrom(j.bl)){ j.w+=TICK; if(j.w>40){ touched.set(j.bl,tm); jobs.splice(k,1); } continue; } j.w=0;
      if(busy(j.bl)) continue; let g=j.groups[j.gi]; while(g&&g.every(c=>c.alive)) g=j.groups[++j.gi];
      if(!g){ jobs.splice(k,1); const bl=j.bl; bl.dead=0; bl.paid=false; api.stats.done++; Ev.emit("rebuilt",bl); D.dirty.add(bl.tiers[0]&&bl.tiers[0].bl); continue; }
      if(heroInside(g)) continue; let n=0; for(const c of g){ if(!c.alive&&D.revive(c)) n++; } api.stats.chunks+=n; } };
  Game.updaters.push(dt=>{ if(Game.mode==="play") api.step(Math.min(dt,.1)); });
  return api; })();
