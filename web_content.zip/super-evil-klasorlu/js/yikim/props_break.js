"use strict";
/* ===== KIRILABİLİR EŞYALAR: posta kutusu, çit, çalı, kütük yığını, bank, çöp kutusu, yangın musluğu, lamba, trafik ışığı, kaya, reklam panosu.
   Eşyalar tür başına döşemeli (tile) örnekli meshlerde çizilir; kırılınca örnek sıfır ölçeğe çekilir, enkaz + toz + ses çıkar (yeniden inşada geri gelir).
   Hasar kaynakları: D.damageSphere (tüm güçler/yumruk/araç çarpması), kahraman ve araç teması (hız → güç). ===== */
Game.Props=(function(){
const CG=Game.CG, L=CG.lists, D=Game.D, FX=Game.FX, C=CG.C, TAU=Math.PI*2;
const api={list:[],kinds:{},total:0,broken:0,hits:0};
const ZERO16=new Float32Array(16); ZERO16[15]=1;

/* ---------- tür tanımları: hp = kırmak için gereken en az güç (D.damageSphere'deki amt ile aynı ölçek); hx/hy/hz = yerel yarı boyut; deb = enkaz rengi ---------- */
const rig=()=>CG.rig();
const KITS={
 mailbox:{hp:.35,hx:.26,hy:.76,hz:.22,deb:"#8a8f98",tint:true,snd:.14,geo(){ const r=rig(); r.box(0,.55,0,.1,1.1,.1,"#5c5c5c"); r.box(0,1.34,0,.45,.3,.3,"#ffffff"); r.box(.17,1.5,.19,.04,.24,.03,"#ff4a3a"); return r.geo(); }},
 fence:{hp:.5,hx:1.2,hy:.56,hz:.12,deb:"#d8d4c8",tint:true,snd:.12,geo(){ const r=rig(); r.box(0,.5,0,2.4,.07,.07,"#ffffff"); r.box(0,.9,0,2.4,.07,.07,"#ffffff"); r.box(-1.2,.5,0,.1,1.0,.1,"#ffffff"); r.box(1.2,.5,0,.1,1.0,.1,"#ffffff"); return r.geo(); }},
 hedge:{hp:1.0,hx:.5,hy:.48,hz:.5,deb:"#3f8f3a",tint:true,scaled:true,snd:.1,geo(){ const r=rig(); r.box(0,.5,0,1,1,1,"#ffffff"); return r.geo(); }},
 woodpile:{hp:.7,hx:1.1,hy:.5,hz:.45,deb:"#8a5a33",snd:.16,geo(){ const r=rig(); r.box(0,.375,0,2.2,.75,.9,"#8a5a33"); r.box(0,.97,0,1.98,.2,.81,"#a06d3f"); return r.geo(); }},
 bench:{hp:.8,hx:.95,hy:.45,hz:.3,deb:"#7a4f2a",snd:.22,body:true,geo(){ const r=rig(); r.box(0,.42,0,1.8,.08,.5,"#7a4f2a"); r.box(0,.74,-.22,1.8,.42,.06,"#6f4724"); r.box(-.75,.2,0,.08,.4,.42,"#3a3d44"); r.box(.75,.2,0,.08,.4,.42,"#3a3d44"); return r.geo(); }},
 bin:{hp:.45,hx:.34,hy:.48,hz:.34,deb:"#3f6b4a",snd:.16,geo(){ const r=rig(); r.cyl(0,.45,0,.3,.34,.9,8,"#3f6b4a"); r.cyl(0,.93,0,.36,.36,.07,8,"#2d3a32"); return r.geo(); }},
 can:{hp:.08,hx:.08,hy:.08,hz:.08,deb:"#c0392b",tint:true,tiny:true,snd:.04,geo(){ const r=rig(); r.cyl(0,.065,0,.04,.04,.13,6,"#ffffff"); r.cyl(0,.135,0,.032,.032,.01,6,"#c8ccd2"); return r.geo(); }},
 bottle:{hp:.08,hx:.14,hy:.05,hz:.05,deb:"#7fc4d6",tint:true,tiny:true,snd:.04,geo(){ const r=rig(); r.cyl(0,.04,0,.035,.035,.1,6,"#ffffff",{rz:Math.PI/2}); r.cyl(.1,.04,0,.015,.015,.07,6,"#ffffff",{rz:Math.PI/2}); return r.geo(); }},
 bag:{hp:.08,hx:.16,hy:.1,hz:.12,deb:"#e9ecef",tint:true,tiny:true,snd:.04,geo(){ const r=rig(); r.ball(0,.08,0,.16,.09,.12,"#ffffff",6); r.ball(.12,.05,.05,.07,.04,.05,"#ffffff",5); return r.geo(); }},
 paper:{hp:.06,hx:.16,hy:.02,hz:.12,deb:"#f3efe4",tint:true,tiny:true,snd:.03,geo(){ const r=rig(); r.box(0,.012,0,.3,.012,.22,"#ffffff",{ry:.4}); r.box(.14,.03,.08,.16,.012,.12,"#ffffff",{ry:-.6,rz:.25}); return r.geo(); }},
 hydrant:{hp:1.0,hx:.24,hy:.46,hz:.24,deb:"#c0281f",snd:.2,jet:true,geo(){ const r=rig(); r.cyl(0,.34,0,.2,.17,.68,8,"#c0281f"); r.cyl(0,.76,0,.21,.21,.1,8,"#a81f18"); r.ball(0,.86,0,.16,.12,.16,"#c0281f",6); r.box(-.23,.5,0,.14,.12,.12,"#d9d9d9"); r.box(.23,.5,0,.14,.12,.12,"#d9d9d9"); return r.geo(); }},
};
const KC={}; for(const k in KITS){ KITS[k].dc=C(KITS[k].deb); }
const GRID=new Map(), CS=16, gk=(ix,iz)=>(ix+4096)*8192+(iz+4096);
function cellAdd(p){ const k=gk(Math.floor(p.x/CS),Math.floor(p.z/CS)); let a=GRID.get(k); if(!a){ a=[]; GRID.set(k,a); } a.push(p); }

/* ---------- kayıt ---------- */
function reg(kind,x,y,z,ry,hx,hy,hz,hp,parts,extra){ const p={kind,x,y,z,ry,hx,hy,hz,hp,parts,alive:true,saved:null,deb:extra&&extra.deb||KITS.bin.dc,snd:extra&&extra.snd||.2,body:extra&&extra.body||null,jet:extra&&extra.jet||false,msh:extra&&extra.msh||null,big:extra&&extra.big||0,tiny:extra&&extra.tiny||false,cs:Math.cos(ry),sn:Math.sin(ry)};
  api.list.push(p); api.total++; api.kinds[kind]=(api.kinds[kind]||0)+1; cellAdd(p); return p; }
const bl=Game.buildings||[];
const inBuilding=(x,z,pad)=>{ for(const e of bl){ if(!e||e.h<=0) continue; if(Math.abs(x-e.x)<e.hw+pad&&Math.abs(z-e.z)<e.hd+pad) return true; } return false; };

/* 1) döşemeli örnekli türler (CG.prop ile üretimde kaydedilenler) */
/* güvenlik ağı: yer donanımı/çöp asfalta düştüyse hiç yerleştirme (kaynakta düzeltilenlerin ötesinde, ileride eklenecek yerleşimleri de korur) */
const SPILL={hedge:.5,bin:.4,hydrant:.4,can:.2,bottle:.2,bag:.2,paper:.2,mailbox:.4,woodpile:.6,bench:.9};
{ const by={}; for(const q of L.props){ if(inBuilding(q.x,q.z,.5)) continue; const sm=SPILL[q.k]; if(sm&&Game.onAsphalt&&Game.onAsphalt(q.x,q.z,sm)) continue; (by[q.k]||(by[q.k]=[])).push(q); }
  for(const k in by){ const K=KITS[k]; if(!K) continue; const list=by[k], white=C("#ffffff");
    const H=CG.tiled(K.geo(),CG.rigMat,list,(o,q)=>{ o.position.set(q.x,q.y,q.z); o.rotation.y=q.ry; if(K.scaled) o.scale.set(q.sx,q.sy,q.sz); else o.scale.set(q.sx,1,1); return K.tint?(q.col?C(q.col):white):null; },true,undefined,1);
    list.forEach((q,i)=>{ let hx,hy,hz; if(K.scaled){ hx=.5*q.sx; hy=.5*q.sy; hz=.5*q.sz; } else { hx=K.hx*q.sx; hy=K.hy; hz=K.hz; }
      const p=reg(k,q.x,q.y,q.z,q.ry,hx,hy,hz,K.hp,[H.at[i]],{deb:q.col&&K.tint?C(q.col):K.dc,snd:K.snd,body:K.body?{sx:Math.max(.4,hx*2),sy:hy*2,sz:Math.max(.4,hz*2)}:null,jet:K.jet,tiny:K.tiny}); p.cy=q.y+hy; }); } }

/* 2) sokak lambaları, trafik ışıkları, kayalar: mevcut döşeme tutacaklarından */
const H=CG.H||{};
if(H.lamp){ const lamps=L.lamps; lamps.forEach((l,i)=>{ const parts=[H.lamp.at[i],H.bulb&&H.bulb.at[i]].filter(Boolean); const p=reg("lamp",l[0],0,l[1],Math.atan2(l[2],l[3]),.5,3.9,.5,1.15,parts,{deb:C("#4d535b"),snd:.45,body:{sx:.3,sy:7.6,sz:.3},big:1}); p.cy=3.9; }); }
if(H.tpole){ const tl=L.tlights; tl.forEach((l,k)=>{ const parts=[H.tpole.at[k]]; if(H.heads){ for(const j of [2*k,2*k+1]){ parts.push(H.heads.at[j]); if(H.lens) for(let n=0;n<3;n++) parts.push(H.lens.at[j*3+n]); } }
  const p=reg("tlight",l[0],0,l[1],0,.55,3.0,.55,1.15,parts.filter(Boolean),{deb:C("#3b4047"),snd:.4,body:{sx:.28,sy:6,sz:.28},big:1}); p.cy=3.0; }); }
if(H.rock){ L.rocks.forEach((r,i)=>{ const s=r[2], g=Game.W.terrainH(r[0],r[1]); const p=reg("rock",r[0],g,r[1],0,1.3*s,.8*s,1.3*s,2.4,[H.rock.at[i]],{deb:C("#8a847c"),snd:.5,big:1}); p.cy=g+.4*s; }); }

/* palmiyeler: gövde + 8 yaprak + (yarısında) hindistan cevizi örnek indeksleri */
{ const PDt=CG.palmData; if(PDt){ PDt.PD.forEach((d,k)=>{ const parts=[[PDt.trunk,k]]; for(let i=0;i<8;i++) parts.push([PDt.frond,k*8+i]); if(k%2===0&&PDt.coco) parts.push([PDt.coco,k>>1]);
    const p=reg("palm",d.x+d.dx*d.H*.5,d.y,d.z+d.dz*d.H*.5,0,.55,d.H*.5,.55,1.1,parts,{deb:C("#8a6a45"),snd:.4,body:{sx:.5,sy:d.H*.9,sz:.5},big:1}); p.cy=d.y+d.H*.5; }); } }
/* 3) bağımsız mesh grupları: sokak reklam panoları (billboards.js CG.lists.propMeshes'e yazar) */
for(const g of L.propMeshes||[]){ const p=reg(g.kind||"ad",g.x,g.y,g.z,0,g.hx,g.hy,g.hz,g.hp||.9,[],{deb:C("#4a505a"),snd:.25,msh:g.meshes,big:.5}); p.cy=g.y+g.hy; }
api.reg=reg;
/* kayıtlı bir eşyayı başka yere taşı / yeniden canlandır (kardan adam havuzu): hücre ızgarasını günceller */
api.relocate=function(p,x,y,z,alive){ const ok=gk(Math.floor(p.x/CS),Math.floor(p.z/CS)), a=GRID.get(ok); if(a){ const i=a.indexOf(p); if(i>=0) a.splice(i,1); }
  p.x=x; p.y=y; p.z=z; p.cy=y+p.hy; if(alive!==undefined) p.alive=!!alive; cellAdd(p); return p; };

/* 4) STATİK PARÇALAR: şehir üretiminde fbox/rbox/cyl… ile birleşik bölge meshlerine gömülen tüm dikey parçalar (tezgâh, direk, şemsiye, depo, bayrak direği, korkuluk…)
   cg_common.js izleyicisi her parçanın kutusunu ve indeks aralığını kaydetti; kırılınca aralık sıfırlanır (üçgenler kaybolur), destek kaybeden üstteki parçalar da gecikmeyle düşer. */
const SP=[], SG=new Map(), nowSolid=bl.filter(e=>e&&!e.tier&&e.h>0);
{ const W=Game.W;
  for(const q of CG.statics||[]){ if(!q.A.IA) continue; const cx=(q.x0+q.x1)/2, cz=(q.z0+q.z1)/2;
    let skip=false; for(const e of nowSolid){ if(Math.abs(cx-e.x)<e.hw+.3&&Math.abs(cz-e.z)<e.hd+.3&&q.y0<(e.h||0)+1){ skip=true; break; } } if(skip) continue;
    const vol=(q.x1-q.x0)*(q.y1-q.y0)*(q.z1-q.z0); q.hp=.45+Math.min(1.3,Math.cbrt(vol)*.18); q.alive=true; q.sv=null; q.gy=W.terrainH?W.terrainH(cx,cz):0; q.id=SP.length; SP.push(q);
    const i0=Math.floor(q.x0/CS), i1=Math.floor(q.x1/CS), j0=Math.floor(q.z0/CS), j1=Math.floor(q.z1/CS);
    for(let ix=i0;ix<=i1;ix++) for(let iz=j0;iz<=j1;iz++){ const k=gk(ix,iz); let a=SG.get(k); if(!a){ a=[]; SG.set(k,a); } a.push(q); } }
  api.total+=SP.length; api.kinds.piece=SP.length; }
const ov=(a0,a1,b0,b1)=>Math.min(a1,b1)-Math.max(a0,b0);
function stands(q){ if(q.y0<=Math.max(.35,q.gy+.4)) return true;
  const i0=Math.floor(q.x0/CS), i1=Math.floor(q.x1/CS), j0=Math.floor(q.z0/CS), j1=Math.floor(q.z1/CS);
  for(let ix=i0;ix<=i1;ix++) for(let iz=j0;iz<=j1;iz++){ const a=SG.get(gk(ix,iz)); if(!a) continue; for(const s of a){ if(s===q||!s.alive) continue; if(Math.abs(s.y1-q.y0)<=.3&&ov(s.x0,s.x1,q.x0,q.x1)>.05&&ov(s.z0,s.z1,q.z0,q.z1)>.05) return true; } }
  return false; }
const pend=[];
function breakStatic(q,vx,vy,vz,quiet){ if(!q.alive) return false; q.alive=false; api.broken++; const A=q.A, IA=A.IA; if(!q.sv) q.sv=IA.slice(q.i0,q.i1); for(let k=q.i0;k<q.i1;k++) IA[k]=0; D.markIdx(A,q.i0,q.i1-1);
  const x=(q.x0+q.x1)/2, y=(q.y0+q.y1)/2, z=(q.z0+q.z1)/2, sx=q.x1-q.x0, sy=q.y1-q.y0, sz=q.z1-q.z0, vol=sx*sy*sz;
  if(budget>0){ budget--; pc.x=x; pc.y=y; pc.z=z; pc.sx=Math.max(.3,sx); pc.sy=Math.max(.3,sy); pc.sz=Math.max(.3,sz); pc.r=q.r; pc.g=q.g; pc.b=q.b;
    if(Game.Debris) Game.Debris.burst(pc,x,y,z,vx,vy,vz,Math.min(1.1,.4+vol*.02),{quiet:true,k:.55});
    if(FX) FX.dust(x,y,z,vol>8?5:3,Math.max(.8,Math.max(sx,sz)*.5),null);
    if(!quiet&&Game.audio&&Game.audio.crash) Game.audio.crash(x,y,z,Math.min(.6,.12+vol*.01)); }
  if(!quiet&&Game.NPC) Game.NPC.noise(x,z,24);
  /* üstünde duran parçalar desteksiz kaldıysa gecikmeyle düşer */
  const i0=Math.floor(q.x0/CS), i1=Math.floor(q.x1/CS), j0=Math.floor(q.z0/CS), j1=Math.floor(q.z1/CS);
  for(let ix=i0;ix<=i1;ix++) for(let iz=j0;iz<=j1;iz++){ const a=SG.get(gk(ix,iz)); if(!a) continue; for(const s of a){ if(!s.alive||s.pw) continue; if(Math.abs(s.y0-q.y1)<=.3&&ov(s.x0,s.x1,q.x0,q.x1)>.05&&ov(s.z0,s.z1,q.z0,q.z1)>.05&&!stands(s)){ s.pw=true; pend.push({q:s,t:.35+Math.random()*.9}); } } }
  return true; }
function hitStatic(x,y,z,r,amt,speed,quiet){ let n=0; const R=r, i0=Math.floor((x-R)/CS), i1=Math.floor((x+R)/CS), j0=Math.floor((z-R)/CS), j1=Math.floor((z+R)/CS);
  for(let ix=i0;ix<=i1;ix++) for(let iz=j0;iz<=j1;iz++){ const a=SG.get(gk(ix,iz)); if(!a) continue;
    for(let k=0;k<a.length;k++){ const q=a[k]; if(!q.alive) continue; const ex=Math.max(q.x0-x,0,x-q.x1), ey=Math.max(q.y0-y,0,y-q.y1), ez=Math.max(q.z0-z,0,z-q.z1), d=Math.hypot(ex,ey,ez); if(d>r) continue;
      const eff=amt*(1-d/Math.max(r,.01)*.5); if(eff<q.hp) continue;
      let vx=(q.x0+q.x1)/2-x, vy=(q.y0+q.y1)/2-y+1.2, vz=(q.z0+q.z1)/2-z; const l=Math.hypot(vx,vy,vz)||1, kk=Math.min(24,(speed||8))*.4/l;
      if(breakStatic(q,vx*kk,vy*kk,vz*kk,quiet)) n++; } }
  return n; }
function reviveStatics(){ for(const q of SP){ if(q.alive||!q.sv) continue; q.A.IA.set(q.sv,q.i0); D.markIdx(q.A,q.i0,q.i1-1); q.alive=true; q.pw=false; } pend.length=0; }
api.statics=SP;

/* ---------- hasar: küre ile yönlü kutu (OBB) testi ---------- */
const pc={x:0,y:0,z:0,sx:1,sy:1,sz:1,r:.5,g:.5,b:.5,burn:0,frost:0,kind:0,t:null};
let budget=14, jets=[];
function hideParts(p){ if(p.parts.length&&!p.saved){ p.saved=p.parts.map(a=>{ const m=a[0], k=a[1]; return m.instanceMatrix.array.slice(k*16,k*16+16); }); }
  for(const a of p.parts){ const m=a[0], k=a[1], ar=m.instanceMatrix.array; for(let i=0;i<16;i++) ar[k*16+i]=ZERO16[i]; m.instanceMatrix.needsUpdate=true; }
  if(p.msh) for(const m of p.msh) m.visible=false; }
function showParts(p){ if(p.parts.length&&p.saved){ p.parts.forEach((a,j)=>{ const m=a[0], k=a[1], ar=m.instanceMatrix.array; ar.set(p.saved[j],k*16); m.instanceMatrix.needsUpdate=true; }); }
  if(p.msh) for(const m of p.msh) m.visible=true; }
function breakIt(p,vx,vy,vz,quiet){ if(!p.alive) return false; p.alive=false; api.broken++; hideParts(p);
  if(p.tiny){ if(budget>0&&FX&&FX.dust){ budget--; FX.dust(p.x,(p.cy||p.y+.1),p.z,1,.22,[.74,.73,.7]); } return true; }
  const x=p.x, y=p.cy||p.y+.5, z=p.z, d=p.deb;
  if(budget>0){ budget--; pc.x=x; pc.y=y; pc.z=z; pc.sx=Math.max(.3,p.hx*1.6); pc.sy=Math.max(.3,p.hy*1.4); pc.sz=Math.max(.3,p.hz*1.6); pc.r=d.r; pc.g=d.g; pc.b=d.b;
    if(Game.Debris) Game.Debris.burst(pc,x,y,z,vx,vy,vz,p.big>=1?.9:.55,{quiet:true,k:p.big>=1?.7:.5});
    if(FX) FX.dust(x,y,z,p.big>=1?6:3,Math.max(.8,p.hx),null);
    if(p.body&&Game.P&&Game.P.spawnDebris){ const b=p.body; Game.P.spawnDebris({x,y,z,sx:b.sx,sy:b.sy,sz:b.sz,r:d.r,g:d.g,b:d.b,burn:0,frost:0},vx*.6,2+Math.abs(vy)*.4,vz*.6); }
    if(!quiet&&Game.audio&&Game.audio.crash) Game.audio.crash(x,y,z,p.snd);
    if(p.jet){ jets.push({x,y:p.y+.7,z,t:0,dur:5.5}); if(Game.audio&&Game.audio.splash) Game.audio.splash(x,y,z,.7); } }
  if(!quiet){ if(Game.NPC) Game.NPC.noise(x,z,p.big>=1?44:26); if(D.shakeNear) D.shakeNear(x,y,z,.05+.08*p.big,28); }
  if(p.kind==="bench"&&Game.Places){ const by=Game.Places.by.seat||[]; for(const s of by){ if(!s.meta||!s.meta.bench||s.off) continue; if(Math.hypot(s.x-x,s.z-z)<1.3){ s.off=true; if(s.o&&Game.NPC&&Game.NPC.cancel){ const o=s.o; s.o=null; Game.NPC.cancel(o); } } } }
  return true; }
/* küre (x,y,z,r) bir eşyaya değiyor mu; değerse güç ≥ hp ise kır. dönen: kırılan sayı */
api.hit=function(x,y,z,r,amt,speed,quiet,fx,fz){ if(!(amt>0)) return 0; let n=0; const R=r+3.6, i0=Math.floor((x-R)/CS), i1=Math.floor((x+R)/CS), j0=Math.floor((z-R)/CS), j1=Math.floor((z+R)/CS);
  for(let ix=i0;ix<=i1;ix++) for(let iz=j0;iz<=j1;iz++){ const a=GRID.get(gk(ix,iz)); if(!a) continue;
    for(let k=0;k<a.length;k++){ const p=a[k]; if(!p.alive) continue; const dx=x-p.x, dz=z-p.z, lx=dx*p.cs-dz*p.sn, lz=dx*p.sn+dz*p.cs, dy=y-(p.cy||p.y+.5);
      const ex=Math.max(Math.abs(lx)-p.hx,0), ey=Math.max(Math.abs(dy)-p.hy,0), ez=Math.max(Math.abs(lz)-p.hz,0), d=Math.hypot(ex,ey,ez); if(d>r) continue;
      const eff=amt*(1-d/Math.max(r,.01)*.5); if(eff<p.hp) continue;
      let vx=p.x-x, vy=(p.cy||p.y+.5)-y+1.5, vz=p.z-z; if(fx!==undefined){ vx+=fx*2; vz+=fz*2; } const l=Math.hypot(vx,vy,vz)||1, kk=Math.min(26,(speed||8))*.45/l;
      if(breakIt(p,vx*kk,vy*kk,vz*kk,quiet)) n++; } }
  n+=hitStatic(x,y,z,r,amt,speed,quiet);
  api.hits+=n; return n; };
api.reviveAll=function(){ for(const p of api.list){ if(p.alive) continue; showParts(p); p.alive=true; } reviveStatics(); api.broken=0; jets.length=0; };
api.count=()=>({total:api.total,broken:api.broken,kinds:api.kinds});

/* D.damageSphere'e bağla: bütün güçler, yumruk, araç çarpması, yıkıcı olaylar eşyaları da kırar */
{ const orig=D.damageSphere; D.damageSphere=function(x,y,z,r,amt,speed,quiet){ const n=orig.apply(D,arguments); try{ api.hit(x,y,z,r*.9,amt,speed,quiet); }catch(e){} return n; }; }

/* ---------- temas: kahraman / araç hızına göre; yangın musluğu fışkırması ---------- */
let tc=0;
Game.updaters.push(dt=>{ budget=14; if(Game.mode!=="play") return;
  for(let i=pend.length-1;i>=0;i--){ const e=pend[i]; e.t-=dt; if(e.t<=0){ pend.splice(i,1); e.q.pw=false; if(e.q.alive&&!stands(e.q)) breakStatic(e.q,(Math.random()-.5)*2,-1,(Math.random()-.5)*2,false); } }
  tc-=dt; if(tc<=0){ tc=.05; const h=Game.heroObj, H0=Game.H; if(h&&H0&&!H0.dead){ const MV=Game.Mounted&&Game.Mounted(), sp=MV?(MV.speed||0):(H0.speed||0); if(sp>5.5){ const pos=MV&&MV.x!==undefined?{x:MV.x,y:MV.y,z:MV.z}:h.position, big=!!MV; api.hit(pos.x,pos.y-(big?.4:.2),pos.z,big?2.3:1.15,sp/13,sp,false); } } }
  for(let i=jets.length-1;i>=0;i--){ const j=jets[i]; j.t+=dt; if(j.t>j.dur){ jets.splice(i,1); continue; } if(Math.random()<dt*22&&FX) FX.dust(j.x,j.y+Math.random()*2.2,j.z,2,.55,[.72,.88,1]); } });
api.jets=jets;
return api; })();
