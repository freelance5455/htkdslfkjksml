"use strict";
/* ===== PARÇALAR (instancing): yaprak, odun kıymığı, kum / taş kırığı. Halka tampon, basit fizik + zemin çarpışması ===== */
Game.Shards=(function(){
const CAP=700, W=Game.W, S={};
const mat=new THREE.MeshStandardMaterial({roughness:.92,flatShading:true});
const m=new THREE.InstancedMesh(new THREE.BoxGeometry(1,1,1),mat,CAP); m.frustumCulled=false; m.castShadow=false; m.receiveShadow=true;
const o=new THREE.Object3D(), white=new THREE.Color(1,1,1);
const f=()=>new Float32Array(CAP);
const px=f(),py=f(),pz=f(),vx=f(),vy=f(),vz=f(),rx=f(),ry=f(),rz=f(),wx=f(),wy=f(),wz=f(),sx=f(),sy=f(),sz=f(),life=f(),ml=f(),gr=f(),fl=f(),st=new Uint8Array(CAP);
o.scale.setScalar(.0001); o.updateMatrix();
for(let i=0;i<CAP;i++){ m.setMatrixAt(i,o.matrix); m.setColorAt(i,white); }
m.instanceMatrix.needsUpdate=true; if(m.instanceColor) m.instanceColor.needsUpdate=true; m.count=0; scene.add(m);
let next=0, hi=0, live=0;
const R=(a,b)=>a+Math.random()*(b-a);
/* o: {sp, up, size:[a,b], flat, cols:[Color], life:[a,b], grav, spin, spread, flutter, dir:[dx,dz,k]} */
S.burst=function(x,y,z,n,q){ const sp=q.sp||4, up=q.up||3, sz=q.size||[.1,.25], cols=q.cols||[white], lf=q.life||[3,5], spr=q.spread||.5, spin=q.spin||8;
  for(let k=0;k<n;k++){ const i=next; next=(next+1)%CAP; if(i+1>hi) hi=i+1; const a=Math.random()*6.283, s=R(.25,1)*sp;
    px[i]=x+R(-spr,spr); py[i]=y+R(-spr,spr)*.6; pz[i]=z+R(-spr,spr);
    vx[i]=Math.cos(a)*s+(q.dir?q.dir[0]*q.dir[2]*R(.4,1):0); vy[i]=R(.2,1)*up; vz[i]=Math.sin(a)*s+(q.dir?q.dir[1]*q.dir[2]*R(.4,1):0);
    rx[i]=R(0,6.28); ry[i]=R(0,6.28); rz[i]=R(0,6.28); wx[i]=R(-spin,spin); wy[i]=R(-spin,spin); wz[i]=R(-spin,spin);
    const b=R(sz[0],sz[1]); if(q.flat){ sx[i]=b; sy[i]=b*.1; sz[i]=b*R(.6,.9); } else { sx[i]=b*R(.6,1.4); sy[i]=b*R(.5,1.1); sz[i]=b*R(.6,1.4); }
    life[i]=ml[i]=R(lf[0],lf[1]); gr[i]=q.grav===undefined?14:q.grav; fl[i]=q.flutter||0; st[i]=0;
    m.setColorAt(i,cols[(Math.random()*cols.length)|0]); live++; }
  m.count=hi; if(m.instanceColor) m.instanceColor.needsUpdate=true; };
S.update=function(dt){ if(!live) return; dt=Math.min(dt,.05); let alive=0;
  for(let i=0;i<hi;i++){ if(life[i]<=0) continue; life[i]-=dt;
    if(life[i]<=0){ o.position.set(0,-999,0); o.scale.setScalar(.0001); o.updateMatrix(); m.setMatrixAt(i,o.matrix); live--; continue; }
    alive++;
    if(!st[i]){ vy[i]-=gr[i]*dt; if(fl[i]){ if(vy[i]<-fl[i]) vy[i]=-fl[i]; vx[i]+=Math.sin(life[i]*5+i)*dt*3; vz[i]+=Math.cos(life[i]*4+i)*dt*3; vx[i]*=1-dt*.8; vz[i]*=1-dt*.8; }
      px[i]+=vx[i]*dt; py[i]+=vy[i]*dt; pz[i]+=vz[i]*dt; rx[i]+=wx[i]*dt; ry[i]+=wy[i]*dt; rz[i]+=wz[i]*dt;
      const g=W.surfaceAt(px[i],pz[i],py[i]), h=Math.max(sx[i],sz[i])*.4;
      if(py[i]<g+h){ py[i]=g+h; if(fl[i]||Math.abs(vy[i])<2){ st[i]=1; } else { vy[i]=-vy[i]*.3; vx[i]*=.6; vz[i]*=.6; wx[i]*=.5; wy[i]*=.5; wz[i]*=.5; } } }
    const k=life[i]/ml[i], sc=k<.2?k/.2:1; o.position.set(px[i],py[i],pz[i]); o.rotation.set(st[i]?(rx[i]*0+(fl[i]?0:rx[i])):rx[i],ry[i],st[i]&&fl[i]?0:rz[i]); o.scale.set(sx[i]*sc+.0001,sy[i]*sc+.0001,sz[i]*sc+.0001); o.updateMatrix(); m.setMatrixAt(i,o.matrix); }
  m.instanceMatrix.needsUpdate=true; if(!alive){ hi=0; m.count=0; live=0; } };
S.live=()=>live;
Game.updaters.push(dt=>S.update(dt));
return S;
})();
