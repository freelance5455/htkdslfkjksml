"use strict";
/* ===== RÜZGÂR TÜRBİNLERİ: dönen pervane, yumruk/uçuş/patlama ile kırılma, devrilme, enkaz, yeniden dikilme ===== */
Game.Turbines=(function(){
  const D=Game.D, FX=Game.FX, au=()=>Game.audio, Ev=Game.Ev, rs=()=>Math.random()-.5;
  const api={list:()=>Game.turbines||[],stats:{broken:0},RESPAWN:240};
  const dirv=(T,dx,dz)=>{ const l=Math.hypot(dx,dz); if(l<1e-3){ const a=Math.random()*6.283; dx=Math.cos(a); dz=Math.sin(a); } else { dx/=l; dz/=l; } T.dx=dx; T.dz=dz; };
  api.hurt=function(T,amt,dx,dz){ if(T.st!=="up") return false; T.hp-=amt; if(T.hp<=0){ api.topple(T,dx,dz); return true; } if(au()&&au().metalHit) au().metalHit(T.x,T.H*.5,T.z); FX.spark(T.x,6,T.z,6,6,[1,.9,.6]); T.shake=.8; return false; };
  api.topple=function(T,dx,dz){ if(T.st!=="up") return; dirv(T,dx,dz); T.st="fall"; T.t=0; T.th=.015; T.w=.06; T.e.h=0; T.hp=0; api.stats.broken++; FX.dust(T.x,2,T.z,10,3); FX.spark(T.x,2.5,T.z,16,12,[1,.8,.5]);
    if(au()){ au().stoneCrack&&au().stoneCrack(T.x,3,T.z); au().metalGroan&&au().metalGroan(T.x,T.H*.6,T.z); }
    if(Game.NPC) Game.NPC.alert(T.x,T.z,70,T.x,T.z); Ev.emit("turbineBroken",T); };
  function land(T){ T.st="down"; T.t=0; const L=T.H, bx=T.x+T.dx*L*.55, bz=T.z+T.dz*L*.55, gy=T.y0;
    FX.dust(bx,gy+1,bz,18,6); FX.cloud&&FX.cloud(bx,gy+1.5,bz,4,7,3); FX.shock&&FX.shock(bx,gy+.5,bz,22,16); FX.spark(bx,gy+1,bz,24,14,[1,.85,.55]);
    if(au()){ au().collapse&&au().collapse(bx,gy+1,bz,.9); au().crash&&au().crash(bx,gy+1,bz,1); au().metalHit&&au().metalHit(bx,gy+2,bz); }
    if(D&&D.shakeNear) D.shakeNear(bx,gy,bz,.6,150);
    for(let k=0;k<7;k++){ const u=k/7*L*.95+1, s=T.sc; Game.P.spawnDebris({x:T.x+T.dx*u,y:gy+1.2,z:T.z+T.dz*u,sx:2.2*s,sy:1.6*s,sz:2.2*s,r:.8,g:.82,b:.85,burn:0,frost:0},T.dx*5+rs()*4,4+Math.random()*5,T.dz*5+rs()*4); }
    for(let k=0;k<3;k++){ const a=k*2.094+T.rg.rotation.z; const rr=7*T.sc, px=T.x+T.dx*L+Math.sin(a)*rr*T.dz, pz=T.z+T.dz*L-Math.sin(a)*rr*T.dx; Game.P.spawnDebris({x:px,y:gy+1,z:pz,sx:.7*T.sc,sy:.3*T.sc,sz:9*T.sc,r:.95,g:.96,b:.97,burn:0,frost:0},T.dx*3+rs()*5,3+Math.random()*4,T.dz*3+rs()*5); }
    if(Game.NPC) Game.NPC.noise(bx,bz,90); }
  function reset(T){ T.g.quaternion.set(0,0,0,1); T.g.position.y=T.y0; T.st="up"; T.hp=1; T.th=0; T.w=0; T.e.h=T.H; T.rg.visible=true; T.nac.visible=true; FX.dust(T.x,2,T.z,8,3); }
  const ax=new THREE.Vector3(), qq=new THREE.Quaternion();
  api.step=function(dt,time){ const L=api.list(); if(!L.length) return; const wind=.45+(Game.windK||1)*.65, h=Game.heroObj, hv=Game.H&&Game.H.vel;
    for(let i=0;i<L.length;i++){ const T=L[i];
      if(T.st==="up"){ T.rg.rotation.z+=dt*wind*T.spin; T.g.rotation.z=T.shake>0.01?Math.sin(time*40)*.004*T.shake:0; if(T.shake>0) T.shake*=Math.exp(-6*dt);
        /* kahraman hızla geçiyorsa kule kırılır */
        if(h&&Game.mode==="play"&&hv){ const sp=hv.length(); if(sp>34&&Math.abs(h.position.x-T.x)<3.4&&Math.abs(h.position.z-T.z)<3.4&&h.position.y<T.H+3){ api.hurt(T,sp>60?1:.55,hv.x,hv.z); if(T.st==="up"&&Game.H) hv.multiplyScalar(.9); } } }
      else if(T.st==="fall"){ T.t+=dt; T.rg.rotation.z+=dt*wind*T.spin*(1-Math.min(1,T.t/3)); const a=1.15*Math.sin(T.th+.02)+.3; T.w+=a*dt; T.th+=T.w*dt;
        ax.set(T.dz,0,-T.dx); qq.setFromAxisAngle(ax,Math.min(T.th,1.5708)); T.g.quaternion.copy(qq);
        if(Math.random()<dt*5) FX.dust(T.x+T.dx*T.H*Math.sin(T.th)*.5,T.y0+T.H*Math.cos(T.th)*.5,T.z+T.dz*T.H*Math.sin(T.th)*.5,1,1.4);
        if(T.th>=1.5){ T.th=1.5; T.g.quaternion.setFromAxisAngle(ax,1.5); land(T); } }
      else if(T.st==="down"){ T.t+=dt; if(T.rg.rotation.z!==undefined) T.rg.rotation.z+=dt*Math.max(0,.6-T.t*.1)*T.spin; if(T.t>api.RESPAWN&&Game.mode==="play"&&h&&Math.hypot(h.position.x-T.x,h.position.z-T.z)>220) reset(T); } } };
  /* hasar küresi (yumruk, patlama, fırlatılan araba) */
  const o=D.damageSphere; D.damageSphere=function(x,y,z,r,amt,speed,quiet){ const n=o.apply(this,arguments); const L=api.list(); for(let i=0;i<L.length;i++){ const T=L[i]; if(T.st!=="up") continue; const dx=T.x-x, dz=T.z-z, d=Math.hypot(dx,dz); if(d>r+1.6*T.sc||y<-r||y>T.H+r) continue; api.hurt(T,Math.min(1,amt*(.55+(speed||10)*.012)),dx,dz); } return n; };
  Game.updaters.push((dt,time)=>{ if(Game.mode==="play"||Game.mode==="menu") api.step(Math.min(dt,.05),time); });
  return api; })();
