"use strict";
/* ===== YIKIM: parça (chunk) yönetimi, destek/çöküş, hasar, yangın, buz, ışın testi (ilçe başına ayrı mesh) ===== */
(function(){
const D=Game.D, FX=Game.FX;
const pending=[], burning=new Set(), dirtyG=new Set(); D.dirty=new Set(); D.burning=burning; D.pending=pending;
const rs=()=>Math.random()-.5, ALIVE=c=>c.alive&&c.pend<0;

function tint(c,tr,tg,tb,k){ const g=c.dg, CA=g.CA, OR=g.ORIG, v0=c.vs*3, n=c.vc*3;
  for(let i=0;i<n;i+=3){ const o=OR[v0+i],p=OR[v0+i+1],q=OR[v0+i+2], lum=Math.min(1,(o+p+q)/3/.6)*.6+.4;
    CA[v0+i]=o+(tr*lum-o)*k; CA[v0+i+1]=p+(tg*lum-p)*k; CA[v0+i+2]=q+(tb*lum-q)*k; }
  if(v0<g.cMin) g.cMin=v0; if(v0+n-1>g.cMax) g.cMax=v0+n-1; dirtyG.add(g); }
function recolor(c){ if(c.burn>0) tint(c,.05,.04,.035,Math.min(1,c.burn)); else if(c.frost>0) tint(c,.55,.82,1,Math.min(1,c.frost)); else tint(c,0,0,0,0); }
function flush(){ if(!dirtyG.size) return;
  for(const g of dirtyG){
    if(g.iMax>=0){ const a=g.geo.index; a.updateRange.offset=g.iMin; a.updateRange.count=g.iMax-g.iMin+1; a.needsUpdate=true; g.iMin=1e12; g.iMax=-1; }
    if(g.cMax>=0){ const a=g.geo.attributes.color; a.updateRange.offset=g.cMin; a.updateRange.count=g.cMax-g.cMin+1; a.needsUpdate=true; g.cMin=1e12; g.cMax=-1; }
    if(g.pMax>=0){ for(const nm of ["position","normal"]){ const a=g.geo.attributes[nm]; a.updateRange.offset=g.pMin; a.updateRange.count=g.pMax-g.pMin+1; a.needsUpdate=true; } g.pMin=1e12; g.pMax=-1; } }
  dirtyG.clear(); }

/* yeniden inşa için: ilk yıkımda parçanın indeks/konum/normal verisi saklanır */
function snap(c){ if(c.sv||!c.dg||!c.dg.geo) return; const g=c.dg, v0=c.vs*3, n=c.vc*3; c.sv={i:g.IA.slice(c.is,c.is+c.ic),p:g.geo.attributes.position.array.slice(v0,v0+n),n:g.geo.attributes.normal.array.slice(v0,v0+n)}; }
D.snap=snap;
D.markIdx=function(g,a,b){ if(a<g.iMin) g.iMin=a; if(b>g.iMax) g.iMax=b; dirtyG.add(g); };   /* başka sistemler (props_break) bölge indeks arabelleğini güvenle günceller */
D.revive=function(c){ if(c.alive||c.fall||c.pend>=0||!c.sv) return false; const g=c.dg, sv=c.sv, v0=c.vs*3, n=c.vc*3;
  g.IA.set(sv.i,c.is); if(c.is<g.iMin) g.iMin=c.is; if(c.is+c.ic-1>g.iMax) g.iMax=c.is+c.ic-1;
  if(g.pMin===undefined){ g.pMin=1e12; g.pMax=-1; } g.geo.attributes.position.array.set(sv.p,v0); g.geo.attributes.normal.array.set(sv.n,v0); if(v0<g.pMin) g.pMin=v0; if(v0+n-1>g.pMax) g.pMax=v0+n-1;
  c.alive=true; c.pend=-1; c.hp=1; c.burn=0; c.frost=0; burning.delete(c); tint(c,0,0,0,0); if(c.att) for(const m of c.att) m.visible=true; if(Game.Interior&&Game.Interior.onRevive) Game.Interior.onRevive(c); D.dirty.add(c.t.bl); dirtyG.add(g); return true; };
D.killSilent=function(c){ if(!c.alive) return; snap(c); c.alive=false; c.pend=-1; const g=c.dg, IA=g.IA, e=c.is+c.ic; for(let k=c.is;k<e;k++) IA[k]=0; if(c.is<g.iMin) g.iMin=c.is; if(e-1>g.iMax) g.iMax=e-1; dirtyG.add(g); burning.delete(c); if(c.att) for(const m of c.att) m.visible=false; if(Game.Interior) Game.Interior.onKill(c); D.dirty.add(c.t.bl); };
D.kill=function(c,vx,vy,vz,quiet){ if(!c.alive) return; snap(c); c.alive=false; c.pend=-1;
  const g=c.dg, IA=g.IA, e=c.is+c.ic; for(let k=c.is;k<e;k++) IA[k]=0;
  if(c.is<g.iMin) g.iMin=c.is; if(e-1>g.iMax) g.iMax=e-1; dirtyG.add(g);
  burning.delete(c); if(c.att) for(const m of c.att) m.visible=false;
  const kind=c.kind, vol=c.sx*c.sy*c.sz, sp=Math.max(c.sx,c.sz);
  if(Game.Debris) Game.Debris.burst(c,c.x,c.y,c.z,vx||0,vy||0,vz||0,quiet?.55:1,{quiet:quiet});
  if(Game.P&&kind!==1) Game.P.spawnDebris(c,vx,vy,vz);
  const ic=c.frost>.5?[.8,.9,1]:null;
  if(kind===1) FX.dust(c.x,c.y,c.z,quiet?2:6,Math.min(6,sp*.3),ic);
  else { FX.dust(c.x,c.y,c.z,quiet?3:(kind===2?12:8),sp*.7,ic); if(!quiet) FX.cloud(c.x,c.y,c.z,vol>20?3:1,sp*.6,1.4+Math.min(2,vol*.02),ic); }
  if(!quiet&&Game.audio) Game.audio.crash(c.x,c.y,c.z,Math.min(1,vol/60));
  if(!quiet&&Game.NPC) Game.NPC.noise(c.x,c.z,45);
  if(Game.Interior) Game.Interior.onKill(c);
  D.dirty.add(c.t.bl); };

/* ---- DÜŞEN PARÇALAR: desteği kopan parça anında kaybolmaz; çekim etkisiyle düşer, savrulur, yere/alttaki parçaya çarpınca dağılır ---- */
const falling=[]; D.falling=falling; const MAXFALL=150, WW=Game.W;
D.startFall=function(c,vx,vy,vz){
  if(!c.alive) return; if(falling.length>=MAXFALL){ D.kill(c,vx,vy,vz,true); return; }
  snap(c); c.alive=false; c.pend=-1; burning.delete(c); if(c.att) for(const m of c.att) m.visible=false; if(Game.Interior) Game.Interior.onKill(c); D.dirty.add(c.t.bl);
  const g=c.dg, PA=g.geo.attributes.position.array, NA=g.geo.attributes.normal.array, v0=c.vs*3, n=c.vc*3; if(g.pMin===undefined){ g.pMin=1e12; g.pMax=-1; }
  const t=c.t; let ox=c.x-t.x, oz=c.z-t.z; const ol=Math.hypot(ox,oz)||1; ox/=ol; oz/=ol; const kind=c.kind;
  let ax=rs(), ay=rs()*.4, az=rs(); const al=Math.hypot(ax,ay,az)||1; ax/=al; ay/=al; az/=al;
  const out=kind===1?0:(1+Math.random()*2.2);
  const f={c,g,t:0,vx:vx+ox*out,vy:vy,vz:vz+oz*out,ang:0,w:(Math.random()<.5?-1:1)*(.35+Math.random()*1.1)*(kind===1?.15:1),max:(kind===1?.1:kind===2?1:.55+Math.random()*.7),ax,ay,az,cx:c.x,cy:c.y,cz:c.z,ox:c.x,oy:c.y,oz:c.z,v0,n,P0:PA.slice(v0,v0+n),N0:NA.slice(v0,v0+n),PA,NA};
  falling.push(f); c.fall=f; };
function floorFor(c,f){ const t=c.t; let fy=WW.terrainH(f.cx,f.cz); if(fy<WW.WATER_Y) fy=WW.WATER_Y;
  if(c.ci>=0){ for(let L=c.L-1;L>=0;L--){ const ch=D.chunks[t.walls[L][c.ci]]; if(ch&&ch.alive){ return Math.max(fy,ch.y+ch.sy/2); } } }
  else if(c.ci===-1){ for(let L=c.L-1;L>=0;L--){ const id=t.cores[L], ch=id>=0?D.chunks[id]:null; if(ch&&ch.alive){ return Math.max(fy,ch.y+ch.sy/2); } } }
  else { const h=t.entry.h; if(h<f.cy-c.sy*.5&&h>fy) return h; }
  const bl=t.bl, ti=bl.tiers.indexOf(t); if(ti>0){ const h=bl.tiers[ti-1].entry.h; if(h>fy&&h<f.cy) fy=h; }
  return fy; }
function finishFall(i,fy){ const f=falling[i], c=f.c, last=falling.pop(); if(last!==f) falling[i]=last; c.fall=null;
  const g=c.dg, IA=g.IA, e=c.is+c.ic; for(let k=c.is;k<e;k++) IA[k]=0; if(c.is<g.iMin) g.iMin=c.is; if(e-1>g.iMax) g.iMax=e-1; dirtyG.add(g);
  const kind=c.kind, vol=c.sx*c.sy*c.sz*(kind===1?.04:1), sp=Math.abs(f.vy), pw=Math.min(1.3,.35+Math.sqrt(vol)*.05+sp*.018), x=f.cx, y=Math.max(fy+.3,f.cy-c.sy*.35), z=f.cz;
  burstBudget--; const k=burstBudget>0?1:.35;
  if(Game.Debris) Game.Debris.burst(c,x,y,z,f.vx*.4,Math.min(4,sp*.12),f.vz*.4,pw,{k:k,spread:2.6});
  if(Game.P&&kind!==1&&burstBudget>-6) Game.P.spawnDebris({x,y,z,sx:c.sx,sy:c.sy,sz:c.sz,r:c.r,g:c.g,b:c.b,burn:c.burn,frost:c.frost},f.vx*.5,2,f.vz*.5);
  const big=vol>12;
  FX.dust(x,fy+.4,z,kind===1?3:(big?9:5),Math.max(1.5,Math.max(c.sx,c.sz)*.6));
  if(big&&kind!==1){ FX.cloud(x,fy+.8,z,2+(vol>40?2:0),Math.max(c.sx,c.sz)*.7,1.6+Math.min(2.4,vol*.03)); if(vol>28&&burstBudget>0) FX.ring(x,fy+.4,z,6,2.6+sp*.12,1.6); }
  if(Game.audio){ Game.audio.crash(x,y,z,Math.min(1,vol/60)); if(vol>26) Game.audio.collapse(x,y,z,Math.min(1,vol/160)); }
  shakeNear(x,y,z,Math.min(.55,pw*.28*(vol>12?1:.4)),70);
  if(Game.NPC&&kind!==1) Game.NPC.noise(x,z,40); D.dirty.add(c.t.bl); }
let burstBudget=12;
function shakeNear(x,y,z,amt,range){ const h=Game.heroObj; if(!h||!Game.shakeAdd) return; const d=Math.hypot(x-h.position.x,y-h.position.y,z-h.position.z); if(d<range) Game.shakeAdd(amt*(1-d/range)); }
D.shakeNear=shakeNear;
function updateFalls(dt){ burstBudget=12;
  for(let i=falling.length-1;i>=0;i--){ const f=falling[i], c=f.c; f.t+=dt; f.vy-=24*dt; const dr=Math.pow(.99,dt*60); f.vx*=dr; f.vz*=dr;
    f.cx+=f.vx*dt; f.cy+=f.vy*dt; f.cz+=f.vz*dt; if(f.ang<f.max) f.ang=Math.min(f.max,f.ang+Math.abs(f.w)*dt);
    const fy=floorFor(c,f), bottom=f.cy-c.sy*.5*(c.kind===1?.15:1);
    if(bottom<=fy+.05||f.t>7||f.cy<-30){ finishFall(i,fy); continue; }
    /* köşeleri döndür + taşı */
    const an=f.ang*(f.w<0?-1:1), cs=Math.cos(an), sn=Math.sin(an), tt=1-cs, ax=f.ax, ay=f.ay, az=f.az,
      r00=tt*ax*ax+cs, r01=tt*ax*ay-sn*az, r02=tt*ax*az+sn*ay, r10=tt*ax*ay+sn*az, r11=tt*ay*ay+cs, r12=tt*ay*az-sn*ax, r20=tt*ax*az-sn*ay, r21=tt*ay*az+sn*ax, r22=tt*az*az+cs,
      P0=f.P0, N0=f.N0, PA=f.PA, NA=f.NA, v0=f.v0, n=f.n, ox=f.ox, oy=f.oy, oz=f.oz, cx=f.cx, cy=f.cy, cz=f.cz;
    for(let k=0;k<n;k+=3){ const dx=P0[k]-ox, dy=P0[k+1]-oy, dz=P0[k+2]-oz; PA[v0+k]=cx+r00*dx+r01*dy+r02*dz; PA[v0+k+1]=cy+r10*dx+r11*dy+r12*dz; PA[v0+k+2]=cz+r20*dx+r21*dy+r22*dz;
      const nx=N0[k], ny=N0[k+1], nz=N0[k+2]; NA[v0+k]=r00*nx+r01*ny+r02*nz; NA[v0+k+1]=r10*nx+r11*ny+r12*nz; NA[v0+k+2]=r20*nx+r21*ny+r22*nz; }
    const g=f.g; if(v0<g.pMin) g.pMin=v0; if(v0+n-1>g.pMax) g.pMax=v0+n-1; dirtyG.add(g);
    /* düşerken toz */
    if(Math.random()<dt*7&&c.kind!==1) FX.dust(f.cx+rs()*c.sx,f.cy-c.sy*.4,f.cz+rs()*c.sz,1,.6); } }
D.updateFalls=updateFalls;

D.dmg=function(c,amt,vx,vy,vz){ if(!c.alive) return false; if(c.frost>=1) amt*=3;
  c.hp=(c.hp===undefined?1:c.hp)-amt; if(c.hp<=0){ D.kill(c,vx,vy,vz); return true; }
  if(c.burn<1-c.hp){ c.burn=1-c.hp; recolor(c); } return false; };
D.ignite=function(c){ if(!c.alive||c.burn>=1||burning.size>70) return; if(!burning.has(c)){ burning.add(c); c.nextSpread=.8+Math.random()*1.5; if(!(c.burn>0)) c.burn=.01; } };
D.freezeChunk=function(c,amt){ if(!c.alive) return; if(burning.has(c)&&amt>.2){ burning.delete(c); c.burn=0; }
  if(c.frost<1){ c.frost=Math.min(1,c.frost+amt); if(c.burn<=0) recolor(c); } };

function schedule(c){ if(c.pend>=0||!c.alive) return; c.pend=.4+c.L*.07+Math.random()*.8; pending.push(c); }
function settle(bl){ let ground=true;
  for(let ti=0;ti<bl.tiers.length;ti++){ const t=bl.tiers[ti], nL=t.walls.length, nc=t.nc; let prev=null, prevCore=ti===0?true:ground, topAny=false, top=0;
    for(let L=0;L<nL;L++){ const row=t.walls[L], s=new Array(nc).fill(false); topAny=false;
      for(let ci=0;ci<nc;ci++){ const c=D.chunks[row[ci]]; if(!ALIVE(c)) continue; let ok;
        if(L===0) ok=ti===0||ground; else { ok=!!prev[ci]; if(!ok) for(const n of t.nb[ci]){ const nc2=D.chunks[row[n]]; if(ALIVE(nc2)&&prev[n]){ ok=true; break; } } }
        if(ok){ s[ci]=true; topAny=true; const tp=c.y+c.sy/2; if(tp>top) top=tp; } else schedule(c); }
      const cid=t.cores[L]; if(cid>=0){ const c=D.chunks[cid]; if(ALIVE(c)){ if(prevCore){ topAny=true; const tp=c.y+c.sy/2; if(tp>top) top=tp; } else schedule(c); }
        prevCore=ALIVE(c)&&prevCore; }
      prev=s; }
    if(t.prop&&ALIVE(t.prop)){ if(!topAny) schedule(t.prop); else top=Math.max(top,t.topY); }
    t.entry.h=top; ground=topAny; } }
D.settleAll=function(){ for(const bl of D.bl) settle(bl); };

D.damageSphere=function(x,y,z,r,amt,speed,quiet){ let n=0;
  for(const e of Game.buildings){ const t=e.tier; if(!t||e.h<=0) continue;
    const dx=Math.max(Math.abs(x-e.x)-e.hw,0), dz=Math.max(Math.abs(z-e.z)-e.hd,0), dy=y>e.h?y-e.h:0; if(dx*dx+dz*dz+dy*dy>r*r) continue;
    for(const c of t.chunks){ if(!c.alive) continue;
      const ax=Math.max(Math.abs(x-c.x)-c.sx/2,0), ay=Math.max(Math.abs(y-c.y)-c.sy/2,0), az=Math.max(Math.abs(z-c.z)-c.sz/2,0), d=Math.hypot(ax,ay,az); if(d>r) continue;
      let vx=c.x-x, vy=c.y-y+2, vz=c.z-z; const l=Math.hypot(vx,vy,vz)||1, k=speed*(1-d/r*.6)/l;
      if(D.dmg(c,amt*(1-d/r*.5),vx*k,vy*k*.7,vz*k)) n++; } }
  return n; };

let RBax=1,RBsg=1;
function rayBox(ox,oy,oz,dx,dy,dz,x0,y0,z0,x1,y1,z1){ let tmin=0,tmax=1e9;
  for(let a=0;a<3;a++){ const o=a===0?ox:a===1?oy:oz, d=a===0?dx:a===1?dy:dz, lo=a===0?x0:a===1?y0:z0, hi=a===0?x1:a===1?y1:z1;
    if(Math.abs(d)<1e-9){ if(o<lo||o>hi) return -1; } else { let t1=(lo-o)/d, t2=(hi-o)/d; if(t1>t2){ const q=t1; t1=t2; t2=q; } if(t1>tmin){ tmin=t1; RBax=a; RBsg=d>0?-1:1; } if(t2<tmax) tmax=t2; if(tmin>tmax) return -1; } }
  return tmin; }
D.rayBox=rayBox;
D.rayB=function(ox,oy,oz,dx,dy,dz,L,res){ let best=L, chunk=null, kind="none", bax=1, bsg=1;
  for(const e of Game.buildings){ if(e.h<=0) continue;
    const t0=rayBox(ox,oy,oz,dx,dy,dz,e.x-e.hw,e.y0||0,e.z-e.hd,e.x+e.hw,e.h,e.z+e.hd); if(t0<0||t0>best) continue;
    if(!e.tier){ best=t0; kind="solid"; chunk=null; bax=RBax; bsg=RBsg; continue; }
    for(const c of e.tier.chunks){ if(!c.alive) continue; const b=c.bx;
      for(let k=0;k<b.length;k+=6){ const t=rayBox(ox,oy,oz,dx,dy,dz,b[k],b[k+1],b[k+2],b[k+3],b[k+4],b[k+5]); if(t>=0&&t<best){ best=t; chunk=c; kind="chunk"; bax=RBax; bsg=RBsg; } } } }
  const r=res||{}; r.t=best; r.chunk=chunk; r.kind=kind; r.nx=bax===0?bsg:0; r.ny=bax===1?bsg:0; r.nz=bax===2?bsg:0; r.x=ox+dx*best; r.y=oy+dy*best; r.z=oz+dz*best; return r; };
D.ray=function(ox,oy,oz,dx,dy,dz,L){ let tt=L, tk="none";
  if(Game.rayTerrain){ const t=Game.rayTerrain(ox,oy,oz,dx,dy,dz,L); if(t>0&&t<L){ tt=t; tk=Game.rayKind||"ground"; } }
  else if(dy<-1e-6){ const t=-oy/dy; if(t>0&&t<L){ tt=t; tk="ground"; } }
  const r=D.rayB(ox,oy,oz,dx,dy,dz,tt);
  if(r.kind==="none") r.kind=tk;
  return r; };

let tm=0;
D.update=function(dt){ tm+=dt;
  for(let i=pending.length-1;i>=0;i--){ const c=pending[i]; if(!c.alive){ pending.splice(i,1); continue; } c.pend-=dt;
    if(c.pend<=0){ pending.splice(i,1); c.pend=0; D.startFall(c,rs()*1.6,-.5,rs()*1.6); } }
  for(const bl of D.dirty) settle(bl); D.dirty.clear();
  for(const c of burning){ if(!c.alive){ burning.delete(c); continue; }
    c.burn+=dt*.11; c.nextSpread-=dt;
    if(Math.random()<dt*14){ FX.fire(c.x+rs()*c.sx,c.y+rs()*c.sy,c.z+rs()*c.sz,1,0,2,0,1.6); if(Math.random()<.4) FX.smoke(c.x,c.y+c.sy/2,c.z,1,1); }
    if(((tm*4)|0)!==(((tm-dt)*4)|0)) recolor(c);
    if(c.nextSpread<=0){ c.nextSpread=1+Math.random()*1.6; const t=c.t, cand=[];
      if(c.ci>=0){ for(const n of t.nb[c.ci]){ cand.push(D.chunks[t.walls[c.L][n]]); } const up=t.walls[c.L+1]; if(up) cand.push(D.chunks[up[c.ci]]); }
      else if(c.ci===-1){ const up=t.cores[c.L+1]; if(up>=0) cand.push(D.chunks[up]); const w=t.walls[c.L]; if(w) cand.push(D.chunks[w[(Math.random()*w.length)|0]]); }
      if(t.prop&&c.L===t.walls.length-1) cand.push(t.prop);
      if(cand.length&&Math.random()<.7) D.ignite(cand[(Math.random()*cand.length)|0]); }
    if(c.burn>=1){ burning.delete(c); D.kill(c,rs()*2,1,rs()*2); Game.NPC&&Game.NPC.alert(c.x,c.z,60,c.x,c.z); } }
  updateFalls(dt); flush(); };
Game.updaters.push(dt=>{ if(Game.mode==="play"||Game.mode==="menu") D.update(dt); });
})();
