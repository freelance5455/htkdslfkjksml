"use strict";
/* ===== ENKAZ 2.0: çok sayıda küçük kırık parça (taş/beton/tuğla) + cam kırıkları. Cannon kullanmaz (ucuz, kinematik);
   yer çarpışması, sekme, yuvarlanma, dinlenme ve küçülerek kaybolma. Büyük gövdeler physics.js'te kalır. ===== */
Game.Debris=(function(){
  const W=Game.W, FX=Game.FX;
  const CAPS={low:[160,90],medium:[320,180],high:[560,320],ultra:[760,420]}, caps=CAPS[Game.quality]||CAPS.medium, NR=caps[0], NG=caps[1];
  const rs=()=>Math.random()-.5, R=(a,b)=>a+Math.random()*(b-a);
  /* --- taş geometrisi: köşeleri bozulmuş küp (aynı konumdaki köşeler aynı kayar → dikişsiz) --- */
  function rockGeo(){ const g=new THREE.BoxGeometry(1,1,1,2,2,2), p=g.attributes.position;
    for(let i=0;i<p.count;i++){ const x=p.getX(i), y=p.getY(i), z=p.getZ(i), h=Math.sin(x*91.7+y*47.3+z*29.1)*43758.5453, h1=h-Math.floor(h), h2=Math.sin(x*12.9+y*78.2+z*37.7)*12345.6789, h3=h2-Math.floor(h2), h4=Math.sin(x*53.1+y*11.3+z*97.9)*9876.54, h5=h4-Math.floor(h4);
      const k=(Math.abs(x)>.49?1:0)+(Math.abs(y)>.49?1:0)+(Math.abs(z)>.49?1:0), j=k>=2?.34:.2; p.setXYZ(i,x*(1+(h1-.5)*j)+(h3-.5)*.1,y*(1+(h3-.5)*j)+(h5-.5)*.1,z*(1+(h5-.5)*j)+(h1-.5)*.1); }
    if(g.computeVertexNormals) g.computeVertexNormals(); return g; }
  const rockMat=new THREE.MeshStandardMaterial({color:0xffffff,roughness:.94,metalness:.02,flatShading:true});
  const rocks=new THREE.InstancedMesh(rockGeo(),rockMat,NR); rocks.castShadow=true; rocks.receiveShadow=true; rocks.frustumCulled=false; scene.add(rocks);
  /* --- cam kırığı: ince eğik üçgen/dörtgen levha --- */
  const sg=new THREE.BufferGeometry(); sg.setAttribute("position",new THREE.BufferAttribute(new Float32Array([-.5,-.5,0, .5,-.35,0, .1,.5,0]),3)); sg.setAttribute("normal",new THREE.BufferAttribute(new Float32Array([0,0,1,0,0,1,0,0,1]),3));
  const glassMat=new THREE.MeshStandardMaterial({color:0xcfeaff,roughness:.04,metalness:.85,transparent:true,opacity:.62,side:THREE.DoubleSide,depthWrite:false,envMapIntensity:1.6});
  const glass=new THREE.InstancedMesh(sg,glassMat,NG); glass.frustumCulled=false; glass.renderOrder=4; scene.add(glass);
  const dummy=new THREE.Object3D(), col=new THREE.Color(), one=new THREE.Color(1,1,1);
  function mkPool(N,mesh){ const P={N,mesh,on:new Uint8Array(N),rest:new Uint8Array(N),x:new Float32Array(N),y:new Float32Array(N),z:new Float32Array(N),vx:new Float32Array(N),vy:new Float32Array(N),vz:new Float32Array(N),
      qx:new Float32Array(N),qy:new Float32Array(N),qz:new Float32Array(N),qw:new Float32Array(N).fill(1),wx:new Float32Array(N),wy:new Float32Array(N),wz:new Float32Array(N),sx:new Float32Array(N),sy:new Float32Array(N),sz:new Float32Array(N),
      age:new Float32Array(N),life:new Float32Array(N),hy:new Float32Array(N),head:0,live:0};
    dummy.scale.set(0,0,0); dummy.position.set(0,-9999,0); dummy.updateMatrix();
    for(let i=0;i<N;i++){ mesh.setMatrixAt(i,dummy.matrix); mesh.setColorAt(i,one); } mesh.instanceMatrix.needsUpdate=true; if(mesh.instanceColor) mesh.instanceColor.needsUpdate=true; return P; }
  const PR=mkPool(NR,rocks), PG=mkPool(NG,glass);
  function slot(P){ for(let k=0;k<P.N;k++){ const i=(P.head+k)%P.N; if(!P.on[i]){ P.head=(i+1)%P.N; return i; } } const i=P.head; P.head=(i+1)%P.N; return i; }   // dolu ise en eskiyi ez
  function spawn(P,x,y,z,vx,vy,vz,sx,sy,sz,r,g,b,life){ const i=slot(P); if(!P.on[i]) P.live++; P.on[i]=1; P.rest[i]=0; P.x[i]=x; P.y[i]=y; P.z[i]=z; P.vx[i]=vx; P.vy[i]=vy; P.vz[i]=vz;
    const u=Math.random()*6.283, v=Math.random()*2-1, s=Math.sqrt(1-v*v), a=Math.random()*3.14, sa=Math.sin(a/2); P.qx[i]=s*Math.cos(u)*sa; P.qy[i]=v*sa; P.qz[i]=s*Math.sin(u)*sa; P.qw[i]=Math.cos(a/2);
    const sp=P===PG?16:9; P.wx[i]=rs()*sp; P.wy[i]=rs()*sp; P.wz[i]=rs()*sp; P.sx[i]=sx; P.sy[i]=sy; P.sz[i]=sz; P.age[i]=0; P.life[i]=life; P.hy[i]=Math.max(sx,sy,sz)*(P===PG?.1:.42);
    P.mesh.setColorAt(i,col.setRGB(r,g,b)); P.mesh.instanceColor.needsUpdate=true; }
  const gR=26, gG=11;
  function stepPool(P,dt,isGlass){ let any=false; const mesh=P.mesh, drag=isGlass?Math.pow(.55,dt):Math.pow(.985,dt*60), hdrag=isGlass?.5:.12;
    for(let i=0;i<P.N;i++){ if(!P.on[i]) continue; P.age[i]+=dt;
      if(!P.rest[i]){
        P.vy[i]-=(isGlass?gG:gR)*dt; if(isGlass){ const k=Math.pow(.4,dt); P.vx[i]*=k; P.vz[i]*=k; if(P.vy[i]<-9) P.vy[i]=-9; }
        P.x[i]+=P.vx[i]*dt; P.y[i]+=P.vy[i]*dt; P.z[i]+=P.vz[i]*dt;
        const gy=W.surfaceAt(P.x[i],P.z[i],P.y[i]+.5);
        if(gy<W.WATER_Y+.01&&W.terrainH(P.x[i],P.z[i])<W.WATER_Y&&P.y[i]<W.WATER_Y+.2){ if(!isGlass&&Math.random()<.5) Game.splash&&Game.splash(P.x[i],P.z[i],.35); P.on[i]=0; P.live--; dummy.scale.set(0,0,0); dummy.position.set(0,-9999,0); dummy.updateMatrix(); mesh.setMatrixAt(i,dummy.matrix); any=true; continue; }
        if(P.y[i]-P.hy[i]<gy){ P.y[i]=gy+P.hy[i]; const vn=-P.vy[i];
          if(vn>5&&!isGlass&&Math.random()<.35&&P.sx[i]>.45) FX.dust(P.x[i],gy+.2,P.z[i],1,.8);
          if(vn>2.5){ P.vy[i]=vn*.3; P.vx[i]*=.62; P.vz[i]*=.62; P.wx[i]*=.55; P.wy[i]*=.55; P.wz[i]*=.55; if(isGlass&&Math.random()<.04&&Game.audio&&Game.audio.glassTick) Game.audio.glassTick(P.x[i],gy,P.z[i]); }
          else { P.vy[i]=0; P.vx[i]*=.8; P.vz[i]*=.8; P.wx[i]*=.7; P.wy[i]*=.7; P.wz[i]*=.7; if(P.vx[i]*P.vx[i]+P.vz[i]*P.vz[i]<.35){ P.rest[i]=1; if(isGlass){ const a=Math.random()*3.14159, sy=Math.sin(a), cy=Math.cos(a), sq=.70711; P.qx[i]=-cy*sq; P.qy[i]=sy*sq; P.qz[i]=sy*sq; P.qw[i]=cy*sq; } } } }
        else { P.vx[i]*=drag; P.vz[i]*=drag; }
        /* dönüş */
        const wx=P.wx[i], wy=P.wy[i], wz=P.wz[i], qx=P.qx[i], qy=P.qy[i], qz=P.qz[i], qw=P.qw[i], h=.5*dt;
        let nx=qx+h*(wx*qw+wy*qz-wz*qy), ny=qy+h*(wy*qw+wz*qx-wx*qz), nz=qz+h*(wz*qw+wx*qy-wy*qx), nw=qw+h*(-wx*qx-wy*qy-wz*qz); const l=1/Math.hypot(nx,ny,nz,nw); P.qx[i]=nx*l; P.qy[i]=ny*l; P.qz[i]=nz*l; P.qw[i]=nw*l;
      }
      /* ömür: dinlenince uzun süre kalır, sonra küçülür */
      let k=1; const t=P.age[i], L=P.life[i]; if(t>L){ k=1-(t-L)/1.4; if(k<=0){ P.on[i]=0; P.live--; dummy.scale.set(0,0,0); dummy.position.set(0,-9999,0); dummy.updateMatrix(); mesh.setMatrixAt(i,dummy.matrix); any=true; continue; } }
      if(P.rest[i]&&k>=1&&P.age[i]>.01&&P.rest[i]===2) continue;   // yerleşmiş: matris değişmez
      dummy.position.set(P.x[i],P.y[i],P.z[i]); dummy.quaternion.set(P.qx[i],P.qy[i],P.qz[i],P.qw[i]); dummy.scale.set(P.sx[i]*k,P.sy[i]*k,P.sz[i]*k); dummy.updateMatrix(); mesh.setMatrixAt(i,dummy.matrix); any=true;
      if(P.rest[i]===1&&k>=1) P.rest[i]=2; }
    if(any) mesh.instanceMatrix.needsUpdate=true; }
  const PAL=[[.46,.45,.43],[.38,.37,.36],[.58,.56,.52],[.30,.29,.29]], tmp=[0,0,0];
  /* parçalanma: chunk c, konum (x,y,z) (düşme bitişinde güncel konum), hız, güç(0..1.4) */
  const api={ pools:{PR,PG}, count:()=>PR.live+PG.live };
  api.burst=function(c,x,y,z,vx,vy,vz,pw,o){ o=o||{}; const t=c.t, kind=c.kind, vol=Math.max(.5,c.sx*c.sy*c.sz), qs=Game.quality==="low"?.5:Game.quality==="medium"?.8:Game.quality==="ultra"?1.25:1;
    let nR=kind===1?(o.n||5+Math.min(7,vol*.004)|0):Math.round((8+Math.min(18,vol*.45))*(pw||1)); nR=Math.max(2,Math.round(nR*qs*(o.k||1)));
    const base=Math.cbrt(vol), icol=t&&t.ic?t.ic:null, bx=t?c.x-t.x:0, bz=t?c.z-t.z:0, bl=Math.hypot(bx,bz)||1, ox=bx/bl, oz=bz/bl;
    let br=c.r*.85, bg=c.g*.85, bb=c.b*.85; if(c.burn>.3){ br=bg=bb=.03; } else if(c.frost>.5){ br=.55; bg=.78; bb=.95; }
    const spread=kind===1?(o.spread||2.2):0;
    for(let i=0;i<nR;i++){ const r=Math.random(); let rr,gg,bb2; if(r<.42){ const k=.65+Math.random()*.5; rr=br*k; gg=bg*k; bb2=bb*k; } else if(r<.78){ const p=PAL[(Math.random()*PAL.length)|0], k=.85+Math.random()*.3; rr=p[0]*k; gg=p[1]*k; bb2=p[2]*k; } else if(icol){ const k=.5+Math.random()*.4; rr=icol.r*k; gg=icol.g*k; bb2=icol.b*k; } else { rr=.5; gg=.48; bb2=.44; }
      if(c.burn>.3){ rr=gg=bb2=.03+Math.random()*.03; } else if(c.frost>.5){ rr=.55+Math.random()*.2; gg=.78; bb2=.95; }
      const s=Math.min(1.5,Math.max(.14,base*R(.05,.22)*(kind===1?.5:1))), px=kind===1?x+rs()*spread*2:x+rs()*c.sx*.9, py=kind===1?y+rs()*c.sy*.4:y+rs()*c.sy*.9, pz=kind===1?z+rs()*spread*2:z+rs()*c.sz*.9;
      const out=R(1.5,6.5)*(pw||1), rv=kind===1?2.5:1; spawn(PR,px,py,pz,vx*R(.35,.9)+(ox*out+rs()*4)*rv,vy*R(.3,.8)+R(1.5,8)*(pw||1),vz*R(.35,.9)+(oz*out+rs()*4)*rv,s*R(.7,1.8),s*R(.5,1.3),s*R(.7,1.8),rr,gg,bb2,R(9,24)); }
    /* cam */
    if(kind===0&&t&&(t.style==="w"||t.style==="g"||t.style==="s"||t.style==="k"||t.style==="h"||t.style==="m")&&Game.quality!=="low"){ let nG=Math.round((t.style==="g"?15:9)*qs*(pw||1)); if(o.k&&o.k<1) nG=Math.max(2,Math.round(nG*o.k));
      for(let i=0;i<nG;i++){ const s=R(.25,.85); spawn(PG,x+ox*c.sz*.5+rs()*c.sx*.9,y+rs()*c.sy*.9,z+oz*c.sz*.5+rs()*c.sz*.9,vx*R(.25,.7)+ox*R(1,5)+rs()*3,vy*.4+R(-.5,5),vz*R(.25,.7)+oz*R(1,5)+rs()*3,s,s*R(.6,1.2),1,.8+Math.random()*.2,.9+Math.random()*.1,1,R(4,9)); }
      if(Game.audio&&Game.audio.glass&&!o.quiet) Game.audio.glass(x,y,z); } };
  api.clear=function(){ for(const P of [PR,PG]){ for(let i=0;i<P.N;i++){ if(P.on[i]){ P.on[i]=0; dummy.scale.set(0,0,0); dummy.position.set(0,-9999,0); dummy.updateMatrix(); P.mesh.setMatrixAt(i,dummy.matrix); } } P.live=0; P.mesh.instanceMatrix.needsUpdate=true; } };
  Game.updaters.push(dt=>{ if(Game.mode!=="play") return; if(PR.live) stepPool(PR,dt,false); if(PG.live) stepPool(PG,dt,true); });
  return api;
})();
