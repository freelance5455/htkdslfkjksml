"use strict";
/* ===== DÜNYA: şehir maskesi, arazi yüksekliği, adalar, okyanus (shader), deniz sınırı ===== */
Game.W=(function(){
const W={CELL:34,LOTH:12,R:11.9,WATER_Y:-1.2,WALK_MIN:-1.1,FLOOR:-22};
Game.WATER_Y=W.WATER_Y;
const CELL=W.CELL, cells=new Set(), list=[];
const n2=(x,z)=>Math.sin(x*.013+1.7)*Math.cos(z*.011-.6)*.5+Math.sin(x*.027-z*.021+2.1)*.3+Math.sin(x*.055+z*.047)*.2;
W.noise=n2;
/* şehir maskesi: gürültülü daire (kıyı girintili), doğu kıyısı köprü için kesik (gx<=9); tek başına kalan hücreler atılır */
{ const inM=(gx,gz)=>gx<=9&&Math.hypot(gx,gz)<=W.R+1.15*n2(gx*34*.9+300,gz*34*.9-120);
  const m0=new Set(); for(let gx=-14;gx<=14;gx++)for(let gz=-14;gz<=14;gz++) if(inM(gx,gz)||(gx>=7&&gx<=9&&gz>=-1&&gz<=2)) m0.add(gx+","+gz);
  for(let pass=0;pass<2;pass++) for(const k of [...m0]){ const [gx,gz]=k.split(",").map(Number); let nb=0; for(const [dx,dz] of [[1,0],[-1,0],[0,1],[0,-1]]) if(m0.has((gx+dx)+","+(gz+dz))) nb++; if(nb<2&&!(gx>=7&&gx<=9&&gz>=-1&&gz<=2)) m0.delete(k); }
  for(let gx=-14;gx<=14;gx++)for(let gz=-14;gz<=14;gz++) if(m0.has(gx+","+gz)){ cells.add(gx+","+gz); list.push([gx,gz]); } }
W.cells=list; W.inCity=(gx,gz)=>cells.has(gx+","+gz);
W.islands=[ {id:"luna",x:700,z:17,R:108,type:"flat"}, {id:"tropic",x:-560,z:560,R:100,type:"hill",peak:24}, {id:"ancient",x:60,z:-880,R:150,type:"dune"}, {id:"dragon",x:-860,z:-430,R:150,type:"mount",peak:92} ];
const sm=(a,b,x)=>{ const t=Math.max(0,Math.min(1,(x-a)/(b-a))); return t*t*(3-2*t); };
function shore(d){ if(d<=6) return 0; if(d<=32.7) return -(d-6)*.045; return Math.max(W.FLOOR,-1.2-(d-32.7)*.12); }
function distCity(x,z){ if(x*x+z*z>600*600) return 999; const gx0=Math.round(x/CELL), gz0=Math.round(z/CELL); let m=999;
  for(let i=-2;i<=2;i++)for(let j=-2;j<=2;j++){ const gx=gx0+i, gz=gz0+j; if(!cells.has(gx+","+gz)) continue; const dx=Math.max(Math.abs(x-gx*CELL)-17,0), dz=Math.max(Math.abs(z-gz*CELL)-17,0), d=Math.hypot(dx,dz); if(d<m) m=d; } return m; }
W.distCity=distCity;
function mainH(x,z){ let d=distCity(x,z); if(d>=999) return W.FLOOR; if(d>0) d+=9*n2(x,z)*Math.min(1,d/12)+3; if(d<0) d=0; return shore(d); }
function islandD(I,x,z){ const dx=x-I.x, dz=z-I.z, r=Math.hypot(dx,dz); return r-I.R-9*n2(x*1.3,z*1.3); }
function islandH(I,x,z){ const dx=x-I.x, dz=z-I.z, r=Math.hypot(dx,dz); if(r>I.R+220) return W.FLOOR; const d=islandD(I,x,z); let h=shore(d);
  if(d<6){ if(I.type==="hill"){ const k=Math.max(0,1-Math.pow(r/(I.R*.78),2)); h+=I.peak*Math.pow(k,1.4)+n2(x*2,z*2)*1.6*k; }
    else if(I.type==="dune"){ const k=sm(60,100,r); h+=k*(1.3+1.4*n2(x*1.7,z*1.7)); }
    else if(I.type==="mount"){ h=mountH(I,x,z,h); } }
  return h; }
/* ---------- Ejderha Dağı: tek zirve + sırtlar + vadiler; mağara/ejderha terasları (düz daireler) yamaca oyulur ---------- */
function mountBase(I,x,z,h0){ const dx=x-I.x, dz=z-I.z, r=Math.hypot(dx,dz), a=Math.atan2(dz,dx);
  const k=Math.max(0,1-Math.pow(r/(I.R*.8),2)), rid=.82+.2*Math.sin(a*5+n2(x*.4,z*.4)*3)*Math.min(1,r/40)+.12*n2(x*2.3,z*2.3);
  return h0+I.peak*Math.pow(k,1.25)*rid+n2(x*3,z*3)*2.2*k; }
W.mountFlats=[];   // {kind,x,z,r,h,a}: ejderha inini ve 3 mağara terasını yamaçta düzleştirir (dragon_world.js bunları kullanır)
{ const I=W.islands[3]; for(const [kind,a,r,rad] of [["lair",.46,64,30],["cave",2.2,86,18],["cave",3.9,88,18],["cave",5.3,84,18]]){ const x=I.x+Math.cos(a)*r, z=I.z+Math.sin(a)*r; let h=mountBase(I,x,z,0), c=1;
    for(let i=0;i<8;i++){ h+=mountBase(I,x+Math.cos(i*.785)*rad*.7,z+Math.sin(i*.785)*rad*.7,0); c++; }
    W.mountFlats.push({kind,x,z,r:rad,h:h/c,a}); } }
function mountH(I,x,z,h0){ let h=mountBase(I,x,z,h0);
  for(const f of W.mountFlats){ const d=Math.hypot(x-f.x,z-f.z); if(d<f.r+9){ const t=1-sm(f.r,f.r+9,d); h=h+(f.h-h)*t; } }
  return h; }
W.mountBase=(x,z)=>{ const I=W.islands[3]; return mountBase(I,x,z,shore(Math.max(0,islandD(I,x,z)))); };
const bridgeSlot={deckAt:null}; W.bridge=bridgeSlot;
W.terrainH=function(x,z){ let h=mainH(x,z); for(const I of W.islands){ const v=islandH(I,x,z); if(v>h) h=v; } return h; };
W.landAt=Game.landAt=(x,z)=>W.terrainH(x,z)>W.WATER_Y+.02;
W.walkable=(x,z)=>W.terrainH(x,z)>=W.WALK_MIN;
W.groundAt=Game.groundAt=function(x,z,feetY){ let h=W.terrainH(x,z); if(bridgeSlot.deckAt){ const b=bridgeSlot.deckAt(x,z); if(b!==null&&feetY>=b-1.3&&b>h) h=b; } return h; };
W.surfaceAt=function(x,z,y){ let h=Math.max(W.terrainH(x,z),W.WATER_Y); if(bridgeSlot.deckAt){ const b=bridgeSlot.deckAt(x,z); if(b!==null&&y>=b-.2&&b>h) h=b; } return h; };
Game.rayTerrain=function(ox,oy,oz,dx,dy,dz,maxT){ if(dy>=-1e-6) return -1; let t=0, y=oy;
  for(let i=0;i<260&&t<maxT;i++){ const x=ox+dx*t, z=oz+dz*t; y=oy+dy*t; const H=W.surfaceAt(x,z,y), gap=y-H;
    if(gap<=.05){ let a=Math.max(0,t-Math.max(.5,Math.min(20,(gap<0?-gap:0)+2))), b=t; for(let k=0;k<10;k++){ const m=(a+b)/2; if(oy+dy*m<=W.surfaceAt(ox+dx*m,oz+dz*m,oy+dy*m)) b=m; else a=m; }
      const px=ox+dx*b, pz=oz+dz*b; Game.rayKind=W.terrainH(px,pz)>W.WATER_Y+.02||(bridgeSlot.deckAt&&bridgeSlot.deckAt(px,pz)!==null)?"ground":"water"; return b; }
    t+=Math.max(.6,Math.min(24,gap*.7)); }
  return -1; };

/* ---------- Arazi ağı (adalar ve şehir tabanı) ---------- */
const C=hex=>new THREE.Color(hex).convertSRGBToLinear();
const SAND=C("#e8d5a2"), WET=C("#b49f6c"), UND=C("#7f8c8a"), PAV=C("#9a9da3"), GRASS=C("#4f9b46"), GRASS2=C("#3b7d3a"), ROCK=C("#8b8d8f"), DUNE=C("#dcc58a"), DUNE2=C("#c9ac6c"), PLAZA=C("#8fbf6a"), SNOWC=C("#eef2f6"), ROCK2=C("#6d6a66"), MOSS=C("#5d7a3c");
{ const M=Game.MAP; if(M.sand) SAND.copy(C(M.sand)); if(M.wet) WET.copy(C(M.wet)); if(M.grass) GRASS.copy(C(M.grass)); if(M.grass2) GRASS2.copy(C(M.grass2)); if(M.plaza) PLAZA.copy(C(M.plaza)); }
function colorFn(x,z,h,I,out){
  if(h<W.WATER_Y-.05){ const k=Math.min(1,(W.WATER_Y-h)/6); out.copy(WET).lerp(UND,k); return out; }
  if(!I){ const d=distCity(x,z); if(d<=6) return out.copy(PAV); const k=sm(6,26,d); return out.copy(SAND).lerp(WET,sm(.85,1,k)*.9); }
  const r=Math.hypot(x-I.x,z-I.z), d=islandD(I,x,z);
  if(I.type==="hill"){ if(h>16) return out.copy(ROCK).lerp(GRASS2,Math.max(0,1-(h-16)/5)); if(h>1.8) return out.copy(GRASS).lerp(GRASS2,sm(1.8,14,h)); return out.copy(SAND).lerp(GRASS,sm(.1,1.8,h)); }
  if(I.type==="mount"){ const nz=n2(x*3.7,z*3.7)*.5; if(h>74+nz*6) return out.copy(SNOWC).lerp(ROCK,Math.max(0,1-(h-74)/6)*.5); if(h>34+nz*8) return out.copy(ROCK).lerp(ROCK2,.5+nz).lerp(GRASS2,Math.max(0,1-(h-34)/8)*.45); if(h>2.2) return out.copy(GRASS).lerp(GRASS2,sm(2.2,30,h)).lerp(MOSS,.25*(.5+nz)); return out.copy(SAND).lerp(GRASS,sm(.1,2.2,h)); }
  if(I.type==="dune"){ return out.copy(DUNE).lerp(DUNE2,Math.max(0,Math.min(1,(n2(x*3,z*3)+.5)))*.7).lerp(WET,d>6?sm(6,24,d)*.6:0); }
  if(r<I.R-6) return out.copy(PLAZA).lerp(GRASS,.35+.3*n2(x*3,z*3)); return out.copy(d<=6?PAV:SAND).lerp(WET,d>6?sm(6,26,d)*.9:0); }
function terrainMesh(x0,z0,x1,z1,res,I,skip){
  const nx=Math.round((x1-x0)/res)+1, nz=Math.round((z1-z0)/res)+1, pos=new Float32Array(nx*nz*3), nor=new Float32Array(nx*nz*3), col=new Float32Array(nx*nz*3), uv=new Float32Array(nx*nz*2), idx=new Uint32Array((nx-1)*(nz-1)*6), tc=new THREE.Color();
  const H=new Float32Array(nx*nz);
  for(let j=0;j<nz;j++)for(let i=0;i<nx;i++){ const x=x0+i*res, z=z0+j*res, h=W.terrainH(x,z), k=j*nx+i; H[k]=h; pos[k*3]=x; pos[k*3+1]=h; pos[k*3+2]=z; uv[k*2]=x*.11; uv[k*2+1]=z*.11; }
  for(let j=0;j<nz;j++)for(let i=0;i<nx;i++){ const k=j*nx+i, hl=H[j*nx+Math.max(0,i-1)], hr=H[j*nx+Math.min(nx-1,i+1)], hd=H[Math.max(0,j-1)*nx+i], hu=H[Math.min(nz-1,j+1)*nx+i];
    let ax=hl-hr, az=hd-hu, ay=2*res; const l=Math.hypot(ax,ay,az); nor[k*3]=ax/l; nor[k*3+1]=ay/l; nor[k*3+2]=az/l;
    colorFn(pos[k*3],pos[k*3+2],H[k],I,tc); col[k*3]=tc.r; col[k*3+1]=tc.g; col[k*3+2]=tc.b; }
  let q=0; for(let j=0;j<nz-1;j++)for(let i=0;i<nx-1;i++){ if(skip&&skip(x0+(i+.5)*res,z0+(j+.5)*res)) continue; const a=j*nx+i, b=a+1, c=a+nx, d=c+1; idx[q++]=a; idx[q++]=c; idx[q++]=b; idx[q++]=b; idx[q++]=c; idx[q++]=d; }
  const g=new THREE.BufferGeometry(); g.setAttribute("position",new THREE.BufferAttribute(pos,3)); g.setAttribute("normal",new THREE.BufferAttribute(nor,3)); g.setAttribute("color",new THREE.BufferAttribute(col,3)); g.setAttribute("uv",new THREE.BufferAttribute(uv,2)); g.setIndex(new THREE.BufferAttribute(skip?idx.slice(0,q):idx,1));
  const m=new THREE.Mesh(g,Game.CG.terrainMat); m.receiveShadow=true; scene.add(m); return m; }
Game.CG.terrainMat=Game.CG.std({vertexColors:true,roughness:.97,metalness:0,map:Game.CG.tex(Game.CG.NC,1)});
W.meshes=[terrainMesh(-510,-510,510,510,6,null)];
for(const I of W.islands){ const e=I.R+110; W.meshes.push(terrainMesh(I.x-e,I.z-e,I.x+e,I.z+e,I.type==="mount"?4:5,I)); }

/* ---------- Okyanus: derinlik dokusu + shader ---------- */
const TX0=-1150, TSPAN=2300, TN=640, dd=new Uint8Array(TN*TN*4);
for(let j=0;j<TN;j++)for(let i=0;i<TN;i++){ const x=TX0+(i+.5)/TN*TSPAN, z=TX0+(j+.5)/TN*TSPAN, h=W.terrainH(x,z), k=(j*TN+i)*4;
  dd[k]=Math.max(0,Math.min(255,Math.round((W.WATER_Y-h)/16*255))); dd[k+1]=h>W.WATER_Y?255:0; dd[k+2]=0; dd[k+3]=255; }
const dTex=new THREE.DataTexture(dd,TN,TN,THREE.RGBAFormat); dTex.magFilter=THREE.LinearFilter; dTex.minFilter=THREE.LinearFilter; dTex.generateMipmaps=false; dTex.needsUpdate=true;
const SU=Game.skyU;
const oceanMat=new THREE.ShaderMaterial({transparent:true,depthWrite:false,fog:true,
  uniforms:THREE.UniformsUtils.merge([THREE.UniformsLib.fog,{dmap:{value:dTex},dinfo:{value:new THREE.Vector3(TX0,TX0,TSPAN)},time:{value:0},sunDir:SU.sunDir,sunCol:SU.sunCol,horCol:SU.hor,zenCol:SU.zen,
    deepCol:{value:C("#0b3f66")},shalCol:{value:C("#37c4c2")},night:SU.night}]),
  vertexShader:`varying vec3 vW;
#include <fog_pars_vertex>
void main(){ vec4 wp=modelMatrix*vec4(position,1.0); vW=wp.xyz; vec4 mvPosition=viewMatrix*wp; gl_Position=projectionMatrix*mvPosition;
#include <fog_vertex>
}`,
  fragmentShader:`uniform sampler2D dmap; uniform vec3 dinfo; uniform float time; uniform vec3 sunDir; uniform vec3 sunCol; uniform vec3 horCol; uniform vec3 zenCol; uniform vec3 deepCol; uniform vec3 shalCol; uniform float night;
varying vec3 vW;
#include <fog_pars_fragment>
float h21(vec2 p){ return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453); }
float vn(vec2 p){ vec2 i=floor(p), f=fract(p); f=f*f*(3.-2.*f); return mix(mix(h21(i),h21(i+vec2(1.,0.)),f.x),mix(h21(i+vec2(0.,1.)),h21(i+vec2(1.,1.)),f.x),f.y); }
vec3 wn(vec2 p,float t){ vec2 g=vec2(0.);
  for(int i=0;i<4;i++){ float fi=float(i); float k=.06+fi*.1, sp=.55+fi*.3; vec2 d=vec2(cos(fi*1.9+.3),sin(fi*1.9+.3)); float ph=dot(p,d)*k*6.283+t*sp; g+=d*cos(ph)*k*(.55/(1.+fi*.6)); }
  g+=(vec2(vn(p*.45+t*.18),vn(p*.45-t*.14+7.))-.5)*.16; return normalize(vec3(-g.x*5.5,1.,-g.y*5.5)); }
void main(){
  vec2 uv=(vW.xz-dinfo.xy)/dinfo.z; float depth=texture2D(dmap,uv).r*16.;
  vec3 V=normalize(cameraPosition-vW); float dist=length(cameraPosition-vW);
  vec3 N=wn(vW.xz,time); N=normalize(mix(N,vec3(0.,1.,0.),clamp(dist/900.,0.,.88)));
  float ndv=max(dot(N,V),0.); float fres=.03+.97*pow(1.-ndv,4.5);
  vec3 col=mix(shalCol,deepCol,smoothstep(.2,7.,depth)); col*=(1.-night*.75);
  vec3 R=reflect(-V,N); float up=clamp(R.y,0.,1.); vec3 refl=mix(horCol,zenCol,pow(up,.55));
  col=mix(col,refl,clamp(fres,0.,1.));
  vec3 Rs=reflect(-sunDir,N); float sp=max(dot(Rs,V),0.); col+=sunCol*(pow(sp,150.)*2.4+pow(sp,14.)*.12)*(1.-night*.85);
  float sh=1.-smoothstep(0.,2.4,depth); float wave=sin(depth*7.-time*1.8+vn(vW.xz*.2)*6.)*.5+.5;
  float foam=sh*smoothstep(.3,.9,wave*.65+vn(vW.xz*1.4+time*.2)*.5)*.85; foam=max(foam,(1.-smoothstep(0.,.3,depth))*.9);
  col=mix(col,vec3(.95,.97,1.)*(1.-night*.65),foam);
  float alpha=mix(.5,1.,smoothstep(.1,4.,depth)); alpha=max(alpha,max(foam,fres));
  alpha*=1.-smoothstep(5200.,7800.,max(abs(vW.x-cameraPosition.x),abs(vW.z-cameraPosition.z)));
  gl_FragColor=vec4(col,alpha);
#include <tonemapping_fragment>
#include <encodings_fragment>
#include <fog_fragment>
}`});
const ocean=new THREE.Mesh(new THREE.PlaneGeometry(16000,16000),oceanMat); ocean.rotation.x=-Math.PI/2; ocean.position.y=W.WATER_Y; ocean.renderOrder=2; ocean.frustumCulled=false; scene.add(ocean);
W.ocean=ocean; W.oceanMat=oceanMat;
Game.updaters.push((dt,time)=>{ oceanMat.uniforms.time.value=time; ocean.position.x=Math.round(camera.position.x/500)*500; ocean.position.z=Math.round(camera.position.z/500)*500; });
return W;
})();
