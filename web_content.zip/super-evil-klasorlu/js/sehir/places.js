"use strict";
/* ===== YERLER KAYDI: bank, kafe sandalyesi, market tezgâhı, dükkân önü — NPC yaşamı (oturma, alışveriş) için dünya üretiminde doldurulur ===== */
Game.Places=(function(){
  const list=[], by={}, R=34, api={list,by};
  const rl=v=>17+R*Math.round((v-17)/R);
  api.add=function(kind,x,z,ang,meta){ const p={kind,x,z,ang:ang||0,y:(meta&&meta.y)||0,o:null,meta:meta||null,id:list.length}; list.push(p); (by[kind]||(by[kind]=[])).push(p); return p; };
  /* uzun ekseni x olan bank yola (±z) bakar; uzun ekseni z olan ±x yönüne bakar */
  api.faceZ=(x,z)=>rl(z)>=z?0:Math.PI;
  api.faceX=(x,z)=>rl(x)>=x?Math.PI/2:-Math.PI/2;
  /* bank: iki oturak */
  api.bench=function(x,z,ax,y,ang){ y=y||.57; if(ax){ const a=ang!==undefined?ang:api.faceZ(x,z); api.add("seat",x-.5,z,a,{y,bench:1}); api.add("seat",x+.5,z,a,{y,bench:1}); } else { const a=ang!==undefined?ang:api.faceX(x,z); api.add("seat",x,z-.5,a,{y,bench:1}); api.add("seat",x,z+.5,a,{y,bench:1}); } };
  /* oturak boş mu: sahibi hâlâ o koltuğa gidiyor/oturuyorsa dolu */
  api.free=function(p){ const o=p.o; if(!o) return true; if(o.seat!==p&&!(o.goal&&o.goal.place===p)) return true; if(!o.vis||o.dead) return true; return false; };
  api.near=function(kind,x,z,r,pred){ const a=by[kind]; if(!a) return null; let best=null,bd=r*r; for(const p of a){ const dx=p.x-x, dz=p.z-z, d=dx*dx+dz*dz; if(d<bd&&(!pred||pred(p))){ bd=d; best=p; } } return best; };
  return api; })();
