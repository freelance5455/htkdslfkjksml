"use strict";
/* ===== ŞEHİR ORTAK ÖGELER: zemin levhası, ağaç/lamba/araç listeleri, bayrak, kapı tabelası ===== */
(function(){
/* ---------- STATİK PARÇA İZLEYİCİ: fbox/rbox/cyl/stripeCone/beam/ball ile "F" dizilerine eklenen dikey parçaların kutusunu ve indeks aralığını kaydeder.
   props_break.js bunlardan her birini ayrı ayrı kırılabilir yapar (indeks aralığı sıfırlanır = üçgenler kaybolur; dizi birleştirmeden sonra da aynı sıra korunur). ---------- */
{ const CG0=Game.CG, ST=CG0.statics=[]; let dep=0;
  const rec=(A,n0,n1,i0,i1)=>{ const P=A.pos; let x0=1e9,y0=1e9,z0=1e9,x1=-1e9,y1=-1e9,z1=-1e9; for(let k=n0*3;k<n1*3;k+=3){ const x=P[k],y=P[k+1],z=P[k+2]; if(x<x0)x0=x; if(x>x1)x1=x; if(y<y0)y0=y; if(y>y1)y1=y; if(z<z0)z0=z; if(z>z1)z1=z; }
    const h=y1-y0, w=x1-x0, d=z1-z0; if(h<.5||w>22||d>22||y0<-1||y1>48||(w>7&&d>7&&h<1.3)) return;
    ST.push({A,i0,i1,x0,y0,z0,x1,y1,z1,r:A.col[n0*3],g:A.col[n0*3+1],b:A.col[n0*3+2]}); };
  for(const nm of ["fbox","rbox","cyl","stripeCone","beam","ball"]){ const f=CG0[nm]; if(!f) continue;
    CG0[nm]=function(A){ if(dep>0||!A||A.kind!=="F"||CG0.noTrack) return f.apply(this,arguments); dep++; const n0=A.n, i0=A.ni; let r; try{ r=f.apply(this,arguments); } finally{ dep--; } if(A.ni>i0) rec(A,n0,A.n,i0,A.ni); return r; }; } }
const CG=Game.CG, L=CG.lists={trees:[],lamps:[],tlights:[],cars:[],palms:[],rocks:[],props:[],propMeshes:[]}, pick=CG.pick, rnd=CG.rnd, fbox=CG.fbox, pbox=CG.pbox;
CG.CC=["#d9363e","#2e6fd8","#f2f2f2","#1d1f24","#e8b220","#2a9d5a","#9aa1a8","#f28a2e","#7b3fe4"];
CG.PAL=["#ffffff","#e9f1ff","#ffeedd","#dfe9f3","#f4e6dc","#e6ecdc","#cfe0f8","#f2e4cf","#e2e0ea"];
CG.RC=["#a2503c","#7a4b36","#505b66","#8a3b30","#6b4a3a","#3f4a56"];
CG.slab=(cx,cz,hex,y,w,d)=>fbox(CG.F(cx,cz),cx,0,cz,w||24,y||.12,d||24,hex);
CG.addCar=(x,z,v,col,l,w,h,type)=>L.cars.push({x,z,v,col,l:l||4.2,w:w||1.9,h:h||.85,type,nat:!l,flip:Math.sin(x*12.9898+z*78.233)>0});
CG.flag=(x,z,col)=>{ const A=CG.F(x,z); fbox(A,x,.12,z,.2,10,.2,"#ddd"); fbox(A,x+1.1,8.2,z,2,1.2,.05,col); };
CG.tree=(x,z,s,type)=>L.trees.push([x,z,s||(.9+rnd()*.6),type===undefined?(rnd()<.3?1:0):type]);
CG.palm=(x,z,s)=>L.palms.push([x,z,s||(.9+rnd()*.5),rnd()*6.28]);
CG.lamp=(x,z,dx,dz)=>L.lamps.push([x,z,dx,dz]);
/* kırılabilir sokak/bahçe eşyası kaydı (props_break.js kurar): tür, konum, dönüş, ölçek, renk (tint) */
CG.prop=(k,x,z,ry,o)=>{ o=o||{}; L.props.push({k,x,z,y:o.y===undefined?.12:o.y,ry:ry||0,sx:o.sx||1,sy:o.sy||1,sz:o.sz||1,col:o.col||null}); };
CG.rock=(x,z,s)=>L.rocks.push([x,z,s||(.8+rnd()*1.4),rnd()*6.28]);
/* kapı üstü tabela (kapı parçasına bağlanır: parça yıkılınca tabela da gider) */
CG.doorSign=(t,txt,w,h,bg,fg,dy)=>{ const p=t.doorPos; if(!p||!t.doorChunk) return null; const s=p.s, off=.06, y=t.y0+(dy||5.6), x=p.cx, z=p.cz;
  const m=s===0?CG.sign(txt,w,h,bg,fg,x,y,z+p.sz/2+off,0):s===2?CG.sign(txt,w,h,bg,fg,x,y,z-p.sz/2-off,Math.PI):s===1?CG.sign(txt,w,h,bg,fg,x+p.sx/2+off,y,z,Math.PI/2):CG.sign(txt,w,h,bg,fg,x-p.sx/2-off,y,z,-Math.PI/2);
  CG.attach(t.doorChunk,m); return m; };
/* bir kabuğun herhangi bir paneline düz yazı/tabela bağla (yan: 0..3, panel sırası) */
CG.wallSign=(t,side,txt,w,h,bg,fg,y,k)=>{ const ids=[]; t.walls[0].forEach((id,i)=>{ const c=Game.D.chunks[id]; if(t.pan&&t.pan[i]&&t.pan[i].s===side) ids.push(i); }); if(!ids.length) return null;
  const i=ids[Math.min(ids.length-1,k===undefined?Math.floor(ids.length/2):k)], p=t.pan[i], c=Game.D.chunks[t.walls[0][i]], off=.06;
  const m=side===0?CG.sign(txt,w,h,bg,fg,p.cx,y,p.cz+p.sz/2+off,0):side===2?CG.sign(txt,w,h,bg,fg,p.cx,y,p.cz-p.sz/2-off,Math.PI):side===1?CG.sign(txt,w,h,bg,fg,p.cx+p.sx/2+off,y,p.cz,Math.PI/2):CG.sign(txt,w,h,bg,fg,p.cx-p.sx/2-off,y,p.cz,-Math.PI/2);
  CG.attach(c,m); return m; };
})();
Game.CG.streetCars=function(){};
