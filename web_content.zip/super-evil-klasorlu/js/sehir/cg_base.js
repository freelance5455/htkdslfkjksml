"use strict";
/* ===== ŞEHİR ÜRETİCİ ALTYAPISI (1/2): rastgele, dokular, malzemeler, ilçe geometri dizileri ===== */
Game.CG=(function(){
const CG={}, DS=136, OFF=17;
let seed=(Game.MAP&&Game.MAP.seed)||1337; const rnd=CG.rnd=()=>(seed=(seed*16807)%2147483647)/2147483647;
CG.seed=s=>{ seed=s; };
CG.pick=a=>a[Math.floor(rnd()*a.length)];
CG.C=h=>new THREE.Color(h).convertSRGBToLinear();
CG.co=c=>(typeof c==="string"||typeof c==="number")?CG.C(c):c;
CG.shd=(c,k)=>new THREE.Color(c.r*k,c.g*k,c.b*k);
const cnv=CG.cnv=(w,h)=>{ const c=document.createElement("canvas"); c.width=w; c.height=h; return c; };
/* düşük cihaz: ≥512 px dokular yarı boyuta indirilir (GPU belleği ~4× az, örnekleme ucuz); anizotropi kapalı. Dokular oluşturulduktan sonra yeniden çizilmez (CG.tex yalnızca statik cephe/malzeme dokularında kullanılır). */
const LOWTEX=!!(Game.Device&&Game.Device.low);
const shrink=c=>{ try{ if(!LOWTEX||!c||!c.getContext||(c.width<512&&c.height<512)) return c; const h=document.createElement("canvas"); h.width=Math.max(8,c.width>>1); h.height=Math.max(8,c.height>>1); const q=h.getContext("2d"); q.drawImage(c,0,0,h.width,h.height); return h; }catch(e){ return c; } };
CG.shrink=shrink;
const tex=CG.tex=(c,srgb,rep)=>{ const t=new THREE.CanvasTexture(shrink(c)); t.wrapS=t.wrapT=THREE.RepeatWrapping; t.anisotropy=LOWTEX?1:4; if(srgb) t.encoding=THREE.sRGBEncoding; if(rep) t.repeat.set(rep,rep); return t; };
const std=CG.std=o=>new THREE.MeshStandardMaterial(o);

/* ---------- Cephe dokuları: 3 stil (pencere / cam perde / dükkân vitrini) ---------- */
function win(f,o,e,x,y,w,h,lit,frame){
  f.fillStyle="rgba(0,0,0,.10)"; f.fillRect(x-4,y+h+2,w+8,10);
  f.fillStyle=frame||"#c7ccd2"; f.fillRect(x-5,y-5,w+10,h+10);
  const g=f.createLinearGradient(x,y,x+w*.6,y+h); g.addColorStop(0,"#79a2cc"); g.addColorStop(.5,"#2c4a72"); g.addColorStop(1,"#142840");
  f.fillStyle=g; f.fillRect(x,y,w,h);
  f.fillStyle="rgba(255,255,255,.2)"; f.beginPath(); f.moveTo(x,y); f.lineTo(x+w*.55,y); f.lineTo(x,y+h*.7); f.fill();
  f.fillStyle=frame||"#c7ccd2"; f.fillRect(x+w/2-2,y,4,h); f.fillRect(x,y+h*.42,w,3);
  f.fillStyle="#9aa0a8"; f.fillRect(x-8,y+h+4,w+16,5);
  o.fillStyle="rgb(255,40,235)"; o.fillRect(x,y,w,h);
  if(lit){ const k=Math.random(), c=k<.6?"rgb(255,205,120)":k<.85?"rgb(190,220,255)":"rgb(130,170,255)"; e.fillStyle=c; e.fillRect(x,y,w,h);
    if(Math.random()<.5){ e.fillStyle="rgba(120,60,20,.55)"; e.fillRect(x,y,w*.28,h); e.fillRect(x+w*.72,y,w*.28,h); } } }
function mkWin(){ const S=512, F=cnv(S,S), O=cnv(S,S), E=cnv(S,S), f=F.getContext("2d"), o=O.getContext("2d"), e=E.getContext("2d");
  f.fillStyle="#e9e6df"; f.fillRect(0,0,S,S); o.fillStyle="rgb(255,225,0)"; o.fillRect(0,0,S,S); e.fillStyle="#000"; e.fillRect(0,0,S,S);
  for(let i=0;i<3500;i++){ f.fillStyle=`rgba(0,0,0,${Math.random()*.06})`; f.fillRect(Math.random()*S,Math.random()*S,2,2); }
  for(let r=0;r<4;r++)for(let c=0;c<4;c++) win(f,o,e,c*128+21,r*128+19,86,78,Math.random()<.24);
  return {F,O,E}; }
function mkGlass(){ const S=512, F=cnv(S,S), O=cnv(S,S), E=cnv(S,S), f=F.getContext("2d"), o=O.getContext("2d"), e=E.getContext("2d");
  f.fillStyle="#3b4552"; f.fillRect(0,0,S,S); o.fillStyle="rgb(255,70,255)"; o.fillRect(0,0,S,S); e.fillStyle="#000"; e.fillRect(0,0,S,S);
  const litRow=[Math.random()<.4,Math.random()<.4,Math.random()<.4,Math.random()<.4];
  for(let r=0;r<4;r++)for(let c=0;c<8;c++){ const x=c*64,y=r*128, g=f.createLinearGradient(x,y,x+64,y+90); g.addColorStop(0,"#8fb4d8"); g.addColorStop(.55,"#35557c"); g.addColorStop(1,"#1b3050");
    f.fillStyle="#2e3640"; f.fillRect(x,y+96,64,32); o.fillStyle="rgb(255,140,60)"; o.fillRect(x,y+96,64,32);   // alt panel opak
    f.fillStyle=g; f.fillRect(x+2,y+3,60,92);
    f.fillStyle="rgba(255,255,255,.16)"; f.beginPath(); f.moveTo(x+2,y+3); f.lineTo(x+34,y+3); f.lineTo(x+2,y+60); f.fill();
    f.fillStyle="#aab2bb"; f.fillRect(x,y,64,3); f.fillRect(x,y,2,128);
    if(litRow[r]&&Math.random()<.75||Math.random()<.07){ e.fillStyle=Math.random()<.7?"rgb(255,214,140)":"rgb(190,222,255)"; e.fillRect(x+2,y+3,60,92); } }
  return {F,O,E}; }
function mkShop(){ const W=512,H=256, F=cnv(W,H), O=cnv(W,H), E=cnv(W,H), f=F.getContext("2d"), o=O.getContext("2d"), e=E.getContext("2d");
  f.fillStyle="#e9e6df"; f.fillRect(0,0,W,H); o.fillStyle="rgb(255,225,0)"; o.fillRect(0,0,W,H); e.fillStyle="#000"; e.fillRect(0,0,W,H);
  for(let c=0;c<4;c++){ win(f,o,e,c*128+21,19,86,78,Math.random()<.24);                        // üst kat pencereleri
    const x=c*128, y=128; f.fillStyle="#cfd3d8"; f.fillRect(x,y,128,128);                      // zemin kat vitrin
    for(let a=0;a<8;a++){ f.fillStyle=a%2?"#f4f4f4":"#c9cdd4"; f.fillRect(x+a*16,y,16,24); }  // tente şeritleri (bina rengiyle boyanır)
    const door=(c%2===1); const g=f.createLinearGradient(x,y+30,x+80,y+120); g.addColorStop(0,"#9fc4e4"); g.addColorStop(.5,"#456a94"); g.addColorStop(1,"#243d5c");
    f.fillStyle=g; f.fillRect(x+10,y+34,108,88); o.fillStyle="rgb(255,60,245)"; o.fillRect(x+10,y+34,108,88);
    f.fillStyle="#aab0b8"; f.fillRect(x+62,y+34,4,88); f.fillRect(x+10,y+98,108,3);
    if(door){ f.fillStyle="#5d6b7a"; f.fillRect(x+34,y+50,60,72); f.fillStyle="#d9dde2"; f.fillRect(x+60,y+84,8,3); }
    if(Math.random()<.8){ e.fillStyle="rgb(255,226,170)"; e.fillRect(x+10,y+34,108,88); }
    f.fillStyle="rgba(0,0,0,.18)"; f.fillRect(x,y+24,128,8); }
  return {F,O,E}; }

/* ---------- Ek cephe stilleri: n = kumtaşı blok, p = sıva (düz), b = ahşap tahta ---------- */
function plainOE(S){ const O=cnv(S,S), E=cnv(S,S), o=O.getContext("2d"), e=E.getContext("2d"); o.fillStyle="rgb(255,235,0)"; o.fillRect(0,0,S,S); e.fillStyle="#000"; e.fillRect(0,0,S,S); return {O,E}; }
function mkStone(){ const S=512, F=cnv(S,S), f=F.getContext("2d"), {O,E}=plainOE(S); f.fillStyle="#efe9dc"; f.fillRect(0,0,S,S);
  for(let r=0;r<8;r++){ const off=(r&1)?32:0; for(let c=-1;c<8;c++){ const x=c*64+off, y=r*64; f.fillStyle=Math.random()<.5?`rgba(0,0,0,${Math.random()*.09})`:`rgba(255,255,255,${Math.random()*.25})`; f.fillRect(x,y,64,64);
      f.fillStyle=`rgba(90,70,40,${.04+Math.random()*.08})`; for(let k=0;k<26;k++) f.fillRect(x+Math.random()*60,y+Math.random()*60,2+Math.random()*3,2); } }
  f.strokeStyle="rgba(70,52,30,.55)"; f.lineWidth=3; for(let r=0;r<=8;r++){ f.beginPath(); f.moveTo(0,r*64); f.lineTo(S,r*64); f.stroke(); }
  for(let r=0;r<8;r++){ const off=(r&1)?32:0; for(let c=0;c<=8;c++){ f.beginPath(); f.moveTo(c*64+off,r*64); f.lineTo(c*64+off,r*64+64); f.stroke(); } }
  return {F,O,E}; }
function mkPlaster(){ const S=512, F=cnv(S,S), f=F.getContext("2d"), {O,E}=plainOE(S); f.fillStyle="#f3f0ea"; f.fillRect(0,0,S,S);
  for(let i=0;i<5000;i++){ f.fillStyle=`rgba(${Math.random()<.5?0:120},${Math.random()<.5?0:100},0,${Math.random()*.045})`; f.fillRect(Math.random()*S,Math.random()*S,3,3); }
  for(let r=1;r<4;r++){ f.fillStyle="rgba(0,0,0,.05)"; f.fillRect(0,r*128-1,S,2); }
  return {F,O,E}; }
function mkPlank(){ const S=512, F=cnv(S,S), f=F.getContext("2d"), {O,E}=plainOE(S); f.fillStyle="#ede2cd"; f.fillRect(0,0,S,S);
  for(let c=0;c<16;c++){ f.fillStyle=`rgba(${60+Math.random()*40},${40+Math.random()*30},10,${.05+Math.random()*.12})`; f.fillRect(c*32,0,32,S); f.fillStyle="rgba(40,25,5,.5)"; f.fillRect(c*32,0,2,S);
    for(let k=0;k<7;k++){ f.fillStyle="rgba(60,40,10,.12)"; f.fillRect(c*32+4+Math.random()*22,Math.random()*S,1.5,20+Math.random()*60); }
    if(Math.random()<.5){ f.fillStyle="rgba(50,30,8,.35)"; f.beginPath(); f.ellipse(c*32+16,Math.random()*S,4,6,0,0,6.3); f.fill(); } }
  return {F,O,E}; }

/* ---------- Yeni cepheler: k = tuğla, h = ahşap kaplama + panjur (ev), m = oluklu metal (sanayi) ---------- */
function mkBrick(){ const S=512, F=cnv(S,S), O=cnv(S,S), E=cnv(S,S), f=F.getContext("2d"), o=O.getContext("2d"), e=E.getContext("2d");
  f.fillStyle="#a9a39a"; f.fillRect(0,0,S,S); o.fillStyle="rgb(255,225,0)"; o.fillRect(0,0,S,S); e.fillStyle="#000"; e.fillRect(0,0,S,S);
  for(let r=0;r<47;r++){ const y=r*11, off=(r&1)?16:0; for(let c=-1;c<17;c++){ const x=c*32+off, v=.84+Math.random()*.16; f.fillStyle="rgb("+((238*v)|0)+","+((232*v)|0)+","+((222*v)|0)+")"; f.fillRect(x+1,y+1,30,9);
      if(Math.random()<.12){ f.fillStyle="rgba(60,30,10,.16)"; f.fillRect(x+1,y+1,30,9); } } }
  for(let i=0;i<2400;i++){ f.fillStyle="rgba(0,0,0,"+(Math.random()*.05)+")"; f.fillRect(Math.random()*S,Math.random()*S,2,2); }
  for(let r=0;r<4;r++)for(let c=0;c<4;c++){ const x=c*128+21, y=r*128+19; f.fillStyle="#f4f1ea"; f.fillRect(x-9,y-13,86+18,7); f.fillStyle="rgba(0,0,0,.18)"; f.fillRect(x-9,y-6,86+18,2); win(f,o,e,x,y,86,78,Math.random()<.24,"#f4f1ea"); }
  return {F,O,E}; }
function mkSiding(){ const S=512, F=cnv(S,S), O=cnv(S,S), E=cnv(S,S), f=F.getContext("2d"), o=O.getContext("2d"), e=E.getContext("2d");
  f.fillStyle="#f2efe8"; f.fillRect(0,0,S,S); o.fillStyle="rgb(255,225,0)"; o.fillRect(0,0,S,S); e.fillStyle="#000"; e.fillRect(0,0,S,S);
  for(let r=0;r<64;r++){ f.fillStyle="rgba(0,0,0,"+(.05+Math.random()*.05)+")"; f.fillRect(0,r*8+6,S,2); f.fillStyle="rgba(255,255,255,.18)"; f.fillRect(0,r*8,S,1); }
  for(let r=0;r<4;r++)for(let c=0;c<4;c++){ const x=c*128+21, y=r*128+19; f.fillStyle="#6c7782"; f.fillRect(x-17,y-3,13,h0(78)+6); f.fillRect(x+86+4,y-3,13,h0(78)+6);
      for(let k=0;k<5;k++){ f.fillStyle="rgba(0,0,0,.25)"; f.fillRect(x-15,y+k*16,9,1.5); f.fillRect(x+86+6,y+k*16,9,1.5); }
      win(f,o,e,x,y,86,78,Math.random()<.24,"#fbf9f4"); }
  return {F,O,E}; }
function h0(v){ return v; }
function mkMetal(){ const S=512, F=cnv(S,S), O=cnv(S,S), E=cnv(S,S), f=F.getContext("2d"), o=O.getContext("2d"), e=E.getContext("2d");
  f.fillStyle="#c9ced3"; f.fillRect(0,0,S,S); o.fillStyle="rgb(255,120,120)"; o.fillRect(0,0,S,S); e.fillStyle="#000"; e.fillRect(0,0,S,S);
  for(let c=0;c<64;c++){ f.fillStyle="rgba(255,255,255,.22)"; f.fillRect(c*8,0,2,S); f.fillStyle="rgba(0,0,0,.14)"; f.fillRect(c*8+4,0,2,S); }
  for(let r=1;r<4;r++){ f.fillStyle="rgba(0,0,0,.3)"; f.fillRect(0,r*128,S,3); }
  for(let i=0;i<1600;i++){ f.fillStyle="rgba(90,60,30,"+(Math.random()*.06)+")"; f.fillRect(Math.random()*S,Math.random()*S,3,6); }
  for(let c=0;c<4;c++){ const x=c*128+10, y=128+30; f.fillStyle="#7d858e"; f.fillRect(x-3,y-3,112,50); const g=f.createLinearGradient(x,y,x+100,y+44); g.addColorStop(0,"#8fb4d8"); g.addColorStop(1,"#27406a"); f.fillStyle=g; f.fillRect(x,y,106,44);
    f.fillStyle="#7d858e"; f.fillRect(x+52,y,3,44); o.fillStyle="rgb(255,40,235)"; o.fillRect(x,y,106,44); if(Math.random()<.4){ e.fillStyle="rgb(255,214,140)"; e.fillRect(x,y,106,44); } }
  return {F,O,E}; }
const NC=cnv(128,128); { const q=NC.getContext("2d"); q.fillStyle="#ececec"; q.fillRect(0,0,128,128);
  for(let i=0;i<1800;i++){ q.fillStyle=`rgba(90,90,90,${.05+Math.random()*.12})`; q.fillRect(Math.random()*128,Math.random()*128,2,2); } }
CG.NC=NC;
const wm=(T)=>{ const ot=tex(T.O,false); return std({map:tex(T.F,1),roughnessMap:ot,metalnessMap:ot,roughness:1,metalness:1,emissive:0xffffff,emissiveMap:tex(T.E,1),emissiveIntensity:.35,vertexColors:true}); };
CG.STY={w:{pu:16,pv:16,mat:wm(mkWin())}, g:{pu:16,pv:16,mat:wm(mkGlass())}, s:{pu:16,pv:8,mat:wm(mkShop())}, n:{pu:16,pv:16,mat:wm(mkStone())}, p:{pu:16,pv:16,mat:wm(mkPlaster())}, b:{pu:8,pv:8,mat:wm(mkPlank())}, k:{pu:16,pv:16,mat:wm(mkBrick())}, h:{pu:16,pv:16,mat:wm(mkSiding())}, m:{pu:16,pv:16,mat:wm(mkMetal())}};
CG.flatMat=std({map:tex(NC,1),vertexColors:true,roughness:.85,metalness:0});
CG.waterMat=std({vertexColors:true,roughness:.05,metalness:.2});
CG.roadMat=null;
CG.setNight=k=>{ for(const s in CG.STY) CG.STY[s].mat.emissiveIntensity=.35+k*1.25; };

/* ---------- Büyüyebilen tipli diziler (ilçe başına) ---------- */
function GA(kind,style){ this.kind=kind; this.style=style; this.n=0; this.ni=0; this.cap=2048;
  this.pos=new Float32Array(this.cap*3); this.nor=new Float32Array(this.cap*3); this.uv=new Float32Array(this.cap*2); this.col=new Float32Array(this.cap*3); this.idx=new Uint32Array(this.cap*2); }
function grow(A){ const cap=A.cap*2, f=(o,k)=>{ const n=new Float32Array(cap*k); n.set(o); return n; };
  A.pos=f(A.pos,3); A.nor=f(A.nor,3); A.uv=f(A.uv,2); A.col=f(A.col,3); const ni=new Uint32Array(cap*2); ni.set(A.idx); A.idx=ni; A.cap=cap; }
const arrs=new Map(); CG.arrs=arrs;
CG.arr=function(kind,x,z,style){ const st=style||"w", key=kind+(kind==="W"?st:"")+Math.floor((x+OFF)/DS)+","+Math.floor((z+OFF)/DS); let A=arrs.get(key); if(!A){ A=new GA(kind,st); arrs.set(key,A); } return A; };
CG.W=(x,z,s)=>CG.arr("W",x,z,s); CG.F=(x,z)=>CG.arr("F",x,z); CG.T=(x,z)=>CG.arr("T",x,z); CG.R=(x,z)=>CG.arr("R",x,z);

const PLU=CG.PLU=[.004,.004,.012,.004,.012,.012,.004,.012];
CG.quad=function(A,a,b,c,d,col,uv,col2){
  if(A.n+4>A.cap) grow(A);
  const ux=b[0]-a[0],uy=b[1]-a[1],uz=b[2]-a[2],vx=d[0]-a[0],vy=d[1]-a[1],vz=d[2]-a[2];
  let nx=uy*vz-uz*vy, ny=uz*vx-ux*vz, nz=ux*vy-uy*vx; const l=Math.hypot(nx,ny,nz)||1; nx/=l; ny/=l; nz/=l;
  const n=A.n, P=A.pos, N=A.nor, U=A.uv, K=A.col, flat=Math.abs(ny)>.5;
  for(let i=0;i<4;i++){ const v=i===0?a:i===1?b:i===2?c:d, k=n+i, cc=(col2&&i>=2)?col2:col;
    P[k*3]=v[0]; P[k*3+1]=v[1]; P[k*3+2]=v[2]; N[k*3]=nx; N[k*3+1]=ny; N[k*3+2]=nz; K[k*3]=cc.r; K[k*3+1]=cc.g; K[k*3+2]=cc.b;
    if(uv){ U[k*2]=uv[i*2]; U[k*2+1]=uv[i*2+1]; } else if(flat){ U[k*2]=v[0]*.17; U[k*2+1]=v[2]*.17; } else { U[k*2]=(v[0]+v[2])*.17; U[k*2+1]=v[1]*.17; } }
  const I=A.idx, q=A.ni; I[q]=n; I[q+1]=n+1; I[q+2]=n+2; I[q+3]=n; I[q+4]=n+2; I[q+5]=n+3; A.ni+=6; A.n+=4; };
/* üçgen (koni/küre/kapak için); normal (b-a)x(c-a) yönünde */
CG.tri=function(A,a,b,c,col){
  if(A.n+3>A.cap) grow(A);
  const ux=b[0]-a[0],uy=b[1]-a[1],uz=b[2]-a[2],vx=c[0]-a[0],vy=c[1]-a[1],vz=c[2]-a[2];
  let nx=uy*vz-uz*vy, ny=uz*vx-ux*vz, nz=ux*vy-uy*vx; const l=Math.hypot(nx,ny,nz)||1; nx/=l; ny/=l; nz/=l;
  const n=A.n, P=A.pos, N=A.nor, U=A.uv, K=A.col, flat=Math.abs(ny)>.5;
  for(let i=0;i<3;i++){ const v=i===0?a:i===1?b:c, k=n+i;
    P[k*3]=v[0]; P[k*3+1]=v[1]; P[k*3+2]=v[2]; N[k*3]=nx; N[k*3+1]=ny; N[k*3+2]=nz; K[k*3]=col.r; K[k*3+1]=col.g; K[k*3+2]=col.b;
    if(flat){ U[k*2]=v[0]*.17; U[k*2+1]=v[2]*.17; } else { U[k*2]=(v[0]+v[2])*.17; U[k*2+1]=v[1]*.17; } }
  const q=A.ni; A.idx[q]=n; A.idx[q+1]=n+1; A.idx[q+2]=n+2; A.ni+=3; A.n+=3; };
CG.fbox=function(A,x,y0,z,w,h,d,c){ c=CG.co(c); const x0=x-w/2,x1=x+w/2,z0=z-d/2,z1=z+d/2,y1=y0+h, q=CG.quad;
  q(A,[x0,y0,z1],[x1,y0,z1],[x1,y1,z1],[x0,y1,z1],c); q(A,[x1,y0,z0],[x0,y0,z0],[x0,y1,z0],[x1,y1,z0],c);
  q(A,[x1,y0,z1],[x1,y0,z0],[x1,y1,z0],[x1,y1,z1],c); q(A,[x0,y0,z0],[x0,y0,z1],[x0,y1,z1],[x0,y1,z0],c);
  q(A,[x0,y1,z1],[x1,y1,z1],[x1,y1,z0],[x0,y1,z0],c); };
/* Dönmüş kutu (yön yaw): köprü kabloları, rayları, eğik çatılar vb. için. Merkez (x,y,z), boyut (w,h,d), yaw ve pitch(x ekseni) */
CG.rbox=function(A,x,y,z,w,h,d,yaw,pitch,c){ c=CG.co(c); const cy=Math.cos(yaw),sy=Math.sin(yaw),cp=Math.cos(pitch||0),sp=Math.sin(pitch||0);
  const P=(lx,ly,lz)=>{ const y1=ly*cp-lz*sp, z1=ly*sp+lz*cp; return [x+lx*cy+z1*sy, y+y1, z+(-lx*sy)+z1*cy]; }, hw=w/2,hh=h/2,hd=d/2, q=CG.quad;
  const v=[P(-hw,-hh,hd),P(hw,-hh,hd),P(hw,hh,hd),P(-hw,hh,hd),P(hw,-hh,-hd),P(-hw,-hh,-hd),P(-hw,hh,-hd),P(hw,hh,-hd)];
  q(A,v[0],v[1],v[2],v[3],c); q(A,v[4],v[5],v[6],v[7],c); q(A,v[1],v[4],v[7],v[2],c); q(A,v[5],v[0],v[3],v[6],c); q(A,v[3],v[2],v[7],v[6],CG.shd(c,1.1)); q(A,v[5],v[4],v[1],v[0],CG.shd(c,.6)); };

/* ---------- Yazı tabelaları (aynı yazı = ortak doku) ---------- */
const signCache={}, signGeo={};
CG.sign=function(txt,w,h,bg,fg,x,y,z,ry){ const key=txt+bg+fg; let m=signCache[key];
  if(!m){ const c=cnv(512,Math.round(512*h/w)), q=c.getContext("2d"); q.fillStyle=bg; q.fillRect(0,0,c.width,c.height); q.strokeStyle=fg; q.lineWidth=6; q.strokeRect(5,5,c.width-10,c.height-10);
    q.fillStyle=fg; q.font=`bold ${c.height*.56}px sans-serif`; q.textAlign="center"; q.textBaseline="middle"; q.fillText(txt,c.width/2,c.height/2+3);
    const t=new THREE.CanvasTexture(shrink(c)); t.encoding=THREE.sRGBEncoding; m=signCache[key]=new THREE.MeshBasicMaterial({map:t}); }
  const gk=w+"x"+h, g=signGeo[gk]||(signGeo[gk]=new THREE.PlaneGeometry(w,h)), mesh=new THREE.Mesh(g,m); mesh.position.set(x,y,z); mesh.rotation.y=ry||0; scene.add(mesh); (Game.smallMeshes||(Game.smallMeshes=[])).push(mesh); return mesh; };

/* ---------- Mesh üretimi (tüm içerik eklendikten sonra) ---------- */
CG.walls=[];
CG.finish=function(){
  for(const A of arrs.values()){ if(A.n===0) continue; const gm=new THREE.BufferGeometry(), n=A.n;
    const P=new Float32Array(A.pos.buffer.slice(0,n*12)), N=new Float32Array(A.nor.buffer.slice(0,n*12)), U=new Float32Array(A.uv.buffer.slice(0,n*8)), K=new Float32Array(A.col.buffer.slice(0,n*12)), I=new Uint32Array(A.idx.buffer.slice(0,A.ni*4));
    gm.setAttribute("position",new THREE.Float32BufferAttribute(P,3)); gm.setAttribute("normal",new THREE.Float32BufferAttribute(N,3)); gm.setAttribute("uv",new THREE.Float32BufferAttribute(U,2)); gm.setAttribute("color",new THREE.Float32BufferAttribute(K,3));
    gm.setIndex(new THREE.BufferAttribute(I,1));
    const mat=A.kind==="W"?CG.STY[A.style].mat:A.kind==="T"?CG.waterMat:A.kind==="R"?CG.roadMat:CG.flatMat, m=new THREE.Mesh(gm,mat); m.castShadow=(A.kind==="W"||A.kind==="F"); m.receiveShadow=true; scene.add(m);
    A.geo=gm; A.mesh=m; A.IA=I; A.CA=gm.attributes.color.array; A.ORIG=new Float32Array(A.CA); A.iMin=1e12; A.iMax=-1; A.cMin=1e12; A.cMax=-1; A.dirty=false;
    A.pos=A.nor=A.uv=A.col=A.idx=null;
    if(A.kind==="W") CG.walls.push(A); }
  CG.finished=true; };
return CG;
})();
