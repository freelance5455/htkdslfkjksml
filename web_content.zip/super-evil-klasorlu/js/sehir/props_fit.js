"use strict";
/* ===== ÖGE YERLEŞTİRME DENETİMİ: ağaç / palmiye / kaya / lamba / trafik ışığı / park halindeki araba bina içinde veya birbirinin üstünde olamaz ===== */
(function(){
const CG=Game.CG, L=CG.lists, B=Game.buildings||[], K=30;
const bk=new Map(); const put=(b)=>{ for(let gx=Math.floor((b.x-b.hw-3)/K);gx<=Math.floor((b.x+b.hw+3)/K);gx++) for(let gz=Math.floor((b.z-b.hd-3)/K);gz<=Math.floor((b.z+b.hd+3)/K);gz++){ const k=gx+","+gz; (bk.get(k)||bk.set(k,[]).get(k)).push(b); } };
for(const b of B){ if(b.h<=0) continue; put(b); }
const near=(x,z)=>bk.get(Math.floor(x/K)+","+Math.floor(z/K))||[];
/* nokta (yarıçap r) bir binanın içinde mi? (kalın duvar payı dahil) */
const inside=(x,z,r)=>{ for(const b of near(x,z)){ if(b.y0&&b.y0>3) continue; if(Math.abs(x-b.x)<b.hw+r&&Math.abs(z-b.z)<b.hd+r) return b; } return null; };
const stats={trees:0,palms:0,rocks:0,lamps:0,tl:0,cars:0,carsOverlap:0};
function cullList(arr,fn,key){ for(let i=arr.length-1;i>=0;i--) if(fn(arr[i])){ arr.splice(i,1); stats[key]++; } }
cullList(L.trees,t=>!!inside(t[0],t[1],.55),"trees");
cullList(L.palms,t=>!!inside(t[0],t[1],.55),"palms");
cullList(L.rocks,t=>!!inside(t[0],t[1],.4+t[2]*.9),"rocks");
cullList(L.lamps,t=>!!inside(t[0],t[1],.35),"lamps");
cullList(L.tlights,t=>!!inside(t[0],t[1],.35),"tl");
/* park halindeki arabalar: binaya ya da başka bir arabaya değiyorsa kaldır */
{ const half=c=>{ const l=(c.l||4.2)/2+.25, w=(c.w||1.9)/2+.2; return c.v?[w,l]:[l,w]; }; const grid=new Map(); const keep=[];
  for(const c of L.cars){ const h=half(c); let bad=false;
    for(const b of near(c.x,c.z)){ if(b.y0&&b.y0>3) continue; if(Math.abs(c.x-b.x)<b.hw+h[0]-.35&&Math.abs(c.z-b.z)<b.hd+h[1]-.35){ bad=true; stats.cars++; break; } }
    if(!bad){ const gx=Math.floor(c.x/12), gz=Math.floor(c.z/12); for(let a=gx-1;a<=gx+1&&!bad;a++) for(let d=gz-1;d<=gz+1&&!bad;d++){ for(const o of (grid.get(a+","+d)||[])){ const ho=half(o); if(Math.abs(c.x-o.x)<h[0]+ho[0]&&Math.abs(c.z-o.z)<h[1]+ho[1]){ bad=true; stats.carsOverlap++; break; } } } }
    if(!bad){ keep.push(c); const k=Math.floor(c.x/12)+","+Math.floor(c.z/12); (grid.get(k)||grid.set(k,[]).get(k)).push(c); } }
  L.cars.length=0; for(const c of keep) L.cars.push(c); }
Game.propFit=stats; CG.insideBuilding=inside;
})();
