"use strict";
/* ===== ŞEKİL YARDIMCILARI: statik (birleştirilmiş) silindir/koni/küre/kiriş + dinamik "rig" (dönen/hareket eden parçalar) ===== */
(function(){
const CG=Game.CG, co=CG.co, shd=CG.shd;
const TAU=Math.PI*2;
/* ---------- STATİK (bir GA dizisine yazar) ---------- */
/* eğik kiriş: iki uç nokta arası, kesit t × t2 */
CG.beam=function(A,x0,y0,z0,x1,y1,z1,t,col,t2){ const dx=x1-x0,dy=y1-y0,dz=z1-z0,len=Math.hypot(dx,dy,dz); if(len<1e-4) return;
  CG.rbox(A,(x0+x1)/2,(y0+y1)/2,(z0+z1)/2,t,t2||t,len,Math.atan2(dx,dz),-Math.atan2(dy,Math.hypot(dx,dz)),col); };
/* dikey kesik koni/silindir: tabanda r0, tepede r1 (r1=0 → koni), taban y0, yükseklik h */
CG.cyl=function(A,cx,y0,cz,r0,r1,h,seg,col,capTop,capBot){ col=co(col); seg=seg||12; const y1=y0+h, k=seg, cs=shd(col,.8), ct=shd(col,1.08), cb=shd(col,.55);
  for(let i=0;i<k;i++){ const a0=i/k*TAU, a1=(i+1)/k*TAU, c0=Math.cos(a0),s0=Math.sin(a0),c1=Math.cos(a1),s1=Math.sin(a1);
    const b0=[cx+c0*r0,y0,cz+s0*r0], b1=[cx+c1*r0,y0,cz+s1*r0], t0=[cx+c0*r1,y1,cz+s0*r1], t1=[cx+c1*r1,y1,cz+s1*r1], cc=(i&1)&&col.alt?col.alt:col;
    if(r1>1e-4) CG.quad(A,b1,b0,t0,t1,(i%3===0)?cs:col); else CG.tri(A,b1,b0,t0,(i%3===0)?cs:col);
    if(capTop&&r1>1e-4) CG.tri(A,[cx,y1,cz],t1,t0,ct);
    if(capBot) CG.tri(A,[cx,y0,cz],b0,b1,cb); } };
/* iki renk dönüşümlü dilimli koni (çadır, atlıkarınca çatısı) */
CG.stripeCone=function(A,cx,y0,cz,r0,r1,h,seg,c1,c2){ c1=co(c1); c2=co(c2); const y1=y0+h;
  for(let i=0;i<seg;i++){ const a0=i/seg*TAU, a1=(i+1)/seg*TAU, b0=[cx+Math.cos(a0)*r0,y0,cz+Math.sin(a0)*r0], b1=[cx+Math.cos(a1)*r0,y0,cz+Math.sin(a1)*r0], t0=[cx+Math.cos(a0)*r1,y1,cz+Math.sin(a0)*r1], t1=[cx+Math.cos(a1)*r1,y1,cz+Math.sin(a1)*r1], c=i&1?c2:c1;
    if(r1>1e-4) CG.quad(A,b1,b0,t0,t1,c); else CG.tri(A,b1,b0,t0,c); } };
/* düz disk / halka (üstten görünür) */
CG.disc=function(A,cx,y,cz,r,seg,col,r0){ col=co(col); seg=seg||16; r0=r0||0;
  for(let i=0;i<seg;i++){ const a0=i/seg*TAU, a1=(i+1)/seg*TAU, p0=[cx+Math.cos(a0)*r,y,cz+Math.sin(a0)*r], p1=[cx+Math.cos(a1)*r,y,cz+Math.sin(a1)*r];
    if(r0>0){ const q0=[cx+Math.cos(a0)*r0,y,cz+Math.sin(a0)*r0], q1=[cx+Math.cos(a1)*r0,y,cz+Math.sin(a1)*r0]; CG.quad(A,q1,p1,p0,q0,col); }
    else CG.tri(A,[cx,y,cz],p1,p0,col); } };
/* küre (enlem-boylam) */
CG.ball=function(A,cx,cy,cz,r,col,seg,sy){ col=co(col); seg=seg||8; const rows=Math.max(3,seg>>1), ry=r*(sy||1);
  const pt=(a,b)=>[cx+Math.cos(a)*Math.sin(b)*r, cy+Math.cos(b)*ry, cz+Math.sin(a)*Math.sin(b)*r];
  for(let j=0;j<rows;j++){ const b0=j/rows*Math.PI, b1=(j+1)/rows*Math.PI, cc=shd(col,.7+.3*Math.cos((b0+b1)/2)*.5+.15);
    for(let i=0;i<seg;i++){ const a0=i/seg*TAU, a1=(i+1)/seg*TAU, p00=pt(a0,b0),p10=pt(a1,b0),p01=pt(a0,b1),p11=pt(a1,b1);
      if(j===0) CG.tri(A,p00,p01,p11,cc); else if(j===rows-1) CG.tri(A,p00,p01,p10,cc); else CG.quad(A,p00,p01,p11,p10,cc); } } };

/* ---------- DİNAMİK RIG: kutu/silindir/küre parçalarını tek BufferGeometry'de toplar; mesh olarak döner ---------- */
CG.rigMat=CG.std({vertexColors:true,roughness:.5,metalness:.18});
CG.rigMats=[CG.rigMat];
CG.rig=function(){
  const P=[],N=[],K=[];
  function tf(o){ o=o||{}; const ry=o.ry||0,rx=o.rx||0,rz=o.rz||0,cy=Math.cos(ry),sy=Math.sin(ry),cx=Math.cos(rx),sx=Math.sin(rx),cz=Math.cos(rz),sz=Math.sin(rz);
    return (x,y,z)=>{ const x1=x*cz-y*sz, y1=x*sz+y*cz; const y2=y1*cx-z*sx, z2=y1*sx+z*cx; return [x1*cy+z2*sy, y2, -x1*sy+z2*cy]; }; }
  const R={n:0};
  R.tri=(a,b,c,col)=>{ const ux=b[0]-a[0],uy=b[1]-a[1],uz=b[2]-a[2],vx=c[0]-a[0],vy=c[1]-a[1],vz=c[2]-a[2]; let nx=uy*vz-uz*vy,ny=uz*vx-ux*vz,nz=ux*vy-uy*vx; const l=Math.hypot(nx,ny,nz)||1; nx/=l; ny/=l; nz/=l;
    for(const v of [a,b,c]){ P.push(v[0],v[1],v[2]); N.push(nx,ny,nz); K.push(col.r,col.g,col.b); } R.n+=3; };
  R.quad=(a,b,c,d,col)=>{ R.tri(a,b,c,col); R.tri(a,c,d,col); };
  /* kutu: merkez, boyut, renk, dönüş {ry,rx,rz} (sıra: z,x,y) */
  R.box=(cx,cy,cz,w,h,d,col,o)=>{ col=co(col); const f=tf(o), hw=w/2,hh=h/2,hd=d/2, V=[[-hw,-hh,hd],[hw,-hh,hd],[hw,hh,hd],[-hw,hh,hd],[hw,-hh,-hd],[-hw,-hh,-hd],[-hw,hh,-hd],[hw,hh,-hd]].map(p=>{ const q=f(p[0],p[1],p[2]); return [q[0]+cx,q[1]+cy,q[2]+cz]; });
    R.quad(V[0],V[1],V[2],V[3],col); R.quad(V[4],V[5],V[6],V[7],col); R.quad(V[1],V[4],V[7],V[2],shd(col,.88)); R.quad(V[5],V[0],V[3],V[6],shd(col,.88)); R.quad(V[3],V[2],V[7],V[6],shd(col,1.1)); R.quad(V[5],V[4],V[1],V[0],shd(col,.6)); return R; };
  /* iki nokta arası kiriş */
  R.bar=(x0,y0,z0,x1,y1,z1,t,col,t2)=>{ const dx=x1-x0,dy=y1-y0,dz=z1-z0,len=Math.hypot(dx,dy,dz); if(len<1e-4) return R; return R.box((x0+x1)/2,(y0+y1)/2,(z0+z1)/2,t,t2||t,len,col,{ry:Math.atan2(dx,dz),rx:-Math.atan2(dy,Math.hypot(dx,dz))}); };
  /* silindir/koni: merkez, taban yarıçapı r0, tepe r1, yükseklik h (merkez ortada), seg */
  R.cyl=(cx,cy,cz,r0,r1,h,seg,col,o,caps)=>{ col=co(col); seg=seg||10; const f=tf(o), hh=h/2, cs=shd(col,.82), ct=shd(col,1.1), cb=shd(col,.55), W=(x,y,z)=>{ const q=f(x,y,z); return [q[0]+cx,q[1]+cy,q[2]+cz]; };
    for(let i=0;i<seg;i++){ const a0=i/seg*TAU,a1=(i+1)/seg*TAU,c0=Math.cos(a0),s0=Math.sin(a0),c1=Math.cos(a1),s1=Math.sin(a1), b0=W(c0*r0,-hh,s0*r0), b1=W(c1*r0,-hh,s1*r0), t0=W(c0*r1,hh,s0*r1), t1=W(c1*r1,hh,s1*r1), cc=i%3===0?cs:col;
      if(r1>1e-4) R.quad(b1,b0,t0,t1,cc); else R.tri(b1,b0,t0,cc);
      if(caps!==false){ if(r1>1e-4) R.tri(W(0,hh,0),t1,t0,ct); R.tri(W(0,-hh,0),b0,b1,cb); } } return R; };
  /* iki renk dilimli koni (taban merkez cy-h/2) */
  R.stripeCone=(cx,cy,cz,r0,r1,h,seg,c1,c2,o)=>{ c1=co(c1); c2=co(c2); const f=tf(o), hh=h/2, W=(x,y,z)=>{ const q=f(x,y,z); return [q[0]+cx,q[1]+cy,q[2]+cz]; };
    for(let i=0;i<seg;i++){ const a0=i/seg*TAU,a1=(i+1)/seg*TAU,b0=W(Math.cos(a0)*r0,-hh,Math.sin(a0)*r0), b1=W(Math.cos(a1)*r0,-hh,Math.sin(a1)*r0), t0=W(Math.cos(a0)*r1,hh,Math.sin(a0)*r1), t1=W(Math.cos(a1)*r1,hh,Math.sin(a1)*r1), c=i&1?c2:c1;
      if(r1>1e-4) R.quad(b1,b0,t0,t1,c); else R.tri(b1,b0,t0,c); } return R; };
  /* elipsoid */
  R.ball=(cx,cy,cz,rx,ry,rz,col,seg,o)=>{ col=co(col); seg=seg||8; const rows=Math.max(3,seg>>1), f=tf(o), pt=(a,b)=>{ const q=f(Math.cos(a)*Math.sin(b)*rx, Math.cos(b)*ry, Math.sin(a)*Math.sin(b)*rz); return [q[0]+cx,q[1]+cy,q[2]+cz]; };
    for(let j=0;j<rows;j++){ const b0=j/rows*Math.PI,b1=(j+1)/rows*Math.PI,cc=shd(col,.8+.2*Math.cos((b0+b1)/2));
      for(let i=0;i<seg;i++){ const a0=i/seg*TAU,a1=(i+1)/seg*TAU,p00=pt(a0,b0),p10=pt(a1,b0),p01=pt(a0,b1),p11=pt(a1,b1);
        if(j===0) R.tri(p00,p01,p11,cc); else if(j===rows-1) R.tri(p00,p01,p10,cc); else R.quad(p00,p01,p11,p10,cc); } } return R; };
  /* mesh üret (materyal: varsayılan rigMat; emissive için {basic:true}) */
  R.mesh=(mat,opts)=>{ const g=new THREE.BufferGeometry(), n=R.n, idx=new Uint32Array(n); for(let i=0;i<n;i++) idx[i]=i;
    g.setAttribute("position",new THREE.Float32BufferAttribute(P.slice(),3)); g.setAttribute("normal",new THREE.Float32BufferAttribute(N.slice(),3)); g.setAttribute("color",new THREE.Float32BufferAttribute(K.slice(),3)); g.setIndex(new THREE.BufferAttribute(idx,1));
    const m=new THREE.Mesh(g,mat||CG.rigMat); m.castShadow=!(opts&&opts.noShadow); m.receiveShadow=true; m.frustumCulled=false; return m; };
  R.geo=()=>R.mesh().geometry;
  return R; };
})();
