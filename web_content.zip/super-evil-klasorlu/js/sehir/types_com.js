"use strict";
/* ===== YAPI TİPLERİ (ticari): gökdelen, otel, dükkân sırası, meydan ===== */
(function(){
const CG=Game.CG, rnd=CG.rnd, pick=CG.pick, pbox=CG.pbox, fbox=CG.fbox, co=CG.co, PAL=CG.PAL;
CG.canopy=function(A,p,dg,col,y){ const out=1.7, w=dg+1.6, yy=y||3.7; col=col||"#6b7480";
  if(p.s===0) pbox(A,p.cx,yy,p.cz+p.sz/2+out/2,w,.25,out,col); else if(p.s===2) pbox(A,p.cx,yy,p.cz-p.sz/2-out/2,w,.25,out,col);
  else if(p.s===1) pbox(A,p.cx+p.sx/2+out/2,yy,p.cz,out,.25,w,col); else pbox(A,p.cx-p.sx/2-out/2,yy,p.cz,out,.25,w,col); };
function roofProps(top,A,t){ const x=t.x,z=t.z,hw=t.w/2-2.4,hd=t.d/2-2.4, n=2+Math.floor(rnd()*3); let m=top+1.4;
  for(let i=0;i<n;i++) pbox(A,x+(rnd()-.5)*2*hw,top,z+(rnd()-.5)*2*hd,2.4,1.3,2.4,"#8d939b");
  pbox(A,x+(rnd()-.5)*hw,top,z+(rnd()-.5)*hd,1.8,1.8,1.8,"#a3a9b0");
  if(rnd()<.7){ const hh=6+rnd()*10; pbox(A,x+(rnd()-.5)*hw,top,z+(rnd()-.5)*hd,.4,hh,.4,"#cc3b3b"); m=Math.max(m,top+hh); }
  if(rnd()<.25){ pbox(A,x,top,z,5,.12,5,"#4a5058"); pbox(A,x,top+.12,z,3.2,.06,.5,"#f2f2f2"); pbox(A,x,top+.12,z,.5,.06,3.2,"#f2f2f2"); }
  return m; }
CG.roofProps=roofProps;
const OFFICE=["#dfe6ee","#e8e4dc","#d8e0e8","#ece6dc"];
CG.tower=function(cx,cz,force){ CG.slab(cx,cz,"#d8dadd");
  const dist=Math.hypot(cx,cz), mult=1+2*Math.exp(-Math.pow(dist/130,2)), fl=force||Math.min(46,Math.max(3,Math.floor((3+rnd()*10)*mult)));
  const w=pick([12,14,16,18]), d=pick([12,14,16,18]), x=cx+(rnd()-.5)*1.4, z=cz+(rnd()-.5)*1.4, tint=pick(PAL), h=fl*4, hotel=fl>=8&&rnd()<.12, st=fl>=16&&rnd()<.65?"g":"w";
  const kind=hotel?"hotel":"office", door=Math.floor(rnd()*4), bl=CG.bl();
  const base={x,z,w,d,y0:0,tint:st==="g"?"#c9d8ea":tint,style:st,kind,door,ic:pick(OFFICE),fc:hotel?"#8b3a3a":"#7d8591",cc:"#f2efe8",doorDeco:(A,p,t,dg)=>CG.canopy(A,p,dg,"#4a5260"),panelDeco:CG.deco.trim({ledge:st==="w",cornice:true,plinth:true,col:st==="g"?"#aab4c0":"#e6e8ea",base:"#6e7480"})};
  let top=h, t, t2=null;
  if(fl>14){ const f2=Math.floor(fl*.25), h1=h; t=CG.tier(bl,Object.assign({},base,{h:h1,roof:"none"})); const tw=w-4, td=d-4;
    t2=CG.tier(bl,Object.assign({},base,{x,z,w:tw,d:td,y0:h1,h:f2*4,door:undefined,props:roofProps,roof:"flat"})); top=h1+f2*4; if(hotel) CG.attach(t2.prop,CG.sign("HOTEL",tw*.7,2,"#5b1d1d","#ffd36b",x,top+2.4,z+td/2+.2,0)); }
  else { t=CG.tier(bl,Object.assign({},base,{h,props:roofProps,roof:"flat"})); if(hotel&&t.prop) CG.attach(t.prop,CG.sign("HOTEL",w*.7,2,"#5b1d1d","#ffd36b",x,top+2.4,z+d/2+.2,0)); }
  if(hotel) CG.doorSign(t,"HOTEL",5,1.2,"#5b1d1d","#ffd36b",3.9);
  if(CG.ads) CG.ads(t,{x,z,w:t2?w-4:w,d:t2?d-4:d,top,fl,hotel,prop:(t2||t).prop});
  if(rnd()<.2&&top>36){ const bc=pick(["#ff4d6d","#ffb703","#06d6a0","#4cc9f0"]), A=CG.F(x,z); fbox(A,x,top+3,z+d/2-.6,w*.6,3,.3,bc); }
  CG.streetCars(cx,cz);
  return t; };
const SHOPN=["CAFE","BAKERY","PHARMACY","BOOKS","PIZZA","FLOWERS","MARKET","TECH","SHOES","BARBER","TOYS","BURGER","FASHION","OPTIC"];
const SHOPC=["#c0392b","#2e86c1","#1e8449","#af601a","#7d3c98","#117a65","#b9770e","#2874a6","#a93226","#1f618d"];
CG.shop=function(x,z,w,d,face,tint,floorsUp){ const bl=CG.bl(), nm=pick(SHOPN), side=face>0?0:2;
  const t0=CG.tier(bl,{x,z,w,d,y0:0,h:8,style:"s",tint,kind:"shop",door:side,ic:pick(["#f1ead9","#ece4d2","#e6edf0"]),fc:pick(["#b8a07a","#9ea3a8","#c9b79c"]),roof:floorsUp?"none":"flat",doorDeco:(A,p,t,dg)=>CG.canopy(A,p,dg,pick(SHOPC),3.5),
    props:floorsUp?undefined:(top,A,t)=>{ pbox(A,x-w*.2,top+.5,z,2,1.1,2,"#8d939b"); return top+1.8; }});
  CG.doorSign(t0,nm,6.4,1.2,pick(SHOPC),"#fff",5.9);
  if(floorsUp){ const t1=CG.tier(bl,{x,z,w,d,y0:8,h:floorsUp*4,style:"w",tint,kind:"res",ic:pick(["#efe6d8","#e8dcc8"]),fc:"#a98a62",roof:pick(["flat","flat","gable"]),roofCol:pick(CG.RC),rh:3,props:(top,A,t)=>{ pbox(A,x,top+.5,z-d*.2,1.6,1.4,1.6,"#8d939b"); return top+2; }}); }
  return t0; };
/* ticari sokak hücresi: bir sıra dükkân + meydan eşyaları */
CG.shops=function(cx,cz){ CG.slab(cx,cz,"#dcdee1"); const face=rnd()<.5?1:-1, zc=cz+face*(-1)*0+(-face)*6.2, n=3, ww=7.4, tintBase=pick(PAL);
  for(let i=0;i<n;i++){ const x=cx+(i-1)*(ww+.5); CG.shop(x,cz-face*5.6,ww,11,face,pick(PAL),pick([0,0,1,2])); Game.Places.add("shopdoor",x,cz+face*1.1,face>0?Math.PI:0,{cx,cz,face}); }
  // ön meydan: bankolar, ağaçlar, kafe masaları
  const fz=cz+face*8.5, A=CG.F(cx,cz);
  fbox(A,cx,.12,fz,23,.04,4.2,"#d9d2c0");
  for(let i=0;i<3;i++){ CG.tree(cx-8+i*8,fz+face*1.6,1+rnd()*.3,0); CG.prop("bench",cx-6+i*8,fz-face*.6,face>0?0:Math.PI,{y:.14}); Game.Places.bench(cx-6+i*8,fz-face*.6,true,.64,face>0?0:Math.PI); }
  for(let i=0;i<2;i++){ const tx=cx-3+i*7, tz=fz-face*.2; Game.Places.add("seat",tx-1,tz,Math.PI/2,{y:.64,cafe:1,tx,tz}); Game.Places.add("seat",tx+1,tz,-Math.PI/2,{y:.64,cafe:1,tx,tz}); fbox(A,tx,.14,tz,.12,.9,.12,"#444"); fbox(A,tx,1.0,tz,1.2,.08,1.2,"#f2f2f2"); fbox(A,tx-1,.14,tz,.6,.5,.6,"#c0392b"); fbox(A,tx+1,.14,tz,.6,.5,.6,"#c0392b"); fbox(A,tx,1.1,tz,2.4,.1,2.4,pick(SHOPC)); }
  CG.streetCars(cx,cz); };
/* büyük meydan: çeşme + heykel + banklar (yıkılabilir değil) */
CG.plaza=function(cx,cz){ CG.slab(cx,cz,"#d6d0c2",.14); const A=CG.F(cx,cz), T=CG.T(cx,cz), W="#4ba3e3";
  fbox(A,cx,.14,cz,10,.5,10,"#c8c2b2"); fbox(T,cx,.64,cz,8.6,.2,8.6,W); fbox(A,cx,.14,cz,2.2,2.6,2.2,"#c3c8ce"); fbox(A,cx,2.7,cz,4.6,.3,4.6,"#c3c8ce"); fbox(T,cx,3,cz,3.4,.2,3.4,W); fbox(A,cx,3.2,cz,.8,2.2,.8,"#b7bcc4");
  for(let k=0;k<4;k++){ const a=k*Math.PI/2+Math.PI/4, px=cx+Math.cos(a)*8.5, pz=cz+Math.sin(a)*8.5; CG.prop("bench",px,pz,(cz-pz)>=0?0:Math.PI,{y:.14,sx:2.4/1.8}); for(const o of [-.6,.6]){ Game.Places.add("seat",px+o,pz,Math.atan2(cx-px-o,cz-pz),{y:.64,bench:1}); } CG.tree(cx+Math.cos(a)*10.5,cz+Math.sin(a)*10.5,1.1,0); }
  for(let i=-4;i<=4;i+=2){ fbox(A,cx+i*2.4,.14,cz+11.2,.4,.4,.4,"#999"); fbox(A,cx+i*2.4,.14,cz-11.2,.4,.4,.4,"#999"); }
  CG.lamp(cx+6,cz+6,1,0); CG.lamp(cx-6,cz-6,-1,0); CG.streetCars(cx,cz); };
})();
