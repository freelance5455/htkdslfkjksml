"use strict";
/* ===== YENİ KONUT TASARIMLARI: tudor, bungalov, şehir evi, konak, kulübe, çiftlik evi, ambar, akdeniz villası, tuğla sıra ev, apartman sitesi + mahalle yerleşimleri ===== */
(function(){
const CG=Game.CG, rnd=CG.rnd, pick=CG.pick, pbox=CG.pbox, fbox=CG.fbox, GR=()=>Game.MAP.grass||"#5aa845";
const FWD=[[0,1],[1,0],[0,-1],[-1,0]];
/* parsel kıskacı: bir nesne (kenar payı m) hücrenin kendi parseli içinde kalsın -- havuz/posta kutusu yol şeridine taşmasın */
const inLot=(v,m)=>{ const W=Game.W, c=Math.round(v/W.CELL)*W.CELL, h=W.LOTH-m; return c+Math.max(-h,Math.min(h,v-c)); };
CG.inLot=inLot;
/* yerel koordinat: u = ileri (ön cephe yönü), v = sağ. f: 0:+z 1:+x 2:-z 3:-x */
const lp=(x,z,f,u,v)=>{ const a=FWD[f]; return [x+a[0]*u+a[1]*v, z+a[1]*u-a[0]*v]; };
/* W0 = cephe genişliği (yanal), D0 = derinlik (ön-arka) → dünya x,z boyutları */
const dim=(f,W0,D0)=>(f===1||f===3)?[D0,W0]:[W0,D0];
const BRICK=["#e3a98f","#d99b80","#e8b79a","#cf8f78","#dcb08c","#c98a70"], SIDE=["#f2e6d0","#cfe0e8","#e6d6c4","#d9e4c9","#f0d3c9","#e8e0c8","#dfe3ee","#f4ecd2"], PLAS=["#f6efe2","#f3e0c4","#efe3d0","#f2d9c4","#e9eef2"], IC=["#efe6d8","#e8dcc8","#dfe6dc","#e9d9d4","#e4e8ee"];
const ROOFC=["#8a3b30","#6b4a3a","#505b66","#7a4b36","#3f4a56","#5b3a2e"], TERRA="#c4623b";
const FL=()=>pick(["#a98a62","#9b8668","#b59d7a"]);
/* --- bahçe öğeleri (statik) --- */
function hedge(A,x,z,w,d,c){ x=inLot(x,w/2+2); z=inLot(z,d/2+2); /* çit parsel içinde kalsın (yola/kaldırıma taşmasın) */ CG.prop("hedge",x,z,0,{sx:w,sy:.95,sz:d,col:c||pick(["#2f7d32","#3f8f3a","#2a6f33"])}); }
function walk(A,x,z,f,len,w,col){ const p=lp(x,z,f,len/2,0), s=dim(f,w,len); fbox(A,p[0],.12,p[1],s[0],.03,s[1],col||"#cfcfcf"); }
function mailbox(A,x,z){ x=inLot(x,1.8); z=inLot(z,1.8); CG.prop("mailbox",x,z,0,{col:pick(["#c0392b","#2a63c9","#3a3a3a"])}); }
function bed(A,x,z,w,d){ fbox(A,x,.12,z,w,.3,d,"#6b4a33"); const n=Math.max(2,(w*d/.9)|0); for(let i=0;i<n;i++) fbox(A,x+(rnd()-.5)*(w-.4),.4,z+(rnd()-.5)*(d-.4),.3,.28,.3,pick(["#ff5d8f","#ffd23f","#e63946","#f8f8f8","#b388ff","#ff8a3d"])); }
function woodpile(A,x,z,f){ CG.prop("woodpile",x,z,(f===1||f===3)?Math.PI/2:0); }
function fence(A,x0,z0,x1,z1,col){ col=col||"#f1efe8"; const ax=Math.abs(x1-x0)>=Math.abs(z1-z0), L=ax?Math.abs(x1-x0):Math.abs(z1-z0), n=Math.max(1,Math.round(L/2.4)), sx=(L/n)/2.4;
  for(let i=0;i<n;i++){ const t=(i+.5)/n; CG.prop("fence",ax?x0+(x1-x0)*t:x0,ax?z0:z0+(z1-z0)*t,ax?0:Math.PI/2,{sx,col}); } }
CG.gfx={fence,hedge,walk,mailbox,bed,woodpile,lp,dim};
const door=(col,y)=>(A,p,t,dg)=>CG.canopy(A,p,dg,col||"#6b5646",y||3.4);
/* üstte zemin katın iki katı kadar çıkmalı giriş basamakları + sundurma (kapı parçasına bağlı) */
function stoop(A,p,dg,steps){ const a=FWD[p.s], lat=p.s%2===0, n=steps||2, half=lat?p.sz*.5:p.sx*.5;
  for(let k=0;k<n;k++){ const o=half+.3+k*.5; pbox(A,p.cx+(lat?0:a[0]*o),0,p.cz+(lat?a[1]*o:0),lat?dg+.8:.5,.2*(n-k),lat?.5:dg+.8,"#b9b4a8"); } }

/* ---------- tek ev tasarımları ---------- */
/* Tudor: tuğla zemin + çıkmalı sıvalı üst kat, dik beşik çatı, uzun baca */
CG.tudor=function(x,z,f){ const bl=CG.bl(), W0=9, D0=7.6, [w,d]=dim(f,W0,D0), [w2,d2]=dim(f,W0+.9,D0+.9), rc=pick(["#4a3a32","#5b3a2e","#3f4a56"]), along=w2>=d2, A=CG.F(x,z);
  CG.tier(bl,{x,z,w,d,y0:0,h:4,LH:4,style:"k",tint:pick(BRICK),kind:"res",door:f,doorW:1.9,ic:pick(IC),fc:FL(),roof:"none",doorDeco:door("#4a3a2c",3.3),panelDeco:CG.deco.trim({cornice:false,base:"#6e665c"})});
  const t=CG.tier(bl,{x,z,w:w2,d:d2,y0:4,h:4,LH:4,T:.7,style:"p",tint:pick(["#f3ead7","#efe4cc"]),kind:"res",ic:pick(IC),fc:FL(),roof:"gable",roofCol:rc,rh:4.6,
    props:(top,A2)=>{ const cx=along?x+w2*.3:x, cz=along?z:z+d2*.3; pbox(A2,cx,top-3.2,cz,1,4.4,1,"#8a4a38"); pbox(A2,cx,top+1.1,cz,1.3,.3,1.3,"#6e665c"); return top+1.4; }});
  walk(A,x,z,f,D0/2+3.6,1.6); const q=lp(x,z,f,D0/2+4.2,3); hedge(A,q[0],q[1],1.4,1,"#2f7d32"); return t; };
/* Bungalov: yan garajlı tek katlı, kalçalı çatı, ön bahçe */
CG.bungalow=function(x,z,f,opt){ opt=opt||{}; const bl=CG.bl(), tint=pick(SIDE), rc=pick(ROOFC), W0=opt.garage?10.5:9.4, D0=7.4, [w,d]=dim(f,W0,D0), A=CG.F(x,z);
  CG.tier(bl,{x,z,w,d,y0:0,h:4,LH:4,style:"h",tint,kind:"res",door:f,doorW:1.9,ic:pick(IC),fc:FL(),roof:"hip",roofCol:rc,rh:2.8,doorDeco:door("#ffffff",3.3),
    props:(top,A2)=>{ const c=lp(x,z,f,-1,-2.4); pbox(A2,c[0],top-2,c[1],.9,3,.9,"#8a5a4a"); return top+.9; }});
  if(opt.garage){ const gp=lp(x,z,f,-.5,W0/2+2.8), [gw,gd]=dim(f,5.2,6.4); CG.tier(CG.bl(),{x:gp[0],z:gp[1],w:gw,d:gd,y0:0,h:4,LH:4,style:"h",tint,kind:"res",ic:"#d9d2c4",fc:"#9a9a98",roof:"gable",roofCol:rc,rh:2.2});
    const dp=lp(x,z,f,D0/2+2.4,W0/2+2.8), ds=dim(f,4.4,5); fbox(A,dp[0],.12,dp[1],ds[0],.03,ds[1],"#8d8f93"); if(rnd()<.6){ const cp=lp(x,z,f,D0/2+2.4,W0/2+2.8); CG.addCar(cp[0],cp[1],f%2===1,pick(CG.CC)); } }
  walk(A,x,z,f,D0/2+3.2,1.5); const fp=lp(x,z,f,D0/2+1.4,-2.8); bed(A,fp[0],fp[1],3,1.1); };
/* Şehir evi (sıra): dar, 3 katlı tuğla, ledge'li, sundurma basamakları */
CG.townhouse=function(x,z,f,tint,w0){ const bl=CG.bl(), W0=w0||5.8, [w,d]=dim(f,W0,9.2);
  return CG.tier(bl,{x,z,w,d,y0:0,h:12,LH:8,T:.7,style:"k",tint:tint||pick(BRICK),kind:"res",door:f,doorW:1.8,ic:pick(IC),fc:FL(),roof:"flat",slabCol:"#b8b3a8",parCol:"#d9d4c8",panelDeco:CG.deco.trim({ledge:true,col:"#f1ede4",base:"#7d776e"}),
    doorDeco:(A2,p,tt,dg)=>{ CG.canopy(A2,p,dg,pick(["#2a4a7a","#7a2a2a","#2a5a44","#3b3f46"]),3.5); stoop(A2,p,dg,2); },
    props:(top,A2)=>{ pbox(A2,x,top+.4,z,1.2,1.2,1.2,"#8d939b"); return top+1.6; }}); };
/* Konak: simetrik, orta bina + iki kanat, sütunlu giriş */
CG.mansion=function(x,z,f){ const bl=CG.bl(), tint=pick(PLAS), rc=pick(["#505b66","#3f4a56","#6b4a3a"]), W0=10, D0=9.2, [w,d]=dim(f,W0,D0), A=CG.F(x,z);
  CG.tier(bl,{x,z,w,d,y0:0,h:8,LH:8,style:"p",tint,kind:"res",door:f,doorW:3.4,ic:pick(IC),fc:FL(),cc:"#f5f1ea",roof:"hip",roofCol:rc,rh:3.6,panelDeco:CG.deco.trim({col:"#fbf8f2",base:"#9b968c"}),
    doorDeco:(A2,p,tt,dg)=>{ const a=FWD[p.s], lat=p.s%2===0;
      for(const k of [-1.9,-.65,.65,1.9]){ const cx=p.cx+a[0]*2.8+(lat?k:0), cz=p.cz+a[1]*2.8+(lat?0:k); CG.cyl(A2,cx,0,cz,.3,.26,4.6,8,"#f4f0e8",true); }
      const mx=p.cx+a[0]*2.6, mz=p.cz+a[1]*2.6; pbox(A2,mx,4.6,mz,lat?5.6:3.4,.4,lat?3.4:5.6,"#ece6dc"); pbox(A2,mx,5.0,mz,lat?4.4:2.2,.5,lat?2.2:4.4,"#d9d2c4"); stoop(A2,p,5.6,3); }});
  for(const sg of [-1,1]){ const p=lp(x,z,f,-.8,sg*(W0/2+2.5)), [ww,dd]=dim(f,5,8); CG.tier(CG.bl(),{x:p[0],z:p[1],w:ww,d:dd,y0:0,h:8,LH:8,style:"p",tint,kind:"res",ic:pick(IC),fc:FL(),roof:"hip",roofCol:rc,rh:3,panelDeco:CG.deco.trim({col:"#fbf8f2"})}); }
  walk(A,x,z,f,D0/2+7,2.4); for(const s of [-1,1]){ const fp=lp(x,z,f,D0/2+3,s*4.6); bed(A,fp[0],fp[1],4,1.5); } };
/* Kütük kulübe: ahşap, taş baca, odun yığını */
CG.cabin=function(x,z,f){ const bl=CG.bl(), W0=7, D0=6, [w,d]=dim(f,W0,D0), along=w>=d, A=CG.F(x,z);
  CG.tier(bl,{x,z,w,d,y0:0,h:4,LH:4,T:.7,style:"b",tint:pick(["#b98a5a","#a8794a","#c49a68"]),kind:"res",door:f,doorW:1.9,ic:"#e8dcc8",fc:"#9b8668",roof:"gable",roofCol:pick(["#5b4636","#4a3a2c","#6b4a3a"]),rh:2.9,doorDeco:door("#5b4636",3.2),
    props:(top,A2)=>{ const cx=along?x+w*.32:x, cz=along?z:z+d*.32; pbox(A2,cx,top-2.6,cz,.9,3.6,.9,"#8a8d8f"); return top+1; }});
  const wp=lp(x,z,f,-D0/2-.8,W0/2-1.4); woodpile(A,wp[0],wp[1],f); walk(A,x,z,f,D0/2+2.6,1.2,"#8a6a45"); };
/* Çiftlik evi: beyaz, sundurmalı, kırmızı çatı */
CG.farmhouse=function(x,z,f){ const bl=CG.bl(), W0=9.4, D0=7.6, [w,d]=dim(f,W0,D0), along=w>=d, A=CG.F(x,z);
  CG.tier(bl,{x,z,w,d,y0:0,h:8,LH:8,style:"h",tint:pick(["#f6f2ea","#efe9dc","#f1e4cc"]),kind:"res",door:f,doorW:2.4,ic:pick(IC),fc:FL(),roof:"gable",roofCol:pick(["#8a3b30","#6b3a2e","#505b66"]),rh:3.6,panelDeco:CG.deco.trim({cornice:false}),
    doorDeco:(A2,p,tt,dg)=>{ const a=FWD[p.s], lat=p.s%2===0, mx=p.cx+a[0]*1.7, mz=p.cz+a[1]*1.7; pbox(A2,mx,3.4,mz,lat?dg+3.6:3.4,.25,lat?3.4:dg+3.6,"#f4f1ea"); for(const k of [-1,1]) pbox(A2,p.cx+a[0]*3.1+(lat?k*(dg*.5+1.5):0),0,p.cz+a[1]*3.1+(lat?0:k*(dg*.5+1.5)),.22,3.4,.22,"#f4f1ea"); },
    props:(top,A2)=>{ const cx=along?x+w*.3:x, cz=along?z:z+d*.3; pbox(A2,cx,top-3,cz,1,4,1,"#9a4a3a"); return top+1.1; }});
  walk(A,x,z,f,D0/2+5,1.8,"#d6cdb8"); const mp=lp(x,z,f,D0/2+6,-2.8); mailbox(A,mp[0],mp[1]); };
/* Ambar: kırmızı ahşap, geniş kapı, silo */
CG.barn=function(x,z,f,noSilo){ const bl=CG.bl(), W0=10, D0=15, [w,d]=dim(f,W0,D0), A=CG.F(x,z);
  const t=CG.tier(bl,{x,z,w,d,y0:0,h:6,LH:6,T:.8,style:"b",tint:pick(["#b2463a","#a33a2c","#c25a44"]),kind:"barn",door:f,doorW:5.2,ic:"#d9c9a6",fc:"#a98a62",roof:"gable",roofCol:"#6b6f76",rh:5.2,doorDeco:(A2,p,tt,dg)=>CG.canopy(A2,p,dg,"#f1efe8",5)});
  if(!noSilo){ const sp=lp(x,z,f,-D0/2-2,W0/2+3); CG.cyl(A,sp[0],0,sp[1],2.2,2.2,11,12,"#c9ced3",true); CG.cyl(A,sp[0],11,sp[1],2.2,0,2.4,12,"#9aa0a8"); Game.buildings.push({x:sp[0],z:sp[1],hw:2.3,hd:2.3,h:13.4}); }
  return t; };
/* Akdeniz villası: terakota çatı, balkonlu, palmiye + havuz */
CG.medivilla=function(x,z,f){ const bl=CG.bl(), W0=11.6, D0=9.4, [w,d]=dim(f,W0,D0), A=CG.F(x,z), tint=pick(["#f5e2c4","#f2d9b0","#f6eada"]);
  CG.tier(bl,{x,z,w,d,y0:0,h:8,LH:8,style:"p",tint,kind:"res",door:f,doorW:3,ic:pick(IC),fc:"#b59d7a",roof:"hip",roofCol:TERRA,rh:3.4,panelDeco:CG.deco.trim({col:"#fff8ec",balcony:2,balCol:"#efe3cc",rail:"#6b4a33",base:"#a89880"}),doorDeco:door("#c4623b",3.5),
    props:(top,A2)=>{ pbox(A2,x,top-1,z,1.2,1.8,1.2,"#c9a074"); return top+.9; }});
  const pp=lp(x,z,f,-D0/2-4.2,0), ps=dim(f,8,4.4); pp[0]=inLot(pp[0],ps[0]/2+1.4); pp[1]=inLot(pp[1],ps[1]/2+1.4); fbox(A,pp[0],.12,pp[1],ps[0]+1.6,.06,ps[1]+1.6,"#efe3cc"); fbox(CG.T(x,z),pp[0],.16,pp[1],ps[0],.1,ps[1],"#3fb5e8");
  walk(A,x,z,f,D0/2+4,2,"#e4d6b8"); for(let i=0;i<2;i++){ const q=lp(x,z,f,D0/2+1.5,(i?1:-1)*(W0/2+1)); CG.palm(inLot(q[0],1.4),inLot(q[1],1.4),.8+rnd()*.3); } };
/* Tuğla sıra evler (n adet, farklı tonlarda) */
CG.terrace=function(cx,cz,f,n,span){ const w0=span/n;
  for(let i=0;i<n;i++){ const p=lp(cx,cz,f,0,(i-(n-1)/2)*w0), tc=i%2?pick(BRICK):pick(["#e8d2a8","#d9c19a","#e6c4b0","#cfd8c9","#d4c3d8"]); CG.townhouse(p[0],p[1],f,tc,w0-.2); walk(CG.F(p[0],p[1]),p[0],p[1],f,4.6+1.2,1.3,"#cfcfcf"); } };
/* Apartman bloğu: 5-7 kat, balkonlu */
CG.aptBlock=function(x,z,f,fl,tint,style){ const bl=CG.bl(), [w,d]=dim(f,18,11), st=style||"k";
  const t=CG.tier(bl,{x,z,w,d,y0:0,h:fl*4,LH:8,style:st,tint:tint||pick(st==="k"?BRICK:["#efe6d8","#dfe6ee","#efe2d2","#e4e6d8"]),kind:"res",door:f,doorW:3.4,ic:pick(IC),fc:FL(),cc:"#f2efe8",roof:"flat",doorDeco:door("#55606c",3.6),panelDeco:CG.deco.trim({ledge:true,balcony:2,col:"#eeeae2"}),
    props:(top,A2,tt)=>CG.roofProps(top,A2,tt)});
  CG.doorSign(t,"APT",3.4,1,"#2a4a7a","#fff",4.6); return t; };

/* ---------- mahalle hücre yerleşimleri (24x24 parsel; kaldırım dışı ±10 içinde kal) ---------- */
const grass=(cx,cz)=>CG.slab(cx,cz,GR());
function trees(cx,cz,n,r){ for(let i=0;i<n;i++) CG.tree(cx+(rnd()-.5)*2*r,cz+(rnd()-.5)*2*r,.85+rnd()*.5,rnd()<.2?1:pick([0,0,2,3])); }
const corner=(ox,oz)=>Math.abs(oz)>=Math.abs(ox)?(oz>0?0:2):(ox>0?1:3);
/* Gül mahallesi (eski mahalle): tudor + kulübe + bungalov, meyve ağaçları */
CG.cottageBlock=function(cx,cz){ grass(cx,cz);
  for(const [ox,oz] of [[-5.8,-5.6],[5.8,-5.6],[-5.8,5.6],[5.8,5.6]]){ const f=corner(ox,oz), x=cx+ox, z=cz+oz, r=rnd(); if(r<.4) CG.tudor(x,z,f); else if(r<.7) CG.cabin(x,z,f); else CG.bungalow(x,z,f); }
  trees(cx,cz,5,2.2); return "cottage"; };
/* Villa mahallesi: konak / akdeniz villası + büyük bahçe */
CG.villaBlock=function(cx,cz){ grass(cx,cz); const A=CG.F(cx,cz), r=rnd();
  if(r<.45){ CG.mansion(cx,cz-3.4,0); hedge(A,cx-8,cz+9,6,.6); hedge(A,cx+8,cz+9,6,.6); }
  else if(r<.8){ CG.medivilla(cx-5.6,cz+3.6,0); CG.medivilla(cx+5.6,cz-3.6,2); }   /* iki villa yan yana; havuzlar kendi arkalarında, parsel içinde */
  else { const T=CG.T(cx,cz); CG.house(cx-2.5,cz-5,"villa",0,pick(["#f6efe2","#efe3d0"])); fbox(A,cx+6,.12,cz+6.5,10,.08,6.4,"#e4dccb"); fbox(T,cx+6,.18,cz+6.5,8.6,.1,5,"#3fb5e8"); }
  trees(cx,cz,4,9.5); return "villa"; };
/* Sıra ev mahallesi: tuğla teraslar + yaya yolu */
CG.rowBlock=function(cx,cz){ grass(cx,cz); const A=CG.F(cx,cz);
  CG.terrace(cx,cz-5.9,2,4,21.2); CG.terrace(cx,cz+5.9,0,4,21.2);
  fbox(A,cx,.12,cz,22,.03,2.0,"#d6cdb8"); for(let i=0;i<3;i++) CG.tree(cx-7+i*7,cz,.8+rnd()*.2,pick([0,3]));
  if(rnd()<.6) CG.addCar(cx-3,cz+.1,true,pick(CG.CC)); return "row"; };
/* Apartman mahallesi: blok + otopark + ağaçlar */
CG.aptCourt=function(cx,cz){ grass(cx,cz); const A=CG.F(cx,cz), fl=pick([5,5,6,7]), f1=rnd()<.5?0:2;
  CG.aptBlock(cx,cz-(f1===0?4.4:-4.4),f1,fl,null,rnd()<.6?"k":"p");
  const pz=cz+(f1===0?8:-8); fbox(A,cx,.12,pz,22,.03,5,"#4a4d52"); for(let i=0;i<8;i++){ fbox(A,cx-10+i*2.9,.16,pz,.12,.03,4,"#f2f2f2"); if(rnd()<.6&&i<7) CG.addCar(cx-8.55+i*2.9,pz,false,pick(CG.CC)); /* i=7 son çizginin ötesinde (parsel kenarı/kaldırım) kalıyordu */ }
  for(let i=0;i<2;i++) CG.tree(cx-9.5+i*19,cz+(f1===0?-1:1)*7.5,1+rnd()*.3,pick([0,3])); return "apt"; };
/* Modern mahalle: modern villalar / şehir evleri + bungalov */
CG.modernBlock=function(cx,cz){ grass(cx,cz); const A=CG.F(cx,cz);
  if(rnd()<.5){ CG.house(cx-4.9,cz-5,"modern",0,pick(["#f1f1f1","#e8e6e0","#dcdfe3"])); CG.house(cx+4.9,cz+5,"modern",2,pick(["#f1f1f1","#e8e6e0","#d6dce2"])); const T=CG.T(cx,cz); fbox(T,cx+6,.14,cz-6,6,.1,3.4,"#3fb5e8"); fbox(A,cx+6,.12,cz-6,7.2,.05,4.6,"#e4dccb"); }
  else { CG.terrace(cx,cz-6,2,3,20.4); CG.bungalow(cx-5.2,cz+6,0); CG.bungalow(cx+5.2,cz+6,0); }
  trees(cx,cz,4,9); return "modern"; };
/* Banliyö: 4 ev; yeni tasarımlarla karışık */
CG.suburbBlock=function(cx,cz){ grass(cx,cz);
  for(const [ox,oz] of [[-5.8,-5.6],[5.8,-5.6],[-5.8,5.6],[5.8,5.6]]){ const f=corner(ox,oz), x=cx+ox, z=cz+oz, r=rnd();
    if(r<.3) CG.bungalow(x,z,f); else if(r<.5) CG.tudor(x,z,f); else if(r<.65) CG.farmhouse(x,z,f); else CG.house(x,z,rnd()<.45?"cottage":"sub",f);
    CG.tree(cx+ox*.2,cz+oz*1.85,.9+rnd()*.4,pick([0,0,2,3,1])); }
  return "garden"; };
})();
