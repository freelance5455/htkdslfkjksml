"use strict";
/* ===== ŞEHİR ÜRETİCİ (2/2): içi boş yıkılabilir kabuk — duvar panelleri + zemin/çekirdek + çatı ===== */
(function(){
const CG=Game.CG, D=Game.D={chunks:[],bl:[]}, rnd=CG.rnd, quad=CG.quad, co=CG.co, shd=CG.shd, PLU=CG.PLU;
let BX=null;
CG.pbox=function(A,x,y0,z,w,h,d,col,sh){ col=co(col); const x0=x-w/2,x1=x+w/2,z0=z-d/2,z1=z+d/2,y1=y0+h, c=shd(col,sh||.82);
  quad(A,[x0,y0,z1],[x1,y0,z1],[x1,y1,z1],[x0,y1,z1],col,PLU); quad(A,[x1,y0,z0],[x0,y0,z0],[x0,y1,z0],[x1,y1,z0],col,PLU);
  quad(A,[x1,y0,z1],[x1,y0,z0],[x1,y1,z0],[x1,y1,z1],col,PLU); quad(A,[x0,y0,z0],[x0,y0,z1],[x0,y1,z1],[x0,y1,z0],col,PLU);
  quad(A,[x0,y1,z1],[x1,y1,z1],[x1,y1,z0],[x0,y1,z0],c,PLU);
  if(BX) BX.push(x0,y0,z0,x1,y1,z1); };
const pbox=CG.pbox;
function reg(t,L,ci,kind,A,vs,is,x,y,z,sx,sy,sz,col,bx){
  const c={id:D.chunks.length,t,L,ci,kind,dg:A,vs,vc:A.n-vs,is,ic:A.ni-is,x,y,z,sx,sy,sz,r:col.r,g:col.g,b:col.b,alive:true,pend:-1,burn:0,frost:0,bx:bx,att:null};
  D.chunks.push(c); t.chunks.push(c); return c; }
CG.attach=function(c,mesh){ (c.att||(c.att=[])).push(mesh); return mesh; };

/* Bir kutuyu (panel parçası) çizer. s: 0=K(+z) 1=D(+x) 2=G(-z) 3=B(-x) — dış yüz penceresi, iç yüz oda rengi */
function pface(A,x0,y0,z0,x1,y1,z1,s,col,ic,ou,ov,bx0,bz0,sty,ao,low){
  const cs=shd(col,.85), ct=shd(col,.8), ao0=ao?shd(col,.7):col, v0=y0/sty.pv+ov, v1=y1/sty.pv+ov, pu=sty.pu, Ux=p=>ou+(p-bx0)/pu, Uz=p=>ou+(p-bz0)/pu;
  const cz1=s===0?col:(s===2?ic:cs), cz0=s===2?col:(s===0?ic:cs), cx1=s===1?col:(s===3?ic:cs), cx0=s===3?col:(s===1?ic:cs);
  quad(A,[x0,y0,z1],[x1,y0,z1],[x1,y1,z1],[x0,y1,z1],s===0?ao0:cz1,s===0?[Ux(x0),v0,Ux(x1),v0,Ux(x1),v1,Ux(x0),v1]:PLU,s===0?col:undefined);
  quad(A,[x1,y0,z0],[x0,y0,z0],[x0,y1,z0],[x1,y1,z0],s===2?ao0:cz0,s===2?[Ux(x1),v0,Ux(x0),v0,Ux(x0),v1,Ux(x1),v1]:PLU,s===2?col:undefined);
  quad(A,[x1,y0,z1],[x1,y0,z0],[x1,y1,z0],[x1,y1,z1],s===1?ao0:cx1,s===1?[Uz(z1),v0,Uz(z0),v0,Uz(z0),v1,Uz(z1),v1]:PLU,s===1?col:undefined);
  quad(A,[x0,y0,z0],[x0,y0,z1],[x0,y1,z1],[x0,y1,z0],s===3?ao0:cx0,s===3?[Uz(z0),v0,Uz(z1),v0,Uz(z1),v1,Uz(z0),v1]:PLU,s===3?col:undefined);
  quad(A,[x0,y1,z1],[x1,y1,z1],[x1,y1,z0],[x0,y1,z0],ct,PLU);
  if(low) quad(A,[x0,y0,z0],[x1,y0,z0],[x1,y0,z1],[x0,y0,z1],shd(ic,.85),PLU); }

/* Çatı: flat | gable | hip | none */
function roofGeo(t,A,top,o){ const x=t.x,z=t.z,w=t.w,d=t.d, rc=co(o.roofCol||"#7a4b36"), tp=t.col, ty=o.roof||"flat", ov=.35;
  if(ty==="none") return top;
  if(ty==="flat"){ const sl=.5, c=co(o.slabCol||"#cfd2d6");
    pbox(A,x,top,z,w+.3,sl,d+.3,c,.9);
    const pc=co(o.parCol||"#bfc3c8"), ph=.6, hh=top+sl; pbox(A,x,hh,z+d/2+.05,w+.3,ph,.35,pc); pbox(A,x,hh,z-d/2-.05,w+.3,ph,.35,pc); pbox(A,x+w/2+.05,hh,z,.35,ph,d-.2,pc); pbox(A,x-w/2-.05,hh,z,.35,ph,d-.2,pc);
    return hh+ph; }
  pbox(A,x,top,z,w+ov*2,.35,d+ov*2,shd(tp,.6),.9);
  const rh=o.rh||Math.min(w,d)*.42, y0=top+.35, y1=y0+rh, X0=x-w/2-ov,X1=x+w/2+ov,Z0=z-d/2-ov,Z1=z+d/2+ov, along=w>=d;
  const k=[1,.82,.7,.6].map(f=>shd(rc,f));
  if(ty==="gable"){
    if(along){ quad(A,[X0,y0,Z1],[X1,y0,Z1],[X1,y1,z],[X0,y1,z],k[0],PLU); quad(A,[X1,y0,Z0],[X0,y0,Z0],[X0,y1,z],[X1,y1,z],k[1],PLU);
      quad(A,[X1,y0,Z1],[X1,y0,Z0],[X1,y1,z],[X1,y1,z],k[2],PLU); quad(A,[X0,y0,Z0],[X0,y0,Z1],[X0,y1,z],[X0,y1,z],k[2],PLU);
      quad(A,[X0,y1,z],[X1,y1,z],[X1,y0,Z1],[X0,y0,Z1],k[3],PLU); quad(A,[X1,y1,z],[X0,y1,z],[X0,y0,Z0],[X1,y0,Z0],k[3],PLU); }
    else { quad(A,[X1,y0,Z1],[X1,y0,Z0],[x,y1,Z0],[x,y1,Z1],k[0],PLU); quad(A,[X0,y0,Z0],[X0,y0,Z1],[x,y1,Z1],[x,y1,Z0],k[1],PLU);
      quad(A,[X0,y0,Z1],[X1,y0,Z1],[x,y1,Z1],[x,y1,Z1],k[2],PLU); quad(A,[X1,y0,Z0],[X0,y0,Z0],[x,y1,Z0],[x,y1,Z0],k[2],PLU);
      quad(A,[x,y1,Z1],[x,y1,Z0],[X1,y0,Z0],[X1,y0,Z1],k[3],PLU); quad(A,[x,y1,Z0],[x,y1,Z1],[X0,y0,Z1],[X0,y0,Z0],k[3],PLU); }
    if(BX){ const n=4; for(let i=0;i<n;i++){ const f0=i/n,f1=(i+1)/n, hh=1-f0, yy0=y0+rh*f0, yy1=y0+rh*f1; if(along) BX.push(X0,yy0,z-(Z1-z)*hh,X1,yy1,z+(Z1-z)*hh); else BX.push(x-(X1-x)*hh,yy0,Z0,x+(X1-x)*hh,yy1,Z1); } }
    return y1; }
  /* hip */
  quad(A,[X0,y0,Z1],[X1,y0,Z1],[x+w*.12,y1,z],[x-w*.12,y1,z],k[0],PLU); quad(A,[X1,y0,Z0],[X0,y0,Z0],[x-w*.12,y1,z],[x+w*.12,y1,z],k[1],PLU);
  quad(A,[X1,y0,Z1],[X1,y0,Z0],[x+w*.12,y1,z],[x+w*.12,y1,z],k[2],PLU); quad(A,[X0,y0,Z0],[X0,y0,Z1],[x-w*.12,y1,z],[x-w*.12,y1,z],k[2],PLU);
  if(BX){ for(let i=0;i<4;i++){ const f0=i/4, hh=1-f0; BX.push(x-(w/2+ov)*hh,y0+rh*f0,z-(d/2+ov)*hh,x+(w/2+ov)*hh,y0+rh*(i+1)/4,z+(d/2+ov)*hh); } }
  return y1; }

/* ------------------------------------------------------------------
   CG.tier(bl,o): içi boş bir kat dizisi üretir.
   o: x,z,w,d,y0,h, tint, style(w|g|s), LH(8), T(.8), kind, ic/fc/cc (oda/zemin/tavan rengi), door(0..3 yan; zemin kat girişi),
      roof:{flat|gable|hip|none}, roofCol, rh, props(top,A,t)->üst yükseklik, interior:false (çekirdek yok) */
CG.tier=function(bl,o){
  const x=o.x,z=o.z,w=o.w,d=o.d,y0=o.y0||0,h=o.h,LH=o.LH||8,T=o.T||.8,st=o.style||"w",sty=CG.STY[st];
  const col=co(o.tint||"#ffffff"), ic=co(o.ic||"#ece6d8"), fc=co(o.fc||"#a98a62"), cc=co(o.cc||"#f2efe8"), A=CG.W(x,z,st), nL=Math.max(1,Math.ceil(h/LH-1e-6));
  const t={bl,x,z,w,d,y0,h,LH,T,nL,kind:o.kind||"res",style:st,A,col,walls:[],cores:[],chunks:[],nb:[],prop:null,entry:null,nc:0,door:o.door,doorW:0,floorN:Math.max(1,Math.round(LH/4)),
    ix0:x-w/2+T,ix1:x+w/2-T,iz0:z-d/2+T,iz1:z+d/2-T,fc,ic,cc,rev:[]};
  const ou=Math.floor(rnd()*4)/4, ov=st==="s"?0:Math.floor(rnd()*4)/4, bx0=x-w/2, bz0=z-d/2;
  const nxp=Math.max(1,Math.round(w/5)), cw=w/nxp, nzp=Math.max(1,Math.round((d-2*T)/5)), cd=(d-2*T)/nzp, P=[];
  for(let i=0;i<nxp;i++) P.push({s:0,cx:x-w/2+(i+.5)*cw,cz:z+d/2-T/2,sx:cw,sz:T});
  for(let j=0;j<nzp;j++) P.push({s:1,cx:x+w/2-T/2,cz:z+d/2-T-(j+.5)*cd,sx:T,sz:cd});
  for(let i=0;i<nxp;i++) P.push({s:2,cx:x+w/2-(i+.5)*cw,cz:z-d/2+T/2,sx:cw,sz:T});
  for(let j=0;j<nzp;j++) P.push({s:3,cx:x-w/2+T/2,cz:z-d/2+T+(j+.5)*cd,sx:T,sz:cd});
  t.nc=P.length; t.pan=P;
  let doorIdx=-1; if(o.door!==undefined&&o.door>=0){ const lst=[]; P.forEach((p,i)=>{ if(p.s===o.door) lst.push(i); }); if(lst.length) doorIdx=lst[Math.floor(lst.length/2)]; }
  const iw=w-2*T, id=d-2*T, hasCol=iw>=10&&id>=10;
  for(let L=0;L<nL;L++){ const ly0=y0+L*LH, lh=Math.min(LH,h-L*LH), cy=ly0+lh/2; t.walls[L]=[];
    for(let ci=0;ci<P.length;ci++){ const p=P[ci], vs=A.n, is=A.ni, x0=p.cx-p.sx/2,x1=p.cx+p.sx/2,z0=p.cz-p.sz/2,z1=p.cz+p.sz/2, bxs=[];
      const dg=(L===0&&ci===doorIdx)?Math.min(o.doorW||3.2,(p.s===0||p.s===2?p.sx:p.sz)-1.4):0, dh=Math.min(3.6,lh-.6);
      const F=(a,b,c,dd,e,f)=>{ pface(A,a,b,c,dd,e,f,p.s,col,ic,ou,ov,bx0,bz0,sty,L===0,L>0||dg>0); bxs.push(a,b,c,dd,e,f); };
      if(dg>0){ t.doorW=dg; t.doorPos=p;
        if(p.s===0||p.s===2){ const a=p.cx-dg/2,b=p.cx+dg/2; F(x0,ly0,z0,a,ly0+lh,z1); F(b,ly0,z0,x1,ly0+lh,z1); F(a,ly0+dh,z0,b,ly0+lh,z1); }
        else { const a=p.cz-dg/2,b=p.cz+dg/2; F(x0,ly0,z0,x1,ly0+lh,a); F(x0,ly0,b,x1,ly0+lh,z1); F(x0,ly0+dh,a,x1,ly0+lh,b); } }
      else F(x0,ly0,z0,x1,ly0+lh,z1);
      if(dg>0&&o.doorDeco){ BX=bxs; o.doorDeco(A,p,t,dg); BX=null; }
      if(o.panelDeco) o.panelDeco(A,p,L,ly0,lh,t,ci);
      const ch=reg(t,L,ci,0,A,vs,is,p.cx,cy,p.cz,p.sx,lh,p.sz,col,bxs); t.walls[L][ci]=ch.id; if(dg>0) t.doorChunk=ch; }
    if(o.interior!==false){ const vs=A.n, is=A.ni, bxs=[], nf=Math.ceil(lh/4-1e-6), tc=shd(fc,1), ex=iw+.1, ez=id+.1;
      for(let f=0;f<nf;f++){ const fy=ly0+f*4, sx0=t.ix0-.05, sx1=t.ix1+.05, sz0=t.iz0-.05, sz1=t.iz1+.05, g0=(L===0&&f===0), th=g0?.14:.4;
        quad(A,[sx0,fy+th,sz1],[sx1,fy+th,sz1],[sx1,fy+th,sz0],[sx0,fy+th,sz0],tc,PLU);       // üst
        quad(A,[sx0,fy,sz0],[sx1,fy,sz0],[sx1,fy,sz1],[sx0,fy,sz1],cc,PLU);                      // alt (tavan)
        quad(A,[sx0,fy,sz1],[sx1,fy,sz1],[sx1,fy+th,sz1],[sx0,fy+th,sz1],ic,PLU); quad(A,[sx1,fy,sz0],[sx0,fy,sz0],[sx0,fy+th,sz0],[sx1,fy+th,sz0],ic,PLU);
        quad(A,[sx1,fy,sz1],[sx1,fy,sz0],[sx1,fy+th,sz0],[sx1,fy+th,sz1],ic,PLU); quad(A,[sx0,fy,sz0],[sx0,fy,sz1],[sx0,fy+th,sz1],[sx0,fy+th,sz0],ic,PLU);
        if(!g0) bxs.push(sx0,fy,sz0,sx1,fy+th,sz1); }
      if(hasCol){ pbox(A,x,ly0,z,1.6,lh,1.6,"#b9bdc4"); bxs.push(x-.8,ly0,z-.8,x+.8,ly0+lh,z+.8); }
      t.cores[L]=reg(t,L,-1,1,A,vs,is,x,cy,z,iw,lh,id,fc,bxs).id; } else t.cores[L]=-1; }
  for(let ci=0;ci<P.length;ci++) t.nb[ci]=[(ci+1)%P.length,(ci+P.length-1)%P.length];
  let topY=y0+h;
  if(o.roof!=="none"||o.props){ const vs=A.n, is=A.ni; BX=[]; t.col=col; const oy=o.props?o.props:null;
    let ty=roofGeo(t,A,y0+h,o); if(oy){ const r=oy(ty,A,t); if(r) ty=Math.max(ty,r); }
    topY=ty; const hh=ty-(y0+h); t.prop=reg(t,nL,-2,2,A,vs,is,x,y0+h+hh/2,z,w*.9,Math.max(.5,hh),d*.9,col,BX); BX=null; }
  const e={x,z,hw:w/2+.4,hd:d/2+.4,h:topY,tier:t}; t.entry=e; t.topY=topY; Game.buildings.push(e); bl.tiers.push(t); return t; };

/* ---- cephe süsleri: dış yüze çıkıntılı kaide/silme/korniş/balkon; panel parçasına dahildir (parça yıkılınca birlikte gider) ---- */
CG.deco={
  trim(o){ o=o||{}; const col=co(o.col||"#ece9e2"), base=co(o.base||"#8b8780"), cn=o.cornice!==false, pl=o.plinth!==false, ledge=!!o.ledge, bal=o.balcony||0, balCol=co(o.balCol||"#d6d3cc"), rail=co(o.rail||"#3b3f46");
    return (A,p,L,ly0,lh,t,ci)=>{ const s=p.s, T=t.T, ox=s===1?1:s===3?-1:0, oz=s===0?1:s===2?-1:0, ax=(s===0||s===2), len=ax?p.sx:p.sz;
      const strip=(y0,h,dep,c)=>{ const off=T*.5+dep*.5-.04; if(ax) pbox(A,p.cx,y0,p.cz+oz*off,len,h,dep,c,.9); else pbox(A,p.cx+ox*off,y0,p.cz,dep,h,len,c,.9); };
      if(pl&&L===0) strip(ly0,.65,.28,base);
      if(cn&&L===t.nL-1) strip(ly0+lh-.4,.4,.55,col);
      if(ledge){ for(let y=ly0+4;y<ly0+lh-.5;y+=4) strip(y-.1,.2,.2,col); }
      if(bal&&L>=1&&(ci%bal===0)){ for(let y=ly0;y<ly0+lh-.5;y+=4){ const off=T*.5+.62, bw=len*.62, dep=1.25;
          if(ax){ pbox(A,p.cx,y,p.cz+oz*off,bw,.22,dep,balCol); pbox(A,p.cx,y+.22,p.cz+oz*(off+dep*.5-.05),bw,.8,.08,rail); pbox(A,p.cx-bw*.5+.04,y+.22,p.cz+oz*off,.08,.8,dep,rail); pbox(A,p.cx+bw*.5-.04,y+.22,p.cz+oz*off,.08,.8,dep,rail); }
          else { pbox(A,p.cx+ox*off,y,p.cz,dep,.22,bw,balCol); pbox(A,p.cx+ox*(off+dep*.5-.05),y+.22,p.cz,.08,.8,bw,rail); pbox(A,p.cx+ox*off,y+.22,p.cz-bw*.5+.04,dep,.8,.08,rail); pbox(A,p.cx+ox*off,y+.22,p.cz+bw*.5-.04,dep,.8,.08,rail); } } } }; }
};
CG.bl=()=>{ const bl={tiers:[]}; D.bl.push(bl); return bl; };
/* ---- parsel sığdırma: kentsel hücrede hiçbir bina ±LIM (kaldırım yolu ±11.6) dışına taşmaz. Küçük taşma (<=1.6 m) tıraşlanır, büyük taşma içeri kaydırılır. ---- */
const LIM=11.0; let CSET=null; const FIT=CG.fitStats={trim:0,shift:0};
const orig=CG.tier;
function fitAxis(c,w){ let half=w/2+.4, lo=c-half, hi=c+half, moved=0;
  if(hi>LIM){ const ov=hi-LIM; if(ov<=1.6&&w-ov>=3.2){ w-=ov; c-=ov/2; FIT.trim++; } else { c-=ov; FIT.shift++; } half=w/2+.4; lo=c-half; hi=c+half; }
  if(lo<-LIM){ const ov=-LIM-lo; if(ov<=1.6&&w-ov>=3.2){ w-=ov; c+=ov/2; FIT.trim++; } else { c+=ov; FIT.shift++; } half=w/2+.4; hi=c+half; if(hi>LIM){ w=Math.max(3.2,2*(LIM-.4)); c=0; } }
  return [c,w]; }
CG.tier=function(bl,o){ const W=Game.W; if(W&&W.cells&&o&&!o.noFit){ if(!CSET){ CSET=new Set(); for(const c of W.cells) CSET.add(c[0]+","+c[1]); }
    const CELL=W.CELL, gx=Math.round(o.x/CELL), gz=Math.round(o.z/CELL);
    if(CSET.has(gx+","+gz)){ const cx=gx*CELL, cz=gz*CELL, a=fitAxis(o.x-cx,o.w), b=fitAxis(o.z-cz,o.d);
      if(a[0]!==o.x-cx||a[1]!==o.w||b[0]!==o.z-cz||b[1]!==o.d) o=Object.assign({},o,{x:cx+a[0],w:a[1],z:cz+b[0],d:b[1]}); } }
  return orig(bl,o); };
})();
