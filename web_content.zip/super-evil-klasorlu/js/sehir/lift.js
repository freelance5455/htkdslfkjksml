"use strict";
/* ===== ELLE KALDIRMA: araba, gemi, jet ski, uçak, helikopter. Boğaz butonu = tut, bırak = indir, yumruk = fırlat ===== */
Game.Lift=(function(){
const H=Game.H, hero=Game.heroObj, Cars=Game.Cars, Sea=Game.Sea, FX=Game.FX, D=Game.D, au=()=>Game.audio, clamp=(v,a,b)=>v<a?a:v>b?b:v, rs=()=>Math.random()-.5;
const qE=new THREE.Euler(0,0,0,"YXZ"), qQ=new THREE.Quaternion(), proj=[];
let cur=null, told=false, bt=0, dripT=0, camAdd=0;
const api={active:false,held:false,target:null,probe,grab,drop,throwIt,weight:0};
const aD=(a,b)=>{ let d=a-b; while(d>Math.PI) d-=6.283185; while(d<-Math.PI) d+=6.283185; return d; };
function probe(d){ const p=hero.position; let best=null;
  if(p.y<22) Cars.query(p.x,p.z,18,(k,i,px,pz,dist)=>{ const dx=px-p.x, dz=pz-p.z, l=Math.hypot(dx,dz)||1, dot=(dx*d.x+dz*d.z)/l; if(dist>4.5&&dot<.1) return; if(!best||dist<best.dist) best={t:"car",k,i,dist}; });
  const s=Sea.nearest(p.x,p.y,p.z,14); if(s&&(!best||s.dist<best.dist)) best={t:"sea",e:s.e,dist:s.dist};
  return best; }
function grab(c){ if(cur||!c) return false; const p=hero.position;
  if(c.t==="car"){ const e=Cars.hold(c.k,c.i); if(!e) return false; const dm=Cars.dimsOf(c.k,c.i), b=e.body;
    cur={t:"car",k:c.k,i:c.i,e,up:dm.H/2,down:dm.H/2,hl:dm.l/2,hw:dm.w/2,w:.6,x:b.position.x,y:b.position.y,z:b.position.z,yaw:Cars.pos(c.k,c.i).ry,pit:0,rol:0,ph:0}; }
  else { const e=c.e; if(!Sea.grab(e)) return false; const d=e.K.d; cur={t:"sea",e,up:d[1],down:d[2],hl:d[3],hw:d[0],w:Math.max(.9,e.K.mass),x:e.x,y:e.y,z:e.z,yaw:e.yaw,pit:e.pit,rol:e.rol,ph:0};
    if(e.K.c!=="a"&&e.y<Game.WATER_Y+3){ Game.splash(e.x,e.z,Math.min(5,1+e.K.mass*.6)); FX.cloud(e.x,Game.WATER_Y+1,e.z,4,e.K.d[3]*.3,3,[.85,.92,1]); } }
  cur.sx=cur.x; cur.sy=cur.y; cur.sz=cur.z; cur.syaw=cur.yaw;
  api.active=true; api.held=true; api.target=cur.t==="sea"?cur.e:null; api.weight=cur.w; bt=0;
  Game.shakeAdd&&Game.shakeAdd(.45+Math.min(.5,cur.w*.08)); if(au()) au().thud(p.x,p.y,p.z);
  FX.dust(p.x,p.y-1,p.z,8,3); if(!told){ told=true; Game.toast&&Game.toast("t_lift",3800); }
  return true; }
function clear(){ cur=null; api.active=false; api.held=false; api.target=null; H.carryK=1; api.weight=0; }
function drop(){ const o=cur; if(!o) return; const d=Game.heroFwd;
  if(o.t==="car"){ Cars.letgo(o.e); Cars.hit(o.k,o.i,H.vel.x*.5+d.x*2,1,H.vel.z*.5+d.z*2,.6); }
  else Sea.release(o.e,H.vel.x*.5+d.x*2,H.vel.y*.4,H.vel.z*.5+d.z*2,false);
  clear(); }
function throwIt(d){ const o=cur; if(!o) return; const fl=H.flying, sp=o.t==="car"?44:clamp(46/Math.sqrt(Math.max(1,o.w)),18,40);
  const vx=d.x*sp+H.vel.x*.5, vy=(fl?d.y*sp:sp*.24+4)+H.vel.y*.3, vz=d.z*sp+H.vel.z*.5;
  if(o.t==="car"){ Cars.letgo(o.e); Cars.hit(o.k,o.i,vx,vy,vz,6,undefined,"throw"); proj.push({k:o.k,i:o.i,t:0,sp:0,boom:false}); }
  else Sea.release(o.e,vx,vy,vz,true);
  FX.shock(hero.position.x,hero.position.y,hero.position.z,14,16); Game.shakeAdd&&Game.shakeAdd(.6); clear(); }
const TG={x:0,y:0,z:0,yaw:0,pit:0,rol:0};
function target(o){ const p=hero.position, yaw=hero.rotation.y, fx=Math.sin(yaw), fz=Math.cos(yaw);
  if(!H.flying){ TG.x=p.x+fx*.3; TG.z=p.z+fz*.3; TG.y=p.y+2.35+o.down; TG.yaw=yaw; TG.pit=0; TG.rol=0; }
  else { const L=Game.lookV, reach=o.hl*.9+3.2; TG.x=p.x+L.x*reach; TG.y=p.y+L.y*reach+o.up*.1; TG.z=p.z+L.z*reach; TG.yaw=yaw; TG.pit=-Math.asin(clamp(L.y,-1,1))*.8; TG.rol=0; } }
function place(o,time,dt){ const ph=o.ph, k=1-Math.exp(-(o.w>3?11:16)*dt), ky=1-Math.exp(-8*dt);
  if(ph<1){ o.ph=Math.min(1,ph+dt/.55); const e=o.ph*o.ph*(3-2*o.ph); o.x=o.sx+(TG.x-o.sx)*e; o.z=o.sz+(TG.z-o.sz)*e; o.y=o.sy+(TG.y-o.sy)*e+Math.sin(e*3.1416)*1.4; o.yaw=o.syaw+aD(TG.yaw,o.syaw)*e; }
  else { o.x+=(TG.x-o.x)*k; o.y+=(TG.y-o.y)*k; o.z+=(TG.z-o.z)*k; o.yaw+=aD(TG.yaw,o.yaw)*ky; }
  o.pit+=(TG.pit+Math.sin(time*5.5)*.012*(H.mv>.1?1:.3)-o.pit)*ky; o.rol+=(TG.rol+Math.sin(time*4.1)*.02*(H.mv>.1?1:.3)-(o.rol))*ky; }
function apply(o){ if(o.t==="car"){ qE.set(o.pit,o.yaw,o.rol); qQ.setFromEuler(qE); Cars.put(o.e,o.x,o.y,o.z,qQ.x,qQ.y,qQ.z,qQ.w); }
  else Sea.place(o.e,o.x,o.y,o.z,o.yaw,o.pit,o.rol); }
Game.updaters.push((dt0,time,raw)=>{ const dt=Math.min(.05,raw||dt0||0); if(!dt) return;
  /* fırlatılan arabalar: bina/zemin darbesi, hızlı çarpma = patlama */
  for(let q=proj.length-1;q>=0;q--){ const r=proj[q]; r.t+=dt; const b=Cars.body(r.k,r.i); if(!b||r.t>6){ proj.splice(q,1); continue; }
    const v=b.velocity, sp=Math.hypot(v.x,v.y,v.z);
    if(sp>12){ const n=D.damageSphere(b.position.x,b.position.y,b.position.z,3.2,.9,sp*.8); if(n>0){ FX.spark(b.position.x,b.position.y,b.position.z,10,12); FX.dust(b.position.x,b.position.y,b.position.z,6,4); v.x*=.7; v.z*=.7; v.y*=.8; } }
    if(!r.boom&&r.t>.15&&r.sp>16&&sp<r.sp*.55){ r.boom=true; Cars.burn(r.k,r.i); const s=Cars.state(r.k,r.i); if(s&&s.burnT) s.burnT=5.1; }
    r.sp=sp; }
  if(!cur){ camAdd+=(0-camAdd)*(1-Math.exp(-3*dt)); H.camAdd=camAdd; return; }
  const o=cur; if(Game.mode!=="play"){ drop(); return; }
  if(o.t==="car"&&(!o.e.body||!o.e.held)){ clear(); return; } if(o.t==="sea"&&o.e.st!=="held"){ clear(); return; }
  target(o); place(o,time,dt); apply(o);
  H.carryK=1/(1+o.w*.18); const wantCam=clamp(o.hl*.75+o.hw*.4,0,30); camAdd+=(wantCam-camAdd)*(1-Math.exp(-3*dt)); H.camAdd=camAdd;
  /* ağırlık hissi: hafif titreme, ıslak gemi damlatır, hızla giderken yapıya sürtünerek hasar verir */
  H.shake=Math.max(H.shake,Math.min(.14,.02*o.w));
  if(o.t==="sea"&&o.e.K.c!=="a"){ dripT-=dt; if(dripT<=0){ dripT=.04; const hx=o.hw*(.4+Math.random()*1.2), cy=Math.cos(o.yaw), sy=Math.sin(o.yaw), lx=(Math.random()<.5?-1:1)*hx, lz=rs()*o.hl*1.6; FX.E(false,o.x+lx*cy+lz*sy,o.y-o.down*.5,o.z-lx*sy+lz*cy,rs()*1.5,-1,rs()*1.5,.9,.35,.2,[.8,.92,1],[.7,.85,1],.7,26,.98); } }
  bt-=dt; if(bt<=0&&H.speed>9){ bt=.25; const r=clamp(Math.max(o.hl,o.hw)*.75,2.5,12), n=D.damageSphere(o.x,o.y,o.z,r,.32,H.speed*.5); if(n>0){ FX.spark(o.x,o.y,o.z,8,10); FX.dust(o.x,o.y,o.z,6,4); H.shake=Math.max(H.shake,.3); H.vel.multiplyScalar(.97); } } });
Game.liftReset=()=>{ if(cur) drop(); clear(); proj.length=0; };
return api;
})();
