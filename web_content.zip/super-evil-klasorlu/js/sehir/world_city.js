"use strict";
/* ===== ŞEHİR YERLEŞİMİ: yol karoları, hücre tipleri, bulvar ortaları, sokak donanımı ===== */
(function(){
const CG=Game.CG, W=Game.W, rnd=CG.rnd, pick=CG.pick, fbox=CG.fbox, CELL=W.CELL, L=CG.lists, C=CG.C;
/* yol dokusu: bir hücre karosu (34 m), yollar karo kenarlarında */
const GC=CG.cnv(512,512), g=GC.getContext("2d"), k=512/CELL, X=m=>(m+17)*k;
g.fillStyle="#35383e"; g.fillRect(0,0,512,512);
for(let i=0;i<9000;i++){ g.fillStyle=Math.random()<.5?"rgba(255,255,255,.04)":"rgba(0,0,0,.08)"; g.fillRect(Math.random()*512,Math.random()*512,2,2); }
for(let i=0;i<40;i++){ g.strokeStyle="rgba(0,0,0,.12)"; g.lineWidth=1; g.beginPath(); const x=Math.random()*512,y=Math.random()*512; g.moveTo(x,y); g.lineTo(x+(Math.random()-.5)*60,y+(Math.random()-.5)*60); g.stroke(); }
g.fillStyle="#e9c13a";
for(const s of [-1,1]) for(let m=-10;m<10;m+=4){ g.fillRect(X(s*17)-2,X(m),4,2*k); g.fillRect(X(m),X(s*17)-2,2*k,4); }
g.fillStyle="#ececec";
for(const sx of [-1,1])for(const sz of [-1,1])for(let m=12.6;m<17;m+=1.4){ g.fillRect(X(sx*m)-.35*k,X(sz*11)-.8*k,.7*k,1.6*k); g.fillRect(X(sx*11)-.8*k,X(sz*m)-.35*k,1.6*k,.7*k); }
const rt=CG.tex(GC,1); rt.wrapS=rt.wrapT=THREE.ClampToEdgeWrapping||1001;
CG.roadMat=CG.std({map:rt,roughness:.9,polygonOffset:true,polygonOffsetFactor:-2,polygonOffsetUnits:-2});
const white=new THREE.Color(1,1,1);
/* SPECIAL: sabit kamu binaları (her zaman kentsel hücre) */
const SPECIAL={"0,0":"police","1,0":"hospital","0,1":"school","1,1":"bigpark","-1,0":"fire","-1,1":"mall","0,-1":"plaza","1,-1":"landmark","-1,-1":"shops",
  "-5,-4":"school","5,4":"police","-4,5":"fire","4,-5":"hospital","-6,3":"mall","6,-3":"plaza","-3,-6":"bigpark","3,6":"shops","7,0":"bigpark","-8,-1":"hospital","0,8":"school","0,-8":"police"};
const D=Game.Districts; D.force(Object.keys(SPECIAL));
/* yol: kenar tabanlı. Kentsel hücrede 4 kenar da yol; kırsal-kırsal kenarda 3 hücrede bir tarla yolu. Yolsuz kenarlar tarla ile dolar (CG.fieldSlab).
   Parsel (|x|,|z|<12) dışındaki 4 şerit + 4 köşe karesi; köşe, bitişik iki kenardan biri yollu ise yol olur. */
const LOT=W.LOTH, EDGES=new Map();
for(const [gx,gz] of W.cells){ const x=gx*CELL,z=gz*CELL, A=CG.R(x,z), X0=x-17, Z1=z+17, e=[D.edgeRoad(gx,gz,0),D.edgeRoad(gx,gz,1),D.edgeRoad(gx,gz,2),D.edgeRoad(gx,gz,3)]; EDGES.set(gx+","+gz,e);
  const rect=(xa,xb,za,zb)=>{ const u=v=>(v-X0)/34, w=v=>(Z1-v)/34;
    CG.quad(A,[xa,.03,zb],[xb,.03,zb],[xb,.03,za],[xa,.03,za],white,[u(xa),w(zb),u(xb),w(zb),u(xb),w(za),u(xa),w(za)]); };
  if(e[0]) rect(x-LOT,x+LOT,z+LOT,z+17); if(e[2]) rect(x-LOT,x+LOT,z-17,z-LOT); if(e[1]) rect(x+LOT,x+17,z-LOT,z+LOT); if(e[3]) rect(x-17,x-LOT,z-LOT,z+LOT);
  for(const sx of [-1,1]) for(const sz of [-1,1]) if(e[sz>0?0:2]||e[sx>0?1:3]) rect(sx>0?x+LOT:x-17,sx>0?x+17:x-LOT,sz>0?z+LOT:z-17,sz>0?z+17:z-LOT); }
Game.cellEdges=EDGES;
/* asfalt testi: (x,z) bir yol şeridine / köşe karesine düşüyor mu? m = tolerans (nesnenin yarı genişliği); m>0 asfalta m kadar yaklaşmış olmayı da sayar.
   Hücre kutusu [c-17,c+17] tam döşeli olduğundan nokta tek bir hücreye aittir. Yolsuz kenarlar (tarla) asfalt sayılmaz. */
Game.onAsphalt=function(x,z,m){ m=m||0; const gx=Math.round(x/CELL), gz=Math.round(z/CELL), e=EDGES.get(gx+","+gz); if(!e) return false;
  const dx=x-gx*CELL, dz=z-gz*CELL, ax=Math.abs(dx), az=Math.abs(dz), T=LOT-m; if(ax<=T&&az<=T) return false;
  const zr=az>T&&e[dz>0?0:2], xr=ax>T&&e[dx>0?1:3]; return !!(zr||xr); };

/* ---------- hücre tipleri ---------- */
function park(cx,cz,big){ CG.slab(cx,cz,Game.MAP.grass||"#5aa845",.14); const A=CG.F(cx,cz), T=CG.T(cx,cz), pick=CG.pick;
  fbox(A,cx,.14,cz,24,.05,3.2,"#dccfa5"); fbox(A,cx,.14,cz,3.2,.05,24,"#dccfa5");
  fbox(A,cx-3.25,.14,cz,.5,.9,7,"#aeb4bb"); fbox(A,cx+3.25,.14,cz,.5,.9,7,"#aeb4bb"); fbox(A,cx,.14,cz-3.25,6,.9,.5,"#aeb4bb"); fbox(A,cx,.14,cz+3.25,6,.9,.5,"#aeb4bb");
  fbox(T,cx,.2,cz,6,.6,6,"#4ba3e3"); fbox(A,cx,.14,cz,1.2,3.4,1.2,"#c3c8ce"); fbox(A,cx,3,cz,3.2,.4,3.2,"#c3c8ce");
  const pond=big||rnd()<.5; if(pond) fbox(T,cx-6.5,.1,cz-6,8,.08,6,"#3d94d6");
  for(const [bx,bz] of [[-6,2.3],[6,-2.3],[2.3,-6],[-2.3,6]]){ const x=cx+bx,z=cz+bz, ho=Math.abs(bx)>3; fbox(A,x,.5,z,ho?1.8:.6,.12,ho?.6:1.8,"#7a4f2a"); fbox(A,x,.14,z,ho?1.6:.4,.36,ho?.4:1.6,"#444"); }
  for(const sx of [-1,1])for(const m of [-6.6,6.6]){ fbox(A,cx+m,.14,cz+sx*11.4,8,1.1,.7,"#2f7d32"); fbox(A,cx+sx*11.4,.14,cz+m,.7,1.1,8,"#2f7d32"); }
  for(let i=0;i<16;i++){ const sx=rnd()<.5?-1:1, sz=rnd()<.5?-1:1, x=cx+sx*(4+rnd()*6.5), z=cz+sz*(4+rnd()*6.5); if(pond&&sx<0&&sz<0&&x>cx-11&&z>cz-9.5) continue; fbox(A,x,.14,z,.7,.35,.7,pick(["#ff5d8f","#ffd23f","#e63946","#f8f8f8","#b388ff"])); }
  const px=cx+6.5,pz=cz+6.5; fbox(A,px-1.6,.14,pz,.2,2.7,.2,"#d94"); fbox(A,px+1.6,.14,pz,.2,2.7,.2,"#d94"); fbox(A,px,2.7,pz,3.4,.2,.2,"#d94"); fbox(A,px-5,.14,pz-.5,3,.2,3,"#e5d29b");
  for(let i=0;i<13;i++){ const sx=rnd()<.5?-1:1, sz=rnd()<.5?-1:1, x=cx+sx*(3.6+rnd()*7), z=cz+sz*(3.6+rnd()*7); if(pond&&sx<0&&sz<0&&x>cx-11&&z>cz-9.5) continue; CG.tree(x,z); }
  L.lamps.push([cx+7,cz+2.4,0,1],[cx-7,cz-2.4,0,-1]); }
Game.parkFn=park;
const FN={police:CG.police,hospital:CG.hospital,school:CG.school,fire:CG.fire,mall:CG.mall,plaza:CG.plaza,shops:CG.shops,bigpark:(x,z)=>park(x,z,true),landmark:(x,z)=>CG.tower(x,z,46)};
Game.cellType={};
const ZN=Game.MAP.zone||[3.6,6.5];
function coreCell(x,z,r){ if(r<.82){ CG.tower(x,z); return "tower"; } if(r<.92){ CG.shops(x,z); return "shops"; } park(x,z,false); return "park"; }
function fillCell(x,z,r){ if(r<.55){ CG.tower(x,z); return "tower"; } if(r<.85){ CG.shops(x,z); return "shops"; } park(x,z,false); return "park"; }
const NB={apt:()=>CG.aptCourt,row:()=>CG.rowBlock,villa:()=>CG.villaBlock,cottage:()=>CG.cottageBlock,modern:()=>CG.modernBlock,garden:()=>CG.suburbBlock};
for(const [gx,gz] of W.cells){ const x=gx*CELL,z=gz*CELL, key=gx+","+gz, sp=SPECIAL[key], r=rnd(), dist=Math.hypot(gx,gz), info=D.info(gx,gz), e=EDGES.get(key); let type;
  if(info.rural){ type=info.kind==="forest"?CG.forestCell(x,z,e):info.kind==="lake"?CG.lakeCell(x,z,e):info.kind==="orchard"?CG.orchardCell(x,z,e):CG.farmCell(x,z,e); Game.cellType[key]=type; continue; }
  if(sp){ type=sp; if(FN[type]) FN[type](x,z); else park(x,z,false); }
  else if(info.kind==="town"){ const q=rnd(); if(info.tring===0) type=CG.townSquare(x,z); else if(info.tring===1) type=q<.6?CG.mainStreet(x,z):q<.8?CG.townHouses(x,z):(CG.pondPark(x,z)); else type=q<.7?CG.townHouses(x,z):q<.85?CG.mainStreet(x,z):CG.pondPark(x,z); }
  else if(info.kind==="core"||dist<ZN[0]) type=coreCell(x,z,r);
  else { const k=info.kind, pFill=dist<ZN[1]?.4:.07;
    if(k==="biz") type=CG.bizCell(x,z); else if(k==="old") type=CG.oldCell(x,z); else if(k==="ind") type=CG.industrial(x,z);
    else if(k==="green") type=r<.3?CG.sportsField(x,z):r<.7?CG.pondPark(x,z):(park(x,z,false),"park");
    else if(r<pFill) type=fillCell(x,z,rnd());
    else type=(NB[k]||NB.garden)()(x,z); }
  Game.cellType[key]=type;
  ring(gx,gz,x,z,type==="hospital"||type==="plaza"||type==="square"||type==="ind"); }

/* ---------- sokak donanımı: ağaç, lamba, trafik ışığı, bulvar ortaları, park halindeki araçlar ---------- */
function ring(gx,gz,cx,cz,noTrees){
  const A=CG.F(cx,cz), q=Math.SQRT1_2;
  /* kaldırım: parsel kenarında beyaz beton şerit + açık renkli bordür */
  { const sw="#ececea", cb="#fafaf8";
    fbox(A,cx,.12,cz+11.1,24,.05,1.8,sw); fbox(A,cx,.12,cz-11.1,24,.05,1.8,sw); fbox(A,cx-11.1,.12,cz,1.8,.05,20.4,sw); fbox(A,cx+11.1,.12,cz,1.8,.05,20.4,sw);
    fbox(A,cx,.17,cz+11.95,24,.03,.1,cb); fbox(A,cx,.17,cz-11.95,24,.03,.1,cb); fbox(A,cx-11.95,.17,cz,.1,.03,23.8,cb); fbox(A,cx+11.95,.17,cz,.1,.03,23.8,cb); }
  if(!noTrees) for(const s of [-1,1]) for(const t of [-7,7]){ if(rnd()<.75) CG.tree(cx+t,cz+s*11.3,.8+rnd()*.5); if(rnd()<.75) CG.tree(cx+s*11.3,cz+t,.8+rnd()*.5); }
  for(const sx of [-1,1])for(const sz of [-1,1]){ const e=[cx+sx*11.3,cz+sz*11.3,sx*q,sz*q]; if(sx*sz>0) L.tlights.push(e.concat(Math.floor(rnd()*3))); else L.lamps.push(e); }
  L.lamps.push([cx,cz+11.5,0,1],[cx,cz-11.5,0,-1],[cx+11.5,cz,1,0],[cx-11.5,cz,-1,0]);
  if(CG.streetAd) CG.streetAd(cx,cz);
  if(rnd()<.55) CG.addCar(cx+(rnd()-.5)*12,cz+(rnd()<.5?13:-13),false,pick(CG.CC));
  if(rnd()<.55) CG.addCar(cx+(rnd()<.5?13:-13),cz+(rnd()-.5)*12,true,pick(CG.CC));
  // bulvar ortaları (her 5. yol): çiçekli orta şerit + ağaçlar
  if(((gx%5)+5)%5===0){ const x=cx+17; fbox(A,x,.03,cz,1.6,.5,16,"#cfd2d6"); fbox(A,x,.5,cz,1.2,.18,15.6,"#4f9a43"); CG.tree(x,cz-5,.8,0); CG.tree(x,cz+5,.8,0); CG.lamp(x,cz,1,0); }
  if(((gz%5)+5)%5===0){ const z=cz+17; fbox(A,cx,.03,z,16,.5,1.6,"#cfd2d6"); fbox(A,cx,.5,z,15.6,.18,1.2,"#4f9a43"); CG.tree(cx-5,z,.8,0); CG.tree(cx+5,z,.8,0); CG.lamp(cx,z,0,1); } }
Game.CG.ring=ring;
})();
