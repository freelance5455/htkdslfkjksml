"use strict";
/* ===== HARİTALAR: tohum (yerleşim), bölge dağılımı, zemin/ağaç renkleri, gökyüzü tonu, hava durumu. Harita değişince sayfa yeniden yüklenir. ===== */
Game.MAPS=[
 {id:"metro",   icon:"🏙️", seed:1337, zone:[3.6,6.5], tod:"day"},
 {id:"suburb",  icon:"🏡", seed:4242, zone:[1.3,3.0], tod:"day", tint:[.95,.85,.7,.12]},
 {id:"downtown",icon:"🌆", seed:9001, zone:[7.2,9.2], tod:"sunset", tint:[1,.6,.35,.18]},
 {id:"desert",  icon:"🏜️", seed:777,  zone:[3.6,6.5], tod:"day", tint:[1,.78,.45,.34], grass:"#c8a766", grass2:"#b3914f", plaza:"#d4ba80", sand:"#ecd29a", wet:"#c9a96b", greens:["#8c8a3c","#9a9540","#7d7a36","#a29b4a","#6f7233"], pines:["#6a6a35","#5b5b2d","#767638"], fogK:1.25},
 {id:"snow",    icon:"❄️", seed:2468, zone:[3.6,6.5], tod:"day", tint:[.8,.9,1,.3], grass:"#e9eff5", grass2:"#d6dfe9", plaza:"#e2eaf1", sand:"#eef3f8", wet:"#cdd8e3", greens:["#dfe9ee","#cfdde5","#e8f0f3","#c4d4de","#d9e5ea"], pines:["#8fb0a5","#7fa196","#9bbdb1"], weather:"snow", fogK:1.5},
 {id:"neon",    icon:"🌃", seed:31337,zone:[3.6,6.5], tod:"night", tint:[.7,.4,1,.22], fogK:1.1},
 {id:"ruins",   icon:"🌋", seed:666,  zone:[3.6,6.5], tod:"sunset", tint:[1,.35,.2,.34], grass:"#4a4535", grass2:"#3d3a2c", plaza:"#4f4838", greens:["#5a5638","#4c4a30","#665f40","#3f3d2b","#57553a"], pines:["#3f3b2a","#34321f","#4a4630"], weather:"ash", ruins:true, fogK:1.6}
];
Game.MAP=Game.MAPS.find(m=>m.id===Game.settings.map)||Game.MAPS[0];
Game.setMap=function(id){ const m=Game.MAPS.find(x=>x.id===id); if(!m) return; store.set("map",m.id); store.set("hour",String({day:12.5,sunset:18,night:22}[m.tod||"day"]||12.5)); try{ location.reload(); }catch(e){} };
