"use strict";
/* ===== BÖLGELER: şehir merkezleri, mahalleler, sanayi, kasabalar ve kırsal alan. Her hücre bir bölgeye ait; yol ağı bölgeye göre seyrekleşir ===== */
Game.Districts=(function(){
const W=Game.W, MP=Game.MAP, n2=W.noise, CELL=W.CELL;
const D={}, zone=MP.zone||[3.6,6.5];
const h2=(a,b,k)=>{ const s=Math.sin(a*127.1+b*311.7+(k||0)*74.7)*43758.5453; return s-Math.floor(s); };
D.h2=h2;
/* iç bölgeler: [id, tür, gx, gz, ağırlık] — mahalle ve merkez tohumları (en yakın tohum kazanır) */
const SEEDS=[
  ["core","core",0,0,1.2],
  ["biz","biz",-5.6,-4.6,1.0], ["old","old",5.4,-5.0,1.0],
  ["ind","ind",7.0,4.4,1.0], ["apt","apt",2.4,5.4,1.0], ["mod","modern",-3.6,5.8,1.0],
  ["row","row",4.8,0.5,.95], ["villa","villa",-7.2,1.2,1.0], ["gul","cottage",-1.8,-7.4,1.0],
  ["gar1","garden",-6.4,-8.0,.9], ["gar2","garden",-6.2,7.0,.9], ["gar3","garden",7.8,-8.6,.8],
  ["grn","green",-3.4,0.4,.8]
];
D.seeds=SEEDS;
/* kasabalar: [ad, gx, gz, yarıçap] */
const TOWNS=[
  {name:"Greenvale",gx:-9.8,gz:-3.4,r:2.0}, {name:"Pinehill",gx:-4.6,gz:8.9,r:1.9}, {name:"Seaview",gx:3.0,gz:9.7,r:1.9},
  {name:"Oakridge",gx:0.6,gz:-9.9,r:1.9}, {name:"Rockport",gx:5.6,gz:-9.0,r:1.8}, {name:"Lakeside",gx:7.9,gz:3.4,r:1.6}
];
D.towns=TOWNS;
const RURAL_R=Math.max(8.5,(zone[1]||6.5)+1.0);
const cache=new Map(), forced=new Set(); D.force=keys=>{ for(const k of keys) forced.add(k); cache.clear(); };
/* hücre bilgisi: {kind, seed, town, ring, rural} */
D.info=function(gx,gz){ const key=gx+","+gz; let o=cache.get(key); if(o) return o;
  const r=Math.hypot(gx,gz); let town=null, td=1e9;
  for(const t of TOWNS){ const d=Math.hypot(gx-t.gx,gz-t.gz); if(d<=t.r&&d<td){ td=d; town=t; } }
  o={gx,gz,r,kind:"",seed:null,town:null,tring:0,rural:false};
  if(town){ o.kind="town"; o.town=town; o.tring=td<.85?0:td<1.55?1:2; o.rural=false; }
  else if(!forced.has(key)&&r>RURAL_R+.9*n2(gx*34*.7,gz*34*.7+50)){ o.rural=true; const k=n2(gx*34*.35+40,gz*34*.35-80), q=h2(gx,gz,3); o.kind=k>.38?"forest":k<-.44?"lake":q<.3?"orchard":"farm"; if(o.kind==="lake"&&r<RURAL_R+1.4) o.kind="farm"; }
  else { let best=1e9, bs=null; for(const s of SEEDS){ if((s[1]==="biz"||s[1]==="old")&&zone[1]<5) continue; if(s[1]==="core"&&r>=zone[0]) continue; const d=Math.hypot(gx-s[2],gz-s[3])/s[4]; if(d<best){ best=d; bs=s; } }
    o.seed=bs; o.kind=bs[1]; if(r<zone[0]) o.kind="core"; }
  cache.set(key,o); return o; };
W.walkCell=(gx,gz)=>W.inCity(gx,gz)&&!D.info(gx,gz).rural;
D.isRural=(gx,gz)=>{ if(!W.inCity(gx,gz)) return true; const o=D.info(gx,gz); return o.rural; };
/* yol: hücrenin bir kenarında yol var mı? (0:+z 1:+x 2:-z 3:-x). Kentsel hücre kenarında her zaman; kırsal-kırsal kenarda 3 hücrede bir (tarla yolu) */
D.edgeRoad=function(gx,gz,side){ const nx=gx+(side===1?1:side===3?-1:0), nz=gz+(side===0?1:side===2?-1:0);
  const aIn=W.inCity(gx,gz), bIn=W.inCity(nx,nz); if(!aIn&&!bIn) return false;
  const rA=aIn?D.isRural(gx,gz):true, rB=bIn?D.isRural(nx,nz):true;
  if(!rA||!rB){ if(!aIn||!bIn){ const c=aIn?D.info(gx,gz):D.info(nx,nz); return !c.rural; } return true; }
  const id=side===0?gz:side===2?gz-1:side===1?gx:gx-1, m=((id%3)+3)%3; return m===0; };
/* etiket (HUD): bölge türü anahtarı + ad */
const LBL={core:"d_core",biz:"d_biz",old:"d_old",ind:"d_ind",apt:"d_apt",modern:"d_mod",row:"d_row",villa:"d_villa",cottage:"d_cot",garden:"d_gar",green:"d_grn",town:"d_town",farm:"d_farm",orchard:"d_farm",forest:"d_forest",lake:"d_forest"};
D.at=function(x,z){ const gx=Math.round(x/CELL), gz=Math.round(z/CELL); if(!W.inCity(gx,gz)) return null; const o=D.info(gx,gz); return {key:LBL[o.kind]||"d_core",name:o.town?o.town.name:(o.seed&&o.seed[0]==="gul"?"Gül":null)}; };
return D;
})();
