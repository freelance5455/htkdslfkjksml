"use strict";
/* ===== AĞAÇ KIRMA: sert yumruk / patlama ağaçları gövdeden kırar. Kütük kalır, üst parça devrilir (yaprak + odun kıymığı + toz + ses) ===== */
Game.Trees=(function(){
const TR=Game.treeRefs, D=Game.D, FX=Game.FX, SH=Game.Shards, W=Game.W, TG=Game.TreeGeo, CGL=Game.CG.lists, C=Game.CG.C, au=()=>Game.audio;
const T={}, recs=TR.recs, VARS=TR.VARS, HS=TG.HS, CS=24, MAXF=8, FC=3;
const grid=new Map(); recs.forEach(r=>{ const k=Math.floor(r.x/CS)*4099+Math.floor(r.z/CS); let a=grid.get(k); if(!a){ a=[]; grid.set(k,a); } a.push(r); });
const WOOD=[C("#8a6a48"),C("#a98a62"),C("#6b4f35"),C("#d8c08a")], BRANCH=new THREE.Color(.074,.052,.037);
/* devrilen parça havuzu: varyant başına 3 yuva (gövde üst parçası + yaprak [+ kışlık dallar]); rüzgârsız malzemeler */
const LEAF_FS=new THREE.MeshStandardMaterial({roughness:.9,map:TG.tex.leaf,vertexColors:true}), LEAF_DS=Game.softSnow(new THREE.MeshStandardMaterial({roughness:.9,map:TG.tex.leaf,vertexColors:true,side:THREE.DoubleSide})),
  BAREM=Game.softSnow(new THREE.MeshStandardMaterial({color:BRANCH,roughness:1,side:THREE.DoubleSide}));
const o3=new THREE.Object3D(), zero=new THREE.Object3D(), white=new THREE.Color(1,1,1); zero.scale.setScalar(.0001); zero.position.set(0,-999,0); zero.updateMatrix();
const mkI=(g,m,cast)=>{ const im=new THREE.InstancedMesh(g,m,FC); for(let i=0;i<FC;i++){ im.setMatrixAt(i,zero.matrix); } im.instanceMatrix.needsUpdate=true; im.frustumCulled=false; im.castShadow=!!cast; im.receiveShadow=true; im.count=0; scene.add(im); return im; };
const FV=VARS.map(V=>{ const f={bark:mkI(V.upper,TR.BARKS[V.kind],true),leaf:mkI(V.leaf,V.sided?LEAF_DS:LEAF_FS,true),bare:V.bare?mkI(V.bare,BAREM,true):null,used:[false,false,false],n:0};
  for(let i=0;i<FC;i++) f.leaf.setColorAt(i,white); return f; });
const F=[], qa=new THREE.Quaternion(), qb=new THREE.Quaternion(), qc=new THREE.Quaternion(), ax=new THREE.Vector3(), ay=new THREE.Vector3(0,1,0), vv=new THREE.Vector3(), tc=new THREE.Color();
const mulQ=(a,b,o)=>o.set(a.w*b.x+a.x*b.w+a.y*b.z-a.z*b.y, a.w*b.y-a.x*b.z+a.y*b.w+a.z*b.x, a.w*b.z+a.x*b.y-a.y*b.x+a.z*b.w, a.w*b.w-a.x*b.x-a.y*b.y-a.z*b.z);
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
function writeFall(f,sc){ const r=f.r, s=f.s; ax.set(f.dz,0,-f.dx); qa.setFromAxisAngle(ax,f.th); qb.setFromAxisAngle(ay,r.rot); mulQ(qa,qb,qc);
  vv.set(0,HS*s,0).applyQuaternion(qa);
  o3.position.set(r.x+f.dx*f.slide-vv.x,r.gy+HS*s-f.drop-vv.y,r.z+f.dz*f.slide-vv.z); o3.quaternion.copy(qc); o3.scale.setScalar(s*sc); o3.updateMatrix();
  const fv=f.fv, m=o3.matrix; fv.bark.setMatrixAt(f.slot,m); fv.bark.instanceMatrix.needsUpdate=true;
  if(f.winter&&fv.bare){ fv.bare.setMatrixAt(f.slot,m); fv.bare.instanceMatrix.needsUpdate=true; fv.leaf.setMatrixAt(f.slot,zero.matrix); }
  else { fv.leaf.setMatrixAt(f.slot,m); if(fv.bare) fv.bare.setMatrixAt(f.slot,zero.matrix); }
  fv.leaf.instanceMatrix.needsUpdate=true; if(fv.bare) fv.bare.instanceMatrix.needsUpdate=true; }
function crownPos(f,out){ ax.set(f.dz,0,-f.dx); qa.setFromAxisAngle(ax,f.th); vv.set(0,(f.V.yc-HS)*f.s,0).applyQuaternion(qa);
  out.x=f.r.x+f.dx*f.slide+vv.x; out.y=f.r.gy+HS*f.s-f.drop+vv.y; out.z=f.r.z+f.dz*f.slide+vv.z; return out; }
const cp={x:0,y:0,z:0};
function leafCols(r){ const p=TR.parts[r.pi], ic=p.leaf.instanceColor, a=ic?ic.array:null, k=r.slot*3, out=[];
  for(let i=0;i<3;i++){ const m=.8+i*.18; out.push(a?new THREE.Color(a[k]*m,a[k+1]*m,a[k+2]*m):new THREE.Color(.2*m,.5*m,.2*m)); } return out; }
const leavesOn=r=>!(Game.season==="winter"&&VARS[r.v].type!==1);
function leafBurst(r,x,y,z,n,sp){ if(!leavesOn(r)){ FX.dust(x,y,z,4,3,[.92,.94,.97]); return; }
  SH.burst(x,y,z,n,{sp,up:sp*.7,size:[.14,.3],flat:true,cols:leafCols(r),life:[3,6.5],grav:5,flutter:1.7,spread:1.6,spin:5});
  FX.dust(x,y,z,4,3,[.45,.6,.35]); }
function startFall(r,dx,dz,power){ const fv=FV[r.v], slot=fv.used.indexOf(false); if(slot<0||F.length>=MAXF) return false; const V=VARS[r.v], s=r.s, part=TR.parts[r.pi], ic=part.leaf.instanceColor;
  fv.used[slot]=true; fv.n++; fv.bark.count=fv.leaf.count=FC; if(fv.bare) fv.bare.count=FC;
  if(ic){ tc.setRGB(ic.array[r.slot*3],ic.array[r.slot*3+1],ic.array[r.slot*3+2]); fv.leaf.setColorAt(slot,tc); if(fv.leaf.instanceColor) fv.leaf.instanceColor.needsUpdate=true; }
  const L=Math.max(3,(V.yc-HS)*s), thEnd=clamp(Math.acos(clamp((V.rc*s*.8-HS*s)/L,-.9,.9)),1.1,1.5);
  const f={r,fv,slot,V,s,th:.08,om:.9+Math.min(1.6,power*.5),dx,dz,state:0,t:0,bounced:false,thEnd,L,winter:Game.season==="winter"&&V.type!==1,slide:0,drop:0};
  F.push(f); writeFall(f,1); return true; }
function endFall(f){ const fv=f.fv; fv.used[f.slot]=false; fv.n--; fv.bark.setMatrixAt(f.slot,zero.matrix); fv.leaf.setMatrixAt(f.slot,zero.matrix); if(fv.bare) fv.bare.setMatrixAt(f.slot,zero.matrix);
  fv.bark.instanceMatrix.needsUpdate=fv.leaf.instanceMatrix.needsUpdate=true; if(fv.bare) fv.bare.instanceMatrix.needsUpdate=true; if(fv.n<=0){ fv.bark.count=fv.leaf.count=0; if(fv.bare) fv.bare.count=0; } }
function impact(f,k){ crownPos(f,cp); const gy=W.terrainH(cp.x,cp.z), cx=camera.position, d=Math.hypot(cp.x-cx.x,cp.z-cx.z);
  leafBurst(f.r,cp.x,Math.max(gy+.8,cp.y),cp.z,Math.round(22*k),4.5*k+1); FX.dust(cp.x,gy+.5,cp.z,Math.round(10*k),4);
  SH.burst(cp.x,gy+.6,cp.z,Math.round(8*k),{sp:4,up:4,size:[.07,.2],cols:WOOD,life:[3,5],grav:16});
  if(au()&&au().treeLand) au().treeLand(cp.x,gy+1,cp.z,k); if(d<48&&Game.shakeAdd) Game.shakeAdd(.32*k*(1-d/48)); }
T.update=function(dt){ if(!F.length) return; dt=Math.min(dt,.05);
  for(let i=F.length-1;i>=0;i--){ const f=F[i]; f.t+=dt; let sc=1;
    if(f.state===0){ f.om+=3.4*Math.sin(f.th+.08)*dt*Math.sqrt(6/f.L)*1.25; f.th+=f.om*dt;
      if(f.th>=f.thEnd){ f.th=f.thEnd; if(!f.bounced){ f.bounced=true; f.om=-f.om*.2; impact(f,1); } else { f.om=0; f.state=1; f.t1=0; impact(f,.45); } } }
    else { f.t1+=dt; const k=Math.min(1,f.t1/.7), e=1-(1-k)*(1-k); f.slide=.7*e; f.drop=.3*f.s*e; sc=1-clamp((f.t1-22)/3,0,1); if(f.t1>25){ endFall(f); F.splice(i,1); continue; } }
    writeFall(f,sc); } };
Game.updaters.push(dt=>T.update(dt));
/* ağacı kır */
T.breakTree=function(r,dx,dz,power,noFall){ if(!r.alive) return false; const V=VARS[r.v], s=r.s;
  TR.setTree(r,false); TR.addStump(r); if(r.solid) r.solid.h=0; const lt=CGL.trees[r.i]; if(lt) lt.dead=true; if(Game.Drive&&Game.Drive.removeObstacle) Game.Drive.removeObstacle(r.x,r.z);
  const l=Math.hypot(dx,dz); if(l<.01){ const a=Math.random()*6.28; dx=Math.cos(a); dz=Math.sin(a); } else { dx/=l; dz/=l; }
  const c=camera.position, near=Math.hypot(r.x-c.x,r.z-c.z)<300, fell=!noFall&&near&&startFall(r,dx,dz,power||1);
  SH.burst(r.x,r.gy+HS*s,r.z,fell?12:7,{sp:5,up:5,size:[.07,.22],cols:WOOD,life:[2.5,4.5],grav:16,spread:.3,dir:[dx,dz,3]});
  FX.dust(r.x,r.gy+HS*s,r.z,4,2.5,[.55,.45,.32]);
  if(!fell){ leafBurst(r,r.x,r.gy+V.yc*s,r.z,22,4); }
  else if(leavesOn(r)) SH.burst(r.x+dx*.8,r.gy+(V.yc-.6)*s,r.z+dz*.8,10,{sp:2.5,up:1.5,size:[.14,.28],flat:true,cols:leafCols(r),life:[3,5],grav:5,flutter:1.6,spread:1.4,spin:5});
  if(au()){ if(au().treeBreak) au().treeBreak(r.x,r.gy+2,r.z); if(fell&&au().treeFall) au().treeFall(r.x,r.gy+3,r.z); }
  return true; };
/* küre ile vuruş: damageSphere kancası çağırır */
const list=[];
T.hit=function(x,y,z,rad,amt,speed){ list.length=0; const reach=rad+3.6, i0=Math.floor((x-reach)/CS), i1=Math.floor((x+reach)/CS), j0=Math.floor((z-reach)/CS), j1=Math.floor((z+reach)/CS);
  for(let a=i0;a<=i1;a++) for(let b=j0;b<=j1;b++){ const arr=grid.get(a*4099+b); if(!arr) continue;
    for(const r of arr){ if(!r.alive) continue; const dh=Math.hypot(r.x-x,r.z-z); if(dh>reach) continue; const V=VARS[r.v], top=r.gy+V.H*r.s, hy=y<r.gy?r.gy-y:(y>top?y-top:0); if(hy>rad) continue;
      const eff=Math.max(0,dh-(y>r.gy+2.2*r.s?V.rc*r.s*.5:.5*r.s)); if(Math.hypot(eff,hy)>rad) continue; list.push(r); r._d=dh; } }
  if(!list.length) return 0; list.sort((p,q)=>p._d-q._d); if(list.length>34) list.length=34;
  let n=0; const power=Math.min(2.5,amt+speed/60);
  for(let k=0;k<list.length;k++){ const r=list[k]; if(T.breakTree(r,r.x-x,r.z-z,power,k>=6)) n++; }
  if(n&&Game.toast) Game.toast("t_tree",1800); return n; };
T.alive=()=>recs.reduce((s,r)=>s+(r.alive?1:0),0);
/* ---------- KATI GÖVDELER: ağaçların içinden geçilemez (kahraman, NPC, enkaz/araç gövdeleri). Gövde kutusu = kare kesit; tepe = ağaç boyu.
   Yumruk/patlama/yüksek hız ağacı kırınca (breakTree -> r.alive=false) gövde de kalkar; kütük solid sayılmaz. */
const trunkR=r=>.3*r.s+.14;
T.trunkR=trunkR;
T.solids=function(x0,y0,z0,x1,y1,z1,out){ const i0=Math.floor((x0-1.2)/CS), i1=Math.floor((x1+1.2)/CS), j0=Math.floor((z0-1.2)/CS), j1=Math.floor((z1+1.2)/CS);
  for(let a=i0;a<=i1;a++) for(let b=j0;b<=j1;b++){ const arr=grid.get(a*4099+b); if(!arr) continue;
    for(const r of arr){ if(!r.alive) continue; const h=trunkR(r); if(x1<r.x-h||x0>r.x+h||z1<r.z-h||z0>r.z+h) continue; const top=r.gy+VARS[r.v].H*r.s; if(y1<r.gy||y0>top) continue; out.push(r.x-h,r.gy,r.z-h,r.x+h,top,r.z+h); } } };
/* fizik gövdeleri için statik kutu kaydı (bina kaydı gibi: {x,z,hw,hd,y0,h}); kırılınca h=0 */
T.solidRec=function(r){ return r.solid||(r.solid={x:r.x,z:r.z,hw:trunkR(r),hd:trunkR(r),y0:r.gy,h:r.gy+VARS[r.v].H*r.s,tree:1}); };
T.near=function(x,z,rad,fn){ const i0=Math.floor((x-rad)/CS), i1=Math.floor((x+rad)/CS), j0=Math.floor((z-rad)/CS), j1=Math.floor((z+rad)/CS);
  for(let a=i0;a<=i1;a++) for(let b=j0;b<=j1;b++){ const arr=grid.get(a*4099+b); if(!arr) continue; for(const r of arr){ if(r.alive&&Math.hypot(r.x-x,r.z-z)<=rad) fn(r); } } };
/* yürüyen NPC: gövdeye giriyorsa dışarı it, tam karşıya yürüyorsa teğet boyunca kaydır */
T.avoid=function(o,mx,mz,step){ const i0=Math.floor((o.x-1.5)/CS), i1=Math.floor((o.x+1.5)/CS), j0=Math.floor((o.z-1.5)/CS), j1=Math.floor((o.z+1.5)/CS);
  for(let a=i0;a<=i1;a++) for(let b=j0;b<=j1;b++){ const arr=grid.get(a*4099+b); if(!arr) continue;
    for(const r of arr){ if(!r.alive) continue; const rr=trunkR(r)*1.2+.32, dx=o.x-r.x, dz=o.z-r.z, d2=dx*dx+dz*dz; if(d2>=rr*rr) continue;
      const d=Math.sqrt(d2)||1e-3, nx=dx/d, nz=dz/d; o.x=r.x+nx*rr; o.z=r.z+nz*rr;
      if(mx*nx+mz*nz<-.45){ const c=mx*nz-mz*nx, sg=c>=0?-1:1; o.x+=-nz*sg*step*.95; o.z+=nx*sg*step*.95; } } } };
Game.hitHooks=[];
if(D&&D.damageSphere){ const orig=D.damageSphere; D.damageSphere=function(x,y,z,r,amt,speed,quiet){ const n=orig.apply(D,arguments);
  if(amt>=.9&&(speed>=20||amt>=1.2)){ try{ T.hit(x,y,z,r,amt,speed||0); }catch(e){ console.error(e); } }
  for(const h of Game.hitHooks){ try{ h(x,y,z,r,amt,speed||0); }catch(e){ console.error(e); } }
  return n; }; }
return T;
})();
