"use strict";
/* ===== BİNA İÇLERİ: yakındaki binaların katlarına mobilya (koltuk, yatak, masa…) — havuzdan, yıkımda açığa çıkar ===== */
Game.Interior=(function(){
const MAXB=3600, C=h=>new THREE.Color(h).convertSRGBToLinear(), rnd=Math.random, pick=a=>a[(rnd()*a.length)|0];
const mat=Game.noSnow(new THREE.MeshStandardMaterial({roughness:.82,metalness:.04})), mesh=new THREE.InstancedMesh(new THREE.BoxGeometry(1,1,1),mat,MAXB);
mesh.frustumCulled=false; mesh.receiveShadow=true; mesh.castShadow=false; scene.add(mesh);
const free=[], A=mesh.instanceMatrix.array, tc=new THREE.Color();
for(let i=MAXB-1;i>=0;i--){ free.push(i); mesh.setColorAt(i,tc.setRGB(1,1,1)); Game.U.hide(A,i); }
mesh.instanceMatrix.needsUpdate=true; mesh.instanceColor.needsUpdate=true;
const COL={}; ["#8e5b3a","#3f5f8a","#6e7f5a","#a34a4a","#5a5a66","#c9a46a","#7c4a6e","#2f6f6a","#d8d2c4","#e8e8ea","#2b2b30","#8a6a45","#5c4630","#b9bec6","#4a7bc8","#2e8b57","#d9b44a","#c0392b","#f4f4f6","#cdd3da","#3b3f46","#7fb2e5","#e6e0d0","#bcd7c2","#d46a6a","#506a8a","#4b6b3c","#a0522d"].forEach(h=>COL[h]=C(h));
const col=h=>COL[h]||(COL[h]=C(h));
function wbox(slots,x,y,z,yaw,sx,sy,sz,c){ if(!free.length) return; const i=free.pop(); slots.push(i); const cs=Math.cos(yaw), sn=Math.sin(yaw), o=i*16;
  A[o]=cs*sx;A[o+1]=0;A[o+2]=-sn*sx;A[o+3]=0; A[o+4]=0;A[o+5]=sy;A[o+6]=0;A[o+7]=0; A[o+8]=sn*sz;A[o+9]=0;A[o+10]=cs*sz;A[o+11]=0; A[o+12]=x;A[o+13]=y;A[o+14]=z;A[o+15]=1;
  mesh.setColorAt(i,col(c)); }
function put(slots,fn,ox,oy,oz,yaw,a,b,c){ const cs=Math.cos(yaw), sn=Math.sin(yaw);
  fn((lx,ly,lz,sx,sy,sz,cl)=>wbox(slots,ox+lx*cs+lz*sn,oy+ly,oz-lx*sn+lz*cs,yaw,sx,sy,sz,cl),a,b,c); }
/* eşyalar: add(yerelX, merkezY, yerelZ, genişlik, yükseklik, derinlik, renk); ön yüz +z, arka duvar -z */
const IT={
 sofa:(a,c)=>{ a(0,.25,0,2.2,.5,.9,c); a(0,.72,-.33,2.2,.55,.24,c); a(-1.02,.45,0,.26,.5,.9,c); a(1.02,.45,0,.26,.5,.9,c); },
 chair:(a,c)=>{ a(0,.28,0,.9,.55,.9,c); a(0,.78,-.34,.9,.55,.22,c); },
 ctable:(a)=>{ a(0,.2,0,1.1,.4,.6,"#5c4630"); a(0,.42,0,1.2,.05,.7,"#8a6a45"); },
 tv:(a)=>{ a(0,.28,0,1.7,.56,.42,"#5c4630"); a(0,.95,0,1.25,.72,.07,"#2b2b30"); },
 rug:(a,c)=>{ a(0,.015,0,3,.03,2.2,c); },
 bed:(a,c)=>{ a(0,.2,0,1.6,.4,2.1,"#8a6a45"); a(0,.5,.05,1.5,.22,1.95,"#f4f4f6"); a(0,.58,.2,1.5,.1,1.4,c); a(-.4,.66,-.8,.55,.13,.36,"#f4f4f6"); a(.4,.66,-.8,.55,.13,.36,"#f4f4f6"); a(0,.7,-1.02,1.7,1.0,.1,"#5c4630"); },
 stand:(a)=>{ a(0,.27,0,.5,.54,.42,"#8a6a45"); a(0,.6,0,.18,.1,.18,"#f2d27a"); },
 wardrobe:(a,c)=>{ a(0,1,0,1.5,2,.6,c); a(-.2,1,.31,.04,1.4,.02,"#cdd3da"); a(.2,1,.31,.04,1.4,.02,"#cdd3da"); },
 dtable:(a)=>{ a(0,.74,0,1.7,.07,.95,"#8a6a45"); for(const sx of [-.75,.75])for(const sz of [-.38,.38]) a(sx,.36,sz,.08,.72,.08,"#5c4630"); },
 dchair:(a,c)=>{ a(0,.44,0,.45,.06,.45,c); a(0,.75,-.2,.45,.55,.05,c); for(const sx of [-.18,.18])for(const sz of [-.18,.18]) a(sx,.2,sz,.05,.4,.05,"#3b3f46"); },
 counter:(a)=>{ a(0,.45,0,2.6,.9,.65,"#e6e0d0"); a(0,.92,0,2.7,.05,.72,"#3b3f46"); a(-.6,.5,.34,.5,.4,.02,"#b9bec6"); },
 fridge:(a)=>{ a(0,.95,0,.75,1.9,.72,"#e8e8ea"); a(.2,1.2,.37,.03,.5,.02,"#8d939b"); },
 desk:(a)=>{ a(0,.73,0,1.5,.05,.75,"#c9a46a"); a(-.7,.36,0,.05,.72,.7,"#8a6a45"); a(.7,.36,0,.05,.72,.7,"#8a6a45"); a(0,1.05,-.2,.55,.38,.05,"#2b2b30"); a(0,.84,-.2,.14,.17,.12,"#2b2b30"); a(.3,.78,.1,.3,.03,.12,"#e8e8ea"); },
 ochair:(a,c)=>{ a(0,.5,0,.5,.07,.5,c); a(0,.85,-.24,.48,.55,.07,c); a(0,.25,0,.07,.5,.07,"#3b3f46"); a(0,.04,0,.5,.06,.5,"#3b3f46"); },
 shelf:(a,c)=>{ a(0,1,0,1.3,2,.38,"#8a6a45"); for(let k=0;k<4;k++) a(0,.45+k*.42,.04,1.2,.3,.3,k%2?"#c0392b":"#4a7bc8"); },
 plant:(a)=>{ a(0,.22,0,.4,.44,.4,"#a0522d"); a(0,.9,0,.7,.9,.7,"#2e8b57"); a(.1,1.45,0,.4,.5,.4,"#3a9b60"); },
 lamp:(a)=>{ a(0,.8,0,.05,1.6,.05,"#3b3f46"); a(0,1.6,0,.4,.32,.4,"#f2d27a"); },
 hbed:(a)=>{ a(0,.45,0,.95,.14,2.1,"#cdd3da"); a(0,.65,.1,.9,.25,1.85,"#f4f4f6"); a(0,.78,.4,.92,.1,1.2,"#7fb2e5"); a(0,.95,-1.02,.95,.7,.07,"#cdd3da"); a(-.55,.2,-.9,.06,.4,.06,"#8d939b"); },
 drip:(a)=>{ a(0,.9,0,.04,1.8,.04,"#b9bec6"); a(0,1.7,0,.3,.04,.04,"#b9bec6"); a(.13,1.55,0,.12,.28,.06,"#bcd7c2"); a(0,.03,0,.45,.06,.45,"#8d939b"); },
 curtain:(a)=>{ a(0,1.1,0,1.8,2.1,.04,"#7fb2e5"); },
 sdesk:(a)=>{ a(0,.7,0,.75,.05,.55,"#c9a46a"); a(-.3,.35,-.2,.04,.7,.04,"#8d939b"); a(.3,.35,-.2,.04,.7,.04,"#8d939b"); a(-.3,.35,.2,.04,.7,.04,"#8d939b"); a(.3,.35,.2,.04,.7,.04,"#8d939b"); },
 schair:(a)=>{ a(0,.42,.55,.38,.05,.38,"#4a7bc8"); a(0,.7,.74,.38,.4,.04,"#4a7bc8"); },
 board:(a)=>{ a(0,1.7,0,3.2,1.1,.06,"#2f5f45"); a(0,1.12,.03,3.3,.05,.08,"#e6e0d0"); },
 locker:(a,c)=>{ a(0,1,0,.55,2,.5,c); a(0,1.2,.26,.03,.5,.02,"#cdd3da"); },
 cab:(a)=>{ a(0,.65,0,.6,1.3,.55,"#8d939b"); a(0,.4,.28,.3,.03,.02,"#3b3f46"); },
 rack:(a,c)=>{ a(0,.9,0,1.9,1.8,.5,"#cdd3da"); for(let k=0;k<4;k++){ a(-.55,.4+k*.4,.08,.5,.28,.3,pick(["#d46a6a","#4a7bc8","#d9b44a","#2e8b57"])); a(.5,.4+k*.4,.08,.6,.28,.3,pick(["#d46a6a","#4a7bc8","#d9b44a","#7c4a6e"])); } },
 mann:(a,c)=>{ a(0,.45,0,.3,.9,.2,c); a(0,1.12,0,.34,.5,.22,c); a(0,1.5,0,.2,.22,.2,"#e8c8a0"); a(0,.04,0,.5,.08,.5,"#3b3f46"); },
 bench:(a)=>{ a(0,.22,0,1.6,.08,.5,"#8a6a45"); a(-.7,.1,0,.08,.2,.4,"#3b3f46"); a(.7,.1,0,.08,.2,.4,"#3b3f46"); },
 coffin:(a)=>{ a(0,.3,0,.8,.55,2.0,"#3b2a22"); a(0,.62,0,.7,.1,1.9,"#5c4630"); a(0,.4,-1.02,.5,.4,.04,"#d9d2c4"); },
 cauldron:(a)=>{ a(0,.35,0,.9,.7,.9,"#2b2b30"); a(0,.72,0,.75,.06,.75,"#4be07a"); a(0,.1,0,1.1,.2,.2,"#5c4630"); },
 arcm:(a,c)=>{ a(0,.95,0,.8,1.9,.8,c); a(0,1.3,.41,.62,.5,.03,"#7dff7a"); a(0,.95,.41,.5,.1,.04,"#ffd23f"); a(0,.4,.41,.3,.3,.03,"#ff3b5c"); },
 sarc:(a)=>{ a(0,.4,0,1.0,.8,2.2,"#d9b44a"); a(0,.88,0,.86,.16,2.0,"#2a5db0"); a(0,.98,.7,.4,.12,.4,"#d9b44a"); },
 urn:(a)=>{ a(0,.45,0,.6,.9,.6,"#a0522d"); a(0,1.0,0,.4,.2,.4,"#c0764a"); a(0,.7,0,.66,.08,.66,"#d9b44a"); },
 chest:(a)=>{ a(0,.28,0,1.1,.56,.7,"#7a4a22"); a(0,.62,0,1.15,.14,.74,"#d9b44a"); a(0,.4,.36,.14,.2,.03,"#ffd23f"); },
 bars:(a)=>{ for(let k=-5;k<=5;k++) a(k*.2,1.1,0,.04,2.2,.04,"#3b3f46"); a(0,2.18,0,2.2,.06,.06,"#3b3f46"); a(0,.05,0,2.2,.06,.06,"#3b3f46"); },
 meet:(a)=>{ a(0,.74,0,2.6,.07,1.2,"#5c4630"); a(0,.36,0,1.8,.7,.6,"#3b3f46"); },
 crate:(a)=>{ a(0,.35,0,.8,.7,.8,"#9a7048"); a(0,.7,0,.84,.05,.84,"#7a5a38"); },
 barrel:(a)=>{ a(0,.45,0,.6,.9,.6,"#6b4a2a"); a(0,.3,0,.66,.06,.66,"#3b3f46"); a(0,.65,0,.66,.06,.66,"#3b3f46"); },
 machine:(a)=>{ a(0,.7,0,1.6,1.4,1.1,"#4a6a8a"); a(0,1.5,0,1.2,.2,.9,"#d9b44a"); a(.5,.4,.57,.3,.3,.03,"#ff3b3b"); },
 conv:(a)=>{ a(0,.3,0,3.0,.4,.7,"#5a5f68"); a(0,.5,0,3.2,.15,.8,"#3b3f46"); a(-1.5,.55,0,.2,.3,.9,"#d9b44a"); },
 hay:(a)=>{ a(0,.35,0,1.4,.7,.9,"#d8c066"); a(0,.9,0,1.2,.4,.8,"#cfb455"); },
 pew:(a)=>{ a(0,.25,0,2.4,.5,.5,"#6b4a2a"); a(0,.75,.22,2.4,.6,.08,"#6b4a2a"); },
 altar:(a)=>{ a(0,.55,0,1.8,1.1,.7,"#d8d2c4"); a(0,1.15,0,1.9,.1,.8,"#e8c14a"); a(-.6,1.4,0,.12,.5,.12,"#fff0c0"); a(.6,1.4,0,.12,.5,.12,"#fff0c0"); }
};
const SOFAC=["#8e5b3a","#3f5f8a","#6e7f5a","#a34a4a","#5a5a66","#7c4a6e","#2f6f6a"], BEDC=["#4a7bc8","#d46a6a","#2e8b57","#d9b44a","#7c4a6e"];
/* tek bir hücre (≈4.5 m) için eşya grubu */
function groupFor(kind,s,cx,y,cz,yaw,hw){
  const P=(fn,dx,dz,a,b,c)=>put(s,IT[fn],cx+dx*Math.cos(yaw)+dz*Math.sin(yaw),y,cz-dx*Math.sin(yaw)+dz*Math.cos(yaw),yaw+(a||0),b,c);
  const r=rnd();
  if(kind==="hospital"){ if(r<.7){ P("hbed",-1,-.4); P("hbed",1.1,-.4); P("drip",-.1,-1.2); P("curtain",0,.9); } else { P("desk",0,-1,0); P("ochair",0,.1,0,SOFAC[1]); P("cab",1.7,-1.5); } return; }
  if(kind==="school"){ if(r<.8){ for(let i=0;i<2;i++)for(let j=0;j<2;j++){ P("sdesk",-1+i*2,-.9+j*1.7); P("schair",-1+i*2,-.9+j*1.7); } } else { P("desk",0,-.8); P("ochair",0,.2,0,"#8a6a45"); P("shelf",1.7,-1.6); } return; }
  if(kind==="police"){ if(r<.55){ P("desk",0,-.8); P("ochair",0,.25,0,"#3b3f46"); P("cab",1.7,-1.6); } else if(r<.8){ P("bars",0,.3); P("bench",0,-1.3); } else { P("meet",0,0); P("ochair",-1,1.1,0,"#3b3f46"); P("ochair",1,1.1,0,"#3b3f46"); } return; }
  if(kind==="fire"){ for(let i=0;i<3;i++) P("locker",-1.2+i*1.2,-1.6,0,"#b01c1c"); P("bench",0,.2); return; }
  if(kind==="haunted"){ if(r<.4){ P("coffin",-.6,-.4); P("coffin",1.1,-.4,0); } else if(r<.7){ P("cauldron",0,-.8); P("shelf",1.7,-1.6); } else { P("bars",0,.3); P("chair",1.2,-1.2,0,"#3b3f46"); } return; }
  if(kind==="tomb"){ if(r<.4){ P("sarc",0,-.2); P("urn",-1.7,-1.6); P("urn",1.7,-1.6); } else if(r<.7){ P("chest",-.8,-1.2); P("chest",.9,-1.0,.4); P("urn",0,.8); } else { P("urn",-1.5,-1.4); P("sarc",1.2,.0,Math.PI/2); } return; }
  if(kind==="factory"){ if(r<.4){ P("machine",0,-.8); P("crate",1.6,-1.4); P("crate",-1.6,.9); } else if(r<.75){ P("crate",-.9,-1.2); P("crate",.2,-1.2); P("crate",-.35,-1.2,0); P("barrel",1.6,.6); P("barrel",1.6,1.4); } else { P("conv",0,0); P("barrel",-1.7,-1.5); P("machine",.2,-1.6,Math.PI); } return; }
  if(kind==="barn"){ if(r<.5){ P("hay",-.8,-1.2); P("hay",.8,-1.2); P("hay",0,.2,0); P("crate",1.8,1.2); } else { P("hay",-1.0,-1.3); P("barrel",1.6,-1.3); P("crate",1.5,.4); P("shelf",0,1.8,Math.PI); } return; }
  if(kind==="church"){ if(r<.75){ for(let k=0;k<3;k++){ P("pew",-1.2,-1.4+k*1.5); P("pew",1.5,-1.4+k*1.5); } } else { P("altar",0,-1.2); P("urn",-1.6,-.4); P("urn",1.6,-.4); } return; }
  if(kind==="arcade"){ const cs=["#d63a3a","#2a63c9","#9b5de5","#2e9d5a"]; for(let i=0;i<3;i++) P("arcm",-1.5+i*1.5,-1.6,0,cs[(i+((r*4)|0))%4]); if(r<.5){ for(let i=0;i<2;i++) P("arcm",-.8+i*1.6,1.7,Math.PI,cs[(i+1)%4]); } else P("counter",0,1.2,Math.PI); return; }
  if(kind==="mall"||kind==="shop"){ if(r<.45){ P("rack",0,-1.4); P("rack",0,.2,Math.PI); } else if(r<.7){ P("counter",0,-1.4); P("ochair",.5,-.2,0,"#3b3f46"); } else if(r<.85){ P("mann",-.8,0,0,"#d46a6a"); P("mann",.2,0,0,"#4a7bc8"); P("mann",1.1,.2,0,"#d9b44a"); } else { P("plant",-1.5,-1.5); P("bench",0,0); } return; }
  if(kind==="office"){ if(r<.6){ P("desk",-.9,-1.0); P("ochair",-.9,.1,Math.PI,"#3b3f46"); P("desk",1.0,-1.0); P("ochair",1.0,.1,Math.PI,"#506a8a"); } else if(r<.78){ P("meet",0,0); for(const dx of [-1,0,1]){ P("ochair",dx,1.1,Math.PI,"#3b3f46"); P("ochair",dx,-1.1,0,"#3b3f46"); } } else if(r<.9){ P("shelf",-1.2,-1.7); P("cab",.3,-1.7); P("plant",1.6,-1.5); } else { P("sofa",0,-1.3,0,SOFAC[pick([0,1,4])]); P("ctable",0,.2); } return; }
  // konut / otel
  if(r<.3){ P("rug",0,.1,0,pick(["#c9a46a","#7c4a6e","#2f6f6a","#a34a4a"])); P("sofa",0,-1.4,0,pick(SOFAC)); P("ctable",0,.2); P("plant",-1.8,-1.7); P("lamp",1.8,-1.7); }
  else if(r<.52){ P("bed",0,-.6,0,pick(BEDC)); P("stand",-1.2,-1.5); P("stand",1.2,-1.5); P("wardrobe",0,1.6,Math.PI,pick(["#d8d2c4","#8a6a45","#5c4630"])); }
  else if(r<.7){ P("dtable",0,0); for(const dx of [-.6,.6]){ P("dchair",dx,.85,Math.PI,pick(BEDC)); P("dchair",dx,-.85,0,pick(BEDC)); } }
  else if(r<.82){ P("counter",0,-1.7); P("fridge",1.8,-1.6); P("dtable",-.2,.5,0); P("dchair",-.2,1.4,Math.PI,pick(BEDC)); }
  else if(r<.92){ P("desk",0,-1.4); P("ochair",0,-.4,Math.PI,pick(BEDC)); P("shelf",1.7,-1.6); P("lamp",-1.8,-1.7); }
  else { P("tv",0,-1.8); P("sofa",0,.4,Math.PI,pick(SOFAC)); P("rug",0,-.3,0,"#506a8a"); } }
/* bir katman (t,L) için tüm kat(lar)ı döşe */
function furnish(t,L,rec){ const s=rec.slots, ly0=t.y0+L*t.LH, nf=Math.ceil(Math.min(t.LH,t.h-L*t.LH)/4-1e-6), gx0=t.ix0+.3, gz0=t.iz0+.3, iw=t.ix1-t.ix0-.6, id=t.iz1-t.iz0-.6, step=4.4, nx=Math.max(1,Math.floor(iw/step)), nz=Math.max(1,Math.floor(id/step)), cw=iw/nx, cd=id/nz;
  for(let f=0;f<nf;f++){ const y=ly0+f*4+((L===0&&f===0)?.14:.4);
    for(let i=0;i<nx;i++)for(let j=0;j<nz;j++){ const cx=gx0+(i+.5)*cw, cz=gz0+(j+.5)*cd;
      if(t.w>=10&&t.d>=10&&Math.hypot(cx-t.x,cz-t.z)<1.7) continue;                       // merkez kolon
      if(L===0&&f===0&&t.doorPos){ const p=t.doorPos, dx=cx-p.cx, dz=cz-p.cz; if(Math.abs(dx)<3.6&&Math.abs(dz)<3.6) continue; }   // kapı önü boş
      let yaw=Math.atan2(t.x-cx,t.z-cz); yaw=Math.round(yaw/(Math.PI/2))*(Math.PI/2);
      groupFor(t.kind,s,cx,y,cz,yaw,Math.min(cw,cd)/2); } }
  mesh.instanceMatrix.needsUpdate=true; mesh.instanceColor.needsUpdate=true; }
function release(rec){ for(const i of rec.slots){ Game.U.hide(A,i); free.push(i); } rec.slots.length=0; mesh.instanceMatrix.needsUpdate=true; }
const api={mesh,free:()=>free.length};
let acc=0;
api.update=function(dt){ acc-=dt; if(acc>0) return; acc=.35; const cam=camera.position, want=[];
  for(const e of Game.buildings){ const t=e.tier; if(!t||e.h<=0) continue; const d=Math.hypot(e.x-cam.x,e.z-cam.z); if(d>(cam.y>80?110:80)) continue;
    for(let L=0;L<t.walls.length;L++){ if(t.cores[L]<0||!Game.D.chunks[t.cores[L]].alive) continue; if(!(L===0&&t.door!==undefined)&&!(t.breach&&t.breach[L])) continue; want.push({t,L,d:d+L*3}); } }
  want.sort((a,b)=>a.d-b.d); const keep=new Set();
  for(const w of want){ const key=w.t.rev; const rec=key[w.L]||(key[w.L]={slots:[],t:w.t,L:w.L}); keep.add(rec); if(!rec.on){ if(free.length<260) break; rec.on=true; furnish(w.t,w.L,rec); } }
  for(const e of Game.buildings){ const t=e.tier; if(!t) continue; for(const rec of t.rev) if(rec&&rec.on&&!keep.has(rec)){ rec.on=false; release(rec); } } };
/* bir parça yıkıldı: duvarsa katmana "yırtık" işareti; zemin/çekirdekse mobilya düşer */
api.onKill=function(c){ const t=c.t; if(c.kind===0){ (t.breach||(t.breach=[]))[c.L]=true; }
  else if(c.kind===1){ const rec=t.rev[c.L]; if(rec&&rec.on){ rec.on=false; const n=Math.min(8,rec.slots.length>>2); for(let k=0;k<n;k++){ const s=.5+Math.random()*.9; if(Game.P) Game.P.spawnDebris({x:c.x+(Math.random()-.5)*(c.sx-2),y:c.y+(Math.random()-.5)*2,z:c.z+(Math.random()-.5)*(c.sz-2),sx:s,sy:s*.7,sz:s,r:.4,g:.25,b:.18,burn:0,frost:0,kind:0},(Math.random()-.5)*3,1,(Math.random()-.5)*3); } release(rec); } } };
api.onRevive=function(c){ const t=c.t; if(c.kind===0&&t.breach&&t.breach[c.L]){ const row=t.walls[c.L]; let all=true; if(row) for(const id of row){ const q=Game.D.chunks[id]; if(q&&!q.alive){ all=false; break; } } if(all) t.breach[c.L]=false; } };
Game.updaters.push(dt=>{ if(Game.mode==="play"||Game.mode==="menu") api.update(dt); });
return api;
})();
