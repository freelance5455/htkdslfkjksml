"use strict";
/* ===== HARİTA EFEKTLERİ: kar / kül yağışı (GPU parçacık), yıkık şehir hazırlığı ===== */
(function(){
const MP=Game.MAP, FX=Game.FX, D=Game.D;
{ const kind=MP.weather||"motes", N=kind==="snow"?1700:kind==="motes"?520:1100, BOX=kind==="motes"?64:90, seeds=new Float32Array(N*4);
  for(let i=0;i<N;i++){ seeds[i*4]=Math.random(); seeds[i*4+1]=Math.random(); seeds[i*4+2]=Math.random(); seeds[i*4+3]=.5+Math.random()*.9; }
  const g=new THREE.BufferGeometry(); g.setAttribute("position",new THREE.BufferAttribute(new Float32Array(N*3),3)); g.setAttribute("sd",new THREE.BufferAttribute(seeds,4));
  const snow=kind==="snow", mote=kind==="motes", u={time:{value:0},cam:{value:new THREE.Vector3()},scale:{value:800},fall:{value:snow?new THREE.Vector3(.7,-2.3,.4):mote?new THREE.Vector3(.18,.06,.1):new THREE.Vector3(1.2,-1.1,.4)},col:{value:snow?new THREE.Color(1,1,1):mote?new THREE.Color(1,.93,.78):new THREE.Color(.62,.52,.46)},op:{value:snow?.9:mote?.5:.7},size:{value:snow?.09:mote?.045:.07},vis:{value:1}};
  const m=new THREE.ShaderMaterial({transparent:true,depthWrite:false,uniforms:u,vertexShader:"attribute vec4 sd; uniform float time,scale,size,vis; uniform vec3 cam,fall; varying float va; void main(){ vec3 p=sd.xyz*"+BOX+".-vec3("+(BOX/2)+".)+fall*time*sd.w; p+=vec3(sin(time*.8+sd.x*30.),0.,cos(time*.7+sd.z*30.))*.6*sd.w; vec3 w=mod(p-cam+vec3("+(BOX/2)+".),"+BOX+".)-vec3("+(BOX/2)+".); vec3 world=cam+w; vec4 mv=viewMatrix*vec4(world,1.); gl_Position=projectionMatrix*mv; float d=length(w); va=vis*(1.-smoothstep("+(BOX*.35).toFixed(1)+","+(BOX*.5)+".,d)); gl_PointSize=clamp(size*scale/max(-mv.z,.4)*sd.w*8.,1.,26.); }",
    fragmentShader:"uniform vec3 col; uniform float op; varying float va; void main(){ vec2 c=gl_PointCoord-.5; float a=smoothstep(.5,.15,length(c))*op*va; if(a<.02) discard; gl_FragColor=vec4(col,a); }"});
  const pts=new THREE.Points(g,m); pts.frustumCulled=false; pts.renderOrder=6; scene.add(pts);
  Game.updaters.push((dt,time,raw)=>{ u.time.value=time; u.cam.value.copy(camera.position); const h=Game.three.renderer?Game.three.renderer.domElement.height:800; u.scale.value=h/(2*Math.tan(camera.fov*Math.PI/360)); u.vis.value=Math.max(0,Math.min(1,1-(camera.position.y-(mote?60:150))/(mote?120:250))); if(mote){ u.op.value=.5*(1-.75*(Game.night||0)); pts.visible=!!Game.ultra&&u.vis.value>.01; } else pts.visible=u.vis.value>.01; }); }
if(MP.ruins){ let done=false, smk=[];
  Game.updaters.push((dt,time,raw)=>{ const d=raw||dt;
    if(!done){ done=true; const r=(()=>{ let s=666; return ()=>{ s=(s*16807)%2147483647; return s/2147483647; }; })();
      for(const e of Game.buildings){ const t=e.tier; if(!t||e.h<=0||r()>.62) continue; const cutY=e.h*(.22+r()*.6);
        for(const c of t.chunks){ if(!c.alive) continue; if(c.y>cutY||r()<.06) D.killSilent(c); }
        if(r()<.45){ smk.push([e.x+(r()-.5)*e.hw,cutY+2,e.z+(r()-.5)*e.hd]); } }
      if(D.settleAll) D.settleAll();
      let n=0; for(const e of Game.buildings){ const t=e.tier; if(!t||n>18) continue; for(const c of t.chunks){ if(c.alive&&r()<.012){ D.ignite(c); n++; } } } }
    if(Game.mode==="play"||Game.mode==="menu"){ for(const s of smk){ if(Math.random()<d*2.2){ const cp=camera.position; if(Math.abs(cp.x-s[0])<260&&Math.abs(cp.z-s[2])<260) FX.smoke(s[0],s[1],s[2],1,2.2); } } } }); }
})();
