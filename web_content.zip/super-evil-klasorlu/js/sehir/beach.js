"use strict";
/* ===== PLAJ: şehir kıyısı boyunca şezlong + şemsiye kümeleri, can kurtaran kulesi, palmiyeler, kıyı yürüyüş patikası (NPC düğümleri) ve
   şezlonglara oturak kaydı (Game.Places "seat", meta.lounge) -- NPC'ler uzanır/güneşlenir. Kıyı: şehir hücrelerinin dışındaki kum şeridi. ===== */
(function(){
const CG=Game.CG, W=Game.W, rnd=CG.rnd, pick=CG.pick, fbox=CG.fbox, PL=Game.Places;
const B=Game.Beach={clusters:0,beds:0,umbrellas:0,towers:0,palms:0,paths:[],seats:0};
const bi=W.bridge&&W.bridge.info, WY=W.WATER_Y, H=(x,z)=>W.terrainH(x,z);
const nearBridge=(x,z)=>!!bi&&x>bi.X0-75&&Math.abs(z-bi.ZC)<60;
function shoreAt(a){ const cx=Math.cos(a), cz=Math.sin(a); for(let r=200;r<640;r+=1.5){ if(H(cx*r,cz*r)<WY-.02) return r; } return -1; }
const COLS=["#f8f8f8","#ffd23f","#ff6b6b","#4aa8ff","#2ec4b6","#ff9f43","#c77dff"], UMB=["#e63946","#2a9d8f","#ffd23f","#4a7bc8","#ff8a3c","#e0407a"];
function bed(bx,bz,nx,nz,yaw,col){ const A=CG.F(bx,bz), ty=H(bx,bz);
  CG.rbox(A,bx+nx*.25,ty+.17,bz+nz*.25,.5,.14,1.5,yaw,0,"#c9ccd1");                    // gövde
  CG.rbox(A,bx+nx*.3,ty+.31,bz+nz*.3,.72,.1,1.3,yaw,0,col);                           // minder
  CG.rbox(A,bx-nx*.78,ty+.46,bz-nz*.78,.72,.09,.82,yaw,.85,col); }                     // yükselen sırt dayanağı
function umbrella(cx,cz,c1){ const A=CG.F(cx,cz), ty=H(cx,cz); CG.cyl(A,cx,ty,cz,.05,.05,2.55,6,"#e8e8e8"); CG.stripeCone(A,cx,ty+2.4,cz,2.05,.1,.72,10,c1,"#f8f8f8"); }
function tower(x,z,nx,nz,yaw){ const A=CG.F(x,z), ty=H(x,z); for(const sx of [-.8,.8]) for(const sz of [-.8,.8]){ const px=x+nz*sx+nx*sz, pz=z-nx*sx+nz*sz; CG.cyl(A,px,ty,pz,.08,.08,1.7,6,"#f2f2f2"); }
  CG.rbox(A,x,ty+1.75,z,2.1,.12,2.1,yaw,0,"#f2f2f2"); CG.rbox(A,x-nx*.85,ty+2.5,z-nz*.85,2.1,1.4,.12,yaw,0,"#ff5a4a"); for(const s of [-1,1]) CG.rbox(A,x+nz*s*1.0,ty+2.5,z-nx*s*1.0,.12,1.4,2.0,yaw,0,"#ff5a4a");
  CG.rbox(A,x,ty+3.3,z,2.5,.14,2.5,yaw,.0,"#ffffff"); CG.rbox(A,x+nx*.9,ty+1.05,z+nz*.9,.7,1.5,.1,yaw,0,"#f2f2f2"); B.towers++; }
const da0=0.0, STEP=13;
let seg=[], segs=[], cnt=0;
const flush=()=>{ if(seg.length>=2) segs.push(seg); seg=[]; };
for(let a=0;a<Math.PI*2;){ const rs=shoreAt(a); if(rs<0){ a+=.02; flush(); continue; }
  const da=STEP/rs, wx=Math.cos(a)*rs, wz=Math.sin(a)*rs;
  /* kıyı normali: yokuş aşağı (denize) yön; yoksa radyal */
  let nx=Math.cos(a), nz=Math.sin(a); { const px=wx-nx*6, pz=wz-nz*6, gx=H(px-2,pz)-H(px+2,pz), gz=H(px,pz-2)-H(px,pz+2), gl=Math.hypot(gx,gz); if(gl>.004){ const ux=gx/gl, uz=gz/gl; if(ux*nx+uz*nz>.55){ nx=ux; nz=uz; } } }
  const tx=-nz, tz=nx, yaw=Math.atan2(nx,nz);
  /* patika: kıyıdan ~14 m içeride (kum; şehir kaldırımına ≥ 8.5 m) */
  { const px=wx-nx*14, pz=wz-nz*14; if(!nearBridge(px,pz)&&W.distCity(px,pz)>8.5&&H(px,pz)>WY+.5) seg.push([px,pz]); else flush(); }
  /* küme: şemsiye + 2 şezlong, kıyıdan 7-10 m içeride */
  { const d=7+rnd()*3, cx=wx-nx*d, cz=wz-nz*d, ch=H(cx,cz);
    if(!nearBridge(cx,cz)&&W.distCity(cx,cz)>8.5&&ch>WY+.3&&ch<.02&&H(cx+tx*3,cz+tz*3)>WY+.2&&H(cx-tx*3,cz-tz*3)>WY+.2&&cnt%1===0){
      umbrella(cx,cz,pick(UMB)); B.umbrellas++; B.clusters++;
      const nb=rnd()<.8?2:1; for(let k=0;k<nb;k++){ const s=nb===2?(k?1:-1):0, bx=cx+tx*s*1.3, bz=cz+tz*s*1.3; bed(bx,bz,nx,nz,yaw,pick(COLS)); B.beds++;
        /* oturak: şezlong üstünde (pelvis, minderin ortası) -- NPC yüzü denize bakar */
        PL.add("seat",bx+nx*.18,bz+nz*.18,yaw,{y:.38,lounge:1}); B.seats++; }
      if(cnt%9===4&&W.distCity(cx-nx*3,cz-nz*3)>9){ tower(cx+tx*6.5,cz+tz*6.5,nx,nz,yaw); }
      if(cnt%3===1){ const px=cx-nx*(5+rnd()*2.5)+tx*(rnd()-.5)*6, pz=cz-nz*(5+rnd()*2.5)+tz*(rnd()-.5)*6; if(W.distCity(px,pz)>9.5&&H(px,pz)>WY+.5){ CG.palm(px,pz,.85+rnd()*.35); B.palms++; } }
      cnt++; } }
  a+=da; }
flush(); B.paths=segs;
})();
