"use strict";
/* ===== YAPI TİPLERİ (karma): sanayi, çiftlik/tarla/bahçe/orman/göl, kasaba (meydan, tuğla dükkân, kilise, belediye), eski çarşı, iş merkezi, spor sahası ===== */
(function(){
const CG=Game.CG, rnd=CG.rnd, pick=CG.pick, pbox=CG.pbox, fbox=CG.fbox, PAL=CG.PAL, GR=()=>Game.MAP.grass||"#5aa845", GFX=CG.gfx, lp=GFX.lp, dim=GFX.dim, FWD=[[0,1],[1,0],[0,-1],[-1,0]];
const IC=["#efe6d8","#e8dcc8","#dfe6dc","#e9d9d4","#e4e8ee"], FL=()=>pick(["#a98a62","#9b8668","#b59d7a"]), BRICK=["#e3a98f","#d99b80","#e8b79a","#cf8f78","#dcb08c","#c98a70"];
const SHOPN=["CAFE","BAKERY","PHARMACY","BOOKS","PIZZA","FLOWERS","MARKET","TECH","SHOES","BARBER","TOYS","BURGER"], SHOPC=["#c0392b","#2e86c1","#1e8449","#af601a","#7d3c98","#117a65","#b9770e","#2874a6","#a93226","#1f618d"];
const canopy=(col,y)=>(A,p,t,dg)=>CG.canopy(A,p,dg,col,y);

/* ---------- kırsal zemin: yolu olmayan kenarlar da alan ile dolar ---------- */
CG.fieldSlab=function(cx,cz,hex,h,e){ h=h||.08; const A=CG.F(cx,cz); fbox(A,cx,0,cz,24,h,24,hex); e=e||[1,1,1,1];
  const fill=s=>!e[s];
  if(fill(0)) fbox(A,cx,0,cz+14.5,24,h,5,hex); if(fill(2)) fbox(A,cx,0,cz-14.5,24,h,5,hex); if(fill(1)) fbox(A,cx+14.5,0,cz,5,h,24,hex); if(fill(3)) fbox(A,cx-14.5,0,cz,5,h,24,hex);
  for(const sx of [-1,1]) for(const sz of [-1,1]) if(fill(sz>0?0:2)&&fill(sx>0?1:3)) fbox(A,cx+sx*14.5,0,cz+sz*14.5,5,h,5,hex); return A; };
/* köşe ve kenarda yola bakan sokak ağaçları */
CG.ruralEdge=function(cx,cz,e){ for(let s=0;s<4;s++){ if(!e[s]) continue; const a=FWD[s]; for(const t of [-7,7]) if(rnd()<.6){ const lat=s%2===0; CG.tree(cx+(lat?t:a[0]*11.2),cz+(lat?a[1]*11.2:t),.8+rnd()*.4,pick([0,2,3])); } } };
function crops(A,x0,z0,w,d,alongX,col,soil){ fbox(A,x0,.08,z0,w,.03,d,soil||"#6b5a3c"); const n=Math.floor((alongX?d:w)/1.7);
  for(let i=0;i<n;i++){ const o=(i-(n-1)/2)*1.7; if(alongX) fbox(A,x0,.1,z0+o,w-.6,.42,.8,col); else fbox(A,x0+o,.1,z0,.8,.42,d-.6,col); } }
function hay(A,x,z){ CG.cyl(A,x,.1,z,.95,.95,1.2,10,"#d9bd5a",true); }
function stall(A,x,z,col){ Game.Places.add("stall",x,z+1.7,Math.PI,{sx:x,sz:z}); fbox(A,x,.12,z,2.6,.9,1.3,"#8a6a45"); for(const sx of [-1.2,1.2]) fbox(A,x+sx,.12,z-.5,.1,2.4,.1,"#5b4636"); fbox(A,x,2.5,z,3,.12,2.2,col); fbox(A,x,1.0,z,2.2,.25,.9,pick(["#d9534f","#f0ad4e","#5cb85c","#e8e0c8"])); }
function bench(A,x,z,ax){ CG.prop("bench",x,z,ax?Game.Places.faceZ(x,z):Game.Places.faceX(x,z)); Game.Places.bench(x,z,ax,.57); }

/* ---------- sanayi ---------- */
function container(A,x,y,z,alongX,col){ fbox(A,x,y,z,alongX?6:2.4,2.5,alongX?2.4:6,col); fbox(A,x,y+2.5,z,alongX?6.05:2.45,.08,alongX?2.45:6.05,"#2b2b30"); }
function tank(A,x,z,r,h,col){ CG.cyl(A,x,0,z,r,r,h,14,col,true); CG.cyl(A,x,h,z,r,r*.2,r*.5,14,col); Game.buildings.push({x,z,hw:r,hd:r,h:h+r*.5}); }
CG.industrial=function(cx,cz){ CG.slab(cx,cz,"#9b9ea3",.12); const A=CG.F(cx,cz), T=pick([0,1,2,3]), f=pick([0,2]);
  if(T===0){ // depo + kamyonlar
    const [w,d]=dim(f,20,11), p=lp(cx,cz,f,-3,0), t=CG.tier(CG.bl(),{x:p[0],z:p[1],w,d,y0:0,h:9,LH:9,T:.7,style:"m",tint:pick(["#b9c3cc","#c9b79c","#9fb0c4","#c4cbb8"]),kind:"factory",door:f,doorW:6,ic:"#d9d6cc",fc:"#8a8d92",roof:"gable",roofCol:"#7d858e",rh:1.8,doorDeco:canopy("#e8b220",5.4),props:(top,A2)=>{ for(let i=0;i<3;i++) pbox(A2,p[0]-6+i*6,top-.4,p[1],1.4,1.1,1.4,"#9aa0a8"); return top+1; }});
    CG.doorSign(t,"CARGO",5,1.1,"#2a2d33","#ffd23f",6.6); const q=lp(cx,cz,f,8.4,-5); CG.addCar(q[0],q[1],f%2===1,"#f2f2f2",8,2.5,3.2,3); fbox(A,cx,.12,cz+(f===0?9:-9),22,.03,5,"#6d7075"); }
  else if(T===1){ // fabrika + baca
    const p=lp(cx,cz,f,-3,0), [w,d]=dim(f,16,11); CG.tier(CG.bl(),{x:p[0],z:p[1],w,d,y0:0,h:10,LH:10,T:.8,style:"m",tint:pick(["#d9c9b0","#c4ccd4","#cfc4b4"]),kind:"factory",door:f,doorW:5,ic:"#d9d6cc",fc:"#8a8d92",roof:"flat",slabCol:"#8d9298",parCol:"#7d838b",doorDeco:canopy("#2a2d33",5),props:(top,A2,tt)=>CG.roofProps(top,A2,tt)});
    const c=lp(cx,cz,f,-3,-9.2), t2=CG.tier(CG.bl(),{x:c[0],z:c[1],w:3.4,d:3.4,y0:0,h:30,LH:10,T:.7,style:"k",tint:"#c98a70",kind:"factory",interior:false,roof:"none",panelDeco:CG.deco.trim({cornice:true,plinth:true,col:"#2a2d33",base:"#6e665c"})});
    fbox(A,cx+(f%2?0:5),.12,cz+(f%2?5:-7.8)*(f===2?-1:1),4,1,4,"#3b3f46"); tank(A,cx+7,cz+(f===0?-8:8),2.2,6,"#c9ced3"); }
  else if(T===2){ // konteyner sahası + vinç
    for(let i=0;i<3;i++) for(let j=0;j<2;j++){ const col=pick(["#c0392b","#2e86c1","#1e8449","#e8b220","#7d3c98","#d9d9d9"]); container(A,cx-6+j*0,.12,cz-8+i*7,false,col); container(A,cx-3.2,.12,cz-8+i*7,false,pick(["#c0392b","#2e86c1","#1e8449","#e8b220"])); if(rnd()<.6) container(A,cx-6+j*0,2.62,cz-8+i*7,false,pick(["#c0392b","#2e86c1","#1e8449","#e8b220"])); }
    for(const sx of [-1,1]) for(const sz of [-1,1]) fbox(A,cx+4+sx*3.6,.12,cz+sz*6,.5,12,.5,"#e8b220"); fbox(A,cx+4,12,cz,.7,.7,13,"#e8b220"); fbox(A,cx+4,12,cz-6.5,8.6,.7,.7,"#e8b220"); fbox(A,cx+4,12,cz+6.5,8.6,.7,.7,"#e8b220");
    CG.addCar(cx+6,cz+9,false,"#f2f2f2",8,2.5,3.2,3); }
  else { // silolar + depolama
    for(let i=0;i<3;i++) tank(A,cx-6+i*6,cz-6,2.4,10+i*2,pick(["#c9ced3","#d9dde2","#b9c0c8"])); fbox(A,cx,10,cz-6,15,.25,.5,"#7d838b"); for(let i=0;i<3;i++) fbox(A,cx-6+i*6,.12,cz-6,.5,10+i*2,.5,"#7d838b");
    const p=lp(cx,cz,f,4,0), [w,d]=dim(f,18,7); CG.tier(CG.bl(),{x:p[0],z:p[1],w,d,y0:0,h:7,LH:7,T:.7,style:"m",tint:"#c4ccd4",kind:"factory",door:f,doorW:4.5,ic:"#d9d6cc",fc:"#8a8d92",roof:"gable",roofCol:"#7d858e",rh:1.4,doorDeco:canopy("#2a2d33",4.6)}); }
  for(let i=0;i<4;i++) fbox(A,cx-9+i*6,.12,cz+(T===0?0:11.3),.3,1.2,.3,"#555"); return "ind"; };

/* ---------- çiftlik / kırsal ---------- */
CG.farmCell=function(cx,cz,e){ const r=rnd(), G1=GR(); CG.fieldSlab(cx,cz,r<.4?"#8aa84a":r<.7?"#b9a653":"#7a9a42",.08,e); const A=CG.F(cx,cz); CG.ruralEdge(cx,cz,e);
  if(r<.2){ // çiftlik avlusu
    const f=pick([0,2]); CG.fieldSlab(cx,cz,"#9ab25a",.08,e); CG.farmhouse(cx+(f===0?-5:5),cz+(f===0?5.4:-5.4),f); CG.barn(cx+(f===0?5.4:-5.4),cz+(f===0?-3:3),f===0?2:0,true); { const sx=cx+(f===0?8.2:-8.2), sz=cz+(f===0?7.8:-7.8); CG.cyl(A,sx,0,sz,2.2,2.2,11,12,"#c9ced3",true); CG.cyl(A,sx,11,sz,2.2,0,2.4,12,"#9aa0a8"); Game.buildings.push({x:sx,z:sz,hw:2.3,hd:2.3,h:13.4}); } for(let i=0;i<3;i++) hay(A,cx-8+i*2.4,cz+(f===0?-9:9)); fbox(A,cx,.1,cz,24,.02,2.4,"#c9b89a"); }
  else if(r<.4){ crops(A,cx-6,cz,10.6,22,false,pick(["#5f9a35","#7aa83a","#c9b44a"]),"#6b5a3c"); crops(A,cx+6,cz,10.6,22,false,pick(["#5f9a35","#d9a73a","#8a9a3a"]),"#6b5a3c"); }
  else if(r<.58){ crops(A,cx,cz-6,22,10.6,true,pick(["#c9b44a","#d9bd5a","#9ab03a"]),"#7a6540"); crops(A,cx,cz+6,22,10.6,true,pick(["#5f9a35","#c9b44a"]),"#7a6540"); for(let i=0;i<3;i++) hay(A,cx-7+i*7,cz); }
  else if(r<.74){ // otlak + çit + ağaçlar
    const fp=pick(["#f1efe8","#8a6a45"]); GFX.fence(A,cx-11,cz-11,cx+11,cz-11,fp); GFX.fence(A,cx-11,cz+11,cx+11,cz+11,fp); GFX.fence(A,cx-11,cz-11,cx-11,cz+11,fp); GFX.fence(A,cx+11,cz-11,cx+11,cz+11,fp);
    for(let i=0;i<5;i++) CG.tree(cx-8+rnd()*16,cz-8+rnd()*16,.9+rnd()*.5,pick([0,0,2])); for(let i=0;i<4;i++){ const x=cx-7+rnd()*14, z=cz-7+rnd()*14, bw=rnd()<.5; fbox(A,x,.5,z,1.6,.9,.7,bw?"#f4f4f4":"#6b4a33"); fbox(A,x+.9,.9,z,.6,.5,.5,bw?"#222":"#f4f4f4"); for(const sx of [-.6,.6]) for(const sz of [-.2,.2]) fbox(A,x+sx,.1,z+sz,.14,.45,.14,"#3b3b3b"); } }
  else if(r<.86){ // rüzgâr türbini
    crops(A,cx,cz+5,22,9,true,"#7aa83a","#6b5a3c"); CG.windTurbine(cx-3,cz-3); if(rnd()<.55) CG.windTurbine(cx+7,cz-8,.85); }
  else { crops(A,cx-6,cz,10.6,22,false,"#2f8a3a","#6b5a3c"); crops(A,cx+6,cz,10.6,22,false,"#d9a73a","#6b5a3c"); const q=pick([[-7,-7],[7,7]]); CG.cabin?CG.cabin(cx+q[0],cz+q[1],0):0; }
  return "farm"; };
CG.orchardCell=function(cx,cz,e){ CG.fieldSlab(cx,cz,"#8aa84a",.08,e); const A=CG.F(cx,cz); CG.ruralEdge(cx,cz,e);
  for(let i=0;i<4;i++) for(let j=0;j<4;j++) if(rnd()<.92) CG.tree(cx-8.4+i*5.6+(rnd()-.5)*.8,cz-8.4+j*5.6+(rnd()-.5)*.8,.8+rnd()*.25,pick([0,3])); fbox(A,cx,.1,cz-2.8,22,.02,1.2,"#c9b89a"); fbox(A,cx,.1,cz+2.8,22,.02,1.2,"#c9b89a"); if(rnd()<.5) CG.cabin(cx+7,cz+7,3); return "farm"; };
CG.forestCell=function(cx,cz,e){ CG.fieldSlab(cx,cz,pick(["#4f8f3f","#468338","#548f40"]),.08,e); const A=CG.F(cx,cz); CG.ruralEdge(cx,cz,e);
  const n=13+((rnd()*5)|0); for(let i=0;i<n;i++){ const x=cx-11+rnd()*22, z=cz-11+rnd()*22; if(Math.abs(x-cx)<2.5&&Math.abs(z-cz)<2.5&&rnd()<.7) continue; CG.tree(x,z,.9+rnd()*.7,rnd()<.38?1:pick([0,0,2,3])); }
  for(let i=0;i<4;i++) CG.rock(cx-10+rnd()*20,cz-10+rnd()*20,.6+rnd()*1.2); for(let i=0;i<3;i++){ const x=cx-8+rnd()*16, z=cz-8+rnd()*16; fbox(A,x,.12,z,2.8,.5,.5,"#6b4a33"); }
  if(rnd()<.18){ CG.cabin(cx,cz,pick([0,1,2,3])); fbox(A,cx+4,.12,cz+4,1.4,.3,1.4,"#3b3b3b"); fbox(A,cx+4,.4,cz+4,.9,.4,.9,"#ff7a1c"); } return "forest"; };
CG.lakeCell=function(cx,cz,e){ CG.fieldSlab(cx,cz,"#d9cba0",.08,e); const A=CG.F(cx,cz), T=CG.T(cx,cz); CG.ruralEdge(cx,cz,e);
  fbox(A,cx,.08,cz,19,.03,19,GR()); fbox(T,cx,.1,cz,15,.1,15,"#3d94d6"); fbox(T,cx+2,.1,cz-5,10,.1,8,"#3d94d6"); fbox(T,cx-3,.1,cz+4,9,.1,9,"#3d94d6");
  for(let i=0;i<8;i++){ const a=i/8*6.28, x=cx+Math.cos(a)*9.5, z=cz+Math.sin(a)*9.5; fbox(A,x,.12,z,.18,1.6,.18,"#4f8a3a"); fbox(A,x+.3,.12,z,.18,1.3,.18,"#5f9a3a"); }
  fbox(A,cx,.2,cz+8.6,2,.2,6,"#8a6038"); for(let i=0;i<6;i++) CG.tree(cx-11+rnd()*22,cz-11+rnd()*22,.9+rnd()*.5,pick([0,3,1])); return "lake"; };
/* rüzgâr türbini: ayrı mesh grubu (kule + gondol + dönen rotor); Game.Turbines kırılma/devrilme/yeniden dikilmeyi yönetir */
CG.windTurbine=function(x,z,sc){ sc=sc||1; const H=34*sc, e={x,z,hw:1.3*sc,hd:1.3*sc,h:H,turbine:true}; Game.buildings.push(e);
  const g=new THREE.Group(); g.position.set(x,Game.W&&Game.W.terrainH?Math.max(0,Game.W.terrainH(x,z)):0,z); scene.add(g);
  const tw=CG.rig(); tw.cyl(0,H/2,0,1.3*sc,.7*sc,H,14,"#eceef1"); tw.cyl(0,.7*sc,0,1.5*sc,1.5*sc,1.4*sc,14,"#9aa0a8"); for(let k=1;k<4;k++) tw.cyl(0,H*k/4.2,0,(1.3-.6*k/4.2)*sc*1.02,(1.3-.6*k/4.2)*sc*1.02,.22*sc,14,"#c9ced4"); tw.cyl(0,H-.2*sc,0,.78*sc,.78*sc,.5*sc,14,"#b8bec6");
  const tm=tw.mesh(); g.add(tm);
  const nac=CG.rig(); nac.box(0,0,0,1.5*sc,1.6*sc,3.6*sc,"#dfe2e6"); nac.box(0,.95*sc,.2*sc,.5*sc,.3*sc,.9*sc,"#8a9099"); nac.box(0,0,1.9*sc,1.3*sc,1.3*sc,.3*sc,"#b8bec6"); const nm=nac.mesh(); nm.position.set(0,H+.8*sc,0); g.add(nm);
  const rg=new THREE.Group(); rg.position.set(0,H+.8*sc,-2*sc); g.add(rg);
  const r=CG.rig(); r.cyl(0,0,0,.6*sc,.6*sc,1.2*sc,12,"#cfd3d8",{rx:Math.PI/2}); r.cyl(0,0,-.9*sc,.5*sc,.05*sc,.9*sc,12,"#e8ebef",{rx:Math.PI/2});
  for(let k=0;k<3;k++){ const a=k*Math.PI*2/3, ca=Math.cos(a), sa=Math.sin(a); r.bar(sa*1.2*sc,ca*1.2*sc,0,sa*8*sc,ca*8*sc,.05*sc,.75*sc,"#f4f6f8",.16*sc); r.bar(sa*8*sc,ca*8*sc,.02*sc,sa*16*sc,ca*16*sc,.05*sc,.42*sc,"#f4f6f8",.1*sc); }
  const rm=r.mesh(); rg.add(rm);
  const T={x,z,sc,H,g,tower:tm,nac:nm,rg,rm,e,hp:1,st:"up",t:0,th:0,w:0,dx:1,dz:0,spin:.5+Math.random()*.4,y0:g.position.y,ph:Math.random()*6};
  (Game.turbines||(Game.turbines=[])).push(T); return T; };

/* ---------- kasaba ---------- */
CG.brickShop=function(x,z,w,d,face,tint,floorsUp){ const bl=CG.bl(), nm=pick(SHOPN), side=face>0?0:2, col=pick(SHOPC);
  const t0=CG.tier(bl,{x,z,w,d,y0:0,h:8,LH:8,style:"s",tint,kind:"shop",door:side,doorW:2.6,ic:pick(["#f1ead9","#ece4d2","#e6edf0"]),fc:pick(["#b8a07a","#9ea3a8","#c9b79c"]),roof:floorsUp?"none":"flat",doorDeco:canopy(col,3.5),panelDeco:CG.deco.trim({plinth:false,cornice:!floorsUp,col:"#f1ede4"}),
    props:floorsUp?undefined:(top,A2)=>{ pbox(A2,x-w*.2,top+.5,z,2,1.1,2,"#8d939b"); return top+1.8; }});
  CG.doorSign(t0,nm,5.4,1.1,col,"#fff",5.9);
  if(floorsUp) CG.tier(bl,{x,z,w,d,y0:8,h:floorsUp*4,LH:8,style:"k",tint,kind:"res",ic:pick(IC),fc:FL(),roof:pick(["flat","gable"]),roofCol:pick(CG.RC),rh:3,panelDeco:CG.deco.trim({plinth:false,ledge:true,balcony:3,col:"#f1ede4"}),props:(top,A2)=>{ pbox(A2,x,top+.5,z-d*.2,1.6,1.4,1.6,"#8d939b"); return top+2; }});
  return t0; };
CG.clockTower=function(x,z,h0){ const bl=CG.bl(), tint=pick(BRICK), A=CG.F(x,z); h0=h0||16;
  const t=CG.tier(bl,{x,z,w:7,d:7,y0:0,h:h0,LH:8,T:.9,style:"k",tint,kind:"res",door:0,doorW:2.2,ic:pick(IC),fc:FL(),roof:"none",doorDeco:canopy("#3b3f46",3.4),panelDeco:CG.deco.trim({ledge:true,col:"#f1ede4"})});
  const t2=CG.tier(bl,{x,z,w:5.8,d:5.8,y0:h0,h:8,LH:8,T:.8,style:"p",tint:"#f3ecdc",kind:"res",ic:pick(IC),fc:FL(),roof:"hip",roofCol:"#4a5058",rh:7,props:(top,A2)=>{ pbox(A2,x,top,z,.2,3,.2,"#c9a74a"); pbox(A2,x,top+2,z,1.2,.2,.2,"#c9a74a"); return top+3.2; }});
  for(const s of [0,1,2,3]) CG.wallSign(t2,s,"12",3,3,"#fafaf5","#222",h0+4.2); return t; };
CG.church=function(cx,cz,f){ const bl=CG.bl(), tint=pick(["#ddd5c4","#e3dccb","#d8cfbb"]), W0=9.4, D0=15, [w,d]=dim(f,W0,D0), p=lp(cx,cz,f,-1,0), A=CG.F(cx,cz);
  CG.tier(bl,{x:p[0],z:p[1],w,d,y0:0,h:9,LH:9,T:.9,style:"k",tint,kind:"church",ic:"#efe6d8",fc:"#a98a62",roof:"gable",roofCol:"#5a5f68",rh:5,panelDeco:CG.deco.trim({ledge:false,col:"#f1ede4"})});
  const tp=lp(cx,cz,f,D0/2-1+1.2,0), [tw,td]=dim(f,6,6), t=CG.tier(bl,{x:tp[0],z:tp[1],w:tw,d:td,y0:0,h:20,LH:10,T:.9,style:"k",tint,kind:"church",door:f,doorW:2.6,ic:"#efe6d8",fc:"#a98a62",roof:"hip",roofCol:"#4a5058",rh:9,doorDeco:canopy("#5b4636",3.6),panelDeco:CG.deco.trim({ledge:true,col:"#f1ede4"}),
    props:(top,A2)=>{ pbox(A2,tp[0],top,tp[1],.25,3.2,.25,"#c9a74a"); pbox(A2,tp[0],top+1.8,tp[1],1.5,.25,.25,"#c9a74a"); return top+3.4; }});
  CG.doorSign(t,"CHURCH",4,.9,"#3a2f26","#f1e4c2",4.7);
  for(let i=0;i<6;i++){ const q=lp(cx,cz,f,-D0/2-2.2,-8+i*3.2); fbox(A,q[0],.12,q[1],.6,.9,.2,"#9a9a98"); } return t; };
CG.townHall=function(cx,cz,f){ const bl=CG.bl(), W0=15, D0=9.6, [w,d]=dim(f,W0,D0), p=lp(cx,cz,f,-1.6,0), A=CG.F(cx,cz);
  const t=CG.tier(bl,{x:p[0],z:p[1],w,d,y0:0,h:12,LH:8,T:.9,style:"p",tint:pick(["#f3ead7","#efe4cc","#e8e3d6"]),kind:"police",door:f,doorW:3.4,ic:"#eef0f2",fc:"#a98a62",roof:"flat",slabCol:"#d9d4c8",parCol:"#c9c3b6",panelDeco:CG.deco.trim({ledge:true,col:"#fbf8f2",base:"#9b968c"}),
    doorDeco:(A2,pp,tt,dg)=>{ const a=FWD[pp.s], lat=pp.s%2===0; for(const k of [-1.7,0,1.7]) CG.cyl(A2,pp.cx+a[0]*2.4+(lat?k:0),0,pp.cz+a[1]*2.4+(lat?0:k),.3,.26,4.3,8,"#f4f0e8",true); pbox(A2,pp.cx+a[0]*2.4,4.3,pp.cz+a[1]*2.4,lat?5.6:3,.4,lat?3:5.6,"#ece6dc"); }});
  CG.doorSign(t,"TOWN HALL",6,1.2,"#2a3a5a","#ffffff",5.8);
  const cp=lp(cx,cz,f,-1.6,0), t2=CG.tier(bl,{x:cp[0],z:cp[1],w:5,d:5,y0:12,h:8,LH:8,T:.8,style:"p",tint:"#f3ecdc",kind:"police",ic:"#eef0f2",fc:"#a98a62",roof:"hip",roofCol:"#4a5058",rh:6,props:(top,A2)=>{ pbox(A2,cp[0],top,cp[1],.2,2.6,.2,"#c9a74a"); return top+2.8; }});
  for(const s of [0,1,2,3]) CG.wallSign(t2,s,"12",2.6,2.6,"#fafaf5","#222",16.2); const q=lp(cx,cz,f,D0/2+3,8); CG.flag(q[0],q[1],"#d62828"); return t; };
CG.townSquare=function(cx,cz){ CG.slab(cx,cz,"#d6d0c2",.14); const A=CG.F(cx,cz), T=CG.T(cx,cz), f=pick([0,2]), r=rnd();
  if(r<.5) CG.church(cx,cz-(f===0?4.6:-4.6),f===0?1:3); else CG.townHall(cx,cz-(f===0?3.6:-3.6),f);
  const fx=cx, fz=cz+(f===0?6.4:-6.4); fbox(A,fx,.14,fz,5.4,.5,5.4,"#c8c2b2"); fbox(T,fx,.64,fz,4.6,.2,4.6,"#4ba3e3"); fbox(A,fx,.14,fz,1,2,1,"#c3c8ce"); fbox(T,fx,2.2,fz,1.8,.2,1.8,"#4ba3e3");
  for(let i=0;i<2;i++) stall(A,cx-8+i*16,fz+(f===0?2:-2),pick(SHOPC)); bench(A,cx-4,fz+(f===0?4:-4),true); bench(A,cx+4,fz+(f===0?4:-4),true);
  for(const s of [-1,1]) CG.tree(cx+s*10,fz,1.1,0); CG.lamp(cx+3,fz+2,1,0); CG.lamp(cx-3,fz-2,-1,0); return "square"; };
/* ana cadde: tuğla dükkân sırası */
CG.mainStreet=function(cx,cz){ CG.slab(cx,cz,"#dcdee1"); const A=CG.F(cx,cz), face=rnd()<.5?1:-1;
  for(let i=0;i<3;i++){ const x=cx+(i-1)*7.2; CG.brickShop(x,cz-face*5.4,6.9,10,face,pick(BRICK.concat(["#efe6d8","#dfe6ee"])),pick([1,2,2,3])); }
  const fz=cz+face*8.4; fbox(A,cx,.12,fz,23,.04,4,"#d9d2c0"); for(let i=0;i<3;i++){ CG.tree(cx-8+i*8,fz+face*1.3,1,pick([0,3])); if(i<2) bench(A,cx-4+i*8,fz-face*.8,true); /* 3. bank x=+12'ye (yola) düşüyordu */ } return "shops"; };
/* kasaba evleri: karışık */
CG.townHouses=function(cx,cz){ return (rnd()<.5?CG.suburbBlock:CG.cottageBlock)(cx,cz); };

/* ---------- şehir merkezleri ---------- */
/* iş merkezi: uzun cam kuleler, plaza, otel */
CG.bizCell=function(cx,cz){ const r=rnd();
  if(r<.7){ CG.tower(cx,cz,22+((rnd()*26)|0)); return "tower"; }
  if(r<.82){ CG.plaza(cx,cz); return "plaza"; }
  if(r<.92){ CG.mall(cx,cz); return "mall"; }
  CG.tower(cx,cz,40); return "tower"; };
/* eski çarşı: tuğla dükkân cadde, pazar yeri, saat kulesi, kilise */
CG.oldCell=function(cx,cz){ const r=rnd(), A=(CG.slab(cx,cz,"#d9d3c6",.12),CG.F(cx,cz));
  if(r<.4){ const face=rnd()<.5?1:-1; for(const row of [-1,1]) for(let i=0;i<3;i++){ const x=cx+(i-1)*7.2, z=cz+row*6.1; CG.brickShop(x,z,6.9,9,row>0?-1:1,pick(BRICK.concat(["#efe6d8","#dfd2b0"])),pick([2,3,4,3])); } fbox(A,cx,.14,cz,23,.04,3.2,"#c9b89a"); for(let i=0;i<4;i++) CG.lamp(cx-9+i*6,cz,0,1); return "old"; }
  if(r<.62){ for(let i=0;i<3;i++) for(let j=0;j<2;j++) stall(A,cx-7+i*7,cz-4+j*8,pick(SHOPC)); fbox(A,cx,.14,cz,4,.5,4,"#c8c2b2"); fbox(CG.T(cx,cz),cx,.64,cz,3.2,.2,3.2,"#4ba3e3"); for(let i=0;i<4;i++) CG.tree(cx+(i%2?9:-9),cz+(i<2?-9:9),1,0); return "plaza"; }
  if(r<.78){ CG.clockTower(cx,cz-2,pick([16,20])); fbox(A,cx,.14,cz+7,12,.05,8,"#e2dbc9"); for(let i=0;i<3;i++) bench(A,cx-4+i*4,cz+8,true); for(const s of [-1,1]) CG.tree(cx+s*9,cz+7,1,0); return "landmark"; }
  if(r<.9){ CG.church(cx,cz,rnd()<.5?0:2); return "church"; }
  CG.townHall(cx,cz-1,rnd()<.5?0:2); return "landmark"; };

/* ---------- yeşil bölge: spor sahası, göl parkı ---------- */
CG.sportsField=function(cx,cz){ CG.slab(cx,cz,"#3f9a47",.12); const A=CG.F(cx,cz);
  for(let i=0;i<6;i++) fbox(A,cx,.14,cz-10+i*4,20,.02,2,i%2?"#3f9a47":"#47a64f"); fbox(A,cx,.16,cz,.2,.02,20,"#fff"); fbox(A,cx,.16,cz-10,20,.02,.2,"#fff"); fbox(A,cx,.16,cz+10,20,.02,.2,"#fff"); fbox(A,cx-10,.16,cz,.2,.02,20,"#fff"); fbox(A,cx+10,.16,cz,.2,.02,20,"#fff");
  for(const s of [-1,1]){ fbox(A,cx+s*10,.14,cz-1.6,.2,2.4,.2,"#eee"); fbox(A,cx+s*10,.14,cz+1.6,.2,2.4,.2,"#eee"); fbox(A,cx+s*10,2.5,cz,.2,.2,3.4,"#eee"); } for(let i=0;i<3;i++) CG.tree(cx-8+i*8,cz+11.2,1,0); return "park"; };
CG.pondPark=function(cx,cz){ CG.slab(cx,cz,GR(),.12); const A=CG.F(cx,cz), T=CG.T(cx,cz); fbox(T,cx,.14,cz,13,.1,10,"#3d94d6"); fbox(A,cx,.14,cz,16,.03,1.4,"#dccfa5"); fbox(A,cx,.14,cz,1.4,.03,20,"#dccfa5"); fbox(A,cx,.15,cz+.0,3,.3,1.4,"#8a6038");
  for(let i=0;i<14;i++){ const a=rnd()*6.28, r=7+rnd()*3.6; CG.tree(cx+Math.cos(a)*r,cz+Math.sin(a)*r,.9+rnd()*.5,pick([0,0,3,2])); } for(const s of [-1,1]) bench(A,cx+s*8,cz+1,false); return "park"; };
})();
