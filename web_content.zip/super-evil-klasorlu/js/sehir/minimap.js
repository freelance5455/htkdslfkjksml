"use strict";
/* ===== MİNİ HARİTA (sol üst): kuşbakışı şehir, yollar, binalar (yıkılanlar kırmızı), adalar, köprü, önemli yerler, kule; yön = bakış yönü ===== */
Game.Minimap=(function(){
  const cv=document.getElementById("mmc"), mm=document.getElementById("mm"), nEl=mm&&mm.querySelector(".mmn"); if(!cv) return {};
  const q=cv.getContext("2d"), W=Game.W, MAP=Game.MAP, CELL=W.CELL, S=cv.width, HALF=S/2;
  /* --- zemin katmanı: kara/deniz maskesi, 4 m/piksel, kareler halinde (menüde beklerken) çizilir --- */
  const EXT=1100, RES=5, N=Math.round(EXT*2/RES), base=document.createElement("canvas"); base.width=base.height=N; const bq=base.getContext("2d"), img=bq.createImageData(N,N), D=img.data;
  const hex=h=>{ const c=new THREE.Color(h); return [c.r*255|0,c.g*255|0,c.b*255|0]; };
  const SAND=hex(MAP.sand||"#e8d5a2"), GRASS=hex(MAP.grass||"#4f9b46"), GRASS2=hex(MAP.grass2||"#3b7d3a"), PLAZA=hex(MAP.plaza||"#8fbf6a"), ROCK=[130,132,134], DUNE=[212,190,130];
  const SHAL=[46,150,160], DEEP=[10,52,92];
  let rowDone=0, ready=false, tex0=0;
  function px(i,j){ const x=-EXT+(i+.5)*RES, z=-EXT+(j+.5)*RES, h=W.terrainH(x,z), k=(j*N+i)*4; let c;
    if(h<=W.WATER_Y+.02){ const t=Math.min(1,(W.WATER_Y-h)/8); c=[SHAL[0]+(DEEP[0]-SHAL[0])*t,SHAL[1]+(DEEP[1]-SHAL[1])*t,SHAL[2]+(DEEP[2]-SHAL[2])*t]; }
    else { const d=W.distCity(x,z); if(d<=6) c=[78,82,88];
      else { let isl=null; for(const I of W.islands){ if(Math.hypot(x-I.x,z-I.z)<I.R+14){ isl=I; break; } }
        if(!isl) c=SAND; else if(isl.type==="hill") c=h>16?ROCK:h>2?(h>9?GRASS2:GRASS):SAND; else if(isl.type==="dune") c=DUNE; else if(isl.type==="mount") c=h>72?[238,242,246]:h>34?ROCK:h>2.2?GRASS2:SAND; else { const r=Math.hypot(x-isl.x,z-isl.z); c=r<isl.R-8?PLAZA:SAND; } } }
    D[k]=c[0]; D[k+1]=c[1]; D[k+2]=c[2]; D[k+3]=255; }
  function buildStep(rows){ const end=Math.min(N,rowDone+rows); for(let j=rowDone;j<end;j++) for(let i=0;i<N;i++) px(i,j); rowDone=end; if(rowDone>=N){ bq.putImageData(img,0,0); ready=true; } }
  /* --- sabit veriler: şehir hücreleri, önemli yerler --- */
  const cells=[], POI=[], POIS={hospital:["H","#e63946"],police:["P","#3b82f6"],fire:["F","#ff7a29"],school:["S","#f1c40f"],mall:["M","#b388ff"]};
  const BLK={tower:"#8a97a8",shops:"#a89a86",houses:"#b9a487",park:"#4f9b46",bigpark:"#3f8a3a",hospital:"#e9e9ee",police:"#8aa3c8",school:"#d9c36a",fire:"#c9786a",mall:"#9d86c4",plaza:"#c9c4b3",landmark:"#d6b25e",villa:"#c4b08a",cottage:"#b79a74",row:"#b5826a",apt:"#a8977f",modern:"#c2bfb6",garden:"#bba98a",ind:"#8d9096",old:"#b58f6e",church:"#c9b99a",farm:"#9ab25a",forest:"#3f7d3a",lake:"#4a90c8",square:"#d6cdb8"};
  for(const [gx,gz] of W.cells){ const key=gx+","+gz, ty=(Game.cellType&&Game.cellType[key])||"tower"; cells.push({x:gx*CELL,z:gz*CELL,c:BLK[ty]||BLK.tower,ty}); if(POIS[ty]) POI.push({x:gx*CELL,z:gz*CELL,ch:POIS[ty][0],col:POIS[ty][1]}); }
  if(Game.DragonWorld&&Game.DragonWorld.lair) POI.push({x:Game.DragonWorld.lair.x,z:Game.DragonWorld.lair.z,ch:"D",col:"#e8431f"});
  const vv=new THREE.Vector3(); let r=130, yawS=0, frame=0, rubT=0; const api={r:130,ready:()=>ready};
  function star(q,x,y,R,col){ q.fillStyle=col; q.beginPath(); for(let i=0;i<10;i++){ const a=-Math.PI/2+i*Math.PI/5, rr=i%2?R*.45:R; q.lineTo(x+Math.cos(a)*rr,y+Math.sin(a)*rr); } q.closePath(); q.fill(); q.lineWidth=1.4; q.strokeStyle="#3a2600"; q.stroke(); }
  function paint(q,S,HALF,px0,pz0,yawS,r,drv,arrowRot,hx,hz,BIG){
    const sc=HALF/r, big=!!BIG;
    q.setTransform(1,0,0,1,0,0); q.fillStyle="#0c3a5c"; q.fillRect(0,0,S,S);
    q.save(); q.translate(HALF,HALF); q.rotate(yawS); q.scale(sc,sc); q.translate(-px0,-pz0);
    if(ready){ q.imageSmoothingEnabled=true; q.drawImage(base,-EXT,-EXT,EXT*2,EXT*2); }
    /* şehir: yol + blok */
    const rr=r*1.5+30, rr2=rr*rr;
    for(const c of cells){ const dx=c.x-px0, dz=c.z-pz0; if(dx*dx+dz*dz>rr2) continue; q.fillStyle="#3a3d44"; q.fillRect(c.x-17,c.z-17,34,34); q.fillStyle="#c9a227"; q.fillRect(c.x-17.4,c.z-.45,34.8,.9); q.fillRect(c.x-.45,c.z-17.4,.9,34.8);
      q.fillStyle=c.ty==="park"||c.ty==="bigpark"?c.c:"#575b63"; q.fillRect(c.x-11.5,c.z-11.5,23,23); }
    /* binalar */
    const B=Game.buildings; q.lineWidth=.5/sc;
    for(let i=0;i<B.length;i++){ const e=B[i], dx=e.x-px0, dz=e.z-pz0; if(dx*dx+dz*dz>rr2) continue; if(e._h0===undefined) e._h0=Math.max(e.h,1); const ratio=e.h/e._h0;
      if(ratio<.3||e.h<=0.5){ q.fillStyle="#7a2a12"; q.fillRect(e.x-e.hw,e.z-e.hd,e.hw*2,e.hd*2); if(r<260){ q.fillStyle="rgba(255,120,40,.55)"; q.fillRect(e.x-e.hw*.6,e.z-e.hd*.6,e.hw*1.2,e.hd*1.2); } continue; }
      const hh=Math.min(1,e._h0/90); const L=150+hh*80|0; q.fillStyle="rgb("+(L*.80|0)+","+(L*.86|0)+","+L+")"; if(ratio<.97) q.fillStyle="#b87a58"; q.fillRect(e.x-e.hw,e.z-e.hd,e.hw*2,e.hd*2); }
    /* köprü */
    const br=W.bridge&&W.bridge.info; if(br){ q.fillStyle="#6a6f78"; q.fillRect(br.X0,br.ZC-5,br.X1-br.X0,10); q.fillStyle="#d9b24a"; q.fillRect(br.X0,br.ZC-.4,br.X1-br.X0,.8); }
    q.restore();
    /* önemli yerler (ekran uzayında, her zaman dik) */
    const ca=Math.cos(yawS), sa=Math.sin(yawS), proj=(x,z)=>{ const dx=(x-px0)*sc, dz=(z-pz0)*sc; return [HALF+dx*ca-dz*sa, HALF+dx*sa+dz*ca]; };
    if(r<460){ q.font="bold 15px sans-serif"; q.textAlign="center"; q.textBaseline="middle";
      for(const p of POI){ const [x,y]=proj(p.x,p.z); if(big?(x<-10||y<-10||x>S+10||y>S+10):Math.hypot(x-HALF,y-HALF)>HALF-10) continue; q.fillStyle=p.col; q.beginPath(); q.arc(x,y,10,0,6.3); q.fill(); q.lineWidth=2; q.strokeStyle="#fff"; q.stroke(); q.fillStyle="#fff"; q.fillText(p.ch,x,y+.5); } }
    /* polis birimleri (arananlıkken): mavi/kırmızı yanıp sönen noktalar */
    if(Game.Police&&Game.Police.markers&&r<560){ const fl=((performance.now()/230)|0)&1; for(const m of Game.Police.markers()){ const [x,y]=proj(m.x,m.z); if(big?(x<-6||y<-6||x>S+6||y>S+6):Math.hypot(x-HALF,y-HALF)>HALF-6) continue; q.fillStyle=m.c; q.beginPath(); q.arc(x,y,m.k==="cop"?3.4:m.k==="tank"?6:5,0,6.3); q.fill(); q.lineWidth=1.6; q.strokeStyle=fl?"#ff3b3b":"#ffffff"; q.stroke(); } }
    /* kule: kenarda ise okla gösterilir */
    const T=Game.TOWER; if(T){ let [x,y]=proj(T.x,T.z); const d=Math.hypot(x-HALF,y-HALF), lim=HALF-16;
      if(!big&&d>lim){ const k=lim/d; x=HALF+(x-HALF)*k; y=HALF+(y-HALF)*k; star(q,x,y,11,"#ffd23a"); } else star(q,x,y,15,"#ffd23a"); }
    /* oyuncu: ok + görüş konisi */
    const [ax,ay]=big?proj(hx,hz):[HALF,HALF];
    q.save(); q.translate(ax,ay);
    const g=q.createRadialGradient(0,0,0,0,0,90); g.addColorStop(0,"rgba(255,255,255,.28)"); g.addColorStop(1,"rgba(255,255,255,0)"); q.fillStyle=g; q.beginPath(); q.moveTo(0,0); q.arc(0,0,90,-Math.PI/2-.62,-Math.PI/2+.62); q.closePath(); q.fill();
    q.rotate(arrowRot); q.fillStyle=drv?"#ffb347":"#ffffff"; q.strokeStyle="#c11a10"; q.lineWidth=3; q.beginPath(); q.moveTo(0,-15); q.lineTo(11,12); q.lineTo(0,6); q.lineTo(-11,12); q.closePath(); q.fill(); q.stroke(); q.restore();
  }
  function draw(time){
    const hero=Game.heroObj, MV=Game.Mounted&&Game.Mounted(), drv=!!MV, px0=drv?MV.x:hero.position.x, pz0=drv?MV.z:hero.position.z;
    camera.getWorldDirection(vv); const yaw=Math.atan2(-vv.x,-vv.z); let dy=yaw-yawS; dy=Math.atan2(Math.sin(dy),Math.cos(dy)); yawS+=dy*.35;
    const alt=Math.max(0,hero.position.y), spd=Game.H.speed||0, want=drv?105+Math.min(260,(MV.speed||0)*2.4):120+Math.min(520,alt*.32)+Math.min(120,spd*.9); r+=(want-r)*.06; api.r=r;
    paint(q,S,HALF,px0,pz0,yawS,r,drv,0,px0,pz0,false);
    if(nEl){ const a=yawS, R=HALF-7; nEl.style.left=(50+Math.sin(a)*(R/HALF)*50)+"%"; nEl.style.top=(50-Math.cos(a)*(R/HALF)*50)+"%"; nEl.style.transform="translate(-50%,-50%)"; }
  }
  /* tam ekran harita: kuzey yukarı, sürükle = kaydır, +/- = yakınlaştır */
  api.paintBig=function(ctx,Sb,cx,cz,r){ const hero=Game.heroObj, MV=Game.Mounted&&Game.Mounted(), drv=!!MV, hx=drv?MV.x:hero.position.x, hz=drv?MV.z:hero.position.z;
    camera.getWorldDirection(vv); const yaw=Math.atan2(-vv.x,-vv.z); paint(ctx,Sb,Sb/2,cx,cz,0,r,drv,-yaw,hx,hz,true); return [hx,hz]; };
  api.playerPos=function(){ const hero=Game.heroObj, MV=Game.Mounted&&Game.Mounted(); return [MV?MV.x:hero.position.x, MV?MV.z:hero.position.z]; };
  Game.updaters.push((dt,time)=>{ frame++;
    if(!ready&&(Game.mode==="menu"||frame>2)) buildStep(Game.mode==="menu"?10:24);
    if(Game.mode!=="play"&&Game.mode!=="pause") return; if(!Game.settings.minimap) return; if(Game.mode==="play"&&(frame&1)) return; draw(time); });
  Game.updaters[Game.updaters.length-1].__menu=true;
  return api;
})();
