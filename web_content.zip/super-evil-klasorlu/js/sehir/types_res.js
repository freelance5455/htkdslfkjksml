"use strict";
/* ===== YAPI TİPLERİ (konut): kulübe, banliyö evi, villa, sıra ev, apartman, modern ev ===== */
(function(){
const CG=Game.CG, rnd=CG.rnd, pick=CG.pick, pbox=CG.pbox, fbox=CG.fbox, PAL=CG.PAL, RC=CG.RC;
const WALLS=["#f5e3cf","#e9d7c1","#dfe8d6","#f2d9d0","#e3e3ee","#f3ecd8","#d9e6ef","#efd9c4"];
const frontSide=(ox,oz)=>Math.abs(oz)>=Math.abs(ox)?(oz>0?0:2):(ox>0?1:3);
const IC=["#efe6d8","#e8dcc8","#dfe6dc","#e9d9d4","#e4e8ee"];
function path(A,x,z,side,len,w){ const o=[[0,1],[1,0],[0,-1],[-1,0]][side]; fbox(A,x+o[0]*len/2,.12,z+o[1]*len/2,o[0]?len:w,.03,o[1]?len:w,"#cfcfcf"); }
function shrubs(x,z,w,d){ const A=CG.F(x,z); for(const sx of [-1,1]){ fbox(A,x+sx*(w/2+.5),.12,z+d/2+.6,.9,.7,.9,pick(["#2f7d32","#3f8f3a"])); } }
/* tek ev: tip cottage|sub|villa|modern */
CG.house=function(x,z,type,front,tint){ const bl=CG.bl(), wc=tint||pick(WALLS), rc=pick(RC); let w,d,h,roof="gable",rh;
  if(type==="cottage"){ w=6.4; d=7.2; h=4; rh=2.6; } else if(type==="sub"){ w=8; d=8; h=8; rh=3; } else if(type==="villa"){ w=14; d=11; h=8; roof="hip"; rh=3.6; } else { w=11; d=9; h=4; roof="flat"; }
  if(front===1||front===3){ const q=w; w=d; d=q; }   // yönlendirme
  const along=w>=d;
  const t=CG.tier(bl,{x,z,w,d,y0:0,h,LH:h>4?8:4,style:"w",tint:wc,kind:"res",door:front,ic:pick(IC),fc:pick(["#a98a62","#9b8668","#b59d7a"]),roof,roofCol:rc,rh,
    doorDeco:(A,p,tt,dg)=>CG.canopy(A,p,dg,"#6b5646",3.4),
    props:roof==="flat"?undefined:(top,A,tt)=>{ pbox(A,x+(along?w*.22:0),top-1.5,z+(along?0:d*.22),.9,2.6,.9,"#8a5a4a"); return top+1.2; }});
  if(type==="modern"){ const t2=CG.tier(bl,{x:x+(front===1||front===3?0:1.2),z:z+(front===1||front===3?1.2:0),w:w*.8,d:d*.8,y0:4,h:4,LH:4,style:"g",tint:"#cfd9e4",kind:"res",ic:"#f3f1ec",fc:"#8d9097",roof:"flat",slabCol:"#d9d9dc"}); }
  else if(type==="sub"&&rnd()<.3){ }
  return t; };
CG.houses=function(cx,cz){ CG.slab(cx,cz,Game.MAP.grass||"#5aa845"); const r=rnd(), A=CG.F(cx,cz);
  if(r<.32){ for(const [ox,oz] of [[-6,-6],[6,-6],[-6,6],[6,6]]){ const x=cx+ox,z=cz+oz, f=frontSide(ox,oz), type=rnd()<.45?"cottage":"sub"; CG.house(x,z,type,f); path(A,x,z,f,type==="cottage"?5:5.5,1.6); shrubs(x,z,6,type==="cottage"?7:8);
      CG.tree(cx+ox*.15,cz+oz*1.75,.9+rnd()*.4,rnd()<.3?1:0); } }
  else if(r<.52){ // villa + havuz + bahçe
    CG.house(cx-2.5,cz-5,"villa",0,pick(["#f6efe2","#efe3d0","#e4eaf0"])); fbox(A,cx-2.5,.12,cz+3,3,.03,6,"#cfcfcf");
    const T=CG.T(cx,cz); fbox(A,cx+6,.12,cz+6.5,10,.08,6.4,"#e4dccb"); fbox(T,cx+6,.18,cz+6.5,8.6,.1,5,"#3fb5e8"); fbox(A,cx-7,.12,cz+7,.5,1.4,.5,"#6b5646");
    for(let i=0;i<5;i++) CG.tree(cx-10+rnd()*20,cz+9+rnd()*2.4,.9+rnd()*.5,0);
    fbox(A,cx,.12,cz+11.7,23,.9,.3,"#d9d2c4"); }
  else if(r<.72){ // sıra evler
    for(const row of [-1,1]){ const z=cz+row*7.5, f=row>0?0:2; const tint=[pick(WALLS),pick(WALLS),pick(WALLS)];
      for(let i=0;i<3;i++){ const x=cx+(i-1)*7.6, bl=CG.bl(); CG.tier(bl,{x,z,w:7.4,d:9,y0:0,h:12,LH:8,style:"w",tint:tint[i],kind:"res",door:f,ic:pick(IC),fc:"#a98a62",roof:"flat",doorDeco:(A2,p,t,dg)=>CG.canopy(A2,p,dg,"#6b5646",3.4),
          props:(top,A2,t)=>{ pbox(A2,x,top+.5,z,1.6,1.2,1.6,"#8d939b"); return top+1.8; }}); path(A,x,z,f,3.4,1.8); } } }
  else if(r<.88){ // apartman bloğu + otopark
    const bl=CG.bl(), f=pick([0,2]), z=cz-(f===0?4:-4);
    const t=CG.tier(bl,{x:cx,z,w:20,d:13,y0:0,h:20,LH:8,style:"w",tint:pick(["#e6dccd","#dfe6ee","#efe2d2","#e4e6d8"]),kind:"res",door:f,ic:pick(IC),fc:"#a98a62",roof:"flat",doorDeco:(A2,p,tt,dg)=>CG.canopy(A2,p,dg,"#55606c",3.6),
      props:(top,A2,tt)=>CG.roofProps(top,A2,tt)});
    CG.doorSign(t,"APT",3.6,1,"#2a4a7a","#fff",4.6);
    const pz=cz+(f===0?8.2:-8.2); fbox(A,cx,.12,pz,22,.03,5.4,"#4a4d52"); for(let i=0;i<8;i++){ fbox(A,cx-10+i*2.9,.16,pz,.12,.03,4.4,"#f2f2f2"); if(rnd()<.6) CG.addCar(cx-8.55+i*2.9,pz,false,pick(CG.CC)); } }
  else { // modern villalar
    CG.house(cx-6,cz-5,"modern",0,pick(["#f1f1f1","#e8e6e0","#dcdfe3"])); CG.house(cx+6,cz+5,"modern",2,pick(["#f1f1f1","#e8e6e0","#d6dce2"]));
    const T=CG.T(cx,cz); fbox(T,cx+6,.14,cz-6,6,.1,3.4,"#3fb5e8"); fbox(A,cx+6,.12,cz-6,7.2,.05,4.6,"#e4dccb"); for(let i=0;i<4;i++) CG.tree(cx-10+rnd()*20,cz-10+rnd()*20,1,0); } };
})();
