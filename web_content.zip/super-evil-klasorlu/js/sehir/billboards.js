"use strict";
/* ===== AFİŞ VE REKLAM PANOLARI (sade): çatı panoları, duvar afişleri, sokak reklam panoları. Kendi rastgele sayı üretecini kullanır (şehir yerleşimi değişmez). ===== */
(function(){
const CG=Game.CG, F=(x,z)=>CG.F(x,z);
const ra=(()=>{ let s=777001; return ()=>{ s=(s*16807)%2147483647; return s/2147483647; }; })(), pk=a=>a[Math.floor(ra()*a.length)%a.length];
const ADS=[["SUPER EVIL","#6e0a0a","#ffd0c0"],["BURGER","#e8b030","#7a1c10"],["COLA","#d2202a","#ffffff"],["CINEMA","#16163a","#ffd54a"],["BANK","#103a6a","#e8f0ff"],["AIR TRAVEL","#1b6fb0","#ffffff"],["TECH","#1c1c20","#4cf0c8"],
  ["MOTORS","#111","#ff4d4d"],["PIZZA","#c0392b","#fff2c0"],["NEWS 24","#f2f2f2","#b00020"],["FASHION","#f4d6e4","#6a1b4d"],["FITNESS","#0f3d2a","#b8ff5a"],["MUSIC","#4a1a7a","#ffd0ff"],["TRAVEL","#0a7a6a","#ffffff"]];
const POSTERS=[["WANTED","#d9c08a","#5a2a10"],["CONCERT","#2a1050","#ff7ad9"],["CIRCUS","#b0201e","#ffe27a"],["SALE","#ffd23f","#c01818"],["THEATER","#1a2f4a","#f0d58a"],["FESTIVAL","#0e7a6e","#ffeaa0"],["SUPER EVIL","#120404","#ff3a1c"],["OPEN","#2a2f36","#8cf0a0"]];
const texCache={}, geoCache={}, MATS={};
function tex(a,wide){ const key=a[0]+wide; if(MATS[key]) return MATS[key]; const W=wide?768:256, H=wide?256:384, c=CG.cnv(W,H), q=c.getContext("2d");
  q.fillStyle=a[1]; q.fillRect(0,0,W,H);
  q.globalAlpha=.22; q.fillStyle=a[2]; for(let i=0;i<5;i++){ q.beginPath(); q.arc(W*(.1+.8*((i*.37+.11)%1)),H*(.15+.7*((i*.61+.2)%1)),H*(.12+.1*((i*.29)%1)),0,6.3); q.fill(); }
  q.globalAlpha=.16; for(let i=-4;i<12;i++){ q.fillRect(i*W/8,0,W/20,H); } q.globalAlpha=1;
  q.strokeStyle=a[2]; q.lineWidth=wide?7:6; q.strokeRect(6,6,W-12,H-12);
  let fs=wide?H*.5:H*.2; q.font="bold "+fs+"px sans-serif"; while(q.measureText(a[0]).width>W*.82&&fs>14){ fs-=3; q.font="bold "+fs+"px sans-serif"; }
  q.fillStyle=a[2]; q.textAlign="center"; q.textBaseline="middle"; q.fillText(a[0],W/2,wide?H*.46:H*.34);
  q.fillRect(W*.2,wide?H*.76:H*.5,W*.6,wide?6:5); if(!wide){ q.beginPath(); q.arc(W/2,H*.74,H*.14,0,6.3); q.fill(); q.fillStyle=a[1]; q.beginPath(); q.arc(W/2+H*.05,H*.72,H*.12,0,6.3); q.fill(); }
  const t=new THREE.CanvasTexture(CG.shrink?CG.shrink(c):c); t.encoding=THREE.sRGBEncoding; return MATS[key]=new THREE.MeshBasicMaterial({map:t}); }
function plane(a,wide,w,h,x,y,z,ry){ const gk=w+"x"+h, g=geoCache[gk]||(geoCache[gk]=new THREE.PlaneGeometry(w,h)), m=new THREE.Mesh(g,tex(a,wide)); m.position.set(x,y,z); m.rotation.y=ry||0; scene.add(m); (Game.smallMeshes||(Game.smallMeshes=[])).push(m); return m; }
const poleMat=new THREE.MeshBasicMaterial({color:0x2a2d33}), poleGeo=new THREE.BoxGeometry(1,1,1);
function pole(x,y,z,w,h,d){ const m=new THREE.Mesh(poleGeo,poleMat); m.position.set(x,y,z); m.scale.set(w,h,d); scene.add(m); (Game.smallMeshes||(Game.smallMeshes=[])).push(m); return m; }
/* çatıda çift yüzlü pano (+z yönü) — binanın çatı parçasına bağlı, bina yıkılınca düşer */
function roofBoard(prop,x,z,d,top,w){ const a=pk(ADS), h=w*.32, y=top+1.2+h/2, zz=z+d/2-1.1;
  CG.attach(prop,plane(a,true,w,h,x,y,zz+.08,0)); CG.attach(prop,plane(a,true,w,h,x,y,zz-.08,Math.PI));
  CG.attach(prop,pole(x-w*.38,top+.6,zz,.25,1.3,.25)); CG.attach(prop,pole(x+w*.38,top+.6,zz,.25,1.3,.25)); }
/* duvar afişi: bir yan duvar panelinin üzerine */
function wallPoster(t,side,y){ const ids=[]; y=Math.min(y,t.y0+t.h-4.2); if(y<5) return; if(!t.walls||!t.walls[0]) return; t.walls[0].forEach((id,i)=>{ if(t.pan&&t.pan[i]&&t.pan[i].s===side) ids.push(i); }); if(!ids.length) return;
  const i=ids[Math.floor(ra()*ids.length)%ids.length], p=t.pan[i], c=Game.D.chunks[t.walls[0][i]], off=.07, a=pk(POSTERS), w=4.2, h=6.3;
  const m=side===0?plane(a,false,w,h,p.cx,y,p.cz+p.sz/2+off,0):side===2?plane(a,false,w,h,p.cx,y,p.cz-p.sz/2-off,Math.PI):side===1?plane(a,false,w,h,p.cx+p.sx/2+off,y,p.cz,Math.PI/2):plane(a,false,w,h,p.cx-p.sx/2-off,y,p.cz,-Math.PI/2);
  CG.attach(c,m); }
CG.ads=function(t,o){ if(!t||o.fl<4) return; const r=ra();
  if(!o.hotel&&o.prop&&r<.28) roofBoard(o.prop,o.x,o.z,o.d,o.top,Math.min(o.w*.8,11));
  if(ra()<.4) wallPoster(t,Math.floor(ra()*4),6+ra()*8);
  if(ra()<.18) wallPoster(t,Math.floor(ra()*4),10+ra()*14); };
/* sokak reklam panosu (otobüs durağı tarzı): kaldırımda, yola bakan çift yüzlü */
CG.streetAd=function(cx,cz){ if(ra()>.17) return; const side=ra()<.5?-1:1, ax=ra()<.5?0:1, t=(ra()-.5)*10, a=pk(ADS), A=F(cx,cz), dd=11.9*side, y=1.55;
  if(ax===0){ const x=cx+t, z=cz+dd, ms=[pole(x-1.45,1.3,z,.14,2.6,.14),pole(x+1.45,1.3,z,.14,2.6,.14),plane(a,true,3.1,1.5,x,y+.25,z+.09,0),plane(a,true,3.1,1.5,x,y+.25,z-.09,Math.PI)]; CG.lists.propMeshes.push({kind:"ad",meshes:ms,x,y:1.45,z,hx:1.65,hy:1.4,hz:.25,hp:.9}); }
  else { const x=cx+dd, z=cz+t, ms=[pole(x,1.3,z-1.45,.14,2.6,.14),pole(x,1.3,z+1.45,.14,2.6,.14),plane(a,true,3.1,1.5,x+.09,y+.25,z,Math.PI/2),plane(a,true,3.1,1.5,x-.09,y+.25,z,-Math.PI/2)]; CG.lists.propMeshes.push({kind:"ad",meshes:ms,x,y:1.45,z,hx:.25,hy:1.4,hz:1.65,hp:.9}); } };
})();
