"use strict";
/* ===== AĞAÇ GEOMETRİSİ: meşe / çam / kavak / huş (gerçekçi taç + gövde), kırılma parçaları, kışlık çıplak dallar =====
   Her varyant: bark (gövde+dallar, tek parça), leaf (yaprak kütleleri; köşe rengi + yaprak dokusu), upper (kırılma noktasından yukarısı),
   bare (kış dalları). Gövde kırılma yüksekliği HS: aşağısı kütük (stump), yukarısı devrilen parça. */
Game.TreeGeo=(function(){
const TG={ HS:1.3, V:[], byType:{0:[],1:[],2:[],3:[]}, stats:{verts:0} };
const mkR=seed=>{ let s=(Math.abs(Math.floor(seed*1000))%2147483646)+1; return ()=>{ s=s*16807%2147483647; return (s-1)/2147483646; }; };
const tex=(w,h,fn)=>{ const c=document.createElement("canvas"); c.width=w; c.height=h; const g=c.getContext("2d"); fn(g,w,h); const t=new THREE.CanvasTexture(c); t.wrapS=t.wrapT=THREE.RepeatWrapping; t.anisotropy=4; return t; };
function makeTex(){
  TG.tex={
    leaf:tex(128,128,(g,w,h)=>{ const R=mkR(11); g.fillStyle="rgb(205,205,205)"; g.fillRect(0,0,w,h);
      for(let i=0;i<560;i++){ const x=R()*w,y=R()*h,rx=2+R()*4.5,ry=1.5+R()*3,a=R()*3.14,v=Math.floor(150+R()*105); g.fillStyle="rgb("+v+","+v+","+v+")";
        for(const ox of [-w,0,w]) for(const oy of [-h,0,h]){ if(x+ox<-10||x+ox>w+10||y+oy<-10||y+oy>h+10) continue; g.beginPath(); g.ellipse(x+ox,y+oy,rx,ry,a,0,6.283); g.fill(); } }
      for(let i=0;i<80;i++){ const x=R()*w,y=R()*h,r=1.5+R()*3,v=Math.floor(85+R()*40); g.fillStyle="rgb("+v+","+v+","+v+")";
        for(const ox of [-w,0,w]) for(const oy of [-h,0,h]){ if(x+ox<-6||x+ox>w+6||y+oy<-6||y+oy>h+6) continue; g.beginPath(); g.arc(x+ox,y+oy,r,0,6.283); g.fill(); } } }),
    bark:tex(64,128,(g,w,h)=>{ const R=mkR(3); g.fillStyle="rgb(168,158,148)"; g.fillRect(0,0,w,h);
      for(let i=0;i<170;i++){ const x=R()*w,ww=1+R()*3,v=Math.floor(80+R()*140),y=R()*h,l=10+R()*50; g.fillStyle="rgb("+v+","+Math.floor(v*.93)+","+Math.floor(v*.86)+")"; g.fillRect(x,y,ww,l); if(x+ww>w) g.fillRect(x-w,y,ww,l); } }),
    birch:tex(64,128,(g,w,h)=>{ const R=mkR(5); g.fillStyle="rgb(236,234,226)"; g.fillRect(0,0,w,h);
      for(let i=0;i<34;i++){ const x=R()*w,y=R()*h,ww=6+R()*16,hh=1.5+R()*3; g.fillStyle="rgba(34,30,28,.88)"; g.fillRect(x,y,ww,hh); if(x+ww>w) g.fillRect(x-w,y,ww,hh); }
      for(let i=0;i<20;i++){ g.fillStyle="rgba(170,160,140,.5)"; g.fillRect(R()*w,R()*h,10+R()*20,1); } })
  }; }
/* ---------- geometri kurucu ---------- */
const Bld=()=>({P:[],N:[],C:[],U:[],I:[]});
function done(b){ const P=b.P,N=b.N,I=b.I;
  for(let t=0;t<I.length;t+=3){ const a=I[t]*3,c=I[t+1]*3,d=I[t+2]*3;
    const ux=P[c]-P[a],uy=P[c+1]-P[a+1],uz=P[c+2]-P[a+2], vx=P[d]-P[a],vy=P[d+1]-P[a+1],vz=P[d+2]-P[a+2];
    const nx=uy*vz-uz*vy, ny=uz*vx-ux*vz, nz=ux*vy-uy*vx, sx=N[a]+N[c]+N[d], sy=N[a+1]+N[c+1]+N[d+1], sz=N[a+2]+N[c+2]+N[d+2];
    if(nx*sx+ny*sy+nz*sz<0){ const q=I[t+1]; I[t+1]=I[t+2]; I[t+2]=q; } }
  const g=new THREE.BufferGeometry(); g.setAttribute("position",new THREE.Float32BufferAttribute(P,3)); g.setAttribute("normal",new THREE.Float32BufferAttribute(N,3));
  g.setAttribute("color",new THREE.Float32BufferAttribute(b.C,3)); g.setAttribute("uv",new THREE.Float32BufferAttribute(b.U,2)); g.setIndex(I); g.userData={verts:P.length/3,tris:I.length/3}; TG.stats.verts+=P.length/3; return g; }
const vtx=(b,x,y,z,nx,ny,nz,c0,c1,c2,u,v)=>{ b.P.push(x,y,z); b.N.push(nx,ny,nz); b.C.push(c0,c1,c2); b.U.push(u,v); return b.P.length/3-1; };
/* icosahedron: 0 bölme (12 köşe, 20 yüz) ve 1 bölme (42 köşe, 80 yüz) */
const mkIco=sub=>{ const t=(1+Math.sqrt(5))/2, V=[[-1,t,0],[1,t,0],[-1,-t,0],[1,-t,0],[0,-1,t],[0,1,t],[0,-1,-t],[0,1,-t],[t,0,-1],[t,0,1],[-t,0,-1],[-t,0,1]].map(v=>{ const l=Math.hypot(v[0],v[1],v[2]); return [v[0]/l,v[1]/l,v[2]/l]; });
  let F=[[0,11,5],[0,5,1],[0,1,7],[0,7,10],[0,10,11],[1,5,9],[5,11,4],[11,10,2],[10,7,6],[7,1,8],[3,9,4],[3,4,2],[3,2,6],[3,6,8],[3,8,9],[4,9,5],[2,4,11],[6,2,10],[8,6,7],[9,8,1]];
  if(sub){ const mid=new Map(), gm=(a,b)=>{ const k=a<b?a+"_"+b:b+"_"+a; let i=mid.get(k); if(i===undefined){ const p=V[a],q=V[b],m=[p[0]+q[0],p[1]+q[1],p[2]+q[2]],l=Math.hypot(m[0],m[1],m[2]); V.push([m[0]/l,m[1]/l,m[2]/l]); i=V.length-1; mid.set(k,i); } return i; };
    const F2=[]; for(const f of F){ const a=gm(f[0],f[1]), b=gm(f[1],f[2]), c=gm(f[2],f[0]); F2.push([f[0],a,c],[f[1],b,a],[f[2],c,b],[a,b,c]); } F=F2; }
  return {V,F}; };
const ICO=mkIco(1), ICO0=mkIco(0);
/* yaprak kütlesi: bozulmuş (topaklı) elipsoid; normaller kısmen taç merkezine bakar (yumuşak hacim), köşe rengi yüksekliğe göre */
function blob(b,cx,cy,cz,rx,ry,rz,o){ const base=b.P.length/3, R=o.R, IC=o.ico||ICO, V=IC.V;
  for(let i=0;i<V.length;i++){ const d=V[i], f=1+o.disp*(R()*2-1), x=cx+d[0]*rx*f, y=cy+d[1]*ry*f, z=cz+d[2]*rz*f;
    let ex=x-o.tc[0], ey=y-o.tc[1], ez=z-o.tc[2]; const el=Math.hypot(ex,ey,ez)||1; ex/=el; ey/=el; ez/=el;
    let nx=d[0]*(1-o.nb)+ex*o.nb, ny=d[1]*(1-o.nb)+ey*o.nb, nz=d[2]*(1-o.nb)+ez*o.nb; const nl=Math.hypot(nx,ny,nz)||1; nx/=nl; ny/=nl; nz/=nl;
    const hf=Math.max(0,Math.min(1,(y-o.y0)/(o.y1-o.y0))), sh=(.66+.6*hf+(R()-.5)*.2)*(.86+.14*(d[1]*.5+.5));
    vtx(b,x,y,z,nx,ny,nz,sh*(.95+.1*hf),sh,sh*.9,(x+z*.6)*.5+o.uo,(y+z*.3)*.5); }
  for(const f of IC.F) b.I.push(base+f[0],base+f[1],base+f[2]); }
/* dal/gövde: iki halka arası konik tüp (keyfi yön) */
function frame(dx,dy,dz){ const l=Math.hypot(dx,dy,dz)||1; dx/=l; dy/=l; dz/=l; const a=Math.abs(dy)<.9?[0,1,0]:[1,0,0];
  let ux=a[1]*dz-a[2]*dy, uy=a[2]*dx-a[0]*dz, uz=a[0]*dy-a[1]*dx; const ul=Math.hypot(ux,uy,uz)||1; ux/=ul; uy/=ul; uz/=ul;
  return [ux,uy,uz, uy*dz-uz*dy, uz*dx-ux*dz, ux*dy-uy*dx]; }
function limb(b,p0,p1,r0,r1,S,col){ const f=frame(p1[0]-p0[0],p1[1]-p0[1],p1[2]-p0[2]), base=b.P.length/3, len=Math.hypot(p1[0]-p0[0],p1[1]-p0[1],p1[2]-p0[2]);
  for(let k=0;k<2;k++){ const p=k?p1:p0, r=k?r1:r0, c=col(k); for(let i=0;i<=S;i++){ const a=i/S*6.2832, ca=Math.cos(a), sa=Math.sin(a), nx=f[0]*ca+f[3]*sa, ny=f[1]*ca+f[4]*sa, nz=f[2]*ca+f[5]*sa;
    vtx(b,p[0]+nx*r,p[1]+ny*r,p[2]+nz*r,nx,ny,nz,c[0],c[1],c[2],i/S,(k?len:0)*.3+p0[1]*.2); } }
  for(let i=0;i<S;i++){ const a=base+i, c=a+S+1; b.I.push(a,c,a+1,c,c+1,a+1); } }
/* gövde: halkalar (düşey) */
function tube(b,rings,S,col,uRep){ const base=b.P.length/3;
  for(let k=0;k<rings.length;k++){ const rg=rings[k], c=col(rg,k);
    for(let i=0;i<=S;i++){ const a=i/S*6.2832, ca=Math.cos(a), sa=Math.sin(a), yj=rg.yj?rg.yj[i%S]:0; vtx(b,rg.x+ca*rg.r,rg.y+yj,rg.z+sa*rg.r,ca,.12,sa,c[0],c[1],c[2],i/S*(uRep||1),rg.y*.3); } }
  for(let k=0;k<rings.length-1;k++) for(let i=0;i<S;i++){ const a=base+k*(S+1)+i, c=a+S+1; b.I.push(a,c,a+1,c,c+1,a+1); } }
const WOOD=[2.4,2.1,1.5];
function cap(b,rg,S,up,yc){ const base=b.P.length/3, ny=up?1:-1; vtx(b,rg.x,yc,rg.z,0,ny,0,WOOD[0],WOOD[1],WOOD[2],.5,.5);
  for(let i=0;i<=S;i++){ const a=i/S*6.2832, ca=Math.cos(a), sa=Math.sin(a), yj=rg.yj?rg.yj[i%S]:0; vtx(b,rg.x+ca*rg.r,rg.y+yj,rg.z+sa*rg.r,0,ny,0,WOOD[0]*.92,WOOD[1]*.92,WOOD[2]*.92,.5+ca*.5,.5+sa*.5); }
  for(let i=0;i<S;i++) b.I.push(base,base+1+i,base+2+i); }
function trunkRings(R,o){ const ph=R()*6;
  return o.ys.map(y=>{ const t=Math.min(1,y/o.H), over=y>o.H?(y-o.H)/(o.top||1):0, r=(o.r0+(o.r1-o.r0)*t)*(1+o.flare*Math.exp(-y*3.2))*(1-.45*Math.min(1,over)), k=Math.pow(t,1.4);
    return {x:o.lean[0]*k+Math.sin(y*1.7+ph)*.035, y, z:o.lean[1]*k+Math.cos(y*1.3+ph)*.035, r}; }); }
const barkCol=R=>(rg,k)=>{ const v=.66+.45*Math.min(1,rg.y/3)+R()*.1; return [v,v*.95,v*.9]; };
function loCrown(seed,blobs,tc,y0,y1){ const b=Bld(), R=mkR(seed+5), pk=[blobs[0],blobs[1],blobs[blobs.length-1]]; pk.forEach((q,i)=>blob(b,q[0],q[1],q[2],q[3]*1.12,q[4]*1.1,q[5]*1.12,{R,disp:.1,tc,nb:.5,y0,y1,uo:i*.37,ico:ICO0})); return done(b); }
function loBark(rings,ri,S,R){ const b=Bld(); tube(b,[rings[0],rings[ri],rings[rings.length-2],rings[rings.length-1]],S||4,barkCol(R),1); return done(b); }
function crownBlobs(b,R,list,tc,y0,y1,nb,disp){ list.forEach((q,i)=>blob(b,q[0],q[1],q[2],q[3],q[4],q[5],{R,disp,tc,nb,y0,y1,uo:i*.37})); }
const lim=(R)=>k=>{ const v=.55+R()*.15; return [v,v*.94,v*.88]; };
/* ---------- türler ---------- */
function oak(seed,v){ const R=mkR(seed), H=2.4+R()*.6, lean=[(R()-.5)*.28,(R()-.5)*.28], yc=H+2.0, HS=TG.HS;
  const ys=[0,.35,.8,HS,2.0,H,H+.8], rings=trunkRings(R,{ys,H,r0:.44+R()*.08,r1:.27,flare:.55,lean,top:.8}), S=6;
  const top=rings[rings.length-1], sat=[]; const ns=v===2?3:4, a0=R()*6.28;
  for(let i=0;i<ns;i++){ const a=a0+i/ns*6.283+(R()-.5)*.6, rho=1.05+R()*.45; sat.push([top.x+Math.cos(a)*rho,yc+(R()-.4)*1.2,top.z+Math.sin(a)*rho,1.3+R()*.2,1.15+R()*.2,1.3+R()*.2]); }
  const blobs=[[top.x,yc,top.z,2.15,1.8,2.15]].concat(sat,[[top.x+(R()-.5)*.5,yc+1.55,top.z+(R()-.5)*.5,1.35,1.1,1.35]]);
  const leaf=Bld(); crownBlobs(leaf,R,blobs,[top.x,yc,top.z],yc-2.2,yc+2.6,.55,.2);
  const bk=Bld(), up=Bld(), c=barkCol(R); tube(bk,rings,S,c,1.3); const ri=ys.indexOf(HS); tube(up,rings.slice(ri),S,c,1.3); cap(up,rings[ri],S,false,HS-.02);
  for(let i=0;i<Math.min(ns,3);i++){ const q=sat[i], p1=[(top.x+q[0])/2+(q[0]-top.x)*.2,yc-.5,(top.z+q[2])/2+(q[2]-top.z)*.2], p0=[top.x,H+.1,top.z], l=lim(R); limb(bk,p0,p1,.17,.07,4,l); limb(up,p0,p1,.17,.07,4,l); }
  return {bark:done(bk),leaf:done(leaf),upper:done(up),lo:{bark:loBark(rings,ri,4,R),leaf:loCrown(seed,blobs,[top.x,yc,top.z],yc-2.2,yc+2.6)},hs:HS,rc:3.0,H:yc+1.7+1.1,yc,kind:"oak",bare:bare(seed+9,{H:H,n:5,tilt:[.55,1.05],len:[2.4,3.2],spread:.9,top:2.8,lean,x:top.x,z:top.z,r:.2})}; }
function pine(seed,v){ const R=mkR(seed), HS=TG.HS, S=5, ys=[0,.5,HS,2.5,4.8,7.4], lean=[(R()-.5)*.1,(R()-.5)*.1];
  const rings=trunkRings(R,{ys,H:7.4,r0:.32,r1:.06,flare:.5,lean,top:1}), leaf=Bld(), nT=v===1?5:6, yb=1.5+R()*.3;
  for(let k=0;k<nT;k++){ const y0=yb+k*(5.4/nT), hT=2.3-k*.1, rB=(2.0-k*(1.65/nT))*(.92+R()*.16), n=10, base=leaf.P.length/3, ox=lean[0]*Math.pow((y0+hT*.4)/7.4,1.4), oz=lean[1]*Math.pow((y0+hT*.4)/7.4,1.4);
    vtx(leaf,ox,y0+hT,oz,0,1,0,1.25,1.25,1.2,0,0);
    for(let i=0;i<n;i++){ const a=i/n*6.2832+k*.5, rr=rB*(i&1?.78+R()*.08:1), y=y0+(i&1?.2:0)+(R()-.5)*.1, ca=Math.cos(a), sa=Math.sin(a), nl=Math.hypot(.75,.55), sh=.5+R()*.12;
      vtx(leaf,ox+ca*rr,y,oz+sa*rr,ca*.75/nl,.55/nl,sa*.75/nl,sh*1.0,sh*1.05,sh*.95,(ox+ca*rr+(oz+sa*rr)*.6)*.5,y*.5); }
    for(let i=0;i<n;i++) leaf.I.push(base,base+1+i,base+1+(i+1)%n); }
  const bk=Bld(), up=Bld(), c=barkCol(R); tube(bk,rings,S,c,1); const ri=ys.indexOf(HS); tube(up,rings.slice(ri),S,c,1); cap(up,rings[ri],S,false,HS-.02);
  return {bark:done(bk),leaf:done(leaf),upper:done(up),hs:HS,rc:2.1,H:yb+(nT-1)*(5.4/nT)+2.3-(nT-1)*.1,yc:4.6,kind:"pine",bare:null,sided:true}; }
function poplar(seed){ const R=mkR(seed), HS=TG.HS, H=2.0, lean=[(R()-.5)*.14,(R()-.5)*.14], ys=[0,.4,.9,HS,2.0,3.2,5.5], S=5;
  const rings=trunkRings(R,{ys,H:5.5,r0:.36,r1:.12,flare:.5,lean,top:1}), blobs=[], cy=[3.3,4.9,6.5,8.0,9.3], rx=[1.15,1.3,1.25,1.0,.65];
  cy.forEach((y,i)=>blobs.push([lean[0]*1.4+(R()-.5)*.35,y,lean[1]*1.4+(R()-.5)*.35,rx[i],i===4?1.5:1.85,rx[i]]));
  const leaf=Bld(); crownBlobs(leaf,R,blobs,[lean[0],6.2,lean[1]],2.4,10.8,.6,.16);
  const bk=Bld(), up=Bld(), c=barkCol(R); tube(bk,rings,S,c,1); const ri=ys.indexOf(HS); tube(up,rings.slice(ri),S,c,1); cap(up,rings[ri],S,false,HS-.02);
  return {bark:done(bk),leaf:done(leaf),upper:done(up),lo:{bark:loBark(rings,ri,4,R),leaf:loCrown(seed,blobs,[lean[0],6.2,lean[1]],2.4,10.8)},hs:HS,rc:1.5,H:10.8,yc:6.2,kind:"oak",bare:bare(seed+9,{H:2.6,n:7,tilt:[.22,.5],len:[2.2,3.6],spread:4.8,top:3.4,lean,x:lean[0],z:lean[1],r:.14})}; }
function birch(seed,v){ const R=mkR(seed), HS=TG.HS, H=3.4+R()*.5, lean=[(R()-.5)*.5,(R()-.5)*.5], ys=[0,.5,HS,2.2,H,H+.9], S=5, yc=H+1.2;
  const rings=trunkRings(R,{ys,H,r0:.26,r1:.15,flare:.25,lean,top:.9}), top=rings[rings.length-1], blobs=[[top.x,yc,top.z,1.7,1.75,1.7]], ns=v===1?2:3, a0=R()*6.28;
  for(let i=0;i<ns;i++){ const a=a0+i/ns*6.283+(R()-.5)*.5, rho=.9+R()*.35; blobs.push([top.x+Math.cos(a)*rho,yc+(R()-.25)*1.5,top.z+Math.sin(a)*rho,1.0+R()*.25,1.05+R()*.25,1.0+R()*.25]); }
  blobs.push([top.x,yc+1.55,top.z,1.05,.95,1.05]);
  const leaf=Bld(); crownBlobs(leaf,R,blobs,[top.x,yc,top.z],yc-2,yc+2.6,.5,.26);
  const bk=Bld(), up=Bld(), c=barkCol(R); tube(bk,rings,S,c,1); const ri=ys.indexOf(HS); tube(up,rings.slice(ri),S,c,1); cap(up,rings[ri],S,false,HS-.02);
  { const q=blobs[1], l=lim(R), p0=[rings[4].x,H-.9,rings[4].z], p1=[q[0]*.8+top.x*.2,yc-.4,q[2]*.8+top.z*.2]; limb(bk,p0,p1,.1,.05,4,l); limb(up,p0,p1,.1,.05,4,l); }
  return {bark:done(bk),leaf:done(leaf),upper:done(up),lo:{bark:loBark(rings,ri,4,R),leaf:loCrown(seed,blobs,[top.x,yc,top.z],yc-2,yc+2.6)},hs:HS,rc:2.4,H:yc+2.4,yc,kind:"birch",bare:bare(seed+9,{H:H-.5,n:5,tilt:[.5,.95],len:[1.9,2.5],spread:1.1,top:2.4,lean,x:top.x,z:top.z,r:.12})}; }
/* kış: çıplak dallar (açık üçgen prizmalar) */
function bare(seed,o){ const R=mkR(seed), b=Bld(), col=()=>[.8,.76,.72], dir=(yaw,tilt)=>[Math.sin(tilt)*Math.sin(yaw),Math.cos(tilt),Math.sin(tilt)*Math.cos(yaw)], add=(p,d,l)=>[p[0]+d[0]*l,p[1]+d[1]*l,p[2]+d[2]*l];
  const p0=[o.x,o.H,o.z], lead=[o.x+(R()-.5)*.4,o.H+o.top,o.z+(R()-.5)*.4]; limb(b,p0,lead,o.r*1.1,.03,3,col);
  for(let i=0;i<o.n;i++){ const yaw=i/o.n*6.283+R()*.7, tilt=o.tilt[0]+R()*(o.tilt[1]-o.tilt[0]), L=o.len[0]+R()*(o.len[1]-o.len[0]), pa=[o.x,o.H+R()*o.spread,o.z], d=dir(yaw,tilt), pb=add(pa,d,L);
    limb(b,pa,pb,o.r*.7,.03,3,col);
    for(let j=0;j<2;j++){ const t=.45+j*.3, pm=[pa[0]+(pb[0]-pa[0])*t,pa[1]+(pb[1]-pa[1])*t,pa[2]+(pb[2]-pa[2])*t], d2=dir(yaw+(j?.8:-.8)+R()*.5,Math.min(1.4,tilt+.35+R()*.3)), pc=add(pm,d2,L*.55);
      limb(b,pm,pc,.035,.015,3,col);
      for(let k=0;k<2;k++){ const d3=dir(yaw+(k?1:-1)*(.6+R()*.5)+(j?.5:-.5),Math.min(1.5,tilt+.6+R()*.4)), pe=add(pc,d3,L*.28), pq=[pc[0]*.5+pm[0]*.5,pc[1]*.5+pm[1]*.5,pc[2]*.5+pm[2]*.5]; limb(b,pq,add(pq,d3,L*.3),.02,.008,3,col); } } }
  return done(b); }
/* kütük (kırılan ağaçtan geriye kalan): düzensiz üst, açık renkli kesit, kıymıklar */
TG.stump=function(kind){ const R=mkR(kind==="pine"?71:kind==="birch"?72:70), HS=TG.HS, S=7, b=Bld(), r0=kind==="birch"?.26:kind==="pine"?.32:.44, r1=kind==="birch"?.19:kind==="pine"?.26:.34;
  const yj=[]; for(let i=0;i<S;i++) yj.push((R()-.5)*.34);
  const ys=[0,.35,.8,HS-.02]; const rings=ys.map((y,k)=>({x:0,y,z:0,r:(r0+(r1-r0)*(k/3))*(1+.5*Math.exp(-y*3.2)),yj:k===3?yj:null}));
  tube(b,rings,S,barkCol(R),1); cap(b,rings[3],S,true,HS+.1);
  for(let i=0;i<3;i++){ const a=(i*2.1+R()*.8), ra=rings[3].r*.55, ca=Math.cos(a), sa=Math.sin(a), y=HS-.02+yj[(i*2)%S], hgt=.22+R()*.25, base=b.P.length/3, a2=a+.7;
    vtx(b,ca*ra*1.1,y,sa*ra*1.1,ca*.7,.5,sa*.7,2.2,1.9,1.4,0,0); vtx(b,Math.cos(a2)*ra*1.1,y,Math.sin(a2)*ra*1.1,Math.cos(a2)*.7,.5,Math.sin(a2)*.7,2.2,1.9,1.4,1,0); vtx(b,Math.cos(a+.35)*ra*.5,y+hgt,Math.sin(a+.35)*ra*.5,0,1,0,2.6,2.3,1.7,.5,1); b.I.push(base,base+1,base+2); }
  return done(b); };
TG.build=function(){ if(TG.V.length) return TG.V; makeTex(); const V=TG.V;
  const add=(type,o)=>{ o.type=type; V.push(o); TG.byType[type].push(V.length-1); };
  add(0,oak(101,0)); add(0,oak(202,1)); add(0,oak(303,2));
  add(1,pine(404,0)); add(1,pine(505,1));
  add(2,poplar(606)); add(3,birch(707,0)); add(3,birch(808,1));
  return V; };
return TG;
})();
