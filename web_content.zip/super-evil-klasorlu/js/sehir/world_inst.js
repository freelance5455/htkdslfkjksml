"use strict";
/* ===== ŞEHİR: örneklenmiş nesneler (ağaç, lamba, ışık, araba), trafik, bulutlar; mesh üretimini bitirir ===== */
(function(){
const CG=Game.CG, W=Game.W, rnd=CG.rnd, pick=CG.pick, C=CG.C, std=CG.std, L=CG.lists, CELL=W.CELL;
CG.finish(); const U_=Game.U;
function inst(geo,mat,list,fn,cast){ const m=new THREE.InstancedMesh(geo,mat,Math.max(1,list.length)), o=new THREE.Object3D();
  list.forEach((it,i)=>{ const c=fn(o,it); o.updateMatrix(); m.setMatrixAt(i,o.matrix); if(c) m.setColorAt(i,c); o.rotation.set(0,0,0); o.scale.set(1,1,1); });
  m.instanceMatrix.needsUpdate=true; if(m.instanceColor) m.instanceColor.needsUpdate=true; m.castShadow=!!cast; m.receiveShadow=true; m.frustumCulled=false; if(list.length===0) m.count=0; scene.add(m); return m; }
CG.inst=inst;
/* ---------- DÖŞEMELİ (tile) örnekli mesh: statik nesneleri (lamba, direk, kaya…) mekânsal döşemelere böler. Her döşemenin kendi sınır küresi olduğundan kamera ve gölge frustum'unun dışında kalanlar hiç çizilmez;
   çok uzaktakiler Game.tileMeshes üzerinden (optimize.js) gizlenir. Döşemeler aynı geometri tamponlarını ve malzemeyi paylaşır (ek GPU belleği/shader yok).
   Dönen tutacak: setColorAt(i,c) / setMatrixAt(i,m) / commit() – i = listedeki sıra numarası. ---------- */
const TILE_M=112, tileReg=Game.tileMeshes=Game.tileMeshes||[];
function tiled(geo,mat,list,fn,cast,ts,shs){ const TS=(typeof ts==="number"&&ts>0)?ts:TILE_M, /* ts yalnız pozitif sayı olabilir: önceden lambada `true` geçilince döşeme 1 m oldu → 1928 lamba = 1928 ayrı draw call (+gölge) */ o=new THREE.Object3D(), tiles=new Map();
  if(!geo.boundingSphere&&geo.computeBoundingSphere) geo.computeBoundingSphere();
  const gb=geo.boundingSphere, gr=gb?gb.radius:2, gc=gb?Math.hypot(gb.center.x,gb.center.y,gb.center.z):0;
  list.forEach((it,i)=>{ const c=fn(o,it); o.updateMatrix(); const p=o.position, key=Math.floor(p.x/TS)+","+Math.floor(p.z/TS); let t=tiles.get(key); if(!t){ t=[]; tiles.set(key,t); }
    t.push({i,mx:o.matrix.clone(),c:c||null,x:p.x,y:p.y,z:p.z,sc:Math.max(.01,o.scale.x,o.scale.y,o.scale.z)}); o.rotation.set(0,0,0); o.scale.set(1,1,1); });
  const H={meshes:[],at:new Array(list.length),dirty:new Set(),dirtyM:new Set()};
  for(const t of tiles.values()){ const n=t.length; let x0=1e9,x1=-1e9,y0=1e9,y1=-1e9,z0=1e9,z1=-1e9; for(const e of t){ x0=Math.min(x0,e.x); x1=Math.max(x1,e.x); y0=Math.min(y0,e.y); y1=Math.max(y1,e.y); z0=Math.min(z0,e.z); z1=Math.max(z1,e.z); }
    const cx=(x0+x1)/2, cy=(y0+y1)/2, cz=(z0+z1)/2; let rad=0; for(const e of t) rad=Math.max(rad,Math.hypot(e.x-cx,e.y-cy,e.z-cz)+(gr+gc)*e.sc);
    const g=new THREE.BufferGeometry(); if(geo.index) g.setIndex(geo.index); for(const k in geo.attributes) g.setAttribute(k,geo.attributes[k]); if(geo.groups) geo.groups.forEach(q=>g.addGroup(q.start,q.count,q.materialIndex));
    g.boundingSphere=new THREE.Sphere(new THREE.Vector3(cx,cy,cz),rad);
    const m=new THREE.InstancedMesh(g,mat,n); if(Game.ensureIC) Game.ensureIC(m); t.forEach((e,k)=>{ m.setMatrixAt(k,e.mx); if(e.c) m.setColorAt(k,e.c); H.at[e.i]=[m,k]; });
    m.instanceMatrix.needsUpdate=true; if(m.instanceColor) m.instanceColor.needsUpdate=true; m.castShadow=!!cast; m.receiveShadow=true; m.frustumCulled=true; scene.add(m); H.meshes.push(m); tileReg.push({m,cx,cz,r:rad,sh:cast?(shs===undefined?5:shs):-1}); }
  H.setColorAt=(i,c)=>{ const a=H.at[i]; if(!a) return; a[0].setColorAt(a[1],c); H.dirty.add(a[0]); };
  H.setMatrixAt=(i,mx)=>{ const a=H.at[i]; if(!a) return; a[0].setMatrixAt(a[1],mx); H.dirtyM.add(a[0]); };
  H.commit=()=>{ for(const m of H.dirty) if(m.instanceColor) m.instanceColor.needsUpdate=true; for(const m of H.dirtyM) m.instanceMatrix.needsUpdate=true; H.dirty.clear(); H.dirtyM.clear(); };
  return H; }
CG.tiled=tiled; CG.H={};   /* kırılabilirlik (props_break.js) için döşeme tutacakları */
const GREENS=(Game.MAP.greens||["#3f8f3a","#4c9f42","#5aa84a","#36803a","#6bb255"]).map(C), PINES=(Game.MAP.pines||["#2f6f3a","#285f33","#37803f"]).map(C);
const G=(x,z)=>W.terrainH(x,z);
const trees=L.trees, lamps=L.lamps, tlights=L.tlights, cars=L.cars;
const TR=Game.treeRefs={}, WK=Game.windKind;
/* ---------- ağaçlar: 8 varyant (meşe×3, çam×2, kavak, huş×2); her varyant = gövde + yaprak (iki örneklenmiş mesh) ---------- */
const TG=Game.TreeGeo, VARS=TG.build(), O3=new THREE.Object3D();
const hsh=(a,b)=>{ const q=Math.sin(a*127.1+b*311.7)*43758.5453; return q-Math.floor(q); };
const BARK_COL={oak:"#8a7058",pine:"#7a5640",birch:"#ffffff"}, BTX={oak:TG.tex.bark,pine:TG.tex.bark,birch:TG.tex.birch};
const BARKW={}, BARKS={}; for(const k of ["oak","pine","birch"]){ const o={color:C(BARK_COL[k]),roughness:1,map:BTX[k],vertexColors:true}; BARKW[k]=WK(std(o),8); BARKS[k]=std(Object.assign({},o,{color:C(BARK_COL[k])})); }
const LEAF_F=WK(std({roughness:.9,map:TG.tex.leaf,vertexColors:true}),7), LEAF_D=Game.softSnow(WK(std({roughness:.9,map:TG.tex.leaf,vertexColors:true,side:THREE.DoubleSide}),7));
const YEL=C("#b4d060"), PAL={ 0:()=>pick(GREENS).clone().multiplyScalar(1.18), 1:()=>pick(PINES).clone().multiplyScalar(1.2), 2:()=>pick(GREENS).clone().multiplyScalar(1.05), 3:()=>pick(GREENS).clone().lerp(YEL,.33).multiplyScalar(1.22) };
const recs=trees.map((t,i)=>{ const ty=TG.byType[t[3]]?t[3]:0, ids=TG.byType[ty], vi=ids[Math.floor(hsh(t[0],t[1])*ids.length)%ids.length];
  return {i,x:t[0],z:t[1],s:t[2],type:ty,v:vi,pi:vi,slot:0,gy:G(t[0],t[1]),rot:hsh(t[1],t[0])*6.283,alive:true,col:null}; });
TR.recs=recs; TR.G=G; TR.VARS=VARS; TR.BARKW=BARKW; TR.BARKS=BARKS; TR.LEAF_F=LEAF_F; TR.LEAF_D=LEAF_D; TR.parts=[];
/* Ana veri (matris/renk) tam uzunlukta "veri meshleri"nde tutulur (ekrana çizilmez); ekrana yalnız kameraya yakın ağaçlar yoğun (compact) örnek meshlerinde çizilir:
   HI_R içinde tam detay (gölge düşürür), HI_R..FAR_R arası düşük poligonlu model, ötesi çizilmez (sis zaten yutuyor). Kırma/mevsim kodu veri meshlerine yazar ve TR.dirty=true yapar. */
const HI_R=150, FAR_R=900, BARE_R=420, HI2=HI_R*HI_R, FAR2=FAR_R*FAR_R, BARE2=BARE_R*BARE_R;
const mkDense=(geo,mat,cap,cast,withCol)=>{ const m=new THREE.InstancedMesh(geo,mat,Math.max(1,cap)); if(withCol) m.setColorAt(0,new THREE.Color(1,1,1)); m.count=0; m.frustumCulled=false; m.castShadow=!!cast; m.receiveShadow=true; scene.add(m); return m; };
VARS.forEach((V,vi)=>{ const list=recs.filter(r=>r.v===vi); list.forEach((r,k)=>{ r.slot=k; });
  const place=(o,r)=>{ o.position.set(r.x,r.gy,r.z); o.rotation.y=r.rot; o.scale.setScalar(r.s); };
  const bark=inst(V.bark,BARKW[V.kind],list,place,true);
  const leafMat=V.sided?LEAF_D:LEAF_F, leaf=inst(V.leaf,leafMat,list,(o,r)=>{ place(o,r); r.col=PAL[V.type](); return r.col; },true);
  scene.remove(bark); scene.remove(leaf);
  const n=list.length, lo=V.lo||{bark:V.bark,leaf:V.leaf}, capHi=Math.min(n,700);
  TR.parts.push({vi,type:V.type,kind:V.type===1?"pine":"broad",bark,leaf,bare:null,bareR:null,list,V,base:leaf.instanceColor?Float32Array.from(leaf.instanceColor.array):null,
    capHi,hiB:mkDense(V.bark,BARKW[V.kind],capHi,true,false),hiL:mkDense(V.leaf,leafMat,capHi,true,true),
    loB:mkDense(lo.bark,BARKW[V.kind],n,false,false),loL:mkDense(lo.leaf,leafMat,n,false,true),nHi:0,nLo:0}); });
TR.dirty=true; TR.HI_R=HI_R; TR.FAR_R=FAR_R;
/* kışlık çıplak dal meshi (veri: p.bare; çizilen: p.bareR) */
TR.attachBare=function(p,mat){ if(p.bareR||!p.V.bare) return; p.bareR=mkDense(p.V.bare,mat,p.list.length,true,false); TR.dirty=true; };
TR.relod=function(){ const c=camera.position, cx=c.x, cy=c.y, cz=c.z;
  for(const p of TR.parts){ const list=p.list, n=list.length; if(!n) continue;
    const bm=p.bark.instanceMatrix.array, ic=p.leaf.instanceColor, lc=ic?ic.array:null,
      hB=p.hiB.instanceMatrix.array, hL=p.hiL.instanceMatrix.array, hC=p.hiL.instanceColor.array, hasLo=true,
      lB=p.loB.instanceMatrix.array, lL=p.loL.instanceMatrix.array, lCc=p.loL.instanceColor.array,
      bR=p.bareR, bA=bR?bR.instanceMatrix.array:null;
    let hi=0, lo=0, br=0;
    for(let i=0;i<n;i++){ const r=list[i]; if(!r.alive) continue; const dx=r.x-cx, dy=r.gy+4-cy, dz=r.z-cz, d2=dx*dx+dy*dy+dz*dz; if(d2>FAR2) continue; const s16=i*16, s3=i*3;
      if(bA&&d2<BARE2){ const o=br*16; for(let k=0;k<16;k++) bA[o+k]=bm[s16+k]; br++; }
      if(d2<HI2&&hi<p.capHi){ const o=hi*16; for(let k=0;k<16;k++){ hB[o+k]=bm[s16+k]; hL[o+k]=bm[s16+k]; } if(lc){ const q=hi*3; hC[q]=lc[s3]; hC[q+1]=lc[s3+1]; hC[q+2]=lc[s3+2]; } hi++; }
      else { const o=lo*16; for(let k=0;k<16;k++){ lB[o+k]=bm[s16+k]; lL[o+k]=bm[s16+k]; } if(lc){ const q=lo*3; lCc[q]=lc[s3]; lCc[q+1]=lc[s3+1]; lCc[q+2]=lc[s3+2]; } lo++; } }
    const lv=p.leaf.visible!==false;
    p.hiB.count=hi; p.hiL.count=hi; p.hiB.instanceMatrix.needsUpdate=true; p.hiL.instanceMatrix.needsUpdate=true; p.hiL.instanceColor.needsUpdate=true; p.hiL.visible=lv;
    { p.loB.count=lo; p.loL.count=lo; p.loB.instanceMatrix.needsUpdate=true; p.loL.instanceMatrix.needsUpdate=true; p.loL.instanceColor.needsUpdate=true; p.loL.visible=lv; }
    if(bR){ bR.count=br; bR.instanceMatrix.needsUpdate=true; bR.visible=!!(p.bare&&p.bare.visible); }
    p.nHi=hi; p.nLo=lo; p.nBare=br; } TR.dirty=false; };
{ let acc=0, lx=1e9, ly=0, lz=0;
  Game.updaters.push(dt=>{ acc+=dt; const c=camera.position, mv=Math.abs(c.x-lx)+Math.abs(c.y-ly)+Math.abs(c.z-lz);
    if(TR.dirty||(acc>.1&&mv>16)||(acc>1.2&&mv>2)){ TR.relod(); acc=0; lx=c.x; ly=c.y; lz=c.z; } }); }
/* bir ağacı gizle/göster (veri matrisi; çizim bir sonraki TR.relod'da) */
TR.setTree=function(r,alive){ const p=TR.parts[r.pi]; O3.position.set(r.x,r.gy,r.z); O3.rotation.set(0,alive?r.rot:0,0); O3.scale.setScalar(alive?r.s:.0001); O3.updateMatrix();
  for(const m of [p.bark,p.leaf,p.bare]){ if(!m) continue; m.setMatrixAt(r.slot,O3.matrix); m.instanceMatrix.needsUpdate=true; } r.alive=alive; TR.dirty=true; O3.rotation.set(0,0,0); O3.scale.set(1,1,1); };
/* kütükler (kırılan ağaçların kalıntısı): tür başına halka tampon */
TR.stumps={}; for(const k of ["oak","pine","birch"]){ const m=new THREE.InstancedMesh(TG.stump(k),BARKS[k],160); m.count=0; m.frustumCulled=false; m.castShadow=true; m.receiveShadow=true; m.userData.n=0; scene.add(m); TR.stumps[k]=m; }
TR.addStump=function(r){ const m=TR.stumps[VARS[r.v].kind], slot=m.userData.n%160; m.userData.n++; m.count=Math.min(m.userData.n,160);
  O3.position.set(r.x,r.gy,r.z); O3.rotation.set(0,r.rot,0); O3.scale.setScalar(r.s); O3.updateMatrix(); m.setMatrixAt(slot,O3.matrix); m.instanceMatrix.needsUpdate=true; O3.rotation.set(0,0,0); O3.scale.set(1,1,1); };

/* ---------- palmiyeler ve kayalar (adalar) ---------- */
{ const palms=L.palms, rocks=L.rocks, PG=["#2f8f3e","#3aa04a","#4aae52","#2a7f3a","#5bb85a"].map(C), RK=["#8b8d8f","#9a9c9e","#7c7f82","#a39a8c"].map(C);
  const PD=palms.map(p=>{ const s=p[2], rot=p[3], gy=G(p[0],p[1]), H=7.4*s, lean=.08+.16*((rot*7.3)%1), dx=Math.sin(lean)*Math.sin(rot), dy=Math.cos(lean), dz=Math.sin(lean)*Math.cos(rot);
    return {x:p[0],y:gy,z:p[1],s,rot,H,lean,dx,dy,dz,cx:p[0]+dx*H,cy:gy+dy*H,cz:p[1]+dz*H}; });
  const palmTrunk=inst(new THREE.CylinderGeometry(.2,.34,1,7),std({color:C("#8a6a45"),roughness:1,flatShading:true}),PD,(o,d)=>{ o.rotation.order="YXZ"; o.position.set(d.x+d.dx*d.H/2,d.y+d.dy*d.H/2,d.z+d.dz*d.H/2); o.rotation.set(d.lean,d.rot,0); o.scale.set(d.s,d.H,d.s); },true);
  const fr=[]; PD.forEach(d=>{ for(let i=0;i<8;i++) fr.push([d,i]); });
  const fg=new THREE.BoxGeometry(.9,.05,3.8); fg.translate(0,0,1.9);
  TR.frond=inst(fg,WK(std({roughness:.8,flatShading:true,side:THREE.DoubleSide}),3),fr,(o,e)=>{ const d=e[0], i=e[1]; o.rotation.order="YXZ"; o.position.set(d.cx,d.cy,d.cz); o.rotation.set(.3+.28*((i*5)%3)/2,d.rot+i*Math.PI/4+.2*(i&1),0); o.scale.set(d.s,1,d.s*(.85+.25*((i*7)%3)/2)); return pick(PG); },true);
  const cg=new THREE.SphereGeometry(.28,6,5);
  const palmCoco=inst(cg,std({color:C("#4a3220"),roughness:.9}),PD.filter((d,i)=>i%2===0),(o,d)=>{ o.position.set(d.cx+.2,d.cy-.35,d.cz+.1); o.scale.setScalar(d.s); },false);
  CG.palmData={PD,trunk:palmTrunk,frond:TR.frond,coco:palmCoco};
  CG.H.rock=tiled(new THREE.IcosahedronGeometry(1,0),std({roughness:1,flatShading:true}),rocks,(o,r)=>{ const s=r[2]; o.rotation.order="YXZ"; o.position.set(r[0],G(r[0],r[1])+.25*s,r[1]); o.rotation.set(r[3]*.3,r[3],0); o.scale.set(1.5*s,.95*s,1.25*s); return pick(RK); },true,0,2); }
/* ---------- sokak donanımı: kalan lambaların yanına çöp kutusu / yangın musluğu / bank (rastgele akışı bozmaz; kırılabilir) ---------- */
{ const hs=(a,b)=>{ const q=Math.sin(a*12.9898+b*78.233)*43758.5453; return q-Math.floor(q); };
  /* asfalt koruması: bulvar ortası / köşe lambalarının çevresi yola düşer; yola taşan donanım hiç üretilmez (hash tabanlı → rastgele akış bozulmaz) */
  const AS=(x,z,m)=>Game.onAsphalt?Game.onAsphalt(x,z,m):false;
  lamps.forEach((l,i)=>{ const r=hs(l[0],l[1]), tx=l[3], tz=-l[2], sg=hs(l[1],l[0])<.5?-1:1;
    if(r<.2){ const x=l[0]+tx*sg*1.5, z=l[1]+tz*sg*1.5; if(!AS(x,z,.45)) CG.prop("bin",x,z,hs(i,3)*6.28); }
    else if(r<.3){ const x=l[0]-tx*sg*1.7, z=l[1]-tz*sg*1.7; if(!AS(x,z,.45)) CG.prop("hydrant",x,z,0); }
    else if(r<.355){ const ax=l[2]===0, a=Math.atan2(l[2],l[3]), bx=l[0]+tx*sg*2.6, bz=l[1]+tz*sg*2.6; if(!AS(bx,bz,1.1)){ CG.prop("bench",bx,bz,a); Game.Places.bench(bx,bz,ax,.57,a); } } }); }
/* ---------- yer çöpleri (kutu, şişe, poşet, kâğıt): kaldırımda lambaların çevresinde; hepsi kırılabilir/dağılır, kışın karla örtülür ---------- */
{ const hs=(a,b)=>{ const q=Math.sin(a*91.17+b*43.37)*43758.5453; return q-Math.floor(q); }, KIND=["can","bottle","bag","paper","paper","can"], COL=["#d94f4f","#4f7fd9","#e0b43a","#4fb36a","#eeeeee","#cfcfcf","#e07d3a"];
  lamps.forEach((l,i)=>{ const r=hs(l[0]+i,l[1]); if(r>.62) return; const n=r<.2?3:r<.4?2:1, tx=l[3], tz=-l[2];
    for(let k=0;k<n;k++){ const d=(hs(i,k+5)-.5)*7, e=-1.6+hs(k,i+9)*1.8, x=l[0]+tx*d+l[2]*e, z=l[1]+tz*d+l[3]*e;
      if(Game.onAsphalt&&Game.onAsphalt(x,z,.3)) continue; /* çöp yola düşmesin */
      CG.prop(KIND[(i*3+k)%KIND.length],x,z,hs(i,k)*6.28,{col:COL[(i+k*2)%COL.length],y:.12}); } }); }
/* ---------- sokak lambası: kaide + konik direk + kavisli kol + kobra başlık (kobra başı yola doğru), lens geceleri parlar ---------- */
const bulbMat=new THREE.MeshBasicMaterial({color:C("#fff0c0")});
{ const lp=CG.rig(); lp.cyl(0,.3,0,.3,.26,.6,10,"#2b2f35"); lp.cyl(0,.78,0,.21,.21,.2,10,"#3a3f46"); lp.cyl(0,4.15,0,.14,.085,6.7,10,"#4d535b");
  lp.bar(0,7.4,0,0,7.85,.6,.12,"#4d535b",.12); lp.bar(0,7.85,.6,0,7.76,1.25,.1,"#4d535b",.1); lp.box(0,7.66,1.5,.52,.2,1.0,"#41474f"); lp.box(0,7.77,1.5,.4,.05,.84,"#5c636c"); lp.box(0,7.62,.95,.16,.14,.2,"#2b2f35");
  CG.H.lamp=tiled(lp.geo(),CG.rigMat,lamps,(o,l)=>{ o.position.set(l[0],0,l[1]); o.rotation.y=Math.atan2(l[2],l[3]); },true,undefined,1);
  CG.H.bulb=tiled(new THREE.BoxGeometry(.42,.04,.82),bulbMat,lamps,(o,l)=>{ o.position.set(l[0]+l[2]*1.5,7.54,l[1]+l[3]*1.5); o.rotation.y=Math.atan2(l[2],l[3]); }); }
/* ---------- trafik ışıkları: direk + her yaklaşma yönüne bir sinyal başı (3 yuvarlak lens, vizör); durumu Game.Traffic.signalAt ile eşzamanlı ---------- */
{ const poleG=CG.rig(); poleG.cyl(0,.28,0,.28,.24,.56,10,"#2a2d32"); poleG.cyl(0,3.0,0,.12,.09,6.0,10,"#3b4047"); poleG.cyl(0,5.95,0,.14,.14,.14,10,"#2a2d32");
  const headG=CG.rig(); headG.box(0,0,0,.56,1.58,.42,"#15171a"); headG.box(0,0,-.2,.74,1.76,.05,"#e9eaec"); headG.box(0,0,-.19,.66,1.68,.05,"#0f1012");
  for(let n=0;n<3;n++){ headG.box(0,.5-n*.5+.2,.27,.4,.05,.3,"#0c0d0f"); headG.box(0,.5-n*.5+.14,.2,.4,.04,.2,"#0c0d0f"); }
  CG.H.tpole=tiled(poleG.geo(),CG.rigMat,tlights,(o,l)=>{ o.position.set(l[0],0,l[1]); },false);
  const heads=[]; for(const l of tlights){ const sx=l[2]>0?1:-1, sz=l[3]>0?1:-1, jx=l[0]+sx*5.7, jz=l[1]+sz*5.7;
    heads.push({x:l[0],z:l[1]-sz*.31,fx:0,fz:-sz,axis:0,jx,jz,ph:-1,i:heads.length},{x:l[0]-sx*.31,z:l[1],fx:-sx,fz:0,axis:1,jx,jz,ph:-1,i:heads.length+1}); }
  const hm=CG.H.heads=tiled(headG.geo(),CG.rigMat,heads,(o,h)=>{ o.position.set(h.x,5.2,h.z); o.rotation.y=Math.atan2(h.fx,h.fz); },false);
  const lg=new THREE.CylinderGeometry(.155,.155,.06,14); if(lg.rotateX) lg.rotateX(Math.PI/2); const lensL=[]; heads.forEach(h=>{ for(let n=0;n<3;n++) lensL.push([h,n]); });
  const LC=[C("#ff2a2a"),C("#ffc400"),C("#22e060")], DIM=C("#241f1f"), lensMat=new THREE.MeshBasicMaterial({color:0xffffff});
  const lm=CG.H.lens=tiled(lg,lensMat,lensL,(o,e)=>{ const h=e[0], n=e[1]; o.position.set(h.x+h.fx*.24,5.2+.5-n*.5,h.z+h.fz*.24); o.rotation.y=Math.atan2(h.fx,h.fz); return DIM; });
  let acc=0, nightK=-1;
  Game.streetSignals={heads,mesh:lm};
  Game.updaters.push(dt=>{ acc-=dt; if(acc>0) return; acc=.18; const T=Game.Traffic; if(!T) return; let dirty=false;
    for(const h of heads){ const ph=T.signalAt(h.jx,h.jz,h.axis); if(ph!==h.ph){ h.ph=ph; const lit=2-ph; for(let n=0;n<3;n++) lm.setColorAt(h.i*3+n,n===lit?LC[n]:DIM); dirty=true; } }
    if(dirty) lm.commit();
    const nt=Game.night||0; if(Math.abs(nt-nightK)>.03){ nightK=nt; lensMat.color.setScalar(1.05+nt*1.7); } }); }
/* gece ışık hâleleri (lambalar) */
(function(){ const n=lamps.length, pos=new Float32Array(n*3); lamps.forEach((l,i)=>{ pos[i*3]=l[0]+l[2]*1.5; pos[i*3+1]=7.45; pos[i*3+2]=l[1]+l[3]*1.5; });
  const g=new THREE.BufferGeometry(); g.setAttribute("position",new THREE.BufferAttribute(pos,3));
  const c=CG.cnv(64,64), q=c.getContext("2d"), gr=q.createRadialGradient(32,32,0,32,32,32); gr.addColorStop(0,"rgba(255,235,180,1)"); gr.addColorStop(.3,"rgba(255,215,140,.45)"); gr.addColorStop(1,"rgba(255,200,120,0)"); q.fillStyle=gr; q.fillRect(0,0,64,64);
  const m=new THREE.ShaderMaterial({transparent:true,depthWrite:false,blending:THREE.AdditiveBlending,uniforms:{tex:{value:new THREE.CanvasTexture(c)},scale:{value:800},op:{value:0}},
    vertexShader:"uniform float scale; void main(){ vec4 mv=modelViewMatrix*vec4(position,1.); gl_Position=projectionMatrix*mv; gl_PointSize=clamp(9.*scale/max(-mv.z,1.),2.,120.); }",
    fragmentShader:"uniform sampler2D tex; uniform float op; void main(){ vec4 t=texture2D(tex,gl_PointCoord); gl_FragColor=vec4(t.rgb*op,t.a*op); }"});
  const p=new THREE.Points(g,m); p.frustumCulled=false; p.visible=false; p.renderOrder=4; scene.add(p); Game.lampGlow=p;
  Game.updaters.push(()=>{ const nt=Game.night||0; p.visible=nt>.08&&Game.mode!=="x"; m.uniforms.op.value=nt*.9; const h=Game.three.renderer?Game.three.renderer.domElement.height:800; m.uniforms.scale.value=h/(2*Math.tan(camera.fov*Math.PI/360));
    bulbMat.color.copy(C("#fff0c0")).multiplyScalar(1+nt*2.2); }); })();
const CK=Game.CarKit, BX=null;
function carType(c,i){ if(c.type!==undefined) return c.type; if(c.h>1.5) return 3; const r=(Math.sin(i*91.7+(c.x||0)*.37+(c.z||0)*.53)*43758.5453)%1, q=Math.abs(r); return q<.22?0:q<.40?1:q<.50?2:q<.68?4:q<.74?5:q<.82?9:q<.91?10:11; }
const TAXI_Y="#f5c211";
const parkedSet=new CK.CarSet(cars,carType), PQ={x:0,y:0,z:0,w:1};
cars.forEach((c,i)=>{ const t=parkedSet.type(i), sc=CK.scaleFor(t,c.nat?0:c.w,c.nat?0:c.l,c.h); c.t=t; c.sc=sc; if(t===5) c.col=TAXI_Y; U_.yawQ((c.v?0:Math.PI/2)+(c.flip?Math.PI:0),PQ); parkedSet.write(i,c.x,.08,c.z,PQ,sc.sx,sc.sy,sc.sz,0); parkedSet.color(i,C(c.col)); }); parkedSet.flush();

/* ---------- Canlı trafik: sadece gerçekten var olan yollarda ---------- */
const lines=[], DI=Game.Districts;
/* trafik şeritleri: yalnızca gerçekten yol çizilen kenarlar boyunca (tarlalardan geçmez); ardışık yol kenarları birleştirilir */
for(let k=-15;k<=15;k++){ for(const ax of [0,1]){ let lo=null, hi=null;
    for(let g=-15;g<=15;g++){ const ga=ax===0?k:g, gb=ax===0?g:k, na=ax===0?k+1:g, nb=ax===0?g:k+1;
      let ok=false; if(W.inCity(ga,gb)) ok=DI.edgeRoad(ga,gb,ax===0?1:0); else if(W.inCity(na,nb)) ok=DI.edgeRoad(na,nb,ax===0?3:2);
      if(ok){ if(lo===null) lo=g*CELL-17; hi=g*CELL+17; } else { if(lo!==null&&hi-lo>=120) lines.push({axis:ax,line:17+34*k,lo:lo+8,hi:hi-8}); lo=null; } }
    if(lo!==null&&hi-lo>=120) lines.push({axis:ax,line:17+34*k,lo:lo+8,hi:hi-8}); } }
const traffic=[]; for(let i=0;i<84;i++){ const ln=pick(lines); const r=rnd(); traffic.push({axis:ln.axis,line:ln.line,lo:ln.lo,hi:ln.hi,dir:rnd()<.5?-1:1,pos:ln.lo+rnd()*(ln.hi-ln.lo),spd:9+rnd()*8,col:pick(CG.CC),type:r<.18?0:r<.34?1:r<.42?2:r<.58?4:r<.66?5:r<.74?9:r<.87?10:11}); if(traffic[traffic.length-1].type===5) traffic[traffic.length-1].col=TAXI_Y; }
/* rezerve araçlar (başta gizli): ambulans x3 (tip 6), polis arabası x8 (tip 7) — emerg.js yönetir */
for(let i=0;i<3;i++) traffic.push({axis:0,line:17,lo:0,hi:1,dir:1,pos:0,spd:16,col:"#f4f4f4",type:6,role:"amb",gone:true});
for(let i=0;i<8;i++) traffic.push({axis:0,line:17,lo:0,hi:1,dir:1,pos:0,spd:17,col:"#f4f4f4",type:7,role:"cop",gone:true});
for(let i=0;i<2;i++) traffic.push({axis:0,line:17,lo:0,hi:1,dir:1,pos:0,spd:8,col:"#5b6b3c",type:8,role:"tank",gone:true,armor:.3});
const TN=traffic.length, trafficSet=new CK.CarSet(traffic,t=>t.type), TQ={x:0,y:0,z:0,w:1};
traffic.forEach((t,i)=>{ t.sc=CK.scaleFor(t.type,0,0,0); trafficSet.color(i,C(t.col)); });
Game.traffic=traffic; Game.carRefs={parkedSet,trafficSet,cars,traffic}; Game.trafficLines=lines; Game.trafficQ=TQ;

/* ---------- Bulutlar ---------- */
const blobs=[]; for(let i=0;i<50;i++){ const a=rnd()*6.28,r=150+rnd()*1100,cx=Math.cos(a)*r,cz=Math.sin(a)*r,cy=280+rnd()*140; for(let j=0,n=3+Math.floor(rnd()*4);j<n;j++) blobs.push([cx+(rnd()-.5)*90,cy+(rnd()-.5)*10,cz+(rnd()-.5)*50,30+rnd()*35,10+rnd()*8,22+rnd()*20]); }
const cloudMat=new THREE.MeshLambertMaterial({color:0xffffff,emissive:0x7a8aa0,transparent:true,opacity:.92,depthWrite:false});
const cloudMesh=inst(new THREE.IcosahedronGeometry(1,1),cloudMat,blobs,(o,b)=>{ o.position.set(b[0],b[1],b[2]); o.scale.set(b[3],b[4],b[5]); }); cloudMesh.receiveShadow=false; Game.cloudMesh=cloudMesh; Game.cloudMat=cloudMat;
Game.updaters.push(dt=>{ cloudMesh.rotation.y+=dt*.004; const n=Game.night||0; cloudMat.emissive.setRGB(.48*(1-n*.85),.54*(1-n*.85),.63*(1-n*.7)); cloudMat.color.setRGB(1-n*.75,1-n*.75,1-n*.65); });
})();
