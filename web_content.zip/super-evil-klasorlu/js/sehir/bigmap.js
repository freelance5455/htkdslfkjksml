"use strict";
/* ===== TAM EKRAN HARİTA: mini haritaya dokun → kuzey yukarı, sürükle = kaydır, kıstır / +- = yakınlaştır ===== */
Game.BigMap=(function(){
  const box=$("bigMap"), cv=$("bmc"), MM=Game.Minimap, api={}; if(!box||!cv||!MM||!MM.paintBig) return api;
  const q=cv.getContext("2d"), EXT=1100; let open=false, r=420, cx=0, cz=0, follow=true, raf=0; const ptr=new Map(); let pinch0=0, r0=0;
  function size(){ const s=Math.min(innerWidth,innerHeight), px=Math.round(Math.max(420,Math.min(1100,s*Math.min(2,window.devicePixelRatio||1)))); if(cv.width!==px){ cv.width=px; cv.height=px; } }
  function clampView(){ r=Math.max(80,Math.min(1100,r)); cx=Math.max(-EXT,Math.min(EXT,cx)); cz=Math.max(-EXT,Math.min(EXT,cz)); }
  function paint(){ if(!open) return; const [hx,hz]=MM.playerPos(); if(follow){ cx=hx; cz=hz; } clampView(); MM.paintBig(q,cv.width,cx,cz,r); const loc=$("bmLoc"); if(loc) loc.classList.toggle("on",!follow); }
  function loop(){ if(!open) return; paint(); raf=requestAnimationFrame(loop); }
  api.open=function(){ if(open||Game.mode!=="play") return; Game.audio.click(); enterMode("pause"); SCREENS.forEach(s=>$(s).classList.remove("on")); size(); follow=true; r=Math.max(260,Math.min(700,MM.r*2.6)); open=true; box.classList.add("on"); loop(); };
  api.close=function(){ if(!open) return; open=false; cancelAnimationFrame(raf); box.classList.remove("on"); ptr.clear(); Game.audio.click(); enterMode("play"); };
  api.isOpen=()=>open;
  const wpp=()=>2*r/Math.max(1,cv.clientWidth);
  cv.addEventListener("pointerdown",e=>{ try{ cv.setPointerCapture(e.pointerId); }catch(_){} ptr.set(e.pointerId,{x:e.clientX,y:e.clientY}); if(ptr.size===2){ const a=[...ptr.values()]; pinch0=Math.hypot(a[0].x-a[1].x,a[0].y-a[1].y); r0=r; } e.preventDefault(); });
  cv.addEventListener("pointermove",e=>{ const p=ptr.get(e.pointerId); if(!p) return;
    if(ptr.size===1){ const k=wpp(); cx-=(e.clientX-p.x)*k; cz-=(e.clientY-p.y)*k; follow=false; }
    p.x=e.clientX; p.y=e.clientY;
    if(ptr.size===2&&pinch0>0){ const a=[...ptr.values()], d=Math.hypot(a[0].x-a[1].x,a[0].y-a[1].y); r=r0*pinch0/Math.max(10,d); follow=false; } e.preventDefault(); });
  const up=e=>{ ptr.delete(e.pointerId); pinch0=0; if(ptr.size===1){ const a=[...ptr.values()][0]; } };
  cv.addEventListener("pointerup",up); cv.addEventListener("pointercancel",up);
  cv.addEventListener("wheel",e=>{ r*=e.deltaY>0?1.12:.89; e.preventDefault(); },{passive:false});
  $("bmIn").onclick=()=>{ Game.audio.click(); r*=.72; }; $("bmOut").onclick=()=>{ Game.audio.click(); r*=1.38; };
  $("bmLoc").onclick=()=>{ Game.audio.click(); follow=true; };
  $("bmClose").onclick=api.close;
  /* mini haritaya dokun */
  const mm=$("mm"); if(mm){ const tap=e=>{ e.preventDefault(); e.stopPropagation(); api.open(); }; mm.addEventListener("touchstart",tap,{passive:false}); mm.addEventListener("mousedown",tap); }
  addEventListener("resize",()=>{ if(open) size(); });
  /* efsane */
  const leg=$("bmLeg"); function legend(){ if(!leg) return; const it=[["#e63946","H","map_h"],["#3b82f6","P","map_p"],["#ff7a29","F","map_f"],["#f1c40f","S","map_s"],["#b388ff","M","map_m"],["#ffd23a","★","map_t"],["#7a2a12","■","map_d"]]; leg.innerHTML=it.map(a=>'<span><i style="background:'+a[0]+'">'+a[1]+'</i>'+t(a[2])+'</span>').join(""); }
  legend(); const prev=Game.onLang2; Game.onLang2=()=>{ if(prev) prev(); legend(); const tt=$("bmTitle"); if(tt) tt.textContent=t("map_title"); };
  return api; })();
