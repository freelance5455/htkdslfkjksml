"use strict";
/* ===== YAPI TİPLERİ (kamu): hastane, karakol, okul, itfaiye, AVM — hepsi yıkılabilir, içi dolu ===== */
(function(){
const CG=Game.CG, rnd=CG.rnd, pick=CG.pick, pbox=CG.pbox, fbox=CG.fbox, CC=CG.CC;
const cross=(top,A,x,z,sz)=>{ pbox(A,x,top,z,sz,.12,sz*.3,"#e02020"); pbox(A,x,top,z,sz*.3,.12,sz,"#e02020"); };
CG.hospital=function(cx,cz){ CG.slab(cx,cz,"#cdd1d6"); const A=CG.F(cx,cz);
  for(let i=0;i<5;i++) fbox(A,cx-10+i*3,.12,cz+9.5,.12,.03,4,"#f2f2f2");
  const bl=CG.bl(), t=CG.tier(bl,{x:cx,z:cz-3,w:20,d:12,y0:0,h:20,LH:8,style:"w",tint:"#ffffff",kind:"hospital",door:0,doorW:4,ic:"#eef3f6",fc:"#c4d0d8",cc:"#f7f9fb",roof:"flat",
    doorDeco:(A2,p,tt,dg)=>CG.canopy(A2,p,dg,"#d22",3.6),
    props:(top,A2,tt)=>{ cross(top+.5,A2,cx-4,cz-3,6); pbox(A2,cx+5,top+.5,cz-5,2.4,1.3,2.4,"#8d939b"); pbox(A2,cx+8,top+.5,cz-1,1.8,1.6,1.8,"#a3a9b0"); return top+2; }});
  CG.doorSign(t,"HOSPITAL",7,1.5,"#d22","#fff",5.4);
  const bl2=CG.bl(), t2=CG.tier(bl2,{x:cx+7,z:cz+6.8,w:6,d:7,y0:0,h:12,LH:8,style:"w",tint:"#f4f7fb",kind:"hospital",ic:"#eef3f6",fc:"#c4d0d8",roof:"flat",
    props:(top,A2,tt)=>{ pbox(A2,cx+7,top+.3,cz+6.8,5.4,.14,5.4,"#363b42"); pbox(A2,cx+5.9,top+.44,cz+6.8,.45,.06,3.2,"#fff"); pbox(A2,cx+8.1,top+.44,cz+6.8,.45,.06,3.2,"#fff"); pbox(A2,cx+7,top+.44,cz+6.8,2.2,.06,.45,"#fff"); return top+.8; }});
  CG.addCar(cx-8,cz+9.8,false,"#ffffff",5,2.1,2.2); CG.addCar(cx-3,cz+9.8,false,"#ffffff",5,2.1,2.2); fbox(A,cx-8,2.62,cz+9.8,.3,.15,1.4,"#e11d2e"); fbox(A,cx-3,2.62,cz+9.8,.3,.15,1.4,"#e11d2e");
  for(const s of [-1,1]) CG.tree(cx+s*11,cz+2,.9,0); };
CG.police=function(cx,cz){ CG.slab(cx,cz,"#c4c8ce"); const A=CG.F(cx,cz), bl=CG.bl();
  const t=CG.tier(bl,{x:cx,z:cz-3.5,w:20,d:11,y0:0,h:12,LH:8,style:"w",tint:"#cdd8ea",kind:"police",door:0,doorW:3.6,ic:"#d6dce6",fc:"#8a96a6",cc:"#eef1f5",roof:"flat",
    doorDeco:(A2,p,tt,dg)=>CG.canopy(A2,p,dg,"#1d4ed8",3.6),
    props:(top,A2,tt)=>{ pbox(A2,cx-4,top+.5,cz-3.5,1.4,.9,1.4,"#e11d2e"); pbox(A2,cx+4,top+.5,cz-3.5,1.4,.9,1.4,"#1d4ed8"); pbox(A2,cx,top+.5,cz-6,.3,6,.3,"#aaa"); pbox(A2,cx+6,top+.5,cz-1,2,1.2,2,"#8d939b"); return top+7; }});
  CG.doorSign(t,"POLICE",7,1.5,"#10265e","#fff",5.4); CG.flag(cx+9.5,cz+8.5,"#1d4ed8");
  [-8,-4.5,-1].forEach((i,n)=>{ CG.addCar(cx+i,cz+9.8,false,"#f5f5f5",4.4,1.85,.85,0); fbox(A,cx+i,1.5,cz+9.8,.3,.14,1.3,n%2?"#1d4ed8":"#e11d2e"); });
  for(const s of [-1,1]) CG.tree(cx+s*11,cz+3,.9,0); };
CG.school=function(cx,cz){ CG.slab(cx,cz,"#e3d6b4"); const A=CG.F(cx,cz), tn="#f2c9a5", bl=CG.bl();
  const t=CG.tier(bl,{x:cx,z:cz-6.5,w:22,d:8,y0:0,h:8,LH:8,style:"w",tint:tn,kind:"school",door:0,doorW:3.6,ic:"#f1e4c4",fc:"#9fa8b0",cc:"#f4efe2",roof:"flat",doorDeco:(A2,p,tt,dg)=>CG.canopy(A2,p,dg,"#2a63c9",3.6),
    props:(top,A2,tt)=>{ pbox(A2,cx-7,top+.5,cz-6.5,1.6,1.1,1.6,"#8d939b"); return top+1.8; }});
  CG.doorSign(t,"SCHOOL",6.4,1.3,"#2a63c9","#fff",5.4);
  const t2=CG.tier(bl,{x:cx,z:cz-6.5,w:5,d:5,y0:8,h:9,LH:8,style:"w",tint:tn,kind:"school",ic:"#f1e4c4",fc:"#9fa8b0",roof:"hip",roofCol:"#8a3b30",rh:4});
  CG.wallSign(t2,0,"12",2.6,2.6,"#fafafa","#222",13.6);
  for(const sx of [-9,9]){ const b2=CG.bl(); CG.tier(b2,{x:cx+sx,z:cz+1,w:4,d:9,y0:0,h:8,LH:8,style:"w",tint:tn,kind:"school",door:sx>0?3:1,ic:"#f1e4c4",fc:"#9fa8b0",roof:"flat"}); }
  fbox(A,cx,.14,cz+4.5,10,.05,6.5,"#3f6fb0"); fbox(A,cx,.19,cz+4.5,.15,.03,6.5,"#fff"); fbox(A,cx,.19,cz+1.3,10,.03,.15,"#fff"); fbox(A,cx,.19,cz+7.7,10,.03,.15,"#fff"); fbox(A,cx-5,.19,cz+4.5,.15,.03,6.5,"#fff"); fbox(A,cx+5,.19,cz+4.5,.15,.03,6.5,"#fff");
  for(const s of [-1,1]){ fbox(A,cx+s*5.3,.14,cz+4.5,.15,3,.15,"#555"); fbox(A,cx+s*5.1,3,cz+4.5,.1,1,1.4,"#eee"); }
  CG.flag(cx+9.5,cz+9.5,"#d62828"); CG.addCar(cx-6,cz+10.4,false,"#ffcc00",8,2.4,2.4); fbox(A,cx-6,.9,cz+10.4,8.02,.3,2.42,"#222"); };
CG.fire=function(cx,cz){ CG.slab(cx,cz,"#cdd0d5"); const A=CG.F(cx,cz), bl=CG.bl();
  const t=CG.tier(bl,{x:cx,z:cz-3,w:20,d:12,y0:0,h:8,LH:8,style:"w",tint:"#f0b8b0",kind:"fire",door:0,doorW:5.5,ic:"#efe3dc",fc:"#8f9399",cc:"#f2eee9",roof:"flat",doorDeco:(A2,p,tt,dg)=>CG.canopy(A2,p,dg,"#b01c1c",4.2)});
  CG.doorSign(t,"FIRE",5,1.2,"#d62828","#fff",5.6);
  const t2=CG.tier(bl,{x:cx+7.5,z:cz-3,w:4,d:4,y0:8,h:10,LH:8,style:"w",tint:"#e9a89f",kind:"fire",ic:"#efe3dc",fc:"#8f9399",roof:"flat",props:(top,A2)=>{ pbox(A2,cx+7.5,top+.5,cz-3,.4,3,.4,"#bbb"); return top+3.5; }});
  CG.addCar(cx-4,cz+8.8,true,"#d62828",7.5,2.5,2.4); CG.addCar(cx+3,cz+8.8,true,"#d62828",7.5,2.5,2.4); };
CG.mall=function(cx,cz){ CG.slab(cx,cz,"#c4c8ce"); const A=CG.F(cx,cz), bl=CG.bl();
  const t=CG.tier(bl,{x:cx,z:cz-3,w:22,d:14,y0:0,h:8,LH:8,style:"s",tint:"#dfe8ff",kind:"mall",door:0,doorW:6,ic:"#f4f4f4",fc:"#c8ccd2",cc:"#fafafa",roof:"none",doorDeco:(A2,p,tt,dg)=>CG.canopy(A2,p,dg,"#7c3aed",3.8)});
  CG.doorSign(t,"MALL",8,1.8,"#7c3aed","#fff",5.8);
  const t2=CG.tier(bl,{x:cx,z:cz-3,w:18,d:10,y0:8,h:8,LH:8,style:"g",tint:"#bcd0e8",kind:"mall",ic:"#f4f4f4",fc:"#c8ccd2",roof:"flat",
    props:(top,A2,tt)=>{ pbox(A2,cx-5,top+.5,cz-3,2.6,1.4,2.6,"#8d939b"); pbox(A2,cx+5,top+.5,cz-3,2.6,1.4,2.6,"#8d939b"); pbox(A2,cx-3.6,top+.65,cz+1.7,.4,1.3,.4,"#4a4f57"); pbox(A2,cx+3.6,top+.65,cz+1.7,.4,1.3,.4,"#4a4f57"); return top+2; }});
  if(t2.prop) CG.attach(t2.prop,CG.sign("MALL",9,2.4,"#7c3aed","#fff",cx,18.2,cz+2.06,0));
  for(let i=0;i<9;i++){ fbox(A,cx-10+i*2.5,.14,cz+9.2,.12,.03,4,"#f4f4f4"); if(rnd()<.7&&i<8) CG.addCar(cx-8.75+i*2.5,cz+9.2,true,pick(CC)); } };
})();
