"use strict";
/* ===== KÖPRÜ: şehir doğu kıyısından Luna Park adasına asma köprü (güverte yürünebilir/uçulabilir) ===== */
(function(){
const CG=Game.CG, W=Game.W, fbox=CG.fbox, rbox=CG.rbox, co=CG.co, L=CG.lists, ZC=17, X0=332, X1=602, YD=7, HW=6.5;
function deckY(x){ if(x<X0||x>X1) return null; if(x<372) return YD*(x-X0)/40; if(x>562) return YD*(X1-x)/40; return YD; }
W.bridge.deckAt=function(x,z){ if(Math.abs(z-ZC)>HW) return null; return deckY(x); };
W.bridge.info={ZC,X0,X1,YD,HW};
/* güverte: 5 m'lik parçalar */
const STEP=5;
for(let x=X0;x<X1;x+=STEP){ const xm=x+STEP/2, y0=deckY(x), y1=deckY(x+STEP), ym=(y0+y1)/2, A=CG.F(xm,ZC), pitch=-Math.atan2(y1-y0,STEP), th=.9;
  rbox(A,xm,ym-th/2,ZC,HW*2,th,STEP+.05,Math.PI/2,pitch,"#3b3f46");                 // gövde (yaw π/2: uzun eksen x)
  rbox(A,xm,ym+.02,ZC,HW*2-2.2,.1,STEP+.05,Math.PI/2,pitch,"#34373d");               // asfalt
  rbox(A,xm,ym+.12,ZC-HW+.55,1.1,.24,STEP+.05,Math.PI/2,pitch,"#b9bcc2"); rbox(A,xm,ym+.12,ZC+HW-.55,1.1,.24,STEP+.05,Math.PI/2,pitch,"#b9bcc2");   // kaldırım
  if(((x-X0)/STEP)%2===0) rbox(A,xm,ym+.09,ZC,STEP*.5,.04,.25,Math.PI/2,pitch,"#e9c13a");
  for(const s of [-1,1]){ rbox(A,xm,ym+1.0,ZC+s*(HW-.1),.12,1.0,STEP+.05,Math.PI/2,pitch,"#c9ced6"); rbox(A,xm,ym+.55,ZC+s*(HW-.1),.12,.12,STEP+.05,Math.PI/2,pitch,"#aeb4bb"); }
  if(((x-X0)/STEP)%3===0) for(const s of [-1,1]) fbox(A,xm,ym-th,ZC+s*(HW-.2),.5,th*.6,.5,"#2f3238"); }
/* sade kirişler (alttan taşıyıcı): her 40 m'de bir ayak çifti */
for(let x=372;x<=562;x+=38){ const A=CG.F(x,ZC); for(const s of [-1,1]){ fbox(A,x,-8,ZC+s*5,2.4,YD-.9+8,2.4,"#9aa0a8"); fbox(A,x,-8,ZC+s*5,3.2,2.6,3.2,"#7d838b"); } fbox(A,x,YD-2,ZC,2,1.1,HW*2-1,"#8d939b"); Game.buildings.push({x,z:ZC-5,hw:1.2,hd:1.2,h:YD-.9,y0:-8}); Game.buildings.push({x,z:ZC+5,hw:1.2,hd:1.2,h:YD-.9,y0:-8}); }
/* ana kulelere */
const TW=[430,500], TH=46;
for(const tx of TW){ const A=CG.F(tx,ZC);
  for(const s of [-1,1]){ const z=ZC+s*(HW+1.4); fbox(A,tx,-8,z,3,TH+8,3,"#c24d3a"); fbox(A,tx,TH-4,z,3.6,4,3.6,"#a63f2e"); Game.buildings.push({x:tx,z:z,hw:1.7,hd:1.7,h:TH,y0:-8}); }
  for(const hh of [YD+14,YD+26,TH-2]) fbox(A,tx,hh,ZC,2.4,2,HW*2+4,"#c24d3a");
  fbox(A,tx,TH+1.5,ZC-HW-1.4,.3,6,.3,"#cc3b3b"); fbox(A,tx,TH+1.5,ZC+HW+1.4,.3,6,.3,"#cc3b3b"); }
/* kablolar: kule1 ← (kıyı) ; kule1 – kule2 sarkık ; kule2 → (ada) */
function cable(xa,ya,xb,yb,sag,z,pts){ const n=Math.max(4,Math.round(Math.abs(xb-xa)/6)); let px=xa,py=ya;
  for(let i=1;i<=n;i++){ const t=i/n, x=xa+(xb-xa)*t, y=ya+(yb-ya)*t-sag*4*t*(1-t); const dx=x-px, dy=y-py, len=Math.hypot(dx,dy), A=CG.F((x+px)/2,z);
    rbox(A,(x+px)/2,(y+py)/2,z,.5,.5,len+.1,Math.PI/2,-Math.atan2(dy,dx),"#d9dce2"); if(pts) pts.push([x,y]); px=x; py=y; } }
for(const s of [-1,1]){ const z=ZC+s*(HW+1.4), pts=[[TW[0],TH]];
  cable(X0+20,YD+1.2,TW[0],TH,0,z,pts); cable(TW[0],TH,TW[1],TH,24,z,pts); cable(TW[1],TH,X1-20,YD+1.2,0,z,pts);
  // askılar: kablo yüksekliğini bul ve güverteye in
  for(let x=X0+30;x<X1-30;x+=10){ if(Math.abs(x-TW[0])<4||Math.abs(x-TW[1])<4) continue; let cy;
    if(x<TW[0]){ const t=(x-(X0+20))/(TW[0]-X0-20); cy=YD+1.2+(TH-YD-1.2)*t; } else if(x<TW[1]){ const t=(x-TW[0])/(TW[1]-TW[0]); cy=TH-24*4*t*(1-t); } else { const t=(x-TW[1])/(X1-20-TW[1]); cy=TH+(YD+1.2-TH)*t; }
    const dy=deckY(x)||YD, A=CG.F(x,z); fbox(A,x,dy+.2,z,.14,Math.max(.3,cy-dy-.2),.14,"#c9ced6"); } }
/* köprü lambaları + ağız tabelaları */
for(let x=X0+25;x<X1-10;x+=26) for(const s of [-1,1]) CG.lamp(x,ZC+s*(HW-.5),0,-s);
{ const A=CG.F(X0,ZC); for(const s of [-1,1]) fbox(A,X0+4,0,ZC+s*(HW+1.5),1.2,5,1.2,"#c24d3a"); fbox(A,X0+4,5,ZC,1.4,1,HW*2+4,"#c24d3a"); }
})();
