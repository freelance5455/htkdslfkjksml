"use strict";
/* ===== TRAFİK YAPAY ZEKASI: şerit takibi (IDM), sinyalli kavşaklar, yayalara/kahramana fren, çarpınca yaralama, üst üste doğmama ===== */
Game.Traffic=(function(){
const R=Game.carRefs, traffic=R.traffic, set=R.trafficSet, lines=Game.trafficLines, TQ=Game.trafficQ, U=Game.U, KIT=Game.CarKit, TN=traffic.length, CELL=Game.W.CELL;
const api={time:0,stats:{hit:0,honk:0}}, CYC=32, GREEN=14, YEL=2;
/* kavşak varlığı: iki şerit gerçekten kesişiyor mu */
const X=new Set(); for(const a of lines) for(const b of lines){ if(a.axis===b.axis) continue; if(b.line>=a.lo&&b.line<=a.hi&&a.line>=b.lo&&a.line<=b.hi) X.add(a.axis+"|"+a.line+"|"+b.line); }
const hasX=(axis,line,c)=>X.has(axis+"|"+line+"|"+c);
/* sinyal: 0 yeşil, 1 sarı, 2 kırmızı (axis 0 = z yönünde akan şeritler) */
function phase(axis,line,c,t){ const kx=axis===0?Math.round((line-17)/CELL):Math.round((c-17)/CELL), kz=axis===0?Math.round((c-17)/CELL):Math.round((line-17)/CELL), off=((kx*5+kz*9)%CYC+CYC)%CYC, u=(t+off)%CYC;
  if(axis===0){ if(u<GREEN) return 0; if(u<GREEN+YEL) return 1; return 2; }
  const w=(u+CYC-16)%CYC; if(w<GREEN) return 0; if(w<GREEN+YEL) return 1; return 2; }
api.signal=(axis,line,c)=>phase(axis,line,c,api.time);
/* görsel ışıklar için: (x,z) kavşak köşesindeki ışığın baktığı eksen için durum */
api.signalAt=function(x,z,axis){ const kx=Math.round((x-17)/CELL), kz=Math.round((z-17)/CELL); return phase(axis,axis===0?17+34*kx:17+34*kz,axis===0?17+34*kz:17+34*kx,api.time); };
const lenOf=t=>(KIT.TYPES[t.type]?KIT.TYPES[t.type].L:4.6)*(t.sc?t.sc.sz:1);
const laneKey=t=>t.axis*4096+Math.round((t.line-17)/CELL)*2+(t.dir>0?1:0);
/* başlangıç: aynı şeritte yeterli aralık bırakarak yerleştir */
function freeAt(t,pos,except){ for(let j=0;j<TN;j++){ const o=traffic[j]; if(o===t||o===except||o.axis!==t.axis||o.line!==t.line||o.dir!==t.dir) continue; if(Math.abs(o.pos-pos)<(lenOf(o)+lenOf(t))/2+9) return false; } return true; }
for(let i=0;i<TN;i++){ const t=traffic[i]; t.spd0=t.spd0||t.spd; t.v=t.spd0*.8; t.reck=Math.random()<.1; t.patience=0; t.hornT=0; t.stuck=0; if(t.role){ t.gone=true; t.v=0; t.off=0; t.siren=0; continue; }
  let ok=false; for(let k=0;k<40&&!ok;k++){ if(freeAt(t,t.pos)){ ok=true; break; } const ln=lines[(Math.random()*lines.length)|0]; t.axis=ln.axis; t.line=ln.line; t.lo=ln.lo; t.hi=ln.hi; t.dir=Math.random()<.5?-1:1; t.pos=ln.lo+Math.random()*(ln.hi-ln.lo); }
  if(!ok){ t.gone=true; } }
const heroPos=()=>Game.heroObj?Game.heroObj.position:{x:0,y:0,z:0};
const order=[]; const peds=[];
function npcObstacles(){ peds.length=0; const N=Game.NPC; if(!N) return; for(const n of N.list){ if(!n.vis||n.st==="gone"||n.st==="held") continue; const b=n.body; peds.push(b?b.position.x:n.x, b?b.position.z:n.z, b?b.position.y:n.y, n); } }
function step(dt){ api.time+=dt; const hp=heroPos(), drv=Game.Drive&&Game.Drive.active?Game.Drive:null; npcObstacles();
  /* şerit sıralaması */
  order.length=0; for(let i=0;i<TN;i++){ const t=traffic[i]; if(t.dyn||t.gone||t.driven) continue; order.push(i); }
  const lanes=new Map(); for(const i of order){ const t=traffic[i], k=laneKey(t); (lanes.get(k)||lanes.set(k,[]).get(k)).push(i); }
  for(const [k,arr] of lanes){ arr.sort((a,b)=>(traffic[a].pos-traffic[b].pos)*traffic[a].dir); }
  for(const [k,arr] of lanes){ for(let q=0;q<arr.length;q++){ const t=traffic[arr[q]], d=t.dir, a0=t.axis===0; const far=Math.hypot((a0?t.line:t.pos)-hp.x,(a0?t.pos:t.line)-hp.z)>230;
      if(t.frozen||t.burnT){ t.v=0; t.spd=0; continue; }
      const L=lenOf(t); let gap=1e9, lv=t.spd0;
      /* öndeki araç (aynı şerit); sıralama dir yönüne göre artan → sonraki eleman öndekidir */
      if(t.siren){ let ov=false; for(let r=q+1;r<arr.length;r++){ const o=traffic[arr[r]], g=(o.pos-t.pos)*d-(lenOf(o)+L)/2; if(g>26) break; if(o.siren){ if(g<gap){ gap=g; lv=o.v||0; } } else if(g<18) ov=true; } t.offT=ov?3.7:0; }
      else if(q+1<arr.length){ const o=traffic[arr[q+1]]; gap=(o.pos-t.pos)*d-(lenOf(o)+L)/2; lv=o.v||0; }
      if(t.siren||t.off){ t.off=(t.off||0)+((t.offT||0)-(t.off||0))*Math.min(1,dt*2.6); if(Math.abs(t.off)<.02&&!t.offT) t.off=0; }
      /* hasarlı/sürülen araç, şeritteki enkaz */
      for(let j=0;j<TN;j++){ const o=traffic[j]; if(o===t||!(o.dyn||o.driven||(o.siren&&(o.off||0)>1.2))||o.gone||o.axis!==t.axis&&false) continue; const ox=o.cx===undefined?1e9:o.cx, oz=o.cz===undefined?1e9:o.cz; const along=((a0?oz:ox)-t.pos)*d, lat=Math.abs((a0?ox:oz)-(a0?t.line-d*1.9:t.line+d*1.9)); if(along>0&&along<40&&lat<2.4){ const g=along-L; if(g<gap){ gap=g; lv=0; } } }
      if(drv&&!far){ const along=((a0?drv.z:drv.x)-t.pos)*d, lat=Math.abs((a0?drv.x:drv.z)-(a0?t.line-d*1.9:t.line+d*1.9)); if(along>0&&along<30&&lat<2.6){ const g=along-L/2-2.4; if(g<gap){ gap=g; lv=Math.max(0,(drv.speed||0)*.3); } } }
      /* kavşak sinyali */
      if(t.hold){ gap=Math.min(gap,.01); lv=0; }
      if(t.stopAt!==undefined&&t.stopAt!==null){ const dist=(t.stopAt-t.pos)*d; if(dist>-1.5){ const g=Math.max(.01,dist+1.9); if(g<gap){ gap=g; lv=0; } } }
      if(!t.siren){ const base=t.pos, idx=d>0?Math.floor((base-17)/CELL)+1:Math.ceil((base-17)/CELL)-1, cNext=17+CELL*idx;
        if(hasX(t.axis,t.line,cNext)){ const stop=cNext-d*(6.2+L/2), dist=(stop-base)*d, ph=phase(t.axis,t.line,cNext,api.time);
          if(dist>-.5&&dist<60){ const brakeD=t.v*t.v/(2*4.2)+1.5; if(ph===2||(ph===1&&dist>brakeD)){ const g=Math.max(.01,dist); if(g<gap){ gap=g; lv=0; } } } } }
      /* yayalar (ve kahraman yerdeyse) */
      if(!t.reck&&!far){ const fx=a0?0:d, fz=a0?d:0, cx=a0?t.line-d*1.9:t.pos, cz=a0?t.pos:t.line+d*1.9, look=7+t.v*1.25;
        for(let p=0;p<peds.length;p+=4){ const dx=peds[p]-cx, dz=peds[p+1]-cz, al=dx*fx+dz*fz; if(al<.5||al>look) continue; const lat=Math.abs(dx*fz-dz*fx); if(lat>1.7) continue; const n=peds[p+3]; if(n.dead&&al>3&&false) continue; const g=al-L/2-1.2; if(g<gap){ gap=g; lv=0; if(t.hornT<=0&&al<14&&!far&&Game.audio&&Game.audio.honk){ t.hornT=3+Math.random()*3; Game.audio.honk(cx,1,cz); api.stats.honk++; } } }
        if(hp.y<3.5){ const dx=hp.x-cx, dz=hp.z-cz, al=dx*fx+dz*fz; if(al>.5&&al<look&&Math.abs(dx*fz-dz*fx)<1.9){ const g=al-L/2-1.5; if(g<gap){ gap=g; lv=0; } } } }
      /* IDM */
      const v=t.v, v0=t.spd0, s0=2.2, T=1.15, am=3.4, bb=4.8; let acc;
      if(gap>=1e8) acc=am*(1-Math.pow(v/v0,4)); else { const dv=v-lv, sStar=s0+Math.max(0,v*T+v*dv/(2*Math.sqrt(am*bb))); acc=am*(1-Math.pow(v/v0,4)-Math.pow(sStar/Math.max(.3,gap),2)); }
      acc=Math.max(-9,Math.min(am,acc)); t.v=Math.max(0,v+acc*dt); if(gap<.8&&t.v>lv) t.v=Math.max(lv,t.v-12*dt);
      t.hornT-=dt; t.spd=t.v;
      let np=t.pos+d*t.v*dt;
      /* yol sonu: kahraman yakınsa dur, uzaksa karşı uçta (boşsa) yeniden başla */
      if(np>t.hi||np<t.lo){ const nearEnd=Math.hypot((a0?t.line:np)-hp.x,(a0?np:t.line)-hp.z)<150; if(nearEnd){ np=d>0?t.hi:t.lo; t.v=0; } else { const start=d>0?t.lo:t.hi; if(freeAt(t,start)){ np=start; t.v=t.spd0*.6; } else np=d>0?t.hi:t.lo; } }
      t.pos=np; } }
  /* yazma + araba-yaya çarpışması */
  for(let i=0;i<TN;i++){ const t=traffic[i]; if(t.dyn||t.gone||t.driven){ continue; } const a0=t.axis===0, of=t.off||0, x=a0?t.line-t.dir*1.9+t.dir*of:t.pos, z=a0?t.pos:t.line+t.dir*1.9-t.dir*of, ry=a0?(t.dir>0?0:Math.PI):(t.dir>0?Math.PI/2:-Math.PI/2); t.cx=x; t.cz=z; t.ry=ry;
    U.yawQ(ry,TQ); set.write(i,x,.08,z,TQ,t.sc.sx,t.sc.sy,t.sc.sz,0);
    if(t.v>3.2&&Game.NPC){ const fx=a0?0:t.dir, fz=a0?t.dir:0, L=lenOf(t)/2+.25; if(Math.abs(x-hp.x)<150&&Math.abs(z-hp.z)<150){ for(let p=0;p<peds.length;p+=4){ const dx=peds[p]-x, dz=peds[p+1]-z; if(Math.abs(dx)>4||Math.abs(dz)>4) continue; const n=peds[p+3]; if(n.carHitT>0||n.dead) continue; const al=dx*fx+dz*fz, lat=dx*fz-dz*fx; if(Math.abs(al)<L&&Math.abs(lat)<1.25&&Math.abs(peds[p+2]-0)<50){ n.carHitT=1.2; const sp=t.v, l=(lat>0?1:-1)*(1+Math.random()*2.5);
        Game.NPC.hit(n,fx*sp*1.1+fz*l,3.2+sp*.22,fz*sp*1.1-fx*l,"car",{speed:sp}); t.v*=.5; api.stats.hit++; if(Game.audio&&Game.audio.carHit) Game.audio.carHit(.9,x,1,z); if(Game.audio&&Game.audio.honk&&t.hornT<=0){ t.hornT=2; Game.audio.honk(x,1,z); } } } } } }
  set.flush(); }
Game.updaters.push(dt=>{ if(Game.mode==="play"||Game.mode==="menu") step(Math.min(dt,.05)); });
api.step=step; api.hasX=hasX; api.lenOf=lenOf; api.freeAt=freeAt; api.X=X; return api; })();
