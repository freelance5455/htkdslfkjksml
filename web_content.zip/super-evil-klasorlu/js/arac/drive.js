"use strict";
/* ===== ARABA SÜRME: BİN / İN, arcade fizik (gaz-fren-el freni-kayma), çarpışma + hasar, bina yıkma, yayalara çarpma, kamera, ses, HUD ===== */
Game.Drive=(function(){
const W=Game.W, U=Game.U, FX=Game.FX, Cars=Game.Cars, KIT=Game.CarKit, H=Game.H, hero=Game.heroObj, D=Game.D, CGL=Game.CG.lists, au=()=>Game.audio;
const api={active:false,x:0,y:0,z:0,speed:0,yaw:0,wind:0,car:null,near:null};
const hudEl=$("hud"), btnEnter=$("enterBtn"), nameEl=$("enterName"), btnExit=$("exitBtn"), spdEl=$("spdNum"), gearEl=$("gearTxt"), rpmEl=$("rpmBar");
/* tip başına: en yüksek hız m/s, ivme, fren, can, hasar katsayısı */
const SPEC=[ {vmax:46,acc:10,brk:20,hp:100,dk:1.2,gear:5},    // 0 sedan
             {vmax:41,acc:9,brk:19,hp:135,dk:.95,gear:5},    // 1 suv
             {vmax:64,acc:14,brk:24,hp:80,dk:1.4,gear:6},       // 2 spor
             {vmax:31,acc:6.5,brk:15,hp:160,dk:.8,gear:4},   // 3 minibüs
             {vmax:39,acc:8.5,brk:18,hp:140,dk:.9,gear:5},   // 4 pikap
             {vmax:45,acc:10,brk:20,hp:100,dk:1.2,gear:5} ];  // 5 taksi
SPEC[9]={vmax:78,acc:17,brk:28,hp:70,dk:1.5,gear:7}; SPEC[10]={vmax:60,acc:15,brk:21,hp:120,dk:1.0,gear:5}; SPEC[11]={vmax:52,acc:13,brk:20,hp:220,dk:.75,gear:4}; // 9 hiper, 10 kas araba, 11 delta kamyonet
const inp={left:false,right:false,gas:false,brake:false,hand:false,horn:false}, keys={}; api.inp=inp;
const clamp=(v,a,b)=>v<a?a:v>b?b:v, TAU=Math.PI*2;
let cur=null, camT=0, shake=0, lookIdle=9, hudT=0, nearT=0, lastFov=70, camPiv=null, camDist=-1, seaT=0;
const Q={x:0,y:0,z:0,w:1}, cpos={x:0,y:0,z:0}, lookV={x:0,y:0,z:0};

/* ---------- girdi: ekran düğmeleri (çoklu dokunma) + klavye ---------- */
document.querySelectorAll(".dbtn").forEach(b=>{ const k=b.dataset.drv; if(!k) return;
  const on=e=>{ e.preventDefault(); e.stopPropagation(); inp[k]=true; b.classList.add("down"); };
  const off=e=>{ e.preventDefault(); inp[k]=false; b.classList.remove("down"); };
  b.addEventListener("touchstart",on,{passive:false}); b.addEventListener("touchend",off,{passive:false}); b.addEventListener("touchcancel",off,{passive:false});
  b.addEventListener("mousedown",on); b.addEventListener("mouseup",off); b.addEventListener("mouseleave",off); });
function clearInputs(){ for(const k in inp) inp[k]=false; document.querySelectorAll(".dbtn.down").forEach(b=>b.classList.remove("down")); }
addEventListener("keydown",e=>{ const k=e.key.toLowerCase(); keys[k]=true; if(Game.mode!=="play") return; if(k==="e"||k==="f"){ if(api.active) api.exit(false); else if(api.near) enter(api.near.kind,api.near.i); } if(k==="h") inp.horn=true; });
addEventListener("keyup",e=>{ const k=e.key.toLowerCase(); keys[k]=false; if(k==="h") inp.horn=false; });
const tapBtn=(el,fn)=>{ if(!el) return; let last=0; const h=e=>{ e.preventDefault(); e.stopPropagation(); const n=performance.now(); if(n-last<350) return; last=n; fn(); };
  el.addEventListener("touchstart",h,{passive:false}); el.addEventListener("mousedown",h); };
tapBtn(btnEnter,()=>{ if(api.near&&Game.mode==="play"&&!api.active){ au().click(); enter(api.near.kind,api.near.i); } });
tapBtn(btnExit,()=>{ if(api.active){ au().click(); api.exit(false); } });

/* ---------- zemin, deniz, engeller ---------- */
const deckAt=(x,z)=>{ const f=W.bridge&&W.bridge.deckAt; if(!f) return null; const d=f(x,z); return d===undefined?null:d; };
const walkable=(x,z)=>deckAt(x,z)!==null||W.terrainH(x,z)>=W.WALK_MIN;
const gAt=(x,z,yr)=>W.surfaceAt(x,z,yr);
const GC=12, grid=new Map(); let gridReady=false;
function buildGrid(){ if(gridReady) return; gridReady=true;
  const add=(x,z,r)=>{ const k=Math.floor(x/GC)*4099+Math.floor(z/GC); let a=grid.get(k); if(!a){ a=[]; grid.set(k,a); } a.push(x,z,r); };
  for(const t of CGL.trees||[]) if(!t.dead) add(t[0],t[1],.4*Math.min(1.5,t[2]||1)+.05);
  for(const t of CGL.palms||[]) add(t[0],t[1],.34);
  for(const t of CGL.lamps||[]) add(t[0],t[1],.2);
  for(const t of CGL.tlights||[]) add(t[0],t[1],.22);
  for(const t of CGL.rocks||[]) add(t[0],t[1],Math.min(2.4,(t[2]||1)*.8)); }
api.removeObstacle=function(x,z){ if(!gridReady) return; const a=grid.get(Math.floor(x/GC)*4099+Math.floor(z/GC)); if(!a) return; for(let k=0;k<a.length;k+=3) if(a[k]===x&&a[k+1]===z){ a.splice(k,3); return; } };
function obstacles(x,z,r,fn){ const ix=Math.floor(x/GC), iz=Math.floor(z/GC);
  for(let a=-1;a<=1;a++) for(let b=-1;b<=1;b++){ const arr=grid.get((ix+a)*4099+(iz+b)); if(!arr) continue;
    for(let k=0;k<arr.length;k+=3){ const dx=x-arr[k], dz=z-arr[k+1], rr=r+arr[k+2], d2=dx*dx+dz*dz; if(d2<rr*rr) fn(arr[k],arr[k+1],arr[k+2],dx,dz,d2,rr); } } }
const bb=[], bc=[];
function gatherBoxes(x0,y0,z0,x1,y1,z1){ bb.length=0; bc.length=0;
  for(const e of Game.buildings){ if(e.h<=0) continue; const ey0=e.y0||0;
    if(x1<e.x-e.hw||x0>e.x+e.hw||z1<e.z-e.hd||z0>e.z+e.hd||y1<ey0||y0>e.h) continue;
    if(!e.tier){ bb.push(e.x-e.hw,ey0,e.z-e.hd,e.x+e.hw,e.h,e.z+e.hd); bc.push(null); continue; }
    for(const ch of e.tier.chunks){ if(!ch.alive) continue; const b=ch.bx;
      for(let k=0;k<b.length;k+=6){ if(x1<b[k]||x0>b[k+3]||z1<b[k+2]||z0>b[k+5]||y1<b[k+1]||y0>b[k+4]) continue; bb.push(b[k],b[k+1],b[k+2],b[k+3],b[k+4],b[k+5]); bc.push(ch); } } } }

/* ---------- bina kırma (yüksek hızda duvara girince) ---------- */
let smashT=0;
function carve(px,py,pz,R,vx,vz,speed){ const R2=R*R, dx=vx/Math.max(speed,1), dz=vz/Math.max(speed,1); let n=0, vol=0, budget=14;
  for(const e of Game.buildings){ const t=e.tier; if(!t||e.h<=0) continue;
    if(px<e.x-e.hw-R||px>e.x+e.hw+R||pz<e.z-e.hd-R||pz>e.z+e.hd+R||py>e.h+R||py<(e.y0||0)-R) continue;
    for(const c of t.chunks){ if(!c.alive) continue; const b=c.bx; let hit=false;
      for(let k=0;k<b.length;k+=6){ const qx=Math.max(b[k]-px,0,px-b[k+3]), qy=Math.max(b[k+1]-py,0,py-b[k+4]), qz=Math.max(b[k+2]-pz,0,pz-b[k+5]); if(qx*qx+qy*qy+qz*qz<=R2){ hit=true; break; } }
      if(!hit) continue;
      let rx=c.x-px, rz=c.z-pz; const al=rx*dx+rz*dz; rx-=al*dx; rz-=al*dz; const rl=Math.hypot(rx,rz)||1; rx/=rl; rz/=rl;
      const k1=.45+Math.random()*.4, out=3+Math.random()*7;
      D.kill(c,vx*k1+rx*out,3+Math.random()*5,vz*k1+rz*out,budget--<=0); n++; vol+=c.kind===1?26:c.sx*c.sy*c.sz; } }
  if(n){ shake=Math.max(shake,Math.min(.9,.25+vol*.0016)); if(smashT<=0){ smashT=.1; au().smash(Math.min(1.3,.35+vol*.004)); }
    FX.spark(px,py,pz,Math.min(14,4+n),12,[1,.8,.5]); FX.cloud(px,py,pz,3,R*.9,2.4); if(Game.NPC) Game.NPC.noise(px,pz,60); }
  return n; }

/* ---------- araba: hasar / yangın / patlama ---------- */
function hurt(d){ const c=cur; if(!c||d<=0||c.dead) return; c.hp-=d; const f=c.hp/c.spec.hp;
  if(f<.35&&!c.scorch){ c.scorch=true; c.set.color(c.i,[.42,.32,.28]); }
  if(c.hp<=0&&!c.dying){ c.dying=.001; Game.toast("t_carfire",3200); } }
function explode(){ const c=cur; if(!c) return; const x=c.x, y=c.y, z=c.z, vx=c.vx, vz=c.vz; leave(true);
  au().boom(x,y,z); FX.fire(x,y+1,z,46,0,6,0,3.2); FX.spark(x,y+1,z,34,18); FX.dust(x,y+1,z,18,3.4,[.3,.3,.3]); FX.shock(x,y+1.2,z,18,14);
  D.damageSphere(x,y+1,z,7.5,.9,13); if(Game.radial) Game.radial(x,y+1,z,10,17,"boom"); shake=1; H.shake=Math.max(H.shake||0,.8); }

/* ---------- bin / in ---------- */
function groundHere(x,z,yr){ return gAt(x,z,yr); }
function enter(kind,i){ if(api.active||Game.mode!=="play"||(Game.Ride&&Game.Ride.active)) return; buildGrid(); const k=Cars.take(kind,i); if(!k) return;
  const sp=SPEC[k.type]||SPEC[0], d=k.d, yaw=k.po.ry;
  cur={kind,i,type:k.type,T:k.T,spec:sp,w:d.w,l:d.l,H:d.H,sx:d.sx,sy:d.sy,sz:d.sz,set:d.set,x:k.po.x,z:k.po.z,y:0,yaw,pitch:0,roll:0,
    vx:Math.sin(yaw)*k.sp,vz:Math.cos(yaw)*k.sp,vy:0,vf:k.sp,vl:0,hp:sp.hp,steer:0,rpm:.14,rpmS:.14,gear:1,thr:0,thrS:0,air:false,dying:0,dead:false,scorch:false,
    skid:0,smD:0,revLock:false,exiting:false,t:0,smokeT:0,lastCrash:-9,cool:new Map(),skT:0,landT:0,hornT:0,fire:0,seaMsg:0};
  cur.y=groundHere(cur.x,cur.z,(k.po.y||0)+.6); api.active=true; api.car=cur; api.x=cur.x; api.z=cur.z; api.y=cur.y; api.speed=Math.abs(k.sp);
  if(Game.dropHeld) Game.dropHeld(); resetActions(); clearInputs(); H.flying=false; H.vel.set(0,0,0);
  H.yaw=yaw+Math.PI; H.pitch=.2; camPiv=null; camDist=-1; camT=0; lookIdle=9; shake=0;
  hudEl.classList.add("driving"); btnEnter.classList.remove("on"); api.near=null; au().door(); setTimeout(()=>au().engineStart(cur&&cur.type),180);
  Game.toast("t_drive",3200); writeCar(); updateHeroPos(); }
function writeCar(){ const c=cur, sy=Math.sin(c.yaw/2), cy=Math.cos(c.yaw/2), px=Math.sin(-c.pitch/2), pw=Math.cos(-c.pitch/2), rz=Math.sin(c.roll/2), rw=Math.cos(c.roll/2);
  /* q = qyaw * qpitch(x) * qroll(z) */
  const bx=cy*px, by=sy*pw, bz=-sy*px, bw=cy*pw;
  Q.x=bx*rw+by*rz; Q.y=by*rw-bx*rz; Q.z=bw*rz+bz*rw; Q.w=bw*rw-bz*rz;
  c.set.write(c.i,c.x,c.y+.05,c.z,Q,c.sx,c.sy,c.sz,0); c.set.flush(); }
function updateHeroPos(){ const c=cur; hero.position.set(c.x,c.y+1.3,c.z); hero.rotation.y=c.yaw; H.face=c.yaw; H.alt=c.y; H.sp=0; api.x=c.x; api.y=c.y; api.z=c.z; api.yaw=c.yaw; }
function spotFree(x,z,y){ if(!walkable(x,z)) return false; gatherBoxes(x-.65,y+.5,z-.65,x+.65,y+2.4,z+.65);
  for(let k=0;k<bb.length;k+=6) if(!(x+.62<=bb[k]||x-.62>=bb[k+3]||z+.62<=bb[k+2]||z-.62>=bb[k+5])) return false;
  let ok=true; obstacles(x,z,.62,()=>{ ok=false; }); return ok; }
function exitSpot(){ const c=cur, fx=Math.sin(c.yaw), fz=Math.cos(c.yaw), lx=fz, lz=-fx, off=c.w/2+1.05, far=c.l/2+1.3;
  const tries=[[lx,lz,off],[-lx,-lz,off],[fx,fz,far],[-fx,-fz,far],[lx,lz,off+1.5],[-lx,-lz,off+1.5]];
  for(const [dx,dz,m] of tries){ const x=c.x+dx*m, z=c.z+dz*m; if(spotFree(x,z,c.y)) return {x,z}; }
  for(let r=3;r<10;r+=1.4) for(let a=0;a<10;a++){ const an=a/10*TAU, x=c.x+Math.cos(an)*r, z=c.z+Math.sin(an)*r; if(spotFree(x,z,c.y)) return {x,z}; }
  return {x:c.x+lx*off,z:c.z+lz*off}; }
/* arabadan çık; wreck: araba patladı (yanık enkaz olur) */
function leave(wreck){ const c=cur; if(!c) return; const sp=exitSpot(), gy=gAt(sp.x,sp.z,c.y+.8);
  hero.position.set(sp.x,gy+1.26,sp.z); hero.rotation.y=c.yaw; H.face=c.yaw; H.yaw=c.yaw+Math.PI; H.pitch=.18; H.vel.set(0,0,0); H.grounded=true; H.flying=false; H.speed=0; H.hv=0;
  if(Game.resetCamPivot) Game.resetCamPivot();
  c.set.write(c.i,c.x,c.y+.05,c.z,yawQ(c.yaw),c.sx,c.sy,c.sz,0); c.set.flush();
  Cars.drop(c.kind,c.i,c.x,c.y,c.z,c.yaw);
  if(wreck) Cars.wreckIt(c.kind,c.i,c.vx*.4,c.vz*.4); else if(c.hp<c.spec.hp*.3||c.dying) Cars.burn(c.kind,c.i);
  api.active=false; api.car=null; api.speed=0; api.wind=0; cur=null; clearInputs(); hudEl.classList.remove("driving","fast");
  const a=au(); a.engine(false); a.skid(0); a.horn(false); if(!wreck) a.door(); setLight(0); }
function yawQ(a){ Q.x=0; Q.y=Math.sin(a/2); Q.z=0; Q.w=Math.cos(a/2); return Q; }
api.exit=function(force){ if(!cur) return; if(force||cur.dead){ leave(false); return; } cur.exiting=true; };
api.enter=enter;
api.impulse=function(vx,vy,vz){ const c=cur; if(!c) return; c.vx+=vx*.32; c.vz+=vz*.32; if(vy>3){ c.vy+=vy*.3; c.air=true; } hurt(Math.hypot(vx,vz)*.25); shake=Math.max(shake,.5); };
const rh=Game.resetHero; Game.resetHero=function(){ if(api.active) leave(false); rh(); };

/* ---------- far ışığı (yükleme anında eklenir: sonradan ışık eklemek tüm gölgelendiricileri yeniden derletir) ---------- */
const hl=new THREE.SpotLight(0xfff1d6,0,130,.52,.55,1.1); hl.castShadow=false; scene.add(hl); scene.add(hl.target);
let lightI=0; function setLight(v){ lightI=v; hl.intensity=v; }

/* ---------- lastik izleri ---------- */
const SK=150, skGeo=(()=>{ const g=new THREE.BufferGeometry(); g.setAttribute("position",new THREE.BufferAttribute(new Float32Array([-.14,0,-.45,.14,0,-.45,.14,0,.45,-.14,0,.45]),3));
  g.setAttribute("normal",new THREE.BufferAttribute(new Float32Array([0,1,0,0,1,0,0,1,0,0,1,0]),3)); g.setIndex(new THREE.BufferAttribute(new Uint16Array([0,2,1,0,3,2]),1)); return g; })();
const skMesh=new THREE.InstancedMesh(skGeo,new THREE.MeshBasicMaterial({color:0x060606,transparent:true,opacity:.5,depthWrite:false,polygonOffset:true,polygonOffsetFactor:-2,polygonOffsetUnits:-2}),SK);
skMesh.frustumCulled=false; skMesh.renderOrder=2; const skAge=new Float32Array(SK).fill(99), skD=new Float32Array(SK*4); let skI=0, skFade=0;
for(let k=0;k<SK;k++) U.hide(skMesh.instanceMatrix.array,k); skMesh.instanceMatrix.needsUpdate=true; scene.add(skMesh);
function mark(x,y,z,ang){ const k=skI; skI=(skI+1)%SK; skAge[k]=0; skD[k*4]=x; skD[k*4+1]=y; skD[k*4+2]=z; skD[k*4+3]=ang; writeMark(k,1); }
function writeMark(k,s){ const a=skD[k*4+3]; Q.x=0; Q.y=Math.sin(a/2); Q.z=0; Q.w=Math.cos(a/2); U.writeMat(skMesh.instanceMatrix.array,k,skD[k*4],skD[k*4+1],skD[k*4+2],Q,0,0,0,0,0,s,1,1); }
function fadeMarks(dt){ skFade-=dt; if(skFade>0) return; skFade=.3; let any=false; for(let k=0;k<SK;k++){ if(skAge[k]>=99) continue; skAge[k]+=.3; if(skAge[k]>16){ skAge[k]=99; U.hide(skMesh.instanceMatrix.array,k); any=true; continue; } writeMark(k,Math.min(1,(16-skAge[k])/6)); any=true; }
  if(any) skMesh.instanceMatrix.needsUpdate=true; }

/* ---------- fizik ---------- */
function maxSteer(v){ return .62/(1+Math.pow(v/13,1.6))+.06; }
function move(c,h,fx,fz,sgnSpeed){
  const ox=c.x, oz=c.z; c.x+=c.vx*h; c.z+=c.vz*h;
  /* deniz: karadan çıkma */
  const ahx=c.x+fx*c.l*.45, ahz=c.z+fz*c.l*.45;
  if(!walkable(c.x,c.z)||!walkable(ahx,ahz)||!walkable(c.x-fx*c.l*.4,c.z-fz*c.l*.4)){
    const okX=walkable(c.x,oz)&&walkable(c.x+fx*c.l*.45,oz+fz*c.l*.45), okZ=walkable(ox,c.z)&&walkable(ox+fx*c.l*.45,c.z+fz*c.l*.45);
    if(okX){ c.z=oz; c.vz*=-.1; } else if(okZ){ c.x=ox; c.vx*=-.1; } else { c.x=ox; c.z=oz; c.vx*=-.15; c.vz*=-.15; }
    c.vx*=.9; c.vz*=.9; if(seaT<=0){ seaT=3; Game.toast("t_sea"); } }
  const r=c.w*.5+.05, offs=[-c.l*.3,0,c.l*.3];
  for(let ci=0;ci<3;ci++){ let cx=c.x+fx*offs[ci], cz=c.z+fz*offs[ci];
    /* bina parçaları */
    for(let bi=0,k=0;bi<bc.length;bi++,k+=6){ const ch=bc[bi]; if(ch&&!ch.alive) continue;
      const qx=clamp(cx,bb[k],bb[k+3]), qz=clamp(cz,bb[k+2],bb[k+5]), dx=cx-qx, dz=cz-qz, d2=dx*dx+dz*dz; if(d2>=r*r) continue;
      let nx,nz,pen; const d=Math.sqrt(d2);
      if(d>1e-4){ nx=dx/d; nz=dz/d; pen=r-d; } else { const l=cx-bb[k], rr=bb[k+3]-cx, t=cz-bb[k+2], b=bb[k+5]-cz, m=Math.min(l,rr,t,b); if(m===l){ nx=-1; nz=0; } else if(m===rr){ nx=1; nz=0; } else if(m===t){ nx=0; nz=-1; } else { nx=0; nz=1; } pen=m+r; }
      const vn=-(c.vx*nx+c.vz*nz);
      if(ch&&vn>24){ carve(qx,c.y+c.H*.5,qz,3+Math.min(1.8,c.speed*.03),c.vx,c.vz,c.speed); c.vx*=.9; c.vz*=.9; if(c.smD<=0){ c.smD=.14; hurt(vn*.13*c.spec.dk); } if(vn>30) shake=Math.max(shake,.7); continue; }
      c.x+=nx*pen; c.z+=nz*pen; cx+=nx*pen; cz+=nz*pen; if(vn>0){ crash(c,vn,nx,nz,qx,qz,false); } }
    /* ağaç, direk, kaya */
    obstacles(cx,cz,r,(ox,oz,orad,dx,dz,d2,rr)=>{ const d=Math.sqrt(d2)||1e-3, nx=dx/d, nz=dz/d, pen=rr-d; c.x+=nx*pen; c.z+=nz*pen; cx+=nx*pen; cz+=nz*pen; const vn=-(c.vx*nx+c.vz*nz); if(vn>0) crash(c,vn,nx,nz,ox,oz,true); }); } }
function crash(c,vn,nx,nz,px,pz,soft){ const j=vn*(soft?1.15:1.25); c.vx+=nx*j; c.vz+=nz*j; c.vx*=.992; c.vz*=.992;
  if(vn>3.2&&c.t-c.lastCrash>.14){ c.lastCrash=c.t; au().carHit(Math.min(1.5,vn/20)); shake=Math.max(shake,Math.min(.9,vn/36)); FX.spark(px,c.y+.6,pz,Math.min(14,2+vn*.4),Math.min(14,4+vn*.3)); if(vn>11) FX.dust(px,c.y+.5,pz,4,2.2); if(Game.NPC) Game.NPC.noise(px,pz,40); }
  hurt(Math.max(0,vn-6)*c.spec.dk*(soft?.9:1)); }
const hitList=[];
function carVsCars(c,dt){
  const fx=Math.sin(c.yaw), fz=Math.cos(c.yaw), r=c.w*.5+.05, offs=[-c.l*.3,0,c.l*.3], rq=c.l+9; hitList.length=0;
  Cars.query(c.x,c.z,rq,(kind,i)=>{ hitList.push(kind,i); });
  for(let q=0;q<hitList.length;q+=2){ const kind=hitList[q], i=hitList[q+1], key=kind+i; if((c.cool.get(key)||0)>c.t) continue; const s=Cars.state(kind,i); if(s.driven) continue;
    const po=Cars.pos(kind,i), dm=Cars.dimsOf(kind,i), ofx=Math.sin(po.ry), ofz=Math.cos(po.ry), hl=dm.l/2, hw=dm.w/2;
    for(let ci=0;ci<3;ci++){ const cx=c.x+fx*offs[ci], cz=c.z+fz*offs[ci], dx=cx-po.x, dz=cz-po.z, lf=dx*ofx+dz*ofz, ll=dx*ofz-dz*ofx;
      const qf=clamp(lf,-hl,hl), ql=clamp(ll,-hw,hw), df=lf-qf, dl=ll-ql, d2=df*df+dl*dl; if(d2>=r*r) continue;
      let nx,nz,pen; const d=Math.sqrt(d2);
      if(d>1e-4){ nx=df*ofx+dl*ofz; nz=df*ofz-dl*ofx; const l=Math.hypot(nx,nz)||1; nx/=l; nz/=l; pen=r-d; } else { nx=dx; nz=dz; const l=Math.hypot(nx,nz)||1; nx/=l; nz/=l; pen=r; }
      let ovx=0, ovz=0; if(kind==="t"&&!s.dyn){ ovx=ofx*(s.spd||0); ovz=ofz*(s.spd||0); }
      const vn=-((c.vx-ovx)*nx+(c.vz-ovz)*nz);
      c.x+=nx*pen*.6; c.z+=nz*pen*.6;
      if(vn>.4){ c.cool.set(key,c.t+.28); const sp=Math.hypot(c.vx,c.vz);
        Cars.hit(kind,i,c.vx*.8+ovx*.3,2+vn*.12,c.vz*.8+ovz*.3,2+vn*.07,undefined,"crash");
        c.vx+=nx*vn*.5; c.vz+=nz*vn*.5; c.vx*=.9; c.vz*=.9;
        if(vn>2.5){ au().carHit(Math.min(1.5,vn/18)); shake=Math.max(shake,Math.min(.8,vn/36)); FX.spark(po.x,c.y+.7,po.z,Math.min(14,3+vn*.4),Math.min(14,5+vn*.3)); if(vn>9) FX.dust(po.x,c.y+.5,po.z,5,2.4); if(Game.NPC) Game.NPC.noise(po.x,po.z,45); }
        hurt(Math.max(0,vn-4.5)*c.spec.dk*.7); }
      break; } } }
function carVsPeople(c,dt){ const NPC=Game.NPC; if(!NPC||c.speed<2.5) return; const fx=Math.sin(c.yaw), fz=Math.cos(c.yaw), hw=c.w/2+.35, hl=c.l/2+.25, list=NPC.list;
  for(let k=0;k<list.length;k++){ const n=list[k]; if(!n.vis) continue; const st=n.st; if(NPC.passive(st)||n.carHitT>0) continue;
    const dx=n.x-c.x, dz=n.z-c.z; if(dx*dx+dz*dz>50) continue; const lf=dx*fx+dz*fz, ll=dx*fz-dz*fx; if(Math.abs(lf)>hl||Math.abs(ll)>hw||Math.abs((n.y||0)-c.y)>2.6) continue;
    const sp=c.speed, jit=(Math.random()-.5)*3; n.carHitT=.9; NPC.hit(n,c.vx*1.05+fz*jit,3.5+sp*.2,c.vz*1.05-fx*jit,"car",{speed:sp}); if(Game.Ev) Game.Ev.emit("playerRanOver",n,sp); c.vx*=.985; c.vz*=.985; shake=Math.max(shake,.12); if(sp>10) NPC.noise(n.x,n.z,45); } }

function step(dt){ const c=cur, sp=c.spec; c.t+=dt; c.smD-=dt;
  const ex=c.exiting, dead=c.hp<=0;
  const gas=!ex&&!dead&&(inp.gas||keys.w||keys.arrowup), brk=ex||(inp.brake||keys.s||keys.arrowdown), hand=!ex&&(inp.hand||keys[" "]);
  const st=ex?0:((inp.left||keys.a||keys.arrowleft?1:0)-(inp.right||keys.d||keys.arrowright?1:0));
  const sr=(st*c.steer<=0&&st!==0)||Math.abs(st)>Math.abs(c.steer)?7:10; c.steer+=(st-c.steer)*(1-Math.exp(-sr*dt));
  let fx=Math.sin(c.yaw), fz=Math.cos(c.yaw), lx=fz, lz=-fx;
  let vf=c.vx*fx+c.vz*fz, vl=c.vx*lx+c.vz*lz;
  /* boylamasına */
  let acc=0, resist=0, thr=0;
  if(gas){ thr=1; acc=vf>-.4?sp.acc*Math.max(.03,1-Math.pow(Math.max(0,vf)/sp.vmax,2.4)):sp.acc*2.6; c.revLock=false; }
  if(brk){ if(vf>1){ resist+=sp.brk; c.revLock=true; } else if(!c.revLock&&!ex&&!dead){ acc-=sp.acc*.6*Math.max(.08,1-Math.pow(Math.max(0,-vf)/(sp.vmax*.3),2)); thr=.55; } else { resist+=14; } }
  else c.revLock=false;
  if(c.air){ acc=0; resist=0; }
  const sg=vf>=0?1:-1, av=Math.abs(vf);
  resist+=.0016*vf*vf+.45; if(!gas&&!brk) resist+=1.2+av*.03; if(hand&&av>.4) resist+=11;
  acc-=9.8*Math.sin(c.pitch)*.85;
  vf+=acc*dt; { const r=resist*dt; if(Math.abs(vf)<=r) vf=0; else vf-=Math.sign(vf)*r; }
  /* direksiyon */
  const av2=Math.abs(vf), wb=c.l*.6, delta=c.steer*maxSteer(av2);
  let yr=vf*Math.tan(delta)/wb; const aLat=(hand?10:15)/(1+.35*Math.pow(av2/30,1.5)), cap=aLat*Math.min(1,Math.abs(c.steer)*1.15)/Math.max(3.5,av2);
  yr=clamp(yr,-cap,cap); if(hand&&av2>5) yr*=1.45; if(c.air) yr*=.12; yr=clamp(yr,-2.6,2.6);
  c.vx=fx*vf+lx*vl; c.vz=fz*vf+lz*vl; c.yaw+=yr*dt;
  fx=Math.sin(c.yaw); fz=Math.cos(c.yaw); lx=fz; lz=-fx;
  vf=c.vx*fx+c.vz*fz; vl=c.vx*lx+c.vz*lz;
  const grip=c.air?.35:hand?1.25:Math.abs(vf)>26?7.5:11; vl*=Math.exp(-grip*dt);
  c.vx=fx*vf+lx*vl; c.vz=fz*vf+lz*vl; c.vf=vf; c.vl=vl; c.speed=Math.hypot(c.vx,c.vz);
  /* hız sınırı (pist dışı: sıkışma) */
  if(c.speed>sp.vmax*1.25){ const k=sp.vmax*1.25/c.speed; c.vx*=k; c.vz*=k; c.speed=sp.vmax*1.25; }
  /* hareket: alt adımlı çarpışma */
  const dist=c.speed*dt, n=Math.max(1,Math.min(10,Math.ceil(dist/.7))), h=dt/n;
  gatherBoxes(c.x-c.l*.5-3-dist,c.y+.55,c.z-c.l*.5-3-dist,c.x+c.l*.5+3+dist,c.y+c.H-.1,c.z+c.l*.5+3+dist); /* kare gibi geniş kutu */
  for(let i=0;i<n;i++){ move(c,h,Math.sin(c.yaw),Math.cos(c.yaw)); }
  carVsCars(c,dt); carVsPeople(c,dt);
  c.speed=Math.hypot(c.vx,c.vz);
  /* zemin: 4 nokta (yunuslama / yatma) + havalanma */
  fx=Math.sin(c.yaw); fz=Math.cos(c.yaw); lx=fz; lz=-fx; const L2=c.l*.36, W2=c.w*.4, yr0=c.y+.7;
  const gF=gAt(c.x+fx*L2,c.z+fz*L2,yr0), gB=gAt(c.x-fx*L2,c.z-fz*L2,yr0), gL=gAt(c.x+lx*W2,c.z+lz*W2,yr0), gR=gAt(c.x-lx*W2,c.z-lz*W2,yr0), gC=(gF+gB+gL+gR)*.25;
  let tp=Math.atan2(gF-gB,L2*2), tr=Math.atan2(gL-gR,W2*2);
  if(c.air){ c.vy-=Game.P.G0*dt; c.y+=c.vy*dt; tp=clamp(Math.atan2(c.vy,Math.max(4,c.speed))*.8,-.5,.5); tr*=.2; if(c.y<=gC){ const vyN=c.vy; c.y=gC; c.air=false; c.vy=0; if(vyN<-7){ au().thud(c.x,c.y,c.z); FX.dust(c.x,c.y+.2,c.z,Math.min(12,4+-vyN*.5),2.4); shake=Math.max(shake,Math.min(.7,-vyN/28)); hurt(Math.max(0,-vyN-14)*c.spec.dk*1.2); } } }
  else { const dy=gC-c.y; if(dy<-.45&&c.speed>6){ c.air=true; c.vy=Math.max(-2,dy/dt*.2); } else { c.y=gC; } }
  const kk=1-Math.exp(-14*dt); c.pitch+=(clamp(tp,-.6,.6)-c.pitch)*kk; c.roll+=(clamp(tr,-.5,.5)-c.roll)*kk;
  /* kayma: ses / lastik izi / duman */
  const slip=Math.abs(vl), skidding=!c.air&&((slip>2.6)||(hand&&c.speed>7)||(brk&&av2>26&&!c.revLock&&false)); const want=skidding?Math.min(1,.35+slip*.12+(hand?.25:0)):0; c.skid+=(want-c.skid)*(1-Math.exp(-14*dt));
  c.skT-=dt; if(skidding&&c.skT<=0){ c.skT=Math.max(.04,.75/Math.max(8,c.speed)); const ang=Math.atan2(c.vx,c.vz), bx=c.x-fx*c.l*.3, bz=c.z-fz*c.l*.3;
    for(const s of [-1,1]){ const mx=bx+lx*s*c.w*.38, mz=bz+lz*s*c.w*.38; mark(mx,gAt(mx,mz,c.y+.5)+.045,mz,ang); }
    if(Math.random()<.7) FX.dust(bx,c.y+.2,bz,1,1.4,[.78,.78,.8]); }
  if(c.landT>0) c.landT-=dt;
  /* vites / rpm */
  const spd=Math.abs(vf), ng=sp.gear; let g=c.gear, gmax=(gg)=>(gg/ng)*(gg/ng*.5+.5)*sp.vmax*1.04;
  if(vf<-.6){ g=1; } else { while(g<ng&&spd>gmax(g)*.94) g++; while(g>1&&spd<gmax(g-1)*.8) g--; }
  c.gear=g; let rpm=.15+.85*clamp(spd/gmax(g),0,1); if(vf<-.6) rpm=.15+.85*clamp(spd/(sp.vmax*.3),0,1); if(thr>0&&spd<4) rpm=Math.max(rpm,.15+thr*.45*(1-spd/4)+.1);
  if(dead||c.dead) rpm*=.4; c.rpm=rpm; c.rpmS+=(rpm-c.rpmS)*(1-Math.exp(-(rpm>c.rpmS?9:5)*dt)); c.thrS+=((gas?1:brk&&thr?.5:0)-c.thrS)*(1-Math.exp(-8*dt));
  /* hasar: duman / ateş / patlama */
  const f=c.hp/sp.hp; if(f<.55){ c.smokeT-=dt; if(c.smokeT<=0){ c.smokeT=.09+f*.25; FX.smoke(c.x+fx*c.l*.32,c.y+c.H*.62,c.z+fz*c.l*.32,1,.8+(1-f)*.9); } }
  if(f<.3||c.dying){ if(Math.random()<dt*(14+(c.dying?24:0))) FX.fire(c.x+fx*c.l*.32+U.rs()*.8,c.y+c.H*.55,c.z+fz*c.l*.32+U.rs()*.8,1,0,2.5,0,1.5); }
  if(c.dying){ c.dying+=dt; if(c.dying>2.6){ explode(); return; } }
  /* hızlı bitirme: araba durunca in */
  if(ex&&c.speed<1.6){ leave(false); return; }
  /* korna */
  const horn=inp.horn; if(horn){ c.hornT-=dt; if(c.hornT<=0){ c.hornT=.5; if(Game.NPC) Game.NPC.noise(c.x,c.z,34); } }
  /* durum */
  writeCar(); updateHeroPos(); api.speed=c.speed; api.wind=Math.max(0,(c.speed-12)*2.2);
  const a=au(); a.engine(!c.dead,c.rpmS,c.thrS,c.type); a.skid(c.skid,c.speed); a.horn(horn&&c.hp>-5);
}
function camera3(c,dt){ const sp=c.speed, fp=Game.settings.cam==="1p";
  const look=Game.lookActive&&Game.lookActive(); if(look) lookIdle=0; else lookIdle+=dt;
  if(!look){ const want=c.yaw+Math.PI; let d=want-H.yaw; d=Math.atan2(Math.sin(d),Math.cos(d)); const rate=lookIdle>1.3?3.4:(sp>5?1.5:0); if(rate) H.yaw+=d*(1-Math.exp(-rate*dt));
    const pw=fp?.05:.2; if(lookIdle>1.3||sp>5) H.pitch+=(pw-H.pitch)*(1-Math.exp(-2.4*dt)); }
  const cp=Math.cos(H.pitch); lookV.x=-Math.sin(H.yaw)*cp; lookV.y=Math.sin(H.pitch); lookV.z=-Math.cos(H.yaw)*cp;
  const fx=Math.sin(c.yaw), fz=Math.cos(c.yaw);
  if(shake>.01){ shake*=Math.exp(-6*dt); } const shk=(shake+Math.max(0,sp-34)*.0016)*Game.settings.shake;
  if(fp){ const ex=c.x+fx*c.l*.12, ey=c.y+c.H*.82+.12, ez=c.z+fz*c.l*.12; camera.position.set(ex+(Math.random()-.5)*shk*.5,ey+(Math.random()-.5)*shk*.5,ez+(Math.random()-.5)*shk*.5); camera.lookAt(ex+lookV.x*10,ey+lookV.y*10,ez+lookV.z*10); }
  else { const tx=c.x+fx*Math.min(3,sp*.04), ty=c.y+c.H*.62+.7, tz=c.z+fz*Math.min(3,sp*.04);
    if(!camPiv){ camPiv={x:camera.position.x+lookV.x*7,y:camera.position.y+lookV.y*7,z:camera.position.z+lookV.z*7}; }
    const rate=c.t<.9?4+c.t*14:16, kp=1-Math.exp(-rate*dt); camPiv.x+=(tx-camPiv.x)*kp; camPiv.y+=(ty-camPiv.y)*kp; camPiv.z+=(tz-camPiv.z)*kp;
    const lag=1.3+sp*.03; let lx=camPiv.x-tx, ly=camPiv.y-ty, lz=camPiv.z-tz; const l2=lx*lx+ly*ly+lz*lz; if(l2>lag*lag){ const k=lag/Math.sqrt(l2); camPiv.x=tx+lx*k; camPiv.y=ty+ly*k; camPiv.z=tz+lz*k; }
    const want=3.4+c.l*.78+Math.min(5,sp*.07); camDist=camDist<0?want:camDist+(want-camDist)*(1-Math.exp(-3*dt));
    let px=camPiv.x-lookV.x*camDist, py=camPiv.y-lookV.y*camDist, pz=camPiv.z-lookV.z*camDist;
    const bx=px-tx, by=py-ty, bz=pz-tz, Ln=Math.hypot(bx,by,bz)||1; D.rayB(tx,ty,tz,bx/Ln,by/Ln,bz/Ln,Ln,rbuf);
    if(rbuf.kind!=="none"&&rbuf.t<Ln){ const L2=Math.max(1.4,rbuf.t-.5); px=tx+bx/Ln*L2; py=ty+by/Ln*L2; pz=tz+bz/Ln*L2; }
    const gy=gAt(px,pz,py)+1; if(py<gy) py=gy;
    const kc=c.t<.9?1-Math.exp(-(5+c.t*30)*dt):1; if(c.t<.9){ camera.position.x+=(px-camera.position.x)*kc; camera.position.y+=(py-camera.position.y)*kc; camera.position.z+=(pz-camera.position.z)*kc; } else camera.position.set(px,py,pz);
    if(shk>.01){ camera.position.x+=(Math.random()-.5)*shk; camera.position.y+=(Math.random()-.5)*shk; camera.position.z+=(Math.random()-.5)*shk; }
    camera.lookAt(tx,ty,tz); }
  const fovT=Game.settings.fovAdd+(fp?78:68)+Math.min(18,sp*.34); camera.fov+=(fovT-camera.fov)*(1-Math.exp(-4*dt)); camera.near=.1; camera.far=6000; camera.updateProjectionMatrix(); }
const rbuf={};

/* ---------- ana döngü ---------- */
Game.updaters.push((dt0,time,raw)=>{
  if(Game.mode!=="play"){ if(api.active||inp.gas||inp.brake) clearInputs(); return; }
  const dt=Math.min(.05,raw||dt0||.016); seaT-=dt; smashT-=dt; fadeMarks(dt);
  /* far */
  { const nt=Game.night||0, want=api.active?Math.max(0,(nt-.2)*3.2):0; lightI+=(want-lightI)*(1-Math.exp(-6*dt)); hl.intensity=lightI<.02?0:lightI;
    if(api.active&&cur&&hl.intensity>0){ const c=cur, fx=Math.sin(c.yaw), fz=Math.cos(c.yaw); hl.position.set(c.x+fx*c.l*.45,c.y+.85,c.z+fz*c.l*.45); hl.target.position.set(c.x+fx*30,c.y-.4,c.z+fz*30); } }
  if(api.active&&cur){ if(!hudEl.classList.contains("driving")) hudEl.classList.add("driving"); step(dt); if(!cur) return; camera3(cur,dt);
    hudEl.classList.toggle("fast",cur.speed>38);
    hudT-=dt; if(hudT<=0){ hudT=.09; spdEl.textContent=Math.round(Math.abs(cur.vf)*(Game.settings.mph?2.237:3.6)); gearEl.textContent=cur.vf<-.6?"R":(Math.abs(cur.vf)<.5&&cur.thrS<.2)?"N":String(cur.gear); rpmEl.style.width=Math.round(clamp(cur.rpmS,0,1)*100)+"%"; }
    return; }
  /* yakındaki araba: BİN düğmesi */
  nearT-=dt; if(nearT>0) return; nearT=.12; if(Game.Ride&&Game.Ride.active){ api.near=null; return; } const p=hero.position; let best=null, bd=1e9;
  if(p.y-gAt(p.x,p.z,p.y)<7){ Cars.query(p.x,p.z,5.8,(kind,i,px,pz,d)=>{ const s=Cars.state(kind,i); if(s.wreck||s.burnT||s.frozen||s.driven||Cars.busy(kind,i)) return; if(d<bd){ bd=d; best={kind,i}; } }); }
  const prev=api.near; api.near=best; if(!!prev!==!!best||(best&&prev&&(best.i!==prev.i||best.kind!==prev.kind))){ btnEnter.classList.toggle("on",!!best); if(best){ const T=KIT.TYPES[best.kind==="t"?Cars.state("t",best.i).type:Cars.state("p",best.i).t]; nameEl.textContent=T?t(T.name):""; } } });
Game.onLang3=()=>{ if(api.near&&nameEl){ const s=Cars.state(api.near.kind,api.near.i), T=KIT.TYPES[api.near.kind==="t"?s.type:s.t]; nameEl.textContent=T?t(T.name):""; } };
return api;
})();
