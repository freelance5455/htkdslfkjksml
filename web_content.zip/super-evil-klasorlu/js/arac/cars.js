"use strict";
/* ===== ARABALAR: savrulma, yanma, patlama, donma; yere düşen enkaz, etkileşim ve zamanla yok olma ===== */
Game.Cars = (function(){
  const R=Game.carRefs, U=Game.U, P=Game.P, FX=Game.FX, W=Game.W, {cars,traffic}=R, col=new THREE.Color();
  const dyn=[], dm=new Map(), MAXDYN=18, LIFE=26, FADE=1.4, RESPAWN=40, ICE=[.55,.8,1], CHAR=[.04,.04,.045];
  const KIT=Game.CarKit, wr=new Set(), gone=[], PQ=new THREE.Quaternion();
  traffic.forEach(t=>{ t.spd0=t.spd; });
  const toLin=h=>new THREE.Color(h).convertSRGBToLinear();
  function setOf(kind){ return kind==="t"?R.trafficSet:R.parkedSet; }
  function dims(kind,i){ const s=kind==="t"?traffic[i]:cars[i], sc=s.sc, T=KIT.TYPES[kind==="t"?s.type:s.t]; return {w:sc.sx*T.W,l:sc.sz*T.L,H:sc.H,sx:sc.sx,sy:sc.sy,sz:sc.sz,set:setOf(kind)}; }
  function pose(kind,i){ const e=dm.size?dm.get(kind+i):null; if(e&&e.body){ const b=e.body, q=b.quaternion; return {x:b.position.x,z:b.position.z,ry:Math.atan2(2*(q.x*q.z+q.w*q.y),1-2*(q.x*q.x+q.y*q.y)),y:b.position.y-e.d.H/2}; }
  if(kind==="t"){ const t=traffic[i]; return {x:t.cx||0,z:t.cz||0,ry:t.ry||0,y:t.cy||0}; } const c=cars[i]; return {x:c.x,z:c.z,ry:c.ry!==undefined?c.ry:(c.v?0:Math.PI/2)+(c.flip?Math.PI:0),y:c.py||0}; }
  function write(e,sink){ const b=e.body, d=e.d, q=b.quaternion, p=b.position; d.set.write(e.i,p.x,p.y-(sink||0),p.z,q,d.sx,d.sy,d.sz,-d.H/2); d.set.flush(); }
  function find(kind,i){ return dm.get(kind+i)||null; }
  function state(kind,i){ return kind==="t"?traffic[i]:cars[i]; }
  function origin(kind,i){ const s=state(kind,i); if(kind==="p"&&!s.o) s.o={x:s.x,z:s.z,ry:s.ry!==undefined?s.ry:(s.v?0:Math.PI/2)+(s.flip?Math.PI:0)}; }
  /* gövdenin son durumunu (konum, yönelim, yükseklik) araba durumuna işle: bırakılan araba tam durduğu yerde, eğik haliyle kalır */
  function keepState(e){ const b=e.body, s=state(e.kind,e.i), po=pose(e.kind,e.i), q=b.quaternion; s.q=[q.x,q.y,q.z,q.w]; s.by=b.position.y;
    if(e.kind==="t"){ s.cx=po.x; s.cz=po.z; s.cy=po.y; s.ry=po.ry; } else { s.x=po.x; s.z=po.z; s.py=po.y; s.ry=po.ry; } }
  function retire(e){ if(!e.body) return; keepState(e); P.removeBody(e.body); const k=dyn.indexOf(e); if(k>=0) dyn.splice(k,1); dm.delete(e.kind+e.i); e.body=null; }
  function setColor(kind,i,rgb){ setOf(kind).color(i,rgb); }
  /* araba tamamen kalkar (dibe batıp yok olur); bir süre sonra uzakta yeniden belirir */
  function vanish(kind,i,e){ const s=state(kind,i), d=dims(kind,i); if(e&&e.body){ const p=e.body.position; FX.dust(p.x,p.y,p.z,6,2,[.4,.4,.4]); P.removeBody(e.body); const k=dyn.indexOf(e); if(k>=0) dyn.splice(k,1); dm.delete(kind+i); e.body=null; }
    s.gone=true; s.dyn=true; s.wreck=true; s.burnT=0; wr.delete(kind+i); d.set.write(i,0,-40,0,PQ.set(0,0,0,1),0,0,0,0); d.set.flush(); gone.push({kind,i,t:0}); }
  function respawn(g){ const s=state(g.kind,g.i), hp=Game.heroObj?Game.heroObj.position:{x:0,z:0};
    if(g.kind==="t"&&s.role){ s.spd=s.spd0; s.dyn=false; s.wreck=false; s.gone=true; s.paid=false; s.dmg=0; s.dm1=0; s.burnT=0; s.frozen=false; s.charred=false; s.q=null; s.by=undefined; s.cy=0; s.wt=0; s.siren=0; s.off=0; s.hold=false; s.stopAt=null; s.mission=null; s.busy=false; s.driven=false; setColor("t",g.i,toLin(s.col)); return true; }
    if(g.kind==="t"){ let ok=false; for(let k=0;k<8&&!ok;k++){ const pos=s.lo+Math.random()*(s.hi-s.lo), x=s.axis===0?s.line-s.dir*1.9:pos, z=s.axis===0?pos:s.line+s.dir*1.9; if(Math.hypot(x-hp.x,z-hp.z)>110){ s.pos=pos; ok=true; } } if(!ok) return false;
      s.spd=s.spd0; s.dyn=false; s.wreck=false; s.gone=false; s.paid=false; s.dmg=0; s.dm1=0; s.burnT=0; s.frozen=false; s.charred=false; s.q=null; s.by=undefined; s.cy=0; s.wt=0; setColor("t",g.i,toLin(s.col)); return true; }
    const o=s.o; if(!o){ s.gone=false; return true; } if(Math.hypot(o.x-hp.x,o.z-hp.z)<110) return false;
    s.x=o.x; s.z=o.z; s.ry=o.ry; s.py=0; s.dyn=false; s.wreck=false; s.gone=false; s.paid=false; s.dmg=0; s.dm1=0; s.burnT=0; s.frozen=false; s.charred=false; s.q=null; s.by=undefined; s.wt=0;
    PQ.setFromAxisAngle({x:0,y:1,z:0},o.ry); const d=dims("p",g.i); d.set.write(g.i,o.x,.08,o.z,PQ,d.sx,d.sy,d.sz,0); d.set.flush(); setColor("p",g.i,toLin(s.col)); return true; }
  /* kalıcı enkaz: üstteki parça zamanla dibe gömülür */
  function writeStatic(kind,i,k){ const s=state(kind,i), d=dims(kind,i); if(!s.q) return; PQ.set(s.q[0],s.q[1],s.q[2],s.q[3]); const x=kind==="t"?s.cx:s.x, z=kind==="t"?s.cz:s.z; d.set.write(i,x,s.by-k*d.H*1.2,z,PQ,d.sx,d.sy,d.sz,-d.H/2); d.set.flush(); }
  function activate(kind,i){ let e=find(kind,i); if(e) return e; const s=state(kind,i); if(s.driven||s.gone) return null; origin(kind,i);
    if(dyn.length>=MAXDYN){ /* önce yerde duran en eski enkazı kalıcı yap; hiçbiri yoksa en eskiyi en yakın zemine indir */
      let v=null; for(const x of dyn){ if(x.rest>1&&x.sup!==0&&!x.held){ v=x; break; } } const dmgd=x=>{ const q=state(x.kind,x.i); return (q.dmg||0)>=1||q.burnT||q.charred; };
      if(!v){ v=dyn.find(x=>!x.held)||dyn[0]; const p=v.body.position, g=W.surfaceAt(p.x,p.z,p.y); p.y=g+v.d.H/2+.05; v.body.velocity.set(0,0,0); v.body.angularVelocity.set(0,0,0); v.body.quaternion.setFromAxisAngle(new P.CN.Vec3(0,1,0),pose(v.kind,v.i).ry); write(v); if(dmgd(v)){ state(v.kind,v.i).wreck=true; state(v.kind,v.i).wt=0; wr.add(v.kind+v.i); } }
      else if(dmgd(v)){ const sv=state(v.kind,v.i); sv.wreck=true; sv.wt=sv.wt||0; wr.add(v.kind+v.i); } retire(v); }
    const d=dims(kind,i), po=pose(kind,i), cy=s.by!==undefined&&s.q?s.by:po.y+.15+d.H/2, b=P.addBody([d.w/2,d.H/2,d.l/2],1100,po.x,cy,po.z,P.G_CAR,P.G_STATIC|P.G_DEBRIS|P.G_NPC|P.G_CAR);
    if(s.q) b.quaternion.set(s.q[0],s.q[1],s.q[2],s.q[3]); else b.quaternion.setFromAxisAngle(new P.CN.Vec3(0,1,0),po.ry); b.linearDamping=.08; b.angularDamping=.35;
    s.dyn=true; if(kind==="t") s.spd=0; wr.delete(kind+i); e={kind,i,body:b,d,age:0,rest:0,fire:0,boom:0,sc:.2,air:0,sup:1}; dyn.push(e); dm.set(kind+i,e); return e; }
  /* hasar: %45 üstü kararır, 1'e ulaşınca "kırık" sayılır (coin olayı bir kez) */
  function markBroken(kind,i){ const s=state(kind,i); if(s.paid) return; s.paid=true; const po=pose(kind,i); Game.Ev.emit("carDestroyed",kind,i,po.x,po.z); }
  function paintDmg(kind,i){ const s=state(kind,i); if(s.dm1) return; s.dm1=1; const c=toLin(s.col); setColor(kind,i,[c.r*.5,c.g*.5,c.b*.5]); }
  const api={
    hit(kind,i,vx,vy,vz,spin,dmg,mode){ const s=state(kind,i); if(s.gone) return;
      const dvR=[vx,vy,vz]; { const sp=Math.min(80,Math.hypot(vx,vy,vz)); { const R=Game.Real.car(mode||(spin>=6?"boom":"def"),vx,vy,vz); vx=R[0]; vy=R[1]; vz=R[2]; } if(dmg===undefined) dmg=sp>=22?(sp-18)*.03:0; if(s.armor&&dmg>0) dmg*=s.armor; if(dmg>0&&!s.driven){ s.dmg=(s.dmg||0)+dmg; if(s.dmg>=1) markBroken(kind,i); } } if(s.driven){ if(Game.Drive){ const R2=Game.Real.car("throw",dvR[0],dvR[1],dvR[2]); Game.Drive.impulse(R2[0],R2[1],R2[2]); } return; } if(s.frozen){ const po=pose(kind,i); FX.ice(po.x,1,po.z,26,6); s.frozen=false; setColor(kind,i,[1,1,1]); }
      const e=activate(kind,i); if(!e) return; const b=e.body; b.velocity.set(vx,vy,vz); Game.Real.tumble(b,vx,vz,Math.min(3,.5+Math.hypot(vx,vz)*.1+(spin>=6?.8:0)),.5); e.rest=0; e.air=0; P.ghost(b,false); if(s.wreck) s.wt=0; },
    burn(kind,i){ const s=state(kind,i); if(s.driven||s.gone||s.charred) return; if(!s.burnT){ s.burnT=.01; setColor(kind,i,[.35,.25,.2]); if(kind==="t") s.spd=0; } },
    freeze(kind,i){ const s=state(kind,i); if(s.driven||s.gone||s.frozen||s.burnT) return; s.frozen=true; if(kind==="t") s.spd=0; setColor(kind,i,ICE); },
    /* küre içindeki her arabaya fn(kind,i,x,z,dist) */
    query(x,z,r,fn){ const r2=r*r;
      for(let i=0;i<traffic.length;i++){ const t=traffic[i]; if(t.driven||t.gone) continue; let px=t.cx===undefined?1e9:t.cx, pz=t.cz||0; if(dm.size){ const e=dm.get("t"+i); if(e){ px=e.body.position.x; pz=e.body.position.z; } } const dx=px-x,dz=pz-z; if(dx*dx+dz*dz<r2) fn("t",i,px,pz,Math.sqrt(dx*dx+dz*dz)); }
      for(let i=0;i<cars.length;i++){ const c=cars[i]; if(c.driven||c.gone) continue; let px=c.x, pz=c.z; if(dm.size){ const e=dm.get("p"+i); if(e){ px=e.body.position.x; pz=e.body.position.z; } } const dx=px-x,dz=pz-z; if(dx*dx+dz*dz<r2) fn("p",i,px,pz,Math.sqrt(dx*dx+dz*dz)); } },
    pos(kind,i){ return pose(kind,i); },
    /* sürüş: arabayı fizik gövdesinden çıkarıp oyuncuya verir; bırakılınca yeni yerinde park kalır */
    take(kind,i){ const s=state(kind,i); if(!s||s.driven||s.wreck||s.gone) return null; origin(kind,i); const e=find(kind,i); if(e) retire(e); const d=dims(kind,i), po=pose(kind,i);
      let sp=0; if(kind==="t"&&!s.dyn) sp=(s.spd||0)*(s.dir||1); const T=KIT.TYPES[kind==="t"?s.type:s.t];
      s.q=null; s.by=undefined; s.driven=true; s.dyn=true; if(kind==="t") s.spd=0; return {kind,i,d,po,type:kind==="t"?s.type:s.t,T,sp,col:s.col,burnT:s.burnT||0}; },
    drop(kind,i,x,y,z,ry){ const s=state(kind,i); if(!s) return; s.driven=false; s.q=null; s.by=undefined; if(kind==="t"){ s.cx=x; s.cz=z; s.cy=y; s.ry=ry; s.dyn=true; s.spd=0; } else { s.x=x; s.z=z; s.py=y; s.ry=ry; } },
    wreckIt(kind,i,vx,vz){ const s=state(kind,i); s.driven=false; s.dmg=2; markBroken(kind,i); const e=activate(kind,i); s.wreck=true; s.charred=true; s.wt=0; setColor(kind,i,CHAR); if(e){ e.body.velocity.set(vx||0,9,vz||0); e.body.angularVelocity.set(U.rs()*4,U.rs()*2,U.rs()*4); } },
    /* elle kaldırma: araba fizik gövdesine alınır, çarpışması kapatılır; Lift her kare put() ile konumlar, bırakılınca letgo() */
    hold(kind,i){ const s=state(kind,i); if(!s||s.gone||s.driven) return null; const e=activate(kind,i); if(!e||!e.body) return null; e.held=true; e.rest=0; s.wreck=false; s.wt=0; wr.delete(kind+i); P.ghost(e.body,false); e.body.collisionFilterMask=0; e.body.velocity.set(0,0,0); e.body.angularVelocity.set(0,0,0); return e; },
    put(e,x,y,z,qx,qy,qz,qw){ const b=e.body; if(!b) return; b.position.set(x,y,z); b.quaternion.set(qx,qy,qz,qw); b.velocity.set(0,0,0); b.angularVelocity.set(0,0,0); write(e,0); },
    letgo(e){ if(!e||!e.body) return; e.held=false; e.rest=0; e.sc=.3; e.air=0; e.body.collisionFilterMask=P.G_STATIC|P.G_DEBRIS|P.G_NPC|P.G_CAR; if(e.body.wakeUp) e.body.wakeUp(); },
    body(kind,i){ const e=dm.get(kind+i); return e?e.body:null; },
    vanish(kind,i){ vanish(kind,i,find(kind,i)); },
    busy(kind,i){ return !!find(kind,i); },
    state(kind,i){ return state(kind,i); }, set(kind){ return setOf(kind); }, dimsOf(kind,i){ return dims(kind,i); }, debug:{dyn,wr,gone}
  };
  const burning=[];
  Game.updaters.push(dt=>{
    for(let k=dyn.length-1;k>=0;k--){ const e=dyn[k], b=e.body; if(!b) continue; e.age+=dt; const s=state(e.kind,e.i);
      if(e.held){ e.rest=0; e.age=0; e.pv=undefined; s.wreck=false; s.wt=0; if(!isFinite(b.position.x)){ vanish(e.kind,e.i,e); } continue; }
      if(!isFinite(b.position.x)||b.position.y<-10||b.sunk){ vanish(e.kind,e.i,e); continue; }
      const sp=b.velocity.length(); if(sp<.5) e.rest+=dt; else e.rest=0;
      if(e.pv!==undefined&&e.age>.15){ const ds=e.pv-sp; if(ds>14){ s.dmg=(s.dmg||0)+(ds-14)*.045*(s.armor||1); if(s.dmg>.45) paintDmg(e.kind,e.i); if(s.dmg>=1){ markBroken(e.kind,e.i); } FX.spark(b.position.x,b.position.y,b.position.z,Math.min(14,4+ds*.4),10); if(Game.audio&&Game.audio.carHit) Game.audio.carHit(Math.min(1.4,ds/22),b.position.x,b.position.y,b.position.z); } } e.pv=sp;
      /* destek denetimi: görünmez bina kutusunda/boşlukta asılı kalanı düşür */
      e.sc-=dt; if(e.sc<=0){ e.sc=.3; e.sup=sp<4?P.support(b):1; if(e.sup===0&&sp<4){ if(++e.air>=2) P.ghost(b,true); } else e.air=0; if(b.ghost&&e.sup===1&&!P.insideStatic(b)) P.ghost(b,false); }
      if(!s.wreck&&(e.rest>2.5||e.age>40)){ if((s.dmg||0)>=1||s.burnT||s.charred){ s.wreck=true; s.wt=0; } else if(e.rest>2.5&&e.sup===1&&!b.ghost){ retire(e); continue; } }
      let sink=0; if(s.wreck){ s.wt+=dt; if(s.wt>LIFE){ const f=(s.wt-LIFE)/FADE; if(f>=1){ vanish(e.kind,e.i,e); continue; } sink=f*e.d.H*1.2; } }
      write(e,sink);
      if(sp>5&&!e.held&&Game.NPC){ const NP=Game.NPC, px=b.position.x, pz=b.position.z, hl=e.d.l*.5+.4, hw=e.d.w*.5+.4, R2=(hl+1.5)*(hl+1.5); for(const n of NP.list){ if(!n.vis||NP.passive(n.st)||n.carHitT>0) continue; const dx=n.x-px, dz=n.z-pz; if(dx*dx+dz*dz>R2||Math.abs(n.y-(b.position.y-e.d.H/2))>3.2) continue; const v=b.velocity, vl=Math.hypot(v.x,v.z)||1; const al=(dx*v.x+dz*v.z)/vl, lat=(dx*v.z-dz*v.x)/vl; if(Math.abs(al)>hl||Math.abs(lat)>hw) continue; n.carHitT=.9; NP.hit(n,v.x*.9+(lat>0?1:-1)*2,3+sp*.14,v.z*.9-(lat>0?1:-1)*2,"car",{speed:sp}); } }
      /* yerde (arazi/köprü) duran enkaz kalıcı hale gelir ve fizik gövdesi boşaltılır; yine de çarpılırsa uyanır */
      if(s.wreck&&e.rest>2.5&&e.sup===1&&!b.ghost&&!s.burnT&&dyn.length>6){ wr.add(e.kind+e.i); retire(e); } }
    for(const key of wr){ const kind=key[0], i=+key.slice(1), s=state(kind,i); if(!s.wreck||dm.has(key)){ wr.delete(key); continue; } s.wt+=dt; if(s.wt>LIFE){ const f=(s.wt-LIFE)/FADE; if(f>=1){ vanish(kind,i,null); continue; } writeStatic(kind,i,f); } }
    for(let k=gone.length-1;k>=0;k--){ const g=gone[k]; g.t+=dt; if(g.t>RESPAWN&&respawn(g)) gone.splice(k,1); }
    // yanan/patlayan arabalar
    for(const [kind,arr] of [["t",traffic],["p",cars]]) for(let i=0;i<arr.length;i++){ const s=arr[i]; if(!s.burnT||s.gone) continue;
      const po=e_pos(kind,i,s); s.burnT+=dt; if(Math.random()<dt*22) FX.fire(po.x+U.rs()*1.4,po.y+.8,po.z+U.rs()*2,1,0,3,0,2); if(Math.random()<dt*10) FX.smoke(po.x,po.y+1.4,po.z,1,1.2);
      if(s.burnT>6){ s.burnT=0; const e=activate(kind,i); s.wreck=true; s.charred=true; s.dmg=2; markBroken(kind,i); s.wt=0; setColor(kind,i,CHAR); FX.fire(po.x,po.y+1,po.z,40,0,6,0,3); FX.spark(po.x,po.y+1,po.z,30,18); FX.dust(po.x,po.y+1,po.z,16,3,[.3,.3,.3]);
        if(Game.audio) Game.audio.boom(po.x,po.y,po.z); if(e){ e.body.velocity.set(U.rs()*5,12,U.rs()*5); e.body.angularVelocity.set(U.rs()*5,U.rs()*3,U.rs()*5); }
        Game.D.damageSphere(po.x,po.y+1,po.z,7,.8,12); Game.radial&&Game.radial(po.x,po.y+1,po.z,9,16,"boom"); } } });
  function e_pos(kind,i,s){ const e=find(kind,i); if(e) return e.body.position; const po=pose(kind,i); return {x:po.x,y:(s.by!==undefined?s.by-.6:.35),z:po.z}; }
  return api;
})();
