"use strict";
/* ===== UÇAK / HELİKOPTER / GEMİ / JET SKİ SÜRME: deniz-hava trafiğindeki araçlara BİN, arcade uçuş + denizcilik fiziği, çarpışma, kamera, HUD ===== */
Game.Ride=(function(){
const W=Game.W, FX=Game.FX, D=Game.D, H=Game.H, hero=Game.heroObj, Sea=Game.Sea, au=()=>Game.audio, WY=W.WATER_Y;
const api={active:false,x:0,y:0,z:0,speed:0,yaw:0,wind:0,e:null,near:null,kind:null,mode:null};
const hudEl=$("hud"), btnEnter=$("enterBtn"), nameEl=$("enterName"), btnExit=$("rideExit");
const clamp=(v,a,b)=>v<a?a:v>b?b:v, TAU=Math.PI*2, rs=()=>Math.random()-.5, R=(a,b)=>a+Math.random()*(b-a);
const aDiff=(a,b)=>{ let d=a-b; while(d>Math.PI) d-=TAU; while(d<-Math.PI) d+=TAU; return d; };
/* m: s gemi, j jet ski, p uçak, h helikopter. vmax m/s, acc ivme, dec fren, turn dönüş hızı (rad/s), hp can, eng: ses tipi (audio.js KF) */
const SPEC={
  cargo:  {m:"s",vmax:21,acc:1.7,dec:3.2,turn:.2, hp:480,rev:.25,eng:20,vib:.4},
  tanker: {m:"s",vmax:19,acc:1.4,dec:3,  turn:.16,hp:520,rev:.2, eng:20,vib:.4},
  ferry:  {m:"s",vmax:25,acc:2.6,dec:4,  turn:.3, hp:380,rev:.3, eng:20,vib:.5},
  yacht:  {m:"s",vmax:30,acc:4.4,dec:6,  turn:.55,hp:240,rev:.35,eng:20,vib:.6},
  fishing:{m:"s",vmax:16,acc:2.6,dec:4,  turn:.5, hp:200,rev:.4, eng:20,vib:.6},
  sail:   {m:"s",vmax:15,acc:2.2,dec:3,  turn:.45,hp:170,rev:.3, eng:20,vib:.4},
  jetski: {m:"j",vmax:40,acc:12, dec:12, turn:1.5,hp:110,rev:.2, eng:24,vib:1},
  airliner:{m:"p",vmax:110,vs:44,acc:15,turn:.55,pr:.5, bmax:.6, boost:1.15,hp:360,eng:22,ceil:1300},
  prop:   {m:"p",vmax:72, vs:26,acc:11,turn:.95,pr:.85,bmax:.85,boost:1.2, hp:170,eng:21,ceil:1300},
  fighter:{m:"p",vmax:170,vs:48,acc:30,turn:1.15,pr:1.05,bmax:1.3,boost:1.45,hp:210,eng:23,ceil:1400},
  heli:   {m:"h",vmax:46, acc:12,turn:1.4,climb:17,hp:170,eng:25,ceil:900}
};
const inp={left:false,right:false,up:false,down:false,fast:false,slow:false,boost:false}, keys={}; api.inp=inp;
let cur=null, nearT=0, hudT=0, camPiv=null, camDist=-1, lookIdle=9, shake=0, grndMsg=0;
const lookV={x:0,y:0,z:0}, rbuf={};

/* ---------- girdi ---------- */
document.querySelectorAll(".rbtn").forEach(b=>{ const k=b.dataset.rd; if(!k) return;
  const on=e=>{ e.preventDefault(); e.stopPropagation(); inp[k]=true; b.classList.add("down"); };
  const off=e=>{ e.preventDefault(); inp[k]=false; b.classList.remove("down"); };
  b.addEventListener("touchstart",on,{passive:false}); b.addEventListener("touchend",off,{passive:false}); b.addEventListener("touchcancel",off,{passive:false});
  b.addEventListener("mousedown",on); b.addEventListener("mouseup",off); b.addEventListener("mouseleave",off); });
function clearInputs(){ for(const k in inp) inp[k]=false; document.querySelectorAll(".rbtn.down").forEach(b=>b.classList.remove("down")); }
addEventListener("keydown",e=>{ const k=e.key.toLowerCase(); keys[k]=true; if(Game.mode!=="play") return;
  if(k==="e"||k==="f"){ if(api.active) api.exit(false); else if(api.near&&!(Game.Drive&&(Game.Drive.active||Game.Drive.near))) board(api.near); }
  if(api.active&&(k===" "||k.startsWith("arrow"))) e.preventDefault(); });
addEventListener("keyup",e=>{ keys[e.key.toLowerCase()]=false; });
const tapBtn=(el,fn)=>{ if(!el) return; let last=0; const h=e=>{ e.preventDefault(); e.stopPropagation(); const n=performance.now(); if(n-last<350) return; last=n; fn(); };
  el.addEventListener("touchstart",h,{passive:false}); el.addEventListener("mousedown",h); };
tapBtn(btnEnter,()=>{ if(api.near&&!api.active&&Game.mode==="play"&&!(Game.Drive&&(Game.Drive.active||Game.Drive.near))){ au().click(); board(api.near); } });
tapBtn(btnExit,()=>{ if(api.active){ au().click(); api.exit(false); } });

/* ---------- yer / engel yardımcıları ---------- */
const gAt=(x,z,y)=>W.surfaceAt(x,z,y);
const deckAt=(x,z)=>{ const f=W.bridge&&W.bridge.deckAt; if(!f) return null; const d=f(x,z); return d===undefined?null:d; };
function groundMax(r,K){ const d=K.d, fx=Math.sin(r.yaw), fz=Math.cos(r.yaw), lx=fz, lz=-fx, L=d[3]*.7, Wd=d[0]*.8; let g=gAt(r.x,r.z,r.y+2);
  for(let i=0;i<4;i++){ const a=i<2?(i?-1:1):0, b=i>=2?(i===3?-1:1):0, h=gAt(r.x+fx*L*a+lx*Wd*b,r.z+fz*L*a+lz*Wd*b,r.y+2); if(h>g) g=h; } return g; }
const isWet=(x,z)=>W.terrainH(x,z)<WY-.05&&deckAt(x,z)===null;
/* gemi: sığ / kara / köprü kirişi */
function shipBlocked(x,z,K,yaw){ const d=K.d, fx=Math.sin(yaw), fz=Math.cos(yaw), lx=fz, lz=-fx, L=d[3]*.82, Wd=d[0]*.7, draft=Math.max(.6,d[2]*.5);
  for(let i=0;i<5;i++){ const a=i===0?1:i===1?-1:0, b=i===2?1:i===3?-1:0, px=x+fx*L*a+lx*Wd*b, pz=z+fz*L*a+lz*Wd*b;
    if(W.terrainH(px,pz)>WY-draft) return true; const dk=deckAt(px,pz); if(dk!==null&&WY+K.d[1]>dk-.4) return true; }
  const bx=Game.gatherBoxes(x-d[0]-1,WY-.5,z-d[3]-1,x+d[0]+1,WY+Math.min(5,d[1]),z+d[3]+1);
  for(let k=0;k<bx.length;k+=6){ for(let i=0;i<5;i++){ const a=i===0?1:i===1?-1:0, b=i===2?1:i===3?-1:0, px=x+fx*L*a+lx*Wd*b, pz=z+fz*L*a+lz*Wd*b; if(px>bx[k]-.6&&px<bx[k+3]+.6&&pz>bx[k+2]-.6&&pz<bx[k+5]+.6) return true; } }
  return false; }

/* ---------- bin ---------- */
const canBoard=e=>e.st==="cruise"&&!e.pol&&!e.used&&!e.dead&&!e.frozen&&SPEC[e.kind]&&(!e.ctl||e.RA)&&e.g.visible;
function board(e){ if(api.active||Game.mode!=="play"||!e||!canBoard(e)) return; const sp=SPEC[e.kind], K=e.K;
  if(Game.dropHeld) Game.dropHeld();
  const air=sp.m==="p"||sp.m==="h", spd0=e.RA?e.RA.spd:(e.spd||0);
  cur={e,k:e.kind,sp,K,x:e.x,y:e.y,z:e.z,yaw:e.yaw,pitch:0,bank:0,pit:isFinite(e.pit)?e.pit:0,rol:isFinite(e.rol)?e.rol:0,/* pit/rol başlatılmazsa gemi/jet ski'de NaN → matris bozulur, binince araç görünmez olurdu */spd:air?Math.max(spd0,sp.m==="p"?sp.vs*1.15:0):Math.max(0,spd0),vy:0,yr:0,thr:0,boost:0,ground:false,t:0,hp:sp.hp,hp0:sp.hp,cool:new Map(),vx:0,vz:0,hitT:0,burnT:0,keepHp:e.hp};
  if(sp.m==="p") cur.thr=clamp(cur.spd/sp.vmax,0,1);
  if(sp.m==="p"){ const gy=groundMax(cur,K); if(cur.y-K.d[2]<=gy+.6&&cur.spd<sp.vs*.9) cur.ground=true; }
  if(sp.m==="h"){ const gy=groundMax(cur,K); if(cur.y-K.d[2]<=gy+.6) cur.ground=true; }
  e.RA=null; e.ctl=ctlRide; e.hp=9999; e.ox=e.oz=0; e.yr=0; e.swa=0; e.burning=false;
  api.active=true; api.e=e; api.kind=e.kind; api.mode=sp.m; api.near=null; clearInputs();
  H.flying=false; H.vel.set(0,0,0); H.yaw=cur.yaw+Math.PI; H.pitch=-.1; camPiv=null; camDist=-1; lookIdle=9; shake=0;
  hudEl.classList.add("driving","riding"); hudEl.dataset.rc=sp.m; btnEnter.classList.remove("on");
  const nm=$("rName"); if(nm) nm.textContent=t("sv_"+e.kind);
  au().door&&au().door(); setTimeout(()=>{ if(cur&&au().engineStart) au().engineStart(0); },120);
  Game.toast(sp.m==="p"?"t_ride_air":sp.m==="h"?"t_ride_heli":"t_ride_sea",4200); writePose(cur); heroPos(cur); }

/* sürücü bıraktıktan sonra araç: uçak düz uçup uzaklaşır / gemi yavaşlayıp durur, sonra rotasına döner */
function autopilot(e,dt){ const A=e.RA, K=e.K, sp=SPEC[e.kind]; if(!A){ e.ctl=null; return; } A.t-=dt;
  if(A.air){ const fx=Math.sin(e.yaw), fz=Math.cos(e.yaw); A.spd+=(A.hold-A.spd)*(1-Math.exp(-dt*.2)); e.x+=fx*A.spd*dt; e.z+=fz*A.spd*dt; e.y+=A.vy*dt; A.vy*=Math.exp(-dt*.8);
    if(sp.m==="h"){ A.spd*=Math.exp(-dt*.4); }
    e.pit+=(0-e.pit)*(1-Math.exp(-dt*1.5)); e.rol+=(0-e.rol)*(1-Math.exp(-dt*1.5)); e.spd=A.spd; e.yr=0;
    const gy=groundMax({x:e.x,z:e.z,yaw:e.yaw,y:e.y},K); if(e.y-K.d[2]<gy+.2){ e.y=gy+K.d[2]; if(A.spd>0) A.spd=Math.max(0,A.spd-dt*14); A.vy=0; }
    if(A.spd<2&&A.t>12) A.t=Math.min(A.t,12); }
  else { A.spd*=Math.exp(-dt*(sp.m==="j"?.5:.12)); const nx=e.x+Math.sin(e.yaw)*A.spd*dt, nz=e.z+Math.cos(e.yaw)*A.spd*dt; if(!shipBlocked(nx,nz,K,e.yaw)){ e.x=nx; e.z=nz; } else A.spd=0;
    e.y=WY+.15+Math.sin(Sea.T||performance.now()/1000+e.ph)*.05; e.spd=A.spd; e.yr=0; e.pit*=Math.exp(-dt); e.rol*=Math.exp(-dt); }
  if(A.t<=0){ e.ctl=null; e.RA=null; e.st="gone"; e.t=R(18,34); e.g.visible=false; if(e.wg) e.wg.visible=false; } }

function leave(why){ const r=cur; if(!r) return; const e=r.e, K=e.K, sp=r.sp, air=sp.m==="p"||sp.m==="h";
  const fx=Math.sin(r.yaw), fz=Math.cos(r.yaw), lx=fz, lz=-fx, alive=e.st==="cruise";
  let hx=r.x, hy=r.y+K.d[1]+2.6, hz=r.z, vx=0, vy=0, vz=0, stand=false;
  if(why==="eject"||!alive){ hy=r.y+K.d[1]*.6+2.5; vx=fx*r.spd*.55; vz=fz*r.spd*.55; vy=Math.max(0,r.vy)+9; if(sp.m==="s"||sp.m==="j"){ vx*=.5; vz*=.5; } }
  else if(air&&!r.ground){ vx=Math.sin(r.yaw)*r.spd*Math.cos(r.pitch)*.6; vz=Math.cos(r.yaw)*r.spd*Math.cos(r.pitch)*.6; vy=r.vy*.5; hy=r.y+K.d[1]+3.5; }
  else if(air&&r.ground){ const side=K.d[0]+3.4; hx=r.x+lx*side; hz=r.z+lz*side; const g=gAt(hx,hz,r.y+3); hy=g+1.26; stand=true; }
  else { vx=fx*r.spd*.25; vz=fz*r.spd*.25; }
  const sp2=Math.hypot(vx,vz); if(sp2>60){ vx*=60/sp2; vz*=60/sp2; }
  hero.position.set(hx,hy,hz); hero.rotation.y=r.yaw; H.face=r.yaw; H.yaw=r.yaw+Math.PI; H.pitch=.12; H.vel.set(vx,vy,vz);
  H.flying=!stand; H.grounded=stand; H.speed=Math.hypot(vx,vy,vz); H.hv=Math.hypot(vx,vz); H.smash=false; H.landLock=0;
  if(Game.resetCamPivot) Game.resetCamPivot();
  if(alive){ e.hp=Math.max(1,Math.round(K.hp*Math.max(.35,r.hp/r.hp0))); e.RA={spd:r.spd,hold:sp.m==="p"?Math.max(r.spd,sp.vs*1.2):r.spd*(sp.m==="h"?.2:1),vy:r.ground?0:(sp.m==="p"?Math.max(r.vy*.5,-8):r.vy*.3),air,t:(air&&r.ground)||!air?45:14,ground:r.ground}; e.ctl=autopilot; }
  else e.ctl=null;
  api.active=false; api.e=null; api.kind=null; api.mode=null; api.speed=0; api.wind=0; cur=null; clearInputs(); hudEl.classList.remove("driving","riding","fast"); delete hudEl.dataset.rc;
  const a=au(); a.engine(false); a.wind&&a.wind(0); if(why!=="eject"&&a.door) a.door(); }
api.exit=function(force){ if(!cur) return; if(force||cur.dead||cur.e.st!=="cruise") leave(force?"force":"eject"); else leave("exit"); };
api.board=board; api.dbg=()=>cur;
const rh=Game.resetHero; Game.resetHero=function(){ if(api.active) leave("force"); rh(); };
Game.Mounted=function(){ if(api.active) return api; const d=Game.Drive; return d&&d.active?d:null; };

/* ---------- hasar / çarpışma ---------- */
function hurt(r,d,x,y,z){ if(!(d>0)||r.dead) return; r.hp-=d; r.hitT=.5; shake=Math.max(shake,clamp(d/r.hp0*3+.15,0,1));
  if(Game.Police&&Game.Police.Hp&&d>r.hp0*.12) Game.Police.Hp.hurt(Math.min(6,d*.02),x,y,z,"ride");
  if(r.hp<=0&&!r.dead){ r.dead=true; api.lastEnd={why:"hp",x,y,z,spd:r.spd,t:r.t}; const e=r.e, K=e.K; e.hp=1; if(r.sp.m==="p"||r.sp.m==="h"){ Sea.crash(e,r.ground||r.y-gAt(r.x,r.z,r.y)<K.d[2]+3?"ground":"ground",r.x,Math.max(r.y,gAt(r.x,r.z,r.y)+1),r.z); } else Sea.destroy(e,"ride",r.vx*.5,0,r.vz*.5); } }
function crash(r,why,x,y,z){ if(r.dead) return; r.dead=true; const e=r.e; e.hp=1; api.lastEnd={why,x,y,z,spd:r.spd,t:r.t};
  if(why==="water"&&(r.sp.m==="p"||r.sp.m==="h")) Sea.crash(e,"water",x,WY,z); else if(r.sp.m==="p"||r.sp.m==="h") Sea.crash(e,"ground",x,y,z); else Sea.destroy(e,"ride",r.vx*.4,0,r.vz*.4);
  if((r.sp.m==="p"||r.sp.m==="h")&&why==="building"){ const K=e.K; D.damageSphere(x,y,z,8+K.exp*4,1.7,26+K.exp*6); }
  Game.toast("t_ride_crash",3000); shake=1; H.shake=Math.max(H.shake||0,.8); if(Game.NPC) Game.NPC.noise(x,z,90); }
/* binalara karşı süpürme: gövde burnu, kanat uçları, kuyruk */
function sweepBuildings(r,ox,oy,oz){ const dx=r.x-ox, dy=r.y-oy, dz=r.z-oz, L=Math.hypot(dx,dy,dz); if(L<1e-4) return null; const nx=dx/L, ny=dy/L, nz=dz/L, d=r.e.K.d, nose=d[3]*.85, wing=d[0]*.9, fx=Math.sin(r.yaw), fz=Math.cos(r.yaw), lx=fz, lz=-fx;
  const O=[[fx*nose,0,fz*nose],[lx*wing,0,lz*wing],[-lx*wing,0,-lz*wing],[-fx*nose*.6,d[1]*.85,-fz*nose*.6],[0,-d[2]*.6,0]];
  for(let i=0;i<O.length;i++){ const o=O[i]; D.rayB(ox+o[0],oy+o[1],oz+o[2],nx,ny,nz,L+.5,rbuf); if(rbuf.kind!=="none"&&rbuf.t<=L+.5) return {x:rbuf.x,y:rbuf.y,z:rbuf.z,nx:rbuf.nx,ny:rbuf.ny,nz:rbuf.nz}; }
  return null; }
/* diğer deniz/hava araçlarıyla çarpışma */
const pt=[0,0,0];
function vsOthers(r){ const K=r.e.K, d=K.d, fx=Math.sin(r.yaw), fz=Math.cos(r.yaw), lx=fz, lz=-fx, L=d[3]*.8, Wd=d[0]*.8, vx=Math.sin(r.yaw)*r.spd, vz=Math.cos(r.yaw)*r.spd, ents=Sea.list();
  for(let q=0;q<ents.length;q++){ const o=ents[q]; if(o===r.e||(o.st!=="cruise"&&o.st!=="fly"&&o.st!=="fall")||(r.cool.get(o.id)||0)>r.t) continue;
    const dx=o.x-r.x, dz=o.z-r.z, rr=K.rr+o.K.rr; if(dx*dx+dz*dz>rr*rr||Math.abs(o.y-r.y)>K.d[1]+o.K.d[1]+8) continue;
    let hit=false; for(let i=0;i<5&&!hit;i++){ const a=i===0?1:i===1?-1:0, b=i===2?1:i===3?-1:0; if(Sea.boxD(o,r.x+fx*L*a+lx*Wd*b,r.y,r.z+fz*L*a+lz*Wd*b,.4)<.5) hit=true; }
    if(!hit) continue; r.cool.set(o.id,r.t+.9);
    const rv=Math.hypot(vx-(o.vx||0),(r.vy||0)-(o.vy||0),vz-(o.vz||0)); if(rv<2.5){ r.spd*=.9; continue; }
    const am=r.sp.m==="p"||r.sp.m==="h", oa=o.K.c==="a", pw=oa?9:Math.max(.6,Math.min(6,rv/9*(r.K.mass||1)/Math.max(.6,o.K.mass)));
    Sea.hit(o,pw,vx*.7,(r.vy||0)*.4+4,vz*.7,"ram"); FX.spark((r.x+o.x)/2,(r.y+o.y)/2,(r.z+o.z)/2,18,16); FX.dust((r.x+o.x)/2,(r.y+o.y)/2,(r.z+o.z)/2,6,4);
    if(au().smash) au().smash(Math.min(1.2,.3+rv/40)); shake=Math.max(shake,.5);
    hurt(r,Math.min(r.hp0*.7,rv*(o.K.mass+.7)*(am?3.2:2.4)),r.x,r.y,r.z); const nl=Math.hypot(dx,dz)||1; r.x-=dx/nl*1.2; r.z-=dz/nl*1.2; r.spd*=am?.9:.7; } }

/* ---------- hareket: uçak ---------- */
function stepPlane(r,dt){ const sp=r.sp, K=r.e.K, d=K.d, vs=sp.vs, bmax=sp.bmax;
  const gas=inp.fast||keys.w, brk=inp.slow||keys.s, up=inp.up||keys.arrowup||keys.i, dn=inp.down||keys.arrowdown||keys.k, lf=inp.left||keys.a||keys.arrowleft, rt=inp.right||keys.d||keys.arrowright, bst=inp.boost||keys.shift;
  const bankIn=(lf?1:0)-(rt?1:0), pitIn=(up?1:0)-(dn?1:0);
  r.thr=clamp(r.thr+((gas?1:0)-(brk?1:0))*dt*.5,0,1);
  r.boost=clamp(r.boost+((bst&&r.thr>.55)?1:-1.4)*dt*1.6,0,1);
  const vmaxE=sp.vmax*(1+(sp.boost-1)*r.boost), tgt=r.thr*vmaxE;
  let a=tgt>r.spd?clamp((tgt-r.spd)*.6,0,sp.acc*(1+r.boost*.5)):-(r.spd-tgt)*(r.ground?.6:.09);
  if(r.ground){ a-=.9; if(brk&&r.spd>1) a-=12; } else a-=9.8*Math.sin(r.pitch)*.6;
  r.spd=Math.max(0,r.spd+a*dt);
  const Lf=r.ground?1:clamp((r.spd-vs*.5)/(vs*.5),0,1), auth=r.ground?(r.spd>vs*.85?1:0):clamp(r.spd/vs,.35,1.2);
  if(pitIn) r.pitch+=pitIn*sp.pr*1.15*auth*dt; else if(!r.ground) r.pitch+=(-.02-r.pitch)*(1-Math.exp(-dt*.75));
  if(!r.ground) r.pitch-=(1-Lf)*1.1*dt;
  r.pitch=r.ground?clamp(r.pitch,0,.5):clamp(r.pitch,-1.25,1.2);
  const bt=r.ground?0:bankIn*bmax*clamp(auth*1.1,0,1); r.bank+=(bt-r.bank)*(1-Math.exp(-dt*(bankIn?2.3:1.7)));
  let yr; if(r.ground) yr=bankIn*.55*clamp(r.spd/9,0,1)/(1+r.spd/38); else yr=(r.bank/bmax)*sp.turn*(1+.5*(1-clamp(r.spd/vmaxE,0,1)));
  r.yaw+=yr*dt; r.yr+=(yr-r.yr)*(1-Math.exp(-dt*8));
  if(r.ground&&r.pitch>.07&&r.spd>vs*.95){ r.ground=false; r.vy=r.spd*Math.sin(r.pitch)*.6; }
  const cp=Math.cos(r.pitch), sn=Math.sin(r.pitch);
  const vyT=r.ground?0:r.spd*sn*(.35+.65*Lf)-(1-Lf)*34; r.vy+=(vyT-r.vy)*(1-Math.exp(-dt*(r.ground?30:3.5)));
  if(r.y>sp.ceil){ r.vy=Math.min(r.vy,-2); r.pitch=Math.min(r.pitch,-.1); }
  const hs=r.spd*cp, ox=r.x, oy=r.y, oz=r.z; r.vx=Math.sin(r.yaw)*hs; r.vz=Math.cos(r.yaw)*hs;
  r.x+=r.vx*dt; r.z+=r.vz*dt; r.y+=r.vy*dt;
  { const rd=Math.hypot(r.x,r.z); if(rd>3600){ const k=(rd-3600)/rd*.02; r.yaw+=aDiff(Math.atan2(-r.x,-r.z),r.yaw)*Math.min(1,k*60*dt); } }
  /* bina */
  const hit=sweepBuildings(r,ox,oy,oz);
  if(hit){ if(r.spd>9||!r.ground&&r.spd>5){ crash(r,"building",hit.x,hit.y,hit.z); return; } r.x=ox; r.y=oy; r.z=oz; r.spd=0; r.vx=r.vz=0; hurt(r,3,hit.x,hit.y,hit.z); }
  /* zemin */
  const gy=groundMax(r,K), bottom=r.y-d[2], wet=gy<=WY+.02&&isWet(r.x,r.z);
  if(r.ground){ if(bottom>gy+.6&&!wet){ r.ground=false; } else { if(wet){ crash(r,"water",r.x,WY,r.z); return; } const slope=r.y; r.y=gy+d[2]; r.vy=0; r.pitch=Math.min(r.pitch,.5); r.x+=0; void slope;
      if(r.spd>.5&&Math.random()<dt*14*Math.min(1,r.spd/20)) FX.dust(r.x-Math.sin(r.yaw)*d[3]*.6,gy+.3,r.z-Math.cos(r.yaw)*d[3]*.6,1,1.5,[.7,.7,.72]); } }
  else if(bottom<=gy){ const vsink=-r.vy;
    if(wet){ crash(r,"water",r.x,WY,r.z); return; }
    if(vsink<11&&Math.abs(r.pitch)<.3&&Math.abs(r.bank)<.4&&r.spd<sp.vmax*.85){ r.ground=true; r.y=gy+d[2]; r.vy=0; r.pitch=0; r.bank=0; if(vsink>5){ hurt(r,(vsink-5)*4,r.x,gy,r.z); FX.dust(r.x,gy+.4,r.z,10,3,[.75,.75,.78]); if(au().thud) au().thud(r.x,gy,r.z); shake=Math.max(shake,.4); } if(grndMsg<=0){ grndMsg=8; Game.toast("t_ride_land",2600); } }
    else { crash(r,"ground",r.x,gy+1,r.z); return; } }
  vsOthers(r);
  r.pit=-r.pitch; r.rol=-r.bank; }

/* ---------- hareket: helikopter ---------- */
function stepHeli(r,dt){ const sp=r.sp, K=r.e.K, d=K.d;
  const gas=inp.fast||keys.w, brk=inp.slow||keys.s, up=inp.up||keys.arrowup||keys[" "], dn=inp.down||keys.arrowdown||keys.k, lf=inp.left||keys.a||keys.arrowleft, rt=inp.right||keys.d||keys.arrowright, bst=inp.boost||keys.shift;
  const yawIn=(lf?1:0)-(rt?1:0); r.yr+=(yawIn*sp.turn-r.yr)*(1-Math.exp(-dt*3.2)); r.yaw+=r.yr*dt;
  const vm=sp.vmax*(bst?1.3:1), tgt=gas?vm:brk?-sp.vmax*.3:0;
  r.spd+=(tgt-r.spd)*(1-Math.exp(-dt*(gas?.9:brk?1.5:.6)));
  const vT=(up?1:0)*sp.climb-(dn?1:0)*sp.climb*.85; r.vy+=(vT-r.vy)*(1-Math.exp(-dt*2.2));
  const pt=-clamp(r.spd/sp.vmax,-.4,1.3)*.34; r.pitch+=(pt-r.pitch)*(1-Math.exp(-dt*3)); r.bank+=(clamp(r.yr*.28,-.5,.5)-r.bank)*(1-Math.exp(-dt*3));
  const ox=r.x, oy=r.y, oz=r.z; r.vx=Math.sin(r.yaw)*r.spd; r.vz=Math.cos(r.yaw)*r.spd; r.x+=r.vx*dt; r.z+=r.vz*dt; r.y+=r.vy*dt;
  if(r.y>sp.ceil){ r.y=sp.ceil; r.vy=Math.min(0,r.vy); }
  { const rd=Math.hypot(r.x,r.z); if(rd>3600){ r.yaw+=aDiff(Math.atan2(-r.x,-r.z),r.yaw)*Math.min(1,dt*1.2); } }
  const hit=sweepBuildings(r,ox,oy,oz);
  if(hit){ if(Math.hypot(r.spd,r.vy)>10){ crash(r,"building",hit.x,hit.y,hit.z); return; } r.x=ox; r.y=oy; r.z=oz; r.spd*=-.2; r.vy=0; hurt(r,1.5+Math.abs(r.spd),hit.x,hit.y,hit.z); }
  const gy=groundMax(r,K), bottom=r.y-d[2];
  if(bottom<=gy+.05){ const vsink=-r.vy; if(vsink>10){ crash(r,"ground",r.x,gy+1,r.z); return; } if(vsink>5) hurt(r,(vsink-5)*5,r.x,gy,r.z); r.y=gy+d[2]; r.vy=Math.max(0,r.vy); r.ground=!up; if(r.ground){ r.spd*=Math.exp(-dt*2.2); r.pitch*=.9; } }
  else r.ground=false;
  if(!r.ground&&r.y-d[2]<gy+4&&Math.random()<dt*20){ if(isWet(r.x,r.z)) Game.splash&&Game.splash(r.x+rs()*7,r.z+rs()*7,.6); else FX.dust(r.x+rs()*6,gy+.3,r.z+rs()*6,1,2,[.75,.75,.78]); }
  vsOthers(r); r.pit=-r.pitch; r.rol=-r.bank; }

/* ---------- hareket: gemi / jet ski ---------- */
function stepShip(r,dt){ const sp=r.sp, K=r.e.K, jet=sp.m==="j";
  const gas=inp.fast||keys.w||keys.arrowup, brk=inp.slow||keys.s||keys.arrowdown, lf=inp.left||keys.a||keys.arrowleft, rt=inp.right||keys.d||keys.arrowright, bst=(inp.boost||keys.shift)&&jet;
  r.boost=clamp(r.boost+(bst?1:-1.5)*dt*2,0,1); const vm=sp.vmax*(1+.28*r.boost), steer=(lf?1:0)-(rt?1:0);
  let a; if(r.e.frozen){ a=-r.spd*1.5; }
  else if(gas) a=sp.acc*(1+r.boost*.6)*Math.max(.04,1-Math.pow(Math.max(0,r.spd)/vm,2));
  else if(brk) a=r.spd>.8?-sp.dec:-sp.acc*.45*Math.max(.1,1-Math.pow(Math.max(0,-r.spd)/(vm*sp.rev),2));
  else a=-(r.spd>0?1:-1)*(.12+Math.abs(r.spd)*(jet?.2:.04));
  const s0=r.spd; r.spd+=a*dt; if(!gas&&!brk&&s0*r.spd<=0) r.spd=0;
  const tk=clamp(Math.abs(r.spd)/(vm*.18),0,1)*(r.spd<0?-1:1), yt=r.e.frozen?0:steer*sp.turn*tk*(1-.3*Math.min(1,Math.abs(r.spd)/vm));
  r.yr+=(yt-r.yr)*(1-Math.exp(-dt*(jet?4.5:1.1))); r.yaw+=r.yr*dt;
  const ox=r.x, oz=r.z; r.vx=Math.sin(r.yaw)*r.spd; r.vz=Math.cos(r.yaw)*r.spd; r.x+=r.vx*dt; r.z+=r.vz*dt;
  if(shipBlocked(r.x,r.z,K,r.yaw)){ const sx=r.x, sz=r.z; r.x=ox; r.z=oz;
    /* kıyıyı kayarak izle: tek eksende dene */
    if(!shipBlocked(sx,oz,K,r.yaw)) r.x=sx; else if(!shipBlocked(ox,sz,K,r.yaw)) r.z=sz;
    const imp=Math.abs(r.spd); if(imp>2.5){ hurt(r,Math.max(0,imp-3)/sp.vmax*r.hp0*.55,r.x,WY,r.z); FX.dust(r.x+Math.sin(r.yaw)*K.d[3],WY+1,r.z+Math.cos(r.yaw)*K.d[3],8,4,[.82,.78,.66]); if(au().thud) au().thud(r.x,WY,r.z); Game.toast("t_ride_ground",2600); }
    r.spd*=-.12; r.yr*=.5; }
  const S=K.mass>=3?1:2.4, T=r.t; r.vy=0; r.y=WY+.15+(jet?Math.abs(Math.sin(T*9))*.1*Math.min(1,r.spd/20)+.04*Math.sin(T*5):Math.sin(T*.8+r.e.ph)*.06*S);
  const kp=1-Math.exp(-dt*(jet?5:2)); r.pit+=((jet?-.1*Math.min(1,Math.abs(r.spd)/20)+.04*Math.sin(T*7):Math.sin(T*.55+r.e.ph)*.012*S-(a>0?.012*S:0)+(a<-1.5?.012*S:0))-r.pit)*kp;
  r.rol+=((jet?-clamp(r.yr*r.spd*.05,-.55,.55)+.03*Math.sin(T*4):clamp(r.yr*r.spd*.02,-.12,.12)+Math.sin(T*.7+r.e.ph*2)*.016*S)-r.rol)*kp;
  vsOthers(r); }

/* ---------- Sea'nin 'cruise' durumundaki kancası ---------- */
function ctlRide(e,dt){ const r=cur; if(!r||r.e!==e) return; r.t+=dt; r.hitT-=dt; grndMsg-=dt; if(r.dead) return;
  if(Game.mode!=="play") return;
  /* dış hasar (patlama, güç) e.hp'yi düşürür: aracın canına çevir */
  if(e.hp<9999){ const lost=9999-e.hp; e.hp=9999; hurt(r,lost*r.hp0*.22,e.x,e.y,e.z); if(r.dead) return; }
  if(e.burning){ r.burnT+=dt; hurt(r,dt*r.hp0*.06,e.x,e.y,e.z); if(r.dead) return; } else r.burnT=0;
  const m=r.sp.m; if(m==="p") stepPlane(r,dt); else if(m==="h") stepHeli(r,dt); else stepShip(r,dt);
  if(r.dead) return;
  e.x=r.x; e.y=r.y; e.z=r.z; e.yaw=r.yaw; if(!(r.pit===r.pit)) r.pit=0; if(!(r.rol===r.rol)) r.rol=0; e.pit=r.pit; e.rol=r.rol;
  e.spd=r.spd; e.yr=r.yr; e.vx=r.vx; e.vy=r.vy; e.vz=r.vz; e.thrown=false; api.speed=Math.abs(r.spd); api.wind=m==="p"||m==="h"?Math.max(0,(r.spd-18)*1.1):Math.abs(r.spd)*.6; }
function writePose(r){ const e=r.e; e.x=r.x; e.y=r.y; e.z=r.z; e.yaw=r.yaw; Sea.sync(e); }
function heroPos(r){ hero.position.set(r.x,r.y+r.K.d[1]*.6,r.z); hero.rotation.y=r.yaw; H.face=r.yaw; H.alt=r.y; H.sp=0; api.x=r.x; api.y=r.y; api.z=r.z; api.yaw=r.yaw; }

/* ---------- kamera ---------- */
function camera3(r,dt){ const fp=Game.settings.cam==="1p", K=r.K, m=r.sp.m, air=m==="p"||m==="h", spd=Math.abs(r.spd);
  const look=Game.lookActive&&Game.lookActive(); if(look) lookIdle=0; else lookIdle+=dt;
  const pw=fp?(air?-r.pitch*.9:.04):(air?-.17+r.pitch*.55:-.3);
  if(!look){ const want=r.yaw+Math.PI; let d=aDiff(want,H.yaw); const rate=lookIdle>1.3?3.2:(spd>4?1.9:0); if(rate) H.yaw+=d*(1-Math.exp(-rate*dt)); if(lookIdle>1.3||spd>4) H.pitch+=(pw-H.pitch)*(1-Math.exp(-2.4*dt)); }
  const cp=Math.cos(H.pitch); lookV.x=-Math.sin(H.yaw)*cp; lookV.y=Math.sin(H.pitch); lookV.z=-Math.cos(H.yaw)*cp;
  const fx=Math.sin(r.yaw), fz=Math.cos(r.yaw);
  if(shake>.01) shake*=Math.exp(-5*dt); const shk=(shake+Math.max(0,spd-(air?90:30))*.002+(m==="j"?.03:0))*Game.settings.shake;
  let roll=0;
  if(fp){ const ef=K.d[3]*(m==="s"?.45:m==="h"?.55:.5), eu=K.d[1]*(m==="s"?.95:.55)+(m==="j"?.9:.45), ex=r.x+fx*ef, ey=r.y+eu, ez=r.z+fz*ef;
    camera.position.set(ex+rs()*shk*.4,ey+rs()*shk*.4,ez+rs()*shk*.4); camera.lookAt(ex+lookV.x*20,ey+lookV.y*20,ez+lookV.z*20); roll=(air?r.bank*.8:r.rol*.5)*(1-Math.min(1,lookIdle<1.3?1:0)*.0); }
  else { const hy=air?K.d[1]*.4+1.2:K.d[1]*.55+2.2, ah=Math.min(8,spd*.06), tx=r.x+fx*ah*(air?1:.4), ty=r.y+hy, tz=r.z+fz*ah*(air?1:.4);
    if(!camPiv) camPiv={x:camera.position.x+lookV.x*9,y:camera.position.y+lookV.y*9,z:camera.position.z+lookV.z*9};
    const rate=r.t<.9?4+r.t*14:18, kp=1-Math.exp(-rate*dt); camPiv.x+=(tx-camPiv.x)*kp; camPiv.y+=(ty-camPiv.y)*kp; camPiv.z+=(tz-camPiv.z)*kp;
    const lag=1.6+spd*.035; let lx=camPiv.x-tx, ly=camPiv.y-ty, lz=camPiv.z-tz; const l2=lx*lx+ly*ly+lz*lz; if(l2>lag*lag){ const k=lag/Math.sqrt(l2); camPiv.x=tx+lx*k; camPiv.y=ty+ly*k; camPiv.z=tz+lz*k; }
    const want=(air?8:11)+K.d[3]*(air?1.9:1.55)+Math.min(air?14:7,spd*(air?.09:.12)); camDist=camDist<0?want:camDist+(want-camDist)*(1-Math.exp(-2.4*dt));
    let px=camPiv.x-lookV.x*camDist, py=camPiv.y-lookV.y*camDist, pz=camPiv.z-lookV.z*camDist;
    const bx=px-tx, by=py-ty, bz=pz-tz, Ln=Math.hypot(bx,by,bz)||1; D.rayB(tx,ty,tz,bx/Ln,by/Ln,bz/Ln,Ln,rbuf);
    if(rbuf.kind!=="none"&&rbuf.t<Ln){ const L2=Math.max(2,rbuf.t-.6); px=tx+bx/Ln*L2; py=ty+by/Ln*L2; pz=tz+bz/Ln*L2; }
    const gy=gAt(px,pz,py)+1.2; if(py<gy) py=gy;
    if(r.t<.9){ const kc=1-Math.exp(-(5+r.t*30)*dt); camera.position.x+=(px-camera.position.x)*kc; camera.position.y+=(py-camera.position.y)*kc; camera.position.z+=(pz-camera.position.z)*kc; } else camera.position.set(px,py,pz);
    if(shk>.01){ camera.position.x+=rs()*shk; camera.position.y+=rs()*shk; camera.position.z+=rs()*shk; }
    camera.lookAt(tx,ty,tz); roll=air?r.bank*.22:0; }
  if(roll&&camera.rotateZ) camera.rotateZ(-roll*(r.rollK=r.rollK===undefined?1:r.rollK));
  const fovT=Game.settings.fovAdd+(fp?82:72)+Math.min(air?26:12,spd*(air?.16:.3))+r.boost*5; camera.fov+=(fovT-camera.fov)*(1-Math.exp(-4*dt)); camera.near=.2; camera.far=7000; camera.updateProjectionMatrix(); }

/* ---------- HUD ---------- */
const hSpd=$("rSpd"), hAlt=$("rAlt"), hThr=$("rThr"), hHp=$("rHp");
function hud(r,dt){ hudT-=dt; if(hudT>0) return; hudT=.09; const air=r.sp.m==="p"||r.sp.m==="h";
  if(hSpd) hSpd.textContent=Math.round(Math.abs(r.spd)*(Game.settings.mph?2.237:3.6)); if(hAlt) hAlt.textContent=Math.round(Math.max(0,r.y-gAt(r.x,r.z,r.y+2))*(Game.settings.mph?3.281:1));
  if(hThr) hThr.style.width=Math.round(clamp(r.sp.m==="p"?r.thr:Math.abs(r.spd)/(r.sp.vmax*1.1),0,1)*100)+"%";
  if(hHp){ const f=clamp(r.hp/r.hp0,0,1); hHp.style.width=Math.round(f*100)+"%"; hHp.style.background=f>.5?"#3be06a":f>.25?"#ffd23a":"#ff3a2a"; }
  hudEl.classList.toggle("fast",Math.abs(r.spd)>(air?95:32)); }

/* ---------- yakındaki araç: BİN düğmesi ---------- */
function findNear(){ const p=hero.position, list=Sea.list(); let best=null, bd=1e9;
  for(let i=0;i<list.length;i++){ const e=list[i]; if(!canBoard(e)) continue; const air=e.K.c==="a", rr=e.K.rr+30, dx=p.x-e.x, dz=p.z-e.z; if(dx*dx+dz*dz>rr*rr) continue;
    const reach=air?(e.kind==="fighter"?26:e.kind==="heli"?14:20):10, dd=Sea.boxD(e,p.x,p.y,p.z,0); if(dd<reach&&dd<bd){ bd=dd; best=e; } }
  return best; }
const ICON={cargo:"🚢",tanker:"🛢️",ferry:"⛴️",yacht:"🛥️",fishing:"🎣",sail:"⛵",jetski:"🏄",airliner:"✈️",prop:"🛩️",fighter:"🛩️",heli:"🚁"};
let shownKind=null;
function updateNear(dt){ nearT-=dt; if(nearT>0) return; nearT=.14; const D0=Game.Drive; if(Game.mode!=="play"||(D0&&D0.active)||Game.heroLock>0){ if(api.near){ api.near=null; } return; }
  const e=findNear(), prev=api.near; api.near=e; const carNear=!!(D0&&D0.near);
  if(e&&!carNear){ btnEnter.classList.add("on"); if(!prev||prev!==e||shownKind!==e.kind){ shownKind=e.kind; const ei=btnEnter.querySelector(".ei"); if(ei) ei.textContent=ICON[e.kind]||"🚢"; nameEl.textContent=t("sv_"+e.kind); } }
  else if(!e&&prev&&!carNear){ btnEnter.classList.remove("on"); shownKind=null; const ei=btnEnter.querySelector(".ei"); if(ei) ei.textContent="🚗"; }
  else if(carNear&&shownKind){ shownKind=null; const ei=btnEnter.querySelector(".ei"); if(ei) ei.textContent="🚗"; } }
Game.onLang4=()=>{ const nm=$("rName"); if(nm&&cur) nm.textContent=t("sv_"+cur.k); if(api.near&&shownKind) nameEl.textContent=t("sv_"+api.near.kind); };

/* ---------- ana döngü (Sea'dan sonra çalışır: araç konumu bu karenin değeridir) ---------- */
Game.updaters.push((dt0,time,raw)=>{
  if(Game.mode!=="play"){ if(api.active||inp.fast||inp.slow) clearInputs(); return; }
  const dt=Math.min(.05,raw||dt0||.016);
  if(!api.active||!cur){ updateNear(dt); return; }
  const r=cur, e=r.e;
  if(e.st!=="cruise"||r.dead){ leave("eject"); return; }
  heroPos(r); camera3(r,dt); hud(r,dt);
  const a=au(); if(a&&a.engine){ const air=r.sp.m==="p"||r.sp.m==="h", rpm=air?(r.sp.m==="p"?r.thr:.7+Math.min(.3,Math.abs(r.spd)/80)):clamp(Math.abs(r.spd)/(r.sp.vmax*1.1),0,1), thr=air?(r.sp.m==="p"?r.thr:.55+(inp.up?.3:0)):(inp.fast||keys.w?1:.25);
    a.engine(!r.dead,.15+rpm*.8,thr,r.sp.eng); } });
return api;
})();
