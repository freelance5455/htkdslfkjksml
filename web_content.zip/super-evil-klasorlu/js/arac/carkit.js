"use strict";
/* ===== ARABA MODELLERİ: 6 tip (sedan, SUV, spor, minibüs/kamyon, pikap, taksi); boyalı gövde + cam/jant/tekerlek + farlar ===== */
Game.CarKit=(function(){
  const U=Game.U, hex=h=>{ const c=new THREE.Color(h); return [c.r,c.g,c.b]; };
  const WH=[1,1,1], GLASS=hex("#0e1722"), TIRE=hex("#141517"), RIM=hex("#b9bec6"), DARK=hex("#1a1c20"), TRIM=hex("#2b2e33"), PLATE=hex("#e8e8e0");
  function MB(){ return {p:[],n:[],c:[],i:[]}; }
  function part(b,pos,idx,color,fix){
    const n=pos.length/3, base=b.p.length/3;
    if(fix!==false){ let cx=0,cy=0,cz=0; for(let k=0;k<n;k++){ cx+=pos[k*3]; cy+=pos[k*3+1]; cz+=pos[k*3+2]; } cx/=n; cy/=n; cz/=n;
      for(let t=0;t<idx.length;t+=3){ const a=idx[t]*3,bb=idx[t+1]*3,c=idx[t+2]*3;
        const ux=pos[bb]-pos[a],uy=pos[bb+1]-pos[a+1],uz=pos[bb+2]-pos[a+2],vx=pos[c]-pos[a],vy=pos[c+1]-pos[a+1],vz=pos[c+2]-pos[a+2];
        const nx=uy*vz-uz*vy,ny=uz*vx-ux*vz,nz=ux*vy-uy*vx, mx=(pos[a]+pos[bb]+pos[c])/3-cx,my=(pos[a+1]+pos[bb+1]+pos[c+1])/3-cy,mz=(pos[a+2]+pos[bb+2]+pos[c+2])/3-cz;
        if(nx*mx+ny*my+nz*mz<0){ const tmp=idx[t+1]; idx[t+1]=idx[t+2]; idx[t+2]=tmp; } } }
    const nr=new Array(n*3).fill(0);
    for(let t=0;t<idx.length;t+=3){ const a=idx[t]*3,bb=idx[t+1]*3,c=idx[t+2]*3;
      const ux=pos[bb]-pos[a],uy=pos[bb+1]-pos[a+1],uz=pos[bb+2]-pos[a+2],vx=pos[c]-pos[a],vy=pos[c+1]-pos[a+1],vz=pos[c+2]-pos[a+2];
      const nx=uy*vz-uz*vy,ny=uz*vx-ux*vz,nz=ux*vy-uy*vx; for(const o of [a,bb,c]){ nr[o]+=nx; nr[o+1]+=ny; nr[o+2]+=nz; } }
    for(let k=0;k<n;k++){ const x=nr[k*3],y=nr[k*3+1],z=nr[k*3+2], l=Math.hypot(x,y,z)||1; b.n.push(x/l,y/l,z/l); b.p.push(pos[k*3],pos[k*3+1],pos[k*3+2]); b.c.push(color[0],color[1],color[2]); }
    for(const k of idx) b.i.push(k+base); }
  /* ring: gövde kesiti (8 nokta) */
  function ring(hw,yb,yt,top){ const h=yt-yb; top=top||.86; return [[-.93*hw,yb],[.93*hw,yb],[hw,yb+.2*h],[hw*.985,yb+.78*h],[hw*top,yt],[-hw*top,yt],[-hw*.985,yb+.78*h],[-hw,yb+.2*h]]; }
  function loft(b,st,color,caps){ const m=st[0].ring.length, pos=[], idx=[];
    st.forEach(s=>s.ring.forEach(p=>pos.push(p[0],p[1],s.z)));
    for(let a=0;a<st.length-1;a++) for(let k=0;k<m;k++){ const k2=(k+1)%m, i0=a*m+k,i1=a*m+k2,i2=(a+1)*m+k2,i3=(a+1)*m+k; idx.push(i0,i1,i2,i0,i2,i3); }
    if(caps!==false) for(const si of [0,st.length-1]){ const base=pos.length/3, s=st[si]; let cx=0,cy=0; s.ring.forEach(p=>{ cx+=p[0]; cy+=p[1]; }); cx/=m; cy/=m; pos.push(cx,cy,s.z); s.ring.forEach(p=>pos.push(p[0],p[1],s.z)); for(let k=0;k<m;k++) idx.push(base,base+1+k,base+1+(k+1)%m); }
    part(b,pos,idx,color); }
  const S=(z,hw,yb,yt,top)=>({z,ring:ring(hw,yb,yt,top)});
  function box(b,cx,cy,cz,sx,sy,sz,color){ const x=sx/2,y=sy/2,z=sz/2, pos=[], idx=[];
    const F=[[[1,0,0],[[x,-y,-z],[x,y,-z],[x,y,z],[x,-y,z]]],[[-1,0,0],[[-x,-y,z],[-x,y,z],[-x,y,-z],[-x,-y,-z]]],[[0,1,0],[[-x,y,-z],[-x,y,z],[x,y,z],[x,y,-z]]],[[0,-1,0],[[-x,-y,z],[-x,-y,-z],[x,-y,-z],[x,-y,z]]],[[0,0,1],[[-x,-y,z],[x,-y,z],[x,y,z],[-x,y,z]]],[[0,0,-1],[[x,-y,-z],[-x,-y,-z],[-x,y,-z],[x,y,-z]]]];
    for(const f of F){ const o=pos.length/3; for(const v of f[1]) pos.push(cx+v[0],cy+v[1],cz+v[2]); idx.push(o,o+1,o+2,o,o+2,o+3); }
    part(b,pos,idx,color); }
  /* iki nokta arası çubuk (A sütunu, bagaj çıtası...) */
  function bar(b,p0,p1,t,color){ let dx=p1[0]-p0[0],dy=p1[1]-p0[1],dz=p1[2]-p0[2]; const L=Math.hypot(dx,dy,dz)||1; dx/=L; dy/=L; dz/=L;
    let rx=1,ry=0,rz=0; if(Math.abs(dx)>.9){ rx=0; ry=1; }
    let vx=dy*rz-dz*ry,vy=dz*rx-dx*rz,vz=dx*ry-dy*rx, vl=Math.hypot(vx,vy,vz)||1; vx/=vl; vy/=vl; vz/=vl;
    const wx=dy*vz-dz*vy,wy=dz*vx-dx*vz,wz=dx*vy-dy*vx, h=t/2, pos=[], idx=[];
    for(const P of [p0,p1]) for(const [a,c] of [[-1,-1],[1,-1],[1,1],[-1,1]]) pos.push(P[0]+(vx*a+wx*c)*h,P[1]+(vy*a+wy*c)*h,P[2]+(vz*a+wz*c)*h);
    for(let k=0;k<4;k++){ const k2=(k+1)%4; idx.push(k,k2,4+k2,k,4+k2,4+k); } idx.push(0,1,2,0,2,3,4,5,6,4,6,7);
    part(b,pos,idx,color); }
  /* x ekseni boyunca silindir (lastik) + dış yüzeyde disk (jant) + gövde üstünde kemer karartması */
  function disc(b,cx,cy,cz,r,seg,dirX,color){ const pos=[cx,cy,cz], idx=[]; for(let k=0;k<seg;k++){ const a=k/seg*6.2832; pos.push(cx,cy+Math.cos(a)*r,cz+Math.sin(a)*r); }
    for(let k=0;k<seg;k++){ const k2=(k+1)%seg; if(dirX>0) idx.push(0,1+k,1+k2); else idx.push(0,1+k2,1+k); } part(b,pos,idx,color,false); }
  function wheel(b,side,xo,cy,cz,r,tw,seg,ar){ // xo: gövde yan düzlemi (pozitif), side ±1
    const x0=side*(xo+.03), x1=side*(xo+.03-tw), pos=[], idx=[];
    for(let k=0;k<seg;k++){ const a=k/seg*6.2832, y=cy+Math.cos(a)*r, z=cz+Math.sin(a)*r; pos.push(x0,y,z,x1,y,z); }
    for(let k=0;k<seg;k++){ const k2=(k+1)%seg; idx.push(2*k,2*k+1,2*k2+1,2*k,2*k2+1,2*k2); }
    part(b,pos,idx,TIRE);
    disc(b,x0+side*.004,cy,cz,r*.62,seg,side,RIM); disc(b,side*(xo+.006),cy,cz,r*(ar||1.22),seg,side,DARK); }
  function wheels(b,xo,zs,r,tw,ar){ for(const z of zs) for(const s of [-1,1]) wheel(b,s,xo,r,z,r,tw,9,ar); }
  function finish(b){ const g=new THREE.BufferGeometry();
    g.setAttribute("position",new THREE.BufferAttribute(new Float32Array(b.p),3)); g.setAttribute("normal",new THREE.BufferAttribute(new Float32Array(b.n),3)); g.setAttribute("color",new THREE.BufferAttribute(new Float32Array(b.c),3));
    g.setIndex(new THREE.BufferAttribute(new Uint16Array(b.i),1)); return g; }
  const HL=hex("#fff6dc"), TL=hex("#ff2a2a"), AMB=hex("#ffb03a");
  function mk(){ return {paint:MB(),det:MB(),lt:MB()}; }
  /* ortak kabin: cam gövdesi + boyalı tavan + sütunlar */
  function cabin(M,cs,roof,roofHW,pill){ loft(M.det,cs.map(c=>S(c[0],c[1],c[2],c[3],c[4]||.74)),GLASS);
    if(roof){ const rs=roof.map(r=>({z:r[0],ring:[[-roofHW,r[1]-.06],[roofHW,r[1]-.06],[roofHW,r[1]+.012],[-roofHW,r[1]+.012]]})); loft(M.paint,rs,WH); }
    if(pill) for(const pl of pill){ for(const s of [-1,1]) bar(M.paint,[s*pl[0],pl[1],pl[2]],[s*pl[3],pl[4],pl[5]],pl[6]||.06,WH); } }
  const TYPES=[];
  /* 0: SEDAN (taksi ve polis de bu gövdeyi kullanır) */
  function sedan(M){
    loft(M.paint,[S(2.30,.76,.46,.64),S(2.20,.86,.34,.72),S(1.95,.91,.30,.80),S(1.40,.93,.28,.90),S(.80,.93,.28,.98),S(-.60,.93,.28,.98),S(-1.60,.93,.28,1.00),S(-2.10,.89,.30,.98),S(-2.30,.80,.40,.90)],WH);
    cabin(M,[[.88,.80,.96,.99],[.55,.80,.96,1.17],[.05,.78,.96,1.42],[-.40,.77,.96,1.45],[-1.00,.77,.97,1.44],[-1.50,.80,.98,1.22],[-1.85,.82,.99,1.04]],[[.20,1.375],[-.10,1.435],[-.90,1.45],[-1.20,1.395]],.58,
      [[.70,1.0,.82,.57,1.40,.18],[.755,1.0,-.50,.60,1.44,-.45,.07]]);
    box(M.det,0,.5,2.285,.95,.15,.05,DARK); box(M.det,0,.36,2.2,1.5,.12,.22,TRIM); box(M.det,0,.46,-2.27,1.5,.14,.12,TRIM); box(M.det,0,.52,2.315,.46,.12,.02,PLATE); box(M.det,0,.72,-2.33,.46,.12,.02,PLATE);
    for(const s of [-1,1]){ box(M.paint,s*1.0,1.05,.78,.1,.08,.17,WH); bar(M.paint,[s*.9,1.0,.8],[s*.97,1.05,.78],.04,WH); box(M.det,s*.9,.62,.52,.016,.34,.014,DARK); box(M.det,s*.9,.62,-.58,.016,.34,.014,DARK);
      box(M.lt,s*.64,.65,2.235,.32,.1,.1,HL); box(M.lt,s*.66,.82,-2.3,.4,.1,.05,TL); }
    wheels(M.det,.88,[1.45,-1.4],.35,.26); }
  { const M=mk(); sedan(M); TYPES[0]={M,W:1.85,L:4.6,H:1.46,name:"car_0"}; }
  /* 1: SUV */
  { const M=mk();
    loft(M.paint,[S(2.38,.82,.52,.86),S(2.28,.93,.40,.98),S(2.0,.97,.38,1.08),S(1.5,.99,.36,1.14),S(.9,.99,.36,1.18),S(-1.0,.99,.36,1.20),S(-2.0,.98,.36,1.20),S(-2.28,.95,.40,1.16),S(-2.375,.88,.46,1.08)],WH);
    cabin(M,[[1.0,.88,1.14,1.18],[.7,.88,1.14,1.40],[.2,.87,1.14,1.72],[-.4,.87,1.14,1.76],[-1.5,.88,1.15,1.77],[-2.15,.9,1.15,1.70],[-2.3,.9,1.15,1.40]],[[.30,1.70],[0,1.76],[-1.8,1.775],[-2.1,1.72]],.71,
      [[.80,1.18,1.0,.68,1.70,.3],[.86,1.15,-.70,.86,1.74,-.65,.07],[.88,1.15,-2.1,.84,1.66,-2.32,.08]]);
    for(const s of [-1,1]) bar(M.det,[s*.56,1.8,.2],[s*.56,1.8,-2.0],.05,DARK);
    box(M.paint,0,1.79,-2.2,1.2,.04,.2,WH);
    box(M.det,0,.62,2.37,1.1,.28,.05,DARK); box(M.det,0,.40,2.28,1.7,.14,.26,TRIM); box(M.det,0,.50,-2.36,1.6,.16,.1,TRIM); box(M.det,0,.56,2.4,.5,.12,.02,PLATE); box(M.det,0,.78,-2.4,.5,.12,.02,PLATE);
    for(const s of [-1,1]){ box(M.paint,s*1.07,1.2,.95,.1,.1,.18,WH); bar(M.paint,[s*.97,1.19,.95],[s*1.04,1.2,.95],.05,WH); box(M.det,s*.96,.9,.7,.016,.4,.014,DARK); box(M.det,s*.96,.9,-.6,.016,.4,.014,DARK); box(M.det,s*.96,.9,-1.6,.016,.4,.014,DARK);
      box(M.lt,s*.68,.94,2.33,.34,.14,.1,HL); box(M.lt,s*.88,1.02,-2.37,.1,.34,.05,TL); }
    wheels(M.det,.94,[1.5,-1.45],.40,.3); TYPES[1]={M,W:1.98,L:4.75,H:1.82,name:"car_1"}; }
  /* 2: SPOR */
  { const M=mk();
    loft(M.paint,[S(2.25,.78,.32,.46),S(2.12,.89,.24,.55),S(1.8,.96,.20,.62),S(1.2,.975,.18,.70),S(.5,.975,.18,.76),S(-.5,.975,.18,.82),S(-1.5,.975,.18,.88),S(-2.0,.95,.2,.90),S(-2.25,.86,.26,.84)],WH);
    cabin(M,[[.55,.84,.74,.77],[.2,.85,.74,.96],[-.3,.84,.76,1.17],[-.8,.82,.78,1.19],[-1.35,.85,.8,1.08],[-2.0,.9,.86,.90]],[[-.05,1.07],[-.3,1.17],[-.8,1.19],[-1.35,1.09]],.64,
      [[.72,.78,.55,.66,.95,.12,.06]]);
    box(M.paint,0,.99,-2.1,1.55,.05,.3,WH); for(const s of [-1,1]) box(M.paint,s*.52,.9,-2.05,.06,.18,.12,WH);
    box(M.det,0,.2,2.2,1.7,.05,.34,DARK); box(M.det,0,.34,2.24,.9,.12,.05,DARK); box(M.det,0,.34,-2.2,1.4,.14,.14,DARK); box(M.det,0,.5,2.27,.4,.1,.02,PLATE); box(M.det,0,.62,-2.27,.4,.1,.02,PLATE);
    for(const s of [-1,1]){ box(M.det,s*.98,.5,-.5,.03,.14,.55,DARK); box(M.paint,s*.99,.8,.55,.08,.06,.14,WH);
      box(M.lt,s*.7,.5,2.2,.4,.07,.1,HL); box(M.lt,s*.62,.76,-2.24,.5,.09,.05,TL); }
    wheels(M.det,.93,[1.5,-1.4],.32,.3,1.02); TYPES[2]={M,W:1.95,L:4.5,H:1.2,name:"car_2"}; }
  /* 3: MİNİBÜS / KAMYON / OTOBÜS (ölçek: genişlik, uzunluk, yükseklik) */
  { const M=mk();
    loft(M.paint,[S(3.0,.92,.55,1.15),S(2.9,1.03,.42,1.30),S(2.4,1.08,.4,1.36),S(-2.9,1.1,.4,1.40),S(-3.0,1.05,.45,1.35)],WH);
    loft(M.paint,[S(1.2,1.04,1.30,2.36,.96),S(-2.9,1.06,1.30,2.38,.96),S(-3.0,1.0,1.30,2.30,.94)],WH);
    loft(M.det,[S(2.45,1.0,1.34,1.40,.9),S(1.9,1.0,1.34,1.95,.9),S(1.2,1.03,1.34,2.34,.92)],GLASS);
    for(const s of [-1,1]){ box(M.det,s*1.075,1.95,-.1,.02,.5,1.5,GLASS); box(M.det,s*1.075,1.95,-2.1,.02,.5,1.3,GLASS); box(M.det,s*1.09,.9,-.2,.02,.03,5.6,TRIM);
      box(M.lt,s*.7,.95,3.0,.4,.2,.08,HL); box(M.lt,s*.85,1.05,-3.03,.16,.5,.06,TL); box(M.paint,s*1.18,1.7,1.5,.1,.3,.1,WH); }
    box(M.det,0,.7,3.0,1.3,.4,.06,DARK); box(M.det,0,.5,2.9,2.0,.2,.3,TRIM); box(M.det,0,.55,-3.05,2.0,.2,.15,TRIM); box(M.det,0,.7,-3.07,.5,.13,.02,PLATE);
    wheels(M.det,1.06,[1.95,-1.9],.42,.34); TYPES[3]={M,W:2.2,L:6.0,H:2.4,name:"car_3"}; }
  /* 4: PİKAP (çift kabin + açık kasa) */
  { const M=mk();
    loft(M.paint,[S(2.67,.84,.55,.92),S(2.55,.98,.42,1.05),S(2.2,1.03,.40,1.15),S(1.5,1.04,.38,1.21),S(.9,1.04,.38,1.25),S(-.62,1.04,.38,1.26),S(-.66,1.04,.38,.95),S(-1.5,1.04,.38,.95),S(-2.5,1.04,.40,.95),S(-2.67,1.0,.45,.92)],WH);
    cabin(M,[[1.05,.92,1.22,1.27],[.7,.92,1.22,1.52],[.25,.91,1.22,1.86],[-.2,.91,1.22,1.92],[-.58,.92,1.22,1.9],[-.66,.92,1.22,1.5]],[[.3,1.88],[0,1.93],[-.55,1.93]],.8,
      [[.86,1.22,.98,.74,1.84,.3],[.9,1.22,-.35,.9,1.9,-.35,.07]]);
    box(M.det,0,1.0,-1.75,1.9,.04,1.86,DARK);                                  // kasa tabanı (koyu kaplama)
    for(const s of [-1,1]){ box(M.paint,s*.99,1.17,-1.75,.1,.42,1.9,WH); box(M.paint,s*.97,1.54,-.82,.12,.45,.06,WH);
      box(M.paint,s*1.11,1.55,.88,.1,.14,.2,WH); box(M.det,s*1.1,1.48,.88,.04,.08,.1,DARK); box(M.det,s*1.045,.9,.55,.016,.5,.014,DARK); box(M.det,s*1.045,.9,-.2,.016,.5,.014,DARK);
      box(M.lt,s*.72,.98,2.62,.4,.16,.1,HL); box(M.lt,s*.92,1.12,-2.66,.14,.32,.05,TL); box(M.det,s*1.07,.55,1.0,.02,.1,1.2,TRIM); }
    box(M.paint,0,1.17,-2.63,1.9,.42,.08,WH); box(M.paint,0,1.17,-.8,1.88,.42,.08,WH);   // kasa kapağı ve ön duvar
    box(M.det,0,.78,2.66,1.4,.34,.05,DARK); box(M.det,0,.48,2.6,2.05,.18,.32,TRIM); box(M.det,0,.5,-2.7,1.9,.16,.14,TRIM); box(M.det,0,.62,-2.72,.5,.12,.02,PLATE); box(M.det,0,.62,2.7,.5,.12,.02,PLATE);
    wheels(M.det,1.0,[1.75,-1.65],.42,.32); TYPES[4]={M,W:2.1,L:5.35,H:1.93,name:"car_4"}; }
  /* 5: TAKSİ (sedan gövdesi + tavan lambası + damalı şerit; hep sarı) */
  { const M=mk(); sedan(M);
    box(M.det,0,1.5,-.28,.56,.07,.26,DARK); box(M.lt,0,1.585,-.28,.5,.11,.22,HL);
    for(const s of [-1,1]) for(let k=0;k<14;k++){ const z=-1.8+k*.26; box(M.det,s*.936,k%2?.56:.68,z,.022,.12,.26,DARK); }
    TYPES[5]={M,W:1.85,L:4.6,H:1.62,name:"car_5"}; }

  /* 6: AMBULANS (kamyonet gövdesi, beyaz; kırmızı şerit + haç + tepe ışıkları) */
  { const M=mk(), RED=hex("#d62020"), WHT=hex("#f2f2f2"), BLU=hex("#2a6bff"), RL=hex("#ff2a2a");
    loft(M.paint,[S(3.0,.92,.55,1.15),S(2.9,1.03,.42,1.30),S(2.4,1.08,.4,1.36),S(-2.9,1.1,.4,1.40),S(-3.0,1.05,.45,1.35)],WH);
    loft(M.paint,[S(1.2,1.04,1.30,2.46,.96),S(-2.9,1.06,1.30,2.50,.96),S(-3.0,1.0,1.30,2.40,.94)],WH);
    loft(M.det,[S(2.45,1.0,1.34,1.40,.9),S(1.9,1.0,1.34,1.95,.9),S(1.2,1.03,1.34,2.34,.92)],GLASS);
    for(const s of [-1,1]){ box(M.det,s*1.115,1.1,-.9,.02,.26,4.1,RED); box(M.det,s*1.112,1.46,-.9,.02,.07,4.1,RED);
      box(M.det,s*1.1,2.02,-1.7,.03,.82,.22,RED); box(M.det,s*1.1,2.02,-1.7,.03,.22,.82,RED); box(M.det,s*1.09,.9,-.2,.02,.03,5.6,TRIM);
      box(M.det,s*1.075,1.95,.25,.02,.46,1.0,GLASS);
      box(M.lt,s*.7,.95,3.0,.4,.2,.08,HL); box(M.lt,s*.85,1.05,-3.03,.16,.5,.06,TL); box(M.paint,s*1.18,1.7,1.5,.1,.3,.1,WH); }
    box(M.det,0,1.1,-3.04,1.8,.26,.02,RED); box(M.det,0,1.9,-3.04,.2,.8,.02,RED); box(M.det,0,1.9,-3.04,.8,.2,.02,RED);
    box(M.det,0,2.55,1.0,1.7,.1,.5,DARK); box(M.lt,-.55,2.64,1.0,.6,.14,.4,RL); box(M.lt,.55,2.64,1.0,.6,.14,.4,BLU);
    box(M.lt,-.9,.98,3.02,.2,.1,.06,RL); box(M.lt,.9,.98,3.02,.2,.1,.06,BLU);
    box(M.det,0,.7,3.0,1.3,.4,.06,DARK); box(M.det,0,.5,2.9,2.0,.2,.3,TRIM); box(M.det,0,.55,-3.05,2.0,.2,.15,TRIM); box(M.det,0,.7,-3.07,.5,.13,.02,PLATE);
    wheels(M.det,1.06,[1.95,-1.9],.42,.34); TYPES[6]={M,W:2.2,L:6.0,H:2.5,name:"car_6"}; }
  /* 7: POLİS ARABASI (sedan gövdesi; lacivert kapılar, beyaz kaput/tavan, çakar) */
  { const M=mk(), NAVYC=hex("#10204a"), RL=hex("#ff2a2a"), BLU=hex("#2a6bff"); sedan(M);
    for(const s of [-1,1]){ box(M.det,s*.945,.72,.05,.02,.42,1.5,NAVYC); box(M.det,s*.945,.72,-1.15,.02,.42,.9,NAVYC); box(M.det,s*.947,.55,.05,.02,.06,3.2,hex("#e8e8f0")); box(M.det,s*.7,1.0,1.5,.5,.02,.5,NAVYC); }
    box(M.det,0,1.5,-.3,1.1,.08,.34,DARK); box(M.lt,-.34,1.585,-.3,.4,.1,.28,RL); box(M.lt,.34,1.585,-.3,.4,.1,.28,BLU);
    box(M.lt,-.55,.62,2.24,.26,.06,.06,BLU); box(M.lt,.55,.62,2.24,.26,.06,.06,RL);
    TYPES[7]={M,W:1.85,L:4.6,H:1.65,name:"car_7"}; }
  /* 8: TANK (gövde + paletler; taret police.js içinde ayrı çizilir) */
  { const M=mk(), TRK=hex("#26282b"), TRK2=hex("#3b3e43"), rg=(cx,hw,yb,yt)=>ring(hw,yb,yt,.9).map(q=>[q[0]+cx,q[1]]), TS=(z,cx,hw,yb,yt)=>({z,ring:rg(cx,hw,yb,yt)});
    for(const sd of [-1,1]){ loft(M.det,[TS(3.62,sd*1.32,.42,.22,.82),TS(3.25,sd*1.32,.44,.06,1.2),TS(1.6,sd*1.32,.44,.04,1.18),TS(-1.6,sd*1.32,.44,.04,1.18),TS(-3.25,sd*1.32,.44,.06,1.2),TS(-3.62,sd*1.32,.42,.22,.82)],TRK);
      for(let k=0;k<6;k++) box(M.det,sd*1.76,.6,-2.6+k*1.04,.05,.72,.72,TRK2);
      box(M.paint,sd*1.5,1.3,0,.62,.07,6.7,WH); }
    loft(M.paint,[S(3.4,1.05,.6,.92,.9),S(2.7,1.5,.56,1.3,.88),S(1.6,1.6,.56,1.52),S(-1.6,1.6,.56,1.52),S(-3.1,1.5,.58,1.42),S(-3.55,1.2,.6,1.1)],WH);
    box(M.det,0,1.34,-3.42,2.3,.5,.14,DARK); box(M.det,0,1.56,-2.25,2.1,.08,1.5,TRIM);
    for(const sd of [-1,1]){ box(M.lt,sd*.82,1.12,3.52,.3,.14,.08,HL); box(M.lt,sd*.9,1.1,-3.56,.3,.1,.05,TL); }
    TYPES[8]={M,W:3.5,L:7.3,H:2.0,name:"car_8"}; }
  /* 9: HİPER ARABA (alçak kama gövde, kanat, yan hava girişleri, çift egzoz) */
  { const M=mk(), CF=hex("#16181c"), AIR=hex("#0b0c0e");
    loft(M.paint,[S(2.32,.70,.20,.33),S(2.16,.90,.17,.42),S(1.7,.99,.15,.52),S(1.0,1.01,.14,.60),S(.2,1.01,.14,.66),S(-.6,1.01,.14,.70),S(-1.4,1.03,.14,.74),S(-2.0,.99,.16,.74),S(-2.32,.84,.22,.66)],WH);
    cabin(M,[[.78,.78,.60,.64],[.38,.80,.60,.86],[-.12,.80,.62,1.06],[-.72,.78,.64,1.08],[-1.28,.82,.66,.95],[-1.8,.86,.68,.80]],[[.04,1.0],[-.14,1.085],[-.72,1.10],[-1.28,.97]],.56,[[.70,.64,.66,.62,.9,.2,.05]]);
    for(const s of [-1,1]){ box(M.det,s*1.0,.44,-.35,.05,.2,1.0,AIR); box(M.det,s*1.0,.30,.2,.05,.08,.5,AIR); box(M.det,s*.55,.27,2.2,.55,.07,.05,AIR); box(M.det,s*.4,.36,-2.32,.17,.13,.06,AIR); box(M.det,s*.4,.36,-2.345,.12,.08,.03,hex("#5a5e66"));
      box(M.paint,s*1.0,.99,-2.1,.04,.18,.46,WH); box(M.paint,s*.46,.88,-2.05,.07,.26,.09,WH); box(M.paint,s*.9,.82,.9,.1,.05,.2,WH);
      box(M.lt,s*.74,.40,2.16,.46,.035,.06,HL); box(M.lt,s*.52,.47,-2.3,.7,.05,.03,TL); }
    box(M.det,0,1.06,-2.1,1.96,.04,.4,CF); box(M.det,0,.14,2.2,1.9,.04,.42,CF); box(M.det,0,.4,-2.3,1.3,.1,.05,AIR); box(M.det,0,.52,2.31,.42,.1,.02,PLATE); box(M.det,0,.6,-2.33,.4,.09,.02,PLATE); box(M.det,0,.74,-.6,.5,.03,1.1,CF);
    wheels(M.det,.98,[1.45,-1.4],.34,.36,1.04); TYPES[9]={M,W:2.06,L:4.68,H:1.14,name:"car_9"}; }
  /* 10: KAS ARABA (uzun kaput, kısa kabin, krom tampon, yarış şeritleri) */
  { const M=mk(), CHR=hex("#d9dde3"), STR=hex("#f0f0f0"), AIR=hex("#0f1013");
    loft(M.paint,[S(2.46,.80,.42,.74),S(2.36,.92,.30,.88),S(2.0,.97,.28,.96),S(1.2,.98,.28,1.0),S(.6,.98,.28,1.02),S(-.6,.98,.28,1.04),S(-1.6,.98,.28,1.06),S(-2.2,.96,.30,1.04),S(-2.46,.88,.36,.98)],WH);
    cabin(M,[[.62,.80,.98,1.02],[.22,.80,.98,1.26],[-.3,.78,1.0,1.38],[-.9,.78,1.0,1.38],[-1.4,.80,1.0,1.28],[-1.88,.84,1.02,1.12]],[[.16,1.32],[-.3,1.395],[-.9,1.395],[-1.4,1.3]],.58,[[.74,1.0,.52,.66,1.32,-.2,.07],[.8,1.0,-1.4,.76,1.26,-1.9,.08]]);
    box(M.det,.2,.985,1.45,.17,.012,1.5,STR); box(M.det,-.2,.985,1.45,.17,.012,1.5,STR); box(M.det,.2,1.4,-.3,.17,.012,1.0,STR); box(M.det,-.2,1.4,-.3,.17,.012,1.0,STR); box(M.det,.2,1.075,-1.75,.17,.012,.9,STR); box(M.det,-.2,1.075,-1.75,.17,.012,.9,STR);
    box(M.det,0,1.04,1.35,.62,.09,.62,AIR); box(M.det,0,1.088,1.35,.5,.02,.5,hex("#30333a"));
    box(M.det,0,.4,2.46,1.9,.13,.1,CHR); box(M.det,0,.64,2.47,1.15,.22,.05,AIR); box(M.det,0,.64,2.49,1.25,.03,.03,CHR); box(M.det,0,.44,-2.46,1.9,.13,.1,CHR); box(M.det,0,.7,-2.5,.5,.12,.02,PLATE); box(M.det,0,.5,2.5,.5,.12,.02,PLATE);
    for(const s of [-1,1]){ box(M.lt,s*.66,.66,2.44,.26,.21,.06,HL); box(M.paint,s*1.0,.64,1.55,.05,.34,1.3,WH); box(M.paint,s*1.0,.66,-1.5,.05,.4,1.3,WH); box(M.det,s*.99,.34,-.3,.03,.09,1.5,CHR); box(M.lt,s*.66,.78,-2.46,.5,.17,.04,TL); box(M.paint,s*1.03,1.1,.62,.09,.07,.17,WH); box(M.det,s*.96,.76,.4,.016,.4,.014,AIR); box(M.det,s*.96,.76,-.7,.016,.4,.014,AIR); }
    wheels(M.det,.96,[1.62,-1.5],.38,.34,1.1); TYPES[10]={M,W:2.0,L:4.95,H:1.42,name:"car_10"}; }
  /* 11: DELTA KAMYONET (keskin kama gövde, ışık çubuğu, geniş jantlar) */
  { const M=mk(), AIR=hex("#101114"), rg6=(hw,yb,yt)=>[[-hw*.96,yb],[hw*.96,yb],[hw,yb+.28*(yt-yb)],[hw*.82,yt],[-hw*.82,yt],[-hw,yb+.28*(yt-yb)]], S6=(z,hw,yb,yt)=>({z,ring:rg6(hw,yb,yt)});
    loft(M.paint,[S6(2.74,.86,.48,.78),S6(2.56,1.0,.42,.94),S6(1.6,1.04,.40,1.28),S6(.8,1.04,.40,1.64),S6(.1,1.04,.40,1.95),S6(-1.2,1.04,.40,1.84),S6(-2.4,1.04,.42,1.42),S6(-2.74,1.0,.46,1.32)],WH);
    loft(M.det,[{z:1.9,ring:[[-.74,1.135],[.74,1.135],[.74,1.162],[-.74,1.162]]},{z:.18,ring:[[-.74,1.885],[.74,1.885],[.74,1.912],[-.74,1.912]]}],GLASS);
    box(M.det,0,1.9,-.55,1.5,.03,1.5,GLASS);
    for(const s of [-1,1]){ box(M.det,s*1.045,1.56,.5,.02,.38,1.7,GLASS); box(M.det,s*1.045,1.5,-1.35,.02,.3,.8,GLASS); box(M.det,s*1.06,.62,1.75,.07,.14,1.35,AIR); box(M.det,s*1.06,.62,-1.7,.07,.14,1.35,AIR); box(M.det,s*1.052,1.0,.1,.016,.9,.014,AIR); box(M.det,s*1.052,1.0,-1.15,.016,.9,.014,AIR); }
    box(M.lt,0,.82,2.74,1.7,.045,.04,HL); box(M.lt,0,1.18,-2.75,1.85,.05,.04,TL); box(M.det,0,.5,2.74,1.9,.2,.08,AIR); box(M.det,0,.5,-2.78,1.9,.2,.08,AIR); box(M.det,0,.78,-2.77,.5,.12,.02,PLATE); box(M.det,0,.62,2.79,.5,.12,.02,PLATE);
    wheels(M.det,1.05,[1.78,-1.72],.48,.4,1.12); TYPES[11]={M,W:2.12,L:5.5,H:2.0,name:"car_11"}; }
  const paintMat=new THREE.MeshStandardMaterial({color:0xffffff,roughness:.28,metalness:.32}), detMat=new THREE.MeshStandardMaterial({vertexColors:true,roughness:.5,metalness:.2}), ltMat=new THREE.MeshBasicMaterial({vertexColors:true});
  TYPES.forEach(T=>{ T.gP=finish(T.M.paint); T.gD=finish(T.M.det); T.gL=finish(T.M.lt); });
  /* ---- örnek kümesi: her araba bir tipe sahip, 3 örnekli ağ ---- */
  const WHITEC=new THREE.Color(1,1,1);
  function CarSet(list,typeOf){ const n=list.length, cnt=TYPES.map(()=>0); this.map=list.map((it,i)=>{ const t=typeOf(it,i); return {t,s:cnt[t]++}; });
    this.m=TYPES.map((T,t)=>{ const N=Math.max(1,cnt[t]), mk3=(g,mat,cast,colored)=>{ const m=new THREE.InstancedMesh(g,mat,N); if(colored){ for(let k=0;k<N;k++) m.setColorAt(k,WHITEC); } m.frustumCulled=false; m.castShadow=!!cast; m.receiveShadow=true; m.count=cnt[t]===0?0:N; for(let k=0;k<N;k++) U.hide(m.instanceMatrix.array,k); m.instanceMatrix.needsUpdate=true; scene.add(m); return m; };
      return {p:mk3(T.gP,paintMat,true,true),d:mk3(T.gD,detMat,true),l:mk3(T.gL,ltMat,false)}; });
    this.col=new THREE.Color(); this.dirty=new Set(); }
  CarSet.prototype.type=function(i){ return this.map[i].t; };
  CarSet.prototype.write=function(i,px,py,pz,q,sx,sy,sz,oy){ const e=this.map[i], m=this.m[e.t]; for(const k of ["p","d","l"]){ const mm=m[k]; U.writeMat(mm.instanceMatrix.array,e.s,px,py,pz,q,0,oy||0,0,0,0,sx,sy,sz); } this.dirty.add(e.t); };
  CarSet.prototype.color=function(i,rgb){ const e=this.map[i], p=this.m[e.t].p; this.col.setRGB(rgb.r!==undefined?rgb.r:rgb[0],rgb.g!==undefined?rgb.g:rgb[1],rgb.b!==undefined?rgb.b:rgb[2]); p.setColorAt(e.s,this.col); p.instanceColor.needsUpdate=true; };
  CarSet.prototype.flush=function(){ for(const t of this.dirty){ const m=this.m[t]; m.p.instanceMatrix.needsUpdate=m.d.instanceMatrix.needsUpdate=m.l.instanceMatrix.needsUpdate=true; } this.dirty.clear(); };
  CarSet.prototype.setLights=function(v){ ltMat.color.setScalar(v); };
  /* ölçek: tip ve araç boyutuna göre */
  function scaleFor(t,w,l,h){ const T=TYPES[t]; if(!w){ w=T.W; l=T.L; } return {sx:w/T.W, sz:l/T.L, sy:t===3?Math.max(.6,(h+.4)/T.H):1, H:t===3?Math.max(.6,(h+.4)/T.H)*T.H:T.H}; }
  Game.updaters.push(()=>{ ltMat.color.setScalar(.7+.7*(Game.night||0)); });
  return {TYPES,CarSet,scaleFor,GK:{MB,part,loft,box,bar,finish,ring,S,hex}};
})();
