"use strict";
/* ===== KIŞ (v12): yerde biriken kar, ayak izleri, kar yığınları, kışlık giyim, aile NPC'ler (ebeveyn + çocuk), gerçek kardan adam yapımı =====
   - Game.snowAcc (season.js): kış başlayınca .3, kar yağdıkça 1'e çıkar; yer/çatı kar örtüsü bu değerle koyulaşır.
   - Ayak izleri: tek InstancedMesh halka tamponu (420 iz). Kahraman yürürken, NPC'ler yürürken iz bırakır (kar ≥ .32).
   - Kar yığınları: ağaç / lamba / bank / çöp kutusu diplerinde, kar birikince büyür (tek InstancedMesh).
   - Aile: ebeveyn + 1-2 çocuk (küçük boy, canlı renkli mont); çocuklar ebeveynin arkasından "follow" durumuyla yürür, ebeveyn korkarsa dağılırlar.
   - Kardan adam: 1-3 NPC boş bir zemine gider, çömelip kar yığar (alt gövde → orta → kafa → kol/şapka/havuç); biter bitmez kırılabilir eşya olur (Game.Props). */
(function(){
const N=Game.NPC, NL=Game.NPCLife, W=Game.W, CG=Game.CG, FX=Game.FX, PR=Game.Props, ST=N.states, list=N.list, MP=Game.MAP, NS=N.scale, DM=Game.HumanKit.D;
const rnd=Math.random, TAU=Math.PI*2, pick=a=>a[(rnd()*a.length)|0], clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const norm=a=>Math.atan2(Math.sin(a),Math.cos(a));
const snowOn=()=>Game.season==="winter"||(MP&&MP.weather==="snow");
const acc=()=>(MP&&MP.weather==="snow")?1:(Game.season==="winter"?(Game.snowAcc===undefined?1:Game.snowAcc):0);
const hero=()=>Game.heroObj?Game.heroObj.position:{x:0,y:0,z:0};
const SAY=(n,cat,o)=>{ if(Game.Speech&&n) Game.Speech.say(n,cat,o); };
const lin=h=>new THREE.Color(h).convertSRGBToLinear();
const WCOL=["#8a2f2f","#2b3a6e","#1f1f24","#4a4f5c","#7a3f1d","#2f6a4a","#b22a2a","#e0e0e8","#6b4a8a","#c27a2a"].map(lin);
const KIDC=["#ff4d4d","#ffcc29","#3aa0ff","#ff7ac8","#46d17a","#ff8a3d","#a46cff","#f4f4f4"].map(lin);
const api={stats:{prints:0,built:0,broken:0,fams:0,kids:0,coats:0},prj:[],fams:[],slots:[]};
Game.Winter=api;
const optStage=()=>Game.Opt?Game.Opt.stage|0:0;

/* ================= AYAK İZLERİ ================= */
const FPN=420; let fpMesh=null, fpI=0, fpTot=0, fpDirty=false;
const M4=new THREE.Matrix4(), QQ=new THREE.Quaternion(), VV=new THREE.Vector3(), SS=new THREE.Vector3(1,1,1), UPV=new THREE.Vector3(0,1,0);
function buildPrints(){
  let tex=null; try{ const c=document.createElement("canvas"); c.width=32; c.height=64; const g=c.getContext("2d"); g.fillStyle="#000"; g.fillRect(0,0,32,64); g.fillStyle="#fff";
    g.beginPath(); g.ellipse(16,20,9,17,0,0,TAU); g.fill(); g.beginPath(); g.ellipse(16,51,6.5,9,0,0,TAU); g.fill(); tex=new THREE.CanvasTexture(c); }catch(e){ tex=null; }
  const geo=new THREE.PlaneGeometry(.22,.46); geo.rotateX(-Math.PI/2); geo.rotateY(Math.PI);
  const mat=Game.noSnow(new THREE.MeshStandardMaterial({color:0x7f8ba3,roughness:1,metalness:0,alphaTest:.5,polygonOffset:true,polygonOffsetFactor:-4,polygonOffsetUnits:-4}));
  if(tex) mat.alphaMap=tex;
  fpMesh=new THREE.InstancedMesh(geo,mat,FPN); fpMesh.count=0; fpMesh.frustumCulled=false; fpMesh.receiveShadow=true; fpMesh.castShadow=false; fpMesh.renderOrder=2; fpMesh.visible=false;
  if(fpMesh.instanceMatrix.setUsage) fpMesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage); scene.add(fpMesh); }
function putPrint(x,z,y,ang,side,sc){ if(!fpMesh) return false; const th=W.terrainH(x,z); if(th<(W.WATER_Y||0)+.12) return false;
  const gy=W.surfaceAt(x,z,y), c=Math.cos(ang), s=Math.sin(ang), o=.12*sc*side; x+=c*o; z-=s*o;
  QQ.setFromAxisAngle(UPV,ang); VV.set(x,gy+.045,z); SS.set(sc,1,sc); M4.compose(VV,QQ,SS); fpMesh.setMatrixAt(fpI,M4); fpI=(fpI+1)%FPN; if(fpTot<FPN){ fpTot++; fpMesh.count=fpTot; } fpDirty=true; api.stats.prints++; return true; }
function clearPrints(){ if(!fpMesh) return; fpI=0; fpTot=0; fpMesh.count=0; fpDirty=false; }
let hpx=null, hpz=null, hside=1;
function heroPrints(){ const H=Game.H, h=Game.heroObj; if(!H||!h) return; if(H.flying||!H.grounded||(Game.Mounted&&Game.Mounted())||H.dead){ hpx=null; return; }
  const p=h.position; if(hpx===null){ hpx=p.x; hpz=p.z; return; } const dx=p.x-hpx, dz=p.z-hpz, d=Math.hypot(dx,dz), step=(H.speed>14?1.2:.75); if(d<step) return; if(d>9){ hpx=p.x; hpz=p.z; return; }
  hside=-hside; putPrint(p.x,p.z,p.y,Math.atan2(dx,dz),hside,1.3); hpx=p.x; hpz=p.z; }
const MOVEST={walk:1,flee:1,chase:1,approach:1,follow:1};
function npcPrints(){ if(optStage()>=4) return; const hp=hero(); let budget=10;
  for(const n of list){ if(budget<=0) break; if(!n.vis||n.dead||!MOVEST[n.st]) continue; const dx0=n.x-hp.x, dz0=n.z-hp.z; if(dx0*dx0+dz0*dz0>3600) continue;
    if(n.fpx===undefined){ n.fpx=n.x; n.fpz=n.z; n.fps=1; continue; } const dx=n.x-n.fpx, dz=n.z-n.fpz, d=Math.hypot(dx,dz), k=(n.ht||NS)/NS, step=.62*k+.1; if(d<step) continue; if(d>6){ n.fpx=n.x; n.fpz=n.z; continue; }
    n.fps=-(n.fps||1); if(putPrint(n.x,n.z,n.y,Math.atan2(dx,dz),n.fps,.95*k)) budget--; n.fpx=n.x; n.fpz=n.z; } }

/* ================= KAR YIĞINLARI ================= */
let mound=null, mBase=[], mAcc=-1;
function buildMounds(){ const src=[], trees=(CG.lists&&CG.lists.trees)||[], stride=Math.max(2,Math.ceil(trees.length/650));
  for(let i=0;i<trees.length;i+=stride){ const t=trees[i]; src.push([t[0],t[1],.55+Math.min(.55,(t[2]||1)*.16),.24,rnd()*TAU,1]); }
  let cnt=0; const R={bench:[.95,.3,.2],bin:[.5,.5,.22],hydrant:[.42,.42,.18],mailbox:[.5,.5,.2],lamp:[.55,.55,.2]};
  for(const p of PR.list){ const r=R[p.kind]; if(!r||cnt>=520||p.y<-100) continue; src.push([p.x,p.z,r[0],r[2]+rnd()*.05,rnd()*TAU,p.kind==="bench"?r[1]/r[0]:1]); cnt++; }
  mBase=src; if(!src.length) return;
  mound=new THREE.InstancedMesh(new THREE.SphereGeometry(1,7,4),Game.noSnow(new THREE.MeshStandardMaterial({color:0xf0f5ff,roughness:.95})),src.length);
  mound.frustumCulled=false; mound.receiveShadow=true; mound.castShadow=false; mound.visible=false; if(mound.instanceMatrix.setUsage) mound.instanceMatrix.setUsage(THREE.DynamicDrawUsage); scene.add(mound); setMounds(0); }
function setMounds(a){ if(!mound) return; mAcc=a; const k=Math.pow(clamp((a-.25)/.75,0,1),1.3);
  for(let i=0;i<mBase.length;i++){ const b=mBase[i], gy=W.terrainH(b[0],b[1]), r=b[2]*(.55+.45*k), h=Math.max(.001,b[3]*k); QQ.setFromAxisAngle(UPV,b[4]); VV.set(b[0],gy-.03,b[1]); SS.set(r,h,r*b[5]); M4.compose(VV,QQ,SS); mound.setMatrixAt(i,M4); }
  mound.instanceMatrix.needsUpdate=true; }

/* ================= KIŞLIK GİYİM ================= */
const KEYS=["sl","sh","sk","dr","coat","coatc","hat","hatc","hs","ht","wd","old","cane","bd","gl","tie","wt","bg","pk","packc","shirt"];
const snap=n=>{ const o={}; for(const k of KEYS) o[k]=n[k]; return o; };
const hatHs=(hat,hs,g)=>hat&&!(hs===1||hs===3||hs===4||hs===8)?(g?1:0):hs;
function winterize(n){ if(n.wst||n.role==="cop"||n.role==="medic"||n.kid) return; if(!n.w0) n.w0=snap(n);
  const hat=rnd()<.55?3:(n.hat||(rnd()<.12?1:0));
  N.look(n,{sl:0,sh:0,sk:n.sk&&rnd()<.5?0:n.sk,coat:rnd()<.9?1:0,coatc:pick(WCOL),hat,hatc:pick(WCOL),hs:hatHs(hat,n.hs,n.g)}); n.wst=1; api.stats.coats++; }
function unwinterize(n){ if(!n.wst&&!n.kid) return; if(n.w0) N.look(n,n.w0); n.w0=null; n.wst=0; n.kid=0; if(n.fid&&n.st==="follow") endFollow(n,true); n.fid=0; n.par=null; }
let sweepI=0;
function sweep(on){ const n0=list.length; for(let k=0;k<8&&n0;k++){ sweepI=(sweepI+1)%n0; const n=list[sweepI]; if(!n) continue; if(on){ if(!n.wst&&!n.kid&&n.vis!==undefined) winterize(n); } else if(n.wst||n.kid) unwinterize(n); } }

/* ================= AİLE: ebeveyn + çocuk ================= */
const FAMS=api.fams; let fidc=0;
const BADS={shock:1,flee:1,rag:1,dead:1,hurt:1,held:1,burn:1,gone:1,carried:1};
function endFollow(n,quiet){ n.par=null; n.fid=0; if(n.st==="follow") NL.resume(n); }
ST.follow={ move:true, shy:true,
  update(n,dt){ const p=n.par; if(!p||p.fid!==n.fid||!p.vis||p.dead){ endFollow(n); return; }
    if(Math.hypot(n.x-p.x,n.z-p.z)>28){ endFollow(n); return; }
    if(BADS[p.st]){ endFollow(n); if(Game.mode==="play"){ const hp=hero(); N.alert(n.x,n.z,.6,hp.x,hp.z); } return; }
    const f=Math.sin(p.ang), g=Math.cos(p.ang), fo=n.fo|0, bk=1.0+fo*.55, sd=(fo%2?1:-1)*.55, tx=p.x-f*bk+g*sd, tz=p.z-g*bk-f*sd, dx=tx-n.x, dz=tz-n.z, d=Math.hypot(dx,dz);
    const moving=p.st==="walk"||p.st==="approach"; let sp=0; if(d>.18) sp=Math.min(6.5,(moving?(p.spd||1.5):1.2)*(.8+Math.min(1.6,d*.7)));
    if(sp>0){ const step=Math.min(sp*dt,d); n.x+=dx/d*step; n.z+=dz/d*step; if(Game.Trees&&Game.Trees.avoid) Game.Trees.avoid(n,dx/d,dz/d,step); n.y=W.surfaceAt(n.x,n.z,60); n.anim+=dt*sp*3.1; n.ang+=norm(Math.atan2(dx,dz)-n.ang)*(1-Math.exp(-9*dt)); }
    else { n.anim+=dt; n.ang+=norm(Math.atan2(p.x-n.x,p.z-n.z)-n.ang)*(1-Math.exp(-5*dt)); n.y=W.surfaceAt(n.x,n.z,60); } n.spd=sp; },
  pose(n,P0,T,i,spd,loco,ph){ const p=n.par, play=p&&p.st==="snowbuild"&&Math.hypot(p.x-n.x,p.z-n.z)<3.5&&spd<.3;
    if(play){ loco(0,0); crouch(n,P0,T,i,.7); return; }
    loco(Math.min(1,spd/1.8),ph); P0.bob+=Math.abs(Math.sin(n.anim*1.5))*.02*NS; if(spd<.3){ P0.turn=Math.sin(T*.8+i)*.35; P0.shL=-.1+Math.sin(T*2+i)*.1; } } };
function kidify(m,par,idx){ if(!m.w0) m.w0=snap(m); const hat=rnd()<.8?3:0;
  N.look(m,{ht:(.56+rnd()*.12)*NS,wd:(.62+rnd()*.1)*NS,old:0,cane:0,bd:0,gl:rnd()<.1?1:0,tie:0,wt:0,bg:0,sl:0,sh:0,sk:0,dr:0,coat:1,coatc:pick(KIDC),hat,hatc:pick(KIDC),hs:hatHs(hat,m.hs,m.g),shirt:pick(KIDC),pk:rnd()<.65?1:0,packc:pick(KIDC)});
  m.wst=1; m.kid=1; m.par=par; m.fid=par.fid; m.fo=idx; if(m.seat||m.goal||m.phone) N.cancel(m,true);
  const a=par.ang+Math.PI*(.7+.6*idx), r=.9+idx*.4; m.x=par.x+Math.sin(a)*r; m.z=par.z+Math.cos(a)*r; m.y=W.surfaceAt(m.x,m.z,60); m.nix=par.nix; m.pix=par.pix; m.ang=par.ang; m.st="follow"; m.t=0; m.spd=par.spd||1.5; m.path=null; m.goal=null; m.fpx=undefined; api.stats.kids++; }
function tryFamily(force){ const hp=hero(), cand=[];
  for(const m of list){ if(!m.vis||m.st!=="walk"||m.goal||m.role||m.thief||m.golden||m.fid||m.kid||m.dead||m.phone) continue; const d=Math.hypot(m.x-hp.x,m.z-hp.z); if(force||(d>55&&d<125)) cand.push(m); }
  if(!cand.length) return null; const par=pick(cand), nk=1+(rnd()<.45?1:0), kids=[];
  for(const m of list){ if(kids.length>=nk) break; if(m===par||!m.vis||m.st!=="walk"||m.goal||m.role||m.thief||m.golden||m.fid||m.kid||m.dead) continue; if(!force&&Math.hypot(m.x-hp.x,m.z-hp.z)<75) continue; kids.push(m); }
  if(!kids.length) return null; if(!par.wst) winterize(par); par.fid=++fidc; kids.forEach((k,i)=>kidify(k,par,i));
  const f={id:par.fid,p:par,kids,say:6+rnd()*10}; FAMS.push(f); api.stats.fams++; return f; }
function famTick(dt){ if(FAMS.length<4&&snowOn()&&Game.mode==="play"){ famT-=dt; if(famT<=0){ famT=7+rnd()*8; tryFamily(false); } }
  for(let i=FAMS.length-1;i>=0;i--){ const f=FAMS[i], p=f.p;
    if(!p||p.fid!==f.id||!p.vis||p.dead||!snowOn()){ for(const k of f.kids) if(k.fid===f.id) endFollow(k); if(p&&p.fid===f.id) p.fid=0; FAMS.splice(i,1); continue; }
    f.kids=f.kids.filter(k=>k.fid===f.id&&k.vis&&!k.dead&&k.kid); if(!f.kids.length){ p.fid=0; FAMS.splice(i,1); continue; }
    for(const k of f.kids){ if(k.st==="walk"&&!k.goal){ if(Math.hypot(k.x-p.x,k.z-p.z)<30){ k.par=p; k.st="follow"; k.t=0; } else { k.fid=0; k.par=null; } } }
    f.say-=dt; if(f.say<=0){ f.say=18+rnd()*25; const hp=hero(); if(Game.mode==="play"&&Math.hypot(p.x-hp.x,p.z-hp.z)<30) rnd()<.5?SAY(p,"famk"):SAY(pick(f.kids),"kidsnow"); } } }
let famT=6;

/* ================= KARDAN ADAM ================= */
const SC=Math.max(.75,NS*.74), SLOTS=10, ZERO16=new Float32Array(16); ZERO16[15]=1;
const rg=()=>CG.rig();
function gBot(){ const r=rg(); r.ball(0,.5,0,.64,.58,.64,"#f2f6fc",12); return r.geo(); }
function gMid(){ const r=rg(); r.ball(0,1.3,0,.47,.43,.47,"#f6f9ff",12); for(let k=0;k<3;k++) r.ball(0,1.46-k*.22,.455-k*.02,.045,.045,.03,"#1c1c20",5); r.cyl(0,1.72,0,.36,.33,.1,12,"#c0282d"); r.box(.2,1.55,.3,.1,.34,.06,"#c0282d",{rz:.2}); return r.geo(); }
function gHead(){ const r=rg(); r.ball(0,1.98,0,.34,.32,.34,"#f8fbff",12); r.ball(-.12,2.04,.3,.04,.04,.03,"#15151a",5); r.ball(.12,2.04,.3,.04,.04,.03,"#15151a",5); r.cyl(0,1.96,.4,.055,0,.3,6,"#ff7a1a",{rx:Math.PI/2});
  for(let k=0;k<5;k++){ const a=-.7+k*.35; r.ball(Math.sin(a)*.17,1.88,.3,.025,.025,.02,"#15151a",4); } r.cyl(0,2.31,0,.2,.2,.3,10,"#1c1c20"); r.cyl(0,2.17,0,.34,.34,.04,12,"#1c1c20"); r.cyl(0,2.2,0,.205,.205,.06,10,"#7a1f23"); return r.geo(); }
function gArms(){ const r=rg(); r.bar(-.4,1.4,0,-1.05,1.75,.05,.05,"#5b3a1e"); r.bar(-.8,1.62,.02,-.95,1.95,.04,.035,"#5b3a1e"); r.bar(.4,1.4,0,1.05,1.62,-.05,.05,"#5b3a1e"); r.bar(.8,1.52,-.02,.95,1.28,-.05,.035,"#5b3a1e"); return r.geo(); }
const SMESH=[]; const CEN=[0,1.3,1.98,1.4];
function buildSnowmen(){ const gs=[gBot(),gMid(),gHead(),gArms()];
  for(let j=0;j<4;j++){ const m=new THREE.InstancedMesh(gs[j],CG.rigMat,SLOTS); if(Game.ensureIC) Game.ensureIC(m); /* CG.rigMat NPC meshleriyle paylaşılır: renk tamponu şart (r128) */ m.frustumCulled=false; m.castShadow=true; m.receiveShadow=true; if(m.instanceMatrix.setUsage) m.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    for(let k=0;k<SLOTS;k++) m.instanceMatrix.array.set(ZERO16,k*16); m.instanceMatrix.needsUpdate=true; scene.add(m); SMESH.push(m); }
  for(let k=0;k<SLOTS;k++){ const parts=SMESH.map(m=>[m,k]); const p=PR.reg("snowman",3000,-500,3000,0,.64*SC,1.25*SC,.64*SC,.3,parts,{deb:CG.C("#f2f6ff"),snd:.1,big:0}); p.alive=false; p.cy=-500+1.25*SC;
    api.slots.push({k,prop:p,used:false,x:0,z:0,rot:rnd()*TAU,pr:null,born:0,said:0}); } }
const ease=(a,b,p)=>{ const t=clamp((p-a)/(b-a),0,1); return t*t*(3-2*t); };
function writeSnowman(pr){ const s=pr.slot, p=pr.prog, v=[p<=0?0:.15+.85*ease(0,.36,p),ease(.3,.62,p),ease(.58,.86,p),ease(.86,1,p)];
  for(let j=0;j<4;j++){ const sc=Math.max(.0001,v[j]*SC); QQ.setFromAxisAngle(UPV,s.rot); VV.set(pr.x,pr.gy-.03+CEN[j]*SC*(1-v[j]),pr.z); SS.set(sc,sc,sc); M4.compose(VV,QQ,SS); SMESH[j].setMatrixAt(s.k,M4); SMESH[j].instanceMatrix.needsUpdate=true; } }
function clearSlot(s){ for(let j=0;j<SMESH.length;j++){ SMESH[j].instanceMatrix.array.set(ZERO16,s.k*16); SMESH[j].instanceMatrix.needsUpdate=true; } s.prop.saved=null; PR.relocate(s.prop,3000,-500,3000,false); s.used=false; s.pr=null; s.said=0; }
function freeSlot(){ for(const s of api.slots) if(!s.used) return s; const hp=hero(); let best=null; for(const s of api.slots){ if(s.pr&&!s.pr.done) continue; if(Math.hypot(s.x-hp.x,s.z-hp.z)<70) continue; if(!best||s.born<best.born) best=s; } if(best) clearSlot(best); return best; }
const bl=Game.buildings||[];
const inBld=(x,z,pad)=>{ for(const e of bl){ if(!e||e.h<=0) continue; if(Math.abs(x-e.x)<e.hw+pad&&Math.abs(z-e.z)<e.hd+pad) return true; } return false; };
function okSpot(x,z,from){ const th=W.terrainH(x,z); if(th<(W.WATER_Y||0)+.5) return false; if(Math.abs(W.terrainH(x+1.5,z)-th)>.5||Math.abs(W.terrainH(x,z+1.5)-th)>.5) return false; if(NL.onRoad(x,z)||inBld(x,z,3)) return false;
  for(const s of api.slots) if(s.used&&Math.hypot(s.x-x,s.z-z)<11) return false; if(N.blocked(from.x,from.z,x,z)) return false;
  const trees=(CG.lists&&CG.lists.trees)||[]; for(const t of trees) if(Math.abs(t[0]-x)<2.6&&Math.abs(t[1]-z)<2.6) return false; return true; }
const PRJ=api.prj; let nextBuild=18;
function buildFinish(n,g){ n.st="snowbuild"; n.t=0; n.prj=g.prj; n.ang=g.ang; }
function tryBuild(n,force){ if(PRJ.length>=2||(nextBuild>0&&!force)||!SMESH.length) return false; const hp=hero(); if(!force&&Math.hypot(n.x-hp.x,n.z-hp.z)>150) return false;
  let sx=0, sz=0, found=false; for(let k=0;k<10;k++){ const a=rnd()*TAU, r=6+rnd()*12; sx=n.x+Math.sin(a)*r; sz=n.z+Math.cos(a)*r; if(okSpot(sx,sz,n)){ found=true; break; } } if(!found) return false;
  const slot=freeSlot(); if(!slot) return false; const pr={x:sx,z:sz,gy:W.terrainH(sx,sz),t:0,prog:0,ms:[],slot,dur:34,done:false,doneT:0,said:0,fxT:0,upT:0,lead:n};
  const ms=[n], ex=NL.pickWalker(n,18); if(ex&&!ex.fid&&!ex.kid) ms.push(ex); const base=rnd()*TAU; let ok=0;
  ms.forEach((m,idx)=>{ const a=base+idx/ms.length*TAU, mx=sx+Math.sin(a)*1.4, mz=sz+Math.cos(a)*1.4, go={ang:Math.atan2(sx-mx,sz-mz),finish:buildFinish,spd:1.35,prj:pr};
    if(idx>0){ N.cancel(m,true); const mi=N.nearestFree(m.x,m.z); if(mi>=0){ m.nix=mi; m.pix=-1; } }
    if(NL.walkTo(m,mx,mz,go)){ pr.ms.push(m); ok++; } });
  if(!ok) return false; slot.used=true; slot.pr=pr; slot.x=sx; slot.z=sz; slot.rot=rnd()*TAU; slot.born=clock; slot.said=0; PRJ.push(pr); nextBuild=30+rnd()*40; return true; }
function finishPrj(pr){ pr.done=true; pr.prog=1; pr.doneT=3.4; writeSnowman(pr); const s=pr.slot; s.prop.saved=null; PR.relocate(s.prop,pr.x,pr.gy,pr.z,true); s.born=clock; api.stats.built++;
  const w=pr.ms.find(m=>m.st==="snowbuild"&&m.prj===pr); if(w) SAY(w,"snowd",{pri:2,range:60}); }
function abortPrj(pr){ if(pr.prog>.5&&!pr.done){ finishPrj(pr); return; } if(!pr.done) clearSlot(pr.slot); pr.dead=true; }
function tickPrj(dt){ nextBuild-=dt;
  for(let i=PRJ.length-1;i>=0;i--){ const pr=PRJ[i]; pr.t+=dt; pr.ms=pr.ms.filter(m=>m.vis&&!m.dead&&(m.st==="snowbuild"||m.st==="approach"||m.st==="walk")&&(m.prj===pr||(m.goal&&m.goal.prj===pr)));
    let arr=0; for(const m of pr.ms) if(m.st==="snowbuild"&&m.prj===pr) arr++;
    if(!pr.done){
      if(arr>0){ pr.prog=Math.min(1,pr.prog+dt/pr.dur*(.55+.45*arr)); pr.fxT-=dt; if(pr.fxT<=0){ pr.fxT=.5; if(FX&&FX.dust) FX.dust(pr.x,pr.gy+.3,pr.z,1,.45,[1,1,1]); } if(!pr.said&&pr.t>2){ pr.said=1; SAY(pr.lead,"snowb",{pri:1,range:50}); } }
      pr.upT-=dt; if(pr.upT<=0){ pr.upT=.1; writeSnowman(pr); }
      if(pr.prog>=1) finishPrj(pr); else if(pr.t>45&&arr===0||!pr.ms.length||!snowOn()) abortPrj(pr); }
    else { pr.doneT-=dt; if(pr.doneT<=0) pr.dead=true; }
    if(pr.dead){ for(const m of pr.ms){ if(m.prj===pr){ m.prj=null; if(m.st==="snowbuild") NL.resume(m); } } PRJ.splice(i,1); } }
  /* kırılan kardan adam: yakındaki biri üzülür */
  for(const s of api.slots){ if(!s.used||!s.pr||!s.pr.done) continue; if(!s.prop.alive&&!s.said){ s.said=1; api.stats.broken++; const hp=hero(); let b=null, bd=900; for(const m of list){ if(!m.vis||m.dead||m.st==="rag") continue; const d=(m.x-s.x)**2+(m.z-s.z)**2; if(d<bd){ bd=d; b=m; } } if(b&&Math.hypot(b.x-hp.x,b.z-hp.z)<45) SAY(b,"snowbk",{pri:2,delay:0}); } } }
function crouch(n,P0,T,i,amp){ const w=Math.sin(T*3+i*1.3); P0.lean=.75+.06*w; P0.hipL=1.0; P0.hipR=.85; P0.knL=1.7; P0.knR=1.6; P0.bob=-.38*n.ht*(amp>.9?1:.8); P0.abL=P0.abR=.2; P0.ankL=P0.ankR=.35; P0.nod=.35;
  P0.shL=-.3+w*.4*amp; P0.shR=-.3-w*.4*amp; P0.elL=.55; P0.elR=.5; P0.turn=Math.sin(T*.7+i)*.15; }
ST.snowbuild={ shy:true,
  update(n,dt){ const pr=n.prj; if(!pr||pr.dead){ n.prj=null; NL.resume(n); return; } n.anim+=dt; n.ang+=norm(Math.atan2(pr.x-n.x,pr.z-n.z)-n.ang)*(1-Math.exp(-6*dt)); },
  pose(n,P0,T,i,spd,loco){ loco(0,0); const pr=n.prj; if(pr&&pr.done){ P0.shL=-2.6+Math.sin(T*9+i)*.25; P0.shR=-2.6-Math.sin(T*9+i)*.25; P0.elL=P0.elR=.5; P0.nod=-.1; P0.bob=Math.abs(Math.sin(T*7+i))*.04; P0.turn=Math.sin(T*2+i)*.3; return; } crouch(n,P0,T,i,1); } };
{ const oi=N.onIdle; N.onIdle=function(n){ if(Game.mode==="play"&&snowOn()&&acc()>.55&&nextBuild<=0&&PRJ.length<2&&rnd()<(n.fid?.03:.012)){ if(tryBuild(n)) return true; } return oi?oi(n):false; }; }
{ const os=N.onSpawn; N.onSpawn=function(n){ n.wst=0; n.w0=null; n.kid=0; n.fid=0; n.par=null; n.prj=null; n.fpx=undefined; if(os) os(n); if(snowOn()&&n.st!=="sit") winterize(n); }; }

/* ================= ana güncelleyici ================= */
let clock=0, tPrint=0, tMound=0, wasOn=null;
Game.updaters.push((dt)=>{ if(Game.mode!=="play") return; dt=Math.min(dt,.1); clock+=dt; const on=snowOn(), a=acc();
  if(on!==wasOn){ wasOn=on; if(!on){ clearPrints(); hpx=null; } }
  if(fpMesh) fpMesh.visible=on&&a>=.32; if(mound) mound.visible=on;
  sweep(on);
  if(!on) return;
  tMound-=dt; if(mound&&tMound<=0){ tMound=1; if(Math.abs(a-mAcc)>.025) setMounds(a); }
  if(a>=.32){ tPrint-=dt; if(tPrint<=0){ tPrint=.05; heroPrints(); npcPrints(); if(fpDirty){ fpMesh.instanceMatrix.needsUpdate=true; fpDirty=false; } } }
  famTick(dt); tickPrj(dt); });
Game.onSeasonSet=function(s){ clearPrints(); hpx=null; if(!snowOn()){ for(const pr of PRJ.slice()) abortPrj(pr); } };
api.forceFamily=()=>tryFamily(true); api.forceBuild=n=>tryBuild(n,true); api.heroPrint=()=>{ const h=hero(); return putPrint(h.x,h.z,h.y,0,1,1.3); }; api.acc=acc;
try{ buildPrints(); buildMounds(); buildSnowmen(); }catch(e){ if(typeof console!=="undefined") console.warn("winter.js: kuruluş hatası",e&&e.message); }
})();
