"use strict";
/* ===== KAN SİSTEMİ: damlalar (balistik), zemin/duvar lekeleri, kan gölleri, atardamar fışkırması. +18 sansür açıkken tamamen kapalı. ===== */
Game.Gore=(function(){
  const W=Game.W, FX=Game.FX, D=Game.D, S=Game.settings, rs=()=>Math.random()-.5, R=(a,b)=>a+Math.random()*(b-a);
  const cens=()=>S.censor;
  const tex=(()=>{ const c=document.createElement("canvas"); c.width=c.height=128; const q=c.getContext("2d"); q.fillStyle="#fff"; q.strokeStyle="#fff";
    const blob=(x,y,r)=>{ q.beginPath(); for(let i=0;i<=16;i++){ const a=i/16*6.283, rr=r*(.75+Math.random()*.5), px=x+Math.cos(a)*rr, py=y+Math.sin(a)*rr; if(i) q.lineTo(px,py); else q.moveTo(px,py); } q.closePath(); q.fill(); };
    blob(64,64,24); for(let i=0;i<11;i++){ const a=Math.random()*6.283, d=22+Math.random()*30; blob(64+Math.cos(a)*d,64+Math.sin(a)*d,2+Math.random()*7); }
    for(let i=0;i<8;i++){ const a=Math.random()*6.283; q.lineWidth=2+Math.random()*3; q.beginPath(); q.moveTo(64+Math.cos(a)*18,64+Math.sin(a)*18); q.lineTo(64+Math.cos(a)*(44+Math.random()*18),64+Math.sin(a)*(44+Math.random()*18)); q.stroke(); }
    return new THREE.CanvasTexture(c); })();
  /* --- lekeler --- */
  const ND=220, dm=new THREE.MeshLambertMaterial({map:tex,transparent:true,depthWrite:false,polygonOffset:true,polygonOffsetFactor:-3,polygonOffsetUnits:-3}), decals=new THREE.InstancedMesh(new THREE.PlaneGeometry(1,1),dm,ND);
  decals.frustumCulled=false; decals.count=0; decals.receiveShadow=true; scene.add(decals);
  const dec=new Array(ND).fill(null), dum=new THREE.Object3D(), qa=new THREE.Quaternion(), qb=new THREE.Quaternion(), nv=new THREE.Vector3(), zv=new THREE.Vector3(0,0,1), colr=new THREE.Color();
  for(let i=0;i<ND;i++) decals.setColorAt(i,colr.setRGB(.4,.01,.02));   /* instanceColor baştan var olmalı (r128: program ilk çizimde sabitlenir) */
  let dHead=0, dCnt=0;
  function writeDecal(i){ const d=dec[i]; dum.position.set(d.x,d.y,d.z); dum.quaternion.copy(d.q); dum.scale.set(d.s,d.s,1); dum.updateMatrix(); decals.setMatrixAt(i,dum.matrix); decals.instanceMatrix.needsUpdate=true; }
  function addDecal(x,y,z,nx,ny,nz,size){ const i=dHead; dHead=(dHead+1)%ND; dCnt=Math.min(ND,dCnt+1);
    nv.set(nx,ny,nz); qa.setFromUnitVectors(zv,nv); qb.setFromAxisAngle(zv,Math.random()*6.283); qa.multiply(qb);
    dec[i]={x:x+nx*.015,y:y+ny*.015,z:z+nz*.015,q:qa.clone(),s:size}; writeDecal(i);
    colr.setRGB(R(.3,.5),R(.005,.02),R(.01,.03)); decals.setColorAt(i,colr); if(decals.instanceColor) decals.instanceColor.needsUpdate=true; decals.count=dCnt; return i; }
  /* --- damlalar --- */
  const NDR=340, X=new Float32Array(NDR),Y=new Float32Array(NDR),Z=new Float32Array(NDR),VX=new Float32Array(NDR),VY=new Float32Array(NDR),VZ=new Float32Array(NDR),SZ=new Float32Array(NDR);
  let drN=0; const drops=new THREE.InstancedMesh(new THREE.CylinderGeometry(.5,.5,1,5),new THREE.MeshLambertMaterial({color:0x6a0508}),NDR); drops.frustumCulled=false; drops.count=0; scene.add(drops);
  const UPv=new THREE.Vector3(0,1,0), dv=new THREE.Vector3();
  function drop(x,y,z,vx,vy,vz,s){ if(drN>=NDR) return; const i=drN++; X[i]=x;Y[i]=y;Z[i]=z;VX[i]=vx;VY[i]=vy;VZ[i]=vz;SZ[i]=s; }
  const rr={}, pools=[], bleeders=[];
  function stepDrops(dt){ const hp=Game.heroObj?Game.heroObj.position:{x:0,z:0}, hx=hp.x, hz=hp.z;
    for(let i=0;i<drN;){ VY[i]-=24*dt; const nx=X[i]+VX[i]*dt, ny=Y[i]+VY[i]*dt, nz=Z[i]+VZ[i]*dt; let dead=false;
      const gy=W.surfaceAt(nx,nz,ny+.6);
      if(ny<=gy+.02){ if(gy>-1.05) addDecal(nx,gy,nz,0,1,0,SZ[i]*R(14,34)); dead=true; }
      else { const sp=Math.hypot(VX[i],VY[i],VZ[i]), L=sp*dt+.05; if(sp>2&&Math.abs(nx-hx)<80&&Math.abs(nz-hz)<80){ D.rayB(X[i],Y[i],Z[i],VX[i]/sp,VY[i]/sp,VZ[i]/sp,L,rr); if(rr.kind!=="none"&&rr.t<L){ addDecal(rr.x,rr.y,rr.z,rr.nx,rr.ny,rr.nz,SZ[i]*R(12,28)); dead=true; } } }
      if(dead){ const l=--drN; if(i!==l){ X[i]=X[l];Y[i]=Y[l];Z[i]=Z[l];VX[i]=VX[l];VY[i]=VY[l];VZ[i]=VZ[l];SZ[i]=SZ[l]; } continue; }
      X[i]=nx;Y[i]=ny;Z[i]=nz; i++; }
        for(let i=0;i<drN;i++){ const sp=Math.hypot(VX[i],VY[i],VZ[i])||1; dv.set(VX[i]/sp,VY[i]/sp,VZ[i]/sp); qa.setFromUnitVectors(UPv,dv); dum.position.set(X[i],Y[i],Z[i]); dum.quaternion.copy(qa); const len=Math.min(.45,sp*.012)+SZ[i]; dum.scale.set(SZ[i],len,SZ[i]); dum.updateMatrix(); drops.setMatrixAt(i,dum.matrix); }
    drops.count=drN; drops.instanceMatrix.needsUpdate=true; dum.quaternion.set(0,0,0,1); }
  const api={
    on:()=>!cens(),
    /* darbe kanı: konum, yön hızı, miktar (0..2) */
    hit(x,y,z,vx,vy,vz,amt){ if(cens()) return; amt=amt||1; const n=Math.round(10+22*amt), sp=Math.hypot(vx,vy,vz)||1;
      for(let i=0;i<n;i++){ const k=R(.1,.5)*sp+R(1,5)*amt; drop(x+rs()*.12,y+rs()*.12,z+rs()*.12,vx/sp*k+rs()*5*amt,vy/sp*k*.5+R(0,5)*amt+rs()*2,vz/sp*k+rs()*5*amt,R(.016,.04)); }
      for(let i=0;i<Math.round(6*amt);i++) FX.E(0,x,y,z,vx*.1+rs()*3,vy*.1+R(0,2),vz*.1+rs()*3,R(.35,.8),R(.25,.5),R(.7,1.1),[.5,.02,.03],[.28,.01,.02],.55,2,.94); },
    /* kopma/kesik: yüksek basınçlı fışkırma + sis */
    burst(x,y,z,vx,vy,vz,amt){ if(cens()) return; amt=amt||1; const n=Math.round(30*amt), sp=Math.hypot(vx,vy,vz)||1;
      for(let i=0;i<n;i++){ const k=R(.15,.7)*sp+R(2,9); drop(x+rs()*.2,y+rs()*.2,z+rs()*.2,vx/sp*k+rs()*7,vy/sp*k*.6+R(0,8),vz/sp*k+rs()*7,R(.02,.055)); }
      for(let i=0;i<Math.round(12*amt);i++) FX.E(0,x,y,z,rs()*6,R(0,4),rs()*6,R(.5,1.1),R(.4,.8),R(1.1,1.8),[.5,.02,.03],[.3,.01,.02],.6,1.5,.93); },
    /* ölü gövde altında büyüyen göl */
    pool(x,y,z,r,dur){ if(cens()) return; const i=addDecal(x,y,z,0,1,0,.3); pools.push({i,t:0,dur:dur||6,r}); },
    /* kesik yerinden atardamar: getter()→{x,y,z}|null */
    bleed(getter,vx,vy,vz,dur,power){ if(cens()) return; if(bleeders.length>=22) bleeders.shift(); bleeders.push({g:getter,vx,vy,vz,t:0,dur:dur||4,p:power||1,ph:0}); },
    clear(){ drN=0; dCnt=0; dHead=0; decals.count=0; pools.length=0; bleeders.length=0; drops.count=0; },
    splat(x,y,z,nx,ny,nz,size){ if(!cens()) addDecal(x,y,z,nx,ny,nz,size); }
  };
  Game.updaters.push((dt0,time,raw)=>{ const dt=raw||dt0;
    if(Game.mode==="menu"&&drN===0&&!pools.length&&!bleeders.length) return;
    for(let i=pools.length-1;i>=0;i--){ const p=pools[i]; p.t+=dt; const k=Math.min(1,p.t/p.dur), d=dec[p.i]; if(d){ d.s=p.r*(1-Math.pow(1-k,2)); writeDecal(p.i); } if(k>=1) pools.splice(i,1); }
    for(let i=bleeders.length-1;i>=0;i--){ const b=bleeders[i]; b.t+=dt; const pos=b.g(); if(!pos||b.t>b.dur){ bleeders.splice(i,1); continue; } const f=1-b.t/b.dur; b.ph+=dt*(2.4+1.5*f);
      const pulse=Math.max(0,Math.sin(b.ph*6.283))**3, n=Math.round((1+pulse*5)*b.p*(.35+f)); for(let k=0;k<n;k++){ const sp=(5+pulse*7)*f*b.p+1.5; drop(pos.x,pos.y,pos.z,b.vx*sp*.3+rs()*1.4,b.vy*sp*.3+R(.5,2.5)+pulse*3,b.vz*sp*.3+rs()*1.4,R(.014,.03)); } }
    stepDrops(dt); });
  return api;
})();
