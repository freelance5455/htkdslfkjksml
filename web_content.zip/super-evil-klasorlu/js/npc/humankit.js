"use strict";
/* ===== İNSAN MODELİ (NPC): gövde, kalça, kafa (yüz detaylı), 3 saç, şapka, gözlük, sırt çantası, etek, eklemli kol/bacak, ayakkabı, yara ===== */
Game.HumanKit=(function(){
  const GK=Game.CarKit.GK, MB=GK.MB, WH=[1,1,1], hex=GK.hex;
  /* tüp: y ekseni boyunca eliptik halkalar. st: {y,rx,rz,cx,cz,c} ; c = istasyon rengi (köşe rengi) */
  function tube(b,st,seg,caps,color){ const pos=[],idx=[]; const n=st.length;
    for(let i=0;i<n;i++){ const s=st[i]; for(let j=0;j<seg;j++){ const a=j/seg*6.28319; pos.push((s.cx||0)+s.rx*Math.cos(a),s.y,(s.cz||0)+s.rz*Math.sin(a)); } }
    for(let i=0;i<n-1;i++) for(let j=0;j<seg;j++){ const j2=(j+1)%seg, a=i*seg+j,b2=i*seg+j2,c=(i+1)*seg+j2,d=(i+1)*seg+j; idx.push(a,b2,c,a,c,d); }
    if(caps!==false) for(const si of [0,n-1]){ const s=st[si], base=pos.length/3; pos.push(s.cx||0,s.y,s.cz||0); for(let j=0;j<seg;j++){ const a=j/seg*6.28319; pos.push((s.cx||0)+s.rx*Math.cos(a),s.y,(s.cz||0)+s.rz*Math.sin(a)); } for(let j=0;j<seg;j++) idx.push(base,base+1+j,base+1+(j+1)%seg); }
    const start=b.c.length; GK.part(b,pos,idx,color||WH);
    for(let i=0;i<n;i++) if(st[i].c) for(let j=0;j<seg;j++){ const o=start+(i*seg+j)*3; b.c[o]=st[i].c[0]; b.c[o+1]=st[i].c[1]; b.c[o+2]=st[i].c[2]; } }
  const ST=(y,rx,rz,cx,cz,c)=>({y,rx,rz,cx,cz,c});
  const DK=hex("#2a1c14"), BELT=[.16,.14,.13], BROW=[.18,.12,.1], MOUTH=[.5,.2,.2], SOLE=[.12,.12,.12], GLASS=hex("#07090d"), PACKD=[.75,.75,.75];
  const G={};
  /* gövde: yaka ve kemer çizgisi köşe renkleri */
  { const b=MB(); tube(b,[ST(.955,.14,.10,0,0,BELT),ST(.99,.146,.102,0,0,BELT),ST(1.04,.15,.105),ST(1.14,.165,.11),ST(1.26,.19,.12,0,.005),ST(1.36,.213,.114),ST(1.42,.2,.1),ST(1.47,.085,.07),ST(1.5,.045,.05)],10,true); G.torso=b; }
  { const b=MB(); tube(b,[ST(.78,.1,.08),ST(.86,.155,.105),ST(.95,.165,.11),ST(1.02,.15,.105)],10,true); G.hips=b; }
  { const b=MB(); tube(b,[ST(.93,.15,.11),ST(.78,.2,.15),ST(.62,.235,.18),ST(.55,.25,.19)],12,false); tube(b,[ST(.9,.12,.09)],12,true); G.skirt=b; }
  /* kafa: boyun + kafatası, yüz hatları (kafa merkezi y=0) */
  { const b=MB(); tube(b,[ST(-.2,.05,.05,0,-.015),ST(-.12,.05,.052,0,-.015),ST(-.115,.045,.06,0,.03),ST(-.09,.07,.085,0,.01),ST(-.04,.088,.10,0,0),ST(.03,.092,.105,0,-.005),ST(.08,.082,.098,0,-.01),ST(.115,.055,.07,0,-.01),ST(.13,.02,.03,0,-.01)],12,true);
    GK.box(b,-.04,.02,.098,.024,.016,.014,DK); GK.box(b,.04,.02,.098,.024,.016,.014,DK);
    GK.box(b,-.04,.047,.098,.036,.008,.012,BROW); GK.box(b,.04,.047,.098,.036,.008,.012,BROW);
    GK.box(b,0,-.012,.112,.02,.044,.03,WH); GK.box(b,0,-.062,.098,.05,.011,.012,MOUTH);
    GK.box(b,-.093,-.005,0,.014,.04,.03,WH); GK.box(b,.093,-.005,0,.014,.04,.03,WH); G.head=b; }
  { const b=MB(); tube(b,[ST(.0,.098,.11,0,-.004),ST(.05,.1,.112,0,-.006),ST(.09,.09,.102,0,-.01),ST(.123,.062,.076,0,-.01),ST(.14,.022,.032,0,-.01)],12,false); GK.box(b,0,.09,.098,.19,.04,.04,WH); G.hairS=b; }
  { const b=MB(); tube(b,[ST(.0,.098,.11,0,-.004),ST(.05,.1,.112,0,-.006),ST(.09,.09,.102,0,-.01),ST(.123,.062,.076,0,-.01),ST(.14,.022,.032,0,-.01)],12,false); GK.box(b,0,.09,.098,.19,.04,.04,WH);
    tube(b,[ST(.07,.098,.05,0,-.085),ST(-.04,.1,.052,0,-.088),ST(-.17,.092,.05,0,-.09),ST(-.31,.07,.035,0,-.085)],10,true); G.hairL=b; }
  { const b=MB(); tube(b,[ST(-.03,.12,.13,0,-.006),ST(.05,.14,.15,0,-.008),ST(.12,.125,.138,0,-.01),ST(.18,.075,.085,0,-.01),ST(.205,.025,.035,0,-.01)],12,false); G.hairC=b; }
  { const b=MB(); tube(b,[ST(.03,.103,.115,0,-.004),ST(.09,.094,.107,0,-.01),ST(.128,.058,.074,0,-.01),ST(.145,.022,.03,0,-.01)],12,false); GK.box(b,0,.04,.142,.15,.012,.1,WH); G.hat=b; }
  { const b=MB(); GK.box(b,-.042,.02,.112,.056,.036,.014,GLASS); GK.box(b,.042,.02,.112,.056,.036,.014,GLASS); GK.box(b,0,.025,.112,.03,.008,.012,GLASS); GK.box(b,-.09,.025,.06,.01,.008,.1,GLASS); GK.box(b,.09,.025,.06,.01,.008,.1,GLASS); G.glass=b; }
  { const b=MB(); GK.box(b,0,1.2,-.17,.28,.36,.12,WH); GK.box(b,0,1.14,-.235,.2,.2,.03,PACKD); GK.box(b,-.1,1.25,-.1,.04,.3,.02,[.3,.3,.3]); GK.box(b,.1,1.25,-.1,.04,.3,.02,[.3,.3,.3]); G.pack=b; }
  /* kollar: yerel başlangıç eklem noktası, aşağı doğru uzanır */
  { const b=MB(); tube(b,[ST(.02,.045,.048),ST(0,.05,.052),ST(-.14,.046,.048),ST(-.29,.04,.042)],8,true); G.uArm=b; }
  { const b=MB(); tube(b,[ST(.0,.04,.04),ST(-.12,.037,.039),ST(-.26,.029,.03)],8,true); G.fArm=b; }
  { const b=MB(); tube(b,[ST(.01,.028,.016),ST(-.04,.036,.02),ST(-.09,.026,.013),ST(-.105,.01,.008)],8,true); GK.box(b,.026,-.035,.01,.014,.05,.02,WH); G.hand=b; }
  { const b=MB(); tube(b,[ST(.02,.088,.09),ST(0,.092,.095),ST(-.12,.087,.092),ST(-.28,.074,.078),ST(-.42,.06,.062)],9,true); G.thigh=b; }
  { const b=MB(); tube(b,[ST(.0,.06,.062),ST(-.09,.062,.072,0,-.012),ST(-.25,.05,.056,0,-.006),ST(-.415,.04,.04)],9,true); G.shin=b; }
  { const b=MB(); GK.box(b,0,-.03,.045,.088,.07,.2,WH); GK.box(b,0,-.045,.15,.078,.04,.09,WH); GK.box(b,0,-.062,.06,.092,.014,.27,SOLE); G.shoe=b; }
  { const b=MB(); tube(b,[ST(-.5,.0,.0),ST(-.3,.7,.7),ST(0,1,1),ST(.3,.7,.7),ST(.5,0,0)],8,false); G.wound=b; }

  /* ===== v7: çeşitlilik parçaları (kadın gövdesi/kafası, 7 saç stili, 3 sakal, gözlük, şapkalar, saat, çanta, kravat, ceket, baston, telefon) ===== */
  /* kısmi halka: yalnızca a0..a1 açı aralığı (0=+x, π/2=+z ön, π=-x, 3π/2=-z arka) */
  function tubeArc(b,st,a0,a1,seg,color){ const pos=[],idx=[],n=st.length,w=seg+1;
    for(let i=0;i<n;i++){ const s=st[i]; for(let j=0;j<=seg;j++){ const a=a0+(a1-a0)*j/seg; pos.push((s.cx||0)+s.rx*Math.cos(a),s.y,(s.cz||0)+s.rz*Math.sin(a)); } }
    for(let i=0;i<n-1;i++) for(let j=0;j<seg;j++){ const a=i*w+j,b2=i*w+j+1,c=(i+1)*w+j+1,d=(i+1)*w+j; idx.push(a,b2,c,a,c,d); }
    const start=b.c.length; GK.part(b,pos,idx,color||WH);
    for(let i=0;i<n;i++) if(st[i].c) for(let j=0;j<w;j++){ const o=start+(i*w+j)*3; b.c[o]=st[i].c[0]; b.c[o+1]=st[i].c[1]; b.c[o+2]=st[i].c[2]; } }
  const LIPS=[.7,.16,.22], LASH=[.05,.04,.04], CUFF=[.62,.62,.62], DIAL=[.12,.13,.16], BAND=[.5,.5,.5];
  /* kadın: omuzlar dar, bel ince, göğüs ve kalça belirgin */
  { const b=MB(); tube(b,[ST(.955,.14,.10,0,0,BELT),ST(.99,.143,.1,0,0,BELT),ST(1.04,.138,.1),ST(1.12,.126,.096),ST(1.2,.14,.108,0,.006),ST(1.28,.16,.124,0,.018),ST(1.345,.185,.112),ST(1.40,.196,.1),ST(1.435,.17,.088),ST(1.47,.075,.066),ST(1.5,.045,.05)],10,true); G.torsoF=b; }
  { const b=MB(); tube(b,[ST(.78,.1,.08),ST(.86,.168,.108),ST(.95,.182,.113),ST(1.02,.146,.101)],10,true); G.hipsF=b; }
  { const b=MB(); tube(b,[ST(.93,.15,.11),ST(.7,.22,.16),ST(.5,.26,.19),ST(.3,.275,.2)],12,false); tube(b,[ST(.9,.12,.09)],12,true); G.skirtL=b; }
  { const b=MB(); tube(b,[ST(-.2,.045,.045,0,-.015),ST(-.12,.045,.048,0,-.015),ST(-.115,.04,.056,0,.03),ST(-.09,.063,.08,0,.012),ST(-.04,.085,.098,0,0),ST(.03,.09,.104,0,-.005),ST(.08,.081,.097,0,-.01),ST(.115,.055,.07,0,-.01),ST(.13,.02,.03,0,-.01)],12,true);
    GK.box(b,-.04,.02,.098,.03,.02,.014,DK); GK.box(b,.04,.02,.098,.03,.02,.014,DK);
    GK.box(b,-.04,.035,.1,.042,.007,.012,LASH); GK.box(b,.04,.035,.1,.042,.007,.012,LASH); GK.box(b,-.064,.03,.099,.012,.012,.012,LASH); GK.box(b,.064,.03,.099,.012,.012,.012,LASH);
    GK.box(b,-.04,.057,.098,.034,.006,.012,BROW); GK.box(b,.04,.057,.098,.034,.006,.012,BROW);
    GK.box(b,0,-.012,.11,.016,.04,.026,WH); GK.box(b,0,-.062,.098,.046,.016,.014,LIPS);
    GK.box(b,-.09,-.005,0,.014,.04,.03,WH); GK.box(b,.09,-.005,0,.014,.04,.03,WH); G.headF=b; }
  /* saç stilleri (ortak taban: kafatası kapağı) */
  const CAPST=()=>[ST(.0,.098,.11,0,-.004),ST(.05,.1,.112,0,-.006),ST(.09,.09,.102,0,-.01),ST(.123,.062,.076,0,-.01),ST(.14,.022,.032,0,-.01)];
  const fringe=b=>GK.box(b,0,.09,.098,.19,.04,.04,WH);
  { const b=MB(); tube(b,CAPST(),12,false); fringe(b); tube(b,[ST(.095,.03,.03,0,-.095),ST(.05,.04,.04,0,-.14),ST(-.04,.044,.044,0,-.175),ST(-.14,.04,.04,0,-.165),ST(-.24,.03,.03,0,-.145),ST(-.31,.012,.012,0,-.13)],8,true); GK.box(b,0,.05,-.125,.05,.02,.04,CUFF); G.hairP=b; }
  { const b=MB(); tube(b,CAPST(),12,false); fringe(b); tube(b,[ST(.13,.03,.03,0,-.06),ST(.16,.05,.05,0,-.06),ST(.2,.058,.058,0,-.06),ST(.24,.045,.045,0,-.06),ST(.265,.015,.015,0,-.06)],10,true); G.hairB=b; }
  { const b=MB(); tube(b,[ST(-.02,.125,.115,0,-.05),ST(.05,.152,.15,0,-.06),ST(.12,.165,.165,0,-.03),ST(.2,.15,.15,0,-.02),ST(.26,.1,.1,0,-.02),ST(.295,.03,.03,0,-.02)],14,false); G.hairA=b; }
  { const b=MB(); tube(b,CAPST().map(s=>Object.assign({},s,{c:[.42,.42,.42]})),12,false); for(let k=0;k<9;k++){ const u=k/8, z=.075-u*.17, h=.05+.09*Math.sin(u*Math.PI*.9+.15); GK.box(b,0,.115+h/2-.01,z,.026,h,.03,WH); } G.hairM=b; }
  { const b=MB(); tube(b,CAPST(),12,false); fringe(b); tubeArc(b,[ST(.05,.108,.122,0,-.012),ST(-.02,.116,.128,0,-.014),ST(-.1,.112,.122,0,-.012),ST(-.13,.1,.11,0,-.01)],.78*Math.PI,2.22*Math.PI,16); G.hairBob=b; }
  { const b=MB(); tube(b,CAPST(),12,false); fringe(b); for(const sx of [-1,1]){ tube(b,[ST(.06,.03,.03,sx*.1,-.02),ST(.02,.042,.042,sx*.135,-.03),ST(-.07,.046,.046,sx*.15,-.045),ST(-.17,.04,.04,sx*.15,-.05),ST(-.26,.028,.028,sx*.145,-.045),ST(-.31,.01,.01,sx*.14,-.04)],8,true); GK.box(b,sx*.125,.0,-.03,.03,.02,.03,CUFF); } G.hairPig=b; }
  { const b=MB(); tube(b,CAPST(),12,false); tube(b,[ST(.09,.07,.09,0,.025),ST(.14,.08,.1,0,.045),ST(.19,.065,.085,0,.05),ST(.225,.03,.045,0,.05),ST(.235,.01,.015,0,.05)],10,false); G.hairQ=b; }
  /* sakal: bıyık, keçi sakal, tam sakal */
  { const b=MB(); GK.bar(b,[-.046,-.04,.104],[0,-.031,.113],.017,WH); GK.bar(b,[.046,-.04,.104],[0,-.031,.113],.017,WH); GK.bar(b,[-.058,-.034,.098],[-.046,-.04,.104],.014,WH); GK.bar(b,[.058,-.034,.098],[.046,-.04,.104],.014,WH); G.stache=b; }
  { const b=MB(); GK.bar(b,[-.04,-.04,.106],[0,-.032,.113],.015,WH); GK.bar(b,[.04,-.04,.106],[0,-.032,.113],.015,WH); GK.box(b,0,-.095,.092,.05,.06,.034,WH); GK.box(b,0,-.125,.075,.034,.03,.03,WH); G.goat=b; }
  { const b=MB(); tubeArc(b,[ST(-.012,.099,.112,0,0),ST(-.05,.098,.111,0,0),ST(-.09,.08,.104,0,.012),ST(-.122,.052,.088,0,.03),ST(-.145,.02,.055,0,.042)],0,Math.PI,14);
    for(const sx of [-1,1]) GK.box(b,sx*.094,.008,.025,.012,.075,.075,WH);
    GK.bar(b,[-.046,-.04,.112],[0,-.031,.119],.016,WH); GK.bar(b,[.046,-.04,.112],[0,-.031,.119],.016,WH); GK.box(b,0,-.067,.114,.036,.012,.012,MOUTH); G.beardF=b; }
  /* yuvarlak çerçeveli gözlük */
  { const b=MB(); for(const sx of [-1,1]){ const x=sx*.042, y=.022, z=.113; GK.box(b,x,y+.025,z,.062,.006,.008,WH); GK.box(b,x,y-.025,z,.062,.006,.008,WH); GK.box(b,x-.03,y,z,.006,.05,.008,WH); GK.box(b,x+.03,y,z,.006,.05,.008,WH); GK.box(b,sx*.096,.03,.06,.006,.006,.1,WH); }
    GK.box(b,0,.032,.113,.026,.006,.008,WH); G.glassR=b; }
  /* şapkalar: bere ve geniş kenarlı */
  { const b=MB(); tube(b,[ST(-.025,.112,.124,0,-.004,CUFF),ST(.03,.114,.126,0,-.004,CUFF),ST(.035,.106,.118,0,-.006),ST(.1,.1,.115,0,-.01),ST(.16,.066,.078,0,-.01),ST(.2,.026,.032,0,-.01)],12,false);
    tube(b,[ST(.2,.03,.03,0,-.01),ST(.23,.042,.042,0,-.01),ST(.265,.03,.03,0,-.01),ST(.28,.01,.01,0,-.01)],8,true); G.hatB=b; }
  { const b=MB(); tube(b,[ST(.055,.103,.115,0,-.005,BAND),ST(.095,.099,.111,0,-.007,BAND),ST(.1,.097,.109,0,-.008),ST(.15,.09,.102,0,-.01),ST(.18,.072,.084,0,-.01),ST(.186,.02,.03,0,-.01)],12,true);
    tube(b,[ST(.062,.2,.215,0,-.005),ST(.054,.2,.215,0,-.005)],16,true); G.hatW=b; }
  /* saat (sol bilek, fArm yerel), el çantası (sağ bilek), kravat, ceket, baston, telefon */
  { const b=MB(); tube(b,[ST(-.187,.0395,.0395),ST(-.232,.04,.04)],10,false); GK.box(b,-.043,-.21,0,.014,.036,.036,WH); GK.box(b,-.051,-.21,0,.004,.027,.027,DIAL); G.watch=b; }
  { const b=MB(); GK.box(b,.0,-.43,.02,.08,.17,.23,WH); GK.box(b,.0,-.34,.02,.082,.014,.236,BAND); GK.bar(b,[0,-.348,-.06],[0,-.27,.0],.012,BAND); GK.bar(b,[0,-.27,.0],[0,-.348,.1],.012,BAND); G.bag=b; }
  { const b=MB(); GK.box(b,0,1.275,.124,.052,.115,.007,WH); GK.box(b,0,1.355,.122,.034,.07,.008,WH); GK.box(b,0,1.405,.118,.044,.036,.018,WH); G.tie=b; }
  { const b=MB(); tubeArc(b,[ST(.77,.2,.134),ST(.9,.2,.136),ST(1.0,.186,.128),ST(1.14,.178,.122),ST(1.26,.208,.132,0,.005),ST(1.36,.228,.123),ST(1.42,.212,.109),ST(1.46,.1,.082)],.56*Math.PI,2.44*Math.PI,16); GK.box(b,0,1.425,.07,.12,.04,.1,WH); G.coat=b; }
  { const b=MB(); GK.bar(b,[0,.04,0],[0,-.86,0],.022,WH); GK.bar(b,[0,.04,0],[0,.07,.06],.022,WH); GK.bar(b,[0,.07,.06],[0,.04,.12],.022,WH); G.cane=b; }
  { const b=MB(); GK.box(b,0,-.045,.02,.022,.105,.058,[.1,.1,.12]); GK.box(b,0,-.045,.0302,.016,.09,.0004,[.55,.85,1.0]); G.phone=b; }
  { const b=MB(); GK.box(b,0,-.09,.012,.026,.19,.034,[.06,.06,.075]); GK.box(b,0,-.1,.03,.012,.15,.012,[.14,.14,.16]); GK.box(b,0,-.03,-.03,.024,.05,.052,[.09,.07,.06]); GK.box(b,0,-.2,.008,.016,.02,.016,[.02,.02,.02]); G.gun=b; }
  const geo={}; for(const k in G) geo[k]=GK.finish(G[k]);
  /* ölçüler (eklem noktaları / uzunluklar) */
  const D={hipX:.1,hipY:.9,thigh:.42,shin:.415,shX:.205,shY:1.4,uArm:.29,fArm:.26,headY:1.66,waistY:.98};
  return {geo,D,tubeArc};
})();
