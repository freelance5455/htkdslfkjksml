"use strict";
/* ===== YAŞAYAN ŞEHİR: bank/kafede oturma, market tezgâhı, dükkâna girme, grup sohbeti, telefonla yürüme, hırsız, altın NPC ===== */
Game.NPCLife=(function(){
  const N=Game.NPC, PL=Game.Places, Ev=Game.Ev, W=Game.W, ST=N.states, list=N.list, nodes=N.nodes, rnd=Math.random, pick=a=>a[(rnd()*a.length)|0], DM=Game.HumanKit.D, NS=N.scale;
  const api={groups:[],thieves:[],stats:{sit:0,shop:0,talk:0,thief:0,caught:0,gold:0}};
  const hero=()=>Game.heroObj?Game.heroObj.position:{x:0,y:0,z:0};
  const SAY=(n,cat,o)=>{ if(Game.Speech) Game.Speech.say(n,cat,o); };
  const norm=a=>Math.atan2(Math.sin(a),Math.cos(a));
  /* asfalt şeridinde mi (yol merkezine 4.3 m) — oturma/sohbet noktaları yola düşmesin */
  const onRoad=(x,z)=>{ if(W.distCity(x,z)>1) return false; const a=((x-17)%34+34)%34, b=((z-17)%34+34)%34; return Math.min(a,34-a)<4.3||Math.min(b,34-b)<4.3; };
  api.onRoad=onRoad;

  /* ---------- yürü → hedef düğüme rota → son yaklaşma ---------- */
  function walkTo(n,x,z,goal){ const a=n.nix; if(a===undefined||a<0||!nodes[a]) return false; const b=N.nearestFree(x,z,26); if(b<0) return false;
    if(N.blocked(nodes[b].x,nodes[b].z,x,z)) return false;
    const r=a===b?[]:N.route(a,b); if(r===null||r.length>70) return false;
    goal.x=x; goal.z=z; n.goal=goal; n.goalNode=b; n.pix=-1;
    if(r.length===0){ n.goalNode=-1; arrive(n); return true; }
    n.path=r; return true; }
  function arrive(n){ const g=n.goal; if(!g){ resume(n); return; } n.path=null; n.st="approach"; n.t=0; n.spd=g.spd||1.25; n.anim=n.anim||0; }
  N.onArrive=arrive;
  /* serbest bırak: yürüyüşe dön */
  function resume(n){ if(n.seat&&n.seat.o===n) n.seat.o=null; n.seat=null; n.goal=null; n.path=null; n.goalNode=-1; n.grp=null; n.pa=null; n.st="walk"; n.t=0; n.spd=N.walkSpd(n)*(n.phone?.8:1); n.hl=null;
    const ni=N.nearestFree(n.x,n.z); if(ni>=0){ n.nix=ni; n.pix=-1; } else { n.st="gone"; n.vis=false; N.hide(n); } }
  api.resume=resume;
  ST.approach={ move:true, shy:true,
    update(n,dt){ const g=n.goal; if(!g){ resume(n); return; } const dx=g.x-n.x, dz=g.z-n.z, d=Math.hypot(dx,dz), step=n.spd*dt; n.anim+=dt*n.spd*3.1;
      if(d<=step||d<.04){ n.x=g.x; n.z=g.z; n.y=W.surfaceAt(n.x,n.z,60); n.goal=null; if(g.finish) g.finish(n,g); else resume(n); return; }
      n.x+=dx/d*step; n.z+=dz/d*step; n.y=W.surfaceAt(n.x,n.z,60); let ta=Math.atan2(dx,dz); if(d<.8&&g.ang!==undefined) ta=g.ang; n.ang+=norm(ta-n.ang)*(1-Math.exp(-9*dt)); if(n.t>30) resume(n); },
    pose(n,P0,T,i,spd,loco,ph){ loco(Math.min(1,spd/1.8),ph); if(n.phone){ P0.shR=-1.2; P0.elR=1.75; P0.nod+=.4; } } };

  /* ---------- OTURMA (bank / kafe sandalyesi) ---------- */
  function sitFinish(n,g){ const p=g.place; n.st="sit"; n.t=0; n.seat=p; p.o=n; n.sitT=g.dur; n.sv=g.variant; n.pa=g.partner||null; n.ang=p.ang; n.x=p.x; n.z=p.z; n.y=W.surfaceAt(p.x,p.z,60); api.stats.sit++; }
  ST.sit={ shy:true,
    update(n,dt){ n.anim+=dt; if(!n.seat){ resume(n); return; } if(n.t>n.sitT){ resume(n); return; }
      if(n.sv===2&&n.pa&&(!n.pa.vis||n.pa.st!=="sit")) n.sv=0;
      if(n.sv===2&&n.t>1&&((n.t*.35+n.i*.7)%1)<dt*.35&&Game.Speech) SAY(n,"idle"); },
    place(n){ const p=n.seat; if(!p) return null; const o=p.meta&&p.meta.lounge?.4:.12; return [p.x-Math.sin(p.ang)*o, n.y, p.z-Math.cos(p.ang)*o]; },
    pose(n,P0,T,i){ const p=n.seat, h=(p?p.y:.57)-.12+.05, v=n.sv|0, ho=1.52, kn=1.5;
      if(v>=4){ /* şezlong: bacaklar öne uzanmış, gövde arkaya yaslanmış (güneşlenme) */
        P0.hipL=1.5; P0.hipR=1.46; P0.knL=.04; P0.knR=.1; P0.bob=h+.1-DM.hipY*n.ht; P0.lean=-.95; P0.abL=P0.abR=.12; P0.ankL=P0.ankR=-.1; P0.nod=.55+Math.sin(T*.4+i)*.03; P0.turn=Math.sin(T*.23+i)*.25;
        if(v===5){ P0.shL=P0.shR=-2.35; P0.elL=P0.elR=1.8; } else { P0.shL=-.3; P0.shR=-.35; P0.elL=.25; P0.elR=.3; P0.shR+=Math.sin(T*.5+i)*.05; } return; }
      P0.hipL=ho; P0.hipR=ho; P0.knL=kn; P0.knR=kn; P0.bob=h-DM.hipY*n.ht; P0.lean=.04; P0.abL=P0.abR=.1; P0.ankL=P0.ankR=.05; P0.nod=Math.sin(T*.7+i)*.04;
      if(v===1){ P0.shR=-1.2; P0.elR=1.75+Math.sin(T*1.1+i)*.03; P0.shL=-.4; P0.elL=1.05; P0.nod=.5; P0.turn=0; n.phn=1; }
      else if(v===2){ let tt=Math.sin(T*.9+i)*.3; if(n.pa){ tt=Math.max(-1,Math.min(1,norm(Math.atan2(n.pa.x-n.x,n.pa.z-n.z)-n.ang)))*.9+Math.sin(T*1.7+i)*.12; } P0.turn=tt; P0.shR=-.65+Math.sin(T*3.2+i)*.4; P0.elR=1.3+Math.sin(T*4.5+i)*.3; P0.shL=-.4; P0.elL=1.1; P0.nod=Math.sin(T*2.1+i)*.08; }
      else if(v===3){ const c=((T*.17+i*.37)%1), up=c<.22?Math.sin(c/.22*Math.PI):0; P0.shR=-.45-.75*up; P0.elR=1.1+1.15*up; P0.shL=-.4; P0.elL=1.1; P0.nod=-.05-.12*up; P0.turn=Math.sin(T*.5+i)*.4; }
      else { P0.shL=-.4; P0.shR=-.4; P0.elL=1.1; P0.elR=1.1; P0.turn=Math.sin(T*.5+i)*.45; } } };
  function trySeat(n){ const p=PL.near("seat",n.x,n.z,48,s=>PL.free(s)); if(!p) return false; p.o=n;
    const cafe=p.meta&&p.meta.cafe, lg=p.meta&&p.meta.lounge; let v=lg?(rnd()<.5?4:5):cafe?(rnd()<.5?3:0):(rnd()<.35?1:0), partner=null, o=null;
    if(cafe&&rnd()<.6){ o=PL.near("seat",p.meta.tx+(p.x>p.meta.tx?-1:1),p.meta.tz,.3,s=>PL.free(s)); if(o){ partner=pickWalker(n,26); if(!partner) o=null; } }
    const g={place:p,ang:p.ang,finish:sitFinish,dur:14+rnd()*38,variant:partner?2:v,partner:partner};
    const so=lg?.4:.12; if(!walkTo(n,p.x-Math.sin(p.ang)*so,p.z-Math.cos(p.ang)*so,g)){ p.o=null; return false; }
    if(partner&&o){ const go={place:o,ang:o.ang,finish:sitFinish,dur:g.dur+rnd()*4,variant:2,partner:n}; o.o=partner; N.cancel(partner,true); const pi=N.nearestFree(partner.x,partner.z); if(pi>=0){ partner.nix=pi; partner.pix=-1; }
      if(!walkTo(partner,o.x-Math.sin(o.ang)*.12,o.z-Math.cos(o.ang)*.12,go)){ o.o=null; g.variant=3; g.partner=null; } }
    return true; }
  function pickWalker(n,r){ let best=null,bd=r*r; for(const m of list){ if(m===n||!m.vis||m.st!=="walk"||m.goal||m.role||m.dead||m.phone) continue; const dx=m.x-n.x, dz=m.z-n.z, d=dx*dx+dz*dz; if(d<bd){ bd=d; best=m; } } return best; }

  /* ---------- MARKET TEZGÂHI / DÜKKÂN ---------- */
  function shopFinish(n,g){ n.st="shop"; n.t=0; n.said=0; n.shopT=g.dur; n.ang=g.ang; n.stall=g.place; api.stats.shop++; }
  ST.shop={ shy:true,
    update(n,dt){ n.anim+=dt; if(!n.said&&n.t>1.2){ n.said=1; if(rnd()<.35) SAY(n,"shop"); } if(n.t>n.shopT){ if(!n.hasBag){ n.hasBag=1; N.look(n,{bg:1}); } if(n.stall&&n.stall.o===n) n.stall.o=null; n.stall=null; resume(n); } },
    pose(n,P0,T,i,spd,loco){ loco(0,0); const c=((T*.3+i*.21)%1), rc=c<.4?Math.sin(c/.4*Math.PI):0; P0.shR=-.12-.95*rc; P0.elR=.35+.55*rc; P0.lean=.04+.1*rc; P0.nod=.22+.15*rc; P0.turn=Math.sin(T*.6+i)*.5; P0.roll=Math.sin(T*.45+i)*.025; P0.hipL=.04; P0.hipR=-.04; P0.bob=Math.sin(T*1.5+i)*.005; P0.shL=-.12; P0.elL=.3; } };
  function doorFinish(n,g){ n.st="inside"; n.t=0; n.insT=7+rnd()*9; n.vis=false; n.door=g.place; N.hide(n); }
  ST.inside={ off(n,dt){ if(n.t<n.insT) return; const p=n.door; n.door=null; if(p&&p.o===n) p.o=null; n.vis=true; if(!n.hasBag){ n.hasBag=1; N.look(n,{bg:1}); } n.x=p.x; n.z=p.z; n.y=W.surfaceAt(n.x,n.z,60); n.ang=p.ang+Math.PI; resume(n); } };
  function tryShop(n){ const st=PL.near("stall",n.x,n.z,55,s=>PL.free(s)), dr=PL.near("shopdoor",n.x,n.z,55,s=>PL.free(s)); let p=null,door=false; if(st&&(!dr||rnd()<.55)) p=st; else if(dr){ p=dr; door=true; } if(!p) return false;
    p.o=n; const off=door?0:(rnd()-.5)*1.4, g={place:p,ang:p.ang,finish:door?doorFinish:shopFinish,dur:5+rnd()*8,spd:1.3};
    if(!walkTo(n,p.x+off,p.z,g)){ p.o=null; return false; } return true; }

  /* ---------- GRUP SOHBETİ ---------- */
  let gid=0;
  function tryTalk(n){ const cand=[]; for(const m of list){ if(m===n||!m.vis||m.st!=="walk"||m.goal||m.role||m.dead||m.phone) continue; const dx=m.x-n.x, dz=m.z-n.z, d=Math.hypot(dx,dz); if(d<17&&!N.blocked(n.x,n.z,m.x,m.z)) cand.push([d,m]); }
    if(!cand.length) return false; cand.sort((a,b)=>a[0]-b[0]); const k=1+(rnd()<.4?1:0)+(rnd()<.15?1:0), ms=[n]; for(const c of cand){ if(ms.length>=k+1) break; ms.push(c[1]); }
    if(ms.length<2) return false; if(onRoad(n.x,n.z)) return false;
    const R=ms.length===2?.8:1.05, base=rnd()*6.28, g={ms,cx:n.x,cz:n.z,t:0,dur:8+rnd()*10,spk:0,spkT:0,id:++gid,dead:false};
    ms.forEach((m,idx)=>{ if(m!==n){ N.cancel(m,true); m.nix=N.nearestFree(m.x,m.z); m.pix=-1; } const a=base+idx/ms.length*Math.PI*2, sx=g.cx+Math.sin(a)*R, sz=g.cz+Math.cos(a)*R, fa=Math.atan2(g.cx-sx,g.cz-sz);
      m.grp=g; m.gAng=fa; const go={ang:fa,finish:talkFinish,spd:1.35,x:sx,z:sz}; m.goal=go; m.st="approach"; m.t=0; m.spd=1.35; m.path=null; });
    api.groups.push(g); return true; }
  function talkFinish(n,g){ n.st="talk"; n.t=0; n.ang=g.ang; api.stats.talk++; }
  ST.talk={ shy:true,
    update(n,dt){ const g=n.grp; if(!g||g.dead){ resume(n); return; } n.anim+=dt; n.ang+=norm(Math.atan2(g.cx-n.x,g.cz-n.z)-n.ang)*(1-Math.exp(-6*dt)); },
    pose(n,P0,T,i,spd,loco){ const g=n.grp, spk=g&&g.ms[g.spk]===n; loco(0,0); P0.hipL=.04; P0.hipR=-.04; P0.bob=Math.sin(T*1.7+i)*.006; P0.lean=.02; P0.roll=Math.sin(T*.5+i)*.03;
      if(spk){ P0.shR=-.7+Math.sin(T*3.4+i)*.45; P0.elR=1.3+Math.sin(T*5+i)*.3; P0.shL=-.3+Math.sin(T*2.6+i)*.25; P0.elL=.85; P0.abR=.14; P0.turn=Math.sin(T*1.3+i)*.28; P0.nod=.04+Math.sin(T*2.4+i)*.09; }
      else { P0.shL=-.62; P0.shR=-.62; P0.elL=2.05; P0.elR=2.05; P0.abL=-.12; P0.abR=-.12; P0.turn=Math.sin(T*.6+i)*.3; P0.nod=Math.sin(T*.9+i)*.05+(Math.sin(T*2+i)>.85?.1:0); } } };
  function tickGroups(dt){ const G=api.groups; for(let k=G.length-1;k>=0;k--){ const g=G[k]; if(g.dead){ G.splice(k,1); continue; } g.t+=dt;
      let talking=0; for(const m of g.ms) if(m.st==="talk") talking++;
      if(g.t>14&&talking<2){ g.dead=true; for(const m of g.ms){ if(m.grp===g){ m.grp=null; if(m.st==="approach"||m.st==="talk") resume(m); } } continue; }
      if(talking>=2){ g.spkT-=dt; if(g.spkT<=0){ g.spk=(g.spk+1)%g.ms.length; g.spkT=2+rnd()*3; const sp=g.ms[g.spk]; if(sp&&sp.st==="talk"&&Math.hypot(sp.x-hero().x,sp.z-hero().z)<26&&rnd()<.5) SAY(sp,"idle"); } }
      if(g.t>g.dur+4){ g.dead=true; for(const m of g.ms){ if(m.grp===g){ m.grp=null; if(m.st==="talk"||m.st==="approach") resume(m); } } } } }
  N.onCancel=function(n){ const g=n.grp; if(g){ n.grp=null; const i=g.ms.indexOf(n); if(i>=0) g.ms.splice(i,1); if(g.ms.length<2){ g.dead=true; for(const m of g.ms){ if(m.grp===g&&(m.st==="talk"||m.st==="approach")){ m.grp=null; resume(m); } } } }
    if(n.door&&n.door.o===n) n.door.o=null; if(n.stall&&n.stall.o===n) n.stall.o=null; };

  /* boştaki yürüyen NPC bir "niyet" seçer */
  N.onIdle=function(n){ if(rnd()>.22) return false; if(n.phone&&rnd()<.5) return false; const r=rnd();
    if(r<.34) return trySeat(n); if(r<.60) return tryShop(n); if(r<.90) return tryTalk(n); return false; };

  /* ---------- doğuş: bazıları zaten oturuyor, telefonla yürüyor; çok nadir altın NPC ve hırsız ---------- */
  const BAGS=["#7b3f1d","#b22a2a","#2a4a8a","#c9a227"];
  N.onSpawn=function(n){ if(Game.mode!=="play"&&Game.mode!=="menu") return;
    if(!n.golden&&rnd()<.0045&&N.countGolden()===0){ N.makeGolden(n); api.stats.gold++; return; }
    if(rnd()<.012&&api.thieves.length<1){ makeThief(n); return; }
    if(rnd()<.28){ const p=PL.near("seat",n.x,n.z,34,s=>PL.free(s)); if(p&&!onRoad(p.x,p.z)){ p.o=n; const cafe=p.meta&&p.meta.cafe; n.x=p.x; n.z=p.z; n.y=W.surfaceAt(p.x,p.z,60); n.t=0; n.seat=p; n.st="sit"; n.sitT=10+rnd()*40; n.sv=(p.meta&&p.meta.lounge)?(rnd()<.5?4:5):cafe?(rnd()<.5?3:0):(rnd()<.35?1:0); n.ang=p.ang; n.pa=null; n.hl=null; return; } }
    if(rnd()<.18){ n.phone=1; n.spd*=.8; } };

  /* ---------- HIRSIZ ---------- */
  function makeThief(n){ N.makeRole(n,"thief"); n.tstate=0; n.caught=0; n.runner=0; n.tt=0; n.victim=null; api.thieves.push(n); api.stats.thief++; }
  function victimFor(t){ let best=null,bd=18*18; for(const m of list){ if(m===t||!m.vis||m.dead||m.thief||m.role||(m.st!=="walk"&&m.st!=="chat"&&m.st!=="sit")) continue; const dx=m.x-t.x, dz=m.z-t.z, d=dx*dx+dz*dz; if(d<bd){ bd=d; best=m; } } return best; }
  function pickNear(t,r,ex){ let best=null,bd=r*r; for(const m of list){ if(m===t||!m.vis||m.dead||(ex&&ex.includes(m))) continue; const d=(m.x-t.x)**2+(m.z-t.z)**2; if(d<bd){ bd=d; best=m; } } return best; }
  ST.chase={ move:true,
    update(n,dt){ const v=n.victim; if(!v||!v.vis||v.dead){ n.victim=null; n.tstate=0; resume(n); return; } const dx=v.x-n.x, dz=v.z-n.z, d=Math.hypot(dx,dz), step=n.spd*dt; n.anim+=dt*n.spd*3.1; n.ang+=norm(Math.atan2(dx,dz)-n.ang)*(1-Math.exp(-10*dt));
      if(d<1.15){ snatch(n,v); return; } n.x+=dx/d*step; n.z+=dz/d*step; n.y=W.surfaceAt(n.x,n.z,60); n.tt+=dt; if(n.tt>14){ n.victim=null; n.tstate=0; resume(n); } },
    pose(n,P0,T,i,spd,loco,ph){ loco(Math.min(1,spd/1.8),ph); P0.nod+=.1; P0.shR=-.35; P0.elR=1.0; P0.lean+=.06; } };
  function snatch(t,v){ t.tstate=2; t.victim=null; t.hasBag=1; N.look(t,{bg:1}); t.st="flee"; t.t=0; t.runner=1; t.spd=7.4; t.fx=v.x; t.fz=v.z; t.rpT=0; t.tflee=0; t.goal=null; t.path=null;
    const ni=N.nearestFree(t.x,t.z); if(ni>=0){ t.nix=ni; t.pix=-1; } N.fleePlan(t); N.pickNext(t,true);
    if(v.st==="sit"||v.st==="shop"||v.st==="talk"||v.goal||v.seat) N.cancel(v);
    v.st="shock"; v.t=.35; v.fx=t.x; v.fz=t.z; v.ang=Math.atan2(t.x-v.x,t.z-v.z);
    SAY(v,"thiefv",{pri:3}); Ev.emit("thiefSnatch",t,v);
    setTimeout(()=>{ const w=pickNear(t,30,[v]); if(w) SAY(w,"thief",{pri:2}); },1100); }
  function caught(t){ if(t.caught) return; t.caught=1; t.runner=0; api.stats.caught++; Ev.emit("thiefCaught",t); SAY(pickNear(t,35,[t])||t,"thiefok",{pri:3}); }
  function tickThieves(dt){ const hp=hero(), A=api.thieves;
    for(let k=A.length-1;k>=0;k--){ const t=A[k]; if(!t.thief||t.caught||t.st==="gone"||(!t.vis&&t.st!=="inside")){ A.splice(k,1); continue; }
      if(t.tstate===2){ const bad=t.st==="held"||t.st==="rag"||t.st==="hurt"||t.st==="dead"||t.st==="frozen"||t.st==="shade"||t.dead; if(bad){ caught(t); A.splice(k,1); continue; }
        t.tflee+=dt; t.rpT+=dt; if(t.st==="flee"&&t.rpT>4){ t.rpT=0; const dh=Math.hypot(t.x-hp.x,t.z-hp.z); if(dh<60){ t.fx=hp.x; t.fz=hp.z; } N.fleePlan(t); }
        if(t.tflee>45&&Math.hypot(t.x-hp.x,t.z-hp.z)>55){ SAY(pickNear(t,40,[t])||t,"thiefgone",{pri:1}); N.vanish(t); A.splice(k,1); continue; } }
      else if(t.tstate===0){ t.tt+=dt; if(t.st==="walk"&&t.tt>1.2){ t.tt=0; if(Math.hypot(t.x-hp.x,t.z-hp.z)<140){ const v=victimFor(t); if(v){ t.victim=v; t.tstate=1; t.tt=0; N.cancel(t,true); t.st="chase"; t.spd=3.4; t.t=0; } } } } } }
  Ev.on("npcHit",(n,kind)=>{ if(n.thief&&n.tstate===2&&!n.caught) caught(n); });

  /* ---------- ALTIN NPC: oyuncu yaklaşınca kaçar ---------- */
  let goldSeen=0;
  function tickGold(dt){ const hp=hero(); for(const g of list){ if(!g.golden||!g.vis||g.dead) continue; const d=Math.hypot(g.x-hp.x,g.z-hp.z);
      if(d<65&&goldSeen<=0&&Game.mode==="play"){ goldSeen=40; const w=pickNear(g,50,[g]); SAY(w||g,"gold",{pri:2}); }
      const calm=g.st==="walk"||g.st==="chat"||g.st==="sit"||g.st==="shop"||g.st==="talk"||g.st==="approach";
      if(calm&&d<46&&Game.mode==="play"){ N.cancel(g,true); g.st="flee"; g.t=0; g.spd=6.8; g.fx=hp.x; g.fz=hp.z; g.rpT=0; const ni=N.nearestFree(g.x,g.z); if(ni>=0){ g.nix=ni; g.pix=-1; } N.fleePlan(g); N.pickNext(g,true); }
      else if(g.st==="flee"){ g.t=Math.min(g.t,5); g.rpT=(g.rpT||0)+dt; if(g.rpT>3.5){ g.rpT=0; g.fx=hp.x; g.fz=hp.z; N.fleePlan(g); } if(d>85){ g.st="walk"; g.spd=N.walkSpd(g)*1.6; g.path=null; } } }
    if(goldSeen>0) goldSeen-=dt; }

  Game.updaters.push(dt=>{ if(Game.mode!=="play"&&Game.mode!=="menu") return; dt=Math.min(dt,.05); tickGroups(dt); tickThieves(dt); tickGold(dt); });
  api.walkTo=walkTo; api.pickWalker=pickWalker; api.makeThief=makeThief; api.onRoad=onRoad;
  return api; })();
