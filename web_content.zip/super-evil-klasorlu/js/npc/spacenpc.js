"use strict";
/* ===== UZAYDA TUTULAN NPC: iki tepkiden biri (rastgele): (1) kahramanı tekmeleyip kurtulur, (2) nefessiz kalır, yüzü morarır ve ölür ===== */
Game.SpaceNPC=(function(){
  const H=Game.H, hero=Game.heroObj, NPC=Game.NPC, FX=Game.FX, au=()=>Game.audio, clamp=(v,a,b)=>v<a?a:v>b?b:v;
  const sm=(a,b,x)=>{ const t=clamp((x-a)/(b-a),0,1); return t*t*(3-2*t); };
  const START=.22, KICK_T=1.55, DIE_T=5.6, flung=[];
  function doKick(n){
    const dx=n.hx-hero.position.x, dz=n.hz-hero.position.z, l=Math.hypot(dx,dz)||1, ux=dx/l, uz=dz/l;
    NPC.release(n,ux*24+H.vel.x*.35,7+Math.random()*4,uz*24+H.vel.z*.35);
    H.vel.x-=ux*17; H.vel.z-=uz*17; H.vel.y+=3; H.shake=Math.max(H.shake,.65); if(Game.shakeAdd) Game.shakeAdd(.55);
    FX.spark(hero.position.x+ux,hero.position.y+.9,hero.position.z+uz,12,9,[1,.85,.6]); FX.shock&&FX.shock(hero.position.x+ux*1.2,hero.position.y+.9,hero.position.z+uz*1.2,6,8);
    if(au()){ au().thud(hero.position.x,hero.position.y,hero.position.z); if(au().whoosh) au().whoosh(); }
    if(Game.toast) Game.toast("t_kick",3400); flung.push(n); n.sx=null; return 2; }
  function suffocate(n,s){
    NPC.setPurple(n,clamp((s.t-.6)/4.4,0,1));
    if(s.t>DIE_T&&!n.dead){ n.dead=true; n.hp=0; NPC.setPurple(n,1);
      FX.ice&&FX.ice(n.hx,n.hy,n.hz,6,1.4); FX.dust(n.hx,n.hy,n.hz,4,1.2,[.7,.6,.8]); if(au()&&au().thud) au().thud(n.hx,n.hy,n.hz);
      if(Game.addScore) Game.addScore(220); if(Game.toast) Game.toast("t_suff",3600); }
    return 1; }
  /* powers.js her karede çağırır: 0 = normal, 1 = bu NPC için hp azaltma/kıvılcım yok, 2 = NPC bırakıldı */
  function tick(n,dt){
    if(H.sp<START||Game.mode!=="play"){ if(n.sx){ n.sx=null; if(n.purple) NPC.setPurple(n,0); } return 0; }
    if(!n.sx) n.sx={mode:Math.random()<.5?"kick":"suff",t:0};
    const s=n.sx; s.t+=dt; if(n.dead) return 1;
    if(s.mode==="kick") return s.t>KICK_T?doKick(n):1;
    return suffocate(n,s); }
  /* npc.js poz kancası: true dönerse varsayılan "held" pozu atlanır */
  function pose(n,P0,T,i){ const s=n.sx; if(!s) return false; const t=s.t;
    if(s.mode==="kick"){ if(t<1.0) return false;
      const wind=sm(1.0,1.38,t), st=sm(1.42,1.52,t), a=wind*(1-st);
      P0.shL=-1.65; P0.shR=-1.6; P0.elL=.55; P0.elR=.6; P0.abL=P0.abR=.28; P0.lean=-.3*wind; P0.nod=.1; P0.turn=0; P0.roll=0;
      P0.hipL=-1.3*a+.32*st; P0.knL=1.55*a+.04*st; P0.hipR=.1+Math.sin(T*20+i)*.3*(1-st); P0.knR=.5+Math.sin(T*20+i+1)*.25*(1-st); return true; }
    const w=sm(1.5,4.9,t), tw=Math.sin(T*(15-w*9)+i)*(1-w*.94);
    P0.shL=-1.55+tw*.28; P0.shR=-1.5-tw*.28; P0.elL=2.05+tw*.1; P0.elR=2.0-tw*.1; P0.abL=P0.abR=.12;
    P0.hipL=.12+tw*.5; P0.hipR=.05-tw*.5; P0.knL=.4+Math.max(0,tw)*.5; P0.knR=.35+Math.max(0,-tw)*.5;
    P0.nod=.22+w*.55; P0.lean=.04+w*.22; P0.roll=Math.sin(T*3+i)*.05*w; P0.turn=Math.sin(T*2.1+i)*.2*(1-w); return true; }
  /* kurtulup uzaya fırlayan NPC'ler: yüksekte ragdoll sayacı sıfırlanır (havada ışınlanmasın), yere sert çarpınca ölür */
  Game.updaters.push(()=>{ for(let q=flung.length-1;q>=0;q--){ const n=flung[q]; if(!n.vis||n.st==="gone"||n.dead){ flung.splice(q,1); continue; }
    const b=n.body; if(!b) continue; const y=b.position.y, v=b.velocity;
    if(y>260) n.t=Math.min(n.t,2);
    else if(!n.sxHit&&y<45){ const sp=Math.hypot(v.x,v.y,v.z); if(sp>38){ n.sxHit=true; NPC.hit(n,v.x*.15,v.y*.15,v.z*.15,"boom"); flung.splice(q,1); } } } });
  return {tick,pose};
})();
