"use strict";
/* ===== POLİS SİSTEMİ + KAHRAMAN CANI =====
   Arananlık (3 yıldız): suç işledikçe ısı yükselir → 1★ devriye arabası + yaya polis, 2★ daha fazla polis, 3★ tanklar + helikopterler + füzeler.
   Polis kapalıysa (ayar) hiçbir şey çalışmaz. Kahramanın canı: mermi/mermi/füze hasar verir; can bitince hastanede uyanır (arananlık silinir). */
Game.Police=(function(){
  const N=Game.NPC, Ev=Game.Ev, W=Game.W, P=Game.P, FX=Game.FX, D=Game.D, H=Game.H, hero=Game.heroObj, E=Game.Emerg, Sea=Game.Sea, R=Game.carRefs, traffic=R.traffic, ST=N.states, list=N.list, NS=N.scale;
  const rnd=Math.random, clamp=(v,a,b)=>v<a?a:v>b?b:v, norm=a=>Math.atan2(Math.sin(a),Math.cos(a));
  const hp0=()=>hero.position, au=()=>Game.audio;
  const LIFE=()=>Game.NPCLife;
  const SAY=(n,cat,o)=>{ if(Game.Speech) Game.Speech.say(n,cat,o); };
  const api={heat:0,stars:0,cruisers:[],tanks:[],helis:[],proj:[],stats:{cops:0,shots:0,hits:0,missiles:0,shells:0,wasted:0}};
  const on=()=>!!(Game.settings&&Game.settings.police)&&Game.mode==="play";
  let clock=0, calm=0, hidden=false, seenOnce=false, hidT=0, dispT=0, heliT=0, tankT=0, copsT=0, goalAlert=0, said3=0, wastedT=0, invul=0;

  /* ================= KAHRAMAN CANI ================= */
  const Hp=Game.Hp={hp:100,max:100,t:0,dead:false,flash:0};
  Hp.hurt=function(d,x,y,z,src){ if(!(d>0)||Hp.dead||invul>0||Game.mode!=="play") return; if(Game.Mounted&&Game.Mounted()) d*=.7; Hp.hp=Math.max(0,Hp.hp-d); Hp.t=0; Hp.flash=Math.min(1,Hp.flash+.35+d*.02); H.shake=Math.max(H.shake||0,Math.min(.5,.08+d*.012));
    if(au()&&au().thud&&d>6) au().thud(hp0().x,hp0().y,hp0().z); if(Hp.hp<=0) die(); };
  Hp.heal=function(v){ Hp.hp=Math.min(Hp.max,Hp.hp+v); };
  function die(){ if(Hp.dead) return; Hp.dead=true; wastedT=0; api.stats.wasted++; Game.heroLock=4; H.flying=false; H.smash=false; if(Game.Drive&&Game.Drive.active&&Game.Drive.exit) Game.Drive.exit(true); if(Game.Ride&&Game.Ride.active) Game.Ride.exit(true);
    if(Game.Lift&&Game.Lift.active&&Game.Lift.release) { try{ Game.Lift.release(); }catch(e){} }
    showWasted(true); Ev.emit("heroDown"); }
  function respawn(){ const hp=hp0(); let hs=E&&E.nearestHospital?E.nearestHospital(hp.x,hp.z):null; if(!hs&&E&&E.hospitals.length){ const h=E.hospitals[0]; hs={h,node:E.nodeNear?E.nodeNear(h,hp.x,hp.z):null}; }
    if(hs&&hs.node){ const x=hs.node.x+3, z=hs.node.z+3; hero.position.set(x,W.surfaceAt(x,z,300)+1.35,z); H.vel.set(0,0,0); H.flying=false; if(Game.resetCamPivot) Game.resetCamPivot(); } else if(Game.resetHero) Game.resetHero();
    Hp.hp=Hp.max; Hp.dead=false; Game.heroLock=0; invul=3; api.clear(true); api.heat=0; setStars(0,true); showWasted(false); if(Game.toast) Game.toast("wasted_sub",3200); }

  /* ================= HUD ================= */
  let elW=null, elStars=[], elHp=null, elHpI=null, elFx=null, elWst=null, wstTxt=null, wstSub=null;
  function mk(tag,id,cls,parent){ const e=document.createElement(tag); if(id) e.id=id; if(cls) e.className=cls; parent.appendChild(e); return e; }
  function hudInit(){ if(elW) return; try{ const hud=document.getElementById("hud")||document.body; elW=mk("div","wanted","",hud); for(let i=0;i<3;i++){ const s=mk("i",null,"",elW); s.textContent="★"; elStars.push(s); }
      elHp=mk("div","hpbar","",hud); elHpI=mk("i",null,"",elHp); elFx=mk("div","hurtfx","",hud); elWst=mk("div","wasted","",hud); wstTxt=mk("b",null,"",elWst); wstSub=mk("span",null,"",elWst); }catch(e){ elW=elW||{}; } }
  function showWasted(v){ hudInit(); try{ if(v){ wstTxt.textContent=t("wasted"); wstSub.textContent=""; elWst.classList.add("on"); } else elWst.classList.remove("on"); }catch(e){} }
  let lastSt=-1, lastHpW=-1, lastHid=null, lastOn=null;
  function hudUpdate(dt){ hudInit(); try{
      const want=Game.mode==="play"&&on()&&(api.stars>0); if(want!==lastOn){ lastOn=want; elW.classList.toggle("on",want); }
      if(api.stars!==lastSt){ lastSt=api.stars; elStars.forEach((s,i)=>s.classList.toggle("f",i<api.stars)); }
      if(hidden!==lastHid){ lastHid=hidden; elW.classList.toggle("hid",hidden); }
      const showHp=Game.mode==="play"&&(Hp.hp<Hp.max-.5||api.stars>0||Hp.dead); elHp.classList.toggle("on",showHp);
      const w=Math.round(Hp.hp/Hp.max*100); if(w!==lastHpW){ lastHpW=w; elHpI.style.width=w+"%"; }
      Hp.flash=Math.max(0,Hp.flash-dt*1.6); elFx.style.opacity=String(Math.min(1,Hp.flash+(Hp.hp<28&&!Hp.dead?.35+.15*Math.sin(clock*7):0)));
    }catch(e){} }

  /* ================= ARANANLIK (ısı → yıldız) ================= */
  const TH=[12,42,78];
  function starsOf(h,cur){ let s=0; for(let i=0;i<3;i++) if(h>=TH[i]-(cur>i?5:0)) s=i+1; return s; }
  function setStars(s,silent){ if(s===api.stars) return; const up=s>api.stars; api.stars=s; if(!silent){ if(up){ if(Game.toast) Game.toast(s>=3?"w_3":"w_up",2600); if(au()&&au().click) au().click(); } else if(s===0){ if(Game.toast) Game.toast("w_clear",2600); } }
    if(s===0&&!silent) api.dismiss(); if(s>=3) said3=0; }
  api.add=function(v,why){ if(!on()||Hp.dead||invul>1.5) return; api.heat=clamp(api.heat+v,0,100); calm=0; setStars(starsOf(api.heat,api.stars)); };
  let hitCool=0;
  Ev.on("npcKill",(n,kind)=>{ if(!on()) return; if(n&&n.role==="cop"){ api.add(12,"cop"); const w=nearCop(n.x,n.z,n,60); if(w) SAY(w,"copdown",{pri:3,cd:5,range:120}); N.unRole(n); } else if(n&&n.thief) api.add(1,"thief"); else api.add(9,"kill"); });
  Ev.on("npcHit",(n,kind)=>{ if(!on()||(n&&n.role==="cop")||hitCool>0) return; hitCool=.45; api.add(n&&n.thief&&!n.caught?.3:1.3,"hit"); });
  Ev.on("building",()=>api.add(5,"building"));
  Ev.on("carDestroyed",(k,i)=>{ const s=k==="t"?traffic[i]:null; api.add(s&&(s.role==="cop"||s.role==="tank")?7:2.5,"car"); });
  Ev.on("turbineBroken",()=>api.add(2,"turbine"));
  Ev.on("playerRanOver",()=>api.add(4,"ranover"));
  Ev.on("thiefCaught",()=>{ if(api.heat>0) api.heat=Math.max(0,api.heat-6); });
  function nearCop(x,z,skip,r){ let b=null,bd=(r||50)*(r||50); for(const n of list){ if(n.role!=="cop"||!n.vis||n.dead||n===skip) continue; const d=(n.x-x)*(n.x-x)+(n.z-z)*(n.z-z); if(d<bd){ bd=d; b=n; } } return b; }

  /* ================= YARDIMCILAR: patlama, iz, LOS ================= */
  let inBoom=false;
  function boom(x,y,z,s,dmg,rad,harmless){ inBoom=true; try{ FX.fire(x,y,z,Math.round(20*s),0,5*s,0,2+s); FX.spark(x,y,z,Math.round(18*s),14+8*s); FX.cloud(x,y,z,Math.round(4*s),5*s,3+2*s); FX.smoke(x,y+1,z,Math.round(5*s),1+s); FX.shock(x,y,z,Math.round(10*s),14+8*s); FX.glow(x,y,z,9*s,[1,.8,.4],.35);
      if(au()&&au().boom) au().boom(x,y,z); const h=hp0(), dh=Math.hypot(x-h.x,y-h.y,z-h.z); if(Game.shakeAdd) Game.shakeAdd(clamp(1*s*(1-dh/(300+200*s)),0,1));
      if(!harmless){ if(D&&D.damageSphere) D.damageSphere(x,y,z,3+3.2*s,.9,14+9*s); if(Game.radial) Game.radial(x,y,z,6+5*s,14+7*s,"boom"); if(dmg>0&&dh<rad){ Hp.hurt(dmg*(1-dh/rad*.55),x,y,z,"blast"); } } }finally{ inBoom=false; } }
  function tracer(x0,y0,z0,x1,y1,z1){ for(let i=0;i<6;i++){ const k=i/5; FX.E(true,x0+(x1-x0)*k,y0+(y1-y0)*k,z0+(z1-z0)*k,0,0,0,.07,.55,.2,[1,.88,.45],[1,.5,.1],.9,0,1); } FX.glow(x0,y0,z0,1.4,[1,.85,.5],.06); }
  function los(x,y,z,tx,ty,tz){ const dx=tx-x, dy=ty-y, dz=tz-z, L=Math.hypot(dx,dy,dz); if(L<2) return true; if(!D||!D.ray) return true; const r=D.ray(x,y,z,dx/L,dy/L,dz/L,L); return !(r&&r.kind==="chunk"&&r.t<L-1.5); }
  function roadWide(x,z){ let t=E.roadTarget(x,z); if(t) return t; let best=null,bd=110; for(const l of Game.trafficLines){ const lat=l.axis===0?Math.abs(x-l.line):Math.abs(z-l.line), al=l.axis===0?z:x; if(lat<bd){ bd=lat; best={axis:l.axis,line:l.line,pos:clamp(al,l.lo+10,l.hi-10),lat}; } } return best; }
  function legLen(legs){ let L=0; for(const g of legs) L+=Math.abs(g.end-g.start); return L; }
  function spawnSpot(tg){ const h=hp0(); const cand=[], st=E.nearestStation(h.x,h.z,700), home=st?st.node:null; if(st&&Math.hypot(st.node.x-h.x,st.node.z-h.z)>85) cand.push({node:st.node,bonus:70});
    const NL=E.graph.NL; for(let k=0;k<90&&cand.length<8;k++){ const n=NL[(rnd()*NL.length)|0], d=Math.hypot(n.x-h.x,n.z-h.z); if(d>175&&d<330&&n.e.length>=2) cand.push({node:n,bonus:0}); }
    let best=null,bc=1e9; for(const c of cand){ const plan=E.planRoute(c.node,tg); if(!plan) continue; const L=legLen(plan.legs)-c.bonus; if(L<bc){ bc=L; best={legs:plan.legs,home:home||c.node}; } }
    return best; }

  /* ================= YAYA POLİS ================= */
  const RANGE=[0,38,48,60], FIRE=[0,1.5,1.05,.8], DMG=[0,2.6,3.2,3.8];
  function copGo(m){ const hp=hp0(); if(!m.vis||m.dead) return; LIFE().resume(m); const ni=N.nearestFree(hp.x,hp.z,70); const d=m.cpd||(m.cpd={fire:1+rnd(),lt:0,los:false,lost:0,rt:0,rec:0}); d.rt=0; d.lost=0; m.gunUp=1;
    if(ni<0){ m.st="copaim"; m.t=0; return; } const nd=N.nodes[ni]; m.spd=4.8; const ok=LIFE().walkTo(m,nd.x,nd.z,{spd:4.8,ang:Math.atan2(hp.x-nd.x,hp.z-nd.z),finish:copArrived}); if(ok) m.spd=4.8; else { m.st="copaim"; m.t=0; } d.gx=hp.x; d.gz=hp.z; }
  function copArrived(n){ n.goal=null; n.st="copaim"; n.t=0; }
  function shoot(n,d){ const hp=hp0(), st=Math.max(1,api.stars), sa=Math.sin(n.ang), ca=Math.cos(n.ang), ox=n.x+sa*.55, oy=n.y+1.2*NS, oz=n.z+ca*.55, dist=Math.hypot(hp.x-n.x,hp.z-n.z);
    const pHit=clamp(.42-dist/130-(H.speed||0)*.0075,.04,.36), hit=rnd()<pHit, ty=hp.y-.15; api.stats.shots++; d.rec=1;
    if(hit){ tracer(ox,oy,oz,hp.x,ty,hp.z); FX.spark(hp.x,ty,hp.z,4,6); api.stats.hits++; Hp.hurt(DMG[st],hp.x,ty,hp.z,"bullet"); }
    else { const j=2.2+rnd()*2.6, a=rnd()*6.283; const ex=hp.x+Math.cos(a)*j, ez=hp.z+Math.sin(a)*j, ey=ty+(rnd()-.5)*j; tracer(ox,oy,oz,ex,ey,ez); if(ey<W.surfaceAt(ex,ez,ey+2)+.3) FX.dust(ex,W.surfaceAt(ex,ez,ey+2)+.1,ez,3,1.2); else FX.spark(ex,ey,ez,3,5); }
    if(au()&&au().gun) au().gun(ox,oy,oz); if(clock-goalAlert>1.3){ goalAlert=clock; N.alert(n.x,n.z,26,hp.x,hp.z); } }
  ST.copaim={ update(n,dt){ n.anim+=dt; const d=n.cpd; if(!d){ LIFE().resume(n); return; } n.gunUp=1; const hp=hp0(), dx=hp.x-n.x, dz=hp.z-n.z, dist=Math.hypot(dx,dz);
      n.ang+=norm(Math.atan2(dx,dz)-n.ang)*(1-Math.exp(-8*dt)); d.fire-=dt; d.rec=Math.max(0,d.rec-dt*5); d.lt-=dt;
      if(d.lt<=0){ d.lt=.4+rnd()*.25; d.los=los(n.x,n.y+1.3*NS,n.z,hp.x,hp.y,hp.z); }
      const Rg=RANGE[Math.max(1,api.stars)]||38; if(!api.stars){ return; }
      if(!d.los||dist>Rg*1.25){ d.lost+=dt; if(d.lost>1.5) copGo(n); } else d.lost=0;
      if(d.los&&dist<=Rg&&d.fire<=0&&!Hp.dead){ shoot(n,d); d.fire=FIRE[api.stars]*(.8+rnd()*.5); } },
    pose(n,P0,T,i,spd,loco){ loco(0,0); const r=(n.cpd&&n.cpd.rec)||0; P0.shL=-1.38; P0.shR=-1.5-r*.22; P0.elL=.4; P0.elR=.12+r*.25; P0.abL=.12; P0.abR=-.03; P0.hipL=.2; P0.hipR=-.17; P0.knL=.28; P0.knR=.2; P0.lean=.05+r*.04; P0.nod=-.03; P0.bob=-.05*n.ht; P0.turn=0; } };
  function board(n){ if(!n.vis) return; n.gunUp=0; N.unRole(n); N.vanish(n); }

  /* ================= PATROL ARABALARI ================= */
  function spawnCruiser(){ const h=hp0(), tg=roadWide(h.x,h.z); if(!tg) return false; const sp=spawnSpot(tg); if(!sp) return false; const V=E.spawn("cop",sp.legs,13,"cop"); if(!V) return false;
    api.cruisers.push({V,st:"go",t:0,cops:[],home:sp.home,unl:false}); return true; }
  function unload(C){ const V=C.V, t=V.t, fx=Math.sin(t.ry), fz=Math.cos(t.ry), lx=fz, lz=-fx, h=hp0(); C.unl=true; let n=0;
    for(let k=0;k<2;k++){ if(footCount()>=[0,3,6,9][api.stars||1]) break; const m=E.recruit(t.cx,t.cz,C.cops); if(!m) break; const s=k?1:-1;
      if(!E.placeRole(m,t.cx+lx*s*2.3-fx*.8,t.cz+lz*s*2.3-fz*.8,Math.atan2(h.x-t.cx,h.z-t.cz),"cop")) break; m.cpd={fire:.8+rnd()*1.2,lt:0,los:false,lost:0,rt:0,rec:0}; m.cpd.car=C; C.cops.push(m); api.stats.cops++; n++; copGo(m); }
    if(n){ if(Game.audio&&Game.audio.door) Game.audio.door(); SAY(C.cops[0],api.stars>=3?"cop3":api.stars>=2?"cop2":"cop1",{pri:3,cd:6,range:120}); } }
  function footCount(){ let c=0; for(const n of list) if(n.role==="cop"&&n.vis&&!n.dead) c++; return c; }
  function updCruiser(C,dt){ const V=C.V, t=V.t; C.t+=dt;
    if(V.released){ return true; }
    if(V.broken){ if(C.st!=="dead"){ C.st="dead"; for(const m of C.cops) if(m&&m.cpd) m.cpd.car=null; } C.bt=(C.bt||0)+dt; if(C.bt>40&&!t.gone&&Math.hypot(t.cx-hp0().x,t.cz-hp0().z)>90&&Game.Cars&&Game.Cars.vanish) Game.Cars.vanish("t",V.idx); if(t.gone) E.release(V); return V.released; }
    if(C.st==="go"){ const h0=hp0(), dh=Math.hypot(t.cx-h0.x,t.cz-h0.z); if((t.v||0)<.3&&!t.hold) C.stuck=(C.stuck||0)+dt; else C.stuck=0;
      if(!C.unl&&(V.arrived||(C.stuck>2.2&&dh<42)||(C.t>40&&dh<70))){ if(!V.arrived){ V.arrived=true; t.hold=true; } unload(C); C.st="park"; C.t=0; } else if(C.t>90){ C.st="park"; C.t=0; C.unl=true; } if(!api.stars) recall(C); }
    else if(C.st==="park"){ if(!api.stars){ recall(C); return false; } const alive=C.cops.filter(m=>m&&m.vis&&!m.dead&&m.role==="cop"), h=hp0(), dist=Math.hypot(t.cx-h.x,t.cz-h.z);
      if(C.t>6&&(alive.length===0||dist>160)){ const tg=roadWide(h.x,h.z); if(tg&&E.driveTo(V,tg)){ C.st="go"; C.t=0; C.unl=false; } else C.t=3; } }
    else if(C.st==="recall"){ let left=0; for(const m of C.cops){ if(m&&m.vis&&!m.dead&&m.role==="cop") left++; } if(left===0||C.t>24){ for(const m of C.cops) if(m&&m.vis&&m.role==="cop") board(m); C.cops.length=0; leave(C); } }
    return false; }
  function recall(C){ C.st="recall"; C.t=0; const V=C.V, t=V.t; for(const m of C.cops){ if(!m||!m.vis||m.dead||m.role!=="cop") continue; m.gunUp=0; LIFE().resume(m); m.spd=3.2; const ok=LIFE().walkTo(m,t.cx+Math.cos(t.ry)*2.2,t.cz-Math.sin(t.ry)*2.2,{spd:3.4,finish:board}); if(!ok) board(m); } }
  function leave(C){ const V=C.V, t=V.t; if(V.released) return; t.hold=false; t.stopAt=null; const legs=E.planReturn(V,C.home); if(!legs){ V.mustVanish=true; V.done=true; } else { V.legs=legs; V.leg=0; V.arrived=false; V.done=false; V.mustVanish=true; V.first=null; E.setLeg(V,legs[0],false); } C.st="leave"; C.t=0; }

  /* ================= TANKLAR ================= */
  const dark=new THREE.MeshStandardMaterial({color:0x2a2d2b,roughness:.5,metalness:.5});
  const GT={ tur:new THREE.CylinderGeometry(1.2,1.45,.82,8), bar:new THREE.CylinderGeometry(.12,.15,4.6,10), hatch:new THREE.CylinderGeometry(.36,.36,.16,10), mg:new THREE.BoxGeometry(.18,.16,.9), mant:new THREE.BoxGeometry(.9,.7,.9), tip:new THREE.BoxGeometry(.28,.28,.5) };
  function mkTurret(){ const grp=new THREE.Group(), tur=new THREE.Group(), mat=new THREE.MeshStandardMaterial({color:0x56653a,roughness:.62,metalness:.25}); const a=new THREE.Mesh(GT.tur,mat); a.position.set(0,1.95,-.25); const b=new THREE.Mesh(GT.bar,dark); b.rotation.x=Math.PI/2; b.position.set(0,2.0,3.0); const c=new THREE.Mesh(GT.hatch,mat); c.position.set(.45,2.42,-.55); const m=new THREE.Mesh(GT.mg,dark); m.position.set(-.5,2.58,-.4); const mt=new THREE.Mesh(GT.mant,mat); mt.position.set(0,2.0,.95); const tp=new THREE.Mesh(GT.tip,dark); tp.position.set(0,2.0,5.2);
    for(const o of [a,b,c,m,mt,tp]){ o.castShadow=true; tur.add(o); } grp.add(tur); grp.visible=false; grp.rotation.order="YXZ"; scene.add(grp); return {grp,tur,mat}; }
  const turrets=[mkTurret(),mkTurret()];
  function spawnTank(){ const h=hp0(), tg=roadWide(h.x,h.z); if(!tg) return false; const sp=spawnSpot(tg); if(!sp) return false; const V=E.spawn("tank",sp.legs,7.5,"tank"); if(!V) return false; const i=V.idx; let tu=null; for(const q of turrets){ if(!q.used){ tu=q; break; } } if(!tu){ E.release(V); return false; }
    tu.used=true; tu.mat.color.set(0x56653a); const T={V,tu,st:"go",t:0,home:sp.home,ty:V.t.ry||0,fireT:5+rnd()*2,broken:false}; api.tanks.push(T); tu.grp.visible=true; return true; }
  function updTank(T,dt){ const V=T.V, t=V.t, tu=T.tu; T.t+=dt;
    if(V.released){ tu.grp.visible=false; tu.used=false; return true; }
    const dyn=t.dyn||t.wreck||t.burnT||t.driven, e=dyn&&Game.Cars?Game.Cars.body("t",V.idx):null;
    if(V.broken){ if(!T.broken){ T.broken=true; T.rel=norm(T.ty-(t.ry||0)); const c=t.charred||t.wreck||t.burnT; } T.bt=(T.bt||0)+dt; if(T.bt>45&&!t.gone&&Math.hypot(t.cx-hp0().x,t.cz-hp0().z)>90&&Game.Cars&&Game.Cars.vanish) Game.Cars.vanish("t",V.idx); if(t.gone){ E.release(V); tu.grp.visible=false; tu.used=false; return true; } }
    if(t.gone){ tu.grp.visible=false; }
    let gx,gy,gz;
    if(e){ const b=e.position, q=e.quaternion; tu.grp.quaternion.set(q.x,q.y,q.z,q.w); tu.grp.position.set(b.x,b.y-1.0,b.z); tu.tur.rotation.y=T.rel===undefined?0:T.rel; if(t.charred||t.wreck||t.burnT) tu.mat.color.set(0x151515); }
    else if(!dyn){ gx=t.cx+(V.cx||0); gz=t.cz+(V.cz||0); tu.grp.quaternion.set(0,0,0,1); tu.grp.position.set(gx,.08,gz); tu.grp.rotation.set(0,t.ry+(V.cr||0),0);
      const h=hp0(), dx=h.x-gx, dz=h.z-gz, dist=Math.hypot(dx,dz), want=Math.atan2(dx,dz); if(dist<190&&!Hp.dead){ T.ty+=clamp(norm(want-T.ty),-1.1*dt,1.1*dt); } else T.ty+=clamp(norm((t.ry||0)-T.ty),-.8*dt,.8*dt);
      tu.tur.rotation.y=norm(T.ty-(t.ry+(V.cr||0))); T.rel=tu.tur.rotation.y;
      T.fireT-=dt; const mx=gx+Math.sin(T.ty)*5.2, my=2.05, mz=gz+Math.cos(T.ty)*5.2;
      if(T.fireT<=0&&dist<150&&dist>26&&Math.abs(norm(want-T.ty))<.09&&!Hp.dead&&api.stars>0){ if(los(mx,my,mz,h.x,h.y,h.z)){ T.fireT=4.2+rnd()*1.8; fireShell(mx,my,mz,T.ty); } else T.fireT=.8; }
      if(t.siren===1&&T.t>0){ /* motor dumanı */ if(rnd()<dt*5&&V.t.v>.5) FX.smoke(gx-Math.sin(t.ry)*3.4,1.5,gz-Math.cos(t.ry)*3.4,1,.8); }
      /* hedefe yaklaşınca dur, hero uzaklaşırsa yeniden rota */
      if((t.v||0)<.3&&!t.hold) T.stuck=(T.stuck||0)+dt; else T.stuck=0; if(T.st==="go"&&(V.arrived||(T.stuck>3&&dist<90))){ if(!V.arrived){ V.arrived=true; t.hold=true; } T.st="park"; T.t=0; } else if(T.st==="park"&&api.stars>0&&T.t>8&&dist>110){ const tg=roadWide(h.x,h.z); if(tg&&E.driveTo(V,tg)){ T.st="go"; T.t=0; } else T.t=4; }
      if(!api.stars&&(T.st==="go"||T.st==="park")){ leaveV(T); } }
    return false; }
  function leaveV(U){ const V=U.V, t=V.t; U.st="leave"; U.t=0; if(V.released) return; t.hold=false; t.stopAt=null; const legs=E.planReturn(V,U.home); if(!legs){ V.mustVanish=true; V.done=true; } else { V.legs=legs; V.leg=0; V.arrived=false; V.done=false; V.mustVanish=true; V.first=null; E.setLeg(V,legs[0],false); } }

  /* ================= MERMİ / TOP / FÜZE ================= */
  const missGeo=(()=>{ const g=new THREE.CylinderGeometry(.17,.17,2.2,8); return g; })(), missMat=new THREE.MeshStandardMaterial({color:0xdadde2,roughness:.4,metalness:.5}), shellGeo=new THREE.SphereGeometry(.28,8,6), shellMat=new THREE.MeshBasicMaterial({color:0xffd070});
  const pool=[]; function mesh(kind){ let m=pool.find(o=>!o.on&&o.kind===kind); if(!m){ const me=new THREE.Mesh(kind==="m"?missGeo:shellGeo,kind==="m"?missMat:shellMat); me.frustumCulled=false; me.visible=false; scene.add(me); m={me,kind,on:false}; pool.push(m); } m.on=true; m.me.visible=true; return m; }
  const UPV=new THREE.Vector3(0,1,0), qv=new THREE.Quaternion(), dv=new THREE.Vector3();
  function fireShell(x,y,z,yaw){ const h=hp0(), dx=h.x-x, dz=h.z-z, dist=Math.hypot(dx,dz), sp=64, tt=dist/sp; const lx=h.x+(H.vel?H.vel.x:0)*tt*.55, lz=h.z+(H.vel?H.vel.z:0)*tt*.55, ly=h.y+(H.vel?H.vel.y:0)*tt*.4;
    const ddx=lx-x, ddz=lz-z, dd=Math.hypot(ddx,ddz), t2=dd/sp, vy=(ly-y+.5*14*t2*t2)/Math.max(.2,t2); const m=mesh("s"); api.proj.push({k:"shell",m,x,y,z,vx:ddx/t2,vy,vz:ddz/t2,age:0});
    FX.fire(x+Math.sin(yaw)*.6,y,z+Math.cos(yaw)*.6,10,0,1,0,1.6); FX.smoke(x,y,z,4,1.4); FX.glow(x,y,z,6,[1,.8,.4],.18); if(au()&&au().cannon) au().cannon(x,y,z); api.stats.shells++; if(Game.shakeAdd){ const q=Math.hypot(x-h.x,z-h.z); Game.shakeAdd(clamp(.5*(1-q/200),0,.5)); } }
  function fireMissile(x,y,z,yaw){ const h=hp0(), m=mesh("m"); const sp=22; const dx=h.x-x, dy=h.y-y, dz=h.z-z, L=Math.hypot(dx,dy,dz)||1; api.proj.push({k:"missile",m,x,y,z,vx:dx/L*sp,vy:dy/L*sp-4,vz:dz/L*sp,age:0,trail:0});
    FX.smoke(x,y,z,4,1.2); FX.glow(x,y,z,5,[1,.8,.5],.2); if(au()&&au().missile) au().missile(x,y,z); api.stats.missiles++; }
  function freeProj(i){ const p=api.proj[i]; p.m.on=false; p.m.me.visible=false; api.proj.splice(i,1); }
  function explodeProj(i,harmless){ const p=api.proj[i]; if(!p) return; const big=p.k==="missile"; freeProj(i); boom(p.x,p.y,p.z,big?1.15:1.35,big?20:26,big?7:8.5,harmless); }
  function updProj(dt){ const h=hp0(); for(let i=api.proj.length-1;i>=0;i--){ const p=api.proj[i]; p.age+=dt;
      if(p.k==="missile"){ const sp=Math.min(56,22+p.age*15), cur=Math.hypot(p.vx,p.vy,p.vz)||1; let dx=h.x-p.x, dy=h.y-.1-p.y, dz=h.z-p.z; const L=Math.hypot(dx,dy,dz)||1; dx/=L; dy/=L; dz/=L; const k=Math.min(1,(p.age<7?2.3:.4)*dt); let vx=p.vx/cur+(dx-p.vx/cur)*k, vy=p.vy/cur+(dy-p.vy/cur)*k, vz=p.vz/cur+(dz-p.vz/cur)*k; const vl=Math.hypot(vx,vy,vz)||1; p.vx=vx/vl*sp; p.vy=vy/vl*sp; p.vz=vz/vl*sp;
        p.trail-=dt; if(p.trail<=0){ p.trail=.035; FX.smoke(p.x,p.y,p.z,1,.6); FX.fire(p.x,p.y,p.z,1,0,0,0,.9); FX.glow(p.x,p.y,p.z,1.6,[1,.7,.3],.07); } }
      else { p.vy-=14*dt; if(p.age*30%1<.6) FX.glow(p.x,p.y,p.z,1.3,[1,.8,.4],.06); }
      const sx=p.x, sy=p.y, sz=p.z; const nx=sx+p.vx*dt, ny=sy+p.vy*dt, nz=sz+p.vz*dt, sl=Math.hypot(nx-sx,ny-sy,nz-sz)||1e-3;
      /* kahramana yakınlık (parça içinde en yakın nokta) */
      const ex=nx-sx, ey=ny-sy, ez=nz-sz, tt=clamp(((h.x-sx)*ex+(h.y-sy)*ey+(h.z-sz)*ez)/(sl*sl),0,1), cx=sx+ex*tt-h.x, cy=sy+ey*tt-h.y, cz=sz+ez*tt-h.z;
      if(!Hp.dead&&cx*cx+cy*cy+cz*cz<2.6*2.6){ p.x=sx+ex*tt; p.y=sy+ey*tt; p.z=sz+ez*tt; explodeProj(i,false); continue; }
      if(D&&D.ray&&sl>.01){ const r=D.ray(sx,sy,sz,ex/sl,ey/sl,ez/sl,sl+.4); if(r&&r.kind==="chunk"&&r.t<sl+.4){ p.x=sx+ex/sl*r.t; p.y=sy+ey/sl*r.t; p.z=sz+ez/sl*r.t; explodeProj(i,false); continue; } }
      if(ny<W.surfaceAt(nx,nz,ny+2)+.15||p.age>(p.k==="missile"?11:6)){ p.x=nx; p.y=Math.max(ny,W.surfaceAt(nx,nz,ny+2)+.2); p.z=nz; explodeProj(i,p.age>(p.k==="missile"?11:6)); continue; }
      p.x=nx; p.y=ny; p.z=nz; p.m.me.position.set(nx,ny,nz); if(p.k==="missile"){ dv.set(p.vx,p.vy,p.vz).normalize(); qv.setFromUnitVectors(UPV,dv); p.m.me.quaternion.copy(qv); } } }
  /* kahramanın güçleri füzeleri/mermileri havada patlatır */
  api.radialHit=function(x,y,z,r){ if(inBoom) return; for(let i=api.proj.length-1;i>=0;i--){ const p=api.proj[i]; if(Math.hypot(p.x-x,p.y-y,p.z-z)<r) explodeProj(i,true); } };
  api.punch=function(x,y,z,r){ for(let i=api.proj.length-1;i>=0;i--){ const p=api.proj[i]; if(Math.hypot(p.x-x,p.y-y,p.z-z)<r) explodeProj(i,true); } };
  { const r0=Game.radial; Game.radial=function(x,y,z,r,speed,kind){ const c=r0?r0.apply(this,arguments):0; if(!inBoom&&api.proj.length) api.radialHit(x,y,z,r); return c; }; }

  /* ================= HELİKOPTERLER ================= */
  function heliCtl(e,dt){ const h=hp0(), U=e.U;
    if(U.leave){ const ax=e.x-h.x, az=e.z-h.z, al=Math.hypot(ax,az)||1; e.vx+=(ax/al*50-e.vx)*(1-Math.exp(-dt*1.2)); e.vz+=(az/al*50-e.vz)*(1-Math.exp(-dt*1.2)); e.vy+=(6-e.vy)*(1-Math.exp(-dt*1)); }
    else { U.pa+=U.dir*dt*.3; const Rr=U.orb, tx=h.x+Math.cos(U.pa)*Rr, tz=h.z+Math.sin(U.pa)*Rr, ty=Math.max(h.y+38,W.surfaceAt(tx,tz,300)+42), dx=tx-e.x, dz=tz-e.z, dy=ty-e.y, d=Math.hypot(dx,dz)||1;
      const sp=Math.min(e.spd0*(d>160?2.4:1),d*1.3+6), k=1-Math.exp(-dt*1.7); e.vx+=(dx/d*sp-e.vx)*k; e.vz+=(dz/d*sp-e.vz)*k; e.vy+=(clamp(dy*.8,-16,16)-e.vy)*k; }
    e.x+=e.vx*dt; e.y+=e.vy*dt; e.z+=e.vz*dt; const hs=Math.hypot(e.vx,e.vz), face=Math.atan2(h.x-e.x,h.z-e.z), hd=Math.atan2(e.vx,e.vz), dist=Math.hypot(h.x-e.x,h.z-e.z), want=(!U.leave&&dist<110)?face:(hs>3?hd:e.yaw);
    const yo=e.yaw; e.yaw+=norm(want-e.yaw)*(1-Math.exp(-dt*2.6)); const yr=norm(e.yaw-yo)/Math.max(dt,1e-3); e.yr+=(yr-e.yr)*(1-Math.exp(-dt*4)); const kk=1-Math.exp(-dt*3); e.pit+=(clamp(hs*.011,0,.32)-e.pit)*kk; e.rol+=(-clamp(e.yr*.35,-.5,.5)-e.rol)*kk; }
  function spawnHeli(){ const e=Sea.polHelis.find(q=>!q.used&&q.g); if(!e||Hp.dead) return false; const h=hp0(), a=rnd()*6.283, d=330+rnd()*60; const x=h.x+Math.cos(a)*d, z=h.z+Math.sin(a)*d, y=Math.max(h.y+70,W.surfaceAt(x,z,300)+80);
    Sea.revive(e,x,y,z,Math.atan2(h.x-x,h.z-z)); e.used=true; e.ctl=heliCtl; e.U={pa:a,dir:rnd()<.5?-1:1,orb:48+rnd()*22,leave:false,gt:3+rnd()*2,burst:0,bt:0,mt:7+rnd()*4,dead:false}; e.spd0=36; api.helis.push(e); return true; }
  function updHeli(e,dt,idx){ const U=e.U; if(!U) return true; const h=hp0();
    if(e.st!=="cruise"){ if(!U.dead){ U.dead=true; api.add(8,"heli"); e.ctl=null; } if(e.st==="gone"){ Sea.hideE(e); e.used=false; e.U=null; return true; } return false; }
    if(U.leave){ if(Math.hypot(e.x-h.x,e.z-h.z)>520){ Sea.hideE(e); e.used=false; e.U=null; return true; } return false; }
    if(!api.stars){ U.leave=true; return false; }
    const dist=Math.hypot(h.x-e.x,h.z-e.z), nx=e.x+Math.sin(e.yaw)*4, ny=e.y-1.2, nz=e.z+Math.cos(e.yaw)*4;
    if(dist<135&&!Hp.dead){ const vis=(U.lt=(U.lt||0)-dt)>0?U.vis:(U.lt=.5,U.vis=los(e.x,e.y,e.z,h.x,h.y,h.z)); U.gt-=dt;
      if(vis){ if(U.burst>0){ U.bt-=dt; if(U.bt<=0){ U.bt=.09; U.burst--; const hit=rnd()<clamp(.2-dist/900-(H.speed||0)*.002,.04,.2); if(hit){ tracer(nx,ny,nz,h.x,h.y-.1,h.z); Hp.hurt(2.4,h.x,h.y,h.z,"heli"); api.stats.hits++; } else { const j=3+rnd()*4, a=rnd()*6.283; tracer(nx,ny,nz,h.x+Math.cos(a)*j,h.y+(rnd()-.5)*j,h.z+Math.sin(a)*j); } if(au()&&au().gun) au().gun(nx,ny,nz); api.stats.shots++; } }
        else if(U.gt<=0){ U.burst=6+((rnd()*5)|0); U.gt=2.4+rnd()*2; } } }
    if(dist<200&&dist>38&&!Hp.dead){ U.mt-=dt; if(U.mt<=0){ U.mt=10+rnd()*5; if(U.vis!==false&&api.stars>=3) fireMissile(nx,ny,nz,e.yaw); } }
    return false; }
  api.activeHelis=()=>api.helis.length;

  /* ================= GENEL DÖNGÜ ================= */
  function visibleToCops(){ const h=hp0(); for(const C of api.cruisers){ const t=C.V.t; if(!C.V.released&&Math.hypot(t.cx-h.x,t.cz-h.z)<95) return true; }
    for(const n of list){ if(n.role==="cop"&&n.vis&&!n.dead&&Math.hypot(n.x-h.x,n.z-h.z)<75&&n.cpd&&n.cpd.los) return true; }
    for(const T of api.tanks){ const t=T.V.t; if(!T.V.released&&Math.hypot(t.cx-h.x,t.cz-h.z)<150) return true; }
    for(const e of api.helis){ if(e.st==="cruise"&&e.U&&!e.U.leave&&Math.hypot(e.x-h.x,e.z-h.z)<240) return true; } return false; }
  function unitCount(){ return api.cruisers.length+api.tanks.length+api.helis.length+api.proj.length; }
  api.units=unitCount;
  function dispatch(){ const s=api.stars; if(s<=0) return; const aliveC=api.cruisers.filter(C=>C.st!=="leave"&&C.st!=="recall").length; if(aliveC<[0,1,2,3][s]){ spawnCruiser(); }
    if(s>=3){ if(!said3){ said3=1; const c=nearCop(hp0().x,hp0().z,null,140); if(c) SAY(c,"cop3",{pri:3,cd:3,range:160}); } const tk=api.tanks.filter(T=>T.st!=="leave").length; if(tk<2&&tankT<=0){ if(spawnTank()) tankT=16; else tankT=4; } const hc=api.helis.filter(e=>e.U&&!e.U.leave).length; if(hc<2&&heliT<=0){ if(spawnHeli()) heliT=14; else heliT=4; } } }
  api.dismiss=function(){ for(const C of api.cruisers) if(C.st==="go"||C.st==="park") recall(C); for(const T of api.tanks) if(T.st==="go"||T.st==="park") leaveV(T); for(const e of api.helis) if(e.U) e.U.leave=true;
    const c=nearCop(hp0().x,hp0().z,null,220); if(c) SAY(c,"copend",{pri:3,cd:3,range:220}); };
  api.clear=function(instant){ for(const C of api.cruisers){ if(!C.V.released) E.release(C.V); for(const m of C.cops){ if(m&&m.role==="cop"){ m.gunUp=0; N.unRole(m); N.vanish(m); } } } api.cruisers.length=0;
    for(const T of api.tanks){ if(!T.V.released) E.release(T.V); T.tu.grp.visible=false; T.tu.used=false; } api.tanks.length=0;
    for(const e of api.helis){ Sea.hideE(e); e.used=false; e.U=null; } api.helis.length=0;
    for(let i=api.proj.length-1;i>=0;i--) freeProj(i);
    for(const n of list){ if(n.role==="cop"){ n.gunUp=0; N.unRole(n); if(n.vis&&!n.dead) N.vanish(n); } } };
  api.onToggle=function(v){ if(!v){ api.clear(true); api.heat=0; api.stars=0; lastSt=-1; } };
  api.reset=function(){ api.clear(true); api.heat=0; api.stars=0; Hp.hp=Hp.max; Hp.dead=false; Game.heroLock=0; invul=0; lastSt=-1; try{ showWasted(false); }catch(e){} };

  Game.updaters.push(dt=>{ dt=Math.min(dt,.05);
    if(Game.mode!=="play"){ if(api.stars||api.heat||unitCount()||Hp.dead||Hp.hp<Hp.max) api.reset(); lastOn=null; return; }
    clock+=dt; hitCool=Math.max(0,hitCool-dt); invul=Math.max(0,invul-dt); tankT-=dt; heliT-=dt;
    /* can: ölüyse girişi sustur, değilse yenilen */
    if(Hp.dead){ const A=Game.input&&Game.input.actions; if(A) for(const k in A) if(A[k]===true) A[k]=false; wastedT+=dt; if(wastedT>1.2&&wstSub&&!wstSub.textContent){ try{ wstSub.textContent=t("wasted_sub"); }catch(e){} } if(wastedT>=3.8) respawn(); hudUpdate(dt); return; }
    Hp.t+=dt; if(Hp.hp<Hp.max&&Hp.t>4.2) Hp.hp=Math.min(Hp.max,Hp.hp+dt*(api.stars?4:9));
    if(!on()){ if(api.stars||api.heat||unitCount()) api.onToggle(false); hudUpdate(dt); return; }
    /* ısı soğuması: son suçtan 9 sn sonra; gözden kaybolunca hızlı */
    calm+=dt; if(api.stars>0||api.heat>0){ const vis=api.stars>0&&visibleToCops(); if(vis) seenOnce=true; hidden=api.stars>0&&seenOnce&&!vis; hidT=hidden?hidT+dt:0; if(calm>(seenOnce?9:22)){ api.heat=Math.max(0,api.heat-dt*(hidT>6?3.2:1.1)); const s=starsOf(api.heat,api.stars); if(s!==api.stars) setStars(s); } if(api.stars>0&&hidden&&hidT>3){ copsT-=dt; if(copsT<=0){ copsT=14; const c=nearCop(hp0().x,hp0().z,null,260); if(c) SAY(c,"copgone",{pri:2,cd:8,range:300}); } } } else{ hidden=false; seenOnce=false; hidT=0; }
    dispT-=dt; if(dispT<=0){ dispT=.9; dispatch(); }
    for(let i=api.cruisers.length-1;i>=0;i--) if(updCruiser(api.cruisers[i],dt)) api.cruisers.splice(i,1);
    for(let i=api.tanks.length-1;i>=0;i--) if(updTank(api.tanks[i],dt)) api.tanks.splice(i,1);
    for(let i=api.helis.length-1;i>=0;i--) if(updHeli(api.helis[i],dt,i)) api.helis.splice(i,1);
    updProj(dt);
    /* yaya polis bekçisi: kalkınca / yolu bitince yeniden görev; çok uzaktaysa ya da arananlık yoksa temizle */
    for(const n of list){ if(n.role!=="cop"||!n.cpd||!n.vis||n.dead) continue; const d=n.cpd; d.rt+=dt; const h=hp0(), far=Math.hypot(n.x-h.x,n.z-h.z);
      if(api.stars>0){ if(far>300){ board(n); continue; } if(n.st==="walk"&&!n.goal&&d.rt>1.2) copGo(n); else if(n.st==="walk"&&n.goal&&d.rt>2.4&&Math.hypot((d.gx||0)-h.x,(d.gz||0)-h.z)>16) copGo(n); }
      else if(!d.car&&d.rt>14) board(n); }
    hudUpdate(dt); });

  api.markers=function(){ const out=[]; if(!api.stars) return out; for(const C of api.cruisers) if(!C.V.released&&!C.V.broken) out.push({x:C.V.t.cx,z:C.V.t.cz,c:"#4f8dff",k:"car"}); for(const T of api.tanks) if(!T.V.released&&!T.V.broken) out.push({x:T.V.t.cx,z:T.V.t.cz,c:"#6aa84f",k:"tank"}); for(const e of api.helis) if(e.st==="cruise") out.push({x:e.x,z:e.z,c:"#9fc2ff",k:"heli"}); for(const n of list) if(n.role==="cop"&&n.vis&&!n.dead) out.push({x:n.x,z:n.z,c:"#3b6fe0",k:"cop"}); return out; };
  api.debug={Hp,die,respawn,spawnCruiser,spawnTank,spawnHeli,fireShell,fireMissile,starsOf,TH,copGo,unload,roadWide,spawnSpot};
  return api; })();
