"use strict";
/* ===== NPC'ler: yaya yolu grafiği üstünde FSM (yürü, sohbet, şok, kaç, ragdoll, yan, don, boğazlan) ===== */
Game.NPC = (function(){
  const U=Game.U, P=Game.P, FX=Game.FX, Cars=Game.Cars;
  const W=Game.W, CELL=W.CELL, nodes=[]; let api_graph=null;
  const addNode=(x,z)=>{ nodes.push({x,z,nb:[]}); return nodes.length-1; }, link=(a,b)=>{ if(a<0||b<0||a===b) return; if(!nodes[a].nb.includes(b)) nodes[a].nb.push(b); if(!nodes[b].nb.includes(a)) nodes[b].nb.push(a); };
  const nearest=(x,z,maxd)=>{ let bi=-1,bd=maxd===undefined?1e18:maxd*maxd; for(let i=0;i<nodes.length;i++){ const dx=nodes[i].x-x, dz=nodes[i].z-z, d=dx*dx+dz*dz; if(d<bd&&(nodes[i].nb.length||!nodes[i].graphDone)){ bd=d; bi=i; } } return bi; };
  { /* şehir: kaldırım ızgarası (yol karolarının iki yanında) */
    const XL=[]; for(let g=-14;g<=14;g++) XL.push(g*CELL-11.6,g*CELL+11.6); const NG=XL.length, grid=[];
    for(let i=0;i<NG;i++){ grid.push([]); for(let j=0;j<NG;j++){ const x=XL[i], z=XL[j]; grid[i].push(W.walkCell(Math.round(x/CELL),Math.round(z/CELL))?addNode(x,z):-1); } }
    for(let i=0;i<NG;i++) for(let j=0;j<NG;j++){ const a=grid[i][j]; if(a<0) continue; if(i+1<NG) link(a,grid[i+1][j]); if(j+1<NG) link(a,grid[i][j+1]); }
    /* köprü: iki kaldırım şeridi (z=11.6 ve 22.4), kıyıdan Luna Park girişine */
    const lane=[11.6,22.4], bi=W.bridge&&W.bridge.info; if(bi){ const prev=[-1,-1], X0=bi.X0, X1=bi.X1;
      lane.forEach((z,k)=>{ let last=nearest(317.6,z,3); for(let x=X0+4;x<=X1-6;x+=13){ const n=addNode(x,z); link(last,n); last=n; } prev[k]=last; });
      Game._brEnd=prev; }
    /* Luna Park: iki şerit gezinti yolu, çeşme çevresinde halka, ride patikaları */
    const IX=700, IZ=17, L1=IZ-3.5, L2=IZ+3.5, ring=[]; for(let i=0;i<16;i++){ const a=i/16*Math.PI*2; ring.push(addNode(IX+Math.cos(a)*14.8,IZ+Math.sin(a)*14.8)); } for(let i=0;i<16;i++) link(ring[i],ring[(i+1)%16]);
    const lanes=[[],[]]; [L1,L2].forEach((z,k)=>{ let last=-1; for(let x=616;x<=744;x+=9){ if(Math.hypot(x-IX,z-IZ)<17.5){ continue; } const n=addNode(x,z); lanes[k].push(n); if(last>=0&&Math.abs(nodes[n].x-nodes[last].x)<10.5) link(last,n); last=n; } });
    for(const lk of lanes) for(const n of lk) for(const r of ring) if(Math.hypot(nodes[n].x-nodes[r].x,nodes[n].z-nodes[r].z)<10.5) link(n,r);
    for(let i=0;i<9;i++) for(const k of [0,1]) for(const kk of [0,1]) if(lanes[k][i]!==undefined&&lanes[kk][i]!==undefined&&k!==kk) link(lanes[k][i],lanes[kk][i]);
    if(Game._brEnd){ link(Game._brEnd[0],lanes[0][0]); link(Game._brEnd[1],lanes[1][0]); }
    const branch=(ax,az,pts)=>{ let last=nearest(ax,az,14); for(const [x,z] of pts){ const n=addNode(x,z); link(last,n); last=n; } };
    branch(700,IZ-14.8,[[700,-6],[700,-16],[700,-24]]); branch(650,L1,[[650,4],[650,-2]]); branch(655,L2,[[655,34],[655,44]]); branch(700,IZ+14.8,[[700,42],[700,52]]); branch(745,L2,[[745,34],[745,42]]);
    /* tropik ve antik adalar: kıyı yürüyüş halkaları (+ tropik iskele) */
    const TI=W.islands[1], AI=W.islands[2], PHI=-Math.PI/4;
    const ringGraph=(I,r,n,off)=>{ const ids=[]; for(let i=0;i<n;i++){ const a=off+i/n*Math.PI*2; ids.push(addNode(I.x+Math.cos(a)*r,I.z+Math.sin(a)*r)); } for(let i=0;i<n;i++) link(ids[i],ids[(i+1)%n]); return ids; };
    const tr=ringGraph(TI,79.5,30,PHI); { let last=tr[0]; for(let i=8;i<=56;i+=8){ const n=addNode(TI.x+Math.cos(PHI)*(79.5+i+(96-79.5)*0),TI.z+Math.sin(PHI)*(79.5+i)); link(last,n); last=n; } }
    const EG=Game.Egypt; if(EG&&EG.walk){ const rid=EG.walk.rings.map(rg=>ringGraph({x:rg.cx,z:rg.cz},rg.r,rg.n,0));
      for(const pa of EG.walk.paths){ let last=nearest(pa[0][0],pa[0][1],16); for(const q of pa){ const n=addNode(q[0],q[1]); if(last>=0) link(last,n); last=n; } const e=nearest(pa[pa.length-1][0],pa[pa.length-1][1],40); if(e>=0&&e!==last) link(last,e); } }
    else ringGraph(AI,84,40,0);
    /* plaj patikası (beach.js): kıyı boyunca yürüyüş yolu; her 3. düğüm en yakın şehir/köprü düğümüne bağlanır (kıyıda gezinen + şezlonga uzanan NPC'ler) */
    const BE=Game.Beach; if(BE&&BE.paths&&BE.paths.length){ const pre=BE.paths.map(pa=>pa.map((q,i)=>i%3===0?nearest(q[0],q[1],46):-1));
      BE.paths.forEach((pa,pi)=>{ let last=-1; pa.forEach((q,i)=>{ const n=addNode(q[0],q[1]); nodes[n].beach=1; if(last>=0) link(last,n); last=n; if(pre[pi][i]>=0) link(n,pre[pi][i]); }); }); } }
  /* ---------- yol grafiği temizliği: evlerin/binaların içinden geçen kenarları sil, ana bileşende olmayan düğümleri devre dışı bırak ---------- */
  let segBlocked=()=>false;
  { const B=Game.buildings||[], K=40, R=.5, bk=new Map(), big=b=>b.hw>=2||b.hd>=2;
    for(const b of B){ if(!big(b)) continue; for(let gx=Math.floor((b.x-b.hw-2)/K);gx<=Math.floor((b.x+b.hw+2)/K);gx++) for(let gz=Math.floor((b.z-b.hd-2)/K);gz<=Math.floor((b.z+b.hd+2)/K);gz++){ const k=gx+","+gz; (bk.get(k)||bk.set(k,[]).get(k)).push(b); } }
    const inBox=(x,z,b)=>x>b.x-b.hw-R&&x<b.x+b.hw+R&&z>b.z-b.hd-R&&z<b.z+b.hd+R;
    const segBox=(ax,az,bx,bz,b)=>{ const x0=b.x-b.hw-R,x1=b.x+b.hw+R,z0=b.z-b.hd-R,z1=b.z+b.hd+R; let t0=0,t1=1; const dx=bx-ax,dz=bz-az;
      for(const [p0,q,lo,hi] of [[ax,dx,x0,x1],[az,dz,z0,z1]]){ if(Math.abs(q)<1e-9){ if(p0<lo||p0>hi) return false; } else { let a=(lo-p0)/q, c=(hi-p0)/q; if(a>c){ const t=a; a=c; c=t; } t0=Math.max(t0,a); t1=Math.min(t1,c); if(t0>t1) return false; } } return true; };
    const blocked=(ax,az,bx,bz)=>{ const k0x=Math.floor(Math.min(ax,bx)/K),k1x=Math.floor(Math.max(ax,bx)/K),k0z=Math.floor(Math.min(az,bz)/K),k1z=Math.floor(Math.max(az,bz)/K);
      for(let gx=k0x;gx<=k1x;gx++) for(let gz=k0z;gz<=k1z;gz++){ const l=bk.get(gx+","+gz); if(l) for(const b of l) if(segBox(ax,az,bx,bz,b)) return true; } return false; };
    segBlocked=blocked;
    let cut=0; nodes.forEach((n,i)=>{ n.nb=n.nb.filter(j=>{ if(j<i&&!nodes[j].nb.includes(i)) return false; const m=nodes[j]; if(blocked(n.x,n.z,m.x,m.z)){ cut++; return false; } return true; }); });
    nodes.forEach((n,i)=>{ n.nb=n.nb.filter(j=>nodes[j].nb.includes(i)||(nodes[j].nb.push(i),true)); });
    /* bileşenler: 8'den küçük kopuk parçalar kullanılmaz */
    const comp=new Int32Array(nodes.length).fill(-1); let nc=0; const sizes=[];
    for(let i=0;i<nodes.length;i++){ if(comp[i]>=0) continue; let sz=0; const st=[i]; comp[i]=nc; while(st.length){ const a=st.pop(); sz++; for(const j of nodes[a].nb) if(comp[j]<0){ comp[j]=nc; st.push(j); } } sizes.push(sz); nc++; }
    let off=0; nodes.forEach((n,i)=>{ if(sizes[comp[i]]<8){ n.nb=[]; off++; } });
    nodes.forEach(n=>{ n.graphDone=true; }); api_graph={cut,off,comps:nc,nodes:nodes.length}; }

  /* ---------- rota bulucu (A*): yaya grafiğinde hedefe en kısa yol; tehdit noktasından kaçınma cezası isteğe bağlı ---------- */
  const gS=new Float64Array(nodes.length), gF=new Float64Array(nodes.length), gP=new Int32Array(nodes.length), gV=new Int32Array(nodes.length); let gTick=0, routeCalls=0;
  const hK=[], hI=[];
  function hPush(k,i){ let c=hK.length; hK.push(k); hI.push(i); while(c>0){ const p=(c-1)>>1; if(hK[p]<=k) break; hK[c]=hK[p]; hI[c]=hI[p]; c=p; } hK[c]=k; hI[c]=i; }
  function hPop(){ const top=hI[0], k=hK.pop(), i=hI.pop(); const n=hK.length; if(n>0){ let c=0; while(true){ let l=c*2+1; if(l>=n) break; if(l+1<n&&hK[l+1]<hK[l]) l++; if(hK[l]>=k) break; hK[c]=hK[l]; hI[c]=hI[l]; c=l; } hK[c]=k; hI[c]=i; } return top; }
  function route(a,b,opt){ if(a<0||b<0||a>=nodes.length||b>=nodes.length) return null; if(a===b) return []; routeCalls++; opt=opt||{}; const ar=opt.ar||0, ap=opt.ap||0, ax=opt.ax, az=opt.az, nb=nodes[b]; gTick++; hK.length=0; hI.length=0;
    gS[a]=0; gP[a]=-1; gV[a]=gTick; hPush(Math.hypot(nodes[a].x-nb.x,nodes[a].z-nb.z),a); let exp=0, found=false;
    while(hK.length&&exp<9000){ const u=hPop(); exp++; if(u===b){ found=true; break; } const nu=nodes[u];
      for(const v of nu.nb){ const nv=nodes[v]; let w=Math.hypot(nv.x-nu.x,nv.z-nu.z); if(ar>0){ const d=Math.hypot(nv.x-ax,nv.z-az); if(d<ar) w*=1+ap*(1-d/ar); } const g=gS[u]+w;
        if(gV[v]!==gTick||g<gS[v]-1e-6){ gV[v]=gTick; gS[v]=g; gP[v]=u; hPush(g+Math.hypot(nv.x-nb.x,nv.z-nb.z),v); } } }
    if(!found) return null; const out=[]; for(let k=b;k!==a&&k>=0;k=gP[k]) out.push(k); out.reverse(); return out; }
  const CAP={low:34,medium:60,high:90,ultra:110}, MAXN=150, DENS={low:.5,mid:1,high:1.5}, capNow=()=>Math.max(14,Math.min(MAXN,Math.round((CAP[Game.quality]||60)*(DENS[Game.settings.npcd]||1)*(Game.npcK||1)))), GIBS=36, Gore=Game.Gore;
  /* ---------- insan modeli: örnekli ağlar (NPC i için slot=(GIBS+i)*mult, parça (gib) g için slot=g*mult) ---------- */
  const HK=Game.HumanKit, GEO=HK.geo, DM=HK.D, MESH={}, NAMES=["torso","torsoF","hips","hipsF","head","headF","hairS","hairL","hairC","hairP","hairB","hairA","hairM","hairBob","hairPig","hairQ","hat","hatB","hatW","glass","glassR","stache","goat","beardF","pack","skirt","skirtL","coat","tie","bag","watch","cane","phone","gun","uArm","fArm","hand","thigh","shin","shoe","wound"], MULT={uArm:2,fArm:2,hand:2,thigh:2,shin:2,shoe:2,wound:6};
  const mat=Game.noSnow(new THREE.MeshStandardMaterial({roughness:.72,metalness:0,vertexColors:true})), woundMat=Game.noSnow(new THREE.MeshStandardMaterial({roughness:.3,metalness:0,vertexColors:true})), white=new THREE.Color(1,1,1);
  for(const nm of NAMES){ const mult=MULT[nm]||1, N=(MAXN+GIBS)*mult, m=new THREE.InstancedMesh(GEO[nm],nm==="wound"?woundMat:mat,N); m.frustumCulled=false; m.castShadow=["torso","torsoF","hips","hipsF","head","headF","thigh","uArm","skirt","skirtL","coat"].includes(nm); m.mult=mult;
    for(let k=0;k<N;k++){ U.hide(m.instanceMatrix.array,k); m.setColorAt(k,white); } scene.add(m); MESH[nm]=m; }
  const toLin=h=>new THREE.Color(h).convertSRGBToLinear(), L=a=>a.map(toLin);
  const SKIN=L(["#f3d2b5","#e8bb94","#d4a07a","#b27a52","#8a5a38","#5e3b24"]), HAIRC=L(["#1b1612","#2a1c14","#3a2616","#5a3a1e","#8b5a2b","#c9a45c","#e6d29a","#a33a1e","#7d7d80","#2b3a6e"]),
    SHIRT=L(["#d94f4f","#4f7fd9","#4fb36a","#e0b43a","#9c5fd0","#e07d3a","#3ab9c4","#eeeeee","#555a66","#d65aa0","#233a5e","#8a2f2f","#2f6a4a","#c9c0a8","#101010"]), PANTS=L(["#2a2f3a","#3a3226","#1d2a44","#55595f","#6b5a3f","#1d1d1d","#5d7aa3","#7a6a52"]), SHOE=L(["#1a1a1a","#f0f0f0","#6a3d1e","#b22a2a","#2a4a8a"]),
    ICE=new THREE.Color(.55,.8,1), PURPLE=toLin("#7a2f9c"), BLK=new THREE.Color(.03,.03,.03), CHAR=new THREE.Color(.05,.03,.03), BLOOD=new THREE.Color(.42,.015,.02), HOT=new THREE.Color(1,.42,.06);
  const q=new THREE.Quaternion(), list=[], rs=U.rs, pick=a=>a[(Math.random()*a.length)|0], rnd=Math.random;
  const DEAD_LIFE=22, NS=1.3; /* NPC ölçeği: kahraman 1.4x olduğundan insanlar da büyütüldü */
  const api={list,nodes,scale:NS,get graph(){ return api_graph; }}; let cap=0, lastNoise=-9, T=0, DT=.016;
  const ST={}; api.states=ST;            /* yeni durumlar: ST[ad]={update(n,dt,c), pose(n,P,T,i,spd), place(n,q)->[x,y,z]} (npclife.js kaydeder) */
  api.route=route; api.nearestNode=nearest; api.blocked=(ax,az,bx,bz)=>segBlocked(ax,az,bx,bz); api.T=()=>T;
  /* en yakın düğüm; ama evin/binanın duvarından geçmeden ulaşılabilen (yakındakiler arasında en yakını) */
  function nearestFree(x,z,maxd){ let bi=-1,bd=1e18,fb=-1,fd=1e18; const lim=(maxd||40)*(maxd||40);
    for(let i=0;i<nodes.length;i++){ const nd=nodes[i]; if(!nd.nb.length) continue; const dx=nd.x-x, dz=nd.z-z, d=dx*dx+dz*dz; if(d>lim) continue; if(d<fd){ fd=d; fb=i; } if(d<bd&&!segBlocked(x,z,nd.x,nd.z)){ bd=d; bi=i; } }
    return bi>=0?bi:fb; }
  api.nearestFree=nearestFree;
  /* hedef/rota/koltuk/telefon bırak: NPC dış bir olayla (korku, vurulma, yakalanma) normal akıştan çıkarken */
  api.cancel=function(n,keepNode){ n.goal=null; n.path=null; n.goalNode=-1; if(n.seat){ if(n.seat.o===n) n.seat.o=null; n.seat=null; } n.phone=0; n.hl=null;
    if(n.carrying){ const p=n.carrying; n.carrying=null; if(p&&p.carrier===n){ p.carrier=null; } }
    if(n.carrier){ const c=n.carrier; n.carrier=null; if(c&&c.carrying===n) c.carrying=null; }
    if(api.onCancel) api.onCancel(n);
    if(!keepNode&&n.vis){ const ni=nearestFree(n.x,n.z); if(ni>=0){ n.nix=ni; n.pix=-1; } } };
  const center=()=>Game.mode==="play"&&Game.heroObj?Game.heroObj.position:{x:0,z:0};
  const HEAD=1, ARM0=2, ARM1=4, LEG0=8, LEG1=16, LOWER=32, ALL=63;
  /* ---------- 4x4 matris yardımcıları (sütun-ana, Float64) ---------- */
  const mk=()=>new Float64Array(16), MA=mk(),MB=mk(),MC=mk(),MD=mk(),ME=mk(),MF=mk(),MG=mk(),MH=mk(),MI=mk(),MJ=mk(),RM=mk(),UM=mk(),TMP=mk();
  function ident(o){ o.fill(0); o[0]=o[5]=o[10]=o[15]=1; return o; }
  function mul(o,a,b){ for(let c=0;c<4;c++){ const b0=b[c*4],b1=b[c*4+1],b2=b[c*4+2],b3=b[c*4+3]; for(let r=0;r<4;r++) o[c*4+r]=a[r]*b0+a[4+r]*b1+a[8+r]*b2+a[12+r]*b3; } return o; }
  function tr(o,x,y,z){ ident(o); o[12]=x; o[13]=y; o[14]=z; return o; }
  function rx(o,t){ ident(o); const c=Math.cos(t),s=Math.sin(t); o[5]=c;o[6]=s;o[9]=-s;o[10]=c; return o; }
  function rz(o,t){ ident(o); const c=Math.cos(t),s=Math.sin(t); o[0]=c;o[1]=s;o[4]=-s;o[5]=c; return o; }
  function ry(o,t){ ident(o); const c=Math.cos(t),s=Math.sin(t); o[0]=c;o[2]=-s;o[8]=s;o[10]=c; return o; }
  function fromQ(o,px,py,pz,qq,sx,sy,sz){ const x=qq.x,y=qq.y,z=qq.z,w=qq.w, xx=x*x,yy=y*y,zz=z*z;
    o[0]=(1-2*(yy+zz))*sx;o[1]=2*(x*y+z*w)*sx;o[2]=2*(x*z-y*w)*sx;o[3]=0; o[4]=2*(x*y-z*w)*sy;o[5]=(1-2*(xx+zz))*sy;o[6]=2*(y*z+x*w)*sy;o[7]=0; o[8]=2*(x*z+y*w)*sz;o[9]=2*(y*z-x*w)*sz;o[10]=(1-2*(xx+yy))*sz;o[11]=0; o[12]=px;o[13]=py;o[14]=pz;o[15]=1; return o; }
  /* a*T*R...: zincir adımı: out = parent * T(x,y,z) * Rz(zr) * Rx(xr) */
  function step(out,parent,x,y,z,zr,xr){ tr(TMP,x,y,z); mul(MJ,parent,TMP); if(zr){ rz(TMP,zr); mul(out,MJ,TMP); MJ.set(out); } if(xr){ rx(TMP,xr); mul(out,MJ,TMP); } else out.set(MJ); return out; }
  const put=(nm,slot,M)=>{ MESH[nm].instanceMatrix.array.set(M,slot*16); };
  const hide=(nm,slot)=>U.hide(MESH[nm].instanceMatrix.array,slot);
  const cset=(nm,slot,c)=>{ MESH[nm].setColorAt(slot,c); };
  const qrot=(qq,x,y,z)=>{ const ix=qq.w*x+qq.y*z-qq.z*y, iy=qq.w*y+qq.z*x-qq.x*z, iz=qq.w*z+qq.x*y-qq.y*x, iw=-qq.x*x-qq.y*y-qq.z*z; return [ix*qq.w+iw*-qq.x+iy*-qq.z-iz*-qq.y, iy*qq.w+iw*-qq.y+iz*-qq.x-ix*-qq.z, iz*qq.w+iw*-qq.z+ix*-qq.y-iy*-qq.x]; };
  const qrotInv=(qq,x,y,z)=>qrot({x:-qq.x,y:-qq.y,z:-qq.z,w:qq.w},x,y,z);

  /* ---------- görünüm ---------- */
  const OLDH=L(["#d8d8d8","#ececec","#a8a8a8"]), DYE=L(["#e2478a","#31d0c4","#8f55ff","#7ad63c","#ff8a1f","#2d8cff"]), TIEC=L(["#7a1020","#1d3a7a","#222222","#2a6a3a","#8a6a1d","#5a1d7a"]), WATCHC=L(["#d4af37","#c8ccd2","#1a1a1a","#8a8f99"]),
    BAGC=L(["#7b3f1d","#101010","#b22a2a","#e8d8c0","#2a4a8a","#c9a227","#d65aa0"]), FRC=L(["#101010","#7b3f1d","#b22a2a","#c9a227","#2a4a8a","#cfcfd6"]), BROWN=toLin("#6b4423");
  /* stil tabloları: hs 0 kısa,1 uzun,2 kıvırcık,3 kel,4 at kuyruğu,5 topuz,6 afro,7 hindistan horozu,8 küt,9 çift örgü/kuyruk,10 kabarık (pompadour) */
  const HAIRN=["hairS","hairL","hairC",null,"hairP","hairB","hairA","hairM","hairBob","hairPig","hairQ"], HATN=[null,"hat","hatB","hatW"], GLN=[null,"glass","glassR"], BEARDN=[null,"stache","goat","beardF"];
  const LOOKF=["g","hs","hat","gl","pk","sk","sh","sl","bd","wt","bg","tie","coat","dr","old","cane"];
  const wpick=ws=>{ let r=rnd()*ws.reduce((a,b)=>a+b,0); for(let i=0;i<ws.length;i++){ r-=ws[i]; if(r<=0) return i; } return 0; };
  const walkSpd=n=>(1.3+Math.random()*.8)*1.12*(n.old?.62:1)*(n.pers>.88?1.3:n.pers<.1?.82:1);
  function dress(n){ hideNpc(n); const g=n.g=rnd()<.5?0:1, old=n.old=rnd()<.13?1:0;
    n.hs=old?(g?[1,5,0,8][wpick([.2,.3,.3,.2])]:[3,0][wpick([.4,.6])]):g?[1,4,5,8,9,2,6,0,7][wpick([.24,.2,.12,.14,.05,.08,.06,.08,.03])]:[0,10,2,3,1,5,6,7,4][wpick([.26,.16,.1,.1,.08,.05,.06,.05,.04])];
    n.hat=rnd()<(old?.12:.2)?[1,2,3][wpick(g?[.3,.3,.4]:[.45,.35,.2])]:0;
    if(n.hat&&!(n.hs===1||n.hs===3||n.hs===4||n.hs===8)) n.hs=g?1:0;
    n.bd=g?0:old?(rnd()<.55?[1,2,3][wpick([.2,.15,.65])]:0):[0,1,2,3][wpick([.58,.12,.1,.2])];
    n.gl=old?(rnd()<.55?2:0):rnd()<.22?(rnd()<.45?1:2):0;
    n.pk=!old&&rnd()<.2?1:0; n.sl=rnd()<.35?1:0; n.sk=g&&rnd()<.28?1:0; n.dr=g&&!n.sk&&rnd()<.14?1:0; n.sh=!n.sk&&(n.dr||rnd()<.2)?1:0;
    n.coat=!n.sl&&rnd()<.3?1:0; n.tie=!g&&!n.sl&&!n.pk&&rnd()<.16?1:0; n.wt=rnd()<.28?1:0; n.bg=g&&!n.pk&&rnd()<.3?1:0; n.cane=old&&rnd()<.5?1:0; n.phn=0;
    const bw=rnd()<.12?1.2:rnd()<.1?.88:1; n.ht=((g?.93:.98)+rnd()*.12)*NS*(old?.96:1); n.wd=((g?.88:.96)+rnd()*.2)*NS*bw;
    n.shirt=pick(SHIRT); n.skin=pick(SKIN); n.pants=pick(PANTS); n.hair=old?pick(OLDH):((n.hs===7||rnd()<.05)&&rnd()<.7?pick(DYE):pick(HAIRC)); n.shoe=pick(SHOE); n.hatc=pick(SHIRT); n.packc=pick(SHIRT); n.coatc=pick(SHIRT); n.tiec=pick(TIEC); n.wc=pick(WATCHC); n.bagc=pick(BAGC); n.frc=pick(FRC);
    n.shade=0; n.purple=0; n.pcA=0; n.sx=null; n.sxHit=false; n.cut=0; n.wounds=[]; n.pooled=false; n.s1=rnd(); n.s2=rnd(); n.s3=rnd(); n.s4=rnd(); n.hq=0; n.hw=0; n.po=null; n.phS=0; n.ck=0; n.golden=0; n.role=null; n.keep=false; n.phone=0; n.hl=null; n.carrying=null; n.carrier=null; n._paid=false; n.pers=rnd(); n.shopped=0; n.thief=0; n.hasBag=0; n.grp=null; n.pa=null; n.stall=null; n.door=null; n.victim=null; n.tstate=0; n.caught=0; n.runner=0; n.seat=null; n.mission=null; n.gunUp=0; }
  const tmpC=new THREE.Color();
  const SHADEC=new THREE.Color(.004,.002,.008);
  function tint(n,c){ tmpC.copy(c); const bl=n.burn>0?Math.min(1,n.burn):0; if(bl>0) tmpC.lerp(CHAR,bl*.92); if(n.frozen) tmpC.lerp(ICE,.85); if(n.shade>0) tmpC.lerp(SHADEC,Math.min(1,n.shade)); return tmpC; }
  const base=n=>GIBS+n.i;
  function colorSet(n,b){ const sh=tint(n,n.shirt).clone(), sk=tint(n,n.skin).clone(), pa=tint(n,n.pants).clone(), hc=tint(n,n.hair).clone(), shoe=tint(n,n.shoe).clone(), cc=n.coat?tint(n,n.coatc).clone():sh;
    if(n.purple>0) sk.lerp(PURPLE,Math.min(1,n.purple)*.9);
    cset(n.g?"torsoF":"torso",b,sh); cset(n.g?"hipsF":"hips",b,pa); cset(n.g?"headF":"head",b,sk);
    const hn=HAIRN[n.hs]; if(hn) cset(hn,b,hc); const ht=HATN[n.hat]; if(ht) cset(ht,b,tint(n,n.hatc)); if(n.gl===1) cset("glass",b,n.shade>0?tint(n,white):white); else if(n.gl===2) cset("glassR",b,tint(n,n.frc)); if(n.bd) cset(BEARDN[n.bd],b,hc);
    if(n.pk) cset("pack",b,tint(n,n.packc)); if(n.sk) cset("skirt",b,pa); if(n.dr) cset("skirtL",b,sh); if(n.coat) cset("coat",b,cc); if(n.tie) cset("tie",b,tint(n,n.tiec)); if(n.bg) cset("bag",b,tint(n,n.bagc)); if(n.wt) cset("watch",b,tint(n,n.wc)); if(n.cane) cset("cane",b,tint(n,BROWN)); cset("phone",b,white);
    for(let s=0;s<2;s++){ const k=b*2+s; cset("uArm",k,cc); cset("fArm",k,(n.sl&&!n.coat)?sk:cc); cset("hand",k,sk); cset("thigh",k,(n.sk?sk:pa)); cset("shin",k,(n.sk||n.sh)?sk:pa); cset("shoe",k,shoe); }
    for(const nm of NAMES) if(MESH[nm].instanceColor) MESH[nm].instanceColor.needsUpdate=true; }
  function setColors(n){ colorSet(n,base(n)); }
  /* kafa takımı (kafa + saç + şapka + gözlük + sakal) tek yerden: n = NPC ya da parça look'u; sway: saç sallanma matrisi (varsa) */
  const HEADSET=n=>{ const a=[n.g?"headF":"head"]; if(HAIRN[n.hs]) a.push(HAIRN[n.hs]); if(HATN[n.hat]) a.push(HATN[n.hat]); if(GLN[n.gl]) a.push(GLN[n.gl]); if(BEARDN[n.bd]) a.push(BEARDN[n.bd]); return a; };
  const SWAYS={hairP:1,hairPig:.7,hairL:.45,hairBob:.15}, MS=mk();
  function putHead(n,slot,M,sway){ put(n.g?"headF":"head",slot,M); const hn=HAIRN[n.hs]; if(hn){ const k=SWAYS[hn]; if(k&&sway){ /* pivot: kafa üstü-arka */ tr(TMP,0,.1,-.07); mul(MS,M,TMP); rx(TMP,sway[0]*k); mul(MG,MS,TMP); if(sway[1]){ rz(TMP,sway[1]*k); mul(MS,MG,TMP); MG.set(MS); } tr(TMP,0,-.1,.07); mul(MS,MG,TMP); put(hn,slot,MS); } else put(hn,slot,M); }
    const ht=HATN[n.hat]; if(ht) put(ht,slot,M); if(n.gl) put(GLN[n.gl],slot,M); if(n.bd) put(BEARDN[n.bd],slot,M); }
  function hideNpc(n){ const b=base(n); for(const nm of NAMES){ const m=MULT[nm]||1; for(let s=0;s<m;s++) hide(nm,b*m+s); } }
  function respawn(n){ if(n.body){ P.removeBody(n.body); n.body=null; } const c=center(); let ix=-1;
    for(let k=0;k<28;k++){ const i=(Math.random()*nodes.length)|0, nd=nodes[i]; if(!nd.nb.length) continue; const d=Math.hypot(nd.x-c.x,nd.z-c.z); if(d>35&&d<170){ ix=i; break; } }
    n.dead=false; n.burn=0; n.frozen=0; n.held=false; n.limp=0; n.hurt=false; n.rescue=0; if(n.seat&&n.seat.o===n) n.seat.o=null; n.seat=null; n.goal=null; n.path=null; n.goalNode=-1; if(n.carrying&&n.carrying.carrier===n) n.carrying.carrier=null; if(n.carrier&&n.carrier.carrying===n) n.carrier.carrying=null; n.fade=0; dress(n);
    if(ix<0){ n.vis=false; n.st="gone"; n.t=0; n.x=0; n.z=0; n.y=-50; hideNpc(n); setColors(n); return; }
    const nd=nodes[ix], t=pick(nd.nb); n.nix=t; n.pix=ix; n.x=nd.x+rs()*.4; n.z=nd.z+rs()*.4; n.y=W.surfaceAt(n.x,n.z,60);
    n.ang=Math.atan2(nodes[t].x-n.x,nodes[t].z-n.z); n.st="walk"; n.t=0; n.spd=walkSpd(n); n.hp=1; n.vis=true; n.fx=n.x; n.fz=n.z; n.anim=Math.random()*6; setColors(n); if(api.onSpawn) api.onSpawn(n); }
  function pickNext(n,flee){ if(n.path&&n.path.length){ n.pix=n.nix; n.nix=n.path.shift(); return; } let best=-1,bs=-1e9, cur=nodes[n.nix];
    for(const a of cur.nb){ const nd=nodes[a], dx=nd.x-cur.x, dz=nd.z-cur.z, l=Math.hypot(dx,dz)||1; let sc=Math.random()*.6;
      if(a===n.pix) sc-=flee?1.5:1.2;
      else if(flee){ const ex=n.x-n.fx, ez=n.z-n.fz, el=Math.hypot(ex,ez)||1; sc+=(dx*ex+dz*ez)/(l*el)*2.2; }
      else if(n.pix>=0){ const pv=nodes[n.pix], px=cur.x-pv.x, pz=cur.z-pv.z, pl=Math.hypot(px,pz)||1; sc+=Math.max(0,(dx*px+dz*pz)/(l*pl))*.7; }
      if(sc>bs){ bs=sc; best=a; } }
    if(best<0) best=cur.nb.length?cur.nb[0]:n.nix; n.pix=n.nix; n.nix=best; }

  /* kaçış planı: tehditten uzak, bina içinden geçmeyen bir hedef düğüm seç, A* ile oraya git (tehdit çevresi pahalı) */
  function fleePlan(n){ n.path=null; const ni=n.nix; if(ni===undefined||ni<0||!nodes[ni]) return; const tx=n.fx, tz=n.fz; if(tx===undefined) return; const d0=Math.hypot(n.x-tx,n.z-tz); let best=-1,bs=-1e9;
    for(let j=0;j<nodes.length;j++){ const nd=nodes[j]; if(!nd.nb.length) continue; const dx=nd.x-n.x, dz=nd.z-n.z; if(Math.abs(dx)>90||Math.abs(dz)>90) continue; const dd=Math.hypot(dx,dz); if(dd<26||dd>90) continue; const sc=(Math.hypot(nd.x-tx,nd.z-tz)-d0)-dd*.12+Math.random()*14; if(sc>bs){ bs=sc; best=j; } }
    if(best>=0){ const r=route(ni,best,{ax:tx,az:tz,ar:24,ap:7}); if(r&&r.length>1&&r.length<48) n.path=r; } }
  api.fleePlan=fleePlan;
  /* merak: kahraman uçarken/yakındayken kafa ona döner */
  function lookHero(n,dt,c){ if(Game.mode!=="play"||!Game.heroObj){ if(n.hl) n.hl=null; return; } const dx=c.x-n.x, dz=c.z-n.z, d2=dx*dx+dz*dz, st=n.st; let want=false;
    if(d2<1700&&st!=="shock"&&st!=="flee"&&st!=="burn"&&st!=="chat"&&st!=="frozen"&&st!=="shade"&&st!=="gone"&&!n.carrying){ want=((c.y||0)>n.y+4)||d2<190; }
    if(!want){ if(n.hl){ const k=Math.exp(-4*dt); n.hl[0]*=k; n.hl[1]*=k; if(Math.abs(n.hl[0])+Math.abs(n.hl[1])<.012) n.hl=null; } return; }
    let a=Math.atan2(dx,dz)-n.ang; a=Math.atan2(Math.sin(a),Math.cos(a)); a=Math.max(-1.1,Math.min(1.1,a)); const pit=Math.atan2((c.y||0)-(n.y+1.5*NS),Math.sqrt(d2)+.1), tn=Math.max(-.45,Math.min(.5,-pit*.6));
    if(!n.hl) n.hl=[0,0]; const k=1-Math.exp(-5*dt); n.hl[0]+=(a-n.hl[0])*k; n.hl[1]+=(tn-n.hl[1])*k; }
  function goldFx(n,dt){ n.gfx=(n.gfx||0)-dt; if(n.gfx<=0){ n.gfx=.1; FX.glow(n.x,n.y+1.3*NS,n.z,2.6,[1,.82,.25],.16); } if(Math.random()<dt*16) FX.spark(n.x+rs()*.4,n.y+Math.random()*1.8*NS,n.z+rs()*.4,1,2.5,[1,.9,.4]); }
  /* özel görünümler: sağlıkçı, polis, hırsız, altın NPC */
  const C_MED=toLin("#e8531e"), C_WHT=toLin("#f4f4f4"), C_NAVY=toLin("#1d2f5e"), C_NAVYD=toLin("#0f1a36"), C_BLK=toLin("#121212"), C_GOLD=toLin("#ffd34a"), C_GOLDD=toLin("#c58a10"), C_GOLDH=toLin("#fff1a8"), C_GOLDS=toLin("#f2c14a");
  function restyle(n){ hideNpc(n); n.hq=0; n.hw=0; n.po=null; n.phS=0; setColors(n); }
  api.makeRole=function(n,role){ n.role=role; n.keep=(role==="medic"||role==="cop");
    const base={coat:0,tie:0,sl:0,cane:0,old:0,bg:0,sk:0,dr:0,sh:0,pk:0,wt:0,gl:0,hat:0};
    if(role==="medic") Object.assign(n,base,{shirt:C_MED,pants:C_WHT,pk:1,packc:C_WHT,shoe:SHOE[1]});
    else if(role==="cop"){ Object.assign(n,base,{shirt:C_NAVY,pants:C_NAVYD,hat:1,hatc:C_NAVY,shoe:SHOE[0],gl:rnd()<.5?2:0,frc:FRC[0],wt:1,wc:WATCHC[1]}); if(!(n.hs===1||n.hs===3||n.hs===4||n.hs===8)) n.hs=n.g?1:3; }
    else if(role==="thief"){ Object.assign(n,base,{shirt:C_BLK,pants:C_BLK,hat:2,hatc:C_BLK,gl:2,frc:FRC[0],shoe:SHOE[0],sl:1}); if(!(n.hs===1||n.hs===3||n.hs===4||n.hs===8)) n.hs=n.g?1:3; n.thief=1; }
    if(n.g===1&&role==="cop") n.sk=0;
    restyle(n); };
  api.makeGolden=function(n){ n.golden=1; n.runner=1; Object.assign(n,{shirt:C_GOLD,pants:C_GOLDD,skin:C_GOLDS,hair:C_GOLDH,shoe:C_GOLDD,hat:0,coat:0,tie:0,pk:0,sk:0,dr:0,sh:0,gl:0,bd:0,old:0,cane:0,wt:1,wc:C_GOLD}); restyle(n); };
  api.unRole=function(n){ n.role=null; n.keep=false; n.gunUp=0; n.thief=0; n.runner=0; if(n.golden){ n.golden=0; } };
  api.countGolden=function(){ let c=0; for(const n of list) if(n.golden&&n.vis&&!n.dead) c++; return c; };
  api.pickNext=pickNext; api.walkSpd=walkSpd; api.respawn=respawn; api.hide=hideNpc; api.colors=setColors; api.nm=n=>n.nm;
  api.setCap=function(){ const c=capNow(); while(list.length>c){ const n=list.pop(); if(n.goal||n.seat||n.carrying||n.carrier||ST[n.st]||n.role) api.cancel(n,true); if(n.body) P.removeBody(n.body); hideNpc(n); }
    while(list.length<c){ const n={i:list.length}; list.push(n); respawn(n); }
    cap=c; for(const nm of NAMES) MESH[nm].count=(GIBS+c)*(MULT[nm]||1); };

  /* ---------- parçalar (gib) ---------- */
  const gibs=[]; for(let g=0;g<GIBS;g++) gibs.push({on:false,g,body:null,kind:"",age:0});
  let gibHead=0;
  const GK={ head:{half:[.11,.13,.11],mass:5,off:0,ctr:[0,1.66,0]}, arm:{half:[.06,.33,.06],mass:3,off:.32,ctr:[0,1.1,0]}, leg:{half:[.09,.45,.09],mass:8,off:.45,ctr:[0,.45,0]}, lower:{half:[.17,.5,.12],mass:18,off:-.5,ctr:[0,.5,0]}, torso:{half:[.2,.27,.12],mass:16,off:-1.22,ctr:[0,1.22,0]}, pelvis:{half:[.17,.13,.12],mass:9,off:-.9,ctr:[0,.9,0]} };
  const gslot=(nm,g)=>g*(MULT[nm]||1);
  function gibHide(gb){ for(const nm of NAMES){ const m=MULT[nm]||1; for(let s=0;s<m;s++) hide(nm,gb.g*m+s); } }
  function gibColors(gb,n){ colorSet(n,gb.g); }
  function spawnGib(kind,n,lp,vx,vy,vz,opt){ opt=opt||{}; const gb=gibs[gibHead]; gibHead=(gibHead+1)%GIBS; if(gb.on) freeGib(gb);
    const K=GK[kind], rq=n.rq||{x:0,y:0,z:0,w:1}, rp=n.rp||{x:n.x,y:n.y,z:n.z}, sc=n.sc||[1,1], lc=opt.ctr||K.ctr, o=qrot(rq,lc[0]*sc[0],lc[1]*sc[1],lc[2]*sc[0]);
    const b=P.addBody([K.half[0]*sc[0],K.half[1]*sc[1],K.half[2]*sc[0]],K.mass,rp.x+o[0],Math.max(.3,rp.y+o[1]),rp.z+o[2],P.G_NPC,P.G_STATIC|P.G_DEBRIS|P.G_CAR);
    b.quaternion.set(rq.x,rq.y,rq.z,rq.w); b.velocity.set(vx,vy,vz); b.angularVelocity.set(rs()*9,rs()*9,rs()*9); b.linearDamping=.1; b.angularDamping=.3;
    const look={ht:sc[1],wd:sc[0]}; for(const f of LOOKF) look[f]=n[f]; Object.assign(gb,{on:true,kind,body:b,age:0,n:look,side:opt.side||0,legs:opt.legs||0,bend:opt.bend||[.5,.4],tr:0,wound:opt.wound||0,pooled:false,bt:0,s1:rnd(),s2:rnd()}); gibColors(gb,n); return gb; }
  function freeGib(gb){ if(gb.body){ P.removeBody(gb.body); gb.body=null; } gb.on=false; gibHide(gb); }
  const WCOLS={red:BLOOD,burn:HOT};
  function gibWound(gb,kind,type){ /* gib üzerinde kesik yüzeyi (yerel eklem noktası) */ gb.woundType=type; }
  function gibRender(gb){ const b=gb.body; if(!b) return; const K=GK[gb.kind], p=b.position, g=gb.g, sc=gb.n, sx=sc.wd, sy=sc.ht;
    gibHide(gb); const wnd=(lx,ly,lz,s,col)=>{ tr(MI,lx,ly,lz); mul(MH,MA,MI); const sM=mk(); sM[0]=s;sM[5]=s*.7;sM[10]=s;sM[15]=1; mul(MG,MH,sM); put("wound",g*6+(gb._w++),MG); cset("wound",g*6+(gb._w-1),col); };
    fromQ(RM,p.x,p.y,p.z,b.quaternion,sx,sy,sx); tr(TMP,0,K.off,0); mul(MA,RM,TMP); gb._w=0; const wc=gb.wound===2?HOT:BLOOD;
    if(gb.kind==="head"){ putHead(gb.n,g,MA); wnd(0,-.2,0,.06,wc); }
    else if(gb.kind==="arm"){ const s=gb.side?1:-1; ident(TMP); step(MB,MA,0,0,0,s*.3,-gb.bend[0]); put("uArm",g*2,MB); step(MC,MB,0,-DM.uArm,0,0,-gb.bend[1]); put("fArm",g*2,MC); step(MD,MC,0,-DM.fArm,0,0,0); put("hand",g*2,MD); if(!gb.side&&gb.n.wt) put("watch",g,MC); if(gb.side&&gb.n.bg) put("bag",g,MC); wnd(0,.02,0,.05,wc); }
    else if(gb.kind==="leg"){ step(MB,MA,0,0,0,0,gb.bend[0]*.6); put("thigh",g*2,MB); step(MC,MB,0,-DM.thigh,0,0,-gb.bend[1]*1.2); put("shin",g*2,MC); step(MD,MC,0,-DM.shin,0,0,.2); put("shoe",g*2,MD); wnd(0,.02,0,.07,wc); }
    else if(gb.kind==="lower"){ put(gb.n.g?"hipsF":"hips",g,MA); if(gb.n.sk) put("skirt",g,MA); if(gb.n.dr) put("skirtL",g,MA); const lg=gb.legs; for(let s=0;s<2;s++){ if(lg&(1<<s)) continue; const sg=s?1:-1; step(MB,MA,sg*DM.hipX,DM.hipY,0,sg*.12,(s?.2:-.2)*(gb.s1-.3)); put("thigh",g*2+s,MB); step(MC,MB,0,-DM.thigh,0,0,.3+.4*gb.s2*(s+1)*.5); put("shin",g*2+s,MC); step(MD,MC,0,-DM.shin,0,0,0); put("shoe",g*2+s,MD); } wnd(0,.99,0,.14,wc); }
    else if(gb.kind==="torso"){ put(gb.n.g?"torsoF":"torso",g,MA); if(gb.n.pk) put("pack",g,MA); if(gb.n.coat) put("coat",g,MA); if(gb.n.tie) put("tie",g,MA); wnd(0,.97,0,.14,wc); wnd(0,1.5,0,.05,wc); wnd(-.2,1.4,0,.05,wc); wnd(.2,1.4,0,.05,wc); }
    else if(gb.kind==="pelvis"){ put(gb.n.g?"hipsF":"hips",g,MA); if(gb.n.sk) put("skirt",g,MA); if(gb.n.dr) put("skirtL",g,MA); wnd(0,1,0,.14,wc); wnd(-.1,.84,0,.06,wc); wnd(.1,.84,0,.06,wc); }
    for(let k=gb._w;k<6;k++) hide("wound",g*6+k); }
  function gibUpdate(dt){ for(const gb of gibs){ if(!gb.on) continue; const b=gb.body; gb.age+=dt;
      if(!b||!isFinite(b.position.x)||b.position.y<-12||gb.age>45||b.sunk){ freeGib(gb); continue; }
      const sp=b.velocity.length(); gb.bt-=dt; if(sp>3&&gb.age<4&&gb.bt<=0&&Gore.on()){ gb.bt=.07; Gore.hit(b.position.x,b.position.y,b.position.z,b.velocity.x*.1,b.velocity.y*.1,b.velocity.z*.1,.25); }
      if(!gb.pooled&&gb.age>1&&sp<.8&&Gore.on()){ gb.pooled=true; Gore.pool(b.position.x,Math.max(W.surfaceAt(b.position.x,b.position.z,b.position.y+1),-1),b.position.z,.7+(gb.kind==="torso"||gb.kind==="lower"?.7:0),4); }
      gb.sck=(gb.sck||0)-dt; if(gb.sck<=0){ gb.sck=.4; if(sp<2){ const su=P.support(b); if(su===0){ gb.air=(gb.air||0)+1; if(gb.air>=2) P.ghost(b,true); } else { gb.air=0; if(b.ghost&&su===1&&!P.insideStatic(b)) P.ghost(b,false); } } else gb.air=0; }
      gibRender(gb); for(const nm of NAMES) MESH[nm].instanceMatrix.needsUpdate=true; } }
  api.clearGibs=function(){ for(const gb of gibs) if(gb.on) freeGib(gb); };

  /* ---------- hasar / durum geçişleri ---------- */
  function makeRag(n,vx,vy,vz){ if(n.body) P.removeBody(n.body);
    const hh=.85*(n.ht||NS), b=P.addBody([.25*(n.wd||NS),hh,.2*(n.wd||NS)],70*NS*NS,n.x,n.y+hh+.1,n.z,P.G_NPC,P.G_STATIC|P.G_DEBRIS|P.G_CAR); b.velocity.set(vx,vy,vz);
    Game.Real.tumble(b,vx,vz,Math.min(5.5,Math.hypot(vx,vz)*.28+.6),1.2); b.linearDamping=.04; b.angularDamping=.2; b.quaternion.setFromAxisAngle(new P.CN.Vec3(0,1,0),n.ang); n.body=b; }
  const cp=n=>({x:n.x,y:(n.body?n.body.position.y:n.y+.95*NS),z:n.z});
  function die(n){ if(n.dead) return; n.dead=true; n.deadT=0; n.hurt=false; Game.Ev.emit("npcKill",n,n.hitKind||n.hurtBy); }
  function bodyPos(n,lx,ly,lz){ const rp=n.rp||{x:n.x,y:n.y,z:n.z}, rq=n.rq||{x:0,y:0,z:0,w:1}, sc=n.sc||[1,1], o=qrot(rq,lx*sc[0],ly*sc[1],lz*sc[0]); return {x:rp.x+o[0],y:rp.y+o[1],z:rp.z+o[2]}; }
  const VMAXH=38, VMAXU=20, LETHAL={punch:1,laser:1,boom:1};
  /* hasar: tek yerden. d: 0..1+ ; ölürse olay yayılır (coin, polis, konuşma) */
  api.hurt=function(n,d,cause){ if(n.dead||!(d>0)) return; n.hp-=d; n.hurtBy=cause||n.hurtBy; if(n.hp<=.01){ n.hp=0; n.hitKind=cause||n.hitKind; die(n); } };
  api.hit=function(n,vx,vy,vz,kind,o){ if(!n.vis) return; n.fade=0; if(n.frozen){ api.shatter(n); return; } if(n.st==="held"){ n.held=false; }
    const sp0=Math.hypot(vx,vy,vz);   /* hasar ham (kuvvet) hızından; hareket gerçekçi şekle sokulur */
    { const R=Game.Real.npc(kind,vx,vy,vz); vx=R[0]; vy=R[1]; vz=R[2]; const h=Math.hypot(vx,vz); if(h>VMAXH){ const k=VMAXH/h; vx*=k; vz*=k; } if(vy>VMAXU) vy=VMAXU; }
    const was=n.st; if(n.goal||n.seat||n.phone||n.carrying||n.carrier||ST[was]||n.hl) api.cancel(n,true); makeRag(n,vx,vy,vz); n.st="rag"; n.t=0; n.getting=0; n.pv=undefined; n.hitKind=kind; n.rescue=0; n.lastHit=T; n.limp=0; n.hurtT0=T;
    const p=cp(n), lethal=!!LETHAL[kind];
    if(lethal) api.hurt(n,1.2,kind);
    else if(kind==="car"){ const sp=(o&&o.speed)||sp0*.6; api.hurt(n,sp<4?.08:sp<8?.3+(sp-4)*.06:sp<13?.55+(sp-8)*.1:1.2,"car"); }
    else if(kind==="throw"){ api.hurt(n,sp0<14?0:Math.min(1.2,(sp0-14)*.03),"throw"); }
    else api.hurt(n,.4,kind);
    if(Gore.on()){ if(lethal) Gore.hit(p.x,p.y+.4,p.z,vx,vy,vz,kind==="punch"?1.1:.7); const sp=Math.hypot(vx,vy,vz);
      if(kind==="car"&&n.dead) Gore.hit(p.x,p.y+.4,p.z,vx*.5,vy*.4,vz*.5,.8);
      if(kind==="punch"&&rnd()<.55) api.rip(n,vx,vy,vz,rnd()<.3?2:1);
      else if((kind==="boom"||kind==="clap"||kind==="gravity")&&Math.hypot(vx,vz)>34&&rnd()<.7) api.explode(n,vx,vy,vz,Math.hypot(vx,vz)*.6); }
    else if(lethal){ FX.dust(p.x,p.y+.4,p.z,5,2); FX.spark(p.x,p.y+.5,p.z,6,6,[1,.95,.7]); }
    Game.Ev.emit("npcHit",n,kind,sp0); if(Game.audio) Game.audio.thud(p.x,p.y,p.z); api.alert(p.x,p.z,35,p.x,p.z); };
  api.char=function(n){ n.burn=1; setColors(n); };
  api.setPurple=function(n,k){ n.purple=k; if(Math.abs(k-(n.pcA||0))>.045||(k===0&&n.pcA)){ n.pcA=k; setColors(n); } };
  api.shatter=function(n){ if(n.goal||n.seat||ST[n.st]) api.cancel(n,true); const p=cp(n); FX.ice(p.x,p.y+.7,p.z,34,6); FX.spark(p.x,p.y+.7,p.z,8,6,[.8,.95,1]); if(Game.audio) Game.audio.glass(p.x,p.y,p.z);
    if(n.body){ P.removeBody(n.body); n.body=null; } n.vis=false; n.st="gone"; n.t=0; n.frozen=0; hideNpc(n); };
  api.burn=function(n){ if(!n.vis) return; if(n.goal||n.seat||n.phone||ST[n.st]) api.cancel(n); if(n.dead){ if(n.body&&n.st!=="held"){ if(n.frozen){ n.frozen=0; } n.cor=4.5; } return; } if(n.st==="burn") return; if(n.frozen){ n.frozen=0; setColors(n); } if(n.body){ P.removeBody(n.body); n.body=null; n.y=W.surfaceAt(n.x,n.z,60); }
    n.st="burn"; n.t=0; n.fx=n.x+rs(); n.fz=n.z+rs(); n.spd=6.2; n.getting=0; };
  api.freeze=function(n){ if(n.frozen||!n.vis||n.st==="burn") return; if(n.goal||n.seat||n.phone||ST[n.st]) api.cancel(n); if(n.dead&&n.body&&n.st!=="held"){ n.frozen=1; n.ft=0; setColors(n); const p=cp(n); FX.ice(p.x,p.y,p.z,16,2); return; } if(n.body){ n.x=n.body.position.x; n.z=n.body.position.z; n.y=W.surfaceAt(n.x,n.z,60); P.removeBody(n.body); n.body=null; }
    n.frozen=1; n.ft=0; n.fphase=n.anim; if(n.st==="held") n.held=false; n.st="frozen"; setColors(n); const p=cp(n); FX.ice(p.x,p.y+1,p.z,16,2); };
  api.shadow=function(n){ if(!n.vis||n.dead||n.st==="gone"||n.st==="shade"||n.st==="held"||n.st==="burn") return false; if(n.goal||n.seat||n.phone||ST[n.st]) api.cancel(n,true); n.frozen=0; if(n.body){ n.x=n.body.position.x; n.z=n.body.position.z; n.y=W.surfaceAt(n.x,n.z,60); P.removeBody(n.body); n.body=null; }
    n.st="shade"; n.t=0; n.shade=.01; n.fphase=n.anim; n.sy0=n.y; setColors(n); const p=cp(n); FX.E(true,p.x,p.y+.3,p.z,0,1,0,.5,3,.5,[.55,.3,1],[.1,0,.3],.8,0,.95); api.alert(n.x,n.z,28,n.x,n.z); return true; };
  api.vanish=function(n){ if(n.goal||n.seat) api.cancel(n,true); if(n.body){ P.removeBody(n.body); n.body=null; } n.held=false; n.frozen=0; n.shade=0; n.vis=false; n.st="gone"; n.t=0; hideNpc(n); };
  api.grab=function(n){ if(!n.vis||n.frozen) return false; if(n.goal||n.seat||n.phone||ST[n.st]||n.carrier||n.carrying) api.cancel(n,true); if(n.body){ P.removeBody(n.body); n.body=null; } n.st="held"; n.held=true; n.t=0; return true; };
  api.release=function(n,vx,vy,vz){ n.held=false; n.x=n.hx; n.z=n.hz; n.y=Math.max(W.surfaceAt(n.hx,n.hz,n.hy)+.05,n.hy-1.5*NS); api.hit(n,vx,vy,vz,"throw"); };

  /* ---------- kesme / koparma / parçalama (yalnızca +18 sansür KAPALIYKEN) ---------- */
  function ensureDead(n,vx,vy,vz){ if(n.frozen) n.frozen=0; if(n.st==="held") n.held=false; if(!n.body||n.st==="getup"||n.st==="walk"||n.st==="flee"||n.st==="chat"||n.st==="shock"||n.st==="burn"){ if(!n.body){ n.y=n.y; makeRag(n,vx,vy,vz); } n.st="rag"; n.t=0; } n.hp=0; die(n); }
  const PARTV=(n,vx,vy,vz,k)=>[vx*k+rs()*5,Math.max(2,vy*k)+rs()*2+3,vz*k+rs()*5];
  function woundBleed(n,wi,dirx,diry,dirz,dur,pw){ const w=n.wounds[wi]; Gore.bleed(()=>{ if(!n.vis||n.st==="gone") return null; const p=bodyPos(n,w.x,w.y,w.z); return p; },dirx,diry,dirz,dur,pw); }
  function addWound(n,lx,ly,lz,type){ if(n.wounds.length>=6) n.wounds.shift(); n.wounds.push({x:lx,y:ly,z:lz,type,t:0,s:type===3?.15:.075}); return n.wounds.length-1; }
  /* bit: HEAD, ARM0/1, LEG0/1, LOWER ; type 2=lazer(yanık), 1=koparma */
  function sever(n,bit,vx,vy,vz,type){ if(n.cut&bit||!Gore.on()||!n.vis) return false; if(n.frozen){ api.shatter(n); return true; }
    ensureDead(n,vx*.2,2,vz*.2); const sp=Math.hypot(vx,vz)+3, tw=type===2;
    const spv=(k)=>PARTV(n,vx,vy,vz,k), v=spv(.5); let w=-1, dp=null;
    if(bit===HEAD){ const o=bodyPos(n,0,1.66,0); spawnGib("head",n,[0,1.66,0],v[0],v[1]+2,v[2],{wound:type}); w=addWound(n,0,1.5,0,type); dp=[0,1.5,0]; }
    else if(bit===ARM0||bit===ARM1){ const s=bit===ARM1?1:0; spawnGib("arm",n,[s?.2:-.2,1.1,0],v[0],v[1],v[2],{side:s,wound:type,ctr:[(s?1:-1)*.22,1.1,0],bend:[.1+rnd()*.5,.3+rnd()*.8]}); w=addWound(n,(s?1:-1)*.2,1.4,0,type); }
    else if(bit===LEG0||bit===LEG1){ const s=bit===LEG1?1:0; spawnGib("leg",n,[s?.1:-.1,.45,0],v[0],v[1],v[2],{side:s,wound:type,ctr:[(s?1:-1)*.1,.45,0],bend:[rnd()*.5,.3+rnd()*.6]}); w=addWound(n,(s?1:-1)*.1,.9,0,type); }
    else if(bit===LOWER){ const lg=((n.cut&LEG0)?1:0)|((n.cut&LEG1)?2:0); spawnGib("lower",n,[0,.5,0],v[0]*.6,v[1]*.7,v[2]*.6,{wound:type,legs:lg}); w=addWound(n,0,.98,0,3); }
    n.cut|=bit; n.wounds[w].type=type; if(bit===LOWER) n.cut|=LEG0|LEG1;
    const p=bodyPos(n,0,bit===HEAD?1.5:bit===LOWER?.98:bit&(ARM0|ARM1)?1.4:.9,0);
    if(tw){ FX.spark(p.x,p.y,p.z,22,10,[1,.7,.3]); FX.glow(p.x,p.y,p.z,3.5,[1,.55,.2],.18); FX.smoke(p.x,p.y,p.z,3,.6); Gore.hit(p.x,p.y,p.z,vx*.3,2,vz*.3,.45); woundBleed(n,w,vx*.1,2,vz*.1,1.4,.5); }
    else { Gore.burst(p.x,p.y,p.z,vx*.4,Math.max(1,vy*.3)+2,vz*.4,1.3); woundBleed(n,w,0,3,0,5.5,1.1); }
    if(n.dead&&!n.pooled&&n.st!=="dead") n.pooled=false; if(Game.audio) Game.audio.thud(p.x,p.y,p.z); api.alert(p.x,p.z,45,p.x,p.z); return true; }
  const shuffle=a=>{ for(let i=a.length-1;i>0;i--){ const j=(Math.random()*(i+1))|0; const t=a[i]; a[i]=a[j]; a[j]=t; } return a; };
  /* rastgele uzuv(lar) kopar */
  api.rip=function(n,vx,vy,vz,count){ if(!Gore.on()) return false; let done=0; for(const bit of shuffle([ARM0,ARM1,LEG0,LEG1,HEAD])){ if(done>=(count||1)) break; if(sever(n,bit,vx,vy,vz,1)) done++; } return done>0; };
  /* tüm vücudu parçala */
  api.explode=function(n,vx,vy,vz,power){ if(!Gore.on()||!n.vis) return false; if(n.frozen){ api.shatter(n); return true; } power=power||14; ensureDead(n,0,0,0);
    const rp=n.rp||{x:n.x,y:n.y,z:n.z}, bits=[]; const sp=Math.hypot(vx,vz)||1, dx=vx/sp, dz=vz/sp; const V=(sx,sy,sz,k)=>[dx*power*k+sx*power*.4+rs()*4,5+rnd()*power*.45*k+sy,dz*power*k+sz*power*.4+rs()*4];
    const old=n.cut; if(!(old&HEAD)){ const v=V(0,2,0,.9); spawnGib("head",n,null,v[0],v[1],v[2],{wound:1}); }
    for(let s=0;s<2;s++){ const bit=s?ARM1:ARM0; if(!(old&bit)){ const v=V(s?1:-1,0,0,.8); spawnGib("arm",n,null,v[0],v[1],v[2],{side:s,wound:1,ctr:[(s?1:-1)*.22,1.1,0],bend:[rnd()*.7,.3+rnd()]}); } }
    for(let s=0;s<2;s++){ const bit=s?LEG1:LEG0; if(!(old&bit)&&!(old&LOWER)){ const v=V(s?1:-1,0,0,.7); spawnGib("leg",n,null,v[0],v[1],v[2],{side:s,wound:1,ctr:[(s?1:-1)*.1,.45,0],bend:[rnd()*.5,.3+rnd()*.6]}); } }
    { const v=V(0,0,0,.45); spawnGib("torso",n,null,v[0],v[1]+3,v[2],{wound:1}); } if(!(old&LOWER)){ const v=V(0,-1,0,.4); spawnGib("pelvis",n,null,v[0],v[1],v[2],{wound:1}); }
    const p=bodyPos(n,0,1.1,0); Gore.burst(p.x,p.y,p.z,dx*power,power*.3,dz*power,2.6); Gore.hit(p.x,p.y,p.z,0,6,0,1.6); for(let k=0;k<3;k++) Gore.burst(p.x+rs()*.5,p.y+rs()*.7,p.z+rs()*.5,rs()*power,power*.4,rs()*power,1.2);
    FX.dust(p.x,p.y,p.z,8,2); if(Game.audio){ Game.audio.thud(p.x,p.y,p.z); Game.audio.boom&&0; } Gore.pool(p.x,Math.max(W.surfaceAt(p.x,p.z,p.y+1),-1),p.z,1.6,5);
    if(n.body){ P.removeBody(n.body); n.body=null; } n.cut=ALL; n.vis=false; n.st="gone"; n.t=0; hideNpc(n); api.alert(p.x,p.z,50,p.x,p.z); return true; };
  /* lazer: ışının değdiği noktada keser (hit: dünya noktası, d: ışın yönü) */
  api.cutAt=function(n,hit,d){ if(!Gore.on()||!n.vis||n.cut===ALL) return false; const rp=n.rp||{x:n.x,y:n.y,z:n.z}, rq=n.rq||{x:0,y:0,z:0,w:1}, sc=n.sc||[1,1];
    const l=qrotInv(rq,hit.x-rp.x,hit.y-rp.y,hit.z-rp.z), lx=l[0]/sc[0], ly=l[1]/sc[1]; const side=lx>0?1:0, c=n.cut; let bit=0;
    if(Math.abs(lx)>.15&&ly>.55&&ly<1.5){ bit=side?ARM1:ARM0; if(c&bit) bit=(c&LOWER)?0:LOWER; }
    else if(ly>1.48){ bit=HEAD; if(c&bit) return false; }
    else if(ly>.92){ bit=LOWER; if(c&bit) return false; }
    else { if(c&LOWER) return false; bit=side?LEG1:LEG0; if(c&bit) bit=side?LEG0:LEG1; if(c&bit) return false; }
    if(!bit) return false; return sever(n,bit,d.x*7,d.y*4+1,d.z*7,2); };

  /* kütle/çarpışma dışı durumlar: araba çarpması bu NPC'leri tekrar vurmaz */
  const PASSIVE={rag:1,dead:1,hurt:1,held:1,gone:1,carried:1,getup:0};
  api.passive=st=>!!PASSIVE[st];
  api.nearest=function(x,y,z,r,fwdx,fwdz,cosMin){ let best=null,bd=r*r; for(const n of list){ if(!n.vis||n.st==="held"||n.st==="gone") continue; const p=n.body?n.body.position:{x:n.x,y:n.y+1.2*NS,z:n.z}; const dx=p.x-x,dy=p.y-y,dz=p.z-z, d=dx*dx+dy*dy+dz*dz; if(d>=bd) continue;
      if(fwdx!==undefined){ const l=Math.hypot(dx,dz)||1; if((dx*fwdx+dz*fwdz)/l<cosMin) continue; } bd=d; best=n; } return best; };
  api.alert=function(x,z,r,ex,ez){ for(const n of list){ if(!n.vis||n.dead||n.frozen) continue; const S=ST[n.st]; if(n.st!=="walk"&&n.st!=="chat"&&!(S&&S.shy)) continue; if(n.keep&&!(S&&S.shy)&&n.role) continue; if(n.thief&&!n.caught&&!n.tstate) continue; const d=Math.hypot(n.x-x,n.z-z); if(d>r) continue; if(n.goal||n.seat||n.phone||S) api.cancel(n);
    n.st="shock"; n.t=.3+Math.random()*.5+d*.004; n.fx=ex; n.fz=ez; n.ang=Math.atan2(ex-n.x,ez-n.z); } };
  api.noise=function(x,z,r){ if(T-lastNoise<.35) return; lastNoise=T; api.alert(x,z,r,x,z); };
  Game.radial=function(x,y,z,r,speed,kind){ let c=0;
    for(const n of list){ if(!n.vis) continue; const p=n.body?n.body.position:{x:n.x,y:n.y+.95*NS,z:n.z}; let dx=p.x-x,dz=p.z-z, d=Math.hypot(dx,dz); if(d>r) continue; const k=speed*(1-d/r*.7)/(d||1); api.hit(n,dx*k,6+speed*.35*(1-d/r),dz*k,kind); c++; }
    Cars.query(x,z,r,(kd,i,px,pz,d)=>{ const l=d||1, k=speed*.7*(1-d/r*.7)/l; Cars.hit(kd,i,(px-x)*k,5+speed*.25*(1-d/r),(pz-z)*k,4); c++; }); return c; };

  /* ---------- çizim: poz hesapla, eklem zincirini kur ---------- */
  const rootQ=new THREE.Quaternion(), PO={lean:0,hipL:0,hipR:0,knL:0,knR:0,shL:0,shR:0,abL:0,abR:0,elL:0,elR:0,nod:0,turn:0,bob:0,spread:0,twist:0,roll:0,ankL:0,ankR:0}, PKEYS=Object.keys(PO);
  /* yürüyüş döngüsü: topuk basışı -> yük alma -> itiş; leğen yalpası, gövde burulması, ayak bileği yuvarlanması, baş sabitleme */
  function poseOf(n,st,spd){ const P0=PO; for(const k of PKEYS) P0[k]=0; const ph=n.anim, i=n.i, old=n.old?1:0; n.phn=n.gunUp?2:((st==="chat"&&n.ck===2)||(n.phone&&(st==="walk"||st==="flee")))?1:0;
    const locomotion=(a,ph2)=>{ const run=spd>4, A=a*(run?1.05:.62)*(old?.7:1), s=Math.sin(ph2), c=Math.cos(ph2), K=(run?1.55:.9)*(old?.72:1), ca=Math.min(1,a*1.6);
      P0.hipL=A*s+(run?.2:.03)*a; P0.hipR=-A*s+(run?.2:.03)*a;
      P0.knL=.1+K*Math.max(0,c)*ca+.1*a*Math.max(0,-c); P0.knR=.1+K*Math.max(0,-c)*ca+.1*a*Math.max(0,c);
      P0.ankL=a*(.55*Math.max(0,-s)-.3*Math.max(0,s)); P0.ankR=a*(.55*Math.max(0,s)-.3*Math.max(0,-s));
      P0.shL=-A*.9*s; P0.shR=A*.9*s; const eb=run?1.3:.25; P0.elL=eb+(run?.45:.2)*Math.max(0,s); P0.elR=eb+(run?.45:.2)*Math.max(0,-s);
      P0.lean=(run?.26:.035*a)+old*.14; P0.bob=Math.abs(c)*(run?.055:.024)*a; P0.abL=P0.abR=run?.1:.045; P0.twist=-s*(run?.22:.11)*a*(old?.6:1); P0.roll=c*.03*a; P0.turn=-s*.05*a; };
    const SH=ST[st]; if(SH&&SH.pose){ SH.pose(n,P0,T,i,spd,locomotion,ph); return finishPose(n,st,P0); }
    if(st==="walk"||st==="flee"||st==="burn"){ const wk=Math.min(1,spd/1.8);
      if(st==="burn"){ locomotion(1,ph*1.3); P0.shL=-2.3+Math.sin(T*14+i)*.9; P0.shR=-2.2+Math.sin(T*12+i*2)*.9; P0.elL=.6+Math.sin(T*11+i)*.5; P0.elR=.6+Math.sin(T*9+i)*.5; P0.abL=P0.abR=.6; P0.nod=-.25; P0.twist=Math.sin(T*10+i)*.3; }
      else { locomotion(wk,ph); if(st==="walk"&&spd<.2){ P0.shL=P0.shR=0; }
        if(st==="flee"){ P0.abL=P0.abR=.3+Math.sin(T*9+i)*.1; P0.elL+=.3; P0.elR+=.3; P0.shL*=1.25; P0.shR*=1.25; P0.turn+=Math.sin(T*2.3+i)*.38; }
        if(st==="walk"&&n.cane){ P0.shR=-.22; P0.elR=.28; P0.abR=.08; }
        if(n.phone&&st==="walk"){ P0.shR=-1.2; P0.elR=1.75+Math.sin(T*1.1+i)*.03; P0.abR=.04; P0.nod+=.45; P0.lean+=.05; }
        if(n.carrying){ P0.shL=P0.shR=-1.15; P0.elL=P0.elR=.55; P0.abL=P0.abR=-.12; P0.lean=-.1; P0.nod=.2; P0.bob*=.5; }
        if(n.thief&&st==="flee"){ P0.shR=-.5; P0.elR=1.1; P0.lean+=.1; }
        if(n.limp){ P0.lean+=.14; P0.bob-=.035*Math.abs(Math.sin(ph)); P0.hipR*=.45; P0.knR*=.5; P0.elL=.9; P0.roll+=Math.sin(ph)*.09; P0.nod+=.2; }
        P0.nod+=-P0.lean*.65+old*.22; } }
    else if(st==="chat"){ const k=n.ck|0, br=Math.sin(T*1.7+i)*.006;
      if(k===0){ P0.shR=-.7+Math.sin(T*3.5+i)*.45; P0.elR=1.3+Math.sin(T*5+i)*.3; P0.shL=-.15; P0.elL=.35; P0.abR=.15; P0.abL=.08; P0.turn=Math.sin(T*1.3+i)*.35; P0.nod=Math.sin(T*2.2+i)*.07; }
      else if(k===1){ P0.shL=-.62; P0.shR=-.62; P0.elL=2.05; P0.elR=2.05; P0.abL=-.12; P0.abR=-.12; P0.turn=Math.sin(T*.6+i)*.55; P0.nod=Math.sin(T*.9+i)*.05; P0.roll=Math.sin(T*.5+i)*.03; }
      else { P0.shR=-1.2; P0.elR=1.75+Math.sin(T*7+i)*.03; P0.abR=.04; P0.shL=-.12; P0.elL=.3; P0.nod=.5+Math.sin(T*1.4+i)*.03; P0.lean=.07; P0.turn=Math.sin(T*.8+i)*.1; }
      P0.bob=br; P0.lean+=.02; P0.hipL=.04; P0.hipR=-.04; P0.roll+=Math.sin(T*.8+i)*.015; }
    else if(st==="shock"&&n.s1<.3){ const tr_=Math.sin(T*26+i)*.03; P0.lean=.75; P0.hipL=1.0; P0.hipR=.85; P0.knL=1.7; P0.knR=1.6; P0.bob=-.38*n.ht; P0.shL=-2.7+tr_; P0.shR=-2.8-tr_; P0.elL=P0.elR=1.9; P0.abL=P0.abR=.25; P0.nod=.7; P0.ankL=P0.ankR=.4; }
    else if(st==="shock"){ const tr_=Math.sin(T*30+i)*.04; P0.shL=-2.5+tr_; P0.shR=-2.5-tr_; P0.elL=P0.elR=.45; P0.abL=P0.abR=.3; P0.nod=-.2; P0.lean=-.1; P0.hipL=-.12; P0.hipR=.1; P0.knL=.2; P0.knR=.1; P0.bob=.01; }
    else if(st==="frozen"){ locomotion(.5,n.fphase||0); P0.bob=0; }
    else if(st==="shade"){ locomotion(.15,n.fphase||0); const q=Math.sin(T*26+i)*.06; P0.shL=-2.2+q; P0.shR=-2.3-q; P0.elL=P0.elR=.5; P0.abL=P0.abR=.35; P0.nod=-.35; P0.lean=-.12; P0.bob=0; P0.turn=Math.sin(T*2+i)*.2; }
    else if(st==="held"&&n.sx&&!n.dead&&Game.SpaceNPC&&Game.SpaceNPC.pose(n,P0,T,i)){ }
    else if(st==="held"){ P0.hipL=.15+Math.sin(T*6+i)*.3; P0.hipR=.1+Math.sin(T*6+i+2)*.3; P0.knL=.35; P0.knR=.25; P0.shL=-2.3+Math.sin(T*7+i)*.45; P0.shR=-2.2+Math.sin(T*7+i+1.7)*.45; P0.elL=.5; P0.elR=.5; P0.abL=P0.abR=.4; P0.nod=n.dead?.9:.25; P0.lean=n.dead?.2:0; if(n.dead){ P0.shL=.2; P0.shR=.2; P0.elL=.2; P0.elR=.2; P0.abL=P0.abR=.15; } }
    else if(st==="getup"){ const u=Math.max(0,1-n.t/.7), a=u*u*(3-2*u); P0.lean=1.2*a; P0.hipL=-.9*a; P0.hipR=-.7*a; P0.knL=1.2*a; P0.knR=1.0*a; P0.shL=-.8*a; P0.shR=-.6*a; P0.elL=.9*a; P0.elR=.9*a; P0.nod=-.4*a; }
    else if(st==="rag"||st==="dead"||st==="hurt"){ const f=n.body?Math.min(1,n.body.velocity.length()/8):0, s1=n.s1,s2=n.s2,s3=n.s3,s4=n.s4, fl=Math.sin(T*9+i)*.5*f; P0.shL=-1.3+s1*2.2+fl; P0.shR=-1.3+s2*2.2-fl; P0.abL=.35+s3*.9; P0.abR=.35+s4*.9; P0.elL=.2+s1*1.3; P0.elR=.2+s2*1.3; P0.hipL=-.5+s3*1.1+fl*.5; P0.hipR=-.5+s4*1.1-fl*.5; P0.knL=.2+s2*.9; P0.knR=.2+s1*.9; P0.nod=-.3+s3*.6; P0.turn=(s1-.5)*.7; }
    return finishPose(n,st,P0); }
  function finishPose(n,st,P0){ if(n.hl){ P0.turn+=n.hl[0]; P0.nod+=n.hl[1]; } return P0; }
  /* durum geçişlerinde ani sıçramayı önleyen poz harmanı (ragdoll'a vuruşta neredeyse anında) */
  const BLT={rag:.07,dead:.07,hurt:.2,held:.14,shock:.12};
  function blend(n,st,T0){ if(!n.po){ n.po={}; n.pf={}; for(const k of PKEYS) n.po[k]=T0[k]; n.pst=st; n.pb=1; }
    if(n.pst!==st){ n.pst=st; for(const k of PKEYS) n.pf[k]=n.po[k]; n.pb=0; }
    const O=n.po; if(n.pb<1){ n.pb=Math.min(1,n.pb+DT/(BLT[st]||.26)); const w=n.pb*n.pb*(3-2*n.pb); for(const k of PKEYS) O[k]=n.pf[k]+(T0[k]-n.pf[k])*w; } else for(const k of PKEYS) O[k]=T0[k];
    return O; }
  const PM=mk(), SWY=[0,0];
  /* saç/kuyruk yay-sönüm fiziği: hareketle geriye savrulur, durunca sallanarak oturur */
  function hairPhys(n,st,spd,P0){ const mov=(st==="walk"||st==="flee"||st==="burn"), run=spd>4, tgt=mov?(run?.5+Math.sin(n.anim*2+1)*.16:.1+Math.sin(n.anim*2+1)*.06):0;
    n.hw+=(-(n.hq-tgt)*70-n.hw*7)*DT; n.hq+=n.hw*DT; if(n.hq>1) n.hq=1; else if(n.hq<-.6) n.hq=-.6; SWY[0]=n.hq-P0.nod*.5; SWY[1]=mov?Math.cos(n.anim)*(run?.22:.09):Math.sin(T*1.3+n.i)*.015; return SWY; }
  const tmpV=new THREE.Vector3();
  function render(n){ const st=n.st, b=base(n), i=n.i;
    if(!n.vis){ hideNpc(n); return; }
    let px=n.x,py=n.y,pz=n.z, spd=0; let sw=n.wd*(n.g?.95:1), sh=n.ht;
    if(st==="rag"||((st==="dead"||st==="hurt")&&n.body)){ const bd=n.body; if(!bd){ hideNpc(n); return; } const bq=bd.quaternion; rootQ.x=bq.x;rootQ.y=bq.y;rootQ.z=bq.z;rootQ.w=bq.w; const r01=2*(rootQ.x*rootQ.y-rootQ.z*rootQ.w), r11=1-2*(rootQ.x*rootQ.x+rootQ.z*rootQ.z), r21=2*(rootQ.y*rootQ.z+rootQ.x*rootQ.w);
      const fk=n.fade>0?Math.max(.02,1-n.fade):1, ro=.85*sh*fk; px=bd.position.x-r01*ro; py=bd.position.y-r11*ro; pz=bd.position.z-r21*ro; if(fk<1){ sw*=fk; sh*=fk; } }
    else if(st==="held"){ px=n.hx; py=n.hy-1.5*NS; pz=n.hz; U.yawQ(n.ang,rootQ); }
    else if(st==="getup"){ U.yawQ(n.ang,rootQ); }
    else if(ST[st]){ const S=ST[st]; U.yawQ(n.ang,rootQ); if(S.place){ const o=S.place(n,rootQ); if(o){ px=o[0]; py=o[1]; pz=o[2]; } } spd=S.move?n.spd:0; }
    else { U.yawQ(n.ang,rootQ); spd=(st==="walk")?n.spd:(st==="flee"||st==="burn")?n.spd:0; }
    if(!(px===px)||!(py===py)){ hideNpc(n); return; }
    const P0=blend(n,st,poseOf(n,st,spd)); py+=P0.bob;
    n.rp=n.rp||{x:0,y:0,z:0}; n.rp.x=px;n.rp.y=py;n.rp.z=pz; n.rq=n.rq||{x:0,y:0,z:0,w:1}; n.rq.x=rootQ.x;n.rq.y=rootQ.y;n.rq.z=rootQ.z;n.rq.w=rootQ.w; n.sc=[sw,sh];
    fromQ(RM,px,py,pz,rootQ,sw,sh,sw); const cut=n.cut;
    /* leğen: yaw + yalpa; üst gövde: bel çevresinde eğilme, burulma ve karşı yalpa */
    tr(TMP,0,.9,0); mul(MA,RM,TMP); ry(TMP,-P0.twist*.55); mul(MB,MA,TMP); rz(TMP,P0.roll); mul(MC,MB,TMP); tr(TMP,0,-.9,0); mul(PM,MC,TMP);
    tr(TMP,0,DM.waistY,0); mul(MA,PM,TMP); ry(TMP,P0.twist); mul(MB,MA,TMP); rz(TMP,-P0.roll*1.6); mul(MC,MB,TMP); rx(TMP,P0.lean); mul(MA,MC,TMP); tr(TMP,0,-DM.waistY,0); mul(UM,MA,TMP);
    put(n.g?"torsoF":"torso",b,UM); if(n.pk) put("pack",b,UM); if(n.coat) put("coat",b,UM); if(n.tie) put("tie",b,UM);
    if(!(cut&LOWER)){ put(n.g?"hipsF":"hips",b,PM); if(n.sk) put("skirt",b,PM); if(n.dr) put("skirtL",b,PM); } else { hide("hips",b); hide("hipsF",b); hide("skirt",b); hide("skirtL",b); }
    /* kafa */
    if(!(cut&HEAD)){ tr(TMP,0,1.46,0); mul(MA,UM,TMP); rx(TMP,P0.nod); mul(MB,MA,TMP); ry(TMP,P0.turn-P0.twist*.6); mul(MC,MB,TMP); tr(TMP,0,.2,0); mul(MD,MC,TMP);
      putHead(n,b,MD,hairPhys(n,st,spd,P0)); }
    else { for(const nm of HEADSET(n)) hide(nm,b); }
    /* kollar */
    for(let s=0;s<2;s++){ const sg=s?1:-1, k=b*2+s, bit=s?ARM1:ARM0;
      if(cut&bit){ hide("uArm",k); hide("fArm",k); hide("hand",k); if(s){ hide("bag",b); hide("cane",b); hide("phone",b); hide("gun",b); } else hide("watch",b); continue; }
      step(MA,UM,sg*.205*(n.g?.93:1),DM.shY,0,sg*(s?P0.abR:P0.abL),-(s?P0.shR:P0.shL)); put("uArm",k,MA);
      step(MB,MA,0,-DM.uArm,0,0,-(s?P0.elR:P0.elL)); put("fArm",k,MB); step(MC,MB,0,-DM.fArm,0,0,0); put("hand",k,MC);
      if(!s){ if(n.wt) put("watch",b,MB); } else { if(n.bg) put("bag",b,MB); if(n.cane) put("cane",b,MC); if(n.phn===2){ put("gun",b,MC); if(n.phS===1) hide("phone",b); n.phS=2; } else if(n.phn){ put("phone",b,MC); if(n.phS===2) hide("gun",b); n.phS=1; } else if(n.phS){ hide(n.phS===2?"gun":"phone",b); n.phS=0; } } }
    /* bacaklar */
    for(let s=0;s<2;s++){ const sg=s?1:-1, k=b*2+s, bit=s?LEG1:LEG0;
      if(cut&(bit|LOWER)){ hide("thigh",k); hide("shin",k); hide("shoe",k); continue; }
      step(MA,PM,sg*DM.hipX*(n.g?.95:1),DM.hipY,0,sg*.04,-(s?P0.hipR:P0.hipL)); put("thigh",k,MA);
      step(MB,MA,0,-DM.thigh,0,0,(s?P0.knR:P0.knL)); put("shin",k,MB); step(MC,MB,0,-DM.shin,0,0,((s?P0.hipR:P0.hipL)-(s?P0.knR:P0.knL))*.25+(s?P0.ankR:P0.ankL)); put("shoe",k,MC); }
    /* yaralar */
    const WS=b*6; for(let k=0;k<6;k++){ const w=n.wounds[k]; if(!w){ hide("wound",WS+k); continue; } w.t+=0; const sM=MH; sM.fill(0); const sz=w.s, big=w.type===3; sM[0]=sz;sM[5]=big?sz*.45:sz*.7;sM[10]=sz;sM[15]=1;
      tr(TMP,w.x,w.y,w.z); mul(MG,RM,TMP); mul(MF,MG,sM); put("wound",WS+k,MF); const age=w.t, hot=w.type===2?Math.max(0,1-age/2.2):0; tmpC.copy(BLOOD); if(w.type===2) tmpC.copy(CHAR).lerp(HOT,hot); cset("wound",WS+k,tmpC); }
    if(n.wounds.length) MESH.wound.instanceColor.needsUpdate=true; }
  /* ragdoll bitti: ayağa kalk (yaralıysa topallayarak) */
  function standUp(n,limp){ const b=n.body; if(b){ const o=b.quaternion; n.ang=Math.atan2(2*(o.w*o.y+o.x*o.z),1-2*(o.y*o.y+o.z*o.z)); n.x=b.position.x; n.z=b.position.z; n.y=W.surfaceAt(n.x,n.z,60); P.removeBody(b); n.body=null; }
    n.st="getup"; n.t=0; n.hurt=false; n.limp=limp?1:0; const ni=nearestFree(n.x,n.z); if(ni<0){ respawn(n); return false; } n.nix=ni; n.pix=-1; n.x=nodes[ni].x+rs()*.2; n.z=nodes[ni].z+rs()*.2; n.y=W.surfaceAt(n.x,n.z,60); pickNext(n,false); return true; }
  function update(dt){ T+=dt; DT=Math.min(.1,dt); const c=center();
    if(list.length!==capNow()) api.setCap();
    for(const n of list){ n.t+=dt; const st=n.st; if(n.carHitT>0) n.carHitT-=dt; for(const w of n.wounds) w.t+=dt;
      if(!n.vis){ if(st==="gone"&&n.t>5) respawn(n); else { const S0=ST[st]; if(S0&&S0.off) S0.off(n,dt,c); } render(n); continue; }
      if(Math.hypot(n.x-c.x,n.z-c.z)>210&&st!=="held"&&st!=="rag"&&!n.keep){ respawn(n); continue; }
      if(n.hasHL||(n.vis&&st!=="rag"&&st!=="dead"&&st!=="hurt"&&st!=="held")) lookHero(n,dt,c);
      if(n.golden&&Math.hypot(n.x-c.x,n.z-c.z)<110) goldFx(n,dt);
      { const S=ST[st]; if(S){ if(S.update) S.update(n,dt,c); render(n); continue; } }
      if(st==="walk"||st==="flee"||st==="burn"){
        const tn=nodes[n.nix], tx=tn.x, tz=tn.z, dx=tx-n.x, dz=tz-n.z, d=Math.hypot(dx,dz), step=n.spd*dt; n.anim+=dt*n.spd*(n.spd>4?2.3:3.1);
        if(d<=step){ n.x=tx; n.z=tz; n.y=W.surfaceAt(n.x,n.z,60);
          if(st==="walk"&&n.goal&&n.nix===n.goalNode){ n.goalNode=-1; if(api.onArrive) api.onArrive(n); }
          else { const nearH=st==="walk"&&!n.goal&&!n.role&&Math.hypot(n.x-c.x,n.z-c.z)<130; let handled=false;
            if(nearH&&api.onIdle) handled=api.onIdle(n);
            if(!handled||n.st==="walk") pickNext(n,st!=="walk");
            if(nearH&&!handled&&n.st==="walk"&&!n.goal&&Math.random()<.06){ n.st="chat"; n.t=0; n.ck=(Math.random()*3)|0; n.ct=2.5+Math.random()*4; n.ang+=Math.PI*(Math.random()<.5?.5:-.5); } } }
        else { n.x+=dx/d*step; n.z+=dz/d*step; if(Game.Trees) Game.Trees.avoid(n,dx/d,dz/d,step); n.y=W.surfaceAt(n.x,n.z,60); const ta=Math.atan2(dx,dz); let da=ta-n.ang; da=Math.atan2(Math.sin(da),Math.cos(da)); n.ang+=da*(1-Math.exp(-9*dt)); }
        if(st==="flee"&&n.t>7&&!n.thief&&!n.runner){ n.st="walk"; n.path=null; n.spd=walkSpd(n)*(n.limp?.5:1); if(n.pers<.15) n.spd*=1.25; }
        if(st==="burn"){ n.burn=Math.min(1,n.t/4); if(Math.random()<dt*30) FX.fire(n.x+rs()*.5,n.y+(.6+Math.random()*1.1)*NS,n.z+rs()*.5,1,0,1.5,0,1.2*NS); if(Math.random()<dt*6) FX.smoke(n.x,n.y+1.8*NS,n.z,1,.6);
          if(((n.t*5)|0)!==(((n.t-dt)*5)|0)) setColors(n); if(n.t>4.2){ makeRag(n,0,0,0); n.st="dead"; n.deadT=0; n.dead=true; setColors(n); FX.smoke(n.x,n.y+1,n.z,5,1); } }
      } else if(st==="chat"){ n.anim+=dt; if(n.t>n.ct){ n.st="walk"; n.t=0; } }
      else if(st==="shock"){ n.t-=dt*2; if(n.t<=0){ n.st="flee"; n.t=0; n.spd=n.limp?2.6:(5.6+n.pers*1.5); n.anim=n.anim||0; fleePlan(n); pickNext(n,true); } }
      else if(st==="rag"||st==="dead"||st==="hurt"){ const b=n.body; if(!b){ n.st="walk"; continue; } if(!isFinite(b.position.x)||b.position.y<-12){ respawn(n); continue; }
        if(b.sunk){ P.removeBody(b); n.body=null; n.vis=false; n.st="gone"; n.t=0; hideNpc(n); continue; }
        { const spN=b.velocity.length(); if(!n.dead&&n.pv!==undefined&&n.t>.06){ const ds=n.pv-spN; if(ds>13) api.hurt(n,(ds-13)*.034,"impact"); } n.pv=spN; }
        n.x=b.position.x; n.z=b.position.z; n.y=Math.max(W.surfaceAt(n.x,n.z,b.position.y),b.position.y-.85*n.ht);
        /* destek denetimi: boşlukta/görünmez bina kutusunda asılı kalmasın, yere düşsün */
        n.sck=(n.sck||0)-dt; if(n.sck<=0){ n.sck=.3; const spd=b.velocity.length(); if(spd<3){ if(P.support(b)===0){ n.air=(n.air||0)+1; if(n.air>=2) P.ghost(b,true); } else { n.air=0; if(b.ghost&&P.support(b)===1&&!P.insideStatic(b)) P.ghost(b,false); } } else n.air=0; }
        if(n.cor>0){ n.cor-=dt; n.burn=Math.min(1,(n.burn||0)+dt*.35); if(Math.random()<dt*26) FX.fire(b.position.x+rs()*.5,b.position.y+rs()*.3,b.position.z+rs()*.5,1,0,1.4,0,1.1*NS); if(Math.random()<dt*5) FX.smoke(b.position.x,b.position.y+.4,b.position.z,1,.6); if(((n.cor*4)|0)!==(((n.cor+dt)*4)|0)) setColors(n); }
        if(n.frozen&&st==="dead"){ n.ft+=dt; if(n.ft>14){ n.frozen=0; setColors(n); } }
        if(st==="dead"){ n.deadT=(n.deadT||0)+dt; if(!n.pooled&&n.deadT>.5&&b.velocity.length()<1.5){ n.pooled=true; if(Gore.on()&&n.y>-1) Gore.pool(n.x,n.y,n.z,1.15,6); }
          if(n.deadT>DEAD_LIFE){ n.fade=(n.deadT-DEAD_LIFE)/1.4; if(n.fade>=1){ n.fade=0; n.vis=false; n.st="gone"; n.t=0; P.removeBody(b); n.body=null; hideNpc(n); } } else n.fade=0; }
        else if(st==="hurt"){ n.hurtT=(n.hurtT||0)+dt; if(n.hp<.35&&!n.rescue){ n.hp-=dt*.0035; if(n.hp<=.01){ n.hp=0; n.hitKind="bleed"; die(n); n.st="dead"; n.deadT=0; } }
          if(!n.dead&&!n.rescue&&n.hurtT>(n.hurtMax||55)&&b.velocity.length()<1.2){ if(!standUp(n,true)) continue; } }
        else if(n.t>1.3&&b.velocity.length()<1.2||n.t>8){ if(n.dead){ n.st="dead"; n.deadT=0; } else if(n.hp<.55){ n.st="hurt"; n.t=0; n.hurtT=0; n.hurt=true; n.hurtMax=40+Math.random()*30; Game.Ev.emit("npcHurt",n); } else { if(!standUp(n,false)) continue; } } }
      else if(st==="getup"){ if(n.t>.7){ if(n.limp){ n.st="walk"; n.t=0; n.spd=1.15; pickNext(n,false); } else { n.st="flee"; n.t=0; n.spd=6; n.fx=n.x+rs()*4; n.fz=n.z+rs()*4; fleePlan(n); pickNext(n,true); } } }
      else if(st==="frozen"){ n.ft+=dt; if(n.ft>14){ n.frozen=0; n.st="walk"; n.t=0; setColors(n); } }
      else if(st==="shade"){ const k=Math.min(1,n.t/.8); if(n.shade<1){ const ns=k; if(Math.abs(ns-n.shade)>.12||ns>=1){ n.shade=ns>=1?1:ns; setColors(n); } }
        const ph=n.t, cx=n.x, cz=n.z, cy=(n.sy0||n.y); if(Math.random()<dt*34) FX.E(false,cx+rs()*.5,cy+.4+Math.random()*1.5*NS,cz+rs()*.5,rs()*.8,.8+Math.random()*1.6,rs()*.8,1.1,.35,.9,[.02,0,.05],[0,0,0],.85,-.2,.95);
        if(Math.random()<dt*14) FX.E(true,cx+rs()*.4,cy+.3+Math.random()*1.6*NS,cz+rs()*.4,rs()*.5,1.2,rs()*.5,.7,.5,.1,[.62,.4,1],[.15,.05,.4],.8,-.4,.95);
        if(ph>1.2){ n.y=cy-(ph-1.2)*1.5*NS; } if(ph>2.1){ FX.E(false,cx,cy+.2,cz,0,0,0,1.2,1.4,3,[.02,0,.04],[0,0,0],.7,0,1); FX.E(true,cx,cy+.8,cz,0,2,0,.6,3,.2,[.7,.5,1],[.2,.1,.5],.8,-.5,.95); if(n.body){ P.removeBody(n.body); n.body=null; } n.shade=0; n.vis=false; n.st="gone"; n.t=0; hideNpc(n); n.dead=false; } }
      else if(st==="held"){ n.anim+=dt*8; }
      render(n); }
    gibUpdate(dt);
    for(const nm of NAMES) MESH[nm].instanceMatrix.needsUpdate=true; }
  api.reset=function(){ api.clearGibs(); for(const n of list){ if(n.body){ P.removeBody(n.body); n.body=null; } respawn(n); } if(Gore) Gore.clear(); };
  Game.updaters.push(dt=>{ if(Game.mode==="play"||Game.mode==="menu") update(dt); });
  Game.onQuality=()=>{ api.setCap(); };
  api.look=function(n,o){ Object.assign(n,o); hideNpc(n); n.hq=0; n.hw=0; n.po=null; n.phS=0; setColors(n); };
  api.setCap(); api.debug={MESH,NAMES,base,GIBS,MULT,gibs};
  return api;
})();
