"use strict";
/* ===== ACİL DURUM: yol grafiği, siren araçları ve AMBULANS görevi =====
   Yaralı bir NPC (npcHurt) → yakındaki biri telefonla arar → EN YAKIN hastaneden ambulans yola çıkar → ambulans yaralının yanında durur →
   iki sağlık görevlisi iner, diz çöküp müdahale eder, yaralıyı taşır → ambulansa yükler → hastaneye döner. Polis (Faz 4) aynı altyapıyı kullanır. */
Game.Emerg=(function(){
  const N=Game.NPC, Ev=Game.Ev, W=Game.W, P=Game.P, FX=Game.FX, U=Game.U, T=Game.Traffic, R=Game.carRefs, traffic=R.traffic, set=R.trafficSet, ST=N.states, list=N.list, CELL=W.CELL, lines=Game.trafficLines;
  const api={missions:[],vehicles:[],hospitals:[],stats:{dispatched:0,saved:0,aborted:0}}, rnd=Math.random, Q={x:0,y:0,z:0,w:1}, Q0={x:0,y:0,z:0,w:1};
  const hero=()=>Game.heroObj?Game.heroObj.position:{x:0,y:0,z:0};
  const norm=a=>Math.atan2(Math.sin(a),Math.cos(a));
  const SAY=(n,cat,o)=>{ if(Game.Speech) Game.Speech.say(n,cat,o); };
  const LIFE=()=>Game.NPCLife;

  /* ---------- yol grafiği: kavşaklar düğüm, aralarındaki şerit parçaları kenar ---------- */
  const nodes=new Map(), NL=[];
  const nk=(x,z)=>Math.round((x-17)/CELL)+","+Math.round((z-17)/CELL);
  function addNode(x,z){ const k=nk(x,z); let n=nodes.get(k); if(!n){ n={k,x:17+CELL*Math.round((x-17)/CELL),z:17+CELL*Math.round((z-17)/CELL),e:[],id:NL.length}; nodes.set(k,n); NL.push(n); } return n; }
  const link=(a,b,axis,line)=>{ const len=Math.hypot(a.x-b.x,a.z-b.z); a.e.push({to:b,axis,line,len}); b.e.push({to:a,axis,line,len}); };
  const lineOf=(axis,line)=>{ for(const l of lines) if(l.axis===axis&&l.line===line) return l; return null; };
  for(const ax of [0,1]){ for(const a of lines){ if(a.axis!==ax) continue; const cs=[]; for(const b of lines){ if(b.axis===ax) continue; if(T.X.has(ax+"|"+a.line+"|"+b.line)) cs.push(b.line); } cs.sort((p,q)=>p-q);
      let prev=null; for(const c of cs){ const n=ax===0?addNode(a.line,c):addNode(c,a.line); if(prev) link(prev,n,ax,a.line); prev=n; } } }
  const nodeAt=(x,z)=>{ const n=nodes.get(nk(x,z)); return n&&Math.abs(n.x-x)<4&&Math.abs(n.z-z)<4?n:null; };
  const coordOf=(n,axis)=>axis===0?n.z:n.x;
  function nodesOnLine(axis,line){ const a=[]; for(const n of NL) if((axis===0?n.x:n.z)===line) a.push(n); a.sort((p,q)=>coordOf(p,axis)-coordOf(q,axis)); return a; }
  function routeNodes(a,b){ if(!a||!b) return null; if(a===b) return [a]; const D=new Float64Array(NL.length).fill(1e18), Pv=new Int32Array(NL.length).fill(-1), done=new Uint8Array(NL.length); D[a.id]=0;
    for(let it=0;it<NL.length;it++){ let u=-1,bd=1e18; for(let i=0;i<NL.length;i++) if(!done[i]&&D[i]<bd){ bd=D[i]; u=i; } if(u<0) break; if(u===b.id) break; done[u]=1; for(const e of NL[u].e){ const v=e.to.id, d=D[u]+e.len; if(d<D[v]){ D[v]=d; Pv[v]=u; } } }
    if(D[b.id]>=1e17) return null; const out=[]; for(let k=b.id;k>=0;k=Pv[k]) out.push(NL[k]); out.reverse(); return out; }
  const pathLen=p=>{ let s=0; for(let i=0;i+1<p.length;i++) s+=Math.hypot(p[i].x-p[i+1].x,p[i].z-p[i+1].z); return s; };
  function legsFromNodes(path){ const legs=[]; for(let i=0;i+1<path.length;i++){ const p=path[i], q=path[i+1], axis=(p.x===q.x)?0:1, line=axis===0?p.x:p.z, from=coordOf(p,axis), to=coordOf(q,axis), dir=to>from?1:-1, last=legs[legs.length-1];
      if(last&&last.axis===axis&&last.line===line&&last.dir===dir) last.end=to; else legs.push({axis,line,dir,start:from,end:to}); } return legs; }
  api.graph={nodes,NL,routeNodes,legsFromNodes,nodeAt,lineOf,nodesOnLine};

  /* ---------- hastaneler ---------- */
  for(const k in Game.cellType){ if(Game.cellType[k]!=="hospital") continue; const [gx,gz]=k.split(",").map(Number); api.hospitals.push({gx,gz,x:gx*CELL,z:gz*CELL}); }
  api.stations=[]; for(const k in Game.cellType){ if(Game.cellType[k]!=="police") continue; const [gx,gz]=k.split(",").map(Number); api.stations.push({gx,gz,x:gx*CELL,z:gz*CELL}); }
  function hospNode(h,fx,fz){ let best=null,bd=1e18; for(const sx of [-1,1]) for(const sz of [-1,1]){ const n=nodeAt(h.x+sx*17,h.z+sz*17); if(!n||!n.e.length) continue; const d=Math.hypot(n.x-fx,n.z-fz); if(d<bd){ bd=d; best=n; } } return best; }
  function nearestHospital(x,z){ let best=null,bd=720; for(const h of api.hospitals){ const d=Math.hypot(h.x-x,h.z-z); if(d<bd&&hospNode(h,x,z)){ bd=d; best=h; } } if(!best) return null; return {h:best,node:hospNode(best,x,z),dist:bd}; }
  api.nearestHospital=nearestHospital;
  function nearestStation(x,z,maxD){ let best=null,bd=maxD||1e9; for(const h of api.stations){ const d=Math.hypot(h.x-x,h.z-z); if(d<bd&&hospNode(h,x,z)){ bd=d; best=h; } } if(!best) return null; return {h:best,node:hospNode(best,x,z),dist:bd}; }
  api.nearestStation=nearestStation; api.nodeNear=hospNode;

  /* ---------- hedef: yolda en yakın şerit noktası ---------- */
  function roadTarget(x,z){ let best=null,bd=24; for(const l of lines){ const lat=l.axis===0?Math.abs(x-l.line):Math.abs(z-l.line), al=l.axis===0?z:x; if(lat>=bd||al<l.lo+6||al>l.hi-6) continue; bd=lat; best={axis:l.axis,line:l.line,pos:al,lat}; } return best; }
  api.roadTarget=roadTarget;
  function planRoute(start,tg){ const on=nodesOnLine(tg.axis,tg.line); if(on.length<2) return null; let lo=null,hi=null; for(const n of on){ if(coordOf(n,tg.axis)<=tg.pos) lo=n; else if(!hi) hi=n; }
    let best=null,bc=1e18; for(const [node,dir] of [[lo,1],[hi,-1]]){ if(!node) continue; const c=coordOf(node,tg.axis), other=dir>0?hi:lo; if(other&&Math.abs(coordOf(other,tg.axis)-c)<22) continue; const path=routeNodes(start,node); if(!path) continue;
      let cost=pathLen(path)+Math.abs(tg.pos-c); const L=legsFromNodes(path), lastL=L[L.length-1]; if(lastL&&lastL.axis===tg.axis&&lastL.line===tg.line&&lastL.dir!==dir) cost+=1e6; if(cost<bc){ bc=cost; best={node,dir,path,c}; } }
    if(!best) return null; const stop=best.dir>0?Math.max(tg.pos,best.c+10):Math.min(tg.pos,best.c-10); const legs=legsFromNodes(best.path); legs.push({axis:tg.axis,line:tg.line,dir:best.dir,start:best.c,end:stop,final:true}); return {legs,stop}; }

  /* ---------- siren araçları: trafik girdilerini şerit parçalarıyla sürer ---------- */
  function acquire(role){ for(const t of traffic){ if(t.role===role&&t.gone&&!t.busy&&!t.dyn&&!t.driven) return t; } return null; }
  function basePose(t){ const a0=t.axis===0, of=t.off||0; return {x:a0?t.line-t.dir*1.9+t.dir*of:t.pos, z:a0?t.pos:t.line+t.dir*1.9-t.dir*of, r:a0?(t.dir>0?0:Math.PI):(t.dir>0?Math.PI/2:-Math.PI/2)}; }
  function setLeg(V,L,smooth){ const t=V.t; let o=null; if(smooth) o={x:t.cx+V.cx,z:t.cz+V.cz,r:t.ry+V.cr};
    t.axis=L.axis; t.line=L.line; t.dir=L.dir; t.pos=V.first!==null&&V.first!==undefined?V.first:L.start; V.first=null; const b=lineOf(L.axis,L.line)||{lo:-1e4,hi:1e4}; t.lo=b.lo; t.hi=b.hi;
    const bp=basePose(t); t.cx=bp.x; t.cz=bp.z; t.ry=bp.r; if(o){ V.cx=o.x-bp.x; V.cz=o.z-bp.z; V.cr=norm(o.r-bp.r); } if(L.final){ t.stopAt=L.end; } else t.stopAt=null; }
  function spawn(role,legs,speed,type){ const t=acquire(role); if(!t||!legs.length) return null; const L=legs[0], len=Math.abs(L.end-L.start), off=Math.min(9,len*.3), pos=L.start+L.dir*off;
    t.axis=L.axis; t.line=L.line; t.dir=L.dir; const b=lineOf(L.axis,L.line)||{lo:-1e4,hi:1e4}; t.lo=b.lo; t.hi=b.hi; if(!T.freeAt(t,pos)) return null;
    const idx=traffic.indexOf(t), V={t,idx,legs,leg:0,cx:0,cz:0,cr:0,first:pos,type,key:"v"+idx,role,arrived:false,done:false,broken:false,doneT:0,fxT:0};
    t.gone=false; t.dyn=false; t.driven=false; t.wreck=false; t.burnT=0; t.frozen=false; t.v=speed; t.spd=speed; t.spd0=type==="amb"?16:type==="tank"?8.5:24; V.base=t.spd0; t.hold=false; t.stopAt=null; t.siren=1; t.off=0; t.offT=0; t.busy=true; t.reck=false; t.hornT=0;
    setLeg(V,L,false); t.cx=basePose(t).x; api.vehicles.push(V); return V; }
  function release(V){ const t=V.t; t.gone=true; t.siren=0; t.hold=false; t.stopAt=null; t.busy=false; t.v=0; t.spd=0; t.off=0; t.offT=0; set.write(V.idx,0,-40,0,Q0,0,0,0,0); set.flush(); if(Game.audio&&Game.audio.siren) Game.audio.siren(V.key,V.type,0,0,false); const i=api.vehicles.indexOf(V); if(i>=0) api.vehicles.splice(i,1); V.released=true; }
  function driveV(V,dt){ const t=V.t; if(V.released) return;
    if(t.dyn||t.driven||t.wreck||t.burnT||t.gone){ if(V.broken&&t.gone&&!V.released&&!V.mission){ release(V); return; } if(!V.broken){ V.broken=true; t.siren=0; if(Game.audio&&Game.audio.siren) Game.audio.siren(V.key,V.type,0,0,false); } return; }
    const L=V.legs[V.leg]; if(!L){ V.done=true; } else { const rem=(L.end-t.pos)*L.dir;
      if(L.final){ t.stopAt=L.end; if(rem<3.4&&t.v<.7&&!V.arrived){ V.arrived=true; t.hold=true; } }
      else if(rem<=.35){ const nx=V.legs[V.leg+1]; if(nx){ V.leg++; setLeg(V,nx,true); } else V.done=true; } }
    if(V.done&&!V.released){ V.doneT+=dt; const hp=hero(), d=Math.hypot(t.cx-hp.x,t.cz-hp.z); if(V.mustVanish&&(d>32||V.doneT>7)){ release(V); return; } if(!V.mustVanish){ t.hold=true; } }
    { const lastL=V.legs[V.legs.length-1], base=V.base||t.spd0; if(!V.done&&!V.arrived&&lastL&&lastL.final&&V.legs[V.leg]){ let remD=Math.abs(V.legs[V.leg].end-t.pos); for(let q=V.leg+1;q<V.legs.length;q++) remD+=Math.abs(V.legs[q].end-V.legs[q].start); t.spd0=Math.max(4.5,Math.min(base,Math.sqrt(2*4.2*Math.max(0,remD-3)))); } else t.spd0=base; }
    if(!V.done&&!V.arrived&&!t.hold&&t.v<.4){ V.stuck=(V.stuck||0)+dt; if(V.stuck>3.2){ V.stuck=0; if(Game.audio&&Game.audio.honk){ Game.audio.honk(t.cx,1,t.cz); Game.audio.honk(t.cx,1.2,t.cz); } } } else V.stuck=0;
    const k=Math.exp(-dt*4.2); V.cx*=k; V.cz*=k; V.cr*=k; U.yawQ(t.ry+V.cr,Q); set.write(V.idx,t.cx+V.cx,.08,t.cz+V.cz,Q,t.sc.sx,t.sc.sy,t.sc.sz,0); set.flush();
    /* siren sesi + çakar ışığı */
    const hp=hero(), dd=Math.hypot(t.cx-hp.x,t.cz-hp.z); if(V.type!=="tank"&&Game.audio&&Game.audio.siren) Game.audio.siren(V.key,V.type,t.cx,t.cz,dd<260);
    V.fxT-=dt; if(V.type!=="tank"&&V.fxT<=0&&dd<130){ V.fxT=.16; V.fl=!V.fl; FX.glow(t.cx+V.cx,2.9,t.cz+V.cz,V.type==="amb"?4:3.4,V.fl?[1,.15,.12]:[.2,.35,1],.15); } }
  api.spawn=spawn; api.release=release; api.setLeg=setLeg;
  function planReturn(V,node){ const t=V.t; let on=nodesOnLine(t.axis,t.line); for(let tries=0;tries<2;tries++){ const seq=t.dir>0?on:on.slice().reverse(); let next=null; for(const n of seq){ if((coordOf(n,t.axis)-t.pos)*t.dir>1.5){ next=n; break; } }
      if(next){ const path=routeNodes(next,node); if(!path) return null; return [{axis:t.axis,line:t.line,dir:t.dir,start:t.pos,end:coordOf(next,t.axis)}].concat(legsFromNodes(path)); }
      t.dir=-t.dir; V.cr=norm(V.cr+Math.PI); }
    return null; }
  api.planReturn=planReturn;
  /* yeni hedefe yeniden rota: önce ilerideki kavşağa, oradan hedef şerit noktasına */
  function driveTo(V,tg){ const t=V.t; if(!tg||V.released||V.broken) return false; let on=nodesOnLine(t.axis,t.line);
    for(let tries=0;tries<2;tries++){ const seq=t.dir>0?on:on.slice().reverse(); let next=null; for(const n of seq){ if((coordOf(n,t.axis)-t.pos)*t.dir>2.2){ next=n; break; } }
      if(next){ const plan=planRoute(next,tg); if(!plan) return false; const first={axis:t.axis,line:t.line,dir:t.dir,start:t.pos,end:coordOf(next,t.axis)};
        V.legs=[first].concat(plan.legs); V.leg=0; V.arrived=false; V.done=false; V.mustVanish=false; V.first=null; t.hold=false; setLeg(V,V.legs[0],false); return true; }
      t.dir=-t.dir; V.cr=norm(V.cr+Math.PI); }
    return false; }
  api.driveTo=driveTo; api.planRoute=planRoute; api.recruit=recruit; api.placeRole=placeMedic; api.nodeOfPatient=null;

  /* ---------- sağlıkçı / yaralı durumları ---------- */
  ST.treat={ update(n,dt){ n.anim+=dt; const p=n.tr; if(p&&p.vis) n.ang+=norm(Math.atan2(p.x-n.x,p.z-n.z)-n.ang)*(1-Math.exp(-6*dt)); },
    pose(n,P0,T,i,spd,loco){ loco(0,0); const k=.5+.5*Math.sin(T*1.3+i); P0.hipL=1.05; P0.hipR=-.15; P0.knL=1.15; P0.knR=2.05; P0.bob=-.34*n.ht; P0.lean=.5; P0.nod=.28; P0.shL=-.9; P0.shR=-.8+k*.25; P0.elL=.5; P0.elR=.6; P0.abL=P0.abR=.1; } };
  ST.mwait={ update(n,dt){ n.anim+=dt; },
    pose(n,P0,T,i,spd,loco){ loco(0,0); P0.turn=Math.sin(T*.5+i)*.45; P0.nod=Math.sin(T*.8+i)*.05; P0.shL=-.1; P0.shR=-.1; P0.elL=.3; P0.elR=.3; P0.bob=Math.sin(T*1.6+i)*.005; } };
  ST.lie={ update(n,dt){ n.lt=Math.min(1,(n.lt||0)+dt/.7); n.anim+=dt; if(!n.carrier&&n.t>1&&!n.mission){ LIFE().resume(n); } },
    place(n,q){ const c=n.carrier; if(!c) return null; const e=Math.min(1,n.lt||0), k=e*e*(3-2*e), sh=c.ht, a=c.ang, psi=a-Math.PI/2, l0=n.l0||[n.x,n.y,n.z,a];
      const tx=c.x+Math.sin(a)*.5*sh/1.3, tz=c.z+Math.cos(a)*.5*sh/1.3, ty=c.y+.95*sh; const gy=l0[1]+.22*sh/1.3;
      const cyp=gy+(ty-gy)*k, cxp=l0[0]+(tx-l0[0])*k, czp=l0[2]+(tz-l0[2])*k, ps=l0[3]+norm(psi-l0[3])*k;
      const cy2=Math.cos(ps/2), sy2=Math.sin(ps/2), th=-Math.PI/2, cx2=Math.cos(th/2), sx2=Math.sin(th/2); q.x=cy2*sx2; q.y=sy2*cx2; q.z=sy2*sx2; q.w=cy2*cx2;
      const len=.92*n.ht; n.x=cxp; n.z=czp; return [cxp+Math.sin(ps)*len,cyp,czp+Math.cos(ps)*len]; },
    pose(n,P0,T,i){ P0.shL=-1.45+Math.sin(T*1.2+i)*.05; P0.shR=-1.5; P0.abL=P0.abR=.15; P0.elL=.25; P0.elR=.2; P0.hipL=-1.3; P0.hipR=-1.25; P0.knL=.3; P0.knR=.35; P0.nod=-.4; P0.turn=.4; } };

  /* ---------- görev akışı ---------- */
  let mid=0;
  function medicSpot(V){ const t=V.t, fx=Math.sin(t.ry), fz=Math.cos(t.ry); return {x:t.cx-fx*3.7,z:t.cz-fz*3.7,fx,fz,lx:fz,lz:-fx}; }
  function recruit(x,z,avoid){ const hp=hero(); let best=null,bs=-1e9;
    for(const n of list){ if(n.golden||n.thief||n.role||n.dead||n.mission||n.carrier||n.carrying||(avoid&&avoid.includes(n))) continue; let s;
      if(!n.vis&&n.st==="gone") s=1e6; else if(n.vis&&n.st==="walk"&&!n.goal&&!n.seat){ const dh=Math.hypot(n.x-hp.x,n.z-hp.z); if(dh<30) continue; s=dh-Math.hypot(n.x-x,n.z-z)*.2; } else continue;
      if(s>bs){ bs=s; best=n; } }
    return best; }
  function placeMedic(m,x,z,ang,role){ if(m.body){ P.removeBody(m.body); m.body=null; } N.cancel(m,true); N.makeRole(m,role||"medic"); m.vis=true; m.dead=false; m.hurt=false; m.frozen=0; m.burn=0; m.cut=0; m.wounds=[]; m.hp=1; m.x=x; m.z=z; m.y=W.surfaceAt(x,z,60); m.ang=ang; m.st="walk"; m.t=0; m.spd=3.6; m.anim=rnd()*6; m.limp=0; m.fade=0;
    const ni=N.nearestFree(x,z,40); if(ni<0) return false; m.nix=ni; m.pix=-1; m.path=null; return true; }
  function nodeOfPatient(p){ return N.nearestFree(p.x,p.z,40); }

  function onHurt(n){ if(Game.mode!=="play"||n.mission||n.thief||n.golden||n.role) return; if(api.missions.length>=2) return; if(Game.settings&&Game.settings.ambulance===false) return;
    const hp=hero(); if(Math.hypot(n.x-hp.x,n.z-hp.z)>230||n.y>6) return; const tgt=roadTarget(n.x,n.z); if(!tgt) return; const hs=nearestHospital(n.x,n.z); if(!hs) return;
    const M={id:++mid,patient:n,tgt,hosp:hs,st:"call",t:0,callT:3.8+rnd()*1.4,caller:null,amb:null,medics:[],flags:{}}; n.mission=M; n.rescue=1; api.missions.push(M);
    const S=Game.Speech, c=S&&S.witness?S.witness(n.x,n.z,n,34):null;
    if(c&&!c.goal&&!c.seat&&!c.role){ M.caller=c; N.cancel(c,true); c.st="chat"; c.ck=2; c.ct=M.callT+.5; c.t=0; c.ang=Math.atan2(n.x-c.x,n.z-c.z); SAY(c,"call",{pri:3,cd:2}); S.later(()=>{ if(c.vis&&c.st==="chat") SAY(c,"call",{pri:3,cd:0}); },2.2); }
    else M.callT=8; }
  Ev.on("npcHurt",onHurt);

  function dropPatient(M){ const p=M.patient; if(!p) return; const c=p.carrier; if(c){ c.carrying=null; p.carrier=null; } p.x=p.x||0; p.rescue=0; p.hp=Math.max(p.hp,.6); p.vis=true; p.dead=false; p.hurt=false; if(p.st==="lie") LIFE().resume(p); }
  function abort(M,why){ if(M.st==="done"||M.aborting) return; M.aborting=true; M.why=why; api.stats.aborted++; const p=M.patient;
    if(p){ if(p.st==="lie") dropPatient(M); else if(p.rescue) p.rescue=0; p.mission=null; }
    for(const m of M.medics){ if(!m||!m.vis||m.role!=="medic") continue; m.mission=null; N.cancel(m,true); m.carrying=null; N.unRole(m); LIFE().resume(m); }
    M.medics.length=0;
    if(M.amb&&!M.amb.broken&&!M.amb.released){ startLeave(M); } else M.st="done"; M.aborting=false; }
  function startLeave(M){ const V=M.amb, t=V.t; t.hold=false; t.stopAt=null; const legs=planReturn(V,M.hosp.node); if(!legs){ V.mustVanish=true; V.done=true; M.st="leave"; return; } V.legs=legs; V.leg=0; V.arrived=false; V.done=false; V.mustVanish=true; V.first=null; setLeg(V,legs[0],false); M.st="leave"; M.t=0; }
  function startDrive(M){ const plan=planRoute(M.hosp.node,M.tgt); if(!plan){ abort(M,"noroute"); return; } const V=spawn("amb",plan.legs,9,"amb"); if(!V){ M.spawnTry=(M.spawnTry||0)+1; M.callT=M.t+1.2; if(M.spawnTry>10) abort(M,"nospawn"); return; }
    M.amb=V; V.mission=M; M.st="drive"; M.t=0; api.stats.dispatched++; }
  function atPatient(m){ const M=m.mission; if(!M) return; m.st="treat"; m.t=0; m.tr=M.patient; }
  function atRear(m){ const M=m.mission; if(!M) return; m.st="mwait"; m.t=0; M.flags["r"+m.i]=1; }
  function spawnMedics(M){ const V=M.amb, sp=medicSpot(V), p=M.patient; const ms=[]; for(let k=0;k<2;k++){ const m=recruit(sp.x,sp.z,ms); if(!m) break; const s=k?1:-1; if(!placeMedic(m,sp.x+sp.lx*s*.9,sp.z+sp.lz*s*.9,Math.atan2(p.x-sp.x,p.z-sp.z))) break; m.mission=M; ms.push(m); }
    if(ms.length<2){ for(const m of ms){ m.mission=null; N.unRole(m); LIFE().resume(m); } abort(M,"nomedics"); return; }
    M.medics=ms; M.st="medics_go"; M.t=0; if(Game.audio&&Game.audio.door) Game.audio.door(); SAY(ms[0],"medic",{pri:3,cd:2});
    ms.forEach((m,k)=>{ const off=k?-.95:.95, ok=LIFE().walkTo(m,p.x+off,p.z+.2,{ang:Math.atan2(-off,-.2),spd:3.7,finish:atPatient}); if(!ok&&!M.aborting) abort(M,"nopath"); }); }
  function pickUp(M){ const [A,B]=M.medics, p=M.patient, V=M.amb; if(!A||!B||!A.vis||!B.vis){ abort(M,"medicLost"); return; }
    if(p.body){ P.removeBody(p.body); p.body=null; } p.l0=[p.x,p.y,p.z,p.ang||0]; p.lt=0; p.st="lie"; p.t=0; p.carrier=A; A.carrying=p; p.rescue=1; p.hurt=true;
    const sp=medicSpot(V); SAY(B,"medic",{pri:3,cd:0});
    for(const [m,spd,off] of [[A,2.3,0],[B,3.1,1.1]]){ m.st="walk"; m.spd=spd; const ni=N.nearestFree(m.x,m.z,40); if(ni>=0){ m.nix=ni; m.pix=-1; } m.path=null; const ok=LIFE().walkTo(m,sp.x+sp.lx*off,sp.z+sp.lz*off,{ang:Math.atan2(-sp.fx,-sp.fz),spd:spd,finish:atRear}); if(!ok){ abort(M,"nopath2"); return; } }
    M.st="carry"; M.t=0; }
  function load(M){ const [A,B]=M.medics, p=M.patient; if(p){ const c=p.carrier; if(c){ c.carrying=null; p.carrier=null; } p.mission=null; p.rescue=0; N.vanish(p); api.stats.saved++; Ev.emit("npcRescued",p); }
    for(const m of M.medics){ if(m){ m.mission=null; m.carrying=null; N.vanish(m); } } M.medics.length=0; if(Game.audio&&Game.audio.door) Game.audio.door(); startLeave(M); }
  function tickMission(M,dt){ M.t+=dt; const p=M.patient, V=M.amb;
    if(M.st!=="leave"&&M.st!=="done"){ if(V&&V.broken){ abort(M,"ambBroken"); }
      else if(M.st!=="carry"&&M.st!=="load"){ if(!p||!p.vis||p.dead||p.st==="gone"||p.st==="frozen"||p.st==="held"||p.st==="burn"||p.st==="shade"){ abort(M,"patientLost"); } else if(p.st!=="hurt"&&p.st!=="lie"){ M.badT=(M.badT||0)+dt; if(M.badT>14) abort(M,"patientChanged"); } else M.badT=0; }
      else if(!p||!p.vis||p.dead){ abort(M,"patientLost"); } }
    if(M.st==="done"){ return; }
    switch(M.st){
      case "call": if(M.t>=M.callT) startDrive(M); break;
      case "drive": if(V.arrived){ M.st="arrived"; M.t=0; } else if(M.t>150) abort(M,"timeout"); break;
      case "arrived": if(M.t>.9) spawnMedics(M); break;
      case "medics_go": { const [A,B]=M.medics; if(A&&B&&A.st==="treat"&&B.st==="treat"){ M.st="treat"; M.t=0; SAY(A,"medic",{pri:3,cd:0}); } else if(M.t>45) abort(M,"slow"); break; }
      case "treat": if(M.t>3.2) pickUp(M); break;
      case "carry": { const [A,B]=M.medics; if(A&&A.st==="mwait"){ M.loadT=(M.loadT||0)+dt; if((B&&B.st==="mwait"&&M.loadT>.7)||M.loadT>5) load(M); } else if(M.t>70) abort(M,"carryTimeout"); break; }
      case "leave": if(!V||V.released||V.broken||(V.done&&M.t>.1&&!V.mustVanish)) { M.st="done"; } else if(M.t>140){ if(!V.released) release(V); M.st="done"; } break; }
    if(M.st==="done"&&M.patient&&M.patient.mission===M) M.patient.mission=null; }

  /* sağlıkçı vuruldu/korktu → görev iptal */
  const prevCancel=N.onCancel;
  N.onCancel=function(n){ if(prevCancel) prevCancel(n); if(n.mission&&n.role==="medic"){ const M=n.mission; n.mission=null; if(M&&!M.aborting&&M.st!=="done"&&M.st!=="leave") abort(M,"medicHit"); } };

  api.reset=function(){ for(const V of api.vehicles.slice()) release(V); for(const M of api.missions){ const p=M.patient; if(p){ p.mission=null; p.rescue=0; } for(const m of M.medics){ if(m){ m.mission=null; N.unRole(m); } } } api.missions.length=0; if(Game.audio&&Game.audio.sirenStopAll) Game.audio.sirenStopAll(); };
  Game.updaters.push(dt=>{ if(Game.mode!=="play"){ if(Game.mode==="menu"&&(api.missions.length||api.vehicles.length)) api.reset(); return; } dt=Math.min(dt,.05);
    for(let i=api.missions.length-1;i>=0;i--){ const M=api.missions[i]; tickMission(M,dt); if(M.st==="done"){ api.missions.splice(i,1); } }
    for(const V of api.vehicles.slice()) driveV(V,dt); });
  api.debug={routeNodes,planRoute,legsFromNodes,nodesOnLine,medicSpot,recruit};
  return api; })();
