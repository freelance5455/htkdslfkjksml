"use strict";
/* ===== NPC KONUŞMALARI: alt yazı (13 dil), oyuncunun eylemlerine tepkiler + gündelik sohbet ===== */
Game.Speech=(function(){
  const N=Game.NPC, Ev=Game.Ev, CODES=["tr","en","de","ar","fr","ko","ja","ru","es","zh","pt","it","hi"];
  const NF=["Ayşe","Elif","Anna","Emma","Yuki","Mina","Sofia","Maria","Chloe","Hana","Eva","Zeynep","Lena","Aisha","Priya","Lucia"], NM=["Mehmet","John","Li","Ahmed","Lucas","Karim","Ivan","Carlos","Leo","Omar","Raj","Noah","Emre","Hans","Kenji","Marco"];
  const ROLE={medic:["Sağlıkçı","Paramedic","Sanitäter","مسعف","Ambulancier","구급대원","救急隊員","Медик","Paramédico","急救员","Paramédico","Paramedico","पैरामेडिक"],cop:["Polis","Police","Polizei","شرطي","Policier","경찰","警察官","Полицейский","Policía","警察","Polícia","Polizia","पुलिस"]};
  const api={shown:0,log:[]}, last={}, lastIdx={}, pending=[]; let lastAny=-9, clock=0, acc=0, wasPlay=false;
  const hero=()=>Game.heroObj?Game.heroObj.position:{x:0,y:0,z:0};
  const lang=()=>{ const i=CODES.indexOf(typeof currentLang!=="undefined"?currentLang:"en"); return i<0?1:i; };
  function label(n){ if(!n) return ""; if(n.role&&ROLE[n.role]) return ROLE[n.role][lang()]||ROLE[n.role][1]; if(!n.nm||n.nmg!==n.g){ n.nmg=n.g; n.nm=(n.g?NF:NM)[(Math.random()*16)|0]; } return n.nm; }
  function show(name,txt,dur){ const box=document.getElementById("subs"); if(!box) return; api.shown++; api.log.push(txt); if(api.log.length>20) api.log.shift();
    try{ const d=document.createElement("div"); d.className="sub"; d.setAttribute("dir","auto"); if(name){ const b=document.createElement("b"); b.textContent=name+": "; d.appendChild(b); } const s=document.createElement("span"); s.textContent=txt; d.appendChild(s); box.appendChild(d);
      while(box.children&&box.children.length>3) box.removeChild(box.firstChild);
      const ms=dur||(2400+txt.length*55); setTimeout(()=>{ try{ d.className="sub out"; }catch(e){} },ms); setTimeout(()=>{ try{ if(d.parentNode) d.parentNode.removeChild(d); }catch(e){} },ms+450); }catch(e){} }
  /* n: konuşan NPC (yoksa adsız), cat: kategori, o: {pri,cd,range,dur} */
  api.say=function(n,cat,o){ o=o||{}; const S=Game.settings; if(!S||!S.subs||Game.mode!=="play") return false; const lines=Game.SPEECH&&Game.SPEECH[cat]; if(!lines||!lines.length) return false;
    const pri=o.pri||1; if(clock-(last[cat]===undefined?-99:last[cat])<(o.cd!==undefined?o.cd:(pri>=3?1.5:5))) return false; if(clock-lastAny<(pri>=3?.6:1.4)&&pri<4) return false;
    if(n){ const hp=hero(); if(Math.hypot(n.x-hp.x,n.z-hp.z)>(o.range||40)) return false; }
    let k=(Math.random()*lines.length)|0; if(lines.length>1&&k===lastIdx[cat]) k=(k+1)%lines.length; lastIdx[cat]=k;
    const txt=lines[k][lang()]||lines[k][1]; last[cat]=clock; lastAny=clock; show(n?label(n):"",txt,o.dur); return true; };
  const later=(fn,d)=>pending.push({t:d,fn});
  const BAD={rag:1,dead:1,gone:1,held:1,burn:1,frozen:1,shade:1,hurt:1,inside:1};
  function witness(x,z,skip,r){ let best=null,bd=(r||26)*(r||26); const hp=hero(); for(const m of N.list){ if(!m.vis||m.dead||m===skip||BAD[m.st]||m.thief) continue; const dx=m.x-x, dz=m.z-z, d=dx*dx+dz*dz; if(d<bd&&(m.x-hp.x)*(m.x-hp.x)+(m.z-hp.z)*(m.z-hp.z)<1600){ bd=d; best=m; } } return best; }
  function react(cat,x,z,o){ o=o||{}; const w=witness(x,z,o.skip,o.r); if(w) later(()=>{ if(w.vis&&!w.dead&&!BAD[w.st]) api.say(w,cat,o); },o.delay!==undefined?o.delay:.6+Math.random()*.6); }
  api.react=react; api.witness=witness; api.later=later;
  Ev.on("npcKill",n=>react("kill",n.x,n.z,{skip:n,pri:2}));
  Ev.on("npcHit",(n,kind)=>{ if(kind==="car") react("car",n.x,n.z,{skip:n,cd:6}); else react("hit",n.x,n.z,{skip:n,cd:6}); });
  Ev.on("building",(bl,x,z)=>react("building",x,z,{r:40,pri:2,cd:6}));
  Ev.on("turbineBroken",T=>react("building",T.x,T.z,{r:40,pri:2,cd:6}));
  Ev.on("carDestroyed",(k,i,x,z)=>react("car",x,z,{cd:7,r:30}));
  Ev.on("playerRanOver",n=>{ if(n&&n.x!==undefined) react("car",n.x,n.z,{skip:n,cd:6}); });
  function poll(){ if(Game.mode!=="play") return; const hp=hero(), H=Game.H||{}; const sayNear=(cat,o,r)=>{ const w=witness(hp.x,hp.z,null,r||30); if(w) api.say(w,cat,o); };
    if(H.flying&&(H.speed||0)>24&&(H.alt||0)>8) sayNear("fly",{cd:16});
    if(Game.Lift&&Game.Lift.active) sayNear("lift",{cd:10,pri:2},26);
    for(const m of N.list){ if(m.vis&&m.st==="burn"&&Math.hypot(m.x-hp.x,m.z-hp.z)<35){ const w=witness(m.x,m.z,m,24); if(w) api.say(w,"fire",{cd:8,pri:2}); break; } }
    if(!H.flying&&(H.speed||0)<7){ for(const m of N.list){ if(m.vis&&!m.dead&&!BAD[m.st]&&!m.role&&!m.thief&&Math.hypot(m.x-hp.x,m.z-hp.z)<7){ api.say(m,"near",{cd:30}); break; } } } }
  Game.updaters.push(dt=>{ const play=Game.mode==="play"; if(!play){ if(wasPlay){ wasPlay=false; pending.length=0; const b=document.getElementById("subs"); try{ if(b) b.innerHTML=""; }catch(e){} } return; } wasPlay=true; dt=Math.min(dt,.1); clock+=dt;
    for(let k=pending.length-1;k>=0;k--){ const p=pending[k]; p.t-=dt; if(p.t<=0){ pending.splice(k,1); try{ p.fn(); }catch(e){} } }
    acc-=dt; if(acc<=0){ acc=.5; poll(); } });
  api.clock=()=>clock;
  return api; })();
