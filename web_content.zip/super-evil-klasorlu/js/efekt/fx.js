"use strict";
/* ===== PARÇACIK SİSTEMİ (özel shader'lı Points: boyut + renk + alfa parçacık başına) ===== */
const FX = Game.FX = (function(){
  const spr=(()=>{ const c=document.createElement("canvas"); c.width=c.height=64; const q=c.getContext("2d"), g=q.createRadialGradient(32,32,0,32,32,32);
    g.addColorStop(0,"rgba(255,255,255,1)"); g.addColorStop(.35,"rgba(255,255,255,.55)"); g.addColorStop(1,"rgba(255,255,255,0)"); q.fillStyle=g; q.fillRect(0,0,64,64);
    return new THREE.CanvasTexture(c); })();
  function mkSys(max,additive){
    const pos=new Float32Array(max*3), col=new Float32Array(max*4), siz=new Float32Array(max);
    const geo=new THREE.BufferGeometry(); geo.setAttribute("position",new THREE.BufferAttribute(pos,3)); geo.setAttribute("pc",new THREE.BufferAttribute(col,4)); geo.setAttribute("psz",new THREE.BufferAttribute(siz,1));
    geo.setDrawRange(0,0);
    const mat=new THREE.ShaderMaterial({transparent:true,depthWrite:false,blending:additive?THREE.AdditiveBlending:THREE.NormalBlending,uniforms:{tex:{value:spr},scale:{value:800},pmax:{value:300}},
      vertexShader:"attribute vec4 pc; attribute float psz; varying vec4 vc; uniform float scale; uniform float pmax; void main(){ vc=pc; vec4 mv=modelViewMatrix*vec4(position,1.); gl_Position=projectionMatrix*mv; gl_PointSize=clamp(psz*scale/max(-mv.z,.5),1.,pmax); }",
      fragmentShader:"uniform sampler2D tex; varying vec4 vc; void main(){ vec4 t=texture2D(tex,gl_PointCoord); float a=vc.a*t.a; if(a<.01) discard; gl_FragColor=vec4(vc.rgb,a); }"});
    const pts=new THREE.Points(geo,mat); pts.frustumCulled=false; pts.renderOrder=5; scene.add(pts);
    const f=n=>new Float32Array(n);
    return {max,cnt:0,pos,col,siz,geo,mat,vx:f(max),vy:f(max),vz:f(max),life:f(max),ml:f(max),s0:f(max),s1:f(max),c0:f(max*3),c1:f(max*3),al:f(max),gr:f(max),dr:f(max)};
  }
  const NORM=mkSys(3800,false), ADD=mkSys(3200,true);
  function E(S,x,y,z,vx,vy,vz,life,s0,s1,c0,c1,a,gr,dr){
    if(S.cnt>=S.max) return; if(Game.fxK<1&&Math.random()>Game.fxK) return; const i=S.cnt++, i3=i*3;
    S.pos[i3]=x;S.pos[i3+1]=y;S.pos[i3+2]=z; S.vx[i]=vx;S.vy[i]=vy;S.vz[i]=vz; S.life[i]=S.ml[i]=life; S.s0[i]=s0;S.s1[i]=s1;
    S.c0[i3]=c0[0];S.c0[i3+1]=c0[1];S.c0[i3+2]=c0[2]; S.c1[i3]=c1[0];S.c1[i3+1]=c1[1];S.c1[i3+2]=c1[2]; S.al[i]=a; S.gr[i]=gr||0; S.dr[i]=dr==null?1:dr; }
  function step(S,dt){
    for(let i=0;i<S.cnt;){ S.life[i]-=dt;
      if(S.life[i]<=0){ const l=--S.cnt; if(i!==l){ const i3=i*3,l3=l*3; S.pos[i3]=S.pos[l3];S.pos[i3+1]=S.pos[l3+1];S.pos[i3+2]=S.pos[l3+2];
        S.vx[i]=S.vx[l];S.vy[i]=S.vy[l];S.vz[i]=S.vz[l];S.life[i]=S.life[l];S.ml[i]=S.ml[l];S.s0[i]=S.s0[l];S.s1[i]=S.s1[l];S.al[i]=S.al[l];S.gr[i]=S.gr[l];S.dr[i]=S.dr[l];
        for(let k=0;k<3;k++){ S.c0[i3+k]=S.c0[l3+k]; S.c1[i3+k]=S.c1[l3+k]; } } continue; }
      const i3=i*3, k=1-S.life[i]/S.ml[i], dm=Math.pow(S.dr[i],dt*60); S.vy[i]-=S.gr[i]*dt; S.vx[i]*=dm; S.vy[i]*=dm; S.vz[i]*=dm;
      S.pos[i3]+=S.vx[i]*dt; S.pos[i3+1]+=S.vy[i]*dt; S.pos[i3+2]+=S.vz[i]*dt;
      const fade=k<.12?k/.12:(1-k)/.88, i4=i*4;
      S.col[i4]=S.c0[i3]+(S.c1[i3]-S.c0[i3])*k; S.col[i4+1]=S.c0[i3+1]+(S.c1[i3+1]-S.c0[i3+1])*k; S.col[i4+2]=S.c0[i3+2]+(S.c1[i3+2]-S.c0[i3+2])*k; S.col[i4+3]=S.al[i]*fade;
      S.siz[i]=S.s0[i]+(S.s1[i]-S.s0[i])*k; i++; }
    S.geo.setDrawRange(0,S.cnt); S.geo.attributes.position.needsUpdate=S.geo.attributes.pc.needsUpdate=S.geo.attributes.psz.needsUpdate=true; }
  const R=(a,b)=>a+Math.random()*(b-a), rs=()=>Math.random()-.5, LIT=c=>{ const L=1-.62*(Game.night||0); return [c[0]*L,c[1]*L,c[2]*L]; };
  const api={
    update(dt){ const h=Game.three.renderer?Game.three.renderer.domElement.height:800, sc=h/(2*Math.tan(camera.fov*Math.PI/360));
      NORM.mat.uniforms.scale.value=ADD.mat.uniforms.scale.value=sc; step(NORM,dt); step(ADD,dt); },
    dust(x,y,z,n,sp,col){ const c=LIT(col||[.62,.58,.52]); for(let i=0;i<n;i++) E(NORM,x+rs()*sp,y+rs()*sp*.5,z+rs()*sp,rs()*sp*1.4,R(.5,sp*1.2),rs()*sp*1.4,R(1.2,2.6),R(.8,1.6),R(3,6),c,[.5,.48,.45],.5,-1,.92); },
    smoke(x,y,z,n,sz){ const a=LIT([.22,.22,.24]), b=LIT([.45,.45,.48]); for(let i=0;i<n;i++) E(NORM,x+rs()*1.5,y,z+rs()*1.5,rs()*1.2,R(2,4.5),rs()*1.2,R(2,4),R(.8,1.5)*(sz||1),R(4,8)*(sz||1),a,b,.6,-.4,.97); },
    cloud(x,y,z,n,spread,size,col){ const c=LIT(col||[.66,.62,.56]), c2=LIT([.5,.48,.45]); for(let i=0;i<n;i++) E(NORM,x+rs()*spread,y+R(0,spread*.35),z+rs()*spread,rs()*spread*.4,R(.7,3),rs()*spread*.4,R(2.6,5.2),size*R(.5,.9),size*R(2.2,3.6),c,c2,.34,-.12,.985); },
    ring(x,y,z,n,sp,size){ const c=LIT([.7,.66,.6]), c2=LIT([.5,.48,.45]); for(let i=0;i<n;i++){ const a=Math.random()*6.283; E(NORM,x,y,z,Math.cos(a)*sp*R(.8,1.15),R(.2,1),Math.sin(a)*sp*R(.8,1.15),R(1.2,2.4),size*R(.6,1),size*R(2.2,3.4),c,c2,.4,0,.94); } },
    fire(x,y,z,n,vx,vy,vz,sz){ for(let i=0;i<n;i++) E(ADD,x+rs()*.5,y,z+rs()*.5,(vx||0)+rs()*1.5,(vy||0)+R(1,3),(vz||0)+rs()*1.5,R(.35,.8),R(.7,1.3)*(sz||1),R(.1,.4),[1,.62,.15],[.9,.12,.02],.85,-1.5,.95); },
    spark(x,y,z,n,sp,c){ const cc=c||[1,.85,.4]; for(let i=0;i<n;i++) E(ADD,x,y,z,rs()*sp,R(0,sp*.8),rs()*sp,R(.25,.7),R(.25,.5),.05,cc,[1,.3,.05],1,14,.97); },
    ice(x,y,z,n,sp,vx,vy,vz){ for(let i=0;i<n;i++) E(ADD,x+rs()*.6,y+rs()*.6,z+rs()*.6,(vx||0)+rs()*sp,(vy||0)+rs()*sp,(vz||0)+rs()*sp,R(.5,1.2),R(.5,1.1),.1,[.8,.95,1],[.3,.7,1],.8,2,.96); },
    blood(x,y,z,n,sp,vx,vy,vz){ for(let i=0;i<n;i++) E(NORM,x,y,z,(vx||0)*.3+rs()*sp,(vy||0)*.3+R(0,sp),(vz||0)*.3+rs()*sp,R(.4,.9),R(.2,.4),.12,[.55,.02,.04],[.25,.0,.02],.95,22,.96); },
    splash(x,z,s){ s=s||1; const y=Game.WATER_Y+.1; for(let i=0;i<Math.round(14*s);i++){ const a=Math.random()*6.283, sp=R(1,5)*s; E(NORM,x,y,z,Math.cos(a)*sp,R(2,7)*s,Math.sin(a)*sp,R(.5,1.1),R(.3,.6)*s,R(.8,1.6)*s,[.85,.95,1],[.7,.85,1],.7,14,.97); }
      for(let i=0;i<Math.round(6*s);i++) E(ADD,x+rs()*s,y,z+rs()*s,rs()*2,R(.5,1.5),rs()*2,R(.4,.8),R(1,2)*s,R(3,5)*s,[.9,1,1],[.6,.8,1],.35,0,.94); },
    glow(x,y,z,size,c,life){ E(ADD,x,y,z,0,0,0,life||.12,size,size*.4,c,c,.9,0,1); },
    shock(x,y,z,n,sp){ for(let i=0;i<n;i++){ const a=Math.random()*6.283; E(ADD,x,y,z,Math.cos(a)*sp,rs()*2,Math.sin(a)*sp,R(.4,.8),R(1,2),R(4,6),[.8,.95,1],[.4,.7,1],.5,0,.95); } },
    E:(k,...a)=>E(k?ADD:NORM,...a), NORM, ADD,
    setMaxPt(v){ NORM.mat.uniforms.pmax.value=v; ADD.mat.uniforms.pmax.value=v; }
  };
  Game.splash=(x,z,s)=>{ api.splash(x,z,s); if(Game.audio&&Game.audio.splash) Game.audio.splash(x,Game.WATER_Y,z,s); };
  Game.updaters.push(dt=>api.update(dt));
  return api;
})();
