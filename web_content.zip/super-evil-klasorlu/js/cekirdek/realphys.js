"use strict";
/* ===== GERÇEKÇİ FİZİK YARDIMCISI: vurulan/fırlatılan NPC ve araba hızları + dönüş (tumble) =====
   Eski sürüm: yumruk 30-32 m/s, fırlatma 72 m/s, yer çekimi 26 ve her eksende rastgele hızlı dönüş -> "havada uçuyorlar".
   Yeni: hız kuvvet-sınıfına göre yumuşak sınırlanır (tanh), yukarı bileşen yatay hıza oranlıdır (gerçekte kimse roket gibi yükselmez),
   dönüş eksenı hız yönüne dik yatay eksendir (takla), yer çekimi 14 (physics.js) ve yerde Coulomb sürtünmesi (clampBody) ile cisimler gerçekte olduğu gibi yay çizip düşer, kayar, durur. */
Game.Real=(function(){
  const th=Math.tanh;
  /* [yatay azami m/s, yukarı oranı, yukarı sabit, yukarı azami] -- yatay hız tanh ile yumuşak sınırlanır (patlama gibi uç değerler de makul kalır) */
  const NPCK={punch:[15,.3,2,6.5],car:[24,.2,1.5,6],throw:[18,.3,2,8],boom:[22,.3,2,8],clap:[18,.28,2,7],gravity:[16,.3,2,8],laser:[5,.2,1,3],soul:[3,0,0,4],fall:[30,.2,2,10]};
  const CARK={def:[11,.3,1.5,5.5],throw:[26,.4,2.5,10],boom:[22,.3,2,8],crash:[22,.1,.8,3]};
  function shape(L,vx,vy,vz){ const H=Math.hypot(vx,vz); let k=1; if(H>.001){ k=L[0]*th(H/L[0])/H; vx*=k; vz*=k; } const Hn=H*k; const up=Math.min(L[3],L[1]*Hn+L[2]); if(vy>up) vy=up; else if(vy<-30) vy=-30; return [vx,vy,vz,Hn]; }
  const api={
    npc(kind,vx,vy,vz){ return shape(NPCK[kind]||[18,.25,1.5,6],vx,vy,vz); },
    car(mode,vx,vy,vz){ return shape(CARK[mode]||CARK.def,vx,vy,vz); },
    /* takla: hız yönüne dik yatay eksen etrafında (baş geride kalacak şekilde ağırlıkla) dönüş + hafif sapma. mag rad/s */
    tumble(b,vx,vz,mag,yawJ){ const H=Math.hypot(vx,vz), s=Math.random()<.7?1:-1, j=yawJ===undefined?1:yawJ; if(H<.5){ b.angularVelocity.set((Math.random()-.5)*mag,(Math.random()-.5)*j,(Math.random()-.5)*mag); return; }
      const ax=-vz/H, az=vx/H; b.angularVelocity.set(ax*mag*s+(Math.random()-.5)*.4,(Math.random()-.5)*j*2,az*mag*s+(Math.random()-.5)*.4); }
  };
  return api;
})();
