"use strict";
/* ===== YAPILANDIRMA: yayın öncesi doldurulacak tek yer ===== */
Game.CONFIG={
  version:"1.0.0",
  /* AdMob: gerçek reklam yalnızca Android uygulamasında (Capacitor + @capacitor-community/admob) çalışır; tarayıcıda "TEST REKLAM" simülasyonu gösterilir */
  ads:{ appId:"ca-app-pub-1648586598987752~6369370670", rewarded:"ca-app-pub-1648586598987752/8828013055",
    testRewarded:"ca-app-pub-3940256099942544/5224354917",   /* Google'ın herkese açık test birimi: geliştirirken useTest:true yapın (kendi reklamınıza tıklamak hesabı askıya aldırabilir) */
    useTest:false,      /* false = GERÇEK reklam birimi (yayın). true yalnızca denemede */
    webSim:true,        /* tarayıcıda (gerçek reklam olamaz) "TEST REKLAM" simülasyonu; Android uygulamasında hiçbir zaman kullanılmaz */
    simSeconds:5 },
  /* Google ile giriş + bulut kayıt (Firebase proje: superevil-d3dc3). Bu web yapılandırması herkese açık olacak şekilde tasarlanmıştır (gizli anahtar değildir);
     güvenlik Firestore kuralları + Authentication ile sağlanır. Analytics bilerek eklenmedi (gerek yok; gizlilik/Veri güvenliği yükümlülüğü getirir). */
  google:{ clientId:"", firebase:{ apiKey:"AIzaSyCoZ8FULqEOEV3YxrsRQfL_VTC4lhPasbA", authDomain:"superevil-d3dc3.firebaseapp.com", projectId:"superevil-d3dc3",
    storageBucket:"superevil-d3dc3.firebasestorage.app", messagingSenderId:"97436440146", appId:"1:97436440146:web:06a5a467575b7c511b318b" } },
  privacyUrl:"", supportMail:""
};
