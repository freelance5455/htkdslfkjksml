"use strict";
/* ===== ORTAK YARDIMCILAR ===== */
Game.U = {
  /* arr: InstancedMesh matris dizisi, i: örnek no, P: kök konum, q: kök dönüş (x,y,z,w), pivot: yerel pivot, drop: pivottan aşağı yarım uzunluk, ax: pivotta X dönüşü, s: ölçek */
  writeMat(arr,i,px,py,pz,q,lx,ly,lz,drop,ax,sx,sy,sz){
    const x=q.x,y=q.y,z=q.z,w=q.w, xx=x*x,yy=y*y,zz=z*z, c0x=1-2*(yy+zz),c0y=2*(x*y+z*w),c0z=2*(x*z-y*w), c1x=2*(x*y-z*w),c1y=1-2*(xx+zz),c1z=2*(y*z+x*w), c2x=2*(x*z+y*w),c2y=2*(y*z-x*w),c2z=1-2*(xx+yy);
    const ca=Math.cos(ax),sa=Math.sin(ax), vy=ly-drop*ca, vz=lz-drop*sa, o=i*16;
    arr[o]=c0x*sx;arr[o+1]=c0y*sx;arr[o+2]=c0z*sx;arr[o+3]=0;
    arr[o+4]=(ca*c1x+sa*c2x)*sy;arr[o+5]=(ca*c1y+sa*c2y)*sy;arr[o+6]=(ca*c1z+sa*c2z)*sy;arr[o+7]=0;
    arr[o+8]=(-sa*c1x+ca*c2x)*sz;arr[o+9]=(-sa*c1y+ca*c2y)*sz;arr[o+10]=(-sa*c1z+ca*c2z)*sz;arr[o+11]=0;
    arr[o+12]=px+c0x*lx+c1x*vy+c2x*vz;arr[o+13]=py+c0y*lx+c1y*vy+c2y*vz;arr[o+14]=pz+c0z*lx+c1z*vy+c2z*vz;arr[o+15]=1; },
  hide(arr,i){ arr.fill(0,i*16,i*16+16); arr[i*16+15]=1; },
  yawQ(a,out){ out.x=0;out.y=Math.sin(a/2);out.z=0;out.w=Math.cos(a/2); return out; },
  rs:()=>Math.random()-.5
};
