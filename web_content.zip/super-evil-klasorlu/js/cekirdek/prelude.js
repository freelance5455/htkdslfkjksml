"use strict";
/* ===== ÖN HAZIRLIK: kısayollar, giriş durumu, güç ayarları ===== */
const $ = id => document.getElementById(id);
const POWER_IDS = ["fly","punch","choke","clap","laser","freeze","fire","meteor","lightning","gravity","timeslow","quake"];
Game.input = {actions:{fly:false,punch:false,choke:false,clap:false,laser:false,freeze:false,fire:false,meteor:false,lightning:false,gravity:false,timeslow:false,quake:false}};
Game.powersPref = {}; POWER_IDS.forEach(p=>Game.powersPref[p]=true);
try{ const sv=JSON.parse(store.get("powers","{}")); for(const k in sv) if(k in Game.powersPref) Game.powersPref[k]=!!sv[k]; Game.powersPref.fly=true; }catch(e){}
/* powersOn[p] = kullanıcı tercihi VE güç sahipliği (Game.Eco: ücretsiz / satın alınmış / deneme) */
Game.powersOn = {}; POWER_IDS.forEach(p=>Object.defineProperty(Game.powersOn,p,{enumerable:true,get(){ return Game.powersPref[p]!==false&&(!Game.Eco||Game.Eco.hasPower(p)); },set(v){ Game.powersPref[p]=!!v; }}));
const reported = {};
function reportErr(e){ let m; try{ const st=(e&&e.stack)?String(e.stack).split("\n").filter(Boolean):[]; m=((e&&e.name)?e.name+": ":"")+((e&&e.message)?e.message:(st.length?"":String(e)))+" @ "+st.slice(0,9).map(x=>x.replace(/https?:\/\/[^\s)]*\//g,"").replace(/^(.{0,70}).*$/,"$1")).join(" | "); }catch(_){ m=String(e); } if(reported[m]) return; reported[m]=1; try{ console.error(e); const b=$("errBox"); b.style.display="block"; b.textContent+=m+"\n"; }catch(_){} }
