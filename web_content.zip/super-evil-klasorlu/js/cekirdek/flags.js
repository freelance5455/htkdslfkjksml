"use strict";
/* ===== BAYRAKLAR: emoji'ye bağlı kalmadan her cihazda aynı görünen satır içi SVG bayraklar ===== */
Game.Flags=(function(){
  const star=(cx,cy,R,r,rot,fill)=>{ let d=""; for(let i=0;i<10;i++){ const a=rot+i*Math.PI/5-Math.PI/2, rr=i%2?r:R; d+=(i?"L":"M")+(cx+Math.cos(a)*rr).toFixed(2)+" "+(cy+Math.sin(a)*rr).toFixed(2); } return '<path d="'+d+'Z" fill="'+fill+'"/>'; };
  const bars=(x,y,rot)=>'<g transform="translate('+x+' '+y+') rotate('+rot+')" fill="#111"><rect x="-6" y="-4" width="12" height="2.2"/><rect x="-6" y="-1.1" width="12" height="2.2"/><rect x="-6" y="1.8" width="12" height="2.2"/></g>';
  const bars2=(x,y,rot)=>'<g transform="translate('+x+' '+y+') rotate('+rot+')" fill="#111"><rect x="-6" y="-4" width="5.2" height="2.2"/><rect x="0.8" y="-4" width="5.2" height="2.2"/><rect x="-6" y="-1.1" width="12" height="2.2"/><rect x="-6" y="1.8" width="5.2" height="2.2"/><rect x="0.8" y="1.8" width="5.2" height="2.2"/></g>';
  let spokes=""; for(let i=0;i<24;i++){ const a=i*Math.PI/12; spokes+='<line x1="30" y1="20" x2="'+(30+Math.cos(a)*5.2).toFixed(2)+'" y2="'+(20+Math.sin(a)*5.2).toFixed(2)+'"/>'; }
  let usStripes=""; for(let i=0;i<13;i+=2) usStripes+='<rect y="'+(i*40/13).toFixed(3)+'" width="60" height="'+(40/13+.04).toFixed(3)+'" fill="#B22234"/>';
  let usStars=""; for(let r=0;r<9;r++){ const n=r%2?5:6; for(let c=0;c<n;c++) usStars+=star(r%2?2.0+c*4+2.0:2.0+c*4,1.55+r*1.9,1.15,.46,0,"#fff"); }
  const US='<rect width="60" height="40" fill="#fff"/>'+usStripes+'<rect width="24" height="'+(7*40/13).toFixed(3)+'" fill="#3C3B6E"/>'+usStars;
  const F={
    tr:'<rect width="60" height="40" fill="#E30A17"/><circle cx="22" cy="20" r="10" fill="#fff"/><circle cx="25" cy="20" r="8" fill="#E30A17"/>'+star(33.5,20,5.2,2.1,Math.PI/10,"#fff"),
    en:'<rect width="60" height="40" fill="#012169"/><path d="M0 0L60 40M60 0L0 40" stroke="#fff" stroke-width="7"/><path d="M0 0L60 40M60 0L0 40" stroke="#C8102E" stroke-width="2.4"/><path d="M30 0V40M0 20H60" stroke="#fff" stroke-width="11"/><path d="M30 0V40M0 20H60" stroke="#C8102E" stroke-width="6.4"/>',
    de:'<rect width="60" height="13.4" fill="#111"/><rect y="13.3" width="60" height="13.4" fill="#DD0000"/><rect y="26.6" width="60" height="13.4" fill="#FFCE00"/>',
    ar:'<rect width="60" height="40" fill="#006C35"/><g fill="none" stroke="#fff" stroke-linecap="round" stroke-width="2.1"><path d="M14 13q3-4 6 0t6 0t6 0t6 0t6 0t6 0"/><path d="M17 19q2-3 4 0t4 0t4 0t4 0t4 0t4 0t4 0"/></g><path d="M13 29.5H47" stroke="#fff" stroke-width="2"/><path d="M13 29.5 10 28.2V30.8Z" fill="#fff"/><path d="M42 27.2v4.6" stroke="#fff" stroke-width="1.6"/>',
    fr:'<rect width="20.2" height="40" fill="#0055A4"/><rect x="20" width="20.2" height="40" fill="#fff"/><rect x="40" width="20" height="40" fill="#EF4135"/>',
    ko:'<rect width="60" height="40" fill="#fff"/><path d="M21 20a9 9 0 0 1 18 0z" fill="#CD2E3A"/><path d="M39 20a9 9 0 0 1-18 0z" fill="#0047A0"/><circle cx="25.5" cy="20" r="4.5" fill="#CD2E3A"/><circle cx="34.5" cy="20" r="4.5" fill="#0047A0"/>'+bars(11,9,-34)+bars2(49,9,34)+bars2(11,31,34)+bars(49,31,-34),
    ja:'<rect width="60" height="40" fill="#fff"/><circle cx="30" cy="20" r="11" fill="#BC002D"/>',
    ru:'<rect width="60" height="13.4" fill="#fff"/><rect y="13.3" width="60" height="13.4" fill="#0039A6"/><rect y="26.6" width="60" height="13.4" fill="#D52B1E"/>',
    es:'<rect width="60" height="40" fill="#AA151B"/><rect y="10" width="60" height="20" fill="#F1BF00"/><g transform="translate(15 20)"><rect x="-3.2" y="-4.6" width="6.4" height="8" rx="1.2" fill="#AA151B" stroke="#8a6a00" stroke-width=".6"/><rect x="-1.4" y="-3" width="2.8" height="5" fill="#F1BF00" opacity=".9"/><rect x="-4.4" y="-4.8" width="1.2" height="9" fill="#8a6a00" opacity=".7"/><rect x="3.2" y="-4.8" width="1.2" height="9" fill="#8a6a00" opacity=".7"/></g>',
    zh:'<rect width="60" height="40" fill="#DE2910"/>'+star(11,10,6.6,2.6,0,"#FFDE00")+star(22,4.6,2.2,.9,.5,"#FFDE00")+star(26,9.4,2.2,.9,.9,"#FFDE00")+star(26,15.6,2.2,.9,.2,"#FFDE00")+star(22,20.4,2.2,.9,.7,"#FFDE00"),
    pt:'<rect width="60" height="40" fill="#009C3B"/><path d="M30 3.5 56.5 20 30 36.5 3.5 20Z" fill="#FFDF00"/><circle cx="30" cy="20" r="9.6" fill="#002776"/><path d="M20.8 17.6q9.6-3.2 18.6 3.4" stroke="#fff" stroke-width="1.7" fill="none"/>',
    it:'<rect width="20.2" height="40" fill="#009246"/><rect x="20" width="20.2" height="40" fill="#fff"/><rect x="40" width="20" height="40" fill="#CE2B37"/>',
    hi:'<rect width="60" height="13.4" fill="#FF9933"/><rect y="13.3" width="60" height="13.4" fill="#fff"/><rect y="26.6" width="60" height="13.4" fill="#138808"/><circle cx="30" cy="20" r="5.6" fill="none" stroke="#000080" stroke-width=".9"/><g stroke="#000080" stroke-width=".35">'+spokes+'</g>'
  };
  const MOONF={en:US};   /* Ay bayrağı: İngilizce = ABD bayrağı (dil çipinde İngiltere kalır) */
  function moonSvg(code){ const body=MOONF[code]||F[code]||'<rect width="60" height="40" fill="#888"/>'; return '<svg xmlns="http://www.w3.org/2000/svg" width="360" height="240" viewBox="0 0 60 40" preserveAspectRatio="none">'+body+'</svg>'; }
  const cache={};
  function svg(code,cls){ const body=F[code]||'<rect width="60" height="40" fill="#555"/>'; return '<svg class="'+(cls||"flag")+'" viewBox="0 0 60 40" preserveAspectRatio="none" aria-hidden="true">'+body+'</svg>'; }
  return {svg,moonSvg,codes:Object.keys(F),ORDER:["tr","en","es","pt","fr","de","it","ru","ar","hi","zh","ko","ja"],has:c=>!!F[c]};
})();
