"use strict";
"use strict";
/* ================= DİL SİSTEMİ ================= */
const LANGS = {
  tr:{name:"Türkçe",title:"SÜPER KAHRAMAN",subtitle:"Şehir senin elinde",play:"Oyna",shop:"Mağaza",settings:"Ayarlar",back:"Geri",language:"Dil",graphics:"Grafik",low:"Düşük",medium:"Orta",high:"Yüksek",skin:"Kahraman rengi",loading:"Yükleniyor…"},
  en:{name:"English",title:"SUPER HERO",subtitle:"The city is yours",play:"Play",shop:"Shop",settings:"Settings",back:"Back",language:"Language",graphics:"Graphics",low:"Low",medium:"Medium",high:"High",skin:"Hero color",loading:"Loading…"},
  de:{name:"Deutsch",title:"SUPERHELD",subtitle:"Die Stadt gehört dir",play:"Spielen",shop:"Shop",settings:"Einstellungen",back:"Zurück",language:"Sprache",graphics:"Grafik",low:"Niedrig",medium:"Mittel",high:"Hoch",skin:"Heldenfarbe",loading:"Lädt…"},
  ar:{name:"العربية",title:"البطل الخارق",subtitle:"المدينة بين يديك",play:"العب",shop:"المتجر",settings:"الإعدادات",back:"رجوع",language:"اللغة",graphics:"الرسومات",low:"منخفض",medium:"متوسط",high:"عالٍ",skin:"لون البطل",loading:"جارٍ التحميل…"},
  fr:{name:"Français",title:"SUPER-HÉROS",subtitle:"La ville est à toi",play:"Jouer",shop:"Boutique",settings:"Paramètres",back:"Retour",language:"Langue",graphics:"Graphismes",low:"Bas",medium:"Moyen",high:"Élevé",skin:"Couleur du héros",loading:"Chargement…"},
  ko:{name:"한국어",title:"슈퍼 히어로",subtitle:"도시는 당신의 것",play:"플레이",shop:"상점",settings:"설정",back:"뒤로",language:"언어",graphics:"그래픽",low:"낮음",medium:"보통",high:"높음",skin:"영웅 색상",loading:"로딩 중…"},
  ja:{name:"日本語",title:"スーパーヒーロー",subtitle:"街はあなたのもの",play:"プレイ",shop:"ショップ",settings:"設定",back:"戻る",language:"言語",graphics:"グラフィック",low:"低",medium:"中",high:"高",skin:"ヒーローの色",loading:"読み込み中…"}
};
const store = {
  get(k,d){ try{ const v=localStorage.getItem("sk_"+k); return v===null?d:v; }catch(e){ return d; } },
  set(k,v){ try{ localStorage.setItem("sk_"+k,v); }catch(e){} }
};
/* ================= CİHAZ SEVİYESİ (Nokia/Android Go sınıfından iPad Pro'ya kadar) =================
   tier 0 = düşük (zayıf/eski cihaz: gölgesiz, yarı çözünürlüklü doku, az NPC/araba, 30 FPS sınırı, daha düşük çözünürlük), tier 1 = normal.
   Yalnızca varsayılanları seçer; oyuncunun kendi Grafik/Optimize seçimi her zaman önceliklidir. Test için: localStorage sk_tier = "low" | "mid". */
const DEVICE=(function(){
  const nav=(typeof navigator!=="undefined"&&navigator)||{}, ua=String(nav.userAgent||""), D={tier:1,reasons:[],gpu:"",info:{},glOk:true};
  const LOWGPU=/Mali-4\d\d|Mali-T[0-7]\d\d|Mali-G(31|51)\b|Adreno \(?TM\)? ?[2-4]\d\d\b|Adreno \(?TM\)? ?50\d\b|PowerVR (SGX|GE8[0-3]\d\d|Rogue G6)|\bSGX\b|VideoCore|Vivante|\bGC\d{3,4}\b|llvmpipe|SwiftShader|Software|Basic Render/i;
  /* saf sınıflandırma (test edilebilir): info = {ua, mem(GB), cores, gpu, maxTex, ios, android} */
  D.classify=function(i){ const r=[]; const android=i.android!==undefined?i.android:/Android/i.test(i.ua||""), ios=i.ios!==undefined?i.ios:/iPhone|iPad|iPod/i.test(i.ua||"");
    const av=+((i.ua||"").match(/Android (\d+)/)||[])[1]||0, ch=+((i.ua||"").match(/Chrome\/(\d+)/)||[])[1]||0;
    if(i.mem&&i.mem<=2) r.push("RAM≤2GB"); if(android&&i.cores&&i.cores<=4) r.push("≤4 çekirdek"); if(android&&av&&av<=8) r.push("Android "+av);
    if(android&&ch&&ch<84) r.push("eski WebView "+ch); if(i.gpu&&LOWGPU.test(i.gpu)) r.push("zayıf GPU "+i.gpu); if(i.maxTex&&i.maxTex<4096) r.push("küçük doku sınırı "+i.maxTex);
    if(ios&&i.cores&&i.cores<=2) r.push("eski iPhone/iPad (2 çekirdek)");
    return {tier:r.length?0:1,reasons:r}; };
  try{
    const forced=store.get("tier","");   // "low" | "mid"
    const info={ua,mem:+nav.deviceMemory||0,cores:+nav.hardwareConcurrency||0,gpu:"",maxTex:0,dpr:+(typeof devicePixelRatio!=="undefined"?devicePixelRatio:1)||1};
    try{ const c=document.createElement("canvas"), gl=c.getContext&&(c.getContext("webgl")||c.getContext("experimental-webgl")); if(gl&&gl.getParameter){ const x=gl.getExtension&&gl.getExtension("WEBGL_debug_renderer_info"); if(x) info.gpu=String(gl.getParameter(x.UNMASKED_RENDERER_WEBGL)||""); info.maxTex=+gl.getParameter(gl.MAX_TEXTURE_SIZE)||0; const lc=gl.getExtension&&gl.getExtension("WEBGL_lose_context"); if(lc&&lc.loseContext) lc.loseContext(); } else if(gl===null) D.glOk=false; }catch(e){}
    D.info=info; D.gpu=info.gpu; const r=D.classify(info); D.tier=r.tier; D.reasons=r.reasons;
    if(forced==="low"){ D.tier=0; D.reasons.push("elle: düşük"); } else if(forced==="mid"){ D.tier=1; D.reasons=["elle: normal"]; }
  }catch(e){}
  D.low=D.tier===0; D.defQuality=D.low?"low":"medium"; D.defNpc=D.low?"low":"mid";
  return D; })();

let currentLang = store.get("lang", (navigator.language||"tr").slice(0,2));
if(!LANGS[currentLang]) currentLang = "tr";

function t(key){ return (LANGS[currentLang] && LANGS[currentLang][key]) || LANGS.en[key] || key; }
function setLang(code){               // sayfa yenilenmeden tüm UI güncellenir
  if(!LANGS[code]) return;
  currentLang = code; store.set("lang", code);
  document.documentElement.lang = code;
  document.documentElement.dir = code==="ar" ? "rtl" : "ltr";
  document.querySelectorAll("[data-i18n]").forEach(el=>{ el.textContent = t(el.dataset.i18n); });
  document.getElementById("langSel").value = code;
  if(Game.onLang) Game.onLang();
}

/* ================= OYUN DURUMU ================= */
const SKINS = ["#e63946","#1d6fe0","#2ecc71","#f1c40f","#9b59b6","#ff7a29","#16d9d9","#222222"];
const Game = {
  mode:"menu",                        // menu | play | pause
  quality:(()=>{ const q=store.get("quality",DEVICE.defQuality); return ["low","medium","high","ultra"].includes(q)?q:DEVICE.defQuality; })(),
  Device:DEVICE,
  skinColor:store.get("skin",SKINS[0]),
  buildings:[],                       // çarpışma kutuları {x,z,hw,hd,h}
  settings:{censor:store.get("censor","1")!=="0",cam:store.get("cam","3p")==="1p"?"1p":"3p",map:store.get("map","metro"),   // +18 sansür (açık=kan/parçalama yok), kamera, harita
    sens:Math.max(.4,Math.min(2.2,parseFloat(store.get("sens","1"))||1)), vol:Math.max(0,Math.min(1,isNaN(parseFloat(store.get("vol","0.55")))?.55:parseFloat(store.get("vol","0.55")))),
    npcd:["low","mid","high"].includes(store.get("npcd",DEVICE.defNpc))?store.get("npcd",DEVICE.defNpc):DEVICE.defNpc, minimap:store.get("minimap","1")!=="0", fps:store.get("fps","0")==="1", vib:store.get("vib","1")!=="0",
    season:["spring","summer","autumn","winter"].includes(store.get("season","summer"))?store.get("season","summer"):"summer",
    /* v9 özelleştirme + polis */
    police:store.get("police","1")!=="0", hs:Math.max(.8,Math.min(1.2,parseFloat(store.get("cu_hs","1"))||1)), ho:Math.max(.35,Math.min(1,parseFloat(store.get("cu_ho","1"))||1)), subs:store.get("cu_subs","1")!=="0", subSz:["s","m","l"].includes(store.get("cu_subsz","m"))?store.get("cu_subsz","m"):"m",
    shake:Math.max(0,Math.min(1,isNaN(parseFloat(store.get("cu_shake","1")))?1:parseFloat(store.get("cu_shake","1")))), fovAdd:Math.max(-10,Math.min(24,isNaN(parseFloat(store.get("cu_fov","0")))?0:parseFloat(store.get("cu_fov","0")))), cross:store.get("cu_cross","1")!=="0", coinPops:store.get("cu_coinpop","1")!=="0", mph:store.get("cu_mph","0")==="1",
    gyro:store.get("cu_gyro","0")==="1", gyroS:Math.max(.4,Math.min(3,parseFloat(store.get("cu_gyros","1"))||1))},
  updaters:[],                        // Bölüm 2: Game.updaters.push((dt,time)=>{...})
  three:{}                            // scene, camera, renderer, lights...
};

/* ================= THREE.JS TEMEL SAHNE ================= */
const container = document.getElementById("game");
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x000000);          // gökyüzü kubbesi (sky.js) çizer; uzayda siyah
scene.fog = new THREE.FogExp2(0x87b8ee, 0.0022);

const camera = new THREE.PerspectiveCamera(70, innerWidth/innerHeight, 0.1, 6000);
camera.position.set(120, 70, 120);

const hemi = new THREE.HemisphereLight(0xcfe6ff, 0x3a3a46, 0.75);
scene.add(hemi);
const sun = new THREE.DirectionalLight(0xfff1d6, 1.15);
sun.position.set(150, 220, 80);
sun.castShadow = true;
sun.shadow.camera.left = sun.shadow.camera.bottom = -260;
sun.shadow.camera.right = sun.shadow.camera.top = 260;
sun.shadow.camera.near = 10; sun.shadow.camera.far = 700;
sun.shadow.bias = -0.0004;
scene.add(sun); scene.add(sun.target);
sun.shadow.camera.left=sun.shadow.camera.bottom=-210; sun.shadow.camera.right=sun.shadow.camera.top=210; sun.shadow.camera.updateProjectionMatrix(); sun.shadow.normalBias=.35;

let renderer = null;
Game.ultra = false;
const QUALITY = {                                      // grafik ön ayarları
  low:   {shadow:false, ratio:1,   shadowMap:512,  aa:false, bloom:false},
  medium:{shadow:true,  ratio:1.5, shadowMap:1024, aa:false, bloom:false},
  high:  {shadow:true,  ratio:2,   shadowMap:2048, aa:true,  bloom:true},
  ultra: {shadow:true,  ratio:2,   shadowMap:4096, aa:true,  bloom:true, ultra:true}   // sinematik: bulutlar, ışık huzmeleri, lens, film efekti, tane
};
/* WebGL bağlamı oluştur; olmazsa daha basit ayarlarla yeniden dene; hiç olmazsa anlaşılır bir mesaj göster (siyah ekran yerine) */
Game.glFail=function(e){ try{ let d=document.getElementById("glFail"); if(!d){ d=document.createElement("div"); d.id="glFail"; d.style.cssText="position:fixed;left:0;top:0;right:0;bottom:0;z-index:99999;background:#0a0a10;color:#fff;display:flex;align-items:center;justify-content:center;text-align:center;padding:24px;font:16px/1.5 system-ui,sans-serif"; document.body.appendChild(d); } d.textContent=t("gl_fail"); }catch(_){} };
function makeGL(aa){ let last=null; for(const o of [{antialias:!!aa,powerPreference:"high-performance"},{antialias:false},{antialias:false,powerPreference:"default",failIfMajorPerformanceCaveat:false}]){ try{ return new THREE.WebGLRenderer(o); }catch(e){ last=e; } } Game.glFail(last); throw last||new Error("WebGL"); }
function buildRenderer(){
  // Anti-aliasing bağlam oluşturulurken seçilir; kalite değişince renderer yeniden kurulur.
  const q = QUALITY[Game.quality];
  if(renderer){ renderer.dispose(); renderer.domElement.remove(); }
  renderer = makeGL(q.aa&&!DEVICE.low);
  Game.curRatio=0; renderer.setPixelRatio(Math.min(devicePixelRatio, q.ratio));
  if(renderer.domElement.addEventListener){   /* WebGL bağlamı kaybolursa (bellek baskısı/arka plan): three.js kendisi yeniden kurar; biz kullanıcıya haber verip malzemeleri tazeleriz */
    renderer.domElement.addEventListener("webglcontextlost",e=>{ try{ e.preventDefault(); }catch(_){} Game.glLost=true; try{ if(Game.toast) Game.toast("gl_lost",5000); }catch(_){} },false);
    renderer.domElement.addEventListener("webglcontextrestored",()=>{ Game.glLost=false; try{ scene.traverse(o=>{ const m=o.material; if(m) (Array.isArray(m)?m:[m]).forEach(x=>{ if(x) x.needsUpdate=true; }); }); if(Game.setupPost) Game.setupPost(); if(Game.toast) Game.toast("gl_back",2500); }catch(_){} },false); }
  renderer.setSize(innerWidth, innerHeight);
  renderer.outputEncoding = THREE.sRGBEncoding;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = .85;
  renderer.shadowMap.enabled = q.shadow;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  sun.castShadow = q.shadow;
  sun.shadow.mapSize.set(q.shadowMap, q.shadowMap);
  if(sun.shadow.map){ sun.shadow.map.dispose(); sun.shadow.map = null; }
  container.appendChild(renderer.domElement);
  Game.three.renderer = renderer;
  Game.bloom = q.bloom; Game.ultra = !!q.ultra;
  if(Game.reapplyTod) Game.reapplyTod();               // Ultra: sis/pozlama/bulut yeniden hesaplanır
  if(Game.makeEnv) Game.makeEnv();
  if(Game.setupPost) Game.setupPost();               // Bölüm 2: true ise EffectComposer + UnrealBloomPass kullan
  scene.traverse(o=>{ if(o.material) o.material.needsUpdate = true; });
}
function setQuality(level){
  if(!QUALITY[level]) return;
  Game.quality = level; store.set("quality", level); if(Game.onQuality) Game.onQuality();
  document.querySelectorAll("#qualRow .btn").forEach(b=>b.classList.toggle("sel", b.dataset.q===level));
  buildRenderer(); if(Game.Opt) Game.Opt.apply(true);
}

