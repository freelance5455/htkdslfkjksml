"use strict";
/* ===== ANA DÖNGÜ VE BAŞLATMA ===== */
const clock=new THREE.Clock(); let orbit=0, menuFrames=0, prevMode="menu";
function onResize(){ camera.aspect=innerWidth/innerHeight; camera.updateProjectionMatrix(); if(renderer) renderer.setSize(innerWidth,innerHeight); if(Game.post) Game.post.setSize(innerWidth,innerHeight); if(Game.menu3d&&Game.menu3d.resize) Game.menu3d.resize(); }
addEventListener("resize",onResize); addEventListener("orientationchange",()=>setTimeout(onResize,250));
/* dinamik çözünürlük + kademeli sadeleştirme artık Game.Opt (optimize.js) içinde */
Game.baseRatio=()=>Math.min(devicePixelRatio,QUALITY[Game.quality].ratio);
Game.curRatio=0;
Game.setRatio=function(r){ if(!renderer) return; Game.curRatio=r; renderer.setPixelRatio(r); if(Game.post&&Game.post.setPixelRatio) Game.post.setPixelRatio(r); onResize(); };
Game.perf={get stage(){ return Game.Opt?Game.Opt.stage:0; }, get floor(){ return .65; }};
/* menü sahnesini çiz (ayrı sahne; bloom varsa göz parlaması için eşik düşürülür, sinema geçişi yumuşatılır) */
function renderMenu(time){ const M=Game.menu3d, P=Game.post;
  if(P&&P.passes&&P.passes[0]){ const rp=P.passes[0], bp=P.passes[1], cp=Game.cine;
    rp.scene=M.scene; rp.camera=M.cam;
    if(bp&&bp.threshold!==undefined){ if(bp.__t0===undefined){ bp.__t0=bp.threshold; bp.__s0=bp.strength; bp.__r0=bp.radius; } bp.threshold=.5; bp.strength=Math.max(bp.__s0,1.05); bp.radius=.9; }
    if(cp){ const u=cp.uniforms; u.rays.value=0; u.flare.value=0; u.grade.value=.25; u.time.value=time%1000; const r=Game.three.renderer; u.res.value.set(r.domElement.width,r.domElement.height); u.aspect.value=innerWidth/innerHeight; }
    P.render();
    rp.scene=scene; rp.camera=camera; if(bp&&bp.__t0!==undefined){ bp.threshold=bp.__t0; bp.strength=bp.__s0; bp.radius=bp.__r0; } if(cp) cp.uniforms.grade.value=1; }
  else renderer.render(M.scene,M.cam); }
function loop(){
  requestAnimationFrame(loop); if(Game.Opt&&Game.Opt.skip()) return; Game.frameN=(Game.frameN||0)+1;
  const raw=Math.min(clock.getDelta(),.05), time=clock.elapsedTime, dt=raw*(Game.ts===undefined?1:Game.ts);
  const M=Game.menu3d, menuScene=Game.mode==="menu"&&!!M;
  if(Game.mode==="menu"){ if(prevMode!=="menu"){ menuFrames=4; } if(!M){ orbit+=raw*.06; camera.position.set(Math.cos(orbit)*430,150+Math.sin(orbit*1.7)*18,Math.sin(orbit)*430); camera.lookAt(0,18,0); camera.near=.5; camera.far=6000; camera.fov=58; camera.updateProjectionMatrix(); } }
  prevMode=Game.mode;
  const light=menuScene&&menuFrames>=4; if(menuScene&&menuFrames<4) menuFrames++;
  for(const fn of Game.updaters){ if(light&&!fn.__menu) continue; try{ fn(dt,time,raw); }catch(e){ reportErr(e); } }
  if(Game.Opt) Game.Opt.preRender();
  try{ if(menuScene) renderMenu(time); else if(Game.post) Game.post.render(); else renderer.render(scene,camera); }catch(e){ reportErr(e); if(Game.healInstances){ Game.healInstances(scene); if(Game.menu3d&&Game.menu3d.scene) Game.healInstances(Game.menu3d.scene); } }
}
document.addEventListener("visibilitychange",()=>{ if(document.hidden&&Game.mode==="play"){ enterMode("pause"); } });
Object.assign(Game.three,{scene,camera,sun,hemi});
if(Game.setHour) Game.setHour(Game.tod.mode==="auto"?"auto":Game.tod.hour); setLang(currentLang); setQuality(Game.quality); applyPowers(); onResize(); loop();
setTimeout(()=>{ if(window.__splash) window.__splash.ready(); },700);
