"use strict";
/* ===== OLAY YOLU: modüller birbirini tanımadan haberleşir (coin, hikaye, polis, konuşma) ===== */
Game.Ev=(function(){ const L={}; const api={
  on(n,f){ (L[n]||(L[n]=[])).push(f); return f; },
  off(n,f){ const a=L[n]; if(!a) return; const i=a.indexOf(f); if(i>=0) a.splice(i,1); },
  emit(n,a,b,c){ const l=L[n]; if(!l) return; for(let i=0;i<l.length;i++){ try{ l[i](a,b,c); }catch(e){ if(window.console) console.warn("Ev",n,e); } } } };
  return api; })();
