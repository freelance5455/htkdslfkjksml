"use strict";
/* ===== GÖKYÜZÜ: shader kubbe, güneş/ay, yıldızlar, gün döngüsü (gündüz / gün batımı / gece / otomatik) ===== */
(function(){
const C=h=>new THREE.Color(h).convertSRGBToLinear();
const SU=Game.skyU={ hor:{value:C("#d3e6f6")}, zen:{value:C("#2f6fc2")}, gnd:{value:C("#5b6068")}, sunDir:{value:new THREE.Vector3(.5,.7,.4).normalize()}, sunCol:{value:C("#fff1d6")}, night:{value:0}, fade:{value:1}, time:{value:0}, space:{value:0}, camP:{value:new THREE.Vector3()}, horizY:{value:.2}, planetR:{value:40000}, cloud:{value:0} };
const dome=new THREE.Mesh(new THREE.SphereGeometry(1500,32,20),new THREE.ShaderMaterial({side:THREE.BackSide,depthWrite:false,fog:false,transparent:false,uniforms:SU,
  vertexShader:`varying vec3 vD; void main(){ vD=position; vec4 mv=modelViewMatrix*vec4(position,1.0); gl_Position=projectionMatrix*mv; gl_Position.z=gl_Position.w*.99999; }`,
  fragmentShader:`uniform vec3 hor; uniform vec3 zen; uniform vec3 gnd; uniform vec3 sunDir; uniform vec3 sunCol; uniform float night; uniform float fade; uniform float time; uniform float space; uniform vec3 camP; uniform float horizY; uniform float planetR; uniform float cloud; varying vec3 vD;
float h31(vec3 p){ return fract(sin(dot(p,vec3(127.1,311.7,74.7)))*43758.5453); }
float n3(vec3 p){ vec3 i=floor(p), f=fract(p); f=f*f*(3.-2.*f);
  return mix(mix(mix(h31(i),h31(i+vec3(1.,0.,0.)),f.x),mix(h31(i+vec3(0.,1.,0.)),h31(i+vec3(1.,1.,0.)),f.x),f.y),mix(mix(h31(i+vec3(0.,0.,1.)),h31(i+vec3(1.,0.,1.)),f.x),mix(h31(i+vec3(0.,1.,1.)),h31(i+vec3(1.,1.,1.)),f.x),f.y),f.z); }
float fbm(vec3 p){ float a=.5, s=0.; for(int i=0;i<4;i++){ s+=a*n3(p); p*=2.03; a*=.5; } return s; }
vec3 starsL(vec3 d){ vec3 c=vec3(0.);
  for(int k=0;k<3;k++){ float fk=float(k); vec3 p=d*(90.+fk*110.); vec3 i=floor(p); float h=h31(i+fk*17.); vec3 q=fract(p)-.5-(vec3(h31(i+1.),h31(i+2.),h31(i+3.))-.5)*.5;
    float st=smoothstep(.22-fk*.05,.0,length(q))*step(.985-fk*.004,h); vec3 tint=mix(vec3(.7,.8,1.),vec3(1.,.85,.7),h31(i+9.)); c+=tint*st*(.7+.3*sin(time*(2.+h*5.)+h*40.))*(1.5-fk*.3); }
  return c; }
vec3 spaceBg(vec3 d){ vec3 c=starsL(d); vec3 mw=normalize(vec3(.35,.82,.45)); float band=exp(-pow(dot(d,mw)*3.2,2.));
  float n=fbm(d*3.+vec3(3.1,1.7,.4)); float n2=fbm(d*7.+n*2.);
  c+=(mix(vec3(.18,.1,.35),vec3(.1,.28,.45),n2)*band*(.3+n*1.2)+vec3(.5,.14,.3)*pow(max(n-.55,0.),2.)*2.2*band)*.75; c+=vec3(.012,.016,.035); return c; }
vec3 planetCol(vec3 d,float t){ vec3 pw=vec3(d.x*t+camP.x, planetR+camP.y+1.2+d.y*t, d.z*t+camP.z); vec3 n=normalize(pw); vec3 w=n*3.4;
  float c=fbm(w+vec3(5.2,1.3,8.1)); float mask=smoothstep(.07,.2,length(n.xz)); float land=smoothstep(.55,.585,c)*mask;
  vec3 oc=mix(vec3(.015,.1,.27),vec3(.05,.3,.5),smoothstep(.35,.55,c));
  vec3 ld=mix(vec3(.13,.4,.13),vec3(.58,.47,.26),smoothstep(.6,.75,fbm(w*2.+9.))); ld=mix(ld,vec3(.92),smoothstep(.77,.86,c)*.9);
  vec3 alb=mix(oc,ld,land); float cl=smoothstep(.5,.78,fbm(n*7.+vec3(time*.012,0.,0.))); alb=mix(alb,vec3(1.),cl*.78);
  float lit=max(dot(n,sunDir),0.); float spec=pow(max(dot(reflect(-sunDir,n),-d),0.),40.)*(1.-land)*(1.-cl)*.7;
  vec3 col=alb*(lit*1.15+.025)+sunCol*spec; col+=vec3(1.,.75,.4)*step(.9,h31(floor(n*420.)))*land*(1.-cl)*smoothstep(.12,0.,lit)*.7;
  float rim=pow(1.-clamp(dot(n,-d),0.,1.),3.); col+=vec3(.25,.5,1.)*rim*(lit*.9+.08); return col; }
void main(){ vec3 d=normalize(vD); float y=d.y;
  vec3 col=y>=0.?mix(hor,zen,pow(y,.5)):mix(hor,gnd,min(1.,-y*4.));
  float sd=max(dot(d,sunDir),0.); col+=sunCol*(pow(sd,1400.)*7.+pow(sd,22.)*.4+pow(sd,3.)*.1*(1.-night));
  if(cloud>.001&&y>0.&&space<.95){ float kc=1.-smoothstep(0.,.6,space); vec2 cp=d.xz/(y+.13)*.5+vec2(time*.010,time*.004); float dn=fbm(vec3(cp,time*.008)); float cov=smoothstep(.48,.76,dn);
    if(cov>.003){ float dn2=fbm(vec3(cp+normalize(sunDir.xz+vec2(.0001))*.12,time*.008)); float lit=clamp(.5+(dn-dn2)*5.,0.,1.); float dayK=1.-night;
      vec3 shade=mix(vec3(.30,.34,.43),hor*.9+vec3(.08),.45)*(.35+.65*dayK)+vec3(.015,.02,.04)*night; vec3 lite=(sunCol*1.15+hor*.25)*(.12+.88*dayK)+vec3(.12,.14,.2)*night;
      vec3 cc=mix(shade,lite,lit); cc=mix(cc,hor,(1.-smoothstep(0.,.22,y))*.8); float a=cov*smoothstep(0.,.1,y)*cloud*kc*.93; col=mix(col,cc,a);
      col+=sunCol*pow(sd,10.)*cov*.28*dayK*cloud*kc*(1.-lit*.4); } }
  float md=max(dot(d,-sunDir),0.); col+=vec3(.75,.82,1.)*pow(md,3000.)*2.2*night;
  if(night>.02&&y>-.05){ vec3 p=d*150.; vec3 i=floor(p); float h=h31(i); vec3 c=fract(p)-.5-(vec3(h31(i+1.),h31(i+2.),h31(i+3.))-.5)*.5;
    float s=smoothstep(.2,.0,length(c))*step(.987,h)*(.65+.35*sin(time*3.+h*60.)); col+=vec3(.85,.9,1.)*s*night*smoothstep(-.02,.2,y)*1.4; }
  if(space>.001){ float k=smoothstep(0.,1.,space); vec3 atmo=col*(1.-.93*k*smoothstep(-.15,.75,y));
    if(space>.2){ vec3 sp=spaceBg(d); float sdd=max(dot(d,sunDir),0.); sp+=sunCol*(pow(sdd,2500.)*30.+pow(sdd,80.)*.7+pow(sdd,8.)*.09);
      vec3 md=normalize(vec3(-.55,.32,.78)); float mm=smoothstep(.9986,.9991,dot(d,md)); sp=mix(sp,vec3(.78,.78,.74)*(.25+.75*max(dot(normalize(cross(md,vec3(0.,1.,0.))),sunDir)*.5+.6,0.)),mm);
      float ang=(-d.y)-horizY;
      if(ang>0.){ float hh=camP.y+1.2; float b=(planetR+hh)*d.y; float disc=b*b-(2.*planetR*hh+hh*hh); float tt=-b-sqrt(max(disc,0.)); sp=planetCol(d,tt); }
      else { float sl=max(dot(normalize(vec3(d.x,0.,d.z)),normalize(vec3(sunDir.x,0.001,sunDir.z))),0.); sp+=vec3(.3,.55,1.)*exp(ang*46.)*.95*(.25+.75*sl)*smoothstep(.3,.7,space); }
      col=mix(atmo,sp,smoothstep(.2,.8,space)); } else col=atmo; }
  gl_FragColor=vec4(col,fade);
#include <tonemapping_fragment>
#include <encodings_fragment>
}`}));
dome.renderOrder=-10; dome.frustumCulled=false; scene.add(dome); Game.sky=dome;

/* ---- gün döngüsü ---- */
const KEYS=[ // yükseklik açısı (derece), ufuk, zirve, güneş rengi, güneş şiddeti, hemi şiddeti, sis yoğunluğu çarpanı
 {e:-16,h:"#0b1432",z:"#02040b",s:"#6d82c8",hi:.16},
 {e:-7, h:"#3a2a56",z:"#0a1030",s:"#8a6fa8",hi:.24},
 {e:0,  h:"#e0784a",z:"#2b3f7a",s:"#ff8c3a",hi:.38},
 {e:8,  h:"#f2b784",z:"#3d63a8",s:"#ffb36b",hi:.46},
 {e:22, h:"#cfe0ee",z:"#2f6fc2",s:"#ffe6c0",hi:.52},
 {e:50, h:"#d3e6f6",z:"#2f6fc2",s:"#fff1d6",hi:.55}];
KEYS.forEach(k=>{ k.hc=C(k.h); k.zc=C(k.z); k.sc=C(k.s); });
const tmpA=new THREE.Color();
function sample(e){ let a=KEYS[0], b=KEYS[KEYS.length-1]; if(e<=a.e){ b=a; } else if(e>=b.e){ a=b; } else { for(let i=0;i<KEYS.length-1;i++) if(e>=KEYS[i].e&&e<=KEYS[i+1].e){ a=KEYS[i]; b=KEYS[i+1]; break; } }
  const t=a===b?0:(e-a.e)/(b.e-a.e); return {a,b,t}; }
const sm=(a,b,x)=>{ const t=Math.max(0,Math.min(1,(x-a)/(b-a))); return t*t*(3-2*t); };
const HOUR_OF={day:12.5,sunset:18,night:22};
const hourToE=h=>Math.max(-30,Math.min(48,50*Math.sin((h-6)*Math.PI/12)));
const T=Game.tod={mode:"manual",hour:12.5,e:48,az:.5,phase:.25,envE:99,envT:0};
{ const sv=store.get("hour",null); if(sv==="auto") T.mode="auto"; else if(sv!==null&&!isNaN(parseFloat(sv))) T.hour=((parseFloat(sv)%24)+24)%24; else { const lg=store.get("tod",null); T.hour=HOUR_OF[lg]||HOUR_OF[(Game.MAP&&Game.MAP.tod)||"day"]||12.5; if(lg==="auto") T.mode="auto"; } }
let hourCbT=0;
Game.setHour=function(h){ if(h==="auto"){ T.mode="auto"; store.set("hour","auto"); }
  else { T.mode="manual"; T.hour=((+h%24)+24)%24; store.set("hour",String(Math.round(T.hour*100)/100)); applyH(); Game.refreshEnv(); }
  if(Game.onHour) Game.onHour(); };
Game.setTodMode=function(m){ if(m==="auto") return Game.setHour("auto"); Game.setHour(HOUR_OF[m]||12.5); };   // eski (gündüz/gün batımı/gece) çağrılar için
function applyH(){ T.az=(T.hour-6)/12*Math.PI/2; applyE(hourToE(T.hour)); }
function applyE(e){
  T.e=e; const rad=e*Math.PI/180, az=T.az*2, cd=Math.cos(rad), sd=SU.sunDir.value; sd.set(cd*Math.cos(az),Math.sin(rad),cd*Math.sin(az)).normalize();
  const s=sample(e); SU.hor.value.copy(s.a.hc).lerp(s.b.hc,s.t); SU.zen.value.copy(s.a.zc).lerp(s.b.zc,s.t); SU.sunCol.value.copy(s.a.sc).lerp(s.b.sc,s.t);
  { const MP=Game.MAP; if(MP&&MP.tint){ tmpA.setRGB(MP.tint[0],MP.tint[1],MP.tint[2]); const k=MP.tint[3]; SU.hor.value.lerp(tmpA,k); SU.zen.value.lerp(tmpA,k*.45); SU.sunCol.value.lerp(tmpA,k*.4); } }
  if(T.hour<12&&e<24&&e>-14){ tmpA.setRGB(.94,.55,.62); SU.hor.value.lerp(tmpA,.2*sm(-14,-2,e)*(1-sm(8,24,e))); }   // şafakta ufuk pembeleşir
  if(Game.onSkyApply) Game.onSkyApply(SU,e);
  SU.gnd.value.copy(SU.hor.value).multiplyScalar(.55); SU.night.value=1-sm(-10,3,e);
  const night=SU.night.value, day=sm(-2,12,e);
  T.hB=hemi.intensity=(s.a.hi+(s.b.hi-s.a.hi)*s.t)*(1-.12*(Game.rainK||0));
  const sunI=day*1.15*(1-.55*(Game.rainK||0)), moonI=sm(2,-8,e)*.32;
  if(e>=-1){ sun.color.copy(SU.sunCol.value); T.sB=sun.intensity=sunI; }
  else { sun.color.set(0x8fa6ff); T.sB=sun.intensity=moonI; }
  hemi.color.copy(SU.hor.value).lerp(new THREE.Color(1,1,1),.4); hemi.groundColor.set(0x3a3a46).lerp(new THREE.Color(.1,.12,.2),night);
  scene.fog.color.copy(SU.hor.value); scene.fog.density=.0013*(1+night*.8)*((Game.MAP&&Game.MAP.fogK)||1)*(Game.ultra?1.2:1)*(Game.seasonFogK||1)*(1+(Game.rainK||0)*.8);
  if(Game.CG&&Game.CG.setNight) Game.CG.setNight(night); Game.night=night;
  renderer&&(renderer.toneMappingExposure=(.85+night*.25)*(Game.ultra?1.07:1)); }
Game.reapplyTod=function(){ SU.cloud.value=Game.ultra?1:0; if(renderer) applyE(T.e); };
Game.refreshEnv=function(force){ if(!Game.makeEnv||!renderer) return; if(force||Math.abs(T.e-T.envE)>3){ T.envE=T.e; try{ Game.makeEnv(); }catch(err){} } };
Game.makeEnv=function(){ const es=new THREE.Scene(), g=new THREE.SphereGeometry(50,24,16), p=g.attributes.position, c=[], col=new THREE.Color(), hor=SU.hor.value, zen=SU.zen.value, gnd=SU.gnd.value;
  for(let i=0;i<p.count;i++){ const y=p.getY(i)/50; if(y>=0) col.copy(hor).lerp(zen,Math.pow(y,.55)); else col.copy(hor).lerp(gnd,Math.min(1,-y*3)); c.push(col.r,col.g,col.b); }
  g.setAttribute("color",new THREE.Float32BufferAttribute(c,3)); es.add(new THREE.Mesh(g,new THREE.MeshBasicMaterial({vertexColors:true,side:THREE.BackSide})));
  const day=Math.max(0,SU.sunDir.value.y), sm2=new THREE.Mesh(new THREE.SphereGeometry(5,8,6),new THREE.MeshBasicMaterial({color:new THREE.Color(9,8,6.5).multiplyScalar(day)}));
  sm2.position.copy(SU.sunDir.value).multiplyScalar(40); es.add(sm2);
  const pm=new THREE.PMREMGenerator(renderer); if(scene.environment&&scene.environment.dispose&&Game._envTex) Game._envTex.dispose(); Game._envTex=pm.fromScene(es,.02).texture; scene.environment=Game._envTex; pm.dispose(); };
applyH();
const ORG=new THREE.Vector3(), SNAP=6;
Game.updaters.push((dt,time)=>{
  SU.time.value=time; dome.position.copy(camera.position); SU.camP.value.copy(camera.position); { const hh=Math.max(1,camera.position.y+1.2), R=SU.planetR.value; SU.horizY.value=Math.sqrt(2*R*hh+hh*hh)/(R+hh); }
  if(T.mode==="auto"){ T.hour=(T.hour+(Game.ts===0?0:dt)*24/480)%24; applyH(); Game.refreshEnv(); hourCbT-=dt; if(hourCbT<=0){ hourCbT=.7; if(Game.onHour) Game.onHour(); } }
  const c=(Game.mode==="play"&&Game.heroObj)?Game.heroObj.position:ORG, cx=Math.round(c.x/SNAP)*SNAP, cz=Math.round(c.z/SNAP)*SNAP;
  const d=SU.sunDir.value, sgn=(T.e>=-1)?1:-1;
  sun.target.position.set(cx,0,cz); sun.target.updateMatrixWorld(); sun.position.set(cx+d.x*sgn*320,Math.max(40,d.y*sgn*320),cz+d.z*sgn*320); });
})();
