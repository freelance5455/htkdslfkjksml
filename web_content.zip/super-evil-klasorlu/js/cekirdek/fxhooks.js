"use strict";
/* ===== GLOBAL GÖLGELENDİRİCİ KANCASI: rüzgârda sallanma (ağaç/çalı/palmiye) + mevsim: çim rengi + kar örtüsü =====
   THREE.Material.prototype.onBeforeCompile ile bütün standart malzemelere eklenir. Bir hata olursa (derleme hatası) kanca kendini kapatır ve
   malzemeler kancasız yeniden derlenir (Game.fxInject=false). Bayraklar: material.defines.WIND_KIND (1 taç, 2 gövde, 3 palmiye yaprağı, 4 çalı, 5 çam, 6 çıplak dal, 7 yeni ağaç yaprağı, 8 yeni ağaç gövdesi), NO_SNOW. */
(function(){
const U=Game.fxU={uTime:{value:0},uWind:{value:1},uSnow:{value:0},uGrass:{value:new THREE.Vector3(1,1,1)}};
Game.fxInject=true; Game.fxFailed=false;
Game.windKind=(mat,k)=>{ mat.defines=Object.assign(mat.defines||{},{WIND_KIND:k}); return mat; };
Game.noSnow=mat=>{ mat.defines=Object.assign(mat.defines||{},{NO_SNOW:1}); return mat; };
Game.softSnow=mat=>{ mat.defines=Object.assign(mat.defines||{},{SNOW_SOFT:1}); return mat; };
if(!THREE.Material||!THREE.Material.prototype) return;
const WIND={
  1:"float wk=.1*(position.y*.5+.5+.3);",
  2:"float wk=.08*pow(clamp(position.y+.5,0.,1.),2.);",
  3:"float wk=.075*position.z+.03*position.z*sin(uTime*5.+position.z*2.+wph);",
  4:"float wk=.16*clamp(position.y*.5+.5,0.,1.);",
  5:"float wk=.3*pow(clamp(position.y+.5,0.,1.),1.6);",
  6:"float wk=.011*position.y*position.y;",
  7:"float wk=.0035*position.y*position.y+.035*clamp(position.y*.15,0.,1.)*sin(uTime*3.1+position.x*2.3+position.z*1.9+wph*3.);",
  8:"float wk=.0035*position.y*position.y;"
};
const MAIN=/void\s+main\s*\(\s*\)\s*\{/;
THREE.Material.prototype.onBeforeCompile=function(sh){ try{ inject.call(this,sh); }catch(e){ Game.fxInject=false; Game.fxFailed=true; try{ ce0(e); }catch(_){} } };
const ce0=function(e){ if(typeof console!=="undefined") console.warn("fxhooks: kapatıldı",e&&e.message); };
function inject(sh){
  if(!Game.fxInject) return; const df=this.defines||{}; if(df.FX_OFF) return;
  let vs=sh.vertexShader, fs=sh.fragmentShader; if(typeof vs!=="string"||typeof fs!=="string"||!sh.uniforms) return;
  const wk=df.WIND_KIND|0;
  if(wk&&WIND[wk]&&vs.indexOf("#include <begin_vertex>")>=0&&MAIN.test(vs)){
    vs=vs.replace(MAIN,"uniform float uTime;\nuniform float uWind;\nvoid main() {");
    vs=vs.replace("#include <begin_vertex>",
"#include <begin_vertex>\n{\n#ifdef USE_INSTANCING\n vec3 wp=instanceMatrix[3].xyz;\n#else\n vec3 wp=modelMatrix[3].xyz;\n#endif\n float wph=wp.x*.13+wp.z*.19;\n float wgx=sin(uTime*1.7+wph)*.6+sin(uTime*3.1+wph*1.7+1.3)*.4;\n float wgz=sin(uTime*1.3+wph*.8+2.0)*.6+sin(uTime*2.3+wph*1.3)*.4;\n "+WIND[wk]+"\n transformed.x+=wgx*uWind*wk;\n transformed.z+=wgz*uWind*wk*.8;\n}");
    sh.uniforms.uTime=U.uTime; sh.uniforms.uWind=U.uWind; }
  if(!df.NO_SNOW&&fs.indexOf("#include <normal_fragment_begin>")>=0&&fs.indexOf("#include <emissivemap_fragment>")>=0&&fs.indexOf("diffuseColor")>=0&&MAIN.test(fs)){
    fs=fs.replace(MAIN,"uniform float uSnow;\nuniform vec3 uGrass;\nvoid main() {");
    fs=fs.replace("#include <emissivemap_fragment>",
"#include <emissivemap_fragment>\n{\n float gG=clamp((diffuseColor.g-max(diffuseColor.r,diffuseColor.b))*6.,0.,1.);\n diffuseColor.rgb=mix(diffuseColor.rgb,diffuseColor.rgb*uGrass,gG);\n vec3 snUp=normalize((viewMatrix*vec4(0.,1.,0.,0.)).xyz);\n float snK=smoothstep("+(df.SNOW_SOFT?".05,.5":".5,.88")+",dot(normalize(normal),snUp))*uSnow;\n float snL=dot(diffuseColor.rgb,vec3(.3,.59,.11));\n snK*=mix(.28,1.,smoothstep(.2,.42,snL));\n diffuseColor.rgb=mix(diffuseColor.rgb,vec3(.93,.95,1.),snK*.92);\n}");
    sh.uniforms.uSnow=U.uSnow; sh.uniforms.uGrass=U.uGrass; }
  sh.vertexShader=vs; sh.fragmentShader=fs; }
/* derleme hatası olursa kancayı kapat ve herkesi yeniden derlet */
const ce=console.error;
console.error=function(){ try{ const m=String(arguments[0]); if(Game.fxInject&&(m.indexOf("THREE.WebGLProgram")>=0||m.indexOf("THREE.WebGLShader")>=0)){ Game.fxInject=false; Game.fxFailed=true; U.uSnow.value=0;
    const fix=sc=>{ if(!sc||!sc.traverse) return; sc.traverse(o=>{ const ms=o.material?(Array.isArray(o.material)?o.material:[o.material]):[]; for(const mt of ms){ mt.defines=Object.assign(mt.defines||{},{FX_OFF:1}); mt.needsUpdate=true; } }); };
    setTimeout(()=>{ try{ fix(scene); if(Game.menu3d) fix(Game.menu3d.scene); }catch(e){} },0); } }catch(e){} return ce.apply(console,arguments); };
})();
