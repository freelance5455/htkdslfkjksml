"use strict";
/* Cannon.js yüklenemezse devreye giren çok küçük yedek fizik (aynı API alt kümesi): yerçekimi, zemin, bina kutuları */
const MiniCannon=(function(){
  class Vec3{constructor(x=0,y=0,z=0){this.x=x;this.y=y;this.z=z;} set(x,y,z){this.x=x;this.y=y;this.z=z;return this;} copy(v){this.x=v.x;this.y=v.y;this.z=v.z;return this;} length(){return Math.hypot(this.x,this.y,this.z);}}
  class Quaternion{constructor(){this.x=0;this.y=0;this.z=0;this.w=1;} set(x,y,z,w){this.x=x;this.y=y;this.z=z;this.w=w;return this;} setFromAxisAngle(a,r){const s=Math.sin(r/2);return this.set(a.x*s,a.y*s,a.z*s,Math.cos(r/2));}}
  class Box{constructor(h){this.halfExtents=h;this.type=4;}} class Plane{constructor(){this.type=2;}}
  class Body{constructor(o){o=o||{};this.mass=o.mass||0;this.position=new Vec3();this.velocity=new Vec3();this.angularVelocity=new Vec3();this.quaternion=new Quaternion();
    this.shapes=[];this.shapeOffsets=[];this.linearDamping=.01;this.angularDamping=.01;this.collisionFilterGroup=1;this.collisionFilterMask=1;this.sleepState=0;if(o.shape)this.addShape(o.shape);}
    addShape(s,o){this.shapes.push(s);this.shapeOffsets.push(o||new Vec3());} updateBoundingRadius(){} }
  class World{constructor(){this.gravity=new Vec3(0,-9.8,0);this.bodies=[];this.solver={iterations:5};this.defaultContactMaterial={friction:.3,restitution:0};}
    addBody(b){this.bodies.push(b);} removeBody(b){const i=this.bodies.indexOf(b);if(i>=0)this.bodies.splice(i,1);}
    step(fd,dt){dt=Math.min(dt||fd,.05);const st=this.bodies.filter(b=>b.mass===0&&b.shapes[0]&&b.shapes[0].type===4);
      for(const b of this.bodies){ if(b.mass<=0) continue; const v=b.velocity,p=b.position,h=b.shapes[0]?b.shapes[0].halfExtents:{x:.5,y:.5,z:.5}, r=Math.max(.2,Math.min(h.x,h.y,h.z)*1.1);
        v.y+=this.gravity.y*dt; const ld=Math.pow(1-b.linearDamping,dt); v.x*=ld;v.y*=ld;v.z*=ld; p.x+=v.x*dt;p.y+=v.y*dt;p.z+=v.z*dt;
        const w=b.angularVelocity,q=b.quaternion,hx=w.x*.5*dt,hy=w.y*.5*dt,hz=w.z*.5*dt; q.set(q.x+hx*q.w+hy*q.z-hz*q.y,q.y+hy*q.w+hz*q.x-hx*q.z,q.z+hz*q.w+hx*q.y-hy*q.x,q.w-hx*q.x-hy*q.y-hz*q.z);
        const l=Math.hypot(q.x,q.y,q.z,q.w)||1;q.set(q.x/l,q.y/l,q.z/l,q.w/l); const ad=Math.pow(1-b.angularDamping,dt);w.x*=ad;w.y*=ad;w.z*=ad;
        const gy=this.groundFn?this.groundFn(p.x,p.z,p.y):0; if(p.y<gy+r){p.y=gy+r;if(v.y<0)v.y*=-.15; const hh=Math.hypot(v.x,v.z); if(hh>1e-4){ const kk=Math.max(0,hh-.7*(-this.gravity.y)*dt)/hh*.99; v.x*=kk; v.z*=kk; } const ag=Math.exp(-dt*9); w.x*=ag;w.y*=ag;w.z*=ag;}
        for(const s of st){ if(!(s.collisionFilterGroup&b.collisionFilterMask)) continue; const e=s.shapes[0].halfExtents,o=s.shapeOffsets[0],cx=s.position.x+o.x,cy=s.position.y+o.y,cz=s.position.z+o.z,dx=p.x-cx,dy=p.y-cy,dz=p.z-cz,px=e.x+r-Math.abs(dx),py=e.y+r-Math.abs(dy),pz=e.z+r-Math.abs(dz);
          if(px>0&&py>0&&pz>0){ if(py<=px&&py<=pz){p.y+=Math.sign(dy)*py;if(v.y*dy<0)v.y*=-.15;} else if(px<=pz){p.x+=Math.sign(dx)*px;v.x*=-.3;} else {p.z+=Math.sign(dz)*pz;v.z*=-.3;} } } } }}
  return {Vec3,Quaternion,Box,Plane,Body,World,SAPBroadphase:class{constructor(){}}};
})();
