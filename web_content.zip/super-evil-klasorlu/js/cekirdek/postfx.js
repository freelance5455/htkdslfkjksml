"use strict";
/* ===== SON İŞLEM: Yüksek = bloom. ULTRA = bloom + sinematik geçiş (ışık huzmeleri, lens parlaması, kromatik sapma, film tanesi, renk tonlama, vinyet).
   Kütüphane yüklenemezse sessizce kapalı kalır. ===== */
Game.post=null;
const CINE={
  uniforms:{tDiffuse:{value:null},res:{value:new THREE.Vector2(1,1)},time:{value:0},aspect:{value:1.6},sunUV:{value:new THREE.Vector2(.5,.5)},tint:{value:new THREE.Vector3(1,.92,.75)},rays:{value:0},flare:{value:0},grade:{value:1}},
  vertexShader:"varying vec2 vUv; void main(){ vUv=uv; gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0); }",
  fragmentShader:[
"uniform sampler2D tDiffuse; uniform vec2 res; uniform vec2 sunUV; uniform vec3 tint; uniform float time; uniform float aspect; uniform float rays; uniform float flare; uniform float grade; varying vec2 vUv;",
"float hash(vec2 p){ vec3 p3=fract(vec3(p.xyx)*.1031); p3+=dot(p3,p3.yzx+33.33); return fract((p3.x+p3.y)*p3.z); }",
"float lum(vec3 c){ return dot(c,vec3(.299,.587,.114)); }",
"void main(){",
"  vec2 uv=vUv; vec2 c=uv-.5; vec2 ca2=vec2(c.x*aspect,c.y); float r2=dot(ca2,ca2);",
"  vec2 ca=c*(.0012+.0042*r2);",
"  vec3 col=vec3(texture2D(tDiffuse,uv+ca).r,texture2D(tDiffuse,uv).g,texture2D(tDiffuse,uv-ca).b);",
"  if(rays>.001){ vec2 dl=sunUV-uv; float dist=length(dl*vec2(aspect,1.)); vec2 st=dl*(.9/16.); vec2 p=uv+st*hash(uv*res+fract(time)*7.); float w=1.; vec3 acc=vec3(0.);",
"    for(int i=0;i<16;i++){ p+=st; vec3 s=texture2D(tDiffuse,p).rgb; float m=smoothstep(.88,1.,lum(s)); acc+=s*m*w; w*=.93; }",
"    col+=acc*(1./16.)*rays*.42*exp(-dist*1.5)*tint; }",
"  if(flare>.001){ vec2 sc=clamp(sunUV,.001,.999); float sv=smoothstep(.6,.96,lum(texture2D(tDiffuse,sc).rgb))*flare; vec2 toC=vec2(.5)-sunUV; vec2 d0=(uv-sunUV)*vec2(aspect,1.); float L=length(d0);",
"    vec3 add=tint*exp(-L*L*38.)*.30+vec3(1.,.82,.62)*(1.-smoothstep(0.,.018,abs(L-.27)))*.035;",
"    add+=vec3(.55,.72,1.)*exp(-abs(uv.y-sunUV.y)*75.)*exp(-abs(uv.x-sunUV.x)*2.1)*.20;",
"    for(int i=0;i<4;i++){ float k=float(i); vec2 gp=sunUV+toC*(.55+k*.55); vec2 dg=(uv-gp)*vec2(aspect,1.); float r=.03+k*.022; float g=1.-smoothstep(r*.55,r,length(dg)); add+=mix(vec3(.4,.7,1.),vec3(1.,.6,.3),fract(k*.37+.2))*g*.05; }",
"    col+=add*sv; }",
"  col=clamp(col,0.,1.); col=mix(col,col*col*(3.-2.*col),.38*grade); float l=lum(col);",
"  col=mix(col,col*vec3(.90,1.0,1.08),(1.-l)*.55*grade); col+=vec3(.06,.025,-.02)*l*l*grade; col=mix(vec3(lum(col)),col,1.+.12*grade);",
"  col*=1.-.5*smoothstep(.28,.98,sqrt(r2)*1.32);",
"  col+=(hash(uv*res+fract(time)*113.)-.5)*.05*(1.-l*.55);",
"  gl_FragColor=vec4(clamp(col,0.,1.),1.); }"].join("\n")
};
Game.setupPost=function(){ Game.post=null; Game.cine=null; if(Game.quality!=="high"&&Game.quality!=="ultra") return;
  try{ if(!THREE.EffectComposer||!THREE.RenderPass||!THREE.UnrealBloomPass||!THREE.ShaderPass||!THREE.GammaCorrectionShader) return;
    const ult=Game.quality==="ultra", r=Game.three.renderer, comp=new THREE.EffectComposer(r); comp.addPass(new THREE.RenderPass(scene,camera));
    comp.addPass(new THREE.UnrealBloomPass(new THREE.Vector2(innerWidth,innerHeight),ult?.8:.6,ult?.7:.55,ult?.88:.92)); comp.addPass(new THREE.ShaderPass(THREE.GammaCorrectionShader));
    if(ult){ const sp=new THREE.ShaderPass(CINE); Game.cine=sp; comp.addPass(sp); }
    Game.post=comp;
  }catch(e){ Game.post=null; Game.cine=null; } };
/* güneş/ay ekran konumu → ışık huzmesi ve lens parlaması */
{ const sv=new THREE.Vector3(), fw=new THREE.Vector3(), sm=(a,b,x)=>{ const t=Math.max(0,Math.min(1,(x-a)/(b-a))); return t*t*(3-2*t); };
  Game.updaters.push((dt,time,raw)=>{ const sp=Game.cine; if(!sp||!Game.post) return; const u=sp.uniforms, r=Game.three.renderer; if(!r) return;
    const nt=Game.night||0, moon=nt>.5, dir=Game.skyU.sunDir.value, k=moon?-1:1;
    sv.set(dir.x*k,dir.y*k,dir.z*k); camera.getWorldDirection(fw); const front=fw.dot(sv);
    sv.multiplyScalar(900).add(camera.position).project(camera);
    const e=Math.max(Math.abs(sv.x),Math.abs(sv.y)), vis=front>.05?1:0, inten=moon?nt*.3:(1-nt), spc=1-Game.skyU.space.value;
    u.sunUV.value.set(sv.x*.5+.5,sv.y*.5+.5); u.rays.value=vis*(1-sm(1,1.9,e))*inten*spc; u.flare.value=vis*(1-sm(.82,1.04,e))*inten*spc;
    const c=Game.skyU.sunCol.value; u.tint.value.set(Math.sqrt(c.r),Math.sqrt(c.g),Math.sqrt(c.b)); if(moon) u.tint.value.set(.7,.8,1);
    u.res.value.set(r.domElement.width,r.domElement.height); u.aspect.value=innerWidth/innerHeight; u.time.value=time%1000; }); }
