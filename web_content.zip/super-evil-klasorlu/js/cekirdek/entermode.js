"use strict";
/* ===== MOD GEÇİŞİ: menu / play / pause. extras.js bunu sarmalar, bu yüzden ondan ÖNCE yüklenir (klasörlü sürümde hoisting olmadığı için) ===== */
function enterMode(mode){
  Game.mode=mode; $("hud").classList.toggle("on",mode==="play");
  if(mode==="menu"||mode==="pause"){ resetActions(); if(Game.dropHeld) Game.dropHeld(); Game.audio.stopLoops(); if(mode==="menu"&&Game.resetPowers2) Game.resetPowers2(); if(mode==="menu"&&Game.Land) Game.Land.reset(); show(mode==="menu"?"menu":"pauseP"); }
  else SCREENS.forEach(s=>$(s).classList.remove("on"));
  Game.audio.unlock(); }
