"use strict";
/* ===== MEVSİMLER: ilkbahar / yaz / sonbahar / kış =====
   Ağaç renkleri (çiçek açan, sararan), kışın çıplak dallı ağaçlar, çalılar, yer çiçekleri / dökülen yapraklar, kar örtüsü (gölgelendirici),
   yağmur (ilkbahar/sonbahar sağanakları + gök gürültüsü), düşen yaprak / kar / çiçek taç yaprağı, rüzgâr esintileri, gökyüzü tonu ve sis. */
(function(){
const U=Game.fxU, SU=Game.skyU, MP=Game.MAP, TR=Game.treeRefs, W=Game.W, CG=Game.CG, T=Game.tod, G=TR.G;
const lin=h=>new THREE.Color(h).convertSRGBToLinear();
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v)), mix=(a,b,t)=>a+(b-a)*t;
const hash=i=>{ const x=Math.sin(i*127.1+311.7)*43758.5453; return x-Math.floor(x); };
const rs=(()=>{ let s=24681; return ()=>{ s=(s*16807)%2147483647; return s/2147483647; }; })();
const SEAS={
  spring:{grass:[.9,1.16,.8],snow:0,fog:1.05,tint:[.86,.95,1,.06],wind:1.05},
  summer:{grass:[1,1,1],snow:0,fog:1,tint:null,wind:.8},
  autumn:{grass:[2.3,.85,.75],snow:0,fog:1.12,tint:[1,.7,.4,.16],wind:1.4},
  winter:{grass:[1.4,.95,1.15],snow:1,fog:1.38,tint:[.8,.9,1,.22],wind:1.1} };
let season=Game.settings.season; if(!SEAS[season]) season="summer";
const cur={snow:SEAS[season].snow,fog:SEAS[season].fog,g:SEAS[season].grass.slice(),wind:SEAS[season].wind};
Game.season=season;
/* kar birikimi (0..1): kışın kar yağdıkça yer yavaş yavaş beyazlaşır (winter.js ayak izi / yığın / kardan adam bunu okur) */
Game.snowAcc=(season==='winter'&&MP.weather!=='snow')?.3:1;
const PINK=["#f6a9c4","#f9c6d9","#ffdbe7","#ef8fb2","#fbe3ee"].map(lin), AUT=["#d9822b","#c4411f","#e0a82a","#9c5a1d","#b8321a","#a8a032","#cf6a1d"].map(lin);
const FRESH=lin("#6fd04c"), OLIVE=lin("#6d7a2a"), WINT=lin("#2c4a44"), BRANCH=lin("#4a3a2c"), BUSHW=lin("#5a4a3c");

/* ---------- ağaç taçları + çam ağaçları: yeniden boyama (her varyantın yaprak mesh'i ayrı) ---------- */
function paintCanopy(mesh,base,n,off){ if(!mesh||!base||!mesh.instanceColor) return; const arr=mesh.instanceColor.array, c=new THREE.Color();
  for(let i=0;i<n;i++){ const br=base[i*3], bg=base[i*3+1], bb=base[i*3+2], h=hash(i+off), h2=hash(i+off+7.3); c.setRGB(br,bg,bb);
    if(season==="spring"){ if(h<.42){ c.copy(PINK[(i*7)%PINK.length]).multiplyScalar((.9+h2*.2)*1.2); } else c.lerp(FRESH,.32); }
    else if(season==="autumn"){ if(h<.16) c.lerp(OLIVE,.55); else c.copy(AUT[(i*5)%AUT.length]).multiplyScalar((.82+h2*.3)*1.18); if(MP.greens&&h>.5) c.lerp(new THREE.Color(br,bg,bb),.25); }
    arr[i*3]=c.r; arr[i*3+1]=c.g; arr[i*3+2]=c.b; }
  mesh.instanceColor.needsUpdate=true; }
function paintPines(mesh,base,n){ if(!mesh||!base||!mesh.instanceColor) return; const arr=mesh.instanceColor.array, c=new THREE.Color();
  for(let i=0;i<n;i++){ c.setRGB(base[i*3],base[i*3+1],base[i*3+2]); if(season==="spring") c.lerp(FRESH,.14); else if(season==="autumn") c.lerp(OLIVE,.2); else if(season==="winter") c.lerp(WINT,.4).multiplyScalar(.85); arr[i*3]=c.r; arr[i*3+1]=c.g; arr[i*3+2]=c.b; }
  mesh.instanceColor.needsUpdate=true; }
function paintTrees(){ for(const p of TR.parts){ if(p.kind==="pine") paintPines(p.leaf,p.base,p.list.length); else paintCanopy(p.leaf,p.base,p.list.length,p.vi*977); } }

/* ---------- kışın çıplak ağaç dalları (varyant başına tek geometri; gövdeyle aynı rüzgâr türü) ---------- */
let bareDone=false;
function ensureBare(){ if(bareDone) return; bareDone=true;
  const mat=Game.softSnow(Game.windKind(new THREE.MeshStandardMaterial({color:BRANCH,roughness:1,side:THREE.DoubleSide}),8)), o=new THREE.Object3D();
  for(const p of TR.parts){ if(!p.V.bare) continue; const list=p.list, m=new THREE.InstancedMesh(p.V.bare,mat,Math.max(1,list.length));
    list.forEach((r,i)=>{ o.position.set(r.x,r.gy,r.z); o.rotation.set(0,r.alive?r.rot:0,0); o.scale.setScalar(r.alive?r.s:.0001); o.updateMatrix(); m.setMatrixAt(i,o.matrix); });
    m.instanceMatrix.needsUpdate=true; m.visible=false; if(!list.length) m.count=0; p.bare=m; TR.attachBare(p,mat); } }

/* ---------- çalılar + yer süsleri (çiçek / yaprak) ---------- */
let bush=null, flowers=null, litter=null, bushList=[];
function buildGround(){ const trees=(CG.lists&&CG.lists.trees)||[], cells=W.inCity; const bl=[], fl=[], lf=[];
  trees.forEach((t,i)=>{ const x=t[0], z=t[1], s=t[2]; if(hash(i*1.7)>.58) return; const gx=Math.round(x/34), gz=Math.round(z/34), cx=gx*34, cz=gz*34; let a;
    if(cells(gx,gz)&&Math.abs(x-cx)<=14&&Math.abs(z-cz)<=14){ const dx=cx-x, dz=cz-z; if(Math.hypot(dx,dz)<1) return; a=Math.atan2(dz,dx)+(rs()-.5)*1.3; }
    else if(Math.hypot(x,z)<420) return; else a=rs()*6.28;
    const d=1.5+rs()*1.1; const bx=x+Math.cos(a)*d, bz=z+Math.sin(a)*d; if(G(bx,bz)<-.2) return; bl.push([bx,bz,.7+rs()*.5,rs()*6.28]);
    if(rs()<.4) for(let k=0;k<7;k++){ const aa=rs()*6.28, rr=.5+rs()*1.3; fl.push([bx+Math.cos(aa)*rr,bz+Math.sin(aa)*rr,rs(),rs()]); } });
  trees.forEach((t,i)=>{ if(hash(i*2.9+4)>.42) return; const x=t[0], z=t[1], s=t[2]; for(let k=0;k<9;k++){ const aa=rs()*6.28, rr=.7+rs()*2.8*s; const px=x+Math.cos(aa)*rr, pz=z+Math.sin(aa)*rr; if(G(px,pz)<-.2) continue; lf.push([px,pz,rs(),rs()]); } });
  bushList=bl; const o=new THREE.Object3D();
  const bm=Game.softSnow(Game.windKind(new THREE.MeshStandardMaterial({roughness:.95,flatShading:true}),4));
  bush=new THREE.InstancedMesh(new THREE.IcosahedronGeometry(1,0),bm,Math.max(1,bl.length*2)); bush.count=bl.length*2;
  bl.forEach((b,i)=>{ const gy=G(b[0],b[1]); o.position.set(b[0],gy+.45*b[2],b[1]); o.rotation.set(0,b[3],0); o.scale.set(1.15*b[2],.8*b[2],1.05*b[2]); o.updateMatrix(); bush.setMatrixAt(i*2,o.matrix);
    o.position.set(b[0]+.55*b[2],gy+.35*b[2],b[1]+.3*b[2]); o.rotation.set(0,b[3]+1,0); o.scale.set(.75*b[2],.6*b[2],.8*b[2]); o.updateMatrix(); bush.setMatrixAt(i*2+1,o.matrix); bush.setColorAt(i*2,new THREE.Color(1,1,1)); bush.setColorAt(i*2+1,new THREE.Color(1,1,1)); });
  bush.instanceMatrix.needsUpdate=true; bush.castShadow=true; bush.receiveShadow=true; bush.frustumCulled=false; scene.add(bush);
  const fg=new THREE.BoxGeometry(1,1,1), fm=new THREE.MeshStandardMaterial({roughness:.8});
  flowers=new THREE.InstancedMesh(fg,fm,Math.max(1,fl.length)); fl.forEach((f,i)=>{ o.position.set(f[0],G(f[0],f[1])+.2,f[1]); o.rotation.set(0,f[2]*6.28,0); o.scale.set(.15+f[3]*.1,.14+f[3]*.1,.15+f[3]*.1); o.updateMatrix(); flowers.setMatrixAt(i,o.matrix);
    flowers.setColorAt(i,[lin("#ff5d8f"),lin("#ffd23f"),lin("#ffffff"),lin("#b388ff"),lin("#ff8a3d")][Math.floor(f[2]*5)%5]); });
  flowers.instanceMatrix.needsUpdate=true; flowers.frustumCulled=false; flowers.receiveShadow=true; flowers.visible=false; if(!fl.length) flowers.count=0; scene.add(flowers);
  litter=new THREE.InstancedMesh(fg,new THREE.MeshStandardMaterial({roughness:1}),Math.max(1,lf.length)); lf.forEach((f,i)=>{ o.position.set(f[0],G(f[0],f[1])+.17,f[1]); o.rotation.set(0,f[2]*6.28,0); o.scale.set(.3+f[3]*.2,.02,.2+f[3]*.15); o.updateMatrix(); litter.setMatrixAt(i,o.matrix); litter.setColorAt(i,AUT[Math.floor(f[3]*AUT.length*.999)]); });
  litter.instanceMatrix.needsUpdate=true; litter.frustumCulled=false; litter.receiveShadow=true; litter.visible=false; if(!lf.length) litter.count=0; scene.add(litter); }
function paintBush(){ if(!bush||!bush.instanceColor) return; const arr=bush.instanceColor.array, c=new THREE.Color(), n=bushList.length*2;
  for(let i=0;i<n;i++){ const h=hash(i*1.3+2), h2=hash(i*.7+5); if(season==="summer") c.setRGB(.05+h*.06,.22+h2*.14,.05+h*.04);
    else if(season==="spring"){ if(h<.35) c.copy(PINK[i%PINK.length]).multiplyScalar(.9); else c.setRGB(.07+h*.05,.3+h2*.14,.06); }
    else if(season==="autumn") c.copy(AUT[(i*3)%AUT.length]).multiplyScalar(.6+h2*.3); else c.copy(BUSHW).multiplyScalar(.8+h2*.4);
    arr[i*3]=c.r; arr[i*3+1]=c.g; arr[i*3+2]=c.b; }
  bush.instanceColor.needsUpdate=true; }

/* ---------- hava durumu parçacıkları: kar / yaprak / taç yaprağı (nokta), yağmur (çizgi) ---------- */
const BOXP=90, BOXR=70, NP=1800, NR=1900, uP={time:{value:0},scale:{value:800},size:{value:.09},vis:{value:0},kind:{value:1},cam:{value:new THREE.Vector3()},fall:{value:new THREE.Vector3(.7,-2.3,.4)},op:{value:.9},lit:{value:1}},
  uR={time:{value:0},vis:{value:0},cam:{value:new THREE.Vector3()},fall:{value:new THREE.Vector3(1.6,-30,.9)},lit:{value:1}};
let pts=null, rain=null, partQ=1;
function buildParticles(){
  const sd=new Float32Array(NP*4); for(let i=0;i<NP;i++){ sd[i*4]=Math.random(); sd[i*4+1]=Math.random(); sd[i*4+2]=Math.random(); sd[i*4+3]=.5+Math.random()*.9; }
  const g=new THREE.BufferGeometry(); g.setAttribute("position",new THREE.BufferAttribute(new Float32Array(NP*3),3)); g.setAttribute("sd",new THREE.BufferAttribute(sd,4));
  const m=new THREE.ShaderMaterial({transparent:true,depthWrite:false,uniforms:uP,
    vertexShader:"attribute vec4 sd; uniform float time,scale,size,vis,kind; uniform vec3 cam,fall; varying float va; varying vec3 vc; void main(){ float B="+BOXP+".; vec3 p=sd.xyz*B-vec3(B*.5)+fall*time*sd.w; float lf=step(1.5,kind);"
      +" p.x+=sin(time*.8+sd.x*30.)*.6*sd.w+lf*sin(time*2.3+sd.y*40.)*.9; p.z+=cos(time*.7+sd.z*30.)*.6*sd.w; p.y+=lf*sin(time*3.1+sd.x*50.)*.3;"
      +" vec3 w=mod(p-cam+vec3(B*.5),B)-vec3(B*.5); vec4 mv=viewMatrix*vec4(cam+w,1.); gl_Position=projectionMatrix*mv; float d=length(w); float keep=step(fract(sd.y*91.7+sd.z*13.1),vis); va=keep*(1.-smoothstep(B*.35,B*.5,d));"
      +" gl_PointSize=clamp(size*scale/max(-mv.z,.4)*sd.w*8.,1.,30.);"
      +" vc=kind<1.5?vec3(1.):(kind<2.5?mix(vec3(.85,.32,.08),vec3(.95,.72,.15),fract(sd.x*13.7))*(.7+.3*fract(sd.z*7.1)):vec3(1.,.78,.86)); }",
    fragmentShader:"uniform float op,lit; varying float va; varying vec3 vc; void main(){ vec2 c=gl_PointCoord-.5; float a=smoothstep(.5,.15,length(c))*op*va; if(a<.02) discard; gl_FragColor=vec4(vc*lit,a); }"});
  pts=new THREE.Points(g,m); pts.frustumCulled=false; pts.renderOrder=6; pts.visible=false; scene.add(pts);
  const sr=new Float32Array(NR*2*4), ee=new Float32Array(NR*2); for(let i=0;i<NR;i++){ const a=Math.random(), b=Math.random(), c=Math.random(), d=Math.random(); for(let k=0;k<2;k++){ sr.set([a,b,c,d],(i*2+k)*4); ee[i*2+k]=k; } }
  const g2=new THREE.BufferGeometry(); g2.setAttribute("position",new THREE.BufferAttribute(new Float32Array(NR*2*3),3)); g2.setAttribute("sd",new THREE.BufferAttribute(sr,4)); g2.setAttribute("e",new THREE.BufferAttribute(ee,1));
  const m2=new THREE.ShaderMaterial({transparent:true,depthWrite:false,uniforms:uR,
    vertexShader:"attribute vec4 sd; attribute float e; uniform float time,vis; uniform vec3 cam,fall; varying float va; void main(){ float B="+BOXR+".; vec3 p=sd.xyz*B-vec3(B*.5)+fall*time*(.85+.3*sd.w); vec3 w=mod(p-cam+vec3(B*.5),B)-vec3(B*.5);"
      +" vec3 wp=cam+w-normalize(fall)*e*(.45+.35*sd.w); gl_Position=projectionMatrix*viewMatrix*vec4(wp,1.); float keep=step(fract(sd.y*91.7+sd.z*13.1),vis); va=keep*(1.-smoothstep(B*.3,B*.5,length(w)))*(1.-e*.8); }",
    fragmentShader:"uniform float lit; varying float va; void main(){ if(va<.02) discard; gl_FragColor=vec4(vec3(.72,.8,.92)*lit,va*.55); }"});
  rain=new THREE.LineSegments(g2,m2); rain.frustumCulled=false; rain.renderOrder=6; rain.visible=false; scene.add(rain); }

/* ---------- uygula ---------- */
function apply(){ const S=SEAS[season]; Game.season=season; Game.settings.season=season;
  paintTrees(); paintBush(); TR.dirty=true;
  const win=season==="winter"; if(win) ensureBare(); for(const p of TR.parts){ if(p.kind==='broad') p.leaf.visible=!win; if(p.bare) p.bare.visible=win; }
  if(flowers) flowers.visible=season==="spring"; if(litter) litter.visible=season==="autumn";
  pts.material.uniforms.kind.value=season==="winter"?1:season==="autumn"?2:3; 
  Game.seasonFogK=cur.fog; if(Game.reapplyTod) Game.reapplyTod(); }
Game.setSeason=function(s){ if(!SEAS[s]||s===season) return; season=s; store.set("season",s); Game.snowAcc=(s==='winter'&&MP.weather!=='snow')?.3:1; apply(); if(Game.onSeasonSet) Game.onSeasonSet(s); };

Game.onSkyApply=function(S,e){ const k=SEAS[season].tint, t=new THREE.Color();
  if(k){ t.setRGB(k[0],k[1],k[2]); S.hor.value.lerp(t,k[3]); S.zen.value.lerp(t,k[3]*.5); S.sunCol.value.lerp(t,k[3]*.3); }
  const r=Game.rainK||0; if(r>.01){ t.setRGB(.5,.55,.62); S.hor.value.lerp(t,.55*r); S.zen.value.lerp(t,.6*r); S.sunCol.value.lerp(t,.4*r); } };

let rainK=0, lastRainApplied=0, flash=0, thunderT=8, nextBird=3, seedF=0, windS=1;
const target=time=>{ if(season==="spring") return clamp(Math.sin(time*.04-1.1)*1.25-.3+.15,0,1); if(season==="autumn") return clamp(Math.sin(time*.027+2.2)*1.3-.55,0,1)*.6; return 0; };
Game.updaters.push((dt,time,raw)=>{ const d=raw||dt; if(!pts) return; const play=Game.mode==="play"||Game.mode==="pause", st=SEAS[season], au=Game.audio;
  /* geçişler */
  const k=Math.min(1,d*.9); if(season==='winter'&&Game.mode==='play'&&Game.snowAcc<1) Game.snowAcc=Math.min(1,Game.snowAcc+d/260); cur.snow+=(st.snow*(season==='winter'?Game.snowAcc:1)-cur.snow)*k; cur.fog+=(st.fog-cur.fog)*k; for(let i=0;i<3;i++) cur.g[i]+=(st.grass[i]-cur.g[i])*k; cur.wind+=(st.wind-cur.wind)*k;
  U.uTime.value=time; U.uSnow.value=cur.snow; U.uGrass.value.set(cur.g[0],cur.g[1],cur.g[2]); Game.seasonFogK=cur.fog;
  /* rüzgâr esintileri */
  const gust=.72+.3*Math.sin(time*.23)+.2*Math.sin(time*.61+1.7); windS=gust*cur.wind*(1+rainK*.5); U.uWind.value=windS; Game.windK=windS;
  /* yağmur */
  const tg=target(time); rainK+=(tg-rainK)*Math.min(1,d*.35); if(rainK<.01&&tg===0) rainK=0; Game.rainK=rainK;
  if(Math.abs(rainK-lastRainApplied)>.05||(rainK===0&&lastRainApplied!==0)){ lastRainApplied=rainK; if(Game.reapplyTod) Game.reapplyTod(); }
  const T=Game.tod; flash=Math.max(0,flash-d*3.2);
  if(rainK>.75&&play){ thunderT-=d; if(thunderT<=0){ thunderT=14+Math.random()*30; flash=1; if(au&&au.thunder) setTimeout(()=>au.thunder(1+Math.random()),350+Math.random()*1600); } }
  if(flash>0||seedF>0){ hemi.intensity=(T.hB||hemi.intensity)*(1+flash*3.2); seedF=flash>0?1:0; }
  /* parçacıklar */
  const alt=camera.position.y, night=Game.night||0, lit=.3+.7*(1-night)*(1-.35*rainK); uP.lit.value=lit; uR.lit.value=lit;
  const hq=Game.quality, pq=hq==="low"?.45:hq==="medium"?.75:1; if(pq!==partQ){ partQ=pq; pts.geometry.setDrawRange(0,Math.floor(NP*pq)); rain.geometry.setDrawRange(0,Math.floor(NR*2*pq)); }
  const snowMap=MP.weather==="snow", cam=camera.position, hh=Game.three.renderer?Game.three.renderer.domElement.height:800;
  const wantP=season==="winter"?(snowMap?0:1):season==="autumn"?.5+.5*windS/1.4:season==="spring"?.35:0, altP=clamp(1-(alt-(season==="winter"?150:90))/220,0,1);
  uP.vis.value+=((play?wantP*altP:0)-uP.vis.value)*Math.min(1,d*1.5); pts.visible=uP.vis.value>.01&&play; uP.time.value=time; uP.cam.value.copy(cam); uP.scale.value=hh/(2*Math.tan(camera.fov*Math.PI/360));
  const kind=uP.kind.value; uP.size.value=kind===1?.09:kind===2?.2:.07; uP.fall.value.set(kind===1?.7:kind===2?1.8*(.5+windS*.6):.9*(.5+windS*.6),kind===1?-2.3:kind===2?-1.3:-.8,kind===2?.7:.3);
  const altR=clamp(1-(alt-90)/160,0,1); uR.vis.value=play?rainK*altR:0; rain.visible=uR.vis.value>.02; uR.time.value=time; uR.cam.value.copy(cam); uR.fall.value.set(1.2+windS*1.1,-30,.9);
  /* ses katmanları + kuşlar */
  if(au&&au.amb){ const low=alt<140; au.amb("rain",play&&low?rainK*.24:0); au.amb("breeze",play?(low?.012+Math.max(0,windS-.5)*.05:.004):0); au.amb("crickets",play&&low&&season!=="winter"&&rainK<.2?clamp((night-.5)*2,0,1)*.03:0);
    if(play&&alt<70&&night<.4&&rainK<.1&&season!=="winter"){ nextBird-=d; if(nextBird<=0){ nextBird=2.5+Math.random()*6; au.bird(); } } } });

buildGround(); buildParticles(); apply();
})();
