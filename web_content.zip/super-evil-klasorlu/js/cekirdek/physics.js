"use strict";
/* ===== FİZİK (Cannon.js): enkaz havuzu, bina kutuları, NPC/araba gövdeleri ===== */
const P = Game.P = (function(){
  const CN=(typeof CANNON!=="undefined")?CANNON:MiniCannon; Game.usingCannon=(typeof CANNON!=="undefined");
  const world=new CN.World(); const G0=14; world.gravity.set(0,-G0,0);  /* 26 -> 14: eski değerde her şey roket gibi fırlayıp 'çizgi film' gibi düşüyordu */
  try{ world.broadphase=new CN.SAPBroadphase(world); }catch(e){}
  world.solver.iterations=6; world.allowSleep=true; world.defaultContactMaterial.friction=.45; world.defaultContactMaterial.restitution=.12;
  const G_STATIC=1,G_DEBRIS=2,G_NPC=4,G_CAR=8;
  const W=Game.W;
  world.groundFn=(x,z,y)=>{ const h=W.surfaceAt(x,z,y); return h; };      // MiniCannon yedeği: arazi/köprü yüksekliği
  const tracked=new Set(), SEA=[];                                       // yer çekimi sonrası arazi/deniz düzeltmesi yapılan gövdeler
  const MAXP=160, CAP={low:36,medium:72,high:120,ultra:150};
  const dMat=new THREE.MeshStandardMaterial({roughness:.85,metalness:.05});
  const dMesh=new THREE.InstancedMesh(new THREE.BoxGeometry(1,1,1),dMat,MAXP); dMesh.castShadow=true; dMesh.receiveShadow=true; dMesh.frustumCulled=false; scene.add(dMesh);
  const dummy=new THREE.Object3D(), col=new THREE.Color(), pool=[], free=[];
  dummy.scale.set(0,0,0); dummy.updateMatrix();
  for(let i=0;i<MAXP;i++){ pool.push({slot:i,body:null,on:false,age:0,rest:0,fade:0,sx:1,sy:1,sz:1}); free.push(i); dMesh.setMatrixAt(i,dummy.matrix); dMesh.setColorAt(i,col.set(1,1,1)); }
  dMesh.instanceMatrix.needsUpdate=true; if(dMesh.instanceColor) dMesh.instanceColor.needsUpdate=true;
  let active=0;
  function release(r){ if(!r.on) return; r.on=false; if(r.body){ tracked.delete(r.body); world.removeBody(r.body); r.body=null; } dummy.scale.set(0,0,0); dummy.updateMatrix(); dMesh.setMatrixAt(r.slot,dummy.matrix); free.push(r.slot); active--; }
  function oldest(){ let o=null; for(const r of pool) if(r.on&&(!o||r.age>o.age)) o=r; return o; }
  const rs=()=>Math.random()-.5, api={world,pool,mesh:dMesh,G_STATIC,G_DEBRIS,G_NPC,G_CAR,CN};
  api.spawnDebris=function(c,vx,vy,vz){
    const vol=c.sx*c.sy*c.sz, n=vol>90?2:1, ax=(c.sy>=c.sx&&c.sy>=c.sz)?1:(c.sx>=c.sz?0:2), dim=[c.sx,c.sy,c.sz], tot=dim[ax], len=tot/n, cap=Math.max(24,Math.round((CAP[Game.quality]||100)*(Game.physK||1)));
    for(let i=0;i<n;i++){ if(free.length===0||active>=cap){ const o=oldest(); if(o) release(o); else return; }
      const s=free.pop(), r=pool[s], d=dim.slice(); d[ax]=len; const off=(i+.5)*len-tot/2, ox=ax===0?off:0, oy=ax===1?off:0, oz=ax===2?off:0;
      r.sx=Math.max(.3,Math.min(3.2,d[0]*.62)); r.sy=Math.max(.3,Math.min(3.2,d[1]*.62)); r.sz=Math.max(.3,Math.min(3.2,d[2]*.62));
      const b=new CN.Body({mass:Math.max(2,r.sx*r.sy*r.sz*.15),shape:new CN.Box(new CN.Vec3(r.sx/2*.97,r.sy/2*.97,r.sz/2*.97))});
      b.position.set(c.x+ox,c.y+oy,c.z+oz); b.velocity.set(vx+rs()*3,vy+rs()*2,vz+rs()*3); b.angularVelocity.set(rs()*6,rs()*6,rs()*6);
      b.linearDamping=.02; b.angularDamping=.3; b.allowSleep=true; b.sleepSpeedLimit=.5; b.sleepTimeLimit=.8;
      b.collisionFilterGroup=G_DEBRIS; b.collisionFilterMask=G_STATIC|G_NPC|G_CAR; b.half=[r.sx/2*.97,r.sy/2*.97,r.sz/2*.97]; tracked.add(b); world.addBody(b);
      r.body=b; r.on=true; r.age=0; r.rest=0; r.fade=0; active++;
      let cr=c.r*.85,cg=c.g*.85,cb=c.b*.85; if(c.burn>.3){cr=cg=cb=.03;} else if(c.frost>.5){cr=.5;cg=.75;cb=.95;}
      dMesh.setColorAt(r.slot,col.setRGB(cr,cg,cb)); if(dMesh.instanceColor) dMesh.instanceColor.needsUpdate=true; } };
  api.addBody=function(half,mass,x,y,z,group,mask){ const b=new CN.Body({mass,shape:new CN.Box(new CN.Vec3(half[0],half[1],half[2]))}); b.position.set(x,y,z);
    b.collisionFilterGroup=group; b.collisionFilterMask=mask; b.linearDamping=.05; b.angularDamping=.2; b.half=half; b.allowSleep=false; /* uyuyan gövde desteği kalkınca havada asılı kalıyordu */ tracked.add(b); world.addBody(b); return b; };
  api.removeBody=b=>{ if(b){ tracked.delete(b); world.removeBody(b); } };
  /* Yakındaki binalar için statik kutular */
  const statics=new Map(); let stT=0;
  function syncStatics(px,pz){
    for(const [e,b] of statics){ if(e.h<=0||Math.hypot(e.x-px,e.z-pz)>(e.tree?90:110)){ world.removeBody(b.body); statics.delete(e); } else if(b.h!==e.h){ resizeStatic(b,e); } }
    for(const e of Game.buildings){ if(e.h<=0||statics.has(e)||Math.hypot(e.x-px,e.z-pz)>90) continue; const body=new CN.Body({mass:0}); body.position.set(e.x,0,e.z);
      body.collisionFilterGroup=G_STATIC; body.collisionFilterMask=0xFFFF; const rec={body,h:0}; resizeStatic(rec,e); world.addBody(body); statics.set(e,rec); }
    if(Game.Trees&&Game.Trees.near) Game.Trees.near(px,pz,70,r=>{ const e=Game.Trees.solidRec(r); if(statics.has(e)) return; const body=new CN.Body({mass:0}); body.position.set(e.x,0,e.z);
      body.collisionFilterGroup=G_STATIC; body.collisionFilterMask=0xFFFF; const rec={body,h:0}; resizeStatic(rec,e); world.addBody(body); statics.set(e,rec); }); }
  function resizeStatic(rec,e){ const b=rec.body; b.shapes=[]; b.shapeOffsets=[]; if(b.shapeOrientations) b.shapeOrientations=[];
    const y0=e.y0||0, hh=Math.max(.1,e.h-y0)/2; b.addShape(new CN.Box(new CN.Vec3(e.hw,hh,e.hd)),new CN.Vec3(0,y0+hh,0)); b.updateBoundingRadius(); b.aabbNeedsUpdate=true; rec.h=e.h; }

  /* arazi/deniz: gövde, yönelimine göre dikey yarı-boyutu kadar zeminin üstünde tutulur; denizde sızar ve "batar" */
  const hyOf=b=>{ const h=b.half||[.3,.3,.3], q=b.quaternion, x=q.x,y=q.y,z=q.z,w=q.w; return h[0]*Math.abs(2*(x*y+z*w))+h[1]*Math.abs(1-2*(x*x+z*z))+h[2]*Math.abs(2*(y*z-x*w)); };
  function clampBody(b,dt){ const p=b.position, v=b.velocity; if(!isFinite(p.x)) return; const hy=hyOf(b), t=W.terrainH(p.x,p.z), deck=W.bridge.deckAt?W.bridge.deckAt(p.x,p.z):null;
    let gy=t; if(deck!==null&&p.y-hy>=deck-1.2&&deck>gy) gy=deck;
    if(gy<W.WATER_Y-.05){                                          // su üstü
      if(p.y-hy<W.WATER_Y+.1){ if(!b.wet){ b.wet=true; Game.splash&&Game.splash(p.x,p.z,Math.min(3,Math.hypot(v.x,v.y,v.z)*.08+.6)); } v.x*=.93; v.z*=.93; v.y=Math.max(v.y*.85,-3); b.angularVelocity.x*=.9; b.angularVelocity.z*=.9; if(p.y<W.WATER_Y-2.4){ b.sunk=true; } }
      else b.wet=false; return; }
    b.wet=false; if(p.y-hy<gy+.04&&v.y<1.5){ if(p.y-hy<gy){ p.y=gy+hy; if(v.y<0) v.y*=-.12; }
      /* yerde Coulomb sürtünmesi: yavaşlama = mu*g (NPC gövdesi yerde sürünür/yuvarlanır, araba tekerleğiyle daha az); ek hafif hava/yuvarlanma direnci */
      const h=Math.hypot(v.x,v.z); if(h>1e-4){ const mu=(b.collisionFilterGroup===G_CAR?.5:.8)*G0*(dt||1/60), k=Math.max(0,h-mu)/h*.99; v.x*=k; v.z*=k; }
      const a=b.angularVelocity, ad=Math.exp(-(dt||1/60)*9); a.x*=ad; a.y*=ad; a.z*=ad; } }
  /* Destek denetimi: gövdenin alt yüzü zemine (1), canlı bina parçasına/köprüye (2) dayanıyor mu, yoksa havada mı (0)?
     Kısmen yıkılmış binaların görünmez kutusu üstünde "havada donan" NPC/araba bu denetimle yakalanır. */
  const SP=[[0,0],[1,1],[-1,1],[1,-1],[-1,-1]];
  api.support=function(b){ const p=b.position, hy=hyOf(b), g=W.surfaceAt(p.x,p.z,p.y); if(p.y-hy-g<.3) return 1;
    const D=Game.D; if(!D||!D.ray) return 2; const h=b.half||[.3,.3,.3], px=h[0]*.7, pz=h[2]*.7, L=hy+.5;
    for(const o of SP){ const r=D.ray(p.x+o[0]*px,p.y,p.z+o[1]*pz,0,-1,0,L); if(r.t<L) return r.kind==="ground"?1:2; }
    return 0; };
  api.insideStatic=function(b){ const p=b.position; for(const [e] of statics){ if(e.h>0&&Math.abs(p.x-e.x)<e.hw+.3&&Math.abs(p.z-e.z)<e.hd+.3&&p.y>(e.y0||0)-.5&&p.y<e.h+.5) return true; } return false; };
  /* hayalet kip: gövde bina kutularını yok sayar, böylece boşlukta duran görünmez raftan düşer */
  api.ghost=function(b,on){ if(on){ if(b.ghost) return; b.ghost=true; b._mask=b.collisionFilterMask; b.collisionFilterMask=b._mask&~G_STATIC; if(b.wakeUp) b.wakeUp(); if(b.velocity.y>-1.5) b.velocity.y=-1.5; }
    else if(b.ghost){ b.ghost=false; b.collisionFilterMask=b._mask; if(b.wakeUp) b.wakeUp(); } };
  api.step=function(dt){ const cx=Game.heroObj?Game.heroObj.position.x:0, cz=Game.heroObj?Game.heroObj.position.z:0; stT-=dt; if(stT<=0){ stT=.5; syncStatics(cx,cz); }
    world.step(1/60,Math.min(dt,.05),3);
    for(const b of tracked){ const v=b.velocity, m=b.collisionFilterGroup===G_NPC?44:b.collisionFilterGroup===G_CAR?64:50, l2=v.x*v.x+v.y*v.y+v.z*v.z; if(l2>m*m){ const k=m/Math.sqrt(l2); v.x*=k; v.y*=k; v.z*=k; } if(!(l2===l2)){ v.set(0,0,0); } }
    if(Game.usingCannon){ const cdt=Math.min(dt,.05); for(const b of tracked) clampBody(b,cdt); }
    for(const r of pool){ if(!r.on) continue; const b=r.body; r.age+=dt;
      if(!isFinite(b.position.x)||b.position.y<-8||r.age>22||b.sunk){ release(r); continue; }
      if(b.sleepState===2||b.velocity.length()<.25) r.rest+=dt; else r.rest=0;
      if(r.rest>3.5||r.age>16) r.fade+=dt/.9; if(r.fade>=1){ release(r); continue; }
      const k=1-r.fade; dummy.position.set(b.position.x,b.position.y,b.position.z); dummy.quaternion.set(b.quaternion.x,b.quaternion.y,b.quaternion.z,b.quaternion.w); dummy.scale.set(r.sx*k,r.sy*k,r.sz*k); dummy.updateMatrix(); dMesh.setMatrixAt(r.slot,dummy.matrix); }
    dMesh.instanceMatrix.needsUpdate=true; };
  api.G0=G0; api.setGravity=s=>{ world.gravity.set(0,-G0*s,0); };
  api.activeDebris=()=>active; api.clear=()=>{ for(const r of pool) release(r); };
  Game.updaters.push(dt=>{ if(Game.mode==="play") api.step(dt); });
  return api;
})();
