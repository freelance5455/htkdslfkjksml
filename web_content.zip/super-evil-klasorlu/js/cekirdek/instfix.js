"use strict";
/* r128 KÖK HATA ÖNLEMİ: r128, malzeme programını ilk çizimde sabitler ve instanceColor var/yok değişimini izlemez. Aynı malzemeyi paylaşan örnekli meshlerden biri renk tamponsuz (instanceColor=null) çizilince
   three.js "WebGLAttributes.get(null)" hatası fırlatır ve o karenin geri kalanı (zemin, yol, gemi…) çizilmez. Çözüm: HER InstancedMesh baştan beyaz bir instanceColor taşır. */
/* v13.1: SADECE gerektiği yerde (döşemeli mesh + paylaşılan malzeme): Game.ensureIC(mesh) örnekli meshe baştan beyaz instanceColor verir.
   Küresel InstancedMesh sarmalayıcısı kaldırıldı (gerçek three.js'te doğrulanamadığı için riskliydi). */
(function(){ try{ const BA=THREE.BufferAttribute;
  Game.ensureIC=function(m){ try{ if(m&&m.instanceMatrix&&!m.instanceColor){ const a=new Float32Array(Math.max(1,m.count|0)*3); a.fill(1); m.instanceColor=new BA(a,3); } }catch(e){} return m; };
  Game.healInstances=function(root){ let n=0; try{ root.traverse(o=>{ if(o.isInstancedMesh&&!o.instanceColor){ Game.ensureIC(o); n++; } }); }catch(_){} return n; };
  /* emniyet: 5 sn'de bir sahneyi tara (sonradan eklenen renk tamponsuz örnekli meshleri onar) */
  if(Game.updaters){ let c=0; Game.updaters.push(()=>{ if((++c%300)===0&&typeof scene!=="undefined") Game.healInstances(scene); }); }
}catch(e){} })();
