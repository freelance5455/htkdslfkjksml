"use strict";
/* ===== VIP DİL MENÜSÜ: bayraklı kart ızgarası, ayarlarda ve ana menüde açılır ===== */
Game.LangUI=(function(){
  const $=id=>document.getElementById(id);
  const ENG={tr:"Turkish",en:"English",es:"Spanish",pt:"Portuguese",fr:"French",de:"German",it:"Italian",ru:"Russian",ar:"Arabic",hi:"Hindi",zh:"Chinese",ko:"Korean",ja:"Japanese"};
  const CODE={tr:"TR",en:"EN",es:"ES",pt:"PT",fr:"FR",de:"DE",it:"IT",ru:"RU",ar:"AR",hi:"HI",zh:"ZH",ko:"KO",ja:"JA"};
  const order=()=>Game.Flags.ORDER.filter(c=>LANGS[c]).concat(Object.keys(LANGS).filter(c=>!Game.Flags.ORDER.includes(c)));
  function flagEl(code){ const w=document.createElement("span"); w.className="flagw"; w.innerHTML=Game.Flags.svg(code); return w; }
  /* hidden <select> hâlâ dolu kalsın (eski kod/testler için) */
  const sel=$("langSel"); if(sel&&!(sel.options&&sel.options.length)) order().forEach(c=>{ const o=document.createElement("option"); o.value=c; o.textContent=LANGS[c].name; sel.appendChild(o); });
  function paintChips(){ const c=currentLang;
    const bf=$("langBtnFlag"); if(bf) bf.innerHTML=Game.Flags.svg(c); const bn=$("langBtnName"); if(bn) bn.textContent=LANGS[c].name; const be=$("langBtnEng"); if(be) be.textContent=ENG[c]||"";
    const mf=$("menuLangFlag"); if(mf) mf.innerHTML=Game.Flags.svg(c); const mc=$("menuLangCode"); if(mc) mc.textContent=CODE[c]||c.toUpperCase(); }
  function build(){ const g=$("langGrid"); if(!g) return; g.innerHTML="";
    order().forEach((c,i)=>{ const b=document.createElement("button"); b.type="button"; b.className="lcard"+(c===currentLang?" sel":""); b.dataset.lang=c; b.style.setProperty("--i",i);
      b.appendChild(flagEl(c));
      const nm=document.createElement("b"); nm.textContent=LANGS[c].name; b.appendChild(nm);
      const en=document.createElement("i"); en.textContent=ENG[c]||c; b.appendChild(en);
      const ck=document.createElement("span"); ck.className="lck"; ck.innerHTML='<svg viewBox="0 0 24 24"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>'; b.appendChild(ck);
      if(c==="ar") b.classList.add("rtl");
      b.onclick=()=>pick(c); g.appendChild(b); });
    const sb=$("langSub"); if(sb) sb.textContent=order().length+" · "+(ENG[currentLang]||""); }
  let closing=0;
  function open(){ build(); const m=$("langModal"); m.classList.add("on"); requestAnimationFrame(()=>m.classList.add("show")); if(Game.audio&&Game.audio.click) Game.audio.click(); }
  function close(){ const m=$("langModal"); m.classList.remove("show"); clearTimeout(closing); closing=setTimeout(()=>m.classList.remove("on"),260); }
  function pick(c){ if(Game.audio&&Game.audio.click) Game.audio.click(); document.querySelectorAll("#langGrid .lcard").forEach(b=>b.classList.toggle("sel",b.dataset.lang===c)); setLang(c); paintChips(); const sb=$("langSub"); if(sb) sb.textContent=order().length+" · "+(ENG[c]||""); setTimeout(close,320); }
  $("langBtn").onclick=open; $("menuLang").onclick=e=>{ e.stopPropagation(); open(); };
  $("langClose").onclick=()=>{ if(Game.audio&&Game.audio.click) Game.audio.click(); close(); }; $("langBack").onclick=close;
  /* ilk açılışta cihaz dili yeni eklenen dillerden biriyse onu seç (core.js bunları henüz bilmiyordu) */
  try{ if(store.get("lang",null)===null){ const nl=(navigator.language||"tr").slice(0,2); if(LANGS[nl]&&nl!==currentLang){ currentLang=nl; } } }catch(e){}
  const prevOn=Game.onLang; Game.onLang=function(){ if(prevOn) prevOn(); paintChips(); if($("langModal").classList.contains("on")) build(); };
  paintChips();
  return {open,close,pick,paint:paintChips,ENG,CODE,order};
})();
