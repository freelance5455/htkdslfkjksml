"use strict";
/* ===== REKLAM KATMANI: Android'de AdMob ödüllü reklam (Capacitor), tarayıcıda "TEST REKLAM" simülasyonu ===== */
Game.Ads=(function(){
  const C=Game.CONFIG.ads; let busy=false, inited=false, listeners=[]; const say=k=>{ if(Game.shopMsg) Game.shopMsg(k); else if(Game.toast) Game.toast(k,2400); };
  const plugin=()=>{ try{ return window.Capacitor&&window.Capacitor.Plugins&&window.Capacitor.Plugins.AdMob; }catch(e){ return null; } };
  /* Android/iOS uygulaması içinde miyiz? (Capacitor yerel kabuğu) — evet ise ASLA sahte reklam gösterilmez */
  const inApp=()=>{ try{ const c=window.Capacitor; if(!c) return false; if(typeof c.isNativePlatform==="function") return !!c.isNativePlatform(); if(typeof c.getPlatform==="function") return c.getPlatform()!=="web"; if(c.isNative===true) return true; if(typeof c.platform==="string") return c.platform!=="web"; return false; }catch(e){ return false; } };
  const api={ native:()=>!!plugin(), inApp, busy:()=>busy, shown:0 };
  function done(cb,ok,why){ busy=false; api.shown+=ok?1:0; try{ cb&&cb(ok,why); }catch(e){} }
  /* simülasyon: web/geliştirme için; açıkça "TEST REKLAM" yazar */
  function simulate(cb){ const ov=document.createElement("div"); ov.className="adsim"; ov.innerHTML='<div class="adbox"><div class="adtag"></div><div class="adbody"><div class="adlogo">▶</div><div class="adtxt"></div></div><div class="adbar"><i></i></div><button class="adbtn" disabled></button><button class="adx" aria-label="close">✕</button></div>';
    document.body.appendChild(ov); const tag=ov.querySelector(".adtag"), txt=ov.querySelector(".adtxt"), bar=ov.querySelector(".adbar i"), btn=ov.querySelector(".adbtn"), x=ov.querySelector(".adx");
    tag.textContent=t("ad_test"); let s=C.simSeconds||5, fin=false, over=false; const upd=()=>{ txt.textContent=s>0?t("ad_wait").replace("%s",s):t("ad_claim"); bar.style.width=((1-s/(C.simSeconds||5))*100)+"%"; btn.textContent=t("ad_claim"); btn.disabled=s>0; };
    upd(); const iv=setInterval(()=>{ s--; if(s<=0){ s=0; clearInterval(iv); } upd(); },1000);
    const close=ok=>{ if(over) return; over=true; clearInterval(iv); ov.remove(); if(!ok) say("ad_skip"); done(cb,ok,ok?null:"closed"); };
    btn.onclick=()=>{ if(s<=0) close(true); }; x.onclick=()=>close(s<=0); }
  async function nativeShow(cb){ const A=plugin(); let got=false, finished=false, wd=0; const finish=(ok,why)=>{ if(finished) return; finished=true; clearTimeout(wd); listeners.forEach(h=>{ try{ h&&h.remove&&h.remove(); }catch(e){} }); listeners=[]; if(!ok&&why!=="closed") say("ad_fail"); done(cb,ok,why); };
    /* takılma koruması: reklam 25 sn içinde yüklenmezse bırak (busy sonsuza kadar kilitli kalıp butonları öldürmesin) */
    wd=setTimeout(()=>finish(false,"timeout"),25000);
    try{ if(!inited){
        /* AB/Birleşik Krallık kullanıcıları için Google UMP onay formu (AdMob'da "Gizlilik ve mesajlaşma" ayarlıysa gösterilir; yoksa sessizce geçer) */
        try{ if(A.requestConsentInfo){ const ci=await A.requestConsentInfo({}); if(ci&&ci.isConsentFormAvailable&&ci.status==="REQUIRED"&&A.showConsentForm) await A.showConsentForm(); } }catch(e){}
        await A.initialize({requestTrackingAuthorization:false,initializeForTesting:!!C.useTest}); inited=true; }
      const id=C.useTest?C.testRewarded:C.rewarded;
      listeners.push(await A.addListener("onRewardedVideoAdReward",()=>{ got=true; }));
      listeners.push(await A.addListener("onRewardedVideoAdDismissed",()=>{ setTimeout(()=>finish(got,got?null:"closed"),50); }));
      listeners.push(await A.addListener("onRewardedVideoAdFailedToLoad",()=>finish(false,"load")));
      listeners.push(await A.addListener("onRewardedVideoAdFailedToShow",()=>finish(false,"show")));
      await A.prepareRewardVideoAd({adId:id,isTesting:!!C.useTest});
      clearTimeout(wd);   /* yüklendi: oynatma süresi için zaman aşımı yok (kapanış olayı bitirir) */
      const r=await A.showRewardVideoAd(); if(r&&(r.amount!==undefined||r.type!==undefined)) got=true; setTimeout(()=>finish(got,got?null:"closed"),600);
    }catch(e){ finish(false,"error"); } }
  /* ödüllü reklam göster: cb(true) = ödül hak edildi.
     • Android uygulamasında YALNIZCA gerçek AdMob reklamı gösterilir; eklenti/yükleme sorunu olursa "reklam yüklenemedi" der, asla sahte reklam göstermez.
     • Tarayıcıda (iPad Safari / .html) gerçek reklam olamaz; CONFIG.ads.webSim açıksa açıkça "TEST REKLAM" yazan simülasyon gösterilir. */
  api.show=function(cb){ if(busy) return; busy=true; if(Game.audio&&Game.audio.click) Game.audio.click();
    if(plugin()) nativeShow(cb);
    else if(inApp()||C.webSim===false){ say("ad_fail"); done(cb,false,"noplugin"); }
    else simulate(cb); };
  return api; })();
