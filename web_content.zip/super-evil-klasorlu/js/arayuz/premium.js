"use strict";
/* ===== PREMİUM: sahiplik durumu (coin ile satın alma Game.Eco üzerinden), HUD premium çubuğu ===== */
Game.Premium=(function(){
  const PW=["blackhole","orbital","tornado","nova","tsunami","void"], MPW=["chrono","reap","planet","violet","hellfire"];
  const st={skins:{},powers:{}};
  try{ const v=JSON.parse(store.get("prem","{}")); if(v&&typeof v==="object"){ st.skins=v.skins||{}; st.powers=v.powers||{}; } }catch(e){}
  const save=()=>{ try{ store.set("prem",JSON.stringify(st)); }catch(e){} };
  const api={ PW, MPW,
    hasSkin:id=>!!st.skins[id], hasPower:id=>!!st.powers[id],
    exportState:()=>JSON.parse(JSON.stringify(st)),
    importState(o){ if(!o) return; for(const k in (o.skins||{})) if(o.skins[k]) st.skins[k]=1; for(const k in (o.powers||{})) if(o.powers[k]) st.powers[k]=1; save(); api.refresh(); },
    allOwned(){ return Game.VIP_IDS.every(i=>st.skins[i])&&PW.every(p=>st.powers[p]); },
    allSkins:()=>Game.VIP_IDS.concat(Game.SUPER_IDS||[]),
    grant(kind,id){ if(kind==="all"){ Game.VIP_IDS.forEach(i=>st.skins[i]=1); PW.forEach(p=>st.powers[p]=1); } else if(kind==="skin") st.skins[id]=1; else st.powers[id]=1; save(); api.refresh(); },
    refresh(){ document.querySelectorAll("#premBar .act,#mythBar .act").forEach(b=>{ const lk=!st.powers[b.dataset.act]; b.classList.toggle("locked",lk); if(b.parentNode&&b.parentNode.classList&&b.parentNode.classList.contains("mfw")) b.parentNode.classList.toggle("locked",lk); }); } };
  /* VIP karakter sahibi değilse klasiğe dön */
  if(api.allSkins().includes(Game.char)&&!st.skins[Game.char]) Game.setCharacter("classic",0,"");
  /* HUD: taç düğmesi premium çubuğunu açıp kapatır */
  const vb=$("vipBtn"), bar=$("premBar");
  if(vb&&bar){ vb.innerHTML=Game.Icons.svg("vip");
    const tg=e=>{ e.preventDefault(); e.stopPropagation(); Game.audio.click(); const o=!bar.classList.contains("open"); bar.classList.toggle("open",o); vb.classList.toggle("on",o); try{ store.set("premOpen",o?"1":"0"); }catch(_){} };
    vb.addEventListener("touchstart",tg,{passive:false}); vb.addEventListener("mousedown",tg);
    if(store.get("premOpen","0")==="1"){ bar.classList.add("open"); vb.classList.add("on"); }
    /* kilitli güce basınca bilgi */
    bar.querySelectorAll(".act").forEach(b=>{ const f=e=>{ if(!st.powers[b.dataset.act]&&Game.toast) Game.toast("prem_locked",2600); }; b.addEventListener("touchstart",f,{passive:true}); b.addEventListener("mousedown",f); }); }
  if(bar) bar.querySelectorAll(".act").forEach(b=>{ if(!b.querySelector(".lk")) b.insertAdjacentHTML("beforeend",'<u class="lk"></u>'); });
  /* MYTHIC çubuğu: mor ateş düğmesi; premium çubuğuyla aynı yerde, biri açılınca öbürü kapanır */
  const mb=$("mythBtn"), mbar=$("mythBar");
  if(mb&&mbar){ try{ mb.innerHTML=Game.Icons.svg("myth"); }catch(e){}
    const mw=$("mythBtnW"), setO=(o)=>{ mbar.classList.toggle("open",o); mb.classList.toggle("on",o); if(mw) mw.classList.toggle("on",o); try{ store.set("mythOpen",o?"1":"0"); }catch(_){} };
    const tg2=e=>{ e.preventDefault(); e.stopPropagation(); Game.audio.click(); const o=!mbar.classList.contains("open"); setO(o); if(o&&bar){ bar.classList.remove("open"); if(vb) vb.classList.remove("on"); } };
    mb.addEventListener("touchstart",tg2,{passive:false}); mb.addEventListener("mousedown",tg2);
    if(vb&&bar){ const tg1=()=>{ if(bar.classList.contains("open")) setO(false); }; vb.addEventListener("touchstart",tg1,{passive:true}); vb.addEventListener("mousedown",tg1); }
    if(store.get("mythOpen","0")==="1"&&!(bar&&bar.classList.contains("open"))) setO(true);
    mbar.querySelectorAll(".act").forEach(b=>{ if(!b.querySelector(".lk")) b.insertAdjacentHTML("beforeend",'<u class="lk"></u>'); }); }
  /* mor ateş dilleri (tüm .mfw sarmalayıcılarına) */
  api.flames=function(root){ (root||document).querySelectorAll(".mfw").forEach(w=>{ if(w.querySelector(".fl")) return; const n=7; let h=""; for(let i=0;i<n;i++){ const a=i/n*360, up=Math.cos(a*Math.PI/180), k=(.62+.38*(up*.5+.5)).toFixed(2); h+='<i class="fl" style="--a:'+a.toFixed(0)+'deg;--k:'+k+';--d:'+(.62+((i*37)%5)*.11).toFixed(2)+'s;--dl:-'+(((i*53)%9)*.1).toFixed(1)+'s"><b></b></i>'; } w.insertAdjacentHTML("afterbegin",h); }); };
  api.flames();
  api.refresh();
  return api;
})();
