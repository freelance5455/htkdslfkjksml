"use strict";
/* ===== OPTİMİZE: kasma / donma önleme. Kare süresini ölçer, gerekirse kademe kademe sadeleştirir (çözünürlük, gölge güncelleme sıklığı, parçacık, NPC, FPS sınırı, bulanık arayüz) ===== */
Game.Opt=(function(){
const mobile=/iPad|iPhone|iPod|Android/i.test(navigator.userAgent||"")||((navigator.maxTouchPoints||0)>1&&/Mac/.test(navigator.platform||""));
/* kademe tablosu: ratio = en çok piksel oranı, cap = FPS sınırı (0 yok), sh = gölge haritası kaç karede bir yenilenir, fx/npc/traf/phys = yoğunluk çarpanı, small = küçük nesne çizim yarıçapı (m) */
const ST=[
 {ratio:9,   cap:0, sh:1, fx:1,   npc:1,   traf:1,   phys:1,   small:380, pt:300, lowfx:0, blur:1},
 {ratio:1.25,cap:60,sh:1, fx:.85, npc:1,   traf:1,   phys:1,   small:300, pt:260, lowfx:0, blur:0},
 {ratio:1.1, cap:60,sh:2, fx:.7,  npc:.85, traf:.85, phys:.8,  small:240, pt:220, lowfx:0, blur:0},
 {ratio:.95, cap:60,sh:3, fx:.5,  npc:.65, traf:.7,  phys:.6,  small:190, pt:170, lowfx:1, blur:0},
 {ratio:.8,  cap:60,sh:6, fx:.35, npc:.5,  traf:.5,  phys:.45, small:150, pt:130, lowfx:1, blur:0},
 {ratio:.65, cap:30,sh:10,fx:.25, npc:.35, traf:.35, phys:.3,  small:120, pt:100, lowfx:1, blur:0}];
const MODE_STAGE={"1":1,"2":3,"3":5,"off":0};
const MODES=["auto","1","2","3","off"];
const api={mode:(()=>{ const m=store.get("opt","auto"); return MODES.includes(m)?m:"auto"; })(),stage:0,cap:0,small:380,fps:60,worst:0,floor:0,changes:0,log:[]};
Game.fxK=1; Game.npcK=1; Game.trafK=1; Game.physK=1;
/* düşük cihaz (Game.Device.low): 3. kademeden başla, FPS 30'a sabitlenir (kararlı 30, dalgalı 45'ten iyidir), çözünürlük ≤0.85 */
const LOW=()=>!!(Game.Device&&Game.Device.low);
const baseStage=()=>LOW()?3:(mobile?1:0);
{ const sv=parseInt(store.get("opt_st","-1"),10); api.stage=api.mode==="auto"?Math.max(baseStage(),sv>=0&&sv<ST.length?Math.min(sv,3):0):(MODE_STAGE[api.mode]||0); }
const smalls=Game.smallMeshes||(Game.smallMeshes=[]);

/* ---------- kademeyi uygula ---------- */
api.apply=function(quiet){ const s=ST[api.stage], rn=Game.three&&Game.three.renderer;
  api.cap=(LOW()&&api.mode!=="off"&&(s.cap===0||s.cap>30))?30:s.cap; api.small=s.small; api.shEvery=s.sh; Game.fxK=s.fx; if(Game.FX&&Game.FX.setMaxPt) Game.FX.setMaxPt(s.pt); Game.npcK=s.npc; Game.trafK=s.traf; Game.physK=s.phys;
  if(Game.baseRatio&&Game.setRatio){ const base=Game.baseRatio(), r=Math.max(.5,Math.min(base,s.ratio,LOW()?.85:9)); if(!Game.curRatio||Math.abs(Game.curRatio-r)>.011) Game.setRatio(r); }
  if(rn&&rn.shadowMap) rn.shadowMap.autoUpdate=s.sh<=1;
  try{ document.body.classList.toggle("lowfx",!!s.lowfx); document.body.classList.toggle("noblur",!s.blur); }catch(e){}
  if(Game.NPC&&Game.NPC.setCap) Game.NPC.setCap();
  for(const t of (Game.tileMeshes||[])) if(t.sh>=0&&t.m.castShadow!==(t.sh>=api.stage)) t.m.castShadow=t.sh>=api.stage;   /* mesh düzeyinde castShadow: shader yeniden derlemesi gerektirmez */
  if(!quiet) paint(); };
function setStage(n,why){ n=Math.max(0,Math.min(ST.length-1,n)); if(n===api.stage) return; api.stage=n; api.changes++; if(api.log.length<40) api.log.push([Math.round(performance.now()/1000),n,why]); api.apply(); if(api.mode==="auto") store.set("opt_st",String(Math.min(n,3))); }
api.setStage=setStage;

/* ---------- ölçüm: her çalışan karede çağrılır (skip içinde) ---------- */
let last=0, winT=0, winN=0, winMax=0, hitch=0, bad=0, good=0, settle=2, lastUp=-999, clock0=0, modeT=0;
function windowEnd(){ const fps=winN*1000/Math.max(1,winT); api.fps=fps; api.worst=winMax; const wasHitch=hitch;
  if(settle>0){ settle--; return; }
  if(api.mode!=="auto") return;
  const target=api.cap===30?30:60, isBad=fps<target*.74||wasHitch>=2, isGood=fps>=target-3&&wasHitch===0;
  if(isBad){ good=0; bad++; if(bad>=2||fps<target*.45){ bad=0; const up=api.stage+1; if(up<ST.length){ const now=performance.now()/1000; if(now-lastUp<90) api.floor=Math.max(api.floor,api.stage); lastUp=now; setStage(up,"fps "+fps.toFixed(0)); settle=2; if(Game.toast&&up>=2) Game.toast("perf_auto",4500); } } }
  else if(isGood){ bad=0; good++; const lo=Math.max(baseStage(),api.floor); if(good>=22&&api.stage>lo){ good=0; setStage(api.stage-1,"stable"); settle=2; } }
  else { bad=0; }
  if(api.floor>0&&performance.now()/1000-lastUp>300) api.floor=0; }
api.skip=function(){ const now=performance.now(), d=now-last;
  if(api.cap>0&&!window.__noCap&&Game.mode==="play"&&last>0&&d<1000/api.cap-1.8) return true;   /* __noCap: yalnızca test düzeneği (kareler gerçek zamanlıdan hızlı koşar) */
  last=now;
  if(Game.mode==="play"&&!(typeof document!=="undefined"&&document.hidden)){ if(d>0&&d<1500){ winT+=d; winN++; if(d>winMax) winMax=d; if(d>80) hitch+=d>160?2:1; if(winT>=1000){ windowEnd(); winT=0; winN=0; winMax=0; hitch=0; } } }
  else { winT=0; winN=0; winMax=0; hitch=0; if(Game.mode!=="play") settle=Math.max(settle,1); }
  if(Game.settings&&Game.settings.fps){ const e=$("fpsTxt"); if(e&&(Game.frameN&31)===0) e.textContent=Math.round(api.fps)+" FPS · "+(Game.curRatio||0).toFixed(2)+"× · O"+api.stage+(api.mode==="auto"?"A":""); }
  return false; };
/* gölge haritası kaç karede bir yenilensin (autoUpdate kapalıyken) */
api.preRender=function(){ const rn=Game.three&&Game.three.renderer; if(!rn||!rn.shadowMap) return; if(api.shEvery>1){ rn.shadowMap.autoUpdate=false; if(((Game.frameN|0)%api.shEvery)===0) rn.shadowMap.needsUpdate=true; } else rn.shadowMap.autoUpdate=true; };

/* ---------- küçük nesne mesafe kesme: tabela, pano, direk vb. (layers ile; .visible'a dokunmaz) ---------- */
let cullT=0, cullI=0; const tiles=Game.tileMeshes||(Game.tileMeshes=[]);
Game.updaters.push(dt=>{ if(Game.mode!=="play"&&Game.mode!=="menu") return; cullT-=dt; if(cullT>0) return; cullT=.35; const c=camera.position, R2=api.small*api.small, n=smalls.length;
  if(n){ const per=Math.min(n,900); for(let k=0;k<per;k++){ const m=smalls[cullI]; cullI=(cullI+1)%n; if(!m.layers||!m.layers.set) continue; const p=m.position, dx=p.x-c.x, dz=p.z-c.z, dy=p.y-c.y, far=dx*dx+dz*dz+dy*dy*.25>R2;
      if(far!==!!m.__far){ m.__far=far; if(far) m.layers.set(1); else m.layers.set(0); } } }
  /* döşemeli statik nesneler (lamba, trafik ışığı, kaya…): sis zaten ~900 m ötesini yutuyor; kademeye göre daha yakında da gizle */
  const LIM=Math.max(260,api.small*2.2); api.tileLim=LIM; let hid=0;
  for(let k=0;k<tiles.length;k++){ const t=tiles[k], far=Math.hypot(t.cx-c.x,t.cz-c.z)-t.r>LIM; if(far) hid++; if(t.m.visible===far) t.m.visible=!far; }
  api.tilesHidden=hid; });

/* ---------- Ayarlar satırı ---------- */
const row=$("optRow");
function paint(){ if(row) row.querySelectorAll(".btn").forEach(b=>b.classList.toggle("sel",b.dataset.opt===api.mode));
  const h=$("optHint"); if(h){ const lv=t("opt_lv")+" "+api.stage; h.textContent=t("opt_hint")+" · "+(api.mode==="auto"?t("opt_auto")+": ":"")+lv; } }
api.setMode=function(m){ if(!MODES.includes(m)) return; api.mode=m; store.set("opt",m); bad=good=0; api.floor=0; settle=2;
  api.stage=m==="auto"?Math.max(baseStage(),api.stage):(MODE_STAGE[m]||0); api.changes++; api.apply(); paint(); };
if(row) row.querySelectorAll(".btn").forEach(b=>{ b.onclick=()=>{ if(Game.audio&&Game.audio.click) Game.audio.click(); api.setMode(b.dataset.opt); }; });
{ const prev=Game.refreshExtra; Game.refreshExtra=function(){ if(prev) prev(); paint(); }; }
{ const prevL=Game.onLang4; Game.onLang4=function(){ if(prevL) prevL(); paint(); }; }
api.ST=ST; api.mobile=mobile; api.base=baseStage;
api.apply(true);
return api;
})();
