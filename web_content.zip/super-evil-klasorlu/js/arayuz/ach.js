"use strict";
/* ===== BAŞARIMLAR (50) + UNVANLAR (16 rozet: 2 Ultra): yaşam boyu sayaçlar Eco kaydında (bulut yedeğine dahil). Unvanlar zordur; birden fazla ölçüt ister. ===== */
Game.Ach=(function(){
  const E=Game.Eco, S=E.S, Ev=Game.Ev, H=Game.H, $=id=>document.getElementById(id);
  const A=S.ach; A.u=A.u||{}; A.tu=A.tu||{}; A.c=A.c||{}; A.title=A.title||"";
  /* kategori: [anahtar, birim bölücü, kademeler] — yedi kategori sayaç, ikisi (chest, earn) Eco istatistiklerinden okunur */
  const CATS=[["bld",1,[10,50,150,400,1000]],["kill",1,[10,100,500,1500,5000]],["car",1,[10,50,200,600]],["gold",1,[1,5,20]],["thief",1,[3,15,50]],["rescue",1,[5,25,100]],["turb",1,[3,15]],["ran",1,[10,100]],
    ["dragon",1,[1,5]],["dchest",1,[1,3]],["ufo",1,[1,5]],["story",1,[1,3]],["dist",1000,[10,100,500]],["play",60,[30,180,600]],["space",1,[1,10]],["star3",1,[1,10]],["chest",1,[5,25,100]],["earn",1,[100000,1000000]]];
  const ROMAN=["I","II","III","IV","V"];
  const val=k=>{ if(k==="chest") return S.stats.chests||0; if(k==="earn") return S.stats.earned||0; if(k==="_ach") return api.count(); const c=CATS.find(q=>q[0]===k); return (A.c[k]||0)/(c?c[1]:1); };
  const LIST=[]; for(const [k,div,tiers] of CATS) tiers.forEach((g,i)=>LIST.push({id:k+(i+1),cat:k,i,goal:g,tier:Math.min(4,i)}));
  /* unvanlar: [id, kademe(1-5), ölçütler[[sayaç, hedef]], simge] */
  const TITLES=[
    {id:"wrecker",tier:1,ic:"hammer",req:[["bld",400],["car",50]]},
    {id:"reaper",tier:2,ic:"skull",req:[["kill",1500],["bld",150]]},
    {id:"nightmare",tier:3,ic:"flame",req:[["bld",1000],["car",200]]},
    {id:"slayer",tier:3,ic:"sword",req:[["dragon",1],["dchest",1]]},
    {id:"astro",tier:2,ic:"planet",req:[["space",10],["dist",100]]},
    {id:"ufo",tier:2,ic:"ufo",req:[["ufo",5]]},
    {id:"wanted",tier:2,ic:"star",req:[["star3",10]]},
    {id:"goldh",tier:2,ic:"coin",req:[["gold",20]]},
    {id:"rich",tier:3,ic:"gem",req:[["earn",1000000]]},
    {id:"saint",tier:3,ic:"heart",req:[["rescue",100],["kill",500]]},
    {id:"teller",tier:2,ic:"book",req:[["story",3]]},
    {id:"master",tier:3,ic:"crown",req:[["_ach",25]]},
    {id:"legend",tier:4,ic:"laurel",req:[["_ach",40]]},
    {id:"god",tier:5,ic:"bolt",req:[["_ach",50]]},
    /* ULTRA (kademe 6, kırmızı destansı): çok zor — tüm başarımlar + devasa sayaçlar */
    {id:"ultra1",tier:6,ic:"demon",req:[["_ach",50],["bld",5000],["kill",5000],["car",1000],["play",1800]]},
    {id:"ultra2",tier:6,ic:"comet",req:[["dragon",10],["ufo",25],["space",50],["star3",50],["earn",10000000],["dist",1000]]}];
  const ICONS={hammer:"M14 4l6 6-3 3-6-6zM12 9L4 17l3 3 8-8",skull:"M12 3a7 7 0 0 0-4 12.7V19h8v-3.3A7 7 0 0 0 12 3zM9.5 11.5h.01M14.5 11.5h.01M10 19v2M14 19v2",flame:"M12 3c1 4 5 5 5 10a5 5 0 0 1-10 0c0-2 1-3 2-4 0 2 1 3 2 3 0-3-1-6 1-9z",
    sword:"M4 20L18 6M14 6h4v4M6 14l4 4M3 21l3-3",planet:"M12 7a5 5 0 1 0 0 10 5 5 0 0 0 0-10zM3 16c4 3 14-2 18-8",ufo:"M3 14h18M6 14a6 6 0 0 1 12 0M8 17l-2 3M16 17l2 3M12 17v3",star:"M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.5 2.9 1-6.1L3.2 9.5l6.1-.9z",
    coin:"M12 4a8 8 0 1 0 0 16 8 8 0 0 0 0-16zM12 7v10M9.5 9.7c0-2 5-2 5 0s-5 1.6-5 3.6 5 2 5 0",gem:"M6 4h12l3 5-9 12L3 9zM3 9h18M9 4l3 5 3-5M12 9v12",heart:"M12 20s-8-5-8-11a4.5 4.5 0 0 1 8-2.5A4.5 4.5 0 0 1 20 9c0 6-8 11-8 11z",
    book:"M4 5a2 2 0 0 1 2-1h6v16H6a2 2 0 0 0-2 1zM20 5a2 2 0 0 0-2-1h-6v16h6a2 2 0 0 1 2 1z",crown:"M3 8l4 4 5-7 5 7 4-4-2 11H5z",laurel:"M12 2l2.4 4.8 5.3.8-3.8 3.7.9 5.3L12 14l-4.8 2.6.9-5.3L4.3 7.6l5.3-.8zM6 21h12",bolt:"M13 2L5 14h6l-1 8 9-13h-6z",demon:"M4 3c0 4 2 6 4 7M20 3c0 4-2 6-4 7M12 21a7 7 0 0 1-7-7c0-3 3-5 7-5s7 2 7 5a7 7 0 0 1-7 7zM9 14h.01M15 14h.01M10 17.5q2 1.2 4 0",comet:"M20 4c-6 1-11 5-13 10M20 4c-3 3-5 8-5 12M20 4c-1 5-5 9-9 11M6 15a3.5 3.5 0 1 0 5 5 3.5 3.5 0 0 0-5-5z"};
  const PAL={1:["#f0b680","#9a5a24","#4a250c","#ffd9a8"],2:["#f6f8ff","#9aa8c6","#44506e","#ffffff"],3:["#fff0a0","#e4a81a","#774804","#fff6c0"],4:["#dffcff","#52c8f0","#14609a","#ffffff"],5:["#f0b8ff","#8a2be2","#26084f","#f6dcff"],6:["#ff9a8a","#e0141c","#3a0206","#ffd9d0"]};
  let uid=0;
  function badge(tier,icon,locked,small){ const u=++uid, c=PAL[tier]||PAL[1];
    return '<svg viewBox="0 0 64 72" class="bdg t'+tier+(locked?" lk":"")+(small?" sm":"")+'" aria-hidden="true"><defs><linearGradient id="bg'+u+'" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="'+c[0]+'"/><stop offset=".55" stop-color="'+c[1]+'"/><stop offset="1" stop-color="'+c[2]+'"/></linearGradient></defs>'
     +'<path d="M32 2L59 14V40C59 56 47 66 32 70 17 66 5 56 5 40V14Z" fill="url(#bg'+u+')" stroke="'+c[3]+'" stroke-width="2.2"/><path d="M32 8L53 17.5V40C53 52 44 60 32 63.5 20 60 11 52 11 40V17.5Z" fill="none" stroke="'+c[3]+'" stroke-opacity=".55" stroke-width="1.2"/>'
     +'<g transform="translate(16 15) scale(1.33)" fill="none" stroke="#fff" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" style="filter:drop-shadow(0 1px 1px rgba(0,0,0,.55))"><path d="'+(ICONS[icon]||ICONS.star)+'"/></g>'
     +(tier===5?'<path d="M32 2L59 14M32 2L5 14" stroke="#fff" stroke-opacity=".6" stroke-width="1"/>':'')+(tier===6?'<path d="M32 2L59 14M32 2L5 14M32 70L5 40M32 70L59 40" stroke="#fff" stroke-opacity=".55" stroke-width="1"/><path d="M5 14L0 6l9 4M59 14l5-8-9 4M32 2l-4-7 4 3 4-3z" fill="#ff3b30" stroke="#ffd9d0" stroke-width="1"/>':'')+'</svg>'; }
  function medal(tier,done){ const c=PAL[tier+1]||PAL[1]; return '<svg viewBox="0 0 40 40" class="mdl'+(done?"":" lk")+'" aria-hidden="true"><circle cx="20" cy="20" r="17" fill="'+c[1]+'" stroke="'+c[3]+'" stroke-width="2.4"/><circle cx="20" cy="20" r="12" fill="none" stroke="'+c[0]+'" stroke-width="1.4" opacity=".8"/>'+(done?'<path d="M12 21l5 5 11-12" stroke="#fff" stroke-width="3.4" fill="none" stroke-linecap="round" stroke-linejoin="round"/>':'<path d="M20 11v18M11 20h18" stroke="'+c[3]+'" stroke-opacity=".5" stroke-width="2" stroke-linecap="round"/>')+'</svg>'; }
  const fmt=n=>{ n=Math.floor(n); return n>=1e6?(n/1e6).toFixed(n%1e6?1:0)+"M":n>=1e4?(n/1e3).toFixed(n%1e3?1:0)+"K":String(n).replace(/\B(?=(\d{3})+(?!\d))/g,"."); };
  const descOf=(k,n)=>t("ach_d_"+k).replace("{n}",fmt(n));
  const api={LIST,TITLES,CATS,badge,medal};
  api.count=()=>{ let n=0; for(const a of LIST) if(A.u[a.id]) n++; return n; };
  api.value=val; api.reqText=ti=>ti.req.map(r=>descOf(r[0]==="_ach"?"total":r[0],r[1])).join("  +  ");
  api.titleName=id=>t("ach_t_"+id); api.titleText=()=>A.title&&A.tu[A.title]?t("ach_t_"+A.title):"";
  api.setTitle=id=>{ if(id===""||A.tu[id]){ A.title=id; E.save(); try{ E.flush(); }catch(e){} if(Game.Profile) Game.Profile.refreshMenu(); } };
  /* ---- sayaç artışı ---- */
  const bump=(k,n)=>{ A.c[k]=(A.c[k]||0)+(n===undefined?1:n); dirty=true; };
  let dirty=false, chkT=0, saveT=0;
  Ev.on("building",()=>bump("bld")); Ev.on("npcKill",(n)=>{ if(n&&n._ach) return; if(n) n._ach=true; bump("kill"); if(n&&n.golden) bump("gold"); });
  Ev.on("carDestroyed",()=>bump("car")); Ev.on("thiefCaught",()=>bump("thief")); Ev.on("npcRescued",()=>bump("rescue")); Ev.on("turbineBroken",()=>bump("turb")); Ev.on("playerRanOver",(n)=>{ if(n&&n._ran) return; if(n) n._ran=true; bump("ran"); });
  Ev.on("dragonSlain",()=>bump("dragon")); Ev.on("chestOpened",()=>bump("dchest")); Ev.on("ufoDown",()=>bump("ufo")); Ev.on("storyEnd",()=>bump("story"));
  let wasSpace=false, wasStar=0, hasP=false; const pp={x:0,y:0,z:0};
  /* ---- açılış bildirimi ---- */
  let bn=null, q=[], bt=0;
  function banner(kind,tier,icon,name,sub){ q.push({kind,tier,icon,name,sub}); if(!bn) mk(); if(bt<=0) pump(); }
  function mk(){ const hud=$("hud")||document.body; bn=document.createElement("div"); bn.id="achBanner"; hud.appendChild(bn); }
  function pump(){ const it=q.shift(); if(!it){ bn.classList.remove("on"); return; } bt=3.6;
    bn.innerHTML='<div class="abi">'+(it.kind==="title"?badge(it.tier,it.icon,false,true):medal(it.tier,true))+'</div><div class="abt"><small>'+it.sub+'</small><b></b></div>'; bn.querySelector("b").textContent=it.name; bn.classList.toggle("ultra",it.tier===6&&it.kind==="title"); bn.classList.add("on"); if(Game.audio){ (Game.audio.buy||Game.audio.coin||function(){})(); } }
  /* ---- denetim ---- */
  function check(){ let any=false;
    for(const a of LIST){ if(A.u[a.id]) continue; if(val(a.cat)>=a.goal){ A.u[a.id]=Date.now(); any=true; banner("ach",a.tier,null,t("ach_n_"+a.cat)+" "+ROMAN[a.i],t("ach_unlocked")); Ev.emit("achievement",a.id); } }
    for(const ti of TITLES){ if(A.tu[ti.id]) continue; if(ti.req.every(r=>val(r[0])>=r[1])){ A.tu[ti.id]=Date.now(); any=true; banner("title",ti.tier,ti.ic,t("ach_t_"+ti.id),t("ach_newtitle")); if(!A.title) A.title=ti.id; Ev.emit("titleUnlocked",ti.id); } }
    if(any||dirty){ dirty=false; E.save(); try{ E.flush(); }catch(e){} if(any&&Game.Profile) Game.Profile.refreshMenu(); } }
  api.check=check;
  Game.updaters.push((dt0,time,raw)=>{ const dt=Math.min(raw||dt0,.1); const play=Game.mode==="play";
    if(bt>0){ bt-=dt; if(bt<=0&&bn) pump(); }
    if(play){ A.c.play=(A.c.play||0)+dt; const driving=Game.Mounted&&Game.Mounted(), hp=Game.heroObj.position; if(hasP&&!driving&&H.flying){ const dd=Math.hypot(hp.x-pp.x,hp.y-pp.y,hp.z-pp.z); if(dd>.01&&dd<120) A.c.dist=(A.c.dist||0)+dd; } pp.x=hp.x; pp.y=hp.y; pp.z=hp.z; hasP=true; dirty=true;
      const sp=Game.Space&&Game.Space.t>.85; if(sp&&!wasSpace) bump("space"); wasSpace=!!sp; const st=Game.Police?Game.Police.stars:0; if(st>=3&&wasStar<3) bump("star3"); wasStar=st; } else { wasSpace=false; wasStar=0; hasP=false; }
    chkT-=dt; if(chkT<=0){ chkT=1; if(play||dirty) check(); } });
  /* ---- arayüz (profil sekmeleri) ---- */
  const el=(tg,cl,tx)=>{ const e=document.createElement(tg); if(cl) e.className=cl; if(tx!==undefined) e.textContent=tx; return e; };
  api.titleChip=function(){ const id=A.title; if(!id||!A.tu[id]) return null; const ti=TITLES.find(x=>x.id===id); const c=el("div","tchip t"+ti.tier); c.innerHTML=badge(ti.tier,ti.ic,false,true); c.appendChild(el("span",null,t("ach_t_"+id))); return c; };
  api.render=function(body,tab,again){
    if(tab==="titles"){ const head=el("div","achhead"); head.appendChild(el("b",null,t("ach_titles_h"))); head.appendChild(el("span",null,Object.keys(A.tu).length+"/"+TITLES.length)); body.appendChild(head); body.appendChild(el("div","achnote",t("ach_titles_note")));
      const g=el("div","ttlgrid");
      for(const ti of TITLES){ const own=!!A.tu[ti.id], eq=A.title===ti.id, c=el("div","ttl t"+ti.tier+(own?" own":" lk")+(eq?" eq":"")); const bd=el("div","tbd"); bd.innerHTML=badge(ti.tier,ti.ic,!own); c.appendChild(bd);
        const x=el("div","ttx"); x.appendChild(el("b",null,own?t("ach_t_"+ti.id):(ti.tier===6?"??? ULTRA":"???"))); if(ti.tier===6) x.appendChild(el("em","ultag","ULTRA · "+t("ach_ultra_hard"))); x.appendChild(el("span","req",api.reqText(ti)));
        const pr=el("div","rp"); for(const r of ti.req){ const v=Math.min(val(r[0]),r[1]), f=Math.max(0,Math.min(1,v/r[1])); const row=el("i"); row.style.setProperty("--f",(f*100).toFixed(0)+"%"); pr.appendChild(row); } x.appendChild(pr); c.appendChild(x);
        if(own){ const b=el("button","pbtn "+(eq?"own":"buy"),eq?t("ach_equipped"):t("ach_equip")); b.onclick=()=>{ Game.audio.click(); api.setTitle(eq?"":ti.id); again(); }; c.appendChild(b); } else { c.appendChild(el("div","lockic","🔒")); }
        g.appendChild(c); } body.appendChild(g); return; }
    const head=el("div","achhead"); head.appendChild(el("b",null,t("ach_h"))); head.appendChild(el("span",null,api.count()+"/"+LIST.length)); body.appendChild(head);
    const tb=el("div","achtot"); const f=el("i"); f.style.width=(api.count()/LIST.length*100)+"%"; tb.appendChild(f); body.appendChild(tb);
    const g=el("div","achgrid");
    for(const a of LIST){ const own=!!A.u[a.id], v=val(a.cat), c=el("div","ach t"+a.tier+(own?" own":""));
      const m=el("div","am"); m.innerHTML=medal(a.tier,own); c.appendChild(m); const x=el("div","ax"); x.appendChild(el("b",null,t("ach_n_"+a.cat)+" "+ROMAN[a.i])); x.appendChild(el("span",null,descOf(a.cat,a.goal)));
      const pb=el("div","apb"); const pf=el("i"); pf.style.width=Math.min(100,v/a.goal*100)+"%"; pb.appendChild(pf); x.appendChild(pb); const nums=el("em",null,own?"✓":fmt(Math.min(v,a.goal))+" / "+fmt(a.goal)); x.appendChild(nums); c.appendChild(x); g.appendChild(c); }
    body.appendChild(g); };
  api.ready=true; return api; })();
