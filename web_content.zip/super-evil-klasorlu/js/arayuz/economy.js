"use strict";
/* ===== EKONOMİ: coin, fiyat listesi, satın alma, günlük limitler, 2x boost, deneme kartı, sandık ödülleri ===== */
Game.Eco=(function(){
  const Ev=Game.Ev;
  /* ---- fiyat listesi ---- */
  const CAT={
    chars:{ classic:{p:0}, pharaoh:{p:500,ad:2}, poseidon:{p:600,ad:2}, zeus:{p:700,ad:2}, ninja:{p:900}, knight:{p:1100}, viking:{p:1300}, samurai:{p:1600}, astro:{p:1900}, robot:{p:2200}, wizard:{p:2600}, dragon:{p:3000} },
    powers:{ fly:{p:0}, laser:{p:0}, choke:{p:0}, clap:{p:0}, punch:{p:0}, freeze:{p:200,ad:1}, fire:{p:250,ad:1}, lightning:{p:300,ad:1}, meteor:{p:350}, gravity:{p:400}, timeslow:{p:420}, quake:{p:450} },
    vip:{ void:{p:20000}, inferno:{p:30000}, frost:{p:30000}, storm:{p:50000}, seraph:{p:70000} },
    spr:{ kronos:{p:100000}, nekro:{p:150000}, kozmos:{p:200000}, neondrake:{p:175000}, altin:{p:300000} },
    vpow:{ blackhole:{p:5000}, orbital:{p:7000}, tornado:{p:9000}, nova:{p:12000}, tsunami:{p:15000} },
    mpow:{ violet:{p:30000}, hellfire:{p:45000} },
    chests:{ bronze:{p:250,max:1000}, silver:{p:500,max:5000}, gold:{p:1000,max:10000}, diamond:{p:2500,max:30000}, cyber:{p:5000,max:75000} } };
  /* sandık ödül tabloları [coin, ağırlık]. Beklenen değer fiyatın biraz altında; en büyük ödül en düşük olasılık. */
  const ODDS={
    bronze:[[125,30],[175,27],[225,20],[300,12],[450,6.5],[700,3.5],[1000,1]],
    silver:[[250,34],[350,28],[450,20],[700,10],[1200,5],[2000,2.5],[5000,.5]],
    gold:[[500,32],[700,26],[900,20],[1300,12],[2000,6],[3500,3],[6000,.8],[10000,.2]],
    diamond:[[1250,31],[1750,26],[2250,19],[3000,12],[4500,7],[7500,3.3],[12000,1.4],[30000,.3]],
    cyber:[[2500,32],[3500,27],[4500,19],[6000,11],[9000,6.5],[15000,3.2],[30000,1],[75000,.3]] };
  const ev=k=>{ const o=ODDS[k]; let w=0,s=0; for(const r of o){ w+=r[1]; s+=r[0]*r[1]; } return s/w; };
  const FREE_POWERS=["fly","laser","choke","clap","punch"];
  const today=()=>{ const d=new Date(); return d.getFullYear()+"-"+(d.getMonth()+1)+"-"+d.getDate(); };
  const S={ coins:0, chars:{classic:1}, powers:{}, prog:{}, day:today(), lim:{c500:0,chest:0,boost:0,trial:0}, boostUntil:0, trial:null, daily:{last:"",streak:0}, stats:{earned:0,spent:0,chests:0,ads:0}, profile:{name:"",avatar:"hero"}, ach:{u:{},tu:{},c:{},title:""}, social:{ig:0,yt:0,t:{}} };
  const hash=o=>{ const s=JSON.stringify(o)+"SE9k"; let h=2166136261; for(let i=0;i<s.length;i++){ h^=s.charCodeAt(i); h=Math.imul(h,16777619); } return (h>>>0).toString(36); };
  function load(){ try{ const raw=store.get("eco",""); if(!raw) return; const o=JSON.parse(raw); if(!o||!o.d) return; if(o.h&&o.h!==hash(o.d)){ /* oynanmış kayıt: sıfırlamak yerine uyar ama kabul et */ } const d=o.d; for(const k of Object.keys(S)) if(d[k]!==undefined) S[k]=(typeof S[k]==="object"&&S[k]&&!Array.isArray(S[k]))?Object.assign(S[k],d[k]):d[k]; }catch(e){} S.chars.classic=1; }
  let dirty=false, saveT=0;
  function save(){ dirty=true; }
  function flush(){ if(!dirty) return; dirty=false; try{ store.set("eco",JSON.stringify({d:S,h:hash(S)})); }catch(e){} if(api.onSave) api.onSave(S); }
  load(); rollDay();
  function rollDay(){ const d=today(); if(S.day!==d){ S.day=d; S.lim={c500:0,chest:0,boost:0,trial:0}; save(); } }
  const api={ S, CAT, ODDS, FREE_POWERS, today, ev, flush, save,
    get coins(){ return S.coins; },
    boosted(){ return S.boostUntil>Date.now(); },
    mult(){ return api.boosted()?2:1; },
    /* kazanç: kaynak etiketi popup için */
    add(n,src,x,z){ if(!(n>0)) return 0; n=Math.round(n*api.mult()); S.coins+=n; S.stats.earned+=n; save(); Ev.emit("coins",n,src,x,z); return n; },
    spend(n){ if(S.coins<n) return false; S.coins-=n; S.stats.spent+=n; save(); Ev.emit("coins",-n,"spend"); return true; },
    /* sahiplik */
    hasChar(id){ const c=CAT.chars[id]; return !c||c.p===0||!!S.chars[id]; },
    hasPower(id){ if(FREE_POWERS.includes(id)) return true; const c=CAT.powers[id]; if(c) return !!S.powers[id]||!!(S.trial&&S.trial.p===id&&S.trial.until>Date.now()); const P=Game.Premium; return P?P.hasPower(id):true; },
    hasVip(id){ return Game.Premium?Game.Premium.hasSkin(id):false; },
    price(kind,id){ const c=CAT[kind]&&CAT[kind][id]; return c?c.p:0; },
    canAfford(n){ return S.coins>=n; },
    /* satın alma: coin ile */
    buy(kind,id){ const c=CAT[kind]&&CAT[kind][id]; if(!c) return {ok:false,why:"unknown"};
      if(kind==="chars"){ if(api.hasChar(id)) return {ok:false,why:"owned"}; }
      else if(kind==="powers"){ if(S.powers[id]) return {ok:false,why:"owned"}; }
      else if(kind==="vip"||kind==="spr"){ if(Game.Premium.hasSkin(id)) return {ok:false,why:"owned"}; }
      else if(kind==="vpow"||kind==="mpow"){ if(Game.Premium.hasPower(id)) return {ok:false,why:"owned"}; }
      if(!api.spend(c.p)) return {ok:false,why:"coins",need:c.p-S.coins};
      api.grant(kind,id); Ev.emit("purchase",kind,id); return {ok:true}; },
    grant(kind,id){ if(kind==="chars") S.chars[id]=1; else if(kind==="powers") S.powers[id]=1;
      else if(kind==="vip"||kind==="spr"){ Game.Premium.grant("skin",id); const own=Game.SKIN_POWER&&Game.SKIN_POWER[id]; if(own) Game.Premium.grant("power",own); }
      else if(kind==="vpow"||kind==="mpow") Game.Premium.grant("power",id);
      save(); flush(); if(api.onGrant) api.onGrant(kind,id); },
    /* reklamla ilerleme (ör. 2 reklam = 1 skin) */
    adProgress(kind,id){ const k=kind+"_"+id; return S.prog[k]||0; },
    adStep(kind,id){ const c=CAT[kind]&&CAT[kind][id]; if(!c||!c.ad) return null; const k=kind+"_"+id; S.prog[k]=(S.prog[k]||0)+1; S.stats.ads++; let done=false; if(S.prog[k]>=c.ad){ delete S.prog[k]; api.grant(kind,id); done=true; Ev.emit("purchase",kind,id); } save(); flush(); return {done,have:S.prog[k]||0,need:c.ad}; },
    /* günlük limitli ödül reklamları */
    left(k,max){ rollDay(); return Math.max(0,max-(S.lim[k]||0)); },
    LIM:{c500:3,chest:2,boost:3,trial:3},
    rewardAd(k){ rollDay(); if((S.lim[k]||0)>=api.LIM[k]) return false; S.lim[k]=(S.lim[k]||0)+1; S.stats.ads++;
      if(k==="c500") api.add(500,"ad"); else if(k==="boost"){ S.boostUntil=Math.max(Date.now(),S.boostUntil)+15*60*1000; Ev.emit("boost"); }
      else if(k==="chest"){ /* sandık açılışı UI tarafında */ }
      else if(k==="trial"){ const locked=Object.keys(CAT.powers).filter(p=>CAT.powers[p].p>0&&!S.powers[p]); if(locked.length){ const p=locked[(Math.random()*locked.length)|0]; S.trial={p,until:Date.now()+5*60*1000}; Ev.emit("trial",p); } }
      save(); flush(); return true; },
    /* sandık */
    roll(tier){ const o=ODDS[tier]; let w=0; for(const r of o) w+=r[1]; let x=Math.random()*w; for(const r of o){ x-=r[1]; if(x<=0) return r[0]; } return o[0][0]; },
    openChest(tier,free){ const c=CAT.chests[tier]; if(!c) return null; if(!free&&!api.spend(c.p)) return null; const n=api.roll(tier); S.coins+=n; S.stats.earned+=n; S.stats.chests++; save(); flush(); Ev.emit("coins",n,"chest"); return n; },
    /* günlük hediye (reklamsız): seri arttıkça büyür */
    dailyReady(){ return S.daily.last!==today(); },
    dailyAmount(){ const st=Math.min(6,S.daily.streak); return 100+st*50; },
    claimDaily(){ if(!api.dailyReady()) return 0; const y=new Date(Date.now()-864e5), ys=y.getFullYear()+"-"+(y.getMonth()+1)+"-"+y.getDate(); S.daily.streak=S.daily.last===ys?S.daily.streak+1:0; S.daily.last=today(); const n=api.dailyAmount(); S.daily.streakShown=S.daily.streak; const g=api.add(n,"daily"); save(); flush(); return g; },
    /* bulut kaydı için toplu al/ver */
    /* sosyal medya takip ödülü: bağlantı açıldıktan sonra bir kez 10.000 coin (takip edildiği doğrulanamaz; dürüstlük + bekleme süresi) */
    SOCIAL:{ ig:{url:"https://www.instagram.com/notexthife?cplk=MWZuNDFqYzRiNGYybQ==",coin:10000}, yt:{url:"https://youtube.com/@notexthife?si=rTBs8sQlCbLabWS4",coin:10000} },
    socialOpen(k){ const c=api.SOCIAL[k]; if(!c) return false; if(!S.social.t) S.social.t={}; if(!S.social.t[k]) S.social.t[k]=Date.now(); save(); flush(); return true; },
    socialReady(k){ return !S.social[k]&&!!(S.social.t&&S.social.t[k])&&Date.now()-S.social.t[k]>=12000; },
    claimSocial(k){ const c=api.SOCIAL[k]; if(!c||S.social[k]||!api.socialReady(k)) return 0; S.social[k]=1; S.coins+=c.coin; S.stats.earned+=c.coin; save(); flush(); Ev.emit("coins",c.coin,"social"); return c.coin; },
    exportState(){ return JSON.parse(JSON.stringify(S)); },
    importState(o){ if(!o||typeof o!=="object") return; for(const k of Object.keys(S)) if(o[k]!==undefined){ if(k==="coins") S.coins=Math.max(S.coins,o.coins|0); else if(k==="chars"||k==="powers"||k==="prog") Object.assign(S[k],o[k]); else if(k==="ach"){ const a=o.ach||{}; for(const id in (a.u||{})) if(!S.ach.u[id]) S.ach.u[id]=a.u[id]; for(const id in (a.tu||{})) if(!S.ach.tu[id]) S.ach.tu[id]=a.tu[id]; for(const id in (a.c||{})) S.ach.c[id]=Math.max(S.ach.c[id]||0,+a.c[id]||0); if(!S.ach.title&&a.title) S.ach.title=a.title; } else if(k==="social"){ const a=o.social||{}; if(a.ig) S.social.ig=1; if(a.yt) S.social.yt=1; } else if(k==="stats"||k==="profile"||k==="daily"||k==="lim") { if(k==="stats"&&o.stats){ for(const q of ["earned","spent","chests","ads"]) S.stats[q]=Math.max(S.stats[q]||0,+o.stats[q]||0); } if(k==="profile"){ if(!S.profile.name&&o.profile) Object.assign(S.profile,o.profile); } } } S.chars.classic=1; save(); flush(); Ev.emit("coins",0,"sync"); }
  };
  /* ---- kazanç olayları ---- */
  Ev.on("building",(bl,x,z)=>api.add(30,"building",x,z));
  Ev.on("npcKill",(n,cause)=>{ if(n._paid) return; n._paid=true; api.add(n.golden?200:20,n.golden?"gold":"npc",n.x,n.z); });
  Ev.on("carDestroyed",(k,i,x,z)=>api.add(10,"car",x,z));
  Ev.on("turbineBroken",T=>api.add(30,"building",T.x,T.z));
  Game.updaters.push(dt=>{ saveT-=dt; if(saveT<=0){ saveT=2; flush(); } });
  addEventListener("pagehide",flush); addEventListener("beforeunload",flush); document.addEventListener("visibilitychange",()=>{ if(document.hidden) flush(); });
  if(!api.hasChar(Game.char)&&Game.setCharacter) Game.setCharacter("classic",0,"");
  return api; })();
