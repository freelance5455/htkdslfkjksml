"use strict";
/* ===== EKRANA UYUM: HUD'u görünür alana göre tek bir ölçekle (--ui) büyütür/küçültür. Referans düzen 820×390 mantıksal px;
   daha küçük ekranda küçülür, büyükte büyür → tuşlar hiçbir cihazda üst üste binmez, kaymaz, sıkıştırmaz. ===== */
(function(){ const root=document.documentElement; let last=0;
  function apply(){ const w=innerWidth||820, h=innerHeight||390, u=Math.min(w/820,h/390), ui=Math.max(.62,Math.min(1.35,u));
    if(Math.abs(ui-last)>.004){ last=ui; root.style.setProperty("--ui",ui.toFixed(3)); } }
  apply(); addEventListener("resize",apply); addEventListener("orientationchange",()=>setTimeout(apply,150));
  Game.layoutApply=apply; Game.layoutUi=()=>last; })();
