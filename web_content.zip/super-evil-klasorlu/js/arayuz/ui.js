"use strict";
/* ===== ARAYÜZ: ekranlar, yeni mağaza (Karakterler / Güçler / Renkler), HUD butonları ===== */
const SCREENS=["menu","shop","settings","maps","pauseP","custom","profile"], POWER_ICON={fly:"🚀",punch:"👊",choke:"🫳",clap:"👏",laser:"👁️",freeze:"❄️",fire:"🔥",meteor:"☄️",lightning:"🌩️",gravity:"🌀",timeslow:"⏳",quake:"🌋"}, NEWP=["meteor","lightning","gravity","timeslow","quake"];
const ACCENTS=["#e63946","#ff7a29","#f1c40f","#2ecc71","#16d9d9","#1d6fe0","#9b59b6","#ff5da2","#f2f2f2","#222222","#8b5a2b","#c9a227"];
function show(id){ SCREENS.forEach(s=>$(s).classList.toggle("on", s===id)); }
function resetActions(){ for(const k in Game.input.actions) Game.input.actions[k]=false; document.querySelectorAll(".act").forEach(b=>b.classList.remove("down")); }
/* enterMode → entermode.js (erken yüklenir: extras.js onu sarmalar) */
$("btnPlay").onclick=()=>{ try{ if(screen.orientation&&screen.orientation.lock) screen.orientation.lock("landscape").catch(()=>{}); }catch(e){} Game.audio.click(); const f0=Game.frameN||0; Game.Loading.run(()=>{ if(Game.Story) Game.Story.off(); enterMode("play"); try{ if(Game.three&&Game.three.renderer&&Game.three.renderer.compile) Game.three.renderer.compile(scene,camera); }catch(e){} },{min:2800,until:()=>(Game.frameN||0)-f0>=30}); };
$("btnStory").onclick=()=>{ try{ if(screen.orientation&&screen.orientation.lock) screen.orientation.lock("landscape").catch(()=>{}); }catch(e){} Game.audio.click(); const f0=Game.frameN||0; Game.Loading.run(()=>{ enterMode("play"); if(Game.Story) Game.Story.begin(); try{ if(Game.three&&Game.three.renderer&&Game.three.renderer.compile) Game.three.renderer.compile(scene,camera); }catch(e){} },{min:2800,until:()=>(Game.frameN||0)-f0>=30}); };
$("btnShop").onclick=()=>{ Game.audio.unlock(); Game.audio.click(); show("shop"); renderShop(); };
let settingsFrom="menu";
function openSettings(from){ settingsFrom=from; show("settings"); refreshSettings(); }
$("btnSettings").onclick=()=>{ Game.audio.unlock(); Game.audio.click(); openSettings("menu"); };
$("btnPauseSettings").onclick=()=>{ Game.audio.click(); openSettings("pauseP"); };
$("btnSetBack").onclick=()=>{ Game.audio.click(); show(settingsFrom); if(settingsFrom==="menu") refreshChips(); };
$("pauseBtn").onclick=()=>enterMode("pause"); $("btnResume").onclick=()=>enterMode("play"); $("btnMain").onclick=()=>{ Game.audio.click(); const f0=Game.frameN||0; Game.Loading.run(()=>{ if(Game.Drive&&Game.Drive.active) Game.Drive.exit(true); if(Game.Ride&&Game.Ride.active) Game.Ride.exit(true); enterMode("menu"); },{min:2200,until:()=>(Game.frameN||0)-f0>=20}); };
document.querySelectorAll("[data-back]").forEach(b=>b.onclick=()=>{ Game.audio.click(); show("menu"); refreshChips(); });
document.querySelectorAll("#qualRow .btn").forEach(b=>b.onclick=()=>setQuality(b.dataset.q));
Object.keys(LANGS).forEach(code=>{ const o=document.createElement("option"); o.value=code; o.textContent=LANGS[code].name; $("langSel").appendChild(o); });
$("langSel").onchange=e=>setLang(e.target.value);

/* --- karakter önizlemeleri: küçük ayrı renderer ile bir kez çizilip görsele çevrilir --- */
const PV={r:null,scene:null,cam:null,cache:{}};
function previewFor(id,skin,accent){ const key=id+"|"+skin+"|"+(accent||""); if(PV.cache[key]) return PV.cache[key];
  try{ if(!PV.r){ PV.r=new THREE.WebGLRenderer({antialias:!(Game.Device&&Game.Device.low),alpha:true,preserveDrawingBuffer:true}); PV.r.setSize(300,380); PV.r.outputEncoding=THREE.sRGBEncoding;
      PV.scene=new THREE.Scene(); PV.scene.add(new THREE.HemisphereLight(0xffffff,0x556070,1.05)); const dl=new THREE.DirectionalLight(0xffffff,1.35); dl.position.set(3,5,6); PV.scene.add(dl); const rim=new THREE.DirectionalLight(0x9fc4ff,.6); rim.position.set(-4,2,-5); PV.scene.add(rim);
      PV.cam=new THREE.PerspectiveCamera(33,300/380,.1,50); PV.cam.position.set(0,.35,6.6); PV.cam.lookAt(0,.28,0); }
    const m=buildHeroModel(id,skin,accent); if(Game.Anim) Game.Anim.preview(m); m.rotation.y=-.5; PV.scene.add(m); PV.r.render(PV.scene,PV.cam); const url=PV.r.domElement.toDataURL("image/png"); PV.scene.remove(m); PV.cache[key]=url;
    /* ikinci WebGL bağlamı yalnızca önizleme sürerken tutulur: bittikten ~3 sn sonra serbest bırakılır (düşük bellekli cihazlarda GPU belleği ve bağlam sınırı için) */
    clearTimeout(PV.t); PV.t=setTimeout(()=>{ try{ if(PV.r){ PV.r.dispose(); if(PV.r.forceContextLoss) PV.r.forceContextLoss(); } }catch(e){} PV.r=null; PV.scene=null; PV.cam=null; },3000);
    return url;
  }catch(e){ return ""; } }
function fillPreviews(){ const imgs=[...document.querySelectorAll("#sbody img[data-pv]")]; let i=0; (function next(){ if(i>=imgs.length) return; const im=imgs[i++]; const [id,sk,ac]=im.dataset.pv.split("|"); im.src=previewFor(id,+sk,ac||null); setTimeout(next,20); })(); }

let shopTab="chars";
const VIP_COL={void:"rgba(140,90,255,.3)",inferno:"rgba(255,90,20,.32)",frost:"rgba(120,200,255,.32)",storm:"rgba(80,140,255,.32)",seraph:"rgba(255,220,120,.34)"}, PW_CD={blackhole:30,orbital:26,tornado:28,nova:34,tsunami:40,void:60,chrono:55,reap:50,planet:45,violet:30,hellfire:38}, vipSkinSel={};
const hex6=n=>"#"+("000000"+(n>>>0).toString(16)).slice(-6);
function el(tag,cls,txt){ const e=document.createElement(tag); if(cls) e.className=cls; if(txt!==undefined) e.textContent=txt; return e; }
/* renderShop / renderPremium → shop.js */
document.querySelectorAll("#shop .tab").forEach(b=>b.onclick=()=>{ shopTab=b.dataset.tab; Game.audio.click(); renderShop(); });
function applyPowers(){ document.querySelectorAll(".act").forEach(b=>b.classList.toggle("off",Game.powersOn[b.dataset.act]===false)); }
Game.onLang=()=>{ refreshLogo(); refreshSettings(); refreshChips(); if($("shop").classList.contains("on")) renderShop(); if($("maps").classList.contains("on")) renderMaps(); markCensor(); markCam(); if(Game.onLang2) Game.onLang2(); if(Game.onLang4) Game.onLang4(); if(Game.onZoneLang) Game.onZoneLang(); };

/* --- HUD aksiyon butonları (çoklu dokunma, görsel tepki) --- */
document.querySelectorAll(".act").forEach(b=>{ const name=b.dataset.act;
  const on=e=>{ e.preventDefault(); b.classList.add("down"); Game.input.actions[name]=true; if(Game.settings.vib&&navigator.vibrate) navigator.vibrate(12); };
  const off=e=>{ e.preventDefault(); b.classList.remove("down"); Game.input.actions[name]=false; };
  b.addEventListener("touchstart",on,{passive:false}); b.addEventListener("touchend",off,{passive:false}); b.addEventListener("touchcancel",off,{passive:false});
  b.addEventListener("mousedown",on); b.addEventListener("mouseup",off); b.addEventListener("mouseleave",off); });
["gesturestart","gesturechange","gestureend"].forEach(ev=>document.addEventListener(ev,e=>e.preventDefault()));
document.addEventListener("touchmove",e=>{ if(e.target.closest&&e.target.closest(".sbody,.panel,.lgrid,.lpanel,.scrollable")) return; e.preventDefault(); },{passive:false});

/* ===== v4: kamera (arkadan / göz görüşü), +18 sansür, harita seçimi ===== */
function markCam(){ const fp=Game.settings.cam==="1p"; document.querySelectorAll("#camRow .btn").forEach(b=>b.classList.toggle("sel",b.dataset.cam===Game.settings.cam)); const cb=$("camBtn"); if(cb) cb.textContent=fp?"👁️":"🎥"; }
function setCam(m,quiet){ Game.settings.cam=m==="1p"?"1p":"3p"; store.set("cam",Game.settings.cam); markCam(); if(!quiet&&Game.toast) Game.toast(m==="1p"?"cam_t1":"cam_t3",1400); }
document.querySelectorAll("#camRow .btn").forEach(b=>b.onclick=()=>{ Game.audio.click(); setCam(b.dataset.cam,true); });
{ const cb=$("camBtn"); const tg=e=>{ e.preventDefault(); e.stopPropagation(); Game.audio.click(); setCam(Game.settings.cam==="1p"?"3p":"1p"); }; cb.addEventListener("touchstart",tg,{passive:false}); cb.addEventListener("mousedown",tg); }
function markCensor(){ const on=Game.settings.censor; document.querySelectorAll("#censorRow .btn").forEach(b=>b.classList.toggle("sel",(b.dataset.cen==="1")===on)); const h=$("censorHint"); if(h) h.textContent=t(on?"censor_on":"censor_off"); }
function setCensor(on){ if(on===Game.settings.censor) return;
  if(!on){ let ok=true; try{ ok=confirm(t("censor_warn")); }catch(e){} if(!ok) return; }
  Game.settings.censor=on; store.set("censor",on?"1":"0");
  if(on){ if(Game.Gore) Game.Gore.clear(); if(Game.NPC&&Game.NPC.clearGibs) Game.NPC.clearGibs(); }
  markCensor(); }
document.querySelectorAll("#censorRow .btn").forEach(b=>b.onclick=()=>{ Game.audio.click(); setCensor(b.dataset.cen==="1"); });
markCam(); markCensor();

/* harita kartları: gökyüzü + silüet küçük resmi (tuvalle çizilir) */
const MAP_SKY={day:["#4f93e0","#bcd9f5"],sunset:["#3b4a8f","#ff9a55"],night:["#0a0820","#4a2a78"]};
function mapThumb(m){ const W=300,H=170,c=document.createElement("canvas"); c.width=W; c.height=H; const q=c.getContext("2d"); let s=m.seed;
  const rnd=()=>{ s=(s*16807)%2147483647; return s/2147483647; }, sk=MAP_SKY[m.tod||"day"], g=q.createLinearGradient(0,0,0,H*.72); g.addColorStop(0,sk[0]); g.addColorStop(1,sk[1]);
  q.fillStyle=g; q.fillRect(0,0,W,H);
  if(m.tint){ q.fillStyle="rgba("+m.tint.slice(0,3).map(v=>Math.round(v*255)).join(",")+","+(m.tint[3]*.9).toFixed(2)+")"; q.fillRect(0,0,W,H); }
  if(m.tod==="night"){ q.fillStyle="#fff"; for(let i=0;i<40;i++){ q.globalAlpha=.3+rnd()*.6; q.fillRect(rnd()*W,rnd()*H*.5,1.4,1.4); } q.globalAlpha=1; }
  const tall=m.zone[1]>=9?1.7:m.zone[0]<2?.28:1, ground=H*.74, gc=m.grass||"#58a04a", sn=m.id==="snow", ds=m.id==="desert", ru=m.id==="ruins", ne=m.id==="neon";
  const far=sn?"#aab9c9":ds?"#b9894f":ru?"#3a2f2a":ne?"#2a1750":"#5f7aa0", near=sn?"#7f93a8":ds?"#8a6a3c":ru?"#241c1a":ne?"#150b30":"#2f4466";
  for(let layer=0;layer<2;layer++){ q.fillStyle=layer?near:far; let x=-6; while(x<W){ const w=(layer?20:14)+rnd()*(layer?26:20), h=(18+rnd()*(layer?72:52))*tall*(layer?1:.8), top=ground-h;
      q.beginPath(); if(ru&&rnd()<.7){ q.moveTo(x,ground); q.lineTo(x,top+rnd()*h*.4); q.lineTo(x+w*.4,top+h*.35); q.lineTo(x+w*.7,top+rnd()*h*.3); q.lineTo(x+w,top+h*.5); q.lineTo(x+w,ground); } else { q.rect(x,top,w,h); } q.fill();
      if(layer&&(m.tod!=="day")){ q.fillStyle=ne?(rnd()<.5?"#ff3bd2":"#3be8ff"):"#ffd87a"; for(let k=0;k<h/9;k++){ if(rnd()<.55) q.fillRect(x+3+rnd()*(w-8),top+4+rnd()*(h-8),3,3); } q.fillStyle=near; }
      x+=w+2+rnd()*5; } }
  if(ds){ q.fillStyle="#d7b36e"; q.beginPath(); q.moveTo(0,ground); for(let x=0;x<=W;x+=20) q.lineTo(x,ground-6-Math.sin(x*.05)*6); q.lineTo(W,ground); q.fill(); }
  q.fillStyle=gc; q.fillRect(0,ground,W,H-ground); q.fillStyle="rgba(30,30,34,.85)"; q.fillRect(0,ground+14,W,16);
  q.fillStyle="rgba(255,255,255,.55)"; for(let x=4;x<W;x+=28) q.fillRect(x,ground+21,14,2);
  if(sn){ q.fillStyle="#fff"; for(let i=0;i<70;i++){ q.globalAlpha=.5+rnd()*.5; q.beginPath(); q.arc(rnd()*W,rnd()*H,1+rnd()*1.6,0,6.3); q.fill(); } q.globalAlpha=1; }
  if(ru){ q.fillStyle="rgba(40,36,34,.55)"; for(let i=0;i<4;i++){ const x=30+rnd()*240; q.beginPath(); q.ellipse(x,ground-60-rnd()*20,16+rnd()*16,40,0,0,6.3); q.fill(); } q.fillStyle="#ff7a2a"; for(let i=0;i<7;i++) q.fillRect(rnd()*W,ground-6-rnd()*30,3,3); }
  const v=q.createRadialGradient(W/2,H/2,H*.3,W/2,H/2,H*.95); v.addColorStop(0,"rgba(0,0,0,0)"); v.addColorStop(1,"rgba(0,0,0,.38)"); q.fillStyle=v; q.fillRect(0,0,W,H);
  return c.toDataURL("image/jpeg",.82); }
const mapThumbs={};
function renderMaps(){ const body=$("mbody"); body.innerHTML=""; const grid=el("div","cards grid mapgrid");
  Game.MAPS.forEach(m=>{ const sel=Game.MAP.id===m.id, c=el("div","card map"+(sel?" sel":"")), pv=el("div","mpv"), im=el("img"); try{ im.src=mapThumbs[m.id]||(mapThumbs[m.id]=mapThumb(m)); }catch(e){} im.alt=m.id; pv.appendChild(im); pv.appendChild(el("span","mic",m.icon)); c.appendChild(pv);
    c.appendChild(el("div","nm",t("map_"+m.id))); c.appendChild(el("div","md",t("md_"+m.id)));
    const b=el("button","btn"+(sel?" main":""),sel?t("map_sel"):t("map_go")); c.appendChild(b);
    const pick=()=>{ if(sel) return; Game.audio.click(); Game.setMap(m.id); }; c.onclick=pick; grid.appendChild(c); });
  body.appendChild(grid); }
$("btnMapsS").onclick=()=>{ Game.audio.click(); show("maps"); renderMaps(); };
$("btnMapsBack").onclick=()=>{ Game.audio.click(); show("settings"); };

/* ===== v5: logo, ayarlar (mevsim, saat, ses, hassasiyet, göstergeler), menü çipleri ===== */
function refreshLogo(){ const w=t("title").split(" "); $("logo1").textContent=w[0]||""; $("logo2").textContent=w.slice(1).join(" ")||""; }
const SEASON_ICON={spring:"🌸",summer:"☀️",autumn:"🍂",winter:"❄️"};
const fmtClock=h=>{ h=((h%24)+24)%24; const hh=Math.floor(h), mm=Math.floor((h-hh)*60); return (hh<10?"0":"")+hh+":"+(mm<10?"0":"")+mm; };
function refreshSettings(){
  const S=Game.settings;
  document.querySelectorAll("#qualRow .btn").forEach(b=>b.classList.toggle("sel",b.dataset.q===Game.quality));
  document.querySelectorAll("#seasonRow .btn").forEach(b=>b.classList.toggle("sel",b.dataset.season===S.season));
  const auto=Game.tod&&Game.tod.mode==="auto", hr=Game.tod?Game.tod.hour:12;
  $("hourRange").value=hr; $("clockTxt").textContent=fmtClock(hr);
  document.querySelectorAll("#todRow .btn").forEach(b=>{ const h=b.dataset.hour; b.classList.toggle("sel",h==="auto"?auto:(!auto&&Math.abs(+h-hr)<.26)); });
  $("sensRange").value=S.sens; $("sensTxt").textContent=S.sens.toFixed(1)+"×"; $("volRange").value=S.vol; $("volTxt").textContent=Math.round(S.vol*100)+"%";
  document.querySelectorAll("#hudRow .btn").forEach(b=>b.classList.toggle("sel",!!S[b.dataset.opt]));
  document.querySelectorAll("#npcdRow .btn").forEach(b=>b.classList.toggle("sel",b.dataset.npcd===S.npcd));
  markCam(); markCensor(); if(Game.refreshExtra) Game.refreshExtra(); }
Game.onHour=()=>{ if(!$("settings").classList.contains("on")) return; const hr=Game.tod.hour; $("hourRange").value=hr; $("clockTxt").textContent=fmtClock(hr); document.querySelectorAll("#todRow .btn").forEach(b=>{ const h=b.dataset.hour; b.classList.toggle("sel",h==="auto"?Game.tod.mode==="auto":(Game.tod.mode!=="auto"&&Math.abs(+h-hr)<.26)); }); };
document.querySelectorAll("#seasonRow .btn").forEach(b=>b.onclick=()=>{ Game.audio.click(); if(Game.setSeason) Game.setSeason(b.dataset.season); else Game.settings.season=b.dataset.season; store.set("season",Game.settings.season); refreshSettings(); });
document.querySelectorAll("#todRow .btn").forEach(b=>b.onclick=()=>{ Game.audio.click(); const h=b.dataset.hour; Game.setHour(h==="auto"?"auto":+h); refreshSettings(); });
$("hourRange").oninput=e=>{ Game.setHour(+e.target.value); $("clockTxt").textContent=fmtClock(+e.target.value); document.querySelectorAll("#todRow .btn").forEach(b=>{ b.classList.toggle("sel",b.dataset.hour!=="auto"&&Math.abs(+b.dataset.hour-(+e.target.value))<.26); }); };
$("sensRange").oninput=e=>{ Game.settings.sens=+e.target.value; store.set("sens",String(Game.settings.sens)); $("sensTxt").textContent=Game.settings.sens.toFixed(1)+"×"; };
$("volRange").oninput=e=>{ Game.settings.vol=+e.target.value; store.set("vol",String(Game.settings.vol)); $("volTxt").textContent=Math.round(Game.settings.vol*100)+"%"; Game.audio.setVolume(Game.settings.vol); };
document.querySelectorAll("#npcdRow .btn").forEach(b=>b.onclick=()=>{ Game.audio.click(); Game.settings.npcd=b.dataset.npcd; store.set("npcd",b.dataset.npcd); if(Game.NPC&&Game.NPC.setCap) Game.NPC.setCap(); refreshSettings(); });
document.querySelectorAll("#hudRow .btn").forEach(b=>b.onclick=()=>{ const k=b.dataset.opt; Game.settings[k]=!Game.settings[k]; store.set(k,Game.settings[k]?"1":"0"); Game.audio.click(); refreshSettings(); applyHudOpts(); });
function applyHudOpts(){ const S=Game.settings; $("mm").style.display=S.minimap?"":"none"; $("fpsTxt").style.display=S.fps?"":"none"; }
applyHudOpts();
function refreshChips(){ const c=$("mchips"); if(!c) return; c.innerHTML=""; const S=Game.settings;
  const mk=(txt,cb)=>{ const d=el("button","chip",txt); d.onclick=()=>{ Game.audio.click(); cb(); }; c.appendChild(d); };
  mk(Game.MAP.icon+" "+t("map_"+Game.MAP.id),()=>{ show("maps"); renderMaps(); });
  mk((SEASON_ICON[S.season]||"")+" "+t("s_"+S.season),()=>openSettings("menu"));
  mk("🕐 "+fmtClock(Game.tod?Game.tod.hour:12),()=>openSettings("menu"));
  mk("⚙ "+t(Game.quality),()=>openSettings("menu")); }
Game.refreshChips=refreshChips;
refreshLogo(); refreshSettings(); refreshChips();
