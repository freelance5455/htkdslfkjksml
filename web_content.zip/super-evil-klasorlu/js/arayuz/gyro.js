"use strict";
/* ===== JİROSKOP (v13): cihazı çevirerek kamerayı/bakışı döndür. iPad/telefon dönüş hızını (devicemotion.rotationRate) ekran eksenlerine çevirir; H.yaw/H.pitch'e ekler.
   Ayarlar > Özelleştirme > Jiroskop. iOS'ta izin kullanıcı dokunuşuyla istenir. Dokunmatik bakış ve sürüş/binme kamerasıyla birlikte çalışır. ===== */
Game.Gyro=(function(){
  const S=Game.settings, H=Game.hero||(window.H), api={on:false,ok:false,denied:false,seen:false};
  const acc={y:0,p:0}; let last=0, listening=false, active=0, asked=false;
  const ang=()=>{ try{ if(screen.orientation&&typeof screen.orientation.angle==="number") return screen.orientation.angle; }catch(_){} return typeof window.orientation==="number"?window.orientation:90; };
  function onMotion(e){ const r=e.rotationRate; if(!r||(r.alpha==null&&r.beta==null&&r.gamma==null)) return; api.seen=true;
    const now=performance.now(); let dt=last?(now-last)/1000:.016; last=now; if(!(dt>0)||dt>.1) dt=.016;
    const wx=(r.beta||0)*Math.PI/180, wy=(r.gamma||0)*Math.PI/180, th=ang()*Math.PI/180, c=Math.cos(th), s=Math.sin(th);
    const sx=wx*c-wy*s, sy=wx*s+wy*c;          /* ekran eksenlerine dönüştür: sx = yatay eksen (eğim), sy = dikey eksen (sağ/sol) */
    acc.y+=sy*dt; acc.p+=sx*dt; }
  function attach(){ if(listening) return; listening=true; addEventListener("devicemotion",onMotion); }
  function detach(){ if(!listening) return; listening=false; removeEventListener("devicemotion",onMotion); acc.y=acc.p=0; last=0; }
  function request(){ asked=true; const DM=window.DeviceMotionEvent;
    if(!DM){ api.ok=false; if(Game.toast) Game.toast("t_gyro_na",3200); return; }
    if(typeof DM.requestPermission==="function"){
      try{ DM.requestPermission().then(r=>{ if(r==="granted"){ api.ok=true; api.denied=false; attach(); } else { api.denied=true; api.ok=false; if(Game.toast) Game.toast("t_gyro_deny",4200); } }).catch(()=>{ asked=false; }); }catch(_){ asked=false; } }
    else { api.ok=true; attach(); } }
  /* ayar değişti / açılış: açıksa dinle, değilse bırak */
  api.sync=function(){ api.on=!!S.gyro; if(!api.on){ detach(); return; }
    if(api.ok){ attach(); return; }
    if(!asked) request(); };
  /* iOS: açılışta kayıtlı ayar açıksa izin ancak bir dokunuşla istenebilir → ilk dokunuşta dene */
  const retry=()=>{ if(S.gyro&&!api.ok&&!api.denied&&!asked) request(); };
  document.addEventListener("touchend",retry,{passive:true}); document.addEventListener("click",retry,{passive:true});
  /* kare başına uygula */
  Game.updaters.push((dt)=>{ const h=Game.H||H; if(!h){ acc.y=acc.p=0; return; }
    const play=Game.mode==="play"; if(!api.on||!play){ acc.y=acc.p=0; active=Math.max(0,active-dt); return; }
    const g=S.gyroS||1, dy=acc.y*g, dp=acc.p*g; acc.y=acc.p=0;
    if(Math.abs(dy)+Math.abs(dp)>.0006){ h.yaw+=dy; const pm=h.flying?1.45:1.1; h.pitch=Math.max(-1.3,Math.min(pm,h.pitch+dp)); active=.7; }
    else active=Math.max(0,active-dt); });
  /* kamera kendini ortalamasın: jiroskop kullanılırken "bakış aktif" say */
  const la=Game.lookActive; Game.lookActive=()=>(la?la():false)||active>0;
  api.sync();
  return api; })();
