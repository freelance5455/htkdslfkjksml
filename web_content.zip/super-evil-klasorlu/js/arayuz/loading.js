"use strict";
/* ===== YÜKLEME EKRANI: oyundan hareketli sahne (yanan şehir, lazerli kahraman) + sağ altta LOADING =====
   Yalnızca uygulama açılışında, "Başla"ya ve "Ana menü" (çıkış) tuşuna basınca görünür; mağaza/ayarlarda görünmez. */
Game.Loading=(function(){
  const ov=document.getElementById("ldScr"), cv=document.getElementById("ldCv"), pctEl=document.getElementById("ldPct"), fillEl=document.getElementById("ldFill"), tipEl=document.getElementById("ldTip");
  if(!ov||!cv||!cv.getContext) return {run(w){ try{ w&&w(); }catch(e){} },busy:()=>false};
  const ctx=cv.getContext("2d"); let W=0,H=0,DPR=1,running=false,raf=0,tS=0,last=0,busy=false,prog=0,workDone=false,minMs=2600,tStart=0,hideT=0,frames=0,untilFn=null;
  const rnd=seed=>{ let s=(seed>>>0)||1; return ()=>{ s=(s*1664525+1013904223)>>>0; return s/4294967296; }; };
  const hash=(a,b,c)=>{ let h=(a*374761393+b*668265263+c*2147483647)>>>0; h=((h^(h>>>13))*1274126177)>>>0; return ((h^(h>>>16))>>>0)/4294967296; };
  const clamp=(x,a,b)=>x<a?a:x>b?b:x, lerp=(a,b,t)=>a+(b-a)*t, ease=t=>t*t*(3-2*t);
  /* küçük ateş/duman sprite'ları */
  const mkSpr=(r,g,b)=>{ const c=document.createElement("canvas"); c.width=c.height=64; const q=c.getContext("2d"); if(!q||!q.createRadialGradient) return c; const gr=q.createRadialGradient(32,32,0,32,32,32); gr.addColorStop(0,"rgba("+r+","+g+","+b+",1)"); gr.addColorStop(.4,"rgba("+r+","+g+","+b+",.5)"); gr.addColorStop(1,"rgba("+r+","+g+","+b+",0)"); q.fillStyle=gr; q.fillRect(0,0,64,64); return c; };
  const SP={hot:mkSpr(255,236,170),org:mkSpr(255,140,40),red:mkSpr(220,50,14),smk:mkSpr(40,14,12),eye:mkSpr(255,40,30)};
  let layers=[], embers=[], horizon=0, tgtB=null;
  function build(){ DPR=Math.min(devicePixelRatio||1,1.5); W=cv.width=Math.max(2,Math.floor(innerWidth*DPR)); H=cv.height=Math.max(2,Math.floor(innerHeight*DPR)); horizon=H*.77;
    const defs=[{seed:11,n:34,min:.07,max:.20,wmin:.035,wmax:.075,col:[84,26,30],par:.012,win:.22,fire:0},{seed:23,n:26,min:.10,max:.28,wmin:.045,wmax:.09,col:[46,13,17],par:.035,win:.4,fire:3},{seed:37,n:15,min:.14,max:.34,wmin:.07,wmax:.13,col:[12,4,7],par:.09,win:.34,fire:2}];
    layers=defs.map(d=>{ const r=rnd(d.seed), span=W*2.4, bs=[]; let x=-W*.1; for(let i=0;x<span&&i<80;i++){ const w=(d.wmin+r()*(d.wmax-d.wmin))*W, h=(d.min+r()*(d.max-d.min))*H*(.8+.5*r()); bs.push({x,w,h,seed:(d.seed*131+i)|0,ant:r()<.3,fire:0,roof:r()<.35?(.4+r()*.5):0}); x+=w+r()*W*.012; }
      const span2=x+W*.02; for(let k=0;k<d.fire;k++){ const b=bs[(r()*bs.length)|0]; b.fire=1; } return Object.assign({},d,{bs,span:span2}); });
    embers=[]; for(let i=0;i<110;i++) embers.push({x:Math.random()*W,y:Math.random()*H,v:20+Math.random()*60,s:(.6+Math.random()*1.8)*DPR,p:Math.random()*6.28}); tgtB=null; }
  function sky(t){ const g=ctx.createLinearGradient(0,0,0,horizon+H*.02); g.addColorStop(0,"#10010a"); g.addColorStop(.32,"#3c0711"); g.addColorStop(.58,"#a2290f"); g.addColorStop(.8,"#ff7a1c"); g.addColorStop(1,"#ffc060"); ctx.fillStyle=g; ctx.fillRect(0,0,W,H);
    /* dev kan-kırmızı güneş + hâle */
    const sx=W*.7, sy=horizon-H*.14, sr=H*.17, hl=ctx.createRadialGradient(sx,sy,sr*.4,sx,sy,sr*3.2); hl.addColorStop(0,"rgba(255,150,60,.65)"); hl.addColorStop(1,"rgba(255,80,20,0)"); ctx.fillStyle=hl; ctx.fillRect(0,0,W,H);
    const sg=ctx.createRadialGradient(sx-sr*.2,sy-sr*.2,sr*.1,sx,sy,sr); sg.addColorStop(0,"#fff0b8"); sg.addColorStop(.55,"#ffb23d"); sg.addColorStop(1,"#e8441a"); ctx.fillStyle=sg; ctx.beginPath(); ctx.arc(sx,sy,sr,0,6.283); ctx.fill();
    /* duman/bulut bantları */
    ctx.globalCompositeOperation="source-over"; for(let i=0;i<9;i++){ const r=hash(i,3,9), y=H*(.08+.5*r), w=W*(.5+.5*hash(i,4,9)), x=((hash(i,5,9)*W*1.6+t*(8+16*r)*DPR)%(W*1.6+w))-w; ctx.globalAlpha=.16+.16*hash(i,6,9); ctx.fillStyle=i%3?"#2b060b":"#4a0d10"; ctx.beginPath(); ctx.ellipse(x+w/2,y,w/2,H*(.018+.03*r),0,0,6.283); ctx.fill(); } ctx.globalAlpha=1; }
  function flame(x,y,s,t,seed){ ctx.globalCompositeOperation="lighter"; for(let k=0;k<5;k++){ const ph=t*(3+k*.7)+seed*3+k*1.7, fy=y-(Math.abs(Math.sin(ph))*s*1.5)*(1-k*.12), fx=x+Math.sin(ph*1.3)*s*.35, sz=s*(1.1-k*.16), a=.55*(1-k*.14);
      ctx.globalAlpha=a; ctx.drawImage(k<2?SP.org:k<4?SP.red:SP.smk,fx-sz,fy-sz,sz*2,sz*2); if(k===0){ ctx.globalAlpha=.6; ctx.drawImage(SP.hot,x-sz*.5,y-sz*.9,sz,sz); } } ctx.globalAlpha=1; ctx.globalCompositeOperation="source-over"; }
  function layer(L,li,t){ const off=t*L.par*W*.35, base=horizon+(li===0?H*.012:li===1?H*.03:H*.05), c=L.col; ctx.fillStyle="rgb("+c[0]+","+c[1]+","+c[2]+")";
    for(let rep=-1;rep<=1;rep++) for(let bi=0;bi<L.bs.length;bi++){ const b=L.bs[bi], x=b.x-((off%L.span+L.span)%L.span)+rep*L.span; if(x>W||x+b.w<0) continue; const y=base-b.h; ctx.fillStyle="rgb("+c[0]+","+c[1]+","+c[2]+")"; ctx.fillRect(x,y,b.w,b.h+H*.1);
        if(b.roof){ ctx.fillRect(x+b.w*.18,y-b.h*.06*b.roof,b.w*.64,b.h*.06*b.roof+1); } if(b.ant){ ctx.fillRect(x+b.w*.5-1,y-b.h*.22,Math.max(1,DPR),b.h*.22); if(li>0&&((t*1.3+b.seed)%2)<1){ ctx.globalCompositeOperation="lighter"; ctx.globalAlpha=.9; ctx.drawImage(SP.eye,x+b.w*.5-5*DPR,y-b.h*.22-5*DPR,10*DPR,10*DPR); ctx.globalAlpha=1; ctx.globalCompositeOperation="source-over"; } }
        /* pencereler */
        if(L.win>0){ const cw=Math.max(3*DPR,b.w/(li===2?14:11)), ch=Math.max(4.5*DPR,cw*1.5), cols=Math.floor((b.w-cw)/cw/1.35), rows=Math.floor((b.h-ch)/ch/1.5); const wx=(b.w-cols*cw*1.35+cw*.35)/2;
          for(let j=0;j<rows;j++) for(let i=0;i<cols;i++){ const h0=hash(b.seed,i,j); if(h0>L.win) continue; let on=h0<L.win*.6; const fl=hash(b.seed,i+9,j+3); if(fl>.9) on=((t*2.2+fl*10)|0)%2===0; if(!on&&h0>L.win*.8) continue; ctx.fillStyle=on?(h0<L.win*.15?"rgba(255,206,120,.9)":"rgba(255,128,44,.75)"):"rgba(110,28,20,.28)"; ctx.fillRect(x+wx+i*cw*1.35,y+ch*.8+j*ch*1.5,cw,ch); } }
        if(b.fire) flame(x+b.w*(.3+.4*hash(b.seed,1,1)),y+2*DPR,(b.w*.38)*(li===2?1.15:.8),t,b.seed); } }
  /* kahraman: yan görünüş, öne uzanmış yumruk, dalgalanan pelerin, kızıl gözler */
  function hero(x,y,s,t,beam){ ctx.save(); ctx.translate(x,y); const tilt=-.12+Math.sin(t*1.4)*.025; ctx.rotate(tilt); ctx.scale(s,s); ctx.lineCap="round"; ctx.lineJoin="round";
    const sil="#06030a", rim="rgba(255,150,70,.6)";
    /* pelerin: omuzdan geriye genişleyen, dalgalı kenarlı büyük örtü */
    const N=26, top=[], bot=[]; for(let i=0;i<=N;i++){ const k=i/N, wv=Math.sin(t*6-k*7)*.07*k+Math.sin(t*3.1-k*3)*.05*k, px=.1-k*1.55, py=-.12+wv-.01*k+k*k*.12, wd=.10+.34*Math.pow(k,.85)+Math.sin(t*5-k*9+1)*.025*k; top.push([px,py]); bot.push([px-.03*k+Math.sin(t*4-k*8)*.02*k,py+wd]); }
    ctx.beginPath(); ctx.moveTo(top[0][0],top[0][1]); for(const p of top) ctx.lineTo(p[0],p[1]); for(let i=N;i>=0;i--) ctx.lineTo(bot[i][0],bot[i][1]); ctx.lineTo(.06,.03); ctx.closePath();
    const cg=ctx.createLinearGradient(.1,0,-1.45,0); cg.addColorStop(0,"#70090c"); cg.addColorStop(.55,"#38050a"); cg.addColorStop(1,"#1a0206"); ctx.fillStyle=cg; ctx.fill(); ctx.strokeStyle="rgba(255,100,50,.5)"; ctx.lineWidth=.011; ctx.beginPath(); ctx.moveTo(top[0][0],top[0][1]); for(const p of top) ctx.lineTo(p[0],p[1]); ctx.stroke();
    /* arka kol */
    ctx.strokeStyle=sil; ctx.lineWidth=.075; ctx.beginPath(); ctx.moveTo(.1,-.02); ctx.lineTo(-.04,.045); ctx.lineTo(-.2,.03); ctx.stroke();
    /* bacaklar (hafif bükük, ayak uçları aşağı) */
    const kb=Math.sin(t*3)*.012;
    ctx.lineWidth=.12; ctx.beginPath(); ctx.moveTo(-.2,.04); ctx.lineTo(-.46,.07+kb); ctx.stroke(); ctx.lineWidth=.092; ctx.beginPath(); ctx.moveTo(-.46,.07+kb); ctx.lineTo(-.72,.015+kb); ctx.stroke(); ctx.lineWidth=.06; ctx.beginPath(); ctx.moveTo(-.72,.015+kb); ctx.lineTo(-.8,.04+kb); ctx.stroke();
    ctx.lineWidth=.105; ctx.beginPath(); ctx.moveTo(-.2,.055); ctx.lineTo(-.44,.14-kb); ctx.stroke(); ctx.lineWidth=.085; ctx.beginPath(); ctx.moveTo(-.44,.14-kb); ctx.lineTo(-.68,.115-kb); ctx.stroke(); ctx.lineWidth=.055; ctx.beginPath(); ctx.moveTo(-.68,.115-kb); ctx.lineTo(-.77,.14-kb); ctx.stroke();
    /* gövde: göğüste kalın, belde ince */
    ctx.fillStyle=sil; ctx.beginPath(); ctx.moveTo(.2,-.15); ctx.quadraticCurveTo(.26,-.02,.15,.05); ctx.lineTo(-.22,.07); ctx.lineTo(-.24,-.04); ctx.quadraticCurveTo(-.02,-.17,.2,-.15); ctx.closePath(); ctx.fill();
    ctx.strokeStyle=rim; ctx.lineWidth=.012; ctx.beginPath(); ctx.moveTo(.2,-.15); ctx.quadraticCurveTo(-.02,-.17,-.24,-.04); ctx.stroke();
    /* öne uzanan kol + yumruk */
    ctx.strokeStyle=sil; ctx.lineWidth=.1; ctx.beginPath(); ctx.moveTo(.12,-.1); ctx.lineTo(.46,-.17); ctx.stroke(); ctx.lineWidth=.085; ctx.beginPath(); ctx.moveTo(.46,-.17); ctx.lineTo(.68,-.2); ctx.stroke(); ctx.fillStyle=sil; ctx.beginPath(); ctx.arc(.73,-.205,.058,0,6.283); ctx.fill();
    ctx.strokeStyle=rim; ctx.lineWidth=.011; ctx.beginPath(); ctx.moveTo(.12,-.155); ctx.lineTo(.68,-.255); ctx.stroke();
    /* kafa + boyun */
    ctx.fillStyle=sil; ctx.beginPath(); ctx.arc(.31,-.13,.082,0,6.283); ctx.fill(); ctx.fillRect(.2,-.15,.1,.07); ctx.strokeStyle=rim; ctx.lineWidth=.012; ctx.beginPath(); ctx.arc(.31,-.13,.082,-2.5,-.6); ctx.stroke();
    /* saç tutamı */
    ctx.fillStyle=sil; ctx.beginPath(); ctx.moveTo(.24,-.195); ctx.quadraticCurveTo(.3,-.255,.37,-.2); ctx.lineTo(.33,-.17); ctx.closePath(); ctx.fill();
    /* kızıl gözler */
    ctx.globalCompositeOperation="lighter"; const ex=.355,ey=-.14, ea=.75+.25*Math.sin(t*9); ctx.globalAlpha=ea; ctx.drawImage(SP.eye,ex-.075,ey-.075,.15,.15); ctx.globalAlpha=1; ctx.fillStyle="#ffc0b0"; ctx.beginPath(); ctx.arc(ex,ey,.013,0,6.283); ctx.fill();
    ctx.restore();
    /* hız çizgileri */
    ctx.globalCompositeOperation="lighter"; for(let i=0;i<5;i++){ const sy=y+(hash(i,1,1)-.5)*s*.5, len=s*(.7+hash(i,2,2)*1.2), ox=s*(.9+hash(i,3,3)*.6)+((t*3+i*.37)%1)*s*.5; ctx.globalAlpha=.07+.06*hash(i,4,4); ctx.strokeStyle="#ffbb88"; ctx.lineWidth=Math.max(1,DPR); ctx.beginPath(); ctx.moveTo(x-ox,sy); ctx.lineTo(x-ox-len,sy+len*.1); ctx.stroke(); }
    if(beam){ const ca=Math.cos(tilt), sa=Math.sin(tilt), ex2=x+(ca*.355-sa*-.14)*s, ey2=y+(sa*.355+ca*-.14)*s, tx=beam.tx, ty=beam.ty, a=beam.a; ctx.globalCompositeOperation="lighter";
      for(const [w,al,col] of [[14,.16,"255,40,20"],[6,.4,"255,90,40"],[2.2,.95,"255,225,205"]]){ ctx.globalAlpha=al*a; ctx.strokeStyle="rgb("+col+")"; ctx.lineWidth=w*DPR; ctx.lineCap="round"; ctx.beginPath(); ctx.moveTo(ex2,ey2); ctx.lineTo(tx,ty); ctx.stroke(); }
      ctx.globalAlpha=a; const gs=H*.06; ctx.drawImage(SP.hot,tx-gs,ty-gs,gs*2,gs*2); const gs2=H*.025; ctx.drawImage(SP.hot,ex2-gs2,ey2-gs2,gs2*2,gs2*2); ctx.globalAlpha=1; }
    ctx.globalCompositeOperation="source-over"; ctx.globalAlpha=1; }
  /* patlama: halka + ateş topu + kıvılcım + düşen parçalar */
  function boom(x,y,u,t){ if(u<0||u>1) return; const e=ease(Math.min(1,u*1.6)), a=1-u; ctx.globalCompositeOperation="lighter";
    const R=H*.17*e; ctx.globalAlpha=a*.9; const g=ctx.createRadialGradient(x,y,R*.1,x,y,R); g.addColorStop(0,"rgba(255,245,200,.95)"); g.addColorStop(.4,"rgba(255,150,40,.6)"); g.addColorStop(1,"rgba(200,30,10,0)"); ctx.fillStyle=g; ctx.beginPath(); ctx.arc(x,y,R,0,6.283); ctx.fill();
    ctx.globalAlpha=a*.7; ctx.strokeStyle="rgba(255,190,120,1)"; ctx.lineWidth=Math.max(1,H*.006*(1-u)); ctx.beginPath(); ctx.arc(x,y,R*1.25,0,6.283); ctx.stroke();
    for(let i=0;i<26;i++){ const ang=hash(i,7,3)*6.283, sp=(.5+hash(i,8,3))*H*.32, d=sp*u, px=x+Math.cos(ang)*d, py=y+Math.sin(ang)*d+H*.18*u*u*(1+hash(i,9,3)); ctx.globalAlpha=a*.9; ctx.fillStyle=i%3?"#ffb040":"#fff0c0"; ctx.fillRect(px,py,2.5*DPR,2.5*DPR); }
    ctx.globalCompositeOperation="source-over"; for(let i=0;i<9;i++){ const ang=-1.57+(hash(i,1,5)-.5)*2.4, sp=hash(i,2,5)*H*.14+H*.04, px=x+Math.cos(ang)*sp*u*.8, py=y+Math.sin(ang)*sp*u+H*.34*u*u, sz=(6+hash(i,3,5)*12)*DPR; ctx.globalAlpha=a; ctx.fillStyle="#120508"; ctx.save(); ctx.translate(px,py); ctx.rotate(u*(hash(i,4,5)*8-4)); ctx.fillRect(-sz/2,-sz/3,sz,sz*.66); ctx.restore(); }
    ctx.globalAlpha=Math.max(0,.5*(1-u*.6)); for(let i=0;i<5;i++){ const sz=H*(.05+.09*u)*(.7+hash(i,5,5)*.6); ctx.drawImage(SP.smk,x+(hash(i,6,5)-.5)*H*.12-sz,y-H*.12*u-i*H*.014-sz,sz*2,sz*2); } ctx.globalAlpha=1; }
  function frame(now){ if(!running) return; raf=requestAnimationFrame(frame); const dt=Math.min(.05,(now-last)/1000); last=now; const t=(now-tS)/1000; if(!W) return; frames++;
    sky(t); layer(layers[0],0,t); layer(layers[1],1,t);
    layer(layers[2],2,t);
    /* sahne döngüsü: kahraman soldan sağa uçar, ortada lazer ateşler, hedef kule patlar */
    const C=9, ph=(t%C)/C, hx=lerp(-W*.2,W*1.12,ph), hy=H*.27+Math.sin(t*1.3)*H*.018+Math.sin(ph*6.283)*H*.025, hs=H*.27, L2=layers[2], offN=((t*L2.par*W*.35)%L2.span+L2.span)%L2.span;
    if(ph<.02||!tgtB){ let best=null,bd=1e9; for(let rep=-1;rep<=1;rep++) for(let bi=0;bi<L2.bs.length;bi++){ const b=L2.bs[bi], x=b.x-offN+rep*L2.span+b.w/2, d2=Math.abs(x-W*.82); if(d2<bd&&b.h>H*.16){ bd=d2; best={bi,rep}; } } tgtB=best; }
    let tx=W*.8, ty=horizon-H*.3; if(tgtB){ const b=L2.bs[tgtB.bi]; tx=b.x-offN+tgtB.rep*L2.span+b.w/2; ty=horizon+H*.05-b.h; }
    let beam=null; if(ph>.4&&ph<.64) beam={tx,ty,a:ph<.43?(ph-.4)/.03:ph>.6?Math.max(0,(.64-ph)/.04):1};
    const bt=(ph-.43)/.2; if(bt>0&&bt<1) boom(tx,ty,bt,t);
    hero(hx,hy,hs,t,beam);
    /* ön yer: sis + kıvılcımlar */
    const fg=ctx.createLinearGradient(0,horizon,0,H); fg.addColorStop(0,"rgba(255,90,30,.0)"); fg.addColorStop(.25,"rgba(20,4,6,.85)"); fg.addColorStop(1,"rgba(3,0,2,1)"); ctx.fillStyle=fg; ctx.fillRect(0,horizon,W,H-horizon);
    ctx.globalCompositeOperation="lighter"; for(const e of embers){ e.y-=e.v*dt*DPR; e.x+=Math.sin(t*1.7+e.p)*22*dt*DPR+6*dt*DPR; if(e.y<-10){ e.y=H+10; e.x=Math.random()*W; } const a=(.35+.65*Math.abs(Math.sin(t*5+e.p*4)))*clamp(e.y/H*1.3,.2,1); ctx.globalAlpha=a; ctx.fillStyle=e.p>3.2?"#ffcf80":"#ff7a2a"; ctx.beginPath(); ctx.arc(e.x,e.y,e.s,0,6.283); ctx.fill(); }
    ctx.globalAlpha=1; ctx.globalCompositeOperation="source-over";
    /* ilerleme */
    const el=(now-tStart)/1000*1000; let target=workDone&&el>=minMs&&(!untilFn||untilFn())?1:Math.min(.9,el/minMs*.9); if(workDone&&el<minMs) target=Math.min(.97,el/minMs*.97); prog+=(target-prog)*(1-Math.exp(-5*dt)); const shown=Math.min(100,Math.round(prog*100));
    if(pctEl&&pctEl.__v!==shown){ pctEl.__v=shown; pctEl.textContent=shown+"%"; } if(fillEl) fillEl.style.width=(prog*100).toFixed(1)+"%";
    if(busy&&workDone&&target===1&&prog>.994&&!hideT){ hideT=now; setTimeout(finish,260); } }
  function finish(){ ov.classList.remove("on"); busy=false; setTimeout(()=>{ if(!busy){ running=false; cancelAnimationFrame(raf); } },520); }
  /* work: ağır iş (mod değiştirme); opts.min: en kısa süre (ms); opts.until: ek koşul (ör. birkaç kare çizilsin) */
  function run(work,opts){ opts=opts||{}; if(busy){ try{ work&&work(); }catch(e){} return; } busy=true; workDone=false; hideT=0; prog=0; frames=0; minMs=opts.min||2600; untilFn=opts.until||null; if(!W) build();
    ov.classList.add("on"); if(!running){ running=true; tS=tStart=last=performance.now(); raf=requestAnimationFrame(frame); } else tStart=performance.now(); if(pctEl) pctEl.__v=-1;
    /* kaplama görününce işi yap (ağır geçişler perdenin arkasında kalsın) */
    setTimeout(()=>{ try{ work&&work(); }catch(e){ if(window.reportErr) reportErr(e); } workDone=true; },300); }
  window.addEventListener("resize",()=>{ if(running||W) build(); });
  return {run,busy:()=>busy,frames:()=>frames,_build:build};
})();
