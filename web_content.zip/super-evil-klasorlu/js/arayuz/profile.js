"use strict";
/* ===== PROFİL + BULUT KAYDI: oyuncu adı/avatar/fotoğraf; Google ile giriş (Firebase) ve bulut yedeği.
   Kurulum: Game.CONFIG.google.firebase doldurulur (PLAYSTORE/KURULUM.md). Boşsa yalnızca yerel profil çalışır. ===== */
Game.Cloud=(function(){
  const E=Game.Eco, C=Game.CONFIG.google||{}, fb=C.firebase||{}, api={ user:null, ready:false, busy:false, last:0 };
  const configured=()=>!!(fb.apiKey&&fb.projectId);
  const capPlugin=()=>{ try{ return window.Capacitor&&window.Capacitor.Plugins&&window.Capacitor.Plugins.FirebaseAuthentication; }catch(e){ return null; } };
  function loadScript(src){ return new Promise((res,rej)=>{ const s=document.createElement("script"); s.src=src; s.onload=res; s.onerror=()=>rej(new Error("load "+src)); document.head.appendChild(s); }); }
  let sdk=null;
  async function ensureSdk(){ if(sdk) return sdk; const V="10.12.2", b="https://www.gstatic.com/firebasejs/"+V+"/";
    if(!window.firebase){ await loadScript(b+"firebase-app-compat.js"); await loadScript(b+"firebase-auth-compat.js"); await loadScript(b+"firebase-firestore-compat.js"); }
    const f=window.firebase; if(!f.apps.length) f.initializeApp({apiKey:fb.apiKey,authDomain:fb.authDomain||(fb.projectId+".firebaseapp.com"),projectId:fb.projectId,appId:fb.appId||undefined,storageBucket:fb.storageBucket||undefined,messagingSenderId:fb.messagingSenderId||undefined});
    sdk=f; return f; }
  const doc=(f,uid)=>f.firestore().collection("players").doc(uid);
  const snapshot=()=>({ eco:E.exportState(), prem:Game.Premium.exportState(), name:E.S.profile.name||"", avatar:E.S.profile.avatar||"hero", photo:E.S.profile.photo||"", v:1, t:Date.now() });
  function mergeIn(d){ if(!d) return; if(d.eco) E.importState(d.eco); if(d.prem) Game.Premium.importState(d.prem);
    if(d.name&&!E.S.profile.name) E.S.profile.name=d.name; if(d.avatar&&!E.S.profile.avatar) E.S.profile.avatar=d.avatar; if(d.photo&&!E.S.profile.photo) E.S.profile.photo=d.photo; E.flush(); }
  async function push(){ if(!api.user||!sdk) return; try{ await doc(sdk,api.user.uid).set(snapshot(),{merge:false}); api.last=Date.now(); if(api.onChange) api.onChange(); }catch(e){} }
  let pushT=0; api.schedule=function(){ if(!api.user) return; clearTimeout(pushT); pushT=setTimeout(push,6000); };
  api.syncNow=async function(){ if(!api.user||!sdk) return false; try{ const snap=await doc(sdk,api.user.uid).get(); if(snap.exists) mergeIn(snap.data()); await push(); return true; }catch(e){ return false; } };
  function setUser(u){ api.user=u?{uid:u.uid,name:u.displayName||"",photo:u.photoURL||"",email:u.email||""}:null; store.set("cloud_on",u?"1":"0"); if(api.onChange) api.onChange(); }
  const inApp=()=>{ try{ const c=window.Capacitor; if(!c) return false; if(typeof c.isNativePlatform==="function") return !!c.isNativePlatform(); if(typeof c.getPlatform==="function") return c.getPlatform()!=="web"; return false; }catch(e){ return false; } };
  /* Firebase SDK'sını önceden yükle: Safari/iOS açılır pencereyi yalnızca kullanıcı dokunuşunun hemen ardından açmaya izin verir; SDK'yı dokunuştan sonra indirirsek engellenir */
  api.preload=function(){ if(configured()&&!sdk&&!window.__fbPre){ window.__fbPre=1; ensureSdk().catch(()=>{ window.__fbPre=0; }); } };
  api.signIn=async function(){ if(!configured()) return {ok:false,why:"setup"}; if(api.busy) return {ok:false,why:"busy"};
    const p=capPlugin(); if(!p&&inApp()) return {ok:false,why:"setup"};   /* Android uygulamasında yerel Google eklentisi yoksa (google-services.json eklenmemiş) açılır pencere çalışmaz */
    api.busy=true;
    try{ let cred;
      if(p){ const f=await ensureSdk(); const r=await p.signInWithGoogle(); const idToken=r&&r.credential&&r.credential.idToken; if(!idToken) throw new Error("no token"); cred=await f.auth().signInWithCredential(f.auth.GoogleAuthProvider.credential(idToken)); }
      else { const f=sdk||await ensureSdk(); const prov=new f.auth.GoogleAuthProvider(); try{ cred=await f.auth().signInWithPopup(prov); }
        catch(e){ const code=e&&e.code||""; if(/popup-blocked|operation-not-supported|web-storage-unsupported/.test(code)&&f.auth().signInWithRedirect){ await f.auth().signInWithRedirect(prov); api.busy=false; return {ok:false,why:"redirect"}; } throw e; } }
      setUser(cred.user); if(!E.S.profile.name&&cred.user.displayName) E.S.profile.name=cred.user.displayName.slice(0,16); if(!E.S.profile.photo&&cred.user.photoURL){ E.S.profile.avatar="google"; E.S.profile.photo=cred.user.photoURL; }
      const ok=await api.syncNow(); api.busy=false; return {ok:true,synced:ok}; }
    catch(e){ api.busy=false; return {ok:false,why:"fail",err:String(e&&e.message||e)}; } };
  api.signOut=async function(){ try{ if(sdk) await sdk.auth().signOut(); const p=capPlugin(); if(p&&p.signOut) await p.signOut(); }catch(e){} setUser(null); };
  /* hesap + bulut verisi silme (Play politikası: uygulama içinden hesap silme). Yerel ilerleme cihazda kalır. */
  api.deleteAccount=async function(){ if(!api.user||!sdk) return {ok:false,why:"none"}; if(api.busy) return {ok:false,why:"busy"}; api.busy=true;
    try{ const f=sdk, u=f.auth().currentUser; try{ await doc(f,api.user.uid).delete(); }catch(e){}
      if(u){ try{ await u.delete(); }catch(e){ const code=e&&e.code||""; if(code.indexOf("requires-recent-login")>=0){ api.busy=false; return {ok:false,why:"recent"}; } throw e; } }
      const p=capPlugin(); try{ if(p&&p.signOut) await p.signOut(); }catch(e){} setUser(null); api.busy=false; return {ok:true}; }
    catch(e){ api.busy=false; return {ok:false,why:"fail",err:String(e&&e.message||e)}; } };
  api.configured=configured;
  /* önceden giriş yapılmışsa açılışta sessizce geri yükle */
  if(configured()&&store.get("cloud_on","0")==="1"){ ensureSdk().then(f=>{ f.auth().onAuthStateChanged(u=>{ if(u){ setUser(u); api.syncNow(); } else setUser(null); }); }).catch(()=>{}); }
  else if(configured()&&!inApp()){ /* tarayıcı: yönlendirmeyle girişten dönülmüş olabilir; SDK'yı boş zamanda ön yükle */
    const idle=window.requestIdleCallback||(fn=>setTimeout(fn,3000)); idle(()=>{ if(!sdk&&!window.__fbPre){ window.__fbPre=1; ensureSdk().then(f=>{ if(f.auth().getRedirectResult) return f.auth().getRedirectResult().then(r=>{ if(r&&r.user){ setUser(r.user); api.syncNow(); } }); }).catch(()=>{ window.__fbPre=0; }); } }); }
  E.onSave=()=>{ api.schedule(); };
  document.addEventListener("visibilitychange",()=>{ if(document.hidden&&api.user) push(); });
  return api; })();

Game.Profile=(function(){
  const E=Game.Eco, S=E.S, api={};
  const AV=["hero","pharaoh","poseidon","zeus","ninja","knight","viking","astro","robot","wizard","samurai","dragon","devil","skull","fire","crown"];
  const AV_ICON={devil:"😈",skull:"💀",fire:"🔥",crown:"👑"};
  const icon=id=>AV_ICON[id]||(id==="hero"?CHARS.classic.icon:(CHARS[id]?CHARS[id].icon:"🦸"));
  const GRAD=["#ff5a3c,#8a1020","#ffb020,#8a4a06","#2ec4b6,#0b3c49","#a06bff,#2b1160","#ff6bb5,#6b1250","#5ac8fa,#0b3d6b"];
  const gradFor=id=>{ let h=0; for(const c of id) h=(h*31+c.charCodeAt(0))>>>0; return GRAD[h%GRAD.length]; };
  api.name=()=>S.profile.name||t("prof_guest");
  function paintAvatar(node,big){ node.innerHTML=""; node.style.background=""; node.classList.remove("photo");
    const p=S.profile; if(p.photo&&(p.avatar==="photo"||p.avatar==="google")){ const im=document.createElement("img"); im.src=p.photo; im.alt=""; im.referrerPolicy="no-referrer"; node.appendChild(im); node.classList.add("photo"); return; }
    const id=p.avatar||"hero"; node.style.background="linear-gradient(135deg,"+gradFor(id)+")"; node.textContent=icon(id); }
  api.refreshMenu=function(){ const a=$("menuProfAv"), n=$("menuProfName"); if(a) paintAvatar(a); if(n){ n.textContent=api.name(); const tl=Game.Ach&&Game.Ach.titleText&&Game.Ach.titleText(); if(tl){ const sm=document.createElement("small"); sm.textContent=tl; n.appendChild(sm); } } };
  /* seçilen resmi 128px kareye kırpıp küçült */
  function shrink(file,cb){ const rd=new FileReader(); rd.onload=()=>{ const im=new Image(); im.onload=()=>{ const c=document.createElement("canvas"); c.width=c.height=128; const q=c.getContext("2d"), m=Math.min(im.width,im.height), sx=(im.width-m)/2, sy=(im.height-m)/2; q.drawImage(im,sx,sy,m,m,0,0,128,128); cb(c.toDataURL("image/jpeg",.78)); }; im.onerror=()=>cb(null); im.src=rd.result; }; rd.onerror=()=>cb(null); rd.readAsDataURL(file); }
  let ptab="profile";
  function render(){ const b=$("profBody"); if(!b) return; b.innerHTML=""; const C=Game.Cloud;
    const tabs=el("div","ptabs"); for(const [id,key] of [["profile","prof_tab_profile"],["titles","ach_titles_h"],["ach","ach_h"]]){ const tb=el("button","ptab"+(ptab===id?" on":""),t(key)); tb.onclick=()=>{ Game.audio.click(); ptab=id; render(); }; tabs.appendChild(tb); } b.appendChild(tabs);
    if(ptab!=="profile"&&Game.Ach){ Game.Ach.render(b,ptab,render); return; }
    const top=el("div","ptop"), av=el("div","pavbig"); paintAvatar(av,true); top.appendChild(av);
    const form=el("div","pform"); const l=el("span","lbl",t("prof_name")); l.dataset.i18n="prof_name"; form.appendChild(l);
    const inp=document.createElement("input"); inp.type="text"; inp.maxLength=16; inp.className="pname"; inp.value=S.profile.name||""; inp.placeholder=t("prof_guest"); inp.oninput=()=>{ S.profile.name=inp.value.trim().slice(0,16); E.flush(); api.refreshMenu(); }; form.appendChild(inp);
    const file=document.createElement("input"); file.type="file"; file.accept="image/*"; file.style.display="none"; file.onchange=()=>{ const f=file.files&&file.files[0]; if(!f) return; shrink(f,u=>{ if(u){ S.profile.photo=u; S.profile.avatar="photo"; E.flush(); api.refreshMenu(); render(); } }); };
    const chip=Game.Ach&&Game.Ach.titleChip&&Game.Ach.titleChip(); if(chip) form.appendChild(chip);
    const pb=el("button","btn",t("prof_photo")); pb.dataset.i18n="prof_photo"; pb.onclick=()=>{ Game.audio.click(); file.click(); }; form.appendChild(pb); form.appendChild(file);
    top.appendChild(form); b.appendChild(top);
    const l2=el("span","lbl",t("prof_avatar")); l2.dataset.i18n="prof_avatar"; b.appendChild(l2);
    const grid=el("div","avgrid"); AV.forEach(id=>{ const d=el("div","avopt"+(S.profile.avatar===id?" sel":"")); d.style.background="linear-gradient(135deg,"+gradFor(id)+")"; d.textContent=icon(id); d.onclick=()=>{ Game.audio.click(); S.profile.avatar=id; E.flush(); api.refreshMenu(); render(); }; grid.appendChild(d); }); b.appendChild(grid);
    const cl=el("div","cloudbox"); const st=el("div","cloudtx");
    if(C.user){ st.textContent=t("prof_cloud_on"); const u=el("div","cuser",(C.user.name||"")+(C.user.email?"  ·  "+C.user.email:"")); const ok=el("div","csync",C.last?t("prof_synced"):""); const bo=el("button","btn",t("prof_out")); bo.dataset.i18n="prof_out"; bo.onclick=async()=>{ Game.audio.click(); await C.signOut(); render(); };
      const bd=el("button","btn danger",t("prof_del")); bd.dataset.i18n="prof_del"; bd.onclick=async()=>{ Game.audio.click(); let yes=true; try{ yes=confirm(t("prof_del_ask")); }catch(e){} if(!yes) return; bd.disabled=true; const r=await C.deleteAccount(); bd.disabled=false;
        if(Game.shopMsg) Game.shopMsg(r.ok?"prof_del_ok":(r.why==="recent"?"prof_del_recent":"prof_del_fail")); render(); };
      cl.appendChild(st); cl.appendChild(u); cl.appendChild(ok); cl.appendChild(bo); cl.appendChild(bd); }
    else { st.textContent=t("prof_cloud_off"); const bg=el("button","gbtn"); bg.innerHTML='<svg viewBox="0 0 24 24" class="gico"><path fill="#4285F4" d="M23 12.3c0-.8-.1-1.5-.2-2.3H12v4.4h6.2a5.3 5.3 0 0 1-2.3 3.5v2.9h3.7c2.2-2 3.4-5 3.4-8.5z"/><path fill="#34A853" d="M12 24c3.1 0 5.7-1 7.6-2.8l-3.7-2.9c-1 .7-2.3 1.1-3.9 1.1-3 0-5.5-2-6.4-4.7H1.8v3A12 12 0 0 0 12 24z"/><path fill="#FBBC05" d="M5.6 14.7a7.2 7.2 0 0 1 0-4.6v-3H1.8a12 12 0 0 0 0 10.7z"/><path fill="#EA4335" d="M12 4.8c1.7 0 3.2.6 4.4 1.7l3.3-3.3A12 12 0 0 0 1.8 7.1l3.8 3C6.5 6.8 9 4.8 12 4.8z"/></svg><span></span>'; bg.querySelector("span").textContent=t("prof_google");
      bg.onclick=async()=>{ Game.audio.click(); if(!C.configured()){ if(Game.shopMsg) Game.shopMsg("prof_setup"); return; } bg.disabled=true; const r=await C.signIn(); bg.disabled=false; if(!r.ok&&r.why!=="busy"&&r.why!=="redirect"&&Game.shopMsg) Game.shopMsg(r.why==="setup"?"prof_setup":"prof_fail"); render(); };
      cl.appendChild(st); cl.appendChild(bg); }
    b.appendChild(cl); }
  Game.Cloud.onChange=()=>{ if($("profile").classList.contains("on")) render(); };
  let from="menu"; $("menuProf").onclick=()=>{ Game.audio.click(); if(Game.Cloud.preload) Game.Cloud.preload(); from="menu"; show("profile"); render(); };
  $("btnProfS").onclick=()=>{ Game.audio.click(); if(Game.Cloud.preload) Game.Cloud.preload(); from="settings"; show("profile"); render(); };
  $("btnProfBack").onclick=()=>{ Game.audio.click(); show(from); api.refreshMenu(); };
  const prevLang=Game.onLang2; Game.onLang2=()=>{ if(prevLang) prevLang(); api.refreshMenu(); if($("profile").classList.contains("on")) render(); };
  api.refreshMenu(); api.render=render;
  return api; })();
