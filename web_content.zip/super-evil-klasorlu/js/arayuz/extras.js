"use strict";
/* ===== EK ÖZELLİKLER: yıkım puanı + seri sayacı, kuş sürüleri, ıslak yollar (yağmur), ilk oyun ipucu, fotoğraf modu (arayüzü gizle) ===== */
(function(){
const D=Game.D, $=id=>document.getElementById(id), clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
/* ---------- yıkım puanı + seri ---------- */
let score=0, shown=0, combo=0, comboT=0, best=parseInt(store.get("best","0"))||0, idleT=99, lastMult=1, bestT=0, lastTxt="", lastLang=currentLang, hintT=0, hinted=store.get("hint","0")==="1";
const el=$("dscore"), ev=$("dsv"), ec=$("dcmb"), eb=$("dbest");
const k0=D.kill; D.kill=function(c){ const was=c.alive, r=k0.apply(this,arguments);
  if(was&&!c.alive&&Game.mode==="play"){ const vol=(c.sx||1)*(c.sy||1)*(c.sz||1), pts=Math.round(2+Math.min(60,vol*.4)); combo++; comboT=3.4; idleT=0; score+=pts*mult(); }
  return r; };
function mult(){ return combo<40?1:combo<120?2:combo<260?3:combo<450?4:5; }
const eM=enterMode; enterMode=function(m){ const prev=Game.mode; eM(m); if(m==="play"&&prev==="menu"){ score=0; shown=0; combo=0; comboT=0; idleT=99; lastTxt=""; }
  if(m!=="play"){ const h=$("hud"); if(h) h.classList.remove("photo"); } };
Game.score=()=>score; Game.resetScore=()=>{ score=0; shown=0; combo=0; }; Game.addScore=pts=>{ combo++; comboT=3.4; idleT=0; score+=Math.round(pts*mult()); };
const pb=$("photoBtn"); if(pb) pb.onclick=()=>{ Game.audio.click(); $("hud").classList.toggle("photo"); };
Game.updaters.push((dt,time,raw)=>{ const d=raw||dt, play=Game.mode==="play";
  if(play){ comboT-=d; if(comboT<=0&&combo>0) combo=0; idleT+=d; }
  shown+=(score-shown)*Math.min(1,d*7); if(Math.abs(score-shown)<1) shown=score;
  const txt=Math.round(shown).toLocaleString("en-US").replace(/,/g,"."); if(el){ if(txt!==lastTxt||lastLang!==currentLang){ lastTxt=txt; lastLang=currentLang; if(ev) ev.textContent=txt; }
    el.classList.toggle("on",play&&score>0); el.classList.toggle("idle",idleT>8);
    const m=mult(); if(ec){ const cs=combo>=15?t("combo")+" ×"+m+" · "+combo:""; if(ec.textContent!==cs) ec.textContent=cs; ec.classList.toggle("on",combo>=15); if(m>lastMult){ ec.classList.remove("pop"); void ec.offsetWidth; ec.classList.add("pop"); } lastMult=m; }
    if(score>best){ best=score; bestT=2; } if(bestT>0){ bestT-=d; if(bestT<=0) store.set("best",String(best)); } if(eb) eb.textContent=best>0?"★ "+best.toLocaleString("en-US").replace(/,/g,"."):""; }
  /* ilk oyun ipucu */
  if(play&&!hinted){ hintT+=d; if(hintT>1.8){ hinted=true; store.set("hint","1"); Game.toast("t_hint",7000); } } });

/* ---------- ıslak yollar: yağmurda yol/zemin pürüzlülüğü azalır (gökyüzü yansır) ---------- */
{ const rm=Game.CG&&Game.CG.roadMat, tm=Game.CG&&Game.CG.terrainMat; let last=-1;
  Game.updaters.push(()=>{ const r=Math.round((Game.rainK||0)*20)/20; if(r===last) return; last=r; if(rm) rm.roughness=.9-.55*r; if(tm) tm.roughness=.97-.3*r; }); }

/* ---------- kuş sürüleri (nokta sprite, kanat çırpma gölgelendiricide) ---------- */
{ const NB=36, FL=6, ph=new Float32Array(NB), pos=new Float32Array(NB*3), fl=[];
  for(let i=0;i<FL;i++) fl.push({a:Math.random()*6.28,R:70+Math.random()*230,h:55+Math.random()*60,w:(.035+Math.random()*.03)*(Math.random()<.5?-1:1),ox:(Math.random()-.5)*60,oz:(Math.random()-.5)*60});
  for(let i=0;i<NB;i++) ph[i]=Math.random()*6.28;
  const g=new THREE.BufferGeometry(); g.setAttribute("position",new THREE.BufferAttribute(pos,3)); g.setAttribute("ph",new THREE.BufferAttribute(ph,1));
  const u={time:{value:0},scale:{value:800},vis:{value:0},cam:{value:new THREE.Vector3()}};
  const m=new THREE.ShaderMaterial({transparent:true,depthWrite:false,uniforms:u,
    vertexShader:"attribute float ph; uniform float scale,vis; uniform vec3 cam; varying float vph; varying float va; void main(){ vec4 mv=viewMatrix*vec4(position,1.); gl_Position=projectionMatrix*mv; float d=max(-mv.z,1.); gl_PointSize=clamp(1.7*scale/d,4.,70.); vph=ph; va=vis*(1.-smoothstep(120.,520.,d))*step(0.,-mv.z); }",
    fragmentShader:"uniform float time; varying float vph; varying float va; float seg(vec2 p,vec2 a,vec2 b){ vec2 pa=p-a, ba=b-a; float h=clamp(dot(pa,ba)/dot(ba,ba),0.,1.); return length(pa-ba*h); }"
      +" void main(){ vec2 p=gl_PointCoord*2.-1.; p.y=-p.y; float f=sin(time*9.+vph)*.55; vec2 L=vec2(-.8,.25+f*.6), R=vec2(.8,.25+f*.6);"
      +" float d=min(seg(p,vec2(0.),L),seg(p,vec2(0.),R)); float a=smoothstep(.2,.08,d)*va; if(a<.05) discard; gl_FragColor=vec4(vec3(.07,.08,.1),a*.9); }"});
  const pts=new THREE.Points(g,m); pts.frustumCulled=false; pts.renderOrder=5; pts.visible=false; scene.add(pts);
  let q=1;
  Game.updaters.push((dt,time,raw)=>{ const d=raw||dt, play=Game.mode==="play", day=(1-(Game.night||0)), ok=play&&day>.35&&(Game.rainK||0)<.1&&Game.season!=="winter"&&camera.position.y<260;
    u.vis.value+=((ok?1:0)-u.vis.value)*Math.min(1,d*1.2); pts.visible=u.vis.value>.02; if(!pts.visible) return;
    const hq=Game.quality, qq=hq==="low"?14:hq==="medium"?24:36; if(qq!==q){ q=qq; g.setDrawRange(0,q); }
    u.time.value=time; u.cam.value.copy(camera.position); const hh=Game.three.renderer?Game.three.renderer.domElement.height:800; u.scale.value=hh/(2*Math.tan(camera.fov*Math.PI/360));
    for(let i=0;i<NB;i++){ const f=fl[i%FL], a=f.a+time*f.w, k=(i/FL|0), px=f.ox+Math.cos(a)*f.R+Math.sin(i*2.7)*5+k*3.1, pz=f.oz+Math.sin(a)*f.R+Math.cos(i*1.9)*5-k*2.4, py=f.h+Math.sin(time*.7+i)*2.2+k*1.3;
      pos[i*3]=px; pos[i*3+1]=py; pos[i*3+2]=pz; }
    g.attributes.position.needsUpdate=true; }); }
})();
