"use strict";
/* ===== ÖZEL İKONLAR: güç butonları için elle çizilmiş vektör ikonlar (emoji yok). Oyunun kırmızı/siyah/altın diline uygun, katmanlı degrade + vurgu çizgileri ===== */
Game.Icons=(function(){
const DEFS='<svg width="0" height="0" style="position:absolute" aria-hidden="true"><defs>'
+'<linearGradient id="ig-gold" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fff3b8"/><stop offset=".45" stop-color="#ffc94a"/><stop offset="1" stop-color="#b8701a"/></linearGradient>'
+'<linearGradient id="ig-steel" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#f6f9fd"/><stop offset=".5" stop-color="#aab6c6"/><stop offset="1" stop-color="#586578"/></linearGradient>'
+'<linearGradient id="ig-red" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ff9a80"/><stop offset=".45" stop-color="#ff3b30"/><stop offset="1" stop-color="#8a0c17"/></linearGradient>'
+'<linearGradient id="ig-ice" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#f4feff"/><stop offset=".5" stop-color="#8fdcff"/><stop offset="1" stop-color="#2a82cf"/></linearGradient>'
+'<linearGradient id="ig-fire" x1="0" y1="1" x2="0" y2="0"><stop offset="0" stop-color="#a50f08"/><stop offset=".4" stop-color="#ff4a12"/><stop offset=".75" stop-color="#ffb02e"/><stop offset="1" stop-color="#fff3a0"/></linearGradient>'
+'<linearGradient id="ig-pfire" x1="0" y1="1" x2="0" y2="0"><stop offset="0" stop-color="#34077a"/><stop offset=".38" stop-color="#8a2cff"/><stop offset=".72" stop-color="#e07aff"/><stop offset="1" stop-color="#fff0ff"/></linearGradient>'
+'<linearGradient id="ig-violet" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#eedcff"/><stop offset=".45" stop-color="#a46bff"/><stop offset="1" stop-color="#43199f"/></linearGradient>'
+'<linearGradient id="ig-water" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#d4f7ff"/><stop offset=".5" stop-color="#3fb4ff"/><stop offset="1" stop-color="#0a449a"/></linearGradient>'
+'<linearGradient id="ig-dark" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#4a4f60"/><stop offset="1" stop-color="#12141c"/></linearGradient>'
+'<linearGradient id="ig-skin" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffd9b8"/><stop offset=".5" stop-color="#f0a878"/><stop offset="1" stop-color="#b8663c"/></linearGradient>'
+'<linearGradient id="ig-rock" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#b79a86"/><stop offset=".5" stop-color="#6e5444"/><stop offset="1" stop-color="#2e2118"/></linearGradient>'
+'<linearGradient id="ig-sand" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffe9a8"/><stop offset="1" stop-color="#e0a030"/></linearGradient>'
+'<linearGradient id="ig-beam" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#fff"/><stop offset=".3" stop-color="#ff7a5a"/><stop offset="1" stop-color="#ff2a10" stop-opacity=".2"/></linearGradient>'
+'<linearGradient id="ig-beamv" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#e8ffff" stop-opacity=".1"/><stop offset=".5" stop-color="#9ff0ff"/><stop offset="1" stop-color="#fff"/></linearGradient>'
+'<radialGradient id="ig-iris" cx=".5" cy=".5" r=".5"><stop offset="0" stop-color="#fff2c0"/><stop offset=".35" stop-color="#ff5a2a"/><stop offset="1" stop-color="#6b0a10"/></radialGradient>'
+'<radialGradient id="ig-void" cx=".5" cy=".5" r=".5"><stop offset="0" stop-color="#000"/><stop offset=".7" stop-color="#0a0614"/><stop offset="1" stop-color="#2c1458"/></radialGradient>'
+'<radialGradient id="ig-sun" cx=".5" cy=".5" r=".5"><stop offset="0" stop-color="#fffbe0"/><stop offset=".5" stop-color="#ffd54a"/><stop offset="1" stop-color="#ff7a1a"/></radialGradient>'
+'<radialGradient id="ig-halo" cx=".5" cy=".5" r=".5"><stop offset="0" stop-color="#fff" stop-opacity=".95"/><stop offset="1" stop-color="#fff" stop-opacity="0"/></radialGradient>'
+'<radialGradient id="ig-ring" cx=".5" cy=".5" r=".5"><stop offset=".55" stop-color="#ffb347" stop-opacity="0"/><stop offset=".72" stop-color="#ffe9a0"/><stop offset=".86" stop-color="#ff6a1a"/><stop offset="1" stop-color="#7a1a8a" stop-opacity="0"/></radialGradient>'
+'</defs></svg>';
const OL='#14070b';
const S=body=>'<svg class="ig" viewBox="0 0 64 64" aria-hidden="true"><g stroke="'+OL+'" stroke-width="2.4" stroke-linejoin="round" stroke-linecap="round">'+body+'</g></svg>';
const G=(id)=>'url(#ig-'+id+')';
const N='stroke="none"';
const star=(cx,cy,r1,r2,n,rot)=>{ let d=""; for(let i=0;i<n*2;i++){ const a=rot+i*Math.PI/n, r=i%2?r2:r1; d+=(i?"L":"M")+(cx+Math.cos(a)*r).toFixed(1)+" "+(cy+Math.sin(a)*r).toFixed(1); } return d+"Z"; };
const I={};
/* ---- uçuş: roket-kahraman, hız çizgileri ---- */
I.fly=S('<path d="M7 41h14M3 49h13M11 57h13" stroke="#fff" stroke-opacity=".75" stroke-width="2.6" fill="none"/>'
 +'<g transform="rotate(42 34 31)"><path d="M28 47Q34 68 40 47Q37 54 34 51Q31 54 28 47Z" fill="'+G('fire')+'"/>'
 +'<path d="M26 36L15 49L15 54L28 48Z" fill="'+G('red')+'"/><path d="M42 36L53 49L53 54L40 48Z" fill="'+G('red')+'"/>'
 +'<path d="M34 5C43 15 45 30 42 47H26C23 30 25 15 34 5Z" fill="'+G('steel')+'"/>'
 +'<path d="M34 5C38.5 10 40.5 14.5 41 19H27C27.5 14.5 29.5 10 34 5Z" fill="'+G('red')+'"/>'
 +'<circle cx="34" cy="29" r="5.6" fill="'+G('ice')+'"/><path d="M31 27.4q2-2.3 4.6-1.4" stroke="#fff" stroke-width="1.6" fill="none"/>'
 +'<rect x="26" y="40" width="16" height="4.6" rx="1.5" fill="'+G('gold')+'"/></g>');
/* ---- yumruk: kırmızı eldiven, altın manşet, darbe patlaması ---- */
I.punch=S('<path d="'+star(32,30,29,17,9,-.3)+'" fill="'+G('fire')+'" stroke="none" opacity=".92"/>'
 +'<path d="M17 31C17 23 22 20 27 20H40C46 20 50 24 50 31V41C50 50 45 53 39 53H28C21 53 17 49 17 41Z" fill="'+G('red')+'"/>'
 +'<path d="M17.5 28C20 24 24 23 28 23H41C45 23 48 25 49.5 28" fill="none" stroke="#ffd0c0" stroke-width="1.6" stroke-opacity=".7"/>'
 +'<path d="M25.4 23.5V31M33.5 22.5V31M41.6 23.5V31" stroke="#8a0c17" stroke-width="2" fill="none"/>'
 +'<path d="M17 36C13 36 11 40 13 44C15 47 20 46 22 43" fill="'+G('red')+'"/>'
 +'<rect x="19" y="51" width="28" height="9" rx="2.5" fill="'+G('gold')+'"/><path d="M24 53v5M32 53v5M40 53v5" stroke="#8a5614" stroke-width="1.4" fill="none"/>');
/* ---- tut/boğ: pençe gibi kapanan el ---- */
I.choke=S('<path d="M10 44C10 34 14 28 22 27L24 40C21 43 17 46 12 48Z" fill="'+G('skin')+'"/>'
 +'<path d="M20 34V20Q20 15 24 15Q28 15 28 20V32" fill="'+G('skin')+'"/><path d="M28 31V15Q28 9 32.5 9Q37 9 37 15V31" fill="'+G('skin')+'"/>'
 +'<path d="M37 31V17Q37 12 41.5 12Q46 12 46 17V33" fill="'+G('skin')+'"/><path d="M46 33V25Q46 21 49.5 21Q53 21 53 25V40" fill="'+G('skin')+'"/>'
 +'<path d="M14 44C14 38 18 33 25 33H45C51 33 54 38 54 44C54 52 49 58 40 58H27C19 58 14 52 14 44Z" fill="'+G('skin')+'"/>'
 +'<path d="M22 16l2-5 2 5M31 10l2-6 2 6M40 13l2-5 2 5M49 22l1.6-4 1.6 4" fill="#ff3b30" stroke="#14070b" stroke-width="1.6"/>'
 +'<path d="M19 40c3 4 8 6 14 6" stroke="#fff" stroke-opacity=".5" stroke-width="1.8" fill="none"/>'
 +'<path d="M31 36l1 6M38 36l1 5" stroke="#b8663c" stroke-width="1.6" fill="none"/>');
/* ---- alkış: iki el + şok halkaları ---- */
I.clap=S('<path d="M12 22Q6 32 12 42M52 22Q58 32 52 42" fill="none" stroke="#9fe8ff" stroke-width="3" stroke-opacity=".85"/>'
 +'<path d="M7 16Q-1 32 7 48M57 16Q65 32 57 48" fill="none" stroke="#9fe8ff" stroke-width="2" stroke-opacity=".5"/>'
 +'<path d="M30 14C26 12 22 14 21 18L18 36C17 44 22 50 29 50H31V16Z" fill="'+G('skin')+'"/>'
 +'<path d="M34 14C38 12 42 14 43 18L46 36C47 44 42 50 35 50H33V16Z" fill="'+G('skin')+'"/>'
 +'<path d="M24 22l-1.5 12M27.5 19l-1 13M36.5 19l1 13M40 22l1.5 12" stroke="#b8663c" stroke-width="1.4" fill="none"/>'
 +'<rect x="21" y="50" width="22" height="9" rx="2.5" fill="'+G('gold')+'"/>'
 +'<path d="M32 5v5M23 8l2.5 4M41 8l-2.5 4" stroke="#fff3a0" stroke-width="2.6" fill="none"/>');
/* ---- lazer gözü: iris + ışın ---- */
I.laser=S('<path d="M34 32H63" stroke="url(#ig-beam)" stroke-width="9" fill="none" stroke-linecap="butt"/><path d="M34 32H63" stroke="#fff" stroke-width="2.6" fill="none" stroke-opacity=".9"/>'
 +'<path d="M2 32C9 20 20 13 31 13C42 13 51 20 56 32C51 44 42 51 31 51C20 51 9 44 2 32Z" fill="#f4f1ee"/>'
 +'<path d="M6 31C12 22 21 17 31 17" fill="none" stroke="#fff" stroke-width="2" stroke-opacity=".8"/>'
 +'<circle cx="30" cy="32" r="13.5" fill="'+G('iris')+'"/><circle cx="30" cy="32" r="13.5" fill="none" stroke="#6b0a10" stroke-width="1.6"/>'
 +'<ellipse cx="30" cy="32" rx="3.4" ry="9.5" fill="#14070b" stroke="none"/><path d="M24 26a8 8 0 0 1 6-4" stroke="#fff" stroke-width="2.2" fill="none"/>'
 +'<path d="M2 32C9 20 20 13 31 13" fill="none"/><path d="M1 24Q8 12 22 9M1 40Q8 52 22 55" fill="none" stroke-width="2"/>');
/* ---- dondur: kristal kar tanesi ---- */
I.freeze=S((()=>{ let a=""; for(let k=0;k<6;k++){ const r=k*60; a+='<g transform="rotate('+r+' 32 32)"><path d="M32 32V5" stroke="#14070b" stroke-width="7" fill="none"/><path d="M32 32V5M32 15L25 8M32 15L39 8M32 24L26 19M32 24L38 19" stroke="'+'#8fdcff'+'" stroke-width="3.4" fill="none"/><path d="M32 32V6" stroke="#f4feff" stroke-width="1.4" fill="none"/></g>'; }
  return a+'<path d="'+star(32,32,8.5,6.5,6,0)+'" fill="'+G('ice')+'"/><circle cx="32" cy="32" r="3" fill="#fff" stroke="none"/>'; })());
/* ---- ateş: üç katmanlı alev ---- */
I.fire=S('<path d="M32 3C35 13 46 17 49 30C52 44 44 59 32 59C20 59 12 47 15 34C17 26 22 22 22 13C27 16 29 21 29 26C33 19 33 10 32 3Z" fill="'+G('fire')+'"/>'
 +'<path d="M32 26C34 33 41 36 41 45C41 53 37 57 32 57C26 57 23 52 24 45C25 40 29 38 30 33C31 34 31.5 36 32 36Z" fill="#ffb02e" stroke="none"/>'
 +'<path d="M32 40C33 45 37 47 37 51.5C37 55 35 57 32 57C29 57 27.5 54.5 28 51.5C28.6 48.5 31 47 32 40Z" fill="#fff3a0" stroke="none"/>'
 +'<path d="M20 38C19 31 24 28 26 24" stroke="#ffd3a8" stroke-width="1.8" fill="none" stroke-opacity=".7"/>');
/* ---- meteor: kaya + ateş kuyruğu ---- */
I.meteor=S('<path d="M8 6C20 8 32 14 40 24L28 36C20 26 12 16 8 6Z" fill="'+G('fire')+'" stroke="none" opacity=".95"/>'
 +'<path d="M4 20C16 20 28 26 34 34M18 4C22 14 28 24 34 30" stroke="#ffb02e" stroke-width="3" fill="none" stroke-opacity=".8"/>'
 +'<circle cx="40" cy="39" r="17" fill="'+G('rock')+'"/><circle cx="34" cy="33" r="3.8" fill="#4a3628" stroke-width="1.6"/><circle cx="46" cy="44" r="4.6" fill="#4a3628" stroke-width="1.6"/><circle cx="40" cy="51" r="2.6" fill="#4a3628" stroke-width="1.4"/>'
 +'<path d="M30 28C34 23 41 22 46 25" stroke="#ffd9a8" stroke-width="2" fill="none" stroke-opacity=".7"/>'
 +'<path d="M55 20l3-3M58 28h4M52 12l1-4" stroke="#ffb02e" stroke-width="2.6" fill="none"/>');
/* ---- şimşek: altın çatallı yıldırım ---- */
I.lightning=S('<path d="M22 4H44L33 24H47L20 60L27 34H15Z" fill="'+G('gold')+'"/>'
 +'<path d="M24 7H40L30 25" stroke="#fffbe0" stroke-width="2" fill="none" stroke-opacity=".85"/>'
 +'<path d="M12 22L5 26L11 30L4 36M52 28L59 24L54 20L60 14" fill="none" stroke="#9fe8ff" stroke-width="2.6"/>'
 +'<path d="M50 44l5 4-4 3 4 5" fill="none" stroke="#9fe8ff" stroke-width="2.2"/>');
/* ---- yerçekimi kuyusu: spiral girdap + çekirdek ---- */
I.gravity=S('<circle cx="32" cy="32" r="28" fill="#1a0f33" stroke="#6b2bd6" stroke-width="2.2"/>'
 +'<path d="M32 6C48 6 58 18 58 32C58 45 48 56 36 56C25 56 18 48 18 40C18 33 24 28 30 28C35 28 38 31 38 35" fill="none" stroke="'+'#c9a0ff'+'" stroke-width="3.6"/>'
 +'<path d="M32 58C16 58 6 46 6 32C6 19 16 8 28 8" fill="none" stroke="#7b3bff" stroke-width="3" stroke-opacity=".85"/>'
 +'<path d="M50 14l4-1-1 4M12 50l-4 1 1-4" fill="none" stroke="#e8d4ff" stroke-width="2.2"/>'
 +'<circle cx="34" cy="35" r="6" fill="url(#ig-void)" stroke="#e8d4ff" stroke-width="1.8"/><circle cx="31.5" cy="32.5" r="1.6" fill="#fff" stroke="none"/>');
/* ---- zamanı yavaşlat: kum saati ---- */
I.timeslow=S('<path d="M15 4H49V9C49 19 40 26 38 32C40 38 49 45 49 55V60H15V55C15 45 24 38 26 32C24 26 15 19 15 9Z" fill="#cfe9f5" fill-opacity=".35"/>'
 +'<path d="M20 9H44C44 16 38 21 34 26H30C26 21 20 16 20 9Z" fill="'+G('sand')+'" stroke="none"/>'
 +'<path d="M30 33H34L38 40C42 44 44 48 44 55H20C20 48 22 44 26 40Z" fill="'+G('sand')+'" stroke="none"/><path d="M32 27V44" stroke="#e0a030" stroke-width="1.8"/>'
 +'<path d="M15 4H49V9C49 19 40 26 38 32C40 38 49 45 49 55V60H15V55C15 45 24 38 26 32C24 26 15 19 15 9Z" fill="none"/>'
 +'<rect x="11" y="1" width="42" height="7" rx="2.5" fill="'+G('gold')+'"/><rect x="11" y="57" width="42" height="7" rx="2.5" fill="'+G('gold')+'"/>'
 +'<path d="M21 12c1 5 4 8 7 11" stroke="#fff" stroke-width="1.8" fill="none" stroke-opacity=".8"/>');
/* ---- deprem: yarılan zemin, parlayan çatlak ---- */
I.quake=S('<path d="M2 36L22 30L26 38L20 46L30 52L24 62H2Z" fill="'+G('rock')+'"/><path d="M62 34L44 30L40 38L46 44L38 52L44 62H62Z" fill="'+G('rock')+'"/>'
 +'<path d="M22 30L26 38L20 46L30 52L24 62H44L38 52L46 44L40 38L44 30L33 33Z" fill="'+G('fire')+'"/>'
 +'<path d="M2 36H22M44 30H62" stroke="#d9c0a8" stroke-width="2.4" fill="none"/>'
 +'<path d="M8 22l5 8M20 14l4 10M56 20l-5 9M46 10l-4 12" stroke="#ffb02e" stroke-width="2.6" fill="none"/>'
 +'<path d="M26 5l5-3M36 8l6-3M30 16l7-3" stroke="#d9c0a8" stroke-width="2.2" fill="none"/><rect x="12" y="20" width="4" height="4" fill="#6e5444" stroke-width="1.4"/><rect x="50" y="14" width="5" height="5" fill="#6e5444" stroke-width="1.4"/>');
/* ---- PREMİUM: karadelik ---- */
I.blackhole=S('<circle cx="32" cy="32" r="29" fill="#07040f" stroke="#43199f" stroke-width="2"/>'
 +'<g fill="#fff" stroke="none"><circle cx="10" cy="14" r="1.2"/><circle cx="52" cy="10" r="1"/><circle cx="55" cy="48" r="1.3"/><circle cx="12" cy="52" r="1"/><circle cx="46" cy="22" r=".8"/></g>'
 +'<ellipse cx="32" cy="32" rx="27" ry="10" fill="url(#ig-ring)" stroke="none" transform="rotate(-18 32 32)"/>'
 +'<circle cx="32" cy="32" r="11" fill="url(#ig-void)" stroke="#ffe9a0" stroke-width="2.2"/>'
 +'<path d="M12 40C20 52 44 52 52 36" fill="none" stroke="#ffb347" stroke-width="2.6" stroke-opacity=".9"/><path d="M15 24C22 12 42 12 50 25" fill="none" stroke="#ffe9a0" stroke-width="2" stroke-opacity=".8"/>');
/* ---- PREMİUM: yörünge saldırısı ---- */
I.orbital=S('<path d="M26 0H38L42 40H22Z" fill="url(#ig-beamv)" stroke="none"/><path d="M29 0H35L36 40H28Z" fill="#fff" stroke="none" opacity=".9"/>'
 +'<ellipse cx="32" cy="48" rx="26" ry="9" fill="none" stroke="#ff4a3d" stroke-width="3"/><ellipse cx="32" cy="48" rx="16" ry="5.4" fill="none" stroke="#ffb02e" stroke-width="2.6"/>'
 +'<ellipse cx="32" cy="48" rx="8" ry="2.8" fill="#fff" stroke="none"/><path d="M4 48H12M52 48H60M32 36V40M32 56V60" stroke="#ff4a3d" stroke-width="2.6" fill="none"/>'
 +'<rect x="22" y="2" width="20" height="9" rx="2" fill="'+G('steel')+'"/><rect x="14" y="4" width="8" height="5" fill="#2a82cf" stroke-width="1.8"/><rect x="42" y="4" width="8" height="5" fill="#2a82cf" stroke-width="1.8"/>');
/* ---- PREMİUM: ateş kasırgası ---- */
I.tornado=S('<path d="M6 8H58C56 14 48 17 44 18H20C16 17 8 14 6 8Z" fill="'+G('fire')+'"/>'
 +'<path d="M14 22H50C48 27 42 30 40 31H24C22 30 16 27 14 22Z" fill="'+G('fire')+'"/><path d="M19 35H45C44 40 39 42 37 43H27C25 42 20 40 19 35Z" fill="'+G('fire')+'"/>'
 +'<path d="M25 47H39L34 60H30Z" fill="'+G('fire')+'"/>'
 +'<path d="M10 11h12M42 13h10M18 25h8M38 27h8M23 38h6" stroke="#fff3a0" stroke-width="2" fill="none" stroke-opacity=".8"/>'
 +'<rect x="4" y="19" width="5" height="4" fill="#6e5444" stroke-width="1.4" transform="rotate(20 6 21)"/><rect x="53" y="31" width="5" height="4" fill="#6e5444" stroke-width="1.4" transform="rotate(-18 55 33)"/><rect x="47" y="3" width="4" height="4" fill="#ffb02e" stroke-width="1.4"/>');
/* ---- PREMİUM: güneş patlaması ---- */
I.nova=S('<path d="'+star(32,32,31,18,12,0)+'" fill="'+G('fire')+'" stroke="none"/>'
 +'<path d="'+star(32,32,27,17,12,Math.PI/12)+'" fill="#ffd54a" stroke="none" opacity=".9"/>'
 +'<circle cx="32" cy="32" r="16.5" fill="url(#ig-sun)"/><circle cx="32" cy="32" r="16.5" fill="none"/>'
 +'<path d="M22 26Q26 20 33 20" stroke="#fff" stroke-width="2.4" fill="none" stroke-opacity=".9"/><circle cx="32" cy="32" r="29.5" fill="none" stroke="#fff3a0" stroke-width="1.4" stroke-dasharray="3 5" stroke-opacity=".8"/>');
/* ---- PREMİUM: tsunami ---- */
I.tsunami=S('<path d="M2 62V38C2 24 12 10 28 8C40 7 50 14 50 24C50 30 44 33 40 31C37 30 37 25 41 24C40 19 35 17 30 19C22 22 20 30 24 38C27 43 34 45 40 45C50 45 58 41 62 36V62Z" fill="'+G('water')+'"/>'
 +'<path d="M41 24C40 19 35 17 30 19C22 22 20 30 24 38" fill="none" stroke="#f4feff" stroke-width="3"/>'
 +'<path d="M30 10C36 7 46 9 50 17" fill="none" stroke="#fff" stroke-width="2.6" stroke-opacity=".85"/>'
 +'<g fill="#fff" stroke="none"><circle cx="46" cy="14" r="2"/><circle cx="52" cy="22" r="1.6"/><circle cx="36" cy="8" r="1.5"/><circle cx="55" cy="14" r="1.2"/></g>'
 +'<path d="M6 52Q14 47 22 52T38 52T54 52T62 50" fill="none" stroke="#d4f7ff" stroke-width="2.4" stroke-opacity=".8"/>');
/* ---- PREMİUM: VOID — siyah küre, beyaz göz, mor çatlaklar ---- */
I.void=S('<circle cx="32" cy="32" r="29" fill="url(#ig-void)" stroke="#8a5cff" stroke-width="2.4"/>'
 +'<path d="M32 3V12M32 52V61M3 32H12M52 32H61M11 11L17 17M53 11L47 17M11 53L17 47M53 53L47 47" stroke="#8a5cff" stroke-width="2.4" fill="none" stroke-opacity=".8"/>'
 +'<path d="M12 32C18 24 25 21 32 21C39 21 46 24 52 32C46 40 39 43 32 43C25 43 18 40 12 32Z" fill="#fff" stroke="#14070b"/>'
 +'<ellipse cx="32" cy="32" rx="5.2" ry="10" fill="#08040f" stroke="none"/><path d="M22 28Q27 24 32 24" stroke="#c9b0ff" stroke-width="1.6" fill="none"/>'
 +'<circle cx="32" cy="32" r="26" fill="none" stroke="#fff" stroke-width="1.2" stroke-opacity=".5"/>');
/* ---- VOID: gölge butonu — çözülen insan silüeti ---- */
I.shadow=S('<circle cx="32" cy="32" r="29" fill="#0b0716" stroke="#8a5cff" stroke-width="2.2"/>'
 +'<path d="M32 12C37 12 40 15.5 40 20C40 24 38 27 35.5 28.4L40.5 30C45 31.4 47 35 47 40V47H17V40C17 35 19 31.4 23.5 30L28.5 28.4C26 27 24 24 24 20C24 15.5 27 12 32 12Z" fill="#000" stroke="#8a5cff" stroke-width="2"/>'
 +'<circle cx="28.4" cy="19" r="1.6" fill="#fff" stroke="none"/><circle cx="35.6" cy="19" r="1.6" fill="#fff" stroke="none"/>'
 +'<g fill="#8a5cff" stroke="none"><rect x="17" y="48" width="4" height="4"/><rect x="24" y="51" width="3" height="3"/><rect x="31" y="49" width="4" height="4"/><rect x="39" y="52" width="3" height="3"/><rect x="45" y="48" width="3" height="3"/><rect x="21" y="55" width="2.5" height="2.5"/><rect x="35" y="56" width="2.5" height="2.5"/></g>'
 +'<path d="M17 47H47" stroke="#8a5cff" stroke-width="1.6" stroke-dasharray="3 3" fill="none"/>');
/* ---- VOID: toz butonu — çöken bina, yükselen toz ---- */
I.dust=S('<circle cx="32" cy="32" r="29" fill="#0b0716" stroke="#8a5cff" stroke-width="2.2"/>'
 +'<path d="M16 50V30H27V20H41V50Z" fill="#2a2440" stroke="#b9a0ff" stroke-width="2"/>'
 +'<g fill="#b9a0ff" stroke="none"><rect x="19" y="33" width="3" height="3"/><rect x="23" y="33" width="3" height="3"/><rect x="19" y="39" width="3" height="3"/><rect x="30" y="24" width="3" height="3"/><rect x="35" y="24" width="3" height="3"/><rect x="30" y="30" width="3" height="3"/><rect x="35" y="36" width="3" height="3"/></g>'
 +'<path d="M41 22L44 22L44 28L41 28M41 32H46V38H41" fill="#2a2440" stroke="#b9a0ff" stroke-width="1.8"/>'
 +'<g fill="#e8d4ff" stroke="none"><rect x="44" y="14" width="4" height="4"/><rect x="50" y="20" width="3" height="3"/><rect x="47" y="25" width="3" height="3"/><rect x="38" y="11" width="3" height="3"/><rect x="52" y="30" width="2.5" height="2.5"/><rect x="49" y="36" width="3" height="3"/><rect x="43" y="42" width="2.5" height="2.5"/></g>'
 +'<path d="M12 52Q32 58 52 52" stroke="#8a5cff" stroke-width="2" fill="none"/>');
/* ---- VIP çubuğu: taç ---- */
I.vip=S('<path d="M7 22L19 34L32 12L45 34L57 22L53 50H11Z" fill="'+G('gold')+'"/><rect x="10" y="50" width="44" height="8" rx="2" fill="'+G('gold')+'"/>'
 +'<circle cx="7" cy="20" r="4" fill="#ff3b30"/><circle cx="32" cy="10" r="4.4" fill="#9fe8ff"/><circle cx="57" cy="20" r="4" fill="#ff3b30"/>'
 +'<path d="M16 46H48" stroke="#8a5614" stroke-width="1.6" fill="none"/><path d="M32 44l-5-8 5-8 5 8Z" fill="#c9a0ff" stroke-width="1.8"/>');
/* ---- MYTHIC: zaman durdur, ruh hasadı, gezegen çarpması, mor alev, mor cehennem ---- */
I.chrono=S('<circle cx="32" cy="32" r="28" fill="'+G('gold')+'"/><circle cx="32" cy="32" r="22.5" fill="#1b0c3c"/><circle cx="32" cy="32" r="22.5" fill="url(#ig-void)" opacity=".55" stroke="none"/>'
 +'<path d="M32 12.5v4.5M32 47v4.5M12.5 32H17M47 32h4.5M18 18l3 3M46 18l-3 3M18 46l3-3M46 46l-3-3" stroke="#ffe08a" stroke-width="2.4" fill="none"/>'
 +'<path d="M32 32V17.5" stroke="#fff3b8" stroke-width="3.4" fill="none"/><path d="M32 32L43.5 38" stroke="#d2a8ff" stroke-width="3.4" fill="none"/><circle cx="32" cy="32" r="3.6" fill="#ffd54a"/>'
 +'<path d="M52 6l2.4 5.2L60 12l-5.6 1.2L52 18l-2.4-4.8L44 12l5.6-.8Z" fill="#e8d4ff" stroke-width="1.4"/>');
I.reap=S('<path d="M32 1C37 11 51 14 53 30C55 45 45 57 32 63C19 57 9 45 11 30C13 14 27 11 32 1Z" fill="'+G('pfire')+'" stroke="none" opacity=".92"/>'
 +'<path d="M32 13C22 13 14.5 20 14.5 30.5C14.5 36.5 17.5 41 22 43V50.5H42V43C46.5 41 49.5 36.5 49.5 30.5C49.5 20 42 13 32 13Z" fill="#f1e9fc"/>'
 +'<ellipse cx="25" cy="31" rx="4.8" ry="5.6" fill="#24084f"/><ellipse cx="39" cy="31" rx="4.8" ry="5.6" fill="#24084f"/><circle cx="25.6" cy="30.4" r="2.1" fill="#e07aff" stroke="none"/><circle cx="39.6" cy="30.4" r="2.1" fill="#e07aff" stroke="none"/>'
 +'<path d="M32 36.5l-2.8 5.4h5.6Z" fill="#24084f"/><path d="M26.5 50.5v-5.5M32 50.5v-5.5M37.5 50.5v-5.5" stroke="#24084f" stroke-width="1.8" fill="none"/>');
I.planet=S('<path d="M3 5C15 6 25 12 32 21L22 31C15 22 8 13 3 5Z" fill="'+G('pfire')+'"/><path d="M12 5C20 9 27 15 31 22" stroke="#fff0ff" stroke-width="2" fill="none" stroke-opacity=".8"/>'
 +'<circle cx="39" cy="39" r="21" fill="'+G('violet')+'"/><path d="M20 35Q39 27 58 38M23 47Q40 44 56 49" stroke="#fff" stroke-opacity=".38" stroke-width="2.6" fill="none"/>'
 +'<circle cx="46" cy="30" r="3.2" fill="#43199f" stroke="none" opacity=".6"/><circle cx="33" cy="46" r="2.4" fill="#43199f" stroke="none" opacity=".6"/>'
 +'<ellipse cx="39" cy="39" rx="33" ry="9.5" transform="rotate(-22 39 39)" fill="none" stroke="#ffd36a" stroke-width="3.8"/><ellipse cx="39" cy="39" rx="33" ry="9.5" transform="rotate(-22 39 39)" fill="none" stroke="#fff3b8" stroke-width="1.2" stroke-opacity=".7"/>');
I.violet=S('<path d="M32 3C35 13 46 17 49 30C52 44 44 59 32 59C20 59 12 47 15 34C17 26 22 22 22 13C27 16 29 21 29 26C33 19 33 10 32 3Z" fill="'+G('pfire')+'"/>'
 +'<path d="M32 26C34 33 41 36 41 45C41 53 37 57 32 57C26 57 23 52 24 45C25 40 29 38 30 33C31 34 31.5 36 32 36Z" fill="#e07aff" stroke="none"/>'
 +'<path d="M32 40C33 45 37 47 37 51.5C37 55 35 57 32 57C29 57 27.5 54.5 28 51.5C28.6 48.5 31 47 32 40Z" fill="#fff0ff" stroke="none"/>'
 +'<path d="M20 38C19 31 24 28 26 24" stroke="#f3d6ff" stroke-width="1.8" fill="none" stroke-opacity=".75"/>');
I.hellfire=S('<path d="M3 58H61" stroke="#1a0a2e" stroke-width="5" fill="none"/><path d="M6 58l5-4 4 3 6-5 5 4 6-5 5 4 6-4 5 3 6-4" stroke="#7a3cff" stroke-width="2" fill="none"/>'
 +'<path d="M12 56C8 44 12 36 14 28C18 34 20 38 19 46C20 52 17 55 16 56Z" fill="'+G('pfire')+'"/>'
 +'<path d="M26 56C20 40 28 28 32 8C37 22 44 34 40 56Z" fill="'+G('pfire')+'"/><path d="M32 56C29 46 33 38 35 30C38 40 38 48 36 56Z" fill="#fff0ff" stroke="none" opacity=".9"/>'
 +'<path d="M48 56C45 46 48 38 52 30C56 38 58 46 54 56Z" fill="'+G('pfire')+'"/>'
 +'<path d="M20 20l2 4M44 14l3 3M52 22l1.6 3" stroke="#e8d4ff" stroke-width="2" fill="none"/>');
I.myth=S('<path d="M7 24L19 36L32 14L45 36L57 24L53 52H11Z" fill="'+G('pfire')+'"/><rect x="10" y="52" width="44" height="8" rx="2" fill="'+G('gold')+'"/>'
 +'<path d="M32 22C34 28 39 30 39 36C39 41 36 44 32 44C28 44 25 41 26 36C27 32 30 30 31 26Z" fill="#fff0ff" stroke="none"/>'
 +'<circle cx="7" cy="22" r="3.6" fill="#ffd36a"/><circle cx="32" cy="12" r="4" fill="#e8d4ff"/><circle cx="57" cy="22" r="3.6" fill="#ffd36a"/>');
const API={ svg:n=>I[n]||"", names:Object.keys(I), init(){
  if(!document.getElementById("igDefs")){ const d=document.createElement("div"); d.id="igDefs"; d.innerHTML=DEFS; document.body.insertBefore(d,document.body.firstChild); }
  document.querySelectorAll(".act[data-act]").forEach(b=>{ const k=b.dataset.act; if(I[k]&&!b.dataset.ic){ b.dataset.ic="1"; b.innerHTML=I[k]; } }); } };
API.init();
return API;
})();
