"use strict";
/* ===== COIN GÖSTERGELERİ: HUD, ana menü çipi, mağaza bakiyesi, kazanç açılır yazıları ===== */
Game.CoinHud=(function(){
  const E=Game.Eco, Ev=Game.Ev, api={};
  const fmt=n=>{ try{ return Math.round(n).toLocaleString(currentLang==="tr"?"tr-TR":currentLang); }catch(e){ return String(Math.round(n)); } };
  api.fmt=fmt;
  const coinI=()=>'<i class="coin"></i>';
  function ensure(){ const hud=$("hud"); if(hud&&!$("coinBox")){ const d=document.createElement("div"); d.id="coinBox"; d.innerHTML=coinI()+'<b id="coinV">0</b><em id="boostTag">2×</em><div id="coinPops"></div>'; hud.appendChild(d); }
    const m=$("menu"); if(m&&!$("menuCoins")){ const b=document.createElement("button"); b.id="menuCoins"; b.type="button"; b.innerHTML=coinI()+'<b>0</b><span class="plus">+</span>'; b.onclick=()=>{ Game.audio.click(); shopTab="rewards"; show("shop"); renderShop(); }; m.appendChild(b); } }
  let shown=-1, anim=null;
  function paint(){ ensure(); const v=E.coins; const set=(el)=>{ if(el) el.textContent=fmt(v); }; set($("coinV")); const mc=$("menuCoins"); if(mc) mc.querySelector("b").textContent=fmt(v); const sb=$("shopCoins"); if(sb) sb.querySelector("b").textContent=fmt(v);
    const bt=$("boostTag"); if(bt){ const on=E.boosted(); bt.style.display=on?"":"none"; } }
  const SRC={building:"🏢",npc:"🧍",car:"🚗",gold:"✨",daily:"🎁",ad:"🎬",chest:"🎁",quest:"⭐"};
  api.pop=function(n,src){ const box=$("coinPops"); if(!box||Game.mode!=="play"||!Game.settings.coinPops) return; const d=document.createElement("div"); d.className="cpop"+(src==="gold"?" gold":"")+(n<0?" neg":""); d.innerHTML=(SRC[src]||"")+" "+(n>0?"+":"")+fmt(n)+coinI(); box.appendChild(d); setTimeout(()=>d.remove(),1900); while(box.childNodes&&box.childNodes.length>5) box.removeChild(box.firstChild); };
  Ev.on("coins",(n,src)=>{ paint(); if(n!==0&&src!=="sync"&&src!=="spend") api.pop(n,src); if(n>0&&Game.audio&&Game.audio.coin&&(src==="npc"||src==="building"||src==="car"||src==="gold")) Game.audio.coin(src==="gold"?1:.5); });
  Ev.on("boost",paint);
  let acc=0; Game.updaters.push((dt)=>{ acc-=dt; if(acc>0) return; acc=1; const bt=$("boostTag"); if(bt) bt.style.display=E.boosted()?"":"none"; });
  api.paint=paint; paint(); setTimeout(paint,50);
  return api; })();
