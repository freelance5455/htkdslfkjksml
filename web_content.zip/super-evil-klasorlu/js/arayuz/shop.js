"use strict";
/* ===== MAĞAZA v9: karakterler (fiyat/kilit/reklam), görünümler, güçler, premium + SüperPremium, sandıklar, ÖDÜLLER ===== */
const E9=()=>Game.Eco, fmtN=n=>Game.CoinHud?Game.CoinHud.fmt(n):String(n);
const coinHTML='<i class="coin"></i>';
function ptag(n){ const s=el("span","ptag"); s.innerHTML=coinHTML+"<b>"+fmtN(n)+"</b>"; return s; }
function shopMsg(key,rep){ let m=t(key); if(rep) for(const k in rep) m=m.replace(k,rep[k]); const tt=$("shopToast"); if(!tt) return; tt.textContent=m; tt.classList.add("on"); clearTimeout(shopMsg.h); shopMsg.h=setTimeout(()=>tt.classList.remove("on"),2200); }
function needCoins(price){ const miss=price-E9().coins; shopMsg("s9_need",{"%n":fmtN(miss)}); if(Game.audio.deny) Game.audio.deny(); const sb=$("shopCoins"); if(sb){ sb.classList.remove("shake"); void sb.offsetWidth; sb.classList.add("shake"); } }
function afterBuy(){ if(Game.audio.buy) Game.audio.buy(); shopMsg("s9_bought"); renderShop(); }
/* fiyat düğmesi: yeterli coin → satın al */
function buyBtn(kind,id,extra){ const E=E9(), p=E.price(kind,id), can=E.canAfford(p), b=el("button","pbtn buy"+(can?"":" poor")); b.innerHTML=t("s9_buy")+" "; b.appendChild(ptag(p));
  b.onclick=e=>{ e.stopPropagation(); Game.audio.click(); const r=E.buy(kind,id); if(r.ok){ if(extra) extra(); afterBuy(); } else if(r.why==="coins") needCoins(p); };
  return b; }
/* reklam düğmesi: 1/2 gibi ilerleme */
function adBtn(kind,id){ const E=E9(), c=E.CAT[kind][id]; if(!c||!c.ad) return null; const have=E.adProgress(kind,id), b=el("button","pbtn adb"); b.innerHTML='<span class="adic">▶</span> '+(c.ad>1?t("s9_adp").replace("%a",have).replace("%b",c.ad):t("s9_watch"));
  b.onclick=e=>{ e.stopPropagation(); Game.Ads.show(ok=>{ if(!ok) return; const r=E.adStep(kind,id); if(r&&r.done){ if(Game.audio.buy) Game.audio.buy(); shopMsg("s9_unlocked"); } renderShop(); }); };
  return b; }
function renderChars(body){ const E=E9(), row=el("div","cards grid");
  CHAR_IDS.forEach(id=>{ const own=E.hasChar(id), sel=Game.char===id, c=el("div","card shopc"+(sel?" sel":"")+(own?"":" locked")), pv=el("div","pv"), im=el("img"); im.dataset.pv=id+"|"+(sel?Game.skin:0)+"|"+(sel?(Game.accent||""):""); im.alt=id; pv.appendChild(im); if(!own){ const lk=el("div","lockic"); lk.innerHTML='<svg viewBox="0 0 24 24"><rect x="5" y="11" width="14" height="10" rx="2.5"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/></svg>'; pv.appendChild(lk); } c.appendChild(pv);
    c.appendChild(el("div","nm",CHARS[id].icon+" "+t("c_"+id)));
    if(own){ const b=el("button","btn"+(sel?" main":""),sel?t("selected"):t("select")); c.onclick=()=>{ Game.audio.click(); if(Game.char!==id) Game.setCharacter(id,0,""); renderShop(); }; c.appendChild(b); }
    else { const w=el("div","pbox"); w.appendChild(buyBtn("chars",id)); const ab=adBtn("chars",id); if(ab) w.appendChild(ab); c.appendChild(w); }
    row.appendChild(c); });
  body.appendChild(row); fillPreviews(); }
function renderSkins(body){ const wrap=el("div"); wrap.style.cssText="display:flex;gap:26px;align-items:flex-start;justify-content:center;flex-wrap:wrap;padding:4px";
  const pv=el("div","card sel"); pv.style.cssText="flex:0 0 230px;height:380px"; const pw=el("div","pv"), im=el("img"); im.dataset.pv=Game.char+"|"+Game.skin+"|"+(Game.accent||""); pw.appendChild(im); pv.appendChild(pw); pv.appendChild(el("div","nm",CHARS[Game.char].icon+" "+t("c_"+Game.char))); wrap.appendChild(pv);
  const right=el("div"); right.style.cssText="flex:1 1 300px;max-width:470px"; const sk=el("div","skinrow");
  const isVip=!!CHARS[Game.char].vip, nSk=isVip?CHARS[Game.char].skins.length:SKIN_COUNT;
  for(let i=0;i<nSk;i++){ const d=el("div","sk"+(Game.skin===i&&!Game.accent?" sel":"")), ii=el("img"); ii.dataset.pv=Game.char+"|"+i+"|"; d.appendChild(ii); d.onclick=()=>{ Game.audio.click(); Game.setCharacter(null,i,""); renderShop(); }; sk.appendChild(d); }
  right.appendChild(sk); const ac=el("div","acc"); if(!isVip){ right.appendChild(el("span","lbl",t("maincol"))); ACCENTS.forEach(c=>{ const d=el("div","skin"+((Game.accent||"")===c?" sel":"")); d.style.background=c; d.onclick=()=>{ Game.audio.click(); Game.setCharacter(null,null,c); renderShop(); }; ac.appendChild(d); }); right.appendChild(ac); }
  wrap.appendChild(right); body.appendChild(wrap); fillPreviews(); }
function renderPowers(body){ const E=E9(), list=el("div","plist");
  POWER_IDS.forEach(p=>{ const own=E.hasPower(p), r=el("div","pw"+(own?"":" locked")), on=Game.powersPref[p]!==false; { const ic=el("div","ic"); ic.innerHTML=Game.Icons.svg(p); r.appendChild(ic); }
    const tx=el("div","tx"); tx.appendChild(el("b",null,t(p==="punch"?"p_punch":"p_"+p))); tx.appendChild(el("span",null,t("q_"+p))); const pr=E.CAT.powers[p]; if(pr&&pr.p===0) tx.appendChild(el("span","freel",t("s9_free"))); r.appendChild(tx);
    if(own){ const tg=el("button","tg"+(on?" on":""),on?t("on"):t("off")); if(p==="fly"){ tg.disabled=true; } else tg.onclick=()=>{ Game.powersPref[p]=!(Game.powersPref[p]!==false); store.set("powers",JSON.stringify(Game.powersPref)); applyPowers(); Game.audio.click(); renderShop(); }; r.appendChild(tg); }
    else { const w=el("div","pbox v"); w.appendChild(buyBtn("powers",p)); const ab=adBtn("powers",p); if(ab) w.appendChild(ab); r.appendChild(w); }
    list.appendChild(r); }); body.appendChild(list); }
const VIPFX={void:"rgba(140,90,255,.3)",inferno:"rgba(255,90,20,.32)",frost:"rgba(120,200,255,.32)",storm:"rgba(80,140,255,.32)",seraph:"rgba(255,220,120,.34)",kronos:"rgba(170,90,255,.5)",nekro:"rgba(120,60,200,.5)",kozmos:"rgba(200,100,255,.5)",neondrake:"rgba(255,230,0,.45)",altin:"rgba(255,200,40,.55)"};
function vipCard(id,kind){ const E=E9(), P=Game.Premium, own=P.hasSkin(id), sel=Game.char===id, sks=CHARS[id].skins, si=sel?Game.skin:(vipSkinSel[id]||0), spr=kind==="spr", c=el("div","vcard"+(spr?" spr":"")+(sel?" sel":"")+(own?"":" locked"));
  c.style.setProperty("--vg",VIPFX[id]||""); c.appendChild(el("div","vrib",spr?t("s9_super"):"VIP"));
  const pv=el("div","pv"), im=el("img"); im.dataset.pv=id+"|"+si+"|"; im.alt=id; pv.appendChild(im); c.appendChild(pv);
  c.appendChild(el("div","nm",t("c_"+id))); c.appendChild(el("div","ds",t("cd_"+id)));
  const own2=Game.SKIN_POWER&&Game.SKIN_POWER[id]; if(own2){ const ip=el("div","inclp"); ip.innerHTML='<span>'+t("s9_incl")+'</span> <b>'+t("p_"+own2)+'</b>'; c.appendChild(ip); }
  const row=el("div","vsk"); if(sks.length>1) sks.forEach((s,i)=>{ const d=el("i",i===si?"on":""), eye=(s[5]&&s[5].eye!==undefined)?hex6(s[5].eye):"#fff"; d.style.background="linear-gradient(135deg,"+s[0]+" 0 48%,"+(s[2]&&s[2]!=="#000000"?s[2]:eye)+" 52%)"; d.onclick=e=>{ e.stopPropagation(); Game.audio.click(); vipSkinSel[id]=i; if(own&&sel) Game.setCharacter(id,i,""); renderShop(); }; row.appendChild(d); });
  c.appendChild(row);
  if(own){ const b=el("button","pbtn"+(sel?" own":""),sel?t("selected"):t("select")); const act=()=>{ Game.audio.click(); if(!sel) Game.setCharacter(id,si,""); renderShop(); }; b.onclick=e=>{ e.stopPropagation(); act(); }; c.onclick=act; c.appendChild(b); }
  else c.appendChild(buyBtn(kind,id,()=>{ Game.setCharacter(id,si,""); }));
  return c; }
function renderPremium(body){ const E=E9(), P=Game.Premium;
  const ban=el("div","pbanner"), cr=el("div","pcrown"); cr.innerHTML=Game.Icons.svg("vip"); ban.appendChild(cr); const tx=el("div","ptx"); tx.appendChild(el("b",null,t("prem_title"))); tx.appendChild(el("span",null,t("s9_sub"))); ban.appendChild(tx); body.appendChild(ban);
  body.appendChild(el("div","psec",t("s9_vip"))); const g=el("div","vgrid"); Game.VIP_IDS.forEach(id=>g.appendChild(vipCard(id,"vip"))); body.appendChild(g);
  if(Game.SUPER_IDS&&Game.SUPER_IDS.length){ body.appendChild(el("div","psec spsec",t("s9_super"))); const sg=el("div","vgrid sgrid"); Game.SUPER_IDS.forEach(id=>sg.appendChild(vipCard(id,"spr"))); body.appendChild(sg); }
  if(Game.SKIN_POWER){ body.appendChild(el("div","psec spsec",t("s9_mpow"))); const mg=el("div","pgrid mgrid");
    P.MPW.forEach(p=>{ const own=P.hasPower(p), r=el("div","prow myth"+(own?"":" lockd")), ic=el("div","ic mfw"); ic.innerHTML=Game.Icons.svg(p); r.appendChild(ic);
      const x=el("div","tx"); x.appendChild(el("b",null,t("p_"+p))); x.appendChild(el("span",null,t("q_"+p))); x.appendChild(el("span","cdn",t("prem_cd")+" "+PW_CD[p]+" "+t("prem_sec")));
      const sk=Object.keys(Game.SKIN_POWER).find(k=>Game.SKIN_POWER[k]===p); if(sk) x.appendChild(el("span","cdn inc",t("s9_incl_by")+" "+t("c_"+sk)));
      r.appendChild(x); if(own) r.appendChild(el("button","pbtn own",t("prem_owned"))); else if(!sk) r.appendChild(buyBtn("mpow",p)); mg.appendChild(r); });
    body.appendChild(mg); P.flames(mg); }
  body.appendChild(el("div","psec",t("s9_vpow"))); const pg=el("div","pgrid");
  Object.keys(E.CAT.vpow).forEach(p=>{ const own=P.hasPower(p), r=el("div","prow"), ic=el("div","ic"); ic.innerHTML=Game.Icons.svg(p); r.appendChild(ic);
    const x=el("div","tx"); x.appendChild(el("b",null,t("p_"+p))); x.appendChild(el("span",null,t("q_"+p))); x.appendChild(el("span","cdn",t("prem_cd")+" "+PW_CD[p]+" "+t("prem_sec"))); r.appendChild(x);
    if(own) r.appendChild(el("button","pbtn own",t("prem_owned"))); else r.appendChild(buyBtn("vpow",p)); pg.appendChild(r); });
  body.appendChild(pg); fillPreviews(); }
/* ---- sandık çizimi (SVG) ---- */
let chestUid=0;
function chestSVG(tier){ const u=++chestUid, P={bronze:{b:["#c98a4b","#8a5428","#4e2c12"],t:["#e9c690","#a8742e"],gem:null,glow:"rgba(255,170,80,.55)",wood:true},
    silver:{b:["#9cc0f0","#5a7fc0","#2b4380"],t:["#ffffff","#a9bddc"],gem:"#6ee7ff",glow:"rgba(130,200,255,.6)"},
    gold:{b:["#ffe27a","#e0a020","#8f5a0a"],t:["#fff6c8","#e6b030"],gem:"#ff3b5c",glow:"rgba(255,215,80,.75)",crown:true},
    diamond:{b:["#d8fbff","#6fd0f5","#1d73b0"],t:["#ffffff","#b8e8ff"],gem:"#ffffff",glow:"rgba(150,235,255,.85)",crystal:true},
    cyber:{b:["#3a2a70","#1a1240","#0a0720"],t:["#ff4df0","#7b3cff"],gem:"#00f5ff",glow:"rgba(255,60,240,.75)",cyber:true}}[tier];
  const grad=(id,c)=>'<linearGradient id="'+id+u+'" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="'+c[0]+'"/><stop offset=".55" stop-color="'+c[1]+'"/><stop offset="1" stop-color="'+(c[2]||c[1])+'"/></linearGradient>';
  const rivets=[40,66,96,124,154,180].map(x=>'<circle cx="'+x+'" cy="100" r="2.6" fill="'+P.t[0]+'" stroke="rgba(0,0,0,.35)" stroke-width=".8"/>').join("");
  return '<svg viewBox="0 0 220 190" class="chestsvg '+tier+'" aria-hidden="true"><defs>'+grad("b",P.b)+grad("t",P.t)+'<radialGradient id="g'+u+'"><stop offset="0" stop-color="#fff" stop-opacity=".95"/><stop offset=".45" stop-color="'+(P.gem||"#fff")+'"/><stop offset="1" stop-color="#000" stop-opacity=".5"/></radialGradient><radialGradient id="o'+u+'"><stop offset="0" stop-color="#fff8d0"/><stop offset=".4" stop-color="'+P.glow+'"/><stop offset="1" stop-color="rgba(255,200,80,0)"/></radialGradient></defs>'
  +'<ellipse cx="110" cy="176" rx="86" ry="9" fill="rgba(0,0,0,.45)"/>'
  +'<g class="cglow"><ellipse cx="110" cy="96" rx="92" ry="34" fill="url(#o'+u+')"/></g>'
  +'<g class="cbody"><rect x="26" y="90" width="168" height="78" rx="11" fill="url(#b'+u+')" stroke="rgba(0,0,0,.4)" stroke-width="1.4"/>'
  +(P.wood?'<path d="M26 116H194M26 142H194" stroke="rgba(0,0,0,.28)" stroke-width="2"/><path d="M40 100v14M150 124v14M80 146v14M176 98v14" stroke="rgba(0,0,0,.18)" stroke-width="2"/>':'<rect x="34" y="98" width="152" height="62" rx="8" fill="none" stroke="'+P.t[0]+'" stroke-opacity=".55" stroke-width="1.6"/>')
  +'<rect x="50" y="90" width="17" height="78" fill="url(#t'+u+')" stroke="rgba(0,0,0,.35)" stroke-width="1"/><rect x="153" y="90" width="17" height="78" fill="url(#t'+u+')" stroke="rgba(0,0,0,.35)" stroke-width="1"/>'
  +'<rect x="22" y="152" width="176" height="18" rx="7" fill="url(#t'+u+')" stroke="rgba(0,0,0,.4)" stroke-width="1.2"/>'+rivets
  +'<rect x="94" y="84" width="32" height="34" rx="8" fill="url(#t'+u+')" stroke="rgba(0,0,0,.45)" stroke-width="1.4"/><circle cx="110" cy="98" r="5.2" fill="#2a1a0a"/><rect x="108" y="98" width="4" height="10" rx="2" fill="#2a1a0a"/></g>'
  +'<g class="clid"><path d="M26 92Q26 34 110 28Q194 34 194 92Z" fill="url(#b'+u+')" stroke="rgba(0,0,0,.4)" stroke-width="1.4"/>'
  +(P.wood?'<path d="M44 80Q70 50 110 46M176 80Q150 50 110 46" stroke="rgba(0,0,0,.22)" stroke-width="2" fill="none"/>':'<path d="M40 86Q44 46 110 38Q176 46 180 86" fill="none" stroke="'+P.t[0]+'" stroke-opacity=".6" stroke-width="2"/>')
  +'<path d="M50 92Q52 52 70 42L70 92Z" fill="url(#t'+u+')" stroke="rgba(0,0,0,.3)" stroke-width="1"/><path d="M170 92Q168 52 150 42L150 92Z" fill="url(#t'+u+')" stroke="rgba(0,0,0,.3)" stroke-width="1"/>'
  +'<rect x="22" y="84" width="176" height="14" rx="7" fill="url(#t'+u+')" stroke="rgba(0,0,0,.4)" stroke-width="1.2"/>'
  +(P.gem?'<circle cx="110" cy="46" r="11" fill="url(#g'+u+')" stroke="'+P.t[0]+'" stroke-width="2.4"/><circle cx="106" cy="42" r="3" fill="#fff" opacity=".8"/>':'')
  +(P.crown?'<path d="M84 34L92 18L101 30L110 12L119 30L128 18L136 34Z" fill="url(#t'+u+')" stroke="rgba(0,0,0,.4)" stroke-width="1.2"/>':'')
  +(P.crystal?'<path d="M26 92L60 60L110 28L160 60L194 92M60 60L110 92L160 60M110 28V92" stroke="#fff" stroke-opacity=".7" stroke-width="1.4" fill="none"/><path d="M92 18L110 4L128 18L110 34Z" fill="url(#t'+u+')" stroke="#fff" stroke-width="1.2"/><path d="M180 40l4 9 9 4-9 4-4 9-4-9-9-4 9-4z" fill="#fff" opacity=".9"/><path d="M36 54l3 6 6 3-6 3-3 6-3-6-6-3 6-3z" fill="#fff" opacity=".8"/>':'')
  +(P.cyber?'<path d="M34 80H78L92 66H128L142 80H186M60 60V80M160 60V80M110 40V66" stroke="'+P.gem+'" stroke-width="2" fill="none" stroke-linecap="round"/><circle cx="60" cy="60" r="3" fill="'+P.t[0]+'"/><circle cx="160" cy="60" r="3" fill="'+P.t[0]+'"/><path d="M26 100H194M26 124H194M26 148H194" stroke="'+P.t[0]+'" stroke-opacity=".35" stroke-width="1.2"/>':'')
  +'<path d="M40 60Q60 40 90 36" stroke="#fff" stroke-opacity=".35" stroke-width="3" fill="none" stroke-linecap="round"/></g></svg>'; }
function chestOdds(tier){ const o=E9().ODDS[tier]; let w=0; for(const r of o) w+=r[1]; return o.map(r=>({v:r[0],p:r[1]/w*100})).sort((a,b)=>b.v-a.v); }
function renderChests(body){ const E=E9(), g=el("div","chestgrid");
  ["bronze","silver","gold","diamond","cyber"].forEach(tier=>{ const c=el("div","chestcard "+tier), pr=E.CAT.chests[tier];
    const art=el("div","chestart"); art.innerHTML=chestSVG(tier); c.appendChild(art);
    c.appendChild(el("div","nm",t("ch_"+tier))); const mx=el("div","chmax"); mx.innerHTML=t("ch_max")+': '+coinHTML+'<b>'+fmtN(pr.max)+'</b>'; c.appendChild(mx);
    const ob=el("button","oddsb",t("ch_odds")+" ⓘ"); const od=el("div","oddsbox"); od.style.display="none"; chestOdds(tier).forEach(r=>{ const l=el("div","oddr"); l.innerHTML=coinHTML+'<b>'+fmtN(r.v)+'</b><span>'+(r.p<1?r.p.toFixed(1):r.p.toFixed(r.p<10?1:0))+'%</span>'; od.appendChild(l); }); od.appendChild(el("div","oddn",t("ch_note")));
    ob.onclick=e=>{ e.stopPropagation(); od.style.display=od.style.display==="none"?"block":"none"; }; c.appendChild(ob); c.appendChild(od);
    const b=el("button","pbtn buy"+(E.canAfford(pr.p)?"":" poor")); b.innerHTML=t("ch_open")+" "; b.appendChild(ptag(pr.p)); b.onclick=e=>{ e.stopPropagation(); Game.audio.click(); if(!E.canAfford(pr.p)){ needCoins(pr.p); return; } openChestUI(tier,false); }; c.appendChild(b); g.appendChild(c); });
  body.appendChild(g); }
/* sandık açma sahnesi */
function openChestUI(tier,free){ const E=E9(); if(!free&&!E.canAfford(E.CAT.chests[tier].p)){ needCoins(E.CAT.chests[tier].p); return; }
  const ov=el("div","chestfx "+tier); ov.innerHTML='<div class="cfback"></div><div class="cfrays"></div><div class="cfstage"><div class="cfchest"></div><div class="cfprompt"></div><div class="cfwin"><small></small><b><i class="coin"></i><span>0</span></b></div><div class="cfbtns"></div></div><div class="cfburst"></div>'; document.body.appendChild(ov);
  const stage=ov.querySelector(".cfchest"), prompt=ov.querySelector(".cfprompt"), win=ov.querySelector(".cfwin"), btns=ov.querySelector(".cfbtns"), burst=ov.querySelector(".cfburst");
  stage.innerHTML=chestSVG(tier); prompt.textContent=t("ch_tap"); let opened=false, prize=0;
  const close=()=>{ ov.remove(); if($("shop").classList.contains("on")) renderShop(); };
  const doOpen=()=>{ if(opened) return; opened=true; prize=E.openChest(tier,free); if(prize===null){ close(); return; } prompt.style.display="none"; if(Game.audio.chest) Game.audio.chest(0);
    stage.classList.add("shake"); setTimeout(()=>{ stage.classList.remove("shake"); stage.classList.add("open"); ov.classList.add("lit"); if(Game.audio.chest) Game.audio.chest(1);
      const n=Math.min(34,10+Math.round(Math.log10(prize)*8)); for(let i=0;i<n;i++){ const c=el("i","coin fly"); const a=Math.random()*Math.PI*2, d=90+Math.random()*190; c.style.setProperty("--dx",Math.cos(a)*d+"px"); c.style.setProperty("--dy",(Math.sin(a)*d*.7-90-Math.random()*60)+"px"); c.style.animationDelay=(Math.random()*.25)+"s"; burst.appendChild(c); }
      win.style.display="block"; win.querySelector("small").textContent=t("ch_got"); const sp=win.querySelector("span"); const t0=performance.now(), dur=900; (function tick(now){ const k=Math.min(1,(now-t0)/dur); sp.textContent=fmtN(prize*(1-Math.pow(1-k,3))); if(k<1) requestAnimationFrame(tick); else { sp.textContent=fmtN(prize); win.classList.add("pop"); if(prize>=E.CAT.chests[tier].max*.4) ov.classList.add("jackpot"); } })(t0);
      btns.innerHTML=""; const cb=el("button","pbtn",t("ch_collect")); cb.onclick=close; btns.appendChild(cb);
      if(!free){ const ag=el("button","pbtn buy"+(E.canAfford(E.CAT.chests[tier].p)?"":" poor")); ag.innerHTML=t("ch_again")+" "; ag.appendChild(ptag(E.CAT.chests[tier].p)); ag.onclick=()=>{ if(!E.canAfford(E.CAT.chests[tier].p)){ needCoins(E.CAT.chests[tier].p); return; } ov.remove(); openChestUI(tier,false); }; btns.appendChild(ag); }
    },750); };
  stage.onclick=doOpen; prompt.onclick=doOpen; ov.querySelector(".cfback").onclick=()=>{ if(opened&&win.classList.contains("pop")) close(); }; }
/* ---- ÖDÜLLER ---- */
function rewCard(cls,icon,title,sub,btnEl,extra){ const c=el("div","rwcard "+cls), ic=el("div","rwic"); ic.innerHTML=icon; c.appendChild(ic); const x=el("div","rwtx"); x.appendChild(el("b",null,title)); x.appendChild(el("span",null,sub)); if(extra) x.appendChild(extra); c.appendChild(x); c.appendChild(btnEl); return c; }
function renderRewards(body){ const E=E9(), S=E.S, g=el("div","rwgrid");
  /* günlük hediye */
  { const ready=E.dailyReady(), b=el("button","pbtn"+(ready?" buy":" own")); if(ready){ b.innerHTML=t("rw_claim")+" "; b.appendChild(ptag(E.dailyAmount())); b.onclick=()=>{ const n=E.claimDaily(); if(n){ if(Game.audio.buy) Game.audio.buy(); renderShop(); } }; } else b.textContent=t("rw_claimed");
    const dots=el("div","streak"); for(let i=0;i<7;i++){ const d=el("i",i<=Math.min(6,S.daily.streak)&&!ready?"on":(ready&&i<Math.min(6,S.daily.streak)?"on":"")); dots.appendChild(d); }
    g.appendChild(rewCard("daily",'<div class="gift"></div>',t("rw_daily"),t("rw_daily_s"),b,dots)); }
  /* sosyal takip ödülleri (Instagram, YouTube): bir kez 10.000 coin */
  const openLink=u=>{ try{ const B=window.Capacitor&&window.Capacitor.Plugins&&window.Capacitor.Plugins.Browser; if(B&&B.open){ B.open({url:u}); return; } }catch(e){} try{ window.open(u,"_blank","noopener"); }catch(e){ location.href=u; } };
  const socCard=(k,icon,title)=>{ const done=!!S.social[k], opened=!!(S.social.t&&S.social.t[k]), ready=E.socialReady(k); let b;
    if(done){ b=el("button","pbtn own",t("soc_done")); }
    else if(!opened){ b=el("button","pbtn buy",t("soc_go")); b.onclick=()=>{ Game.audio.click(); E.socialOpen(k); openLink(E.SOCIAL[k].url); renderShop(); }; }
    else if(!ready){ b=el("button","pbtn own",t("soc_wait")); b.onclick=()=>{ openLink(E.SOCIAL[k].url); }; setTimeout(()=>{ if(!document.hidden&&document.getElementById("shop")&&document.getElementById("shop").classList.contains("on")) renderShop(); },Math.max(400,12100-(Date.now()-S.social.t[k]))); }
    else { b=el("button","pbtn buy"); b.innerHTML=t("soc_claim")+" "; b.appendChild(ptag(E.SOCIAL[k].coin)); b.onclick=()=>{ const n=E.claimSocial(k); if(n){ if(Game.audio.buy) Game.audio.buy(); shopMsg("soc_got"); renderShop(); } }; }
    g.appendChild(rewCard("soc "+k,icon,title,t("soc_s"),b)); };
  socCard("ig",'<svg viewBox="0 0 48 48" class="socic"><defs><linearGradient id="igg" x1="0" y1="1" x2="1" y2="0"><stop offset="0" stop-color="#feda75"/><stop offset=".35" stop-color="#fa7e1e"/><stop offset=".6" stop-color="#d62976"/><stop offset="1" stop-color="#4f5bd5"/></linearGradient></defs><rect x="4" y="4" width="40" height="40" rx="12" fill="url(#igg)"/><rect x="12" y="12" width="24" height="24" rx="8" fill="none" stroke="#fff" stroke-width="3"/><circle cx="24" cy="24" r="6" fill="none" stroke="#fff" stroke-width="3"/><circle cx="32" cy="16" r="1.9" fill="#fff"/></svg>',t("soc_ig"));
  socCard("yt",'<svg viewBox="0 0 48 48" class="socic"><rect x="3" y="10" width="42" height="28" rx="9" fill="#ff1f1f"/><path d="M20 18l11 6-11 6z" fill="#fff"/></svg>',t("soc_yt"));
  const adCard=(key,cls,icon,title,sub,onReward,extraFn)=>{ const left=E.left(key,E.LIM[key]), b=el("button","pbtn adb"+(left?"":" own")); if(left){ b.innerHTML=t("rw_watch"); b.onclick=()=>{ Game.Ads.show(ok=>{ if(!ok) return; if(E.rewardAd(key)){ onReward&&onReward(); } renderShop(); }); }; } else b.textContent=t("rw_none");
    const cnt=el("span","rwleft",t("rw_left").replace("%n",left+"/"+E.LIM[key])); const ex=el("div","rwx"); ex.appendChild(cnt); if(extraFn){ const q=extraFn(); if(q) ex.appendChild(q); } g.appendChild(rewCard(cls,icon,title,sub,b,ex)); };
  adCard("c500","c500",'<div class="coinstack"></div>',t("rw_c500"),t("rw_c500_s"),()=>{ if(Game.audio.buy) Game.audio.buy(); shopMsg("s9_bought"); });
  adCard("chest","chest",chestSVG("bronze"),t("rw_chest"),t("rw_chest_s"),()=>{ setTimeout(()=>openChestUI("bronze",true),80); });
  adCard("boost","boost",'<div class="x2">2×</div>',t("rw_boost"),t("rw_boost_s"),()=>{ if(Game.audio.buy) Game.audio.buy(); },()=>{ if(E.boosted()){ const m=Math.ceil((S.boostUntil-Date.now())/60000); return el("span","rwon",t("rw_active").replace("%m",m)); } });
  adCard("trial","trial",'<div class="trialic">⚡</div>',t("rw_trial"),t("rw_trial_s"),()=>{ if(Game.audio.buy) Game.audio.buy(); },()=>{ if(S.trial&&S.trial.until>Date.now()){ const m=Math.ceil((S.trial.until-Date.now())/60000); return el("span","rwon",t("rw_trial_on").replace("%p",t("p_"+S.trial.p)).replace("%m",m)); } });
  body.appendChild(g); }
function renderShop(){
  const body=$("sbody"); body.innerHTML="";
  document.querySelectorAll("#shop .tab").forEach(b=>b.classList.toggle("on",b.dataset.tab===shopTab));
  if(Game.CoinHud) Game.CoinHud.paint();
  if(shopTab==="chars") renderChars(body); else if(shopTab==="powers") renderPowers(body); else if(shopTab==="premium") renderPremium(body); else if(shopTab==="chests") renderChests(body); else if(shopTab==="rewards") renderRewards(body); else renderSkins(body); }
{ const sc=$("shopCoins"); if(sc){ sc.onclick=()=>{ Game.audio.click(); shopTab="rewards"; renderShop(); }; } }

/* sahiplik değişince HUD güç düğmeleri güncellensin; deneme süresi bitince de */
Game.Ev.on("purchase",()=>{ applyPowers(); if(Game.Premium) Game.Premium.refresh(); });
Game.Ev.on("trial",()=>{ applyPowers(); });
{ let wasT=false, acc=0; Game.updaters.push(dt=>{ acc-=dt; if(acc>0) return; acc=1; const T=E9().S.trial, act=!!(T&&T.until>Date.now()); if(act!==wasT){ wasT=act; applyPowers(); if(!act&&Game.Ev) Game.Ev.emit("trialEnd"); } }); }

Game.shopMsg=shopMsg;
