"use strict";
/* ===== AYARLAR EKLERİ: polis anahtarı, Özelleştirme paneli (düğme boyutu/saydamlık, sarsıntı, FOV, altyazı, nişangâh, coin yazıları, hız birimi) ===== */
Game.Custom=(function(){
  const S=Game.settings, api={};
  const DEF={hs:1,ho:1,shake:1,fovAdd:0,subs:true,subSz:"m",cross:true,coinPops:true,mph:false,gyro:false,gyroS:1};
  const KEY={hs:"cu_hs",ho:"cu_ho",shake:"cu_shake",fovAdd:"cu_fov",subs:"cu_subs",subSz:"cu_subsz",cross:"cu_cross",coinPops:"cu_coinpop",mph:"cu_mph",gyro:"cu_gyro",gyroS:"cu_gyros"};
  const sv=(k)=>{ const v=S[k]; store.set(KEY[k],typeof v==="boolean"?(v?"1":"0"):String(v)); };
  api.apply=function(){ const r=document.documentElement.style; r.setProperty("--hs",S.hs); r.setProperty("--ho",S.ho);
    const c=$("cross"); if(c) c.style.visibility=S.cross?"":"hidden";
    const sp=document.querySelector("#speedo small"); if(sp) sp.textContent=S.mph?"mph":"km/h";
    const sb=$("subs"); if(sb) sb.className=(S.subs?"":"off ")+"sz-"+S.subSz;
    if(Game.Gyro) Game.Gyro.sync(); };
  /* ---- polis ---- */
  function markPolice(){ document.querySelectorAll("#polRow .btn").forEach(b=>b.classList.toggle("sel",(b.dataset.pol==="1")===!!S.police)); }
  document.querySelectorAll("#polRow .btn").forEach(b=>b.onclick=()=>{ Game.audio.click(); S.police=b.dataset.pol==="1"; store.set("police",S.police?"1":"0"); if(Game.Police&&Game.Police.onToggle) Game.Police.onToggle(S.police); markPolice(); });
  /* ---- özelleştirme paneli ---- */
  const cols=$("custCols"); const refs={};
  function slider(parent,key,lab,min,max,step,fmt){ const l=el("span","lbl"); const sp=el("span"); sp.dataset.i18n=lab; sp.textContent=t(lab); const val=el("b","clock"); l.appendChild(sp);  l.appendChild(val);
    const inp=document.createElement("input"); inp.type="range"; inp.min=min; inp.max=max; inp.step=step; inp.oninput=()=>{ S[key]=+inp.value; val.textContent=fmt(S[key]); sv(key); api.apply(); };
    parent.appendChild(l); parent.appendChild(inp); refs[key]=()=>{ inp.value=S[key]; val.textContent=fmt(S[key]); }; }
  function toggle(parent,key,lab){ const l=el("span","lbl"); l.dataset.i18n=lab; l.textContent=t(lab); const row=el("div","row"); const a=el("button","btn",t("on")), b=el("button","btn",t("off")); a.dataset.i18n="on"; b.dataset.i18n="off";
    a.onclick=()=>{ Game.audio.click(); S[key]=true; sv(key); api.apply(); refs[key](); }; b.onclick=()=>{ Game.audio.click(); S[key]=false; sv(key); api.apply(); refs[key](); };
    row.appendChild(a); row.appendChild(b); parent.appendChild(l); parent.appendChild(row); refs[key]=()=>{ a.classList.toggle("sel",!!S[key]); b.classList.toggle("sel",!S[key]); }; }
  function choice(parent,key,lab,opts){ const l=el("span","lbl"); l.dataset.i18n=lab; l.textContent=t(lab); const row=el("div","row"); const btns=opts.map(o=>{ const b=el("button","btn"); if(o[2]){ b.dataset.i18n=o[2]; b.textContent=t(o[2]); } else b.textContent=o[1]; b.onclick=()=>{ Game.audio.click(); S[key]=o[0]; sv(key); api.apply(); refs[key](); }; row.appendChild(b); return [o[0],b]; });
    parent.appendChild(l); parent.appendChild(row); refs[key]=()=>btns.forEach(([v,b])=>b.classList.toggle("sel",S[key]===v)); }
  if(cols){ const c1=el("div","col"), c2=el("div","col"); cols.appendChild(c1); cols.appendChild(c2);
    slider(c1,"hs","cu_hs",.8,1.2,.05,v=>Math.round(v*100)+"%"); slider(c1,"ho","cu_ho",.35,1,.05,v=>Math.round(v*100)+"%");
    slider(c1,"shake","cu_shake",0,1,.1,v=>Math.round(v*100)+"%"); slider(c1,"fovAdd","cu_fov",-10,24,1,v=>(v>0?"+":"")+v+"°");
    toggle(c2,"subs","cu_subs"); choice(c2,"subSz","cu_subsz",[["s","", "sz_s"],["m","","sz_m"],["l","","sz_l"]]);
    toggle(c2,"cross","cu_cross"); toggle(c2,"coinPops","cu_coin"); choice(c2,"mph","cu_mph",[[false,"km/h"],[true,"mph"]]);
    toggle(c2,"gyro","cu_gyro"); slider(c2,"gyroS","cu_gyros",.4,3,.1,v=>"×"+v.toFixed(1));
    const rs=el("button","btn"); rs.dataset.i18n="cu_reset"; rs.textContent=t("cu_reset"); rs.onclick=()=>{ Game.audio.click(); for(const k in DEF){ S[k]=DEF[k]; sv(k); } api.apply(); api.refresh(); }; c2.appendChild(rs);
    /* Gizlilik politikası bağlantısı (Play Store zorunluluğu): yalnız CONFIG.privacyUrl doluysa görünür */
    if(Game.CONFIG&&Game.CONFIG.privacyUrl){ const pv=el("button","btn"); pv.dataset.i18n="cu_privacy"; pv.textContent=t("cu_privacy"); pv.onclick=()=>{ Game.audio.click(); const u=Game.CONFIG.privacyUrl; try{ const B=window.Capacitor&&window.Capacitor.Plugins&&window.Capacitor.Plugins.Browser; if(B&&B.open){ B.open({url:u}); return; } }catch(e){} try{ window.open(u,"_blank","noopener"); }catch(e){ location.href=u; } }; c2.appendChild(pv); } }
  api.refresh=function(){ for(const k in refs) refs[k](); };
  Game.refreshExtra=function(){ markPolice(); api.refresh(); };
  $("btnCustS").onclick=()=>{ Game.audio.click(); show("custom"); api.refresh(); };
  $("btnCustBack").onclick=()=>{ Game.audio.click(); show("settings"); };
  api.apply(); api.refresh(); markPolice();
  return api; })();
