"use strict";
/* ===== SES v2: siren (ambulans/polis), coin/satın alma/sandık sesleri — Web Audio, dosya yok ===== */
(function(){ const a=Game.audio, V={};
  const ready=()=>a._ctx&&a._ctx()&&a._master&&a._master();
  /* tür: "amb" (iki tonlu), "cop" (yükselip alçalan) ; gain: 0..1 (mesafeye göre hesaplanmış) */
  a.siren=function(key,type,x,z,on){ const ctx=a._ctx&&a._ctx(); if(!ctx) return; let v=V[key]; const dist=on?a._vol(x,2,z):0, gain=Math.min(1,dist*1.5);
    if(!v){ if(!on||gain<.02) return; const m=a._master(), o=ctx.createOscillator(), o2=ctx.createOscillator(), lp=ctx.createBiquadFilter(), g=ctx.createGain(), lfo=ctx.createOscillator(), lg=ctx.createGain();
      o.type="sawtooth"; o2.type="square"; lp.type="lowpass"; lp.frequency.value=2400; lp.Q.value=.7; g.gain.value=0;
      if(type==="amb"){ o.frequency.value=750; o2.frequency.value=750; lfo.type="square"; lfo.frequency.value=1.15; lg.gain.value=135; }
      else { o.frequency.value=980; o2.frequency.value=980; lfo.type="triangle"; lfo.frequency.value=.42; lg.gain.value=330; }
      lfo.connect(lg); lg.connect(o.frequency); lg.connect(o2.frequency); const g2=ctx.createGain(); g2.gain.value=.45; o.connect(lp); o2.connect(g2); g2.connect(lp); lp.connect(g); g.connect(m); o.start(); o2.start(); lfo.start(); v=V[key]={g,o,o2,lfo,on:true}; }
    v.g.gain.setTargetAtTime(on?gain*.16:0,ctx.currentTime,.12);
    if(!on&&!v.dying){ v.dying=setTimeout(()=>{ try{ v.o.stop(); v.o2.stop(); v.lfo.stop(); v.g.disconnect(); }catch(e){} delete V[key]; },700); } };
  /* silah sesleri: tabanca, tank topu, füze */
  a.gun=function(x,y,z){ const T=a._t, N=a._n; if(!T||!ready()) return; const v=a._vol(x,y,z); if(v<.03) return; N(.08,2800,.9,.55*v,"bandpass",900); N(.16,300,.8,.5*v,"lowpass",90); T(190,55,.07,.4*v,"square"); };
  a.cannon=function(x,y,z){ const T=a._t, N=a._n; if(!T||!ready()) return; const v=a._vol(x,y,z); if(v<.03) return; N(.55,800,.7,.95*v,"lowpass",70); T(115,28,.55,.95*v,"sawtooth"); N(.12,3600,1,.35*v,"highpass"); };
  a.missile=function(x,y,z){ const T=a._t, N=a._n; if(!T||!ready()) return; const v=a._vol(x,y,z); if(v<.03) return; N(1,2000,1.2,.5*v,"bandpass",420); T(320,80,.9,.22*v,"sawtooth"); };
  a.sirenStopAll=function(){ for(const k in V) a.siren(k,"amb",0,0,false); };
  /* coin: iki kısa parlak ton */
  a.coin=function(big){ const T=a._t; if(!T||!ready()) return; const f=big>.8?1320:1040; T(f,f*1.01,.09,.13,"triangle"); setTimeout(()=>T(f*1.5,f*1.5,.16,.11,"triangle"),70); };
  a.deny=function(){ const T=a._t; if(!T||!ready()) return; T(220,140,.16,.18,"square"); setTimeout(()=>T(170,110,.2,.16,"square"),110); };
  a.buy=function(){ const T=a._t; if(!T||!ready()) return; [660,880,1175].forEach((f,i)=>setTimeout(()=>T(f,f,.14,.13,"triangle"),i*85)); setTimeout(()=>T(1568,1568,.3,.1,"sine"),270); };
  a.chest=function(stage){ const T=a._t, N=a._n; if(!T||!ready()) return; if(!stage){ N(.35,500,1,.35,"lowpass",120); T(90,50,.3,.35,"sawtooth"); } else { [523,659,784,1047,1319].forEach((f,i)=>setTimeout(()=>T(f,f,.22,.13,"triangle"),i*70)); N(.5,6000,1.5,.15,"highpass"); } };

  /* ejderha: kükreme, ateş soluğu, horultu */
  a.roar=function(x,y,z,k){ const T=a._t, N=a._n; if(!T||!ready()) return; const v=Math.max(.35,a._vol(x,y,z))*(k||1); N(1.7,260,.9,.9*v,"lowpass",60); T(98,36,1.6,.75*v,"sawtooth"); T(147,52,1.4,.35*v,"square"); N(.95,900,2,.3*v,"bandpass",300); };
  a.flame=function(x,y,z){ const N=a._n; if(!N||!ready()) return; const v=Math.max(.3,a._vol(x,y,z)); N(1.9,1500,.7,.5*v,"bandpass",320); N(1.6,380,.9,.35*v,"lowpass",90); };
  a.snore=function(x,y,z){ const T=a._t, N=a._n; if(!T||!ready()) return; const v=a._vol(x,y,z); if(v<.04) return; N(1.5,220,.8,.2*v,"lowpass",80); T(58,40,1.4,.13*v,"sine"); };
})();
