"use strict";
/* ===== SES: Web Audio ile sentetik efektler (dosya yok) ===== */
Game.audio = (function(){
  let ctx=null, master=null, noiseBuf=null, ambient=null, windG=null, windF=null, lastCrash=0; const loops={}, a={};
  function init(){ if(ctx) return; const AC=window.AudioContext||window.webkitAudioContext; if(!AC) return;
    try{ ctx=new AC(); master=ctx.createGain(); master.gain.value=(Game.settings&&Game.settings.vol!==undefined)?Game.settings.vol:.55; master.connect(ctx.destination);
      noiseBuf=ctx.createBuffer(1,ctx.sampleRate*2,ctx.sampleRate); const d=noiseBuf.getChannelData(0); let last=0; for(let i=0;i<d.length;i++){ last=(last+.02*(Math.random()*2-1))/1.02; d[i]=(Math.random()*2-1)*.5+last*3; }
      ambient=ctx.createBufferSource(); ambient.buffer=noiseBuf; ambient.loop=true; const f=ctx.createBiquadFilter(); f.type="lowpass"; f.frequency.value=380; const g=ctx.createGain(); g.gain.value=.05; ambient.connect(f); f.connect(g); g.connect(master); ambient.start();
      windG=ctx.createGain(); windG.gain.value=0; windF=ctx.createBiquadFilter(); windF.type="bandpass"; windF.frequency.value=500; windF.Q.value=.6; const ws=ctx.createBufferSource(); ws.buffer=noiseBuf; ws.loop=true; ws.connect(windF); windF.connect(windG); windG.connect(master); ws.start();
    }catch(e){ ctx=null; } }
  const vol=(x,y,z)=>{ if(x===undefined) return 1; const c=camera.position, d=Math.hypot(x-c.x,y-c.y,z-c.z); return 1/(1+d*.035); };
  function noise(dur,freq,q,gain,type,sweepTo){ if(!ctx||gain<.01) return; const s=ctx.createBufferSource(); s.buffer=noiseBuf; const f=ctx.createBiquadFilter(); f.type=type||"lowpass"; f.frequency.setValueAtTime(freq,ctx.currentTime); if(sweepTo) f.frequency.exponentialRampToValueAtTime(sweepTo,ctx.currentTime+dur); f.Q.value=q||1;
    const g=ctx.createGain(); g.gain.setValueAtTime(gain,ctx.currentTime); g.gain.exponentialRampToValueAtTime(.001,ctx.currentTime+dur); s.connect(f); f.connect(g); g.connect(master); s.start(0,Math.random(),dur+.05); }
  function tone(f0,f1,dur,gain,type){ if(!ctx||gain<.01) return; const o=ctx.createOscillator(); o.type=type||"sine"; o.frequency.setValueAtTime(f0,ctx.currentTime); o.frequency.exponentialRampToValueAtTime(Math.max(1,f1),ctx.currentTime+dur);
    const g=ctx.createGain(); g.gain.setValueAtTime(gain,ctx.currentTime); g.gain.exponentialRampToValueAtTime(.001,ctx.currentTime+dur); o.connect(g); g.connect(master); o.start(); o.stop(ctx.currentTime+dur+.05); }
  a.setVolume=function(v){ if(master&&ctx) master.gain.setTargetAtTime(v,ctx.currentTime,.03); };
  let lastSm=0, lastCol=0, lastGt=0;
  a.smash=function(p){ if(!ctx) return; const t=ctx.currentTime; if(t-lastSm<.11) return; lastSm=t; p=Math.min(1.4,p||.6); noise(.45+p*.4,1400,.8,.55*p,"lowpass",110); noise(.2,5200,1.4,.22*p,"bandpass",1800); tone(95,32,.35+p*.2,.55*p,"sawtooth"); };
  a.collapse=function(x,y,z,m){ if(!ctx) return; const t=ctx.currentTime; if(t-lastCol<.18) return; lastCol=t; const v=vol(x,y,z)*Math.min(1,.35+m*.7); noise(1.1+m*1.3,420,.9,.62*v,"lowpass",45); tone(58,19,1.1+m*.8,.5*v); noise(.5,2200,1.2,.15*v,"bandpass",600); };
  a.glassTick=function(x,y,z){ if(!ctx) return; const t=ctx.currentTime; if(t-lastGt<.05) return; lastGt=t; const v=vol(x,y,z); tone(2400+Math.random()*2200,1500,.07,.07*v,"triangle"); };
  a.unlock=function(){ init(); if(ctx&&(ctx.state==="suspended"||ctx.state==="interrupted")) ctx.resume(); };   /* iOS: arama/Siri sonrası durum "interrupted" olur */
  /* uygulama arka plana gidince ses de durur (iOS/Android pil + "arka planda ses çalıyor" şikâyeti); dönünce ilk dokunuşta açılır */
  try{ document.addEventListener("visibilitychange",()=>{ if(!ctx) return; try{ if(document.hidden){ if(ctx.state==="running"&&ctx.suspend) ctx.suspend(); } else if(ctx.state==="suspended"&&ctx.resume) ctx.resume(); }catch(e){} }); }catch(e){}
  a.crash=function(x,y,z,m){ if(!ctx) return; const t=ctx.currentTime; if(t-lastCrash<.07) return; lastCrash=t; const v=vol(x,y,z)*(.4+m*.6); noise(.6+m*.6,900,.8,.5*v,"lowpass",120); tone(80,28,.5,.5*v); };
  a.boom=function(x,y,z,big){ const v=big?.6:vol(x,y,z); noise(1.2,500,.7,.9*v,"lowpass",60); tone(70,22,1,.9*v); if(big) noise(.5,3000,1,.3,"highpass"); };
  a.thud=function(x,y,z){ const v=vol(x,y,z); tone(130,45,.18,.55*v); noise(.15,500,1,.35*v); };
  a.punch=function(){ tone(160,45,.2,.7); noise(.18,1200,1.2,.5,"bandpass"); };
  /* yumruk şarjı: yükselen ton (lv 0..1); loop=true → kısa tik; bırakınca ağır vuruş */
  let lastCh=0; a.charge=function(lv,loop){ if(!ctx) return; lv=lv||0; const t=ctx.currentTime; if(t-lastCh<.06) return; lastCh=t; const f=140+lv*520; tone(f,f*(loop?1.12:1.5),loop?.16:.32,loop?.16+lv*.12:.28+lv*.15,loop?"triangle":"sawtooth"); if(!loop) noise(.25,900+lv*2400,1.5,.12+lv*.1,"bandpass",3000); };
  a.chargeHit=function(lv){ if(!ctx) return; tone(70+lv*30,24,.5+lv*.5,.65+lv*.3,"sawtooth"); noise(.35+lv*.4,1800,.9,.3+lv*.3,"lowpass",150); };
  a.glass=function(x,y,z){ const v=vol(x,y,z); noise(.35,5000,2,.35*v,"bandpass"); tone(2600,1700,.2,.12*v,"triangle"); tone(3400,2100,.25,.08*v,"triangle"); };
  a.splash=function(x,y,z,s){ const v=vol(x,y,z)*Math.min(1,.4+(s||1)*.3); noise(.5,1800,.8,.45*v,"bandpass",500); noise(.3,4000,1,.18*v,"highpass"); };
  a.whoosh=function(){ noise(.7,300,1.5,.5,"bandpass",2200); };
  a.click=function(){ tone(700,500,.07,.15,"triangle"); };
  a.wind=function(speed){ if(!ctx||!windG) return; const k=Math.min(1,speed/120); windG.gain.setTargetAtTime(k*.5,ctx.currentTime,.15); windF.frequency.setTargetAtTime(300+k*1800,ctx.currentTime,.15); };
  a.loop=function(name,on){ if(!ctx) return; let L=loops[name]; if(!L){ const g=ctx.createGain(); g.gain.value=0; g.connect(master); const nodes=[];
      if(name==="laser"){ const o=ctx.createOscillator(); o.type="sawtooth"; o.frequency.value=330; const lfo=ctx.createOscillator(); lfo.frequency.value=22; const lg=ctx.createGain(); lg.gain.value=60; lfo.connect(lg); lg.connect(o.frequency); o.connect(g); o.start(); lfo.start(); const n=ctx.createBufferSource(); n.buffer=noiseBuf; n.loop=true; const hf=ctx.createBiquadFilter(); hf.type="highpass"; hf.frequency.value=2500; n.connect(hf); hf.connect(g); n.start(); }
      else { const n=ctx.createBufferSource(); n.buffer=noiseBuf; n.loop=true; const f=ctx.createBiquadFilter(); f.type=name==="fire"?"lowpass":"highpass"; f.frequency.value=name==="fire"?700:3200; n.connect(f); f.connect(g); n.start();
        if(name==="ice"){ const o=ctx.createOscillator(); o.type="sine"; o.frequency.value=1900; const og=ctx.createGain(); og.gain.value=.15; o.connect(og); og.connect(g); o.start(); } }
      L=loops[name]={g,peak:name==="laser"?.16:name==="fire"?.7:.35}; }
    L.g.gain.setTargetAtTime(on?L.peak:0,ctx.currentTime,.05); };
  a.zap=function(){ noise(.35,6000,1.2,.6,"highpass"); noise(.5,900,.8,.5,"lowpass",90); tone(1800,90,.25,.25,"sawtooth"); };
  a.phase=function(on){ if(on){ noise(.6,2500,2,.25,"bandpass",400); tone(900,200,.5,.14,"sine"); } };
  a.slow=function(on){ if(on){ tone(520,70,1.2,.4,"sine"); noise(.9,800,1,.2,"lowpass",90); } else { tone(90,520,.6,.3,"sine"); } };
  a.quake=function(){ noise(2.2,160,.8,.9,"lowpass",40); tone(48,20,2,.8); };
  /* ---- araba sesleri: motor (rpm/gaz/tip), lastik kayması, korna, kapı, çarpma ---- */
  let eng=null, skidN=null, hornN=null;
  const KF={0:1,1:.8,2:1.28,3:.62,4:.72,5:1,20:.5,21:.95,22:1.35,23:1.9,24:1.4,25:.55};
  function mkEngine(){ const g=ctx.createGain(); g.gain.value=0; const lp=ctx.createBiquadFilter(); lp.type="lowpass"; lp.frequency.value=600; lp.Q.value=1.4;
    const o1=ctx.createOscillator(); o1.type="sawtooth"; const o2=ctx.createOscillator(); o2.type="square"; const o3=ctx.createOscillator(); o3.type="sawtooth";
    const g1=ctx.createGain(), g2=ctx.createGain(), g3=ctx.createGain(); g1.gain.value=.5; g2.gain.value=.34; g3.gain.value=.22;
    o1.connect(g1); o2.connect(g2); o3.connect(g3); g1.connect(lp); g2.connect(lp); g3.connect(lp);
    const lfo=ctx.createOscillator(); lfo.frequency.value=14; const lg=ctx.createGain(); lg.gain.value=3.2; lfo.connect(lg); lg.connect(o1.frequency);
    const n=ctx.createBufferSource(); n.buffer=noiseBuf; n.loop=true; const nf=ctx.createBiquadFilter(); nf.type="bandpass"; nf.frequency.value=900; nf.Q.value=.7; const ng=ctx.createGain(); ng.gain.value=0; n.connect(nf); nf.connect(ng); ng.connect(g);
    lp.connect(g); g.connect(master); o1.start(); o2.start(); o3.start(); lfo.start(); n.start(); return {g,lp,o1,o2,o3,ng,nf,lfo}; }
  a.engine=function(on,rpm,thr,kind){ if(!ctx) return; if(!eng){ if(!on) return; eng=mkEngine(); } const t=ctx.currentTime, kf=KF[kind]||1;
    if(!on){ eng.g.gain.setTargetAtTime(0,t,.06); return; }
    const f=(46+rpm*118)*kf; eng.o1.frequency.setTargetAtTime(f,t,.03); eng.o2.frequency.setTargetAtTime(f*.5,t,.03); eng.o3.frequency.setTargetAtTime(f*1.503,t,.03); eng.lfo.frequency.setTargetAtTime(f*.25,t,.05);
    eng.lp.frequency.setTargetAtTime(260+rpm*1500+thr*900,t,.05); eng.g.gain.setTargetAtTime((.07+.15*thr+.05*rpm)*(kind===3?1.15:1),t,.04);
    eng.ng.gain.setTargetAtTime(.1+thr*.35+rpm*.15,t,.05); eng.nf.frequency.setTargetAtTime(500+rpm*1800,t,.05); };
  a.engineStart=function(kind){ if(!ctx) return; tone(52,95,.55,.28,"sawtooth"); noise(.4,420,1.2,.28,"lowpass",160); setTimeout(()=>{ tone(75,120,.25,.22,"sawtooth"); },380); };
  a.skid=function(level,speed){ if(!ctx) return; if(!skidN){ if(level<.02) return; const n=ctx.createBufferSource(); n.buffer=noiseBuf; n.loop=true; const f=ctx.createBiquadFilter(); f.type="bandpass"; f.frequency.value=1500; f.Q.value=2.2; const g=ctx.createGain(); g.gain.value=0; n.connect(f); f.connect(g); g.connect(master); n.start(); skidN={g,f}; }
    const t=ctx.currentTime; skidN.g.gain.setTargetAtTime(Math.min(1,level)*.32,t,.05); skidN.f.frequency.setTargetAtTime(1100+Math.min(1,(speed||0)/45)*1700,t,.08); };
  a.horn=function(on){ if(!ctx) return; if(!hornN){ if(!on) return; const g=ctx.createGain(); g.gain.value=0; const f=ctx.createBiquadFilter(); f.type="lowpass"; f.frequency.value=2200; f.connect(g); g.connect(master);
      const mk=fr=>{ const o=ctx.createOscillator(); o.type="sawtooth"; o.frequency.value=fr; o.connect(f); o.start(); return o; }; mk(392); mk(494); mk(587); hornN={g}; }
    hornN.g.gain.setTargetAtTime(on?.1:0,ctx.currentTime,.012); };
  a.door=function(){ if(!ctx) return; noise(.09,1100,1,.4,"lowpass",300); tone(170,70,.13,.5,"square"); setTimeout(()=>{ noise(.06,2200,1.4,.2,"bandpass"); tone(120,60,.08,.3,"triangle"); },95); };
  a.carHit=function(m,x,y,z){ if(!ctx) return; m=Math.min(1.5,m||.5)*(x===undefined?1:Math.max(.15,vol(x,y,z)*1.6)); noise(.3+m*.25,1700,.9,.5*m,"bandpass",260); tone(190,55,.3,.5*m,"sawtooth"); if(m>.7){ tone(2700,1800,.14,.1,"triangle"); noise(.3,5200,1.6,.15,"bandpass",2200); } };
  a.crashMetal=a.carHit;
  /* trafik kornası: kısa iki tonlu bip (konuma göre) */
  let lastHonk=0; a.honk=function(x,y,z){ if(!ctx) return; const t=ctx.currentTime; if(t-lastHonk<.25) return; lastHonk=t; const v=Math.min(.5,vol(x,y,z)*1.4); if(v<.03) return; const f=380+Math.random()*60; tone(f,f*.98,.22,.16*v,"sawtooth"); tone(f*1.26,f*1.24,.22,.12*v,"square"); setTimeout(()=>{ tone(f,f*.97,.18,.14*v,"sawtooth"); tone(f*1.26,f*1.23,.18,.1*v,"square"); },260); };
  a.stopLoops=function(){ for(const k in loops) a.loop(k,false); for(const k in amb){ amb[k].lv=-1; a.amb(k,0); } a.wind(0); a.engine(false); a.skid(0); a.horn(false); };
  /* ---- v5: ortam katmanları (yağmur, esinti, cırcır böceği) + gök gürültüsü + kuş ---- */
  const amb={};
  function layer(name){ if(!ctx||!noiseBuf) return null; if(amb[name]) return amb[name]; const g=ctx.createGain(); g.gain.value=0; g.connect(master); const L=amb[name]={g,lv:0};
    const nz=()=>{ const s=ctx.createBufferSource(); s.buffer=noiseBuf; s.loop=true; s.start(0,Math.random()); return s; };
    if(name==="rain"){ const f=ctx.createBiquadFilter(); f.type="highpass"; f.frequency.value=1500; const f2=ctx.createBiquadFilter(); f2.type="lowpass"; f2.frequency.value=8500; const s=nz(); s.connect(f); f.connect(f2); f2.connect(g); }
    else if(name==="breeze"){ const f=ctx.createBiquadFilter(); f.type="bandpass"; f.frequency.value=420; f.Q.value=.5; const s=nz(); s.connect(f); f.connect(g); L.f=f; }
    else if(name==="crickets"){ for(const [fr,lf] of [[4300,13],[4750,10.5]]){ const o=ctx.createOscillator(); o.type="sine"; o.frequency.value=fr; const am=ctx.createGain(); am.gain.value=.5; const lfo=ctx.createOscillator(); lfo.type="sine"; lfo.frequency.value=lf; const lg=ctx.createGain(); lg.gain.value=.5; lfo.connect(lg); lg.connect(am.gain); o.connect(am); am.connect(g); o.start(); lfo.start(); } }
    return L; }
  a.amb=function(name,v){ if(!ctx) return; const L=layer(name); if(!L) return; v=Math.max(0,v); if(Math.abs(v-L.lv)<.004) return; L.lv=v; L.g.gain.setTargetAtTime(v,ctx.currentTime,.5); if(L.f&&name==="breeze") L.f.frequency.setTargetAtTime(300+v*900,ctx.currentTime,.4); };
  a.thunder=function(far){ if(!ctx) return; const d=far||1; noise(2.6+d,260,.8,.85/d,"lowpass",38); setTimeout(()=>noise(1.8,180,.9,.5/d,"lowpass",30),420+Math.random()*500); tone(52,24,2.2,.5/d,"sine"); };
  a.bird=function(){ if(!ctx) return; const f0=2300+Math.random()*1700, n=2+Math.floor(Math.random()*4); for(let i=0;i<n;i++) setTimeout(()=>{ tone(f0*(1+Math.random()*.15),f0*(1.25+Math.random()*.4),.07+Math.random()*.05,.05,"sine"); },i*(95+Math.random()*60)); };
  /* v8: ağaç / deve / heykel sesleri */
  a._n=noise; a._t=tone; let lastTB=0;
  a.treeBreak=function(x,y,z){ if(!ctx) return; const t=ctx.currentTime; if(t-lastTB<.06) return; lastTB=t; const v=vol(x,y,z); noise(.12,2200,1.3,.55*v,"bandpass"); noise(.35,700,.9,.5*v,"lowpass",160); tone(95,40,.28,.5*v);
    for(let i=0;i<4;i++) setTimeout(()=>{ noise(.05,3000+Math.random()*2000,2,.2*v,"bandpass"); },40+i*55+Math.random()*30); };
  a.treeFall=function(x,y,z){ if(!ctx) return; const v=vol(x,y,z); noise(1.1,1500,.6,.3*v,"bandpass",500); };
  a.treeLand=function(x,y,z,m){ if(!ctx) return; const v=vol(x,y,z)*(m||1); noise(.55,380,.8,.62*v,"lowpass",70); tone(70,30,.5,.55*v); noise(.22,2600,.8,.18*v,"highpass"); };
  a.camelBreak=function(x,y,z){ if(!ctx) return; const v=vol(x,y,z); noise(.18,3600,1.6,.4*v,"bandpass"); tone(520,240,.16,.28*v,"triangle"); noise(.5,900,.8,.3*v,"lowpass",200); };
  a.spirit=function(x,y,z){ if(!ctx) return; const v=Math.max(.25,vol(x,y,z)); tone(440,760,1.1,.18*v,"sine"); setTimeout(()=>tone(660,1180,1.0,.12*v,"sine"),140); setTimeout(()=>tone(990,1500,.8,.07*v,"triangle"),300); };
  a.stoneCrack=function(x,y,z){ if(!ctx) return; const v=Math.max(.3,vol(x,y,z)); noise(.3,1300,1.1,.55*v,"bandpass",300); tone(150,55,.35,.55*v); setTimeout(()=>noise(.1,3200,2,.25*v,"bandpass"),90); };
  a.eyeCharge=function(){ if(!ctx) return; tone(180,1300,1.2,.22,"sawtooth"); tone(90,650,1.2,.2,"sine"); };
  a._ctx=()=>ctx; a._master=()=>master; a._buf=()=>noiseBuf; a._vol=vol;
  const un=()=>a.unlock(); ["touchstart","mousedown","keydown"].forEach(e=>addEventListener(e,un,{passive:true}));
  return a;
})();
