"use strict";
/* ===== SES v3 (profesyonel katman): ana çıkışa sıkıştırıcı (dinamik aralık/patlamada bozulma yok) + sentetik oda yankısı (reverb), konuma bağlı ses yolu
   (mesafeyle kısılma + yüksek frekans emilimi + sol/sağ panorama), katmanlı gerçekçi yıkım/çarpma/patlama/cam/araba sesleri, şehir ve dalga ortam yatakları. Dosya yok. ===== */
(function(){
  const a=Game.audio; if(!a) return;
  let ctx=null, comp=null, wet=null, ok=false, load=0, lastCol=0, lastCr=0, lastSm=0, lastGl=0, lastCh=0, lastTb=0, lastBm=0;
  const clamp=(v,lo,hi)=>v<lo?lo:v>hi?hi:v, rnd=Math.random;
  const orig={}; for(const k of ["collapse","crash","smash","boom","glass","carHit","treeBreak","stoneCrack","thud","punch"]) orig[k]=a[k];
  const origUnlock=a.unlock;
  a.unlock=function(){ origUnlock.apply(a,arguments); setup(); };
  function setup(){ if(ok) return; ctx=a._ctx&&a._ctx(); const m=a._master&&a._master(); if(!ctx||!m||!a._buf()) return;
    try{ comp=ctx.createDynamicsCompressor(); comp.threshold.value=-17; comp.knee.value=14; comp.ratio.value=5; comp.attack.value=.004; comp.release.value=.24;
      m.disconnect(); m.connect(comp); comp.connect(ctx.destination);
      /* yankı: üstel sönümlü, alçak geçirilmiş stereo gürültü darbe yanıtı */
      const len=Math.floor(ctx.sampleRate*2.1), ir=ctx.createBuffer(2,len,ctx.sampleRate);
      for(let ch=0;ch<2;ch++){ const d=ir.getChannelData(ch); let lp=0; for(let i=0;i<len;i++){ const e=Math.pow(1-i/len,2.6); lp+=((rnd()*2-1)-lp)*(.35-.28*i/len); d[i]=lp*e*(i<ctx.sampleRate*.012?i/(ctx.sampleRate*.012):1)*2.2; } }
      const rev=ctx.createConvolver(); rev.buffer=ir; const rl=ctx.createBiquadFilter(); rl.type="lowpass"; rl.frequency.value=3600; wet=ctx.createGain(); wet.gain.value=1; wet.connect(rl); rl.connect(rev); rev.connect(m);
      ok=true; }catch(e){ ok=false; wet=null; } }
  /* ---- ses yolu: kaynak → mesafe kazancı → alçak geçiren (hava emilimi) → panorama → master; yankıya mesafeyle artan gönderim ---- */
  const camRight=()=>{ try{ const e=camera.matrixWorld&&camera.matrixWorld.elements; if(e&&e.length===16) return [e[0],e[1],e[2]]; }catch(x){} return null; };
  function bus(x,y,z,wetK){ const g=ctx.createGain(), lp=ctx.createBiquadFilter(); lp.type="lowpass"; let d=0, pan=0;
    if(x!==undefined&&isFinite(x)&&isFinite(y)&&isFinite(z)){ const c=camera.position; d=Math.hypot(x-c.x,y-c.y,z-c.z); if(!isFinite(d)) d=0; const R=camRight(); if(R&&d>.5) pan=clamp(((x-c.x)*R[0]+(y-c.y)*R[1]+(z-c.z)*R[2])/d,-1,1)*.85; }
    g.gain.value=(d>0?2.6:1)/(1+d*.03); lp.frequency.value=clamp(19000/(1+d*.028),700,19000); g.connect(lp); let out=lp;
    if(pan!==0&&ctx.createStereoPanner){ const p=ctx.createStereoPanner(); p.pan.value=pan; lp.connect(p); out=p; }
    out.connect(a._master()); if(wet&&wetK){ const s=ctx.createGain(); s.gain.value=clamp(wetK*(.5+d*.012),0,.9); out.connect(s); s.connect(wet); }
    return g; }
  /* gürültü darbesi: t0 başlangıç, dur süre, f0→f1 filtre süpürmesi, kazanç, tip, atak */
  function N(o,t0,dur,f0,f1,q,gain,type,att){ if(gain<.004) return; load+=3; const s=ctx.createBufferSource(); s.buffer=a._buf(); const f=ctx.createBiquadFilter(); f.type=type||"lowpass"; f.Q.value=q||1; f.frequency.setValueAtTime(f0,t0); if(f1&&f1!==f0) f.frequency.exponentialRampToValueAtTime(Math.max(20,f1),t0+dur);
    const g=ctx.createGain(); g.gain.setValueAtTime(.0001,t0); g.gain.linearRampToValueAtTime(gain,t0+(att||.003)); g.gain.exponentialRampToValueAtTime(.0008,t0+dur); s.connect(f); f.connect(g); g.connect(o); s.start(t0,rnd()*1.5,dur+.05); }
  function Tn(o,t0,dur,f0,f1,gain,type,att,lpf){ if(gain<.004) return; load+=3; const s=ctx.createOscillator(); s.type=type||"sine"; s.frequency.setValueAtTime(f0,t0); s.frequency.exponentialRampToValueAtTime(Math.max(1,f1),t0+dur);
    const g=ctx.createGain(); g.gain.setValueAtTime(.0001,t0); g.gain.linearRampToValueAtTime(gain,t0+(att||.004)); g.gain.exponentialRampToValueAtTime(.0008,t0+dur); let n=s; if(lpf){ const f=ctx.createBiquadFilter(); f.type="lowpass"; f.frequency.value=lpf; s.connect(f); n=f; } n.connect(g); g.connect(o); s.start(t0); s.stop(t0+dur+.05); }
  const on=()=>ok&&ctx&&a._buf();
  const busy=()=>{ const t=ctx.currentTime; load=Math.max(0,load-(t-(busy.t||t))*70); busy.t=t; return load>260; };
  const mk=(x,y,z,w)=>bus(x,y,z,w);

  /* ===== bina yıkımı: çatlama → çarpma → gürleme → metal inleme → enkaz yağmuru → cam → toz ===== */
  a.collapse=function(x,y,z,m){ if(!on()) return orig.collapse&&orig.collapse.apply(a,arguments); const t=ctx.currentTime; if(t-lastCol<.4||busy()) return; lastCol=t; m=clamp(m===undefined?.5:m,.1,1.4);
    const o=mk(x,y,z,.55), T=t+.005, v=Math.min(1,.42+m*.6);
    N(o,T,.1,6200,1200,.9,.42*v,"bandpass",.002);                                          // beton çatlağı
    Tn(o,T,.9+.5*m,80,23,.85*v,"sine",.005); Tn(o,T,.45,150,52,.34*v,"triangle");          // gövde çarpması
    N(o,T+.04,2.4+m*2.2,280,48,.9,.72*v,"lowpass",.22); N(o,T+.22,3+m*2.2,130,34,.8,.46*v,"lowpass",.5); // gürleme
    Tn(o,T+.1,1.7,54,33,.15*v,"sawtooth",.35,210);                                         // çelik inlemesi
    N(o,T,1.7,1500,300,.6,.15*v,"bandpass",.2);                                            // toz/hava üfürümü
    const nc=Math.round(8+10*m), span=1.7+m*1.5;
    for(let i=0;i<nc;i++){ const tt=T+.08+Math.pow(rnd(),1.6)*span, k=1-i/nc*.55; N(o,tt,.05+rnd()*.09,500+rnd()*3300,200,1.6,(.06+.26*rnd())*v*k,"bandpass",.002); if(rnd()<.35) Tn(o,tt,.09,90+rnd()*130,45,.17*v*k,"triangle"); }
    const ng=Math.round(4+6*m); for(let i=0;i<ng;i++) Tn(o,T+.1+rnd()*1.2,.1+rnd()*.12,2600+rnd()*3400,1900,.04*v,"triangle"); };
  /* ===== parça çarpması (enkaz) ===== */
  a.crash=function(x,y,z,m){ if(!on()) return orig.crash&&orig.crash.apply(a,arguments); const t=ctx.currentTime; if(t-lastCr<.09||busy()) return; lastCr=t; m=clamp(m||.4,.1,1.2);
    const o=mk(x,y,z,.3), T=t+.003, v=.4+m*.6;
    N(o,T,.08+.1*m,2400,500,1.3,.34*v,"bandpass",.002); N(o,T,.5+.5*m,900,110,.8,.46*v,"lowpass",.01); Tn(o,T,.45,95,30,.48*v,"sine");
    if(m>.3){ const n=2+Math.round(m*3); for(let i=0;i<n;i++) N(o,T+.05+rnd()*.35,.04+rnd()*.05,900+rnd()*3000,300,1.8,.13*v,"bandpass",.002); } };
  /* ===== kahramanın bina içinden geçişi ===== */
  a.smash=function(p){ if(!on()) return orig.smash&&orig.smash.apply(a,arguments); const t=ctx.currentTime; if(t-lastSm<.11||busy()) return; lastSm=t; p=clamp(p||.6,.1,1.4);
    const o=mk(undefined,0,0,.25), T=t+.003;
    N(o,T,.5+p*.4,1500,100,.8,.5*p,"lowpass",.004); N(o,T,.22,5400,1700,1.3,.2*p,"bandpass",.002); Tn(o,T,.4+p*.2,98,30,.55*p,"sawtooth",.004,260); Tn(o,T,.3,60,24,.5*p,"sine"); };
  /* ===== patlama ===== */
  a.boom=function(x,y,z,big){ if(!on()) return orig.boom&&orig.boom.apply(a,arguments); const t=ctx.currentTime, T=t+.003; if(t-lastBm<.07||(busy()&&!big)) return; lastBm=t; const o=big?mk(undefined,0,0,.7):mk(x,y,z,.7), v=big?.9:1;
    N(o,T,.14,7000,900,.8,.5*v,"highpass",.001); Tn(o,T,1.3,96,21,.95*v,"sine",.004); N(o,T,1.5,950,65,.7,.82*v,"lowpass",.006); N(o,T+.15,2.2,260,38,.8,.5*v,"lowpass",.3); N(o,T+.02,.9,2600,500,1,.2*v,"bandpass",.01); };
  /* ===== cam ===== */
  a.glass=function(x,y,z){ if(!on()) return orig.glass&&orig.glass.apply(a,arguments); const t=ctx.currentTime; if(t-lastGl<.05||busy()) return; lastGl=t; const o=mk(x,y,z,.25), T=t+.003;
    N(o,T,.28,5600,3000,1.8,.62,"bandpass",.001); N(o,T,.12,9000,5000,.7,.26,"highpass",.001); const n=5+Math.floor(rnd()*5); for(let i=0;i<n;i++) Tn(o,T+i*.022+rnd()*.03,.12+rnd()*.2,2400+rnd()*4200,1700+rnd()*1200,.09+rnd()*.07,"triangle",.001); };
  /* ===== araba çarpması / metal ===== */
  a.carHit=function(m,x,y,z){ if(!on()) return orig.carHit&&orig.carHit.apply(a,arguments); const t=ctx.currentTime; if(t-lastCh<.07||busy()) return; lastCh=t; m=clamp(m||.5,.1,1.5); const o=mk(x,y,z,.3), T=t+.002, v=Math.min(1.1,.35+m*.65);
    N(o,T,.3+m*.25,1700,250,.9,.52*v,"bandpass",.002); Tn(o,T,.32,190,52,.5*v,"sawtooth",.003,700);
    const np=2+Math.round(m*2); for(let i=0;i<np;i++){ const f=700+rnd()*1700; Tn(o,T+i*.018,.16+rnd()*.14,f,f*.93,.07*v,"square",.001,3200); }
    N(o,T,.06,6500,2500,1.2,.16*v,"highpass",.001); if(m>.7){ for(let i=0;i<3;i++) N(o,T+.08+i*.07+rnd()*.05,.09,1200+rnd()*1500,300,1.6,.18*v,"bandpass",.002); Tn(o,T,.5,120,36,.4*v,"sine"); } };
  a.crashMetal=a.carHit;
  /* ===== ağaç kırılması (odun çatırtısı) ===== */
  a.treeBreak=function(x,y,z){ if(!on()) return orig.treeBreak&&orig.treeBreak.apply(a,arguments); const t=ctx.currentTime; if(t-lastTb<.06||busy()) return; lastTb=t; const o=mk(x,y,z,.2), T=t+.002;
    N(o,T,.1,2400,900,1.6,.5,"bandpass",.001); N(o,T,.38,720,150,.9,.46,"lowpass",.005); Tn(o,T,.3,98,40,.46,"sine"); for(let i=0;i<5;i++) N(o,T+.04+i*.05+rnd()*.03,.05,2600+rnd()*2400,900,2.2,.17,"bandpass",.001); };
  a.stoneCrack=function(x,y,z){ if(!on()) return orig.stoneCrack&&orig.stoneCrack.apply(a,arguments); const t=ctx.currentTime, o=mk(x,y,z,.35), T=t+.002;
    N(o,T,.3,1400,320,1.2,.55,"bandpass",.001); Tn(o,T,.4,150,50,.55,"sine"); N(o,T+.08,.1,3400,1500,2,.24,"bandpass",.001); N(o,T+.02,.9,420,70,.7,.3,"lowpass",.01); };
  a.thud=function(x,y,z){ if(!on()) return orig.thud&&orig.thud.apply(a,arguments); const t=ctx.currentTime, o=mk(x,y,z,.15), T=t+.002; Tn(o,T,.24,138,38,.62,"sine",.002); N(o,T,.14,620,140,1,.34,"lowpass",.002); };
  a.punch=function(){ if(!on()) return orig.punch&&orig.punch.apply(a,arguments); const t=ctx.currentTime, o=mk(undefined,0,0,.2), T=t+.002; Tn(o,T,.24,170,42,.72,"sine",.002); N(o,T,.17,1300,300,1.2,.5,"bandpass",.001); N(o,T,.05,5200,2000,1,.18,"highpass",.001); };

  /* ===== ortam yatakları: şehir uğultusu + deniz dalgası (konuma göre) ===== */
  const beds={};
  function bed(name){ if(beds[name]) return beds[name]; if(!ctx||!a._buf()) return null; const g=ctx.createGain(); g.gain.value=0; g.connect(a._master()); const L=beds[name]={g,lv:0};
    const nz=()=>{ const s=ctx.createBufferSource(); s.buffer=a._buf(); s.loop=true; s.start(0,rnd()*1.5); return s; };
    if(name==="city"){ const f1=ctx.createBiquadFilter(); f1.type="lowpass"; f1.frequency.value=190; f1.Q.value=.5; nz().connect(f1); f1.connect(g);                       // alçak uğultu
      const f2=ctx.createBiquadFilter(); f2.type="bandpass"; f2.frequency.value=620; f2.Q.value=.45; const g2=ctx.createGain(); g2.gain.value=.4; nz().connect(f2); f2.connect(g2); g2.connect(g);   // uzak trafik
      const lfo=ctx.createOscillator(); lfo.frequency.value=.11; const lg=ctx.createGain(); lg.gain.value=.18; lfo.connect(lg); lg.connect(g2.gain); lfo.start(); }
    else if(name==="surf"){ const f=ctx.createBiquadFilter(); f.type="lowpass"; f.frequency.value=900; f.Q.value=.6; const sw=ctx.createGain(); sw.gain.value=.55; nz().connect(f); f.connect(sw); sw.connect(g);
      const lfo=ctx.createOscillator(); lfo.frequency.value=.13; const lg=ctx.createGain(); lg.gain.value=.4; lfo.connect(lg); lg.connect(sw.gain); lfo.start(); const f2=ctx.createBiquadFilter(); f2.type="highpass"; f2.frequency.value=2500; const g2=ctx.createGain(); g2.gain.value=.08; nz().connect(f2); f2.connect(g2); g2.connect(g); }
    return L; }
  a.bed=function(name,v){ if(!on()) return; const L=bed(name); if(!L) return; v=Math.max(0,v); if(Math.abs(v-L.lv)<.003) return; L.lv=v; L.g.gain.setTargetAtTime(v,ctx.currentTime,.6); };
  const W=Game.W; let bt=0;
  Game.updaters.push((dt0,time,raw)=>{ if(!ctx) { ctx=a._ctx&&a._ctx(); } if(!on()) return; bt-=Math.min(raw||dt0,.2); if(bt>0) return; bt=.5; const play=Game.mode==="play", p=Game.heroObj&&Game.heroObj.position; if(!play||!p){ a.bed("city",0); a.bed("surf",0); return; }
    const alt=p.y-(W.terrainH(p.x,p.z)||0), up=clamp(1-(alt-30)/220,0,1)*(1-(Game.H&&Game.H.sp||0));
    const dc=W.distCity(p.x,p.z); const cityK=clamp(1-dc/90,0,1)*up; let wetN=0; for(let i=0;i<8;i++){ const an=i*.785, h=W.terrainH(p.x+Math.cos(an)*34,p.z+Math.sin(an)*34); if(h<=W.WATER_Y+.1) wetN++; }
    const here=W.terrainH(p.x,p.z)<=W.WATER_Y+.1; const surfK=(here?1:clamp(wetN/5,0,1))*up*(wetN>0||here?1:0);
    a.bed("city",cityK*.07); a.bed("surf",surfK*.09); });
  a._pro=()=>({ok,load,comp:!!comp,wet:!!wet});
})();
