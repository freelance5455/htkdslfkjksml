"use strict";
/* ===== MEGA KARAKTERLER: ALTIN MEGA (canlı altın zırh) + NEON EJDERHA (lacivert/mor/sarı neon, ağızdan lav) =====
   Mythic kademesinde satılır (Game.SUPER_IDS). Neon Ejderha'da göz lazeri yok: ateş tuşu AĞIZDAN LAV nefesi atar (lavabreath.js). */
Game.SUPER_IDS.push("altin","neondrake");
(function(){
const K=Game.VIPKit, PI=Math.PI, TAU=PI*2, clamp=K.clamp, fan=K.fan, AD=THREE.AdditiveBlending;
const keep=m=>{ m.userData=m.userData||{}; m.userData.keepEm=true; return m; };
const basic=(o,mats)=>{ const m=new THREE.MeshBasicMaterial(Object.assign({side:THREE.DoubleSide,fog:false},o)); mats.push(m); return m; };
const capeMat=(kind)=>ctx=>{ const tex=K.capeTexture(kind,ctx.pal.cape); const m=new THREE.MeshBasicMaterial({map:tex,alphaTest:.5,side:THREE.DoubleSide,fog:true}); ctx.mats.push(m); return keep(m); };
const lerp=(a,b,t)=>a+(b-a)*t;

/* ------------------------------------------------------------------ ALTIN MEGA ------------------------------------------------------------------ */
function goldTex(p){ const c=K.cnv(256,256), q=c.getContext("2d"); const g=q.createLinearGradient(0,0,256,256);
  g.addColorStop(0,p.a||"#a86a00"); g.addColorStop(.28,p.b||"#ffd24a"); g.addColorStop(.5,p.c||"#fff6c2"); g.addColorStop(.72,p.b||"#ffd24a"); g.addColorStop(1,p.a||"#a86a00"); q.fillStyle=g; q.fillRect(0,0,256,256);
  const rnd=K.rngS(p.seed||11); q.globalAlpha=.16; for(let i=0;i<70;i++){ q.fillStyle=rnd()<.5?"#fff":"#6a3c00"; q.fillRect(rnd()*256,rnd()*256,2+rnd()*30,1+rnd()*2); } q.globalAlpha=1;
  const t=new THREE.CanvasTexture(c); t.wrapS=t.wrapT=THREE.RepeatWrapping; return t; }
Game.VIPB.altin={
  mats(c){ const {M,pri,sec,trim,pal}=c, tex=goldTex(pal.gt||{}), tone=pal.tone||0xffffff;
    const gold=keep(M("#ffffff",{roughness:.26,metalness:.8,map:tex,emissive:pal.em!=null?pal.em:0x9a6400,emissiveIntensity:.5}));
    const bright=keep(M(trim,{roughness:.18,metalness:.95,emissive:pal.em!=null?pal.em:0xb07a00,emissiveIntensity:.6}));
    const dark=M(sec,{roughness:.35,metalness:.55});
    return {pri:gold,sec:dark,trim:bright,skin:keep(M(pri,{roughness:.34,metalness:.55,emissive:pal.em!=null?pal.em:0x8a5a00,emissiveIntensity:.35})),dark:M("#1a1004",{roughness:.6}),white:M("#fff8d8",{roughness:.4}),
      arm:gold,leg:gold,tor:gold,hand:bright,boot:dark,_tex:tex,_tone:tone}; },
  build(c){ const {R,add,cl,CO,SP,CY,TO,B,grp,M,mats,fc,pal,mPri,mSec,mTrim,mSkin,mDark,mWhite,mGlow,g,laserHex,vm}=c; const tex=vm._tex;
    const gem=basic({color:pal.gem!=null?pal.gem:0xff3a5a},mats), halo=basic({color:pal.halo!=null?pal.halo:0xffe08a,transparent:true,opacity:.7,blending:AD,depthWrite:false},mats);
    fc.brL.visible=fc.brR.visible=true;
    /* --- devasa kas: omuz, göğüs, sırt, kol, bacak --- */
    for(const s of [-1,1]){ const sh=s<0?R.shL:R.shR, el=s<0?R.elL:R.elR, kn=s<0?R.knL:R.knR, hp=s<0?R.hpL:R.hpR, ft=s<0?R.ftL:R.ftR;
      add(R.chest,SP(.27,14,10),mPri,s*.5,.4,0,0,0,0,1.05,.72,1.1); add(R.chest,TO(.25,.035,8,18),mTrim,s*.5,.4,0,PI/2,0,s*.18);
      for(let i=0;i<4;i++){ const a=i*.62-.9; add(R.chest,CO(.04,.2,5),mTrim,s*(.52+Math.cos(a)*.02),.52+Math.sin(a+.9)*.05,Math.sin(a)*.22,Math.sin(a)*.9,0,s*-.9+Math.cos(a)*.15); }
      add(sh,SP(.13,10,8),mPri,0,-.17,.07,0,0,0,1,1.5,1.05); add(sh,SP(.11,10,8),mPri,0,-.17,-.07,0,0,0,1,1.4,.9);   // ek pazı/arka kol
      add(el,CY(.125,.105,.28,12),mTrim,0,-.15,0); add(el,TO(.115,.02,6,14),mSec,0,-.03,0,PI/2); add(el,TO(.11,.02,6,14),mSec,0,-.27,0,PI/2); add(el,CO(.035,.14,5),mTrim,0,-.06,-.12,-PI/2);  // altın bileklik/kolluk
      add(kn,CY(.13,.095,.28,12),mTrim,0,-.2,0); add(kn,SP(.115,10,8),mTrim,0,.0,.07,0,0,0,1,1,.8); add(kn,CO(.04,.16,5),mTrim,0,-.02,.17,PI/2);  // diz zırhı + diz dikeni
      add(hp,SP(.13,10,8),mPri,0,-.17,.07,0,0,0,1.15,1.7,1);                                                                                            // ekstra quad
      add(ft,B(.2,.14,.36),mTrim,0,-.04,.07); add(ft,B(.2,.05,.14),mTrim,0,-.1,.22);
    }
    add(R.chest,SP(.25,12,9),mPri,-.19,.22,.17,0,0,0,1.05,.8,.62); add(R.chest,SP(.25,12,9),mPri,.19,.22,.17,0,0,0,1.05,.8,.62);                     // dev göğüs plakaları
    cl(R.chest,mTrim,0,.2,.255,.05,.4,.03); for(let i=0;i<3;i++) cl(R.chest,mTrim,0,.38-i*.1,.268,.6-i*.04,.03,.02);
    for(let i=0;i<3;i++) for(const s of [-1,1]) add(R.spine,SP(.075,8,6),mPri,s*.085,.2-i*.1,.172,0,0,0,1.05,.85,.5);                                  // 6'lı karın
    /* kemer + devasa M tokası */
    cl(R.root,mTrim,0,.06,0,.66,.1,.4); add(R.root,CY(.15,.15,.05,6),mTrim,0,.05,.2,PI/2); add(R.root,CY(.115,.115,.06,6),mDark,0,.05,.205,PI/2);
    const mk=basic({color:0xffe08a},mats); for(const s of [-1,1]){ cl(R.root,mk,s*.06,.05,.235,.022,.12,.01); cl(R.root,mk,s*.03,.05,.235,.02,.11,.01,0,0,s*.35); }
    for(const s of [-1,1]){ cl(R.root,mPri,s*.2,-.12,.18,.2,.3,.04,0,0,s*.08); cl(R.root,mTrim,s*.2,-.27,.19,.2,.03,.04,0,0,s*.08); }                          // zırh etekliği
    cl(R.root,mPri,0,-.14,.19,.18,.34,.04); cl(R.root,mTrim,0,-.32,.2,.14,.03,.04);
    /* kafa: altın taç + gem + yüz detayı */
    add(R.head,TO(.2,.03,8,24),mTrim,0,.24,0,PI/2);
    for(let i=0;i<7;i++){ const a=-PI*.78+i*(PI*1.56/6), h=i===3?.26:(i%2?.14:.2); add(R.head,CO(.035,h,5),mTrim,Math.sin(a)*.2,.25+h/2,Math.cos(a)*.2-.0,0,0,0); add(R.head,SP(.022,7,6),gem,Math.sin(a)*.2,.25+h+.01,Math.cos(a)*.2); }
    cl(R.head,mTrim,0,.0,.205,.02,.12,.03); cl(R.head,mTrim,-.22,.0,.0,.03,.12,.12); cl(R.head,mTrim,.22,.0,.0,.03,.12,.12);                           // yanak plakaları
    fc.eyeL.scale.set(1.15,1.05,1); fc.eyeR.scale.set(1.15,1.05,1);
    const eg=[]; for(const s of [-1,1]){ const sp=K.glowSprite(R.head,pal.eye!=null?pal.eye:0xfff0b0,.4,s*.075,.12,.235,.85); eg.push({sp,op:.85,s:.4,ph:s}); }
    /* hale + ışın halkası (kafanın arkasında dönen) */
    const hal=grp(R.head,0,.12,-.3); const ring=new THREE.Mesh(new THREE.TorusGeometry(.46,.016,6,56),halo); hal.add(ring);
    const rays=grp(hal,0,0,0); for(let i=0;i<14;i++){ const a=i/14*TAU; const m=new THREE.Mesh(new THREE.BoxGeometry(.018,i%2?.12:.2,.01),halo); m.position.set(Math.cos(a)*(.56),Math.sin(a)*.56,0); m.rotation.z=a-PI/2; rays.add(m); }
    const hg=K.glowSprite(hal,pal.halo!=null?pal.halo:0xffe08a,1.3,0,0,-.02,.35);
    /* dönen altın coinler (bel çevresinde) */
    const orb=grp(R.root,0,.05,0), coins=[]; for(let i=0;i<5;i++){ const cg=new THREE.Mesh(new THREE.CylinderGeometry(.09,.09,.014,18),mTrim); const rim=new THREE.Mesh(new THREE.TorusGeometry(.075,.008,5,16),mSec); rim.rotation.x=PI/2; cg.add(rim); orb.add(cg); coins.push({m:cg,ph:i/5*TAU}); }
    /* aura: altın pırıltı */
    const ac=pal.aura||[0xffe08a,0xfff6c0,0xffffff];
    const em=[{ob:R.chest,x:.55,y:.5,z:-.2,r:.3},{ob:R.chest,x:-.55,y:.5,z:-.2,r:.3},{ob:R.head,x:0,y:.3,z:-.2,r:.3},{ob:R.chest,x:0,y:.2,z:-.1,r:.5},{ob:R.hdL,x:0,y:-.05,z:0,r:.07},{ob:R.hdR,x:0,y:-.05,z:0,r:.07},{ob:R.ftL,x:0,y:-.1,z:.1,r:.07},{ob:R.ftR,x:0,y:-.1,z:.1,r:.07}];
    const glit=K.makeAura(g,{n:46,color:ac,vel:[0,.35,0],jit:.5,up:.5,life:[1,2.2],size:[.1,.02],rate:26,grav:.1,drag:.985,swirl:.6,op:.95,emit:em,flick:true});
    return Game.VIPRun(c,{hairs:[],auras:[{o:glit}],eyeGlow:eg,auraK:st=>.9+st.f*.9+(st.act?1.1:0),
      tick(st,dt,time){ const sp=st.act?2.2:1; ring.rotation.z=time*.35*sp; rays.rotation.z=-time*.6*sp; hg.material.opacity=.3+.1*Math.sin(time*2.4)+(st.act?.2:0);
        tex.offset.x=(time*.03)%1; tex.offset.y=(time*.015)%1;
        for(const k of coins){ const a=time*1.1*sp+k.ph; k.m.position.set(Math.cos(a)*.72,Math.sin(time*1.7+k.ph)*.1,Math.sin(a)*.72); k.m.rotation.set(time*2.2+k.ph,0,PI/2*Math.sin(time+k.ph)); } } }); } };

/* ------------------------------------------------------------------ NEON EJDERHA ------------------------------------------------------------------ */
function scaleTex(p){ const W=256, c=K.cnv(W,W), e=K.cnv(W,W), q=c.getContext("2d"), z=e.getContext("2d"); const base=p.base||"#0a1448", hi=p.hi||"#2a2fa8", edge=p.edge||"#ffe600", glow=p.glow||"#8a3cff";
  q.fillStyle=base; q.fillRect(0,0,W,W); z.fillStyle="#000"; z.fillRect(0,0,W,W); const rnd=K.rngS(p.seed||23), R=16, rows=W/(R*.6);
  for(let r=-1;r<rows+1;r++){ for(let k=-1;k<W/(R*2)+1;k++){ const x=k*R*2+(r&1?R:0), y=r*R*.6, tone=rnd();
      q.beginPath(); q.moveTo(x-R,y); q.quadraticCurveTo(x-R*.9,y+R*1.15,x,y+R*1.2); q.quadraticCurveTo(x+R*.9,y+R*1.15,x+R,y); q.closePath();
      const gr=q.createLinearGradient(x,y,x,y+R*1.2); gr.addColorStop(0,tone<.25?glow:hi); gr.addColorStop(1,base); q.fillStyle=gr; q.fill(); q.strokeStyle="rgba(0,0,10,.55)"; q.lineWidth=1.4; q.stroke();
      z.beginPath(); z.moveTo(x-R,y); z.quadraticCurveTo(x-R*.9,y+R*1.15,x,y+R*1.2); z.quadraticCurveTo(x+R*.9,y+R*1.15,x+R,y); z.strokeStyle=tone<.18?edge:glow; z.globalAlpha=tone<.18?.95:.5; z.lineWidth=1.5; z.stroke(); z.globalAlpha=1; } }
  const tc=new THREE.CanvasTexture(c), te=new THREE.CanvasTexture(e); tc.wrapS=tc.wrapT=te.wrapS=te.wrapT=THREE.RepeatWrapping; tc.repeat.set(2,2); te.repeat.set(2,2); return {c:tc,e:te}; }
function wingTex(p){ const W=256, c=K.cnv(W,W), q=c.getContext("2d"); const g=q.createLinearGradient(0,0,W,W); g.addColorStop(0,p.a||"#7a2cff"); g.addColorStop(.6,p.b||"#4a1ac0"); g.addColorStop(1,p.c||"#12104a"); q.fillStyle=g; q.fillRect(0,0,W,W);
  /* damarlar: kökten parmak uçlarına */ q.strokeStyle="rgba(255,230,0,.5)"; q.lineWidth=2; q.shadowColor="#ffe600"; q.shadowBlur=6;
  for(const [u,v] of WING_TIPS){ q.beginPath(); q.moveTo(0,W*.1); q.quadraticCurveTo(u*W*.5,v*W*.35+W*.1,u*W,v*W); q.stroke(); }
  q.shadowBlur=0; q.globalAlpha=.18; for(let i=0;i<60;i++){ q.fillStyle="#fff"; q.fillRect(Math.random()*W,Math.random()*W,1.5,1.5); }
  const t=new THREE.CanvasTexture(c); return t; }
/* kanat parmak uçları [x,geri] (metre) ve normalize */
const WING={ root:[0,0], wrist:[.52,-.1], tips:[[1.32,.1],[1.18,.55],[.86,.88],[.46,.98]], sx:1.4, sz:1.12, z0:.12 };
const nrm=(x,b)=>[x/WING.sx,(b+WING.z0)/WING.sz];
const WING_TIPS=WING.tips.map(t=>nrm(t[0],t[1]));
function boneBetween(par,mat,x0,b0,x1,b1,r0,r1,s){ const ax=x0*s, az=-b0, bx=x1*s, bz=-b1, dx=bx-ax, dz=bz-az, len=Math.hypot(dx,dz); const m=new THREE.Mesh(new THREE.CylinderGeometry(r1,r0,len,5),mat);
  m.position.set((ax+bx)/2,0,(az+bz)/2); m.rotation.order="YXZ"; m.rotation.set(PI/2,Math.atan2(dx,dz),0); m.castShadow=false; par.add(m); return m; }

Game.VIPB.neondrake={
  mats(c){ const {M,pri,sec,trim,pal}=c, T=scaleTex({base:pri,hi:pal.hi,edge:pal.edgeC||trim,glow:pal.glowC,seed:pal.seed});
    const body=keep(M("#ffffff",{roughness:.4,metalness:.4,map:T.c,emissive:0xffffff,emissiveMap:T.e,emissiveIntensity:1.05}));
    const neon=keep(M(trim,{roughness:.3,metalness:.2,emissive:trim,emissiveIntensity:1.15})), purp=keep(M(sec,{roughness:.45,metalness:.3,emissive:pal.purE!=null?pal.purE:0x4a14c0,emissiveIntensity:.7}));
    return {pri:body,sec:purp,trim:neon,skin:body,dark:M("#070a24",{roughness:.55,metalness:.4}),white:M("#fff7c8",{roughness:.4}),arm:body,leg:body,tor:body,hand:body,boot:purp,_horn:M(pal.horn||"#120a3c",{roughness:.35,metalness:.55,emissive:0x1a0a60,emissiveIntensity:.5}),_T:T}; },
  build(c){ const {R,add,cl,CO,SP,CY,TO,B,grp,M,mats,fc,pal,mPri,mSec,mTrim,mSkin,mDark,mWhite,mGlow,g,laserHex,vm,extra,setTail}=c;
    const horn=vm._horn, neon=mTrim, purp=mSec, tipM=basic({color:pal.edgeC!=null?pal.edgeC:0xffe600},mats), claw=M("#fff3a0",{roughness:.3,metalness:.4,emissive:0xaa8800,emissiveIntensity:.5});
    const lavaM=basic({color:0xff6a10,transparent:true,opacity:0,blending:AD,depthWrite:false},mats);
    /* ---- KAFA: ejderha başı ---- */
    fc.brL.visible=fc.brR.visible=fc.nose.visible=fc.mouth.visible=false;
    fc.eyeL.scale.set(1.2,.8,1); fc.eyeR.scale.set(1.2,.8,1);
    add(R.head,CY(.072,.118,.3,8),mSkin,0,.005,.3,PI/2,0,0,1,1,.74);                    // üst çene/burun
    add(R.head,SP(.075,8,6),mSkin,0,.03,.44,0,0,0,1.1,.8,1);                            // burun ucu
    for(const s of [-1,1]){ add(R.head,SP(.014,6,5),mDark,s*.032,.06,.475); add(R.head,B(.1,.04,.12),mSkin,s*.08,.18,.15,0,s*.15,s*.4); add(R.head,CO(.03,.12,4),horn,s*.12,.04,.2,PI/2,0,0); }  // burun delikleri, kaş çıkıntısı, yanak dikeni
    const jaw=grp(R.head,0,-.065,.07); add(jaw,CY(.052,.098,.28,8),mSkin,0,-.012,.17,PI/2,0,0,1,1,.6); add(jaw,CO(.025,.08,4),horn,0,-.07,.31,PI); add(jaw,B(.1,.02,.2),lavaM,0,.03,.18);
    for(let i=0;i<4;i++) for(const s of [-1,1]){ add(jaw,CO(.011,.05,4),mWhite,s*(.035+i*.0),.028,.1+i*.065,0,0,0); add(R.head,CO(.011,.05,4),mWhite,s*.045,-.03,.2+i*.065,PI); }
    add(R.head,B(.1,.02,.26),lavaM,0,-.043,.3);
    const mouth=grp(R.head,0,-.04,.48); extra.mouth=mouth;
    for(const s of [-1,1]){ /* ana boynuzlar (arkaya doğru bükülü) + neon uçlar */
      add(R.head,CO(.058,.36,6),horn,s*.11,.25,-.1,-1.0,0,s*-.28); add(R.head,CO(.032,.22,5),horn,s*.15,.4,-.4,-1.25,0,s*-.2); add(R.head,CO(.016,.13,5),tipM,s*.16,.46,-.58,-1.3,0,s*-.15);
      add(R.head,CO(.04,.2,5),horn,s*.2,.09,-.05,-.3,0,s*-1.25); add(R.head,CO(.018,.1,4),tipM,s*.33,.1,-.1,-.3,0,s*-1.3);
      add(R.head,B(.012,.12,.2),purp,s*.205,.1,-.12,0,s*.3,0); }
    for(let i=0;i<4;i++){ add(R.head,CO(.03-i*.004,.16-i*.02,5),horn,0,.27-i*.02,-.1-i*.1,-.9,0,0); add(R.head,CO(.012,.07,4),tipM,0,.33-i*.03,-.12-i*.1,-.9,0,0); }
    const eg=[]; for(const s of [-1,1]){ const sp=K.glowSprite(R.head,pal.eye!=null?pal.eye:0xffe600,.46,s*.075,.12,.235,.95); eg.push({sp,op:.95,s:.46,ph:s}); }
    const mg=K.glowSprite(mouth,0xff6a10,.9,0,0,0,0);
    /* ---- GÖVDE: karın plakaları, göğüs çekirdeği, sırt dikenleri, omuz dikenleri ---- */
    for(let i=0;i<5;i++) add(R.chest,B(.4-i*.018,.05,.03),purp,0,.4-i*.1,.222,0,0,0); for(let i=0;i<4;i++) add(R.spine,B(.3-i*.01,.05,.03),purp,0,.26-i*.085,.17);
    add(R.chest,CY(.075,.075,.04,6),tipM,0,.22,.235,PI/2); add(R.chest,TO(.105,.016,6,6),neon,0,.22,.238,0,0,0); const core=K.glowSprite(R.chest,pal.edgeC!=null?pal.edgeC:0xffe600,.55,0,.22,.3,.7);
    for(let i=0;i<5;i++){ const y=.46-i*.1, z=-.24-i*.003; add(R.chest,CO(.05-i*.004,.2-i*.02,5),horn,0,y,z,-.85,0,0); add(R.chest,CO(.02,.09,4),tipM,0,y+.05,z-.07,-.85,0,0); }
    for(let i=0;i<3;i++){ add(R.spine,CO(.04,.16,5),horn,0,.22-i*.1,-.2,-.8,0,0); add(R.spine,CO(.016,.07,4),tipM,0,.26-i*.1,-.26,-.8,0,0); }
    add(R.root,CO(.05,.16,5),horn,0,.0,-.2,-.9,0,0);
    for(const s of [-1,1]){ const el=s<0?R.elL:R.elR, kn=s<0?R.knL:R.knR, ft=s<0?R.ftL:R.ftR, hd=s<0?R.hdL:R.hdR;
      add(R.chest,SP(.2,12,9),mPri,s*.5,.4,0,0,0,0,1,.7,1.08);
      for(let i=0;i<3;i++){ add(R.chest,CO(.045-i*.007,.26-i*.05,5),horn,s*(.55+i*.06),.5+i*.04-.05,-.02+i*.04,0,0,s*(-.85-i*.15)); add(R.chest,CO(.017,.1,4),tipM,s*(.7+i*.1),.56+i*.04-.05,-.02+i*.04,0,0,s*(-.9-i*.15)); }
      add(el,CO(.05,.2,5),horn,0,-.04,-.1,-PI/2); add(el,CO(.018,.08,4),tipM,0,-.04,-.22,-PI/2); add(el,B(.014,.2,.1),purp,0,-.16,-.07); add(el,TO(.09,.015,5,12),neon,0,-.28,0,PI/2);
      for(let i=0;i<3;i++){ add(hd,CO(.022,.13,5),claw,(i-1)*.04,-.2,.06,PI-.5,0,0); } add(hd,CO(.02,.11,5),claw,s*.075,-.12,.04,PI-.5,0,s*-.6);
      add(kn,CO(.05,.2,5),horn,0,-.02,.1,PI/2); add(kn,CO(.04,.17,5),horn,0,-.14,-.09,-PI/2); add(kn,TO(.1,.016,5,12),neon,0,-.37,0,PI/2); add(kn,CO(.018,.08,4),tipM,0,-.14,-.2,-PI/2);
      for(const x of [-.06,0,.06]) add(ft,CO(.03,.16,5),claw,x,-.09,.3,PI/2); add(ft,CO(.028,.13,5),claw,0,-.09,-.08,-PI/2);
      add(R.root,B(.016,.4,.1),purp,s*.19,-.08,.12); }
    add(R.root,B(.62,.08,.38),purp,0,.05,0); add(R.root,CY(.1,.1,.04,6),tipM,0,.05,.2,PI/2);
    cl(R.root,mDark,0,-.14,.19,.2,.3,.04); cl(R.root,purp,0,-.32,.2,.16,.03,.04);
    /* ---- KUYRUK (7 parça, uçta bıçak) ---- */
    const tail=[]; let par=R.root; for(let i=0;i<7;i++){ const seg=grp(par,0,i===0?-.05:0,i===0?-.16:-.2); add(seg,CY(.105-i*.012,.092-i*.012,.22,8),mSkin,0,0,-.1,PI/2); add(seg,CO(.04-i*.004,.14-i*.01,5),horn,0,.08-i*.007,-.1);
      if(i<6) add(seg,CO(.016,.06,4),tipM,0,.17-i*.016,-.1); if(i===6){ add(seg,CO(.1,.34,4),neon,0,0,-.34,-PI/2,0,0,1.7,1,.28); add(seg,CO(.05,.2,4),purp,0,0,-.3,-PI/2,0,0,1.5,1,.3); } tail.push(seg); par=seg; }
    setTail(tail);
    /* ---- KANATLAR (membran + neon kemikler) ---- */
    const wt=wingTex({}), memM=keep(M("#ffffff",{roughness:.55,metalness:.1,map:wt,emissive:0x5a1aff,emissiveIntensity:.55,side:THREE.DoubleSide,transparent:true,opacity:.9})), wingsG=[];
    const sh=new THREE.Shape(); const P=(x,b)=>nrm(x,b); const p0=P(0,0), pw=P(WING.wrist[0],WING.wrist[1]), T=WING.tips.map(t=>P(t[0],t[1]));
    sh.moveTo(p0[0],p0[1]); sh.lineTo(pw[0],pw[1]); sh.lineTo(T[0][0],T[0][1]);
    const ctl=[[.93,.2],[.7,.5],[.4,.65]]; for(let i=1;i<4;i++){ const cp=P(ctl[i-1][0],ctl[i-1][1]); sh.quadraticCurveTo(cp[0],cp[1],T[i][0],T[i][1]); }
    const bk=P(.1,.7); sh.quadraticCurveTo(bk[0],bk[1],p0[0],P(0,.55)[1]); sh.lineTo(p0[0],p0[1]);
    const memG=new THREE.ShapeGeometry(sh);
    for(const s of [-1,1]){ const w=grp(R.chest,s*.2,.34,-.22); const mem=new THREE.Mesh(memG,memM); mem.rotation.x=-PI/2; mem.scale.set(s*WING.sx,WING.sz,1); mem.position.set(0,0,WING.z0); mem.frustumCulled=false; w.add(mem);
      boneBetween(w,horn,0,0,WING.wrist[0],WING.wrist[1],.034,.024,s); boneBetween(w,neon,0,.0,WING.wrist[0],WING.wrist[1],.012,.01,s);
      for(const t of WING.tips){ boneBetween(w,horn,WING.wrist[0],WING.wrist[1],t[0],t[1],.018,.007,s); boneBetween(w,neon,WING.wrist[0],WING.wrist[1],t[0],t[1],.008,.005,s); }
      const prev=[WING.tips[0],WING.tips[1],WING.tips[2],WING.tips[3]]; for(let i=0;i<3;i++){ const a=prev[i], b=prev[i+1], cp=ctl[i]; boneBetween(w,neon,a[0],a[1],cp[0],cp[1],.01,.01,s); boneBetween(w,neon,cp[0],cp[1],b[0],b[1],.01,.01,s); }
      const cw=new THREE.Mesh(new THREE.ConeGeometry(.03,.16,5),claw); cw.position.set(s*(WING.wrist[0]+.02),0,-WING.wrist[1]+.0); cw.rotation.set(-PI/2,0,s*-.5); w.add(cw);
      wingsG.push(w); }
    /* ---- AURA: sarı/mor kıvılcım + ağız dumanı ---- */
    const ac=pal.aura||[0xffe600,0xa060ff,0xffffff];
    const em=[{ob:R.chest,x:.8,y:.5,z:-.3,r:.4},{ob:R.chest,x:-.8,y:.5,z:-.3,r:.4},{ob:R.head,x:0,y:.35,z:-.2,r:.2},{ob:R.chest,x:0,y:.2,z:-.2,r:.4},{ob:R.hdL,x:0,y:-.05,z:0,r:.07},{ob:R.hdR,x:0,y:-.05,z:0,r:.07},{ob:R.ftL,x:0,y:-.1,z:.1,r:.06},{ob:R.ftR,x:0,y:-.1,z:.1,r:.06}];
    const sparks=K.makeAura(g,{n:40,color:ac,vel:[0,.7,0],jit:.8,up:.7,life:[.9,2],size:[.12,.02],rate:24,grav:.2,drag:.985,swirl:.8,op:.95,emit:em,flick:true});
    let jw=0, lv=0, wf=0, wsp=0;
    return Game.VIPRun(c,{hairs:[],auras:[{o:sparks}],eyeGlow:eg,auraK:st=>.8+st.f*.8+(st.act?1.4:0),
      tick(st,dt,time){ const br=(st.act==="breath"||st.act==="laser")?1:0, k=1-Math.exp(-dt*9);
        jw=lerp(jw,br?.62+.08*Math.sin(time*18):.03+.02*Math.sin(time*1.6),k); jaw.rotation.x=jw; lv=lerp(lv,br,k); lavaM.opacity=lv*.95; mg.material.opacity=lv*.85; const ms=.5+lv*.7+Math.sin(time*20)*.06*lv; mg.scale.set(ms,ms,1);
        core.material.opacity=.55+.2*Math.sin(time*3.3)+(st.act?.25:0);
        /* kanat: yerde kıvrık, uçarken çırpma, hızlı uçuşta arkaya yatık */
        const fl=st.fly, boost=st.boost, flap=fl?(boost?Math.sin(time*13)*.22+.15:Math.sin(time*6.5)*.55+.25):Math.sin(time*1.4)*.05-.1;
        const tz=fl?flap:-.45+flap, ty=fl?(boost?.95:.55):1.02+.05*Math.sin(time*1.4), kk=1-Math.exp(-dt*(fl?12:6)); wf=lerp(wf,tz,kk); wsp=lerp(wsp,ty,kk);
        for(let i=0;i<2;i++){ const s=i===0?-1:1, w=wingsG[i]; w.rotation.z=s*wf; w.rotation.y=s*wsp; } } }); } };

/* ------------------------------------------------------------------ KATALOG ------------------------------------------------------------------ */
Object.assign(CHARS,{
  altin:{vip:true,icon:"👑",laser:0xffd24a,eye:0xfff0b0,accent:"#ffc933",cape:{w:1.04,h:1.5,cols:9,rows:14,ay:.36,az:-.22,make:capeMat("storm"),jag:(j,dep,time)=>dep>.6?(Math.sin(time*2.6+j*2)*.5+.5)*.08*(dep-.6)/.4:0},
    skins:[["#ffd75a","#3a2400","#ffe08a","#caa000",0,{eye:0xfff0b0,laser:0xffd24a,gem:0xff3a5a,halo:0xffe08a,em:0x9a6400,gt:{a:"#a86a00",b:"#ffd24a",c:"#fff6c2",seed:11},aura:[0xffe08a,0xfff6c0,0xffffff],cape:{a:"#5a3600",b:"#d89a00",c:"#fff0a0",bolt:"rgba(255,255,255,.95)"}}],
           ["#e8eef6","#222a3a","#ffffff","#9fb0c8",0,{eye:0xd8f2ff,laser:0x9fe0ff,gem:0x38c8ff,halo:0xbfe8ff,em:0x3a4a66,gt:{a:"#7a8aa4",b:"#dfe8f4",c:"#ffffff",seed:19},aura:[0xcfe8ff,0xffffff,0x9fd8ff],cape:{a:"#2a3650",b:"#9fb0c8",c:"#ffffff",bolt:"rgba(190,235,255,.95)"}}]]},
  neondrake:{vip:true,mouthFire:true,icon:"🐲",laser:0xff6a10,eye:0xffe600,accent:"#0a1448",cape:null,
    skins:[["#0a1448","#7a2cff","#ffe600","#4a1ac0",0,{eye:0xffe600,laser:0xff6a10,hi:"#2a2fa8",glowC:"#8a3cff",edgeC:0xffe600,purE:0x4a14c0,horn:"#120a3c",seed:23,aura:[0xffe600,0xa060ff,0xffffff]}],
           ["#08080f","#d414a0","#18e8ff","#7a0a5a",0,{eye:0x18e8ff,laser:0xff6a10,hi:"#3a0a50",glowC:"#ff2ad0",edgeC:0x18e8ff,purE:0x8a0a70,horn:"#1a0620",seed:31,aura:[0x18e8ff,0xff2ad0,0xffffff]}]]}
});
})();
