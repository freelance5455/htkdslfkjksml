"use strict";
/* ===== ANA MENÜ SAHNESİ: KIRMIZI CEHENNEM — lav ovası, kor yağmuru, kara kayalar, yanan harabe silüeti, dev kızıl güneş.
   Kahraman sağda, ekrana bakar; gözler 2 sn'de bir kırmızı enerjiyle parlar ve söner. Oyun sahnesinden ayrı sahne (menü açıkken şehir çizilmez). ===== */
Game.menu3d=null;
(function(){
try{
const sc=new THREE.Scene(), cam=new THREE.PerspectiveCamera(36,innerWidth/innerHeight,.1,2500);
sc.background=new THREE.Color(0x120203); sc.fog=new THREE.FogExp2(0x5a0d05,.0105);
const GLSL_NOISE=[
"float h21(vec2 p){ p=fract(p*vec2(123.34,456.21)); p+=dot(p,p+45.32); return fract(p.x*p.y); }",
"float n2(vec2 p){ vec2 i=floor(p), f=fract(p); f=f*f*(3.-2.*f); return mix(mix(h21(i),h21(i+vec2(1.,0.)),f.x),mix(h21(i+vec2(0.,1.)),h21(i+vec2(1.,1.)),f.x),f.y); }",
"float fbm2(vec2 p){ float a=.5, s=0.; for(int i=0;i<5;i++){ s+=a*n2(p); p=p*2.02+vec2(3.1,1.7); a*=.5; } return s; }"].join("\n");
/* --- parıltı dokusu (radyal) --- */
function makeGlow(hex,op){ return new THREE.Sprite(new THREE.SpriteMaterial({map:glowTex(),color:hex,transparent:true,opacity:op,blending:THREE.AdditiveBlending,depthWrite:false,fog:false})); }
let _gt=null; function glowTex(){ if(_gt) return _gt; const c=document.createElement("canvas"); c.width=c.height=128; const q=c.getContext("2d"), g=q.createRadialGradient(64,64,0,64,64,64);
  g.addColorStop(0,"rgba(255,255,255,1)"); g.addColorStop(.18,"rgba(255,255,255,.75)"); g.addColorStop(.5,"rgba(255,255,255,.18)"); g.addColorStop(1,"rgba(255,255,255,0)"); q.fillStyle=g; q.fillRect(0,0,128,128); _gt=new THREE.CanvasTexture(c); return _gt; }
/* --- gökyüzü kubbesi --- */
const SKY={time:{value:0},sunDir:{value:new THREE.Vector3(-.42,.13,-.9).normalize()},flash:{value:0}};
const sky=new THREE.Mesh(new THREE.SphereGeometry(1800,32,20),new THREE.ShaderMaterial({side:THREE.BackSide,depthWrite:false,fog:false,toneMapped:false,uniforms:SKY,
  vertexShader:"varying vec3 vD; void main(){ vD=position; vec4 mv=modelViewMatrix*vec4(position,1.0); gl_Position=projectionMatrix*mv; gl_Position.z=gl_Position.w*.99999; }",
  fragmentShader:["uniform float time; uniform vec3 sunDir; uniform float flash; varying vec3 vD;\n"+GLSL_NOISE+"\n"+
"void main(){ vec3 d=normalize(vD); float y=d.y;",
"  vec3 hor=vec3(1.05,.2,.04), mid=vec3(.34,.035,.02), top=vec3(.03,.0,.007);",
"  vec3 col=mix(hor,mid,smoothstep(0.,.22,y)); col=mix(col,top,smoothstep(.12,.85,y)); if(y<0.) col=mix(hor*.6,vec3(.15,.02,.01),smoothstep(0.,-.3,y));",
"  float sd=max(dot(d,sunDir),0.); col+=vec3(1.,.28,.05)*pow(sd,5.)*.9+vec3(1.,.6,.2)*pow(sd,48.)*1.3+vec3(1.,.9,.6)*smoothstep(.9972,.9986,sd)*3.2;",
"  if(y>.0){ vec2 p=d.xz/(y+.16)*1.25+vec2(time*.012,time*.004); float n=fbm2(p), n2v=fbm2(p*1.9+vec2(time*.02,0.)); float cl=smoothstep(.42,.78,n*.7+n2v*.45)*smoothstep(0.,.08,y);",
"    float lit=pow(clamp(1.-y*1.2,0.,1.),2.2)*(.35+.65*sd*sd); vec3 cc=mix(vec3(.025,.004,.004),vec3(1.,.28,.06),lit); cc+=vec3(1.,.5,.2)*pow(sd,10.)*.4*(1.-cl*.5); col=mix(col,cc,cl*.9); }",
"  col+=vec3(.9,.25,.15)*flash*smoothstep(-.1,.7,y)*.5;",
"  gl_FragColor=vec4(col,1.);",
"#include <tonemapping_fragment>",
"#include <encodings_fragment>",
"}"].join("\n")}));
sky.renderOrder=-10; sky.frustumCulled=false; sc.add(sky);
/* --- lav ovası --- */
const LV={time:{value:0}};
const lava=new THREE.Mesh(new THREE.PlaneGeometry(1600,1600,1,1),new THREE.ShaderMaterial({fog:false,toneMapped:false,uniforms:LV,
  vertexShader:"varying vec3 vP; void main(){ vec4 wp=modelMatrix*vec4(position,1.0); vP=wp.xyz; gl_Position=projectionMatrix*viewMatrix*wp; }",
  fragmentShader:["uniform float time; varying vec3 vP;\n"+GLSL_NOISE+"\n"+
"vec2 vor(vec2 p){ vec2 g=floor(p), f=fract(p); float d1=8., d2=8.; for(int j=-1;j<=1;j++){ for(int i=-1;i<=1;i++){ vec2 o=vec2(float(i),float(j)); vec2 r=o+vec2(h21(g+o),h21(g+o+17.3))*.85+.075-f; float d=dot(r,r); if(d<d1){ d2=d1; d1=d; } else if(d<d2){ d2=d; } } } return vec2(sqrt(d1),sqrt(d2)); }",
"void main(){ vec2 p=vP.xz*.22; float n=fbm2(p*.6+vec2(time*.02,0.)); vec2 v=vor(p+n*.7); float edge=v.y-v.x; float crack=1.-smoothstep(0.,.16,edge);",
"  float pulse=.65+.35*sin(time*.9+n*9.+v.x*5.); float heat=clamp(crack*pulse*1.25+n*.12,0.,1.);",
"  vec3 crust=vec3(.03,.011,.009)*(.5+n*1.2); vec3 lv=mix(vec3(.75,.1,.015),vec3(1.1,.7,.18),heat*heat); vec3 col=mix(crust,lv,smoothstep(.18,.62,heat));",
"  col+=vec3(.5,.07,.01)*smoothstep(.55,1.,fbm2(p*2.4-time*.05))*.25;",
"  float dist=length(vP-cameraPosition); float f=1.-exp(-dist*.0105); col=mix(col,vec3(.5,.08,.025),clamp(f,0.,1.)*.9);",
"  gl_FragColor=vec4(col,1.);",
"#include <tonemapping_fragment>",
"#include <encodings_fragment>",
"}"].join("\n")}));
lava.rotation.x=-Math.PI/2; lava.position.y=-.55; sc.add(lava);
/* --- kayalar: platform + kule gibi sivri kayalar + uzak yanan harabeler --- */
const rockMat=Game.noSnow(new THREE.MeshStandardMaterial({color:0x1b0b0a,roughness:.95,metalness:.05,flatShading:true,emissive:0x1a0300,emissiveIntensity:.8}));
const rnd=(()=>{ let s=1666; return ()=>{ s=(s*16807)%2147483647; return s/2147483647; }; })();
function rockGeo(r0,r1,h,seg,jit){ const g=new THREE.CylinderGeometry(r1,r0,h,seg,3,false), p=g.attributes.position; for(let i=0;i<p.count;i++){ const y=p.getY(i); if(y>h*.49||y<-h*.49) continue; const k=1+(rnd()-.5)*jit; p.setX(i,p.getX(i)*k); p.setZ(i,p.getZ(i)*k); p.setY(i,y+(rnd()-.5)*h*.08); } if(g.computeVertexNormals) g.computeVertexNormals(); return g; }
const plat=new THREE.Mesh(rockGeo(3.1,2.6,.9,9,.28),rockMat); plat.position.set(2.55,-.12,.1); sc.add(plat);
const platGlow=new THREE.Mesh(new THREE.RingGeometry(2.75,3.35,40),new THREE.MeshBasicMaterial({color:0xff4a10,transparent:true,opacity:.55,blending:THREE.AdditiveBlending,depthWrite:false,fog:false})); platGlow.rotation.x=-Math.PI/2; platGlow.position.set(2.55,-.5,.1); sc.add(platGlow);
const spires=[];
for(let i=0;i<34;i++){ const side=rnd()<.5?-1:1, x=side*(8+rnd()*70)+(i%5===0?(rnd()-.5)*10:0), z=-12-rnd()*80, h=10+rnd()*(18+Math.abs(x)*.22), r=2.2+rnd()*5.5;
  const g=new THREE.ConeGeometry(r,h,5+(i%3),3,false), p=g.attributes.position; for(let k=0;k<p.count;k++){ const y=p.getY(k); if(y<h*.48){ const j=1+(rnd()-.5)*.5; p.setX(k,p.getX(k)*j); p.setZ(k,p.getZ(k)*j); } } if(g.computeVertexNormals) g.computeVertexNormals();
  const m=new THREE.Mesh(g,rockMat); m.position.set(x,h/2-1,z); m.rotation.y=rnd()*6; m.rotation.z=(rnd()-.5)*.12; sc.add(m); spires.push(m); }
/* yanan harabe silüetleri (uzakta, dumanlı) */
const ruinMat=new THREE.MeshBasicMaterial({color:0x140404}), fires=[];
for(let i=0;i<26;i++){ const x=-170+i*13.5+(rnd()-.5)*8, z=-150-rnd()*90, w=5+rnd()*9, h=14+rnd()*52, b=new THREE.Mesh(new THREE.BoxGeometry(w,h,w*(.7+rnd()*.5)),ruinMat); b.position.set(x,h/2-2,z); b.rotation.y=(rnd()-.5)*.5; sc.add(b);
  if(rnd()<.45){ const f=makeGlow(0xff6a1a,.9); f.position.set(x+(rnd()-.5)*w*.5,h-2+rnd()*2,z+w*.4); f.scale.set(14+rnd()*14,22+rnd()*22,1); f.userData.ph=rnd()*6; sc.add(f); fires.push(f); } }
/* --- kor yağmuru --- */
const NE=520, sd4=new Float32Array(NE*4); for(let i=0;i<NE;i++){ sd4[i*4]=rnd(); sd4[i*4+1]=rnd(); sd4[i*4+2]=rnd(); sd4[i*4+3]=.4+rnd()*1.1; }
const eg=new THREE.BufferGeometry(); eg.setAttribute("position",new THREE.BufferAttribute(new Float32Array(NE*3),3)); eg.setAttribute("sd",new THREE.BufferAttribute(sd4,4));
const EM={time:{value:0},scale:{value:900}};
const embers=new THREE.Points(eg,new THREE.ShaderMaterial({transparent:true,depthWrite:false,blending:THREE.AdditiveBlending,fog:false,toneMapped:false,uniforms:EM,
  vertexShader:"attribute vec4 sd; uniform float time,scale; varying float va; varying float vh; void main(){ float t=time*(.35+sd.w*.5)+sd.x*40.; vec3 p=vec3(sd.x*26.-13.+sin(t*.9+sd.y*20.)*1.2+time*.25*sd.w, mod(sd.y*14.+t*.9,14.)-1., sd.z*24.-14.+cos(t*.7+sd.x*20.)*1.1); vec4 mv=viewMatrix*vec4(p,1.); gl_Position=projectionMatrix*mv; va=(1.-smoothstep(9.,14.,p.y+1.))*(.55+.45*sin(time*(4.+sd.w*6.)+sd.x*50.)); vh=sd.w; gl_PointSize=clamp(scale*(.05+.05*sd.w)/max(-mv.z,.5),1.,18.); }",
  fragmentShader:"varying float va; varying float vh; void main(){ vec2 c=gl_PointCoord-.5; float a=smoothstep(.5,.0,length(c))*va; if(a<.02) discard; gl_FragColor=vec4(mix(vec3(1.,.28,.04),vec3(1.,.8,.3),vh*.6),a); }"}));
embers.frustumCulled=false; embers.renderOrder=8; sc.add(embers);
/* --- ışıklar --- */
const hemiM=new THREE.HemisphereLight(0x8a2410,0xff4a12,.62); sc.add(hemiM);
const rim=new THREE.DirectionalLight(0xff7a30,2.1); rim.position.set(-7,3.5,-9); sc.add(rim); sc.add(rim.target); rim.target.position.set(2.6,1.8,0);
const key=new THREE.PointLight(0xff3a10,2.2,16,2); key.position.set(1.2,.3,5.2); sc.add(key);
const eyeL=new THREE.PointLight(0xff1a0a,0,7,2); sc.add(eyeL);
/* --- kahraman --- */
const stage=new THREE.Group(); stage.position.set(2.55,0,.1); sc.add(stage);
let hero=null, mHead=null, glow=[], streak=null, eyeMat=null; const EYE_X=.075, EYE_Y=.12, EYE_Z=.2;
function rebuild(){ try{
  if(hero){ stage.remove(hero); hero=null; } glow.length=0;
  const m=buildHeroModel(Game.char,Game.skin,Game.accent); m.scale.setScalar(2.0); m.position.y=1.8; m.rotation.y=-.34; stage.add(m); hero=m;
  m.traverse(o=>{ if(o.isMesh){ o.castShadow=false; } });
  if(Game.Anim) Game.Anim.reset(m);
  const u=m.userData, head=u.rig.head; eyeMat=u.eyeMat;
  const vipHex=u.vip?u.eyeHex:null; eyeL.color.setHex(vipHex!=null?vipHex:0xff1a0a);
  for(const s of [-1,1]){ const g=makeGlow(vipHex!=null?vipHex:0xff1e0a,0); g.material.depthTest=false; g.position.set(s*EYE_X,EYE_Y,EYE_Z); g.scale.set(.5,.5,1); g.renderOrder=20; head.add(g); glow.push(g); }
  streak=makeGlow(vipHex!=null?vipHex:0xff3a18,0); streak.material.depthTest=false; streak.position.set(0,EYE_Y,EYE_Z+.03); streak.scale.set(2.4,.12,1); streak.renderOrder=21; head.add(streak);
  eyeL.position.set(0,0,0); head.add(eyeL);
  eyeL.position.set(0,EYE_Y+.02,EYE_Z+.5);
  if(Game.Anim&&Game.Anim.menuPose) Game.Anim.menuPose(m,.5,0,0,22);
}catch(e){ if(window.reportErr) reportErr(e); } }
const sm=(a,b,x)=>{ const t=Math.max(0,Math.min(1,(x-a)/(b-a))); return t*t*(3-2*t); };
/* göz nabzı: her 2 saniyede bir kırmızı enerji patlaması → sönme */
function pulse(t){ const k=(t%2)/2; return sm(0,.04,k)*(1-sm(.14,.62,k))*(.9+.1*Math.sin(t*90)); }
const HOT=new THREE.Color(1,.18,.08), DIM=new THREE.Color(.1,.02,.02), WHITE=new THREE.Color(1,.8,.7), tmpC=new THREE.Color();
let t0=0, eyeK=0;
function update(dt,time){ if(!hero) return; t0+=dt; const tt=t0;
  SKY.time.value=tt; LV.time.value=tt; EM.time.value=tt; EM.scale.value=(Game.three.renderer?Game.three.renderer.domElement.height:900);
  /* kamera: yavaş sinematik süzülme */
  cam.position.set(-.1+Math.sin(tt*.17)*.35,1.35+Math.sin(tt*.23)*.07,10.2+Math.sin(tt*.13)*.25); cam.lookAt(.75+Math.sin(tt*.11)*.12,2.0,0);
  if(Game.Anim&&Game.Anim.menuPose) Game.Anim.menuPose(hero,dt,tt,3*Math.sin(tt*.6),22+4*Math.sin(tt*1.3));
  const e=pulse(tt); eyeK=e;
  if(eyeMat&&eyeMat.color&&!hero.userData.vip){ tmpC.copy(DIM).lerp(HOT,Math.min(1,e*1.4)).lerp(WHITE,Math.max(0,e-.75)*2); eyeMat.color.copy(tmpC); }
  for(const g of glow){ g.material.opacity=Math.min(1,e*1.05); const s=.13+e*.6; g.scale.set(s,s,1); }
  if(streak){ streak.material.opacity=e*.75; streak.scale.set(.4+e*2.2,.04+e*.1,1); }
  eyeL.intensity=e*5.5; key.intensity=2.2*(1+.1*Math.sin(tt*7.3)+.06*Math.sin(tt*17.1))+e*1.2; hemiM.intensity=.62+e*.18; SKY.flash.value=e*.35;
  platGlow.material.opacity=.45+.15*Math.sin(tt*1.4);
  for(const f of fires){ const q=.65+.35*Math.sin(tt*5+f.userData.ph)*Math.sin(tt*3.1+f.userData.ph*2); f.material.opacity=.55*q; }
  stage.rotation.y=Math.sin(tt*.3)*.02; }
function resize(){ cam.aspect=innerWidth/innerHeight; cam.updateProjectionMatrix(); }
rebuild(); resize();
Game.menu3d={scene:sc,cam,update,resize,rebuild,eye:()=>eyeK,hero:()=>hero,stage};
Game.updaters.push((dt0,time,raw)=>{ if(Game.mode!=="menu"||!Game.menu3d) return; update(raw||dt0,time); });
Game.updaters[Game.updaters.length-1].__menu=true;
}catch(e){ Game.menu3d=null; if(window.reportErr) reportErr(e); else console.error(e); }
})();
