"use strict";
/* ===== KAHRAMAN: model, çoklu dokunma, hareket, uçuş, çarpışma (parça kutuları), deniz sınırı, hayalet geçiş, uzay, kamera ===== */
const U = Game.U, W = Game.W;
const hero = new THREE.Group(); hero.rotation.order = "YXZ";
const S = 1.4, HIP = 0.9*S, RAD = .62, HEAD = 1.55, STEP = .6;
let heroModel = null, lastFp=false, fpT=0, fpPh=0, fpY=null, fpRoll=0;
Game.char = store.get("char","classic"); if(!CHARS[Game.char]) Game.char="classic";
Game.skin = +store.get("skinIdx","0")||0; Game.accent = store.get("accent","")||null;
Game.setCharacter = function(id, skin, accent){
  if(id) Game.char=id; if(skin!==undefined&&skin!==null) Game.skin=skin|0; if(accent!==undefined) Game.accent=accent||null;
  store.set("char",Game.char); store.set("skinIdx",String(Game.skin)); store.set("accent",Game.accent||"");
  if(heroModel){ hero.remove(heroModel); }
  heroModel = buildHeroModel(Game.char, Game.skin, Game.accent); hero.add(heroModel); Game.model=heroModel;
  if(Game.Anim) Game.Anim.reset(heroModel);
  if(Game.menu3d&&Game.menu3d.rebuild) Game.menu3d.rebuild(); };
hero.scale.setScalar(S); hero.position.set(17,HIP,17); scene.add(hero); Game.heroObj = hero;

const H = Game.H = {vel:new THREE.Vector3(), yaw:0, pitch:.1, flying:false, face:0, boost:false, speed:0, shake:0, gscale:1,
  grounded:true, smash:false, sp:0, alt:0, wet:false, onWater:false, hv:0, turn:0, landT:0, landLock:0, mv:0, hitWall:false, speedMul:1};
Game.setCharacter();
const joy = {x:0,y:0,id:null,ox:0,oy:0}, lk = {id:null,x:0,y:0};
const joyEl = $("joy"), joyKnob = joyEl.firstElementChild, JR = 55, jz = $("joyZone"), lz = $("lookZone");
const pmax=()=>H.flying?1.45:1.1;
jz.addEventListener("touchstart",e=>{ if(joy.id!==null) return; const t=e.changedTouches[0]; joy.id=t.identifier; joy.ox=t.clientX; joy.oy=t.clientY;
  joyEl.style.display="block"; joyEl.style.left=t.clientX+"px"; joyEl.style.top=t.clientY+"px"; e.preventDefault(); },{passive:false});
jz.addEventListener("touchmove",e=>{ for(const t of e.changedTouches) if(t.identifier===joy.id){
  let dx=t.clientX-joy.ox, dy=t.clientY-joy.oy; const l=Math.hypot(dx,dy)||1, k=Math.min(l,JR)/l; dx*=k; dy*=k; joy.x=dx/JR; joy.y=dy/JR; joyKnob.style.transform=`translate(${dx}px,${dy}px)`; } e.preventDefault(); },{passive:false});
["touchend","touchcancel"].forEach(n=>jz.addEventListener(n,e=>{ for(const t of e.changedTouches) if(t.identifier===joy.id){ joy.id=null; joy.x=joy.y=0; joyEl.style.display="none"; joyKnob.style.transform=""; } }));
lz.addEventListener("touchstart",e=>{ if(lk.id!==null) return; const t=e.changedTouches[0]; lk.id=t.identifier; lk.x=t.clientX; lk.y=t.clientY; e.preventDefault(); },{passive:false});
lz.addEventListener("touchmove",e=>{ for(const t of e.changedTouches) if(t.identifier===lk.id){
  H.yaw -= (t.clientX-lk.x)*.006*Game.settings.sens; H.pitch = Math.max(-1.3,Math.min(pmax(),H.pitch-(t.clientY-lk.y)*.005*Game.settings.sens)); lk.x=t.clientX; lk.y=t.clientY; } e.preventDefault(); },{passive:false});
["touchend","touchcancel"].forEach(n=>lz.addEventListener(n,e=>{ for(const t of e.changedTouches) if(t.identifier===lk.id) lk.id=null; }));
/* Masaüstü test kolaylığı: WASD + fare sürükleme */
const keys={}; addEventListener("keydown",e=>{ keys[e.key.toLowerCase()]=true; }); addEventListener("keyup",e=>{ keys[e.key.toLowerCase()]=false; });
let md=false; lz.addEventListener("mousedown",e=>{ md=true; lk.x=e.clientX; lk.y=e.clientY; }); addEventListener("mouseup",()=>md=false);
addEventListener("mousemove",e=>{ if(!md) return; H.yaw-=(e.clientX-lk.x)*.006*Game.settings.sens; H.pitch=Math.max(-1.3,Math.min(pmax(),H.pitch-(e.clientY-lk.y)*.005*Game.settings.sens)); lk.x=e.clientX; lk.y=e.clientY; });

const fwd=new THREE.Vector3(), rgt=new THREE.Vector3(), dir=new THREE.Vector3(), lookV=new THREE.Vector3(), camT=new THREE.Vector3(), tmp=new THREE.Vector3(), piv=new THREE.Vector3(), UP=new THREE.Vector3(0,1,0), rr={};
Game.lookV=lookV; Game.heroFwd=new THREE.Vector3(0,0,1);
const sm01=x=>{ x=x<0?0:x>1?1:x; return x*x*(3-2*x); };
H.spaceT=y=>sm01((y-1200)/2800);
Game.lookActive=()=>lk.id!==null||md;
Game.resetCamPivot=()=>{ piv.set(hero.position.x,hero.position.y+2.2,hero.position.z); camDist=-1; };
Game.resetHero=function(){ hero.position.set(17,HIP,17); H.vel.set(0,0,0); H.flying=false; H.yaw=0; H.pitch=.1; H.smash=false; piv.copy(hero.position); camDist=-1; };

/* ---- bildirim (toast) ve bölge etiketi ---- */
let toastT=0, lastToast="", toastCool={};
Game.toast=function(key,ms){ const el=$("toast"); if(!el) return; const now=performance.now(); if(toastCool[key]&&now-toastCool[key]<(ms||2200)+800) return; toastCool[key]=now;
  el.textContent=t(key); el.classList.add("on"); toastT=(ms||2200)/1000; lastToast=key; };
Game.onLang2=()=>{ const el=$("toast"); if(el&&el.classList.contains("on")) el.textContent=t(lastToast); };

/* ---- zemin / çarpışma ---- */
const cand=[];
function gather(x0,y0,z0,x1,y1,z1,solidOnly){ cand.length=0;
  for(const e of Game.buildings){ if(e.h<=0) continue; const ey0=e.y0||0;
    if(x1<e.x-e.hw||x0>e.x+e.hw||z1<e.z-e.hd||z0>e.z+e.hd||y1<ey0||y0>e.h) continue;
    if(!e.tier){ cand.push(e.x-e.hw,ey0,e.z-e.hd,e.x+e.hw,e.h,e.z+e.hd); continue; }
    if(solidOnly) continue;
    for(const c of e.tier.chunks){ if(!c.alive) continue; const b=c.bx;
      for(let k=0;k<b.length;k+=6){ if(x1<b[k]||x0>b[k+3]||z1<b[k+2]||z0>b[k+5]||y1<b[k+1]||y0>b[k+4]) continue; cand.push(b[k],b[k+1],b[k+2],b[k+3],b[k+4],b[k+5]); } } }
  if(treeSolid&&Game.Trees) Game.Trees.solids(x0,y0,z0,x1,y1,z1,cand); }
let treeSolid=true;   /* ağaç gövdesi kutuları: kahraman için; araç kendi daire engellerini (drive.js) kullanır */
Game.gatherBoxes=(x0,y0,z0,x1,y1,z1,solidOnly)=>{ treeSolid=false; gather(x0,y0,z0,x1,y1,z1,solidOnly); treeSolid=true; return cand; };
function overlapAny(p){ gather(p.x-RAD-.5,p.y-HIP-.5,p.z-RAD-.5,p.x+RAD+.5,p.y+HEAD+.5,p.z+RAD+.5); const fy=p.y-HIP+.05, ty=p.y+HEAD-.05, x0=p.x-RAD+.05, x1=p.x+RAD-.05, z0=p.z-RAD+.05, z1=p.z+RAD-.05;
  for(let k=0;k<cand.length;k+=6){ if(x1<=cand[k]||x0>=cand[k+3]||z1<=cand[k+2]||z0>=cand[k+5]||ty<=cand[k+1]||fy>=cand[k+4]) continue; return true; } return false; }
const deckAt=(x,z)=>{ const f=W.bridge&&W.bridge.deckAt; if(!f) return null; const d=f(x,z); return d===undefined?null:d; };
function floorAt(x,z,fy,vy){ let h=W.terrainH(x,z), wet=false; if(h<W.WATER_Y){ h=W.WATER_Y; wet=true; }
  const dk=deckAt(x,z); if(dk!==null&&dk>h&&fy>=dk-.45&&vy<=.5){ h=dk; wet=false; }
  if(Game.Moon){ const mf=Game.Moon.floor(x,z,fy,vy); if(mf!==null&&mf>h){ h=mf; wet=false; } } rr.wet=wet; return h; }
const walkOK=(x,z)=>{ const dk=deckAt(x,z); return dk!==null||W.terrainH(x,z)>=W.WALK_MIN||(Game.Moon&&Game.Moon.over(x,z)); };
function landed(vy,wet,p){ if(vy>-12) return; H.landT=Math.min(1,-vy/50);
  if(wet){ const s=Math.min(4,-vy/14); Game.splash(p.x,p.z,s); H.shake=Math.max(H.shake,.25); return; }
  const imp=-vy, k=Game.Land?Game.Land.power(imp):0;
  if(imp>=26){ FX.dust(p.x,p.y-HIP+.3,p.z,14,3); H.shake=Math.max(H.shake,.4); Game.D.damageSphere(p.x,p.y-HIP,p.z,4+6*k,.3+.5*k,8+14*k); if(Game.audio) Game.audio.thud(p.x,p.y-HIP,p.z); }
  /* kahramanca iniş: yalnızca eşik hızın üstünde (çatlak + animasyon); güç çarpma hızından hesaplanır */
  if(Game.heroLand&&Game.heroLand(p.x,p.y-HIP,p.z,imp)>0&&H.flying) H.flying=false; }
function stepMove(p,v,h,smash){
  const ox=p.x, oz=p.z; p.x+=v.x*h; p.y+=v.y*h; p.z+=v.z*h;
  if(!H.flying&&!walkOK(p.x,p.z)){ H.seaBlock=true; if(walkOK(p.x,oz)){ p.z=oz; v.z=0; } else if(walkOK(ox,p.z)){ p.x=ox; v.x=0; } else { p.x=ox; p.z=oz; v.x=v.z=0; } }
  { const b=cand;
    for(let k=0;k<b.length;k+=6){ const fy=p.y-HIP, ty=p.y+HEAD, x0=p.x-RAD, x1=p.x+RAD, z0=p.z-RAD, z1=p.z+RAD;
      if(x1<=b[k]||x0>=b[k+3]||z1<=b[k+2]||z0>=b[k+5]||ty<=b[k+1]||fy>=b[k+4]) continue;
      const up=b[k+4]-fy;
      if(up<=STEP&&v.y<=1.5){ p.y+=up; if(v.y<0){ landed(v.y,false,p); v.y=0; } H.grounded=true; continue; }
      const px=p.x<(b[k]+b[k+3])*.5?b[k]-x1:b[k+3]-x0, pz=p.z<(b[k+2]+b[k+5])*.5?b[k+2]-z1:b[k+5]-z0, dn=ty-b[k+1], ax=Math.abs(px), az=Math.abs(pz);
      if(dn<ax&&dn<az&&dn<up){ p.y-=dn; if(v.y>0) v.y=0; }
      else if(up<ax&&up<az){ p.y+=up; if(v.y<0){ landed(v.y,false,p); v.y=0; } H.grounded=true; }
      else if(ax<az){ p.x+=px; if(px*v.x<0) v.x=0; H.hitWall=true; } else { p.z+=pz; if(pz*v.z<0) v.z=0; H.hitWall=true; } } }
  const fy=p.y-HIP, fl=floorAt(p.x,p.z,fy,v.y), wet=rr.wet;
  if(fy<fl){ p.y=fl+HIP; if(v.y<0){ landed(v.y,wet,p); v.y=0; } H.grounded=true; H.onWater=wet; } else if(fy<fl+.05&&v.y<=0){ H.grounded=true; H.onWater=wet; } }

let prevFly=false, hudT=0, camDist=-1, wakeT=0, stepT=0, zoneT=0;
const ZN=[["z_luna",W.islands[0]],["z_tropic",W.islands[1]],["z_ancient",W.islands[2]],["z_dragon",W.islands[3]]];
function zoneKey(p){ const y=p.y;
  if(y>4000) return "z_space"; if(y>1500) return "z_sky";
  for(const [k,I] of ZN) if(Math.hypot(p.x-I.x,p.z-I.z)<I.R+30) return k;
  const bi=W.bridge&&W.bridge.info; if(bi&&p.x>bi.X0-6&&p.x<bi.X1+6&&Math.abs(p.z-bi.ZC)<30) return "z_bridge";
  if(W.distCity(p.x,p.z)<18){ const dd=Game.Districts&&Game.Districts.at(p.x,p.z); return dd?"dk:"+dd.key+(dd.name?"|"+dd.name:""):"z_city"; } return "z_sea"; }
const zoneText=zk=>{ if(zk.slice(0,3)!=="dk:") return t(zk); const q=zk.slice(3).split("|"); return t(q[0])+(q[1]?" · "+q[1]:""); };
const fmtAlt=y=>y>=1000?(y/1000).toFixed(y>=10000?1:2)+" km":Math.round(y)+" m";

/* ---- yüksek hızda bina kırma: süpürülen küre içindeki parçalar öne/yanlara savrulur; hız hafifçe düşer ---- */
const SMASH_ON=78, SMASH_OFF=66;                      // m/s  (≈252 / 216 km/s)
let smashToastN=0, smashSndT=0;
const smashCone=(()=>{ const c=document.createElement("canvas"); c.width=4; c.height=64; const q=c.getContext("2d"), g=q.createLinearGradient(0,0,0,64); g.addColorStop(0,"rgba(255,255,255,1)"); g.addColorStop(.35,"rgba(190,225,255,.55)"); g.addColorStop(1,"rgba(120,180,255,0)"); q.fillStyle=g; q.fillRect(0,0,4,64);
  const tx=new THREE.CanvasTexture(c), m=new THREE.Mesh(new THREE.CylinderGeometry(.02,2.3,8,18,1,true),new THREE.MeshBasicMaterial({map:tx,transparent:true,opacity:0,blending:THREE.AdditiveBlending,depthWrite:false,side:THREE.DoubleSide,fog:false}));
  m.visible=false; m.frustumCulled=false; scene.add(m); return m; })();
const smashQ=new THREE.Quaternion(), smashV=new THREE.Vector3(), smashUp=new THREE.Vector3(0,1,0); let smashOp=0;
function smashStart(p,v){ if(smashToastN<2){ smashToastN++; Game.toast("t_smash",2200); }
  FX.shock(p.x,p.y,p.z,26,18); H.shake=Math.max(H.shake,.55); if(Game.audio){ Game.audio.whoosh(); Game.audio.smash(.5); } }
function smashFx(p,v,speed,dt,time){ const want=H.smash?.55:0; smashOp+=(want-smashOp)*(1-Math.exp(-7*dt)); const on=smashOp>.02&&!Game.settings.cam.startsWith("1p");
  smashCone.visible=on; if(on){ smashV.copy(v).multiplyScalar(1/Math.max(speed,1)); smashQ.setFromUnitVectors(smashUp,smashV); smashCone.quaternion.copy(smashQ); const fl=1+.1*Math.sin(time*50)+.06*Math.sin(time*31);
    smashCone.position.set(p.x+smashV.x*(1.9-4),p.y+smashV.y*(1.9-4)+.1,p.z+smashV.z*(1.9-4)); smashCone.scale.set(fl,1,fl); smashCone.material.opacity=smashOp; }
  const hudEl=$("hud"); if(hudEl){ const f=H.flying&&speed>38; if(hudEl.classList.contains("smash")!==H.smash) hudEl.classList.toggle("smash",H.smash); if(hudEl.classList.contains("fast")!==f) hudEl.classList.toggle("fast",f); } }
/* Süpürülen küre: çekirdek bölgedeki parçalar kırılır, kenara değenler çatlar (hasar). Enerji bütçesi (hız², dt) kadar hacim yıkılır; bina yüksekliğine göre direnç; hız buna göre düşer. */
const SC=[];
function smashCarve(p,v,speed,dist,dt){
  const dx=v.x/speed, dy=v.y/speed, dz=v.z/speed, R=Math.max(2.5,Math.min(4.6,1.9+dist*.7+(speed-60)*.01));
  const cx=p.x+dx*1.6, cy=p.y+.2+dy*1.6, cz=p.z+dz*1.6, R2=R*R, D=Game.D; let vol=0, n=0, budget=10; SC.length=0;
  for(const e of Game.buildings){ const t=e.tier; if(!t||e.h<=0) continue;
    if(cx<e.x-e.hw-R||cx>e.x+e.hw+R||cz<e.z-e.hd-R||cz>e.z+e.hd+R||cy>e.h+R||cy<(e.y0||0)-R) continue;
    const tk=e.h>60?1.7:e.h>25?1.25:.8;
    for(const c of t.chunks){ if(!c.alive) continue; const b=c.bx; let bd=1e9;
      for(let k=0;k<b.length;k+=6){ const qx=Math.max(b[k]-cx,0,cx-b[k+3]), qy=Math.max(b[k+1]-cy,0,cy-b[k+4]), qz=Math.max(b[k+2]-cz,0,cz-b[k+5]), d2=qx*qx+qy*qy+qz*qz; if(d2<bd) bd=d2; }
      if(bd<=R2) SC.push({c,d:Math.sqrt(bd),tk}); } }
  if(!SC.length) return; SC.sort((a,b)=>a.d-b.d);
  let energy=speed*speed*dt*2.6;
  for(const h of SC){ const c=h.c; if(!c.alive) continue; const cv=c.kind===1?26:Math.max(8,c.sx*c.sy*c.sz)*h.tk;
    let rx=c.x-p.x, ry=c.y-p.y, rz=c.z-p.z; const al=rx*dx+ry*dy+rz*dz; rx-=al*dx; ry-=al*dy; rz-=al*dz; const rl=Math.hypot(rx,ry,rz)||1; rx/=rl; ry/=rl; rz/=rl;
    const k1=.4+Math.random()*.4, out=4+Math.random()*8;
    if(h.d<R*.55&&energy>=cv){ energy-=cv; D.kill(c,v.x*k1+rx*out,v.y*k1+ry*out+3,v.z*k1+rz*out,budget--<=0); n++; vol+=cv; }
    else if(energy>0){ const part=Math.min(.5,energy/cv*.5); energy-=cv*.25; if(D.dmg(c,part,v.x*.3,v.y*.3+2,v.z*.3)){ n++; vol+=cv; } } }
  if(n){ const loss=Math.min(.24,vol*.00042); v.multiplyScalar(1-loss);
    H.shake=Math.max(H.shake,Math.min(.8,.2+vol*.0011));
    smashSndT-=dt; if(Game.audio&&smashSndT<=0){ smashSndT=.12; Game.audio.smash(Math.min(1.3,.3+vol*.004)); }
    FX.spark(cx,cy,cz,Math.min(12,3+n),12,[1,.8,.5]); if(Math.random()<.5) FX.cloud(cx,cy,cz,2,R*.8,2.2); } }

Game.updaters.push((dt0,time,raw)=>{
  hero.visible = Game.mode==="play";
  if(Game.mode!=="play") return;
  const MV=Game.Mounted&&Game.Mounted();
  if(MV){ hero.visible=false; H.flying=false; H.smash=false; H.vel.set(0,0,0); H.speed=MV.speed; H.hv=H.speed; H.boost=false; smashCone.visible=false; smashOp=0; prevFly=true;
    hudT-=raw||dt0; if(hudT<=0){ hudT=.25; const zk=zoneKey(hero.position), zel=$("zone"); if(zel&&zel.dataset.k!==zk){ zel.dataset.k=zk; zel.textContent=zoneText(zk); zel.classList.remove("pop"); void zel.offsetWidth; zel.classList.add("pop"); } }
    if(toastT>0){ toastT-=raw||dt0; if(toastT<=0){ const el=$("toast"); if(el) el.classList.remove("on"); } }
    return; }
  const dt=raw||dt0, A = Game.input.actions, p=hero.position, v=H.vel;
  const LOCK=Game.heroLock>0; if(!LOCK&&(A.fly||keys[" "]) && !prevFly && !(H.landLock>.28)){ H.flying = !H.flying; if(H.flying){ v.y = Math.max(v.y,9); H.grounded=false; if(Game.audio) Game.audio.whoosh(); } } prevFly = A.fly||!!keys[" "];
  if(!H.flying&&H.onWater&&!walkOK(p.x,p.z)){ H.flying=true; v.y=Math.max(v.y,4); Game.toast("t_nowalk"); }
  H.pitch=Math.min(H.pitch,pmax());
  lookV.set(-Math.sin(H.yaw)*Math.cos(H.pitch), Math.sin(H.pitch), -Math.cos(H.yaw)*Math.cos(H.pitch));
  fwd.set(-Math.sin(H.yaw),0,-Math.cos(H.yaw)); rgt.set(Math.cos(H.yaw),0,-Math.sin(H.yaw));
  let jx=LOCK?0:joy.x, jy=LOCK?0:joy.y; if(!LOCK){ if(keys.w) jy=-1; if(keys.s) jy=1; if(keys.a) jx=-1; if(keys.d) jx=1; } if(H.landLock>0&&!H.flying){ jx=0; jy=0; }
  const mag=Math.min(1,Math.hypot(jx,jy)), boost=H.flying&&mag>.85; if(boost&&!H.boost&&Game.audio) Game.audio.boom(p.x,p.y,p.z,true); H.boost=boost; H.mv=mag;
  dir.set(0,0,0); if(mag>.08){ dir.addScaledVector(H.flying?lookV:fwd,-jy).addScaledVector(rgt,jx); if(dir.lengthSq()>0) dir.normalize(); }
  const alt=Math.max(0,p.y); H.alt=alt; H.sp=H.spaceT(alt); const am=1+3*sm01(alt/3000)+4*sm01((alt-4000)/8000); H.speedMul=am;
  const gs=H.gscale, base=(H.flying?(boost?150:48)*am:(Game.sprint?24:16))*(H.carryK||1), sp=base*(boost?1:mag), k=1-Math.exp(-(H.flying?3:10)*dt);
  v.x+=(dir.x*sp-v.x)*k; v.z+=(dir.z*sp-v.z)*k;
  if(H.flying) v.y+=(dir.y*sp-v.y)*k; else v.y=Math.max(v.y-45*gs*dt,-150);
  const speed=v.length(); H.speed=speed; H.hv=Math.hypot(v.x,v.z);
  /* yüksek hız: yeterince hızlı uçarken binalar kırılarak geçilir (hayalet yok, gerçek yıkım); yavaşlayınca içerideysen kırmaya devam eder */
  if((H.flying||speed>100)&&speed>=SMASH_ON){ if(!H.smash){ H.smash=true; smashStart(p,v); } }
  else if(H.smash&&(speed<SMASH_OFF||(!H.flying&&speed<80))&&!overlapAny(p)) H.smash=false;
  H.seaBlock=false; H.grounded=false; H.hitWall=false; H.onWater=false;
  const dist=speed*dt, n=Math.max(1,Math.min(14,Math.ceil(dist/.35))), h=dt/n;
  gather(p.x-RAD-dist-1,p.y-HIP-dist-1,p.z-RAD-dist-1,p.x+RAD+dist+1,p.y+HEAD+dist+1,p.z+RAD+dist+1,H.smash);
  for(let i=0;i<n;i++) stepMove(p,v,h,H.smash);
  if(H.smash) smashCarve(p,v,speed,dist,dt);
  if(H.seaBlock&&!H.flying) Game.toast("t_sea");
  /* denize dokunma: su yüzeyinde asılı kalır, dalga/sıçrama efekti */
  const fyNow=p.y-HIP, overSea=W.terrainH(p.x,p.z)<W.WATER_Y&&deckAt(p.x,p.z)===null;
  if(overSea&&fyNow<=W.WATER_Y+.9){ wakeT-=dt; if(H.flying&&fyNow<=W.WATER_Y+.15){ Game.toast("t_sea"); if(v.y<0) v.y=0; }
    if(wakeT<=0&&(H.hv>3||fyNow<=W.WATER_Y+.2)){ wakeT=.1+.4/(1+H.hv*.06); Game.splash(p.x+v.x*.05,p.z+v.z*.05,.45+Math.min(2.2,H.hv*.025)); } }
  else if(!H.flying&&H.grounded&&p.y-HIP<W.WATER_Y+.5&&H.hv>2){ stepT-=dt; if(stepT<=0){ stepT=.32; Game.splash(p.x,p.z,.3); } }
  p.x=Math.max(-12000,Math.min(12000,p.x)); p.z=Math.max(-12000,Math.min(12000,p.z)); if(p.y>90000){ p.y=90000; if(v.y>0) v.y=0; }
  if(H.hv>1.5) H.face=Math.atan2(v.x,v.z);
  if(Game.aimFace!==undefined&&Game.aimFace!==null) H.face=Game.aimFace;     // güç kullanırken bakış yönüne dön
  let d=H.face-hero.rotation.y; d=Math.atan2(Math.sin(d),Math.cos(d)); hero.rotation.y+=d*(1-Math.exp(-10*dt)); H.turn+=((d*3)-H.turn)*(1-Math.exp(-8*dt));
  Game.heroFwd.set(Math.sin(hero.rotation.y),0,Math.cos(hero.rotation.y));
  /* uçuşta gövde hız yönüne yatar: yatay uçuş = yüzüstü, tırmanış = dik */
  let tilt=0; if(H.flying){ const ph=Math.atan2(v.y,H.hv+1e-3), f=Math.min(1,speed/38); tilt=Math.min(2.7,.18+(Math.PI/2-ph-.18)*f); if(speed<4) tilt=.12; }
  hero.rotation.x+=(tilt-hero.rotation.x)*(1-Math.exp(-6*dt)); H.landT*=Math.exp(-5*dt);
  // uçuş efektleri
  if(H.flying){ const bk=Game.heroFwd, fy=p.y-1.1;
    FX.E(true,p.x-bk.x*.8,fy,p.z-bk.z*.8,-v.x*.15+U.rs(),-v.y*.1-1.5,-v.z*.15+U.rs(),.4,.5,.1,[1,.8,.4],[1,.25,.05],.7,0,.96);
    if(speed>60&&Math.random()<.9) FX.E(true,p.x+U.rs()*14+v.x*.1,p.y+U.rs()*8,p.z+U.rs()*14+v.z*.1,0,0,0,.35,.25,.25,[.9,.95,1],[.9,.95,1],.35,0,1);
    if(H.smash){ for(let q2=0;q2<2;q2++) FX.E(true,p.x+U.rs()*3,p.y+U.rs()*2.2,p.z+U.rs()*3,-v.x*.1,-v.y*.1,-v.z*.1,.38,.35,.08,[.9,.96,1],[.55,.78,1],.5,0,1); } }
  /* kamera: ivme gecikmesi sınırlı (hız arttıkça sınırlı mesafede kalır → uzayda sıçrama/atlama yok), mesafe ve FOV yumuşak */
  const sh=H.shake*Game.settings.shake; H.shake*=Math.exp(-6*dt); if(H.smash) H.shake=Math.max(H.shake,.1);
  const spk=H.flying?Math.min(1,speed/150):0, want=(H.flying?(boost?17:12):8.5)*(1+1.25*H.sp)+spk*3+(H.camAdd||0);
  camT.set(p.x,p.y+2.2,p.z);
  const fp=Game.settings.cam==="1p"; if(fp!==lastFp){ lastFp=fp; piv.copy(camT); camDist=-1; fpY=null; fpRoll=0; }
  if(fp){ /* göz görüşü: kamera kahramanın gözünde -- yumuşatılmış göz yüksekliği, adım sallanması, iniş çökmesi, dönüşte yatma, nefes */
    const FPK=Game.settings.shake>0?1:0, hv=H.hv, g=H.grounded&&!H.flying, run=Math.min(1,hv/(Game.sprint?20:11));
    fpT+=dt; if(g) fpPh+=dt*(2.4+hv*.42)*(hv>.8?1:0); else fpPh+=0;
    const ampB=g?Math.min(1,hv/6)*(.028+.05*run)*FPK:0, bobY=-Math.abs(Math.sin(fpPh))*ampB*1.5+Math.sin(fpT*1.55)*.007*(1-Math.min(1,hv/3))*FPK, bobX=Math.cos(fpPh)*ampB*.7, bobR=Math.cos(fpPh)*ampB*.1, bobP=Math.sin(fpPh*2)*ampB*.05;
    const dip=H.landT*.32*FPK;                                  // inişte kamera çöker
    const tgtY=p.y+(H.flying?.1:1.22);
    if(fpY===null||!isFinite(fpY)||H.flying||!g||Math.abs(tgtY-fpY)>1.2) fpY=tgtY; else fpY+=(tgtY-fpY)*(1-Math.exp(-16*dt));   // basamak/yokuş sarsıntısını yumuşat
    const lead=H.flying?1.25:.25, ex=p.x+(H.flying?lookV.x*lead:fwd.x*lead)+rgt.x*bobX, ez=p.z+(H.flying?lookV.z*lead:fwd.z*lead)+rgt.z*bobX, ey=(H.flying?p.y+.1+lookV.y*lead:fpY)+bobY-dip;
    const rollT=Math.max(-.16,Math.min(.16,H.flying?-H.turn*.045:-H.turn*.008))*FPK, strafe=g?(joy.x||0)*-.012*FPK:0;
    fpRoll+=((rollT+bobR+strafe)-fpRoll)*(1-Math.exp(-9*dt));
    camera.position.set(ex,ey,ez); if(sh>.01){ camera.position.x+=U.rs()*sh; camera.position.y+=U.rs()*sh; camera.position.z+=U.rs()*sh; }
    const hf=H.flying?Math.min(1,speed/120):0;                 // hızlı uçuşta hafif titreşim (rüzgâr)
    if(hf>.35&&FPK){ const w=(hf-.35)*.012; camera.position.x+=U.rs()*w; camera.position.y+=U.rs()*w; camera.position.z+=U.rs()*w; }
    camera.lookAt(ex+lookV.x*10,ey+lookV.y*10+bobP*10,ez+lookV.z*10); if(camera.rotateZ) camera.rotateZ(fpRoll); H.fpRoll=fpRoll;
    hero.visible=false; }
  else {
    const rate=H.flying?(boost?8:11):30, maxLag=H.flying?(2.4+Math.min(15,speed*.04)):.7;
    piv.lerp(camT,1-Math.exp(-rate*dt));
    { const lx=piv.x-camT.x, ly=piv.y-camT.y, lz=piv.z-camT.z, l2=lx*lx+ly*ly+lz*lz; if(l2>maxLag*maxLag){ const k=maxLag/Math.sqrt(l2); piv.set(camT.x+lx*k,camT.y+ly*k,camT.z+lz*k); } }
    if(camDist<0) camDist=want; else { const dd=(want-camDist)*(1-Math.exp(-3.2*dt)); camDist+=Math.max(-dt*28,Math.min(dt*30,dd)); }
    tmp.copy(piv).addScaledVector(lookV,-camDist);
    { const bx=tmp.x-camT.x, by=tmp.y-camT.y, bz=tmp.z-camT.z, L=Math.hypot(bx,by,bz)||1; Game.D.rayB(camT.x,camT.y,camT.z,bx/L,by/L,bz/L,L,rr);
      if(rr.kind!=="none"&&rr.t<L){ const L2=Math.max(1.1,rr.t-.45); tmp.set(camT.x+bx/L*L2,camT.y+by/L*L2,camT.z+bz/L*L2); camDist=Math.max(1.1,Math.min(camDist,L2*.999)); } }
    const cf=floorAt(tmp.x,tmp.z,tmp.y,0); if(tmp.y<cf+1) tmp.y=cf+1;
    camera.position.copy(tmp); if(sh>.01){ camera.position.x+=U.rs()*sh; camera.position.y+=U.rs()*sh; camera.position.z+=U.rs()*sh; } camera.lookAt(camT);
    const dC=camera.position.distanceTo(camT); hero.visible = dC>1.5;
  }
  { const fovT=Game.settings.fovAdd+(fp?68+(H.flying?0:(Game.sprint&&H.hv>10?5:0)):70)+(H.flying?Math.min(fp?18:20,Math.max(0,speed-30)*(fp?.19:.2)):0)+(boost?4:0)+(H.smash?(fp?2:3):0); camera.fov+=(fovT-camera.fov)*(1-Math.exp(-4*dt)); }
  { const nn=.1+3.9*H.sp, ff=6000+394000*H.sp; camera.near+=(nn-camera.near)*(1-Math.exp(-8*dt)); camera.far=ff; }
  camera.updateProjectionMatrix();
  { const hd=$("hud"); if(hd){ if(hd.classList.contains("fp")!==fp) hd.classList.toggle("fp",fp); } }
  smashFx(p,v,speed,dt,time);
  /* HUD */
  if(toastT>0){ toastT-=dt; if(toastT<=0){ const el=$("toast"); if(el) el.classList.remove("on"); } }
  hudT-=dt; if(hudT<=0){ hudT=.25; $("alt").textContent="⬆ "+fmtAlt(alt)+" · "+Math.round(speed*3.6)+" km/h";
    zoneT-=.25; const zk=zoneKey(p), zel=$("zone"); if(zel&&zel.dataset.k!==zk){ zel.dataset.k=zk; zel.textContent=zoneText(zk); zel.classList.remove("pop"); void zel.offsetWidth; zel.classList.add("pop"); } }
});
Game.onZoneLang=()=>{ const z=$("zone"); if(z&&z.dataset.k) z.textContent=zoneText(z.dataset.k); };
