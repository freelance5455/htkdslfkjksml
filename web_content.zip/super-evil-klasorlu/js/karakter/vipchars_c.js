"use strict";
/* ===== MYTHIC KARAKTERLER: KRONOS (zaman efendisi), NEKRO (ruh çağıran, mor ateş saçlı), KOZMOS (galaksi bedenli) =====
   Mor arka planlı "MYTHIC" kademesi. Her biri kendi gücüyle gelir (Game.SKIN_POWER): chrono / reap / planet. */
Game.SUPER_IDS=["kronos","nekro","kozmos"];
Game.SKIN_POWER={kronos:"chrono",nekro:"reap",kozmos:"planet"};
(function(){
const K=Game.VIPKit, PI=Math.PI, TAU=PI*2, clamp=K.clamp, fan=K.fan, AD=THREE.AdditiveBlending;
const keep=m=>{ m.userData=m.userData||{}; m.userData.keepEm=true; return m; };
const basic=(o,mats)=>{ const m=new THREE.MeshBasicMaterial(Object.assign({side:THREE.DoubleSide,fog:false},o)); mats.push(m); return m; };
const flameMat=mats=>basic({vertexColors:true,transparent:true,blending:AD,depthWrite:false},mats);
const capeMat=(kind,post)=>ctx=>{ const tex=K.capeTexture(kind,ctx.pal.cape); if(post){ try{ post(tex,ctx); }catch(e){} }
  const m=new THREE.MeshBasicMaterial({map:tex,alphaTest:.5,side:THREE.DoubleSide,fog:kind!=="flame"}); ctx.mats.push(m); return keep(m); };
/* galaksi dokusu: koyu zemin + nebula lekeleri + yıldızlar (kaplanabilir) */
function paintGalaxy(q,W,H,p,rnd,clip){
  q.save(); if(clip) q.globalCompositeOperation="source-atop";
  const g=q.createLinearGradient(0,0,W,H); g.addColorStop(0,p.a||"#0a0426"); g.addColorStop(.5,p.b||"#2a0f6a"); g.addColorStop(1,p.a||"#0a0426"); q.fillStyle=g; q.fillRect(0,0,W,H);
  q.globalCompositeOperation=clip?"source-atop":"lighter";
  const neb=p.neb||["rgba(255,90,210,.32)","rgba(110,90,255,.34)","rgba(60,200,255,.24)"];
  for(let i=0;i<14;i++){ const x=rnd()*W, y=rnd()*H, r=W*(.12+rnd()*.24), col=neb[(rnd()*neb.length)|0];
    for(const ox of [-W,0,W]) for(const oy of [-H,0,H]){ const cx=x+ox, cy=y+oy; if(cx+r<0||cx-r>W||cy+r<0||cy-r>H) continue; const rg=q.createRadialGradient(cx,cy,0,cx,cy,r); rg.addColorStop(0,col); rg.addColorStop(1,"rgba(0,0,0,0)"); q.fillStyle=rg; q.fillRect(cx-r,cy-r,r*2,r*2); } }
  for(let i=0;i<170;i++){ const x=rnd()*W, y=rnd()*H, r=.5+Math.pow(rnd(),3)*1.9, a=.4+rnd()*.6; q.fillStyle=rnd()<.25?"rgba(170,230,255,"+a+")":rnd()<.4?"rgba(255,190,240,"+a+")":"rgba(255,255,255,"+a+")"; q.beginPath(); q.arc(x,y,r,0,TAU); q.fill();
    if(r>1.7){ q.strokeStyle="rgba(255,255,255,.55)"; q.lineWidth=.7; q.beginPath(); q.moveTo(x-r*3,y); q.lineTo(x+r*3,y); q.moveTo(x,y-r*3); q.lineTo(x,y+r*3); q.stroke(); } }
  q.restore(); }
function galaxyTex(p){ const c=K.cnv(256,256), q=c.getContext("2d"); paintGalaxy(q,256,256,p||{},K.rngS((p&&p.seed)||5),false); const t=new THREE.CanvasTexture(c); t.wrapS=t.wrapT=THREE.RepeatWrapping; return t; }
const hairMat=(M,emi,em)=>{ const m=M("#ffffff",{roughness:.3,metalness:.2,side:THREE.DoubleSide,emissive:emi,emissiveIntensity:em==null?.35:em}); m.vertexColors=true; return keep(m); };
const sashes=(cols,seed)=>{ const a=[]; for(const s of [-1,1]) for(let i=0;i<2;i++) a.push({r:[s*(.22+i*.07),-.02,.12-i*.3],d:[s*.5,-1,0],L:.5+i*.16,n:8,w0:.13,w1:.1,wave:.3,wph:i*2+s+(seed||0),stiff:.045,cols}); return a; };

/* ================= KRONOS ================= */
Game.VIPB.kronos={
  mats(c){ const {M,pri,sec,trim,pal}=c;
    return {pri:M(pri,{roughness:.32,metalness:.5}),sec:M(sec,{roughness:.5,metalness:.3,side:THREE.DoubleSide}),trim:keep(M(trim,{roughness:.2,metalness:1,emissive:pal.trimE||0x7a5a10,emissiveIntensity:.45})),skin:M("#ead7f6",{roughness:.55}),dark:M("#1a0f2a",{roughness:.7}),white:M("#ffffff",{roughness:.7}),
      arm:M(pri,{roughness:.45,metalness:.3}),leg:M(sec,{roughness:.5}),tor:M(pri,{roughness:.32,metalness:.5}),hand:M(trim,{roughness:.3,metalness:.8}),boot:M(sec,{roughness:.35,metalness:.6})}; },
  build(c){ const {R,add,cl,CO,SP,CY,TO,B,grp,M,mats,fc,pal,mPri,mSec,mTrim,mGlow,g,laserHex}=c;
    const gold=basic({color:pal.gold!=null?pal.gold:0xffd36a},mats);
    /* saat halesi (kafanın arkasında, kamera görür) */
    const clk=grp(R.head,0,.16,-.46); clk.rotation.x=-.05;
    add(clk,TO(.5,.022,8,48),gold,0,0,0); add(clk,TO(.41,.008,6,40),gold,0,0,0);
    const disc=new THREE.Mesh(new THREE.CircleGeometry(.5,36),basic({color:pal.disc||0x8a4cff,transparent:true,opacity:.24,blending:AD,depthWrite:false},mats)); disc.position.z=-.004; clk.add(disc);
    for(let i=0;i<12;i++){ const a=i/12*TAU, big=i%3===0; add(clk,B(big?.026:.014,big?.085:.05,.01),gold,Math.sin(a)*.45,Math.cos(a)*.45,0,0,0,-a); }
    const hHr=grp(clk,0,0,.012), hMn=grp(clk,0,0,.02); add(hHr,B(.024,.26,.01),gold,0,.12,0); add(hMn,B(.015,.38,.01),gold,0,.18,0); add(clk,SP(.03,8,6),gold,0,0,.024);
    hHr.rotation.z=-.9; hMn.rotation.z=-3.1;
    const clkG=K.glowSprite(clk,pal.glow||0xffc94a,1.55,0,0,-.03,.32);
    /* cüppe + kuşak */
    const robeM=M(c.sec,{roughness:.7,metalness:.05,side:THREE.DoubleSide}); add(R.root,CY(.27,.46,.7,20),robeM,0,-.34,0,0,0,0,1,1,.85);
    add(R.root,TO(.45,.02,6,30),mTrim,0,-.67,0,PI/2); add(R.root,TO(.35,.012,6,28),mTrim,0,-.52,0,PI/2); cl(R.root,mTrim,0,.05,0,.62,.08,.37);
    /* göğüs zırhı + kum saati */
    cl(R.chest,mPri,0,.12,.215,.66,.4,.04); cl(R.chest,mTrim,0,.3,.236,.62,.035,.015); cl(R.chest,mTrim,0,-.05,.236,.5,.03,.015);
    const hg=grp(R.chest,0,.19,.25); add(hg,CO(.06,.1,8),mTrim,0,.05,0,0,0,PI); add(hg,CO(.06,.1,8),mTrim,0,-.05,0); add(hg,CY(.072,.072,.016,10),mTrim,0,.105,0); add(hg,CY(.072,.072,.016,10),mTrim,0,-.105,0); add(hg,SP(.028,8,6),mGlow,0,-.06,.012);
    const hgG=K.glowSprite(R.chest,laserHex,.5,0,.19,.29,.5);
    for(const s of [-1,1]){ const el=s<0?R.elL:R.elR, kn=s<0?R.knL:R.knR;
      add(R.chest,SP(.18,12,8),mTrim,s*.46,.37,0,0,0,0,1,.78,1.1); add(R.chest,SP(.125,10,8),mPri,s*.48,.44,0,0,0,0,1,.7,1);
      add(R.chest,CO(.045,.3,5),mTrim,s*.56,.58,-.02,0,0,s*-.55); add(R.chest,CO(.035,.22,5),mTrim,s*.62,.5,.05,0,0,s*-1.1);
      add(el,CY(.087,.07,.23,10),mTrim,0,-.15,0); add(el,TO(.084,.012,6,12),mPri,0,-.06,0,PI/2); add(el,TO(.07,.012,6,12),mPri,0,-.25,0,PI/2);
      add(kn,CY(.09,.074,.13,10),mTrim,0,-.34,0); add(kn,CO(.045,.15,5),mTrim,0,-.02,.1,PI/2); cl(s<0?R.ftL:R.ftR,mTrim,0,-.04,.2,.12,.03,.1); }
    /* gümüş uzun saç + bukleler */
    const hc=pal.hair||[[1,.97,.85],[.78,.6,1]], mh=hairMat(M,pal.hairE||0x3a1a6a,.35);
    const hs=fan({count:24,az0:1.9,az1:TAU-1.9,el0:-.05,el1:.95,L0:.55,L1:1.05,n:11,w0:.12,w1:.035,droop:.5,wave:.4,out:.3,down:1,dz:-.35,stiff:.045,seed:9,cols:hc}), bang=fan({count:7,az0:-.6,az1:.6,el0:.85,el1:1.1,L0:.2,L1:.34,n:5,w0:.09,w1:.03,droop:1.4,dz:.45,out:.5,stiff:.05,seed:3,cols:hc});
    const hair=K.makeHair(R.head,{mat:mh,grav:.5,drag:.93,wind:.7,stiff:.04,tip:1.1,wp:.8,colliders:[["head",0,.1,0,.205,.22,.205],["chest",0,0,-.05,.46,.5,.28]],strands:hs.concat(bang)},R);
    const ribM=M("#ffffff",{roughness:.4,metalness:.3,side:THREE.DoubleSide,emissive:0x5a3c00,emissiveIntensity:.2}); ribM.vertexColors=true;
    const sashH=K.makeHair(R.root,{mat:ribM,grav:.8,drag:.93,wind:.6,stiff:.04,colliders:[["root",0,-.02,0,.32,.12,.2],["hpL",0,-.21,0,.12,.25,.12],["hpR",0,-.21,0,.12,.25,.12]],strands:sashes([[1,.84,.4],[.7,.5,1]])},R);
    /* kum zerrecikleri (kum saatinden dökülen) */
    const ac=pal.aura||[0xffe08a,0xc9a0ff,0xffffff];
    const em=[{ob:R.chest,x:.5,y:.7,z:-.25,r:.3},{ob:R.chest,x:-.5,y:.7,z:-.25,r:.3},{ob:R.head,x:0,y:.4,z:-.3,r:.3},{ob:R.chest,x:0,y:.2,z:0,r:.5},{ob:R.hdL,x:0,y:-.05,z:0,r:.06},{ob:R.hdR,x:0,y:-.05,z:0,r:.06}];
    const sand=K.makeAura(g,{n:46,color:ac,vel:[0,-.35,0],jit:.35,up:0,life:[1.4,2.8],size:[.07,.02],rate:20,grav:-.1,drag:.985,swirl:.5,op:.95,emit:em,flick:true});
    const eg=[]; for(const s of [-1,1]){ const sp=K.glowSprite(R.head,pal.eye!=null?pal.eye:0xffe9a8,.32,s*.075,.12,.235,.85); eg.push({sp,op:.85,s:.32,ph:s}); }
    return Game.VIPRun(c,{hairs:[hair,sashH],auras:[{o:sand}],eyeGlow:eg,auraK:st=>.8+st.f*.9+(st.act?1.3:0),
      tick(st,dt,time){ const sp=st.act?7:(st.fly?2.4:1); hMn.rotation.z-=dt*sp*1.3; hHr.rotation.z-=dt*sp*.11; clkG.material.opacity=.28+.1*Math.sin(time*2)+(st.act?.25:0); hg.rotation.y=Math.sin(time*.9)*.25; hgG.material.opacity=.42+.14*Math.sin(time*3.2)+(st.act?.3:0); } }); } };

/* ================= NEKRO ================= */
Game.VIPB.nekro={
  mats(c){ const {M,pri,sec,trim,pal}=c, robe=M(pri,{roughness:.85,metalness:0,side:THREE.DoubleSide}), bone=M(pal.bone||"#ddd2ea",{roughness:.55,metalness:.05});
    return {pri:robe,sec:M(sec,{roughness:.8,side:THREE.DoubleSide}),trim:keep(M(trim,{roughness:.3,metalness:.6,emissive:pal.trimE||0x4a1a8a,emissiveIntensity:.5})),skin:bone,dark:M("#0a0412",{roughness:.8}),white:bone,arm:robe,leg:robe,tor:robe,hand:bone,boot:robe,_bone:bone}; },
  build(c){ const {R,add,cl,CO,SP,CY,TO,B,grp,M,mats,fc,pal,mPri,mSec,mTrim,mGlow,mDark,g,laserHex,vm}=c; const bone=vm._bone, ink=basic({color:0x05010c},mats);
    /* kukuleta + boynuzlar + kafatası yüzü */
    const hood=new THREE.Mesh(new THREE.SphereGeometry(.25,22,14,PI/2+1.15,TAU-2.3),mPri); hood.position.set(0,.13,-.04); hood.scale.set(1,1.03,1.06); R.head.add(hood);
    add(R.head,CO(.14,.44,10),mPri,0,.34,-.2,-.95);
    for(const s of [-1,1]){ add(R.head,CO(.045,.36,6),bone,s*.15,.3,-.04,-.3,0,s*-.55); add(R.head,CO(.03,.22,5),bone,s*.23,.2,-.06,-.5,0,s*-1.0); }
    fc.brL.visible=fc.brR.visible=fc.nose.visible=false; fc.mouth.visible=false;
    fc.eyeL.scale.set(1.25,1.15,1); fc.eyeR.scale.set(1.25,1.15,1);
    cl(R.head,mDark,0,.0,.193,.13,.022,.01); for(let i=0;i<6;i++) cl(R.head,bone,(i-2.5)*.022,.0,.199,.012,.03,.01); add(R.head,CO(.022,.05,3),ink,0,.065,.2,PI/2);
    const eg=[]; for(const s of [-1,1]){ const sp=K.glowSprite(R.head,pal.eye!=null?pal.eye:0xd98cff,.42,s*.075,.12,.235,.9); eg.push({sp,op:.9,s:.42,ph:s}); }
    /* kaburga kafesi + ruh çekirdeği */
    cl(R.chest,mDark,0,.14,.215,.6,.4,.03); cl(R.chest,bone,0,.14,.228,.05,.4,.025);
    for(let i=0;i<4;i++) for(const s of [-1,1]) cl(R.chest,bone,s*.16,.3-i*.08,.226,.28,.026,.028,0,0,s*-.2);
    add(R.chest,SP(.065,10,8),mGlow,0,.17,.215); const core=K.glowSprite(R.chest,laserHex,.55,0,.17,.3,.8);
    /* omuz kafatasları + dikenler, tören kuşağı */
    for(const s of [-1,1]){ const el=s<0?R.elL:R.elR, kn=s<0?R.knL:R.knR;
      add(R.chest,SP(.2,12,8),mPri,s*.46,.36,0,0,0,0,1,.8,1.1); add(R.chest,SP(.095,10,8),bone,s*.5,.52,.05,0,0,0,1,1.05,1); add(R.chest,SP(.024,6,6),ink,s*.5-.034,.54,.135); add(R.chest,SP(.024,6,6),ink,s*.5+.034,.54,.135);
      add(R.chest,CO(.04,.32,5),bone,s*.6,.62,-.02,0,0,s*-.7); add(R.chest,CO(.03,.22,5),bone,s*.64,.46,.07,0,0,s*-1.2); add(R.chest,CO(.03,.22,5),bone,s*.4,.58,-.14,-.4,0,s*-.3);
      add(el,CY(.088,.074,.22,10),mPri,0,-.15,0); add(el,TO(.085,.013,6,12),mTrim,0,-.06,0,PI/2); add(el,CO(.03,.18,4),bone,0,-.04,-.1,-PI/2);
      add(kn,CY(.09,.076,.12,10),mPri,0,-.34,0); add(kn,CO(.04,.14,5),bone,0,-.02,.1,PI/2); }
    add(R.root,CY(.27,.5,.74,18,1,true),mPri,0,-.36,0,0,0,0,1,1,.85); cl(R.root,mTrim,0,.05,0,.62,.07,.37); add(R.root,SP(.07,8,6),bone,0,.04,.2,0,0,0,1,1.1,.8);
    /* MOR ATEŞ SAÇ + kalça alevleri */
    const flame=flameMat(mats), hc=pal.hair||[[.96,.82,1],[.66,.22,1]], tipC=pal.tip||[.2,0,.45];
    const hs=fan({count:22,az0:0,az1:TAU-.2,el0:.3,el1:1.25,L0:.34,L1:.86,n:8,w0:.1,w1:.01,droop:-.2,wave:.5,up:.9,out:.75,stiff:.07,seed:21,cols:[hc[0],tipC]}); for(const s of hs) s.cols=[hc[0],tipC];
    const hair=K.makeHair(R.head,{mat:flame,grav:-.55,drag:.9,wind:2.4,stiff:.06,tip:.9,wp:.8,strands:hs},R);
    const hip=[]; for(let i=0;i<8;i++){ const a=i/8*TAU, rx=Math.sin(a)*.26, rz=Math.cos(a)*.17; hip.push({r:[rx,-.05,rz],d:[rx*1.2,-.7,rz*1.2],L:.5+((i*29)%4)*.1,n:6,w0:.12,w1:.01,wave:.4,wph:i*.9,stiff:.05,cols:[hc[0],tipC]}); }
    const hipF=K.makeHair(R.root,{mat:flame,grav:-.5,drag:.9,wind:2,stiff:.05,colliders:[["root",0,-.02,0,.32,.12,.2],["hpL",0,-.21,0,.12,.25,.12],["hpR",0,-.21,0,.12,.25,.12]],strands:hip},R);
    const rag=[]; for(let i=0;i<9;i++){ const x=(i-4)*.07; rag.push({r:[x,-.06,.2-Math.abs(i-4)*.04],d:[x*2,-1,.3],L:.5+((i*37)%5)*.1,n:7,w0:.1,w1:.02,wave:.3,wph:i,stiff:.04,cols:[[.16,.05,.3],[.04,0,.08]]}); }
    const ragM=hairMat(M,0x1a0838,.2); const ragH=K.makeHair(R.root,{mat:ragM,grav:.8,drag:.93,wind:.8,stiff:.04,colliders:[["root",0,-.02,0,.32,.12,.2],["hpL",0,-.21,0,.12,.25,.12],["hpR",0,-.21,0,.12,.25,.12]],strands:rag},R);
    const ac=pal.aura||[0xb44cff,0xe0b0ff,0x7a2cff];
    const em2=[{ob:R.head,x:0,y:.35,z:-.05,r:.14},{ob:R.chest,x:.5,y:.5,z:0,r:.1},{ob:R.chest,x:-.5,y:.5,z:0,r:.1},{ob:R.hdL,x:0,y:-.05,z:0,r:.05},{ob:R.hdR,x:0,y:-.05,z:0,r:.05},{ob:R.chest,x:0,y:.1,z:-.3,r:.25},{ob:R.ftL,x:0,y:-.1,z:.1,r:.06},{ob:R.ftR,x:0,y:-.1,z:.1,r:.06}];
    const embers=K.makeAura(g,{n:44,color:ac,vel:[0,1.2,0],jit:1.2,up:1.2,life:[.8,1.9],size:[.14,.02],rate:32,grav:.6,drag:.985,swirl:1.2,op:.95,emit:em2,flick:true});
    const souls=K.makeAura(g,{n:14,color:[0xe9d0ff,0xffffff],vel:[0,.5,0],jit:.4,up:.4,life:[1.6,3],size:[.2,.05],rate:6,grav:.05,drag:.99,swirl:.9,op:.55,emit:em2});
    return Game.VIPRun(c,{hairs:[hair,hipF,ragH],auras:[{o:embers},{o:souls,k:.7}],eyeGlow:eg,
      tick(st,dt,time){ core.material.opacity=Math.min(1,.55+.3*Math.sin(time*4.1)+(st.act?.35:0)); const s=.5+.1*Math.sin(time*4.1)+(st.act?.25:0); core.scale.set(s,s,1); } }); } };

/* ================= KOZMOS ================= */
Game.VIPB.kozmos={
  mats(c){ const {M,pri,sec,trim,pal}=c, tex=galaxyTex(pal.gx||{}), gal=keep(M("#ffffff",{roughness:.5,metalness:.1,map:tex,emissive:0xffffff,emissiveMap:tex,emissiveIntensity:.8}));
    return {pri:gal,sec:M(sec,{roughness:.4,metalness:.5}),trim:keep(M(trim,{roughness:.2,metalness:1,emissive:pal.trimE||0x701a60,emissiveIntensity:.5})),skin:M("#f0d6ee",{roughness:.55}),dark:M("#12082a",{roughness:.7}),white:M("#ffffff",{roughness:.7}),
      arm:gal,leg:gal,tor:gal,hand:M(trim,{roughness:.3,metalness:.8}),boot:M(sec,{roughness:.35,metalness:.6}),_tex:tex}; },
  build(c){ const {R,add,cl,CO,SP,CY,TO,B,grp,M,mats,fc,pal,mPri,mSec,mTrim,mGlow,g,laserHex,vm}=c; const tex=vm._tex;
    /* yıldız tacı */
    const starM=basic({color:pal.star!=null?pal.star:0xfff0b0},mats), stars=[];
    for(let i=0;i<9;i++){ const az=-1.6+i*.4, h=(i===4?.26:i%2?.12:.18), gp=grp(R.head,Math.sin(az)*.2,.27,Math.cos(az)*.2-.01); gp.rotation.y=az; add(gp,CO(.03,h,4),starM,0,h/2,0,.3); stars.push(gp); }
    add(R.head,TO(.205,.014,6,24),mTrim,0,.26,0,PI/2);
    const crownG=K.glowSprite(R.head,pal.glow||0xff9be8,.9,0,.42,-.02,.5);
    /* göğüs: galaksi çekirdeği */
    cl(R.chest,mTrim,0,.3,.236,.62,.035,.015); cl(R.chest,mTrim,0,-.05,.236,.5,.03,.015);
    add(R.chest,SP(.085,12,8),mGlow,0,.19,.235); add(R.chest,TO(.13,.016,8,24),mTrim,0,.19,.235); add(R.chest,TO(.17,.008,6,28),mTrim,0,.19,.238,.35,0,.5);
    const coreG=K.glowSprite(R.chest,laserHex,.6,0,.19,.3,.8);
    for(const s of [-1,1]){ const el=s<0?R.elL:R.elR, kn=s<0?R.knL:R.knR;
      add(R.chest,SP(.18,12,8),mTrim,s*.46,.37,0,0,0,0,1,.78,1.1); add(R.chest,CO(.04,.28,5),mTrim,s*.56,.58,-.02,0,0,s*-.6);
      add(el,CY(.087,.07,.2,10),mTrim,0,-.16,0); add(el,TO(.084,.012,6,12),mSec,0,-.06,0,PI/2);
      add(kn,CY(.09,.074,.12,10),mTrim,0,-.34,0); add(kn,TO(.088,.012,6,12),mSec,0,-.3,0,PI/2); cl(s<0?R.ftL:R.ftR,mTrim,0,-.04,.2,.12,.03,.1); }
    cl(R.root,mTrim,0,.05,0,.62,.07,.37); cl(R.root,mSec,0,-.02,.2,.12,.34,.02);
    /* yıldız tozu saçı */
    const hc=pal.hair||[[1,.7,.95],[.45,.85,1]], mh=hairMat(M,pal.hairE||0x401a6a,.5);
    const hs=fan({count:26,az0:1.7,az1:TAU-1.7,el0:-.05,el1:1,L0:.6,L1:1.2,n:12,w0:.12,w1:.03,droop:.3,wave:.55,out:.4,down:.8,dz:-.4,stiff:.04,seed:17,cols:hc}), bang=fan({count:7,az0:-.6,az1:.6,el0:.85,el1:1.1,L0:.2,L1:.34,n:5,w0:.09,w1:.03,droop:1.4,dz:.45,out:.5,stiff:.05,seed:5,cols:hc});
    const hair=K.makeHair(R.head,{mat:mh,grav:.25,drag:.94,wind:.9,stiff:.04,tip:1.1,wp:.8,colliders:[["head",0,.1,0,.205,.22,.205],["chest",0,0,-.05,.46,.5,.28]],strands:hs.concat(bang)},R);
    const sashH=K.makeHair(R.root,{mat:mh,grav:.8,drag:.93,wind:.6,stiff:.04,colliders:[["root",0,-.02,0,.32,.12,.2],["hpL",0,-.21,0,.12,.25,.12],["hpR",0,-.21,0,.12,.25,.12]],strands:sashes([[1,.7,.95],[.5,.8,1]],3)},R);
    /* yörüngede dönen gezegenler */
    const orb=grp(R.root,0,.05,0), tilt=grp(orb,0,0,0); tilt.rotation.set(.25,0,.35);
    const ring=new THREE.Mesh(new THREE.TorusGeometry(.8,.006,6,64),basic({color:pal.ring||0xff9be8,transparent:true,opacity:.45,blending:AD,depthWrite:false},mats)); ring.rotation.x=PI/2; tilt.add(ring);
    const PL=[{s:.075,col:pal.p1||"#ff7ad9",ph:0,sp:1.1},{s:.055,col:pal.p2||"#7ad7ff",ph:2.1,sp:1.1},{s:.066,col:pal.p3||"#ffd36a",ph:4.2,sp:1.1,rg:1}];
    for(const p of PL){ const mt=M(p.col,{roughness:.5,emissive:p.col,emissiveIntensity:.7}); p.m=new THREE.Mesh(new THREE.SphereGeometry(p.s,12,10),mt); tilt.add(p.m); if(p.rg){ const r2=new THREE.Mesh(new THREE.TorusGeometry(p.s*1.7,p.s*.12,5,20),basic({color:0xffe6a0,transparent:true,opacity:.8},mats)); r2.rotation.x=PI/2-.4; p.m.add(r2); } p.gl=K.glowSprite(p.m,p.col,p.s*7,0,0,0,.45); }
    const ac=pal.aura||[0xff9be8,0x9fd8ff,0xffffff];
    const em=[{ob:R.chest,x:.8,y:.7,z:-.25,r:.3},{ob:R.chest,x:-.8,y:.7,z:-.25,r:.3},{ob:R.head,x:0,y:.35,z:0,r:.25},{ob:R.chest,x:0,y:.2,z:0,r:.5},{ob:R.hdL,x:0,y:-.05,z:0,r:.06},{ob:R.hdR,x:0,y:-.05,z:0,r:.06},{ob:R.ftL,x:0,y:-.1,z:.1,r:.06},{ob:R.ftR,x:0,y:-.1,z:.1,r:.06}];
    const dust=K.makeAura(g,{n:48,color:ac,vel:[0,.1,0],jit:.5,up:.2,life:[1.6,3.4],size:[.1,.02],rate:20,grav:.02,drag:.98,swirl:.8,op:.95,emit:em,flick:true});
    const eg=[]; for(const s of [-1,1]){ const sp=K.glowSprite(R.head,pal.eye!=null?pal.eye:0xffffff,.34,s*.075,.12,.235,.85); eg.push({sp,op:.85,s:.34,ph:s}); }
    return Game.VIPRun(c,{hairs:[hair,sashH],auras:[{o:dust}],eyeGlow:eg,auraK:st=>.8+st.f*.9+(st.act?1.4:0),
      tick(st,dt,time){ const sp=st.act?2.4:1; tex.offset.x=(time*.012)%1; tex.offset.y=(time*.007)%1; orb.rotation.y=time*.5*sp;
        for(const p of PL){ const a=time*p.sp*sp+p.ph; p.m.position.set(Math.cos(a)*.8,0,Math.sin(a)*.8); }
        coreG.material.opacity=.6+.2*Math.sin(time*3.4)+(st.act?.3:0); crownG.material.opacity=.4+.12*Math.sin(time*2.2); for(let i=0;i<stars.length;i++) stars[i].scale.y=.85+.25*Math.sin(time*3+i*1.7); } }); } };

const gxCape=()=>(tex,ctx)=>{ const cv=tex.image; if(!cv||!cv.getContext) return; const g=Object.assign({a:"#10052e",b:"#3a147a",seed:9},(ctx.pal&&ctx.pal.gx)||{}); paintGalaxy(cv.getContext("2d"),cv.width,cv.height,g,K.rngS(31),true); tex.needsUpdate=true; };
Object.assign(CHARS,{
  kronos:{vip:true,icon:"⌛",laser:0xffd36a,eye:0xffe9a8,accent:"#4b1f9a",cape:{w:1,h:1.45,cols:9,rows:14,ay:.35,az:-.2,make:capeMat("storm"),jag:(j,dep,time)=>dep>.6?(Math.sin(time*3+j*2.1)*.5+.5)*.08*(dep-.6)/.4:0},
    skins:[["#2a1458","#150a30","#ffd36a","#4b1f9a",0,{eye:0xffe9a8,laser:0xffd36a,glow:0xffc94a,gold:0xffd36a,disc:0x8a4cff,trimE:0x7a5a10,hair:[[1,.97,.85],[.78,.6,1]],aura:[0xffe08a,0xc9a0ff,0xffffff],cape:{a:"#1b0b3d",b:"#4b1f9a",c:"#b98bff",bolt:"rgba(255,224,130,.95)"}}],
           ["#142058","#0a1030","#e6ecff","#2a4fc0",0,{eye:0xcfe4ff,laser:0x9fd0ff,glow:0x9fd0ff,gold:0xe6ecff,disc:0x4c8cff,trimE:0x30407a,hair:[[.95,.98,1],[.5,.7,1]],aura:[0xcfe4ff,0x9fb8ff,0xffffff],cape:{a:"#0b1240",b:"#2a4fc0",c:"#9fd0ff",bolt:"rgba(210,235,255,.95)"}}]]},
  nekro:{vip:true,icon:"☠",laser:0xb44cff,eye:0xd98cff,accent:"#1c0a2e",cape:{w:.98,h:1.35,cols:8,rows:13,ay:.35,az:-.2,make:capeMat("flame"),jag:(j,dep,time)=>dep>.6?(Math.sin(time*6.5+j*1.9)*.5+.5)*.14*(dep-.6)/.4:0},
    skins:[["#1c0a2e","#0b0414","#c9a8ff","#3a0f7a",0,{eye:0xd98cff,laser:0xb44cff,bone:"#ddd2ea",trimE:0x4a1a8a,hair:[[.96,.82,1],[.66,.22,1]],tip:[.2,0,.45],aura:[0xb44cff,0xe0b0ff,0x7a2cff],cape:{a:"#0b0218",b:"#3a0f7a",c:"#9a3dff",d:"#f0c8ff"}}],
           ["#0e2418","#050e09","#b8ffd0","#14532d",0,{eye:0xa8ffc4,laser:0x58ff9a,bone:"#d6ead9",trimE:0x1a6a3a,hair:[[.85,1,.9],[.18,.9,.5]],tip:[0,.28,.12],aura:[0x58ff9a,0xc8ffd8,0x1fbf6a],cape:{a:"#02100a",b:"#0f5a30",c:"#2fe07a",d:"#d8ffe6"}}]]},
  kozmos:{vip:true,icon:"✺",laser:0xff7ae0,eye:0xffffff,accent:"#5b1f9a",cape:{w:1.02,h:1.5,cols:9,rows:14,ay:.35,az:-.2,make:capeMat("storm",gxCape()),jag:(j,dep,time)=>dep>.6?(Math.sin(time*2.4+j*2.3)*.5+.5)*.09*(dep-.6)/.4:0},
    skins:[["#1a0a4a","#0a0626","#ff9be8","#5b1f9a",0,{eye:0xffffff,laser:0xff7ae0,glow:0xff9be8,star:0xfff0b0,ring:0xff9be8,gx:{a:"#0a0426",b:"#2a0f6a",seed:5},hair:[[1,.7,.95],[.45,.85,1]],aura:[0xff9be8,0x9fd8ff,0xffffff],cape:{a:"#10052e",b:"#5b1f9a",c:"#ff6ad5",bolt:"rgba(160,230,255,.95)"}}],
           ["#2a1048","#120626","#ffd36a","#7a3cc0",0,{eye:0xfff0c0,laser:0xffd36a,glow:0xffd36a,star:0xffffff,ring:0xffd36a,p1:"#ffd36a",p2:"#ff8a5a",p3:"#c9a0ff",trimE:0x7a5a10,gx:{a:"#140628",b:"#4a1a6a",neb:["rgba(255,200,90,.3)","rgba(255,110,170,.3)","rgba(150,100,255,.3)"],seed:12},hair:[[1,.9,.55],[1,.45,.8]],aura:[0xffd36a,0xffb0e0,0xffffff],cape:{a:"#180830",b:"#7a3cc0",c:"#ffb060",bolt:"rgba(255,230,160,.95)"}}]]}
});
})();
