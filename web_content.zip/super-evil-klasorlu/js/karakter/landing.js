"use strict";
/* ===== KAHRAMAN İNİŞİ: yeterince sert düşüşte diz çöküp yumruk yere iniş + geçici yer çatlağı =====
   Güç, çarpma hızından hesaplanır: LAND_MIN altında hiçbir şey olmaz (her iniş çatlatmaz), LAND_FULL'da tavan. */
Game.Land=(function(){
  const H=Game.H, FX=Game.FX, P=Game.P, rs=Game.U.rs;
  const LAND_MIN=34, LAND_FULL=105, COOL=.9, NDEC=3;
  const power=imp=>Math.max(0,Math.min(1,(imp-LAND_MIN)/(LAND_FULL-LAND_MIN)));
  /* çatlak dokusu: R = çatlağın merkezden uzaklık kodu (iyileşmede uçtan merkeze silinir), G = çatlak maskesi, B = toz/kir halkası */
  function mkTex(seed){ let s=seed*9301+49297; const rnd=()=>{ s=(s*9301+49297)%233280; return s/233280; };
    const c=Game.CG.cnv(256,256), q=c.getContext("2d"), R=122; q.fillStyle="#000"; q.fillRect(0,0,256,256); q.globalCompositeOperation="lighten"; q.lineCap="round";
    const gr=q.createRadialGradient(128,128,6,128,128,R*.78); gr.addColorStop(0,"rgb(0,0,255)"); gr.addColorStop(.55,"rgb(0,0,190)"); gr.addColorStop(1,"rgb(0,0,0)"); q.fillStyle=gr; q.beginPath(); q.arc(128,128,R*.78,0,6.2832); q.fill();
    const crack=(x,y,a,len,w,gen)=>{ let px=x,py=y; for(let d=0;d<len;d+=5){ a+=(rnd()-.5)*.42; const nx=px+Math.cos(a)*5, ny=py+Math.sin(a)*5, dd=Math.hypot(nx-128,ny-128)/R; if(dd>.99) break;
        q.strokeStyle="rgb("+((dd*255)|0)+",255,0)"; q.lineWidth=Math.max(.9,w*(1-d/len*.75)); q.beginPath(); q.moveTo(px,py); q.lineTo(nx,ny); q.stroke(); px=nx; py=ny;
        if(gen<2&&rnd()<.1) crack(px,py,a+(rnd()<.5?-1:1)*(.45+rnd()*.7),len*(.35+rnd()*.25),w*.7,gen+1); } };
    const N=10+((rnd()*5)|0); for(let i=0;i<N;i++) crack(128+rs()*6,128+rs()*6,i/N*6.2832+rs()*.35,R*(.5+rnd()*.5),3.4,0);
    const t=new THREE.CanvasTexture(c); return t; }
  const VS="varying vec2 vUv; void main(){ vUv=uv; gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.); }";
  const FS="uniform sampler2D map; uniform float grow, heal; varying vec2 vUv; void main(){ vec4 t=texture2D(map,vUv); float lim=min(grow,1.0-heal)*1.05;"+
    " float cr=smoothstep(.12,.55,t.g)*(1.0-smoothstep(lim-.05,lim,t.r)); float dirt=t.b*smoothstep(0.,.3,grow)*(1.0-heal); float a=max(cr*.96,dirt*.55);"+
    " vec3 c=mix(vec3(.17,.15,.13),vec3(.012,.012,.012),cr); gl_FragColor=vec4(c,a); }";
  const decals=[], geo=new THREE.PlaneGeometry(1,1);
  for(let i=0;i<NDEC;i++){ const mat=new THREE.ShaderMaterial({transparent:true,depthWrite:false,polygonOffset:true,polygonOffsetFactor:-6,polygonOffsetUnits:-6,uniforms:{map:{value:mkTex(i+3)},grow:{value:0},heal:{value:0}},vertexShader:VS,fragmentShader:FS});
    const m=new THREE.Mesh(geo,mat); m.visible=false; m.renderOrder=3; m.frustumCulled=false; scene.add(m); decals.push({m,mat,on:false,t:0,life:0,grow:.16}); }
  let next=0, cool=0;
  /* x,y,z: ayak altındaki zemin noktası; imp: çarpma hızı (m/s). Sert inişse çatlak + animasyon başlatır, güç 0..1 döner (0 = normal iniş). */
  function land(x,y,z,imp){ const k=power(imp); if(cool>0||imp<LAND_MIN) return 0; cool=COOL;
    const dc=decals[next], R=3+6.5*k; next=(next+1)%NDEC; dc.on=true; dc.t=0; dc.life=4.2+3.2*k; dc.grow=.16+.1*k; dc.m.position.set(x,y+.035,z); dc.m.rotation.set(-Math.PI/2,0,Math.random()*6.283); dc.m.scale.set(R*2,R*2,1); dc.m.visible=true; dc.mat.uniforms.grow.value=0; dc.mat.uniforms.heal.value=0;
    H.shake=Math.max(H.shake,.55+.9*k); if(Game.shakeAdd) Game.shakeAdd(.3+.6*k);
    FX.shock(x,y+.3,z,22+(k*30|0),14+14*k); FX.dust(x,y+.3,z,18+(k*26|0),3+3*k); FX.spark(x,y+.2,z,8+(k*14|0),8+8*k,[1,.85,.55]); if(k>.45) FX.cloud&&FX.cloud(x,y+.5,z,3,R*.8,2.4);
    if(Game.audio){ Game.audio.thud(x,y,z); if(k>.3&&Game.audio.boom) Game.audio.boom(x,y,z); }
    /* çatlaktan fırlayan moloz */
    if(P&&P.spawnDebris){ const n=4+(k*9|0); for(let i=0;i<n;i++){ const a=Math.random()*6.283, sp=4+Math.random()*(6+10*k), s=.28+Math.random()*.32, g=.34+Math.random()*.16;
        P.spawnDebris({sx:s,sy:s*.7,sz:s,x:x+Math.cos(a)*1.2,y:y+.25,z:z+Math.sin(a)*1.2,r:g,g:g*.95,b:g*.9,burn:0,frost:0},Math.cos(a)*sp,5+Math.random()*(5+7*k),Math.sin(a)*sp); } }
    /* iniş sırasında hareket kilidi ve animasyon (süre güce bağlı) */
    const dur=.85+.55*k; H.landLock=dur*.62; if(Game.act) Game.act("land",dur,1);
    if(Game.NPC) Game.NPC.alert(x,z,60+60*k,x,z); if(Game.radial) Game.radial(x,y+1,z,6+9*k,10+20*k,"clap");
    return k; }
  Game.heroLand=land;
  const fn=(dt)=>{ if(cool>0) cool-=dt; if(H.landLock>0) H.landLock-=dt;
    for(const dc of decals){ if(!dc.on) continue; dc.t+=dt; const u=dc.mat.uniforms, healStart=dc.life*.55;
      u.grow.value=Math.min(1,dc.t/dc.grow); u.heal.value=dc.t<healStart?0:Math.min(1,(dc.t-healStart)/(dc.life-healStart));
      /* iyileşirken zeminden hafif toz tütmesi */
      if(dc.t>healStart&&Math.random()<dt*10) FX.dust(dc.m.position.x+rs()*dc.m.scale.x*.3,dc.m.position.y+.1,dc.m.position.z+rs()*dc.m.scale.y*.3,1,.6);
      if(dc.t>=dc.life){ dc.on=false; dc.m.visible=false; } } };
  fn.__menu=false; Game.updaters.push(fn);
  Game.Land_debug={decals,power,LAND_MIN,LAND_FULL};
  return {land,power,LAND_MIN,LAND_FULL,reset(){ for(const dc of decals){ dc.on=false; dc.m.visible=false; } cool=0; H.landLock=0; }};
})();
