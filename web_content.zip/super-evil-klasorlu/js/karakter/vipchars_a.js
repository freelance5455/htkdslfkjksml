"use strict";
/* ===== VIP KARAKTERLER (1/2): ortak çalıştırıcı + VOID (kara varlık) + INFERNO (alev) =====
   Her VIP: kendi malzemeleri (VB.mats) + gövde süsleri/saç/aura (VB.build) + kare güncellemesi (Game.VIPRun). Premium Mağaza'dan açılır. */
Game.VIPB={};
Game.VIP_IDS=["void","inferno","frost","storm","seraph"];
(function(){
const K=Game.VIPKit, PI=Math.PI, clamp=K.clamp, sm=K.sm;
const lerp=(a,b,t)=>a+(b-a)*t, keep=m=>{ m.userData=m.userData||{}; m.userData.keepEm=true; return m; };
/* ortak çalıştırıcı: göz kırpma/kısma, saç + aura güncelleme, menü rüzgârı */
Game.VIPRun=function(ctx,P){
  const fc=ctx.fc, hairs=P.hairs||[], auras=P.auras||[], eg=P.eyeGlow||[], bL=[fc.eyeL.scale.x,fc.eyeL.scale.y,fc.eyeL.scale.z], bR=[fc.eyeR.scale.x,fc.eyeR.scale.y,fc.eyeR.scale.z];
  let blinkT=1.5+Math.random()*3, blink=0;
  const vip={P,hairs,auras,st:null,
    attach(u){ vip.u=u; },
    update(dt,time,u){ const H=Game.H; if(!u.menuWind&&Game.heroObj&&Game.heroObj.visible===false) return; dt=clamp(dt,.0005,.05);
      const menu=!!u.menuWind, fly=menu?false:!!H.flying, f=menu?0:Math.min(1,(H.speed||0)/38);
      const st=vip.st={dt,time,menu,fly,f,boost:menu?false:!!H.boost,hv:menu?0:(H.hv||0),grounded:menu?true:!!H.grounded,vy:menu?0:H.vel.y,act:menu?"":(u.act||""),land:menu?0:(H.landT||0),turn:menu?0:(H.turn||0),sp:menu?0:(H.sp||0)};
      blinkT-=dt; if(blinkT<0){ blink=.15; blinkT=2+Math.random()*4.5; } if(blink>0) blink-=dt;
      const bk=blink>0?Math.abs(blink/.15*2-1):1, wide=st.act==="laser"?1.3:1, sq=(st.fly&&st.f>.55)?.72:1, k=Math.max(.06,bk)*wide*sq;
      fc.eyeL.scale.set(bL[0],bL[1]*k,bL[2]); fc.eyeR.scale.set(bR[0],bR[1]*k,bR[2]);
      const lit=(P.eyeLit||1)*(st.act==="laser"?1.5:1); for(const e of eg){ e.sp.material.opacity=Math.min(1,e.op*Math.min(1,k*1.2)*lit); const s=e.s*(.9+.1*Math.sin(time*5+e.ph))*(.7+.3*Math.min(1,k)); e.sp.scale.set(s*(e.ax||1),s*(e.ay||1),1); }
      const mw=u.menuWind, wind=mw?{x:-mw.x*.012,y:0,z:-mw.z*.012}:null;
      for(const h of hairs) h.update(dt,time,wind);
      const ak=P.auraK?P.auraK(st):(1+st.f*1.1+(st.act?1:0)+(st.fly?.4:0)); for(const a of auras) a.o.update(dt,ak*(a.k||1),a.emit);
      if(P.tick) P.tick(st,dt,time,u); },
    rest(){ for(const h of hairs) h.rest(70); if(P.rest) P.rest(); },
    reset(){ for(const h of hairs) h.reset(); for(const a of auras) a.o.clear(); if(P.reset) P.reset(); } };
  return vip; };
const fan=K.fan;
const rgb=h=>{ const c=new THREE.Color(h); return [c.r,c.g,c.b]; };
const basic=(o,mats)=>{ const m=new THREE.MeshBasicMaterial(Object.assign({side:THREE.DoubleSide,fog:false},o)); mats.push(m); return m; };
const flameMat=mats=>basic({vertexColors:true,transparent:true,blending:THREE.AdditiveBlending,depthWrite:false},mats);
function lavaTex(rgbStr){ const c=K.cnv(256,256), q=c.getContext("2d"), rnd=K.rngS(77); q.fillStyle="#000"; q.fillRect(0,0,256,256); q.lineCap="round"; q.lineJoin="round";
  for(let i=0;i<30;i++){ let x=rnd()*256, y=rnd()*256, a=rnd()*6.28; const pts=[[x,y]]; const n=4+((rnd()*5)|0); for(let k=0;k<n;k++){ a+=(rnd()-.5)*1.4; x+=Math.cos(a)*(14+rnd()*24); y+=Math.sin(a)*(14+rnd()*24); pts.push([x,y]); }
    for(const [ox,oy] of [[0,0],[256,0],[-256,0],[0,256],[0,-256]]){ q.beginPath(); pts.forEach((p,j)=>j?q.lineTo(p[0]+ox,p[1]+oy):q.moveTo(p[0]+ox,p[1]+oy)); q.strokeStyle="rgba("+rgbStr+",.3)"; q.lineWidth=7; q.stroke(); q.strokeStyle="rgb("+rgbStr+")"; q.lineWidth=2.2; q.stroke(); } }
  const t=new THREE.CanvasTexture(c); t.wrapS=t.wrapT=THREE.RepeatWrapping; return t; }
const capeMat=(kind,pal)=>ctx=>{ const m=new THREE.MeshBasicMaterial({map:K.capeTexture(kind,pal?pal(ctx):ctx.pal.cape),alphaTest:.5,side:THREE.DoubleSide,color:kind==="void"?0x000000:0xffffff,fog:kind!=="flame"}); ctx.mats.push(m); return keep(m); };

/* ================= VOID ================= */
Game.VIPB.void={
  mats(c){ const m=Game.noSnow(new THREE.MeshPhysicalMaterial({color:0x000000,roughness:1,metalness:0,reflectivity:0,side:THREE.DoubleSide})); c.mats.push(m);
    return {pri:m,sec:m,trim:m,skin:m,dark:m,white:m,arm:m,leg:m,tor:m,hand:m,boot:m,_b:m}; },
  build(c){ const {R,add,CO,SP,CY,mats,fc,mEye}=c, b=c.vm._b, ink=basic({color:0x000000},mats);
    /* kukuleta: yüzü açık, arkası/üstü kapalı kabuk + sivri tepe */
    const hood=new THREE.Mesh(new THREE.SphereGeometry(.246,22,14,PI/2+1.15,PI*2-2.3),b); hood.position.set(0,.13,-.04); hood.scale.set(1,1.03,1.06); R.head.add(hood);
    add(R.head,CO(.15,.5,10),b,0,.34,-.21,-.95); add(R.head,CO(.09,.34,8),b,0,.16,-.34,-1.45);
    fc.brL.visible=fc.brR.visible=fc.nose.visible=fc.mouth.visible=false;
    /* gözler: ince, açılı, parlak beyaz yarıklar + halo */
    fc.eyeL.scale.set(1.95,.5,1); fc.eyeR.scale.set(1.95,.5,1); fc.eyeL.rotation.z=-.42; fc.eyeR.rotation.z=.42; fc.eyeL.position.set(-.082,.125,.19); fc.eyeR.position.set(.082,.125,.19);
    const eg=[]; for(const s of [-1,1]){ const sp=K.glowSprite(R.head,0xffffff,.5,s*.082,.125,.235,.9); eg.push({sp,op:.9,s:.5,ph:s}); }
    const st=K.glowSprite(R.head,0xffffff,1,0,.125,.24,.35); eg.push({sp:st,op:.35,s:1,ph:2,ax:.9,ay:.12});
    /* omuz/dirsek/diz dikenleri (sadece siluet) */
    for(const s of [-1,1]){ add(R.chest,SP(.2,12,8),b,s*.45,.34,0,0,0,0,1,.8,1.1); add(R.chest,CO(.1,.52,6),b,s*.52,.56,-.05,0,0,s*-.75); add(R.chest,CO(.07,.34,5),b,s*.62,.42,.06,0,0,s*-1.25); add(R.chest,CO(.06,.3,5),b,s*.4,.55,-.2,-.5,0,s*-.3);
      add(s<0?R.elL:R.elR,CO(.05,.3,5),b,0,-.02,-.09,-PI/2); add(s<0?R.knL:R.knR,CO(.045,.24,5),b,0,0,.1,PI/2); add(s<0?R.hdL:R.hdR,CO(.03,.16,5),b,s*.04,-.12,.05,.3); }
    add(R.chest,CY(.34,.5,.34,12,1,true),b,0,.5,-.1,.2); /* yüksek yaka */
    /* şeritler: kafa dumanı, sırt hortumları, bel şeritleri */
    const head=K.makeHair(R.head,{mat:ink,grav:-.14,drag:.93,wind:1.5,stiff:.04,wp:.8,strands:fan({count:9,az0:PI-1.2,az1:PI+1.2,el0:.05,el1:.8,L0:.5,L1:1,n:8,w0:.1,w1:.008,droop:-.25,wave:.5,dz:-.25,up:.2,out:.7,seed:5})},R);
    const back=[]; for(let i=0;i<7;i++){ const x=(i-3)*.12, f=Math.abs(i-3)/3; back.push({r:[x,.32-f*.06,-.2],d:[x*1.6,-.25,-1],L:1.15+((i*37)%5)*.12,n:11,w0:.15,w1:.012,wave:.35,wph:i*1.3,droop:.25,sd:[1,0,0]}); }
    const bk=K.makeHair(R.chest,{mat:ink,grav:.2,drag:.94,wind:1.1,stiff:.03,wp:.9,colliders:[["chest",0,.13,-.01,.42,.3,.24],["spine",0,.14,0,.34,.2,.22]],strands:back},R);
    const sash=[]; for(let i=0;i<7;i++){ const a=i/6*PI*2, rx=Math.sin(a)*.25, rz=Math.cos(a)*.17; sash.push({r:[rx,-.05,rz],d:[rx*1.4,-1,rz*1.4],L:.6+((i*53)%4)*.1,n:7,w0:.13,w1:.02,wave:.25,wph:i,stiff:.04}); }
    const wa=K.makeHair(R.root,{mat:ink,grav:.7,drag:.93,wind:.8,stiff:.035,colliders:[["root",0,-.02,0,.32,.12,.2],["hpL",0,-.21,0,.12,.25,.12],["hpR",0,-.21,0,.12,.25,.12]],strands:sash},R);
    /* kara duman */
    const em=[{ob:R.chest,x:.45,y:.42,z:-.1,r:.12},{ob:R.chest,x:-.45,y:.42,z:-.1,r:.12},{ob:R.head,x:0,y:.2,z:-.22,r:.1},{ob:R.hdL,x:0,y:-.05,z:0,r:.05},{ob:R.hdR,x:0,y:-.05,z:0,r:.05},{ob:R.chest,x:0,y:.1,z:-.3,r:.2}];
    const smoke=K.makeAura(c.g,{n:26,color:[0x000000],add:false,vel:[0,.55,0],jit:.5,up:.5,life:[1.2,2.4],size:[.28,.85],rate:11,grav:.18,drag:.985,swirl:.5,op:.55,emit:em,order:6});
    return Game.VIPRun(c,{hairs:[head,bk,wa],auras:[{o:smoke}],eyeGlow:eg}); } };

/* ================= INFERNO ================= */
Game.VIPB.inferno={
  mats(c){ const {M,pal}=c, crack=lavaTex(pal.crack||"255,110,20"), em=(col,i)=>{ const m=M(col,{roughness:.8,emissive:0xffffff,emissiveMap:crack,emissiveIntensity:i}); return keep(m); };
    const skin=em(pal.skinC||"#1f1210",.95), tor=M(pal.armor||"#171010",{roughness:.45,metalness:.6}), trim=M(c.trim,{roughness:.3,metalness:.4,emissive:pal.trimE||0xff4a00,emissiveIntensity:.7}); keep(trim);
    return {skin,arm:skin,leg:em(pal.skinC||"#241311",.8),hand:skin,tor,boot:tor,trim,dark:M("#0f0808",{roughness:.7}),pri:tor,sec:M(c.sec,{roughness:.7}),_skin:skin}; },
  build(c){ const {R,add,cl,CO,SP,CY,TO,mats,fc,pal,mPri,mTrim,mGlow,mSec,laserHex}=c, vm=c.vm;
    /* boynuzlar */
    for(const s of [-1,1]){ add(R.head,CO(.058,.36,7),mPri,s*.13,.3,-.02,-.35,0,s*-.55); add(R.head,CO(.032,.24,6),mGlow,s*.255,.52,-.1,-.6,0,s*-.9); add(R.head,CO(.04,.18,5),mPri,s*.2,.2,-.05,-.5,0,s*-1.1); }
    add(R.head,TO(.2,.02,6,20),mTrim,0,.25,0,PI/2,0,0,1,1,1);
    /* göğüs çekirdeği + plaka */
    cl(R.chest,mPri,0,.12,.215,.66,.4,.04); cl(R.chest,mTrim,0,.12,.237,.05,.4,.015); cl(R.chest,mTrim,0,.3,.237,.5,.04,.015);
    add(R.chest,SP(.085,12,8),mGlow,0,.2,.24); add(R.chest,TO(.125,.018,8,18),mTrim,0,.2,.235);
    const core=K.glowSprite(R.chest,laserHex,.55,0,.2,.3,.85);
    for(const s of [-1,1]){ const el=s<0?R.elL:R.elR, kn=s<0?R.knL:R.knR;
      add(R.chest,SP(.2,12,8),mPri,s*.46,.36,0,0,0,0,1,.8,1.1); add(R.chest,CO(.055,.3,5),mPri,s*.52,.58,0,0,0,s*-.5); add(R.chest,CO(.045,.24,5),mPri,s*.6,.5,.07,0,0,s*-1.1); add(R.chest,CO(.045,.22,5),mPri,s*.58,.5,-.08,0,0,s*-1.0);
      add(R.chest,SP(.03,6,6),mGlow,s*.57,.76,0); add(R.chest,SP(.025,6,6),mGlow,s*.77,.62,.1);
      add(el,CY(.088,.076,.22,10),mPri,0,-.15,0); add(el,TO(.085,.013,6,12),mTrim,0,-.06,0,PI/2); add(el,TO(.075,.013,6,12),mTrim,0,-.25,0,PI/2); cl(el,mGlow,0,-.18,.075,.025,.12,.02);
      add(kn,CY(.088,.076,.12,10),mPri,0,-.34,0); add(kn,TO(.085,.014,6,12),mTrim,0,-.3,0,PI/2); add(kn,CO(.05,.16,5),mPri,0,-.02,.1,PI/2);
      add(s<0?R.ftL:R.ftR,B1(c),mGlow,0,-.1,.06,0,0,0,1,.12,1); }
    cl(R.root,mPri,0,.04,0,.64,.1,.37); cl(R.root,mGlow,0,.04,.19,.12,.08,.02); cl(R.root,mTrim,0,.1,0,.66,.03,.38);
    /* alev saçı + kalça alevleri */
    const flame=flameMat(mats), hc=pal.hair||[[1,1,.75],[1,.45,.06]], tipC=[pal.tip?pal.tip[0]:.45,pal.tip?pal.tip[1]:.03,pal.tip?pal.tip[2]:0];
    const mid=[hc[1][0],hc[1][1],hc[1][2]];
    const hs=fan({count:22,az0:0,az1:PI*2-.2,el0:.3,el1:1.25,L0:.34,L1:.82,n:8,w0:.1,w1:.01,droop:-.2,wave:.5,up:.9,out:.75,stiff:.07,seed:11,cols:[hc[0],tipC]}); for(const s of hs){ s.cols=[hc[0],tipC]; }
    const hair=K.makeHair(R.head,{mat:flame,grav:-.55,drag:.9,wind:2.4,stiff:.06,tip:.9,wp:.8,strands:hs},R);
    const hip=[]; for(let i=0;i<8;i++){ const a=i/8*PI*2, rx=Math.sin(a)*.26, rz=Math.cos(a)*.17; hip.push({r:[rx,-.05,rz],d:[rx*1.2,-.7,rz*1.2],L:.5+((i*29)%4)*.1,n:6,w0:.12,w1:.01,wave:.4,wph:i*.9,stiff:.05,cols:[hc[0],tipC]}); }
    const hipF=K.makeHair(R.root,{mat:flame,grav:-.5,drag:.9,wind:2,stiff:.05,colliders:[["root",0,-.02,0,.32,.12,.2],["hpL",0,-.21,0,.12,.25,.12],["hpR",0,-.21,0,.12,.25,.12]],strands:hip},R);
    const ac=pal.aura||[0xff7a1a,0xffc04a,0xff3a0a];
    const em=[{ob:R.head,x:0,y:.35,z:-.05,r:.14},{ob:R.chest,x:.5,y:.5,z:0,r:.1},{ob:R.chest,x:-.5,y:.5,z:0,r:.1},{ob:R.hdL,x:0,y:-.05,z:0,r:.05},{ob:R.hdR,x:0,y:-.05,z:0,r:.05},{ob:R.chest,x:0,y:.1,z:-.3,r:.25},{ob:R.ftL,x:0,y:-.1,z:.1,r:.06},{ob:R.ftR,x:0,y:-.1,z:.1,r:.06}];
    const embers=K.makeAura(c.g,{n:40,color:ac,vel:[0,1.2,0],jit:1.2,up:1.2,life:[.8,1.9],size:[.13,.02],rate:30,grav:.6,drag:.985,swirl:1.2,op:.95,emit:em,flick:true});
    const smoke=K.makeAura(c.g,{n:12,color:[0x1a0c0a],add:false,vel:[0,.7,0],jit:.4,life:[1.4,2.6],size:[.2,.6],rate:5,grav:.1,drag:.985,op:.28,emit:em,order:6});
    const eg=[]; for(const s of [-1,1]){ const sp=K.glowSprite(c.R.head,pal.eye!=null?pal.eye:0xffe27a,.34,s*.075,.12,.235,.85); eg.push({sp,op:.85,s:.34,ph:s}); }
    const skinM=vm._skin;
    return Game.VIPRun(c,{hairs:[hair,hipF],auras:[{o:embers},{o:smoke,k:.7}],eyeGlow:eg,
      tick(st,dt,time){ const hot=st.act?1.4:1; const fl=.75+.25*Math.sin(time*6.1)*Math.sin(time*3.7); skinM.emissiveIntensity=fl*.95*hot; core.material.opacity=Math.min(1,(.55+.3*Math.sin(time*4.3)+(st.act?.3:0))); const s=.5+.12*Math.sin(time*4.3)+(st.act?.25:0); core.scale.set(s,s,1); } }); } };
function B1(c){ return new THREE.BoxGeometry(.17,.1,.3); }
Object.assign(CHARS,{
  void:{vip:true,icon:"◼",laser:0xeef4ff,eye:0xffffff,accent:"#000000",cape:{w:1.12,h:1.65,cols:10,rows:15,ay:.37,az:-.2,make:capeMat("void"),jag:(j,dep,time)=>dep>.6?(Math.sin(time*2.6+j*2.3)*.5+.5)*.1*(dep-.6)/.4:0},
    skins:[["#000000","#000000","#000000","#000000",0,{eye:0xffffff,laser:0xeef4ff}]]},
  inferno:{vip:true,icon:"♨",laser:0xff5a14,eye:0xffe27a,accent:"#ff7a1a",cape:{w:.98,h:1.32,cols:8,rows:13,ay:.35,az:-.2,make:capeMat("flame"),jag:(j,dep,time)=>dep>.6?(Math.sin(time*7+j*1.9)*.5+.5)*.14*(dep-.6)/.4:0},
    skins:[["#171010","#3a120a","#ff8a1f","#ff6a14",3,{eye:0xffe27a,laser:0xff5a14,crack:"255,110,20",hair:[[1,1,.75],[1,.45,.06]],tip:[.45,.03,0],aura:[0xff7a1a,0xffc04a,0xff3a0a],trimE:0xff4a00,cape:{a:"#1c0504",b:"#7a1405",c:"#ff6a14",d:"#ffe066"}}],
           ["#0a1626","#0e2a4a","#4fd0ff","#1f7fe0",3,{eye:0xd8f6ff,laser:0x39b8ff,crack:"60,190,255",skinC:"#0c141f",armor:"#0a1220",hair:[[.92,1,1],[.12,.55,1]],tip:[0,.06,.4],aura:[0x39b8ff,0x9be8ff,0x1f6bff],trimE:0x1f9bff,cape:{a:"#04101c",b:"#0b3a7a",c:"#2f9bff",d:"#d8f6ff"}}]]}
});
})();
