"use strict";
/* ===== VIP KARAKTERLER (2/2): FROST (buz) + STORM (fırtına) + SERAPH (melek, tüylü kanatlar) ===== */
(function(){
const K=Game.VIPKit, PI=Math.PI, clamp=K.clamp, lerp=(a,b,t)=>a+(b-a)*t, sm=K.sm;
const keep=m=>{ m.userData=m.userData||{}; m.userData.keepEm=true; return m; };
const basic=(o,mats)=>{ const m=new THREE.MeshBasicMaterial(Object.assign({side:THREE.DoubleSide,fog:false},o)); mats.push(m); return m; };
const fan=K.fan;
const capeMat=(kind)=>ctx=>{ const m=new THREE.MeshBasicMaterial({map:K.capeTexture(kind,ctx.pal.cape),alphaTest:.5,side:THREE.DoubleSide,fog:true}); ctx.mats.push(m); return keep(m); };
function snowTex(col){ const c=K.cnv(128,128), q=c.getContext("2d"); q.translate(64,64); q.strokeStyle=col; q.lineWidth=5; q.lineCap="round"; q.shadowColor=col; q.shadowBlur=10;
  for(let i=0;i<6;i++){ q.save(); q.rotate(i*PI/3); q.beginPath(); q.moveTo(0,0); q.lineTo(0,-52); for(const d of [18,32,44]){ const w=(1-d/70)*19; q.moveTo(0,-d); q.lineTo(-w,-d-13); q.moveTo(0,-d); q.lineTo(w,-d-13); } q.stroke(); q.restore(); } return new THREE.CanvasTexture(c); }
const decal=(par,tex,col,w,x,y,z,mats)=>{ const m=new THREE.Mesh(new THREE.PlaneGeometry(w,w),new THREE.MeshBasicMaterial({map:tex,color:col,transparent:true,depthWrite:false,blending:THREE.AdditiveBlending,fog:false})); m.position.set(x,y,z); par.add(m); mats.push(m.material); return m; };

/* ================= FROST ================= */
Game.VIPB.frost={
  mats(c){ const {M,pri,sec,trim,pal}=c, ice=keep(M(pri,{roughness:.16,metalness:.7,emissive:pal.glow||0x3a78b0,emissiveIntensity:.14})), under=M(sec,{roughness:.55,metalness:.2});
    return {pri:ice,sec:under,trim:M(trim,{roughness:.2,metalness:.95}),skin:M("#f1d9cc",{roughness:.6}),dark:M("#1a2a44",{roughness:.7}),white:M("#f6fbff",{roughness:.9}),arm:under,leg:under,tor:ice,hand:ice,boot:ice,_ice:ice}; },
  build(c){ const {R,add,cl,CO,SP,CY,TO,grp,M,mats,fc,pal,mPri,mSec,mTrim,mWhite,mGlow,laserHex}=c;
    const shard=keep(M(pal.shard||"#bfeaff",{roughness:.08,metalness:.1,transparent:true,opacity:.8,emissive:pal.glow||0x58b0ff,emissiveIntensity:.55}));
    /* buz tacı */
    for(let i=0;i<9;i++){ const az=-1.55+i*.39, h=(i===4?.2:i%2?.08:.13), gp=grp(R.head,Math.sin(az)*.2,.27+(i===4?.02:0),Math.cos(az)*.2-.005); gp.rotation.y=az; add(gp,CO(.034,h,5),shard,0,h/2,0,.34); }
    add(R.head,TO(.205,.016,6,24),mTrim,0,.26,0,PI/2);
    /* göğüs: buz zırhı + kar tanesi */
    cl(R.chest,mPri,0,.12,.215,.66,.4,.04); cl(R.chest,mTrim,0,.3,.236,.62,.035,.015); cl(R.chest,mTrim,0,-.04,.236,.5,.03,.015);
    const sf=decal(R.chest,snowTex("#ffffff"),pal.flake||0x9fe0ff,.3,0,.18,.245,mats); const flakeGlow=K.glowSprite(R.chest,pal.glow||0x58b0ff,.55,0,.18,.27,.45);
    /* kürk yaka */
    for(let i=0;i<12;i++){ const a=i/12*PI*2; add(R.chest,SP(.1,8,6),mWhite,Math.sin(a)*.27,.47,Math.cos(a)*.2-.02,0,0,0,1,.7,1); }
    for(const s of [-1,1]){ const el=s<0?R.elL:R.elR, kn=s<0?R.knL:R.knR;
      add(R.chest,SP(.19,12,8),mPri,s*.46,.36,0,0,0,0,1,.8,1.1); add(R.chest,TO(.19,.016,6,18),mTrim,s*.46,.34,0,0,PI/2,0);
      add(R.chest,CO(.06,.4,5),shard,s*.52,.58,-.02,0,0,s*-.45); add(R.chest,CO(.045,.3,5),shard,s*.62,.5,.07,0,0,s*-1.05); add(R.chest,CO(.05,.34,5),shard,s*.58,.5,-.09,-.3,0,s*-.85); add(R.chest,CO(.04,.22,5),shard,s*.4,.56,-.1,-.4,0,s*-.3);
      add(el,CY(.088,.07,.24,10),mPri,0,-.15,0); add(el,TO(.085,.013,6,12),mTrim,0,-.06,0,PI/2); add(el,CO(.03,.16,4),shard,s*.07,-.18,-.02,0,0,s*-.7); add(el,CO(.025,.12,4),shard,s*.06,-.26,0,0,0,s*-.6);
      add(kn,CY(.09,.075,.13,10),mPri,0,-.33,0); add(kn,CO(.05,.2,5),shard,0,-.02,.1,PI/2); add(kn,TO(.088,.013,6,12),mTrim,0,-.28,0,PI/2); }
    cl(R.root,mPri,0,.04,0,.64,.09,.37); cl(R.root,mTrim,0,.1,0,.66,.025,.38); add(R.root,SP(.07,8,6),shard,0,.04,.2);
    /* saç: uzun akıcı + kâkül, etek şeritleri */
    const hc=pal.hair||[[.94,.98,1],[.45,.75,1]], mh=M("#ffffff",{roughness:.32,metalness:.15,side:THREE.DoubleSide,emissive:pal.hairE||0x1c3050,emissiveIntensity:.3}); mh.vertexColors=true; keep(mh);
    const hs=fan({count:24,az0:2.1,az1:PI*2-2.1,el0:-.05,el1:.9,L0:.78,L1:1.28,n:11,w0:.13,w1:.05,droop:.5,wave:.3,out:.3,down:1,dz:-.35,stiff:.04,seed:3,cols:hc}), side=fan({count:12,az0:.45,az1:PI*2-.45,el0:.15,el1:.9,L0:.25,L1:.42,n:6,w0:.09,w1:.04,droop:.9,wave:.2,out:.6,down:.8,stiff:.05,seed:13,cols:hc}).filter(s=>Math.abs(Math.sin(Math.atan2(s.r[0],s.r[2])))>.55&&s.r[2]>-.05);
    const bang=fan({count:6,az0:-.55,az1:.55,el0:.85,el1:1.1,L0:.2,L1:.32,n:5,w0:.09,w1:.03,droop:1.4,dz:.45,out:.5,stiff:.05,seed:9,cols:hc});
    const hair=K.makeHair(R.head,{mat:mh,grav:.55,drag:.93,wind:.7,stiff:.035,tip:1.1,wp:.8,colliders:[["head",0,.1,0,.205,.22,.205],["chest",0,0,-.05,.46,.5,.28]],strands:hs},R), hair2=K.makeHair(R.head,{mat:mh,grav:.55,drag:.93,wind:.7,stiff:.05,tip:1.1,wp:.8,colliders:[["head",0,.1,0,.205,.22,.205]],strands:side.concat(bang)},R);
    const sk=[]; for(let i=0;i<9;i++){ const a=i/9*PI*2, rx=Math.sin(a)*.27, rz=Math.cos(a)*.18; sk.push({r:[rx,-.05,rz],d:[rx*1.6,-1,rz*1.6],L:.6+((i*31)%4)*.09,n:7,w0:.16,w1:.07,wave:.2,wph:i*.8,stiff:.05,cols:[[.5,.75,.95],[.9,.97,1]]}); }
    const ms=M("#ffffff",{roughness:.5,metalness:.2,side:THREE.DoubleSide,emissive:0x203858,emissiveIntensity:.25}); ms.vertexColors=true;
    const skirt=K.makeHair(R.root,{mat:ms,grav:.8,drag:.93,wind:.6,stiff:.04,colliders:[["root",0,-.02,0,.32,.12,.2],["hpL",0,-.21,0,.12,.25,.12],["hpR",0,-.21,0,.12,.25,.12]],strands:sk},R);
    const gl=pal.glow||0x58b0ff, ac=pal.aura||[0xdff6ff,0xaee8ff,0xffffff];
    const em=[{ob:R.head,x:0,y:.3,z:-.1,r:.2},{ob:R.chest,x:.5,y:.5,z:0,r:.14},{ob:R.chest,x:-.5,y:.5,z:0,r:.14},{ob:R.chest,x:0,y:.2,z:-.3,r:.3},{ob:R.hdL,x:0,y:-.05,z:0,r:.06},{ob:R.hdR,x:0,y:-.05,z:0,r:.06},{ob:R.root,x:0,y:-.3,z:0,r:.3}];
    const snow=K.makeAura(c.g,{n:34,color:ac,vel:[0,-.12,0],jit:.5,life:[1.5,3],size:[.07,.03],rate:15,grav:-.08,drag:.97,swirl:.7,op:.95,emit:em,flick:true});
    const mist=K.makeAura(c.g,{n:14,color:[gl],vel:[0,-.2,0],jit:.3,life:[1.6,3],size:[.3,.95],rate:5,grav:-.04,drag:.985,swirl:.3,op:.16,emit:em,order:6});
    const eg=[]; for(const s of [-1,1]){ const sp=K.glowSprite(R.head,pal.eye!=null?pal.eye:0xaef4ff,.32,s*.075,.12,.235,.85); eg.push({sp,op:.85,s:.32,ph:s}); }
    return Game.VIPRun(c,{hairs:[hair,hair2,skirt],auras:[{o:snow},{o:mist,k:.7}],eyeGlow:eg,
      tick(st,dt,time){ flakeGlow.material.opacity=.32+.14*Math.sin(time*2.2)+(st.act?.25:0); const s=.55+.08*Math.sin(time*2.2); flakeGlow.scale.set(s,s,1); shard.emissiveIntensity=.5+.2*Math.sin(time*1.7)+(st.act?.3:0); } }); } };

/* ================= STORM ================= */
Game.VIPB.storm={
  mats(c){ const {M,pri,sec,trim,pal}=c;
    return {pri:M(pri,{roughness:.35,metalness:.75}),sec:M(sec,{roughness:.6,metalness:.2}),trim:keep(M(trim,{roughness:.22,metalness:1,emissive:pal.trimE||0x6a5000,emissiveIntensity:.3})),skin:M("#c68a5e",{roughness:.65}),dark:M("#0a0e1c",{roughness:.7}),white:M("#e9f4ff",{roughness:.8}),arm:M(sec,{roughness:.6,metalness:.2}),leg:M(sec,{roughness:.6,metalness:.2}),tor:M(pri,{roughness:.35,metalness:.75}),hand:M(pri,{roughness:.3,metalness:.8}),boot:M(pri,{roughness:.35,metalness:.75})}; },
  build(c){ const {R,add,cl,CO,SP,CY,TO,B,grp,M,mats,fc,pal,mPri,mSec,mTrim,mGlow,g,laserHex}=c;
    const cy=pal.glow||0x6fd8ff, cyM=basic({color:cy},mats);
    /* başlık + şimşek mücevheri */
    add(R.head,TO(.212,.022,6,24),mTrim,0,.2,0,PI/2); cl(R.head,cyM,0,.2,.215,.05,.09,.025,0,0,.3);
    for(const s of [-1,1]) cl(R.head,mTrim,s*.22,.2,0,.04,.14,.1);
    /* göğüs reaktörü + devre çizgileri */
    cl(R.chest,mPri,0,.12,.215,.66,.4,.04); add(R.chest,TO(.135,.02,8,20),mTrim,0,.2,.236); add(R.chest,SP(.08,10,8),mGlow,0,.2,.246); const reactor=K.glowSprite(R.chest,laserHex,.6,0,.2,.29,.75);
    for(const s of [-1,1]){ cl(R.chest,cyM,s*.24,.1,.238,.012,.36,.01); cl(R.chest,cyM,s*.3,.02,.238,.1,.012,.01); cl(R.chest,cyM,s*.34,.24,.238,.012,.14,.01); }
    for(const s of [-1,1]){ const el=s<0?R.elL:R.elR, kn=s<0?R.knL:R.knR, hd=s<0?R.hdL:R.hdR;
      for(let i=0;i<3;i++) cl(R.chest,i===2?mTrim:mPri,s*(.44+i*.03),.46-i*.07,0,.34-i*.04,.06,.34,0,0,s*(.3+i*.12));
      add(R.chest,CO(.05,.34,4),mTrim,s*.6,.52,-.05,0,0,s*-1.05); add(R.chest,CO(.04,.26,4),mTrim,s*.5,.62,-.1,-.3,0,s*-.5);
      add(el,CY(.088,.07,.24,10),mPri,0,-.15,0); add(el,TO(.085,.012,6,12),cyM,0,-.06,0,PI/2); add(el,TO(.075,.012,6,12),cyM,0,-.24,0,PI/2);
      add(kn,CY(.09,.075,.13,10),mPri,0,-.33,0); add(kn,TO(.088,.012,6,12),cyM,0,-.28,0,PI/2); cl(s<0?R.ftL:R.ftR,mTrim,0,-.04,.2,.12,.03,.1);
      cl(hd,cyM,0,-.1,.07,.1,.015,.02); }
    cl(R.root,mPri,0,.04,0,.64,.1,.37); cl(R.root,mTrim,0,.1,0,.66,.03,.38); cl(R.root,cyM,0,.04,.19,.14,.05,.02);
    /* orbit halkaları (yumruklarda) */
    const rings=[]; for(const s of [-1,1]){ const hd=s<0?R.hdL:R.hdR, rg=grp(hd,0,-.06,0), m1=new THREE.Mesh(new THREE.TorusGeometry(.13,.011,6,20),cyM), m2=new THREE.Mesh(new THREE.TorusGeometry(.105,.009,6,18),cyM); rg.add(m1); rg.add(m2); rings.push({m1,m2,s}); }
    /* saç: sivri dikenler + geriye savrulan şimşek tutamları */
    const hc=pal.hair||[[1,1,.78],[1,.85,.2]], hm=basic({vertexColors:true},mats); hm.fog=true;
    const sp=fan({count:16,az0:0,az1:PI*2-.4,el0:.7,el1:1.3,L0:.34,L1:.66,n:4,w0:.12,w1:.002,droop:-.1,out:.9,up:.75,stiff:.5,seed:21,cols:hc,wave:.1});
    const hair=K.makeHair(R.head,{mat:hm,grav:.05,drag:.88,wind:1.1,stiff:.5,wp:1,strands:sp},R);
    const sw=[]; for(const s of [-1,1]) for(let i=0;i<3;i++){ const q=K.scalp(s*(1.4+i*.18),.45+i*.2,.2); sw.push({r:q.r,d:[q.n[0]*.4,.25,-1],L:.8+i*.15,n:8,w0:.1,w1:.01,wave:.9,wph:i*2+s,droop:.2,stiff:.05,cols:hc}); }
    const hair2=K.makeHair(R.head,{mat:hm,grav:.25,drag:.93,wind:1.3,stiff:.05,wp:.9,strands:sw},R);
    const arcs=[]; for(let i=0;i<5;i++) arcs.push(K.makeArc(g,0xbff3ff,7));
    const em=[{ob:R.head,x:0,y:.35,z:0,r:.2},{ob:R.chest,x:.5,y:.45,z:0,r:.12},{ob:R.chest,x:-.5,y:.45,z:0,r:.12},{ob:R.hdL,x:0,y:-.05,z:0,r:.08},{ob:R.hdR,x:0,y:-.05,z:0,r:.08},{ob:R.chest,x:0,y:.15,z:-.25,r:.3},{ob:R.root,x:0,y:-.3,z:0,r:.3}];
    const sparks=K.makeAura(g,{n:44,color:pal.aura||[0xbff3ff,0xffffff,0xfff27a],vel:[0,0,0],jit:2.6,life:[.14,.38],size:[.1,.01],rate:34,drag:.9,op:1,emit:em,flick:true});
    const eg=[]; for(const s of [-1,1]){ const spr=K.glowSprite(R.head,pal.eye!=null?pal.eye:0xdff6ff,.34,s*.075,.12,.235,.9); eg.push({sp:spr,op:.9,s:.34,ph:s}); }
    const Pw={x:0,y:0,z:0}, Pw2={x:0,y:0,z:0}, La={x:0,y:0,z:0}, Lb={x:0,y:0,z:0}; let arcT=0;
    const ends=[[R.chest,.43,.32,0,R.hdL,0,-.06,0],[R.chest,-.43,.32,0,R.hdR,0,-.06,0],[R.head,0,.4,0,R.chest,.45,.4,0],[R.head,0,.4,0,R.chest,-.45,.4,0],[R.chest,0,.25,-.1,R.root,0,-.4,0]];
    return Game.VIPRun(c,{hairs:[hair,hair2],auras:[{o:sparks}],eyeGlow:eg,auraK:st=>.6+st.f*1.2+(st.act?1.6:0),
      tick(st,dt,time){ const hot=st.act?1:0, F=K.frame(g);
        for(const r of rings){ const sp=1.8+hot*4+st.f*2; r.m1.rotation.x=time*sp*r.s; r.m1.rotation.y=time*sp*.6; r.m2.rotation.z=time*sp*1.3; r.m2.rotation.x=time*sp*.7+1; }
        arcT-=dt; if(arcT<=0){ arcT=.05+Math.random()*.08; const chance=.14+hot*.55+st.f*.2; for(let i=0;i<arcs.length;i++){ const e=ends[i], on=Math.random()<chance*(i<2?1:.7); arcs[i].line.visible=on&&(!st.menu||Math.random()<.5);
            if(on){ K.wpos(e[0],e[1],e[2],e[3],Pw); K.wpos(e[4],e[5],e[6],e[7],Pw2); F.toL(Pw.x,Pw.y,Pw.z,La); F.toL(Pw2.x,Pw2.y,Pw2.z,Lb); arcs[i].set(La.x,La.y,La.z,Lb.x,Lb.y,Lb.z,.28); arcs[i].line.material.opacity=.55+Math.random()*.45; } } }
        const s=.55+.1*Math.sin(time*13)+(st.act?.25:0); reactor.scale.set(s,s,1); reactor.material.opacity=.55+.25*Math.sin(time*9); } }); } };

/* ================= SERAPH ================= */
Game.VIPB.seraph={
  mats(c){ const {M,pri,sec,trim,pal}=c;
    return {pri:M(pri,{roughness:.32,metalness:.28}),sec:M(sec,{roughness:.4,metalness:.5}),trim:keep(M(trim,{roughness:.18,metalness:1,emissive:pal.trimE||0x8a6a10,emissiveIntensity:.3})),skin:M("#f3d9c6",{roughness:.6}),dark:M("#3a2e22",{roughness:.7}),white:M("#ffffff",{roughness:.7}),
      arm:M(pri,{roughness:.5}),leg:M(pri,{roughness:.5}),tor:M(pri,{roughness:.32,metalness:.28}),hand:M("#f3d9c6",{roughness:.6}),boot:M(sec,{roughness:.35,metalness:.6})}; },
  build(c){ const {R,add,cl,CO,SP,CY,TO,B,grp,M,mats,fc,pal,mPri,mSec,mTrim,mGlow,mWhite,g,laserHex}=c;
    const gold=pal.glow||0xffe69a, goldM=basic({color:pal.halo!=null?pal.halo:0xffd34d},mats);
    /* hale */
    const halo=grp(R.head,0,.52,-.03); halo.rotation.x=.12; const hr=new THREE.Mesh(new THREE.TorusGeometry(.25,.019,8,40),goldM), hr2=new THREE.Mesh(new THREE.TorusGeometry(.2,.007,6,36),goldM); halo.add(hr); halo.add(hr2); const haloG=K.glowSprite(halo,gold,.9,0,0,0,.5);
    /* cüppe + kuşak */
    const robeM=M("#ffffff",{roughness:.7,metalness:.05,side:THREE.DoubleSide}), robe=add(R.root,CY(.27,.44,.64,20),robeM,0,-.32,0,0,0,0,1,1,.85);
    add(R.root,TO(.43,.02,6,30),mTrim,0,-.62,0,PI/2); add(R.root,TO(.34,.012,6,28),mTrim,0,-.5,0,PI/2); cl(R.root,mTrim,0,.05,0,.62,.08,.37); cl(R.root,mSec,0,-.02,.2,.1,.5,.02,0,0,0);
    cl(R.chest,mPri,0,.12,.215,.66,.4,.04); cl(R.chest,mTrim,0,.3,.236,.62,.035,.015);
    const sun=grp(R.chest,0,.19,.245); add(sun,SP(.065,10,8),mGlow,0,0,0); for(let i=0;i<10;i++){ const a=i/10*PI*2; add(sun,B(.014,.08,.01),mTrim,-Math.sin(a)*.115,Math.cos(a)*.115,0,0,0,a); } const sunG=K.glowSprite(R.chest,laserHex,.55,0,.19,.29,.55);
    for(const s of [-1,1]){ const el=s<0?R.elL:R.elR, kn=s<0?R.knL:R.knR;
      add(R.chest,SP(.17,12,8),mTrim,s*.45,.37,0,0,0,0,1,.75,1.1); add(R.chest,SP(.12,10,8),mPri,s*.47,.43,0,0,0,0,1,.7,1);
      add(el,CY(.085,.068,.22,10),mSec,0,-.15,0); add(el,TO(.083,.012,6,12),mTrim,0,-.06,0,PI/2); add(el,TO(.07,.012,6,12),mTrim,0,-.25,0,PI/2);
      add(kn,CY(.09,.074,.13,10),mSec,0,-.34,0); add(kn,TO(.088,.012,6,12),mTrim,0,-.3,0,PI/2); cl(s<0?R.ftL:R.ftR,mTrim,0,-.04,.2,.12,.03,.1); }
    /* tüylü kanatlar */
    const fm=(col,em)=>{ const m=M(col,{roughness:.45,metalness:.08,side:THREE.DoubleSide,emissive:pal.glow||0xffe69a,emissiveIntensity:em}); m.vertexColors=true; return keep(m); };
    const wm1=fm(pal.wing1||"#ffffff",.16), wm2=fm(pal.wing2||"#fff6e8",.14), wm3=fm(pal.wing3||"#ffffff",.12), tipT=pal.wingTip;
    const spec={mat:wm1,layers:[
      {n:11,len:[.55,1.4],wid:.5,base:[.12,.2,.64,.64],open:[-.95,.72],fold:[-1.78,-1.46],z:-.02,mat:wm1,peak:.5,ph:.3},
      {n:10,len:[.4,.98],wid:.56,base:[.1,.22,.6,.62],open:[-.82,.78],fold:[-1.72,-1.44],z:.016,mat:wm2,peak:.5,ph:.3},
      {n:9,len:[.22,.52],wid:.76,base:[.08,.24,.56,.6],open:[-.7,.84],fold:[-1.66,-1.4],z:.036,mat:wm3,peak:.5,ph:.3,lag:.6}]};
    const wings=[]; for(const s of [-1,1]){ const mt=grp(R.chest,s*.2,.3,-.24), w=K.makeWing(s,spec); mt.add(w.root); wings.push(w); }
    /* saç + kuşak şeritleri + omuz şalı */
    const hc=pal.hair||[[1,.96,.72],[1,.78,.32]], mh=M("#ffffff",{roughness:.3,metalness:.25,side:THREE.DoubleSide,emissive:pal.hairE||0x5a3c00,emissiveIntensity:.3}); mh.vertexColors=true; keep(mh);
    const hs=fan({count:22,az0:2.1,az1:PI*2-2.1,el0:-.05,el1:.9,L0:.6,L1:1.0,n:11,w0:.12,w1:.04,droop:.5,wave:.45,out:.3,down:1,dz:-.35,stiff:.045,seed:4,cols:hc}), side=fan({count:12,az0:.45,az1:PI*2-.45,el0:.15,el1:.9,L0:.22,L1:.38,n:6,w0:.08,w1:.035,droop:.9,wave:.25,out:.6,down:.8,stiff:.05,seed:14,cols:hc}).filter(s=>Math.abs(Math.sin(Math.atan2(s.r[0],s.r[2])))>.55&&s.r[2]>-.05);
    const bang=fan({count:6,az0:-.55,az1:.55,el0:.85,el1:1.1,L0:.2,L1:.32,n:5,w0:.09,w1:.03,droop:1.4,dz:.45,out:.5,stiff:.05,seed:8,cols:hc});
    const hair=K.makeHair(R.head,{mat:mh,grav:.5,drag:.93,wind:.7,stiff:.04,tip:1.1,wp:.8,colliders:[["head",0,.1,0,.205,.22,.205],["chest",0,0,-.05,.46,.5,.28]],strands:hs},R), hair2=K.makeHair(R.head,{mat:mh,grav:.5,drag:.93,wind:.7,stiff:.05,tip:1.1,wp:.8,colliders:[["head",0,.1,0,.205,.22,.205]],strands:side.concat(bang)},R);
    const sash=[]; for(const s of [-1,1]) for(let i=0;i<2;i++) sash.push({r:[s*(.22+i*.07),-.02,.12-i*.3],d:[s*.5,-1,0],L:.5+i*.16,n:8,w0:.13,w1:.1,wave:.3,wph:i*2+s,stiff:.045,cols:[[1,.85,.4],[1,.95,.75]]});
    const ribM=M("#ffffff",{roughness:.4,metalness:.3,side:THREE.DoubleSide,emissive:0x5a3c00,emissiveIntensity:.2}); ribM.vertexColors=true;
    const sashH=K.makeHair(R.root,{mat:ribM,grav:.8,drag:.93,wind:.6,stiff:.04,colliders:[["root",0,-.02,0,.32,.12,.2],["hpL",0,-.21,0,.12,.25,.12],["hpR",0,-.21,0,.12,.25,.12]],strands:sash},R);
    const man=[]; for(const s of [-1,1]) man.push({r:[s*.3,.46,-.12],d:[s*.3,-.5,-1],L:1.0,n:10,w0:.2,w1:.12,wave:.3,wph:s,stiff:.03,cols:[[1,1,1],[1,.93,.78]]});
    const manH=K.makeHair(R.chest,{mat:ribM,grav:.4,drag:.94,wind:.9,stiff:.03,colliders:[["chest",0,.13,-.01,.42,.3,.24]],strands:man},R);
    const ac=pal.aura||[0xfff0b0,0xffffff,0xffd34d];
    const em=[{ob:R.chest,x:.8,y:.7,z:-.25,r:.3},{ob:R.chest,x:-.8,y:.7,z:-.25,r:.3},{ob:R.head,x:0,y:.35,z:0,r:.25},{ob:R.chest,x:0,y:.2,z:0,r:.5},{ob:R.hdL,x:0,y:-.05,z:0,r:.06},{ob:R.hdR,x:0,y:-.05,z:0,r:.06}];
    const motes=K.makeAura(g,{n:40,color:ac,vel:[0,.14,0],jit:.4,up:.2,life:[1.6,3.2],size:[.09,.02],rate:16,grav:.04,drag:.98,swirl:.7,op:.95,emit:em,flick:true});
    const eg=[]; for(const s of [-1,1]){ const spr=K.glowSprite(R.head,pal.eye!=null?pal.eye:0xfff6c0,.32,s*.075,.12,.235,.85); eg.push({sp:spr,op:.85,s:.32,ph:s}); }
    const ws={spread:.1,flap:-.2,sweep:0,fl:.02}; let stretchT=7+Math.random()*5, stretch=0;
    function poseWings(dt,time){ for(const w of wings) w.pose(ws.spread,ws.flap,ws.sweep,ws.fl,time,dt); }
    return Game.VIPRun(c,{hairs:[hair,hair2,sashH,manH],auras:[{o:motes}],eyeGlow:eg,auraK:st=>.8+st.f*.8+(st.act?1.4:0),
      rest(){ ws.spread=.35; ws.flap=.05; ws.sweep=.1; ws.fl=0; poseWings(.016,0); },
      reset(){ ws.spread=.1; ws.flap=-.2; ws.sweep=0; },
      tick(st,dt,time){ let tS,tF,tW,fl=.02;
        if(st.menu){ tS=.82; tF=.14+Math.sin(time*1.15)*.13; tW=.12; fl=.025; }
        else if(st.sp>.25){ tS=1; tF=.15+Math.sin(time*1.6)*.35; tW=.1; fl=.03; }
        else if(st.fly){ const f=st.f, fr=lerp(1.6,4.6,f)*(st.boost?1.6:1), amp=lerp(.6,.1,f); tS=lerp(1,.82,f); tF=.12+Math.sin(time*fr*PI*2)*amp-(st.boost?.25:0); tW=lerp(.08,.95,f); fl=.035+.05*f; }
        else if(!st.grounded&&st.vy<-6){ tS=.95; tF=.6+Math.sin(time*17)*.12; tW=-.15; fl=.09; }
        else if(!st.grounded&&st.vy>3){ tS=.78; tF=.45; tW=0; fl=.04; }
        else { stretchT-=dt; if(stretchT<0){ stretch=1; stretchT=11+Math.random()*8; } stretch=Math.max(0,stretch-dt*.5); const sk=Math.sin(stretch*PI);
          tS=.1+.9*sk+Math.min(.25,st.hv*.03); tF=-.25+.5*sk+Math.sin(time*1.4)*.03; tW=.22*sk; fl=.012+.02*sk; if(st.land>.02){ tS=.88; tF=.5*st.land+.1; } }
        const k=1-Math.exp(-dt*(st.fly||st.land>.02?12:6)); ws.spread+=(tS-ws.spread)*k; ws.flap+=(tF-ws.flap)*(st.fly?1-Math.exp(-dt*30):k); ws.sweep+=(tW-ws.sweep)*k; ws.fl=fl;
        poseWings(dt,time);
        halo.position.y=.52+Math.sin(time*1.6)*.02; halo.rotation.y=time*.9; halo.rotation.z=Math.sin(time*1.1)*.05; haloG.material.opacity=.4+.12*Math.sin(time*2.4)+(st.act?.25:0); sunG.material.opacity=.45+.12*Math.sin(time*3.1)+(st.act?.3:0); sun.rotation.z=time*.5; } }); } };

Object.assign(CHARS,{
  frost:{vip:true,icon:"❄",laser:0x6fe0ff,eye:0xaef4ff,accent:"#bfe3ff",cape:{w:.92,h:1.4,cols:8,rows:13,ay:.35,az:-.2,make:capeMat("frost")},
    skins:[["#cfeaff","#2f5c9a","#f4f9ff","#bfe3ff",5,{eye:0xaef4ff,laser:0x6fe0ff,glow:0x58b0ff,flake:0x9fe0ff,hair:[[.94,.98,1],[.45,.75,1]],aura:[0xdff6ff,0xaee8ff,0xffffff],cape:{a:"#6fa8dc",b:"#bfe3ff",c:"#f6fdff"}}],
           ["#d9fff0","#3a2a8a","#ffd9ff","#b9ffd8",5,{eye:0xcaffd8,laser:0x7affc0,glow:0x7affc0,flake:0xb8ffe0,shard:"#c9ffe6",hair:[[.82,1,.92],[.68,.42,1]],hairE:0x1c4a3a,aura:[0xd8ffee,0xb8a8ff,0xffffff],cape:{a:"#3a2a8a",b:"#7fd8b8",c:"#e8fff4"}}]]},
  storm:{vip:true,icon:"ϟ",laser:0xfff27a,eye:0xdff6ff,accent:"#1a2a78",cape:{w:.88,h:1.22,cols:8,rows:11,ay:.35,az:-.2,make:capeMat("storm")},
    skins:[["#1a2442","#0d1630","#ffd84a","#1a2a78",2,{eye:0xdff6ff,laser:0xfff27a,glow:0x6fd8ff,trimE:0x6a5000,hair:[[1,1,.78],[1,.85,.2]],aura:[0xbff3ff,0xffffff,0xfff27a],cape:{a:"#0b1030",b:"#1a2a78",c:"#2f6bff"}}],
           ["#2a1445","#150a28","#ff5cf0","#5b1f9a",2,{eye:0xffe0ff,laser:0xff7cf6,glow:0xff7cf6,trimE:0x6a1060,hair:[[1,.88,1],[.85,.3,1]],aura:[0xffc8fa,0xffffff,0xc77cff],cape:{a:"#160a30",b:"#5b1f9a",c:"#d04cff",bolt:"rgba(255,170,250,.95)"}}]]},
  seraph:{vip:true,icon:"✦",laser:0xfff0a0,eye:0xfff6c0,accent:"#ffd34d",cape:null,
    skins:[["#fff6e0","#e9c46a","#ffd34d","#ffffff",5,{eye:0xfff6c0,laser:0xfff0a0,glow:0xffe69a,halo:0xffd34d,hair:[[1,.96,.72],[1,.78,.32]],aura:[0xfff0b0,0xffffff,0xffd34d]}],
           ["#f4f1ff","#c7b9ff","#e9e9f5","#ffffff",5,{eye:0xf0e6ff,laser:0xd9c6ff,glow:0xd9c6ff,halo:0xe6e0ff,trimE:0x40407a,hair:[[.97,.9,1],[.85,.6,1]],hairE:0x3a1a5a,aura:[0xe9dcff,0xffffff,0xc7b9ff],wing1:"#f4f0ff",wing2:"#efe6ff",wing3:"#ffffff"}]]}
});
})();
