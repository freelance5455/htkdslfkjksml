"use strict";
/* ===== VIP KİT: fizikli saç/dokunaç şeritleri (Verlet + "lider takip"), tüylü kanat, aura parçacıkları, pelerin dokuları ===== */
Game.VIPKit=(function(){
  const clamp=(v,a,b)=>v<a?a:v>b?b:v, sm=(a,b,x)=>{ const t=clamp((x-a)/(b-a),0,1); return t*t*(3-2*t); }, PI=Math.PI;
  /* ---------- 4x4 (sütun-ana) matris yardımcıları: nesne zincirinden dünya matrisi (three'nin matrixWorld durumundan bağımsız) ---------- */
  const m4=()=>new Float64Array(16), TA=m4(), TB=m4(), R1=m4(), R2=m4(), R3=m4();
  const ident=o=>{ o.fill(0); o[0]=o[5]=o[10]=o[15]=1; return o; };
  function mul(o,a,b){ for(let c=0;c<4;c++){ const b0=b[c*4],b1=b[c*4+1],b2=b[c*4+2],b3=b[c*4+3]; for(let r=0;r<4;r++) o[c*4+r]=a[r]*b0+a[4+r]*b1+a[8+r]*b2+a[12+r]*b3; } return o; }
  const RX=(o,t)=>{ ident(o); const c=Math.cos(t),s=Math.sin(t); o[5]=c;o[6]=s;o[9]=-s;o[10]=c; return o; }, RY=(o,t)=>{ ident(o); const c=Math.cos(t),s=Math.sin(t); o[0]=c;o[2]=-s;o[8]=s;o[10]=c; return o; }, RZ=(o,t)=>{ ident(o); const c=Math.cos(t),s=Math.sin(t); o[0]=c;o[1]=s;o[4]=-s;o[5]=c; return o; };
  function localM(ob,out){ const p=ob.position, r=ob.rotation, s=ob.scale, ord=r.order||"XYZ"; ident(R1);
    for(let q=0;q<3;q++){ const ch=ord[q]; (ch==="X"?RX:ch==="Y"?RY:RZ)(R2,ch==="X"?r.x:ch==="Y"?r.y:r.z); mul(R3,R1,R2); R1.set(R3); }
    for(let i=0;i<3;i++){ out[i]=R1[i]*s.x; out[4+i]=R1[4+i]*s.y; out[8+i]=R1[8+i]*s.z; } out[3]=out[7]=out[11]=0; out[12]=p.x; out[13]=p.y; out[14]=p.z; out[15]=1; return out; }
  const CHN=[];
  function worldM(ob,out){ CHN.length=0; for(let q=ob;q;q=q.parent) CHN.push(q); ident(out); for(let i=CHN.length-1;i>=0;i--){ localM(CHN[i],TA); mul(TB,out,TA); out.set(TB); } return out; }
  /* çerçeve: dünya matrisi + (tek tip ölçekli rijit) ters dönüşümler */
  function frame(ob){ const M=worldM(ob,m4()), s=Math.hypot(M[0],M[1],M[2])||1, s2=s*s; return {M,s,
    toW(x,y,z,o){ o.x=M[0]*x+M[4]*y+M[8]*z+M[12]; o.y=M[1]*x+M[5]*y+M[9]*z+M[13]; o.z=M[2]*x+M[6]*y+M[10]*z+M[14]; return o; },
    dirW(x,y,z,o){ o.x=(M[0]*x+M[4]*y+M[8]*z)/s; o.y=(M[1]*x+M[5]*y+M[9]*z)/s; o.z=(M[2]*x+M[6]*y+M[10]*z)/s; return o; },
    toL(x,y,z,o){ const dx=x-M[12], dy=y-M[13], dz=z-M[14]; o.x=(M[0]*dx+M[1]*dy+M[2]*dz)/s2; o.y=(M[4]*dx+M[5]*dy+M[6]*dz)/s2; o.z=(M[8]*dx+M[9]*dy+M[10]*dz)/s2; return o; },
    dirL(x,y,z,o){ o.x=(M[0]*x+M[1]*y+M[2]*z)/s; o.y=(M[4]*x+M[5]*y+M[6]*z)/s; o.z=(M[8]*x+M[9]*y+M[10]*z)/s; return o; } }; }
  const wpos=(ob,x,y,z,o)=>{ const F=frame(ob); return F.toW(x,y,z,o||{x:0,y:0,z:0}); };
  /* ---------- parıltı dokusu + sprite ---------- */
  let glowT=null; const glowTex=()=>glowT||(glowT=(()=>{ const c=document.createElement("canvas"); c.width=c.height=64; const q=c.getContext("2d"), g=q.createRadialGradient(32,32,0,32,32,32); g.addColorStop(0,"rgba(255,255,255,1)"); g.addColorStop(.28,"rgba(255,255,255,.6)"); g.addColorStop(1,"rgba(255,255,255,0)"); q.fillStyle=g; q.fillRect(0,0,64,64); return new THREE.CanvasTexture(c); })());
  function glowSprite(parent,hex,s,x,y,z,op,blend){ const m=new THREE.Sprite(new THREE.SpriteMaterial({map:glowTex(),color:hex,transparent:true,opacity:op==null?1:op,blending:blend===false?THREE.NormalBlending:THREE.AdditiveBlending,depthWrite:false,fog:false})); m.scale.set(s,s,1); m.position.set(x||0,y||0,z||0); m.renderOrder=7; if(parent) parent.add(m); return m; }
  const norm=a=>{ const l=Math.hypot(a[0],a[1],a[2])||1; return [a[0]/l,a[1]/l,a[2]/l]; };
  /* kafa derisi: azimut az (0 = ön +z, π = arka), yükseklik el → kök noktası + dış normal. Kafa: r=.2, merkez y=.1 */
  function scalp(az,el,rr){ rr=rr==null?.2:rr; const ce=Math.cos(el), n=[Math.sin(az)*ce,Math.sin(el),Math.cos(az)*ce]; return {r:[n[0]*rr,.1+n[1]*rr*1.06,n[2]*rr],n}; }
  /* ---------- şerit saç / dokunaç / kumaş şeridi ----------
     spec: {strands:[{r:[x,y,z], d:[x,y,z], L, n, w0, w1, sd:[x,y,z], droop, wave, wph, stiff, cols:[[r,g,b],[r,g,b]]}], mat, grav, buoy, drag, wind, stiff, tip, wp, colliders:[[boneName,cx,cy,cz,rx,ry,rz],…], order} */
  const EL_DEFAULT=[["head",0,.1,0,.205,.22,.205],["chest",0,.13,-.01,.44,.3,.25],["spine",0,.14,0,.34,.2,.22]];
  function makeHair(frameObj,spec,rig){
    const S=spec.strands, NS=S.length; let rings=0; for(const s of S) rings+=s.n+1;
    const RP=[], PW=[], QW=[], SDL=[];
    for(let i=0;i<NS;i++){ const s=S[i], n=s.n, d=norm(s.d), rp=new Float32Array((n+1)*3), segL=s.L/n; let sd=s.sd?norm(s.sd):null;
      if(!sd){ sd=Math.abs(d[1])>.9?[1,0,0]:norm([d[2],0,-d[0]]); } SDL.push(sd);
      let x=s.r[0], y=s.r[1], z=s.r[2], dx=d[0], dy=d[1], dz=d[2];
      for(let k=0;k<=n;k++){ rp[k*3]=x; rp[k*3+1]=y; rp[k*3+2]=z; const f=k/n, dr=(s.droop||0)*(.15+f), wv=(s.wave||0)*Math.sin(f*5.2+(s.wph||0));
        let ex=d[0]+sd[0]*wv, ey=d[1]-dr+sd[1]*wv, ez=d[2]+sd[2]*wv; const l=Math.hypot(ex,ey,ez)||1; dx+=(ex/l-dx)*.55; dy+=(ey/l-dy)*.55; dz+=(ez/l-dz)*.55; const ll=Math.hypot(dx,dy,dz)||1; dx/=ll; dy/=ll; dz/=ll;
        x+=dx*segL; y+=dy*segL; z+=dz*segL; }
      RP.push(rp); PW.push(new Float64Array((n+1)*3)); QW.push(new Float64Array((n+1)*3)); }
    const pos=new Float32Array(rings*2*3), nor=new Float32Array(rings*2*3), uv=new Float32Array(rings*2*2), colA=new Float32Array(rings*2*3), idx=[];
    let o=0; for(let i=0;i<NS;i++){ const n=S[i].n, cc=S[i].cols||spec.cols||[[1,1,1],[1,1,1]], a=cc[0], b=cc[1];
      for(let k=0;k<=n;k++){ const f=k/n, v=(o+k)*2, t=Math.pow(f,spec.tip||1); uv[v*2]=0; uv[v*2+1]=f; uv[v*2+2]=1; uv[v*2+3]=f;
        for(let j=0;j<2;j++){ const c=(v+j)*3; colA[c]=a[0]+(b[0]-a[0])*t; colA[c+1]=a[1]+(b[1]-a[1])*t; colA[c+2]=a[2]+(b[2]-a[2])*t; } }
      for(let k=0;k<n;k++){ const a0=(o+k)*2, b0=(o+k+1)*2; idx.push(a0,a0+1,b0, a0+1,b0+1,b0); } o+=n+1; }
    const geo=new THREE.BufferGeometry(); geo.setAttribute("position",new THREE.BufferAttribute(pos,3)); geo.setAttribute("normal",new THREE.BufferAttribute(nor,3)); geo.setAttribute("uv",new THREE.BufferAttribute(uv,2)); geo.setAttribute("color",new THREE.BufferAttribute(colA,3)); geo.setIndex(new THREE.BufferAttribute(new Uint16Array(idx),1));
    const mesh=new THREE.Mesh(geo,spec.mat); mesh.frustumCulled=false; mesh.castShadow=false; if(spec.order!=null) mesh.renderOrder=spec.order; frameObj.add(mesh);
    const tmp={x:0,y:0,z:0}, tmp2={x:0,y:0,z:0}, tw={x:0,y:0,z:0}, sdW={x:0,y:0,z:0}, sphL={x:0,y:0,z:0}, sph={x:0,y:0,z:0}, lastRoot={x:1e9,y:0,z:0}, wpv=spec.wp||1;
    let init=false, tt=Math.random()*10;
    function output(F){ let base=0;
      for(let i=0;i<NS;i++){ const s=S[i], n=s.n, P=PW[i], sd=SDL[i];
        for(let k=0;k<=n;k++){ const k0=Math.max(0,k-1), k2=Math.min(n,k+1); let tx=P[k2*3]-P[k0*3], ty=P[k2*3+1]-P[k0*3+1], tz=P[k2*3+2]-P[k0*3+2]; const tl=Math.hypot(tx,ty,tz)||1; tx/=tl; ty/=tl; tz/=tl;
          F.dirW(sd[0],sd[1],sd[2],sdW); const dp=sdW.x*tx+sdW.y*ty+sdW.z*tz; let wx=sdW.x-tx*dp, wy=sdW.y-ty*dp, wz=sdW.z-tz*dp, wl=Math.hypot(wx,wy,wz);
          if(wl<.15){ wx=-tz; wy=0; wz=tx; wl=Math.hypot(wx,wy,wz); if(wl<.05){ wx=1; wy=0; wz=0; wl=1; } } wx/=wl; wy/=wl; wz/=wl;
          const f=k/n, hw=(s.w0+(s.w1-s.w0)*Math.pow(f,wpv))*.5;
          F.toL(P[k*3],P[k*3+1],P[k*3+2],tmp); F.dirL(wx,wy,wz,tmp2); const v=(base+k)*6;
          pos[v]=tmp.x+tmp2.x*hw; pos[v+1]=tmp.y+tmp2.y*hw; pos[v+2]=tmp.z+tmp2.z*hw; pos[v+3]=tmp.x-tmp2.x*hw; pos[v+4]=tmp.y-tmp2.y*hw; pos[v+5]=tmp.z-tmp2.z*hw;
          F.dirL(ty*wz-tz*wy,tz*wx-tx*wz,tx*wy-ty*wx,tw); const nl=Math.hypot(tw.x,tw.y,tw.z)||1; for(let j=0;j<2;j++){ nor[v+j*3]=tw.x/nl; nor[v+j*3+1]=tw.y/nl; nor[v+j*3+2]=tw.z/nl; } }
        base+=n+1; }
      geo.attributes.position.needsUpdate=true; geo.attributes.normal.needsUpdate=true; }
    function reset(F){ for(let i=0;i<NS;i++){ const n=S[i].n, rp=RP[i], P=PW[i], Q=QW[i]; for(let k=0;k<=n;k++){ F.toW(rp[k*3],rp[k*3+1],rp[k*3+2],tmp); P[k*3]=Q[k*3]=tmp.x; P[k*3+1]=Q[k*3+1]=tmp.y; P[k*3+2]=Q[k*3+2]=tmp.z; } } init=true; }
    const cols=spec.colliders===false?[]:(spec.colliders||EL_DEFAULT), colF=[];
    function step(dt,time,wind,F,calm){
      const Hh=Game.H, gs=Hh&&Hh.gscale!==undefined?Hh.gscale:1, k60=Math.min(3,dt*60), damp=Math.pow(spec.drag||.92,k60), g=9.8*gs*(spec.grav==null?1:spec.grav), wnd=calm?0:(spec.wind||0)*dt*dt*60;
      colF.length=0; if(rig){ for(const e of cols){ const ob=rig[e[0]]; if(ob) colF.push({F:frame(ob),e}); } }
      for(let i=0;i<NS;i++){ const s=S[i], n=s.n, P=PW[i], Q=QW[i], rp=RP[i], segW=s.L/n*F.s, st=(s.stiff!=null?s.stiff:(spec.stiff==null?.05:spec.stiff)), ph=s.wph||0;
        F.toW(rp[0],rp[1],rp[2],tmp); P[0]=Q[0]=tmp.x; P[1]=Q[1]=tmp.y; P[2]=Q[2]=tmp.z;
        for(let k=1;k<=n;k++){ const a=k*3, f=k/n; const vx=(P[a]-Q[a])*damp, vy=(P[a+1]-Q[a+1])*damp, vz=(P[a+2]-Q[a+2])*damp; Q[a]=P[a]; Q[a+1]=P[a+1]; Q[a+2]=P[a+2];
          let px=P[a]+vx, py=P[a+1]+vy-g*dt*dt, pz=P[a+2]+vz;
          if(wnd){ const w=(.3+f)*wnd; px+=Math.sin(tt*3.1+k*.9+ph*3)*w; py+=Math.sin(tt*2.7+k*1.3+ph)*w*.7; pz+=Math.cos(tt*2.3+k*1.1+ph)*w; }
          if(wind){ const w=f*dt*dt*60; px+=wind.x*w; py+=wind.y*w; pz+=wind.z*w; }
          F.toW(rp[a],rp[a+1],rp[a+2],tmp); const sk=st*(1-f*.7)*Math.min(1,k60); px+=(tmp.x-px)*sk; py+=(tmp.y-py)*sk; pz+=(tmp.z-pz)*sk; P[a]=px; P[a+1]=py; P[a+2]=pz; }
        /* kısıtlar: elipsoit/kutu çarpışma + uzunluk (3 tur, son işlem uzunluk → boy her zaman tam) */
        for(let it=0;it<3;it++){
          if(colF.length) for(let k=1;k<=n;k++){ const a=k*3; let px=P[a], py=P[a+1], pz=P[a+2];
            for(let q=0;q<colF.length;q++){ const c=colF[q], e=c.e; c.F.toL(px,py,pz,sphL);
              if(e[7]==="zbox"){ const dx=sphL.x-e[1], dy=sphL.y-e[2], dz=sphL.z-e[3]; if(Math.abs(dx)<e[4]&&Math.abs(dy)<e[5]&&Math.abs(dz)<e[6]){ c.F.toW(sphL.x,sphL.y,e[3]-e[6],sph); px=sph.x; py=sph.y; pz=sph.z; } continue; }
              if(e[7]==="box"){ const dx=sphL.x-e[1], dy=sphL.y-e[2], dz=sphL.z-e[3], ax=e[4]-Math.abs(dx), ay=e[5]-Math.abs(dy), az=e[6]-Math.abs(dz);
                if(ax>0&&ay>0&&az>0){ let lx=sphL.x, ly=sphL.y, lz=sphL.z; if(az<=ax&&az<=ay) lz=e[3]+(dz<0?-e[6]:e[6]); else if(ax<=ay) lx=e[1]+(dx<0?-e[4]:e[4]); else ly=e[2]+(dy<0?-e[5]:e[5]); c.F.toW(lx,ly,lz,sph); px=sph.x; py=sph.y; pz=sph.z; } continue; }
              const qx=(sphL.x-e[1])/e[4], qy=(sphL.y-e[2])/e[5], qz=(sphL.z-e[3])/e[6], d=Math.hypot(qx,qy,qz);
              if(d<1&&d>1e-4){ c.F.toW(e[1]+qx/d*e[4],e[2]+qy/d*e[5],e[3]+qz/d*e[6],sph); px=sph.x; py=sph.y; pz=sph.z; } }
            P[a]=px; P[a+1]=py; P[a+2]=pz; }
          for(let k=1;k<=n;k++){ const a=k*3, b=a-3; const dx=P[a]-P[b], dy=P[a+1]-P[b+1], dz=P[a+2]-P[b+2], l=Math.hypot(dx,dy,dz)||1e-6, r=segW/l; P[a]=P[b]+dx*r; P[a+1]=P[b+1]+dy*r; P[a+2]=P[b+2]+dz*r; } } } }
    function update(dt,time,wind){ dt=clamp(dt||.016,.001,.05); tt+=dt; const F=frame(frameObj), Hh=Game.H;
      F.toW(S[0].r[0],S[0].r[1],S[0].r[2],tmp); const sp=Hh&&Game.mode==="play"?(Hh.speed||0):0, jump=Math.hypot(tmp.x-lastRoot.x,tmp.y-lastRoot.y,tmp.z-lastRoot.z); lastRoot.x=tmp.x; lastRoot.y=tmp.y; lastRoot.z=tmp.z;
      if(!init||jump>sp*dt*2+4+(Hh&&Hh.sp>.3?60:0)) reset(F);
      const sub=sp*dt>1.2?2:1; for(let q=0;q<sub;q++) step(dt/sub,time,wind,F); output(F); }
    function rest(settle){ const F=frame(frameObj); reset(F); for(let q=0;q<(settle||0);q++) step(1/60,0,null,F,true); output(F); }
    return {mesh,geo,update,rest,reset:()=>{ init=false; },strands:S,rp:RP};
  }
  /* ---------- tüy + kanat ---------- */
  let featherG=null;
  function featherGeo(){ if(featherG) return featherG; const T=[0,.08,.26,.5,.74,.9,1], W=[.012,.05,.085,.1,.082,.042,0], P=[], I=[], C=[];
    for(let i=0;i<T.length;i++){ const t=T[i], w=W[i], cz=-.05*t*t, ct=t*t; P.push(t,w,cz, t,-w,cz); C.push(1,1-.14*ct,1-.5*ct, 1,1-.14*ct,1-.5*ct); }
    for(let i=0;i<T.length-1;i++){ const a=i*2; I.push(a,a+1,a+2, a+1,a+3,a+2); }
    const g=new THREE.BufferGeometry(); g.setAttribute("position",new THREE.BufferAttribute(new Float32Array(P),3)); g.setAttribute("color",new THREE.BufferAttribute(new Float32Array(C),3)); g.setIndex(new THREE.BufferAttribute(new Uint16Array(I),1)); if(g.computeVertexNormals) g.computeVertexNormals(); return (featherG=g); }
  /* kanat: spec {mat, layers:[{n,len:[a,b],wid,base:[x0,y0,x1,y1],open:[a0,a1],fold:[b0,b1],z,mat,peak,ph,lag}]}  s=+1 sağ, -1 sol. Açı z ekseni etrafında: 0=+x (dışarı), +π/2=yukarı */
  function makeWing(s,spec){ const root=new THREE.Group(), feathers=[], fg=featherGeo();
    for(const L of spec.layers){ for(let i=0;i<L.n;i++){ const f=L.n>1?i/(L.n-1):0, piv=new THREE.Group(), m=new THREE.Mesh(fg,L.mat||spec.mat); m.castShadow=false;
        const ln=L.len[0]+(L.len[1]-L.len[0])*Math.sin(f*PI*(L.peak||.8)+(L.ph||.2)), wd=L.wid*(.85+.3*Math.sin(f*PI)); m.scale.set(ln,ln*wd*2.2,1);
        piv.position.set(s*(L.base[0]+(L.base[2]-L.base[0])*f),L.base[1]+(L.base[3]-L.base[1])*f,L.z+(i%2?.012:0)); piv.add(m); root.add(piv);
        feathers.push({piv,mesh:m,open:L.open[0]+(L.open[1]-L.open[0])*f,fold:L.fold[0]+(L.fold[1]-L.fold[0])*f,f,lag:L.lag==null?1:L.lag}); } }
    let prevFlap=0, vel=0;
    function pose(spread,flap,sweep,flutter,time,dt){ /* spread 0..1 (katlı → açık), flap: kol z açısı, sweep: arkaya süpürme */
      const d=Math.max(dt||.016,.001); root.rotation.z=s*flap; root.rotation.y=-s*sweep; vel+=((flap-prevFlap)/d-vel)*Math.min(1,d*14); prevFlap=flap;
      for(const F of feathers){ const a=F.fold+(F.open-F.fold)*spread, lag=clamp(-vel*.035*F.f*F.lag,-.7,.7)+Math.sin(time*(9+F.f*7)+F.f*6)*flutter*(.4+F.f), ang=a+lag;
        F.piv.rotation.z=s>0?ang:PI-ang; F.piv.rotation.x=s*(1-spread)*.18*(.5-F.f)+Math.sin(time*5+F.f*9)*flutter*.4; } }
    return {root,pose,feathers}; }
  /* ---------- aura parçacıkları (model çocuğu sprite havuzu, dünya uzayında hareket) ---------- */
  function makeAura(root,spec){ const n=spec.n, ps=[], tex=spec.tex||glowTex(), tmp={x:0,y:0,z:0}, tmpL={x:0,y:0,z:0};
    for(let i=0;i<n;i++){ const sp=new THREE.Sprite(new THREE.SpriteMaterial({map:tex,color:spec.color[0],transparent:true,opacity:0,blending:spec.add===false?THREE.NormalBlending:THREE.AdditiveBlending,depthWrite:false,fog:false})); sp.renderOrder=spec.order||7; sp.visible=false; root.add(sp);
      ps.push({sp,life:0,ml:1,x:0,y:0,z:0,vx:0,vy:0,vz:0,s0:1,s1:1,c:0,fs:1}); }
    let acc=0, cur=0;
    function spawn(p,em){ const e=em[(Math.random()*em.length)|0], EF=frame(e.ob); EF.toW(e.x+(Math.random()-.5)*(e.r||0)*2,e.y+(Math.random()-.5)*(e.r||0)*2,e.z+(Math.random()-.5)*(e.r||0)*2,tmp);
      p.x=tmp.x; p.y=tmp.y; p.z=tmp.z; const v=spec.vel, j=spec.jit||0; p.fs=EF.s; p.vx=(v[0]+(Math.random()-.5)*j)*p.fs; p.vy=(v[1]+(Math.random()-.5)*j+Math.random()*(spec.up||0))*p.fs; p.vz=(v[2]+(Math.random()-.5)*j)*p.fs;
      p.ml=p.life=spec.life[0]+Math.random()*(spec.life[1]-spec.life[0]); p.s0=spec.size[0]*(.7+Math.random()*.6); p.s1=spec.size[1]*(.7+Math.random()*.6); p.c=(Math.random()*spec.color.length)|0; p.sp.material.color.setHex(spec.color[p.c]); p.sp.visible=true; }
    function update(dt,inten,emit){ const F=frame(root), em=emit||spec.emit; acc+=dt*spec.rate*inten;
      while(acc>=1){ acc-=1; for(let q=0;q<n;q++){ const p=ps[(cur+q)%n]; if(p.life<=0){ cur=(cur+q+1)%n; spawn(p,em); break; } } }
      const gs=Game.H&&Game.H.gscale!==undefined?Game.H.gscale:1;
      for(const p of ps){ if(p.life<=0){ if(p.sp.visible) p.sp.visible=false; continue; } p.life-=dt; const k=1-clamp(p.life/p.ml,0,1);
        p.vy+=(spec.grav||0)*gs*dt*p.fs; const dm=Math.pow(spec.drag||.98,dt*60); p.vx*=dm; p.vy*=dm; p.vz*=dm; if(spec.swirl){ p.vx+=Math.sin(k*9+p.c*2+p.ml*3)*spec.swirl*dt*p.fs; p.vz+=Math.cos(k*8+p.c*3+p.ml*2)*spec.swirl*dt*p.fs; }
        p.x+=p.vx*dt; p.y+=p.vy*dt; p.z+=p.vz*dt; F.toL(p.x,p.y,p.z,tmpL); p.sp.position.set(tmpL.x,tmpL.y,tmpL.z);
        const sz=(p.s0+(p.s1-p.s0)*k)/F.s*p.fs; p.sp.scale.set(sz,sz,1); const fade=k<.15?k/.15:(1-k)/.85; p.sp.material.opacity=Math.max(0,fade)*(spec.op||1)*(spec.flick?(.65+.35*Math.sin(k*40+p.c*7)):1); if(p.life<=0) p.sp.visible=false; } }
    function clear(){ for(const p of ps){ p.life=0; p.sp.visible=false; } }
    return {update,clear,ps}; }
  /* ---------- şimşek kolu: rastgele kıvrımlı çizgi ---------- */
  function makeArc(root,hex,segs){ const pts=new Float32Array((segs+1)*3), g=new THREE.BufferGeometry(); g.setAttribute("position",new THREE.BufferAttribute(pts,3));
    const l=new THREE.Line(g,new THREE.LineBasicMaterial({color:hex,transparent:true,opacity:.9,blending:THREE.AdditiveBlending,depthWrite:false,fog:false})); l.frustumCulled=false; l.renderOrder=8; root.add(l); l.visible=false;
    return {line:l,set(ax,ay,az,bx,by,bz,jit){ for(let i=0;i<=segs;i++){ const t=i/segs, k=Math.sin(t*PI)*jit; pts[i*3]=ax+(bx-ax)*t+(Math.random()-.5)*k; pts[i*3+1]=ay+(by-ay)*t+(Math.random()-.5)*k; pts[i*3+2]=az+(bz-az)*t+(Math.random()-.5)*k; } g.attributes.position.needsUpdate=true; }}; }
  /* ---------- canvas dokuları ---------- */
  const cnv=(w,h)=>{ const c=document.createElement("canvas"); c.width=w; c.height=h; return c; };
  const rngS=seed=>{ let s=(seed|0)||1; return ()=>{ s=(s*16807)%2147483647; return s/2147483647; }; };
  /* kenarı yırtık/alevli/sivri pelerin dokusu (alfa testli). kind: void|flame|frost|storm. v: üstte 1 → altta 0 (canvas üstten alta) */
  function capeTexture(kind,pal){ const W=256, Hh=512, c=cnv(W,Hh), q=c.getContext("2d"), rnd=rngS(kind.length*977+13); pal=pal||{};
    const base=kind==="frost"?Hh-26:Hh*.76, T=kind==="flame"?9:kind==="void"?12:kind==="storm"?7:6;
    q.save(); q.beginPath(); q.moveTo(0,0); q.lineTo(W,0); q.lineTo(W,base);
    for(let i=T-1;i>=0;i--){ const xa=(i+1)/T*W, xm=(i+.5)/T*W, xb=i/T*W; /* sağdan sola: vadi, uç, vadi */
      let tip;
      if(kind==="void") tip=base+(Hh-base)*(.25+rnd()*.75); else if(kind==="flame") tip=base+(Hh-base)*(.2+rnd()*.8); else if(kind==="storm") tip=base+(Hh-base)*(i%2?.45:1); else tip=Hh-2;
      const valley=kind==="frost"?Hh-26:base-4-rnd()*(kind==="flame"?18:10);
      if(kind==="frost"){ q.lineTo(xa,valley); q.quadraticCurveTo(xm,tip+10,xb,valley); } else { q.lineTo(xa,valley); q.lineTo(xm,tip); q.lineTo(xb,valley); } }
    q.lineTo(0,base); q.closePath(); q.clip();
    const g=q.createLinearGradient(0,0,0,Hh);
    if(kind==="void"){ g.addColorStop(0,"#000"); g.addColorStop(1,"#000"); }
    else if(kind==="flame"){ g.addColorStop(0,pal.a||"#1c0504"); g.addColorStop(.42,pal.b||"#7a1405"); g.addColorStop(.78,pal.c||"#ff6a14"); g.addColorStop(1,pal.d||"#ffe066"); }
    else if(kind==="frost"){ g.addColorStop(0,pal.a||"#6fa8dc"); g.addColorStop(.55,pal.b||"#bfe3ff"); g.addColorStop(1,pal.c||"#f6fdff"); }
    else { g.addColorStop(0,pal.a||"#0b1030"); g.addColorStop(.6,pal.b||"#1a2a78"); g.addColorStop(1,pal.c||"#2f6bff"); }
    q.fillStyle=g; q.fillRect(0,0,W,Hh);
    if(kind==="flame"){ for(let i=0;i<70;i++){ const x=rnd()*W, y=Hh*(.3+rnd()*.7), r=10+rnd()*34, rg=q.createRadialGradient(x,y,0,x,y,r); rg.addColorStop(0,"rgba(255,"+((150+rnd()*90)|0)+",40,.6)"); rg.addColorStop(1,"rgba(255,80,0,0)"); q.fillStyle=rg; q.fillRect(x-r,y-r,r*2,r*2); } }
    if(kind==="frost"){ q.strokeStyle="rgba(255,255,255,.6)"; q.lineWidth=1.4; for(let i=0;i<46;i++){ let x=rnd()*W, y=rnd()*Hh; q.beginPath(); q.moveTo(x,y); for(let k=0;k<4;k++){ x+=(rnd()-.5)*34; y+=10+rnd()*26; q.lineTo(x,y); } q.stroke(); }
      for(let i=0;i<40;i++){ const x=rnd()*W,y=rnd()*Hh,r=2+rnd()*5; q.fillStyle="rgba(255,255,255,"+(.25+rnd()*.5)+")"; q.beginPath(); q.arc(x,y,r,0,7); q.fill(); } }
    if(kind==="storm"){ q.strokeStyle=pal.bolt||"rgba(150,230,255,.95)"; q.shadowColor="#6fd8ff"; q.shadowBlur=10; for(let i=0;i<7;i++){ let x=18+rnd()*(W-36), y=Hh*(.1+rnd()*.3); q.lineWidth=1.5+rnd()*2; q.beginPath(); q.moveTo(x,y); while(y<Hh*.94){ x+=(rnd()-.5)*46; y+=18+rnd()*34; q.lineTo(x,y); } q.stroke(); } q.shadowBlur=0; }
    q.restore(); return new THREE.CanvasTexture(c); }
  /* kafa derisinden yelpaze şeklinde şerit dizisi: out = yüzey normali payı, up/down = dikey payı, dx/dz = ek yön */
  function fan(o){ const rnd=rngS(o.seed||7), out=[]; for(let i=0;i<o.count;i++){ const f=o.count>1?i/(o.count-1):.5, az=o.az0+(o.az1-o.az0)*f+(rnd()-.5)*(o.jit||0), el=o.el0+(o.el1-o.el0)*rnd(), sc=scalp(az,el,o.rr), n=sc.n, ou=o.out==null?1:o.out;
      out.push({r:sc.r,d:[n[0]*ou+(o.dx||0), n[1]*ou+(o.up||0)-(o.down||0), n[2]*ou+(o.dz||0)],L:o.L0+(o.L1-o.L0)*rnd(),n:o.n,w0:o.w0,w1:o.w1,droop:o.droop||0,wave:(o.wave||0)*(rnd()-.5)*2,wph:rnd()*6,stiff:o.stiff,cols:o.cols}); } return out; }
  return {clamp,sm,frame,wpos,glowSprite,glowTex,makeHair,makeWing,makeAura,makeArc,scalp,norm,capeTexture,EL_DEFAULT,rngS,cnv,PI,fan};
})();
