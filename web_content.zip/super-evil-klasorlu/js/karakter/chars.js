"use strict";
/* ===== KARAKTERLER: 12 karakter × 8 görünüm, eklemli iskelet (rig). Ölçek 1 ≈ 1.9 birim boy; orijin = kalça ===== */
const TONES=["#f0c8a0","#e3b48a","#c68a5e","#8d5a3b","#5e3a24","#f7d9c0"];
/* skins: [birincil, ikincil, süs/metal, pelerin, ten(opsiyonel indeks)] */
const CHARS = {
  classic: {icon:"🦸", laser:0xff4a10, eye:0xff2200, accent:"#e63946", cape:{w:.78,h:1.15}, skins:[
    ["#e63946","#7a1020","#ffcc33","#b01020"],["#1d4fd8","#c0392b","#ffd23f","#c0392b"],["#222831","#6b7280","#f1c40f","#111827"],["#2ecc71","#1b6b3a","#ffffff","#145a32"],
    ["#f2f2f2","#9ca3af","#ffcc33","#3b82f6"],["#7e22ce","#3b0764","#fbbf24","#581c87"],["#ff7a29","#7c2d12","#fde047","#9a3412"],["#0ea5a4","#134e4a","#f9a8d4","#115e59",2]]},
  pharaoh: {icon:"🏺", laser:0xffc933, eye:0xffd84a, accent:"#1a4fb0", cape:{w:.62,h:.95}, skins:[
    ["#1a4fb0","#f3ead2","#e3b341","#1a4fb0"],["#b91c1c","#f8f1dc","#facc15","#7f1d1d"],["#0f766e","#ece3c6","#d4a017","#115e59",2],["#111827","#d6c9a3","#e3b341","#312e81",3],
    ["#7c3aed","#fdf6e3","#fcd34d","#5b21b6"],["#15803d","#efe6c8","#eab308","#14532d",1],["#f97316","#f5ebd0","#fde68a","#9a3412",2],["#e5e7eb","#d1d5db","#9ca3af","#6b7280",4]]},
  poseidon: {icon:"🔱", laser:0x33e0ff, eye:0x66f0ff, accent:"#1aa6a0", cape:{w:.85,h:1.2}, skins:[
    ["#1aa6a0","#0e3b5c","#d6b13a","#1f7fa8"],["#2563eb","#1e3a8a","#e5e7eb","#1d4ed8"],["#10b981","#064e3b","#fde047","#047857",2],["#8b5cf6","#4c1d95","#a5f3fc","#6d28d9"],
    ["#0ea5e9","#075985","#f0abfc","#0284c7",3],["#14b8a6","#134e4a","#fb7185","#0f766e",1],["#1e293b","#0f172a","#38bdf8","#0c4a6e",4],["#f43f5e","#881337","#fcd34d","#be123c"]]},
  zeus: {icon:"⚡", laser:0xfff27a, eye:0xbfe6ff, accent:"#f2f2f2", cape:{w:.8,h:1.1}, skins:[
    ["#f6f6f6","#f2f2f2","#d4af37","#eeeeff"],["#fde68a","#fef3c7","#b45309","#fbbf24"],["#93c5fd","#dbeafe","#1d4ed8","#60a5fa"],["#a78bfa","#ede9fe","#f59e0b","#8b5cf6",1],
    ["#fca5a5","#fee2e2","#b91c1c","#f87171",2],["#6ee7b7","#d1fae5","#047857","#34d399"],["#1f2937","#374151","#fbbf24","#111827",3],["#e5e7eb","#f9fafb","#6b7280","#9ca3af",5]]},
  ninja: {icon:"🥷", laser:0xff2b6a, eye:0xff3d7f, accent:"#1c1f2b", cape:{w:.22,h:.95,scarf:true}, skins:[
    ["#1c1f2b","#3a3f55","#c0c4d6","#b91c1c"],["#7f1d1d","#450a0a","#e5e7eb","#111827"],["#14532d","#052e16","#bbf7d0","#facc15"],["#1e3a8a","#172554","#93c5fd","#e5e7eb"],
    ["#f5f5f5","#a3a3a3","#404040","#dc2626"],["#581c87","#2e1065","#e9d5ff","#f59e0b"],["#78350f","#451a03","#fde68a","#0f172a",2],["#0f172a","#020617","#22d3ee","#22d3ee"]]},
  knight: {icon:"🛡️", laser:0x7ad7ff, eye:0x9be7ff, accent:"#9aa5b5", cape:{w:.7,h:.8}, skins:[
    ["#9aa5b5","#4b5563","#d4af37","#b91c1c"],["#d4af37","#92400e","#fef3c7","#1d4ed8"],["#374151","#111827","#9ca3af","#7f1d1d"],["#e5e7eb","#9ca3af","#2563eb","#2563eb"],
    ["#7f1d1d","#450a0a","#fbbf24","#111827"],["#065f46","#022c22","#fcd34d","#065f46"],["#1e3a8a","#172554","#e5e7eb","#e5e7eb"],["#6d28d9","#2e1065","#f0abfc","#a21caf"]]},
  viking: {icon:"🪓", laser:0xffa347, eye:0x9fd8ff, accent:"#7b4a2a", cape:{w:.74,h:.6,fur:true}, skins:[
    ["#7b4a2a","#4a2c17","#c9ccd2","#e8e0d0"],["#4b5563","#1f2937","#fbbf24","#78716c"],["#1d4ed8","#1e3a8a","#e5e7eb","#d6d3d1"],["#991b1b","#450a0a","#d6d3d1","#292524"],
    ["#166534","#052e16","#fde68a","#a8a29e",1],["#a16207","#422006","#e5e7eb","#fef3c7",2],["#111827","#030712","#9ca3af","#52525b",3],["#6b21a8","#3b0764","#fcd34d","#e7e5e4"]]},
  astro: {icon:"🧑‍🚀", laser:0x66ffcc, eye:0x66ffcc, accent:"#f4f6fa", cape:null, skins:[
    ["#f4f6fa","#9aa4b2","#ff6a2b","#f4f6fa"],["#ff8c1a","#7c3a00","#ffffff","#ff8c1a"],["#1e3a8a","#172554","#e5e7eb","#1e3a8a"],["#14532d","#052e16","#facc15","#14532d"],
    ["#111827","#030712","#22d3ee","#111827"],["#e11d48","#4c0519","#ffffff","#e11d48"],["#a855f7","#3b0764","#fde047","#a855f7"],["#f5d0fe","#c026d3","#ffffff","#f5d0fe"]]},
  robot: {icon:"🤖", laser:0x35f0ff, eye:0x35f0ff, accent:"#8e9bb0", cape:null, skins:[
    ["#8e9bb0","#3a4252","#35f0ff","#8e9bb0"],["#c0392b","#4b0f08","#ffd23f","#c0392b"],["#e5e7eb","#6b7280","#a3e635","#e5e7eb"],["#1f2937","#030712","#f43f5e","#1f2937"],
    ["#d4af37","#78350f","#fff7ae","#d4af37"],["#2563eb","#1e3a8a","#f0f9ff","#2563eb"],["#16a34a","#052e16","#bbf7d0","#16a34a"],["#a21caf","#4a044e","#f5d0fe","#a21caf"]]},
  wizard: {icon:"🧙", laser:0xc27bff, eye:0xd7a8ff, accent:"#5b3aa8", cape:{w:.82,h:1.05}, skins:[
    ["#5b3aa8","#2e1a6b","#fbbf24","#3b1f86"],["#1e40af","#1e3a8a","#e0f2fe","#1d4ed8"],["#7f1d1d","#450a0a","#fcd34d","#991b1b"],["#065f46","#022c22","#fde68a","#047857"],
    ["#e5e7eb","#9ca3af","#7c3aed","#c4b5fd",1],["#111827","#030712","#a78bfa","#1f2937",3],["#b45309","#451a03","#fef3c7","#92400e",2],["#be185d","#500724","#fbcfe8","#9d174d"]]},
  samurai: {icon:"⚔️", laser:0xff5a3c, eye:0xffd0a0, accent:"#a31621", cape:{w:.3,h:.7,scarf:true}, skins:[
    ["#a31621","#1f1f27","#d4af37","#a31621"],["#1e3a8a","#0f172a","#e5e7eb","#1d4ed8"],["#14532d","#0f1f14","#fbbf24","#166534"],["#111827","#030712","#dc2626","#7f1d1d"],
    ["#f5f5f5","#525252","#b91c1c","#f5f5f5",5],["#581c87","#1e1b4b","#fde047","#7e22ce"],["#c2410c","#431407","#fef3c7","#ea580c",2],["#0e7490","#083344","#a5f3fc","#06b6d4",1]]},
  dragon: {icon:"🐲", laser:0xff7a1a, eye:0xffe14a, accent:"#2b1a2f", cape:null, skins:[
    ["#2b1a2f","#7f1d1d","#f59e0b","#b91c1c"],["#064e3b","#022c22","#a3e635","#16a34a"],["#1e1b4b","#0f0a2e","#60a5fa","#3b82f6"],["#44403c","#1c1917","#fb923c","#dc2626"],
    ["#831843","#500724","#fda4af","#be185d"],["#0c4a6e","#082f49","#7dd3fc","#0284c7"],["#713f12","#422006","#fde047","#ca8a04"],["#f1f5f9","#94a3b8","#38bdf8","#e2e8f0"]]}
};
const CHAR_IDS = Object.keys(CHARS);
const SKIN_COUNT = 8;

function buildHeroModel(id, skinIdx, accentHex){
  const C=CHARS[id]||CHARS.classic, sk=C.skins[((skinIdx|0)%C.skins.length+C.skins.length)%C.skins.length];
  const pri=accentHex||sk[0], sec=sk[1], trim=sk[2], capeC=accentHex&&C.cape&&!C.cape.fur?accentHex:sk[3];
  const tone=TONES[sk[4]!==undefined?sk[4]:(id==="dragon"?6:0)], skinC=id==="dragon"?"#b3261e":id==="robot"?"#8e9bb0":tone;
  const g=new THREE.Group(), mats=[], accentMats=[];
  const M=(c,o)=>{ const m=Game.noSnow(new THREE.MeshStandardMaterial(Object.assign({color:c,roughness:.55,metalness:.08},o||{}))); mats.push(m); return m; };
  const VB=C.vip&&Game.VIPB?Game.VIPB[id]:null, VP=VB?(sk[5]||{}):{}, vm=VB?VB.mats({M,pri,sec,trim,sk,pal:VP,mats,accentMats}):null;
  let mPri=M(pri,{roughness:.42,metalness:.15}); accentMats.push(mPri);
  let mSec=M(sec,{roughness:.6}), mTrim=M(trim,{roughness:.28,metalness:.85}), mSkin=M(skinC,{roughness:.68,metalness:0}), mDark=M("#17181f",{roughness:.7}), mWhite=M("#f4f4f4",{roughness:.8});
  if(vm){ if(vm.pri) mPri=vm.pri; if(vm.sec) mSec=vm.sec; if(vm.trim) mTrim=vm.trim; if(vm.skin) mSkin=vm.skin; if(vm.dark) mDark=vm.dark; if(vm.white) mWhite=vm.white; }
  const eyeHex=VP.eye!=null?VP.eye:C.eye, laserHex=VP.laser!=null?VP.laser:C.laser;
  const mEye=new THREE.MeshBasicMaterial({color:eyeHex}); mats.push(mEye);
  const mGlow=new THREE.MeshBasicMaterial({color:laserHex}); mats.push(mGlow);
  const B=(w,h,d)=>new THREE.BoxGeometry(w,h,d), SP=(r,a,b)=>new THREE.SphereGeometry(r,a||14,b||10), CY=(r0,r1,h,s)=>new THREE.CylinderGeometry(r0,r1,h,s||12), CO=(r,h,s)=>new THREE.ConeGeometry(r,h,s||8);
  const add=(par,geo,mat,x,y,z,rx,ry,rz,sx,sy,sz)=>{ const m=new THREE.Mesh(geo,mat); m.position.set(x||0,y||0,z||0); if(rx||ry||rz) m.rotation.set(rx||0,ry||0,rz||0); if(sx!==undefined) m.scale.set(sx,sy===undefined?sx:sy,sz===undefined?sx:sz); m.castShadow=true; par.add(m); return m; };
  const grp=(par,x,y,z)=>{ const o=new THREE.Group(); o.position.set(x||0,y||0,z||0); par.add(o); return o; };
  const R={}; // iskelet
  R.root=grp(g,0,0,0); R.spine=grp(R.root,0,.06,0); R.chest=grp(R.spine,0,.3,0); R.neck=grp(R.chest,0,.36,0); R.head=grp(R.neck,0,.1,0);
  const bare=(id==="pharaoh"||id==="poseidon"||id==="zeus"||id==="dragon"||id==="viking"), suitArm=(id==="classic"||id==="ninja"||id==="astro"||id==="wizard"||id==="samurai"||id==="knight"||id==="robot");
  let mArm=suitArm?(id==="astro"?mWhite:mPri):mSkin, mLeg=(id==="classic"||id==="ninja"||id==="astro"||id==="robot"||id==="knight")?(id==="astro"?mWhite:mPri):(id==="samurai"||id==="wizard"?mSec:mSkin);
  let mTor=(id==="pharaoh"||id==="poseidon"||id==="zeus"||id==="dragon")?mSkin:mPri, mHand=(id==="classic"||id==="astro"||id==="knight"||id==="ninja"||id==="robot")?(id==="astro"||id==="knight"||id==="robot"?mSec:mSec):mSkin, mBoot=(id==="pharaoh"||id==="poseidon"||id==="zeus")?mSkin:mSec;
  if(vm){ if(vm.arm) mArm=vm.arm; if(vm.leg) mLeg=vm.leg; if(vm.tor) mTor=vm.tor; if(vm.hand) mHand=vm.hand; if(vm.boot) mBoot=vm.boot; }
  // gövde: V-formlu kaslı gövde (geniş sırt/omuz, dar bel), göğüs kasları, karın kasları, trapez
  const mMus=(id==="robot")?mTor:mTor;
  add(R.root,B(.6,.2,.34),(id==="classic"||id==="pharaoh")?mSec:mLeg===mSkin?mSec:mLeg,0,-.01,0);
  add(R.spine,B(.5,.34,.3),mTor,0,.14,0); add(R.chest,B(.8,.46,.42),mTor,0,.14,0); add(R.chest,SP(.3,12,8),mTor,0,.34,0,0,0,0,1.38,.45,.66);
  add(R.chest,B(.9,.2,.38),mTor,0,.32,-.01,0,0,0);                                            // geniş sırt (latissimus): V şekli
  for(const s of [-1,1]){ add(R.chest,SP(.2,12,9),mTor,s*.18,.2,.15,0,0,0,1,.78,.62);          // göğüs (pectoral)
    add(R.chest,SP(.12,8,6),mTor,s*.17,.44,-.03,0,0,0,1.2,.8,1);                                // trapez
    add(R.spine,SP(.09,8,6),mTor,s*.09,.2,.145,0,0,0,1,.8,.55); add(R.spine,SP(.09,8,6),mTor,s*.09,.09,.148,0,0,0,1,.8,.55); add(R.spine,SP(.085,8,6),mTor,s*.09,-.02,.145,0,0,0,1,.8,.55); // karın kasları
    add(R.spine,SP(.1,8,6),mTor,s*.2,.1,.0,0,0,0,.7,1.6,1); }                                  // yan karın (oblik)
  add(R.neck,CY(.1,.12,.17,10),mSkin,0,0,0);
  // kafa
  const head=add(R.head,SP(.2,16,12),mSkin,0,.1,0,0,0,0,1,1.06,1);
  add(R.head,B(.24,.12,.2),mSkin,0,-.06,.04);                                                   // güçlü çene
  const fc={eyeL:add(R.head,B(.08,.035,.03),mEye,-.075,.12,.185), eyeR:add(R.head,B(.08,.035,.03),mEye,.075,.12,.185),
    brL:add(R.head,B(.1,.026,.04),mDark,-.078,.16,.185,0,0,.2), brR:add(R.head,B(.1,.026,.04),mDark,.078,.16,.185,0,0,-.2),
    nose:add(R.head,B(.05,.07,.05),mSkin,0,.07,.2), mouth:add(R.head,B(.1,.016,.02),M("#7a3b3b"),0,-.0,.19)};
  // kollar: büyük deltoid, pazı (biceps/triceps), kaslı önkol, iri el
  const arm=(s)=>{ const sh=grp(R.chest,s*.47,.3,0); add(sh,SP(.165,12,9),(id==="knight"||id==="viking"||id==="robot"||id==="samurai")?mTrim:mArm,0,.0,0,0,0,0,1,.95,1);
    add(sh,CY(.108,.084,.34,12),mArm,0,-.17,0); add(sh,SP(.098,10,8),mArm,0,-.15,.045,0,0,0,1,1.35,.95); add(sh,SP(.085,9,7),mArm,0,-.15,-.05,0,0,0,1,1.3,.85);
    const el=grp(sh,0,-.34,0); add(el,SP(.082,9,7),mArm,0,0,0); add(el,CY(.09,.06,.32,12),mArm===mSkin?mSkin:mArm,0,-.16,0); add(el,SP(.082,9,7),mArm,0,-.09,.02,0,0,0,1,1.45,1.05);
    const hd=grp(el,0,-.32,0); add(hd,SP(.082,10,8),mHand,0,-.02,0); add(hd,B(.13,.1,.14),mHand,0,-.06,.01); for(let i=0;i<4;i++) add(hd,B(.026,.06,.03),mHand,(i-1.5)*.03,-.13,.045); return {sh,el,hd}; };
  const aL=arm(-1), aR=arm(1); R.shL=aL.sh; R.elL=aL.el; R.hdL=aL.hd; R.shR=aR.sh; R.elR=aR.el; R.hdR=aR.hd;
  // bacaklar: iri uyluk (quad), baldır, büyük bot
  const leg=(s)=>{ const hp=grp(R.root,s*.19,-.04,0); add(hp,SP(.13,9,7),mLeg,0,0,0); add(hp,CY(.15,.1,.43,12),mLeg,0,-.21,0); add(hp,SP(.125,10,8),mLeg,0,-.17,.055,0,0,0,1,1.7,1); add(hp,SP(.11,9,7),mLeg,0,-.17,-.05,0,0,0,1,1.6,.9); const kn=grp(hp,0,-.43,0); add(kn,SP(.1,9,7),mLeg,0,0,0); add(kn,CY(.105,.068,.4,12),mLeg,0,-.2,0); add(kn,SP(.095,9,7),mLeg,0,-.1,-.04,0,0,0,1,1.6,1);
    const ft=grp(kn,0,-.4,0); add(ft,B(.18,.11,.32),mBoot,0,-.05,.06); add(ft,B(.19,.06,.12),mBoot,0,-.09,.2); return {hp,kn,ft}; };
  const lL=leg(-1), lR=leg(1); R.hpL=lL.hp; R.knL=lL.kn; R.ftL=lL.ft; R.hpR=lR.hp; R.knR=lR.kn; R.ftR=lR.ft;
  R.mount=grp(R.hdR,0,-.06,.08);        // sağ el nesnesi (asa, kılıç…)
  R.mountL=grp(R.hdL,0,-.06,.08);
  let wings=null, tail=null, extra={}, vip=null;
  const cl=(par,c,x,y,z,w,h,d,rx,ry,rz)=>add(par,B(w,h,d),c,x,y,z,rx,ry,rz);
  if(id==="classic"){
    add(R.chest,B(.3,.3,.03),mTrim,0,.2,.205,0,0,Math.PI/4,.9,.9,1); add(R.chest,B(.2,.2,.03),mSec,0,.2,.215,0,0,Math.PI/4);       // arma
    cl(R.root,mDark,0,0,0,.62,.08,.36); cl(R.root,mTrim,0,0,.18,.12,.08,.03);
    add(R.head,SP(.215,14,8),M("#1b1b22"),0,.15,-.025,0,0,0,1,.62,1.02); add(R.head,B(.36,.1,.06),M("#1b1b22"),0,.22,.12,.3);
    add(R.chest,B(.3,.06,.05),mSec,0,.42,0);
  } else if(id==="pharaoh"){
    add(R.root,CY(.24,.4,.5,12),mSec,0,-.2,0,0,0,0,1,1,.78); cl(R.root,mTrim,0,.08,0,.64,.07,.38); for(let i=-2;i<=2;i++) cl(R.root,mPri,i*.1,-.27,.255,.05,.4,.02);
    add(R.chest,CY(.34,.4,.12,18),mTrim,0,.38,0,0,0,0,1,1,.7); add(R.chest,CY(.3,.34,.05,18),mPri,0,.33,0,0,0,0,1,1,.7); add(R.chest,B(.76,.05,.44),mTrim,0,.05,0);
    for(const s of [-1,1]){ add(R.elR===null?R.chest:(s<0?R.elL:R.elR),CY(.07,.07,.07,10),mTrim,0,-.2,0); }
    add(R.head,SP(.235,14,10),mTrim,0,.14,-.015,0,0,0,1,.72,1.06); cl(R.head,mTrim,-.225,-.02,.02,.1,.4,.16); cl(R.head,mTrim,.225,-.02,.02,.1,.4,.16);
    cl(R.head,mPri,-.225,-.02,.1,.1,.34,.05); cl(R.head,mPri,.225,-.02,.1,.1,.34,.05); cl(R.head,mTrim,0,-.04,-.24,.3,.5,.1,.15); cl(R.head,mPri,0,.04,-.246,.3,.06,.04,.15); cl(R.head,mPri,0,-.1,-.25,.3,.06,.04,.15);
    add(R.head,CO(.04,.18,6),mTrim,0,.38,.17,.5); add(R.head,SP(.035,6,6),mGlow,0,.31,.23); add(R.head,B(.07,.12,.07),M("#16130f"),0,-.16,.2);
    add(R.mount,CY(.025,.025,1.55,6),mTrim,0,.3,0); add(R.mount,new THREE.TorusGeometry(.1,.025,6,12),mTrim,0,1.12,0); add(R.mount,B(.2,.04,.04),mTrim,0,1.0,0);
  } else if(id==="poseidon"){
    const sea=mPri; add(R.root,CY(.27,.36,.4,12),sea,0,-.12,0,0,0,0,1,1,.8); cl(R.root,mDark,0,.04,0,.62,.08,.36);
    for(let i=0;i<3;i++) cl(R.chest,M("#b8895f"),0,.04+i*.13,.205,.4,.025,.02); cl(R.chest,M("#b8895f"),0,.2,.205,.02,.4,.02);
    for(const s of [-1,1]){ add(R.chest,SP(.17,10,8),mTrim,s*.42,.38,0,0,0,0,1,.7,1); cl(R.chest,mTrim,s*.42,.28,0,.26,.05,.32,0,0,s*.3); }
    add(R.head,SP(.225,14,8),mWhite,0,.16,-.03,0,0,0,1,.7,1.03); cl(R.head,mWhite,0,-.12,.15,.26,.26,.16); cl(R.head,mWhite,0,-.28,.17,.14,.14,.12,0,0,0);
    add(R.head,new THREE.TorusGeometry(.215,.025,6,18),mTrim,0,.27,0,Math.PI/2); for(let i=-2;i<=2;i++) add(R.head,CO(.035,.14+(2-Math.abs(i))*.04,5),mTrim,Math.sin(i*.45)*.215,.36,Math.cos(i*.45)*.215-.02);
    add(R.mount,CY(.03,.03,1.9,8),M("#6b8e9c",{metalness:.8}),0,.4,0); cl(R.mount,mTrim,0,1.36,0,.34,.05,.05); for(const s of [-1,0,1]) add(R.mount,CO(.032,.3+(s===0?.1:0),6),mTrim,s*.17,1.58+(s===0?.05:0),0);
  } else if(id==="zeus"){
    add(R.root,CY(.28,.38,.5,12),mWhite,0,-.17,0,0,0,0,1,1,.8); cl(R.root,mTrim,0,.06,0,.62,.1,.38);
    cl(R.chest,mWhite,.12,.14,.0,.62,.48,.43,0,0,-.05); add(R.chest,CY(.12,.13,.5,10),mWhite,-.36,.28,0,0,0,.9); cl(R.chest,mPri,0,.12,.215,.7,.05,.03,0,0,-.55);
    add(R.head,SP(.225,14,8),mWhite,0,.16,-.03,0,0,0,1,.72,1.04); cl(R.head,mWhite,-.2,-.05,0,.1,.3,.12); cl(R.head,mWhite,.2,-.05,0,.1,.3,.12);
    cl(R.head,mWhite,0,-.2,.14,.28,.34,.14,.1); cl(R.head,mWhite,0,-.4,.16,.18,.2,.1,.1);
    for(let i=0;i<7;i++){ const a=(i/6-.5)*2.6; add(R.head,B(.05,.12,.02),mTrim,Math.sin(a)*.23,.22,Math.cos(a)*.22-.03,.5,a,0); }
    const bolt=new THREE.MeshBasicMaterial({color:0xfff27a}); mats.push(bolt); add(R.mount,B(.07,.4,.07),bolt,0,.18,0,0,0,.45); add(R.mount,B(.07,.38,.07),bolt,-.13,.47,0,0,0,-.5); add(R.mount,B(.07,.42,.07),bolt,.02,.78,0,0,0,.5); add(R.mount,CO(.06,.2,4),bolt,.13,1.0,0,0,0,-.3);
  } else if(id==="ninja"){
    add(R.head,SP(.212,14,10),mPri,0,.1,0,0,0,0,1,1.07,1.01); cl(R.head,mDark,0,.07,.0,.4,.12,.4); cl(R.head,mEye,-.075,.12,.19,.08,.035,.03); cl(R.head,mEye,.075,.12,.19,.08,.035,.03);
    cl(R.head,trim==="#c0c4d6"?M("#c0c4d6",{metalness:.8}):mTrim,0,.22,.19,.4,.07,.06); cl(R.head,mSec,0,-.03,.195,.34,.17,.03);
    cl(R.head,mTrim,-.21,.22,-.08,.06,.34,.05,.3); cl(R.head,mTrim,-.18,.1,-.3,.05,.4,.04,.5);
    cl(R.root,mSec,0,.04,0,.6,.08,.36); for(const s of [-1,1]) cl(R.chest,mSec,s*.42,.0,0,.2,.07,.22); cl(R.chest,mSec,0,.3,.18,.5,.04,.05,.0,0,.5); cl(R.chest,mSec,0,.3,.18,.5,.04,.05,0,0,-.5);
    const kat=grp(R.chest,0,.15,-.28); kat.rotation.z=.8; add(kat,B(.04,.9,.05),M("#cfd5dd",{metalness:.9,roughness:.2}),0,.6,0); add(kat,B(.05,.28,.06),mDark,0,.0,0); add(kat,B(.14,.03,.08),mTrim,0,.15,0);
    add(R.mount,B(.03,.62,.05),M("#cfd5dd",{metalness:.9,roughness:.2}),0,.2,0,.0); extra.hideMount=true;
  } else if(id==="knight"){
    for(const s of [-1,1]){ add(R.chest,SP(.16,10,8),mPri,s*.44,.34,0,0,0,0,1,.8,1.1); add(R.root,B(.2,.34,.2),mPri,s*.28,-.06,0); add(R.chest,B(.2,.24,.2),mTrim,s*.0,0,0,0,0,0,0.01); }
    cl(R.chest,mPri,0,.12,.215,.66,.4,.04); cl(R.chest,mTrim,0,.12,.235,.06,.4,.02); cl(R.chest,mTrim,0,.18,.235,.4,.05,.02); cl(R.root,mTrim,0,.04,0,.6,.07,.36);
    for(const [e,s] of [[R.elL,-1],[R.elR,1]]) add(e,CY(.082,.07,.2,10),mPri,0,-.14,0);
    add(R.head,CY(.215,.22,.4,16),mPri,0,.1,0); add(R.head,SP(.215,14,8),mPri,0,.3,0,0,0,0,1,.8,1); cl(R.head,mDark,0,.14,.205,.32,.045,.03); cl(R.head,mDark,0,.04,.205,.03,.2,.03); cl(R.head,mTrim,0,.23,.21,.34,.025,.02);
    add(R.head,B(.04,.2,.4),mSec,0,.55,0); add(R.head,B(.1,.14,.5),M("#b91c1c"),0,.5,-.05,.3);
    add(R.mount,B(.05,1.0,.1),M("#dfe5ee",{metalness:.9,roughness:.2}),0,.45,0); cl(R.mount,mTrim,0,-.02,0,.4,.05,.07); add(R.mount,SP(.05,8,6),mTrim,0,-.2,0);
    const shield=grp(R.elL,-.12,-.16,.08); shield.rotation.y=-.2; cl(shield,mPri,0,0,0,.08,.8,.58); cl(shield,mTrim,-.05,0,0,.04,.7,.08); cl(shield,mTrim,-.05,.1,0,.04,.08,.5); extra.shield=shield;
  } else if(id==="viking"){
    cl(R.root,M("#6b4a2d"),0,0,0,.62,.14,.36); add(R.root,CY(.26,.3,.34,12),M("#6b4a2d"),0,-.2,0,0,0,0,1,1,.8); cl(R.chest,M("#5a3b22"),0,.12,.21,.68,.38,.03); cl(R.chest,mTrim,0,0,.215,.1,.07,.02);
    add(R.chest,CY(.34,.42,.16,14),M(sk[3]),0,.4,0,0,0,0,1.1,1,.72); for(const s of [-1,1]){ add(R.chest,SP(.14,10,8),M(sk[3]),s*.44,.36,0,0,0,0,1,.8,1); add(R.elL===R.elR?R.elR:(s<0?R.elL:R.elR),CY(.08,.08,.12,10),M("#5a3b22"),0,-.12,0); }
    add(R.head,SP(.215,14,8),mTrim,0,.19,0,0,0,0,1,.7,1); add(R.head,CY(.218,.215,.06,16),M("#5a3b22"),0,.18,0);
    for(const s of [-1,1]){ add(R.head,CY(.04,.05,.18,6),mWhite,s*.24,.26,0,0,0,s*-.9); add(R.head,CO(.04,.28,6),mWhite,s*.34,.42,0,0,0,s*-.3); }
    const beardC=M(id==="viking"&&sk[4]===3?"#2a1a10":"#c2662a"); cl(R.head,beardC,0,-.12,.15,.3,.26,.16); cl(R.head,beardC,0,-.3,.16,.12,.2,.1); cl(R.head,beardC,-.07,-.36,.17,.04,.18,.05); cl(R.head,beardC,.07,-.36,.17,.04,.18,.05);
    add(R.mount,CY(.03,.03,1.3,8),M("#6b4a2d"),0,.3,0); cl(R.mount,M("#c9ccd2",{metalness:.9,roughness:.3}),.14,.92,0,.3,.34,.05); cl(R.mount,M("#c9ccd2",{metalness:.9,roughness:.3}),-.04,.92,0,.06,.2,.05);
    const rs=grp(R.chest,0,.2,-.26); add(rs,CY(.42,.42,.06,16),M("#8a5a2b"),0,0,0,Math.PI/2); add(rs,CY(.1,.1,.09,10),mTrim,0,0,0,Math.PI/2); add(rs,new THREE.TorusGeometry(.42,.03,6,20),mTrim,0,0,.03);
  } else if(id==="astro"){
    cl(R.chest,mSec,0,.14,.21,.5,.3,.04); cl(R.chest,mTrim,-.13,.25,.235,.1,.07,.02); cl(R.chest,M("#2f6fe0"),.14,.25,.235,.12,.07,.02); cl(R.chest,mDark,0,.1,.235,.22,.1,.02);
    const pack=cl(R.chest,mSec,0,.14,-.32,.52,.58,.24); cl(R.chest,mWhite,0,.14,-.45,.34,.4,.05);
    cl(R.root,mSec,0,0,0,.6,.1,.36); for(const e of [R.elL,R.elR]) add(e,CY(.075,.075,.06,10),mSec,0,-.3,0); for(const k of [R.knL,R.knR]) add(k,CY(.09,.09,.05,10),mSec,0,-.38,0);
    const hel=add(R.head,SP(.3,20,14),mWhite,0,.1,0,0,0,0,1,1,1.02); add(R.head,SP(.255,20,14),M("#201a10",{roughness:.08,metalness:.95,color:"#3b2f12"}),0,.1,.1,0,0,0,1.0,.88,.85); add(R.head,CY(.26,.3,.08,18),mSec,0,-.14,0);
    add(R.head,new THREE.TorusGeometry(.17,.012,6,16),mGlow,0,.1,.31,0,0,0,1,.7,1); add(R.head,SP(.035,6,6),mTrim,.3,.12,0);
    extra.noFace=true; extra.hideMount=true;
    add(R.mount,CY(.03,.03,.5,6),mSec,0,.2,0); add(R.mount,SP(.06,6,6),mGlow,0,.5,0);
  } else if(id==="robot"){
    add(R.head,B(.36,.32,.34),M("#8e9bb0",{metalness:.8,roughness:.3}),0,.1,0); cl(R.head,mEye,0,.12,.175,.3,.07,.03); cl(R.head,mDark,0,.01,.175,.2,.04,.03); add(R.head,CY(.015,.015,.22,6),mTrim,.1,.4,0); add(R.head,SP(.04,6,6),mGlow,.1,.52,0);
    add(R.head,CY(.07,.07,.4,10),mSec,-.2,.1,0,0,0,Math.PI/2,.5,1,.5); add(R.head,CY(.07,.07,.4,10),mSec,.2,.1,0,0,0,Math.PI/2,.5,1,.5);
    add(R.chest,CY(.1,.1,.04,12),mGlow,0,.22,.205,Math.PI/2); add(R.chest,new THREE.TorusGeometry(.13,.02,6,16),mTrim,0,.22,.205); for(let i=0;i<4;i++) cl(R.chest,mSec,0,.0+i*.05,.205,.5,.02,.02);
    for(const s of [-1,1]){ add(R.chest,CY(.1,.1,.2,10),mTrim,s*.43,.3,0,0,0,Math.PI/2); add(R.root,CY(.08,.08,.18,10),mTrim,s*.16,-.04,0,0,0,Math.PI/2); }
    cl(R.chest,mSec,0,.46,0,.3,.08,.26); cl(R.chest,mSec,0,.14,-.26,.5,.4,.12); add(R.chest,CY(.03,.05,.32,6),mTrim,-.18,.44,-.28); add(R.chest,CY(.03,.05,.32,6),mTrim,.18,.44,-.28);
    extra.noFace=true; add(R.mount,B(.1,.1,.1),mGlow,0,0,.1);
  } else if(id==="wizard"){
    add(R.root,CY(.26,.46,.8,14),mPri,0,-.22,0,0,0,0,1,1,.86); cl(R.root,mTrim,0,.06,0,.58,.07,.36); add(R.chest,B(.74,.46,.42),mPri,0,.14,0);
    cl(R.chest,mSec,0,.14,.215,.12,.46,.02); for(const s of [-1,1]) add(s<0?R.elL:R.elR,CY(.14,.16,.3,10),mPri,0,-.2,0);
    add(R.head,CO(.27,.74,14),mPri,0,.34,-.02,-.12); add(R.head,CY(.3,.3,.04,16),mPri,0,.15,0); add(R.head,CY(.275,.275,.035,16),mTrim,0,.18,0); add(R.head,SP(.045,6,6),mGlow,0,.7,-.1);
    const bc=M("#e8e8ee"); cl(R.head,bc,0,-.14,.16,.28,.3,.14,.08); cl(R.head,bc,0,-.38,.17,.2,.3,.1,.08); cl(R.head,bc,0,-.58,.17,.12,.2,.07,.08); cl(R.head,bc,0,.02,.19,.28,.05,.05);
    add(R.mount,CY(.035,.04,1.7,8),M("#6b4a2d"),0,.4,0); add(R.mount,new THREE.TorusGeometry(.12,.03,6,12),mTrim,0,1.3,0); add(R.mount,SP(.1,12,10),mGlow,0,1.3,0);
  } else if(id==="samurai"){
    add(R.root,CY(.3,.34,.55,12),mSec,0,-.17,0,0,0,0,1,1,.85); cl(R.root,mDark,0,.06,0,.6,.09,.36); cl(R.root,mTrim,0,.06,.19,.1,.12,.03);
    for(let i=0;i<5;i++) cl(R.chest,i%2?mPri:mSec,0,-.06+i*.1,.215,.7,.08,.03); for(const s of [-1,1]){ for(let i=0;i<3;i++) cl(R.chest,i%2?mPri:mSec,s*.45,.42-i*.08,0,.24,.07,.3,0,0,s*.25*(i+1)*.5); cl(R.chest,mPri,s*.0,.1,-.215,.7,.46,.03); }
    for(const e of [R.elL,R.elR]) add(e,CY(.085,.075,.2,10),mPri,0,-.14,0);
    add(R.head,SP(.222,14,8),mDark,0,.17,-.01,0,0,0,1,.75,1.03); cl(R.head,mDark,0,.0,-.2,.46,.22,.06,-.1); for(const s of [-1,1]){ cl(R.head,mDark,s*.2,.04,.0,.07,.2,.3,0,0,s*.3); cl(R.head,mTrim,s*.08,.3,.2,.02,.28,.04,0,0,s*.7); }
    cl(R.head,mPri,0,-.08,.19,.34,.18,.04); add(R.head,CO(.04,.1,6),mDark,0,-.04,.215,Math.PI/2);
    add(R.head,new THREE.TorusGeometry(.2,.012,6,20),mTrim,0,.3,.1,.3);
    const kat=grp(R.root,.3,0,.12); kat.rotation.set(1.57,0,-.3); add(kat,B(.04,.95,.05),mDark,0,.5,0); add(kat,B(.14,.03,.08),mTrim,0,.05,0); add(kat,B(.05,.22,.05),mPri,0,-.06,0);
    add(R.mount,B(.03,.9,.05),M("#cfd5dd",{metalness:.9,roughness:.2}),0,.4,0); extra.hideMount=true;
  } else if(VB){
    vip=VB.build({id,g,R,M,add,grp,cl,B,SP,CY,CO,TO:(a,b,c,d,e)=>new THREE.TorusGeometry(a,b,c||8,d||16,e),mats,accentMats,pri,sec,trim,sk,pal:VP,mPri,mSec,mTrim,mSkin,mDark,mWhite,mEye,mGlow,fc,extra,vm,C,eyeHex,laserHex,setTail:t=>{ tail=t; },setWings:w=>{ wings=w; }});
  } else { /* dragon */
    cl(R.root,M("#1c1317"),0,.0,0,.62,.14,.36); add(R.root,CY(.27,.3,.28,12),M("#1c1317"),0,-.14,0,0,0,0,1,1,.8); cl(R.chest,M("#1c1317"),0,.14,.215,.6,.38,.04); cl(R.chest,mTrim,0,.14,.235,.06,.4,.02);
    for(const s of [-1,1]){ add(R.chest,SP(.16,10,8),M("#1c1317"),s*.44,.36,0,0,0,0,1,.8,1.1); for(let i=0;i<3;i++) add(R.chest,CO(.035,.14,5),mTrim,s*(.44+i*.03),.5-i*.04,0,0,0,s*-.5); add(R.head,CO(.06,.4,6),mDark,s*.14,.34,-.06,-.5,0,s*-.3); add(R.head,CO(.03,.22,5),mTrim,s*.22,.2,-.05,-.7,0,s*-.9); }
    add(R.head,CO(.05,.2,5),mDark,0,.0,.2,Math.PI/2); cl(R.head,mDark,0,-.1,.17,.2,.08,.12);
    tail=[]; let par=R.root, px=0; for(let i=0;i<5;i++){ const seg=grp(par,0,i===0?-.05:0,i===0?-.16:-.2); add(seg,CY(.09-i*.014,.075-i*.014,.22,8),mSkin,0,0,-.1,Math.PI/2); if(i===4) add(seg,CO(.06,.2,4),mTrim,0,0,-.28,-Math.PI/2); tail.push(seg); par=seg; }
    wings=[]; for(const s of [-1,1]){ const w=grp(R.chest,s*.18,.3,-.24); const arm1=grp(w,0,0,0); cl(arm1,mDark,s*.35,0,0,.7,.05,.05); const mem=add(arm1,B(1,1,1),M(sk[3],{side:THREE.DoubleSide,roughness:.8}),s*.4,-.3,0,0,0,0,.8,.02,.6); const mem2=add(arm1,B(1,1,1),M(sk[3],{side:THREE.DoubleSide,roughness:.8}),s*.85,-.2,0,0,0,0,.5,.02,.45); wings.push(arm1); }
    add(R.mount,CY(.03,.03,1.2,6),mDark,0,.3,0); add(R.mount,CO(.06,.3,6),mTrim,0,1.0,0); extra.hideMount=true;
  }
  if(extra.hideMount){ /* sağ el boş: kılıç/asa mount içinde ise gizlenmez; sadece boş bırak */ }
  // pelerin
  let capeGeo=null, capeBase=null, capeAnchor=null, capeSeg=0, CW=0, CH=0;
  let capeCols=6, capeRows=10, capeJag=null;
  if(C.cape){ CW=C.cape.w; CH=C.cape.h; const scarf=!!C.cape.scarf, fur=!!C.cape.fur; capeCols=C.cape.cols||6; capeRows=C.cape.rows||10; capeJag=C.cape.jag||null;
    const cm=C.cape.make?C.cape.make({M,mats,capeC,sk,pal:VP,id}):M(capeC,{roughness:.8,side:THREE.DoubleSide}); if(!fur&&!scarf&&!C.cape.make) accentMats.push(cm);
    capeGeo=new THREE.PlaneGeometry(CW,CH,capeCols,capeRows); capeGeo.translate(0,-CH/2,0); const mc=new THREE.Mesh(capeGeo,cm); mc.castShadow=!C.cape.make; mc.frustumCulled=false;
    capeAnchor=grp(R.chest,0,C.cape.ay!=null?C.cape.ay:(scarf?.38:.34),C.cape.az!=null?C.cape.az:(scarf?-.04:-.2)); capeAnchor.add(mc); capeBase=capeGeo.attributes.position.array.slice(); capeSeg=capeRows; }
  g.userData={id,rig:R,mats,accentMats,eyeMat:mEye,glowMat:mGlow,hand:R.mount,capeGeo,capeBase,capeAnchor,capeW:CW,capeH:CH,capeRows:capeRows,capeCols:capeCols,capeJag,vip,fc,eyeHex,laserHex,scarf:!!(C.cape&&C.cape.scarf),wings,tail,extra,head,
    capeDir:null, ph:0, cur:{}, t:0};
  /* küçük süs parçaları (diken, diş, pençe...) gölge geçişine girmesin: kare başına yüzlerce çizim çağrısı tasarrufu */
  g.traverse(o=>{ if(!o.geometry||!o.castShadow) return; const q=o.geometry.parameters; if(!q) return; const sc=Math.max(Math.abs(o.scale.x),Math.abs(o.scale.y),Math.abs(o.scale.z));
    const ext=q.width!==undefined?Math.max(q.width,q.height||0,q.depth||0):q.radiusTop!==undefined?Math.max(Math.max(q.radiusTop,q.radiusBottom)*2,q.height||0):q.radius!==undefined&&q.height!==undefined?Math.max(q.radius*2,q.height):q.radius!==undefined?(q.tube!==undefined?(q.radius+q.tube)*2:q.radius*2):1;
    if(ext*sc<.13) o.castShadow=false; });
  g.userData.mats.forEach(m=>{ m.userData=m.userData||{}; });
  if(vip&&vip.attach) vip.attach(g.userData);
  return g;
}
function setModelAccent(model, hex){ if(CHARS[model.userData.id].vip) return; const sk=CHARS[model.userData.id].skins[0]; for(const m of model.userData.accentMats) if(m&&m.color) m.color.set(hex||sk[0]); }
/* hayalet geçiş görseli: yarı saydam + parıltı */
Game.applyGhost=function(model,a){ if(!model) return; for(const m of model.userData.mats){ if(m===model.userData.eyeMat||m===model.userData.glowMat){ continue; } if(m.userData&&m.userData.keepEm){ m.transparent=a>0; m.opacity=a>0?.5:1; m.depthWrite=a<=0; continue; } m.transparent=a>0; m.opacity=a>0?.38:1; m.depthWrite=a<=0; if(m.emissive) m.emissive.setRGB(a*.1,a*.25,a*.5); } };
