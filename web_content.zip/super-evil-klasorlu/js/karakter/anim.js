"use strict";
/* ===== ANİMASYON: yürüyüş/koşu döngüsü, nefes, iniş, uçuş pozları, güç hareketleri, pelerin simülasyonu ===== */
Game.Anim=(function(){
  const H=Game.H, A=Game.input.actions, hero=Game.heroObj, on=n=>Game.powersOn[n]!==false;
  const BONES=["root","spine","chest","neck","head","shL","elL","hdL","shR","elR","hdR","hpL","knL","ftL","hpR","knR","ftR"];
  const ZERO=[0,0,0], sm=(a,b,x)=>{ const t=Math.max(0,Math.min(1,(x-a)/(b-a))); return t*t*(3-2*t); };
  const lerp=(a,b,t)=>a+(b-a)*t, PI=Math.PI;
  /* zamanlı eylem (yumruk, alkış, meteor…): Game.act("punch",.4,side) */
  Game.heroAct={name:"",t:9,dur:0,side:1}; let punchSide=1;
  Game.act=function(name,dur,side){ const a=Game.heroAct; a.name=name; a.t=0; a.dur=dur||.5; a.side=side||1; };
  Game.nextPunchSide=()=>{ punchSide=-punchSide; return punchSide; };

  let TG={};
  const set=(n,x,y,z)=>{ TG[n]=[x||0,y||0,z||0]; };
  const arm=(s,f,abd,el)=>{ const k=s>0?"R":"L"; set("sh"+k,-f,0,(s>0?1:-1)*(abd||0)); set("el"+k,-(el||0),0,0); };
  const leg=(s,f,abd,kn,ft)=>{ const k=s>0?"R":"L"; set("hp"+k,-f,0,(s>0?1:-1)*(abd||0)); set("kn"+k,kn||0,0,0); set("ft"+k,ft||0,0,0); };

  function locomotion(u,dt,time){
    const fly=H.flying, hv=H.hv, sp=H.speed, f=Math.min(1,sp/38);
    u.ph+= (5+hv*.9)*dt*(fly?0:1);
    const amp=fly?0:Math.min(1,hv/9), ph=u.ph, c=Math.cos(ph), s=Math.sin(ph), br=Math.sin(time*1.9);
    let rootY=0, lean=0, chestX=0, headX=0, headY=0;
    /* ivme ve dönüş: kalkışta öne, frenlemede geriye yaslan; dönüşe doğru yat */
    const accRaw=dt>0?(sp-(u.spPrev===undefined?sp:u.spPrev))/dt:0; u.spPrev=sp; u.acc=(u.acc||0)+(accRaw-(u.acc||0))*(1-Math.exp(-dt*6));
    const accL=Math.max(-.22,Math.min(.2,u.acc*.012))*(fly?0:1)*Math.min(1,hv/3), bank=Math.max(-.3,Math.min(.3,-H.turn*(fly?.16:.09)))*(fly?1.4:Math.min(1,hv/6));
    u.idleT=(!fly&&H.grounded&&hv<.6)?(u.idleT||0)+dt:0;
    if(fly){
      const boost=H.boost, hover=1-f;
      // üstten yatık vücutta kollar: yumruk ileri (sağ), sol yanda; boost'ta ikisi ileri
      arm(1,lerp(.35,PI-.12,f),lerp(.25,.06,f),lerp(.4,.05,f));
      if(boost||sp>110) arm(-1,PI-.14,.1,.05); else arm(-1,lerp(.3,-.12,f),lerp(.3,.1,f),lerp(.5,.15,f));
      const sw=Math.sin(time*2.6)*(.12*hover+.04);
      leg(1,lerp(-.1+sw,-.18,f),lerp(.12,.04,f),lerp(.35,.12,f)+hover*.15*Math.sin(time*2.2),lerp(.25,.9,f));
      leg(-1,lerp(.1-sw,-.12,f),lerp(.12,.04,f),lerp(.5,.1,f)+hover*.15*Math.sin(time*2.2+1),lerp(.25,.9,f));
      chestX=-.12*f+hover*.04*br; headX=-.35*f-.0; rootY=hover*.03*br;
    } else if(!H.grounded&&H.vel.y<-6){            // düşüş: kollar havada
      const fl=Math.sin(time*14)*.15; arm(1,2.2+fl,.7,.3); arm(-1,2.2-fl,.7,.3); leg(1,.5,.15,.7,.3); leg(-1,-.2,.15,.9,.3); chestX=.1; headX=-.2;
    } else if(!H.grounded&&H.vel.y>3){              // sıçrama / yükselme
      arm(1,1.6,.5,.5); arm(-1,1.3,.5,.6); leg(1,.8,.1,1.1,.5); leg(-1,-.1,.1,.4,.7); chestX=.08;
    } else {
      // yer: yürüme/koşma + durma
      const run=sm(5,13,hv);
      const swing=lerp(.55,1.15,run)*amp, kneeB=lerp(.25,1.3,run)*amp;
      leg(1,s*swing,.04,Math.max(0,Math.sin(ph+PI*.5+.4))*kneeB+.06,Math.max(0,-s)*.3-Math.max(0,s)*.12);
      leg(-1,-s*swing,.04,Math.max(0,Math.sin(ph-PI*.5+.4))*kneeB+.06,Math.max(0,s)*.3-Math.max(0,-s)*.12);
      const as=lerp(.5,1.1,run)*amp, ae=lerp(.25,1.5,run)*amp+.12;
      arm(1,-s*as,.08,ae+Math.max(0,s)*.2*amp); arm(-1,s*as,.08,ae+Math.max(0,-s)*.2*amp);
      if(amp<.08){ const ib=Math.sin(time*1.7)*.03; arm(1,ib,.1+Math.abs(ib)*.5,.14); arm(-1,-ib,.1+Math.abs(ib)*.5,.14); leg(1,0,.05,.04,0); leg(-1,0,.05,.04,0); }
      rootY=-Math.abs(c)*.07*amp*(.5+run)+(1-amp)*Math.sin(time*1.7)*.008; lean=Math.min(.42,hv/34)*(.4+run*.6)+accL; chestX=lean*.6+Math.sin(time*1.7)*.015*(1-amp); headX=-lean*.5+.0;
      const tw=s*(.18+run*.2)*amp; set("chest",chestX,tw,c*.04*amp); set("spine",lean*.4,-tw*.55,0); set("root",lean*.2,0,s*.05*amp);
      if(amp<.08){ headY=Math.sin(time*.45)*.3*Math.max(0,Math.sin(time*.23));
        /* uzun beklemede kötü adam duruşu: kollar kavuşturulur, çene yukarı, ağır bakış */
        const q=(u.idleT||0)%18, vil=sm(6,6.9,q)*(1-sm(12,12.9,q));
        if(vil>.01){ arm(1,lerp(.14,.86,vil),lerp(.1,-.5,vil),lerp(.14,2.15,vil)); arm(-1,lerp(.14,.86,vil),lerp(.1,-.5,vil),lerp(.14,2.15,vil)); chestX-=.08*vil; headX=-.12*vil; headY=Math.sin(time*.35)*.42*vil; set("spine",-.05*vil,0,0); set("root",0,0,0); leg(1,.0,.1,.05,0); leg(-1,.0,-.0+.14*vil,.06,0); TG.hpL[2]=-.14*vil-.02; } }
    }
    // iniş çömelmesi
    if(H.landT>.02&&!fly){ const l=H.landT; rootY-=l*.32; TG.hpR=[-(.2+l*.9),0,.05]; TG.hpL=[-(.2+l*.9),0,-.05]; TG.knR=[.15+l*1.5,0,0]; TG.knL=[.15+l*1.5,0,0]; chestX+=l*.35; }
    if(!TG.chest) set("chest",chestX,0,0); else TG.chest[0]=chestX;
    if(!TG.spine) set("spine",0,0,0); if(!TG.root) set("root",lean*.0,0,0);
    TG.root[2]+=bank; TG.chest[2]+=bank*.5; TG.rootY=rootY; set("neck",0,0,0); set("head",headX,headY,0);
  }
  /* eylemler: yalnızca ilgili uzuvların hedefini ezer */
  function actions(u,dt,time){
    const a=Game.heroAct; let nm="", t=0, d=1, s=1;
    if(a.t<a.dur){ nm=a.name; t=a.t; d=a.dur; s=a.side; }
    else if(A.laser&&on("laser")) nm=(CHARS[u.id]&&CHARS[u.id].mouthFire)?"breath":"laser"; else if((A.freeze&&on("freeze"))||(A.fire&&on("fire"))||(Game.Mythic&&Game.Mythic.breathing)) nm="breath"; else if(Game.Lift&&Game.Lift.active) nm="lift"; else if(A.choke&&on("choke")) nm="choke";
    u.act=nm; if(!nm) return;
    const grounded=H.grounded&&!H.flying, braced=grounded?1:0;
    if(nm==="punch"){ const k=t/d, wind=sm(0,.28,k), strike=sm(.28,.5,k), rec=sm(.62,1,k), w=wind*(1-strike)+0, st=strike*(1-rec);
      arm(s,lerp(-.2,-1,w)+st*2.55,.1,lerp(.4,1.7,w)*(1-strike)+(.12)*strike+(1-wind)*.4+rec*.3); arm(-s,.9,.1,1.75);
      TG.chest=[.12,s*(-.55*w+.6*st),0]; TG.spine=[.08,s*(-.2*w+.25*st),0]; if(braced){ leg(s,-.35-st*.1,.12,.15); leg(-s,.5*st+.1,.12,.35+st*.2,0); TG.rootY=-.05; }
      TG.head=[-.1,0,0]; }
    else if(nm==="clap"){ const k=t/d, open=sm(0,.22,k)*(1-sm(.24,.36,k)), cl=sm(.24,.36,k);
      arm(1,lerp(.3,1.5,cl),lerp(.1,1.5,open)-cl*.62,lerp(.3,.55,cl)); arm(-1,lerp(.3,1.5,cl),lerp(.1,1.5,open)-cl*.62,lerp(.3,.55,cl)); TG.chest=[-.15*open+.1*cl,0,0]; TG.head=[-.1+.2*cl,0,0];
      if(braced){ leg(1,0,.2,.25); leg(-1,0,.2,.25); } }
    else if(nm==="laser"){ arm(1,.15,.3,.5); arm(-1,.15,.3,.5); TG.chest=[-.1,0,0]; TG.head=[-H.pitch*.8,0,0]; if(braced){ leg(1,.1,.18,.12); leg(-1,-.1,.18,.12); }
      TG.shake=.02; }
    else if(nm==="breath"){ const r=sm(0,.3,u.actT||0); arm(1,lerp(.2,1.95,r),-.1,lerp(.3,2.1,r)); arm(-1,lerp(.2,1.95,r),-.1,lerp(.3,2.1,r)); TG.chest=[-.22*r+Math.sin(time*9)*.04,0,0]; TG.head=[-.3*r-H.pitch*.5,0,0]; if(braced){ leg(1,.1,.15,.2); leg(-1,-.1,.15,.2); } }
    else if(nm==="choke"){ arm(1,1.5,.1,.25+Math.sin(time*28)*.05); arm(-1,1.25,-.15,.95); TG.chest=[.08,.25,0]; TG.head=[.12,0,0]; if(braced){ leg(1,.3,.1,.2); leg(-1,-.3,.1,.2); } }
    else if(nm==="lift"){ const w=Math.min(1.6,Game.Lift.weight||1), q=Math.sin(time*(14+w*3))*.012*w;
      if(braced){ arm(1,2.88+q,.16,.28); arm(-1,2.88-q,.16,.28); TG.chest=[-.1-.03*w,0,0]; TG.spine=[-.05,0,0]; TG.head=[-.28,0,0]; leg(1,.22+.05*w,.15,.28+.1*w); leg(-1,-.22-.05*w,.15,.28+.1*w); TG.rootY=-.05-.03*w; TG.shake=.012*w; }
      else { arm(1,1.7+q,.26,.35); arm(-1,1.7-q,.26,.35); TG.chest=[-.12,0,0]; TG.head=[-H.pitch*.6-.1,0,0]; TG.shake=.012*w; } }
    else if(nm==="meteor"){ const r=sm(0,.4,t/d*d), hold=1; arm(1,lerp(.4,3.05,r),.1,.1); arm(-1,-.35,.7,.3); TG.chest=[-.18*r,0,0]; TG.head=[-.7*r,0,0]; if(braced){ leg(1,.15,.2,.2); leg(-1,-.15,.2,.2); } }
    else if(nm==="lightning"){ const sh=Math.sin(time*40)*.04; arm(1,1.5+sh,.4,.1); arm(-1,1.5-sh,.4,.1); TG.chest=[.05,0,0]; TG.head=[-.05,0,0]; if(braced){ leg(1,.3,.14,.2); leg(-1,-.3,.14,.2); } }
    else if(nm==="gravity"){ arm(1,1.55,.1,.2); arm(-1,.6,-.1,1.3); TG.chest=[.12,.2,0]; if(braced){ leg(1,.3,.12,.3); leg(-1,-.25,.12,.2); TG.rootY=-.06; } }
    else if(nm==="timeslow"){ const w=Math.sin(time*2.2)*.25; arm(1,.25,1.15+w,.3); arm(-1,.25,1.15-w,.3); TG.chest=[-.05,0,0]; TG.head=[-.15,Math.sin(time*1.2)*.2,0]; }
    else if(nm==="land"){ /* kahramanca iniş: bir diz yerde, yumruk yerde, diğer kol geride, baş eğik; sonda yavaşça kalkar */
      const w=sm(0,.07,t)*(1-sm(d-.42,d,t)), sk=1-sm(d-.42,d,t)*.0;
      arm(1,.95*w,.12,.16*w); arm(-1,-.5*w,.75*w,.4*w); leg(1,1.5*w,.06,1.8*w,.1*w); leg(-1,-.15*w,.1,1.7*w,.5*w);
      TG.chest=[.6*w,.1*w,0]; TG.spine=[.3*w,0,0]; TG.head=[.25*w,0,0]; TG.rootY=-.42*w; TG.root=[0,-.15*w,0]; }
    else if(nm==="quake"){ const k=t/d, w=sm(0,.4,k)*(1-sm(.42,.5,k)), sl=sm(.42,.55,k)*(1-sm(.7,1,k));
      arm(1,lerp(.2,-.9,w)+sl*1.45,.1,lerp(.4,.6,w)); arm(-1,lerp(.2,-.9,w)+sl*1.45,.1,lerp(.4,.6,w)); TG.chest=[.1+.65*sl-.2*w,0,0]; TG.spine=[.3*sl,0,0]; TG.head=[-.1+.15*sl,0,0];
      if(braced){ const c=w*1.2+sl*.9; leg(1,.9*c*.5,.12,c); leg(-1,.9*c*.5,.12,c); TG.rootY=-.3*c; } }
  }
  /* pelerin: satır zinciri, rüzgâr + yer çekimi, hız ve dönüşe göre gecikme */
  const hv3={x:0,y:0,z:0};
  function cape(u,dt,time){
    const geo=u.capeGeo; if(!geo) return; const pa=geo.attributes.position, base=u.capeBase, rows=u.capeRows, cols=u.capeCols, CH=u.capeH, seg=CH/rows;
    if(!u.capeDir){ u.capeDir=new Float32Array((rows+1)*3); for(let i=0;i<=rows;i++){ u.capeDir[i*3+1]=-1; } }
    const dirs=u.capeDir, v=H.vel, sp=H.speed, sN=Math.min(1,sp/60), ry=hero.rotation.y, rx=hero.rotation.x, cy=Math.cos(ry), sy=Math.sin(ry), cx=Math.cos(rx), sx=Math.sin(rx);
    const wl=(x,y,z,o)=>{ const X=x*cy-z*sy, Z=x*sy+z*cy; o.x=X; o.y=y*cx+Z*sx; o.z=-y*sx+Z*cx; return o; };
    const gW=1-.6*sN, spd=Math.max(sp,1), wk=Math.min(1.7,sp*.05), scarf=u.scarf;
    let px=0, py=0, pz=0, flare=1+sN*.15; const jag=u.capeJag;
    for(let i=0;i<=rows;i++){ const dep=i/rows;
      if(i>0){ const tx=0*gW+(-v.x/spd)*wk*dep, ty=-1*gW*(scarf?.7:1)+(-v.y/spd)*wk*dep, tz=0+(-v.z/spd)*wk*dep; wl(tx,ty,tz,hv3);
        hv3.x+=Math.sin(time*7+dep*6.5)*.09*dep*(.3+sN*1.2)+(-H.turn*.25*dep); hv3.z+=Math.sin(time*5.3+dep*5)*.1*dep*(.3+sN)-.1;
        const l=Math.hypot(hv3.x,hv3.y,hv3.z)||1; hv3.x/=l; hv3.y/=l; hv3.z/=l;
        const k=1-Math.exp(-dt*(22/(1+dep*3.2))); dirs[i*3]+=(hv3.x-dirs[i*3])*k; dirs[i*3+1]+=(hv3.y-dirs[i*3+1])*k; dirs[i*3+2]+=(hv3.z-dirs[i*3+2])*k;
        const dl=Math.hypot(dirs[i*3],dirs[i*3+1],dirs[i*3+2])||1; px+=dirs[i*3]/dl*seg; py+=dirs[i*3+1]/dl*seg; pz+=dirs[i*3+2]/dl*seg; if(pz>-.03-dep*.05) pz=-.03-dep*.05-0; }
      const w=1+dep*.35*flare+Math.sin(time*6+dep*5)*.03*dep*sN;
      for(let j=0;j<=cols;j++){ const k=(i*(cols+1)+j)*3; pa.array[k]=base[k]*w+px; pa.array[k+1]=py-(jag?jag(j,dep,time):0); pa.array[k+2]=pz+Math.sin(time*9+dep*4+j*.9)*.03*dep*(.2+sN); } }
    pa.needsUpdate=true; if(geo.computeVertexNormals&&((u.t*30)|0)%2===0) geo.computeVertexNormals();
  }
  function extras(u,dt,time){
    const e=u.eyeMat, laser=u.act==="laser"; if(e&&e.color&&u._las!==laser){ u._las=laser; e.color.setHex(laser?(u.laserHex!=null?u.laserHex:CHARS[u.id].laser):(u.eyeHex!=null?u.eyeHex:CHARS[u.id].eye)); }
    if(u.vip) u.vip.update(dt,time,u);
    if(u.tail){ const sp=H.speed; for(let i=0;i<u.tail.length;i++){ const sg=u.tail[i]; sg.rotation.y=Math.sin(time*3-i*.7)*(.14+Math.min(.2,sp*.01))-H.turn*.1; sg.rotation.x=(H.flying?.12:-.04)+Math.sin(time*2-i*.5)*.05; } }
    if(u.wings){ const fl=H.flying; for(let i=0;i<2;i++){ const s=i===0?-1:1, w=u.wings[i], flap=fl?(.45+Math.sin(time*(H.boost?14:7))*(H.boost?.25:.55)):-.55; w.rotation.z=lerp(w.rotation.z,s*flap,1-Math.exp(-10*dt)); w.rotation.y=lerp(w.rotation.y,s*(fl?-.3:-.8),1-Math.exp(-6*dt)); } }
  }
  /* kemik yayları: kritik-altı sönümlü (ζ<1) — eylem başlarken hafif aşma/devam hareketi (follow-through), durunca yumuşak oturma */
  const ZW={root:1.1,spine:1.15,chest:1.2,neck:1.1,head:1.0,shL:1.7,elL:1.7,hdL:1.5,shR:1.7,elR:1.7,hdR:1.5,hpL:1.6,knL:1.6,ftL:1.5,hpR:1.6,knR:1.6,ftR:1.5};
  const ZZ={root:.86,spine:.82,chest:.74,neck:.72,head:.62,shL:.64,elL:.72,hdL:.55,shR:.64,elR:.72,hdR:.55,hpL:.8,knL:.82,ftL:.72,hpR:.8,knR:.82,ftR:.72};
  function apply(u,dt,rate){
    const R=u.rig, cur=u.cur, cv=u.cv||(u.cv={}), steps=Math.max(1,Math.min(8,Math.ceil(dt/.0167))), h=dt/steps;
    for(const n of BONES){ const b=R[n]; if(!b) continue; const t=TG[n]||ZERO, c=cur[n]||(cur[n]=[0,0,0]), v=cv[n]||(cv[n]=[0,0,0]), w=rate*(ZW[n]||1.2), z=ZZ[n]||.8;
      for(let s=0;s<steps;s++) for(let a=0;a<3;a++){ const acc=w*w*(t[a]-c[a])-2*z*w*v[a]; v[a]+=acc*h; c[a]+=v[a]*h; }
      b.rotation.set(c[0],c[1],c[2]); }
    if(R.mount){ R.mount.rotation.x=-((cur.shR?cur.shR[0]:0)+(cur.elR?cur.elR[0]:0))+.12; R.mount.rotation.z=-(cur.shR?cur.shR[2]:0)*.6; }
    const ry=TG.rootY||0; cur.ry=(cur.ry||0)+(ry-(cur.ry||0))*(1-Math.exp(-dt*14)); R.root.position.y=cur.ry+(TG.shake?Math.sin(u.t*70)*TG.shake:0);
  }
  /* ana menü: kahramanca duruş + nefes + sürekli rüzgârlı pelerin (oyun durumundan bağımsız; H durumu geçici değiştirilip geri yüklenir) */
  function menuPose(m,dt,time,wx,wz){ const u=m.userData; if(!u||!u.rig) return; u.t=(u.t||0)+dt; TG={};
    const br=Math.sin(time*1.6), sw=Math.sin(time*.7);
    arm(1,.06+.02*br,.34,.72); arm(-1,.1-.02*br,.34,.8); leg(1,-.05,.16,.06,0); leg(-1,.1,.14,.1,0);
    set("spine",.04+.01*br,-.06,0); set("chest",.06+.02*br,.1,0); set("neck",0,0,0); set("head",.09+.02*Math.sin(time*.9),-.12+.1*sw,0); set("root",0,.05,0); TG.rootY=.012*br;
    apply(u,dt,8);
    const sv=H.vel.x, sy=H.vel.y, sz=H.vel.z, ss=H.speed, st=H.turn, sf=H.flying, ry=hero.rotation.y, rx=hero.rotation.x;
    H.vel.set(wx,0,wz); H.speed=Math.hypot(wx,wz); H.turn=0; H.flying=false; hero.rotation.y=m.rotation.y+(m.parent?m.parent.rotation.y:0); hero.rotation.x=0;
    u.menuWind={x:wx,y:0,z:wz}; cape(u,dt,time); extras(u,dt,time); u.menuWind=null;
    H.vel.set(sv,sy,sz); H.speed=ss; H.turn=st; H.flying=sf; hero.rotation.y=ry; hero.rotation.x=rx; }
  const api={
    menuPose,
    reset(m){ const u=m.userData; u.cur={}; u.cv={}; u.capeDir=null; u.ph=0; u.t=0; u.idleT=0; u.acc=0; u.spPrev=undefined; if(u.vip&&u.vip.reset) u.vip.reset(); },
    update(dt,time){ const m=Game.model; if(!m) return; const u=m.userData; u.t+=dt; TG={}; const a=Game.heroAct; if(a.t<a.dur) a.t+=dt;
      u.actT=(u.act?(u.actT||0)+dt:0);
      locomotion(u,dt,time); actions(u,dt,time); if(!u.act) u.actT=0; apply(u,dt,H.flying?9:13); cape(u,dt,time); extras(u,dt,time); },
    /* mağaza önizlemesi: kahramanca duruş, pelerin asılı */
    preview(m){ const u=m.userData; TG={}; arm(1,.3,.4,.75); arm(-1,.15,.75,1.9); if(u.rig.mount) u.rig.mount.rotation.x=-(-.3-.75)+.12; leg(1,-.1,.14,.05); leg(-1,.12,.1,.12); set("chest",-.05,-.12,0); set("spine",0,.0,0); set("head",-.06,-.2,0); set("root",0,0,0); TG.rootY=0;
      const cur={}; for(const n of BONES){ const b=u.rig[n]; if(b){ const t=TG[n]||ZERO; b.rotation.set(t[0],t[1],t[2]); } }
      if(u.tail) u.tail.forEach((s,i)=>{ s.rotation.y=.35+i*.05; }); if(u.wings) u.wings.forEach((w,i)=>{ w.rotation.z=(i?1:-1)*-.2; w.rotation.y=(i?1:-1)*-.5; });
      if(u.capeGeo){ u.capeDir=null; const saveH=H.vel.x; for(let k=0;k<30;k++) cape(u,.05,k*.05); }
      if(u.vip&&u.vip.rest) u.vip.rest(); }
  };
  Game.updaters.push((dt0,time,raw)=>{ if(Game.mode!=="play") return; api.update(raw||dt0,time); });
  return api;
})();
