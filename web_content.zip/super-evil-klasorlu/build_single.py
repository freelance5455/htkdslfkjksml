#!/usr/bin/env python3
"""Klasörlü projeden TEK dosyalık oyunu üretir: python3 build_single.py  ->  super-kahraman.html (iPad/Safari'de direkt açılır)."""
import re,os
D=os.path.dirname(os.path.abspath(__file__))+"/"; r=lambda p: open(D+p,encoding="utf-8").read()
idx=r("index.html"); order=[l.strip() for l in open(D+"yukleme_sirasi.txt") if l.strip()]
css="".join(r(m) for m in re.findall(r'<link rel="stylesheet" href="([^"]+)">',idx))
body="\n".join("/* >>> "+p.split("/")[-1]+" */\n"+re.sub(r'^"use strict";\n','',r(p)) for p in order)
head=idx.split("<link rel=\"stylesheet\"")[0]
tail=idx[idx.index("<body>"):]; tail=re.sub(r'<script src="js/[^"]+"></script>\n?','',tail).replace("</body>",'<script>\n"use strict";\n'+body+"\n</script>\n</body>")
out=head+"<style>\n"+css+"\n</style>\n</head>\n"+tail
open(D+"super-kahraman.html","w",encoding="utf-8").write(out); print("super-kahraman.html",len(out))
