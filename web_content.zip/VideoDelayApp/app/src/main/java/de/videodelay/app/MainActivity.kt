package de.videodelay.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.view.WindowManager
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.webkit.WebViewAssetLoader

class MainActivity : Activity() {

    private lateinit var web: WebView
    private var pending: PermissionRequest? = null
    private var customView: View? = null
    private var customCb: WebChromeClient.CustomViewCallback? = null
    private lateinit var chrome: WebChromeClient

    @Suppress("DEPRECATION")
    private fun bars(hide: Boolean) {
        window.decorView.systemUiVisibility = if (hide)
            View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        else View.SYSTEM_UI_FLAG_VISIBLE
    }

    private fun hasCamera() =
        checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        web = WebView(this)
        setContentView(web)

        // Kameraerlaubnis gleich beim Start abfragen
        if (!hasCamera()) requestPermissions(arrayOf(Manifest.permission.CAMERA), 1)

        // Liefert assets/index.html über https://appassets.androidplatform.net (sicherer Kontext, Kamera erlaubt)
        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
        }

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView, request: WebResourceRequest
            ): WebResourceResponse? = loader.shouldInterceptRequest(request.url)

            // Fehleranzeige und Ausweichen auf die direkte Asset-Datei, falls die https-Adresse nicht lädt
            override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                if (!request.isForMainFrame) return
                Toast.makeText(
                    this@MainActivity,
                    "Fehler ${error.errorCode}: ${error.description}\n${request.url}",
                    Toast.LENGTH_LONG
                ).show()
                if (request.url.host == "appassets.androidplatform.net") {
                    view.loadUrl("file:///android_asset/index.html")
                }
            }

            override fun onReceivedHttpError(
                view: WebView, request: WebResourceRequest, errorResponse: WebResourceResponse
            ) {
                if (!request.isForMainFrame) return
                Toast.makeText(
                    this@MainActivity,
                    "HTTP ${errorResponse.statusCode} für ${request.url}",
                    Toast.LENGTH_LONG
                ).show()
            }
        }

        chrome = object : WebChromeClient() {
            override fun onShowCustomView(view: View, callback: CustomViewCallback) {
                customView = view
                customCb = callback
                setContentView(view)
                bars(true)
            }

            override fun onHideCustomView() {
                customCb?.onCustomViewHidden()
                customView = null
                customCb = null
                setContentView(web)
                bars(false)
            }

            override fun onPermissionRequest(request: PermissionRequest) {
                runOnUiThread {
                    if (hasCamera()) {
                        request.grant(arrayOf(PermissionRequest.RESOURCE_VIDEO_CAPTURE))
                    } else {
                        pending = request
                        requestPermissions(arrayOf(Manifest.permission.CAMERA), 1)
                    }
                }
            }
        }

        web.webChromeClient = chrome
        web.loadUrl("https://appassets.androidplatform.net/assets/index.html")
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        val granted = results.isNotEmpty() && results[0] == PackageManager.PERMISSION_GRANTED
        val req = pending
        pending = null
        if (req != null) {
            if (granted) req.grant(arrayOf(PermissionRequest.RESOURCE_VIDEO_CAPTURE)) else req.deny()
        }
        if (!granted && !shouldShowRequestPermissionRationale(Manifest.permission.CAMERA)) {
            // Dauerhaft abgelehnt: App-Einstellungen öffnen
            Toast.makeText(this, "Bitte Kamera in den App-Einstellungen erlauben", Toast.LENGTH_LONG).show()
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + packageName))
            )
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (customView != null) { chrome.onHideCustomView(); return }
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}
