Video-Delay App (Android Studio Projekt, komplett offline)

1. Modelldateien einmalig laden (Internet nötig, nur auf dem Rechner):
   Windows: tools\download_models.bat doppelklicken
   Mac/Linux: sh tools/download_models.sh
   Danach liegen die Dateien in app/src/main/assets/mediapipe/
   (vision_bundle.js, pose_landmarker_lite.task, Ordner wasm mit 4 Dateien).
   Falls ein Download fehlschlägt: das Paket @mediapipe/tasks-vision@0.10.14 von npm laden
   (npm pack) und daraus vision_bundle.mjs (als vision_bundle.js speichern) und den ganzen
   Ordner wasm kopieren.
2. ZIP-Ordner in Android Studio öffnen ("Open"), Gradle-Sync abwarten.
3. APK bauen: Build > Build Bundle(s) / APK(s) > Build APK(s)
   Die Datei liegt unter app/build/outputs/apk/debug/app-debug.apk
4. APK aufs Handy kopieren und installieren.

Die App hat nur die Kamera-Berechtigung, keine Internet-Berechtigung.
