Video-Delay App (Android Studio Projekt)

1. ZIP entpacken, in Android Studio "Open" und den Ordner VideoDelayApp wählen.
2. Gradle-Sync abwarten (Internet nötig). Falls Android Studio ein Upgrade vorschlägt, ruhig annehmen.
3. APK bauen: Build > Build Bundle(s) / APK(s) > Build APK(s)
   Die Datei liegt danach unter app/build/outputs/apk/debug/app-debug.apk
4. APK aufs Handy kopieren und installieren (Installation aus unbekannten Quellen erlauben),
   oder das Handy per USB anschließen und in Android Studio auf "Run" klicken.

Die App öffnet assets/index.html in einer WebView. Dort lässt sich die Seite jederzeit austauschen.
Die Handgelenkerkennung lädt ihr Modell beim Einschalten des Trackings aus dem Internet.
Berechtigungen: Kamera und Internet.
