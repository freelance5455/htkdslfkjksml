@echo off
rem Laedt Erkennungsmodell und MediaPipe-Dateien einmalig ins Projekt (Internet noetig)
set D=%~dp0..\app\src\main\assets\mediapipe
set B=https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14
mkdir "%D%\wasm" 2>nul
curl.exe -fL -o "%D%\vision_bundle.js" "%B%/vision_bundle.mjs"
for %%f in (vision_wasm_internal.js vision_wasm_internal.wasm vision_wasm_nogpu_internal.js vision_wasm_nogpu_internal.wasm) do curl.exe -fL -o "%D%\wasm\%%f" "%B%/wasm/%%f"
curl.exe -fL -o "%D%\pose_landmarker_lite.task" "https://storage.googleapis.com/mediapipe-models/pose_landmarker/pose_landmarker_lite/float16/1/pose_landmarker_lite.task"
echo Fertig.
