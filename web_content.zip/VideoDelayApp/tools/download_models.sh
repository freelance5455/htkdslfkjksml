#!/bin/sh
# Lädt Erkennungsmodell und MediaPipe-Dateien einmalig ins Projekt (Internet nötig)
set -e
D="$(dirname "$0")/../app/src/main/assets/mediapipe"
B="https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14"
mkdir -p "$D/wasm"
curl -fL -o "$D/vision_bundle.js" "$B/vision_bundle.mjs"
for f in vision_wasm_internal.js vision_wasm_internal.wasm vision_wasm_nogpu_internal.js vision_wasm_nogpu_internal.wasm; do
  curl -fL -o "$D/wasm/$f" "$B/wasm/$f"
done
curl -fL -o "$D/pose_landmarker_lite.task" "https://storage.googleapis.com/mediapipe-models/pose_landmarker/pose_landmarker_lite/float16/1/pose_landmarker_lite.task"
echo "Fertig."
