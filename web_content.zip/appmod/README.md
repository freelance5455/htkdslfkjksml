# APP MOD

## Lancer en local (Node.js 20.6+ requis)
1. `npm install`
2. `cp .env.example .env` puis modifiez ADMIN_EMAIL, ADMIN_CODE et SESSION_SECRET
3. `npm start` → http://localhost:3000

## Administration
Allez sur `/admin`. Connexion = e-mail admin + code (défini dans `.env`, haché au démarrage, jamais exposé côté public). 5 échecs = blocage 15 min.
Ajoutez vos apps (icône, image, fichier privé, prix, publication), gérez catégories, commandes, utilisateurs et votre profil public.

## Paiement
Sans `STRIPE_SECRET_KEY` : paiement simulé (démo). Avec une clé Stripe : vrai Stripe Checkout, fichier débloqué après vérification du paiement.

## Déploiement
Sur Render, Railway ou un VPS : build `npm install`, start `npm start`, variables du `.env` dans l'interface, NODE_ENV=production, HTTPS obligatoire. Conservez un disque persistant pour `data.db`, `private/` et `public/uploads/`. Sauvegardez ces trois éléments.
Avant la mise en ligne : complétez CGU, mentions légales, confidentialité et remboursement (pages `#/page/...` dans index.html).
