#!/usr/bin/env python3
"""Create and integrity-check a private StudyVault database + uploads backup."""
from __future__ import annotations
import argparse
import sqlite3
import sys
import tempfile
import zipfile
from datetime import datetime, timezone
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--data-dir', default='data', help='StudyVault DATA_DIR (default: ./data)')
    parser.add_argument('--output-dir', default='backups', help='Private output directory (default: ./backups)')
    args = parser.parse_args()

    data_dir = Path(args.data_dir).expanduser().resolve()
    db_path = data_dir / 'studyvault.sqlite'
    uploads = data_dir / 'uploads'
    if not db_path.is_file():
        print(f'ERROR: database not found: {db_path}', file=sys.stderr)
        return 2

    output_dir = Path(args.output_dir).expanduser().resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    output_path = output_dir / f'studyvault-backup-{stamp}.zip'

    # SQLite's backup API includes committed WAL content and avoids copying a live DB naively.
    with tempfile.TemporaryDirectory(prefix='studyvault-backup-') as temp:
        snapshot = Path(temp) / 'studyvault.sqlite'
        with sqlite3.connect(f'file:{db_path.as_posix()}?mode=ro', uri=True, timeout=10) as source:
            with sqlite3.connect(snapshot) as destination:
                source.backup(destination)
                result = destination.execute('PRAGMA integrity_check').fetchone()[0]
                if result != 'ok':
                    raise RuntimeError(f'SQLite integrity_check failed: {result}')
                tables = destination.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name").fetchall()

        with zipfile.ZipFile(output_path, 'w', compression=zipfile.ZIP_DEFLATED) as archive:
            archive.write(snapshot, 'database/studyvault.sqlite')
            if uploads.is_dir():
                for file in sorted(uploads.rglob('*')):
                    if file.is_file() and file.name != '.gitkeep':
                        archive.write(file, f'uploads/{file.relative_to(uploads).as_posix()}')

    with zipfile.ZipFile(output_path, 'r') as archive:
        bad_member = archive.testzip()
        if bad_member:
            output_path.unlink(missing_ok=True)
            raise RuntimeError(f'Backup archive integrity failed at {bad_member}')

    size = output_path.stat().st_size
    print(f'Backup created: {output_path}')
    print(f'SQLite integrity: ok; tables: {len(tables)}; archive size: {size} bytes')
    print('Store the archive privately. It contains account and order data plus potentially sensitive customer-uploaded payment proof.')
    return 0


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f'ERROR: {exc}', file=sys.stderr)
        raise SystemExit(1)
