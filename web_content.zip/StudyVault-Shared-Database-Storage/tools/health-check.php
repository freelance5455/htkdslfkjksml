<?php
/**
 * StudyVault PHP health-check utility.
 * Usage: php tools/health-check.php https://your-studyvault-host.example
 * This intentionally checks only the public health endpoint; it never accesses user data.
 */
declare(strict_types=1);

$base = $argv[1] ?? getenv('STUDYVAULT_BASE_URL') ?: '';
$base = rtrim(trim($base), '/');
if ($base === '' || !preg_match('~^https?://~i', $base)) {
    fwrite(STDERR, "Usage: php tools/health-check.php https://your-studyvault-host.example\n");
    exit(2);
}
$url = $base . '/api/health';
$context = stream_context_create([
    'http' => [
        'method' => 'GET',
        'timeout' => 8,
        'ignore_errors' => true,
        'header' => "Accept: application/json\r\nCache-Control: no-cache\r\n",
    ],
]);
$body = @file_get_contents($url, false, $context);
$statusLine = $http_response_header[0] ?? 'HTTP status unavailable';
if ($body === false) {
    fwrite(STDERR, json_encode(['ok' => false, 'url' => $url, 'error' => 'Health endpoint unreachable'], JSON_PRETTY_PRINT) . "\n");
    exit(1);
}
$decoded = json_decode($body, true);
$ok = str_contains($statusLine, ' 200 ') && is_array($decoded) && ($decoded['ok'] ?? false) === true;
echo json_encode(['ok' => $ok, 'url' => $url, 'http' => $statusLine, 'response' => $decoded ?? $body], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) . "\n";
exit($ok ? 0 : 1);
