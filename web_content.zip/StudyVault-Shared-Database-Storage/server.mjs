import http from 'node:http';
import path from 'node:path';
import fs from 'node:fs';
import fsp from 'node:fs/promises';
import crypto from 'node:crypto';
import { promisify } from 'node:util';
import { fileURLToPath } from 'node:url';
import { DatabaseSync } from 'node:sqlite';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.PORT || 8080);
const HOST = process.env.HOST || '0.0.0.0';
const IS_PROD = process.env.NODE_ENV === 'production';
const SESSION_DAYS = Math.min(30, Math.max(1, Number(process.env.SESSION_DAYS || 14)));
const MAX_PDF_BYTES = Math.min(50, Math.max(1, Number(process.env.MAX_PDF_MB || 25))) * 1024 * 1024;
const MAX_JSON_BYTES = Math.max(12 * 1024 * 1024, MAX_PDF_BYTES * 1.5 + 3 * 1024 * 1024);
const DATA_DIR = path.resolve(process.env.DATA_DIR || path.join(__dirname, 'data'));
const UPLOAD_DIR = path.join(DATA_DIR, 'uploads');
const RECEIPT_DIR = path.join(UPLOAD_DIR, 'receipts');
const PUBLIC_DIR = path.join(__dirname, 'public');
const DB_FILE = path.join(DATA_DIR, 'studyvault.sqlite');
const COOKIE_NAME = 'sv_session';
const scrypt = promisify(crypto.scrypt);

await fsp.mkdir(UPLOAD_DIR, { recursive: true });
await fsp.mkdir(RECEIPT_DIR, { recursive: true });
const db = new DatabaseSync(DB_FILE);
db.exec(await fsp.readFile(path.join(__dirname, 'schema.sql'), 'utf8'));

// Small forward-compatible migration for databases created by earlier project versions.
const orderColumns = new Set(db.prepare('PRAGMA table_info(orders)').all().map(c => c.name));
if (!orderColumns.has('pdf_path_snapshot')) {
  db.exec("ALTER TABLE orders ADD COLUMN pdf_path_snapshot TEXT NOT NULL DEFAULT ''");
}

const defaultSettings = {
  storeName: 'StudyVault', tagline: 'Your secure vault for learning',
  heroTitle: 'Study smarter with trusted reviewers',
  shopTitle: 'Explore Reviewers', shopSubtitle: 'Browse published PDF reviewers.',
  categoriesTitle: 'Browse by Subject', orderTitle: 'My Orders', orderSubtitle: 'Track your purchases.',
  supportTitle: 'Need help?', supportText: 'Contact the owner for help with your order.',
  ownerName: 'StudyVault Owner', supportEmail: '', paymentInstructions: 'Send the exact amount shown. Your download remains locked until the owner verifies the transfer.',
  refundPolicy: 'Please contact the owner before requesting a refund.', footerText: 'StudyVault · Learn with confidence', accent: '#245fe5',
  gCashName: '', gCashAccount: '', gcashQr: ''
};
if (!db.prepare('SELECT id FROM app_settings WHERE id=1').get()) {
  db.prepare('INSERT INTO app_settings(id,json) VALUES(1,?)').run(JSON.stringify(defaultSettings));
}

function now() { return new Date().toISOString(); }
function id(prefix) { return `${prefix}_${crypto.randomBytes(9).toString('base64url')}`; }
function token() { return crypto.randomBytes(32).toString('base64url'); }
function hashToken(value) { return crypto.createHash('sha256').update(value).digest('hex'); }
function safeEqual(a, b) {
  const aa = Buffer.from(String(a)); const bb = Buffer.from(String(b));
  return aa.length === bb.length && crypto.timingSafeEqual(aa, bb);
}
function hashPasswordSync(password) {
  const salt = crypto.randomBytes(16);
  const key = crypto.scryptSync(password, salt, 64);
  return `scrypt$${salt.toString('base64url')}$${key.toString('base64url')}`;
}
async function verifyPassword(password, stored) {
  const [algorithm, saltText, keyText] = String(stored || '').split('$');
  if (algorithm !== 'scrypt' || !saltText || !keyText) return false;
  const salt = Buffer.from(saltText, 'base64url');
  const expected = Buffer.from(keyText, 'base64url');
  const actual = await scrypt(String(password), salt, expected.length);
  return actual.length === expected.length && crypto.timingSafeEqual(actual, expected);
}

const ownerRow = db.prepare("SELECT id, username FROM users WHERE role='owner' LIMIT 1").get();
if (!ownerRow) {
  let ownerPassword = process.env.OWNER_PASSWORD;
  const ownerUsername = String(process.env.OWNER_USERNAME || 'owner').trim();
  if (!ownerPassword) {
    if (IS_PROD) throw new Error('OWNER_PASSWORD must be set before first production startup. Use a strong, unique password of at least 12 characters.');
    ownerPassword = token();
    console.warn('\n[StudyVault] Generated development-only owner login because OWNER_PASSWORD was not set.');
    console.warn(`[StudyVault] Owner username: ${ownerUsername}`);
    console.warn(`[StudyVault] Owner password (save it now): ${ownerPassword}\n`);
  }
  if (/^REPLACE_WITH_|^(change|changeme|password|admin123)/i.test(ownerPassword)) throw new Error('Replace the example/placeholder OWNER_PASSWORD with your own unique password before starting.');
  if (ownerPassword.length < 12) throw new Error('OWNER_PASSWORD must contain at least 12 characters.');
  if (!ownerUsername || ownerUsername.length > 60) throw new Error('OWNER_USERNAME must be 1–60 characters.');
  db.prepare(`INSERT INTO users(id,name,username,password_hash,role,must_change,created_at)
              VALUES(?,?,?,?, 'owner',0,?)`)
    .run(id('usr'), 'StudyVault Owner', ownerUsername, hashPasswordSync(ownerPassword), now());
}

class HttpError extends Error {
  constructor(status, message, code = '') { super(message); this.status = status; this.code = code; }
}
const sseClients = new Set();
const loginFailures = new Map();
function sendJson(res, status, data, headers = {}) {
  const body = JSON.stringify(data);
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff', ...headers });
  res.end(body);
}
function errorMessage(error) {
  if (error instanceof HttpError) return error.message;
  if (error?.message === 'UNIQUE constraint failed: users.email_norm') return 'An account with this email already exists.';
  if (error?.message === 'UNIQUE constraint failed: users.username') return 'That owner username is already in use.';
  return 'Something went wrong. Please try again.';
}
function parseCookies(req) {
  const out = {};
  for (const part of String(req.headers.cookie || '').split(';')) {
    const ix = part.indexOf('='); if (ix < 0) continue;
    const key = part.slice(0, ix).trim();
    try { out[key] = decodeURIComponent(part.slice(ix + 1).trim()); } catch {}
  }
  return out;
}
function resolveUser(req) {
  const raw = parseCookies(req)[COOKIE_NAME];
  if (!raw) return null;
  const row = db.prepare(`SELECT u.id,u.name,u.email,u.email_norm,u.username,u.role,u.must_change,s.expires_at
    FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=?`).get(hashToken(raw));
  if (!row) return null;
  if (Date.parse(row.expires_at) <= Date.now()) {
    db.prepare('DELETE FROM sessions WHERE token_hash=?').run(hashToken(raw));
    return null;
  }
  return { id: row.id, name: row.name, email: row.email || '', emailNorm: row.email_norm || '', username: row.username || '', role: row.role, mustChange: !!row.must_change };
}
function setSessionCookie(res, raw) {
  const secure = IS_PROD ? '; Secure' : '';
  res.setHeader('Set-Cookie', `${COOKIE_NAME}=${encodeURIComponent(raw)}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${SESSION_DAYS * 86400}${secure}`);
}
function clearSessionCookie(res) {
  const secure = IS_PROD ? '; Secure' : '';
  res.setHeader('Set-Cookie', `${COOKIE_NAME}=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0${secure}`);
}
function createSession(userId, res) {
  const raw = token();
  const created = now();
  const expires = new Date(Date.now() + SESSION_DAYS * 86400000).toISOString();
  db.prepare('INSERT INTO sessions(token_hash,user_id,expires_at,created_at) VALUES(?,?,?,?)').run(hashToken(raw), userId, expires, created);
  setSessionCookie(res, raw);
}
function publicCustomer(user) { return { id: user.id, name: user.name, email: user.email || '' }; }
function readSettings() {
  try { return { ...defaultSettings, ...JSON.parse(db.prepare('SELECT json FROM app_settings WHERE id=1').get().json) }; }
  catch { return { ...defaultSettings }; }
}
function writeSettings(value) {
  db.prepare('UPDATE app_settings SET json=? WHERE id=1').run(JSON.stringify(value));
}
function publicProduct(row) {
  if (!row) return null;
  return { id: row.id, title: row.title, subject: row.subject, description: row.description,
    price: Number(row.price), stock: Number(row.stock), active: !!row.active, cover: row.cover_data || '', createdAt: row.created_at, updatedAt: row.updated_at };
}
function getProduct(idValue) {
  return db.prepare('SELECT * FROM products WHERE id=?').get(idValue);
}
function productForOrder(order) {
  return order.product_title || (order.product_id ? getProduct(order.product_id)?.title : null) || 'Removed product';
}
function publicOrder(row, includePrivate = false) {
  const obj = {
    id: row.id, token: row.token, productId: row.product_id, productTitle: productForOrder(row),
    amount: Number(row.amount), amountPaid: row.amount_paid == null ? null : Number(row.amount_paid),
    customerName: row.customer_name, customerEmail: row.customer_email,
    customerGcashName: row.customer_gcash_name || '', customerGcashAccount: row.customer_gcash_account || '',
    status: row.status, paymentReference: row.payment_reference || '', createdAt: row.created_at,
    purchasedAt: row.created_at, approvedAt: row.approved_at || null, rejectionReason: row.rejection_reason || '',
    downloadCount: Number(row.download_count || 0),
    messageCount: Number(db.prepare('SELECT COUNT(*) AS n FROM messages WHERE order_id=?').get(row.id).n)
  };
  if (includePrivate) {
    const storedReceipt = row.payment_screenshot || '';
    // Older records may contain a data URL; new receipts are stored as private files.
    obj.paymentScreenshot = storedReceipt.startsWith('data:image/')
      ? storedReceipt
      : storedReceipt ? `/api/admin/orders/${encodeURIComponent(row.id)}/receipt` : '';
  }
  return obj;
}
function getOrderByToken(key) {
  return db.prepare('SELECT * FROM orders WHERE token=? OR id=? LIMIT 1').get(key, key);
}
function orderForCustomer(req, order) {
  if (!order) throw new HttpError(404, 'Order not found.');
  const user = req.user;
  if (user?.role === 'owner') return order;
  if (user?.role !== 'customer' || order.customer_user_id !== user.id) throw new HttpError(404, 'Order not found.');
  return order;
}
function requireCustomer(req) {
  if (!req.user || req.user.role !== 'customer') throw new HttpError(401, 'Please sign in to use this feature.');
  return req.user;
}
function requireOwner(req) {
  if (!req.user || req.user.role !== 'owner') throw new HttpError(401, 'Owner authentication required.');
  return req.user;
}
function requireSameOrigin(req) {
  const origin = req.headers.origin;
  if (!origin) return;
  let parsed;
  try { parsed = new URL(origin); } catch { throw new HttpError(403, 'Invalid request origin.'); }
  const host = String(req.headers.host || '').toLowerCase();
  if (parsed.host.toLowerCase() !== host || !['http:', 'https:'].includes(parsed.protocol)) {
    throw new HttpError(403, 'Cross-origin changes are not allowed.');
  }
}
function recordActivity(userId, action, detail = '') {
  db.prepare('INSERT INTO activity_log(id,user_id,action,detail,created_at) VALUES(?,?,?,?,?)')
    .run(id('act'), userId || null, action, String(detail).slice(0, 500), now());
}
function notify(type, title, body, orderId = null) {
  db.prepare('INSERT INTO notifications(id,type,title,body,created_at,read,order_id) VALUES(?,?,?,?,?,0,?)')
    .run(id('ntf'), type, title, String(body || '').slice(0, 1000), now(), orderId);
}
function broadcast(event, payload = {}, opts = {}) {
  const serialized = JSON.stringify(payload);
  for (const client of [...sseClients]) {
    if (client.res.writableEnded || client.res.destroyed) { sseClients.delete(client); continue; }
    let allowed = false;
    if (client.scope === 'owner' && client.user?.role === 'owner') {
      allowed = event !== 'customer:changed' || !opts.userId || client.user.id === opts.userId;
    } else if (client.scope === 'customer') {
      if (event === 'store:changed') allowed = true;
      else if (opts.userId && client.user?.role === 'customer' && client.user.id === opts.userId) allowed = true;
    }
    if (allowed) {
      try { client.res.write(`event: ${event}\ndata: ${serialized}\n\n`); } catch { sseClients.delete(client); }
    }
  }
}
function passwordRateCheck(key) {
  const entry = loginFailures.get(key);
  if (entry && entry.until > Date.now() && entry.count >= 10) throw new HttpError(429, 'Too many sign-in attempts. Please wait 15 minutes before trying again.');
}
function passwordRateFail(key) {
  const old = loginFailures.get(key);
  if (!old || old.until <= Date.now()) loginFailures.set(key, { count: 1, until: Date.now() + 15 * 60 * 1000 });
  else old.count++;
}
function passwordRateClear(key) { loginFailures.delete(key); }
function validEmail(email) { return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) && email.length <= 254; }
function amountInRange(value) { return Number.isFinite(value) && value >= 0 && value <= 10000000; }
function parseDataUrl(data, typeRegex, maxBytes, label) {
  if (typeof data !== 'string') throw new HttpError(400, `${label} is required.`);
  const match = data.match(/^data:([^;,]+);base64,([A-Za-z0-9+/=\r\n]+)$/i);
  if (!match || !typeRegex.test(match[1])) throw new HttpError(400, `Invalid ${label} format.`);
  const bytes = Buffer.from(match[2].replace(/\s/g, ''), 'base64');
  if (!bytes.length || bytes.length > maxBytes) throw new HttpError(413, `${label} is too large.`);
  return { mime: match[1].toLowerCase(), bytes };
}
async function savePdfData(data, required = true) {
  if (!data && !required) return null;
  const { bytes } = parseDataUrl(data, /^application\/pdf$/i, MAX_PDF_BYTES, 'PDF file');
  const header = bytes.subarray(0, 1024).toString('latin1');
  if (!header.includes('%PDF-')) throw new HttpError(400, 'The uploaded file does not appear to be a valid PDF.');
  const fileName = `${crypto.randomUUID()}.pdf`;
  const absolute = path.join(UPLOAD_DIR, fileName);
  await fsp.writeFile(absolute, bytes, { flag: 'wx', mode: 0o600 });
  return path.relative(DATA_DIR, absolute).split(path.sep).join('/');
}
function imageMagicMatches(mime, bytes) {
  if (mime === 'image/png') return bytes.length >= 8 && bytes.subarray(0, 8).equals(Buffer.from([0x89,0x50,0x4e,0x47,0x0d,0x0a,0x1a,0x0a]));
  if (mime === 'image/jpeg') return bytes.length >= 3 && bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff;
  if (mime === 'image/webp') return bytes.length >= 12 && bytes.toString('ascii', 0, 4) === 'RIFF' && bytes.toString('ascii', 8, 12) === 'WEBP';
  return false;
}
function validImageData(data, label = 'Image') {
  if (data == null || data === '') return '';
  const { mime, bytes } = parseDataUrl(data, /^image\/(png|jpeg|webp)$/i, 2 * 1024 * 1024, label);
  if (!imageMagicMatches(mime, bytes)) throw new HttpError(400, `${label} file contents do not match its image type.`);
  return data;
}

async function saveReceiptData(data) {
  const { mime, bytes } = parseDataUrl(data, /^image\/(png|jpeg|webp)$/i, 5 * 1024 * 1024, 'Payment screenshot');
  if (!imageMagicMatches(mime, bytes)) throw new HttpError(400, 'Payment screenshot file contents do not match its image type.');
  const extension = mime === 'image/jpeg' ? '.jpg' : mime === 'image/webp' ? '.webp' : '.png';
  const absolute = path.join(RECEIPT_DIR, `${crypto.randomUUID()}${extension}`);
  await fsp.writeFile(absolute, bytes, { flag: 'wx', mode: 0o600 });
  return path.relative(DATA_DIR, absolute).split(path.sep).join('/');
}
function safeFileName(value) {
  return String(value || 'studyvault-reviewer').normalize('NFKD').replace(/[^a-z0-9]+/gi, '-').replace(/^-+|-+$/g, '').toLowerCase().slice(0, 100) || 'studyvault-reviewer';
}
async function readJson(req) {
  const contentType = String(req.headers['content-type'] || '').toLowerCase();
  if (!contentType.includes('application/json')) throw new HttpError(415, 'Send this request as JSON.');
  const declared = Number(req.headers['content-length'] || 0);
  if (declared > MAX_JSON_BYTES) throw new HttpError(413, 'Request body is too large.');
  const chunks = []; let length = 0;
  for await (const chunk of req) {
    length += chunk.length;
    if (length > MAX_JSON_BYTES) throw new HttpError(413, 'Request body is too large.');
    chunks.push(chunk);
  }
  if (!length) return {};
  try { return JSON.parse(Buffer.concat(chunks).toString('utf8')); }
  catch { throw new HttpError(400, 'Invalid JSON request body.'); }
}
function setSecurityHeaders(res) {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'SAMEORIGIN');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
  res.setHeader('Cross-Origin-Opener-Policy', 'same-origin');
  res.setHeader('Content-Security-Policy', "default-src 'self'; script-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net; style-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net; img-src 'self' data: blob:; connect-src 'self'; object-src 'none'; base-uri 'self'; form-action 'self'; frame-ancestors 'self'");
  res.setHeader('X-Powered-By', 'StudyVault');
  if (IS_PROD) res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
}
async function handleApi(req, res, url) {
  const method = req.method || 'GET';
  const pathname = decodeURI(url.pathname);
  const parts = pathname.split('/').filter(Boolean);
  req.user = resolveUser(req);
  if (['POST', 'PUT', 'PATCH', 'DELETE'].includes(method)) requireSameOrigin(req);

  if (method === 'GET' && pathname === '/api/health') return sendJson(res, 200, { ok: true, service: 'StudyVault', time: now(), version: '1.0.0' });
  if (method === 'GET' && pathname === '/api/store') {
    const products = db.prepare('SELECT * FROM products WHERE active=1 ORDER BY created_at DESC').all().map(publicProduct);
    return sendJson(res, 200, { settings: readSettings(), products });
  }
  if (method === 'GET' && pathname === '/api/realtime') {
    const scope = url.searchParams.get('scope') || 'customer';
    if (!['customer', 'owner'].includes(scope)) throw new HttpError(400, 'Invalid real-time scope.');
    if (scope === 'owner') requireOwner(req);
    res.writeHead(200, {
      'Content-Type': 'text/event-stream; charset=utf-8', 'Cache-Control': 'no-cache, no-transform',
      'Connection': 'keep-alive', 'X-Accel-Buffering': 'no'
    });
    res.write('retry: 3000\nevent: connected\ndata: {"ok":true}\n\n');
    const client = { res, scope, user: req.user };
    sseClients.add(client);
    const heartbeat = setInterval(() => { if (!res.writableEnded) { try { res.write(`: heartbeat ${Date.now()}\n\n`); } catch { clearInterval(heartbeat); sseClients.delete(client); } } }, 20000);
    req.on('close', () => { clearInterval(heartbeat); sseClients.delete(client); });
    return;
  }

  // Customer authentication.
  if (method === 'POST' && pathname === '/api/auth/signup') {
    const body = await readJson(req);
    const name = String(body.name || '').trim();
    const email = String(body.email || '').trim().toLowerCase();
    const password = String(body.password || '');
    if (name.length < 2 || name.length > 100) throw new HttpError(400, 'Enter a name between 2 and 100 characters.');
    if (!validEmail(email)) throw new HttpError(400, 'Enter a valid email address.');
    if (password.length < 8 || password.length > 200) throw new HttpError(400, 'Password must be at least 8 characters.');
    const rateKey = `${req.socket.remoteAddress || 'unknown'}:signup`;
    passwordRateCheck(rateKey);
    const userId = id('usr');
    try {
      db.prepare(`INSERT INTO users(id,name,email,email_norm,password_hash,role,must_change,created_at)
        VALUES(?,?,?,?,?,'customer',0,?)`).run(userId, name, email, email, await hashPassword(password), now());
    } catch (e) {
      if (String(e.message).includes('UNIQUE')) throw new HttpError(409, 'An account with this email already exists.');
      throw e;
    }
    passwordRateClear(rateKey);
    createSession(userId, res);
    recordActivity(userId, 'customer_signup', 'Account created');
    return sendJson(res, 201, { ok: true, customer: { id: userId, name, email } });
  }
  if (method === 'POST' && pathname === '/api/auth/login') {
    const body = await readJson(req); const email = String(body.email || '').trim().toLowerCase(); const password = String(body.password || '');
    const key = `${req.socket.remoteAddress || 'unknown'}:customer-login`;
    passwordRateCheck(key);
    const user = db.prepare("SELECT * FROM users WHERE email_norm=? AND role='customer'").get(email);
    if (!user || !(await verifyPassword(password, user.password_hash))) { passwordRateFail(key); throw new HttpError(401, 'Email or password is incorrect.'); }
    passwordRateClear(key); createSession(user.id, res); recordActivity(user.id, 'customer_login');
    return sendJson(res, 200, { ok: true, customer: publicCustomer(user) });
  }
  if (method === 'POST' && pathname === '/api/auth/logout') {
    const raw = parseCookies(req)[COOKIE_NAME]; if (raw) db.prepare('DELETE FROM sessions WHERE token_hash=?').run(hashToken(raw));
    clearSessionCookie(res); return sendJson(res, 200, { ok: true });
  }
  if (method === 'GET' && pathname === '/api/auth/me') {
    return sendJson(res, 200, { customer: req.user?.role === 'customer' ? publicCustomer(req.user) : null });
  }

  // Owner authentication and administration.
  if (method === 'POST' && pathname === '/api/admin/login') {
    const body = await readJson(req); const username = String(body.username || '').trim(); const password = String(body.password || '');
    const key = `${req.socket.remoteAddress || 'unknown'}:owner-login`; passwordRateCheck(key);
    const owner = db.prepare("SELECT * FROM users WHERE username=? AND role='owner'").get(username);
    if (!owner || !(await verifyPassword(password, owner.password_hash))) { passwordRateFail(key); throw new HttpError(401, 'Invalid owner credentials.'); }
    passwordRateClear(key); createSession(owner.id, res); recordActivity(owner.id, 'owner_login');
    return sendJson(res, 200, { ok: true, mustChange: !!owner.must_change });
  }
  if (method === 'POST' && pathname === '/api/admin/logout') {
    requireOwner(req); const raw = parseCookies(req)[COOKIE_NAME]; if (raw) db.prepare('DELETE FROM sessions WHERE token_hash=?').run(hashToken(raw));
    clearSessionCookie(res); return sendJson(res, 200, { ok: true });
  }
  if (pathname.startsWith('/api/admin/')) requireOwner(req);

  if (method === 'GET' && pathname === '/api/admin/me') {
    const owner = db.prepare('SELECT username,must_change FROM users WHERE id=?').get(req.user.id);
    return sendJson(res, 200, { authenticated: true, settings: readSettings(), owner: { username: owner.username, mustChange: !!owner.must_change } });
  }
  if (method === 'GET' && pathname === '/api/admin/overview') {
    const sales = db.prepare("SELECT COALESCE(SUM(amount),0) AS total FROM orders WHERE status='approved'").get().total;
    const pending = db.prepare("SELECT COUNT(*) AS n FROM orders WHERE status='payment_submitted'").get().n;
    const orderCount = db.prepare('SELECT COUNT(*) AS n FROM orders').get().n;
    const productCount = db.prepare('SELECT COUNT(*) AS n FROM products').get().n;
    const unread = db.prepare('SELECT COUNT(*) AS n FROM notifications WHERE read=0').get().n;
    return sendJson(res, 200, { sales: Number(sales), pending: Number(pending), orders: Number(orderCount), products: Number(productCount), unreadNotifications: Number(unread) });
  }
  if (method === 'GET' && pathname === '/api/admin/products') {
    return sendJson(res, 200, { products: db.prepare('SELECT * FROM products ORDER BY created_at DESC').all().map(publicProduct) });
  }
  if (method === 'POST' && pathname === '/api/admin/products') {
    const body = await readJson(req); const title = String(body.title || '').trim();
    const subject = String(body.subject || 'General').trim() || 'General'; const description = String(body.description || '').trim();
    const price = Number(body.price); const stock = Number(body.stock);
    if (!title || title.length > 180) throw new HttpError(400, 'Enter a product title (maximum 180 characters).');
    if (!amountInRange(price) || !Number.isInteger(stock) || stock < 0 || stock > 1000000) throw new HttpError(400, 'Enter a valid price and stock quantity.');
    const cover = validImageData(body.coverData || '', 'Cover image');
    const savedPdf = await savePdfData(body.pdfData, true);
    const productId = id('prd'); const created = now();
    try {
      db.prepare(`INSERT INTO products(id,title,subject,description,price,stock,active,cover_data,pdf_path,created_at,updated_at)
        VALUES(?,?,?,?,?,?,?,?,?,?,?)`).run(productId, title, subject, description, price, stock, body.active === false ? 0 : 1, cover, savedPdf, created, created);
    } catch (e) { await fsp.rm(path.join(DATA_DIR, savedPdf), { force: true }); throw e; }
    recordActivity(req.user.id, 'product_created', `${title} (${productId})`);
    notify('product', 'Product published', `${title} was added to the catalog`);
    broadcast('store:changed', { reason: 'product_created', productId }); broadcast('admin:changed', { reason: 'product_created', productId });
    return sendJson(res, 201, { product: publicProduct(getProduct(productId)) });
  }
  const productMatch = pathname.match(/^\/api\/admin\/products\/([^/]+)$/);
  if (productMatch && (method === 'PUT' || method === 'DELETE')) {
    const productId = decodeURIComponent(productMatch[1]); const existing = getProduct(productId);
    if (!existing) throw new HttpError(404, 'Product not found.');
    if (method === 'DELETE') {
      db.prepare('DELETE FROM products WHERE id=?').run(productId);
      // Keep the PDF file: already-paid orders retain their purchased file snapshot.
      recordActivity(req.user.id, 'product_deleted', `${existing.title} (${productId})`);
      notify('product', 'Product removed', `${existing.title} was removed from the catalog`);
      broadcast('store:changed', { reason: 'product_deleted', productId }); broadcast('admin:changed', { reason: 'product_deleted', productId });
      return sendJson(res, 200, { ok: true });
    }
    const body = await readJson(req);
    const title = body.title === undefined ? existing.title : String(body.title).trim();
    const subject = body.subject === undefined ? existing.subject : String(body.subject).trim();
    const description = body.description === undefined ? existing.description : String(body.description).trim();
    const price = body.price === undefined ? Number(existing.price) : Number(body.price);
    const stock = body.stock === undefined ? Number(existing.stock) : Number(body.stock);
    const active = body.active === undefined ? !!existing.active : !!body.active;
    if (!title || title.length > 180) throw new HttpError(400, 'Enter a product title (maximum 180 characters).');
    if (!amountInRange(price) || !Number.isInteger(stock) || stock < 0 || stock > 1000000) throw new HttpError(400, 'Enter a valid price and stock quantity.');
    const cover = body.coverData === undefined ? existing.cover_data : validImageData(body.coverData, 'Cover image');
    const newPdfPath = body.pdfData ? await savePdfData(body.pdfData, true) : existing.pdf_path;
    try {
      db.prepare(`UPDATE products SET title=?,subject=?,description=?,price=?,stock=?,active=?,cover_data=?,pdf_path=?,updated_at=? WHERE id=?`)
        .run(title, subject || 'General', description, price, stock, active ? 1 : 0, cover, newPdfPath, now(), productId);
    } catch (e) {
      if (newPdfPath !== existing.pdf_path) await fsp.rm(path.join(DATA_DIR, newPdfPath), { force: true });
      throw e;
    }
    // Keep prior file versions for orders created before a product's PDF was replaced.
    recordActivity(req.user.id, 'product_updated', `${title} (${productId}); active=${active}`);
    broadcast('store:changed', { reason: 'product_updated', productId }); broadcast('admin:changed', { reason: 'product_updated', productId });
    return sendJson(res, 200, { product: publicProduct(getProduct(productId)) });
  }
  if (method === 'GET' && pathname === '/api/admin/orders') {
    const rows = db.prepare('SELECT * FROM orders ORDER BY created_at DESC').all();
    return sendJson(res, 200, { orders: rows.map(row => publicOrder(row, true)) });
  }
  const receiptMatch = pathname.match(/^\/api\/admin\/orders\/([^/]+)\/receipt$/);
  if (receiptMatch && method === 'GET') {
    requireOwner(req);
    const orderId = decodeURIComponent(receiptMatch[1]);
    const order = db.prepare('SELECT id,payment_screenshot FROM orders WHERE id=?').get(orderId);
    if (!order || !order.payment_screenshot) throw new HttpError(404, 'Payment screenshot not found.');
    if (order.payment_screenshot.startsWith('data:image/')) {
      // Support old records created before receipt files were moved into private storage.
      const parsed = parseDataUrl(order.payment_screenshot, /^image\/(png|jpeg|webp)$/i, 5 * 1024 * 1024, 'Payment screenshot');
      if (!imageMagicMatches(parsed.mime, parsed.bytes)) throw new HttpError(500, 'Stored payment screenshot is invalid.');
      res.writeHead(200, { 'Content-Type': parsed.mime, 'Content-Length': parsed.bytes.length, 'Cache-Control': 'private, no-store', 'X-Content-Type-Options': 'nosniff' });
      return res.end(parsed.bytes);
    }
    const absolute = path.resolve(DATA_DIR, order.payment_screenshot);
    const receiptPrefix = path.resolve(RECEIPT_DIR) + path.sep;
    if (!absolute.startsWith(receiptPrefix)) throw new HttpError(500, 'Invalid payment screenshot storage path.');
    const ext = path.extname(absolute).toLowerCase();
    const mime = ({ '.png': 'image/png', '.jpg': 'image/jpeg', '.webp': 'image/webp' })[ext];
    if (!mime) throw new HttpError(500, 'Invalid payment screenshot file type.');
    let bytes;
    try { bytes = await fsp.readFile(absolute); } catch { throw new HttpError(404, 'Payment screenshot file is unavailable.'); }
    res.writeHead(200, { 'Content-Type': mime, 'Content-Length': bytes.length, 'Cache-Control': 'private, no-store', 'X-Content-Type-Options': 'nosniff' });
    return res.end(bytes);
  }
  if (method === 'GET' && pathname === '/api/admin/notifications') {
    const rows = db.prepare('SELECT * FROM notifications ORDER BY created_at DESC LIMIT 100').all();
    return sendJson(res, 200, { notifications: rows.map(n => ({ id: n.id, type: n.type, title: n.title, body: n.body, createdAt: n.created_at, read: !!n.read, orderId: n.order_id })) });
  }
  if (method === 'POST' && pathname === '/api/admin/notifications/read') {
    const body = await readJson(req);
    if (body.id) db.prepare('UPDATE notifications SET read=1 WHERE id=?').run(String(body.id));
    else db.prepare('UPDATE notifications SET read=1').run();
    broadcast('admin:changed', { reason: 'notifications_read' }); return sendJson(res, 200, { ok: true });
  }
  if (method === 'GET' && pathname === '/api/admin/messages') {
    const rows = db.prepare('SELECT * FROM messages ORDER BY created_at ASC').all();
    return sendJson(res, 200, { messages: rows.map(m => ({ id: m.id, orderId: m.order_id, from: m.sender, message: m.message, createdAt: m.created_at })) });
  }
  if (method === 'GET' && pathname === '/api/admin/settings') return sendJson(res, 200, { settings: readSettings() });
  if (method === 'PUT' && pathname === '/api/admin/settings') {
    const body = await readJson(req); const current = readSettings();
    const stringKeys = ['storeName','tagline','heroTitle','shopTitle','shopSubtitle','categoriesTitle','orderTitle','orderSubtitle','supportTitle','supportText','ownerName','supportEmail','paymentInstructions','refundPolicy','footerText','accent','gCashName','gCashAccount'];
    for (const key of stringKeys) if (body[key] !== undefined) current[key] = String(body[key]).slice(0, 5000);
    if (body.gcashQrData !== undefined) current.gcashQr = validImageData(body.gcashQrData, 'GCash QR image');
    writeSettings(current); recordActivity(req.user.id, 'settings_updated', 'Website and payment destination settings updated');
    broadcast('store:changed', { reason: 'settings_updated' }); broadcast('admin:changed', { reason: 'settings_updated' });
    return sendJson(res, 200, { settings: current });
  }
  if (method === 'PUT' && (pathname === '/api/admin/password' || pathname === '/api/admin/account')) {
    const body = await readJson(req); const owner = db.prepare('SELECT * FROM users WHERE id=? AND role=\'owner\'').get(req.user.id);
    if (!(await verifyPassword(String(body.currentPassword || ''), owner.password_hash))) throw new HttpError(400, 'Current password is incorrect.');
    if (pathname.endsWith('/password')) {
      const newPassword = String(body.newPassword || '');
      if (newPassword.length < 10 || newPassword.length > 200) throw new HttpError(400, 'New password must be at least 10 characters.');
      db.prepare('UPDATE users SET password_hash=?,must_change=0 WHERE id=?').run(await hashPassword(newPassword), owner.id);
    } else {
      const username = String(body.username || owner.username).trim();
      if (!username || username.length > 60) throw new HttpError(400, 'Enter a username up to 60 characters.');
      const newPassword = String(body.newPassword || '');
      if (newPassword && (newPassword.length < 10 || newPassword.length > 200)) throw new HttpError(400, 'New password must be at least 10 characters.');
      try {
        if (newPassword) db.prepare('UPDATE users SET username=?,password_hash=?,must_change=0 WHERE id=?').run(username, await hashPassword(newPassword), owner.id);
        else db.prepare('UPDATE users SET username=? WHERE id=?').run(username, owner.id);
      } catch (e) { if (String(e.message).includes('UNIQUE')) throw new HttpError(409, 'That owner username is already in use.'); throw e; }
    }
    recordActivity(req.user.id, 'owner_account_updated', 'Owner credentials updated');
    return sendJson(res, 200, { ok: true, owner: { username: body.username || owner.username, mustChange: false } });
  }
  const adminOrderAction = pathname.match(/^\/api\/admin\/orders\/([^/]+)\/(approve|reject|reply)$/);
  if (adminOrderAction && method === 'POST') {
    const key = decodeURIComponent(adminOrderAction[1]); const action = adminOrderAction[2]; const order = getOrderByToken(key);
    if (!order) throw new HttpError(404, 'Order not found.');
    const body = action === 'reply' || action === 'reject' ? await readJson(req) : {};
    if (action === 'reply') {
      const message = String(body.message || '').trim();
      if (!message || message.length > 3000) throw new HttpError(400, 'Enter a message up to 3000 characters.');
      const mid = id('msg'); const created = now();
      db.prepare('INSERT INTO messages(id,order_id,sender,message,created_at) VALUES(?,?,\'owner\',?,?)').run(mid, order.id, message, created);
      notify('chat', 'Owner replied', message, order.id);
      recordActivity(req.user.id, 'owner_message_sent', order.id);
      broadcast('chat:changed', { orderId: order.id }, { userId: order.customer_user_id });
      return sendJson(res, 200, { ok: true });
    }
    if (action === 'approve') {
      if (order.status !== 'payment_submitted') throw new HttpError(409, 'Payment has not been submitted for verification.');
      if (order.amount_paid == null || Math.round(Number(order.amount_paid) * 100) !== Math.round(Number(order.amount) * 100)) throw new HttpError(409, 'Payment amount does not exactly match the order total.');
      const product = order.product_id ? getProduct(order.product_id) : null;
      if (!product) throw new HttpError(409, 'The product file is missing; the order cannot be approved.');
      db.exec('BEGIN IMMEDIATE');
      try {
        const fresh = db.prepare('SELECT * FROM orders WHERE id=?').get(order.id);
        const freshProduct = db.prepare('SELECT * FROM products WHERE id=?').get(product.id);
        if (!fresh || fresh.status !== 'payment_submitted') throw new HttpError(409, 'Order status changed; reload and try again.');
        if (!freshProduct || Number(freshProduct.stock) <= 0) throw new HttpError(409, 'The product is out of stock; cannot approve.');
        db.prepare('UPDATE products SET stock=stock-1,updated_at=? WHERE id=?').run(now(), product.id);
        db.prepare("UPDATE orders SET status='approved',approved_at=?,rejection_reason='' WHERE id=?").run(now(), order.id);
        db.exec('COMMIT');
      } catch (e) { try { db.exec('ROLLBACK'); } catch {} throw e; }
      notify('approved', 'Payment approved', `Order ${order.id} approved`, order.id);
      recordActivity(req.user.id, 'payment_approved', order.id);
      broadcast('store:changed', { reason: 'stock_updated', productId: product.id });
      broadcast('admin:changed', { reason: 'payment_approved', orderId: order.id });
      broadcast('order:changed', { orderId: order.id }, { userId: order.customer_user_id });
      return sendJson(res, 200, { order: publicOrder(db.prepare('SELECT * FROM orders WHERE id=?').get(order.id)) });
    }
    if (order.status !== 'payment_submitted') throw new HttpError(409, 'Only submitted payments can be rejected.');
    const reason = String(body.reason || '').trim().slice(0, 1000);
    db.prepare("UPDATE orders SET status='rejected',rejection_reason=? WHERE id=?").run(reason, order.id);
    notify('rejected', 'Payment rejected', `Order ${order.id} was rejected`, order.id);
    recordActivity(req.user.id, 'payment_rejected', `${order.id}: ${reason}`);
    broadcast('admin:changed', { reason: 'payment_rejected', orderId: order.id });
    broadcast('order:changed', { orderId: order.id }, { userId: order.customer_user_id });
    return sendJson(res, 200, { order: publicOrder(db.prepare('SELECT * FROM orders WHERE id=?').get(order.id)) });
  }

  // Customer cart, orders, and downloads.
  if (pathname.startsWith('/api/customer/')) requireCustomer(req);
  if (method === 'GET' && pathname === '/api/customer/cart') {
    const items = db.prepare(`SELECT p.* FROM cart_items c JOIN products p ON p.id=c.product_id WHERE c.user_id=? ORDER BY c.created_at DESC`).all(req.user.id).map(publicProduct);
    return sendJson(res, 200, { items });
  }
  if (method === 'POST' && pathname === '/api/customer/cart') {
    const body = await readJson(req); const product = getProduct(String(body.productId || ''));
    if (!product || !product.active) throw new HttpError(404, 'Product unavailable.');
    if (product.stock <= 0) throw new HttpError(409, 'This reviewer is out of stock.');
    db.prepare('INSERT OR IGNORE INTO cart_items(user_id,product_id,created_at) VALUES(?,?,?)').run(req.user.id, product.id, now());
    broadcast('customer:changed', { reason: 'cart_changed' }, { userId: req.user.id });
    return sendJson(res, 200, { ok: true });
  }
  const cartDelete = pathname.match(/^\/api\/customer\/cart\/([^/]+)$/);
  if (method === 'DELETE' && cartDelete) {
    db.prepare('DELETE FROM cart_items WHERE user_id=? AND product_id=?').run(req.user.id, decodeURIComponent(cartDelete[1]));
    broadcast('customer:changed', { reason: 'cart_changed' }, { userId: req.user.id }); return sendJson(res, 200, { ok: true });
  }
  if (method === 'GET' && pathname === '/api/customer/orders') {
    const rows = db.prepare('SELECT * FROM orders WHERE customer_user_id=? ORDER BY created_at DESC').all(req.user.id);
    return sendJson(res, 200, { orders: rows.map(row => publicOrder(row)) });
  }
  if (method === 'GET' && pathname === '/api/customer/downloads') {
    const rows = db.prepare("SELECT * FROM orders WHERE customer_user_id=? AND status='approved' ORDER BY approved_at DESC").all(req.user.id);
    return sendJson(res, 200, { downloads: rows.map(row => publicOrder(row)) });
  }
  if (method === 'POST' && pathname === '/api/orders') {
    const user = requireCustomer(req); const body = await readJson(req); const product = getProduct(String(body.productId || ''));
    if (!product || !product.active) throw new HttpError(404, 'Product unavailable.');
    if (product.stock <= 0) throw new HttpError(409, 'Product is out of stock.');
    const payerName = String(body.customerGcashName || '').trim(); const payerAccount = String(body.customerGcashAccount || '').trim();
    if (!payerName || !payerAccount) throw new HttpError(400, 'Enter your GCash account name and public account number/identifier.');
    const orderId = id('ord'); const orderToken = token(); const created = now();
    db.prepare(`INSERT INTO orders(id,token,customer_user_id,product_id,product_title,pdf_path_snapshot,amount,amount_paid,customer_name,customer_email,customer_gcash_name,customer_gcash_account,status,payment_reference,payment_screenshot,rejection_reason,created_at,approved_at,download_count)
      VALUES(?,?,?,?,?,?,?,NULL,?,?,?,?,'awaiting_payment','','','',?,NULL,0)`)
      .run(orderId, orderToken, user.id, product.id, product.title, product.pdf_path, Number(product.price), user.name, user.email, payerName, payerAccount, created);
    notify('order', 'New order created', `${user.name} started ${product.title}`, orderId);
    recordActivity(user.id, 'order_created', orderId);
    broadcast('admin:changed', { reason: 'order_created', orderId });
    broadcast('order:changed', { orderId }, { userId: user.id });
    const order = db.prepare('SELECT * FROM orders WHERE id=?').get(orderId);
    return sendJson(res, 201, { order: publicOrder(order) });
  }
  const orderMatch = pathname.match(/^\/api\/orders\/([^/]+)(?:\/(payment|messages|download))?$/);
  if (orderMatch) {
    const key = decodeURIComponent(orderMatch[1]); const suffix = orderMatch[2] || ''; const order = orderForCustomer(req, getOrderByToken(key));
    if (!suffix && method === 'GET') {
      const settings = readSettings();
      return sendJson(res, 200, { order: publicOrder(order), settings: { storeName: settings.storeName, tagline: settings.tagline, refundPolicy: settings.refundPolicy, paymentInstructions: settings.paymentInstructions, gcashQr: settings.gcashQr, gCashName: settings.gCashName, gCashAccount: settings.gCashAccount } });
    }
    if (suffix === 'payment' && method === 'POST') {
      const user = requireCustomer(req); if (order.customer_user_id !== user.id) throw new HttpError(404, 'Order not found.');
      const body = await readJson(req);
      if (order.status !== 'awaiting_payment') throw new HttpError(409, 'Payment cannot be submitted in the current order state.');
      const paid = Number(body.amountPaid);
      if (!Number.isFinite(paid) || Math.round(paid * 100) !== Math.round(Number(order.amount) * 100)) throw new HttpError(400, 'Payment amount must exactly match the order total.');
      const reference = String(body.paymentReference || '').trim();
      if (!reference || reference.length > 150) throw new HttpError(400, 'Enter a valid GCash payment reference.');
      const shot = String(body.paymentScreenshot || '');
      const savedReceiptPath = await saveReceiptData(shot);
      try {
        const update = db.prepare("UPDATE orders SET amount_paid=?,payment_reference=?,payment_screenshot=?,status='payment_submitted' WHERE id=? AND status='awaiting_payment'")
          .run(paid, reference, savedReceiptPath, order.id);
        if (!update.changes) throw new HttpError(409, 'Order status changed. Refresh the page and try again.');
      } catch (error) {
        await fsp.rm(path.join(DATA_DIR, savedReceiptPath), { force: true });
        throw error;
      }
      notify('payment', 'Payment submitted', `${order.customer_name} submitted payment for ${order.product_title}`, order.id);
      recordActivity(user.id, 'payment_submitted', order.id);
      broadcast('admin:changed', { reason: 'payment_submitted', orderId: order.id });
      broadcast('order:changed', { orderId: order.id }, { userId: user.id });
      return sendJson(res, 200, { order: publicOrder(db.prepare('SELECT * FROM orders WHERE id=?').get(order.id)) });
    }
    if (suffix === 'messages') {
      if (method === 'GET') {
        const messages = db.prepare('SELECT * FROM messages WHERE order_id=? ORDER BY created_at').all(order.id).map(m => ({ id: m.id, orderId: m.order_id, from: m.sender, message: m.message, createdAt: m.created_at }));
        return sendJson(res, 200, { messages });
      }
      if (method === 'POST') {
        const user = requireCustomer(req); if (order.customer_user_id !== user.id) throw new HttpError(404, 'Order not found.');
        const body = await readJson(req); const message = String(body.message || '').trim();
        if (!message || message.length > 3000) throw new HttpError(400, 'Enter a message up to 3000 characters.');
        const messageId = id('msg'); const created = now();
        db.prepare("INSERT INTO messages(id,order_id,sender,message,created_at) VALUES(?,?,'customer',?,?)").run(messageId, order.id, message, created);
        notify('chat', 'New customer message', message, order.id); recordActivity(user.id, 'customer_message_sent', order.id);
        broadcast('chat:changed', { orderId: order.id }, { userId: user.id });
        return sendJson(res, 201, { message: { id: messageId, orderId: order.id, from: 'customer', message, createdAt: created } });
      }
    }
    if (suffix === 'download' && method === 'GET') {
      const user = requireCustomer(req); if (order.customer_user_id !== user.id) throw new HttpError(404, 'Order not found.');
      if (order.status !== 'approved') throw new HttpError(403, 'Download is locked until the owner approves payment.');
      const currentProduct = order.product_id ? getProduct(order.product_id) : null;
      const pdfPath = order.pdf_path_snapshot || currentProduct?.pdf_path;
      if (!pdfPath) throw new HttpError(404, 'The reviewer file is unavailable.');
      const abs = path.resolve(DATA_DIR, pdfPath);
      if (!abs.startsWith(UPLOAD_DIR + path.sep)) throw new HttpError(500, 'Invalid protected file location.');
      let bytes; try { bytes = await fsp.readFile(abs); } catch { throw new HttpError(404, 'The reviewer file is unavailable.'); }
      if (!bytes.subarray(0, 1024).toString('latin1').includes('%PDF-')) throw new HttpError(500, 'The reviewer file failed validation.');
      db.prepare('UPDATE orders SET download_count=download_count+1 WHERE id=?').run(order.id);
      recordActivity(user.id, 'pdf_downloaded', order.id);
      res.writeHead(200, { 'Content-Type': 'application/pdf', 'Content-Disposition': `attachment; filename="${safeFileName(order.product_title)}.pdf"`, 'Content-Length': bytes.length, 'Cache-Control': 'private, no-store', 'X-Content-Type-Options': 'nosniff' });
      res.end(bytes); return;
    }
    throw new HttpError(405, 'Method not allowed for this order endpoint.');
  }

  throw new HttpError(404, 'API endpoint not found.');
}

async function handle(req, res) {
  setSecurityHeaders(res);
  try {
    const url = new URL(req.url || '/', `http://${req.headers.host || 'localhost'}`);
    if (url.pathname.startsWith('/api/')) return await handleApi(req, res, url);
    if (req.method !== 'GET' && req.method !== 'HEAD') throw new HttpError(405, 'Only GET and HEAD are supported for website files.');
    let requestPath = url.pathname;
    if (requestPath === '/') requestPath = '/customer.html';
    if (requestPath === '/customer') requestPath = '/customer.html';
    if (requestPath === '/owner') requestPath = '/owner.html';
    if (requestPath === '/favicon.ico') { res.writeHead(204); return res.end(); }
    const decoded = decodeURIComponent(requestPath);
    const absolute = path.resolve(PUBLIC_DIR, `.${decoded}`);
    if (!absolute.startsWith(PUBLIC_DIR + path.sep) && absolute !== PUBLIC_DIR) throw new HttpError(403, 'Forbidden.');
    let stat; try { stat = await fsp.stat(absolute); } catch { throw new HttpError(404, 'Website file not found.'); }
    if (!stat.isFile()) throw new HttpError(404, 'Website file not found.');
    const ext = path.extname(absolute).toLowerCase();
    const types = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.webp': 'image/webp', '.png': 'image/png', '.jpg': 'image/jpeg', '.svg': 'image/svg+xml', '.ico': 'image/x-icon' };
    const headers = { 'Content-Type': types[ext] || 'application/octet-stream', 'Content-Length': stat.size, 'Cache-Control': ext === '.html' ? 'no-cache' : 'public, max-age=3600' };
    res.writeHead(200, headers);
    if (req.method === 'HEAD') return res.end();
    fs.createReadStream(absolute).pipe(res);
  } catch (error) {
    if (res.headersSent) { try { res.end(); } catch {} return; }
    const status = error instanceof HttpError ? error.status : 500;
    if (status >= 500) console.error('[StudyVault API error]', error);
    return sendJson(res, status, { error: errorMessage(error), ...(error instanceof HttpError && error.code ? { code: error.code } : {}) });
  }
}

// Keep sessions and abuse-control entries tidy for long-running deployments.
setInterval(() => {
  try { db.prepare('DELETE FROM sessions WHERE expires_at <= ?').run(now()); } catch {}
  for (const [key, value] of loginFailures) if (value.until <= Date.now()) loginFailures.delete(key);
}, 60 * 60 * 1000).unref();

const server = http.createServer((req, res) => { void handle(req, res); });
server.requestTimeout = 120000;
server.headersTimeout = 125000;
server.keepAliveTimeout = 65000;
server.listen(PORT, HOST, () => {
  console.log(`StudyVault running on http://${HOST}:${PORT}`);
  console.log(`Customer website: http://localhost:${PORT}/customer`);
  console.log(`Owner website:    http://localhost:${PORT}/owner`);
  console.log(`Database: ${DB_FILE}`);
  if (IS_PROD) console.log('Production mode: secure cookies enabled; keep the DATA_DIR persistent.');
});

async function hashPassword(password) {
  const salt = crypto.randomBytes(16);
  const key = await scrypt(String(password), salt, 64);
  return `scrypt$${salt.toString('base64url')}$${Buffer.from(key).toString('base64url')}`;
}

function shutdown() {
  for (const c of sseClients) { try { c.res.end(); } catch {} }
  sseClients.clear();
  try { server.close(); } catch {}
  try { db.close(); } catch {}
}
process.on('SIGTERM', shutdown);
process.on('SIGINT', () => { shutdown(); process.exit(0); });
