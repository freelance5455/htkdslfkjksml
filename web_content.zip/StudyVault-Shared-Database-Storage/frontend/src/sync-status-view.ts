/*
 * StudyVault React status view, authored in TypeScript.
 * React is loaded as a pinned UMD library by the small shadow-DOM host component.
 * Bootstrap classes are scoped inside that shadow root so they cannot override the
 * legacy customer/owner CSS class names such as .row, .card, .badge and .table.
 */
export type StudyVaultSyncStatus = 'checking' | 'connected' | 'reconnecting' | 'offline' | 'demo';

export interface StudyVaultSyncStatusProps {
  status: StudyVaultSyncStatus;
  message?: string;
}

declare const React: {
  createElement(
    type: string,
    props: Record<string, unknown>,
    ...children: unknown[]
  ): unknown;
};

const statusPresentation: Record<StudyVaultSyncStatus, { label: string; classes: string }> = {
  checking: { label: 'Checking sync', classes: 'text-bg-secondary' },
  connected: { label: 'Live sync active', classes: 'text-bg-success' },
  reconnecting: { label: 'Reconnecting', classes: 'text-bg-warning' },
  offline: { label: 'Offline', classes: 'text-bg-danger' },
  demo: { label: 'Local preview', classes: 'text-bg-secondary' },
};

export function SyncStatusView(props: StudyVaultSyncStatusProps): unknown {
  const status = statusPresentation[props.status] ? props.status : 'checking';
  const view = statusPresentation[status];
  return React.createElement(
    'span',
    {
      className: `badge rounded-pill ${view.classes} sv-sync-badge`,
      role: 'status',
      'aria-live': 'polite',
      title: props.message || view.label,
    },
    React.createElement('span', { className: 'sv-sync-dot', 'aria-hidden': true }, '●'),
    ` ${view.label}`,
  );
}
