import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { spawnSync } from 'node:child_process';

const root = path.resolve('public');
const targets = ['customer.html', 'owner.html'];
let totalScripts = 0;
for (const name of targets) {
  const file = path.join(root, name);
  const html = await fs.readFile(file, 'utf8');
  if (!html.includes('StudyVault')) throw new Error(`${name}: StudyVault brand text missing`);
  if (!html.includes('/api/realtime?scope=')) throw new Error(`${name}: real-time API client hook missing`);
  if (!html.includes('/api/store')) throw new Error(`${name}: store API client hook missing`);
  if (!html.includes('studyvault-sync-status')) throw new Error(`${name}: React sync-status widget missing`);
  if (!html.includes('emitStudyVaultConnectionStatus')) throw new Error(`${name}: sync connection state dispatch missing`);
  if (!html.includes('/assets/sync-status.js')) throw new Error(`${name}: sync-status runtime missing`);
  const scripts = [...html.matchAll(/<script\b[^>]*>([\s\S]*?)<\/script\s*>/gi)];
  for (let i = 0; i < scripts.length; i++) {
    const js = scripts[i][1];
    if (!js.trim()) continue;
    const temp = path.join(os.tmpdir(), `studyvault-${name}-${i}-${process.pid}.js`);
    await fs.writeFile(temp, js, 'utf8');
    const checked = spawnSync(process.execPath, ['--check', temp], { encoding: 'utf8' });
    await fs.rm(temp, { force: true });
    if (checked.status !== 0) throw new Error(`${name}: inline script ${i + 1} failed syntax check:\n${checked.stderr || checked.stdout}`);
    totalScripts++;
  }
  console.log(`PASS ${name}: ${html.length.toLocaleString()} characters; ${scripts.length} script block(s); embedded brand; API/realtime hooks found.`);
}
console.log(`PASS Front-end checks: ${totalScripts} non-empty inline scripts passed node --check.`);
for (const asset of ['assets/sync-status.js', 'assets/sync-status-view.js']) {
  const full = path.join(root, asset);
  const stat = await fs.stat(full);
  if (!stat.isFile() || stat.size === 0) throw new Error(`${asset}: missing or empty`);
}
const sql = await fs.readFile(path.resolve('schema.sql'), 'utf8');
for (const table of ['users', 'sessions', 'products', 'cart_items', 'orders', 'messages', 'notifications', 'activity_log', 'app_settings']) {
  if (!new RegExp(`CREATE TABLE IF NOT EXISTS ${table}\\b`, 'i').test(sql)) throw new Error(`schema.sql: ${table} table missing`);
}
console.log('PASS Stack checks: React widget assets and SQL schema tables found.');
