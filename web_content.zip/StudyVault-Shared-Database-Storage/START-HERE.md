# StudyVault — Start Here

## What this package connects

This package keeps the **Customer Website** and **Owner/Admin Website** as separate pages, but both use the **same running backend** and the **same persistent data area**.

- Customer page: `/customer`
- Owner page: `/owner`
- Shared API: `/api/...`
- One database file: `DATA_DIR/studyvault.sqlite`
- Private file storage: `DATA_DIR/uploads/`
- Payment-receipt files: `DATA_DIR/uploads/receipts/`
- Live updates: `/api/realtime` (server-sent events)

Products, customer accounts, sessions, orders, settings, and payment statuses are saved in the same database. Reviewer PDFs and new payment screenshots are saved as private files outside the public website folder. A customer cannot access the owner's receipt endpoint or download a reviewer before approval.

## Run it on a computer first

1. Install **Node.js 24.15 or newer**.
2. Extract the complete project folder.
3. Copy `.env.example` to a new file named `.env` in the project root.
4. Edit `.env`. Set `OWNER_USERNAME` and a unique, strong `OWNER_PASSWORD` (at least 12 characters). Do not share this file or upload it to a public repository.
5. Open a terminal in the project folder and run:

   ```sh
   npm install --include=dev
   npm run check
   npm test
   npm start
   ```

6. On that same computer, open `http://localhost:8080/customer` and `http://localhost:8080/owner`.

Do not open the two `.html` files directly from the Downloads folder. The backend must be running for accounts, product synchronization, orders, uploads, payment review, protected downloads, and live updates to work.

## Make both websites accessible online

The package includes `render.yaml` for a single Render web service with a persistent disk. To deploy it:

1. Put the project in a **private** Git repository. Do not commit `.env`, live database files, uploaded receipts/PDFs, or private backups.
2. In Render, create a Blueprint from that repository and review `render.yaml` before deploying.
3. Set `OWNER_USERNAME` and `OWNER_PASSWORD` in the service environment. Use a unique password.
4. Keep the persistent disk mounted at `/var/data` and keep **one running app instance** for this SQLite + local-file-storage configuration.
5. Wait for `/api/health` to pass. Then share the deployed HTTPS address with `/customer` appended. Keep the `/owner` URL private and protect its credentials.

The shared database and storage are hosted with the backend, so both pages on the deployed service use the same data. The package is **not already deployed** and does not yet have a public URL; deployment must be completed in your hosting account.

## Important limits

- This version uses **one SQLite database file plus persistent private file storage** on one application server. That is suitable for the current single-server setup; it is not configured for multiple app instances.
- New receipt images are saved to `uploads/receipts/`; only authenticated owners can view them. PDFs are also stored privately and served only after access checks.
- GCash payment handling is **manual verification**. The owner must verify the transfer in the actual GCash account before approving the order. A screenshot alone is not automatic proof of payment.
- Configure the real GCash destination in Owner → Website Settings before accepting payments.
- Back up the database and the whole `DATA_DIR` together; the database references the private files.
