import test from 'node:test';
import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { createServer } from 'node:net';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { setTimeout as delay } from 'node:timers/promises';
import { fileURLToPath } from 'node:url';

const project = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

async function freePort() {
  const s = createServer();
  await new Promise((resolve, reject) => s.once('error', reject).listen(0, '127.0.0.1', resolve));
  const { port } = s.address();
  await new Promise(resolve => s.close(resolve));
  return port;
}

function getCookie(response) {
  const raw = response.headers.get('set-cookie');
  assert.ok(raw, 'expected authentication cookie');
  return raw.split(';')[0];
}

async function jsonRequest(base, route, { method = 'GET', body, cookie } = {}) {
  const headers = {};
  if (body !== undefined) headers['content-type'] = 'application/json';
  if (cookie) headers.cookie = cookie;
  const response = await fetch(base + route, { method, headers, body: body === undefined ? undefined : JSON.stringify(body) });
  const contentType = response.headers.get('content-type') || '';
  const data = contentType.includes('application/json') ? await response.json() : await response.text();
  return { response, data };
}

test('StudyVault shared backend integration', { timeout: 30000 }, async t => {
  const dataDir = await fs.mkdtemp(path.join(os.tmpdir(), 'studyvault-test-'));
  const port = await freePort();
  const base = `http://127.0.0.1:${port}`;
  const ownerPassword = 'Test-Owner-Password-2026!';
  let child = spawn(process.execPath, ['server.mjs'], {
    cwd: project,
    env: { ...process.env, NODE_ENV: 'test', HOST: '127.0.0.1', PORT: String(port), DATA_DIR: dataDir, OWNER_USERNAME: 'testowner', OWNER_PASSWORD: ownerPassword },
    stdio: ['ignore', 'pipe', 'pipe']
  });
  let logs = '';
  child.stdout.on('data', d => { logs += d.toString(); });
  child.stderr.on('data', d => { logs += d.toString(); });
  t.after(async () => {
    child.kill('SIGTERM');
    await Promise.race([new Promise(resolve => child.once('exit', resolve)), delay(1500)]);
    await fs.rm(dataDir, { recursive: true, force: true });
  });

  let healthy = false;
  for (let i = 0; i < 70; i++) {
    if (child.exitCode !== null) break;
    try { const r = await fetch(base + '/api/health'); if (r.ok) { healthy = true; break; } } catch {}
    await delay(100);
  }
  assert.ok(healthy, `server should boot. Logs: ${logs}`);

  const health = await fetch(base + '/api/health');
  assert.equal((await health.json()).ok, true);
  const customerPage = await fetch(base + '/customer');
  assert.equal(customerPage.status, 200);
  const customerHtml = await customerPage.text();
  assert.match(customerHtml, /StudyVault/);
  const ownerPage = await fetch(base + '/owner');
  assert.equal(ownerPage.status, 200);
  const ownerHtml = await ownerPage.text();
  assert.match(ownerHtml, /StudyVault/);
  assert.match(customerHtml, /studyvault-sync-status/);
  assert.match(ownerHtml, /studyvault-sync-status/);
  const syncRuntime = await fetch(base + '/assets/sync-status.js');
  assert.equal(syncRuntime.status, 200);
  assert.match(await syncRuntime.text(), /studyvault:connection/);
  const syncView = await fetch(base + '/assets/sync-status-view.js');
  assert.equal(syncView.status, 200);
  assert.match(await syncView.text(), /Live sync active/);

  const unauthAdmin = await jsonRequest(base, '/api/admin/products');
  assert.equal(unauthAdmin.response.status, 401);

  const signup = await jsonRequest(base, '/api/auth/signup', { method: 'POST', body: { name: 'Test Student', email: 'student@example.com', password: 'StudentPass123!' } });
  assert.equal(signup.response.status, 201, JSON.stringify(signup.data));
  const customerCookie = getCookie(signup.response);
  assert.equal(signup.data.customer.email, 'student@example.com');
  const emptyStore = await jsonRequest(base, '/api/store');
  assert.equal(emptyStore.response.status, 200);
  assert.deepEqual(emptyStore.data.products, []);

  const ownerLogin = await jsonRequest(base, '/api/admin/login', { method: 'POST', body: { username: 'testowner', password: ownerPassword } });
  assert.equal(ownerLogin.response.status, 200, JSON.stringify(ownerLogin.data));
  const ownerCookie = getCookie(ownerLogin.response);

  const controller = new AbortController();
  const stream = await fetch(base + '/api/realtime?scope=customer', { signal: controller.signal });
  assert.equal(stream.status, 200);
  assert.match(stream.headers.get('content-type') || '', /text\/event-stream/);
  const reader = stream.body.getReader();
  const eventPromise = (async () => {
    let text = '';
    while (text.length < 10000) {
      const { value, done } = await reader.read(); if (done) break;
      text += new TextDecoder().decode(value);
      if (text.includes('event: store:changed')) return text;
    }
    throw new Error('Timed out waiting for store:changed SSE event');
  })();

  const pdfText = '%PDF-1.4\n% StudyVault automated test\n%%EOF\n';
  const pngData = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+/2N8AAAAASUVORK5CYII=';
  const pdfData = 'data:application/pdf;base64,' + Buffer.from(pdfText).toString('base64');
  const createdProduct = await jsonRequest(base, '/api/admin/products', { method: 'POST', cookie: ownerCookie, body: { title: 'Criminal Justice Reviewer', subject: 'Criminal Justice', description: 'Integration test reviewer', price: 49.99, stock: 2, active: true, pdfData } });
  assert.equal(createdProduct.response.status, 201, JSON.stringify(createdProduct.data));
  const product = createdProduct.data.product;
  assert.ok(product.id);
  assert.equal(product.pdfData, undefined, 'private PDF bytes must never be returned in product JSON');
  const sseText = await Promise.race([eventPromise, delay(2500).then(() => { throw new Error('Timed out waiting for real-time store event'); })]);
  assert.match(sseText, /event: store:changed/);
  controller.abort();

  const customerStore = await jsonRequest(base, '/api/store');
  assert.equal(customerStore.data.products.length, 1);
  assert.equal(customerStore.data.products[0].title, 'Criminal Justice Reviewer');
  const cartAdded = await jsonRequest(base, '/api/customer/cart', { method: 'POST', cookie: customerCookie, body: { productId: product.id } });
  assert.equal(cartAdded.response.status, 200);
  const cart = await jsonRequest(base, '/api/customer/cart', { cookie: customerCookie });
  assert.equal(cart.data.items.length, 1);

  const noOrderWithoutSession = await jsonRequest(base, '/api/orders', { method: 'POST', body: { productId: product.id, customerName: 'Spoof', customerEmail: 'spoof@example.com', customerGcashName: 'Test', customerGcashAccount: '09123456789' } });
  assert.equal(noOrderWithoutSession.response.status, 401);

  const orderCreated = await jsonRequest(base, '/api/orders', { method: 'POST', cookie: customerCookie, body: { productId: product.id, customerName: 'Spoof name is ignored', customerEmail: 'spoof@example.com', customerGcashName: 'Test Student', customerGcashAccount: '09123456789' } });
  assert.equal(orderCreated.response.status, 201, JSON.stringify(orderCreated.data));
  const order = orderCreated.data.order;
  assert.equal(order.customerEmail, 'student@example.com', 'server must use the authenticated account identity');

  const lockedDownload = await fetch(base + '/api/orders/' + encodeURIComponent(order.token) + '/download', { headers: { cookie: customerCookie } });
  assert.equal(lockedDownload.status, 403);

  const invalidPayment = await jsonRequest(base, `/api/orders/${encodeURIComponent(order.token)}/payment`, { method: 'POST', cookie: customerCookie, body: { amountPaid: 12, paymentReference: 'WRONG', paymentScreenshot: pngData } });
  assert.equal(invalidPayment.response.status, 400);
  const submitted = await jsonRequest(base, `/api/orders/${encodeURIComponent(order.token)}/payment`, { method: 'POST', cookie: customerCookie, body: { amountPaid: 49.99, paymentReference: 'GCASH-TEST-REF-2026', paymentScreenshot: pngData } });
  assert.equal(submitted.response.status, 200, JSON.stringify(submitted.data));
  assert.equal(submitted.data.order.status, 'payment_submitted');

  const orderList = await jsonRequest(base, '/api/admin/orders', { cookie: ownerCookie });
  assert.equal(orderList.response.status, 200);
  assert.equal(orderList.data.orders.length, 1);
  const receiptUrl = orderList.data.orders[0].paymentScreenshot;
  assert.equal(receiptUrl, `/api/admin/orders/${encodeURIComponent(order.id)}/receipt`, 'owner API should return a protected receipt URL, not base64 image data');
  const privateReceipt = await fetch(base + receiptUrl, { headers: { cookie: ownerCookie } });
  assert.equal(privateReceipt.status, 200);
  assert.match(privateReceipt.headers.get('content-type') || '', /image\/png/);
  assert.match(privateReceipt.headers.get('cache-control') || '', /private, no-store/);
  assert.ok((await privateReceipt.arrayBuffer()).byteLength > 20, 'receipt image bytes should be saved to shared private storage');
  const customerReceiptDenied = await fetch(base + receiptUrl, { headers: { cookie: customerCookie } });
  assert.equal(customerReceiptDenied.status, 401, 'customers cannot access the owner-only receipt endpoint');
  const receiptFiles = await fs.readdir(path.join(dataDir, 'uploads', 'receipts'));
  assert.equal(receiptFiles.length, 1, 'receipt must be stored as a file separate from the database');
  assert.equal((await fetch(base + '/uploads/receipts/' + encodeURIComponent(receiptFiles[0]))).status, 404, 'receipt files must not be exposed as public static files');
  const approved = await jsonRequest(base, `/api/admin/orders/${encodeURIComponent(order.id)}/approve`, { method: 'POST', cookie: ownerCookie });
  assert.equal(approved.response.status, 200, JSON.stringify(approved.data));
  assert.equal(approved.data.order.status, 'approved');

  const downloadList = await jsonRequest(base, '/api/customer/downloads', { cookie: customerCookie });
  assert.equal(downloadList.data.downloads.length, 1);
  const download = await fetch(base + '/api/orders/' + encodeURIComponent(order.token) + '/download', { headers: { cookie: customerCookie } });
  assert.equal(download.status, 200);
  assert.match(download.headers.get('content-type') || '', /application\/pdf/);
  assert.match(Buffer.from(await download.arrayBuffer()).toString('latin1'), /%PDF-1\.4/);

  const customerMessage = await jsonRequest(base, `/api/orders/${encodeURIComponent(order.token)}/messages`, { method: 'POST', cookie: customerCookie, body: { message: 'Hello, please confirm my order.' } });
  assert.equal(customerMessage.response.status, 201);
  const ownerMessages = await jsonRequest(base, '/api/admin/messages', { cookie: ownerCookie });
  assert.equal(ownerMessages.data.messages.length, 1);
  const ownerReply = await jsonRequest(base, `/api/admin/orders/${encodeURIComponent(order.id)}/reply`, { method: 'POST', cookie: ownerCookie, body: { message: 'Payment approved. Thank you.' } });
  assert.equal(ownerReply.response.status, 200);
  const customerMessages = await jsonRequest(base, `/api/orders/${encodeURIComponent(order.token)}/messages`, { cookie: customerCookie });
  assert.equal(customerMessages.data.messages.length, 2);

  const changedSettings = await jsonRequest(base, '/api/admin/settings', { method: 'PUT', cookie: ownerCookie, body: { storeName: 'StudyVault Test Store', gCashName: 'Test Owner', gCashAccount: '09999999999' } });
  assert.equal(changedSettings.response.status, 200);
  const freshStore = await jsonRequest(base, '/api/store');
  assert.equal(freshStore.data.settings.storeName, 'StudyVault Test Store');
  assert.equal(freshStore.data.settings.gCashAccount, '09999999999');

  const customerForbidden = await jsonRequest(base, '/api/admin/products', { cookie: customerCookie });
  assert.equal(customerForbidden.response.status, 401);
  const guestOrders = await jsonRequest(base, '/api/customer/orders');
  assert.equal(guestOrders.response.status, 401);

  // Verify a different signed-in customer cannot inspect or download the first customer's order.
  const otherSignup = await jsonRequest(base, '/api/auth/signup', { method: 'POST', body: { name: 'Other Student', email: 'other@example.com', password: 'OtherStudentPass123!' } });
  assert.equal(otherSignup.response.status, 201);
  const otherCookie = getCookie(otherSignup.response);
  const privateOrder = await jsonRequest(base, '/api/orders/' + encodeURIComponent(order.token), { cookie: otherCookie });
  assert.equal(privateOrder.response.status, 404);
  const privateDownload = await fetch(base + '/api/orders/' + encodeURIComponent(order.token) + '/download', { headers: { cookie: otherCookie } });
  assert.equal(privateDownload.status, 404);

  // Reject a second submitted payment and verify that this order remains locked.
  const secondOrderResult = await jsonRequest(base, '/api/orders', { method: 'POST', cookie: customerCookie, body: { productId: product.id, customerGcashName: 'Test Student', customerGcashAccount: '09123456789' } });
  assert.equal(secondOrderResult.response.status, 201);
  const secondOrder = secondOrderResult.data.order;
  const secondPayment = await jsonRequest(base, `/api/orders/${encodeURIComponent(secondOrder.token)}/payment`, { method: 'POST', cookie: customerCookie, body: { amountPaid: 49.99, paymentReference: 'GCASH-TEST-REF-REJECT', paymentScreenshot: pngData } });
  assert.equal(secondPayment.response.status, 200);
  const rejected = await jsonRequest(base, `/api/admin/orders/${encodeURIComponent(secondOrder.id)}/reject`, { method: 'POST', cookie: ownerCookie, body: { reason: 'Test rejection path' } });
  assert.equal(rejected.response.status, 200);
  assert.equal(rejected.data.order.status, 'rejected');
  const lockedRejectedDownload = await fetch(base + '/api/orders/' + encodeURIComponent(secondOrder.token) + '/download', { headers: { cookie: customerCookie } });
  assert.equal(lockedRejectedDownload.status, 403);

  const updateProduct = await jsonRequest(base, `/api/admin/products/${encodeURIComponent(product.id)}`, { method: 'PUT', cookie: ownerCookie, body: { active: false } });
  assert.equal(updateProduct.response.status, 200);
  assert.deepEqual((await jsonRequest(base, '/api/store')).data.products, []);
  const republish = await jsonRequest(base, `/api/admin/products/${encodeURIComponent(product.id)}`, { method: 'PUT', cookie: ownerCookie, body: { active: true } });
  assert.equal(republish.response.status, 200);
  assert.equal((await jsonRequest(base, '/api/store')).data.products.length, 1);

  // Removing the product must not destroy files already bought by approved customers.
  const deletedProduct = await jsonRequest(base, `/api/admin/products/${encodeURIComponent(product.id)}`, { method: 'DELETE', cookie: ownerCookie });
  assert.equal(deletedProduct.response.status, 200);
  assert.deepEqual((await jsonRequest(base, '/api/store')).data.products, []);
  const historicalDownload = await fetch(base + '/api/orders/' + encodeURIComponent(order.token) + '/download', { headers: { cookie: customerCookie } });
  assert.equal(historicalDownload.status, 200, 'approved purchase must retain its protected PDF after product removal');
  assert.match(Buffer.from(await historicalDownload.arrayBuffer()).toString('latin1'), /%PDF-1\.4/);

  const overview = await jsonRequest(base, '/api/admin/overview', { cookie: ownerCookie });
  assert.equal(overview.data.sales, 49.99);
  assert.equal(overview.data.orders, 2);
  assert.equal(overview.data.products, 0);

  // Restart the server against the same DATA_DIR: customers, orders, settings, sessions and files must survive.
  const oldChild = child;
  const stopped = new Promise(resolve => oldChild.once('exit', resolve));
  oldChild.kill('SIGTERM');
  await Promise.race([stopped, delay(3000)]);
  child = spawn(process.execPath, ['server.mjs'], {
    cwd: project,
    env: { ...process.env, NODE_ENV: 'test', HOST: '127.0.0.1', PORT: String(port), DATA_DIR: dataDir, OWNER_USERNAME: 'testowner', OWNER_PASSWORD: ownerPassword },
    stdio: ['ignore', 'pipe', 'pipe']
  });
  child.stdout.on('data', d => { logs += d.toString(); });
  child.stderr.on('data', d => { logs += d.toString(); });
  let restarted = false;
  for (let i = 0; i < 70; i++) {
    if (child.exitCode !== null) break;
    try { const r = await fetch(base + '/api/health'); if (r.ok) { restarted = true; break; } } catch {}
    await delay(100);
  }
  assert.ok(restarted, `server should restart with the same persistent database. Logs: ${logs}`);
  assert.equal((await jsonRequest(base, '/api/admin/overview', { cookie: ownerCookie })).response.status, 200, 'owner session must persist across a service restart');
  assert.equal((await jsonRequest(base, '/api/customer/orders', { cookie: customerCookie })).response.status, 200, 'customer session and order history must persist across a service restart');
  const afterRestartDownload = await fetch(base + '/api/orders/' + encodeURIComponent(order.token) + '/download', { headers: { cookie: customerCookie } });
  assert.equal(afterRestartDownload.status, 200, 'protected PDF storage and purchase permission must survive a service restart');
  assert.match(Buffer.from(await afterRestartDownload.arrayBuffer()).toString('latin1'), /%PDF-1\.4/);
  const receiptAfterRestart = await fetch(base + receiptUrl, { headers: { cookie: ownerCookie } });
  assert.equal(receiptAfterRestart.status, 200, 'private payment receipt must remain available after a service restart');
  assert.match(receiptAfterRestart.headers.get('content-type') || '', /image\/png/);
  console.log('PASS system integration: shared catalog, SSE, auth boundaries, private PDF and receipt storage, cart/checkout, manual payment review, protected downloads, messaging, settings, publish/unpublish, and restart persistence verified.');
});
