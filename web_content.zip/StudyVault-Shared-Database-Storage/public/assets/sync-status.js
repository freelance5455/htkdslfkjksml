import { SyncStatusView } from './sync-status-view.js';

const REACT_URL = 'https://cdn.jsdelivr.net/npm/react@18.3.1/umd/react.production.min.js';
const REACT_DOM_URL = 'https://cdn.jsdelivr.net/npm/react-dom@18.3.1/umd/react-dom.production.min.js';
const BOOTSTRAP_URL = 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css';
const BOOTSTRAP_INTEGRITY = 'sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB';

function loadScript(url) {
  return new Promise((resolve, reject) => {
    const existing = [...document.scripts].find(script => script.src === url);
    if (existing) {
      if (url.includes('/react-dom@') && window.ReactDOM) return resolve();
      if (url.includes('/react@') && !url.includes('/react-dom@') && window.React) return resolve();
      existing.addEventListener('load', resolve, { once: true });
      existing.addEventListener('error', reject, { once: true });
      return;
    }
    const script = document.createElement('script');
    script.src = url;
    script.crossOrigin = 'anonymous';
    script.onload = resolve;
    script.onerror = () => reject(new Error('Could not load optional React UI dependency'));
    document.head.appendChild(script);
  });
}

class StudyVaultSyncStatus extends HTMLElement {
  connectedCallback() {
    if (this._started) return;
    this._started = true;
    this._status = window.__studyvaultConnectionState || { status: 'checking', message: 'Checking shared server connection.' };
    this._shadow = this.attachShadow({ mode: 'open' });
    const bootstrap = document.createElement('link');
    bootstrap.rel = 'stylesheet';
    bootstrap.href = BOOTSTRAP_URL;
    bootstrap.integrity = BOOTSTRAP_INTEGRITY;
    bootstrap.crossOrigin = 'anonymous';
    this._shadow.appendChild(bootstrap);
    const fallbackCss = document.createElement('style');
    fallbackCss.textContent = `
      :host{display:inline-flex;align-items:center;font:600 12px/1.2 system-ui,sans-serif;white-space:nowrap}
      #mount{display:inline-flex;align-items:center;min-height:26px}
      .sv-fallback{display:inline-flex;align-items:center;gap:6px;padding:6px 10px;border-radius:999px;background:#edf1f6;color:#35435a;border:1px solid #d9e1eb}
      .sv-fallback[data-status="connected"]{background:#e7f8ef;color:#12633a;border-color:#b9e7cb}
      .sv-fallback[data-status="reconnecting"]{background:#fff5dc;color:#805700;border-color:#f0d794}
      .sv-fallback[data-status="offline"]{background:#ffebee;color:#9b1c2c;border-color:#f6c5cc}
      .sv-fallback[data-status="demo"]{background:#edf1f6;color:#35435a}
      .sv-sync-dot{font-size:10px;margin-right:4px}
      .sv-sync-badge{font:600 12px/1.2 system-ui,sans-serif;padding:6px 10px}
    `;
    this._shadow.appendChild(fallbackCss);
    this._mount = document.createElement('span');
    this._mount.id = 'mount';
    this._shadow.appendChild(this._mount);
    this._listener = event => {
      this._status = event.detail || { status: 'checking' };
      this._renderStatus();
    };
    window.addEventListener('studyvault:connection', this._listener);
    this._renderFallback();
    // Defer optional React/Bootstrap downloads until the containing header is visible.
    // On the customer entry screen and owner login screen the header is hidden.
    if ('IntersectionObserver' in window) {
      this._visibilityObserver = new IntersectionObserver(entries => {
        if (entries.some(entry => entry.isIntersecting)) {
          this._visibilityObserver?.disconnect();
          this._activateReact();
        }
      }, { threshold: 0.01 });
      this._visibilityObserver.observe(this);
    } else {
      this._activateReact();
    }
  }

  disconnectedCallback() {
    if (this._listener) window.removeEventListener('studyvault:connection', this._listener);
    this._visibilityObserver?.disconnect();
    try { this._root?.unmount(); } catch {}
    this._root = null;
    this._started = false;
  }

  _renderFallback() {
    if (!this._mount) return;
    const labels = {
      checking: 'Checking sync', connected: 'Live sync active',
      reconnecting: 'Reconnecting', offline: 'Offline', demo: 'Local preview'
    };
    const status = Object.hasOwn(labels, this._status?.status) ? this._status.status : 'checking';
    const badge = document.createElement('span');
    badge.className = 'sv-fallback';
    badge.dataset.status = status;
    badge.setAttribute('role', 'status');
    badge.setAttribute('aria-live', 'polite');
    badge.title = this._status?.message || labels[status];
    badge.textContent = `● ${labels[status]}`;
    this._mount.replaceChildren(badge);
  }

  async _activateReact() {
    try {
      if (!window.React) await loadScript(REACT_URL);
      if (!window.ReactDOM) await loadScript(REACT_DOM_URL);
      if (!this.isConnected || !window.React || !window.ReactDOM?.createRoot) return;
      this._root = window.ReactDOM.createRoot(this._mount);
      this._renderStatus();
    } catch {
      // Intentionally keep the working vanilla fallback; optional React CDN failure
      // must never break customer or owner workflows.
    }
  }

  _renderStatus() {
    if (!this._root || !window.React) {
      this._renderFallback();
      return;
    }
    const detail = this._status || { status: 'checking' };
    this._root.render(window.React.createElement(SyncStatusView, {
      status: detail.status || 'checking',
      message: detail.message || ''
    }));
  }
}

if (!customElements.get('studyvault-sync-status')) {
  customElements.define('studyvault-sync-status', StudyVaultSyncStatus);
}
