const statusPresentation = {
    checking: { label: 'Checking sync', classes: 'text-bg-secondary' },
    connected: { label: 'Live sync active', classes: 'text-bg-success' },
    reconnecting: { label: 'Reconnecting', classes: 'text-bg-warning' },
    offline: { label: 'Offline', classes: 'text-bg-danger' },
    demo: { label: 'Local preview', classes: 'text-bg-secondary' },
};
export function SyncStatusView(props) {
    const status = statusPresentation[props.status] ? props.status : 'checking';
    const view = statusPresentation[status];
    return React.createElement('span', {
        className: `badge rounded-pill ${view.classes} sv-sync-badge`,
        role: 'status',
        'aria-live': 'polite',
        title: props.message || view.label,
    }, React.createElement('span', { className: 'sv-sync-dot', 'aria-hidden': true }, '●'), ` ${view.label}`);
}
