# StudyVault Full System

This package combines your existing **Customer Website** and **Owner/Admin Website** with a shared server, persistent database, access-controlled APIs, protected PDF storage, and real-time updates.

## Shared database and private storage

Both pages are served by the same Node.js backend and read/write one persistent SQLite database at `DATA_DIR/studyvault.sqlite`. Uploaded reviewer PDFs are kept under `DATA_DIR/uploads/`, and new payment screenshots are stored as private files under `DATA_DIR/uploads/receipts/`. Those files are not served as public static assets; owner access to payment screenshots is checked by the API. Both websites receive catalog/order changes through the backend real-time event stream.

**Read `START-HERE.md` first** for setup and deployment steps. The two HTML pages are not standalone apps when opened directly from a file manager; they need the backend running. This package is source code and has not been deployed to a public URL.

## What is included

- `public/customer.html` — your customer-facing StudyVault website, including the embedded logo.
- `public/owner.html` — your owner/admin website, including the embedded logo.
- `public/assets/sync-status.js` — shared connection-status web component with a vanilla fallback.
- `public/assets/sync-status-view.js` — compiled React status view, generated from `frontend/src/sync-status-view.ts`.
- `frontend/src/sync-status-view.ts` — typed React component source for the real-time status indicator.
- `schema.sql` — explicit SQLite schema, loaded by the Node.js server at startup.
- `server.mjs` — the single server and API for both websites.
- SQLite database created automatically inside `DATA_DIR`.
- Protected PDF files stored outside the public website folder.
- Passwords hashed with Node's built-in scrypt; owner/customer sessions use HttpOnly cookies.
- Server-sent events at `/api/realtime` for catalog, order, cart, and chat-related refreshes.
- Manual GCash transfer/reference/screenshot submission and owner verification; a PDF download becomes available only after approval.
- `render.yaml` — deployment blueprint for one Node service with a persistent disk.
- `test/system.test.mjs` — end-to-end test of the important user flows.

The production server uses Node's built-in HTTP, crypto, and SQLite modules. TypeScript is a development dependency used to compile the React sync-status view. The status badge loads pinned React 18.3.1 and Bootstrap 5.3.8 assets from a CDN; if those optional assets cannot load, a built-in CSS/DOM fallback preserves the indicator. Bootstrap is isolated in Shadow DOM so it cannot override the existing page CSS. Node 24.15+ is recommended; Node 22.13+ may print an experimental SQLite warning.

## Run locally

1. Install Node.js 24.15 or newer (Node 24 LTS is preferred).
2. Extract this ZIP.
3. Run `npm install` to install the TypeScript compiler used for the React widget build.
4. Copy `.env.example` to `.env`.
5. In `.env`, set `OWNER_USERNAME` and change `OWNER_PASSWORD` to a unique password at least 12 characters long. Do not reuse a password from another account.
6. Run the checks and compile the TypeScript component:

   ```sh
   npm run check
   npm test
   ```

7. Start the server:

   ```sh
   npm start
   ```

8. Open `http://localhost:8080/customer` for the Customer Website and `http://localhost:8080/owner` for the Owner/Admin Website.

The initial owner is created the first time the database starts. The password in `.env` is only used at that first creation; after that, change the password through Owner → Account/Security. The server does not include a public default owner password. If running in development with no `OWNER_PASSWORD`, it generates a random temporary owner password and prints it once to the terminal.

## Test before deployment

Run:

```sh
npm run check
npm test
```

The tests check frontend JavaScript syntax, auth boundaries, shared catalog reads, a real SSE catalog event, cart, checkout, payment submission and approval, order messaging, settings synchronization, publish/unpublish, protected PDF downloads, and preservation of a previously purchased PDF when a product is deleted.


## How the requested technologies are used

| Technology | Role in this StudyVault project |
|---|---|
| JavaScript | Existing customer and owner browser logic; API calls and real-time event handling. |
| CSS | The original custom styles for both websites and the connection-status fallback. |
| Bootstrap 5.3.8 | Badge styling inside the isolated sync-status widget's Shadow DOM, avoiding clashes with existing CSS class names. |
| React 18.3.1 | Renders the live connection status widget on both sites. |
| TypeScript | Types the React status component; `npm run build:typescript` compiles it into the runtime module under `public/assets/`. |
| Node.js | The sole production server for the customer and owner websites and their APIs. |
| SQL / SQLite | `schema.sql` defines the relational tables; the Node.js server loads this schema on startup and applies forward-compatible migrations. |
| PHP | `tools/health-check.php` is an optional deployment health-check client. It is not a second API server. |
| Python | `tools/backup.py` creates and integrity-checks a private backup of the SQLite database and protected uploaded files. |

**Architecture note:** PHP, Python, and Node.js are all capable of server-side work, but running three independent backends for the same accounts/orders would duplicate logic and create security and synchronization problems. This project deliberately uses Node.js as the single API server. PHP and Python are supplied as operations tools, not as alternate live request paths. React/TypeScript is used for the small connection-status component; the existing customer and owner pages remain intact so their established interactions are preserved.

### Optional maintenance tools

Run a public health check from a machine with PHP installed:

```sh
php tools/health-check.php https://your-studyvault-host.example
```

Create a private database-and-upload backup on a machine with Python 3 installed:

```sh
python3 tools/backup.py --data-dir data --output-dir backups
```

The backup contains customer accounts, orders, and potentially sensitive payment evidence. Restrict access to it, store it privately, and do not upload it to a public repository.

## Deploy online

### Render blueprint

1. Run `npm install`, `npm run check`, and `npm test` locally first.
2. Create a private Git repository and upload this project's files to it. Do not commit `.env`, the `data/` folder, or private `backups/`.
3. In Render, create a new Blueprint from that repository and review `render.yaml`.
4. Set the required `OWNER_USERNAME` and `OWNER_PASSWORD` environment values. Use a strong unique password (at least 12 characters).
5. Deploy the service and wait until the `/api/health` health check passes.
6. Open the service's public HTTPS address. `/customer` opens the customer website and `/owner` opens the owner/admin website.
7. In Owner → Website Settings, add and verify the owner's actual GCash recipient name and public account/QR before accepting transfers.

**Persistence matters:** this configuration writes the SQLite database and uploaded PDFs under `/var/data`, mounted to a persistent disk. Render documents that persistent disks are for paid services and that disk-backed services run as a single instance; without persistent storage, customer accounts, orders, and uploaded PDFs could be lost across restarts/redeploys. Review the provider's current price before creating a paid service. See https://render.com/docs/disks and https://render.com/docs/compute-plans.

Keep this deployment as a **single server instance** while using the local SQLite database and in-process SSE broadcaster. To scale to multiple application instances later, migrate to a managed shared database and a shared event/pub-sub layer.

## GCash and order safety

The included payment flow is intentionally **manual verification**: the customer transfers money in GCash, submits the reference and screenshot, and the owner checks the transaction in the actual GCash account before approving the order. A screenshot or reference is not proof by itself. Do not approve unless the actual transaction is confirmed. Automatic payment verification requires onboarding with an authorized payment provider/merchant integration and server-side verification; no such merchant credentials were provided in this project. Start with the official GCash for Business information: https://gcash.com/business/enterprise/webpay.

## Security and launch checklist

- Set unique, strong `OWNER_PASSWORD` and protect the hosting account.
- Keep `.env`, SQLite database, uploaded PDF files, and backups private.
- Configure real GCash recipient details before taking payments.
- Test customer and owner sign-in from separate browsers/devices after deployment.
- Test live product publish/unpublish updates and payment approval/download end-to-end.
- Back up the entire `DATA_DIR` (database plus `uploads/`) regularly and store backups privately.
- Do not publish this system as a static-only site: the Node server must be running for APIs, authentication, payments, protected downloads, and real-time updates to work.

## Important limits

- This is a complete **deployable source package**, but it is not already deployed under a public URL. You must deploy it to your hosting account and configure the owner password and actual payment destination.
- GCash is manual-transfer plus owner verification; automatic GCash payment confirmation is not enabled.
- SQLite and local file storage work for a single server instance with persistent storage. They are not intended for horizontally scaled multi-instance deployment.
- This server cannot make payments, confirm a transfer in the owner's GCash account, or verify merchant credentials without authorized external integration.
