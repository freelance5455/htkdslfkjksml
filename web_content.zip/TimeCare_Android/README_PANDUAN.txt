TIMECARE ANDROID - PANDUAN MEMBUAT APK

Isi paket:
- File index.html milik TimeCare ditempatkan di app/src/main/assets/
- Proyek Android Studio yang membungkus halaman HTML dalam WebView
- JavaScript dan penyimpanan lokal (localStorage) diaktifkan agar fitur aplikasi dapat berjalan

CARA MEMBUAT APK DI ANDROID STUDIO
1. Ekstrak ZIP ini ke komputer/laptop.
2. Pasang Android Studio versi terbaru yang stabil.
3. Buka Android Studio > Open, lalu pilih folder TimeCare_Android (folder yang berisi settings.gradle.kts).
4. Tunggu proses Gradle Sync selesai. Jika diminta, pasang Android SDK Platform 35 dan JDK 17.
5. Untuk membuat APK uji coba: pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Setelah selesai, tekan tautan "locate" pada notifikasi hasil build. Biasanya APK ada di:
   app/build/outputs/apk/debug/app-debug.apk
7. Pindahkan app-debug.apk ke HP Android, buka file tersebut, lalu izinkan pemasangan dari sumber ini jika diminta.

MEMBUAT APK RELEASE
- Untuk dibagikan secara luas, gunakan Build > Generate Signed Bundle / APK dan ikuti langkah pembuatan keystore.
- Simpan keystore dan kata sandinya dengan aman.

CATATAN
- Paket ini adalah proyek sumber Android, bukan file APK yang sudah dikompilasi.
- Fitur jadwal disimpan secara lokal di perangkat melalui penyimpanan browser WebView. Data tidak otomatis tersinkron ke perangkat lain.
- Jika file HTML menggunakan fitur browser yang tidak didukung di WebView atau ada tautan eksternal, perilakunya mungkin perlu penyesuaian.
- Untuk menguji hasil akhir, coba tambah, edit, dan hapus jadwal, lalu tutup dan buka kembali aplikasi untuk memastikan data tersimpan.
