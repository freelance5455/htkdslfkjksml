LUTAWA BUSINESS MANAGER v2.2.0
Phone Folder Backup Edition

Files:
- index.html: Main standalone application
- sw.js: Offline service worker (requires HTTPS hosting or localhost)
- manifest.webmanifest: PWA installation metadata

Changes in v2.2.0:
- Added Settings > Phone folder storage.
- Where the browser supports the File System Access API, the administrator can choose a phone folder.
- The app writes/updates LUTAWA_BUSINESS_MANAGER_DATA.json in that folder after saved changes.
- Folder handle is retained in IndexedDB where browser support and permissions allow.
- Added manual Save to folder now and Disconnect folder actions.
- Existing Download backup and Restore backup remain available.

Important limitations:
- Folder selection is browser-dependent. Some Android browsers do not expose directory selection to web apps.
- Use the app from a secure HTTPS origin in a supported browser for folder selection.
- If Choose phone folder is unavailable, use Download backup and select the phone Downloads folder in the system save dialog.
- The live working database remains in browser local storage; the selected folder receives a JSON backup copy, not the live database.
- Keep separate backups. Do not clear browser data unless you have verified a backup file.

Default administrator login (if unchanged):
Username: admin
Password: admin123

Security note: This is a local/offline application. Change default credentials before operational use.
