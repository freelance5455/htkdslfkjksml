
function texCanvas(){
  const c = document.createElement("canvas"); c.width = c.height = 64;
  return [c, c.getContext("2d")];
}
function darken(src, k){
  const [c, g] = texCanvas();
  g.drawImage(src, 0, 0);
  g.globalCompositeOperation = "source-atop";
  g.fillStyle = `rgba(0,0,0,${k})`;
  g.fillRect(0, 0, 64, 64);
  return c;
}
function noiseOver(g, amount, alpha){
  for (let i=0;i<amount;i++){
    const x = Math.random()*64, y = Math.random()*64;
    g.fillStyle = `rgba(${Math.random()<.5?0:255},${Math.random()<.5?0:255},255,${alpha*Math.random()})`;
    g.fillRect(x|0, y|0, 1 + (Math.random()*2|0), 1);
  }
}
function texBrick(base, mortar){
  const [c, g] = texCanvas();
  g.fillStyle = mortar; g.fillRect(0, 0, 64, 64);
  const bh = 8;
  for (let row=0; row<8; row++){
    const off = (row % 2) * 16;
    for (let bx=-32; bx<64; bx+=32){
      const x = bx + off, y = row*bh;
      g.fillStyle = base;
      g.fillRect(x + 1, y + 1, 30, bh - 2);
      g.fillStyle = "rgba(255,255,255,.07)";
      g.fillRect(x + 1, y + 1, 30, 1);
      g.fillStyle = "rgba(0,0,0,.22)";
      g.fillRect(x + 1, y + bh - 2, 30, 1);
    }
  }
  noiseOver(g, 260, .10);
  return c;
}
function texMetal(base, dark){
  const [c, g] = texCanvas();
  g.fillStyle = base; g.fillRect(0, 0, 64, 64);
  for (let y=0; y<64; y+=32){
    g.fillStyle = dark; g.fillRect(0, y, 64, 3);
    g.fillStyle = "rgba(255,255,255,.06)"; g.fillRect(0, y + 3, 64, 1);
  }
  g.fillStyle = dark; g.fillRect(30, 0, 3, 64);
  for (let y=8; y<64; y+=16){
    for (const x of [6, 24, 40, 58]){
      g.fillStyle = "rgba(255,255,255,.16)"; g.fillRect(x, y, 3, 3);
      g.fillStyle = "rgba(0,0,0,.35)"; g.fillRect(x + 1, y + 2, 2, 1);
    }
  }
  noiseOver(g, 200, .09);
  return c;
}
function texConcrete(base, dark){
  const [c, g] = texCanvas();
  g.fillStyle = base; g.fillRect(0, 0, 64, 64);
  for (let i=0;i<14;i++){
    const x = Math.random()*64, w = 2 + Math.random()*7, h = 8 + Math.random()*40;
    g.fillStyle = `rgba(0,0,0,${.08 + Math.random()*.14})`;
    g.fillRect(x|0, (Math.random()*20)|0, w|0, h|0);
  }
  g.strokeStyle = dark; g.lineWidth = 1;
  for (let i=0;i<3;i++){
    g.beginPath();
    let x = Math.random()*64, y = 0;
    g.moveTo(x, y);
    while (y < 64){ x += (Math.random()*8 - 4); y += 6 + Math.random()*8; g.lineTo(x, y); }
    g.stroke();
  }
  noiseOver(g, 320, .12);
  return c;
}

var TEX = {
  1:[texBrick("#63300f", "#2a1408")],
  2:[texMetal("#4d5240", "#2b2f22")],
  3:[texConcrete("#6d2a24", "#3a1210")]
};
for (const k in TEX) TEX[k][1] = darken(TEX[k][0], .34);

var cv = document.getElementById("c"), ctx = cv.getContext("2d", {alpha:false});
var W = 0, H = 0, zbuf = null;
var CAM_PLANE = .66;
function resize(){
  const rw = cv.clientWidth, rh = cv.clientHeight;
  W = Math.max(80, Math.min(440, Math.round(rw / 2 * SET.quality)));
  H = Math.round(W * rh / rw);
  CAM_PLANE = Math.max(.66, W / (2 * H));
  cv.width = W; cv.height = H;
  zbuf = new Float32Array(W);
  ctx.imageSmoothingEnabled = false;
  buildVignette();
}
addEventListener("resize", () => { resize(); if (typeof layoutBossBar === "function") layoutBossBar(); });

function blank(){
  const s = document.createElement("canvas"); s.width = s.height = 64;
  return [s, s.getContext("2d")];
}

function imp(frame){
  const [s,g] = blank();
  const sway = frame ? 2 : -2;
  g.fillStyle = "#3d2418";
  g.fillRect(24 + sway, 48, 6, 16); g.fillRect(34 - sway, 48, 6, 16);
  g.fillStyle = "#7a4526";
  g.beginPath(); g.ellipse(32, 42, 13, 13, 0, 0, 7); g.fill();
  g.fillStyle = "#6b3c20";
  g.beginPath(); g.ellipse(14, 40 + sway, 5, 9, .4, 0, 7); g.ellipse(50, 40 - sway, 5, 9, -.4, 0, 7); g.fill();
  g.fillStyle = "#8a5730";
  g.beginPath(); g.ellipse(32, 22, 15, 15, 0, 0, 7); g.fill();
  g.fillStyle = "#d8cdaa";
  g.beginPath(); g.moveTo(19,11); g.lineTo(12,-2); g.lineTo(28,8); g.closePath(); g.fill();
  g.beginPath(); g.moveTo(45,11); g.lineTo(52,-2); g.lineTo(36,8); g.closePath(); g.fill();
  g.fillStyle = "#f5edd6";
  g.beginPath(); g.ellipse(25,20,5,4,0,0,7); g.ellipse(39,20,5,4,0,0,7); g.fill();
  g.fillStyle = "#c1160d";
  g.beginPath(); g.arc(25 + sway*.4, 20, 2.2, 0, 7); g.arc(39 + sway*.4, 20, 2.2, 0, 7); g.fill();
  g.fillStyle = "#2a0806";
  g.beginPath(); g.ellipse(32, 31, 8, 5, 0, 0, 7); g.fill();
  g.fillStyle = "#f5edd6";
  for (let i=0;i<3;i++) g.fillRect(26+i*5, 27, 3, 4);
  return s;
}

function bull(frame){
  const [s,g] = blank();
  const sway = frame ? 3 : -3;
  g.fillStyle = "#2b3320";
  g.fillRect(20 + sway, 50, 9, 14); g.fillRect(36 - sway, 50, 9, 14);
  g.fillStyle = "#4d5c33";
  g.beginPath(); g.ellipse(32, 43, 21, 16, 0, 0, 7); g.fill();
  g.fillStyle = "#3f4c2a";
  g.beginPath(); g.ellipse(9, 42 + sway, 7, 11, .3, 0, 7); g.ellipse(55, 42 - sway, 7, 11, -.3, 0, 7); g.fill();
  g.fillStyle = "#5e7040";
  g.beginPath(); g.ellipse(32, 22, 19, 16, 0, 0, 7); g.fill();
  g.fillStyle = "#ded3b4";
  g.beginPath(); g.moveTo(14,16); g.lineTo(2,6); g.lineTo(18,6); g.closePath(); g.fill();
  g.beginPath(); g.moveTo(50,16); g.lineTo(62,6); g.lineTo(46,6); g.closePath(); g.fill();
  g.fillStyle = "#f7d34a";
  g.beginPath(); g.ellipse(24,20,6,4,0,0,7); g.ellipse(40,20,6,4,0,0,7); g.fill();
  g.fillStyle = "#1a1206";
  g.beginPath(); g.arc(24 + sway*.3, 20, 2.4, 0, 7); g.arc(40 + sway*.3, 20, 2.4, 0, 7); g.fill();
  g.fillStyle = "#20130a";
  g.beginPath(); g.ellipse(32, 33, 12, 6, 0, 0, 7); g.fill();
  g.fillStyle = "#f5edd6";
  for (let i=0;i<4;i++){ g.fillRect(23+i*5, 28, 3, 5); g.fillRect(25+i*5, 35, 3, 4); }
  return s;
}

function caster(frame){
  const [s,g] = blank();
  const bob = frame ? -2 : 2;
  g.fillStyle = "#3a2246";
  g.beginPath(); g.moveTo(32, 10 + bob); g.lineTo(52, 62); g.lineTo(12, 62); g.closePath(); g.fill();
  g.fillStyle = "#4d2d5e";
  g.beginPath(); g.moveTo(32, 6 + bob); g.lineTo(46, 30 + bob); g.lineTo(18, 30 + bob); g.closePath(); g.fill();
  g.fillStyle = "#120a17";
  g.beginPath(); g.ellipse(32, 24 + bob, 9, 7, 0, 0, 7); g.fill();
  g.fillStyle = "#00e0c8";
  g.beginPath(); g.arc(28, 24 + bob, 2.2, 0, 7); g.arc(36, 24 + bob, 2.2, 0, 7); g.fill();
  g.fillStyle = "#c9bda0"; g.fillRect(8, 30 + bob, 4, 30);
  g.fillStyle = "#ff8a2b";
  g.beginPath(); g.arc(10, 28 + bob, 5, 0, 7); g.fill();
  return s;
}

function bloodSplash(){
  const [s,g] = blank();
  g.fillStyle = "rgba(150,18,12,.85)";
  g.beginPath(); g.ellipse(32, 47, 17, 5, 0, 0, Math.PI*2); g.fill();
  for (const p of [[16,45,3],[12,39,2],[21,37,2],[43,39,2],[49,46,3],[38,34,1.5]]) {
    g.beginPath(); g.arc(p[0],p[1],p[2],0,Math.PI*2); g.fill();
  }
  return s;
}

function lifeHeart(){
  const [s,g] = blank();
  const px = [
    "..XXX...XXX..",
    ".XXXXX.XXXXX.",
    "XXWXXXXXXXXXX",
    "XWXXXXXXXXXXX",
    "XXXXXXXXXXXXX",
    ".XXXXXXXXXXX.",
    "..XXXXXXXXX..",
    "...XXXXXXX...",
    "....XXXXX....",
    ".....XXX.....",
    "......X......"
  ];
  const k = 3, ox = 32 - 13*k/2, oy = 18;
  for (let y = 0; y < px.length; y++) for (let x = 0; x < px[y].length; x++){
    const c = px[y][x];
    if (c === ".") continue;
    g.fillStyle = c === "W" ? "#ffd6dc" : (y > 6 ? "#b0142a" : "#e02846");
    g.fillRect(ox + x*k, oy + y*k, k, k);
  }
  return s;
}

function medkit(){
  const [s,g] = blank();
  g.fillStyle = "#e8e2d2"; g.fillRect(14, 22, 36, 26);
  g.fillStyle = "#b8b0a0"; g.fillRect(14, 22, 36, 4);
  g.fillStyle = "#c1160d"; g.fillRect(28, 28, 8, 16); g.fillRect(20, 32, 24, 8);
  return s;
}
function armorItem(){
  const [s,g] = blank();
  g.fillStyle = "#6d7f8c";
  g.beginPath(); g.moveTo(32,18); g.lineTo(50,26); g.lineTo(44,50); g.lineTo(32,56); g.lineTo(20,50); g.lineTo(14,26); g.closePath(); g.fill();
  g.fillStyle = "#9fb2bf";
  g.beginPath(); g.moveTo(32,24); g.lineTo(43,29); g.lineTo(39,46); g.lineTo(32,50); g.closePath(); g.fill();
  return s;
}
function ammoBox(color, label){
  const [s,g] = blank();
  g.fillStyle = color; g.fillRect(16, 26, 32, 22);
  g.fillStyle = "rgba(0,0,0,.35)"; g.fillRect(16, 26, 32, 5);
  g.fillStyle = "#efe6cc"; g.font = "bold 14px monospace"; g.textAlign = "center";
  g.fillText(label, 32, 43);
  return s;
}
function fireballSprite(){
  const [s,g] = blank();
  const gr = g.createRadialGradient(32,32,2,32,32,22);
  gr.addColorStop(0,"#fff3c4"); gr.addColorStop(.4,"#ff9a1f"); gr.addColorStop(1,"rgba(190,40,0,0)");
  g.fillStyle = gr; g.beginPath(); g.arc(32,32,22,0,7); g.fill();
  return s;
}

function drawFallbackEnemy(g){
  g.clearRect(0, 0, 64, 64);
  g.fillStyle = "#2e211c"; g.fillRect(10, 30, 44, 34);
  g.fillStyle = "#5e4234"; g.fillRect(16, 6, 32, 30);
  g.fillStyle = "#402c23"; g.fillRect(16, 6, 32, 6);
  g.fillStyle = "#c8160e"; g.fillRect(22, 18, 7, 5); g.fillRect(35, 18, 7, 5);
  g.fillStyle = "#140a08"; g.fillRect(24, 28, 16, 4);
}

var ENEMY_IMG = "assets/enemies/enemy.jpg";
var CHAR_FILES = {
  imp:ENEMY_IMG, bull:ENEMY_IMG, caster:ENEMY_IMG,
  boss_tank:ENEMY_IMG, boss_summoner:ENEMY_IMG, boss_caster:ENEMY_IMG, boss_berserk:ENEMY_IMG,
  boss_final:"assets/enemies/final-boss.jpg"
};
var CHAR = {};

function paintChar(key, src){
  const c = CHAR[key];
  if (typeof spriteDirty === "function"){ spriteDirty(c.sprite); spriteDirty(c.corpse); }
  const g = c.sprite.getContext("2d");
  g.clearRect(0, 0, 64, 64);
  g.imageSmoothingEnabled = false;
  g.drawImage(src, 0, 0, 64, 64);
  const cg = c.corpse.getContext("2d");
  cg.clearRect(0, 0, 64, 64);
  cg.imageSmoothingEnabled = false;
  cg.save(); cg.translate(32, 42); cg.rotate(Math.PI/2);
  cg.drawImage(src, -28, -28, 56, 56);
  cg.restore();
}

for (const key in CHAR_FILES){
  const sprite = document.createElement("canvas"); sprite.width = sprite.height = 64;
  const corpseCv = document.createElement("canvas"); corpseCv.width = corpseCv.height = 64;
  CHAR[key] = { sprite, corpse:corpseCv, fallback:false };
}

(() => {
  const byPath = {};
  for (const key in CHAR_FILES) (byPath[CHAR_FILES[key]] = byPath[CHAR_FILES[key]] || []).push(key);
  for (const path in byPath){
    const keys = byPath[path], img = new Image();
    let tries = 0;
    img.onload = () => { for (const k of keys){ paintChar(k, img); CHAR[k].fallback = false; CHAR[k].loaded = true; } };
    img.onerror = () => {
      if (tries++ < 2){ setTimeout(() => { img.src = path + "?r=" + Date.now(); }, 900 * tries); return; }
      const t = document.createElement("canvas"); t.width = t.height = 64;
      drawFallbackEnemy(t.getContext("2d"));
      for (const k of keys){ paintChar(k, k === "boss_final" ? drawPalPalych(64) : t); CHAR[k].fallback = true; }
    };
    img.src = path;
  }
})();

function drawPalPalych(size){
  const c = document.createElement("canvas"); c.width = c.height = size;
  const g = c.getContext("2d");
  const k = size / 64;
  const R = (x, y, w, h, col) => { g.fillStyle = col; g.fillRect(x*k, y*k, w*k, h*k); };
  R(6, 44, 52, 20, "#34383f");
  R(10, 42, 44, 4, "#3e434b");
  R(18, 44, 10, 20, "#454b54"); R(36, 44, 10, 20, "#454b54");
  R(26, 42, 12, 12, "#e8e4da");
  R(30, 44, 4, 4, "#8e0f09"); R(29, 48, 6, 13, "#a3120b"); R(31, 48, 2, 13, "#c21a10");
  R(12, 50, 4, 4, "#c9a227"); R(13, 51, 2, 2, "#f0d060");
  R(25, 36, 14, 7, "#b8845c");
  R(16, 10, 32, 28, "#d9a27a");
  R(14, 20, 36, 14, "#d9a27a");
  R(16, 30, 32, 6, "#c89068");
  R(16, 8, 32, 3, "#e4b08a");
  R(18, 10, 28, 2, "#7a7068"); R(20, 12, 24, 1, "#7a7068"); R(22, 14, 18, 1, "#6b6258");
  R(13, 16, 4, 12, "#6b6258"); R(47, 16, 4, 12, "#6b6258");
  R(12, 21, 3, 7, "#c89068"); R(49, 21, 3, 7, "#c89068");
  R(18, 16, 5, 3, "#3a3029"); R(23, 17, 5, 3, "#3a3029"); R(28, 18, 3, 2, "#3a3029");
  R(41, 16, 5, 3, "#3a3029"); R(36, 17, 5, 3, "#3a3029"); R(33, 18, 3, 2, "#3a3029");
  R(18, 20, 12, 8, "#111"); R(34, 20, 12, 8, "#111");
  R(19, 21, 10, 6, "#6e8594"); R(35, 21, 10, 6, "#6e8594");
  R(30, 22, 4, 2, "#111");
  R(22, 23, 4, 3, "#ff3020"); R(38, 23, 4, 3, "#ff3020");
  R(23, 23, 2, 1, "#ffd0c0"); R(39, 23, 2, 1, "#ffd0c0");
  R(19, 21, 3, 1, "#b7c7d2"); R(35, 21, 3, 1, "#b7c7d2");
  R(29, 27, 6, 5, "#c48462");
  R(21, 32, 22, 4, "#3a2c22"); R(19, 33, 4, 3, "#3a2c22"); R(41, 33, 4, 3, "#3a2c22");
  R(26, 36, 12, 2, "#6a1a12");
  return c;
}

if (!CHAR.boss_final.loaded) paintChar("boss_final", drawPalPalych(64));
var PAL_PORTRAIT = null;
function palPortraitURL(){
  if (!PAL_PORTRAIT) PAL_PORTRAIT = drawPalPalych(256).toDataURL();
  return PAL_PORTRAIT;
}

function gunItem(color, label){
  const [s,g] = blank();
  g.fillStyle = "rgba(0,0,0,.45)"; g.fillRect(10, 22, 44, 30);
  g.fillStyle = color; g.fillRect(12, 24, 40, 26);
  g.fillStyle = "#efe6cc"; g.font = "bold 16px monospace"; g.textAlign = "center";
  g.fillText(label, 32, 44);
  return s;
}
function buffItem(color){
  const [s,g] = blank();
  const gr = g.createRadialGradient(32, 34, 2, 32, 34, 20);
  gr.addColorStop(0, "#ffffff"); gr.addColorStop(.4, color); gr.addColorStop(1, "rgba(0,0,0,0)");
  g.fillStyle = gr; g.beginPath(); g.arc(32, 34, 20, 0, 7); g.fill();
  return s;
}
function grenadeSprite(){
  const [s,g] = blank();
  g.fillStyle = "#2f3a20"; g.beginPath(); g.arc(32, 36, 9, 0, 7); g.fill();
  g.fillStyle = "#8d9a5e"; g.fillRect(29, 23, 6, 8);
  return s;
}
function boomSprite(){
  const [s,g] = blank();
  const gr = g.createRadialGradient(32, 32, 2, 32, 32, 30);
  gr.addColorStop(0, "#fff6d0"); gr.addColorStop(.35, "#ffb020");
  gr.addColorStop(.7, "#c0350a"); gr.addColorStop(1, "rgba(90,20,0,0)");
  g.fillStyle = gr; g.beginPath(); g.arc(32, 32, 30, 0, 7); g.fill();
  return s;
}

var ART = {
  imp:[CHAR.imp.sprite, CHAR.imp.sprite],
  bull:[CHAR.bull.sprite, CHAR.bull.sprite],
  caster:[CHAR.caster.sprite, CHAR.caster.sprite],
  boss_tank:[CHAR.boss_tank.sprite, CHAR.boss_tank.sprite],
  boss_summoner:[CHAR.boss_summoner.sprite, CHAR.boss_summoner.sprite],
  boss_caster:[CHAR.boss_caster.sprite, CHAR.boss_caster.sprite],
  boss_berserk:[CHAR.boss_berserk.sprite, CHAR.boss_berserk.sprite],
  boss_final:[CHAR.boss_final.sprite, CHAR.boss_final.sprite],
  corpse:{imp:CHAR.imp.corpse, bull:CHAR.bull.corpse, caster:CHAR.caster.corpse,
          boss_tank:CHAR.boss_tank.corpse, boss_summoner:CHAR.boss_summoner.corpse,
          boss_caster:CHAR.boss_caster.corpse, boss_berserk:CHAR.boss_berserk.corpse,
          boss_final:CHAR.boss_final.corpse},
  bloodSplash:bloodSplash(),
  medkit:medkit(),
  life:lifeHeart(),
  armor:armorItem(),
  bullets:ammoBox("#4a7a2e","П"),
  shells:ammoBox("#8a2320","Д"),
  fireball:fireballSprite(),
  grenades:ammoBox("#5b4a8c","Г"),
  gun1:gunItem("#8a2320","Д"), gun2:gunItem("#4a7a2e","П"), gun3:gunItem("#5b4a8c","Г"),
  rage:buffItem("#c8321e"), haste:buffItem("#e0c020"), shield:buffItem("#3f9fd0"),
  grenade:grenadeSprite(), boom:boomSprite()
};

var HITR = e => .48 * (e.scale || KIND[e.type].scale);

var KIND = {
  imp:    {hp:10, speed:1.70, dmg:9,  rate:.9,  melee:true,  reach:.85, art:"imp",    scale:1.0},
  bull:   {hp:35, speed:1.00, dmg:17, rate:1.2, melee:true,  reach:1.05,art:"bull",   scale:1.35},
  caster: {hp:15, speed:.8,   dmg:0,  rate:1.6, melee:false, reach:7.0, art:"caster", scale:1.1},
  boss:   {hp:0,  speed:1,    dmg:20, rate:1.2, melee:true,  reach:1.6, art:"imp",    scale:1.8}
};
var BOSS_EVERY = 20;
var BOSS_TYPES = [
  {id:"tank",     name:"ВАХТЁРША", hp:1700, speed:.85, scale:1.95, dmg:24, tint:"rgba(130,85,40,.28)"},
  {id:"summoner", name:"ЗАВУЧ",    hp:1100, speed:.95, scale:1.7,  dmg:14, tint:"rgba(60,170,70,.3)"},
  {id:"caster",   name:"ХИМИЧКА",  hp:1200, speed:1.1, scale:1.7,  dmg:14, tint:"rgba(150,70,210,.32)"},
  {id:"berserk",  name:"ФИЗРУК",   hp:1500, speed:1.45, scale:1.8, dmg:18, tint:"rgba(210,40,30,.3)"}
];
var FINAL_LEVEL = 150;
var FINAL_BOSS = {id:"final", name:"ПАЛ ПАЛЫЧ", hp:36000, speed:1.0, scale:2.5, dmg:26, tint:null};
var isBossLevel = () => level > 0 && (level % BOSS_EVERY === 0 || level === FINAL_LEVEL);
var isFinalLevel = () => level === FINAL_LEVEL;
function bossTypeFor(lvl){
  if (lvl === FINAL_LEVEL) return FINAL_BOSS;
  const n = lvl / BOSS_EVERY;
  const off = Math.floor(mulberry32((runSeed ^ 0x9E3779B9) >>> 0)() * BOSS_TYPES.length);
  return BOSS_TYPES[(n - 1 + off) % BOSS_TYPES.length];
}
var FIREBALL_DMG = 13, FIREBALL_SPEED = 4.0;

var DEPTH_CAP = 150;
var depth = () => Math.min(level, DEPTH_CAP);

var t150 = () => depth()/DEPTH_CAP;
var ramp = (cap, pow) => cap * Math.pow(t150(), pow);

var ENDLESS_CAP = 1000;
var endU = () => level > DEPTH_CAP ? (Math.min(level, ENDLESS_CAP) - DEPTH_CAP) / (ENDLESS_CAP - DEPTH_CAP) : 0;
var endless = () => 1 + 1.5 * endU();
var endHp = () => 1 + 2.5 * Math.pow(endU(), 1.3);
var bossEnd = () => Math.exp(1.6 * endU());
var dmgBonus = () => (level <= 10 ? level*.6 : 6 + 12*Math.pow((depth()-10)/140, .7)) * endless();
var rateMul = () => Math.max(.5, (1 - .35*Math.pow(t150(), .6)) / (1 + .25 * endU()));
var bossRate = () => Math.max(.8, rateMul());
var HP_GROWTH = {imp:5, bull:3.86, caster:4.33};
var enemyHp = type => Math.round(KIND[type].hp * (1 + HP_GROWTH[type] * Math.pow(t150(), .75)) * endHp());
var enemySpeed = k => k.speed * (1 + .16*Math.min(level, 10)/10 + .22*Math.pow(t150(), .55));
var shotSpeed = () => FIREBALL_SPEED * (1 + .25*t150());
var bossHpMul = () => (1 + 1.6 * t150()) * bossEnd();
var bossLvl = () => t150();

var isSurge = () => level > 0 && level % 5 === 0 && level % 20 !== 0 && level !== 150;

function countRange(){
  if (level <= 3){ const n = Math.round((4 + Math.round(level*1.5)) * .7); return [n, n]; }
  const center = level <= 10 ? 4 + level*1.5
               : 19 + 17*Math.pow((depth()-10)/140, .7);
  const spread = level < 10 ? 1 : 2;
  return [Math.round(center - spread), Math.round(center + spread)];
}

function enemyCount(){
  const [lo, hi] = countRange();
  if (isSurge()) return hi;
  const r = mulberry32((runSeed ^ Math.imul(level + 11, 0x85EBCA6B)) >>> 0)();
  return lo + Math.floor(r * (hi - lo + 1));
}
var curve = () => ({
  surge: isSurge(),
  count:   enemyCount(),
  hpBonus: type => enemyHp(type) - KIND[type].hp,
  bulls:   level >= 2 ? .12 + ramp(.28, .4) : 0,
  casters: level >= 3 ? .08 + ramp(.26, .4) + (isSurge() ? .08 : 0) : 0,
  medkits: depth() < 40 ? Math.min(4, 1 + Math.floor(level/2))
                        : Math.max(2, 4 - Math.floor((depth() - 40)/50)),
  bullets: Math.min(3, 1 + Math.floor(level/5)),
  shells:  Math.min(2, 1 + Math.floor(level/8)),
  bulletAmt: 24 + Math.min(10, Math.floor(depth()/15)),
  shellAmt:  5 + Math.min(3, Math.floor(depth()/40)),
  dropChance: .24 + Math.min(.08, depth()*.0006),
  levelHeal: Math.max(6, 15 - Math.floor(depth()/25))
});

var shade = document.createElement("canvas"); shade.width = shade.height = 64;
var sctx = shade.getContext("2d");
var CANVAS_FILTER = (() => {
  try {
    const t = document.createElement("canvas").getContext("2d");
    t.filter = "brightness(0.5)";
    return t.filter !== "none" && t.filter !== "";
  } catch(e){ return false; }
})();

var AC = null;
var noiseBuf = null;
