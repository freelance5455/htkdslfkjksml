/* JOSTECH — COURS 07 : BASES DE DONNÉES & SYSTÈMES D'INFORMATION */
registerDisciplineLevels(7, {
  1: {
    label: "Niveau 1 — Fondamental",
    subtitle: "Modélisation des données, modèle relationnel et clés PK / FK.",
    chapters: [{
      id: "bdd-1-1", title: "Chapitre 1 : Modèle Relationnel",
      lessons: [{
        id: "bdd-1-1-1", title: "Leçon 1 : Tables, Clé Primaire (PK) et Clé Étrangère (FK)", duration: "25 min",
        objectives: ["Structurer des données sans redondance.", "Distinguer Clé Primaire (PK) et Clé Étrangère (FK)."],
        prerequisites: ["Notions de fichiers."],
        sections: [
          { type: "definition", term: "Base de Données Relationnelle (SGBDR)", text: "Collection structurée de tables (relations) composées de colonnes (attributs) et de lignes (enregistrements), gérée par un SGBDR comme MySQL ou PostgreSQL." },
          { type: "table", title: "Les deux clés fondamentales", headers: ["Clé", "Rôle exact"], rows: [
            ["Clé Primaire (PK)", "Identifiant unique et non nul de chaque ligne (ex: id_etudiant)."],
            ["Clé Étrangère (FK)", "Colonne pointant vers la PK d'une autre table pour créer un lien (intégrité référentielle)."]
          ]}
        ],
        exercise: {
          question: "Dans une base JOSTECH avec les tables Etudiants et Notes, dans quelle table place-t-on la clé étrangère id_etudiant et pourquoi ?",
          solution: "Dans la table Notes ! Car un étudiant peut avoir plusieurs notes (relation 1-à-plusieurs) : chaque ligne de Note référence ainsi son étudiant."
        },
        summary: "Le modèle relationnel élimine les doublons en reliant des tables normalisées par clés primaires et étrangères.",
        references: ["Codd, E. F. (1970) — A Relational Model of Data."]
      }]
    }]
  },
  2: {
    label: "Niveau 2 — Intermédiaire",
    subtitle: "Langage SQL (SELECT, INSERT, UPDATE, DELETE et JOIN).",
    chapters: [{
      id: "bdd-2-1", title: "Chapitre 2 : Maîtrise du Langage SQL",
      lessons: [{
        id: "bdd-2-1-1", title: "Leçon 1 : Requêtes SQL et Jointures (INNER JOIN)", duration: "30 min",
        objectives: ["Écrire des requêtes CRUD en SQL.", "Relier plusieurs tables via INNER JOIN."],
        prerequisites: ["Niveau 1 — Modèle relationnel."],
        sections: [
          { type: "code", lang: "SQL (MySQL / PostgreSQL)", code: "SELECT e.nom, n.valeur\nFROM etudiants e\nINNER JOIN notes n ON e.id = n.etudiant_id\nWHERE n.valeur >= 14\nORDER BY n.valeur DESC;" },
          { type: "warning", title: "Piège classique SQL", text: "N'exécutez JAMAIS UPDATE ou DELETE sans clause WHERE précise (sinon vous modifiez ou supprimez TOUTES les lignes de la table !)." }
        ],
        exercise: {
          question: "Écrivez la requête SQL pour afficher la moyenne générale (AVG) de la colonne « note » dans la table « notes ».",
          solution: "SELECT AVG(note) AS moyenne_generale FROM notes;"
        },
        summary: "SQL standardise la création (CREATE), la lecture filtrée (SELECT/JOIN), l'insertion (INSERT), la mise à jour (UPDATE) et la suppression (DELETE).",
        references: ["PostgreSQL & MySQL Official Documentation."]
      }]
    }]
  },
  3: {
    label: "Niveau 3 — Avancé & Universitaire",
    subtitle: "Transactions ACID, indexation, sauvegardes et systèmes d'information.",
    chapters: [{
      id: "bdd-3-1", title: "Chapitre 3 : Transactions ACID, Index & SI",
      lessons: [{
        id: "bdd-3-1-1", title: "Leçon 1 : Propriétés ACID, Index B-Tree et Sauvegardes", duration: "30 min",
        objectives: ["Garantir la cohérence par transactions ACID.", "Optimiser les requêtes par indexation et planifier les sauvegardes."],
        prerequisites: ["Niveau 2 — SQL."],
        sections: [
          { type: "definition", term: "Transactions ACID (BEGIN / COMMIT / ROLLBACK)", text: "• Atomicité : tout réussit ou tout est annulé (ex: virement bancaire débit + crédit).\n• Cohérence : les règles d'intégrité restent valides.\n• Isolation : deux requêtes simultanées ne se corrompent pas.\n• Durabilité : une fois validé (COMMIT), le résultat survit même à une coupure électrique." },
          { type: "theory", title: "Indexation et Systèmes d'Information (SI)", text: "Un index (souvent en arbre B-Tree) accélère les recherches SQL de O(n) à O(log n), comme l'index à la fin d'un livre. Côté gestion des SI, une entreprise combine SGBD, droits d'accès (RBAC) et sauvegardes automatiques régulières testées par restauration." }
        ],
        exercise: {
          question: "Lors d'un transfert d'argent en base de données, l'étape 1 (débiter A) réussit mais le serveur plante avant l'étape 2 (créditer B). Quelle commande SQL rétablit l'état initial ?",
          solution: "ROLLBACK (annulation automatique de la transaction non validée par COMMIT), garantissant l'Atomicité."
        },
        summary: "Les transactions ACID protègent les opérations critiques, les index accélèrent la lecture et les sauvegardes assurent la continuité du SI.",
        references: ["Kleppmann, M. — Designing Data-Intensive Applications."]
      }]
    }]
  }
});