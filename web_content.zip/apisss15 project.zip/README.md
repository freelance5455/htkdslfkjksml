# Apisss Project V1 - APK Build Guide

File ini berisi source code lengkap web application (HTML, CSS, JavaScript) dengan efek **Liquid Glass**, sistem login (`apisss` / `apisss15`), pemutar lagu, shop, banner **Apisss Project V1**, 5 fitur optimasi khusus, developer panel sender dengan hak atas nama **Apisss15**, foto profil & logout, serta **4 mini-games** pada slide kedua.

## Cara Mengubah ZIP ini menjadi APK Android:
Anda dapat dengan mudah membungkus file web ini menjadi aplikasi Android (.apk) menggunakan salah satu metode berikut:

1. **Menggunakan Website Pembuat APK Webview (Paling Mudah & Instan):**
   - Upload file `index.html` (beserta file pendukungnya) ke hosting gratis (seperti Netlify, Vercel, atau GitHub Pages), atau gunakan file lokal.
   - Gunakan layanan online converter gratis seperti **AppsGeyser**, **WebintoApp**, atau **Glide / PWABuilder**.
   - Masukkan link web Anda, dan website tersebut akan otomatis mengompilasinya menjadi file `.apk` siap download.

2. **Menggunakan Android Studio (Metode Developer):**
   - Buat project baru di Android Studio dengan template **Empty Views Activity**.
   - Tambahkan komponen `WebView` di `activity_main.xml`.
   - Masukkan folder project web ini ke dalam folder `assets/` di Android Studio.
   - Load file di WebView dengan perintah: `webView.loadUrl("file:///android_asset/index.html");`
   - Build APK (`Build > Build Bundle(s) / APK(s) > Build APK(s)`).

3. **Menggunakan Apache Cordova / Capacitor (CLI):**
   - Install Cordova: `npm install -g cordova`
   - Buat project: `cordova create myapp com.apisss.project ApisssProject`
   - Masukkan file ke folder `www/` dan compile untuk platform Android.
