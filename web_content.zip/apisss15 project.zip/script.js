document.addEventListener('DOMContentLoaded', () => {
    // LOGIN LOGIC
    const loginBtn = document.getElementById('login-btn');
    const usernameInput = document.getElementById('username');
    const passwordInput = document.getElementById('password');
    const loginError = document.getElementById('login-error');
    const loginScreen = document.getElementById('login-screen');
    const appScreen = document.getElementById('app-screen');

    loginBtn.addEventListener('click', () => {
        const u = usernameInput.value.trim();
        const p = passwordInput.value.trim();

        if (u === 'apisss' && p === 'apisss15') {
            loginScreen.classList.remove('active');
            appScreen.classList.add('active');
            showToast('Login Berhasil! Selamat datang di Apisss Project V1');
        } else {
            loginError.textContent = 'Username atau Password salah! (Gunakan: apisss / apisss15)';
        }
    });

    // SIDEBAR & NAVIGATION
    const menuToggle = document.getElementById('menu-toggle');
    const sidebar = document.getElementById('sidebar');
    const sidebarOverlay = document.getElementById('sidebar-overlay');
    const closeSidebar = document.getElementById('close-sidebar');

    function toggleSidebar() {
        sidebar.classList.toggle('open');
        sidebarOverlay.classList.toggle('active');
    }

    menuToggle.addEventListener('click', toggleSidebar);
    closeSidebar.addEventListener('click', toggleSidebar);
    sidebarOverlay.addEventListener('click', toggleSidebar);

    // LOGOUT
    const logoutBtn = document.getElementById('logout-btn');
    logoutBtn.addEventListener('click', () => {
        toggleSidebar();
        appScreen.classList.remove('active');
        loginScreen.classList.add('active');
        usernameInput.value = 'apisss';
        passwordInput.value = 'apisss15';
        showToast('Berhasil Logout');
    });

    // PROFILE PICTURE
    const profileTrigger = document.getElementById('profile-trigger');
    const avatarInput = document.getElementById('avatar-input');
    const avatarImg = document.getElementById('avatar-img');

    profileTrigger.addEventListener('click', () => avatarInput.click());
    avatarInput.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = (event) => {
                avatarImg.src = event.target.result;
                showToast('Foto profil berhasil diperbarui!');
            };
            reader.readAsDataURL(file);
        }
    });

    // SLIDE TABS NAVIGATION
    const tabBtns = document.querySelectorAll('.tab-btn');
    const slides = document.querySelectorAll('.slide');

    tabBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            const targetIndex = btn.getAttribute('data-slide');
            
            tabBtns.forEach(b => b.classList.remove('active'));
            slides.forEach(s => s.classList.remove('active'));

            btn.classList.add('active');
            slides[targetIndex].classList.add('active');
        });
    });

    // FEATURE TOGGLES
    const toggles = document.querySelectorAll('.feature-toggle');
    toggles.forEach(toggle => {
        toggle.addEventListener('change', (e) => {
            const featName = e.target.getAttribute('data-name');
            if (e.target.checked) {
                showToast(`Fitur [${featName}] Berhasil Diaktifkan!`);
            } else {
                showToast(`Fitur [${featName}] Dimatikan`);
            }
        });
    });

    // DEVELOPER PRIVATE SENDER
    const sendPrivateBtn = document.getElementById('send-private-btn');
    const privateMsg = document.getElementById('private-msg');
    const senderStatus = document.getElementById('sender-status');

    sendPrivateBtn.addEventListener('click', () => {
        const msg = privateMsg.value.trim();
        if (!msg) {
            senderStatus.style.color = '#ef4444';
            senderStatus.textContent = 'Pesan tidak boleh kosong!';
            return;
        }
        senderStatus.style.color = '#10b981';
        senderStatus.textContent = 'Berhasil mengirim private sender atas nama Apisss15!';
        showToast('Private message sent by Apisss15!');
        privateMsg.value = '';
    });

    // MODALS HANDLING (SONG & SHOP)
    const modals = document.querySelectorAll('.modal');
    const closeModals = document.querySelectorAll('.close-modal');

    document.querySelectorAll('.sidebar-menu li[data-modal]').forEach(item => {
        item.addEventListener('click', () => {
            toggleSidebar();
            const modalId = item.getAttribute('data-modal');
            document.getElementById(modalId).classList.add('active');
        });
    });

    closeModals.forEach(btn => {
        btn.addEventListener('click', () => {
            modals.forEach(m => m.classList.remove('active'));
        });
    });

    window.addEventListener('click', (e) => {
        modals.forEach(m => {
            if (e.target === m) m.classList.remove('active');
        });
    });

    // AUDIO PLAYER LOGIC (SYNTHESIZER / AUDIO API)
    let isPlaying = false;
    let audioCtx = null;
    let oscillator = null;
    const playSongBtn = document.getElementById('play-song');
    const playIcon = document.getElementById('play-icon');
    const songTitle = document.getElementById('song-title');
    const songArtist = document.getElementById('song-artist');
    const playlistItems = document.querySelectorAll('.playlist-item');

    playlistItems.forEach(item => {
        item.addEventListener('click', () => {
            playlistItems.forEach(i => i.classList.remove('active'));
            item.classList.add('active');
            songTitle.textContent = item.textContent.split('. ')[1] + ' - Apisss Vibe';
            if (isPlaying) {
                stopTone();
                startTone();
            }
            showToast(`Memutar: ${songTitle.textContent}`);
        });
    });

    playSongBtn.addEventListener('click', () => {
        if (!isPlaying) {
            startTone();
            playIcon.classList.remove('fa-play');
            playIcon.classList.add('fa-pause');
            isPlaying = true;
            showToast('Pemutar Lagu Dimulai');
        } else {
            stopTone();
            playIcon.classList.remove('fa-pause');
            playIcon.classList.add('fa-play');
            isPlaying = false;
            showToast('Pemutar Lagu Dijeda');
        }
    });

    function startTone() {
        if (!audioCtx) {
            audioCtx = new (window.AudioContext || window.webkitAudioContext)();
        }
        oscillator = audioCtx.createOscillator();
        const gainNode = audioCtx.createGain();
        oscillator.type = 'sine';
        oscillator.frequency.setValueAtTime(440, audioCtx.currentTime); // A4 note
        gainNode.gain.setValueAtTime(0.1, audioCtx.currentTime);
        oscillator.connect(gainNode);
        gainNode.connect(audioCtx.destination);
        oscillator.start();
    }

    function stopTone() {
        if (oscillator) {
            oscillator.stop();
            oscillator.disconnect();
            oscillator = null;
        }
    }

    // SHOP ITEMS
    window.buyItem = function(itemName) {
        showToast(`Item [${itemName}] berhasil diklaim & aktif!`);
    };

    // TOAST HELPER
    window.showToast = function(message) {
        const toast = document.getElementById('toast');
        toast.textContent = message;
        toast.classList.add('show');
        setTimeout(() => {
            toast.classList.remove('show');
        }, 3000);
    };
});

// MINI GAMES SYSTEM (4 GAMES)
const gameModal = document.getElementById('game-modal');
const gameTitleHeader = document.getElementById('game-title-header');
const gameBody = document.getElementById('game-body');

window.openGame = function(gameType) {
    gameModal.classList.add('active');
    gameBody.innerHTML = '';

    if (gameType === 'clicker') {
        gameTitleHeader.textContent = 'Tap Booster Game';
        let score = 0;
        let timeLeft = 10;
        let timerStarted = false;

        gameBody.innerHTML = `
            <p>Tekan tombol secepat mungkin dalam 10 detik!</p>
            <h2 id="clicker-score" style="font-size: 2.5rem; color: var(--primary);">0</h2>
            <p id="clicker-timer">Waktu: 10s</p>
            <button id="tap-btn" class="glass-btn primary-btn" style="padding: 20px 40px; font-size: 1.2rem;">TAP DISINI!</button>
        `;

        const tapBtn = document.getElementById('tap-btn');
        const scoreDisplay = document.getElementById('clicker-score');
        const timerDisplay = document.getElementById('clicker-timer');

        tapBtn.addEventListener('click', () => {
            if (!timerStarted) {
                timerStarted = true;
                const interval = setInterval(() => {
                    timeLeft--;
                    timerDisplay.textContent = `Waktu: ${timeLeft}s`;
                    if (timeLeft <= 0) {
                        clearInterval(interval);
                        tapBtn.disabled = true;
                        tapBtn.style.opacity = 0.5;
                        showToast(`Game Selesai! Skor Anda: ${score}`);
                    }
                }, 1000);
            }
            if (timeLeft > 0) {
                score++;
                scoreDisplay.textContent = score;
            }
        });

    } else if (gameType === 'reaction') {
        gameTitleHeader.textContent = 'Reaction Speed Test';
        gameBody.innerHTML = `
            <div id="reaction-box" class="glass-card" style="width: 100%; padding: 40px; background: rgba(239, 68, 68, 0.2); cursor: pointer;">
                <h3 id="reaction-text">Tunggu warna hijau...</h3>
            </div>
            <button class="glass-btn" onclick="openGame('reaction')">Reset</button>
        `;

        const box = document.getElementById('reaction-box');
        const text = document.getElementById('reaction-text');
        let startTime = 0;
        let state = 'waiting';

        const timeout = setTimeout(() => {
            if (state === 'waiting') {
                state = 'ready';
                box.style.background = 'rgba(16, 185, 129, 0.3)';
                text.textContent = 'KLIK SEKARANG!';
                startTime = Date.now();
            }
        }, Math.random() * 2000 + 1500);

        box.addEventListener('click', () => {
            if (state === 'waiting') {
                clearTimeout(timeout);
                state = 'ended';
                box.style.background = 'rgba(239, 68, 68, 0.4)';
                text.textContent = 'Terlalu cepat! Coba lagi.';
            } else if (state === 'ready') {
                state = 'ended';
                const reactionTime = Date.now() - startTime;
                box.style.background = 'rgba(56, 189, 248, 0.3)';
                text.textContent = `Waktu Reaksi: ${reactionTime} ms!`;
                showToast(`Refleks: ${reactionTime} ms`);
            }
        });

    } else if (gameType === 'guess') {
        gameTitleHeader.textContent = 'Guess the Number (1-100)';
        const target = Math.floor(Math.random() * 100) + 1;
        let attempts = 0;

        gameBody.innerHTML = `
            <p>Tebak angka rahasia antara 1 sampai 100</p>
            <div class="input-group" style="width: 100%;">
                <input type="number" id="guess-input" placeholder="Masukkan angka...">
            </div>
            <button id="guess-btn" class="glass-btn primary-btn">Tebak</button>
            <p id="guess-feedback" style="color: var(--primary);"></p>
        `;

        const guessInput = document.getElementById('guess-input');
        const guessBtn = document.getElementById('guess-btn');
        const feedback = document.getElementById('guess-feedback');

        guessBtn.addEventListener('click', () => {
            const val = parseInt(guessInput.value);
            if (isNaN(val)) return;
            attempts++;
            if (val === target) {
                feedback.textContent = `🎉 Benar! Angkanya ${target} dalam ${attempts} percobaan.`;
                showToast('Selamat, Anda Berhasil Menebak!');
            } else if (val < target) {
                feedback.textContent = `Terlalu KECIL! (Percobaan ke-${attempts})`;
            } else {
                feedback.textContent = `Terlalu BESAR! (Percobaan ke-${attempts})`;
            }
            guessInput.value = '';
        });

    } else if (gameType === 'tictactoe') {
        gameTitleHeader.textContent = 'Tic Tac Toe';
        let board = ['', '', '', '', '', '', '', '', ''];
        let currentPlayer = 'X';
        let activeGame = true;

        let gridHtml = '<div style="display: grid; grid-template-columns: repeat(3, 70px); gap: 8px;">';
        for (let i = 0; i < 9; i++) {
            gridHtml += `<button class="glass-btn tictactoe-cell" data-index="${i}" style="width: 70px; height: 70px; font-size: 1.5rem; font-weight: bold;"></button>`;
        }
        gridHtml += '</div><p id="ttt-status" style="margin-top: 10px;">Giliran: Player X</p>';

        gameBody.innerHTML = gridHtml;

        const cells = document.querySelectorAll('.tictactoe-cell');
        const tttStatus = document.getElementById('ttt-status');

        cells.forEach(cell => {
            cell.addEventListener('click', () => {
                const idx = cell.getAttribute('data-index');
                if (board[idx] !== '' || !activeGame) return;

                board[idx] = currentPlayer;
                cell.textContent = currentPlayer;
                cell.style.color = currentPlayer === 'X' ? '#38bdf8' : '#a855f7';

                // Check winner
                const winConditions = [
                    [0,1,2], [3,4,5], [6,7,8],
                    [0,3,6], [1,4,7], [2,5,8],
                    [0,4,8], [2,4,6]
                ];

                let roundWon = false;
                for (let cond of winConditions) {
                    if (board[cond[0]] && board[cond[0]] === board[cond[1]] && board[cond[0]] === board[cond[2]]) {
                        roundWon = true;
                        break;
                    }
                }

                if (roundWon) {
                    tttStatus.textContent = `🏆 Player ${currentPlayer} Menang!`;
                    showToast(`Player ${currentPlayer} Menang!`);
                    activeGame = false;
                    return;
                }

                if (!board.includes('')) {
                    tttStatus.textContent = `🤝 Seri!`;
                    showToast(`Permainan Seri!`);
                    activeGame = false;
                    return;
                }

                currentPlayer = currentPlayer === 'X' ? 'O' : 'X';
                tttStatus.textContent = `Giliran: Player ${currentPlayer}`;
            });
        });
    }
};

window.closeGameModal = function() {
    gameModal.classList.remove('active');
};
