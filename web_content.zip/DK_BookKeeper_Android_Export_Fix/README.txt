DK BookKeeper — Guided Voice + Android Export Integration

WHAT CHANGED
1. Voice entry is now guided, one field at a time:
   - Entry type: Expense / Income / Contra / Journal
   - Amount in PKR
   - First account
   - Second account
   - Narration / remarks
2. Journal labels are Debit Account and Credit Account.
3. Expense, Income, and Contra show their appropriate account labels.
4. Each spoken answer is reviewed before it is applied. The full voucher must still be reviewed before Save.
5. AndroidVoiceBridge.kt uses Android's native speech recognition intent, avoiding reliance on Web Speech API inside Android WebView.
6. AndroidFileBridge.kt saves exported XLSX files to Downloads through Android MediaStore on Android 10+.

FILES
- app/src/main/assets/index.html — updated app interface and guided voice workflow
- MainActivity.kt — sample WebView activity wiring both native bridges
- AndroidVoiceBridge.kt — native Android speech recognition bridge
- AndroidFileBridge.kt — native XLSX file saving bridge
- AndroidManifest_permissions.xml.txt — manifest note

IMPORTANT — THIS IS SOURCE INTEGRATION, NOT A BUILT APK
This ZIP is not an APK. To produce a working APK, integrate these files into the Android Studio project used to build your current app. Do not replace your existing MainActivity blindly; merge the bridge registration into it and preserve your package name and existing project setup. The sample MainActivity assumes AndroidX AppCompat and Activity Result APIs are available.

MANIFEST / BUILD NOTES
- Keep INTERNET permission if the SheetJS CDN is used.
- For reliable offline export, bundle xlsx.full.min.js in app/src/main/assets and change the CDN script tag in index.html to <script src="xlsx.full.min.js"></script>.
- Native speech recognition is launched by Android. Availability depends on a speech recognition service installed/enabled on the phone. Internet may be required by the device's speech service.
- The language selector passes en-PK, ur-PK, or en-US to Android recognition.
- Keep the AndroidX Activity Result dependency available through your project's AppCompat/Activity setup.

TEST
1. Install the rebuilt APK on the phone.
2. Tap Start guided entry.
3. Tap Speak answer for each field and speak only the requested value.
4. If speech recognition returns an incorrect account, edit the recognized answer and tap Use answer / Next step; account matching is restricted to the Chart of Accounts.
5. Review date, voucher number, accounts, amount, and narration before saving.
6. Export a small test workbook and confirm it appears in Downloads and imports correctly into BookKeeper before bulk use.

DATA
Transactions remain in local browser storage on the device. Back up regularly. No cloud sync is included.
