package com.dkbookkeeper.app

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.provider.MediaStore
import android.util.Base64
import android.webkit.JavascriptInterface
import java.io.File
import java.io.FileOutputStream

class AndroidFileBridge(private val context: Context) {
    @JavascriptInterface
    fun saveBase64File(fileName: String, mimeType: String, base64Data: String): String {
        return try {
            val safeName = fileName.replace(Regex("[^A-Za-z0-9._-]"), "_")
            val bytes = Base64.decode(base64Data, Base64.DEFAULT)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, safeName)
                    put(MediaStore.Downloads.MIME_TYPE, mimeType)
                    put(MediaStore.Downloads.IS_PENDING, 1)
                }
                val uri = context.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    ?: return "ERROR: Could not create file in Downloads"
                context.contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                    ?: return "ERROR: Could not write file"
                values.clear()
                values.put(MediaStore.Downloads.IS_PENDING, 0)
                context.contentResolver.update(uri, values, null, null)
                "OK: Saved to Downloads/$safeName"
            } else {
                @Suppress("DEPRECATION")
                val dir = android.os.Environment.getExternalStoragePublicDirectory(
                    android.os.Environment.DIRECTORY_DOWNLOADS
                )
                if (!dir.exists()) dir.mkdirs()
                val file = File(dir, safeName)
                FileOutputStream(file).use { it.write(bytes) }
                "OK: Saved to ${file.absolutePath}"
            }
        } catch (e: Exception) {
            "ERROR: ${e.message ?: "Unknown file save error"}"
        }
    }
}
