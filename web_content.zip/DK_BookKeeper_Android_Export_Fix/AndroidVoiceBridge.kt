package com.dkbookkeeper.app

import android.app.Activity
import android.content.Intent
import android.speech.RecognizerIntent
import android.webkit.JavascriptInterface
import java.util.Locale

class AndroidVoiceBridge(
    private val activity: Activity,
    private val launchRecognizer: (Intent) -> Unit
) {
    @JavascriptInterface
    fun startListening(languageTag: String) {
        activity.runOnUiThread {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, languageTag)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, languageTag)
                putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak the requested voucher field")
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            }
            launchRecognizer(intent)
        }
    }
}
