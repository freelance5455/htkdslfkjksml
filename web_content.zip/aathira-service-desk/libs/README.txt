OFFLINE PDF (optional)
Put these 2 files in this folder, then the app makes PDFs without internet:
  html2canvas.min.js  from https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js
  jspdf.umd.min.js    from https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js
(Open each link in a browser, Save As, keep the same file name.)
Without these files the app loads them from the internet.
