AATHIRA SERVICE DESK - APK seivadhu eppadi
==========================================

Folder la irukkadhu: index.html (app), manifest.webmanifest + sw.js + icons (phone la install-ku), libs (offline PDF, optional).

APK seyya (easy way - code theva illa)
1. Indha folder ai free hosting la upload pannunga: https://app.netlify.com/drop  (folder ai drag & drop). Oru https link kidaikkum.
2. https://www.pwabuilder.com ponga, antha link ai potu Start. "Package for Android" click panni APK / AAB download pannunga.
   (Vera option: "zip to apk" web-to-app sites la indha zip ai upload pannalaam. Index.html root la irukkum.)
3. APK ai phone la install pannunga.

Gavanikka vendiyadhu
- Records phone la (device) mattum save aagum. Settings > "Download backup (JSON)" ippo ippo eduthukonga. "Restore backup" la thirumba kondu varalaam. Phone maathina / app uninstall pannina backup thaan kaapaathum.
- Maththa phone la data theriyaadhu (cloud sync illa).
- First time PDF seiya internet venum (PDF library load aaga). Offline venum-na libs/README.txt paarunga.
- PDF anuppa: PDF preview la "Share PDF (choose WhatsApp)" button varum (Android la). Illa-na "Download PDF" pannitu WhatsApp la attach pannunga.
- Company phone / email / GST: Settings la maathalaam.
