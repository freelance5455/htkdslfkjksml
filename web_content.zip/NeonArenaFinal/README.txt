NEON ARENA — OFFLINE BATTLE PROTOTYPE

Included: index.html, a self-contained WebGL game prototype intended for mobile browsers.
Features: third-person 3D-style arena, house district, cover blocks, enemy bots, shooting, waves, health, score, dash, energy pickups, and three cosmetic player color finishes.

How to play:
1. Open index.html in a modern Android browser with WebGL enabled.
2. Tap DEPLOY.
3. Use the left virtual stick to move; drag the right side of the screen to aim/turn.
4. Tap FIRE to shoot and DASH to evade.
5. Choose a cosmetic finish before starting.

Limitations: This is a compact prototype, not a PUBG-scale production game. It uses stylized low-poly geometry and bots, not realistic human characters, multiplayer, licensed weapon models, or a large open world. This package is HTML source, not an APK. An Android build service or Android build environment is required to package it as an installable APK.
