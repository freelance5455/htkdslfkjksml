MY SALARY - Offline prototype

Open index.html in a modern browser. Data is stored in browser localStorage on that device/browser.
Features: attendance records, editable salary settings, salary/deduction/overtime calculations, conveyance, monthly/yearly reports, CSV export, JSON backup and restore.

Important limitations:
- This is a browser-based prototype, not a compiled Android APK or iOS IPA.
- Direct Google Drive sync is not included; download JSON and upload manually to Drive.
- Back up regularly. Clearing browser storage or changing browser/device can remove local data.
- Check calculations against your employer's actual salary policy before relying on them.
