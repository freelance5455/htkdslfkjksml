MY SALARY - APP PROJECT

Is folder mein offline-friendly web app source hai. Ismein:
- ₹400 default daily salary
- 9:00 AM to 6:00 PM default shift
- 30 minute lunch
- ₹50 per eligible overtime hour
- Attendance records and late/short-time deduction calculation
- Conveyance: salary mein add ya separate reimbursement
- Monthly/yearly report, CSV export
- JSON backup and restore

IMPORTANT:
Yeh source project hai, ready Android APK nahi. APK banane ke liye project ko HTTPS par host karke Android wrapper/PWA builder se package/build karna hoga. Google Drive ka automatic sync included nahi; JSON backup ko manually Google Drive par upload kar sakte hain.

Open index.html to preview in a browser. For installable PWA/offline service worker, host over HTTPS (or localhost); opening file:// directly does not enable service worker.

Salary calculation note:
Worked minutes = out time - in time - configured lunch minutes. Target = configured regular paid hours. If worked less than target, deduction is calculated according to selected deduction policy. If worked beyond target, extra time can qualify for OT. Complete-hour OT is the default. This is a personal estimate tool; confirm employer-specific payroll rules before relying on it.
