MY SALARY APP — HINDI GUIDE

Is ZIP mein my_salary_app/index.html main app file hai.

FEATURES
- Present, Absent aur Weekly Off attendance
- Day Duty aur Night Duty selection
- Shift midnight ke baad khatam ho to bhi duration calculate hota hai (jaise 9 AM se 3 AM)
- Default daily salary ₹400, regular paid hours 8.5, lunch 30 minute, overtime ₹50 per eligible hour
- Night allowance per eligible night hour alag rate par; Settings mein night window (default 10 PM–6 AM) aur ₹/hour rate set karein
- Night allowance aur overtime alag-alag calculate hote hain
- Late/short hours deduction settings
- Monthly/yearly reports, CSV export, conveyance, JSON backup/restore

PHONE PAR CHALANE KA TAREEQA
1. ZIP download karein aur File Manager/ZArchiver se extract karein.
2. my_salary_app folder mein index.html ko browser mein kholne ki koshish karein. Kuch Android browsers local HTML ko restrict karte hain.
3. Agar na khule, project ko HTTPS par host karna hoga.
4. Records isi browser/device ke local storage mein save hote hain. Settings & Backup se JSON backup download karein; ise Google Drive par manually upload kar sakte hain.

APK NOTE
Yeh HTML web app project hai, compiled Android APK nahi. APK ke liye is project ko Android package mein build karna aur phone par test karna alag step hai.

SALARY CALCULATION NOTE
- Present: recorded paid duration ke hisaab se daily salary; regular hours ke baad OT alag.
- Absent: salary ₹0 aur configured daily salary absent deduction ke roop mein report hoti hai.
- Weekly Off: salary/deduction nahi.
- Night allowance sirf Night Duty record par, Settings ke night-time window mein overlap hone wale hours par lagta hai.
- Night allowance aur OT dono alag line items hain; employer policy ke hisaab se rate set karein. Night-window overlap se lunch break ko automatically nahi ghataaya jaata, kyunki lunch ka exact time record nahi hota.
- In/out time mein end time start se pehle ho to app end ko agle din ka samajhti hai.
