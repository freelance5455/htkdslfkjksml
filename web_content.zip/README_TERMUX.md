# Syllabe V3.10 — Lecteur vocal Android

Cette version reprend intégralement la base Syllabe V3.9 fournie dans
`Syllabe_V3_9_400_Images_Corrige.zip`.

## Nouveauté
Un pont Android natif `TextToSpeech` est ajouté à l'APK.

Priorité de lecture :
1. Android Text-to-Speech français (dans l'APK)
2. SpeechSynthesis WebView (secours dans Termux/navigateur)

Le lecteur lit les lettres, syllabes et mots déjà demandés par l'application.
La vitesse choisie dans Syllabe est transmise au moteur Android.

## Important
Ce n'est pas une IA cloud qui envoie les voix sur Internet : c'est la synthèse
vocale Android. Cela permet de fonctionner hors ligne si une voix française est
installée sur le téléphone.

## Construction avec Termux

Copier le dossier dans le HOME, puis vérifier le SDK Android :

```bash
cd ~/Syllabe_V3_10_IA_Vocale
ls
gradle --version
echo $ANDROID_HOME
```

Si `ANDROID_HOME` pointe vers le SDK Android et que Gradle est installé :

```bash
cd ~/Syllabe_V3_10_IA_Vocale
gradle :app:assembleDebug
```

APK produit :

```text
app/build/outputs/apk/debug/app-debug.apk
```

Installation :

```bash
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

Si Android demande une voix française, ouvrir les réglages de synthèse vocale
du téléphone et installer/sélectionner une voix française.
