# FF Panel V3
Built by modifying FF Panel V2.

## Lock
The dashboard starts locked. No feature is usable until `/api/key/activate` accepts a valid key. Normal and Premium each have 20 keys; one key binds to one device on the server.

## Features
- Mandatory Key Gate
- Normal/Premium tier separation
- Aim Trainer 0–100
- Network health and latency checks
- Generic proxy-format/diagnostics UI (does not route game traffic)
- Android game-launch intent buttons
- Event Log
- Risk Profile display: Normal 67 / Premium 100 = internal feature score only, not a ban-prevention guarantee.

## Safety
No game memory editing, injection, hooks, traffic tampering, anti-cheat bypass, or ban-evasion functionality.

## Run
`npm install` then `node server.js`
