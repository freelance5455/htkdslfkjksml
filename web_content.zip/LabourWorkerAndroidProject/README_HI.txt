लेबर ऐप (Worker) - Android Studio प्रोजेक्ट

यह दूसरा ऐप है: लेबर अपने मोबाइल नंबर से लॉगिन स्क्रीन देखेगा; ऐप में पंच इन/पंच आउट और अपनी हाजिरी/पेमेंट का UI बनाया गया है।

APK बनाने के लिए:
1. Android Studio में इस फोल्डर को Open करें।
2. Gradle Sync पूरा होने दें।
3. Android SDK Platform 35 उपलब्ध रखें।
4. Build > Build Bundle(s) / APK(s) > Build APK(s) चुनें।
5. APK app/build/outputs/apk/debug/app-debug.apk में मिलेगा।

जरूरी: यह अभी UI/डेमो प्रोटोटाइप है, असली OTP SMS नहीं भेजता और डेटा Admin ऐप से ऑनलाइन सिंक नहीं होता। OTP के लिए Firebase Phone Authentication, Firestore में Admin द्वारा बनाए गए Worker रिकॉर्ड की जाँच, सुरक्षित access rules, GPS/geofence validation और वास्तविक पेमेंट/हाजिरी डेटा कनेक्शन जोड़ना बाकी है। पंच इन/आउट का वर्तमान डेमो डेटा केवल ऐप खुला रहने तक स्क्रीन पर दिखता है; इसे असली रिकॉर्ड न मानें।
