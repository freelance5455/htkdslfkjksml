# ANONYMOUX STUDIO 2.5.6 — Change Log

## Visual system
- Added a unified noir / neon-lime visual layer for the authenticated platform and public entry page.
- Reworked the Agent Conversation screen with a responsive live transcript, accessible status indicator, composer and voice controls.
- Added new generated, text-free visual assets derived from the supplied screenshots' visual direction: monochrome masked identity, cinematic creator portrait, motion-transfer dancer and studio equipment.
- Applied image-backed dashboard workspace tiles, refreshed Explore gallery thumbnails, glass surfaces, button states, focus states and mobile responsive refinements.
- Kept the Explore route and shared video workspace; Shorts Studio remains a safe not-found route and is not linked in navigation.

## Fish Audio Agent Studio
- Fixed the adapter's restrictive endpoint validator. It previously rejected documented nested endpoints such as `/agents/{id}/config`, `/agents/{id}/publish`, `/sessions/{id}/end`, and knowledge-source endpoints before any HTTP request was made.
- Added strict method/path allowlisting for current documented Fish Audio Agent endpoints.
- Kept API credentials server-side and retained sanitized provider diagnostics.
- Improved cleanup when browser session startup fails after the provider session was created.
- Added measured web-session conversation cost reconciliation using Fish Audio's provider-reported `duration_seconds` and its currently published per-minute price.
- Added admin-configurable provider USD/minute and ANON credits-per-USD conversion. If the conversion is zero, measured provider usage is recorded but no wallet debit occurs.
- Reconciliation is idempotent per provider session / generation record; unpaid measured usage can be retried after the wallet is funded.

## Testing caveats
- Static syntax and contract checks are included in the release report. Live Fish Audio and Flutterwave account tests require the deployment's own API credentials and a staging domain.
