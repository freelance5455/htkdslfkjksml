@echo off
setlocal
cd /d %~dp0
echo === BMA Android build setup ===
echo 1. Installing Capacitor packages...
call npm.cmd install
if errorlevel 1 goto :fail
echo 2. Creating Android project if missing...
if not exist android call npx.cmd cap add android
if errorlevel 1 goto :fail
echo 3. Syncing web app...
call npx.cmd cap sync android
if errorlevel 1 goto :fail
echo 4. Building debug APK...
cd android
call gradlew.bat assembleDebug
if errorlevel 1 goto :fail
echo.
echo APK created under android\app\build\outputs\apk\debug\app-debug.apk
goto :end
:fail
echo.
echo Build failed. Check the error above.
exit /b 1
:end
pause
