# Screen Map

## Entry
Splash -> Activation (first run) -> App Lock (if enabled) -> Dashboard

## Dashboard
Dashboard -> Customers View All
Dashboard -> Payments View All
Dashboard -> Follow-ups View All
Dashboard -> Reports

## Customers
Customers -> Search/Filter -> Customer Profile
Customers -> Add Customer
Customer Profile -> Edit
Customer Profile -> Payments
Customer Profile -> Follow-up
Customer Profile -> Location
Customer Profile -> Notes

## Payments
Payments -> Add Payment -> Customer Profile
Payments -> Payment detail

## Follow-ups
Follow-ups -> Overdue / Today / Upcoming / Completed
Follow-up -> Customer Profile

## More
More -> Business Profile
More -> UPI QR
More -> Settings
More -> App Lock
More -> Backup / Restore
More -> Contact Us
More -> About Us
More -> Business Assistant

## AI
Assistant -> message -> parsed action preview -> confirm/cancel -> repository
