# BMA V4 — My Profile

## Included
- Instagram-style bottom navigation on mobile: Dashboard, AI, Customers, Search, My Profile.
- My Profile sections: Edit Profile, Product Gallery, Work Information, Sales Details, Help & Support, Logout.
- Top-right Settings icon on My Profile.
- Profile photo upload.
- Product Gallery with photo + product name + details.
- Work Information form.
- Sales Details derived live from customers/payments.
- Mountain scenery background and lightweight liquid-glass UI.
- Supabase Realtime subscriptions for customers, payments and follow-ups.

## Supabase setup
Run `SUPABASE_V4_SETUP.sql` in the existing Supabase project before using cloud profile/gallery/work storage. The SQL adds profile fields, creates owner-protected tables, creates storage buckets and enables realtime publication entries.

The browser must only use the Supabase publishable key. Never place a service-role/secret key in the frontend.
