# Database Contract

Existing cloud tables:
- profiles
- customers
- payments
- followups
- devices
- activation_codes
- business_settings

Relationships:
customers.id -> payments.customer_id
customers.id -> followups.customer_id

Rules:
1. Money is decimal/numeric, never floating-point in business logic.
2. Payment amount > 0.
3. Customer status: active | inactive | pending.
4. Payment mode: cash | upi | bank | other.
5. Follow-up status: pending | completed | cancelled.
6. Deactivation is distinct from logout.
7. RLS remains mandatory.
8. The app should calculate pending as order total minus recorded payments, with business-specific safeguards against negative pending.
