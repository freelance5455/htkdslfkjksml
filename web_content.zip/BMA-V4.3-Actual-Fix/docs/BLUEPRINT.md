# Business Panel — Master Blueprint v1

## 1. Product
Private Android-first CRM for a small business. Offline-first, Supabase-backed sync, activation/device control, Android system authentication, and an optional management AI assistant.

## 2. Navigation
Bottom navigation:
- Dashboard
- Customers
- Payments
- Follow-ups
- More

Floating action:
- Add Customer

Dashboard rule:
Only compact previews. Every major area has View All -> dedicated full screen.

## 3. Core modules
### Dashboard
Total Customers, Active Customers, Follow-ups Due, Total Orders, Payments Received, Pending Payment, Today's Follow-ups, Recent Payments.

### Customers
Search/filter, active/inactive/pending, add/edit, customer profile, photo, mobile, notes, order amount, last visit, next follow-up, GPS coordinates, saved location, Google Maps launch.

### Payments
Received, pending, history, payment mode (cash/upi/bank/other), date, note.

### Follow-ups
Overdue, today, upcoming, completed/cancelled.

### Reports
Customer/order/payment/pending totals, date filters, future charts.

### More
Business Profile, UPI QR, Settings, App Lock, Backup/Restore, Contact Us, About Us.

## 4. Security
First launch -> activation code -> device registration.
App lock -> Android system authentication / biometrics via platform APIs. Never read or store the device PIN/password.
Supabase client uses publishable key only. Secret/service-role keys stay server-side.
RLS protects production data.

## 5. Offline-first
Local DB is source for immediate UI.
Operations are queued with sync state:
pending -> syncing -> synced / failed.
Conflict policy: server timestamp + explicit business rules; payments should never be silently overwritten.

Local-only:
customers, payments, follow-ups, notes, photos, UPI QR, cached reports.

Online:
Supabase sync, activation verification, device status, AI requests, maps.

## 6. AI Business Assistant
AI is an action interpreter, not a free-form database administrator.
Examples:
- "Sharma Traders ka 15000 payment add kar, UPI."
- "Aaj ke follow-ups batao."
- "Is month ka summary batao."
- "Kis customer ka payment sabse pehle follow-up karna chahiye?"

Write actions require confirmation:
AI -> structured action preview -> Confirm -> app service -> local DB -> sync.

Forbidden direct AI actions:
delete all data, change security, change activation system, change operator access, bulk destructive operations.

## 7. Data model
customers
payments
followups
business_settings
devices
activation_codes
profiles
local_sync_queue (device-local)
ai_action_audit (optional server table for approved AI actions)

## 8. UX visual system
Palette:
Obsidian background, titanium surfaces, soft white text, restrained electric blue accent.
Liquid-glass effect only for selected cards/sheets.
Large touch targets, clean typography, subtle motion.

## 9. Build phases
Phase A: blueprint + UX contract (this package)
Phase B: Flutter shell + design system
Phase C: local DB + repositories
Phase D: Supabase auth/sync/RLS
Phase E: activation/device security
Phase F: GPS/maps + QR
Phase G: AI assistant
Phase H: testing + APK/release

## 10. Definition of done
No demo data in production.
No secrets in client.
All destructive actions confirmed.
Offline CRUD works.
Sync is observable/retryable.
App lock uses platform authentication.
Activation can be remotely deactivated.
AI cannot bypass confirmation for writes.
