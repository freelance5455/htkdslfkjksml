# Infrastructure

Flutter Android app
    |
    +-- Presentation / Riverpod or equivalent state layer
    |
    +-- Domain use-cases
    |
    +-- Repositories
    |       +-- Local database
    |       +-- Supabase remote
    |
    +-- Sync queue
    |
    +-- Platform services
            +-- Android authentication/biometrics
            +-- GPS / Maps
            +-- Secure storage
            +-- File/photo storage

Cloud:
Supabase Auth
Supabase Postgres + RLS
Supabase Storage (business/customer images as required)
Edge Function(s) for privileged operations / AI gateway
Netlify/Vercel only for the existing Operator web panel, not as the Android backend.

AI:
Flutter app -> secure backend/Edge Function -> AI provider -> validated structured action -> app confirmation -> repository.
Do not put an AI provider secret key in the APK.

Suggested Flutter packages later:
- flutter_riverpod
- go_router
- supabase_flutter
- drift (or another local SQLite abstraction)
- flutter_secure_storage
- local_auth
- geolocator
- url_launcher
- image_picker
- qr_flutter / mobile_scanner as needed
- intl

Package choices are provisional until the Flutter environment is available.
