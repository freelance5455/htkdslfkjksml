# BMA V4.1 — Refined CRM + Android-ready

This build fixes the V4 interaction issues and prepares the CRM for an Android APK through Capacitor.

## Fixed / added
- Functional navigation with Dashboard, AI, Customers, Payments, Follow-ups, Reports, Search, Profile and Settings.
- Search uses event listeners instead of fragile inline `oninput` handlers.
- Customer shop photo upload and preview.
- Customer profile includes a mini Google Maps iframe when an address is saved, plus an Open Google Maps button.
- Customer location can be added/edited directly from the profile map section.
- Profile: Edit Profile, Product Gallery, Work Information, Sales Details, Help & Support, red Logout.
- Product Gallery uploads images to Supabase Storage and stores product information in Supabase.
- Profile photo uploads to Supabase Storage.
- Supabase realtime listeners for customers, payments, follow-ups, gallery and work information.
- AI Preview → Confirm → Execute remains enforced for data-changing AI actions.
- PWA manifest + service worker included.
- Capacitor Android wrapper configuration and `BUILD-ANDROID.bat` included.

## Supabase setup
Run `SUPABASE_V4_SETUP.sql` in the existing Supabase project's SQL Editor. It adds only the fields/tables/storage buckets needed for these V4.1 features and enables realtime publication entries safely.

## Browser test
Serve this folder from a web server, not `file://`. Example:
`python -m http.server 8080`
Then open the shown localhost address.

## Android APK
1. Install Node.js and Android Studio.
2. Open this folder in Command Prompt.
3. Run `BUILD-ANDROID.bat`.
4. The first run installs Capacitor, creates the Android project and builds a debug APK.
5. APK output: `android\\app\\build\\outputs\\apk\\debug\\app-debug.apk`

For a release APK/AAB, open the generated `android` project in Android Studio and create a signed release build.

## Important
- This package is Android-ready source; an APK is not prebuilt inside the ZIP.
- Real Supabase data requires the existing project's publishable key + authenticated operator session.
- AI requires the Netlify function deployment and server-side AI configuration.
- Google Maps display depends on a usable customer address and the WebView/network being allowed to load Google Maps.
- Never put a Supabase service-role/secret key in the browser or APK.

## Checks performed
- Node syntax check: PASS for app.js and both Netlify functions.
- Static feature checks: PASS.
- ZIP integrity: to be checked after packaging.

## Not performed in this environment
- Real Android Studio/Gradle APK compilation.
- Browser click-by-click E2E test.
- Live Supabase write/realtime test against the user's production data.


## V4.2 stability fixes
- Hardened startup/rendering so one UI error does not blank the whole app.
- Search inputs have explicit event wiring.
- Corrupt localStorage gallery/work data no longer prevents startup.
- Safe minimal service worker included for mobile/PWA use.
