import OpenAI from 'openai';
import { createClient } from '@supabase/supabase-js';

const headers = {'content-type':'application/json','cache-control':'no-store'};
const json = (body,status=200)=>new Response(JSON.stringify(body),{status,headers});
const allowed = {customers:['insert','update','delete'],payments:['insert','delete'],followups:['insert','update','delete']};

async function authClient(req){
  const url=process.env.SUPABASE_URL;
  const key=process.env.SUPABASE_PUBLISHABLE_KEY;
  if(!url||!key) throw new Error('Supabase server configuration is missing');
  const auth=req.headers.get('authorization')||'';
  if(!auth.startsWith('Bearer ')) return null;
  const sb=createClient(url,key,{global:{headers:{Authorization:auth}}});
  const {data:{user},error}=await sb.auth.getUser();
  if(error||!user) return null;
  return {sb,user};
}

async function news(){
  const feeds=[
    'https://feeds.bbci.co.uk/news/business/rss.xml',
    'https://www.cnbc.com/id/100003114/device/rss/rss.html'
  ];
  const out=[];
  for(const feed of feeds){try{
    const r=await fetch(feed,{headers:{'user-agent':'BMA/1.0'}}); if(!r.ok) continue;
    const xml=await r.text();
    for(const m of xml.matchAll(/<item>[\s\S]*?<title>([\s\S]*?)<\/title>[\s\S]*?<link>([\s\S]*?)<\/link>[\s\S]*?(?:<description>([\s\S]*?)<\/description>)?[\s\S]*?<\/item>/g)){
      const clean=s=>String(s||'').replace(/<!\[CDATA\[|\]\]>/g,'').replace(/<[^>]+>/g,' ').replace(/&amp;/g,'&').trim();
      out.push({title:clean(m[1]),url:clean(m[2]),summary:clean(m[3]).slice(0,300)});
    }
  }catch{}}
  return out.slice(0,12);
}

async function snapshot(sb){
  const [c,p,f]=await Promise.all([
    sb.from('customers').select('*').limit(500),
    sb.from('payments').select('*').order('payment_date',{ascending:false}).limit(500),
    sb.from('followups').select('*').order('followup_date',{ascending:true}).limit(500)
  ]);
  if(c.error||p.error||f.error) throw new Error('Could not read business data');
  return {customers:c.data||[],payments:p.data||[],followups:f.data||[]};
}

function balanceData(data){
  const paid={}; for(const p of data.payments) paid[p.customer_id]=(paid[p.customer_id]||0)+Number(p.amount||0);
  return data.customers.map(c=>({...c,total_paid:paid[c.id]||0,outstanding:Math.max(0,Number(c.order_amount||0)-(paid[c.id]||0))}));
}

export default async (req)=>{
  try{
    const ctx=await authClient(req); if(!ctx) return json({error:'Authentication required'},401);
    const body=await req.json(); const {sb}=ctx;
    if(body.action){
      const {table,operation,values,id}=body.action;
      if(!allowed[table]?.includes(operation)) return json({error:'Action not allowed'},400);
      if(operation==='insert'){
        const {data,error}=await sb.from(table).insert(values).select().single(); if(error) return json({error:error.message},400); return json({executed:true,data});
      }
      if(!id) return json({error:'Record id required'},400);
      if(operation==='update'){
        const {data,error}=await sb.from(table).update(values).eq('id',id).select().single(); if(error) return json({error:error.message},400); return json({executed:true,data});
      }
      const {error}=await sb.from(table).delete().eq('id',id); if(error) return json({error:error.message},400); return json({executed:true});
    }
    const data=await snapshot(sb); const balanced=balanceData(data); const market=await news();
    const client=new OpenAI();
    const system=`You are BMA, a practical business management assistant. Answer in the user's language. You have business data and recent market/business news. Be concise but useful. Never invent numbers. For any data-changing request, DO NOT execute it; instead return a PREVIEW object with table, operation, id if applicable, and safe values. Allowed mutation tables: customers, payments, followups. Never propose arbitrary SQL, auth/security changes, activation-code changes, or bulk destructive actions. If today's follow-ups or incomplete payments are relevant, call them out proactively. Current date: ${new Date().toISOString().slice(0,10)}.`;
    const completion=await client.chat.completions.create({model:'gpt-4o-mini',temperature:.2,messages:[
      {role:'system',content:system},
      {role:'user',content:JSON.stringify({request:body.prompt,data:{customers:balanced,payments:data.payments,followups:data.followups},market_news:market})}
    ],response_format:{type:'json_object'}});
    const raw=completion.choices?.[0]?.message?.content||'{}';
    let result; try{result=JSON.parse(raw)}catch{result={answer:raw}}
    return json({answer:result.answer||'',preview:result.preview||null,market_news:market});
  }catch(e){ console.error(e); return json({error:e.message||'AI request failed'},500); }
};
