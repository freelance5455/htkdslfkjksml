import {createClient} from '@supabase/supabase-js';
export default async()=>{
  // Scheduled hook reserved for a future notification channel (email/push/SMS).
  // It intentionally does not send messages or mutate business data.
  const url=process.env.SUPABASE_URL,key=process.env.SUPABASE_PUBLISHABLE_KEY;
  if(!url||!key) return new Response('BMA daily briefing not configured',{status:200});
  const sb=createClient(url,key);
  return Response.json({ok:true,message:'Daily briefing scheduler is installed; connect a notification provider to deliver it.'});
};
