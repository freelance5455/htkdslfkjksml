-- BMA V4.1 setup for existing Supabase project.
-- Run in Supabase SQL Editor. No new project is created.

alter table public.profiles add column if not exists name text;
alter table public.profiles add column if not exists email text;
alter table public.profiles add column if not exists location text;
alter table public.profiles add column if not exists avatar_url text;
alter table public.customers add column if not exists shop_photo_url text;

create table if not exists public.product_gallery (
  id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
  name text not null, details text, image_url text not null, created_at timestamptz not null default now()
);
create table if not exists public.work_information (
  id uuid primary key default gen_random_uuid(), user_id uuid not null unique references auth.users(id) on delete cascade,
  business_name text, role text, hours text, description text, updated_at timestamptz not null default now()
);

alter table public.product_gallery enable row level security;
alter table public.work_information enable row level security;
drop policy if exists "product_gallery_owner_all" on public.product_gallery;
create policy "product_gallery_owner_all" on public.product_gallery for all to authenticated using (auth.uid()=user_id) with check (auth.uid()=user_id);
drop policy if exists "work_information_owner_all" on public.work_information;
create policy "work_information_owner_all" on public.work_information for all to authenticated using (auth.uid()=user_id) with check (auth.uid()=user_id);

insert into storage.buckets (id,name,public) values ('profile-photos','profile-photos',true) on conflict (id) do nothing;
insert into storage.buckets (id,name,public) values ('product-gallery','product-gallery',true) on conflict (id) do nothing;
insert into storage.buckets (id,name,public) values ('shop-photos','shop-photos',true) on conflict (id) do nothing;

drop policy if exists "profile_photos_owner_write" on storage.objects;
create policy "profile_photos_owner_write" on storage.objects for all to authenticated using (bucket_id='profile-photos' and (storage.foldername(name))[1]=auth.uid()::text) with check (bucket_id='profile-photos' and (storage.foldername(name))[1]=auth.uid()::text);
drop policy if exists "product_gallery_owner_write" on storage.objects;
create policy "product_gallery_owner_write" on storage.objects for all to authenticated using (bucket_id='product-gallery' and (storage.foldername(name))[1]=auth.uid()::text) with check (bucket_id='product-gallery' and (storage.foldername(name))[1]=auth.uid()::text);
drop policy if exists "shop_photos_owner_write" on storage.objects;
create policy "shop_photos_owner_write" on storage.objects for all to authenticated using (bucket_id='shop-photos' and (storage.foldername(name))[1]=auth.uid()::text) with check (bucket_id='shop-photos' and (storage.foldername(name))[1]=auth.uid()::text);

-- Add only if not already present in the publication.
do $$ begin
  begin execute 'alter publication supabase_realtime add table public.customers'; exception when duplicate_object then null; end;
  begin execute 'alter publication supabase_realtime add table public.payments'; exception when duplicate_object then null; end;
  begin execute 'alter publication supabase_realtime add table public.followups'; exception when duplicate_object then null; end;
  begin execute 'alter publication supabase_realtime add table public.product_gallery'; exception when duplicate_object then null; end;
  begin execute 'alter publication supabase_realtime add table public.work_information'; exception when duplicate_object then null; end;
end $$;
