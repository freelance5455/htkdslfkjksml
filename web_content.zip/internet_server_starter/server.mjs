import http from "node:http";
import fs from "node:fs";
import path from "node:path";
import os from "node:os";
import { fileURLToPath } from "node:url";

const here = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(here, "public");
const PORT = Number(process.env.PORT || 8080);
const PASSWORD = process.env.SERVER_PASSWORD || "";
if (PASSWORD.length < 12) {
  console.error("ضع كلمة مرور قوية بطول 12 حرفاً على الأقل في SERVER_PASSWORD ثم أعد التشغيل.");
  process.exit(1);
}
const mime = {".html":"text/html; charset=utf-8",".css":"text/css; charset=utf-8",".js":"text/javascript; charset=utf-8",".json":"application/json; charset=utf-8",".png":"image/png",".jpg":"image/jpeg",".jpeg":"image/jpeg",".svg":"image/svg+xml",".txt":"text/plain; charset=utf-8",".pdf":"application/pdf"};
function authorized(req) {
  const h = req.headers.authorization || "";
  if (!h.startsWith("Basic ")) return false;
  try {
    const decoded = Buffer.from(h.slice(6), "base64").toString();
    const i = decoded.indexOf(":");
    return i >= 0 && decoded.slice(i + 1) === PASSWORD;
  } catch { return false; }
}
function send(res, code, body, type="text/plain; charset=utf-8") {
  res.writeHead(code, {"Content-Type":type,"X-Content-Type-Options":"nosniff","X-Frame-Options":"DENY","Referrer-Policy":"no-referrer"});
  res.end(body);
}
function localAddress() {
  for (const list of Object.values(os.networkInterfaces())) for (const n of list || [])
    if (n.family === "IPv4" && !n.internal) return `http://${n.address}:${PORT}`;
  return `http://127.0.0.1:${PORT}`;
}
const server = http.createServer((req,res) => {
  if (!authorized(req)) {
    res.writeHead(401, {"WWW-Authenticate":'Basic realm="Internet Server", charset="UTF-8"',"Cache-Control":"no-store"});
    return res.end("Authentication required");
  }
  const url = new URL(req.url, `http://${req.headers.host || "localhost"}`);
  if (url.pathname === "/_server/status") return send(res,200,JSON.stringify({status:"online",localUrl:localAddress()}),"application/json");
  if (url.pathname === "/_server/files") {
    const files = [];
    const walk = (dir, prefix="") => {
      for (const ent of fs.readdirSync(dir,{withFileTypes:true})) {
        if (ent.name.startsWith(".")) continue;
        const rel = path.posix.join(prefix,ent.name);
        if (ent.isDirectory()) walk(path.join(dir,ent.name),rel); else files.push(rel);
      }
    };
    walk(ROOT);
    return send(res,200,JSON.stringify({files}),"application/json");
  }
  let pathname;
  try { pathname = decodeURIComponent(url.pathname); } catch { return send(res,400,"Bad URL"); }
  if (pathname === "/") pathname = "/index.html";
  const target = path.resolve(ROOT, "." + pathname);
  if (!target.startsWith(ROOT + path.sep) && target !== ROOT) return send(res,403,"Forbidden");
  fs.stat(target,(err,st)=>{
    if (err || !st.isFile()) return send(res,404,"Not found");
    const ext = path.extname(target).toLowerCase();
    res.writeHead(200,{"Content-Type":mime[ext] || "application/octet-stream","X-Content-Type-Options":"nosniff","X-Frame-Options":"DENY","Cache-Control":"no-store"});
    fs.createReadStream(target).pipe(res);
  });
});
server.listen(PORT,"127.0.0.1",()=>console.log(`Server running at http://127.0.0.1:${PORT}\nLAN info: ${localAddress()}\nPress Ctrl+C to stop.`));
