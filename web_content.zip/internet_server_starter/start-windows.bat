@echo off
set /p SERVER_PASSWORD=Enter a strong password (12+ characters):
set PORT=8080
node server.mjs
pause
