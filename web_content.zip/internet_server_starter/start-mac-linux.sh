#!/usr/bin/env sh
printf "Enter a strong password (12+ characters): "
stty -echo
read SERVER_PASSWORD
stty echo
printf "\n"
export SERVER_PASSWORD
export PORT=8080
node server.mjs
