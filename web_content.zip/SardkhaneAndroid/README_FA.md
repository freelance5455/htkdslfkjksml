# سردخانه مرکزی میانه — پروژه آزمایشی Android

این پروژه، فایل HTML آزمایشی را داخل `app/src/main/assets/index.html` قرار می‌دهد و با Android WebView اجرا می‌کند.

## ساخت APK
1. پوشه `SardkhaneAndroid` را در Android Studio باز کنید.
2. اجازه دهید Gradle Sync انجام شود.
3. از منوی Build گزینه Build APK(s) را بزنید.
4. APK آزمایشی در مسیر `app/build/outputs/apk/debug/app-debug.apk` ایجاد می‌شود.

## نکته
کتابخانه Excel در HTML فعلی هنوز از CDN استفاده می‌کند؛ بنابراین برای کارکرد Excel در حالت کاملاً آفلاین باید در مرحله بعد `xlsx.full.min.js` داخل assets قرار گیرد.
