'use strict';
/* ============================================================
   Configuração (topo do código)
   ============================================================ */
const APP_NAME = 'ProTracker Elite';
const APP_VERSION = '4.0.0';
const SUPPORT_URL = ""; // opcional: se vazia, nenhum botão de apoio aparece

/* ---------- Utilitários ---------- */
const U = {
  uid(prefix='id'){ return prefix + '_' + Date.now().toString(36) + Math.random().toString(36).slice(2,7); },
  el(tag, props={}, children=[]){
    const node = document.createElement(tag);
    for(const [k,v] of Object.entries(props)){
      if(v === null || v === undefined || v === false) continue;
      if(k === 'class') node.className = v;
      else if(k === 'style' && typeof v === 'object'){
        for(const [sk,sv] of Object.entries(v)){
          if(sk.includes('-')) node.style.setProperty(sk, sv); else node.style[sk] = sv;
        }
      }
      else if(k === 'text') node.textContent = v;
      else if(k === 'html') node.innerHTML = v; // somente conteúdo estático confiável (SVG gerado por código)
      else if(k.startsWith('on') && typeof v === 'function') node.addEventListener(k.slice(2).toLowerCase(), v);
      else node.setAttribute(k, v === true ? '' : v);
    }
    (Array.isArray(children) ? children : [children]).forEach(c=>{
      if(c == null || c === false) return;
      node.appendChild(typeof c === 'string' ? document.createTextNode(c) : c);
    });
    return node;
  },
  clear(node){ while(node.firstChild) node.removeChild(node.firstChild); },
  clone(o){ return JSON.parse(JSON.stringify(o)); },
  norm(s){ return String(s||'').trim().toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/\s+/g,' '); },
  slug(s){ return U.norm(s).replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'').slice(0,40) || 'x'; },
  parseNum(s){
    if(s === '' || s == null) return null;
    const n = parseFloat(String(s).replace(',', '.'));
    return Number.isFinite(n) ? n : null;
  },
  pad(n){ return String(n).padStart(2,'0'); },
  /* datas locais como chave 'yyyy-mm-dd' */
  dayKey(ts){ const d = new Date(ts); return d.getFullYear() + '-' + U.pad(d.getMonth()+1) + '-' + U.pad(d.getDate()); },
  keyToDate(k){ const p = k.split('-').map(Number); return new Date(p[0], p[1]-1, p[2]); },
  keyToTs(k){ return U.keyToDate(k).getTime(); },
  addDays(k, n){ const d = U.keyToDate(k); d.setDate(d.getDate()+n); return U.dayKey(d.getTime()); },
  dow(k){ return U.keyToDate(k).getDay(); },
  weekKey(k){ const d = U.keyToDate(k); d.setDate(d.getDate() - ((d.getDay()+6)%7)); return U.dayKey(d.getTime()); }, // segunda
  daysBetween(a, b){ return Math.round((U.keyToTs(b) - U.keyToTs(a)) / 86400000); },
  hash(str){ let h = 2166136261; for(let i=0;i<str.length;i++){ h ^= str.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; },
  rng(seed){ let a = seed >>> 0; return function(){ a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; },
  splitList(s){ return String(s || '').split(',').map(x=>x.trim()).filter(Boolean); }
};

/* SVG helpers */
const SVGNS = 'http://www.w3.org/2000/svg';
const ICONS = {
  check:'<polyline points="20 6 9 17 4 12"/>',
  plus:'<line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>',
  minus:'<line x1="5" y1="12" x2="19" y2="12"/>',
  play:'<polygon points="5 3 19 12 5 21 5 3"/>',
  edit:'<path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/>',
  trash:'<polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/>',
  up:'<polyline points="18 15 12 9 6 15"/>',
  down:'<polyline points="6 9 12 15 18 9"/>',
  copy:'<rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>',
  timer:'<circle cx="12" cy="13" r="8"/><polyline points="12 9 12 13 14 15"/><line x1="9" y1="2" x2="15" y2="2"/>',
  clock:'<circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>',
  bars:'<line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/>',
  share:'<circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><line x1="8.6" y1="13.5" x2="15.4" y2="17.5"/><line x1="15.4" y1="6.5" x2="8.6" y2="10.5"/>',
  download:'<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/>',
  close:'<line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>',
  user:'<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',
  dumbbell:'<path d="M6.5 6.5v11"/><path d="M17.5 6.5v11"/><path d="M3.5 9v6"/><path d="M20.5 9v6"/><path d="M6.5 12h11"/>',
  gear:'<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/>',
  info:'<circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/>',
  undo:'<polyline points="1 4 1 10 7 10"/><path d="M3.51 15a9 9 0 1 0 2.13-9.36L1 10"/>'
};
function icon(name, size){
  const svg = document.createElementNS(SVGNS,'svg');
  svg.setAttribute('viewBox','0 0 24 24'); svg.setAttribute('fill','none'); svg.setAttribute('stroke','currentColor');
  svg.setAttribute('stroke-width','2'); svg.setAttribute('stroke-linecap','round'); svg.setAttribute('stroke-linejoin','round');
  svg.setAttribute('aria-hidden','true');
  if(size){ svg.style.width = size+'px'; svg.style.height = size+'px'; }
  svg.innerHTML = ICONS[name] || '';
  return svg;
}
