package com.example.ytanalytics;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.IntentSender;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.webkit.WebViewAssetLoader;
import com.google.android.gms.auth.api.identity.AuthorizationRequest;
import com.google.android.gms.auth.api.identity.AuthorizationResult;
import com.google.android.gms.auth.api.identity.Identity;
import com.google.android.gms.common.api.Scope;
import java.util.Arrays;
import org.json.JSONObject;

public class MainActivity extends Activity {
    static final int REQ = 1001;
    WebView web;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this)).build();
        web.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                return loader.shouldInterceptRequest(r.getUrl());
            }
        });
        web.addJavascriptInterface(new Bridge(), "Android");
        web.loadUrl("https://appassets.androidplatform.net/assets/index.html");
    }

    class Bridge {
        @JavascriptInterface public void login() { runOnUiThread(() -> startAuth()); }
        @JavascriptInterface public void openUrl(String u) {
            runOnUiThread(() -> startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(u))));
        }
        @JavascriptInterface public void copy(String t) {
            runOnUiThread(() -> ((ClipboardManager) getSystemService(CLIPBOARD_SERVICE))
                .setPrimaryClip(ClipData.newPlainText("text", t)));
        }
    }

    void startAuth() {
        AuthorizationRequest req = AuthorizationRequest.builder().setRequestedScopes(Arrays.asList(
            new Scope("https://www.googleapis.com/auth/yt-analytics.readonly"),
            new Scope("https://www.googleapis.com/auth/youtube.readonly"))).build();
        Identity.getAuthorizationClient(this).authorize(req)
            .addOnSuccessListener(r -> {
                if (r.hasResolution()) {
                    try {
                        startIntentSenderForResult(r.getPendingIntent().getIntentSender(), REQ, null, 0, 0, 0);
                    } catch (IntentSender.SendIntentException e) { fail(e.getMessage()); }
                } else deliver(r.getAccessToken());
            })
            .addOnFailureListener(e -> fail(String.valueOf(e.getMessage())));
    }

    @Override protected void onActivityResult(int code, int res, Intent data) {
        super.onActivityResult(code, res, data);
        if (code != REQ) return;
        if (res != RESULT_OK || data == null) { fail("ورود لغو شد"); return; }
        try {
            AuthorizationResult r = Identity.getAuthorizationClient(this).getAuthorizationResultFromIntent(data);
            deliver(r.getAccessToken());
        } catch (Exception e) { fail(String.valueOf(e.getMessage())); }
    }

    void deliver(String t) { web.evaluateJavascript("window.onNativeToken(" + JSONObject.quote(t) + ")", null); }
    void fail(String m) { web.evaluateJavascript("window.onNativeError(" + JSONObject.quote(m) + ")", null); }
}
