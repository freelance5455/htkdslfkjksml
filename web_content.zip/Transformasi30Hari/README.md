# Transformasi 30 Hari — Android

Aplikasi Android ringkas berbahasa Melayu untuk checklist harian, rutin senaman, rekod pemakanan dan sejarah berat badan. Data disimpan secara setempat pada peranti melalui localStorage WebView.

## Cara paling mudah bina APK secara online (percuma)

Projek ini disediakan dengan GitHub Actions. Selepas projek dimuat naik ke repositori GitHub:

1. Buka tab **Actions** pada repositori.
2. Pilih workflow **Build Transformasi 30 Hari APK**.
3. Tekan **Run workflow**.
4. Tunggu sehingga job selesai dengan status hijau.
5. Buka run tersebut dan muat turun artifact **Transformasi30Hari-debug-apk**.
6. Extract ZIP artifact dan pasang `app-debug.apk` pada telefon Android.

Workflow menggunakan Java 17, Android SDK 35 dan Gradle 8.9. Ia membina APK debug yang boleh dipasang untuk ujian; ia bukan signed release APK untuk edaran Play Store.

## Bina secara lokal

1. Buka folder `Transformasi30Hari` dalam Android Studio.
2. Pastikan Android SDK Platform 35 tersedia.
3. Jalankan Gradle task `assembleDebug`.
4. APK berada di `app/build/outputs/apk/debug/app-debug.apk`.

Package ID: `com.transformasi30hari.app`  
Min Android: Android 6.0 (API 23)
