import "dotenv/config";
import express from "express";
import multer from "multer";
import { fal } from "@fal-ai/client";
import { File } from "node:buffer";

const app = express();
const port = process.env.PORT || 3000;

if (!process.env.FAL_KEY) {
  console.warn("⚠️ FAL_KEY no está configurada. La interfaz abrirá, pero la generación no funcionará.");
}

fal.config({ credentials: process.env.FAL_KEY || "" });

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 200 * 1024 * 1024 }
});

app.use(express.static("public"));

function buildRewritePrompt(userPrompt, style, keepAudio, keepCamera, keepDuration) {
  const constraints = [
    "Rewrite the supplied video rather than merely describing or editing it.",
    "Preserve the identity and appearance of the main subjects whenever possible.",
    "Preserve the original action choreography and temporal progression unless the user's instruction explicitly changes them.",
    keepCamera ? "Keep the original camera framing, camera movement and shot composition as closely as possible." : "",
    keepDuration ? "Keep the original duration and pacing as closely as the model allows." : "",
    keepAudio ? "Preserve the original audio intent; if the visual rewrite makes the original audio impossible, keep timing aligned so audio can be remixed later." : "",
    `Visual style: ${style}.`,
    `USER'S REWRITE INSTRUCTION: ${userPrompt}`
  ].filter(Boolean);

  return constraints.join("\n");
}

app.post("/api/rewrite", upload.single("video"), async (req, res) => {
  try {
    if (!process.env.FAL_KEY) {
      return res.status(500).json({
        error: "FAL_KEY no configurada. Crea un archivo .env y añade tu clave de fal."
      });
    }

    if (!req.file) {
      return res.status(400).json({ error: "No se recibió ningún video." });
    }

    if (!req.file.mimetype.startsWith("video/")) {
      return res.status(400).json({ error: "El archivo debe ser un video." });
    }

    const userPrompt = String(req.body.prompt || "").trim();
    if (!userPrompt) {
      return res.status(400).json({ error: "Escribe una instrucción para la IA." });
    }

    const style = String(req.body.style || "Cinematic");
    const keepAudio = req.body.keepAudio !== "false";
    const keepCamera = req.body.keepCamera !== "false";
    const keepDuration = req.body.keepDuration !== "false";

    // fal admite subir el archivo directamente y devuelve una URL utilizable por el modelo.
    const file = new File([req.file.buffer], req.file.originalname, {
      type: req.file.mimetype
    });
    const videoUrl = await fal.storage.upload(file);

    const prompt = buildRewritePrompt(
      userPrompt,
      style,
      keepAudio,
      keepCamera,
      keepDuration
    );

    // Modelo video-to-video pensado para editar/reimaginar un video existente.
    const result = await fal.subscribe(
      "fal-ai/kling-video/o1/video-to-video/edit",
      {
        input: {
          prompt,
          video_url: videoUrl
        },
        logs: true,
        onQueueUpdate: (update) => {
          if (update.status === "IN_PROGRESS") {
            console.log(update.logs?.map(x => x.message).join("\n") || "Generando...");
          }
        }
      }
    );

    const output = result?.data?.video?.url || result?.data?.video;
    if (!output) {
      console.error(result);
      return res.status(502).json({ error: "El modelo terminó sin devolver un video." });
    }

    res.json({
      ok: true,
      videoUrl: output,
      requestId: result.requestId || null,
      prompt
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({
      error: err?.message || "Error generando el video."
    });
  }
});

app.listen(port, () => {
  console.log(`ReWriteVideo AI funcionando en http://localhost:${port}`);
});
