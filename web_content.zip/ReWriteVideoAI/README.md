# ReWriteVideo AI

Esta versión YA conecta la interfaz con un modelo real de video-to-video mediante fal.ai.

## Requisitos

- Node.js 20+
- Una API key de fal.ai
- Un video compatible con el modelo

## Instalación

1. Copia `.env.example` a `.env`.
2. Pon tu clave en `FAL_KEY`.
3. Ejecuta:

```bash
npm install
npm start
```

4. Abre `http://localhost:3000`.

## Qué hace realmente

El navegador envía el video y la instrucción al servidor. El servidor sube el video al almacenamiento de fal y llama a `fal-ai/kling-video/o1/video-to-video/edit`. El resultado devuelto por el modelo se muestra en la aplicación y queda disponible para descargar.

La API key permanece en el servidor y no se expone al navegador.

## Importante

La generación de video no puede ejecutarse completamente gratis/offline desde un HTML porque requiere un modelo generativo pesado. Esta versión sí hace la llamada real cuando configuras `FAL_KEY`.

El modelo puede tener límites de duración/resolución y coste según la cuenta/proveedor.
