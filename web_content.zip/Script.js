﻿document.addEventListener("DOMContentLoaded", function() {
    try {
        checkTrialAndLicense();
        loadShopName();
        loadAllData();
    } catch(e) {}
});

// لایسنس ۱۵ روزه
function checkTrialAndLicense() {
    try {
        var isActivated = localStorage.getItem('afaghi_activated');
        if (isActivated === 'true') {
            var lockEl = document.getElementById('lockScreen');
            var bannerEl = document.getElementById('trialBanner');
            if(lockEl) lockEl.style.display = 'none';
            if(bannerEl) bannerEl.style.display = 'none';
            return;
        }

        var firstRun = localStorage.getItem('afaghi_first_run');
        if (!firstRun) {
            firstRun = Date.now();
            localStorage.setItem('afaghi_first_run', firstRun);
        }

        var elapsedDays = Math.floor((Date.now() - parseInt(firstRun)) / (1000 * 60 * 60 * 24));
        var daysLeft = 15 - elapsedDays;

        if (daysLeft <= 0) {
            var bannerEl = document.getElementById('trialBanner');
            var lockEl = document.getElementById('lockScreen');
            if(bannerEl) bannerEl.style.display = 'none';
            if(lockEl) lockEl.style.display = 'flex';
            
            var sysCode = localStorage.getItem('afaghi_sys_code');
            if (!sysCode) {
                sysCode = Math.floor(1000 + Math.random() * 9000).toString();
                localStorage.setItem('afaghi_sys_code', sysCode);
            }
            var codeBox = document.getElementById('displaySystemCode');
            if(codeBox) codeBox.innerText = sysCode;
        } else {
            var daysEl = document.getElementById('daysLeftText');
            if(daysEl) daysEl.innerText = daysLeft;
        }
    } catch(e) {}
}

function checkActivation() {
    try {
        var inputVal = document.getElementById('activationInput').value.trim();
        var sysCode = parseInt(localStorage.getItem('afaghi_sys_code'));
        var correctCode = (sysCode + 15) * 7;

        if (parseInt(inputVal) === correctCode) {
            localStorage.setItem('afaghi_activated', 'true');
            document.getElementById('lockScreen').style.display = 'none';
            document.getElementById('trialBanner').style.display = 'none';
            alert('نرم‌افزار با موفقیت فعال شد!');
        } else {
            alert('کد فعال‌سازی اشتباه است.');
        }
    } catch(e) {}
}

// مدیریت پنل تنظیمات و پشتیبان‌گیری
function openSettingsModal() {
    var modal = document.getElementById('settingsModal');
    if(modal) modal.style.display = 'flex';
}

function closeSettingsModal() {
    var modal = document.getElementById('settingsModal');
    if(modal) modal.style.display = 'none';
}

function exportBackup() {
    try {
        var backupData = {
            shopName: localStorage.getItem('afaghi_shop_name'),
            services: localStorage.getItem('autoServices'),
            customers: localStorage.getItem('afaghi_customers'),
            firstRun: localStorage.getItem('afaghi_first_run'),
            activated: localStorage.getItem('afaghi_activated'),
            sysCode: localStorage.getItem('afaghi_sys_code')
        };
        var dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(backupData));
        var downloadAnchor = document.createElement('a');
        downloadAnchor.setAttribute("href", dataStr);
        downloadAnchor.setAttribute("download", "AutoService_Backup_" + new Date().toISOString().slice(0,10) + ".json");
        document.body.appendChild(downloadAnchor);
        downloadAnchor.click();
        downloadAnchor.remove();
        alert('فایل پشتیبان با موفقیت دانلود شد.');
    } catch(e) {
        alert('خطا در گرفتن پشتیبان.');
    }
}

function importBackup(event) {
    var file = event.target.files[0];
    if (!file) return;
    var reader = new FileReader();
    reader.onload = function(e) {
        try {
            var backupData = JSON.parse(e.target.result);
            if(backupData.services) localStorage.setItem('autoServices', backupData.services);
            if(backupData.customers) localStorage.setItem('afaghi_customers', backupData.customers);
            if(backupData.shopName) localStorage.setItem('afaghi_shop_name', backupData.shopName);
            if(backupData.firstRun) localStorage.setItem('afaghi_first_run', backupData.firstRun);
            if(backupData.activated) localStorage.setItem('afaghi_activated', backupData.activated);
            if(backupData.sysCode) localStorage.setItem('afaghi_sys_code', backupData.sysCode);
            
            loadShopName();
            loadAllData();
            checkTrialAndLicense();
            closeSettingsModal();
            alert('اطلاعات با موفقیت بازیابی شد!');
        } catch(err) {
            alert('فایل پشتیبان نامعتبر است.');
        }
    };
    reader.readAsText(file);
}

// سوییچ ایمن تب‌ها
function switchTab(tabId) {
    try {
        var contents = document.querySelectorAll('.tab-content');
        for(var i = 0; i < contents.length; i++) {
            contents[i].classList.remove('active');
            contents[i].style.display = 'none';
        }

        var buttons = document.querySelectorAll('.tab-btn');
        for(var j = 0; j < buttons.length; j++) {
            buttons[j].classList.remove('active');
        }

        var targetTab = document.getElementById(tabId);
        if(targetTab) {
            targetTab.classList.add('active');
            targetTab.style.display = 'block';
        }

        if(tabId === 'registerTab') {
            var btn = document.getElementById('btnReg');
            if(btn) btn.classList.add('active');
        } else if(tabId === 'customersTab') {
            var btn = document.getElementById('btnCust');
            if(btn) btn.classList.add('active');
            renderCustomers();
        } else if(tabId === 'historyTab') {
            var btn = document.getElementById('btnHist');
            if(btn) btn.classList.add('active');
            renderHistory();
        }
    } catch(e) {}
}

function validatePhoneInput() {
    try {
        var phoneInput = document.getElementById('phone');
        var phoneError = document.getElementById('phoneError');
        if(!phoneInput || !phoneError) return true;
        var val = phoneInput.value.trim();
        if(val === "") {
            phoneInput.classList.remove('input-error');
            phoneError.style.display = 'none';
            return true;
        }
        var isValid = /^09\d{9}$/.test(val);

        if (!isValid) {
            phoneInput.classList.add('input-error');
            phoneError.style.display = 'block';
            return false;
        } else {
            phoneInput.classList.remove('input-error');
            phoneError.style.display = 'none';
            return true;
        }
    } catch(e) { return true; }
}

function calculateNextKm() {
    try {
        var currentKmVal = parseInt(document.getElementById('currentKm').value) || 0;
        var radios = document.getElementsByName('kmAdd');
        var addVal = 0;
        for(var i=0; i<radios.length; i++) {
            if(radios[i].checked) {
                addVal = parseInt(radios[i].value);
                break;
            }
        }
        if (addVal > 0 && currentKmVal > 0) {
            document.getElementById('nextServiceKm').value = currentKmVal + addVal;
        }
    } catch(e) {}
}

function resetFormForNewPerson() {
    try {
        document.getElementById('serviceForm').reset();
        document.getElementById('editIndex').value = '-1';
        document.getElementById('formTitle').innerText = 'ثبت کارت سرویس جدید';
        document.getElementById('phone').classList.remove('input-error');
        document.getElementById('phoneError').style.display = 'none';
        document.getElementById('phone').focus();
    } catch(e) {}
}

function loadShopName() {
    try {
        var shopName = localStorage.getItem('afaghi_shop_name') || 'اتوسرویس آفاقی';
        var el = document.getElementById('shopTitleDisplay');
        if (el) el.innerText = shopName;
    } catch(e) {}
}

function changeShopName() {
    try {
        var currentName = localStorage.getItem('afaghi_shop_name') || 'اتوسرویس آفاقی';
        var newName = prompt('نام جدید اتوسرویس خود را وارد کنید:', currentName);
        if (newName && newName.trim() !== '') {
            localStorage.setItem('afaghi_shop_name', newName.trim());
            loadShopName();
            alert('نام اتوسرویس با موفقیت تغییر کرد.');
        }
    } catch(e) {}
}

function autoFillCustomer() {
    try {
        var phoneInput = document.getElementById('phone');
        if(!phoneInput) return;
        var phone = phoneInput.value.trim();
        if (!phone) return;

        var customers = JSON.parse(localStorage.getItem('afaghi_customers') || '[]');
        var foundCust = null;
        for(var i=0; i<customers.length; i++) {
            if(customers[i].phone === phone) {
                foundCust = customers[i];
                break;
            }
        }

        if (foundCust) {
            document.getElementById('customerName').value = foundCust.name;
            if (foundCust.cars && foundCust.cars.length > 0) {
                if (foundCust.cars.length === 1) {
                    var car = foundCust.cars[0];
                    document.getElementById('carModel').value = car.model;
                    document.getElementById('plate').value = car.plate || '';
                } else {
                    showCarSelector(foundCust);
                }
            }
            return;
        }

        var services = JSON.parse(localStorage.getItem('autoServices') || '[]');
        for(var j=services.length-1; j>=0; j--) {
            if(services[j].phone === phone) {
                document.getElementById('customerName').value = services[j].name;
                document.getElementById('carModel').value = services[j].car;
                document.getElementById('plate').value = services[j].plate || '';
                break;
            }
        }
    } catch(e) {}
}

function showCarSelector(cust) {
    try {
        var listDiv = document.getElementById('carSelectList');
        if(!listDiv) return;
        listDiv.innerHTML = '';
        for(var i=0; i<cust.cars.length; i++) {
            var car = cust.cars[i];
            var btn = document.createElement('button');
            btn.type = 'button';
            btn.style.cssText = "padding: 10px; background: #eff6ff; border: 1px solid #3b82f6; border-radius: 6px; font-weight: bold; color: #1e40af; cursor: pointer; font-family: Tahoma; width:100%; margin-bottom:5px;";
            btn.innerHTML = '🚗 مدل: ' + car.model + ' | پلاک: ' + (car.plate || 'بدون پلاک');
            btn.onclick = (function(c, name) {
                return function() {
                    document.getElementById('customerName').value = name;
                    document.getElementById('carModel').value = c.model;
                    document.getElementById('plate').value = c.plate || '';
                    document.getElementById('carSelectModal').style.display = 'none';
                };
            })(car, cust.name);
            listDiv.appendChild(btn);
        }
        document.getElementById('carSelectModal').style.display = 'flex';
    } catch(e) {}
}

function closeCarSelectModal() {
    var modal = document.getElementById('carSelectModal');
    if(modal) modal.style.display = 'none';
}

function onCustomerNameInput() {
    try {
        var nameInput = document.getElementById('customerName');
        var dataList = document.getElementById('customerSuggestions');
        if (!nameInput || !dataList) return;
        var inputVal = nameInput.value.trim().toLowerCase();
        dataList.innerHTML = '';

        if (!inputVal) return;

        var customers = JSON.parse(localStorage.getItem('afaghi_customers') || '[]');
        for(var i=0; i<customers.length; i++) {
            var c = customers[i];
            if (c.name.toLowerCase().indexOf(inputVal) !== -1) {
                if (c.cars && c.cars.length > 0) {
                    for(var k=0; k<c.cars.length; k++) {
                        var car = c.cars[k];
                        var option = document.createElement('option');
                        option.value = c.name + ' (' + car.model + ' - ' + (car.plate || 'بدون پلاک') + ') - ' + c.phone;
                        dataList.appendChild(option);
                    }
                } else {
                    var option = document.createElement('option');
                    option.value = c.name + ' (' + c.phone + ')';
                    dataList.appendChild(option);
                }
            }
        }
    } catch(e) {}
}

function autoFillCustomerByName() {
    try {
        var nameInputEl = document.getElementById('customerName');
        if(!nameInputEl) return;
        var nameInput = nameInputEl.value.trim();
        if (!nameInput) return;

        var customers = JSON.parse(localStorage.getItem('afaghi_customers') || '[]');
        var matchedCust = null;
        var matchedCar = null;

        for(var i=0; i<customers.length; i++) {
            var c = customers[i];
            if (nameInput.indexOf(c.phone) !== -1) {
                matchedCust = c;
                if (c.cars) {
                    for(var k=0; k<c.cars.length; k++) {
                        if (nameInput.indexOf(c.cars[k].model) !== -1) {
                            matchedCar = c.cars[k];
                            break;
                        }
                    }
                }
            } else if (c.name === nameInput || nameInput.indexOf(c.name + ' ') === 0) {
                matchedCust = c;
            }
        }

        if (!matchedCust) {
            for(var i=0; i<customers.length; i++) {
                if (nameInput.toLowerCase().indexOf(customers[i].name.toLowerCase()) !== -1) {
                    matchedCust = customers[i];
                    break;
                }
            }
        }

        if (matchedCust) {
            document.getElementById('customerName').value = matchedCust.name;
            document.getElementById('phone').value = matchedCust.phone;

            if (matchedCust.cars && matchedCust.cars.length > 0) {
                var carToUse = matchedCar || matchedCust.cars[matchedCust.cars.length - 1];
                document.getElementById('carModel').value = carToUse.model;
                document.getElementById('plate').value = carToUse.plate || '';
            }
        }
    } catch(e) {}
}

function prepareServiceForCar(phone, name, carModel, plate) {
    switchTab('registerTab');
    document.getElementById('phone').value = phone;
    document.getElementById('customerName').value = name;
    document.getElementById('carModel').value = carModel;
    document.getElementById('plate').value = plate || '';
    document.getElementById('editIndex').value = -1;
    document.getElementById('formTitle').innerText = 'ثبت کارت سرویس جدید';
    document.getElementById('nextServiceKm').focus();
}

function handleServiceFormSubmit(e) {
    e.preventDefault();
    try {
        var phone = document.getElementById('phone').value.trim();
        if (!/^09\d{9}$/.test(phone)) {
            alert('شماره موبایل نامعتبر است. لطفاً شماره صحیح ۱۱ رقمی وارد کنید.');
            document.getElementById('phone').focus();
            return;
        }

        var name = document.getElementById('customerName').value.trim();
        var car = document.getElementById('carModel').value.trim();
        var plate = document.getElementById('plate').value.trim();
        var editIndex = parseInt(document.getElementById('editIndex').value);

        var customers = JSON.parse(localStorage.getItem('afaghi_customers') || '[]');
        var custIndex = -1;
        for(var i=0; i<customers.length; i++) {
            if(customers[i].phone === phone) {
                custIndex = i;
                break;
            }
        }

        if (custIndex === -1) {
            customers.push({ name: name, phone: phone, cars: [{ model: car, plate: plate }] });
        } else {
            var custCars = customers[custIndex].cars || [];
            var carExists = false;
            for(var k=0; k<custCars.length; k++) {
                if(custCars[k].model === car && custCars[k].plate === plate) {
                    carExists = true;
                    break;
                }
            }
            
            if (!carExists && editIndex === -1) {
                var confirmNewCar = confirm('پلاک یا مدل خودروی "' + car + '" با خودروهای قبلی این مشتری متفاوت است.\nآیا این را به عنوان خودروی جدید این مشتری ثبت کنم؟');
                if (confirmNewCar) {
                    customers[custIndex].cars.push({ model: car, plate: plate });
                }
            }
        }
        localStorage.setItem('afaghi_customers', JSON.stringify(customers));

        var services = JSON.parse(localStorage.getItem('autoServices') || '[]');
        var serviceData = {
            id: editIndex > -1 ? services[editIndex].id : Date.now(),
            name: name,
            phone: phone,
            car: car,
            plate: plate,
            date: document.getElementById('serviceDate').value,
            oil: document.getElementById('oilType').value,
            km: document.getElementById('currentKm').value || '-',
            nextKm: document.getElementById('nextServiceKm').value,
            totalPrice: document.getElementById('totalPrice').value,
            filters: {
                oil: document.getElementById('oilFilter').value,
                air: document.getElementById('airFilter').value,
                cabin: document.getElementById('cabinFilter').value,
                gearbox: document.getElementById('gearboxStatus').value
            },
            checks: {
                fuelFilter: document.getElementById('checkFuelFilter').checked ? document.getElementById('fuelFilterStatus').value : null,
                antifreeze: document.getElementById('checkAntifreeze').checked ? document.getElementById('antifreezeStatus').value : null,
                brakeOil: document.getElementById('checkBrakeOil').checked ? document.getElementById('brakeOilStatus').value : null
            },
            note: document.getElementById('serviceNote').value.trim()
        };

        if (editIndex > -1) {
            services[editIndex] = serviceData;
            document.getElementById('editIndex').value = -1;
            document.getElementById('formTitle').innerText = 'ثبت کارت سرویس جدید';
        } else {
            services.push(serviceData);
        }

        localStorage.setItem('autoServices', JSON.stringify(services));
        document.getElementById('serviceForm').reset();
        
        loadAllData();

        var smsModal = document.getElementById('smsPromptModal');
        if(smsModal) smsModal.style.display = 'flex';
        var sendBtn = document.getElementById('confirmSendSmsBtn');
        if(sendBtn) {
            sendBtn.onclick = function() {
                triggerNativeSms(serviceData);
                closeSmsPromptModal();
            };
        }
    } catch(e) {}
}

function closeSmsPromptModal() {
    var modal = document.getElementById('smsPromptModal');
    if(modal) modal.style.display = 'none';
}

function triggerNativeSms(s) {
    try {
        var shopName = localStorage.getItem('afaghi_shop_name') || 'اتوسرویس آفاقی';
        var oilFilterTxt = (s.filters && s.filters.oil) ? s.filters.oil : '-';
        var airFilterTxt = (s.filters && s.filters.air) ? s.filters.air : '-';

        var message = 'مشتری محترم؛ سرویس دوره ای خودرو ' + s.car + ' شما انجام شد\n' +
'تاریخ: ' + s.date + '\n' +
'روغن: ' + s.oil + '\n' +
'فیلترروغن: ' + oilFilterTxt + '\n' +
'هواکش: ' + airFilterTxt + '\n' +
'کیلومتر بعدی: ' + s.nextKm + '\n' +
shopName;

        var cleanPhone = s.phone.replace(/[^0-9+]/g, '');
        var encodedMsg = encodeURIComponent(message);
        window.location.href = 'sms:' + cleanPhone + '?body=' + encodedMsg;
    } catch(e) {}
}

function openNewCustomerModal() {
    var modal = document.getElementById('newCustomerModal');
    if(modal) modal.style.display = 'flex';
}

function closeNewCustomerModal() {
    var modal = document.getElementById('newCustomerModal');
    if(modal) modal.style.display = 'none';
}

function handleNewCustomerSubmit(e) {
    e.preventDefault();
    try {
        var newCust = {
            name: document.getElementById('newCustName').value.trim(),
            phone: document.getElementById('newCustPhone').value.trim(),
            cars: [{
                model: document.getElementById('newCustCar').value.trim(),
                plate: document.getElementById('newCustPlate').value.trim()
            }]
        };

        var customers = JSON.parse(localStorage.getItem('afaghi_customers') || '[]');
        for(var i=0; i<customers.length; i++) {
            if(customers[i].phone === newCust.phone) {
                alert('این شماره تلفن قبلاً ثبت شده است.');
                return;
            }
        }

        customers.push(newCust);
        localStorage.setItem('afaghi_customers', JSON.stringify(customers));

        document.getElementById('newCustomerForm').reset();
        closeNewCustomerModal();
        renderCustomers();
        alert('مشتری جدید با موفقیت اضافه شد!');
    } catch(e) {}
}

function openNewCarModal(phone, name) {
    try {
        document.getElementById('targetPhone').value = phone;
        document.getElementById('targetCustomerText').innerText = 'ثبت خودروی جدید برای: ' + name + ' (' + phone + ')';
        document.getElementById('newCarModal').style.display = 'flex';
    } catch(e) {}
}

function closeNewCarModal() {
    var modal = document.getElementById('newCarModal');
    if(modal) modal.style.display = 'none';
}

function handleNewCarSubmit(e) {
    e.preventDefault();
    try {
        var phone = document.getElementById('targetPhone').value;
        var newCar = {
            model: document.getElementById('newCarModel').value.trim(),
            plate: document.getElementById('newCarPlate').value.trim()
        };

        var customers = JSON.parse(localStorage.getItem('afaghi_customers') || '[]');
        for(var i=0; i<customers.length; i++) {
            if(customers[i].phone === phone) {
                if (!customers[i].cars) customers[i].cars = [];
                customers[i].cars.push(newCar);
                localStorage.setItem('afaghi_customers', JSON.stringify(customers));
                break;
            }
        }

        document.getElementById('newCarForm').reset();
        closeNewCarModal();
        renderCustomers();
        alert('خودروی جدید با موفقیت اضافه شد!');
    } catch(e) {}
}

function loadAllData() {
    renderCustomers();
    renderHistory();
}

function renderCustomers() {
    try {
        var grid = document.getElementById('customerGrid');
        if (!grid) return;
        grid.innerHTML = '';
        var searchInput = document.getElementById('customerSearchInput');
        var query = searchInput ? searchInput.value.toLowerCase().trim() : '';

        var customers = JSON.parse(localStorage.getItem('afaghi_customers') || '[]');
        var services = JSON.parse(localStorage.getItem('autoServices') || '[]');

        var customersMap = {};

        for(var i=0; i<customers.length; i++) {
            var c = customers[i];
            customersMap[c.phone] = { name: c.name, phone: c.phone, cars: c.cars || [], count: 0, lastDate: 'بدون سرویس' };
        }

        for(var j=0; j<services.length; j++) {
            var s = services[j];
            if (!customersMap[s.phone]) {
                customersMap[s.phone] = { name: s.name, phone: s.phone, cars: [{model: s.car, plate: s.plate}], count: 0, lastDate: s.date };
            } else {
                customersMap[s.phone].lastDate = s.date;
            }
            customersMap[s.phone].count++;
        }

        var custList = [];
        for(var key in customersMap) {
            if(customersMap.hasOwnProperty(key)) {
                custList.push(customersMap[key]);
            }
        }

        if (query) {
            var filtered = [];
            for(var i=0; i<custList.length; i++) {
                var c = custList[i];
                var match = c.name.toLowerCase().indexOf(query) !== -1 || c.phone.toLowerCase().indexOf(query) !== -1;
                if(!match && c.cars) {
                    for(var k=0; k<c.cars.length; k++) {
                        if(c.cars[k].model.toLowerCase().indexOf(query) !== -1 || (c.cars[k].plate && c.cars[k].plate.toLowerCase().indexOf(query) !== -1)) {
                            match = true;
                            break;
                        }
                    }
                }
                if(match) filtered.push(c);
            }
            custList = filtered;
        }

        if (custList.length === 0) {
            grid.innerHTML = '<p style="grid-column: 1/-1; text-align: center; color: #64748b;">مشتری یافت نشد.</p>';
            return;
        }

        for(var i=0; i<custList.length; i++) {
            var c = custList[i];
            var carsHtml = '';
            if (c.cars && c.cars.length > 0) {
                for(var k=0; k<c.cars.length; k++) {
                    var car = c.cars[k];
                    carsHtml += '<div class="car-badge-box">' +
                        '<span class="car-badge">🚗 ' + car.model + ' (' + (car.plate || 'بدون پلاک') + ')</span>' +
                        '<button type="button" class="new-service-car-btn" onclick="prepareServiceForCar(\'' + c.phone + '\', \'' + c.name + '\', \'' + car.model + '\', \'' + (car.plate || '') + '\')">سرویس جدید</button>' +
                    '</div>';
                }
            }

            var card = document.createElement('div');
            card.className = 'customer-card';
            card.innerHTML = '<h3>👤 ' + c.name + '</h3>' +
                '<div class="customer-info">' +
                    '📞 تلفن: <strong>' + c.phone + '</strong><br>' +
                    '📊 تعداد کل سرویس‌ها: ' + c.count + '<br>' +
                    '⏱ آخرین سرویس: ' + c.lastDate + '<br>' +
                    '<div style="margin-top: 8px;"><strong>خودروها:</strong></div>' +
                    carsHtml +
                '</div>' +
                '<button type="button" class="btn-action" style="margin: 8px 0 0 0; width:100%; font-size:11px; padding:5px;" onclick="openNewCarModal(\'' + c.phone + '\', \'' + c.name + '\')">➕ افزودن خودرو جدید</button>' +
                '<button type="button" class="view-history-btn" onclick="openCustomerModal(\'' + c.phone + '\')">مشاهده سوابق و پیامک‌ها</button>';
            grid.appendChild(card);
        }
    } catch(e) {}
}

function renderHistory() {
    try {
        var tbody = document.getElementById('historyTableBody');
        if (!tbody) return;
        tbody.innerHTML = '';

        var services = JSON.parse(localStorage.getItem('autoServices') || '[]');
        for(var i = services.length - 1; i >= 0; i--) {
            var s = services[i];
            var tr = document.createElement('tr');
            tr.innerHTML = '<td>' + s.date + '</td>' +
                '<td><strong>' + s.name + '</strong></td>' +
                '<td>' + s.phone + '</td>' +
                '<td>' + s.car + '</td>' +
                '<td>' + (s.plate || '-') + '</td>' +
                '<td>' + s.oil + '</td>' +
                '<td style="color:var(--primary-color); font-weight:bold;">' + s.nextKm + '</td>' +
                '<td>' + (s.totalPrice || '-') + '</td>' +
                '<td>' +
                    '<button type="button" class="sms-btn" onclick="sendSmsFromHistory(' + i + ')">پیامک</button> ' +
                    '<button type="button" class="edit-btn" onclick="editService(' + i + ')">ویرایش</button> ' +
                    '<button type="button" class="delete-btn" onclick="deleteService(' + i + ')">حذف</button>' +
                '</td>';
            tbody.appendChild(tr);
        }
    } catch(e) {}
}

function searchHistory() {
    try {
        var query = document.getElementById('historySearchInput').value.toLowerCase().trim();
        var tbody = document.getElementById('historyTableBody');
        if (!tbody) return;
        tbody.innerHTML = '';

        var services = JSON.parse(localStorage.getItem('autoServices') || '[]');
        for(var i = services.length - 1; i >= 0; i--) {
            var s = services[i];
            var match = s.name.toLowerCase().indexOf(query) !== -1 ||
                        s.phone.toLowerCase().indexOf(query) !== -1 ||
                        s.car.toLowerCase().indexOf(query) !== -1 ||
                        (s.plate && s.plate.toLowerCase().indexOf(query) !== -1) ||
                        s.date.indexOf(query) !== -1;
            
            if (match) {
                var tr = document.createElement('tr');
                tr.innerHTML = '<td>' + s.date + '</td>' +
                    '<td><strong>' + s.name + '</strong></td>' +
                    '<td>' + s.phone + '</td>' +
                    '<td>' + s.car + '</td>' +
                    '<td>' + (s.plate || '-') + '</td>' +
                    '<td>' + s.oil + '</td>' +
                    '<td style="color:var(--primary-color); font-weight:bold;">' + s.nextKm + '</td>' +
                    '<td>' + (s.totalPrice || '-') + '</td>' +
                    '<td>' +
                        '<button type="button" class="sms-btn" onclick="sendSmsFromHistory(' + i + ')">پیامک</button> ' +
                        '<button type="button" class="edit-btn" onclick="editService(' + i + ')">ویرایش</button> ' +
                        '<button type="button" class="delete-btn" onclick="deleteService(' + i + ')">حذف</button>' +
                    '</td>';
                tbody.appendChild(tr);
            }
        }
    } catch(e) {}
}

function openCustomerModal(phone) {
    try {
        var services = JSON.parse(localStorage.getItem('autoServices') || '[]');
        var custServices = [];
        var indices = [];
        for(var i=0; i<services.length; i++) {
            if(services[i].phone === phone) {
                custServices.push(services[i]);
                indices.push(i);
            }
        }

        if (custServices.length === 0) {
            alert('سرویسی برای این مشتری یافت نشد.');
            return;
        }

        document.getElementById('modalCustomerTitle').innerText = 'سوابق مشتری: ' + custServices[0].name + ' (' + phone + ')';
        var tbody = document.getElementById('modalTableBody');
        tbody.innerHTML = '';

        for(var k = custServices.length - 1; k >= 0; k--) {
            var s = custServices[k];
            var originalIndex = indices[k];
            var tr = document.createElement('tr');
            tr.innerHTML = '<td>' + s.date + '</td>' +
                '<td>' + s.car + '</td>' +
                '<td>' + (s.plate || '-') + '</td>' +
                '<td>' + s.oil + '</td>' +
                '<td style="color:var(--primary-color); font-weight:bold;">' + s.nextKm + '</td>' +
                '<td>' + (s.totalPrice || '-') + '</td>' +
                '<td>' +
                    '<button type="button" class="sms-btn" onclick="sendSmsFromHistory(' + originalIndex + ')">پیامک</button> ' +
                    '<button type="button" class="edit-btn" onclick="closeModal(); editService(' + originalIndex + ')">ویرایش</button> ' +
                    '<button type="button" class="delete-btn" onclick="deleteServiceFromModal(' + originalIndex + ', \'' + phone + '\')">حذف</button>' +
                '</td>';
            tbody.appendChild(tr);
        }

        document.getElementById('customerModal').style.display = 'flex';
    } catch(e) {}
}

function closeModal() {
    var modal = document.getElementById('customerModal');
    if(modal) modal.style.display = 'none';
}

function deleteServiceFromModal(index, phone) {
    if (confirm('آیا از حذف این کارت سرویس اطمینان دارید؟')) {
        try {
            var services = JSON.parse(localStorage.getItem('autoServices') || '[]');
            services.splice(index, 1);
            localStorage.setItem('autoServices', JSON.stringify(services));
            loadAllData();
            openCustomerModal(phone);
        } catch(e) {}
    }
}

function editService(index) {
    try {
        var services = JSON.parse(localStorage.getItem('autoServices') || '[]');
        var s = services[index];
        if (!s) return;

        document.getElementById('phone').value = s.phone;
        document.getElementById('customerName').value = s.name;
        document.getElementById('carModel').value = s.car;
        document.getElementById('plate').value = s.plate || '';
        document.getElementById('serviceDate').value = s.date;
        document.getElementById('oilType').value = s.oil;
        document.getElementById('currentKm').value = s.km !== '-' ? s.km : '';
        document.getElementById('nextServiceKm').value = s.nextKm;
        document.getElementById('totalPrice').value = s.totalPrice || '';
        document.getElementById('serviceNote').value = s.note || '';

        if (s.filters) {
            document.getElementById('oilFilter').value = s.filters.oil || '-';
            document.getElementById('airFilter').value = s.filters.air || '-';
            document.getElementById('cabinFilter').value = s.filters.cabin || '-';
            document.getElementById('gearboxStatus').value = s.filters.gearbox || '-';
        }

        if (s.checks) {
            if (s.checks.fuelFilter) {
                document.getElementById('checkFuelFilter').checked = true;
                document.getElementById('fuelFilterStatus').value = s.checks.fuelFilter;
            } else {
                document.getElementById('checkFuelFilter').checked = false;
            }

            if (s.checks.antifreeze) {
                document.getElementById('checkAntifreeze').checked = true;
                document.getElementById('antifreezeStatus').value = s.checks.antifreeze;
            } else {
                document.getElementById('checkAntifreeze').checked = false;
            }

            if (s.checks.brakeOil) {
                document.getElementById('checkBrakeOil').checked = true;
                document.getElementById('brakeOilStatus').value = s.checks.brakeOil;
            } else {
                document.getElementById('checkBrakeOil').checked = false;
            }
        }

        document.getElementById('editIndex').value = index;
        document.getElementById('formTitle').innerText = 'ویرایش کارت سرویس';
        switchTab('registerTab');
        window.scrollTo({ top: 0, behavior: 'smooth' });
    } catch(e) {}
}

function deleteService(index) {
    if (confirm('آیا از حذف این کارت سرویس اطمینان دارید؟')) {
        try {
            var services = JSON.parse(localStorage.getItem('autoServices') || '[]');
            services.splice(index, 1);
            localStorage.setItem('autoServices', JSON.stringify(services));
            loadAllData();
            alert('کارت سرویس حذف شد.');
        } catch(e) {}
    }
}

function sendSmsFromHistory(index) {
    try {
        var services = JSON.parse(localStorage.getItem('autoServices') || '[]');
        var s = services[index];
        if (s) {
            triggerNativeSms(s);
        }
    } catch(e) {}
}
