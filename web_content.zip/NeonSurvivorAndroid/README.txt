NEON SURVIVOR Android project

Bug fix:
- The game has no attack/kill mechanic, so the previous ENEMIES stat was showing the kill counter and stayed at 0.
- The end screen now says ENEMIES SPAWNED and counts how many enemies appeared during the run.

Build:
1. Open this folder in Android Studio.
2. Allow Gradle sync.
3. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
4. For Play Store, build a signed Android App Bundle (AAB) from Build > Generate Signed Bundle / APK.

This is a project source package, not a prebuilt APK. It requires Android Studio/Android SDK to build.
