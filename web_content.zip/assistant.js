/* Learnova Creator Studio — AI Creator Assistant */
(function(){
  const CHAT_KEY="learnova_assistant_chat_v1";
  const projectSelect=document.getElementById("assistantProject");
  const log=document.getElementById("chatLog");
  const form=document.getElementById("assistantForm");
  const input=document.getElementById("assistantInput");
  const send=document.getElementById("sendAssistant");
  const saveScript=document.getElementById("saveLastScript");
  let chat=[];
  let lastReply="";
  let shown=0,revealRaf=0;
  try { const saved=JSON.parse(localStorage.getItem(CHAT_KEY)||"[]"); if(Array.isArray(saved)) chat=saved.slice(-40); } catch(e) {}
  shown=chat.length;

  function currentProject(){return data.projects.find(p=>p.id===projectSelect.value)||null;}
  function contextText(){
    const p=currentProject();
    if(!p) return "No project selected. Help with Learnova, a faceless educational YouTube channel for a global audience.";
    return `Selected project context:\nTitle: ${p.title||p.name||"Untitled"}\nFormat: ${p.format||"Not set"}\nTarget length: ${p.length||"Not set"}\nContent pillar: ${p.pillar||"Not set"}\nGoal: ${p.goal||"Not set"}\nAudience: ${p.audience||"Not set"}\nResearch notes: ${p.research||"None"}\nHook: ${p.hook||"None"}\nExisting script: ${(p.script||"None").slice(0,6500)}\nScene beats: ${(p.scenes||[]).map((s,i)=>`${i+1}. ${s.beat||"Scene"}: ${s.narration||""}`).join("\n")||"None"}\nVisual style: ${p.visualStyle||"Not set"}`;
  }
  function saveChat(){try{localStorage.setItem(CHAT_KEY,JSON.stringify(chat.slice(-40)));}catch(e){toast("Chat history could not be saved. Export it if needed.");}}
  function render(reveal){
    cancelAnimationFrame(revealRaf);
    log.innerHTML="";
    const empty=!chat.length;
    const all=empty?[{role:"assistant",text:"Hi! Tell me what video you're making, or choose a starter prompt below. I can help you plan and improve your educational videos."}]:chat;
    let revealEl=null,revealText="";
    all.forEach((m,i)=>{
      const el=document.createElement("div");el.className="chat-message "+(m.role==="user"?"user-message":"assistant-message");
      if(!empty&&i>=shown)el.classList.add("fx-new");
      const who=document.createElement("strong");who.textContent=m.role==="user"?"You":"Learnova AI";
      const body=document.createElement("p");body.textContent=m.text;el.append(who,body);
      if(m.role!=="user"&&!empty){
        const cp=document.createElement("button");cp.type="button";cp.className="msg-copy";cp.textContent="Copy";cp.setAttribute("aria-label","Copy this reply");
        cp.onclick=()=>{copyText(m.text);cp.textContent="Copied ✓";setTimeout(()=>cp.textContent="Copy",1400);};el.appendChild(cp);
      }
      if(reveal&&!empty&&i===all.length-1&&m.role!=="user"){revealEl=body;revealText=m.text;}
      log.appendChild(el);
    });
    shown=chat.length;
    log.scrollTop=log.scrollHeight;
    if(revealEl)typewriter(revealEl,revealText);
  }
  function typewriter(el,text){
    if(matchMedia("(prefers-reduced-motion: reduce)").matches)return;
    const tokens=text.match(/\S+\s*/g)||[text];
    const per=Math.max(1,Math.ceil(tokens.length/110));   // whole reply reveals in ~2 seconds
    let i=0,last=0;el.textContent="";el.classList.add("fx-caret");
    function step(t){
      if(t-last>=22){last=t;i=Math.min(tokens.length,i+per);el.textContent=tokens.slice(0,i).join("");
        const nearBottom=log.scrollHeight-log.scrollTop-log.clientHeight<140;if(nearBottom)log.scrollTop=log.scrollHeight;}
      if(i<tokens.length)revealRaf=requestAnimationFrame(step);else{el.textContent=text;el.classList.remove("fx-caret");}
    }
    revealRaf=requestAnimationFrame(step);
  }
  function showTyping(on){
    const old=log.querySelector(".typing-wrap");if(old)old.remove();
    if(!on)return;
    const el=document.createElement("div");el.className="chat-message assistant-message typing-wrap fx-new";
    el.innerHTML='<div class="typing" aria-label="Learnova AI is thinking"><i></i><i></i><i></i></div>';
    log.appendChild(el);log.scrollTop=log.scrollHeight;
  }
  function fillProjects(){const old=projectSelect.value;projectSelect.innerHTML='<option value="">General Learnova help (no project)</option>'+data.projects.map(p=>`<option value="${esc(p.id)}">${esc(p.title||p.name||"Untitled video")}</option>`).join("");if(data.projects.some(p=>p.id===old))projectSelect.value=old;}
  function setBusy(b){send.disabled=b;input.disabled=b;send.textContent=b?"Thinking…":"Send ↗";showTyping(b);}
  async function ask(text){
    text=String(text||"").trim();if(!text||send.disabled)return;
    chat.push({role:"user",text});render();saveChat();input.value="";setBusy(true);saveScript.disabled=true;
    try{
      const prompt=`You are Learnova AI Creator Assistant, helping plan faceless educational YouTube videos for a worldwide audience. Be practical, clear and encouraging. Ask one concise clarifying question if essential details are missing. Do not invent statistics, studies, quotations, or sources; mark uncertain factual claims [VERIFY]. Prefer original ideas and honest, non-misleading titles. Keep advice appropriate for a teen creator.\n\n${contextText()}\n\nUser message:\n${text}\n\nGive a useful answer with clear headings or numbered steps where helpful. If asked for a script, make it natural to narrate aloud.`;
      const reply=await ai(prompt,2200);
      if(reply){lastReply=reply;chat.push({role:"assistant",text:reply});saveChat();render(true);saveScript.disabled=!currentProject();}
      else {chat.push({role:"assistant",text:"I couldn't get a reply. Open Backup → AI assistant, save a valid provider key and model, then try again with internet access."});saveChat();render();}
    }catch(e){chat.push({role:"assistant",text:"The AI request failed: "+(e&&e.message?e.message:"unknown error")+". Check your internet connection, API key, model name, and provider limits in Backup → AI assistant."});saveChat();render();}
    finally{setBusy(false);input.focus();}
  }
  projectSelect.addEventListener("change",()=>{saveScript.disabled=!lastReply||!currentProject();});
  form.addEventListener("submit",e=>{e.preventDefault();ask(input.value);});
  document.querySelectorAll("[data-prompt]").forEach(b=>b.addEventListener("click",()=>ask(b.dataset.prompt)));
  document.getElementById("clearChat").addEventListener("click",()=>{if(confirm("Clear this assistant conversation from this browser?")){chat=[];lastReply="";shown=0;saveChat();render();saveScript.disabled=true;}});
  saveScript.addEventListener("click",()=>{
    const p=currentProject();if(!p||!lastReply){toast("Choose a project and generate an AI reply first.");return;}
    if(!confirm("Replace the selected project's current script with the latest AI reply? You can cancel if you want to copy it manually instead."))return;
    p.script=lastReply;p.updated=new Date().toISOString();save();document.getElementById("saveScriptState").textContent="Saved to “"+(p.title||p.name)+"”. Open its Script page to review and edit.";toast("AI reply saved to project script.");
  });
  document.getElementById("exportChat").addEventListener("click",()=>{
    if(!chat.length){toast("There is no conversation to export yet.");return;}
    const body=chat.map(m=>(m.role==="user"?"YOU":"LEARNOVA AI")+"\n"+m.text).join("\n\n--------------------\n\n");
    const blob=new Blob(["Learnova Creator Studio — AI Assistant conversation\n\n"+body],{type:"text/plain;charset=utf-8"});const url=URL.createObjectURL(blob);const a=document.createElement("a");a.href=url;a.download="learnova-ai-conversation.txt";document.body.appendChild(a);a.click();a.remove();URL.revokeObjectURL(url);
  });
  fillProjects();render();
})();
