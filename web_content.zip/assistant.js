/* JOSTECH — TUTEUR IA EXACT (MOTS ENTIERS) */
["ai-data.js", "offline-badges.js"].forEach(f => {
  const s = document.createElement("script");
  s.src = f;
  if (f === "offline-badges.js") s.onload = () => { if (typeof updateDashboardStats === "function") updateDashboardStats(); };
  document.head.appendChild(s);
});
let aiInitialized = false;
const AI_DAILY_LIMIT = 15;

function aiEscape(s) { return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); }
function normAi(s) { return String(s || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase(); }

function getAiQuotaState() {
  const today = new Date().toISOString().slice(0, 10);
  try { const raw = JSON.parse(localStorage.getItem("jostech_ai_quota") || "{}"); if (raw.date === today) return raw; } catch (e) {}
  return { date: today, count: 0 };
}
function consumeAiQuota() {
  const q = getAiQuotaState(); if (q.count >= AI_DAILY_LIMIT) return false;
  q.count++; try { localStorage.setItem("jostech_ai_quota", JSON.stringify(q)); } catch (e) {}
  updateAiQuotaBadge(); return true;
}
function updateAiQuotaBadge() {
  const b = document.getElementById("ai-quota-badge"); if (!b) return;
  const q = getAiQuotaState(); b.textContent = `Quota : ${AI_DAILY_LIMIT - q.count}/${AI_DAILY_LIMIT} aujourd'hui`;
}

function initAiView() {
  const host = document.getElementById("view-ai"); if (!host) return;
  if (!aiInitialized) {
    aiInitialized = true;
    host.innerHTML = `
      <div class="section-header"><h2 class="metallic-text">Assistant Pédagogique</h2><span id="ai-quota-badge" class="pill-badge pilot">Quota</span></div>
      <p class="section-sub">Tuteur spécialisé en sciences informatiques (actif même hors connexion).</p>
      <div class="ai-chips">
        <button class="copy-btn" onclick="askAiQuick('Explique Von Neumann')">Von Neumann</button>
        <button class="copy-btn" onclick="askAiQuick('Binaire et hexadecimal')">Binaire/Hexa</button>
        <button class="copy-btn" onclick="askAiQuick('Difference padding et margin')">Padding/Margin</button>
        <button class="copy-btn" onclick="askAiQuick('Que me recommandes-tu ?')">Recommandation</button>
      </div>
      <div id="ai-chat-box" class="ai-chat-box"><div class="ai-msg bot"><strong>Tuteur JOSTECH :</strong> Bonjour ! Posez-moi une question sur vos cours (ordinateur, binaire, Python, C, POO, HTML/CSS, JS, API REST, SQL, réseaux, cybersécurité...).</div></div>
      <form class="ai-input-row" onsubmit="handleAiSubmit(event)">
        <input id="ai-input" type="text" class="field-input" style="margin-bottom:0;" placeholder="Posez votre question informatique..." required />
        <button type="submit" class="btn-primary">Envoyer</button>
      </form>`;
  }
  updateAiQuotaBadge();
}

function askAiQuick(t) { const i = document.getElementById("ai-input"); if (i) { i.value = t; handleAiSubmit({ preventDefault: () => {} }); } }
function appendAiMsg(who, html) {
  const box = document.getElementById("ai-chat-box"); if (!box) return;
  const div = document.createElement("div"); div.className = who === "user" ? "ai-msg user" : "ai-msg bot";
  div.innerHTML = html; box.appendChild(div); box.scrollTop = box.scrollHeight;
}
function handleAiSubmit(e) {
  e.preventDefault();
  const inp = document.getElementById("ai-input"); if (!inp) return;
  const q = inp.value.trim(); if (!q) return; inp.value = "";
  appendAiMsg("user", aiEscape(q));
  if (!consumeAiQuota()) return appendAiMsg("bot", "<strong>Tuteur JOSTECH :</strong> Quota journalier atteint (" + AI_DAILY_LIMIT + "/jour).");
  appendAiMsg("bot", "<strong>Tuteur JOSTECH :</strong> " + generateAiReply(q));
}

function generateAiReply(raw) {
  const nq = normAi(raw), words = nq.match(/[a-z0-9]+/g) || [];
  if (words.some(w => ["bonjour", "salut", "bonsoir", "hello", "coucou"].includes(w)) && words.length <= 3) {
    return "Bonjour ! Sur quelle notion informatique souhaitez-vous de l'aide aujourd'hui ?";
  }
  if (words.some(w => ["merci", "bravo", "super"].includes(w)) && words.length <= 4) {
    return "Avec plaisir ! Bon apprentissage sur JOSTECH.";
  }
  if (nq.includes("recommand") || nq.includes("commencer") || nq.includes("quoi lire")) {
    const done = typeof getCompletedLessons === "function" ? getCompletedLessons() : [];
    const all = typeof getAllLessonsFlat === "function" ? getAllLessonsFlat() : [];
    const next = all.find(x => !done.includes(x.lesson.id));
    return next
      ? `Progression : <strong>${done.length}/${all.length}</strong> leçons. Prochaine étape conseillée : <strong>${aiEscape(next.disc.title)} (Niv. ${next.levelNum}) → ${aiEscape(next.lesson.title)}</strong>.`
      : "Toutes les leçons pilotes sont terminées ! Passez les Examens /20 ou pratiquez dans le Labo.";
  }

  let best = null, bestScore = 0;
  if (typeof AI_KNOWLEDGE !== "undefined") {
    AI_KNOWLEDGE.forEach(item => {
      let sc = 0;
      item.keys.forEach(k => {
        if (k.includes(" ") ? nq.includes(k) : words.includes(k)) sc += (k.includes(" ") ? 2 : 1);
      });
      if (sc > bestScore) { bestScore = sc; best = item; }
    });
  }
  if (best && bestScore > 0) return `<em>[${aiEscape(best.title)}]</em><br>${aiEscape(best.ans)}`;

  if (typeof DISCIPLINES !== "undefined") {
    const matchDisc = DISCIPLINES.find(d => words.some(w => w.length >= 4 && (normAi(d.title).includes(w) || d.topics.some(t => normAi(t).includes(w)))));
    if (matchDisc) return `Cette notion correspond à la discipline <strong>${matchDisc.num}. ${aiEscape(matchDisc.title)}</strong> : ${aiEscape(matchDisc.shortDesc)}`;
  }
  return "Je n'ai pas encore d'explication détaillée hors connexion pour cette question précise. Essayez un mot-clé du cours (ex : Von Neumann, binaire, Boole, cache, pointeur, Big-O, HTML, CSS, DOM, REST, SQL, cybersécurité).";
}