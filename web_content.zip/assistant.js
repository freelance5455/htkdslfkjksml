/* Rift Mate - المساعد المحلي + التعرف على لقطة الدرافت + وضع أونلاين اختياري + تحليل كاونتر أعمق.
   يعمل بالكامل أوفلاين على بيانات التطبيق. الأونلاين لا يعمل إلا عند ضغط زر 🌐 وبمفتاح يدخله المستخدم بنفسه. */
(function(){
'use strict';
if(window.__MR_ASSIST)return;window.__MR_ASSIST=1;
const DBX=window.WRC_DB||{},AR=window.WRC4_AR||{},AB=window.WRC4_AB||{},SP=window.WRC4_SPELLS||[];
const TM=Object.assign({},DBX.translations||{},window.WRC4_TR||{});
const A=()=>typeof lang!=='undefined'&&lang==='ar';
const T=(a,e)=>A()?a:e;
const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
const LANES=['Baron','Jungle','Mid','Dragon','Support'];
const LANE_AR={Baron:'البارون',Jungle:'الجانجل',Mid:'الميد',Dragon:'الدراجون',Support:'السابورت'};
const lname=l=>A()?(LANE_AR[l]||l):l;
const NOREC='لا تتوفر بيانات موثقة حاليًا';
/* ---------- تطبيع النص ---------- */
function norm(s){
  s=String(s||'').toLowerCase().replace(/[\u064B-\u065F\u0670\u0640]/g,'')
   .replace(/[أإآٱ]/g,'ا').replace(/ى/g,'ي').replace(/ة/g,'ه').replace(/ؤ/g,'و').replace(/ئ/g,'ي')
   .replace(/[٠-٩]/g,d=>'٠١٢٣٤٥٦٧٨٩'.indexOf(d)).replace(/['’`]/g,'')
   .replace(/[^a-z0-9\u0600-\u06FF ]+/g,' ').replace(/\s+/g,' ').trim();
  return s;
}
const nameAr_=()=>(typeof nameAr!=='undefined'?nameAr:{})||{};
const EXTRA={'Ahri':['اهري','اري','أهري'],'Zed':['زد','زيد','زيدد'],'Lux':['لاكس','لكس'],'Jinx':['جينكس','جنكس'],'Kai\'Sa':['كايسا','كاي سا'],'Ezreal':['ايزريال','ازريال','إيزريال'],'Lee Sin':['لي سين','لى سين','ليسين'],'Master Yi':['ماستر يي','ماستر يى','ماستري'],'Vi':['فاي'],'Ekko':['ايكو','إيكو'],'Thresh':['تريش','ثريش'],'Garen':['جارين','غارين'],'Yone':['يون','يوني'],'Jhin':['جين','جهين'],'Viego':['فييجو','فيجو'],'Kha\'Zix':['خازيكس','كازيكس'],'Cho\'Gath':['شوجات','تشوجات'],'Vel\'Koz':['فيل كوز','فيلكوز'],'Twisted Fate':['تويستد فيت','تي اف','tf'],'Miss Fortune':['ميس فورتشن','mf'],'Dr. Mundo':['موندو','دكتور موندو'],'Tahm Kench':['تام كينش'],'Xin Zhao':['شين جاو','زين جاو'],'Wukong':['ووكونج','وكونج'],'Nunu & Willump':['نونو','نونو وويلامب'],'Aurelion Sol':['اوريليون سول'],'Rek\'Sai':['ريكساي'],'Kog\'Maw':['كوج ماو','كوجماو'],'LeBlanc':['ليبلان'],'Graves':['جريفز','غريفز'],'Draven':['دريفن','دراين']};
let CH=[],ALIAS={},ITEMALIAS={};
function buildIndex(){
  CH=(typeof CHAMPS!=='undefined'?CHAMPS:[]);ALIAS={};
  CH.forEach(c=>{
    const al=new Set([c.name,c.slug&&c.slug.replace(/-/g,' '),nameAr_()[c.name],c.name.replace(/ /g,'')].concat(EXTRA[c.name]||[]));
    al.forEach(a=>{if(!a)return;const n=norm(a);if(n&&!ALIAS[n])ALIAS[n]=c;});
  });
  ['ياسو','يازو','ياسوو'].forEach(x=>{});
  (DBX.items||[]).forEach(it=>{[it.name,it.nameAr].forEach(a=>{const n=norm(a);if(n&&n.length>2&&!ITEMALIAS[n])ITEMALIAS[n]=it;});});
}
const STOP=new Set(['vi','mel','sett','nami','lux','zoe','jax','ivern','gnar','ryze','zed','rell','ekko','nilah','bard','yone','yasuo','janna','annie','aphelios','kai sa','akali']);
function lev1(a,b){if(Math.abs(a.length-b.length)>1)return false;let i=0,j=0,e=0;while(i<a.length&&j<b.length){if(a[i]===b[j]){i++;j++;continue;}if(++e>1)return false;if(a.length>b.length)i++;else if(a.length<b.length)j++;else{i++;j++;}}return e+(a.length-i)+(b.length-j)<=1;}
function fuzzy(p){if(p.length<4)return null;let hit=null;for(const k in ALIAS){if(k.length>=4&&lev1(p,k)){if(hit&&hit.id!==ALIAS[k].id)return null;hit=ALIAS[k];}}return hit;}
function findChamps(q){
  const t=norm(q).split(' '),out=[],used=new Array(t.length).fill(false);
  for(let n=3;n>=1;n--)for(let i=0;i+n<=t.length;i++){
    if(used.slice(i,i+n).some(Boolean))continue;
    let p=t.slice(i,i+n).join(' '),c=ALIAS[p];
    if(!c&&/^[بلوف]/.test(p)&&p.length>3)c=ALIAS[p.slice(1)];
    if(!c&&p.startsWith('ال')&&p.length>4)c=ALIAS[p.slice(2)];
    if(!c&&n===1&&p.length>=4){c=fuzzy(p)||(p.length>5&&/^[بلوف]/.test(p)?fuzzy(p.slice(1)):null);}
    if(c&&p.length<3&&!/^[a-z]+$/.test(p)&&p!=='زد')c=null;
    if(c){for(let k=i;k<i+n;k++)used[k]=true;if(!out.some(o=>o.c.id===c.id))out.push({c,pos:i});}
  }
  return out.sort((a,b)=>a.pos-b.pos).map(o=>o.c);
}
function findItem(q){const n=norm(q);let best=null;for(const k in ITEMALIAS){if(k.length>3&&n.includes(k)&&(!best||k.length>best.k.length))best={k,it:ITEMALIAS[k]};}return best&&best.it;}
function findLane(q){
  const n=norm(q);
  if(/\b(baron|top)\b|توب|بارون|علوي/.test(n))return 'Baron';
  if(/\b(jungle|jg|jungler)\b|جانجل|جنجل|غابه/.test(n))return 'Jungle';
  if(/\bmid\b|ميد|وسط/.test(n))return 'Mid';
  if(/\b(dragon|adc|bot)\b|ادك|ايه دي سي|دراجون|ديراجون|بوت/.test(n))return 'Dragon';
  if(/\b(support|sup)\b|سابورت|سبورت|ساب |دعم/.test(n))return 'Support';
  return null;
}
/* ---------- بيانات ---------- */
const G=c=>(DBX.guides||{})[c.name]||{};
const dn=c=>A()?((nameAr_()[c.name]||c.name)+(nameAr_()[c.name]?' ('+c.name+')':'')):c.name;
const sn=c=>A()?(nameAr_()[c.name]||c.name):c.name;
const tierOrder=t=>({'S+':6,'S':5,'A':4,'B':3,'C':2,'D':1})[t]||0;
const ct=(c,l)=>(c.laneTiers&&c.laneTiers[l])||c.tier;
function tr(en){if(!en)return '';return A()?(TM[en]||en):en;}
function itemN(n){return A()?(((AR.ITEM_AR||{})[n])||n):n;}
function runeN(n){return A()?(((AR.RUNE_AR||{})[n])||n):n;}
function bootN(n){return A()?(((AR.BOOTS_AR||{})[n])||n):n;}
function buildN(n){if(!A())return n;const p=String(n).split(' — ');return ((AR.BUILD_NAME_AR||{})[p[0]]||p[0])+(p[1]?' — '+(((AR.SUB_AR||{})[p[1]])||p[1]):'');}
const VAR={Hard:'كاونتر قوي',Unfavorable:'مواجهة صعبة',Skill:'متوازنة (حسب المهارة)',Favorable:'مواجهة مريحة'};
const VEN={Hard:'hard counter',Unfavorable:'unfavorable',Skill:'even / skill',Favorable:'favorable'};
const vl=v=>A()?(VAR[v]||v):(VEN[v]||v);
function counterList(c,lane){
  try{const by=window.WRC4.laneCM(c),L=(lane&&by[lane])?lane:Object.keys(by)[0];return{lane:L,counters:(by[L]||{}).counters||[],strong:(by[L]||{}).strong||[]};}catch(e){return{lane:lane,counters:[],strong:[]};}
}
function records(a,b){
  const M=DBX.matchups||[];
  return M.filter(m=>(m.champion===a.name&&m.opponent===b.name)||(m.champion===b.name&&m.opponent===a.name));
}
function loadDetail(c){return new Promise(res=>{try{window.WRC4.load(c.slug,(d)=>res(d||null));}catch(e){res(null);}});}
function statLine(c){const s=c.stats;if(!s||s.winRate==null)return T(NOREC,'No documented stats');
  return T('نسبة الفوز '+s.winRate+'% · الاختيار '+s.pickRate+'% · الحظر '+s.banRate+'%','Win '+s.winRate+'% · Pick '+s.pickRate+'% · Ban '+s.banRate+'%');}
const li=a=>'<ul>'+a.map(x=>'<li>'+x+'</li>').join('')+'</ul>';
const chip=(label,q)=>'<button class="as-chip" data-q="'+esc(q)+'">'+esc(label)+'</button>';
function chipsFor(c,lane){return '<div class="as-chips">'+[chip(T('كاونترات ','Counters ')+sn(c),T('كاونتر ','counters ')+c.name),chip(T('بيلد ','Build ')+sn(c),T('بيلد ','build ')+c.name),chip(T('إحصائيات','Stats'),T('إحصائيات ','stats ')+c.name),chip(T('انسجام','Synergy'),T('انسجام ','synergy ')+c.name),chip(T('نقاط ضعفه','Weaknesses'),T('نقاط ضعف ','weaknesses of ')+c.name)].join('')+'</div>';}
/* ---------- ردود ---------- */
const ctx={champ:null,lane:null};
function ansSummary(c){
  const g=G(c),r=c.ratings||{},roles=(c.roles||[c.lane]).map(lname).join(' / ');
  let o='<b>'+esc(dn(c))+'</b> · '+esc(roles)+' · Tier '+esc(c.tier)+'<br>'+esc(statLine(c));
  if(c.damage)o+='<br>'+T('نوع الضرر: ','Damage: ')+esc(c.damage)+(c.damageSource==='estimate'?T(' (تقدير)',' (estimate)'):'');
  if(c.difficulty!=null)o+='<br>'+T('الصعوبة: ','Difficulty: ')+esc(c.difficulty)+T(' (تقدير)',' (estimate)');
  if(g.powerCurve)o+='<br>'+T('منحنى القوة (تقدير): بداية '+g.powerCurve.early+' · وسط '+g.powerCurve.mid+' · متأخر '+g.powerCurve.late,'Power curve (est.): early '+g.powerCurve.early+' · mid '+g.powerCurve.mid+' · late '+g.powerCurve.late);
  return o+chipsFor(c);
}
function ansCounters(c,lane){
  const cl=counterList(c,lane);
  if(!cl.counters.length)return esc(T('مفيش كاونترات موثقة لـ '+sn(c)+' في '+lname(cl.lane||lane)+'. '+NOREC+'.','No documented counters for '+c.name+'.'));
  let o='<b>'+esc(T('اللي بيكسروا '+sn(c)+' في '+lname(cl.lane),'Counters to '+c.name+' ('+cl.lane+')'))+':</b>';
  o+=li(cl.counters.slice(0,8).map(x=>esc(sn(x.c))+' <small>('+esc(x.s>=3?T('كاونتر قوي','hard'):T('صعب عليه','tough'))+' · Tier '+esc(ct(x.c,cl.lane))+')</small>'));
  if(cl.strong.length)o+='<b>'+esc(T('وهو قوي ضد: ','He is strong against: '))+'</b>'+cl.strong.slice(0,6).map(x=>esc(sn(x.c))).join('، ');
  ctx.champ=c;ctx.lane=cl.lane;
  return o+chipsFor(c);
}
function ansStrong(c,lane){const cl=counterList(c,lane);if(!cl.strong.length)return esc(T(NOREC,'No documented data'));ctx.champ=c;return '<b>'+esc(T(sn(c)+' بيكسر:','Champions '+c.name+' beats:'))+'</b>'+li(cl.strong.slice(0,10).map(x=>esc(sn(x.c))))+chipsFor(c);}
function ansBuild(c,lane){
  const g=G(c);ctx.champ=c;
  let bs=(g.builds||[]);if(lane)bs=bs.filter(b=>!b.lane||b.lane===lane);if(!bs.length)bs=g.builds||[];
  if(!bs.length)return esc(T('مفيش بيلد موثق لـ '+sn(c)+'. '+NOREC+'.','No documented build.'));
  let o='<b>'+esc(T('بيلدات '+sn(c),'Builds for '+c.name))+':</b>';
  o+=li(bs.slice(0,4).map(b=>'<b>'+esc(buildN(b.name))+'</b>'+(b.lane?' <small>('+esc(lname(b.lane))+')</small>':'')+': '+b.items.map(i=>esc(itemN(i))).join(' ← ')));
  if(g.runes&&g.runes.length)o+=esc(T('الرونز: ','Runes: '))+g.runes.map(r=>esc(runeN(r))).join('، ')+'<br>';
  if(g.boots&&g.boots.length)o+=esc(T('الحذاء: ','Boots: '))+g.boots.map(r=>esc(bootN(r))).join('، ');
  return o+chipsFor(c);
}
function ansRunes(c){const g=G(c);ctx.champ=c;if(!g.runes||!g.runes.length)return esc(T(NOREC,'No documented data'));return '<b>'+esc(T('رونز '+sn(c),'Runes '+c.name))+':</b> '+g.runes.map(r=>esc(runeN(r))).join('، ')+(g.boots&&g.boots.length?'<br>'+esc(T('الحذاء: ','Boots: '))+g.boots.map(r=>esc(bootN(r))).join('، '):'')+chipsFor(c);}
function ansStats(c){ctx.champ=c;let o='<b>'+esc(dn(c))+'</b><br>'+esc(statLine(c));if(c.stats&&c.stats.scope)o+='<br><small>'+esc(c.stats.scope)+'</small>';return o+chipsFor(c);}
function ansSynergy(c){
  ctx.champ=c;const S=(DBX.synergies||[]).filter(s=>s.champion===c.name||s.partner===c.name);
  if(!S.length)return esc(T('مفيش انسجام موثق لـ '+sn(c)+'. '+NOREC+'.','No documented synergies.'));
  const rank={Ideal:3,Strong:2,Related:1},seen={},arr=[];
  S.sort((a,b)=>(rank[b.tier]||0)-(rank[a.tier]||0)).forEach(s=>{const p=s.champion===c.name?s.partner:s.champion;if(seen[p])return;seen[p]=1;arr.push({p,t:s.tier});});
  const nm=n=>{const ch=CH.find(x=>x.name===n);return ch?sn(ch):n;};
  return '<b>'+esc(T('بيتناغم مع '+sn(c),'Best partners of '+c.name))+':</b>'+li(arr.slice(0,8).map(x=>esc(nm(x.p))+' <small>('+esc(x.t==='Ideal'?T('مثالي','ideal'):x.t==='Strong'?T('قوي','strong'):T('مرتبط','related'))+')</small>'))+chipsFor(c);
}
function ansAbilities(c,key){
  ctx.champ=c;const a=AB[c.slug];if(!a)return esc(T('وصف القدرات غير متاح. '+NOREC,'Ability text unavailable.'));
  const names=['P','Q','W','E','R'];let idx=key?names.indexOf(key):-1;
  const one=(x,i)=>'<b>'+names[i]+' · '+esc(A()&&x[2]?x[2]:x[0])+'</b>: '+esc(((A()&&x[3])?x[3]:x[1])||'').slice(0,260);
  if(idx>=0&&a[idx])return one(a[idx],idx)+chipsFor(c);
  return '<b>'+esc(T('قدرات '+sn(c),'Abilities of '+c.name))+':</b>'+li(a.map((x,i)=>one(x,i)))+chipsFor(c);
}
async function ansWeak(c,lane){
  ctx.champ=c;const d=await loadDetail(c);let o='';
  const cl=counterList(c,lane);
  const v=d&&d.variants&&(d.variants.find(x=>x.lane===(lane||cl.lane))||d.variants[0]);
  if(v&&v.weak&&v.weak.length)o+='<b>'+esc(T(sn(c)+' بيضعف لما:','When '+c.name+' is weak:'))+'</b>'+li(v.weak.map(w=>esc(tr(w))));
  if(v&&v.strengths&&v.strengths.length)o+='<b>'+esc(T('نقاط قوته:','Strengths:'))+'</b>'+li(v.strengths.map(w=>esc(tr(w))));
  if(cl.counters.length)o+='<b>'+esc(T('أحسن كاونترات: ','Best counters: '))+'</b>'+cl.counters.slice(0,5).map(x=>esc(sn(x.c))).join('، ');
  return (o||esc(T(NOREC,'No documented data')))+chipsFor(c);
}
async function ansTips(c){
  ctx.champ=c;const g=G(c);const d=await loadDetail(c);
  let tips=(d&&d.tips&&d.tips.length)?d.tips:(g.tips||[]);let o='<b>'+esc(T('نصايح لعب '+sn(c),'Tips for '+c.name))+':</b>';
  if(tips.length)o+=li(tips.slice(0,5).map(t=>esc(tr(typeof t==='string'?t:(t.text||t.tip||JSON.stringify(t))))));
  if(g.gamePlan&&g.gamePlan.length)o+='<b>'+esc(T('خطة اللعب: ','Game plan: '))+'</b>'+li(g.gamePlan.map(x=>esc(tr(x))));
  if(!tips.length&&!(g.gamePlan||[]).length)o+=esc(T(NOREC,'No documented data'));
  return o+chipsFor(c);
}
function ansMatchup(a,b,lane){
  const rs=records(a,b).filter(m=>!lane||!m.lane||m.lane===lane);
  if(!rs.length)return esc(T('مفيش مواجهة موثقة بين '+sn(a)+' و'+sn(b)+(lane?' في '+lname(lane):'')+'. '+NOREC+'.','No documented matchup between '+a.name+' and '+b.name+'.'));
  let o='<b>'+esc(sn(a))+' ⚔ '+esc(sn(b))+'</b>';
  o+=li(rs.slice(0,3).map(m=>{
    const x=m.champion===a.name?a:b,y=x===a?b:a;
    const txt=m.verdict==='Hard'?T(sn(y)+' بيكسر '+sn(x)+' بقوة','Hard: '+y.name+' counters '+x.name):m.verdict==='Unfavorable'?T(sn(y)+' ماسك '+sn(x)+' (صعب على '+sn(x)+')',y.name+' has the edge on '+x.name):m.verdict==='Favorable'?T(sn(x)+' ماسك '+sn(y)+' (مريح)',x.name+' is favored vs '+y.name):T('متوازنة حسب المهارة','Even, skill-dependent');
    return esc(txt)+(m.lane?' <small>('+esc(lname(m.lane))+')</small>':'');}));
  o+=esc(sn(a)+': '+statLine(a))+'<br>'+esc(sn(b)+': '+statLine(b));
  ctx.champ=a;return o;
}
function ansTier(lane){
  const L=lane||'Mid';const arr=CH.filter(c=>(c.roles||[c.lane]).includes(L)).sort((a,b)=>tierOrder(ct(b,L))-tierOrder(ct(a,L))||((b.stats&&b.stats.winRate)||0)-((a.stats&&a.stats.winRate)||0)).slice(0,8);
  ctx.lane=L;
  return '<b>'+esc(T('أقوى أبطال '+lname(L)+' حاليًا (Tier + نسبة فوز، Patch '+((DBX.source||{}).patch||'')+'):','Top '+L+' picks (tier + winrate):'))+'</b>'+li(arr.map(c=>esc(sn(c))+' <small>(Tier '+esc(ct(c,L))+(c.stats?' · '+c.stats.winRate+'%':'')+')</small>'));
}
function ansItem(it){
  let o='<b>'+esc(A()&&it.nameAr?it.nameAr+' ('+it.name+')':it.name)+'</b>'+(it.price?' · '+it.price+T(' ذهب',' gold'):'')+(it.category?' · '+esc(it.category):'');
  if(it.description)o+='<br>'+esc(tr(it.description));
  if(it.usedBy&&it.usedBy.length)o+='<br>'+esc(T('بيستخدمه: ','Used by: '))+it.usedBy.slice(0,8).map(n=>{const c=CH.find(x=>x.name===n);return esc(c?sn(c):n);}).join('، ');
  return o;
}
function ansDraft(){
  try{
    const n=Object.keys(draft.ally).length+Object.keys(draft.enemy).length;
    if(!n)return esc(T('الدرافت فاضي. قولي مثلًا: «ضيف ياسو للخصم» أو ارفع لقطة شاشة بزر 📷.','Draft is empty. Add champions or upload a screenshot with 📷.'));
    scoreDraft();const rs=(typeof lastResults!=='undefined'?lastResults:[]).slice(0,3);
    if(!rs.length)return esc(T('مفيش ترشيحات متاحة.','No recommendations.'));
    let o='<b>'+esc(T('أفضل اختيارات لمسارك دلوقتي:','Top picks for your lane now:'))+'</b>'+li(rs.map(x=>'<b>'+esc(sn(x.c))+'</b> ('+x.score+'/100): '+x.reasons.slice(0,3).map(esc).join(' · ')));
    o+='<div class="as-chips">'+chip(T('افتح الدرافت','Open draft'),'__go_draft')+'</div>';
    return o;
  }catch(e){return esc(T('تعذر تحليل الدرافت.','Could not analyze draft.'));}
}
function addToDraft(list,side,lane){
  const done=[];
  list.forEach(c=>{
    let role=lane&&!draft[side][lane]?lane:null;
    if(!role)role=(c.roles||[c.lane]).find(r=>!draft[side][r])||LANES.find(r=>!draft[side][r]);
    if(!role)return;draft[side][role]=c.id;done.push(sn(c)+' ('+lname(role)+')');
  });
  try{renderSlots();renderDraftPool();}catch(e){}
  return done;
}
const JOKES=['ليه المغتال مبيحبش الـ vision؟ لأنه بيحب يبقى مفاجأة.','سابورت قال لـ ADC: متقلقش أنا معاك… وبعدين دخل الـ bush لوحده.','بطل بيقول «واحد بس بعد كده» وده الـ fifth game ورا بعض.','الـ Teemo مبيخسرش، هو بس بيزرع فطر في حياتك.'];
let jk=0;
/* ---------- فلتر الشتائم ---------- */
const BADW=['غبي','حمار','تافه','فاشل','زباله','stupid','idiot','dumb','useless','moron','كسمك','كس امك','شرموطه','شرموط','منيوك','متناك','خول','عرص','طيز','زبي','نيك','ابن الكلب','ابن ال','fuck','shit','bitch','asshole','dick','cunt','bastard'];
function isBad(q){const n=norm(q);return BADW.some(w=>{const m=norm(w);return n.includes(m)&&(m.length>3||(' '+n+' ').includes(' '+m+' '));});}
function maskBad(q){let r=String(q);BADW.forEach(w=>{r=r.split(w).join('***');});return r;}
const SOFT=['أنا مساعد وبحترمك، ومش هقدر أرد على الألفاظ دي. خلينا نركز في اللعبة وأساعدك تكسب. 🙏','مفيش داعي للزعل، أنا هنا أساعدك. قولي عايز تعرف إيه عن الأبطال أو الكاونترات؟ 🙂','بحترمك وبتمنى نفس الشيء. تعالى نشوف أحسن اختيار للدرافت بتاعك. 🎮'];
let sj=0;
/* ---------- دردشة عامة ---------- */
const CHAT=[
[/(صباح الخير|صباح النور|good morning)/,'صباح النور! ☀️ جاهز نكسب النهارده؟','Good morning! ☀️ Ready to win today?'],
[/(مساء الخير|مساء النور|good evening)/,'مساء النور! 🌙 نبدأ بدرافت؟','Good evening! 🌙 Shall we draft?'],
[/(تصبح علي خير|تصبحو|ليله سعيده|good night)/,'تصبح على خير! نوم الهنا وبكرة رانكد جديد. 😴','Good night! 😴'],
[/(عامل ايه|عامله ايه|ازيك|اخبارك|how are you|كيف حالك|اخبار)/,'أنا تمام الحمد لله، جاهز أساعدك. إنت عامل إيه؟ 😊','I am great, thanks! How are you? 😊'],
[/(انا كويس|انا تمام|الحمد لله|كويس|تمام|بخير|fine|good)$/,'الحمد لله، يلا نشوف هنلعب إيه النهارده. 🎮','Glad to hear it! 🎮'],
[/(انا زعلان|مضايق|تعبان|حزين|sad)/,'معلش يا صاحبي، ربنا يعدّيها. لو عايز تفصل شوية، جرّب تلعب بطل مريح. أنا هنا. 🤍','Sorry to hear that. I am here. 🤍'],
[/(مين صنعك|مين عملك|مين مبرمجك|who made you|who created)/,'اتعملت جوه تطبيق Rift Mate عشان أساعدك في Wild Rift. 🛠️','I was built inside the Rift Mate app to help with Wild Rift. 🛠️'],
[/(اسمك ايه|اسمك|what is your name)/,'اسمي مساعد Rift Mate. 🤖','I am the Rift Mate assistant. 🤖'],
[/(انت ذكي|انت بتفهم|انت ذكاء اصطناعي|are you ai|are you smart)/,'أنا مساعد محلي بيشتغل على داتا التطبيق من غير نت. مش بفهم زي ChatGPT، بس في Wild Rift هحاول أفيدك. 🤓','I am a local assistant working on the app data offline. Not like ChatGPT, but I know this app well. 🤓'],
[/(انت فين|انت موجود|بتسمعني|هل انت)/,'أنا معاك دايمًا جوه التطبيق. اسأل! 👋','I am right here. Ask away! 👋'],
[/(بتحب ايه|بتحب|favorite|ـ)/,'بحب الدرافت المظبوط والكاونتر الذكي. 😄','I love a well-built draft and a smart counter. 😄'],
[/(احسن لاعب|افضل لاعب|مين احسن لاعب)/,'احسن لاعب هو اللي بيتعلم من كل ماتش. 😉 قولي لينك وأرشحلك أقوى الأبطال.','The best player learns from every match. Tell me your lane and I will suggest strong picks. 😉'],
[/(سهل|اسهل بطل|مبتدئ|جديد في اللعبه|beginner)/,'لو مبتدئ، قولي اللين اللي بتحبه وأرشحلك أبطال سهلة وقوية. اكتب مثلًا: «أقوى سابورت». 🌱','For a beginner, tell me your lane and I will suggest easy, strong champions. 🌱'],
[/(ازاي ارفع الرانك|ارفع رانك|اطلع رانك|climb)/,'نصايح سريعة للرانك: 1) اتقن 2-3 أبطال بس 2) ركز على الـ farm والأهداف 3) تابع الـ vision 4) متلعبش وانت متضايق. 🔝','Quick ranked tips: master 2-3 champions, focus on farm and objectives, ward, and do not play tilted. 🔝'],
[/(انا بخسر|بخسر كتير|losing)/,'الخسارة بتحصل. راجع الدرافت بتاعك وجرب «حلل الدرافت»، وغالبًا الاختيار والمواجهة بيفرقوا كتير. 💪','Losses happen. Check your draft with "analyze draft". 💪'],
[/(مبروك|كسبت|فزت|won)/,'مبروك! 🎉 كمّل على كده.','Congrats! 🎉'],
[/(ايه رايك|رايك ايه)/,'رأيي مبني على الداتا: لو قولتلي بطل أو لين أقولك الأقوى والأضعف. 📊','My opinion comes from the data: name a champion or lane. 📊'],
[/(احا|ياه|اوف|هههه|ههه|lol|haha)/,'😄😄','😄'],
[/(ok|اوكي|اوك|حاضر|ماشي|تمام كده)$/,'ماشي! 👍 لو عايز حاجة قولي.','OK! 👍'],
[/(لا شكرا|مش عايز|خلاص)/,'تمام، أنا موجود لو احتجتني. 👍','Alright, I am here if you need me. 👍'],
[/(نفسي|عايز اتعلم|علمني)/,'قولي إنت عايز تتعلم إيه: بطل معين؟ لين؟ أو «نصايح [اسم بطل]». 📘','Tell me what to learn: a champion, a lane, or "tips [champion]". 📘'],
[/(ممكن تساعدني|محتاج مساعده|محتاج مساعدة)/,'أكيد! اكتب سؤالك أو «مساعدة» عشان تشوف اللي أقدر أعمله. 🙌','Sure! Type your question or "help". 🙌']
,[/^(اهلا|مرحبا|هاي|هلا|السلام عليكم|سلام عليكم|هالو|ازيك يا|hello|hi|hey|yo)\b/,'أهلًا بيك! 👋 أنا Rift Mate، اسألني عن أي بطل أو كاونتر أو بيلد.||يا أهلًا! 😄 نبدأ بإيه النهارده؟ درافت ولا كاونتر؟||أهلًا وسهلًا! جاهز أساعدك، قولي عايز إيه.','Hey there! 👋 Ask me about any champion, counter or build.||Hello! 😄 Draft or counter today?'],
[/(وعليكم السلام)/,'وعليكم السلام ورحمة الله! 🌹 اتفضل اسأل.','Peace be upon you too! 🌹'],
[/(^| )(شكرا|تسلم|تسلم ايدك|ميرسي|thanks|thank you|thx)( |$)/,'العفو! 🌹 أي وقت.||ولا يهمك، ده شغلي! 😄||تحت أمرك دايمًا. 🙌','You are welcome! 🌹||Anytime! 😄'],
[/(^| )(مع السلامه|باي|سلام|الى اللقاء|bye|goodbye|see you)( |$)/,'مع السلامه! 👋 بالتوفيق في الرانك.||في أمان الله! اكسب كتير. 🏆','Bye! 👋 Good luck climbing.'],
[/(انت مين|عرفني بنفسك|مين انت|who are you)/,'أنا مساعد Rift Mate، شغال أوفلاين على داتا التطبيق. بساعدك في الدرافت.','I am the Rift Mate assistant.'],
[/(بتعمل ايه|تقدر تعمل ايه|ايه اللي تعرفه|وظيفتك|what can you do)/,'أقدر اجاوبك عن كاونتر، بيلد، رونز، قدرات، إحصائيات، تير كل لاين، سينرجي، ونقاط الضعف. وبحلل الدرافت وبملاه من صورة. اكتب «مساعدة» لأمثلة. 💡','I can answer about counters, builds, runes, abilities, stats, tiers, synergy and weaknesses, analyze drafts and fill them from a screenshot. Type "help". 💡'],
[/(انت جميل|انت حلو|انت شاطر|انت رائع|برافو|عاش|شاطر|احسنت|good bot|well done|great job)/,'تسلم! كلامك شجعني. 😊||ده من ذوقك! يلا نكسب. 💪','Thanks, that means a lot! 😊'],
[/(بحبك|احبك|love you)/,'وأنا بحب أساعدك! 🤍 يلا نركز في الماتش.||ربنا يخليك! 🤍','That is kind of you! 🤍'],
[/(ممل|زهقان|زهقت|مليت|bored)/,'جرّب تحلل درافت جديد أو تسألني عن بطل مش بتلعبه، ممكن تلاقي حاجة تعجبك. 🎲','Try analyzing a new draft or asking about a champion you never play. 🎲'],
[/(نكتة|نكته|قولي نكتة|اضحكني|joke)/,'مرة واحد لعب ياسو وقال: مش هموت! ... وبعدين شاف الـ 0/10 قال: ده الـ windwall اللي كان ناقصني. 😂||ليه الدعم دايمًا هادي؟ لأنه خلاص مش لاقي حد يدي له كيل. 😂','A Yasuo says: I will not die! ... then sees 0/10. 😂'],
[/(^| )(لعبت كام|لعبت كتير|تعبت)( |$)/,'خد استراحة صغيرة، التركيز بيفرق في الرانك. ☕','Take a short break, focus matters in ranked. ☕'],
[/(ماتش صعب|لاعيبه بيلعبو وحش|الفريق وحش|تيم وحش|تيمي وحش|trolls?)/,'اللي بإيدك: درافت كويس وكوميونيكيشن هادي. ركز في اللي تقدر تتحكم فيه. 💪','Control what you can: a good draft and calm comms. 💪'],
[/(مين افضل|افضل بطل|احسن بطل)$/,'قولي اللين وأقولك الأقوى حسب بيانات التطبيق، مثلًا: «أقوى ميد». 📊','Tell me the lane, e.g. "best mid". 📊'],
[/(^| )(الجو|الطقس|الاكل|اكل|كوره|سياسه|دين)( |$)/,'ده برّه تخصصي، أنا متخصص في Wild Rift بس. 😅 اسألني عن الأبطال أو الدرافت.','That is outside what I know. I only know Wild Rift. 😅'],
[/(هتفضل معايا|هتسيبني|هتروح)/,'أنا جوه التطبيق وموجود في أي وقت. 🤝','I am inside the app, always available. 🤝'],
[/(^| )(غلط|مش صح|كلامك غلط)( |$)/,'معلش، لو الرد مش مظبوط قولي السؤال بشكل تاني أو اكتب اسم البطل واضح وأنا أحاول تاني. 🙏','Sorry. Rephrase or write the champion name clearly and I will try again. 🙏'],
[/(اعد|كرر|تاني|مش فاهم)$/,'أكيد، اسألني تاني بصيغة تانية وأنا أجاوبك. 🔁','Sure, ask again in other words. 🔁'],
[/(ايه الجديد|فيه جديد|اخر باتش|patch)/,'التطبيق شغال على داتا Patch 7.3f. 📅','The app runs on Patch 7.3f data. 📅'],
[/(انت بتتعلم|بتتدرب|تتعلم مني)/,'أنا مساعد محلي بقواعد وداتا التطبيق، مش بتعلم من المحادثات. بس بحاول أفهم صيغ كتير للسؤال. 🧠','I am a local rule-based assistant, I do not learn from chats, but I understand many phrasings. 🧠'],
[/(هل تتكلم عربي|بتتكلم عربي|بتفهم عربي|english|انجليزي)/,'بفهم عربي وإنجليزي، واتكلم باللغة اللي التطبيق شغال بيها. 🌍','I understand Arabic and English. 🌍']
,[/(نكتة|نكته|اضحكني|هزر معايا|قولي حاجة تضحك|joke|make me laugh|funny)/,'مرة واحد لعب ياسو وقال: مش هموت المرة دي! وبعدين الشاشة قالتله 0/9... قال: الغلط في الـ windwall مش فيا. 😂||ليه الجانجلر دايمًا متأخر؟ لأنه بيحسب الكامبات من ورا الخريطة. 🗺️😂||واحد سأل الدعم: ليه ماسك الورد؟ قاله: عشان لو الفريق خسر، أبقى على الأقل بصّرت. 😂||مرة مينيون وقف قدام تيمو وقاله: انت بتزرع فطر ولا بتزرع قلق؟ 😂||الـ ADC فاكر إنه الكاري، والدعم عارف إنه الشاحن. 🔋😂||أخطر جملة في الريفت: «أنا هعمل فلاش وأرجع». 💀😂','A Yasuo says: not dying this time! Screen says 0/9... "windwall was the problem". 😂||Why is the jungler late? He is counting camps through the fog. 😂||The ADC thinks he is the carry. The support knows he is the charger. 🔋😂'],
[/(ههه+|هاها+|😂|🤣|lol|lmao|haha+)/,'😂😂 ده كان قوي! كمل.||هههههه ضحكتني والله. 🤣||ههه تمام كده، بس خلي الضحك ما يوقفناش عن الرانك! 😄','Haha 😂 that was good!||LOL 🤣 you got me.'],
[/(انت بتضحك|بتضحك|بتهزر|هزار|دمك خفيف|دمك خفيف)/,'أنا بحب الهزار بس بدون قلة أدب. دمي خفيف على قد ما الداتا تسمح! 😄','I love a good joke, as long as it is kind. 😄'],
[/(احكيلي|احكي حكاية|قصة)/,'كان فيه سموكر بيلعب ميد، دايمًا بيقول: الدرافت ده مضمون. وبعدين يشوف الخصم أخد 3 تانكات ويقول: طب الدرافت اللي بعده. 😄 تحب أحلللك درافت بجد؟','There was a mid laner who always said: this draft is guaranteed. Then the enemy took 3 tanks. 😄 Want a real analysis?'],
[/(صباحو|صباح الفل|صباح الورد)/,'صباح الفل والياسمين! 🌼 جاهز للرانك ولا نفطر الأول؟ 😄','Good morning! 🌼 Ready to climb or breakfast first? 😄'],
[/(سلامو عليكو|يا صاحبي|يا غالي|يا برنس|يا باشا|يا كبير|يا معلم)/,'يا هلا بيك يا باشا! 😎 أؤمر.||تحت أمرك يا كبير! نحلل درافت ولا نجيب كاونتر؟ 💪||يا أهلا يا معلم! عايز إيه النهاردة؟ 🎮','Hey boss! 😎 What do you need?'],
[/(^| )(انت ظريف|ظريف|لذيذ|كيوت|جامد|جامد جدا|تحفه|مفيد|برافو عليك)( |$)/,'تسلم يا غالي! ده من ذوقك. 😊 يلا نكسب.||أنت اللي جامد! 😄 نشوف حاجة تانية؟','Thank you, that is kind of you! 😊'],
[/(^| )(زهقت منك|مش عاجبني|اتأخرت)( |$)/,'حقك عليا، قولي أنا أقدر أساعدك إزاي وأنا أظبطها فورًا. 🙏','Sorry about that. Tell me how I can help and I will fix it. 🙏'],
[/(وحشتني|كنت فين)/,'وإنت كمان وحشتني! 🤍 أنا هنا من أول ما فتحت التطبيق. نبدأ؟','I missed you too! 🤍 Shall we start?'],
[/(هتكسب|هنكسب|نكسب|هفوز)/,'بالدرافت المظبوط والكاونتر الصح كل حاجة ممكنة. 🏆 ابعتلي التشكيلة وأقولك فرصتكم.','With a good draft and counters anything is possible. 🏆 Send the comp.'],
[/(انا نمت|هنام|عايز انام|نعسان|تعبان نوم)/,'نوم الهنا! 😴 بكرة رانك جديد وراسك أنضف.','Sleep well! 😴'],
[/(جعان|هاكل|اكل ايه)/,'الأول ماتش وبعدين أكل! 😄 بس لو جعان بجد، كل حاجة خفيفة وارجع بطاقة. 🍕','Match first, then food! 😄 Eat something light and come back. 🍕']
,
/* v4.0.19 expanded situations */
[/^(?:خسرت|خسرنا|اتهزمنا|هزمونا|اتغلبنا)$/,"معلش يا باشا، الخسارة جزء من الرانك. 🫡||كل ماتش بيعلمك حاجة، ارجع بذهن صافي.||خد نفس وشوف الدرافت اللي فات كان فيه إيه، ممكن نصلحه سوا. 🔍||ماتش وعدى، الجاي أحسن بإذن الله. 💪","Gg, losses happen. Reset and go again. 💪"],
[/^(?:كسبت|كسبنا|فزت|فزنا|انتصرنا)$/,"مبروك يا بطل! 🏆 عاش جدًا.||يا سلام! تستاهل. 🎉 عايز نحلل الدرافت بتاعكم؟||ألف مبروك! كمّل بنفس التركيز. 🔥||كده ينفع! الفوز ده بتاعك. 😎","Congrats on the win! 🏆"],
[/^(?:\S+ ){0,3}(?:خسرت كتير|خسرت ستريك|ستريك خساير|ستريك خسارة|خسرت ٣|خسرت ٤|خسرت ٥|لوز ستريك|losing streak)(?: \S+){0,3}$/,"ستريك الخسارة بيحصل لأي حد. 🫂 الأحسن تقعد شوية وترجع بعدها.||غالبًا التيلت هو المشكلة مش مهارتك. خد استراحة نص ساعة وارجع.||جرّب تلعب بطلين تعرفهم كويس بدل ما تغير كل ماتش. 🎯||وقّف ماتش أو اتنين، ومتحاولش تعوض بسرعة.","Losing streaks happen. Take a break and stick to champions you know. 🫂"],
[/^(?:\S+ ){0,3}(?:تيلت|اتعصبت|متعصب|عصبي|اعصابي|زعلان من الماتش|اتنرفزت)(?: \S+){0,3}$/,"اهدا يا باشا، الأعصاب بتضيع ماتشات أكتر من الدرافت. 🧘||خد نفس عميق. ماتش واحد مش نهاية الدنيا. 😌||لو متعصب، الأحسن تقفل وتشرب مية وترجع. 💧||أنا معاك. فكّر في الماتش الجاي بس. 🎯","Take a breath. Tilt loses more games than drafts. 🧘"],
[/^(?:\S+ ){0,3}(?:فريقي وحش|التيم وحش|زمايلي وحشين|زمايلي بيلعبو وحش|فيدر|فيدرز|فيدر عندي|تروول|ترول)(?: \S+){0,3}$/,"أحيانًا بيحصل، بس اللي بإيدك: درافت كويس وكلام هادي ومحاولة تكسب لينك. 🤝||ركز في لعبك. أوقات كتير ماتش بيتقلب لو فضلت ثابت. 🔥||متدخلش في خناقات، اكتب كلمة مفيدة بس. 🙂","Focus on what you control: your lane and calm comms. 🤝"],
[/^(?:\S+ ){0,3}(?:ازاي اطلع رانك|اطلع رانك|ازاي اعلى|ازاي اكسب كتير|عايز ارفع رانك|ارفع الرانك|اتحسن في الرانك)(?: \S+){0,3}$/,"الأساسيات: بطل أو اتنين لكل لين تتقنهم، درافت مظبوط، وتركيز على الأهداف مش الكيلز بس. 📈||لعّب نفس الأبطال وراجع أخطاءك. وبعد كل ماتش اسأل: إيه اللي كان ممكن أعمله أحسن؟ 🧠||قلل التيلت واسأل عن الكاونتر قبل ما تختار. وأنا هنا لده. 😉","To climb: master a small pool, draft well, and play for objectives. 📈"],
[/^(?:\S+ ){0,3}(?:بطل سهل|ابدا بايه|مبتدي|مبتديء|اول مره العب|لسه جديد)(?: \S+){0,3}$/,"لو لسه جديد، اختار بطل بسيط وثابت وتعلّمه كويس قبل ما تنتقل لغيره. 🌱 قولي اللين وأقولك اللي أنسب من داتا التطبيق.||أهلًا بيك! ابدأ بلين واحد وبطلين بس، والباقي بييجي مع الوقت. 🌟||اسألني «أقوى [لين]» وأعرضلك الأبطال حسب التير، وبعدين اختار اللي يعجبك. 📊","New? Start with one lane and two champions, learn them well. 🌱"],
[/^(?:\S+ ){0,3}(?:ايه رايك فيا|رايك فيا|انا لاعب كويس|انا شاطر)(?: \S+){0,3}$/,"أنا مش شايف لعبك، بس طالما بتراجع وبتتعلم فأنت ماشي صح. 💪||الاهتمام بالدرافت لوحده ده علامة لاعب جاد. 👏","I cannot see your play, but studying drafts is the mark of a serious player. 💪"],
[/^(?:\S+ ){0,3}(?:انت ذكي|ذكي|عبقري|فاهم|مخك كبير|انت دكي)(?: \S+){0,3}$/,"تسلم! بس أنا بشتغل بقواعد وداتا التطبيق، مش ذكاء توليدي. 😄 اللي عندي بقدمه بدقة.||ده من ذوقك! بحاول أكون مفيد في حدود الداتا اللي معايا. 🤓||شكرًا! لو لقيت رد مش كويس قولي أظبطه. 🙏","Thanks! I run on the app's data and rules, not generative AI. 🤓"],
[/^(?:\S+ ){0,3}(?:غبي|مش ذكي|ضعيف)(?: \S+){0,3}$/,"معلش لو الرد ماعجبكش، قولي السؤال بشكل تاني أو اكتب اسم البطل بوضوح وأنا أحاول أظبطها. 🙏||حقك عليا. أنا بتعلم من صياغاتك الأوضح، جرّب تسألني تاني. 🙂","Sorry. Try rephrasing or naming the champion clearly. 🙏"],
[/^(?:\S+ ){0,3}(?:مين عملك|مين صنعك|مين المطور|مين مطورك|مين صاحب التطبيق|صاحب التطبيق)(?: \S+){0,3}$/,"المطور وصاحب Rift Mate هو Mazen Mohamed. تلاقي صفحته في قسم المطور. ✨||Rift Mate من تطوير Mazen Mohamed، وأنا المساعد جوّاه. 🤝","Rift Mate was built by Mazen Mohamed. ✨"],
[/^(?:\S+ ){0,3}(?:اسمك ايه|اسمك|بتتسمى ايه|انا مين)(?: \S+){0,3}$/,"أنا مساعد Rift Mate. 🛡️ ممكن تناديني «ريفت» لو حابب. 😄||اسمي مساعد Rift Mate، بس لقبي عندك: اللي بيعرف الكاونترات! 😎","I am the Rift Mate assistant. 🛡️"],
[/^(?:\S+ ){0,3}(?:عمرك كام|انت كام سنه|انت ولد ولا بنت|انت ولد|انت بنت)(?: \S+){0,3}$/,"أنا برنامج داخل التطبيق، مش ليا عمر ولا نوع. 😄 بس عندي طاقة لاعب مجتهد.||أنا مساعد رقمي، تقدر تعتبرني صاحبك في الدرافت. 🤝","I am an in-app assistant, no age or gender. 😄"],
[/^(?:\S+ ){0,3}(?:انت حقيقي|انت روبوت|انت انسان|انت بوت|انت ai)(?: \S+){0,3}$/,"أنا مساعد برمجي بيشتغل جوه التطبيق بقواعد وداتا محلية، مش إنسان. بس بحاول أكون صاحب كويس. 🤖||مش إنسان، أنا قواعد وداتا اتكتبت بعناية. 🤖 وده عشان أشتغل أوفلاين.","I am a rule-based in-app assistant, not a person. 🤖"],
[/^(?:\S+ ){0,3}(?:انت فاهمني|فاهم عليا|فهمتني)(?: \S+){0,3}$/,"بحاول! لو سؤالك فيه اسم بطل وطلب واضح هرد بدقة. لو لأ، قولي بصيغة تانية. 🎯","I try! Name a champion and what you need. 🎯"],
[/^(?:\S+ ){0,3}(?:ازيك|عامل ايه|عامله ايه|اخبارك ايه|اخبارك|ايه الاخبار|انت كويس)(?: \S+){0,3}$/,"الحمد لله تمام! 😄 وإنت أخبارك؟ جاهز لماتش جديد؟||زي الفل! 🌟 عايز نحلل درافت ولا نسأل عن بطل؟||تمام وجاهز. إنت عامل إيه؟ 😎||الحمد لله، أنا هنا ومستعد. اتفضل اسأل. 🙌","I am great! Ready for a new match? 😄"],
[/^(?:\S+ ){0,3}(?:كل سنه وانت طيب|عيد مبارك|رمضان كريم|عيد سعيد|مبارك عليكم الشهر)(?: \S+){0,3}$/,"وإنت طيب وبخير! 🌙 كل سنة وإنت بألف خير.||الله يبارك فيك! أيام مباركة عليك وعلى أهلك. 🌹||تسلم يا غالي، وكل عام وأنت بخير! 🎉","Wishing you the best too! 🌹"],
[/^(?:\S+ ){0,3}(?:جمعه مباركه|الجمعه|يوم الجمعه)(?: \S+){0,3}$/,"جمعة مباركة عليك! 🕌 الله يتقبل منك.||جمعة مباركة! ماتشات الجمعة أحسن بإذن الله. 🌿","Blessed Friday! 🌿"],
[/^(?:\S+ ){0,3}(?:مساء الخير|مساء النور|مساء الفل|مساء الورد)(?: \S+){0,3}$/,"مساء النور! 🌙 جاهز لماتشات الليل؟||مساء الفل! اتفضل اسأل في أي حاجة. 🌸||مساء الخير عليك. نبدأ ببطل ولا درافت؟ 😄","Good evening! 🌙"],
[/^(?:\S+ ){0,3}(?:تصبح على خير|تصبحوا على خير|ليله سعيده|هروح انام)(?: \S+){0,3}$/,"وإنت من أهل الخير! 🌙 نام كويس وبكرة رانك جديد.||تصبح على خير يا باشا. 😴 بالتوفيق بكرة.||تسلم، ارتاح وارجع بطاقة. 🌟","Good night! 😴"],
[/^(?:\S+ ){0,3}(?:انا تعبان|تعبان|انا مرهق|مرهق|مجهد|مصدع|صداع)(?: \S+){0,3}$/,"سلامتك! 🫂 ارتاح شوية، اللعب مش هيطير.||خد استراحة ومية وشوية هدوء. صحتك أهم من أي ماتش. 💧||الراحة مهمة، متلعبش وإنت مرهق عشان قراراتك بتبقى أضعف. 😌","Take care. Rest first, games can wait. 🫂"],
[/^(?:\S+ ){0,3}(?:انا زعلان|زعلان|حزين|متضايق|مضايق|مكتئب)(?: \S+){0,3}$/,"ألف سلامة عليك. 🫂 لو حابب تفضفض أنا سامعك، ولو عايز تلعب شوية تشتت وتروّق فأنا معاك.||معلش، الأيام بتعدي. خد وقتك. 🌿 لو محتاج حاجة في اللعبة أنا هنا.||ربنا يريح قلبك. 🤍 والماتش الجاي ممكن يبقى أحسن.","Sorry you feel down. 🫂 I am here if you want to chat or play."],
[/^(?:\S+ ){0,3}(?:انا مبسوط|مبسوط|فرحان|سعيد|يوم جميل)(?: \S+){0,3}$/,"يا رب دايمًا! 😄 مبسوط عشانك.||جميل! الطاقة دي هتفرق في الماتش. 🔥||الله! كمّل كده. 😎","Great to hear it! 😄"],
[/^(?:\S+ ){0,3}(?:امتحان|مذاكره|هذاكر|عندي امتحان|دراسه|كليه|مدرسه)(?: \S+){0,3}$/,"ربنا يوفقك! 📚 ذاكر كويس وبعدين العب براحتك.||بالتوفيق في الامتحان. 🍀 خد وقتك وارجع للرانك بعدها.||التركيز في المذاكرة أهم. وأنا مستنيك لما تخلص. 😉","Good luck with your studies! 📚"],
[/^(?:\S+ ){0,3}(?:شغل|عندي شغل|شغلي)(?: \S+){0,3}$/,"ربنا يعينك على الشغل! 💼 ولما تفضى أنا هنا.||شد حيلك! وبعد الشغل ماتش خفيف يفرق. 😄","Good luck at work! 💼"],
[/^(?:\S+ ){0,3}(?:كوره|ماتش الاهلي|ماتش الزمالك|ماتش كره|صلاح)(?: \S+){0,3}$/,"الكورة مش تخصصي، أنا في Wild Rift بس. ⚽😄 بس بحب حماسك!||بعيد عن تخصصي، بس تحب نحلل درافت قبل ما الماتش يبدأ؟ 😄","Football is outside my lane, I am a Wild Rift assistant. ⚽"],
[/^(?:\S+ ){0,3}(?:لاج|الاج|بيلاج|اللاج|بنج عالي|ping|lag|النت وحش|النت بطيء)(?: \S+){0,3}$/,"التطبيق بتاعي أوفلاين ومش بيعتمد على النت. لو لاج اللعبة، جرّب تقفل التطبيقات التانية وتقرب من الراوتر. 📶||اللاج بيجي من النت غالبًا. جرّب بيانات الموبايل أو وصلة تانية. 📱","The app is offline. For game lag, try another connection or close other apps. 📶"],
[/^(?:\S+ ){0,3}(?:الموبايل سخن|موبايلي سخن|البطاريه|بطاريه بتخلص|سخونه)(?: \S+){0,3}$/,"لو الموبايل سخن، خفف سطوع الشاشة واقفل التطبيقات اللي في الخلفية وخد استراحة. 🔋||التطبيق نفسه خفيف وأوفلاين. جرّب تقلل الحركات من الإعدادات. ⚙️","If your phone is hot, lower brightness and take a break. 🔋"],
[/^(?:\S+ ){0,3}(?:التطبيق بطيء|بطيء|بيهنج|هنج|بيقفل|crash)(?: \S+){0,3}$/,"معلش! جرّب تقفله وتفتحه تاني، ومن الإعدادات قلل الحركات لو الجهاز ضعيف. ⚙️ ولو المشكلة فضلت قولي بتحصل فين بالظبط. 🙏","Sorry! Try reopening the app and reducing animations in Settings. ⚙️"],
[/^(?:\S+ ){0,3}(?:ايه المميزات|مميزات التطبيق|ايه في التطبيق|التطبيق بيعمل ايه)(?: \S+){0,3}$/,"في التطبيق: مساعد الدرافت، محلل الكاونتر والانسجام، معمل البيلدات والرونات، الأبطال والعناصر، الميتا، المدرب، والصورة إلى درافت. وكله أوفلاين. 🛡️","The app has a draft assistant, counter and synergy analyzers, build lab, champions, items, meta, coach, and photo-to-draft. All offline. 🛡️"],
[/^(?:\S+ ){0,3}(?:ازاي استخدم|طريقه الاستخدام|اتعلم التطبيق|اشرح التطبيق|ازاي اشتغل عليه)(?: \S+){0,3}$/,"ابدأ بقسم الدرافت: ضيف أبطال فريقك والخصم، اختار لينك واضغط حلل. وبعدها اسألني عن أي بطل أو كاونتر. 📘||الدرافت لتحليل التشكيلة، والكاونتر والانسجام للمقارنة، والبيلدات للاطلاع. وأنا أجاوبك على أي سؤال. 🙂","Open Draft, add champions, pick your lane and analyze. Ask me anything else. 📘"],
[/^(?:\S+ ){0,3}(?:اللغه|غير اللغه|انجليزي|عربي)(?: \S+){0,3}$/,"تقدر تغير اللغة من زر اللغة في الأعلى أو من الإعدادات. 🌍","Switch language from the top button or Settings. 🌍"],
[/^(?:الموسيقى|الصوت|الاغاني|المزيكا)$/,"الموسيقى الخلفية في الإعدادات: تشغيل، إيقاف، كتم، وتحكم في الصوت. 🎵","Background music is in Settings: play, stop, mute and volume. 🎵"],
[/^(?:\S+ ){0,3}(?:ايه الفرق بين الكاونتر والانسجام|كاونتر ولا انسجام|يعني ايه كاونتر|يعني ايه انسجام|يعني ايه سينرجي)(?: \S+){0,3}$/,"الكاونتر: بطل بيضغط على بطل تاني في المواجهة. الانسجام: أبطال بيكملوا بعض في الفريق. الاتنين مهمين في الدرافت. 🧩||الكاونتر ضد الخصم، والانسجام مع زمايلك. ✨","Counter = a champion pressures another; synergy = champions that work together. 🧩"],
[/^(?:\S+ ){0,3}(?:يعني ايه درافت|ايه هو الدرافت|مين الدرافت)(?: \S+){0,3}$/,"الدرافت هو مرحلة اختيار الأبطال قبل الماتش. اختيار أبطال متكاملين وقادرين على مواجهة الخصم بيحدد جزء كبير من الأداء. 📋","Draft is the champion selection phase before the match. 📋"],
[/^(?:\S+ ){0,3}(?:يعني ايه ميتا|ايه الميتا|ايه هي الميتا)(?: \S+){0,3}$/,"الميتا هي الأبطال والأساليب الأقوى حاليًا حسب الباتش. 📊 في التطبيق قسم الميتا بيعرضها حسب التير اللي اتسجل.","Meta means the strongest champions and styles in the current patch. 📊"],
[/^(?:\S+ ){0,3}(?:يعني ايه تير|ايه التير|ايه الفرق بين s و a)(?: \S+){0,3}$/,"التير تصنيف للأبطال من S+ لحد C حسب قوتهم في الباتش. التصنيف ده ملخّص، مش حكم نهائي في أي ماتش. 🏅","Tier ranks champions from S+ to C by patch strength. It is a summary, not a verdict. 🏅"],
[/^(?:\S+ ){0,3}(?:ايه الاسكور|الاسكور بيتحسب ازاي|الدرجه بتتحسب ازاي|ازاي بتحسب)(?: \S+){0,3}$/,"السكور في الدرافت بيجمع: التير، ملاءمة اللين، المواجهات الموثقة، الانسجام، واحتياج الفريق. والأسباب بتظهر تحت كل ترشيح. 🧮","The draft score combines tier, lane fit, documented matchups, synergy and team needs. 🧮"],
[/^(?:\S+ ){0,3}(?:اثق فيك|دقيق|دقتك كام|انت صح|بتغلط)(?: \S+){0,3}$/,"ردودي من داتا التطبيق الموثقة، ولو مفيش داتا بقولك «لا تتوفر بيانات موثقة». مش بخمّن. ولو لقيت غلطة بلّغني أظبطها. ✅","My answers come from the app's documented data. If there is none I say so. ✅"],
[/^(?:\S+ ){0,3}(?:ارشحلي|رشحلي|اختار عني|اختارلي|مش عارف العب ايه)(?: \S+){0,3}$/,"قولي اللين اللي هتلعبه وأرشحلك حسب التير وبيانات التطبيق، أو أضف التشكيلة في الدرافت وأحللها. 🎯","Tell me your lane and I will suggest picks from the app's data. 🎯"],
[/^(?:\S+ ){0,3}(?:عايز العب حاجه جديده|جرب حاجه جديده|بطل مش معروف)(?: \S+){0,3}$/,"جرّب تسألني «أقوى [لين]» وأعرضلك أبطال تير عالي، وتختار منهم واحد ما لعبتهوش قبل كده. 🎲","Ask for the best in a lane and try one you have never played. 🎲"],
[/^(?:\S+ ){0,3}(?:نصيحه|نصايح عامه|اديني نصيحه|نصيحه سريعه)(?: \S+){0,3}$/,"نصيحة: خد بالك من الخريطة وقبل ما تدخل أي مشاجرة اتأكد إن فريقك قريب. 🗺️||نصيحة: متفضلش تموت على نفس الحركة، غيّر طريقة لعبك. 🔁||نصيحة: الدرافت اللي فيه خطة واضحة أحسن من أقوى أبطال من غير تناغم. 🧩||نصيحة: صبرك على اللين غالبًا أفضل من الاندفاع. 🧘","Tip: check the minimap before every fight. 🗺️"],
[/^(?:\S+ ){0,3}(?:ازاي اتجنب الموت|بموت كتير|بموت|اموت كتير)(?: \S+){0,3}$/,"لو بتموت كتير، افتح الخريطة أكتر، وابعد عن الخطوط من غير رؤية، وفكر في الكاونتر قبل الاشتباك. 👀||جرّب تلعب بطل أكثر أمانًا وتتعلم توقيت الدخول. 🛡️","If you die a lot, watch the minimap and avoid fights without vision. 👀"],
[/^(?:\S+ ){0,3}(?:ازاي افارم|الفارم|فارم احسن|سي اس)(?: \S+){0,3}$/,"الفارم مهارة تتحسن بالتدريب: ركز على ضربة الجندي الأخيرة، وجرّب تتدرب في وضع التمرين. 🌾","Farming improves with practice: focus on last hits. 🌾"],
[/^(?:\S+ ){0,3}(?:جانجل ازاي|لعب الجانجل|ازاي اللعب جانجل)(?: \S+){0,3}$/,"الجانجل عنده مسار واضح: تعرف الخصم فين، وتساعد اللين اللي متقدم، وتحافظ على الأهداف. اسألني عن بطل جانجل معين وأوريك بيانات التطبيق. 🌿","Jungle is about tracking, helping winning lanes and taking objectives. Ask about a specific jungler. 🌿"],
[/^(?:\S+ ){0,3}(?:سابورت ازاي|لعب السابورت|ازاي اللعب سابورت)(?: \S+){0,3}$/,"السابورت بيحمي ويفتح الرؤية ويحدد توقيت الاشتباك. اختيار بطل يكمّل الدراجون مهم، اسألني عن «انسجام» سابورت معين. 🛡️","Support protects, provides vision and times fights. Ask about synergy for a specific support. 🛡️"],
[/^(?:\S+ ){0,3}(?:ازاي اشتغل مع الفريق|اتواصل مع الفريق|كوميونيكيشن|تواصل)(?: \S+){0,3}$/,"استخدم رسائل قصيرة وإشارات واضحة، ومتتخانقش. «ارجع» و«اقتل هدف» أحسن من اللوم. 🗣️","Use short, clear pings and skip the blame. 🗣️"],
[/^(?:\S+ ){0,3}(?:انا عايز اتسلى|اتسلى|فاضي|مفيش حاجه اعملها|فاضي ومزهق)(?: \S+){0,3}$/,"نتسلى! جرّب تسألني سؤال عن بطل غريب، أو قولي «نكتة»، أو حلل درافت وهمي مع أصحابك. 🎮||تحب أحكيلك نكتة ولا نلعب بالأبطال؟ اطلب «نكتة» أو «حكاية». 😄","Bored? Ask for a joke, a story, or analyze a fun draft. 🎮"],
[/^(?:\S+ ){0,3}(?:ضحكني|عايز اضحك|حاجه تضحك|قولي حاجه حلوه)(?: \S+){0,3}$/,"لو ياسو قال «هنكسب»، اطمئن: سبقها 5 دقايق ويندوول. 😂||قالوا للسابورت: مين بيحميك؟ قال: الكاميرا بتاعت السيرفر. 😄||ثقة الجانجل في الجانج: ٩٠٪. نتيجة الماتش: ٠/٥. 😅","Here is one: Yasuo says 'we win'. Then the windwall cooldown hits. 😂"],
[/^(?:هههه+|ههه|هاها|هاهاها|lol|lmao|😂)$/,"😂😂 يا سلام! لو عايز كمان قولّي «نكتة».||هههه حلو الضحك ده! 😄||يا باشا ضحكتني! 🤣 كمّل.||😂 جدع! يلا نرجع للماتش. 😉","😂 Glad you are laughing! Ask for another joke anytime."],
[/^(?:ايوه|اه|ايوا|تمام|ماشي|اوكي|ok|okay|حاضر)$/,"تمام! اتفضل اسأل أو اكتب اسم بطل. 🙌||ماشي! عايز تبدأ بإيه؟ 😉||اوكي، أنا جاهز. ✅","Okay! Ask away. 🙌"],
[/^(?:\S+ ){0,3}(?:لا|لأ|مش عايز|لا شكرا|مش دلوقتي)(?: \S+){0,3}$/,"ولا يهمك، وقت ما تحب أنا هنا. 🙂||تمام، خد راحتك. 👍","No problem, I am here when you need me. 🙂"],
[/^(?:استنى|ثواني|لحظه|دقيقه|استني)$/,"خد وقتك، أنا مستنيك. ⏳||براحتك، مفيش استعجال. 🙂","Take your time. ⏳"],
[/^(?:\S+ ){0,3}(?:ايه ده|يا نهار|ايه الحلاوه دي|واو|wow|ياه)(?: \S+){0,3}$/,"😄 حلو؟ عايز تعرف أكتر عن أي حاجة؟||يا سلام! اتفضل اسأل لو عايز تفاصيل. ✨","😄 Want to dig deeper? Ask away."],
[/^(?:\S+ ){0,3}(?:بتحب ايه|بتحب مين|ايه بطلك المفضل|بطلك المفضل|مين احسن بطل عندك)(?: \S+){0,3}$/,"أنا مش بلعب، بس بحب الأبطال اللي بتحتاج تفكير في الكاونتر. 🧠 قولي إنت بتحب مين وأطلعلك أبرز معلومات عنه.||اختياراتي بتتبع الداتا مش الذوق، بس قولي بطلك وأكلمك عنه. 🎯","I do not play, I follow data. Tell me your favorite and I will tell you about it. 🎯"],
[/^(?:\S+ ){0,3}(?:ايه رايك في الباتش|الباتش حلو|الباتش وحش|الباتش الجديد)(?: \S+){0,3}$/,"أنا بقرا بيانات الباتش 7.3f اللي في التطبيق. الرأي الأخير ليك أنت لما تلعب. 📅","I read the Patch 7.3f data in the app. Your own play decides the opinion. 📅"],
[/^(?:\S+ ){0,3}(?:انت بتنام|بتنام|بتتعب|بتاكل)(?: \S+){0,3}$/,"أنا برنامج، مبتعبش ولا بنام. 😄 بس أنا هنا في أي وقت.","I am software, I do not sleep or tire. 😄"],
[/^(?:اسمع|كلمني|اتكلم|صوت|ميك)$/,"أنا بكتب بس، مفيش صوت أو ميكروفون عشان التطبيق أوفلاين بالكامل. ⌨️ اكتب سؤالك.","I only type, there is no voice or mic since the app is fully offline. ⌨️"],
[/^(?:\S+ ){0,3}(?:اتصل|كلم مازن|رقم مازن|تواصل مع المطور|ايميل المطور)(?: \S+){0,3}$/,"تقدر تتواصل مع المطور من قسم «المطور» عبر الحساب الرسمي المتاح. 🤝","You can reach the developer from the Developer section via the official account. 🤝"],
[/^(?:\S+ ){0,3}(?:حلو التطبيق|التطبيق حلو|التطبيق جامد|بحب التطبيق|التطبيق ممتاز)(?: \S+){0,3}$/,"ده شغل Mazen وفريق الاختبار، وأنا فرحان إنه عجبك! 😊||تسلم! لو عندك فكرة تحسين، المطور أكيد هيحب يعرف. 💡","Glad you like the app! 😊"],
[/^(?:\S+ ){0,3}(?:التطبيق وحش|مش عاجبني التطبيق|التطبيق وحش جدا|مش عاجبني)(?: \S+){0,3}$/,"آسف إنه مش مريحك. 🙏 قولي إيه اللي مضايقك بالظبط وأنا أوصله.||حقك. قولي المشكلة وأنا أسجلها وأقولها للمطور. 🛠️","Sorry about that. Tell me what bothers you and I will pass it along. 🛠️"],
[/^(?:\S+ ){0,3}(?:عندي فكره|اقتراح|عايز اقترح|ضيف ميزه|ميزه جديده)(?: \S+){0,3}$/,"أحب الأفكار! 💡 اكتب فكرتك وأنا أسجلها وأوصلها للمطور. أي ميزة جديدة بتخضع للقواعد: أوفلاين ومن غير بيانات مخترعة.","Love ideas! 💡 Share yours and I will note it for the developer."],
[/^(?:\S+ ){0,3}(?:كويس|حلو|جميل|رائع|عظيم|ممتاز|برافو عليك)(?: \S+){0,3}$/,"تسلم! 🙏 عايز نكمل في إيه؟||جميل! نكمل. 🔥","Nice! What next? 🙏"],
[/^(?:يلا|هيا|يالا|نبدا|بينا)$/,"يلا بينا! 🚀 قولي اللين أو أضف التشكيلة وأحللها.||ماشي، جاهز. ابدأ بسؤال أو اكتب «حلل الدرافت». 🎯","Let us go! 🚀 Tell me a lane or add your draft."],
[/^(?:\S+ ){0,3}(?:وحش|وحشه|مش حلو|مش كويس)(?: \S+){0,3}$/,"قولي أنهي حاجة مش حلوة وأنا أحاول أساعد أو أعدل. 🙏","Tell me what is off and I will try to help. 🙏"],
[/^(?:\S+ ){0,3}(?:احسن حاجه في وايلد ريفت|ليه بلعب وايلد ريفت|وايلد ريفت حلوه)(?: \S+){0,3}$/,"وايلد ريفت لعبة سريعة تتحمّس فيها، والدرافت بيفرق جدًا فيها. 🎮","Wild Rift is fast and exciting, and the draft matters a lot. 🎮"],
[/^(?:\S+ ){0,3}(?:مين احسن لاعب|احسن لاعب محترف|بروبلاير|بروفيشنال)(?: \S+){0,3}$/,"معنديش بيانات موثقة عن اللاعبين المحترفين في التطبيق، فمش هقول حاجة مخترعة. 🙂 أقدر أساعدك في الأبطال والدرافت.","I have no documented pro-player data in the app, so I will not invent any. 🙂"],
[/^(?:\S+ ){0,3}(?:نصيحه لماتش مهم|ماتش مهم|ماتش فاصل|بطوله|تورنمنت|ترنمنت)(?: \S+){0,3}$/,"للماتش المهم: درافت واضح، تواصل هادي، وأبطال تعرفهم كويس. اكتب تشكيلتك وأحللها لك. 🏟️","For important matches: clear draft, calm comms, champions you know. Add your draft for analysis. 🏟️"],
[/^(?:\S+ ){0,3}(?:رشحلي بطل اتعلمه|عايز اتعلم بطل|بطل جديد اتعلمه)(?: \S+){0,3}$/,"قولي اللين اللي بتفضله وأرشحلك بطل تير كويس، وبعدين اسألني عن البيلد والرونات بتاعه. 📘","Tell me your lane and I will suggest a champion to learn, then build and runes. 📘"],
[/^(?:\S+ ){0,3}(?:بتفهم مصري|بتفهم عامي|عامي|فصحى|بالمصري)(?: \S+){0,3}$/,"أيوه بفهم عامية مصرية وعربي فصحى وإنجليزي، اكتب براحتك. 🇪🇬","Yes, I understand Egyptian Arabic, Modern Standard Arabic and English. 🇪🇬"],
[/^(?:سكت|اسكت|كفايه|بس|وقف)$/,"تمام، هسكت. لو احتجتني قولّي. 🤐||حاضر! قول لي لما تحتاج. 🙂","Okay, I will be quiet. Call me when you need me. 🤐"],
[/^(?:\S+ ){0,3}(?:انا مستعجل|بسرعه|بسرعه لو سمحت|مستعجل)(?: \S+){0,3}$/,"حاضر، اكتب اسم البطل وطلبك في سطر واحد وأرد بسرعة. ⚡","Sure, name the champion and your need in one line. ⚡"],
[/^(?:\S+ ){0,3}(?:شكرا على كل حاجه|شكرا جدا|متشكر جدا|ألف شكر|الف شكر)(?: \S+){0,3}$/,"الشكر لله وليك يا باشا. 🌹 أي وقت.||العفو، ده واجبي. 🙌 بالتوفيق في الماتشات.||تسلم، وأنا سعيد إني ساعدت. 😊","You are welcome, anytime! 🌹"]
];
function chat(n){if(window.MR_EXTRA){const x=window.MR_EXTRA.reply(n,A());if(x)return esc(x);}for(const r of CHAT){if(r[0].test(n)){const a=T(r[1],r[2]).split('||');return esc(a[Math.floor(Math.random()*a.length)]);}}return null;}
/* ---------- المحرك الرئيسي ---------- */
async function answer(q){
  const n=norm(q),champs=findChamps(q),lane=findLane(q)||null;
  const has=r=>r.test(n);
  if(!n)return esc(T('اكتب سؤالك.','Type your question.'));
  if(isBad(q)){sj=(sj+1)%SOFT.length;return esc(T(SOFT[sj],'I respect you and will not answer that kind of language. Let us focus on the game and help you win. 🙏'));}
  const CH_=chat(n);if(CH_&&!champs.length)return CH_;
  if(q==='__go_draft'){try{go('draft');}catch(e){}return '';}
  // دردشة
  if(!champs.length){
    if(has(/^(هاي|هلو|اهلا|اهلين|سلام|السلام|مرحبا|صباح|مساء|hello|hi|hey|yo|ازيك|عامل ايه|عامله ايه|ايه الاخبار)/))return esc(T('أهلًا بيك يا بطل! 👾 أنا مساعد Rift Mate. اسألني عن أي بطل أو كاونتر أو بيلد أو إحصائية، أو قولي «حلل الدرافت».','Hey! Ask me about any champion, counter, build, stats, or say "analyze draft".'));
    if(has(/(شكرا|تسلم|متشكر|thanks|thx|جزاك)/))return esc(T('العفو! أي وقت. 🙌','Anytime! 🙌'));
    if(has(/(باي|سلامو عليكم|مع السلامه|bye|تصبح|تصبحوا)/))return esc(T('مع السلامة! بالتوفيق في الرانكد. 🎮','See you! Good luck in ranked. 🎮'));
    if(has(/(انت مين|انتي مين|اسمك|who are you|what are you)/))return esc(T('أنا مساعد محلي جوه التطبيق، بقرأ من داتا الأبطال والمواجهات والبيلدات اللي في التطبيق وبرد من غير نت. مش ذكاء اصطناعي توليدي، فمعلوماتي عن اللعبة بس.','I am a local assistant that reads the data inside this app, offline. I am not a generative AI.'));
    if(has(/(بتعمل ايه|تعمل ايه|تقدر|مساعده|help|ساعدني|ايه اللي تعرفه)/))return T('أقدر أجاوب على: <ul><li>كاونتر أي بطل («مين يكسر ياسو؟»)</li><li>المواجهات («أهري ضد زد»)</li><li>البيلد والرونز والحذاء والقدرات</li><li>الإحصائيات والـ Tier لكل لين</li><li>الانسجام ونقاط الضعف والنصايح</li><li>الآيتمز («قناع الهاوية»)</li><li>«حلل الدرافت» و«ضيف X للخصم»</li><li>ودردشة خفيفة 🙂</li></ul>','I can answer: counters, matchups, builds, runes, abilities, stats, tiers, synergies, weaknesses, tips, items, draft analysis.');
    if(has(/(نكته|نكت|joke|هزار|اضحكني)/)){jk=(jk+1)%JOKES.length;return esc(JOKES[jk]);}
    if(has(/(بحبك|love you|انت جامد|انت حلو|برافو|تمام كده)/))return esc(T('ده من ذوقك! 😄 يلا نكسب الماتش الجاي.','Thanks! 😄 Let us win the next game.'));
    if(has(/(زهقان|ملل|تعبان|زعلان|bored)/))return esc(T('معلش، خد نفس. جرّب بطل جديد النهارده: قولي اللين اللي بتلعبه وأرشحلك حد قوي في الميتا. 😉','Take a breath. Tell me your lane and I will suggest a strong pick.'));
    if(has(/(الساعه كام|اليوم ايه|التاريخ|الطقس|اخبار|سياسه|كوره|اسهم)/))return esc(T('ده برا اللي أعرفه، أنا مساعد أوفلاين وبفهم في Wild Rift بس. اسألني عن الأبطال والكاونترات والبيلدات! 🙂','That is outside my scope: I am an offline assistant that only knows Wild Rift. Ask me about champions, counters and builds! 🙂'));
    if(has(/(حلل|analy|تحليل).*(درافت|draft)|(درافت|draft).*(حلل|analy)|^(حلل|analyze)/))return ansDraft();
    if(has(/(مسح|امسح|clear|reset).*(درافت|draft)/)){draft.ally={};draft.enemy={};try{renderSlots();renderDraftPool();}catch(e){}return esc(T('مسحت الدرافت.','Draft cleared.'));}
    const it=findItem(q);if(it)return ansItem(it);
    if(has(/(احسن|افضل|اقوي|ميتا|tier|تير|best|top)/)||lane)return ansTier(lane||ctx.lane);
    if(has(/(باتش|patch|اصدار|تحديث)/))return esc(T('بيانات التطبيق على Patch '+((DBX.source||{}).patch||'7.3f')+' (آخر تحديث '+((DBX.source||{}).updated||'')+').','Data patch: '+((DBX.source||{}).patch||'')));
    if(ctx.champ&&n.split(' ').length<=4&&has(/(كاونتر|counter|يكسر|بيلد|build|رونز|ضعف|قوه|نصايح|tips|انسجام|synergy|احصائيات|stats|قدرات|الت|ult|\bq\b|\bw\b|\be\b|\br\b)/))champs.push(ctx.champ);
    else return T('مش فاهم سؤالك بالظبط. 🤔 جرّب تذكر اسم بطل مع اللي عايزه، مثلًا: «كاونتر ياسو» أو «بيلد أهري» أو «أقوى ميد». اكتب «مساعدة» عشان تشوف أمثلة.','Not sure what you mean. Try naming a champion, e.g. "counters Yasuo" or "build Ahri". Type "help".');
  }
  // أوامر الدرافت
  if(has(/(ضيف|حط|اضف|add|put|سجل)/)&&(has(/(فريقي|معايا|عندي|ally|my team|لفريقي|ليا)/)||has(/(خصم|عدو|عندهم|enemy|الاعداء|ضدي)/))){
    const side=has(/(خصم|عدو|عندهم|enemy|الاعداء|ضدي)/)?'enemy':'ally';
    const done=addToDraft(champs,side,lane);
    return esc(done.length?T('ضفت '+done.join('، ')+(side==='enemy'?' للخصم.':' لفريقك.'),'Added '+done.join(', ')+'.'):T('مفيش خانات فاضية.','No free slots.'))+'<div class="as-chips">'+chip(T('حلل الدرافت','Analyze draft'),T('حلل الدرافت','analyze draft'))+'</div>';
  }
  const c=champs[0];
  if(champs.length>=2&&has(/(ضد|vs|versus|مقابل|ولا|او|مع|قدام|يكسر)/)&&!has(/(انسجام|synergy|يلعب مع)/))return ansMatchup(champs[0],champs[1],lane);
  if(has(/(انسجام|synergy|يلعب مع|مع مين|تناغم)/))return ansSynergy(c);
  if(has(/(قوي ضد|بيكسر|يكسر مين|strong against|beats|بيغلب|بيتغلب علي مين)/)&&!has(/(مين يكسر|مين بيكسر|who counters)/))return ansStrong(c,lane);
  if(has(/(ضعف|weak|نقاط|يضعف|weaknesses|strength|قوه)/))return ansWeak(c,lane);
  if(has(/(كاونتر|counter|مين يكسر|مين بيكسر|يغلب|مين يهزم|هزم|احسن بطل ضد|ضد ايه|افضل بطل ضد|who counters|beats)/))return ansCounters(c,lane);
  if(has(/(رونز|rune|runes)/))return ansRunes(c);
  if(has(/(بيلد|build|اشتري|ايتمات|items|اشتريه|ايتم)/))return ansBuild(c,lane);
  if(has(/(احصائيات|احصاءات|stats|win ?rate|نسبه الفوز|فوز|بيك|حظر|ban|pick)/))return ansStats(c);
  if(has(/(نصايح|نصيحه|tips|ازاي العب|طريقه لعب|خطه|plan|اتعلم)/))return ansTips(c);
  if(has(/(قدرات|مهارات|skills|abilities|الت|ult|ultimate|سلبيه|passive|\bq\b|\bw\b|\be\b|\br\b)/)){
    let k=null;if(has(/(الت|ult|ultimate|\br\b)/))k='R';else if(has(/\bq\b/))k='Q';else if(has(/\bw\b/))k='W';else if(has(/\be\b/))k='E';else if(has(/(سلبيه|passive)/))k='P';
    return ansAbilities(c,k);
  }
  if(has(/(مين|ايه|يعني|عن|معلومات|اعرف|about|who|what|info)/)||champs.length===1)return ansSummary(c);
  return ansSummary(c);
}
/* ---------- واجهة ---------- */
const css='.as-dots i{font-style:normal;animation:asd 1s infinite}.as-dots i:nth-child(2){animation-delay:.2s}.as-dots i:nth-child(3){animation-delay:.4s}@keyframes asd{0%,100%{opacity:.2}50%{opacity:1}}#asFab{position:fixed;left:14px;bottom:78px;z-index:9998;width:54px;height:54px;border-radius:50%;border:1px solid var(--line,#444);background:linear-gradient(135deg,#6b3df0,#c13dd8);color:#fff;font-size:26px;box-shadow:0 6px 20px rgba(0,0,0,.5);cursor:pointer}'+
'#asPanel{position:fixed;inset:auto 0 0 0;z-index:9999;max-width:560px;margin:0 auto;height:78vh;background:#0e0c16;border:1px solid var(--line,#333);border-radius:18px 18px 0 0;display:none;flex-direction:column;color:#eee;font-size:14px}'+
'#asPanel.open{display:flex}#asHead{display:flex;align-items:center;gap:8px;padding:10px 12px;border-bottom:1px solid var(--line,#333)}#asHead b{flex:1}'+
'#asLog{flex:1;overflow:auto;padding:10px;display:flex;flex-direction:column;gap:8px}.as-m{max-width:92%;padding:8px 11px;border-radius:14px;line-height:1.6;word-break:break-word}.as-u{align-self:flex-start;background:#3a2a6e}.as-b{align-self:flex-end;background:#1c1830;border:1px solid var(--line,#333)}'+
'.as-m ul{margin:4px 0;padding-inline-start:18px}.as-chips{display:flex;flex-wrap:wrap;gap:5px;margin-top:6px}.as-chip{border:1px solid var(--line,#555);background:#17142a;color:#ddd;border-radius:999px;padding:3px 9px;font-size:12px;cursor:pointer}'+
'#asBar{display:flex;gap:6px;padding:8px;border-top:1px solid var(--line,#333)}#asIn{flex:1;min-width:0;padding:9px;border-radius:10px;border:1px solid var(--line,#444);background:#17142a;color:#fff}#asBar button,#asHead button{border:1px solid var(--line,#444);background:#17142a;color:#fff;border-radius:10px;padding:0 10px;min-height:38px;cursor:pointer}'+
'#asCfg{display:none;padding:8px 12px;border-bottom:1px solid var(--line,#333);font-size:12px}#asCfg input{width:100%;margin:3px 0;padding:6px;border-radius:8px;border:1px solid var(--line,#444);background:#17142a;color:#fff}'+
'.rv{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin:6px 0}.rv-col b{font-size:12px}.rv-row{display:grid;grid-template-columns:auto 34px 1fr;gap:4px 6px;align-items:center;margin:4px 0;font-size:11px}.rv-row img{width:34px;height:34px;border-radius:7px}.rv-ph{width:34px;height:34px;border-radius:7px;background:#2a2340;display:flex;align-items:center;justify-content:center}.rv-row select{min-width:0;width:100%;font-size:11px;padding:3px;border-radius:7px;background:#17142a;color:#fff;border:1px solid #444}.rv-row small{grid-column:1/-1}.rv-lane{font-size:10px;color:#a69db8}.rv-alts{grid-column:1/-1;display:flex;gap:4px;flex-wrap:wrap}.rv-alt{font-size:10px;padding:2px 6px;border-radius:9px;border:1px solid #6a5a9a;background:#241d3d;color:#fff}.as-shot{display:flex;flex-wrap:wrap;gap:6px;margin:6px 0}.as-shot div{text-align:center;font-size:11px;width:64px}.as-shot img{width:56px;height:56px;border-radius:8px;display:block;margin:auto}';

/* ---------- صلاحية الصور (أندرويد عبر Capacitor Camera) ---------- */
function nativeCam(){try{const C=window.Capacitor;if(C&&C.isNativePlatform&&C.isNativePlatform()&&C.Plugins&&C.Plugins.Camera)return C.Plugins.Camera;}catch(e){}return null;}
async function askPhotoPermission(){
  const cam=nativeCam();if(!cam||!cam.requestPermissions)return 'web';
  try{if(localStorage.getItem('mra_perm_photos'))return 'asked';}catch(e){}
  try{const r=await cam.requestPermissions({permissions:['photos']});try{localStorage.setItem('mra_perm_photos',JSON.stringify(r||1));}catch(e){}return r&&r.photos||'asked';}catch(e){return 'error';}
}
async function nativePickImage(){
  const cam=nativeCam();if(!cam)return null;
  try{const ph=await cam.getPhoto({source:'PHOTOS',resultType:'dataUrl',quality:100,correctOrientation:true});
    if(!ph||!ph.dataUrl)return null;const im=new Image();await new Promise((ok,no)=>{im.onload=ok;im.onerror=no;im.src=ph.dataUrl;});return im;}catch(e){return null;}
}
let panel,log,inp,shotRes=null,lastImg=null;
function addMsg(html,cls){const d=document.createElement('div');d.className='as-m '+cls;d.innerHTML=html;log.appendChild(d);log.scrollTop=log.scrollHeight;return d;}
async function send(q){
  q=(q||'').trim();if(!q)return;addMsg(esc(maskBad(q)),'as-u');
  const think=addMsg('<span class="as-dots">'+esc(T('بفكر','Thinking'))+' <i>.</i><i>.</i><i>.</i></span>','as-b as-think');
  let h;try{h=await answer(q);}catch(e){h=esc(T('حصل خطأ في المساعد.','Assistant error.'));}
  const wait=Math.min(900,250+String(h).length*2);await new Promise(r=>setTimeout(r,wait));
  think.remove();
  if(h==='')return;addMsg(h,'as-b');log.scrollTop=log.scrollHeight;
}
function buildUI(){
  const st=document.createElement('style');st.textContent=css;document.head.appendChild(st);
  const fab=document.createElement('button');fab.id='asFab';fab.textContent='🤖';fab.setAttribute('aria-label','AI');document.body.appendChild(fab);
  panel=document.createElement('div');panel.id='asPanel';
  panel.innerHTML='<div id="asHead"><b></b><button id="asX">✕</button></div>'+
  '<div id="asLog"></div><div id="asBar"><button id="asCam">📷</button><input id="asIn" type="text" autocomplete="off"><button id="asSend">➤</button></div><input type="file" id="asFile" accept="image/*" style="display:none">';
  document.body.appendChild(panel);log=panel.querySelector('#asLog');inp=panel.querySelector('#asIn');
  const label=()=>{panel.querySelector('#asHead b').textContent=T('🤖 مساعد Rift Mate (أوفلاين بالكامل)','🤖 Rift Mate Assistant (fully offline)');inp.placeholder=T('اسأل عن بطل، كاونتر، بيلد...','Ask about a champion, counter, build...');};
  fab.onclick=()=>{buildIndex();label();panel.classList.toggle('open');if(!log.children.length)addMsg(esc(T('أهلًا! أنا مساعد محلي بيشتغل بدون نت على داتا التطبيق. اسألني عن أي بطل أو كاونتر أو بيلد، أو ارفع لقطة الدرافت بزر 📷.','Hi! I am a local assistant working offline on the app data. Ask me anything about champions, or upload a draft screenshot with 📷.'))+'<div class="as-chips">'+chip(T('أقوى ميد','Top mid'),T('أقوى ميد','best mid'))+chip(T('كاونتر ياسو','Counters Yasuo'),'counters yasuo')+chip(T('حلل الدرافت','Analyze draft'),T('حلل الدرافت','analyze draft'))+'</div>','as-b');};
  panel.querySelector('#asX').onclick=()=>panel.classList.remove('open');
  panel.querySelector('#asSend').onclick=()=>{const v=inp.value;inp.value='';send(v);};
  
  inp.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();panel.querySelector('#asSend').click();}});
  log.addEventListener('click',e=>{const al=e.target.closest('.rv-alt');if(al){const row=al.closest('.rv-row'),c=CH.find(x=>x.id==al.dataset.id);row.querySelector('select').value=al.dataset.id;if(c&&c.image){const im=row.querySelector('img');if(im)im.src=c.image;}return;}
    const rs=e.target.closest('[data-reshot]');if(rs&&lastImg){const bx=rs.closest('.as-review')||rs.closest('.as-b');(async()=>{try{const r=rs.dataset.reshot==='draft'?await recognizeDraft(lastImg,true):await recognizeBoard(lastImg);if(r){shotRes=r;bx.innerHTML=reviewHTML(r);}}catch(er){}})();return;}
    const cf=e.target.closest('[data-confirm]');if(cf){confirmShot(cf.closest('.as-review')||cf.closest('.as-b')||document);return;}
    const b=e.target.closest('.as-chip');if(b&&b.dataset.q)send(b.dataset.q);});
  log.addEventListener('change',e=>{const sel=e.target.closest('.rv-row select');if(!sel)return;const row=sel.closest('.rv-row'),c=CH.find(x=>x.id==sel.value),im=row.querySelector('img');if(im&&c&&c.image)im.src=c.image;});
  // صورة
  const file=panel.querySelector('#asFile');const runShot=async im=>{const d=addMsg(esc(T('بقرا اللقطة... ممكن ياخد كام ثانية.','Reading screenshot...')),'as-b');try{lastImg=im;const r=await recognize(im);shotRes=r;d.innerHTML=reviewHTML(r);d.classList.add('as-review');}catch(e){d.innerHTML=esc(T('تعذر قراءة الصورة ('+(e&&e.message||e)+').','Could not read image.'));}};
  panel.querySelector('#asCam').onclick=async()=>{if(nativeCam()){await askPhotoPermission();const im=await nativePickImage();if(im){runShot(im);return;}}file.click();};
  file.onchange=async()=>{const f=file.files[0];file.value='';if(!f)return;const d=addMsg(esc(T('بقرا اللقطة... ممكن ياخد كام ثانية.','Reading screenshot...')),'as-b');
    try{const url=URL.createObjectURL(f),im=new Image();await new Promise((ok,no)=>{im.onload=ok;im.onerror=no;im.src=url;});lastImg=im;const r=await recognize(im);shotRes=r;
      d.innerHTML=reviewHTML(r);d.classList.add('as-review');
    }catch(e){d.innerHTML=esc(T('تعذر قراءة الصورة ('+(e&&e.message||e)+').','Could not read image.'));}};
}
function layoutShot(res){
  if(res&&res.board){const a=[null,null,null,null,null],e=[null,null,null,null,null];res.items.forEach(i=>{(i.side?e:a)[i.row]=i;});return{ally:a,enemy:e};}
  const its=((res&&res.items)||[]).slice(),xs=its.map(i=>i.x).sort((a,b)=>a-b);
  let split=null,bg=0;if(its.length>1){for(let i=1;i<xs.length;i++){const g=xs[i]-xs[i-1];if(g>bg){bg=g;split=(xs[i]+xs[i-1])/2;}}}
  if(split!=null&&bg<(res.W||1000)*0.15)split=null;
  const ys=its.map(i=>i.y).sort((a,b)=>a-b);let pitch=0;
  if(ys.length>1){const gaps=[];for(let i=1;i<ys.length;i++)if(ys[i]-ys[i-1]>(its[0].S||30)*0.6)gaps.push(ys[i]-ys[i-1]);pitch=gaps.length?Math.min(...gaps):0;
    // pitch الحقيقي هو أصغر فرق مقسوم على عدد الصفوف التقريبي
    if(pitch&&gaps.length){const base=pitch;pitch=base;}}
  const y0=ys[0]||0,span=ys.length?ys[ys.length-1]-y0:0,full=pitch&&Math.round(span/pitch)>=4;
  const rowOf=it=>pitch?Math.min(4,Math.max(0,full?Math.round((it.y-y0)/pitch):Math.round(2+(it.y-(res.H||0)/2)/pitch))):0;
  const arr=side=>{const a=[null,null,null,null,null];side.sort((x,y)=>y.score-x.score).forEach(it=>{let r=rowOf(it);if(a[r]){let k=r;while(k<5&&a[k])k++;if(k>4){k=r;while(k>=0&&a[k])k--;}r=k;}if(r>=0&&r<5)a[r]=it;});return a;};
  return{ally:arr(its.filter(i=>split==null||i.x<=split)),enemy:arr(its.filter(i=>split!=null&&i.x>split))};
}
function reviewHTML(res){
  const lay=layoutShot(res);const opts=CH.slice().sort((a,b)=>sn(a).localeCompare(sn(b),A()?'ar':'en')).map(c=>'<option value="'+c.id+'">'+esc(sn(c))+'</option>').join('');
  const col=(side,arr,title)=>'<div class="rv-col"><b>'+esc(title)+'</b>'+arr.map((it,i)=>{
    const sure=it&&it.score>=0.9&&it.margin>=0.05;const alts=it&&it.alts?it.alts.filter(a=>a.c.id!==it.c.id).slice(0,3):[];
    return '<div class="rv-row" data-side="'+side+'" data-i="'+i+'"><span class="rv-lane">'+esc(roleAr&&A()?(roleAr[LANES[i]]||LANES[i]):LANES[i])+'</span>'+
      (it?'<img src="'+esc(it.c.image||'')+'" alt="">':'<span class="rv-ph">؟</span>')+
      '<select>'+'<option value="">'+esc(T('— فاضي —','— empty —'))+'</option>'+opts.replace('value="'+(it?it.c.id:'')+'"','value="'+(it?it.c.id:'')+'" selected')+'</select>'+
      '<small>'+(it?(sure?'✅ ':'⚠️ '+esc(T('راجع','check'))+' ')+Math.round(it.score*100)+'%':(res.draft&&res.empty&&res.empty.some(e=>e.side===(side==='enemy'?1:0)&&e.row===i)?'⬜ '+esc(T('خانة فاضية (لسه ما اتختارش). اختار بإيدك لو عايز','empty slot (not picked yet). Choose manually if needed')):'⚠️ '+esc(T('مش متعرف عليه، اختار بإيدك','not detected, choose manually'))))+'</small>'+
      (alts.length&&!sure?'<div class="rv-alts">'+alts.map(a=>'<button class="rv-alt" data-id="'+a.c.id+'">'+esc(sn(a.c))+'</button>').join('')+'</div>':'')+'</div>';}).join('')+'</div>';
  return '<b>'+esc(T('راجع اللي اتعرف عليه قبل التحليل. ممكن يغلط، صحّح أي بطل من القايمة:','Review what was detected before analysis. It can be wrong, fix any champion:'))+'</b>'+
    '<div class="rv">'+col('ally',lay.ally,T('فريقك (الشمال)','Your team (left)'))+col('enemy',lay.enemy,T('الخصم (اليمين)','Enemy (right)'))+'</div>'+
    '<div class="as-chips"><button class="as-chip" data-confirm="1">'+esc(T('✔ تأكيد ووضعهم في الدرافت','✔ Confirm and fill draft'))+'</button></div>'+
    (res.draft?'<small>'+esc(T('دي شاشة اختيار أبطال: الصفوف بترتيب الاختيار مش بالمسار، فحط كل بطل في مساره الصح من القايمة. البانات اختارها من تبويب الدرافت. القراءة هنا تقديرية ومش مقاسة على لقطات كتير.','Draft screen: rows follow pick order, not lanes, so set each champion to its real lane. Pick bans in the Draft tab. This reading is an estimate and not measured on many screenshots.'))+'</small><br>':'')+'<div class="as-chips"><button class="as-chip" data-reshot="'+(res.draft?'board':'draft')+'">'+esc(res.draft?T('دي شاشة نهاية ماتش','This is an end-of-match screen'):T('دي شاشة اختيار أبطال (درافت)','This is a champion-select (draft) screen'))+'</button></div>'+'<small>'+esc(T('الترتيب من فوق لتحت = Baron, Jungle, Mid, Dragon, Support. مفيش ضمان إن التعرف دايمًا صح.','Top to bottom = Baron, Jungle, Mid, Dragon, Support. Recognition is not guaranteed to be correct.'))+'</small>';
}
function confirmShot(box){
  draft.ally={};draft.enemy={};
  box.querySelectorAll('.rv-row').forEach(r=>{const v=r.querySelector('select').value;if(v)draft[r.dataset.side][LANES[+r.dataset.i]]=+v;});
  try{renderSlots();renderDraftPool();go('draft');}catch(e){}
  addMsg(esc(T('اتحطوا في الدرافت. دوس «تحليل الدرافت» لما تتأكد.','Placed in the draft. Press Analyze when ready.')),'as-b');
}
function fillFromShot(){}
/* ---------- التعرف على الصور (مطابقة قوالب متعددة القياسات + تدقيق محلي) ---------- */
const FS=14,MARG=[0.04,0.12,0.2];let TPL=null,TC=null;
function feat(src,sx,sy,sw,sh,cv,F){F=F||FS;const x=cv.getContext('2d',{willReadFrequently:true});x.clearRect(0,0,F,F);x.drawImage(src,sx,sy,sw,sh,0,0,F,F);const d=x.getImageData(0,0,F,F).data,v=new Float32Array(F*F*3);let m=0,k=0;for(let i=0;i<d.length;i+=4){v[k++]=d[i];v[k++]=d[i+1];v[k++]=d[i+2];}
  for(let i=0;i<v.length;i++)m+=v[i];m/=v.length;let n=0;for(let i=0;i<v.length;i++){v[i]-=m;n+=v[i]*v[i];}n=Math.sqrt(n);if(n<(F<FS?15:25))return null;for(let i=0;i<v.length;i++)v[i]/=n;return v;}
async function templates(){
  if(TPL)return TPL;buildIndex();TPL=[];TC=[];const cv=document.createElement('canvas');cv.width=cv.height=FS;
  await Promise.all(CH.map(c=>new Promise(res=>{if(!c.image)return res();const im=new Image();im.onload=()=>{try{const w=im.naturalWidth,h=im.naturalHeight;MARG.forEach(m=>{const v=feat(im,w*m,h*m,w*(1-2*m),h*(1-2*m),cv);if(v)TPL.push({c,v});});{const m=0.12,v=feat(im,w*m,h*m,w*(1-2*m),h*(1-2*m),cv,8);if(v)TC.push({c,v});}}catch(e){}res();};im.onerror=()=>res();im.src=c.image;})));
  return TPL;
}
function best2(v,tp){let b=-1,bi=-1,sb=-1,sc=null;for(let i=0;i<tp.length;i++){const t=tp[i].v;let s=0;for(let k=0;k<v.length;k++)s+=v[k]*t[k];if(s>b){if(bi>=0&&tp[bi].c.id!==tp[i].c.id){sb=b;}b=s;bi=i;}else if(s>sb&&tp[i].c.id!==tp[bi].c.id)sb=s;}return{s:b,i:bi,s2:sb};}

/* ---------- شاشة نهاية الماتش: شبكة ثابتة 5 صفوف × عمودين + قناع دائري (الثلثان العلويان لتفادي شارة المستوى) ---------- */
const BN=40,BTOP=0.66;let BT=null;
function bfeat(cv){const x=cv.getContext('2d',{willReadFrequently:true}),d=x.getImageData(0,0,BN,BN).data,c=(BN-1)/2,R=BN*0.44,idx=[];for(let y=0;y<BN*BTOP;y++)for(let xx=0;xx<BN;xx++){if((y-c)*(y-c)+(xx-c)*(xx-c)<=R*R)idx.push((y*BN+xx)*4);}
  const v=new Float32Array(idx.length*3);let m=[0,0,0];idx.forEach((p,i)=>{for(let k=0;k<3;k++){v[i*3+k]=d[p+k];m[k]+=d[p+k];}});m=m.map(a=>a/idx.length);let n=0;idx.forEach((p,i)=>{for(let k=0;k<3;k++){v[i*3+k]-=m[k];n+=v[i*3+k]*v[i*3+k];}});n=Math.sqrt(n)||1;for(let i=0;i<v.length;i++)v[i]/=n;return v;}
async function boardTemplates(){if(BT)return BT;BT=[];const cv=document.createElement('canvas');cv.width=cv.height=BN;const g=cv.getContext('2d',{willReadFrequently:true});
  await Promise.all(CH.map(c=>new Promise(res=>{if(!c.image)return res();const im=new Image();im.onload=()=>{try{g.clearRect(0,0,BN,BN);g.drawImage(im,0,0,BN,BN);BT.push({c,v:bfeat(cv)});}catch(e){}res();};im.onerror=()=>res();im.src=c.image;})));
  const nmn=x=>String(x).toLowerCase().replace(/[^a-z]/g,'');await Promise.all((window.SHOT_REFS||[]).map(r=>new Promise(res=>{const c=CH.find(z=>nmn(z.name)===nmn(r[0]));if(!c)return res();const im=new Image();im.onload=()=>{try{g.clearRect(0,0,BN,BN);g.drawImage(im,0,0,BN,BN);BT.push({c,v:bfeat(cv)});}catch(e){}res();};im.onerror=()=>res();im.src='data:image/jpeg;base64,'+r[1];})));return BT;}
const BCOL=[227/1598,909/1598],BROW=[168/719,264/719,360/719,456/719,552/719];
async function recognizeBoard(img){
  const iw=img.naturalWidth||img.width,ih=img.naturalHeight||img.height;if(!iw||!ih||iw/ih<1.9||iw/ih>2.6)return null;
  const tp=await boardTemplates();if(tp.length<100)return null;
  const big=document.createElement('canvas');big.width=iw;big.height=ih;big.getContext('2d',{willReadFrequently:true}).drawImage(img,0,0);
  const cv=document.createElement('canvas');cv.width=cv.height=BN;const g=cv.getContext('2d',{willReadFrequently:true});const s=ih/719;
  const items=[];
  for(let side=0;side<2;side++)for(let row=0;row<5;row++){const cx=BCOL[side]*iw,cy=BROW[row]*ih;let best=null;
    for(let dx=-4;dx<=4;dx+=2)for(let dy=-4;dy<=4;dy+=2)for(const rr of[30,33,36]){const r=rr*s,x0=cx+dx*s-r,y0=cy+dy*s-r;if(x0<0||y0<0||x0+2*r>iw||y0+2*r>ih)continue;
      g.clearRect(0,0,BN,BN);g.drawImage(big,x0,y0,2*r,2*r,0,0,BN,BN);const v=bfeat(cv);let b=-1,bi=-1;const all=[];
      for(let i=0;i<tp.length;i++){const t=tp[i].v;let q=0;for(let k=0;k<v.length;k++)q+=v[k]*t[k];all.push(q);if(q>b){b=q;bi=i;}}
      if(!best||b>best.b)best={b,bi,all};}
    if(!best)continue;const order=best.all.map((q,i)=>[q,i]).sort((a,b)=>b[0]-a[0]);const sec=order[1][0];
    items.push({c:tp[best.bi].c,score:best.b,margin:best.b-sec,x:cx,y:cy,S:66*s,side,row,alts:order.slice(0,4).map(a=>({c:tp[a[1]].c,q:a[0]}))});}
  if(items.length<10)return null;const mean=items.reduce((a,b)=>a+b.score,0)/10;
  if(mean<0.8)return null;
  return{items,W:iw,H:ih,board:true,mean};
}
/* ---------- شاشة اختيار الأبطال (الدرافت): إحداثيات ثابتة + كاشف الخانات الفاضية. مقاسة على لقطة واحدة فقط ---------- */
const DXL=[141,141,141,125,103],DXR=[1178,1178,1178,1178,1178],DYL=[103,184,262,338,413],DYR=[108,185,262,338,413];
function draftEmpty(big,cx,cy,r){const g=big.getContext('2d',{willReadFrequently:true}),R=Math.round(r*0.66);if(cx-R<0||cy-R<0)return false;const d=g.getImageData(Math.round(cx-R),Math.round(cy-R),2*R,2*R).data;let m=0,n=0,q=0;for(let i=0;i<d.length;i+=4){const l=(d[i]*0.299+d[i+1]*0.587+d[i+2]*0.114)/255;m+=l;q+=l*l;n++;}m/=n;const sd=Math.sqrt(Math.max(0,q/n-m*m));return m<0.17&&sd<0.12;}
async function recognizeDraft(img,force){
  const iw=img.naturalWidth||img.width,ih=img.naturalHeight||img.height;if(!iw||!ih||(!force&&(iw/ih<1.9||iw/ih>2.6)))return null;
  const tp=await boardTemplates();if(tp.length<100)return null;
  const big=document.createElement('canvas');big.width=iw;big.height=ih;big.getContext('2d',{willReadFrequently:true}).drawImage(img,0,0);
  const cv=document.createElement('canvas');cv.width=cv.height=BN;const g=cv.getContext('2d',{willReadFrequently:true});const s=ih/576;
  const items=[],empty=[];
  for(let side=0;side<2;side++)for(let row=0;row<5;row++){const cy=(side?DYR:DYL)[row]/576*ih;const cxs=(side?[DXR[row]]:[141,125,103]).map(x=>x/1280*iw);
    if(cxs.every(cx=>draftEmpty(big,cx,cy,33*s))){empty.push({side,row});continue;}
    let best=null,bcx=cxs[0];
    for(const cx of cxs)for(let dx=-6;dx<=6;dx+=3)for(let dy=-6;dy<=6;dy+=3)for(const rr of[30,33,36]){const r=rr*s,x0=cx+dx*s-r,y0=cy+dy*s-r;if(x0<0||y0<0||x0+2*r>iw||y0+2*r>ih)continue;
      g.clearRect(0,0,BN,BN);g.drawImage(big,x0,y0,2*r,2*r,0,0,BN,BN);const v=bfeat(cv);let b=-1,bi=-1;const all=[];
      for(let i=0;i<tp.length;i++){const t=tp[i].v;let q=0;for(let k=0;k<v.length;k++)q+=v[k]*t[k];all.push(q);if(q>b){b=q;bi=i;}}
      if(!best||b>best.b){best={b,bi,all};bcx=cx;}}
    if(!best)continue;const order=best.all.map((q,i)=>[q,i]).sort((a,b)=>b[0]-a[0]);
    items.push({c:tp[best.bi].c,score:best.b,margin:best.b-order[1][0],x:bcx,y:cy,S:66*s,side,row,alts:order.slice(0,4).map(a=>({c:tp[a[1]].c,q:a[0]}))});}
  const mean=items.length?items.reduce((a,b)=>a+b.score,0)/items.length:0;
  return{items,empty,W:iw,H:ih,board:true,draft:true,mean};
}
async function recognize(img,opts){if(opts&&opts.mode==='draft')return await recognizeDraft(img,true);if(!(opts&&opts.noboard)){try{const bd=await recognizeBoard(img);const dd=await recognizeDraft(img,false);if(dd&&dd.items.length>=3&&dd.mean>=0.65&&(!bd||dd.mean>bd.mean+0.1))return dd;if(bd)return bd;}catch(e){}}const thr=(opts&&opts.thr)||THR;
  const tp=await templates();if(!tp.length)throw new Error('templates');
  const iw=img.naturalWidth||img.width,ih=img.naturalHeight||img.height,sc=Math.min(1,1400/Math.max(iw,ih)),W=Math.round(iw*sc),H=Math.round(ih*sc);
  const big=document.createElement('canvas');big.width=W;big.height=H;big.getContext('2d',{willReadFrequently:true}).drawImage(img,0,0,W,H);
  const cv=document.createElement('canvas');cv.width=cv.height=FS;let cand=[];const mn=Math.min(W,H);
  const sizes=[];for(let r=0.05;r<=0.24;r*=1.22)sizes.push(Math.round(mn*r));
  const at=(x,y,S)=>{const m=Math.round(S*0.1);if(x<0||y<0||x+S>W||y+S>H)return null;const v=feat(big,x+m,y+m,S-2*m,S-2*m,cv);if(!v)return null;return best2(v,tp);};
  const cv8=document.createElement('canvas');cv8.width=cv8.height=8;
  for(const S of sizes){const step=Math.max(3,Math.round(S/4));
    for(let y=0;y+S<=H;y+=step){for(let x=0;x+S<=W;x+=step){const m=Math.round(S*0.1),v=feat(big,x+m,y+m,S-2*m,S-2*m,cv8,8);if(!v)continue;let b=-1,bi=-1,top=[];for(let i=0;i<TC.length;i++){const t=TC[i].v;let q=0;for(let k=0;k<v.length;k++)q+=v[k]*t[k];if(q>b){b=q;bi=i;}if(q>thr-0.3)top.push([q,i]);}
      if(b>=thr-0.2){top.sort((a,b)=>b[0]-a[0]);cand.push({c:TC[bi].c,ids:top.slice(0,4).map(a=>TC[a[1]].c.id),score:b,x,y,S});}}}
    await new Promise(r=>setTimeout(r,0));}
  cand.sort((a,b)=>b.score-a.score);
  // دمج المرشحين المتقاربين ثم تدقيق محلي حوالين كل واحد
  const seeds=[];for(const k of cand){if(seeds.length>=200)break;if(seeds.some(o=>Math.hypot(o.x+o.S/2-k.x-k.S/2,o.y+o.S/2-k.y-k.S/2)<Math.min(o.S,k.S)*0.35))continue;seeds.push(k);}
  const byC={};tp.forEach(t=>{(byC[t.c.id]=byC[t.c.id]||[]).push(t);});
  const scoreC=(x,y,S,ids)=>{const m=Math.round(S*0.1);if(x<0||y<0||x+S>W||y+S>H)return -1;const v=feat(big,x+m,y+m,S-2*m,S-2*m,cv);if(!v)return -1;let b=-1;for(const id of ids)for(const t of byC[id]){let q=0;for(let k=0;k<v.length;k++)q+=v[k]*t.v[k];if(q>b)b=q;}return b;};
  const refined=[],minS=mn*0.045;
  for(const k of seeds){let b={x:k.x,y:k.y,S:k.S,score:scoreC(k.x,k.y,k.S,k.ids)};const d0=Math.round(k.S*0.25),st=Math.max(2,Math.round(k.S/10));
    for(const f of[0.8,0.9,1,1.1,1.25]){const S=Math.round(k.S*f);if(S<minS)continue;for(let dy=-d0;dy<=d0;dy+=st)for(let dx=-d0;dx<=d0;dx+=st){const q=scoreC(k.x+dx,k.y+dy,S,k.ids);if(q>b.score)b={x:k.x+dx,y:k.y+dy,S,score:q};}}
    if(b.score<thr-0.05)continue;const rr=at(b.x,b.y,b.S);if(!rr||rr.s<thr)continue;refined.push({c:tp[rr.i].c,score:rr.s,x:b.x+b.S/2,y:b.y+b.S/2,S:b.S,margin:rr.s-rr.s2});}
  // اختيار: الأعلى سكورًا أولًا، مع تفضيل النافذة الأكبر عند تقارب السكور (البورتريه الكامل مش جزء منه)
  refined.sort((a,b)=>(b.score+0.02*Math.log(b.S))-(a.score+0.02*Math.log(a.S)));const out=[];
  for(const k of refined){if(out.length>=10)break;if(out.some(o=>o.c.id===k.c.id))continue;if(out.some(o=>Math.hypot(o.x-k.x,o.y-k.y)<Math.max(o.S,k.S)*0.6))continue;out.push(k);}
  const topK=(it)=>{const m=Math.round(it.S*0.1),x0=Math.round(it.x-it.S/2),y0=Math.round(it.y-it.S/2);const v=(x0<0||y0<0||x0+it.S>W||y0+it.S>H)?null:feat(big,x0+m,y0+m,it.S-2*m,it.S-2*m,cv);if(!v)return[];const bc={};for(const t of tp){let q=0;for(let k=0;k<v.length;k++)q+=v[k]*t.v[k];if(!(t.c.id in bc)||q>bc[t.c.id].q)bc[t.c.id]={c:t.c,q};}return Object.values(bc).sort((a,b)=>b.q-a.q).slice(0,4);};
  out.forEach(o=>{o.alts=topK(o);});
  const strong=out.filter(o=>o.score>=0.86).map(o=>o.S).sort((a,b)=>a-b);
  if(strong.length>=2){const med=strong[strong.length>>1];for(let i=out.length-1;i>=0;i--)if(out[i].S<med*0.7||out[i].S>med*1.5)out.splice(i,1);}
  return{items:out,W,H};
}
const THR=0.74;
/* ---------- تحليل كاونتر أعمق ---------- */
function deepCounter(){
  try{
    const sel=document.getElementById('counterA'),res=document.getElementById('counterResult');if(!sel||!res)return;
    const a=CH.find(c=>c.id===+sel.value);if(!a)return;
    const old=document.getElementById('deepCounter');if(old)old.remove();
    const lane=(document.getElementById('counterLane')||{}).value||a.lane,cl=counterList(a,lane),g=G(a);
    const sevN=x=>x.s>=3?3:2;
    const rows=cl.counters.map(x=>{
      const y=x.c,wr=y.stats&&y.stats.winRate!=null?y.stats.winRate:null;
      let sc=40+sevN(x)*12+tierOrder(ct(y,cl.lane))*3+(wr!=null?Math.max(-6,Math.min(8,(wr-50)*2)):0);
      const rec=(DBX.matchups||[]).filter(m=>m.lane===cl.lane&&((m.champion===a.name&&m.opponent===y.name)||(m.champion===y.name&&m.opponent===a.name)));
      const gy=G(y);const vs=(gy.builds||[]).find(b=>new RegExp(a.damage==='AP'?'AP':'AD','i').test(b.name||'')&&/vs/i.test(b.name||''));
      return{y,sc:Math.round(Math.min(99,sc)),wr,vs,sev:x.s,rec};
    }).sort((p,q)=>q.sc-p.sc).slice(0,8);
    let o='<div id="deepCounter" class="notice" style="margin-top:12px"><h3>'+esc(T('تحليل الكاونتر المتقدم لـ ','Advanced counter analysis for ')+sn(a)+' · '+lname(cl.lane))+'</h3>';
    if(g.powerCurve){const pc=g.powerCurve,mx=Math.max(pc.early,pc.mid,pc.late),ph=pc.early===mx?T('البداية','early game'):pc.mid===mx?T('منتصف اللعبة','mid game'):T('المتأخر','late game');
      o+='<p>'+esc(T('أقوى مرحلة له (تقدير): '+ph+'. اضغط عليه في المراحل الأضعف: ','Strongest phase (est.): '+ph+'. Pressure him in weaker phases: '))+esc(T('بداية '+pc.early+' · وسط '+pc.mid+' · متأخر '+pc.late,'early '+pc.early+' · mid '+pc.mid+' · late '+pc.late))+'</p>';}
    if(rows.length){o+='<b>'+esc(T('أفضل Counterpicks مرتبة بنقاط (واحدة تجمع شدة الكاونتر + Tier + نسبة الفوز):','Best counterpicks ranked (severity + tier + winrate):'))+'</b>';
      o+=li(rows.map(r=>'<b>'+esc(sn(r.y))+'</b> · '+r.sc+'/100 <small>('+esc(r.sev>=3?T('كاونتر قوي','hard counter'):T('مواجهة صعبة عليه','tough for him'))+' · Tier '+esc(ct(r.y,cl.lane))+(r.wr!=null?' · '+r.wr+'%':'')+')</small>'+(r.vs?'<br><small>'+esc(T('بيلد مقترح ضده: ','Build vs him: '))+r.vs.items.map(itemN).join(' ← ')+'</small>':'')));}
    else o+='<p>'+esc(T('مفيش كاونترات موثقة. '+NOREC+'.','No documented counters.'))+'</p>';
    if(cl.strong.length)o+='<p><b>'+esc(T('تحذير: ماتختارهوش ضد ','Avoid picking into: '))+'</b>'+cl.strong.slice(0,6).map(x=>esc(sn(x.c))).join('، ')+'</p>';
    o+='<div id="deepWeak"><small>'+esc(T('بحمّل نقاط ضعفه...','loading weaknesses...'))+'</small></div></div>';
    res.insertAdjacentHTML('beforeend',o);
    loadDetail(a).then(d=>{const el=document.getElementById('deepWeak');if(!el)return;const v=d&&d.variants&&(d.variants.find(x=>x.lane===cl.lane)||d.variants[0]);
      el.innerHTML=(v&&v.weak&&v.weak.length)?'<b>'+esc(T('اضرب فين؟ بيضعف لما:','Exploit when he is weak:'))+'</b>'+li(v.weak.map(w=>esc(tr(w)))):'<small>'+esc(T(NOREC,'No documented data'))+'</small>';});
  }catch(e){}
}
function init(){
  if(!document.body||typeof CHAMPS==='undefined'){setTimeout(init,300);return;}
  buildIndex();buildUI();
  const go_=document.getElementById('counterGo');if(go_)go_.addEventListener('click',()=>setTimeout(deepCounter,50));
  const sel=document.getElementById('counterA');if(sel)sel.addEventListener('change',()=>setTimeout(()=>{if(document.querySelector('#counterResult .row'))deepCounter();},80));
  setTimeout(()=>{askPhotoPermission().catch(()=>{});},1200);
  window.MR_ASSIST={askPhotoPermission,nativePickImage,reviewHTML,layoutShot,confirmShot,answer,findChamps,findLane,recognize,fillFromShot,deepCounter,_norm:norm};
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();
