// Minimal development API for Diesel Market. Not production-ready: add authentication,
// validation, rate limits, secure image storage, and database migrations before deployment.
const http=require('http'),fs=require('fs'),path=require('path');
const PORT=process.env.PORT||8787,DATA=path.join(__dirname,'ads.json');
function read(){try{return JSON.parse(fs.readFileSync(DATA,'utf8'))}catch{return []}}
function send(res,status,data){res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Access-Control-Allow-Origin':'*','Access-Control-Allow-Methods':'GET,POST,DELETE,OPTIONS','Access-Control-Allow-Headers':'Content-Type'});res.end(JSON.stringify(data))}
const server=http.createServer((req,res)=>{if(req.method==='OPTIONS'){send(res,204,{});return}const url=new URL(req.url,`http://${req.headers.host||'localhost'}`);
 if(url.pathname==='/health'&&req.method==='GET')return send(res,200,{ok:true,name:'Diesel Market API'});
 if(url.pathname==='/ads'&&req.method==='GET')return send(res,200,read());
 if(url.pathname==='/ads'&&req.method==='POST'){let body='';req.on('data',chunk=>{body+=chunk;if(body.length>8*1024*1024){req.destroy()}});req.on('end',()=>{try{const ad=JSON.parse(body);if(!ad.title||!ad.category||!ad.location)return send(res,400,{error:'title, category and location required'});ad.id=String(Date.now());ad.createdAt=new Date().toISOString();const ads=read();ads.unshift(ad);fs.writeFileSync(DATA,JSON.stringify(ads,null,2));send(res,201,ad)}catch(e){send(res,400,{error:'invalid JSON'})}});return}
 if(url.pathname.startsWith('/ads/')&&req.method==='DELETE'){const id=decodeURIComponent(url.pathname.slice(5));const ads=read().filter(a=>a.id!==id);fs.writeFileSync(DATA,JSON.stringify(ads,null,2));return send(res,200,{deleted:true})}
 send(res,404,{error:'not found'});
});server.listen(PORT,'0.0.0.0',()=>console.log(`Diesel Market API listening on ${PORT}`));
