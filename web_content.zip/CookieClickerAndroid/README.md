# Cookie Clicker Android

A simple offline cookie-clicking game packaged in a native Android WebView shell.

## Build an APK

1. Install **Android Studio** on a computer.
2. Extract this ZIP.
3. In Android Studio, choose **Open** and select the `CookieClickerAndroid` folder.
4. Let Gradle sync. If prompted, install Android SDK Platform 35 and use JDK 17.
5. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. When the build finishes, choose **Locate**. The APK is usually at `app/build/outputs/apk/debug/app-debug.apk`.

To install it on your Android device, transfer the APK to the device and open it. Android may ask you to allow installation from that source.

## Features

- Tap the large cookie to earn cookies.
- Buy cursors, grandmas, farms, bakeries, and factories.
- Upgrades automatically generate cookies over time.
- Progress saves locally on the device.
- Works offline; no internet permission is requested.

## Notes

This is the Android Studio source project, not a prebuilt or signed APK. The debug APK is suitable for testing. For publishing, create a signed release build in Android Studio.
