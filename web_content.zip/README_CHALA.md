# CHALA GENERAL TRADING PLC — Android Application

A branded Android application for coffee sourcing, cup quality, contracts, inventory, buyers, shipments, finance and company document generation.

## App name
Chala General Trading PLC

## Package
com.coffeetrade.erp

## Build
Open this folder in Android Studio, allow Gradle synchronization, then use:
Build > Generate App Bundles or APKs > Generate APKs.

The signed release configuration is retained from the supplied project.
