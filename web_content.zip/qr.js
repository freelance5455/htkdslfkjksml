/* Offline QR Code encoder: version 1, error correction L, fixed mask 0.
   Supports inventory identifiers of up to 17 UTF-8 bytes (e.g. ENV-000001).
   No network, external assets or analytics. */
(function(){
'use strict';
function gfMul(a,b){let p=0;for(let i=0;i<8;i++){if(b&1)p^=a;const hi=a&128;a=(a<<1)&255;if(hi)a^=0x1d;b>>=1;}return p;}
function rsEncode(data){let gen=[1],alpha=1;for(let i=0;i<7;i++){const next=new Array(gen.length+1).fill(0);for(let j=0;j<gen.length;j++){next[j]^=gen[j];next[j+1]^=gfMul(gen[j],alpha);}gen=next;alpha=gfMul(alpha,2);}const rem=new Array(7).fill(0);for(const b of data){const f=b^rem.shift();rem.push(0);for(let i=0;i<7;i++)rem[i]^=gfMul(gen[i+1],f);}return rem;}
function encode(value){const bytes=new TextEncoder().encode(String(value));if(bytes.length>17||bytes.length===0)throw Error('QR kod için 1–17 bayt gereklidir');
const bits=[];const put=(val,count)=>{for(let i=count-1;i>=0;i--)bits.push((val>>>i)&1);};put(4,4);put(bytes.length,8);for(const b of bytes)put(b,8);const limit=19*8;put(0,Math.min(4,limit-bits.length));while(bits.length%8)bits.push(0);const data=[];for(let i=0;i<bits.length;i+=8){let v=0;for(let j=0;j<8;j++)v=(v<<1)|bits[i+j];data.push(v);}while(data.length<19)data.push(data.length%2===0?0xec:0x11);const all=data.concat(rsEncode(data));
const n=21,m=Array.from({length:n},()=>Array(n).fill(null));function set(x,y,val){if(x>=0&&y>=0&&x<n&&y<n)m[y][x]=Boolean(val);}
function finder(x,y){for(let dy=-1;dy<=7;dy++)for(let dx=-1;dx<=7;dx++){const xx=x+dx,yy=y+dy;if(xx<0||yy<0||xx>=n||yy>=n)continue;const edge=dx===-1||dx===7||dy===-1||dy===7,ring=dx===0||dx===6||dy===0||dy===6,core=dx>=2&&dx<=4&&dy>=2&&dy<=4;set(xx,yy,!edge&&(ring||core));}}
finder(0,0);finder(14,0);finder(0,14);
for(let i=8;i<=12;i++){set(i,6,i%2===0);set(6,i,i%2===0);}
// Reserve the modules occupied by the two redundant format strings.
for(let i=0;i<9;i++){if(m[8][i]===null)set(i,8,false);if(m[i][8]===null)set(8,i,false);}
for(let i=13;i<21;i++){set(i,8,false);set(8,i,false);}set(8,13,true);
let at=0;for(let right=20;right>=1;right-=2){if(right===6)right=5;const upward=((right+1)&2)===0;for(let i=0;i<21;i++){const y=upward?20-i:i;for(let k=0;k<2;k++){const x=right-k;if(m[y][x]!==null)continue;let b=0;if(at<all.length*8)b=(all[at>>>3]>>>(7-(at&7)))&1;at++;set(x,y,b^(((x+y)&1)===0?1:0));}}}
// L format 01, mask 000. BCH polynomial 0x537, inverted with 0x5412.
const payload=8;let bch=payload;for(let i=0;i<10;i++)bch=(bch<<1)^(((bch>>>9)&1)?0x537:0);const format=((payload<<10)|bch)^0x5412;
const bit=i=>((format>>>i)&1)!==0;
for(let i=0;i<=5;i++)set(8,i,bit(i));set(8,7,bit(6));set(8,8,bit(7));set(7,8,bit(8));for(let i=9;i<=14;i++)set(14-i,8,bit(i));
for(let i=0;i<=7;i++)set(20-i,8,bit(i));for(let i=8;i<=14;i++)set(8,21-15+i,bit(i));set(8,13,true);
return m;
}
function svg(text,pixel=232){const m=encode(text),modules=29,size=Math.max(100,Number(pixel)||232),scale=size/modules;let paths=[];for(let y=0;y<21;y++)for(let x=0;x<21;x++)if(m[y][x])paths.push('M'+(x+4)+' '+(y+4)+'h1v1h-1z');return `<svg class="qr-symbol" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${modules} ${modules}" width="${size}" height="${size}" shape-rendering="crispEdges" role="img" aria-label="QR: ${String(text).replace(/[&<>\"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','\"':'&quot;'}[c]))}"><rect width="29" height="29" fill="white"/><path d="${paths.join('')}" fill="#061b2e"/></svg>`;}
window.KENV_QR={encode,svg};
})();
