/* JOSTECH — MANUEL 10 : ANGLAIS INFORMATIQUE NIVEAU 2 */
registerLessonDetail(10, 2, "eng-2-1-1", {
  title: "Leçon 1 : Reading Official Documentation & Error Messages",
  duration: "40 min (Manuel complet)",
  objectives: [
    "Décoder instantanément les messages d'erreur et Stack Traces en anglais.",
    "Naviguer dans une documentation officielle (Syntax, Parameters, Return value, Deprecated).",
    "Comprendre les mots-clés normatifs RFC (MUST, SHOULD, MAY)."
  ],
  prerequisites: ["Niveau 1 — Anglais IT et bases de programmation."],
  sections: [
    {
      type: "table",
      title: "1. Décoder les messages d'erreur courants",
      headers: ["Message console anglais", "Signification exacte et cause"],
      rows: [
        ["Unexpected end of input", "Fin de fichier inattendue : code coupé ou accolade '}' manquante."],
        ["X is not defined", "Variable ou fonction X introuvable ou fichier JS pas encore chargé."],
        ["Cannot read properties of null", "Vous manipulez un élément HTML inexistant (id mal orthographié)."],
        ["Permission denied / Forbidden", "Droits insuffisants pour lire/écrire ce fichier ou accéder à l'API."],
        ["Timeout exceeded", "Le serveur a mis trop de temps à répondre (vérifier réseau/URL)."]
      ]
    },
    {
      type: "theory",
      title: "2. Anatomie d'une documentation technique (MDN / Python)",
      text: "Toute bonne documentation suit la même structure :\n• Overview / Description : à quoi sert la fonction.\n• Parameters / Arguments : données attendues, précisées comme Required (obligatoire) ou Optional (facultatif, avec Default value).\n• Return value : ce que la fonction renvoie (ou void / None si elle ne renvoie rien).\n• Exceptions / Throws : les erreurs possibles.\n• Warning « Deprecated » : fonction obsolète qui marche encore aujourd'hui mais sera supprimée prochainement — ne l'utilisez pas dans un nouveau projet !"
    },
    {
      type: "code",
      lang: "Extrait type de documentation API (RFC 2119)",
      code: [
        "MUST / SHALL      : Exigence absolue obligatoire (ex: API MUST use HTTPS).",
        "MUST NOT          : Interdiction absolue.",
        "SHOULD            : Fortement recommandé (sauf raison exceptionnelle).",
        "MAY               : Optionnel / facultatif."
      ].join("\n")
    }
  ],
  exercises: [
    {
      title: "Exercice 1 — Lire un avertissement de documentation",
      question: "Traduisez et expliquez l'action à faire : « Warning: execCommand('copy') is deprecated. Developers SHOULD use navigator.clipboard.writeText() instead, which returns a Promise. »",
      solution: "« Attention : execCommand('copy') est obsolète. Les développeurs devraient utiliser navigator.clipboard.writeText() à la place, qui renvoie une Promesse (asynchrone). » Il faut donc migrer vers l'API moderne."
    },
    {
      title: "Exercice 2 — Diagnostiquer une erreur réelle",
      question: "Acode affiche : « Uncaught ReferenceError: startQuiz is not defined at HTMLButtonElement.onclick ». Que devez-vous vérifier ?",
      solution: "Le navigateur ne trouve pas la fonction startQuiz : soit le fichier quiz-engine.js n'est pas chargé dans index.html, soit il a été coupé / mal orthographié."
    }
  ],
  summary: "Savoir lire les erreurs console et les spécifications techniques en anglais (Required, Deprecated, Return value, MUST/SHOULD) donne une autonomie totale en développement.",
  references: ["MDN Web Docs (developer.mozilla.org).", "RFC 2119 — Key words for use in RFCs."]
});