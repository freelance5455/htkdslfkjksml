========================================================================
PMD READER & CONVERTER TO DOCX - FULL SOFTWARE PACKAGE (DESKTOP & ANDROID)
========================================================================

INCLUDED FILES IN THIS ARCHIVE:
-------------------------------
1. pmd_converter_mobile_app.html
   - Standalone Android / Mobile / Desktop offline web application.
   - Open directly in Chrome or any browser on your phone to read .pmd/.p65
     files and export them to .docx offline.
   - Can also be converted into an installable .apk in 1 click using
     "Website 2 APK Builder" or "WebCode" on Android.

2. pmd_to_docx_converter.py
   - Full Desktop GUI + Command Line (CLI) application for Windows, macOS,
     and Linux.
   - Run:
       pip install python-docx olefile
       python pmd_to_docx_converter.py

3. android_kivy_project/main.py
   - Native Python Kivy Android application source code with a built-in
     zero-dependency .docx writer.

4. android_kivy_project/buildozer.spec
   - Buildozer configuration file for packaging the Kivy app into an .apk.

5. android_kivy_project/.github/workflows/build_apk.yml
   - Automated GitHub Actions workflow that compiles the native Android .apk
     in the cloud for free when pushed to a GitHub repository.
