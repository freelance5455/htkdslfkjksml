#!/usr/bin/env python3
"""
Android Kivy Application for PMD Reader & DOCX Converter
Compiles directly into an Android .apk using Buildozer.
"""
import os
import re
import zipfile
from pathlib import Path
from xml.sax.saxutils import escape

from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from kivy.uix.spinner import Spinner
from kivy.uix.filechooser import FileChooserListView
from kivy.uix.popup import Popup


def extract_pmd_blocks(raw_bytes: bytes, encoding: str = "cp1252") -> list[str]:
    pattern = re.compile(rb"[\x09\x0a\x0d\x20-\x7e\xa0-\xff]{6,}")
    blocks = []
    seen = set()
    for match in pattern.finditer(raw_bytes):
        decoded = match.group(0).decode(encoding, errors="ignore")
        decoded = decoded.replace("\r\n", "\n").replace("\r", "\n")
        for line in decoded.split("\n"):
            cleaned = line.strip()
            if len(cleaned) >= 4 and cleaned not in seen:
                alnum = sum(c.isalnum() or c in " .,;:'\"?!-()[]{}/&$%@#+" for c in cleaned)
                if alnum / len(cleaned) >= 0.72:
                    seen.add(cleaned)
                    blocks.append(cleaned)
    return blocks


def write_pure_python_docx(output_path: str, title: str, paragraphs: list[str]):
    """Zero-dependency pure-Python .docx writer (works on Android without native C libraries)."""
    content_types = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
</Types>"""

    rels = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
</Relationships>"""

    body_xml = "".join(
        f'<w:p><w:r><w:t xml:space="preserve">{escape(p)}</w:t></w:r></w:p>'
        for p in paragraphs
    )
    document_xml = f"""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
  <w:body>
    <w:p><w:r><w:rPr><w:b/><w:sz w:val="32"/></w:rPr><w:t>{escape(title)}</w:t></w:r></w:p>
    {body_xml}
  </w:body>
</w:document>"""

    with zipfile.ZipFile(output_path, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("[Content_Types].xml", content_types)
        zf.writestr("_rels/.rels", rels)
        zf.writestr("word/document.xml", document_xml)


class PMDAndroidApp(App):
    def build(self):
        self.current_file = None
        root = BoxLayout(orientation="vertical", padding=12, spacing=10)

        header = Label(
            text="PMD Reader & DOCX Converter",
            size_hint_y=None,
            height=48,
            bold=True,
            font_size="18sp",
        )
        root.add_widget(header)

        top_bar = BoxLayout(size_hint_y=None, height=48, spacing=8)
        btn_open = Button(text="Open .PMD File", background_color=(0.15, 0.39, 0.92, 1))
        btn_open.bind(on_release=self.show_file_chooser)

        self.enc_spinner = Spinner(
            text="cp1252",
            values=("cp1252", "mac_roman", "latin1", "utf-8"),
            size_hint_x=0.45,
        )
        self.enc_spinner.bind(text=self.on_encoding_change)

        top_bar.add_widget(btn_open)
        top_bar.add_widget(self.enc_spinner)
        root.add_widget(top_bar)

        self.status_lbl = Label(
            text="Select a .pmd or .p65 file to extract text.",
            size_hint_y=None,
            height=34,
        )
        root.add_widget(self.status_lbl)

        self.editor = TextInput(
            hint_text="Extracted PageMaker text will appear here...",
            multiline=True,
        )
        root.add_widget(self.editor)

        btn_save = Button(
            text="Convert & Save as .DOCX",
            size_hint_y=None,
            height=52,
            background_color=(0.09, 0.64, 0.29, 1),
        )
        btn_save.bind(on_release=self.export_docx)
        root.add_widget(btn_save)

        return root

    def show_file_chooser(self, *args):
        content = BoxLayout(orientation="vertical", spacing=8)
        start_dir = os.path.expanduser("~")
        if os.path.exists("/storage/emulated/0"):
            start_dir = "/storage/emulated/0"
        chooser = FileChooserListView(path=start_dir, filters=["*.pmd", "*.p65", "*.PMD", "*.P65"])
        content.add_widget(chooser)

        btn_select = Button(text="Load Selected File", size_hint_y=None, height=48)
        popup = Popup(title="Select PageMaker (.pmd) File", content=content, size_hint=(0.95, 0.9))

        def load_selection(*_):
            if chooser.selection:
                self.load_pmd(chooser.selection[0])
                popup.dismiss()

        btn_select.bind(on_release=load_selection)
        content.add_widget(btn_select)
        popup.open()

    def on_encoding_change(self, spinner, text):
        if self.current_file:
            self.load_pmd(self.current_file)

    def load_pmd(self, filepath: str):
        try:
            self.current_file = filepath
            raw = Path(filepath).read_bytes()
            blocks = extract_pmd_blocks(raw, encoding=self.enc_spinner.text)
            self.editor.text = "\n\n".join(blocks)
            self.status_lbl.text = f"Loaded {Path(filepath).name} ({len(blocks)} blocks)"
        except Exception as e:
            self.status_lbl.text = f"Error: {e}"

    def export_docx(self, *args):
        text = self.editor.text.strip()
        if not text:
            self.status_lbl.text = "Nothing to export! Load a .pmd file first."
            return
        out_path = (
             str(Path(self.current_file).with_suffix(".docx"))
            if self.current_file
            else os.path.join(os.path.expanduser("~"), "converted_pagemaker.docx")
        )
        try:
            paragraphs = [p.strip() for p in text.split("\n\n") if p.strip()]
            title = Path(self.current_file).stem if self.current_file else "Converted Document"
            write_pure_python_docx(out_path, title, paragraphs)
            self.status_lbl.text = f"Saved DOCX: {out_path}"
        except Exception as e:
            self.status_lbl.text = f"Save failed: {e}"


if __name__ == "__main__":
    PMDAndroidApp().run()
