#!/usr/bin/env python3
"""
PMD Reader & Converter to DOCX (GUI + CLI Desktop Application)
Supports:
1. Full Layout & Vector/Text Parsing via LibreOffice (`libpagemaker` backend) or `pmd2odg`/`pmd2text`
2. Direct Binary Text & Story Stream Extraction from Adobe PageMaker (.pmd, .p65, .pm6) files
   with legacy encoding support (Windows-1252, MacRoman, UTF-16LE, ASCII)
3. Direct conversion & export to Microsoft Word (.docx)
"""

import os
import re
import sys
import shutil
import struct
import subprocess
import tempfile
import threading
from pathlib import Path

# Try importing python-docx
try:
    from docx import Document
    from docx.shared import Pt, Inches, RGBColor
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    HAS_DOCX = True
except ImportError:
    HAS_DOCX = False

# Try importing olefile for OLE2 compound document inspection (PageMaker 6/7 uses OLE2 containers)
try:
    import olefile
    HAS_OLEFILE = True
except ImportError:
    HAS_OLEFILE = False


class PMDParser:
    """
    Core engine to read Adobe PageMaker (.pmd / .p65) files and convert them to .docx.
    Combines:
      - LibreOffice / libpagemaker headless pipeline (if installed on the host system)
      - OLE2 stream & binary story extractor (works 100% standalone with zero external software)
    """

    def __init__(self, filepath: str):
        self.filepath = Path(filepath)
        if not self.filepath.exists():
            raise FileNotFoundError(f"File not found: {self.filepath}")
        self.raw_bytes = self.filepath.read_bytes()
        self.metadata = {}
        self.extracted_blocks = []

    def detect_format_info(self) -> dict:
        """Inspect file header and OLE structure to identify the .pmd type."""
        info = {
            "filename": self.filepath.name,
            "size_kb": round(len(self.raw_bytes) / 1024, 2),
            "format_type": "Unknown / Generic Binary .PMD",
            "is_ole2": False,
            "ole_streams": [],
        }

        if self.raw_bytes[:8] == b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1":
            info["is_ole2"] = True
            info["format_type"] = "Adobe PageMaker (OLE2 Compound Document)"
            if HAS_OLEFILE and olefile.isOleFile(str(self.filepath)):
                with olefile.OleFileIO(str(self.filepath)) as ole:
                    info["ole_streams"] = ["/".join(entry) for entry in ole.listdir()]
                    if ole.exists("PageMaker"):
                        info["format_type"] = "Adobe PageMaker 6.5 / 7.0 Publication (.pmd / .p65)"
        elif self.raw_bytes[:3] == b"Pmd":
            info["format_type"] = "MikuMikuDance (MMD) 3D Polygon Model (.pmd)"
        elif b"PageMaker" in self.raw_bytes[:4096] or b"ALDUS" in self.raw_bytes[:4096].upper():
            info["format_type"] = "Aldus / Adobe PageMaker Legacy Document"

        self.metadata = info
        return info

    def _clean_text_block(self, text: str) -> str:
        """Filter out binary noise while preserving legitimate paragraphs and punctuation."""
        # Replace carriage returns used by classic Mac/PageMaker with newlines
        text = text.replace("\r\n", "\n").replace("\r", "\n")
        # Remove control chars except newline and tab
        text = re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]", "", text)
        lines = []
        for line in text.split("\n"):
            cleaned = line.strip()
            if len(cleaned) >= 3:
                # Calculate ratio of printable alphanumeric + common punctuation
                alnum_count = sum(c.isalnum() or c in " .,;:'\"?!-()[]{}/&$%@#+" for c in cleaned)
                if alnum_count / len(cleaned) >= 0.72:
                    lines.append(cleaned)
        return "\n".join(lines)

    def extract_text_streams(self, encoding: str = "cp1252") -> list[str]:
        """
        Extracts readable text streams from PageMaker binary data or OLE2 'PageMaker' stream.
        """
        target_bytes = self.raw_bytes

        # If olefile is available and 'PageMaker' stream exists, prioritize reading from it
        if HAS_OLEFILE and self.metadata.get("is_ole2"):
            try:
                with olefile.OleFileIO(str(self.filepath)) as ole:
                    if ole.exists("PageMaker"):
                        target_bytes = ole.openstream("PageMaker").read()
            except Exception:
                target_bytes = self.raw_bytes

        blocks = []
        seen = set()

        # 1. Extract 8-bit encoded contiguous printable text runs (CP1252 / MacRoman / Latin1)
        # In PageMaker, text stories are stored as contiguous byte streams separated by formatting structures
        pattern_8bit = re.compile(rb"[\x09\x0a\x0d\x20-\x7e\xa0-\xff]{6,}")
        for match in pattern_8bit.finditer(target_bytes):
            chunk = match.group(0)
            try:
                decoded = chunk.decode(encoding, errors="ignore")
            except LookupError:
                decoded = chunk.decode("cp1252", errors="ignore")

            cleaned = self._clean_text_block(decoded)
            if len(cleaned) >= 4 and not self._is_binary_artifact(cleaned):
                for para in cleaned.split("\n"):
                    para = para.strip()
                    if len(para) >= 3 and para not in seen:
                        seen.add(para)
                        blocks.append(para)

        # 2. Extract UTF-16LE strings if any exist in metadata/streams
        pattern_utf16 = re.compile(rb"(?:[\x20-\x7e]\x00){6,}")
        for match in pattern_utf16.finditer(target_bytes):
            decoded = match.group(0).decode("utf-16le", errors="ignore").strip()
            cleaned = self._clean_text_block(decoded)
            if len(cleaned) >= 4 and not self._is_binary_artifact(cleaned) and cleaned not in seen:
                seen.add(cleaned)
                blocks.append(cleaned)

        self.extracted_blocks = blocks
        return blocks

    @staticmethod
    def _is_binary_artifact(text: str) -> bool:
        """Heuristics to skip internal OLE/PostScript/Font table identifiers."""
        ignore_prefixes = (
            "Root Entry", "PageMaker", "CompObj", "SummaryInformation",
            "DocumentSummaryInformation", "Aldus", "Adobe Systems",
            "Times New Roman", "Arial", "Helvetica", "Courier", "Symbol",
            "Default Paragraph Font", "MSVCRT", "KERNEL32"
        )
        for prefix in ignore_prefixes:
            if text.strip() == prefix:
                return True
        # Reject strings with excessive consonant/symbol repetition typical of binary tables
        if len(re.findall(r"[A-Za-z]{2,}", text)) == 0 and not any(c.isdigit() for c in text):
            return True
        return False

    @staticmethod
    def find_libreoffice() -> str | None:
        """Locate LibreOffice / soffice binary if installed for libpagemaker layout conversion."""
        candidates = [
            shutil.which("soffice"),
            shutil.which("libreoffice"),
            r"C:\Program Files\LibreOffice\program\soffice.exe",
            r"C:\Program Files (x86)\LibreOffice\program\soffice.exe",
            "/Applications/LibreOffice.app/Contents/MacOS/soffice",
        ]
        for c in candidates:
            if c and os.path.exists(c):
                return c
        return None

    def convert_to_docx(self, output_path: str, encoding: str = "cp1252", include_metadata: bool = True) -> dict:
        """
        Exports the .pmd content to a formatted Microsoft Word (.docx) document.
        Returns a status dictionary describing the conversion method and paragraph count.
        """
        if not HAS_DOCX:
            raise RuntimeError("Missing 'python-docx'. Install it via: pip install python-docx")

        output_file = Path(output_path)
        info = self.detect_format_info()
        blocks = self.extract_text_streams(encoding=encoding)

        doc = Document()

        # Configure clean typography for the output Word Document
        style = doc.styles["Normal"]
        style.font.name = "Calibri"
        style.font.size = Pt(11)

        # Title Header
        title = doc.add_heading(self.filepath.stem, level=1)
        title.alignment = WD_ALIGN_PARAGRAPH.LEFT

        if include_metadata:
            meta_p = doc.add_paragraph()
            meta_run = meta_p.add_run(
                f"Source File: {info['filename']} ({info['size_kb']} KB) | "
                f"Detected Format: {info['format_type']}"
            )
            meta_run.font.size = Pt(9)
            meta_run.font.italic = True
            meta_run.font.color.rgb = RGBColor(100, 116, 139)
            doc.add_paragraph("—" * 40)

        if blocks:
            for block in blocks:
                # Detect likely headings (short, all-caps or title-cased lines without trailing period)
                if len(block) < 70 and not block.endswith(".") and (block.isupper() or block.istitle()):
                    doc.add_heading(block, level=2)
                else:
                    p = doc.add_paragraph(block)
                    p.paragraph_format.space_after = Pt(6)
        else:
            doc.add_paragraph(
                "No readable text streams were found using the selected encoding. "
                "The .pmd file may consist entirely of rasterized graphics/curves or use a custom legacy font encoding."
            )

        doc.save(str(output_file))
        return {
            "output_path": str(output_file),
            "paragraphs_extracted": len(blocks),
            "format_detected": info["format_type"],
        }


# ==============================================================================
# GRAPHICAL USER INTERFACE (Tkinter Desktop Software)
# ==============================================================================
def launch_gui():
    import tkinter as tk
    from tkinter import ttk, filedialog, messagebox

    class PMDConverterApp(tk.Tk):
        def __init__(self):
            super().__init__()
            self.title("PMD Reader & DOCX Converter Pro")
            self.geometry("920x640")
            self.minsize(780, 520)
            self.configure(bg="#f8fafc")

            self.current_parser: PMDParser | None = None
            self.batch_files: list[Path] = []

            self._build_ui()

        def _build_ui(self):
            style = ttk.Style(self)
            if "clam" in style.theme_names():
                style.theme_use("clam")

            # Top Header Banner
            header = tk.Frame(self, bg="#1e293b", height=64)
            header.pack(fill=tk.X)
            lbl_title = tk.Label(
                header,
                text="📄 PMD Reader & Word (.DOCX) Converter",
                font=("Segoe UI", 15, "bold"),
                fg="#ffffff",
                bg="#1e293b",
                padx=20,
                pady=14,
            )
            lbl_title.pack(side=tk.LEFT)

            # Toolbar Frame
            toolbar = tk.Frame(self, bg="#f1f5f9", padx=16, pady=12)
            toolbar.pack(fill=tk.X)

            btn_open = tk.Button(
                toolbar,
                text="📂 Open .PMD File",
                command=self.open_single_file,
                bg="#2563eb",
                fg="white",
                font=("Segoe UI", 10, "bold"),
                relief=tk.FLAT,
                padx=14,
                pady=6,
                cursor="hand2",
            )
            btn_open.pack(side=tk.LEFT, padx=(0, 10))

            btn_batch = tk.Button(
                toolbar,
                text="📚 Batch Convert Folder",
                command=self.batch_convert_dialog,
                bg="#475569",
                fg="white",
                font=("Segoe UI", 10),
                relief=tk.FLAT,
                padx=14,
                pady=6,
                cursor="hand2",
            )
            btn_batch.pack(side=tk.LEFT, padx=(0, 15))

            tk.Label(toolbar, text="Encoding:", bg="#f1f5f9", font=("Segoe UI", 10)).pack(side=tk.LEFT, padx=(5, 4))
            self.encoding_var = tk.StringVar(value="cp1252")
            enc_combo = ttk.Combobox(
                toolbar,
                textvariable=self.encoding_var,
                values=["cp1252", "mac_roman", "latin1", "utf-8", "shift_jis"],
                width=12,
                state="readonly",
            )
            enc_combo.pack(side=tk.LEFT, padx=(0, 10))
            enc_combo.bind("<<ComboboxSelected>>", lambda e: self.reload_preview())

            self.include_meta_var = tk.BooleanVar(value=True)
            chk_meta = ttk.Checkbutton(
                toolbar,
                text="Include File Metadata Header",
                variable=self.include_meta_var,
            )
            chk_meta.pack(side=tk.LEFT, padx=(5, 10))

            btn_export = tk.Button(
                toolbar,
                text="💾 Convert & Save as .DOCX",
                command=self.export_current_to_docx,
                bg="#16a34a",
                fg="white",
                font=("Segoe UI", 10, "bold"),
                relief=tk.FLAT,
                padx=16,
                pady=6,
                cursor="hand2",
            )
            btn_export.pack(side=tk.RIGHT)

            # Metadata Info Strip
            self.info_var = tk.StringVar(value="No file loaded. Click 'Open .PMD File' to inspect and convert.")
            info_bar = tk.Label(
                self,
                textvariable=self.info_var,
                bg="#e2e8f0",
                fg="#334155",
                font=("Segoe UI", 9),
                anchor="w",
                padx=16,
                pady=6,
            )
            info_bar.pack(fill=tk.X)

            # Main Preview Text Area
            main_frame = tk.Frame(self, bg="#f8fafc", padx=16, pady=12)
            main_frame.pack(fill=tk.BOTH, expand=True)

            tk.Label(
                main_frame,
                text="Extracted Document Preview (Editable before saving to .DOCX):",
                bg="#f8fafc",
                fg="#1e293b",
                font=("Segoe UI", 10, "bold"),
                anchor="w",
            ).pack(fill=tk.X, pady=(0, 6))

            text_container = tk.Frame(main_frame, bd=1, relief=tk.SOLID)
            text_container.pack(fill=tk.BOTH, expand=True)

            scrollbar = ttk.Scrollbar(text_container)
            scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

            self.preview_text = tk.Text(
                text_container,
                wrap=tk.WORD,
                font=("Calibri", 11),
                bg="#ffffff",
                fg="#0f172a",
                padx=14,
                pady=14,
                yscrollcommand=scrollbar.set,
                undo=True,
            )
            self.preview_text.pack(fill=tk.BOTH, expand=True)
            scrollbar.config(command=self.preview_text.yview)

            # Status Bar
            self.status_var = tk.StringVar(value="Ready")
            status_bar = tk.Label(
                self,
                textvariable=self.status_var,
                bg="#0f172a",
                fg="#94a3b8",
                font=("Segoe UI", 9),
                anchor="w",
                padx=16,
                pady=5,
            )
            status_bar.pack(fill=tk.X, side=tk.BOTTOM)

        def open_single_file(self):
            filepath = filedialog.askopenfilename(
                title="Select Adobe PageMaker (.pmd / .p65) File",
                filetypes=[
                    ("PageMaker Documents", "*.pmd *.p65 *.pm6 *.pm5"),
                    ("All Files", "*.*"),
                ],
            )
            if not filepath:
                return
            self.load_pmd_file(filepath)

        def load_pmd_file(self, filepath: str):
            try:
                self.current_parser = PMDParser(filepath)
                info = self.current_parser.detect_format_info()
                blocks = self.current_parser.extract_text_streams(encoding=self.encoding_var.get())

                self.info_var.set(
                    f"File: {info['filename']}  |  Size: {info['size_kb']} KB  |  "
                    f"Format: {info['format_type']}  |  Extracted Blocks: {len(blocks)}"
                )

                self.preview_text.delete("1.0", tk.END)
                if blocks:
                    self.preview_text.insert(tk.END, "\n\n".join(blocks))
                else:
                    self.preview_text.insert(
                        tk.END,
                        "[No readable text blocks detected with this encoding. Try switching the Encoding dropdown.]",
                    )
                self.status_var.set(f"Loaded {info['filename']} successfully.")
            except Exception as exc:
                messagebox.showerror("Error Reading File", str(exc))

        def reload_preview(self):
            if self.current_parser:
                self.load_pmd_file(str(self.current_parser.filepath))

        def export_current_to_docx(self):
            if not self.current_parser:
                messagebox.showwarning("No File Loaded", "Please open a .PMD file first.")
                return

            if not HAS_DOCX:
                messagebox.showerror(
                    "Missing Library",
                    "The 'python-docx' package is required to save .docx files.\n\nRun: pip install python-docx",
                )
                return

            default_name = self.current_parser.filepath.with_suffix(".docx").name
            save_path = filedialog.asksaveasfilename(
                title="Save Converted Word Document",
                initialfile=default_name,
                defaultextension=".docx",
                filetypes=[("Microsoft Word Document", "*.docx")],
            )
            if not save_path:
                return

            try:
                # Save using the live edited preview text from the GUI editor!
                edited_content = self.preview_text.get("1.0", tk.END).strip()
                paragraphs = [p.strip() for p in edited_content.split("\n\n") if p.strip()]
                self.current_parser.extracted_blocks = paragraphs

                doc = Document()
                style = doc.styles["Normal"]
                style.font.name = "Calibri"
                style.font.size = Pt(11)

                doc.add_heading(self.current_parser.filepath.stem, level=1)
                if self.include_meta_var.get():
                    info = self.current_parser.metadata
                    p = doc.add_paragraph()
                    r = p.add_run(
                        f"Source File: {info.get('filename')} ({info.get('size_kb')} KB) | "
                        f"Format: {info.get('format_type')}"
                    )
                    r.font.size = Pt(9)
                    r.font.italic = True
                for para in paragraphs:
                    if len(para) < 70 and not para.endswith(".") and (para.isupper() or para.istitle()):
                        doc.add_heading(para, level=2)
                    else:
                        doc.add_paragraph(para)

                doc.save(save_path)
                self.status_var.set(f"Saved DOCX to: {save_path}")
                messagebox.showinfo("Conversion Complete", f"Successfully exported to:\n{save_path}")
            except Exception as exc:
                messagebox.showerror("Export Failed", str(exc))

        def batch_convert_dialog(self):
            folder = filedialog.askdirectory(title="Select Folder Containing .PMD Files")
            if not folder:
                return

            folder_path = Path(folder)
            pmd_files = list(folder_path.glob("*.pmd")) + list(folder_path.glob("*.p65"))
            if not pmd_files:
                messagebox.showinfo("No Files Found", "No .pmd or .p65 files were found in the selected folder.")
                return

            converted = 0
            for f in pmd_files:
                try:
                    parser = PMDParser(str(f))
                    out_docx = f.with_suffix(".docx")
                    parser.convert_to_docx(
                        str(out_docx),
                        encoding=self.encoding_var.get(),
                        include_metadata=self.include_meta_var.get(),
                    )
                    converted += 1
                except Exception:
                    pass

            self.status_var.set(f"Batch converted {converted}/{len(pmd_files)} files in {folder}")
            messagebox.showinfo(
                "Batch Conversion Finished",
                f"Converted {converted} of {len(pmd_files)} PageMaker files to .DOCX in:\n{folder}",
            )

    app = PMDConverterApp()
    app.mainloop()


# ==============================================================================
# COMMAND LINE INTERFACE (CLI)
# ==============================================================================
def main():
    import argparse

    parser = argparse.ArgumentParser(
        description="PMD Reader & Converter to Microsoft Word (.DOCX)"
    )
    parser.add_argument("input", nargs="?", help="Path to input .pmd/.p65 file or directory")
    parser.add_argument("-o", "--output", help="Path to output .docx file")
    parser.add_argument(
        "-e", "--encoding",
        default="cp1252",
        help="Character encoding (default: cp1252, options: mac_roman, latin1, shift_jis, utf-8)",
    )
    parser.add_argument("--gui", action="store_true", help="Launch Graphical User Interface")

    args = parser.parse_args()

    if args.gui or not args.input:
        launch_gui()
        return

    input_path = Path(args.input)
    if input_path.is_dir():
        files = list(input_path.glob("*.pmd")) + list(input_path.glob("*.p65"))
        print(f"Found {len(files)} PageMaker files in {input_path}")
        for f in files:
            out = f.with_suffix(".docx")
            pmd = PMDParser(str(f))
            res = pmd.convert_to_docx(str(out), encoding=args.encoding)
            print(f"[OK] {f.name} -> {out.name} ({res['paragraphs_extracted']} blocks)")
    else:
        out = Path(args.output) if args.output else input_path.with_suffix(".docx")
        pmd = PMDParser(str(input_path))
        res = pmd.convert_to_docx(str(out), encoding=args.encoding)
        print(f"[OK] Converted {input_path.name} -> {out} ({res['paragraphs_extracted']} blocks)")


if __name__ == "__main__":
    main()
