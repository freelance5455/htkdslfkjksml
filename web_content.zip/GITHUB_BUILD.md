# NexPhys Maroc — Build APK

1. Upload the project files to the GitHub repository (not only the ZIP).
2. Make sure `.github/workflows/build-apk.yml` is present at repository root.
3. Open **Actions** → **Build NexPhys Maroc APK**.
4. Choose **Run workflow**.
5. When the run is green, open it and download the artifact **PhysiX-Maroc-debug-apk**.
6. Extract the downloaded artifact to get `app-debug.apk`.
