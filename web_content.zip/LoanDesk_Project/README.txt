LoanDesk - Black & Red Edition

Files:
- index.html: single-file offline app for Android WebView / APKForge.

New in this update:
- Black + red interface theme.
- Monthly loans accrue simple interest automatically from the loan date using the Excel-style formula:
  principal * 10% * (complete months + remaining days / 30)
- Interest is calculated against the original principal; partial payments reduce the outstanding amount but do not change the interest principal.
- Automatic accrued interest is refreshed when the app opens or re-renders. It is not a background process while the app is fully closed.
- Discounted settlement: enter the actual final amount received; the app records the amount received, the waived discount, and closes the loan.
- Existing open monthly loans are migrated to date-based automatic interest on first launch after this update. Export a backup before replacing the old app.

APKForge:
1. Unzip the project.
2. Create/import an HTML or WebView app.
3. Upload index.html as the app's main page.
4. Enable JavaScript, DOM storage/local storage, file chooser and external links.
5. Build the APK and test with sample data before using real customer records.

Important:
- Data is stored locally on this device/browser profile. Export backups regularly.
- Automatic interest refreshes when the app is opened/used; it does not run as an Android background service.
- WhatsApp sharing is manual and depends on Android/WebView support.
- This is a record-keeping calculator, not legal or financial advice. Check applicable lending, interest-rate, privacy and collateral rules before use.
