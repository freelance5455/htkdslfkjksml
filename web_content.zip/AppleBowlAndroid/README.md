# Apple Bowl Game — Android wrapper

This project wraps the supplied TurboWarp HTML game in a fullscreen Android WebView. The original game is bundled locally in `app/src/main/assets/index.html`.

## Build an APK

1. Open this folder in Android Studio (current stable version), allow Gradle sync, and choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
2. The debug APK will be at `app/build/outputs/apk/debug/app-debug.apk`.

### Build without Android Studio

Push this project to a GitHub repository. Open **Actions > Build Android APK > Run workflow**. Download the `Apple-Bowl-Game-APK` artifact from the completed workflow run.

The APK is a debug build for testing/sideloading. A Play Store release requires a separately signed release build.
