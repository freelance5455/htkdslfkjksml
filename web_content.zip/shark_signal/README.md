# Shark Exchange Signal Pro

## Included
- Shark public market REST candle requests: `POST https://api.sharkexchange.in/v1/market/klines?priceType=MARK_PRICE`
- Public Socket.IO feed: `https://fawss.sharkexchange.in/`
- 3m / 5m / 15m candle verification and timeframe agreement
- EMA 9/21/34, RSI 14, MACD 12/26/9, ATR 14, relative-volume check
- BUY / SELL only when all three timeframes agree; otherwise WAIT
- ATR-derived entry reference, target and stop-loss, fixed for that signal instance
- India timezone display

## Run
1. Extract the ZIP.
2. Open `index.html` in a modern browser with internet access. If the browser blocks API requests from `file://`, run a local static server (for example, in the folder run `python -m http.server 8000`) and open `http://localhost:8000`.
3. Select a market and press **Refresh analysis**.

## Important limits
No software can guarantee an exact future target price or a profitable BUY/SELL signal. The target shown is a formula-derived level, not a promise that the market will reach it. This version does not place orders and does not need private API credentials. Public API availability, CORS, symbol support, network conditions, and the exact current exchange response can change. If candle data cannot be validated, the app intentionally shows WAIT.

## API reference
Official Shark API docs: https://docs.sharkexchange.in/
