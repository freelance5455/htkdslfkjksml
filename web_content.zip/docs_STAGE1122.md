# CPLS V2 — Stage 1122

## Futures connection hardening

- Continued from Stage 1121.
- Keeps the official LBank Futures WebSocket endpoint: `wss://lbkperpws.lbank.com/ws`.
- Does **not** invent or send an undocumented Futures subscription payload.
- Keeps the REST Futures market/order-book feed as the production data source.
- Improves the diagnostic payload with endpoint, timestamps, message count, retry count, and close code.
- Improves the mobile diagnostic text so connection state is easier to read.

## Important

This package is a source ZIP, not an APK. Live WebSocket reachability cannot be honestly certified from this build environment. The phone test is the authoritative check for whether the official Futures WS is reachable from the user's network.
