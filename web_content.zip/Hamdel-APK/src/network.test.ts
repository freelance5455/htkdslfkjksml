import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';

const htmlPath = path.resolve(process.cwd(), 'index.html');
const html = fs.readFileSync(htmlPath, 'utf8');

function extractScriptModule(source: string): string {
  const match = source.match(/<script type="module">([\s\S]*?)<\/script>/);
  assert.ok(match, 'index.html must contain an inline <script type="module"> block');
  return match[1];
}

function loadV3DataEnvironment() {
  const script = extractScriptModule(html);
  const categoriesMatch = script.match(/const CATEGORIES = (\[[\s\S]*?\n      \]);/);
  const catColorsMatch = script.match(/const CATEGORY_COLOR_MAP = (\{[\s\S]*?\n      \});/);
  const topicsMatch = script.match(/const OFFICIAL_TOPICS = (\[[\s\S]*?\n      \]);/);
  const eduMatch = script.match(/const EDUCATION_LINKS = (\{[\s\S]*?\n      \});/);
  const photosMatch = script.match(/const PROOF_PHOTOS = (\{[\s\S]*?\n      \});/);
  const pickPhotoMatch = script.match(/function pickPhotoForRecord\(rec\) \{[\s\S]*?\n      \}/);
  const parseYearMatch = script.match(/function parsePersianYear\(yStr\) \{[\s\S]*?\n      \}/);
  const rawRecordsMatch = script.match(/const RAW_RECORDS = (\[[\s\S]*?\n      \]);/);
  const normCatMatch = script.match(/function normalizeFunctionalCategory\(cat\) \{[\s\S]*?\n      \}/);
  const hydrateMatch = script.match(/function hydrateRecord\(rec\) \{[\s\S]*?\n      \}/);
  const emptyProvMatch = script.match(/const EMPTY_PROVINCES = (\[[^\n]+\]);/);
  const centroidsMatch = script.match(/const PROVINCE_CENTROIDS = (\{[\s\S]*?\n      \});/);
  const cityNormMatch = script.match(/const CITY_NORM_COORDS = (\{[\s\S]*?\n      \});/);
  const borderMatch = script.match(/const IRAN_BORDER_NORM = (\[[\s\S]*?\n      \]);/);
  const suggMatch = script.match(/const SUGGESTIONS_BY_CATEGORY = (\{[\s\S]*?\n      \});/);
  const filterMatch = script.match(/function matchesFilters\(action, filters\) \{[\s\S]*?\n      \}/);

  assert.ok(
    categoriesMatch &&
      catColorsMatch &&
      topicsMatch &&
      eduMatch &&
      photosMatch &&
      pickPhotoMatch &&
      parseYearMatch &&
      rawRecordsMatch &&
      normCatMatch &&
      hydrateMatch &&
      emptyProvMatch &&
      centroidsMatch &&
      cityNormMatch &&
      borderMatch &&
      suggMatch &&
      filterMatch,
    'All expected v3 data blocks and pure helpers must exist in index.html'
  );

  return Function(`
    "use strict";
    const CATEGORIES = ${categoriesMatch[1]};
    const CATEGORY_COLOR_MAP = ${catColorsMatch[1]};
    const OFFICIAL_TOPICS = ${topicsMatch[1]};
    const TOPIC_COLOR_MAP = Object.fromEntries(OFFICIAL_TOPICS.map((t) => [t.name, t.color]));
    const EDUCATION_LINKS = ${eduMatch[1]};
    const PROOF_PHOTOS = ${photosMatch[1]};
    ${pickPhotoMatch[0]}
    ${parseYearMatch[0]}
    const RAW_RECORDS = ${rawRecordsMatch[1]};
    ${normCatMatch[0]}
    ${hydrateMatch[0]}
    const ACTIONS = RAW_RECORDS.map(hydrateRecord);
    const EMPTY_PROVINCES = ${emptyProvMatch[1]};
    const PROVINCE_CENTROIDS = ${centroidsMatch[1]};
    const CITY_NORM_COORDS = ${cityNormMatch[1]};
    const IRAN_BORDER_NORM = ${borderMatch[1]};
    const SUGGESTIONS_BY_CATEGORY = ${suggMatch[1]};
    ${filterMatch[0]}
    return {
      CATEGORIES,
      CATEGORY_COLOR_MAP,
      OFFICIAL_TOPICS,
      EDUCATION_LINKS,
      PROOF_PHOTOS,
      ACTIONS,
      EMPTY_PROVINCES,
      PROVINCE_CENTROIDS,
      CITY_NORM_COORDS,
      IRAN_BORDER_NORM,
      SUGGESTIONS_BY_CATEGORY,
      matchesFilters,
    };
  `)() as {
    CATEGORIES: string[];
    CATEGORY_COLOR_MAP: Record<string, string>;
    OFFICIAL_TOPICS: Array<{ id: string; name: string; color: string; description: string }>;
    EDUCATION_LINKS: Record<string, Array<{ title: string; url: string }>>;
    PROOF_PHOTOS: Record<string, string>;
    ACTIONS: Array<{
      id: string;
      title: string;
      city: string;
      province: string;
      topic: string;
      category: string;
      year: string;
      yearNum: number;
      ledBy: string;
      verification: string;
      isDemo: boolean;
      sourceUrl: string;
      proof: {
        image: string;
        caption: string;
        impact: string;
        links: Array<{ label: string; source: string; type: string; url: string }>;
      };
    }>;
    EMPTY_PROVINCES: string[];
    PROVINCE_CENTROIDS: Record<string, [number, number]>;
    CITY_NORM_COORDS: Record<string, [number, number]>;
    IRAN_BORDER_NORM: Array<[number, number]>;
    SUGGESTIONS_BY_CATEGORY: Record<string, Array<{ title: string; meta: string }>>;
    matchesFilters: (
      a: { category: string; topic: string; province: string; year: string },
      f: { category?: string; topic?: string; province?: string; year?: string }
    ) => boolean;
  };
}

test('ACT 1, aesthetic, Persian RTL, lazy Three.js init, and ZERO sort-by control', () => {
  const script = extractScriptModule(html);

  assert.match(html, /<html\s+lang="fa"\s+dir="rtl">/);
  assert.match(html, /Vazirmatn/);
  assert.match(html, /--bg:\s*#0b0a08/);
  assert.match(html, /id="intro-screen"/);
  assert.match(html, /id="act1-splash"/);
  assert.match(html, /@keyframes rtlReveal/);
  assert.match(html, /شبکه‌ای از اقدامات مردم ایران/);
  assert.match(html, /id="act1-feed-stats"/);
  assert.match(html, /id="act1-feed"/);
  assert.match(html, /آماده‌ای از چشم دیگری به این اقدام‌ها نگاه کنی؟/);
  assert.match(html, /class="reveal-desc"/);
  assert.match(html, /هر نقطه نورانی یکی از همین اقدام‌های واقعی مردم ایران است/);
  assert.match(html, /ورود به شبکه/);
  assert.match(html, /z-index:\s*99999/);
  assert.match(html, /۵۰ اقدام واقعی · ۲۷ استان · کانون میناب/);
  assert.match(script, /function startAct1Sequence\(\)/);
  assert.match(script, /function startAct1TerminalFeed\(\)/);
  assert.match(script, /const activeStreams = \[\];/);
  assert.match(script, /const readingHoldTimer = window\.setTimeout/);
  assert.match(script, /if \(params\.get\('autostart'\) === '1'\)/);
  assert.match(script, /function initThreeSceneOnce\(\)/);
  assert.match(script, /new THREE\.Vector3\(0,\s*8,\s*22\)/);
  assert.match(script, /new THREE\.Vector3\(0,\s*30,\s*45\)/);
  assert.match(script, /revealDollyDuration:\s*2\.0/);
  assert.match(script, /NODE_VERTEX_SHADER/);
  assert.match(script, /EDGE_FRAGMENT_SHADER/);
  assert.match(html, /<script type="importmap">/);

  // Safety & clean UI constraints
  assert.doesNotMatch(html, /\b(alert|confirm|prompt)\s*\(/);
  assert.doesNotMatch(html, /backdrop-filter/);

  // §1 THE ONLY REMOVAL: sort-by control must not exist anywhere
  assert.doesNotMatch(html, /id="sort-select"/);
  assert.doesNotMatch(script, /\bsortBy\b/);
  assert.doesNotMatch(script, /\bsortActionIndices\b/);
});

test('Real data honesty (§4 + Minab solidarity records): 50 verified records across 27 provinces + 5 labeled demos + 4 empty provinces', () => {
  const env = loadV3DataEnvironment();

  assert.equal(env.ACTIONS.length, 55);

  const verified = env.ACTIONS.filter((a) => a.verification === 'verified');
  const demos = env.ACTIONS.filter((a) => a.verification === 'demo');

  assert.equal(verified.length, 50, 'Must have 50 verified real records (mh-001..mh-050)');
  assert.equal(demos.length, 5, 'Must have 5 clearly labeled demo records');

  const validTopicNames = new Set(env.OFFICIAL_TOPICS.map((t) => t.name));
  const validCategories = new Set(env.CATEGORIES);
  const verifiedProvinces = new Set<string>();
  const verifiedCategories = new Set<string>();

  for (const act of verified) {
    assert.equal(act.isDemo, false);
    assert.ok(act.sourceUrl.startsWith('https://'), `Verified record ${act.id} must have real https URL`);
    assert.ok(act.proof.links.some((l) => l.url.startsWith('https://')), `Proof links for ${act.id} must include https URL`);
    assert.ok(act.ledBy && act.ledBy.length > 2, `Record ${act.id} must include ledBy`);
    assert.ok(validTopicNames.has(act.topic), `Record ${act.id} topic "${act.topic}" must match official collaboration topics`);
    assert.ok(validCategories.has(act.category), `Record ${act.id} category "${act.category}" must map to one of the 6 functional categories`);
    verifiedProvinces.add(act.province);
    verifiedCategories.add(act.category);
  }

  assert.equal(verifiedProvinces.size, 27, '50 verified records must span exactly 27 provinces of Iran');
  assert.equal(verifiedCategories.size, 6, 'All 6 functional categories must have verified real records');

  // 4 explicitly empty provinces must remain honestly at 0 records
  assert.deepEqual(env.EMPTY_PROVINCES, ['بوشهر', 'خوزستان', 'زنجان', 'قم']);
  for (const emptyProv of env.EMPTY_PROVINCES) {
    const count = env.ACTIONS.filter((a) => a.province === emptyProv).length;
    assert.equal(count, 0, `Empty province ${emptyProv} must remain honestly at 0 records`);
  }

  // Every local editorial proof photo exists on disk (all 6 categories have distinct images)
  assert.equal(Object.keys(env.PROOF_PHOTOS).length, 6, 'All 6 functional categories must have a dedicated photo slot');
  assert.equal(new Set(Object.values(env.PROOF_PHOTOS)).size, 6, 'All 6 functional categories must use distinct photo files');
  for (const photoPath of Object.values(env.PROOF_PHOTOS)) {
    const abs = path.resolve(process.cwd(), photoPath.replace(/^\//, ''));
    assert.ok(fs.existsSync(abs), `Expected proof image on disk: ${photoPath}`);
  }
});

test('Functional category filter chips, distinct category colors, dynamic HUD stat, and «همکاری‌ها» tracks including بازی‌واره آموزشی', () => {
  const env = loadV3DataEnvironment();
  const script = extractScriptModule(html);

  assert.deepEqual(env.CATEGORIES, [
    'آموزش',
    'کمک به دیگران',
    'محیط زیست',
    'محله‌محور',
    'مهارت و فناوری',
    'سلامت',
  ]);

  // Distinct color for each of the 6 functional categories
  const colorValues = env.CATEGORIES.map((c) => env.CATEGORY_COLOR_MAP[c]);
  assert.equal(new Set(colorValues).size, 6, 'All 6 functional categories must have distinct hex colors');

  // Filtering by functional category works deterministically
  for (const cat of env.CATEGORIES) {
    const matched = env.ACTIONS.filter((a) => env.matchesFilters(a, { category: cat, topic: 'همه', province: 'همه', year: 'همه' }));
    assert.ok(matched.length >= 2, `Category "${cat}" should have >= 2 records`);
    for (const m of matched) assert.equal(m.category, cat);
  }

  // Dynamic HUD stat format for functional category
  assert.match(script, /اقدام در \$\{state\.filters\.category\}/);

  // Official collaboration tracks include بازی‌واره آموزشی
  assert.equal(env.OFFICIAL_TOPICS.length, 7);
  assert.ok(env.OFFICIAL_TOPICS.some((t) => t.name === 'بازی‌واره آموزشی'));
  for (const cat of env.CATEGORIES) {
    assert.equal(env.SUGGESTIONS_BY_CATEGORY[cat].length, 3);
    assert.equal(env.EDUCATION_LINKS[cat].length, 3);
  }
});

test('v1 3D Neural Sphere (Act 2) <-> Traced Iran Map (Act 3), 2-nearest-node light beams, and imperative PNG export', () => {
  const script = extractScriptModule(html);

  // Act 2 3D Fibonacci sphere + Act 3 Iran map morph + Act 3 invitation dock
  assert.match(script, /const sphereHubByCluster = new Map\(\)/);
  assert.match(html, /id="act3-map-btn"[^>]*>نمایش نقشه ایران</);
  assert.match(html, /id="act3-invite-dock"/);
  assert.match(html, /حالا تو چه سهمی در درخشش ایران داری؟/);
  assert.match(html, /id="act3-contribute-btn"[^>]*>یک اقدام انتخاب کن</);
  assert.match(html, /id="act2-return-btn"[^>]*>بازگشت به شبکه</);
  assert.match(html, /چطور اقدام خودم را اضافه کنم؟/);
  assert.match(html, /id="act3-finale-banner"/);
  assert.match(html, /یک نفر، یک اقدام\. هزاران نفر، یک قدرت\./);
  assert.match(script, /function enterAct3Map\(\)/);
  assert.match(script, /function returnToAct2Network\(\)/);
  assert.match(script, /function buildEdgesForMode\(nodes,\s*mode = 'cluster'\)/);
  assert.match(script, /return outVec\.set\(0,\s*18,\s*28\)/);

  // 2-nearest-node AdditiveBlending light beams (800ms draw -> permanent dim gold + wave)
  assert.match(script, /function findNearestExistingNodeIndices\(targetPos,\s*excludeIdx,\s*count = 2\)/);
  assert.match(script, /function createContributionLightBeam\(/);
  assert.match(script, /THREE\.AdditiveBlending/);
  assert.match(script, /setDrawRange/);
  assert.match(script, /beamDuration\s*=\s*0\.8/);
  assert.match(script, /triggerContributionWave\(origin\)/);
  assert.match(script, /hamdel_contributions/);
  assert.match(script, /markCurrentUserActionDone/);

  // Pure PNG image download with imperative copy (no navigator.share)
  assert.match(html, /ذخیره تصویر/);
  assert.match(html, /تصویرش را ذخیره کن و برای دوستانت بفرست!/);
  assert.match(script, /a\.download = 'hamdel\.png'/);
  assert.doesNotMatch(script, /navigator\.share/);
});

test('Traced Iran map (§2/§3), top typewriter guide tips, 15ms stats+actions feed, and README/.gitignore remain intact', () => {
  const env = loadV3DataEnvironment();
  const script = extractScriptModule(html);

  assert.ok(env.IRAN_BORDER_NORM.length >= 50);
  assert.equal(Object.keys(env.PROVINCE_CENTROIDS).length, 31);
  assert.match(html, /700 120px Vazirmatn/);
  assert.match(html, /ctx\.fillText\('ایران'/);
  assert.match(script, /بکش تا بچرخد/);
  assert.match(script, /لمس کن تا داستانش را بخوانی/);
  assert.match(script, /اقدام خودت را اضافه کن/);
  assert.match(script, /سامانه داده‌کاوی و نمایش اقدام‌های مردمی ایران/);
  assert.match(script, /function syncMobileDockHeight\(\)/);
  assert.match(html, /--mobile-dock-h/);
  assert.match(script, /\},\s*15\);/);
  assert.ok(fs.existsSync(path.resolve(process.cwd(), 'README.md')));
  assert.ok(fs.existsSync(path.resolve(process.cwd(), '.gitignore')));
});
