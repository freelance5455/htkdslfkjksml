package com.bluechat.messenger.privacy

import android.content.Context
import android.content.SharedPreferences

enum class LastSeenVisibility {
    EVERYONE, CONTACTS_ONLY, NOBODY
}

class PrivacyManager(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("bluechat_privacy_prefs", Context.MODE_PRIVATE)

    var showOnlineStatus: Boolean
        get() = prefs.getBoolean("show_online_status", true)
        set(value) = prefs.edit().putBoolean("show_online_status", value).apply()

    var lastSeenVisibility: LastSeenVisibility
        get() {
            val raw = prefs.getString("last_seen_visibility", LastSeenVisibility.EVERYONE.name)
            return LastSeenVisibility.valueOf(raw ?: LastSeenVisibility.EVERYONE.name)
        }
        set(value) = prefs.edit().putString("last_seen_visibility", value.name).apply()

    var sendReadReceipts: Boolean
        get() = prefs.getBoolean("send_read_receipts", true)
        set(value) = prefs.edit().putBoolean("send_read_receipts", value).apply()

    var displayName: String
        get() = prefs.getString("display_name", "BlueChat User") ?: "BlueChat User"
        set(value) = prefs.edit().putString("display_name", value).apply()

    var statusBio: String
        get() = prefs.getString("status_bio", "Available over Bluetooth") ?: "Available over Bluetooth"
        set(value) = prefs.edit().putString("status_bio", value).apply()

    /**
     * Builds the presence payload to broadcast over Bluetooth RFCOMM.
     * Respects reciprocal privacy rules (if you hide Last Seen, your timestamp is omitted).
     */
    fun buildPresencePayload(isCurrentlyActive: Boolean): Map<String, Any?> {
        val visibleOnline = if (showOnlineStatus) isCurrentlyActive else false
        val visibleLastSeen = when (lastSeenVisibility) {
            LastSeenVisibility.NOBODY -> null
            LastSeenVisibility.EVERYONE, LastSeenVisibility.CONTACTS_ONLY -> System.currentTimeMillis()
        }
        return mapOf(
            "displayName" to displayName,
            "statusBio" to statusBio,
            "isOnline" to visibleOnline,
            "lastSeenEpochMs" to visibleLastSeen,
            "readReceiptsEnabled" to sendReadReceipts
        )
    }
}
