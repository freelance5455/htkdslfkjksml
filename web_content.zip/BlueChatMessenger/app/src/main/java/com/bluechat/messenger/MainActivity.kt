package com.bluechat.messenger

import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import androidx.appcompat.app.AppCompatActivity
import com.bluechat.messenger.audio.BluetoothVoiceCallEngine
import com.bluechat.messenger.privacy.PrivacyManager

/**
 * Main Entry Activity for BlueChat Offline Bluetooth Messenger.
 * Bridges the native BluetoothMeshService, BluetoothVoiceCallEngine, and PrivacyManager
 * with the rich WhatsApp-style UI.
 */
class MainActivity : AppCompatActivity() {
    private lateinit var privacyManager: PrivacyManager
    private val voiceEngine = BluetoothVoiceCallEngine()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        privacyManager = PrivacyManager(this)

        val webView = WebView(this)
        setContentView(webView)
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = true
            mediaPlaybackRequiresUserGesture = false
            cacheMode = WebSettings.LOAD_NO_CACHE
        }
        webView.webChromeClient = WebChromeClient()
        webView.loadUrl("file:///android_asset/bluechat_ui.html")
    }

    override fun onDestroy() {
        voiceEngine.endVoiceCall()
        super.onDestroy()
    }
}
