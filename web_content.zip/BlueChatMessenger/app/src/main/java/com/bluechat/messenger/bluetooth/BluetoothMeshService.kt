package com.bluechat.messenger.bluetooth

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothServerSocket
import android.bluetooth.BluetoothSocket
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import kotlin.concurrent.thread

/**
 * Multiplexed Bluetooth Classic RFCOMM service supporting:
 * - Text Messages & Read Receipts
 * - Photo, Video, and Arbitrary File Transfers (Chunked Binary Stream)
 * - 24-Hour Status Broadcasts
 * - Online / Last Seen Presence Pings
 */
@SuppressLint("MissingPermission")
class BluetoothMeshService(
    private val adapter: BluetoothAdapter?,
    private val listener: Listener
) {
    companion object {
        const val SERVICE_NAME = "BlueChatOfflineMesh"
        val CHAT_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
        private const val CHUNK_SIZE = 16 * 1024 // 16 KB Bluetooth frame chunks

        const val FRAME_TEXT: Byte = 0x01
        const val FRAME_PHOTO: Byte = 0x02
        const val FRAME_VIDEO: Byte = 0x03
        const val FRAME_FILE: Byte = 0x04
        const val FRAME_STATUS: Byte = 0x05
        const val FRAME_PRESENCE: Byte = 0x06
        const val FRAME_READ_RECEIPT: Byte = 0x07
    }

    interface Listener {
        fun onPeerConnected(device: BluetoothDevice)
        fun onPeerDisconnected(address: String)
        fun onTextReceived(fromAddress: String, messageId: String, text: String, timestamp: Long)
        fun onMediaReceived(fromAddress: String, frameType: Byte, fileName: String, savedFile: File)
        fun onTransferProgress(address: String, fileName: String, percent: Int)
        fun onPresenceUpdated(fromAddress: String, isOnline: Boolean, lastSeenEpochMs: Long?)
        fun onStatusReceived(fromAddress: String, statusId: String, caption: String, mediaFile: File?)
        fun onReadReceipt(fromAddress: String, messageId: String)
    }

    private var serverSocket: BluetoothServerSocket? = null
    @Volatile private var running = false
    private val activeSockets = ConcurrentHashMap<String, BluetoothSocket>()

    fun startServer() {
        if (adapter == null || running) return
        running = true
        thread(name = "BT-AcceptThread", isDaemon = true) {
            try {
                serverSocket = adapter.listenUsingRfcommWithServiceRecord(SERVICE_NAME, CHAT_UUID)
                while (running) {
                    val socket = serverSocket?.accept() ?: break
                    handleConnectedSocket(socket)
                }
            } catch (_: IOException) {
            }
        }
    }

    fun connectToPeer(device: BluetoothDevice) {
        thread(name = "BT-Connect-${device.address}", isDaemon = true) {
            try {
                adapter?.cancelDiscovery()
                val socket = device.createRfcommSocketToServiceRecord(CHAT_UUID)
                socket.connect()
                handleConnectedSocket(socket)
            } catch (e: IOException) {
                listener.onPeerDisconnected(device.address)
            }
        }
    }

    private fun handleConnectedSocket(socket: BluetoothSocket) {
        val address = socket.remoteDevice.address
        activeSockets[address] = socket
        listener.onPeerConnected(socket.remoteDevice)

        thread(name = "BT-Reader-$address", isDaemon = true) {
            val input = DataInputStream(socket.inputStream)
            try {
                while (running && socket.isConnected) {
                    val frameType = input.readByte()
                    when (frameType) {
                        FRAME_TEXT -> {
                            val msgId = input.readUTF()
                            val text = input.readUTF()
                            val ts = input.readLong()
                            listener.onTextReceived(address, msgId, text, ts)
                        }
                        FRAME_PRESENCE -> {
                            val isOnline = input.readBoolean()
                            val hasLastSeen = input.readBoolean()
                            val lastSeen = if (hasLastSeen) input.readLong() else null
                            listener.onPresenceUpdated(address, isOnline, lastSeen)
                        }
                        FRAME_READ_RECEIPT -> {
                            val msgId = input.readUTF()
                            listener.onReadReceipt(address, msgId)
                        }
                        FRAME_PHOTO, FRAME_VIDEO, FRAME_FILE, FRAME_STATUS -> {
                            val metaId = input.readUTF()
                            val fileName = input.readUTF()
                            val totalBytes = input.readLong()
                            val outFile = File.createTempFile("bt_recv_", "_$fileName")
                            FileOutputStream(outFile).use { fos ->
                                val buf = ByteArray(CHUNK_SIZE)
                                var received = 0L
                                while (received < totalBytes) {
                                    val toRead = minOf(buf.size.toLong(), totalBytes - received).toInt()
                                    val read = input.read(buf, 0, toRead)
                                    if (read == -1) break
                                    fos.write(buf, 0, read)
                                    received += read
                                    val pct = ((received * 100) / totalBytes).toInt()
                                    listener.onTransferProgress(address, fileName, pct)
                                }
                            }
                            if (frameType == FRAME_STATUS) {
                                listener.onStatusReceived(address, metaId, fileName, outFile)
                            } else {
                                listener.onMediaReceived(address, frameType, fileName, outFile)
                            }
                        }
                    }
                }
            } catch (_: IOException) {
            } finally {
                activeSockets.remove(address)
                listener.onPeerDisconnected(address)
            }
        }
    }

    fun sendText(address: String, messageId: String, text: String) {
        val socket = activeSockets[address] ?: return
        thread {
            synchronized(socket) {
                val out = DataOutputStream(socket.outputStream)
                out.writeByte(FRAME_TEXT.toInt())
                out.writeUTF(messageId)
                out.writeUTF(text)
                out.writeLong(System.currentTimeMillis())
                out.flush()
            }
        }
    }

    fun sendPresence(address: String, isOnline: Boolean, lastSeenEpochMs: Long?) {
        val socket = activeSockets[address] ?: return
        thread {
            synchronized(socket) {
                val out = DataOutputStream(socket.outputStream)
                out.writeByte(FRAME_PRESENCE.toInt())
                out.writeBoolean(isOnline)
                out.writeBoolean(lastSeenEpochMs != null)
                if (lastSeenEpochMs != null) {
                    out.writeLong(lastSeenEpochMs)
                }
                out.flush()
            }
        }
    }

    fun sendMediaFile(address: String, frameType: Byte, metaId: String, file: File) {
        val socket = activeSockets[address] ?: return
        thread {
            synchronized(socket) {
                val out = DataOutputStream(socket.outputStream)
                out.writeByte(frameType.toInt())
                out.writeUTF(metaId)
                out.writeUTF(file.name)
                out.writeLong(file.length())
                FileInputStream(file).use { fis ->
                    val buf = ByteArray(CHUNK_SIZE)
                    var sent = 0L
                    val total = file.length()
                    while (true) {
                        val read = fis.read(buf)
                        if (read == -1) break
                        out.write(buf, 0, read)
                        sent += read
                        val pct = ((sent * 100) / total).toInt()
                        listener.onTransferProgress(address, file.name, pct)
                    }
                }
                out.flush()
            }
        }
    }

    fun stop() {
        running = false
        serverSocket?.close()
        activeSockets.values.forEach { it.close() }
        activeSockets.clear()
    }
}
