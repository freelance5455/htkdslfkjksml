package com.bluechat.messenger.audio

import android.annotation.SuppressLint
import android.bluetooth.BluetoothSocket
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import kotlin.concurrent.thread

/**
 * Full-Duplex Low-Latency Voice Call Engine over Bluetooth RFCOMM.
 * Captures 16 kHz 16-bit Mono PCM audio from the microphone and streams
 * it directly over the peer-to-peer Bluetooth socket with mute & speaker controls.
 */
@SuppressLint("MissingPermission")
class BluetoothVoiceCallEngine {
    companion object {
        private const val SAMPLE_RATE = 16000
    }

    @Volatile var isCallActive = false
        private set
    @Volatile var isMuted = false

    fun startVoiceCall(voiceSocket: BluetoothSocket) {
        if (isCallActive) return
        isCallActive = true

        val minRecordBuf = AudioRecord.getMinBufferSize(
            SAMPLE_RATE,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        ).coerceAtLeast(1280)

        val minPlayBuf = AudioTrack.getMinBufferSize(
            SAMPLE_RATE,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        ).coerceAtLeast(1280)

        // Uplink Thread: Mic -> Bluetooth Socket
        thread(name = "BT-VoiceUplink", isDaemon = true) {
            val recorder = AudioRecord(
                MediaRecorder.AudioSource.VOICE_COMMUNICATION,
                SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                minRecordBuf
            )
            val buf = ByteArray(640) // 20ms frame at 16kHz 16-bit mono
            val silence = ByteArray(640)
            try {
                recorder.startRecording()
                val out = voiceSocket.outputStream
                while (isCallActive && voiceSocket.isConnected) {
                    val read = recorder.read(buf, 0, buf.size)
                    if (read > 0) {
                        out.write(if (isMuted) silence else buf, 0, read)
                    }
                }
            } catch (_: Exception) {
            } finally {
                recorder.stop()
                recorder.release()
            }
        }

        // Downlink Thread: Bluetooth Socket -> EarPiece / Speaker
        thread(name = "BT-VoiceDownlink", isDaemon = true) {
            val player = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(SAMPLE_RATE)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(minPlayBuf)
                .build()

            val buf = ByteArray(640)
            try {
                player.play()
                val input = voiceSocket.inputStream
                while (isCallActive && voiceSocket.isConnected) {
                    val read = input.read(buf, 0, buf.size)
                    if (read > 0) {
                        player.write(buf, 0, read)
                    } else if (read == -1) {
                        break
                    }
                }
            } catch (_: Exception) {
            } finally {
                player.stop()
                player.release()
            }
        }
    }

    fun endVoiceCall() {
        isCallActive = false
    }
}
