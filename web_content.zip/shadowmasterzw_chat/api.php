<?php
require __DIR__ . '/config.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

function out($data, $status = 200) {
    http_response_code($status);
    echo json_encode($data, JSON_UNESCAPED_SLASHES);
    exit;
}
function body() {
    $data = json_decode(file_get_contents('php://input'), true);
    return is_array($data) ? $data : $_POST;
}
function need_login() {
    if (empty($_SESSION['uid'])) out(['ok'=>false, 'error'=>'Please log in first.'], 401);
    return (int)$_SESSION['uid'];
}
function clean_text($s, $max = 2000) {
    $s = trim((string)$s);
    if (mb_strlen($s) > $max) $s = mb_substr($s, 0, $max);
    return $s;
}
function save_upload($field, $allowed, $folder) {
    if (empty($_FILES[$field]) || $_FILES[$field]['error'] === UPLOAD_ERR_NO_FILE) return null;
    $f = $_FILES[$field];
    if ($f['error'] !== UPLOAD_ERR_OK || $f['size'] > MAX_UPLOAD_BYTES) out(['ok'=>false,'error'=>'Upload failed or file is too large (8 MB maximum).'], 400);
    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']);
    if (!isset($allowed[$mime])) out(['ok'=>false,'error'=>'This file type is not supported.'], 400);
    $dir = UPLOAD_DIR . '/' . $folder;
    if (!is_dir($dir)) mkdir($dir, 0755, true);
    $name = bin2hex(random_bytes(16)) . '.' . $allowed[$mime];
    if (!move_uploaded_file($f['tmp_name'], $dir . '/' . $name)) out(['ok'=>false,'error'=>'Could not save uploaded file.'], 500);
    return 'uploads/' . $folder . '/' . $name;
}
try {
    $pdo = db();
    $action = $_GET['action'] ?? '';
    $b = body();

    if ($action === 'register') {
        $name = clean_text($b['name'] ?? '', 40);
        $username = strtolower(clean_text($b['username'] ?? '', 24));
        $pass = (string)($b['password'] ?? '');
        if ($name === '' || !preg_match('/^[a-z0-9_]{3,24}$/', $username) || strlen($pass) < 8)
            out(['ok'=>false,'error'=>'Enter a name, username (3–24 letters/numbers/underscores) and password (at least 8 characters).'], 400);
        $q = $pdo->prepare('INSERT INTO users(name,username,password_hash) VALUES(?,?,?)');
        try { $q->execute([$name,$username,password_hash($pass,PASSWORD_DEFAULT)]); }
        catch (PDOException $e) { out(['ok'=>false,'error'=>'That username is already taken.'], 409); }
        session_regenerate_id(true);
        $_SESSION['uid'] = (int)$pdo->lastInsertId();
        out(['ok'=>true,'user'=>['id'=>$_SESSION['uid'],'name'=>$name,'username'=>$username]]);
    }

    if ($action === 'login') {
        $username = strtolower(clean_text($b['username'] ?? '', 24));
        $q = $pdo->prepare('SELECT id,name,username,password_hash,is_disabled FROM users WHERE username=?');
        $q->execute([$username]); $u = $q->fetch();
        if (!$u || (int)$u['is_disabled']===1 || !password_verify((string)($b['password'] ?? ''), $u['password_hash']))
            out(['ok'=>false,'error'=>'Incorrect username or password.'], 401);
        session_regenerate_id(true); $_SESSION['uid'] = (int)$u['id'];
        $pdo->prepare('UPDATE users SET last_seen=NOW() WHERE id=?')->execute([$u['id']]);
        out(['ok'=>true,'user'=>['id'=>(int)$u['id'],'name'=>$u['name'],'username'=>$u['username']]]);
    }

    if ($action === 'me') {
        $uid = need_login();
        $q=$pdo->prepare('SELECT id,name,username,about,profile_pic,is_admin,last_seen FROM users WHERE id=?');
        $q->execute([$uid]); out(['ok'=>true,'user'=>$q->fetch()]);
    }
    if ($action === 'logout') {
        $_SESSION = [];
        session_destroy();
        out(['ok'=>true]);
    }

    $uid = need_login();
    $pdo->prepare('UPDATE users SET last_seen=NOW() WHERE id=?')->execute([$uid]);

    if ($action === 'users') {
        $q=$pdo->prepare("SELECT id,name,username,profile_pic,(last_seen > NOW() - INTERVAL 90 SECOND) AS online FROM users WHERE id<>? ORDER BY name");
        $q->execute([$uid]); out(['ok'=>true,'users'=>$q->fetchAll()]);
    }

    if ($action === 'messages') {
        $other=(int)($_GET['with'] ?? 0);
        $pdo->prepare('UPDATE messages SET is_read=1 WHERE sender_id=? AND receiver_id=?')->execute([$other,$uid]);
        $q=$pdo->prepare('SELECT m.id,m.sender_id,m.receiver_id,m.message,m.media_url,m.media_type,m.is_read,m.created_at,u.name AS sender_name FROM messages m JOIN users u ON u.id=m.sender_id WHERE (m.sender_id=? AND m.receiver_id=?) OR (m.sender_id=? AND m.receiver_id=?) ORDER BY m.id DESC LIMIT 100');
        $q->execute([$uid,$other,$other,$uid]); $rows=array_reverse($q->fetchAll()); foreach($rows as &$row){$rq=$pdo->prepare('SELECT r.emoji,COUNT(*) AS total,SUM(r.user_id=?) AS mine FROM message_reactions r WHERE r.message_id=? GROUP BY r.emoji');$rq->execute([$uid,$row['id']]);$row['reactions']=$rq->fetchAll();} unset($row); out(['ok'=>true,'messages'=>$rows]);
    }
    if ($action === 'send_message') {
        $to=(int)($b['to'] ?? 0); $msg=clean_text($b['message'] ?? '',2000);
        if ($to===$uid || $to<1 || ($msg==='')) out(['ok'=>false,'error'=>'Write a message first.'],400);
        $q=$pdo->prepare('INSERT INTO messages(sender_id,receiver_id,message) SELECT ?,?,? WHERE EXISTS(SELECT id FROM users WHERE id=?)');
        $q->execute([$uid,$to,$msg,$to]);
        if (!$q->rowCount()) out(['ok'=>false,'error'=>'User not found.'],404);
        out(['ok'=>true]);
    }
    if ($action === 'send_audio') {
        $to=(int)($_POST['to'] ?? 0);
        if ($to<1 || $to===$uid) out(['ok'=>false,'error'=>'Invalid recipient.'],400);
        $url=save_upload('audio',['audio/webm'=>'webm','audio/ogg'=>'ogg','audio/mp4'=>'m4a','audio/mpeg'=>'mp3'],'audio');
        if (!$url) out(['ok'=>false,'error'=>'No audio received.'],400);
        $q=$pdo->prepare('INSERT INTO messages(sender_id,receiver_id,message,media_url,media_type) SELECT ?,?,?,?,? WHERE EXISTS(SELECT id FROM users WHERE id=?)');
        $q->execute([$uid,$to,'Voice message',$url,'audio',$to]);
        out(['ok'=>true]);
    }

    if ($action === 'statuses') {
        $q=$pdo->prepare('SELECT s.id,s.user_id,s.text,s.media_url,s.created_at,u.name,u.username FROM statuses s JOIN users u ON u.id=s.user_id WHERE s.created_at > NOW()-INTERVAL 24 HOUR ORDER BY s.created_at DESC');
        $q->execute(); out(['ok'=>true,'statuses'=>$q->fetchAll()]);
    }
    if ($action === 'status_create') {
        $text=clean_text($_POST['text'] ?? '',500);
        $url=save_upload('media',['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'],'status');
        if ($text==='' && !$url) out(['ok'=>false,'error'=>'Add text or choose a picture.'],400);
        $pdo->prepare('INSERT INTO statuses(user_id,text,media_url) VALUES(?,?,?)')->execute([$uid,$text,$url]);
        out(['ok'=>true]);
    }

    if ($action === 'channels') {
        $q=$pdo->prepare('SELECT c.id,c.name,c.description,c.owner_id,u.name AS owner_name,(SELECT COUNT(*) FROM channel_follows f WHERE f.channel_id=c.id) AS followers, EXISTS(SELECT 1 FROM channel_follows f WHERE f.channel_id=c.id AND f.user_id=?) AS following FROM channels c JOIN users u ON u.id=c.owner_id ORDER BY c.created_at DESC');
        $q->execute([$uid]); out(['ok'=>true,'channels'=>$q->fetchAll()]);
    }
    if ($action === 'channel_create') {
        $name=clean_text($b['name'] ?? '',60); $desc=clean_text($b['description'] ?? '',300);
        if ($name==='') out(['ok'=>false,'error'=>'Enter a channel name.'],400);
        $pdo->prepare('INSERT INTO channels(owner_id,name,description) VALUES(?,?,?)')->execute([$uid,$name,$desc]);
        out(['ok'=>true]);
    }
    if ($action === 'channel_follow') {
        $id=(int)($b['channel_id'] ?? 0);
        $q=$pdo->prepare('SELECT id FROM channel_follows WHERE channel_id=? AND user_id=?'); $q->execute([$id,$uid]);
        if ($q->fetch()) $pdo->prepare('DELETE FROM channel_follows WHERE channel_id=? AND user_id=?')->execute([$id,$uid]);
        else $pdo->prepare('INSERT IGNORE INTO channel_follows(channel_id,user_id) VALUES(?,?)')->execute([$id,$uid]);
        out(['ok'=>true]);
    }
    if ($action === 'channel_posts') {
        $id=(int)($_GET['channel_id'] ?? 0);
        $q=$pdo->prepare('SELECT p.id,p.text,p.created_at,u.name FROM channel_posts p JOIN users u ON u.id=p.user_id WHERE p.channel_id=? ORDER BY p.id DESC LIMIT 50');
        $q->execute([$id]); out(['ok'=>true,'posts'=>$q->fetchAll()]);
    }
    if ($action === 'channel_post') {
        $id=(int)($b['channel_id'] ?? 0); $msg=clean_text($b['text'] ?? '',2000);
        $q=$pdo->prepare('INSERT INTO channel_posts(channel_id,user_id,text) SELECT c.id,?,? FROM channels c WHERE c.id=? AND c.owner_id=?');
        $q->execute([$uid,$msg,$id,$uid]);
        if (!$q->rowCount()) out(['ok'=>false,'error'=>'Only the channel owner can publish there.'],403);
        out(['ok'=>true]);
    }


    if ($action === 'profile_update') {
        $name=clean_text($b['name'] ?? '',40); $about=clean_text($b['about'] ?? '',160);
        if ($name==='') out(['ok'=>false,'error'=>'Display name is required.'],400);
        $pic=save_upload('avatar',['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'],'avatars');
        if($pic) $pdo->prepare('UPDATE users SET name=?,about=?,profile_pic=? WHERE id=?')->execute([$name,$about,$pic,$uid]);
        else $pdo->prepare('UPDATE users SET name=?,about=? WHERE id=?')->execute([$name,$about,$uid]);
        out(['ok'=>true]);
    }
    if ($action === 'react') {
        $mid=(int)($b['message_id'] ?? 0); $emoji=(string)($b['emoji'] ?? '');
        if(!in_array($emoji,['❤️','🔥','😂','👍','🙏'],true)) out(['ok'=>false,'error'=>'Reaction not allowed.'],400);
        $q=$pdo->prepare('SELECT id FROM messages WHERE id=? AND (sender_id=? OR receiver_id=?)');$q->execute([$mid,$uid,$uid]);
        if(!$q->fetch()) out(['ok'=>false,'error'=>'Message not found.'],404);
        $q=$pdo->prepare('SELECT emoji FROM message_reactions WHERE message_id=? AND user_id=?');$q->execute([$mid,$uid]);$old=$q->fetchColumn();
        if($old===$emoji) $pdo->prepare('DELETE FROM message_reactions WHERE message_id=? AND user_id=?')->execute([$mid,$uid]);
        else $pdo->prepare('INSERT INTO message_reactions(message_id,user_id,emoji) VALUES(?,?,?) ON DUPLICATE KEY UPDATE emoji=VALUES(emoji)')->execute([$mid,$uid,$emoji]);
        out(['ok'=>true]);
    }
    if ($action === 'groups') {
        $q=$pdo->prepare('SELECT g.id,g.name,g.description,g.owner_id,(SELECT COUNT(*) FROM group_members gm WHERE gm.group_id=g.id) AS members FROM chat_groups g JOIN group_members mine ON mine.group_id=g.id AND mine.user_id=? ORDER BY g.created_at DESC');
        $q->execute([$uid]);out(['ok'=>true,'groups'=>$q->fetchAll()]);
    }
    if ($action === 'group_create') {
        $name=clean_text($b['name'] ?? '',60);$desc=clean_text($b['description'] ?? '',250);$members=$b['members']??[];
        if($name==='')out(['ok'=>false,'error'=>'Group name is required.'],400);
        $pdo->beginTransaction();$pdo->prepare('INSERT INTO chat_groups(owner_id,name,description) VALUES(?,?,?)')->execute([$uid,$name,$desc]);$gid=(int)$pdo->lastInsertId();
        $pdo->prepare('INSERT INTO group_members(group_id,user_id,role) VALUES(?,?,?)')->execute([$gid,$uid,'admin']);
        if(is_array($members)){foreach(array_unique(array_map('intval',$members)) as $member){if($member>0 && $member!==$uid)$pdo->prepare('INSERT IGNORE INTO group_members(group_id,user_id,role) SELECT ?,id,? FROM users WHERE id=?')->execute([$gid,'member',$member]);}}
        $pdo->commit();out(['ok'=>true,'group_id'=>$gid]);
    }
    if ($action === 'group_messages') {
        $gid=(int)($_GET['group_id']??0);$q=$pdo->prepare('SELECT role FROM group_members WHERE group_id=? AND user_id=?');$q->execute([$gid,$uid]);if(!$q->fetch())out(['ok'=>false,'error'=>'You are not a member of this group.'],403);
        $q=$pdo->prepare('SELECT gm.id,gm.user_id AS sender_id,gm.message,gm.created_at,u.name AS sender_name FROM group_messages gm JOIN users u ON u.id=gm.user_id WHERE gm.group_id=? ORDER BY gm.id DESC LIMIT 100');$q->execute([$gid]);out(['ok'=>true,'messages'=>array_reverse($q->fetchAll())]);
    }
    if ($action === 'group_send') {
        $gid=(int)($b['group_id']??0);$msg=clean_text($b['message']??'',2000);if($msg==='')out(['ok'=>false,'error'=>'Write a message.'],400);
        $q=$pdo->prepare('INSERT INTO group_messages(group_id,user_id,message) SELECT ?,?,? WHERE EXISTS(SELECT 1 FROM group_members WHERE group_id=? AND user_id=?)');$q->execute([$gid,$uid,$msg,$gid,$uid]);if(!$q->rowCount())out(['ok'=>false,'error'=>'You are not a member of this group.'],403);out(['ok'=>true]);
    }
    if ($action === 'admin_overview') {
        $q=$pdo->prepare('SELECT is_admin FROM users WHERE id=?');$q->execute([$uid]);if(!(int)$q->fetchColumn())out(['ok'=>false,'error'=>'Admin access is not enabled for this account.'],403);
        $stats=['users'=>(int)$pdo->query('SELECT COUNT(*) FROM users')->fetchColumn(),'groups'=>(int)$pdo->query('SELECT COUNT(*) FROM chat_groups')->fetchColumn(),'channels'=>(int)$pdo->query('SELECT COUNT(*) FROM channels')->fetchColumn(),'messages'=>(int)$pdo->query('SELECT COUNT(*) FROM messages')->fetchColumn()];
        $list=$pdo->query('SELECT id,name,username,created_at FROM users ORDER BY id DESC LIMIT 100')->fetchAll();out(['ok'=>true,'stats'=>$stats,'users'=>$list]);
    }
    if ($action === 'admin_toggle_user') {
        $q=$pdo->prepare('SELECT is_admin FROM users WHERE id=?');$q->execute([$uid]);if(!(int)$q->fetchColumn())out(['ok'=>false,'error'=>'Admin access denied.'],403);
        $target=(int)($b['user_id']??0);if($target===$uid)out(['ok'=>false,'error'=>'You cannot disable your own account.'],400);
        $pdo->prepare('UPDATE users SET is_disabled=1-is_disabled WHERE id=?')->execute([$target]);out(['ok'=>true]);
    }

    out(['ok'=>false,'error'=>'Unknown action.'],404);
} catch (Throwable $e) {
    error_log($e);
    out(['ok'=>false,'error'=>'Server error. Check your database setup and PHP error log.'],500);
}
