SHADOWMASTERZW CHAT V2 — InfinityFree setup

PACKAGE FILES
- index.html: responsive V2 interface
- api.php: PHP API
- config.php: database connection settings
- schema.sql: original database tables
- migration_v2.sql: V2 database upgrade
- uploads.htaccess: upload-folder protection rules

INSTALL / UPGRADE
1. Back up your current database and website files first.
2. In InfinityFree, open phpMyAdmin for the existing SHADOWMASTERZW CHAT database.
3. Run migration_v2.sql ONCE. If you are installing fresh, first import schema.sql, then run migration_v2.sql.
4. Keep your existing config.php credentials. If this is a fresh install, enter the exact database host, name, username and password shown by InfinityFree.
5. Upload/replace index.html and api.php in htdocs. Keep config.php unchanged if its database credentials are already correct.
6. Create htdocs/uploads and place uploads.htaccess inside it. PHP creates audio, status and avatars subfolders.
7. Visit the HTTPS site and sign in with your existing account.

ENABLE YOUR ADMIN ACCOUNT
After signing in, find your numeric user ID in phpMyAdmin > users, then run: UPDATE users SET is_admin=1 WHERE id=YOUR_ID;
Replace YOUR_ID with your actual numeric ID. Do not make public users admins.

V2 FEATURES
- Profile display name, about text and profile picture
- Group creation and group messaging; add members by comma-separated usernames
- Reactions to private messages: ❤️ 🔥 😂 👍 🙏
- Read receipts for private messages (read when recipient opens conversation)
- Browser notifications while the website is open and permission is granted
- Status updates and channels retained from V1
- Admin overview and account disable/enable controls

IMPORTANT LIMITATIONS
- Shared hosting uses short polling; this is not a WebSocket live-chat system. Messages refresh about every 3 seconds while a conversation is open.
- Browser notifications in this build work while the site is open. True background push notifications need a service worker plus a push service/server support.
- Voice recording requires HTTPS and microphone permission.
- This starter is not end-to-end encrypted. Do not use it for sensitive conversations.
- Before public launch, add stronger abuse prevention, blocking/reporting, moderation, privacy policy, backups and security review.
- Do not share database credentials. Keep config.php private.
