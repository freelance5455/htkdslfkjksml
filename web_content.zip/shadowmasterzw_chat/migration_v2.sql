-- Run this ONCE in phpMyAdmin on your existing SHADOWMASTERZW CHAT database.
ALTER TABLE users ADD COLUMN profile_pic VARCHAR(255) DEFAULT NULL, ADD COLUMN is_admin TINYINT(1) NOT NULL DEFAULT 0, ADD COLUMN is_disabled TINYINT(1) NOT NULL DEFAULT 0;
CREATE TABLE message_reactions (
  message_id BIGINT UNSIGNED NOT NULL,
  user_id INT UNSIGNED NOT NULL,
  emoji VARCHAR(8) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY(message_id,user_id),
  CONSTRAINT fk_reaction_message FOREIGN KEY(message_id) REFERENCES messages(id) ON DELETE CASCADE,
  CONSTRAINT fk_reaction_user FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE chat_groups (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  owner_id INT UNSIGNED NOT NULL,
  name VARCHAR(60) NOT NULL,
  description VARCHAR(250) DEFAULT '',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_group_owner FOREIGN KEY(owner_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE group_members (
  group_id INT UNSIGNED NOT NULL,
  user_id INT UNSIGNED NOT NULL,
  role ENUM('admin','member') NOT NULL DEFAULT 'member',
  joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY(group_id,user_id),
  CONSTRAINT fk_member_group FOREIGN KEY(group_id) REFERENCES chat_groups(id) ON DELETE CASCADE,
  CONSTRAINT fk_member_user FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE group_messages (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  group_id INT UNSIGNED NOT NULL,
  user_id INT UNSIGNED NOT NULL,
  message TEXT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX(group_id,id),
  CONSTRAINT fk_gmsg_group FOREIGN KEY(group_id) REFERENCES chat_groups(id) ON DELETE CASCADE,
  CONSTRAINT fk_gmsg_user FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
-- After registering your own account, replace 1 with your actual user ID:
-- UPDATE users SET is_admin=1 WHERE id=1;
