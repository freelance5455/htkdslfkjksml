package com.example.discipline;
import android.app.*;import android.content.*;import android.os.Build;
public class ReminderReceiver extends BroadcastReceiver {
 public void onReceive(Context context,Intent intent){String channel="discipline_reminders";NotificationManager nm=(NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);if(Build.VERSION.SDK_INT>=26){NotificationChannel ch=new NotificationChannel(channel,"Напоминания",NotificationManager.IMPORTANCE_DEFAULT);nm.createNotificationChannel(ch);}Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(context,channel):new Notification.Builder(context);b.setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle("Дисциплина").setContentText("Время действовать! Не забудь выполнить свои задачи 💪").setAutoCancel(true);nm.notify(1,b.build());}
}
