package com.example.discipline;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout list; TextView count; ArrayList<String> tasks = new ArrayList<>();
    ArrayList<Boolean> done = new ArrayList<>();
    int purple = Color.rgb(112,67,220);
    public void onCreate(Bundle b){super.onCreate(b); getWindow().setStatusBarColor(Color.rgb(23,19,33)); getWindow().setNavigationBarColor(Color.rgb(23,19,33));
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},7);
        tasks.add("Сделать зарядку");tasks.add("Учиться 1 час");tasks.add("Прочитать Коран");tasks.add("Помочь дома"); for(int i=0;i<tasks.size();i++)done.add(false);
        LinearLayout root=new LinearLayout(this);root.setOrientation(1);root.setPadding(22,24,22,20);root.setBackgroundColor(Color.rgb(17,16,25));setContentView(root);
        TextView title=new TextView(this);title.setText("👑  Дисциплина");title.setTextColor(Color.WHITE);title.setTextSize(30);title.setTypeface(null,1);root.addView(title);
        TextView sub=new TextView(this);sub.setText("Становись лучше каждый день!");sub.setTextColor(0xffc8c3d8);sub.setTextSize(16);sub.setPadding(0,5,0,20);root.addView(sub);
        TextView quote=new TextView(this);quote.setText("ТЫ МОЖЕШЬ БОЛЬШЕ!  💪");quote.setTextColor(Color.WHITE);quote.setTextSize(18);quote.setPadding(16,18,16,18);quote.setBackgroundColor(0xff292338);root.addView(quote);
        count=new TextView(this);count.setTextColor(Color.WHITE);count.setTextSize(20);count.setPadding(0,22,0,12);root.addView(count);
        ScrollView scroll=new ScrollView(this);list=new LinearLayout(this);list.setOrientation(1);scroll.addView(list);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));render();
        Button add=button("＋  Добавить задачу");root.addView(add);add.setOnClickListener(v->{EditText input=new EditText(this);input.setHint("Например: прочитать 10 страниц");new AlertDialog.Builder(this).setTitle("Новая задача").setView(input).setPositiveButton("Добавить",(d,w)->{String s=input.getText().toString().trim();if(!s.isEmpty()){tasks.add(s);done.add(false);render();}}).setNegativeButton("Отмена",null).show();});
        Button reminder=button("🔔  Настроить напоминание");root.addView(reminder);reminder.setOnClickListener(v->pickTime());
    }
    Button button(String s){Button b=new Button(this);b.setText(s);b.setTextColor(Color.WHITE);b.setTextSize(15);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(purple));return b;}
    void render(){list.removeAllViews();int n=0;for(boolean x:done)if(x)n++;count.setText("Сегодняшние задачи   "+n+" / "+tasks.size());for(int i=0;i<tasks.size();i++){final int k=i;CheckBox c=new CheckBox(this);c.setText(tasks.get(i));c.setTextSize(17);c.setTextColor(Color.WHITE);c.setButtonTintList(android.content.res.ColorStateList.valueOf(0xffa98cff));c.setPadding(8,9,8,9);c.setChecked(done.get(i));c.setOnCheckedChangeListener((v,checked)->{done.set(k,checked);render();});list.addView(c);}}
    void pickTime(){Calendar now=Calendar.getInstance();new TimePickerDialog(this,(view,hour,min)->{Calendar c=Calendar.getInstance();c.set(Calendar.HOUR_OF_DAY,hour);c.set(Calendar.MINUTE,min);c.set(Calendar.SECOND,0);if(c.getTimeInMillis()<=System.currentTimeMillis())c.add(Calendar.DAY_OF_YEAR,1);Intent i=new Intent(this,ReminderReceiver.class);PendingIntent pi=PendingIntent.getBroadcast(this,1,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);AlarmManager am=(AlarmManager)getSystemService(ALARM_SERVICE);am.setInexactRepeating(AlarmManager.RTC_WAKEUP,c.getTimeInMillis(),AlarmManager.INTERVAL_DAY,pi);Toast.makeText(this,String.format(Locale.getDefault(),"Напоминание каждый день в %02d:%02d",hour,min),Toast.LENGTH_LONG).show();},now.get(Calendar.HOUR_OF_DAY),now.get(Calendar.MINUTE),true).show();}
}
