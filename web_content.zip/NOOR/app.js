const $ = (s, root=document) => root.querySelector(s);
const $$ = (s, root=document) => [...root.querySelectorAll(s)];
const API_Q = 'https://api.alquran.cloud/v1';
const API_P = 'https://api.aladhan.com/v1';
const API_QE = 'https://quranenc.com/api/v1';
const QURAN_LANGUAGES = [
  ['en','English','English','en.sahih'],['ar','العربية','Arabic',null],['ur','اردو','Urdu',null],['ta','தமிழ்','Tamil',null],['bn','বাংলা','Bengali',null],['id','Bahasa Indonesia','Indonesian',null],['ms','Bahasa Melayu','Malay',null],['tr','Türkçe','Turkish',null],['fr','Français','French',null],['es','Español','Spanish',null],['ru','Русский','Russian',null],['zh','中文','Chinese',null],['hi','हिन्दी','Hindi',null],['fa','فارسی','Persian',null],['de','Deutsch','German',null],['sw','Kiswahili','Swahili',null],['ha','Hausa','Hausa',null],['ps','پښتو','Pashto',null],['ku','کوردی','Kurdish',null],['so','Soomaali','Somali',null],['it','Italiano','Italian',null],['nl','Nederlands','Dutch',null],['sq','Shqip','Albanian',null]
];
let translationEdition = localStorage.getItem('noor-quran-edition') || 'en.sahih';
let translationLanguage = localStorage.getItem('noor-quran-language') || 'en';
let translationName = localStorage.getItem('noor-quran-translation-name') || 'Sahih International';
let translationCatalog = [];
const LANG_LABELS = {en:'English',ar:'Arabic',ur:'Urdu',ta:'Tamil',bn:'Bengali',id:'Indonesian',ms:'Malay',tr:'Turkish',fr:'French',es:'Spanish',ru:'Russian',zh:'Chinese',hi:'Hindi',fa:'Persian',de:'German',sw:'Swahili',ha:'Hausa',ps:'Pashto',ku:'Kurdish',so:'Somali',it:'Italian',nl:'Dutch',sq:'Albanian',pt:'Portuguese',az:'Azerbaijani',vi:'Vietnamese',si:'Sinhala',tl:'Filipino',am:'Amharic',as:'Assamese',ja:'Japanese',ko:'Korean',th:'Thai',uz:'Uzbek',kk:'Kazakh',ug:'Uyghur',yo:'Yoruba',wo:'Wolof',fa:'Persian',ne:'Nepali',om:'Oromo',sw:'Swahili'};
const RIYADH = {city:'Riyadh', country:'Saudi Arabia', lat:24.7136, lon:46.6753};
let prayerLocation = (()=>{try{return JSON.parse(localStorage.getItem('noor-prayer-location'))||{city:'Riyadh',country:'Saudi Arabia',lat:24.7136,lon:46.6753};}catch{return {city:'Riyadh',country:'Saudi Arabia',lat:24.7136,lon:46.6753};}})();
const KAABA = {lat:21.422487, lon:39.826206};
const PRAYERS = ['Fajr','Dhuhr','Asr','Maghrib','Isha'];
const ALL_PRAYERS = ['Fajr','Sunrise','Dhuhr','Asr','Maghrib','Isha'];
const SURAH_NAMES_FALLBACK = ['Al-Fatihah','Al-Baqarah','Ali Imran','An-Nisa','Al-Maidah','Al-Anam','Al-Araf','Al-Anfal','At-Tawbah','Yunus','Hud','Yusuf','Ar-Rad','Ibrahim','Al-Hijr','An-Nahl','Al-Isra','Al-Kahf','Maryam','Ta-Ha','Al-Anbiya','Al-Hajj','Al-Muminun','An-Nur','Al-Furqan','Ash-Shuara','An-Naml','Al-Qasas','Al-Ankabut','Ar-Rum','Luqman','As-Sajdah','Al-Ahzab','Saba','Fatir','Ya-Sin','As-Saffat','Sad','Az-Zumar','Ghafir','Fussilat','Ash-Shura','Az-Zukhruf','Ad-Dukhan','Al-Jathiyah','Al-Ahqaf','Muhammad','Al-Fath','Al-Hujurat','Qaf','Adh-Dhariyat','At-Tur','An-Najm','Al-Qamar','Ar-Rahman','Al-Waqiah','Al-Hadid','Al-Mujadila','Al-Hashr','Al-Mumtahanah','As-Saff','Al-Jumuah','Al-Munafiqun','At-Taghabun','At-Talaq','At-Tahrim','Al-Mulk','Al-Qalam','Al-Haqqah','Al-Maarij','Nuh','Al-Jinn','Al-Muzzammil','Al-Muddaththir','Al-Qiyamah','Al-Insan','Al-Mursalat','An-Naba','An-Naziat','Abasa','At-Takwir','Al-Infitar','Al-Mutaffifin','Al-Inshiqaq','Al-Buruj','At-Tariq','Al-Ala','Al-Ghashiyah','Al-Fajr','Al-Balad','Ash-Shams','Al-Layl','Ad-Duha','Ash-Sharh','At-Tin','Al-Alaq','Al-Qadr','Al-Bayyinah','Az-Zalzalah','Al-Adiyat','Al-Qariah','At-Takathur','Al-Asr','Al-Humazah','Al-Fil','Quraysh','Al-Maun','Al-Kawthar','Al-Kafirun','An-Nasr','Al-Masad','Al-Ikhlas','Al-Falaq','An-Nas'];
let surahs = [], currentSurah = 1, currentVerses = [], currentAudio = null, currentAudioIndex = -1, audioToken = 0, paused = false, prayerData = null, prayerTimer = null, notificationTimer = null, qiblaBearing = 0, compassListening = false, customAdhanUrl = null;
let selectedReciter=localStorage.getItem('noor-reciter')||'ar.alafasy', memorizePage=Number(localStorage.getItem('noor-memorize-page')||1), memorizedPages=new Set(JSON.parse(localStorage.getItem('noor-memorized-pages')||'[]')), memorizeVerses=[], memorizeHidden=false, memorizeAudioToken=0, memorizeAudio=null, memorizeAudioStop=null;
let hifzMeta=(()=>{try{return JSON.parse(localStorage.getItem('noor-hifz-meta')||'{}')}catch{return {}}})();
let hifzTarget=Number(localStorage.getItem('noor-hifz-target')||1);
let daily = loadDaily();
let tasbeeh = loadTasbeeh();
let customCounters = JSON.parse(localStorage.getItem('noor-custom-counters') || '[]');
let lastRead = JSON.parse(localStorage.getItem('noor-last-read') || '{"surah":1,"ayah":1}');
let bookmarks = JSON.parse(localStorage.getItem('noor-bookmarks') || '[]');
let offlineSurahIds = JSON.parse(localStorage.getItem('noor-offline-surah-ids') || '[]');

function todayKey(){ const d=new Date(); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`; }
function loadDaily(){ const key=todayKey(); try {const old=JSON.parse(localStorage.getItem('noor-daily')||'{}'); return old.date===key?old:{date:key,readAyahs:[],dhikr:0,prayers:{}};}catch{return {date:key,readAyahs:[],dhikr:0,prayers:{}};} }
function saveDaily(){localStorage.setItem('noor-daily',JSON.stringify(daily));renderProgress();}
function loadTasbeeh(){try{const o=JSON.parse(localStorage.getItem('noor-tasbeeh')||'{}');return o.date===todayKey()?o:{date:todayKey(),counts:[0,0,0],step:0};}catch{return {date:todayKey(),counts:[0,0,0],step:0};}}
function saveTasbeeh(){localStorage.setItem('noor-tasbeeh',JSON.stringify(tasbeeh));}
function esc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function toast(msg){const el=$('#toast');el.textContent=msg;el.classList.add('show');clearTimeout(toast.timer);toast.timer=setTimeout(()=>el.classList.remove('show'),2400);}
function dateLabel(){const d=new Date();$('#today-label').textContent=d.toLocaleDateString('en-SA',{weekday:'short',day:'numeric',month:'short'});}
function setView(name){
  $$('.view').forEach(v=>v.classList.toggle('active',v.id===`view-${name}`));
  $$('.nav-item').forEach(b=>b.classList.toggle('active',b.dataset.view===name));
  const names={home:'Overview',quran:'The Quran',memorize:'Memorize Quran',prayer:'Prayer times',dhikr:'Dhikr counter',duas:'Duas & Adhkar',learn:'Learn Islam',saved:'Saved items',settings:'Settings'};
  $('#page-title').textContent=names[name]||'NOOR';
  $('#sidebar').classList.remove('open');
  if(name==='saved')renderSaved();
  if(name==='quran')renderQuranAside();
  const jump=$('#ayah-jump-fab');if(jump)jump.hidden=name!=='quran';
  if(name==='memorize')loadMemorizePage(memorizePage);
}
$$('[data-view]').forEach(b=>b.addEventListener('click',()=>setView(b.dataset.view)));
$$('[data-go]').forEach(b=>b.addEventListener('click',()=>setView(b.dataset.go)));
$('#menu-toggle').addEventListener('click',()=>$('#sidebar').classList.toggle('open'));
$('#theme-toggle').addEventListener('click',()=>setTheme(document.body.classList.contains('light')?'dark':'light'));
function setTheme(theme){document.body.classList.toggle('light',theme==='light');localStorage.setItem('noor-theme',theme);}
setTheme(localStorage.getItem('noor-theme')||'dark');
dateLabel();

function idbOpen(){
  return new Promise((resolve,reject)=>{
    if(!('indexedDB' in window)){reject(new Error('IndexedDB unavailable'));return;}
    const req=indexedDB.open('NOOR-Local',1);
    req.onupgradeneeded=()=>{const db=req.result;if(!db.objectStoreNames.contains('surahs'))db.createObjectStore('surahs',{keyPath:'number'});if(!db.objectStoreNames.contains('files'))db.createObjectStore('files');};
    req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error);
  });
}
async function idbPut(store,value,key){
  const db=await idbOpen();return new Promise((resolve,reject)=>{const tx=db.transaction(store,'readwrite');const req=key===undefined?tx.objectStore(store).put(value):tx.objectStore(store).put(value,key);req.onsuccess=()=>resolve(true);req.onerror=()=>reject(req.error);tx.oncomplete=()=>db.close();});
}
async function idbGet(store,key){
  const db=await idbOpen();return new Promise((resolve,reject)=>{const tx=db.transaction(store,'readonly');const req=tx.objectStore(store).get(key);req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error);tx.oncomplete=()=>db.close();});
}
async function idbAll(store){
  const db=await idbOpen();return new Promise((resolve,reject)=>{const tx=db.transaction(store,'readonly');const req=tx.objectStore(store).getAll();req.onsuccess=()=>resolve(req.result||[]);req.onerror=()=>reject(req.error);tx.oncomplete=()=>db.close();});
}

function setConnection(){
  const online=navigator.onLine;
  $('#online-dot').parentElement.classList.toggle('online',online);
  $('#online-dot').parentElement.classList.toggle('offline',!online);
  $('#online-label').textContent=online?'Online':'Offline mode';
  $('#footer-connection').textContent=online?'Online services connected':'Offline · cached/local content only';
}
window.addEventListener('online',setConnection);window.addEventListener('offline',setConnection);setConnection();

async function loadSurahIndex(){
  try{
    const r=await fetch(`${API_Q}/surah`,{cache:'no-cache'});if(!r.ok)throw new Error('Quran index request failed');
    const j=await r.json();if(j.code!==200||!Array.isArray(j.data))throw new Error('Unexpected Quran index response');
    surahs=j.data;localStorage.setItem('noor-surah-index',JSON.stringify(surahs));
  }catch(e){
    try{surahs=JSON.parse(localStorage.getItem('noor-surah-index')||'[]');}catch{surahs=[];}
    if(!surahs.length){surahs=SURAH_NAMES_FALLBACK.map((englishName,i)=>({number:i+1,englishName,name:'',numberOfAyahs:0,revelationType:''}));}
    toast('Using saved Quran index. Some online features may be unavailable.');
  }
  $('#surah-select').innerHTML=surahs.map(s=>`<option value="${s.number}">${String(s.number).padStart(3,'0')} · ${esc(s.englishName)} ${s.name?`· ${esc(s.name)}`:''}</option>`).join('');
  const resume=Number(lastRead.surah)||1;$('#surah-select').value=String(resume);
  await loadSurah(resume,Number(lastRead.ayah)||1);
}
async function fetchSurah(n){
  const arabicPromise=fetch(`${API_Q}/surah/${n}/quran-uthmani`).then(async r=>{if(!r.ok)throw new Error('Arabic Quran request failed');const j=await r.json();if(j.code!==200||!j.data?.ayahs)throw new Error('Arabic Quran data unavailable');return j.data;});
  let translationPromise;
  if(translationEdition.startsWith('quranenc:')){
    const key=translationEdition.slice('quranenc:'.length);
    translationPromise=fetch(`${API_QE}/translation/sura/${encodeURIComponent(key)}/${n}`).then(async r=>{if(!r.ok)throw new Error('This translation could not be loaded');const j=await r.json();if(!Array.isArray(j.result))throw new Error('Unexpected translation response');return j.result;});
  }else{
    translationPromise=fetch(`${API_Q}/surah/${n}/${encodeURIComponent(translationEdition)}`).then(async r=>{if(!r.ok)throw new Error('Translation request failed');const j=await r.json();if(j.code!==200||!j.data?.ayahs)throw new Error('Translation data unavailable');return j.data.ayahs.map(a=>({aya:a.numberInSurah,translation:a.text}));});
  }
  const [ar,translated]=await Promise.all([arabicPromise,translationPromise]);
  const byAyah=new Map(translated.map(a=>[Number(a.aya??a.numberInSurah),a.translation]));
  return {number:n,name:ar.englishName||surahs.find(s=>s.number===n)?.englishName||`Surah ${n}`,arabicName:ar.name||'',revelationType:ar.revelationType||'',translationEdition,translationName,ayahs:ar.ayahs.map(a=>({number:a.numberInSurah,globalNumber:a.number,text:a.text,translation:byAyah.get(a.numberInSurah)||''}))};
}
async function loadSurah(n,scrollToAyah=null){
  stopAudio();currentSurah=n;$('#surah-select').value=String(n);$('#ayah-list').innerHTML='<div class="panel empty-state"><div class="loader"></div><p>Loading Surah…</p></div>';
  let data=null,offline=false;
  try{data=await fetchSurah(n);}catch(e){
    try{data=await idbGet('surahs',n);offline=!!data&&(data.translationEdition===translationEdition||(!data.translationEdition&&translationEdition==='en.sahih'));if(!offline)data=null;}catch{}
    if(!data){$('#ayah-list').innerHTML=`<div class="panel empty-state"><p>Could not load this Surah. Connect to the internet or open a Surah you saved offline.</p><small>${esc(e.message)}</small></div>`;$('#audio-state').textContent='Quran text unavailable.';return;}
  }
  currentVerses=data.ayahs||[];$('#surah-title').textContent=data.name;$('#surah-meta').textContent=`SURAH ${n} · ${data.revelationType||'QURAN'}`.toUpperCase();$('#surah-subtitle').textContent=`${data.arabicName||''} · ${currentVerses.length} Ayahs${offline?' · Offline copy':''}`;
  $('#quran-cache-state').textContent=offline?`Showing saved offline text (${data.translationName||translationName}). Audio still needs internet.`:`Quran text from AlQuran Cloud · ${data.translationName||translationName} translation.`;
  renderAyahs();$('#audio-state').textContent=`${data.name} ready · Mishary Alafasy`;$('#audio-position').textContent=`${currentVerses.length} ayahs`;
  if(scrollToAyah){const idx=currentVerses.findIndex(a=>a.number===scrollToAyah);if(idx>=0)setTimeout(()=>focusAyah(idx,false),120);}
  if(lastRead.surah===n)renderQuranAside();
}
function renderAyahs(){
  $('#ayah-list').innerHTML=currentVerses.map((a,i)=>`<article class="ayah-card" id="ayah-${i}" data-index="${i}">
    <div class="ayah-top"><span class="ayah-number">${a.number} · ${currentSurah}:${a.number}</span><div class="ayah-actions"><button data-play-index="${i}">▶ Play from here</button><button data-bookmark-index="${i}">☆ Save</button></div></div>
    <div class="ayah-arabic" lang="ar" dir="rtl">${esc(a.text)}</div>
    <div class="ayah-translation"><span class="translation-label">${esc(translationName)} · ${esc(LANG_LABELS[translationLanguage]||QURAN_LANGUAGES.find(x=>x[0]===translationLanguage)?.[1]||'English')}</span>${esc(a.translation)}</div>
  </article>`).join('');
  $$('#ayah-list [data-play-index]').forEach(b=>b.addEventListener('click',()=>playAt(Number(b.dataset.playIndex))));
  $$('#ayah-list [data-bookmark-index]').forEach(b=>b.addEventListener('click',()=>addBookmark(Number(b.dataset.bookmarkIndex))));
  $$('.ayah-card').forEach(card=>card.addEventListener('click',e=>{if(e.target.closest('button'))return;focusAyah(Number(card.dataset.index),true);}));
  if(lastRead.surah===currentSurah){const idx=currentVerses.findIndex(a=>a.number===lastRead.ayah);if(idx>=0)$('#ayah-'+idx)?.classList.add('selected');}
}
function focusAyah(i,markRead=true){
  const el=$(`#ayah-${i}`);if(!el)return;
  $$('.ayah-card.selected').forEach(x=>x.classList.remove('selected'));el.classList.add('selected');
  el.scrollIntoView({behavior:'smooth',block:'center'});
  if(markRead)recordRead(currentSurah,currentVerses[i].number);
}
function recordRead(surah,ayah){
  lastRead={surah,ayah};localStorage.setItem('noor-last-read',JSON.stringify(lastRead));
  const key=`${surah}:${ayah}`;if(!daily.readAyahs.includes(key))daily.readAyahs.push(key);saveDaily();
  $('#continue-title').textContent=surahs.find(s=>s.number===surah)?.englishName||`Surah ${surah}`;$('#continue-subtitle').textContent=`Continue from ayah ${ayah}.`;
  renderQuranAside();
}
function renderQuranAside(){
  $('#aside-last-read').textContent=`${lastRead.surah}:${lastRead.ayah}`;
  $('#aside-last-name').textContent=(surahs.find(s=>s.number===lastRead.surah)?.englishName||`Surah ${lastRead.surah}`)+` · Ayah ${lastRead.ayah}`;
  $('#quran-goal-count').textContent=`${Math.min(daily.readAyahs.length,10)} / 10 today`;
  $('#quran-goal-bar').style.width=`${Math.min(100,daily.readAyahs.length/10*100)}%`;
}
$('#load-surah').addEventListener('click',()=>loadSurah(Number($('#surah-select').value)));
$('#surah-select').addEventListener('change',()=>loadSurah(Number($('#surah-select').value)));
$('#jump-last').addEventListener('click',()=>{if(currentSurah!==lastRead.surah)loadSurah(lastRead.surah,lastRead.ayah);else{const i=currentVerses.findIndex(a=>a.number===lastRead.ayah);focusAyah(Math.max(i,0),false);}});
$('#ayah-jump-fab').addEventListener('click',()=>{const targetIndex=currentAudioIndex>=0?currentAudioIndex:currentVerses.findIndex(a=>a.number===lastRead.ayah);const el=$(`#ayah-${Math.max(0,targetIndex)}`);if(el)el.scrollIntoView({behavior:'smooth',block:'center'});else toast('Play an ayah or choose a reading position first.');});
$('#download-surah').addEventListener('click',async()=>{
  if(!currentVerses.length){toast('Load a Surah first.');return;}
  try{const data={number:currentSurah,name:$('#surah-title').textContent,arabicName:surahs.find(s=>s.number===currentSurah)?.name||'',revelationType:'',translationEdition,translationName,ayahs:currentVerses};await idbPut('surahs',data);if(!offlineSurahIds.includes(currentSurah))offlineSurahIds.push(currentSurah);localStorage.setItem('noor-offline-surah-ids',JSON.stringify(offlineSurahIds));toast('Surah saved for offline reading.');renderSaved();}
  catch(e){toast('Could not save offline data in this browser.');}
});
$('#bookmark-surah').addEventListener('click',()=>{const key=`surah:${currentSurah}`;if(!bookmarks.some(b=>b.key===key)){bookmarks.push({key,type:'surah',surah:currentSurah,ayah:1,name:surahs.find(s=>s.number===currentSurah)?.englishName||`Surah ${currentSurah}`});saveBookmarks();toast('Surah bookmarked.');}else toast('Already bookmarked.');});
function addBookmark(i){
  const a=currentVerses[i];if(!a)return;const key=`${currentSurah}:${a.number}`;
  if(!bookmarks.some(b=>b.key===key)){bookmarks.push({key,type:'ayah',surah:currentSurah,ayah:a.number,name:surahs.find(s=>s.number===currentSurah)?.englishName||`Surah ${currentSurah}`});saveBookmarks();toast('Ayah bookmarked.');}
  else toast('Already saved.');
}
function saveBookmarks(){localStorage.setItem('noor-bookmarks',JSON.stringify(bookmarks));renderSaved();}
function renderSaved(){
  $('#bookmark-count').textContent=`${bookmarks.length} saved`;
  $('#saved-bookmarks').innerHTML=bookmarks.length?bookmarks.map((b,i)=>`<div class="saved-item"><div><b>${esc(b.name)}</b><small>${b.type==='surah'?'Whole Surah':`Ayah ${b.ayah}`} · ${b.surah}:${b.ayah}</small></div><div><button data-open-bookmark="${i}">Open</button> <button data-remove-bookmark="${i}">×</button></div></div>`).join(''):'<p class="muted">No Quran bookmarks yet. Save a Surah or ayah while reading.</p>';
  $$('#saved-bookmarks [data-open-bookmark]').forEach(b=>b.addEventListener('click',()=>{const item=bookmarks[Number(b.dataset.openBookmark)];setView('quran');loadSurah(item.surah,item.ayah);}));
  $$('#saved-bookmarks [data-remove-bookmark]').forEach(b=>b.addEventListener('click',()=>{bookmarks.splice(Number(b.dataset.removeBookmark),1);saveBookmarks();}));
  $('#offline-count').textContent=`${offlineSurahIds.length} saved`;
  $('#saved-surahs').innerHTML=offlineSurahIds.length?offlineSurahIds.map(n=>`<div class="saved-item"><div><b>${esc(surahs.find(s=>s.number===n)?.englishName||`Surah ${n}`)}</b><small>Surah ${n} · offline text</small></div><button data-open-offline="${n}">Open</button></div>`).join(''):'<p class="muted">No Surahs saved offline yet. Use “Save Surah offline” while online.</p>';
  $$('[data-open-offline]').forEach(b=>b.addEventListener('click',()=>{setView('quran');loadSurah(Number(b.dataset.openOffline));}));
}
async function searchQuran(){
  const q=$('#quran-search').value.trim();if(q.length<2){toast('Enter at least two letters.');return;}
  const box=$('#search-results');box.hidden=false;box.innerHTML=`<span class="muted">Searching ${esc(translationName)}…</span>`;
  try{
    let matches=[];
    if(translationEdition.startsWith('quranenc:')){
      matches=currentVerses.filter(a=>a.translation.toLocaleLowerCase().includes(q.toLocaleLowerCase())).map(a=>({surah:{number:currentSurah,englishName:$('#surah-title').textContent},numberInSurah:a.number,text:a.translation}));
      box.querySelector('.muted')?.remove();
      if(!matches.length){box.innerHTML='<span class="muted">No matches in the currently open Surah. Open another Surah to search it.</span>';return;}
    }else{
      const r=await fetch(`${API_Q}/search/${encodeURIComponent(q)}/all/${encodeURIComponent(translationEdition)}`);if(!r.ok)throw new Error('Search unavailable');
      const j=await r.json();matches=j.data?.matches||[];
      if(!matches.length){box.innerHTML='<span class="muted">No matches found.</span>';return;}
    }
    box.innerHTML=matches.slice(0,12).map(m=>`<button class="search-hit" data-search-surah="${m.surah.number}" data-search-ayah="${m.numberInSurah}"><b>${esc(m.surah.englishName)} ${m.numberInSurah}</b> · ${esc(m.text)}</button>`).join('');
    $$('[data-search-surah]',box).forEach(b=>b.addEventListener('click',()=>{const s=Number(b.dataset.searchSurah),a=Number(b.dataset.searchAyah);$('#search-results').hidden=true;loadSurah(s,a);}));
  }catch(e){box.innerHTML='<span class="muted">Search needs an internet connection. You can still read saved Surahs.</span>';}
}
$('#search-quran').addEventListener('click',searchQuran);
$('#quran-search').addEventListener('keydown',e=>{if(e.key==='Enter')searchQuran();});

function updateAudioUI(){
  const a=currentVerses[currentAudioIndex];$('#audio-position').textContent=a?`${currentSurah}:${a.number} / ${currentVerses.length}`:'—';
  $('#audio-progress').style.width=a?`${(currentAudioIndex+1)/Math.max(1,currentVerses.length)*100}%`:'0%';
  $('#audio-play').textContent=paused?'▶':'▶';
}
function stopAudio(){
  audioToken++;if(currentAudio){currentAudio.pause();currentAudio.src='';currentAudio=null;}
  currentAudioIndex=-1;paused=false;$$('.ayah-card.active').forEach(x=>x.classList.remove('active'));updateAudioUI();
}
async function playAt(index){
  if(!currentVerses.length)return;
  if(index<0||index>=currentVerses.length){stopAudio();$('#audio-state').textContent='Surah complete. Alhamdulillah.';return;}
  const token=++audioToken;
  currentAudioIndex=index;paused=false;
  const ayah=currentVerses[index];recordRead(currentSurah,ayah.number);
  $$('.ayah-card.active').forEach(x=>x.classList.remove('active'));
  $$('.ayah-card.selected').forEach(x=>x.classList.remove('selected'));
  const el=$(`#ayah-${index}`);if(el){el.classList.add('active','selected');}
  $('#audio-state').textContent=`Loading ayah ${ayah.number}…`;updateAudioUI();
  // Reuse one media element for the whole Surah. Some Android WebViews block
  // autoplay when a fresh Audio() object is created after every Ayah ends.
  const audio=currentAudio||(currentAudio=new Audio());
  audio.preload='auto';
  audio.onended=()=>{if(token===audioToken)playAt(index+1);};
  audio.onerror=()=>{if(token===audioToken)$('#audio-state').textContent='Audio unavailable. Check your internet connection. Try another reciter or check your connection.';};
  try{
    audio.pause();
    audio.src=reciterAudioUrl(currentSurah,ayah.number,ayah.globalNumber);
    audio.load();
    await audio.play();
    if(token===audioToken)$('#audio-state').textContent=`Playing ${surahs.find(s=>s.number===currentSurah)?.englishName||'Surah'} · Ayah ${ayah.number}`;
  }catch(e){if(token===audioToken)$('#audio-state').textContent='Playback could not continue. Tap Play to try again.';}
}
const RECITER_NAMES={'ar.alafasy':'Mishary Rashid Alafasy','ar.abdurrahmaansudais':'Abdurrahman Al-Sudais','ar.mahermuaiqly':'Maher Al-Muaiqly'};
// Use the provider's actual file naming: Sudais and Maher are per-surah/per-ayah on EveryAyah.
function reciterAudioUrl(surah,ayah,globalAyah){
 if(selectedReciter==='ar.abdurrahmaansudais')return `https://everyayah.com/data/Abdurrahmaan_As-Sudais_192kbps/${String(surah).padStart(3,'0')}${String(ayah).padStart(3,'0')}.mp3`;
 if(selectedReciter==='ar.mahermuaiqly')return `https://everyayah.com/data/MaherAlMuaiqly128kbps/${String(surah).padStart(3,'0')}${String(ayah).padStart(3,'0')}.mp3`;
 return `https://cdn.islamic.network/quran/audio/128/ar.alafasy/${globalAyah}.mp3`;
}
$('#reciter-select').value=selectedReciter;$('#reciter-name').textContent=RECITER_NAMES[selectedReciter]||RECITER_NAMES['ar.alafasy'];
$('#reciter-select').addEventListener('change',e=>{selectedReciter=e.target.value;localStorage.setItem('noor-reciter',selectedReciter);$('#reciter-name').textContent=RECITER_NAMES[selectedReciter];if(currentAudioIndex>=0)playAt(currentAudioIndex);else $('#audio-state').textContent=`Reciter selected: ${RECITER_NAMES[selectedReciter]}`;});
$('#audio-play').addEventListener('click',()=>playAt(0));
$('#audio-pause').addEventListener('click',async()=>{
  if(!currentAudio){if(currentAudioIndex>=0)playAt(currentAudioIndex);else playAt(0);return;}
  if(currentAudio.paused){try{await currentAudio.play();paused=false;$('#audio-state').textContent='Recitation resumed.';}catch{toast('Tap again to resume audio.');}}
  else{currentAudio.pause();paused=true;$('#audio-state').textContent='Recitation paused.';}
});
$('#audio-stop').addEventListener('click',()=>{stopAudio();$('#audio-state').textContent='Playback stopped.';});
$('#audio-next').addEventListener('click',()=>playAt(currentAudioIndex<0?0:currentAudioIndex+1));
$('#audio-prev').addEventListener('click',()=>playAt(currentAudioIndex<=0?0:currentAudioIndex-1));


// Page-by-page Hifz workspace (604-page Madinah Mushaf pagination).
function initMemorize(){
 const select=$('#memorize-page');select.innerHTML=Array.from({length:604},(_,i)=>`<option value="${i+1}">Page ${i+1}</option>`).join('');select.value=String(memorizePage);
 select.addEventListener('change',()=>loadMemorizePage(Number(select.value)));
 $('#memorize-prev').addEventListener('click',()=>loadMemorizePage(Math.max(1,memorizePage-1)));
 $('#memorize-next').addEventListener('click',()=>loadMemorizePage(Math.min(604,memorizePage+1)));
 $('#memorize-reveal').addEventListener('click',()=>{memorizeHidden=!memorizeHidden;$('#memorize-verses').classList.toggle('memorize-hidden',memorizeHidden);$('#memorize-reveal').textContent=memorizeHidden?'Reveal Arabic':'Hide Arabic';});
 $('#memorize-done').addEventListener('click',()=>{memorizedPages.add(memorizePage);setHifzRating('strong');saveMemorizeProgress();renderMemorizeProgress();renderHifzTools();toast(`Page ${memorizePage} marked memorized and added to revision.`);});
 $('#memorize-not-yet').addEventListener('click',()=>{memorizedPages.delete(memorizePage);delete hifzMeta[memorizePage];localStorage.setItem('noor-hifz-meta',JSON.stringify(hifzMeta));saveMemorizeProgress();renderMemorizeProgress();renderHifzTools();toast('Page removed from memorized list.');});
 $('#memorize-listen').addEventListener('click',playMemorizePage);
 $('#hifz-target').value=String(hifzTarget);$('#hifz-target').addEventListener('change',e=>{hifzTarget=Number(e.target.value);localStorage.setItem('noor-hifz-target',String(hifzTarget));renderHifzTools();});
 $('#hifz-rate-learning').addEventListener('click',()=>rateCurrentHifz('learning'));$('#hifz-rate-review').addEventListener('click',()=>rateCurrentHifz('review'));$('#hifz-rate-strong').addEventListener('click',()=>rateCurrentHifz('strong'));
 $('#hifz-next-due').addEventListener('click',()=>{const due=getDueHifzPages();if(due.length)loadMemorizePage(due[0]);else toast('No revision pages are due today.');});
 renderMemorizeProgress();renderHifzTools();
}
function hifzToday(){return new Date().toISOString().slice(0,10)}
function setHifzRating(rating){const days={learning:1,review:3,strong:7};hifzMeta[memorizePage]={rating,reviewAt:new Date(Date.now()+days[rating]*86400000).toISOString().slice(0,10),updated:hifzToday()};localStorage.setItem('noor-hifz-meta',JSON.stringify(hifzMeta));}
function rateCurrentHifz(rating){if(rating==='strong')memorizedPages.add(memorizePage);else memorizedPages.delete(memorizePage);setHifzRating(rating);saveMemorizeProgress();renderMemorizeProgress();renderHifzTools();toast(rating==='strong'?'Strong recall — revise again in 7 days.':rating==='review'?'Getting there — revise again in 3 days.':'Needs more practice — scheduled for tomorrow.');}
function getDueHifzPages(){const today=hifzToday();return Object.entries(hifzMeta).filter(([p,m])=>m.reviewAt&&m.reviewAt<=today).map(([p])=>Number(p)).sort((a,b)=>a-b)}
function renderHifzTools(){const due=getDueHifzPages();$('#hifz-due-count').textContent=due.length;$('#hifz-target-label').textContent=`Daily target: ${hifzTarget} ${hifzTarget===1?'page':'pages'}`;$('#hifz-session-hint').textContent=`Aim for ${hifzTarget} new ${hifzTarget===1?'page':'pages'} today, then revise ${due.length} due ${due.length===1?'page':'pages'}.`;}
function saveMemorizeProgress(){localStorage.setItem('noor-memorized-pages',JSON.stringify([...memorizedPages].sort((a,b)=>a-b)));localStorage.setItem('noor-memorize-page',String(memorizePage));}
function renderMemorizeProgress(){const n=memorizedPages.size,p=Math.round(n/604*100);$('#memorized-count').textContent=n;$('#memorized-percent').textContent=`${p}%`;$('#memorize-progress-bar').style.width=`${p}%`;$('#memorize-done').textContent=memorizedPages.has(memorizePage)?'✓ Page memorized':'✓ Mark page memorized';$('#memorize-not-yet').disabled=!memorizedPages.has(memorizePage);$('#hifz-current-status').textContent=hifzMeta[memorizePage]?.rating?`Page status: ${hifzMeta[memorizePage].rating} · Next review ${hifzMeta[memorizePage].reviewAt}`:'Rate your recall after practising this page.';}
async function loadMemorizePage(page){
  memorizePage=Math.min(604,Math.max(1,page));saveMemorizeProgress();$('#memorize-page').value=String(memorizePage);$('#memorize-page-range').textContent=`MUSHAF PAGE ${memorizePage} OF 604`;$('#memorize-page-title').textContent=`Page ${memorizePage}`;$('#memorize-page-subtitle').textContent='Loading complete page…';$('#memorize-verses').classList.remove('memorize-hidden');memorizeHidden=false;$('#memorize-reveal').textContent='Hide Arabic';$('#memorize-verses').innerHTML='<div class="loader"></div>';
  try{
    const arRes=await fetch(`${API_Q}/page/${memorizePage}/quran-uthmani`);
    if(!arRes.ok)throw new Error('Quran page could not be loaded');const ar=await arRes.json();let tr=null;try{const trRes=await fetch(`${API_Q}/page/${memorizePage}/${encodeURIComponent(translationEdition)}`);if(trRes.ok){const tj=await trRes.json();tr=tj.data?.ayahs||[];}}catch{}
    memorizeVerses=ar.data?.ayahs||[];if(!memorizeVerses.length)throw new Error('No ayahs returned for this page');
    const first=memorizeVerses[0],last=memorizeVerses[memorizeVerses.length-1],sName=surahs.find(x=>x.number===first.surah.number)?.englishName||`Surah ${first.surah.number}`;
    $('#memorize-page-title').textContent=sName+(first.surah.number!==last.surah.number?` → ${surahs.find(x=>x.number===last.surah.number)?.englishName||`Surah ${last.surah.number}`}`:'');
    $('#memorize-page-subtitle').textContent=`${memorizeVerses.length} ayahs · ${first.surah.englishName||sName} ${first.numberInSurah}${first.surah.number!==last.surah.number?` to ${last.surah.englishName||'next Surah'} ${last.numberInSurah}`:`–${last.numberInSurah}`}`;
    $('#memorize-verses').innerHTML=memorizeVerses.map((a,i)=>{const t=tr?.find(x=>x.number===a.number)?.text||'';return `<article class="memorize-verse"><div class="memorize-verse-meta">${a.surah.englishName||`Surah ${a.surah.number}`} · ${a.numberInSurah}</div><div class="memorize-arabic" lang="ar" dir="rtl">${esc(a.text)}</div>${t?`<p class="memorize-translation">${esc(t)}</p>`:''}</article>`;}).join('');
    $('#memorize-page-subtitle').textContent+=` · ${memorizedPages.has(memorizePage)?'Previously marked memorized':'Not marked memorized yet'}`;renderMemorizeProgress();renderHifzTools();
  }catch(e){$('#memorize-verses').innerHTML=`<p class="muted">Could not load this Mushaf page. Check your internet connection and try again.</p><button class="btn btn-outline" id="memorize-retry">Try again</button>`;$('#memorize-retry').addEventListener('click',()=>loadMemorizePage(memorizePage));$('#memorize-page-subtitle').textContent=e.message;}
}
async function playMemorizePage(){if(!memorizeVerses.length)return;if(memorizeAudio){memorizeAudioToken++;memorizeAudio.pause();memorizeAudio.src='';memorizeAudio=null;memorizeAudioStop?.();memorizeAudioStop=null;$('#memorize-listen').textContent='▶ Listen to page';return;}const token=++memorizeAudioToken;$('#memorize-listen').textContent='Ⅱ Stop page audio';for(let i=0;i<memorizeVerses.length;i++){if(token!==memorizeAudioToken)break;const a=memorizeVerses[i];$('#memorize-page-subtitle').textContent=`Listening · ${a.surah.englishName} ${a.numberInSurah} (${i+1}/${memorizeVerses.length})`;const audio=new Audio(reciterAudioUrl(a.surah.number,a.numberInSurah,a.number));memorizeAudio=audio;try{await new Promise((resolve,reject)=>{memorizeAudioStop=resolve;audio.onended=resolve;audio.onerror=reject;audio.play().catch(reject);});}catch(e){$('#memorize-page-subtitle').textContent='Recitation could not play. Check your internet connection.';break;}finally{if(memorizeAudio===audio)memorizeAudio=null;memorizeAudioStop=null;}}if(token===memorizeAudioToken)$('#memorize-listen').textContent='▶ Listen to page';}
initMemorize();

function fmtTime(t){
  if(!t)return'—';const m=String(t).match(/(\d{1,2}):(\d{2})/);if(!m)return String(t);
  let h=Number(m[1]),ampm=h>=12?'PM':'AM';h=h%12||12;return `${h}:${m[2]} ${ampm}`;
}
function parsePrayerDateTime(t,base=new Date()){
  const m=String(t||'').match(/(\d{1,2}):(\d{2})/);if(!m)return null;
  const d=new Date(base);d.setHours(Number(m[1]),Number(m[2]),0,0);return d;
}
async function loadPrayerTimes(){
  const cards=$('#prayer-cards');
  cards.innerHTML='<div class="skeleton tall"></div><div class="skeleton tall"></div><div class="skeleton tall"></div>';
  $('#home-prayer-list').innerHTML='<div class="skeleton"></div><div class="skeleton"></div><div class="skeleton"></div>';
  $('#home-next-prayer').textContent='Loading prayer times…';
  try{
    const school=Number(localStorage.getItem('noor-asr-school')||0);
    const method=Number(localStorage.getItem('noor-prayer-method')||4);
    const loc=prayerLocation;
    let url;
    if(Number.isFinite(loc.lat)&&Number.isFinite(loc.lon)){
      // AlAdhan's dated coordinate endpoint is reliable; a bare /timings/lat,lon path is not.
      const now=new Date();
      const date=`${String(now.getDate()).padStart(2,'0')}-${String(now.getMonth()+1).padStart(2,'0')}-${now.getFullYear()}`;
      url=`${API_P}/timings/${date}?latitude=${encodeURIComponent(loc.lat)}&longitude=${encodeURIComponent(loc.lon)}&method=${method}&school=${school}`;
    }else{
      url=`${API_P}/timingsByCity?city=${encodeURIComponent(loc.city||'Riyadh')}&country=${encodeURIComponent(loc.country||'Saudi Arabia')}&method=${method}&school=${school}`;
    }
    const response=await fetch(url,{cache:'no-store'});
    if(!response.ok)throw new Error(`Prayer service returned HTTP ${response.status}`);
    const payload=await response.json();
    if(payload.code!==200||!payload.data?.timings)throw new Error(payload.status||'The prayer service returned no timings');
    prayerData=payload.data;
    renderPrayerTimes();startPrayerTicker();
    scheduleNativePrayerNotifications();
    $('#prayer-date').textContent=payload.data.date?.readable||new Date().toLocaleDateString();
    if(payload.data.date?.hijri?.date)$('#hijri-label').textContent=`${payload.data.date.hijri.date} AH · Hijri date`;
    const label=locLabel();
    $('#prayer-location-label').textContent=label;
    $('#home-prayer-location').textContent=label;
    $('#location-current').textContent=`Current location: ${label}`;
    $('#prayer-source-note').textContent=`Source: AlAdhan · Method ${method} · ${label}. Compare with your local mosque timetable if it differs.`;
    updateQibla();
  }catch(error){
    const message=error?.message||'Unknown error';
    $('#home-prayer-list').innerHTML='<span class="muted">Prayer times could not be loaded.</span>';
    $('#home-next-prayer').innerHTML='<span class="muted">Check your internet connection, then press Refresh.</span>';
    cards.innerHTML=`<div class="prayer-load-error"><b>Could not load prayer times.</b><p>${esc(message)}</p><p>Check your internet connection and confirm the city in Settings.</p><button class="btn btn-outline" type="button" id="retry-prayer-load">Try again</button></div>`;
    $('#retry-prayer-load')?.addEventListener('click',loadPrayerTimes);
    $('#prayer-source-note').textContent='Prayer timings need an internet connection to fetch the latest calculation.';
  }
}
function getNextPrayer(){
  if(!prayerData)return null;const now=new Date();
  for(const name of PRAYERS){const d=parsePrayerDateTime(prayerData.timings[name]);if(d&&d>now)return{name,time:d};}
  const tomorrow=new Date(now);tomorrow.setDate(tomorrow.getDate()+1);
  return{name:'Fajr',time:parsePrayerDateTime(prayerData.timings.Fajr,tomorrow)};
}
function renderPrayerTimes(){
  if(!prayerData)return;const times=prayerData.timings;
  $('#home-prayer-list').innerHTML=ALL_PRAYERS.map(n=>`<div class="mini-prayer"><b>${n}</b><span>${fmtTime(times[n])}</span></div>`).join('');
  $('#prayer-cards').innerHTML=PRAYERS.map(n=>`<div class="prayer-card" data-prayer="${n}"><div><b>${n}</b><small>Daily salah</small></div><strong>${fmtTime(times[n])}</strong></div>`).join('');
  highlightNextPrayer();
}
function startPrayerTicker(){
  clearInterval(prayerTimer);const tick=()=>{
    const next=getNextPrayer();if(!next)return;
    const ms=Math.max(0,next.time-new Date()),h=Math.floor(ms/3600000),m=Math.floor(ms%3600000/60000),s=Math.floor(ms%60000/1000);
    $('#home-next-prayer').innerHTML=`<div><span>Next prayer</span><br><strong>${next.name}</strong></div><div style="text-align:right"><strong>${fmtTime(prayerData.timings[next.name])}</strong><br><span>${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')} remaining</span></div>`;highlightNextPrayer();
  };tick();prayerTimer=setInterval(tick,1000);
}
$('#refresh-prayer').addEventListener('click',loadPrayerTimes);
function highlightNextPrayer(){ $$('.prayer-card').forEach(card=>card.classList.toggle('current',card.dataset.prayer===getNextPrayer()?.name)); }
function bearingBetween(from,to){
  const rad=x=>x*Math.PI/180,deg=x=>(x*180/Math.PI+360)%360;
  const p1=rad(from.lat),p2=rad(to.lat),dl=rad(to.lon-from.lon);
  return deg(Math.atan2(Math.sin(dl)*Math.cos(p2),Math.cos(p1)*Math.sin(p2)-Math.sin(p1)*Math.cos(p2)*Math.cos(dl)));
}
function locLabel(){return [prayerLocation.city,prayerLocation.country].filter(Boolean).join(', ')||'Selected coordinates';}
function updateQibla(){if(!Number.isFinite(prayerLocation.lat)||!Number.isFinite(prayerLocation.lon)){qiblaBearing=null;$('#qibla-degree').textContent='—°';$('#qibla-status').textContent='Use device location to calculate an accurate Qibla bearing for your position.';return;}qiblaBearing=bearingBetween({lat:prayerLocation.lat,lon:prayerLocation.lon},KAABA);$('#qibla-degree').textContent=`${Math.round(qiblaBearing)}°`;$('#compass').style.setProperty('--bearing',`${qiblaBearing}deg`);$('.compass-needle').style.transform=`rotate(${qiblaBearing}deg)`;$('#qibla-status').textContent=`Bearing from true north, calculated for ${locLabel()}.`;}
updateQibla();
$('#enable-compass').addEventListener('click',async()=>{
  try{
    if(typeof DeviceOrientationEvent==='undefined'){toast('This device or browser has no compass sensor.');return;}
    if(typeof DeviceOrientationEvent.requestPermission==='function'){
      const p=await DeviceOrientationEvent.requestPermission();if(p!=='granted'){toast('Compass permission was not granted.');return;}
    }
    if(qiblaBearing===null){toast('Use device location first to calculate your Qibla bearing.');return;}
    if(compassListening)return;
    const handler=e=>{
      let heading=null;
      if(typeof e.webkitCompassHeading==='number')heading=e.webkitCompassHeading;
      else if(typeof e.alpha==='number' && e.absolute)heading=(360-e.alpha)%360;
      if(heading!==null){$('.compass-needle').style.transform=`rotate(${qiblaBearing-heading}deg)`;$('#qibla-status').textContent=`Live compass · heading ${Math.round(heading)}° · turn until the gold pointer faces 12 o’clock.`;}
    };
    window.addEventListener('deviceorientationabsolute',handler,true);window.addEventListener('deviceorientation',handler,true);compassListening=true;
    $('#qibla-status').textContent='Waiting for compass sensor… Keep the device flat and move it gently in a figure-eight to calibrate. Laptops often do not have a magnetic sensor; try NOOR on a phone if no heading appears.';
    setTimeout(()=>{if(compassListening && !$('#qibla-status').textContent.startsWith('Live compass'))$('#qibla-status').textContent='No live heading received. This device/browser may not have a compass sensor. Your Qibla bearing is still calculated from your location.';},5000);
  }catch(e){toast('Compass sensor permission or support unavailable.');}
});

// User-provided Adhan recording bundled locally with NOOR.
const BUILTIN_ADHAN_URL='./assets/audio/adhan.mp3';
let adhanPreview=null;
async function playBuiltinAdhan(){
  try{
    if(adhanPreview){adhanPreview.pause();adhanPreview.currentTime=0;}
    adhanPreview=new Audio(BUILTIN_ADHAN_URL);adhanPreview.preload='auto';
    await adhanPreview.play();
    return true;
  }catch(error){toast('Local Adhan audio could not start. Check that assets/audio/adhan.mp3 is present, then press Preview Adhan again.');return false;}
}
$('#adhan-preview').addEventListener('click',playBuiltinAdhan);
$('#adhan-toggle').addEventListener('change',e=>{localStorage.setItem('noor-adhan-enabled',e.target.checked?'1':'0');if(e.target.checked)toast('Local Adhan enabled. Preview it once to allow audio in this browser.');});
// Capacitor's Local Notifications plugin is used on Android/iOS. The regular
// browser Notification API remains the fallback for the laptop/PWA edition.
async function getNativeLocalNotifications(){
  if(!window.Capacitor?.isNativePlatform?.())return null;
  try{return (await import('@capacitor/local-notifications')).LocalNotifications;}catch{return null;}
}
async function notificationPermissionGranted(){
  const native=await getNativeLocalNotifications();
  if(native){try{return (await native.checkPermissions()).display==='granted';}catch{return false;}}
  return ('Notification'in window)&&Notification.permission==='granted';
}
async function enablePrayerNotifications(){
  const native=await getNativeLocalNotifications();
  if(native){
    let permission=await native.checkPermissions();
    if(permission.display!=='granted')permission=await native.requestPermissions();
    return permission.display==='granted';
  }
  if(!('Notification'in window))return false;
  let permission=Notification.permission;
  if(permission==='default'){try{permission=await Notification.requestPermission();}catch{permission='denied';}}
  return permission==='granted';
}
async function scheduleNativePrayerNotifications(){
  const native=await getNativeLocalNotifications();
  if(!native||!prayerData||localStorage.getItem('noor-notifications')!=='1')return;
  try{
    const permission=await native.checkPermissions();if(permission.display!=='granted')return;
    const pending=await native.getPending();
    if(pending.notifications?.length)await native.cancel({notifications:pending.notifications.map(n=>({id:n.id}))});
    const notifications=[];
    PRAYERS.forEach((name,index)=>{
      const at=parsePrayerDateTime(prayerData.timings[name]);
      if(!at||at<=new Date())return;
      notifications.push({id:Math.floor(Date.now()/1000)%1000000+index+1,title:`It's time for ${name}`,body:`${locLabel()} prayer time · ${fmtTime(prayerData.timings[name])}`,schedule:{at},smallIcon:'ic_stat_icon_config_sample'});
    });
    if(notifications.length)await native.schedule({notifications});
  }catch(error){console.warn('NOOR could not schedule native prayer reminders',error);}
}
$('#notifications-toggle').addEventListener('change',async e=>{
  if(e.target.checked){
    const enabled=await enablePrayerNotifications();
    if(!enabled){e.target.checked=false;localStorage.setItem('noor-notifications','0');toast('Notification permission was not granted.');return;}
    localStorage.setItem('noor-notifications','1');
    await scheduleNativePrayerNotifications();
    toast(window.Capacitor?.isNativePlatform?.()?'Prayer reminders enabled on this device.':'Prayer reminders enabled while NOOR is open.');
  }else{
    localStorage.setItem('noor-notifications','0');
    const native=await getNativeLocalNotifications();
    if(native){try{const pending=await native.getPending();if(pending.notifications?.length)await native.cancel({notifications:pending.notifications.map(n=>({id:n.id}))});}catch{}}
  }
});
async function checkPrayerAlerts(){
  if(!prayerData)return;
  const isNative=!!window.Capacitor?.isNativePlatform?.();
  const notify=!isNative&&localStorage.getItem('noor-notifications')==='1'&&('Notification'in window)&&Notification.permission==='granted';
  const playAdhan=localStorage.getItem('noor-adhan-enabled')==='1';
  if(!notify&&!playAdhan)return;
  const now=new Date(),date=todayKey(),fired=JSON.parse(localStorage.getItem('noor-alerts-fired')||'{}');
  for(const n of PRAYERS){
    const d=parsePrayerDateTime(prayerData.timings[n]);if(!d)continue;
    const key=`${date}:${n}`;
    if(now>=d&&now-d<65000&&!fired[key]){
      fired[key]=true;localStorage.setItem('noor-alerts-fired',JSON.stringify(fired));
      if(notify){try{new Notification(`It's time for ${n}`,{body:`${locLabel()} prayer time · ${fmtTime(prayerData.timings[n])}`,icon:'icon.svg'});}catch{}}
      if(playAdhan){ await playBuiltinAdhan(); }
    }
  }
}
notificationTimer=setInterval(checkPrayerAlerts,15000);
$('#notifications-toggle').checked=localStorage.getItem('noor-notifications')==='1';
$('#adhan-toggle').checked=localStorage.getItem('noor-adhan-enabled')==='1';

// Show the in-app question only while NOOR reminders are not enabled.
// Once permission + the saved opt-in are both present, never interrupt launch.
async function showNotificationWelcome(){
  const modal=$('#notification-welcome');if(!modal)return;
  const optedIn=localStorage.getItem('noor-notifications')==='1';
  const granted=await notificationPermissionGranted();
  if(optedIn&&granted){modal.hidden=true;$('#notifications-toggle').checked=true;return;}
  const note=$('#notification-welcome-note');
  if(window.Capacitor?.isNativePlatform?.())note.textContent='Turn this on to receive prayer-time reminders from NOOR even when the app is not open. You can change notification permission later in your phone settings.';
  else if(!('Notification'in window))note.textContent='This browser does not support notifications. You can still use the built-in Adhan while NOOR is open.';
  else if(Notification.permission==='denied')note.textContent='Notifications are blocked in your browser settings. You can change that there; NOOR cannot show the browser permission prompt again.';
  else note.textContent='Turn this on to receive a reminder when each of the five daily prayer times begins, even when NOOR is not in the foreground where supported.';
  modal.hidden=false;
}
function closeNotificationWelcome(){const modal=$('#notification-welcome');if(modal)modal.hidden=true;}
$('#notification-welcome-no').addEventListener('click',()=>{localStorage.setItem('noor-notifications','0');$('#notifications-toggle').checked=false;closeNotificationWelcome();});
$('#notification-welcome-yes').addEventListener('click',async()=>{
  const enabled=await enablePrayerNotifications();
  localStorage.setItem('noor-notifications',enabled?'1':'0');$('#notifications-toggle').checked=enabled;
  if(enabled)await scheduleNativePrayerNotifications();
  closeNotificationWelcome();
  toast(enabled?'Prayer-time notifications enabled.':(window.Capacitor?.isNativePlatform?.()?'Notification permission was not granted. Check your phone settings.':'Notifications were not allowed. You can change this in browser settings.'));
});
window.addEventListener('load',()=>setTimeout(showNotificationWelcome,500));


const standardDhikr=[
  {name:'SubhanAllah',arabic:'سُبْحَانَ اللَّهِ'},
  {name:'Alhamdulillah',arabic:'الْحَمْدُ لِلَّهِ'},
  {name:'Allahu Akbar',arabic:'اللَّهُ أَكْبَرُ'}
];
function renderTasbeeh(){
  const step=Math.min(2,Math.max(0,tasbeeh.step));
  $('#tasbeeh-steps').innerHTML=standardDhikr.map((d,i)=>`<button class="step-chip ${i===step?'active':tasbeeh.counts[i]>=33?'done':''}" data-tasbeeh-step="${i}">${i+1}. ${d.name}<br><b>${Math.min(tasbeeh.counts[i],33)}/33</b></button>`).join('');
  $$('[data-tasbeeh-step]').forEach(b=>b.addEventListener('click',()=>{tasbeeh.step=Number(b.dataset.tasbeehStep);saveTasbeeh();renderTasbeeh();}));
  const d=standardDhikr[step],count=Math.min(tasbeeh.counts[step],33);$('#tasbeeh-current-name').textContent=d.name;$('#tasbeeh-count').textContent=count;$('#tasbeeh-progress').style.width=`${count/33*100}%`;
  const beadRing=$('#tasbeeh-beads');if(beadRing)beadRing.innerHTML=Array.from({length:33},(_,i)=>`<i class=\"tasbeeh-bead ${i<count?'counted':''}\" style=\"--bead:${i}\"></i>`).join('');
}
function advanceTasbeeh(){
  const i=tasbeeh.step;if(tasbeeh.counts[i]<33)tasbeeh.counts[i]++;
  daily.dhikr=Math.min(99,tasbeeh.counts.reduce((a,b)=>a+Math.min(b,33),0));saveDaily();saveTasbeeh();
  if(tasbeeh.counts[i]>=33){$('#tasbeeh-message').textContent=i<2?'MashaAllah. Next phrase is ready.':'MashaAllah — the 33 × 3 set is complete.';if(i<2)tasbeeh.step=i+1;}
  else $('#tasbeeh-message').textContent='';
  saveTasbeeh();renderTasbeeh();
}
$('#tasbeeh-tap').addEventListener('click',advanceTasbeeh);
$('#tasbeeh-minus').addEventListener('click',()=>{const i=tasbeeh.step;tasbeeh.counts[i]=Math.max(0,tasbeeh.counts[i]-1);daily.dhikr=Math.min(99,tasbeeh.counts.reduce((a,b)=>a+Math.min(b,33),0));saveDaily();saveTasbeeh();$('#tasbeeh-message').textContent='One count undone.';renderTasbeeh();});
$('#tasbeeh-reset').addEventListener('click',()=>{tasbeeh={date:todayKey(),counts:[0,0,0],step:0};daily.dhikr=0;saveTasbeeh();saveDaily();$('#tasbeeh-message').textContent='Counter reset.';renderTasbeeh();});
$('#custom-dhikr-form').addEventListener('submit',e=>{
  e.preventDefault();const name=$('#custom-dhikr-name').value.trim(),target=Number($('#custom-dhikr-target').value);
  if(!name||!target)return;customCounters.push({id:Date.now(),name,target,count:0});localStorage.setItem('noor-custom-counters',JSON.stringify(customCounters));$('#custom-dhikr-name').value='';renderCustomCounters();toast('Custom counter added.');
});
function renderCustomCounters(){
  $('#custom-dhikr-list').innerHTML=customCounters.length?customCounters.map((c,i)=>`<div class="custom-counter"><div><b>${esc(c.name)}</b><small>${c.count} / ${c.target}</small></div><div class="custom-counter-actions"><button data-custom-minus="${i}">−</button><button data-custom-add="${i}">＋</button><button data-custom-delete="${i}">×</button></div></div>`).join(''):'<p class="muted">No custom counters yet.</p>';
  $$('[data-custom-add]').forEach(b=>b.addEventListener('click',()=>{const c=customCounters[Number(b.dataset.customAdd)];c.count=Math.min(c.target,c.count+1);saveCustom();}));
  $$('[data-custom-minus]').forEach(b=>b.addEventListener('click',()=>{const c=customCounters[Number(b.dataset.customMinus)];c.count=Math.max(0,c.count-1);saveCustom();}));
  $$('[data-custom-delete]').forEach(b=>b.addEventListener('click',()=>{customCounters.splice(Number(b.dataset.customDelete),1);saveCustom();}));
}
function saveCustom(){localStorage.setItem('noor-custom-counters',JSON.stringify(customCounters));renderCustomCounters();}

const duas=[
  {type:'quran',title:'A good in this life and the next',arabic:'رَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً وَفِي الْآخِرَةِ حَسَنَةً وَقِنَا عَذَابَ النَّارِ',translation:'Our Lord, give us good in this world and good in the Hereafter, and protect us from the punishment of the Fire.',ref:'Quran 2:201'},
  {type:'quran',title:'Increase me in knowledge',arabic:'رَبِّ زِدْنِي عِلْمًا',translation:'My Lord, increase me in knowledge.',ref:'Quran 20:114'},
  {type:'quran',title:'Keep our hearts firm',arabic:'رَبَّنَا لَا تُزِغْ قُلُوبَنَا بَعْدَ إِذْ هَدَيْتَنَا وَهَبْ لَنَا مِن لَّدُنكَ رَحْمَةً ۚ إِنَّكَ أَنتَ الْوَهَّابُ',translation:'Our Lord, do not let our hearts deviate after You have guided us, and grant us mercy from Yourself.',ref:'Quran 3:8'},
  {type:'adhkar',title:'Morning and evening glorification',arabic:'سُبْحَانَ اللَّهِ وَبِحَمْدِهِ',translation:'Glory and praise be to Allah. A narration mentions saying this one hundred times.',ref:'Sahih Muslim 2692'},
  {type:'adhkar',title:'Two beloved phrases',arabic:'سُبْحَانَ اللَّهِ وَبِحَمْدِهِ، سُبْحَانَ اللَّهِ الْعَظِيمِ',translation:'Glory and praise be to Allah; glory be to Allah, the Magnificent.',ref:'Sahih al-Bukhari 6406; Sahih Muslim 2694'},
  {type:'life',title:'Before eating',arabic:'بِسْمِ اللَّهِ',translation:'In the name of Allah. If you forget at the beginning, say: Bismillahi awwalahu wa akhirahu (In the name of Allah, at its beginning and end).',ref:'Sahih al-Bukhari 5376; Sunan Abi Dawud 3767'},
  {type:'life',title:'After eating',arabic:'الْحَمْدُ لِلَّهِ الَّذِي أَطْعَمَنِي هَذَا وَرَزَقَنِيهِ مِنْ غَيْرِ حَوْلٍ مِنِّي وَلَا قُوَّةٍ',translation:'Praise be to Allah who fed me this and provided it for me without any power or strength from myself.',ref:'Jami at-Tirmidhi 3458; Sunan Abi Dawud 4023 (wording/numbering may vary)'},
  {type:'life',title:'Before sleeping',arabic:'بِاسْمِكَ اللَّهُمَّ أَمُوتُ وَأَحْيَا',translation:'In Your name, O Allah, I die and I live.',ref:'Sahih al-Bukhari 6324'},
  {type:'life',title:'After waking up',arabic:'الْحَمْدُ لِلَّهِ الَّذِي أَحْيَانَا بَعْدَ مَا أَمَاتَنَا وَإِلَيْهِ النُّشُورُ',translation:'Praise be to Allah who gave us life after causing us to die, and to Him is the resurrection.',ref:'Sahih al-Bukhari 6312; 6324 (numbering varies)'},
  {type:'life',title:'When entering the bathroom',arabic:'اللَّهُمَّ إِنِّي أَعُوذُ بِكَ مِنَ الْخُبُثِ وَالْخَبَائِثِ',translation:'O Allah, I seek refuge in You from male and female devils.',ref:'Sahih al-Bukhari 142; Sahih Muslim 375'},
  {type:'life',title:'When leaving the bathroom',arabic:'غُفْرَانَكَ',translation:'I ask You for forgiveness.',ref:'Sunan Abi Dawud 30; Jami at-Tirmidhi 7'},
  {type:'life',title:'When leaving home',arabic:'بِسْمِ اللَّهِ، تَوَكَّلْتُ عَلَى اللَّهِ، وَلَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ',translation:'In the name of Allah; I place my trust in Allah. There is no power and no strength except through Allah.',ref:'Sunan Abi Dawud 5095; Jami at-Tirmidhi 3426'},
  {type:'life',title:'When entering home',arabic:'بِسْمِ اللَّهِ',translation:'Mention Allah’s name when entering and greet the people of the home with salam. The hadith teaches that remembering Allah at home is a means of blessing.',ref:'Sahih Muslim 2018; Quran 24:61 for the greeting'},
  {type:'life',title:'When entering the mosque',arabic:'اللَّهُمَّ افْتَحْ لِي أَبْوَابَ رَحْمَتِكَ',translation:'O Allah, open for me the gates of Your mercy.',ref:'Sahih Muslim 713'},
  {type:'life',title:'When leaving the mosque',arabic:'اللَّهُمَّ إِنِّي أَسْأَلُكَ مِنْ فَضْلِكَ',translation:'O Allah, I ask You for Your bounty.',ref:'Sahih Muslim 713'},
  {type:'life',title:'When putting on clothes',arabic:'الْحَمْدُ لِلَّهِ الَّذِي كَسَانِي هَذَا وَرَزَقَنِيهِ مِنْ غَيْرِ حَوْلٍ مِنِّي وَلَا قُوَّةٍ',translation:'Praise be to Allah who clothed me with this and provided it for me without any power or strength from myself.',ref:'Sunan Abi Dawud 4023; Jami at-Tirmidhi 3458 (reports/numbering vary)'},
  {type:'life',title:'When sneezing',arabic:'الْحَمْدُ لِلَّهِ',translation:'The one who sneezes praises Allah. The listener responds: يَرْحَمُكَ اللَّهُ (May Allah have mercy on you). The sneezer replies: يَهْدِيكُمُ اللَّهُ وَيُصْلِحُ بَالَكُمْ (May Allah guide you and set your affairs right).',ref:'Sahih al-Bukhari 6224; Sahih Muslim 2991'},
  {type:'life',title:'When something pleases you',arabic:'الْحَمْدُ لِلَّهِ',translation:'Praise Allah when something good happens. This is a general remembrance, not a fixed special formula for every occasion.',ref:'Quran 1:2; general dhikr'},
  {type:'life',title:'When feeling worried or distressed',arabic:'لَا إِلَهَ إِلَّا أَنْتَ سُبْحَانَكَ إِنِّي كُنْتُ مِنَ الظَّالِمِينَ',translation:'There is no deity except You; glory be to You. Indeed, I have been among the wrongdoers.',ref:'Quran 21:87 — supplication of Prophet Yunus عليه السلام'},
  {type:'life',title:'When starting a journey',arabic:'اللَّهُ أَكْبَرُ، اللَّهُ أَكْبَرُ، اللَّهُ أَكْبَرُ، سُبْحَانَ الَّذِي سَخَّرَ لَنَا هَذَا وَمَا كُنَّا لَهُ مُقْرِنِينَ',translation:'Allah is the Greatest. Glory be to the One who has subjected this to us, though we could not have controlled it ourselves.',ref:'Quran 43:13; travel supplication in Sahih Muslim 1342'},
  {type:'life',title:'When breaking the fast',arabic:'ذَهَبَ الظَّمَأُ وَابْتَلَّتِ الْعُرُوقُ وَثَبَتَ الْأَجْرُ إِنْ شَاءَ اللَّهُ',translation:'The thirst has gone, the veins are moistened, and the reward is confirmed, if Allah wills.',ref:'Sunan Abi Dawud 2357 (grading/numbering should be checked with a trusted hadith reference)'}
];
function renderDuas(filter='all'){
  $('#dua-grid').innerHTML=duas.filter(d=>filter==='all'||d.type===filter).map(d=>`<article class="dua-card"><div class="dua-category">${d.type==='quran'?'Quranic supplication':d.type==='life'?'Everyday moment':'Prophetic remembrance'}</div><h3>${esc(d.title)}</h3><div class="dua-arabic" lang="ar" dir="rtl">${esc(d.arabic)}</div><p class="dua-translation">${esc(d.translation)}</p><div class="dua-ref">${esc(d.ref)}</div><div class="dua-actions"><button data-copy-dua="${duas.indexOf(d)}">Copy Arabic</button></div></article>`).join('');
  $$('[data-copy-dua]').forEach(b=>b.addEventListener('click',async()=>{const d=duas[Number(b.dataset.copyDua)];try{await navigator.clipboard.writeText(d.arabic);toast('Arabic copied.');}catch{toast('Clipboard access is unavailable in this browser.');}}));
}
$$('[data-dua-filter]').forEach(b=>b.addEventListener('click',()=>{$$('[data-dua-filter]').forEach(x=>x.classList.remove('active'));b.classList.add('active');renderDuas(b.dataset.duaFilter);}));

const lessons={
  wudu:{title:'Wudu · Ablution',intro:'A common step-by-step outline of wudu, drawing on Quran 5:6 and the Prophet’s described practice.',steps:[
    ['Intention and beginning','Make the intention in your heart. Saying Bismillah is commonly taught; its legal classification is discussed by scholars.'],
    ['Wash the hands','Wash both hands up to the wrists.'],
    ['Rinse mouth and nose','Rinse the mouth and clean the nose with water.'],
    ['Wash the face','Wash the whole face within its prescribed boundaries.'],
    ['Wash the arms','Wash both arms, including the elbows.'],
    ['Wipe the head and ears','Wipe the head with wet hands; details of the amount and ears differ among schools.'],
    ['Wash the feet','Wash both feet, including the ankles, unless a valid concession such as wiping over qualifying footwear applies.']
  ],sideTitle:'Helpful reminders',side:['Do not waste water.','Remove anything that prevents water reaching the skin.','The order and continuity have specific rulings; follow the method taught in your school.','Quran reference: Al-Ma’idah 5:6.']},
  ghusl:{title:'Ghusl · Full ritual bath',intro:'A general description of the complete ghusl narrated in reports about the Prophet’s purification. Minimum validity and recommended sequence are not identical in every madhhab.',steps:[
    ['Make the intention','Intend purification in the heart.'],
    ['Wash the hands and private area','Wash the hands and remove any impurity.'],
    ['Perform wudu','Perform wudu as for prayer; some details of foot washing in the sequence are reported differently.'],
    ['Wash the head','Pour water over the head, ensuring it reaches the scalp and roots of the hair.'],
    ['Wash the whole body','Wash the entire body, ensuring water reaches all required areas; begin with the right side in the commonly described complete method.']
  ],sideTitle:'When is ghusl required?',side:['After sexual intercourse.','After ejaculation, according to its relevant rulings.','After menstruation or postnatal bleeding has ended.','Quran reference: Al-Ma’idah 5:6 and An-Nisa 4:43.','The legal details and minimum requirements differ among schools.']},
  salah:{title:'Salah · The daily prayer',intro:'A beginner-friendly outline of the prayer. The detailed wording, posture and some actions have differences in authentic practice and across legal schools.',steps:[
    ['Prepare','Ensure the prayer time has entered, you have purification, your clothing and place are clean, and you face the Qiblah.'],
    ['Stand and begin','Make the intention in your heart and begin with Takbirat al-Ihram: Allahu Akbar.'],
    ['Recite','Recite Surah Al-Fatihah while standing; additional recitation is made in the appropriate rak‘ahs.'],
    ['Ruku','Bow with calmness, glorifying Allah. Rise fully from bowing.'],
    ['Sujud','Prostrate, sit between the two prostrations, then prostrate again with calmness.'],
    ['Complete the rak‘ahs','Repeat the prayer units as required. Sit for tashahhud and finish with salam.']
  ],sideTitle:'Obligatory rak‘ahs',side:['Fajr: 2','Dhuhr: 4','Asr: 4','Maghrib: 3','Isha: 4','These are the fard rak‘ahs; Sunnah and voluntary prayers are additional. Learn the detailed method from a trusted teacher.']}
,
  umrah:{title:'Umrah · A general overview',intro:'An introductory sequence for learning. Ihram details, boundaries, timing and valid concessions should be learned from a qualified guide before travel.',steps:[
    ['Prepare and enter Ihram','Learn the miqat for your route, make ghusl if appropriate, wear the required Ihram clothing and enter the state of Ihram with the intention for Umrah.'],
    ['Talbiyah','Recite the Talbiyah and observe the restrictions of Ihram. Ask a trusted scholar about details that apply to your circumstances.'],
    ['Tawaf','Perform seven circuits around the Ka‘bah, beginning and ending at the Black Stone line, while following the official crowd-safety instructions.'],
    ['Two rak‘ahs and Zamzam','Pray two rak‘ahs where safely possible without obstructing others, then drink Zamzam if available.'],
    ['Sa‘i','Walk seven lengths between Safa and Marwah, beginning at Safa and ending at Marwah.'],
    ['Complete Umrah','Men trim or shave the hair; women trim a small amount according to the guidance they follow. This completes Umrah.']
  ],sideTitle:'Before you travel',side:['Check current Saudi permits, entry rules and official Nusuk guidance.','Know your miqat and transport route before departure.','Do not block pathways or push through crowds to reach a landmark.','Learn Ihram restrictions and relevant exemptions from a qualified guide.']},
  hajj:{title:'Hajj · A general overview',intro:'Hajj has specific days, rites and legal conditions. This is a high-level learning outline, not a travel itinerary or a ruling on validity.',steps:[
    ['Learn the type of Hajj','Understand Tamattu‘, Qiran and Ifrad with a qualified teacher and follow the plan assigned by your authorised Hajj provider.'],
    ['Ihram and Mina','Enter Ihram at the correct time and place. Follow your group and official crowd-management instructions.'],
    ['Arafah','Standing at Arafah on the prescribed day is a central pillar of Hajj. Follow official transport and timing arrangements.'],
    ['Muzdalifah','Proceed according to the authorised schedule, remembering Allah and following safety directions.'],
    ['Ramy, sacrifice and hair','The sequence and requirements can vary by Hajj type and circumstance. Follow your scholar and official Hajj group guidance.'],
    ['Tawaf and Sa‘i','Complete the required rites at the prescribed times, with patience and care for other pilgrims.']
  ],sideTitle:'Important reminders',side:['Use official Saudi Hajj channels and your authorised provider for current procedures.','Do not rely on a generic app for permit, health or transport rules.','Know the concessions and rulings relevant to illness, age, disability or travel disruption.','Ask a qualified scholar about the details of your Hajj type.']}
};
function renderLesson(key){
  const l=lessons[key];$('#learn-content').innerHTML=`<div class="learn-main"><div class="eyebrow">Step-by-step guide</div><h2>${l.title}</h2><p class="muted" style="font-size:11px">${l.intro}</p>${l.steps.map((s,i)=>`<div class="learn-step"><span class="learn-step-num">${i+1}</span><div><b>${esc(s[0])}</b><p>${esc(s[1])}</p></div></div>`).join('')}</div><aside class="learn-side"><div class="eyebrow">Keep in mind</div><h3>${l.sideTitle}</h3><ul>${l.side.map(x=>`<li>${esc(x)}</li>`).join('')}</ul></aside>`;
}
$$('[data-learn-tab]').forEach(b=>b.addEventListener('click',()=>{$$('[data-learn-tab]').forEach(x=>x.classList.remove('active'));b.classList.add('active');renderLesson(b.dataset.learnTab);}));

function renderProgress(){
  const q=Math.min(daily.readAyahs.length,10),d=Math.min(daily.dhikr,33);
  const done=[q>=10,d>=33].filter(Boolean).length,percent=Math.round((q/10+d/33)/2*100);
  $('#progress-percent').textContent=`${percent}%`;$('#progress-ring').style.setProperty('--progress',`${percent}%`);
  $('#progress-complete').textContent=`${done} of 2 goals`;$('#goal-quran').textContent=`${q}/10`;$('#goal-dhikr').textContent=`${d}/33`;
  $('#bar-quran').style.width=`${q/10*100}%`;$('#bar-dhikr').style.width=`${d/33*100}%`;
  $('#streak-label').textContent=done===2?'Both goals complete':(q+d>0?'Good progress today':'Start today');
  renderQuranAside();
}
// Quran translation language selector. Language and translator names come from QuranEnc's catalogue.
async function populateQuranLanguages(){
  const select=$('#quran-language');
  try{
    const cached=JSON.parse(localStorage.getItem('noor-quranenc-catalog')||'[]');
    if(cached.length)translationCatalog=cached;
    const response=await fetch(`${API_QE}/translations/list/`);
    if(response.ok){const payload=await response.json();const items=Array.isArray(payload)?payload:(payload.translations||payload.result||[]);if(Array.isArray(items)&&items.length){translationCatalog=items;localStorage.setItem('noor-quranenc-catalog',JSON.stringify(translationCatalog));}}
  }catch{}
  const byLanguage=new Map();
  const codeAliases={eng:'en',ara:'ar',urd:'ur',tam:'ta',ben:'bn',ind:'id',msa:'ms',tur:'tr',fra:'fr',spa:'es',rus:'ru',zho:'zh',hin:'hi',fas:'fa',deu:'de',swa:'sw',hau:'ha',pus:'ps',kur:'ku',som:'so',ita:'it',nld:'nl',sqi:'sq',por:'pt',aze:'az',vie:'vi',sin:'si',tgl:'tl',amh:'am',asm:'as',jpn:'ja',kor:'ko',tha:'th',uzb:'uz'};
  translationCatalog.forEach(t=>{const raw=t.language_iso_code||t.language_code;const code=codeAliases[raw]||raw;if(!code||!t.key)return;t.noorLanguageCode=code;if(!byLanguage.has(code))byLanguage.set(code,[]);byLanguage.get(code).push(t);});
  const preferred=['en','ta','ur','bn','id','ms','tr','fr','es','ru','zh','hi','fa','de','sw','ha','ps','ku','so','it','nl','sq','pt','az','vi','si','tl','am','as','ja','ko','th','uz'];
  const all=[...new Set([...preferred,...[...byLanguage.keys()].sort()])];
  const options=[`<option value="en">English · Sahih International (default)</option>`,`<option value="ar">العربية · Arabic original text</option>`];
  all.filter(code=>!['en','ar'].includes(code)).forEach(code=>{
    const editions=byLanguage.get(code)||[];const label=LANG_LABELS[code]||editions[0]?.title||code.toUpperCase();
    const available=editions.length>0;const title=available?(editions.length>1?`${label} · ${editions.length} translations available`:label):`${label} · translation not listed`;
    options.push(`<option value="${esc(code)}">${esc(title)}</option>`);
  });
  select.innerHTML=options.join('');
  const inline=$('#quran-language-inline');if(inline){inline.innerHTML=select.innerHTML;inline.value=translationLanguage;}
  if(translationLanguage!=='en'&&translationLanguage!=='ar'&&!byLanguage.has(translationLanguage)){translationLanguage='en';translationEdition='en.sahih';translationName='Sahih International';localStorage.setItem('noor-quran-language','en');localStorage.setItem('noor-quran-edition','en.sahih');localStorage.setItem('noor-quran-translation-name','Sahih International');}
  select.value=translationLanguage;
  $('#translation-current').textContent=`Current: ${translationName} · ${LANG_LABELS[translationLanguage]||translationLanguage.toUpperCase()}`;$('#translation-aside-name').textContent=translationName;
}
async function changeQuranLanguage(code){
  const status=$('#translation-status');status.textContent='Loading the selected Quran translation…';$('#quran-language').disabled=true;
  const previous={language:translationLanguage,edition:translationEdition,name:translationName};
  try{
    if(code==='en'){translationLanguage='en';translationEdition='en.sahih';translationName='Sahih International';}
    else if(code==='ar'){translationLanguage='ar';translationEdition='quran-uthmani';translationName='Arabic original text';}
    else{
      const editions=translationCatalog.filter(t=>(t.noorLanguageCode||t.language_iso_code)===code&&t.key);
      if(!editions.length)throw new Error(`No verified published ${LANG_LABELS[code]||code} translation is currently listed by the free QuranEnc catalogue. Try another language or refresh when online.`);
      const preferred=editions.find(t=>/clear|simple|concise|brief/i.test(t.title||''))||editions[0];
      translationLanguage=code;translationEdition=`quranenc:${preferred.key}`;translationName=preferred.title||LANG_LABELS[code]||code;
    }
    // Update translation text in place. The Arabic recitation audio is independent
    // of translation, so do not call loadSurah()/stopAudio() here.
    const refreshed=await fetchSurah(currentSurah);
    const translatedByAyah=new Map((refreshed.ayahs||[]).map(a=>[Number(a.number),a.translation||'']));
    currentVerses=currentVerses.map(a=>({...a,translation:translatedByAyah.get(Number(a.number))||''}));
    localStorage.setItem('noor-quran-language',translationLanguage);localStorage.setItem('noor-quran-edition',translationEdition);localStorage.setItem('noor-quran-translation-name',translationName);
    $('#translation-current').textContent=`Current: ${translationName} · ${LANG_LABELS[translationLanguage]||translationLanguage.toUpperCase()}`;$('#translation-aside-name').textContent=translationName;$('#quran-language').value=translationLanguage;$('#quran-language-inline').value=translationLanguage;
    renderAyahs();
    if(currentAudioIndex>=0){$('#ayah-'+currentAudioIndex)?.classList.add('active','selected');}
    updateAudioUI();
    $('#quran-cache-state').textContent=`Quran text from AlQuran Cloud · ${translationName} translation.`;
    status.textContent=`${LANG_LABELS[code]||code} selected. Recitation continues without restarting.`;
  }catch(error){
    translationLanguage=previous.language;translationEdition=previous.edition;translationName=previous.name;
    localStorage.setItem('noor-quran-language',translationLanguage);localStorage.setItem('noor-quran-edition',translationEdition);localStorage.setItem('noor-quran-translation-name',translationName);
    $('#translation-current').textContent=`Current: ${translationName} · ${LANG_LABELS[translationLanguage]||translationLanguage.toUpperCase()}`;$('#translation-aside-name').textContent=translationName;
    $('#quran-language').value=translationLanguage;$('#quran-language-inline').value=translationLanguage;status.textContent=error.message||'Could not change translation. Your previous selection is still active.';
  }
  finally{$('#quran-language').disabled=false;}
}
$('#quran-language').addEventListener('change',e=>changeQuranLanguage(e.target.value));
$('#quran-language-inline').addEventListener('change',e=>{ $('#quran-language').value=e.target.value; changeQuranLanguage(e.target.value); });
populateQuranLanguages();

$('#setting-dark').addEventListener('click',()=>setTheme('dark'));
$('#setting-light').addEventListener('click',()=>setTheme('light'));
let arabicSize=Number(localStorage.getItem('noor-arabic-size')||32);
function applyArabicSize(){document.documentElement.style.setProperty('--arabic-size',`${arabicSize}px`);$('#font-size-label').textContent=`${arabicSize} px`;localStorage.setItem('noor-arabic-size',String(arabicSize));}
$('#font-smaller').addEventListener('click',()=>{arabicSize=Math.max(22,arabicSize-2);applyArabicSize();});
$('#font-larger').addEventListener('click',()=>{arabicSize=Math.min(48,arabicSize+2);applyArabicSize();});
applyArabicSize();
$('#asr-school').value=localStorage.getItem('noor-asr-school')||'0';
$('#asr-school').addEventListener('change',()=>{localStorage.setItem('noor-asr-school',$('#asr-school').value);loadPrayerTimes();});
$('#prayer-method').value=localStorage.getItem('noor-prayer-method')||'4';
$('#prayer-method').addEventListener('change',()=>{localStorage.setItem('noor-prayer-method',$('#prayer-method').value);loadPrayerTimes();});
$('#location-city').value=prayerLocation.city||'';$('#location-country').value=prayerLocation.country||'';
$('#location-current').textContent=`Current location: ${locLabel()}`;
$('#save-location').addEventListener('click',()=>{const city=$('#location-city').value.trim(),country=$('#location-country').value.trim();if(!city||!country){toast('Enter both a city and country.');return;}prayerLocation={city,country};localStorage.setItem('noor-prayer-location',JSON.stringify(prayerLocation));updateQibla();loadPrayerTimes();toast(`Prayer location set to ${city}, ${country}.`);});
$('#use-device-location').addEventListener('click',()=>{if(!navigator.geolocation){toast('Device location is not supported by this browser.');return;}toast('Requesting your location permission…');navigator.geolocation.getCurrentPosition(async pos=>{prayerLocation={city:'Device location',country:'GPS coordinates',lat:pos.coords.latitude,lon:pos.coords.longitude};localStorage.setItem('noor-prayer-location',JSON.stringify(prayerLocation));updateQibla();loadPrayerTimes();toast('Device location applied.');},err=>toast(err.code===1?'Location permission was denied.': 'Could not determine your location.'),{enableHighAccuracy:true,timeout:12000,maximumAge:300000});});
$('#clear-data').addEventListener('click',async()=>{
  if(!confirm('Clear NOOR bookmarks, settings, counters and saved offline Surahs from this browser? This cannot be undone.'))return;
  try{localStorage.removeItem('noor-bookmarks');localStorage.removeItem('noor-custom-counters');localStorage.removeItem('noor-daily');localStorage.removeItem('noor-tasbeeh');localStorage.removeItem('noor-last-read');localStorage.removeItem('noor-offline-surah-ids');localStorage.removeItem('noor-theme');localStorage.removeItem('noor-arabic-size');localStorage.removeItem('noor-asr-school');localStorage.removeItem('noor-prayer-method');localStorage.removeItem('noor-prayer-location');localStorage.removeItem('noor-quran-language');localStorage.removeItem('noor-quran-edition');localStorage.removeItem('noor-quran-translation-name');localStorage.removeItem('noor-notifications');localStorage.removeItem('noor-adhan-enabled');localStorage.removeItem('noor-reciter');localStorage.removeItem('noor-memorized-pages');localStorage.removeItem('noor-memorize-page');localStorage.removeItem('noor-hifz-meta');localStorage.removeItem('noor-hifz-target');bookmarks=[];customCounters=[];offlineSurahIds=[];prayerLocation={city:'Riyadh',country:'Saudi Arabia',lat:24.7136,lon:46.6753};$('#location-city').value='Riyadh';$('#location-country').value='Saudi Arabia';$('#prayer-method').value='4';updateQibla();daily=loadDaily();tasbeeh=loadTasbeeh();renderSaved();renderCustomCounters();renderTasbeeh();renderProgress();loadPrayerTimes();setTheme('dark');toast('Local NOOR data cleared.');}catch{toast('Could not clear all browser data.');}
});

if(!window.Capacitor?.isNativePlatform?.() && 'serviceWorker'in navigator && (location.protocol==='https:'||location.hostname==='localhost'||location.hostname==='127.0.0.1')){
  window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js').then(()=>{}).catch(()=>{}));
}
renderTasbeeh();renderCustomCounters();renderDuas();renderLesson('wudu');renderProgress();renderSaved();loadPrayerTimes();loadSurahIndex();
