@echo off
title NOOR - Local App
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 (
  echo Python launcher "py" was not found.
  echo Install Python 3 from https://www.python.org/downloads/
  echo Then run this file again.
  pause
  exit /b 1
)
start "" cmd /c "timeout /t 2 >nul & start http://localhost:8000"
echo NOOR is running at http://localhost:8000
echo Keep this window open while using the app.
echo Press Ctrl+C to stop the local server.
py -m http.server 8000
pause
