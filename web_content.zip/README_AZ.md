# ASAN MED — Android layihəsi

Bu layihə göndərdiyiniz `ASAN_MED_SOFTWARE_6_0.zip` arxivindəki `ASAN_MED_PRO/index.html` interfeysini Android WebView daxilində, internet bağlantısı tələb etmədən açır.

## APK necə yaradılır?

1. Kompüterdə Android Studio quraşdırın.
2. Android Studio-da **Open** seçərək bu qovluğu açın.
3. Gradle sinxronizasiyasının tamamlanmasını gözləyin və tələb olunarsa Android SDK Platform 35-i quraşdırın.
4. Menyudan **Build → Build Bundle(s) / APK(s) → Build APK(s)** seçin.
5. APK bu qovluqda yaranacaq: `app/build/outputs/apk/debug/app-debug.apk`.

## Bu APK-nın əhatəsi

- ASAN MED-in HTML/CSS/JavaScript demo interfeysi Android tətbiqində açılır.
- Brauzer `localStorage` yaddaşı aktivdir; demo məlumatları cihazda saxlanıla bilər.
- Bu layihə hazırda ayrıca Python API backend-ə qoşulmur. Arxivdəki backend, API klienti və rəsmi ASAN Login inteqrasiyası bu APK-ya daxil edilməyib.
- İlkin arxivin öz qeydlərinə görə bu, nümayiş/prototip mərhələsidir; real tibbi məlumatlar və real pasiyent xidməti üçün nəzərdə tutulmayıb.

## Texniki məlumat

- Application ID: `az.asanmed.app`
- Minimum Android: 6.0 (API 23)
- Compile SDK: 35
- Target SDK: 34
- Java: 17

Bu qovluq Android Studio layihəsidir, hazır APK deyil. APK-nın kompilyasiyası Android SDK/Gradle mühiti tələb edir.
