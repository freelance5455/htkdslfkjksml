# Divarpanel.az — Avtomatik qaimə (Android layihəsi)

## Funksiyalar
- Lokal cihaz yaddaşı (`localStorage`); internet olmadan əsas funksiyalar işləyir.
- Məhsul və müştəri bazası.
- Satış qaiməsi və qiymət təklifi.
- Avtomatik cəmləmə, endirim, çatdırılma, ilkin ödəniş və borc hesabı.
- Sənəd tarixçəsi, qismən ödəniş qeydiyyatı, borc hesabatı.
- Çap pəncərəsi vasitəsilə PDF kimi saxlama.
- WhatsApp paylaşımı (internet/WhatsApp tələb edir).
- JSON ehtiyat nüsxəsi çıxarma və bərpa.

## APK yaratmaq
Bu paket Android Studio layihə mənbəyidir; hazır imzalanmış APK deyil. Hazır APK-ni bu mühitdə kompilyasiya etmək üçün Android SDK/Gradle quraşdırılmayıb.

1. Kompüterdə Android Studio quraşdırın.
2. Android Studio → **Open** → bu qovluğu seçin.
3. Gradle sync tamamlanmasını gözləyin (JDK 17 və Android SDK Platform 35 tələb olunur).
4. **Build → Build APK(s)** seçin.
5. APK adətən `app/build/outputs/apk/debug/app-debug.apk` yolunda yaranır.

## İstifadə
1. APK-ni Android telefona quraşdırın.
2. Əvvəlcə Parametrlər bölməsində mağaza məlumatlarını daxil edin.
3. Məhsul bazasına məhsul, kod, ölçü və qiymətləri əlavə edin.
4. Yeni sənəd bölməsində müştəri və məhsulları seçin.
5. Sənədi yadda saxlayın; PDF/Çap və WhatsApp paylaşımından istifadə edin.
6. Mütəmadi olaraq Hesabat bölməsindən JSON ehtiyat nüsxəsi çıxarın.

## Vacib məhdudiyyətlər
- Məlumatlar yalnız bu tətbiqin lokal yaddaşında saxlanılır. Tətbiqin məlumatlarını silmək və ya tətbiqi silmək məlumat itkisinə səbəb ola bilər; ehtiyat nüsxə çıxarın.
- PDF yaratmaq üçün çap dialoqundan “PDF kimi saxla” seçilir. WebView/cihazdan asılı olaraq çap davranışı dəyişə bilər.
- WhatsApp düyməsi qaimənin mətnini paylaşır; PDF faylını birbaşa əlavə etmir. PDF-ni ayrıca saxlayıb WhatsApp-da fayl kimi göndərmək olar.
- Bu daxili satış qaiməsi/qiymət təklifidir, rəsmi vergi elektron qaiməsi deyil.
