YouTube Engine — no API key / no YouTube embed

This is a YouTube-style HOME FEED prototype, not a search-engine landing page.
Features:
- Home video feed from a public alternative catalog API
- Separate Shorts section (best effort; availability depends on the selected public instance)
- Trending and topic/category browsing
- Search for video listings
- Thumbnails, titles, creator names, view counts when returned
- Save videos locally
- Dark/light theme, responsive mobile layout

How data is fetched:
The app tries several public Invidious-compatible instances, which expose public video metadata without a YouTube Data API key. The official documentation lists search, trending/popular, and shortVideo metadata endpoints. These are third-party services, not access to YouTube's private internal database.

Important limitations:
- Public instances can be down, rate-limited, or block browser requests. If all fail, the feed will show an error instead of fake videos.
- No YouTube embed is used. Clicking a card opens the original YouTube watch page. Direct playback of arbitrary YouTube videos inside the app is not included.
- Shorts detection and catalog availability vary by instance.
- This is an HTML prototype, not a signed native Android APK.

Use:
1. Extract the ZIP.
2. Open index.html in a modern browser, or host it on a static web host.
3. If the feed fails, tap Refresh and try later.
