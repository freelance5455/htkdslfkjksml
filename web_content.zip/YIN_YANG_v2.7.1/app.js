// YOUTUBE x Yin Yang v2.0 JavaScript Engine
document.addEventListener('DOMContentLoaded', () => {
    const landingScreen = document.getElementById('landing-screen');
    const mainApp = document.getElementById('main-app');
    const btnEnterApp = document.getElementById('btn-enter-app');
    const searchInput = document.getElementById('search-input');
    const searchBtn = document.getElementById('search-btn');
    const videoGrid = document.getElementById('video-grid');
    const chipCodingLogout = document.getElementById('chip-coding-logout');
    
    // UN Commands Logic
    const SECRET_ON = 'UpdateNewYinYang';
    const SECRET_OFF = 'unUpdateNewYinYang';

    const videos = [
        { id: 1, title: 'Yin Yang Hub - Blox Fruits Auto Farm Script Review v2.0', channel: 'Yin Yang Official', views: '250K', duration: '10:25', thumb: 'https://images.unsplash.com/photo-1542751371-adc38448a05e', script: 'loadstring(game:HttpGet("https://raw.githubusercontent.com/YinYang/BloxFruits/main/script.lua"))()' },
        { id: 2, title: 'Evade Roblox - Auto Evade & Godmode Script Showcase', channel: 'Yin Yang Dev', views: '180K', duration: '08:14', thumb: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe', script: 'loadstring(game:HttpGet("https://raw.githubusercontent.com/YinYang/Evade/main/script.lua"))()' },
        { id: 3, title: 'Murder Mystery 2 - ESP & Silent Aim Script Yin Yang', channel: 'Yin Yang Security', views: '310K', duration: '12:00', thumb: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f', script: 'loadstring(game:HttpGet("https://raw.githubusercontent.com/YinYang/MM2/main/script.lua"))()' }
    ];

    btnEnterApp.addEventListener('click', () => {
        landingScreen.classList.add('hidden');
        mainApp.classList.remove('hidden');
        renderVideos();
        renderScriptHub();
    });

    function renderVideos() {
        videoGrid.innerHTML = '';
        videos.forEach(v => {
            const card = document.createElement('div');
            card.className = 'video-card';
            card.innerHTML = `
                <div class="thumb-wrap">
                    <img src="${v.thumb}" alt="thumb">
                    <span class="duration">${v.duration}</span>
                </div>
                <div class="video-details">
                    <div class="video-title">${v.title}</div>
                    <div class="video-meta">${v.channel} • ${v.views} ครั้ง</div>
                </div>
            `;
            card.addEventListener('click', () => openVideoModal(v));
            videoGrid.appendChild(card);
        });
    }

    function renderScriptHub() {
        const list = document.getElementById('script-list');
        list.innerHTML = '';
        videos.forEach(v => {
            const sc = document.createElement('div');
            sc.className = 'script-card';
            sc.innerHTML = `
                <h3>${v.title}</h3>
                <p style="color:#aaa; font-size:13px; margin-bottom:10px;">Supported Game: Roblox</p>
                <textarea readonly>${v.script}</textarea>
                <button class="btn-glow-purple" onclick="navigator.clipboard.writeText('${v.script}')"><i class="fa-solid fa-copy"></i> คัดลอกสคริปต์</button>
            `;
            list.appendChild(sc);
        });
    }

    function openVideoModal(video) {
        document.getElementById('modal-video-title').innerText = video.title;
        document.getElementById('video-modal').classList.remove('hidden');
        document.getElementById('btn-get-script').onclick = () => {
            navigator.clipboard.writeText(video.script);
            alert('คัดลอกสคริปต์เรียบร้อย!');
        };
    }

    document.getElementById('close-video-modal').addEventListener('click', () => {
        document.getElementById('video-modal').classList.add('hidden');
    });

    function processCommand(cmd) {
        if (cmd === SECRET_ON) {
            document.body.className = 'hacker-theme';
            document.querySelectorAll('.secret-tab').forEach(el => el.classList.remove('hidden'));
            document.getElementById('logo-text').innerHTML = 'YinYang <span class="tag-yy">ScriptHub</span>';
            alert('🔓 ปลดล็อกโหมด Yin Yang Script Hub & Dev Center เรียบร้อย!');
        } else if (cmd === SECRET_OFF) {
            document.body.className = 'dark-theme';
            document.querySelectorAll('.secret-tab').forEach(el => el.classList.add('hidden'));
            document.getElementById('logo-text').innerHTML = 'YouTube <span class="tag-yy">YinYang</span>';
            switchTab('home');
            alert('🔒 ปิดโหมดลับ คืนค่าสู่หน้า YouTube ปกติเรียบร้อย');
        }
    }

    searchBtn.addEventListener('click', () => processCommand(searchInput.value.trim()));
    searchInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') processCommand(searchInput.value.trim());
    });

    chipCodingLogout.addEventListener('click', () => {
        const code = prompt('กรอกรหัสลับเปิด/ปิดโหมด (UpdateNewYinYang / unUpdateNewYinYang):');
        if (code) processCommand(code.trim());
    });

    function switchTab(tabName) {
        document.querySelectorAll('.view-section').forEach(el => el.classList.add('hidden'));
        if (tabName === 'home') document.getElementById('view-youtube').classList.remove('hidden');
        if (tabName === 'scripthub') document.getElementById('view-scripthub').classList.remove('hidden');
        if (tabName === 'obfuscator') document.getElementById('view-obfuscator').classList.remove('hidden');
        if (tabName === 'builder') document.getElementById('view-builder').classList.remove('hidden');
        if (tabName === 'redeem') document.getElementById('view-redeem').classList.remove('hidden');
    }

    document.querySelectorAll('.nav-item').forEach(item => {
        item.addEventListener('click', () => switchTab(item.getAttribute('data-tab')));
    });

    // AI Obfuscator Engine 60s
    const btnLockCode = document.getElementById('btn-lock-code');
    const btnGetCode = document.getElementById('btn-get-code');
    const timerContainer = document.getElementById('timer-container');
    const timerSeconds = document.getElementById('timer-seconds');
    const timerProgress = document.getElementById('timer-progress');
    let obfuscatedResult = '';

    btnLockCode.addEventListener('click', () => {
        const inputCode = document.getElementById('obfuscate-input').value;
        if (!inputCode.trim()) { alert('กรุณาใส่โค้ดสคริปต์ก่อนประมวลผล'); return; }

        btnLockCode.classList.add('hidden');
        timerContainer.classList.remove('hidden');
        let timeLeft = 60;

        const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()_+-=[]{}|;:,.<>?';
        obfuscatedResult = '-- [Yin Yang AI Obfuscator v2.0 Encrypted Code]
local YY_SEC = "';
        for (let i = 0; i < 200; i++) obfuscatedResult += chars.charAt(Math.floor(Math.random() * chars.length));
        obfuscatedResult += '"
return loadstring(game:HttpGet("' + obfuscatedResult.substring(0, 30) + '"))()';

        const timer = setInterval(() => {
            timeLeft--;
            timerSeconds.innerText = timeLeft;
            timerProgress.style.width = ((60 - timeLeft) / 60 * 100) + '%';

            if (timeLeft <= 0) {
                clearInterval(timer);
                timerContainer.classList.add('hidden');
                btnGetCode.classList.remove('hidden');
            }
        }, 1000);
    });

    btnGetCode.addEventListener('click', () => {
        document.getElementById('result-code-text').value = obfuscatedResult;
        document.getElementById('code-result-modal').classList.remove('hidden');
    });

    document.getElementById('close-code-modal').addEventListener('click', () => {
        document.getElementById('code-result-modal').classList.add('hidden');
    });

    document.getElementById('btn-copy-code').addEventListener('click', () => {
        navigator.clipboard.writeText(obfuscatedResult);
        alert('คัดลอกโค้ดสคริปต์ Obfuscated เรียบร้อย!');
    });

    // Strict Builder Form Submission
    document.getElementById('strict-builder-form').addEventListener('submit', (e) => {
        e.preventDefault();
        alert('✅ บันทึกและอนุมัติสคริปต์เข้าสู่ระบบ Yin Yang เรียบร้อยแล้ว!');
        document.getElementById('strict-builder-form').reset();
    });
});
