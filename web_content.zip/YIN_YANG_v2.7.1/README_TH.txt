=================================================
☯️ YOUTUBE x Yin Yang v2.0 Ultimate Full Package
=================================================

แพ็กเกจไฟล์พัฒนาระบบเว็บแอปพลิเคชันมัลติฟังก์ชันฉบับสมบูรณ์ 1,000,000%

📌 โครงสร้างไฟล์ในแพ็กเกจนี้:
-------------------------------------------------
1. index.html           : ไฟล์โครงสร้าง HTML หน้า Landing Markdown + YouTube App
2. styles.css           : ไฟล์สไตล์ Responsive PC/Mobile + Multi-Theme (Dark/Hacker)
3. app.js               : ระบบควบคุมหลัก (UN Commands, Video Modal, AI Obfuscator)
4. API_SPEC_TH.md       : เอกสารจำลอง API Endpoint สำหรับเชื่อมต่อ Backend
5. DATABASE_SCHEMA.sql  : โครงสร้างฐานข้อมูล SQL สำหรับระบบ Yin Yang
6. script_hub.lua       : สคริปต์ตัวอย่างสำหรับทดสอบระบบ

🚀 วิธีการใช้งานระบบสั่งการ (UN System):
-------------------------------------------------
- พิมพ์คำสั่ง: UpdateNewYinYang -> เพื่อเปิดโหมดลับ Hacker Script Hub
- พิมพ์คำสั่ง: unUpdateNewYinYang -> เพื่อปิดโหมดลับ กลับสู่ YouTube ปกติ

🛡️ ระบบ AI Obfuscator (60s Lock Code):
-------------------------------------------------
- นำสคริปต์ปกติวางลงในช่อง -> กด Lock Code -> รอเวลานับถอยหลัง 60 วินาที
- เมื่อครบกำหนดจะปรากฏปุ่ม Get Code เพื่อรับรหัสสคริปต์ที่เข้ารหัสอย่างแน่นหนา
