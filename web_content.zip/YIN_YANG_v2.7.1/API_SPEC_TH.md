# 📡 Yin Yang Backend API Specifications (v2.0)

## Endpoints Summary

### 1. Secret Mode Status
- **POST** `/api/v1/system/toggle-mode`
- **Request Body**: `{ "command": "UpdateNewYinYang" }`
- **Response**: `{ "status": "success", "mode": "hacker", "access": true }`

### 2. AI Script Obfuscator
- **POST** `/api/v1/obfuscate`
- **Request Body**: `{ "source_code": "string", "timer": 60 }`
- **Response**: `{ "status": "processing", "job_id": "yy_9841" }`

### 3. Strict Script Builder
- **POST** `/api/v1/scripts/create`
- **Request Body**:
  ```json
  {
    "name": "Yin Yang Blox Fruits",
    "supported_map": "Blox Fruits",
    "anticheat": "Bypassed 100%",
    "image_url": "https://...",
    "source_code": "..."
  }
  ```
