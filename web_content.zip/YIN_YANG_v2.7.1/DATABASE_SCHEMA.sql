-- Yin Yang Database Schema v2.0
CREATE TABLE users (
    user_id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) NOT NULL,
    yyp_points INT DEFAULT 1500,
    vip_level INT DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE scripts (
    script_id INT PRIMARY KEY AUTO_INCREMENT,
    script_name VARCHAR(100) NOT NULL,
    supported_map VARCHAR(100) NOT NULL,
    anticheat_status VARCHAR(50) NOT NULL,
    image_url TEXT NOT NULL,
    obfuscated_code TEXT NOT NULL,
    author_id INT,
    FOREIGN KEY (author_id) REFERENCES users(user_id)
);
