/* JOSTECH — MANUEL 09 : GÉNIE LOGICIEL NIVEAU 1 */
registerLessonDetail(9, 1, "gl-1-1-1", {
  title: "Leçon 1 : Cycle de Vie Logiciel, Cascade, Cycle en V et Scrum",
  duration: "40 min (Manuel complet)",
  objectives: [
    "Comprendre la « crise du logiciel » et la naissance du Génie Logiciel (1968).",
    "Comparer les modèles séquentiels (Cascade, Cycle en V) et les méthodes Agiles (Scrum).",
    "Rédiger des User Stories et critères d'acceptation clairs pour un cahier des charges."
  ],
  prerequisites: ["Notions de programmation."],
  sections: [
    {
      type: "definition",
      term: "Génie Logiciel (Software Engineering)",
      text: "Discipline d'ingénierie née en 1968 face aux dérives budgétaires et retards des grands projets informatiques. Son objectif est de concevoir, développer, tester et maintenir des logiciels fiables, dans les délais et les coûts prévus, grâce à des méthodes rigoureuses."
    },
    {
      type: "theory",
      title: "1. Cascade & Cycle en V vs Méthode Agile (Scrum)",
      text: "Tout logiciel traverse un cycle de vie (SDLC) : Analyse des besoins → Conception → Codage → Tests → Déploiement → Maintenance.\n• Modèle en Cascade / Cycle en V : on termine entièrement une phase avant la suivante. Très sûr dans l'aéronautique ou le médical où tout est spécifié d'avance, mais très risqué si les besoins évoluent.\n• Méthodes Agiles (Manifeste Agile, 2001) : on livre de la valeur par itérations courtes de 1 à 4 semaines appelées « Sprints ». C'est exactement l'approche suivie pour bâtir JOSTECH phase par phase !"
    },
    {
      type: "table",
      title: "2. L'équipe et les rituels Scrum",
      headers: ["Élément Scrum", "Rôle exact"],
      rows: [
        ["Product Owner (PO)", "Représente la vision client et priorise le Product Backlog (liste des fonctions)."],
        ["Scrum Master", "Garantit la méthode Agile et débloque l'équipe."],
        ["Daily Stand-up", "Point quotidien de 15 min : Fait hier ? Prévu aujourd'hui ? Blocages ?"],
        ["Sprint Review & Rétro", "Démonstration du produit fonctionnel + amélioration des processus d'équipe."]
      ]
    },
    {
      type: "code",
      lang: "Format officiel d'une User Story Agile",
      code: [
        "En tant que [type d'utilisateur],",
        "Je veux [action / fonctionnalité],",
        "Afin de [bénéfice attendu].",
        "",
        "Exemple JOSTECH : « En tant qu'étudiant, je veux télécharger mes leçons,",
        "afin de pouvoir réviser dans le bus sans connexion Internet. »"
      ].join("\n")
    }
  ],
  exercises: [
    {
      title: "Exercice 1 — Choix de méthode de projet",
      question: "Vous dirigez le logiciel de freinage d'un avion (spécifications fixes à 100 %, sécurité critique) et parallèlement une application mobile grand public dont le marché change chaque mois. Quel modèle (Cycle en V ou Scrum) choisissez-vous pour chacun ?",
      solution: "1) Avion : Cycle en V (traçabilité totale, tests rigoureux face à chaque spécification).\n2) App mobile : Scrum Agile (livraisons rapides, adaptation continue aux retours utilisateurs)."
    },
    {
      title: "Exercice 2 — Rédiger une User Story",
      question: "Transformez ce besoin vague : « Il faut un bouton favoris » en une véritable User Story professionnelle.",
      solution: "« En tant qu'apprenant connecté, je veux ajouter une leçon en favori (★), afin de retrouver immédiatement mes chapitres prioritaires dans mon profil. »"
    }
  ],
  summary: "Le génie logiciel structure la création de logiciels fiables. Le Cycle en V sécurise les systèmes critiques figés, tandis que Scrum Agile excelle pour les produits numériques évolutifs.",
  references: ["Manifeste Agile (agilemanifesto.org).", "Sommerville, I. — Software Engineering (10th Ed.)."]
});