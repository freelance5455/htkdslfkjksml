import 'dotenv/config';
import express from 'express';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';

const app = express();
const PORT = Number(process.env.PORT || 3000);
const API_KEY = process.env.GEMINI_API_KEY;
const ALLOWED_ORIGIN = process.env.ALLOWED_ORIGIN || '';

app.disable('x-powered-by');
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: '12mb' }));
app.use(rateLimit({ windowMs: 60_000, limit: 30, standardHeaders: 'draft-7', legacyHeaders: false }));

app.use((req, res, next) => {
  const origin = req.headers.origin;
  if (origin && (!ALLOWED_ORIGIN || origin !== ALLOWED_ORIGIN)) return res.status(403).json({ error: { message: 'Origin not allowed. Configure ALLOWED_ORIGIN on the server.' } });
  if (origin && origin === ALLOWED_ORIGIN) {
    res.setHeader('Access-Control-Allow-Origin', origin);
    res.setHeader('Vary', 'Origin');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
    res.setHeader('Access-Control-Allow-Methods', 'GET,POST,OPTIONS');
  }
  if (req.method === 'OPTIONS') return res.sendStatus(204);
  next();
});

app.get('/api/health', (_req, res) => res.json({ ok: true, service: 'SVEXO AI API proxy', configured: Boolean(API_KEY) }));

app.post('/api/chat', async (req, res) => {
  if (!API_KEY) return res.status(503).json({ error: { message: 'Server is missing GEMINI_API_KEY.' } });
  const { model = 'gemini-2.5-flash', contents, system_instruction, generationConfig } = req.body || {};
  const allowedModels = new Set(['gemini-2.5-flash', 'gemini-2.0-flash']);
  if (!allowedModels.has(model)) return res.status(400).json({ error: { message: 'Unsupported model.' } });
  if (!Array.isArray(contents) || !contents.length || JSON.stringify(contents).length > 9_000_000) {
    return res.status(400).json({ error: { message: 'Missing conversation or request too large.' } });
  }
  try {
    const upstream = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${encodeURIComponent(API_KEY)}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ contents, system_instruction, generationConfig })
    });
    const body = await upstream.json().catch(() => ({ error: { message: 'Invalid response from AI provider.' } }));
    res.status(upstream.status).json(body);
  } catch {
    res.status(502).json({ error: { message: 'Could not reach the AI provider.' } });
  }
});

app.listen(PORT, () => console.log(`SVEXO AI proxy listening on port ${PORT}`));
