# SVEXO AI — website source

Created by **SVEXO**. This is a responsive web application, not an Android APK. The ZIP you supplied was an Android/Gradle app; I inspected its structure and used the requested SVEXO AI identity to build this separate browser-based website. No old app code or screenshots are needed for this web version.

## Project files

- `index.html` — complete website structure and UI
- `style.css` — responsive styling and Light, Dark, Hacker themes
- `script.js` — chat UI, history, file parsing, voice, demo profile, Gemini connection
- `backend/` — optional Node.js Gemini proxy that keeps the API key on the server
- `README.md` — this guide

## Open on Android

### Quick static preview
1. Download and extract `SVEXO-AI-Website.zip`.
2. Open `index.html` in Chrome or another modern browser.
3. Themes, interface, demo profile, local chat history, and local UI work without an API key. Actual AI replies need a configured Gemini key or backend and an internet connection.
4. Some browsers restrict microphone, clipboard, or external libraries for `file://` pages. Use the local-server method below if something is blocked.

### Recommended local web server
On Android, use any local HTTP server app, or use Termux if already installed (Termux is optional, not an Android build requirement):
```sh
pkg install python
cd /path/to/extracted/svexo-ai
python -m http.server 8080
```
Then open `http://127.0.0.1:8080` in your browser. The folder path depends on where you extracted the ZIP. Stop the server with Ctrl+C.

## Configure real AI

### Option A — direct browser API key (development only)
1. Obtain a Gemini API key from Google AI Studio.
2. Open SVEXO AI → Settings → AI connection.
3. Paste the key and press **Save connection**.
4. The key remains only in the page's JavaScript memory; refreshing clears it. A browser-side key can still be inspected while the page is running. Do not use this method for a public production site.

### Option B — recommended server proxy
Requires Node.js 18+ on a computer or hosting service that supports Node applications. Do not place the server `.env` file in the public website folder.

1. Deploy the `backend` folder to a Node-capable host.
2. In `backend`, copy `.env.example` to `.env`, then set `GEMINI_API_KEY` to your private key. Set `ALLOWED_ORIGIN` to the exact URL of your frontend, for example `https://your-site.example`. Never commit `.env`.
3. Install and start:
   ```sh
   npm install
   npm start
   ```
4. The service exposes `POST /api/chat` and `GET /api/health`. Put the backend URL in SVEXO AI → Settings → AI connection → **Secure backend URL**, then save. Example: `https://api.your-site.example`.
5. Keep HTTPS enabled on the public site and backend. The proxy includes basic request rate limiting and an origin allow-list, but this is a starter proxy, not a complete abuse-prevention system. Add hosting-level quotas, monitoring, and stronger rate limits before public launch.

## Publish online / custom domain
Upload `index.html`, `style.css`, and `script.js` to a static host such as GitHub Pages, Cloudflare Pages, or Netlify. The frontend can be hosted statically; the optional proxy must run on a Node-capable host separately. Connect a custom domain in the host's domain settings and configure HTTPS. For a public production site, use the backend proxy and set `ALLOWED_ORIGIN` to your exact frontend origin.

## Implemented features

- Responsive chat layout and mobile navigation drawer
- SVEXO AI branding and creator identity
- Light, Dark, and Hacker themes saved between visits
- New conversations, local history, auto titles, rename/delete actions, clear history with confirmation, JSON export
- Gemini API integration with loading indicator and error messages for invalid keys, rate limits, and other API failures
- Session-only direct API key input; optional backend URL setting
- TXT, MD, CSV, JSON, HTML, PDF, DOCX text extraction; PNG/JPG/WEBP image attachment for models that accept image input
- Attachment name/size display, remove attachment, 8 MB per-file limit and up to 4 attachments per message
- Speech recognition with browser support/permission checks; optional text-to-speech and language choice
- Copy assistant responses and code blocks
- English, Hindi, and Nepali interface selector
- Local demo registration/login/logout with clear warning that it is not secure authentication

## Limitations and security

- **Accounts are a local demonstration only.** There is no production user database, password hashing, secure session, server authorization, or multi-device account sync. Do not use a real/reused password. For real accounts, integrate a trusted auth provider or build a proper backend.
- **Conversations are local to the browser/device.** They are not synced across users or devices. Do not enter sensitive data into a shared device.
- **Direct browser API mode is not secure for production.** Use the backend proxy to keep the Gemini key in server environment variables. A URL configured in the page is not secret.
- PDF.js and Mammoth are loaded from CDNs; first-time PDF/DOCX parsing needs internet. Scanned PDFs do not get OCR; the app reports when no readable text is extracted.
- Voice recognition support varies by browser, language, permissions, and secure context. HTTPS or localhost is usually needed. No fake recognition is used when the browser API is unavailable.
- AI model availability and pricing depend on your provider account. The API key is not validated until you send a message.
- The website has no database, payment system, or account backend configured by default.

## Quality checks performed
- Reviewed the generated file structure and verified all local files referenced by the HTML are present.
- JavaScript syntax check is performed with Node.js when available.
- This environment does not provide a real Gemini key, microphone permission, or a deployed browser session, so live AI, voice permissions, and online deployment cannot be claimed as end-to-end tested.
