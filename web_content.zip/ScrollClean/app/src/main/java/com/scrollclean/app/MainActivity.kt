package com.scrollclean.app

import android.Manifest
import android.content.ContentResolver
import android.content.ContentUris
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.util.Size
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.webkit.WebViewAssetLoader
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream

class MainActivity : AppCompatActivity() {

    companion object { const val HOST = "appassets.androidplatform.net" }

    private lateinit var web: WebView
    @Volatile private var trusted = false          // true only while our local page is loaded
    private var pendingUris: Map<String, Uri> = emptyMap()
    private var pendingSizes: Map<String, Long> = emptyMap()

    private val permLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { js("ScrollCleanNative.onPerm('" + state() + "')") }

    private val delLauncher = registerForActivityResult(
        ActivityResultContracts.StartIntentSenderForResult()
    ) { finishDelete() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        web = WebView(this)
        web.setBackgroundColor(0xFF121212.toInt())
        setContentView(web)
        ViewCompat.setOnApplyWindowInsetsListener(web) { v, ins ->
            val b = ins.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            v.setPadding(b.left, b.top, b.right, b.bottom)
            WindowInsetsCompat.CONSUMED
        }
        WindowCompat.getInsetsController(window, web).isAppearanceLightStatusBars = false

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
        }
        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                val u = request.url
                if (u.host != HOST) return empty(403)           // block everything off-origin
                if (u.path?.startsWith("/media/") == true) return thumb(u)
                return loader.shouldInterceptRequest(u)
            }
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest) =
                request.url.host != HOST                         // never navigate away
            override fun onPageStarted(view: WebView, url: String?, favicon: Bitmap?) {
                trusted = url?.startsWith("https://$HOST/assets/") == true
            }
        }
        web.addJavascriptInterface(Bridge(), "AndroidBridge")
        web.loadUrl("https://$HOST/assets/index.html")

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                web.evaluateJavascript("(window.scBack&&scBack())") { if (it != "true") finish() }
            }
        })
    }

    /** Only methods below are visible to JavaScript, and only for our own local page. */
    inner class Bridge {
        @JavascriptInterface fun getPermissionState(): String = if (trusted) state() else "denied"
        @JavascriptInterface fun requestPermission() { if (trusted) runOnUiThread { permLauncher.launch(perms()) } }
        @JavascriptInterface fun loadMedia(): String = if (trusted) queryMedia() else "[]"
        @JavascriptInterface fun deleteMedia(keys: String) { if (trusted) runOnUiThread { startDelete(keys) } }
    }

    private fun js(code: String) = runOnUiThread {
        web.evaluateJavascript("window.ScrollCleanNative&&$code", null)
    }

    // ---------- permissions ----------
    private fun perms(): Array<String> = when {
        Build.VERSION.SDK_INT >= 34 -> arrayOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO, Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED)
        Build.VERSION.SDK_INT >= 33 -> arrayOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO)
        else -> arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
    }
    private fun has(p: String) = checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED
    private fun state(): String = when {
        Build.VERSION.SDK_INT >= 33 -> when {
            has(Manifest.permission.READ_MEDIA_IMAGES) || has(Manifest.permission.READ_MEDIA_VIDEO) -> "granted"
            Build.VERSION.SDK_INT >= 34 && has(Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED) -> "partial"
            else -> "denied"
        }
        has(Manifest.permission.READ_EXTERNAL_STORAGE) -> "granted"
        else -> "denied"
    }

    // ---------- MediaStore ----------
    private fun baseUri(k: String): Uri =
        if (k == "v") MediaStore.Video.Media.EXTERNAL_CONTENT_URI else MediaStore.Images.Media.EXTERNAL_CONTENT_URI

    private fun queryMedia(): String {
        val out = JSONArray()
        val c = MediaStore.MediaColumns
        val proj = arrayOf(c._ID, c.DISPLAY_NAME, c.SIZE, c.DATE_ADDED, c.MIME_TYPE, c.RELATIVE_PATH)
        for (k in listOf("i", "v")) {
            val args = Bundle().apply {
                putInt(ContentResolver.QUERY_ARG_LIMIT, 400)
                putStringArray(ContentResolver.QUERY_ARG_SORT_COLUMNS, arrayOf(c.DATE_ADDED))
                putInt(ContentResolver.QUERY_ARG_SORT_DIRECTION, ContentResolver.QUERY_SORT_DIRECTION_DESCENDING)
            }
            try {
                contentResolver.query(baseUri(k), proj, args, null)?.use { cur ->
                    while (cur.moveToNext()) {
                        val size = cur.getLong(2)
                        if (size <= 0) continue
                        out.put(JSONObject()
                            .put("id", cur.getLong(0)).put("k", k)
                            .put("n", cur.getString(1) ?: "file").put("z", size)
                            .put("d", cur.getLong(3)).put("m", cur.getString(4) ?: "")
                            .put("s", (cur.getString(5) ?: "").contains("Screenshots", true)))
                    }
                }
            } catch (_: Exception) { }
        }
        return out.toString()
    }

    private fun sizeOf(u: Uri): Long = try {
        contentResolver.query(u, arrayOf(MediaStore.MediaColumns.SIZE), null, null, null)?.use { if (it.moveToFirst()) it.getLong(0) else 0L } ?: 0L
    } catch (_: Exception) { 0L }

    private fun exists(u: Uri): Boolean = try {
        contentResolver.query(u, arrayOf(MediaStore.MediaColumns._ID), null, null, null)?.use { it.count > 0 } ?: false
    } catch (_: Exception) { false }

    private fun empty(code: Int) = WebResourceResponse("text/plain", "utf-8", code, "Blocked", emptyMap(), ByteArrayInputStream(ByteArray(0)))

    /** Serves /media/<id>?k=i|v as a JPEG thumbnail straight from MediaStore. */
    private fun thumb(u: Uri): WebResourceResponse {
        val id = u.lastPathSegment?.toLongOrNull() ?: return empty(404)
        val k = if (u.getQueryParameter("k") == "v") "v" else "i"
        return try {
            val bmp = contentResolver.loadThumbnail(ContentUris.withAppendedId(baseUri(k), id), Size(1080, 1920), null)
            val bos = ByteArrayOutputStream()
            bmp.compress(Bitmap.CompressFormat.JPEG, 82, bos)
            WebResourceResponse("image/jpeg", null, 200, "OK", mapOf("Cache-Control" to "max-age=3600"), ByteArrayInputStream(bos.toByteArray()))
        } catch (_: Exception) { empty(404) }
    }

    // ---------- deletion (system confirmation dialog, never silent) ----------
    private fun startDelete(json: String) {
        try {
            val arr = JSONArray(json)
            val uris = LinkedHashMap<String, Uri>()
            val sizes = HashMap<String, Long>()
            for (i in 0 until arr.length()) {
                val key = arr.getString(i)
                val p = key.split(":")
                if (p.size != 2 || (p[1] != "i" && p[1] != "v")) continue
                val id = p[0].toLongOrNull() ?: continue
                val u = ContentUris.withAppendedId(baseUri(p[1]), id)
                uris[key] = u; sizes[key] = sizeOf(u)
            }
            if (uris.isEmpty()) return
            pendingUris = uris; pendingSizes = sizes
            val pi = MediaStore.createDeleteRequest(contentResolver, uris.values.toList())
            delLauncher.launch(IntentSenderRequest.Builder(pi.intentSender).build())
        } catch (_: Exception) {
            js("ScrollCleanNative.onDelete({keys:[],bytes:0})")
        }
    }

    /** Recovered bytes = sizes of files that really no longer exist after the system dialog. */
    private fun finishDelete() {
        Thread {
            val keys = JSONArray(); var bytes = 0L
            for ((k, u) in pendingUris) if (!exists(u)) { keys.put(k); bytes += pendingSizes[k] ?: 0L }
            js("ScrollCleanNative.onDelete({keys:$keys,bytes:$bytes})")
        }.start()
    }
}
