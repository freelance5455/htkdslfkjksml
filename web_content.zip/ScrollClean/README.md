# ScrollClean (Android)

## Folder structure
ScrollClean/
  settings.gradle.kts, build.gradle.kts, gradle.properties
  gradle/wrapper/gradle-wrapper.properties
  app/build.gradle.kts
  app/src/main/AndroidManifest.xml
  app/src/main/java/com/scrollclean/app/MainActivity.kt
  app/src/main/assets/index.html        <- your UI (same design, gestures, animations)
  app/src/main/res/values/themes.xml
  app/src/main/res/drawable/ic_launcher.xml

## Build the APK (beginner steps)
1. Install Android Studio (latest stable) from developer.android.com/studio.
2. File > Open, choose the ScrollClean folder. Click "Trust Project" if asked.
3. Wait for "Gradle sync" to finish (first time downloads Gradle and libraries; needs internet).
4. Build > Build Bundle(s) / APK(s) > Build APK(s). Click "locate" in the popup.
   The file is app/build/outputs/apk/debug/app-debug.apk
5. Copy the APK to your phone, open it, allow "Install unknown apps" for your file manager, install.

## Run directly from Android Studio
Phone: Settings > About phone > tap Build number 7 times > Developer options > USB debugging on.
Plug in with USB, accept the prompt, pick your phone at the top of Studio, press the green Run button.

## Behaviour
- Android 13+: asks for photo/video access. Android 14+: "Select photos" (partial) is supported, the app cleans only what you shared and offers "Select more".
- Deleting uses MediaStore.createDeleteRequest: Android shows its own confirmation. Deletion is permanent.
- "Recovered" storage = sizes of files that no longer exist after Android finishes.
- No all-files access, no internet permission, and the JS bridge only works for the app's own local page.
