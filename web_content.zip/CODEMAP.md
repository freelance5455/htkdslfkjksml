# CODEMAP — mapa de index.html

> Generado por `node tools/build.js` (o `node tools/codemap.js`). **No editar a mano.** Sirve para leer solo la zona necesaria en vez del archivo entero.

- Líneas: 1621 · tamaño: 197 KB · líneas de más de 600 caracteres: 6

## Bloques

| Bloque | Líneas |
|---|---|
| CSS | 5–229 |
| script id="bal" | 253–373 |
| script | 374–1596 |
| script id="icons" | 1597–1620 |

**Pantallas HTML (`.scr`):** splash@231, menu@232, book@247, mis@247, set@247, gac@247, roul@247, arc@247, lvl@248, pause@249, over@250, err@251, ckwin@252

## Secciones (comentarios `// ----` y `// =====`)

- L328: Nivel de cuenta y misiones. Las misiones dan XP de cuenta; el nivel desbloquea las dificultades ×2, ×5 y ×10.
- L362: Grimorio arcano: habilidades que SOLO salen del gacha. Probabilidad ∝ 1/Q_P^rareza (Legendaria = 1 %), poder
- L376: Diagnóstico (F15): registro circular de eventos y captura global de errores. Solo datos de juego, nada persona
- L389: Guardado a prueba de fallos (F6-F9): versión + migraciones, copia doble con suma de comprobación, exportar/imp
- L449: datos: tipos [nombre monstruo, tipo, paleta base/sombra/luz]
- L516: Grimorio arcano (solo gacha): id, nombre, tipo, icono, rareza (0-3), descripción. El poder = 2,5^rareza · 1,25
- L540: Resumen de partida y registro local (F16). Contadores simples: sin coste apreciable en el bucle.
- L582: Misiones
- L650: fondos nuevos: refugio nocturno (inicio y menús) y cosmos místico (gacha)
- L801: habilidades arcanas en combate (solo se equipan desde el Grimorio; no existen en SK ni salen al subir de nivel
- L930: CHAOS KING: mega jefe de 2 barras, arena cerrada y habilidades con sprites (fx_*)
- L1151: invocación (banner mixto: personajes + compañeros; mismo coste, mismas rarezas y misma garantía)
- L1200: Grimorio arcano: gacha de habilidades exclusivas (150 ✦, ×10 = 1500 ✦). Prob.: 76,7 / 18,1 / 4,2 / 1 % (cada r
- L1283: selección de banner estilo «deseos»: pestañas arriba, cartel con el destacado al centro y botones x1 / x10 aba
- L1408: Escenarios por ETAPA (uno por cada etapa de 10 oleadas, ver BAL.ERAS; procedural, capas en espacio de mundo, c
- L1586: Service worker con aviso de actualización (F11): la versión nueva espera a que el jugador pulse ACTUALIZAR.

## Funciones de primer nivel

fail(e,src)@379 · rs()@386 · toast(msg,ms,key)@398 · loadSave()@399 · save()@410 · exportCode()@420 · parseCode(c)@421 · importObj(o)@430 · askCorrupt()@434 · sane()@531 · rsTop(o)@544 · rsEnd(v)@545 · hpSpark(h)@553 · summaryHTML(S0,v)@556 · errReport()@563 · errUI()@570 · cleanRun(r)@571 · menu()@572 · miRoll()@584 · miClaim(list)@593 · missions(g,msg)@595 · book()@612 · ainit()@623 · nt(f,d,ty,v,sl,at)@624 · sfx(k)@627 · mtick()@630 · wl()@641 · vig()@642 · ridge(base,amp,fr,ph,col,u0)@652 · bgHome(tt)@653 · bgGacha(tt)@665 · parade(tt,g)@676 · title()@685 · setUI(back)@693 · start()@721 · boom(px,py,c,n)@737 · near()@738 · frost(e)@741 · dropHeal(x,y)@743 · heal(n,force)@744 · hurt(e,d,el,px,py,q)@745 · blast(bx,by,R,dm,el,col,stun,ex)@752 · newSk(dt)@759 · drawZn()@785 · drawZn2()@791 · arStart()@803 · arAoe(cx,cy,R,dm,el,fn)@806 · arRevive()@807 · arKill()@811 · arcSk(dt)@813 · drawArc()@850 · pushP(cx,cy,R,dist)@866 · push(e,a,dist,dep)@867 · sepEn()@869 · hitP(dm,st,src)@872 · mk(id,x0,y0,elite)@880 · mkBoss(mini,tier)@888 · waveBosses()@894 · bossAI(e,dt)@902 · ckClamp(o,m)@931 · startCK()@932 · ckBar2(e)@939 · ckWin(e)@941 · ckTick(dt)@942 · ckCast(e,k,T,a,f2)@949 · ckFire(g)@956 · ckAI(e,dt,a,d)@962 · ckDraw()@970 · bombard(e)@979 · tgFire(g)@980 · offerList()@994 · lvlUp()@1000 · pick(k)@1015 · die(v)@1021 · up(dt)@1026 · wheel(tt)@1154 · spinNow()@1171 · spinTen()@1177 · spinDone(r)@1192 · arcBG(tt)@1204 · arcSpinN(n)@1214 · arcDone(r)@1221 · arcUI()@1222 · roulUI()@1249 · gacBanners()@1285 · gacUI()@1300 · gacBG(tt)@1319 · R(c,a,b,w,h)@1329 · waveId(fodder)@1335 · orcPick()@1336 · loadSprites()@1338 · vfd(k,fr,px,py,W,H,row,ang,al)@1342 · sprN(e,fl,tm,key,mul)@1346 · sprO(e,fl,tm)@1351 · spr(e,fl,tm)@1354 · fxs(k,px,py,S,tm,fps,ang)@1364 · heroS(n,px,py,tm)@1370 · PL(c,pts)@1377 · mon(k,px,py,r,fl,tm,ph)@1379 · hero(px,py,fm,fc,tm)@1398 · bgDecor(k,px,py,h,B,al,t)@1422 · bgDraw(cx,cy)@1435 · hpBar(x0,y0,w,h,f,c1,c2,tr,bc)@1488 · hpTxt(s,cx,cy,sz,col)@1493 · draw()@1496 · loop(ts)@1570 · showUpd(w)@1587 · icEl(k)@1602 · icText(t)@1603 · iconize(n)@1608 · drawIco(x,ch,cx,cy,sz)@1612

## Tablas y constantes de datos

BAL@254 · ARC@270 · AFF@276 · THEMES@280 · ERAS@295 · BOSS_EARLY@305 · PAT@315 · DIF@326 · ACC_MAX@330 · MIS@334 · DQ@349 · MI@354 · MAX_SK@355 · ARC_W@363 · T0@377 · SAVE_V@390 · MIGR@393 · DF@445 · EL@450 · CATN@453 · SK@455 · CH@489 · SUP@500 · SYN@509 · POOL@513 · AP@514 · SH@515 · AR@517 · ARI@530 · RS@541 · WT@619 · SF@625 · SQ@626 · MCH@629 · STR@651 · PAR@675 · CK_WAVES@719 · AC@736 · KB@887 · GP@1152 · AFX@1203 · SPN@1331 · GALE_A@1341 · FXD@1361 · HMAP@1366 · BIO@1410 · RM@1416 · ICM@1599 · ICIMG@1600 · VS@1601

## Líneas muy largas

L149 (964), L535 (783), L1238 (787), L1267 (670), L1580 (710), L1599 (838)
