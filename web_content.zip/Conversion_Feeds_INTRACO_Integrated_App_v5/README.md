# Conversion Feeds Ltd. | INTRACO Feed Costing App

Commercial-ready PWA/native-wrapper source package for feed costing and farm management.

## Updated in this release
- 32 embedded formulas, including the two requested 100 kg swine formulas:
  - Piglet Weaning 20% Concentrate — 2nd Month: 46 kg maize/corn + 20 kg maize bran + 20 kg piglet weaning 20% CCT + 14 kg soya bean.
  - Piglet Starter Twist Concentrate 10% — 3rd Month: 45 kg maize/corn + 25 kg maize bran + 10 kg piglet twist starter 10% CCT + 20 kg soya bean.
- Farm Calculator summaries expanded for each enterprise.
- Layer: feed/day, week, month; monthly feed cost; daily/weekly/monthly eggs; monthly egg revenue; other expenses; net revenue.
- Broiler: feed/day, week, month; monthly feed cost; birds sold; sales revenue; other expenses; net revenue.
- Dairy: feed/day, week, month; monthly feed cost; milk/day, week, month; milk revenue; animal sales; other expenses; net revenue.
- Swine: feed/day, week, month; monthly feed cost; pigs sold; sales revenue; other expenses; net revenue.
- PDF downloads are generated as table-formatted PDF files with title, enterprise/formula name, metadata and totals.
- PDF downloads available from Dashboard, Feed Costing, Price Book, Farm Calculator, My Formulas and Farmer Information.
- INTRACO splash screen on app startup with “EXPERT ADVICE AND RESPONSIBLE SOLUTIONS”.
- Blue, red and white professional visual theme.
- Removed the old prototype payment-data statement and old workbook footer wording.

## Launch/build
Open `START HERE.html` or `index.html` in a browser, or host over HTTPS for PWA installation. For Google Play, wrap/build this web app in the Android project and produce a signed AAB.

## Important pricing note
The requested swine formula concentrate “Piglet Twist Starter 10% CCT” has no price shown in the supplied image, so its initial price is set to UGX 0 and is editable in the Price Book. The existing Piglet Weaning 20% concentrate price is linked to the current INTRACO price book entry.


## Piglet concentrate correction
- Removed duplicate Piglet weaning 20% CCT and Piglet Twist Starter 10% CCT price-book entries.
- Canonical concentrate: Intraco Piglet Weaning 20% — UGX 183,000 per 20 kg bag.
- Canonical concentrate: Intraco Piglet Starter — UGX 198,000 per 20 kg bag.
- The two swine formulas now reference these canonical Intraco concentrate names.


## v5 UI consolidation
- Integrated the detailed table-style PDF reporting system.
- Removed the four Price Book tabs and replaced them with a single table-based page.
- Removed the four Farm Calculator tabs and replaced them with one enterprise selector plus one complete summary table.
- Preserved the 32 INTRACO formulas, including Piglet Weaning 20% and Piglet Starter 10%.
- Preserved Intraco Piglet Weaning 20% at UGX 183,000/20 kg and Intraco Piglet Starter at UGX 198,000/20 kg.
- Application identity is Conversion Feeds Ltd. | INTRACO only.
