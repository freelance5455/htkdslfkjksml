# Release Notes - INTRACO Feed Costing App

## Version 2.0 update
1. Added two 100 kg swine formulas from the supplied reference image.
2. Expanded farm summaries by enterprise.
3. Converted downloads to table-formatted PDF reports.
4. Added titles and relevant metadata to PDF files.
5. Removed prototype payment-data wording.
6. Removed old workbook/UGX footer wording.
7. Added INTRACO startup splash and company motto.
8. Applied professional blue/red/white visual theme.

## Developer acceptance tests
- Select Swine and confirm F31/F32 each total exactly 100 kg.
- Edit ingredient prices and verify cost/kg changes.
- Edit concentrate prices and verify cost/kg changes.
- Download a formula PDF and confirm a table is present.
- Download a farm summary PDF for all four enterprise tabs.
- Relaunch app and confirm the INTRACO splash appears.
- Install as PWA and verify icon/manifest.

## PDF reporting / attribution update
- Print and Download actions now generate detailed table-based PDF reports.
- PDF reports include titles, relevant inputs, all table rows, totals and calculated results.
- App attribution: `App created by 11:5:14 Tech's`.


## PDF detail correction v4
- Reports now include all entered assumptions/inputs plus calculated summaries where applicable.
- Feed costing PDFs include every ingredient, inclusion, price/kg, line cost, total mix, total cost, cost/kg and cost per 50 kg.
- Farm PDFs include all user-entered assumptions and all calculated results for the selected enterprise.
- Price Book PDFs include all ingredient and concentrate prices, bag weights and calculated price/kg.
- Multi-page PDFs repeat the title, metadata and table headers on each page.
