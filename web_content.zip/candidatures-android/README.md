# Candidatures — app Android

Ton CV, tes documents et le suivi de tes candidatures, stockés sur le téléphone.

## Obtenir l'APK

1. Crée un dépôt GitHub (privé si tu veux) et pousse ce dossier sur la branche `main`.
2. Onglet **Actions** → workflow **Build APK** → attends la coche verte (2 à 4 min).
3. Ouvre le run, télécharge l'artefact **Candidatures-apk** (un zip qui contient `app-debug.apk`).
4. Sur le téléphone : ouvre `app-debug.apk`, autorise l'installation depuis cette source, installe.

Pour une mise à jour, modifie `app/src/main/assets/www/index.html`, pousse, et réinstalle la nouvelle APK
par-dessus : les données sont conservées tant que tu gardes le même nom de paquet.

## Fonctions Android

- Partager une annonce depuis Chrome, LinkedIn ou Indeed → « Candidatures » : la fiche se pré-remplit.
- « Enregistrer » range les fichiers dans `Téléchargements/Candidatures`.
- ⤴ envoie un document à Gmail, LinkedIn, WhatsApp…
- Copie de l'offre : à la création d'une candidature avec un lien, l'app charge l'annonce en arrière-plan et en garde le texte (sinon « Coller le texte »).
- Lettres : « Rédiger avec Claude » (clé API dans Réglages) ou « Ouvrir dans Claude » qui copie une demande prête à coller dans un projet Claude dédié.
- Bouton retour : ferme le panneau ouvert avant de quitter.

## Compiler en local (optionnel)

Avec Android Studio : *Open* ce dossier, puis *Build → Build APK(s)*.
