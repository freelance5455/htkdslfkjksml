(function(){
  function clean(t){ return (t||"").replace(/ /g," ").replace(/[ \t]+\n/g,"\n").replace(/\n{3,}/g,"\n\n").replace(/[ \t]{2,}/g," ").trim(); }
  function htmlToText(h){
    var d=document.createElement("div");
    d.innerHTML=String(h||"").replace(/<br\s*\/?>/gi,"\n").replace(/<\/(p|div|li|h[1-6]|tr)>/gi,"\n").replace(/<li[^>]*>/gi,"• ");
    return clean(d.textContent);
  }
  function findJob(o){
    if(!o||typeof o!=="object") return null;
    if(Array.isArray(o)){ for(var i=0;i<o.length;i++){ var r=findJob(o[i]); if(r) return r; } return null; }
    var t=o["@type"]; if(t==="JobPosting"||(Array.isArray(t)&&t.indexOf("JobPosting")>=0)) return o;
    if(o["@graph"]) return findJob(o["@graph"]);
    return null;
  }
  var job=null, scripts=document.querySelectorAll('script[type="application/ld+json"]');
  for(var i=0;i<scripts.length&&!job;i++){ try{ job=findJob(JSON.parse(scripts[i].textContent)); }catch(e){} }
  var out={url:location.href};
  if(job){
    out.title=job.title||"";
    var org=job.hiringOrganization; out.company=(org&&(org.name||org))||"";
    if(typeof out.company!=="string") out.company="";
    var loc=job.jobLocation; if(Array.isArray(loc)) loc=loc[0];
    var a=loc&&loc.address; if(a) out.location=[a.addressLocality,a.addressRegion].filter(Boolean).join(", ");
    if(job.jobLocationType==="TELECOMMUTE") out.location=(out.location?out.location+" · ":"")+"Télétravail";
    out.contract=[].concat(job.employmentType||[]).join(", ");
    var sal=job.baseSalary, v=sal&&sal.value;
    if(v){ var mn=v.minValue||v.value, mx=v.maxValue; if(mn) out.salary=(mx&&mx!==mn?mn+"–"+mx:mn)+" "+(sal.currency||"")+(v.unitText?" / "+v.unitText.toLowerCase():""); }
    out.text=htmlToText(job.description);
  }
  if(!out.text||out.text.length<200){
    var root=document.querySelector("main,article,[role=main]")||document.body;
    out.text=clean(root.innerText);
    out.title=out.title||clean(document.title);
  }
  out.text=out.text.slice(0,60000);
  return JSON.stringify(out);
})()
