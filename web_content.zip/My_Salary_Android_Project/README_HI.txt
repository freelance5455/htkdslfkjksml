MY SALARY WALLET — ANDROID STUDIO PROJECT

Yeh Android app ka source project hai; yeh pehle se compiled/installable APK nahi hai.

FEATURES
- ₹12,000 monthly salary default
- Present / Absent / Weekly Off
- Optional tea break entry (skip kar sakte hain)
- Night allowance, overtime aur optional night meal entry
- CSV report Android Downloads folder mein save karne ke liye native bridge
- JSON backup Downloads folder mein save hota hai
- Restore Backup mein Android file picker se JSON select kar sakte hain
- Attendance/settings local app WebView storage mein rehte hain

APK BANANE KE LIYE
1. Computer par Android Studio install karein.
2. Android Studio > Open par jaakar My_Salary_Android_Project folder select karein.
3. Gradle sync complete hone dein (internet chahiye; Android SDK Platform 35 install hona chahiye).
4. Build > Build Bundle(s) / APK(s) > Build APK(s) choose karein.
5. Build complete hone par app/build/outputs/apk/debug/app-debug.apk file milegi.
6. APK ko apne phone par bhej kar install karein. Unknown-app install permission Android pooche toh sirf apne banaye/test kiye APK ke liye allow karein.

IMPORTANT
- Is environment mein Android SDK/Gradle build tool available nahi tha, isliye yahan compiled APK generate/test nahi ki gayi.
- Pehli baar use karne par sample attendance save karke CSV export aur JSON backup/restore test karein.
- App data phone ke app storage mein hai; app uninstall/clear data se data mit sakta hai. Regular JSON backup lein.
