#!/bin/bash

# Script ROOM WANGI MLBB
# Untuk Termux (No Root, No Guardian)

echo "==================================="
echo "     ROOM WANGI MLBB SCRIPT        "
echo "    BY DANN STOREE V               "
echo "==================================="
echo ""

# Warna
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Cek paket yang dibutuhkan
echo -e "${YELLOW}[✓] Mengecek dependencies...${NC}"

# Install paket yang diperlukan
pkg update -y && pkg upgrade -y
pkg install -y tsu python nodejs curl git

# Install npm package
npm install -g wscat

# Cek koneksi
echo -e "${BLUE}[✓] Cek koneksi internet...${NC}"
if ping -c 1 google.com > /dev/null 2>&1; then
    echo -e "${GREEN}[✓] Koneksi OK${NC}"
else
    echo -e "${RED}[✗] Tidak ada koneksi internet${NC}"
    exit 1
fi

# Input Server
echo ""
echo -e "${YELLOW}Masukkan Server IP (default: 127.0.0.1):${NC}"
read -p "IP: " server_ip
server_ip=${server_ip:-127.0.0.1}

echo -e "${YELLOW}Masukkan Port (default: 8080):${NC}"
read -p "Port: " server_port
server_port=${server_port-8080}

echo -e "${YELLOW}Masukkan Durasi Room (detik, default: 3600):${NC}"
read -p "Durasi: " duration
duration=${duration:-3600}

echo ""
echo -e "${GREEN}====================================${NC}"
echo -e "${GREEN}Memulai Room Wangi...${NC}"
echo -e "${GREEN}Server: $server_ip:$server_port${NC}"
echo -e "${GREEN}Durasi: $duration detik${NC}"
echo -e "${GREEN}====================================${NC}"

# Script Python untuk MLBB Room
cat > mlbb_room.py << 'EOF'
import socket
import time
import json
import threading
import sys

class MLBBRoom:
    def __init__(self, host='127.0.0.1', port=8080):
        self.host = host
        self.port = port
        self.room_id = None
        self.active = True
        
    def create_room(self):
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.connect((self.host, self.port))
            
            # Simulasi request create room
            room_data = {
                "action": "create_room",
                "mode": "custom",
                "max_players": 10,
                "duration": 3600
            }
            
            sock.send(json.dumps(room_data).encode())
            response = sock.recv(1024).decode()
            
            if response:
                data = json.loads(response)
                self.room_id = data.get('room_id', 'MLBB-ROOM-001')
                print(f"[✓] Room Created: {self.room_id}")
                return True
                
        except Exception as e:
            print(f"[✗] Error: {e}")
            return False
        finally:
            sock.close()
            
    def keep_alive(self, duration):
        print(f"[✓] Room active for {duration} seconds")
        time.sleep(duration)
        self.active = False
        print("[✓] Room expired")

if __name__ == "__main__":
    host = sys.argv[1] if len(sys.argv) > 1 else '127.0.0.1'
    port = int(sys.argv[2]) if len(sys.argv) > 2 else 8080
    dur = int(sys.argv[3]) if len(sys.argv) > 3 else 3600
    
    room = MLBBRoom(host, port)
    if room.create_room():
        room.keep_alive(dur)
EOF

# Jalankan script
python mlbb_room.py "$server_ip" "$server_port" "$duration"

echo ""
echo -e "${GREEN}====================================${NC}"
echo -e "${GREEN}Room Wangi Selesai${NC}"
echo -e "${GREEN}====================================${NC}"

