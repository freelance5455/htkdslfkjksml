/* MIDOK 1.5 : la liste commune ne reçoit que les noms des cotisants ayant payé. */
const MidokCommunity = (() => {
  let loading = false, data = null, last = 0, timer = null;
  const fmt = value => /^\d{4}-\d{2}-\d{2}$/.test(value || '') ? value.slice(8,10)+'/'+value.slice(5,7)+'/'+value.slice(0,4) : '';
  function frame() {
    const view = document.getElementById('view');
    view.innerHTML = '<h1>Reconstitution en cours</h1><p>Adhérents ayant intégralement réglé la reconstitution du mois affiché, après validation par la trésorerie.</p>' +
      '<button onclick="MidokCommunity.refresh(true)">Actualiser la liste</button><p id="community-status" role="status"></p><div id="community-list"></div>';
    draw(); refresh();
  }
  function draw() {
    const el = document.getElementById('community-list'); if (!el || !data) return;
    const label = new Intl.DateTimeFormat('fr-FR',{month:'long',year:'numeric',timeZone:'Africa/Abidjan'}).format(new Date(data.month+'-15T12:00:00Z'));
    el.innerHTML = '<div class="card"><h2>'+esc(label)+'</h2><p>Du '+fmt(data.starts_on)+' au '+fmt(data.ends_on)+'. Prochaine liste le '+fmt(data.next_refresh)+'.</p><b>'+data.count+' adhérent(s) ayant payé</b></div>' +
      '<div class="card">'+(data.members.length ? '<ol>'+data.members.map(m=>'<li style="padding:12px 4px;border-bottom:1px solid #dce8df">'+esc(m.name)+'</li>').join('')+'</ol>' : '<p>Aucun paiement complet validé pour cette reconstitution.</p>')+'</div><p>Les versements partiels et les demandes en attente ne figurent pas dans cette liste. Les paiements des autres mois restent dans leur historique.</p>';
  }
  async function refresh(force=false) {
    if (!Cloud.auth || page !== 'currentReconstitution' || loading) return;
    if (!force && Date.now()-last < 10000) return;
    loading = true;
    const status = document.getElementById('community-status'); if (status) status.textContent='Actualisation…';
    try {
      const result = await Cloud.rpc('midok_current_reconstitution',{});
      if (!/^\d{4}-(0[1-9]|1[0-2])$/.test(result?.month || '') || !Array.isArray(result.members) || result.members.some(m=>typeof m?.name!=='string')) throw Error('Liste illisible.');
      data = result; last = Date.now();
      if (page === 'currentReconstitution') {
        draw(); const live=document.getElementById('community-status');
        if(live)live.textContent='Liste à jour · '+new Date(result.checked_at).toLocaleTimeString('fr-FR',{timeZone:'Africa/Abidjan'});
      }
    } catch(e) {
      data=null;last=0;
      if(page === 'currentReconstitution') {
        const live=document.getElementById('community-status'),box=document.getElementById('community-list');if(box)box.textContent='';
        if(live)live.textContent='Liste indisponible. '+(/midok_current_reconstitution|schema cache/i.test(e.message)?'La mise à jour SQL 04 doit être installée dans Supabase.':e.message);
      }
    } finally { loading=false; }
  }
  function start() { clearInterval(timer); data=null;last=0;timer=setInterval(()=>refresh(),15000); }
  return {frame,refresh,start};
})();
const MidokFamily = {
  html(m) {
    if (!m) return '<p>Fiche d’adhésion indisponible.</p>';
    const fields=[['Conjoint(e)','spouse',''],['Père','father','fatherPhone'],['Mère','mother','motherPhone']];
    return '<p>Ayants droit renseignés dans la fiche d’adhésion validée.</p>'+fields.map(([label,key,phone])=>
      '<article class="card"><h2>'+label+'</h2><p>'+esc(String(m[key]||'').trim()||'Non renseigné dans la fiche')+'</p>'+
      (phone&&m[phone]?'<p>Contact : '+esc(m[phone])+'</p>':'')+'</article>').join('');
  }
};
