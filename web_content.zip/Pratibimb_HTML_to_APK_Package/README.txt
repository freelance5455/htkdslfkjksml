PRATIBIMB CRAFTS — HTML-TO-APK UPLOAD PACKAGE

This package is arranged to match the local URL shown in the error screenshot:
https://appassets.androidplatform.net/web/index.html

PACKAGE CONTENTS
- web/index.html  <- preferred entry page if the APK maker preserves the web/ folder
- index.html      <- root-level copy for makers that require index.html at the ZIP root

UPLOAD INSTRUCTIONS
1. If the maker accepts a ZIP and preserves folders, upload this ZIP and set the start page to web/index.html (if asked).
2. If the maker asks for a folder or website source directory, upload/select the extracted folder and ensure web/index.html is included.
3. If the maker accepts only one HTML file, upload web/index.html (or index.html if it asks for a root index page).
4. If the maker has a setting called Start URL, Start Page, Local HTML Path, or Web Directory, use web/index.html to match the error URL.
5. Rebuild the APK after changing the source. Reinstall/update that new APK; merely reopening the old APK will not change its bundled files.

IMPORTANT TECHNICAL NOTE
The error URL strongly suggests the maker is trying to load a bundled page at /web/index.html, but this ZIP cannot change native WebView code or a builder's private packaging rules. If the maker ignores folders, hard-codes a different path, or expects a different project structure, its exact URL or upload instructions are needed to tailor the package further.

APP FEATURES
- Select multiple text-based shipping label/invoice PDFs
- Detect COD vs prepaid and extract available order fields
- Preview extracted order data
- Export an XLSX workbook with Orders and Raw Extracted Data sheets
- PDF text is processed locally in the browser

DEPENDENCIES / LIMITATIONS
- PDF.js and SheetJS are loaded from public CDNs, so internet access is needed for those libraries.
- Scanned/image-only PDFs are not supported in this version.
- Extraction rules are tailored to the two sample PDF layouts and results should be checked before fulfilment/accounting.
- This is a source package, not a compiled APK. The APK must be rebuilt by the chosen maker.
