# WONDER SHIFT V13 — paquet réconcilié

Cette version est basée sur l’état Supabase déjà construit dans le projet et sur le code V12. Elle ne demande pas de repartir de zéro.

## À utiliser dans Supabase
**`supabase-reconciliation-v13.sql` uniquement.**

Ne pas exécuter les anciennes migrations ni un ancien SQL final en plus.

## Corrections principales V13
- Synchronisation réellement alignée avec les stores locaux existants.
- Services, tâches et stock créés/modifiés/désactivés sont synchronisés.
- Mouvements de stock synchronisés.
- Alertes de stock synchronisées.
- Suppressions de catalogue transformées en désactivation pour éviter les divergences entre appareils.
- Profil utilisateur normalisé même si un ancien champ de nom est vide.
- Invitations utilisateurs : profil complet et nettoyage si la création échoue.
- RLS réconciliées avec les trois rôles : Agent, Superviseur, Développeur.
- Caisse et mouvements espèces compatibles avec les opérations des Agents.
- Audit et demandes de suppression conservés.
- Aucun secret `service_role` dans l’application.

## Ce que l'utilisateur devra faire
1. Exécuter `supabase-reconciliation-v13.sql` dans le SQL Editor du projet existant.
2. Déployer `manage-user`.
3. Déployer `send-report`.
4. Configurer les secrets Gmail uniquement si l'envoi automatique par Gmail doit être utilisé.

Le reste des corrections de code est déjà dans le paquet.

## Limite de test
La connexion directe à l’API Supabase n’est pas disponible depuis l’environnement de vérification. Le paquet a donc été contrôlé statiquement et comparé avec l’historique Supabase déjà établi dans le projet ; le test live final doit être fait après le déploiement.
