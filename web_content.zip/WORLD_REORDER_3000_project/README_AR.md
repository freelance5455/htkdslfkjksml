# WORLD REORDER 3000 — تعليمات التشغيل

## التشغيل على المتصفح
- افتح ملف `index.html` مباشرة بالنقر المزدوج (يعمل بلا خادم وبلا إنترنت).
- للتثبيت كتطبيق (PWA) وللعمل دون إنترنت: شغّل خادماً محلياً داخل المجلد: `python3 -m http.server 8000` ثم افتح `http://localhost:8000`، واختر «تثبيت التطبيق» من المتصفح.

## الكرة الأرضية ثلاثية الأبعاد (Three.js)
- زر 🌐 يفتح كرة أرضية. إن وُجد ملف `three.min.js` بجانب `index.html` (أو توفر إنترنت) تُستخدم Three.js، وإلا تعمل كرة احتياطية مدمجة دون أي اعتماد خارجي.
- لتحميل Three.js محلياً: https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js وضعه بجانب `index.html`.

## التحويل إلى تطبيق Android (Capacitor)
```
npm init -y
npm i @capacitor/core @capacitor/cli @capacitor/android
npx cap init WR3000 com.example.wr3000 --web-dir=www
mkdir www && cp index.html manifest.json icon.svg sw.js www/
npx cap add android
npx cap sync
npx cap open android      # ثم Build > Build APK في Android Studio
```
بديل بلا Android Studio: ارفع المجلد على استضافة HTTPS ثم استخدم PWABuilder.com لإنشاء APK.

## الاختصارات
Space إيقاف/استئناف · 1–4 السرعة · V تحديد · B رسم · E محو · F تعبئة · T تضاريس · H تحريك · +/- تكبير · الأسهم تحريك · Ctrl+Z/Y تراجع/إعادة · Ctrl+S حفظ · Esc إيقاف.

## الحفظ
يُحفظ كل شيء في IndexedDB داخل المتصفح (حفظ تلقائي كل 45 ثانية وعند إيقاف الزمن أو مغادرة الصفحة).
