STAR PATH - HTML TO ANDROID APK PROJECT

1. Install Android Studio on your laptop.
2. Extract this ZIP.
3. Open the extracted "StarPath" folder in Android Studio.
4. Let Gradle sync/download dependencies.
5. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Android Studio will show the generated APK location.

The game HTML is at:
app/src/main/assets/index.html

This project does NOT include AdMob yet. Ads can be added later after the basic APK works.
