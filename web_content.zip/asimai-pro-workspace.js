/* Additive AsimAI Pro interactions: IDE quick-open/command palette and extra JARVIS shortcuts. */
(() => {
  'use strict';
  const esc = value => (window.Utils && Utils.escapeHtml) ? Utils.escapeHtml(String(value)) : String(value).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

  const IDEPro = {
    mode: 'commands',
    selected: 0,
    overlay: null,
    input: null,
    list: null,
    commands: [
      { name: 'New File', hint: 'Create a file', icon: 'fa-file-circle-plus', run: () => IDE.newFile() },
      { name: 'New Folder', hint: 'Create a folder', icon: 'fa-folder-plus', run: () => IDE.newFolder() },
      { name: 'Save All', hint: 'Save workspace files', icon: 'fa-floppy-disk', run: () => IDE.saveAll() },
      { name: 'Run / Preview', hint: 'Ctrl / Cmd + Enter', icon: 'fa-play', run: () => IDE.run() },
      { name: 'Search Across Files', hint: 'Open workspace search', icon: 'fa-magnifying-glass', run: () => { IDE.setView('search'); IDE.q('[data-s="q"]')?.focus(); } },
      { name: 'Import Files or Project', hint: 'Files, folder or ZIP', icon: 'fa-file-import', run: () => IDE.q('[data-in="files"]')?.click() },
      { name: 'Export Project ZIP', hint: 'Download project', icon: 'fa-file-zipper', run: () => IDE.exportZip() },
      { name: 'Create Starter Project', hint: 'HTML, CSS and JavaScript', icon: 'fa-wand-magic-sparkles', run: () => IDE.createStarter() },
      { name: 'Toggle Live Preview', hint: 'Enable / disable auto refresh', icon: 'fa-bolt', run: () => IDE.setPref('live', !IDE.prefs.live) },
      { name: 'Open Quick File', hint: 'Browse project files', icon: 'fa-folder-open', run: () => IDEPro.open('files') }
    ],
    ensure() {
      if (!window.IDE?.root || this.overlay?.isConnected) return;
      this.overlay = document.createElement('div');
      this.overlay.className = 'asim-studio-overlay';
      this.overlay.hidden = true;
      this.overlay.innerHTML = `<section class="asim-studio-palette" role="dialog" aria-modal="true" aria-label="Code workspace command palette">
        <div class="asim-studio-palette-head"><i class="fa-solid fa-wand-magic-sparkles" aria-hidden="true"></i><input type="text" autocomplete="off" spellcheck="false" aria-label="Search files and commands" placeholder="Search files and commands…"></div>
        <div class="asim-studio-palette-list" role="listbox" aria-label="Results"></div>
        <div class="asim-studio-palette-foot"><span><kbd>↑</kbd> <kbd>↓</kbd> navigate · <kbd>Enter</kbd> open</span><span><kbd>Esc</kbd> close</span></div>
      </section>`;
      IDE.root.appendChild(this.overlay);
      this.input = this.overlay.querySelector('input');
      this.list = this.overlay.querySelector('.asim-studio-palette-list');
      this.input.addEventListener('input', () => { this.selected = 0; this.render(); });
      this.overlay.addEventListener('click', event => {
        if (event.target === this.overlay) this.close();
        const row = event.target.closest('[data-result-index]');
        if (row) this.activate(Number(row.dataset.resultIndex));
      });
      this.overlay.addEventListener('keydown', event => this.onPaletteKey(event));
      const title = IDE.root.querySelector('.ide-title');
      if (title && !title.querySelector('.asim-studio-badge')) {
        const badge = document.createElement('span');
        badge.className = 'asim-studio-badge';
        badge.textContent = 'STUDIO PRO';
        title.appendChild(badge);
      }
    },
    fuzzy(haystack, query) {
      const h = String(haystack).toLowerCase();
      const q = String(query).toLowerCase().trim();
      if (!q) return true;
      if (h.includes(q)) return true;
      let i = 0;
      for (const char of q) { i = h.indexOf(char, i); if (i < 0) return false; i++; }
      return true;
    },
    results() {
      const query = this.input?.value || '';
      if (this.mode === 'files') {
        return Object.keys(IDE.files || {}).filter(path => !IDE.files[path]?.binary && this.fuzzy(path, query)).sort().slice(0, 100).map(path => ({
          name: path, hint: IDE.isDirty(path) ? 'Unsaved changes' : (IDE.files[path]?.language || 'Project file'), icon: IDE.iconFor(path), run: () => IDE.openFile(path)
        }));
      }
      return this.commands.filter(item => this.fuzzy(`${item.name} ${item.hint}`, query));
    },
    render() {
      if (!this.list) return;
      const items = this.results();
      this.selected = Math.max(0, Math.min(this.selected, Math.max(0, items.length - 1)));
      this.list.innerHTML = items.length ? items.map((item, index) => `<button class="asim-studio-palette-row" role="option" aria-selected="${index === this.selected}" data-result-index="${index}" type="button"><i class="fa-solid ${esc(item.icon || 'fa-code')}" aria-hidden="true"></i><span>${esc(item.name)}</span><small>${esc(item.hint || '')}</small></button>`).join('') : '<div class="asim-studio-palette-empty">No matching files or commands</div>';
    },
    open(mode = 'commands') {
      if (!window.IDE?.opened) return;
      this.ensure();
      if (!this.overlay) return;
      this.mode = mode;
      this.selected = 0;
      this.overlay.hidden = false;
      this.input.placeholder = mode === 'files' ? 'Type a file name to open…' : 'Type a command or search for a file…';
      this.input.value = '';
      this.render();
      requestAnimationFrame(() => this.input?.focus());
    },
    close() {
      if (!this.overlay) return;
      this.overlay.hidden = true;
      IDE.cm?.focus();
    },
    activate(index) {
      const item = this.results()[index];
      if (!item) return;
      this.close();
      try { item.run(); } catch (error) { console.error('[AsimAI Studio]', error); window.ChatRenderer?.showToast(error.message || 'Workspace action failed'); }
    },
    onPaletteKey(event) {
      const items = this.results();
      if (event.key === 'Escape') { event.preventDefault(); this.close(); }
      else if (event.key === 'ArrowDown') { event.preventDefault(); this.selected = (this.selected + 1) % Math.max(1, items.length); this.render(); this.list.querySelector(`[data-result-index="${this.selected}"]`)?.scrollIntoView({block:'nearest'}); }
      else if (event.key === 'ArrowUp') { event.preventDefault(); this.selected = (this.selected - 1 + Math.max(1, items.length)) % Math.max(1, items.length); this.render(); this.list.querySelector(`[data-result-index="${this.selected}"]`)?.scrollIntoView({block:'nearest'}); }
      else if (event.key === 'Enter') { event.preventDefault(); this.activate(this.selected); }
    }
  };

  document.addEventListener('keydown', event => {
    if (!window.IDE?.opened || !IDE.root) return;
    const mod = event.ctrlKey || event.metaKey;
    if (!mod) return;
    const key = event.key.toLowerCase();
    if (event.shiftKey && key === 'p') { event.preventDefault(); IDEPro.open('commands'); }
    else if (!event.shiftKey && key === 'p') { event.preventDefault(); IDEPro.open('files'); }
    else if (event.shiftKey && key === 's') { event.preventDefault(); IDE.saveAll(); }
  }, true);

  const addJarvisTools = () => {
    const app = window.appInstance;
    const panel = document.querySelector('#jarvisModal .jarvis-panel');
    if (panel && !panel.querySelector('.jarvis-command-deck')) {
      const deck = document.createElement('div');
      deck.className = 'jarvis-command-deck';
      deck.setAttribute('aria-label', 'JARVIS quick actions');
      deck.innerHTML = `<button type="button" data-jarvis-command="open code workspace"><i class="fa-solid fa-code"></i><span>Code workspace</span></button>
        <button type="button" data-jarvis-command="open history"><i class="fa-solid fa-clock-rotate-left"></i><span>Chat history</span></button>
        <button type="button" data-jarvis-command="search for latest AI news"><i class="fa-solid fa-magnifying-glass"></i><span>Web search</span></button>
        <button type="button" data-jarvis-command="help"><i class="fa-solid fa-circle-question"></i><span>Voice commands</span></button>`;
      panel.querySelector('.jarvis-hint')?.after(deck);
      deck.addEventListener('click', event => {
        const button = event.target.closest('[data-jarvis-command]');
        if (button && window.appInstance) window.appInstance.sendJarvisMessage(button.dataset.jarvisCommand);
      });
    }
    if (!app || !app.handleJarvisCommand || app._asimProVoicePatched) return false;
    const original = app.handleJarvisCommand;
    app.handleJarvisCommand = function(rawText) {
      const text = String(rawText || '').trim().toLowerCase().replace(/[.!?]+$/g, '');
      const reply = message => {
        this.appendJarvisMessage('assistant', message);
        if (this.settings?.jarvisVoice !== false) this.speakJarvis(message);
      };
      if (/^(help|commands|what can you do|show commands)$/.test(text)) {
        reply("Try: open code workspace, open history, start a new chat, search for something, open camera, turn flashlight on or off, tell me the time or date, read my last reply, or stop speaking. Camera and flashlight depend on your browser and device permissions.");
        return true;
      }
      if (/^(open|launch|show) (the )?(code workspace|workspace|ide)$/.test(text)) {
        this.jarvisModal?.classList.add('hidden');
        window.IDE?.open();
        reply('Opening the code workspace.');
        return true;
      }
      if (/^(open|show) (the )?(chat )?history$/.test(text)) {
        this.jarvisModal?.classList.add('hidden');
        document.getElementById('openHistorySidebarBtn')?.click();
        reply('Opening your chat history.');
        return true;
      }
      if (/^(start|create|new) (a )?(new )?chat$/.test(text) || /^(new chat)$/.test(text)) {
        this.jarvisModal?.classList.add('hidden');
        (document.getElementById('mainNewChatBtn') || document.getElementById('newChatBtn'))?.click();
        reply('Starting a new chat.');
        return true;
      }
      const webSearch = text.match(/^(?:search the web for|search web for|web search for)\s+(.+)$/);
      if (webSearch) return original.call(this, `search for ${webSearch[1]}`);
      if (/^(stop speaking|stop voice|be quiet)$/.test(text)) { this.stopJarvisSpeech(); return true; }
      return original.call(this, rawText);
    };
    app._asimProVoicePatched = true;
    return true;
  };

  const observeWorkspace = () => {
    const host = document.getElementById('idePage');
    if (host) new MutationObserver(() => IDEPro.ensure()).observe(host, { childList: true, subtree: true });
    IDEPro.ensure();
  };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', observeWorkspace, { once: true }); else observeWorkspace();
  let attempts = 0;
  const jarvisTimer = setInterval(() => {
    attempts++;
    addJarvisTools();
    if (window.appInstance?._asimProVoicePatched || attempts > 100) clearInterval(jarvisTimer);
  }, 100);
})();
