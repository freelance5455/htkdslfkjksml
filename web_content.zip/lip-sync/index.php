<?php
declare(strict_types=1);
require_once dirname(__DIR__) . '/workspace-entry.php';
anonymoux_workspace_entry('lip-sync.php', 'lip-sync.php', 'lip-sync/');
