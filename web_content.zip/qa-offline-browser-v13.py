"""Actual Chromium service-worker installation and offline reopening over local HTTP.
Does not verify an Android physical-device install or Netlify deployment."""
from pathlib import Path
from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
from threading import Thread
from playwright.sync_api import sync_playwright
import json
R=Path(__file__).resolve().parent
class Handler(SimpleHTTPRequestHandler):
 def __init__(self,*a,**k):super().__init__(*a,directory=str(R),**k)
 def log_message(self,*a):pass
server=ThreadingHTTPServer(('127.0.0.1',0),Handler);port=server.server_address[1]
Thread(target=server.serve_forever,daemon=True).start()
try:
 with sync_playwright() as p:
  b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
  ctx=b.new_context(viewport={'width':390,'height':844},service_workers='allow')
  page=ctx.new_page()
  errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  page.goto(f'http://127.0.0.1:{port}/index.html',wait_until='domcontentloaded',timeout=20000)
  page.wait_for_function('window.LOONIE_CURRICULUM_V13',timeout=20000)
  page.wait_for_function('navigator.serviceWorker&&navigator.serviceWorker.controller',timeout=20000)
  count=page.evaluate('caches.keys().then(keys=>keys.length)');assert count>0,count
  assets=page.evaluate('''async()=>{const c=await caches.open('loonie-20261116-v13');return (await c.keys()).map(x=>new URL(x.url).pathname.split('/').at(-1));}''')
  assert len(assets)>=20,assets
  for x in ['academy-v13.js','curriculum-v13.js','academy-v13.css','life-v12.js','index.html']:
   assert x in assets,(x,assets)
  page.evaluate('''()=>{state.onboarded=true;state.academyV13={projects:{carp:{note:'Offline stored project',checks:[0]}}};save();}''')
  ctx.set_offline(True)
  page.reload(wait_until='domcontentloaded',timeout=20000)
  page.wait_for_function('window.LOONIE_CURRICULUM_V13',timeout=12000)
  assert page.evaluate('LESSONS.length')==807
  assert page.evaluate('state.academyV13.projects.carp.note')=='Offline stored project'
  page.evaluate('''()=>{location.hash='#s-carp';route()}''')
  assert page.locator('.a13-stage').count()==3
  page.evaluate('''()=>{location.hash='#l-385';route()}''')
  assert page.locator('.reader').count()==1
  assert not errors,errors
  print(f'PASS: real localhost PWA installed, {len(assets)} core resources cached, airplane-mode-equivalent reload, legacy and new lesson pages, v13 saved project retained')
  ctx.close();b.close()
finally:server.shutdown();server.server_close()
