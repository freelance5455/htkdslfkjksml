# Contábil Quest para Android

Aplicativo Android simples que abre localmente a versão com aulas do Contábil Quest em um WebView. O conteúdo fica dentro do APK; não exige conta nem conexão à internet para abrir o jogo. O progresso é guardado no armazenamento local do WebView.

## Gerar o APK automaticamente
1. Crie um repositório no GitHub e envie todo o conteúdo desta pasta para a branch `main`.
2. Abra a aba **Actions** do repositório.
3. Selecione **Build Contábil Quest APK** e clique em **Run workflow** (ou aguarde o build após o push).
4. Quando terminar, abra a execução concluída e baixe o artefato **Contabil-Quest-APK**. Dentro dele estará `app-debug.apk`.
5. Transfira o APK para o Android e autorize a instalação para o app usado para abrir o arquivo, se o Android solicitar.

## Compilação local
Requer JDK 17, Android SDK com plataforma 35 e Gradle 8.9. Execute `gradle assembleDebug` na raiz do projeto.

O APK de debug é destinado a testes/instalação manual, não é uma versão publicada na Play Store.
