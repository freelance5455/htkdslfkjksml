Open City 3D - موبایل ډیمو
دا اصلي GTA San Andreas نه دی؛ دا یو خپلواک 3D-style game prototype دی.
index.html په Chrome کې خلاص کړئ. انټرنېټ ته اړتیا نه لري.
کنټرول: ▲ ▼ ◀ ▶. د سودا او ماموریت تڼۍ هم شته.
