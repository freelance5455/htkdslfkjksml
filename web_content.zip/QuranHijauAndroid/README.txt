AL-QUR'AN HIJAU — ANDROID WEBVIEW PROJECT

Status: prototype awal (v0.1.0), belum berupa APK yang ditandatangani.

Cara membuka:
1. Ekstrak folder QuranHijauAndroid.
2. Buka folder tersebut melalui Android Studio (Open).
3. Tunggu Gradle Sync selesai.
4. Sambungkan HP Android atau pilih emulator.
5. Pilih Run untuk uji coba.
6. Untuk membuat APK: Build > Build Bundle(s) / APK(s) > Build APK(s).

Catatan fitur:
- Teks Arab dan terjemahan diambil dari AlQuran Cloud API; unduh melalui menu Data untuk menyimpan data surah pada perangkat.
- Audio murottal memerlukan internet.
- Jadwal salat dan perhitungan arah kiblat memerlukan lokasi; jadwal salat memerlukan internet.
- Bookmark, riwayat terakhir dibaca, dan tasbih disimpan di penyimpanan browser/WebView.
- Tafsir masih berupa penanda fitur pada prototipe dan belum terhubung ke basis data tafsir.
- Kompas saat ini menampilkan azimut kiblat dari utara, belum mengikuti rotasi sensor magnetometer perangkat.

Untuk build APK dibutuhkan Android Studio, Android SDK 35, dan koneksi internet saat Gradle mengambil dependensi.
