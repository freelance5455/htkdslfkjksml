# Fish Audio Agent Studio repair notes — 2.5.6

## Confirmed root cause
The previous adapter allowed only `/v1/agent/agents` or `/v1/agent/agents/{single-segment}` and equivalent sessions paths. Real application calls include nested paths (`/config`, `/publish`, `/end`) and knowledge-source endpoints. The local validator rejected these requests before cURL was called, producing a local rejection that looked like Fish Audio rejecting the request.

## Current documented contract used
- Create agent: `POST /v1/agent/agents`
- Update draft configuration: `PATCH /v1/agent/agents/{agent_id}/config`
- Publish: `POST /v1/agent/agents/{agent_id}/publish`
- Create web session: `POST /v1/agent/sessions`
- Read session details: `GET /v1/agent/sessions/{session_id}`
- End session: `POST /v1/agent/sessions/{session_id}/end`
- Browser connection: `@fishaudio/agent-client` with the backend session response passed as `sessionToken`

Official docs reviewed 2026-11-15:
- https://docs.fish.audio/agents/quickstart
- https://docs.fish.audio/agents/deploy/web-sdk
- https://docs.fish.audio/api-reference/endpoint/agent/create-agent-session
- https://docs.fish.audio/api-reference/endpoint/agent/get-agent-session
- https://docs.fish.audio/api-reference/endpoint/agent/end-agent-session
- https://docs.fish.audio/agents/pricing

## Billing
Fish Audio currently documents web-agent conversation at USD 0.07/minute, counted by second, with extra token billing for non-basic LLM models. The application now uses provider-reported session duration and provider-reported `billable_cost_usd` for token-billed LLM usage. The conversation rate and customer credit conversion are configurable by an administrator. The app does not estimate duration from browser timers or fabricate LLM usage.

The ANON credits-per-USD value must be configured to represent the administrator's current USD-to-NGN conversion and chosen markup policy. For the agreed 100% markup and ₦10 per credit, configure `CEILING(current USD-to-NGN rate × 2 ÷ 10)` credits per USD. Update this setting when FX changes. Keep it at zero to record provider usage without charging users until the commercial conversion is approved.

## Live verification still required
A real Fish Audio account/API key and public HTTPS deployment are required to validate account access, voice availability, microphone permissions, LiveKit transport, successful real-time audio, and final usage settlement. These cannot be represented as passed by static tests.
