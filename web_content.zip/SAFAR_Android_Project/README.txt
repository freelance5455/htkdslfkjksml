SAFAR 3D Android Studio project

This is an Android WebView wrapper around the SAFAR 3D HTML prototype. It is a source project, not a compiled APK.

Build an APK:
1. Install Android Studio on a Windows/Mac/Linux computer.
2. Extract this ZIP and open the SAFAR_Android_Project folder in Android Studio.
3. Let Gradle sync and install Android SDK platform 35 if prompted.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio will show the output path, usually app/build/outputs/apk/debug/app-debug.apk.
6. Transfer that APK to your Android phone and install it. Android may ask you to allow installs from that source.

Important:
- The game imports Three.js from jsDelivr, so gameplay requires an internet connection.
- This is a prototype wrapper, not a full GTA-scale game.
- WebView file-origin settings are enabled so the HTML module can import the CDN module. Only use this project with trusted game HTML.
- This project has not been compiled or tested on a device in this environment.
