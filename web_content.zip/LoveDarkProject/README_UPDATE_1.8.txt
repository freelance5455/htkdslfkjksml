LoveDark Update 1.8

- Secret message code changed to 200781.
- The image cards now open their corresponding game sections.
- Added five additional visual cards by reusing embedded artwork with different crops; no new image generation.
- Added more random story events and increased event frequency slightly.
- Existing save keys and Android project identifiers are unchanged.

Validation: JavaScript syntax and ZIP integrity checked. Not built as an APK or device-tested.
