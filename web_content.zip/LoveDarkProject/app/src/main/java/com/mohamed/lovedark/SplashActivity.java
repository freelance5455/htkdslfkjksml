package com.mohamed.lovedark;

// Splash Activity placeholder