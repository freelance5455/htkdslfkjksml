LoveDark v1.6 update

- Added visible in-game clock that advances with game time and day ticks.
- Rebalanced energy/hunger consumption and improved sleep recovery.
- Added six additional visual cards.
- Proposal now includes a meeting with Arwa's father and exactly four response choices; outcomes depend on job, skills, reputation, relationship trust, and honesty.
- Preserved Android package/application identifiers and save keys for update compatibility.
- Validation: JavaScript syntax and ZIP integrity checked. Not device-tested; build APK in Android Studio/your existing Android workflow.
