LoveDark Android Project — Update 1.5

Changes:
- Energy drains much more gently during normal actions and on the real-time calendar.
- Game calendar advances by one day every 2 real seconds while the game is visible.
- Removed the displayed in-game clock; day count remains visible.
- Monthly salary, rent, child expenses, business proceeds and car maintenance are settled on payday, rather than draining the wallet every two seconds.
- Difficulty tuning now meaningfully changes income, monthly costs and crime risk.
- Added cinematic image cards for the city, work, cars, family and fictional crime storyline.
- Kept the localStorage save key layl_life_save_v4 and Android project identifiers unchanged.

Testing: JavaScript syntax and ZIP integrity checked. This is not a built APK and has not been tested on a physical Android device.
