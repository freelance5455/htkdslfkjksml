LoveDark v2.3
- Unified calendar labels across the home screen, phone and mission area.
- Replaced the repeating interval with a self-rescheduling timer and foreground/page-resume hooks.
- Added lightweight button/card/modal/bar animations; respects reduced-motion preference.
- Tuned as a maintenance release: no new content sections added.
- App ID and save keys remain unchanged.
- Must rebuild/reinstall Android app to ensure updated assets are loaded.
