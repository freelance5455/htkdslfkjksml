LoveDark Project - Update 1.4

This update builds on v1.3 while preserving the Android project structure, application ID, and existing localStorage keys (layl_life_save_v4 / layl_life_save_v3 migration).

Changes:
- Added difficulty modes: Easy, Balanced, and Hard, with explanations and effects on energy, hunger, costs, income, and fictional crime risk.
- Added an interactive Arabic tutorial available from the phone and settings.
- Added story chapter log and new branching story events with consequences for skills, reputation, money, family mood, heat, and gang loyalty.
- Added a car dealership with multiple purchasable car models, daily maintenance costs, job income bonuses, one-car garage limit, and resale.
- Expanded fictional crime-world choices with lay-low, contact/mediator, and lawyer options.
- Added car/story/tutorial apps to the in-game phone.
- Kept save key and Android package/build files unchanged.

Validation: JavaScript syntax checked with Node.js and archive integrity checked. This package was not built into an APK and was not fully play-tested on a physical Android device.
