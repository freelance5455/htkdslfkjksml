LoveDark v2.0
- Secret panel always asks for code 200781; prior saved unlock flags no longer bypass the prompt. Enter submits the code.
- Calendar uses one direct 2-second interval; day labels refresh after each tick. No visible clock. Guarded fallback advances the day if a story event throws an error.
- Normalized loaded day values.
Checks: JS syntax, archive integrity, and headless-browser smoke test attempted. Not a guarantee of zero bugs on all Android devices.
