LoveDark v2.1 — Calendar reliability patch

- Removed the visibilityState gate that could stop calendar progression in Android WebView.
- Calendar advances by elapsed time, with a one-second pulse and one in-game day per two seconds.
- Calendar labels are synchronized independently before and after UI rendering, including the phone and daily missions.
- Day event errors are isolated so one event/UI exception does not permanently stop the calendar.
- Save key and Android application identifiers remain unchanged.

Validation: JavaScript syntax check and ZIP integrity check completed. Full Android-device testing has not been performed.
