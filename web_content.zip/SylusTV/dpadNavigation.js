export function initializeDPadNavigation() {
    const focusableQuery = 'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])';
    const focusableElements = document.querySelectorAll(focusableQuery);

    if (focusableElements.length > 0) {
        focusableElements[0].focus();
        focusableElements[0].classList.add("remote-focused");
    }

    window.addEventListener("keydown", (event) => {
        const items = Array.from(document.querySelectorAll(focusableQuery));
        if (items.length === 0) return;
        
        let currentIndex = items.indexOf(document.activeElement);
        if (currentIndex === -1) currentIndex = 0;

        if (event.key === "ArrowDown" || event.key === "ArrowRight") {
            event.preventDefault();
            currentIndex = (currentIndex + 1) % items.length;
        } else if (event.key === "ArrowUp" || event.key === "ArrowLeft") {
            event.preventDefault();
            currentIndex = (currentIndex - 1 + items.length) % items.length;
        } else {
            return;
        }

        items.forEach(el => el.classList.remove("remote-focused"));
        items[currentIndex].focus();
        items[currentIndex].classList.add("remote-focused");
    });
}