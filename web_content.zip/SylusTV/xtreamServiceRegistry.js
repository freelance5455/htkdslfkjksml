class XtreamServiceConfig {
    constructor(name, confidentialUrl) {
        this.name = name;
        this.confidentialUrl = confidentialUrl;
    }

    resolveServerUrl() {
        return this.confidentialUrl;
    }
}

export const XtreamServiceRegistry = {
    availableServices: [
        new XtreamServiceConfig("Rolex", "http://ccfc.live"),
        new XtreamServiceConfig("King X", "http://rabbitlovers.xyz"),
        new XtreamServiceConfig("Godzilla", "http://bitsnpieces-a.xyz")
    ],

    getServiceByName(serviceName) {
        return this.availableServices.find(s => s.name === serviceName) || this.availableServices[0];
    }
};