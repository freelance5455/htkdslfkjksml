export const AppThemeStyles = {
    SKY_GLASS: { name: "Sky Glass", primaryColor: "#0F172A", accentColor: "#00E5FF" },
    VIRGIN: { name: "Virgin", primaryColor: "#CC0000", accentColor: "#FFFFFF" },
    EE: { name: "EE", primaryColor: "#005EB8", accentColor: "#00FFCC" },

    fromName(themeName) {
        const key = Object.keys(this).find(k => this[k].name === themeName);
        return key ? this[key] : this.SKY_GLASS;
    },

    applyTheme(themeObj, rootElement = document.documentElement) {
        rootElement.style.setProperty("--app-primary", themeObj.primaryColor);
        rootElement.style.setProperty("--app-accent", themeObj.accentColor);
    }
};