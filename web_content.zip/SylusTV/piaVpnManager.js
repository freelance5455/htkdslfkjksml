export const PIAVpnManager = {
    prepareVpnConnection() {
        return { action: "prepare_vpn", allowed: true };
    },

    connectToPIAServer(serverRegion, username, password) {
        const vpnPayload = {
            provider: "PIA",
            region: serverRegion,
            auth: { user: username, pass: password },
            status: "CONNECTING"
        };
        localStorage.setItem("sylus_vpn_session", JSON.stringify(vpnPayload));
        return vpnPayload;
    }
};