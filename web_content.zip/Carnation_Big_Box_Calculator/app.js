(() => {
  const quantityInput = document.getElementById('quantity');
  const calculateButton = document.getElementById('calculate');
  const resetButton = document.getElementById('reset');
  const errorBox = document.getElementById('error');
  const results = document.getElementById('results');
  const layerList = document.getElementById('layer-list');
  const noteBox = document.getElementById('note');

  // Packing guidance: keep sides around 7–9 where possible; 10 is an occasional
  // practical exception. Every generated layer adds up exactly to the input.
  function chooseLayerCount(n) {
    if (n <= 20) return 1;
    if (n <= 27) return 1; // small quantities may require a higher-than-usual layer
    if (n <= 44) return 2;
    if (n <= 62) return 3;
    if (n <= 72) return 4;
    if (n <= 100) return 5;
    if (n <= 120) return 6;
    if (n <= 138) return 7;
    return 8;
  }

  function makeArrangement(n) {
    const count = chooseLayerCount(n);
    const totals = Array(count).fill(Math.floor(n / count));
    let remainder = n % count;
    // Spread remainder across layers, so the last layer is not arbitrarily tiny.
    for (let i = 0; i < count && remainder > 0; i++, remainder--) totals[i]++;

    const layers = totals.map((total, index) => {
      let left = Math.floor(total / 2);
      let right = total - left;
      // Slightly alternate which side receives the extra bunch for visual balance.
      if (total % 2 && index % 2 === 1) {
        left = Math.ceil(total / 2);
        right = Math.floor(total / 2);
      }
      return { left, right, total };
    });

    const notes = [];
    if (n >= 21 && n <= 27) {
      notes.push({
        en: 'This quantity needs an unusually full single layer. Check the physical box width before packing; if it feels too tight, use an extra layer and follow your box’s safe capacity.',
        hi: 'इस संख्या के लिए एक परत सामान्य से अधिक भरी होगी। पैकिंग से पहले बॉक्स की चौड़ाई जाँचें; यदि जगह कम लगे, तो अतिरिक्त परत बनाएँ और बॉक्स की सुरक्षित क्षमता का ध्यान रखें।'
      });
    }
    if (layers.some(layer => layer.left > 10 || layer.right > 10)) {
      notes.push({
        en: 'At least one side has more than 10 bunches. Please check the actual bunch width and box capacity before packing.',
        hi: 'कम-से-कम एक तरफ 10 से अधिक बंच हैं। पैकिंग से पहले बंच की वास्तविक चौड़ाई और बॉक्स की क्षमता जाँच लें।'
      });
    }
    if (layers.some(layer => layer.left < 7 || layer.right < 7) && n > 20) {
      notes.push({
        en: 'One or more sides have fewer than 7 bunches because of the selected total. Adjust physically if needed while keeping the total exact.',
        hi: 'चुनी गई कुल संख्या के कारण एक या अधिक तरफ 7 से कम बंच हैं। जरूरत होने पर वास्तविक बॉक्स के अनुसार व्यवस्था बदलें, लेकिन कुल संख्या सही रखें।'
      });
    }
    return { layers, notes };
  }

  function showError(messageEn, messageHi) {
    errorBox.innerHTML = `${messageEn}<span class="hindi">${messageHi}</span>`;
    errorBox.hidden = false;
    results.hidden = true;
  }

  function calculate() {
    const raw = quantityInput.value.trim();
    const n = Number(raw);
    errorBox.hidden = true;
    if (!raw || !Number.isInteger(n) || n < 1 || n > 150) {
      showError('Please enter a whole number from 1 to 150.', 'कृपया 1 से 150 के बीच पूरी संख्या डालें।');
      quantityInput.focus();
      return;
    }

    const { layers, notes } = makeArrangement(n);
    const verifiedTotal = layers.reduce((sum, layer) => sum + layer.left + layer.right, 0);
    if (verifiedTotal !== n) {
      showError('The arrangement could not be verified. Please try again.', 'व्यवस्था की जाँच पूरी नहीं हो सकी। कृपया फिर से कोशिश करें।');
      return;
    }

    document.getElementById('total-value').textContent = n;
    document.getElementById('layers-value').textContent = layers.length;
    layerList.innerHTML = '';

    layers.forEach((layer, index) => {
      const card = document.createElement('article');
      card.className = 'layer-card';
      card.innerHTML = `
        <div class="layer-top">
          <div class="layer-title">Layer ${index + 1}<span class="hindi">परत ${index + 1}</span></div>
          <div class="layer-total">${layer.total} bunches<br><span class="hindi">${layer.total} बंच</span></div>
        </div>
        <div class="sides">
          <div class="side">
            <div class="side-name">Left side<span class="hindi">बाईं तरफ</span></div>
            <strong>${layer.left}</strong>
          </div>
          <div class="side">
            <div class="side-name">Right side<span class="hindi">दाईं तरफ</span></div>
            <strong>${layer.right}</strong>
          </div>
        </div>`;
      layerList.appendChild(card);
    });

    if (notes.length) {
      noteBox.innerHTML = notes.map(note => `<div>${note.en}<span class="hindi">${note.hi}</span></div>`).join('<hr>');
      noteBox.hidden = false;
    } else {
      noteBox.hidden = true;
      noteBox.innerHTML = '';
    }

    results.hidden = false;
    results.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  calculateButton.addEventListener('click', calculate);
  quantityInput.addEventListener('keydown', event => {
    if (event.key === 'Enter') calculate();
  });
  resetButton.addEventListener('click', () => {
    quantityInput.value = '';
    results.hidden = true;
    errorBox.hidden = true;
    quantityInput.focus();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });
})();