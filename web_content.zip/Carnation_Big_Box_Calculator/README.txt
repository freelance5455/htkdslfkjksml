CARNATION BIG BOX CALCULATOR
कार्नेशन बिग बॉक्स कैलकुलेटर

Files included:
- index.html: app interface
- style.css: responsive mobile-first design
- app.js: layer arrangement calculation
- README.txt: these instructions

How to test:
1. Extract the ZIP file.
2. Open index.html in a modern browser.
3. Enter a whole number from 1 to 150 and press Calculate.

How to make an APK:
Use these files in an HTML-to-APK builder, or place them in the assets folder of an Android Studio WebView project. This ZIP contains the website source files; it is not itself a compiled APK.

Important packing note:
The calculator provides a balanced layer-wise starting arrangement and checks that the total matches the entered quantity. Actual bunch width, box dimensions, and safe packing capacity can vary, so physically check the box before packing—especially where a note appears.

Permanent watermark:
Built by ER. Nitish Thakur
निर्माता: ER. Nitish Thakur
