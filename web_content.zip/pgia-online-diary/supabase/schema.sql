-- ПГИА – Кърджали: начален модел на база данни за Supabase / PostgreSQL
-- ВНИМАНИЕ: изпълнете първо в тестов проект. Не използвайте реални ученически данни,
-- преди да настроите и проверите политиките за достъп, резервните копия и правното основание.

create type public.app_role as enum ('director','teacher','homeroom','student','parent','club_coordinator');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null,
  role public.app_role not null default 'teacher',
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

create table public.school_classes (
  id uuid primary key default gen_random_uuid(),
  class_name text not null unique,
  grade smallint not null check (grade between 8 and 12),
  section text not null check (section in ('А','Б','В','Г')),
  homeroom_teacher_id uuid references public.profiles(id) on delete set null,
  school_year text not null default '2026/2027',
  created_at timestamptz not null default now()
);

create table public.students (
  id uuid primary key default gen_random_uuid(),
  profile_id uuid unique references public.profiles(id) on delete set null,
  student_number text,
  full_name text not null,
  class_id uuid not null references public.school_classes(id) on delete restrict,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

create table public.subjects (
  id uuid primary key default gen_random_uuid(),
  name text not null unique
);

create table public.teacher_subject_classes (
  id uuid primary key default gen_random_uuid(),
  teacher_id uuid not null references public.profiles(id) on delete cascade,
  subject_id uuid not null references public.subjects(id) on delete cascade,
  class_id uuid not null references public.school_classes(id) on delete cascade,
  unique(teacher_id, subject_id, class_id)
);

create table public.grades (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references public.students(id) on delete cascade,
  subject_id uuid not null references public.subjects(id) on delete restrict,
  teacher_id uuid not null references public.profiles(id) on delete restrict,
  grade numeric(2,1) not null check (grade >= 2 and grade <= 6),
  grade_date date not null default current_date,
  comment text,
  created_at timestamptz not null default now()
);

create table public.absences (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references public.students(id) on delete cascade,
  subject_id uuid references public.subjects(id) on delete set null,
  recorded_by uuid not null references public.profiles(id) on delete restrict,
  absence_date date not null default current_date,
  lessons_count smallint not null default 1 check (lessons_count > 0),
  status text not null check (status in ('неизвинено','извинено','закъснение')),
  note text,
  created_at timestamptz not null default now()
);

create table public.lessons (
  id uuid primary key default gen_random_uuid(),
  class_id uuid not null references public.school_classes(id) on delete cascade,
  subject_id uuid not null references public.subjects(id) on delete restrict,
  teacher_id uuid not null references public.profiles(id) on delete restrict,
  lesson_date date not null default current_date,
  topic text not null,
  homework text,
  homework_due date,
  created_at timestamptz not null default now()
);

create table public.audit_log (
  id bigint generated always as identity primary key,
  actor_id uuid references public.profiles(id) on delete set null,
  action text not null,
  entity_type text not null,
  entity_id text,
  created_at timestamptz not null default now()
);

create index students_class_id_idx on public.students(class_id);
create index grades_student_date_idx on public.grades(student_id, grade_date desc);
create index absences_student_date_idx on public.absences(student_id, absence_date desc);
create index lessons_class_date_idx on public.lessons(class_id, lesson_date desc);

-- Включваме RLS, но това само по себе си НЕ е достатъчно.
-- Политиките по-долу са минимална отправна точка и трябва да бъдат прегледани
-- от разработчик/администратор преди използване с реални лични данни.
alter table public.profiles enable row level security;
alter table public.school_classes enable row level security;
alter table public.students enable row level security;
alter table public.subjects enable row level security;
alter table public.teacher_subject_classes enable row level security;
alter table public.grades enable row level security;
alter table public.absences enable row level security;
alter table public.lessons enable row level security;
alter table public.audit_log enable row level security;

create or replace function public.current_app_role()
returns public.app_role
language sql stable security definer
set search_path = public
as $$
  select role from public.profiles where id = auth.uid() and is_active = true
$$;

-- Профил: потребителят вижда собствения си профил; директорът вижда профилите.
create policy "profile self or director read" on public.profiles
for select to authenticated
using (id = auth.uid() or public.current_app_role() = 'director');

-- Директорът управлява профили. Не разрешаваме на потребителя сам да променя ролята си.
create policy "director manages profiles" on public.profiles
for all to authenticated
using (public.current_app_role() = 'director')
with check (public.current_app_role() = 'director');

create policy "authenticated read classes" on public.school_classes
for select to authenticated using (true);
create policy "director manages classes" on public.school_classes
for all to authenticated
using (public.current_app_role() = 'director')
with check (public.current_app_role() = 'director');

-- За първа версия записите в дневника се управляват от директор/учителски роли.
-- Ограничението до конкретен клас/предмет трябва да се доразшири преди реално пускане.
create policy "staff read students" on public.students
for select to authenticated
using (public.current_app_role() in ('director','teacher','homeroom','club_coordinator'));
create policy "director manages students" on public.students
for all to authenticated
using (public.current_app_role() = 'director')
with check (public.current_app_role() = 'director');

create policy "authenticated read subjects" on public.subjects
for select to authenticated using (true);
create policy "director manages subjects" on public.subjects
for all to authenticated
using (public.current_app_role() = 'director')
with check (public.current_app_role() = 'director');

create policy "staff read teaching assignments" on public.teacher_subject_classes
for select to authenticated
using (public.current_app_role() in ('director','teacher','homeroom'));
create policy "director manages teaching assignments" on public.teacher_subject_classes
for all to authenticated
using (public.current_app_role() = 'director')
with check (public.current_app_role() = 'director');

create policy "staff read grades" on public.grades
for select to authenticated
using (public.current_app_role() in ('director','teacher','homeroom'));
create policy "staff insert grades" on public.grades
for insert to authenticated
with check (public.current_app_role() in ('director','teacher','homeroom') and teacher_id = auth.uid());
create policy "staff update own grades or director" on public.grades
for update to authenticated
using (teacher_id = auth.uid() or public.current_app_role() = 'director')
with check (teacher_id = auth.uid() or public.current_app_role() = 'director');
create policy "director deletes grades" on public.grades
for delete to authenticated
using (public.current_app_role() = 'director');

create policy "staff read absences" on public.absences
for select to authenticated
using (public.current_app_role() in ('director','teacher','homeroom'));
create policy "staff inserts absences" on public.absences
for insert to authenticated
with check (public.current_app_role() in ('director','teacher','homeroom') and recorded_by = auth.uid());
create policy "director manages absences" on public.absences
for all to authenticated
using (public.current_app_role() = 'director')
with check (public.current_app_role() = 'director');

create policy "staff read lessons" on public.lessons
for select to authenticated
using (public.current_app_role() in ('director','teacher','homeroom'));
create policy "staff writes lessons" on public.lessons
for insert to authenticated
with check (public.current_app_role() in ('director','teacher','homeroom') and teacher_id = auth.uid());
create policy "owner or director updates lessons" on public.lessons
for update to authenticated
using (teacher_id = auth.uid() or public.current_app_role() = 'director')
with check (teacher_id = auth.uid() or public.current_app_role() = 'director');
create policy "director deletes lessons" on public.lessons
for delete to authenticated
using (public.current_app_role() = 'director');

create policy "director reads audit log" on public.audit_log
for select to authenticated
using (public.current_app_role() = 'director');
