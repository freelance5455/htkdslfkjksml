/* ПГИА – Кърджали | Онлайн дневник
   В тази начална версия няма вградени тайни или пароли.
   Конфигурирайте Supabase URL и anon key в настройките по-долу.
*/
const SUPABASE_URL = "";       // Например: https://xxxxxxxx.supabase.co
const SUPABASE_ANON_KEY = "";  // Публичен anon key; никога не поставяйте service_role key тук.

const $ = (id) => document.getElementById(id);
let supabaseClient = null;
let currentUser = null;
let currentView = "dashboard";

const viewTitles = {
  dashboard: "Начало", students: "Ученици", classes: "Класове", grades: "Оценки",
  absences: "Отсъствия", lessons: "Уроци и домашни", reports: "Справки", settings: "Настройки"
};
const roleNames = {
  director: "Директор", teacher: "Учител", homeroom: "Класен ръководител",
  student: "Ученик", parent: "Родител", club_coordinator: "Координатор на клуб"
};

function showToast(message) {
  const el = $("toast");
  el.textContent = message;
  el.classList.add("show");
  setTimeout(() => el.classList.remove("show"), 3000);
}
function setView(view) {
  currentView = viewTitles[view] ? view : "dashboard";
  $("pageTitle").textContent = viewTitles[currentView];
  $("sectionHeading").textContent = currentView === "dashboard" ? "Общ преглед" : viewTitles[currentView];
  document.querySelectorAll(".nav-item").forEach(b => b.classList.toggle("active", b.dataset.view === currentView));
  const descriptions = {
    students: ["Регистър на учениците", "Списъкът ще се зарежда от защитената база данни."],
    classes: ["Класове и паралелки", "Учебни групи и класни ръководители."],
    grades: ["Оценки", "Оценките са достъпни според правата на профила."],
    absences: ["Отсъствия", "Присъствия, закъснения и извинени отсъствия."],
    lessons: ["Уроци и домашни работи", "Учебни теми, домашни работи и срокове."],
    reports: ["Справки и отчети", "Справките ще се изчисляват от реалните записи."],
    settings: ["Настройки на системата", "Конфигурацията и управлението на достъпа."]
  };
  if (currentView !== "dashboard") {
    $("tableTitle").textContent = descriptions[currentView][0];
    $("tableDescription").textContent = descriptions[currentView][1];
    $("tableHead").innerHTML = "<th>Информация</th><th>Статус</th><th>Бележка</th>";
    $("tableBody").innerHTML = `<tr><td colspan="3" class="empty-state">Разделът е подготвен във визуалния интерфейс. Следва да се свърже с таблиците и правилата за достъп в Supabase.</td></tr>`;
  } else {
    $("tableTitle").textContent = "Последни записи";
    $("tableDescription").textContent = "Последните действия ще се показват след свързване с базата данни.";
    $("tableHead").innerHTML = "<th>Раздел</th><th>Статус</th><th>Бележка</th>";
    $("tableBody").innerHTML = '<tr><td colspan="3" class="empty-state">Свържете Supabase, за да зареждате реални данни.</td></tr>';
  }
  $("sidebar").classList.remove("open");
}
function showSignedIn(profile) {
  currentUser = profile;
  $("loginView").hidden = true;
  $("appView").hidden = false;
  $("welcomeText").textContent = `Добре дошли${profile.full_name ? ", " + profile.full_name : ""}.`;
  $("profileName").textContent = profile.full_name || profile.email || "Потребител";
  $("profileRole").textContent = roleNames[profile.role] || profile.role || "Неопределена роля";
  $("avatar").textContent = (profile.full_name || profile.email || "П").split(/\s+/).slice(0,2).map(s => s[0]).join("").toUpperCase();
  $("connectionStatus").textContent = supabaseClient ? "Supabase е конфигуриран" : "Не е конфигурирана";
  setView("dashboard");
}
async function initSupabase() {
  if (!SUPABASE_URL || !SUPABASE_ANON_KEY || !window.supabase) return;
  supabaseClient = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
  $("connectionStatus").textContent = "Supabase е конфигуриран";
  const { data: { session } } = await supabaseClient.auth.getSession();
  if (session?.user) {
    const { data: profile } = await supabaseClient.from("profiles").select("id,full_name,role").eq("id", session.user.id).maybeSingle();
    showSignedIn({ ...profile, email: session.user.email });
  }
}
$("loginForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const email = $("email").value.trim();
  const password = $("password").value;
  $("loginMessage").textContent = "";
  if (!supabaseClient) {
    $("loginMessage").textContent = "Системата още не е свързана с Supabase. Следвайте README.md за настройка.";
    return;
  }
  const { data, error } = await supabaseClient.auth.signInWithPassword({ email, password });
  if (error) {
    $("loginMessage").textContent = "Входът не беше успешен. Проверете имейла и паролата.";
    return;
  }
  const { data: profile, error: profileError } = await supabaseClient.from("profiles").select("id,full_name,role").eq("id", data.user.id).single();
  if (profileError) {
    $("loginMessage").textContent = "Профилът не е настроен. Обърнете се към администратора.";
    return;
  }
  showSignedIn({ ...profile, email: data.user.email });
});
$("logoutBtn").addEventListener("click", async () => {
  if (supabaseClient) await supabaseClient.auth.signOut();
  currentUser = null;
  $("appView").hidden = true;
  $("loginView").hidden = false;
  $("password").value = "";
  showToast("Излязохте от системата.");
});
document.querySelectorAll("[data-view]").forEach(btn => btn.addEventListener("click", () => setView(btn.dataset.view)));
$("menuBtn").addEventListener("click", () => $("sidebar").classList.toggle("open"));
$("refreshBtn").addEventListener("click", () => showToast(supabaseClient ? "Сесията е активна. Зареждането на модулите предстои." : "Първо конфигурирайте Supabase."));
$("todayChip").textContent = new Intl.DateTimeFormat("bg-BG", { day:"numeric", month:"long", year:"numeric" }).format(new Date());
$("year").textContent = new Date().getFullYear();
initSupabase().catch(() => { $("connectionStatus").textContent = "Проверете настройките"; });
