BlueMouse Pro — HTML prototype

Contents:
- index.html: one-file app interface (HTML + embedded CSS + JavaScript)

How to use:
1. Extract this ZIP on your Android phone.
2. Upload index.html to APKForge as the app's HTML entry file.
3. Preview the interface.

Important limitations:
- This is a UI prototype. It does not yet send real Bluetooth mouse or keyboard input to Windows.
- Real Bluetooth HID requires native Android implementation and device testing.
- The 7-day trial is a localStorage prototype and is not secure licensing.
- The $10 payment and activation service are not connected.
