STARSMVRT CONCEPT – BRANCH & FINANCE MANAGER

Files:
- index.html: standalone app. Open in a modern browser (Chrome recommended).
- README.txt: this guide.

Included:
- Five starter branches: Abeokuta, Ibadan, Lagos, Ifo, Sagamu (you can add branches).
- Individual internal branch wallets.
- Cement sales register for Dangote, BUA and HBM; saved sales credit the chosen branch wallet.
- Transfer/expense requests with pending, approve and reject workflow. Approval debits the source wallet; internal branch transfers also credit the destination.
- Tax centre to register VAT, CIT, PAYE, WHT, Development levy and state/local obligations, due dates, liability, payment records and CSV export.
- Business profile, TIN field, JSON backup/restore, ledger CSV export.

IMPORTANT LIMITATIONS:
- This is a local/offline prototype. Data is stored in the browser on the device that opens it.
- It is NOT a real PalmPay account and does NOT connect to banks, send real transfers, verify payments or calculate/file tax returns.
- Branch wallet entries are internal accounting records. Record only money actually received as sales credits.
- For multi-device live sync, staff logins, audit controls and actual bank/payment API connectivity, a secure backend and authorized provider integration are required.
- Tax obligations and deadlines depend on entity type, turnover, transaction facts and applicable federal/state rules. Confirm with the Nigeria Revenue Service (NRS), relevant state authority and a qualified Nigerian tax professional before filing or paying.
- Back up your data regularly using Settings & backup.
