# Firebase setup for SOCIAL MEDIA

This project now uses real Firebase Authentication + Cloud Firestore hooks instead of localStorage authentication.

1. Create a Firebase project.
2. Register a Web app.
3. Enable Authentication > Sign-in method > Email/Password.
4. Create a Firestore database.
5. Copy the Web App config into `social-media/firebase-config.js`.
6. Apply `firestore.rules` to Firestore Rules.

The Firebase client configuration is not a service-account secret. Never put a Firebase Admin SDK service-account JSON or private key into the app.
