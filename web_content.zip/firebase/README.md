# Multiplayer Firebase — passo a passo

1. Acesse o [Firebase Console](https://console.firebase.google.com/) e crie um projeto.
2. Adicione um aplicativo Web e copie o objeto `firebaseConfig` completo.
3. Em **Authentication → Sign-in method**, habilite **Anonymous**.
4. Em **Realtime Database**, crie o banco e copie o `databaseURL` indicado pelo console.
5. Em **Realtime Database → Rules**, publique o conteúdo de `database.rules.json`.
6. No FOTO DUEL, abra **Multiplayer online → Configurar Firebase**, cole o `firebaseConfig` e salve.
7. Repita a configuração no segundo aparelho, usando o mesmo projeto Firebase.
8. No primeiro aparelho, escolha um deck completo e crie uma sala. No segundo, informe o código de seis caracteres e entre com outro deck. O anfitrião inicia quando os dois estiverem conectados.

## Compartilhamento de fotos

O compartilhamento de fotografias é opcional e vem desativado. Marque **Compartilhar fotos das cartas em campo** antes de criar/entrar na sala para reduzir as fotografias e permitir que a imagem da carta seja mostrada ao adversário quando ela for jogada. A mão e o monte de compra permanecem privados; o aplicativo não envia fotografias se a caixa estiver desmarcada. Não use fotos de outras pessoas sem consentimento.

## O que sincroniza

A sala guarda participantes, turno, vida, energia, criaturas ativas e do banco, estados, equipamentos, armadilhas e registro de jogadas. A mão e a pilha de compra ficam em `/private/{uid}`; as regras permitem que cada participante leia/escreva apenas o próprio caminho privado. O jogo público é alterado por transações e verifica o UID do turno atual.

## Segurança e custos

A API key Web do Firebase identifica o projeto; não é uma senha administrativa. As regras incluídas são apropriadas para um teste privado com duas pessoas. Como as jogadas ainda são validadas pelo cliente, não existe proteção anti-cheat completa. Para um lançamento competitivo, mova toda a validação das jogadas para Cloud Functions ou um servidor confiável, adicione App Check, limites de taxa e uma rotina de limpeza para salas abandonadas.

O Firebase pode gerar consumo/cobrança conforme uso e plano. As fotos são comprimidas, mas o compartilhamento de várias imagens aumenta tráfego e armazenamento. Para partidas sem internet, use o modo de dois jogadores no mesmo aparelho.
