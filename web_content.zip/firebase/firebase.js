// JavaScript

// Import only once per Firebase module, destructuring all needed functions
import { initializeApp } from "https://www.gstatic.com/firebasejs/12.18.0/firebase-app.js";
import { getAnalytics } from "https://www.gstatic.com/firebasejs/12.18.0/firebase-analytics.js";
import {
  getAuth,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/12.18.0/firebase-auth.js";
import {
  getDatabase,
  ref,
  set,
  get,
  child,
  remove
} from "https://www.gstatic.com/firebasejs/12.18.0/firebase-database.js";

// Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyDHjqIRyA7VoWoH1Wdr7XUbRmAxhnUufjk",
  authDomain: "clips-61b6a.firebaseapp.com",
  databaseURL: "https://clips-61b6a-default-rtdb.firebaseio.com",
  projectId: "clips-61b6a",
  storageBucket: "clips-61b6a.appspot.com",
  messagingSenderId: "408398676797",
  appId: "1:408398676797:web:ecc603268691d236ca3b54",
  measurementId: "G-GBWWMMFP4D"
};

// Initialize Firebase services
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);
const auth = getAuth(app);
const database = getDatabase(app);
const dbRef = ref(database);

// Export Firebase objects and functions for easy usage in other modules
export {
  app,
  analytics,
  auth,
  database,
  dbRef,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  onAuthStateChanged,
  get,
  child,
  set,
  ref,
  remove
};

// Simplified auth state change handler
export function onAuthChange(user) {
  if (user) {
    window.location.href = './main.html';
  } else {
    console.log('Please log in');
  }
}

// Usage example (in another module):
// import { auth, onAuthChange } from './firebase.js';
// onAuthStateChanged(auth, onAuthChange);