import { initializeApp } from "https://www.gstatic.com/firebasejs/12.18.0/firebase-app.js";
import { getAnalytics } from "https://www.gstatic.com/firebasejs/12.18.0/firebase-analytics.js";
import {
  getAuth,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  onAuthStateChanged,
  signOut
} from "https://www.gstatic.com/firebasejs/12.18.0/firebase-auth.js";
import {
  getDatabase,
  ref,
  set,
  get,
  child,
  push,
  remove,
  onValue
} from "https://www.gstatic.com/firebasejs/12.18.0/firebase-database.js";
import {
  getStorage,
  ref as storageRef,
  uploadBytes,
  getDownloadURL
} from "https://www.gstatic.com/firebasejs/12.18.0/firebase-storage.js";

const firebaseConfig = {
  apiKey: "AIzaSyDHjqIRyA7VoWoH1Wdr7XUbRmAxhnUufjk",
  authDomain: "clips-61b6a.firebaseapp.com",
  databaseURL: "https://clips-61b6a-default-rtdb.firebaseio.com",
  projectId: "clips-61b6a",
  storageBucket: "clips-61b6a.appspot.com",
  messagingSenderId: "408398676797",
  appId: "1:408398676797:web:ecc603268691d236ca3b54",
  measurementId: "G-GBWWMMFP4D"
};

const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);
const auth = getAuth(app);
const database = getDatabase(app);
const storage = getStorage(app);
const dbRef = ref(database);

export {
  app,
  analytics,
  auth,
  database,
  storage,
  dbRef,
  ref,
  set,
  get,
  child,
  push,
  remove,
  onValue,
  storageRef,
  uploadBytes,
  getDownloadURL,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  onAuthStateChanged,
  signOut
};
