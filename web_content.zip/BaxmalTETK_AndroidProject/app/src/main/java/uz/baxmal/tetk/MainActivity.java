package uz.baxmal.tetk;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.JavascriptInterface;
import android.content.Intent;
import android.net.Uri;
import android.widget.Toast;

public class MainActivity extends Activity {
  WebView web;
  @Override public void onCreate(Bundle b){super.onCreate(b); web=new WebView(this); web.getSettings().setJavaScriptEnabled(true); web.getSettings().setDomStorageEnabled(true); web.getSettings().setAllowFileAccess(true); web.getSettings().setAllowFileAccessFromFileURLs(true); web.getSettings().setAllowUniversalAccessFromFileURLs(true); web.setWebViewClient(new WebViewClient()); web.setWebChromeClient(new WebChromeClient()); web.addJavascriptInterface(new Bridge(), "AndroidBridge"); setContentView(web); web.loadUrl("file:///android_asset/index.html");}
  public class Bridge { @JavascriptInterface public void openMap(String uri){ runOnUiThread(()->{try{ Intent i=new Intent(Intent.ACTION_VIEW, Uri.parse(uri)); startActivity(i);}catch(Exception e){Toast.makeText(MainActivity.this,"Xarita ilovasi topilmadi",Toast.LENGTH_LONG).show();}}); } }
  @Override public void onBackPressed(){if(web!=null && web.canGoBack())web.goBack();else super.onBackPressed();}
}
