# Baxmal TETK Android ilovasi

Excel fayl asosida offline ishlaydigan hisoblagichlar qidiruvi. Jami yozuvlar: 35,592.

## Funksiyalar
- Abonent, shaxsiy hisob, hisoblagich raqami, TP, manzil bo‘yicha qidirish
- Abonent tafsilotlarini ko‘rish
- GPS lokatsiya tugmasi bosilganda Android xarita ilovasini `geo:` koordinatasi bilan ochish (telefon mavjud xarita ilovasini tanlatadi)
- Internet talab qilmaydigan ichki ma’lumotlar bazasi

## APK build qilish
1. Android Studio (JDK 17 va Android SDK 35) o‘rnating.
2. `BaxmalTETK_AndroidProject` papkasini Android Studio’da oching.
3. Gradle sync tugagach: **Build → Build APK(s)** ni tanlang.
4. APK odatda `app/build/outputs/apk/debug/app-debug.apk` ichida hosil bo‘ladi.

Ilova Excel faylidagi abonent ma’lumotlarini ichiga oladi. APKni faqat ruxsat berilgan xodimlarga tarqating.
