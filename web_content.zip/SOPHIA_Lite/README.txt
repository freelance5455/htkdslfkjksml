S.O.P.H.I.A. Lite — immediate prototype

HOW TO USE ON ANDROID
1. Download and extract SOPHIA_Lite.zip.
2. Open index.html in Chrome or another modern browser.
3. Allow microphone permission if prompted.
4. Tap Start listening, or type commands.

This is a lightweight web prototype, not an APK. It has a futuristic interface, typed commands, browser-supported voice recognition and spoken replies, and a few built-in commands. It is not a full AI model and does not have unrestricted control over Android. Voice recognition availability varies by browser and may require internet.
To turn it into an installable APK, it must be packaged and tested with an Android development toolchain.
