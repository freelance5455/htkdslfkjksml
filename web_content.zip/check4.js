
function toggleV44BestSalePanel(){
 const box=document.getElementById('v44BestSalePanel');
 if(!box)return;
 if(box.style.display!=='none'){box.style.display='none';return;}
 const sells=(S.trades||[]).filter(t=>{
   const type=String(t.type||'').toUpperCase();
   return type==='SELL' || type.includes('VENDA');
 });
 if(!sells.length){
   box.innerHTML='<div class="v44-best-sale-box"><div class="v44-best-sale-title">Melhor venda</div><div class="sub">Ainda não existem vendas.</div></div>';
 }else{
   const bestTrade=sells.reduce((best,t)=>Number(t.profit||0)>Number(best.profit||0)?t:best,sells[0]);
   const coin=String(bestTrade.symbol||'').replace('USDT','');
   const profit=Number(bestTrade.profit||0);
   const price=Number(bestTrade.price||0);
   const cls=profit>=0?'good':'bad';
   const sign=profit>=0?'+':'';
   box.innerHTML='<div class="v44-best-sale-box"><div class="v44-best-sale-title">Moeda da melhor venda</div><div class="v44-best-sale-coin">'+esc(coin||'—')+'</div><div class="v44-best-sale-meta">Lucro: <b class="'+cls+'">'+sign+money(profit)+'</b>'+(price?' · Preço: '+money(price):'')+'</div></div>';
 }
 box.style.display='block';
 box.scrollIntoView({behavior:'smooth',block:'nearest'});
}
