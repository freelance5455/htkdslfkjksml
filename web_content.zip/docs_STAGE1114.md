# CryptoPulse / CPLS V2 — Stage 1114

## Persistent Live Connections
- Internal page navigation now stays inside the same WebView/JS context instead of reloading local HTML pages.
- Shared LBank market WebSocket/native market cache remains alive while switching Home, Trade, Futures and Wallet.
- Trade K-Line history/live state can reuse the existing shared cache instead of reconnecting from zero.
- Futures now uses a persistent native background feed with in-memory market, order-book and recent price-sample caches.
- BTC Futures is pre-warmed at app startup; additional Futures symbols can be started without tearing down existing feeds.
- Futures chart reconstructs candles from real Futures price samples when official contract K-Line history is unavailable.
- Returning to Futures immediately hydrates the page from the hot native snapshot.

## Version
- Android versionCode: 113
- Android versionName: 11.3.0

## Note
The project archive was syntax-checked for JavaScript and structurally checked after patching. A local Gradle wrapper/build tool was not included in the uploaded project, so a full APK build was not available in this environment.
