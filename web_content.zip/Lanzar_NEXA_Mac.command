#!/bin/bash
cd "$(dirname "$0")"
echo "Iniciando NEXA Safety en ventana independiente..."
open -a "Google Chrome" --args --app="file://$(pwd)/index.html" 2>/dev/null || open "index.html"
