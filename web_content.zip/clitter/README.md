# Clitter — Supabase-ready frontend starter

This project includes the Clitter UI, Supabase email/password authentication, account credit display, credit-history loading, and clip-library loading. The actual AI video-processing worker and payment provider are **not included**; the signed-in Generate button intentionally does not charge credits or create fake clips.

## 1. Create the database

1. Open your project at https://supabase.com/dashboard.
2. Open **SQL Editor → New query**.
3. Open `supabase/schema.sql`, copy all its contents into the SQL Editor, and click **Run**.
4. The schema creates `profiles`, `credit_transactions`, `clips`, and `jobs`, enables Row Level Security (RLS), and creates a trigger that grants each newly created auth user 1,000 welcome credits once.
5. The browser is only allowed to read its own profile, credit ledger, clips, and jobs. It cannot update credit balances or insert fake clips.

If you have already run a previous version of this schema, check the SQL Editor output for any errors before proceeding.

## 2. Add the public browser credentials

1. In Supabase, open **Project Settings → API Keys** (or **Connect**, depending on dashboard layout).
2. Copy the **Project URL** and the **publishable key** (`sb_publishable_...`). The legacy `anon` key can also be used for this browser client if that is what your dashboard shows.
3. Open `frontend/index.html` in a code editor.
4. Near the top of the main script, replace these placeholders:

```js
const SUPABASE_URL='YOUR_SUPABASE_PROJECT_URL';
const SUPABASE_PUBLISHABLE_KEY='YOUR_SUPABASE_PUBLISHABLE_KEY';
```

Use the Project URL and publishable/anon key only. **Never put a `service_role` or secret key in `index.html`, a ZIP shared with users, or any browser-side code.** The publishable key is designed to be public; RLS is what protects user data.

## 3. Configure Auth URLs

In Supabase, open **Authentication → URL Configuration**:

- Set **Site URL** to the HTTPS URL where you deploy Clitter.
- Add that URL to **Redirect URLs**.
- For local development, add the exact local URL you use (for example `http://localhost:5500/**`) if your local server uses that port.
- If email confirmation is enabled, new users must confirm the email before they can sign in.

For testing, serve the folder using a local web server or deploy it to an HTTPS static host. Opening the HTML directly as `file://` may not work reliably for Auth redirects.

## 4. Test the connection

1. Open Clitter in the browser.
2. Tap **Sign in → Create account** and register with an email and password.
3. Confirm the email if Supabase asks you to.
4. Sign in. The app should show **CONNECTED**, display the profile's credit balance, and load credit history and any saved clip metadata.
5. Create a second account to confirm its data is isolated from the first account.

## What works after this setup

- Supabase email/password sign-up, sign-in, and sign-out.
- Profile and credit balance read from Postgres.
- Per-user credit history and clip library read under RLS.
- A one-time 1,000-credit welcome entry created by the auth trigger.
- Atomic backend-only credit reserve/refund SQL functions for future job processing.

## What still needs a backend

- AI highlight selection, transcription, FFmpeg vertical rendering, and real downloadable MP4s.
- A trusted server/worker that creates jobs and clip rows, uploads files, calls the reserve/refund functions, and updates job status.
- Payment checkout and verified payment webhooks before paid plans grant credits.

The authenticated UI intentionally will **not** run the fake demo generator or debit a real account's credits. Never let browser code decide or directly write the user's credit balance.
