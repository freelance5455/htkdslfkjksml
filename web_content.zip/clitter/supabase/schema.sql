-- Clitter Supabase schema
-- Run once in Supabase Dashboard > SQL Editor.
-- The browser app is read-only for credits. Only trusted server/worker code using
-- the service-role key may reserve/refund credits or write generated clip records.

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  credits integer not null default 1000 check (credits >= 0),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.credit_transactions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  amount integer not null check (amount <> 0),
  reason text not null,
  description text not null default '',
  balance_after integer not null check (balance_after >= 0),
  job_id uuid,
  created_at timestamptz not null default now()
);

create table if not exists public.clips (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null,
  duration_seconds integer not null default 0 check (duration_seconds >= 0),
  aspect_ratio text not null default '9:16' check (aspect_ratio in ('9:16','1:1','16:9')),
  caption_style text not null default 'clean',
  saved_minutes integer not null default 0 check (saved_minutes >= 0),
  status text not null default 'queued' check (status in ('queued','processing','completed','failed')),
  source_path text,
  output_path text,
  created_at timestamptz not null default now()
);

create table if not exists public.jobs (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  status text not null default 'queued' check (status in ('queued','processing','completed','failed','cancelled')),
  requested_shorts integer not null check (requested_shorts between 1 and 10),
  clip_length_seconds integer not null check (clip_length_seconds in (15,30,45,60)),
  credits_reserved integer not null check (credits_reserved >= 0),
  source_path text,
  error_message text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists credit_transactions_user_created_idx on public.credit_transactions(user_id, created_at desc);
create index if not exists clips_user_created_idx on public.clips(user_id, created_at desc);
create index if not exists jobs_user_created_idx on public.jobs(user_id, created_at desc);

-- Create a profile and grant the 1,000-credit welcome bonus exactly once per auth user.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  v_name text;
begin
  v_name := coalesce(new.raw_user_meta_data ->> 'display_name', split_part(new.email, '@', 1), 'Creator');
  insert into public.profiles (id, display_name, credits)
  values (new.id, v_name, 1000)
  on conflict (id) do nothing;

  insert into public.credit_transactions (user_id, amount, reason, description, balance_after)
  values (new.id, 1000, 'Welcome bonus', 'One-time new-account promotional credits', 1000)
  on conflict do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created_clitter on auth.users;
create trigger on_auth_user_created_clitter
after insert on auth.users
for each row execute procedure public.handle_new_user();

-- RLS: signed-in users can read only their own records. No browser-side balance updates.
alter table public.profiles enable row level security;
alter table public.credit_transactions enable row level security;
alter table public.clips enable row level security;
alter table public.jobs enable row level security;

drop policy if exists "Users can read own profile" on public.profiles;
create policy "Users can read own profile" on public.profiles
  for select to authenticated using ((select auth.uid()) = id);

drop policy if exists "Users can read own credit history" on public.credit_transactions;
create policy "Users can read own credit history" on public.credit_transactions
  for select to authenticated using ((select auth.uid()) = user_id);

drop policy if exists "Users can read own clips" on public.clips;
create policy "Users can read own clips" on public.clips
  for select to authenticated using ((select auth.uid()) = user_id);

drop policy if exists "Users can read own jobs" on public.jobs;
create policy "Users can read own jobs" on public.jobs
  for select to authenticated using ((select auth.uid()) = user_id);

revoke all on public.profiles from anon, authenticated;
revoke all on public.credit_transactions from anon, authenticated;
revoke all on public.clips from anon, authenticated;
revoke all on public.jobs from anon, authenticated;
grant select on public.profiles, public.credit_transactions, public.clips, public.jobs to authenticated;

-- Atomic credit reservation for trusted backend jobs. Not executable by browser users.
create or replace function public.reserve_clitter_credits(
  p_user_id uuid,
  p_amount integer,
  p_reason text default 'Clip generation',
  p_description text default 'Credits reserved for a generation job',
  p_job_id uuid default null
)
returns integer
language plpgsql
security definer
set search_path = public
as $$
declare
  v_balance integer;
begin
  if p_amount is null or p_amount <= 0 then
    raise exception 'Credit amount must be positive';
  end if;
  update public.profiles
     set credits = credits - p_amount, updated_at = now()
   where id = p_user_id and credits >= p_amount
   returning credits into v_balance;
  if v_balance is null then
    raise exception 'Insufficient credits or profile not found';
  end if;
  insert into public.credit_transactions(user_id, amount, reason, description, balance_after, job_id)
  values (p_user_id, -p_amount, p_reason, p_description, v_balance, p_job_id);
  return v_balance;
end;
$$;

-- Refund failed jobs through trusted backend code only.
create or replace function public.refund_clitter_credits(
  p_user_id uuid,
  p_amount integer,
  p_reason text default 'Generation refund',
  p_description text default 'Refund for a failed generation job',
  p_job_id uuid default null
)
returns integer
language plpgsql
security definer
set search_path = public
as $$
declare
  v_balance integer;
begin
  if p_amount is null or p_amount <= 0 then
    raise exception 'Refund amount must be positive';
  end if;
  update public.profiles
     set credits = credits + p_amount, updated_at = now()
   where id = p_user_id
   returning credits into v_balance;
  if v_balance is null then
    raise exception 'Profile not found';
  end if;
  insert into public.credit_transactions(user_id, amount, reason, description, balance_after, job_id)
  values (p_user_id, p_amount, p_reason, p_description, v_balance, p_job_id);
  return v_balance;
end;
$$;

revoke all on function public.reserve_clitter_credits(uuid, integer, text, text, uuid) from public, anon, authenticated;
revoke all on function public.refund_clitter_credits(uuid, integer, text, text, uuid) from public, anon, authenticated;
grant execute on function public.reserve_clitter_credits(uuid, integer, text, text, uuid) to service_role;
grant execute on function public.refund_clitter_credits(uuid, integer, text, text, uuid) to service_role;
