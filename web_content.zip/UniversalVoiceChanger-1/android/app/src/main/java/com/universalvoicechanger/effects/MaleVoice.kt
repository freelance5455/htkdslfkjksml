package com.universalvoicechanger.effects

class MaleVoice {
    fun process(sample: Float, previous: Float, amount: Float): Float =
        sample * (1f - amount * 0.04f) - (sample - previous) * amount * 0.03f
}
