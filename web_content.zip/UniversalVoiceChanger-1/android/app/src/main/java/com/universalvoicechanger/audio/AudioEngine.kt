package com.universalvoicechanger.audio

import android.content.Context
import com.universalvoicechanger.communication.LocalAudioTransport

class AudioEngine(context: Context) {
    private val input = AudioInput()
    private val output = AudioOutput()
    private val processor = VoiceProcessor()
    private val transport = LocalAudioTransport()

    init {
        transport.subscribe { buffer ->
            val processed = processor.process(buffer)
            output.write(processed)
        }
    }

    fun start() {
        output.start()
        input.start { buffer -> transport.publish(buffer) }
    }

    fun stop() {
        input.stop()
        transport.clear()
        output.stop()
    }

    fun setEffect(name: String, amount: Float) {
        processor.setEffect(name, amount)
    }

    fun setVolume(volume: Float) {
        output.setVolume(volume)
    }
}
