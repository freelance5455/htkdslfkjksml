package com.universalvoicechanger.communication

class LocalAudioTransport {
    private val listeners = mutableListOf<(ShortArray) -> Unit>()

    @Synchronized
    fun subscribe(listener: (ShortArray) -> Unit) {
        listeners += listener
    }

    @Synchronized
    fun publish(buffer: ShortArray) {
        listeners.toList().forEach { it(buffer) }
    }

    @Synchronized
    fun clear() {
        listeners.clear()
    }
}
