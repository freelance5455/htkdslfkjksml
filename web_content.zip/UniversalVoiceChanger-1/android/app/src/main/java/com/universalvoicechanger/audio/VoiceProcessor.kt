package com.universalvoicechanger.audio

import com.universalvoicechanger.effects.AdultVoice
import com.universalvoicechanger.effects.ChildVoice
import com.universalvoicechanger.effects.FemaleVoice
import com.universalvoicechanger.effects.MaleVoice

class VoiceProcessor {
    private val female = FemaleVoice()
    private val male = MaleVoice()
    private val child = ChildVoice()
    private val adult = AdultVoice()

    private var effect = "adult"
    private var amount = 0.7f
    private var previous = 0f

    fun setEffect(name: String, value: Float) {
        effect = name
        amount = value.coerceIn(0f, 1f)
    }

    fun process(input: ShortArray): ShortArray {
        val output = ShortArray(input.size)
        for (i in input.indices) {
            val sample = input[i] / 32768f
            val value = when (effect) {
                "female" -> female.process(sample, previous, amount)
                "male" -> male.process(sample, previous, amount)
                "child" -> child.process(sample, previous, amount)
                else -> adult.process(sample, previous, amount)
            }
            previous = sample
            output[i] = (value.coerceIn(-1f, 1f) * 32767f).toInt().toShort()
        }
        return output
    }
}
