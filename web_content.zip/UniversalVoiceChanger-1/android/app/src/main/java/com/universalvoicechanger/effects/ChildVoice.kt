package com.universalvoicechanger.effects

class ChildVoice {
    fun process(sample: Float, previous: Float, amount: Float): Float =
        sample * (1f + amount * 0.12f) + (sample - previous) * amount * 0.20f
}
