package com.universalvoicechanger.bridge

import android.content.Context
import android.webkit.JavascriptInterface
import com.universalvoicechanger.audio.AudioEngine

class WebAudioBridge(context: Context) {
    private val appContext = context.applicationContext
    private val engine = AudioEngine(appContext)

    @JavascriptInterface
    fun onWebReady() {}

    @JavascriptInterface
    fun setRunning(running: Boolean) {
        if (running) engine.start() else engine.stop()
    }

    @JavascriptInterface
    fun setEffect(name: String, amount: Double) {
        engine.setEffect(name, amount.toFloat())
    }

    @JavascriptInterface
    fun setVolume(volume: Double) {
        engine.setVolume(volume.toFloat())
    }

    @JavascriptInterface
    fun saveSettings(effect: String) {
        appContext.getSharedPreferences("settings", Context.MODE_PRIVATE)
            .edit()
            .putString("defaultEffect", effect)
            .apply()
    }
}
