package com.universalvoicechanger.effects

class AdultVoice {
    fun process(sample: Float, previous: Float, amount: Float): Float =
        sample * (1f + amount * 0.01f)
}
