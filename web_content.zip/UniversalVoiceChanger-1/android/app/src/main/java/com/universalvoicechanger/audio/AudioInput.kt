package com.universalvoicechanger.audio

import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder

class AudioInput {
    private val sampleRate = 44100
    private val minBuffer = AudioRecord.getMinBufferSize(
        sampleRate,
        AudioFormat.CHANNEL_IN_MONO,
        AudioFormat.ENCODING_PCM_16BIT
    )
    private var recorder: AudioRecord? = null
    private var thread: Thread? = null

    fun start(onAudio: (ShortArray) -> Unit) {
        if (thread != null) return

        val size = maxOf(minBuffer, 4096)
        recorder = AudioRecord(
            MediaRecorder.AudioSource.MIC,
            sampleRate,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT,
            size
        )
        recorder?.startRecording()

        thread = Thread {
            val buffer = ShortArray(1024)
            while (!Thread.currentThread().isInterrupted) {
                val count = recorder?.read(buffer, 0, buffer.size) ?: -1
                if (count > 0) onAudio(buffer.copyOf(count))
            }
        }.also { it.start() }
    }

    fun stop() {
        thread?.interrupt()
        thread = null
        recorder?.stop()
        recorder?.release()
        recorder = null
    }
}
