package com.universalvoicechanger.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack

class AudioOutput {
    private val sampleRate = 44100
    private var track: AudioTrack? = null
    private var volume = 1f

    fun start() {
        if (track != null) return
        val minBuffer = AudioTrack.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )
        track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setSampleRate(sampleRate)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(maxOf(minBuffer, 4096))
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
        track?.setVolume(volume)
        track?.play()
    }

    fun write(buffer: ShortArray) {
        track?.write(buffer, 0, buffer.size)
    }

    fun setVolume(value: Float) {
        volume = value.coerceIn(0f, 1f)
        track?.setVolume(volume)
    }

    fun stop() {
        track?.stop()
        track?.release()
        track = null
    }
}
