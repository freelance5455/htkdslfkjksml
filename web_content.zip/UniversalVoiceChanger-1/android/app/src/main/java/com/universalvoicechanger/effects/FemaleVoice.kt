package com.universalvoicechanger.effects

class FemaleVoice {
    fun process(sample: Float, previous: Float, amount: Float): Float =
        sample * (1f + amount * 0.08f) + (sample - previous) * amount * 0.12f
}
