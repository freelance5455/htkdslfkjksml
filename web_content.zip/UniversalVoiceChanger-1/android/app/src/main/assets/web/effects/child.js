export function child(ctx, amount) {
  const high = ctx.createBiquadFilter();
  high.type = "highshelf";
  high.frequency.value = 1800;
  high.gain.value = amount * 8;

  const bright = ctx.createBiquadFilter();
  bright.type = "peaking";
  bright.frequency.value = 3200;
  bright.Q.value = 0.9;
  bright.gain.value = amount * 5;

  return [high, bright];
}
