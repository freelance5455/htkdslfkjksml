export function adult(ctx, amount) {
  const body = ctx.createBiquadFilter();
  body.type = "peaking";
  body.frequency.value = 1100;
  body.Q.value = 0.7;
  body.gain.value = amount * 2;

  const smooth = ctx.createDynamicsCompressor();
  smooth.threshold.value = -18;
  smooth.ratio.value = 2;

  return [body, smooth];
}
