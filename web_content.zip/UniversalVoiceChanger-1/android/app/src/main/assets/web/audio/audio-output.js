export class AudioOutput {
  constructor() {
    this.gainNode = null;
  }

  connect(engine) {
    if (!engine?.outputNode || !engine?.context) return;
    this.gainNode = engine.context.createGain();
    engine.outputNode.connect(this.gainNode);
    this.gainNode.connect(engine.context.destination);
  }

  setVolume(value) {
    if (this.gainNode) this.gainNode.gain.value = Number(value);
  }

  disconnect() {
    try { this.gainNode?.disconnect(); } catch (_) {}
    this.gainNode = null;
  }
}
