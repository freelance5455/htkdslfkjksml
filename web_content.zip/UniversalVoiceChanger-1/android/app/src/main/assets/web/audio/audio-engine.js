export class AudioEngine {
  constructor() {
    this.context = null;
    this.inputGain = null;
    this.effectGain = null;
    this.outputNode = null;
    this.source = null;
    this.effectNodes = [];
  }

  async start(microphone) {
    this.context = new (window.AudioContext || window.webkitAudioContext)();
    if (this.context.state === "suspended") await this.context.resume();

    this.inputGain = this.context.createGain();
    this.effectGain = this.context.createGain();
    this.outputNode = this.context.createGain();
    this.effectGain.gain.value = 1;

    this.inputGain.connect(this.effectGain);
    this.effectGain.connect(this.outputNode);

    this.source = await microphone.start(this.context);
    this.source.connect(this.inputGain);
  }

  clearEffect() {
    for (const node of this.effectNodes) {
      try { node.disconnect(); } catch (_) {}
    }
    this.effectNodes = [];
  }

  setEffect(factory, amount) {
    if (!this.context || !this.inputGain) return;
    this.clearEffect();

    const nodes = factory(this.context, amount);
    if (!nodes || nodes.length === 0) return;

    this.inputGain.disconnect();
    let current = this.inputGain;
    for (const node of nodes) {
      current.connect(node);
      current = node;
    }
    current.connect(this.effectGain);
    this.effectNodes = nodes;
  }

  stop() {
    this.clearEffect();
    try { this.source?.disconnect(); } catch (_) {}
    try { this.inputGain?.disconnect(); } catch (_) {}
    try { this.effectGain?.disconnect(); } catch (_) {}
    try { this.outputNode?.disconnect(); } catch (_) {}
    this.context?.close();
    this.context = null;
    this.source = null;
  }
}
