import { female } from "../effects/female.js";
import { male } from "../effects/male.js";
import { child } from "../effects/child.js";
import { adult } from "../effects/adult.js";

const effects = { female, male, child, adult };

export function applyVoiceEffect(engine, name, amount) {
  const factory = effects[name] || effects.adult;
  engine.setEffect(factory, amount);
}
