export function female(ctx, amount) {
  const high = ctx.createBiquadFilter();
  high.type = "highpass";
  high.frequency.value = 90 + amount * 120;

  const presence = ctx.createBiquadFilter();
  presence.type = "peaking";
  presence.frequency.value = 2500;
  presence.Q.value = 0.8;
  presence.gain.value = amount * 6;

  return [high, presence];
}
