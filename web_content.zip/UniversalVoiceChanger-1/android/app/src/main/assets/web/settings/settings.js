const select = document.querySelector("#defaultEffect");
const save = document.querySelector("#save");
const message = document.querySelector("#message");

const stored = localStorage.getItem("defaultEffect");
if (stored) select.value = stored;

save.addEventListener("click", () => {
  localStorage.setItem("defaultEffect", select.value);
  if (window.AndroidVoiceBridge?.saveSettings) {
    window.AndroidVoiceBridge.saveSettings(select.value);
  }
  message.textContent = "Saved";
});
