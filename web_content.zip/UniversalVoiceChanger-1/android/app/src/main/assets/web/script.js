import { Microphone } from "./audio/microphone.js";
import { AudioEngine } from "./audio/audio-engine.js";
import { AudioOutput } from "./audio/audio-output.js";
import { applyVoiceEffect } from "./audio/voice-effects.js";

const effect = document.querySelector("#effect");
const amount = document.querySelector("#amount");
const amountValue = document.querySelector("#amountValue");
const volume = document.querySelector("#volume");
const volumeValue = document.querySelector("#volumeValue");
const startButton = document.querySelector("#start");
const stopButton = document.querySelector("#stop");
const status = document.querySelector("#status");

const android = !!window.AndroidVoiceBridge;
const microphone = new Microphone();
const engine = new AudioEngine();
const output = new AudioOutput();

function setStatus(text) { status.textContent = text; }

function syncEffect() {
  amountValue.textContent = `${Math.round(Number(amount.value) * 100)}%`;
  if (android) {
    window.AndroidVoiceBridge.setEffect(effect.value, Number(amount.value));
  } else if (engine.context) {
    applyVoiceEffect(engine, effect.value, Number(amount.value));
  }
}

function syncVolume() {
  volumeValue.textContent = `${Math.round(Number(volume.value) * 100)}%`;
  if (android) {
    window.AndroidVoiceBridge.setVolume(Number(volume.value));
  } else {
    output.setVolume(Number(volume.value));
  }
}

async function start() {
  try {
    startButton.disabled = true;
    stopButton.disabled = false;
    if (android) {
      window.AndroidVoiceBridge.setRunning(true);
    } else {
      await engine.start(microphone);
      output.connect(engine);
      syncVolume();
      syncEffect();
    }
    setStatus("Running");
  } catch (error) {
    console.error(error);
    setStatus("Microphone error");
    startButton.disabled = false;
    stopButton.disabled = true;
  }
}

function stop() {
  if (android) {
    window.AndroidVoiceBridge.setRunning(false);
  } else {
    output.disconnect();
    microphone.stop();
    engine.stop();
  }
  startButton.disabled = false;
  stopButton.disabled = true;
  setStatus("Stopped");
}

effect.addEventListener("change", syncEffect);
amount.addEventListener("input", syncEffect);
volume.addEventListener("input", syncVolume);
startButton.addEventListener("click", start);
stopButton.addEventListener("click", stop);

amountValue.textContent = `${Math.round(Number(amount.value) * 100)}%`;
volumeValue.textContent = `${Math.round(Number(volume.value) * 100)}%`;
