export function male(ctx, amount) {
  const low = ctx.createBiquadFilter();
  low.type = "lowshelf";
  low.frequency.value = 180;
  low.gain.value = -amount * 5;

  const body = ctx.createBiquadFilter();
  body.type = "peaking";
  body.frequency.value = 850;
  body.Q.value = 0.8;
  body.gain.value = -amount * 3;

  return [low, body];
}
