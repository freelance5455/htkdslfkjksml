export class Microphone {
  constructor() { this.stream = null; this.source = null; }

  async start(audioContext) {
    this.stream = await navigator.mediaDevices.getUserMedia({
      audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: false }
    });
    this.source = audioContext.createMediaStreamSource(this.stream);
    return this.source;
  }

  stop() {
    if (this.stream) this.stream.getTracks().forEach(track => track.stop());
    this.stream = null;
    this.source = null;
  }
}
