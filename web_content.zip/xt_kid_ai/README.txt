XT KID AI - Starter Project

How to use:
1. Upload this ZIP to an HTML-to-APK builder.
2. Set app name to XT KID AI.
3. Export as APK.

Important:
- This is a starter interface.
- It previews M15/M5 screenshots and generates a structured report.
- It does not yet perform real AI vision analysis.
- Real automatic analysis requires a secure backend and AI vision API.
