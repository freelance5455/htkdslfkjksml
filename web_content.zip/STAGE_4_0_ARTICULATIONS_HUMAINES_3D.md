# CGD V117 — Socle 4.0 : articulations humaines 3D

## Objectif
Améliorer la lecture corporelle des damistes sans modifier les règles, les coups légaux, les résultats, les compétitions ou les systèmes de carrière.

## Évolutions intégrées
- Jambes composées de deux segments avec genou visible, au lieu d'un seul membre rigide.
- Bras composés de bras supérieur et avant-bras, avec coude matérialisé.
- Points de flexion spécifiques aux attitudes réflexion, prise, célébration, défaite et présentation.
- Alternance des jambes et léger balancement du corps synchronisés à la trajectoire animée du pion.
- Transmission explicite des paramètres de marche à la construction du modèle 3D animé.
- Conservation des silhouettes, couleurs d'équipe, couronnes, éclairage, caméra et poses précédentes.

## Périmètre préservé
Aucun changement aux règles du jeu de dames, à la détection des prises, aux promotions, aux chronomètres, aux compétitions, aux classements ou à l'enregistrement des rencontres.

## Validation automatisée
- Suite complète : 232 tests réussis, 0 échec.
- Vérification syntaxique Node.js de tous les fichiers JavaScript de `src/` et `tests/` : réussie.

## Limites connues
Le rendu reste un modèle humanoïde stylisé en WebGL, pas une capture photoréaliste. Les articulations sont représentées par des segments géométriques et des points de flexion ; il ne s'agit pas encore d'un squelette 3D avec skinning. La validation visuelle réelle sur navigateur et téléphone reste à effectuer.
