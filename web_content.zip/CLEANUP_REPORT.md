# AI സിലബസ് — Cleanup / UI Update Report

തീയതി: 2026-10-26

## സിലബസ് പേജിലെ blank / disappearing panel

- സിലബസ് പേജിൽ ആദ്യം കണ്ട് പിന്നീട് കാലിയാവുകയോ മറയുകയോ ചെയ്തിരുന്ന പ്രത്യേക “ആഴ്ചയിലെ പിരീഡ്” +/− panel നീക്കംചെയ്തു.
- ആ panel-ിന്റെ polling, MutationObserver, runtime rendering code-ഉം നീക്കംചെയ്തു.
- **ആഴ്ചക്രമം പേജിലെ +/− സംവിധാനം നീക്കംചെയ്തിട്ടില്ല.** അത് നിലനിർത്തി പരിശോധിച്ചു.
- പാഠങ്ങളുടെ പിരീഡ് കൂട്ടാനും കുറയ്ക്കാനുമുള്ള lesson +/− controls-ഉം നിലനിർത്തിയിട്ടുണ്ട്.

## First-load flash ഒഴിവാക്കാൻ

- Add Subject ഭാഗം runtime-ൽ hide ചെയ്യുന്ന polling code നീക്കി native `details/summary` expand/collapse ആക്കി.
- Class panel മാറ്റിസ്ഥാപിക്കാനുണ്ടായിരുന്ന polling code നീക്കംചെയ്തു; ക്ലാസ് തിരഞ്ഞെടുപ്പ് ഇനി dashboard-ൽ ആദ്യം വരും.
- Backup-ലേക്കുള്ള പ്രത്യേക runtime button നീക്കി സാധാരണ navigation destination ആക്കി.

## UI / Mobile updates

- മൊബൈലിൽ 5-tab bottom navigation.
- Desktop-ൽ sticky top navigation; വ്യക്തമായ active state, icons, labels.
- പുതിയ compact header, app logo, refresh control, responsive typography.
- Mobile-first forms, cards, buttons, subject layouts, weekly controls, responsive tables.
- 44px-ലധികം touch targets, focus-visible states, improved contrast, reduced-motion support.
- Add Subject സൗകര്യം വ്യക്തമായ expand/collapse panel ആക്കി.
- Backup navigation എല്ലാ ഉപകരണങ്ങളിലും എളുപ്പത്തിൽ എത്താവുന്നതാക്കി.
- +/− പ്രവർത്തനങ്ങൾക്ക് ആവശ്യമായ notification function ചേർത്ത് modern toast message നൽകി.

## Offline / PWA updates

- 192px, 512px app icons ചേർത്തു; manifest അപ്ഡേറ്റ് ചെയ്തു.
- Malayalam font UI-യിലും ഉപയോഗിക്കുകയും offline cache-ൽ ചേർക്കുകയും ചെയ്തു.
- Icons, font, syllabus, manifest എന്നിവ service worker core cache-ൽ ചേർത്തു.
- `CACHE_NAME` `syllabus-calculator-v27` ആയി പുതുക്കി.

## പരിശോധന

- JavaScript syntax check pass.
- ESLint: checked scope-ൽ undefined reference, unused variable, unreachable code, duplicate key warnings ഇല്ല.
- Browser-like functional smoke test pass:
  - Class 2-ലെ 6 വിഷയങ്ങൾ load ചെയ്യൽ.
  - Manual subject adding.
  - Lesson +/− controls.
  - Weekly +/− controls: minus, rerender, plus, toast.
  - Weekly/timetable generation, backup navigation.
- Real Chromium test pass:
  - Mobile 390px viewport; body width 390px—horizontal page overflow ഇല്ല.
  - Blank quota panel ഇല്ല; weekly 6 plus, 6 minus controls ദൃശ്യമാണ്.
  - Mobile fixed navigation, desktop sticky navigation.
  - Page-level JavaScript errors ഇല്ല.
- Offline reload test pass: service worker controller സജീവം; 5 navigation buttons, സൂക്ഷിച്ച 6 വിഷയങ്ങൾ എന്നിവ തിരിച്ചു ലഭിച്ചു.
- External CDN ആവശ്യമുള്ള PDF/Excel export-ുകളുടെ live export test ഈ പരിശോധനയിൽ ഉൾപ്പെടുത്തിയിട്ടില്ല.

## Spacing-only update

- ചില ഉപകരണങ്ങളിൽ header-ന്റെ മുകളിൽ അധിക പച്ച ഭാഗം ഉണ്ടാക്കിയ device-dependent top padding നീക്കംചെയ്തു.
- Bottom navigation-ന്റെ താഴെ വന്നിരുന്ന അധിക blank space നീക്കംചെയ്തു.
- ഈ update-ൽ functionality, navigation, forms, data, export, backup എന്നിവയിൽ മാറ്റമില്ല.
- പുതിയ spacing cache ചെയ്യാൻ `CACHE_NAME` `syllabus-calculator-v28` ആയി മാറ്റി.

## Workflow update

- “ഉദാഹരണപാഠ പദ്ധതി ചേർക്കുക”, “ഉദാഹരണപാഠ പദ്ധതി മായ്ക്കുക” buttons, ചുവന്ന ചോദ്യചിഹ്ന help control, അതിന്റെ വിശദീകരണം, sample-data generation/detection/removal code എന്നിവ DOM-ൽ നിന്നും JavaScript-ൽ നിന്നും പൂർണ്ണമായി നീക്കംചെയ്തു.
- ആവശ്യമായ ഘട്ടം പൂർത്തിയാക്കാതെ മുന്നോട്ടുപോകുമ്പോൾ സിലബസ്, ആഴ്ചക്രമം, ടൈംടേബിൾ പേജുകളിൽ inline മുന്നറിയിപ്പ് കാണിക്കും. Navigation തടയുന്നില്ല; Backup-ന് നിയന്ത്രണമില്ല.
- “ഓട്ടോമാറ്റിക്” ആയി ക്രമീകരിച്ച weekly slot-ഉം പൂർത്തിയാക്കിയ ആഴ്ചക്രമമായി കണക്കാക്കും.
- Sample-removal / workflow tests, JavaScript syntax, ESLint, weekly and lesson controls, timetable generation എന്നിവയുടെ browser-like smoke tests pass.
- പുതിയ version എല്ലാ ഉപകരണങ്ങളിലും ലഭിക്കാൻ `CACHE_NAME` `syllabus-calculator-v29` ആയി മാറ്റി.

## Fixed mobile footer update

- മൊബൈലിൽ AI സിലബസ് branding അഞ്ച് navigation tabs-ന്റെ ഉടൻ മുകളിലേക്ക് മാറ്റി. Branding-ഉം tabs-ഉം scroll ചെയ്യുമ്പോഴും screen-ന്റെ താഴെ സ്ഥിരമായി നിൽക്കും.
- Top-left-ൽ വളരെ ചെറിയ അക്ഷരത്തിൽ `VKS thangal` ചേർത്തു. Refresh button-ന്റെ സ്ഥാനമോ പ്രവർത്തനമോ മാറ്റിയില്ല.
- Last Updated കുറിപ്പ് header-ൽ നിന്നും export text-ൽ നിന്നും നീക്കംചെയ്തു; അതിന്റെ HTML/CSS/JavaScript ഭാഗങ്ങൾ hide ചെയ്യാതെ പൂർണ്ണമായി ഡിലീറ്റ് ചെയ്തു.
- Fixed footer-ന് പിന്നിലേക്ക് content പോകാതിരിക്കാൻ bottom spacing-ഉം toast സ്ഥാനവും ക്രമീകരിച്ചു.
- Desktop-ന്റെ header branding-ഉം sticky navigation-ഉം മുമ്പുപോലെ നിലനിർത്തി.
- Chromium mobile scroll test, desktop layout test, workflow regression tests, JavaScript syntax, ESLint എന്നിവ pass. Page errors-ഉം horizontal overflow-ഉം ഇല്ല.
- പുതിയ version ലഭിക്കാൻ `CACHE_NAME` `syllabus-calculator-v30` ആയി മാറ്റി.

## Deploy ചെയ്യുമ്പോൾ

1. നിലവിലെ site-ന്റെയും browser data-യുടെയും ആവശ്യമുള്ള backup സൂക്ഷിക്കുക.
2. ZIP-ലെ ഘടന മാറ്റാതെ ഫയലുകൾ അപ്‌ലോഡ് ചെയ്യുക.
3. Deploy ചെയ്ത ശേഷം ഒരിക്കൽ refresh ചെയ്യുക.
4. മൊബൈലിൽ സിലബസ്, ആഴ്ചക്രമം, ടൈംടേബിൾ, backup tabs തുറന്ന് പരിശോധിക്കുക.
