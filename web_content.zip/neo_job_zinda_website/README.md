# Neo Job Zinda — Website Starter

A responsive React + TypeScript website starter for Neo Job Zinda Private Limited, with app directory, news, academy, franchise directory, contact and consultation forms, and a Supabase-backed admin console.

## Features included

- Responsive black/neon-green corporate website
- Apps directory with starter entries for Zinda Store, Zinda Learn, Zinda Marriage and Job Zinda
- News and updates listing
- Zinda Academy course listing
- Franchise directory and Google Maps links
- Contact/enquiry and consultation forms
- WhatsApp click-to-chat links
- `/admin` login route and `/admin/dashboard`
- Supabase schema and row-level security starter policies
- Admin CRUD for applications, posts, courses, and franchises

## Important before production

This is a source-code starter, not a deployed or fully audited production service. Configure Supabase, verify security policies, add server-side spam protection, test all workflows, and provide the real approved company details before launch.

The supplied initial admin password was intentionally **not written into source code**. Create an admin account in Supabase Auth using a private email/password, then add that user's UUID to `public.admin_profiles`. The current login form accepts the authentication account's email, not the display ID `ZINDA`; if you require a username-only login, implement a secure server-side username mapping or Edge Function. Never put a password in frontend code.

## Requirements

- Node.js 20+ recommended
- npm
- A Supabase project for persistent database and authentication

## Run locally

1. Extract this ZIP.
2. Open a terminal in the project directory.
3. Install dependencies:

   ```bash
   npm install
   ```

4. Copy `.env.example` to `.env` and set the Supabase project URL and anon key:

   ```env
   VITE_SUPABASE_URL=https://YOUR_PROJECT.supabase.co
   VITE_SUPABASE_ANON_KEY=YOUR_SUPABASE_ANON_KEY
   ```

5. Run the development server:

   ```bash
   npm run dev
   ```

6. Open the local URL shown by Vite.

Without Supabase variables, public pages use starter demo data. Forms show a demo submission state and do not deliver enquiries to the company.

## Configure Supabase

1. Create a Supabase project.
2. Open SQL Editor and run `supabase/schema.sql`.
3. In Supabase Authentication, create the initial administrator privately.
4. Copy the new user's UUID from Authentication users.
5. In SQL Editor, run the following with the real UUID:

   ```sql
   insert into public.admin_profiles (id, display_name)
   values ('REPLACE-WITH-AUTH-USER-UUID', 'ZINDA Administrator');
   ```

6. Add the project URL and anon key to `.env`.
7. Restart the dev server.
8. Log in at `/admin` with the administrator's configured Auth email and password.

The admin editor is a starter CRUD interface. It currently exposes core fields for each content type; extend forms and schema for extra video URLs, images, launch status, phone numbers, scheduling, translations, and media uploads before production.

## Build

```bash
npm run build
npm run preview
```

## Deployment

Deploy the built Vite site to a static hosting provider such as Vercel or Netlify. Configure the same `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY` environment variables in the hosting provider.

Configure SPA rewrites so routes such as `/admin` and `/academy` resolve to `index.html`.

## Security checklist

- Never put a Supabase service-role key in a `VITE_*` variable.
- Never hardcode administrator passwords.
- Review every RLS policy before production. The sample public enquiry/consultation insert policies permit anonymous inserts; add server-side validation and rate limiting/CAPTCHA before public launch.
- Configure storage bucket policies before uploading files.
- Add server-side validation, anti-spam protections, and notification providers if needed.
- Test that unauthenticated users cannot read enquiries, bookings, private notes, or unpublished content.
- Use verified addresses and branch data only.
- Configure real AI services server-side; no AI API key is included in this starter.
- Add approved privacy policy and terms before launch.

## Contact defaults

The starter includes the business contact details provided in the project conversation:
- Display name: Rafi Job Zinda
- Phone / WhatsApp: +91 98475 61998
- Instagram handle: @rafiography

Confirm that these details are authorized for public display before production.
