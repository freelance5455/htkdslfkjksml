-- Neo Job Zinda starter schema
-- Run in Supabase SQL Editor after creating your project.
-- Create the first admin in Supabase Auth, then insert their UUID into admin_profiles.
create extension if not exists pgcrypto;

create table if not exists public.admin_profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default 'Administrator',
  created_at timestamptz not null default now()
);

create table if not exists public.applications (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text unique not null,
  category text not null default 'General',
  description text not null default '',
  website_url text,
  logo_url text,
  status text not null default 'draft' check (status in ('draft','published','archived','Coming Soon','Under Development','Active')),
  featured boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create table if not exists public.posts (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  slug text unique not null,
  summary text not null default '',
  content text not null default '',
  category text not null default 'Company',
  cover_url text,
  status text not null default 'draft' check (status in ('draft','published','archived')),
  published_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create table if not exists public.courses (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  slug text unique not null,
  description text not null default '',
  category text not null default 'Company',
  thumbnail_url text,
  is_free boolean not null default true,
  status text not null default 'draft' check (status in ('draft','published','archived')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create table if not exists public.lessons (
  id uuid primary key default gen_random_uuid(),
  course_id uuid not null references public.courses(id) on delete cascade,
  title text not null,
  description text not null default '',
  video_url text,
  resource_url text,
  duration_minutes integer,
  sort_order integer not null default 0,
  status text not null default 'draft' check (status in ('draft','published','archived')),
  created_at timestamptz not null default now()
);
create table if not exists public.franchises (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text unique not null,
  address text not null,
  district text,
  state text,
  pin_code text,
  phone text,
  whatsapp text,
  maps_url text,
  latitude double precision,
  longitude double precision,
  description text not null default '',
  verified boolean not null default false,
  status text not null default 'draft' check (status in ('draft','published','archived')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create table if not exists public.enquiries (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  phone text not null,
  email text,
  category text not null default 'General enquiry',
  message text not null,
  status text not null default 'pending' check (status in ('pending','in_progress','replied','resolved','closed')),
  private_notes text,
  created_at timestamptz not null default now()
);
create table if not exists public.consultations (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  phone text not null,
  email text,
  category text not null default 'General consultation',
  preferred_date date,
  preferred_time time,
  meeting_preference text,
  message text not null,
  status text not null default 'pending' check (status in ('pending','confirmed','rescheduled','rejected','cancelled','completed')),
  private_notes text,
  created_at timestamptz not null default now()
);
create table if not exists public.company_settings (
  key text primary key,
  value jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);
create table if not exists public.admin_activity_logs (
  id uuid primary key default gen_random_uuid(),
  admin_id uuid references auth.users(id) on delete set null,
  action text not null,
  entity_type text,
  entity_id text,
  created_at timestamptz not null default now()
);

alter table public.admin_profiles enable row level security;
alter table public.applications enable row level security;
alter table public.posts enable row level security;
alter table public.courses enable row level security;
alter table public.lessons enable row level security;
alter table public.franchises enable row level security;
alter table public.enquiries enable row level security;
alter table public.consultations enable row level security;
alter table public.company_settings enable row level security;
alter table public.admin_activity_logs enable row level security;

create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path = public
as $$ select exists(select 1 from public.admin_profiles where id = auth.uid()); $$;

create policy "Admins can read own admin profile" on public.admin_profiles for select to authenticated using (id = auth.uid());
create policy "Public read published applications" on public.applications for select to anon, authenticated using (status = 'published' or status = 'Active' or status = 'Coming Soon' or status = 'Under Development' or public.is_admin());
create policy "Admins manage applications" on public.applications for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "Public read published posts" on public.posts for select to anon, authenticated using (status = 'published' or public.is_admin());
create policy "Admins manage posts" on public.posts for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "Public read published courses" on public.courses for select to anon, authenticated using (status = 'published' or public.is_admin());
create policy "Admins manage courses" on public.courses for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "Public read lessons for published courses" on public.lessons for select to anon, authenticated using (
  (status = 'published' and exists(select 1 from public.courses c where c.id = course_id and c.status = 'published' and c.is_free = true)) or public.is_admin()
);
create policy "Admins manage lessons" on public.lessons for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "Public read published franchises" on public.franchises for select to anon, authenticated using ((status = 'published' and verified = true) or public.is_admin());
create policy "Admins manage franchises" on public.franchises for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "Public submit enquiries" on public.enquiries for insert to anon, authenticated with check (true);
create policy "Admins manage enquiries" on public.enquiries for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "Public submit consultations" on public.consultations for insert to anon, authenticated with check (true);
create policy "Admins manage consultations" on public.consultations for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "Public read company settings" on public.company_settings for select to anon, authenticated using (key in ('public_contact','social_links','homepage') or public.is_admin());
create policy "Admins manage company settings" on public.company_settings for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "Admins read activity logs" on public.admin_activity_logs for select to authenticated using (public.is_admin());
create policy "Admins insert activity logs" on public.admin_activity_logs for insert to authenticated with check (public.is_admin());

insert into public.applications(name,slug,category,description,status) values
('Zinda Store','zinda-store','Commerce','Discover products and shopping experiences across the Zinda ecosystem.','Coming Soon'),
('Zinda Learn','zinda-learn','Education','Learning resources, tutorials and educational experiences.','Coming Soon'),
('Zinda Marriage','zinda-marriage','Community','A dedicated platform concept for marriage and community connections.','Coming Soon'),
('Job Zinda','job-zinda','Careers','Explore opportunities and career-related services.','Coming Soon')
on conflict (slug) do nothing;

insert into public.courses(title,slug,description,category,is_free,status) values
('Discover Neo Job Zinda','company-introduction','An introductory course about the company. Replace this starter description with approved company information.','Company',true,'draft')
on conflict (slug) do nothing;

-- Configure Storage buckets from Supabase Dashboard:
-- 1. Create "public-media" bucket for approved public logos, thumbnails and posters.
-- 2. Restrict writes to authenticated administrators with storage policies.
-- Never expose private documents from a public bucket.
