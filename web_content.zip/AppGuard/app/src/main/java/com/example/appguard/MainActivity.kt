package com.example.appguard

import android.accessibilityservice.AccessibilityServiceInfo
import android.content.*
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*

class MainActivity : android.app.Activity() {
    private val prefs by lazy { getSharedPreferences("guard", MODE_PRIVATE) }
    private lateinit var list: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        list = findViewById(R.id.appList)

        findViewById<Button>(R.id.serviceButton).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        findViewById<Button>(R.id.savePin).setOnClickListener {
            val pin = findViewById<EditText>(R.id.pinInput).text.toString()
            if (pin.length !in 4..8 || !pin.all(Char::isDigit)) {
                toast("PIN harus 4-8 digit")
            } else {
                prefs.edit().putString("pin", pin).apply()
                toast("PIN disimpan")
            }
        }
        renderApps()
    }

    override fun onResume() { super.onResume(); renderApps() }

    private fun renderApps() {
        list.removeAllViews()
        val pm = packageManager
        val apps = pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0
        ).distinctBy { it.activityInfo.packageName }
            .filter { it.activityInfo.packageName != packageName }
            .sortedBy { it.loadLabel(pm).toString().lowercase() }

        for (ri in apps) {
            val pkg = ri.activityInfo.packageName
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(12, 10, 12, 10)
                setBackgroundColor(Color.rgb(24,24,24))
            }
            val icon = ImageView(this).apply {
                setImageDrawable(ri.loadIcon(pm))
                layoutParams = LinearLayout.LayoutParams(52,52)
            }
            val name = TextView(this).apply {
                text = ri.loadLabel(pm).toString()
                textSize = 16f; setTextColor(Color.WHITE)
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                setPadding(12,0,8,0)
            }
            val check = CheckBox(this).apply {
                isChecked = prefs.getBoolean("blocked_$pkg", false)
                setOnCheckedChangeListener { _, checked ->
                    prefs.edit().putBoolean("blocked_$pkg", checked).apply()
                }
            }
            row.addView(icon); row.addView(name); row.addView(check)
            list.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 8 })
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
