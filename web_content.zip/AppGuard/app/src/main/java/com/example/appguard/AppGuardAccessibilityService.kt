package com.example.appguard

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

class AppGuardAccessibilityService : AccessibilityService() {
    private var lastPackage: String? = null
    private var lastLaunch = 0L

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName) return
        if (pkg == "android" || pkg == "com.android.systemui") return

        val prefs = getSharedPreferences("guard", MODE_PRIVATE)
        if (!prefs.getBoolean("blocked_$pkg", false)) {
            lastPackage = pkg
            return
        }

        val now = System.currentTimeMillis()
        if (pkg == lastPackage && now - lastLaunch < 900) return
        lastPackage = pkg
        lastLaunch = now

        val intent = Intent(this, LockActivity::class.java).apply {
            putExtra("package", pkg)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS)
        }
        startActivity(intent)
    }

    override fun onInterrupt() = Unit
}
