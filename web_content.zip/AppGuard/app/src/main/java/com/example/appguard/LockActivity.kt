package com.example.appguard

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.Window
import android.view.WindowManager
import android.widget.*

class LockActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("guard", MODE_PRIVATE) }
    private var targetPackage = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        setContentView(R.layout.activity_lock)

        targetPackage = intent.getStringExtra("package") ?: ""
        val name = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(targetPackage, 0)) }
                   catch (_: Exception) { targetPackage }
        findViewById<TextView>(R.id.appName).text = name

        findViewById<Button>(R.id.unlock).setOnClickListener {
            val entered = findViewById<EditText>(R.id.pin).text.toString()
            val saved = prefs.getString("pin", "") ?: ""
            if (saved.isNotEmpty() && entered == saved) {
                prefs.edit().putLong("bypass_until", System.currentTimeMillis() + 60_000L).apply()
                finish()
            } else {
                findViewById<TextView>(R.id.error).text = "PIN salah"
            }
        }
    }

    override fun onBackPressed() {
        // Tetap di layar pembatas agar tombol Back tidak langsung membuka aplikasi.
    }
}
