import { Feather, Ionicons } from "@expo/vector-icons";
import { Image } from "expo-image";
import { ActivityIndicator, Pressable, StyleSheet, Text, View } from "react-native";
import { useColors } from "@/hooks/useColors";
import type { Track } from "@/src/music";

interface TrackRowProps {
  track: Track;
  favorite?: boolean;
  cached?: boolean;
  busy?: boolean;
  onPlay: () => void;
  onFavorite?: () => void;
  onCache?: () => void;
  onRemoveCache?: () => void;
}

export function TrackRow({ track, favorite, cached, busy, onPlay, onFavorite, onCache, onRemoveCache }: TrackRowProps) {
  const colors = useColors();
  return (
    <View style={[styles.row, { borderBottomColor: colors.border }]}>
      <Pressable onPress={onPlay} accessibilityLabel={`Слушать ${track.trackName}`} style={styles.main}>
      <Image source={{ uri: track.artworkUrl }} contentFit="cover" style={[styles.cover, { backgroundColor: colors.coverPlaceholder }]} />
        <View style={styles.copy}>
          <Text numberOfLines={1} style={[styles.title, { color: colors.foreground }]}>{track.trackName}</Text>
          <Text numberOfLines={1} style={[styles.artist, { color: colors.mutedForeground }]}>{track.artistName}</Text>
        </View>
      </Pressable>
      {onFavorite ? (
        <Pressable onPress={onFavorite} accessibilityLabel={favorite ? "Убрать из избранного" : "В избранное"} style={styles.action}>
          <Ionicons name={favorite ? "heart" : "heart-outline"} size={20} color={favorite ? colors.primary : colors.mutedForeground} />
        </Pressable>
      ) : null}
      {onCache || onRemoveCache ? (
        <Pressable onPress={cached ? onRemoveCache : onCache} disabled={busy} accessibilityLabel={cached ? "Удалить офлайн-копию" : "Сохранить для офлайн"} style={styles.action}>
          {busy ? <ActivityIndicator size="small" color={colors.primary} /> : <Feather name={cached ? "check-circle" : "download"} size={18} color={cached ? colors.primary : colors.mutedForeground} />}
        </Pressable>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  row: { minHeight: 72, flexDirection: "row", alignItems: "center", borderBottomWidth: StyleSheet.hairlineWidth, paddingVertical: 9 },
  main: { flex: 1, flexDirection: "row", alignItems: "center", minWidth: 0 },
  cover: { width: 52, height: 52, borderRadius: 10 },
  copy: { flex: 1, paddingLeft: 12, paddingRight: 8, gap: 5 },
  title: { fontSize: 13, fontWeight: "600" },
  artist: { fontSize: 12 },
  action: { width: 39, height: 44, alignItems: "center", justifyContent: "center" },
});
