import { Feather, Ionicons } from "@expo/vector-icons";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { KeyboardAvoidingView } from "react-native-keyboard-controller";
import React, { useEffect, useMemo, useState } from "react";
import { FlatList, Platform, Pressable, StyleSheet, Text, TextInput, View } from "react-native";
import { useColors } from "@/hooks/useColors";

const CHAT_KEY = "echo:chat:v1";
type Language = "ru" | "en" | "ky";
type ChatMessage = { role: "user" | "assistant"; content: string };
const locales: Language[] = ["ru", "en", "ky"];
const copy: Record<Language, { title: string; subtitle: string; placeholder: string; send: string; greeting: string; suggestions: string[]; localReply: string; localMode: string }> = {
  ru: {
    title: "Музыкальный помощник", subtitle: "Тестовый экран чата · без AI-сервиса", placeholder: "Напиши сообщение…", send: "Отправить",
    greeting: "Привет. Какую музыку ты сегодня ищешь? Расскажи о настроении, любимом жанре или артисте.",
    suggestions: ["Что послушать вечером?", "Подскажи похожих артистов", "Объясни этот жанр"],
    localReply: "Это демонстрационный интерфейс: внешний AI-сервис не подключён. Открой вкладку «Поиск», чтобы найти доступные музыкальные превью.",
    localMode: "Ответы не генерируются AI",
  },
  en: {
    title: "Your music companion", subtitle: "Chat UI preview · no AI service", placeholder: "Write a message…", send: "Send",
    greeting: "Hi. What kind of music are you looking for today? Tell me your mood, favorite genre, or an artist you enjoy.",
    suggestions: ["Music for tonight?", "Find similar artists", "Explain a genre"],
    localReply: "This is a UI demo: no external AI service is connected. Open Search to find available music previews.",
    localMode: "Replies are not AI-generated",
  },
  ky: {
    title: "Музыка боюнча жардамчы", subtitle: "Чаттын көрүнүшү · AI кызматы жок", placeholder: "Билдирүү жаз…", send: "Жөнөтүү",
    greeting: "Салам. Бүгүн кандай музыка угуп жатасың? Маанайыңды, жактырган жанрыңды же артистиңди айтып бер.",
    suggestions: ["Кечке эмне угайын?", "Окшош аткаруучуларды тап", "Бул жанрды түшүндүр"],
    localReply: "Бул интерфейстин демо версиясы: тышкы AI кызматы туташкан эмес. Музыкалык үзүндүлөрдү табуу үчүн «Издөө» бөлүмүн ач.",
    localMode: "Жоопторду AI түзбөйт",
  },
};

export default function AssistantScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const [language, setLanguage] = useState<Language>("ru");
  const [draft, setDraft] = useState("");
  const [history, setHistory] = useState<Partial<Record<Language, ChatMessage[]>>>({});
  const t = copy[language];
  const topPadding = Platform.OS === "web" ? 67 : insets.top + 5;
  const messages = history[language] ?? [];
  const visibleMessages = useMemo(
    () => messages.length ? messages : [{ role: "assistant" as const, content: t.greeting }],
    [messages, t.greeting],
  );

  useEffect(() => {
    void AsyncStorage.getItem(CHAT_KEY).then((saved) => {
      if (saved) setHistory(JSON.parse(saved) as Partial<Record<Language, ChatMessage[]>>);
    }).catch(() => undefined);
  }, []);

  function persist(next: Partial<Record<Language, ChatMessage[]>>) {
    setHistory(next);
    void AsyncStorage.setItem(CHAT_KEY, JSON.stringify(next));
  }

  function sendMessage(text = draft) {
    const content = text.trim();
    if (!content) return;
    const userMessage: ChatMessage = { role: "user", content };
    const nextMessages = [...messages, userMessage];
    persist({ ...history, [language]: [...nextMessages, { role: "assistant", content: t.localReply }] });
    setDraft("");
  }

  return (
    <KeyboardAvoidingView style={[styles.screen, { backgroundColor: colors.background, paddingTop: topPadding }]} behavior="padding" keyboardVerticalOffset={0}>
      <View style={styles.header}>
        <View style={[styles.avatar, { backgroundColor: colors.primary }]}><Ionicons name="sparkles" size={20} color={colors.primaryForeground} /></View>
        <View style={{ flex: 1 }}>
          <Text style={[styles.title, { color: colors.foreground }]}>{t.title}</Text>
          <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>{t.subtitle}</Text>
        </View>
      </View>
      <View style={[styles.languageSelector, { backgroundColor: colors.card, borderColor: colors.border }]}>
        {locales.map((item) => (
          <Pressable key={item} onPress={() => setLanguage(item)} style={[styles.languageButton, language === item && { backgroundColor: colors.primary }]}>
            <Text style={[styles.languageText, { color: language === item ? colors.primaryForeground : colors.mutedForeground }]}>{item === "ru" ? "РУС" : item === "en" ? "ENG" : "КЫР"}</Text>
          </Pressable>
        ))}
      </View>
      <View style={[styles.localNotice, { backgroundColor: colors.card }]}>
        <Feather name="info" size={13} color={colors.mutedForeground} />
        <Text style={[styles.localNoticeText, { color: colors.mutedForeground }]}>{t.localMode}</Text>
      </View>
      <FlatList
        inverted
        data={[...visibleMessages].reverse()}
        keyExtractor={(_, index) => `${language}-${index}`}
        keyboardDismissMode="interactive"
        keyboardShouldPersistTaps="handled"
        contentContainerStyle={styles.messageList}
        renderItem={({ item }) => {
          const mine = item.role === "user";
          return <View style={[styles.messageRow, mine && styles.messageMine]}><View style={[styles.bubble, mine ? { backgroundColor: colors.primary } : { backgroundColor: colors.card, borderColor: colors.border }, !mine && styles.assistantBubble]}><Text style={[styles.messageText, { color: mine ? colors.primaryForeground : colors.foreground }]}>{item.content}</Text></View></View>;
        }}
        ListEmptyComponent={null}
      />
      {messages.length === 0 ? (
        <View style={styles.suggestions}>
          {t.suggestions.map((item) => <Pressable key={item} onPress={() => sendMessage(item)} style={[styles.suggestion, { backgroundColor: colors.card, borderColor: colors.border }]}><Text style={[styles.suggestionText, { color: colors.foreground }]}>{item}</Text><Feather name="arrow-up-right" size={14} color={colors.primary} /></Pressable>)}
        </View>
      ) : null}
      <View style={[styles.composerWrap, { borderTopColor: colors.border, paddingBottom: Math.max(insets.bottom, Platform.OS === "web" ? 34 : 12) }]}>
        <View style={[styles.composer, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <TextInput value={draft} onChangeText={setDraft} multiline maxLength={1500} placeholder={t.placeholder} placeholderTextColor={colors.mutedForeground} selectionColor={colors.primary} style={[styles.input, { color: colors.foreground }]} testID="assistant-message-input" />
          <Pressable onPress={() => sendMessage()} disabled={!draft.trim()} accessibilityLabel={t.send} style={[styles.sendButton, { backgroundColor: colors.primary, opacity: !draft.trim() ? 0.45 : 1 }]}>
            <Ionicons name="arrow-up" size={19} color={colors.primaryForeground} />
          </Pressable>
        </View>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  header: { flexDirection: "row", alignItems: "center", gap: 12, paddingHorizontal: 20, paddingTop: 8, paddingBottom: 15 },
  avatar: { width: 40, height: 40, borderRadius: 15, alignItems: "center", justifyContent: "center" },
  title: { fontSize: 16, fontWeight: "700" },
  subtitle: { fontSize: 11, marginTop: 4 },
  languageSelector: { marginHorizontal: 20, marginBottom: 10, borderWidth: 1, borderRadius: 14, padding: 4, flexDirection: "row", gap: 4 },
  languageButton: { flex: 1, height: 32, alignItems: "center", justifyContent: "center", borderRadius: 10 },
  languageText: { fontSize: 10, fontWeight: "700", letterSpacing: 0.9 },
  localNotice: { marginHorizontal: 20, marginBottom: 5, paddingHorizontal: 10, paddingVertical: 6, borderRadius: 10, flexDirection: "row", alignItems: "center", gap: 6, alignSelf: "flex-start" },
  localNoticeText: { fontSize: 10 },
  messageList: { flexGrow: 1, paddingHorizontal: 18, paddingTop: 8, paddingBottom: 10 },
  messageRow: { flexDirection: "row", justifyContent: "flex-start", marginBottom: 11 },
  messageMine: { justifyContent: "flex-end" },
  bubble: { maxWidth: "84%", paddingHorizontal: 14, paddingVertical: 11, borderRadius: 18 },
  assistantBubble: { borderWidth: 1, borderTopLeftRadius: 6 },
  messageText: { fontSize: 14, lineHeight: 20 },
  suggestions: { paddingHorizontal: 20, gap: 8, paddingBottom: 10 },
  suggestion: { minHeight: 42, paddingHorizontal: 13, borderRadius: 14, borderWidth: 1, flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  suggestionText: { fontSize: 12, fontWeight: "500" },
  composerWrap: { borderTopWidth: StyleSheet.hairlineWidth, paddingHorizontal: 14, paddingTop: 10 },
  composer: { minHeight: 48, maxHeight: 120, borderRadius: 20, borderWidth: 1, padding: 5, flexDirection: "row", alignItems: "flex-end", gap: 8 },
  input: { flex: 1, fontSize: 14, lineHeight: 20, paddingHorizontal: 10, paddingTop: 8, paddingBottom: 8, maxHeight: 108 },
  sendButton: { width: 36, height: 36, alignItems: "center", justifyContent: "center", borderRadius: 18, marginBottom: 1 },
});
