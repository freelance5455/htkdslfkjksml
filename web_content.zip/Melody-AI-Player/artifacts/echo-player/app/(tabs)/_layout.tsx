import { Feather, Ionicons } from "@expo/vector-icons";
import type { ComponentProps } from "react";
import { Image } from "expo-image";
import { Tabs } from "expo-router";
import { Platform, Pressable, StyleSheet, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useColors } from "@/hooks/useColors";
import { useMusic } from "@/src/MusicContext";

const labels: Record<string, string> = {
  index: "Главная",
  search: "Поиск",
  assistant: "Помощник",
  library: "Медиатека",
};

const icons: Record<string, keyof typeof Feather.glyphMap> = {
  index: "radio",
  search: "search",
  assistant: "message-circle",
  library: "layers",
};

type PlayerTabBarProps = Parameters<NonNullable<ComponentProps<typeof Tabs>["tabBar"]>>[0];

function MiniPlayer() {
  const colors = useColors();
  const { currentTrack, isPlaying, isLoading, currentTime, duration, togglePlayback } = useMusic();
  if (!currentTrack) return null;
  const progress = duration > 0 ? Math.min(100, (currentTime / duration) * 100) : 0;

  return (
    <View style={[styles.player, { backgroundColor: colors.card, borderColor: colors.border }]}>
      <Image source={{ uri: currentTrack.artworkUrl }} contentFit="cover" style={[styles.cover, { backgroundColor: colors.coverPlaceholder }]} />
      <View style={styles.trackCopy}>
        <Text numberOfLines={1} style={[styles.trackName, { color: colors.foreground }]}>{currentTrack.trackName}</Text>
        <Text numberOfLines={1} style={[styles.artist, { color: colors.mutedForeground }]}>{currentTrack.artistName}</Text>
      </View>
      <View style={styles.progressTrack}><View style={[styles.progressFill, { backgroundColor: colors.primary, width: `${progress}%` }]} /></View>
      <Pressable onPress={togglePlayback} accessibilityLabel={isPlaying ? "Пауза" : "Продолжить"} testID="player-play-toggle" style={styles.playButton}>
        {isLoading ? <Feather name="loader" size={17} color={colors.foreground} /> : <Ionicons name={isPlaying ? "pause" : "play"} size={21} color={colors.foreground} />}
      </Pressable>
    </View>
  );
}

function PlayerTabBar(props: PlayerTabBarProps) {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const bottom = Platform.OS === "web" ? 34 : Math.max(insets.bottom, 8);

  return (
    <View style={{ backgroundColor: colors.background, paddingBottom: bottom }}>
      <MiniPlayer />
      <View style={[styles.tabs, { borderTopColor: colors.border }]}>
        {props.state.routes.map((route, index) => {
          const focused = props.state.index === index;
          const color = focused ? colors.primary : colors.mutedForeground;
          return (
            <Pressable
              key={route.key}
              accessibilityRole="button"
              accessibilityState={focused ? { selected: true } : {}}
              accessibilityLabel={labels[route.name]}
              onPress={() => {
                const event = props.navigation.emit({ type: "tabPress", target: route.key, canPreventDefault: true });
                if (!focused && !event.defaultPrevented) props.navigation.navigate(route.name, route.params);
              }}
              style={styles.tabButton}
            >
              <Feather name={icons[route.name] ?? "circle"} size={19} color={color} />
              <Text style={[styles.tabLabel, { color, fontWeight: focused ? "700" : "500" }]}>{labels[route.name] ?? route.name}</Text>
            </Pressable>
          );
        })}
      </View>
    </View>
  );
}

export default function TabLayout() {
  const colors = useColors();
  return (
    <Tabs
      tabBar={(props) => <PlayerTabBar {...props} />}
      screenOptions={{
        headerShown: false,
        sceneStyle: { backgroundColor: colors.background },
      }}
    >
      <Tabs.Screen name="index" options={{ title: "Главная" }} />
      <Tabs.Screen name="search" options={{ title: "Поиск" }} />
      <Tabs.Screen name="assistant" options={{ title: "AI-чат" }} />
      <Tabs.Screen name="library" options={{ title: "Медиатека" }} />
    </Tabs>
  );
}

const styles = StyleSheet.create({
  player: { minHeight: 58, marginHorizontal: 11, marginBottom: 7, paddingHorizontal: 9, borderWidth: 1, borderRadius: 15, flexDirection: "row", alignItems: "center", gap: 10, position: "relative", overflow: "hidden" },
  cover: { width: 40, height: 40, borderRadius: 8 },
  trackCopy: { flex: 1, minWidth: 0, gap: 3 },
  trackName: { fontSize: 11, fontWeight: "700" },
  artist: { fontSize: 10 },
  progressTrack: { position: "absolute", left: 10, right: 10, bottom: 0, height: 2, backgroundColor: "rgba(148,160,152,0.18)" },
  progressFill: { height: 2 },
  playButton: { width: 36, height: 40, alignItems: "center", justifyContent: "center" },
  tabs: { minHeight: 54, borderTopWidth: StyleSheet.hairlineWidth, flexDirection: "row", paddingHorizontal: 4 },
  tabButton: { flex: 1, minHeight: 52, alignItems: "center", justifyContent: "center", gap: 4 },
  tabLabel: { fontSize: 9, letterSpacing: 0.1 },
});
