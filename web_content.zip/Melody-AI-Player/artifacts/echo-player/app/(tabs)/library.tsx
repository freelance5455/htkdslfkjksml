import { Feather } from "@expo/vector-icons";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Platform, Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import React, { useState } from "react";
import { useColors } from "@/hooks/useColors";
import { TrackRow } from "@/src/components/TrackRow";
import { useMusic } from "@/src/MusicContext";

type Collection = "saved" | "offline";

export default function LibraryScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const [collection, setCollection] = useState<Collection>("saved");
  const { favorites, cachedTracks, playTrack, toggleFavorite, removeCachedTrack } = useMusic();
  const tracks = collection === "saved" ? favorites : cachedTracks;
  const topPadding = Platform.OS === "web" ? 67 : insets.top + 8;

  return (
    <View style={[styles.screen, { backgroundColor: colors.background, paddingTop: topPadding }]}>
      <View style={styles.header}>
        <View><Text style={[styles.kicker, { color: colors.primary }]}>ТВОЯ КОЛЛЕКЦИЯ</Text><Text style={[styles.title, { color: colors.foreground }]}>Медиатека</Text></View>
        <View style={[styles.count, { backgroundColor: colors.card }]}><Text style={[styles.countText, { color: colors.mutedForeground }]}>{favorites.length + cachedTracks.length}</Text></View>
      </View>
      <View style={[styles.tabs, { borderBottomColor: colors.border }]}>
        <Pressable onPress={() => setCollection("saved")} style={[styles.tab, collection === "saved" && { borderBottomColor: colors.primary }]}>
          <Feather name="heart" size={15} color={collection === "saved" ? colors.primary : colors.mutedForeground} /><Text style={[styles.tabText, { color: collection === "saved" ? colors.foreground : colors.mutedForeground }]}>Избранное</Text><Text style={[styles.tabCount, { color: colors.mutedForeground }]}>{favorites.length}</Text>
        </Pressable>
        <Pressable onPress={() => setCollection("offline")} style={[styles.tab, collection === "offline" && { borderBottomColor: colors.primary }]}>
          <Feather name="download" size={15} color={collection === "offline" ? colors.primary : colors.mutedForeground} /><Text style={[styles.tabText, { color: collection === "offline" ? colors.foreground : colors.mutedForeground }]}>Офлайн</Text><Text style={[styles.tabCount, { color: colors.mutedForeground }]}>{cachedTracks.length}</Text>
        </Pressable>
      </View>
      <ScrollView contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: insets.bottom + 145 }} showsVerticalScrollIndicator={false}>
        <Text style={[styles.description, { color: colors.mutedForeground }]}>{collection === "saved" ? "Треки, к которым хочется вернуться." : "Сохранённые превью доступны без сети на этом устройстве."}</Text>
        {tracks.map((track) => (
          <TrackRow
            key={track.trackId}
            track={track}
            favorite={favorites.some((item) => item.trackId === track.trackId)}
            cached={cachedTracks.some((item) => item.trackId === track.trackId)}
            onPlay={() => playTrack(track)}
            onFavorite={() => toggleFavorite(track)}
            onRemoveCache={collection === "offline" ? () => void removeCachedTrack(track) : undefined}
          />
        ))}
        {tracks.length === 0 ? (
          <View style={styles.empty}>
            <View style={[styles.emptyIcon, { backgroundColor: colors.card }]}><Feather name={collection === "saved" ? "heart" : "download"} size={23} color={colors.primary} /></View>
            <Text style={[styles.emptyTitle, { color: colors.foreground }]}>{collection === "saved" ? "Избранное пока пусто" : "Нет сохранённых превью"}</Text>
            <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>{collection === "saved" ? "Отметь сердцем понравившийся трек, чтобы найти его здесь." : "Найди трек и нажми на значок загрузки, чтобы оставить его на устройстве."}</Text>
          </View>
        ) : null}
        {collection === "offline" && cachedTracks.length ? <Text style={[styles.notice, { color: colors.mutedForeground }]}>Кэшируются только музыкальные превью из каталога.</Text> : null}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  header: { paddingHorizontal: 22, paddingBottom: 18, flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  kicker: { fontSize: 10, letterSpacing: 2, fontWeight: "700", marginBottom: 7 },
  title: { fontSize: 29, fontWeight: "700", letterSpacing: -0.7 },
  count: { minWidth: 38, height: 34, alignItems: "center", justifyContent: "center", paddingHorizontal: 10, borderRadius: 17 },
  countText: { fontSize: 12, fontWeight: "700" },
  tabs: { flexDirection: "row", paddingHorizontal: 20, borderBottomWidth: 1, gap: 21 },
  tab: { flexDirection: "row", alignItems: "center", gap: 7, height: 44, borderBottomWidth: 2, borderBottomColor: "transparent" },
  tabText: { fontSize: 12, fontWeight: "700" },
  tabCount: { fontSize: 10, marginLeft: 1 },
  description: { fontSize: 12, marginTop: 17, marginBottom: 8 },
  empty: { alignItems: "center", paddingHorizontal: 28, paddingTop: 76 },
  emptyIcon: { width: 58, height: 58, borderRadius: 20, alignItems: "center", justifyContent: "center", marginBottom: 17 },
  emptyTitle: { fontSize: 15, fontWeight: "700", textAlign: "center" },
  emptyText: { fontSize: 12, lineHeight: 18, marginTop: 8, textAlign: "center" },
  notice: { textAlign: "center", fontSize: 10, paddingTop: 16 },
});
