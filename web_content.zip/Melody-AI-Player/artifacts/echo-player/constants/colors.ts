const palette = {
  text: "#F4F6F4",
  tint: "#1ED760",
  background: "#090B0A",
  foreground: "#F4F6F4",
  card: "#141816",
  cardForeground: "#F4F6F4",
  primary: "#1ED760",
  primaryForeground: "#07120B",
  secondary: "#1B211D",
  secondaryForeground: "#E8EEE9",
  muted: "#1B211D",
  mutedForeground: "#94A098",
  accent: "#1B211D",
  accentForeground: "#E8EEE9",
  destructive: "#FF6B6B",
  destructiveForeground: "#FFFFFF",
  border: "#242B26",
  input: "#242B26",
  heroStart: "#17392B",
  heroMiddle: "#111A15",
  heroEnd: "#101312",
  heroForeground: "#F2FFF6",
  heroMuted: "#A8B8AE",
  heroWave: "#58F79A",
  coverPlaceholder: "#202622",
  overlay: "rgba(0,0,0,0.56)",
};

const colors = {
  light: palette,
  dark: palette,
  radius: 16,
};

export default colors;
