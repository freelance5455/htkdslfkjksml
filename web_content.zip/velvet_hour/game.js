
const V8IMG={"kael": "assets/img_01.png", "rubi": "assets/img_02.png", "luna": "assets/img_03.png"};V8IMG.você=V8IMG.kael;
const V8IMG2={naty:"assets/img_04.png",guifer:"assets/img_05.png",debora:"assets/img_06.png"};
const V8IMG3={yuri:"assets/img_07.png"};
const V8IMG4={lara:"assets/img_08.png",marcela:"assets/img_09.png",fernando:"assets/img_10.png"};
const V8IMG5={erick:"assets/img_11.png",melina:"assets/img_12.png"};
const KEYS={};
const SV={raw(){try{return JSON.parse(localStorage.getItem('velvet8'))||{}}catch(e){return{}}},
 put(o){try{localStorage.setItem('velvet8',JSON.stringify(o))}catch(e){}},
 get(p){return this.raw()['p'+p]||null},set(p,d){const o=this.raw();o['p'+p]=d;o.part=p;this.put(o)},
 part(p){const o=this.raw();o.part=p;this.put(o)},clear(){try{localStorage.removeItem('velvet8')}catch(e){}}};
const V8={_c:null,ctx(){if(!this._c){try{this._c=new(window.AudioContext||window.webkitAudioContext)()}catch(e){}}return this._c},onFim:null,onFb:null,toPart2:null};
V8.typing=0;V8.ti=null;
V8.type=tx=>{clearInterval(V8.ti);const el=document.getElementById('dt');V8.full=tx;let i=0;el.textContent='';V8.typing=1;
 V8.ti=setInterval(()=>{if(!document.getElementById('dlg')||!el.isConnected){clearInterval(V8.ti);V8.typing=0;return}if(i>0&&el.textContent!==tx.slice(0,i)){clearInterval(V8.ti);V8.typing=0;return}i++;el.textContent=tx.slice(0,i);if(tx[i-1]!==' ')V8.blip();if(i>=tx.length){clearInterval(V8.ti);V8.typing=0}},32)};
V8.skipType=()=>{clearInterval(V8.ti);V8.typing=0;document.getElementById('dt').textContent=V8.full};
V8.wrap=()=>{const d=document.getElementById('dlg'),f=d.onclick;if(f)d.onclick=e=>{if(V8.typing){V8.skipType();return}f(e)}};
V8.blip=()=>{try{const c=V8.ctx();if(!c)return;if(c.state==='suspended')c.resume();const o=c.createOscillator(),v=c.createGain(),t0=c.currentTime;o.type='square';o.frequency.value=440;v.gain.setValueAtTime(.16,t0);v.gain.exponentialRampToValueAtTime(.002,t0+.05);o.connect(v);v.connect(c.destination);o.start(t0);o.stop(t0+.06)}catch(e){}};
/* ============ escolha de personagem / gênero ============ */
const SKIN={m:"assets/img_13.png",f:"assets/img_14.png"};
V8.gs=null;V8.fem=false;V8.IM1=null;V8.IM2=null;
V8.skin=g=>{if(!SKIN[g])return;V8.gs=g;V8.fem=g==='f';
 [V8.IM1,V8.IM2].forEach(M=>{if(!M)return;if(M['você'])M['você'].src=SKIN[g];if(M.kael)M.kael.src=SKIN[g]})};
V8.G=s=>{if(!V8.fem||typeof s!=='string')return s;
 return s.replace(/O Outro você/g,'A outra você').replace(/Outro você/g,'Outra você')
  .replace(/, Kael(?=[.,!?])/g,'').replace(/mim mesmo/g,'mim mesma').replace(/esteve sozinho/g,'esteve sozinha')
  .replace(/foi o único a/g,'foi a única a').replace(/não foi o único/g,'não foi a única').replace(/Você é o melhor/g,'Você é a melhor')
  .replace(/, querido\b/g,', querida').replace(/O senhor deseja/g,'A senhora deseja').replace(/, senhor\./g,', senhora.')
  .replace(/\bbem-vindo ao\b/g,'bem-vinda ao').replace(/\bBem-vindo ao\b/g,'Bem-vinda ao')};
(function(){const vt=V8.type;V8.type=tx=>vt(V8.G(tx));
 const dn=document.getElementById('dn');new MutationObserver(()=>{const x=V8.G(dn.textContent);if(x!==dn.textContent)dn.textContent=x}).observe(dn,{childList:true,characterData:true,subtree:true});
 const ch=document.getElementById('ch');new MutationObserver(()=>{ch.querySelectorAll('button').forEach(b=>{const x=V8.G(b.textContent);if(x!==b.textContent)b.textContent=x})}).observe(ch,{childList:true})})();
const $=i=>document.getElementById(i);
const P1=(function(){

/* ============ COMO EDITAR (leia primeiro) ============
 1) SALAS ficam na lista R. Cada sala tem: n (nome), c (cor da parede),
    l / r (sala à esquerda / direita), o (objetos), p (personagem: ['id', posição]).
    Objeto: [posição, 'tipo', 'texto que aparece'].  Porta: [posição,'porta', número da sala].
 2) PERSONAGENS ficam na lista NPC. Cada um tem uma fala, duas respostas (a e b),
    uma lembrança e uma fala para quando você voltar a falar com ele.
 3) Para usar um PNG: coloque assets/id.png (ex: assets/rubi.png) e inclua o nome em SRC.
 4) Cuidado com aspas ' e vírgulas: se apagar uma, o jogo trava.
======================================================== */
const SRC=V8IMG;const IM={};for(const k in SRC){const i=new Image();i.src=SRC[k];IM[k]=i}V8.IM1=IM;
const $=i=>document.getElementById(i),C=$('c'),g=C.getContext('2d',{willReadFrequently:true}),FL=146;
/* ---- tipos de objeto: [largura, altura, cor, detalhe, altura do chão] ---- */
const K={porta:[34,66,'#4a2a1e','#e0a458',0],cama:[64,26,'#7a1832','#e8d6c0',0],vitrola:[26,28,'#4a2a1e','#e0a458',0],janela:[46,60,'#1b1030','#d94f8a',50],quadro:[30,40,'#2a1a24','#e0a458',50],relogio:[22,50,'#4a2a1e','#e8d6c0',0],carta:[18,12,'#e8d6c0','#8a1f3d',22],estante:[40,70,'#3a2418','#a06a3a',0],gaveta:[36,56,'#46505a','#c8d4e8',0],panela:[24,20,'#555','#999',24],barril:[24,30,'#5a3a22','#8a5a3a',0],espelho:[24,56,'#3a4a66','#e0a458',30],mesa:[60,26,'#5a3328','#c8d4e8',0],piano:[46,40,'#111','#e8d6c0',0],planta:[22,36,'#1a3a24','#e8e8f0',0],caldeira:[40,60,'#3a1a1a','#d8481c',0],divan:[56,22,'#3a2a3a','#8a6a8a',0],altar:[40,44,'#2a1a2a','#a0203f',0]};
/* ---- as 22 salas ---- */
const R=[
{n:'Suíte 12',c:'#24122a',r:1,o:[[40,'cama','Lençóis mornos. A marca de um corpo, e o corpo sou eu.'],[120,'vitrola','A agulha desce. O jazz lento preenche tudo.'],[200,'janela','Chove em rosa e azul. Meu reflexo sorri meio segundo atrasado.']]},
{n:'Corredor Leste',c:'#1c1020',l:0,r:2,o:[[90,'quadro','Retrato da Senhora do Hotel. Os olhos me seguem, e piscam.']],p:['rubi',210]},
{n:'Saguão',c:'#2a1620',l:1,r:3,o:[[50,'relogio','Marca 23:59. Marcava 23:59 quando entrei.'],[270,'porta',5]],p:['alvorada',170]},
{n:'Corredor Oeste',c:'#1c1020',l:2,r:4,o:[[80,'carta','Carta na minha letra: “Não confie em quem lembra demais.”'],[240,'porta',7]]},
{n:'Escadaria',c:'#20122a',l:3,r:11,o:[[70,'porta',9],[250,'porta',14]]},
{n:'Biblioteca',c:'#2a1c14',l:2,r:6,o:[[80,'estante','Todos os livros têm o meu nome na lombada.'],[200,'estante','Um livro aberto descreve esta cena e continua além do que vivi.']]},
{n:'Arquivo de Luna',c:'#182028',l:5,o:[[60,'gaveta','Gavetas com datas que ainda vão acontecer.']],p:['luna',170]},
{n:'Cozinha',c:'#2a2418',l:3,r:8,o:[[240,'panela','Algo ferve. Cheira à casa onde nunca morei.']],p:['hera',140]},
{n:'Adega',c:'#1a1418',l:7,o:[[100,'barril','Barris rotulados com dias da semana que não existem.'],[210,'espelho','No espelho a adega está vazia. E eu estou de costas.']]},
{n:'Corredor dos Quartos',c:'#20122a',l:4,r:10,o:[],p:['nina',130]},
{n:'Quarto 13',c:'#22142e',l:9,o:[[60,'cama','Cama arrumada para alguém que acabou de levantar. Os lençóis ainda estão quentes.']],p:['isis',180]},
{n:'Sala de Jantar',c:'#2a1018',l:4,r:12,o:[[80,'mesa','Uma mesa posta para treze. Uma cadeira vazia.']],p:['garcom',170]},
{n:'Salão de Música',c:'#160a1e',l:11,r:13,o:[[60,'piano','As teclas se mexem sozinhas, em voz baixa.']],p:['corvo',160]},
{n:'Jardim de Inverno',c:'#12201a',l:12,o:[[100,'planta','Flores brancas e frias. Uma tem o meu rosto nas pétalas.']],p:['orfeu',180]},
{n:'Porão',c:'#120c10',l:4,r:15,req:4,o:[[130,'carta','Paredes escritas à mão, repetindo: “quem lembra quem?”']]},
{n:'Sala das Caldeiras',c:'#2a0c0c',l:14,r:16,o:[[100,'caldeira','O fogo queima sem lenha. Queima o que eu lembro.']]},
{n:'Túnel dos Relógios',c:'#0e1018',l:15,r:17,o:[[60,'relogio','Todos os ponteiros giram para trás.'],[220,'relogio','Marca a hora exata em que estou lendo isto: {hora}.']]},
{n:'Consultório',c:'#1c1c20',l:16,r:18,o:[[60,'divan','O divã tem a forma do meu corpo.']],p:['valerio',170]},
{n:'Capela Invertida',c:'#2a0a18',l:17,r:19,o:[[100,'altar','O altar adora o relógio. O relógio adora o nada.']],p:['senhora',170]},
{n:'Corredor Infinito',c:'#0c0c12',l:18,r:20,o:[[150,'quadro','Todos os quadros são espelhos. Todos os espelhos são portas fechadas.']]},
{n:'Espelho Infinito',c:'#101018',l:19,r:21,o:[[150,'espelho','Cada reflexo é um Você diferente. Um deles acena antes de mim.']]},
{n:'Sala Branca',c:'#c8c8d0',f:'#8a8a99',l:20,req:9,o:[],p:['outro',170]}];
/* ---- os personagens (Você é você; aqui estão os outros 12) ----
   ma / mb = lembrança que você recebe se aceitar / negar; da / db = fala quando você volta, conforme a sua resposta ---- */
const NPC={
rubi:{nome:'Rubi',roupa:'#a0203f',cabelo:'#7a1010',pele:'#f0d2c4',fala:'Você acordou. Quase ninguém acorda na mesma noite em que chega, você não foi o único, existem vários momentos como esse.',a:['Então estou no lugar certo.','Ótima resposta. O hotel gosta de quem não resiste.'],b:['Que lugar é este?','Pergunta velha. A resposta muda a cada hóspede.'],lembranca:'Rubi guarda a primeira hora do hotel: a hora em que alguém decidiu não ir embora.',depois:'Siga pelo hotel. Eu espero onde você já esteve.',ma:'Rubi guarda a primeira hora do hotel: a hora em que alguém decidiu não ir embora. Era você, e você sorria.',mb:'Rubi guarda a primeira hora do hotel: a hora em que alguém decidiu não ir embora. Era você, e você chorava.',da:'Você escolheu ficar. Fico feliz. Quase ninguém escolhe.',db:'Resistir só faz o hotel te querer mais. Eu avisei com carinho.'},
alvorada:{nome:'Sr. Alvorada',roupa:'#2a3a5a',cabelo:'#bbbbbb',fala:'Boa noite. Boa noite. Boa noite. Desculpe, o relógio repetiu.',a:['Boa noite.','Obrigado por responder. Poucos respondem.'],b:['Por que repete tudo?','Repetir é só lembrar com medo.'],lembranca:'O porteiro nunca viu ninguém sair. Só chegar. Há décadas.',depois:'Boa noite. A porta da frente não abre, mas ela está lá.',ma:'O porteiro nunca viu ninguém sair. Só chegar. Há décadas. Você foi o único a responder à saudação dele, e ele guardou isso como um tesouro.',mb:'O porteiro nunca viu ninguém sair. Só chegar. Há décadas. Você foi o único a perguntar o motivo, e por isso ele ainda guarda o seu rosto.',da:'Boa noite. Obrigado por sempre responder.',db:'Boa pergunta, a sua. Ainda estou pensando nela. Boa noite.'},
luna:{nome:'Luna',roupa:'#16141c',cabelo:'#c9cbe2',pele:'#f2e0dc',fala:'Cada hóspede deixa uma lembrança em mim. Você deixou duas.',a:['Quero as duas de volta.','Então precisa de coragem. Elas não voltam iguais.'],b:['Não deixei nada.','Todos dizem isso antes de lerem os próprios nomes nas gavetas.'],lembranca:'Luna guarda o seu nome. Não o de agora: o primeiro, de antes do hotel.',depois:'Continue. As gavetas não se esvaziam sozinhas.',ma:'Luna guarda o seu nome. Não o de agora: o primeiro, de antes do hotel. Ela deixou a gaveta entreaberta para você voltar.',mb:'Luna guarda o seu nome. Não o de agora: o primeiro, de antes do hotel. Ela leu o nome em voz alta, e você não reconheceu a própria voz.',da:'A gaveta continua entreaberta. Volte quando tiver coragem.',db:'Você ainda nega, mas as gavetas já têm o seu nome em letra nova.'},
hera:{nome:'Dona Hera',roupa:'#5a5a3a',cabelo:'#d8d0c0',fala:'Sente. A sopa de hoje é feita de coisas que você esqueceu.',a:['Eu como.','Tem gosto de infância, mesmo sem infância.'],b:['Não tenho fome.','A fome também é uma lembrança, querido.'],lembranca:'Hera cozinha o que os hóspedes perdem. Quanto mais esquecem, mais o hotel engorda.',depois:'A panela ainda ferve. Tudo ferve aqui.',ma:'Hera cozinha o que os hóspedes perdem. Quanto mais esquecem, mais o hotel engorda. Você comeu a sopa e lembrou o gosto de um dia que nunca viveu.',mb:'Hera cozinha o que os hóspedes perdem. Quanto mais esquecem, mais o hotel engorda. Você recusou, e a sopa esfriou com o seu nome na borda do prato.',da:'Comeu tudo, querido. Ficou um pouco do gosto de casa em você.',db:'Guardei um prato para você. A fome sempre volta.'},
nina:{nome:'Nina',roupa:'#3a4a4a',cabelo:'#2a1a1a',fala:'Limpei o quarto 12 hoje. De novo. Ontem também. Ou foi amanhã?',a:['Quantas vezes você limpou?','Todas. Todas ao mesmo tempo, às vezes.'],b:['Você deve estar cansada.','Cansada? Não durmo desde antes de ser camareira.'],lembranca:'Nina vê as noites se repetindo. Você já dormiu naquela cama mais vezes do que consegue contar.',depois:'Cuidado com os lençóis. Eles lembram.',ma:'Nina vê as noites se repetindo. Você já dormiu naquela cama mais vezes do que consegue contar. Ela contou por você: quarenta e uma noites, todas com o mesmo sonho.',mb:'Nina vê as noites se repetindo. Você já dormiu naquela cama mais vezes do que consegue contar. Ela guardou uma toalha dobrada para você, por gratidão.',da:'Quarenta e uma. Contei de novo hoje, só para você.',db:'Obrigada por perguntar. O quarto 12 pareceu menos sozinho hoje.'},
isis:{nome:'Ísis',roupa:'#4a3a6a',cabelo:'#111111',fala:'Estudo sonhos. O seu quarto é o único que sonha de volta.',a:['O que ele sonha?','Você. Sempre você, em outra versão.'],b:['Sonhos não sonham.','Diga isso ao espelho do porão.'],lembranca:'Ísis anotou: quem sonha no hotel não acorda, apenas troca de quarto.',depois:'Anote tudo. Papel é o único que não esquece sozinho.',ma:'Ísis anotou: quem sonha no hotel não acorda, apenas troca de quarto. Ela anotou o sonho do quarto: você, de costas, abrindo uma porta que não existe.',mb:'Ísis anotou: quem sonha no hotel não acorda, apenas troca de quarto. Ela anotou a sua dúvida e sublinhou duas vezes.',da:'Anotei o seu sonho. Está na página treze.',db:'Sublinhei a sua dúvida. Duvidar também é uma forma de sonhar.'},
garcom:{nome:'O Garçom',roupa:'#111111',cabelo:'#111111',pele:'#2a2a2a',fala:'O senhor deseja o prato do dia? É a sua própria voz, bem passada.',a:['Quero.','Agora sabe como soa por dentro.'],b:['Quem é você?','Quem serve é sempre quem ninguém olha.'],lembranca:'O Garçom serve uma lembrança por mesa. A sua mesa nunca esteve vazia.',depois:'A conta fica para depois. Sempre fica.',ma:'O Garçom serve uma lembrança por mesa. A sua mesa nunca esteve vazia. Você provou, e o gosto era a sua voz dizendo adeus.',mb:'O Garçom serve uma lembrança por mesa. A sua mesa nunca esteve vazia. Você perguntou o nome dele. Ele não tinha, e deixou a cadeira puxada para você.',da:'Gostou do prato? A casa nunca erra o tempero.',db:'Ainda sem nome, senhor. Mas a sua cadeira está sempre puxada.'},
corvo:{nome:'Corvo',roupa:'#1a1a22',cabelo:'#222222',fala:'Toco a mesma melodia há cem anos. Você a cantarolou quando entrou.',a:['Toque mais uma vez.','Esta nota é o seu passo no corredor.'],b:['Não conheço essa música.','Conhece. Só não a reconhece. É diferente.'],lembranca:'Corvo toca o som de quem chega. O seu passo é a única nota que nunca mudou.',depois:'Não pare de andar. A música depende disso.',ma:'Corvo toca o som de quem chega. O seu passo é a única nota que nunca mudou. Ele tocou de novo, e a nota mudou um pouco, em sua homenagem.',mb:'Corvo toca o som de quem chega. O seu passo é a única nota que nunca mudou. Você negou a música, e ele passou a tocar mais baixo, para não te assustar.',da:'Toquei de novo, mais devagar. Você ouviu a mudança?',db:'Toco baixo agora. Um dia você vai reconhecer.'},
orfeu:{nome:'Orfeu',roupa:'#2a4a2a',cabelo:'#6a5a3a',fala:'Plantei isto com o que sobrou de você. Dê boas-vindas às suas flores.',a:['Elas são lindas.','Crescem melhor no escuro. Como você, de certo modo.'],b:['Isso é perturbador.','A beleza costuma ser. A raiz mais ainda.'],lembranca:'Orfeu enterra as horas esquecidas. De cada uma nasce uma flor branca.',depois:'Não pise nas brancas. São as mais recentes.',ma:'Orfeu enterra as horas esquecidas. De cada uma nasce uma flor branca. Ele plantou uma flor nova, com o seu nome na raiz.',mb:'Orfeu enterra as horas esquecidas. De cada uma nasce uma flor branca. Ele concordou com você e, mesmo assim, deixou uma flor na sua porta.',da:'A flor que plantei para você abriu hoje. Não pise nela.',db:'Perturbador, sim. Mas a flor na sua porta continua viva.'},
valerio:{nome:'Dr. Valério',roupa:'#d8d8d0',cabelo:'#555555',fala:'Sente-se. O tema de hoje é: quem observa o observador?',a:['Eu observo a mim mesmo.','Então são dois. Já é um começo de doença, ou de cura.'],b:['Ninguém me observa.','Seria um alívio. Mas a sua pulsação diz que não.'],lembranca:'Dr. Valério diagnosticou o hotel: um homem que se dividiu em treze para suportar uma única noite.',depois:'A cura dói. A doença também. Escolha a dor com sentido.',ma:'Dr. Valério diagnosticou o hotel: um homem que se dividiu em treze para suportar uma única noite. Na ficha dele: “paciente se observa; ainda há esperança”.',mb:'Dr. Valério diagnosticou o hotel: um homem que se dividiu em treze para suportar uma única noite. Na ficha dele: “paciente nega ser observado; a pulsação discorda”.',da:'Continue se observando. É assim que a cura começa.',db:'A sua pulsação ainda me contradiz, Kael.'},
senhora:{nome:'A Senhora',roupa:'#6a1a3a',cabelo:'#e0e0e0',fala:'Todo tempo tem dono. O seu, eu comprei por uma lágrima.',a:['Devolva.','Devolver é matar o que cresceu com ele. Ainda quer?'],b:['Eu não vendi nada.','Vendeu, e riu. Foi a melhor risada da casa.'],lembranca:'A Senhora vende horas. A sua, Kael, foi a mais cara: a hora em que você se escolheu.',depois:'No fim, o tempo cobra. Eu só avisei.',ma:'A Senhora vende horas. A sua, Kael, foi a mais cara: a hora em que você se escolheu. Ela guardou o seu pedido numa gaveta e sorriu por vê-lo exigir o que é seu.',mb:'A Senhora vende horas. A sua, Kael, foi a mais cara: a hora em que você se escolheu. Ela guardou a sua risada e jurou que foi a melhor do hotel.',da:'O seu pedido está guardado. Ainda não decidi se devolvo.',db:'Negue o quanto quiser. A risada continua comigo.'},
outro:{nome:'Outro Kael',png:'kael',filtro:'invert(1)'}};
/* ---- final: quatro desfechos ---- */
const E={
A:['Final: O Hóspede é o Hotel',['Você aceita. As paredes respiram. Rubi, Luna, Corvo, Hera... todos dizem a mesma frase com a sua voz.','Se tudo que te acolhe é você, então nunca esteve sozinho. E nunca foi só você.','A porta da suíte 12 se abre. Dentro, alguém acorda e não lembra de nada. A chuva recomeça.']],
B:['Final: A Rua Sem Saída',['Você grita que nada disso é real. O espelho concorda, e isso é pior.','O hotel se apaga como uma vela. Você sai para a rua, mas a rua tem a mesma chuva.','Alguém pergunta o seu nome. Você responde, mas a voz que sai não é a sua.']],
C:['Final: Treze Vozes, Uma Pergunta',['Quem sonha o sonhador? O Outro você sorri com a sua boca.','Treze vozes falam juntas: “Treze não é um número. É a conta de quem conta.”','Você percebe que já perguntou isso antes. E antes disso. A pergunta é a porta.','Tela branca. Um relógio sem ponteiros. Uma suíte com a luz acesa. A chuva. A chuva. A chuva.']],
D:['Final: O Quarto Sem Porta',['Você não responde. O silêncio é o único quarto sem porta.','O Outro você senta ao seu lado. Por muito tempo, ninguém é ninguém.']],
E:['Final: A Hora Devolvida',['Você exige o que é seu. Luna abre a última gaveta e a Senhora, em silêncio, devolve a lágrima.','O relógio da Capela gira para a frente pela primeira vez. Cada hóspede some com um aceno, como quem sai de uma festa.','Você acorda na suíte 12. Ainda chove, mas a chuva agora tem hora para acabar.']]};
/* ============ motor do jogo ============ */
let rm=0,px=40,dir=1,busy=0,keys=KEYS,t=0,F,vivo=0,A=null,OUT=null,on=1,lpf=0;
function say(n,tx,ch,next){busy=1;$('dn').textContent=n;V8.type(tx);const b=$('ch');b.innerHTML='';
 if(ch){$('dlg').onclick=null;ch.forEach(([l,f])=>{const x=document.createElement('button');x.textContent=l;x.onclick=e=>{e.stopPropagation();f()};b.append(x)})}
 else $('dlg').onclick=next||end;V8.wrap()}
function end(){RV=0;busy=0;$('ch').innerHTML='';$('dn').textContent=R[rm].n;$('dt').textContent='…';$('dlg').onclick=null;save()}
function seq(a,done){let i=0;const s=()=>{if(i>=a.length)return done?done():end();const[n,x]=a[i++];say(n,x,null,s)};s()}
function talk(id){const c=NPC[id];if(id==='outro')return final();
 if(F.met[id])return say(c.nome,c['d'+(F.ch&&F.ch[id])]||c.depois);
 say(c.nome,c.fala,[[c.a[0],()=>resp(id,'a')],[c.b[0],()=>resp(id,'b')]])}
function resp(id,k){const c=NPC[id];F[k==='a'?'acc':'neg']++;F.ch=F.ch||{};F.ch[id]=k;const mem=c['m'+k]||c.lembranca;
  seq([[c.nome,c[k][1]],['Lembrança',mem]],()=>{F.met[id]=1;F.fr++;F.frs.push(c.nome+': '+mem);end()})}
function final(){const ch=F.ch||{};
 const abre=F.acc>F.neg?'Você aceitou quase tudo. Foi fácil demais, ou foi o hotel que facilitou?':F.neg>F.acc?'Você negou quase tudo. Até a dúvida cansou de você.':'Metade aceitou, metade negou. O hotel gosta de quem não se decide.';
 seq([['Outro você','Você demorou. Eu estive aqui o tempo todo. Ou foi você?'],['Outro você','Cada pessoa que conheceu era uma hora que você deixou para trás.'],['Outro você',abre],['Outro você','Se uma hora esquecida ainda caminha, quem é dono do tempo: quem lembra ou quem vive?']],
  ()=>say('Outro você','Escolha. Ou escolha não escolher.',[
   ...(F.acc>=1?[['Aceitar: eu sou o hotel',()=>ending('A')]]:[]),
   ...(F.neg>=1?[['Negar: nada disso é real',()=>ending('B')]]:[]),
   ...(F.fr>=11&&F.acc>=4&&F.neg>=4?[['Perguntar: quem sonha o sonhador?',()=>ending('C')]]:[]),
   ...(F.fr>=11&&ch.senhora==='a'&&ch.luna==='a'?[['Exigir: devolvam a minha hora',()=>ending('E')]]:[]),
   ['Calar',()=>ending('D')]]))}
function ending(k){$('dlg').classList.add('tr');const [ti,ls]=E[k];const pf=F.acc>=8?'O hotel agora te chama pelo nome, como quem chama um dos seus.':F.neg>=8?'O hotel guardou cada recusa, uma a uma, como quem guarda moedas.':'Nem inteiro de um lado, nem do outro: o hotel anotou a sua dúvida.';
 seq([...ls.map(x=>['…',x]),['Hotel','Você aceitou '+F.acc+' vezes e negou '+F.neg+'. O hotel contou todas.'],['Hotel',pf]],()=>fin(ti,k))}
function fin(ti,k){$('dlg').classList.remove('tr');$('dlg').onclick=null;let v=[];try{v=JSON.parse(localStorage.getItem('velvet4f'))||[]}catch(e){}
 if(k&&!v.includes(k)){v.push(k);try{localStorage.setItem('velvet4f',JSON.stringify(v))}catch(e){}}
 vivo=0;busy=1;V8.toPart2(ti)}
function move(n,via){const q=R[n];
 if(q.req&&F.fr<q.req){if(via==='r')px=300;if(via==='l')px=20;say('Você','Algo me impede de seguir. Preciso de mais lembranças ('+F.fr+'/'+q.req+').');return}
 const from=rm;rm=n;const d=q.o.find(o=>o[1]==='porta'&&o[2]===from);px=d?d[0]+17:(via==='l'?306:14);dir=via==='l'?-1:1;$('dn').textContent=q.n;save()}
function save(){if(!vivo)return;try{SV.set(1,{F,rm,px})}catch(e){}}
function load(){try{return SV.get(1)}catch(e){return null}}
function near(){const q=R[rm];if(q.p&&Math.abs(px-q.p[1])<24)return{npc:q.p[0]};
 const o=q.o.find(o=>px>=o[0]-8&&px<=o[0]+K[o[1]][0]+8);return o?{o}:null}
function act(){if(!vivo||busy)return;audio();const a=near();if(!a){say('Você','Nada por aqui.');return}
 if(a.npc)return talk(a.npc);const o=a.o;if(o[1]==='porta')return move(o[2],'d');
 if(o[1]==='vitrola')F.rec=!F.rec;let tx=o[1]==='vitrola'&&!F.rec?'Silêncio de novo. A chuva assume.':o[2];if(tx.includes('{hora}')){RV=tx;tx=tx.replace('{hora}',hora())}say('Você',tx)}
const book=()=>{if(vivo&&!busy)say('Lembranças ('+F.fr+'/11)',F.frs.length?F.frs.join('\n\n'):'Ainda não tenho nenhuma.')};
/* ============ detalhes extras: ambiente ============ */
function amb(q){if(rm===21)return;const q2=rm>=15;
 rc('rgba(0,0,0,.35)',0,0,320,6);rc('rgba(224,164,88,.22)',0,6,320,1);rc('rgba(224,164,88,.08)',0,8,320,1);
 for(let x=0;x<320;x+=32)for(let y=20;y<FL-40;y+=28){const o=(((x/32)+(y/28))|0)%2?16:0;rc('rgba(255,255,255,.035)',x+o+14,y,2,2);rc('rgba(255,255,255,.035)',x+o+13,y+2,4,2);rc('rgba(255,255,255,.035)',x+o+14,y+4,2,2)}
 rc('rgba(0,0,0,.22)',0,FL-34,320,28);rc('rgba(224,164,88,.18)',0,FL-34,320,1);
 for(let x=4;x<320;x+=40){rc('rgba(255,255,255,.05)',x,FL-30,32,1);rc('rgba(0,0,0,.25)',x,FL-10,32,1);rc('rgba(0,0,0,.2)',x,FL-30,1,21);rc('rgba(255,255,255,.04)',x+31,FL-30,1,21)}
 for(let r=0;r<4;r++){const y=FL+r*9;rc('rgba(0,0,0,.22)',0,y+8,320,1);for(let x=(r%2)*28;x<320;x+=56)rc('rgba(0,0,0,.18)',x,y,1,9)}
 rc('rgba(255,255,255,.04)',0,FL,320,1);
 if(rm<14){rc('rgba(138,31,61,.28)',30,FL+10,260,14);rc('rgba(224,164,88,.25)',30,FL+10,260,1);rc('rgba(224,164,88,.25)',30,FL+23,260,1);for(let x=30;x<290;x+=6){rc('rgba(224,164,88,.18)',x,FL+24,1,2)}}
 if(rm===1){[0,304].forEach(x=>{rc('#5a1226',x,8,16,FL-8);for(let y=8;y<FL;y+=1)if(y%1===0)rc('rgba(0,0,0,.25)',x+4+(y>>4)%2,y,1,1);rc('rgba(0,0,0,.3)',x+5,8,1,FL-8);rc('rgba(0,0,0,.3)',x+11,8,1,FL-8);rc('rgba(224,164,88,.5)',x,8,16,2)})}
 [24,296].forEach((x,i)=>{const fl=.5+.5*Math.sin(t*9+i*2.1+Math.sin(t*3.3)*2),cc=q2?'255,70,90':'255,190,100';
  const h=g.createRadialGradient(x,48,1,x,48,34);h.addColorStop(0,'rgba('+cc+','+(.22+.1*fl)+')');h.addColorStop(1,'rgba('+cc+',0)');g.fillStyle=h;g.fillRect(x-36,12,72,72);
  rc('#4a2a1e',x-2,56,4,8);rc('#e0a458',x-4,54,8,2);rc('#e0a458',x-1,50,2,4);rc(q2?'#ff8090':'#ffd890',x-1,46-Math.round(fl),2,4+Math.round(fl));rc('#fff4d0',x,47,1,2)})}
function detAmb(q){if(rm===21)return;
 if(rm>=14){const f=g.createLinearGradient(0,FL-14,0,FL+10);f.addColorStop(0,'rgba(160,140,190,0)');f.addColorStop(1,'rgba(160,140,190,.10)');g.fillStyle=f;g.fillRect(0,FL-14,320,24);rc('rgba(200,190,220,.06)',(t*8)%360-40,FL+4,60,3);rc('rgba(200,190,220,.05)',320-((t*5)%360),FL+14,80,3)}
 if(rm===0)for(let j=0;j<8;j++){const y=36+((t*60+j*17)%56);rc('rgba(180,200,255,.5)',202+j*5.5,y,1,4)}
 if(rm===7)for(let j=0;j<5;j++){const p=((t*14+j*12)%50);rc('rgba(235,235,245,'+(.35-p/160)+')',250+Math.sin(t*2+j)*5+j,102-p,3+p/12,3+p/12)}
 if(rm===6)for(let j=0;j<6;j++){const x=60+j*40+Math.sin(t*.8+j)*10,y=FL-20-((t*7+j*21)%110);rc('rgba(200,215,255,.35)',x,y,4,3);rc('rgba(200,215,255,.2)',x+1,y+3,2,1)}
 if(rm===12){g.font='8px monospace';for(let j=0;j<3;j++){const p=((t*12+j*14)%42);g.fillStyle='rgba(232,214,192,'+(.55-p/80)+')';g.fillText(j%2?'♫':'♪',64+j*9+Math.sin(t+j)*3,FL-45-p)}}
 const n=rm===15?22:16;
 for(let i=0;i<n;i++){let x,y,c,s=1;
  if(rm===15){x=(i*37+Math.sin(t*1.2+i)*6+320)%320;y=FL+10-((t*18+i*29)%150);c='rgba(255,'+(90+i*5)+',40,'+Math.max(0,.5-((FL+10-y)/150)*.5)+')'}
  else if(rm===13){x=(i*41+t*6+Math.sin(t+i)*8)%320;y=((t*9+i*23)%160);c='rgba(240,240,255,.5)';s=2}
  else{x=(i*53.7+t*(3+i%4)+Math.sin(t*.7+i)*5)%320;y=(i*31.3+Math.sin(t*.5+i*2)*8+t*(1+i%3))%FL;c='rgba(255,220,160,'+(.12+.12*Math.sin(t*2+i))+')'}
  rc(c,x,y,s,s)}}
/* ============ detalhes extras: você, Rubi e Luna ============ */
function aura(k,x,y){const C={você:'224,164,88',rubi:'255,50,80',luna:'170,190,255',alvorada:'224,164,88',hera:'255,170,90',nina:'120,170,170',isis:'170,140,255',garcom:'230,230,230',corvo:'120,120,170',orfeu:'110,200,120',valerio:'150,190,220',senhora:'200,40,90'}[k];if(!C)return;const p=.5+.5*Math.sin(t*1.6);
 const h=g.createRadialGradient(x,y-33,4,x,y-33,38);h.addColorStop(0,'rgba('+C+','+(.10+.05*p)+')');h.addColorStop(1,'rgba('+C+',0)');g.fillStyle=h;g.fillRect(x-40,y-75,80,80)}
function det(k,i){const W=i.naturalWidth,H=i.naturalHeight,s=66/H,a=t;if(!{você:1,rubi:1,luna:1}[k]||(k==='você'&&V8.gs))return;
 g.save();g.scale(s,s);g.translate(-W/2,-H);
 const P=(c,x,y,w,h,al)=>{g.globalAlpha=al;g.fillStyle=c;g.fillRect(x,y,w,h)},pu=(f,o)=>.5+.5*Math.sin(a*f+(o||0));
 if(k==='você'){
  P('#9fd0ff',23,19,2,1,.25+.45*pu(2));P('#9fd0ff',30,19,2,1,.25+.45*pu(2,.4));
  const ix=Math.floor(a*3)%6;P('#ffffff',37,66+ix*3,1,1,.8);P('#c8d4e8',37,66+((ix+3)%6)*3,1,1,.5);
  P('#e0a458',20,73,2,3,.35+.4*pu(2.5));P('#e0a458',33,38,2,2,.35+.4*pu(1.5,1));P('#e0a458',34,40,1,5,.25);
  if(Math.sin(a*1.1)>.92)P('#ffffff',26,53,3,2,.8);
  const y=30+((a*16)%60);P('#c8d4e8',11,y,1,2,.4);P('#c8d4e8',42,y+4,1,2,.35);
 }
 if(k==='rubi'){
  P('#ff3050',33,29,2,2,.4+.6*pu(3));P('#ffd0d8',33,17,1,1,.5+.4*pu(2));P('#ffd0d8',41,17,1,1,.5+.4*pu(2,.5));
  P('#ff9aa8',30,10,2,2,.3+.5*pu(1.7,2));
  for(let j=0;j<5;j++)P('#ffb0b8',34,40+j*2,1,1,j%2===Math.floor(a*2)%2?.7:.15);
  P('#ffd0d8',25,103,2,1,.3+.5*pu(2.2));P('#ffd0d8',42,102,2,1,.3+.5*pu(2.2,1.3));
  for(let j=0;j<7;j++){const p=((a*9+j*16)%100),x=8+((j*11)%52)+Math.sin(a*1.3+j)*3;P(j%2?'#ff3050':'#ff8090',x,100-p,1,1,Math.max(0,.7-p/110))}
 }
 if(k==='luna'){
  P('#a8c8ff',26,17,2,1,.3+.4*pu(1.8));P('#a8c8ff',31,17,2,1,.3+.4*pu(1.8,.5));
  const bx=(a*14)%90-15;for(let y=8;y<110;y+=4){const x=Math.round(bx-y*.25+(y%8));if(x>8&&x<56)P('#ffffff',x,y,1,2,.35)}
  P('#e8e8ff',36,52,2,3,.3+.5*pu(2));P('#e8e8ff',31,33,2,1,.3+.4*pu(1.3,1));P('#b0a0ff',16,10,2,2,.3+.5*pu(1.1,2));
  for(let j=0;j<5;j++){const x=31+Math.cos(a*.6+j*1.3)*26,y=60+Math.sin(a*.5+j*2)*40,al=.25+.45*pu(1.5,j);P('#cfd8ff',x,y,2,2,al);if(j%2){P('#cfd8ff',x-2,y+.5,6,1,al*.5);P('#cfd8ff',x+.5,y-2,1,6,al*.5)}}
 }
 g.restore()}
/* ============ detalhes extras: som calmo e estranho ============ */
function estranho(){const M=A.createGain();M.gain.value=.8;M.connect(OUT);
 const dl=A.createDelay(2),fb=A.createGain(),dp=A.createBiquadFilter();dl.delayTime.value=.62;fb.gain.value=.52;dp.type='lowpass';dp.frequency.value=1400;dl.connect(dp);dp.connect(fb);fb.connect(dl);dp.connect(M);
 const pad=A.createGain();pad.gain.value=.7;const pl=A.createBiquadFilter();pl.type='lowpass';pl.frequency.value=700;pad.connect(pl);pl.connect(M);
 [146.8,148.1,220,223.1,293.7].forEach(f=>{const o=A.createOscillator(),og=A.createGain();o.type='sine';o.frequency.value=f;og.gain.value=.012;o.connect(og);og.connect(pad);o.start()});
 const l1=A.createOscillator(),l1g=A.createGain();l1.frequency.value=.07;l1g.gain.value=.5;l1.connect(l1g);l1g.connect(pad.gain);l1.start();
 const l2=A.createOscillator(),l2g=A.createGain();l2.frequency.value=.05;l2g.gain.value=300;l2.connect(l2g);l2g.connect(pl.frequency);l2.start();
 const nb=A.createBuffer(1,A.sampleRate*3,A.sampleRate),nd=nb.getChannelData(0);for(let i=0;i<nd.length;i++)nd[i]=Math.random()*2-1;
 const ns=A.createBufferSource(),nf=A.createBiquadFilter(),ng=A.createGain();ns.buffer=nb;ns.loop=true;nf.type='bandpass';nf.frequency.value=400;nf.Q.value=4;ng.gain.value=.02;ns.connect(nf);nf.connect(ng);ng.connect(M);ns.start();
 const l3=A.createOscillator(),l3g=A.createGain();l3.frequency.value=.04;l3g.gain.value=250;l3.connect(l3g);l3g.connect(nf.frequency);l3.start();
 function bell(){if(A.state==='running'&&on){const sc=rm>=14?[196,207.7,293.7,311.1,466.2,554.4]:[196,220,261.6,329.6,392,440,523.3,659.3];
   const f=sc[Math.floor(Math.random()*sc.length)]*(Math.random()<.25?.5:1),rev=Math.random()<.3,now=A.currentTime,top=rev?2:5;
   const o=A.createOscillator(),o2=A.createOscillator(),n=A.createGain(),n2=A.createGain(),dry=A.createGain();o.type='sine';o2.type='sine';o.frequency.setValueAtTime(f,now);o2.frequency.value=f*2.76;n2.gain.value=.25;dry.gain.value=.5;
   if(Math.random()<.3)o.frequency.exponentialRampToValueAtTime(f*.94,now+4);
   n.gain.setValueAtTime(0.0001,now);if(rev){n.gain.linearRampToValueAtTime(.05,now+1.8);n.gain.linearRampToValueAtTime(0.0001,now+2)}else{n.gain.linearRampToValueAtTime(.05,now+.02);n.gain.exponentialRampToValueAtTime(.0005,now+5)}
   o.connect(n);o2.connect(n2);n2.connect(n);n.connect(dl);n.connect(dry);dry.connect(M);o.start(now);o2.start(now);o.stop(now+top+.1);o2.stop(now+top+.1)}
  setTimeout(bell,5000+Math.random()*9000)}
 setTimeout(bell,3000)}
function marca(q){if(!q.p||!F.ch||!F.ch[q.p[0]])return;const a=F.ch[q.p[0]]==='a',x=q.p[1],y=FL-84+Math.round(Math.sin(t*2)*1.5),cc=a?'#e0a458':'#7fa8ff';
 rc(cc,x-1,y,2,2);rc(cc,x-2,y+1,1,1);rc(cc,x+1,y+1,1,1);rc(cc,x-1,y+2,2,1)}
var RV=0;function hora(){return new Date().toLocaleTimeString('pt-BR')}
function relogios(){if(rm!==16)return;const d=new Date(),sc=d.getSeconds()+d.getMilliseconds()/1000,mi=d.getMinutes()+sc/60,hr=(d.getHours()%12)+mi/60;
 const relo=(cx,cy,h,m,s)=>{g.fillStyle='#e8d6c0';g.beginPath();g.arc(cx,cy,9,0,7);g.fill();g.strokeStyle='#4a2a1e';g.lineWidth=1;g.stroke();
  for(let k=0;k<12;k++){const a=k*Math.PI/6;rc('#4a2a1e',cx+Math.sin(a)*7.2,cy-Math.cos(a)*7.2,1,1)}
  const ln=(a,l,c,w)=>{g.strokeStyle=c;g.lineWidth=w;g.beginPath();g.moveTo(cx,cy);g.lineTo(cx+Math.sin(a)*l,cy-Math.cos(a)*l);g.stroke()};
  ln(h/12*Math.PI*2,4.5,'#2a1a14',1.4);ln(m/60*Math.PI*2,6.5,'#2a1a14',1);ln(s/60*Math.PI*2,7,'#a0203f',.6)};
 relo(71,FL-33,12-((t*.05)%12),60-((t*3)%60),60-((t*30)%60));relo(231,FL-33,hr,mi,sc)}
/* ============ desenho ============ */
const rc=(c,x,y,w,h)=>{g.fillStyle=c;g.fillRect(Math.round(x),Math.round(y),w,h)};
const PELE={'Sr. Alvorada':'#e0b898','Dona Hera':'#e8c0a0','Nina':'#d8b898','Ísis':'#c89878','Corvo':'#d8c0a8','Orfeu':'#c89868','Dr. Valério':'#e0c0a8','A Senhora':'#eadcdc'};
function boneco(x,y,c){const m=Math.abs(Math.sin(t/5))*1,N=c.nome,pe=c.pele||PELE[N]||'#e8c4a0',ro=c.roupa||'#444',ca=c.cabelo||'#222',pisca=(t%4)<.12;
 g.save();g.translate(Math.round(x),y);g.scale(1.65,1.65);
 rc('#1a1018',-4,-12,3,12);rc('#1a1018',1,-12,3,12);rc('#0c080c',-5,-2,4,2);rc('#0c080c',1,-2,4,2);
 /* atrás do corpo */
 if(N==='Corvo'){rc(ro,-6,-14,4,8);rc(ro,2,-14,4,8)}
 if(N==='Orfeu'){rc('#6a4a2a',7,-38,1,36);rc('#aab4bc',6,-4,4,4);rc('#8a949c',6,-4,4,1)}
 if(N==='Dona Hera'){rc('#aaaaaa',7,-34-m,1,20);rc('#888888',6,-36-m,3,3)}
 /* tronco, braços, mãos, cinto, pescoço */
 rc(ro,-5,-28-m,10,17);rc(ro,-7,-27-m,2,13);rc(ro,5,-27-m,2,13);
 rc(pe,-7,-14-m,2,2);rc(pe,5,-14-m,2,2);rc('rgba(0,0,0,.25)',-5,-18-m,10,1);rc(pe,-1,-30-m,2,2);
 /* cabeça, cabelo, olhos, boca */
 rc(pe,-4,-37-m,8,9);rc(ca,-5,-39-m,10,4);rc(ca,-5,-37-m,1,4);rc(ca,4,-37-m,1,4);
 if(!pisca){rc('#111',-2,-33-m,1,1);rc('#111',1,-33-m,1,1)}
 if(N!=='O Garçom')rc('rgba(80,30,30,.7)',-1,-30-m,2,1);
 /* características de cada um */
 switch(N){
 case 'Sr. Alvorada':
  rc('#1a2440',-5,-44-m,10,5);rc('#0c1224',-6,-39-m,12,1);rc('#e0a458',-5,-40-m,10,1);rc('#e0a458',-1,-43-m,2,2);
  rc('#cfcfcf',-3,-31-m,6,1);rc('#e0a458',-1,-26-m,1,1);rc('#e0a458',-1,-22-m,1,1);rc('#e0a458',-6,-28-m,3,1);rc('#e0a458',3,-28-m,3,1);
  rc('#f0f0f0',-7,-14-m,2,2);rc('#f0f0f0',5,-14-m,2,2);rc('#e0a458',-4,-23-m,5,1);rc('#e0a458',-4,-22-m,1,1);break;
 case 'Dona Hera':
  rc('#e8e0d0',-4,-25-m,8,13);rc('#c8c0b0',-4,-25-m,8,1);rc('#a0402f',-2,-20-m,1,1);rc('#a0402f',1,-17-m,1,1);
  rc(ca,-3,-43-m,6,4);rc('rgba(220,90,90,.55)',-4,-31-m,2,1);rc('rgba(220,90,90,.55)',2,-31-m,2,1);
  rc('#c8d4e8',-3,-34-m,3,1);rc('#c8d4e8',0,-34-m,3,1);rc('#c8d4e8',-3,-32-m,3,1);rc('#c8d4e8',0,-32-m,3,1);break;
 case 'Nina':
  rc('#e8e8e8',-5,-41-m,10,3);rc('#c8c8d0',-5,-39-m,10,1);rc('#e8e8e8',-3,-28-m,6,2);rc('#e8e8e8',-3,-24-m,6,12);
  rc(ca,4,-36-m,2,8);rc('rgba(70,40,90,.6)',-3,-32-m,2,1);rc('rgba(70,40,90,.6)',1,-32-m,2,1);
  rc('#e8e8f0',-9,-24-m,3,7);rc('#c0c0d0',-9,-18-m,3,1);rc('#e0a458',3,-17-m,1,1);rc('#e0a458',4,-16-m,2,2);break;
 case 'Ísis':
  rc(ca,-6,-37-m,2,22);rc(ca,4,-37-m,2,22);rc('#e0a458',-3,-40-m,6,1);rc('#e8e8ff',-1,-41-m,2,2);rc('#b0a0ff',0,-37-m,1,1);
  rc('#e8e0ff',-3,-24-m,1,1);rc('#e8e0ff',2,-21-m,1,1);rc('#e8e0ff',-2,-16-m,1,1);rc('#b0a0ff',3,-26-m,1,1);
  rc('#e8d6c0',-10,-22-m,5,6);rc('#8a6a4a',-10,-22-m,1,6);rc('#8a6a4a',-8,-20-m,3,1);
  rc('rgba(176,160,255,.8)',Math.round(Math.cos(t*1.5)*11),Math.round(-46-m+Math.sin(t*1.5)*3),2,2);break;
 case 'O Garçom':
  rc('#e8e8e8',-3,-28-m,6,10);rc('#111',-5,-28-m,3,17);rc('#111',2,-28-m,3,17);rc('#a0203f',-2,-28-m,4,1);
  rc('#e8e8e8',-2,-33-m,1,1);rc('#e8e8e8',1,-33-m,1,1);
  rc(ro,-8,-36-m,2,10);rc('#e8e8e8',-8,-37-m,2,1);rc('#c8d4e8',-13,-38-m,11,1);rc('#c8d4e8',-11,-41-m,7,3);rc('#ffffff',-10,-41-m,2,1);rc('#c8d4e8',-8,-43-m,2,2);
  rc('#e8e8e8',6,-22-m,3,6);rc('#f0f0f0',5,-14-m,2,2);break;
 case 'Corvo':
  rc(ca,-6,-41-m,2,3);rc(ca,-3,-42-m,2,4);rc(ca,0,-43-m,2,5);rc(ca,3,-41-m,2,3);
  rc('#e0b070',4,-32-m,3,2);rc('#c89050',6,-31-m,2,1);rc('#e0a458',1,-33-m,1,1);
  rc('#2a2a36',-6,-29-m,12,2);rc('#1a1a22',-5,-27-m,2,1);rc('#1a1a22',-1,-27-m,2,1);rc('#1a1a22',3,-27-m,2,1);
  rc('#e8e8e8',-1,-26-m,2,10);rc('#d8c0a8',-8,-14-m,1,3);rc('#d8c0a8',7,-14-m,1,3);break;
 case 'Orfeu':
  rc('#c8a860',-8,-40-m,16,2);rc('#c8a860',-4,-44-m,8,5);rc('#2a4a2a',-4,-41-m,8,1);rc('#e8e8f0',3,-43-m,2,2);
  rc(ca,-4,-30-m,8,3);rc(ca,-3,-27-m,6,1);rc('#3a8a3a',-7,-29-m,3,2);rc('#3a8a3a',4,-29-m,3,2);rc('#5ab05a',-6,-30-m,1,1);
  rc('#3a2a1a',-4,-9,3,2);rc('#3a2a1a',1,-9,3,2);rc('#5a4a2a',-3,-28-m,1,10);rc('#5a4a2a',2,-28-m,1,10);break;
 case 'Dr. Valério':
  rc('#d8d8d0',-6,-28-m,12,20);rc('#b8b8b0',-1,-28-m,1,20);rc('#4a6a8a',-1,-27-m,2,7);rc('#e8e8e8',-2,-27-m,1,6);rc('#e8e8e8',1,-27-m,1,6);
  rc('#222222',-3,-28-m,1,6);rc('#222222',2,-28-m,1,6);rc('#aab4bc',-1,-22-m,2,2);
  rc('#c8d4e8',-4,-34-m,3,1);rc('#c8d4e8',-4,-32-m,3,1);rc('#c8d4e8',1,-34-m,3,1);rc('#c8d4e8',1,-32-m,3,1);rc('#c8d4e8',-1,-33-m,2,1);
  rc('#777777',-3,-40-m,3,1);rc('#a0703a',-11,-22-m,6,8);rc('#e8e8e8',-10,-21-m,4,6);rc('#555555',-9,-19-m,2,1);rc('#555555',-9,-17-m,2,1);rc('#2a4a8a',3,-24-m,1,3);break;
 case 'A Senhora':{const p=.5+.5*Math.sin(t*3);
  rc(ro,-7,-20-m,14,19);rc(ro,-9,-8,18,7);rc('#e0a458',-9,-1,18,1);
  rc(ca,-5,-43-m,10,5);rc(ca,-3,-47-m,6,4);rc('#ff3050',3,-44-m,1,1);rc('#e0a458',-4,-42-m,1,2);
  [-3,-1,1,3].forEach(i=>rc('#f0f0f0',i,-27-m,1,1));rc('rgba(168,216,255,'+(.5+.5*p)+')',0,-24-m,1,2);
  rc('#a0203f',-1,-30-m,2,1);rc('#a0203f',7,-27-m,6,4);rc('#e0a458',7,-27-m,6,1);rc('#601020',9,-27-m,1,4);
  rc('#111111',-7,-14-m,2,2);rc('#111111',5,-14-m,2,2);break}
 }
 g.restore()}
function spr(k,x,y,mv,d,f,c){const i=IM[k];g.fillStyle='rgba(0,0,0,.45)';g.beginPath();g.ellipse(x,y,12,3,0,0,7);g.fill();if(!f)aura(k,x,y);
 if(!i||!i.complete||!i.naturalHeight)return boneco(x,y,c||{});
 const h=66,w=i.naturalWidth/i.naturalHeight*h,b=mv?Math.abs(Math.sin(t/5))*1.5:Math.sin(t/30)*.5;
 g.save();g.translate(Math.round(x),y-b);if(d<0)g.scale(-1,1);if(mv)g.rotate(Math.sin(t/5)*.03);if(f)g.filter=f;g.drawImage(i,-w/2,-h,w,h);if(!f)det(k,i);g.restore()}
function frame(){if(!on){lpf=0;return}t+=.016;g.setTransform(2,0,0,2,0,0);g.imageSmoothingEnabled=false;const q=R[rm];
 if(vivo&&rm>=16)g.translate((Math.random()-.5)*(rm>=20?3:1),0);
 rc(q.c,0,0,320,FL);for(let x=0;x<320;x+=10)rc('rgba(255,255,255,.03)',x,0,4,FL);rc('rgba(0,0,0,.25)',0,FL-6,320,6);rc(q.f||'#1c1016',0,FL,320,34);amb(q);
 q.o.forEach(o=>{const k=K[o[1]];rc(k[2],o[0],FL-k[4]-k[1],k[0],k[1]);rc(k[3],o[0],FL-k[4]-k[1],k[0],2);rc(k[3],o[0]+k[0]/2-2,FL-k[4]-k[1]/2-2,4,4)});
 relogios();if(q.p){const c=NPC[q.p[0]];spr(c.png||q.p[0],q.p[1],FL+16,0,1,c.filtro,c);marca(q)}
 if(vivo){if(!busy){const a=(keys.L?-1:0)+(keys.R?1:0);if(a){px+=a*1.6;dir=a}
   if(px<10){if(q.l!=null)move(q.l,'l');else px=10}if(px>310){if(q.r!=null)move(q.r,'r');else px=310}}
  spr('você',px,FL+18,keys.L||keys.R,dir,null,{roupa:'#15121a',cabelo:'#0e0c12'});
  if(!busy&&near()){g.fillStyle='#e0a458';const y=FL-80+Math.round(Math.sin(t*6));g.fillRect(Math.round(px)-1,y,3,5);g.fillRect(Math.round(px)-1,y+7,3,2)}}
 detAmb(q);if(RV&&busy){const x=RV.replace('{hora}',hora());if($('dt').textContent!==x)$('dt').textContent=x}const gr=g.createRadialGradient(160,FL-40,2,160,FL-40,130);gr.addColorStop(0,'rgba(255,170,80,.2)');gr.addColorStop(1,'rgba(255,170,80,0)');g.fillStyle=gr;g.fillRect(0,0,320,180);
 const v=g.createRadialGradient(160,90,70,160,90,210);v.addColorStop(0,'rgba(0,0,0,0)');v.addColorStop(1,'rgba(0,0,0,'+(rm>=14?.8:.6)+')');g.fillStyle=v;g.fillRect(0,0,320,180);
 if(vivo&&rm>=15&&Math.random()<.05)rc('rgba(255,0,60,.15)',0,Math.random()*180,320,3);
 if(vivo){g.fillStyle='#000a';g.fillRect(3,3,150,12);g.fillStyle='#e0a458';g.font='7px monospace';g.fillText(q.n+'  ◆'+F.fr+'/11',6,12)}
 requestAnimationFrame(frame)}
/* ============ som ambiente (o mesmo de sempre) ============ */
function audio(){if(A)return;A=V8.ctx();if(!A)return;OUT=A.createGain();OUT.connect(A.destination);if(A.state==="suspended")A.resume();try{estranho()}catch(e){}
 const lp=A.createBiquadFilter();lp.type='lowpass';lp.frequency.value=500;lp.connect(OUT);
 [55,82.4,110,130.8].forEach(f=>{const o=A.createOscillator(),n=A.createGain();o.type='sine';o.frequency.value=f;n.gain.value=.05;o.connect(n);n.connect(lp);o.start()});
 const b=A.createBuffer(1,A.sampleRate*2,A.sampleRate),d=b.getChannelData(0);for(let i=0;i<d.length;i++)d[i]=Math.random()*2-1;
 const s=A.createBufferSource(),bp=A.createBiquadFilter(),n=A.createGain();s.buffer=b;s.loop=true;bp.type='bandpass';bp.frequency.value=2500;n.gain.value=.025;s.connect(bp);bp.connect(n);n.connect(OUT);s.start();
 const sc=[261.6,311.1,392,466.2,392,311.1,233,293.7];let k=0;
 setInterval(()=>{if(!on||!F.rec||rm!==0||A.state!=='running')return;const o=A.createOscillator(),n=A.createGain();o.type='triangle';o.frequency.value=sc[k++%8];n.gain.setValueAtTime(.06,A.currentTime);n.gain.exponentialRampToValueAtTime(.001,A.currentTime+.4);o.connect(n);n.connect(OUT);o.start();o.stop(A.currentTime+.45)},420)}
/* ============ início e controles ============ */
function start(c){audio();const d=c?load():null;F=d?d.F:{fr:0,acc:0,neg:0,met:{},frs:[],rec:0,ch:{}};F.ch=F.ch||{};rm=d?d.rm:0;px=d?d.px:100;vivo=1;busy=0;on=1;document.documentElement.classList.remove('p2');$('ti').hidden=1;
 seq([['Você','Acordo na suíte 12. Chove. Lembro de uma hora a menos na minha noite.'],['Você','Ande pelo hotel para resgatar oque foi perdido.']])}
F={fr:0,acc:0,neg:0,met:{},frs:[],rec:0,ch:{}};
function enter(){if(busy&&$('dlg').onclick)$('dlg').onclick();else act()}
function stop(){vivo=0;on=0;try{OUT.gain.setTargetAtTime(0,A.currentTime,.8)}catch(e){}}
function run(){on=1;if(!lpf){lpf=1;frame()}}
run();return{start,act,book,enter,stop};

})();
const P2=(function(){
/* ===== PARTE 2: Castelo Ailton's ===== */
const V8IMG6={stella:"assets/img_15.png",ruby:"assets/img_16.png"};
const ALI_PNG="assets/img_17.png";
const YM_PNG="assets/img_18.png",HO_PNG="assets/img_19.png";const MASKI=new Image();MASKI.src="assets/img_20.png";
const SRC={alinny:ALI_PNG,yurimask:YM_PNG,honorio:HO_PNG,você:V8IMG.você,naty:V8IMG2.naty,guifer:V8IMG2.guifer,debora:V8IMG2.debora,yuri:V8IMG3.yuri,lara:V8IMG4.lara,marcela:V8IMG4.marcela,fernando:V8IMG4.fernando,erick:V8IMG5.erick,melina:V8IMG5.melina,stella:V8IMG6.stella,ruby:V8IMG6.ruby};
const IM={};for(const k in SRC){const i=new Image();i.src=SRC[k];IM[k]=i}V8.IM2=IM;
const ESI=new Image();ESI.src="assets/img_21.png";
const HH={você:66,naty:60,guifer:68,debora:66,yuri:66,lara:66,marcela:66,fernando:48,erick:66,melina:66,stella:66,ruby:66};
const $=i=>document.getElementById(i),g=document.getElementById('c').getContext('2d',{willReadFrequently:true}),FL=146;
let rm=0,px=70,dir=1,busy=0,keys=KEYS,t=0,vivo=0,A=null,RV=0,rapido=0,on=0,lpf=0,MU=0,F={met:{},ch:{},frs:[],fim:0};
const W={mesalonga:200,colher:18,fogao:44,camarosa:70,penteadeira:34,luzinhas:56,ursinho:24,faixabr:70,camisas:60,trofeu:22,saco:20,mesadesenho:60,varal:70,pigmento:24,tenis:50,espelho:26,cha:44,sino:16,vinil:36,fone:20,molduras:64,cavalete:34,prat:56,berco:44,portao:56,fonte:40,lanterna:8,lareira:48,mesa:72,estandarte:24,retrato:30,relogiog:30,carta:18,portal:38,portaltopo:38,escada:110,tatame:70,pergaminho:24,cristal:24,tv:50,sofa:60,neon:44,gol:56,bola:10,caca:36,fotos:44,vaso:22,escrivaninha:56,notas:30,livros:22,mapa:60,globo:24,mala:30,cadeira:22,lampada:10,relogioreverso:46,ampulheta:16,mural:64,monitor:34,altarcruz:44,banco:56,porta:38,item:14};
const R=[
{n:'Pátio do Castelo',sky:1,f:'#3a3550',r:1,o:[[30,'portao','Um portão imenso, você chegou.'],[100,'fonte','A água canta baixo e reflete um céu que ainda não decidiu se é tarde ou noite.'],[262,'lanterna','Uma lanterna acesa antes da hora, como quem espera visita.']],p:['naty',185]},
{n:'Grande Salão',c:'#3b3556',f:'#2a2236',l:0,r:2,win:[70,200],tor:[130,296],o:[[12,'lareira','O fogo estala baixinho e parece acompanhar a música.'],[88,'mesa','Uma mesa comprida, posta para a família. Ainda há muitos lugares vazios.'],[262,'estandarte',"Estandarte azul com um A bordado em ouro. Ailton's, em letras miúdas."]],p:['guifer',200]},
{n:'Galeria dos Retratos',c:'#2d3b57',f:'#1f2636',l:1,r:3,win:[150],tor:[24,296],o:[[44,'retrato','','naty'],[104,'retrato','','guifer'],[188,'retrato','','debora'],[246,'retrato','','yuri']],p:['debora',150]},
{n:'Torre do Relógio',c:'#3a3354',f:'#261f36',l:2,win:[226],tor:[40],o:[[84,'relogiog','Este relógio não gira para trás. Marca a hora exata em que estou lendo isto: {hora}.'],[150,'carta','Uma carta lacrada com um A dourado. Só será aberta quando a família estiver completa.'],[262,'portal','']]},
{n:'Escadaria da Torre',c:'#322d4e',f:'#241d34',l:3,win:[150],tor:[24,244],o:[[30,'escada','Degraus de pedra gastos, subindo em curva. Lá em cima, alguém espera de mão no bolso.'],[262,'portaltopo','']],p:['yuri',190]},
{n:'Sala do Lazuli',c:'#26407a',f:'#1c2c58',gate:1,l:4,r:6,tor:[24,296],o:[[24,'mesadesenho','Uma mesa de desenho coberta de rascunhos, lápis gastos e borracha em migalhas.'],[116,'pergaminho','Um desenho emoldurado, com uma palavra só escrita embaixo: Sensei.'],[262,'pigmento','Um pote de pigmento azul-escuro, lazuli, que brilha baixinho.']],p:['lara',190]},
{n:'Quarto do Fernando',c:'#2a2440',f:'#1a1628',gate:1,l:5,r:7,o:[[16,'tv','A TV está ligada num jogo de mundo aberto, e o controle continua no sofá.'],[90,'sofa','Um sofá afundado no formato de quem joga por horas seguidas.'],[260,'neon','Um letreiro de neon rosa pisca: PROVISO.']],p:['fernando',200]},
{n:'Campo do Erick',c:'#2c4a3e',f:'#24593a',gate:1,l:6,r:8,o:[[14,'gol','Uma trave de gol meio torta, com a rede remendada.'],[100,'bola','Uma bola de futebol esquecida no meio do campo.'],[266,'caca','Uma máquina de caça-níquel piscando, com um tigrinho na tela. Melhor não chegar perto.']],p:['erick',190]},
{n:'Sala da Marcela',c:'#4a2a4a',f:'#2e1a30',gate:1,l:7,r:9,tor:[24],o:[[20,'fotos','Um mural de fotos de amigos: todos sorrindo, todos juntos.'],[70,'sofa','Um sofá largo, com lugar para todo mundo.'],[272,'vaso','Uma planta bem cuidada. Alguém rega todo dia.']],p:['marcela',200]},
{n:'Quarto da Alinny',c:'#2a2c58',f:'#1c1e3c',gate:1,l:8,r:10,o:[[20,'escrivaninha','Livros empilhados e um caderno cheio de anotações. A lâmpada nunca apaga.'],[110,'notas','Notas musicais flutuam no ar, vindas de lugar nenhum.'],[160,'porta',19,'Uma porta que eu não tinha visto. Cheiro de papel velho e de terra molhada.'],[264,'livros','Uma pilha de livros quase tão alta quanto eu.']],p:['alinny',190]},
{n:'Sala Azul I',c:'#1f4a9a',f:'#16306a',flat:1,l:9,r:11,msg:"Você não deve tá entendendo qual a relação do começo do jogo com a família não é?",auto:"....",o:[]},
{n:'Sala Azul II',c:'#1f4a9a',f:'#16306a',flat:1,l:10,r:12,msg:"Eles se perderam no tempo...já não existem mais os mesmos sorrisos de antes e nem mesmo a conexão de segunda a sexta..",auto:"....",o:[]},
{n:'Sala Azul III',c:'#1f4a9a',f:'#16306a',flat:1,l:11,r:13,msg:"Já não sentimos mais o mesmo prazer de fazer rimas na arquibancada, e nem mesmo existem os membros para fazer piadas..",auto:"....",o:[]},
{n:'Sala Azul IV',c:'#1f4a9a',f:'#16306a',flat:1,l:12,r:14,msg:"A realidade? É que o tempo não se esgotou, ele apenas tomou conta da nossa vida e fez a gente se separar, o que mantinha eles juntos? O mesmo que os fez se separar; o tempo.",auto:"....",o:[]},
{n:'Sala dos Mapas',c:'#3a3050',f:'#251c38',gate:1,l:13,r:15,o:[[20,'mapa','Um mapa-múndi com um alfinete cravado bem longe daqui.'],[100,'globo','Um globo que gira devagar, sozinho.'],[270,'mala','Uma mala antiga, com etiquetas de aeroportos.']],p:['melina',190]},
{n:'Sala Silenciosa',c:'#2c2c38',f:'#1e1e28',gate:1,l:14,r:16,o:[[110,'cadeira','Uma cadeira solitária. Aqui ninguém pede explicações.'],[250,'lampada','Uma lâmpada nua, acesa, balançando de leve.']],p:['thunine',190]},
{n:'Sala do Relógio Reverso',c:'#40283a',f:'#2a1a28',gate:1,l:15,r:17,o:[[20,'relogioreverso','Um relógio enorme. Os ponteiros giram para trás, insistentes.'],[272,'ampulheta','Uma ampulheta com a areia subindo, grão a grão.']],p:['ruby',180]},
{n:'Sala de Investigação',c:'#1e3a40',f:'#142830',gate:1,l:16,r:18,o:[[14,'mural','Um mural cheio de fotos ligadas por fios vermelhos. No centro, o rosto de alguém foi riscado.'],[100,'monitor','Um monitor mostra a palavra REC, e uma luz vermelha pisca no canto.']],p:['stella',200]},
{n:'Capela do Castelo',c:'#2e2040',f:'#201530',l:17,win:[210],o:[[50,'altarcruz','Um altar simples, com velas acesas e uma cruz.'],[112,'banco','Um banco de madeira escura, gasto por muitas orações.'],[262,'portaltopo','']],p:['padre',186]},
{n:'Biblioteca Esquecida',c:'#3a2c3c',f:'#241a28',gate:0,l:9,r:20,tor:[24,296],o:[[16,'livros','Livros empilhados no chão, todos com o mesmo cheiro de tarde de chuva.'],[70,'item','Entre dois livros, um controle de videogame cheio de adesivos. Só pode ser do Fernando.','controle','Controle do Fernando'],[150,'escrivaninha','Uma escrivaninha com bilhetes antigos: horários de treino, de jogo, de aula. Todos riscados.'],[228,'item','Um diário aberto: \"Segunda a sexta a gente se via todo dia. Eu não sabia que isso era raro.\"','m_bib','Biblioteca: o diário diz que ver todo mundo todo dia era raro, e ninguém percebia.'],[274,'lampada','Uma lâmpada que ilumina só um canto, como se esperasse alguém ler.']]},
{n:'Jardim dos Irmãos',c:'#1f3a30',f:'#1a2e22',l:19,r:21,win:[150],o:[[18,'vaso','Flores de todas as cores, regadas por alguém que nunca aparece.'],[84,'fonte','A fonte tem moedas no fundo. Cada uma com um desejo: \"que todo mundo volte\".'],[158,'item','Preso entre as folhas de um galho, um pincel fino de cabo azul, ainda com tinta fresca.','faixa','Pincel azul da Lara'],[200,'item','Num banco, iniciais riscadas: todas as letras do grupo, dentro de um coração torto.','m_jar','Jardim: um banco com as iniciais de todo mundo, dentro de um coração torto.'],[236,'item','Uma chave pesada, enferrujada, escondida entre as flores.','chavepor','Chave do porão'],[284,'lanterna','Uma lanterna que acende sozinha quando alguém se aproxima.']]},
{n:'Cozinha da Família',c:'#4a3426',f:'#2e2018',l:20,r:22,o:[[12,'lareira','Uma panela esquecida no fogo baixo. Cheiro de pão quente, o mesmo do pátio.'],[90,'mesa','Uma mesa de madeira com pratos pela metade, como se todos tivessem levantado de uma vez.'],[190,'item','Em cima do balcão, uma mamadeira ainda morna. Deve ser a da Marcela.','mamadeira','Mamadeira'],[240,'item','Um caderno de receitas: \"o segredo é cozinhar para muita gente, mesmo que venha pouca\".','m_coz','Cozinha: a receita da família diz para cozinhar para muita gente, mesmo que venha pouca.']]},
{n:'Porão das Lembranças',c:'#201a26',f:'#15111b',lock:'chavepor',lm:'A porta do porão está trancada. Preciso de uma chave pesada.',l:21,r:23,qg:1,tor:[24],o:[[30,'cadeira','Uma cadeira de frente para a parede, como alguém que veio pensar e ficou.'],[84,'item','Atrás de uma caixa, um par de luvas de goleiro bem gastas. Do Erick, sem dúvida.','luvas','Luvas de goleiro'],[160,'mala','Uma mala cheia de camisas de times, jogos e bilhetes. Todos guardados de propósito.'],[250,'item','Uma foto antiga do grupo inteiro, rindo de alguma coisa que ninguém lembra mais.','m_por','Porão: uma foto do grupo inteiro rindo, de uma piada que ninguém lembra mais.']]}];
R.push(
{n:'Quarto da Melina',c:'#f2b6d0',f:'#d98aad',flat:1,l:22,r:24,o:[[8,'camarosa',"Uma cama com dossel rosa, lençóis macios e travesseiros em formato de coração."],[92,'penteadeira',"Uma penteadeira branca com espelho, laços, perfumes e um porta-retrato de infância."],[134,'luzinhas',"Luzinhas rosa e douradas piscam no teto, como vagalumes de mentirinha."],[262,'ursinho',"Um ursinho de pelúcia com laço rosa e um balão flutuando. O Sr. Algodão, imagino."]],p:['melina',200]},
{n:'Quarto do Yuri',c:'#27624a',f:'#1c4a34',flat:1,l:23,r:25,o:[[8,'faixabr',"Uma faixa gigante da seleção brasileira, verde e amarela."],[84,'camisas',"Camisas de várias Copas penduradas na parede, cada uma com sua sorte."],[240,'trofeu',"Uma taça dourada na vitrine. Segundo lugar, mas com orgulho."],[270,'bola',"Uma bola de futebol aos pés da cama, sempre pronta."]],p:['yuri',190]},
{n:'Quarto da Lara',c:'#26407a',f:'#3b2f55',flat:1,l:24,r:26,o:[[10,'mesadesenho',"A mesa de desenho da Lara, com um desenho começado e o lápis ainda quente."],[78,'varal',"Um varal de rascunhos presos com pregadores, balançando de leve."],[156,'pergaminho',"Um desenho emoldurado com uma palavra só embaixo: Sensei."],[262,'pigmento',"O pigmento lazuli brilha baixinho no pedestal."]],p:['lara',190]},
{n:'Quarto do Guifer',c:'#3a3a48',f:'#2a2a36',flat:1,l:25,r:27,o:[[8,'tenis',"Uma prateleira de tênis brancos, alinhados e limpinhos."],[80,'espelho',"Um espelho dourado de corpo inteiro. Dá para ver o topete rebelde."],[258,'tenis',"Mais tênis, agora com solas coloridas. A coleção não acaba."]],p:['guifer',190]},
{n:'Quarto da Naty',c:'#d8c4a0',f:'#a88a6a',flat:1,l:26,r:28,o:[[8,'cha',"Uma mesinha de chá com bule, xícaras e um vapor perfumado."],[66,'sino',"Um sino dourado de recepção. Cada toque é um abraço."],[110,'lanterna',"Uma lanterna acesa antes da hora, como no pátio."],[264,'vaso',"Um vaso de flores frescas, escolhidas para quem chega."]],p:['naty',190]},
{n:'Quarto Noturno da Alinny',c:'#2e2a5a',f:'#1c1a3e',l:27,r:29,o:[[10,'escrivaninha',"Escrivaninha cheia de cadernos, com a lâmpada que nunca apaga."],[86,'vinil',"Uma vitrola girando um disco sem nome."],[130,'fone',"Fones roxos pendurados, esperando o próximo capítulo."],[262,'livros',"Livros de estudo empilhados, com marcadores coloridos."]],p:['alinny',190]},
{n:'Quarto da Débora',c:'#1a1620',f:'#100c14',flat:1,l:28,r:30,o:[[8,'molduras',"Molduras douradas, cada uma com um rosto da família."],[84,'cavalete',"Um cavalete com uma tela ainda úmida de tinta."],[258,'espelho',"Um espelho para ver o quadro de longe."]],p:['debora',190]},
{n:'Quarto do Proviso',c:'#2a2440',f:'#1a1628',l:29,r:31,o:[[8,'tv',"A TV mostra um mundo aberto pausado. O controle azul está no braço do sofá."],[70,'sofa',"O sofá guarda o formato exato do Proviso."],[138,'prat',"Uma prateleira cheia de controles de todas as cores."],[262,'neon',"O neon rosa pisca: PROVISO."]],p:['fernando',200]},
{n:'Quarto do Erick',c:'#2c4a3e',f:'#24593a',l:30,r:32,o:[[10,'gol',"Uma trave de verdade dentro do quarto, com rede nova."],[80,'bola',"A bola oficial, guardada como relíquia."],[100,'trofeu',"Um troféu de 19 pontos. Ninguém acreditava, mas está aqui."],[262,'caca',"A máquina do tigrinho, como lembrete de que a casa sempre ganha."]],p:['erick',190]},
{n:'Quarto da Marcela',c:'#4a2a4a',f:'#2e1a30',l:31,r:33,cg:1,o:[[8,'fotos',"Um mural enorme de fotos de todos juntos."],[60,'sofa',"Um sofá largo, com lugar para todo mundo."],[132,'berco',"Um bercinho com móbile de estrelas. O bebê dorme tranquilo."],[270,'vaso',"A plantinha que alguém rega todo dia, ao som de música."]],p:['marcela',200]});
R.push(
{n:'Quintal do Castelo',sky:1,f:'#3a5a3a',l:32,r:34,o:[[14,'colher',"Um canteiro de hortelã, cheirosa e fresquinha.",'hortela','#3aa04a'],[64,'colher',"Tomates vermelhos, quase caindo do pé.",'tomate','#e03030'],[114,'colher',"Cenouras alaranjadas espiando da terra.",'cenoura','#f08a2a'],[164,'colher',"Manjericão de folhas largas e brilhantes.",'manjericao','#2a7a3a'],[222,'fonte',"Uma fonte pequena que rega o quintal sozinha."],[274,'lanterna',"Uma lanterna acesa, mesmo de dia."]]},
{n:'Cozinha do Jardim',c:'#5a3e2a',f:'#3a281c',l:33,tor:[24,296],o:[[12,'fogao',"Um fogão de pedra com uma panela grande, pronto para cozinhar para a família toda."],[100,'mesalonga',"Uma mesa comprida, com um lugar para cada pessoa da família."]]});
/* ===== MANHÃ: despertador 7:00 AM e a frente da escola ===== */
const ESR=R.push({n:'Frente da Escola',esc:1,o:[[146,'escola','']]})-1;W.escola=40;
const ES={h:[],lx:0,mv:0,auto:0,alvo:0,cb:null,go:0,ent:[],run:0,ord:['naty','guifer','debora','yuri','lara','fernando','erick','marcela','alinny']},ESY=168,SX=166,LAG=10;
const esp=ms=>new Promise(r=>setTimeout(r,ms));
/* ===== CORREDOR PRINCIPAL e SALA 1 ===== */
const CORI=new Image();CORI.src="assets/img_22.png";
const COR=R.push({n:'Corredor Principal',cor:1,o:[[10,'sala1'],[67,'salaX','A porta da Sala 2 está trancada. Hoje todo mundo está na Sala 1.'],[117,'salaX','A Sala 3 está escura e silenciosa.'],[162,'escadaC','A escada leva ao andar de cima. A porta lá no alto está fechada por enquanto.'],[227,'salaX','A Sala 4 está trancada.'],[278,'salaX','A Sala 5 está trancada.']]})-1;
const S1=R.push({n:'Sala 1',sala:1,o:[[6,'saida'],...ES.ord.map((k,i)=>[39+i*30,'aluno',k])]})-1;
W.sala1=44;W.salaX=26;W.escadaC=46;W.aluno=18;W.saida=26;
const NMS={"naty": "Naty", "guifer": "Guifer", "debora": "Débora", "yuri": "Yuri", "lara": "Lara", "fernando": "Fernando", "erick": "Erick", "marcela": "Marcela", "alinny": "Alinny"};
const JK={"naty": [["guifer", "Guifer, na fila da escola o lanche foi a única coisa que você conferiu. Prioridades, hein?", "O resto eu confio em você, Naty, ksks."], ["debora", "Débora conferiu mochila, caderno e lanche. Só faltou conferir se a gente queria ser conferido.", "Cuidar dá trabalho, tá?"], ["yuri", "Yuri, na escada você chegou a tempo do gol ou a gente teve que te esperar?", "Cheguei no tempo certo, tá."], ["lara", "Lara, o professor já disse bom dia e você ainda está no bom oia, perai.", "Perai... ata, bom dia!"], ["fernando", "Fernando, hoje eu apresento a família e deixo o título de mais pika para você. Só hoje.", "Tchooo! Registrado!"]], "guifer": [["naty", "Naty apresentou a família no castelo e agora apresenta a sala. Qual vai ser, a escola inteira?", "Se precisar, eu apresento."], ["debora", "Débora, o sinal bateu e você ainda estava conferindo a mochila, ksks.", "Alguém tinha que conferir."], ["yuri", "Yuri, mão no bolso em sala de aula? O professor vai achar que você está escondendo cola.", "É só pose de tranquilo, ksks."], ["fernando", "Fernando, se o GTA 6 saísse hoje, você ainda vinha para a aula?", "Vinha, mas culpava o Red Dead."], ["marcela", "Marcela é a amiga leal, mas me emprestou o lápis e nunca devolveu.", "Lealdade tem limites, Guifer."]], "debora": [["guifer", "Guifer descreve o tênis branco com tanto carinho que ele merecia uma moldura.", "Ele merece, está limpinho!"], ["naty", "Naty, se você apresentar a Sala 1 como apresentou o castelo, a gente fica até o sinal.", "É para ficar completo."], ["yuri", "Yuri, a camisa da seleção dá sorte na prova ou só no jogo?", "Na prova eu dependo do estudo, ksks."], ["lara", "Lara desenha tão bem que o caderno dela virou a minha próxima moldura.", "O Sensei aprovaria!"], ["erick", "Erick, o apelido 19 pontos vale nota na prova de matemática?", "Se valer, eu passo."]], "yuri": [["naty", "Naty, a fila foi na frente e a gente seguiu. Na escola vale a regra da escada também?", "Vale. A escada é minha."], ["guifer", "Guifer, o topete que nunca obedece o pente também desobedece o professor?", "Ele é rebelde, ksks."], ["erick", "Erick, o 19 pontos aqui: se não pegar o apagador, é pênalti!", "Eu pego tudo, calma."], ["fernando", "Fernando, se a prova fosse de GTA você tirava dez e ainda cobrava bônus.", "Cobrava mesmo!"], ["alinny", "Alinny, a única que estudou até com os fones no ouvido. Dá uma dica?", "Ksks... me deixa estudar."]], "lara": [["naty", "Naty, eu ia fazer uma piada, mas esqueci... ata, lembrei: você entra primeiro e sai por último.", "Apresentadora tem essa função."], ["fernando", "Fernando, desenhei o seu retrato de mais pika e o lápis quebrou, ksks.", "Ficou lindo, hein."], ["guifer", "Guifer, desenhei o seu topete e o lápis quebrou tentando pentear.", "Ele é indomável!"], ["marcela", "Marcela, você é leal, mas em que sala a gente está mesmo? Perai...", "Sala 1, Lara. Está escrito na porta."], ["debora", "Débora, me diz a hora do sinal e eu desenho o seu retrato de graça.", "Fechado. O sinal já tocou."]], "fernando": [["erick", "Erick, 19 pontos no futebol? No GTA eu faço cem só de entrar na escola.", "Quero ver você tentar."], ["naty", "Naty, tchooo!? Você apresenta a família e eu apresento o desafio: quem aguenta a primeira aula acordado.", "Eu aguento. Você, não."], ["lara", "Lara, ata, lembrei? Eu lembro: hoje tem prova.", "Perai... tem prova?!"], ["alinny", "Alinny, vou passar a manhã ouvindo você estudar. Vou até levar um fone também.", "Posso dividir o meu."], ["guifer", "Guifer, aquela cargo cheia de bolso guarda o lanche do Fernando, né?", "Ksks, guarda sim."]], "erick": [["fernando", "Fernando, o mais pika do grupo ainda não passou na prova de português.", "Tchooo! Calúnia!"], ["yuri", "Yuri, você chegou a tempo do gol, mas foi o último a sentar na Sala 1.", "Tranquilo, o sinal ainda não bateu."], ["marcela", "Marcela, você me chamou de 19 pontos na frente de todo mundo.", "Eu apresentei o craque, ksks."], ["guifer", "Guifer, o tênis branco de manhã vai durar só até o recreio.", "Eu guardo ele no bolso."], ["naty", "Naty, se a apresentação da família for prova, eu vou de luva.", "Luva não vale nota."]], "marcela": [["erick", "Erick, o 19 pontos virou 19 minutos de atraso para chegar na Sala 1.", "Fui o último da fila, ok?"], ["lara", "Lara, eu sou leal, mas não vou soprar a resposta da prova para você.", "Perai... eu nem pedi!"], ["naty", "Naty, você nos apresentou tão bem que o professor já sabe o nome de todo mundo.", "Missão cumprida."], ["fernando", "Fernando, tchooo!? É o som do seu cérebro reiniciando?", "Carrega... carrega..."], ["debora", "Débora conferiu mochila, caderno e lanche. Só esqueceu de conferir se eu tenho lápis.", "Tenho um sobrando."]], "alinny": [["guifer", "Guifer, você demorou mais para descrever o tênis do que eu para estudar a lição.", "Ksks, ele merece detalhes."], ["yuri", "Yuri, eu estava estudando com música e só consegui ouvir você falando da camisa.", "Ela dá sorte nos estudos também."], ["naty", "Naty, a apresentação da família demorou tanto que eu terminei de estudar a matéria.", "Eu falo com carinho, tá?"], ["lara", "Lara, o bom oia, perai, ata lembrei já virou música nos meus fones.", "Ksks, toca de novo!"], ["erick", "Erick, se 19 pontos fosse nota eu repetia o ano, mas você passava no futebol.", "Passo no gol, não na prova, ksks."]]};
const JI={};
const QIMG=new Image();QIMG.src="assets/foto_02.jpg";
const QF=ES.ord.slice();
const QD=R.push({n:'Quadra',qd:1,l:COR,o:[[4,'multidao','A arquibancada está lotada. Parece que a escola inteira veio para o intervalo.'],...QF.map((k,i)=>[91+i*21,'qfam',k])]})-1;
W.multidao=70;W.qfam=18;
const QY=10;const FQ={h:[],lp:-1,go:0};let SALAF=0;
const QL={naty:'Daqui eu vejo a quadra inteira. Escolhi o melhor lugar, claro.',guifer:'A arquibancada lotada de rapariga e eu de tênis branco.',debora:'Quanta gente! Alguém conferiu o lanche?',yuri:'Minha máscara vey...',lara:'Oi! Bom...perai, quem vai jogar hoje?',fernando:'Fds Lara! Quem aguenta um intervalo sem GTA?',erick:'Se a jogadora de tigrinho for, eu não vou.',marcela:'Fala isso mas tu fica vendo Xv..DEIXA..',alinny:'Muito barulho... posso ficar quieta aqui?',honorio:'Se alguém aparecer de máscara de novo, eu arranco.'};
const QN={naty:'Naty',guifer:'Guifer',debora:'Débora',yuri:'Yuri',lara:'Lara',fernando:'Fernando',erick:'Erick',marcela:'Marcela',alinny:'Alinny',honorio:'Honório'};
const CRW=[];(function(){let s=7;const r=()=>(s=(s*1103515245+12345)&0x7fffffff)/0x7fffffff,cs=['#c0392b','#2980b9','#f1c40f','#ecf0f1','#27ae60','#8e44ad','#e67e22','#16a085','#2c3e50','#e84393'],pe=['#f0c9a0','#d9a97a','#b07a50','#7a4b2a','#e8b98f'],ca=['#1c1c1c','#3a2616','#7a4a1e','#c9a24a','#111111','#5a3a1e'];
 [[87,34],[100,32],[114,30]].forEach(([y,n],ri)=>{for(let i=0;i<n;i++)CRW.push({x:6+i*(308/n)+r()*4,y:y+(r()*2|0),c:cs[r()*cs.length|0],p:pe[r()*pe.length|0],h:ca[r()*ca.length|0],ph:r()*6.28})})})();
function fila(){return;if(!FQ.h.length)FQ.h=Array(150).fill({x:px,d:dir});
 const mv=px!==FQ.lp;if(mv){FQ.h.push({x:px,d:dir});if(FQ.h.length>600)FQ.h.shift()}FQ.lp=px;
 const L=ES.ord.filter(k=>!(k==='yuri'&&F.maskOn&&!F.pairJoin)).concat(F.pairJoin?['honorio']:[]);
 for(let i=L.length-1;i>=0;i--){const k=L[i],o=FQ.h[Math.max(0,FQ.h.length-1-(i+1)*14)];let x=o.x;
  if(F.pairJoin&&(k==='yuri'||k==='honorio')){const J=FQ.j||(FQ.j={yuri:px,honorio:px});J[k]+=Math.max(-2.2,Math.min(2.2,o.x-J[k]));x=J[k]}
  spr(k,x,FL+8,mv,k==='fernando'?-o.d:o.d)}}
function quadra(){g.fillStyle='#2a2012';g.fillRect(0,0,320,180);if(QIMG.complete&&QIMG.naturalHeight)g.drawImage(QIMG,0,37.6,320,142.4);
 const T=performance.now()/1000;for(const p of CRW){const b=Math.sin(T*3+p.ph)>.85?1:0;rc(p.c,p.x,p.y+5-b,6,9);rc(p.p,p.x+1,p.y+1-b,4,4);rc(p.h,p.x+1,p.y-b,4,2)}
 {const QX=FQ.qx||(FQ.qx={});QF.forEach((k,i)=>{if(k==='yuri'&&!F.mask)return;const tx=100+i*21;let x=QX[k];if(x==null)x=tx;const m=x<tx-.5;if(m)x=Math.min(tx,x+1.6);QX[k]=x;spr(k,x,FL+8+QY,m,m?(k==='fernando'?-1:1):(k==='fernando'?1:-1))})}if(!busy&&!GM.on)QW++;if(vivo&&!F.quadVista&&!busy){F.quadVista=1;seq([['Naty','Demorou! A gente já pegou lugar.'],['Guifer','A escola inteira veio, ksks.']])}else if(vivo&&!busy&&!GM.on&&QW>30&&F.mask&&!F.banter){F.banter=1;save();banter()}else if(vivo&&!busy&&!GM.on&&QW>30&&F.banter&&!F.jgFim){jogosMenu()}else if(vivo&&!busy&&!GM.on&&!CUT.on&&QW>30&&F.jgFim&&!F.cenaFim){cenaMidia()}}
let QW=0;
/* ===== v46: diálogos da quadra, jogos, glitch, sala de mídia e vídeo ===== */
let GM={on:0},GLF=0;
const CVS=document.getElementById('c');
const CUT={on:0,fimTxt:0};
const raf=()=>new Promise(r=>requestAnimationFrame(r));
async function fadeTo(v,ms){const a=BLK,t0=performance.now();for(;;){await raf();const e=Math.min(1,(performance.now()-t0)/ms);BLK=a+(v-a)*e;if(e>=1)break}}
function falas(a){return new Promise(res=>seq(a,()=>{$('dlg').onclick=null;$('dt').textContent='…';busy=1;res()}))}
async function andar(x,vel){vel=vel||1.6;while(Math.abs(px-x)>vel){const d=Math.sign(x-px);px+=d*vel;dir=d;keys.L=d<0?1:0;keys.R=d>0?1:0;await raf()}keys.L=0;keys.R=0}
/* ---------- glitch de pixel (como uma tela com defeito) ---------- */
const GC=document.createElement('canvas');GC.width=80;GC.height=100;const gcx=GC.getContext('2d');
function glitchFx(k,x,y){if(x<-30||x>350)return;const h=HH[k]||66,w=40,x0=Math.round(x-w/2),y0=Math.round(y-h-4),fx=CVS.width/320;
 const T=Math.floor(performance.now()/85),r=n=>{const v=Math.sin(T*12.9898+n*78.233)*43758.5453;return v-Math.floor(v)};
 if(r(1)>.5){const bs=3+Math.floor(r(2)*3),bw=Math.ceil(w/bs),bh=Math.ceil((h+6)/bs);gcx.clearRect(0,0,80,100);gcx.imageSmoothingEnabled=false;gcx.drawImage(CVS,x0*fx,y0*fx,w*fx,(h+6)*fx,0,0,bw,bh);g.save();g.imageSmoothingEnabled=false;g.drawImage(GC,0,0,bw,bh,x0,y0,bw*bs,bh*bs);g.restore()}
 for(let i=0;i<2;i++){if(r(10+i)>.45){const sy=y0+Math.floor(r(20+i)*h),sh=2+Math.floor(r(30+i)*5),dx=Math.round((r(40+i)-.5)*12);g.drawImage(CVS,x0*fx,sy*fx,w*fx,sh*fx,x0+dx,sy,w,sh)}}
 if(r(50)>.35){g.globalAlpha=.55;g.fillStyle=r(51)>.5?'#00ffff':'#ff00ff';g.fillRect(x0,y0+Math.floor(r(52)*h),w,1+Math.floor(r(53)*2));g.globalAlpha=1}}
function glitchSpr(k,x,y,sc,d){if(x<-30||x>350)return;const i=IM[k];if(!i||!i.complete||!i.naturalHeight)return;
 const H=i.naturalHeight,W0=i.naturalWidth,h=(HH[k]||66)*sc,w=W0/H*h,y0=Math.round(y-h);
 const T=Math.floor(performance.now()/85),r=n=>{const v=Math.sin(T*12.9898+n*78.233)*43758.5453;return v-Math.floor(v)};
 g.save();g.imageSmoothingEnabled=false;let xx=Math.round(x);if(d<0){g.translate(xx,0);g.scale(-1,1);xx=0}const x0=xx-Math.round(w/2);
 if(r(1)>.5){const bs=3+Math.floor(r(2)*3),bw=Math.max(1,Math.ceil(w/bs)),bh=Math.max(1,Math.ceil(h/bs));gcx.clearRect(0,0,80,100);gcx.imageSmoothingEnabled=false;gcx.drawImage(i,0,0,bw,bh);g.drawImage(GC,0,0,bw,bh,x0,y0,bw*bs,bh*bs)}
 for(let n=0;n<2;n++){if(r(10+n)>.45){const sh=2+Math.floor(r(30+n)*5),sy=Math.floor(r(20+n)*Math.max(1,h-sh)),dx=Math.round((r(40+n)-.5)*12);g.drawImage(i,0,sy/h*H,W0,Math.max(1,sh/h*H),x0+dx,y0+sy,w,sh)}}
 if(r(50)>.35){g.globalAlpha=.55;g.fillStyle=r(51)>.5?'#00ffff':'#ff00ff';g.fillRect(x0,y0+Math.floor(r(52)*h),w,1+Math.floor(r(53)*2));g.globalAlpha=1}
 g.restore()}
function screenGlitch(){GLF--;const fx=CVS.width/320,T=GLF;for(let i=0;i<4;i++){const q=Math.random(),sy=Math.floor(Math.random()*170),sh=2+Math.floor(Math.random()*14),dx=Math.round((q-.5)*40);g.drawImage(CVS,0,sy*fx,CVS.width,sh*fx,dx,sy,320,sh)}
 g.globalAlpha=.18;g.fillStyle=T%4<2?'#00ffff':'#ff00ff';g.fillRect(0,Math.floor(Math.random()*170),320,6);g.globalAlpha=1}
/* ---------- diálogo da quadra (3 falas de cada) ---------- */
const BANTER=[['naty',"vê só..."],
['guifer',"cafetões!"],
['debora',"Calma, gente. Eu trouxe pão de queijo. Cada um pega um, o resto é meu por direito."],
['erick',"Débora, se tu contar pão de queijo igual conta ponto, ninguém aqui come."],
['yuri',"E tu devendo 19 pontos em artes kkkkkkkkkkk."],
['lara',"kkkkk que isso yuri."],
['fernando',"vou ligar pra minha mãe pra me buscar."],
['marcela',"MDS, não faz nada, não copia e vive faltando"],
['alinny',"........."],
['guifer',"clbc jogadora de tigrinho."],
['alinny',"o sinal já tocou..."],
['erick',"Queria tá em casa agora comendo fandangos é uma conquinha, Oh delícia!."],
['naty',"kkkkkkkkkkkkk."],
['lara',"Estudar que é bom nada né bonitinho?."],
['debora',"mds olha esse menino.."],
['fernando',"OUUUH TCHAA!!! *espirro*."],
['yuri',"Que isso Barrabás kkkkkk."],
['marcela',"Para com isso Yuri!"],
['naty',"kkkkkkkkkkkkkkkkkkk."],
['guifer',"Oh Yuri, tu já deu o teu buraco?."],
['debora',"mdsss!!kkkk toma vergonha Guilherme!"],
['yuri',"é né? vou perguntar pra Leila.."],
['lara',"KKKKKKKKKKKKKKKKKKK!"],
['fernando',"TUA MÃE AQUELA RPGA! YURI"],
['erick',"Faz silêncio ae Caraí."],
['marcela',"tudo boca podre.."],
['alinny',"........"]];
const QLG={alinny:"Tá acontecendo aquilo dnv.. (a voz dela falha por um instante)",debora:"Vixe tá acontecendo oque hein?...",lara:"que merda...."};
const GLN=['alinny','debora','lara'];
function banter(){busy=1;seq(BANTER.map(([k,x])=>[QN[k],x]),()=>jogosMenu())}
function jogosMenu(){const D=F.jg||(F.jg={});if(D.pen&&D.que&&D.cab)return fimJogos();
 const op=[];if(!D.pen)op.push(['Pênalti',()=>iniciaJogo('pen')]);if(!D.que)op.push(['Fuga da queimada',()=>iniciaJogo('que')]);if(!D.cab)op.push(['Cabo de guerra',()=>iniciaJogo('cab')]);
 say('Naty',Object.keys(D).length?'Mais um? Escolhe!':'Bora jogar? Escolhe um!',op)}
function iniciaJogo(k){end();busy=1;GM={on:1,k,g:GAMES[k],s:null,win:0};GAMES[k].init();}
function gameWin(k){GM={on:0};const D=F.jg||(F.jg={});D[k]=1;const who=GLN[Object.keys(D).length-1];(F.gl||(F.gl={}))[who]=1;GLF=55;save();
 const RX={pen:[['Marcela',"Gol é gol! Alinny, vem comemorar com a gente!"],['Alinny',"Tô indo… ué? Por que… tá tudo normal, né?"],['Você',"Por um segundo, a Alinny tremeu como uma tela com sinal ruim."]],
 que:[['Erick',"Sobreviveu! Quase gostei de ver, carai."],['Débora',"Meu pão de queijo… eu tava com ele agora. Tava, né?"],['Você',"A imagem da Débora quebrou em pedacinhos quadrados e voltou ao normal."]],
 cab:[['Naty',"A família ganhou! Como sempre."],['Lara',"Oie! Eu… falei oie? Tá tudo meio quadradinho, gente."],['Você',"Três deles estão assim agora. E ninguém quer olhar pra isso."]]}[k];
 busy=1;seq(RX,()=>jogosMenu())}
function fimJogos(){F.jgFim=1;save();seq([['Você',"O que está acontecendo?"],['Naty',"Alguns dos membros estão com algum tipo de falha, mas é melhor não tocar no assunto…"],['Erick',"Fala logo, carai, deixa de frescura."],['Yuri',"Bixo, tu sabe que não pode, né…?"],['Você',"Do que vocês estão falando?"],['Marcela',"Vamos todos para a sala de mídia… a gente te explica lá…"]],()=>{cenaMidia()})}
/* ---------- jogos ---------- */
function big(k,x,y,sc,fl,rot){const i=IM[k];if(!i||!i.complete||!i.naturalHeight)return;const h=(HH[k]||66)*sc,w=i.naturalWidth/i.naturalHeight*h;g.save();g.translate(Math.round(x),Math.round(y));if(rot)g.rotate(rot);if(fl)g.scale(-1,1);g.drawImage(i,-w/2,-h,w,h);g.restore();if(F.gl&&F.gl[k])glitchFx(k,x,y)}
function qBase(){g.fillStyle='#2a2012';g.fillRect(0,0,320,180);if(QIMG.complete&&QIMG.naturalHeight)g.drawImage(QIMG,0,37.6,320,142.4);const T=performance.now()/1000;for(const p of CRW){const b=Math.sin(T*3+p.ph)>.85?1:0;rc(p.c,p.x,p.y+5-b,6,9);rc(p.p,p.x+1,p.y+1-b,4,4);rc(p.h,p.x+1,p.y-b,4,2)}}
function txt(s,x,y,c,sz){g.font='bold '+(sz||10)+'px monospace';g.textAlign='center';g.fillStyle='#000';g.fillText(s,x+1,y+1);g.fillStyle=c||'#e8b85c';g.fillText(s,x,y);g.textAlign='left'}
function ball(x,y,r,c){g.fillStyle='#000a';g.beginPath();g.arc(x+1,y+1,r,0,7);g.fill();g.fillStyle=c||'#d92b2b';g.beginPath();g.arc(x,y,r,0,7);g.fill();g.fillStyle='rgba(255,255,255,.55)';g.beginPath();g.arc(x-r*.3,y-r*.35,r*.28,0,7);g.fill()}
function hud(l){rc('#000a',3,17,128,12);g.fillStyle='#e8b85c';g.font='7px monospace';g.fillText(l,6,26)}
const GAMES={};
function gmDraw(){GM.g.draw()}
let TIPT=0;function setTip(n,t){$('dn').textContent=n;$('dt').textContent=t;clearTimeout(TIPT);TIPT=setTimeout(()=>{if(GM&&GM.on){$('dn').textContent=R[rm].n;$('dt').textContent='…'}},7000)}
/* PÊNALTI */
const GX=86,GY=38,GW=148,GH=94;
GAMES.pen={init(){GM.s={shots:0,goals:0,ph:0,tt:0,ax:160,ay:90,cx:160,cy:90,kz:0,bt:0,rt:0,res:'',hist:[],end:0};setTip('Pênalti','Toque em AGIR para travar a mira: primeiro na horizontal, depois na vertical. Mire nos cantos! Faça 3 gols em 5 chutes.')},
 act(){const s=GM.s;if(s.ph===0){s.ax=s.cx;s.ph=1}else if(s.ph===1){s.ay=s.cy;s.ph=2;s.bt=0;const r=Math.random();s.kz=r<.4?-1:r<.6?0:1}},
 draw(){const s=GM.s;qBase();s.tt+=.016;const sp=3+s.shots*.45;
  if(s.ph===0)s.cx=GX+GW*(.5+.5*Math.sin(s.tt*sp));if(s.ph===1)s.cy=GY+GH*(.5+.5*Math.sin(s.tt*(sp+.9)));
  if(s.ph===2){s.bt+=1/30;if(s.bt>=1){const z=s.ax<GX+GW*.36?-1:s.ax>GX+GW*.64?1:0,corner=(s.ax<GX+GW*.15||s.ax>GX+GW*.85)&&s.ay<GY+GH*.62,sv=(z===s.kz)&&!corner;s.shots++;s.hist.push(sv?0:1);if(sv)s.res='DEFENDEU!';else{s.goals++;s.res='GOOOL!'}s.ph=3;s.rt=0}}
  if(s.ph===3){s.rt++;if(s.rt>75){if(s.shots>=5){if(s.goals>=3){s.ph=4;s.rt=0;s.res='VENCEU!'}else{s.res='';s.shots=0;s.goals=0;s.hist=[];s.ph=0;setTip('Pênalti','Não deu! Faltaram gols. Tenta de novo: mire nos cantos.')}}else{s.ph=0;s.res=''}}}
  if(s.ph===4){s.rt++;if(s.rt>80){gameWin('pen');return}}
  g.fillStyle='rgba(0,0,0,.38)';g.fillRect(GX,GY,GW,GH);for(let x=GX;x<=GX+GW;x+=8)rc('rgba(255,255,255,.16)',x,GY,1,GH);for(let y=GY;y<=GY+GH;y+=8)rc('rgba(255,255,255,.16)',GX,y,GW,1);
  const dv=s.ph>=2?Math.min(1,s.bt*1.7):(s.ph>=3?1:0),e=s.ph>=3?1:dv;big('erick',GX+GW/2+s.kz*GW*.30*e,132-Math.sin(e*Math.PI)*7,1.0,s.kz>0,s.kz*.55*e);
  rc('#f4f4f4',GX-3,GY-3,3,GH+3);rc('#f4f4f4',GX+GW,GY-3,3,GH+3);rc('#f4f4f4',GX-3,GY-3,GW+6,3);
  if(s.ph===0){rc('rgba(232,184,92,.95)',Math.round(s.cx)-1,GY,2,GH)}
  if(s.ph===1){rc('rgba(232,184,92,.5)',Math.round(s.ax)-1,GY,2,GH);rc('rgba(232,184,92,.95)',GX,Math.round(s.cy)-1,GW,2);g.strokeStyle='#e8b85c';g.lineWidth=1;g.beginPath();g.arc(s.ax,s.cy,7,0,7);g.stroke()}
  let bx=160,by=170,br=7;if(s.ph===2){bx=160+(s.ax-160)*s.bt;by=170+(s.ay-170)*s.bt-Math.sin(s.bt*Math.PI)*14;br=7-3.2*s.bt}else if(s.ph>=3){bx=s.ax;by=s.ay;br=3.8}
  big('você',112,178,.8,0,s.ph===2?.12:0);ball(bx,by,br);
  const bump=s.ph===3&&s.res==='GOOOL!'?Math.abs(Math.sin(s.rt*.3))*5:0;big('marcela',30,170-bump,.72,0);big('guifer',292,170-bump,.72,1);
  hud('PÊNALTI   Gols '+s.goals+'/3   Chute '+Math.min(5,s.shots+(s.ph<3?1:0))+'/5');for(let i=0;i<5;i++)rc(i<s.hist.length?(s.hist[i]?'#3fbf5f':'#d9503f'):'#555',268+i*10,5,8,8);
  if(s.res)txt(s.res,160,46,s.res==='DEFENDEU!'?'#ff7a6b':'#e8c46a',18)}};
/* FUGA DA QUEIMADA */
const QTH=[['guifer',238],['lara',258],['erick',278],['marcela',298]];
GAMES.que={init(){GM.s={f:0,life:3,balls:[],sp:40,x:70,inv:0,dash:0,dc:0,fail:0,ft:0,win:0,wt:0,th:{}};setTip('Fuga da queimada','Segure ◀ ▶ para fugir das bolas: a sombra mostra onde elas caem. AGIR dá um arranco rápido. Sobreviva 20 segundos!')},
 act(){const s=GM.s;if(s.dc<=0&&!s.fail){s.dash=12;s.dc=45}},
 draw(){const s=GM.s;qBase();
  if(!s.fail&&!s.win){s.f++;const a=(keys.L?-1:0)+(keys.R?1:0),v=1.8*(s.dash>0?2.3:1);s.x=Math.max(16,Math.min(214,s.x+a*v));if(s.dash>0)s.dash--;if(s.dc>0)s.dc--;if(s.inv>0)s.inv--;
   if(--s.sp<=0&&s.f<1230){const T=QTH[Math.floor(Math.random()*QTH.length)];s.sp=Math.max(20,60-s.f/28);const tot=Math.max(44,78-s.f/42),lx=Math.max(12,Math.min(224,s.x+(Math.random()-.5)*50+a*20));s.balls.push({x0:T[1],y0:112,lx,f:0,tot,arc:36+Math.random()*34,c:Math.random()<.5?'#d92b2b':'#222'});s.th[T[0]]=14}
   for(const b of s.balls){b.f++;if(b.f>=b.tot){b.dead=1;if(s.inv<=0&&Math.abs(s.x-b.lx)<11){s.life--;s.inv=70;if(s.life<=0){s.fail=1;s.ft=0}}}}s.balls=s.balls.filter(b=>!b.dead);
   if(s.f>=1300&&!s.fail){s.win=1;s.wt=0}}
  else if(s.fail){s.ft++;if(s.ft>75){const th=s.th;GM.s={f:0,life:3,balls:[],sp:40,x:70,inv:0,dash:0,dc:0,fail:0,ft:0,win:0,wt:0,th:{}};return}}
  else if(s.win){s.wt++;if(s.wt>80){gameWin('que');return}}
  QTH.forEach(([k,x])=>{const th=s.th[k]||0;if(th>0)s.th[k]--;big(k,x,152,.82,1,th>0?-.14:0)});
  for(const b of s.balls){const u=b.f/b.tot;g.fillStyle='rgba(255,70,70,'+(.2+.35*u)+')';g.beginPath();g.ellipse(b.lx,163,4+9*u,1.5+3*u,0,0,7);g.fill()}
  if(!(s.inv>0&&Math.floor(s.inv/4)%2))big('você',s.x,166,1.0,keys.L&&!keys.R,s.dash>0?(keys.L?-.1:.1):0);
  for(const b of s.balls){const u=b.f/b.tot,x=b.x0+(b.lx-b.x0)*u,y=b.y0+(163-b.y0)*u-b.arc*4*u*(1-u);ball(x,y,5,b.c)}
  hud('FUGA DA QUEIMADA');for(let i=0;i<3;i++)rc(i<s.life?'#e8506b':'#444',92+i*10,19,8,8);rc('#222',224,5,92,8);rc('#e8b85c',225,6,Math.min(90,90*s.f/1300),6);if(s.dc>0)rc('#6bb7ff',6,30,Math.max(0,24*(1-s.dc/45)),2);
  if(s.fail)txt('QUEIMADO! De novo…',160,40,'#ff7a6b',14);if(s.win)txt('SOBREVIVEU!',160,40,'#e8c46a',18)}};
/* CABO DE GUERRA */
GAMES.cab={init(){GM.s={q:0,f:0,bump:0,fail:0,ft:0,win:0,wt:0};setTip('Cabo de guerra','Aperte AGIR o mais rápido que puder para puxar a corda para o seu lado!')},
 act(){const s=GM.s;if(!s.fail&&!s.win){s.q+=.05;s.bump=6}},
 draw(){const s=GM.s;qBase();
  if(!s.fail&&!s.win){s.f++;s.q-=.0030+s.f*.0000018+.0012*Math.sin(s.f*.09);if(s.bump>0)s.bump--;if(s.q>=1){s.win=1;s.wt=0}else if(s.q<=-1||s.f>1500){s.fail=1;s.ft=0}}
  else if(s.fail){s.ft++;if(s.ft>75){GM.s={q:0,f:0,bump:0,fail:0,ft:0,win:0,wt:0};return}}
  else{s.wt++;if(s.wt>80){gameWin('cab');return}}
  const dx=-s.q*30,gy=154;rc('#3a2c18',40,gy,240,2);
  const L=[['você',116],['naty',92],['debora',68],['fernando',44]],Rr=[['erick',204],['guifer',228],['marcela',252],['yuri',276]];
  L.forEach(([k,x],i)=>big(k,x+dx-(s.bump>0?2:0),gy+8,.86,k==='fernando'?1:0,-.11-(s.bump>0?.04:0)+Math.sin(s.f*.2+i)*.012));
  Rr.forEach(([k,x],i)=>big(k,x+dx,gy+8,.86,1,.12+Math.sin(s.f*.17+i)*.012));
  g.strokeStyle='#9a7a45';g.lineWidth=2;g.beginPath();g.moveTo(52+dx,118);g.quadraticCurveTo(160+dx,126+Math.sin(s.f*.1)*1.5,272+dx,118);g.stroke();
  const fx=160+dx;rc('#d92b2b',fx-1,100,2,22);g.fillStyle='#d92b2b';g.beginPath();g.moveTo(fx+1,100);g.lineTo(fx+11,104);g.lineTo(fx+1,108);g.fill();
  rc('rgba(255,255,255,.35)',100,96,1,60);rc('rgba(255,255,255,.35)',220,96,1,60);
  hud('CABO DE GUERRA');rc('#222',138,19,170,8);rc('#e8506b',139,20,168,6);rc('#3b82f6',139,20,Math.round(84+84*s.q),6);rc('#fff',139+Math.round(84+84*s.q)-1,17,2,12);
  if(s.fail)txt('A corda escapou! De novo…',160,40,'#ff7a6b',12);if(s.win)txt('PUXOU!',160,40,'#e8c46a',18)}};
/* ---------- 2º andar e sala de mídia ---------- */
const COR2=R.push({n:'2º Andar',cor2:1,o:[]})-1,MIDR=R.push({n:'Sala de Mídia',midia:1,o:[]})-1;
const MIDO=['naty','guifer','debora','yuri','você','lara','fernando','erick','marcela','alinny'];
const MID={sit:0,st:null,all:0};
function midiaInit(){MID.sit=0;MID.all=0;MID.st={};let d=0;MIDO.forEach((k,i)=>{if(k==='você')return;MID.st[k]={x:-16,tx:34+i*28,w:46+d*20,s:0};d++})}
function corredor2(){g.fillStyle='#1c2030';g.fillRect(0,0,320,180);if(CORI.complete&&CORI.naturalHeight)g.drawImage(CORI,0,70,320,106.7);
 [[17,'MÍDIA'],[69,'SALA 7'],[119,'SALA 8'],[227,'SALA 9'],[282,'LAB']].forEach(([x,l])=>{rc('#dfe3ec',x,101,23,8);rc('#222',x+1,102,21,6);g.fillStyle='#fff';g.font='5px monospace';g.fillText(l,x+2,107.5)});
 g.fillStyle='rgba(8,10,30,.38)';g.fillRect(0,0,320,180);if(!F.interv0){}famSegue()}
function sentM(k,x){const i=IM[k],h=(HH[k]||66)*.8,dy=k==='fernando'?4:10;
 if(k!=='fernando'){rc('#232b45',x-11,FL-42,22,38);rc('#1b2238',x-12,FL-44,24,3)}
 if(i&&i.complete&&i.naturalHeight){const w=i.naturalWidth/i.naturalHeight*h;if(k==='fernando'){g.save();g.translate(Math.round(x),0);g.scale(-1,1);g.drawImage(i,Math.round(-w/2),FL-4-h+dy,w,h);g.restore()}else g.drawImage(i,Math.round(x-w/2),FL-4-h+dy,w,h)}
 if(k!=='fernando'){rc('#2f3858',x-13,FL-14,26,5);rc('#222a44',x-11,FL-9,22,14)}
 if(F.gl&&F.gl[k])glitchFx(k,x,FL+6)}
function midia(){const gr=g.createLinearGradient(0,0,0,FL);gr.addColorStop(0,'#151b2e');gr.addColorStop(1,'#0d111e');g.fillStyle=gr;g.fillRect(0,0,320,FL);
 rc('#0a0d18',0,FL,320,34);for(let x=0;x<320;x+=40)rc('#0f1424',x,FL,1,34);rc('#1b2238',0,FL-4,320,4);
 rc('#10152a',96,102,128,30);rc('#0a0d1a',98,104,124,3);rc('#1a2038',100,110,36,20);rc('#1a2038',184,110,36,20);
 rc('#06070c',106,32,108,58);rc('#0a0f1a',109,35,102,52);g.fillStyle='rgba(150,180,255,.06)';g.beginPath();g.moveTo(109,35);g.lineTo(150,35);g.lineTo(122,87);g.lineTo(109,87);g.fill();g.beginPath();g.moveTo(170,35);g.lineTo(186,35);g.lineTo(150,87);g.lineTo(134,87);g.fill();rc('#06070c',152,90,16,12);
 if(Math.floor(performance.now()/900)%2)rc('#c0392b',204,87,2,2);
 rc('#c9d0e0',236,22,68,20);rc('#aeb6cb',236,38,68,4);for(let i=0;i<6;i++)rc('#8f98b0',240+i*10,28,7,1);rc('#8f98b0',240,32,56,1);
 rc(Math.floor(performance.now()/1200)%2?'#3fe07a':'#1b6b3d',298,25,2,2);
 for(let i=0;i<5;i++){const p=((performance.now()/20+i*23)%46);g.fillStyle='rgba(190,215,255,'+(.10*(1-p/46))+')';g.fillRect(244+i*11,43+p,6,2)}
 if(MID.st){let all=1;for(const k of MIDO){if(k==='você')continue;const s=MID.st[k];if(!s)continue;if(MID.hold){all=0;continue}if(s.w>0){s.w--;all=0;continue}if(s.x<s.tx-.5){s.x=Math.min(s.tx,s.x+1.6);all=0}else s.s=1}MID.all=all&&MID.sit}
 const draw=[];for(const k of MIDO){if(k==='você'){if(MID.sit)draw.push([k,34+4*28,1]);continue}const s=MID.st&&MID.st[k];if(!s||s.w>0)continue;draw.push([k,s.x,s.s])}
 draw.forEach(([k,x,sit])=>{if(sit)sentM(k,x);else spr(k,x,FL+8,1,k==='fernando'?-1:1)});
 g.fillStyle='rgba(2,4,12,.24)';g.fillRect(0,0,320,180)}
/* ---------- cena: corredor → escada → 2º andar → sala de mídia → vídeo ---------- */
function calaMusica(){try{if(MG)MG.gain.setTargetAtTime(0,A.currentTime,.4);const c=V8.ctx();if(TG&&c)TG.gain.setTargetAtTime(0,c.currentTime,.4);if(TEMA){TEMA.volume=0;TEMA.pause()}}catch(e){}}
function mutaTudo(){calaMusica();try{const c=V8.ctx();if(c&&c.state==='running')c.suspend()}catch(e){}try{document.querySelectorAll('audio').forEach(a=>{try{a.pause()}catch(e){}})}catch(e){}}
function voltaSom(){try{const c=V8.ctx();if(c&&c.state==='suspended')c.resume()}catch(e){}}
function tocarVideo(){return new Promise(res=>{
 mutaTudo();
 const wrap=document.createElement('div');wrap.style.cssText='position:fixed;z-index:20;background:#000;overflow:hidden;display:flex;align-items:center;justify-content:center';
 const pos=()=>{if(!wrap.isConnected)return;const r=CVS.getBoundingClientRect();wrap.style.left=r.left+'px';wrap.style.top=r.top+'px';wrap.style.width=r.width+'px';wrap.style.height=r.height+'px';requestAnimationFrame(pos)};
 const v=document.createElement('video');v.setAttribute('playsinline','');v.playsInline=true;v.style.cssText='width:100%;height:100%;object-fit:contain;background:#000;opacity:0';v.controls=false;v.disablePictureInPicture=true;v.addEventListener('playing',()=>{v.style.opacity=1},{once:true});v.volume=1;v.muted=false;
 v.src='assets/video.mp4';
 const sk=document.createElement('button');sk.textContent='Pular ▶▶';sk.style.cssText='position:absolute;right:6px;bottom:6px;padding:4px 8px;border-radius:6px;border:1px solid #fff6;background:#0009;color:#fff;font:11px system-ui;z-index:2';
 const fim=()=>{try{v.pause()}catch(e){}wrap.remove();URL.revokeObjectURL(url);voltaSom();calaMusica();res()};v.onended=fim;v.onerror=()=>setTimeout(fim,1200);sk.onclick=fim;wrap.append(v,sk);document.body.append(wrap);pos();
 v.play().catch(()=>{v.muted=true;v.play().catch(()=>{});const un=()=>{v.muted=false;removeEventListener('pointerdown',un)};addEventListener('pointerdown',un)})})}
async function cenaMidia(){CUT.on=1;busy=1;$('dlg').onclick=null;keys.L=0;keys.R=0;
 await fadeTo(1,700);rm=COR;px=304;dir=-1;FQ.h=[{x:304,d:-1}];FQ.lp=-1;$('dn').textContent=R[rm].n;await fadeTo(0,500);
 await andar(188);await esp(350);
 await fadeTo(1,500);rm=MIDR;midiaInit();MID.hold=1;px=-14;dir=1;FQ.h=[];$('dn').textContent=R[rm].n;calaMusica();await fadeTo(0,600);
 await falas([['Sala de Mídia',"Escura e em silêncio. Uma TV desligada e o ar-condicionado zumbindo baixinho."]]);MID.hold=0;
 await andar(34+4*28);MID.sit=1;keys.L=0;keys.R=0;
 while(!MID.all)await raf();await esp(600);
 {const k=ES.ord[Math.floor(Math.random()*ES.ord.length)];await falas([[QN[k],"eu lembro daquele dia…"]])}
 await esp(500);await fadeTo(1,1000);await esp(300);await tocarVideo();await esp(400);await fadeTo(0,900);
 CUT.on=0;
 seq([['Você',"Então foi isso que aconteceu?"],['Você',"É por isso que ele nunca aparece…"],['Você',"Mas onde está ele?"],['Você',"e algumas pessoas estão estranhas, falhand.."]],async()=>{$('dlg').onclick=null;busy=1;{const r0=rm,p0=px;rm=QD;px=14;F.cenaFim=1;save();rm=r0;px=p0}await esp(800);await fadeTo(1,1200);await cenaNoite()})}

function sino(){try{const c=V8.ctx();if(!c)return;if(c.state==='suspended')c.resume();[0,.45,.9].forEach(d=>{const o=c.createOscillator(),gn=c.createGain(),t=c.currentTime+d;o.type='sine';o.frequency.value=988;gn.gain.setValueAtTime(.0001,t);gn.gain.exponentialRampToValueAtTime(.25,t+.02);gn.gain.exponentialRampToValueAtTime(.0001,t+.8);o.connect(gn);gn.connect(c.destination);o.start(t);o.stop(t+.85)})}catch(e){}}
function intervalo(){busy=1;sino();seq([['12:00 PM','O sinal do intervalo toca.'],['Naty','Intervalo! A gente vai na frente para a quadra. Vem depois!']],()=>{end();F.interv=1;SALAF=1;save();busy=0})}
/* tema dos quartos novos: pré-carga e nova tentativa */
setTimeout(()=>{try{if(!TEMA){TEMA=new Audio(TEMA_SRC);TEMA.loop=true;TEMA.preload='auto';const c=V8.ctx();if(c){TG=c.createGain();TG.gain.value=0;c.createMediaElementSource(TEMA).connect(TG);TG.connect(c.destination)}else TEMA.volume=0}}catch(e){}},0);
const retomaTema=()=>{try{if(!TO||!TEMA)return;const c=V8.ctx();if(c&&c.state==='suspended')c.resume();if(TG&&c)TG.gain.setTargetAtTime(.7,c.currentTime,1);if(TEMA.paused)TEMA.play().catch(()=>{})}catch(e){}};
setInterval(retomaTema,1000);document.addEventListener('pointerdown',retomaTema,true);
/* máscara */
setTimeout(()=>{NPC.honorio={nome:'Honório',cor:{ro:'#f0f0f0',ca:'#1a1a1a',pe:'#d9a97a'}};NPC.yurimask=NPC.yuri||{nome:'Yuri',cor:{ro:'#f0f0f0',ca:'#1a1a1a',pe:'#d9a97a'}}},0);
let BLK=0;function blink(mid,done){const t0=performance.now();let m=0;(function f(n){const e=(n-t0)/1800;BLK=e<.5?Math.sin(e*Math.PI):Math.sin(Math.min(1,e)*Math.PI);if(e>=.5&&!m){m=1;mid()}if(e>=1){BLK=0;done();return}requestAnimationFrame(f)})(t0)}
const MK={yx:150,hx2:176,ph:0,hx:196,fly:0,mx:0,my:0,vx:0,vy:0,r:0,t:0};
function maskScene(){MK.ph=1;busy=1;seq([['Honório','Yuri. Tira essa máscara.'],['Yuri','Não..'],['Honório','O intervalo já começou e você aí, de máscara.'],['Yuri','Ox..to de boa...'],['Honório','Tira essa DISGRAÇA.'],['Yuri','Honório, não faz isso...']],()=>{end();busy=1;MK.ph=2})}
function maskDraw(){const done=F.mask,yy=FL+8;
 if(done){MK.yx+=1.6;MK.hx2+=1.6;if(MK.yx>345&&MK.hx2>345)F.pairGone=1}
 spr(done||MK.fly?'yuri':'yurimask',MK.yx,yy,done?1:0,1);spr('honorio',done?MK.hx2:MK.hx,yy,done||MK.ph===2?1:0,done?1:-1);
 if(done)return;
 if(MK.ph===2){MK.hx-=1.4;if(MK.hx<=176){MK.hx=176;MK.hx2=176;MK.ph=3;MK.fly=1;MK.mx=MK.yx+4;MK.my=FL-38;MK.vx=1.9;MK.vy=-2.6;MK.t=0}}
 if(MK.fly){MK.t++;MK.vy+=.04;MK.mx+=MK.vx;MK.my+=MK.vy;MK.r+=.4;if(MASKI.complete&&MASKI.naturalHeight){g.save();g.translate(MK.mx,MK.my);g.rotate(MK.r);g.drawImage(MASKI,-13,-8,26,16);g.restore()}}
 if(MK.ph===3&&MK.t>110){MK.ph=4;seq([['Yuri','faz isso não!'],['Honório','Tira essa porra dessa máscara.'],['Yuri','Eu não tô brincando não...mds.']],()=>{end();busy=1;blink(()=>{F.mask=1;F.pairGone=1;save()},()=>{busy=0})})}}
function irQuadra(){QW=0;const prim=!F.famQuadra;F.famQuadra=1;FQ.h=[];FQ.j=null;FQ.qx={};if(!prim)QF.forEach((k,i)=>{FQ.qx[k]=100+i*21});if(prim)QF.forEach((k,i)=>{FQ.qx[k]=k==='yuri'?100+i*21:14-(i+1)*12});ES.ent=[];save();move(QD,'r')}
const CM={on:0,go:0,m:[]};
function famSegue(){if(!CUT.on&&(!F.interv||F.famQuadra))return;if(!FQ.h.length)FQ.h=[{x:px,d:dir}];
 const mv=Math.abs(px-FQ.lp)>.01;if(mv){FQ.h.push({x:px,d:dir});if(FQ.h.length>600)FQ.h.splice(0,100)}FQ.lp=px;
 const L=ES.ord.filter(k=>CUT.on||k!=='yuri');
 for(let i=L.length-1;i>=0;i--){const k=L[i],idx=FQ.h.length-1-(i+1)*10;let x,d;if(idx>=0){x=FQ.h[idx].x;d=FQ.h[idx].d}else{d=FQ.h[0].d;x=FQ.h[0].x+idx*1.6*d}spr(k,x,FL+8,mv,k==='fernando'?-d:d)}}
function corredor(){g.fillStyle='#1c2030';g.fillRect(0,0,320,180);if(CORI.complete&&CORI.naturalHeight)g.drawImage(CORI,0,70,320,106.7);
 if(vivo&&!F.corFim&&!CM.on)corCena();famSegue();if(F.interv&&!F.mask)maskDraw();
 if(F.interv&&F.famQuadra&&!F.mask&&!MK.ph&&Math.abs(px-150)<50)maskScene();
 if(F.interv&&px>306)irQuadra()}
function corCena(){CM.on=1;F.corFim=1;seq([['Você','A família já deve estar na Sala 1, a primeira porta à esquerda. Vou até lá.']])}
function sentado(k,x){const i=IM[k],h=(HH[k]||66)*.8,dy=k==='fernando'?4:10;
 rc('#5a3a22',x-12,FL-30,2,28);rc('#5a3a22',x+10,FL-30,2,28);rc('#5a3a22',x-12,FL-30,24,3);
 if(i&&i.complete&&i.naturalHeight){const w=i.naturalWidth/i.naturalHeight*h;if(k==='fernando'){g.save();g.translate(Math.round(x),0);g.scale(-1,1);g.drawImage(i,Math.round(-w/2),FL-4-h+dy,w,h);g.restore()}else g.drawImage(i,Math.round(x-w/2),FL-4-h+dy,w,h)}
 rc('#b8935c',x-13,FL-16,26,4);rc('#8a6a3d',x-11,FL-12,22,18)}
function sala1(){rc('#cdd2e2',0,0,320,FL);rc('#0b4fb3',0,92,320,8);
 for(let x=20;x<320;x+=100){rc('#8c96b8',x,0,34,5);rc('#fff',x+4,2,26,2)}
 rc('#8a6a3d',86,18,148,50);rc('#1f3d33',89,21,142,44);g.fillStyle='#e9f1e4';g.font='9px monospace';g.textAlign='center';g.fillText('Bem-vindos à Sala 1',160,46);g.textAlign='left';
 rc('#8c96b8',0,FL,320,34);for(let x=0;x<320;x+=32)rc('#7a85a8',x,FL,1,34);rc('#7a85a8',0,FL+16,320,1);
 rc('#082c66',4,FL-78,30,78);rc('#0b4fb3',7,FL-75,24,75);rc('#a8d4ff',11,FL-66,16,16);
 const al=F.interv?SALAF:1;if(al>0){g.globalAlpha=al;ES.ord.forEach((k,i)=>sentado(k,48+i*30));g.globalAlpha=1;if(F.interv)SALAF=Math.max(0,SALAF-.02)}}
function entrarSala1(){say('Você','A Sala 1. Todo mundo deve estar lá dentro.',[['Entrar na Sala 1',()=>{end();rm=S1;px=34;dir=1;$('dn').textContent=R[rm].n;save();if(F.interv){F.salaVazia=1;say('Você','Vazia. Todo mundo já saiu para o intervalo.')}}],['Ficar no corredor',end]])}
function sairSala1(){say('Você','Sair da Sala 1?',[['Voltar ao corredor',()=>{end();FQ.h=[];rm=COR;px=36;dir=1;$('dn').textContent=R[rm].n;save();}],['Ficar',end]])}
function falar(k){const l=JK[k],i=JI[k]||0,[al,pi,re]=l[i%l.length];JI[k]=i+1;seq([[NMS[k],pi],[NMS[al],re]],()=>{end();if(!F.interv&&ES.ord.every(x=>(JI[x]||0)>=5))intervalo()})}

function escola(){const s=g.createLinearGradient(0,0,0,160);s.addColorStop(0,'#86aacb');s.addColorStop(.6,'#c9d6d8');s.addColorStop(1,'#f6dcb4');g.fillStyle=s;g.fillRect(0,0,320,180);
 for(let i=0;i<4;i++){const x=((i*110+t*3)%420)-60,y=10+i*9;rc('rgba(255,255,255,.55)',x,y,48,5);rc('rgba(255,255,255,.45)',x+8,y-3,28,4)}
 if(ESI.complete&&ESI.naturalHeight)g.drawImage(ESI,0,0,320,161.5);
 rc('#95725b',0,158,320,22);rc('rgba(255,235,200,.12)',142,158,48,22);
 for(let x=0;x<320;x+=6){const h=hs(x,7);if(h<35)rc('rgba(0,0,0,.10)',x,162+hs(x,3)%14,3,1);else if(h>80)rc('rgba(255,235,200,.08)',x,164+hs(x,5)%12,4,1)}}
function toque(){const c=V8.ctx();if(!c)return;try{if(c.state==='suspended')c.resume();const t0=c.currentTime+.05;
 for(let r=0;r<5;r++)for(let b=0;b<4;b++){const s=t0+r*.95+b*.14;
  [1760,2349].forEach((fr,ix)=>{const o=c.createOscillator(),v=c.createGain();o.type=ix?'square':'triangle';o.frequency.value=fr;v.gain.setValueAtTime(.0001,s);v.gain.linearRampToValueAtTime(ix?.07:.2,s+.008);v.gain.exponentialRampToValueAtTime(.0005,s+.11);o.connect(v);v.connect(c.destination);o.start(s);o.stop(s+.12)})}}catch(e){}}
async function manha(){if(ES.run||F.escola)return;ES.run=1;busy=1;
 const f=$('fim'),el=$('ft');V8.onFim=null;$('fc').hidden=1;$('fb').hidden=1;el.textContent='';el.className='';
 f.style.transition='none';f.style.opacity=0;f.hidden=0;void f.offsetWidth;f.style.transition='opacity .9s';f.style.opacity=1;
 await esp(1000);el.className='alarme';el.textContent='⏰\n7:00 AM';toque();await esp(4500);
 el.className='';el.textContent='';
 for(const l of["O relógio não anda mais para trás.","Sete da manhã. A casa inteira acorda de uma vez.","Todo mundo se arruma, pega a mochila e sai para a escola."]){for(const ch of l){el.textContent+=ch;if(ch!==' ')tic();await esp(40)}el.textContent+='\n\n';await esp(650)}
 await esp(600);
 rm=ESR;F.escola=1;px=-12;dir=1;ES.h=[{x:-12,d:1}];ES.lx=-12;ES.go=0;ES.ent=[];ES.auto=1;ES.alvo=128;ES.cb=escolaIntro;$('dn').textContent=R[rm].n;save();
 f.style.transition='opacity 1.3s';f.style.opacity=0;await esp(1400);f.hidden=1;f.style.transition='';f.style.opacity='';el.textContent='';ES.run=0}
function escolaIntro(){seq([['Naty',"Chegamos! Essa é a frente da escola, aqui foi onde surgiu toda a família, antes do ocorrido..."],['Débora',"Precisa lembrar não"],['Guifer',"se acionar a tropa vai rolar resenha, td só sigilo, tudo no esquema..*Guifer cantando*."],['Naty',"Vai na frente. Todos nós seguimos você até o portão, é a escada bem no meio."]])}
function escolaEntrar(){if(ES.go||busy)return;
 seq([['Você',"me parece tranquilo"],['Naty',"Pode subir. A gente vai logo atrás de você."],['Guifer',"Bora, antes que o sinal bata!"]],()=>{end();busy=1;
  const e=[{k:'você',x:px,d:dir}];
  ES.ord.forEach((k,i)=>{const idx=ES.h.length-1-(i+1)*LAG;let x,d;if(idx>=0){x=ES.h[idx].x;d=ES.h[idx].d}else{x=(ES.h[0]||{x:px}).x+idx*1.6;d=1}e.push({k,x,d})});
  e.forEach((o,j)=>{o.y=ESY;o.s=1;o.a=1;o.st='ir';o.u=0;o.delay=j*14;o.tx=SX+(j%3-1)*4});
  ES.ent=e;ES.go=1})}
function escolaSobe(){const E=ES;let vivos=0;
 E.ent.forEach(o=>{if(o.st==='fim')return;vivos++;
  if(o.delay>0){o.delay--;return}
  if(o.st==='ir'){const dx=o.tx-o.x;if(Math.abs(dx)<1.6){o.x=o.tx;o.st='sobe';o.u=0}else{o.x+=Math.sign(dx)*1.6;o.d=Math.sign(dx)}}
  else{o.u++;o.y=ESY-o.u*.5;const p=o.u/44;o.s=1-.2*p;o.a=1-Math.max(0,(p-.45)/.55);if(o.u>=44)o.st='fim'}});
 E.ent.filter(o=>o.st!=='fim').sort((a,b)=>a.y-b.y).forEach(o=>{g.save();g.globalAlpha=Math.max(0,o.a);g.translate(o.x,o.y);g.scale(o.s,o.s);spr(o.k,0,0,o.st==='ir'&&o.delay<=0,o.k==='fernando'?-o.d:o.d);g.restore()});
 if(!vivos&&E.go===1){E.go=2;escolaFim()}}
function escolaDraw(){const E=ES;
 if(E.auto){if(px<E.alvo){px+=1.6;dir=1}else{E.auto=0;const f=E.cb;E.cb=null;if(f)f()}}
 if(E.go)return escolaSobe();
 const mv=Math.abs(px-E.lx)>.01;if(mv){E.h.push({x:px,d:dir});if(E.h.length>600)E.h.splice(0,100)}E.lx=px;E.mv=mv;
 for(let i=E.ord.length-1;i>=0;i--){const idx=E.h.length-1-(i+1)*LAG;let x,d;if(idx>=0){x=E.h[idx].x;d=E.h[idx].d}else{x=(E.h[0]||{x:px}).x+idx*1.6;d=1}spr(E.ord[i],x,ESY-1,mv,E.ord[i]==='fernando'?-d:d)}
 spr('você',px,ESY,mv,dir)}
async function escolaFim(){const f=$('fim'),el=$('ft');
 F.escFim=1;F.frs.push('Manhã: às 7:00 o relógio tocou e a família Ailton\'s inteira foi para a escola, seguindo você até o portão.');save();
 el.textContent='';el.className='';$('fc').hidden=1;$('fb').hidden=1;$('fb').textContent='Entrar na escola';
 f.style.transition='none';f.style.opacity=0;f.hidden=0;void f.offsetWidth;f.style.transition='opacity 1.4s';f.style.opacity=1;
 V8.onFim=null;V8.onFb=()=>{f.hidden=1;f.style.transition='';f.style.opacity='';V8.onFim=V8.onFb=null;ES.go=0;ES.ent=[];move(COR,'l');end()};
 await esp(1500);
 for(const l of["Você sobe a escada do meio.","Atrás de você, um a um, a família Ailton's atravessa o portão da escola.","O sinal toca."]){for(const ch of l){el.textContent+=ch;if(ch!==' ')tic();await esp(46)}el.textContent+='\n\n';await esp(700)}
 $('fc').hidden=0;$('fb').hidden=0}
const CH={
melina:{n:'Quarto da Melina',o:"Oiiii! Bem-vindo ao meu cantinho rosa! Pode olhar tudo, só não pisa no tapete de coração, ksksks.",m:"Quarto da Melina: você ouviu a Mel contar tudo sobre o rosa, o ursinho e o sonho da mesa grande.",q:[["Seu quarto é lindo! Por que tanto rosa?","Ksksks, rosa é a cor que me abraça! Quando cheguei aqui com 2 anos, minha primeira coberta era rosa. Acho que nunca larguei."],["O que são essas luzinhas?","São meus vagalumes de mentirinha! Acendo todas as noites. Parece que o quarto fica respirando junto comigo."],["Como foi chegar aqui com 2 anos?","Eu nem lembro, só as fotos! Dizem que eu falava um mix de duas línguas. Até hoje escapa uma palavrinha, ksks."],["Sente falta do lugar onde nasceu?","Um pouquinhooo. Não da cidade, mas da ideia dela. Por isso tenho mapa e globo, para não esquecer de onde vim."],["Quem é o ursinho na cama?","O Sr. Algodão! Está comigo há mais tempo que qualquer amigo. Sabe todos os meus segredos e não conta nada."],["Por que pediu o texto das salas azuis?","Porque às 11:03 da noite percebi que a gente se perdeu um pouco. Escrevi para lembrar que ainda dá tempo de voltar."],["O que faz na penteadeira?","Penteio o cabelo, escolho a cor do dia e treino sorrisos. Todo mundo acha que é vaidade, mas é minha hora de calma."],["Qual é o seu maior sonho?","Reunir todo mundo numa mesa grande, sem pressa e sem celular. Um jantar que dure a noite inteira, ksksks."],["O que mais gosta no grupo?","Que ninguém me julga quando eu falo errado. O Fernando corrige, mas com carinho. Aqui eu nunca fui estrangeira."],["Posso voltar a visitar você?","Claro! A porta rosa nunca tranca. Traz o grupo todo e eu faço chá com biscoito. Prometo falar certinho. Ou quase."]]},
yuri:{n:'Quarto do Yuri',o:"Opa, entra! Cuidado com a bola no chão. Aqui é o meu QG, tranquilo e verde-amarelo.",m:"Quarto do Yuri: você conheceu o QG da seleção, as camisas da sorte e a taça de segundo lugar.",q:[["Que quarto é esse, Yuri?","O meu QG! Bandeira, camisas, taça e uma bola. Tudo que um cara tranquilo precisa para viver bem."],["Por que a seleção?","Meu avô me deu a primeira camisa aos cinco anos. Desde então, jogo da seleção é feriado nacional aqui dentro."],["Essas camisas são todas suas?","Todas! Cada uma é de uma Copa que eu vi. Se uma não está lavada, é porque deu sorte e não pode lavar."],["Por que põe a mão no bolso?","Hábito! Dizem que é pose de tranquilo. Na verdade é para esconder o nervoso. Mas não conta para ninguém."],["Qual foi o seu melhor gol?","Uma bicicleta no campinho do Erick, no escuro. Ninguém viu, então só eu acredito. Mas foi lindo, juro."],["Quem joga melhor no grupo?","O Erick tem a luva e a marra, eu tenho a estratégia. A Lara desenha melhor que nós dois. Não vale comparar."],["O que significa a taça?","É do torneio da família! Fiquei em segundo. Mas coloquei na vitrine porque segundo lugar com amigos vale ouro."],["Fica nervoso em dia de jogo?","Demais. Aí lembro que o jogo dura noventa minutos e os amigos duram a vida inteira. Aí acalma."],["O que faria sem o futebol?","Treinaria a escada da torre, ora! Brincadeira. Sentiria falta do barulho da torcida, mesmo sendo só a família."],["Posso treinar com você?","Claro! Bola, campinho, amanhã cedo. Leva água e boa vontade, o resto eu ensino. Chego sempre a tempo, lembra?"]]},
lara:{n:'Quarto da Lara',o:"Oie! Bom oia... perai, ata, entra! Cuidado com as tintas no chão, ksks.",m:"Quarto da Lara: você conheceu o ateliê azul, o pigmento lazuli e o jeito de desenhar sem levantar a mão.",q:[["Esse quarto é um ateliê?","É sim, Lazuli style! Mesa de desenho, varal de rascunhos e um pote de azul. Desenhar aqui me deixa menos... bom, lerda, ksks."],["Por que te chamam de Lazuli?","Por causa do pigmento azul-escuro. Meu pai disse que eu brilho baixinho, mas brilho. Peguei o apelido e fiquei."],["Por que chama seu pai de Sensei?","Ele me ensinou a segurar o lápis, a olhar antes de traçar e a esperar a hora certa. Pai é pai, mas Sensei é Sensei."],["Lembrou do que ia dizer?","Ata, lembrei! Era sobre o meu pincel azul. Quando esqueço, rabisco na palma da mão. Às vezes esqueço de olhar."],["Te chamam de lerda mesmo?","Chamam, e eu rio junto. Mas lerda também é devagar para perceber o que importa. E eu percebo bem os amigos."],["Qual é a sua melhor técnica?","O traço sem levantar a mão! Um risco só, do começo ao fim. A vida tem curva demais, melhor aprender a desenhar com ela."],["O que diz o desenho emoldurado?","Só uma palavra: Sensei. Meu pai escreveu com pincel embaixo do meu primeiro desenho e eu emoldurei. Demorei para entender por que é só uma."],["Pode falar do Fernando?","Ele é... bom, deixa pra lá! Brincadeira. Ele é chato e engraçado, e eu o defendo até de mim mesma."],["Desenha todo dia?","Todo dia! Mesmo sem ânimo, eu pego o lápis e faço um rabisco de cinco minutos. Cinco viram trinta. O difícil é começar."],["Posso desenhar com você?","Claro! A mesa é de todo mundo. Pega um lápis que eu te ensino a fazer sombra sem borrar. O resto a gente descobre."]]},
guifer:{n:'Quarto do Guifer',o:"E aí! Entra, mas sem pisar no tênis, hein? Esse é o meu closet com cama.",m:"Quarto do Guifer: você viu o closet, os tênis limpinhos e ouviu sobre o topete rebelde.",q:[["Que quarto estiloso! O que tem aqui?","Meu closet com cama! Tênis, cabides e um espelho gigante. Quem sai de casa arrumado sai feliz também."],["Por que os tênis são tão limpinhos?","Segredo de família: escova, sabão neutro e nunca pisar em poça. Se pisou, o tênis vira pedido de desculpas."],["O que tem nos bolsos da cargo?","Chaves, fone, chiclete, um bilhete da sorte e um canivete de mentirinha. Sempre tem bolso para o inesperado."],["O topete nunca obedece?","Nunca! Já tentei gel, spray e reza. Ele manda em mim. A gente se entende: eu deixo ele em paz."],["Você é o anfitrião do Grande Salão?","Sou! Recebo todo mundo e já deixo a mesa pronta. Quem é bem recebido sempre volta."],["Qual é o seu look favorito?","Polo preta, cargo e tênis branco. Simples, mas parece que eu me esforcei. Esse é o truque."],["Quem é o mais estiloso da família?","A Débora, sem dúvida: tudo preto e combina com tudo. Eu venho logo atrás, nem tão atrás assim, ksks."],["Por que chega cedo nas festas?","Porque o melhor da festa é o começo: som baixo, cadeiras vazias e a certeza de que todo mundo vai chegar."],["O espelho ajuda em quê?","Me lembra de sorrir antes de sair. Meu sorriso é o melhor acessório e ainda é de graça!"],["Pode me dar um conselho de estilo?","Pode! Regra um: roupa boa é a que você esquece que está vestindo. Regra dois: tênis branco, sempre limpinho."]]},
naty:{n:'Quarto da Naty',o:"Seja bem-vindo ao meu quarto! A chaleira acabou de apitar. Sente-se, a conversa pede calma.",m:"Quarto da Naty: você tomou chá com a anfitriã e ouviu por que as horas ficam no castelo.",q:[["Seu quarto parece um salão de chá.","É meu cantinho de recepção! Aqui eu treino as boas-vindas: chá quente, sino na mesa e uma cortina que nunca fecha."],["O que é esse sino?","Toco quando chega alguém querido. Cada toque é um abraço sem sair do lugar. Quer tocar? Só um toquinho."],["Por que a música toca no castelo?","Ela toca para quem chega de coração tranquilo. Se você está ansioso, ela fica mais baixinha para te acalmar."],["Por que as horas ficam aqui?","Porque aqui a gente não conta as horas, conta as histórias. Cada hora que passa vira uma lembrança guardada."],["Como você apresenta a família?","Com carinho e um pouco de suspense. Cada um é um capítulo, e eu só digo o título para você ler com calma."],["Qual é o seu chá favorito?","Camomila com mel e uma folhinha de hortelã. Serve para dias ruins e para dias bons também."],["Sente solidão no portão?","Às vezes, quando demora. Mas o portão aberto me lembra: quem sai pode voltar. Aí eu fico em paz."],["O que mais quer para a família?","Que a mesa encha de novo. Não precisa ser todo dia. Só que, quando encher, a gente lembre de rir alto."],["Qual foi a visita mais especial?","A sua! Não é puxa-saco, não. Você andou pelo castelo inteiro, ouviu todos e ainda ajudou. Raro."],["Posso tomar um chá com você?","Claro! Senta, a chaleira já apitou. Conversa boa pede xícara cheia e tempo de sobra."]]},
alinny:{n:'Quarto Noturno da Alinny',o:"Ah... oi. Entra, desculpa a bagunça de cadernos. A luz fica acesa, tá?",m:"Quarto da Alinny: você ouviu sobre estudos, música e sentimentos difíceis de nomear.",q:[["Seu quarto é lindo. Você estuda aqui?","Obrigada... Estudo, escuto vinil e às vezes só fico olhando o teto. Aqui eu faço tudo isso sem pedir desculpa."],["Que música está tocando?","Uma playlist sem nome. Tem coisa triste, coisa animada e coisa que não sei explicar. Igual a mim... desculpa."],["Por que muda tanto de humor?","Ainda estou aprendendo a ler meus sentimentos. Às vezes sinto tudo e não sei o nome. Não leva a mal, tá?"],["Gosta mais de estudar ou de música?","Música me acalma, estudo me organiza. Sem uma, a outra não funciona. Estudo com fone, no volume baixinho."],["Por que a lâmpada nunca apaga?","Porque o silêncio no escuro pesa. Com luz acesa eu penso melhor. Acho que a luz também ouve."],["Posso ler seu caderno?","Uma página! Tem fórmula, letra de música e um desenho do Yuri de bermuda azul. Não conta para ele."],["Sente falta de algo?","Das tardes em que todo mundo estava online ao mesmo tempo. Parecia que a casa respirava junto. Hoje é mais silencioso."],["O que faz quando está mal?","Coloco uma música lenta, respiro fundo e escrevo uma frase. Uma só. Depois outra. Aos poucos o nó solta."],["Qual é a sua música favorita?","Não consigo escolher! Mas se fosse um som, seria um piano tocando devagar no fim da tarde."],["Posso te visitar de novo?","Pode, sim. Eu demoro para abrir, mas quando abro, abro de verdade. Obrigada por vir... e desculpa por pedir desculpa."]]},
debora:{n:'Quarto da Débora',o:"Oi! Entra, mas não encosta nas telas, ainda estão úmidas. Meu ateliê é preto, mas a conversa é colorida.",m:"Quarto da Débora: você viu o ateliê de molduras e ouviu sobre tranças, preto e retratos.",q:[["Que quarto é esse, Débora?","Meu ateliê! Molduras na parede, cavalete no canto e um espelho para ver o quadro de longe. Preto de fundo, cor no centro."],["Por que ama preto?","Porque o preto não briga com nada. Deixa tudo ao redor brilhar. Igual a mim: fico de fundo, mas sustento o quadro."],["Como faz as tranças?","Com paciência e um bom filme de fundo. Levam horas, mas cada uma conta uma história."],["E o aparelho nos dentes?","É meu acessório favorito! Já ganhou até apelido: chega antes de mim. Quando tirar, vou sentir falta."],["O que tem nas molduras?","Rostos da família. Só pinto quem já conheci direito. As molduras vazias esperam gente nova."],["Qual retrato foi o mais difícil?","O do Fernando! Não parava quieto e queria aparecer jogando. Resolvi pintar o neon dele ao fundo."],["Pinta pessoas ou lembranças?","Lembranças com rosto. Um retrato bom não mostra só o olhar, mostra o dia em que a pessoa riu."],["Qual cor nunca usa?","Cinza. Acho meio sem decisão. Prefiro o preto firme ou um vermelho que grita. Meio-termo me dá sono."],["Posso ganhar um retrato meu?","Já tem moldura esperando! Preciso só de uma tarde, um sorriso sincero e você sentado sem mexer. Difícil, eu sei."],["Posso voltar ao ateliê?","Pode vir sempre. Traga lanche ou tinta, os dois são bem-vindos. Pintura nova nasce de conversa boa."]]},
fernando:{n:'Quarto do Proviso',o:"Eaeee! Tchooo! Entra no QG do Proviso! Cuidado com o sofá, ele tem dono.",m:"Quarto do Proviso: você conheceu o QG gamer, o neon rosa e o orgulho do mais pika do grupo.",q:[["Seu quarto parece uma central gamer!","É o QG do Proviso! TV gigante, sofá afundado e neon rosa. Só falta a pizza chegar pela janela."],["Por que te chamam de Proviso?","Ah, tchooo, é história longa: o apelido pegou num dia e ficou. Hoje até meu personagem se chama Proviso."],["GTA 6 ou Red Dead?","Red Dead pela história, GTA pela bagunça. Mas nenhum ganha de zerar com os amigos do lado."],["Quem joga melhor no grupo?","Eu, óbvio! Tchooo. O Yuri é bom no futebol, a Lara desenha até o jogo inteiro, mas controle na mão é comigo."],["O que aconteceu com o controle?","Sumiu e foi parar na biblioteca. Até hoje não sei como. Alguém me trollou. Suspeito da Lara."],["Por que se acha o mais pika?","Porque confiança é meio caminho andado! Se eu não acreditar em mim, quem vai? O resto é carisma."],["A Lara disse para tomar cuidado com você.","Ahhh, ela exagera! Eu só provoco com carinho. Se ela cai, eu levanto. Se eu caio, ela ri. Justo."],["O que significa o neon PROVISO?","É meu cartão de visita. Rosa pisca, rosa chama atenção. Quem passa já sabe que tem gente jogando firme."],["Qual jogo marcou sua infância?","Um de carrinho, com a família toda no sofá. A gente brigava pelo controle, mas ria o tempo todo."],["Joga uma partida comigo?","Bora! Pega o controle azul, o outro é meu. Aviso: eu ganho. Se perder, a culpa é do lag, claro."]]},
erick:{n:'Quarto do Erick',o:"Eae, de boa? Entra aí. Esse é o meu campinho particular, só não chuta a bola na vitrine.",m:"Quarto do Erick: você viu o campo, a camisa 19 e conversou com o goleiro do castelo.",q:[["Que quarto é esse, Erick?","Meu campinho particular. Trave, bola, taça e a camisa 19 na parede. Só falta a torcida, mas ela está no meu coração."],["Por que te chamam de 19 pontos?","Fiz 19 pontos num jogo sozinho. Ninguém acreditava, então virou apelido. Foi o melhor dia da minha vida."],["Você joga de goleiro?","Goleiro, sim! Defendo tudo, até o que não era para defender. Minhas luvas voltaram e o campinho ficou completo."],["O que é a máquina de tigrinho?","Cilada! Me ensinou que quem aposta quase sempre perde. Deixei ali de lembrete: a casa sempre ganha."],["Por que não fala da sua casa?","Porque às vezes é pesado. Mas aqui no castelo eu respiro. Se eu quiser falar, falo. Valeu por não forçar."],["Qual foi a melhor defesa?","Um pênalti no último minuto, no campinho. Pulei tarde, mas a mão foi mais rápida que a cabeça. Todo mundo gritou."],["Quem é seu melhor amigo do grupo?","Falar um só é injusto! O Yuri joga comigo, a Marcela escuta, o Fernando me tira do sério e eu amo todos."],["Tem ritual antes do jogo?","Calço a luva esquerda primeiro, bato três vezes no peito e olho para a trave. Se esquecer, perco a sorte."],["Qual é o seu sonho no futebol?","Jogar profissional e dedicar o gol à minha família do castelo. Pode ser clichê, mas é verdade."],["Posso chutar uns pênaltis com você?","Bora! Mas vou defender todos. Brincadeira... talvez um ou dois passem. Se passar, eu pago o lanche."]]},
marcela:{n:'Quarto da Marcela',o:"Oii! Entra, entra! Fala baixinho que o bebê acabou de dormir. Pode sentar onde quiser.",m:"Quarto da Marcela: você ouviu sobre lealdade, fotos, plantinhas e o bebê da família.",q:[["Que quarto aconchegante!","É a casa de todo mundo! Fotos nas paredes, sofá largo, plantinha e um bercinho no canto. Quem chega já é da família."],["De quem é o bebê?","Do carinho de todo mundo. Pode chamar de nosso. Quando ele acorda, o castelo inteiro acorda junto."],["Obrigado por confiar na mamadeira.","Imagina! Você mostrou que cuida. Quem cuida de um bebê cuida de qualquer pessoa. Isso vale ouro."],["Por que é tão leal?","Porque amizade é escolha diária. Eu escolhi cada um deles e não pretendo trocar. Se precisar, eu estarei lá."],["O que são as fotos do mural?","Os melhores dias! Tem foto borrada, foto engraçada e uma em que ninguém abriu os olhos. Perfeitas."],["Quem cuida da plantinha?","Eu! Rego todo dia com música baixinha. Planta que ouve música cresce mais feliz, diz minha avó."],["Qual foi o momento mais engraçado?","Quando o Erick virou 19 pontos. Expliquei o apelido para todo mundo e ele ficou vermelho. Valeu cada risada."],["O que faz quando alguém está triste?","Sento do lado, em silêncio, e ofereço lanche. Às vezes a pessoa só precisa de companhia, não de conselho."],["O que mais deseja para a família?","Que a gente nunca esqueça de marcar encontro. Pode ser pizza, pode ser só café. Contanto que seja junto."],["Posso contar com você?","Sempre. Pode ligar de madrugada, mandar mensagem ou aparecer sem avisar. Aqui o sofá é largo e a porta é aberta."]]}};
// Conversa com os 10 papos de cada personagem, direto na caixa de diálogo (sem telão).
// As perguntas vêm uma por uma; dá para ir para a próxima, refazer a mesma ou voltar à anterior.
function papo(id){const k=CH[id],c=NPC[id],d=F.pp[id]=F.pp[id]||[],N=k.q.length;
  const prox=i=>{for(let j=1;j<=N;j++){const n=(i+j)%N;if(!d.includes(n))return n}return(i+1)%N};
  const first=()=>{const n=k.q.findIndex((_,j)=>!d.includes(j));return n<0?0:n};
  const ask=i=>{const[q,a]=k.q[i];let novo=0;if(!d.includes(i)){d.push(i);novo=1}save();
    const opts=[['Próxima pergunta ('+d.length+'/'+N+')',()=>ask(prox(i))],['Refazer esta pergunta',()=>ask(i)]];
    if(i>0)opts.push(['Voltar à pergunta anterior',()=>ask(i-1)]);
    opts.push(['Encerrar conversa',end]);
    say('Você',q,null,()=>{
      if(novo&&d.length===N){F.frs.push(k.m);save();say(c.nome,a,null,()=>say('Anotação',k.m,opts))}
      else say(c.nome,a,opts)})};
  say(c.nome,k.o,[['Conversar ('+d.length+'/'+N+' perguntas)',()=>ask(first())],['Sair',end]])}
const NPC={
naty:{nome:'Naty',fala:"Você chegou! Eu sou a Naty. Hoje eu vou apresentar a família Ailton's para você.",
 a:['Prazer, Naty!',"O prazer é meu! Ouviu a música? Ela toca para quem chega de coração tranquilo."],
 b:['Que castelo é este?',"A casa da família Ailton's. Cada cômodo guarda uma lembrança boa, dessas que a gente quer manter."],
 extra:["Dizem que você veio de um lugar onde as horas se perdem. Aqui elas ficam, eu prometo.","Siga em frente até o Grande Salão. O Guifer está lá, e ele adora se apresentar.","Depois visite a Galeria e a Torre do Relógio. A família está só começando a chegar."],
 nota:"Naty: recebe quem chega ao Pátio do Castelo e apresenta a família Ailton's.",
 depois:()=>(F.ch.naty==='a'?'Que bom que você ficou! ':'Ainda curioso? ')+(F.met.guifer&&F.met.debora?(F.met.yuri?'Que bom que você está aqui! Ainda tem mais gente da família pelo castelo.':'Já conheceu o Guifer e a Débora? Então é só subir à Torre do Relógio e seguir pela escada. Tem alguém esperando lá em cima.'):F.met.guifer?'Já conheceu o Guifer? A Débora está na Galeria dos Retratos, cuidando das molduras.':'O Grande Salão fica logo à direita. O Guifer está esperando.')},
guifer:{nome:'Guifer',
 intro:["E aí! Eu sou o Guilherme, mas pode me chamar de Guifer.","Deixa eu me descrever direito: cabelo castanho, curto, com um topete que nunca obedece o pente.","Hoje estou de camisa polo preta, com a gola listrada de branco e uma estampa clara na lateral.","Calça cargo preta, cheia de bolso, e tênis branco, sempre limpinho. Sorriso de quem chegou cedo para a festa."],
 fala:"Pronto, essa é a minha descrição. E aí, o que achou?",
 a:['Gostei do estilo!',"Valeu! Os bolsos da cargo guardam mais coisa do que parece."],
 b:['Você é da família?',"Sou sim: um dos Ailton's. A Naty apresenta a casa, eu apresento o resto de mim."],
 extra:["Quando conhecer os outros, volte aqui. Tem lugar na mesa para todo mundo."],
 nota:"Guifer (Guilherme): cabelo castanho curto com topete, polo preta, calça cargo e tênis branco. Recebe os visitantes no Grande Salão.",
 depois:()=>F.ch.guifer==='a'?'Os bolsos da cargo ainda guardam surpresa. Pergunte de novo depois.':'A mesa ainda tem lugares vazios. Logo, logo enche.'},
debora:{nome:'Débora',
 intro:["Oi! Eu sou a Débora. Cuido da Galeria dos Retratos, e hoje vou me apresentar direito.","Tranças longas e pretas, que descem quase até a cintura. Cada uma é feita com muita paciência.","Estou de camiseta preta, calça preta justa e tênis preto sem cadarço. Eu sei, eu amo preto, mas combina com tudo.","E o detalhe mais importante: meu sorriso de aparelho. Ele chega antes de mim em qualquer lugar."],
 fala:"Pronto, essa sou eu. O que você achou?",
 a:['Adorei as tranças!',"Obrigada! Dá trabalho, mas vale cada trança."],
 b:['Você é da família?',"Sou sim: a Débora dos Ailton's. Eu cuido das molduras até todo mundo chegar."],
 extra:["Esta moldura aqui ficou pronta para mim. Olha só, já está até sorrindo.","A Torre do Relógio só abre para quem conheceu toda a família. Falta pouco."],
 nota:"Débora: tranças longas e pretas, sorriso de aparelho, camiseta e calça pretas, tênis preto. Cuida da Galeria dos Retratos.",
 depois:()=>F.ch.debora==='a'?'As tranças agradecem! Já passou pela Torre do Relógio?':'A moldura já tem o meu rosto. A Torre do Relógio espera por você.'},
yuri:{nome:'Yuri',
 intro:["Opa! Você subiu rápido. Eu sou o Yuri e fico de olho nesta escada.","Deixa eu me descrever: cabelo curto e escuro, daquele corte baixinho que não dá trabalho nenhum.","Estou com a camisa branca da seleção: gola e punhos azuis, o escudo no peito com as estrelas em cima e a palavra BRASIL escrita embaixo.","Bermuda azul, tênis azul com detalhes brancos e uma mão sempre no bolso, porque eu sou assim: tranquilo."],
 fala:"Pronto, esse sou eu. E aí, o que achou?",
 a:['Gostei da camisa!',"Valeu! Ela dá sorte, principalmente em dia de jogo."],
 b:['Você é da família?',"Sou sim: o Yuri dos Ailton's. Eu sempre chego a tempo do gol."],
 extra:["Agora você já conhece a Naty, o Guifer, a Débora e eu.","A porta lá no alto leva ao resto da família. Pode ir, eles te esperam."],
 nota:"Yuri: cabelo curto e escuro, camisa branca da seleção com gola azul, bermuda e tênis azuis, mão no bolso. Espera no alto da escada da torre.",
 depois:()=>F.ch.yuri==='a'?'A camisa continua dando sorte. Vai lá, a porta do alto leva ao resto da família.':'A porta do alto leva ao resto da família. É toda sua.'},
lara:{nome:'Lara',cor:{ro:'#2a4a9a',ca:'#2a1a1a',pe:'#e8c4a0'},lines:["Oie! Bom oia, perai.. ata lembrei!","Eu sou Lara, conhecida por ser um pouco lerda ou besta como dizem!","Adoro desenhar! Aprendi com meu pai Ailton, que às vezes chamo de Sensei. Você também pode me conhecer pelo apelido Lazuli!","Toma cuidado com Fernando, ele é.... Bom deixa pra lá!"],nota:"Lara (Lazuli): um pouco lerda ou besta, como dizem. Adora desenhar. Adora o pai Ailton e às vezes o chama de Sensei.",depois:"Toma cuidado com Fernando, ele é.... Bom deixa pra lá!"},
fernando:{nome:'Fernando',cor:{ro:'#1a1a1a',ca:'#3a2a1a',pe:'#d8b090',ac:'#e03090'},lines:["Eaeee! Tchooo!? Prazer, pode me chamar de proviso!","Eu amo GTA 6 e Red dead!","Sou um dos membros mais pika desse grupo e não tem outro igual a mim!"],nota:"Fernando (proviso): ama GTA 6 e Red Dead e se acha o membro mais pika do grupo.",depois:"Sou um dos membros mais pika desse grupo e não tem outro igual a mim!"},
erick:{nome:'Erick Silva',cor:{ro:'#2a8a3a',ca:'#1a1a1a',pe:'#c89870',ac:'#e8d040'},lines:["Eae caralho..de boa? Meu nome é Erick..","Gosto de futebol, na minha casa, meus pais...deixa pra lá.","É isso fdp, tá olhando o que? Cuidado com a jogadora de tigrinho..ali do lado."],nota:"Erick Silva (19 pontos): gosta de futebol e não quer falar sobre a casa e os pais.",depois:"É isso fdp, tá olhando o que? Cuidado com a jogadora de tigrinho..ali do lado."},
marcela:{nome:'Marcela',cor:{ro:'#c04a8a',ca:'#4a2a1a',pe:'#d8a888'},lines:["Oii! Você provavelmente acabou de passar pelos 19 pontos, né? Ah não? É o apelido do Erick.","Meu nome é Marcela!","Sou uma amiga muito leal, vou tá com você sempre que precisar!"],nota:"Marcela: amiga muito leal, vai estar com você sempre que precisar.",depois:"Sou uma amiga muito leal, vou tá com você sempre que precisar!"},
alinny:{nome:'Alinny',cor:{ro:'#6a4aa8',ca:'#2a1a2a',pe:'#e0b898',ac:'#e8e8f0'},lines:["Meu Deus! Você demorou tanto pra chegar aqui, já tava desistindo...desculpa.","Sou Alinny, adoro passar o dia todo estudando e ouvindo música!","Eu..ainda não entendo bem meus sentimentos então não se assusta se eu mudar de humor.."],nota:"Alinny: passa o dia estudando e ouvindo música, e muda de humor porque ainda não entende bem os próprios sentimentos.",depois:"Eu..ainda não entendo bem meus sentimentos então não se assusta se eu mudar de humor.."},
melina:{nome:'Melina',cor:{ro:'#e08a3a',ca:'#5a3a1a',pe:'#e8c4a8'},lines:["Oiiiii! Adorou o texto ali? eu quem pedi para escrever isso às 11:03 PM!","Eii! Deixe-me apresentar pra ti!","Ah, e só pra deixar claro: eu não sou dos Ailton's, eu sou da família 2, tá? Ksksks.","Eu sou Mel, nasci fora do Brasil e aos 2 anos de idade cheguei aqui! Por isso não acha estranho se eu falar um pouquinhooo errado ksksks."],nota:"Melina (Mel): não é da família Ailton's, e sim da família 2. Nasceu fora do Brasil e chegou aqui aos 2 anos. Foi ela quem pediu o texto das salas azuis, às 11:03 PM.",depois:"Não acha estranho se eu falar um pouquinhooo errado ksksks."},
thunine:{nome:'Thunine',cor:{ro:'#555566',ca:'#222222',pe:'#c8a888'},lines:["Opa! De boa Man?","Não tenho muito o que falar sobre mim não, pode passar pro próximo."],nota:"Thunine: não tem muito o que falar sobre si e prefere que você passe para o próximo.",depois:"Não tenho muito o que falar sobre mim não, pode passar pro próximo."},
ruby:{nome:'Ruby',cor:{ro:'#a01030',ca:'#6a0a14',pe:'#e0b8a0'},lines:["Hum? A eae?","Lembra do relógio que anda para trás lá no início? Ele quer voltar no tempo."],nota:"Ruby: diz que o relógio que anda para trás, lá do início, quer voltar no tempo.",depois:"Lembra do relógio que anda para trás lá no início? Ele quer voltar no tempo."},
stella:{nome:'Stella',cor:{ro:'#2a8a8a',ca:'#1a1a2a',pe:'#d8b098',ac:'#e8e8e8'},lines:["Oioi, prazer, eu era ou sou a OBS da equipe, ou pra você \"família 2\"","recentemente estou investigando o desaparecimento de uma garota que eu odeio.."],nota:"Stella: era ou é a OBS da equipe, a \"família 2\". Investiga o desaparecimento de uma garota que odeia.",depois:"Recentemente estou investigando o desaparecimento de uma garota que eu odeio.."},
padre:{nome:'Padre',cor:{ro:'#111111',ca:'#cfcfcf',pe:'#e0c0a0',ac:'#f0f0f0'},lines:["Sou um clássico! Posso rezar pela sua alma?","Por favor, meninas, entrem, homens não! Hehe.","Falando nisso, já reparou que a vida do criador do jogo é cheia de mulheres? Ainda me pergunto como ele faz isso.."],nota:"Padre: um clássico, oferece rezar pela sua alma. Acha a vida do criador do jogo cheia de mulheres.",depois:"Posso rezar pela sua alma?"}};
/* ============ motor ============ */
function say(n,tx,ch,next){busy=1;$('dn').textContent=n;V8.type(tx);const b=$('ch');b.innerHTML='';
 if(ch){$('dlg').onclick=null;ch.forEach(([l,f])=>{const x=document.createElement('button');x.textContent=l;x.onclick=e=>{e.stopPropagation();f()};b.append(x)})}
 else $('dlg').onclick=next||end;V8.wrap()}
function end(){RV=0;busy=0;$('ch').innerHTML='';$('dn').textContent=R[rm].n;$('dt').textContent='…';$('dlg').onclick=null;save()}
function seq(a,done){let i=0;const s=()=>{if(i>=a.length)return done?done():end();const[n,x]=a[i++];say(n,x,null,s)};s()}
let MG=null,TEMA=null,TG=null,TV=0,TI=0,TO=0;const TEMA_SRC="assets/audio_01.mp3";
function tema(on_){TO=on_;
 if(!TEMA){if(!on_)return;TEMA=new Audio(TEMA_SRC);TEMA.loop=true;try{const c=V8.ctx();if(c){TG=c.createGain();TG.gain.value=0;c.createMediaElementSource(TEMA).connect(TG);TG.connect(c.destination)}else TEMA.volume=0}catch(e){TG=null;TEMA.volume=0}}
 try{const c=V8.ctx();if(c&&c.state==='suspended')c.resume();if(MG)MG.gain.setTargetAtTime(on_?0:.8,A.currentTime,1.5);if(TG)TG.gain.setTargetAtTime(on_?.7:0,c.currentTime,1.5)}catch(e){}
 if(on_)TEMA.play().catch(()=>{});clearInterval(TI);
 if(TG){if(!on_)TI=setTimeout(()=>{if(!TO)TEMA.pause()},7000);return}
 const alvo=on_?.7:0;TI=setInterval(()=>{TV+=(alvo-TV)*.05;TEMA.volume=Math.min(1,Math.max(0,TV));if(Math.abs(alvo-TV)<.01){TV=alvo;TEMA.volume=alvo;clearInterval(TI);if(!on_)TEMA.pause()}},100)}
let MGC=null;
const DI={timing:'Toque em “Agora!” quando a barra passar pelo verde.',quiz:'Acerte pelo menos duas perguntas.',pen:'Escolha onde chutar. Faça 2 gols em 3 chutes.',mem:'Encontre todos os pares.',simon:'Observe a sequência e repita.'};
const MGS={
5:{o:'mesadesenho',t:'timing',n:'Traço certeiro',hits:3,spd:.9,w:.22,m:'Sala do Lazuli: você acertou o traço na mesa de desenho, sem borrar.'},
6:{o:'tv',t:'quiz',n:'Quiz do Proviso',need:2,q:[["Qual é o apelido do Fernando?",["Proviso","Provão","Provinha"],0],["Quem é o “19 pontos”?",["Guifer","Erick","Yuri"],1],["Qual é o nome do pai da Lara?",["Alberto","Ailton","Arlindo"],1]],m:'Quarto do Fernando: você mandou bem no quiz do Proviso.'},
7:{o:'gol',t:'pen',n:'Pênaltis no campinho',m:'Campinho do Erick: você fez gol nos pênaltis.'},
8:{o:'fotos',t:'mem',n:'Mural de fotos',e:['🐱','🎮','⚽','🍼'],m:'Sala da Marcela: você juntou todos os pares do mural de fotos.'},
9:{o:'notas',t:'simon',n:'Notas da Alinny',s:['♪','♫','♩','♬'],n2:4,m:'Quarto da Alinny: você repetiu a melodia que flutua no ar.'},
19:{o:'escrivaninha',t:'quiz',n:'Charada da biblioteca',need:2,q:[["Que letra está bordada no estandarte azul?",["K","A","L"],1],["O relógio da torre marca que horas?",["Meia-noite","Seis da tarde","A hora em que você lê"],2],["Segundo a Naty, o que as horas fazem aqui?",["Passam","Voltam","Ficam"],2]],m:'Biblioteca: você resolveu a charada dos livros.'},
20:{o:'fonte',t:'simon',n:'Flores da fonte',s:['🌹','🌻','🌷','🌼'],n2:5,m:'Jardim: você repetiu a ordem em que as flores se abrem.'},
21:{o:'mesa',t:'timing',n:'Ponto do pão',hits:4,spd:1.1,w:.16,m:'Cozinha: você tirou o pão no ponto certo.'},
22:{o:'mala',t:'mem',n:'Mala de recordações',e:['📷','🧤','🎮','⚽','🍞','🎵'],m:'Porão: você achou todos os pares da mala de recordações.'}};
function mgBox(t,d){const e=document.createElement('div');e.id='mg';e.style.cssText='position:fixed;inset:0;z-index:9;background:rgba(5,6,15,.93);display:flex;align-items:center;justify-content:center;padding:12px';
 e.innerHTML='<div style="width:100%;max-width:420px;background:var(--pan);border:3px solid var(--gold);padding:14px;text-align:center"><div style="color:var(--gold);font-weight:bold">'+t+'</div><div style="font-size:12px;opacity:.85;margin:4px 0 10px">'+d+'</div><div id="mgb"></div><div id="mgs" style="min-height:1.5em;margin:10px 0"></div><button id="mgx">Sair</button></div>';
 document.body.append(e);$('mgx').onclick=()=>mgEnd(0);return $('mgb')}
function mgEnd(ok,k){if(MGC)MGC();MGC=null;const e=$('mg');if(e)e.remove();end();if(ok){const nv=!F.mg[rm];F.mg[rm]=1;if(nv)F.frs.push(k.m);save();if(k.fim&&!F.jantar){return jantar()}say('Você','Consegui: '+k.n+'!'+(nv?' Uma nova lembrança foi anotada.':' Dá para jogar quantas vezes quiser.'))}}
function gTiming(b,k,win){let pos=0,d=1,h=0,sp=k.spd;const bar=(c,st)=>'<div style="position:absolute;top:0;bottom:0;background:'+c+';'+st+'"></div>';
 b.innerHTML='<div style="position:relative;height:26px;background:#000;border:2px solid var(--gold)">'+bar('#40803a','left:'+(50-k.w*50)+'%;width:'+k.w*100+'%')+'<div id="tm" style="position:absolute;top:0;bottom:0;width:4px;background:#fff"></div></div><button id="ta" style="margin-top:12px">Agora!</button>';
 const iv=setInterval(()=>{pos+=d*sp;if(pos>=100||pos<=0)d*=-1;const m=$('tm');if(m)m.style.left=pos+'%'},16);
 $('ta').onclick=()=>{if(Math.abs(pos-50)<k.w*50){h++;sp*=1.12;$('mgs').textContent='Acertou! '+h+'/'+k.hits;if(h>=k.hits){clearInterval(iv);win()}}else{h=0;sp=k.spd;$('mgs').textContent='Errou, recomeçando!'}};
 return()=>clearInterval(iv)}
function gQuiz(b,k,win){let i=0,ok=0;const qs=k.q.map(q=>{const ix=q[1].map((_,j)=>j).sort(()=>Math.random()-.5);return[q[0],ix.map(j=>q[1][j]),ix.indexOf(q[2])]}).sort(()=>Math.random()-.5);const show=()=>{const q=qs[i];b.innerHTML='<div style="margin-bottom:8px">'+q[0]+'</div>';
 q[1].forEach((o,j)=>{const x=document.createElement('button');x.textContent=o;x.style.cssText='display:block;width:100%;margin:5px 0';
  x.onclick=()=>{if(j===q[2]){ok++;$('mgs').textContent='Certo!'}else $('mgs').textContent='Quase! Era: '+q[1][q[2]];i++;
   if(i<qs.length)setTimeout(show,800);else if(ok>=k.need)setTimeout(win,800);else setTimeout(()=>{i=0;ok=0;$('mgs').textContent='Tente de novo!';show()},900)};b.append(x)})};show()}
function gPen(b,k,win){let sh=0,go=0;const L=['⬅ Esquerda','⬆ Meio','➡ Direita'];const draw=()=>{b.innerHTML='Chute '+(sh+1)+'/3 · Gols: '+go+'<br>';
 L.forEach((l,j)=>{const x=document.createElement('button');x.textContent=l;x.style.cssText='min-width:0;margin:8px 3px';
  x.onclick=()=>{const gk=Math.random()*3|0;if(gk!==j){go++;$('mgs').textContent='GOOOL!'}else $('mgs').textContent='O goleiro defendeu!';sh++;
   if(sh<3)draw();else if(go>=2)setTimeout(win,800);else setTimeout(()=>{sh=0;go=0;$('mgs').textContent='Mais uma série!';draw()},900)};b.append(x)})};draw()}
function gMem(b,k,win){const e=[...k.e,...k.e].sort(()=>Math.random()-.5);let a=null,lock=0,n=0;b.style.cssText='display:grid;grid-template-columns:repeat(4,1fr);gap:6px';
 e.forEach(em=>{const x=document.createElement('button');x.style.cssText='min-width:0;height:54px;font-size:24px;padding:0';x.textContent='?';
  x.onclick=()=>{if(lock||x.disabled||x===a)return;x.textContent=em;if(!a){a=x;return}
   if(a.textContent===em){a.disabled=x.disabled=true;a=null;if(++n>=k.e.length)setTimeout(win,600)}else{lock=1;const y=a;a=null;setTimeout(()=>{x.textContent=y.textContent='?';lock=0},700)}};b.append(x)})}
function gSimon(b,k,win){const seq=[];for(let i=0;i<k.n2;i++)seq.push(Math.random()*k.s.length|0);let p=0,lock=1;const bs=[];
 const tone=j=>{const c=V8.ctx();if(!c)return;const o=c.createOscillator(),v=c.createGain();o.frequency.value=262*Math.pow(1.26,j);v.gain.value=.05;o.connect(v);v.connect(c.destination);o.start();o.stop(c.currentTime+.25)};
 const lit=j=>{bs[j].style.background='var(--gold)';tone(j);setTimeout(()=>bs[j].style.background='',320)};
 const play=()=>{lock=1;p=0;$('mgs').textContent='Observe…';let i=0;const iv=setInterval(()=>{if(i>=seq.length){clearInterval(iv);lock=0;$('mgs').textContent='Sua vez!';return}lit(seq[i++])},700)};
 k.s.forEach((sy,j)=>{const x=document.createElement('button');x.textContent=sy;x.style.cssText='min-width:0;width:21%;margin:3px;height:56px;font-size:22px;padding:0';
  x.onclick=()=>{if(lock)return;lit(j);if(j!==seq[p]){$('mgs').textContent='Errou! Vou repetir.';setTimeout(play,900);return}p++;if(p>=seq.length){lock=1;setTimeout(win,500)}};bs.push(x);b.append(x)});setTimeout(play,500)}
const ENG={timing:gTiming,quiz:gQuiz,pen:gPen,mem:gMem,simon:gSimon};
function jogo(o){const k=MGS[rm];busy=1;MGC=ENG[k.t](mgBox(k.n+(F.mg[rm]?' (de novo)':''),DI[k.t]),k,()=>mgEnd(1,k))}
const IT={controle:'Controle do Fernando',faixa:'Pincel azul da Lara',chavepor:'Chave do porão',mamadeira:'Mamadeira',luvas:'Luvas de goleiro'};
const Q={
lara:{item:'faixa',ask:["Perai... lembrei de uma coisa!","Perdi meu pincel azul, o de ponta fina. Acho que deixei no jardim, depois da biblioteca.","A porta fica no quarto da Alinny. Traz pra mim?"],wait:"O pincel azul, lembra? Deve estar no jardim, atrás da porta do quarto da Alinny.",done:["Meu pincel! Você é o melhor!","Agora posso desenhar de novo, sensei de mim mesma."],mem:"Lara: perdeu o pincel azul e você achou no jardim.",fim:"Já estou desenhando de novo, olha só!"},
fernando:{item:'controle',ask:["Cara, preciso falar sério: sumiu o meu controle.","Sem ele eu não termino a missão do GTA 6. Deve ter ido parar numa biblioteca que eu nem sabia que existia.","Se achar, me traz! Eu te devo uma, ó."],wait:"Meu controle... tá em algum lugar da ala da biblioteca, nem sei como foi parar lá.",done:["MEU CONTROLE! Tchooo! Valeu demais!","Missão cumprida. A primeira de várias, provavelmente."],mem:"Fernando: perdeu o controle do videogame, achado na biblioteca.",fim:"Já estou de volta no jogo. Não me chama por uma hora."},
erick:{item:'luvas',ask:["Eae... queria pedir uma coisa.","Minhas luvas de goleiro sumiram. Acho que ficaram no porão, onde ninguém vai.","Só que a porta é trancada. A chave deve estar em algum canto da casa, quem sabe no jardim."],wait:"As luvas, mano. Porão trancado, e a chave deve estar no jardim.",done:["Minhas luvas! Deixa pra lá, valeu mesmo.","Agora o campinho volta a ter goleiro."],mem:"Erick: perdeu as luvas de goleiro, achadas no porão.",fim:"Hoje eu defendo tudo. Até o tigrinho eu seguro."},
marcela:{item:'mamadeira',ask:["Ai, que bom que você voltou!","O bebê acordou com fome e sumiu a mamadeira. Acho que deixei lá na cozinha da ala nova.","Pode buscar pra mim? Eu não posso largar ele agora."],wait:"A mamadeira deve estar na cozinha, depois da biblioteca e do jardim. Corre!",done:["Você salvou o dia! Olha só, ele já está sorrindo.","Obrigada, de coração. Você faz parte da família."],mem:"Marcela: a mamadeira do bebê estava na cozinha, e você levou a tempo.",fim:"Ele dormiu tranquilo, graças a você."}};
function quest(id){const c=NPC[id],k=Q[id],st=F.q[id]||0;
 const entrega=()=>{delete F.inv[k.item];F.q[id]=2;F.frs.push(k.mem);seq([...k.done.map(x=>[c.nome,x]),['Anotação',k.mem]])};
 if(st===0){F.q[id]=1;return seq(k.ask.map(x=>[c.nome,x]),F.inv[k.item]?entrega:null)}
 if(st===1){if(F.inv[k.item])return entrega();return say(c.nome,k.wait)}
 say(c.nome,k.fim)}
Object.assign(IT,{hortela:'Hortelã',tomate:'Tomate',cenoura:'Cenoura',manjericao:'Manjericão'});const ING=['hortela','tomate','cenoura','manjericao'];
MGS[34]={o:'fogao',t:'timing',n:'Ponto da sopa',fim:1,hits:4,spd:1,w:.18,m:'Cozinha do Jardim: você cozinhou a sopa da família com as plantas colhidas no quintal.'};
function colher(o){const id=o[3];if(F.got[id]){say('Você','Já colhi tudo daqui.');return}F.got[id]=1;F.inv[id]=1;say('Você',o[2]+' Colhi: '+IT[id]+'.')}
const FAM=['naty','guifer','debora','yuri','lara','fernando','erick','marcela','alinny'],FAMS=['naty','guifer','yuri','lara','fernando','erick','marcela','alinny'];
function sprm(k,x){const i=IM[k],h=(HH[k]||66)*.8;if(i&&i.complete&&i.naturalHeight){const w=i.naturalWidth/i.naturalHeight*h;g.drawImage(i,Math.round(x-w/2),FL-4-h,w,h)}else if(NPC[k]&&NPC[k].cor){g.save();g.translate(x,FL-3);g.scale(.78,.78);fig(0,0,NPC[k].cor);g.restore()}}
function cena(){seq([['Você',"A porta se abre e o cheiro de panela quente me abraça. A família inteira está sentada atrás da mesa comprida, esperando."],['Naty',"Chegou na hora! Todo mundo veio para o jantar. Só faltava você com as ervas."],['Débora',"Hoje a cozinheira sou eu! Pode me passar o tomate, a cenoura, a hortelã e o manjericão."],['Fernando',"Tchooo! Se a sopa ficar boa, eu paro de pedir pizza. Por uma noite."],['Erick',"Se tiver tomate, eu defendo dois pratos."],['Marcela',"Eu já deixei o bebê dormindo. Podemos jantar sem pressa."],['Lara',"Ata, lembrei! O Sensei dizia que cozinhar também é arte."],['Guifer',"Mesa posta, família reunida. Cheguei cedo e ainda assim fui o último a sentar, ksks."],['Yuri',"Tranquilo, o jogo só começa quando a sopa estiver pronta."],['Alinny',"Eu... trouxe uma música baixinha para o jantar. Espero que ninguém se importe."],['Débora',"Vem ao fogão e me ajuda a acertar o ponto da sopa!"]])}
function jantar(){seq([['Débora',"A sopa está pronta! Pode servir, família!"],['Fernando',"Tchooo! Melhor que qualquer pizza. Registrem isso."],['Erick',"Defendi dois pratos, como prometido."],['Marcela',"Quentinha e caprichada. O bebê vai sentir o cheiro lá de cima."],['Lara',"Ata, está tão boa que até lembrei de tudo o que ia dizer!"],['Yuri',"Gol de placa, Débora."],['Guifer',"O segundo prato é por minha conta. O primeiro eu já devorei."],['Alinny',"Está tão boa que eu nem pensei em pedir desculpa. Quase."],['Naty',"A mesa está cheia, enfim. Era isso que eu esperava desde o portão."],['Você',"Uma noite que não termina, e uma hora que eu não quero perder."]],()=>{const n='Jantar: a família inteira se reuniu na cozinha, e a sopa da Débora fez todo mundo rir à mesa.';F.frs.push(n);F.jantar=1;R[34].p=null;save();say('Anotação',n,null,manha)})}
function porta(o){move(o[2],'r');say('Você',o[3])}
function pegar(o){const id=o[3];if(F.got[id]||(NT.free&&Object.values(Q).some(k=>k.item===id))){say('Você','Nada por aqui.');return}F.got[id]=1;
 if(id.startsWith('m_')){F.frs.push(o[4]);say('Você',o[2]+' (anotado nas lembranças)')}else{F.inv[id]=1;say('Você',o[2]+' Peguei: '+IT[id]+'.')}}
function talk(id){const c=NPC[id];
 if(id==='melina'&&NT.free&&R[rm].n==='Quarto da Melina')return melHair();
 if(rm===34&&id==='debora')return say('Débora',F.jantar?'A sopa ficou perfeita! Obrigada por ajudar. Agora senta e come com a gente.':'Vem para o fogão! Eu mexo a panela e você acerta o ponto da sopa.');
 if(rm>22&&CH[id])return papo(id);
 if(!F.met[id]&&c.lines)return seq(c.lines.map(x=>[c.nome,x]),()=>{F.met[id]=1;F.frs.push(c.nota);end()});
 if(F.met[id]){if(Q[id]&&!NT.free)return quest(id);const d=typeof c.depois==='function'?c.depois():c.depois;return say(c.nome,d)}
 const ask=()=>say(c.nome,c.fala,[[c.a[0],()=>resp(id,'a')],[c.b[0],()=>resp(id,'b')]]);
 if(c.intro)seq(c.intro.map(x=>[c.nome,x]),ask);else ask()}
function resp(id,k){const c=NPC[id];F.ch[id]=k;
 seq([[c.nome,c[k][1]],...c.extra.map(x=>[c.nome,x]),['Anotação',c.nota]],()=>{F.met[id]=1;F.frs.push(c.nota);end()})}
function hora(){return new Date().toLocaleTimeString('pt-BR')}
function save(){if(vivo)SV.set(2,{F,rm,px})}
function load(){return SV.get(2)}
function move(n,via){rm=n;tema(n>22);px=via==='l'?306:14;dir=via==='l'?-1:1;$('dn').textContent=R[n].n;save();const q=R[n];if(q.auto&&!F.seen[n]){F.seen[n]=1;say('…',q.auto,null,end)}
 if(n===34&&!F.ceia&&ING.every(i=>F.got[i])){F.ceia=1;R[34].p=['debora',68];save();cena()}}
function near(){const q=R[rm];if(NT.free&&q.n==='Quarto da Melina'&&Math.abs(px-MELX)<24)return{npc:'melina'};if(q.p&&!NT.on&&(rm===34||!(F.ceia&&!F.jantar&&FAM.includes(q.p[0])))&&Math.abs(px-q.p[1])<24)return{npc:q.p[0]};
 const o=q.o.find(o=>px>=o[0]-8&&px<=o[0]+W[o[1]]+8);return o?{o}:null}
function act(){if(GM.on&&GM.g){GM.g.act();return}if(!vivo||busy)return;musica();const a=near();if(!a){say('Você','Nada por aqui.');return}
 if(a.npc)return talk(a.npc);const o=a.o;if(o[1]==='carta'&&R[rm].n==='Torre do Relógio'&&NT.free&&F.aEv===1)return cenaLivro();if(o[1]==='colher')return colher(o);if(MGS[rm]&&o[1]===MGS[rm].o){if(rm===34&&!F.jantar&&!ING.every(i=>F.got[i])){say('Você','Faltam ingredientes do quintal: '+ING.filter(i=>!F.got[i]).map(i=>IT[i]).join(', ')+'.');return}return jogo(o)}if(o[1]==='item')return pegar(o);if(o[1]==='porta')return porta(o);if(o[1]==='portal')return portal();if(o[1]==='portaltopo')return topo();if(o[1]==='escola')return escolaEntrar();if(o[1]==='sala1')return entrarSala1();if(o[1]==='saida')return sairSala1();if(o[1]==='qfam')return(o[2]==='yuri'&&!F.mask)?say('Você','O Yuri ainda está lá no corredor.'):say(QN[o[2]],(F.gl&&F.gl[o[2]]&&QLG[o[2]])||QL[o[2]]);if(o[1]==='aluno')return F.interv?say('Você','A sala esvaziou. Todo mundo foi para o intervalo.'):falar(o[2]);
 let tx=o[2];if(o[1]==='escada'&&(NT.free||F.met.yuri))tx='Degraus de pedra gastos, subindo em curva.';if(o[1]==='retrato')tx=o[3]&&F.met[o[3]]?'Retrato de '+NPC[o[3]].nome+'. A moldura brilha, como se a música passasse por ela.':'Uma moldura vazia, guardada para alguém que ainda vai chegar.';
 if(tx.includes('{hora}')){RV=tx;tx=tx.replace('{hora}',hora())}say('Você',tx)}
function topo(){if(rm===4){if(NT.free||F.met.yuri){move(5,'r');say('Você','A porta se abre para uma nova ala do castelo. Escuto vozes lá dentro.');return}say('Você','A porta no alto da escada está fechada. Antes, acho melhor falar com quem está parado ali.');return}
 if(NT.free||F.met.padre)return finale();say('Você','A última porta continua fechada. Ainda falta alguém por aqui.')}
function portal(){if(NT.free||(F.met.naty&&F.met.guifer&&F.met.debora)){move(4,'r');if(!NT.free&&!F.met.yuri)say('Você','Uma escada de pedra sobe em curva. Há alguém parado ali, esperando por mim.');return}
 say('Você','A porta da torre não se move. Acho que ela só abre para quem já conheceu a família.')}
const book=()=>{if(vivo&&!busy)say("Família Ailton's ("+Object.keys(F.met).length+")",F.frs.length?F.frs.join('\n\n')+(Object.keys(F.inv).length?'\n\nMochila: '+Object.keys(F.inv).map(k=>IT[k]).join(', '):''):'Ainda ninguém foi apresentado.')};
/* ============ final: tela com animação escrita ============ */
const sleep=ms=>new Promise(r=>setTimeout(r,rapido?0:ms));
function tic(){if(!A||A.state!=='running')return;const o=A.createOscillator(),e=A.createGain();o.type='sine';o.frequency.value=880+Math.random()*80;e.gain.setValueAtTime(.02,A.currentTime);e.gain.exponentialRampToValueAtTime(.0005,A.currentTime+.05);o.connect(e);e.connect(A.destination);o.start();o.stop(A.currentTime+.06)}
async function finale(){busy=1;F.fim=1;save();rapido=0;const el=$('ft');el.textContent='';$('fc').hidden=1;$('fb').hidden=1;$('fb').textContent='Voltar ao castelo';
 const f=$('fim');f.style.transition='';f.style.opacity='';f.hidden=0;
 V8.onFim=()=>{rapido=1};V8.onFb=()=>{f.hidden=1;V8.onFim=V8.onFb=null;end()};
 const L=["O castelo respira em paz.","Todos já foram apresentados.","Na Galeria, as quatro molduras agora têm rosto.","Na mesa, ainda sobram lugares.","A música continua, mais suave, e lá fora alguém novo está chegando ao portão."];
 for(const l of L){for(const ch of l){el.textContent+=ch;if(ch!==' ')tic();await sleep(46)}el.textContent+='\n\n';await sleep(700)}
 $('fc').hidden=0;$('fb').hidden=0}
/* ============ desenho ============ */
const rc=(c,x,y,w,h)=>{g.fillStyle=c;g.fillRect(Math.round(x),Math.round(y),w,h)};
const hs=(a,b)=>((a*73856093^b*19349663)>>>0)%100;
const glow=(x,y,r,c,a)=>{const h=g.createRadialGradient(x,y,1,x,y,r);h.addColorStop(0,'rgba('+c+','+a+')');h.addColorStop(1,'rgba('+c+',0)');g.fillStyle=h;g.fillRect(x-r,y-r,r*2,r*2)};
function ceu(){const s=g.createLinearGradient(0,0,0,FL);s.addColorStop(0,'#26305e');s.addColorStop(.55,'#8a5a8a');s.addColorStop(1,'#f0a868');g.fillStyle=s;g.fillRect(0,0,320,FL);
 for(let i=0;i<14;i++)rc('rgba(255,255,255,'+(.3+.4*Math.sin(t*2+i))+')',(i*47)%320,(i*13)%46,1,1);
 glow(236,100,50,'255,220,160',.35);g.fillStyle='#ffe2a0';g.beginPath();g.arc(236,100,9,0,7);g.fill();
 for(let i=0;i<4;i++){const x=((i*110+t*4)%420)-60,y=22+i*14;rc('rgba(255,210,200,.3)',x,y,52,6);rc('rgba(255,210,200,.25)',x+10,y-3,30,4)}
 rc('#201f44',0,112,320,34);rc('#1a1a38',0,126,320,20);
 rc('#17183a',196,62,42,84);rc('#17183a',176,80,18,66);rc('#17183a',240,70,22,76);rc('#17183a',150,100,24,46);
 [[196,62,42],[176,80,18],[240,70,22],[150,100,24]].forEach(([x,y,w])=>{for(let k=0;k<w;k+=6)rc('#17183a',x+k,y-3,3,3)});
 [[212,80],[224,96],[182,96],[248,90],[156,116]].forEach(([x,y],i)=>rc('rgba(255,216,144,'+(.6+.3*Math.sin(t*2+i))+')',x,y,2,4));
 rc('#cccccc',216,50,1,14);rc('#2a3f8a',217,51,8+Math.round(Math.sin(t*3)),4);
 for(let i=0;i<3;i++){const x=((t*12+i*100)%360)-20,y=30+i*12+Math.sin(t*3+i)*3,u=Math.sin(t*14+i)>0?0:1;rc('#2a1a3a',x,y+u,2,1);rc('#2a1a3a',x+2,y+1,1,1);rc('#2a1a3a',x+3,y+u,2,1)}}
function parede(q){rc(q.c,0,0,320,FL);
 for(let y=0,r=0;!q.flat&&y<FL;y+=9,r++){rc('rgba(0,0,0,.22)',0,y,320,1);for(let x=(r%2)*12;x<320;x+=24){rc('rgba(0,0,0,.2)',x,y,1,9);const h=hs(x,y);if(h<30)rc('rgba(255,255,255,.04)',x+2,y+2,9,4);else if(h>85)rc('rgba(0,0,0,.08)',x+2,y+2,9,5)}}
 rc('rgba(0,0,0,.28)',0,FL-14,320,14);rc('rgba(232,184,92,.35)',0,FL-14,320,1);rc('rgba(0,0,0,.35)',0,0,320,5);rc('rgba(232,184,92,.25)',0,5,320,1);
 if(q.flat)for(let x=0;x<320;x+=40)rc('rgba(255,255,255,.04)',x,0,2,FL);if(q.msg)paredeTxt(q.msg);(q.win||[]).forEach(janela);(q.tor||[]).forEach(tocha)}
function paredeTxt(s){g.font='6px monospace';g.fillStyle='rgba(200,225,255,.9)';const ls=[];let l='';for(const p of s.split(' ')){const n=l?l+' '+p:p;if(g.measureText(n).width>250&&l){ls.push(l);l=p}else l=n}ls.push(l);ls.forEach((x,i)=>g.fillText(x,Math.round((320-g.measureText(x).width)/2),34+i*10))}
/* --- a partir daqui: trecho que tinha sido cortado, completado --- */
function janela(wx){const y0=30;g.fillStyle='#0c1030';g.fillRect(wx-2,y0-2,30,52);g.beginPath();g.arc(wx+13,y0,15,Math.PI,0);g.fill();
 const sg=g.createLinearGradient(0,y0-14,0,y0+48);sg.addColorStop(0,'#3a3a7a');sg.addColorStop(.6,'#d8886a');sg.addColorStop(1,'#f4b878');g.fillStyle=sg;g.fillRect(wx,y0,26,48);g.beginPath();g.arc(wx+13,y0,13,Math.PI,0);g.fill();
 rc('#3a2e4a',wx+12,y0-14,2,62);rc('#3a2e4a',wx,y0+16,26,2);rc('#e8b85c',wx-2,y0+48,30,2);glow(wx+13,y0+20,34,'255,190,120',.12)}
function tocha(x){const fl=.5+.5*Math.sin(t*9+x);glow(x,46,36,'255,190,100',.2+.1*fl);rc('#3a2e3a',x-1,52,2,10);rc('#e8b85c',x-4,48,8,3);rc('#ffb050',x-2,42-Math.round(fl),4,6);rc('#ffe090',x-1,43,2,3)}
function chao(q){rc(q.f||'#2a2236',0,FL,320,34);
 for(let r=0;r<4;r++){const y=FL+r*9;rc('rgba(0,0,0,.22)',0,y+8,320,1);for(let x=(r%2)*14;x<320;x+=28)rc('rgba(0,0,0,.18)',x,y,1,9)}
 if(rm===1||rm===2){rc('#22306a',24,FL+10,272,14);rc('#e8b85c',24,FL+10,272,1);rc('#e8b85c',24,FL+23,272,1)}}
function bustoR(id,x0){const i=IM[id];if(!i||!i.complete||!i.naturalHeight)return;const nw=i.naturalWidth,nh=i.naturalHeight;let sh=nh*.38,sw=sh*26/38;if(sw>nw){sw=nw;sh=sw*38/26}g.drawImage(i,(nw-sw)/2,0,sw,sh,x0,40,26,38)}
function busto(id,cx,y){const i=IM[id];if(!i||!i.complete||!i.naturalHeight)return;const sh=i.naturalHeight*.3,sw=Math.min(sh*.8,i.naturalWidth),dw=24*sw/(sh*.8);g.drawImage(i,(i.naturalWidth-sw)/2,0,sw,sh,cx-dw/2,y-33,dw,30)}
function fig(x,y,c){const pisca=(t%4)<.12,bob=Math.abs(Math.sin(t*2))*.8;g.save();g.translate(Math.round(x),y-bob);g.scale(1.65,1.65);
 rc('#1a1018',-4,-12,3,12);rc('#1a1018',1,-12,3,12);rc('#0c080c',-5,-2,4,2);rc('#0c080c',1,-2,4,2);
 rc(c.ro,-5,-28,10,17);rc(c.ro,-7,-27,2,13);rc(c.ro,5,-27,2,13);rc(c.pe,-7,-14,2,2);rc(c.pe,5,-14,2,2);rc('rgba(0,0,0,.25)',-5,-18,10,1);
 if(c.ac)rc(c.ac,-2,-29,4,2);
 rc(c.pe,-1,-30,2,2);rc(c.pe,-4,-37,8,9);rc(c.ca,-5,-39,10,4);rc(c.ca,-5,-37,1,4);rc(c.ca,4,-37,1,4);
 if(!pisca){rc('#111',-2,-33,1,1);rc('#111',1,-33,1,1)}rc('rgba(80,30,30,.7)',-1,-30,2,1);g.restore()}
function spr0(k,x,y,mv,d){const i=IM[k];g.fillStyle='rgba(0,0,0,.45)';g.beginPath();g.ellipse(x,y,12,3,0,0,7);g.fill();if((!i||!i.complete||!i.naturalHeight)&&NPC[k]&&NPC[k].cor)return fig(x,y,NPC[k].cor);
 if(!i||!i.complete||!i.naturalHeight)return;
 const h=HH[k]||66,w=i.naturalWidth/i.naturalHeight*h,bb=mv?Math.abs(Math.sin(t/5))*1.5:Math.sin(t/30)*.5;
 g.save();g.translate(Math.round(x),y-bb);if(d<0)g.scale(-1,1);if(mv)g.rotate(Math.sin(t/5)*.03);g.drawImage(i,-w/2,-h,w,h);g.restore()}
function spr(k,x,y,mv,d){spr0(k,x,y,mv,d);if(F.gl&&F.gl[k])glitchSpr(k,x,y,1,d)}
function objeto(o){const x=o[0],b=FL,p=.5+.5*Math.sin(t*3);
 switch(o[1]){
 case 'portao':rc('#1c1830',x,b-84,56,84);rc('#0a0d1e',x+8,b-76,40,76);g.fillStyle='#0a0d1e';g.beginPath();g.arc(x+28,b-76,20,Math.PI,0);g.fill();
  for(let j=0;j<7;j++)rc('rgba(160,190,255,.5)',x+11+j*5,b-72+((t*50+j*13)%64),1,4);
  rc('#4a3322',x+1,b-74,8,74);rc('#4a3322',x+47,b-74,8,74);rc('#e8b85c',x+3,b-50,3,3);rc('#e8b85c',x+49,b-50,3,3);break;
 case 'fonte':rc('#6a6a88',x,b-12,40,12);rc('#8a8aa8',x,b-12,40,2);rc('#6f9fe8',x+3,b-10,34,5);rc('#7a7a98',x+17,b-30,6,20);rc('#8a8aa8',x+11,b-32,18,4);
  for(let j=0;j<5;j++){const q=(t*30+j*9)%22;rc('rgba(200,225,255,.8)',x+19+Math.sin(j*2)*q/3,b-34+q,1,2)}break;
 case 'lanterna':rc('#2a2a3a',x+3,b-70,2,70);rc('#e8b85c',x,b-80,8,10);glow(x+4,b-76,28,'255,200,110',.3+.1*p);rc('#fff0b0',x+2,b-78,4,6);break;
 case 'lareira':{rc('#4a3d5a',x,b-64,48,64);rc('#6a5a7a',x-3,b-66,54,5);rc('#14101c',x+8,b-40,32,40);
  glow(x+24,b-20,44,'255,150,60',.3+.1*p);for(let j=0;j<6;j++){const h=8+((t*20+j*7)%14);rc(j%2?'#ff9030':'#ffc860',x+12+j*5,b-4-h,4,h)}rc('#3a2210',x+10,b-4,28,4);break}
 case 'mesa':rc('#6a4430',x,b-26,72,4);rc('#2a3f8a',x,b-22,72,10);rc('#e8b85c',x,b-12,72,1);rc('#4a3022',x+4,b-12,4,12);rc('#4a3022',x+64,b-12,4,12);
  for(let j=0;j<6;j++)rc('#e8e0d0',x+6+j*11,b-28,7,2);[x+20,x+50].forEach(c=>{rc('#e8e0d0',c,b-36,2,8);rc('#ffd080',c,b-39-Math.round(p),2,3)});break;
 case 'estandarte':rc('#e8b85c',x-2,10,28,2);rc('#2a3f8a',x,12,24,56);g.fillStyle='#2a3f8a';g.beginPath();g.moveTo(x,68);g.lineTo(x+24,68);g.lineTo(x+12,80);g.fill();g.fillStyle='#e8b85c';g.font='bold 16px monospace';g.fillText('A',x+7,44);break;
 case 'retrato':rc('#e8b85c',x,38,30,42);rc('#161a33',x+2,40,26,38);if(o[3]&&F.met[o[3]])bustoR(o[3],x+2);else{rc('#222a4a',x+9,52,12,14);rc('#222a4a',x+5,68,20,10)}break;
 case 'relogiog':{rc('#4a2f22',x+3,b-84,24,84);rc('#5a3a2a',x,b-96,30,22);const d=new Date(),mi=d.getMinutes()+d.getSeconds()/60,hr=d.getHours()%12+mi/60,cx=x+15,cy=b-85;
  g.fillStyle='#e8d6c0';g.beginPath();g.arc(cx,cy,8,0,7);g.fill();g.strokeStyle='#2a1a14';g.lineWidth=1;
  [[hr/12,4],[mi/60,6]].forEach(([a,l])=>{g.beginPath();g.moveTo(cx,cy);g.lineTo(cx+Math.sin(a*6.283)*l,cy-Math.cos(a*6.283)*l);g.stroke()});
  rc('#241410',x+8,b-66,14,46);const s=Math.sin(t*3)*4;rc('#c8a050',x+14+s,b-30,3,3);rc('#c8a050',x+15+s/3,b-64,1,34);break}
 case 'carta':rc('#5a3a2a',x+4,b-16,10,16);rc('#e8e0c8',x,b-20,18,6);rc('#e8b85c',x+8,b-19,3,3);glow(x+9,b-20,16,'232,184,92',.15+.1*p);break;

 case 'mesadesenho':rc('#5a3a28',x+2,b-22,4,22);rc('#5a3a28',x+54,b-22,4,22);rc('#7a5238',x,b-26,60,5);rc('#a8805a',x,b-26,60,1);
   rc('#d9c9a8',x+6,b-44,34,20);rc('#b8a888',x+6,b-26,34,2);for(let j=0;j<5;j++)rc('rgba(40,60,140,.55)',x+9+j*6,b-40+(j%3)*3,4+(j%2)*3,1);rc('#3a5ad8',x+14,b-36,10,6);rc('#9ab4ff',x+16,b-34,3,2);
   rc('#2a2a44',x+46,b-36,9,10);rc('#e8b85c',x+47,b-42,1,6);rc('#d03060',x+49,b-44,1,8);rc('#3a5ad8',x+51,b-41,1,5);rc('#f0e6d0',x+43,b-28,6,2);
   rc('#4a4a5a',x+42,b-56,2,14);rc('#4a4a5a',x+42,b-56,10,2);rc('#e8b85c',x+50,b-55,6,4);glow(x+53,b-48,22,'255,210,120',.18+.06*p);break;
  case 'varal':{rc('#c8b88a',x,26,70,1);rc('#c8b88a',x+4,27,62,1);for(let j=0;j<4;j++){const sw=Math.round(Math.sin(t*1.5+j*1.7));const px0=x+5+j*16+sw;
   rc('#f0e6d0',px0,29,12,16);rc('#c0392b',px0+5,28,2,3);
   if(j===0){rc('#3a5ad8',px0+2,32,8,6);rc('#9ab4ff',px0+3,33,2,2)}
   else if(j===1){rc('#d03060',px0+4,32,4,4);rc('#2a2a2a',px0+3,38,6,1)}
   else if(j===2){rc('#3a8a4a',px0+2,38,8,3);rc('#e8b85c',px0+8,31,2,2);rc('#3a5ad8',px0+3,33,4,4)}
   else{for(let q=0;q<4;q++)rc('rgba(40,60,140,.6)',px0+2,32+q*3,7-q,1)}}break}
  case 'pigmento':{glow(x+12,b-18,30,'110,150,255',.24+.1*p);rc('#2a2a44',x+3,b-4,18,4);rc('#3a3a5a',x+3,b-4,18,1);
   rc('#bcd0ff',x+6,b-22,12,18);rc('#1e38b0',x+7,b-17,10,12);rc('#3a5ad8',x+7,b-17,10,2);rc('#9ab4ff',x+9,b-15,2,5);rc('#8a5a3a',x+8,b-25,8,4);
   const sp=(t*20)%12;rc('#cfe0ff',x+5+sp,b-30+Math.sin(t*3+sp)*2,1,1);break}
 case 'tatame':rc('#c8b88a',x,b-6,70,6);rc('#a89868',x,b-6,70,1);for(let j=1;j<5;j++)rc('rgba(0,0,0,.2)',x+j*14,b-6,1,6);break;
 case 'pergaminho':rc('#3a2a1e',x,40,24,3);rc('#e8dcc0',x+2,43,20,30);rc('#3a2a1e',x,73,24,3);rc('#8a1f1f',x+10,50,4,16);break;
 case 'cristal':{glow(x+12,b-18,28,'110,150,255',.22+.1*p);g.fillStyle='#3a5ad8';g.beginPath();g.moveTo(x+12,b-34);g.lineTo(x+22,b-14);g.lineTo(x+12,b-4);g.lineTo(x+2,b-14);g.fill();rc('#9ab4ff',x+10,b-26,2,10);rc('#2a2a44',x+4,b-4,16,4);break}
 case 'tv':rc('#3a2a22',x,b-16,50,16);rc('#14141c',x+2,b-48,46,32);rc('#d8784a',x+5,b-45,40,14);rc('#4a3a8a',x+5,b-31,40,12);rc('#ffd890',x+22,b-40,6,6);rc('#14141c',x+5,b-33,40,2);rc('#aaaaaa',x+30,b-18,10,4);glow(x+25,b-30,44,'130,160,255',.12+.05*p);break;
 case 'sofa':rc('#5a2a3a',x,b-22,60,22);rc('#7a3a4a',x,b-30,60,10);rc('#4a2030',x,b-22,8,22);rc('#4a2030',x+52,b-22,8,22);rc('#7a3a4a',x+8,b-26,44,6);break;
 case 'neon':{glow(x+22,48,40,'255,90,160',.18+.06*p);rc('#1a1020',x,40,44,16);g.font='bold 9px monospace';g.fillStyle='rgba(255,90,160,'+(.7+.3*p)+')';g.fillText('PROVISO',x+3,52);break}
 case 'gol':rc('#e8e8e8',x,b-50,3,50);rc('#e8e8e8',x+53,b-50,3,50);rc('#e8e8e8',x,b-50,56,3);for(let j=0;j<8;j++)rc('rgba(255,255,255,.25)',x+3+j*6,b-47,1,47);for(let j=0;j<6;j++)rc('rgba(255,255,255,.25)',x+3,b-47+j*8,50,1);break;
 case 'bola':g.fillStyle='#f4f4f4';g.beginPath();g.arc(x+5,b-5,5,0,7);g.fill();rc('#222222',x+3,b-7,3,3);break;
 case 'caca':{rc('#7a1010',x,b-60,30,60);rc('#e8b85c',x,b-60,30,3);rc('#14141c',x+3,b-50,24,20);for(let j=0;j<3;j++){rc('#f0f0e0',x+4+j*8,b-48,7,16);rc('#e03030',x+6+j*8,b-44,3,8);rc((Math.floor(t*4)+j)%2?'#ffd040':'#a07010',x+3+j*10,b-56,4,3)}rc('#cccccc',x+32,b-45,2,20);rc('#e03030',x+31,b-48,4,4);break}
 case 'fotos':rc('#3a2a3a',x,30,44,34);for(let j=0;j<6;j++){rc('#e8dcc0',x+3+(j%3)*13,33+Math.floor(j/3)*15,10,12);rc('#c88a8a',x+6+(j%3)*13,37+Math.floor(j/3)*15,4,4)}break;
 case 'vaso':rc('#8a4a2a',x+4,b-14,14,14);rc('#2a6a3a',x+2,b-30,18,16);rc('#3a8a4a',x+6,b-36,10,10);break;
 case 'escrivaninha':rc('#5a3a2a',x,b-26,56,4);rc('#3a2418',x+4,b-22,4,22);rc('#3a2418',x+48,b-22,4,22);rc('#a03040',x+4,b-34,12,8);rc('#3050a0',x+16,b-32,10,6);rc('#e8e0d0',x+30,b-29,16,3);rc('#e8b85c',x+44,b-40,3,14);glow(x+46,b-40,28,'255,210,130',.2);break;
 case 'notas':g.font='10px monospace';for(let j=0;j<4;j++){const q=(t*10+j*11)%46;g.fillStyle='rgba(232,214,255,'+(.8-q/60)+')';g.fillText(j%2?'♫':'♪',x+j*9+Math.sin(t+j)*3,b-30-q)}break;
 case 'livros':rc('#a03040',x,b-8,22,8);rc('#3050a0',x+2,b-16,20,8);rc('#40803a',x,b-24,22,8);rc('#e0b040',x+3,b-30,18,6);break;
 case 'mapa':rc('#2a1c20',x-1,36,62,42);rc('#6a98c8',x+1,38,58,38);rc('#5a9a4a',x+8,46,14,12);rc('#5a9a4a',x+30,44,18,10);rc('#5a9a4a',x+36,58,12,12);rc('#e03030',x+50,50,3,3);break;
 case 'globo':{rc('#4a3022',x+10,b-6,4,6);g.fillStyle='#3a78c8';g.beginPath();g.arc(x+12,b-20,11,0,7);g.fill();rc('#5aa04a',x+6+Math.round(Math.sin(t)*3),b-24,6,5);g.strokeStyle='#e8b85c';g.lineWidth=1;g.beginPath();g.arc(x+12,b-20,12,0,7);g.stroke();break}
 case 'mala':rc('#7a4a2a',x,b-22,30,22);rc('#4a2a18',x,b-22,30,2);rc('#4a2a18',x+13,b-26,4,4);rc('#e8dcc0',x+6,b-16,8,6);rc('#e03030',x+18,b-14,6,6);break;
 case 'cadeira':rc('#4a3022',x,b-34,4,34);rc('#4a3022',x,b-14,20,3);rc('#4a3022',x+16,b-14,3,14);break;
 case 'lampada':glow(x+5,44,46,'255,220,140',.3+.05*Math.sin(t*5));rc('#555555',x+4,0,1,40);rc('#ffe090',x+2,40,6,6);break;
 case 'relogioreverso':{const cx=x+23,cy=56;g.fillStyle='#e8d6c0';g.beginPath();g.arc(cx,cy,22,0,7);g.fill();g.strokeStyle='#4a2a1e';g.lineWidth=2;g.stroke();for(let k=0;k<12;k++){const a=k*Math.PI/6;rc('#4a2a1e',cx+Math.sin(a)*18,cy-Math.cos(a)*18,2,2)}[[-t*.1,11,'#2a1a14',2],[-t*.6,16,'#2a1a14',1.5],[-t*3,18,'#a0203f',.8]].forEach(([a,l,c,w])=>{g.strokeStyle=c;g.lineWidth=w;g.beginPath();g.moveTo(cx,cy);g.lineTo(cx+Math.sin(a)*l,cy-Math.cos(a)*l);g.stroke()});break}
 case 'ampulheta':rc('#e8b85c',x,b-30,14,2);rc('#e8b85c',x,b-4,14,2);rc('rgba(200,225,255,.4)',x+1,b-28,12,24);rc('#e8c070',x+3,b-12,8,8);for(let j=0;j<4;j++)rc('#e8c070',x+6,b-14-((t*10+j*5)%12),1,1);break;
 case 'mural':rc('#4a3a2a',x,30,64,44);rc('#c8a870',x+2,32,60,40);for(let j=0;j<5;j++)rc('#e8e8e8',x+6+j*11,36+(j%2)*18,8,10);g.strokeStyle='#d02020';g.lineWidth=1;g.beginPath();g.moveTo(x+10,41);g.lineTo(x+32,52);g.lineTo(x+54,41);g.moveTo(x+32,52);g.lineTo(x+43,63);g.stroke();rc('#d02020',x+30,50,4,4);break;
 case 'monitor':rc('#1a1a22',x,b-44,34,26);rc('#0a1a22',x+2,b-42,30,22);rc('rgba(255,40,40,'+(.4+.6*p)+')',x+4,b-40,3,3);g.font='6px monospace';g.fillStyle='#ff6060';g.fillText('REC',x+10,b-37);rc('#1a1a22',x+14,b-18,6,8);rc('#1a1a22',x+8,b-10,18,3);break;
 case 'altarcruz':glow(x+22,b-40,40,'255,200,120',.12+.06*p);rc('#4a3a5a',x,b-30,44,30);rc('#e8dcc0',x,b-32,44,3);rc('#e8b85c',x+20,b-62,4,30);rc('#e8b85c',x+14,b-56,16,4);[x+4,x+36].forEach(c=>{rc('#e8e0d0',c,b-42,3,10);rc('#ffd080',c,b-46-Math.round(p),3,4)});break;
 case 'banco':rc('#3a2418',x,b-20,56,4);rc('#3a2418',x,b-34,56,4);rc('#3a2418',x+2,b-20,3,20);rc('#3a2418',x+51,b-20,3,20);rc('#2a1810',x,b-34,3,16);break;
 case 'escada':for(let j=0;j<8;j++){const hh=(j+1)*9,sx=x+j*12;rc('#4a4068',sx,b-hh,12,hh);rc('#6a5f8e',sx,b-hh,12,2);rc('rgba(0,0,0,.28)',sx,b-hh+2,1,hh-2)}rc('#e8b85c',x,b-30,2,30);rc('#e8b85c',x+96,b-86,2,18);break;

 case 'colher':rc('#4a3022',x-2,b-6,22,6);if(!F.got[o[3]]){const sw=Math.sin(t*2+x);rc('#2a8a3a',x+8,b-18,2,12);rc(o[4],x+3+sw,b-26,12,9);rc('rgba(255,255,255,.35)',x+5+sw,b-25,3,2);glow(x+9,b-20,18,'255,240,170',.12+.06*p)}break;
 case 'fogao':rc('#6a6070',x,b-30,44,30);rc('#4a4256',x,b-32,44,3);rc('#14101c',x+6,b-22,32,16);rc('#ffa040',x+10,b-14-Math.round(p*3),6,8);rc('#ffd060',x+26,b-14-Math.round(p*2),6,6);glow(x+22,b-14,30,'255,150,60',.2+.08*p);rc('#8a8a98',x+8,b-42,28,10);rc('#aaaaaa',x+6,b-44,32,3);rc('rgba(255,255,255,.35)',x+16,b-48-((t*10)%8),2,4);break;
 case 'mesalonga':rc('#6a4430',x,b-26,200,4);rc('#2a3f8a',x,b-22,200,10);rc('#e8b85c',x,b-12,200,1);rc('#1f2f6a',x,b-12,200,12);rc('#4a3022',x+6,b-12,4,12);rc('#4a3022',x+190,b-12,4,12);for(let j=0;j<9;j++){rc('#e8e0d0',x+10+j*21,b-28,9,2);if(F.jantar){rc('#d8884a',x+11+j*21,b-30,7,2);rc('rgba(255,255,255,.35)',x+14+j*21,b-34-((t*8+j*3)%6),1,3)}}break;
 case 'camarosa':rc('rgba(255,214,232,.55)',x,22,70,3);rc('rgba(255,214,232,.4)',x,25,7,72);rc('rgba(255,214,232,.4)',x+63,25,7,72);rc('#c06a90',x,b-30,3,30);rc('#c06a90',x+67,b-30,3,30);rc('#f6c6dc',x,b-22,70,22);rc('#fff0f6',x+3,b-28,64,8);rc('#e88ab4',x+48,b-36,18,12);rc('#ff9ac8',x+8,b-34,14,10);break;
 case 'penteadeira':rc('#fff',x,b-24,34,24);rc('#e8a0c0',x,b-26,34,3);rc('#c06a90',x+6,b-66,22,38);rc('#d8f0ff',x+8,b-64,18,34);rc('rgba(255,255,255,.5)',x+10,b-62+((t*8)%26),2,6);rc('#ff6aa8',x+3,b-32,4,6);rc('#ffd0e8',x+26,b-31,4,5);break;
 case 'luzinhas':rc('rgba(255,255,255,.3)',x,28,56,1);for(let j=0;j<8;j++){const a=.5+.5*Math.sin(t*4+j);rc(['rgba(255,208,232,','rgba(255,240,160,','rgba(200,232,255,'][j%3]+a+')',x+j*7,29+(j%2)*3,3,3)}break;
 case 'ursinho':rc('#c8905a',x+4,b-14,14,14);rc('#c8905a',x+6,b-24,10,10);rc('#c8905a',x+5,b-26,3,3);rc('#c8905a',x+14,b-26,3,3);rc('#ff7ab0',x+9,b-12,4,3);g.fillStyle='#ff9ac8';g.beginPath();g.arc(x+18,b-46+Math.sin(t*2)*2,6,0,7);g.fill();rc('#fff',x+18,b-40+Math.sin(t*2)*2,1,18);break;
 case 'faixabr':rc('#f6d020',x,18,70,16);rc('#1a9a3a',x,34,70,3);g.font='bold 9px monospace';g.fillStyle='#1a7a3a';g.fillText('BRASIL',x+12,30);break;
 case 'camisas':rc('#6a4a2a',x,32,60,2);for(let j=0;j<3;j++){rc(['#f6d020','#f4f4f4','#2a6ad8'][j],x+j*20+1,34,16,22);rc('#1a7a3a',x+j*20+6,34,6,3)}break;
 case 'trofeu':rc('#e8b85c',x+7,b-22,8,12);rc('#e8b85c',x+3,b-26,16,6);rc('#e8b85c',x+10,b-12,2,8);rc('#7a5a2a',x+4,b-4,14,4);glow(x+11,b-20,18,'255,210,120',.18+.08*p);break;
 case 'saco':{const s=Math.sin(t*2)*2;rc('#888',x+9+s/4,10,2,30);rc('#c8302a',x+3+s,40,14,40);rc('#7a1a1a',x+3+s,40,14,2);break}
 case 'tenis':rc('#4a3a30',x,b-52,50,3);rc('#4a3a30',x,b-30,50,3);for(let j=0;j<4;j++){rc('#fff',x+2+j*12,b-57,10,5);rc(['#e03030','#3a6ad8','#222','#e8b85c'][j],x+2+j*12,b-52,10,1);rc('#f4f4f4',x+2+j*12,b-35,10,5);rc(['#222','#e8b85c','#e03030','#3a6ad8'][j],x+2+j*12,b-30,10,1)}break;
 case 'espelho':rc('#e8b85c',x,b-76,26,52);rc('#cfe8ff',x+2,b-74,22,48);rc('rgba(255,255,255,.5)',x+4,b-72+((t*10)%30),2,10);break;
 case 'cha':rc('#fff0d0',x,b-24,44,3);rc('#8a5a3a',x+20,b-21,4,21);rc('#fff',x+6,b-32,10,8);rc('#e8b85c',x+6,b-34,10,2);rc('#fff',x+26,b-29,6,5);rc('#fff',x+34,b-29,6,5);rc('rgba(255,255,255,.4)',x+10,b-38-((t*10)%8),1,3);break;
 case 'sino':rc('#e8b85c',x+2,b-20,12,12);rc('#e8b85c',x,b-10,16,3);rc('#7a5a2a',x+6,b-22,4,3);break;
 case 'vinil':rc('#2a2030',x,b-18,36,18);g.fillStyle='#111';g.beginPath();g.arc(x+14,b-20,8,0,7);g.fill();rc('#e03070',x+14+Math.cos(t*6)*5,b-20+Math.sin(t*6)*5,2,2);rc('#ccc',x+28,b-32,2,14);break;
 case 'fone':rc('#222',x+2,40,16,2);rc('#6a4aa8',x,42,4,10);rc('#6a4aa8',x+16,42,4,10);break;
 case 'molduras':for(let j=0;j<3;j++){const y=j%2?44:34;rc('#e8b85c',x+j*22,y,18,24);rc('#1a1a2a',x+j*22+2,y+2,14,20);rc(['#d03060','#3a6ad8','#e8b85c'][j],x+j*22+6,y+8,6,6)}break;
 case 'cavalete':rc('#6a4a2a',x+4,b-58,2,58);rc('#6a4a2a',x+26,b-58,2,58);rc('#f4ecdc',x+6,b-54,22,28);rc('#d03060',x+10,b-48,6,6);rc('#2a2a2a',x+18,b-42,8,8);break;
 case 'prat':rc('#2a2030',x,b-48,56,3);for(let j=0;j<5;j++)rc(['#e03090','#3a6ad8','#40c060','#f0c030','#f4f4f4'][j],x+3+j*10,b-54,7,6);break;
 case 'berco':rc('#e8d0b0',x,b-44,44,3);rc('#e8d0b0',x,b-26,44,3);rc('#f6f0e0',x+2,b-23,40,16);for(let j=0;j<6;j++)rc('#e8d0b0',x+2+j*8,b-44,2,44);rc('#ffd0e8',x+10+Math.sin(t*2)*4,22,4,4);rc('#ffd0e8',x+30+Math.sin(t*2+1)*4,26,4,4);break;
 case 'item':if(!F.got[o[3]]){glow(x+7,b-10,22,'255,230,140',.25+.15*p);rc('#ffe090',x+4,b-12+Math.round(Math.sin(t*4)*1.5),6,6);rc('#fff8d0',x+6,b-11,2,2)}break;
 case 'porta':{rc('#2a2540',x-4,b-82,46,82);rc('#4a3322',x,b-74,38,74);g.fillStyle='#4a3322';g.beginPath();g.arc(x+19,b-74,19,Math.PI,0);g.fill();rc('#2a2030',x,b-50,38,3);rc('#2a2030',x,b-26,38,3);rc('#e8b85c',x+30,b-36,3,3);glow(x+19,b-40,40,'232,184,92',.14+.08*p);break}
 case 'portal':case 'portaltopo':{const ok=o[1]==='portal'?(F.met.naty&&F.met.guifer&&F.met.debora):(rm===4?F.met.yuri:F.met.padre);rc('#2a2540',x-4,b-82,46,82);rc('#4a3322',x,b-74,38,74);g.fillStyle='#4a3322';g.beginPath();g.arc(x+19,b-74,19,Math.PI,0);g.fill();
  rc('#2a2030',x,b-50,38,3);rc('#2a2030',x,b-26,38,3);rc('#e8b85c',x+30,b-36,3,3);if(ok){glow(x+19,b-40,48,'232,184,92',.2+.12*p);rc('rgba(255,225,150,'+(.5+.4*p)+')',x+18,b-72,2,72)}break}
 }}
function frame(){if(!on){lpf=0;return}t+=.016;g.setTransform(2,0,0,2,0,0);g.imageSmoothingEnabled=false;const q=R[rm];
 if(GM.on)gmDraw();else if(q.cor)corredor();else if(q.cor2)corredor2();else if(q.midia)midia();else if(q.qd)quadra();else if(q.sala)sala1();else if(q.esc)escola();else{if(q.sky)ceu();else parede(q);chao(q)}
 (q.win||[]).forEach(w=>{g.fillStyle='rgba(255,200,140,.05)';g.beginPath();g.moveTo(w,FL);g.lineTo(w+26,FL);g.lineTo(w+46,FL+22);g.lineTo(w+14,FL+22);g.fill()});
 if(rm===34&&F.ceia&&!F.jantar)FAMS.forEach((k,i)=>sprm(k,112+i*22));q.o.forEach(o=>objeto(o));if(NT.on)noiteDraw();
 if(q.p&&!NT.on&&(rm===34||!(F.ceia&&!F.jantar&&FAM.includes(q.p[0]))))spr(q.p[0],q.p[1],FL+8,0,q.p[0]==='debora'?-1:1);
 if(vivo){if(!busy){const a=(keys.L?-1:0)+(keys.R?1:0);if(a){px+=a*1.6;dir=a}
   if(px<10){if(q.l!=null)move(q.l,'l');else px=10}if(px>310){if(q.r!=null){if(q.qg&&!NT.free&&!['lara','fernando','erick','marcela'].every(i=>F.q[i]===2)){px=308;say('Você','Uma passagem selada no fundo do porão. Ainda faltam os pedidos de: '+['lara','fernando','erick','marcela'].filter(i=>F.q[i]!==2).map(i=>NPC[i].nome).join(', ')+'. Só abre quando todos estiverem entregues.')}else if(q.cg&&!NT.free&&!Object.keys(CH).every(i=>(F.pp[i]||[]).length>=10)){px=308;say('Você','A porta dos fundos continua fechada. Antes de ir ao quintal, quero conversar com todo mundo: '+Object.keys(CH).filter(i=>(F.pp[i]||[]).length>=10).length+'/10 conversas completas.')}else if(R[q.r].lock&&!NT.free&&!F.inv[R[q.r].lock]){px=308;say('Você',R[q.r].lm)}else if(q.gate&&q.p&&!NT.free&&!F.met[q.p[0]]){px=308;say('Você','Antes de seguir, preciso falar com '+NPC[q.p[0]].nome+'.')}else move(q.r,'r')}else px=310}}
  if(q.esc)escolaDraw();else if(!GM.on&&!NT.hide&&!(q.midia&&MID.sit))spr('você',px,FL+10+(q.qd?QY:0),keys.L||keys.R,dir);
  if(!busy&&near()){g.fillStyle='#e8b85c';const y=FL-80+(q.qd?QY:0)+Math.round(Math.sin(t*6));g.fillRect(Math.round(px)-1,y,3,5);g.fillRect(Math.round(px)-1,y+7,3,2)}}
 if(RV&&busy){const x=RV.replace('{hora}',hora());if($('dt').textContent!==x)$('dt').textContent=x}
 if(F.noiteFree&&!NT.on&&!CUT.on&&rm<ESR){NT.on=1;NT.free=1;NT.dimT=.5;NT.dim=.5}if(NT.free&&!F.noiteFree){NT.on=0;NT.free=0;NT.dim=0;NT.dimT=0;NT.sl=null}if(NT.on)noiteOver();else hzBtn.style.display='none';if(BLK>0){g.fillStyle='rgba(0,0,0,'+BLK+')';g.fillRect(0,0,320,180)}
 if(GLF>0)screenGlitch();if(CUT.fimTxt){g.fillStyle='#e8c46a';g.font='bold 11px monospace';g.textAlign='center';g.fillText('Continua…',160,92);g.textAlign='left'}
 const v=g.createRadialGradient(160,90,80,160,90,220);v.addColorStop(0,'rgba(0,0,0,0)');v.addColorStop(1,'rgba(5,6,20,.55)');g.fillStyle=v;g.fillRect(0,0,320,180);
 if(vivo){g.fillStyle='#000a';g.fillRect(3,3,120,12);g.fillStyle='#e8b85c';g.font='7px monospace';g.fillText(q.n+'  ◆'+Object.keys(F.met).length+'/'+Object.keys(NPC).length,6,12)}
 requestAnimationFrame(frame)}
/* ============ música tranquila ============ */
function musica(){const c=V8.ctx();if(!c)return;A=c;if(c.state==='suspended')c.resume();if(MU)return;MU=1;
 const M=A.createGain();MG=M;M.gain.value=(TEMA&&TV>0)?0:.8;M.connect(A.destination);
 const dl=A.createDelay(1),fb=A.createGain(),lo=A.createBiquadFilter();dl.delayTime.value=.4;fb.gain.value=.38;lo.type='lowpass';lo.frequency.value=2400;dl.connect(lo);lo.connect(fb);fb.connect(dl);lo.connect(M);
 const nt=(f,d,v,ty)=>{const o=A.createOscillator(),n=A.createGain(),n0=A.currentTime;o.type=ty;o.frequency.value=f;n.gain.setValueAtTime(.0001,n0);n.gain.linearRampToValueAtTime(v,n0+(d>3?.8:.02));n.gain.exponentialRampToValueAtTime(.0003,n0+d);o.connect(n);n.connect(dl);n.connect(M);o.start();o.stop(n0+d+.1)};
 const ch=[[130.8,196,261.6,329.6],[110,164.8,220,261.6],[174.6,220,261.6,349.2],[98,196,246.9,293.7]];let s=0;
 setInterval(()=>{if(!on||A.state!=='running')return;const c2=ch[(s>>3)%4];if(s%8===0)c2.forEach(f=>nt(f,4,.014,'sine'));
  nt(c2[[0,1,2,3,2,1,3,2][s%8]]*2,1.4,.035,'triangle');if(s%8===4&&Math.random()<.6)nt(c2[3]*(Math.random()<.5?2:3),1.8,.025,'sine');s++},520)}
/* ============ início ============ */
function start(c){musica();const d=c?load():null;F=d?d.F:{met:{},ch:{},frs:[],fim:0};F.ch=F.ch||{};F.met=F.met||{};F.frs=F.frs||[];F.seen=F.seen||{};F.inv=F.inv||{};F.q=F.q||{};F.got=F.got||{};F.mg=F.mg||{};F.pp=F.pp||{};R[34].p=F.ceia&&!F.jantar?['debora',68]:null;
 rm=d?d.rm:0;px=d?d.px:70;dir=1;busy=0;vivo=1;document.documentElement.classList.add('p2');$('ti').hidden=1;$('dn').textContent=R[rm].n;run();tema(rm>22);
 if(d){end();if(rm===ESR&&!F.escFim){ES.h=[{x:px,d:1}];ES.lx=px;ES.go=0;ES.ent=[];ES.auto=0;if(px<20){px=-12;ES.h=[{x:-12,d:1}];ES.lx=-12;ES.auto=1;ES.alvo=128;ES.cb=escolaIntro;busy=1}}else if(F.jantar&&!F.escola)setTimeout(manha,500)}else{SV.part(2);seq([['Você','Uma luz azul. Cheiro de pedra molhada e de pão quente.'],['Você','Não é mais o hotel. Alguém deixou um portão aberto para mim, e há música em algum lugar.'],['Você',"Vou seguir o som. Acho que estão me esperando: a família Ailton's."]])}}
function enter(){if(busy&&$('dlg').onclick)$('dlg').onclick();else act()}
function run(){on=1;if(!lpf){lpf=1;frame()}}

/* ===== v50: relógio 4:40 PM, saída da escola, castelo e sono ===== */
const NT={free:0,on:0,hide:0,dim:0,dimT:0,fol:[],h:[],lp:0,sl:null,tint:null};
const DORM=[['naty','Quarto da Naty',190],['guifer','Quarto do Guifer',160],['debora','Quarto da Débora',160],['yuri','Quarto do Yuri',170],['lara','Quarto da Lara',216],['fernando','Quarto do Proviso',222],['erick','Quarto do Erick',190],['marcela','Quarto da Marcela',222],['alinny','Quarto Noturno da Alinny',205]];
const BEDC={naty:'#b07a9e',guifer:'#5a6a90',debora:'#7a4a5a',yuri:'#2f7a52',lara:'#3a5ca8',fernando:'#7a4aa0',erick:'#2a7a4a',marcela:'#a05a8a',alinny:'#4a4a9a'};
function lieSpr(k,cx){const i=IM[k];if(!i||!i.complete||!i.naturalHeight)return;const h=(HH[k]||66)*.62,w=i.naturalWidth/i.naturalHeight*h;g.save();g.translate(Math.round(cx+21),FL-17);g.rotate(-Math.PI/2);g.drawImage(i,-w/2,-h,w,h);g.restore()}
function LENCOL(k,cx){const c=BEDC[k]||'#556';
 rc(c,cx-10,FL-29,41,23);rc(c,cx-9,FL-30,39,1);rc('rgba(255,255,255,.22)',cx-9,FL-30,39,2);
 rc('rgba(0,0,0,.2)',cx-10,FL-11,41,5);rc('rgba(255,255,255,.12)',cx+8,FL-29,1,23)}
const MELI=[new Image(),new Image()];MELI[0].src="assets/img_23.png";MELI[1].src="assets/img_24.png";
const MELX=109;
function melinaPenteia(){const i=MELI[Math.floor(performance.now()/520)%2];if(!i.complete||!i.naturalHeight)return;
 const h=66,w=i.naturalWidth/i.naturalHeight*h,x=MELX,y=FL+8;g.fillStyle='rgba(0,0,0,.45)';g.beginPath();g.ellipse(x,y,12,3,0,0,7);g.fill();g.drawImage(i,Math.round(x-w/2),y-h,w,h)}
const BRUSH_SRC="assets/img_25.png";
function gBrush(b,k,win){const TH=230,BH=52;let y=BH/2,d=1,sp=k.spd,h=0,ty=0;const novo=()=>{ty=40+Math.random()*(TH-80)};novo();
 b.innerHTML='<div id="mh" style="position:relative;width:110px;height:'+TH+'px;margin:0 auto;border:2px solid var(--gold);background:repeating-linear-gradient(90deg,#8a3a1c 0 5px,#a24a22 5px 9px);overflow:hidden;cursor:pointer;touch-action:manipulation"><div id="mhd" style="position:absolute;left:50%;width:20px;height:20px;margin:-10px 0 0 -10px;border-radius:50%;background:#3ddc5a;box-shadow:0 0 10px #3ddc5a;border:2px solid #fff"></div><img id="mhb" src="'+BRUSH_SRC+'" style="position:absolute;left:50%;height:'+BH+'px;transform:translate(-50%,-50%);pointer-events:none"></div><button id="ta" style="margin-top:12px">Agora!</button>';
 const place=()=>{const e=$('mhd');if(e)e.style.top=ty+'px'};place();
 const iv=setInterval(()=>{y+=d*sp;if(y>=TH-BH/2){y=TH-BH/2;d=-1}else if(y<=BH/2){y=BH/2;d=1}const m=$('mhb');if(m)m.style.top=y+'px'},16);
 const hit=()=>{if(Math.abs(y-ty)<k.tol){h++;sp*=1.1;$('mgs').textContent='Pentou! '+h+'/'+k.hits;novo();place();if(h>=k.hits){clearInterval(iv);win()}}else{h=Math.max(0,h-1);$('mgs').textContent='Passou do ponto! '+h+'/'+k.hits}};
 $('ta').onclick=hit;$('mh').onclick=hit;return()=>clearInterval(iv)}
function melHair(){
 if(F.melHair)return say('Melina','Obrigada pelo cabelo! Ficou tão macio, ksksks. Agora eu já vou deitar.');
 say('Melina','Ei, você aí! Pode me ajudar a pentear o cabelo? Ele embolou todo hoje, ksksks.',[['Claro, deixa comigo!',()=>{$('ch').innerHTML='';busy=1;
  MGC=gBrush(mgBox('Pentear o cabelo da Mel','Clique quando a escova passar pelo ponto verde.'),{hits:4,spd:2.2,tol:14},()=>{if(MGC)MGC();MGC=null;const e=$('mg');if(e)e.remove();
   F.melHair=1;F.frs.push('Noite: você ajudou a Mel a pentear o cabelo antes de dormir.');save();say('Melina','Aaah, ficou liso demais! Obrigada, de verdade! Agora é só dormir, ksksks.')})}],['Agora não',end]])}
function noiteDraw(){NVIS();MUS();if(NT.free&&R[rm].n==='Quarto da Melina')melinaPenteia();CAD();
 if(NT.free){const d=DORM.find(x=>x[1]===R[rm].n);NT.sl=d?{k:d[0],bx:d[2],st:d[0]==='fernando'?'stand':'lie',n:100,x:d[0]==='fernando'?165:0}:null}
 if(NT.fol.length){const mv=Math.abs(px-NT.lp)>.01;if(mv){NT.h.push({x:px,d:dir});if(NT.h.length>600)NT.h.splice(0,100)}NT.lp=px;
  for(let i=NT.fol.length-1;i>=0;i--){const k=NT.fol[i],idx=NT.h.length-1-(i+1)*10;let x,d;if(idx>=0){x=NT.h[idx].x;d=NT.h[idx].d}else{d=NT.h[0].d;x=NT.h[0].x+idx*1.6*d}spr(k,x,FL+8,mv,k==='fernando'?-d:d)}}
 const S=NT.sl;if(!S)return;const cx=S.bx;
 rc('#2a1d18',cx-30,FL-26,4,32);rc('#2a1d18',cx+26,FL-12,3,18);rc('#4a3426',cx-28,FL-6,56,6);rc('#e9e2d6',cx-26,FL-10,52,5);rc('#f6f2ea',cx-25,FL-16,13,6);
 rc('#3a2a20',cx+32,FL-14,10,16);rc('#f0c070',cx+35,FL-21,4,6);
 if(S.k==='fernando'){if(S.st==='walk'){S.x+=1.6;spr(S.k,S.x,FL+8,1,-1);if(S.x>=165){S.st='stand';S.n=0}}else{S.n++;spr(S.k,S.x,FL+8,0,1)}return}
 if(S.st==='walk'){S.x+=1.6;spr(S.k,S.x,FL+8,1,S.k==='lara'?-1:1);if(S.x>=cx+22){S.st='lie';S.n=0}}
 else{S.n++;lieSpr(S.k,cx);LENCOL(S.k,cx);
  if(F.gl&&F.gl[S.k]){const hh=HH[S.k];HH[S.k]=22;glitchFx(S.k,cx,FL-4);HH[S.k]=hh}}}
function noiteOver(){
 hzBtn.style.display=(NT.free&&rm===0&&!busy&&!HZ.on)?'block':'none';
 NT.dim+=(NT.dimT-NT.dim)*.05;
 if(NT.tint){g.fillStyle=NT.tint;g.fillRect(0,0,320,180)}
 if(NT.dim>.005){g.fillStyle='rgba(4,6,24,'+NT.dim+')';g.fillRect(0,0,320,180);
  if(NT.sl&&NT.sl.st==='lie')glow(NT.sl.bx+37,FL-24,46,'255,190,120',.14*Math.min(1,NT.dim/.5))}
 if(NT.free&&!NT.hide&&!HZ.on)glow(px,FL-30,70,'255,205,150',.16);
 const S=NT.sl;if(S&&S.st==='lie'&&S.n>25){for(let i=0;i<3;i++){const a=((t*.5+i/3)%1);g.fillStyle='rgba(225,232,255,'+(.9*(1-a))+')';g.font='bold '+(5+i*2)+'px monospace';g.fillText('z',S.bx-24+a*16+i*3,FL-32-a*24)}}}
async function cenaNoite(){
 const f=$('fim'),el=$('ft');let ok=0;
 try{
  NT.on=1;NT.hide=0;NT.sl=null;NT.fol=[];NT.dim=0;NT.dimT=0;NT.tint=null;CUT.on=1;busy=1;keys.L=0;keys.R=0;
  V8.onFim=null;V8.onFb=null;$('fc').hidden=1;$('fb').hidden=1;el.textContent='';el.className='';
  f.style.transition='none';f.style.opacity=0;f.hidden=0;void f.offsetWidth;f.style.transition='opacity .9s';f.style.opacity=1;
  await esp(1000);
  el.className='alarme';el.textContent='🕟\n4:40 PM';toque();await esp(4500);
  el.className='';el.textContent='';
  for(const l of["O relógio toca.","Quatro e quarenta da tarde.","Todos descem a escada, atravessam o corredor e saem da escola."]){for(const ch of l){el.textContent+=ch;if(ch!==' ')tic();await esp(40)}el.textContent+='\n\n';await esp(650)}
  await esp(500);
  /* 2º andar → escada */
  rm=COR2;px=30;dir=1;FQ.h=[{x:20,d:1}];FQ.lp=-1;$('dn').textContent=R[rm].n;BLK=0;
  f.style.transition='opacity 1.3s';f.style.opacity=0;await esp(1400);f.hidden=1;f.style.transition='';f.style.opacity='';el.textContent='';
  await falas([['Naty',"Já são quase cinco horas. Bora descer, gente."],['Guifer',"Finalmente! Meus pés já estavam pedindo a escada, ksks."]]);
  await andar(188);await esp(300);
  /* térreo → saída pelo corredor */
  await fadeTo(1,500);rm=COR;px=188;dir=1;FQ.h=[{x:188,d:1}];FQ.lp=-1;$('dn').textContent=R[rm].n;await fadeTo(0,500);
  await andar(300);await esp(250);
  /* frente da escola */
  await fadeTo(1,600);rm=ESR;px=SX;dir=1;ES.go=0;ES.auto=0;ES.ent=[];ES.h=[{x:SX,d:1}];ES.lx=SX;$('dn').textContent=R[rm].n;NT.tint='rgba(255,140,60,.16)';await fadeTo(0,600);
  await falas([['Débora',"Vamos para o castelo antes que escureça."],['Naty',"Todo mundo junto, hein. Ninguém fica para trás."]]);
  await andar(350);
  /* pátio do castelo */
  await fadeTo(1,600);rm=0;NT.tint=null;px=-12;dir=1;NT.fol=ES.ord.slice();NT.h=[{x:-12,d:1}];NT.lp=-12;$('dn').textContent=R[rm].n;
  voltaSom();try{if(TEMA)TEMA.volume=TG?1:0}catch(e){}tema(true);await fadeTo(0,700);
  await andar(110);
  await falas([['Naty',"Chegamos em casa. Que dia longo, hein?"],['Débora',"Já está quase de noite. Hora de descansar."]]);
  await andar(318);
  /* grande salão */
  await fadeTo(1,600);rm=1;px=-12;dir=1;NT.h=[{x:-12,d:1}];NT.lp=-12;$('dn').textContent=R[rm].n;await fadeTo(0,600);
  await andar(150);
  await falas([['Naty',"Boa noite, pessoal. Cada um no seu quarto."],['Yuri',"Eu durmo antes de encostar no travesseiro."],['Marcela',"Falem baixinho, o bebê já dormiu."],['Alinny',"Boa noite… e obrigada por hoje."],['Você',"Boa noite. Eu vou ficar mais um pouco por aqui."]]);
  await fadeTo(1,700);
  /* cada um no seu quarto, luzes baixas */
  NT.fol=[];NT.hide=1;
  for(const [k,nome,bx] of DORM){
   const ri=R.findIndex(r=>r.n===nome);if(ri<0)continue;
   rm=ri;$('dn').textContent=R[rm].n;NT.dim=0;NT.dimT=0;NT.sl={k,bx,x:14,st:'walk',n:0};
   await fadeTo(0,350);
   while(NT.sl.st==='walk')await raf();
   await esp(350);NT.dimT=.62;await esp(1500);
   await fadeTo(1,350);
  }
  /* só o protagonista fica acordado */
  NT.sl=null;NT.hide=0;rm=1;px=150;dir=1;NT.dim=0;NT.dimT=.55;$('dn').textContent=R[rm].n;
  await fadeTo(0,900);await esp(1400);
  await falas([['Você',"A casa inteira dormiu. Só se ouve o silêncio."],['Você',"Todos dormem… menos eu. Eu continuo acordado."]]);
  await esp(600);
  F.noite=1;F.noiteFree=1;F.frs.push("Tarde: às 4:40 PM o relógio tocou e todos saíram da escola rumo ao castelo. Cada um foi dormir no seu quarto. Só você ficou acordado.");
  await falas([['Você',"Posso andar pelo castelo sem fazer barulho. Ninguém vai acordar."]]);
  NT.free=1;NT.dimT=.5;CUT.on=0;end();save();ok=1;
 }catch(e){console.error(e)}
 f.hidden=1;f.style.transition='';f.style.opacity='';
 if(!ok){await fadeTo(1,1600);NT.on=0;NT.hide=0;NT.sl=null;NT.fol=[];CUT.on=0;CUT.fimTxt=1}}
/* ===== v51: cenas na horizontal, pulo e ataque ===== */

/* ===== v57: a palavra piscando, o A dourado e o livro derrubado ===== */
const CA={on:0,bx:148,act:[],cup:0,book:0,stain:0,shake:0,smoke:0,sx:0};let CAB=0;
const NL={lara:1,fernando:1};
const REQ=['Quarto da Naty','Quarto do Guifer','Quarto da Débora','Quarto do Yuri','Quarto da Lara','Quarto do Erick','Quarto da Marcela','Quarto Noturno da Alinny','Quarto do Proviso','Quarto da Melina'];
(function(){const s=document.createElement('style');s.textContent='@keyframes cshk{0%{translate:-4px 3px}25%{translate:5px -3px}50%{translate:-3px -4px}75%{translate:4px 4px}100%{translate:-4px 3px}}.cshake{animation:cshk .09s infinite}@keyframes cblink{0%,49%{opacity:1}50%,100%{opacity:0}}#awd{position:fixed;left:0;right:0;top:34%;text-align:center;z-index:7;pointer-events:none;font:bold clamp(34px,11vw,72px) Georgia,serif;letter-spacing:.35em;color:#e8b85c;text-shadow:0 0 18px #e8b85c,0 0 40px #8a1f3d;animation:cblink .7s steps(1) infinite}#cfl{position:fixed;inset:0;z-index:8;pointer-events:none;opacity:0;background:#fff}';document.head.append(s)})();

const KEEPER_SRC="assets/audio_02.mp3";
const KM={a:null,on:0,iv:0};
function musA(on_,ms){ms=ms||1500;clearInterval(KM.iv);
 if(on_){KMUTE();if(!KM.a){KM.a=new Audio(KEEPER_SRC);KM.a.loop=true}KM.on=1;KM.a.currentTime=0;KM.a.volume=0;KM.a.play().catch(()=>{});const t1=performance.now();KM.iv=setInterval(()=>{const q=Math.min(1,(performance.now()-t1)/ms);KM.a.volume=.75*q;if(q>=1)clearInterval(KM.iv)},60)}
 else{KM.on=0;const a=KM.a;if(!a)return;const v0=a.volume,t1=performance.now();KM.iv=setInterval(()=>{const q=Math.min(1,(performance.now()-t1)/ms);a.volume=Math.max(0,v0*(1-q));if(q>=1){clearInterval(KM.iv);a.pause();a.currentTime=0}},60)}}
function KMUTE(){try{TO=0;if(A){if(MG){MG.gain.cancelScheduledValues(A.currentTime);MG.gain.value=0}if(TG){TG.gain.cancelScheduledValues(A.currentTime);TG.gain.value=0}}if(TEMA&&!TEMA.paused)TEMA.pause()}catch(e){}}
function MUS(){const inT=NT.free&&F.aEv===1&&R[rm].n==='Torre do Relógio';if(inT&&!KM.on)musA(1,2500);else if(!inT&&KM.on&&F.aEv===1){musA(0,1500);try{tema(rm>22)}catch(e){}}
 if(KM.on&&((MG&&MG.gain.value>.001)||(TG&&TG.gain.value>.001)||(TEMA&&!TEMA.paused)))KMUTE()}
function NVIS(){if(!NT.free||CAB||F.aEv)return;const n=R[rm].n;if(REQ.includes(n)){F.nv=F.nv||{};F.nv[n]=1}
 if(!busy&&!CUT.on&&!HZ.on&&!MGC&&REQ.every(x=>F.nv&&F.nv[x])){CAB=1;cenaPalavra()}}
function flipD(k,d){return NL[k]?-d:d}
function CAD(){
 if(CA.book){const x=CA.bx;
  rc('#3a3354',x-2,FL-22,24,22);rc('#5a5078',x-2,FL-22,24,3);rc('#2a2440',x-2,FL-4,24,4);
  rc('#e8b85c',x+1,FL-34,13,12);rc('#b8862c',x+1,FL-23,13,1);rc('#fff0b0',x+2,FL-34,11,1);g.fillStyle='#5a3a0c';g.font='bold 9px monospace';g.fillText('A',x+5,FL-24);
  glow(x+8,FL-30,30,'255,215,110',.25+.08*Math.sin(t*5));
  if(CA.stain){rc('rgba(60,32,14,.9)',x+3,FL-34,Math.min(10,CA.stain),7);rc('rgba(60,32,14,.8)',x+1,FL-23,Math.min(13,CA.stain+2),1);rc('rgba(60,32,14,.85)',x+15,FL-22,2,Math.min(18,CA.stain*1.1))}
  const cx=x+16;if(CA.cup===0){rc('#f2f2f2',cx,FL-30,5,8);rc('#5a3410',cx+1,FL-29,3,2);rc('#d8d8d8',cx+5,FL-28,2,4)}else if(CA.cup===1){rc('#f2f2f2',cx-1,FL-25,8,3);rc('#5a3410',cx+7,FL-24,3,1)}}
 CA.act.forEach(a=>spr(a.k,a.x,FL+8,a.mv,flipD(a.k,a.d)));
 if(CA.smoke>0){const p=CA.smoke;for(let i=0;i<70;i++){const a=i*2.399+t*1.3,r=(6+(i%9)*5)*p*(1+.25*Math.sin(t*3+i));
  g.fillStyle='rgba('+(8+i%6)+',4,'+(14+i%10)+','+Math.min(.85,.2+p*.5)+')';const sz=4+(i%4)*3*p;g.fillRect(Math.round(CA.sx+Math.cos(a)*r*1.4-sz/2),Math.round(FL-34+Math.sin(a)*r*1.1-sz/2),sz,sz)}
  glow(CA.sx,FL-34,70*p,'40,0,70',.35*p)}}
async function mover(a,x,v){v=v||2;while(Math.abs(a.x-x)>v){const d=Math.sign(x-a.x);a.x+=d*v;a.d=d;a.mv=1;await raf()}a.mv=0}
function aud(){const c=V8.ctx();if(c&&c.state==='suspended')c.resume();return c}
function somAgua(ms){const c=aud();if(!c)return;try{const n=c.sampleRate*(ms/1000),b=c.createBuffer(1,n,c.sampleRate),d=b.getChannelData(0);for(let i=0;i<n;i++)d[i]=(Math.random()*2-1);
 const s=c.createBufferSource();s.buffer=b;const f=c.createBiquadFilter();f.type='bandpass';f.frequency.value=1800;f.Q.value=.8;const lf=c.createOscillator(),lg=c.createGain();lf.frequency.value=11;lg.gain.value=700;lf.connect(lg);lg.connect(f.frequency);
 const e=c.createGain();e.gain.setValueAtTime(.0001,c.currentTime);e.gain.linearRampToValueAtTime(.22,c.currentTime+.15);e.gain.setValueAtTime(.22,c.currentTime+ms/1000-.25);e.gain.linearRampToValueAtTime(.0001,c.currentTime+ms/1000);
 s.connect(f);f.connect(e);e.connect(c.destination);s.start();lf.start();s.stop(c.currentTime+ms/1000);lf.stop(c.currentTime+ms/1000)}catch(e){}}
function somGrave(f0,f1,ms,vol){const c=aud();if(!c)return;try{const o=c.createOscillator(),e=c.createGain();o.type='sawtooth';o.frequency.setValueAtTime(f0,c.currentTime);o.frequency.exponentialRampToValueAtTime(f1,c.currentTime+ms/1000);
 e.gain.setValueAtTime(vol||.2,c.currentTime);e.gain.exponentialRampToValueAtTime(.0005,c.currentTime+ms/1000);o.connect(e);e.connect(c.destination);o.start();o.stop(c.currentTime+ms/1000)}catch(e){}}
function piscaTela(n,ms){return new Promise(async res=>{let e=$('cfl');if(!e){e=document.createElement('div');e.id='cfl';document.body.append(e)}
 for(let i=0;i<n;i++){e.style.background=i%2?'#c37bff':'#fff';e.style.opacity=.95;somGrave(260,60,ms*1.6,.12);await esp(ms);e.style.opacity=0;await esp(ms)}res()})}

async function cenaPalavra(){
 try{
  busy=1;CUT.on=1;keys.L=0;keys.R=0;
  NT.dimT=.72;await esp(1200);
  const w=document.createElement('div');w.id='awd';w.textContent='VOLTE';document.body.append(w);
  somGrave(90,40,1600,.25);await esp(2200);
  await falas([['???',"Volte para o início e force o A dourado..."],['???',"Não... não faça isso..."]]);
  w.remove();NT.dimT=.5;await esp(500);
  await falas([['Você',"O A dourado de Ailton's... É o selo da carta lá na Torre do Relógio. Preciso ir até lá e olhar de perto."]]);
  F.aEv=1;CUT.on=0;end();save();
 }catch(e){console.error(e);const w=$('awd');if(w)w.remove();F.aEv=1;CUT.on=0;end()}
}

async function cenaLivro(){
 try{
  busy=1;CUT.on=1;keys.L=0;keys.R=0;F.aEv=2;
  if(R[rm].n!=='Torre do Relógio'){rm=R.findIndex(r=>r.n==='Torre do Relógio');$('dn').textContent=R[rm].n;px=170}CA.bx=148;await andar(205);dir=-1;
  await falas([['Você',"O selo dourado, com o A de Ailton's... Deixa eu ver isso de perto."]]);
  somGrave(180,40,900,.3);CA.on=1;CA.book=1;
  await piscaTela(7,70);
  /* a tela para */
  const fl=$('cfl');fl.style.background='#000';fl.style.opacity=1;await esp(1600);fl.style.opacity=0;await esp(500);
  const S={k:'stella',x:-24,d:1,mv:0};CA.act.push(S);
  const pS=mover(S,122,3.4);
  await falas([['Stella',"O QUE VOCÊ ESTÁ FAZENDO!? Não pode abrir o livro dourado! Apenas quando todos os 10 membros estiverem aqui! Ou seja, NUNCA!"]]);await pS;
  await falas([['Stella',"DA ÚLTIMA VEZ QUE A GENTE TENTOU FAZER ISSO, FOMOS EXTERMINADOS! Ailton simplesmente removeu todos nós do grupo e acabou tudo.."]]);
  const G={k:'guifer',x:344,d:-1,mv:0};CA.act.push(G);const pG=mover(G,250,2.4);
  await falas([['Guilherme',"Ei, mísera, se tu abrir isso vai dar problema."]]);await pG;
  await falas([['Stella',"Exatamente! Da última vez ele não foi ao encontro com a família toda, e nem teve! Pelo que eu ouvi falar!"],['Guilherme',"Hehe.. até hoje eu lembro do boneco.."],['Você',"Que boneco?"],['Guilherme',"Daquele quando ele puxou a perninha, subiu um p#nis bem grande! Kkk"]]);
  const E={k:'erick',x:-24,d:1,mv:0};CA.act.push(E);const pE=mover(E,94,2.6);
  await falas([['Erick',"Cala a boca aê, Caraí, que zuada!"]]);await pE;
  const Al={k:'alinny',x:-24,d:1,mv:0};CA.act.push(Al);const pA=mover(Al,62,2.4);
  await falas([['Alinny',"O que tá acontecendo a uma hora dessas!"]]);await pA;
  const L={k:'lara',x:-24,d:1,mv:0};CA.act.push(L);const pL=mover(L,138,1.1);
  await falas([['Lara',"Aah... que sono... hum! Olha que livro legal, né?"]]);await pL;
  await falas([['Stella',"Lara, tira o novato(a) daqui, quase abriu o livro!"],['Lara',"Tá... *voz de sono*"]]);
  await falas([['Narrador',"...Lara, cansada, deixa o café ao lado do livro.."]]);
  CA.cup=1;somAgua(2000);
  for(let i=0;i<120;i++){CA.stain=Math.min(16,i/6);await raf()}
  await falas([['Lara',"Eita gente............"]]);
  await falas([['Guilherme',"OO PORRA!"],['Alinny',"NÃO!!!"],['Stella',"Que diabos!!!!"],['Erick',"Eita porra, fudeu Carai!!! Não, NÃOOOO!"]]);
  const M={k:'marcela',x:-24,d:1,mv:0};CA.act.push(M);const pM=mover(M,30,3);
  somGrave(70,30,1800,.35);$('st').classList.add('cshake');
  await falas([['Marcela',"O que foi isso!! O bebê até acordou!! MDS, LARA, PQ TU É TÃO BURRA!!"]]);await pM;
  await falas([['Narrador',"O castelo todo começa a tremer..."]]);
  await falas([['Você',"O QUE SIGNIFICA ISSO?"],['Marcela',"Ela derrubou o café no livro! Ele vai nos fazer mal!"],['Você',"Ele quem???"],['Stella',"A porcaria do Anfitrião, ou Ailton pra você.."],['Guilherme',"O livro foi danificado por causa dessa rapariga da Lara!"],['Lara',"Fecha teu c# oh arrombado!! Foi sem querer!"]]);
  /* o tremor para e a fumaça preta captura o protagonista */
  $('st').classList.remove('cshake');somGrave(55,28,2600,.3);
  CA.sx=px;
  for(let i=0;i<150;i++){CA.smoke=Math.min(1.6,i/70);await raf()}
  NT.hide=1;
  for(let i=0;i<110;i++){CA.smoke=1.6+i/40;await raf()}
  await fadeTo(1,2600);await esp(900);
  CA.smoke=0;CA.act=[];CA.book=0;CA.on=0;
  F.aEv=3;F.frs.push("Noite: você foi olhar o A dourado da carta na Torre do Relógio, a Lara derrubou o café no livro dourado e uma fumaça preta levou você para outro universo.");save();
  CUT.fimTxt=1;await esp(7000);musA(0,4000);
 }catch(e){console.error(e);musA(0,1500);$('st').classList.remove('cshake');CA.smoke=0;CA.act=[];CA.on=0;F.aEv=3;CUT.on=0;NT.hide=0;BLK=0;end()}
}

const HZ={on:0};
const HZL1={title:'Corredor das Falhas',w:1500,seg:[[0,640],[740,1160],[1260,1500]],pl:[[300,232,110],[560,205,100],[880,235,110],[1180,212,110]],en:[[420,0],[820,1],[1010,1],[1330,2],[1410,2]],ex:1440};
function bip(f,d){try{const c=V8.ctx();if(!c)return;const o=c.createOscillator(),v=c.createGain();o.type='square';o.frequency.value=f;v.gain.value=.05;o.connect(v);v.connect(c.destination);o.start();o.stop(c.currentTime+d)}catch(e){}}
function hzNew(L){return{L,k:{},jb:0,t:0,kills:0,dead:0,win:0,safe:{x:30,y:260},cam:0,
 p:{x:30,y:260,vx:0,vy:0,f:1,g:0,co:0,nj:0,hp:5,inv:0,kb:0,at:0,cd:0,hit:new Set()},
 en:L.en.map(([x,si])=>({x,y:278,w:22,h:22,hp:3,dir:1,home:x,a:L.seg[si][0],b:L.seg[si][1],kb:0,kv:0,fl:0}))}}
function hzStep(S){
 const L=S.L,p=S.p,k=S.k;S.t++;
 if(S.win){S.win++;return}
 if(S.dead){if(--S.dead<=0){const k0=S.k,n=hzNew(L);Object.assign(S,n);S.k=k0}return}
 const mx=(k.R?1:0)-(k.L?1:0);
 if(p.kb>0)p.kb--;else{p.vx=mx*3.4;if(mx)p.f=mx}
 if(k.J&&!k.Jh){k.Jh=1;S.jb=8}if(!k.J){k.Jh=0;if(p.vy<-6.5)p.vy=-6.5}
 if(S.jb>0)S.jb--;
 if(p.g)p.co=6;else if(p.co>0)p.co--;
 if(S.jb>0){if(p.co>0){p.vy=-11.5;p.co=0;S.jb=0;bip(520,.08)}else if(p.nj<1){p.vy=-10;p.nj++;S.jb=0;bip(660,.08)}}
 if(k.A&&!k.Ah){k.Ah=1;if(p.cd<=0){p.at=12;p.cd=22;p.hit=new Set();bip(180,.07)}}if(!k.A)k.Ah=0;
 if(p.at>0)p.at--;if(p.cd>0)p.cd--;if(p.inv>0)p.inv--;
 p.vy=Math.min(14,p.vy+.6);p.x=Math.max(0,Math.min(L.w-18,p.x+p.vx));
 const pb=p.y+40;p.y+=p.vy;const b=p.y+40;p.g=0;
 const sf=[];L.seg.forEach(([a,c],i)=>sf.push([a,c,300,i]));L.pl.forEach(([x,y,w])=>sf.push([x,x+w,y,-1]));
 for(const[a,c,sy,si]of sf){if(p.vy>=0&&p.x+18>a&&p.x<c&&pb<=sy+1&&b>=sy){p.y=sy-40;p.vy=0;p.g=1;p.nj=0;if(si>=0&&p.x>a+30&&p.x+18<c-30)S.safe={x:p.x,y:p.y};break}}
 if(p.y>420){p.hp--;bip(110,.2);if(p.hp<=0)S.dead=70;else{p.x=S.safe.x;p.y=S.safe.y-4;p.vx=0;p.vy=0;p.inv=60}}
 for(const e of S.en){if(e.hp<=0)continue;
  if(e.kb>0){e.kb--;e.x+=e.kv}else{const dx=p.x-e.x;if(Math.abs(dx)<170&&Math.abs(p.y+40-300)<70&&p.hp>0){e.dir=Math.sign(dx)||1;e.x+=e.dir*1.15}else{e.x+=e.dir*.6;if(Math.abs(e.x-e.home)>70)e.dir*=-1}}
  e.x=Math.max(e.a+2,Math.min(e.b-e.w-2,e.x));if(e.fl>0)e.fl--;
  if(p.at>0){const hx=p.f>0?p.x+18:p.x-36;if(!p.hit.has(e)&&hx<e.x+e.w&&hx+36>e.x&&p.y+6<e.y+e.h&&p.y+36>e.y){p.hit.add(e);e.hp--;e.kb=10;e.kv=p.f*3.5;e.fl=8;bip(300,.06);if(e.hp<=0){S.kills++;bip(90,.18)}}}
  if(e.hp>0&&p.inv<=0&&p.x+18>e.x&&p.x<e.x+e.w&&p.y+40>e.y&&p.y<e.y+e.h){p.hp--;p.inv=70;p.kb=10;p.vx=(p.x<e.x?-1:1)*4;p.vy=-6;bip(110,.15);if(p.hp<=0)S.dead=70}}
 if(S.en.every(e=>e.hp<=0)&&p.x>=L.ex-20)S.win=1}
function hzDraw(S,c){const L=S.L,p=S.p,cam=Math.round(S.cam),T=S.t;c.textAlign='left';
 const gr=c.createLinearGradient(0,0,0,360);gr.addColorStop(0,'#0a0a1c');gr.addColorStop(1,'#241338');c.fillStyle=gr;c.fillRect(0,0,640,360);
 for(let i=0;i<22;i++){const x=((i*97-cam*.3)%720+720)%720-40,h=60+(i*53)%110;c.fillStyle='rgba(60,50,120,.25)';c.fillRect(x,300-h,34,h)}
 if(T%90<4){c.fillStyle='rgba(0,255,255,.12)';c.fillRect(0,(T*7)%300,640,3);c.fillStyle='rgba(255,0,200,.10)';c.fillRect(0,(T*13)%300,640,2)}
 L.seg.forEach(([a,b])=>{c.fillStyle='#1a1530';c.fillRect(a-cam,300,b-a,60);c.fillStyle='#6a5acd';c.fillRect(a-cam,300,b-a,3)});
 L.pl.forEach(([x,y,w])=>{c.fillStyle='#2a2250';c.fillRect(x-cam,y,w,8);c.fillStyle='#8a7aff';c.fillRect(x-cam,y,w,2)});
 const open=S.en.every(e=>e.hp<=0);c.fillStyle=open?'#e8b85c':'#555';c.fillRect(L.ex-cam,252,28,48);c.fillStyle='rgba(0,0,0,.55)';c.fillRect(L.ex+4-cam,260,20,40);
 for(const e of S.en){if(e.hp<=0)continue;const x=e.x-cam;for(let i=0;i<4;i++){c.fillStyle=e.fl>0?'#fff':['#ff2fd0','#2ff0ff','#7a5cff','#fff'][(i+(T>>2))%4];c.fillRect(x+(i%2)*11+((Math.random()*3-1)|0),e.y+(i>>1)*11+((Math.random()*3-1)|0),10,10)}c.fillStyle='#e33';c.fillRect(x,e.y-5,e.w*e.hp/3,2)}
 if(!(p.inv>0&&((T>>2)%2))){const i=IM['você'];if(i&&i.complete&&i.naturalHeight){const h=50,w=i.naturalWidth/i.naturalHeight*h;c.save();c.shadowColor='rgba(200,210,255,.9)';c.shadowBlur=6;c.translate(p.x+9-cam,p.y+42);if(p.f<0)c.scale(-1,1);c.drawImage(i,-w/2,-h,w,h);c.restore()}else{c.fillStyle='#4af';c.fillRect(p.x-cam,p.y,18,40)}}
 if(p.at>0){c.strokeStyle='rgba(255,255,255,'+(p.at/12)+')';c.lineWidth=4;c.beginPath();const cx=p.x+9-cam+p.f*16,cy=p.y+22;if(p.f>0)c.arc(cx,cy,28,-1,1);else c.arc(cx,cy,28,Math.PI-1,Math.PI+1);c.stroke()}
 c.font='16px monospace';for(let i=0;i<5;i++){c.fillStyle=i<p.hp?'#ff4a6a':'#443';c.fillText('♥',10+i*18,24)}
 c.fillStyle='#e8b85c';c.font='12px monospace';c.fillText('Falhas: '+S.kills+'/'+S.en.length,10,42);c.textAlign='center';c.fillText(L.title,320,18);
 if(T<300)c.fillText('← → andar   Espaço pular (2x no ar)   Z atacar',320,345);
 if(!open&&p.x>L.ex-200)c.fillText('Derrote todas as falhas para abrir a saída',320,44);
 if(S.dead){c.fillStyle='rgba(0,0,0,.6)';c.fillRect(0,0,640,360);c.fillStyle='#fff';c.font='bold 22px monospace';c.fillText('Você caiu… recomeçando',320,180)}
 if(S.win){c.fillStyle='rgba(0,0,0,'+Math.min(.8,S.win/60)+')';c.fillRect(0,0,640,360);c.fillStyle='#e8b85c';c.font='bold 22px monospace';c.fillText('Corredor limpo!',320,180)}
 c.textAlign='left'}
function hzStart(L,done){HZ.on=1;const S=hzNew(L);S.pause=0;
 const ov=document.createElement('div');ov.style.cssText='position:fixed;inset:0;z-index:30;background:#000;display:flex;align-items:center;justify-content:center;touch-action:none;user-select:none;-webkit-user-select:none';
 const cv=document.createElement('canvas');cv.width=640;cv.height=360;cv.style.cssText='width:min(100vw,calc(100vh*16/9));height:auto;image-rendering:pixelated;background:#000';cv.style.width='min(100vw,calc(100dvh*16/9))';
 const rot=document.createElement('div');rot.textContent='↻ Gire o celular para jogar na horizontal';rot.style.cssText='position:absolute;inset:0;display:none;align-items:center;justify-content:center;color:#e8b85c;font:bold 18px system-ui;text-align:center;padding:24px';
 ov.append(cv,rot);
 const mk=(t,key,css)=>{const b=document.createElement('button');b.textContent=t;b.style.cssText='position:absolute;box-sizing:border-box;min-width:0;padding:0;width:64px;height:64px;border-radius:50%;border:2px solid rgba(255,255,255,.4);background:rgba(255,255,255,.13);color:#fff;font:bold 26px system-ui;touch-action:none;'+css;b.addEventListener('pointerdown',e=>{e.preventDefault();S.k[key]=1});['pointerup','pointercancel','pointerleave'].forEach(v=>b.addEventListener(v,()=>{S.k[key]=0}));ov.append(b)};
 mk('◀','L','left:14px;bottom:18px');mk('▶','R','left:90px;bottom:18px');mk('▲','J','right:90px;bottom:18px');mk('⚔','A','right:14px;bottom:18px');
 const ex=document.createElement('button');ex.textContent='Sair ✕';ex.style.cssText='position:absolute;top:10px;right:10px;min-width:0;padding:6px 10px;border-radius:8px;border:1px solid rgba(255,255,255,.4);background:rgba(0,0,0,.5);color:#fff;font:12px system-ui';ov.append(ex);
 const KM={ArrowLeft:'L',a:'L',A:'L',ArrowRight:'R',d:'R',D:'R',ArrowUp:'J',w:'J',W:'J',' ':'J',z:'A',Z:'A',x:'A',X:'A',j:'A',J:'A'};
 const kd=e=>{const q=KM[e.key];if(!q)return;e.preventDefault();e.stopImmediatePropagation();S.k[q]=1},ku=e=>{const q=KM[e.key];if(!q)return;e.stopImmediatePropagation();S.k[q]=0};
 const chk=()=>{const pt=innerHeight>innerWidth;rot.style.display=pt?'flex':'none';cv.style.visibility=pt?'hidden':'visible';S.pause=pt};
 addEventListener('keydown',kd,true);addEventListener('keyup',ku,true);addEventListener('resize',chk);chk();
 try{screen.orientation&&screen.orientation.lock&&screen.orientation.lock('landscape').catch(()=>{})}catch(e){}
 const c=cv.getContext('2d');c.imageSmoothingEnabled=false;
 const fim=w=>{if(!S.on)return;S.on=0;HZ.on=0;removeEventListener('keydown',kd,true);removeEventListener('keyup',ku,true);removeEventListener('resize',chk);ov.remove();try{screen.orientation&&screen.orientation.unlock&&screen.orientation.unlock()}catch(e){}done(w)};
 ex.onclick=()=>fim(0);document.body.append(ov);
 let last=performance.now(),acc=0;
 const lp=n=>{if(!S.on)return;acc+=Math.min(50,n-last);last=n;if(!S.pause){while(acc>=16.667){hzStep(S);acc-=16.667}}else acc=0;S.cam=Math.max(0,Math.min(L.w-640,S.p.x-240));hzDraw(S,c);if(S.win>100)return fim(1);requestAnimationFrame(lp)};
 S.on=1;requestAnimationFrame(lp);return S}
const hzBtn=document.createElement('button');hzBtn.textContent='⚔ Corredor das Falhas';hzBtn.style.cssText='position:fixed;right:10px;top:10px;z-index:8;display:none;min-width:0;padding:6px 10px;border-radius:8px;border:1px solid #e8b85c;background:rgba(0,0,0,.7);color:#e8b85c;font:12px system-ui';document.body.append(hzBtn);
async function hzEntrar(){if(busy||HZ.on||!NT.free||rm!==0)return;busy=1;hzBtn.style.display='none';
 await falas([['Você',"Um zumbido vem lá de baixo… pixels soltos no ar. Vou dar uma olhada."]]);
 hzStart(HZL1,async win=>{busy=1;if(win){F.hz1=1;save();await falas([['Você',"As falhas se desfizeram em pixels. O corredor ficou em silêncio de novo."]])}end()})}
hzBtn.onclick=hzEntrar;
function stop(){hzBtn.style.display='none';on=0;vivo=0;if(TEMA){clearInterval(TI);TEMA.pause()}}
return{start,act,book,enter,stop};

})();
let CUR=P1,skip=0;
const wait=ms=>new Promise(r=>{if(skip)return r();const i=setInterval(()=>{if(skip){clearInterval(i);clearTimeout(tm);r()}},60),tm=setTimeout(()=>{clearInterval(i);r()},ms)});
const TRANS_SRC="assets/audio_03.mp3",TRANS_DUR=11;
function zumbido(dur){const c=V8.ctx();if(!c)return null;try{if(c.state==='suspended')c.resume();const t0=c.currentTime,m=c.createGain();m.gain.setValueAtTime(.0001,t0);m.gain.exponentialRampToValueAtTime(.2,t0+dur*.92);m.connect(c.destination);
 const mk=(ty,f0,f1,v)=>{const o=c.createOscillator(),gn=c.createGain();o.type=ty;o.frequency.setValueAtTime(f0,t0);o.frequency.exponentialRampToValueAtTime(f1,t0+dur);gn.gain.value=v;o.connect(gn);gn.connect(m);o.start(t0);return o};
 const os=[mk('sawtooth',60,95,.45),mk('sawtooth',61.5,97,.35),mk('triangle',120,190,.3),mk('sine',440,900,.16)];
 const l=c.createOscillator(),lg=c.createGain();l.frequency.value=9;lg.gain.value=.05;l.connect(lg);lg.connect(m.gain);l.start(t0);
 return{stop(){const t=c.currentTime;try{m.gain.cancelScheduledValues(t);m.gain.setTargetAtTime(.0001,t,.3)}catch(e){}setTimeout(()=>{os.forEach(o=>{try{o.stop()}catch(e){}});try{l.stop()}catch(e){}},1500)}}}catch(e){return null}}
let CH1=null,CH1T=0;
function musicaCap1(lig){clearInterval(CH1T);
 if(lig){if(!CH1){CH1=new Audio(TRANS_SRC);CH1.loop=true}if(!CH1.paused)return;CH1.volume=.6;CH1.play().catch(()=>{})}
 else if(CH1&&!CH1.paused){const v0=CH1.volume,t1=performance.now();CH1T=setInterval(()=>{const q=Math.min(1,(performance.now()-t1)/1500);CH1.volume=Math.max(0,v0*(1-q));if(q>=1){clearInterval(CH1T);CH1.pause();CH1.currentTime=0}},60)}}
V8.toPart2=async ti=>{musicaCap1(0);skip=0;SV.part(2);P1.stop();const f=$('fim');$('ft').textContent='';$('fc').hidden=1;$('fb').hidden=1;
 let gl=document.getElementById('glw');if(!gl){gl=document.createElement('div');gl.id='glw';gl.style.cssText='position:absolute;inset:0;pointer-events:none;opacity:0';f.appendChild(gl)}
 gl.style.opacity=0;f.style.background='';f.style.transition='none';f.style.opacity=0;f.hidden=0;void f.offsetWidth;f.style.transition='opacity 1.2s';f.style.opacity=1;
 const z=zumbido(TRANS_DUR);V8.onFim=()=>{skip=1};
 const D=TRANS_DUR*1000,t0=performance.now();
 await new Promise(r=>{const step=n=>{const el=n-t0,p=skip?1:Math.min(1,el/D),e=p*p*p;
  gl.style.opacity=Math.min(1,e*1.6);
  gl.style.background='radial-gradient(circle at 50% 46%,rgba(255,250,225,'+(.3+e*.7)+') 0%,rgba(255,215,140,'+(.15+e*.5)+') '+(4+e*30)+'%,rgba(255,190,100,0) '+(12+e*88)+'%)';
  const w=Math.max(0,Math.min(1,(p-.72)/.28)),m=(a,b)=>Math.round(a+(b-a)*w);f.style.background='rgb('+m(5,255)+','+m(6,243)+','+m(15,214)+')';
  if(p>=1)return r();requestAnimationFrame(step)};requestAnimationFrame(step)});
 if(z)z.stop();skip=0;V8.onFim=null;CUR=P2;P2.start(0);
 f.style.transition='opacity 2.4s';f.style.opacity=0;
 await wait(2500);f.hidden=1;f.style.transition='';f.style.opacity='';f.style.background='';gl.style.opacity=0};
$('fim').onclick=()=>{V8.onFim&&V8.onFim()};$('fb').onclick=e=>{e.stopPropagation();V8.onFb&&V8.onFb()};
$('sm').firstChild.src=SKIN.m;$('sf').firstChild.src=SKIN.f;
try{const g=localStorage.getItem('velvet8g');if(g)V8.skin(g)}catch(e){}
function pick(g){V8.skin(g);try{localStorage.setItem('velvet8g',g)}catch(e){}$('sel').hidden=1;SV.clear();CUR=P1;P1.start(0)}

/* ===== ABERTURA: câmera anda devagar para a direita, a história aparece escrita na parede, escurece e segue para a seleção de personagens ===== */
const OPEN_SRC="assets/audio_04.mp3";
// Texto da história: cada bloco aparece na parede, letra por letra. Use "|" para quebrar linha. Ajuste aqui à vontade.
const OPEN_TXT=[
 "Existe uma noite|que não termina.",
 "Nela, um relógio|anda para trás,|e ninguém lembra|de tê-lo ligado.",
 "Quem chega acorda|sem saber quanto|tempo já passou|lá fora.",
 "Os corredores guardam|o que você esqueceu:|nomes, rostos, vozes.",
 "Dizem que, no fim,|há um castelo com|uma mesa posta|para uma família.",
 "Algumas portas só abrem|para quem escuta|cada um que ficou.",
 "Ande devagar.|Examine tudo.|Converse com todos.",
 "#NEXT LEVEL|a hora espera por você."];
function abertura(done){
  const box=document.getElementById('op'),cv=document.getElementById('opc'),x=cv.getContext('2d'),bt=document.getElementById('ops');
  const au=new Audio(OPEN_SRC);au.volume=.85;let fim=0,raf=0,t0=performance.now(),ok=0;
  const N=OPEN_TXT.length,X0=520,GAP=360,XL=X0+(N-1)*GAP;
  const hs=(a,b)=>{let h=(a*374761393+b*668265263)|0;h=(h^(h>>>13))*1274126177|0;return((h^(h>>>16))>>>0)/4294967295};
  function acabar(){if(fim)return;fim=1;cancelAnimationFrame(raf);try{au.pause()}catch(e){}box.hidden=1;done()}
  bt.onclick=acabar;au.onended=acabar;
  box.hidden=0;au.play().then(()=>{ok=1}).catch(()=>{});
  const E=[];for(let i=0;i<70;i++)E.push({x:hs(i,1)*640,y:hs(i,2)*330,s:.3+hs(i,3)*.9,r:.5+hs(i,4)*1.3,p:hs(i,5)*6});
  function quadro(){if(fim)return;
    const D=isFinite(au.duration)&&au.duration>5?au.duration:71.7,T=(ok&&!au.paused)?au.currentTime:(performance.now()-t0)/1000;
    if(T>=D+.6)return acabar();
    const SP=(XL-330)/(D-12),cam=SP*T;
    // parede de pedra fria
    x.fillStyle='#0d131c';x.fillRect(0,0,640,360);
    const RH=20,BW=56;
    for(let r=0;r<15;r++){const off=(r%2)*BW/2,y=r*RH;
      for(let k=-1;k<14;k++){const wx=Math.floor((cam+k*BW-off)/BW),px=wx*BW+off-cam,h=hs(wx,r),v=Math.round(20+h*14);
        x.fillStyle='rgb('+(v-4)+','+(v+6)+','+(v+18)+')';x.fillRect(Math.round(px)+1,y+1,BW-2,RH-2);
        x.fillStyle='rgba(150,190,235,'+(.03+h*.05)+')';x.fillRect(Math.round(px)+1,y+1,BW-2,2)}}
    // rachaduras, correntes e janelas com luar frio
    for(let c=0;c<6;c++){const wx=c*520+130+hs(c,7)*200,sx=wx-cam*1;if(sx<-60||sx>700)continue;x.strokeStyle='#070b11';x.lineWidth=2;x.beginPath();let cx=sx,cy=30+hs(c,8)*60;x.moveTo(cx,cy);for(let j=0;j<7;j++){cx+=(hs(c,10+j)-.5)*22;cy+=18+hs(c,20+j)*14;x.lineTo(cx,cy)}x.stroke()}
    for(let c=0;c<4;c++){const sx=c*760+330-cam,len=70+hs(c,3)*70;if(sx<-20||sx>660)continue;const sw=Math.sin(T*.8+c*2)*3;
      for(let j=0;j<len/7;j++){x.fillStyle=j%2?'#3a4658':'#2a3444';x.fillRect(Math.round(sx+sw*j/12),j*7,4,6)}}
    for(let c=0;c<3;c++){const sx=c*1000+650-cam;if(sx<-120||sx>700)continue;
      const g=x.createLinearGradient(sx,40,sx+90,300);g.addColorStop(0,'rgba(170,205,255,.20)');g.addColorStop(1,'rgba(170,205,255,0)');x.fillStyle=g;x.beginPath();x.moveTo(sx,40);x.lineTo(sx+26,40);x.lineTo(sx+130,300);x.lineTo(sx+60,300);x.fill();
      x.fillStyle='#04070b';x.fillRect(sx-2,24,30,70);x.fillStyle='rgba(185,215,255,.55)';x.fillRect(sx+4,30,18,58)}
    // chão e névoa
    x.fillStyle='#0a0f17';x.fillRect(0,300,640,60);x.fillStyle='rgba(120,160,210,.07)';x.fillRect(0,300,640,2);
    for(let k=0;k<12;k++){const px=Math.round(k*60-(cam%60));x.fillStyle='rgba(0,0,0,.35)';x.fillRect(px,302,1,58)}
    for(let m=0;m<3;m++){const mx=((-cam*(.5+m*.3)+m*300)%900+900)%900-260;const g=x.createRadialGradient(mx+260,318+m*8,5,mx+260,318+m*8,260);g.addColorStop(0,'rgba(160,190,225,'+(.13-m*.03)+')');g.addColorStop(1,'rgba(160,190,225,0)');x.fillStyle=g;x.fillRect(mx,250,520,110)}
    // cinzas/poeira de gelo
    for(const e of E){const px=((e.x-cam*e.s*.6+e.p*40)%700+700)%700-30,py=(e.y+Math.sin(T*.6+e.p)*14+T*3*e.s)%330;x.fillStyle='rgba(200,225,255,'+(.15+.2*Math.sin(T+e.p)**2)+')';x.fillRect(Math.round(px),Math.round(py),e.r>1?2:1,e.r>1?2:1)}
    // texto na parede (letra por letra)
    x.textBaseline='middle';
    for(let i=0;i<N;i++){const gx=X0+i*GAP-cam;if(gx>650||gx<-420)continue;
      const raw=OPEN_TXT[i],big=raw[0]==='#',lines=(big?raw.slice(1):raw).split('|'),ts=(X0+i*GAP-330)/SP,fz=big?42:24,lh=big?50:34,top=150-(lines.length-1)*lh/2;
      let n=0;x.font='bold '+fz+"px 'Courier New',monospace";
      lines.forEach((ln,li)=>{const cw=x.measureText('M').width;const fs=(big&&li===1)?18:fz;if(big&&li===1)x.font='bold 18px \'Courier New\',monospace';
        for(let c=0;c<ln.length;c++,n++){const a=Math.max(0,Math.min(1,(T-ts-n*.075)/.35));if(a<=0)continue;
          const px=gx+c*(big&&li===1?10.8:cw),py=top+li*lh+(big&&li===1?14:0);
          x.globalAlpha=a*.9;x.fillStyle='#05080d';x.fillText(ln[c],px+2,py+2);
          x.shadowColor='rgba(150,195,255,.65)';x.shadowBlur=10;x.fillStyle=big&&li===0?'#e8f2ff':'#cfe0f5';x.fillText(ln[c],px,py);x.shadowBlur=0}
        x.font='bold '+fz+"px 'Courier New',monospace"});x.globalAlpha=1}
    // vinheta fria + entrada e saída do escuro
    const vg=x.createRadialGradient(320,170,120,320,170,420);vg.addColorStop(0,'rgba(0,0,10,0)');vg.addColorStop(1,'rgba(0,0,12,.75)');x.fillStyle=vg;x.fillRect(0,0,640,360);
    const fi=Math.max(0,1-T/2.5),fo=Math.max(0,Math.min(1,(T-(D-7))/6));
    x.fillStyle='rgba(0,0,0,'+Math.max(fi,fo)+')';x.fillRect(0,0,640,360);
    raf=requestAnimationFrame(quadro)}
  quadro()}
document.getElementById('bs').onclick=()=>{abertura(()=>{musicaCap1(1);document.getElementById('sel').hidden=0})};

$('sm').onclick=()=>pick('m');$('sf').onclick=()=>pick('f');$('sb').onclick=()=>{$('sel').hidden=1};
$('bc').onclick=()=>{if(SV.raw().part===2){P1.stop();CUR=P2;P2.start(1)}else{CUR=P1;musicaCap1(1);P1.start(1)}};
$('bc').disabled=!SV.raw().part;
/* ===== caixa de diálogo só aparece quando há fala, narração, interação ou escolha ===== */
(function(){const d=$('dlg'),tx=$('dt'),c=$('ch');
 const upd=()=>{d.classList.toggle('idle',tx.textContent==='…'&&!c.querySelector('button'))};
 new MutationObserver(upd).observe(d,{childList:true,subtree:true,characterData:true});upd()})();

/* ===== v62: menu temático com música ===== */
(function(){
 const ti=$('ti'),bs=$('bs'),bc=$('bc');
 
 bs.textContent='COMEÇAR';bc.textContent='CONTINUAR';
 const au=new Audio("assets/audio_05.mp3");au.loop=true;au.volume=.8;
 let want=1,iv=0;
 function pl(){if(!want)return;clearInterval(iv);au.volume=.8;au.play().catch(()=>{})}
 function fade(ms){want=0;clearInterval(iv);const v0=au.volume,t1=performance.now();iv=setInterval(()=>{const q=Math.min(1,(performance.now()-t1)/ms);au.volume=Math.max(0,v0*(1-q));if(q>=1){clearInterval(iv);au.pause();au.volume=.8}},50)}
 au.addEventListener('playing',()=>ti.classList.add('mus'));
 au.addEventListener('pause',()=>ti.classList.remove('mus'));
 const evs=['pointerdown','pointerup','touchstart','touchend','click','keydown'];let ok=0;
 function unmute(){if(!want||ok)return;au.muted=false;au.volume=.8;const p=au.play();if(p)p.then(()=>{if(!au.paused&&!au.muted){ok=1;evs.forEach(e=>removeEventListener(e,unmute,true))}}).catch(()=>{})}
 evs.forEach(e=>addEventListener(e,unmute,true));
 au.play().catch(()=>{au.muted=true;au.play().catch(()=>{})});
 bs.addEventListener('click',()=>fade(900));bc.addEventListener('click',()=>fade(900));
 $('sb').addEventListener('click',()=>{want=1;au.currentTime=0;pl()});
})();

$('act').onclick=()=>CUR.act();$('bk').onclick=()=>CUR.book();
$('L').addEventListener('pointerdown',e=>{e.preventDefault();KEYS.L=1});$('R').addEventListener('pointerdown',e=>{e.preventDefault();KEYS.R=1});
['pointerup','pointerleave','pointercancel'].forEach(v=>{$('L').addEventListener(v,()=>KEYS.L=0);$('R').addEventListener(v,()=>KEYS.R=0)});
addEventListener('keydown',e=>{if(e.key==='ArrowLeft')KEYS.L=1;if(e.key==='ArrowRight')KEYS.R=1;if(e.key==='Enter'||e.key===' '||e.key==='e'){e.preventDefault();CUR.enter()}});
addEventListener('keyup',e=>{if(e.key==='ArrowLeft')KEYS.L=0;if(e.key==='ArrowRight')KEYS.R=0});
