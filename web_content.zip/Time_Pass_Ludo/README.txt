TIME PASS LUDO
================
A simple offline Ludo prototype with original branding.

Run:
1. Extract the ZIP.
2. Open index.html in a mobile/desktop browser.
3. Tap ROLL DICE.

This is a prototype, not a store-ready multiplayer Ludo engine.
