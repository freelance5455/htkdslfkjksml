# CPLS / CryptoPulse — Stage 1167
## Anti-Fraud Device & App Integrity Boundary

Stage 1167 adds a conservative integrity boundary for future backend anti-fraud work.

### Added
- Local package identity signal.
- Debuggable-build signal.
- App version/version code signal.
- SHA-256 digest of the installed signing certificate when available.
- Explicit `playIntegrityIntegrated=false` and `attestationVerified=false` state.
- WebView bridge: `getAppIntegrityBoundaryState()`.
- Explicit policy that local signals cannot authorize rewards.

### Security rule
The APK must never decide that a device is trustworthy merely because these local values look normal. A determined attacker can modify or replay client-side signals. The future backend must independently verify any authoritative attestation token and bind it to a short-lived server challenge before allowing sensitive reward actions.

### Play Integrity status
No Play Integrity API integration is claimed in this stage. The source deliberately reports that it is not integrated. This avoids a false security claim.

### Reward boundary
`rewardAuthorizationAllowed=false` remains hard-coded in the client integrity state. Reward eligibility and final claim authorization remain backend-authoritative.

### Network / wallet safety
- Sepolia only: chain ID `11155111`.
- Mainnet remains locked.
- No private key or seed exposure.
- No signing or transaction broadcast.
- No live backend deployment is claimed.
