redbrowser — RMail setup prototype

RMail now includes local configuration fields for a domain you control, mail address, HTTPS backend URL, provider type, identity verification method/endpoint, an E2EE review checklist and a readiness report.

Important: these are configuration and readiness UI only. The HTML does not provision DNS, create mailboxes, send email, contact the backend, perform real identity verification, or encrypt messages. E2EE remains disabled.

Before production, you must supply a domain you control, configure MX/SPF/DKIM/DMARC, deploy a secure HTTPS backend, implement identity verification and account recovery, and integrate a maintained/reviewed E2EE protocol/library with independent security review. Keep provider secrets on the server, never in the APK. Do not claim mail is encrypted until the full implementation is reviewed and tested.
