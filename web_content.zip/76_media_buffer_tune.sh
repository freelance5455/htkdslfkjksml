#!/system/bin/sh
# 76_media_buffer_tune.sh
# Bump the media network buffer so YouTube/Netflix/Spotify keep
# playback smooth over lossy cellular. Real Stagefright props.
net_fn_76() {
    if [ "$PROFILE_LEVEL" -lt 1 ]; then return 0; fi
    vlog INFO "[76] Media network buffer tune"
    void_try_setprop "fn76 media_buffer"    "media.stagefright.buffer_size"  "15728640"
    void_try_setprop "fn76 media_prefetch"  "media.stagefright.prefetch_ms"  "8000"
    void_try_setprop "fn76 media_lowlat"    "media.stagefright.enable-http2" "true"
}
