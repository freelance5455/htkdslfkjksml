# CGD V117 — Socle 1.0 : Coupe Galactique

## Règles historiques auditées
- 8 clubs participants : le club dirigé et 7 autres clubs choisis parmi les clubs disponibles.
- Élimination directe en trois tours : quarts de finale, demi-finales et finale.
- Calendrier historique : journées 6, 12 et 18 du championnat (`CUPJ`).
- Le V116 départageait un match nul par un choix aléatoire à 50 %. La V117 rend ce départage déterministe par identifiant de rencontre afin de préserver la reproductibilité des sauvegardes.

## Intégration V117
- Nouveau module `src/galactic-cup.js`.
- Création des fixtures dans le calendrier central, identifiants stables et `competitionId` dédié.
- Progression automatique du tableau après homologation de toutes les rencontres du tour.
- Simulation IA par le même moteur de dames que les rencontres de championnat.
- Le match du club dirigé peut être joué sur le plateau ; le résultat actualise les statistiques de Coupe Galactique, sans modifier le classement du championnat.
- Le bouton de simulation respecte les journées de disponibilité et réserve le match du club dirigé.
- Les tours de coupe sont exclus du calcul des journées de championnat pour éviter les blocages dus aux numéros de tours indépendants.

## Tests et validation
- 72 tests automatisés réussis, 0 échec.
- Syntaxe vérifiée pour tous les fichiers `src/*.js` et `tests/*.js`.
- Parcours de coupe testé jusqu'au champion, match manuel, simulation IA, match nul, anti-doublon, calendrier et séparation des statistiques.
- Test navigateur Chromium headless tenté mais non abouti dans l'environnement ; aucun test visuel navigateur n'est revendiqué.

## Éléments non terminés
- La Coupe des Clubs, la Champions League, l'Intergalactique des Clubs, l'Intergalactique des sélections et la Coupe Lunaire restent à raccorder à partir des règles V116.
- Dame d'Or reste une distinction individuelle à intégrer, pas une coupe à matchs.
- L'IA reste heuristique ; le jeu complet façon Football Manager n'est pas encore achevé.
