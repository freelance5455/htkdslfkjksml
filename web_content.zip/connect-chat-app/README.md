# Connect Chat — Starter Project

A small, runnable starter for an internet messaging app:
- username/password registration and login (passwords hashed with bcrypt)
- real-time text chat using Socket.IO
- image/document upload (15 MB limit)
- audio/video calls using WebRTC with Socket.IO signaling
- online indicators and browser-local login token

## Requirements
- Node.js 18+
- Two browser sessions/accounts for testing
- For real use across the internet: deploy to a public host with HTTPS.

## Run locally
1. Install Node.js.
2. Unzip this folder and open a terminal in it.
3. Run:
   ```sh
   npm install
   npm start
   ```
4. Open `http://localhost:3000`.
5. Create two accounts in two browsers (or one normal and one private/incognito window), then select the other user.

On two phones on the same Wi-Fi, use your computer/server's LAN IP, e.g. `http://192.168.1.10:3000`, and allow the port through the firewall. Microphone/camera permissions generally require HTTPS, except localhost. For calls over the public internet, deploy behind HTTPS/WSS.

## How it connects
- **HTTP API**: register/login, fetch user list and message history, upload files.
- **Socket.IO**: delivers new chat messages, online state, and WebRTC signaling messages.
- **WebRTC**: carries the audio/video media between peers. The server forwards offer/answer/ICE signaling but does not relay the media.
- **STUN**: helps peers discover network paths. Some NAT/firewall combinations require a TURN relay. Configure a TURN service in the `iceServers` list for reliable calls.

## Before any public/commercial launch — important
This is a starter/demo, not a production-hardened messenger. It has not been independently security-audited.
- Set a long random `JWT_SECRET` environment variable; never use the development default.
- Replace JSON-file storage with a real database (PostgreSQL, MySQL, or managed service) and migrations/backups.
- Add rate limiting, login throttling, account recovery, email/phone verification, CSRF/security headers, request validation, and monitoring.
- Add a persistent session/token revocation strategy and stronger authorization checks.
- Uploads are served publicly by filename; production should use private object storage, signed download URLs, quotas, virus scanning, MIME/content verification, and retention rules.
- Add consent/privacy policy, report/block features, abuse handling, and delete-account/data export flows.
- Do not describe messages or calls as end-to-end encrypted: this starter does not implement E2EE.
- In-memory online state only tracks one active socket per account. Production should support multiple devices and a shared adapter such as Redis.
- The JSON-file persistence is suitable only for local tests/small demos and can lose updates under concurrent writes.
- Only use original or properly licensed names, logos, and assets if you plan to sell the app.

## Environment variables
- `PORT` (default 3000)
- `JWT_SECRET` (required for deployment; use a unique random secret)

## Notes
- Browsers require a secure context (HTTPS) for camera/microphone on public hosts.
- STUN alone is not enough on every network; TURN is often needed for dependable connectivity.
