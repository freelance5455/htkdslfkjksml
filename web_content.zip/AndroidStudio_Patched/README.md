# Fun Race 3D + Unity Ads Android

Android Studio project wrapping the supplied Fun Race 3D HTML in a WebView.

## Unity Ads configuration

Game ID:
800275589

Placements:
- Banner_Android
- Interstitial_Android
- Rewarded_Android

SDK:
com.unity3d.ads:unity-ads:4.20.1

## Important

`UNITY_TEST_MODE` is TRUE in `MainActivity.java` for testing. This should remain
true until you verify the integration. Set it to false only for production.

The supplied HTML is stored unchanged as:
app/src/main/assets/index.html

The HTML's Famobi iframe remains:
https://play.famobi.com/fun-race-3d/A1000-10A or A1000-10B

The native Android layer provides:
window.AndroidAds.showInterstitial()
window.AndroidAds.showRewarded()
window.AndroidAds.isUnityAdsInitialized()

A native banner is displayed at the bottom of the Android activity.

When Unity confirms a rewarded completion, Android calls:
window.onUnityRewardedCompleted()

## Build

Open this folder in Android Studio and let Gradle sync.

Then:
Build > Make Project
Run the app on a real Android device.

Internet permission is required because the game is loaded from Famobi and
Unity Ads requires network access.

## If ads do not show

1. Verify Game ID 800275589 is an Android Game ID.
2. Verify all three placement names exist exactly as configured.
3. Keep Unity test mode enabled during testing.
4. Check Logcat for `FunRace3D` and Unity Ads messages.
5. Do not expect an ad on every request; inventory/fill and loading are asynchronous.
6. If Unity dashboard reports a placement is not configured, fix it in the
   Unity Monetization dashboard rather than changing the HTML.

## Privacy

Unity's current Android documentation requires publishers to configure
appropriate user consent before/during initialization where applicable.
Add your consent flow before production release.
