package com.funrace3d.unityads;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

import com.unity3d.ads.BannerAd;
import com.unity3d.ads.BannerConfiguration;
import com.unity3d.ads.BannerLoadListener;
import com.unity3d.ads.BannerShowListener;
import com.unity3d.ads.BannerSize;
import com.unity3d.ads.InitializationConfiguration;
import com.unity3d.ads.InitializationListener;
import com.unity3d.ads.InterstitialAd;
import com.unity3d.ads.InterstitialLoadListener;
import com.unity3d.ads.InterstitialShowListener;
import com.unity3d.ads.LoadConfiguration;
import com.unity3d.ads.RewardedAd;
import com.unity3d.ads.RewardedLoadListener;
import com.unity3d.ads.RewardedShowListener;
import com.unity3d.ads.ShowConfiguration;
import com.unity3d.ads.ShowFinishState;
import com.unity3d.ads.UnityAds;
import com.unity3d.ads.UnityAdsError;

public class MainActivity extends Activity {
    private static final String TAG = "FunRace3D";
    private static final String GAME_ID = "800275589";
    private static final String BANNER = "Banner_Android";
    private static final String INTERSTITIAL = "Interstitial_Android";
    private static final String REWARDED = "Rewarded_Android";
    private static final boolean TEST_MODE = true;

    private WebView webView;
    private FrameLayout bannerContainer;
    private InterstitialAd interstitialAd;
    private RewardedAd rewardedAd;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(com.funrace3d.unityads.R.layout.main);
        webView = findViewById(com.funrace3d.unityads.R.id.gameWebView);
        bannerContainer = findViewById(com.funrace3d.unityads.R.id.bannerContainer);
        configureWebView();
        initializeUnityAds();
    }

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    private void configureWebView() {
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        webView.setBackgroundColor(Color.BLACK);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new UnityBridge(), "AndroidAds");
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void initializeUnityAds() {
        InitializationConfiguration c = new InitializationConfiguration.Builder(GAME_ID)
                .withTestMode(TEST_MODE).build();
        UnityAds.initialize(c, new InitializationListener() {
            @Override public void onInitializationComplete(UnityAdsError error) {
                if (error == null) { loadBanner(); loadInterstitial(); loadRewarded(); }
                else Log.e(TAG, "Unity init failed: " + error.getMessage());
            }
        });
    }

    private void loadBanner() {
        runOnUiThread(new Runnable() { @Override public void run() {
            BannerSize size = new BannerSize(320, 50);
            BannerShowListener show = new BannerShowListener() {
                @Override public void onImpression(BannerAd ad) {}
                @Override public void onClicked(BannerAd ad) {}
                @Override public void onFailedToShow(BannerAd ad, UnityAdsError e) { Log.e(TAG, "Banner show: " + e.getMessage()); }
            };
            BannerConfiguration cfg = new BannerConfiguration.Builder(BANNER, size, show).build();
            BannerAd.load(cfg, new BannerLoadListener() {
                @Override public void onBannerLoaded(BannerAd ad, UnityAdsError error) {
                    if (ad != null && error == null && ad.getView() != null) {
                        bannerContainer.removeAllViews();
                        bannerContainer.addView(ad.getView(), new FrameLayout.LayoutParams(-1, -2));
                        bannerContainer.setVisibility(View.VISIBLE);
                    } else if (error != null) Log.e(TAG, "Banner load: " + error.getMessage());
                }
            });
        }});
    }

    private void loadInterstitial() {
        InterstitialAd.load(new LoadConfiguration.Builder(INTERSTITIAL).build(), new InterstitialLoadListener() {
            @Override public void onInterstitialLoaded(InterstitialAd ad, UnityAdsError error) {
                if (ad != null && error == null) interstitialAd = ad;
            }
        });
    }

    private void loadRewarded() {
        RewardedAd.load(new LoadConfiguration.Builder(REWARDED).build(), new RewardedLoadListener() {
            @Override public void onRewardedLoaded(RewardedAd ad, UnityAdsError error) {
                if (ad != null && error == null) rewardedAd = ad;
            }
        });
    }

    private void showInterstitial() {
        runOnUiThread(new Runnable() { @Override public void run() {
            if (interstitialAd == null) { loadInterstitial(); return; }
            InterstitialAd ad = interstitialAd; interstitialAd = null;
            ad.show(new ShowConfiguration.Builder().build(), new InterstitialShowListener() {
                @Override public void onStarted(InterstitialAd a) {}
                @Override public void onClicked(InterstitialAd a) {}
                @Override public void onCompleted(InterstitialAd a, ShowFinishState s) { loadInterstitial(); }
                @Override public void onFailed(InterstitialAd a, UnityAdsError e) { loadInterstitial(); }
            });
        }});
    }

    private void showRewarded() {
        runOnUiThread(new Runnable() { @Override public void run() {
            if (rewardedAd == null) { loadRewarded(); Toast.makeText(MainActivity.this, "Rewarded ad is loading", Toast.LENGTH_SHORT).show(); return; }
            RewardedAd ad = rewardedAd; rewardedAd = null;
            ad.show(new ShowConfiguration.Builder().withCustomRewardString("fun_race_reward").build(), new RewardedShowListener() {
                @Override public void onStarted(RewardedAd a) {}
                @Override public void onClicked(RewardedAd a) {}
                @Override public void onRewarded(RewardedAd a) {
                    if (webView != null) webView.post(new Runnable() { @Override public void run() { webView.evaluateJavascript("window.onUnityRewardedCompleted && window.onUnityRewardedCompleted();", null); }});
                }
                @Override public void onCompleted(RewardedAd a, ShowFinishState s) { loadRewarded(); }
                @Override public void onFailed(RewardedAd a, UnityAdsError e) { loadRewarded(); }
            });
        }});
    }

    public class UnityBridge {
        @JavascriptInterface public void showInterstitial() { MainActivity.this.showInterstitial(); }
        @JavascriptInterface public void showRewarded() { MainActivity.this.showRewarded(); }
        @JavascriptInterface public boolean isUnityAdsInitialized() { return UnityAds.isInitialized(); }
    }

    @Override protected void onDestroy() {
        if (webView != null) { webView.removeJavascriptInterface("AndroidAds"); webView.destroy(); }
        super.onDestroy();
    }
}
