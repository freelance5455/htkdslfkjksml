plugins {
    id("com.android.application")
}

android {
    namespace = "com.funrace3d.unityads"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.funrace3d.unityads"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
        debug {
            isMinifyEnabled = false
        }
    }
}

dependencies {
    implementation("com.unity3d.ads:unity-ads:4.20.1")
}
