# Unity Ads 4.20.1 supplies its consumer/R8 rules through the dependency.
# Add project-specific rules here if you enable minification later.
