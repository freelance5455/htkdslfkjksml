# DrodSign Android project

DrodSign is an Android Studio project for choosing APK files, signing locally with a generated app-specific RSA identity, verifying signatures, and opening online signing resources.

## Build the APK
1. Install Android Studio (with Android SDK Platform 35).
2. Open this folder as a project.
3. Allow Gradle to sync and download dependencies.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. The debug APK is usually at `app/build/outputs/apk/debug/app-debug.apk`.

## Notes
- This environment did not have Android SDK/Gradle installed, so a compiled APK could not be produced here. This is the complete project source, not an APK binary.
- The online-signing button opens web resources; it does not automatically upload files to a third-party site.
- Local signing uses an app-generated self-signed certificate. The key is stored in the app's private storage and is not exportable from the UI. If the app is uninstalled, the key is lost, and APKs signed with a different key cannot update each other normally.
- Signing is not malware scanning. Only sign apps you have permission to modify and install.
