package com.drodsign.app;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.apksig.ApkSigner;
import com.android.apksig.ApkVerifier;

import org.bouncycastle.asn1.x500.X500Name;
import org.bouncycastle.cert.X509CertificateHolder;
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter;
import org.bouncycastle.cert.jcajce.JcaX509v3CertificateBuilder;
import org.bouncycastle.operator.ContentSigner;
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder;
import org.bouncycastle.jce.provider.BouncyCastleProvider;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.math.BigInteger;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.Security;
import java.security.cert.X509Certificate;
import java.util.Arrays;
import java.util.Date;
import java.util.Collections;

public class MainActivity extends Activity {
    private static final int PICK_APK = 101;
    private static final int CREATE_OUTPUT = 102;
    private Uri selectedApk;
    private TextView status;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        if (Security.getProvider("BC") == null) Security.addProvider(new BouncyCastleProvider());

        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(28, 34, 28, 28);
        root.setBackgroundColor(0xFFF5F4FA);
        scroll.addView(root);

        TextView title = new TextView(this);
        title.setText("DrodSign");
        title.setTextSize(32);
        title.setTextColor(0xFF4F35B8);
        title.setGravity(Gravity.CENTER);
        root.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("APK signing manager · Local + online");
        subtitle.setTextSize(15);
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setPadding(0, 4, 0, 24);
        root.addView(subtitle);

        addButton(root, "1. Choose APK", v -> pickApk());
        addButton(root, "2. Sign APK locally", v -> signLocally());
        addButton(root, "Open APK signing website", v -> openWebsite());
        addButton(root, "Verify APK signature", v -> verifyApk());

        status = new TextView(this);
        status.setText("Choose an APK to begin. Local signing creates a new DrodSign signing identity on this device.");
        status.setTextSize(14);
        status.setTextColor(0xFF34313D);
        status.setPadding(4, 22, 4, 12);
        root.addView(status);

        TextView warning = new TextView(this);
        warning.setText("Safety: only upload APKs to websites you trust. A signature does not make an app safe or bypass its original developer's protections. Re-signing may prevent updates over the original app.");
        warning.setTextSize(12);
        warning.setTextColor(0xFF6A6575);
        warning.setPadding(4, 12, 4, 12);
        root.addView(warning);
        setContentView(scroll);
    }

    private void addButton(LinearLayout root, String label, View.OnClickListener listener) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setOnClickListener(listener);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 7, 0, 7);
        root.addView(b, lp);
    }

    private void pickApk() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.setType("application/vnd.android.package-archive");
        i.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(i, PICK_APK);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        if (requestCode == PICK_APK) {
            selectedApk = uri;
            status.setText("Selected: " + uri.getLastPathSegment() + "\nChoose local signing or open a website.");
        } else if (requestCode == CREATE_OUTPUT) {
            Uri outputUri = uri;
            new Thread(() -> {
                try {
                    File input = copyToCache(selectedApk, "input.apk");
                    File output = new File(getCacheDir(), "signed-output.apk");
                    signFile(input, output);
                    try (InputStream in = new FileInputStream(output);
                         android.os.ParcelFileDescriptor pfd = getContentResolver().openFileDescriptor(outputUri, "w");
                         FileOutputStream out = new FileOutputStream(pfd.getFileDescriptor())) {
                        byte[] buf = new byte[64 * 1024]; int n;
                        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                        out.flush();
                    }
                    runOnUiThread(() -> status.setText("Success! Signed APK saved to the location you selected."));
                } catch (Exception e) {
                    runOnUiThread(() -> status.setText("Signing failed: " + e.getMessage()));
                }
            }).start();
        }
    }

    private void signLocally() {
        if (selectedApk == null) {
            Toast.makeText(this, "Choose an APK first.", Toast.LENGTH_SHORT).show();
            return;
        }
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.setType("application/vnd.android.package-archive");
        i.putExtra(Intent.EXTRA_TITLE, "DrodSign-signed.apk");
        startActivityForResult(i, CREATE_OUTPUT);
    }

    private File copyToCache(Uri uri, String name) throws Exception {
        File f = new File(getCacheDir(), name);
        try (InputStream in = getContentResolver().openInputStream(uri);
             FileOutputStream out = new FileOutputStream(f)) {
            if (in == null) throw new Exception("Cannot read selected APK");
            byte[] buf = new byte[64 * 1024]; int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        }
        return f;
    }

    private void signFile(File input, File output) throws Exception {
        File keyFile = new File(getFilesDir(), "drodsign-key.p12");
        KeyPair pair;
        X509Certificate cert;
        if (keyFile.exists()) {
            java.security.KeyStore ks = java.security.KeyStore.getInstance("PKCS12");
            try (FileInputStream fis = new FileInputStream(keyFile)) { ks.load(fis, "DrodSignLocalKey".toCharArray()); }
            java.security.Key key = ks.getKey("drodsign", "DrodSignLocalKey".toCharArray());
            cert = (X509Certificate) ks.getCertificate("drodsign");
            pair = new KeyPair(cert.getPublicKey(), (java.security.PrivateKey) key);
        } else {
            KeyPairGenerator gen = KeyPairGenerator.getInstance("RSA");
            gen.initialize(2048);
            pair = gen.generateKeyPair();
            long now = System.currentTimeMillis();
            X500Name name = new X500Name("CN=DrodSign Local, OU=APK Signing, O=DrodSign, C=US");
            JcaX509v3CertificateBuilder builder = new JcaX509v3CertificateBuilder(
                name, BigInteger.valueOf(now), new Date(now - 86400000L),
                new Date(now + 10L * 365 * 86400000L), name, pair.getPublic());
            ContentSigner signer = new JcaContentSignerBuilder("SHA256withRSA").setProvider("BC").build(pair.getPrivate());
            X509CertificateHolder holder = builder.build(signer);
            cert = new JcaX509CertificateConverter().setProvider("BC").getCertificate(holder);
            java.security.KeyStore ks = java.security.KeyStore.getInstance("PKCS12");
            ks.load(null, null);
            ks.setKeyEntry("drodsign", pair.getPrivate(), "DrodSignLocalKey".toCharArray(), new java.security.cert.Certificate[]{cert});
            try (FileOutputStream fos = new FileOutputStream(keyFile)) { ks.store(fos, "DrodSignLocalKey".toCharArray()); }
        }

        ApkSigner.SignerConfig signerConfig = new ApkSigner.SignerConfig.Builder(
            "DrodSign", pair.getPrivate(), Collections.singletonList(cert)).build();
        ApkSigner signer = new ApkSigner.Builder(Collections.singletonList(signerConfig))
            .setInputApk(input).setOutputApk(output)
            .setV1SigningEnabled(true).setV2SigningEnabled(true)
            .setV3SigningEnabled(true).setV4SigningEnabled(false)
            .build();
        signer.sign();
    }

    private void openWebsite() {
        String[] choices = {"APKSign", "Online APK Signer"};
        new android.app.AlertDialog.Builder(this)
            .setTitle("Choose a signing website")
            .setItems(choices, (dialog, which) -> {
                String url = which == 0 ? "https://apk.tools/" : "https://www.google.com/search?q=online+APK+signer";
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
            }).show();
    }

    private void verifyApk() {
        if (selectedApk == null) {
            Toast.makeText(this, "Choose an APK first.", Toast.LENGTH_SHORT).show();
            return;
        }
        new Thread(() -> {
            try {
                File input = copyToCache(selectedApk, "verify-input.apk");
                ApkVerifier.Result result = new ApkVerifier.Builder(input).build().verify();
                String message = result.isVerified() ? "Signature verified." : "Signature verification failed.";
                runOnUiThread(() -> status.setText(message));
            } catch (Exception e) {
                runOnUiThread(() -> status.setText("Could not verify APK: " + e.getMessage()));
            }
        }).start();
    }
}
