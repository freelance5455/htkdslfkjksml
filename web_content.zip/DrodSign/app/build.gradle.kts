plugins { id("com.android.application") }

android {
    namespace = "com.drodsign.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.drodsign.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}

dependencies {
    implementation("com.android.tools.build:apksig:8.7.3")
    implementation("org.bouncycastle:bcprov-jdk18on:1.78.1")
    implementation("org.bouncycastle:bcpkix-jdk18on:1.78.1")
}
