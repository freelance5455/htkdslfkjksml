# DEFPliF V4 changelog

- Preserved the V3 Firebase email/password authentication and persistent session flow.
- Preserved Jamendo discovery/search and online audio streaming.
- Preserved background playback notification/media controls.
- Preserved Firestore cloud favorites and playlists.
- Preserved lyrics where available, artwork, mini-player, full player, seek, and next.
- Added local recently played history (up to 20 tracks) using SharedPreferences.
- Added a Home section to replay recently played tracks.
- Bumped app version to 4.0.0+4.
- No offline downloads were added.
