# DEFPliF V5

- Mempertahankan fitur V4: setup Jamendo/Firebase, login, pencarian dan streaming online, mini/full player, favorit cloud, playlist cloud, profil/logout, dan riwayat lokal 20 track terakhir.
- Menambahkan panel **Lirik & penerjemah** di halaman pemutar.
- Lirik asli ditampilkan bila tersedia pada data track dari penyedia.
- Pengguna dapat memilih bahasa sumber dan bahasa tujuan, termasuk Bahasa Indonesia, Inggris, Spanyol, Prancis, Jerman, Italia, Portugis, Jepang, Korea, Mandarin, Arab, Rusia, Thailand, Turki, Belanda, dan Hindi.
- Terjemahan memakai layanan pihak ketiga MyMemory melalui HTTPS; teks lirik dikirim ke layanan tersebut. Hasil otomatis dapat keliru dan kuota/availability mengikuti layanan.
- Menambahkan `index.html` di root sebagai halaman informasi struktur proyek, serta `web/index.html` sebagai entry point Flutter Web.
- Source aplikasi Android tetap Flutter/Dart di `lib/main.dart`; root `index.html` bukan pengendali APK Android.
