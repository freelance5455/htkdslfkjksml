
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:just_audio/just_audio.dart';
import 'package:just_audio_background/just_audio_background.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:audio_service/audio_service.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

const bg = Color(0xFF090914), panel = Color(0xFF19192B), purple = Color(0xFFAA83FF);
Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await JustAudioBackground.init(
    androidNotificationChannelId: 'com.defplif.audio',
    androidNotificationChannelName: 'DEFPliF Music',
    androidNotificationOngoing: true,
  );
  runApp(const DefplifApp());
}
class DefplifApp extends StatelessWidget {
  const DefplifApp({super.key});
  @override Widget build(BuildContext context)=>MaterialApp(
    title:'DEFPliF', debugShowCheckedModeBanner:false,
    theme:ThemeData(useMaterial3:true,brightness:Brightness.dark,scaffoldBackgroundColor:bg,
      colorScheme:ColorScheme.fromSeed(seedColor:purple,brightness:Brightness.dark),
      inputDecorationTheme:const InputDecorationTheme(filled:true,fillColor:panel,border:OutlineInputBorder(borderRadius:BorderRadius.all(Radius.circular(14)),borderSide:BorderSide.none))),
    home:const StartupGate());
}
class AppSettings {
  static const keys=['jamendo_id','fb_api','fb_app','fb_project','fb_sender','fb_bucket'];
  static Future<Map<String,String>> load() async {
    final p=await SharedPreferences.getInstance();
    return {for(final k in keys) k:(p.getString(k)??'')};
  }
  static Future<void> save(Map<String,String> v) async {
    final p=await SharedPreferences.getInstance();
    for(final k in keys) { final s=(v[k]??'').trim(); if(s.isEmpty){await p.remove(k);}else{await p.setString(k,s);} }
  }
  static Future<bool> configured() async {
    final v=await load();
    return (v['jamendo_id']??'').isNotEmpty && (v['fb_api']??'').isNotEmpty &&
      (v['fb_app']??'').isNotEmpty && (v['fb_project']??'').isNotEmpty &&
      (v['fb_sender']??'').isNotEmpty;
  }
  static Future<void> initFirebase() async {
    final v=await load();
    if(Firebase.apps.isEmpty) {
      await Firebase.initializeApp(options:FirebaseOptions(
        apiKey:v['fb_api']!, appId:v['fb_app']!, projectId:v['fb_project']!,
        messagingSenderId:v['fb_sender']!, storageBucket:(v['fb_bucket']??'').isEmpty?null:v['fb_bucket']));
    }
  }
}
class StartupGate extends StatefulWidget {const StartupGate({super.key});@override State<StartupGate> createState()=>_StartupGateState();}
class _StartupGateState extends State<StartupGate>{
 bool ready=false,setup=false;String error='';
 @override void initState(){super.initState();boot();}
 Future<void> boot() async {
  try {
   setup=!(await AppSettings.configured());
   if(!setup) await AppSettings.initFirebase();
  } catch(e){error=e.toString();setup=true;}
  if(mounted)setState(()=>ready=true);
 }
 @override Widget build(BuildContext context){
  if(!ready)return const Scaffold(body:Center(child:CircularProgressIndicator()));
  if(setup)return SetupScreen(error:error,onSaved:(){setState(()=>ready=false);boot();});
  return StreamBuilder<User?>(stream:FirebaseAuth.instance.authStateChanges(),
   builder:(c,s)=>s.connectionState==ConnectionState.waiting?const Scaffold(body:Center(child:CircularProgressIndicator())):
   s.data==null?const LoginScreen():const HomeScreen());
 }
}
class SetupScreen extends StatefulWidget{
 final String error;final VoidCallback onSaved;
 const SetupScreen({super.key,required this.onSaved,required this.error});
 @override State<SetupScreen> createState()=>_SetupScreenState();
}
class _SetupScreenState extends State<SetupScreen>{
 final fields=<String,TextEditingController>{};
 bool busy=false,showHelp=false;String err='';
 @override void initState(){super.initState();for(final k in AppSettings.keys){fields[k]=TextEditingController();}AppSettings.load().then((v){for(final k in fields.keys){fields[k]!.text=v[k]??'';}if(mounted)setState((){});});err=widget.error;}
 @override void dispose(){for(final c in fields.values){c.dispose();}super.dispose();}
 Widget field(String key,String label,{bool secret=false})=>Padding(padding:const EdgeInsets.only(bottom:12),child:TextField(controller:fields[key],obscureText:secret,decoration:InputDecoration(labelText:label)));
 Future<void> save() async {
  final v={for(final k in fields.keys) k:fields[k]!.text.trim()};
  if(v.values.any((e)=>e.isEmpty && !identical(e,v['fb_bucket']))){setState(()=>err='Lengkapi Jamendo Client ID dan semua kolom Firebase wajib.');return;}
  setState(()=>busy=true);
  try{await AppSettings.save(v);await AppSettings.initFirebase();widget.onSaved();}
  catch(e){setState(()=>err='Konfigurasi gagal: $e');}
  finally{if(mounted)setState(()=>busy=false);}
 }
 @override Widget build(BuildContext context)=>Scaffold(body:SafeArea(child:ListView(padding:const EdgeInsets.all(22),children:[
  const SizedBox(height:20),const Icon(Icons.graphic_eq,color:purple,size:64),
  const Text('DEFPliF',textAlign:TextAlign.center,style:TextStyle(fontSize:34,fontWeight:FontWeight.w900,color:purple,letterSpacing:3)),
  const SizedBox(height:8),const Text('Pengaturan awal satu kali',textAlign:TextAlign.center,style:TextStyle(color:Colors.white70,fontSize:18)),
  const SizedBox(height:20),const Text('1. Jamendo',style:TextStyle(fontSize:18,fontWeight:FontWeight.bold)),
  const Text('Buat aplikasi di developer.jamendo.com lalu tempel Client ID di sini.',style:TextStyle(color:Colors.white60)),
  field('jamendo_id','Jamendo Client ID'),
  const Divider(height:28),const Text('2. Firebase Authentication',style:TextStyle(fontSize:18,fontWeight:FontWeight.bold)),
  const Text('Buat project Firebase, tambahkan aplikasi Android, aktifkan Email/Password. Salin nilai konfigurasi aplikasi dari Firebase Console.',style:TextStyle(color:Colors.white60)),
  field('fb_api','Firebase API Key'),field('fb_app','Firebase App ID'),field('fb_project','Firebase Project ID'),field('fb_sender','Firebase Messaging Sender ID'),field('fb_bucket','Storage Bucket (opsional)'),
  if(err.isNotEmpty)Padding(padding:const EdgeInsets.only(bottom:10),child:Text(err,style:const TextStyle(color:Colors.redAccent))),
  FilledButton(onPressed:busy?null:save,style:FilledButton.styleFrom(backgroundColor:purple,padding:const EdgeInsets.all(16)),child:Text(busy?'Menyimpan...':'Simpan & lanjutkan')),
  TextButton(onPressed:()=>setState(()=>showHelp=!showHelp),child:const Text('Di mana mendapatkan konfigurasi?')),
  if(showHelp)const Text('Firebase Console → Project settings → General → Your apps → pilih aplikasi Android. Untuk Jamendo: developer.jamendo.com → My Apps. Nilai ini disimpan lokal di perangkat. Firebase API key adalah identifier proyek, bukan password akun.',style:TextStyle(color:Colors.white60)),
  const SizedBox(height:16),const Text('DEFPliF V4 hanya streaming online. Tidak ada fitur download offline.',textAlign:TextAlign.center,style:TextStyle(color:Colors.white38))
 ])));
}
class LoginScreen extends StatefulWidget{const LoginScreen({super.key});@override State<LoginScreen> createState()=>_LoginScreenState();}
class _LoginScreenState extends State<LoginScreen>{
 final email=TextEditingController(),password=TextEditingController();bool register=false,busy=false;String err='';
 Future<void> submit()async{
  setState(()=>busy=true);try{
   if(register){await FirebaseAuth.instance.createUserWithEmailAndPassword(email:email.text.trim(),password:password.text);}
   else{await FirebaseAuth.instance.signInWithEmailAndPassword(email:email.text.trim(),password:password.text);}
  }on FirebaseAuthException catch(e){setState(()=>err=e.message??e.code);}catch(e){setState(()=>err='$e');}
  finally{if(mounted)setState(()=>busy=false);}
 }
 @override Widget build(BuildContext context)=>Scaffold(body:SafeArea(child:Center(child:SingleChildScrollView(padding:const EdgeInsets.all(24),child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
  const Icon(Icons.graphic_eq,color:purple,size:70),const Text('DEFPliF',textAlign:TextAlign.center,style:TextStyle(fontSize:36,fontWeight:FontWeight.w900,color:purple,letterSpacing:3)),
  const Text('Your music. Your world.',textAlign:TextAlign.center,style:TextStyle(color:Colors.white60)),const SizedBox(height:34),
  Text(register?'Buat akun DEFPliF':'Selamat datang kembali',style:const TextStyle(fontSize:23,fontWeight:FontWeight.bold)),
  const SizedBox(height:16),TextField(controller:email,keyboardType:TextInputType.emailAddress,decoration:const InputDecoration(labelText:'Email',prefixIcon:Icon(Icons.email_outlined))),
  const SizedBox(height:12),TextField(controller:password,obscureText:true,decoration:const InputDecoration(labelText:'Password',prefixIcon:Icon(Icons.lock_outline))),
  if(err.isNotEmpty)Padding(padding:const EdgeInsets.all(8),child:Text(err,style:const TextStyle(color:Colors.redAccent))),
  FilledButton(onPressed:busy?null:submit,style:FilledButton.styleFrom(backgroundColor:purple,padding:const EdgeInsets.all(16)),child:Text(busy?'Mohon tunggu':register?'Daftar':'Login')),
  TextButton(onPressed:()=>setState(()=>register=!register),child:Text(register?'Sudah punya akun? Login':'Belum punya akun? Daftar')),
  const Text('Sesi login tersimpan otomatis oleh Firebase.',textAlign:TextAlign.center,style:TextStyle(color:Colors.white38,fontSize:12))
 ])))));
}
class Track{
 final String id,name,artist,album,image,audio,lyrics,license;
 final int duration;
 const Track({required this.id,required this.name,required this.artist,required this.album,required this.image,required this.audio,required this.duration,required this.lyrics,required this.license});
 factory Track.fromJson(Map<String,dynamic> j)=>Track(id:'${j['id']}',name:'${j['name']??'Untitled'}',artist:'${j['artist_name']??'Unknown'}',album:'${j['album_name']??''}',image:'${j['album_image']??''}',audio:'${j['audio']??''}',duration:(j['duration'] as num?)?.toInt()??0,lyrics:'${j['lyrics']??''}',license:'${j['license_ccurl']??''}');
 Map<String,dynamic> toStoredMap()=>{'id':id,'name':name,'artist':artist,'album':album,'image':image,'audio':audio,'duration':duration,'lyrics':lyrics,'license':license};
 factory Track.fromStoredMap(Map<String,dynamic> j)=>Track(id:'${j['id']??''}',name:'${j['name']??'Untitled'}',artist:'${j['artist']??'Unknown'}',album:'${j['album']??''}',image:'${j['image']??''}',audio:'${j['audio']??''}',duration:(j['duration'] as num?)?.toInt()??0,lyrics:'${j['lyrics']??''}',license:'${j['license']??''}');
}

class CloudLibrary {
  final String uid;
  CloudLibrary(this.uid);
  CollectionReference<Map<String,dynamic>> get favorites =>
    FirebaseFirestore.instance.collection('users').doc(uid).collection('favorites');
  CollectionReference<Map<String,dynamic>> get playlists =>
    FirebaseFirestore.instance.collection('users').doc(uid).collection('playlists');

  Future<void> setFavorite(Track t) => favorites.doc(t.id).set({
    'id':t.id,'name':t.name,'artist':t.artist,'album':t.album,'image':t.image,
    'audio':t.audio,'duration':t.duration,'lyrics':t.lyrics,'license':t.license,
    'updatedAt':FieldValue.serverTimestamp(),
  });
  Future<void> removeFavorite(String id)=>favorites.doc(id).delete();
  Stream<QuerySnapshot<Map<String,dynamic>>> watchFavorites()=>favorites.orderBy('updatedAt',descending:true).snapshots();
  Future<void> createPlaylist(String name)=>playlists.add({
    'name':name,'trackIds':<String>[],'createdAt':FieldValue.serverTimestamp(),
  });
  Future<void> addToPlaylist(String playlistId, Track t) async {
    await playlists.doc(playlistId).update({'trackIds':FieldValue.arrayUnion([t.id])});
    await playlists.doc(playlistId).collection('tracks').doc(t.id).set({
      'id':t.id,'name':t.name,'artist':t.artist,'album':t.album,'image':t.image,
      'audio':t.audio,'duration':t.duration,'lyrics':t.lyrics,'license':t.license,
    });
  }
  Stream<QuerySnapshot<Map<String,dynamic>>> watchPlaylists()=>playlists.orderBy('createdAt',descending:true).snapshots();
  Stream<QuerySnapshot<Map<String,dynamic>>> watchPlaylistTracks(String id)=>
    playlists.doc(id).collection('tracks').snapshots();
}

class Jamendo{
 Future<List<Track>> fetch(String clientId,{String query=''})async{
  final p=<String,String>{'client_id':clientId,'format':'json','limit':'30','audioformat':'mp31','include':'lyrics'};
  if(query.trim().isNotEmpty){p['search']=query.trim();p['order']='relevance';}else{p['order']='popularity_total';}
  final u=Uri.https('api.jamendo.com','/v3.0/tracks/',p);
  final r=await http.get(u).timeout(const Duration(seconds:25));
  if(r.statusCode!=200)throw Exception('Jamendo HTTP ${r.statusCode}');
  final data=jsonDecode(r.body) as Map<String,dynamic>;
  if(data['headers']?['status']!='success')throw Exception(data['headers']?['error_message']??'Jamendo API error');
  return (data['results'] as List? ??[]).map((e)=>Track.fromJson(e)).where((e)=>e.audio.isNotEmpty).toList();
 }
}
class HomeScreen extends StatefulWidget{const HomeScreen({super.key});@override State<HomeScreen> createState()=>_HomeScreenState();}
class _HomeScreenState extends State<HomeScreen>{
 final player=AudioPlayer(),search=TextEditingController();final api=Jamendo();List<Track> tracks=[],recent=[];Track? current;bool loading=true;String error='';int tab=0;final Set<String> favorites={}; CloudLibrary? cloud;
 String clientId='';
 @override void initState(){super.initState();AppSettings.load().then((v){clientId=v['jamendo_id']??'';final user=FirebaseAuth.instance.currentUser;if(user!=null)cloud=CloudLibrary(user.uid);load();SharedPreferences.getInstance().then((p){favorites.addAll(p.getStringList('favorites')??[]);final raw=p.getString('recent_tracks');if(raw!=null){try{recent=(jsonDecode(raw) as List).map((e)=>Track.fromStoredMap(Map<String,dynamic>.from(e as Map))).toList();}catch(_){recent=[];}}if(mounted)setState((){});});});}
 Future<void> load([String q=''])async{setState(()=>loading=true);try{tracks=await api.fetch(clientId,query:q);error='';}catch(e){error=e.toString();}if(mounted)setState(()=>loading=false);}
 Future<void> play(Track t)async{try{await player.setAudioSource(AudioSource.uri(Uri.parse(t.audio),tag:MediaItem(id:t.id,album:t.album,title:t.name,artist:t.artist,artUri:Uri.tryParse(t.image))));await player.play();recent.removeWhere((x)=>x.id==t.id);recent.insert(0,t);if(recent.length>20)recent=recent.take(20).toList();final prefs=await SharedPreferences.getInstance();await prefs.setString('recent_tracks',jsonEncode(recent.map((x)=>x.toStoredMap()).toList()));if(mounted)setState(()=>current=t);}catch(e){if(mounted)setState(()=>error='Gagal memutar: $e');}}
 Future<void> next()async{if(tracks.isEmpty)return;final i=tracks.indexWhere((t)=>t.id==current?.id);await play(tracks[(i+1)%tracks.length]);}
 @override void dispose(){player.dispose();search.dispose();super.dispose();}
 @override Widget build(BuildContext context)=>Scaffold(
  appBar:AppBar(title:const Text('DEFPliF',style:TextStyle(color:purple,fontWeight:FontWeight.w900,letterSpacing:2)),actions:[IconButton(onPressed:()=>FirebaseAuth.instance.signOut(),icon:const Icon(Icons.logout))]),
  body:tab==0?home():tab==1?searchTab():tab==2?favoritesTab():tab==3?playlistTab():profileTab(),
  bottomNavigationBar:NavigationBar(backgroundColor:panel,selectedIndex:tab,onDestinationSelected:(v)=>setState(()=>tab=v),destinations:const[
   NavigationDestination(icon:Icon(Icons.home_outlined),label:'Home'),NavigationDestination(icon:Icon(Icons.search),label:'Cari'),NavigationDestination(icon:Icon(Icons.favorite_border),label:'Favorit'),NavigationDestination(icon:Icon(Icons.queue_music),label:'Playlist'),NavigationDestination(icon:Icon(Icons.person_outline),label:'Profil')]),
  bottomSheet:current==null?null:MiniPlayer(track:current!,player:player,onOpen:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>PlayerScreen(track:current!,player:player,onNext:next)))));
 Widget home()=>ListView(padding:const EdgeInsets.all(18),children:[
  const Text('Musik untuk duniamu',style:TextStyle(fontSize:25,fontWeight:FontWeight.bold)),const SizedBox(height:5),const Text('Jelajahi rilisan musik independen dari berbagai negara.',style:TextStyle(color:Colors.white60)),
  const SizedBox(height:16),TextField(controller:search,onSubmitted:(q){setState(()=>tab=1);load(q);},decoration:const InputDecoration(prefixIcon:Icon(Icons.search),hintText:'Cari lagu atau artis...')),
  const SizedBox(height:20),Container(padding:const EdgeInsets.all(17),decoration:BoxDecoration(gradient:const LinearGradient(colors:[Color(0xFF39245F),Color(0xFF17172B)]),borderRadius:BorderRadius.circular(18)),child:const Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('DEFPliF DISCOVERY',style:TextStyle(color:Color(0xFFD9C7FF),fontWeight:FontWeight.bold)),SizedBox(height:5),Text('Temukan suara baru setiap hari',style:TextStyle(fontSize:18,fontWeight:FontWeight.bold))]),
  if(recent.isNotEmpty)const SizedBox(height:20),if(recent.isNotEmpty)const Text('Terakhir diputar',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)),if(recent.isNotEmpty)...recent.take(8).map(tile),const SizedBox(height:20),const Text('Sedang populer',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)),if(loading)const Center(child:CircularProgressIndicator()),if(error.isNotEmpty)Text(error,style:const TextStyle(color:Colors.orangeAccent)),...tracks.map(tile),const SizedBox(height:100)
 ]);
 Widget searchTab()=>ListView(padding:const EdgeInsets.all(18),children:[const Text('Cari musik dunia',style:TextStyle(fontSize:24,fontWeight:FontWeight.bold)),const SizedBox(height:12),TextField(onSubmitted:(q)=>load(q),decoration:const InputDecoration(prefixIcon:Icon(Icons.search),hintText:'Judul lagu atau nama artis')),if(loading)const LinearProgressIndicator(),if(error.isNotEmpty)Text(error),...tracks.map(tile),const SizedBox(height:90)]);
 Widget favoritesTab()=>ListView(padding:const EdgeInsets.all(18),children:[
 const Text('Lagu favorit',style:TextStyle(fontSize:24,fontWeight:FontWeight.bold)),
 if(cloud==null)const Text('Login diperlukan untuk sinkronisasi cloud.'),
 if(cloud!=null)StreamBuilder<QuerySnapshot<Map<String,dynamic>>>(stream:cloud!.watchFavorites(),builder:(c,s){
  if(s.hasError)return Text('Gagal memuat favorit: ${s.error}');
  if(!s.hasData)return const Center(child:CircularProgressIndicator());
  if(s.data!.docs.isEmpty)return const Text('Belum ada lagu favorit.');
  return Column(children:s.data!.docs.map((d){final x=d.data();final t=Track(id:'${x['id']}',name:'${x['name']}',artist:'${x['artist']}',album:'${x['album']??''}',image:'${x['image']??''}',audio:'${x['audio']}',duration:(x['duration'] as num?)?.toInt()??0,lyrics:'${x['lyrics']??''}',license:'${x['license']??''}');return ListTile(title:Text(t.name),subtitle:Text(t.artist),leading:const Icon(Icons.music_note),onTap:()=>play(t),trailing:IconButton(icon:const Icon(Icons.delete_outline),onPressed:()=>cloud!.removeFavorite(t.id)));}).toList());
 })
]);

 Widget playlistTab()=>ListView(padding:const EdgeInsets.all(18),children:[
  Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[
   const Text('Playlist kamu',style:TextStyle(fontSize:24,fontWeight:FontWeight.bold)),
   IconButton(onPressed:()=>showDialog(context:context,builder:(ctx){final c=TextEditingController();return AlertDialog(title:const Text('Playlist baru'),content:TextField(controller:c,decoration:const InputDecoration(labelText:'Nama playlist')),actions:[TextButton(onPressed:()=>Navigator.pop(ctx),child:const Text('Batal')),FilledButton(onPressed:()async{if(c.text.trim().isNotEmpty&&cloud!=null)await cloud!.createPlaylist(c.text.trim());if(ctx.mounted)Navigator.pop(ctx);},child:const Text('Buat'))]);}),icon:const Icon(Icons.add_circle_outline,color:purple))
  ]),
  if(cloud==null)const Text('Login diperlukan untuk playlist cloud.'),
  if(cloud!=null)StreamBuilder<QuerySnapshot<Map<String,dynamic>>>(stream:cloud!.watchPlaylists(),builder:(c,s){
   if(s.hasError)return Text('Gagal memuat playlist: ${s.error}');
   if(!s.hasData)return const Center(child:CircularProgressIndicator());
   if(s.data!.docs.isEmpty)return const Text('Belum ada playlist. Tekan + untuk membuat.');
   return Column(children:s.data!.docs.map((d)=>ExpansionTile(title:Text('${d.data()['name']??'Playlist'}'),subtitle:Text('${(d.data()['trackIds'] as List? ??[]).length} lagu'),children:[
    StreamBuilder<QuerySnapshot<Map<String,dynamic>>>(stream:cloud!.watchPlaylistTracks(d.id),builder:(c,ts){
     if(!ts.hasData)return const Padding(padding:EdgeInsets.all(12),child:CircularProgressIndicator());
     return Column(children:ts.data!.docs.map((td){final x=td.data();final t=Track(id:'${x['id']}',name:'${x['name']}',artist:'${x['artist']}',album:'${x['album']??''}',image:'${x['image']??''}',audio:'${x['audio']}',duration:(x['duration'] as num?)?.toInt()??0,lyrics:'${x['lyrics']??''}',license:'${x['license']??''}');return ListTile(title:Text(t.name),subtitle:Text(t.artist),onTap:()=>play(t));}).toList());
    })
   ])).toList());
  })
 ]);
 Widget profileTab()=>ListView(padding:const EdgeInsets.all(18),children:[const Text('Profil',style:TextStyle(fontSize:24,fontWeight:FontWeight.bold)),Text(FirebaseAuth.instance.currentUser?.email??''),const SizedBox(height:20),const Text('DEFPliF V4 • Online streaming'),const Text('Katalog dan audio disediakan oleh Jamendo sesuai lisensi masing-masing track.')]);
 Widget tile(Track t)=>ListTile(contentPadding:const EdgeInsets.symmetric(vertical:5),leading:ClipRRect(borderRadius:BorderRadius.circular(9),child:t.image.isEmpty?Container(width:54,height:54,color:panel,child:const Icon(Icons.music_note)):Image.network(t.image,width:54,height:54,fit:BoxFit.cover,errorBuilder:(_,__,___)=>Container(width:54,height:54,color:panel,child:const Icon(Icons.music_note)))),title:Text(t.name,maxLines:1,overflow:TextOverflow.ellipsis),subtitle:Text(t.artist,maxLines:1,overflow:TextOverflow.ellipsis),onTap:()=>play(t),trailing:PopupMenuButton<String>(onSelected:(v)async{
 if(v=='fav'&&cloud!=null){await cloud!.setFavorite(t);setState(()=>favorites.add(t.id));}
 if(v=='playlist'&&cloud!=null){final ps=await cloud!.playlists.get();if(!mounted)return; if(ps.docs.isEmpty){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Buat playlist terlebih dahulu.')));return;}showDialog(context:context,builder:(ctx)=>SimpleDialog(title:const Text('Tambahkan ke playlist'),children:ps.docs.map((d)=>SimpleDialogOption(child:Text('${d.data()['name']}'),onPressed:()async{await cloud!.addToPlaylist(d.id,t);if(ctx.mounted)Navigator.pop(ctx);})).toList()));}
 },itemBuilder:(_)=>const [PopupMenuItem(value:'fav',child:Text('Simpan favorit')),PopupMenuItem(value:'playlist',child:Text('Tambah ke playlist'))],icon:const Icon(Icons.more_vert)));
}
class MiniPlayer extends StatelessWidget{final Track track;final AudioPlayer player;final VoidCallback onOpen;const MiniPlayer({super.key,required this.track,required this.player,required this.onOpen});@override Widget build(BuildContext context)=>Material(color:const Color(0xFF302247),child:ListTile(onTap:onOpen,title:Text(track.name,maxLines:1),subtitle:Text(track.artist),leading:const Icon(Icons.equalizer,color:purple),trailing:StreamBuilder<PlayerState>(stream:player.playerStateStream,builder:(c,s)=>IconButton(onPressed:()=>s.data?.playing==true?player.pause():player.play(),icon:Icon(s.data?.playing==true?Icons.pause:Icons.play_arrow,color:purple,size:30)))));}

class LyricsTranslator {
  static const languages = <String,String>{
    'en':'Inggris','id':'Indonesia','es':'Spanyol','fr':'Prancis',
    'de':'Jerman','it':'Italia','pt':'Portugis','ja':'Jepang',
    'ko':'Korea','zh':'Mandarin','ar':'Arab','ru':'Rusia',
    'th':'Thailand','tr':'Turki','nl':'Belanda','hi':'Hindi'
  };

  static List<String> _chunks(String text, {int max = 450}) {
    final words = text.split(RegExp(r'\s+'));
    final out = <String>[];
    var current = '';
    for (final word in words) {
      final candidate = current.isEmpty ? word : '$current $word';
      if (candidate.length > max && current.isNotEmpty) {
        out.add(current);
        current = word;
      } else {
        current = candidate;
      }
    }
    if (current.isNotEmpty) out.add(current);
    return out;
  }

  static Future<String> translate(String text, String source, String target) async {
    if (text.trim().isEmpty) throw Exception('Teks lirik kosong.');
    if (source == target) return text;
    final parts = _chunks(text);
    final translated = <String>[];
    for (final part in parts) {
      final uri = Uri.https('api.mymemory.translated.net', '/get', {
        'q': part,
        'langpair': '$source|$target',
      });
      final response = await http.get(uri).timeout(const Duration(seconds: 25));
      if (response.statusCode != 200) {
        throw Exception('Layanan penerjemah memberi HTTP ${response.statusCode}.');
      }
      final data = jsonDecode(response.body) as Map<String, dynamic>;
      final status = (data['responseStatus'] as num?)?.toInt() ?? 0;
      final result = (data['responseData'] as Map?)?['translatedText']?.toString() ?? '';
      if (status != 200 || result.isEmpty) {
        throw Exception(data['responseDetails']?.toString() ?? 'Terjemahan tidak tersedia.');
      }
      translated.add(result);
    }
    return translated.join('\n');
  }
}

class LyricsPanel extends StatefulWidget {
  final String lyrics;
  const LyricsPanel({super.key, required this.lyrics});
  @override State<LyricsPanel> createState() => _LyricsPanelState();
}

class _LyricsPanelState extends State<LyricsPanel> {
  String source = 'en';
  String target = 'id';
  String? translated;
  bool loading = false;
  String error = '';

  Future<void> runTranslation() async {
    if (widget.lyrics.trim().isEmpty) return;
    setState(() { loading = true; error = ''; translated = null; });
    try {
      final result = await LyricsTranslator.translate(widget.lyrics, source, target);
      if (mounted) setState(() => translated = result);
    } catch (e) {
      if (mounted) setState(() => error = e.toString().replaceFirst('Exception: ', ''));
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override Widget build(BuildContext context) => ExpansionTile(
    initiallyExpanded: false,
    title: const Text('Lirik & penerjemah'),
    leading: const Icon(Icons.lyrics_outlined, color: purple),
    children: [
      Padding(padding: const EdgeInsets.fromLTRB(16, 0, 16, 18), child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          if (widget.lyrics.trim().isEmpty)
            const Text('Lirik belum tersedia dari sumber lagu ini. DEFPliF tidak mengambil atau menyalin lirik dari sumber tidak resmi.'),
          if (widget.lyrics.trim().isNotEmpty) ...[
            const Text('Lirik asli', style: TextStyle(fontWeight: FontWeight.bold, color: purple)),
            const SizedBox(height: 8),
            Container(width: double.infinity, padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(12)), child: SelectableText(widget.lyrics)),
            const SizedBox(height: 14),
            const Text('Terjemahkan lirik', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Row(children: [
              Expanded(child: DropdownButtonFormField<String>(value: source, isExpanded: true, decoration: const InputDecoration(labelText: 'Dari'), items: LyricsTranslator.languages.entries.map((e) => DropdownMenuItem(value: e.key, child: Text(e.value, overflow: TextOverflow.ellipsis))).toList(), onChanged: loading ? null : (v) => setState(() { if (v != null) source = v; }))),
              const SizedBox(width: 10),
              Expanded(child: DropdownButtonFormField<String>(value: target, isExpanded: true, decoration: const InputDecoration(labelText: 'Ke'), items: LyricsTranslator.languages.entries.map((e) => DropdownMenuItem(value: e.key, child: Text(e.value, overflow: TextOverflow.ellipsis))).toList(), onChanged: loading ? null : (v) => setState(() { if (v != null) target = v; }))),
            ]),
            const SizedBox(height: 10),
            FilledButton.icon(onPressed: loading ? null : runTranslation, icon: const Icon(Icons.translate), label: Text(loading ? 'Menerjemahkan...' : 'Terjemahkan')),
            if (loading) const Padding(padding: EdgeInsets.all(10), child: Center(child: CircularProgressIndicator())),
            if (error.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 8), child: Text(error, style: const TextStyle(color: Colors.orangeAccent))),
            if (translated != null) ...[
              const SizedBox(height: 12),
              Text('Hasil: ${LyricsTranslator.languages[target]}', style: const TextStyle(fontWeight: FontWeight.bold, color: purple)),
              const SizedBox(height: 8),
              Container(width: double.infinity, padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(12)), child: SelectableText(translated!)),
            ],
            const SizedBox(height: 8),
            const Text('Terjemahan otomatis dapat kurang tepat untuk slang, metafora, dan ungkapan lagu. Layanan pihak ketiga menerima teks lirik untuk diproses.', style: TextStyle(color: Colors.white54, fontSize: 11)),
          ],
        ],
      )),
    ],
  );
}

class PlayerScreen extends StatelessWidget{
 final Track track;final AudioPlayer player;final VoidCallback onNext;
 const PlayerScreen({super.key,required this.track,required this.player,required this.onNext});
 String time(Duration d)=>'${d.inMinutes.remainder(60).toString().padLeft(2,'0')}:${d.inSeconds.remainder(60).toString().padLeft(2,'0')}';
 @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Now Playing')),body:Padding(padding:const EdgeInsets.all(24),child:Column(children:[
 const Spacer(),ClipRRect(borderRadius:BorderRadius.circular(24),child:track.image.isEmpty?Container(width:280,height:280,color:panel,child:const Icon(Icons.music_note,size:90)):Image.network(track.image,width:280,height:280,fit:BoxFit.cover,errorBuilder:(_,__,___)=>Container(width:280,height:280,color:panel,child:const Icon(Icons.music_note,size:90)))),
 const SizedBox(height:24),Text(track.name,textAlign:TextAlign.center,style:const TextStyle(fontSize:22,fontWeight:FontWeight.bold)),Text(track.artist,style:const TextStyle(color:Colors.white60)),const SizedBox(height:20),
 StreamBuilder<Duration?>(stream:player.durationStream,builder:(c,d)=>StreamBuilder<Duration>(stream:player.positionStream,builder:(c,p){final total=d.data??Duration.zero,pos=p.data??Duration.zero;return Column(children:[Slider(value:total.inMilliseconds==0?0:pos.inMilliseconds.clamp(0,total.inMilliseconds).toDouble(),max:total.inMilliseconds==0?1:total.inMilliseconds.toDouble(),onChanged:(v)=>player.seek(Duration(milliseconds:v.toInt()))),Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[Text(time(pos)),Text(time(total))])]);})),
 Row(mainAxisAlignment:MainAxisAlignment.center,children:[IconButton(onPressed:()=>player.seek(Duration.zero),icon:const Icon(Icons.skip_previous,size:34)),StreamBuilder<PlayerState>(stream:player.playerStateStream,builder:(c,s)=>IconButton(iconSize:62,color:purple,onPressed:()=>s.data?.playing==true?player.pause():player.play(),icon:Icon(s.data?.playing==true?Icons.pause_circle:Icons.play_circle))),IconButton(onPressed:onNext,icon:const Icon(Icons.skip_next,size:34))]),
 const SizedBox(height:14), LyricsPanel(lyrics: track.lyrics),
 const SizedBox(height:12),const Text('Streaming online • Tidak ada download offline',style:TextStyle(color:Colors.white38)),const Spacer()
 ])));
}
