# DEFPliF V5 — Online Music, Lyrics & Translation

V4 dibangun dari source V3. Semua fitur V3 tetap dipertahankan; tambahan V4 adalah riwayat pemutaran lokal.

## Fitur yang dipertahankan
- Setup awal Jamendo Client ID dan konfigurasi Firebase dari dalam aplikasi.
- Registrasi dan login email/password dengan sesi Firebase yang persisten.
- Jelajah katalog populer Jamendo dan pencarian lagu/artis.
- Streaming online, cover art, dan lirik jika tersedia pada track.
- Mini-player dan halaman pemutar penuh.
- Play/pause, next, seek, dan kontrol media melalui notifikasi/background playback.
- Favorit tersinkronisasi ke Cloud Firestore.
- Playlist cloud: membuat playlist, menambahkan lagu, dan melihat lagu di dalam playlist.
- Profil dan logout.
- Tidak ada unduhan atau pemutaran offline.

## Tambahan V5
- Panel lirik dan penerjemah pada halaman Now Playing.
- Pilihan bahasa sumber dan tujuan, termasuk Bahasa Indonesia.
- Terjemahan menggunakan MyMemory API; teks lirik dikirim ke layanan pihak ketiga. Kualitas, batas penggunaan, dan ketersediaan mengikuti penyedia.
- `index.html` root adalah halaman informasi struktur proyek; `web/index.html` adalah entry point Flutter Web. Aplikasi Android tetap berjalan dari source Flutter/Dart di `lib/main.dart`.

## Riwayat dan fitur V4 yang dipertahankan
- Riwayat hingga 20 lagu terakhir diputar.
- Riwayat disimpan di perangkat menggunakan SharedPreferences.
- Bagian **Terakhir diputar** muncul di halaman Home dan bisa diputar kembali.
- Versi aplikasi dinaikkan menjadi `5.0.0+5`.

## Setup awal
1. Install Flutter SDK dan Android SDK di komputer.
2. Buat aplikasi di https://developer.jamendo.com/ lalu salin Client ID.
3. Buat project Firebase di https://console.firebase.google.com/.
4. Tambahkan Android app pada Firebase dengan package name yang sama dengan `applicationId` proyek Flutter.
5. Aktifkan Authentication → Email/Password dan buat Cloud Firestore.
6. Salin Firebase API Key, App ID, Project ID, dan Sender ID dari Project settings.
7. Jalankan aplikasi, lalu isi Jamendo Client ID dan konfigurasi Firebase di halaman setup awal.

Contoh Firestore Rules untuk membatasi data berdasarkan akun:

```text
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /users/{userId}/{document=**} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
    }
  }
}
```

## Build di komputer
```bash
flutter create --platforms=android --project-name defplif .
flutter pub get
flutter run
flutter build apk --release
```

APK Flutter biasanya berada di `build/app/outputs/flutter-apk/app-release.apk`.

## Catatan transparansi
- Arsip ini berisi source Dart dan konfigurasi yang dibawa dari V3; folder Android minimal dari V3 belum merupakan Gradle wrapper lengkap. Jalankan `flutter create --platforms=android --project-name defplif .` dari direktori proyek untuk menghasilkan scaffold Android standar sebelum build (buat salinan cadangan terlebih dahulu).
- Flutter/Dart SDK tidak tersedia di lingkungan pembuatan arsip ini, jadi source belum dapat dianalisis atau dibuild. Ini **bukan APK siap instal** dan belum boleh dianggap lulus pengujian.
- AdMob belum diintegrasikan. Jika kelak ditambahkan, diperlukan App ID dan Ad Unit ID resmi.
- Jamendo adalah katalog musik yang tersedia melalui layanan dan lisensinya, bukan seluruh katalog komersial dunia. Audio dan lirik bergantung pada track.
- Riwayat pemutaran lokal hanya menyimpan metadata/link track; pemutaran ulang tetap membutuhkan koneksi internet dan track yang masih tersedia.
- Firebase API key adalah pengenal proyek aplikasi, bukan password akun. Jangan masukkan password Firebase atau kredensial privat ke konfigurasi aplikasi.
