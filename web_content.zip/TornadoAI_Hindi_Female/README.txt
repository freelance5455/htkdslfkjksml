TORNADO AI — HINDI FEMALE VOICE BUILD

Included:
- Hindi (India) speech recognition selected by default (requires WebView/browser SpeechRecognition support and microphone permission).
- Hindi-first AI responses.
- Hindi female-sounding text-to-speech selected by default; exact voice depends on Android's installed speech voices.
- Hindi male, system default, and English voice options.
- Groq chat endpoint and a documented default model setting.

IMPORTANT: No valid provider API key is embedded. API keys are private credentials created for each account; a working key cannot safely or legitimately be shared or fabricated. Create your own key at:
https://console.groq.com/keys

Then open Tornado AI > Settings, paste the key, tap Save key on this device, and tap Test AI connection.

Endpoint:
https://api.groq.com/openai/v1/chat/completions
Default model:
llama-3.3-70b-versatile
Check Groq's current model list if this model is no longer available in your account.

VOICE SETUP ON ANDROID:
1. Allow microphone permission for the installed app.
2. In Android Settings, install/enable Hindi speech recognition and Hindi text-to-speech voice data (Google Speech Services / your installed TTS engine).
3. In Tornado AI Settings, keep Recognition language set to Hindi (India) and Voice set to Hindi female voice.
4. Tap Test selected voice.

LIMITATIONS:
- A female Hindi voice is best-effort because voice names and availability vary by device. If no Hindi female voice is installed, Android may use another Hindi voice.
- Some ZIP-to-APK wrappers do not expose Web Speech recognition or allow cross-origin HTTPS API requests. If AI network fails with a CORS/WebView error, a backend proxy or a different native wrapper is needed.
- This is a single-page web app project, not a compiled or device-tested APK.
- API key stored in local browser/app storage is not secure. Do not distribute an APK with your personal key saved inside.
