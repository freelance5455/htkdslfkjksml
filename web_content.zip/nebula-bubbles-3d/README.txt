Cosmoblast
==========
Quick start: open index.html in Chrome, Safari, Edge or Firefox. Internet is needed (three.js and the font load from the web).

Offline / installable app (PWA):
1. Put the folder on any web host with HTTPS, or run a local server in this folder (for example: python3 -m http.server 8000) and open http://localhost:8000
2. Open the game once while online. Files are cached automatically.
3. Use "Install" / "Add to Home Screen" in your browser. It then also works offline.
(Service workers do not run when index.html is opened directly from disk.)

Progress, coins and settings are saved in the browser. Use Settings > Export save to back them up.

Update: new animated intro with cheerful music and a difficulty setting (Easy / Normal / Hard) on the intro screen and in Settings. Normal is the new default and has weaker power-ups.

Update 3: 10 unique bosses (levels 10, 20 ... 100) with their own look and attack, shown on the map and behind the bubble wall during the fight. Power-ups now need a x4 combo to charge, and using one makes the wall drop sooner.

Update 4: boss levels now have 2 stages (clear the level, then fight the boss). The gun color always matches the fired bubble. The offline cache (sw.js) now loads fresh files first, so updates show up. If you host the game online and still see the old version, clear the site data once or reload twice.

Update 5: After you tap PLAY on the intro, Leo's comic story starts: 12 animated scenes with a calm, deep, touching and motivating English male narrator (browser voice), word-by-word subtitles, comic sound words and cinematic music. Skip any time (SKIP button, Esc/Enter). CC = subtitles on/off, speaker = narrator on/off, microphone button = next narrator (other male voices, or DEEP / SOFT / DARK variants of the same voice), tap the picture for the next scene. Watch it again in Settings > Leo's story.
Voice tip: the narrator uses the best male voice your device offers. Best results: Microsoft Edge (Natural voices such as 'Guy' or 'Ryan'), or iPhone/Mac with an Enhanced voice (Daniel, Arthur, Aaron) installed under Settings > Accessibility > Spoken Content > Voices.

Update 6: Cancel aiming. While you aim, drag your finger back down to the cannon: the dotted line disappears and nothing is fired when you let go. Drag back up to aim again. A shot is only fired when you release while aiming.

Update 7:
- RULE BRIEFINGS: before every new gameplay variety a rules screen explains it with an animated demo, a 3-page guide (what / how it works / pro tips). Covers: Ice, Rocks, Chameleons, Combo Power-ups, Solar Wind, Mirror Space, Gravity Well, Puzzle, Rescue, Boss Battle, Core Breaker, Endless, Time Attack, Daily. The first time you see one, the full guide is shown. Later a short reminder card appears (Settings > Rule briefings: ALWAYS / FIRST TIME / OFF). Settings > Rule guide lets you re-read every rule.
- BOSS FIGHTS: siren and WARNING cinematic intro, boss health bar with ATTACK IN countdown and red alarm before each attack, attack banners, damage numbers (CRIT!), phase banners at 50% and 25% (enraged, red screen pulse), boss taunts, armor-break moment.
- CORE BREAKER: after the boss armor is gone you finish him in a mini game. Drag to aim, release to fire a pulse through the gaps of the rotating shield rings and hit the core. Shoot down the orbs the boss fires at your cannon (3 lives). Every boss has its own special (frost orbs, homing orbs, volleys, self-healing, core shield, darkness, reverse rings). If you retreat, the next try starts directly at the Core Breaker.

Update 8: Fixed overlapping screens. The boss health bar and taunts no longer show through the level/boss intro screens; the boss intro now has its own solid background, the duplicated rule text was removed from the old intro (the new rules screen covers it), and the boss bar sits right below the game HUD with the taunt next to the attack counter.

Update 9: Bosses on the map. Every boss level (10, 20 ... 100) now shows its own boss that jumps up and down aggressively: crouch, big leap, hard slam with squash, shockwave ring on the ground, red aura and angry shaking. Every third jump is a bigger roar-jump. The bosses are animated live and can be tapped to select the level. Locked bosses jump too, just dimmer.

Update 10: Overlapping texts fixed for good. The level/boss intro screen is now fully opaque (before, the game HUD showed through as ghost text behind the title). The old intro no longer repeats rules that the new rules screen already explained (mode note, long power-up list). Boss taunts now sit under the boss health bar instead of beside it, and the phase banners have more spacing.


Update 11: BOSS CARDS, CARD ALBUM and more.
- Every boss you defeat drops a premium trading card with holographic foil that follows your finger or tilting phone. 4 rarities: DEFEATED, HOLO RARE, ULTRA RARE (full art) and SECRET PRISM. Fewer lost hearts in the finale = rarer card. Open the ALBUM with the CARDS button on the map: cards, cannon skins, goals, daily boss, hall of fame.
- Each card unlocks a cannon skin. All 10 cards unlock the animated PRISM cannon.
- HARD MODE rematch for beaten bosses (needed for the Secret Prism card).
- STORM DODGE: second finale mini game (bullet storm) for the bosses of levels 20, 40, 60, 80. Level 100 needs both finales.
- Screen-shatter finish, comic cutscene after every boss, a real ending with credits after level 100.
- Daily missions + weekly goals, daily boss with a twist, hall of fame, new achievements.
- Shooting stars give a free power-up charge when tapped. Combo music layer + haptics. Every crew member has their own voice.

Update 12: SPECIAL BUBBLES + ELITE GUARDIANS.
- From level 4: bubbles with a symbol. Bomb pops all neighbours, Lightning wipes its row, Magnet pops the 4 nearest bubbles of its colour. They chain and they hurt bosses.
- Levels 5, 15, 25 ... 95 have an Elite Guardian mini boss: its own health bar (every popped bubble hurts it), it attacks every 4 shots with rocks, defeating it wins the level (+30 coins).
- New rule guides for both (shown automatically the first time).

Update 13: Share a card as an image (SHARE button on a card saves/shares a PNG of the card), flying ships and comets on the map.


Update 14: Recorded narrator for Leo's story (embedded in index.html). Pictures, subtitles and word highlighting now follow the audio clock, so they stay in sync even if the device lags; tapping the picture jumps to the next scene's audio. The browser voice is only used if the audio cannot be played. The comics after boss fights still use the browser voice.

Update 15: Shop fix: the SHOP button now always opens the full shop again (bubble skins Classic / Neon Ring / Gem / Planet, drone, Pulse Core, hull plating). Leo in the game screen is about 19% larger; his feet stay in place so he grows upward in the corner, away from the bubble wall.

Update 16: Leo stands a bit closer to the cannon. Map v2: glowing energy path with travelling light pulses, star-system gates, ringed planets with orbiting moons, animated space stations, nebula clouds, drifting dust, orbiting moons and rings around every level node and a red danger ring around every boss level. The jumping bosses are unchanged.

Update 17: Monetization placeholders. Shop: free-coins video (5/day), Starter pack, 4 coin packs. After a failed level: video for a retry with +2 misses. After a win: video for double coins. Rewarded ads use AdMob inside a Capacitor app (see ADS-SETUP.txt); in the browser a placeholder ad and a TEST PURCHASE screen are shown.

Update 18: Difficulty fixed. The intro now has three buttons (EASY / MEDIUM / HARD), always visible and tappable, with a short description. Easy: +3 misses, full power-ups, slower wall, weaker bosses (-20% HP). Medium: standard. Hard: -2 misses, no start power-ups, faster wall, stronger bosses (+25% HP), coins x1.5. Also changeable in Settings.

Update 19 (gameplay-plus.js): Laser + Slime bubbles, black holes and bumpers, level codes, weekly tournament, auto-help after fails, power-up fusion (bomb+bolt, bomb+rainbow, bolt+rainbow), crew abilities, stronger prestige. Open the PLUS button on the map.

Update 20 (card-fullscreen.js): tap an owned boss card in the album to open it fullscreen with an opening animation that depends on its rarity and boss level (silver iris, cyan shockwaves, golden sunburst, rainbow prism). Tap the intro to skip, tap the card to flip, drag to tilt.

Update 21: Gameplay+ and fullscreen cards are now embedded directly in index.html (no extra files needed).

Update 22: 500 levels. From level 105 a unique boss appears every 5 levels (80 new bosses), each with its own generated look, name, taunt and attack.

Update 23: all 80 new bosses (levels 105-500, every 5th level) jump on the map like the original bosses and drop a card (ULTRA with 80%+ misses left, HOLO with 50%+, otherwise DEFEATED; HARD mode adds one rarity). The album now holds 90 cards.


Update 24: 80 completely new hand-designed boss figures (levels 105-500). 8 worlds x 10 bosses, each with its own silhouette, face, colors and idle animation: Beasts (105-150), Machines (155-200), Undead (205-250), Elementals (255-300), Cosmic (305-350), Nightmare Toys (355-400), Nature & Insects (405-450), Tyrants & Gods (455-500). Every boss has its own name, title and taunt. Cards show the world as type (BEAST, MACHINE, UNDEAD ...).

Update 25: Boss cards for levels 105-500 redesigned. Every boss has 2 own attacks (name + description), own weakness, resistance and size. Each of the 8 worlds has its own card style: pattern background, colored art border, corner frame and a world badge (BEAST, MACHINE, UNDEAD, ELEMENT, COSMIC, TOY, NATURE, TYRANT). Works on all rarities (silver, gold, holo, rainbow).

Update 26: BOSSPLAY. The 80 new bosses now fight with the two attacks printed on their card (attack 1 normally, attack 2 as well once they are below half health), and each world has its own rule: Beasts FRENZY, Machines SELF-REPAIR, Undead HAUNTED, Elementals constant WIND, Cosmic GRAVITY WELL, Toys CHAOS, Nature REGROWTH, Tyrants ARMOR. 20+ attack effects (rocks, ash, ice, slime, scramble, spawn, eat, steal, armor, darkness, wall drop, flipped aim, wind, gravity, combo reset, charge steal ...). Attack power grows slightly from world to world. The boss intro lists both attacks and the world rule.

Update 27: 8 bosses with SIGNATURE mechanics: Reactis (heat meter / meltdown), Draculon (heals on your misses), Zephyra (wind changes every shot), Singula (heals when you clear 5+ bubbles), Chronos (every attack undoes your last shot), Dicey (dice-roll attacks), Medusae (stone spreads next to rocks), Omegon (changes form every attack and uses another world's rule). Shown in the boss intro with a star.

Update 28: ACHIEVEMENT BADGES on the map (your earned badges appear as a column on the left, with a counter), VICTORY FLAGS planted on every boss whose card you own (all 90 bosses), FRIENDS CODES (Album > HALL: share your weekly score as a code, paste a friend's code and compare on a weekly friends list) and SHARE YOUR BEST RUN AS AN IMAGE (Album > HALL > IMAGE).

