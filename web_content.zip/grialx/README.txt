GRIALX / GRLX — Android Premium v3

Cambios:
- Tipografía display GRIALX embebida localmente (Inter Display Bold/Black), sin depender de Internet.
- Tratamiento futurista de marca: mayúsculas, tracking, inclinación y brillo.
- Corrección completa del modo claro: GRIALX, títulos, secciones, números y navegación cambian a tonos oscuros legibles.
- Modo oscuro/claro persistente.
- Web offline incluida en el proyecto.
- Staking demo y retiro de recompensas.
