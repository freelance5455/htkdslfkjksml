
const KEY="quranAppV1";
const surahs = [{"name": "الفاتحة", "verses": 7}, {"name": "البقرة", "verses": 286}, {"name": "آل عمران", "verses": 200}, {"name": "النساء", "verses": 176}, {"name": "المائدة", "verses": 120}, {"name": "الأنعام", "verses": 165}, {"name": "الأعراف", "verses": 206}, {"name": "الأنفال", "verses": 75}, {"name": "التوبة", "verses": 129}, {"name": "يونس", "verses": 109}, {"name": "هود", "verses": 123}, {"name": "يوسف", "verses": 111}, {"name": "الرعد", "verses": 43}, {"name": "إبراهيم", "verses": 52}, {"name": "الحجر", "verses": 99}, {"name": "النحل", "verses": 128}, {"name": "الإسراء", "verses": 111}, {"name": "الكهف", "verses": 110}, {"name": "مريم", "verses": 98}, {"name": "طه", "verses": 135}, {"name": "الأنبياء", "verses": 112}, {"name": "الحج", "verses": 78}, {"name": "المؤمنون", "verses": 118}, {"name": "النور", "verses": 64}, {"name": "الفرقان", "verses": 77}, {"name": "الشعراء", "verses": 227}, {"name": "النمل", "verses": 93}, {"name": "القصص", "verses": 88}, {"name": "العنكبوت", "verses": 69}, {"name": "الروم", "verses": 60}, {"name": "لقمان", "verses": 34}, {"name": "السجدة", "verses": 30}, {"name": "الأحزاب", "verses": 73}, {"name": "سبأ", "verses": 54}, {"name": "فاطر", "verses": 45}, {"name": "يس", "verses": 83}, {"name": "الصافات", "verses": 182}, {"name": "ص", "verses": 88}, {"name": "الزمر", "verses": 75}, {"name": "غافر", "verses": 85}, {"name": "فصلت", "verses": 54}, {"name": "الشورى", "verses": 53}, {"name": "الزخرف", "verses": 89}, {"name": "الدخان", "verses": 59}, {"name": "الجاثية", "verses": 37}, {"name": "الأحقاف", "verses": 35}, {"name": "محمد", "verses": 38}, {"name": "الفتح", "verses": 29}, {"name": "الحجرات", "verses": 18}, {"name": "ق", "verses": 45}, {"name": "الذاريات", "verses": 60}, {"name": "الطور", "verses": 49}, {"name": "النجم", "verses": 62}, {"name": "القمر", "verses": 55}, {"name": "الرحمن", "verses": 78}, {"name": "الواقعة", "verses": 96}, {"name": "الحديد", "verses": 29}, {"name": "المجادلة", "verses": 22}, {"name": "الحشر", "verses": 24}, {"name": "الممتحنة", "verses": 13}, {"name": "الصف", "verses": 14}, {"name": "الجمعة", "verses": 11}, {"name": "المنافقون", "verses": 11}, {"name": "التغابن", "verses": 18}, {"name": "الطلاق", "verses": 12}, {"name": "التحريم", "verses": 12}, {"name": "الملك", "verses": 30}, {"name": "القلم", "verses": 52}, {"name": "الحاقة", "verses": 52}, {"name": "المعارج", "verses": 44}, {"name": "نوح", "verses": 28}, {"name": "الجن", "verses": 28}, {"name": "المزمل", "verses": 20}, {"name": "المدثر", "verses": 56}, {"name": "القيامة", "verses": 40}, {"name": "الإنسان", "verses": 31}, {"name": "المرسلات", "verses": 50}, {"name": "النبأ", "verses": 40}, {"name": "النازعات", "verses": 46}, {"name": "عبس", "verses": 42}, {"name": "التكوير", "verses": 29}, {"name": "الانفطار", "verses": 19}, {"name": "المطففين", "verses": 36}, {"name": "الانشقاق", "verses": 25}, {"name": "البروج", "verses": 22}, {"name": "الطارق", "verses": 17}, {"name": "الأعلى", "verses": 19}, {"name": "الغاشية", "verses": 26}, {"name": "الفجر", "verses": 30}, {"name": "البلد", "verses": 20}, {"name": "الشمس", "verses": 15}, {"name": "الليل", "verses": 21}, {"name": "الضحى", "verses": 11}, {"name": "الشرح", "verses": 8}, {"name": "التين", "verses": 8}, {"name": "العلق", "verses": 19}, {"name": "القدر", "verses": 5}, {"name": "البينة", "verses": 8}, {"name": "الزلزلة", "verses": 8}, {"name": "العاديات", "verses": 11}, {"name": "القارعة", "verses": 11}, {"name": "التكاثر", "verses": 8}, {"name": "العصر", "verses": 3}, {"name": "الهمزة", "verses": 9}, {"name": "الفيل", "verses": 5}, {"name": "قريش", "verses": 4}, {"name": "الماعون", "verses": 7}, {"name": "الكوثر", "verses": 3}, {"name": "الكافرون", "verses": 6}, {"name": "النصر", "verses": 3}, {"name": "المسد", "verses": 5}, {"name": "الإخلاص", "verses": 4}, {"name": "الفلق", "verses": 5}, {"name": "الناس", "verses": 6}];
const seed={
 settings:{teacherName:"أحمد محمد",circleName:"حلقة مسجد النور",start:"17:00",end:"19:00"},
 students:[
  {id:1,name:"عبدالله إبراهيم",present:true},{id:2,name:"أحمد محمد",present:true},{id:3,name:"يوسف علي",present:true},
  {id:4,name:"عمر خالد",present:true},{id:5,name:"محمد حسن",present:false},{id:6,name:"علي محمود",present:true}
 ],
 recitations:[],
 reports:[],
 teachers:[{id:1,name:"أحمد محمد",circle:"حلقة مسجد النور"}]
};
let db=load(); 
function load(){try{return JSON.parse(localStorage.getItem(KEY))||structuredClone(seed)}catch(e){return structuredClone(seed)}}
function save(){localStorage.setItem(KEY,JSON.stringify(db))}
function resetDemo(){if(confirm("إعادة بيانات التجربة؟")){db=structuredClone(seed);save();location.reload()}}
function show(id){document.querySelectorAll(".screen").forEach(x=>x.classList.remove("active"));document.getElementById(id).classList.add("active")}
function enterApp(){renderTeacher()}
function toast(s){let x=document.getElementById("toast");x.textContent=s;x.style.display="block";setTimeout(()=>x.style.display="none",2200)}
document.addEventListener("click",e=>{let b=e.target.closest(".tab");if(!b)return;let parent=b.parentElement;parent.querySelectorAll(".tab").forEach(x=>x.classList.remove("active"));b.classList.add("active");let screen=b.closest(".screen");screen.querySelectorAll(".tabpage").forEach(x=>x.classList.remove("active"));screen.querySelector("#"+b.dataset.tab).classList.add("active")});

function renderTeacher(){
 const s=db.settings, present=db.students.filter(x=>x.present).length, absent=db.students.length-present;
 document.getElementById("teacherNameLabel").textContent=s.teacherName+" • "+s.circleName;
 document.getElementById("teacherStats").innerHTML=stats([["عدد الطلاب",db.students.length],["الحاضرون",present],["الغياب",absent],["التقارير المرسلة",db.reports.filter(r=>r.teacher===s.teacherName).length]]);
 document.getElementById("settingsTeacherName").value=s.teacherName;document.getElementById("settingsCircleName").value=s.circleName;document.getElementById("settingsStart").value=s.start;document.getElementById("settingsEnd").value=s.end;
 document.getElementById("todayLesson").innerHTML=`<div class="lesson"><div class="box"><b>${s.circleName}</b><span>الحلقة</span></div><div class="box"><b>${s.start} - ${s.end}</b><span>الوقت</span></div><div class="box"><b>${present} / ${db.students.length}</b><span>الحضور</span></div></div>`;
 document.getElementById("studentList").innerHTML=db.students.map(x=>`<div class="student-row"><b>${x.name}</b><span class="pill ${x.present?"":"absent"}">${x.present?"حاضر":"غائب"}</span></div>`).join("");
 renderRecitations(); renderDailyReport();
}
function stats(a){return a.map(x=>`<div class="stat"><b>${x[1]}</b><span>${x[0]}</span></div>`).join("")}
function openAttendance(){
 document.getElementById("modalBody").innerHTML=`<h3>تسجيل حضور اليوم</h3>`+db.students.map(x=>`<div class="student-row"><b>${x.name}</b><button class="${x.present?"primary":"secondary"} small" onclick="togglePresent(${x.id})">${x.present?"حاضر":"غائب"}</button></div>`).join("")+`<button class="primary wide" onclick="closeModal();renderTeacher()">حفظ الحضور</button>`;
 document.getElementById("modal").classList.add("open")
}
function togglePresent(id){let s=db.students.find(x=>x.id===id);s.present=!s.present;save();openAttendance()}
function addStudent(){let name=prompt("اسم الطالب");if(name&&name.trim()){db.students.push({id:Date.now(),name:name.trim(),present:true});save();renderTeacher();toast("تمت إضافة الطالب")}}
function renderRecitations(){
 const el=document.getElementById("recitationList");
 let items=db.recitations;
 el.innerHTML=items.length?items.map((r,i)=>`<div class="recite-item"><strong>${r.student} — ${r.type}</strong><span>${r.surah} من ${r.from} إلى ${r.to} • ${r.count} آيات</span> <button class="danger" onclick="removeRecite(${i})">حذف</button></div>`).join(""):"<p class='muted'>لم يتم تسجيل تسميع اليوم.</p>";
 el.innerHTML+=`<button class="secondary wide" onclick="openRecitation()">+ تسجيل جديد أو مراجعة</button>`
}
function openRecitation(){
 const opts=db.students.map(x=>`<option>${x.name}</option>`).join(""), sopts=surahs.map((x,i)=>`<option value="${i}">${x.name}</option>`).join("");
 document.getElementById("modalBody").innerHTML=`<h3>تسجيل التسميع</h3>
 <label>الطالب<select id="rStudent">${opts}</select></label>
 <label>النوع<select id="rType"><option>جديد</option><option>مراجعة</option><option>جديد + مراجعة</option></select></label>
 <label>السورة<select id="rSurah" onchange="updateVerseMax()">${sopts}</select></label>
 <div class="recite-form"><label>من آية<input id="rFrom" type="number" min="1" value="1"></label><label>إلى آية<input id="rTo" type="number" min="1" value="7"></label><div id="verseHint" class="muted"></div></div>
 <button class="primary wide" onclick="addRecitation()">حفظ التسميع</button>`;
 document.getElementById("modal").classList.add("open");updateVerseMax()
}
function updateVerseMax(){let max=surahs[+document.getElementById("rSurah").value].verses;document.getElementById("rTo").max=max;document.getElementById("rFrom").max=max;document.getElementById("verseHint").textContent=`السورة تحتوي على ${max} آية`}
function addRecitation(){let si=+document.getElementById("rSurah").value,from=+rFrom.value,to=+rTo.value;if(from<1||to<from||to>surahs[si].verses){toast("راجع أرقام الآيات");return}db.recitations.push({student:rStudent.value,type:rType.value,surah:surahs[si].name,from,to,count:to-from+1});save();closeModal();renderTeacher();toast("تم حفظ التسميع")}
function removeRecite(i){db.recitations.splice(i,1);save();renderTeacher()}
function dailyData(){let present=db.students.filter(x=>x.present).length,absent=db.students.length-present,newA=db.recitations.filter(x=>x.type.includes("جديد")).reduce((a,x)=>a+x.count,0),revA=db.recitations.filter(x=>x.type.includes("مراجعة")).reduce((a,x)=>a+x.count,0);return{present,absent,newA,revA,total:db.students.length}}
function renderDailyReport(){let d=dailyData();document.getElementById("dailyReport").innerHTML=`<div class="summary-grid"><div class="summary-card"><span>الحاضرين</span><b>${d.present}</b></div><div class="summary-card"><span>الغائبين</span><b>${d.absent}</b></div><div class="summary-card"><span>الجديد</span><b>${d.newA} آية</b></div><div class="summary-card"><span>المراجعة</span><b>${d.revA} آية</b></div></div><p class="muted">المدة: ${db.settings.start} - ${db.settings.end} • ${db.settings.circleName}</p>`}
function sendReport(){let d=dailyData(), date=new Date().toISOString().slice(0,10);db.reports.push({id:Date.now(),date,teacher:db.settings.teacherName,circle:db.settings.circleName,start:db.settings.start,end:db.settings.end,present:d.present,absent:d.absent,total:d.total,newA:d.newA,revA:d.revA,status:"مرسل"});db.recitations=[];save();renderTeacher();toast("تم إرسال التقرير للمدير")}
function saveDraft(){toast("تم حفظ التقرير على الجهاز بدون إرساله")}
function saveSettings(){db.settings.teacherName=settingsTeacherName.value.trim()||"المحفظ";db.settings.circleName=settingsCircleName.value.trim()||"حلقة";db.settings.start=settingsStart.value;db.settings.end=settingsEnd.value;let t=db.teachers[0];t.name=db.settings.teacherName;t.circle=db.settings.circleName;save();renderTeacher();toast("تم حفظ الإعدادات")}
function closeModal(){document.getElementById("modal").classList.remove("open")}

function renderManager(){
 let month=document.getElementById("monthPicker").value||new Date().toISOString().slice(0,7);document.getElementById("monthPicker").value=month;
 let rs=db.reports.filter(r=>r.date.startsWith(month)), hours=rs.reduce((a,r)=>a+duration(r.start,r.end),0),students=rs.reduce((a,r)=>a+r.present,0),newA=rs.reduce((a,r)=>a+r.newA,0),revA=rs.reduce((a,r)=>a+r.revA,0);
 document.getElementById("managerStats").innerHTML=stats([["الحصص المرسلة",rs.length],["إجمالي الساعات",hours.toFixed(1)],["مرات حضور الطلاب",students],["آيات الجديد",newA]]);
 document.getElementById("monthSummary").innerHTML=`<div class="summary-grid"><div class="summary-card"><span>الحصص</span><b>${rs.length}</b></div><div class="summary-card"><span>الساعات</span><b>${hours.toFixed(1)}</b></div><div class="summary-card"><span>الجديد</span><b>${newA}</b></div><div class="summary-card"><span>المراجعة</span><b>${revA}</b></div></div>`;
 document.getElementById("reportsTable").innerHTML=rs.length?`<table><thead><tr><th>التاريخ</th><th>المحفظ</th><th>الحضور</th><th>الساعات</th><th>الجديد</th><th>المراجعة</th></tr></thead><tbody>${rs.map(r=>`<tr><td>${r.date}</td><td>${r.teacher}</td><td>${r.present}</td><td>${duration(r.start,r.end).toFixed(1)}</td><td>${r.newA}</td><td>${r.revA}</td></tr>`).join("")}</tbody></table>`:"<p class='muted'>لا توجد تقارير مرسلة في هذا الشهر.</p>";
 document.getElementById("teacherTable").innerHTML=db.teachers.map(t=>`<div class="teacher-row"><b>${t.name}</b><span>${t.circle}</span></div>`).join("");
}
function duration(a,b){if(!a||!b)return 0;let [h1,m1]=a.split(":").map(Number),[h2,m2]=b.split(":").map(Number);let x=(h2*60+m2)-(h1*60+m1);if(x<0)x+=1440;return x/60}
function addTeacher(){let name=prompt("اسم المحفظ");if(name){db.teachers.push({id:Date.now(),name,circle:"حلقة جديدة"});save();renderManager();toast("تمت إضافة المحفظ")}}
function exportReports(){let rows=[["التاريخ","المحفظ","الحلقة","الحضور","الغياب","الساعات","الجديد","المراجعة"],...db.reports.map(r=>[r.date,r.teacher,r.circle,r.present,r.absent,duration(r.start,r.end).toFixed(1),r.newA,r.revA])];let csv="\ufeff"+rows.map(r=>r.join(",")).join("\n");let a=document.createElement("a");a.href=URL.createObjectURL(new Blob([csv],{type:"text/csv;charset=utf-8"}));a.download="تقارير_الحلقات.csv";a.click()}
renderTeacher();renderManager();

window.addEventListener("load",renderTeacher);
function clearLocal(){if(confirm("مسح بيانات المحفظ على هذا الجهاز؟")){localStorage.removeItem(KEY);location.reload()}}
