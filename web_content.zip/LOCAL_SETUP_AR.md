# دليل التشغيل

## لوحة الإدارة
1. ثبّت Node.js.
2. افتح مجلد `admin` في الطرفية.
3. نفّذ `npm install` ثم `npm run dev`.
4. افتح الرابط الذي يظهر غالبًا `http://localhost:5173`.
5. في الوضع التجريبي: `admin@example.com` وكلمة المرور `DemoOnly123!` (للتجربة المحلية فقط، لا تستخدمها في النشر).

## تطبيق Android
1. افتح مجلد `mobile`.
2. نفّذ `npm install` ثم `npx expo start`.
3. امسح QR باستخدام Expo Go للتجربة.
4. لإنشاء APK: نفّذ `npx eas-cli login` ثم `npx eas-cli build:configure` ثم `npx eas-cli build -p android --profile preview`. يتطلب ذلك حساب Expo واتصال إنترنت.

## ربط قاعدة البيانات
1. أنشئ مشروعًا في Supabase وشغّل `supabase/schema.sql` في SQL Editor.
2. أنشئ مستخدم مشرف عبر Authentication.
3. عيّن دوره إلى admin:
```sql
update public.profiles set role='admin'
where id=(select id from auth.users where email='YOUR_ADMIN_EMAIL@example.com');
```
4. ضع Project URL و anon/public key في `admin/.env` باسم `VITE_SUPABASE_URL` و`VITE_SUPABASE_ANON_KEY`.
5. وفي `mobile/.env` استخدم `EXPO_PUBLIC_SUPABASE_URL` و`EXPO_PUBLIC_SUPABASE_ANON_KEY`.
6. أعد تشغيل التطبيقين.

مهم: لا تضع مفتاح service_role في واجهة المستخدم. لا تنشر النسخة قبل اختبار الصلاحيات والخصوصية. طلب الفتوى يجب أن يراجعه مختص مؤهل.
