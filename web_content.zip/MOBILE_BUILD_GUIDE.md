# NOOR phone app project (Android + iPhone)

This folder is prepared for Capacitor, which packages the existing NOOR app as a native Android and iOS app while keeping the laptop/browser edition.

## Compatibility target

- Android minimum API target: Android 6.0 / API 23 as a packaging baseline. The Samsung Galaxy A9 (2018) and Galaxy A55 are within the intended device range, subject to OS/browser WebView updates.
- iOS deployment target: iOS 14.0. iPhone X and newer devices, including the iPhone 18 family, are within the intended device range if running a supported iOS release.
- The app uses a responsive layout; this does not mean every device/OS combination has been physically tested.

## Build Android (Windows or macOS)

1. Install Node.js 20+ and Android Studio.
2. Install the Android SDK platform and build tools offered by Android Studio.
3. In this folder run:

   ```bash
   npm install
   npm run cap:add:android
   npm run cap:sync
   npm run android
   ```

4. In Android Studio choose Build → Build Bundle(s) / APK(s) → Build APK(s). Android Studio will show the APK location.

## Build iPhone app (requires a Mac)

Apple requires Xcode and macOS to compile/sign an iOS app. Windows cannot produce a genuine installable IPA by itself.

1. On a Mac install Node.js 20+ and Xcode.
2. In this folder run:

   ```bash
   npm install
   npm run cap:add:ios
   npm run cap:sync
   npm run ios
   ```

3. In Xcode set the signing Team, bundle identifier `com.noor.islamiccompanion`, and deployment target iOS 14.0. Run on a device or archive for distribution.

## Notifications

- The in-app Yes/No prompt appears only when NOOR's reminder setting is off or OS notification permission is no longer granted.
- If reminders are enabled and permission remains granted, app launches are silent: no repeated prompt.
- Choosing No leaves reminders off; NOOR asks again on a later launch while they remain off.
- Native builds use Capacitor Local Notifications to schedule the remaining prayer reminders for the currently loaded day's timetable. Open NOOR daily so it can refresh the next day's timetable. Browser/laptop mode keeps browser notifications and its foreground timer.
- iOS/Android own the final permission dialog. The app cannot override a permission denial; users must change it in system settings.

## Notes

- This is a native-project source package, not a precompiled APK/IPA. Android APK generation needs Android Studio + Android SDK. iOS builds require macOS + Xcode + Apple signing.
- The app continues to use the existing free public Quran, translation and prayer-time data services. Internet is needed for fresh data and streamed Quran recitation.
- Before publishing publicly, confirm rights to redistribute all bundled audio and complete store privacy disclosures.
