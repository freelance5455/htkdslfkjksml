# لمّة — Android

نسخة Android من لعبة لمّة، مبنية من ملفات الويب الأصلية.

- App name: لمّة
- Application ID: com.mohanad.lamma
- Orientation: Portrait
- Web assets bundled locally under `app/src/main/assets`

افتح المجلد في Android Studio ثم Build > Build APK(s).
