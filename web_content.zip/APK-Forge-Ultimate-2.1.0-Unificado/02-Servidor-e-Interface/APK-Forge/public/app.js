const form = document.querySelector("#builder");
const projectInput = document.querySelector("#project");
const iconInput = document.querySelector("#icon");
const keyInput = document.querySelector("#keystore");
const buildButton = document.querySelector("#build");
const statusBox = document.querySelector("#status");
const logBox = document.querySelector("#log");
const HISTORY_KEY = "apkForge.history.v2";
const API_URL_KEY = "apkForge.apiUrl.v2";
const pageTitles = { dashboard: "Painel", builder: "Novo build", permissions: "Permissões", history: "Histórico", diagnostics: "Diagnóstico", settings: "Configurações", about: "Sobre e limites" };
let currentAnalysis = null;
let lastDiagnostic = null;
let isBuilding = false;
let analysisSequence = 0;

const byId = id => document.getElementById(id);
const trimSlash = value => value.trim().replace(/\/+$/, "");
const safeText = value => String(value ?? "");

function showPage(name) {
  if (!pageTitles[name]) return;
  document.querySelectorAll("[data-page]").forEach(page => { page.hidden = page.dataset.page !== name; });
  document.querySelectorAll("[data-page-target]").forEach(button => {
    const active = button.dataset.pageTarget === name;
    button.classList.toggle("active", active);
    if (button.classList.contains("nav-link")) active ? button.setAttribute("aria-current", "page") : button.removeAttribute("aria-current");
  });
  byId("pageTitle").textContent = pageTitles[name];
  if (name === "history") renderHistory();
  if (name === "dashboard") renderDashboard();
  if (name === "diagnostics") renderDiagnostics();
  window.scrollTo({ top: 0, behavior: "smooth" });
}

document.querySelectorAll("[data-page-target]").forEach(button => button.addEventListener("click", () => showPage(button.dataset.pageTarget)));

function getHistory() {
  try {
    const history = JSON.parse(localStorage.getItem(HISTORY_KEY) || "[]");
    return Array.isArray(history) ? history.filter(item => item && typeof item.id === "string") : [];
  } catch { return []; }
}
function recoverInterruptedBuilds() {
  const history = getHistory();
  let changed = false;
  history.forEach(item => {
    if (item.status === "Compilando") {
      item.status = "Sem confirmação";
      item.error = "A aba foi fechada ou recarregada antes de receber a resposta do servidor.";
      changed = true;
    }
  });
  if (changed) { try { localStorage.setItem(HISTORY_KEY, JSON.stringify(history)); } catch {} }
}
function saveHistory(history) {
  try { localStorage.setItem(HISTORY_KEY, JSON.stringify(history.slice(0, 50))); }
  catch { setStatus("O histórico deste navegador não pôde ser salvo (armazenamento local cheio).", "error"); }
  renderHistory(); renderDashboard();
}
function formatDate(value) {
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? "Data desconhecida" : date.toLocaleString("pt-BR", { dateStyle: "medium", timeStyle: "short" });
}
function formatSize(bytes) {
  if (!Number.isFinite(Number(bytes))) return "—";
  const value = Number(bytes);
  return value < 1024 * 1024 ? `${(value / 1024).toFixed(0)} KB` : `${(value / (1024 * 1024)).toFixed(2)} MB`;
}
function addHistory(item) {
  const history = getHistory();
  history.unshift(item);
  saveHistory(history);
}
function renderHistory() {
  const target = byId("historyList");
  if (!target) return;
  target.replaceChildren();
  const history = getHistory();
  if (!history.length) { target.innerHTML = '<div class="empty-state">Nenhum build registrado. O histórico começa depois da primeira análise ou compilação.</div>'; }
  history.forEach(item => {
    const row = document.createElement("article"); row.className = "history-row";
    const main = document.createElement("div");
    const title = document.createElement("strong"); title.textContent = item.appName || "Aplicativo";
    const meta = document.createElement("small"); meta.textContent = `${item.packageId || "Sem package ID"} · ${item.versionName || "1.0"} (${item.versionCode || 1}) · ${formatDate(item.date)}`;
    main.append(title, meta);
    const statusWrap = document.createElement("div");
    const unknown = item.status === "Sem confirmação";
    const state = document.createElement("span"); state.className = `history-status ${item.status === "Falhou" ? "failed" : unknown ? "unknown" : ""}`; state.textContent = item.status || "Concluído";
    const size = document.createElement("small"); size.textContent = item.status === "Concluído" ? `Pacote ${formatSize(item.size)}` : (item.error || "Confira o diagnóstico");
    statusWrap.append(state, size);
    const actions = document.createElement("div"); actions.className = "history-actions";
    const reuse = document.createElement("button"); reuse.type = "button"; reuse.className = "mini-button"; reuse.textContent = "Reutilizar config"; reuse.addEventListener("click", () => reuseHistory(item));
    const remove = document.createElement("button"); remove.type = "button"; remove.className = "mini-button delete"; remove.textContent = "Excluir"; remove.setAttribute("aria-label", `Excluir histórico de ${item.appName || "app"}`); remove.addEventListener("click", () => saveHistory(getHistory().filter(entry => entry.id !== item.id)));
    actions.append(reuse, remove); row.append(main, statusWrap, actions); target.append(row);
  });
}
function renderDashboard() {
  const history = getHistory();
  byId("statBuilds").textContent = String(history.length);
  byId("statStorage").textContent = `${(new Blob([JSON.stringify(history)]).size / 1024).toFixed(1)} KB`;
  const success = history.find(item => item.status === "Concluído");
  const last = history[0];
  byId("statLastBuild").textContent = last ? (last.status === "Concluído" ? "OK" : last.status === "Falhou" ? "Falhou" : "?") : "—";
  byId("statLastBuild").classList.toggle("danger-text", last?.status === "Falhou");
  byId("statLastBuildNote").textContent = success ? `${success.appName} · ${formatDate(success.date)}` : (last ? `${last.appName} · último resultado` : "Nenhum build registrado");
  byId("statBuilds").title = "Registros desta aba/navegador; não representa armazenamento no servidor.";
  const list = byId("recentBuilds"); list.replaceChildren();
  if (!history.length) { list.innerHTML = '<div class="empty-state">Ainda não há builds registrados.</div>'; return; }
  history.slice(0, 4).forEach(item => {
    const row = document.createElement("div"); row.className = "recent-row";
    const text = document.createElement("div");
    const name = document.createElement("div"); name.className = "recent-name"; name.textContent = item.appName || "Aplicativo";
    const meta = document.createElement("div"); meta.className = "recent-meta"; meta.textContent = `${item.packageId || ""} · ${formatDate(item.date)}`;
    text.append(name, meta);
    const state = document.createElement("span"); state.className = `recent-status ${item.status === "Falhou" ? "failed" : item.status === "Sem confirmação" ? "unknown" : ""}`; state.textContent = item.status === "Falhou" ? "FALHOU" : item.status === "Concluído" ? "CONCLUÍDO" : "SEM CONFIRMAÇÃO";
    row.append(text, state); list.append(row);
  });
}
function reuseHistory(item) {
  form.elements.appName.value = item.appName || "Meu Aplicativo";
  form.elements.packageId.value = item.packageId || "com.exemplo.meuapp";
  form.elements.versionName.value = item.versionName || "1.0.0";
  form.elements.versionCode.value = String(Math.max(1, Number(item.versionCode) || 1));
  form.elements.minSdk.value = String(item.minSdk || 23);
  form.elements.orientation.value = item.orientation || "portrait";
  form.elements.theme.value = item.theme || "dark";
  form.elements.primaryColor.value = item.primaryColor || "#8b72ff";
  byId("splash") && (byId("splash").checked = Boolean(item.splash));
  form.elements.ads.checked = Boolean(item.ads);
  form.elements.storageAccess.checked = Boolean(item.storageAccess);
  form.querySelectorAll('input[name="permission"]').forEach(input => { input.checked = (item.permissions || []).includes(input.value); });
  byId("trustGradle").checked = false;
  projectInput.value = ""; currentAnalysis = null; updateProjectName();
  setStatus("Configurações preenchidas. Selecione novamente o ZIP do projeto; arquivos e chaves não são mantidos no histórico.", "success");
  showPage("builder");
}

function setStatus(message, kind = "") {
  statusBox.textContent = message;
  statusBox.className = `status-message ${kind}`.trim();
}
function apiBase() {
  const value = byId("serverUrl").value.trim();
  if (!value) throw new Error("Informe a URL do backend em Configurações.");
  const url = new URL(value);
  if (!/^https?:$/.test(url.protocol)) throw new Error("Use uma URL HTTP ou HTTPS.");
  if (url.protocol === "http:" && !isPrivateHost(url.hostname)) throw new Error("HTTP sem criptografia só é permitido para endereço local/privado. Use HTTPS fora da LAN.");
  return trimSlash(url.toString());
}
function isPrivateHost(host) {
  const h = host.toLowerCase().replace(/^\[|\]$/g, "");
  if (["localhost", "127.0.0.1", "::1"].includes(h)) return true;
  const m = h.match(/^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/);
  if (!m || m.slice(1).some(n => Number(n) > 255)) return false;
  const a = Number(m[1]), b = Number(m[2]);
  return a === 10 || (a === 192 && b === 168) || (a === 172 && b >= 16 && b <= 31) || a === 127;
}
function getToken() { return byId("apiToken").value.trim(); }
function rememberSettings() {
  try { localStorage.setItem(API_URL_KEY, byId("serverUrl").value.trim()); } catch {}
  try { sessionStorage.setItem("apkForge.apiToken.session", getToken()); } catch {}
}
function loadSettings() {
  let savedUrl = "";
  try { savedUrl = localStorage.getItem(API_URL_KEY) || ""; } catch {}
  byId("serverUrl").value = savedUrl || ((location.protocol === "http:" || location.protocol === "https:") ? location.origin : "");
  try { byId("apiToken").value = sessionStorage.getItem("apkForge.apiToken.session") || ""; } catch {}
}

function setConnection(connected, message, data = null) {
  const state = connected ? "ok" : "bad";
  byId("sidebarDot").className = `status-dot ${state}`;
  byId("headerDot").className = `status-dot ${state}`;
  byId("sidebarServer").textContent = connected ? "Backend online" : "Backend indisponível";
  byId("headerServer").textContent = connected ? "Online" : "Desconectado";
  byId("sidebarVersion").textContent = connected ? `API ${data?.apiVersion ?? "?"} · autenticação ${data?.authenticationConfigured ? "ativa" : "não configurada"}` : message;
  byId("settingsBadge").className = `badge ${connected ? "success" : "error"}`;
  byId("settingsBadge").textContent = connected ? "ONLINE" : "OFFLINE";
  byId("diagBackendBadge").className = `badge ${connected ? "success" : "error"}`;
  byId("diagBackendBadge").textContent = connected ? "ONLINE" : "OFFLINE";
  byId("diagBackend").textContent = connected ? `${message} · API ${data?.apiVersion ?? "?"} · token ${data?.authenticationConfigured ? "configurado" : "ausente no servidor"}` : message;
  byId("statSdk").textContent = connected ? (data?.androidSdk || "35") : "—";
  byId("statGradle").textContent = connected ? `Gradle ${data?.gradle || "8.9"} · API ${data?.apiVersion ?? "?"}` : "Versões aparecem após conectar";
  byId("diagToolchain").textContent = connected ? `Android SDK ${data?.androidSdk || "35"}\nGradle ${data?.gradle || "8.9"}\nBuild simultâneo: ${data?.maxConcurrentBuilds || 1}` : "Toolchain não consultada porque o backend está offline.";
  byId("connectionMessage").textContent = connected ? `Conexão recebida de ${message}. ${data?.authenticationConfigured ? "Builds exigem um token Bearer válido." : "O token não está configurado no backend; builds retornarão 503."}` : message;
  lastDiagnostic = { connected, message, at: new Date().toISOString(), data };
  updateHeaderFromBuild(data);
}
function updateHeaderFromBuild(data) {
  if (data?.buildInProgress) {
    byId("sidebarDot").className = "status-dot busy";
    byId("headerDot").className = "status-dot busy";
    byId("sidebarServer").textContent = "Build em andamento";
    byId("headerServer").textContent = "Build ativo";
  }
}
async function testConnection(silent = false) {
  rememberSettings();
  let base;
  try { base = apiBase(); }
  catch (error) { setConnection(false, error.message); if (!silent) showPage("settings"); return false; }
  byId("testConnection").disabled = true;
  byId("refreshHealth").disabled = true;
  try {
    const response = await fetch(`${base}/api/health`, { headers: { Accept: "application/json" }, cache: "no-store" });
    const data = await response.json();
    if (!response.ok || !data.ok) throw new Error(data.error || `HTTP ${response.status}`);
    setConnection(true, new URL(base).host, data);
    if (!silent) showPage("settings");
    return true;
  } catch (error) {
    setConnection(false, `Não foi possível consultar ${base}: ${error.message}`);
    if (!silent) showPage("settings");
    return false;
  } finally { byId("testConnection").disabled = false; byId("refreshHealth").disabled = false; }
}

function updateProjectName() {
  const file = projectInput.files[0];
  if (!file) analysisSequence++;
  byId("fileName").textContent = file ? `${file.name} · ${formatSize(file.size)}` : "Nenhum arquivo selecionado";
  byId("analyzeProject").disabled = !file;
  byId("clearProject").hidden = !file;
  if (!file) {
    currentAnalysis = null;
    byId("analysisBadge").className = "badge neutral";
    byId("analysisBadge").textContent = "AGUARDANDO ARQUIVO";
    byId("analysisReport").hidden = true;
    byId("analysisHint").textContent = "A análise identifica HTML, Gradle, manifesto e arquivos encontrados.";
  }
}
function renderAnalysis(result) {
  const report = byId("analysisReport"); report.replaceChildren(); report.hidden = false;
  const summary = document.createElement("div"); summary.className = "analysis-summary";
  const title = document.createElement("strong"); title.textContent = result.kind === "html" ? "Projeto HTML/WebView detectado" : result.kind === "android-gradle" ? "Projeto Android Gradle detectado" : "Estrutura não reconhecida";
  const badge = document.createElement("span"); badge.className = `badge ${result.kind === "unsupported" ? "warning" : "success"}`; badge.textContent = result.kind.toUpperCase();
  summary.append(title, badge); report.append(summary);
  const lines = [
    `${result.fileCount} arquivos · ${formatSize(result.totalBytes)} descompactados`,
    result.indexPath ? `index.html: ${result.indexPath}` : "index.html não encontrado",
    result.indexTitle ? `Título HTML: ${result.indexTitle}` : "Título HTML não detectado",
    result.gradleWrapper ? `Gradle Wrapper: ${result.gradleWrapper}` : "Gradle Wrapper não encontrado",
    result.manifestPackage ? `Package encontrado: ${result.manifestPackage}` : "Package não extraído do manifesto",
  ];
  const ul = document.createElement("ul"); lines.forEach(text => { const li = document.createElement("li"); li.textContent = text; ul.append(li); });
  (result.warnings || []).forEach(text => { const li = document.createElement("li"); li.textContent = text; ul.append(li); });
  report.append(ul);
  const preview = (result.files || []).slice(0, 12);
  if (preview.length) {
    const list = document.createElement("ul"); list.className = "file-preview";
    preview.forEach(file => { const li = document.createElement("li"); li.textContent = `${file.path} · ${formatSize(file.size)}`; list.append(li); });
    report.append(list);
  }
}
async function analyzeProject() {
  const file = projectInput.files[0];
  if (!file) return;
  const sequence = ++analysisSequence;
  let base;
  try { base = apiBase(); } catch (error) { byId("analysisHint").textContent = error.message; return; }
  if (!getToken()) { byId("analysisHint").textContent = "Informe o token do backend em Configurações antes da análise."; showPage("settings"); return; }
  const button = byId("analyzeProject"); button.disabled = true; button.textContent = "Analisando…";
  byId("analysisBadge").className = "badge neutral"; byId("analysisBadge").textContent = "VALIDANDO ZIP";
  byId("analysisHint").textContent = "O ZIP está sendo validado e os caminhos estão sendo inspecionados sem executar scripts.";
  const data = new FormData(); data.append("project", file);
  try {
    const response = await fetch(`${base}/api/analyze`, { method: "POST", headers: { Authorization: `Bearer ${getToken()}` }, body: data });
    const result = await response.json();
    if (sequence !== analysisSequence || projectInput.files[0] !== file) return;
    if (!response.ok) throw new Error(result.error || `HTTP ${response.status}`);
    currentAnalysis = { fileName: file.name, size: file.size, lastModified: file.lastModified, ...result };
    renderAnalysis(result);
    byId("analysisBadge").className = `badge ${result.kind === "unsupported" ? "warning" : "success"}`;
    byId("analysisBadge").textContent = result.kind === "unsupported" ? "REVISAR ESTRUTURA" : "ANÁLISE CONCLUÍDA";
    byId("analysisHint").textContent = result.kind === "unsupported" ? "O ZIP não foi reconhecido como HTML ou Android Gradle compatível." : "Análise concluída sem executar o projeto.";
    if (result.manifestPackage && result.kind === "android-gradle" && /^([A-Za-z][A-Za-z0-9_]*\.)+[A-Za-z][A-Za-z0-9_]*$/.test(result.manifestPackage)) form.elements.packageId.value = result.manifestPackage;
    if (result.indexTitle && result.kind === "html" && form.elements.appName.value.trim() === "Meu Aplicativo") form.elements.appName.value = result.indexTitle.slice(0, 40);
  } catch (error) {
    if (sequence !== analysisSequence || projectInput.files[0] !== file) return;
    currentAnalysis = null;
    byId("analysisBadge").className = "badge error"; byId("analysisBadge").textContent = "ANÁLISE FALHOU";
    byId("analysisHint").textContent = error.message;
    byId("analysisReport").hidden = false; byId("analysisReport").textContent = `O servidor recusou a análise: ${error.message}`;
  } finally { if (sequence === analysisSequence) { button.disabled = false; button.textContent = "Analisar estrutura"; } }
}
projectInput.addEventListener("change", () => { updateProjectName(); if (projectInput.files[0]) analyzeProject(); });
byId("clearProject").addEventListener("click", () => { projectInput.value = ""; updateProjectName(); });
byId("analyzeProject").addEventListener("click", analyzeProject);
iconInput.addEventListener("change", () => { byId("iconName").textContent = iconInput.files[0] ? `${iconInput.files[0].name} · ${formatSize(iconInput.files[0].size)}` : "Ícone padrão do Android"; });
keyInput.addEventListener("change", () => { byId("keyName").textContent = keyInput.files[0] ? `${keyInput.files[0].name} · ${formatSize(keyInput.files[0].size)}` : "Sem arquivo de chave selecionado"; });

const dropZone = byId("dropZone");
["dragenter", "dragover"].forEach(name => dropZone.addEventListener(name, event => { event.preventDefault(); dropZone.classList.add("dragover"); }));
["dragleave", "drop"].forEach(name => dropZone.addEventListener(name, event => { event.preventDefault(); dropZone.classList.remove("dragover"); }));
dropZone.addEventListener("drop", event => {
  const file = [...(event.dataTransfer?.files || [])].find(item => item.name.toLowerCase().endsWith(".zip"));
  if (!file) { byId("analysisHint").textContent = "Solte um arquivo .zip válido."; return; }
  const transfer = new DataTransfer(); transfer.items.add(file); projectInput.files = transfer.files; projectInput.dispatchEvent(new Event("change", { bubbles: true }));
});

function safeFilename(value) { return value.trim().replace(/[^a-z0-9_-]/gi, "_").slice(0, 48) || "app"; }
function validateForm() {
  const appName = form.elements.appName.value.trim();
  const packageId = form.elements.packageId.value.trim();
  const versionName = form.elements.versionName.value.trim();
  const versionCode = Number(form.elements.versionCode.value);
  const minSdk = Number(form.elements.minSdk.value);
  if (!appName || appName.length > 40) throw new Error("Informe um nome de até 40 caracteres.");
  if (!/^([A-Za-z][A-Za-z0-9_]*\.)+[A-Za-z][A-Za-z0-9_]*$/.test(packageId) || packageId.length > 255) throw new Error("Package ID inválido. Use segmentos como com.empresa.aplicativo.");
  if (!/^[A-Za-z0-9._+-]{1,32}$/.test(versionName)) throw new Error("Version Name deve ter até 32 caracteres alfanuméricos, ponto, +, - ou _.");
  if (!Number.isSafeInteger(versionCode) || versionCode < 1 || versionCode > 2147483647) throw new Error("Version Code deve ser um inteiro positivo.");
  if (!Number.isInteger(minSdk) || minSdk < 23 || minSdk > 35) throw new Error("SDK mínimo fora do intervalo suportado (23–35).");
  if (!projectInput.files[0]) throw new Error("Selecione o ZIP do projeto.");
  if (projectInput.files[0].size > 250 * 1024 * 1024) throw new Error("O ZIP excede o limite de 250 MB.");
  if (iconInput.files[0]?.size > 10 * 1024 * 1024) throw new Error("O ícone excede o limite de 10 MB.");
  if (keyInput.files[0]?.size > 10 * 1024 * 1024) throw new Error("A keystore excede o limite de 10 MB.");
  if (currentAnalysis && currentAnalysis.kind === "unsupported") throw new Error("O ZIP analisado não contém index.html nem um Gradle Wrapper reconhecido.");
  if (currentAnalysis?.kind === "android-gradle" && !byId("trustGradle").checked) throw new Error("Confirme que confia nos scripts Gradle deste projeto.");
  if (keyInput.files[0] && (!form.elements.keyAlias.value.trim() || !form.elements.keyStorePassword.value)) throw new Error("Para importar uma keystore, informe alias e senha.");
  return { appName, packageId, versionName, versionCode, minSdk };
}
function updateRecord(item) {
  const history = getHistory(); const index = history.findIndex(row => row.id === item.id);
  if (index >= 0) history[index] = { ...history[index], ...item };
  else history.unshift(item);
  saveHistory(history);
}
function friendlyHttpError(status, message) {
  if (status === 401) return `Token inválido ou ausente. Confira Configurações. ${message}`;
  if (status === 413) return `O servidor recusou um arquivo acima do limite de upload. ${message}`;
  if (status === 429) return `Já existe um build/análise em andamento no servidor. Aguarde e tente novamente. ${message}`;
  if (status === 503) return `O backend não tem token configurado. Configure APK_FORGE_API_TOKEN no servidor. ${message}`;
  return message;
}

form.addEventListener("submit", async event => {
  event.preventDefault();
  if (isBuilding) return;
  let identity;
  try { identity = validateForm(); apiBase(); }
  catch (error) { setStatus(error.message, "error"); return; }
  if (!getToken()) { setStatus("Informe o token Bearer em Configurações.", "error"); showPage("settings"); return; }
  if (!currentAnalysis || currentAnalysis.fileName !== projectInput.files[0].name || currentAnalysis.size !== projectInput.files[0].size || currentAnalysis.lastModified !== projectInput.files[0].lastModified) {
    await analyzeProject();
    if (!currentAnalysis || currentAnalysis.kind === "unsupported") { setStatus("A análise do ZIP precisa ser concluída antes do build.", "error"); return; }
  }
  if (currentAnalysis.kind === "android-gradle" && !byId("trustGradle").checked) { setStatus("Confirme que confia nos scripts Gradle antes de compilar.", "error"); return; }
  if (currentAnalysis.kind === "android-gradle") {
    const proceed = window.confirm("Este ZIP contém projeto Gradle. A compilação executa scripts do projeto no servidor. Continue somente se você confia nesta origem.");
    if (!proceed) return;
  }
  const data = new FormData();
  data.append("project", projectInput.files[0]);
  if (iconInput.files[0]) data.append("icon", iconInput.files[0]);
  if (keyInput.files[0]) data.append("keystore", keyInput.files[0]);
  ["appName", "packageId", "versionName", "versionCode", "minSdk", "orientation", "theme", "author", "description", "primaryColor", "keyAlias", "keyStorePassword", "keyPassword"].forEach(name => data.append(name, form.elements[name].value.trim()));
  data.append("splash", String(form.elements.splash.checked));
  data.append("ads", String(form.elements.ads.checked));
  data.append("storageAccess", String(form.elements.storageAccess.checked));
  const permissions = [...form.querySelectorAll('input[name="permission"]:checked')].map(input => input.value);
  data.append("permissions", JSON.stringify(permissions));
  data.append("trustGradle", String(byId("trustGradle").checked));
  const recordId = (crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random()}`);
  const record = { id: recordId, appName: identity.appName, packageId: identity.packageId, versionName: identity.versionName, versionCode: identity.versionCode, minSdk: identity.minSdk, orientation: form.elements.orientation.value, theme: form.elements.theme.value, primaryColor: form.elements.primaryColor.value, splash: form.elements.splash.checked, ads: form.elements.ads.checked, storageAccess: form.elements.storageAccess.checked, permissions: [...form.querySelectorAll('input[name="permission"]:checked')].map(input => input.value), projectKind: currentAnalysis.kind, date: new Date().toISOString(), status: "Compilando", size: 0 };
  addHistory(record);
  isBuilding = true; buildButton.disabled = true; buildButton.textContent = "Compilando…";
  setStatus("Projeto validado. Enviando ao backend e compilando; mantenha esta página aberta. A senha da keystore não é gravada no histórico.", "");
  logBox.hidden = true; logBox.textContent = "";
  const controller = new AbortController(); const timeout = setTimeout(() => controller.abort(), 16 * 60 * 1000);
  try {
    const base = apiBase();
    const response = await fetch(`${base}/api/build`, { method: "POST", headers: { Authorization: `Bearer ${getToken()}` }, body: data, signal: controller.signal });
    const type = response.headers.get("content-type") || "";
    if (!response.ok) {
      const result = type.includes("json") ? await response.json() : { error: await response.text() };
      const message = friendlyHttpError(response.status, result.error || `HTTP ${response.status}`);
      setStatus(`Falha no build: ${message}`, "error");
      if (result.log) { logBox.textContent = result.log; logBox.hidden = false; lastDiagnostic = { ...(lastDiagnostic || {}), error: message, log: result.log, date: new Date().toISOString() }; }
      updateRecord({ ...record, status: "Falhou", error: message });
      return;
    }
    const blob = await response.blob();
    if (!blob.size) throw new Error("O servidor retornou um arquivo vazio.");
    const url = URL.createObjectURL(blob); const anchor = document.createElement("a");
    const disposition = response.headers.get("content-disposition") || "";
    const encodedName = disposition.match(/filename\*=UTF-8''([^;]+)/i)?.[1];
    const plainName = disposition.match(/filename="?([^";]+)"?/i)?.[1];
    let downloadName = `${safeFilename(identity.appName)}-APK-Forge.zip`;
    try { downloadName = encodedName ? decodeURIComponent(encodedName) : (plainName || downloadName); } catch {}
    anchor.href = url; anchor.download = downloadName;
    document.body.append(anchor); anchor.click(); anchor.remove(); setTimeout(() => URL.revokeObjectURL(url), 60_000);
    updateRecord({ ...record, status: "Concluído", size: blob.size });
    setStatus(`Build concluído. O servidor entregou ${downloadName} (${formatSize(blob.size)}). O pacote inclui o APK assinado e os arquivos de assinatura; guarde-o em local privado.`, "success");
    lastDiagnostic = { ...(lastDiagnostic || {}), lastBuild: "Concluído", date: new Date().toISOString() };
  } catch (error) {
    const message = error.name === "AbortError" ? "A solicitação passou do limite de 16 minutos; verifique o backend e o log do servidor." : error.message;
    setStatus(`Não foi possível concluir o build: ${message}`, "error");
    updateRecord({ ...record, status: "Falhou", error: message });
    lastDiagnostic = { ...(lastDiagnostic || {}), error: message, date: new Date().toISOString() };
  } finally {
    clearTimeout(timeout); isBuilding = false; buildButton.disabled = false; buildButton.textContent = "Construir e assinar APK"; renderDiagnostics();
  }
});

byId("clearHistory").addEventListener("click", () => {
  if (!getHistory().length) return;
  if (window.confirm("Apagar os registros locais deste navegador? Os arquivos baixados não serão excluídos.")) saveHistory([]);
});
byId("testConnection").addEventListener("click", () => testConnection(false));
byId("refreshHealth").addEventListener("click", () => testConnection(true));
byId("runDiagnostics").addEventListener("click", () => testConnection(true));
byId("serverUrl").addEventListener("change", rememberSettings);
byId("apiToken").addEventListener("input", rememberSettings);
function renderDiagnostics() {
  const history = getHistory(); const last = history[0];
  const message = last ? `${last.appName || "Aplicativo"} · ${last.status} · ${formatDate(last.date)}${last.error ? ` · ${last.error}` : ""}` : "Nenhum build nesta sessão.";
  byId("diagLastBuild").textContent = message;
  const log = lastDiagnostic?.log || "";
  byId("diagLog").textContent = log;
  byId("diagLog").hidden = !log;
}
loadSettings(); recoverInterruptedBuilds(); renderDashboard(); renderHistory(); renderDiagnostics();
if (byId("serverUrl").value) testConnection(true);
