#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SDK="${ANDROID_HOME:-$HOME/android-sdk}"
GRADLE_VERSION=8.9
GRADLE_DIR="$HOME/gradle-$GRADLE_VERSION"
CACHE="$HOME/.cache/apk-forge-android-tools"
mkdir -p "$SDK/cmdline-tools" "$CACHE"
JAVAC_BIN="$(command -v javac || true)"
if [[ -z "$JAVAC_BIN" ]]; then echo "Instale JDK 17 ou superior (javac e jlink)." >&2; exit 1; fi
JAVA_HOME="$(dirname "$(dirname "$(readlink -f "$JAVAC_BIN")")")"
if [[ ! -x "$JAVA_HOME/bin/jlink" ]]; then echo "É necessário um JDK completo com jlink: $JAVA_HOME" >&2; exit 1; fi
export JAVA_HOME
export PATH="$JAVA_HOME/bin:$PATH"

if [[ ! -x "$SDK/cmdline-tools/latest/bin/sdkmanager" ]]; then
  curl -fL --retry 3 'https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip' -o "$CACHE/android-commandline-tools.zip"
  unzip -q -o "$CACHE/android-commandline-tools.zip" -d "$SDK/cmdline-tools"
  mv "$SDK/cmdline-tools/cmdline-tools" "$SDK/cmdline-tools/latest"
fi
if [[ ! -x "$GRADLE_DIR/bin/gradle" ]]; then
  curl -fL --retry 3 "https://services.gradle.org/distributions/gradle-${GRADLE_VERSION}-bin.zip" -o "$CACHE/gradle-${GRADLE_VERSION}-bin.zip"
  unzip -q -o "$CACHE/gradle-${GRADLE_VERSION}-bin.zip" -d "$HOME"
fi
export ANDROID_HOME="$SDK"
export ANDROID_SDK_ROOT="$SDK"
export PATH="$GRADLE_DIR/bin:$SDK/cmdline-tools/latest/bin:$SDK/platform-tools:$SDK/build-tools/35.0.0:$PATH"
if [[ "$(uname -m)" == "aarch64" ]] && ! command -v qemu-x86_64-static >/dev/null 2>&1; then
  echo "Este Android SDK usa ferramentas Linux x86-64; em hosts ARM64 instale qemu-user-static e bibliotecas amd64 antes do build." >&2
  exit 1
fi
yes | sdkmanager --licenses >/dev/null || { rc=$?; [[ "$rc" -eq 141 ]] || exit "$rc"; }
sdkmanager 'platform-tools' 'platforms;android-35' 'build-tools;35.0.0'
cd "$ROOT/android-client"
if [[ ! -f gradle/wrapper/gradle-wrapper.jar ]]; then
  "$GRADLE_DIR/bin/gradle" wrapper --gradle-version "$GRADLE_VERSION" --distribution-type bin
fi
./gradlew --no-daemon assembleDebug
printf '\nAPK gerado: %s\n' "$ROOT/android-client/app/build/outputs/apk/debug/app-debug.apk"
