package com.apkforge.client;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import org.json.JSONObject;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.util.Locale;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

public class MainActivity extends Activity {
    private static final int PICK_PROJECT = 101;
    private static final int PICK_ICON = 102;
    private static final int PICK_KEYSTORE = 103;
    private static final int SAVE_EXPORT = 201;
    private static final String PREFS = "apk_forge_settings";
    private static final String KEY_ALIAS = "apk_forge_api_token_key";
    private static final int BG = Color.rgb(11, 16, 32);
    private static final int CARD = Color.rgb(21, 28, 49);
    private static final int PURPLE = Color.rgb(165, 140, 255);
    private static final int WHITE = Color.rgb(237, 241, 255);
    private static final int MUTED = Color.rgb(157, 168, 198);

    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private EditText urlField, tokenField, appNameField, packageField, aliasField, storePasswordField, keyPasswordField;
    private CheckBox trustGradle, splash, ads;
    private TextView projectInfo, iconInfo, keystoreInfo, status, logs;
    private Button buildButton;
    private Uri projectUri, iconUri, keystoreUri;
    private File pendingExport;

    private static final class BuildRequest {
        final String base, token, appName, packageId, alias, storePassword, keyPassword;
        final boolean splash, ads, trustGradle;
        final Uri projectUri, iconUri, keystoreUri;

        BuildRequest(String base, String token, String appName, String packageId,
                     boolean splash, boolean ads, boolean trustGradle, String alias,
                     String storePassword, String keyPassword, Uri projectUri, Uri iconUri, Uri keystoreUri) {
            this.base = base; this.token = token; this.appName = appName; this.packageId = packageId;
            this.splash = splash; this.ads = ads; this.trustGradle = trustGradle;
            this.alias = alias; this.storePassword = storePassword; this.keyPassword = keyPassword;
            this.projectUri = projectUri; this.iconUri = iconUri; this.keystoreUri = keystoreUri;
        }
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().getDecorView().setSystemUiVisibility(0);
        buildUi();
        loadPreferences();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setFitsSystemWindows(true);
        scroll.setBackgroundColor(BG);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(22), dp(18), dp(28));
        scroll.addView(root);

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView mark = text("AF", 19, PURPLE, true);
        mark.setGravity(Gravity.CENTER);
        mark.setBackground(round(PURPLE, 16, PURPLE, 0));
        LinearLayout.LayoutParams markLp = new LinearLayout.LayoutParams(dp(54), dp(54));
        header.addView(mark, markLp);
        LinearLayout titleGroup = new LinearLayout(this);
        titleGroup.setOrientation(LinearLayout.VERTICAL);
        titleGroup.setPadding(dp(12), 0, 0, 0);
        TextView title = text("APK Forge", 25, WHITE, true);
        TextView subtitle = text("Construa e assine APKs", 13, MUTED, false);
        titleGroup.addView(title); titleGroup.addView(subtitle);
        header.addView(titleGroup, new LinearLayout.LayoutParams(0, -2, 1));
        root.addView(header);

        TextView warning = text("O app cliente envia seu projeto ao servidor configurado. Builds Gradle executam código: use apenas ZIPs confiáveis. Para servidores fora da rede privada, configure HTTPS.", 13, Color.rgb(240, 215, 165), false);
        warning.setPadding(dp(14), dp(12), dp(14), dp(12));
        warning.setBackground(round(Color.rgb(36, 29, 19), 12, Color.rgb(102, 81, 45), dp(1)));
        LinearLayout.LayoutParams warningLp = new LinearLayout.LayoutParams(-1, -2);
        warningLp.topMargin = dp(18); warningLp.bottomMargin = dp(5);
        root.addView(warning, warningLp);

        LinearLayout connection = panel(root, "01 / SERVIDOR");
        urlField = field(connection, "URL do backend", "https://seu-servidor ou http://192.168.1.10:3000", android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_URI);
        tokenField = field(connection, "Token de acesso", "Token configurado no servidor", android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);
        button(connection, "Testar conexão", false, this::testConnection);

        LinearLayout projectPanel = panel(root, "02 / PROJETO");
        button(projectPanel, "Selecionar projeto ZIP", false, () -> pickFile(PICK_PROJECT, "application/zip", new String[]{"application/zip", "application/x-zip-compressed", "application/octet-stream"}));
        projectInfo = text("Nenhum arquivo selecionado", 12, MUTED, false);
        addTop(projectPanel, projectInfo, 7);
        trustGradle = check("Confio neste projeto Gradle", "Projetos Android podem executar scripts no servidor. Só marque se conhece a origem.");
        projectPanel.addView(trustGradle);

        LinearLayout identity = panel(root, "03 / IDENTIDADE DO APP");
        appNameField = field(identity, "Nome do aplicativo", "Meu Aplicativo", android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        appNameField.setText("Meu Aplicativo");
        packageField = field(identity, "Identificador do pacote", "com.exemplo.meuapp", android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        packageField.setText("com.exemplo.meuapp");
        button(identity, "Escolher ícone (opcional)", false, () -> pickFile(PICK_ICON, "image/*", new String[]{"image/png", "image/jpeg"}));
        iconInfo = text("Usar ícone padrão se não selecionar", 12, MUTED, false);
        addTop(identity, iconInfo, 6);

        LinearLayout signing = panel(root, "04 / CHAVE DE ASSINATURA");
        TextView keyTip = text("Sem keystore, será criada uma nova e entregue no pacote exportado. Para atualizações futuras, reutilize a mesma chave e o mesmo identificador do app.", 12, MUTED, false);
        signing.addView(keyTip);
        button(signing, "Importar keystore existente (opcional)", false, () -> pickFile(PICK_KEYSTORE, "*/*", new String[]{"application/octet-stream", "application/x-java-keystore"}));
        keystoreInfo = text("Nenhuma keystore importada", 12, MUTED, false);
        addTop(signing, keystoreInfo, 6);
        aliasField = field(signing, "Alias da chave", "Ex.: release", android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        storePasswordField = field(signing, "Senha do keystore", "Não é armazenada no app", android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);
        keyPasswordField = field(signing, "Senha da chave (se diferente)", "Deixe vazio para usar a senha do keystore", android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);

        LinearLayout options = panel(root, "05 / OPÇÕES");
        splash = check("Tela inicial simples", "Tela breve para projetos HTML convertidos.");
        splash.setChecked(true);
        ads = check("Adicionar lembrete de anúncios", "Não instala SDK nem exibe anúncios.");
        options.addView(splash); options.addView(ads);
        buildButton = button(options, "Construir e assinar APK", true, this::startBuild);
        status = text("Pronto. Configure o servidor e escolha um ZIP.", 14, PURPLE, false);
        status.setPadding(0, dp(12), 0, 0);
        options.addView(status);
        logs = text("", 11, MUTED, false);
        logs.setTextIsSelectable(true);
        logs.setPadding(0, dp(8), 0, 0);
        logs.setVisibility(View.GONE);
        options.addView(logs);

        TextView foot = text("APK Forge 2.0 · o build é executado no seu backend", 11, MUTED, false);
        foot.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams footLp = new LinearLayout.LayoutParams(-1, -2);
        footLp.topMargin = dp(20);
        root.addView(foot, footLp);
        setContentView(scroll);
    }

    private LinearLayout panel(LinearLayout parent, String heading) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(17), dp(16), dp(17), dp(17));
        box.setBackground(round(CARD, 18, Color.rgb(40, 51, 79), dp(1)));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(13);
        parent.addView(box, lp);
        TextView title = text(heading, 12, PURPLE, true);
        title.setLetterSpacing(0.08f);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(-1, -2);
        titleLp.bottomMargin = dp(8);
        box.addView(title, titleLp);
        return box;
    }

    private EditText field(LinearLayout parent, String label, String hint, int inputType) {
        TextView labelView = text(label, 13, WHITE, false);
        LinearLayout.LayoutParams labelLp = new LinearLayout.LayoutParams(-1, -2);
        labelLp.topMargin = dp(10);
        parent.addView(labelView, labelLp);
        EditText edit = new EditText(this);
        edit.setSingleLine(true);
        edit.setTextSize(15);
        edit.setTextColor(WHITE);
        edit.setHintTextColor(MUTED);
        edit.setHint(hint);
        edit.setInputType(inputType);
        edit.setPadding(dp(12), dp(9), dp(12), dp(9));
        edit.setBackgroundTintList(ColorStateList.valueOf(Color.rgb(120, 105, 173)));
        parent.addView(edit, new LinearLayout.LayoutParams(-1, -2));
        return edit;
    }

    private CheckBox check(String title, String detail) {
        CheckBox box = new CheckBox(this);
        box.setText(title + "\n" + detail);
        box.setTextColor(WHITE);
        box.setTextSize(13);
        box.setGravity(Gravity.CENTER_VERTICAL);
        box.setButtonTintList(ColorStateList.valueOf(PURPLE));
        box.setPadding(0, dp(7), 0, dp(7));
        return box;
    }

    private Button button(LinearLayout parent, String label, boolean primary, Runnable action) {
        Button b = new Button(this);
        b.setAllCaps(false);
        b.setText(label);
        b.setTextSize(primary ? 16 : 14);
        b.setTypeface(null, Typeface.BOLD);
        b.setTextColor(primary ? Color.rgb(17, 19, 41) : WHITE);
        b.setBackground(round(primary ? PURPLE : Color.rgb(35, 44, 69), 12, primary ? PURPLE : Color.rgb(75, 88, 122), dp(1)));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(10);
        parent.addView(b, lp);
        b.setOnClickListener(v -> action.run());
        return b;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(color);
        if (bold) view.setTypeface(null, Typeface.BOLD);
        return view;
    }

    private void addTop(LinearLayout parent, View child, int margin) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(margin);
        parent.addView(child, lp);
    }

    private GradientDrawable round(int color, int radius, int stroke, int strokeWidth) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        if (strokeWidth > 0) d.setStroke(strokeWidth, stroke);
        return d;
    }

    private int dp(float value) { return (int) (value * getResources().getDisplayMetrics().density + 0.5f); }

    private void pickFile(int request, String type, String[] mimeTypes) {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType(type);
        intent.putExtra(Intent.EXTRA_MIME_TYPES, mimeTypes);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(intent, request);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null) {
            if (requestCode == SAVE_EXPORT) {
                if (pendingExport != null) pendingExport.delete();
                pendingExport = null;
                setStatus("Exportação cancelada; o pacote temporário foi descartado. Gere o build novamente quando quiser.", false);
            }
            return;
        }
        Uri uri = data.getData();
        if (requestCode == PICK_PROJECT) {
            projectUri = uri;
            persistReadPermission(data, uri);
            projectInfo.setText("Selecionado: " + displayName(uri));
        } else if (requestCode == PICK_ICON) {
            iconUri = uri;
            persistReadPermission(data, uri);
            iconInfo.setText("Ícone: " + displayName(uri));
        } else if (requestCode == PICK_KEYSTORE) {
            keystoreUri = uri;
            persistReadPermission(data, uri);
            keystoreInfo.setText("Keystore: " + displayName(uri));
        } else if (requestCode == SAVE_EXPORT && pendingExport != null) {
            Uri destination = uri;
            File source = pendingExport;
            setStatus("Salvando pacote exportado…", false);
            worker.execute(() -> saveExport(source, destination));
        }
    }

    private void persistReadPermission(Intent data, Uri uri) {
        try { getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION); }
        catch (Exception ignored) { }
    }

    private String displayName(Uri uri) {
        if (uri == null) return "arquivo";
        try (Cursor cursor = getContentResolver().query(uri, null, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (index >= 0) return cursor.getString(index);
            }
        } catch (Exception ignored) { }
        return uri.getLastPathSegment() == null ? "arquivo" : uri.getLastPathSegment();
    }

    private void loadPreferences() {
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        urlField.setText(prefs.getString("serverUrl", ""));
        appNameField.setText(prefs.getString("appName", "Meu Aplicativo"));
        packageField.setText(prefs.getString("packageId", "com.exemplo.meuapp"));
        tokenField.setText(decrypt(prefs.getString("apiTokenEnc", "")));
    }

    private void savePreferences() {
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        prefs.edit()
                .putString("serverUrl", urlField.getText().toString().trim())
                .putString("appName", appNameField.getText().toString().trim())
                .putString("packageId", packageField.getText().toString().trim())
                .putString("apiTokenEnc", encrypt(tokenField.getText().toString().trim()))
                .apply();
    }

    private String encrypt(String clear) {
        if (clear == null || clear.isEmpty()) return "";
        try {
            SecretKey key = getOrCreateSecretKey();
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.ENCRYPT_MODE, key);
            byte[] iv = cipher.getIV();
            byte[] encrypted = cipher.doFinal(clear.getBytes(StandardCharsets.UTF_8));
            byte[] combined = new byte[iv.length + encrypted.length];
            System.arraycopy(iv, 0, combined, 0, iv.length);
            System.arraycopy(encrypted, 0, combined, iv.length, encrypted.length);
            return Base64.encodeToString(combined, Base64.NO_WRAP);
        } catch (Exception e) { return ""; }
    }

    private String decrypt(String encoded) {
        if (encoded == null || encoded.isEmpty()) return "";
        try {
            byte[] combined = Base64.decode(encoded, Base64.NO_WRAP);
            if (combined.length <= 12) return "";
            byte[] iv = new byte[12];
            byte[] encrypted = new byte[combined.length - 12];
            System.arraycopy(combined, 0, iv, 0, 12);
            System.arraycopy(combined, 12, encrypted, 0, encrypted.length);
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.DECRYPT_MODE, getOrCreateSecretKey(), new GCMParameterSpec(128, iv));
            return new String(cipher.doFinal(encrypted), StandardCharsets.UTF_8);
        } catch (Exception e) {
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().remove("apiTokenEnc").apply();
            return "";
        }
    }

    private SecretKey getOrCreateSecretKey() throws Exception {
        KeyStore keyStore = KeyStore.getInstance("AndroidKeyStore");
        keyStore.load(null);
        if (keyStore.containsAlias(KEY_ALIAS)) return (SecretKey) keyStore.getKey(KEY_ALIAS, null);
        KeyGenerator generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        generator.init(new KeyGenParameterSpec.Builder(KEY_ALIAS, KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true)
                .build());
        return generator.generateKey();
    }

    private boolean validEndpoint(String raw, boolean showError) {
        try {
            URL url = new URL(raw);
            if (!("https".equalsIgnoreCase(url.getProtocol()) || "http".equalsIgnoreCase(url.getProtocol()))) throw new IllegalArgumentException("Use uma URL HTTP ou HTTPS.");
            if (url.getUserInfo() != null || url.getHost().isEmpty()) throw new IllegalArgumentException("URL inválida.");
            if ("http".equalsIgnoreCase(url.getProtocol()) && !isPrivateHost(url.getHost())) throw new IllegalArgumentException("HTTP sem criptografia só é aceito em localhost ou IP de rede privada. Use HTTPS fora da rede local.");
            return true;
        } catch (Exception e) {
            if (showError) setStatus("URL inválida: " + e.getMessage(), false);
            return false;
        }
    }

    private boolean isPrivateHost(String host) {
        String h = host.toLowerCase(Locale.ROOT).replace("[", "").replace("]", "");
        if (h.equals("localhost") || h.equals("::1") || h.equals("10.0.2.2")) return true;
        String[] p = h.split("\\.");
        if (p.length != 4) return false;
        try {
            int a = Integer.parseInt(p[0]), b = Integer.parseInt(p[1]);
            for (String part : p) { int n = Integer.parseInt(part); if (n < 0 || n > 255) return false; }
            return a == 10 || (a == 192 && b == 168) || (a == 172 && b >= 16 && b <= 31) || a == 127;
        } catch (NumberFormatException e) { return false; }
    }

    private String baseUrl() { return urlField.getText().toString().trim().replaceAll("/+$", ""); }

    private void testConnection() {
        String base = baseUrl();
        if (!validEndpoint(base, true)) return;
        setStatus("Testando conexão…", false);
        worker.execute(() -> {
            HttpURLConnection connection = null;
            try {
                connection = (HttpURLConnection) new URL(base + "/api/health").openConnection();
                connection.setConnectTimeout(10000);
                connection.setReadTimeout(10000);
                connection.setRequestMethod("GET");
                int code = connection.getResponseCode();
                InputStream stream = code < 400 ? connection.getInputStream() : connection.getErrorStream();
                String response = readString(stream);
                JSONObject json = new JSONObject(response);
                boolean configured = json.optBoolean("authenticationConfigured", true);
                String message = code == 200 && json.optBoolean("ok") && configured
                        ? "Servidor acessível e token de backend configurado."
                        : code == 200 && json.optBoolean("ok") ? "Servidor acessível, mas o token APK_FORGE_API_TOKEN não foi configurado nele."
                        : "Servidor respondeu HTTP " + code + ".";
                setStatus(message, code == 200 && configured);
            } catch (Exception e) { setStatus("Não foi possível conectar: " + shortMessage(e), false); }
            finally { if (connection != null) connection.disconnect(); }
        });
    }

    private void startBuild() {
        if (projectUri == null) { setStatus("Selecione o ZIP do projeto primeiro.", false); return; }
        String base = baseUrl();
        if (!validEndpoint(base, true)) return;
        if (tokenField.getText().toString().trim().isEmpty()) { setStatus("Informe o token configurado no backend.", false); return; }
        if (appNameField.getText().toString().trim().isEmpty()) { setStatus("Informe o nome do aplicativo.", false); return; }
        if (keystoreUri != null && (aliasField.getText().toString().trim().isEmpty() || storePasswordField.getText().toString().isEmpty())) {
            setStatus("Para importar keystore, informe alias e senha do keystore.", false); return;
        }
        savePreferences();
        BuildRequest request = new BuildRequest(base, tokenField.getText().toString().trim(),
                appNameField.getText().toString().trim(), packageField.getText().toString().trim(),
                splash.isChecked(), ads.isChecked(), trustGradle.isChecked(), aliasField.getText().toString().trim(),
                storePasswordField.getText().toString(), keyPasswordField.getText().toString(),
                projectUri, iconUri, keystoreUri);
        logs.setVisibility(View.GONE);
        logs.setText("");
        buildButton.setEnabled(false);
        setStatus("Enviando arquivos e compilando. Mantenha o app aberto; o primeiro build pode levar vários minutos.", false);
        View focus = getCurrentFocus();
        if (focus != null) ((InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(focus.getWindowToken(), 0);
        worker.execute(() -> performBuild(request));
    }

    private void performBuild(BuildRequest request) {
        HttpURLConnection connection = null;
        try {
            String boundary = "----APKForge" + UUID.randomUUID().toString().replace("-", "");
            connection = (HttpURLConnection) new URL(request.base + "/api/build").openConnection();
            connection.setRequestMethod("POST");
            connection.setConnectTimeout(20000);
            connection.setReadTimeout(16 * 60 * 1000);
            connection.setDoOutput(true);
            connection.setChunkedStreamingMode(64 * 1024);
            connection.setRequestProperty("Authorization", "Bearer " + request.token);
            connection.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + boundary);
            connection.setRequestProperty("Accept", "application/zip, application/json");
            try (OutputStream raw = new BufferedOutputStream(connection.getOutputStream())) {
                writeText(raw, boundary, "appName", request.appName);
                writeText(raw, boundary, "packageId", request.packageId);
                writeText(raw, boundary, "splash", String.valueOf(request.splash));
                writeText(raw, boundary, "ads", String.valueOf(request.ads));
                writeText(raw, boundary, "trustGradle", String.valueOf(request.trustGradle));
                writeText(raw, boundary, "keyAlias", request.alias);
                writeText(raw, boundary, "keyStorePassword", request.storePassword);
                writeText(raw, boundary, "keyPassword", request.keyPassword);
                writeFile(raw, boundary, "project", request.projectUri, "application/zip");
                if (request.iconUri != null) writeFile(raw, boundary, "icon", request.iconUri, mimeFor(request.iconUri, "image/png"));
                if (request.keystoreUri != null) writeFile(raw, boundary, "keystore", request.keystoreUri, "application/octet-stream");
                writeBytes(raw, "--" + boundary + "--\r\n");
            }
            int code = connection.getResponseCode();
            String contentType = connection.getContentType() == null ? "" : connection.getContentType().toLowerCase(Locale.ROOT);
            InputStream response = code < 400 ? connection.getInputStream() : connection.getErrorStream();
            if (code < 200 || code >= 300 || contentType.contains("json")) {
                String body = readString(response);
                JSONObject json;
                try { json = new JSONObject(body); } catch (Exception ignored) { json = new JSONObject().put("error", body); }
                String error = json.optString("error", "Falha no servidor (HTTP " + code + ")");
                String buildLog = json.optString("log", "");
                runOnUiThread(() -> {
                    setStatus(error, false);
                    if (!buildLog.isEmpty()) { logs.setText(buildLog); logs.setVisibility(View.VISIBLE); }
                    buildButton.setEnabled(true);
                });
                return;
            }
            if (!contentType.contains("zip") && !contentType.contains("octet-stream")) throw new Exception("Resposta inesperada do servidor: " + contentType);
            File result = File.createTempFile("apkforge-export-", ".zip", getCacheDir());
            try (InputStream in = new BufferedInputStream(response); FileOutputStream out = new FileOutputStream(result)) {
                byte[] buffer = new byte[64 * 1024];
                int n;
                while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
            }
            if (result.length() == 0) { result.delete(); throw new Exception("O servidor retornou um pacote vazio."); }
            pendingExport = result;
            runOnUiThread(() -> {
                buildButton.setEnabled(true);
                setStatus("Build concluído e assinatura verificada. Escolha onde salvar o pacote APK + keystore.", true);
                Intent save = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                save.addCategory(Intent.CATEGORY_OPENABLE);
                save.setType("application/zip");
                save.putExtra(Intent.EXTRA_TITLE, safeFileName(request.appName) + "-APK-Forge.zip");
                startActivityForResult(save, SAVE_EXPORT);
            });
        } catch (Exception e) {
            String message = "Build não concluído: " + shortMessage(e);
            runOnUiThread(() -> { setStatus(message, false); buildButton.setEnabled(true); });
        } finally {
            if (connection != null) connection.disconnect();
        }
    }

    private void writeText(OutputStream out, String boundary, String name, String value) throws Exception {
        writeBytes(out, "--" + boundary + "\r\nContent-Disposition: form-data; name=\"" + name + "\"\r\n\r\n");
        writeBytes(out, value + "\r\n");
    }

    private void writeFile(OutputStream out, String boundary, String field, Uri uri, String mime) throws Exception {
        String name = displayName(uri).replace("\r", "_").replace("\n", "_").replace("\"", "_");
        writeBytes(out, "--" + boundary + "\r\nContent-Disposition: form-data; name=\"" + field + "\"; filename=\"" + name + "\"\r\nContent-Type: " + mime + "\r\n\r\n");
        try (InputStream in = getContentResolver().openInputStream(uri)) {
            if (in == null) throw new Exception("Não foi possível ler " + name);
            byte[] buffer = new byte[32 * 1024];
            int n;
            while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
        }
        writeBytes(out, "\r\n");
    }

    private void writeBytes(OutputStream out, String value) throws Exception { out.write(value.getBytes(StandardCharsets.UTF_8)); }

    private String mimeFor(Uri uri, String fallback) {
        String type = getContentResolver().getType(uri);
        return type == null ? fallback : type;
    }

    private String readString(InputStream stream) throws Exception {
        if (stream == null) return "";
        try (InputStream in = stream; ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[8192];
            int n;
            while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
            return out.toString("UTF-8");
        }
    }

    private void saveExport(File source, Uri destination) {
        try (InputStream in = new BufferedInputStream(new java.io.FileInputStream(source));
             OutputStream out = getContentResolver().openOutputStream(destination, "w")) {
            if (out == null) throw new Exception("Não foi possível gravar no destino selecionado.");
            byte[] buffer = new byte[64 * 1024];
            int n;
            while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
            out.flush();
            runOnUiThread(() -> setStatus("Pacote salvo. Extraia o ZIP: ele contém o APK assinado e os dados da chave.", true));
            source.delete();
        } catch (Exception e) {
            source.delete();
            runOnUiThread(() -> setStatus("Falha ao salvar: " + shortMessage(e), false));
        } finally {
            runOnUiThread(() -> pendingExport = null);
        }
    }

    private String safeFileName(String value) {
        String safe = value.trim().replaceAll("[^A-Za-z0-9._-]", "_");
        return safe.isEmpty() ? "app" : safe.substring(0, Math.min(safe.length(), 40));
    }

    private String shortMessage(Exception e) {
        String message = e.getMessage();
        if (message == null || message.trim().isEmpty()) return e.getClass().getSimpleName();
        return message.length() > 220 ? message.substring(0, 220) : message;
    }

    private void setStatus(String message, boolean good) {
        runOnUiThread(() -> {
            status.setText(message);
            status.setTextColor(good ? Color.rgb(143, 225, 176) : PURPLE);
        });
    }

    @Override protected void onDestroy() {
        worker.shutdown();
        super.onDestroy();
    }
}
