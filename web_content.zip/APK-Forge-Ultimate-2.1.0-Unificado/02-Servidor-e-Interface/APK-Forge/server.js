const express = require("express");
const multer = require("multer");
const AdmZip = require("adm-zip");
const helmet = require("helmet");
const fs = require("fs");
const path = require("path");
const os = require("os");
const crypto = require("crypto");
const { spawn } = require("child_process");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const WORK = process.env.APK_FORGE_WORK || path.join(os.tmpdir(), "apk-forge-jobs");
const API_TOKEN = process.env.APK_FORGE_API_TOKEN || "";
const MAX_BUILD_MS = Math.max(60_000, Number(process.env.APK_FORGE_BUILD_TIMEOUT_MS || 15 * 60_000));
const MAX_LOG_BYTES = 1024 * 1024;
fs.mkdirSync(path.join(WORK, "uploads"), { recursive: true, mode: 0o700 });
app.disable("x-powered-by");
app.use(helmet());
app.use(express.static(path.join(__dirname, "public"), { maxAge: "1h" }));

const upload = multer({
  dest: path.join(WORK, "uploads"),
  limits: { fileSize: 250 * 1024 * 1024, files: 3, fields: 16, fieldSize: 16 * 1024 },
});
const safeName = s => String(s || "app").normalize("NFKD").replace(/[^a-zA-Z0-9._-]/g, "_").slice(0, 64) || "app";
const validPackage = s => typeof s === "string" && s.length <= 255 &&
  s.split(".").length >= 2 && s.split(".").length <= 6 &&
  s.split(".").every(part => /^[A-Za-z][A-Za-z0-9_]{0,62}$/.test(part));
const xmlEscape = s => String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;");
const HTML_WRAPPER_PERMISSIONS = new Set(["CAMERA", "RECORD_AUDIO", "LOCATION", "VIBRATE"]);
let activeBuilds = 0;
let activeAnalyses = 0;

function constantTimeTokenMatch(candidate, expected) {
  if (!candidate || !expected) return false;
  const a = Buffer.from(String(candidate));
  const b = Buffer.from(String(expected));
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}
function requireToken(req, res, next) {
  if (!API_TOKEN) return res.status(503).json({ error: "O backend não foi configurado. Defina APK_FORGE_API_TOKEN no servidor." });
  const auth = req.get("authorization") || "";
  const candidate = auth.startsWith("Bearer ") ? auth.slice(7) : "";
  if (!constantTimeTokenMatch(candidate, API_TOKEN)) return res.status(401).json({ error: "Token de acesso ausente ou inválido." });
  next();
}
function safeExtract(zipPath, destination) {
  const zip = new AdmZip(zipPath);
  const entries = zip.getEntries();
  if (!entries.length || entries.length > 5000) throw new Error("O ZIP está vazio ou contém mais de 5.000 arquivos.");
  let total = 0;
  const seen = new Set();
  const root = path.resolve(destination);
  for (const entry of entries) {
    const name = entry.entryName.replace(/\\/g, "/");
    if (!name || name.includes("\0") || name.startsWith("/") || /^[A-Za-z]:/.test(name) || name.split("/").includes("..")) {
      throw new Error("ZIP contém um caminho inseguro.");
    }
    const normalized = name.replace(/\/+$/, "");
    if (seen.has(normalized)) throw new Error("O ZIP contém nomes duplicados.");
    seen.add(normalized);
    const type = (entry.header.attr >>> 16) & 0o170000;
    if (type === 0o120000) throw new Error("O ZIP contém link simbólico, que não é aceito.");
    const size = Number(entry.header.size || 0);
    if (!Number.isFinite(size) || size < 0 || size > 250 * 1024 * 1024) throw new Error("Um arquivo do ZIP excede o limite de 250 MB.");
    total += size;
    if (total > 500 * 1024 * 1024) throw new Error("O conteúdo descompactado excede o limite de 500 MB.");
    const target = path.resolve(root, name);
    if (target !== root && !target.startsWith(root + path.sep)) throw new Error("Caminho inválido no ZIP.");
  }
  zip.extractAllTo(destination, true);
}
function findFile(dir, filename, depth = 0) {
  if (!fs.existsSync(dir) || depth > 8) return null;
  for (const item of fs.readdirSync(dir, { withFileTypes: true })) {
    if (["node_modules", ".git", ".gradle", "build"].includes(item.name)) continue;
    const full = path.join(dir, item.name);
    if (item.isFile() && item.name === filename) return full;
    if (item.isDirectory()) {
      const found = findFile(full, filename, depth + 1);
      if (found) return found;
    }
  }
  return null;
}
function findApk(dir) {
  const found = [];
  function walk(current, depth) {
    if (depth > 10 || !fs.existsSync(current)) return;
    for (const item of fs.readdirSync(current, { withFileTypes: true })) {
      const full = path.join(current, item.name);
      if (item.isDirectory()) walk(full, depth + 1);
      else if (item.isFile() && item.name.toLowerCase().endsWith(".apk") && /debug|unsigned/i.test(item.name)) found.push(full);
    }
  }
  walk(dir, 0);
  return found.find(p => path.basename(p) === "app-debug.apk") || found[0] || null;
}
function iconExtension(filePath) {
  if (!filePath) return null;
  const fd = fs.openSync(filePath, "r");
  const signature = Buffer.alloc(8);
  try { fs.readSync(fd, signature, 0, 8, 0); } finally { fs.closeSync(fd); }
  if (signature.equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) return ".png";
  if (signature[0] === 0xff && signature[1] === 0xd8 && signature[2] === 0xff) return ".jpg";
  throw new Error("Ícone inválido. Envie uma imagem PNG ou JPEG real.");
}
function makeLogger(filePath) {
  let written = 0;
  return text => {
    if (written >= MAX_LOG_BYTES) return;
    const buf = Buffer.from(String(text));
    const chunk = buf.subarray(0, MAX_LOG_BYTES - written);
    try { fs.appendFileSync(filePath, chunk); written += chunk.length; } catch {}
  };
}
function sanitizedBuildEnv(extra = {}) {
  const env = { ...process.env };
  for (const key of Object.keys(env)) {
    if (/TOKEN|SECRET|PASSWORD|CREDENTIAL|OPENAI_API_KEY|AWS_/i.test(key)) delete env[key];
  }
  return Object.assign(env, extra);
}
function run(command, args, cwd, log, options = {}) {
  return new Promise((resolve, reject) => {
    const isWindows = process.platform === "win32";
    const child = spawn(command, args, { cwd, shell: false, env: options.env || sanitizedBuildEnv(), detached: !isWindows, stdio: ["ignore", "pipe", "pipe"] });
    let finished = false;
    const timer = setTimeout(() => {
      if (finished) return;
      try { if (!isWindows && child.pid) process.kill(-child.pid, "SIGTERM"); else child.kill("SIGTERM"); } catch {}
      setTimeout(() => { try { if (!isWindows && child.pid) process.kill(-child.pid, "SIGKILL"); else child.kill("SIGKILL"); } catch {} }, 3000).unref();
      finished = true;
      reject(new Error(`O comando excedeu o limite de ${Math.round(MAX_BUILD_MS / 60000)} minutos.`));
    }, MAX_BUILD_MS);
    timer.unref();
    child.stdout.on("data", d => log(d.toString()));
    child.stderr.on("data", d => log(d.toString()));
    child.on("error", e => { if (finished) return; finished = true; clearTimeout(timer); reject(e); });
    child.on("close", code => {
      if (finished) return;
      finished = true;
      clearTimeout(timer);
      code === 0 ? resolve() : reject(new Error(`${path.basename(command)} terminou com código ${code}.`));
    });
  });
}
function javaSource(packageId, appName, opts) {
  const selected = new Set(opts.permissions || []);
  const runtime = [];
  if (selected.has("CAMERA")) runtime.push("Manifest.permission.CAMERA");
  if (selected.has("RECORD_AUDIO")) runtime.push("Manifest.permission.RECORD_AUDIO");
  if (selected.has("LOCATION")) runtime.push("Manifest.permission.ACCESS_COARSE_LOCATION", "Manifest.permission.ACCESS_FINE_LOCATION");
  const runtimeArray = runtime.length ? `new String[] { ${runtime.join(", ")} }` : "new String[0]";
  return `package ${packageId};
import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.webkit.GeolocationPermissions;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebView;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebViewClient;
import android.widget.TextView;
import android.view.Gravity;
import java.util.ArrayList;
import java.util.List;
import java.util.Arrays;
public class MainActivity extends Activity {
 private static final int FILE_REQUEST = 601;
 private static final int WEB_PERMISSION_REQUEST = 602;
 private static final int GEO_PERMISSION_REQUEST = 603;
 private static final boolean ALLOW_CAMERA = ${selected.has("CAMERA")};
 private static final boolean ALLOW_MICROPHONE = ${selected.has("RECORD_AUDIO")};
 private static final boolean ALLOW_LOCATION = ${selected.has("LOCATION")};
 private static final boolean ALLOW_STORAGE_ACCESS = ${Boolean(opts.storageAccess)};
 private static final String[] DECLARED_RUNTIME_PERMISSIONS = ${runtimeArray};
 private ValueCallback<Uri[]> pendingFileCallback;
 private PermissionRequest pendingMediaRequest;
 private String[] pendingMediaResources;
 private GeolocationPermissions.Callback pendingGeoCallback;
 private String pendingGeoOrigin;
 @Override public void onCreate(Bundle b) {
  super.onCreate(b);
  ${opts.splash ? `TextView loading = new TextView(this);
  loading.setText(${JSON.stringify(appName)} + "\\nCarregando...");
  loading.setTextColor(0xFFFFFFFF); loading.setBackgroundColor(android.graphics.Color.parseColor(${JSON.stringify(opts.primaryColor)}));
  loading.setGravity(Gravity.CENTER); loading.setTextSize(22); setContentView(loading);` : ""}
  WebView web = new WebView(this);
  web.setWebViewClient(new WebViewClient() {
   @Override public void onPageFinished(WebView view, String url) { ${opts.splash ? "setContentView(view);" : ""} }
   @Override public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
    if (request.isForMainFrame()) view.loadDataWithBaseURL("file:///android_asset/", "<html><meta name='viewport' content='width=device-width'><body style='font:16px sans-serif;background:#0b0d18;color:#eef0ff;padding:28px'><h2>Não foi possível abrir o aplicativo</h2><p>Verifique os arquivos do projeto e tente compilar novamente.</p></body></html>", "text/html", "UTF-8", null);
   }
  });
  web.setWebChromeClient(new WebChromeClient() {
   @Override public void onPermissionRequest(PermissionRequest request) {
    runOnUiThread(() -> handleMediaPermission(request));
   }
   @Override public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
    runOnUiThread(() -> handleGeolocation(origin, callback));
   }
   @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
    if (pendingFileCallback != null) pendingFileCallback.onReceiveValue(null);
    pendingFileCallback = callback;
    try { startActivityForResult(params.createIntent(), FILE_REQUEST); return true; }
    catch (Exception e) { pendingFileCallback = null; callback.onReceiveValue(null); return false; }
   }
  });
  web.getSettings().setJavaScriptEnabled(true);
  web.getSettings().setDomStorageEnabled(true);
  web.getSettings().setAllowFileAccess(true);
  web.getSettings().setAllowContentAccess(true);
  web.getSettings().setGeolocationEnabled(true);
  web.loadUrl("file:///android_asset/index.html");
  ${opts.splash ? "" : "setContentView(web);"}
  requestStorageAccessIfSelected();
 }
 private boolean granted(String permission) {
  return Build.VERSION.SDK_INT < 23 || checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED;
 }
 private boolean includes(String[] values, String value) {
  for (String item : values) if (value.equals(item)) return true;
  return false;
 }
 private void handleMediaPermission(PermissionRequest request) {
  List<String> acceptedResources = new ArrayList<>();
  List<String> needed = new ArrayList<>();
  for (String resource : request.getResources()) {
   if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(resource) && ALLOW_CAMERA) {
    acceptedResources.add(resource); if (!granted(Manifest.permission.CAMERA)) needed.add(Manifest.permission.CAMERA);
   } else if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(resource) && ALLOW_MICROPHONE) {
    acceptedResources.add(resource); if (!granted(Manifest.permission.RECORD_AUDIO)) needed.add(Manifest.permission.RECORD_AUDIO);
   }
  }
  if (acceptedResources.isEmpty()) { request.deny(); return; }
  String[] resources = acceptedResources.toArray(new String[0]);
  if (needed.isEmpty()) { request.grant(resources); return; }
  String[] androidPermissions = needed.toArray(new String[0]);
  new AlertDialog.Builder(this).setTitle("Permissão necessária")
   .setMessage("A página solicita câmera ou microfone. O Android exibirá a autorização do sistema; você pode negar e continuar sem esse recurso.")
   .setNegativeButton("Agora não", (dialog, which) -> request.deny())
   .setPositiveButton("Continuar", (dialog, which) -> {
    pendingMediaRequest = request; pendingMediaResources = resources;
    requestPermissions(androidPermissions, WEB_PERMISSION_REQUEST);
   }).show();
 }
 private boolean hasLocation() {
  return granted(Manifest.permission.ACCESS_FINE_LOCATION) || granted(Manifest.permission.ACCESS_COARSE_LOCATION);
 }
 private void handleGeolocation(String origin, GeolocationPermissions.Callback callback) {
  if (!ALLOW_LOCATION) { callback.invoke(origin, false, false); return; }
  if (hasLocation()) { callback.invoke(origin, true, false); return; }
  new AlertDialog.Builder(this).setTitle("Permitir localização?")
   .setMessage("A página solicita sua localização. O Android pedirá autorização; você pode cancelar.")
   .setNegativeButton("Agora não", (dialog, which) -> callback.invoke(origin, false, false))
   .setPositiveButton("Continuar", (dialog, which) -> {
    pendingGeoCallback = callback; pendingGeoOrigin = origin;
    requestPermissions(new String[] { Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION }, GEO_PERMISSION_REQUEST);
   }).show();
 }
 @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
  super.onRequestPermissionsResult(requestCode, permissions, grantResults);
  if (requestCode == WEB_PERMISSION_REQUEST && pendingMediaRequest != null) {
   List<String> allowed = new ArrayList<>();
   if (includes(pendingMediaResources, PermissionRequest.RESOURCE_VIDEO_CAPTURE) && granted(Manifest.permission.CAMERA)) allowed.add(PermissionRequest.RESOURCE_VIDEO_CAPTURE);
   if (includes(pendingMediaResources, PermissionRequest.RESOURCE_AUDIO_CAPTURE) && granted(Manifest.permission.RECORD_AUDIO)) allowed.add(PermissionRequest.RESOURCE_AUDIO_CAPTURE);
   if (allowed.isEmpty()) pendingMediaRequest.deny(); else pendingMediaRequest.grant(allowed.toArray(new String[0]));
   pendingMediaRequest = null; pendingMediaResources = null;
  } else if (requestCode == GEO_PERMISSION_REQUEST && pendingGeoCallback != null) {
   boolean allowed = hasLocation(); pendingGeoCallback.invoke(pendingGeoOrigin, allowed, false);
   pendingGeoCallback = null; pendingGeoOrigin = null;
  }
 }
 @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
  super.onActivityResult(requestCode, resultCode, data);
  if (requestCode == FILE_REQUEST && pendingFileCallback != null) {
   pendingFileCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data));
   pendingFileCallback = null;
  }
 }
 private void requestStorageAccessIfSelected() {
  if (ALLOW_STORAGE_ACCESS && Build.VERSION.SDK_INT >= 30 && !Environment.isExternalStorageManager()) {
   new AlertDialog.Builder(this).setTitle("Acesso a arquivos")
    .setMessage("Este aplicativo selecionou acesso amplo aos arquivos. Isso só é necessário para apps que precisam operar diretamente sobre muitos arquivos. Você pode cancelar; para continuar, o Android abrirá Configurações e exigirá sua autorização explícita.")
    .setNegativeButton("Agora não", (dialog, which) -> dialog.dismiss())
    .setPositiveButton("Abrir Configurações", (dialog, which) -> {
     try { startActivity(new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:" + getPackageName()))); }
     catch (Exception e) { try { startActivity(new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)); } catch (Exception ignored) {} }
    }).show();
  }
 }
 @Override protected void onDestroy() {
  if (pendingFileCallback != null) pendingFileCallback.onReceiveValue(null);
  if (pendingMediaRequest != null) pendingMediaRequest.deny();
  super.onDestroy();
 }
}`;
}
function createHtmlAndroidProject(sourceDir, projectDir, opts) {
  const index = findFile(sourceDir, "index.html");
  if (!index) throw new Error("Não encontrei index.html no ZIP. Para um projeto HTML, inclua esse arquivo.");
  const assets = path.join(projectDir, "app/src/main/assets");
  const javaDir = path.join(projectDir, "app/src/main/java", ...opts.packageId.split("."));
  fs.mkdirSync(assets, { recursive: true });
  fs.mkdirSync(javaDir, { recursive: true });
  fs.cpSync(path.dirname(index), assets, { recursive: true });
  const iconAttr = opts.iconPath ? ' android:icon="@drawable/forge_icon"' : "";
  const appGradle = `plugins { id 'com.android.application' }
android {
    namespace '${opts.packageId}'
    compileSdk 35
    defaultConfig {
        applicationId '${opts.packageId}'
        minSdk ${opts.minSdk}
        targetSdk 35
        versionCode ${opts.versionCode}
        versionName '${opts.versionName}'
    }
}
`;
  fs.writeFileSync(path.join(projectDir, "settings.gradle"), "pluginManagement { repositories { google(); mavenCentral(); gradlePluginPortal() } }\ndependencyResolutionManagement { repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS); repositories { google(); mavenCentral() } }\nrootProject.name = 'ApkForgeBuild'\ninclude ':app'\n");
  fs.writeFileSync(path.join(projectDir, "build.gradle"), "plugins { id 'com.android.application' version '8.7.3' apply false }\n");
  fs.writeFileSync(path.join(projectDir, "gradle.properties"), "org.gradle.jvmargs=-Xmx1g -Dfile.encoding=UTF-8\norg.gradle.daemon=false\nandroid.useAndroidX=true\n");
  fs.mkdirSync(path.join(projectDir, "app"), { recursive: true });
  fs.writeFileSync(path.join(projectDir, "app/build.gradle"), appGradle);
  const permissionMap = {
    CAMERA: ["android.permission.CAMERA"],
    RECORD_AUDIO: ["android.permission.RECORD_AUDIO"],
    LOCATION: ["android.permission.ACCESS_COARSE_LOCATION", "android.permission.ACCESS_FINE_LOCATION"],
    VIBRATE: ["android.permission.VIBRATE"],
  };
  const declarations = new Set(["android.permission.INTERNET"]);
  for (const item of opts.permissions) for (const permission of (permissionMap[item] || [])) declarations.add(permission);
  if (opts.storageAccess) declarations.add("android.permission.MANAGE_EXTERNAL_STORAGE");
  const permissionTags = [...declarations].map(permission => `<uses-permission android:name="${permission}"/>`).join("");
  const theme = opts.theme === "light" ? "@android:style/Theme.Material.Light.NoActionBar" : "@android:style/Theme.Material.NoActionBar";
  const metadata = `<meta-data android:name="apkforge.author" android:value="${xmlEscape(opts.author)}"/><meta-data android:name="apkforge.description" android:value="${xmlEscape(opts.description)}"/>`;
  fs.writeFileSync(path.join(projectDir, "app/src/main/AndroidManifest.xml"),
    `<manifest xmlns:android="http://schemas.android.com/apk/res/android">${permissionTags}<application android:theme="${theme}" android:label="${xmlEscape(opts.appName)}" android:usesCleartextTraffic="false"${iconAttr}>${metadata}<activity android:name=".MainActivity" android:exported="true" android:screenOrientation="${opts.orientation}" android:windowSoftInputMode="adjustResize"><intent-filter><action android:name="android.intent.action.MAIN"/><category android:name="android.intent.category.LAUNCHER"/></intent-filter></activity></application></manifest>`);
  fs.writeFileSync(path.join(javaDir, "MainActivity.java"), javaSource(opts.packageId, opts.appName, opts));
  if (opts.iconPath && fs.existsSync(opts.iconPath)) {
    const res = path.join(projectDir, "app/src/main/res/drawable-nodpi");
    fs.mkdirSync(res, { recursive: true });
    fs.copyFileSync(opts.iconPath, path.join(res, `forge_icon${opts.iconExt}`));
  }
  if (opts.ads) fs.writeFileSync(path.join(assets, "APK_FORGE_ADS.txt"),
    "Integração de anúncios solicitada. Nenhum SDK ou anúncio foi incluído. Antes de publicar, use um provedor oficial e implemente consentimento, política de privacidade e requisitos legais.");
}
async function signApk(apk, jobDir, opts, log) {
  const output = path.join(jobDir, `${safeName(opts.appName)}-assinado.apk`);
  let keystorePath;
  let alias;
  let storePassword;
  let keyPassword;
  let generated = false;
  if (opts.keystorePath) {
    keystorePath = path.join(jobDir, "chave-importada.jks");
    fs.copyFileSync(opts.keystorePath, keystorePath);
    alias = opts.keyAlias;
    storePassword = opts.keyStorePassword;
    keyPassword = opts.keyPassword || storePassword;
  } else {
    keystorePath = path.join(jobDir, "apk-forge-release.jks");
    alias = "apkforge";
    storePassword = crypto.randomBytes(24).toString("hex");
    keyPassword = storePassword;
    generated = true;
    const env = sanitizedBuildEnv({ APKFORGE_STOREPASS: storePassword, APKFORGE_KEYPASS: keyPassword });
    await run("keytool", ["-genkeypair", "-v", "-keystore", keystorePath, "-storepass:env", "APKFORGE_STOREPASS", "-keypass:env", "APKFORGE_KEYPASS", "-alias", alias, "-keyalg", "RSA", "-keysize", "2048", "-validity", "10000", "-dname", "CN=APK Forge, OU=APK Builder, O=APK Forge, L=Unknown, ST=Unknown, C=BR"], jobDir, log, { env });
  }
  const passDir = path.join(jobDir, "secrets");
  fs.mkdirSync(passDir, { recursive: true, mode: 0o700 });
  const storeFile = path.join(passDir, "storepass.txt");
  const keyFile = path.join(passDir, "keypass.txt");
  fs.writeFileSync(storeFile, `${storePassword}\n`, { mode: 0o600 });
  fs.writeFileSync(keyFile, `${keyPassword}\n`, { mode: 0o600 });
  const apksigner = process.env.APK_SIGNER || "apksigner";
  try {
    await run(apksigner, ["sign", "--ks", keystorePath, "--ks-key-alias", alias,
      "--ks-pass", `file:${storeFile}`, "--key-pass", `file:${keyFile}`, "--out", output, apk], jobDir, log);
    await run(apksigner, ["verify", "--verbose", "--print-certs", output], jobDir, log);
  } finally {
    fs.rmSync(passDir, { recursive: true, force: true });
  }
  return { output, keystorePath, alias, storePassword, keyPassword, generated };
}
function makeExport(jobDir, signed, opts) {
  const archive = new AdmZip();
  const apkName = `${safeName(opts.appName)}.apk`;
  archive.addLocalFile(signed.output, "", apkName);
  archive.addLocalFile(signed.keystorePath, "", "apk-forge-release.jks");
  const signingInfo = signed.generated
    ? `APK Forge — dados de assinatura\n\nPacote: ${opts.packageId}\nAlias: ${signed.alias}\nArquivo da chave: apk-forge-release.jks\nSenha do keystore: ${signed.storePassword}\nSenha da chave: ${signed.keyPassword}\n\nGuarde este arquivo e o keystore em local seguro. Qualquer pessoa com esses dados pode assinar aplicativos como esta identidade. Use a mesma chave e o mesmo applicationId para publicar atualizações.\n`
    : `APK Forge — dados de assinatura\n\nPacote: ${opts.packageId}\nAlias usado: ${signed.alias}\nArquivo: apk-forge-release.jks\nA chave foi fornecida por você; as senhas não são incluídas neste arquivo. Preserve sua cópia original da chave e suas senhas.\n`;
  archive.addFile("DADOS-DE-ASSINATURA.txt", Buffer.from(signingInfo, "utf8"));
  archive.addFile("BUILD-INFO.json", Buffer.from(JSON.stringify({
    appName: opts.appName, packageId: opts.packageId, createdAt: new Date().toISOString(),
    projectKind: opts.projectKind,
    configurationApplied: opts.projectKind === "html-wrapper" ? "APK Forge HTML wrapper" : "project Gradle preserved; form settings are not applied",
    versionName: opts.versionName, versionCode: opts.versionCode, minSdk: opts.minSdk,
    orientation: opts.orientation, theme: opts.theme, author: opts.author, description: opts.description,
    permissions: opts.projectKind === "html-wrapper" ? opts.permissions : "manifest-preserved",
    storageAccess: opts.projectKind === "html-wrapper" ? opts.storageAccess : "not-applied",
    signingKey: signed.generated ? "generated-for-this-build" : "user-provided",
    contents: [apkName, "apk-forge-release.jks", "DADOS-DE-ASSINATURA.txt"],
  }, null, 2), "utf8"));
  const pathOut = path.join(jobDir, "APK-FORGE-EXPORT.zip");
  archive.writeZip(pathOut);
  return pathOut;
}
function cleanupFiles(files) {
  for (const file of files || []) if (file?.path) fs.rmSync(file.path, { force: true });
}

function collectFiles(root, current = root, depth = 0) {
  if (depth > 12) return [];
  const found = [];
  for (const item of fs.readdirSync(current, { withFileTypes: true })) {
    if (["node_modules", ".git", ".gradle", "build"].includes(item.name)) continue;
    const full = path.join(current, item.name);
    if (item.isDirectory()) found.push(...collectFiles(root, full, depth + 1));
    else if (item.isFile()) found.push({ path: path.relative(root, full).split(path.sep).join("/"), size: fs.statSync(full).size });
  }
  return found;
}
function parsePermissionOptions(raw) {
  let value = [];
  if (raw) {
    try { value = JSON.parse(raw); } catch { throw new Error("A lista de permissões está em formato inválido."); }
  }
  if (!Array.isArray(value) || value.length > HTML_WRAPPER_PERMISSIONS.size) throw new Error("A lista de permissões é inválida.");
  const unique = [...new Set(value)];
  if (unique.some(item => typeof item !== "string" || !HTML_WRAPPER_PERMISSIONS.has(item))) throw new Error("A lista contém uma permissão não suportada pelo wrapper HTML.");
  return unique;
}

app.get("/api/health", (_req, res) => res.json({
  ok: true, service: "APK Forge", apiVersion: 3,
  authenticationConfigured: Boolean(API_TOKEN),
  androidSdk: "35", gradle: "8.9", buildInProgress: activeBuilds > 0,
  maxConcurrentBuilds: 1,
}));

app.post("/api/analyze", requireToken,
  upload.fields([{ name: "project", maxCount: 1 }]),
  async (req, res) => {
    const files = Object.values(req.files || {}).flat();
    const projectFile = req.files?.project?.[0];
    if (activeAnalyses >= 1) {
      cleanupFiles(files);
      return res.status(429).json({ error: "O servidor já está analisando um arquivo. Tente novamente em instantes." });
    }
    activeAnalyses++;
    const analysisDir = path.join(WORK, `analysis-${crypto.randomUUID()}`);
    try {
      if (!projectFile) throw new Error("Envie um ZIP do projeto para análise.");
      const extracted = path.join(analysisDir, "source");
      fs.mkdirSync(extracted, { recursive: true, mode: 0o700 });
      safeExtract(projectFile.path, extracted);
      const filesFound = collectFiles(extracted).sort((a, b) => a.path.localeCompare(b.path));
      const index = findFile(extracted, "index.html");
      const gradle = findFile(extracted, "gradlew");
      const buildFile = findFile(extracted, "build.gradle") || findFile(extracted, "build.gradle.kts");
      const manifest = findFile(extracted, "AndroidManifest.xml");
      const manifestText = manifest && fs.statSync(manifest).size <= 1024 * 1024 ? fs.readFileSync(manifest, "utf8") : "";
      const manifestPackage = manifestText.match(/\bpackage\s*=\s*["']([^"']+)["']/i)?.[1] || "";
      const indexTitle = index && fs.statSync(index).size <= 1024 * 1024
        ? (fs.readFileSync(index, "utf8").match(/<title[^>]*>([\s\S]*?)<\/title>/i)?.[1] || "").replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim().slice(0, 100)
        : "";
      const kind = gradle ? "android-gradle" : index ? "html" : "unsupported";
      const warnings = [];
      if (gradle) warnings.push("A análise não executou scripts; builds Gradle executarão código e exigem confirmação de confiança.");
      if (buildFile && !gradle) warnings.push("Foi encontrado build.gradle sem Gradle Wrapper; este backend exige o Wrapper para projetos Android.");
      if (kind === "unsupported") warnings.push("Não foi localizado index.html nem gradlew dentro dos limites de busca.");
      const privateName = /(^|\/)(\.env|[^/]*\.(jks|keystore)|[^/]*(secret|password)[^/]*)$/i;
      const preview = filesFound.filter(item => !privateName.test(item.path)).slice(0, 30);
      res.json({
        apiVersion: 1, kind,
        fileCount: filesFound.length,
        totalBytes: filesFound.reduce((sum, item) => sum + item.size, 0),
        indexPath: index ? path.relative(extracted, index).split(path.sep).join("/") : "",
        indexTitle, gradleWrapper: gradle ? path.relative(extracted, gradle).split(path.sep).join("/") : "",
        manifestPackage, manifestPermissions: [...manifestText.matchAll(/android:name\s*=\s*["'](android\.permission\.[^"']+)["']/gi)].map(match => match[1]),
        files: preview, warnings,
      });
    } catch (error) {
      res.status(400).json({ error: error?.message || "Não foi possível analisar o ZIP." });
    } finally {
      cleanupFiles(files);
      fs.rmSync(analysisDir, { recursive: true, force: true });
      activeAnalyses = Math.max(0, activeAnalyses - 1);
    }
  });

app.post("/api/build", requireToken,
  upload.fields([{ name: "project", maxCount: 1 }, { name: "icon", maxCount: 1 }, { name: "keystore", maxCount: 1 }]),
  async (req, res) => {
    const files = Object.values(req.files || {}).flat();
    if (activeBuilds >= 1) {
      cleanupFiles(files);
      return res.status(429).json({ error: "O servidor já está compilando um projeto. Tente novamente em alguns minutos." });
    }
    activeBuilds++;
    const projectFile = req.files?.project?.[0];
    let jobDir;
    let log = () => {};
    try {
      if (!projectFile) throw new Error("Envie um arquivo ZIP do projeto.");
      const appName = String(req.body.appName || "Meu Aplicativo").trim().slice(0, 40);
      const packageId = String(req.body.packageId || "com.exemplo.meuapp").trim();
      if (!appName) throw new Error("Informe o nome do aplicativo.");
      if (!validPackage(packageId)) throw new Error("Identificador inválido. Use segmentos Android válidos, por exemplo com.exemplo.meuapp.");
      const versionName = String(req.body.versionName || "1.0.0").trim();
      const versionCode = Number(req.body.versionCode || 1);
      const minSdk = Number(req.body.minSdk || 23);
      const orientation = String(req.body.orientation || "portrait");
      const theme = String(req.body.theme || "dark");
      const primaryColor = String(req.body.primaryColor || "#8b72ff");
      const author = String(req.body.author || "").replace(/[\u0000-\u001f\u007f]/g, " ").trim().slice(0, 80);
      const description = String(req.body.description || "").replace(/[\u0000-\u001f\u007f]/g, " ").trim().slice(0, 200);
      const permissions = parsePermissionOptions(req.body.permissions || "[]");
      if (!/^[A-Za-z0-9._+-]{1,32}$/.test(versionName)) throw new Error("Version Name inválido. Use até 32 caracteres alfanuméricos, ponto, +, - ou _.");
      if (!Number.isSafeInteger(versionCode) || versionCode < 1 || versionCode > 2147483647) throw new Error("Version Code deve ser um inteiro positivo.");
      if (!Number.isInteger(minSdk) || minSdk < 23 || minSdk > 35) throw new Error("SDK mínimo deve estar entre 23 e 35.");
      if (!["portrait", "landscape", "unspecified"].includes(orientation)) throw new Error("Orientação inválida.");
      if (!["dark", "light"].includes(theme)) throw new Error("Tema inválido.");
      if (!/^#[0-9a-f]{6}$/i.test(primaryColor)) throw new Error("Cor principal inválida.");
      jobDir = path.join(WORK, crypto.randomUUID());
      fs.mkdirSync(jobDir, { recursive: true, mode: 0o700 });
      log = makeLogger(path.join(jobDir, "build.log"));
      const source = path.join(jobDir, "source");
      const generatedProject = path.join(jobDir, "android");
      fs.mkdirSync(source); fs.mkdirSync(generatedProject);
      safeExtract(projectFile.path, source);
      const opts = {
        appName, packageId, versionName, versionCode, minSdk, orientation, theme,
        author, description, primaryColor, permissions,
        splash: req.body.splash === "true",
        ads: req.body.ads === "true",
        storageAccess: req.body.storageAccess === "true",
        iconPath: req.files?.icon?.[0]?.path,
        iconExt: iconExtension(req.files?.icon?.[0]?.path),
        keystorePath: req.files?.keystore?.[0]?.path,
        keyAlias: String(req.body.keyAlias || "").trim(),
        keyStorePassword: String(req.body.keyStorePassword || ""),
        keyPassword: String(req.body.keyPassword || ""),
      };
      if (req.files?.icon?.[0]?.size > 10 * 1024 * 1024) throw new Error("O ícone deve ter no máximo 10 MB.");
      if (req.files?.keystore?.[0]?.size > 10 * 1024 * 1024) throw new Error("O keystore deve ter no máximo 10 MB.");
      if (opts.keystorePath && (!opts.keyAlias || opts.keyAlias.length > 128 || /[\r\n\0]/.test(opts.keyAlias) || !opts.keyStorePassword)) {
        throw new Error("Para usar uma chave existente, informe alias e senha do keystore.");
      }
      if (opts.keyStorePassword.length > 512 || opts.keyPassword.length > 512) throw new Error("Senha do keystore excede 512 caracteres.");
      const gradleWrapper = findFile(source, "gradlew");
      let projectRoot;
      if (gradleWrapper) {
        opts.projectKind = "android-gradle";
        if (req.body.trustGradle !== "true") throw new Error("Confirme que confia nos scripts Gradle deste ZIP. Projetos Gradle executam código durante a compilação.");
        projectRoot = path.dirname(gradleWrapper);
        log("Projeto Android detectado. Executando Gradle Wrapper (somente projetos confiáveis)...\n");
        await run("bash", ["./gradlew", "--no-daemon", "assembleDebug"], projectRoot, log);
      } else {
        const buildGradle = findFile(source, "build.gradle") || findFile(source, "build.gradle.kts");
        if (buildGradle) throw new Error("Projeto Gradle sem Wrapper. Inclua gradlew e gradle/wrapper no ZIP.");
        opts.projectKind = "html-wrapper";
        createHtmlAndroidProject(source, generatedProject, opts);
        projectRoot = generatedProject;
        log("Projeto HTML detectado. Criando aplicativo Android com WebView...\n");
        await run("gradle", ["--no-daemon", "assembleDebug"], projectRoot, log);
      }
      const apk = findApk(path.join(projectRoot, "app", "build", "outputs", "apk"));
      if (!apk) throw new Error("A compilação terminou, mas nenhum APK debug/unsigned foi localizado.");
      log("Assinando e verificando o APK...\n");
      const signed = await signApk(apk, jobDir, opts, log);
      const exported = makeExport(jobDir, signed, opts);
      res.download(exported, `${safeName(appName)}-APK-Forge.zip`, err => {
        if (err) console.error(`Falha no envio do resultado: ${err.message}`);
        fs.rmSync(jobDir, { recursive: true, force: true });
        cleanupFiles(files);
      });
    } catch (error) {
      const message = error?.message || "Falha desconhecida no build.";
      if (jobDir && fs.existsSync(path.join(jobDir, "build.log"))) log(`\nERRO: ${message}\n`);
      const logText = jobDir && fs.existsSync(path.join(jobDir, "build.log"))
        ? fs.readFileSync(path.join(jobDir, "build.log"), "utf8").slice(-12_000) : "";
      console.error(`Build falhou: ${message}`);
      cleanupFiles(files);
      if (jobDir) fs.rmSync(jobDir, { recursive: true, force: true });
      if (!res.headersSent) res.status(400).json({ error: message, log: logText });
      else if (!res.destroyed) res.end();
    } finally {
      activeBuilds = Math.max(0, activeBuilds - 1);
    }
  });

app.use((err, req, res, _next) => {
  cleanupFiles(Object.values(req.files || {}).flat());
  const status = err instanceof multer.MulterError ? 413 : 400;
  console.error(`Requisição inválida: ${err.message}`);
  if (res.headersSent) return res.end();
  const message = err instanceof multer.MulterError
    ? (err.code === "LIMIT_FILE_SIZE" ? "Um arquivo excede o limite de 250 MB." : `Upload inválido: ${err.message}`)
    : "Upload inválido ou arquivo não pôde ser processado.";
  res.status(status).json({ error: message });
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`APK Forge API escutando na porta ${PORT}; autenticação ${API_TOKEN ? "configurada" : "NÃO configurada"}.`);
});
