# APK Forge Ultimate 2.1.0

APK Forge combina uma interface web (`public/index.html`), um cliente Android nativo opcional (`android-client/`) e um backend privado. O backend executa a compilação Android e assina o APK; o navegador/celular não compila Gradle localmente.

## Recursos implementados

- Dashboard responsivo com conexão real ao endpoint de saúde, fluxo de build e histórico local de metadados.
- Análise autenticada do ZIP antes do build: valida extração, detecta `index.html`, Gradle Wrapper e manifesto, lista uma amostra dos arquivos e não executa scripts durante a análise.
- Wrapper Android WebView para projetos HTML, com nome, package ID, version name/code, SDK mínimo, orientação, tema, cor da tela inicial, ícone, metadados e splash.
- Configuração limitada de permissões para wrapper HTML: Internet é incluída; câmera, microfone e localização são solicitados pelo sistema somente quando a página usa esses recursos; vibração é opcional. Upload de arquivo usa seletor do Android sem acesso amplo por padrão.
- Opção original de `MANAGE_EXTERNAL_STORAGE` restaurada, desmarcada por padrão. Só abre as Configurações depois de confirmação explícita. É uma permissão sensível e pode impedir distribuição pela Play Store; use apenas se essencial.
- Importação de keystore existente ou geração de uma chave nova. Resultado contém APK assinado, keystore e instruções; dados de assinatura são material sensível.
- Backend privado com token Bearer, análise sem execução, limite de upload/expansão, timeout, logs limitados e um build simultâneo.

## Executar o backend

Requisitos: Docker Engine/Desktop com Docker Compose v2 e pelo menos 4 GB de memória disponíveis para o container.

1. Copie `.env.example` para `.env`.
2. Gere um token forte, por exemplo `openssl rand -hex 32`, e substitua `APK_FORGE_API_TOKEN`.
3. Inicie o serviço:

```bash
cp .env.example .env
# edite .env e substitua o token de exemplo
docker compose up --build -d
```

A primeira construção baixa o Android SDK, o Gradle e dependências. A interface fica em `http://localhost:3000`; o health check é `http://localhost:3000/api/health`. A porta fica ligada a `127.0.0.1` por padrão.

O health check confirma que o processo HTTP responde e informa as versões configuradas no container; não executa um build de teste nem comprova espaço livre ou disponibilidade de rede Maven.

### Celular na mesma rede local

Para permitir que outro dispositivo alcance o backend, altere `APK_FORGE_BIND=0.0.0.0`, restrinja a porta no firewall aos dispositivos confiáveis e reinicie o Compose. Abra a interface pelo endereço do backend e use o IP privado do computador. HTTP em LAN não é criptografado; para qualquer acesso externo, use HTTPS. Não exponha diretamente a porta de build na internet.

## Usar a interface web

1. Abra `http://localhost:3000` (ou o endereço privado configurado) e, em **Configurações**, informe o token Bearer.
2. Selecione um ZIP. A análise chama `POST /api/analyze` autenticado, valida estrutura e não roda código.
3. Configure os campos de identidade. Em projetos HTML, as opções são aplicadas ao wrapper. Para Android Gradle, confirme que confia no código; os scripts Gradle serão executados no servidor e a configuração do projeto é preservada.
4. Selecione permissões somente se necessárias. A opção de todos os arquivos é separada, avançada e desativada por padrão.
5. Clique em **Construir e assinar APK**. A requisição é síncrona: mantenha a página aberta. O retorno é um ZIP e o histórico guarda apenas metadados no navegador, nunca APK, projeto, keystore ou senha.

O painel usa o backend da mesma origem por padrão. Abrir a interface de outro domínio/origem requer que a implantação configure CORS de forma explícita. O URL pode ser lembrado no navegador; o token fica no `sessionStorage` da aba atual e não é incluído no histórico.

## Contrato da API

- `GET /api/health`: público; retorna disponibilidade HTTP, configuração de autenticação, API, versões anunciadas do SDK/Gradle e se há build ativo.
- `POST /api/analyze`: Bearer obrigatório, `multipart/form-data` com `project` ZIP. Inspeciona arquivos e detecta HTML/Gradle, sem executar scripts.
- `POST /api/build`: Bearer obrigatório, `multipart/form-data` com `project` e campos de identidade/configuração; `icon` e `keystore` são opcionais. Sucesso retorna ZIP; falha retorna JSON `{error, log?}`. Há um build simultâneo.

## Tipos de projeto e limites

- **HTML/CSS/JS:** precisa conter `index.html`. Os arquivos próximos a esse HTML são empacotados em um WebView local. Permissões de câmera, microfone e localização podem ser pedidas sob demanda; recursos não habilitados são negados. O seletor de arquivos do WebView usa o seletor seguro do Android.
- **Android Gradle:** precisa de `gradlew` e `gradle/wrapper`. É executado `assembleDebug`; o build usa o manifesto/configuração enviados e não reescreve package, SDK mínimo, permissões, tema ou orientação do projeto. O app pede confirmação antes de executar scripts.
- Upload individual: até 250 MB; expansão do ZIP: até 500 MB e 5.000 entradas; ícone e keystore: até 10 MB. A análise não determina se o projeto é seguro; apenas valida estrutura e caminhos.
- Builds Gradle rodam código do projeto. O container reduz privilégios e limita recursos, mas não é sandbox multiusuário por build. Use projetos confiáveis, em backend privado e de usuário único.
- O build é `assembleDebug`, não uma pipeline pronta de publicação. Revise versão, manifesto, permissões, política de privacidade e requisitos de distribuição.
- Anúncios são apenas lembrete de integração; nenhum SDK, ID de anúncio ou rastreador é incluído.
- `MANAGE_EXTERNAL_STORAGE` é sujeito a restrições do Android e da Google Play. Para seleção de documentos, prefira o seletor seguro; o builder não adiciona gerenciador de arquivos nativo.
- Notificações push e Bluetooth não são habilitados pelo wrapper HTML genérico; configure-os em um projeto Android nativo.

## Cliente Android opcional

O app cliente nativo está em `android-client/`. Abra-o, informe URL e token, selecione ZIP/ícone/keystore e salve o ZIP de resultado com o seletor do sistema. O cliente Android e a interface web são duas formas de usar o mesmo backend.

Para compilar o cliente manualmente, use JDK 17+, Android SDK Platform 35 e Gradle 8.9:

```bash
cd android-client
./gradlew assembleDebug
```

Para uma release do cliente, configure uma keystore própria por variáveis de ambiente (`APKFORGE_RELEASE_STORE_FILE`, `APKFORGE_RELEASE_STORE_PASSWORD`, `APKFORGE_RELEASE_KEY_ALIAS` e `APKFORGE_RELEASE_KEY_PASSWORD`). Nunca grave senhas no Gradle ou no Git.
