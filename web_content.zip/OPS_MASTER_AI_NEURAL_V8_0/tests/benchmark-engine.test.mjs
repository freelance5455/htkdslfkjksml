import test from 'node:test';
import assert from 'node:assert/strict';
import { scoreAgentMetrics, createBenchmarkEngine } from '../server/benchmark-engine.mjs';

test('score transparent et confiance selon la taille de l’échantillon',()=>{
 const empty=scoreAgentMetrics(); assert.equal(empty.score,null); assert.equal(empty.confidence,'insuffisante');
 const small=scoreAgentMetrics({total:4,done:3,failed:1,retries:1,avgDurationMs:30000}); assert.equal(small.success_rate,75); assert.equal(small.confidence,'faible'); assert.ok(small.score>=0&&small.score<=100);
 const large=scoreAgentMetrics({total:24,done:22,failed:2,retries:3,avgDurationMs:1000}); assert.equal(large.confidence,'élevée');
});
test('rapport benchmark agrège tâches et consommation observées',async()=>{
 const calls=[]; const db={all:async(sql,args)=>{calls.push(sql); if(sql.includes('FROM usage'))return [{agent_id:'coder',calls:7,tokens:900,successful_calls:6,failed_calls:1}]; if(sql.includes('FROM tasks'))return [{agent_id:'coder',total:5,done:4,failed:1,finished:5,retries:2,avg_duration_ms:12000}]; return [];},run:async(sql,args)=>({changes:1})};
 const engine=createBenchmarkEngine({db,workspace:{log:async()=>{}}}); const r=await engine.report('p1');
 assert.equal(r.agents[0].success_rate,80); assert.equal(r.agents[0].tokens,900); assert.equal(r.summary.tasks,5); assert.ok(r.methodology.limitations.length>=3);
});
test('instantané conserve le rapport et écrit un journal',async()=>{let inserted=false,logged=false;const db={all:async()=>[],run:async(sql)=>{inserted=sql.includes('benchmark_snapshots');return {changes:1};}};const engine=createBenchmarkEngine({db,workspace:{log:async()=>{logged=true;}}});const x=await engine.snapshot('p');assert.ok(x.id.startsWith('bench_'));assert.ok(inserted&&logged);});
