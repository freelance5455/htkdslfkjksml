import test from 'node:test';
import assert from 'node:assert/strict';
import { createGameFactoryBlueprint, buildFactoryDeliveryReport } from '../server/game-factory.mjs';

test('OPS GAME FACTORY transforme le brief en exigences identifiées et flux dépendants', () => {
  const plan = createGameFactoryBlueprint({ title: 'Jeu OPS', brief: 'Créer une ville. Ajouter des véhicules. Préserver les missions.', constraints: ['Pas de suppression'] });
  assert.equal(plan.schema, 'ops.game-factory.v1');
  assert.deepEqual(plan.requirements.map(x => x.id), ['REQ-001', 'REQ-002', 'REQ-003']);
  assert.equal(plan.workstreams.length, 9);
  assert.ok(plan.workstreams.every((x, i) => x.order === i + 1 && x.status === 'planned'));
  assert.deepEqual(plan.workstreams.at(-1).depends_on, ['quality']);
});

test('rapport Factory liste les fichiers et garde les exigences en revue sans preuve', () => {
  const plan = createGameFactoryBlueprint({ title: 'Jeu OPS', brief: 'Créer une ville.' });
  const report = buildFactoryDeliveryReport(plan, {
    files: ['src/main.js', { path: 'index.html' }],
    diagnostics: [{ severity: 'error', code: 'BROKEN_IMPORT' }],
    regression: { ok: true, findings: [] },
    checks: { passed: true, summary: { total: 4 } },
  });
  assert.deepEqual(report.file_manifest, ['index.html', 'src/main.js']);
  assert.equal(report.requirement_tracking[0].status, 'needs_review');
  assert.equal(report.integration.passed, false);
  assert.equal(report.delivery_status, 'blocked');
});
