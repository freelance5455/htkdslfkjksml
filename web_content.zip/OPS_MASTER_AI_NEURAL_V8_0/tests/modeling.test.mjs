import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { boot, bootWithStub } from './helpers.mjs';
import { generateAsset, validateAsset, normalizeAssetParams, toGltf, toObj, toMtl, toPreviewSvg, generatePbrTextures, planKit, ALL_KINDS, BUILDING_KINDS, PROP_KINDS, STYLES, BUDGET } from '../server/modelgen.mjs';
import { generateWorld } from '../server/worldgen.mjs';

const dl = async (t, id, file) => { const r = await fetch(`${t.base}/api/modeling/assets/${id}/download?file=${encodeURIComponent(file)}`, { headers: { authorization: 'Bearer tok-test-123' } }); return { status: r.status, text: await r.text() }; };
const pending = async (t, pid) => (await t.api('GET', `/api/approvals?project_id=${pid}`)).data;
const mkWorld = async (t, pid, params = {}) => (await t.api('POST', '/api/world/generate', { project_id: pid, params: { seed: 'kit', size: 'small', ...params } })).data.world;

/** Contrôle glTF indépendant du générateur : lit le JSON + le tampon embarqué. */
function checkGltf(text) {
  const g = JSON.parse(text);
  assert.equal(g.asset.version, '2.0');
  const uri = g.buffers[0].uri, buf = Buffer.from(uri.split(',')[1], 'base64');
  assert.equal(buf.length, g.buffers[0].byteLength);
  for (const v of g.bufferViews) { assert.ok(v.byteOffset % 4 === 0, 'alignement 4 octets'); assert.ok(v.byteOffset + v.byteLength <= buf.length, 'bufferView dans le tampon'); }
  const size = { 5126: 4, 5123: 2, 5125: 4 }, comps = { VEC3: 3, VEC2: 2, SCALAR: 1 };
  for (const a of g.accessors) { const v = g.bufferViews[a.bufferView]; assert.ok(a.count * comps[a.type] * size[a.componentType] <= v.byteLength, 'accessor dans sa vue'); }
  let tris = 0;
  for (const m of g.meshes) for (const p of m.primitives) {
    const pos = g.accessors[p.attributes.POSITION], idx = g.accessors[p.indices];
    assert.equal(g.accessors[p.attributes.NORMAL].count, pos.count); assert.equal(g.accessors[p.attributes.TEXCOORD_0].count, pos.count);
    assert.ok(pos.min && pos.max, 'POSITION min/max requis');
    const v = g.bufferViews[idx.bufferView]; const arr = idx.componentType === 5123 ? new Uint16Array(buf.buffer, buf.byteOffset + v.byteOffset, idx.count) : new Uint32Array(buf.buffer, buf.byteOffset + v.byteOffset, idx.count);
    assert.ok(arr.every((i) => i < pos.count), 'indices valides'); assert.equal(idx.count % 3, 0);
    const pv = g.bufferViews[pos.bufferView], pa = new Float32Array(buf.buffer, buf.byteOffset + pv.byteOffset, pos.count * 3);
    for (let k = 0; k < 3; k++) { let mn = Infinity, mx = -Infinity; for (let i = 0; i < pos.count; i++) { mn = Math.min(mn, pa[3 * i + k]); mx = Math.max(mx, pa[3 * i + k]); } assert.ok(Math.abs(mn - pos.min[k]) < 1e-4 && Math.abs(mx - pos.max[k]) < 1e-4, 'min/max exacts'); }
    assert.ok(p.material >= 0 && p.material < g.materials.length); tris += idx.count / 3;
  }
  assert.deepEqual(g.nodes.filter((n) => n.mesh !== undefined).map((n) => n.name.match(/LOD\d$/)[0]), ['LOD0', 'LOD1', 'LOD2']);
  return { g, tris };
}

// ------------------------------------------------------------- générateur (fonctions pures)
test('modèles : déterministes ; chaque type, style et gabarit valide (seuls les dépassements de budget extrêmes sont refusés)', () => {
  const a = JSON.stringify(generateAsset({ kind: 'office', style: 'verre', floors: 12, width: 20, depth: 16 })), b = JSON.stringify(generateAsset({ kind: 'office', style: 'verre', floors: 12, width: 20, depth: 16 }));
  assert.equal(a, b);
  let n = 0;
  for (const kind of ALL_KINDS) for (const style of STYLES) for (const floors of [1, 3, 9, 25]) for (const [width, depth] of [[8, 8], [14, 30], [40, 40], [80, 12]]) {
    const m = generateAsset({ kind, style, floors, width, depth }); n++;
    const errs = m.validation.issues.filter((i) => i.level === 'error');
    assert.ok(errs.length === 0, `${kind}/${style}/${floors}/${width}x${depth} : ${errs.map((e) => e.msg).join(' ; ')}`);
    assert.ok(m.lods[0].tris > m.lods[1].tris && m.lods[1].tris > m.lods[2].tris);
    assert.ok(Math.abs(m.bounds.min[1]) <= 0.011);
  }
  assert.equal(n, ALL_KINDS.length * 8 * 4 * 4);
  // limites : un gabarit extrême est refusé par le budget, pas accepté en silence
  const huge = generateAsset({ kind: 'house', floors: 60, width: 80, depth: 80 });
  assert.equal(huge.validation.ok, false); assert.match(huge.validation.issues.map((i) => i.msg).join(' '), /budget LOD0/);
});


test('textures PBR : PNG déterministes, maps baseColor/normal/ORM et branchement glTF 2.0', () => {
  const a = generateAsset({ kind: 'office', style: 'brique', quality: 'high' });
  const m = a.materials[0], x = generatePbrTextures(m, 64), y = generatePbrTextures(m, 64);
  for (const key of ['baseColor', 'normal', 'orm']) {
    assert.equal(x[key].subarray(0, 8).toString('hex'), '89504e470d0a1a0a');
    assert.equal(x[key].readUInt32BE(16), 64); assert.equal(x[key].readUInt32BE(20), 64);
    assert.deepEqual(x[key], y[key], 'textures déterministes');
  }
  const g = JSON.parse(toGltf(a));
  assert.equal(g.images.length, a.materials.length * 3);
  assert.equal(g.textures.length, a.materials.length * 3);
  for (const mat of g.materials) {
    assert.ok(mat.pbrMetallicRoughness.baseColorTexture);
    assert.ok(mat.pbrMetallicRoughness.metallicRoughnessTexture);
    assert.ok(mat.normalTexture); assert.ok(mat.occlusionTexture);
  }
  assert.ok(g.images.every((i) => i.uri.endsWith('.png') && !i.uri.startsWith('data:')), 'glTF référence les PNG externes livrés à côté');
  assert.match(toMtl(a), /map_Kd .*_BaseColor\.png/);
});

test('profils de qualité : géométrie courbe plus fine en High/Ultra, paramètres invalides refusés', () => {
  const balanced = generateAsset({ kind: 'stadium', quality: 'balanced' });
  const high = generateAsset({ kind: 'stadium', quality: 'high' });
  const ultra = generateAsset({ kind: 'stadium', quality: 'ultra' });
  assert.equal(balanced.quality, 'balanced');
  assert.equal(high.quality, 'high');
  assert.equal(ultra.quality, 'ultra');
  assert.ok(high.lods[0].tris > balanced.lods[0].tris, 'High doit augmenter la finesse des anneaux');
  assert.ok(ultra.lods[0].tris > high.lods[0].tris, 'Ultra doit augmenter encore la finesse');
  for (const a of [balanced, high, ultra]) assert.equal(a.validation.ok, true, JSON.stringify(a.validation.issues));
  assert.throws(() => normalizeAssetParams({ quality: 'cinematic-8k' }), /quality/);
  assert.equal(normalizeAssetParams({}).quality, 'balanced', 'compatibilité des anciens appels');
});

test('modèles : paramètres invalides refusés (400), valeurs par défaut, collisions cohérentes', () => {
  for (const bad of [{ kind: 'dragon' }, { style: 'lave' }, { floors: 0 }, { floors: 99 }, { width: 2 }, { depth: 'large' }, { kind: 'tree', height: 99 }]) assert.throws(() => normalizeAssetParams(bad), (e) => e.status === 400, JSON.stringify(bad));
  const d = normalizeAssetParams({}); assert.equal(d.kind, 'house'); assert.match(d.name, /^SM_house_/);
  const h = generateAsset({ kind: 'house', floors: 2, width: 12, depth: 10 });
  assert.equal(h.collision.length, 1); assert.deepEqual(h.collision[0].half, [6, 3, 5]); assert.equal(h.collision[0].center[1], 3);
  const tower = generateAsset({ kind: 'tower', floors: 30, width: 30, depth: 30 }); assert.equal(tower.collision.length, 3, 'une boîte par étage de la tour');
  const stadium = generateAsset({ kind: 'stadium', floors: 2, width: 40, depth: 40 }); assert.ok(stadium.collision.length >= 16, 'anneau de boîtes');
  for (const k of PROP_KINDS) { const p = generateAsset({ kind: k }); assert.ok(p.lods[0].tris <= BUDGET.prop.lod0 && p.lods[2].tris <= BUDGET.prop.lod2, k); }
  assert.ok(BUILDING_KINDS.length === 11 && PROP_KINDS.length === 4);
});

test('validateAsset : détecte réellement les défauts (faces inversées, normales, dégénérés, indices, matériau, LOD, base, collision, budget)', () => {
  const base = () => JSON.parse(JSON.stringify(generateAsset({ kind: 'office', floors: 4, width: 14, depth: 14 })));
  assert.ok(validateAsset(base()).ok);
  const has = (a, re) => validateAsset(a).issues.some((i) => i.level === 'error' && re.test(i.msg));
  let a = base(); const p = a.lods[0].prims[0]; [p.idx[1], p.idx[2]] = [p.idx[2], p.idx[1]]; assert.ok(has(a, /orientation/));
  a = base(); a.lods[1].prims[0].nrm[0] = 5; assert.ok(has(a, /normale/));
  a = base(); a.lods[0].prims[0].idx[1] = a.lods[0].prims[0].idx[0]; assert.ok(has(a, /dégénéré/));
  a = base(); a.lods[0].prims[0].idx[0] = 99999; assert.ok(has(a, /hors limites/));
  a = base(); a.lods[0].prims[0].material = 'inconnu'; assert.ok(has(a, /matériau inconnu/));
  a = base(); a.lods[0].prims[0].uv.pop(); assert.ok(has(a, /incohérentes/));
  a = base(); a.lods[0].prims[0].pos[0] = NaN; assert.ok(has(a, /non finies/));
  a = base(); [a.lods[0], a.lods[2]] = [a.lods[2], a.lods[0]]; assert.ok(has(a, /LOD non décroissants/));
  a = base(); a.bounds.min[1] = 2; assert.ok(has(a, /y = 0/));
  a = base(); a.collision = []; assert.ok(has(a, /aucune collision/));
  a = base(); a.collision[0].half[0] = 0; assert.ok(has(a, /collision invalide/));
  a = base(); a.lods[0].tris = 1; a.lods[1].tris = 0.5; a.lods[2].tris = 0.1; a.name = 'bad name!'; assert.ok(has(a, /nom invalide/));
  a = base(); a.lods[2].tris = BUDGET.building.lod2 + 1; a.lods[1].tris = a.lods[2].tris + 1; a.lods[0].tris = a.lods[1].tris + 1; assert.ok(has(a, /budget LOD2/));
});

test('exports : glTF 2.0 structurellement valide (tampon, accessors, min/max), OBJ/MTL cohérents, aperçu SVG sûr', () => {
  for (const kind of ['house', 'tower', 'stadium', 'tree', 'streetlight']) {
    const a = generateAsset({ kind, floors: kind === 'tower' ? 20 : 3, width: 24, depth: 24 }), { g, tris } = checkGltf(toGltf(a));
    assert.equal(tris, a.lods.reduce((n, l) => n + l.tris, 0), kind);
    assert.equal(g.materials.length, a.materials.length); assert.ok(g.extras.collision.length > 0);
    const obj = toObj(a, 0).split('\n'), v = obj.filter((l) => l.startsWith('v ')).length;
    assert.equal(obj.filter((l) => l.startsWith('f ')).length, a.lods[0].tris);
    for (const f of obj.filter((l) => l.startsWith('f '))) for (const t of f.slice(2).split(' ')) assert.ok(Number(t.split('/')[0]) <= v && Number(t.split('/')[0]) >= 1);
    const mtl = toMtl(a); for (const m of a.materials) assert.ok(mtl.includes(`newmtl ${m.name}`));
    assert.ok(obj.every((l) => !/NaN|undefined|Infinity/.test(l)));
    const svg = toPreviewSvg(a); assert.match(svg, /^<svg /); assert.ok(svg.endsWith('</svg>')); assert.ok(svg.includes('<polygon'));
  }
  const evil = toPreviewSvg({ ...generateAsset({ kind: 'crate' }), name: '<script>alert(1)</script>' });
  assert.ok(!evil.includes('<script>'));
});

test('textures PBR : résolutions autorisées, PNG cohérents et glTF en références externes', () => {
  const a = generateAsset({ kind: 'crate', texture_resolution: 128 });
  assert.equal(a.textureResolution, 128);
  const tex = generatePbrTextures(a.materials[0], 128);
  for (const png of [tex.baseColor, tex.normal, tex.orm]) {
    assert.equal(png.subarray(0, 8).toString('hex'), '89504e470d0a1a0a');
    assert.equal(png.readUInt32BE(16), 128); assert.equal(png.readUInt32BE(20), 128);
  }
  const gl = JSON.parse(toGltf(a));
  assert.ok(gl.images.every((im) => im.uri.endsWith('.png') && !im.uri.startsWith('data:')));
  assert.equal(gl.extras.pbr_textures.includes('128x128'), true);
  assert.equal(normalizeAssetParams({ texture_resolution: 2048 }).texture_resolution, 2048);
  assert.throws(() => normalizeAssetParams({ texture_resolution: 4096 }), (e) => e.status === 400);
});

test('kit : archétypes bornés, aucune fusion de monuments, erreur de forme limitée, un placement par bâtiment', () => {
  for (const cfg of [{ size: 'small', water: 'river' }, { size: 'medium', water: 'coast', theme: 'coastal' }, { size: 'large', water: 'none', theme: 'desert', target: 'pc' }]) {
    const w = generateWorld({ seed: 'plan', ...cfg }), plan = planKit(w, { maxArchetypes: 48 });
    assert.ok(plan.map.size <= 48, `${plan.map.size} archétypes`);
    assert.equal(plan.placements.length, w.buildings.length); assert.equal(new Set(plan.placements.map((p) => p.b.id)).size, w.buildings.length);
    for (const { key, b } of plan.placements) {
      const a = generateAsset(plan.map.get(key)), s = [b.footprint[0] / a.footprint[0], b.height / a.height, b.footprint[1] / a.footprint[1]];
      assert.ok(s.every((v) => v >= 0.7 && v <= 1.4), `${b.id} échelle ${s.map((x) => x.toFixed(2))}`);
    }
    const lm = w.buildings.filter((b) => b.landmark).length; assert.equal([...plan.map.values()].filter((p) => ['tower', 'cityhall', 'stadium', 'cathedral', 'museum', 'market', 'station'].includes(p.kind)).length >= Math.min(lm, 1), true);
  }
  const a = JSON.stringify([...planKit(generateWorld({ seed: 'd' }), {}).map]), b = JSON.stringify([...planKit(generateWorld({ seed: 'd' }), {}).map]);
  assert.equal(a, b, 'déterministe');
  assert.throws(() => planKit({ format: 'autre' }), (e) => e.status === 400);
});

// ------------------------------------------------------------- service + API
test('API : modèle généré, fichiers proposés puis approuvés, téléchargements sûrs, erreurs', async () => {
  const t = await boot();
  try {
    await t.api('POST', '/api/projects', { name: 'Mod' });
    const g = await t.api('POST', '/api/modeling/generate', { project_id: 'mod', params: { kind: 'cityhall', style: 'grès', floors: 5, width: 40, depth: 40, name: 'SM_mairie' } });
    assert.equal(g.status, 200); assert.equal(g.data.asset.valid, true); assert.equal(g.data.asset.files_mode, 'proposed'); assert.match(g.data.asset.folder, /^models\/sm-mairie-/);
    const ap = await pending(t, 'mod');
    const approvedNames = ap.map((a) => a.path.split('/').pop());
    for (const required of ['SM_mairie.gltf', 'SM_mairie.mtl', 'SM_mairie.ops-asset.json', 'SM_mairie_LOD0.obj', 'SM_mairie_preview.svg']) assert.ok(approvedNames.includes(required), required);
    assert.ok(approvedNames.some((n) => n.endsWith('_BaseColor.png'))); assert.ok(approvedNames.some((n) => n.endsWith('_Normal.png'))); assert.ok(approvedNames.some((n) => n.endsWith('_ORM.png')));
    assert.ok(ap.every((a) => a.agent_id === 'modeling'));
    const gl = ap.find((a) => a.path.endsWith('.gltf')); assert.equal((await t.api('POST', `/api/approvals/${gl.id}/approve`, {})).status, 200);
    const gltfDoc = JSON.parse(fs.readFileSync(path.join(t.dir, 'projects', 'mod', 'workspace', gl.path), 'utf8'));
    assert.ok(gltfDoc.images.every((im) => approvedNames.includes(path.basename(im.uri))), 'chaque image glTF doit être livrée comme PNG externe');
    const pngApproval = ap.find((a) => a.path.endsWith('_Normal.png')); assert.equal((await t.api('POST', `/api/approvals/${pngApproval.id}/approve`, {})).status, 200);
    assert.equal(fs.readFileSync(path.join(t.dir, 'projects', 'mod', 'workspace', pngApproval.path)).subarray(0, 8).toString('hex'), '89504e470d0a1a0a', 'l’approbation conserve le PNG en binaire');
    checkGltf(fs.readFileSync(path.join(t.dir, 'projects', 'mod', 'workspace', gl.path), 'utf8'));
    const id = g.data.asset.id, f = await dl(t, id, 'SM_mairie.gltf'); assert.equal(f.status, 200); checkGltf(f.text);
    const texName = approvedNames.find((n) => n.endsWith('_Normal.png'));
    const texRes = await fetch(`${t.base}/api/modeling/assets/${id}/download?file=${encodeURIComponent(texName)}`, { headers: { authorization: 'Bearer tok-test-123' } });
    assert.equal(texRes.status, 200); assert.ok(texRes.headers.get('content-type').startsWith('image/png')); assert.equal(Buffer.from(await texRes.arrayBuffer()).subarray(0, 8).toString('hex'), '89504e470d0a1a0a');
    assert.equal((await dl(t, id, '../../.token')).status, 404, 'seuls les fichiers de l’asset sont téléchargeables');
    assert.equal((await dl(t, id, 'inconnu.txt')).status, 404);
    assert.equal((await fetch(`${t.base}/api/modeling/assets/${id}/download?file=SM_mairie.gltf`)).status, 401);
    assert.equal((await t.api('GET', '/api/modeling/assets?project_id=mod')).data.length, 1);
    assert.equal((await t.api('GET', `/api/modeling/assets/${id}`)).data.stats.lods.length, 3);
    assert.equal((await t.api('GET', '/api/modeling/assets/zzz')).status, 404);
    assert.equal((await t.api('POST', '/api/modeling/generate', { project_id: 'mod', params: { kind: 'dragon' } })).status, 400);
    assert.equal((await t.api('POST', '/api/modeling/generate', { project_id: 'absent', params: {} })).status, 404);
    // asset invalide (budget) : enregistré mais fichiers non livrés
    const big = (await t.api('POST', '/api/modeling/generate', { project_id: 'mod', params: { kind: 'house', floors: 60, width: 80, depth: 80 } })).data;
    assert.equal(big.asset.valid, false); assert.equal(big.asset.files_mode, 'none'); assert.equal((await pending(t, 'mod')).filter((a) => /house/.test(a.path)).length, 0);
  } finally { await t.close(); }
});

test('API : mode « auto » écrit avec sauvegarde de version, nom de fichier sûr', async () => {
  const t = await boot();
  try {
    await t.api('POST', '/api/projects', { name: 'Auto', write_mode: 'auto' });
    const a = (await t.api('POST', '/api/modeling/generate', { project_id: 'auto', params: { kind: 'tree', name: '../../évasion' } })).data.asset;
    assert.equal(a.files_mode, 'written'); assert.ok(!a.folder.includes('..'));
    assert.ok(a.files.every((f) => !f.includes('/') && !f.includes('..')), a.files.join());
    assert.ok(fs.existsSync(path.join(t.dir, 'projects', 'auto', 'workspace', a.folder, a.files.find((f) => f.endsWith('.gltf')))));
    const autoPng = a.files.find((f) => f.endsWith('_BaseColor.png'));
    assert.equal(fs.readFileSync(path.join(t.dir, 'projects', 'auto', 'workspace', a.folder, autoPng)).subarray(0, 8).toString('hex'), '89504e470d0a1a0a', 'mode auto conserve les PNG en binaire');
    assert.ok((await t.api('GET', '/api/projects/auto/versions')).data.some((v) => /models\//.test(v.label)));
  } finally { await t.close(); }
});

test('API kit : monde WORLD → archétypes + placements + props (contrat ops-assets), limites et erreurs', async () => {
  const t = await boot();
  try {
    await t.api('POST', '/api/projects', { name: 'Kit' });
    assert.equal((await t.api('POST', '/api/modeling/kit', { project_id: 'kit', world_id: 'wld_absent' })).status, 404);
    const w = await mkWorld(t, 'kit');
    const k = await t.api('POST', '/api/modeling/kit', { project_id: 'kit', world_id: w.id });
    assert.equal(k.status, 200); assert.equal(k.data.asset.type, 'kit'); assert.equal(k.data.asset.valid, true, JSON.stringify(k.data.validation.issues));
    const st = k.data.asset.stats; assert.equal(st.buildings, w.stats.buildings); assert.ok(st.archetypes <= 48 && st.archetypes >= 4); assert.equal(st.props, 4);
    assert.ok(st.instanced_triangles.lod0 > st.instanced_triangles.lod1 && st.instanced_triangles.lod1 > st.instanced_triangles.lod2);
    const man = JSON.parse((await dl(t, k.data.asset.id, 'kit.ops-assets.json')).text);
    assert.equal(man.format, 'ops-assets'); assert.equal(man.version, 1); assert.equal(man.world.id, w.id);
    assert.equal(man.placements.length, w.stats.buildings);
    const names = new Set(man.assets.map((a) => a.name)); assert.ok(man.placements.every((p) => names.has(p.asset)));
    assert.equal(man.assets.reduce((n, a) => n + a.instances, 0), w.stats.buildings, 'chaque bâtiment est instancié exactement une fois');
    const world = JSON.parse((await (await fetch(`${t.base}/api/world/worlds/${w.id}/download?kind=json`, { headers: { authorization: 'Bearer tok-test-123' } })).text()));
    const byId = new Map(world.buildings.map((b) => [b.id, b]));
    for (const p of man.placements) { const b = byId.get(p.building_id); assert.deepEqual(p.position, b.position); assert.equal(p.rotation_y_deg, b.rotation); assert.ok(p.scale.every((s) => s >= 0.7 && s <= 1.4)); }
    for (const a of man.assets) { const gl = (await dl(t, k.data.asset.id, `${a.name}.gltf`)); assert.equal(gl.status, 200); checkGltf(gl.text); }
    assert.ok(man.materials.length >= 5 && man.materials.every((m) => /^MI_/.test(m.name)));
    assert.ok((await pending(t, 'kit')).filter((a) => a.agent_id === 'modeling').length >= man.assets.length * 2 + 3);
    // erreurs
    assert.equal((await t.api('POST', '/api/modeling/kit', { project_id: 'kit', world_id: w.id, max_archetypes: 2 })).status, 400);
    assert.equal((await t.api('POST', '/api/modeling/kit', { project_id: 'kit', world_id: w.id, max_archetypes: 4 })).status, 409, 'trop peu d’archétypes : refus honnête');
    await t.api('POST', '/api/projects', { name: 'Autre' });
    assert.equal((await t.api('POST', '/api/modeling/kit', { project_id: 'autre', world_id: w.id })).status, 404, 'monde d’un autre projet');
  } finally { await t.close(); }
});

test('brief → plan avec un fournisseur : asset ou kit ; sortie invalide, sans monde ou sans fournisseur : erreur honnête, rien créé', async () => {
  const none = await boot();
  try { await none.api('POST', '/api/projects', { name: 'P' }); assert.equal((await none.api('POST', '/api/modeling/from-brief', { project_id: 'p', brief: 'une maison' })).status, 502); assert.equal((await none.api('GET', '/api/modeling/assets')).data.length, 0); } finally { await none.close(); }
  const t = await bootWithStub();
  try {
    const pid = t.project.id;
    assert.equal((await t.api('POST', '/api/modeling/from-brief', { project_id: pid, brief: ' ' })).status, 400);
    const one = await t.api('POST', '/api/modeling/from-brief', { project_id: pid, brief: 'Une maison en brique' });
    assert.equal(one.status, 200); assert.equal(one.data.asset.name, 'SM_stub_house'); assert.equal(one.data.asset.params.style, 'brique'); assert.ok(!('evil' in one.data.asset.params));
    t.stub.st.modelScope = 'kit';
    assert.equal((await t.api('POST', '/api/modeling/from-brief', { project_id: pid, brief: 'kit' })).status, 409, 'aucun monde dans le projet');
    await mkWorld(t, pid);
    const kit = await t.api('POST', '/api/modeling/from-brief', { project_id: pid, brief: 'kit de la ville' });
    assert.equal(kit.status, 200); assert.equal(kit.data.asset.type, 'kit');
    for (const bad of ['pas du json', JSON.stringify({ scope: 'magie' }), JSON.stringify({ scope: 'asset', asset: { kind: 'dragon' } }), JSON.stringify({ scope: 'kit', max_archetypes: 1 }), '[1]']) {
      t.stub.st.badModelPlan = bad; const r = await t.api('POST', '/api/modeling/from-brief', { project_id: pid, brief: 'x' });
      assert.equal(r.status, 502, bad); assert.match(r.data.error, /MODELING AI/);
    }
    assert.equal((await t.api('GET', `/api/modeling/assets?project_id=${pid}`)).data.length, 2, 'aucun asset créé sur sortie invalide');
  } finally { await t.close(); }
});

test('chat direct avec MODELING AI : réponse réelle, modèle et kit par balises, échecs honnêtes, limite de 2', async () => {
  const t = await bootWithStub();
  try {
    const pid = t.project.id;
    assert.match((await t.api('POST', '/api/studio/modeling/chat', { project_id: pid, text: 'Bonjour' })).data.reply, /Réponse de MODELING AI/);
    const g = (await t.api('POST', '/api/studio/modeling/chat', { project_id: pid, text: 'Génère une tour' })).data;
    assert.equal(g.actions.length, 1); assert.ok(g.actions[0].ok); assert.match(g.reply, /Actions effectuées/);
    assert.equal((await t.api('GET', `/api/modeling/assets?project_id=${pid}`)).data[0].stats.kind, 'tower');
    const nokit = (await t.api('POST', '/api/studio/modeling/chat', { project_id: pid, text: 'fais un kit' })).data;
    assert.ok(!nokit.actions[0].ok, 'pas de monde : échec rapporté'); assert.match(nokit.reply, /⛔/);
    const w = await mkWorld(t, pid);
    const kit = (await t.api('POST', '/api/studio/modeling/chat', { project_id: pid, text: 'fais un kit' })).data;
    assert.ok(kit.actions[0].ok, JSON.stringify(kit.actions)); assert.match(kit.actions[0].detail, /archétypes/);
    assert.equal((await t.api('GET', `/api/modeling/assets?project_id=${pid}`)).data.filter((a) => a.world_id === w.id).length, 1);
    const bad = (await t.api('POST', '/api/studio/modeling/chat', { project_id: pid, text: 'invalide' })).data; assert.ok(!bad.actions[0].ok);
    const many = (await t.api('POST', '/api/studio/modeling/chat', { project_id: pid, text: 'trois caisses' })).data;
    assert.equal(many.actions.filter((a) => a.ok).length, 2); assert.ok(many.actions.some((a) => /ignorée/.test(a.detail)));
    assert.equal((await t.api('POST', '/api/studio/modeling/chat', { project_id: pid, text: ' ' })).status, 400);
  } finally { await t.close(); }
});

test('MODELING AI : construite, validable ; roster AAA complet', async () => {
  const t = await boot();
  try {
    const r = (await t.api('GET', '/api/studio')).data;
    assert.equal(r.find((a) => a.id === 'modeling').status, 'built'); assert.ok(r.find((a) => a.id === 'modeling').executable);
    assert.equal(r.filter((a) => a.executable).length, 13);
    assert.equal((await t.api('POST', '/api/studio/modeling/validate', {})).status, 200);
    assert.equal((await t.api('POST', '/api/studio/animation/validate', {})).status, 200);
    assert.equal((await t.api('POST', '/api/studio/animation/chat', { project_id: 'x', text: 'a' })).status, 404, 'IA active mais projet inexistant');
  } finally { await t.close(); }
});

// ------------------------------------------------------------- intégration : Director → WORLD → MODELING
test('collaboration : le plan « ville » enchaîne Director → WORLD → MODELING, le kit utilise le monde produit, messages remis', async () => {
  const t = await bootWithStub();
  try {
    const pid = t.project.id, run = (id) => t.api('POST', `/api/director/tasks/${id}/run`, {});
    const v = (await t.api('POST', '/api/director/plans', { project_id: pid, template: 'city' })).data;
    const spec = v.tasks.find((x) => x.title.includes('Cahier')), satellite = v.tasks.find((x) => x.assignee === 'satellite'), world = v.tasks.find((x) => x.assignee === 'world'), mod = v.tasks.find((x) => x.assignee === 'modeling');
    assert.equal((await run(mod.id)).status, 409, 'dépendances non terminées');
    assert.equal((await run(spec.id)).data.status, 'done');
    assert.equal((await run(satellite.id)).data.status, 'done');
    assert.equal((await run(world.id)).data.status, 'done');
    const worldId = (await t.api('GET', `/api/world/worlds?project_id=${pid}`)).data[0].id;
    // MODELING a reçu le handoff de WORLD (remis, pas en file d'attente)
    let inbox = (await t.api('GET', `/api/director/messages?project_id=${pid}&to=modeling`)).data;
    assert.ok(inbox.length >= 1 && inbox.every((m) => m.status === 'pending') && inbox.some((m) => m.from_ai === 'world'));
    t.stub.st.modelScope = 'kit';
    const r = await run(mod.id);
    assert.equal(r.status, 200); assert.equal(r.data.status, 'done');
    assert.match(r.data.result, /Kit de modèles/); assert.match(r.data.result, new RegExp(worldId)); assert.match(r.data.result, /Validation : OK/);
    const req = t.stub.st.requests.filter((q) => /Tu es OPS MODELING AI|OPS MODELING AI/.test(q.sys)).pop();
    assert.match(req.last, /PARAMÈTRES JSON/); assert.match(req.last, /Résultats précédents/); assert.match(req.last, new RegExp(worldId));
    inbox = (await t.api('GET', `/api/director/messages?project_id=${pid}&to=modeling`)).data; assert.ok(inbox.every((m) => m.status === 'read'));
    const kit = (await t.api('GET', `/api/modeling/assets?project_id=${pid}`)).data[0];
    assert.equal(kit.type, 'kit'); assert.equal(kit.world_id, worldId); assert.equal(kit.task_id, mod.id);
    // la suite (GRAPHICS) reçoit le handoff directement
    const q = (await t.api('GET', `/api/director/messages?project_id=${pid}&to=graphics`)).data;
    assert.ok(q.length >= 1 && q.every((m) => m.status === 'pending') && q.some((m) => m.from_ai === 'modeling' && /Kit de modèles/.test(m.body)));
    // sans monde dans le projet : la tâche MODELING échoue honnêtement et reste « à faire »
    await t.api('POST', '/api/projects', { name: 'Vide' });
    await t.api('PUT', '/api/studio/modeling', { model: 'stub-model' });
    const v2 = (await t.api('POST', '/api/director/plans', { project_id: 'vide', template: 'city' })).data;
    const sp2 = v2.tasks.find((x) => x.title.includes('Cahier')), sat2 = v2.tasks.find((x) => x.assignee === 'satellite'), w2 = v2.tasks.find((x) => x.assignee === 'world'), m2 = v2.tasks.find((x) => x.assignee === 'modeling');
    await run(sp2.id); await run(sat2.id);
    await t.api('PUT', `/api/director/tasks/${w2.id}`, { status: 'in_progress' }); await t.api('PUT', `/api/director/tasks/${w2.id}`, { status: 'done', result: 'fait à la main, sans génération' });
    const bad = await run(m2.id); assert.equal(bad.status, 409); assert.match(bad.data.error, /monde valide/);
    const again = (await t.api('GET', `/api/director/plans/${v2.plan.id}`)).data.tasks.find((x) => x.id === m2.id); assert.equal(again.status, 'todo'); assert.equal(again.state, 'ready');
    assert.equal((await t.api('GET', '/api/modeling/assets?project_id=vide')).data.length, 0);
  } finally { await t.close(); }
});


test('API sculpture : modifie un asset existant, conserve les trois LOD et met à jour les exports', async () => {
  const t = await boot();
  try {
    await t.api('POST', '/api/projects', { name: 'Sculpt' });
    const created = (await t.api('POST', '/api/modeling/generate', { project_id: 'sculpt', params: { kind: 'house', quality: 'high', floors: 3, width: 18, depth: 16 } })).data.asset;
    const before = JSON.parse((await dl(t, created.id, `${created.name}.gltf`)).text);
    const changed = await t.api('POST', `/api/modeling/assets/${created.id}/sculpt`, { operations: [{ mode: 'inflate', center: [0, 9, 0], radius: 30, strength: 0.1 }] });
    assert.equal(changed.status, 200, JSON.stringify(changed.data));
    assert.equal(changed.data.asset.stats.sculpted_lods, 3);
    assert.equal(changed.data.asset.stats.sculpt_operations, 1);
    const after = JSON.parse((await dl(t, created.id, `${created.name}.gltf`)).text);
    assert.notDeepEqual(after.accessors, before.accessors);
    assert.equal(changed.data.validation.ok, true);
    const appended = await t.api('POST', `/api/modeling/assets/${created.id}/sculpt`, { operations: [{ mode: 'smooth', center: [0, 9, 0], radius: 30, strength: 0.05 }] });
    assert.equal(appended.status, 200);
    assert.equal(appended.data.asset.stats.sculpt_operations, 2);
  } finally { await t.close(); }
});


test('matériaux PBR : couleur, metallic et roughness sont persistés dans glTF/MTL et survivent à la sculpture', async () => {
  const t = await boot();
  try {
    await t.app.ctx.workspace.createProject({ name: 'Matériaux', id: 'materiaux' });
    const created = (await t.app.ctx.modeling.generate({ project_id: 'materiaux', params: { kind: 'house', quality: 'high', floors: 3, width: 18, depth: 16 } })).asset;
    const detail = await t.app.ctx.modeling.get(created.id);
    assert.ok(detail.material_catalog.length >= 3);
    const edited = await t.app.ctx.modeling.updateMaterial({ asset_id: created.id, material_id: 'wall', patch: { baseColor: [0.12, 0.34, 0.56, 1], metallic: 0.72, roughness: 0.18 } });
    assert.deepEqual(edited.material.baseColor, [0.12, 0.34, 0.56, 1]);
    const gltfFile = await t.app.ctx.modeling.file(created.id, `${created.name}.gltf`);
    const gltf = JSON.parse(gltfFile.buf.toString());
    const wall = gltf.materials.find(m => m.name === 'MI_wall_béton');
    assert.deepEqual(wall.pbrMetallicRoughness.baseColorFactor, [0.12, 0.34, 0.56, 1]);
    assert.equal(wall.pbrMetallicRoughness.metallicFactor, 0.72);
    assert.equal(wall.pbrMetallicRoughness.roughnessFactor, 0.18);
    const mtl = (await t.app.ctx.modeling.file(created.id, `${created.name}.mtl`)).buf.toString();
    assert.match(mtl, /Ks 0.72 0.72 0.72/);
    await assert.rejects(() => t.app.ctx.modeling.updateMaterial({ asset_id: created.id, material_id: 'wall', patch: { roughness: 2 } }), /roughness doit être compris/);
    const sculpt = await t.app.ctx.modeling.sculpt({ asset_id: created.id, operations: [{ mode: 'inflate', center: [0, 9, 0], radius: 30, strength: 0.08 }] });
    assert.equal(sculpt.validation.ok, true);
    const after = JSON.parse((await t.app.ctx.modeling.file(created.id, `${created.name}.gltf`)).buf.toString());
    const afterWall = after.materials.find(m => m.name === 'MI_wall_béton');
    assert.deepEqual(afterWall.pbrMetallicRoughness.baseColorFactor, [0.12, 0.34, 0.56, 1]);
    assert.equal(afterWall.pbrMetallicRoughness.metallicFactor, 0.72);
    assert.equal(afterWall.pbrMetallicRoughness.roughnessFactor, 0.18);
    const geometryAfterSculpt = after.accessors;
    await t.app.ctx.modeling.updateMaterial({ asset_id: created.id, material_id: 'wall', patch: { metallic: 0.64 } });
    const afterMaterialSecondEdit = JSON.parse((await t.app.ctx.modeling.file(created.id, `${created.name}.gltf`)).buf.toString());
    assert.deepEqual(afterMaterialSecondEdit.accessors, geometryAfterSculpt, 'une édition matériau ne doit pas effacer la sculpture existante');
    assert.equal(afterMaterialSecondEdit.materials.find(m => m.name === 'MI_wall_béton').pbrMetallicRoughness.metallicFactor, 0.64);
  } finally { await t.close(); }
});
