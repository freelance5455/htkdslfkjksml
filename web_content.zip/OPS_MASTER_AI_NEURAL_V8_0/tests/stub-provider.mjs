import http from 'node:http';

/**
 * FIXTURE DE TEST UNIQUEMENT — petit serveur qui parle le protocole OpenAI /chat/completions (et /models).
 * Il n'est jamais utilisé par le produit : il permet de tester l'orchestration de bout en bout sans réseau ni clé réelle.
 */
export async function startStub({ key = 'test-key' } = {}) {
  const st = { requests: [], inflight: 0, peak: 0, flaky429: 0, garbagePlan: false, reviewIssue: null, mixedCoder: false, patchCoder: false, requestHandoff: false, delay: 120 };
  const server = http.createServer(async (req, res) => {
    const chunks = []; for await (const c of req) chunks.push(c);
    const body = chunks.length ? JSON.parse(Buffer.concat(chunks).toString()) : {};
    const send = (code, obj) => { res.writeHead(code, { 'content-type': 'application/json' }); res.end(JSON.stringify(obj)); };
    if (req.headers.authorization !== `Bearer ${key}`) return send(401, { error: { message: 'Invalid API key' } });
    if (req.url.endsWith('/models')) return send(200, { data: [{ id: 'stub-model' }, { id: 'stub-big' }] });
    if (!req.url.endsWith('/chat/completions')) return send(404, { error: { message: 'not found' } });
    if (st.flaky429 > 0) { st.flaky429--; return send(429, { error: { message: 'rate limited' } }); }
    const sys = body.messages.find((m) => m.role === 'system')?.content || '';
    const user = body.messages.filter((m) => m.role === 'user').map((m) => m.content).join('\n');
    const last = body.messages[body.messages.length - 1].content;
    st.requests.push({ model: body.model, sys: sys.slice(0, 80), user, last });
    const reply = (text) => send(200, { choices: [{ message: { role: 'assistant', content: text } }], usage: { prompt_tokens: 50, completion_tokens: 20 } });
    const agentCall = /Tu es OPS (CODE ARCHITECT|FRONTEND|BACKEND|SENIOR DEBUG)/.test(sys);
    if (agentCall) { st.inflight++; st.peak = Math.max(st.peak, st.inflight); await new Promise((r) => setTimeout(r, st.delay)); st.inflight--; }

    if (/Réponds UNIQUEMENT par un objet JSON/.test(user) && /subtasks/.test(user)) {
      if (st.garbagePlan) return reply('Voici mon plan en prose, pas de JSON.');
      return reply(JSON.stringify({ summary: 'Plan de test', subtasks: [
        { id: 't1', title: 'Architecture', agent: 'architect', instruction: 'Conçois la structure.', depends_on: [] },
        { id: 't2', title: 'Interface', agent: 'frontend', instruction: "Écris l'interface.", depends_on: ['t1'] },
        { id: 't3', title: 'API', agent: 'backend', instruction: "Écris l'API.", depends_on: ['t1'] },
      ] }));
    }
    if (/PLAN DE PRODUCTION JSON/.test(user)) {
      if (st.badDirectorPlan) return reply(st.badDirectorPlan);
      return reply(JSON.stringify({ tasks: [
        { key: 'a', assignee: 'director', title: 'Cadrage', description: 'cadrer', depends_on: [], estimate_h: 2 },
        { key: 'b', assignee: 'world', title: 'Monde', description: 'monde', depends_on: ['a'], estimate_h: 8 },
        { key: 'c', assignee: 'qa', title: 'Tests', description: 'tests', depends_on: ['b'], estimate_h: 4 },
        { key: 'd', assignee: 'director', title: 'Bilan', description: 'bilan', depends_on: ['c'], estimate_h: 1 } ] }));
    }
    if (/Tu es OPS CODER AI/.test(sys) && st.patchCoder) return reply('Modification ciblée livrée.\n<ops-patch path="src/existing.js">[{"find":"export const value = 1;","replace":"export const value = 2;"}]</ops-patch>');
    if (/Tu es OPS CODER AI/.test(sys) && st.mixedCoder) {
      if (/ops-result/.test(last)) return reply('Inspection reçue, implémentation finalisée.\n<ops-file path="src/real-code.js">export function add(a, b) { return a + b; }</ops-file>');
      return reply('<ops-tool>{"tool":"inspect_project"}</ops-tool>\n<ops-file path="src/real-code.js">export function add(a, b) { return Number(a) + Number(b); }</ops-file>');
    }
    if (/Tu es OPS WORLD AI/.test(sys)) {
      if (/PARAMÈTRES JSON/.test(last)) return reply(st.badWorldParams || JSON.stringify({ name: 'Ville stub', seed: 'stub', size: 'small', theme: 'modern', water: 'river', density: 0.7, landmarks: 2, target: 'mobile', hack: 'ignoré' }));
      if (/MODE CONVERSATION DIRECTE/.test(sys)) {
        if (/génère/i.test(last)) return reply('Je génère.\n<ops-generate name="Ville chat" seed="s1" size="small" water="none"/>');
        if (/invalide/i.test(last)) return reply('Essai.\n<ops-generate size="gigantic"/>');
        if (/trois/i.test(last)) return reply(Array.from({ length: 3 }, (_, i) => `<ops-generate name="v${i}" seed="q${i}" size="small"/>`).join(''));
        return reply('Réponse de WORLD AI.');
      }
    }
    if (/Tu es OPS MODELING AI/.test(sys)) {
      if (/PARAMÈTRES JSON/.test(last)) {
        if (st.badModelPlan) return reply(st.badModelPlan);
        if (st.modelScope === 'kit') return reply(JSON.stringify({ scope: 'kit', max_archetypes: 48 }));
        return reply(JSON.stringify({ scope: 'asset', asset: { kind: 'house', style: 'brique', floors: 2, width: 12, depth: 10, name: 'SM_stub_house', evil: 'ignoré' } }));
      }
      if (/MODE CONVERSATION DIRECTE/.test(sys)) {
        if (/kit/i.test(last)) return reply(`Je fabrique le kit.\n<ops-kit world="${sys.match(/"id":"(wld_\w+)"/)?.[1] || 'wld_inconnu'}" max="48"/>`);
        if (/génère/i.test(last)) return reply('Je modélise.\n<ops-model kind="tower" style="verre" floors="20" width="30" depth="30"/>');
        if (/invalide/i.test(last)) return reply('Essai.\n<ops-model kind="dragon"/>');
        if (/trois/i.test(last)) return reply(Array.from({ length: 3 }, () => '<ops-model kind="crate"/>').join(''));
        return reply('Réponse de MODELING AI.');
      }
    }
    if (/OPS DIRECTOR AI/.test(sys) && /Produis le livrable/.test(last)) return reply(`LIVRABLE-DIRECTOR ${/RÉSULTATS DES TÂCHES PRÉCÉDENTES/.test(last) ? '(avec résultats précédents)' : ''}`);
    if (/MODE CONVERSATION DIRECTE/.test(sys)) {
      st.directorSeen = body.messages.map((m) => m.content);
      if (/crée une ville/i.test(last)) return reply('Je lance le plan.\n<ops-plan template="city" title="Ville du chat"/>\n<ops-decision title="Cible">30 fps mobile</ops-decision>\n<ops-send to="animation" kind="request">Prépare le plan de ville</ops-send>');
      if (/actions invalides/i.test(last)) return reply('Voilà.\n<ops-plan template="inconnu"/>\n<ops-send to="robot">x</ops-send>\n<ops-task plan="plan_absent">t</ops-task>');
      if (/trop d.actions/i.test(last)) return reply(Array.from({ length: 7 }, (_, i) => `<ops-decision title="d${i}">b</ops-decision>`).join(''));
      return reply(`Réponse du Director (${body.messages.filter((m) => m.role === 'user').length} message(s) utilisateur).`);
    }
    if (/Relis de façon critique/.test(user)) {
      if (st.reviewIssue) { const id = user.match(/### (task_\w+)/)?.[1]; const issue = st.reviewIssue; st.reviewIssue = null; return reply(JSON.stringify({ verdict: 'problemes', issues: [{ task_id: id, problem: issue, fix: 'Corrige.' }] })); }
      return reply(JSON.stringify({ verdict: 'ok', summary: 'RAS', issues: [] }));
    }
    if (/Rédige le rapport final/.test(last)) return reply('# Rapport final\nSynthèse de test.');
    if (/CODE ARCHITECT/.test(sys)) return reply('Architecture définie.\n<ops-memory key="stack">node+sqlite</ops-memory>\n<ops-file path="docs/archi.md">\n# Architecture\n</ops-file>' + (st.requestHandoff ? '\n<ops-request agent="npc">Définis le contrat de navigation des PNJ avec WORLD.</ops-request>' : ''));
    if (/FRONTEND/.test(sys) || /BACKEND/.test(sys)) {
      const fe = /FRONTEND/.test(sys);
      if (/Versions en conflit/.test(last)) return reply('Versions fusionnées.\n<ops-file path="shared.txt">version fusionnée</ops-file>');
      if (/Correction :/.test(last)) return reply('Corrigé.\n<ops-file path="fixed.txt">ok</ops-file>');
      return reply(`${fe ? 'UI' : 'API'} faite.\n<ops-file path="${fe ? 'web/index.html' : 'api/server.js'}">${fe ? '<h1>OPS</h1>' : 'export const ok = true;'}</ops-file>\n<ops-file path="shared.txt">version ${fe ? 'frontend' : 'backend'}</ops-file>`);
    }
    if (/SENIOR DEBUG/.test(sys)) {
      if (!/ops-result/.test(last)) return reply('<ops-tool>{"tool":"read_file","path":"a.js"}</ops-tool>');
      return reply(`J'ai lu le fichier : ${last.includes('SECRET_MARKER') ? 'marqueur trouvé' : 'rien'}`);
    }
    return reply('Réponse de test.');
  });
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  return { st, key, url: `http://127.0.0.1:${server.address().port}/v1`, close: () => new Promise((r) => server.close(r)) };
}
