import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const app = fs.readFileSync(new URL('../public/app.js', import.meta.url), 'utf8');

test('V6.1 expose le manifeste dans la navigation et relie les actions à l’API authentifiée', () => {
  assert.match(app, /\['release', '📦', 'Manifeste de livraison'\]/);
  assert.match(app, /SCREENS\.release =/);
  assert.match(app, /\/release-manifest`/);
  assert.match(app, /\/release-manifest\/snapshot`/);
  assert.match(app, /release-files/);
  assert.match(app, /snapshot désactivé|Snapshot désactivé/);
});

test('V6.2 expose les profils de qualité géométrique dans MODELING AI', () => {
  assert.match(app, /const QUALITIES = \['balanced', \x27high\x27, \x27ultra\x27\]/);
  assert.match(app, /Profil de qualité/);
  assert.match(app, /qualité \$\{s\.quality/);
});

test('V6.4 expose la résolution des textures PBR et la plage 64–2048 dans MODELING AI', () => {
  const app = fs.readFileSync(new URL('../public/app.js', import.meta.url), 'utf8');
  assert.match(app, /texture_resolution: opt\('512', \['64','128','256','512','1024','2048'\]\)/);
  assert.match(app, /Résolution PBR/);
});

test('V6.6 expose un éditeur de sculpture relié à l’API avec contrôles de pinceau', () => {
  assert.match(app, /\['sculpt', 'Éditeur de sculpture'\]/);
  assert.match(app, /\/api\/modeling\/assets\/\$\{a\.id\}\/sculpt/);
  assert.match(app, /inflate.*smooth.*flatten/);
  assert.match(app, /Centre X/);
  assert.match(app, /recalcul des normales/);
});

test('V6.7 fournit un viewport WebGL 2 glTF avec rotation tactile, zoom et rendu du LOD0', () => {
  assert.match(app, /getContext\('webgl2'/);
  assert.match(app, /pointerdown/);
  assert.match(app, /pinchDistance/);
  assert.match(app, /drawElements\(gl\.TRIANGLES/);
  assert.match(app, /ops_lod===0/);
  assert.match(app, /endsWith\('\.gltf'\)/);
});


test('V6.8 permet de sélectionner un sommet du viewport tactile et de centrer le pinceau en mètres', () => {
  assert.match(app, /Sculpter en glissant sur la surface/);
  assert.match(app, /const pickVertex =/);
  assert.match(app, /Surface sélectionnée/);
  assert.match(app, /touchSculpt\.checked/);
  assert.match(app, /glState\.modelTransform/);
});


test('V6.9 détecte les surfaces par triangle et profondeur puis applique un trait tactile borné', () => {
  assert.match(app, /const pickSurface =/);
  assert.match(app, /const barycentric =/);
  assert.match(app, /nearest=depth/);
  assert.match(app, /indices:idx/);
  assert.match(app, /const applyStroke = async/);
  assert.match(app, /stroke\.length>=32/);
  assert.match(app, /Sculpter en glissant sur la surface/);
});


test('V7.0 charge les maps PBR BaseColor, Normal et ORM dans le viewport WebGL', () => {
  assert.match(app, /uNormalMap/);
  assert.match(app, /uHasBase/);
  assert.match(app, /uHasNormal/);
  assert.match(app, /uHasORM/);
  assert.match(app, /createImageBitmap/);
  assert.match(app, /TEXCOORD_0/);
  assert.match(app, /gl\.activeTexture/);
  assert.match(app, /Éditeur de sculpture 3D — PBR/);
});


test('V7.1 ajoute un éclairage studio procédural et des réglages de matériau en temps réel', () => {
  assert.match(app, /uEnvStrength/);
  assert.match(app, /uKeyStrength/);
  assert.match(app, /uRoughnessBias/);
  assert.match(app, /uMetalBoost/);
  assert.match(app, /Éclairage studio/);
  assert.match(app, /Environnement procédural stylisé/);
});


test('V7.2 ajoute une bibliothèque de presets PBR et la sauvegarde locale par projet', () => {
  assert.match(app, /Bibliothèque de matériaux/);
  assert.match(app, /Béton mat/);
  assert.match(app, /Métal poli/);
  assert.match(app, /Bois verni/);
  assert.match(app, /Caoutchouc/);
  assert.match(app, /ops\.material-presets\./);
  assert.match(app, /Enregistrer le preset/);
  assert.match(app, /Appliquer au modèle/);
  assert.match(app, /localStorage\.setItem/);
  assert.match(app, /fichiers glTF originaux restent inchangés/);
});


test('V7.3 ajoute un éditeur PBR persistant avec écriture glTF/MTL et conservation des sculptures', () => {
  assert.match(app, /Édition PBR persistante/);
  assert.match(app, /Couleur BaseColor/);
  assert.match(app, /Enregistrer le matériau/);
  assert.match(app, /materialMetal/);
  assert.match(app, /materialRough/);
  assert.match(app, /uRoughFactor/);
  assert.match(app, /uMetalFactor/);
});
