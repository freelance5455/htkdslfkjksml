import test from 'node:test';
import assert from 'node:assert/strict';
import { buildProjectManagerReport } from '../server/project-manager.mjs';
import { boot } from './helpers.mjs';

test('Project Manager agrège blocages, tâches anciennes, charge agents et réservations', () => {
  const now = 2_000_000;
  const r = buildProjectManagerReport({
    project:{id:'p1',name:'OPS'}, now,
    tasks:[{id:'t1',title:'Compilation',agent_id:'coder',status:'running',updated:now-30*60_000,depends_on:'[]'}, {id:'t2',title:'Collision',agent_id:'physics',status:'blocked',updated:now-1000,error:'contrat absent',depends_on:'[]'}],
    directorTasks:[{id:'d1',title:'Créer la ville',assignee:'world',status:'queued',priority:5,updated:now-1000,depends_on:'[]'}],
    workItems:[{id:'w1',title:'Créer les bâtiments',to_agent:'modeling',from_agent:'world',status:'queued',updated:now,depends_on:'[]'}],
    agents:[{id:'coder',name:'CODER',enabled:1},{id:'world',name:'WORLD',enabled:1},{id:'physics',name:'PHYSICS',enabled:1},{id:'modeling',name:'MODELING',enabled:1}],
    dependencies:[{prerequisite:'world',dependent:'modeling',contract:'ops-world'}],
    claims:[{path:'src/city.js',agent_id:'world',status:'active'}],
  });
  assert.equal(r.schema,'ops.project-manager.v1');
  assert.equal(r.summary.blocked,1);
  assert.equal(r.summary.stale,1);
  assert.equal(r.summary.active_file_claims,1);
  assert.ok(r.recommendations.some(x=>x.code==='STALE_TASK'));
  assert.ok(r.recommendations.some(x=>x.code==='BLOCKED_TASK'));
  assert.equal(r.dependencies[0].contract,'ops-world');
  assert.ok(!r.available_agents.some(x=>x.id==='coder'));
});

test('API Project Manager expose le rapport et refuse une transmission vers agent indisponible', async () => {
  const t=await boot();
  try {
    const p=await t.api('POST','/api/projects',{name:'Manager test'});
    const report=await t.api('GET',`/api/projects/${p.data.id}/manager`);
    assert.equal(report.status,200);
    assert.equal(report.data.schema,'ops.project-manager.v1');
    const a=await t.api('POST',`/api/projects/${p.data.id}/manager/dispatch`,{to:'unknown',title:'Test',instruction:'Faire le test'});
    assert.equal(a.status,409);
  } finally { await t.close(); }
});
