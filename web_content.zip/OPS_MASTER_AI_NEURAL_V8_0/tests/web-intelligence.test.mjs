import test from 'node:test';
import assert from 'node:assert/strict';
import { normalizeSearchResults, isPrivateIp } from '../server/web.mjs';

test('recherche Web : normalise, déduplique et borne les sources', () => {
  const rows = normalizeSearchResults([
    { title: 'Doc', url: 'https://example.com/docs', snippet: 'A' },
    { title: 'Duplicate', url: 'https://example.com/docs', snippet: 'B' },
    { title: 'Bad protocol', url: 'javascript:alert(1)' },
    { title: 'Second', url: 'https://example.org', snippet: 'C' },
  ], 5);
  assert.equal(rows.length, 2);
  assert.equal(rows[0].url, 'https://example.com/docs');
  assert.equal(rows[1].url, 'https://example.org/');
});

test('recherche Web : limite le nombre de résultats à dix', () => {
  const rows = Array.from({ length: 20 }, (_, i) => ({ title: `T${i}`, url: `https://example${i}.com` }));
  assert.equal(normalizeSearchResults(rows, 100).length, 10);
});

test('protection réseau : refuse les adresses locales et privées', () => {
  for (const ip of ['127.0.0.1', '10.0.0.2', '192.168.1.1', '169.254.1.1', '::1', 'fc00::1']) assert.equal(isPrivateIp(ip), true, ip);
  assert.equal(isPrivateIp('8.8.8.8'), false);
});
