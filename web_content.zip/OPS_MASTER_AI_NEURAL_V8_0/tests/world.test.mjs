import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { boot, bootWithStub } from './helpers.mjs';
import { generateWorld, validateWorld, normalizeParams, toObj, toSvg, SIZES, THEMES, TARGETS } from '../server/worldgen.mjs';

const dl = async (t, id, kind) => { const r = await fetch(`${t.base}/api/world/worlds/${id}/download?kind=${kind}`, { headers: { authorization: 'Bearer tok-test-123' } }); return { status: r.status, text: await r.text(), type: r.headers.get('content-type') }; };
const pending = async (t, pid) => (await t.api('GET', `/api/approvals?project_id=${pid}`)).data;

// ------------------------------------------------------------- générateur (fonctions pures)
test('générateur : déterministe (même graine = même monde), graines différentes = mondes différents', () => {
  const a = JSON.stringify(generateWorld({ seed: 'alpha', size: 'small' })), b = JSON.stringify(generateWorld({ seed: 'alpha', size: 'small' }));
  assert.equal(a, b);
  assert.notEqual(a, JSON.stringify(generateWorld({ seed: 'beta', size: 'small' })));
  const w = generateWorld({ seed: 'alpha', size: 'small' });
  assert.equal(w.format, 'ops-world'); assert.equal(w.version, 1);
  assert.equal(w.grid.length, SIZES.small); assert.ok(w.grid.every((r) => r.length === SIZES.small));
  assert.equal(w.terrain.heights.length, (SIZES.small + 1) ** 2);
});

test('générateur : monde valide sur toutes les combinaisons taille × eau × thème × graine', () => {
  let n = 0;
  for (const size of Object.keys(SIZES)) for (const water of ['none', 'river', 'coast']) for (const theme of Object.keys(THEMES)) for (const seed of ['a', 'zz9']) {
    const w = generateWorld({ seed, size, water, theme, target: size === 'large' ? 'pc' : 'mobile' }); n++;
    assert.ok(w.validation.ok, `${size}/${water}/${theme}/${seed} : ${w.validation.issues.map((i) => i.msg).join(' ; ')}`);
    assert.ok(w.stats.buildings > 0 || w.stats.water_ratio > 0.5, `${size}/${water}/${theme}/${seed} sans bâtiment`);
  }
  assert.equal(n, 3 * 3 * 5 * 2);
});

test('générateur : paramètres invalides refusés (400), valeurs par défaut, budget mobile respecté, monuments conservés', () => {
  for (const bad of [{ size: 'gigantic' }, { theme: 'lave' }, { water: 'lac' }, { target: 'ps5' }, { density: 5 }, { districts: 1 }, { landmarks: 99 }, { density: 'beaucoup' }]) {
    assert.throws(() => normalizeParams(bad), (e) => e.status === 400, JSON.stringify(bad));
  }
  const d = normalizeParams({}); assert.equal(d.size, 'medium'); assert.equal(d.target, 'mobile');
  const big = generateWorld({ seed: 'budget', size: 'large', density: 1, target: 'mobile', landmarks: 5 });
  assert.ok(big.buildings.length <= TARGETS.mobile.maxBuildings, 'budget mobile');
  assert.ok(big.stats.trimmed > 0, 'des bâtiments ont été retirés pour tenir le budget');
  assert.equal(big.buildings.filter((b) => b.landmark).length, 5, 'les monuments ne sont jamais retirés');
  assert.ok(big.validation.ok);
  const low = generateWorld({ seed: 'x', size: 'small', density: 0.1 }), high = generateWorld({ seed: 'x', size: 'small', density: 1 });
  assert.ok(high.buildings.length > low.buildings.length, 'la densité joue');
});

test('validateWorld : détecte réellement les défauts (chevauchement, route, eau, ponts, réseau coupé, budget)', () => {
  const base = () => JSON.parse(JSON.stringify(generateWorld({ seed: 'val', size: 'medium', water: 'river' })));
  assert.ok(validateWorld(base()).ok);
  const has = (w, re) => validateWorld(w).issues.some((i) => i.level === 'error' && re.test(i.msg));
  // chevauchement
  let w = base(); w.buildings.push({ ...w.buildings[0], id: 'dup' }); assert.ok(has(w, /chevauche/));
  // bâtiment sur une route
  w = base(); const r = w.roads.find((x) => x.type === 'R'); w.buildings.push({ ...w.buildings[0], id: 'surroute', span: 1, cell: [r.x, r.z] }); assert.ok(has(w, /non constructible/));
  // hors carte
  w = base(); w.buildings[0].cell = [999, 999]; assert.ok(has(w, /hors de la carte/));
  // bâtiment sans route adjacente
  w = base(); let spot = null;
  for (let z = 2; z < w.grid.length && !spot; z += 4) for (let x = 2; x < w.grid.length; x += 4) if (w.grid[z][x] === '.' && !w.buildings.some((b) => b.cell[0] === x && b.cell[1] === z)) { spot = [x, z]; break; }
  assert.ok(spot, 'cour intérieure libre'); w.buildings.push({ ...w.buildings[0], id: 'isole', span: 1, cell: spot }); assert.ok(has(w, /adjacent/));
  // réseau routier coupé : on retire une cellule de route d'une artère
  w = base(); const cut = w.grid.map((l) => l.split('')); let removed = 0;
  for (let x = 0; x < cut.length && removed < 40; x++) if ('RAB'.includes(cut[8][x]) && x > 4) { cut[8][x] = '.'; removed++; }
  w.grid = cut.map((l) => l.join('')); assert.ok(has(w, /non connexe|non constructible|adjacent/) || validateWorld(w).ok === false);
  // pont sans eau
  w = base(); const road = w.roads.find((x) => x.type === 'R'); road.type = 'B'; w.grid[road.z] = w.grid[road.z].slice(0, road.x) + 'B' + w.grid[road.z].slice(road.x + 1);
  assert.ok(has(w, /sans eau/));
  // budget
  w = base(); w.params.target = 'mobile'; while (w.buildings.length <= TARGETS.mobile.maxBuildings) w.buildings.push({ ...w.buildings[0], id: 'x' + w.buildings.length }); assert.ok(has(w, /budget bâtiments/));
  // dimensions
  w = base(); w.buildings[0].height = 0; assert.ok(has(w, /dimensions invalides/));
});

test('exports : OBJ cohérent (indices de faces valides), SVG bien formé, JSON relisible', () => {
  const w = generateWorld({ seed: 'exp', size: 'small' });
  const obj = toObj(w).split('\n');
  const v = obj.filter((l) => l.startsWith('v ')).length;
  const faces = obj.filter((l) => l.startsWith('f '));
  assert.ok(v > 0 && faces.length > 0);
  for (const f of faces) for (const i of f.slice(2).split(' ').map(Number)) assert.ok(Number.isInteger(i) && i >= 1 && i <= v, `face invalide : ${f}`);
  assert.ok(obj.every((l) => !/NaN|undefined|Infinity/.test(l)));
  assert.equal(obj.filter((l) => l.startsWith('o building_')).length, w.buildings.length);
  const svg = toSvg(w);
  assert.match(svg, /^<svg [^>]*xmlns="http:\/\/www\.w3\.org\/2000\/svg"/); assert.ok(svg.endsWith('</svg>'));
  assert.equal((svg.match(/<title>/g) || []).length, w.buildings.length + 1);
  const evil = toSvg({ ...w, name: '<script>alert(1)</script>' });
  assert.ok(!evil.includes('<script>'), 'nom échappé dans le SVG');
  assert.deepEqual(JSON.parse(JSON.stringify(w)).stats, w.stats);
});

// ------------------------------------------------------------- service + API
test('API : génération réelle, fichiers proposés puis approuvés, téléchargements, erreurs', async () => {
  const t = await boot();
  try {
    await t.api('POST', '/api/projects', { name: 'Monde' });
    const g = await t.api('POST', '/api/world/generate', { project_id: 'monde', params: { name: 'Ville Test', seed: 's1', size: 'small', water: 'none' } });
    assert.equal(g.status, 200); assert.equal(g.data.world.valid, true); assert.equal(g.data.world.files_mode, 'proposed');
    assert.match(g.data.world.folder, /^world\/ville-test-/);
    const ap = await pending(t, 'monde');
    assert.deepEqual(ap.map((a) => a.path.split('/').pop()).sort(), ['README.md', 'preview.svg', 'world.json', 'world.obj']);
    assert.ok(ap.every((a) => a.agent_id === 'world'));
    // rien n'est écrit tant que non approuvé
    assert.equal((await t.api('GET', '/api/projects/monde/files')).data.length ?? 0, 0);
    const json = ap.find((a) => a.path.endsWith('world.json'));
    assert.equal((await t.api('POST', `/api/approvals/${json.id}/approve`, {})).status, 200);
    const onDisk = path.join(t.dir, 'projects', 'monde', 'workspace', json.path);
    assert.equal(JSON.parse(fs.readFileSync(onDisk, 'utf8')).seed, 's1');
    // téléchargements
    const id = g.data.world.id;
    const j = await dl(t, id, 'json'); assert.equal(j.status, 200); assert.equal(JSON.parse(j.text).format, 'ops-world');
    const o = await dl(t, id, 'obj'); assert.equal(o.status, 200); assert.match(o.text, /^# OPS WORLD AI/);
    const s = await dl(t, id, 'svg'); assert.equal(s.status, 200); assert.match(s.text, /^<svg/);
    assert.equal((await dl(t, id, 'exe')).status, 400);
    assert.equal((await t.api('GET', '/api/world/worlds/inconnu')).status, 404);
    assert.equal((await (await fetch(`${t.base}/api/world/worlds/${id}/download?kind=json`)).status), 401, 'authentification requise');
    // liste / détail
    assert.equal((await t.api('GET', '/api/world/worlds?project_id=monde')).data.length, 1);
    assert.equal((await t.api('GET', `/api/world/worlds/${id}`)).data.stats.buildings, g.data.world.stats.buildings);
    // même graine = même monde via l'API
    const g2 = await t.api('POST', '/api/world/generate', { project_id: 'monde', params: { name: 'Ville Test', seed: 's1', size: 'small', water: 'none' } });
    assert.equal((await dl(t, g2.data.world.id, 'json')).text, j.text);
    // erreurs
    assert.equal((await t.api('POST', '/api/world/generate', { project_id: 'monde', params: { size: 'gigantic' } })).status, 400);
    assert.equal((await t.api('POST', '/api/world/generate', { project_id: 'absent', params: {} })).status, 404);
  } finally { await t.close(); }
});

test('API : mode « auto » écrit directement avec une version de sauvegarde ; chemins sûrs', async () => {
  const t = await boot();
  try {
    await t.api('POST', '/api/projects', { name: 'Auto', write_mode: 'auto' });
    const g = (await t.api('POST', '/api/world/generate', { project_id: 'auto', params: { name: '../../évasion', seed: 'k', size: 'small' } })).data.world;
    assert.equal(g.files_mode, 'written');
    assert.ok(!g.folder.includes('..'), g.folder);
    assert.ok(fs.existsSync(path.join(t.dir, 'projects', 'auto', 'workspace', g.folder, 'world.obj')));
    assert.equal((await pending(t, 'auto')).length, 0);
    const versions = (await t.api('GET', '/api/projects/auto/versions')).data;
    assert.ok(versions.some((v) => /world\//.test(v.label)), 'sauvegarde avant écriture');
    assert.ok((await t.api('GET', '/api/journal?project_id=auto')).data.some((e) => e.action === 'world.generate'));
  } finally { await t.close(); }
});

test('brief → paramètres avec un fournisseur : validés, clés inconnues ignorées ; sortie invalide ou sans fournisseur : 502, rien créé', async () => {
  const none = await boot();
  try {
    await none.api('POST', '/api/projects', { name: 'P' });
    const r = await none.api('POST', '/api/world/from-brief', { project_id: 'p', brief: 'une ville' });
    assert.equal(r.status, 502); assert.equal((await none.api('GET', '/api/world/worlds')).data.length, 0);
  } finally { await none.close(); }
  const t = await bootWithStub();
  try {
    const pid = t.project.id;
    assert.equal((await t.api('POST', '/api/world/from-brief', { project_id: pid, brief: '  ' })).status, 400);
    const ok = await t.api('POST', '/api/world/from-brief', { project_id: pid, brief: 'Une petite ville moderne avec rivière' });
    assert.equal(ok.status, 200); assert.equal(ok.data.params.name, 'Ville stub'); assert.equal(ok.data.params.size, 'small'); assert.ok(!('hack' in ok.data.params));
    assert.equal(ok.data.world.valid, true);
    for (const bad of ['pas du json', JSON.stringify({ size: 'gigantic' }), '[1,2]']) {
      t.stub.st.badWorldParams = bad;
      const r = await t.api('POST', '/api/world/from-brief', { project_id: pid, brief: 'x' });
      assert.equal(r.status, 502, bad); assert.match(r.data.error, /WORLD AI/);
    }
    assert.equal((await t.api('GET', `/api/world/worlds?project_id=${pid}`)).data.length, 1, 'aucun monde créé sur sortie invalide');
  } finally { await t.close(); }
});

test('chat direct avec WORLD AI : réponse réelle, génération par balise, échecs honnêtes, limite de 2', async () => {
  const t = await bootWithStub();
  try {
    const pid = t.project.id;
    const hello = await t.api('POST', '/api/studio/world/chat', { project_id: pid, text: 'Bonjour' });
    assert.equal(hello.status, 200); assert.match(hello.data.reply, /Réponse de WORLD AI/);
    const g = (await t.api('POST', '/api/studio/world/chat', { project_id: pid, text: 'Génère une ville' })).data;
    assert.equal(g.actions.length, 1); assert.ok(g.actions[0].ok); assert.match(g.reply, /Actions effectuées/); assert.match(g.reply, /Ville chat/);
    const worlds = (await t.api('GET', `/api/world/worlds?project_id=${pid}`)).data;
    assert.equal(worlds.length, 1); assert.equal(worlds[0].seed, 's1'); assert.equal(worlds[0].id, g.actions[0].id);
    const bad = (await t.api('POST', '/api/studio/world/chat', { project_id: pid, text: 'invalide' })).data;
    assert.ok(!bad.actions[0].ok); assert.match(bad.reply, /⛔/); assert.equal((await t.api('GET', `/api/world/worlds?project_id=${pid}`)).data.length, 1);
    const many = (await t.api('POST', '/api/studio/world/chat', { project_id: pid, text: 'trois mondes' })).data;
    assert.equal(many.actions.filter((a) => a.ok).length, 2); assert.ok(many.actions.some((a) => /ignorée/.test(a.detail)));
    // historique propre à WORLD (distinct du Director)
    const hist = t.stub.st.requests.filter((r) => /OPS WORLD AI/.test(r.sys)).length;
    assert.ok(hist >= 4);
    assert.equal((await t.api('POST', '/api/studio/world/chat', { project_id: pid, text: ' ' })).status, 400);
    assert.equal((await t.api('POST', '/api/studio/world/chat', { project_id: 'absent', text: 'a' })).status, 404);
  } finally { await t.close(); }
});

test('WORLD AI : construite, validable, configurable ; messages en file d\'attente remis ; ANIMATION reste non construite', async () => {
  const t = await boot();
  try {
    const r = (await t.api('GET', '/api/studio')).data;
    assert.equal(r.find((a) => a.id === 'world').status, 'built'); assert.ok(r.find((a) => a.id === 'world').executable);
    assert.equal(r.find((a) => a.id === 'animation').status, 'built');
    assert.equal((await t.api('POST', '/api/studio/world/validate', {})).status, 200);
    assert.equal((await t.api('GET', '/api/studio')).data.find((a) => a.id === 'world').status, 'validated');
    assert.equal((await t.api('POST', '/api/studio/animation/validate', {})).status, 200);
    assert.equal((await t.api('POST', '/api/studio/animation/chat', { project_id: 'x', text: 'a' })).status, 404);
  } finally { await t.close(); }
});

// ------------------------------------------------------------- intégration Director ↔ WORLD
test('Director ↔ WORLD : le plan « ville » s\'exécute réellement, handoffs, boîte de réception, IA suivante en attente', async () => {
  const t = await bootWithStub();
  try {
    const pid = t.project.id;
    const v = (await t.api('POST', '/api/director/plans', { project_id: pid, template: 'city' })).data;
    const spec = v.tasks.find((x) => x.title.includes('Cahier')), satellite = v.tasks.find((x) => x.assignee === 'satellite'), world = v.tasks.find((x) => x.assignee === 'world');
    assert.ok(world, 'le plan ville contient une tâche WORLD');
    // dépendance non terminée : refus
    assert.equal((await t.api('POST', `/api/director/tasks/${world.id}/run`, {})).status, 409);
    const s = await t.api('POST', `/api/director/tasks/${spec.id}/run`, {}); assert.equal(s.data.status, 'done');
    assert.equal((await t.api('POST', `/api/director/tasks/${satellite.id}/run`, {})).data.status, 'done');
    // handoff du Director → WORLD : remis (WORLD est construite), non plus en file d'attente
    let inbox = (await t.api('GET', `/api/director/messages?project_id=${pid}&to=world`)).data;
    assert.ok(inbox.length >= 1 && inbox.every((m) => m.status === 'pending'));
    await t.api('POST', '/api/director/decisions', { project_id: pid, title: 'Cible', body: '30 fps mobile' });
    const run = await t.api('POST', `/api/director/tasks/${world.id}/run`, {});
    assert.equal(run.status, 200); assert.equal(run.data.status, 'done');
    assert.match(run.data.result, /Monde « Ville stub » généré par OPS WORLD AI/); assert.match(run.data.result, /Validation : OK/); assert.match(run.data.result, /proposés/);
    // le prompt du LLM contenait bien le contexte (résultat du cadrage + décision + message reçu)
    const req = t.stub.st.requests.filter((r) => /OPS WORLD AI/.test(r.sys)).pop();
    assert.match(req.last, /PARAMÈTRES JSON/); assert.match(req.last, /LIVRABLE-DIRECTOR/); assert.match(req.last, /30 fps mobile/); assert.match(req.last, /Messages reçus/);
    // message consommé
    inbox = (await t.api('GET', `/api/director/messages?project_id=${pid}&to=world`)).data;
    assert.ok(inbox.every((m) => m.status === 'read'));
    // fichiers proposés et monde rattaché à la tâche
    const worlds = (await t.api('GET', `/api/world/worlds?project_id=${pid}`)).data;
    assert.equal(worlds.length, 1); assert.equal(worlds[0].task_id, world.id);
    assert.equal((await pending(t, pid)).filter((a) => a.agent_id === 'world').length, 4);
    // handoff WORLD → MODELING : remis (MODELING est construite) ; GRAPHICS est construite mais attend encore ses dépendances
    const q = (await t.api('GET', `/api/director/messages?project_id=${pid}&to=modeling`)).data;
    assert.ok(q.length >= 1 && q.every((m) => m.status === 'pending') && q.some((m) => m.from_ai === 'world' && /Ville stub/.test(m.body)));
    const after = (await t.api('GET', `/api/director/plans/${v.plan.id}`)).data;
    assert.equal(after.tasks.find((x) => x.assignee === 'modeling').state, 'ready');
    const gfx = after.tasks.find((x) => x.assignee === 'graphics'); assert.notEqual(gfx.state, 'ready');
    assert.equal((await t.api('POST', `/api/director/tasks/${gfx.id}/run`, {})).status, 409);
    // échec du fournisseur / sortie invalide : la tâche revient à « à faire », rien d'inventé
    const v2 = (await t.api('POST', '/api/director/plans', { project_id: pid, template: 'city', title: 'Deuxième' })).data;
    const spec2 = v2.tasks.find((x) => x.title.includes('Cahier')), sat2 = v2.tasks.find((x) => x.assignee === 'satellite'), world2 = v2.tasks.find((x) => x.assignee === 'world');
    await t.api('POST', `/api/director/tasks/${spec2.id}/run`, {});
    await t.api('POST', `/api/director/tasks/${sat2.id}/run`, {});
    t.stub.st.badWorldParams = 'n’importe quoi';
    const bad = await t.api('POST', `/api/director/tasks/${world2.id}/run`, {});
    assert.equal(bad.status, 502);
    const again = (await t.api('GET', `/api/director/plans/${v2.plan.id}`)).data.tasks.find((x) => x.id === world2.id);
    assert.equal(again.status, 'todo'); assert.equal(again.state, 'ready');
    assert.equal((await t.api('GET', `/api/world/worlds?project_id=${pid}`)).data.length, 1);
  } finally { await t.close(); }
});
