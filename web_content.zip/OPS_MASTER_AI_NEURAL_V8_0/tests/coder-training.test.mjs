import test from 'node:test';
import assert from 'node:assert/strict';
import { CODER_CURRICULUM_VERSION, CODER_EXECUTION_RULES, buildCoderExecutionChecklist, buildCoderTrainingContext } from '../server/coder-training.mjs';
import { DEFAULT_AGENTS, systemPromptFor } from '../server/agents.mjs';

test('CODER curriculum 3.2 exposes concrete execution rules', () => {
  assert.equal(CODER_CURRICULUM_VERSION, '3.2.0');
  assert.ok(CODER_EXECUTION_RULES.length >= 7);
  const checklist = buildCoderExecutionChecklist();
  for (const phrase of ['Décomposition avant codage', 'Vérification incrémentale', 'Gestion de l’incertitude']) assert.ok(checklist.includes(phrase));
});

test('CODER system prompt includes reinforced implementation and verification protocol', () => {
  const coder = DEFAULT_AGENTS.find((agent) => agent.id === 'coder');
  const prompt = systemPromptFor(coder);
  for (const phrase of ['MODE CODEUR RENFORCÉ V8.0', 'source de vérité', 'tests ciblés', 'limites', 'carte d’impact']) assert.ok(prompt.toLowerCase().includes(phrase.toLowerCase()));
});

test('training context distinguishes contextual learning from model-weight training', () => {
  const context = buildCoderTrainingContext();
  assert.ok(context.includes('ne modifient pas les poids du modèle fournisseur'));
  assert.ok(context.includes('PROTOCOLE D\'EXÉCUTION POUR CHAQUE TÂCHE'));
});
