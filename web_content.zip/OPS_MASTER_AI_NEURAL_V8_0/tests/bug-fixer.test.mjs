import test from 'node:test';
import assert from 'node:assert/strict';
import { boot } from './helpers.mjs';

test('OPS V3.13 crée une sauvegarde et une mission IA à partir d’un rapport de test', async (t) => {
  const env = await boot(); t.after(() => env.close());
  const project = (await env.api('POST', '/api/projects', { name: 'Jeu à corriger' })).data;
  await env.app.ctx.workspace.writeFile(project.id, 'index.html', '<!doctype html><title>Jeu</title>');
  await env.app.ctx.db.run('INSERT INTO test_reports(id,project_id,ts,kind,passed,summary,detail) VALUES(?,?,?,?,?,?,?)', [
    'report_fix_1', project.id, Date.now(), 'visual-static', 0,
    JSON.stringify({ errors: 1, warnings: 1 }),
    JSON.stringify({ findings: [{ severity: 'error', code: 'viewport-missing', message: 'Viewport absent', evidence: ['index.html'] }], inspected: ['index.html'] }),
  ]);
  const started = await env.api('POST', `/api/projects/${project.id}/bug-fixes`, { report_id: 'report_fix_1' });
  assert.equal(started.status, 200);
  assert.equal(started.data.status, 'running');
  assert.ok(started.data.run_id);
  assert.ok(started.data.baseline_version_id);
  const versions = await env.api('GET', `/api/projects/${project.id}/versions`);
  assert.ok(versions.data.some(v => v.id === started.data.baseline_version_id));
  const listed = await env.api('GET', `/api/projects/${project.id}/bug-fixes`);
  assert.equal(listed.status, 200);
  assert.equal(listed.data.length, 1);
});

test('OPS V3.13 refuse un rapport qui appartient à un autre projet ou qui est absent', async (t) => {
  const env = await boot(); t.after(() => env.close());
  const project = (await env.api('POST', '/api/projects', { name: 'Projet protégé' })).data;
  const result = await env.api('POST', `/api/projects/${project.id}/bug-fixes`, { report_id: 'unknown-report' });
  assert.equal(result.status, 404);
});

test('OPS V3.13 refuse de démarrer une correction sans identifiant de rapport', async (t) => {
  const env = await boot(); t.after(() => env.close());
  const project = (await env.api('POST', '/api/projects', { name: 'Projet sans rapport' })).data;
  const result = await env.api('POST', `/api/projects/${project.id}/bug-fixes`, {});
  assert.equal(result.status, 400);
});


test('OPS V7.8 classe les régressions après correction sans les masquer', async () => {
  const { buildBugFixRegressionReview } = await import('../server/bug-fixer.mjs');
  const clean = buildBugFixRegressionReview({ baseline: { id: 'v1' }, summary: { added: 1, removed: 0, modified: 1 }, findings: [], clean: true });
  assert.equal(clean.status, 'clean');
  assert.equal(clean.blocking, false);
  const lostFile = buildBugFixRegressionReview({ baseline: { id: 'v1' }, summary: { added: 0, removed: 1, modified: 0 }, findings: [{ level: 'error', type: 'file_removed', path: 'src/main.js', msg: 'Fichier supprimé' }] });
  assert.equal(lostFile.status, 'blocked');
  assert.equal(lostFile.blocking, true);
  const lostSymbol = buildBugFixRegressionReview({ baseline: { id: 'v1' }, findings: [{ level: 'warn', type: 'symbols_removed', path: 'src/app.js', msg: 'Fonction absente' }] });
  assert.equal(lostSymbol.status, 'review');
  assert.equal(lostSymbol.blocking, false);
  assert.ok(lostSymbol.actions.length);
  const unavailable = buildBugFixRegressionReview(null);
  assert.equal(unavailable.status, 'unavailable');
});

test('OPS V7.9 construit une boucle bornée avec preuves et arrêt explicite', async () => {
  const { MAX_BUG_FIX_CYCLES, buildBugFixCycleInstruction } = await import('../server/bug-fixer.mjs');
  assert.equal(MAX_BUG_FIX_CYCLES, 3);
  const instruction = buildBugFixCycleInstruction({
    project: { id: 'p1', name: 'Projet test', write_mode: 'approval' },
    reportId: 'report-2', row: { kind: 'checks' }, summary: { failed: 2 }, findings: [{ code: 'syntax' }],
    compiler: { context: 'TS2304 src/main.ts:4' }, candidatePaths: ['src/main.ts'], source: [], cycle: 2, maxCycles: 3,
  });
  assert.match(instruction, /CYCLE 2\/3/);
  assert.match(instruction, /nouveau rapport de test réellement exécuté/);
  assert.match(instruction, /ne doit pas se relancer lui-même indéfiniment/);
  assert.match(instruction, /mode d'écriture « approval »/);
});

test('OPS V7.9 refuse les boucles non terminées, les succès, les régressions bloquantes et les cycles au-delà du maximum', async () => {
  const { evaluateBugFixAdvance } = await import('../server/bug-fixer.mjs');
  assert.equal(evaluateBugFixAdvance({runStatus:'running',cycleCount:1}).allowed, false);
  assert.equal(evaluateBugFixAdvance({runStatus:'done',cycleCount:1,reportPassed:true}).allowed, false);
  assert.equal(evaluateBugFixAdvance({runStatus:'done',cycleCount:1,blockingRegression:true}).allowed, false);
  assert.equal(evaluateBugFixAdvance({runStatus:'done',cycleCount:3}).allowed, false);
  assert.equal(evaluateBugFixAdvance({runStatus:'done',cycleCount:1,reportAlreadyUsed:true}).allowed, false);
  assert.equal(evaluateBugFixAdvance({runStatus:'partial',cycleCount:1}).allowed, true);
});
