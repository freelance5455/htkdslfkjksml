import test from 'node:test';
import assert from 'node:assert/strict';
import { generateAsset } from '../server/modelgen.mjs';
import { sculptAsset } from '../server/sculpting.mjs';

test('sculpting: inflate, smooth and flatten modify geometry, recalculate normals and preserve valid LODs', () => {
  const asset = generateAsset({ kind: 'house', quality: 'high', floors: 3, width: 18, depth: 16 });
  const before = asset.lods[0].prims[0].pos.slice();
  const result = sculptAsset(asset, [
    { mode: 'inflate', center: [0, 9, 0], radius: 30, strength: 0.12 },
    { mode: 'smooth', center: [0, 9, 0], radius: 30, strength: 0.08 },
    { mode: 'flatten', center: [0, 9, 0], radius: 30, strength: 0.04 },
  ]);
  assert.notDeepEqual(result.asset.lods[0].prims[0].pos, before);
  assert.equal(result.asset.lods.length, 3);
  assert.equal(result.validation.ok, true, JSON.stringify(result.validation.issues));
  for (const lod of result.asset.lods) for (const p of lod.prims) assert.equal(p.nrm.length, p.pos.length);
});

test('sculpting: reject unsafe modes, excessive strength and too many operations', () => {
  const asset = generateAsset({ kind: 'crate' });
  assert.throws(() => sculptAsset(asset, [{ mode: 'cut' }]), /mode invalide/);
  assert.throws(() => sculptAsset(asset, [{ strength: 1 }]), /hors limites/);
  assert.throws(() => sculptAsset(asset, []), /1 à 32/);
});
