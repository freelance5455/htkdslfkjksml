import test from 'node:test';
import assert from 'node:assert/strict';
import { boot } from './helpers.mjs';

test('OPS V3.12 expose le statut du navigateur et conserve un historique vide', async (t) => {
  const env = await boot(); t.after(() => env.close());
  const project = (await env.api('POST','/api/projects',{name:'Projet gameplay'})).data;
  const status = await env.api('GET',`/api/projects/${project.id}/gameplay-tests/status`);
  assert.equal(status.status,200);
  assert.equal(typeof status.data.available,'boolean');
  const history = await env.api('GET',`/api/projects/${project.id}/gameplay-tests`);
  assert.equal(history.status,200);
  assert.deepEqual(history.data,[]);
});

test('OPS V3.12 refuse de lancer un jeu sans autorisation explicite', async (t) => {
  const env = await boot(); t.after(() => env.close());
  const project = (await env.api('POST','/api/projects',{name:'Projet protégé'})).data;
  await env.app.ctx.workspace.writeFile(project.id,'index.html','<!doctype html><title>Test</title>');
  const result = await env.api('POST',`/api/projects/${project.id}/gameplay-tests`,{viewport:'desktop'});
  assert.equal(result.status,403);
  assert.match(String(result.data.error || result.data.message || ''), /Autoriser l’exécution de code/);
});

test('OPS V3.12 valide le fichier d’entrée sans accepter un chemin externe', async (t) => {
  const env = await boot(); t.after(() => env.close());
  const project = (await env.api('POST','/api/projects',{name:'Projet chemin'})).data;
  await env.app.ctx.workspace.updateProject(project.id,{allow_exec:true});
  await env.app.ctx.workspace.writeFile(project.id,'index.html','<!doctype html><title>Test</title>');
  const status = await env.app.ctx.gameplayTesting.status();
  if (!status.available) {
    const result = await env.api('POST',`/api/projects/${project.id}/gameplay-tests`,{entry:'../../etc/passwd'});
    assert.equal(result.status,503); // dépendance navigateur absente : aucune exécution possible
  }
});
