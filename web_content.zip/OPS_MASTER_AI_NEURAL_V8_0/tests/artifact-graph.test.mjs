import test from 'node:test';
import assert from 'node:assert/strict';
import { analyzeArtifactGraph } from '../server/artifact-graph.mjs';

test('OPS V3.17 relie les modules livrés par imports locaux', () => {
  const graph = analyzeArtifactGraph([
    { path: 'src/main.js', content: "import { boot } from './game/boot.js'; boot();" },
    { path: 'src/game/boot.js', content: "import './world.js'; export const boot = () => true;" },
    { path: 'src/game/world.js', content: 'export const world = {};' },
  ]);
  assert.equal(graph.summary.files, 3);
  assert.equal(graph.summary.links, 2);
  assert.equal(graph.summary.warnings, 0);
  assert.ok(graph.edges.some((e) => e.from === 'src/main.js' && e.to === 'src/game/boot.js'));
});

test('OPS V3.17 signale les imports locaux sans cible connue', () => {
  const graph = analyzeArtifactGraph([{ path: 'src/main.ts', content: "import { x } from './missing.js';" }]);
  assert.equal(graph.diagnostics.length, 1);
  assert.equal(graph.diagnostics[0].code, 'LOCAL_REFERENCE_UNRESOLVED');
});

test('OPS V3.17 relie les scripts HTML et accepte les fichiers déjà présents', () => {
  const graph = analyzeArtifactGraph([
    { path: 'index.html', content: '<script type="module" src="./src/main.js"></script><link href="./style.css" rel="stylesheet">' },
    { path: 'src/main.js', content: 'console.log(1);' },
  ], ['style.css']);
  assert.equal(graph.summary.links, 2);
  assert.equal(graph.summary.warnings, 0);
});

test('OPS V3.17 refuse de transformer un chemin sortant du workspace en nœud', () => {
  const graph = analyzeArtifactGraph([{ path: '../outside.js', content: 'x' }, { path: 'src/main.js', content: "import '../outside.js';" }]);
  assert.deepEqual(graph.nodes, ['src/main.js']);
  assert.equal(graph.diagnostics.length, 1);
});
