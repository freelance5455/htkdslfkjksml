import test from 'node:test';
import assert from 'node:assert/strict';
import { buildControlCenterReport } from '../server/control-center.mjs';
import { boot } from './helpers.mjs';

test('Control Center agrège projets, charge agents, transmissions, moteurs et alertes',()=>{
  const r=buildControlCenterReport({projects:[{id:'p1',name:'OPS CITY',archived:0}],agents:[{id:'coder',name:'CODER',role:'Code',enabled:1}],taskRows:[{project_id:'p1',agent_id:'coder',status:'running'},{project_id:'p1',agent_id:'coder',status:'blocked'}],directorRows:[{project_id:'p1',assignee:'coder',status:'done'}],workItems:[{project_id:'p1',to_agent:'coder',status:'queued'}],events:[{id:'e1',project_id:'p1',type:'handoff.created',from_agent:'world',to_agent:'coder',payload:'{}',created:10}],engines:[{id:'en1',project_id:'p1',name:'World Engine',kind:'world',status:'online'}],studioAis:[{id:'ai1',name:'OPS AI',status:'ready'}],providers:[{enabled:1,model:'model',key_set:true}],generatedAt:123});
  assert.equal(r.schema,'ops.control-center.v1');
  assert.equal(r.summary.projects,1); assert.equal(r.summary.active,1); assert.equal(r.summary.blocked,1);
  assert.equal(r.summary.pending_handoffs,1); assert.equal(r.summary.engines_online,1); assert.equal(r.summary.providers_ready,1);
  assert.equal(r.projects[0].done,1); assert.equal(r.agents[0].pending_inbox,1); assert.equal(r.recent_events[0].type,'handoff.created');
  assert.ok(r.alerts.some(a=>a.code==='TASKS_BLOCKED')); assert.ok(r.alerts.some(a=>a.code==='HANDOFFS_PENDING'));
});

test('API Control Center retourne une vue globale authentifiée',async()=>{
  const t=await boot();
  try { const p=await t.api('GET','/api/control-center'); assert.equal(p.status,200); assert.equal(p.data.schema,'ops.control-center.v1'); assert.ok(Array.isArray(p.data.projects)); assert.ok(Array.isArray(p.data.agents)); }
  finally { await t.close(); }
});
