import test from 'node:test';
import assert from 'node:assert/strict';
import { createInternalCore } from '../server/internal-core.mjs';

test('OPS Internal Core fonctionne en local sans appel externe', async () => {
  const core = createInternalCore();
  assert.equal(core.health().external_network_calls, 0);
  const r = await core.chat({ id: 'debug' }, [{ role: 'user', content: 'Analyse ce bug de crash et propose un plan' }]);
  assert.match(r.text, /OPS INTERNAL CORE/);
  assert.equal(r.provider, 'OPS INTERNAL CORE');
});

test('OPS Internal Core calcule localement', async () => {
  const r = await createInternalCore().chat({ id: 'coordinator' }, [{ role: 'user', content: 'Calcule 12 * (8 + 2)' }]);
  assert.match(r.text, /120/);
});

test('OPS Internal Core renvoie un plan de production structuré', async () => {
  const r = await createInternalCore().chat({ id: 'director' }, [{ role: 'user', content: 'PLAN DE PRODUCTION JSON pour le projet OPS. Réponds UNIQUEMENT par JSON avec tasks.' }]);
  const d = JSON.parse(r.text);
  assert.ok(d.tasks.length >= 3);
  assert.equal(d.tasks.at(-1).assignee, 'quality');
});

import { createProviders } from '../server/providers.mjs';

test('repli local : actif seulement si OPS_LOCAL_FALLBACK=1, sinon échec explicite', async () => {
  const db = { get: async () => null, all: async () => [], run: async () => {} };
  const off = createProviders({ db, config: { secret: 'x', localFallback: false } });
  await assert.rejects(() => off.chat({ id: 'coordinator' }, [{ role: 'user', content: 'Calcule 2 + 2' }]), /Aucun fournisseur/);
  const on = createProviders({ db, config: { secret: 'x', localFallback: true } });
  const r = await on.chat({ id: 'coordinator' }, [{ role: 'user', content: 'Calcule 2 + 2' }]);
  assert.equal(r.provider, 'OPS INTERNAL CORE');
  assert.match(r.text, /4/);
});
