import test from 'node:test';
import assert from 'node:assert/strict';
import { detectCoderLanguage, buildCoderValidationPlan, validateCoderJson, buildCoderDiagnosticContext } from '../server/coder-diagnostics.mjs';

test('detects common implementation languages by file extension', () => {
  assert.equal(detectCoderLanguage('src/game.ts'), 'typescript');
  assert.equal(detectCoderLanguage('server/main.mjs'), 'javascript');
  assert.equal(detectCoderLanguage('tools/build.py'), 'python');
  assert.equal(detectCoderLanguage('shaders/water.wgsl'), 'wgsl');
  assert.equal(detectCoderLanguage('assets/model.fbx'), 'unknown');
});

test('builds grouped validation plans without duplicate paths', () => {
  const plan = buildCoderValidationPlan(['a.js', 'b.js', 'a.js', 'c.py']);
  assert.equal(plan.length, 2);
  assert.deepEqual(plan[0].files, ['a.js', 'b.js']);
  assert.ok(plan[0].checks.some((x) => x.includes('node --check')));
  assert.ok(plan[1].checks.some((x) => x.includes('py_compile')));
});

test('validates JSON artifacts and reports parse errors', () => {
  assert.deepEqual(validateCoderJson('config.json', '{"ok":true}'), { applicable: true, valid: true, errors: [] });
  const invalid = validateCoderJson('config.json', '{bad}');
  assert.equal(invalid.applicable, true);
  assert.equal(invalid.valid, false);
  assert.equal(invalid.errors.length, 1);
  assert.equal(validateCoderJson('main.js', 'not json').applicable, false);
});

test('diagnostic context tells CODER to validate based on actual file types', () => {
  const context = buildCoderDiagnosticContext(['main.ts', 'index.html']);
  assert.ok(context.includes('TYPESCRIPT'));
  assert.ok(context.includes('HTML'));
  assert.ok(context.includes('tsc --noEmit'));
});

import { parseCompilerDiagnostics, buildCompilerRepairContext } from '../server/compiler-diagnostics.mjs';

test('normalizes compiler output with file, line, column and error code', () => {
  const parsed = parseCompilerDiagnostics('src/game.ts(18,7): error TS2304: Cannot find name player.\nmain.go:9:4: undefined: score');
  assert.equal(parsed.length, 2);
  assert.deepEqual(parsed[0], { language:'typescript', severity:'error', path:'src/game.ts', line:18, column:7, code:'TS2304', message:'Cannot find name player.', source_line:1 });
  assert.equal(parsed[1].language, 'go');
  assert.equal(parsed[1].path, 'main.go');
  assert.equal(parsed[1].line, 9);
});

test('rejects unsafe paths and bounds diagnostic count', () => {
  const parsed = parseCompilerDiagnostics('../outside.ts(2,1): error TS1: unsafe\nsrc/a.ts(3,1): error TS2: safe', { maxItems:1 });
  assert.equal(parsed.length, 1);
  assert.equal(parsed[0].path, '');
});

test('repair context makes no validation claims when output is unrecognized', () => {
  const result = buildCompilerRepairContext('build started');
  assert.equal(result.diagnostics.length, 0);
  assert.match(result.context, /Ne pas inventer/);
});

test('Bug Fixer injects normalized compiler evidence and keeps workspace approval rules', async () => {
  const { createBugFixer } = await import('../server/bug-fixer.mjs');
  let instruction = '';
  const report = { id:'r1', project_id:'p1', kind:'npm:build', passed:0,
    summary:JSON.stringify({exit_code:1}),
    detail:JSON.stringify({output:'src/app.ts(22,5): error TS2304: Cannot find name state.', inspected:['src/app.ts']}) };
  const job = { id:'fix1', project_id:'p1', report_id:'r1', run_id:'run1', baseline_version_id:'v1', status:'running', created:1, updated:1 };
  const db = {
    get: async (sql) => sql.includes('test_reports') ? report : job,
    run: async () => ({changes:1}), all: async () => [job]
  };
  const workspace = {
    getProject: async () => ({id:'p1',name:'Demo',write_mode:'approval'}),
    createVersion: async () => ({id:'v1'}),
    readFile: () => ({path:'src/app.ts',binary:false,content:'const app = {};'}),
    log: async () => {}
  };
  const orchestrator = {
    start: async ({instruction: value}) => { instruction = value; return 'run1'; },
    getRun: async () => ({status:'running'})
  };
  const fixer = createBugFixer({db,workspace,orchestrator,events:{emit(){}}});
  await fixer.start('p1',{report_id:'r1'});
  assert.match(instruction,/TS2304/);
  assert.match(instruction,/src\/app\.ts:22:5/);
  assert.match(instruction,/approbations/);
});
