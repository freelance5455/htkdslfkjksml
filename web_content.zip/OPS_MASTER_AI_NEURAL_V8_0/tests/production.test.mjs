import test from 'node:test';
import assert from 'node:assert/strict';
import { boot } from './helpers.mjs';

test('OPS V3.9 démarre un pipeline de production avec sauvegarde de référence', async (t) => {
  const env = await boot(); t.after(() => env.close());
  const project = (await env.api('POST', '/api/projects', { name: 'Jeu Pipeline OPS' })).data;
  const started = await env.api('POST', `/api/projects/${project.id}/production`, {
    title: 'Prototype 3D OPS',
    brief: 'Créer un prototype 3D avec une scène, un personnage contrôlable et une boucle de jeu.',
    constraints: ['Préserver les fichiers existants', 'Relier les modules au point d’entrée'],
  });
  assert.equal(started.status, 200);
  assert.equal(started.data.status, 'running');
  assert.ok(started.data.run_id);
  assert.ok(started.data.baseline_version_id);
  const versions = await env.api('GET', `/api/projects/${project.id}/versions`);
  assert.equal(versions.status, 200);
  assert.ok(versions.data.some(v => v.id === started.data.baseline_version_id));
  const run = await env.api('GET', `/api/runs/${started.data.run_id}`);
  assert.equal(run.status, 200);
});

test('OPS V3.9 exige une autorisation explicite avant les scripts npm', async (t) => {
  const env = await boot(); t.after(() => env.close());
  const project = (await env.api('POST', '/api/projects', { name: 'Projet sécurisé' })).data;
  const baseline = await env.app.ctx.workspace.createVersion(project.id, { label: 'Avant validation', reason: 'test' });
  await env.app.ctx.workspace.writeFile(project.id, 'package.json', JSON.stringify({ scripts: { test: 'node -e "process.exit(0)"' } }));
  await env.app.ctx.db.run('INSERT INTO production_pipelines(id,project_id,run_id,title,brief,status,baseline_version_id,checks,final_version_id,created,updated) VALUES(?,?,?,?,?,?,?,?,?,?,?)', ['prod_permission', project.id, 'run_test', 'Test permission', '{}', 'ready_for_review', baseline.id, JSON.stringify({ passed: true, summary: {} }), null, Date.now(), Date.now()]);
  const denied = await env.api('POST', '/api/production/prod_permission/execute-checks', {});
  assert.equal(denied.status, 403);
  assert.equal(denied.data.code, 'exec_not_allowed');
});

test('OPS V3.9 exécute test/build et crée un livrable après réussite', async (t) => {
  const env = await boot(); t.after(() => env.close());
  const project = (await env.api('POST', '/api/projects', { name: 'Projet validation réelle' })).data;
  await env.api('PUT', `/api/projects/${project.id}`, { allow_exec: true });
  const baseline = await env.app.ctx.workspace.createVersion(project.id, { label: 'Avant validation', reason: 'test' });
  await env.app.ctx.workspace.writeFile(project.id, 'package.json', JSON.stringify({ scripts: { test: 'node -e "process.exit(0)"', build: 'node -e "process.exit(0)"' } }));
  await env.app.ctx.db.run('INSERT INTO production_pipelines(id,project_id,run_id,title,brief,status,baseline_version_id,checks,final_version_id,created,updated) VALUES(?,?,?,?,?,?,?,?,?,?,?)', ['prod_runtime', project.id, 'run_test', 'Test runtime', '{}', 'ready_for_review', baseline.id, JSON.stringify({ passed: true, summary: {} }), null, Date.now(), Date.now()]);
  const result = await env.api('POST', '/api/production/prod_runtime/execute-checks', {});
  assert.equal(result.status, 200);
  assert.equal(result.data.runtime.passed, true);
  assert.deepEqual(result.data.runtime.executions.map(x => x.script), ['test', 'build']);
  assert.ok(result.data.final_version.id);
  assert.equal(result.data.status, 'ready_for_review');
});

test('OPS V3.18 expose une progression de production et des étapes explicites', async (t) => {
  const env = await boot(); t.after(() => env.close());
  const project = (await env.api('POST', '/api/projects', { name: 'Progression V318' })).data;
  const started = await env.api('POST', `/api/projects/${project.id}/production`, {
    title: 'Jeu OPS progression', brief: 'Créer un jeu avec une scène principale et des interactions.'
  });
  assert.equal(started.status, 200);
  assert.ok(started.data.progress);
  assert.equal(started.data.progress.stages.length, 7);
  assert.ok(started.data.progress.stages.some((stage) => stage.id === 'implementation'));
  assert.ok(started.data.run.tasks);
});

test('OPS V3.18 contrôle les références de modules et les suppressions depuis la sauvegarde', async (t) => {
  const env = await boot(); t.after(() => env.close());
  const project = (await env.api('POST', '/api/projects', { name: 'Intégration V318' })).data;
  await env.app.ctx.workspace.writeFile(project.id, 'src/main.js', "import './missing.js';\\nexport function startGame() {}\\n");
  await env.app.ctx.workspace.writeFile(project.id, 'src/legacy.js', 'export const keep = true;');
  const baseline = await env.app.ctx.workspace.createVersion(project.id, { label: 'Base V318', reason: 'test' });
  await env.app.ctx.workspace.safePath(project.id, 'src/legacy.js');
  const fs = await import('node:fs');
  fs.unlinkSync(env.app.ctx.workspace.safePath(project.id, 'src/legacy.js').abs);
  const result = await env.app.ctx.production.inspectIntegration(project.id, baseline.id);
  assert.ok(result.graph.summary.warnings >= 1);
  assert.ok(result.graph.diagnostics.some((item) => item.code === 'LOCAL_REFERENCE_UNRESOLVED'));
  assert.equal(result.regression.ok, false);
  assert.ok(result.regression.findings.some((item) => item.type === 'file_removed'));
});

test('OPS V3.19 crée un blueprint Factory avec dépendances et exigences traçables', async (t) => {
  const env = await boot(); t.after(() => env.close());
  const project = (await env.api('POST', '/api/projects', { name: 'Factory V319' })).data;
  const started = await env.api('POST', `/api/projects/${project.id}/production`, {
    title: 'Aventure OPS', brief: 'Créer une ville explorable. Ajouter un personnage contrôlable. Préserver les missions existantes.',
    constraints: ['Ne supprimer aucun système existant']
  });
  assert.equal(started.status, 200);
  const factory = started.data.brief.factory;
  assert.equal(factory.schema, 'ops.game-factory.v1');
  assert.equal(factory.workstreams.length, 9);
  assert.equal(factory.requirements.length, 3);
  assert.deepEqual(factory.workstreams.find(x => x.id === 'integration').depends_on, ['specialists']);
  assert.equal(factory.acceptance_gates.length, 5);
});

test('OPS V3.20 reprend une production échouée sans recréer sa baseline', async (t) => {
  const env = await boot(); t.after(() => env.close());
  const project = (await env.api('POST', '/api/projects', { name: 'Reprise continue V320' })).data;
  const baseline = await env.app.ctx.workspace.createVersion(project.id, { label: 'Baseline conservée', reason: 'test' });
  await env.app.ctx.workspace.writeFile(project.id, 'index.html', '<main>Projet existant</main>');
  await env.app.ctx.db.run(
    'INSERT INTO production_pipelines(id,project_id,run_id,title,brief,status,baseline_version_id,checks,final_version_id,created,updated) VALUES(?,?,?,?,?,?,?,?,?,?,?)',
    ['prod_resume_v320', project.id, 'run_previous_missing', 'Jeu à reprendre', JSON.stringify({ requirements: 'Créer un jeu sans supprimer le contenu existant.', constraints: ['Préserver index.html'], resume_count: 0 }), 'development_failed', baseline.id, JSON.stringify({ passed: false, reason: 'Run précédent interrompu' }), null, Date.now(), Date.now()]
  );
  const resumed = await env.api('POST', '/api/production/prod_resume_v320/resume', {});
  assert.equal(resumed.status, 200);
  assert.equal(resumed.data.resumed, true);
  assert.notEqual(resumed.data.run_id, 'run_previous_missing');
  assert.equal(resumed.data.resume_count, 1);
  assert.equal(resumed.data.baseline_version_id, baseline.id);
  assert.equal(resumed.data.status, 'running');
  assert.ok(resumed.data.brief.resume_history.length === 1);
  const file = env.app.ctx.workspace.readFile(project.id, 'index.html');
  assert.equal(file.content, '<main>Projet existant</main>');
});

test('OPS V3.20 refuse la reprise d’une production déjà en cours ou en attente d’approbation', async (t) => {
  const env = await boot(); t.after(() => env.close());
  const project = (await env.api('POST', '/api/projects', { name: 'Reprise protégée V320' })).data;
  const baseline = await env.app.ctx.workspace.createVersion(project.id, { label: 'Baseline', reason: 'test' });
  await env.app.ctx.db.run(
    'INSERT INTO production_pipelines(id,project_id,run_id,title,brief,status,baseline_version_id,checks,final_version_id,created,updated) VALUES(?,?,?,?,?,?,?,?,?,?,?)',
    ['prod_resume_locked', project.id, 'run_locked', 'Pipeline verrouillé', '{}', 'awaiting_approval', baseline.id, null, null, Date.now(), Date.now()]
  );
  const result = await env.api('POST', '/api/production/prod_resume_locked/resume', {});
  assert.equal(result.status, 409);
  assert.equal(result.data.code, 'production_not_resumable');
});
