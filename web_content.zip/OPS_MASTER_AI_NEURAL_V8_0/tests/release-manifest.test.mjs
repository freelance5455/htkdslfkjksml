import test from 'node:test';
import assert from 'node:assert/strict';
import { buildReleaseManifest } from '../server/release-manifest.mjs';
import { boot } from './helpers.mjs';

function make(project, files, contents) {
  return buildReleaseManifest({ project, files: files.map(f => ({type:'file', ...f})), readBytes: p => Buffer.from(contents[p] ?? '') });
}

test('manifeste V6 : empreintes SHA-256 déterministes et inventaire trié', () => {
  const a = make({id:'p',name:'Projet'}, [{path:'z.js',size:1},{path:'index.html',size:4},{path:'README.md',size:1}], {'z.js':'x','index.html':'<a/>','README.md':'R'});
  const b = make({id:'p',name:'Projet'}, [{path:'README.md',size:1},{path:'index.html',size:4},{path:'z.js',size:1}], {'z.js':'x','index.html':'<a/>','README.md':'R'});
  assert.equal(a.status, 'ready'); assert.equal(a.integrity.root_sha256, b.integrity.root_sha256);
  assert.deepEqual(a.files.map(x=>x.path), ['index.html','README.md','z.js']);
  assert.match(a.files[0].sha256, /^[a-f0-9]{64}$/);
});

test('manifeste V6 : secrets bloquent le snapshot et les fichiers manquants demandent une revue', () => {
  const secret = make({id:'p',name:'P'}, [{path:'.env',size:25},{path:'index.html',size:1}], {'.env':'API_KEY=abcdefghijklmnopqrstu','index.html':'x'});
  assert.equal(secret.status, 'blocked'); assert.ok(secret.findings.some(x=>x.code==='secret-file'));
  const review = make({id:'p',name:'P'}, [{path:'index.html',size:1}], {'index.html':'x'});
  assert.equal(review.status, 'review'); assert.ok(review.findings.some(x=>x.code==='missing-readme'));
});

test('API V6 : manifeste authentifié et snapshot versionné', async t => {
  const env = await boot(); t.after(() => env.close());
  const project = (await env.api('POST','/api/projects',{name:'Manifest V6'})).data;
  await env.api('PUT',`/api/projects/${project.id}/file`,{path:'index.html',content:'<main>ok</main>'});
  await env.api('PUT',`/api/projects/${project.id}/file`,{path:'README.md',content:'# Test'});
  const report = await env.api('GET',`/api/projects/${project.id}/release-manifest`);
  assert.equal(report.status,200,JSON.stringify(report.data)); assert.equal(report.data.schema,'ops.release-manifest.v1'); assert.equal(report.data.status,'ready');
  const snap = await env.api('POST',`/api/projects/${project.id}/release-manifest/snapshot`,{label:'V6 release'});
  assert.equal(snap.status,200,JSON.stringify(snap.data)); assert.ok(snap.data.snapshot.id); assert.equal(snap.data.integrity.root_sha256,report.data.integrity.root_sha256);
});
