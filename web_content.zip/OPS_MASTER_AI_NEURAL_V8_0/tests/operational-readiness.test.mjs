import test from 'node:test';
import assert from 'node:assert/strict';
import { boot, bootWithStub } from './helpers.mjs';

test('diagnostic opérationnel signale honnêtement les fournisseurs absents et les composants câblés', async () => {
  const t = await boot();
  try {
    const r = await t.api('GET','/api/system/readiness');
    assert.equal(r.status,200);
    assert.equal(r.data.summary.status,'blocked');
    assert.ok(r.data.checks.some(x=>x.id==='provider'&&x.status==='blocked'));
    assert.equal(r.data.studio.length,13);
    assert.ok(r.data.studio.every(x=>x.status==='blocked'));
    assert.ok(r.data.limitations.length>=3);
  } finally { await t.close(); }
});

test('diagnostic avec fournisseur réel de test : agents exécutables, projet et moteurs correctement signalés', async () => {
  const t = await bootWithStub();
  try {
    const r = await t.api('GET',`/api/system/readiness?project_id=${t.project.id}`);
    assert.equal(r.status,200);
    assert.equal(r.data.checks.find(x=>x.id==='provider').status,'ready');
    assert.ok(r.data.agents.every(x=>x.status==='ready'));
    assert.equal(r.data.project.allow_exec,false);
    assert.equal(r.data.checks.find(x=>x.id==='project-exec').status,'warning');
    assert.ok(r.data.studio.some(x=>x.id==='world'&&x.specialty_handler==='integrated'));
  } finally { await t.close(); }
});
