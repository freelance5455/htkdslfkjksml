import test from 'node:test';
import assert from 'node:assert/strict';
import { inspectProject } from '../scripts/doctor.mjs';

test('OPS V4 Integrity Doctor : audit en lecture seule et cohérence des versions', async () => {
  const report = await inspectProject();
  assert.equal(report.mode, 'read-only');
  assert.equal(report.version, '8.0.0');
  assert.ok(report.summary.checks >= 5);
  assert.ok(report.checks.some(c => c.id === 'javascript-syntax' && c.status === 'ok'));
  assert.ok(report.checks.some(c => c.id === 'version-alignment' && c.status === 'ok'));
  assert.equal(report.summary.errors, 0, JSON.stringify(report.checks.filter(c => c.status === 'error')));
});

test('OPS V4 Integrity Doctor : les contrôles signalent les ressources locales absentes', async () => {
  const report = await inspectProject();
  assert.ok(report.checks.some(c => c.id === 'frontend-assets'));
});

test('configuration : limites de port et de taille de requête validées', async () => {
  const { loadConfig } = await import('../server/config.mjs');
  const os = await import('node:os');
  const path = await import('node:path');
  const fs = await import('node:fs');
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'ops-config-'));
  try {
    assert.throws(() => loadConfig({ dataDir: path.join(dir, 'bad-port'), port: 70000 }), /PORT/);
    assert.throws(() => loadConfig({ dataDir: path.join(dir, 'bad-body'), env: { OPS_MAX_BODY_BYTES: '10' } }), /OPS_MAX_BODY_BYTES/);
    const cfg = loadConfig({ dataDir: path.join(dir, 'valid'), port: 0, env: { OPS_MAX_BODY_BYTES: '2048' } });
    assert.equal(cfg.port, 0);
    assert.equal(cfg.maxBodyBytes, 2048);
  } finally { fs.rmSync(dir, { recursive: true, force: true }); }
});
