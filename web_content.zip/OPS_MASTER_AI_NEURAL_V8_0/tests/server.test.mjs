import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import net from 'node:net';
import crypto from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { boot, bootWithStub, waitRun } from './helpers.mjs';
import { encodeFrame, decodeFrames } from '../server/ws.mjs';
import { parseAgentOutput, validatePlan, rulePlan } from '../server/orchestrator.mjs';
import { isPrivateIp } from '../server/web.mjs';

// ---------------------------------------------------------------- sécurité & noyau
test('authentification : jeton requis, santé publique', async () => {
  const t = await boot();
  try {
    assert.equal((await t.api('GET', '/api/health', undefined, null)).status, 200);
    assert.equal((await t.api('GET', '/api/state', undefined, null)).status, 401);
    assert.equal((await t.api('GET', '/api/state', undefined, 'mauvais')).status, 401);
    assert.equal((await t.api('GET', '/api/state')).status, 200);
    assert.equal((await t.api('GET', '/api/inconnue')).status, 404);
  } finally { await t.close(); }
});

test('WebSocket : refusé sans jeton, hello avec jeton, diffusion des événements', async () => {
  const t = await boot();
  try {
    const connect = (query) => new Promise((resolve) => {
      const s = net.connect(t.port, '127.0.0.1');
      const key = crypto.randomBytes(16).toString('base64');
      let buf = Buffer.alloc(0), upgraded = false;
      s.write(`GET /ws${query} HTTP/1.1\r\nHost: 127.0.0.1:${t.port}\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Key: ${key}\r\nSec-WebSocket-Version: 13\r\n\r\n`);
      s.on('data', (d) => {
        buf = Buffer.concat([buf, d]);
        if (!upgraded) { const i = buf.indexOf('\r\n\r\n'); if (i < 0) return; const head = buf.subarray(0, i).toString(); if (!head.startsWith('HTTP/1.1 101')) return resolve({ status: head.split(' ')[1], s }); upgraded = true; buf = buf.subarray(i + 4); }
        const { frames, rest } = decodeFrames(buf); buf = rest;
        if (frames.length) { const f = frames.shift(); s.frames = [...(s.frames || []), JSON.parse(f.payload.toString()), ...frames.map((x) => JSON.parse(x.payload.toString()))]; if (!s.ready) { s.ready = true; resolve({ status: '101', s }); } }
      });
    });
    const bad = await connect('');
    assert.equal(bad.status, '401'); bad.s.destroy();
    const ok = await connect('?token=tok-test-123');
    assert.equal(ok.status, '101');
    assert.equal(ok.s.frames[0].type, 'hello');
    await t.api('POST', '/api/projects', { name: 'WS projet' });
    await new Promise((r) => setTimeout(r, 150));
    assert.ok(ok.s.frames.some((f) => f.type === 'journal'), 'événement journal diffusé');
    ok.s.destroy();
  } finally { await t.close(); }
});

test('WebSocket : encodage/décodage de trames (masquées, 126 et 64 bits)', () => {
  const big = Buffer.alloc(70000, 'a');
  for (const p of [Buffer.from('salut'), Buffer.alloc(300, 'x'), big]) {
    const f = encodeFrame(1, p);
    const { frames } = decodeFrames(f);
    assert.equal(frames[0].payload.length, p.length);
  }
  const mask = Buffer.from([1, 2, 3, 4]);
  const payload = Buffer.from('hello');
  const masked = Buffer.from(payload.map((b, i) => b ^ mask[i % 4]));
  const { frames } = decodeFrames(Buffer.concat([Buffer.from([0x81, 0x80 | 5]), mask, masked]));
  assert.equal(frames[0].payload.toString(), 'hello');
});

test('clés API : chiffrées au repos, jamais renvoyées', async () => {
  const t = await boot();
  try {
    const r = await t.api('POST', '/api/providers', { name: 'P', kind: 'openai', model: 'm', api_key: 'sk-SECRET-ABCD1234' });
    assert.equal(r.status, 200);
    assert.equal(r.data.key_set, true);
    assert.equal(r.data.key_hint, '••••1234');
    const all = JSON.stringify((await t.api('GET', '/api/providers')).data);
    assert.ok(!all.includes('SECRET'));
    const row = await t.app.ctx.db.get('SELECT key_enc FROM providers WHERE id=?', [r.data.id]);
    assert.ok(row.key_enc && !row.key_enc.includes('SECRET'));
    const dump = fs.readFileSync(path.join(t.dir, 'ops.db'));
    assert.ok(!dump.includes('sk-SECRET-ABCD1234'), 'clé absente du fichier SQLite');
    assert.equal((await t.api('POST', '/api/providers', { name: 'X', kind: 'inconnu' })).status, 400);
  } finally { await t.close(); }
});

test('SSRF : adresses privées refusées, recherche non configurée honnête', async () => {
  const t = await boot();
  try {
    for (const ip of ['127.0.0.1', '10.0.0.5', '192.168.1.1', '169.254.169.254', '172.16.0.1', '::1', 'fd00::1', '::ffff:127.0.0.1']) assert.equal(isPrivateIp(ip), true, ip);
    assert.equal(isPrivateIp('8.8.8.8'), false);
    assert.equal((await t.api('POST', '/api/web/fetch', { url: 'http://127.0.0.1:1/' })).status, 403);
    assert.equal((await t.api('POST', '/api/web/fetch', { url: 'http://localhost/' })).status, 403);
    assert.equal((await t.api('POST', '/api/web/fetch', { url: 'file:///etc/passwd' })).status, 400);
    const s = await t.api('POST', '/api/web/search', { query: 'test' });
    assert.equal(s.status, 503);
    assert.equal(s.data.code, 'web_not_configured');
  } finally { await t.close(); }
});

// ---------------------------------------------------------------- projets, fichiers, sauvegardes
test('fichiers : traversée de chemin et liens symboliques refusés, isolation entre projets', async () => {
  const t = await boot();
  try {
    await t.api('POST', '/api/projects', { name: 'Alpha' });
    await t.api('POST', '/api/projects', { name: 'Beta' });
    await t.api('PUT', '/api/projects/alpha/file', { path: 'secret.txt', content: 'alpha' });
    for (const p of ['../beta/x.txt', '/etc/passwd', '..\\..\\x', 'a/../../x', 'C:\\x']) {
      assert.ok([400, 403].includes((await t.api('PUT', '/api/projects/alpha/file', { path: p, content: 'x' })).status), p);
    }
    assert.equal((await t.api('GET', '/api/projects/beta/file?path=secret.txt')).status, 404);
    fs.symlinkSync('/etc', path.join(t.dir, 'projects/alpha/workspace/lien'));
    assert.equal((await t.api('GET', '/api/projects/alpha/file?path=lien/passwd')).status, 403);
    assert.equal((await t.api('PUT', '/api/projects/alpha/file', { path: 'lien/x', content: 'x' })).status, 403);
    assert.equal((await t.api('GET', '/api/projects/..%2F..%2Fx/files')).status, 400);
  } finally { await t.close(); }
});

test('sauvegarde avant modification, annulation, suppression confirmée', async () => {
  const t = await boot();
  try {
    await t.api('POST', '/api/projects', { name: 'Doc' });
    const w1 = (await t.api('PUT', '/api/projects/doc/file', { path: 'a.txt', content: 'v1' })).data;
    const w2 = (await t.api('PUT', '/api/projects/doc/file', { path: 'a.txt', content: 'v2' })).data;
    assert.equal(w2.action, 'modify');
    assert.equal((await t.api('POST', `/api/projects/doc/changes/${w1.change_id}/undo`, {})).status, 409, 'annulation hors ordre refusée');
    assert.equal((await t.api('POST', `/api/projects/doc/changes/${w2.change_id}/undo`, {})).status, 200);
    assert.equal((await t.api('GET', '/api/projects/doc/file?path=a.txt')).data.content, 'v1');
    assert.equal((await t.api('DELETE', '/api/projects/doc/file?path=a.txt')).status, 409, 'suppression sans confirm');
    const d = await t.api('DELETE', '/api/projects/doc/file?path=a.txt&confirm=1');
    assert.equal(d.status, 200);
    assert.equal((await t.api('GET', '/api/projects/doc/file?path=a.txt')).status, 404);
    assert.equal((await t.api('POST', `/api/projects/doc/changes/${d.data.change_id}/undo`, {})).status, 200);
    assert.equal((await t.api('GET', '/api/projects/doc/file?path=a.txt')).data.content, 'v1', 'fichier supprimé restauré');
    const j = (await t.api('GET', '/api/journal?project_id=doc')).data.map((x) => x.action);
    assert.ok(['file.create', 'file.modify', 'file.delete', 'file.undo'].every((a) => j.includes(a)), 'journalisation');
  } finally { await t.close(); }
});

test('versions : restauration avec sauvegarde de sécurité, diff, non-régression', async () => {
  const t = await boot();
  try {
    await t.api('POST', '/api/projects', { name: 'Ver' });
    await t.api('PUT', '/api/projects/ver/file', { path: 'game.js', content: 'function tirer(){return 1}\nclass Arme{}\n' + 'x'.repeat(400) });
    await t.api('PUT', '/api/projects/ver/file', { path: 'utile.txt', content: 'important' });
    const v = (await t.api('POST', '/api/projects/ver/versions', { label: 'V1' })).data;
    assert.equal(v.files, 2);
    assert.equal((await t.api('GET', '/api/projects/ver/regression')).data.clean, true);
    await t.api('PUT', '/api/projects/ver/file', { path: 'game.js', content: 'const a=1' });
    await t.api('DELETE', '/api/projects/ver/file?path=utile.txt&confirm=1');
    const reg = (await t.api('GET', '/api/projects/ver/regression')).data;
    assert.equal(reg.ok, false);
    const types = reg.findings.map((f) => f.type);
    assert.ok(types.includes('file_removed') && types.includes('shrunk') && types.includes('symbols_removed'), JSON.stringify(types));
    const diff = (await t.api('GET', `/api/projects/ver/versions/${v.id}/diff`)).data;
    assert.deepEqual(diff.removed, ['utile.txt']); assert.equal(diff.modified[0].path, 'game.js');
    const fd = (await t.api('GET', `/api/projects/ver/versions/${v.id}/diff?path=game.js`)).data;
    assert.ok(fd.removed >= 1 && fd.added >= 1);
    assert.equal((await t.api('POST', `/api/projects/ver/versions/${v.id}/restore`, {})).status, 409, 'confirmation requise');
    const rs = (await t.api('POST', `/api/projects/ver/versions/${v.id}/restore`, { confirm: true })).data;
    assert.equal((await t.api('GET', '/api/projects/ver/file?path=utile.txt')).data.content, 'important');
    assert.ok(rs.safety_version, 'état précédent sauvegardé avant restauration');
    assert.equal((await t.api('GET', '/api/projects/ver/versions')).data.length, 2);
  } finally { await t.close(); }
});

test('export ZIP valide', async () => {
  const t = await boot();
  try {
    await t.api('POST', '/api/projects', { name: 'Zip' });
    await t.api('PUT', '/api/projects/zip/file', { path: 'dir/é.txt', content: 'bonjour '.repeat(500) });
    await t.api('PUT', '/api/projects/zip/file', { path: 'b.bin', content: Buffer.from([0, 1, 2, 3]).toString('base64'), encoding: 'base64' });
    const r = await fetch(`${t.base}/api/projects/zip/export.zip`, { headers: { authorization: 'Bearer tok-test-123' } });
    const buf = Buffer.from(await r.arrayBuffer());
    const f = path.join(t.dir, 'x.zip'); fs.writeFileSync(f, buf);
    const out = execFileSync('unzip', ['-t', f]).toString();
    assert.match(out, /No errors detected/);
  } finally { await t.close(); }
});

test('centre de tests : erreurs de syntaxe JS/JSON/HTML détectées, exécution de code refusée par défaut', async () => {
  const t = await boot();
  try {
    await t.api('POST', '/api/projects', { name: 'Tst' });
    await t.api('PUT', '/api/projects/tst/file', { path: 'ok.mjs', content: 'import fs from "node:fs"; export const a = 1;' });
    await t.api('PUT', '/api/projects/tst/file', { path: 'esm.js', content: 'export default function f(){ return 1 }' });
    await t.api('PUT', '/api/projects/tst/file', { path: 'bad.js', content: 'function ( {' });
    await t.api('PUT', '/api/projects/tst/file', { path: 'bad.json', content: '{a:1}' });
    await t.api('PUT', '/api/projects/tst/file', { path: 'p.html', content: '<script>let x = ;</script><script src="x.js"></script>' });
    await t.api('PUT', '/api/projects/tst/file', { path: 'good.html', content: '<script>const k = () => 1;</script>' });
    const r = (await t.api('POST', '/api/projects/tst/tests', {})).data;
    const bad = r.files.filter((f) => !f.ok).map((f) => f.path).sort();
    assert.deepEqual(bad, ['bad.js', 'bad.json', 'p.html']);
    assert.equal(r.passed, false);
    assert.equal((await t.api('GET', '/api/projects/tst/tests')).data.length, 1);
    const run = await t.api('POST', '/api/projects/tst/run', { script: 'test' });
    assert.equal(run.status, 403);
    assert.equal(run.data.code, 'exec_not_allowed');
  } finally { await t.close(); }
});

test('exécution npm test (après autorisation explicite) : env épuré sans clé API', async () => {
  const t = await boot();
  try {
    process.env.OPS_TEST_SECRET_VAR = 'FUITE';
    await t.api('POST', '/api/projects', { name: 'Run' });
    await t.api('PUT', '/api/projects/run/file', { path: 'package.json', content: JSON.stringify({ scripts: { test: 'node t.js' } }) });
    await t.api('PUT', '/api/projects/run/file', { path: 't.js', content: 'if (process.env.OPS_TEST_SECRET_VAR) { console.log("LEAK"); process.exit(1) } console.log("pass")' });
    await t.api('PUT', '/api/projects/run', { allow_exec: true });
    const r = (await t.api('POST', '/api/projects/run/run', { script: 'test' })).data;
    assert.equal(r.passed, true, r.output);
    assert.match(r.output, /pass/);
    assert.equal((await t.api('POST', '/api/projects/run/run', { script: 'rm' })).status, 400);
  } finally { delete process.env.OPS_TEST_SECRET_VAR; await t.close(); }
});

// ---------------------------------------------------------------- fournisseurs
test('fournisseur : test de connexion, erreur d\'authentification classée, liste de modèles', async () => {
  const t = await bootWithStub();
  try {
    const ok = (await t.api('POST', `/api/providers/${t.provider.id}/test`, {})).data;
    assert.equal(ok.ok, true);
    const m = (await t.api('GET', `/api/providers/${t.provider.id}/models`)).data;
    assert.deepEqual(m.models, ['stub-big', 'stub-model']);
    const bad = (await t.api('POST', '/api/providers', { name: 'Mauvaise clé', kind: 'openai', base_url: t.stub.url, model: 'm', api_key: 'faux' })).data;
    const r = (await t.api('POST', `/api/providers/${bad.id}/test`, {})).data;
    assert.equal(r.ok, false); assert.equal(r.code, 'auth');
  } finally { await t.close(); }
});

test('fournisseur : retry sur 429, budget quotidien appliqué', async () => {
  const t = await bootWithStub();
  try {
    t.stub.st.flaky429 = 1;
    const a = (await t.api('GET', '/api/agents')).data.find((x) => x.id === 'debug');
    const r = await t.app.ctx.providers.chat(a, [{ role: 'user', content: 'ping' }]);
    assert.equal(r.text, 'Réponse de test.');
    await t.api('PUT', `/api/providers/${t.provider.id}`, { max_tokens_day: 100 });
    await t.app.ctx.providers.chat(a, [{ role: 'user', content: 'ping' }]);
    await assert.rejects(() => t.app.ctx.providers.chat(a, [{ role: 'user', content: 'ping' }]), (e) => e.code === 'budget');
    const u = (await t.api('GET', '/api/providers')).data.providers[0].usage_today;
    assert.ok(u.tokens >= 100);
  } finally { await t.close(); }
});

// ---------------------------------------------------------------- agents & orchestrateur
test('les agents sont créés avec leur spécialité', async () => {
  const t = await boot();
  try {
    const a = (await t.api('GET', '/api/agents')).data;
    assert.equal(a.length, 14);
    assert.deepEqual(a.map((x) => x.id), ['coordinator', 'architect', 'coder', 'frontend', 'backend', 'engine3d', 'debug', 'gameplay', 'npc', 'physics', 'art3d', 'animation', 'audio', 'quality']);
    assert.ok(a.every((x) => x.role && x.system_prompt.length > 40));
  } finally { await t.close(); }
});

test('sans fournisseur configuré : échec explicite, aucune réponse simulée', async () => {
  const t = await boot();
  try {
    const p = (await t.api('POST', '/api/projects', { name: 'Vide' })).data;
    const run = (await t.api('POST', '/api/chat', { project_id: p.id, text: 'corrige le bug du menu', mode: 'team' })).data;
    const r = await waitRun(t.api, run.run_id);
    assert.equal(r.status, 'failed');
    assert.match(r.report, /fournisseur/i);
    assert.ok(r.tasks.every((x) => x.status !== 'done'));
  } finally { await t.close(); }
});

test('mode équipe : plan, parallélisme, dépendances, relecture, conflit détecté puis fusionné, autorisations', async () => {
  const t = await bootWithStub();
  try {
    t.stub.st.reviewIssue = null;
    const run = (await t.api('POST', '/api/chat', { project_id: t.project.id, text: 'Crée une interface et une API', mode: 'team' })).data;
    const r = await waitRun(t.api, run.run_id);
    assert.equal(r.status, 'done', r.report);
    // plan IA (pas de règles)
    assert.equal(r.plan.by_rules, false);
    assert.equal(r.plan.subtasks.length, 3);
    // parallélisme : frontend et backend simultanés
    assert.ok(t.stub.st.peak >= 2, `pic de concurrence ${t.stub.st.peak}`);
    // dépendances : les agents dépendants ont reçu le résultat de l'architecte
    const feReq = t.stub.st.requests.find((q) => /Écris l'interface/.test(q.user) && !/Correction/.test(q.user));
    assert.match(feReq.user, /Architecture définie/);
    assert.match(feReq.user, /stack : node\+sqlite|FICHIERS DU PROJET/);
    // conflit shared.txt détecté automatiquement puis corrigé (tâche de correction, round 1)
    const corr = r.tasks.filter((x) => x.round === 1);
    assert.equal(corr.length, 1);
    assert.match(corr[0].title, /Contradiction/);
    // rapport avec relecture et état d'exécution
    assert.match(r.report, /Rapport final/);
    assert.match(r.report, /Relecture croisée/);
    // aucune écriture sans autorisation
    const tree = (await t.api('GET', `/api/projects/${t.project.id}/files`)).data;
    assert.equal(tree.length, 0, 'workspace intact tant que rien n\'est approuvé');
    const pend = (await t.api('GET', `/api/approvals?project_id=${t.project.id}`)).data;
    const paths = pend.map((a) => a.path).sort();
    assert.deepEqual(paths, ['api/server.js', 'docs/archi.md', 'shared.txt', 'web/index.html'], 'shared.txt : une seule proposition fusionnée');
    const shared = pend.find((a) => a.path === 'shared.txt');
    const full = (await t.api('GET', `/api/approvals/${shared.id}/diff`)).data;
    assert.equal(full.content, 'version fusionnée');
    // approbation → écriture réelle, sauvegarde, journal
    assert.equal((await t.api('POST', `/api/approvals/${shared.id}/approve`, {})).status, 200);
    assert.equal((await t.api('GET', `/api/projects/${t.project.id}/file?path=shared.txt`)).data.content, 'version fusionnée');
    assert.equal((await t.api('POST', `/api/approvals/${shared.id}/approve`, {})).status, 409, 'double approbation refusée');
    const rej = pend.find((a) => a.path === 'api/server.js');
    await t.api('POST', `/api/approvals/${rej.id}/reject`, {});
    assert.equal((await t.api('GET', `/api/projects/${t.project.id}/file?path=api/server.js`)).status, 404);
    // mémoire partagée
    const mem = (await t.api('GET', `/api/projects/${t.project.id}/memory`)).data;
    assert.ok(mem.some((m) => m.key === 'stack' && m.agent_id === 'architect'));
    // historique par agent
    const h = (await t.api('GET', `/api/agents/frontend/history?project_id=${t.project.id}`)).data;
    assert.ok(h.tasks.length >= 1);
  } finally { await t.close(); }
});

test('OPS V3.21 convertit les demandes ops-request en transmissions inter-IA suivies', async () => {
  const t = await bootWithStub();
  try {
    t.stub.st.requestHandoff = true;
    const run = (await t.api('POST', '/api/chat', { project_id:t.project.id, text:'Crée une interface et une API avec coordination des PNJ', mode:'team' })).data;
    const result = await waitRun(t.api, run.run_id);
    assert.equal(result.status, 'done', result.report);
    const handoffs = (await t.api('GET', `/api/projects/${t.project.id}/collaboration/work?agent_id=npc`)).data;
    assert.equal(handoffs.length, 1);
    assert.equal(handoffs[0].from_agent, 'architect');
    assert.equal(handoffs[0].to_agent, 'npc');
    assert.match(handoffs[0].instruction, /contrat de navigation/);
    assert.ok(['accepted','in_progress','done'].includes(handoffs[0].status));
  } finally { await t.close(); }
});

test('relecture qualité : problème signalé → correction par l\'agent fautif', async () => {
  const t = await bootWithStub();
  try {
    t.stub.st.reviewIssue = 'La route API manque de validation';
    const run = (await t.api('POST', '/api/chat', { project_id: t.project.id, text: 'Crée une interface et une API', mode: 'team' })).data;
    const r = await waitRun(t.api, run.run_id);
    const q = r.tasks.filter((x) => /validation/.test(x.title));
    assert.equal(q.length, 1);
    assert.equal(q[0].status, 'done');
    assert.ok(['architect', 'frontend', 'backend'].includes(q[0].agent_id));
  } finally { await t.close(); }
});

test('plan IA invalide → repli par règles, signalé explicitement', async () => {
  const t = await bootWithStub();
  try {
    t.stub.st.garbagePlan = true;
    const run = (await t.api('POST', '/api/chat', { project_id: t.project.id, text: 'Corrige le bug de la ville 3D', mode: 'team' })).data;
    const r = await waitRun(t.api, run.run_id);
    assert.equal(r.plan.by_rules, true);
    assert.match(r.plan.summary, /règles/);
    assert.ok(r.tasks.some((x) => x.agent_id === 'debug'));
  } finally { await t.close(); }
});

test('mode direct : un agent, outils de lecture, isolation des projets', async () => {
  const t = await bootWithStub();
  try {
    const other = (await t.api('POST', '/api/projects', { name: 'Autre' })).data;
    await t.api('PUT', `/api/projects/${t.project.id}/file`, { path: 'a.js', content: '// SECRET_MARKER' });
    await t.api('PUT', `/api/projects/${other.id}/file`, { path: 'b.js', content: '// AUTRE' });
    const run = (await t.api('POST', '/api/chat', { project_id: t.project.id, text: 'Lis a.js', mode: 'agent', agent_id: 'debug' })).data;
    const r = await waitRun(t.api, run.run_id);
    assert.equal(r.status, 'done');
    assert.match(r.report, /marqueur trouvé/);
    const msgs = (await t.api('GET', `/api/messages?project_id=${t.project.id}&agent_id=debug`)).data;
    assert.equal(msgs.length, 2);
    const team = (await t.api('GET', `/api/messages?project_id=${t.project.id}&agent_id=team`)).data;
    assert.equal(team.length, 0, 'fil direct séparé du fil équipe');
    assert.equal((await t.api('POST', '/api/chat', { project_id: t.project.id, text: 'x', mode: 'agent', agent_id: 'inconnu' })).status, 400);
  } finally { await t.close(); }
});

test('OPS CODER traite les outils et livre le fichier même dans la même réponse', async () => {
  const t = await bootWithStub();
  try {
    t.stub.st.mixedCoder = true;
    const run = (await t.api('POST', '/api/chat', { project_id: t.project.id, text: 'Implémenter une fonction add dans un vrai fichier JavaScript', mode: 'agent', agent_id: 'coder' })).data;
    const r = await waitRun(t.api, run.run_id);
    assert.equal(r.status, 'done');
    assert.ok(t.stub.st.requests.some(x => /ops-result tool="inspect_project"/.test(x.last)), 'l’outil demandé a été exécuté malgré le fichier présent');
    const pending = (await t.api('GET', `/api/approvals?project_id=${t.project.id}&status=pending&full=1`)).data;
    const file = pending.find(x => x.path === 'src/real-code.js');
    assert.ok(file, 'le fichier complet du codeur est enregistré comme proposition réelle');
    assert.match(file.content, /export function add/);
    assert.match(r.report, /FICHIERS DE CODE LIVRÉS/);
  } finally { await t.close(); }
});

test('OPS CODER applique un patch exact au fichier existant avec sauvegarde et approval', async () => {
  const t = await bootWithStub();
  try {
    t.stub.st.patchCoder = true;
    await t.api('PUT', `/api/projects/${t.project.id}/file`, { path: 'src/existing.js', content: 'export const value = 1;\nexport const keep = true;' });
    const run = (await t.api('POST', '/api/chat', { project_id: t.project.id, text: 'Corriger le code existant dans src/existing.js', mode: 'agent', agent_id: 'coder' })).data;
    const r = await waitRun(t.api, run.run_id);
    assert.equal(r.status, 'done');
    const pending = (await t.api('GET', `/api/approvals?project_id=${t.project.id}&status=pending&full=1`)).data;
    const patch = pending.find(x => x.path === 'src/existing.js');
    assert.ok(patch);
    assert.match(patch.content, /value = 2/);
    assert.match(patch.content, /keep = true/);
    assert.equal((await t.api('GET', `/api/projects/${t.project.id}/file?path=src/existing.js`)).data.content, 'export const value = 1;\nexport const keep = true;');
    await t.api('POST', `/api/approvals/${patch.id}/approve`, {});
    assert.match((await t.api('GET', `/api/projects/${t.project.id}/file?path=src/existing.js`)).data.content, /value = 2/);
  } finally { await t.close(); }
});

test('OPS CODER en chat direct écrit réellement dans le workspace en mode auto avec sauvegarde', async () => {
  const t = await bootWithStub();
  try {
    t.stub.st.mixedCoder = true;
    await t.api('PUT', `/api/projects/${t.project.id}`, { write_mode: 'auto' });
    const run = (await t.api('POST', '/api/chat', { project_id: t.project.id, text: 'Implémenter une fonction add dans un vrai fichier JavaScript', mode: 'agent', agent_id: 'coder' })).data;
    const r = await waitRun(t.api, run.run_id);
    assert.equal(r.status, 'done');
    const file = await t.api('GET', `/api/projects/${t.project.id}/file?path=src/real-code.js`);
    assert.equal(file.status, 200);
    assert.match(file.data.content, /export function add/);
    const versions = (await t.api('GET', `/api/projects/${t.project.id}/versions`)).data;
    assert.ok(versions.some(v => v.reason === 'avant run auto'));
  } finally { await t.close(); }
});

test('mode auto : application avec sauvegarde préalable ; suppression jamais automatique', async () => {
  const t = await bootWithStub();
  try {
    await t.api('PUT', `/api/projects/${t.project.id}`, { write_mode: 'auto' });
    await t.api('PUT', `/api/projects/${t.project.id}/file`, { path: 'existant.txt', content: 'avant' });
    const run = (await t.api('POST', '/api/chat', { project_id: t.project.id, text: 'Crée une interface et une API', mode: 'team' })).data;
    const r = await waitRun(t.api, run.run_id);
    assert.equal(r.status, 'done');
    assert.equal((await t.api('GET', `/api/projects/${t.project.id}/file?path=web/index.html`)).data.content, '<h1>OPS</h1>');
    const vs = (await t.api('GET', `/api/projects/${t.project.id}/versions`)).data;
    assert.ok(vs.some((v) => v.reason === 'avant run auto'));
    assert.ok((await t.api('GET', `/api/projects/${t.project.id}/changes`)).data.length >= 4);
  } finally { await t.close(); }
});

test('annulation d\'une exécution en cours', async () => {
  const t = await bootWithStub();
  try {
    t.stub.st.delay = 600;
    const run = (await t.api('POST', '/api/chat', { project_id: t.project.id, text: 'Crée une interface et une API', mode: 'team' })).data;
    await new Promise((x) => setTimeout(x, 400));
    assert.equal((await t.api('POST', `/api/runs/${run.run_id}/cancel`, {})).status, 200);
    const r = await waitRun(t.api, run.run_id);
    assert.equal(r.status, 'cancelled');
  } finally { await t.close(); }
});

test('reprise : tâches en erreur relancées après correction du fournisseur', async () => {
  const t = await bootWithStub();
  try {
    await t.api('PUT', `/api/providers/${t.provider.id}`, { enabled: false });
    const run = (await t.api('POST', '/api/chat', { project_id: t.project.id, text: 'Corrige le bug du menu', mode: 'team' })).data;
    const r1 = await waitRun(t.api, run.run_id);
    assert.equal(r1.status, 'failed');
    await t.api('PUT', `/api/providers/${t.provider.id}`, { enabled: true });
    const rs = await t.api('POST', `/api/runs/${run.run_id}/resume`, {});
    assert.equal(rs.status, 200);
    const r2 = await waitRun(t.api, run.run_id);
    assert.ok(r2.tasks.some((x) => x.status === 'done'));
  } finally { await t.close(); }
});

test('rapport d\'avancement : alertes factuelles', async () => {
  const t = await bootWithStub();
  try {
    await t.api('PUT', `/api/projects/${t.project.id}/file`, { path: 'a.txt', content: 'x' });
    const p = (await t.api('GET', `/api/projects/${t.project.id}/progress`)).data;
    assert.equal(p.files, 1);
    assert.ok(p.suggestions.some((s) => /sauvegarde de version/.test(s)));
    assert.ok(p.suggestions.some((s) => /test/i.test(s)));
  } finally { await t.close(); }
});

// ---------------------------------------------------------------- unités
test('parseAgentOutput reconnaît le bus de communication et les contrats de dépendance', () => {
  const out = parseAgentOutput('<ops-bus type="model.ready" to="graphics">{\"asset\":\"SM_House\"}</ops-bus><ops-dependency prerequisite="world" dependent="npc" contract="Zones et navigation"/>');
  assert.equal(out.bus.length, 1);
  assert.equal(out.bus[0].type, 'model.ready');
  assert.equal(out.bus[0].payload.asset, 'SM_House');
  assert.equal(out.dependencies[0].prerequisite, 'world');
  assert.equal(out.dependencies[0].dependent, 'npc');
});

test('parseAgentOutput / validatePlan / rulePlan', () => {
  const o = parseAgentOutput('Ok <ops-file path="a/b.js">\nlet x\n</ops-file> <ops-delete path="old.js"/> <ops-memory key="k">v</ops-memory> <ops-request agent="debug">regarde</ops-request> <ops-tool>{"tool":"list_files"}</ops-tool>');
  assert.equal(o.files[0].content, 'let x'); assert.equal(o.deletes[0].path, 'old.js');
  assert.equal(o.memory[0].key, 'k'); assert.equal(o.requests[0].agent, 'debug'); assert.equal(o.tools[0].tool, 'list_files');
  const allowed = ['architect', 'frontend'];
  assert.throws(() => validatePlan({ subtasks: [{ id: 'a', agent: 'audio', instruction: 'x' }] }, allowed), /non autorisé/);
  assert.throws(() => validatePlan({ subtasks: [{ id: 'a', agent: 'frontend', instruction: 'x', depends_on: ['b'] }, { id: 'b', agent: 'architect', instruction: 'y', depends_on: ['a'] }] }, allowed), /cycle/);
  assert.throws(() => validatePlan({ subtasks: [{ id: 'a', agent: 'frontend', instruction: 'x', depends_on: ['zz'] }] }, allowed), /inconnue/);
  assert.equal(validatePlan({ subtasks: [{ agent: 'frontend', instruction: 'x' }] }, allowed)[0].id, 't1');
  const rp = rulePlan('ajoute du son et une animation de squelette', ['audio', 'animation', 'architect']);
  assert.deepEqual(rp.subtasks.map((s) => s.agent).sort(), ['animation', 'audio']);
});

test('import du projet V3.8 fourni (seed) : préservé et versionné', async () => {
  const t = await boot({ seedProjects: true });
  try {
    const ps = (await t.api('GET', '/api/projects')).data;
    assert.deepEqual(ps.map((p) => p.name), ['OPÉRATION SURVIVANT 3D', 'FBX STUDIO 3D', 'CITY & VEHICLE STUDIO 3D', 'EUPHORIA 3D ENGINE']);
    const tree = (await t.api('GET', '/api/projects/city-vehicle-studio-3d/files')).data.map((f) => f.path);
    assert.ok(tree.includes('index.html') && tree.includes('server.mjs'));
    assert.equal((await t.api('GET', '/api/projects/city-vehicle-studio-3d/versions')).data.length, 1);
    assert.equal((await t.api('GET', '/api/projects/fbx-studio-3d/files')).data.length, 0, 'aucun mélange entre projets');
  } finally { await t.close(); }
});

// ---------------------------------------------------------------- bibliothèque
test('bibliothèque : ajout, isolation projet/global, import annulable, téléchargement sûr, suppression confirmée', async () => {
  const t = await bootWithStub();
  try {
    const other = (await t.api('POST', '/api/projects', { name: 'Autre lib' })).data;
    const b64 = (s) => Buffer.from(s).toString('base64');
    const priv = (await t.api('POST', '/api/library', { name: 'notes.md', content: b64('# secret projet'), tags: 'Doc, Design', project_id: t.project.id })).data;
    const glob = (await t.api('POST', '/api/library', { name: 'texture.png', content: Buffer.from([137, 80, 78, 71, 0, 1]).toString('base64'), tags: ['texture'] })).data;
    assert.deepEqual(priv.tags, ['doc', 'design']); assert.equal(glob.project_id, null); assert.equal(glob.mime, 'image/png');
    const idsOf = async (pid, extra = '') => (await t.api('GET', `/api/library?project_id=${pid}${extra}`)).data.map((x) => x.id);
    assert.deepEqual((await idsOf(t.project.id)).sort(), [priv.id, glob.id].sort());
    assert.deepEqual(await idsOf(other.id), [glob.id], 'élément projet invisible pour un autre projet');
    assert.deepEqual(await idsOf(t.project.id, '&q=texture'), [glob.id]);
    assert.deepEqual(await idsOf(t.project.id, '&tag=design'), [priv.id]);
    assert.equal((await t.api('GET', `/api/library/${priv.id}/preview?project_id=${other.id}`)).status, 403);
    assert.equal((await t.api('POST', `/api/library/${priv.id}/import`, { project_id: other.id })).status, 403);
    const pv = (await t.api('GET', `/api/library/${priv.id}/preview?project_id=${t.project.id}`)).data;
    assert.equal(pv.content, '# secret projet');
    // import = copie sauvegardée et annulable
    const imp = (await t.api('POST', `/api/library/${glob.id}/import`, { project_id: other.id, path: 'assets/t.png' })).data;
    assert.equal((await t.api('GET', `/api/projects/${other.id}/file?path=assets/t.png`)).data.binary, true);
    assert.equal((await t.api('POST', `/api/projects/${other.id}/changes/${imp.change_id}/undo`, {})).status, 200);
    assert.equal((await t.api('POST', `/api/library/${glob.id}/import`, { project_id: other.id, path: '../x' })).status, 403);
    // téléchargement : octets exacts, jamais interprété par le navigateur
    const r = await fetch(`${t.base}/api/library/${glob.id}/download`, { headers: { authorization: 'Bearer tok-test-123' } });
    assert.match(r.headers.get('content-disposition'), /attachment/); assert.match(r.headers.get('content-security-policy'), /sandbox/);
    assert.deepEqual([...Buffer.from(await r.arrayBuffer())], [137, 80, 78, 71, 0, 1]);
    assert.equal((await fetch(`${t.base}/api/library/${glob.id}/download`)).status, 401);
    // depuis un projet, tags, limites
    await t.api('PUT', `/api/projects/${t.project.id}/file`, { path: 'src/a.js', content: 'let a' });
    const fp = (await t.api('POST', '/api/library/from-project', { project_id: t.project.id, path: 'src/a.js', global: true })).data;
    assert.equal(fp.name, 'a.js'); assert.equal(fp.project_id, null);
    assert.equal((await t.api('POST', '/api/library/from-project', { project_id: t.project.id, path: '../../x' })).status, 403);
    const evil = (await t.api('POST', '/api/library', { name: '../../evil.txt', content: b64('x') })).data.name;
    assert.ok(!/[\\/]/.test(evil) && evil.endsWith('evil.txt'), evil);
    assert.equal((await t.api('POST', '/api/library', { name: 'vide', content: '' })).status, 400);
    assert.equal((await t.api('PUT', `/api/library/${priv.id}`, { tags: 'x' })).data.tags[0], 'x');
    // outils agents : recherche + lecture limitées au projet
    assert.ok((await t.app.ctx.library.toolSearch(t.project.id, 'notes')).length === 1);
    assert.equal((await t.app.ctx.library.toolSearch(other.id, 'notes')).length, 0);
    assert.equal(await t.app.ctx.library.toolRead(t.project.id, priv.id), '# secret projet');
    await assert.rejects(() => t.app.ctx.library.toolRead(other.id, priv.id));
    // suppression : confirmation + exemplaire conservé
    assert.equal((await t.api('DELETE', `/api/library/${priv.id}`)).status, 409);
    assert.equal((await t.api('DELETE', `/api/library/${priv.id}?confirm=1`)).status, 200);
    assert.ok(fs.readdirSync(path.join(t.dir, 'library', 'trash')).some((f) => f.includes('notes.md')));
    assert.equal((await t.api('GET', `/api/library/${priv.id}/preview`)).status, 404);
  } finally { await t.close(); }
});

test('navigateur IA : aperçu HTML et ressources locales restent isolés et authentifiés', async () => {
  const t = await boot();
  try {
    await t.api('POST', '/api/projects', { name: 'Browser' });
    await t.api('PUT', '/api/projects/browser/file', { path: 'index.html', content: '<!doctype html><html><head></head><body><h1>OPS PREVIEW</h1><script src="app.js"></script></body></html>' });
    await t.api('PUT', '/api/projects/browser/file', { path: 'app.js', content: 'window.previewLoaded = true;' });
    await t.api('PUT', '/api/projects/browser/file', { path: 'assets/nested.css', content: 'body{color:red}' });
    const p = await t.api('GET', '/api/projects/browser/preview?path=index.html');
    assert.equal(p.status, 200); assert.match(p.data.content, /OPS PREVIEW/);
    const inspection = await t.api('GET', '/api/projects/browser/inspection');
    assert.equal(inspection.status, 200); assert.equal(inspection.data.file_count, 3);
    assert.ok(inspection.data.entrypoints.some((x) => x.path === 'index.html'));
    assert.equal(inspection.data.assets.length, 0);
    const r = await fetch(`${t.base}/api/projects/browser/preview-resource/app.js?root=&token=tok-test-123`);
    assert.equal(r.status, 200); assert.match(await r.text(), /previewLoaded/);
    const nested = await fetch(`${t.base}/api/projects/browser/preview-resource/assets/nested.css?root=&token=tok-test-123`);
    assert.equal(nested.status, 200); assert.match(await nested.text(), /color:red/);
    const noAuth = await fetch(`${t.base}/api/projects/browser/preview-resource/app.js`);
    assert.equal(noAuth.status, 401);
  } finally { await t.close(); }
});

test('mémoire expérience : seules les leçons validées deviennent disponibles aux IA', async () => {
  const t = await boot();
  try {
    await t.api('POST', '/api/projects', { name: 'Memory' });
    const created = await t.api('POST', '/api/projects/memory/experiences', { domain: 'Three.js', lesson: 'Toujours raccorder les systèmes au Game Loop existant et tester le bootstrap.', evidence: 'Test de démarrage' });
    assert.equal(created.status, 200);
    const pending = (await t.api('GET', '/api/projects/memory/experiences?status=pending')).data;
    assert.equal(pending.length, 1); assert.equal(pending[0].status, 'pending');
    assert.equal((await t.app.ctx.db.all("SELECT id FROM experience_memory WHERE status='approved'")).length, 0);
    assert.equal((await t.api('POST', `/api/experiences/${created.data.id}/review`, { approved: true, global: true })).status, 200);
    const approved = (await t.api('GET', '/api/projects/memory/experiences?status=approved')).data;
    assert.equal(approved.length, 1); assert.equal(approved[0].lesson.includes('Game Loop'), true);
    assert.equal(approved[0].project_id, null, 'la leçon globale est partagée entre les projets');
    const stats = await t.api('GET', '/api/projects/memory/experience-stats');
    assert.equal(stats.status, 200); assert.equal(stats.data.totals.approved, 1); assert.equal(stats.data.usage.retrievals, 0);
  } finally { await t.close(); }
});

test('les agents peuvent proposer des leçons d’expérience distinctes de la mémoire ordinaire', () => {
  const parsed = parseAgentOutput('Livraison faite.\n<ops-experience domain="WebGL">Après avoir créé un shader, vérifier le fallback WebGL et les limites GPU sur appareil cible.</ops-experience>');
  assert.equal(parsed.experiences.length, 1);
  assert.equal(parsed.experiences[0].domain, 'WebGL');
  assert.match(parsed.experiences[0].lesson, /fallback WebGL/);
});

test('HTTP : en-têtes de sécurité cohérents et HEAD sans corps', async () => {
  const t = await boot();
  try {
    const response = await fetch(`http://127.0.0.1:${t.port}/`);
    assert.equal(response.status, 200);
    assert.equal(response.headers.get('x-content-type-options'), 'nosniff');
    assert.equal(response.headers.get('x-frame-options'), 'DENY');
    assert.equal(response.headers.get('referrer-policy'), 'no-referrer');
    const head = await fetch(`http://127.0.0.1:${t.port}/`, { method: 'HEAD' });
    assert.equal(head.status, 200);
    assert.equal(await head.text(), '');
  } finally { await t.close(); }
});
