import test from 'node:test';
import assert from 'node:assert/strict';
import { boot } from './helpers.mjs';

test('OPS V3.11 audit visuel statique détecte les défauts mobiles et les commandes de jeu', async (t) => {
  const env = await boot(); t.after(() => env.close());
  const project = (await env.api('POST', '/api/projects', { name: 'Jeu visuel mobile' })).data;
  await env.app.ctx.workspace.writeFile(project.id, 'index.html', '<!doctype html><html><head><title>Jeu</title></head><body><canvas id="game"></canvas></body></html>');
  await env.app.ctx.workspace.writeFile(project.id, 'style.css', '#game { width: 900px; height: 700px; overflow: hidden; }');
  await env.app.ctx.workspace.writeFile(project.id, 'game.js', 'const renderer = new THREE.WebGLRenderer(); renderer.render(scene, camera);');
  const result = await env.api('POST', `/api/projects/${project.id}/visual-tests`, {});
  assert.equal(result.status, 200);
  assert.equal(result.data.summary.method, 'static-source-audit');
  assert.equal(result.data.summary.screenshot_captured, false);
  assert.ok(result.data.findings.some(x => x.code === 'viewport-missing'));
  assert.ok(result.data.findings.some(x => x.code === 'touch-input-not-detected'));
  assert.ok(result.data.findings.some(x => x.code === 'resize-handling-not-detected'));
  const history = await env.api('GET', `/api/projects/${project.id}/visual-tests`);
  assert.equal(history.status, 200);
  assert.equal(history.data.length, 1);
});

test('OPS V3.11 audit visuel reconnaît une interface mobile mieux préparée', async (t) => {
  const env = await boot(); t.after(() => env.close());
  const project = (await env.api('POST', '/api/projects', { name: 'Jeu prêt mobile' })).data;
  await env.app.ctx.workspace.writeFile(project.id, 'index.html', '<!doctype html><html><head><meta name="viewport" content="width=device-width, initial-scale=1"><title>OPS</title></head><body><main><canvas id="game"></canvas><button aria-label="Avancer">Avancer</button></main></body></html>');
  await env.app.ctx.workspace.writeFile(project.id, 'style.css', '#game { width: 100%; height: 100%; touch-action: none; } @media(max-width:700px){#game{height:100dvh}}');
  await env.app.ctx.workspace.writeFile(project.id, 'game.js', "window.addEventListener('resize', resize); canvas.addEventListener('pointerdown', move); renderer.setAnimationLoop(render);");
  const result = await env.api('POST', `/api/projects/${project.id}/visual-tests`, {});
  assert.equal(result.status, 200);
  assert.equal(result.data.summary.errors, 0);
  assert.equal(result.data.summary.game_like_project, true);
  assert.equal(result.data.summary.screenshot_captured, false);
});
