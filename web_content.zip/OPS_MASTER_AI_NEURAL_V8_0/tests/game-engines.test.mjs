import test from 'node:test';
import assert from 'node:assert/strict';
import { OPSNPCEngine } from '../game-engines/npc-engine.mjs';
import { OPSPhysicsEngine } from '../game-engines/physics-engine.mjs';
import { createOPSGameRuntime } from '../game-engines/runtime-bridge.mjs';
import { DEFAULT_AGENTS, ALL_AGENT_IDS, WORKER_IDS, seedAgents } from '../server/agents.mjs';
import { rulePlan, newGamePlan, validatePlan, shouldRunAgentTools, coderTaskRequiresFiles, parseAgentOutput, applyExactPatches } from '../server/orchestrator.mjs';
import { systemPromptFor } from '../server/agents.mjs';

test('OPS NPC Engine enregistre, met à jour, mémorise et publie les changements', () => {
  const npc = new OPSNPCEngine({ adapter: { perceive: () => ({ nearby: true }), navigate: () => ({ path: [] }) } });
  npc.register('civilian-1', { update: ({ sensed }) => ({ state: sensed.nearby ? 'alert' : 'idle', remember: 'player_seen' }) });
  const r = npc.update(1/60, {});
  assert.equal(r.updated, 1); assert.equal(npc.get('civilian-1').state, 'alert');
  assert.equal(npc.get('civilian-1').memory.length, 1); assert.equal(r.events[0].type, 'npc:state');
});

test('OPS NPC Engine limite les mises à jour et la mémoire', () => {
  const npc = new OPSNPCEngine({ maxUpdatesPerFrame: 1 });
  npc.register('a', { memoryLimit: 2 }); npc.register('b');
  npc.remember('a', 1); npc.remember('a', 2); npc.remember('a', 3);
  assert.equal(npc.update(0.016).updated, 1); assert.deepEqual(npc.get('a').memory.map(x=>x.event), [2,3]);
});

test('OPS Physics Engine avance à pas fixe et borne les sous-pas', () => {
  let steps = 0; const physics = new OPSPhysicsEngine({ backend: { step: () => steps++, syncRender: () => {} } });
  const r = physics.update(1/30);
  assert.equal(steps, 2); assert.equal(r.steps, 2); assert.ok(r.alpha >= 0 && r.alpha < 1);
});

test('OPS Game Runtime raccorde NPC et physique au même cycle de jeu', () => {
  let npcTicks = 0, physicsTicks = 0;
  const runtime = createOPSGameRuntime({ npc: { update: () => npcTicks++ }, physics: { update: () => physicsTicks++ } });
  runtime.start(); runtime.update(1000); runtime.update(1016);
  assert.equal(npcTicks, 2); assert.equal(physicsTicks, 2); assert.equal(runtime.engines.npc, true);
  runtime.stop(); assert.equal(runtime.update(1032), null);
});

test('OPS agents NPC et PHYSICS sont des agents du planificateur principal', () => {
  assert.ok(ALL_AGENT_IDS.includes('coder')); assert.ok(ALL_AGENT_IDS.includes('npc')); assert.ok(ALL_AGENT_IDS.includes('physics'));
  assert.ok(WORKER_IDS.includes('coder')); assert.ok(WORKER_IDS.includes('npc')); assert.ok(WORKER_IDS.includes('physics'));
  assert.ok(DEFAULT_AGENTS.find(a=>a.id==='coder').prompt.includes('<ops-file>'));
  assert.ok(DEFAULT_AGENTS.find(a=>a.id==='coder').prompt.includes('OPS QUALITY TEAM'));
  assert.ok(DEFAULT_AGENTS.find(a=>a.id==='npc').prompt.includes('Game Loop'));
  assert.ok(DEFAULT_AGENTS.find(a=>a.id==='physics').prompt.includes('bootstrap'));
  assert.ok(systemPromptFor({...DEFAULT_AGENTS.find(a=>a.id==='coder'),system_prompt:DEFAULT_AGENTS.find(a=>a.id==='coder').prompt}).includes('ops-experience'));
  assert.ok(systemPromptFor({...DEFAULT_AGENTS.find(a=>a.id==='coder'),system_prompt:DEFAULT_AGENTS.find(a=>a.id==='coder').prompt}).includes('inspect_project'));
});


test('migration additive : les projets existants reçoivent toute l’équipe de jeu sans perdre leurs agents', async () => {
  const rows = [{ id: 'p1', agents: JSON.stringify(['coordinator','gameplay']) }]; const updates = [];
  const db = {
    get: async () => null,
    run: async (sql, args) => { if (sql.startsWith('UPDATE projects')) updates.push({ sql, args }); },
    all: async () => rows
  };
  await seedAgents(db);
  assert.equal(updates.length, 1);
  const migrated = JSON.parse(updates[0].args[0]);
  assert.deepEqual(migrated, ['coordinator','gameplay', ...DEFAULT_AGENTS.map(a => a.id).filter(id => !['coordinator','quality','gameplay'].includes(id))]);
});


test('création de jeu : le plan de secours sélectionne systématiquement les moteurs NPC et PHYSICS', () => {
  const plan = rulePlan('Créer un jeu 3D avec des PNJ intelligents et un moteur physique', WORKER_IDS);
  const selected = plan.subtasks.map(t => t.agent);
  for (const id of ['coder','engine3d','gameplay','npc','physics','art3d','animation']) assert.ok(selected.includes(id), `agent manquant : ${id}`);
});

import { CODER_LESSONS, CODER_FEW_SHOTS, CODER_ADVANCED_LESSONS, CODER_ADVANCED_CASES, buildCoderTrainingContext, evaluateCoderEvidence, evaluateCoderAdvancedEvidence } from '../server/coder-training.mjs';

test('OPS CODER AI reçoit son curriculum d’apprentissage à chaque requête', () => {
  const coder = DEFAULT_AGENTS.find(a => a.id === 'coder');
  const prompt = systemPromptFor({ ...coder, system_prompt: coder.prompt });
  assert.ok(CODER_LESSONS.length >= 8);
  assert.ok(CODER_FEW_SHOTS.length >= 3);
  assert.ok(prompt.includes('CURRICULUM OPS CODER AI'));
  assert.ok(prompt.includes('Intégration exécutable'));
  assert.ok(prompt.includes('AUTO-ÉVALUATION AVANT LIVRAISON'));
  assert.ok(buildCoderTrainingContext().includes('ne modifient pas les poids'));
});

test('OPS CODER AI mesure ses preuves de qualité sans inventer les tests', () => {
  const partial = evaluateCoderEvidence({ inspected: true, testsAdded: true });
  assert.equal(partial.score, 25);
  assert.equal(partial.ready, false);
  const complete = evaluateCoderEvidence({ inspected: true, entryPointIntegrated: true, testsAdded: true, testsExecuted: true, preservationChecked: true, contractsDefined: true, securityReviewed: true, limitationsReported: true });
  assert.equal(complete.score, 100);
  assert.equal(complete.ready, true);
});


test('OPS CODER AI reçoit le niveau avancé de son curriculum', () => {
  const context = buildCoderTrainingContext();
  assert.ok(CODER_ADVANCED_LESSONS.length >= 10);
  assert.ok(CODER_ADVANCED_CASES.length >= 3);
  for (const phrase of ['Traçabilité des exigences', 'Analyse d’impact multi-modules', 'Vérification des API', 'Déterminisme et reproductibilité', 'Revue indépendante']) assert.ok(context.includes(phrase), `leçon absente : ${phrase}`);
  assert.ok(context.includes('NIVEAU AVANCÉ'));
});

test('OPS CODER AI évalue séparément les preuves avancées', () => {
  const partial = evaluateCoderAdvancedEvidence({ requirementsMapped: true, apiVerified: true, deterministicTests: true });
  assert.equal(partial.passed, 3);
  assert.equal(partial.total, 12);
  assert.equal(partial.ready, false);
  const complete = evaluateCoderAdvancedEvidence({ requirementsMapped:true, impactMapped:true, apiVerified:true, changesReversible:true, deterministicTests:true, observabilityReviewed:true, performanceMeasured:true, dataSafetyReviewed:true, failureModesHandled:true, independentReview:true, uxReviewed:true, releaseReproducible:true });
  assert.equal(complete.score, 100);
  assert.equal(complete.ready, true);
});


test('création autonome : CODER reçoit les résultats des spécialistes avant de construire le jeu', () => {
  const plan = newGamePlan('Créer un nouveau jeu 3D mobile', WORKER_IDS);
  const coder = plan.subtasks.find(t => t.agent === 'coder');
  assert.ok(coder);
  assert.equal(plan.workflow, 'game-build-debug-repair');
  assert.ok(plan.subtasks.length <= 14);
  assert.ok(coder.depends_on.length >= 6);
  assert.ok(coder.instruction.includes("vrais points d'entrée"));
  assert.ok(coder.instruction.includes('Game Loop'));
  for (const id of ['architect','engine3d','gameplay','npc','physics','art3d','animation']) assert.ok(coder.depends_on.includes(`design_${id}`));
});

test('création autonome : pipeline compatible si certains spécialistes ne sont pas affectés', () => {
  const plan = newGamePlan('Créer un jeu', ['coder','gameplay','engine3d']);
  assert.deepEqual(plan.subtasks.map(t => t.agent), ['engine3d','gameplay','coder']);
  assert.deepEqual(plan.subtasks.at(-1).depends_on, ['design_engine3d','design_gameplay']);
  assert.throws(() => newGamePlan('Créer un jeu', ['gameplay']), /CODER AI/);
});

import { CODER_INTENSIVE_LESSONS, CODER_INTENSIVE_CASES, evaluateCoderIntensiveEvidence } from '../server/coder-training.mjs';

test('OPS CODER AI reçoit un entraînement intensif spécialisé jeux vidéo', () => {
  const context = buildCoderTrainingContext();
  assert.ok(CODER_INTENSIVE_LESSONS.length >= 20);
  assert.ok(CODER_INTENSIVE_CASES.length >= 8);
  for (const phrase of ['Boucle de jeu robuste', 'IA des personnages', 'Monde ouvert et streaming', 'Optimisation mobile', 'Tests de gameplay', 'Compilation et livraison']) assert.ok(context.includes(phrase), `compétence absente : ${phrase}`);
  assert.ok(context.includes('ÉTUDES DE CAS DE CONSTRUCTION'));
});

test('OPS CODER AI applique une grille de preuves à la construction complète d’un jeu', () => {
  const partial = evaluateCoderIntensiveEvidence({ bootstrapWorks:true, gameLoopWorks:true, playerControlsWork:true });
  assert.equal(partial.passed, 3);
  assert.equal(partial.total, 16);
  assert.equal(partial.ready, false);
  const complete = evaluateCoderIntensiveEvidence({ designTranslated:true, bootstrapWorks:true, gameLoopWorks:true, playerControlsWork:true, coreGameplayWorks:true, uiConnected:true, enginesIntegrated:true, assetsVerified:true, saveLoadTested:true, mobileConsidered:true, performanceProfiled:true, gameplayTestsRun:true, regressionSuiteRun:true, coldStartVerified:true, docsComplete:true, limitationsHonest:true });
  assert.equal(complete.score, 100);
  assert.equal(complete.ready, true);
});

import { boot } from './helpers.mjs';

test('OPS AI COMMUNICATION BUS persiste les événements et filtre les destinataires', async () => {
  const t = await boot();
  try {
    const project = await t.api('POST', '/api/projects', { name: 'Bus Test' });
    const pid = project.data.id;
    const sent = await t.api('POST', `/api/projects/${pid}/collaboration/events`, { type: 'asset.ready', from: 'modeling', to: 'graphics', payload: { asset: 'SM_Tower', version: 2 } });
    assert.equal(sent.status, 200);
    const all = await t.api('GET', `/api/projects/${pid}/collaboration/events`);
    assert.equal(all.data.length, 1);
    assert.equal(all.data[0].payload.asset, 'SM_Tower');
    const targeted = await t.api('GET', `/api/projects/${pid}/collaboration/events?agent_id=physics`);
    assert.equal(targeted.data.length, 0);
    const receiver = await t.api('GET', `/api/projects/${pid}/collaboration/events?agent_id=graphics`);
    assert.equal(receiver.data.length, 1);
  } finally { await t.close(); }
});

test('OPS DEPENDENCY MANAGER refuse les cycles et conserve les contrats moteurs', async () => {
  const t = await boot();
  try {
    const project = await t.api('POST', '/api/projects', { name: 'Dependencies Test' });
    const pid = project.data.id;
    const a = await t.api('POST', `/api/projects/${pid}/collaboration/dependencies`, { prerequisite: 'world', dependent: 'npc', contract: 'Le monde fournit navigation et zones.' });
    assert.equal(a.status, 200);
    const b = await t.api('POST', `/api/projects/${pid}/collaboration/dependencies`, { prerequisite: 'npc', dependent: 'gameplay', contract: 'Les PNJ exposent leurs états.' });
    assert.equal(b.status, 200);
    const cycle = await t.api('POST', `/api/projects/${pid}/collaboration/dependencies`, { prerequisite: 'gameplay', dependent: 'world' });
    assert.equal(cycle.status, 409);
    const rows = await t.api('GET', `/api/projects/${pid}/collaboration/dependencies`);
    assert.equal(rows.data.length, 2);
    assert.equal(rows.data.find(x => x.prerequisite === 'world').contract, 'Le monde fournit navigation et zones.');
  } finally { await t.close(); }
});


test('OPS V3.14 impose le cycle CODER → DEBUG → CODER pour la création de jeu', () => {
  const allowed = DEFAULT_AGENTS.filter(a => !['coordinator', 'quality'].includes(a.id)).map(a => a.id);
  const plan = newGamePlan('Créer un jeu 3D mobile avec des PNJ et des véhicules', allowed);
  const validated = validatePlan(plan, allowed);
  const build = validated.find(t => t.id === 'build_game');
  const debug = validated.find(t => t.id === 'debug_review');
  const repair = validated.find(t => t.id === 'coder_repairs');
  assert.equal(build.agent, 'coder');
  assert.deepEqual(debug.depends_on, ['build_game']);
  assert.equal(debug.agent, 'debug');
  assert.deepEqual(repair.depends_on, ['build_game', 'debug_review']);
  assert.equal(repair.agent, 'coder');
  assert.ok(validated.length <= 14);
  assert.ok(plan.summary.includes('audite'));
});

test('OPS V3.14 renforce les rôles IA de production de jeu et le binôme CODER/DEBUG', () => {
  const byId = Object.fromEntries(DEFAULT_AGENTS.map(a => [a.id, a]));
  const promptFor = id => systemPromptFor({ ...byId[id], system_prompt: byId[id].prompt });
  const coder = promptFor('coder');
  const debug = promptFor('debug');
  const npc = promptFor('npc');
  const quality = promptFor('quality');
  assert.match(coder, /COLLABORATION OBLIGATOIRE AVEC OPS DEBUG AI/);
  assert.match(coder, /fichiers complets et exécutables/);
  assert.match(debug, /propositions de fichiers/);
  assert.match(npc, /perception bornée/);
  assert.match(quality, /traçabilité défaut → correctif → test/);
});


test('OPS CODER conserve les fichiers même quand la réponse contient aussi des outils', () => {
  const mixed = parseAgentOutput('<ops-tool>{"tool":"inspect_project"}</ops-tool>\n<ops-file path="src/main.js">export const game = true;</ops-file>');
  assert.equal(mixed.tools.length, 1);
  assert.equal(mixed.files.length, 1);
  assert.equal(mixed.files[0].path, 'src/main.js');
  assert.equal(shouldRunAgentTools(mixed, 0), true);
  assert.equal(shouldRunAgentTools(mixed, 4), false);
});

test('OPS CODER ne valide plus une tâche de programmation sans fichier source', () => {
  assert.equal(coderTaskRequiresFiles({ agent_id: 'coder', title: 'Développement du jeu', instruction: 'Implémenter la boucle de jeu' }), true);
  assert.equal(coderTaskRequiresFiles({ agent_id: 'debug', title: 'Correction', instruction: 'Corriger le bug' }), false);
  assert.equal(coderTaskRequiresFiles({ agent_id: 'coder', title: 'Réponse directe', instruction: 'Explique les rôles des agents' }), false);
});


test('OPS CODER AI parse des patchs exacts en conservant le chemin', () => {
  const parsed = parseAgentOutput('<ops-patch path="src/main.js">[{"find":"const a = 1;","replace":"const a = 2;"}]</ops-patch>');
  assert.equal(parsed.patches.length, 1);
  assert.equal(parsed.patches[0].path, 'src/main.js');
  assert.equal(parsed.patches[0].operations[0].replace, 'const a = 2;');
});

test('OPS CODER AI applique les patchs avec contexte exact et refuse les ambiguïtés', () => {
  assert.equal(applyExactPatches('const a = 1;\nconst b = 2;', [{ find: 'const a = 1;', replace: 'const a = 3;' }]), 'const a = 3;\nconst b = 2;');
  assert.throws(() => applyExactPatches('x x', [{ find: 'x', replace: 'y' }]), /ambigu/);
  assert.throws(() => applyExactPatches('hello', [{ find: 'missing', replace: 'x' }]), /introuvable/);
  assert.throws(() => applyExactPatches('hello', [{ find: '', replace: 'x' }]), /invalide/);
});


test('OPS V3.21 crée des transmissions inter-IA persistantes et contrôle leurs transitions', async () => {
  const t = await boot();
  try {
    const project = await t.api('POST', '/api/projects', { name: 'Collaboration handoff' });
    const pid = project.data.id;
    const created = await t.api('POST', `/api/projects/${pid}/collaboration/work`, { from:'world', to:'npc', title:'Contrat de navigation', instruction:'Utiliser les zones et chemins exposés par WORLD.' });
    assert.equal(created.status, 200);
    assert.equal(created.data.status, 'queued');
    const inbox = await t.api('GET', `/api/projects/${pid}/collaboration/work?agent_id=npc&status=queued`);
    assert.equal(inbox.data.length, 1);
    const accepted = await t.api('PATCH', `/api/collaboration/work/${created.data.id}`, { agent_id:'npc', status:'accepted' });
    assert.equal(accepted.data.status, 'accepted');
    const started = await t.api('PATCH', `/api/collaboration/work/${created.data.id}`, { agent_id:'npc', status:'in_progress' });
    assert.equal(started.data.status, 'in_progress');
    const done = await t.api('PATCH', `/api/collaboration/work/${created.data.id}`, { agent_id:'npc', status:'done', result:'Navigation branchée sur world.getZones().' });
    assert.equal(done.data.result, 'Navigation branchée sur world.getZones().');
    const invalid = await t.api('PATCH', `/api/collaboration/work/${created.data.id}`, { agent_id:'npc', status:'queued' });
    assert.equal(invalid.status, 409);
  } finally { await t.close(); }
});

test('OPS V3.21 réserve les fichiers à un agent et détecte les conflits de modification', async () => {
  const t = await boot();
  try {
    const project = await t.api('POST', '/api/projects', { name: 'Artifact ownership' });
    const pid = project.data.id;
    const first = await t.api('POST', `/api/projects/${pid}/collaboration/claims`, { agent_id:'world', work_item_id:'w1', paths:['src/world.js','assets/city.json'] });
    assert.equal(first.status, 200);
    assert.equal(first.data.length, 2);
    const conflict = await t.api('POST', `/api/projects/${pid}/collaboration/claims`, { agent_id:'npc', work_item_id:'w2', paths:['src/world.js'] });
    assert.equal(conflict.status, 409);
    assert.match(conflict.data.error, /déjà réservée/);
    const released = await t.api('POST', `/api/projects/${pid}/collaboration/claims/release`, { agent_id:'world', work_item_id:'w1' });
    assert.equal(released.data.released, 2);
    const retry = await t.api('POST', `/api/projects/${pid}/collaboration/claims`, { agent_id:'npc', work_item_id:'w2', paths:['src/world.js'] });
    assert.equal(retry.status, 200);
  } finally { await t.close(); }
});

test('OPS V3.21 refuse les chemins dangereux et les transitions non autorisées', async () => {
  const t = await boot();
  try {
    const project = await t.api('POST', '/api/projects', { name: 'Safe collaboration' });
    const pid = project.data.id;
    const badPath = await t.api('POST', `/api/projects/${pid}/collaboration/claims`, { agent_id:'coder', paths:['../secrets.env'] });
    assert.equal(badPath.status, 400);
    const badAgent = await t.api('POST', `/api/projects/${pid}/collaboration/work`, { from:'coder', to:'../admin', instruction:'nope' });
    assert.equal(badAgent.status, 400);
  } finally { await t.close(); }
});
