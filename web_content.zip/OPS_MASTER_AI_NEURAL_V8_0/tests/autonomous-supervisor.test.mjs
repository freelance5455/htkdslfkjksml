import test from 'node:test';
import assert from 'node:assert/strict';
import { buildSupervisorReport, mapDirectorPlanTasks, createAutonomousSupervisor } from '../server/autonomous-supervisor.mjs';
import { boot } from './helpers.mjs';

test('Supervisor détecte tâches bloquées, anciennes, transmissions et réservations',()=>{
 const at=5_000_000;
 const r=buildSupervisorReport({project:{id:'p',name:'OPS'},now:at,tasks:[{id:'t1',title:'Build',agent_id:'coder',status:'error',error:'compile',updated:at-100}],directorTasks:[{id:'d1',title:'Ville',assignee:'world',status:'running',updated:at-30*60_000}],workItems:[{id:'w1',title:'Mesh',to_agent:'modeling',status:'queued',updated:at}],agents:[{id:'coder',enabled:1},{id:'world',enabled:1},{id:'modeling',enabled:1}],claims:[{path:'city.js',agent_id:'world',status:'active'}],dependencies:[{prerequisite:'world',dependent:'modeling'}]});
 assert.equal(r.schema,'ops.autonomous-supervisor.v1'); assert.ok(r.findings.some(x=>x.code==='TASK_BLOCKED')); assert.ok(r.findings.some(x=>x.code==='TASK_STALE')); assert.ok(r.findings.some(x=>x.code==='HANDOFF_PENDING')); assert.ok(r.findings.some(x=>x.code==='FILE_CLAIM_ACTIVE'));
 const missing=buildSupervisorReport({project:{id:'p',name:'OPS'},files:[],approvedArtifacts:[{path:'src/missing.js',task_id:'t9',agent_id:'coder'}]});
 assert.ok(missing.findings.some(x=>x.code==='APPROVED_FILE_MISSING'));
});

test('API supervise en observation sans réaffectation automatique',async()=>{const t=await boot();try{const p=await t.api('POST','/api/projects',{name:'Supervisor test'});const r=await t.api('POST',`/api/projects/${p.data.id}/supervisor/scan`,{mode:'observe'});assert.equal(r.status,200);assert.equal(r.data.schema,'ops.autonomous-supervisor.v1');assert.equal(r.data.scan.automatic_reassignment,false);const g=await t.api('GET',`/api/projects/${p.data.id}/supervisor`);assert.equal(g.status,200);}finally{await t.close();}});


test('V7.4 transforme un plan Director en tâches exécutables et conserve les dépendances',()=>{
 const tasks=mapDirectorPlanTasks([
  {id:'spec',title:'Cadrage',description:'Définir le périmètre',assignee:'director',depends_on:[]},
  {id:'build',title:'Développement',description:'Réaliser le module',assignee:'coder',depends_on:['spec']},
  {id:'qa',title:'Contrôle QA',description:'Vérifier le module',assignee:'qa',depends_on:['build']},
 ],'Créer un module autonome','Projet OPS');
 assert.equal(tasks.length,3); assert.deepEqual(tasks.map(x=>x.id),['agent_task_1','agent_task_2','agent_task_3']);
 assert.deepEqual(tasks[1].depends_on,['agent_task_1']); assert.deepEqual(tasks[2].depends_on,['agent_task_2']);
 assert.match(tasks[1].instruction,/Créer un module autonome/); assert.equal(tasks[1].agent_id,'coder');
});

test('V7.4 refuse un plan Director vide ou une tâche sans agent',()=>{
 assert.throws(()=>mapDirectorPlanTasks([],'objectif','projet'),/plan vide/);
 assert.throws(()=>mapDirectorPlanTasks([{id:'x',title:'Tâche',description:'faire'}],'objectif','projet'),/incomplète/);
});


test('V7.4 lance un objectif via Director puis le moteur multi-agents',async()=>{
 const calls=[];
 const db={get:async(sql,args)=>sql.includes('FROM projects')?{id:'p1',name:'Projet OPS',description:'Projet de test'}:null,run:async(sql,args)=>{calls.push({sql,args});return {changes:1};}};
 const director={createPlan:async(input)=>{calls.push({director:input});return {plan:{id:'dp1',title:'Mission test'}};},view:async()=>({tasks:[{id:'a',title:'Cadrage',description:'Définir',assignee:'director',depends_on:[]},{id:'b',title:'QA',description:'Vérifier',assignee:'qa',depends_on:['a']}]})};
 const orchestration={create:async(pid,input)=>{calls.push({create:input});return {plan:{id:'op1'},summary:{total:2}};},start:async(id)=>{calls.push({start:id});return {plan:{id,status:'running'},summary:{total:2}};}};
 const collaboration={publish:async(pid,event)=>calls.push({event})};
 const supervisor=createAutonomousSupervisor({db,director,orchestration,collaboration,workspace:{tree:async()=>[]}});
 const result=await supervisor.launchObjective('p1',{objective:'Créer un module de gestion autonome',autoStart:true});
 assert.equal(result.execution.plan.id,'op1'); assert.equal(result.auto_started,true);
 const create=calls.find(x=>x.create)?.create; assert.equal(create.tasks.length,2); assert.deepEqual(create.tasks[1].depends_on,['agent_task_1']);
 assert.ok(calls.some(x=>x.start==='op1')); assert.equal(result.safeguards.shell_commands_auto_executed,false);
});
