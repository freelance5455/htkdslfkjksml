import test from 'node:test';
import assert from 'node:assert/strict';
import { generateCity, createCityEngine } from '../server/city-engine.mjs';
import { createCollaboration } from '../server/collaboration.mjs';
import { parseAgentOutput } from '../server/orchestrator.mjs';
import { boot } from './helpers.mjs';

test('OPS CITY ENGINE produit une ville déterministe et bornée', () => {
  const a = generateCity({ seed:'test-seed', blocks:4 });
  const b = generateCity({ seed:'test-seed', blocks:4 });
  assert.equal(a.stats.blocks,16);
  assert.equal(a.roads.length,10);
  assert.equal(a.buildings.length,b.buildings.length);
  assert.deepEqual(a.buildings,b.buildings);
  assert.ok(a.buildings.every(x => x.position && x.dimensions.height > 0));
  assert.ok(a.limitations.length >= 1);
});

test('OPS CITY ENGINE écrit les données et documente ses limites', async () => {
  const writes=[];
  const ctx={workspace:{getProject:async()=>({id:'p'}),writeFile:async(_p,path,content)=>writes.push({path,content}),log:async()=>{}},events:{emit(){}}};
  const result=await createCityEngine(ctx).generate('p',{seed:'abc',blocks:3});
  assert.equal(writes.length,2);
  assert.ok(writes[0].path.endsWith('/city.json'));
  assert.ok(JSON.parse(writes[0].content).stats.roads > 0);
  assert.ok(writes[1].content.includes('meshes'));
  assert.equal(result.city.stats.blocks,9);
});

test('OPS AI COMMUNICATION BUS publie, liste et acquitte les messages', async () => {
  const rows=[];
  const db={run:async(sql,args)=>{ if(sql.startsWith('INSERT INTO ops_bus_messages')) rows.push(args); if(sql.startsWith("UPDATE ops_bus_messages")){ const row=rows.find(x=>x[0]===args[2]); if(row){row[7]='read';return {changes:1};} return {changes:0}; } return {changes:1}; },all:async()=>rows.map(x=>({id:x[0],project_id:x[1],from_ai:x[2],to_ai:x[3],kind:x[4],body:x[5],refs:x[6],status:x[7],created:x[8]})),get:async()=>null};
  const ctx={db,workspace:{getProject:async()=>({id:'p'})},events:{emit(){}}};
  const bus=createCollaboration(ctx);
  const msg=await bus.publish({project_id:'p',from_ai:'coder',to_ai:'npc',kind:'request',body:'Créer le contrat NPC'});
  assert.ok(msg.id);
  const list=await bus.messages({project_id:'p',to_ai:'npc'});
  assert.equal(list.length,1); assert.equal(list[0].body,'Créer le contrat NPC');
  assert.deepEqual(await bus.acknowledge(msg.id,'npc'),{ok:true});
});


test('protocole IA parse les handoffs OPS BUS', () => {
  const parsed = parseAgentOutput('<ops-bus to=\"npc\" kind=\"contract\">Contrat de navigation v1</ops-bus>');
  assert.equal(parsed.bus.length,1);
  assert.equal(parsed.bus[0].to,'npc');
  assert.equal(parsed.bus[0].kind,'contract');
  assert.equal(parsed.bus[0].body,'Contrat de navigation v1');
});

test('API V3.8 expose le bus collaboratif et la génération urbaine', async (t) => {
  const env=await boot(); t.after(()=>env.close());
  const project=(await env.api('POST','/api/projects',{name:'Projet Ville OPS'})).data;
  const generated=await env.api('POST',`/api/projects/${project.id}/city/generate`,{name:'Test City',seed:'api-seed',blocks:3});
  assert.equal(generated.status,200);
  assert.equal(generated.data.city.stats.blocks,9);
  const msg=await env.api('POST','/api/collaboration/messages',{project_id:project.id,from_ai:'architect',to_ai:'engine3d',kind:'contract',body:'Utiliser ops-city/1'});
  assert.equal(msg.status,200);
  const inbox=await env.api('GET',`/api/collaboration/messages?project_id=${project.id}&to_ai=engine3d`);
  assert.equal(inbox.data.length,1);
  const context=await env.api('GET',`/api/projects/${project.id}/collaboration-context`);
  assert.equal(context.data.project.id,project.id);
  assert.ok(context.data.files.some(x=>x.path.endsWith('/city.json')));
});


