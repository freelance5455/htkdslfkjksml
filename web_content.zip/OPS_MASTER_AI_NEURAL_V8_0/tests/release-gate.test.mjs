import test from 'node:test';
import assert from 'node:assert/strict';
import { buildReleaseGate } from '../server/release-gate.mjs';

test('release gate bloque un projet sans point d’entrée et avec défaut critique',()=>{
 const r=buildReleaseGate({project:{id:'p',name:'P'},files:[],supervisor:{summary:{critical:1}},benchmark:{summary:{tasks:0}},readiness:{summary:{status:'blocked'}}});
 assert.equal(r.status,'blocked'); assert.equal(r.release_allowed,false); assert.equal(r.summary.blocked,2);
});
test('release gate distingue une candidature d’une validation de publication',()=>{
 const r=buildReleaseGate({project:{id:'p',name:'P'},files:[{type:'file',path:'index.html'},{type:'file',path:'package.json',content:JSON.stringify({scripts:{test:'node --test'}})}],supervisor:{summary:{critical:0,warning:0,pending_handoffs:0},findings:[]},benchmark:{summary:{tasks:12}},readiness:{summary:{status:'ready'}}});
 assert.equal(r.status,'candidate'); assert.equal(r.release_allowed,true); assert.ok(r.limitations.some(x=>x.includes('pas une certification')));
});
test('release gate signale les preuves manquantes sans inventer de tests exécutés',()=>{
 const r=buildReleaseGate({project:{id:'p',name:'P'},files:[{type:'file',path:'index.html'}],supervisor:{summary:{critical:0,warning:1,pending_handoffs:1},findings:[]},benchmark:{summary:{tasks:0}},readiness:{summary:{status:'partial'}}});
 assert.equal(r.status,'review'); assert.ok(r.checks.find(x=>x.id==='test-command').status==='review'); assert.equal(r.release_allowed,false);
});

test('OPS V5.1 expose le Release Gate directement depuis une production', async (t) => {
 const { boot } = await import('./helpers.mjs');
 const env = await boot(); t.after(() => env.close());
 const project = (await env.api('POST', '/api/projects', { name: 'Production avec Release Gate' })).data;
 const baseline = await env.app.ctx.workspace.createVersion(project.id, { label: 'Baseline', reason: 'test' });
 await env.app.ctx.workspace.writeFile(project.id, 'index.html', '<main>OPS</main>');
 await env.app.ctx.db.run(
  'INSERT INTO production_pipelines(id,project_id,run_id,title,brief,status,baseline_version_id,checks,final_version_id,created,updated) VALUES(?,?,?,?,?,?,?,?,?,?,?)',
  ['prod_gate_route', project.id, 'run_missing', 'Pipeline Gate', '{}', 'ready_for_review', baseline.id, JSON.stringify({ passed: true }), null, Date.now(), Date.now()]
 );
 const result = await env.api('GET', '/api/production/prod_gate_route/release-gate');
 assert.equal(result.status, 200, JSON.stringify(result.data));
 assert.equal(result.data.schema, 'ops.release-gate.v1');
 assert.equal(result.data.project.id, project.id);
 assert.ok(Array.isArray(result.data.checks));
});
