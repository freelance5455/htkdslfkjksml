import test from 'node:test';
import assert from 'node:assert/strict';
import { DEFAULT_AGENTS, systemPromptFor } from '../server/agents.mjs';
import { agentIntelligenceProfile, buildAgentIntelligenceContext, listAgentIntelligenceProfiles, INTELLIGENCE_VERSION } from '../server/agent-intelligence.mjs';

test('chaque agent OPS possède un profil d’expertise spécialisé', () => {
  for (const agent of DEFAULT_AGENTS) {
    const profile = agentIntelligenceProfile(agent.id);
    assert.ok(profile, `profil absent : ${agent.id}`);
    assert.ok(profile.skills.length >= 4);
    assert.ok(profile.method.length > 40);
  }
  assert.equal(listAgentIntelligenceProfiles().length, DEFAULT_AGENTS.length);
});

test('les prompts système intègrent la couche intelligence sans perdre le protocole', () => {
  for (const agent of DEFAULT_AGENTS) {
    const prompt = systemPromptFor({ ...agent, system_prompt: agent.prompt });
    assert.match(prompt, /OPS INTELLIGENCE LAYER/);
    assert.match(prompt, /CYCLE DE TRAVAIL OBLIGATOIRE/);
    assert.match(prompt, /ne déclare jamais un test exécuté/);
    assert.match(prompt, /PROTOCOLE OPS/);
    assert.match(prompt, /INTERNET POUR TOUS LES AGENTS/);
    assert.match(prompt, /web_search/);
    assert.match(prompt, /APPRENTISSAGE CONTINU/);
  }
  assert.match(systemPromptFor({ ...DEFAULT_AGENTS.find(a => a.id === 'coder'), system_prompt: DEFAULT_AGENTS.find(a => a.id === 'coder').prompt }), /CURRICULUM OPS CODER AI/);
});

test('les profils sont inconnus de façon sûre et la version est explicite', () => {
  assert.equal(agentIntelligenceProfile('unknown'), null);
  assert.match(buildAgentIntelligenceContext('unknown'), /PROFIL COORDINATOR/);
  assert.equal(INTELLIGENCE_VERSION, '1.1.0');
});
