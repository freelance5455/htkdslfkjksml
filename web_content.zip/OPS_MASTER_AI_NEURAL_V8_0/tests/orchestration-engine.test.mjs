import test from 'node:test';
import assert from 'node:assert/strict';
import { validateOrchestrationTasks, shouldRetryOrchestrationFailure } from '../server/orchestration-engine.mjs';
import { boot, bootWithStub } from './helpers.mjs';


test('V5.2 retente les échecs récupérables mais bloque les erreurs d’approbation et de configuration', () => {
  assert.equal(shouldRetryOrchestrationFailure('Exécution terminée avec l’état failed'), true);
  assert.equal(shouldRetryOrchestrationFailure('Aucun résultat exploitable reçu.'), true);
  assert.equal(shouldRetryOrchestrationFailure('Une proposition de fichier a été rejetée.'), false);
  assert.equal(shouldRetryOrchestrationFailure('Approbation sans preuve de changement.'), false);
  assert.equal(shouldRetryOrchestrationFailure('Invalid API key'), false);
  assert.equal(shouldRetryOrchestrationFailure('Aucun modèle configuré'), false);
});

const waitPlan = async (api, id, predicate, timeout = 12000) => {
  const start = Date.now();
  for (;;) {
    const r = (await api('GET', `/api/orchestration/${id}`)).data;
    if (predicate(r)) return r;
    if (Date.now() - start > timeout) throw new Error(`Délai dépassé : plan=${r.plan.status}, tâches=${r.tasks.map((t) => `${t.local_id}:${t.status}:${t.error || ''}`).join(',')}, logs=${r.logs.map((x) => x.message).join(' | ')}`);
    await new Promise((resolve) => setTimeout(resolve, 40));
  }
};


test('V5.3 récupère au redémarrage une tâche interrompue et relance un essai disponible', async () => {
  const t = await bootWithStub();
  try {
    const created = await t.api('POST', `/api/projects/${t.project.id}/orchestration`, { title: 'Récupération après arrêt', tasks: [
      { id: 'architecture', title: 'Architecture', instruction: 'Conçois une architecture courte et documente-la.', agent_id: 'architect' },
    ] });
    const planId = created.data.plan.id;
    const task = created.data.tasks[0];
    await t.app.ctx.db.run("UPDATE orchestration_plans SET status='running' WHERE id=?", [planId]);
    await t.app.ctx.db.run("UPDATE orchestration_plan_tasks SET status='starting',attempts=1,started=?,error=NULL WHERE id=?", [Date.now(), task.id]);

    const recovered = await t.app.ctx.orchestration.recoverInterrupted();
    assert.equal(recovered.scanned, 1);
    assert.equal(recovered.recovered[0].plan_id, planId);
    const report = await waitPlan(t.api, planId, (r) => r.tasks[0].status === 'review');
    assert.equal(report.tasks[0].attempts, 2);
    assert.ok(report.tasks[0].execution_run_id);
    assert.ok(report.logs.some((x) => /Reprise après interruption/.test(x.message)));
    assert.ok(t.stub.st.requests.some((r) => /Conçois une architecture courte/.test(r.user)));
  } finally { await t.close(); }
});

test('V5.3 ne rejoue pas automatiquement une tâche nécessitant une validation humaine', async () => {
  const t = await bootWithStub();
  try {
    const created = await t.api('POST', `/api/projects/${t.project.id}/orchestration`, { title: 'Validation protégée', tasks: [
      { id: 'approval', title: 'Validation', instruction: 'Vérifie les propositions refusées.', agent_id: 'architect' },
    ] });
    const planId = created.data.plan.id;
    const task = created.data.tasks[0];
    await t.app.ctx.db.run("UPDATE orchestration_plans SET status='running' WHERE id=?", [planId]);
    await t.app.ctx.db.run("UPDATE orchestration_plan_tasks SET status='error',attempts=1,error='Une proposition de fichier a été rejetée.' WHERE id=?", [task.id]);
    const before = t.stub.st.requests.length;
    await t.app.ctx.orchestration.recoverInterrupted();
    const report = (await t.api('GET', `/api/orchestration/${planId}`)).data;
    assert.equal(report.tasks[0].status, 'error');
    assert.equal(t.stub.st.requests.length, before);
    assert.ok(report.logs.some((x) => /validation humaine requise/.test(x.message)));
  } finally { await t.close(); }
});

test('validation orchestration refuse IDs dupliqués, dépendances absentes et cycles', () => {
  const agents = [{ id: 'coder', enabled: 1 }, { id: 'quality', enabled: 1 }];
  assert.throws(() => validateOrchestrationTasks([{ id: 'a', title: 'A', instruction: 'x' }, { id: 'a', title: 'B', instruction: 'y' }], agents), /dupliqué/);
  assert.throws(() => validateOrchestrationTasks([{ id: 'a', title: 'A', instruction: 'x', depends_on: ['missing'] }], agents), /Dépendance inconnue/);
  assert.throws(() => validateOrchestrationTasks([{ id: 'a', title: 'A', instruction: 'x', depends_on: ['b'] }, { id: 'b', title: 'B', instruction: 'y', depends_on: ['a'] }], agents), /Cycle/);
  assert.throws(() => validateOrchestrationTasks([{ id: 'a', title: 'A', instruction: 'x', agent_id: 'absent' }], agents), /Agent indisponible/);
});

test('V3.26 exécute réellement les agents et attend l’approbation avant de libérer les dépendances', async () => {
  const t = await bootWithStub();
  try {
    const created = await t.api('POST', `/api/projects/${t.project.id}/orchestration`, { title: 'Exécution réelle OPS', tasks: [
      { id: 'architecture', title: 'Architecture', instruction: 'Conçois la structure du module et propose le fichier de documentation.', agent_id: 'architect' },
      { id: 'validation', title: 'Validation', instruction: 'Relis le résultat précédent et fournis une validation.', agent_id: 'quality', depends_on: ['architecture'] },
    ] });
    assert.equal(created.status, 200);
    assert.equal(created.data.plan.status, 'draft');
    assert.equal(created.data.summary.waiting, 2);

    const started = await t.api('POST', `/api/orchestration/${created.data.plan.id}/start`, {});
    assert.equal(started.status, 200);
    const review = await waitPlan(t.api, created.data.plan.id, (r) => r.tasks.some((x) => x.local_id === 'architecture' && x.status === 'review'));
    assert.equal(review.tasks.find((x) => x.local_id === 'validation').status, 'waiting_dependencies');
    assert.ok(review.tasks.find((x) => x.local_id === 'architecture').execution_run_id);
    assert.ok(t.stub.st.requests.some((r) => /Conçois la structure/.test(r.user)), 'le fournisseur stub doit avoir reçu la tâche réelle');

    const approvals = await t.api('GET', `/api/approvals?project_id=${t.project.id}`);
    assert.equal(approvals.status, 200);
    assert.equal(approvals.data.length, 1);
    const paused = await t.api('POST', `/api/orchestration/${created.data.plan.id}/pause`, {});
    assert.equal(paused.data.plan.status, 'paused');
    const approved = await t.api('POST', `/api/approvals/${approvals.data[0].id}/approve`, {});
    assert.equal(approved.status, 200);
    const stillPaused = await t.api('GET', `/api/orchestration/${created.data.plan.id}`);
    assert.equal(stillPaused.data.plan.status, 'paused');
    assert.equal(stillPaused.data.tasks.find((x) => x.local_id === 'validation').status, 'waiting_dependencies');

    await t.api('POST', `/api/orchestration/${created.data.plan.id}/resume`, {});
    const done = await waitPlan(t.api, created.data.plan.id, (r) => r.plan.status === 'done');
    assert.equal(done.summary.done, 2);
    assert.ok(done.tasks.every((x) => x.result && x.execution_run_id));
    assert.ok(t.stub.st.requests.some((r) => /RÉSULTATS VALIDÉS DES DÉPENDANCES/.test(r.user) && /Architecture définie/.test(r.user)), 'le résultat de la première tâche doit être transmis à la suivante');
    assert.ok(done.logs.some((x) => /Exécution lancée/.test(x.message)));
  } finally { await t.close(); }
});

test('V3.26 refuse de déclarer une tâche terminée sans fournisseur réel', async () => {
  const t = await boot();
  try {
    const p = await t.api('POST', '/api/projects', { name: 'Orchestration sans fournisseur' });
    const created = await t.api('POST', `/api/projects/${p.data.id}/orchestration`, { title: 'Sans fournisseur', tasks: [
      { id: 'analysis', title: 'Analyse', instruction: 'Produis une analyse réelle.', agent_id: 'quality' },
    ] });
    await t.api('POST', `/api/orchestration/${created.data.plan.id}/start`, {});
    const report = await waitPlan(t.api, created.data.plan.id, (r) => ['attention', 'done'].includes(r.plan.status));
    assert.equal(report.plan.status, 'attention');
    assert.equal(report.tasks[0].status, 'error');
    assert.match(report.tasks[0].error, /fournisseur|provider|clé|modèle|model/i);
    assert.equal(report.summary.done, 0);
  } finally { await t.close(); }
});

test('V3.26 pause et reprise pendant une exécution déjà lancée', async () => {
  const t = await bootWithStub();
  try {
    t.stub.st.delay = 650;
    const created = await t.api('POST', `/api/projects/${t.project.id}/orchestration`, { title: 'Pause en cours', tasks: [
      { id: 'one', title: 'Architecture', instruction: 'Conçois une architecture courte et documente-la.', agent_id: 'architect' },
    ] });
    await t.api('POST', `/api/orchestration/${created.data.plan.id}/start`, {});
    await waitPlan(t.api, created.data.plan.id, (r) => r.tasks[0].status === 'executing');
    const paused = await t.api('POST', `/api/orchestration/${created.data.plan.id}/pause`, {});
    assert.equal(paused.data.plan.status, 'paused');
    const resumed = await t.api('POST', `/api/orchestration/${created.data.plan.id}/resume`, {});
    assert.equal(resumed.data.plan.status, 'running');
    const review = await waitPlan(t.api, created.data.plan.id, (r) => r.tasks[0].status === 'review');
    assert.equal(review.plan.status, 'waiting_approval');
    const approvals = await t.api('GET', `/api/approvals?project_id=${t.project.id}`);
    for (const a of approvals.data) await t.api('POST', `/api/approvals/${a.id}/approve`, {});
    await t.api('POST', `/api/orchestration/${created.data.plan.id}/resume`, {});
    const done = await waitPlan(t.api, created.data.plan.id, (r) => r.plan.status === 'done');
    assert.equal(done.summary.done, 1);
  } finally { await t.close(); }
});

test('V3.26 route WORLD et MODELING vers leurs moteurs spécialisés réels', async () => {
  const t = await bootWithStub();
  try {
    const p = await t.api('POST', '/api/projects', { name: 'Moteurs spécialisés', write_mode: 'auto' });
    const created = await t.api('POST', `/api/projects/${p.data.id}/orchestration`, { title: 'World vers Modeling', tasks: [
      { id: 'world', title: 'Générer une petite ville', instruction: 'Crée une petite ville urbaine pour le projet.', agent_id: 'world' },
      { id: 'modeling', title: 'Créer un modèle', instruction: 'Crée un bâtiment adapté à la ville générée.', agent_id: 'modeling', depends_on: ['world'] },
    ] });
    assert.equal(created.status, 200);
    await t.api('POST', `/api/orchestration/${created.data.plan.id}/start`, {});
    const done = await waitPlan(t.api, created.data.plan.id, (r) => ['done', 'attention'].includes(r.plan.status), 15000);
    assert.equal(done.plan.status, 'done', JSON.stringify(done.tasks.map((x) => ({ id: x.local_id, status: x.status, error: x.error }))));
    assert.equal(done.summary.done, 2);
    const worlds = await t.api('GET', `/api/world/worlds?project_id=${p.data.id}`);
    const assets = await t.api('GET', `/api/modeling/assets?project_id=${p.data.id}`);
    assert.equal(worlds.data.length, 1);
    assert.equal(worlds.data[0].valid, true);
    assert.equal(worlds.data[0].files_mode, 'written');
    assert.equal(assets.data.length, 1);
    assert.equal(assets.data[0].valid, true);
    assert.equal(assets.data[0].files_mode, 'written');
    assert.ok(t.stub.st.requests.some((r) => /PARAMÈTRES JSON pour ce brief de monde/.test(r.user)));
    assert.ok(t.stub.st.requests.some((r) => /PARAMÈTRES JSON pour ce brief de modélisation/.test(r.user)));
  } finally { await t.close(); }
});


test('V3.26 vérifie les approbations des moteurs spécialisés WORLD', async () => {
  const t = await bootWithStub();
  try {
    const p = await t.api('POST', '/api/projects', { name: 'WORLD approval', write_mode: 'approval' });
    const created = await t.api('POST', `/api/projects/${p.data.id}/orchestration`, { title: 'WORLD en mode approval', tasks: [
      { id: 'world', title: 'Générer le monde', instruction: 'Crée une petite ville valide.', agent_id: 'world' },
    ] });
    await t.api('POST', `/api/orchestration/${created.data.plan.id}/start`, {});
    const review = await waitPlan(t.api, created.data.plan.id, (r) => r.tasks[0].status === 'review');
    assert.ok(review.tasks[0].approval_task_id);
    const approvals = await t.api('GET', `/api/approvals?project_id=${p.data.id}`);
    assert.equal(approvals.data.length, 4);
    for (const a of approvals.data) await t.api('POST', `/api/approvals/${a.id}/approve`, {});
    await t.api('POST', `/api/orchestration/${created.data.plan.id}/resume`, {});
    const done = await waitPlan(t.api, created.data.plan.id, (r) => r.plan.status === 'done');
    assert.equal(done.summary.done, 1);
    assert.equal(done.tasks[0].status, 'done');
  } finally { await t.close(); }
});
