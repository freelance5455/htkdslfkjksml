import test from 'node:test';
import assert from 'node:assert/strict';
import { analyzeProjectArchitecture, formatArchitectureReport } from '../server/project-architecture.mjs';

test('V8.0 détecte les points d’entrée HTML et la chaîne de dépendances', () => {
  const report = analyzeProjectArchitecture([
    { path: 'index.html', content: '<script type="module" src="./src/main.js"></script>' },
    { path: 'src/main.js', content: "import './game.js';" },
    { path: 'src/game.js', content: 'export const start = true;' },
  ], ['index.html', 'src/main.js', 'src/game.js']);
  assert.ok(report.entrypoints.includes('src/main.js'));
  assert.equal(report.summary.orphan_modules, 0);
  assert.equal(report.summary.unresolved_references, 0);
});

test('V8.0 signale les modules sources non atteignables depuis les points d’entrée', () => {
  const report = analyzeProjectArchitecture([
    { path: 'src/index.js', content: 'export const app = true;' },
    { path: 'src/unused.js', content: 'export const unused = true;' },
  ], ['src/index.js', 'src/unused.js']);
  assert.deepEqual(report.orphan_modules, ['src/unused.js']);
});

test('V8.0 détecte les cycles de dépendances', () => {
  const report = analyzeProjectArchitecture([
    { path: 'src/index.js', content: "import './a.js';" },
    { path: 'src/a.js', content: "import './b.js';" },
    { path: 'src/b.js', content: "import './a.js';" },
  ], ['src/index.js', 'src/a.js', 'src/b.js']);
  assert.equal(report.dependency_cycles.length, 1);
});

test('V8.0 calcule les dépendants directs et transitifs d’un fichier modifié', () => {
  const report = analyzeProjectArchitecture([
    { path: 'src/index.js', content: "import './feature.js';" },
    { path: 'src/feature.js', content: "import './core.js';" },
    { path: 'src/core.js', content: 'export const value = 1;' },
  ], ['src/index.js', 'src/feature.js', 'src/core.js'], ['src/core.js']);
  assert.deepEqual(report.impact[0].affected_dependents, ['src/feature.js', 'src/index.js']);
});

test('V8.0 exclut les chemins hors workspace et produit un rapport lisible', () => {
  const report = analyzeProjectArchitecture([{ path: '../outside.js', content: 'x' }], ['src/index.js']);
  assert.equal(report.summary.files, 1);
  assert.match(formatArchitectureReport(report), /Limite : analyse statique/);
});
