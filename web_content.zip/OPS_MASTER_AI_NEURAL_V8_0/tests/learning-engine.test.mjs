import test from 'node:test';
import assert from 'node:assert/strict';
import { extractLearningCandidate, createLearningEngine } from '../server/learning-engine.mjs';

test('seules les leçons explicitement formulées deviennent des candidats', () => {
  assert.equal(extractLearningCandidate('Tout est terminé.'), null);
  const c = extractLearningCandidate('DOMAINE: rendu 3D\nLEÇON RÉUTILISABLE: Toujours vérifier la présence des textures avant de lancer le chargement de la scène.\nPREUVE: test de chargement réussi.');
  assert.equal(c.domain, 'rendu 3D');
  assert.match(c.lesson, /textures/);
  assert.match(c.evidence, /test de chargement/);
});

test('capture une expérience en attente sans l’approuver automatiquement', async () => {
  const calls=[]; const db={run:async(sql,args)=>{calls.push({sql,args});}}; const logs=[];
  const engine=createLearningEngine({db,workspace:{log:async(...a)=>logs.push(a)}});
  const r=await engine.captureTask({projectId:'p1',agentId:'coder',taskId:'t1',result:'LEÇON RÉUTILISABLE: Toujours tester les imports après chaque ajout de module pour éviter les erreurs de démarrage.'});
  assert.equal(r.captured,true); assert.equal(r.status,'pending');
  assert.match(calls[0].sql,/experience_memory/); assert.match(calls[0].sql,/'pending'/); assert.equal(logs.length,1);
});
