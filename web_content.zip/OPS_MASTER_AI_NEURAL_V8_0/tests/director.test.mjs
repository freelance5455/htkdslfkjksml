import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import { boot, bootWithStub } from './helpers.mjs';
import { computeStates, criticalPath, hasCycle, STUDIO_IDS, TEMPLATES } from '../server/director.mjs';
import { makeZip, readZip } from '../server/zip.mjs';
import { sha1 } from '../server/util.mjs';

const mkPlan = async (t, template = 'city', pid = 'dir') => (await t.api('POST', '/api/director/plans', { project_id: pid, template })).data;
const byTitle = (v, s) => v.tasks.find((x) => x.title.includes(s));

// ------------------------------------------------------------- équipe du studio
test('studio : 13 IA officielles, toutes les IA du studio sont construites ; validation par l\'utilisateur', async () => {
  const t = await boot();
  try {
    const r = (await t.api('GET', '/api/studio')).data;
    assert.deepEqual(r.map((a) => a.name), ['OPS DIRECTOR AI', 'OPS WORLD AI', 'OPS MODELING AI', 'OPS SATELLITE AI', 'OPS WEB RESEARCH AI', 'OPS ANIMATION AI', 'OPS NPC AI', 'OPS PHYSICS AI', 'OPS VEHICLE AI', 'OPS GAMEPLAY AI', 'OPS GRAPHICS AI', 'OPS STORY AI', 'OPS QA AI']);
    assert.deepEqual(r.filter((a) => a.executable).map((a) => a.id), STUDIO_IDS);
    assert.equal((await t.api('POST', '/api/studio/animation/validate', {})).status, 200, 'l’IA spécialisée construite peut être validée');
    assert.equal((await t.api('PUT', '/api/studio/animation', { model: 'x' })).status, 200);
    assert.equal((await t.api('POST', '/api/studio/director/validate', {})).status, 200);
    assert.equal((await t.api('GET', '/api/studio')).data[0].status, 'validated');
    await t.api('POST', '/api/studio/director/validate', { validated: false });
    assert.equal((await t.api('GET', '/api/studio')).data[0].status, 'built');
  } finally { await t.close(); }
});




test('OPS WEB RESEARCH AI est construite et exige une recherche web réellement configurée', async () => {
  const t = await bootWithStub();
  try {
    const roster = (await t.api('GET', '/api/studio')).data;
    assert.ok(roster.some((a) => a.id === 'webresearch' && a.name === 'OPS WEB RESEARCH AI' && a.executable));
    const r = await t.api('POST', '/api/studio/webresearch/chat', { project_id: t.project.id, text: 'Recherche les dernières documentations officielles pour optimiser un moteur 3D mobile.' });
    assert.equal(r.status, 503);
    assert.equal(r.data.code, 'web_not_configured');
    assert.match(r.data.error, /Tavily ou Brave/);
  } finally { await t.close(); }
});

test('OPS SATELLITE AI analyse une image et partage le dossier avec toutes les autres IA', async () => {
  const t = await bootWithStub();
  try {
    const image = 'data:image/png;base64,' + Buffer.from('fake-image-data').toString('base64');
    const r = await t.api('POST', '/api/studio/satellite/chat', { project_id: t.project.id, text: 'Analyse cette image satellitaire pour créer une ville fictive.', image_data_url: image });
    assert.equal(r.status, 200);
    assert.equal(r.data.shared_with_studio, STUDIO_IDS.length - 1);
    const satelliteRequest = t.stub.st.requests.find((x) => Array.isArray(x.last));
    assert.ok(satelliteRequest, 'le fournisseur reçoit un contenu multimodal');
    assert.ok(satelliteRequest.last.some((part) => part.type === 'image_url'));
    for (const target of STUDIO_IDS.filter((id) => id !== 'satellite')) {
      const delivered = (await t.api('GET', `/api/director/messages?project_id=${t.project.id}&to=${target}`)).data;
      assert.ok(delivered.some((m) => m.from_ai === 'satellite' && /DOSSIER SATELLITAIRE PARTAGÉ/.test(m.body)), `dossier reçu par ${target}`);
    }
    const inbox = (await t.api('GET', '/api/director/messages?project_id=' + t.project.id + '&to=world')).data;
    assert.ok(inbox.some((m) => m.from_ai === 'satellite' && /DOSSIER SATELLITAIRE PARTAGÉ/.test(m.body)));
    const ctx = (await t.api('POST', '/api/studio/world/chat', { project_id: t.project.id, text: 'Prends en compte les observations satellites.' }));
    assert.equal(ctx.status, 200);
    assert.ok(t.stub.st.requests.some((x) => x.sys.includes('OPS WORLD AI')));
    assert.equal((await t.api('POST', '/api/studio/satellite/chat', { project_id: t.project.id, text: 'image invalide', image_data_url: 'data:text/plain;base64,abc' })).status, 400);
  } finally { await t.close(); }
});

// ------------------------------------------------------------- logique pure
test('états, chemin critique et cycles (fonctions pures)', () => {
  const T = (id, deps, status = 'todo', assignee = 'director', h = 1) => ({ id, title: id, depends_on: deps, status, assignee, estimate_h: h });
  const built = new Set(['director']);
  const tasks = [T('a', [], 'done'), T('b', ['a']), T('c', ['b']), T('d', ['a'], 'todo', 'world'), T('e', ['x'], 'todo'), T('x', [], 'cancelled')];
  const s = computeStates(tasks, built);
  assert.equal(s.get('a').state, 'done'); assert.equal(s.get('b').state, 'ready'); assert.equal(s.get('c').state, 'waiting_deps');
  assert.equal(s.get('d').state, 'waiting_ai'); assert.equal(s.get('e').state, 'blocked'); assert.match(s.get('e').reason, /annulée/);
  const cp = criticalPath([T('a', [], 'todo', 'director', 2), T('b', ['a'], 'todo', 'director', 5), T('c', ['a'], 'todo', 'director', 1)]);
  assert.deepEqual(cp, { hours: 7, path: ['a', 'b'] });
  assert.equal(hasCycle([{ id: 'a', depends_on: ['b'] }, { id: 'b', depends_on: ['a'] }]), true);
  assert.equal(hasCycle([{ id: 'a', depends_on: [] }, { id: 'b', depends_on: ['a'] }]), false);
  for (const tpl of Object.values(TEMPLATES)) {
    const keys = new Set(tpl.tasks.map((x) => x.key));
    assert.ok(tpl.tasks.every((x) => STUDIO_IDS.includes(x.assignee) && x.deps.every((d) => keys.has(d))));
    assert.equal(hasCycle(tpl.tasks.map((x) => ({ id: x.key, depends_on: x.deps }))), false);
  }
});

// ------------------------------------------------------------- plans et tâches
test('plan « ville » : chaîne WORLD → MODELING → GRAPHICS/PHYSICS → NPC → QA supervisée par le Director', async () => {
  const t = await boot();
  try {
    await t.api('POST', '/api/projects', { name: 'Dir' });
    const v = await mkPlan(t);
    assert.deepEqual(v.tasks.map((x) => x.assignee), ['director', 'satellite', 'world', 'modeling', 'graphics', 'physics', 'npc', 'qa', 'director']);
    assert.equal(byTitle(v, 'Cahier').state, 'ready');
    assert.equal(byTitle(v, 'Analyser les références').state, 'waiting_deps');
    assert.equal(byTitle(v, 'Construire').state, 'waiting_deps');
    assert.equal(v.progress, 0);
    assert.deepEqual(v.next_ready, [byTitle(v, 'Cahier').id]);
    assert.equal((await t.api('POST', '/api/director/plans', { project_id: 'dir', template: 'inconnu' })).status, 400);
    assert.equal((await t.api('POST', '/api/director/plans', { project_id: 'nope', template: 'city' })).status, 404);
  } finally { await t.close(); }
});

test('cycle de vie : transitions contrôlées, dépendances, agents AAA exécutables et handoffs', async () => {
  const t = await boot();
  try {
    await t.api('POST', '/api/projects', { name: 'Dir' });
    const v0 = await mkPlan(t);
    const spec = byTitle(v0, 'Cahier'), satellite = byTitle(v0, 'Analyser les références'), world = byTitle(v0, 'Construire'), models = byTitle(v0, 'bâtiments');
    const up = (id, b) => t.api('PUT', `/api/director/tasks/${id}`, b);
    assert.equal((await up(world.id, { assignee: 'animation' })).status, 200, 'réattribution à une IA AAA construite');
    assert.equal((await up(world.id, { status: 'in_progress' })).status, 409, 'dépendances non terminées');
    assert.equal((await up(spec.id, { status: 'review' })).status, 409, 'todo → review interdit');
    assert.equal((await up(spec.id, { status: 'in_progress' })).status, 200);
    assert.equal((await up(spec.id, { status: 'done' })).status, 400, 'résultat requis');
    assert.equal((await up(spec.id, { status: 'done', result: 'Ville de 4 quartiers, 60 fps mobile.' })).status, 200);
    await up(satellite.id, { status: 'in_progress' });
    await up(satellite.id, { status: 'done', result: 'Référence de terrain de test.' });
    assert.equal((await up(spec.id, { status: 'todo' })).status, 409, 'une tâche terminée reste terminée');
    assert.equal((await up(spec.id, { assignee: 'qa' })).status, 409);
    // ANIMATION n'est pas construite : prête côté dépendances mais non exécutable
    let v = (await t.api('GET', `/api/director/plans/${v0.plan.id}`)).data;
    assert.equal(byTitle(v, 'Construire').state, 'ready');
    assert.equal((await up(world.id, { status: 'in_progress' })).status, 200);
    // handoff : message mis en file d'attente pour OPS ANIMATION AI, avec le résultat du Director
    const q = (await t.api('GET', '/api/director/messages?project_id=dir&to=animation')).data;
    const directorHandoff = q.find((m) => m.kind === 'handoff' && m.from_ai === 'director');
    assert.ok(directorHandoff); assert.ok(q.every((m) => m.status === 'pending'));
    assert.match(directorHandoff.body, /4 quartiers/);
    assert.equal((await t.api('POST', `/api/director/messages/${directorHandoff.id}/read`, {})).status, 200, 'le destinataire construit peut lire le transfert');
    // dépendance cyclique refusée, dépendance annulée → blocage
    assert.equal((await up(spec.id, { depends_on: [models.id] })).status, 409);
    assert.equal((await up(world.id, { depends_on: [world.id] })).status, 400);
    await up(world.id, { status: 'cancelled' });
    v = (await t.api('GET', `/api/director/plans/${v0.plan.id}`)).data;
    assert.equal(byTitle(v, 'bâtiments').state, 'blocked');
    assert.ok(v.issues.some((i) => i.level === 'error' && /annulée/.test(i.msg)));
    await up(world.id, { status: 'todo' });
    // réattribution au Director : devient exécutable
    assert.equal((await up(world.id, { assignee: 'director' })).status, 200);
    v = (await t.api('GET', `/api/director/plans/${v0.plan.id}`)).data;
    assert.equal(byTitle(v, 'Construire').state, 'ready');
    // ajout d'une tâche
    const nt = (await t.api('POST', `/api/director/plans/${v0.plan.id}/tasks`, { title: 'Revue légale', assignee: 'qa', depends_on: [spec.id] })).data;
    assert.equal(nt.assignee, 'qa');
    assert.equal((await t.api('POST', `/api/director/plans/${v0.plan.id}/tasks`, { title: 'x', assignee: 'robot' })).status, 400);
    assert.equal((await t.api('POST', `/api/director/plans/${v0.plan.id}/tasks`, { title: 'x', depends_on: ['inconnu'] })).status, 400);
    const j = (await t.api('GET', '/api/journal?project_id=dir')).data.map((x) => x.action);
    assert.ok(['plan.create', 'task.update', 'task.add'].every((a) => j.includes(a)));
  } finally { await t.close(); }
});

test('progression pondérée par les estimations et chemin critique du plan', async () => {
  const t = await boot();
  try {
    await t.api('POST', '/api/projects', { name: 'Dir' });
    const v = await mkPlan(t, 'mission');
    const spec = byTitle(v, 'Cadrage');
    await t.api('PUT', `/api/director/tasks/${spec.id}`, { status: 'in_progress' });
    await t.api('PUT', `/api/director/tasks/${spec.id}`, { status: 'done', result: 'ok' });
    const v2 = (await t.api('GET', `/api/director/plans/${v.plan.id}`)).data;
    const total = TEMPLATES.mission.tasks.reduce((s, x) => s + x.estimate_h, 0);
    assert.equal(v2.progress, Math.round((2 / total) * 100));
    assert.equal(v2.critical_path.path.length, 4); // story → game → qa → close (cadrage terminé : exclu)
    assert.equal(v2.critical_path.hours, 8 + 8 + 5 + 2);
    assert.equal((await t.api('GET', '/api/director/plans?project_id=dir')).data[0].progress, v2.progress);
  } finally { await t.close(); }
});

// ------------------------------------------------------------- Director = IA réelle (fournisseur requis)
test('exécution d\'une tâche du Director : erreur explicite sans fournisseur, résultat réel avec fournisseur', async () => {
  const t = await boot();
  try {
    await t.api('POST', '/api/projects', { name: 'Dir' });
    const v = await mkPlan(t);
    const spec = byTitle(v, 'Cahier');
    const r = await t.api('POST', `/api/director/tasks/${spec.id}/run`, {});
    assert.equal(r.status, 502); assert.match(r.data.error, /fournisseur/i);
    assert.equal(byTitle((await t.api('GET', `/api/director/plans/${v.plan.id}`)).data, 'Cahier').status, 'todo', 'tâche remise à todo après l\'échec');
    assert.equal((await t.api('POST', `/api/director/tasks/${byTitle(v, 'Construire').id}/run`, {})).status, 409, 'IA construite mais dépendances non terminées');
  } finally { await t.close(); }
});

test('Director avec fournisseur : exécute, transmet les résultats, plan IA validé, plan invalide refusé, bilan', async () => {
  const t = await bootWithStub();
  try {
    const pid = t.project.id;
    const v = (await t.api('POST', '/api/director/plans', { project_id: pid, template: 'vehicle' })).data;
    const spec = byTitle(v, 'Spécification');
    const done = (await t.api('POST', `/api/director/tasks/${spec.id}/run`, {})).data;
    assert.equal(done.status, 'done'); assert.match(done.result, /LIVRABLE-DIRECTOR/);
    // la tâche finale reçoit bien les résultats des précédentes (via dépendances terminées)
    const vq = (await t.api('GET', `/api/director/plans/${v.plan.id}`)).data;
    assert.equal(byTitle(vq, 'Modéliser').state, 'ready', 'MODELING est construite : la tâche est prête');
    // plan généré par l'IA
    const ai = (await t.api('POST', '/api/director/plans', { project_id: pid, ai: true, brief: 'Petite ville' })).data;
    assert.equal(ai.plan.source, 'ai'); assert.equal(ai.tasks.length, 4);
    assert.deepEqual(ai.tasks.map((x) => x.assignee), ['director', 'world', 'qa', 'director']);
    const bad = [['pas du json', /JSON/], [JSON.stringify({ tasks: [{ key: 'a', assignee: 'pirate', title: 't', depends_on: [] }] }), /IA inconnue/], [JSON.stringify({ tasks: [{ key: 'a', assignee: 'qa', title: 't', depends_on: ['b'] }, { key: 'b', assignee: 'qa', title: 'u', depends_on: ['a'] }] }), /cycle/]];
    for (const [out, re] of bad) {
      t.stub.st.badDirectorPlan = out;
      const r = await t.api('POST', '/api/director/plans', { project_id: pid, ai: true, brief: 'x' });
      assert.equal(r.status, 502); assert.match(r.data.error, re);
    }
    assert.equal((await t.api('GET', `/api/director/plans?project_id=${pid}`)).data.length, 2, 'aucun plan partiel créé');
    // bilan
    const rep = (await t.api('GET', `/api/director/report?project_id=${pid}`)).data.markdown;
    assert.match(rep, /Bilan de production/); assert.match(rep, /OPS ANIMATION AI \| construite/); assert.match(rep, /Chemin critique/);
    const repAi = (await t.api('GET', `/api/director/report?project_id=${pid}&ai=1`)).data.markdown;
    assert.match(repAi, /Analyse du Director/);
  } finally { await t.close(); }
});

// ------------------------------------------------------------- messagerie, mémoire, contexte
test('messagerie inter-IA, décisions et paquet de contexte partagé', async () => {
  const t = await boot();
  try {
    await t.api('POST', '/api/projects', { name: 'Dir' });
    const m = (await t.api('POST', '/api/director/messages', { project_id: 'dir', from: 'director', to: 'director', kind: 'note', body: 'rappel' })).data;
    assert.equal(m.status, 'pending');
    const q = (await t.api('POST', '/api/director/messages', { project_id: 'dir', from: 'director', to: 'qa', kind: 'request', body: 'plan de test' })).data;
    assert.equal(q.status, 'pending');
    assert.equal((await t.api('POST', '/api/director/messages', { project_id: 'dir', from: 'x', to: 'qa', body: 'a' })).status, 400);
    assert.equal((await t.api('POST', '/api/director/messages', { project_id: 'dir', from: 'qa', to: 'director', kind: 'bidon', body: 'a' })).status, 400);
    assert.equal((await t.api('POST', '/api/director/messages', { project_id: 'dir', from: 'qa', to: 'director', body: ' ' })).status, 400);
    assert.equal((await t.api('POST', `/api/director/messages/${m.id}/read`, {})).status, 200);
    assert.equal((await t.api('GET', '/api/director/messages?project_id=dir&status=pending')).data.length, 1);
    assert.equal((await t.api('GET', '/api/studio?project_id=dir')).data.find((a) => a.id === 'qa').inbox, 1);
    await t.api('POST', '/api/director/decisions', { project_id: 'dir', title: 'Cible mobile', body: '2 Go de RAM, 30 fps' });
    await t.api('POST', '/api/library', { name: 'notes.md', content: Buffer.from('x').toString('base64'), project_id: 'dir' });
    await t.api('POST', '/api/director/plans', { project_id: 'dir', template: 'mission' });
    const c = (await t.api('GET', '/api/director/context?project_id=dir')).data;
    assert.equal(c.decisions[0].title, 'Cible mobile'); assert.equal(c.library[0].name, 'notes.md'); assert.equal(c.plans.length, 1);
    assert.equal(c.ais.find((a) => a.id === 'animation').status, 'built');
    // les décisions sont aussi dans la mémoire partagée du projet (vue par tous les agents)
    assert.ok((await t.api('GET', '/api/projects/dir/memory')).data.some((x) => /Cible mobile/.test(x.key)));
  } finally { await t.close(); }
});

// ------------------------------------------------------------- moteurs : vérification réelle
test('moteurs : « verified » seulement après un vrai test (HTTP et dossier d\'échange)', async () => {
  const t = await boot();
  const srv = http.createServer((q, r) => { r.statusCode = q.url === '/bad' ? 500 : 200; r.end('ok'); });
  await new Promise((r) => srv.listen(0, '127.0.0.1', r));
  const base = `http://127.0.0.1:${srv.address().port}`;
  try {
    await t.api('POST', '/api/projects', { name: 'Eng' });
    const add = (b) => t.api('POST', '/api/engines', { project_id: 'eng', ...b });
    const good = (await add({ name: 'Euphoria', kind: 'http', endpoint: base + '/health', formats: 'fbx, JSON' })).data;
    assert.equal(good.status, 'declared'); assert.deepEqual(good.formats, ['fbx', 'json']);
    assert.equal((await t.api('POST', `/api/engines/${good.id}/check`, {})).data.status, 'verified');
    const bad = (await add({ name: 'Cassé', kind: 'http', endpoint: base + '/bad' })).data;
    assert.equal((await t.api('POST', `/api/engines/${bad.id}/check`, {})).data.status, 'failed');
    const dead = (await add({ name: 'Éteint', kind: 'http', endpoint: 'http://127.0.0.1:9/x' })).data;
    const d = (await t.api('POST', `/api/engines/${dead.id}/check`, {})).data;
    assert.equal(d.status, 'failed'); assert.match(d.detail, /échec/);
    const fe = (await add({ name: 'City Studio', kind: 'files', exchange_dir: 'exchange/city' })).data;
    const c = (await t.api('POST', `/api/engines/${fe.id}/check`, {})).data;
    assert.equal(c.status, 'verified'); assert.match(c.detail, /aller-retour/);
    assert.deepEqual(fs.readdirSync(path.join(t.dir, 'projects/eng/workspace/exchange/city')), [], 'sonde nettoyée');
    assert.equal((await add({ name: 'Évasion', kind: 'files', exchange_dir: '../../etc' })).status, 403);
    assert.equal((await add({ name: 'X', kind: 'http', endpoint: 'ftp://x' })).status, 400);
    assert.equal((await add({ name: 'X', kind: 'autre' })).status, 400);
    assert.equal((await t.api('DELETE', `/api/engines/${bad.id}`)).status, 409);
    assert.equal((await t.api('DELETE', `/api/engines/${bad.id}?confirm=1`)).status, 200);
    assert.match((await t.api('GET', '/api/director/report?project_id=eng')).data.markdown, /Euphoria \(http\) : \*\*verified\*\*/);
  } finally { srv.close(); await t.close(); }
});

// ------------------------------------------------------------- format d'échange
test('ops-exchange : export → import identique, dry-run, conflits, intégrité, chemins piégés, zip-bomb', async () => {
  const t = await boot();
  try {
    await t.api('POST', '/api/projects', { name: 'Src' }); await t.api('POST', '/api/projects', { name: 'Dst' });
    await t.api('PUT', '/api/projects/src/file', { path: 'models/car.json', content: '{"wheels":4}' });
    await t.api('PUT', '/api/projects/src/file', { path: 'tex/a.bin', content: Buffer.from([1, 2, 3, 0, 255]).toString('base64'), encoding: 'base64' });
    await t.api('PUT', '/api/projects/src/file', { path: 'other/x.txt', content: 'x' });
    const get = async (qs = '') => Buffer.from(await (await fetch(`${t.base}/api/projects/src/exchange.zip${qs}`, { headers: { authorization: 'Bearer tok-test-123' } })).arrayBuffer());
    const pkg = await get('?paths=models,tex');
    const entries = readZip(pkg);
    const mf = JSON.parse(entries.find((e) => e.name === 'manifest.json').data);
    assert.equal(mf.format, 'ops-exchange'); assert.deepEqual(mf.assets.map((a) => a.path).sort(), ['models/car.json', 'tex/a.bin']);
    assert.equal(mf.assets.find((a) => a.path === 'models/car.json').format, 'json');
    const imp = (b) => t.api('POST', '/api/projects/dst/exchange/import', b);
    const dry = (await imp({ content: pkg.toString('base64'), dry_run: true })).data;
    assert.equal(dry.dry_run, true); assert.deepEqual(dry.files.map((f) => f.status), ['new', 'new']);
    assert.equal((await t.api('GET', '/api/projects/dst/files')).data.length, 0, 'dry-run n\'écrit rien');
    const done = (await imp({ content: pkg.toString('base64') })).data;
    assert.equal(done.written, 2);
    assert.deepEqual([...Buffer.from((await t.api('GET', '/api/projects/dst/file?path=tex/a.bin')).data.size ? [1, 2, 3, 0, 255] : [])], [1, 2, 3, 0, 255]);
    assert.equal(fs.readFileSync(path.join(t.dir, 'projects/dst/workspace/models/car.json'), 'utf8'), '{"wheels":4}');
    assert.equal((await imp({ content: pkg.toString('base64') })).data.written, 0, 'identique : rien à réécrire');
    // conflit
    await t.api('PUT', '/api/projects/dst/file', { path: 'models/car.json', content: '{"wheels":3}' });
    const c = await imp({ content: pkg.toString('base64') });
    assert.equal(c.status, 409); assert.equal(c.data.code, 'conflict');
    assert.equal(fs.readFileSync(path.join(t.dir, 'projects/dst/workspace/models/car.json'), 'utf8'), '{"wheels":3}');
    assert.equal((await imp({ content: pkg.toString('base64'), overwrite: true })).data.written, 1);
    const chg = (await t.api('GET', '/api/projects/dst/changes')).data.find((x) => x.path === 'models/car.json' && x.action === 'modify');
    assert.ok(chg, 'remplacement sauvegardé et annulable');
    // paquets invalides
    const mk = (manifest, files) => makeZip([{ name: 'manifest.json', data: Buffer.from(JSON.stringify(manifest)) }, ...files]).toString('base64');
    const data = Buffer.from('hello');
    const A = (p, extra = {}) => ({ format: 'ops-exchange', version: 1, assets: [{ path: p, size: 5, sha1: sha1(data), ...extra }] });
    assert.equal((await imp({ content: mk(A('a.txt', { sha1: 'deadbeef' }), [{ name: 'files/a.txt', data }]) })).data.code, 'integrity');
    assert.equal((await imp({ content: mk(A('../evil.txt'), [{ name: 'files/../evil.txt', data }]) })).data.code, 'bad_path');
    assert.equal((await imp({ content: mk(A('/etc/x'), [{ name: 'files//etc/x', data }]) })).data.code, 'bad_path');
    assert.equal((await imp({ content: mk(A('manquant.txt'), []) })).data.code, 'missing');
    assert.equal((await imp({ content: mk({ format: 'ops-exchange', version: 9, assets: [{}] }, []) })).data.code, 'bad_version');
    assert.equal((await imp({ content: mk({ format: 'autre' }, []) })).data.code, 'bad_package');
    assert.equal((await imp({ content: Buffer.from('pas un zip').toString('base64') })).data.code, 'bad_package');
    assert.ok(!fs.existsSync(path.join(t.dir, 'projects/dst/evil.txt')) && !fs.existsSync(path.join(t.dir, 'projects/evil.txt')));
    // zip-bomb : taille déclarée excessive refusée avant décompression
    const bomb = makeZip([{ name: 'manifest.json', data: Buffer.alloc(70 * 1024 * 1024, 0) }]);
    assert.throws(() => readZip(bomb), /excessive/);
    assert.equal((await t.api('GET', '/api/projects/src/exchange.zip?paths=inexistant')).status === 200, false);
  } finally { await t.close(); }
});

// ------------------------------------------------------------- conversation directe
test('chat direct avec le Director : réponse réelle, historique, contexte ; sans fournisseur : erreur ; IA non construite : refus', async () => {
  const t = await bootWithStub();
  try {
    const pid = t.project.id;
    assert.equal((await t.api('POST', '/api/studio/animation/chat', { project_id: pid, text: 'bonjour' })).status, 200);
    assert.equal((await t.api('POST', '/api/studio/inconnue/chat', { project_id: pid, text: 'bonjour' })).status, 404);
    assert.equal((await t.api('POST', '/api/studio/director/chat', { project_id: pid, text: '  ' })).status, 400);
    assert.equal((await t.api('POST', '/api/studio/director/chat', { project_id: 'nope', text: 'a' })).status, 404);
    const r1 = (await t.api('POST', '/api/studio/director/chat', { project_id: pid, text: 'Salut Director' })).data;
    assert.match(r1.reply, /1 message\(s\) utilisateur/); assert.deepEqual(r1.actions, []);
    const r2 = (await t.api('POST', '/api/studio/director/chat', { project_id: pid, text: 'Et ensuite ?' })).data;
    assert.match(r2.reply, /2 message\(s\) utilisateur/, 'l\'historique est transmis au modèle');
    assert.match(t.stub.st.directorSeen[0], /MODE CONVERSATION DIRECTE/);
    assert.match(t.stub.st.directorSeen[0], /Projet Test/, 'contexte réel du projet dans le prompt');
    const msgs = (await t.api('GET', `/api/messages?project_id=${pid}&agent_id=director`)).data;
    assert.deepEqual(msgs.map((m) => m.role), ['user', 'assistant', 'user', 'assistant']);
    assert.equal((await t.api('GET', `/api/messages?project_id=${pid}&agent_id=team`)).data.length, 0, 'fil séparé du chat équipe');
  } finally { await t.close(); }
  const t2 = await boot();
  try {
    await t2.api('POST', '/api/projects', { name: 'Sans IA' });
    const r = await t2.api('POST', '/api/studio/director/chat', { project_id: 'sans-ia', text: 'bonjour' });
    assert.equal(r.status, 502); assert.match(r.data.error, /fournisseur/i);
  } finally { await t2.close(); }
});

test('chat direct : actions réelles (plan, décision, message), échecs rapportés honnêtement, limite de 5 actions', async () => {
  const t = await bootWithStub();
  try {
    const pid = t.project.id;
    const r = (await t.api('POST', '/api/studio/director/chat', { project_id: pid, text: 'Crée une ville' })).data;
    assert.equal(r.actions.length, 3); assert.ok(r.actions.every((a) => a.ok));
    assert.match(r.reply, /Actions effectuées/); assert.match(r.reply, /Plan « Ville du chat » créé \(9 tâches\)/);
    const plans = (await t.api('GET', `/api/director/plans?project_id=${pid}`)).data;
    assert.equal(plans.length, 1); assert.equal(plans[0].title, 'Ville du chat');
    assert.equal((await t.api('GET', `/api/director/decisions?project_id=${pid}`)).data[0].key, 'décision : Cible');
    const q = (await t.api('GET', `/api/director/messages?project_id=${pid}&to=animation`)).data;
    assert.equal(q.length, 1); assert.equal(q[0].status, 'pending'); assert.match(q[0].body, /plan de ville/);
    // actions invalides : rien n'est créé, chaque échec est dit
    const bad = (await t.api('POST', '/api/studio/director/chat', { project_id: pid, text: 'actions invalides' })).data;
    assert.equal(bad.actions.length, 3); assert.ok(bad.actions.every((a) => !a.ok));
    assert.match(bad.reply, /⛔/);
    assert.equal((await t.api('GET', `/api/director/plans?project_id=${pid}`)).data.length, 1);
    // limite
    const many = (await t.api('POST', '/api/studio/director/chat', { project_id: pid, text: 'trop d\'actions' })).data;
    assert.equal(many.actions.filter((a) => a.ok).length, 5); assert.ok(many.actions.some((a) => a.type === 'limit'));
    // la tâche ajoutée par le chat doit appartenir à un plan du projet
    const planId = plans[0].id;
    const ok = await t.app.ctx.director.chat(pid, 'Crée une ville').catch((e) => e);
    assert.ok(ok.actions, 'le chat reste utilisable après des échecs');
    assert.ok((await t.api('GET', '/api/journal?project_id=' + pid)).data.some((j) => j.action === 'chat'));
    assert.ok(planId);
  } finally { await t.close(); }
});

test('les IA AAA spécialisées exécutent leurs tâches avec leur prompt métier et partagent le contexte', async () => {
  const t = await bootWithStub();
  try {
    const pid = t.project.id;
    const plan = (await t.api('POST', '/api/director/plans', { project_id: pid, template: 'mission' })).data;
    const task = (await t.api('POST', `/api/director/plans/${plan.plan.id}/tasks`, { title: 'Créer les comportements autonomes', description: 'Perception, mémoire, routines et navigation des PNJ.', assignee: 'npc' })).data;
    const run = await t.api('POST', `/api/director/tasks/${task.id}/run`, {});
    assert.equal(run.status, 200, JSON.stringify(run.data));
    assert.equal(run.data.status, 'done');
    const req = t.stub.st.requests.find((x) => /spécialiste IA de personnages non-joueurs AAA/.test(x.sys));
    assert.ok(req, 'OPS NPC AI reçoit son propre prompt métier');
    assert.match(req.last, /Projet Test/);
    const chat = await t.api('POST', '/api/studio/animation/chat', { project_id: pid, text: 'Comment organises-tu le retargeting ?' });
    assert.equal(chat.status, 200);
    assert.equal(chat.data.agent, 'animation');
    assert.match(t.stub.st.requests.at(-1).sys, /spécialiste animation AAA/);
  } finally { await t.close(); }
});
