import test from 'node:test';
import assert from 'node:assert/strict';
import { calculateExpression, extractMathExpression, neuralSystemContext, NEURAL_MODULES, analyzeNeuralRequest, neuralQualityChecklist, aaaDetailContract } from '../server/neural.mjs';

test('OPS NEURAL MATH calcule les priorités, fractions, puissances et parenthèses', () => {
  assert.equal(calculateExpression('2 + 3 * 4').value, 14);
  assert.equal(calculateExpression('(1/2) + (1/3)').exact, '0.833333333333');
  assert.equal(calculateExpression('(1/2) + (1/3)').fraction, '5/6');
  assert.equal(calculateExpression('2^3^2').value, 512);
  assert.throws(() => calculateExpression('1/0'), /Division par zéro/);
  assert.throws(() => calculateExpression('process.exit()'));
});

test('la détection mathématique évite la recherche web et reconnaît une demande de calcul', () => {
  assert.equal(extractMathExpression('Calcule 25 * 4').exact, '100');
  assert.equal(extractMathExpression('Bonjour, comment vas-tu ?'), null);
});

test('le contexte neuronal transmet mémoire et historique', () => {
  const s = neuralSystemContext({ memories:[{agent_id:'user',key:'choix',value:'ne rien supprimer'}], history:[{role:'user',content:'Garder tous les moteurs'}], analysis: analyzeNeuralRequest('Développer une animation 3D', ['animation','engine3d']) });
  assert.match(s, /ne rien supprimer/);
  assert.match(s, /Garder tous les moteurs/);
  assert.ok(NEURAL_MODULES.length >= 14);
  assert.match(s, /OPS NEURAL ANALYSIS/);
  assert.match(s, /Collaboration obligatoire/);
  assert.match(s, /Gestion des conflits/);
});


test('OPS NEURAL ANALYSIS détecte les domaines AAA et les risques de préservation', () => {
  const a = analyzeNeuralRequest('Développer les animations 3D, améliorer les missions et ne supprimer aucune fonction', ['animation','engine3d','gameplay','quality']);
  assert.ok(a.recommended_agents.includes('animation'));
  assert.ok(a.recommended_agents.includes('engine3d'));
  assert.ok(a.recommended_agents.includes('gameplay'));
  assert.ok(a.risks.some((r) => r.id === 'preservation' && r.level === 'high'));
  assert.ok(a.complexity >= 2);
});

test('OPS NEURAL QUALITY GATE signale les contrôles incomplets sans inventer de réussite', () => {
  const q = neuralQualityChecklist({ tasks:[{ depends_on:[] }], files:[], risks:[] });
  assert.ok(q.score < 100);
  assert.ok(q.incomplete.includes('files'));
  assert.ok(q.incomplete.includes('preservation'));
  assert.ok(q.incomplete.includes('tests'));
});

test('contrat de détail AAA spécialisé : exigences concrètes pour chaque métier', () => {
  for (const id of ['director','world','modeling','satellite','webresearch','animation','npc','physics','vehicle','gameplay','graphics','story','qa']) {
    const c = aaaDetailContract(id);
    assert.match(c, /critères d'acceptation/);
    assert.match(c, /AUTO-AMÉLIORATION/i);
    assert.ok(c.length > 900, `${id} doit recevoir un contrat détaillé`);
  }
  assert.match(aaaDetailContract('npc'), /mémoire courte\/longue/);
  assert.match(aaaDetailContract('npc'), /navigation/);
  assert.match(aaaDetailContract('physics'), /synchronisation fixe/);
  assert.match(aaaDetailContract('graphics'), /budgets GPU/);
  assert.match(aaaDetailContract('webresearch'), /sources primaires/);
  assert.match(aaaDetailContract('satellite'), /provenance/);
  assert.match(aaaDetailContract('npc'), /mémoire courte\/longue/);
  assert.match(aaaDetailContract('npc'), /navigation/);
  assert.match(aaaDetailContract('physics'), /synchronisation fixe/);
  assert.match(aaaDetailContract('director'), /contrats d.interface/);
});
