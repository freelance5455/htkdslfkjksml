import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { createApp } from '../server/app.mjs';
import { startStub } from './stub-provider.mjs';

export async function boot(over = {}) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'ops-test-'));
  const app = await createApp({ dataDir: dir, port: 0, token: 'tok-test-123', automation: false, seedProjects: false, ...over });
  const port = await app.listen();
  const base = `http://127.0.0.1:${port}`;
  const api = async (method, url, body, token = 'tok-test-123') => {
    const r = await fetch(base + url, { method, headers: { 'content-type': 'application/json', ...(token ? { authorization: `Bearer ${token}` } : {}) }, body: body === undefined ? undefined : JSON.stringify(body) });
    const text = await r.text();
    let data; try { data = JSON.parse(text); } catch { data = text; }
    return { status: r.status, data };
  };
  return { app, dir, base, port, api, async close() { await app.close(); fs.rmSync(dir, { recursive: true, force: true }); } };
}

/** Démarre l'app + un faux fournisseur compatible OpenAI et le configure comme fournisseur par défaut. */
export async function bootWithStub(over = {}) {
  const t = await boot(over);
  const stub = await startStub();
  const prov = await t.api('POST', '/api/providers', { name: 'Stub', kind: 'openai', base_url: stub.url, model: 'stub-model', api_key: stub.key });
  await t.api('PUT', '/api/settings', { default_provider_id: prov.data.id });
  const proj = await t.api('POST', '/api/projects', { name: 'Projet Test', description: 'test' });
  return { ...t, stub, provider: prov.data, project: proj.data, async close() { await stub.close(); await t.close(); } };
}

export async function waitRun(api, runId, timeout = 20000) {
  const t0 = Date.now();
  for (;;) {
    const r = (await api('GET', `/api/runs/${runId}`)).data;
    if (['done', 'failed', 'partial', 'cancelled', 'interrupted'].includes(r.status)) return r;
    if (Date.now() - t0 > timeout) throw new Error('timeout run : ' + r.status);
    await new Promise((x) => setTimeout(x, 40));
  }
}
