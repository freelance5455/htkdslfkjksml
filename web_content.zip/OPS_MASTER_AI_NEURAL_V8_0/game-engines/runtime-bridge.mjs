/** Pont commun : raccorde les moteurs OPS au cycle de vie réel du jeu sans imposer de moteur graphique. */
export function createOPSGameRuntime({ npc, physics, gameplay, animation, events } = {}) {
  if (!npc && !physics && !gameplay && !animation) throw new Error('Au moins un moteur OPS doit être fourni.');
  let running = false, last = null;
  const listeners = new Set();
  function update(timestamp, context = {}) {
    if (!running) return null;
    const now = Number(timestamp) || 0; const dt = last === null ? 0 : Math.max(0, Math.min((now-last)/1000, 0.1)); last = now;
    const result = { dt, npc: npc?.update(dt, context) ?? null, physics: physics?.update(dt) ?? null,
      gameplay: gameplay?.update?.(dt, context) ?? null, animation: animation?.update?.(dt, context) ?? null };
    for (const fn of listeners) fn(result);
    events?.emit?.('ops:runtime:update', result); return result;
  }
  return {
    start() { running = true; last = null; return this; },
    stop() { running = false; last = null; return this; },
    update,
    onUpdate(fn) { listeners.add(fn); return () => listeners.delete(fn); },
    get running() { return running; },
    get engines() { return { npc: !!npc, physics: !!physics, gameplay: !!gameplay, animation: !!animation }; }
  };
}

/** À appeler depuis le vrai game loop (requestAnimationFrame, Unity Update, Godot _process, etc.). */
export function connectOPSGameLoop(runtime, gameLoop, getContext = () => ({})) {
  if (!runtime || typeof runtime.update !== 'function' || typeof gameLoop?.subscribe !== 'function')
    throw new TypeError('Le jeu doit fournir gameLoop.subscribe(callback) et un runtime OPS valide.');
  runtime.start();
  const unsubscribe = gameLoop.subscribe((time) => runtime.update(time, getContext()));
  return () => { unsubscribe?.(); runtime.stop(); };
}
