/** OPS NPC Engine — noyau déterministe sans dépendance moteur. L'adaptateur du jeu fournit navigation/perception. */
export class OPSNPCEngine {
  constructor({ adapter = {}, maxUpdatesPerFrame = 200, inactiveDistance = Infinity } = {}) {
    this.adapter = adapter; this.maxUpdatesPerFrame = maxUpdatesPerFrame; this.inactiveDistance = inactiveDistance;
    this.agents = new Map(); this.events = []; this.clock = 0;
  }
  register(id, config = {}) {
    if (!id || this.agents.has(id)) throw new Error(`NPC id invalide ou déjà enregistré : ${id}`);
    const agent = { id, state: config.state || 'idle', position: config.position || { x: 0, y: 0, z: 0 }, target: null,
      memory: [], memoryLimit: Math.max(0, Math.min(100, config.memoryLimit ?? 12)), update: config.update || null,
      active: config.active !== false, metadata: config.metadata || {} };
    this.agents.set(id, agent); return agent;
  }
  remove(id) { return this.agents.delete(id); }
  get(id) { return this.agents.get(id) || null; }
  remember(id, event) {
    const a = this.get(id); if (!a) return false;
    a.memory.push({ at: this.clock, event }); if (a.memory.length > a.memoryLimit) a.memory.splice(0, a.memory.length - a.memoryLimit); return true;
  }
  emit(event) { this.events.push(event); if (this.events.length > 500) this.events.shift(); }
  setState(id, state, detail = null) { const a = this.get(id); if (!a) return false; const previous = a.state; a.state = state; this.emit({ type: 'npc:state', id, previous, state, detail, at: this.clock }); return true; }
  update(dt, context = {}) {
    const delta = Math.max(0, Math.min(Number(dt) || 0, 0.1)); this.clock += delta;
    const player = context.playerPosition || null; let updated = 0;
    for (const a of this.agents.values()) {
      if (!a.active || updated >= this.maxUpdatesPerFrame) continue;
      if (player && Number.isFinite(this.inactiveDistance)) {
        const dx = a.position.x-player.x, dy = a.position.y-player.y, dz = a.position.z-player.z;
        if (dx*dx+dy*dy+dz*dz > this.inactiveDistance*this.inactiveDistance) continue;
      }
      const sensed = this.adapter.perceive?.(a, context) ?? {};
      const nav = this.adapter.navigate?.(a, context) ?? null;
      if (typeof a.update === 'function') {
        const next = a.update({ npc: a, dt: delta, context, sensed, navigation: nav, memory: [...a.memory] });
        if (next?.state && next.state !== a.state) this.setState(a.id, next.state, next.detail ?? null);
        if (next?.position) a.position = { ...a.position, ...next.position };
        if (next?.remember !== undefined) this.remember(a.id, next.remember);
      }
      updated++;
    }
    const events = this.events.splice(0, this.events.length);
    return { updated, total: this.agents.size, events };
  }
  snapshot() { return [...this.agents.values()].map(a => ({ id:a.id, state:a.state, position:{...a.position}, active:a.active, memory:[...a.memory] })); }
}
