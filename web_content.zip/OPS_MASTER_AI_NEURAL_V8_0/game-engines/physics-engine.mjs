/** OPS Physics Engine — orchestration fixed-step. Le calcul physique est délégué au backend réel du jeu. */
export class OPSPhysicsEngine {
  constructor({ backend, fixedStep = 1/60, maxSubSteps = 5 } = {}) {
    if (!backend || typeof backend.step !== 'function') throw new TypeError('Un backend physique compatible avec step(dt) est requis.');
    this.backend = backend; this.fixedStep = Math.max(1/240, Math.min(1/20, fixedStep));
    this.maxSubSteps = Math.max(1, Math.min(12, maxSubSteps|0)); this.accumulator = 0; this.droppedTime = 0;
  }
  addBody(spec) { if (!this.backend.addBody) throw new Error('Backend sans addBody'); return this.backend.addBody(spec); }
  removeBody(id) { return this.backend.removeBody?.(id) ?? false; }
  addCollider(spec) { if (!this.backend.addCollider) throw new Error('Backend sans addCollider'); return this.backend.addCollider(spec); }
  raycast(origin, direction, maxDistance = Infinity) { return this.backend.raycast?.(origin, direction, maxDistance) ?? null; }
  applyImpulse(id, impulse) { if (!this.backend.applyImpulse) throw new Error('Backend sans applyImpulse'); return this.backend.applyImpulse(id, impulse); }
  update(frameDt) {
    this.accumulator += Math.max(0, Math.min(Number(frameDt) || 0, 0.25));
    let steps = 0;
    while (this.accumulator >= this.fixedStep && steps < this.maxSubSteps) {
      this.backend.step(this.fixedStep); this.accumulator -= this.fixedStep; steps++;
    }
    if (this.accumulator >= this.fixedStep) { const keep = this.accumulator % this.fixedStep; this.droppedTime += this.accumulator - keep; this.accumulator = keep; }
    this.backend.syncRender?.(this.accumulator / this.fixedStep);
    return { steps, alpha: this.accumulator / this.fixedStep, droppedTime: this.droppedTime };
  }
}
