import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { loadConfig } from './config.mjs';
import { openDb } from './db.mjs';
import { attachWs } from './ws.mjs';
import { seedAgents, ALL_AGENT_IDS } from './agents.mjs';
import { createProviders, KINDS, ProviderError } from './providers.mjs';
import { createWeb } from './web.mjs';
import { createWorkspace } from './workspace.mjs';
import { createOrchestrator } from './orchestrator.mjs';
import { createTesting } from './testing.mjs';
import { createVisualTesting } from './visual-testing.mjs';
import { createGameplayTesting } from './gameplay-testing.mjs';
import { createBugFixer } from './bug-fixer.mjs';
import { createAutomation } from './automation.mjs';
import { createLibrary } from './library.mjs';
import { createDirector } from './director.mjs';
import { createWorld } from './world.mjs';
import { createModeling } from './modeling.mjs';
import { NEURAL_MODULES } from './neural.mjs';
import { createExchange, createEngines } from './exchange.mjs';
import { createCollaboration } from './collaboration.mjs';
import { createProjectManager } from './project-manager.mjs';
import { createAutonomousSupervisor } from './autonomous-supervisor.mjs';
import { createControlCenter } from './control-center.mjs';
import { createOrchestrationEngine } from './orchestration-engine.mjs';
import { createLearningEngine } from './learning-engine.mjs';
import { createBenchmarkEngine } from './benchmark-engine.mjs';
import { createOperationalReadiness } from './operational-readiness.mjs';
import { createReleaseGate } from './release-gate.mjs';
import { createReleaseManifest } from './release-manifest.mjs';
import { createProduction } from './production.mjs';
import { HttpError, safeEqual, now } from './util.mjs';

const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.json': 'application/json', '.webmanifest': 'application/manifest+json', '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon' };
const CSP = "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; connect-src 'self' ws: wss:; frame-ancestors 'none'; base-uri 'none'";

const SEED_PROJECTS = [
  { name: 'OPÉRATION SURVIVANT 3D', id: 'operation-survivant-3d', description: 'Jeu de survie/tir 3D.' },
  { name: 'FBX STUDIO 3D', id: 'fbx-studio-3d', description: 'Studio d’import, édition et export FBX.' },
  { name: 'CITY & VEHICLE STUDIO 3D', id: 'city-vehicle-studio-3d', description: 'Studio de villes et véhicules 3D (V3.8 Universal Internet importée).', importFrom: 'city-vehicle-studio-v3.8' },
  { name: 'EUPHORIA 3D ENGINE', id: 'euphoria-3d-engine', description: 'Moteur d’animation physique 3D.' },
];

export async function createApp(over = {}) {
  const config = loadConfig(over);
  const db = await openDb(config);
  await seedAgents(db);

  const clients = { broadcast: () => {} };
  const ctx = { config, db, events: { emit: (type, data) => clients.broadcast({ type, data, ts: now() }) } };
  ctx.collaboration = createCollaboration(ctx);
  ctx.projectManager = createProjectManager(ctx);
  ctx.providers = createProviders(ctx);
  ctx.web = createWeb(ctx);
  ctx.workspace = createWorkspace(ctx);
  ctx.supervisor = createAutonomousSupervisor(ctx);
  ctx.controlCenter = createControlCenter(ctx);
  ctx.orchestration = createOrchestrationEngine(ctx);
  ctx.learning = createLearningEngine(ctx);
  ctx.benchmark = createBenchmarkEngine(ctx);
  ctx.readiness = createOperationalReadiness(ctx);
  ctx.releaseGate = createReleaseGate(ctx);
  ctx.releaseManifest = createReleaseManifest(ctx);
  ctx.library = createLibrary(ctx);
  ctx.engines = createEngines(ctx);
  ctx.exchange = createExchange(ctx);
  ctx.director = createDirector(ctx);
  await ctx.director.seed();
  ctx.world = createWorld(ctx);
  await ctx.world.seed();
  ctx.modeling = createModeling(ctx);
  await ctx.modeling.seed();
  ctx.orchestrator = createOrchestrator(ctx);
  ctx.testing = createTesting(ctx);
  ctx.visualTesting = createVisualTesting(ctx);
  ctx.gameplayTesting = createGameplayTesting(ctx);
  ctx.bugFixer = createBugFixer(ctx);
  ctx.production = createProduction(ctx);
  ctx.automation = createAutomation(ctx);

  if (config.seedProjects) {
    for (const sp of SEED_PROJECTS) {
      if (!(await db.get('SELECT id FROM projects WHERE id=?', [sp.id]))) {
        await ctx.workspace.createProject({ name: sp.name, id: sp.id, description: sp.description });
        const src = sp.importFrom && path.join(config.seedDir, sp.importFrom);
        if (src && fs.existsSync(src)) { await ctx.workspace.importDir(sp.id, src); await ctx.workspace.createVersion(sp.id, { label: 'Import initial V3.8', reason: 'import' }); }
      }
    }
  }
  await ctx.orchestrator.recoverInterrupted();
  await ctx.orchestration.recoverInterrupted();

  const fails = new Map();
  const authOk = (req, url) => {
    const h = req.headers.authorization || '';
    const t = h.startsWith('Bearer ') ? h.slice(7) : url.searchParams.get('token') || '';
    return t.length > 0 && safeEqual(t, config.token);
  };
  const limited = (ip) => { const f = fails.get(ip); if (!f) return false; if (now() - f.t >= 5 * 60000) { fails.delete(ip); return false; } return f.n >= 20; };

  // ---------- routes ----------
  const routes = [];
  const R = (method, pattern, fn) => routes.push({ method, re: new RegExp('^' + pattern.replace(/:(\w+)/g, '(?<$1>[^/]+)') + '$'), fn });
  const proj = (p) => ctx.workspace.getProject(decodeURIComponent(p.id));

  R('GET', '/api/control-center', async () => ctx.controlCenter.report());
  R('GET', '/api/projects/:id/orchestration', async (p) => { await proj(p); return ctx.orchestration.list(p.id); });
  R('POST', '/api/projects/:id/orchestration', async (p, _u, b) => { await proj(p); return ctx.orchestration.create(p.id, b); });
  R('GET', '/api/orchestration/:id', async (p) => ctx.orchestration.report(p.id));
  R('POST', '/api/orchestration/:id/start', async (p) => ctx.orchestration.start(p.id));
  R('POST', '/api/orchestration/:id/pause', async (p) => ctx.orchestration.pause(p.id));
  R('POST', '/api/orchestration/:id/resume', async (p) => ctx.orchestration.start(p.id));
  R('POST', '/api/orchestration/:id/tasks/:taskId/retry', async (p) => ctx.orchestration.retryTask(p.id, p.taskId));
  R('POST', '/api/orchestration/:id/advance', async (p) => ctx.orchestration.advance(p.id));
  R('GET', '/api/system/readiness', async (_p, u) => { const projectId=u.searchParams.get('project_id'); if(projectId) await proj({id:projectId}); return ctx.readiness.report(projectId); });
  R('GET', '/api/health', async () => ({ ok: true, name: 'OPS MASTER AI CHAT', version: config.version, database: db.kind }));
  R('GET', '/api/neural/status', async () => ({ name: 'OPS NEURAL SYSTEM', version: '3.29.0', mode: 'hybride déterministe + mémoire d’expériences validées + modèles configurés', modules: NEURAL_MODULES, limitations: ['La mémoire d’expériences ne modifie pas les poids des modèles externes', 'Les leçons restent en attente jusqu’à validation humaine', 'Les réponses des modèles restent dépendantes du fournisseur configuré'] }));
  R('GET', '/api/internal-core/status', async () => ctx.providers.internalStatus());
  R('POST', '/api/internal-core/chat', async (_p, _u, b) => {
    if (!b || typeof b.message !== 'string' || !b.message.trim()) throw new HttpError(400, 'message requis');
    if (b.message.length > 12000) throw new HttpError(413, 'message trop long (12 000 caractères maximum)');
    const agentId = typeof b.agent_id === 'string' ? b.agent_id.slice(0, 64) : 'coordinator';
    const r = await ctx.providers.internalChat({ id: agentId }, [{ role: 'user', content: b.message }]);
    return { ...r, internal: true, external_models_used: false };
  });
  R('GET', '/api/state', async () => {
    const providers = await ctx.providers.list();
    const projects = await ctx.workspace.listProjects();
    const row = async (sql, p = []) => Number((await db.get(sql, p)).n);
    return {
      version: config.version, database: db.kind, ws_clients: clients.count?.() || 0,
      providers: providers.length, providers_ready: providers.filter((p) => p.enabled && p.model && p.key_set).length,
      web: await ctx.web.status(), projects: projects.length,
      active_runs: ctx.orchestrator.activeCount(),
      pending_approvals: await row("SELECT COUNT(*) AS n FROM approvals WHERE status='pending'"),
      runs_total: await row('SELECT COUNT(*) AS n FROM runs'),
      tasks_error: await row("SELECT COUNT(*) AS n FROM tasks WHERE status IN ('error','blocked')"),
    };
  });
  // fournisseurs
  R('GET', '/api/providers', async () => ({ kinds: Object.fromEntries(Object.entries(KINDS).map(([k, v]) => [k, { label: v.label, defaultBase: v.defaultBase }])), providers: await Promise.all((await ctx.providers.list()).map(async (p) => ({ ...p, usage_today: await ctx.providers.usageToday(p.id) }))), default_provider_id: (await db.get("SELECT value FROM settings WHERE key='default_provider_id'"))?.value || '' }));
  R('POST', '/api/providers', async (_p, _u, b) => ctx.providers.create(b));
  R('PUT', '/api/providers/:id', async (p, _u, b) => ctx.providers.update(p.id, b));
  R('DELETE', '/api/providers/:id', async (p) => { await ctx.providers.remove(p.id); return { ok: true }; });
  R('POST', '/api/providers/:id/test', async (p) => ctx.providers.test(p.id));
  R('GET', '/api/providers/:id/models', async (p) => ctx.providers.models(p.id));
  // paramètres
  const SETTINGS = { default_provider_id: 'string', concurrency: 'int', max_correction_rounds: 'int' };
  R('GET', '/api/settings', async () => {
    const o = {};
    for (const k of Object.keys(SETTINGS)) o[k] = (await db.get('SELECT value FROM settings WHERE key=?', [k]))?.value ?? '';
    return { ...o, web: await ctx.web.status() };
  });
  R('PUT', '/api/settings', async (_p, _u, b) => {
    for (const [k, t] of Object.entries(SETTINGS)) {
      if (b[k] === undefined) continue;
      let v = b[k];
      if (t === 'int') { v = Math.floor(Number(v)); if (!(v >= 0 && v <= 10)) throw new HttpError(400, `${k} : entier 0–10`); if (k === 'concurrency' && v < 1) throw new HttpError(400, 'concurrency ≥ 1'); }
      await db.run('INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value', [k, String(v)]);
    }
    if (b.web) await ctx.web.configure(b.web);
    await ctx.workspace.log(null, 'user', 'settings.update', Object.keys(b).join(','));
    return { ok: true };
  });
  // agents
  R('GET', '/api/agents', async (_p, u) => {
    const agents = await db.all('SELECT id,name,role,system_prompt,provider_id,model,enabled,sort_order FROM agents ORDER BY sort_order');
    const pid = u.searchParams.get('project_id');
    const out = [];
    for (const a of agents) {
      const st = await db.get(`SELECT SUM(CASE WHEN status='done' THEN 1 ELSE 0 END) AS done, SUM(CASE WHEN status IN ('error','blocked') THEN 1 ELSE 0 END) AS err, SUM(CASE WHEN status='running' THEN 1 ELSE 0 END) AS running FROM tasks WHERE agent_id=? ${pid ? 'AND project_id=?' : ''}`, pid ? [a.id, pid] : [a.id]);
      out.push({ ...a, enabled: !!a.enabled, stats: { done: Number(st.done || 0), error: Number(st.err || 0), running: Number(st.running || 0) } });
    }
    return out;
  });
  R('PUT', '/api/agents/:id', async (p, _u, b) => {
    const a = await db.get('SELECT * FROM agents WHERE id=?', [p.id]);
    if (!a) throw new HttpError(404, 'Agent inconnu');
    if (b.provider_id) { if (!(await db.get('SELECT id FROM providers WHERE id=?', [b.provider_id]))) throw new HttpError(400, 'Fournisseur inconnu'); }
    await db.run('UPDATE agents SET system_prompt=?,provider_id=?,model=?,enabled=? WHERE id=?', [b.system_prompt ?? a.system_prompt, b.provider_id === undefined ? a.provider_id : (b.provider_id || null), b.model === undefined ? a.model : (b.model || null), b.enabled === undefined ? a.enabled : (b.enabled ? 1 : 0), p.id]);
    await ctx.workspace.log(null, 'user', 'agent.update', p.id);
    return { ok: true };
  });
  R('GET', '/api/agents/:id/history', async (p, u) => {
    const pid = u.searchParams.get('project_id');
    const tasks = await db.all(`SELECT id,run_id,project_id,title,status,error,attempts,started,finished,created FROM tasks WHERE agent_id=? ${pid ? 'AND project_id=?' : ''} ORDER BY created DESC LIMIT 50`, pid ? [p.id, pid] : [p.id]);
    const notes = await db.all(`SELECT project_id,key,value,created FROM memory WHERE agent_id=? ${pid ? 'AND project_id=?' : ''} ORDER BY created DESC LIMIT 50`, pid ? [p.id, pid] : [p.id]);
    return { tasks, notes };
  });
  // projets
  R('GET', '/api/projects', async () => ctx.workspace.listProjects(true));
  R('POST', '/api/projects', async (_p, _u, b) => ctx.workspace.createProject(b));
  R('GET', '/api/projects/:id', proj);
  R('PUT', '/api/projects/:id', async (p, _u, b) => ctx.workspace.updateProject(p.id, b));
  R('GET', '/api/projects/:id/manager', async (p) => { await proj(p); return ctx.projectManager.report(p.id); });
  R('POST', '/api/projects/:id/manager/dispatch', async (p, _u, b) => { await proj(p); return ctx.projectManager.dispatch(p.id, b); });
  R('GET', '/api/projects/:id/supervisor', async (p) => { await proj(p); return ctx.supervisor.report(p.id); });
  R('POST', '/api/projects/:id/supervisor/scan', async (p, _u, b) => { await proj(p); return ctx.supervisor.scan(p.id, { mode:b.mode || 'observe' }); });
  R('POST', '/api/projects/:id/supervisor/objective', async (p, _u, b) => { await proj(p); return ctx.supervisor.launchObjective(p.id, b || {}); });
  R('GET', '/api/projects/:id/collaboration/events', async (p, u) => { await proj(p); return ctx.collaboration.listEvents(p.id, { agentId: u.searchParams.get('agent_id'), limit: u.searchParams.get('limit'), since: u.searchParams.get('since') }); });
  R('POST', '/api/projects/:id/collaboration/events', async (p, _u, b) => { await proj(p); return ctx.collaboration.publish(p.id, { type: b.type, from: b.from, to: b.to, payload: b.payload }); });
  R('GET', '/api/projects/:id/collaboration/dependencies', async (p) => { await proj(p); return ctx.collaboration.listDependencies(p.id); });
  R('POST', '/api/projects/:id/collaboration/dependencies', async (p, _u, b) => { await proj(p); return ctx.collaboration.addDependency(p.id, b.prerequisite, b.dependent, b.contract); });
  R('GET', '/api/projects/:id/collaboration/work', async (p, u) => { await proj(p); return ctx.collaboration.listWorkItems(p.id, { agentId:u.searchParams.get('agent_id'), status:u.searchParams.get('status'), limit:u.searchParams.get('limit') }); });
  R('POST', '/api/projects/:id/collaboration/work', async (p, _u, b) => { await proj(p); return ctx.collaboration.createWorkItem(p.id, b); });
  R('PATCH', '/api/collaboration/work/:id', async (p, _u, b) => ctx.collaboration.updateWorkItem(p.id, { agentId:b.agent_id, status:b.status, result:b.result }));
  R('GET', '/api/projects/:id/collaboration/claims', async (p, u) => { await proj(p); return ctx.collaboration.listArtifactClaims(p.id, { activeOnly:u.searchParams.get('all')!=='1' }); });
  R('POST', '/api/projects/:id/collaboration/claims', async (p, _u, b) => { await proj(p); return ctx.collaboration.claimArtifacts(p.id, { agentId:b.agent_id, workItemId:b.work_item_id, paths:b.paths }); });
  R('POST', '/api/projects/:id/collaboration/claims/release', async (p, _u, b) => { await proj(p); return ctx.collaboration.releaseArtifacts(p.id, { agentId:b.agent_id, workItemId:b.work_item_id, paths:b.paths }); });
  R('GET', '/api/projects/:id/progress', async (p) => ctx.automation.progress(p.id));
  R('POST', '/api/projects/:id/suggest', async (p) => ctx.automation.aiSuggestions(p.id));
  R('GET', '/api/projects/:id/memory', async (p) => db.all('SELECT id,agent_id,key,value,created FROM memory WHERE project_id=? ORDER BY created DESC LIMIT 200', [p.id]));
  R('POST', '/api/projects/:id/memory', async (p, _u, b) => {
    await proj(p);
    if (!b.key || !b.value) throw new HttpError(400, 'key et value requis');
    await db.run('INSERT INTO memory(id,project_id,agent_id,key,value,created) VALUES(?,?,NULL,?,?,?)', ['mem_' + now() + Math.random().toString(36).slice(2, 6), p.id, String(b.key).slice(0, 80), String(b.value).slice(0, 4000), now()]);
    return { ok: true };
  });
  R('DELETE', '/api/memory/:id', async (p) => { await db.run('DELETE FROM memory WHERE id=?', [p.id]); return { ok: true }; });
  R('GET', '/api/projects/:id/experiences', async (p, u) => { await proj(p); const status = u.searchParams.get('status'); return db.all(`SELECT * FROM experience_memory WHERE (project_id=? OR project_id IS NULL) ${status ? 'AND status=?' : ''} ORDER BY created DESC LIMIT 250`, status ? [p.id, status] : [p.id]); });
  R('GET', '/api/projects/:id/benchmarks', async (p) => { await proj(p); return ctx.benchmark.report(p.id); });
  R('GET', '/api/projects/:id/release-gate', async (p) => { await proj(p); return ctx.releaseGate.report(p.id); });
  R('GET', '/api/projects/:id/release-manifest', async (p) => { await proj(p); return ctx.releaseManifest.report(p.id); });
  R('POST', '/api/projects/:id/release-manifest/snapshot', async (p, _u, b) => { await proj(p); return ctx.releaseManifest.snapshot(p.id, b.label); });
  R('POST', '/api/projects/:id/benchmarks/snapshot', async (p) => { await proj(p); return ctx.benchmark.snapshot(p.id); });
  R('GET', '/api/projects/:id/benchmarks/history', async (p) => { await proj(p); return ctx.benchmark.history(p.id); });
  R('GET', '/api/projects/:id/learning-stats', async (p) => { await proj(p); return ctx.learning.stats(p.id); });
  R('GET', '/api/projects/:id/experience-stats', async (p) => { await proj(p); const totals = await db.get("SELECT COUNT(*) AS total, SUM(CASE WHEN status='approved' THEN 1 ELSE 0 END) AS approved, SUM(CASE WHEN status='pending' THEN 1 ELSE 0 END) AS pending, SUM(CASE WHEN status='rejected' THEN 1 ELSE 0 END) AS rejected FROM experience_memory WHERE project_id=? OR project_id IS NULL", [p.id]); const used = await db.get("SELECT COUNT(*) AS retrievals, COUNT(DISTINCT experience_id) AS distinct_experiences FROM experience_events WHERE project_id=?", [p.id]); const top = await db.all("SELECT e.id,e.domain,e.lesson,COUNT(v.id) AS uses FROM experience_memory e LEFT JOIN experience_events v ON v.experience_id=e.id WHERE e.status='approved' AND (e.project_id=? OR e.project_id IS NULL) GROUP BY e.id ORDER BY uses DESC,e.created DESC LIMIT 10", [p.id]); return {totals, usage:used, most_used:top}; });
  R('POST', '/api/projects/:id/experiences', async (p, _u, b) => { await proj(p); if (!String(b.domain || '').trim() || !String(b.lesson || '').trim()) throw new HttpError(400, 'Domaine et leçon requis'); const id = 'exp_' + now() + Math.random().toString(36).slice(2,7); await db.run(`INSERT INTO experience_memory(id,project_id,agent_id,domain,lesson,evidence,status,source_task,created,reviewed) VALUES(?,?,?,?,?,?,'pending',NULL,?,NULL)`, [id,p.id,null,String(b.domain).slice(0,80),String(b.lesson).slice(0,2500),String(b.evidence||'Ajout manuel').slice(0,1000),now()]); return {ok:true,id}; });
  R('POST', '/api/experiences/:id/review', async (p, _u, b) => { const status = b.approved ? 'approved' : 'rejected'; const r = await db.run(`UPDATE experience_memory SET status=?,reviewed=?,project_id=CASE WHEN ? THEN NULL ELSE project_id END WHERE id=? AND status='pending'`, [status,now(),b.global ? 1 : 0,p.id]); if (!r.changes) throw new HttpError(404,'Expérience en attente introuvable'); return {ok:true,status}; });
  R('DELETE', '/api/experiences/:id', async (p) => { await db.run('DELETE FROM experience_memory WHERE id=?', [p.id]); return {ok:true}; });
  R('GET', '/api/projects/:id/preview', async (p, u) => { await proj(p); const rel = u.searchParams.get('path') || 'index.html'; const f = ctx.workspace.readFile(p.id, rel, {maxBytes: 1024*1024}); if (f.binary) throw new HttpError(415,'Aperçu indisponible pour un fichier binaire'); return {path:f.path,content:f.content,hash:f.hash}; });
  R('GET', '/api/projects/:id/inspection', async (p) => { await proj(p); const files = ctx.workspace.tree(p.id).filter(x => x.type === 'file'); const ext = {}; for (const f of files) { const e = (f.path.match(/\.([^.\/]+)$/)?.[1] || 'sans-extension').toLowerCase(); ext[e] = (ext[e] || 0) + 1; } const entries = files.filter(f => /(^|\/)(index\.html|package\.json|src\/(main|index)\.[cm]?[jt]sx?|main\.[cm]?[jt]sx?|README\.md)$/i.test(f.path)); const assets = files.filter(f => /\.(png|jpe?g|webp|svg|glb|gltf|fbx|obj|mp3|wav|ogg)$/i.test(f.path)); const experiences = await db.get("SELECT COUNT(*) AS total, SUM(CASE WHEN status='approved' THEN 1 ELSE 0 END) AS approved, SUM(CASE WHEN status='pending' THEN 1 ELSE 0 END) AS pending FROM experience_memory WHERE project_id=? OR project_id IS NULL", [p.id]); return {project:await ctx.workspace.getProject(p.id), file_count:files.length, total_bytes:files.reduce((n,f)=>n+(f.size||0),0), extensions:ext, entrypoints:entries, assets:assets.slice(0,120), tree:ctx.workspace.tree(p.id).slice(0,500), experience_memory:experiences}; });
  // fichiers
  R('GET', '/api/projects/:id/files', async (p) => { await proj(p); return ctx.workspace.tree(p.id); });
  R('GET', '/api/projects/:id/file', async (p, u) => { await proj(p); return ctx.workspace.readFile(p.id, u.searchParams.get('path')); });
  R('PUT', '/api/projects/:id/file', async (p, _u, b) => { await proj(p); return ctx.workspace.writeFile(p.id, b.path, b.content, { actor: 'user', encoding: b.encoding }); });
  R('DELETE', '/api/projects/:id/file', async (p, u) => { await proj(p); return ctx.workspace.deleteFile(p.id, u.searchParams.get('path'), { actor: 'user', confirm: u.searchParams.get('confirm') === '1' }); });
  R('GET', '/api/projects/:id/changes', async (p) => ctx.workspace.changes(p.id));
  R('POST', '/api/projects/:id/changes/:cid/undo', async (p, _u, b) => ctx.workspace.undoChange(p.id, p.cid, { force: !!b.force }));
  // versions
  R('GET', '/api/projects/:id/versions', async (p) => ctx.workspace.listVersions(p.id));
  R('POST', '/api/projects/:id/versions', async (p, _u, b) => ctx.workspace.createVersion(p.id, { label: b.label, reason: 'manuel' }));
  R('GET', '/api/projects/:id/versions/:vid/diff', async (p, u) => { const f = u.searchParams.get('path'); return f ? ctx.workspace.fileDiff(p.id, p.vid, f) : ctx.workspace.diffVersion(p.id, p.vid); });
  R('POST', '/api/projects/:id/versions/:vid/restore', async (p, _u, b) => ctx.workspace.restoreVersion(p.id, p.vid, { confirm: b.confirm === true }));
  R('GET', '/api/projects/:id/regression', async (p, u) => ctx.workspace.regression(p.id, u.searchParams.get('version')));
  // tests
  R('POST', '/api/projects/:id/tests', async (p) => { await proj(p); return ctx.testing.runChecks(p.id); });
  R('GET', '/api/projects/:id/tests', async (p) => ctx.testing.reports(p.id));
  R('POST', '/api/projects/:id/visual-tests', async (p, _u, b) => { await proj(p); return ctx.visualTesting.run(p.id, b || {}); });
  R('GET', '/api/projects/:id/visual-tests', async (p, u) => { await proj(p); return ctx.visualTesting.reports(p.id, u.searchParams.get('limit')); });
  R('GET', '/api/projects/:id/gameplay-tests/status', async (p) => { await proj(p); return ctx.gameplayTesting.status(); });
  R('POST', '/api/projects/:id/gameplay-tests', async (p, _u, b) => { await proj(p); return ctx.gameplayTesting.run(p.id, b || {}); });
  R('GET', '/api/projects/:id/gameplay-tests', async (p, u) => { await proj(p); return ctx.gameplayTesting.reports(p.id, u.searchParams.get('limit')); });
  R('POST', '/api/projects/:id/bug-fixes', async (p, _u, b) => { await proj(p); return ctx.bugFixer.start(p.id, b || {}); });
  R('GET', '/api/projects/:id/bug-fixes', async (p) => { await proj(p); return ctx.bugFixer.list(p.id); });
  R('GET', '/api/bug-fixes/:id', async (p) => ctx.bugFixer.get(p.id));
  R('POST', '/api/bug-fixes/:id/advance', async (p, _u, b) => ctx.bugFixer.advance(p.id, b || {}));
  R('POST', '/api/projects/:id/run', async (p, _u, b) => ctx.testing.runScript(p.id, b.script));
  // approbations
  R('GET', '/api/approvals', async (_p, u) => {
    const pid = u.searchParams.get('project_id'), st = u.searchParams.get('status') || 'pending';
    const rows = await db.all(`SELECT id,project_id,run_id,agent_id,kind,path,status,created,decided,${u.searchParams.get('full') ? 'content' : 'LENGTH(content) AS size'} FROM approvals WHERE status=? ${pid ? 'AND project_id=?' : ''} ORDER BY created DESC LIMIT 200`, pid ? [st, pid] : [st]);
    return rows;
  });
  R('GET', '/api/approvals/:id/diff', async (p) => {
    const a = await db.get('SELECT * FROM approvals WHERE id=?', [p.id]);
    if (!a) throw new HttpError(404, 'Introuvable');
    const { lineDiff } = await import('./workspace.mjs');
    let before = '';
    try { const f = ctx.workspace.readFile(a.project_id, a.path); before = f.binary ? '' : f.content; } catch { /* nouveau fichier */ }
    return { ...a, diff: a.kind === 'delete' ? { deleted: true, lines: before.split('\n').map((l) => '- ' + l) } : lineDiff(before, a.content || '') };
  });
  R('POST', '/api/approvals/:id/approve', async (p) => ctx.orchestrator.approve(p.id));
  R('POST', '/api/approvals/:id/reject', async (p) => ctx.orchestrator.reject(p.id));
  // chat & exécutions
  R('GET', '/api/messages', async (_p, u) => {
    const pid = u.searchParams.get('project_id'), ag = u.searchParams.get('agent_id');
    if (!pid) throw new HttpError(400, 'project_id requis');
    const rows = ag && ag !== 'team'
      ? await db.all('SELECT * FROM messages WHERE project_id=? AND agent_id=? ORDER BY created DESC LIMIT 100', [pid, ag])
      : await db.all("SELECT * FROM messages WHERE project_id=? AND (agent_id IS NULL OR agent_id='coordinator') ORDER BY created DESC LIMIT 100", [pid]);
    return rows.reverse();
  });
  R('POST', '/api/projects/:id/production', async (p, _u, b) => { await proj(p); return ctx.production.start({ project_id: p.id, title: b.title, brief: b.brief, constraints: b.constraints }); });
  R('GET', '/api/projects/:id/production', async (p) => { await proj(p); return ctx.production.list(p.id); });
  R('GET', '/api/production/:id', async (p) => ctx.production.get(p.id));
  R('GET', '/api/production/:id/release-gate', async (p) => { const pipeline = await db.get('SELECT project_id FROM production_pipelines WHERE id=?', [p.id]); if (!pipeline) throw new HttpError(404, 'Pipeline de production introuvable'); return ctx.releaseGate.report(pipeline.project_id); });
  R('POST', '/api/production/:id/resume', async (p) => ctx.production.resume(p.id));
  R('POST', '/api/production/:id/execute-checks', async (p) => ctx.production.executeChecks(p.id));
  R('POST', '/api/chat', async (_p, _u, b) => {
    let pid = b.project_id;
    if (!pid) { const m = await ctx.workspace.resolveProjectFromText(b.text); if (!m) throw new HttpError(400, 'Projet non identifié : sélectionnez un projet (ou citez son nom dans la demande).', 'project_required'); pid = m.id; }
    const mode = b.mode === 'agent' ? 'agent' : 'team';
    return { run_id: await ctx.orchestrator.start({ projectId: pid, instruction: b.text, mode, agentId: b.agent_id }), project_id: pid };
  });
  R('GET', '/api/runs', async (_p, u) => ctx.orchestrator.listRuns(u.searchParams.get('project_id')));
  R('GET', '/api/runs/:id', async (p) => ctx.orchestrator.getRun(p.id));
  R('POST', '/api/runs/:id/cancel', async (p) => ctx.orchestrator.cancel(p.id));
  R('POST', '/api/runs/:id/resume', async (p) => ctx.orchestrator.resume(p.id));
  R('GET', '/api/journal', async (_p, u) => {
    const pid = u.searchParams.get('project_id'), lim = Math.min(500, Number(u.searchParams.get('limit')) || 100);
    return db.all(`SELECT * FROM journal ${pid ? 'WHERE project_id=?' : ''} ORDER BY ts DESC LIMIT ?`, pid ? [pid, lim] : [lim]);
  });
  // OPS DIRECTOR AI & studio
  R('GET', '/api/studio', async (_p, u) => ctx.director.roster(u.searchParams.get('project_id') || undefined));
  R('PUT', '/api/studio/:id', async (p, _u, b) => ctx.director.configure(p.id, b));
  R('POST', '/api/studio/:id/validate', async (p, _u, b) => ctx.director.validate(p.id, b.validated !== false));
  R('POST', '/api/studio/:id/chat', async (p, _u, b) => {
    const a = await db.get('SELECT * FROM studio_ais WHERE id=?', [p.id]);
    if (!a) throw new HttpError(404, 'IA inconnue');
    if (a.status === 'planned') throw new HttpError(409, `${a.name} n'est pas encore construite : impossible de discuter avec elle`, 'not_built');
    if (p.id === 'world') return ctx.world.chat(b.project_id, b.text);
    if (p.id === 'modeling') return ctx.modeling.chat(b.project_id, b.text);
    if (p.id === 'director') return ctx.director.chat(b.project_id, b.text);
    return ctx.director.agentChat(p.id, b.project_id, b.text, { image_data_url: b.image_data_url });
  });
  // OPS WORLD AI
  R('POST', '/api/world/generate', async (_p, _u, b) => ctx.world.generate({ project_id: b.project_id, params: b.params || {} }));
  R('POST', '/api/world/from-brief', async (_p, _u, b) => ctx.world.fromBrief(b));
  R('GET', '/api/world/worlds', async (_p, u) => ctx.world.list(u.searchParams.get('project_id') || undefined));
  R('GET', '/api/world/worlds/:id', async (p) => ctx.world.get(p.id));
  // OPS MODELING AI
  R('POST', '/api/modeling/generate', async (_p, _u, b) => ctx.modeling.generate({ project_id: b.project_id, params: b.params || {} }));
  R('POST', '/api/modeling/assets/:id/sculpt', async (p, _u, b) => ctx.modeling.sculpt({ asset_id: p.id, operations: b.operations }));
  R('PUT', '/api/modeling/assets/:id/materials/:materialId', async (p, _u, b) => ctx.modeling.updateMaterial({ asset_id: p.id, material_id: p.materialId, patch: b.patch || b }));
  R('POST', '/api/modeling/kit', async (_p, _u, b) => ctx.modeling.kit({ project_id: b.project_id, world_id: b.world_id, max_archetypes: b.max_archetypes === undefined ? 48 : b.max_archetypes, props: b.props !== false }));
  R('POST', '/api/modeling/from-brief', async (_p, _u, b) => ctx.modeling.fromBrief(b));
  R('GET', '/api/modeling/assets', async (_p, u) => ctx.modeling.list(u.searchParams.get('project_id') || undefined));
  R('GET', '/api/modeling/assets/:id', async (p) => ctx.modeling.get(p.id));
  R('GET', '/api/director/templates', async () => Object.entries((await import('./director.mjs')).TEMPLATES).map(([id, t]) => ({ id, label: t.label, tasks: t.tasks.length })));
  R('GET', '/api/director/plans', async (_p, u) => ctx.director.listPlans(u.searchParams.get('project_id') || undefined));
  R('POST', '/api/director/plans', async (_p, _u, b) => ctx.director.createPlan(b));
  R('GET', '/api/director/plans/:id', async (p) => ctx.director.view(p.id));
  R('POST', '/api/director/plans/:id/tasks', async (p, _u, b) => ctx.director.addTask(p.id, b));
  R('PUT', '/api/director/tasks/:id', async (p, _u, b) => ctx.director.updateTask(p.id, b));
  R('POST', '/api/director/tasks/:id/run', async (p) => ctx.director.runTask(p.id));
  R('GET', '/api/director/messages', async (_p, u) => ctx.director.messages({ project_id: u.searchParams.get('project_id') || undefined, to: u.searchParams.get('to') || undefined, from: u.searchParams.get('from') || undefined, status: u.searchParams.get('status') || undefined }));
  R('POST', '/api/director/messages', async (_p, _u, b) => ctx.director.send(b));
  R('POST', '/api/director/messages/:id/read', async (p) => ctx.director.markRead(p.id));
  R('GET', '/api/director/decisions', async (_p, u) => ctx.director.decisions(u.searchParams.get('project_id')));
  R('POST', '/api/director/decisions', async (_p, _u, b) => ctx.director.addDecision(b.project_id, b.title, b.body));
  R('GET', '/api/director/context', async (_p, u) => ctx.director.context(u.searchParams.get('project_id')));
  R('GET', '/api/director/report', async (_p, u) => ctx.director.report(u.searchParams.get('project_id'), { ai: u.searchParams.get('ai') === '1' }));
  R('GET', '/api/engines', async (_p, u) => ctx.engines.list(u.searchParams.get('project_id') || undefined));
  R('POST', '/api/engines', async (_p, _u, b) => ctx.engines.add(b));
  R('POST', '/api/engines/:id/check', async (p) => ctx.engines.check(p.id));
  R('DELETE', '/api/engines/:id', async (p, u) => ctx.engines.remove(p.id, { confirm: u.searchParams.get('confirm') === '1' }));
  R('POST', '/api/projects/:id/exchange/import', async (p, _u, b) => { if (typeof b.content !== 'string') throw new HttpError(400, 'content (base64) requis'); return ctx.exchange.import(p.id, Buffer.from(b.content, 'base64'), { dry_run: !!b.dry_run, overwrite: !!b.overwrite }); });
  // bibliothèque de fichiers
  R('GET', '/api/library', async (_p, u) => ctx.library.list({ project_id: u.searchParams.get('project_id') || undefined, q: u.searchParams.get('q') || undefined, tag: u.searchParams.get('tag') || undefined, scope: u.searchParams.get('scope') || undefined }));
  R('POST', '/api/library', async (_p, _u, b) => {
    if (typeof b.content !== 'string') throw new HttpError(400, 'content (base64) requis');
    return ctx.library.add({ name: b.name, buf: Buffer.from(b.content, 'base64'), tags: b.tags, description: b.description, project_id: b.project_id || null });
  });
  R('POST', '/api/library/from-project', async (_p, _u, b) => ctx.library.saveFromProject(b.project_id, b.path, { tags: b.tags, description: b.description, global: !!b.global }));
  R('PUT', '/api/library/:id', async (p, _u, b) => ctx.library.update(p.id, b));
  R('DELETE', '/api/library/:id', async (p, u) => ctx.library.remove(p.id, { confirm: u.searchParams.get('confirm') === '1' }));
  R('POST', '/api/library/:id/import', async (p, _u, b) => ctx.library.importToProject(p.id, b.project_id, b.path));
  R('GET', '/api/library/:id/preview', async (p, u) => {
    const { row, buf } = await ctx.library.read(p.id, u.searchParams.get('project_id') || undefined);
    const text = ctx.library.pub(row).text;
    return { ...ctx.library.pub(row), content: text ? buf.subarray(0, 200 * 1024).toString('utf8') : null, truncated: text && buf.length > 200 * 1024 };
  });
  // web
  R('POST', '/api/web/search', async (_p, _u, b) => ({ results: await ctx.web.search(b.query) }));
  R('POST', '/api/web/fetch', async (_p, _u, b) => ctx.web.fetchDoc(b.url));

  const json = (res, status, obj) => {
    const body = JSON.stringify(obj);
    res.writeHead(status, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store', 'x-content-type-options': 'nosniff' });
    res.end(body);
  };
  const readBody = (req) => new Promise((resolve, reject) => {
    const chunks = []; let n = 0, oversized = false;
    req.on('data', (c) => { if (oversized) return; n += c.length; if (n > config.maxBodyBytes) { oversized = true; chunks.length = 0; reject(new HttpError(413, 'Requête trop grande')); } else chunks.push(c); });
    req.on('end', () => { if (oversized) return; try { resolve(n ? JSON.parse(Buffer.concat(chunks).toString('utf8')) : {}); } catch { reject(new HttpError(400, 'JSON invalide')); } });
    req.on('error', reject);
  });

  const server = http.createServer(async (req, res) => {
    const url = new URL(req.url, 'http://localhost');
    const ip = req.socket.remoteAddress;
    res.setHeader('x-content-type-options', 'nosniff');
    res.setHeader('referrer-policy', 'no-referrer');
    res.setHeader('x-frame-options', 'DENY');
    res.setHeader('permissions-policy', 'camera=(), microphone=(), geolocation=()');
    try {
      if (config.corsOrigin) {
        res.setHeader('access-control-allow-origin', config.corsOrigin);
        res.setHeader('access-control-allow-headers', 'authorization,content-type');
        res.setHeader('access-control-allow-methods', 'GET,POST,PUT,PATCH,DELETE,OPTIONS');
        if (req.method === 'OPTIONS') { res.writeHead(204); return res.end(); }
      }
      if (url.pathname.startsWith('/api/')) {
        const publicRoute = url.pathname === '/api/health';
        if (!publicRoute) {
          if (limited(ip)) throw new HttpError(429, 'Trop de tentatives, réessayez plus tard');
          if (!authOk(req, url)) { const f = fails.get(ip) || { n: 0, t: now() }; f.n++; f.t = now(); fails.set(ip, f); throw new HttpError(401, 'Jeton OPS invalide ou manquant', 'unauthorized'); }
          fails.delete(ip);
        }
        for (const r of routes) {
          if (r.method !== req.method) continue;
          const m = r.re.exec(url.pathname);
          if (!m) continue;
          const body = ['POST', 'PUT', 'PATCH', 'DELETE'].includes(req.method) ? await readBody(req) : {};
          const out = await r.fn({ ...m.groups }, url, body, req, res);
          return json(res, 200, out);
        }
        const previewMatch = /^\/api\/projects\/([^/]+)\/preview-resource\/(.*)$/.exec(url.pathname);
        if (req.method === 'GET' && previewMatch) {
          const pid = decodeURIComponent(previewMatch[1]); await ctx.workspace.getProject(pid);
          const tail = decodeURIComponent(previewMatch[2] || ''); const rootDir = String(url.searchParams.get('root') || '').replace(/^\/+|\/+$/g,'');
          const rel = [rootDir, tail].filter(Boolean).join('/'); const f = ctx.workspace.readFile(pid, rel, {maxBytes: 5*1024*1024});
          if (f.binary) { const { abs } = ctx.workspace.safePath(pid, rel); const buf = fs.readFileSync(abs); res.writeHead(200, {'content-type': MIME[path.extname(rel)] || 'application/octet-stream','content-security-policy':"sandbox; default-src 'none'; img-src data: blob:",'x-content-type-options':'nosniff','cache-control':'no-store'}); return res.end(buf); }
          const types = {'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.mjs':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json'}; res.writeHead(200, {'content-type':types[path.extname(rel)] || 'text/plain; charset=utf-8','content-security-policy':"sandbox; default-src 'self' data: blob:; connect-src 'none'; object-src 'none'; frame-ancestors 'none'",'x-content-type-options':'nosniff','cache-control':'no-store'}); return res.end(f.content);
        }
        if (req.method === 'GET' && /^\/api\/projects\/[^/]+\/export\.zip$/.test(url.pathname)) {
          const pid = decodeURIComponent(url.pathname.split('/')[3]);
          await ctx.workspace.getProject(pid);
          const buf = ctx.workspace.exportZip(pid);
          res.writeHead(200, { 'content-type': 'application/zip', 'content-disposition': `attachment; filename="${pid}.zip"`, 'content-length': buf.length });
          return res.end(buf);
        }
        const xm = /^\/api\/projects\/([^/]+)\/exchange\.zip$/.exec(url.pathname);
        if (req.method === 'GET' && xm) {
          const pid = decodeURIComponent(xm[1]); await ctx.workspace.getProject(pid);
          const paths = (url.searchParams.get('paths') || '').split(',').map((x) => x.trim()).filter(Boolean);
          const buf = ctx.exchange.export(pid, { paths, kind: url.searchParams.get('kind') || 'assets', note: url.searchParams.get('note') || '' });
          res.writeHead(200, { 'content-type': 'application/zip', 'content-disposition': `attachment; filename="${pid}.ops-exchange.zip"`, 'content-length': buf.length });
          return res.end(buf);
        }
        const wm = /^\/api\/world\/worlds\/([^/]+)\/download$/.exec(url.pathname);
        if (req.method === 'GET' && wm) {
          const f = await ctx.world.file(decodeURIComponent(wm[1]), url.searchParams.get('kind') || 'json');
          res.writeHead(200, { 'content-type': f.mime + '; charset=utf-8', 'content-disposition': `attachment; filename*=UTF-8''${encodeURIComponent(f.name)}`, 'content-length': f.buf.length, 'x-content-type-options': 'nosniff', 'content-security-policy': "sandbox; default-src 'none'" });
          return res.end(f.buf);
        }
        const mm = /^\/api\/modeling\/assets\/([^/]+)\/download$/.exec(url.pathname);
        if (req.method === 'GET' && mm) {
          const f = await ctx.modeling.file(decodeURIComponent(mm[1]), url.searchParams.get('file') || '');
          res.writeHead(200, { 'content-type': f.mime + '; charset=utf-8', 'content-disposition': `attachment; filename*=UTF-8''${encodeURIComponent(f.name)}`, 'content-length': f.buf.length, 'x-content-type-options': 'nosniff', 'content-security-policy': "sandbox; default-src 'none'" });
          return res.end(f.buf);
        }
        const dm = /^\/api\/library\/([^/]+)\/download$/.exec(url.pathname);
        if (req.method === 'GET' && dm) {
          const { row, buf } = await ctx.library.read(decodeURIComponent(dm[1]), url.searchParams.get('project_id') || undefined);
          res.writeHead(200, { 'content-type': 'application/octet-stream', 'content-disposition': `attachment; filename*=UTF-8''${encodeURIComponent(row.name)}`, 'content-length': buf.length, 'x-content-type-options': 'nosniff', 'content-security-policy': "sandbox; default-src 'none'" });
          return res.end(buf);
        }
        throw new HttpError(404, 'Route inconnue');
      }
      // statique
      if (req.method !== 'GET' && req.method !== 'HEAD') throw new HttpError(405, 'Méthode non autorisée');
      let rel = decodeURIComponent(url.pathname);
      if (rel === '/') rel = '/index.html';
      const abs = path.resolve(config.publicDir, '.' + rel);
      if (!abs.startsWith(config.publicDir + path.sep) || !fs.existsSync(abs) || !fs.statSync(abs).isFile()) throw new HttpError(404, 'Introuvable');
      res.writeHead(200, { 'content-type': MIME[path.extname(abs)] || 'application/octet-stream', 'content-security-policy': CSP, 'x-content-type-options': 'nosniff', 'referrer-policy': 'no-referrer', 'cache-control': abs.endsWith('sw.js') ? 'no-cache' : 'public, max-age=300' });
      return res.end(req.method === 'HEAD' ? undefined : fs.readFileSync(abs));
    } catch (e) {
      const status = e instanceof HttpError ? e.status : e instanceof ProviderError ? 502 : 500;
      if (status === 500) console.error('[OPS] erreur interne :', e);
      json(res, status, { error: status === 500 ? 'Erreur interne du serveur' : e.message, code: e.code || 'error' });
    }
  });

  const ws = attachWs(server, { auth: authOk });
  clients.broadcast = ws.broadcast; clients.count = ws.count;
  if (config.automation) ctx.automation.start();

  return {
    ctx, config, server,
    listen: () => new Promise((resolve, reject) => {
      const onError = (error) => { server.off('listening', onListening); reject(error); };
      const onListening = () => { server.off('error', onError); resolve(server.address().port); };
      server.once('error', onError); server.once('listening', onListening);
      server.requestTimeout = 120_000; server.headersTimeout = 30_000; server.keepAliveTimeout = 5_000;
      server.listen(config.port, config.host);
    }),
    async close() { ctx.automation.stop(); ws.close(); await new Promise((r) => server.close(r)); await db.close(); },
  };
}
