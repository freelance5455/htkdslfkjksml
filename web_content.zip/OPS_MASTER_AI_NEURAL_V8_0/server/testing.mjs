import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import vm from 'node:vm';
import { execFile, spawn } from 'node:child_process';
import { promisify } from 'node:util';
import { uid, now, j, HttpError } from './util.mjs';

const execFileP = promisify(execFile);

async function nodeCheck(file) {
  try { await execFileP(process.execPath, ['--check', file], { timeout: 20000 }); return null; }
  catch (e) { return String(e.stderr || e.message).split('\n').filter(Boolean).slice(0, 4).join(' | '); }
}

/** Vérification syntaxique d'un code JS (module ou script) via une copie temporaire .mjs/.cjs ; n'exécute jamais le code. */
async function checkJs(code, asModule, tmpDir) {
  const f = path.join(tmpDir, uid('c_') + (asModule ? '.mjs' : '.cjs'));
  fs.writeFileSync(f, code);
  const r = await nodeCheck(f);
  fs.unlinkSync(f);
  return r;
}

export function createTesting(ctx) {
  const { db, workspace } = ctx;

  /** Centre de tests : syntaxe JS/JSON/HTML (scripts inline), puis non-régression. N'exécute pas le code du projet. */
  async function runChecks(pid) {
    const files = workspace.filesIn(workspace.wdir(pid));
    const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'ops-check-'));
    const results = [];
    try {
      for (const f of files) {
        const ext = path.extname(f.rel).toLowerCase();
        if (!['.js', '.mjs', '.cjs', '.json', '.html', '.htm'].includes(ext)) continue;
        if (fs.statSync(f.abs).size > 5 * 1024 * 1024) { results.push({ path: f.rel, ok: true, note: 'ignoré (> 5 Mo)' }); continue; }
        let err = null;
        const src = fs.readFileSync(f.abs, 'utf8');
        if (ext === '.json') { try { JSON.parse(src); } catch (e) { err = e.message; } }
        else if (ext === '.cjs') err = await nodeCheck(f.abs);
        else if (ext === '.mjs') err = await nodeCheck(f.abs);
        else if (ext === '.js') {
          const isEsm = /^\s*(import|export)\s/m.test(src);
          err = await checkJs(src, isEsm, tmp);
        } else {
          let n = 0;
          for (const m of src.matchAll(/<script\b([^>]*)>([\s\S]*?)<\/script>/gi)) {
            const attrs = m[1];
            if (/\bsrc\s*=/.test(attrs) || !m[2].trim()) continue;
            const type = (attrs.match(/type\s*=\s*["']?([^"'\s>]+)/i) || [])[1] || '';
            if (type && !/^(module|text\/javascript|application\/javascript)$/i.test(type)) continue;
            n++;
            const e = await checkJs(m[2], type === 'module', tmp);
            if (e) { err = `script #${n} : ${e}`; break; }
          }
        }
        results.push({ path: f.rel, ok: !err, error: err || undefined });
      }
    } finally { fs.rmSync(tmp, { recursive: true, force: true }); }
    const bad = results.filter((r) => !r.ok);
    const regression = await workspace.regression(pid);
    const passed = bad.length === 0 && regression.ok;
    const summary = { checked: results.length, failed: bad.length, regression_findings: regression.findings.length, baseline: regression.baseline?.label || null };
    const id = uid('rep_');
    await db.run('INSERT INTO test_reports(id,project_id,ts,kind,passed,summary,detail) VALUES(?,?,?,?,?,?,?)', [id, pid, now(), 'checks', passed ? 1 : 0, j(summary), j({ files: results, regression })]);
    await workspace.log(pid, 'system', 'tests.checks', `${summary.checked} fichiers, ${summary.failed} erreur(s), ${summary.regression_findings} alerte(s) de régression`);
    ctx.events?.emit('tests', { project_id: pid, id, passed });
    return { id, passed, summary, files: results, regression };
  }

  /** Exécute `npm run <script>` (test|build) du projet. Exige l'autorisation explicite du projet ; environnement épuré (aucune clé API). */
  async function runScript(pid, script) {
    const p = await workspace.getProject(pid);
    if (!['test', 'build'].includes(script)) throw new HttpError(400, 'Script autorisé : test ou build');
    if (!p.allow_exec) throw new HttpError(403, "Exécution de code désactivée pour ce projet. Autorisez-la explicitement dans les paramètres du projet.", 'exec_not_allowed');
    const cwd = workspace.wdir(pid);
    let pkg; try { pkg = JSON.parse(fs.readFileSync(path.join(cwd, 'package.json'), 'utf8')); } catch { throw new HttpError(404, 'package.json introuvable dans le projet'); }
    if (!pkg.scripts?.[script]) throw new HttpError(404, `Script « ${script} » absent de package.json`);
    await workspace.createVersion(pid, { label: `Avant npm run ${script}`, reason: 'avant exécution' });
    const env = { PATH: process.env.PATH, HOME: os.tmpdir(), NODE_ENV: script === 'test' ? 'test' : 'production', CI: '1' };
    const t0 = Date.now();
    const out = await new Promise((resolve) => {
      let buf = '', killed = false;
      const c = spawn(process.platform === 'win32' ? 'npm.cmd' : 'npm', ['run', script, '--silent'], { cwd, env, shell: false });
      const timer = setTimeout(() => { killed = true; c.kill('SIGKILL'); }, 120000);
      const add = (d) => { buf += d; if (buf.length > 60000) buf = buf.slice(-60000); };
      c.stdout.on('data', add); c.stderr.on('data', add);
      c.on('error', (e) => { clearTimeout(timer); resolve({ code: -1, output: String(e.message), killed }); });
      c.on('close', (code) => { clearTimeout(timer); resolve({ code, output: buf, killed }); });
    });
    const passed = out.code === 0;
    const id = uid('rep_');
    await db.run('INSERT INTO test_reports(id,project_id,ts,kind,passed,summary,detail) VALUES(?,?,?,?,?,?,?)', [id, pid, now(), `npm:${script}`, passed ? 1 : 0, j({ script, exit_code: out.code, duration_ms: Date.now() - t0, timeout: out.killed }), j({ output: out.output })]);
    await workspace.log(pid, 'system', `run.${script}`, `code ${out.code}${out.killed ? ' (timeout)' : ''}`);
    return { id, passed, exit_code: out.code, timeout: out.killed, output: out.output, duration_ms: Date.now() - t0 };
  }

  return {
    runChecks, runScript,
    async reports(pid, limit = 20) {
      const rows = await db.all('SELECT * FROM test_reports WHERE project_id=? ORDER BY ts DESC LIMIT ?', [pid, limit]);
      return rows.map((r) => ({ ...r, passed: !!r.passed, summary: JSON.parse(r.summary), detail: JSON.parse(r.detail) }));
    },
  };
}
export { vm };
