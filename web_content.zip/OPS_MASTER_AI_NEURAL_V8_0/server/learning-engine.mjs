/** OPS NEURAL LEARNING ENGINE — apprentissage par expériences vérifiables et validation humaine.
 * N'entraîne pas les poids des modèles : capitalise des leçons explicites, traçables et approuvées.
 */
import { uid, now } from './util.mjs';

const MARKERS = /(?:LE[CÇ]ON R[EÉ]UTILISABLE|EXP[EÉ]RIENCE [AÀ] CAPITALISER|RETOUR D['’]EXP[EÉ]RIENCE)\s*:\s*([\s\S]{20,1800}?)(?=\n(?:PREUVE|EVIDENCE|PREUVE DE VALIDATION)\s*:|$)/i;
const DOMAIN = /(?:DOMAINE|DOMAIN)\s*:\s*([^\n]{2,80})/i;
const EVIDENCE = /(?:PREUVE|EVIDENCE|PREUVE DE VALIDATION)\s*:\s*([^\n]{5,500})/i;

export function extractLearningCandidate(result, fallbackDomain = 'OPS général') {
  const source = String(result || '');
  const match = source.match(MARKERS);
  if (!match) return null;
  const lesson = match[1].trim().replace(/\s+/g, ' ');
  if (lesson.length < 20) return null;
  return { domain: (source.match(DOMAIN)?.[1] || fallbackDomain).trim().slice(0,80), lesson: lesson.slice(0,1800), evidence: (source.match(EVIDENCE)?.[1] || 'Leçon proposée dans le rapport de tâche ; validation requise').trim().slice(0,500) };
}

export function createLearningEngine({ db, workspace }) {
  return {
    async captureTask({ projectId, agentId, taskId, result, domain }) {
      const candidate = extractLearningCandidate(result, domain || agentId || 'OPS général');
      if (!candidate) return { captured:false, reason:'Aucune leçon explicitement formulée' };
      const id = uid('learn_');
      await db.run(`INSERT INTO experience_memory(id,project_id,agent_id,domain,lesson,evidence,status,source_task,created,reviewed) VALUES(?,?,?,?,?,?,'pending',?,?,NULL)`, [id,projectId,agentId,candidate.domain,candidate.lesson,candidate.evidence,taskId,now()]);
      await workspace.log(projectId, agentId || 'OPS NEURAL', 'learning.proposed', `${candidate.domain} — ${id}`);
      return { captured:true, id, status:'pending' };
    },
    async stats(projectId) {
      return db.get("SELECT COUNT(*) total, SUM(CASE WHEN status='approved' THEN 1 ELSE 0 END) approved, SUM(CASE WHEN status='pending' THEN 1 ELSE 0 END) pending, SUM(CASE WHEN status='rejected' THEN 1 ELSE 0 END) rejected FROM experience_memory WHERE project_id=? OR project_id IS NULL", [projectId]);
    }
  };
}
