import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import { uid, now, j, HttpError } from './util.mjs';

const MIME = { '.html':'text/html; charset=utf-8', '.htm':'text/html; charset=utf-8', '.js':'text/javascript; charset=utf-8', '.mjs':'text/javascript; charset=utf-8', '.css':'text/css; charset=utf-8', '.json':'application/json', '.png':'image/png', '.jpg':'image/jpeg', '.jpeg':'image/jpeg', '.webp':'image/webp', '.svg':'image/svg+xml', '.wasm':'application/wasm', '.mp3':'audio/mpeg', '.ogg':'audio/ogg', '.mp4':'video/mp4', '.glb':'model/gltf-binary', '.gltf':'model/gltf+json' };
const MAX_ASSET = 40 * 1024 * 1024;

async function loadPlaywright() {
  try { return await import('playwright'); } catch { return null; }
}

/** Tests de jeu par navigateur isolé. Le code du projet n'est servi qu'en local et les requêtes externes sont bloquées. */
export function createGameplayTesting(ctx) {
  const { db, workspace } = ctx;

  async function status() {
    const pw = await loadPlaywright();
    if (!pw) return { available:false, browser:'Playwright absent', instruction:'Installer Playwright et Chromium sur la machine qui héberge OPS pour activer les tests de gameplay.' };
    let browser = false;
    try { const b = await pw.chromium.launch({ headless:true }); await b.close(); browser = true; } catch {}
    return { available:browser, browser:browser ? 'Chromium disponible' : 'Chromium non installé ou impossible à démarrer', instruction:browser ? null : 'Installer Chromium avec Playwright sur le serveur OPS.' };
  }

  async function run(pid, options = {}) {
    const project = await workspace.getProject(pid);
    if (!project.allow_exec) throw new HttpError(403, 'Activez explicitement « Autoriser l’exécution de code » avant de lancer le jeu dans le navigateur.', 'exec_not_allowed');
    const pw = await loadPlaywright();
    if (!pw) throw new HttpError(503, 'Playwright est absent du serveur. Installez Playwright et Chromium pour activer les tests automatisés.', 'playwright_unavailable');
    const root = workspace.wdir(pid);
    const entry = String(options.entry || 'index.html').replace(/^\/+/, '');
    const entryPath = path.resolve(root, entry);
    if (!entryPath.startsWith(path.resolve(root) + path.sep) || !fs.existsSync(entryPath) || !fs.statSync(entryPath).isFile()) throw new HttpError(404, 'Fichier d’entrée introuvable ou chemin invalide.');
    const viewport = options.viewport === 'mobile' ? { width:390, height:844, isMobile:true, hasTouch:true, deviceScaleFactor:1 } : { width:1280, height:720, isMobile:false, hasTouch:false, deviceScaleFactor:1 };
    let server;
    const serverErrors = [];
    server = http.createServer((req,res) => {
      let pathname;
      try { pathname = decodeURIComponent(new URL(req.url, 'http://127.0.0.1').pathname); } catch { res.writeHead(400).end(); return; }
      const rel = pathname === '/' ? entry : pathname.replace(/^\/+/, '');
      const file = path.resolve(root, rel);
      if (!(file === path.resolve(root) || file.startsWith(path.resolve(root) + path.sep))) { res.writeHead(403).end(); return; }
      let st; try { st = fs.statSync(file); } catch { res.writeHead(404).end('Not found'); return; }
      if (!st.isFile() || st.size > MAX_ASSET) { res.writeHead(st.size > MAX_ASSET ? 413 : 404).end(); return; }
      res.writeHead(200, { 'content-type':MIME[path.extname(file).toLowerCase()] || 'application/octet-stream', 'cache-control':'no-store', 'x-content-type-options':'nosniff', 'content-security-policy':"default-src 'self' data: blob:; script-src 'self' 'unsafe-inline' 'unsafe-eval' blob:; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; media-src 'self' blob:; connect-src 'self' ws://127.0.0.1:*; object-src 'none'; frame-ancestors 'none'" });
      fs.createReadStream(file).on('error', () => { if (!res.headersSent) res.writeHead(500); res.end(); }).pipe(res);
    });
    await new Promise((resolve,reject) => { server.once('error',reject); server.listen(0,'127.0.0.1',resolve); });
    const port = server.address().port;
    let browser;
    const consoleErrors = [], pageErrors = [], failedRequests = [], blockedRequests = [];
    const started = Date.now();
    try {
      browser = await pw.chromium.launch({ headless:true });
      const context = await browser.newContext({ viewport:{ width:viewport.width,height:viewport.height }, deviceScaleFactor:viewport.deviceScaleFactor, isMobile:viewport.isMobile, hasTouch:viewport.hasTouch, acceptDownloads:false, permissions:[] });
      const page = await context.newPage();
      page.on('console', msg => { if (msg.type() === 'error') consoleErrors.push(msg.text().slice(0,500)); });
      page.on('pageerror', err => pageErrors.push(String(err.message || err).slice(0,500)));
      page.on('requestfailed', req => failedRequests.push({ url:req.url().slice(0,300), error:req.failure()?.errorText || 'échec réseau' }));
      await page.route('**/*', route => {
        const u = new URL(route.request().url());
        if (u.hostname === '127.0.0.1' && Number(u.port) === port) return route.continue();
        blockedRequests.push(u.origin); return route.abort('blockedbyclient');
      });
      const response = await page.goto(`http://127.0.0.1:${port}/${entry.split('/').map(encodeURIComponent).join('/')}`, { waitUntil:'domcontentloaded', timeout:20000 });
      await page.waitForTimeout(1200);
      const dom = await page.evaluate(() => ({ title:document.title, body_text:(document.body?.innerText || '').slice(0,1200), canvas_count:document.querySelectorAll('canvas').length, visible_buttons:[...document.querySelectorAll('button')].filter(x=>{const r=x.getBoundingClientRect();return r.width>0&&r.height>0}).length, document_width:document.documentElement.scrollWidth, viewport_width:innerWidth, document_height:document.documentElement.scrollHeight, viewport_height:innerHeight, webgl: [...document.querySelectorAll('canvas')].some(c=>!!(c.getContext('webgl2')||c.getContext('webgl'))) }));
      const screenshot = await page.screenshot({ type:'jpeg', quality:65, fullPage:false, timeout:10000 });
      const findings = [];
      if (!response || response.status() >= 400) findings.push({ severity:'error', code:'entry-http-error', message:`La page d’entrée a répondu avec HTTP ${response?.status() ?? 'aucune réponse'}.` });
      if (pageErrors.length) findings.push({ severity:'error', code:'javascript-runtime-error', message:`${pageErrors.length} erreur(s) JavaScript non interceptée(s).`, evidence:pageErrors.slice(0,8) });
      if (consoleErrors.length) findings.push({ severity:'warning', code:'console-errors', message:`${consoleErrors.length} erreur(s) dans la console.`, evidence:consoleErrors.slice(0,8) });
      if (dom.document_width > dom.viewport_width + 2) findings.push({ severity:'warning', code:'horizontal-overflow', message:'Le contenu dépasse horizontalement la largeur de l’écran.' });
      if (dom.canvas_count === 0) findings.push({ severity:'info', code:'canvas-not-present', message:'Aucun canvas détecté dans cette scène.' });
      if (dom.canvas_count > 0 && !dom.webgl) findings.push({ severity:'warning', code:'webgl-not-confirmed', message:'Aucun contexte WebGL actif détecté sur les canvas inspectés.' });
      if (failedRequests.length) findings.push({ severity:'warning', code:'failed-requests', message:`${failedRequests.length} requête(s) locale(s) ont échoué.`, evidence:failedRequests.slice(0,8).map(x=>`${x.url} — ${x.error}`) });
      if (blockedRequests.length) findings.push({ severity:'info', code:'external-requests-blocked', message:`${blockedRequests.length} origine(s) externe(s) bloquée(s) pour isoler le test.`, evidence:[...new Set(blockedRequests)].slice(0,8) });
      const report = { id:uid('gameplay_'), project_id:pid, ts:now(), passed:!pageErrors.length && (!response || response.status()<400), summary:{ viewport:options.viewport==='mobile'?'mobile':'desktop', http_status:response?.status() ?? null, duration_ms:Date.now()-started, console_errors:consoleErrors.length, page_errors:pageErrors.length, failed_requests:failedRequests.length, canvas_count:dom.canvas_count, webgl_detected:dom.webgl, screenshot_captured:true }, findings, dom, screenshot_jpeg_base64:screenshot.toString('base64'), limitations:['Test d’une seule page et d’une seule scène d’entrée.', 'Aucune validation artistique ou de jouabilité humaine.', 'Les interactions destructrices ne sont pas simulées.', 'Les requêtes externes sont bloquées pendant le test.'] };
      await db.run('INSERT INTO test_reports(id,project_id,ts,kind,passed,summary,detail) VALUES(?,?,?,?,?,?,?)',[report.id,pid,report.ts,'gameplay-browser',report.passed?1:0,j(report.summary),j({ findings,dom,console_errors:consoleErrors.slice(0,30),page_errors:pageErrors.slice(0,30),failed_requests:failedRequests.slice(0,30),blocked_origins:[...new Set(blockedRequests)].slice(0,30),screenshot_jpeg_base64:report.screenshot_jpeg_base64,limitations:report.limitations })]);
      await workspace.log(pid,'system','tests.gameplay-browser',`${report.summary.viewport}, HTTP ${report.summary.http_status}, ${pageErrors.length} erreur(s) runtime`);
      ctx.events?.emit('gameplay-tests',{project_id:pid,id:report.id,passed:report.passed});
      return report;
    } catch (error) {
      if (error instanceof HttpError) throw error;
      throw new HttpError(503, `Le test navigateur n’a pas pu être terminé : ${String(error.message||error).slice(0,500)}`, 'browser_test_failed');
    } finally {
      try { await browser?.close(); } catch {}
      await new Promise(resolve => server.close(resolve));
    }
  }

  async function reports(pid, limit=10) {
    await workspace.getProject(pid);
    const rows = await db.all("SELECT * FROM test_reports WHERE project_id=? AND kind='gameplay-browser' ORDER BY ts DESC LIMIT ?",[pid,Math.max(1,Math.min(20,Number(limit)||10))]);
    return rows.map(r=>({ id:r.id,ts:r.ts,passed:!!r.passed,summary:JSON.parse(r.summary),detail:JSON.parse(r.detail) }));
  }
  return { status, run, reports };
}
