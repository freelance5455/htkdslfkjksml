import fs from 'node:fs';
import path from 'node:path';
import { uid, now, j, pj, sha1, slugify, HttpError, normText } from './util.mjs';
import { ALL_AGENT_IDS } from './agents.mjs';
import { zipFromPaths } from './zip.mjs';

const ID_RE = /^[a-z0-9][a-z0-9-]{0,60}$/;
const SKIP_DIRS = new Set(['node_modules', '.git']);
const MAX_FILE = 5 * 1024 * 1024;
const MAX_ENTRIES = 5000;

const isBinary = (buf) => buf.subarray(0, 8000).includes(0);

/** Diff de lignes (LCS) borné ; retourne un diff unifié simplifié. */
export function lineDiff(a, b) {
  const A = a === '' ? [] : a.split('\n'), B = b === '' ? [] : b.split('\n');
  if (A.length * B.length > 4_000_000) {
    const sa = new Set(A), sb = new Set(B);
    return { added: B.filter((x) => !sa.has(x)).length, removed: A.filter((x) => !sb.has(x)).length, lines: null, approx: true };
  }
  const n = A.length, m = B.length;
  const dp = Array.from({ length: n + 1 }, () => new Uint32Array(m + 1));
  for (let i = n - 1; i >= 0; i--) for (let k = m - 1; k >= 0; k--) dp[i][k] = A[i] === B[k] ? dp[i + 1][k + 1] + 1 : Math.max(dp[i + 1][k], dp[i][k + 1]);
  const out = []; let i = 0, k = 0, added = 0, removed = 0;
  while (i < n && k < m) {
    if (A[i] === B[k]) { out.push('  ' + A[i]); i++; k++; }
    else if (dp[i + 1][k] >= dp[i][k + 1]) { out.push('- ' + A[i]); i++; removed++; }
    else { out.push('+ ' + B[k]); k++; added++; }
  }
  while (i < n) { out.push('- ' + A[i++]); removed++; }
  while (k < m) { out.push('+ ' + B[k++]); added++; }
  return { added, removed, lines: out, approx: false };
}

export function createWorkspace(ctx) {
  const { db, config } = ctx;
  const pdir = (pid) => path.join(config.dataDir, 'projects', pid);
  const wdir = (pid) => path.join(pdir(pid), 'workspace');
  const vdir = (pid, vid) => path.join(pdir(pid), 'versions', vid);
  const udir = (pid) => path.join(pdir(pid), 'undo');
  const rdir = (pid) => path.join(pdir(pid), 'reports');

  const pubProject = (r) => r && ({ id: r.id, name: r.name, description: r.description, agents: pj(r.agents, ALL_AGENT_IDS), dependencies: pj(r.dependencies, []), write_mode: r.write_mode, allow_exec: !!r.allow_exec, archived: !!r.archived, created: r.created, updated: r.updated });

  async function getProject(pid) {
    if (!ID_RE.test(String(pid))) throw new HttpError(400, 'Identifiant de projet invalide');
    const r = await db.get('SELECT * FROM projects WHERE id=?', [pid]);
    if (!r) throw new HttpError(404, 'Projet introuvable');
    return pubProject(r);
  }

  /** Résout un chemin relatif DANS le workspace du projet. Refuse .., chemins absolus et échappements par lien symbolique. */
  function safePath(pid, rel) {
    if (typeof rel !== 'string' || rel.includes('\0') || !rel.length) throw new HttpError(400, 'Chemin invalide');
    const r = rel.replace(/\\/g, '/');
    if (r.startsWith('/') || /^[a-zA-Z]:/.test(r)) throw new HttpError(403, 'Chemin absolu refusé');
    const root = wdir(pid);
    fs.mkdirSync(root, { recursive: true });
    const realRoot = fs.realpathSync(root);
    const abs = path.resolve(root, r);
    if (abs !== root && !abs.startsWith(root + path.sep)) throw new HttpError(403, 'Chemin hors du projet refusé');
    let probe = abs;
    while (!fs.existsSync(probe) && probe !== root) probe = path.dirname(probe);
    const real = fs.realpathSync(probe);
    if (real !== realRoot && !real.startsWith(realRoot + path.sep)) throw new HttpError(403, 'Lien symbolique hors du projet refusé');
    return { abs, rel: path.relative(root, abs).split(path.sep).join('/') };
  }

  function walk(pid, sub = '.', out = []) {
    const root = wdir(pid);
    const start = sub === '.' ? root : safePath(pid, sub).abs;
    const rec = (dir) => {
      let ents; try { ents = fs.readdirSync(dir, { withFileTypes: true }); } catch { return; }
      for (const e of ents.sort((a, b) => a.name.localeCompare(b.name))) {
        if (out.length >= MAX_ENTRIES) return;
        if (e.isSymbolicLink()) continue;
        const abs = path.join(dir, e.name), rel = path.relative(root, abs).split(path.sep).join('/');
        if (e.isDirectory()) { if (SKIP_DIRS.has(e.name)) continue; out.push({ path: rel, type: 'dir' }); rec(abs); }
        else if (e.isFile()) out.push({ path: rel, type: 'file', size: fs.statSync(abs).size });
      }
    };
    if (fs.existsSync(start)) rec(start);
    return out;
  }

  function filesIn(dir) {
    const res = [];
    const rec = (d) => {
      let ents; try { ents = fs.readdirSync(d, { withFileTypes: true }); } catch { return; }
      for (const e of ents) {
        if (e.isSymbolicLink()) continue;
        const abs = path.join(d, e.name);
        if (e.isDirectory()) { if (!SKIP_DIRS.has(e.name)) rec(abs); } else if (e.isFile()) res.push({ abs, rel: path.relative(dir, abs).split(path.sep).join('/') });
      }
    };
    if (fs.existsSync(dir)) rec(dir);
    return res;
  }

  const api = {
    pubProject, getProject, safePath, wdir, pdir, rdir, walk, filesIn,

    async log(pid, actor, action, detail) {
      await db.run('INSERT INTO journal(id,ts,project_id,actor,action,detail) VALUES(?,?,?,?,?,?)', [uid('j_'), now(), pid || null, actor || 'system', action, typeof detail === 'string' ? detail : j(detail)]);
      ctx.events?.emit('journal', { project_id: pid, actor, action });
    },

    async listProjects(includeArchived = false) {
      const rows = await db.all(`SELECT * FROM projects ${includeArchived ? '' : 'WHERE archived=0'} ORDER BY created`);
      return rows.map(pubProject);
    },

    async createProject({ name, description = '', id, agents, dependencies, write_mode }) {
      name = String(name || '').trim();
      if (!name) throw new HttpError(400, 'Nom requis');
      id = id ? String(id) : slugify(name);
      if (!ID_RE.test(id)) throw new HttpError(400, 'Identifiant invalide (a-z, 0-9, tirets)');
      if (await db.get('SELECT id FROM projects WHERE id=?', [id])) throw new HttpError(409, 'Ce projet existe déjà');
      if (write_mode && !['approval', 'auto'].includes(write_mode)) throw new HttpError(400, 'write_mode : approval ou auto');
      const ag = Array.isArray(agents) ? agents.filter((a) => ALL_AGENT_IDS.includes(a)) : ALL_AGENT_IDS;
      await db.run('INSERT INTO projects(id,name,description,agents,dependencies,write_mode,allow_exec,archived,created,updated) VALUES(?,?,?,?,?,?,0,0,?,?)',
        [id, name, description, j(ag), j(dependencies || []), write_mode || 'approval', now(), now()]);
      for (const d of ['workspace', 'versions', 'undo', 'reports']) fs.mkdirSync(path.join(pdir(id), d), { recursive: true });
      await api.log(id, 'user', 'project.create', name);
      return getProject(id);
    },

    async updateProject(pid, b) {
      const cur = await getProject(pid);
      if (b.write_mode && !['approval', 'auto'].includes(b.write_mode)) throw new HttpError(400, 'write_mode : approval ou auto');
      const ag = Array.isArray(b.agents) ? b.agents.filter((a) => ALL_AGENT_IDS.includes(a)) : cur.agents;
      await db.run('UPDATE projects SET name=?,description=?,agents=?,dependencies=?,write_mode=?,allow_exec=?,archived=?,updated=? WHERE id=?',
        [b.name ?? cur.name, b.description ?? cur.description, j(ag), j(b.dependencies ?? cur.dependencies), b.write_mode ?? cur.write_mode, b.allow_exec === undefined ? (cur.allow_exec ? 1 : 0) : (b.allow_exec ? 1 : 0), b.archived === undefined ? (cur.archived ? 1 : 0) : (b.archived ? 1 : 0), now(), pid]);
      await api.log(pid, 'user', 'project.update', Object.keys(b).join(','));
      return getProject(pid);
    },

    // ---------- fichiers ----------
    tree(pid) { return walk(pid); },

    readFile(pid, rel, { maxBytes = MAX_FILE } = {}) {
      const { abs, rel: r } = safePath(pid, rel);
      if (!fs.existsSync(abs) || !fs.statSync(abs).isFile()) throw new HttpError(404, 'Fichier introuvable');
      const st = fs.statSync(abs);
      if (st.size > maxBytes) throw new HttpError(413, `Fichier trop gros (${st.size} octets)`);
      const buf = fs.readFileSync(abs);
      if (isBinary(buf)) return { path: r, size: st.size, binary: true };
      return { path: r, size: st.size, binary: false, content: buf.toString('utf8'), hash: sha1(buf) };
    },

    /** Écriture avec sauvegarde préalable, entrée au journal et possibilité d'annulation. */
    async writeFile(pid, rel, content, { actor = 'user', encoding = 'utf8' } = {}) {
      const { abs, rel: r } = safePath(pid, rel);
      const buf = encoding === 'base64' ? Buffer.from(String(content), 'base64') : Buffer.from(String(content ?? ''), 'utf8');
      if (buf.length > MAX_FILE) throw new HttpError(413, 'Fichier > 5 Mo refusé');
      if (fs.existsSync(abs) && fs.statSync(abs).isDirectory()) throw new HttpError(400, 'Ce chemin est un dossier');
      const cid = uid('chg_');
      let before = null;
      if (fs.existsSync(abs)) {
        fs.mkdirSync(udir(pid), { recursive: true });
        before = `${cid}.bak`;
        fs.copyFileSync(abs, path.join(udir(pid), before));
      }
      fs.mkdirSync(path.dirname(abs), { recursive: true });
      fs.writeFileSync(abs, buf);
      await db.run('INSERT INTO changes(id,project_id,path,action,before_file,after_hash,actor,undone,ts) VALUES(?,?,?,?,?,?,?,0,?)', [cid, pid, r, before ? 'modify' : 'create', before, sha1(buf), actor, now()]);
      await api.log(pid, actor, before ? 'file.modify' : 'file.create', r);
      ctx.events?.emit('files', { project_id: pid, path: r });
      return { change_id: cid, path: r, action: before ? 'modify' : 'create', size: buf.length };
    },

    /** Suppression : toujours précédée d'une sauvegarde, jamais exécutée sans confirm=true. */
    async deleteFile(pid, rel, { actor = 'user', confirm = false } = {}) {
      if (!confirm) throw new HttpError(409, 'Suppression : confirmation explicite requise', 'confirm_required');
      const { abs, rel: r } = safePath(pid, rel);
      if (!fs.existsSync(abs) || !fs.statSync(abs).isFile()) throw new HttpError(404, 'Fichier introuvable');
      const cid = uid('chg_');
      fs.mkdirSync(udir(pid), { recursive: true });
      fs.copyFileSync(abs, path.join(udir(pid), `${cid}.bak`));
      const hash = sha1(fs.readFileSync(abs));
      fs.unlinkSync(abs);
      await db.run('INSERT INTO changes(id,project_id,path,action,before_file,after_hash,actor,undone,ts) VALUES(?,?,?,?,?,?,?,0,?)', [cid, pid, r, 'delete', `${cid}.bak`, hash, actor, now()]);
      await api.log(pid, actor, 'file.delete', r);
      ctx.events?.emit('files', { project_id: pid, path: r });
      return { change_id: cid, path: r };
    },

    async changes(pid, limit = 100) {
      return db.all('SELECT id,path,action,actor,undone,ts FROM changes WHERE project_id=? ORDER BY ts DESC LIMIT ?', [pid, limit]);
    },

    async undoChange(pid, cid, { force = false } = {}) {
      const c = await db.get('SELECT * FROM changes WHERE id=? AND project_id=?', [cid, pid]);
      if (!c) throw new HttpError(404, 'Modification introuvable');
      if (c.undone) throw new HttpError(409, 'Déjà annulée');
      const { abs } = safePath(pid, c.path);
      const exists = fs.existsSync(abs);
      if (c.action !== 'delete') {
        const curHash = exists ? sha1(fs.readFileSync(abs)) : null;
        if (!force && curHash !== c.after_hash) throw new HttpError(409, 'Le fichier a changé depuis cette modification ; annulez les plus récentes d\'abord (ou force).', 'stale');
      } else if (exists && !force) throw new HttpError(409, 'Le fichier existe de nouveau', 'stale');
      if (c.before_file) {
        const bak = path.join(udir(pid), c.before_file);
        if (!fs.existsSync(bak)) throw new HttpError(410, 'Sauvegarde introuvable');
        // sauvegarde de l'état courant avant d'annuler (l'annulation est elle-même annulable via les versions)
        fs.mkdirSync(path.dirname(abs), { recursive: true });
        fs.copyFileSync(bak, abs);
      } else if (exists) fs.unlinkSync(abs); // annulation d'une création
      await db.run('UPDATE changes SET undone=1 WHERE id=?', [cid]);
      await api.log(pid, 'user', 'file.undo', `${c.action} ${c.path}`);
      ctx.events?.emit('files', { project_id: pid, path: c.path });
      return { ok: true, path: c.path };
    },

    // ---------- versions ----------
    async createVersion(pid, { label = '', reason = 'manuel' } = {}) {
      await getProject(pid);
      const vid = uid('v_');
      const dest = vdir(pid, vid);
      fs.mkdirSync(dest, { recursive: true });
      let count = 0, bytes = 0;
      for (const f of filesIn(wdir(pid))) {
        const to = path.join(dest, f.rel);
        fs.mkdirSync(path.dirname(to), { recursive: true });
        fs.copyFileSync(f.abs, to);
        count++; bytes += fs.statSync(f.abs).size;
      }
      await db.run('INSERT INTO versions(id,project_id,label,reason,files,bytes,created) VALUES(?,?,?,?,?,?,?)', [vid, pid, label || new Date().toISOString(), reason, count, bytes, now()]);
      await api.log(pid, 'system', 'version.create', `${label} (${reason}) ${count} fichiers`);
      return { id: vid, label, reason, files: count, bytes };
    },

    async listVersions(pid) { return db.all('SELECT * FROM versions WHERE project_id=? ORDER BY created DESC', [pid]); },

    async getVersion(pid, vid) {
      const v = await db.get('SELECT * FROM versions WHERE id=? AND project_id=?', [vid, pid]);
      if (!v) throw new HttpError(404, 'Version introuvable');
      return v;
    },

    /** Compare une version (ou null = dernière) à l'état courant. */
    async diffVersion(pid, vid) {
      const v = await api.getVersion(pid, vid);
      return api.compareDirs(vdir(pid, v.id), wdir(pid));
    },

    compareDirs(oldDir, newDir) {
      const A = new Map(filesIn(oldDir).map((f) => [f.rel, f.abs]));
      const B = new Map(filesIn(newDir).map((f) => [f.rel, f.abs]));
      const added = [], removed = [], modified = [];
      let unchanged = 0;
      for (const [rel, abs] of B) {
        if (!A.has(rel)) { added.push(rel); continue; }
        const x = fs.readFileSync(A.get(rel)), y = fs.readFileSync(abs);
        if (x.equals(y)) unchanged++;
        else modified.push({ path: rel, before_size: x.length, after_size: y.length, binary: isBinary(x) || isBinary(y) });
      }
      for (const rel of A.keys()) if (!B.has(rel)) removed.push(rel);
      return { added, removed, modified, unchanged };
    },

    fileDiff(pid, vid, rel) {
      const cur = fs.existsSync(safePath(pid, rel).abs) ? fs.readFileSync(safePath(pid, rel).abs) : null;
      const oldAbs = path.join(vdir(pid, vid), rel);
      const old = fs.existsSync(oldAbs) ? fs.readFileSync(oldAbs) : null;
      if ((cur && isBinary(cur)) || (old && isBinary(old))) return { binary: true };
      return lineDiff(old ? old.toString('utf8') : '', cur ? cur.toString('utf8') : '');
    },

    /** Restauration : sauvegarde automatique de l'état courant, puis remplacement du workspace par la version. */
    async restoreVersion(pid, vid, { confirm = false } = {}) {
      if (!confirm) throw new HttpError(409, 'Restauration : confirmation explicite requise', 'confirm_required');
      const v = await api.getVersion(pid, vid);
      const safety = await api.createVersion(pid, { label: `Avant restauration de « ${v.label} »`, reason: 'pré-restauration' });
      const w = wdir(pid);
      for (const e of fs.readdirSync(w)) fs.rmSync(path.join(w, e), { recursive: true, force: true });
      fs.cpSync(vdir(pid, vid), w, { recursive: true });
      await api.log(pid, 'user', 'version.restore', `${v.label} (sauvegarde ${safety.id})`);
      ctx.events?.emit('files', { project_id: pid });
      return { ok: true, safety_version: safety.id };
    },

    // ---------- non-régression ----------
    /** Compare une version de référence à l'état courant : fichiers perdus, fichiers fortement réduits, fonctions/classes disparues. */
    async regression(pid, vid) {
      let base = vid ? await api.getVersion(pid, vid) : (await db.get('SELECT * FROM versions WHERE project_id=? ORDER BY created DESC LIMIT 1', [pid]));
      if (!base) return { baseline: null, ok: true, note: 'Aucune version de référence : créez une sauvegarde pour activer la comparaison.', findings: [] };
      const d = api.compareDirs(vdir(pid, base.id), wdir(pid));
      const findings = [];
      for (const r of d.removed) findings.push({ level: 'error', type: 'file_removed', path: r, msg: `Fichier supprimé depuis « ${base.label} »` });
      const symRe = /(?:function\*?\s+|class\s+)([A-Za-z_$][\w$]*)|(?:const|let|var)\s+([A-Za-z_$][\w$]*)\s*=\s*(?:async\s*)?(?:function|\([^)]*\)\s*=>|[A-Za-z_$][\w$]*\s*=>)/g;
      const symbols = (s) => { const out = new Set(); for (const m of s.matchAll(symRe)) out.add(m[1] || m[2]); return out; };
      for (const m of d.modified) {
        if (m.binary) continue;
        if (m.before_size > 200 && m.after_size < m.before_size * 0.6) findings.push({ level: 'warn', type: 'shrunk', path: m.path, msg: `Fichier réduit de ${Math.round((1 - m.after_size / m.before_size) * 100)} % (${m.before_size} → ${m.after_size} octets)` });
        if (/\.(m?js|cjs|ts|html?)$/i.test(m.path)) {
          const oldS = symbols(fs.readFileSync(path.join(vdir(pid, base.id), m.path), 'utf8'));
          const newS = symbols(fs.readFileSync(safePath(pid, m.path).abs, 'utf8'));
          const lost = [...oldS].filter((x) => !newS.has(x));
          if (lost.length) findings.push({ level: 'warn', type: 'symbols_removed', path: m.path, msg: `Fonctions/classes disparues : ${lost.slice(0, 12).join(', ')}${lost.length > 12 ? '…' : ''}` });
        }
      }
      return { baseline: { id: base.id, label: base.label, created: base.created }, ok: !findings.some((f) => f.level === 'error'), clean: findings.length === 0, summary: { added: d.added.length, removed: d.removed.length, modified: d.modified.length, unchanged: d.unchanged }, findings };
    },

    // ---------- export ----------
    exportZip(pid) {
      return zipFromPaths(filesIn(wdir(pid)).map((f) => ({ abs: f.abs, name: f.rel })));
    },

    /** Importe un dossier source dans le workspace d'un projet (copie, jamais de déplacement). */
    async importDir(pid, srcDir, actor = 'system') {
      let n = 0;
      for (const f of filesIn(srcDir)) {
        const to = safePath(pid, f.rel);
        fs.mkdirSync(path.dirname(to.abs), { recursive: true });
        fs.copyFileSync(f.abs, to.abs); n++;
      }
      await api.log(pid, actor, 'project.import', `${n} fichiers`);
      return n;
    },

    async dependencies(pid) {
      const p = await getProject(pid);
      let pkg = null;
      try { pkg = JSON.parse(fs.readFileSync(path.join(wdir(pid), 'package.json'), 'utf8')); } catch { /* pas de package.json */ }
      return { declared: p.dependencies, npm: pkg ? { ...pkg.dependencies, ...pkg.devDependencies } : {} };
    },

    async resolveProjectFromText(text) {
      const t = normText(text);
      const ps = await api.listProjects();
      const hits = ps.filter((p) => t.includes(normText(p.name)) || t.includes(p.id.replace(/-/g, ' ')));
      return hits.length === 1 ? hits[0] : null;
    },
  };
  return api;
}
