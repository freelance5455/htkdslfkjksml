import path from 'node:path';
import { analyzeArtifactGraph } from './artifact-graph.mjs';

const SOURCE = /\.(?:[cm]?[jt]sx?|vue|svelte|py|java|kt|cs|cpp|h|hpp|rs|go|php)$/i;
const ENTRY = /(^|\/)(main|index|app|bootstrap|entry|server|client)\.(?:[cm]?[jt]sx?|vue|svelte|py|java|kt|cs|cpp|rs|go|php)$/i;
const safe = (value) => {
  const p = path.posix.normalize(String(value || '').replace(/\\/g, '/').replace(/^\.\//, ''));
  return p && p !== '.' && !p.startsWith('../') && !p.startsWith('/') ? p : null;
};

function findCycles(nodes, edges) {
  const adjacency = new Map(nodes.map((n) => [n, []]));
  for (const e of edges) if (adjacency.has(e.from) && adjacency.has(e.to)) adjacency.get(e.from).push(e.to);
  const state = new Map(), stack = [], cycles = [], seen = new Set();
  function visit(node) {
    state.set(node, 1); stack.push(node);
    for (const next of adjacency.get(node) || []) {
      if (state.get(next) === 1) {
        const cycle = stack.slice(stack.indexOf(next)).concat(next);
        const key = [...cycle.slice(0, -1)].sort().join('|');
        if (!seen.has(key)) { seen.add(key); cycles.push(cycle); }
      } else if (!state.has(next)) visit(next);
    }
    stack.pop(); state.set(node, 2);
  }
  for (const node of nodes) if (!state.has(node)) visit(node);
  return cycles;
}

/** Audit statique multi-fichiers. N'exécute aucun code et ne modifie aucun fichier. */
export function analyzeProjectArchitecture(files = [], existingPaths = [], changedPaths = []) {
  const byPath = new Map();
  for (const f of files || []) {
    const p = safe(f?.path);
    if (p && typeof f.content === 'string') byPath.set(p, f.content);
  }
  const paths = [...new Set([...(existingPaths || []).map(safe).filter(Boolean), ...byPath.keys()])];
  const graph = analyzeArtifactGraph([...byPath].map(([path, content]) => ({ path, content })), paths);
  const entrypoints = new Set(paths.filter((p) => ENTRY.test(p)));
  const packagePath = paths.find((p) => p === 'package.json');
  if (packagePath && byPath.has(packagePath)) {
    try {
      const pkg = JSON.parse(byPath.get(packagePath));
      for (const key of ['main', 'module', 'browser']) if (typeof pkg[key] === 'string') { const p = safe(pkg[key]); if (p) entrypoints.add(p); }
      for (const value of Object.values(pkg.scripts || {})) {
        if (typeof value !== 'string') continue;
        for (const match of value.matchAll(/(?:node|tsx?|vite|webpack|rollup|parcel)\s+(?:\.\/)?([\w./-]+\.(?:mjs|cjs|js|ts|tsx|jsx))/g)) {
          const p = safe(match[1]); if (p) entrypoints.add(p);
        }
      }
    } catch { /* Le diagnostic JSON spécialisé remontera l'erreur. */ }
  }
  for (const [p, content] of byPath) if (/\.html?$/i.test(p)) {
    for (const m of content.matchAll(/<script\b[^>]*\bsrc\s*=\s*['"]([^'"]+)['"]/gi)) {
      if (/^(?:https?:|data:|\/\/)/i.test(m[1])) continue;
      const target = safe(path.posix.normalize(path.posix.join(path.posix.dirname(p), m[1].split(/[?#]/)[0])));
      if (target) entrypoints.add(target);
    }
  }
  const adjacency = new Map(paths.map((p) => [p, []]));
  const reverse = new Map(paths.map((p) => [p, []]));
  for (const e of graph.edges) { adjacency.get(e.from)?.push(e.to); reverse.get(e.to)?.push(e.from); }
  const reachable = new Set();
  const queue = [...entrypoints].filter((p) => adjacency.has(p));
  while (queue.length) { const p = queue.shift(); if (reachable.has(p)) continue; reachable.add(p); queue.push(...(adjacency.get(p) || [])); }
  const sourcePaths = paths.filter((p) => SOURCE.test(p));
  const orphanModules = entrypoints.size ? sourcePaths.filter((p) => !reachable.has(p) && !entrypoints.has(p)) : [];
  const cycles = findCycles(paths, graph.edges);
  const changed = [...new Set((changedPaths || []).map(safe).filter(Boolean))];
  const impact = changed.map((origin) => {
    const affected = new Set(), pending = [...(reverse.get(origin) || [])];
    while (pending.length) { const p = pending.shift(); if (affected.has(p)) continue; affected.add(p); pending.push(...(reverse.get(p) || [])); }
    return { path: origin, direct_dependents: (reverse.get(origin) || []).length, affected_dependents: [...affected].sort() };
  });
  return {
    schema: 'ops-project-architecture/1',
    summary: { files: paths.length, entrypoints: entrypoints.size, source_modules: sourcePaths.length, orphan_modules: orphanModules.length, dependency_cycles: cycles.length, unresolved_references: graph.diagnostics.length },
    entrypoints: [...entrypoints].filter((p) => paths.includes(p)).sort(),
    orphan_modules: orphanModules.sort(),
    dependency_cycles: cycles,
    unresolved_references: graph.diagnostics,
    impact,
    graph: { nodes: graph.nodes, edges: graph.edges },
  };
}

export function formatArchitectureReport(report) {
  return [
    `CARTE ARCHITECTURALE (${report.summary.files} fichiers)`,
    `Points d'entrée : ${report.entrypoints.join(', ') || 'non déterminés'}`,
    `Modules sources non atteignables : ${report.orphan_modules.join(', ') || 'aucun détecté'}`,
    `Cycles de dépendances : ${report.dependency_cycles.length ? report.dependency_cycles.map((x) => x.join(' → ')).join(' ; ') : 'aucun détecté'}`,
    `Références locales non résolues : ${report.unresolved_references.length}`,
    ...report.impact.map((x) => `Impact ${x.path} : ${x.affected_dependents.join(', ') || 'aucun dépendant détecté'}`),
    'Limite : analyse statique ; les imports dynamiques, alias, plugins et chargements à l’exécution peuvent nécessiter une revue manuelle.',
  ].join('\n');
}
