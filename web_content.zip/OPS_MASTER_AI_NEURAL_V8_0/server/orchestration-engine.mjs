import { uid, now, HttpError } from './util.mjs';

const TERMINAL_RUNS = new Set(['done', 'failed', 'partial', 'cancelled', 'interrupted']);
const TERMINAL_TASKS = new Set(['done', 'error', 'blocked']);
const asJson = (v, fallback = []) => { try { return typeof v === 'string' ? JSON.parse(v) : (v ?? fallback); } catch { return fallback; } };
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

/** Les erreurs de sortie récupérables sont retentées ; les refus et problèmes de configuration restent bloquants. */
export function shouldRetryOrchestrationFailure(error) {
  const message = String(error || '').toLowerCase();
  if (!message) return true;
  const nonRetryable = [
    /proposition.{0,30}(refus|rejet)/, /a été rejetée/, /approbation/, /approval/,
    /clé api/, /api key/, /unauthori[sz]ed/, /forbidden/, /authentification/,
    /fournisseur.{0,30}(absent|introuvable|non configuré)/, /provider.{0,30}(missing|not found|disabled)/,
    /aucun modèle/, /no model/, /quota dépassé/, /budget dépassé/, /insufficient quota/,
  ];
  return !nonRetryable.some((pattern) => pattern.test(message));
}

export function validateOrchestrationTasks(tasks, agents) {
  if (!Array.isArray(tasks) || tasks.length < 1 || tasks.length > 40) throw new Error('Le plan doit contenir entre 1 et 40 tâches.');
  const ids = new Set();
  const agentMap = new Map(agents.map((a) => [a.id, a]));
  const normalized = tasks.map((t, i) => {
    const id = String(t.id || `task_${i + 1}`).trim();
    if (!/^[a-zA-Z0-9_-]{1,64}$/.test(id) || ids.has(id)) throw new Error(`Identifiant de tâche invalide ou dupliqué : ${id}`);
    ids.add(id);
    const title = String(t.title || '').trim(), instruction = String(t.instruction || '').trim();
    if (!title || title.length > 160 || !instruction || instruction.length > 12000) throw new Error(`Titre ou instruction invalide pour ${id}.`);
    const deps = [...new Set((Array.isArray(t.depends_on) ? t.depends_on : []).map(String))];
    return { id, title, instruction, agent_id: t.agent_id ? String(t.agent_id) : null, depends_on: deps };
  });
  for (const t of normalized) {
    for (const d of t.depends_on) if (!ids.has(d) || d === t.id) throw new Error(`Dépendance inconnue ou autoréférence : ${t.id} → ${d}`);
    if (t.agent_id && !agentMap.get(t.agent_id)?.enabled) throw new Error(`Agent indisponible ou désactivé : ${t.agent_id}`);
  }
  const byId = new Map(normalized.map((t) => [t.id, t])), visiting = new Set(), visited = new Set();
  function visit(id) {
    if (visiting.has(id)) throw new Error('Cycle détecté dans les dépendances du plan.');
    if (visited.has(id)) return;
    visiting.add(id);
    for (const d of byId.get(id).depends_on) visit(d);
    visiting.delete(id); visited.add(id);
  }
  for (const t of normalized) visit(t.id);
  return normalized;
}

export function createOrchestrationEngine(ctx) {
  const { db, collaboration } = ctx;
  const pumps = new Map();
  async function ensureSchema() {
    await db.exec(`
      CREATE TABLE IF NOT EXISTS orchestration_plans(
        id TEXT PRIMARY KEY, project_id TEXT NOT NULL, title TEXT NOT NULL, status TEXT NOT NULL, created BIGINT, updated BIGINT
      );
      CREATE INDEX IF NOT EXISTS idx_orch_plans_project ON orchestration_plans(project_id,created);
      CREATE TABLE IF NOT EXISTS orchestration_plan_tasks(
        id TEXT PRIMARY KEY, plan_id TEXT NOT NULL, local_id TEXT NOT NULL, title TEXT NOT NULL, instruction TEXT NOT NULL,
        agent_id TEXT, depends_on TEXT NOT NULL, status TEXT NOT NULL, work_item_id TEXT, error TEXT, created BIGINT, updated BIGINT,
        UNIQUE(plan_id,local_id)
      );
      CREATE INDEX IF NOT EXISTS idx_orch_tasks_plan ON orchestration_plan_tasks(plan_id,status);
      CREATE TABLE IF NOT EXISTS orchestration_execution_logs(
        id TEXT PRIMARY KEY, plan_id TEXT NOT NULL, task_id TEXT, level TEXT NOT NULL, message TEXT NOT NULL, created BIGINT
      );
      CREATE INDEX IF NOT EXISTS idx_orch_logs_plan ON orchestration_execution_logs(plan_id,created);
    `);
    const columns = [
      ['execution_run_id', 'TEXT'], ['approval_task_id', 'TEXT'], ['attempts', 'INTEGER DEFAULT 0'], ['result', 'TEXT'],
      ['started', 'BIGINT'], ['finished', 'BIGINT'], ['approval_count', 'INTEGER DEFAULT 0']
    ];
    for (const [name, type] of columns) {
      try { await db.exec(`ALTER TABLE orchestration_plan_tasks ADD COLUMN ${name} ${type}`); } catch { /* colonne déjà présente */ }
    }
  }
  let schemaReady = false;
  async function schema() { if (!schemaReady) { await ensureSchema(); schemaReady = true; } }
  async function log(planId, taskId, level, message) {
    await db.run('INSERT INTO orchestration_execution_logs(id,plan_id,task_id,level,message,created) VALUES(?,?,?,?,?,?)', [uid('oelog_'), planId, taskId || null, level, String(message).slice(0, 5000), now()]);
    ctx.events?.emit?.('orchestration.log', { plan_id: planId, task_id: taskId || null, level, message: String(message).slice(0, 300) });
  }
  async function planReport(planId) {
    await schema();
    const plan = await db.get('SELECT * FROM orchestration_plans WHERE id=?', [planId]);
    if (!plan) throw new HttpError(404, 'Plan d’orchestration introuvable');
    const tasks = await db.all('SELECT * FROM orchestration_plan_tasks WHERE plan_id=? ORDER BY created,local_id', [planId]);
    const summary = {
      total: tasks.length,
      waiting: tasks.filter((t) => ['waiting_dependencies', 'ready'].includes(t.status)).length,
      executing: tasks.filter((t) => ['starting', 'executing'].includes(t.status)).length,
      review: tasks.filter((t) => t.status === 'review').length,
      done: tasks.filter((t) => t.status === 'done').length,
      error: tasks.filter((t) => t.status === 'error').length,
      blocked: tasks.filter((t) => t.status === 'blocked').length,
    };
    const logs = await db.all('SELECT id,task_id,level,message,created FROM orchestration_execution_logs WHERE plan_id=? ORDER BY created DESC LIMIT 100', [planId]);
    return {
      schema: 'ops.autonomous-execution-plan.v1', plan, summary,
      tasks: tasks.map((t) => ({ ...t, depends_on: asJson(t.depends_on) })),
      logs: logs.reverse(),
    };
  }
  async function chooseAgent(task, agents, loads) {
    if (task.agent_id) return agents.find((a) => a.id === task.agent_id && a.enabled);
    const text = `${task.title} ${task.instruction}`.toLowerCase();
    const rules = [
      [/interface|ui|css|écran|ecran|navigation|bouton/, 'frontend'],
      [/api|serveur|backend|base de données|database/, 'backend'],
      [/3d|three|babylon|rendu|moteur|physique|collision/, 'engine3d'],
      [/pnj|npc|comportement|population/, 'npc'], [/animation|squelette|rig/, 'animation'],
      [/audio|son|voix/, 'audio'], [/mission|gameplay|jouabilité/, 'gameplay'],
      [/bug|erreur|corrig|debug/, 'debug'], [/test|qualité|qualite|audit/, 'quality'],
      [/modèle|modelisation|modélisation|texture|bâtiment|batiment/, 'art3d'],
    ];
    const preferred = rules.find(([re]) => re.test(text))?.[1];
    const candidates = agents.filter((a) => a.enabled && !a.is_studio && a.id !== 'coordinator');
    candidates.sort((a, b) => (((a.id === preferred) ? -100 : 0) + (loads.get(a.id) || 0)) - (((b.id === preferred) ? -100 : 0) + (loads.get(b.id) || 0)));
    return candidates[0] || null;
  }
  async function approvalsState(runId, approvalTaskId = null) {
    const approvals = runId
      ? await db.all('SELECT id,project_id,kind,path,status,note FROM approvals WHERE run_id=? OR (run_id IS NULL AND task_id=?) ORDER BY created', [runId, approvalTaskId || ''])
      : await db.all('SELECT id,project_id,kind,path,status,note FROM approvals WHERE run_id IS NULL AND task_id=? ORDER BY created', [approvalTaskId || '']);
    if (approvals.some((a) => a.status === 'rejected')) return { state: 'rejected', approvals };
    if (approvals.some((a) => a.status === 'pending')) return { state: 'pending', approvals };
    for (const a of approvals.filter((x) => x.status === 'approved')) {
      if (!a.note) return { state: 'invalid', approvals, error: `Approbation sans preuve de changement : ${a.path}` };
      if (a.kind === 'write') {
        try { const f = ctx.workspace.readFile(a.project_id, a.path); if (f.binary) return { state: 'invalid', approvals, error: `Fichier approuvé illisible : ${a.path}` }; }
        catch { return { state: 'invalid', approvals, error: `Fichier approuvé absent du projet : ${a.path}` }; }
      } else if (a.kind === 'delete') {
        try { ctx.workspace.readFile(a.project_id, a.path); return { state: 'invalid', approvals, error: `Suppression non vérifiée : ${a.path}` }; } catch { /* absence confirmée */ }
      }
    }
    return { state: 'approved', approvals };
  }
  async function finishFromRun(plan, task, run) {
    const runTasks = Array.isArray(run.tasks) ? run.tasks : [];
    const failed = runTasks.filter((t) => t.status !== 'done');
    if (run.status !== 'done' || !runTasks.length || failed.length) {
      const detail = run.error || failed.map((t) => `${t.agent_id}: ${t.error || t.status}`).join('; ') || `Exécution terminée avec l’état ${run.status}`;
      await db.run("UPDATE orchestration_plan_tasks SET status='error',error=?,finished=?,updated=? WHERE id=?", [String(detail).slice(0, 1000), now(), now(), task.id]);
      await log(plan.id, task.id, 'error', `Exécution ${run.id} non validée : ${detail}`);
      return;
    }
    const result = String(run.report || runTasks.map((t) => t.result || '').filter(Boolean).join('\n\n')).trim();
    if (!result) {
      await db.run("UPDATE orchestration_plan_tasks SET status='error',error='Aucun résultat exploitable reçu.',finished=?,updated=? WHERE id=?", [now(), now(), task.id]);
      await log(plan.id, task.id, 'error', 'L’agent n’a retourné aucun résultat exploitable.');
      return;
    }
    const a = await approvalsState(run.id, task.approval_task_id || null);
    const status = a.state === 'pending' ? 'review' : a.state === 'approved' ? 'done' : 'error';
    const error = a.state === 'rejected' ? 'Une proposition de fichier a été rejetée.' : a.state === 'invalid' ? a.error : null;
    await db.run('UPDATE orchestration_plan_tasks SET status=?,result=?,error=?,approval_count=?,finished=?,updated=? WHERE id=?', [status, result, error, a.approvals.length, now(), now(), task.id]);
    await log(plan.id, task.id, status === 'done' ? 'success' : status === 'review' ? 'warning' : 'error', status === 'done' ? `Résultat reçu et validé via l’exécution ${run.id}.` : status === 'review' ? `${a.approvals.filter((x) => x.status === 'pending').length} approbation(s) requise(s) avant de débloquer les dépendances.` : error);
  }
  async function reconcile(planId) {
    const plan = await db.get('SELECT * FROM orchestration_plans WHERE id=?', [planId]);
    const rows = await db.all('SELECT * FROM orchestration_plan_tasks WHERE plan_id=?', [planId]);
    for (const task of rows) {
      if (task.status === 'review' && (task.execution_run_id || task.approval_task_id)) {
        const a = await approvalsState(task.execution_run_id || null, task.approval_task_id || null);
        if (a.state === 'approved') {
          await db.run("UPDATE orchestration_plan_tasks SET status='done',error=NULL,finished=?,updated=? WHERE id=?", [now(), now(), task.id]);
          await log(planId, task.id, 'success', 'Toutes les propositions ont été approuvées et les fichiers vérifiés dans le projet.');
        } else if (a.state === 'rejected' || a.state === 'invalid') {
          await db.run("UPDATE orchestration_plan_tasks SET status='error',error=?,updated=? WHERE id=?", [a.error || 'Une proposition de fichier a été rejetée.', now(), task.id]);
          await log(planId, task.id, 'error', a.error || 'Une proposition de fichier a été rejetée.');
        }
      } else if (['starting', 'executing'].includes(task.status) && task.execution_run_id && !ctx.orchestrator?.isActive(task.execution_run_id)) {
        try {
          const run = await ctx.orchestrator.getRun(task.execution_run_id);
          if (TERMINAL_RUNS.has(run.status)) await finishFromRun(plan, task, run);
          else {
            await db.run("UPDATE orchestration_plan_tasks SET status='error',error='Exécution interrompue avant réception du résultat.',finished=?,updated=? WHERE id=?", [now(), now(), task.id]);
            await log(planId, task.id, 'error', `L’exécution ${task.execution_run_id} n’est plus active.`);
          }
        } catch (e) {
          await db.run("UPDATE orchestration_plan_tasks SET status='error',error=?,finished=?,updated=? WHERE id=?", [`Impossible de reprendre l’exécution : ${e.message}`, now(), now(), task.id]);
        }
      } else if (task.status === 'starting' && !task.execution_run_id) {
        await db.run("UPDATE orchestration_plan_tasks SET status='error',error='Démarrage interrompu avant création de l’exécution.',finished=?,updated=? WHERE id=?", [now(), now(), task.id]);
      }
    }
  }
  async function finishFromSpecialist(plan, task, specialist, agentId) {
    let artifact;
    if (agentId === 'world') artifact = await db.get('SELECT valid,files_mode,folder FROM worlds WHERE task_id=? ORDER BY created DESC LIMIT 1', [specialist.task_id]);
    else if (agentId === 'modeling') artifact = await db.get('SELECT valid,files_mode,folder,files FROM assets WHERE task_id=? ORDER BY created DESC LIMIT 1', [specialist.task_id]);
    if (!artifact || !artifact.valid || artifact.files_mode === 'none') {
      const reason = !artifact ? 'Le moteur spécialisé n’a enregistré aucun monde/asset.' : !artifact.valid ? 'Le monde/asset généré a échoué à sa validation.' : 'Le moteur spécialisé n’a livré aucun fichier au projet.';
      await db.run("UPDATE orchestration_plan_tasks SET status='error',result=?,error=?,approval_task_id=?,finished=?,updated=? WHERE id=?", [specialist.result, reason, specialist.task_id, now(), now(), task.id]);
      await log(plan.id, task.id, 'error', reason);
      return;
    }
    const a = await approvalsState(null, specialist.task_id);
    let verificationError = null;
    if (artifact.files_mode === 'written') {
      const names = agentId === 'world' ? ['world.json', 'world.obj', 'preview.svg', 'README.md'] : asJson(artifact.files);
      for (const name of names) {
        try { const f = ctx.workspace.readFile(plan.project_id, `${artifact.folder}/${name}`); if (f.binary && !name.toLowerCase().endsWith('.png')) throw new Error('binaire inattendu'); }
        catch { verificationError = `Fichier spécialisé absent du workspace : ${artifact.folder}/${name}`; break; }
      }
    }
    const status = verificationError || a.state === 'rejected' || a.state === 'invalid' ? 'error' : a.state === 'pending' ? 'review' : 'done';
    const error = verificationError || (a.state === 'rejected' ? 'Une proposition de fichier a été rejetée.' : a.state === 'invalid' ? a.error : null);
    await db.run('UPDATE orchestration_plan_tasks SET status=?,result=?,approval_task_id=?,approval_count=?,error=?,finished=?,updated=? WHERE id=?', [status, specialist.result, specialist.task_id, a.approvals.length, error, now(), now(), task.id]);
    await log(plan.id, task.id, status === 'done' ? 'success' : status === 'review' ? 'warning' : 'error', status === 'done' ? `Résultat du moteur ${agentId.toUpperCase()} reçu et artefacts vérifiés.` : status === 'review' ? `${a.approvals.filter((x) => x.status === 'pending').length} approbation(s) requise(s) pour le moteur spécialisé.` : error);
  }
  async function executeOne(planId, taskId, agent, dependencies) {
    const plan = await db.get('SELECT * FROM orchestration_plans WHERE id=?', [planId]);
    let task = await db.get('SELECT * FROM orchestration_plan_tasks WHERE id=?', [taskId]);
    const maxAttempts = 2;
    for (let attempt = Number(task.attempts || 0) + 1; attempt <= maxAttempts; attempt++) {
      await db.run("UPDATE orchestration_plan_tasks SET status='starting',agent_id=?,attempts=?,execution_run_id=NULL,approval_task_id=NULL,started=COALESCE(started,?),error=NULL,updated=? WHERE id=?", [agent.id, attempt, now(), now(), taskId]);
      await log(planId, taskId, 'info', `Démarrage réel de ${agent.name || agent.id} (tentative ${attempt}/${maxAttempts}).`);
      const dependencyContext = dependencies.length ? '\n\nRÉSULTATS VALIDÉS DES DÉPENDANCES :\n' + dependencies.map((d) => `--- ${d.local_id} · ${d.title} ---\n${d.result || '(aucun texte)'} `).join('\n\n') : '';
      const instruction = `[OPS AUTONOMOUS EXECUTION · PLAN ${plan.title} · TÂCHE ${task.local_id}]\n${task.instruction}${dependencyContext}\n\nRends un résultat concret et vérifiable. Si des fichiers doivent être modifiés, utilise le protocole OPS CODER et le circuit de propositions/approbations existant. Ne déclare jamais une intégration ou un test qui n’a pas réellement eu lieu. Les tâches dépendantes attendront la validation de ce résultat.`;
      let runId;
      try {
        if (agent.is_studio) {
          const specialist = await ctx.director.executeStandaloneTask({ project_id: plan.project_id, agent_id: agent.id, title: task.title, instruction });
          await finishFromSpecialist(plan, { ...task, id: taskId }, specialist, agent.id);
          const completed = await db.get('SELECT status,error FROM orchestration_plan_tasks WHERE id=?', [taskId]);
          if (completed?.status === 'error' && attempt < maxAttempts && shouldRetryOrchestrationFailure(completed.error)) {
            await log(planId, taskId, 'warning', `Résultat spécialisé non validé : ${completed.error}. Nouvelle tentative ${attempt + 1}/${maxAttempts}.`);
            task = await db.get('SELECT * FROM orchestration_plan_tasks WHERE id=?', [taskId]);
            continue;
          }
          return;
        }
        runId = await ctx.orchestrator.start({ projectId: plan.project_id, instruction, mode: 'agent', agentId: agent.id });
        await db.run("UPDATE orchestration_plan_tasks SET execution_run_id=?,status='executing',updated=? WHERE id=?", [runId, now(), taskId]);
        await log(planId, taskId, 'info', `Exécution lancée : ${runId}.`);
        const deadline = Date.now() + 60 * 60 * 1000;
        let run;
        do {
          await sleep(250);
          run = await ctx.orchestrator.getRun(runId);
          if (TERMINAL_RUNS.has(run.status)) break;
          if (Date.now() > deadline) throw new Error('Délai maximal d’attente dépassé (60 minutes).');
        } while (true);
        await finishFromRun(plan, { ...task, id: taskId }, run);
        const completed = await db.get('SELECT status,error FROM orchestration_plan_tasks WHERE id=?', [taskId]);
        if (completed?.status === 'error' && attempt < maxAttempts && shouldRetryOrchestrationFailure(completed.error)) {
          await log(planId, taskId, 'warning', `Exécution non validée : ${completed.error}. Nouvelle tentative ${attempt + 1}/${maxAttempts}.`);
          task = await db.get('SELECT * FROM orchestration_plan_tasks WHERE id=?', [taskId]);
          continue;
        }
        return;
      } catch (e) {
        if (runId && ctx.orchestrator?.isActive(runId)) {
          try { ctx.orchestrator.cancel(runId); } catch { /* le run a pu terminer entre-temps */ }
        }
        task = await db.get('SELECT * FROM orchestration_plan_tasks WHERE id=?', [taskId]);
        if (attempt < maxAttempts) {
          await log(planId, taskId, 'warning', `Tentative ${attempt} échouée : ${e.message}. Nouvelle tentative limitée.`);
          continue;
        }
        await db.run("UPDATE orchestration_plan_tasks SET status='error',error=?,finished=?,updated=? WHERE id=?", [String(e.message).slice(0, 1000), now(), now(), taskId]);
        await log(planId, taskId, 'error', `Échec après ${attempt} tentative(s) : ${e.message}`);
      }
    }
  }
  async function pump(planId) {
    if (pumps.has(planId)) return pumps.get(planId);
    const work = (async () => {
      for (;;) {
        let plan = await db.get('SELECT * FROM orchestration_plans WHERE id=?', [planId]);
        if (!plan) throw new HttpError(404, 'Plan d’orchestration introuvable');
        if (plan.status !== 'running') break;
        await reconcile(planId);
        const rows = await db.all('SELECT * FROM orchestration_plan_tasks WHERE plan_id=? ORDER BY created,local_id', [planId]);
        const byLocal = new Map(rows.map((t) => [t.local_id, t]));
        for (const task of rows) {
          const deps = asJson(task.depends_on).map((id) => byLocal.get(id)).filter(Boolean);
          if (task.status === 'blocked' && String(task.error || '').startsWith('Une dépendance') && deps.length && deps.every((d) => d.status === 'done')) {
            await db.run("UPDATE orchestration_plan_tasks SET status='waiting_dependencies',error=NULL,finished=NULL,updated=? WHERE id=?", [now(), task.id]);
            task.status = 'waiting_dependencies';
          }
          if (!['waiting_dependencies', 'ready'].includes(task.status)) continue;
          if (deps.some((d) => ['error', 'blocked'].includes(d.status))) {
            await db.run("UPDATE orchestration_plan_tasks SET status='blocked',error='Une dépendance a échoué ou est bloquée.',finished=?,updated=? WHERE id=?", [now(), now(), task.id]);
            await log(planId, task.id, 'warning', 'Tâche bloquée : une dépendance n’a pas été validée.');
          } else if (deps.every((d) => d.status === 'done')) {
            if (task.status !== 'ready') await db.run("UPDATE orchestration_plan_tasks SET status='ready',updated=? WHERE id=?", [now(), task.id]);
          }
        }
        plan = await db.get('SELECT * FROM orchestration_plans WHERE id=?', [planId]);
        if (plan.status !== 'running') break;
        const activeRows = await db.all("SELECT id FROM orchestration_plan_tasks WHERE plan_id=? AND status IN ('starting','executing')", [planId]);
        const settings = await db.get("SELECT value FROM settings WHERE key='concurrency'");
        const concurrency = Math.max(1, Math.min(10, Number(settings?.value || 3)));
        const capacity = Math.max(0, concurrency - activeRows.length);
        const ready = await db.all("SELECT * FROM orchestration_plan_tasks WHERE plan_id=? AND status='ready' ORDER BY created,local_id LIMIT ?", [planId, capacity || 1]);
        if (!ready.length || capacity <= 0) {
          if (activeRows.length) { await sleep(150); continue; }
          break;
        }
        const generalAgents = await db.all('SELECT id,name,role,enabled FROM agents ORDER BY sort_order');
        const studioAgents = (await db.all('SELECT id,name,domain AS role,status FROM studio_ais ORDER BY sort_order')).map((a) => ({ ...a, enabled: a.status !== 'planned', is_studio: true }));
        const agents = [...generalAgents, ...studioAgents];
        const loads = new Map();
        for (const a of await db.all("SELECT agent_id AS id,COUNT(*) AS n FROM tasks WHERE status IN ('queued','running','in_progress','accepted') GROUP BY agent_id")) loads.set(a.id, Number(a.n));
        for (const a of await db.all("SELECT agent_id AS id,COUNT(*) AS n FROM orchestration_plan_tasks WHERE status IN ('starting','executing') GROUP BY agent_id")) loads.set(a.id, (loads.get(a.id) || 0) + Number(a.n));
        const launch = [];
        for (const task of ready.slice(0, capacity)) {
          const agent = await chooseAgent(task, agents, loads);
          if (!agent) {
            await db.run("UPDATE orchestration_plan_tasks SET status='error',error='Aucun agent activé compatible avec cette tâche.',finished=?,updated=? WHERE id=?", [now(), now(), task.id]);
            await log(planId, task.id, 'error', 'Aucun agent activé compatible.');
            continue;
          }
          const deps = asJson(task.depends_on).map((id) => byLocal.get(id)).filter(Boolean);
          const claimed = await db.run("UPDATE orchestration_plan_tasks SET status='starting',agent_id=?,updated=? WHERE id=? AND status='ready'", [agent.id, now(), task.id]);
          if (claimed.changes) { loads.set(agent.id, (loads.get(agent.id) || 0) + 1); launch.push({ task, agent, deps }); }
        }
        if (launch.length) await Promise.all(launch.map((x) => executeOne(planId, x.task.id, x.agent, x.deps)));
      }
      const rows = await db.all('SELECT status FROM orchestration_plan_tasks WHERE plan_id=?', [planId]);
      const current = await db.get('SELECT status FROM orchestration_plans WHERE id=?', [planId]);
      if (current?.status === 'running') {
        const status = rows.every((t) => t.status === 'done') ? 'done'
          : rows.some((t) => ['starting', 'executing'].includes(t.status)) ? 'running'
            : rows.some((t) => t.status === 'review') ? 'waiting_approval'
              : rows.some((t) => ['error', 'blocked'].includes(t.status)) || rows.some((t) => ['waiting_dependencies', 'ready'].includes(t.status)) ? 'attention' : 'done';
        await db.run('UPDATE orchestration_plans SET status=?,updated=? WHERE id=?', [status, now(), planId]);
        await log(planId, null, status === 'done' ? 'success' : status === 'waiting_approval' ? 'warning' : status === 'attention' ? 'error' : 'info', `État du plan : ${status}.`);
      }
      return planReport(planId);
    })().finally(() => pumps.delete(planId));
    pumps.set(planId, work);
    return work;
  }
  async function create(projectId, { title, tasks } = {}) {
    await schema();
    const project = await db.get('SELECT id FROM projects WHERE id=?', [projectId]);
    if (!project) throw new HttpError(404, 'Projet introuvable');
    const generalAgents = await db.all('SELECT id,name,role,enabled FROM agents ORDER BY sort_order');
    const studioAgents = (await db.all('SELECT id,name,domain AS role,status FROM studio_ais ORDER BY sort_order')).map((a) => ({ ...a, enabled: a.status !== 'planned', is_studio: true }));
    const agents = [...generalAgents, ...studioAgents];
    let normalized;
    try { normalized = validateOrchestrationTasks(tasks, agents); } catch (e) { throw new HttpError(400, e.message); }
    const planId = uid('orch_'), ts = now(), planTitle = String(title || 'Production multi-IA').trim().slice(0, 160) || 'Production multi-IA';
    await db.run('INSERT INTO orchestration_plans(id,project_id,title,status,created,updated) VALUES(?,?,?,\'draft\',?,?)', [planId, projectId, planTitle, ts, ts]);
    for (const t of normalized) await db.run("INSERT INTO orchestration_plan_tasks(id,plan_id,local_id,title,instruction,agent_id,depends_on,status,created,updated) VALUES(?,?,?,?,?,?,?,'waiting_dependencies',?,?)", [uid('opt_'), planId, t.id, t.title, t.instruction, t.agent_id, JSON.stringify(t.depends_on), ts, ts]);
    await collaboration.publish(projectId, { type: 'orchestration.plan.created', from: 'orchestrator', payload: { plan_id: planId, title: planTitle, task_count: normalized.length } });
    await log(planId, null, 'info', `Plan créé : ${normalized.length} tâche(s). Aucune tâche n’a encore été exécutée.`);
    return planReport(planId);
  }
  async function start(planId) {
    await schema();
    const plan = await db.get('SELECT * FROM orchestration_plans WHERE id=?', [planId]);
    if (!plan) throw new HttpError(404, 'Plan d’orchestration introuvable');
    if (['done', 'completed'].includes(plan.status)) throw new HttpError(409, 'Ce plan est déjà terminé.');
    await db.run("UPDATE orchestration_plans SET status='running',updated=? WHERE id=?", [now(), planId]);
    await log(planId, null, 'info', 'Exécution du plan démarrée/reprise.');
    // Si le pump précédent termine une tâche pendant la reprise, il relira ce statut et continuera.
    if (!pumps.has(planId)) void pump(planId).catch(async (e) => { await db.run("UPDATE orchestration_plans SET status='attention',updated=? WHERE id=?", [now(), planId]); await log(planId, null, 'error', `Moteur d’exécution : ${e.message}`); });
    return planReport(planId);
  }
  async function pause(planId) {
    await schema();
    const plan = await db.get('SELECT * FROM orchestration_plans WHERE id=?', [planId]);
    if (!plan) throw new HttpError(404, 'Plan d’orchestration introuvable');
    await db.run("UPDATE orchestration_plans SET status='paused',updated=? WHERE id=?", [now(), planId]);
    await log(planId, null, 'warning', 'Pause demandée : les exécutions déjà lancées peuvent se terminer, aucune nouvelle tâche ne démarrera.');
    return planReport(planId);
  }
  async function retryTask(planId, localId) {
    await schema();
    const task = await db.get('SELECT * FROM orchestration_plan_tasks WHERE plan_id=? AND local_id=?', [planId, localId]);
    if (!task) throw new HttpError(404, 'Tâche introuvable');
    if (!['error', 'blocked'].includes(task.status)) throw new HttpError(409, 'Seules les tâches en erreur ou bloquées peuvent être relancées.');
    await db.run("UPDATE orchestration_plan_tasks SET status='waiting_dependencies',attempts=0,error=NULL,execution_run_id=NULL,finished=NULL,updated=? WHERE id=?", [now(), task.id]);
    await log(planId, task.id, 'info', 'Relance manuelle demandée ; les dépendances seront revérifiées.');
    return start(planId);
  }
  /** Récupère au démarrage les plans restés actifs après un arrêt du serveur.
   * Les tâches interrompues sont réconciliées avec leurs runs. Seuls les échecs
   * récupérables ayant encore un essai disponible sont remis dans la file.
   * Les revues/approbations restent en attente et ne sont jamais rejouées.
   */
  async function recoverInterrupted() {
    await schema();
    const plans = await db.all("SELECT * FROM orchestration_plans WHERE status='running' ORDER BY created");
    const recovered = [];
    for (const plan of plans) {
      await reconcile(plan.id);
      const errors = await db.all("SELECT id,local_id,error,attempts FROM orchestration_plan_tasks WHERE plan_id=? AND status='error'", [plan.id]);
      let queued = 0;
      for (const task of errors) {
        if (Number(task.attempts || 0) < 2 && shouldRetryOrchestrationFailure(task.error)) {
          await db.run("UPDATE orchestration_plan_tasks SET status='ready',error=NULL,finished=NULL,execution_run_id=NULL,approval_task_id=NULL,updated=? WHERE id=? AND status='error'", [now(), task.id]);
          await log(plan.id, task.id, 'warning', `Reprise après interruption : nouvelle tentative autorisée (${Number(task.attempts || 0) + 1}/2).`);
          queued++;
        } else if (!shouldRetryOrchestrationFailure(task.error)) {
          await log(plan.id, task.id, 'warning', 'Reprise automatique refusée : erreur non récupérable ou validation humaine requise.');
        }
      }
      const remaining = await db.all('SELECT status FROM orchestration_plan_tasks WHERE plan_id=?', [plan.id]);
      const actionable = remaining.some((t) => ['ready', 'waiting_dependencies'].includes(t.status));
      const active = remaining.some((t) => ['starting', 'executing'].includes(t.status));
      if (actionable || active || queued) {
        await db.run("UPDATE orchestration_plans SET status='running',updated=? WHERE id=?", [now(), plan.id]);
        recovered.push({ plan_id: plan.id, queued });
        if (!pumps.has(plan.id)) void pump(plan.id).catch(async (e) => {
          await db.run("UPDATE orchestration_plans SET status='attention',updated=? WHERE id=?", [now(), plan.id]);
          await log(plan.id, null, 'error', `Récupération du plan impossible : ${e.message}`);
        });
      } else {
        const hasReview = remaining.some((t) => t.status === 'review');
        const hasErrors = remaining.some((t) => ['error', 'blocked'].includes(t.status));
        const status = hasReview ? 'waiting_approval' : hasErrors ? 'attention' : remaining.every((t) => t.status === 'done') ? 'done' : 'attention';
        await db.run('UPDATE orchestration_plans SET status=?,updated=? WHERE id=?', [status, now(), plan.id]);
      }
    }
    return { scanned: plans.length, recovered };
  }
  async function advance(planId) { return start(planId); }
  async function list(projectId) { await schema(); return db.all('SELECT * FROM orchestration_plans WHERE project_id=? ORDER BY created DESC LIMIT 50', [projectId]); }
  return { create, start, pause, retryTask, advance, recoverInterrupted, report: planReport, list };
}
