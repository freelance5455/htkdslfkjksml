import { HttpError } from './util.mjs';

/**
 * OPS WORLD AI — générateur procédural de villes/environnements (fonctions pures, déterministes : même graine = même monde).
 *
 * Modèle : grille de n×n cellules de CELL mètres. Les lignes x%4==0 / z%4==0 sont des routes (artères tous les 8),
 * les blocs de 3×3 cellules entre routes accueillent bâtiments, parcs ou monuments (2×2).
 * Codes de `grid` : '.' terrain constructible, '~' mer, 'w' eau douce, 'R' rue, 'A' artère, 'B' pont, 'P' parc.
 */
export const CELL = 24;
export const SIZES = { small: 24, medium: 40, large: 64 };
export const THEMES = {
  modern: { amp: 6, styles: ['verre', 'béton'], ground: '#5d7d57' },
  coastal: { amp: 8, styles: ['crépi', 'bois'], ground: '#7a9a5e' },
  desert: { amp: 10, styles: ['adobe', 'grès'], ground: '#c9a86a' },
  snow: { amp: 14, styles: ['bois', 'ardoise'], ground: '#dfe8ee' },
  rural: { amp: 9, styles: ['brique', 'bois'], ground: '#6f9a4b' },
};
export const WATER_MODES = ['none', 'river', 'coast'];
export const TARGETS = { mobile: { maxBuildings: 350, maxTriangles: 60000 }, pc: { maxBuildings: 1500, maxTriangles: 400000 } };
const SLOPE_MAX = 3.5;

// ---------- aléa déterministe ----------
function hashSeed(str) {
  let h = 1779033703 ^ str.length;
  for (let i = 0; i < str.length; i++) { h = Math.imul(h ^ str.charCodeAt(i), 3432918353); h = (h << 13) | (h >>> 19); }
  h = Math.imul(h ^ (h >>> 16), 2246822507); h = Math.imul(h ^ (h >>> 13), 3266489909);
  return (h ^ (h >>> 16)) >>> 0;
}
function mulberry32(a) { return () => { a |= 0; a = (a + 0x6d2b79f5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
const lat = (seed, x, z) => { let h = Math.imul(x, 374761393) + Math.imul(z, 668265263) + seed; h = Math.imul(h ^ (h >>> 13), 1274126177); return ((h ^ (h >>> 16)) >>> 0) / 4294967296; };
const sm = (t) => t * t * (3 - 2 * t);
function noise(seed, x, z) {
  const x0 = Math.floor(x), z0 = Math.floor(z), fx = sm(x - x0), fz = sm(z - z0);
  const a = lat(seed, x0, z0), b = lat(seed, x0 + 1, z0), c = lat(seed, x0, z0 + 1), d = lat(seed, x0 + 1, z0 + 1);
  return a + (b - a) * fx + (c - a) * fz + (a - b - c + d) * fx * fz;
}
const fbm = (seed, x, z) => (noise(seed, x / 12, z / 12) * 0.6 + noise(seed + 1, x / 6, z / 6) * 0.3 + noise(seed + 2, x / 3, z / 3) * 0.1);
const smoothstep = (a, b, x) => { const t = Math.min(1, Math.max(0, (x - a) / (b - a))); return t * t * (3 - 2 * t); };
const r2 = (v) => Math.round(v * 100) / 100;

export function normalizeParams(p = {}) {
  const bad = (m) => { throw new HttpError(400, m, 'bad_params'); };
  const out = {};
  out.name = String(p.name ?? 'Ville OPS').trim().slice(0, 60) || 'Ville OPS';
  out.seed = String(p.seed ?? Math.random().toString(36).slice(2, 10)).slice(0, 40);
  out.size = p.size ?? 'medium'; if (!(out.size in SIZES)) bad(`size : ${Object.keys(SIZES).join(' | ')}`);
  out.theme = p.theme ?? 'modern'; if (!(out.theme in THEMES)) bad(`theme : ${Object.keys(THEMES).join(' | ')}`);
  out.water = p.water ?? 'river'; if (!WATER_MODES.includes(out.water)) bad(`water : ${WATER_MODES.join(' | ')}`);
  out.target = p.target ?? 'mobile'; if (!(out.target in TARGETS)) bad(`target : ${Object.keys(TARGETS).join(' | ')}`);
  const num = (k, d, lo, hi, int) => { const v = p[k] === undefined || p[k] === '' ? d : Number(p[k]); if (!Number.isFinite(v) || v < lo || v > hi) bad(`${k} : nombre entre ${lo} et ${hi}`); return int ? Math.round(v) : v; };
  out.density = num('density', 0.6, 0.1, 1, false);
  out.districts = num('districts', 5, 3, 8, true);
  out.landmarks = num('landmarks', 3, 0, 7, true);
  return out;
}

const DISTRICT_ORDER = ['downtown', 'commercial', 'residential', 'industrial', 'residential', 'suburb', 'commercial', 'residential'];
const DENSITY_FACTOR = { downtown: 1, commercial: 0.9, residential: 0.8, industrial: 0.7, harbor: 0.6, suburb: 0.5 };
const LANDMARKS = [['tower', 40, 3.4], ['cityhall', 6, 4], ['stadium', 4, 4], ['cathedral', 8, 4], ['museum', 4, 4], ['market', 2, 4], ['station', 3, 4]];

export function generateWorld(rawParams) {
  const P = normalizeParams(rawParams);
  const n = SIZES[P.size], N1 = n + 1, theme = THEMES[P.theme];
  const seedN = hashSeed(P.seed), rng = mulberry32(seedN);

  // --- terrain ---
  const riverPhase = rng() * 6.28, riverX = n * (0.25 + 0.5 * rng()), riverAmp = n * 0.08;
  const H = [];
  for (let z = 0; z <= n; z++) for (let x = 0; x <= n; x++) {
    let h = (fbm(seedN, x, z) - 0.5) * 2 * theme.amp;
    const d = Math.hypot((x - n / 2) / (n / 2), (z - n / 2) / (n / 2));
    const plateau = 1 - smoothstep(0.35, 0.95, d);
    h = h * (1 - 0.85 * plateau) + 1.5 * plateau;
    if (P.water === 'coast') h -= smoothstep(0.72, 1.0, z / n) * 12;
    if (P.water === 'river') {
      const cx = riverX + Math.sin(z * 0.25 + riverPhase) * riverAmp;
      const depth = smoothstep(2.2, 0.6, Math.abs(x - cx)) ;
      h = Math.min(h, h * (1 - depth) - depth * 3);
    }
    H.push(r2(h));
  }
  const hv = (x, z) => H[z * N1 + x];
  const cellH = (x, z) => r2((hv(x, z) + hv(x + 1, z) + hv(x, z + 1) + hv(x + 1, z + 1)) / 4);
  const cellSlope = (x, z) => { const v = [hv(x, z), hv(x + 1, z), hv(x, z + 1), hv(x + 1, z + 1)]; return Math.max(...v) - Math.min(...v); };

  // --- eau ---
  const g = Array.from({ length: n }, () => Array(n).fill('.'));
  const isW = (x, z) => g[z][x] === '~' || g[z][x] === 'w';
  for (let z = 0; z < n; z++) for (let x = 0; x < n; x++) if (cellH(x, z) <= 0) g[z][x] = (P.water === 'coast' && z > n * 0.6) ? '~' : 'w';

  // --- routes (lignes régulières), coupe des franchissements trop longs / marins, ponts, composante principale ---
  const road = new Set(), key = (x, z) => x + ',' + z;
  const lineCell = (x, z) => x % 4 === 0 || z % 4 === 0;
  for (let z = 0; z < n; z++) for (let x = 0; x < n; x++) if (lineCell(x, z)) road.add(key(x, z));
  const cutRuns = (cells) => { // cells : liste ordonnée des cellules d'une ligne
    let run = [];
    const flush = () => { if (run.length && (run.length > 5 || run.some(([x, z]) => g[z][x] === '~'))) run.forEach(([x, z]) => road.delete(key(x, z))); run = []; };
    for (const c of cells) { if (isW(c[0], c[1])) run.push(c); else flush(); }
    flush();
  };
  for (let x = 0; x < n; x += 4) cutRuns(Array.from({ length: n }, (_, z) => [x, z]));
  for (let z = 0; z < n; z += 4) cutRuns(Array.from({ length: n }, (_, x) => [x, z]));
  // composante connexe principale
  const seen = new Set(), comps = [];
  for (const k of road) {
    if (seen.has(k)) continue;
    const comp = [], st = [k]; seen.add(k);
    while (st.length) { const c = st.pop(); comp.push(c); const [x, z] = c.split(',').map(Number); for (const [dx, dz] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) { const kk = key(x + dx, z + dz); if (road.has(kk) && !seen.has(kk)) { seen.add(kk); st.push(kk); } } }
    comps.push(comp);
  }
  comps.sort((a, b) => b.length - a.length);
  const keep = new Set(comps[0] || []);
  const roads = [];
  for (let z = 0; z < n; z++) for (let x = 0; x < n; x++) {
    if (!keep.has(key(x, z))) continue;
    const art = x % 8 === 0 || z % 8 === 0;
    const type = isW(x, z) ? 'B' : art ? 'A' : 'R';
    g[z][x] = type; roads.push({ x, z, type });
  }
  const isRoad = (x, z) => x >= 0 && z >= 0 && x < n && z < n && 'RAB'.includes(g[z][x]);
  const buildable = (x, z) => x >= 0 && z >= 0 && x < n && z < n && g[z][x] === '.' && cellSlope(x, z) <= SLOPE_MAX;
  const nearRoad = (x, z) => isRoad(x + 1, z) || isRoad(x - 1, z) || isRoad(x, z + 1) || isRoad(x, z - 1);

  // --- quartiers (Voronoi) ---
  const seeds = [];
  while (seeds.length < P.districts) {
    const s = [Math.floor(rng() * n), Math.floor(rng() * n)];
    if (seeds.every((o) => Math.hypot(o[0] - s[0], o[1] - s[1]) >= n / 6) || seeds.length > 40) seeds.push(s); else if (rng() < 0.05) seeds.push(s);
  }
  const byCenter = seeds.map((s, i) => ({ i, d: Math.hypot(s[0] - n / 2, s[1] - n / 2) })).sort((a, b) => a.d - b.d);
  const dtype = Array(seeds.length);
  byCenter.forEach((e, rank) => { dtype[e.i] = DISTRICT_ORDER[rank % DISTRICT_ORDER.length]; });
  if (P.water === 'coast') { const cand = byCenter.slice(1).map((e) => e.i).sort((a, b) => seeds[b][1] - seeds[a][1])[0]; if (cand !== undefined) dtype[cand] = 'harbor'; }
  const districtAt = (x, z) => { let best = 0, bd = Infinity; seeds.forEach((s, i) => { const d = Math.hypot(s[0] - x, s[1] - z); if (d < bd) { bd = d; best = i; } }); return best; };
  const districts = seeds.map((s, i) => ({ id: i, type: dtype[i], seed: s }));

  // --- blocs, parcs ---
  const blocks = [], parks = [];
  for (let bz = 0; 4 * bz + 3 < n; bz++) for (let bx = 0; 4 * bx + 3 < n; bx++) {
    const ox = 4 * bx + 1, oz = 4 * bz + 1;
    const di = districtAt(ox + 1, oz + 1), type = dtype[di];
    const park = type !== 'downtown' && type !== 'industrial' && type !== 'harbor' && rng() < 0.12;
    const blk = { x: ox, z: oz, district: di, type, park: false };
    const cells3 = [0, 1, 2].flatMap((dz) => [0, 1, 2].map((dx) => [ox + dx, oz + dz]));
    if (park && cells3.every(([x, z]) => g[z][x] === '.')) { blk.park = true; cells3.forEach(([x, z]) => { g[z][x] = 'P'; }); parks.push({ x: ox, z: oz }); }
    blocks.push(blk);
  }

  // --- bâtiments ---
  const buildings = [], mark = new Set();
  const place = (b) => { buildings.push(b); for (let dz = 0; dz < b.span; dz++) for (let dx = 0; dx < b.span; dx++) mark.add(key(b.cell[0] + dx, b.cell[1] + dz)); };
  const free = (x, z) => buildable(x, z) && !mark.has(key(x, z));
  const centerDist = (x, z) => Math.hypot(x - n / 2, z - n / 2) / (n / 2);
  const rankDist = { downtown: 0, commercial: 1, residential: 2, suburb: 3, industrial: 4, harbor: 5 };
  // monuments 2×2
  const cands = blocks.filter((b) => !b.park && [0, 1].every((dz) => [0, 1].every((dx) => buildable(b.x + dx, b.z + dz))) && [[0, 0], [1, 0], [0, 1], [1, 1]].some(([dx, dz]) => nearRoad(b.x + dx, b.z + dz)))
    .sort((a, b) => rankDist[a.type] - rankDist[b.type] || centerDist(a.x, a.z) - centerDist(b.x, b.z));
  const lm = [];
  for (let i = 0; i < Math.min(P.landmarks, LANDMARKS.length, cands.length); i++) {
    const [kind, floors, fh] = LANDMARKS[i], c = cands[i];
    place({ type: 'landmark', kind, district: c.district, cell: [c.x, c.z], span: 2, footprint: [40, 40], floors, height: r2(floors * fh), style: theme.styles[0], rotation: 0, landmark: true });
    lm.push(kind);
  }
  for (const blk of blocks) {
    if (blk.park) continue;
    for (let dz = 0; dz < 3; dz++) for (let dx = 0; dx < 3; dx++) {
      if (dx === 1 && dz === 1) continue;
      const x = blk.x + dx, z = blk.z + dz;
      const roll = rng(), sizeRoll = rng(), floorRoll = rng(), styleRoll = rng(), rotRoll = rng();
      if (!free(x, z) || !nearRoad(x, z)) continue;
      const di = districtAt(x, z), type = dtype[di];
      if (roll >= Math.min(1, P.density * DENSITY_FACTOR[type])) continue;
      const c = centerDist(x, z);
      let floors, w;
      if (type === 'downtown') { floors = 6 + Math.floor(floorRoll * (1 - c * 0.6) * 24); w = 14 + sizeRoll * 6; }
      else if (type === 'commercial') { floors = 3 + Math.floor(floorRoll * 8); w = 14 + sizeRoll * 6; }
      else if (type === 'residential') { floors = 2 + Math.floor(floorRoll * 5); w = 12 + sizeRoll * 6; }
      else if (type === 'suburb') { floors = 1 + Math.floor(floorRoll * 2.5); w = 11 + sizeRoll * 5; }
      else { floors = 1 + Math.floor(floorRoll * 3); w = 17 + sizeRoll * 5; } // industrial / harbor
      const d2 = type === 'industrial' || type === 'harbor' ? 16 + sizeRoll * 6 : w * (0.8 + sizeRoll * 0.2);
      place({ type, kind: type === 'industrial' ? 'factory' : type === 'harbor' ? 'warehouse' : type === 'suburb' || type === 'residential' ? 'house' : 'office', district: di, cell: [x, z], span: 1, footprint: [r2(w), r2(d2)], floors, height: r2(floors * 3.2), style: theme.styles[Math.floor(styleRoll * theme.styles.length)], rotation: rotRoll < 0.5 ? 0 : 90, landmark: false });
    }
  }
  // budget (les monuments sont conservés, on retire les plus éloignés du centre)
  const bud = TARGETS[P.target]; let trimmed = 0;
  if (buildings.length > bud.maxBuildings) {
    const norm = buildings.filter((b) => !b.landmark).sort((a, b) => centerDist(...b.cell) - centerDist(...a.cell));
    const drop = new Set(norm.slice(0, buildings.length - bud.maxBuildings));
    trimmed = drop.size;
    for (let i = buildings.length - 1; i >= 0; i--) if (drop.has(buildings[i])) buildings.splice(i, 1);
  }
  buildings.forEach((b, i) => {
    b.id = 'b' + String(i + 1).padStart(3, '0');
    const gh = cellH(b.cell[0], b.cell[1]);
    const off = b.span / 2;
    b.position = { x: r2((b.cell[0] + off) * CELL), y: gh, z: r2((b.cell[1] + off) * CELL) };
  });

  const stats = (() => {
    const byType = {}; for (const b of buildings) byType[b.type === 'landmark' ? 'landmark:' + b.kind : b.type] = (byType[b.type === 'landmark' ? 'landmark:' + b.kind : b.type] || 0) + 1;
    const water = g.flat().filter((c) => c === '~' || c === 'w').length;
    const tris = 2 * n * n + buildings.length * 12 + roads.length * 2 + 2;
    return { buildings: buildings.length, by_type: byType, landmarks: lm, parks: parks.length, road_cells: roads.length, road_length_m: roads.length * CELL, bridges: roads.filter((r) => r.type === 'B').length, water_ratio: r2(water / (n * n)), districts: districts.length, trimmed, triangles: tris, triangle_budget: bud.maxTriangles, size_m: n * CELL };
  })();

  const world = {
    format: 'ops-world', version: 1, generator: 'OPS WORLD AI v1', name: P.name, seed: P.seed, params: P,
    size: { cells: n, cell_m: CELL, meters: n * CELL }, terrain: { resolution: N1, heights: H, sea_level: 0, ground_color: theme.ground },
    grid: g.map((r) => r.join('')), districts, blocks: blocks.map((b) => ({ x: b.x, z: b.z, district: b.district, park: b.park })), roads, buildings, stats,
  };
  world.validation = validateWorld(world);
  return world;
}

/** Contrôle qualité indépendant du générateur : lit uniquement le monde produit. */
export function validateWorld(w) {
  const issues = []; const n = w.size.cells, g = w.grid;
  const err = (msg) => issues.push({ level: 'error', msg }), warn = (msg) => issues.push({ level: 'warn', msg });
  const at = (x, z) => (x >= 0 && z >= 0 && x < n && z < n ? g[z][x] : null);
  const used = new Map();
  for (const b of w.buildings) {
    for (let dz = 0; dz < b.span; dz++) for (let dx = 0; dx < b.span; dx++) {
      const x = b.cell[0] + dx, z = b.cell[1] + dz, c = at(x, z);
      if (c === null) err(`${b.id} hors de la carte`);
      else if (c !== '.') err(`${b.id} posé sur une cellule non constructible (${c}) en ${x},${z}`);
      const k = x + ',' + z; if (used.has(k)) err(`${b.id} chevauche ${used.get(k)}`); used.set(k, b.id);
    }
    const adj = [...used.entries()].length >= 0 && Array.from({ length: b.span * b.span }, (_, i) => [b.cell[0] + (i % b.span), b.cell[1] + Math.floor(i / b.span)]).some(([x, z]) => [[1, 0], [-1, 0], [0, 1], [0, -1]].some(([dx, dz]) => 'RAB'.includes(at(x + dx, z + dz) || ' ')));
    if (!adj) err(`${b.id} n'est adjacent à aucune route`);
    if (!(b.height > 0) || !(b.floors >= 1)) err(`${b.id} dimensions invalides`);
  }
  // routes : une seule composante connexe
  const rs = new Set(); for (let z = 0; z < n; z++) for (let x = 0; x < n; x++) if ('RAB'.includes(g[z][x])) rs.add(x + ',' + z);
  if (!rs.size) err('aucune route');
  else { const st = [rs.values().next().value], seen = new Set(st); while (st.length) { const [x, z] = st.pop().split(',').map(Number); for (const [dx, dz] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) { const k = (x + dx) + ',' + (z + dz); if (rs.has(k) && !seen.has(k)) { seen.add(k); st.push(k); } } } if (seen.size !== rs.size) err(`réseau routier non connexe (${seen.size}/${rs.size} cellules reliées)`); }
  // ponts : doivent enjamber de l'eau
  const N1 = w.terrain.resolution, Hh = w.terrain.heights;
  const under = (x, z) => (Hh[z * N1 + x] + Hh[z * N1 + x + 1] + Hh[(z + 1) * N1 + x] + Hh[(z + 1) * N1 + x + 1]) / 4;
  for (const r of w.roads) if (r.type === 'B' && under(r.x, r.z) > 0.01) err(`pont ${r.x},${r.z} sans eau en dessous`);
  const bud = TARGETS[w.params.target];
  if (w.buildings.length > bud.maxBuildings) err(`budget bâtiments dépassé (${w.buildings.length}/${bud.maxBuildings})`);
  if (w.stats.triangles > bud.maxTriangles) warn(`budget de triangles dépassé (${w.stats.triangles}/${bud.maxTriangles})`);
  if (w.stats.water_ratio > 0.6) warn(`monde presque entièrement sous l'eau (${Math.round(w.stats.water_ratio * 100)} %)`);
  if (!w.buildings.length) warn('aucun bâtiment généré (densité trop faible ou terrain inadapté)');
  return { ok: !issues.some((i) => i.level === 'error'), issues };
}

// ---------- exports ----------
export function toObj(w) {
  const n = w.size.cells, N1 = n + 1, C = w.size.cell_m, H = w.terrain.heights, L = ['# OPS WORLD AI — ' + w.name + ' (seed ' + w.seed + ')', 'o terrain'];
  for (let z = 0; z <= n; z++) for (let x = 0; x <= n; x++) L.push(`v ${x * C} ${H[z * N1 + x]} ${z * C}`);
  let vc = N1 * N1;
  for (let z = 0; z < n; z++) for (let x = 0; x < n; x++) { const a = z * N1 + x + 1, b = a + 1, d = a + N1, c = d + 1; L.push(`f ${a} ${d} ${c} ${b}`); }
  const quad = (pts) => { for (const p of pts) L.push(`v ${p[0]} ${p[1]} ${p[2]}`); L.push(`f ${vc + 1} ${vc + 4} ${vc + 3} ${vc + 2}`); vc += 4; };
  L.push('o water'); const m = n * C; quad([[0, 0, 0], [m, 0, 0], [m, 0, m], [0, 0, m]]);
  L.push('o roads');
  const ch = (x, z) => { const v = [H[z * N1 + x], H[z * N1 + x + 1], H[(z + 1) * N1 + x], H[(z + 1) * N1 + x + 1]]; return (v[0] + v[1] + v[2] + v[3]) / 4; };
  for (const r of w.roads) { const y = r.type === 'B' ? 0.6 : r2(ch(r.x, r.z) + 0.08), x0 = r.x * C, z0 = r.z * C; quad([[x0, y, z0], [x0 + C, y, z0], [x0 + C, y, z0 + C], [x0, y, z0 + C]]); }
  for (const b of w.buildings) {
    L.push(`o building_${b.id}_${b.kind}`);
    const [fw, fd] = b.rotation === 90 ? [b.footprint[1], b.footprint[0]] : b.footprint, cx = b.position.x, cz = b.position.z, y0 = b.position.y, y1 = r2(y0 + b.height);
    const x0 = r2(cx - fw / 2), x1 = r2(cx + fw / 2), z0 = r2(cz - fd / 2), z1 = r2(cz + fd / 2);
    for (const [x, y, z] of [[x0, y0, z0], [x1, y0, z0], [x1, y0, z1], [x0, y0, z1], [x0, y1, z0], [x1, y1, z0], [x1, y1, z1], [x0, y1, z1]]) L.push(`v ${x} ${y} ${z}`);
    const f = (...i) => L.push('f ' + i.map((k) => vc + k).join(' '));
    f(1, 4, 3, 2); f(5, 8, 7, 6); f(1, 5, 6, 2); f(4, 3, 7, 8); f(1, 4, 8, 5); f(3, 2, 6, 7);
    vc += 8;
  }
  return L.join('\n') + '\n';
}

const esc = (s) => String(s).replace(/[<>&"']/g, (c) => ({ '<': '&lt;', '>': '&gt;', '&': '&amp;', '"': '&quot;', "'": '&#39;' }[c]));
export function toSvg(w) {
  const n = w.size.cells, S = 10, g = w.grid;
  const col = { '.': w.terrain.ground_color, '~': '#2f6fa8', w: '#4a8fc4', R: '#9a9a9a', A: '#c9c9c9', B: '#a8742f', P: '#3f8f4a' };
  const bcol = { downtown: '#3b4a63', commercial: '#5a4a7a', residential: '#8a6a4a', suburb: '#a08060', industrial: '#6a6a6a', harbor: '#4f6f7f', landmark: '#d9b43a' };
  const o = [`<svg xmlns="http://www.w3.org/2000/svg" width="${n * S}" height="${n * S}" viewBox="0 0 ${n * S} ${n * S}"><title>${esc(w.name)} — seed ${esc(w.seed)}</title>`];
  for (let z = 0; z < n; z++) { let x = 0; while (x < n) { const c = g[z][x]; let e = x + 1; while (e < n && g[z][e] === c) e++; o.push(`<rect x="${x * S}" y="${z * S}" width="${(e - x) * S}" height="${S}" fill="${col[c]}"/>`); x = e; } }
  for (const b of w.buildings) { const p = b.span * S, m = b.landmark ? 0.5 : 1.5; o.push(`<rect x="${b.cell[0] * S + m}" y="${b.cell[1] * S + m}" width="${p - 2 * m}" height="${p - 2 * m}" fill="${bcol[b.type]}"${b.landmark ? ' stroke="#fff" stroke-width="1"' : ''}><title>${esc(b.id)} ${esc(b.kind)} ${b.floors} étages</title></rect>`); }
  o.push('</svg>');
  return o.join('');
}
