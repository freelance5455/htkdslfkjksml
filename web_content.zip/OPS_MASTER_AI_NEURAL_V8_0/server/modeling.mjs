import fs from 'node:fs';
import path from 'node:path';
import { uid, now, j, pj, slugify, trunc, extractJson, sha1, HttpError } from './util.mjs';
import { aaaDetailContract } from './neural.mjs';
import { sculptAsset } from './sculpting.mjs';
import { generateAsset, normalizeAssetParams, planKit, toGltf, toObj, toMtl, toPreviewSvg, validateAsset, ALL_KINDS, BUILDING_KINDS, PROP_KINDS, STYLES, materialLibrary, UV_TILE, toTextureFiles } from './modelgen.mjs';

export const MODELING_PROMPT = `Tu es OPS MODELING AI, l'IA de modélisation 3D d'un studio de jeux vidéo visant la qualité AAA : bâtiments, monuments, props, avec profils géométriques balanced/high/ultra, LOD, collisions et matériaux PBR.
Ton travail réel : choisir les PARAMÈTRES d'un générateur procédural déterministe (le système construit ensuite les meshes, les valide et les exporte en glTF 2.0 / OBJ). Tu ne dessines pas de maillage toi-même et tu n'inventes jamais de résultat.
Portée possible : « asset » (un modèle : kind ${ALL_KINDS.join('|')} ; style ${STYLES.join('|')} ; floors 1–60 ; width/depth 6–80 m) ou « kit » (archétypes instanciables pour TOUS les bâtiments d'un monde généré par OPS WORLD AI, avec placements).
Tu travailles avec les autres IA du studio via le contrat « ops-assets » : WORLD fournit le monde, GRAPHICS lira les matériaux, PHYSICS les collisions, NPC et les autres les emprises et hauteurs. Sois concis, factuel, en français.`;

const ATTR = /(\w+)="([^"]*)"/g;
const SCALE_RANGE = [0.7, 1.4];

export function createModeling(ctx) {
  const { db, config, providers, workspace, events } = ctx;
  const mdir = (pid, id) => path.join(config.dataDir, 'projects', pid, 'models', id);
  const agent = async () => { const a = await db.get("SELECT * FROM studio_ais WHERE id='modeling'"); return { id: 'modeling', provider_id: a?.provider_id, model: a?.model, system_prompt: `${MODELING_PROMPT}\n\n${aaaDetailContract('modeling')}` }; };
  async function chatWithCentral(spec, messages) {
    try { return await providers.chat(spec, messages, { timeoutMs: 45000, retries: 0 }); }
    catch (e) {
      if (e.code !== 'timeout') throw e;
      const d = await db.get("SELECT * FROM studio_ais WHERE id='director'");
      const director = { id: 'director', provider_id: d?.provider_id, model: d?.model, system_prompt: 'Tu es OPS DIRECTOR AI. Aide le spécialiste à débloquer sa tâche avec un plan concret, détaillé et vérifiable.' };
      const help = await providers.chat(director, [
        { role: 'system', content: `${director.system_prompt}\n\n${aaaDetailContract('director')}` },
        { role: 'user', content: `OPS MODELING AI dépasse le délai de réponse. Prépare une aide technique immédiatement exploitable à partir de cette tâche :\n${trunc(messages.map(m => m.content || '').join('\n\n'), 10000)}\n\nFournis les étapes, décisions, contraintes, cas limites, critères d'acceptation et tests. Ne prétends pas avoir généré ou modifié des fichiers.` }
      ], { timeoutMs: 90000, retries: 1 });
      return providers.chat(spec, [...messages,
        { role: 'assistant', content: 'OPS DIRECTOR AI intervient pour accélérer le travail.' },
        { role: 'user', content: `AIDE DU DIRECTOR :\n${trunc(help.text, 10000)}\n\nReprends la tâche en vérifiant cette aide. Complète le niveau de détail et livre le résultat réel de ta spécialité.` }
      ], { timeoutMs: 180000, retries: 2 });
    }
  }

  const pub = (r) => r && ({ id: r.id, project_id: r.project_id, type: r.type, name: r.name, params: pj(r.params, {}), stats: pj(r.stats, {}), valid: !!r.valid, issues: pj(r.issues, []), folder: r.folder, files: pj(r.files, []), files_mode: r.files_mode, world_id: r.world_id, task_id: r.task_id, created: r.created });
  const getRow = async (id) => { const r = await db.get('SELECT * FROM assets WHERE id=?', [id]); if (!r) throw new HttpError(404, 'Asset introuvable'); return r; };

  const assetFiles = (a) => [
    { name: `${a.name}.gltf`, content: toGltf(a) }, { name: `${a.name}_LOD0.obj`, content: toObj(a, 0) }, { name: `${a.name}.mtl`, content: toMtl(a) },
    { name: `${a.name}_preview.svg`, content: toPreviewSvg(a, 0) }, { name: `${a.name}.ops-asset.json`, content: JSON.stringify(manifestEntry(a), null, 2) }, ...toTextureFiles(a, a.textureResolution),
  ];
  const manifestEntry = (a) => ({ name: a.name, kind: a.kind, style: a.style, quality: a.quality, texture_resolution: a.textureResolution || 512, floors: a.floors, footprint: a.footprint, height: a.height, bounds: a.bounds, materials: a.materials.map((m) => m.id), collision: a.collision, lods: a.lods.map((l) => ({ lod: l.lod, triangles: l.tris, vertices: l.verts })), gltf: `${a.name}.gltf`, textures: a.materials.map((m) => ({ material: m.name, baseColor: `${a.name}_${m.id}_BaseColor.png`, normal: `${a.name}_${m.id}_Normal.png`, orm: `${a.name}_${m.id}_ORM.png` })), material_properties: a.materials.map((m) => ({ id: m.id, name: m.name, baseColor: m.baseColor, metallic: m.metallic, roughness: m.roughness, ...(m.emissive ? { emissive: m.emissive } : {}) })) });
  const manifestBase = () => ({ format: 'ops-assets', version: 1, generator: 'OPS MODELING AI v1', units: 'm', up: 'Y', handedness: 'right', winding: 'ccw', uv_tile_m: UV_TILE, lods: 3, collision: 'convex boxes (center, half, rotation_y)', naming: { mesh: 'SM_*', material: 'MI_*' } });
  const save = (pid, id, files) => { const d = mdir(pid, id); fs.mkdirSync(d, { recursive: true }); for (const f of files) fs.writeFileSync(path.join(d, f.name), f.content); };
  const stamp = (name) => slugify(name) || 'asset';
  const applyMaterialOverrides = (asset, overrides = {}) => {
    for (const material of asset.materials) {
      const patch = overrides?.[material.id]; if (!patch || typeof patch !== 'object') continue;
      if (Array.isArray(patch.baseColor)) material.baseColor = [...patch.baseColor];
      if (Number.isFinite(patch.metallic)) material.metallic = patch.metallic;
      if (Number.isFinite(patch.roughness)) material.roughness = patch.roughness;
      if (Array.isArray(patch.emissive)) material.emissive = [...patch.emissive];
    }
    return asset;
  };
  const validateMaterialPatch = (patch) => {
    if (!patch || typeof patch !== 'object' || Array.isArray(patch)) throw new HttpError(400, 'Paramètres matériau invalides');
    const out = {};
    if (patch.baseColor !== undefined) {
      if (!Array.isArray(patch.baseColor) || ![3,4].includes(patch.baseColor.length) || patch.baseColor.some(v => !Number.isFinite(v) || v < 0 || v > 1)) throw new HttpError(400, 'baseColor doit contenir 3 ou 4 valeurs entre 0 et 1');
      out.baseColor = patch.baseColor.length === 3 ? [...patch.baseColor, 1] : [...patch.baseColor];
    }
    for (const key of ['metallic', 'roughness']) if (patch[key] !== undefined) {
      if (!Number.isFinite(patch[key]) || patch[key] < 0 || patch[key] > 1) throw new HttpError(400, `${key} doit être compris entre 0 et 1`);
      out[key] = patch[key];
    }
    if (patch.emissive !== undefined) {
      if (!Array.isArray(patch.emissive) || patch.emissive.length !== 3 || patch.emissive.some(v => !Number.isFinite(v) || v < 0 || v > 1)) throw new HttpError(400, 'emissive doit contenir 3 valeurs entre 0 et 1');
      out.emissive = [...patch.emissive];
    }
    if (!Object.keys(out).length) throw new HttpError(400, 'Aucune propriété de matériau à modifier');
    return out;
  };

  const api = {
    async seed() {
      const a = await db.get("SELECT status FROM studio_ais WHERE id='modeling'");
      if (a && a.status === 'planned') await db.run("UPDATE studio_ais SET status='built', built_at=? WHERE id='modeling'", [now()]);
      await db.run("UPDATE studio_messages SET status='pending' WHERE to_ai='modeling' AND status='queued'");
    },

    /** Génère un asset (3 LOD + collisions + matériaux), le valide, le persiste et propose les fichiers. */
    async generate({ project_id, params, task_id = null }) {
      await workspace.getProject(project_id);
      const a = generateAsset(params || {}), id = uid('ast_'), folder = `models/${stamp(a.name)}-${id.slice(-6)}`;
      const files = assetFiles(a);
      save(project_id, id, files);
      let mode = 'none';
      if (a.validation.ok) mode = await ctx.world.deliver(project_id, folder, files, task_id, 'modeling');
      const stats = { kind: a.kind, style: a.style, quality: a.quality, floors: a.floors, footprint: a.footprint, height: a.height, lods: a.lods.map((l) => ({ lod: l.lod, triangles: l.tris, vertices: l.verts })), materials: a.materials.length, texture_maps: a.materials.length * 3, texture_resolution: `${a.textureResolution}x${a.textureResolution}`, collision_hulls: a.collision.length };
      await db.run('INSERT INTO assets(id,project_id,type,name,params,stats,valid,issues,folder,files,files_mode,world_id,task_id,created) VALUES(?,?,?,?,?,?,?,?,?,?,?,NULL,?,?)', [id, project_id, 'asset', a.name, j(normalizeAssetParams(params || {})), j(stats), a.validation.ok ? 1 : 0, j(a.validation.issues), folder, j(files.map((f) => f.name)), mode, task_id, now()]);
      await workspace.log(project_id, 'modeling', 'model.generate', `${a.name} ${stats.lods.map((l) => l.triangles).join('/')} tris, valide=${a.validation.ok}, fichiers=${mode}`);
      events.emit('modeling', { id, project_id });
      return { asset: pub(await getRow(id)), validation: a.validation };
    },

    /** Kit complet pour un monde ops-world : archétypes instanciables + placements + props, contrat ops-assets. */
    async kit({ project_id, world_id, max_archetypes = 48, props = true, task_id = null }) {
      await workspace.getProject(project_id);
      const max = Number(max_archetypes); if (!Number.isInteger(max) || max < 4 || max > 64) throw new HttpError(400, 'max_archetypes : entier entre 4 et 64');
      const wr = await db.get('SELECT * FROM worlds WHERE id=?', [world_id]);
      if (!wr || wr.project_id !== project_id) throw new HttpError(404, 'Monde introuvable dans ce projet');
      if (!wr.valid) throw new HttpError(409, 'Ce monde est invalide : aucun kit possible');
      const world = JSON.parse((await ctx.world.file(world_id, 'json')).buf.toString());
      const plan = planKit(world, { maxArchetypes: max });
      if (plan.map.size > max) throw new HttpError(409, `Impossible de tenir en ${max} archétypes (${plan.map.size} nécessaires)`);
      const archetypes = new Map(); const issues = [];
      for (const [key, params] of plan.map) { const a = generateAsset({ ...params, texture_resolution: 128 }); archetypes.set(key, a); if (!a.validation.ok) issues.push(...a.validation.issues.filter((i) => i.level === 'error').map((i) => ({ level: 'error', msg: `${a.name} : ${i.msg}` }))); }
      const propAssets = props ? PROP_KINDS.map((kind) => generateAsset({ kind, texture_resolution: 128 })) : [];
      for (const a of propAssets) if (!a.validation.ok) issues.push(...a.validation.issues.filter((i) => i.level === 'error').map((i) => ({ level: 'error', msg: `${a.name} : ${i.msg}` })));
      const placements = []; const seen = new Set();
      for (const { key, b } of plan.placements) {
        const a = archetypes.get(key), [fw, fd] = a.footprint, sc = [r3(b.footprint[0] / fw), r3(b.height / a.height), r3(b.footprint[1] / fd)];
        if (seen.has(b.id)) issues.push({ level: 'error', msg: `placement en double : ${b.id}` }); seen.add(b.id);
        if (sc.some((v) => v < SCALE_RANGE[0] || v > SCALE_RANGE[1])) issues.push({ level: 'error', msg: `${b.id} : échelle hors limites [${sc.join(', ')}] pour ${a.name}` });
        placements.push({ building_id: b.id, asset: a.name, position: b.position, rotation_y_deg: b.rotation, scale: sc });
      }
      for (const b of world.buildings) if (!seen.has(b.id)) issues.push({ level: 'error', msg: `bâtiment sans placement : ${b.id}` });
      const list = [...archetypes.values()], uniq = new Set(list.map((a) => a.name));
      if (uniq.size !== list.length) issues.push({ level: 'error', msg: 'noms d’archétypes en collision' });
      const count = new Map(); for (const p of placements) count.set(p.asset, (count.get(p.asset) || 0) + 1);
      const tri = (lod) => placements.reduce((n, p) => n + list.find((a) => a.name === p.asset).lods[lod].tris, 0);
      const stats = { world: world.name, world_id, buildings: world.buildings.length, archetypes: list.length, props: propAssets.length, merged_variants: plan.level, instanced_triangles: { lod0: tri(0), lod1: tri(1), lod2: tri(2) }, unique_triangles_lod0: list.reduce((n, a) => n + a.lods[0].tris, 0), max_scale_error: Math.max(0, ...placements.flatMap((p) => p.scale.map((v) => Math.abs(1 - v)))) };
      stats.max_scale_error = r3(stats.max_scale_error);
      const valid = !issues.some((i) => i.level === 'error');
      const manifest = { ...manifestBase(), world: { id: world_id, name: world.name, seed: world.seed }, materials: [...new Map(list.concat(propAssets).flatMap((a) => a.materials).map((m) => [m.name, m])).values()], assets: list.concat(propAssets).map((a) => ({ ...manifestEntry(a), instances: count.get(a.name) || 0 })), placements, stats };
      const id = uid('kit_'), folder = `models/kit-${stamp(world.name)}-${id.slice(-6)}`;
      const files = [{ name: 'kit.ops-assets.json', content: JSON.stringify(manifest) }, { name: 'placements.json', content: JSON.stringify(placements) },
        ...list.concat(propAssets).flatMap((a) => [{ name: `${a.name}.gltf`, content: toGltf(a) }, { name: `${a.name}_preview.svg`, content: toPreviewSvg(a, 0) }, ...toTextureFiles(a, a.textureResolution)]),
        { name: 'README.md', content: `# Kit de modèles — ${world.name}\n\nGénéré par OPS MODELING AI à partir du monde \`${world_id}\` (graine \`${world.seed}\`).\n\n- ${stats.buildings} bâtiments → **${stats.archetypes} archétypes** instanciés (${plan.level} fusion(s) de variantes proches), écart d'échelle max ${Math.round(stats.max_scale_error * 100)} %\n- Triangles instanciés : LOD0 ${stats.instanced_triangles.lod0} · LOD1 ${stats.instanced_triangles.lod1} · LOD2 ${stats.instanced_triangles.lod2}\n- Contrat \`ops-assets\` v1 : mètres, Y haut, repère droit, triangles anti-horaires, UV tuilées (${UV_TILE} m), matériaux PBR, 3 LOD, collisions en boîtes.\n- \`placements.json\` : pour chaque \`building_id\` du monde, l'archétype, la position, la rotation Y (degrés) et l'échelle.\n- Les meshes sont procéduraux (volumes, fenêtres, toits, détails), avec maps PBR procédurales 128×128 ; aucun sculpting artistique n'est inclus.\n` }];
      save(project_id, id, files);
      const mode = valid ? await ctx.world.deliver(project_id, folder, files, task_id, 'modeling') : 'none';
      await db.run('INSERT INTO assets(id,project_id,type,name,params,stats,valid,issues,folder,files,files_mode,world_id,task_id,created) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)', [id, project_id, 'kit', `Kit ${world.name}`, j({ world_id, max_archetypes: max, props }), j(stats), valid ? 1 : 0, j(issues), folder, j(files.map((f) => f.name)), mode, world_id, task_id, now()]);
      await workspace.log(project_id, 'modeling', 'model.kit', `${world.name} : ${stats.buildings} bâtiments → ${stats.archetypes} archétypes, valide=${valid}, fichiers=${mode}`);
      events.emit('modeling', { id, project_id });
      return { asset: pub(await getRow(id)), validation: { ok: valid, issues } };
    },

    /** Sculpting non destructif à partir des paramètres d'origine ; remplace les fichiers de cet asset après validation. */
    async sculpt({ asset_id, operations }) {
      const row = await getRow(asset_id);
      if (row.type !== 'asset') throw new HttpError(400, 'La sculpture directe concerne un asset, pas un kit');
      const stored = pj(row.params, {}); const base = applyMaterialOverrides(generateAsset(stored), stored.material_overrides || {});
      const allOperations = [...(stored.sculpt_operations || []), ...(operations || [])];
      const result = sculptAsset(base, allOperations);
      if (!result.validation.ok) throw new HttpError(409, `Sculpture refusée par le contrôle qualité : ${result.validation.issues.filter(x => x.level === 'error').map(x => x.msg).join('; ')}`);
      const files = assetFiles(result.asset); save(row.project_id, asset_id, files);
      const params = { ...stored, sculpt_operations: allOperations };
      const stats = { ...pj(row.stats, {}), sculpt_operations: params.sculpt_operations.length, sculpted_lods: 3, lods: result.asset.lods.map(l => ({ lod:l.lod, triangles:l.tris, vertices:l.verts })) };
      await db.run('UPDATE assets SET params=?,stats=?,valid=1,issues=?,files=? WHERE id=?', [j(params), j(stats), j(result.validation.issues), j(files.map(f=>f.name)), asset_id]);
      await workspace.log(row.project_id, 'modeling', 'model.sculpt', `${row.name}: ${result.operations.length} opération(s), 3 LOD recalculés`);
      events.emit('modeling', { id: asset_id, project_id: row.project_id, sculpted: true });
      return { asset: pub(await getRow(asset_id)), operations: allOperations, validation: result.validation };
    },

    /** Modifie durablement les facteurs PBR du matériau dans les exports glTF/MTL et les métadonnées. */
    async updateMaterial({ asset_id, material_id, patch }) {
      const row = await getRow(asset_id);
      if (row.type !== 'asset') throw new HttpError(400, 'La modification des matériaux concerne un asset, pas un kit');
      const stored = pj(row.params, {}), asset = generateAsset(stored);
      const material = asset.materials.find(m => m.id === material_id);
      if (!material) throw new HttpError(404, 'Matériau introuvable dans cet asset');
      const clean = validateMaterialPatch(patch);
      const overrides = { ...(stored.material_overrides || {}), [material_id]: { ...(stored.material_overrides?.[material_id] || {}), ...clean } };
      const params = { ...stored, material_overrides: overrides };
      let updated = applyMaterialOverrides(generateAsset(params), overrides);
      if (params.sculpt_operations?.length) { const sculpted = sculptAsset(updated, params.sculpt_operations); if (!sculpted.validation.ok) throw new HttpError(409, 'La géométrie sculptée existante ne passe plus la validation'); updated = sculpted.asset; }
      if (!updated.validation.ok) throw new HttpError(409, 'Le contrôle qualité a refusé la mise à jour du matériau');
      const files = assetFiles(updated); save(row.project_id, asset_id, files);
      const stats = { ...pj(row.stats, {}), materials: updated.materials.length, material_edits: Object.keys(overrides).length };
      await db.run('UPDATE assets SET params=?,stats=?,valid=1,issues=?,files=? WHERE id=?', [j(params), j(stats), j(updated.validation.issues), j(files.map(f => f.name)), asset_id]);
      await workspace.log(row.project_id, 'modeling', 'model.material.update', `${row.name}: matériau ${material_id} modifié (${Object.keys(clean).join(', ')})`);
      events.emit('modeling', { id: asset_id, project_id: row.project_id, material_updated: true });
      return { asset: await api.get(asset_id), material: updated.materials.find(m => m.id === material_id), validation: updated.validation };
    },

    async list(pid) { return (await db.all(`SELECT * FROM assets ${pid ? 'WHERE project_id=?' : ''} ORDER BY created DESC LIMIT 200`, pid ? [pid] : [])).map(pub); },
    async get(id) { const row = await getRow(id), base = pub(row); if (row.type === 'asset') { const params = pj(row.params, {}); base.material_catalog = applyMaterialOverrides(generateAsset(params), params.material_overrides || {}).materials; } return base; },
    async file(id, name) {
      const r = await getRow(id), files = pj(r.files, []);
      if (!files.includes(name)) throw new HttpError(404, 'Fichier inconnu pour cet asset');
      const p = path.join(mdir(r.project_id, id), name);
      if (!fs.existsSync(p)) throw new HttpError(404, 'Fichier introuvable');
      const ext = path.extname(name), mime = { '.gltf': 'model/gltf+json', '.json': 'application/json', '.svg': 'image/svg+xml', '.obj': 'text/plain', '.mtl': 'text/plain', '.md': 'text/markdown', '.png': 'image/png' }[ext] || 'application/octet-stream';
      return { buf: fs.readFileSync(p), name, mime };
    },

    /** Brief → décision JSON {scope, asset?, world_id?, max_archetypes?} (fournisseur réel requis ; sortie invalide → 502, rien créé). */
    async planFromBrief(brief, extra = '', worlds = []) {
      const r = await chatWithCentral(await agent(), [{ role: 'system', content: `${MODELING_PROMPT}\n\n${aaaDetailContract('modeling')}` }, { role: 'user', content: `PARAMÈTRES JSON pour ce brief de modélisation :\n${trunc(brief, 6000)}\n${extra ? '\nCONTEXTE :\n' + trunc(extra, 6000) + '\n' : ''}\nMondes disponibles dans le projet : ${JSON.stringify(worlds.map((w) => ({ id: w.id, name: w.name, buildings: w.stats.buildings })))}\nRéponds UNIQUEMENT par un objet JSON : {"scope":"asset"|"kit","world_id":"(kit)","max_archetypes":48,"asset":{"kind":"","style":"","floors":0,"width":0,"depth":0,"name":""}}` }]);
      let o; try { o = extractJson(r.text); } catch { o = null; }
      if (!o || typeof o !== 'object' || Array.isArray(o) || !['asset', 'kit'].includes(o.scope)) throw new HttpError(502, 'MODELING AI n’a pas renvoyé de plan JSON exploitable', 'bad_ai_output');
      try {
        if (o.scope === 'asset') { const a = o.asset || {}; return { scope: 'asset', params: normalizeAssetParams(Object.fromEntries(Object.entries(a).filter(([k]) => ['kind', 'style', 'floors', 'width', 'depth', 'height', 'name'].includes(k)))) }; }
        const max = o.max_archetypes === undefined ? 48 : Number(o.max_archetypes); if (!Number.isInteger(max) || max < 4 || max > 64) throw new Error('max_archetypes invalide');
        return { scope: 'kit', world_id: typeof o.world_id === 'string' ? o.world_id : null, max_archetypes: max };
      } catch (e) { throw new HttpError(502, `Plan refusé (MODELING AI) : ${e.message}`, 'bad_ai_output'); }
    },
    async fromBrief({ project_id, brief }) {
      if (!String(brief || '').trim()) throw new HttpError(400, 'Brief vide');
      const worlds = (await db.all('SELECT * FROM worlds WHERE project_id=? AND valid=1 ORDER BY created DESC', [project_id])).map((r) => ({ id: r.id, name: r.name, stats: pj(r.stats, {}) }));
      const plan = await api.planFromBrief(brief, '', worlds);
      if (plan.scope === 'asset') return { plan, ...(await api.generate({ project_id, params: plan.params })) };
      const wid = plan.world_id && worlds.some((w) => w.id === plan.world_id) ? plan.world_id : worlds[0]?.id;
      if (!wid) throw new HttpError(409, 'Aucun monde valide dans ce projet : générez-en un avec OPS WORLD AI d’abord');
      return { plan, ...(await api.kit({ project_id, world_id: wid, max_archetypes: plan.max_archetypes })) };
    },

    /** Exécution d'une tâche du plan (appelée par le Director). Retourne le livrable markdown. */
    async executeTask({ task, plan, deps, decisions }) {
      const inbox = await db.all("SELECT * FROM studio_messages WHERE to_ai='modeling' AND project_id=? AND status='pending' ORDER BY created", [task.project_id]);
      const worlds = (await db.all('SELECT * FROM worlds WHERE project_id=? AND valid=1 ORDER BY created DESC', [task.project_id])).map((r) => ({ id: r.id, name: r.name, stats: pj(r.stats, {}) }));
      const extra = [
        `Plan : ${plan.title}\nBrief du plan : ${plan.brief || '(aucun)'}\nTâche : ${task.title}\n${task.description || ''}`,
        deps.length ? 'Résultats précédents :\n' + deps.map((d) => `--- ${d.title} ---\n${trunc(d.result, 2500)}`).join('\n') : '',
        inbox.length ? 'Messages reçus :\n' + inbox.map((m) => `[${m.from_ai}/${m.kind}] ${trunc(m.body, 1500)}`).join('\n') : '',
        decisions.length ? 'Décisions du projet :\n' + decisions.map((d) => `- ${d.key.replace('décision : ', '')} : ${trunc(d.value, 300)}`).join('\n') : '',
      ].filter(Boolean).join('\n\n');
      const pl = await api.planFromBrief(`${plan.brief || plan.title}\n${task.title}\n${task.description || ''}`, extra, worlds);
      let out;
      if (pl.scope === 'asset') out = await api.generate({ project_id: task.project_id, params: pl.params, task_id: task.id });
      else {
        const depText = deps.map((d) => d.result || '').join('\n'), fromDeps = worlds.find((w) => depText.includes(w.id));
        const wid = (pl.world_id && worlds.some((w) => w.id === pl.world_id) ? pl.world_id : null) || fromDeps?.id || worlds[0]?.id;
        if (!wid) throw new HttpError(409, 'Aucun monde valide dans ce projet : exécutez d’abord la tâche OPS WORLD AI', 'no_world');
        out = await api.kit({ project_id: task.project_id, world_id: wid, max_archetypes: pl.max_archetypes, task_id: task.id });
      }
      if (inbox.length) await db.run(`UPDATE studio_messages SET status='read' WHERE id IN (${inbox.map(() => '?').join(',')})`, inbox.map((m) => m.id));
      const w = out.asset, s = w.stats, bad = out.validation.issues.filter((i) => i.level === 'error'), where = w.files_mode === 'written' ? 'écrits dans le workspace' : w.files_mode === 'proposed' ? 'proposés (à approuver dans « Approbations »)' : 'non livrés (invalide)';
      const body = w.type === 'kit'
        ? `## Kit de modèles « ${w.name} » généré par OPS MODELING AI\n\n- Monde source : \`${s.world_id}\` (${s.world}) — ${s.buildings} bâtiments → ${s.archetypes} archétypes + ${s.props} props\n- Triangles instanciés : LOD0 ${s.instanced_triangles.lod0} · LOD1 ${s.instanced_triangles.lod1} · LOD2 ${s.instanced_triangles.lod2} (écart d'échelle max ${Math.round(s.max_scale_error * 100)} %)`
        : `## Modèle « ${w.name} » généré par OPS MODELING AI\n\n- ${s.kind} · style ${s.style} · ${s.floors} étage(s) · ${s.height} m · LOD ${s.lods.map((l) => l.triangles).join('/')} triangles · ${s.collision_hulls} collision(s)`;
      return `${body}\n- Validation : ${out.validation.ok ? 'OK' : 'ÉCHEC — ' + bad.map((i) => i.msg).slice(0, 3).join(' ; ')}\n- Fichiers : \`${w.folder}/\` — ${where}\n- ID : \`${w.id}\` · contrat \`ops-assets\` v1 (matériaux PBR → GRAPHICS, collisions → PHYSICS, emprises/hauteurs → NPC, placements → WORLD)\n\nÀ suivre : pas de textures ni de modèles sculptés ; animation, personnages et véhicules relèvent d'autres IA (spécialités dédiées du studio).`;
    },

    /** Conversation directe. Balises : <ops-model kind style floors width depth height name/> · <ops-kit world="wld_…" max="48"/> (max 2 par message). */
    async chat(pid, text) {
      text = String(text || '').trim();
      if (!text) throw new HttpError(400, 'Message vide');
      if (text.length > 20000) throw new HttpError(413, 'Message trop long');
      await workspace.getProject(pid);
      const hist = (await db.all("SELECT role,content FROM messages WHERE project_id=? AND agent_id='modeling' ORDER BY created DESC LIMIT 10", [pid])).reverse().map((m) => ({ role: m.role === 'user' ? 'user' : 'assistant', content: trunc(m.content, 3000) }));
      const have = (await api.list(pid)).slice(0, 8).map((a) => ({ id: a.id, type: a.type, name: a.name, valid: a.valid }));
      const worlds = (await ctx.world.list(pid)).filter((w) => w.valid).slice(0, 5).map((w) => ({ id: w.id, name: w.name, buildings: w.stats.buildings }));
      const sys = `${MODELING_PROMPT}\n\nMODE CONVERSATION DIRECTE avec l'utilisateur. Assets/kits existants (données réelles) : ${JSON.stringify(have)}. Mondes utilisables : ${JSON.stringify(worlds)}\nActions (max 2 par message) :\n<ops-model kind="${BUILDING_KINDS[0]}|…|${PROP_KINDS[0]}" style="béton" floors="4" width="14" depth="14" name="optionnel"/>\n<ops-kit world="id_du_monde" max="24"/>\nN'affirme avoir créé un modèle que si tu émets la balise : le système te rapportera le résultat réel.`;
      const mid = () => uid('m_');
      await db.run('INSERT INTO messages(id,project_id,run_id,agent_id,role,content,created) VALUES(?,?,NULL,?,?,?,?)', [mid(), pid, 'modeling', 'user', text, now()]);
      const r = await chatWithCentral(await agent(), [{ role: 'system', content: sys }, ...hist, { role: 'user', content: text }]);
      const todo = [];
      const reply0 = r.text.replace(/<ops-(model|kit)\b([^>]*?)\/?>(?:<\/ops-(?:model|kit)>)?/g, (_, tag, attrs) => { const o = { tag }; for (const m of attrs.matchAll(ATTR)) o[m[1]] = m[2]; todo.push(o); return ''; }).trim();
      const actions = [];
      for (const o of todo.slice(0, 2)) {
        try {
          if (o.tag === 'model') { const g = await api.generate({ project_id: pid, params: o }); actions.push({ ok: true, id: g.asset.id, detail: `Modèle « ${g.asset.name} » : LOD ${g.asset.stats.lods.map((l) => l.triangles).join('/')} triangles, ${g.asset.valid ? 'valide' : 'INVALIDE'}, fichiers ${g.asset.files_mode === 'proposed' ? 'proposés (à approuver)' : g.asset.files_mode === 'written' ? 'écrits' : 'non livrés'}` }); }
          else { const g = await api.kit({ project_id: pid, world_id: o.world, max_archetypes: o.max === undefined ? 48 : Number(o.max) }); actions.push({ ok: true, id: g.asset.id, detail: `${g.asset.name} : ${g.asset.stats.buildings} bâtiments → ${g.asset.stats.archetypes} archétypes, ${g.asset.valid ? 'valide' : 'INVALIDE'}` }); }
        } catch (e) { actions.push({ ok: false, detail: `Échec : ${e.message}` }); }
      }
      if (todo.length > 2) actions.push({ ok: false, detail: `${todo.length - 2} action(s) ignorée(s) (maximum 2 par message)` });
      let reply = reply0;
      if (actions.length) reply += '\n\n**Actions effectuées**\n' + actions.map((a) => `- ${a.ok ? '✅' : '⛔'} ${a.detail}`).join('\n');
      await db.run('INSERT INTO messages(id,project_id,run_id,agent_id,role,content,created) VALUES(?,?,NULL,?,?,?,?)', [mid(), pid, 'modeling', 'assistant', reply, now()]);
      events.emit('modeling', { id: null, project_id: pid });
      return { reply, actions };
    },
  };
  return api;
}
const r3 = (v) => Math.round(v * 1000) / 1000;
