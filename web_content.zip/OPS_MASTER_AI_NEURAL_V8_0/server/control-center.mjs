/** Agrégateur global OPS : lecture seule, indépendant des moteurs et superviseurs existants. */
export function buildControlCenterReport({ projects = [], agents = [], taskRows = [], directorRows = [], workItems = [], events = [], engines = [], studioAis = [], providers = [], generatedAt = Date.now() }) {
  const byProject = new Map(projects.map(p => [p.id, { id:p.id, name:p.name, archived:!!p.archived, tasks:0, active:0, blocked:0, done:0, handoffs:0, engines:0 }]));
  const activeStates = new Set(['running','in_progress','accepted']);
  const blockedStates = new Set(['blocked','error','failed']);
  const countTask = (t) => {
    const p=byProject.get(t.project_id); if(!p) return;
    p.tasks++;
    if(activeStates.has(t.status)) p.active++;
    if(blockedStates.has(t.status)) p.blocked++;
    if(t.status==='done') p.done++;
  };
  taskRows.forEach(countTask); directorRows.forEach(countTask);
  for(const w of workItems){ const p=byProject.get(w.project_id); if(p && ['queued','accepted'].includes(w.status)) p.handoffs++; }
  for(const e of engines){ const p=byProject.get(e.project_id); if(p) p.engines++; }
  const workload = agents.map(a => {
    const tasks=taskRows.filter(t=>t.agent_id===a.id), directed=directorRows.filter(t=>t.assignee===a.id), inbox=workItems.filter(w=>w.to_agent===a.id && ['queued','accepted'].includes(w.status));
    const running=tasks.filter(t=>activeStates.has(t.status)).length+directed.filter(t=>activeStates.has(t.status)).length;
    const failed=tasks.filter(t=>blockedStates.has(t.status)).length+directed.filter(t=>blockedStates.has(t.status)).length;
    return {id:a.id,name:a.name,role:a.role,enabled:!!a.enabled,running,failed,pending_inbox:inbox.length,done:tasks.filter(t=>t.status==='done').length+directed.filter(t=>t.status==='done').length};
  });
  const activeProjects=[...byProject.values()].filter(p=>!p.archived);
  const total={projects:activeProjects.length,agents:agents.length,agents_enabled:agents.filter(a=>a.enabled).length,tasks:taskRows.length+directorRows.length,active:taskRows.filter(t=>activeStates.has(t.status)).length+directorRows.filter(t=>activeStates.has(t.status)).length,blocked:taskRows.filter(t=>blockedStates.has(t.status)).length+directorRows.filter(t=>blockedStates.has(t.status)).length,pending_handoffs:workItems.filter(w=>['queued','accepted'].includes(w.status)).length,engines:engines.length,engines_online:engines.filter(e=>['online','ready','connected','active'].includes(String(e.status).toLowerCase())).length,studio_ais:studioAis.length,providers_ready:providers.filter(p=>p.enabled&&p.model&&p.key_set).length};
  return {schema:'ops.control-center.v1',generated_at:generatedAt,live:true,summary:total,projects:activeProjects.sort((a,b)=>b.active-a.active||b.blocked-a.blocked||a.name.localeCompare(b.name)),agents:workload.sort((a,b)=>b.running-a.running||b.pending_inbox-a.pending_inbox||a.name.localeCompare(b.name)),engines:engines.map(e=>({id:e.id,project_id:e.project_id,name:e.name,kind:e.kind,status:e.status,last_check:e.last_check,detail:e.detail})),studio_ais:studioAis.map(a=>({id:a.id,name:a.name,domain:a.domain,status:a.status,model:a.model,validated_at:a.validated_at})),recent_events:events.map(e=>({id:e.id,project_id:e.project_id,type:e.type,from_agent:e.from_agent,to_agent:e.to_agent,payload:e.payload,created:e.created})),alerts:[...(total.blocked?[{severity:'high',code:'TASKS_BLOCKED',count:total.blocked,message:`${total.blocked} tâche(s) en erreur ou bloquées.`}]:[]),...(total.pending_handoffs?[{severity:'warning',code:'HANDOFFS_PENDING',count:total.pending_handoffs,message:`${total.pending_handoffs} transmission(s) attendent une prise en charge.`}]:[]),...(total.agents_enabled===0?[{severity:'high',code:'NO_AGENT_ENABLED',count:0,message:'Aucun agent activé.'}]:[])]};
}

export function createControlCenter(ctx){
  async function report(){
    const [projects,agents,taskRows,directorRows,workItems,events,engines,studioAis,providers]=await Promise.all([
      ctx.db.all('SELECT id,name,archived FROM projects ORDER BY archived ASC,name ASC'),
      ctx.db.all('SELECT id,name,role,enabled FROM agents ORDER BY sort_order'),
      ctx.db.all('SELECT id,project_id,agent_id,status FROM tasks ORDER BY created DESC LIMIT 3000'),
      ctx.db.all('SELECT id,project_id,assignee,status FROM director_tasks ORDER BY created DESC LIMIT 3000'),
      ctx.db.all("SELECT id,project_id,to_agent,status FROM collaboration_work_items ORDER BY created DESC LIMIT 1000"),
      ctx.db.all('SELECT id,project_id,type,from_agent,to_agent,payload,created FROM collaboration_events ORDER BY created DESC LIMIT 60'),
      ctx.db.all('SELECT id,project_id,name,kind,status,last_check,detail FROM engines ORDER BY created DESC LIMIT 300'),
      ctx.db.all('SELECT id,name,domain,status,model,validated_at FROM studio_ais ORDER BY sort_order'),
      ctx.db.all('SELECT id,enabled,model,key_enc FROM providers'),
    ]);
    const ready=providers.map(p=>({...p,key_set:!!p.key_enc}));
    return buildControlCenterReport({projects,agents,taskRows,directorRows,workItems,events,engines,studioAis,providers:ready});
  }
  return {report};
}
