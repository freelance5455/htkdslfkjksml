import crypto from 'node:crypto';

export const uid = (p = '') => p + crypto.randomBytes(8).toString('hex');
export const now = () => Date.now();
export const j = (v) => JSON.stringify(v);
export const pj = (s, d = null) => { try { return s == null ? d : JSON.parse(s); } catch { return d; } };
export const sha1 = (buf) => crypto.createHash('sha1').update(buf).digest('hex');

export const sleep = (ms, signal) => new Promise((res, rej) => {
  if (signal?.aborted) return rej(new Error('aborted'));
  const t = setTimeout(res, ms);
  signal?.addEventListener('abort', () => { clearTimeout(t); rej(new Error('aborted')); }, { once: true });
});

export function slugify(s) {
  return String(s || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase()
    .replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 60) || 'projet';
}

export class HttpError extends Error {
  constructor(status, message, code) { super(message); this.status = status; this.code = code || 'error'; }
}

export function trunc(s, n) {
  s = String(s ?? '');
  return s.length > n ? s.slice(0, n) + `\n…[tronqué : ${s.length - n} caractères]` : s;
}

export function normText(s) {
  return String(s || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase();
}

export function safeEqual(a, b) {
  const x = crypto.createHash('sha256').update(String(a)).digest();
  const y = crypto.createHash('sha256').update(String(b)).digest();
  return crypto.timingSafeEqual(x, y);
}

/** Extrait le premier objet JSON d'une réponse de modèle (tolère le texte autour et les blocs ```json). */
export function extractJson(text) {
  if (!text) return null;
  const fence = text.match(/```(?:json)?\s*([\s\S]*?)```/i);
  const cands = [];
  if (fence) cands.push(fence[1]);
  const a = text.indexOf('{'), b = text.lastIndexOf('}');
  if (a >= 0 && b > a) cands.push(text.slice(a, b + 1));
  for (const c of cands) { const v = pj(c.trim()); if (v && typeof v === 'object') return v; }
  return null;
}
