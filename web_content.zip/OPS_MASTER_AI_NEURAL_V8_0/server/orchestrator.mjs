import { uid, now, j, pj, trunc, extractJson, normText, HttpError } from './util.mjs';
import { systemPromptFor, WORKER_IDS, ALL_AGENT_IDS } from './agents.mjs';
import { extractMathExpression, neuralSystemContext, analyzeNeuralRequest, neuralQualityChecklist, aaaDetailContract } from './neural.mjs';
import { analyzeArtifactGraph } from './artifact-graph.mjs';
import { analyzeProjectArchitecture, formatArchitectureReport } from './project-architecture.mjs';

const MAX_TOOL_ROUNDS = 4;
const MAX_EXTRA_REQUESTS = 4;

/** Les outils doivent être exécutés même si le même message contient déjà des fichiers. */
export function shouldRunAgentTools(output, rounds = 0) {
  return Array.isArray(output?.tools) && output.tools.length > 0 && rounds < MAX_TOOL_ROUNDS;
}

/** Applique des remplacements exacts, bornés et non ambigus à un texte source. */
export function applyExactPatches(source, operations) {
  if (!Array.isArray(operations) || operations.length < 1 || operations.length > 100) throw new Error('Patch invalide : 1 à 100 opérations attendues.');
  let result = String(source);
  for (let i = 0; i < operations.length; i++) {
    const op = operations[i];
    if (!op || typeof op.find !== 'string' || !op.find.length || typeof op.replace !== 'string') throw new Error(`Patch ${i + 1} invalide : find et replace doivent être des chaînes, find non vide.`);
    if (op.find.length > 50000 || op.replace.length > 100000) throw new Error(`Patch ${i + 1} trop volumineux.`);
    const first = result.indexOf(op.find);
    if (first < 0) throw new Error(`Patch ${i + 1} refusé : contexte introuvable, le fichier a peut-être changé.`);
    if (result.indexOf(op.find, first + op.find.length) >= 0) throw new Error(`Patch ${i + 1} refusé : contexte ambigu (plusieurs occurrences).`);
    result = result.slice(0, first) + op.replace + result.slice(first + op.find.length);
    if (Buffer.byteLength(result, 'utf8') > 5 * 1024 * 1024) throw new Error('Patch refusé : fichier supérieur à 5 Mo.');
  }
  return result;
}

export function coderTaskRequiresFiles(task) {
  if (task?.agent_id !== 'coder') return false;
  return /code|program|développ|developp|implément|implement|cré|constru|intégr|integr|corrig|fix|refactor|build|jeu/i.test(`${task.title || ''}\n${task.instruction || ''}`);
}

/** Extrait les balises du protocole OPS d'une réponse d'agent. */
export function parseAgentOutput(text) {
  const tools = [], files = [], patches = [], deletes = [], memory = [], experiences = [], requests = [], bus = [], dependencies = [];
  let clean = String(text || '');
  clean = clean.replace(/<ops-tool>([\s\S]*?)<\/ops-tool>/g, (_, b) => { const o = pj(b.trim()); if (o?.tool) tools.push(o); return ''; });
  clean = clean.replace(/<ops-file\s+path="([^"]+)"\s*>([\s\S]*?)<\/ops-file>/g, (_, p, c) => { files.push({ path: p.trim(), content: c.replace(/^\r?\n/, '').replace(/\r?\n$/, '') }); return `[fichier proposé : ${p.trim()}]`; });
  clean = clean.replace(/<ops-patch\s+path="([^"]+)"\s*>([\s\S]*?)<\/ops-patch>/g, (_, p, body) => { const parsed = pj(body.trim()); patches.push({ path: p.trim(), operations: Array.isArray(parsed) ? parsed : parsed?.operations }); return `[patch proposé : ${p.trim()}]`; });
  clean = clean.replace(/<ops-delete\s+path="([^"]+)"\s*\/?>(?:<\/ops-delete>)?/g, (_, p) => { deletes.push({ path: p.trim() }); return `[suppression proposée : ${p.trim()}]`; });
  clean = clean.replace(/<ops-memory\s+key="([^"]+)"\s*>([\s\S]*?)<\/ops-memory>/g, (_, k, v) => { memory.push({ key: k.trim(), value: v.trim() }); return ''; });
  clean = clean.replace(/<ops-experience\s+domain="([^"]+)"\s*>([\s\S]*?)<\/ops-experience>/g, (_, domain, lesson) => { experiences.push({ domain: domain.trim(), lesson: lesson.trim() }); return '[expérience proposée pour validation]'; });
  clean = clean.replace(/<ops-request\s+agent="([^"]+)"\s*>([\s\S]*?)<\/ops-request>/g, (_, a, b) => { requests.push({ agent: a.trim(), text: b.trim() }); return `[demande à ${a.trim()}]`; });
  clean = clean.replace(/<ops-bus\s+type="([^"]+)"(?:\s+to="([^"]*)")?\s*>([\s\S]*?)<\/ops-bus>/g, (_, type, to, body) => { let payload; try { payload = JSON.parse(body.trim() || '{}'); } catch { payload = { text: body.trim() }; } bus.push({ type: type.trim(), to: (to || '').trim() || null, payload }); return '[événement transmis au bus OPS]'; });
  clean = clean.replace(/<ops-dependency\s+prerequisite="([^"]+)"\s+dependent="([^"]+)"(?:\s+contract="([^"]*)")?\s*\/?>/g, (_, prerequisite, dependent, contract) => { dependencies.push({ prerequisite: prerequisite.trim(), dependent: dependent.trim(), contract: (contract || '').trim() }); return '[contrat de dépendance proposé]'; });
  return { tools, files, patches, deletes, memory, experiences, requests, bus, dependencies, text: clean.trim() };
}

/** Valide un plan : agents connus, dépendances existantes, pas de cycle. Retourne les sous-tâches normalisées ou lève une erreur. */
export function validatePlan(plan, allowed) {
  const subs = Array.isArray(plan?.subtasks) ? plan.subtasks : null;
  if (!subs || !subs.length) throw new Error('plan sans sous-tâches');
  if (subs.length > 14) throw new Error('trop de sous-tâches (max 14)');
  const ids = new Set();
  const out = subs.map((s, i) => {
    const id = String(s.id || `t${i + 1}`);
    if (ids.has(id)) throw new Error(`id dupliqué ${id}`);
    ids.add(id);
    const agent = String(s.agent || '');
    if (!allowed.includes(agent)) throw new Error(`agent non autorisé : ${agent}`);
    if (!String(s.instruction || '').trim()) throw new Error(`instruction vide (${id})`);
    return { id, title: String(s.title || s.instruction).slice(0, 120), agent, instruction: String(s.instruction), depends_on: Array.isArray(s.depends_on) ? s.depends_on.map(String) : [] };
  });
  for (const s of out) for (const d of s.depends_on) if (!ids.has(d)) throw new Error(`dépendance inconnue : ${d}`);
  const state = new Map();
  const visit = (id) => {
    if (state.get(id) === 2) return;
    if (state.get(id) === 1) throw new Error('cycle de dépendances');
    state.set(id, 1);
    for (const d of out.find((x) => x.id === id).depends_on) visit(d);
    state.set(id, 2);
  };
  out.forEach((s) => visit(s.id));
  return out;
}

const KEYWORDS = [
  ['architect', /architect|structure|conception|module|schema|schéma/],
  ['coder', /codeur|coder|programmer|programme|coder ai|développer|developper|implémenter|implementation|intégrer.*moteur|corriger.*code/],
  ['frontend', /interface|ui\b|ecran|écran|css|html|responsive|bouton|menu/],
  ['backend', /api|serveur|server|base de donn|sqlite|postgres|websocket|auth/],
  ['engine3d', /moteur|3d|shader|webgl|rendu|render|fbx|gltf|physique/],
  ['debug', /bug|erreur|corrig|crash|plante|r[ée]gression|fix/],
  ['gameplay', /gameplay|mission|ennemi|niveau|score|progression|arme/],
  ['npc', /npc|pnj|personnage non joueur|comportement.*personnage|intelligence.*personnage|foule|population/],
  ['physics', /physique|collision|gravité|gravite|ragdoll|rigid.?body|raycast|trigger|simulation physique/],
  ['art3d', /mod[eè]le|texture|environnement|asset|v[ée]hicule|b[âa]timent|ville|city/],
  ['animation', /animation|squelette|rig|ragdoll|skeleton|euphoria/],
  ['audio', /audio|son\b|voix|vocal|musique|sound/],
];


/** Plan déterministe complet pour créer un nouveau jeu : les spécialistes définissent leurs contrats, CODER assemble et écrit le jeu jouable. */
export function newGamePlan(instruction, allowed) {
  if (!allowed.includes('coder')) throw new Error('OPS CODER AI doit être affecté au projet pour créer un jeu.');
  const roles = [
    ['architect', 'Architecture et contrats', 'Définis l’architecture complète, points d’entrée, modules, contrats API, événements, unités, ordre d’initialisation, compatibilité et critères d’acceptation.'],
    ['engine3d', 'Moteur 3D et rendu', 'Définis et livre les fondations réellement intégrables : scène, caméra, boucle, éclairage, ressources, redimensionnement, gestion des erreurs et profils de performance.'],
    ['gameplay', 'Mécaniques jouables', 'Conçois les mécaniques centrales, objectifs, progression, états de partie, victoire/défaite, contrôles et tests déterministes.'],
    ['npc', 'Intelligence des PNJ', 'Livre comportements PNJ connectables au Game Loop : états, perception bornée, réactions événementielles, navigation disponible, mémoire et budget CPU.'],
    ['physics', 'Physique et interactions', 'Définis les unités, collisions, triggers, gravité, interactions et synchronisation avec le moteur existant.'],
    ['art3d', 'Monde et ressources 3D', 'Prépare environnement et ressources procédurales/code compatibles avec le pipeline détecté, échelle, pivots, matériaux, LOD et budgets.'],
    ['animation', 'Personnages et animations', 'Définis rigs, états, transitions, blending et fallback procédural en fonction des assets réellement présents.'],
    ['frontend', 'Interface et commandes', 'Conçois HUD et menus réellement connectés aux états du jeu, commandes clavier/tactiles, pause, chargement, erreurs et responsive.'],
    ['audio', 'Audio et retours sonores', 'Conçois le système audio réellement intégrable, activation utilisateur, volumes, spatialisation si supportée et fallback sans assets.'],
  ];
  const subtasks = [];
  for (const [agent, title, instructionPart] of roles) if (allowed.includes(agent)) {
    subtasks.push({ id: `design_${agent}`, agent, title, instruction: `CONTRIBUTION À LA CRÉATION DU JEU. Demande utilisateur : ${instruction}\n${instructionPart}\nRetourne des contrats précis, du code concret si approprié, critères d'acceptation, tests et limites. Tu travailles en parallèle avec les autres spécialistes. N'écris pas de modules incompatibles ou isolés.`, depends_on: [] });
  }
  if (allowed.includes('backend') && /multijoueur|multiplayer|en ligne|online|serveur|serveur dédié|coopératif|coop/i.test(instruction)) {
    subtasks.push({ id: 'design_backend', agent: 'backend', title: 'Services et réseau', instruction: `Conçois les services réellement requis pour cette demande de jeu : ${instruction}. Définis API, données, sécurité, synchronisation et tests. N'invente pas de serveur disponible.`, depends_on: [] });
  }
  const designDeps = subtasks.map(x => x.id);
  subtasks.push({ id: 'build_game', agent: 'coder', title: 'OPS CODER AI — développement et intégration du jeu', instruction: `TU ES LE RESPONSABLE DE L'IMPLÉMENTATION. Demande utilisateur : ${instruction}\nAnalyse les livrables de tous les spécialistes dont tu dépends. Inspecte le workspace et les vrais points d'entrée. Développe le jeu complet correspondant au périmètre demandé : fichiers sources complets, scène/écran, boucle de jeu, commandes clavier et tactiles si navigateur mobile, mécaniques centrales, HUD, pause/reprise, fin/recommencer, interactions/collisions, sauvegarde si pertinente, gestion d'erreurs et README. Intègre réellement les systèmes compatibles dans le bootstrap et le Game Loop. Chaque bouton doit agir, chaque fonction annoncée doit être reliée. Crée des tests adaptés et vérifie imports, exports, chemins, API, performances et compatibilité. Fournis un inventaire des fichiers et une carte des points d'intégration pour OPS DEBUG AI. Ne livre pas de pseudo-code, TODO ou modules isolés en remplacement des fonctions demandées. Si une capacité est impossible avec les ressources présentes, indique la limite sans la simuler.`, depends_on: designDeps });
  const debugAvailable = allowed.includes('debug');
  if (debugAvailable) {
    subtasks.push({ id: 'debug_review', agent: 'debug', title: 'OPS DEBUG AI — audit du code de CODER', instruction: `Audite indépendamment les fichiers complets proposés par OPS CODER AI dans la tâche build_game. Les sources proposées te seront transmises comme artefacts de dépendance. Vérifie syntaxe logique, imports, chemins, API, intégration au bootstrap/Game Loop, fonctions factices, contrôles, états, compatibilité et tests. Ne réécris pas les fichiers. Retourne uniquement des constats actionnables : ID, sévérité, confirmé/probable/non vérifiable, fichier, preuve, cause racine, correction minimale et test de non-régression. S'il n'y a aucun défaut démontrable, dis-le explicitement.`, depends_on: ['build_game'] });
    subtasks.push({ id: 'coder_repairs', agent: 'coder', title: 'OPS CODER AI — corrections après audit DEBUG', instruction: `Reprends ton implémentation à partir des fichiers proposés dans build_game ET du rapport indépendant debug_review. Pour chaque défaut, indique confirmé/non reproduit/hypothèse, puis corrige les défauts confirmés et les risques justifiés. Rends les fichiers complets corrigés via <ops-file>, conserve les fonctions déjà présentes, ajoute les tests de non-régression et mets à jour les imports/bootstrap si nécessaire. Ne désactive aucun test pour le faire passer. Pour les constats non retenus, démontre pourquoi. Termine par un tableau défaut → décision → fichier corrigé → test.`, depends_on: ['build_game', 'debug_review'] });
  }
  return { summary: 'Pipeline de création jeu : spécialistes en parallèle → OPS CODER AI implémente → OPS DEBUG AI audite les fichiers proposés → OPS CODER AI corrige → OPS QUALITY TEAM vérifie indépendamment.', subtasks, by_rules: true, workflow: 'game-build-debug-repair' };
}

/** Planificateur déterministe, utilisé uniquement si le coordinateur IA est injoignable ou renvoie un plan invalide. */
export function rulePlan(instruction, allowed) {
  const t = normText(instruction);
  const picked = KEYWORDS.filter(([a, re]) => allowed.includes(a) && re.test(t)).map(([a]) => a);
  if (/jeu|game|jeu vid[eé]o|projet ludique/.test(t)) {
    for (const id of ['coder', 'engine3d', 'gameplay', 'npc', 'physics', 'art3d', 'animation']) if (allowed.includes(id) && !picked.includes(id)) picked.push(id);
  }
  const agents = picked.length ? picked : [allowed.includes('architect') ? 'architect' : allowed[0]];
  const subtasks = agents.map((a, i) => ({
    id: `t${i + 1}`, agent: a, title: `Contribution ${a}`,
    instruction: `Demande de l'utilisateur : ${instruction}\n\nTraite uniquement la partie relevant de ta spécialité.`,
    depends_on: a !== 'architect' && agents.includes('architect') ? [`t${agents.indexOf('architect') + 1}`] : [],
  }));
  return { summary: 'Plan établi par règles de mots-clés (coordinateur IA indisponible ou plan invalide).', subtasks, by_rules: true };
}

export function createOrchestrator(ctx) {
  const { db, providers, workspace, web, events } = ctx;
  const active = new Map(); // runId -> AbortController

  const getAgent = async (id) => db.get('SELECT * FROM agents WHERE id=?', [id]);
  const setting = async (k, d) => { const r = await db.get('SELECT value FROM settings WHERE key=?', [k]); return r ? r.value : d; };

  async function setRun(id, patch) {
    const keys = Object.keys(patch);
    await db.run(`UPDATE runs SET ${keys.map((k) => k + '=?').join(',')} WHERE id=?`, [...keys.map((k) => (typeof patch[k] === 'object' && patch[k] !== null ? j(patch[k]) : patch[k])), id]);
    events.emit('run.update', { id, ...patch, plan: undefined, report: undefined });
  }
  async function setTask(id, patch) {
    patch.updated = now();
    const keys = Object.keys(patch);
    await db.run(`UPDATE tasks SET ${keys.map((k) => k + '=?').join(',')} WHERE id=?`, [...keys.map((k) => (typeof patch[k] === 'object' && patch[k] !== null ? j(patch[k]) : patch[k])), id]);
    const t = await db.get('SELECT id,run_id,agent_id,title,status,error,attempts FROM tasks WHERE id=?', [id]);
    events.emit('task.update', t);
  }
  async function addMessage(project_id, run_id, agent_id, role, content) {
    const m = { id: uid('m_'), project_id, run_id, agent_id, role, content, created: now() };
    await db.run('INSERT INTO messages(id,project_id,run_id,agent_id,role,content,created) VALUES(?,?,?,?,?,?,?)', [m.id, project_id, run_id, agent_id, role, content, m.created]);
    events.emit('message', { ...m, content: trunc(content, 400) });
    return m;
  }
  async function createTask(run, s, round = 0) {
    const id = uid('task_');
    const t = { id, run_id: run.id, project_id: run.project_id, agent_id: s.agent, title: s.title, instruction: s.instruction, status: 'pending', depends_on: j(s.depends_on || []), round, created: now() };
    await db.run('INSERT INTO tasks(id,run_id,project_id,agent_id,title,instruction,status,depends_on,result,error,attempts,round,created,started,finished,updated) VALUES(?,?,?,?,?,?,?,?,NULL,NULL,0,?,?,NULL,NULL,?)',
      [t.id, t.run_id, t.project_id, t.agent_id, t.title, t.instruction, t.status, t.depends_on, round, t.created, t.created]);
    return { ...t, depends_on: s.depends_on || [] };
  }

  async function projectContext(pid) {
    const p = await workspace.getProject(pid);
    const tree = workspace.tree(pid).filter((e) => e.type === 'file').slice(0, 150).map((e) => `${e.path} (${e.size} o)`);
    const mem = await db.all('SELECT agent_id,key,value FROM memory WHERE project_id=? ORDER BY created DESC LIMIT 25', [pid]);
    return { p, tree, mem };
  }

  // ---------- exécution d'un outil demandé par un agent ----------
  async function runTool(pid, call) {
    try {
      if (call.tool === 'list_files') return j(workspace.walk(pid, call.path || '.').slice(0, 300));
      if (call.tool === 'inspect_project') {
        const entries = workspace.walk(pid).filter((x) => x.type === 'file');
        const preferred = entries.filter((x) => /(^|\/)(package\.json|index\.html|vite\.config\.|webpack\.config\.|src\/main\.|src\/index\.|main\.|README\.md)$/i.test(x.path)).slice(0, 12);
        const picked = preferred.length ? preferred : entries.filter((x) => /\.(html|js|mjs|ts|json|css|md)$/i.test(x.path)).slice(0, 8);
        const samples = []; for (const f of picked) { try { const v = workspace.readFile(pid, f.path, { maxBytes: 45000 }); if (!v.binary) samples.push(`\n--- ${f.path} ---\n${trunc(v.content, 9000)}`); } catch {} }
        const architectureFiles = [];
        for (const f of entries.filter((x) => /\.(?:[cm]?[jt]sx?|vue|svelte|html?|json)$/i.test(x.path)).slice(0, 220)) {
          try { const v = workspace.readFile(pid, f.path, { maxBytes: 180000 }); if (!v.binary) architectureFiles.push({ path: f.path, content: v.content }); } catch {}
        }
        const architecture = analyzeProjectArchitecture(architectureFiles, entries.map((x) => x.path));
        return `ARBORESCENCE (${entries.length} fichiers)\n${entries.slice(0, 180).map((x) => `${x.path} (${x.size} o)`).join('\n')}\n\n${formatArchitectureReport(architecture)}\n\nDONNÉES ARCHITECTURE JSON :\n${JSON.stringify({ summary: architecture.summary, entrypoints: architecture.entrypoints, orphan_modules: architecture.orphan_modules, dependency_cycles: architecture.dependency_cycles, unresolved_references: architecture.unresolved_references.slice(0, 80) })}\n\nFICHIERS D’ENTRÉE ET CONFIGURATION :${samples.join('\n')}`;
      }
      if (call.tool === 'read_file') {
        if (/(^|\/)\.env|\.pem$|id_rsa|\.key$/i.test(String(call.path))) return 'Refusé : fichier sensible.';
        const f = workspace.readFile(pid, String(call.path), { maxBytes: 300 * 1024 });
        return f.binary ? '(fichier binaire)' : trunc(f.content, 24000);
      }
      if (call.tool === 'web_search') return j(await web.search(String(call.query)));
      if (call.tool === 'web_fetch') return trunc((await web.fetchDoc(String(call.url))).text, 16000);
      if (call.tool === 'library_search') return j(await ctx.library.toolSearch(pid, String(call.query || '')));
      if (call.tool === 'library_read') return trunc(await ctx.library.toolRead(pid, String(call.id)), 24000);
      return `Outil inconnu : ${call.tool}`;
    } catch (e) { return `Erreur outil : ${e.message}`; }
  }

  // ---------- propositions de fichiers ----------
  async function recordProposal(task, kind, path, content) {
    try { workspace.safePath(task.project_id, path); } catch (e) { return { skipped: `${path} : ${e.message}` }; }
    if (kind === 'write') {
      try { const cur = workspace.readFile(task.project_id, path); if (!cur.binary && cur.content === content) return { skipped: `${path} : identique` }; } catch { /* nouveau fichier */ }
      // une correction (round>0) remplace toutes les propositions en attente du run sur ce fichier ; sinon seulement celles du même agent
      if (task.round > 0) await db.run("UPDATE approvals SET status='superseded', decided=? WHERE run_id=? AND path=? AND status='pending'", [now(), task.run_id, path]);
      else await db.run("UPDATE approvals SET status='superseded', decided=? WHERE run_id=? AND path=? AND agent_id=? AND status='pending'", [now(), task.run_id, path, task.agent_id]);
    }
    const id = uid('apr_');
    await db.run('INSERT INTO approvals(id,project_id,run_id,task_id,agent_id,kind,path,content,status,note,created,decided) VALUES(?,?,?,?,?,?,?,?,?,NULL,?,NULL)',
      [id, task.project_id, task.run_id, task.id, task.agent_id, kind, path, content ?? null, 'pending', now()]);
    events.emit('approval', { id, project_id: task.project_id, path, kind, agent_id: task.agent_id });
    return { id };
  }

  async function approve(id, { actor = 'user' } = {}) {
    const a = await db.get('SELECT * FROM approvals WHERE id=?', [id]);
    if (!a) throw new HttpError(404, 'Demande introuvable');
    if (a.status !== 'pending') throw new HttpError(409, `Déjà traitée (${a.status})`);
    let r;
    if (a.kind === 'delete') r = await workspace.deleteFile(a.project_id, a.path, { actor: `${actor}:${a.agent_id}`, confirm: true });
    else { const binary = typeof a.content === 'string' && a.content.startsWith('__OPS_BASE64__'); r = await workspace.writeFile(a.project_id, a.path, binary ? a.content.slice('__OPS_BASE64__'.length) : a.content, { actor: `${actor}:${a.agent_id}`, encoding: binary ? 'base64' : 'utf8' }); }
    await db.run("UPDATE approvals SET status='approved', decided=?, note=? WHERE id=?", [now(), r.change_id, id]);
    events.emit('approval', { id, project_id: a.project_id, status: 'approved' });
    return { ok: true, change_id: r.change_id };
  }
  async function reject(id) {
    const a = await db.get('SELECT * FROM approvals WHERE id=?', [id]);
    if (!a) throw new HttpError(404, 'Demande introuvable');
    if (a.status !== 'pending') throw new HttpError(409, `Déjà traitée (${a.status})`);
    await db.run("UPDATE approvals SET status='rejected', decided=? WHERE id=?", [now(), id]);
    await workspace.log(a.project_id, 'user', 'approval.reject', a.path);
    events.emit('approval', { id, project_id: a.project_id, status: 'rejected' });
    return { ok: true };
  }

  // ---------- exécution d'une tâche par un agent ----------
  async function runTask(run, task, ctxInfo, signal) {
    const agent = await getAgent(task.agent_id);
    if (!agent || !agent.enabled) throw Object.assign(new Error(`Agent indisponible : ${task.agent_id}`), { fatal: true });
    const deps = Array.isArray(task.depends_on) ? task.depends_on : pj(task.depends_on, []);
    const depRows = deps.length ? await db.all(`SELECT agent_id,title,result FROM tasks WHERE run_id=? AND id IN (${deps.map(() => '?').join(',')})`, [run.id, ...deps]) : [];
    const dependencyFiles = deps.length ? await db.all(`SELECT task_id,agent_id,path,content,status FROM approvals WHERE run_id=? AND task_id IN (${deps.map(() => '?').join(',')}) AND kind='write' ORDER BY created`, [run.id, ...deps]) : [];
    const { p, tree, mem } = ctxInfo;
    const candidates = await db.all("SELECT id,agent_id,domain,lesson,evidence,created FROM experience_memory WHERE status='approved' AND (project_id IS NULL OR project_id=?) ORDER BY created DESC LIMIT 150", [run.project_id]);
    const terms = new Set(normText(`${run.instruction} ${task.instruction} ${task.title}`).split(/[^a-z0-9à-ÿ]+/).filter((x) => x.length > 2));
    const experiences = candidates.map((m) => {
      const words = normText(`${m.domain} ${m.lesson}`).split(/[^a-z0-9à-ÿ]+/).filter((x) => x.length > 2);
      const overlap = words.reduce((n, w) => n + (terms.has(w) ? 1 : 0), 0);
      const domainHit = [...terms].some((t) => normText(m.domain).includes(t));
      return { ...m, relevance: overlap + (domainHit ? 4 : 0) };
    }).filter((m) => m.relevance > 0).sort((a, b) => b.relevance - a.relevance || b.created - a.created).slice(0, 12);
    for (const m of experiences) await db.run('INSERT INTO experience_events(id,experience_id,project_id,task_id,event,created) VALUES(?,?,?,?,?,?)', [uid('exev_'), m.id, run.project_id, task.id, 'retrieved', now()]);
    const historyRows = await db.all('SELECT role,content FROM messages WHERE project_id=? ORDER BY created DESC LIMIT 12', [run.project_id]);
    const history = historyRows.reverse();
    const math = extractMathExpression(task.instruction) || extractMathExpression(run.instruction);
    const neuralAnalysis = analyzeNeuralRequest(`${run.instruction}\n${task.instruction}`, ctxInfo.p.agents);
    const neuralContext = neuralSystemContext({ memories: mem, history, math, analysis: neuralAnalysis });
    const parts = [
      `PROJET : ${p.name} (${p.id})${p.description ? ' — ' + p.description : ''}`,
      `DEMANDE GLOBALE DE L'UTILISATEUR :\n${run.instruction}`,
      `TA SOUS-TÂCHE (${task.title}) :\n${task.instruction}`,
    ];
    if (depRows.length) parts.push('RÉSULTATS DES AGENTS DONT TU DÉPENDS :\n' + depRows.map((d) => `--- ${d.agent_id} / ${d.title} ---\n${trunc(d.result, 6000)}`).join('\n'));
    if (dependencyFiles.length) parts.push('FICHIERS SOURCES PROPOSÉS PAR LES TÂCHES DONT TU DÉPENDS (contenu exact, pas encore nécessairement approuvé/appliqué) :\n' + dependencyFiles.map((f) => `--- ${f.agent_id} | ${f.path} | ${f.status} ---\n${trunc(f.content, 18000)}`).join('\n\n'));
    if (mem.length) parts.push('MÉMOIRE PARTAGÉE DU PROJET :\n' + mem.map((m) => `- [${m.agent_id || 'user'}] ${m.key} : ${trunc(m.value, 400)}`).join('\n'));
    if (ctx.collaboration) { const busContext = await ctx.collaboration.contextFor(run.project_id, task.agent_id, 10); if (busContext) parts.push('OPS AI COMMUNICATION BUS — ÉVÉNEMENTS RÉCENTS PERTINENTS :\n' + busContext); const deps = await ctx.collaboration.listDependencies(run.project_id); if (deps.length) parts.push('CONTRATS DE DÉPENDANCE ENTRE MOTEURS :\n' + deps.map((d) => `- ${d.prerequisite} → ${d.dependent}${d.contract ? ` : ${d.contract}` : ''}`).join('\n')); }
    if (experiences.length) parts.push('MÉMOIRE D’EXPÉRIENCE VALIDÉE (à appliquer si pertinente) :\n' + experiences.map((m) => `- [${m.agent_id || 'équipe'} / ${m.domain}] ${trunc(m.lesson, 700)}${m.evidence ? ` | preuve : ${trunc(m.evidence, 300)}` : ''}`).join('\n'));
    parts.push('INSPECTION DU PROJET : avant toute modification, utilise inspect_project puis read_file sur les fichiers pertinents. Après avoir proposé des fichiers, vérifie leurs imports, chemins, points d’entrée et cohérence avec l’arborescence.');
    parts.push(`FICHIERS DU PROJET (${tree.length} affichés) :\n${tree.join('\n') || '(workspace vide)'}`);
    const messages = [{ role: 'system', content: systemPromptFor(agent) + '\n\n' + neuralContext + '\n\n' + aaaDetailContract(task.agent_id) }];
    if (run.history?.length) messages.push(...run.history);
    messages.push({ role: 'user', content: parts.join('\n\n') + '\n\nLIVRABLE EXIGE : développe chaque point utile avec suffisamment de détails pour qu’un développeur puisse le réaliser. Termine par : détails livrés, critères d’acceptation, auto-critique, améliorations appliquées, tests/protocoles et limites restantes.' });

    let final = null, toolRounds = 0, lastText = '';
    let centralSupport = '';
    let firstAttempt = true;
    let coderFileNudgeUsed = false;
    const collected = { files: new Map(), patches: [], deletes: [], memory: [], experiences: [], requests: [], bus: [], dependencies: [], text: [] };
    let providerMeta = {};
    for (;;) {
      let r;
      try {
        r = await providers.chat(agent, messages, { signal, timeoutMs: firstAttempt ? 45000 : 180000, retries: firstAttempt ? 0 : 2 });
      } catch (e) {
        if (firstAttempt && e.code === 'timeout' && task.agent_id !== 'coordinator' && !signal.aborted) {
          const coordinator = await getAgent('coordinator');
          const assistPrompt = `ASSISTANCE PRIORITAIRE À UN SPÉCIALISTE TROP LENT\nLe spécialiste ${task.agent_id} travaille sur : ${task.title}.\nDemande : ${run.instruction}\nSous-tâche : ${task.instruction}\nContexte projet : ${p.name}\nDépendances : ${depRows.map((d) => `${d.agent_id}/${d.title}: ${trunc(d.result, 1200)}`).join('\n') || 'aucune'}\n\nProduis un dossier d'aide concret et immédiatement exploitable : décomposition en petites étapes, décisions techniques, architecture proposée, pièges, exemples, critères d'acceptation et tests. N'invente aucun fichier ni résultat. Le spécialiste reprendra ensuite et restera responsable de son livrable.`;
          const assist = await providers.chat(coordinator, [{ role: 'system', content: systemPromptFor(coordinator) + '\n\n' + aaaDetailContract('director') }, { role: 'user', content: assistPrompt }], { signal, timeoutMs: 90000, retries: 1 });
          centralSupport = assist.text;
          messages.push({ role: 'assistant', content: 'La première tentative a dépassé le délai. OPS DIRECTOR AI apporte une assistance technique.' }, { role: 'user', content: `DOSSIER D'ASSISTANCE DE OPS DIRECTOR AI :\n${trunc(centralSupport, 12000)}\n\nReprends la tâche en t'appuyant sur cette aide, vérifie les choix, complète les détails et livre le résultat final de ta spécialité.` });
          firstAttempt = false;
          continue;
        }
        throw e;
      }
      firstAttempt = false;
      providerMeta = { provider: r.provider, model: r.model };
      const out = parseAgentOutput(r.text);
      lastText = out.text;
      if (out.text) collected.text.push(out.text);
      // Conserver les artefacts à travers plusieurs tours : une réponse peut contenir simultanément des outils ET du code.
      for (const f of out.files) collected.files.set(f.path, f.content);
      collected.patches.push(...out.patches);
      collected.deletes.push(...out.deletes);
      collected.memory.push(...out.memory);
      collected.experiences.push(...out.experiences);
      collected.requests.push(...out.requests);
      collected.bus.push(...out.bus);
      collected.dependencies.push(...out.dependencies);

      if (shouldRunAgentTools(out, toolRounds)) {
        toolRounds++;
        const results = [];
        for (const c of out.tools.slice(0, 4)) results.push(`<ops-result tool="${c.tool}">\n${await runTool(task.project_id, c)}\n</ops-result>`);
        messages.push({ role: 'assistant', content: r.text }, { role: 'user', content: results.join('\n') + '\nContinue la même mission. Garde les fichiers déjà préparés et complète-les après inspection.' });
        continue;
      }

      // Un CODER ne peut pas conclure une tâche d'implémentation par une simple description.
      if (coderTaskRequiresFiles(task) && collected.files.size === 0 && collected.patches.length === 0 && !coderFileNudgeUsed) {
        coderFileNudgeUsed = true;
        messages.push({ role: 'assistant', content: r.text }, { role: 'user', content: `LIVRABLE DE CODE MANQUANT : tu n'as encore fourni aucun <ops-file> ni <ops-patch>. Tu dois maintenant écrire réellement le code demandé. Utilise les résultats d'inspection déjà reçus, puis fournis le contenu COMPLET de chaque fichier créé ou modifié avec <ops-file path="..."></ops-file>, ou un patch exact <ops-patch path="...">[{"find":"texte exact","replace":"nouveau texte"}]</ops-patch> après lecture du fichier. Une explication, un plan, un extrait ou un pseudo-code ne valide pas cette tâche. Si tu ne peux pas coder, explique précisément le blocage sans prétendre avoir livré.` });
        continue;
      }
      final = { ...out, files: [...collected.files].map(([path, content]) => ({ path, content })), patches: collected.patches, deletes: collected.deletes, experiences: collected.experiences, requests: collected.requests, bus: collected.bus, dependencies: collected.dependencies, text: collected.text.join('\n\n'), ...providerMeta };
      break;
    }
    // Les patchs sont appliqués au contenu réellement présent dans le workspace, jamais à un fichier supposé.
    const patchPaths = new Set((final.patches || []).map((x) => x.path));
    for (const path of patchPaths) {
      if (final.files.some((f) => f.path === path)) throw new Error(`Livraison ambiguë : ${path} est fourni à la fois en fichier complet et en patch.`);
      const patchGroup = final.patches.filter((x) => x.path === path);
      let current;
      const existing = workspace.readFile(task.project_id, path);
      if (existing.binary) throw new Error(`Patch refusé : ${path} est un fichier binaire.`);
      current = existing.content;
      for (const patch of patchGroup) current = applyExactPatches(current, patch.operations);
      final.files.push({ path, content: current });
    }
    if (coderTaskRequiresFiles(task) && final.files.length === 0) {
      throw Object.assign(new Error('OPS CODER AI n’a fourni aucun fichier de code après sa relance. La tâche est marquée en échec au lieu de prétendre que le code a été écrit.'), { code: 'coder_no_artifacts' });
    }
    // Graphe d'intégration multi-fichiers : références locales et liens entre livrables/workspace.
    const workspaceFiles = workspace.tree(task.project_id).filter((e) => e.type === 'file').map((e) => e.path);
    const artifactGraph = analyzeArtifactGraph(final.files, workspaceFiles);
    const architecture = analyzeProjectArchitecture(final.files, workspaceFiles, final.files.map((f) => f.path));
    const graphReport = `\n\nGRAPHE D'INTÉGRATION OPS (${artifactGraph.summary.files} fichiers, ${artifactGraph.summary.links} liens, ${artifactGraph.summary.warnings} avertissement(s)) :\n` +
      (artifactGraph.edges.length ? artifactGraph.edges.map((e) => `- ${e.from} → ${e.to} (${e.kind})`).join('\n') : '- Aucun lien local détecté.') +
      (artifactGraph.diagnostics.length ? '\nRéférences locales à vérifier :\n' + artifactGraph.diagnostics.map((d) => `- ${d.from} importe « ${d.specifier} » mais aucune cible connue ne correspond.`).join('\n') : '') +
      `\n\n${formatArchitectureReport(architecture)}`;
    const proposals = [];
    for (const f of final.files) { const x = await recordProposal(task, 'write', f.path, f.content); proposals.push({ path: f.path, ...x }); }
    for (const d of final.deletes) { const x = await recordProposal(task, 'delete', d.path, null); proposals.push({ path: d.path, kind: 'delete', ...x }); }
    for (const m of final.memory) await db.run('INSERT INTO memory(id,project_id,agent_id,key,value,created) VALUES(?,?,?,?,?,?)', [uid('mem_'), task.project_id, task.agent_id, m.key.slice(0, 80), m.value.slice(0, 4000), now()]);
    for (const x of final.experiences || []) { if (x.lesson.length >= 35) await db.run(`INSERT INTO experience_memory(id,project_id,agent_id,domain,lesson,evidence,status,source_task,created,reviewed) VALUES(?,?,?,?,?,?,'pending',?,?,NULL)`, [uid('exp_'), task.project_id, task.agent_id, x.domain.slice(0, 80), x.lesson.slice(0, 2500), `Proposée après la tâche : ${task.title}`, task.id, now()]); }
    const collaborationWarnings = [];
    for (const e of final.bus || []) { try { await ctx.collaboration.publish(task.project_id, { type: e.type, from: task.agent_id, to: e.to, payload: e.payload }); } catch (err) { collaborationWarnings.push(`événement bus refusé : ${err.message}`); } }
    for (const d of final.dependencies || []) { try { await ctx.collaboration.addDependency(task.project_id, d.prerequisite, d.dependent, d.contract); } catch (err) { collaborationWarnings.push(`dépendance refusée : ${err.message}`); } }
    const skipped = proposals.filter((x) => x.skipped).map((x) => x.skipped);
    const fileSummary = proposals.filter((x) => x.id && x.kind !== 'delete').map((x) => x.path);
    const result = final.text + graphReport + (fileSummary.length ? `\n\nFICHIERS DE CODE LIVRÉS (${fileSummary.length}) :\n${fileSummary.map((x) => `- ${x}`).join('\n')}` : '') + (skipped.length ? `\n\n(Propositions ignorées : ${skipped.join(' ; ')})` : '') + (collaborationWarnings.length ? `\n\n(Collaboration : ${collaborationWarnings.join(' ; ')})` : '');
    await workspace.log(task.project_id, task.agent_id, 'task.done', `${task.title} — ${proposals.filter((x) => x.id).length} proposition(s) de fichier, modèle ${final.provider}/${final.model}`);
    return { result, requests: final.requests };
  }

  // ---------- planificateur / exécuteur de graphe de tâches ----------
  async function executeTasks(run, tasks, ctxInfo, signal, concurrency) {
    const byId = new Map(tasks.map((t) => [t.id, t]));
    const state = new Map(tasks.map((t) => [t.id, t.status === 'done' ? 'done' : 'pending']));
    const running = new Map();
    const extra = { n: 0 };
    const finishedFail = (t, e) => setTask(t.id, { status: 'error', error: String(e.message || e).slice(0, 500), finished: now() });

    const start = (t) => {
      state.set(t.id, 'running');
      const p = (async () => {
        for (let attempt = 1; attempt <= 2; attempt++) {
          try {
            await setTask(t.id, { status: 'running', started: now(), attempts: attempt, error: null });
            const r = await runTask(run, t, ctxInfo, signal);
            await setTask(t.id, { status: 'done', result: r.result, finished: now() });
            if (ctx.learning) await ctx.learning.captureTask({ projectId: run.project_id, agentId: t.agent_id, taskId: t.id, result: r.result, domain: t.agent_id });
            state.set(t.id, 'done');
            for (const rq of r.requests) {
              if (extra.n >= MAX_EXTRA_REQUESTS) break;
              if (!ctxInfo.p.agents.includes(rq.agent) || rq.agent === t.agent_id) continue;
              extra.n++;
              const handoff = await ctx.collaboration.createWorkItem(run.project_id, { from:t.agent_id, to:rq.agent, title:`Demande de ${t.agent_id}`, instruction:`${rq.text}\n\nContexte de sa tâche (« ${t.title} ») :\n${trunc(r.result, 3000)}` });
              const nt = await createTask(run, { agent: rq.agent, title: `Demande de ${t.agent_id}`, instruction: `Transmission OPS ${handoff.id} — accuse réception, traite la demande et publie ton résultat.\n${rq.text}\n\nContexte de sa tâche (« ${t.title} ») :\n${trunc(r.result, 3000)}`, depends_on: [] }, t.round);
              byId.set(nt.id, nt); state.set(nt.id, 'pending');
              await ctx.collaboration.updateWorkItem(handoff.id,{agentId:rq.agent,status:'accepted'});
              await workspace.log(run.project_id, t.agent_id, 'task.request', `${t.agent_id} → ${rq.agent} (${handoff.id})`);
            }
            return;
          } catch (e) {
            if (signal.aborted) { await setTask(t.id, { status: 'cancelled', finished: now() }); state.set(t.id, 'cancelled'); return; }
            const retry = attempt < 2 && !e.fatal && !['no_provider', 'no_model', 'auth', 'budget'].includes(e.code);
            if (!retry) { await finishedFail(t, e); state.set(t.id, 'error'); return; }
            await workspace.log(run.project_id, t.agent_id, 'task.retry', `${t.title} : ${e.message}`);
          }
        }
      })().finally(() => running.delete(t.id));
      running.set(t.id, p);
    };

    for (;;) {
      if (signal.aborted) break;
      let progressed = false;
      for (const t of byId.values()) {
        if (state.get(t.id) !== 'pending') continue;
        const deps = (Array.isArray(t.depends_on) ? t.depends_on : pj(t.depends_on, []));
        const depStates = deps.map((d) => state.get(d));
        if (depStates.some((s) => s === 'error' || s === 'blocked' || s === 'cancelled')) {
          state.set(t.id, 'blocked'); progressed = true;
          await setTask(t.id, { status: 'blocked', error: 'Dépendance en échec', finished: now() });
        } else if (depStates.every((s) => s === 'done') && running.size < concurrency) { start(t); progressed = true; }
      }
      if (running.size === 0 && !progressed) break;
      if (running.size) await Promise.race(running.values());
    }
    if (signal.aborted) for (const t of byId.values()) if (state.get(t.id) === 'pending') await setTask(t.id, { status: 'cancelled', finished: now() });
    await Promise.allSettled(running.values());
    return [...byId.values()].map((t) => ({ id: t.id, state: state.get(t.id) }));
  }

  // ---------- phases ----------
  async function plan(run, ctxInfo, signal) {
    const allowed = WORKER_IDS.filter((a) => ctxInfo.p.agents.includes(a));
    if (!allowed.length) throw new HttpError(400, 'Aucun agent de développement affecté à ce projet');
    const isNewGame = /\b(créer|creer|crée|cree|développer|developper|fabriquer|construire|build|make)\b.{0,70}\b(jeu|game|jeu vidéo|jeu 3d|jeu mobile)\b|\b(nouveau|nouvelle)\s+(jeu|game)\b/i.test(run.instruction);
    if (isNewGame) return newGamePlan(run.instruction, allowed);
    const coord = await getAgent('coordinator');
    const neuralAnalysis = analyzeNeuralRequest(run.instruction, ctxInfo.p.agents);
    const prompt = `ANALYSE NEURONALE PRÉALABLE :\n${JSON.stringify(neuralAnalysis, null, 2)}\nUtilise les spécialistes recommandés lorsque cela apporte une vraie valeur ; couvre les risques sans multiplier inutilement les tâches. Pour tout projet de JEU ou demande de programmation, si ces agents sont disponibles, planifie explicitement OPS CODER AI comme responsable de l'implémentation et de l'assemblage, ainsi que OPS NPC ENGINE AI, OPS PHYSICS ENGINE AI et l'agent moteur 3D pertinent. Leurs livrables doivent être du code dans le projet de jeu, importé/appelé depuis le point d'entrée ou un bootstrap réellement relié au Game Loop ; un rapport seul ne suffit pas. Coordonne les contrats d'API entre eux et avec GAMEPLAY/ANIMATION.\n\nProjet actif : ${ctxInfo.p.name} — ${ctxInfo.p.description || ''}
Fichiers existants : ${ctxInfo.tree.slice(0, 40).join(', ') || '(aucun)'}
Agents disponibles (id : rôle) :
${allowed.map((a) => `- ${a}`).join('\n')}

DEMANDE : ${run.instruction}

Réponds UNIQUEMENT par un objet JSON :
{"summary":"phrase","subtasks":[{"id":"t1","title":"titre court","agent":"id_agent","instruction":"consigne autonome et précise","depends_on":[]}]}
Règles : 1 à 8 sous-tâches ; agent ∈ liste ci-dessus ; mets depends_on seulement si une tâche a vraiment besoin du résultat d'une autre (sinon vide pour travailler en parallèle) ; la relecture qualité est automatique, ne la planifie pas.`;
    let lastErr;
    for (let i = 0; i < 2; i++) {
      try {
        const r = await providers.chat(coord, [{ role: 'system', content: systemPromptFor(coord) }, { role: 'user', content: prompt + (lastErr ? `\n\nTa réponse précédente était invalide (${lastErr}). Corrige.` : '') }], { signal });
        const parsed = extractJson(r.text);
        return { summary: parsed?.summary || '', subtasks: validatePlan(parsed, allowed), by_rules: false };
      } catch (e) {
        if (signal.aborted) throw e;
        lastErr = e.message;
        if (['no_provider', 'no_model', 'auth', 'budget', 'network', 'timeout'].includes(e.code)) break;
      }
    }
    const rp = rulePlan(run.instruction, allowed);
    rp.summary += ` Raison : ${lastErr}`;
    return rp;
  }

  async function review(run, tasks, signal) {
    // L'audit final est confié à un agent indépendant, après la fin des tâches.
    const q = await getAgent('quality');
    const done = tasks.filter((t) => t.status === 'done');
    const conflicts = await db.all("SELECT path, COUNT(DISTINCT agent_id) AS n FROM approvals WHERE run_id=? AND status='pending' AND kind='write' GROUP BY path HAVING COUNT(*)>1", [run.id]);
    const conflictList = [];
    for (const c of conflicts) {
      const rows = await db.all("SELECT agent_id, task_id, content FROM approvals WHERE run_id=? AND path=? AND status='pending' AND kind='write'", [run.id, c.path]);
      if (new Set(rows.map((r) => r.content)).size > 1) conflictList.push({ path: c.path, rows });
    }
    const issues = [];
    for (const c of conflictList) issues.push({ source: 'détection automatique', task_id: c.rows[0].task_id, agent: c.rows[0].agent_id, problem: `Contradiction : ${c.rows.map((r) => r.agent_id).join(' et ')} proposent deux versions différentes de « ${c.path} ».`, fix: `Fusionne les deux versions de ${c.path} en une seule en conservant toutes les fonctionnalités.`, conflict: c });
    if (!done.length) return { available: false, verdict: 'non évalué', issues, note: 'Aucune tâche terminée à auditer.' };
    const proposals = await db.all("SELECT id,task_id,agent_id,kind,path,status,content FROM approvals WHERE run_id=? AND status IN ('pending','approved') ORDER BY created", [run.id]);
    const proposalText = proposals.map((p) => `### ${p.kind} ${p.path} — ${p.agent_id} — ${p.status} — tâche ${p.task_id}\n${trunc(p.content || '(pas de contenu)', 9000)}`).join('\n\n');
    const prompt = `Relis de façon critique et réalise l'AUDIT FINAL OBLIGATOIRE — OPS NEURAL SUPERVISOR.\n\nTu interviens seulement maintenant : tous les agents ont terminé leur travail ou signalé leur échec. Demande utilisateur : « ${run.instruction} ».\n\nRÉSULTATS DE TOUS LES AGENTS :\n${done.map((t) => `### ${t.id} — ${t.agent_id} — ${t.title}\n${trunc(t.result, 4500)}`).join('\n\n')}\n\nFICHIERS ET CHANGEMENTS PROPOSÉS (inspecte le contenu, pas seulement les titres) :\n${proposalText || '(aucun fichier proposé)'}\n\nRéalise un audit multi-axes : 1) conformité exacte à la demande et fonctionnalités antérieures préservées ; 2) cohérence entre agents et fichiers ; 3) erreurs logiques/techniques visibles dans le contenu ; 4) sécurité et gestion des erreurs ; 5) performances/mobile si pertinent ; 6) tests réellement présents et preuves disponibles ; 7) éléments annoncés mais absents ; 8) niveau de détail suffisant pour une implémentation réelle ; 9) finition, cohérence UX, cas limites et critères d'acceptation ; 10) pistes d'amélioration concrètes. Vérifie aussi les propositions de suppression. Évalue comme une revue de production d'un jeu commercial, sans prétendre certifier un niveau AAA.\n\nNe prétends pas avoir exécuté le code ou des tests si aucun outil ne l'a fait. Distingue constat prouvé, risque probable et point impossible à vérifier. Ne fabrique pas de problème. Pour chaque problème corrigeable, donne le task_id exact de l'agent responsable et une consigne de correction exploitable. Si aucun problème démontrable : issues [].\n\nRéponds UNIQUEMENT en JSON : {"verdict":"ok"|"problemes","summary":"bilan précis","issues":[{"task_id":"id exact","problem":"constat et preuve","fix":"correction concrète"}],"unverified":["points non vérifiés"]}.`;
    try {
      const r = await providers.chat(q, [{ role: 'system', content: systemPromptFor(q) }, { role: 'user', content: prompt }], { signal });
      const parsed = extractJson(r.text);
      if (!parsed) return { available: false, verdict: 'non évalué', issues, note: 'Réponse du superviseur illisible (JSON attendu).' };
      for (const i of (parsed.issues || [])) {
        const t = done.find((x) => x.id === i.task_id);
        if (t && String(i.problem || '').trim() && String(i.fix || '').trim()) issues.push({ source: 'OPS NEURAL SUPERVISOR', task_id: t.id, agent: t.agent_id, problem: String(i.problem), fix: String(i.fix) });
      }
      return { available: true, verdict: issues.length ? 'problèmes' : 'ok', summary: parsed.summary || '', issues, unverified: Array.isArray(parsed.unverified) ? parsed.unverified.slice(0, 20) : [] };
    } catch (e) {
      if (signal.aborted) throw e;
      return { available: false, verdict: 'non évalué', issues, note: `Audit final impossible : ${e.message}` };
    }
  }

  async function mergeReport(run, ctxInfo, tasks, reviews, signal) {
    const coord = await getAgent('coordinator');
    const props = await db.all("SELECT id,agent_id,kind,path,status FROM approvals WHERE run_id=? AND status IN ('pending','approved')", [run.id]);
    const header = tasks.map((t) => `- ${t.agent_id} · ${t.title} : ${t.status}${t.error ? ' (' + t.error + ')' : ''}`).join('\n');
    const prompt = `Rédige le rapport final destiné à l'utilisateur pour : « ${run.instruction} ».\nRésultats des agents :\n${tasks.filter((t) => t.status === 'done').map((t) => `### ${t.agent_id} — ${t.title}\n${trunc(t.result, 3000)}`).join('\n\n')}\n\nRelecture qualité : ${j(reviews.map((r) => ({ verdict: r.verdict, issues: r.issues.map((i) => i.problem), note: r.note })))}\nFichiers proposés : ${props.map((p) => `${p.kind} ${p.path}`).join(', ') || 'aucun'}\n\nRapport en markdown : synthèse, livrables, points non résolus, prochaines étapes. N'affirme rien qui ne figure pas dans les résultats ci-dessus.`;
    let body;
    try {
      const r = await providers.chat(coord, [{ role: 'system', content: systemPromptFor(coord) }, { role: 'user', content: prompt }], { signal });
      body = parseAgentOutput(r.text).text;
    } catch (e) {
      if (signal.aborted) throw e;
      body = `*(Synthèse IA indisponible : ${e.message} — assemblage direct des résultats.)*\n\n` + tasks.filter((t) => t.status === 'done').map((t) => `### ${t.agent_id} — ${t.title}\n${t.result}`).join('\n\n');
    }
    const rev = reviews.length ? reviews[reviews.length - 1] : null;
    const gate = neuralQualityChecklist({ tasks, files: props, risks: analyzeNeuralRequest(run.instruction).risks });
    const footer = [
      '\n---\n**OPS NEURAL QUALITY GATE**', `Couverture déterministe : ${gate.score}%`, ...gate.checks.map((c) => `- ${c.evidence ? 'Contrôle renseigné' : 'À compléter'} — ${c.label}`),
      '\n**État de l\'exécution**', header,
      `\n**Relecture croisée** : ${rev ? (rev.available ? `verdict « ${rev.verdict} »` : `non réalisée — ${rev.note}`) : 'non réalisée'}${rev?.issues?.length ? '\n' + rev.issues.map((i) => `- (${i.agent}) ${i.problem}`).join('\n') : ''}`,
      `\n**Fichiers en attente d'autorisation** : ${props.filter((p) => p.status === 'pending').length}`,
    ].join('\n');
    return body + '\n' + footer;
  }

  async function executeTeamRun(run, signal) {
    const ctxInfo = await projectContext(run.project_id);
    const concurrency = Math.max(1, Number(await setting('concurrency', 3)));
    const maxCorr = Math.max(0, Math.min(5, Number(await setting('max_correction_rounds', 4))));
    await setRun(run.id, { status: 'planning' });
    const pl = await plan(run, ctxInfo, signal);
    await setRun(run.id, { plan: pl, status: 'running' });
    await workspace.log(run.project_id, 'coordinator', 'run.plan', `${pl.subtasks.length} sous-tâches${pl.by_rules ? ' (plan par règles)' : ''}`);
    const idMap = new Map();
    const tasks = [];
    for (const s of pl.subtasks) {
      const t = await createTask(run, { ...s, depends_on: [] }, 0);
      idMap.set(s.id, t.id); tasks.push({ ...t, _deps: s.depends_on });
    }
    for (const t of tasks) { t.depends_on = t._deps.map((d) => idMap.get(d)); await db.run('UPDATE tasks SET depends_on=? WHERE id=?', [j(t.depends_on), t.id]); }
    if (run.autosnapshot !== false && ctxInfo.p.write_mode === 'auto') await workspace.createVersion(run.project_id, { label: `Avant exécution ${run.id}`, reason: 'avant run auto' });
    await executeTasks(run, tasks, ctxInfo, signal, concurrency);

    const reviews = [];
    for (let round = 0; round <= maxCorr; round++) {
      if (signal.aborted) break;
      await setRun(run.id, { status: 'reviewing' });
      const all = await db.all('SELECT * FROM tasks WHERE run_id=? ORDER BY created', [run.id]);
      const rv = await review(run, all, signal);
      reviews.push(rv);
      if (!rv.issues.length || round === maxCorr) break;
      await setRun(run.id, { status: 'correcting' });
      const fixes = [];
      for (const issue of rv.issues.slice(0, 6)) {
        const orig = all.find((t) => t.id === issue.task_id);
        let extra = '';
        if (issue.conflict) extra = '\n\nVersions en conflit :\n' + issue.conflict.rows.map((r) => `--- version de ${r.agent_id} ---\n${trunc(r.content, 8000)}`).join('\n');
        fixes.push(await createTask(run, { agent: issue.agent, title: `Correction : ${String(issue.problem).replace(/\s+/g, ' ').slice(0, 70)}`, instruction: `Une relecture croisée a relevé un problème dans ton travail (« ${orig?.title || ''} ») :\n${issue.problem}\nCorrection attendue : ${issue.fix}\n\nTon résultat précédent :\n${trunc(orig?.result, 3000)}${extra}\n\nLivre la version corrigée complète (<ops-file> pour chaque fichier concerné).`, depends_on: [] }, round + 1));
      }
      await executeTasks(run, fixes, ctxInfo, signal, concurrency);
    }
    if (signal.aborted) throw new Error('aborted');
    await setRun(run.id, { status: 'merging' });
    const finalTasks = await db.all('SELECT * FROM tasks WHERE run_id=? ORDER BY created', [run.id]);
    const report = await mergeReport(run, ctxInfo, finalTasks, reviews, signal);
    // mode auto : application des propositions sans conflit (sauvegarde déjà faite, tout est annulable) ; suppressions : jamais sans autorisation
    if (ctxInfo.p.write_mode === 'auto') {
      const pend = await db.all("SELECT id,path FROM approvals WHERE run_id=? AND status='pending' AND kind='write' ORDER BY created", [run.id]);
      const count = pend.reduce((m, a) => m.set(a.path, (m.get(a.path) || 0) + 1), new Map());
      for (const a of pend) if (count.get(a.path) === 1) await approve(a.id, { actor: 'auto' });
    }
    const failed = finalTasks.filter((t) => ['error', 'blocked'].includes(t.status));
    const status = finalTasks.every((t) => t.status === 'error' || t.status === 'blocked') ? 'failed' : failed.length ? 'partial' : 'done';
    return { report, status };
  }

  async function executeAgentRun(run, signal) {
    const ctxInfo = await projectContext(run.project_id);
    const math = extractMathExpression(run.instruction);
    if (math) {
      const report = `OPS NEURAL MATH — calcul vérifié\n\n${math.expression} = **${math.fraction}** (≈ ${math.exact})\n\nRésultat calculé localement par le moteur arithmétique OPS, sans recherche web.`;
      await addMessage(run.project_id, run.id, run.agent_id, 'assistant', report);
      return { report, status: 'done' };
    }
    await setRun(run.id, { status: 'running', plan: { summary: 'Conversation directe', subtasks: [{ id: 't1', agent: run.agent_id, title: 'Réponse directe' }] } });
    const t = await createTask(run, { agent: run.agent_id, title: 'Réponse directe', instruction: run.instruction, depends_on: [] }, 0);
    if (ctxInfo.p.write_mode === 'auto') await workspace.createVersion(run.project_id, { label: `Avant exécution directe ${run.id}`, reason: 'avant run auto' });
    await executeTasks(run, [t], ctxInfo, signal, 1);
    const row = await db.get('SELECT * FROM tasks WHERE id=?', [t.id]);
    if (row.status !== 'done') throw new Error(row.error || row.status);
    // Le chat direct doit respecter le même contrat d'écriture que le mode équipe.
    // Les fichiers sont appliqués avec sauvegarde ; les suppressions restent toujours manuelles.
    if (ctxInfo.p.write_mode === 'auto') {
      const pend = await db.all("SELECT id,path FROM approvals WHERE run_id=? AND status='pending' AND kind='write' ORDER BY created", [run.id]);
      const count = pend.reduce((m, a) => m.set(a.path, (m.get(a.path) || 0) + 1), new Map());
      for (const a of pend) if (count.get(a.path) === 1) await approve(a.id, { actor: 'auto' });
    }
    return { report: row.result, status: 'done' };
  }

  async function start({ projectId, instruction, mode = 'team', agentId = null }) {
    instruction = String(instruction || '').trim();
    if (!instruction) throw new HttpError(400, 'Message vide');
    if (instruction.length > 20000) throw new HttpError(413, 'Message trop long');
    const p = await workspace.getProject(projectId);
    if (mode === 'agent') {
      const a = await getAgent(agentId);
      if (!a || !a.enabled) throw new HttpError(400, 'Agent inconnu ou désactivé');
    }
    const run = { id: uid('run_'), project_id: p.id, instruction, mode, agent_id: agentId, created: now() };
    await db.run('INSERT INTO runs(id,project_id,instruction,mode,status,plan,report,error,created,finished) VALUES(?,?,?,?,?,NULL,NULL,NULL,?,NULL)', [run.id, p.id, instruction, mode, 'planning', run.created]);
    await addMessage(p.id, run.id, mode === 'agent' ? agentId : null, 'user', instruction);
    if (mode === 'agent') {
      const hist = await db.all("SELECT role,content FROM messages WHERE project_id=? AND agent_id=? AND run_id<>? ORDER BY created DESC LIMIT 8", [p.id, agentId, run.id]);
      run.history = hist.reverse().map((m) => ({ role: m.role === 'user' ? 'user' : 'assistant', content: trunc(m.content, 3000) }));
    }
    const ac = new AbortController();
    active.set(run.id, ac);
    (async () => {
      try {
        const r = mode === 'agent' ? await executeAgentRun(run, ac.signal) : await executeTeamRun(run, ac.signal);
        await db.run('UPDATE runs SET report=? WHERE id=?', [r.report, run.id]);
        await addMessage(p.id, run.id, mode === 'agent' ? agentId : 'coordinator', 'assistant', r.report);
        await setRun(run.id, { status: r.status, finished: now() });
      } catch (e) {
        const cancelled = ac.signal.aborted;
        const msg = cancelled ? 'Exécution annulée par l\'utilisateur.' : `Échec : ${e.message}`;
        await db.run('UPDATE runs SET error=?, report=? WHERE id=?', [msg, msg, run.id]);
        await addMessage(p.id, run.id, mode === 'agent' ? agentId : 'coordinator', 'assistant', msg);
        await setRun(run.id, { status: cancelled ? 'cancelled' : 'failed', finished: now() });
        await workspace.log(p.id, 'system', cancelled ? 'run.cancel' : 'run.fail', e.message);
      } finally { active.delete(run.id); }
    })();
    return run.id;
  }

  return {
    start, approve, reject,
    cancel(runId) { const ac = active.get(runId); if (!ac) throw new HttpError(404, 'Exécution non active'); ac.abort(); return { ok: true }; },
    isActive: (id) => active.has(id),
    activeCount: () => active.size,
    async getRun(id) {
      const r = await db.get('SELECT * FROM runs WHERE id=?', [id]);
      if (!r) throw new HttpError(404, 'Exécution introuvable');
      const tasks = await db.all('SELECT * FROM tasks WHERE run_id=? ORDER BY created', [id]);
      return { ...r, plan: pj(r.plan), tasks: tasks.map((t) => ({ ...t, depends_on: pj(t.depends_on, []) })), active: active.has(id) };
    },
    async listRuns(pid, limit = 50) {
      return db.all(`SELECT id,project_id,instruction,mode,status,error,created,finished FROM runs ${pid ? 'WHERE project_id=?' : ''} ORDER BY created DESC LIMIT ?`, pid ? [pid, limit] : [limit]);
    },
    /** Relance les tâches en erreur/bloquées/en attente d'une exécution interrompue (déclenchée par l'utilisateur ou l'automatisation). */
    async resume(runId) {
      const run = await db.get('SELECT * FROM runs WHERE id=?', [runId]);
      if (!run) throw new HttpError(404, 'Exécution introuvable');
      if (active.has(runId)) throw new HttpError(409, 'Exécution déjà en cours');
      const todo = await db.all("SELECT * FROM tasks WHERE run_id=? AND status IN ('error','blocked','pending','running','cancelled')", [runId]);
      if (!todo.length) throw new HttpError(409, 'Rien à relancer');
      const ac = new AbortController(); active.set(runId, ac);
      const r = { ...run, id: runId };
      (async () => {
        try {
          const ctxInfo = await projectContext(run.project_id);
          await setRun(runId, { status: 'running', error: null, finished: null });
          for (const t of todo) await db.run("UPDATE tasks SET status='pending', error=NULL WHERE id=?", [t.id]);
          const all = await db.all('SELECT * FROM tasks WHERE run_id=?', [runId]);
          const tasks = all.map((t) => ({ ...t, depends_on: pj(t.depends_on, []) }));
          await executeTasks(r, tasks, ctxInfo, ac.signal, Math.max(1, Number(await setting('concurrency', 3))));
          const fin = await db.all('SELECT status FROM tasks WHERE run_id=?', [runId]);
          const bad = fin.filter((t) => ['error', 'blocked', 'cancelled'].includes(t.status)).length;
          await setRun(runId, { status: bad ? (bad === fin.length ? 'failed' : 'partial') : 'done', finished: now() });
        } catch (e) { await setRun(runId, { status: ac.signal.aborted ? 'cancelled' : 'failed', error: e.message, finished: now() }); }
        finally { active.delete(runId); }
      })();
      return { ok: true, relaunched: todo.length };
    },
    async recoverInterrupted() {
      const rows = await db.all("SELECT id FROM runs WHERE status IN ('planning','running','reviewing','correcting','merging')");
      for (const r of rows) { await db.run("UPDATE runs SET status='interrupted', error='Serveur redémarré pendant l''exécution' WHERE id=?", [r.id]); await db.run("UPDATE tasks SET status='error', error='Interrompu (redémarrage)' WHERE run_id=? AND status IN ('running')", [r.id]); }
      return rows.length;
    },
  };
}
export { ALL_AGENT_IDS };
