import path from 'node:path';
import { uid, now, j, HttpError } from './util.mjs';

const HTML_EXT = new Set(['.html', '.htm']);
const CSS_EXT = new Set(['.css']);
const GAME_HINT = /three\.js|babylon|webgl|<canvas|requestAnimationFrame|renderer\.render|game loop|game-loop/i;

/** Audit visuel statique et non intrusif. Il inspecte les sources sans exécuter le jeu ni prétendre produire une capture d'écran. */
export function createVisualTesting(ctx) {
  const { db, workspace } = ctx;

  async function run(pid, options = {}) {
    await workspace.getProject(pid);
    const files = workspace.filesIn(workspace.wdir(pid));
    const htmlFiles = files.filter(f => HTML_EXT.has(path.extname(f.rel).toLowerCase()));
    const cssFiles = files.filter(f => CSS_EXT.has(path.extname(f.rel).toLowerCase()));
    const jsFiles = files.filter(f => /\.(?:js|mjs|cjs|ts|tsx|jsx)$/i.test(f.rel));
    const findings = [];
    const add = (severity, code, message, evidence = []) => findings.push({ severity, code, message, evidence: evidence.slice(0, 8) });
    const read = (f) => {
      try { return workspace.readFile(pid, f.rel, { maxBytes: 2 * 1024 * 1024 }).content || ''; }
      catch { return ''; }
    };
    const html = htmlFiles.map(read).join('\n');
    const css = cssFiles.map(read).join('\n');
    const js = jsFiles.map(read).join('\n');
    const combined = `${html}\n${css}\n${js}`;
    const gameLike = GAME_HINT.test(combined);

    if (!htmlFiles.length) add('warning', 'html-entry-missing', 'Aucun fichier HTML trouvé : impossible d’auditer la structure visuelle de l’interface.', []);
    if (htmlFiles.length && !/<meta\s+[^>]*name=["']viewport["']/i.test(html)) add('error', 'viewport-missing', 'Balise viewport absente : l’interface risque d’être mal dimensionnée sur mobile.', htmlFiles.map(x => x.rel));
    if (htmlFiles.length && !/<title(?:\s|>)/i.test(html)) add('info', 'document-title-missing', 'Titre HTML absent : ajoute un titre explicite pour identifier la page.', htmlFiles.map(x => x.rel));
    if (gameLike && !/<canvas\b/i.test(html) && !/document\.createElement\(['"]canvas['"]\)/i.test(js)) add('warning', 'game-canvas-not-detected', 'Le projet semble utiliser un moteur 3D ou une boucle de jeu, mais aucun canvas n’a été détecté dans les sources inspectées.', [...htmlFiles, ...jsFiles].slice(0, 8).map(x => x.rel));
    if (gameLike && !/(?:addEventListener\s*\(\s*['"]resize|ResizeObserver|setSize\s*\()/i.test(combined)) add('warning', 'resize-handling-not-detected', 'Aucune gestion de redimensionnement détectée : vérifier l’adaptation du rendu lors d’une rotation ou d’un changement de taille.', [...htmlFiles, ...cssFiles, ...jsFiles].slice(0, 8).map(x => x.rel));
    if (gameLike && !/(?:touchstart|pointerdown|touch-action|PointerEvent)/i.test(combined)) add('warning', 'touch-input-not-detected', 'Aucune entrée tactile/pointeur détectée : les commandes mobiles doivent être vérifiées.', [...htmlFiles, ...cssFiles, ...jsFiles].slice(0, 8).map(x => x.rel));
    if (gameLike && !/(?:requestAnimationFrame|setAnimationLoop)/i.test(js)) add('warning', 'render-loop-not-detected', 'Aucune boucle de rendu reconnue dans les fichiers JavaScript inspectés.', jsFiles.slice(0, 8).map(x => x.rel));
    if (htmlFiles.length && !/(?:<main\b|role=["']main["'])/i.test(html)) add('info', 'main-landmark-missing', 'Zone principale sémantique non détectée : envisager <main> ou role="main".', htmlFiles.map(x => x.rel));
    if (htmlFiles.length && !/(?:aria-label|aria-labelledby|<label\b)/i.test(html)) add('info', 'control-labels-not-detected', 'Aucun libellé accessible détecté dans le HTML : vérifier les boutons et commandes du jeu.', htmlFiles.map(x => x.rel));
    if (/(?:overflow\s*:\s*hidden)/i.test(css) && !/(?:overflow\s*:\s*auto|overflow-y\s*:\s*auto)/i.test(css)) add('info', 'global-overflow-hidden', 'Un overflow:hidden est présent sans zone défilante reconnue : vérifier que les menus et panneaux restent accessibles sur petit écran.', cssFiles.map(x => x.rel));
    if (/(?:width\s*:\s*\d{3,}px|height\s*:\s*\d{3,}px)/i.test(css) && !/(?:@media|clamp\s*\(|min\(|max\()/i.test(css)) add('warning', 'fixed-large-dimensions', 'Des dimensions fixes importantes sont détectées sans règle responsive évidente.', cssFiles.map(x => x.rel));
    if (/(?:TODO|FIXME|PLACEHOLDER)/i.test(combined)) add('info', 'unfinished-markers', 'Des marqueurs TODO/FIXME/PLACEHOLDER restent présents dans les sources.', files.filter(f => /\.(?:html?|css|js|mjs|ts|tsx|jsx)$/i.test(f.rel)).filter(f => /(?:TODO|FIXME|PLACEHOLDER)/i.test(read(f))).slice(0, 8).map(x => x.rel));

    const errors = findings.filter(x => x.severity === 'error').length;
    const warnings = findings.filter(x => x.severity === 'warning').length;
    const score = Math.max(0, 100 - errors * 22 - warnings * 9 - findings.filter(x => x.severity === 'info').length * 2);
    const summary = {
      score, files_scanned: files.length, html_files: htmlFiles.length, css_files: cssFiles.length,
      script_files: jsFiles.length, game_like_project: gameLike, findings: findings.length,
      errors, warnings, information: findings.length - errors - warnings,
      method: 'static-source-audit', screenshot_captured: false,
    };
    const id = uid('vis_');
    const passed = errors === 0;
    await db.run('INSERT INTO test_reports(id,project_id,ts,kind,passed,summary,detail) VALUES(?,?,?,?,?,?,?)', [id, pid, now(), 'visual-static', passed ? 1 : 0, j(summary), j({ findings, inspected: [...htmlFiles, ...cssFiles, ...jsFiles].map(x => x.rel) })]);
    await workspace.log(pid, 'system', 'tests.visual-static', `${score}/100, ${errors} erreur(s), ${warnings} avertissement(s)`);
    ctx.events?.emit('visual-tests', { project_id: pid, id, passed, score });
    return { id, passed, summary, findings, inspected: [...htmlFiles, ...cssFiles, ...jsFiles].map(x => x.rel), limitations: ['Analyse statique des sources uniquement.', 'Aucune capture d’écran ni exécution du moteur graphique dans cette version.', 'Le score est un indicateur heuristique, pas une mesure de qualité artistique.'] };
  }

  return {
    run,
    async reports(pid, limit = 20) {
      await workspace.getProject(pid);
      const rows = await db.all("SELECT * FROM test_reports WHERE project_id=? AND kind='visual-static' ORDER BY ts DESC LIMIT ?", [pid, Math.max(1, Math.min(100, Number(limit) || 20))]);
      return rows.map(r => ({ ...r, passed: !!r.passed, summary: JSON.parse(r.summary), detail: JSON.parse(r.detail) }));
    },
  };
}
