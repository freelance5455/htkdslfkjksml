/** OPS V6 Release Manifest: empreinte vérifiable du workspace, sans exécuter le code livré. */
import fs from 'node:fs';
import crypto from 'node:crypto';
import { HttpError } from './util.mjs';

const MAX_FILES = 5000;
const MAX_TOTAL_BYTES = 200 * 1024 * 1024;
const SECRET_NAME = /(^|\/)(\.env|\.env\.[^.]+|id_rsa|id_ed25519|credentials\.json|service-account\.json)$/i;
const ENTRY = /(^|\/)(index\.html|package\.json|src\/(main|index)\.[cm]?[jt]sx?|main\.[cm]?[jt]sx?)$/i;
const LOCK = /(^|\/)(package-lock\.json|pnpm-lock\.yaml|yarn\.lock|bun\.lockb?)$/i;

function digest(buf) { return crypto.createHash('sha256').update(buf).digest('hex'); }

export function buildReleaseManifest({ project, files = [], readBytes }) {
  if (!project) throw new HttpError(404, 'Projet introuvable');
  const rows = files.filter(f => f.type === 'file').slice(0, MAX_FILES);
  if (files.filter(f => f.type === 'file').length > MAX_FILES) throw new HttpError(413, 'Trop de fichiers pour établir le manifeste');
  let total = 0;
  const entries = [];
  const findings = [];
  for (const f of rows) {
    const size = Number(f.size || 0);
    total += size;
    if (!Number.isSafeInteger(size) || size < 0) throw new HttpError(400, `Taille de fichier invalide : ${f.path}`);
    if (total > MAX_TOTAL_BYTES) throw new HttpError(413, 'Workspace supérieur à 200 Mo : manifeste interrompu');
    const bytes = readBytes(f.path);
    if (!Buffer.isBuffer(bytes)) throw new HttpError(500, `Lecture impossible : ${f.path}`);
    if (bytes.length !== size) findings.push({ code: 'size-mismatch', path: f.path, severity: 'block', detail: 'La taille lue diffère de celle de l’inventaire.' });
    const text = bytes.subarray(0, 8192).toString('utf8');
    if (SECRET_NAME.test(f.path) && !/\.example$/i.test(f.path)) findings.push({ code: 'secret-file', path: f.path, severity: 'block', detail: 'Nom de fichier potentiellement sensible ; vérifier avant partage.' });
    if (/-----BEGIN (RSA |EC |OPENSSH )?PRIVATE KEY-----/.test(text)) findings.push({ code: 'private-key', path: f.path, severity: 'block', detail: 'Une clé privée semble présente dans ce fichier.' });
    if (/\b(?:OPENAI|ANTHROPIC|GEMINI|AWS|GITHUB)_?(?:API_)?KEY\s*=\s*['"]?(?!your_|replace_|changeme)[A-Za-z0-9_\-]{16,}/i.test(text)) findings.push({ code: 'possible-api-secret', path: f.path, severity: 'block', detail: 'Une valeur ressemblant à un secret est détectée.' });
    entries.push({ path: f.path, size, sha256: digest(bytes), extension: f.path.includes('.') ? f.path.split('.').pop().toLowerCase() : '' });
  }
  entries.sort((a,b) => a.path.localeCompare(b.path));
  const entrypoints = entries.filter(f => ENTRY.test(f.path)).map(f => f.path);
  const locks = entries.filter(f => LOCK.test(f.path)).map(f => f.path);
  const hasReadme = entries.some(f => /(^|\/)README(?:\.md|\.txt)?$/i.test(f.path));
  if (!entrypoints.length) findings.push({ code: 'missing-entrypoint', path: null, severity: 'review', detail: 'Aucun point d’entrée HTML/JavaScript reconnu.' });
  if (!hasReadme) findings.push({ code: 'missing-readme', path: null, severity: 'review', detail: 'Aucun README détecté.' });
  const canonical = entries.map(f => `${f.sha256}  ${f.path}`).join('\n');
  const blocked = findings.some(f => f.severity === 'block');
  const review = findings.some(f => f.severity === 'review');
  return {
    schema: 'ops.release-manifest.v1', generated_at: new Date().toISOString(),
    project: { id: project.id, name: project.name },
    status: blocked ? 'blocked' : review ? 'review' : 'ready',
    integrity: { algorithm: 'SHA-256', root_sha256: digest(Buffer.from(canonical)), files: entries.length, total_bytes: total },
    entrypoints, lockfiles: locks, files: entries, findings,
    limitations: [
      'Le manifeste prouve l’empreinte des fichiers au moment de sa création, pas leur qualité fonctionnelle.',
      'Aucun script du projet n’est exécuté par ce contrôle.',
      'Les fichiers peuvent changer après la génération : recalculer le manifeste avant toute livraison.'
    ]
  };
}

export function createReleaseManifest(ctx) {
  return {
    async report(projectId) {
      const project = await ctx.workspace.getProject(projectId);
      const files = ctx.workspace.tree(projectId);
      return buildReleaseManifest({ project, files, readBytes: rel => {
        const { abs } = ctx.workspace.safePath(projectId, rel);
        try { return fs.readFileSync(abs); } catch { throw new HttpError(404, `Fichier introuvable : ${rel}`); }
      }});
    },
    async snapshot(projectId, label = 'Manifeste de livraison V6') {
      const manifest = await this.report(projectId);
      if (manifest.status === 'blocked') throw new HttpError(409, 'Manifeste bloqué : corrigez les éléments sensibles avant de créer le snapshot.', 'release_blocked');
      const version = await ctx.workspace.createVersion(projectId, { label: String(label).slice(0, 120), reason: 'release-manifest' });
      await ctx.workspace.log(projectId, 'system', 'release.manifest.snapshot', { version_id: version.id, root_sha256: manifest.integrity.root_sha256, status: manifest.status });
      return { ...manifest, snapshot: version };
    }
  };
}
