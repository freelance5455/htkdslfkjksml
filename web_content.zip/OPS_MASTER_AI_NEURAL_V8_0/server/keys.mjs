import crypto from 'node:crypto';

/** Chiffrement AES-256-GCM des clés API au repos. La clé maître reste sur le serveur (data/.secret ou OPS_SECRET). */
const keyOf = (secret) => crypto.createHash('sha256').update('ops-keys:' + secret).digest();

export function encrypt(secret, plain) {
  if (!plain) return '';
  const iv = crypto.randomBytes(12);
  const c = crypto.createCipheriv('aes-256-gcm', keyOf(secret), iv);
  const ct = Buffer.concat([c.update(String(plain), 'utf8'), c.final()]);
  return Buffer.concat([iv, c.getAuthTag(), ct]).toString('base64');
}

export function decrypt(secret, blob) {
  if (!blob) return '';
  const b = Buffer.from(blob, 'base64');
  const d = crypto.createDecipheriv('aes-256-gcm', keyOf(secret), b.subarray(0, 12));
  d.setAuthTag(b.subarray(12, 28));
  return Buffer.concat([d.update(b.subarray(28)), d.final()]).toString('utf8');
}

export const hint = (k) => (k ? '••••' + String(k).slice(-4) : '');
