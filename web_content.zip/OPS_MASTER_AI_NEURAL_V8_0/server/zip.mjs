import zlib from 'node:zlib';
import fs from 'node:fs';

/** Écriture ZIP minimale (deflate) sans dépendance. files: [{name, data:Buffer}] */
export function makeZip(files) {
  const parts = [], central = [];
  let offset = 0;
  for (const f of files) {
    const name = Buffer.from(f.name.replace(/\\/g, '/'), 'utf8');
    const raw = f.data;
    const comp = zlib.deflateRawSync(raw);
    const useDeflate = comp.length < raw.length;
    const data = useDeflate ? comp : raw;
    const crc = zlib.crc32(raw) >>> 0;
    const method = useDeflate ? 8 : 0;
    const lh = Buffer.alloc(30);
    lh.writeUInt32LE(0x04034b50, 0); lh.writeUInt16LE(20, 4); lh.writeUInt16LE(0x0800, 6); lh.writeUInt16LE(method, 8);
    lh.writeUInt16LE(0, 10); lh.writeUInt16LE(0x21, 12); lh.writeUInt32LE(crc, 14); lh.writeUInt32LE(data.length, 18); lh.writeUInt32LE(raw.length, 22);
    lh.writeUInt16LE(name.length, 26); lh.writeUInt16LE(0, 28);
    parts.push(lh, name, data);
    const ch = Buffer.alloc(46);
    ch.writeUInt32LE(0x02014b50, 0); ch.writeUInt16LE(20, 4); ch.writeUInt16LE(20, 6); ch.writeUInt16LE(0x0800, 8); ch.writeUInt16LE(method, 10);
    ch.writeUInt16LE(0, 12); ch.writeUInt16LE(0x21, 14); ch.writeUInt32LE(crc, 16); ch.writeUInt32LE(data.length, 20); ch.writeUInt32LE(raw.length, 24);
    ch.writeUInt16LE(name.length, 28); ch.writeUInt32LE(offset, 42);
    central.push(ch, name);
    offset += lh.length + name.length + data.length;
  }
  const cd = Buffer.concat(central);
  const end = Buffer.alloc(22);
  end.writeUInt32LE(0x06054b50, 0); end.writeUInt16LE(files.length, 8); end.writeUInt16LE(files.length, 10);
  end.writeUInt32LE(cd.length, 12); end.writeUInt32LE(offset, 16);
  return Buffer.concat([...parts, cd, end]);
}

export function zipFromPaths(entries, maxBytes = 256 * 1024 * 1024) {
  let total = 0;
  const files = [];
  for (const e of entries) {
    const data = fs.readFileSync(e.abs);
    total += data.length;
    if (total > maxBytes) throw new Error('Export trop volumineux');
    files.push({ name: e.name, data });
  }
  return makeZip(files);
}

/** Lecture ZIP sécurisée (répertoire central) : méthodes 0/8, limites d'entrées et de taille décompressée (anti zip-bomb). */
export function readZip(buf, { maxEntries = 2000, maxTotal = 64 * 1024 * 1024 } = {}) {
  let e = -1;
  for (let i = buf.length - 22; i >= Math.max(0, buf.length - 65557); i--) if (buf.readUInt32LE(i) === 0x06054b50) { e = i; break; }
  if (e < 0) throw new Error('ZIP invalide');
  const n = buf.readUInt16LE(e + 10); let off = buf.readUInt32LE(e + 16);
  if (n > maxEntries) throw new Error('ZIP : trop d’entrées');
  const out = []; let total = 0;
  for (let k = 0; k < n; k++) {
    if (buf.readUInt32LE(off) !== 0x02014b50) throw new Error('ZIP corrompu');
    const method = buf.readUInt16LE(off + 10), csize = buf.readUInt32LE(off + 20), usize = buf.readUInt32LE(off + 24);
    const nl = buf.readUInt16LE(off + 28), xl = buf.readUInt16LE(off + 30), cl = buf.readUInt16LE(off + 32), lho = buf.readUInt32LE(off + 42);
    const name = buf.subarray(off + 46, off + 46 + nl).toString('utf8');
    off += 46 + nl + xl + cl;
    total += usize; if (total > maxTotal) throw new Error('ZIP : taille décompressée excessive');
    if (name.endsWith('/')) continue;
    const lnl = buf.readUInt16LE(lho + 26), lxl = buf.readUInt16LE(lho + 28), start = lho + 30 + lnl + lxl;
    const raw = buf.subarray(start, start + csize);
    let data;
    if (method === 0) data = raw; else if (method === 8) data = zlib.inflateRawSync(raw, { maxOutputLength: Math.max(usize, 1) + 1 }); else throw new Error('ZIP : méthode non supportée');
    if (data.length !== usize) throw new Error('ZIP : taille incohérente');
    out.push({ name, data });
  }
  return out;
}
