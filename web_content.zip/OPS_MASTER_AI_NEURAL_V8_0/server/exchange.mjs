import fs from 'node:fs';
import path from 'node:path';
import { uid, now, j, pj, sha1, HttpError } from './util.mjs';
import { makeZip, readZip } from './zip.mjs';

/**
 * Format d'échange commun « ops-exchange » v1 : un ZIP contenant manifest.json + files/<chemin>.
 * Le manifeste liste chaque fichier avec taille et SHA-1 ; l'import vérifie tout avant d'écrire quoi que ce soit.
 */
export const EXCHANGE_FORMAT = 'ops-exchange';
export const EXCHANGE_VERSION = 1;
const MAX_FILE = 5 * 1024 * 1024;

const FORMAT_BY_EXT = { fbx: 'fbx', glb: 'glb', gltf: 'gltf', obj: 'obj', png: 'png', jpg: 'jpg', json: 'json', js: 'javascript', mjs: 'javascript', wav: 'wav', mp3: 'mp3', ogg: 'ogg', md: 'markdown', txt: 'text', html: 'html' };
const fmtOf = (p) => FORMAT_BY_EXT[(p.split('.').pop() || '').toLowerCase()] || 'binary';

function safeRel(rel) {
  const r = String(rel).replace(/\\/g, '/');
  if (!r || r.startsWith('/') || /^[a-zA-Z]:/.test(r) || r.includes('\0') || r.split('/').some((s) => s === '..' || s === '')) throw new HttpError(400, `Chemin refusé dans le paquet : ${rel}`, 'bad_path');
  return r;
}

export function createExchange(ctx) {
  const { workspace } = ctx;
  return {
    export(pid, { paths, kind = 'assets', note = '' } = {}) {
      const all = workspace.filesIn(workspace.wdir(pid));
      const sel = Array.isArray(paths) && paths.length ? all.filter((f) => paths.includes(f.rel) || paths.some((p) => f.rel.startsWith(p.replace(/\/?$/, '/')))) : all;
      if (!sel.length) throw new HttpError(404, 'Aucun fichier à exporter');
      const files = [], assets = [];
      for (const f of sel) {
        const data = fs.readFileSync(f.abs);
        if (data.length > MAX_FILE) continue;
        assets.push({ path: f.rel, size: data.length, sha1: sha1(data), format: fmtOf(f.rel) });
        files.push({ name: 'files/' + f.rel, data });
      }
      const manifest = { format: EXCHANGE_FORMAT, version: EXCHANGE_VERSION, project: pid, kind, note, created: new Date().toISOString(), assets };
      return makeZip([{ name: 'manifest.json', data: Buffer.from(JSON.stringify(manifest, null, 2)) }, ...files]);
    },

    /** Analyse + vérification complète d'un paquet. Ne touche à aucun fichier. */
    inspect(buf, pid) {
      let entries;
      try { entries = readZip(buf); } catch (e) { throw new HttpError(400, `Paquet illisible : ${e.message}`, 'bad_package'); }
      const mf = entries.find((e) => e.name === 'manifest.json');
      const m = mf && pj(mf.data.toString('utf8'));
      if (!m || m.format !== EXCHANGE_FORMAT) throw new HttpError(400, 'Ce n’est pas un paquet ops-exchange (manifest.json absent ou invalide)', 'bad_package');
      if (m.version !== EXCHANGE_VERSION) throw new HttpError(400, `Version ${m.version} non supportée (attendu ${EXCHANGE_VERSION})`, 'bad_version');
      if (!Array.isArray(m.assets) || !m.assets.length) throw new HttpError(400, 'Manifeste sans fichiers', 'bad_package');
      const byName = new Map(entries.map((e) => [e.name, e.data]));
      const items = [];
      for (const a of m.assets) {
        const rel = safeRel(a.path);
        const data = byName.get('files/' + rel);
        if (!data) throw new HttpError(400, `Fichier annoncé mais absent du paquet : ${rel}`, 'missing');
        if (data.length > MAX_FILE) throw new HttpError(413, `Fichier trop gros : ${rel}`);
        if (sha1(data) !== a.sha1 || data.length !== a.size) throw new HttpError(400, `Intégrité : empreinte incorrecte pour ${rel}`, 'integrity');
        workspace.safePath(pid, rel);
        let status = 'new';
        const cur = path.join(workspace.wdir(pid), rel);
        if (fs.existsSync(cur)) status = sha1(fs.readFileSync(cur)) === a.sha1 ? 'identical' : 'conflict';
        items.push({ path: rel, size: data.length, format: a.format, status, data });
      }
      return { manifest: { project: m.project, kind: m.kind, note: m.note, created: m.created }, items };
    },

    async import(pid, buf, { dry_run = false, overwrite = false } = {}) {
      await workspace.getProject(pid);
      const { manifest, items } = this.inspect(buf, pid);
      const report = items.map((i) => ({ path: i.path, size: i.size, format: i.format, status: i.status }));
      const conflicts = report.filter((r) => r.status === 'conflict');
      if (dry_run) return { dry_run: true, manifest, files: report, conflicts: conflicts.length };
      if (conflicts.length && !overwrite) throw new HttpError(409, `${conflicts.length} fichier(s) existent avec un contenu différent : relancez avec overwrite=true pour les remplacer (sauvegarde automatique, annulable).`, 'conflict');
      let written = 0;
      for (const i of items) { if (i.status === 'identical') continue; await workspace.writeFile(pid, i.path, i.data.toString('base64'), { actor: 'import:ops-exchange', encoding: 'base64' }); written++; }
      await workspace.log(pid, 'user', 'exchange.import', `${written} fichier(s) depuis ${manifest.project || '?'}`);
      return { dry_run: false, manifest, files: report, written };
    },
  };
}

/** Registre des moteurs OPS : un moteur n'est « verified » que si un test réel a réussi. */
export function createEngines(ctx) {
  const { db, workspace } = ctx;
  const pub = (r) => ({ ...r, formats: pj(r.formats, []), last_check: r.last_check ? Number(r.last_check) : null });
  const get = async (id) => { const r = await db.get('SELECT * FROM engines WHERE id=?', [id]); if (!r) throw new HttpError(404, 'Moteur introuvable'); return r; };
  const api = {
    async list(pid) { return (await db.all(`SELECT * FROM engines ${pid ? 'WHERE project_id=?' : ''} ORDER BY created`, pid ? [pid] : [])).map(pub); },
    async add({ project_id, name, kind, endpoint, exchange_dir, formats }) {
      await workspace.getProject(project_id);
      name = String(name || '').trim();
      if (!name) throw new HttpError(400, 'Nom requis');
      if (!['http', 'files'].includes(kind)) throw new HttpError(400, 'kind : http (API) ou files (dossier d’échange)');
      if (kind === 'http') { try { const u = new URL(endpoint); if (!/^https?:$/.test(u.protocol)) throw 0; } catch { throw new HttpError(400, 'endpoint http(s) invalide'); } }
      if (kind === 'files') workspace.safePath(project_id, exchange_dir || 'exchange');
      const id = uid('eng_');
      await db.run('INSERT INTO engines(id,project_id,name,kind,endpoint,exchange_dir,formats,status,last_check,detail,created) VALUES(?,?,?,?,?,?,?,?,NULL,NULL,?)', [id, project_id, name, kind, kind === 'http' ? endpoint : null, kind === 'files' ? (exchange_dir || 'exchange') : null, j((Array.isArray(formats) ? formats : String(formats || '').split(',')).map((x) => String(x).trim().toLowerCase()).filter(Boolean)), 'declared', now()]);
      await workspace.log(project_id, 'user', 'engine.add', `${name} (${kind})`);
      return pub(await get(id));
    },
    /** Vérification réelle : GET sur l'API (réponse 2xx) ou aller-retour écriture/lecture dans le dossier d'échange. */
    async check(id) {
      const e = await get(id);
      const t0 = Date.now(); let ok = false, detail = '';
      try {
        if (e.kind === 'http') {
          const r = await fetch(e.endpoint, { signal: AbortSignal.timeout(5000), redirect: 'manual' });
          ok = r.status >= 200 && r.status < 300; detail = `HTTP ${r.status} en ${Date.now() - t0} ms`;
        } else {
          const { abs } = workspace.safePath(e.project_id, e.exchange_dir);
          fs.mkdirSync(abs, { recursive: true });
          const probe = path.join(abs, `.ops-check-${uid()}`), val = uid('v');
          fs.writeFileSync(probe, val); ok = fs.readFileSync(probe, 'utf8') === val; fs.unlinkSync(probe);
          detail = ok ? `aller-retour écriture/lecture réussi dans ${e.exchange_dir}` : 'lecture différente de l’écriture';
        }
      } catch (err) { detail = `échec : ${err?.cause?.code || err.message}`; }
      await db.run('UPDATE engines SET status=?, last_check=?, detail=? WHERE id=?', [ok ? 'verified' : 'failed', now(), detail, id]);
      await workspace.log(e.project_id, 'director', 'engine.check', `${e.name} : ${ok ? 'OK' : 'ÉCHEC'} — ${detail}`);
      return pub(await get(id));
    },
    async remove(id, { confirm = false } = {}) {
      if (!confirm) throw new HttpError(409, 'Suppression : confirmation requise', 'confirm_required');
      const e = await get(id); await db.run('DELETE FROM engines WHERE id=?', [id]); await workspace.log(e.project_id, 'user', 'engine.remove', e.name); return { ok: true };
    },
  };
  return api;
}
