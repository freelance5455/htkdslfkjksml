import { decrypt, encrypt, hint } from './keys.mjs';
import { uid, now, sleep, HttpError } from './util.mjs';
import { createInternalCore } from './internal-core.mjs';

/**
 * Passerelle universelle : adaptateurs interchangeables.
 *  - openai    : toute API compatible OpenAI /chat/completions (OpenAI, OpenRouter, Mistral, Groq, DeepSeek, Ollama, LM Studio…)
 *  - anthropic : API Messages d'Anthropic
 *  - gemini    : API generateContent de Google
 * Aucun faux fournisseur : sans clé/endpoint réels, les appels échouent explicitement.
 */
export const KINDS = {
  openai: { label: 'Compatible OpenAI', defaultBase: 'https://api.openai.com/v1', needsKey: true },
  anthropic: { label: 'Anthropic', defaultBase: 'https://api.anthropic.com', needsKey: true },
  gemini: { label: 'Google Gemini', defaultBase: 'https://generativelanguage.googleapis.com/v1beta', needsKey: true },
};

export class ProviderError extends Error {
  constructor(message, { code = 'provider_error', status = 0, retryable = false } = {}) {
    super(message); this.code = code; this.status = status; this.retryable = retryable;
  }
}

const trimSlash = (s) => String(s || '').replace(/\/+$/, '');

async function http(url, init, timeoutMs) {
  let res;
  try {
    res = await fetch(url, { ...init, signal: AbortSignal.any([AbortSignal.timeout(timeoutMs), ...(init.signal ? [init.signal] : [])]) });
  } catch (e) {
    if (init.signal?.aborted) throw new ProviderError('Appel annulé', { code: 'aborted' });
    const timeout = e?.name === 'TimeoutError';
    throw new ProviderError(timeout ? 'Délai dépassé' : `Réseau : ${e?.cause?.code || e?.message}`, { code: timeout ? 'timeout' : 'network', retryable: true });
  }
  const text = await res.text();
  let data = null; try { data = JSON.parse(text); } catch { /* texte brut */ }
  if (!res.ok) {
    const msg = data?.error?.message || data?.message || data?.error || text.slice(0, 300) || res.statusText;
    const code = res.status === 401 || res.status === 403 ? 'auth' : res.status === 429 ? 'rate_limit' : res.status === 404 ? 'not_found' : 'http_' + res.status;
    throw new ProviderError(`HTTP ${res.status} : ${typeof msg === 'string' ? msg : JSON.stringify(msg)}`, { code, status: res.status, retryable: res.status === 429 || res.status >= 500 });
  }
  return data ?? {};
}

const toAnthropicContent = (content) => { if (!Array.isArray(content)) return content; return content.map((part) => { if (part.type === 'text') return { type: 'text', text: part.text }; const url = part.image_url?.url || ''; const m = url.match(/^data:(image\/(?:png|jpeg|webp));base64,([A-Za-z0-9+/=]+)$/); if (!m) throw new ProviderError('Image : format data URL non pris en charge par ce fournisseur.', { code: 'image_format' }); return { type: 'image', source: { type: 'base64', media_type: m[1], data: m[2] } }; }); };
const toGeminiParts = (content) => { if (!Array.isArray(content)) return [{ text: content }]; return content.map((part) => { if (part.type === 'text') return { text: part.text }; const url = part.image_url?.url || ''; const m = url.match(/^data:(image\/(?:png|jpeg|webp));base64,([A-Za-z0-9+/=]+)$/); if (!m) throw new ProviderError('Image : format non pris en charge par Gemini.', { code: 'image_format' }); return { inlineData: { mimeType: m[1], data: m[2] } }; }); };

const adapters = {
  async openai(p, { messages, maxTokens, signal, timeoutMs }) {
    const body = { model: p.model, messages };
    if (maxTokens) body.max_tokens = maxTokens;
    const d = await http(`${trimSlash(p.base_url || KINDS.openai.defaultBase)}/chat/completions`, {
      method: 'POST', signal,
      headers: { 'content-type': 'application/json', ...(p.key ? { authorization: `Bearer ${p.key}` } : {}) },
      body: JSON.stringify(body),
    }, timeoutMs);
    const text = d.choices?.[0]?.message?.content;
    if (typeof text !== 'string') throw new ProviderError('Réponse sans contenu texte', { code: 'bad_response' });
    return { text, usage: { prompt: d.usage?.prompt_tokens || 0, completion: d.usage?.completion_tokens || 0 } };
  },
  async anthropic(p, { messages, maxTokens, signal, timeoutMs }) {
    const system = messages.filter((m) => m.role === 'system').map((m) => m.content).join('\n\n');
    const msgs = messages.filter((m) => m.role !== 'system').map((m) => ({ role: m.role === 'assistant' ? 'assistant' : 'user', content: toAnthropicContent(m.content) }));
    const d = await http(`${trimSlash(p.base_url || KINDS.anthropic.defaultBase)}/v1/messages`, {
      method: 'POST', signal,
      headers: { 'content-type': 'application/json', 'x-api-key': p.key || '', 'anthropic-version': '2023-06-01' },
      body: JSON.stringify({ model: p.model, max_tokens: maxTokens || 4096, ...(system ? { system } : {}), messages: msgs }),
    }, timeoutMs);
    const text = (d.content || []).filter((b) => b.type === 'text').map((b) => b.text).join('');
    if (!text) throw new ProviderError('Réponse sans contenu texte', { code: 'bad_response' });
    return { text, usage: { prompt: d.usage?.input_tokens || 0, completion: d.usage?.output_tokens || 0 } };
  },
  async gemini(p, { messages, maxTokens, signal, timeoutMs }) {
    const system = messages.filter((m) => m.role === 'system').map((m) => m.content).join('\n\n');
    const contents = messages.filter((m) => m.role !== 'system').map((m) => ({ role: m.role === 'assistant' ? 'model' : 'user', parts: toGeminiParts(m.content) }));
    const d = await http(`${trimSlash(p.base_url || KINDS.gemini.defaultBase)}/models/${encodeURIComponent(p.model)}:generateContent`, {
      method: 'POST', signal,
      headers: { 'content-type': 'application/json', 'x-goog-api-key': p.key || '' },
      body: JSON.stringify({ contents, ...(system ? { systemInstruction: { parts: [{ text: system }] } } : {}), ...(maxTokens ? { generationConfig: { maxOutputTokens: maxTokens } } : {}) }),
    }, timeoutMs);
    const text = (d.candidates?.[0]?.content?.parts || []).map((x) => x.text || '').join('');
    if (!text) throw new ProviderError(d.promptFeedback?.blockReason ? `Bloqué : ${d.promptFeedback.blockReason}` : 'Réponse sans contenu texte', { code: 'bad_response' });
    return { text, usage: { prompt: d.usageMetadata?.promptTokenCount || 0, completion: d.usageMetadata?.candidatesTokenCount || 0 } };
  },
};

const listers = {
  async openai(p, timeoutMs) {
    const d = await http(`${trimSlash(p.base_url || KINDS.openai.defaultBase)}/models`, { headers: p.key ? { authorization: `Bearer ${p.key}` } : {} }, timeoutMs);
    return (d.data || []).map((m) => m.id).sort();
  },
  async anthropic(p, timeoutMs) {
    const d = await http(`${trimSlash(p.base_url || KINDS.anthropic.defaultBase)}/v1/models?limit=100`, { headers: { 'x-api-key': p.key || '', 'anthropic-version': '2023-06-01' } }, timeoutMs);
    return (d.data || []).map((m) => m.id);
  },
  async gemini(p, timeoutMs) {
    const d = await http(`${trimSlash(p.base_url || KINDS.gemini.defaultBase)}/models?pageSize=100`, { headers: { 'x-goog-api-key': p.key || '' } }, timeoutMs);
    return (d.models || []).filter((m) => (m.supportedGenerationMethods || []).includes('generateContent')).map((m) => m.name.replace(/^models\//, ''));
  },
};

export function createProviders(ctx) {
  const { db, config } = ctx;
  const internalCore = createInternalCore();
  const pub = (r) => r && ({ id: r.id, name: r.name, kind: r.kind, base_url: r.base_url, model: r.model, key_set: !!r.key_enc, key_hint: r.key_hint, enabled: !!r.enabled, max_tokens_day: r.max_tokens_day, created: r.created });

  async function withKey(id) {
    const r = await db.get('SELECT * FROM providers WHERE id=?', [id]);
    if (!r) return null;
    return { ...r, key: r.key_enc ? decrypt(config.secret, r.key_enc) : '' };
  }

  function validate(b, partial) {
    if (!partial || b.kind !== undefined) if (!KINDS[b.kind]) throw new HttpError(400, `Type inconnu. Valeurs : ${Object.keys(KINDS).join(', ')}`);
    if (!partial && !String(b.name || '').trim()) throw new HttpError(400, 'Nom requis');
    if (b.base_url) { try { const u = new URL(b.base_url); if (!/^https?:$/.test(u.protocol)) throw 0; } catch { throw new HttpError(400, 'base_url invalide'); } }
  }

  return {
    pub,
    async list() { return (await db.all('SELECT * FROM providers ORDER BY created')).map(pub); },
    async create(b) {
      validate(b, false);
      const id = uid('prov_');
      await db.run('INSERT INTO providers(id,name,kind,base_url,model,key_enc,key_hint,enabled,max_tokens_day,created) VALUES(?,?,?,?,?,?,?,?,?,?)',
        [id, String(b.name).trim(), b.kind, b.base_url || '', b.model || '', encrypt(config.secret, b.api_key), hint(b.api_key), b.enabled === false ? 0 : 1, Number(b.max_tokens_day) || 0, now()]);
      return pub(await db.get('SELECT * FROM providers WHERE id=?', [id]));
    },
    async update(id, b) {
      const cur = await db.get('SELECT * FROM providers WHERE id=?', [id]);
      if (!cur) throw new HttpError(404, 'Fournisseur introuvable');
      validate(b, true);
      const key_enc = b.api_key ? encrypt(config.secret, b.api_key) : cur.key_enc;
      const key_hint = b.api_key ? hint(b.api_key) : cur.key_hint;
      await db.run('UPDATE providers SET name=?,kind=?,base_url=?,model=?,key_enc=?,key_hint=?,enabled=?,max_tokens_day=? WHERE id=?',
        [b.name ?? cur.name, b.kind ?? cur.kind, b.base_url ?? cur.base_url, b.model ?? cur.model, key_enc, key_hint, b.enabled === undefined ? cur.enabled : (b.enabled ? 1 : 0), b.max_tokens_day ?? cur.max_tokens_day, id]);
      return pub(await db.get('SELECT * FROM providers WHERE id=?', [id]));
    },
    async remove(id) {
      await db.run('UPDATE agents SET provider_id=NULL WHERE provider_id=?', [id]);
      await db.run('DELETE FROM providers WHERE id=?', [id]);
    },
    async resolveFor(agent) {
      let id = agent?.provider_id;
      if (!id) id = (await db.get("SELECT value FROM settings WHERE key='default_provider_id'"))?.value;
      let p = id ? await withKey(id) : null;
      if (!p || !p.enabled) p = null;
      if (!p && !agent?.provider_id) { const any = await db.get('SELECT id FROM providers WHERE enabled=1 ORDER BY created LIMIT 1'); if (any) p = await withKey(any.id); }
      return p;
    },
    internalChat(agent, messages) { return internalCore.chat(agent, messages); },
    internalStatus() { return internalCore.health(); },
    async usageToday(providerId) {
      const since = new Date(); since.setHours(0, 0, 0, 0);
      const r = await db.get('SELECT COALESCE(SUM(prompt_tokens+completion_tokens),0) AS t, COUNT(*) AS n FROM usage WHERE provider_id=? AND ts>=?', [providerId, since.getTime()]);
      return { tokens: Number(r.t), calls: Number(r.n) };
    },
    /** Appel de modèle avec contrôle de budget, retries (429/5xx/réseau) et journal d'usage. */
    async chat(agent, messages, { signal, maxTokens, timeoutMs = 180000, retries = 2 } = {}) {
      const p = await this.resolveFor(agent);
      if (!p) {
        // Repli 100 % local : noyau interne OPS (aucun appel réseau, aucune clé requise).
        if (config.localFallback === true) return internalCore.chat(agent, messages);
        throw new ProviderError("Aucun fournisseur IA configuré pour cet agent. Ajoutez-en un dans « Fournisseurs IA ».", { code: 'no_provider' });
      }
      if (!p.model && !agent?.model) throw new ProviderError(`Aucun modèle défini pour « ${p.name} ».`, { code: 'no_model' });
      if (KINDS[p.kind].needsKey && !p.key && p.kind !== 'openai') throw new ProviderError(`Clé API manquante pour « ${p.name} ».`, { code: 'auth' });
      if (p.max_tokens_day > 0) {
        const u = await this.usageToday(p.id);
        if (u.tokens >= p.max_tokens_day) throw new ProviderError(`Limite quotidienne atteinte pour « ${p.name} » (${u.tokens}/${p.max_tokens_day} tokens).`, { code: 'budget' });
      }
      const eff = { ...p, model: agent?.model || p.model };
      let last;
      for (let i = 0; i <= retries; i++) {
        try {
          const r = await adapters[p.kind](eff, { messages, maxTokens, signal, timeoutMs });
          await db.run('INSERT INTO usage(id,ts,provider_id,agent_id,prompt_tokens,completion_tokens,ok,error) VALUES(?,?,?,?,?,?,1,NULL)', [uid('u_'), now(), p.id, agent?.id || null, r.usage.prompt, r.usage.completion]);
          return { ...r, provider: p.name, model: eff.model };
        } catch (e) {
          last = e;
          await db.run('INSERT INTO usage(id,ts,provider_id,agent_id,prompt_tokens,completion_tokens,ok,error) VALUES(?,?,?,?,0,0,0,?)', [uid('u_'), now(), p.id, agent?.id || null, String(e.message).slice(0, 300)]);
          if (!(e instanceof ProviderError) || !e.retryable || i === retries) throw e;
          await sleep(800 * 2 ** i, signal);
        }
      }
      throw last;
    },
    async test(id) {
      const p = await withKey(id);
      if (!p) throw new HttpError(404, 'Fournisseur introuvable');
      const t0 = Date.now();
      try {
        const r = await adapters[p.kind](p, { messages: [{ role: 'user', content: 'Réponds uniquement par le mot : OK' }], maxTokens: 20, timeoutMs: 30000 });
        return { ok: true, latency_ms: Date.now() - t0, model: p.model, sample: r.text.slice(0, 80) };
      } catch (e) {
        return { ok: false, code: e.code || 'error', error: e.message, latency_ms: Date.now() - t0 };
      }
    },
    async models(id) {
      const p = await withKey(id);
      if (!p) throw new HttpError(404, 'Fournisseur introuvable');
      try { return { ok: true, models: await listers[p.kind](p, 20000) }; } catch (e) { return { ok: false, error: e.message, code: e.code }; }
    },
  };
}
