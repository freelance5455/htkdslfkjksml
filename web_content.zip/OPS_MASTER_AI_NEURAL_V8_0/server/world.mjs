import fs from 'node:fs';
import path from 'node:path';
import { uid, now, j, pj, slugify, trunc, extractJson, HttpError } from './util.mjs';
import { aaaDetailContract } from './neural.mjs';
import { generateWorld, normalizeParams, toObj, toSvg, SIZES, THEMES, WATER_MODES, TARGETS } from './worldgen.mjs';

export const WORLD_PROMPT = `Tu es OPS WORLD AI, l'IA de conception de mondes d'un studio de jeux vidéo AAA : villes, quartiers, réseaux routiers, terrain, eau, environnements.
Ton travail réel : choisir les PARAMÈTRES d'un générateur procédural déterministe (le système produit ensuite le monde, le valide et l'exporte). Tu ne dessines pas la carte toi-même et tu n'inventes jamais de résultat de génération.
Paramètres possibles : name, seed, size (${Object.keys(SIZES).join('|')}), theme (${Object.keys(THEMES).join('|')}), water (${WATER_MODES.join('|')}), density (0.1–1), districts (3–8), landmarks (0–7), target (${Object.keys(TARGETS).join('|')}).
Tu travailles avec OPS DIRECTOR AI (qui te confie les tâches) ; la modélisation des bâtiments, les matériaux, les collisions et les PNJ appartiennent à d'autres IA : tu leur transmets un plan de monde (world.json), pas leur travail. Sois concis, factuel, en français.`;

const ATTR = /(\w+)="([^"]*)"/g;
const FILES = [['world.json', 'application/json'], ['world.obj', 'text/plain'], ['preview.svg', 'image/svg+xml']];

export function createWorld(ctx) {
  const { db, config, providers, workspace, events } = ctx;
  const wdir = (pid) => path.join(config.dataDir, 'projects', pid, 'worlds');
  const fpath = (pid, id, name) => path.join(wdir(pid), `${id}.${name.split('.').pop()}`);
  const pub = (r) => r && ({ id: r.id, project_id: r.project_id, name: r.name, seed: r.seed, params: pj(r.params, {}), stats: pj(r.stats, {}), valid: !!r.valid, issues: pj(r.issues, []), folder: r.folder, files_mode: r.files_mode, task_id: r.task_id, created: r.created });
  const agent = async () => { const a = await db.get("SELECT * FROM studio_ais WHERE id='world'"); return { id: 'world', provider_id: a?.provider_id, model: a?.model, system_prompt: `${WORLD_PROMPT}\n\n${aaaDetailContract('world')}` }; };
  async function chatWithCentral(spec, messages) {
    try { return await providers.chat(spec, messages, { timeoutMs: 45000, retries: 0 }); }
    catch (e) {
      if (e.code !== 'timeout') throw e;
      const d = await db.get("SELECT * FROM studio_ais WHERE id='director'");
      const director = { id: 'director', provider_id: d?.provider_id, model: d?.model, system_prompt: 'Tu es OPS DIRECTOR AI. Aide le spécialiste à débloquer sa tâche avec un plan concret, détaillé et vérifiable.' };
      const help = await providers.chat(director, [
        { role: 'system', content: `${director.system_prompt}\n\n${aaaDetailContract('director')}` },
        { role: 'user', content: `OPS WORLD AI dépasse le délai de réponse. Prépare une aide technique immédiatement exploitable à partir de cette tâche :\n${trunc(messages.map(m => m.content || '').join('\n\n'), 10000)}\n\nFournis les étapes, décisions, contraintes, cas limites, critères d'acceptation et tests. Ne prétends pas avoir généré ou modifié des fichiers.` }
      ], { timeoutMs: 90000, retries: 1 });
      return providers.chat(spec, [...messages,
        { role: 'assistant', content: 'OPS DIRECTOR AI intervient pour accélérer le travail.' },
        { role: 'user', content: `AIDE DU DIRECTOR :\n${trunc(help.text, 10000)}\n\nReprends la tâche en vérifiant cette aide. Complète le niveau de détail et livre le résultat réel de ta spécialité.` }
      ], { timeoutMs: 180000, retries: 2 });
    }
  }


  async function getRow(id) { const r = await db.get('SELECT * FROM worlds WHERE id=?', [id]); if (!r) throw new HttpError(404, 'Monde introuvable'); return r; }

  /** Dépose les fichiers dans le workspace du projet : directement en mode auto, sinon comme demandes d'approbation. */
  async function deliver(pid, folder, files, taskId, agent = 'world') {
    const p = await workspace.getProject(pid);
    if (p.write_mode === 'auto') {
      await workspace.createVersion(pid, { label: `Avant ${folder}`, reason: `avant écriture ${agent.toUpperCase()} AI` });
      for (const f of files) await workspace.writeFile(pid, `${folder}/${f.name}`, Buffer.isBuffer(f.content) ? f.content.toString('base64') : f.content, { actor: agent, encoding: Buffer.isBuffer(f.content) ? 'base64' : 'utf8' });
      return 'written';
    }
    for (const f of files) {
      const id = uid('apr_');
      await db.run('INSERT INTO approvals(id,project_id,run_id,task_id,agent_id,kind,path,content,status,note,created,decided) VALUES(?,?,NULL,?,?,?,?,?,?,NULL,?,NULL)', [id, pid, taskId, agent, 'write', `${folder}/${f.name}`, Buffer.isBuffer(f.content) ? `__OPS_BASE64__${f.content.toString('base64')}` : f.content, 'pending', now()]);
      events.emit('approval', { id, project_id: pid, path: `${folder}/${f.name}`, kind: 'write', agent_id: agent });
    }
    return 'proposed';
  }

  const readme = (w, id, folder) => `# ${w.name}\n\nMonde généré par OPS WORLD AI (graine \`${w.seed}\`, id \`${id}\`).\n\n- Taille : ${w.size.meters} m × ${w.size.meters} m (${w.size.cells}×${w.size.cells} cellules de ${w.size.cell_m} m)\n- Bâtiments : ${w.stats.buildings} · routes : ${w.stats.road_cells} cellules · ponts : ${w.stats.bridges} · parcs : ${w.stats.parks}\n- Cible : ${w.params.target} (${w.stats.triangles}/${w.stats.triangle_budget} triangles estimés)\n- Validation : ${w.validation.ok ? 'OK' : 'ÉCHEC'}\n\nFichiers : \`world.json\` (format ops-world v1, source de vérité), \`world.obj\` (géométrie simple : terrain, eau, routes, volumes de bâtiments), \`preview.svg\` (vue du dessus).\nLes bâtiments sont des **volumes simples** : la modélisation détaillée est transmise à OPS MODELING AI.\nRégénération identique : mêmes paramètres + même graine.\n`;

  const api = {
    /** Seed : WORLD AI passe à « construite » ; les messages en attente de sa construction lui sont remis. */
    async seed() {
      const a = await db.get("SELECT status FROM studio_ais WHERE id='world'");
      if (a && a.status === 'planned') await db.run("UPDATE studio_ais SET status='built', built_at=? WHERE id='world'", [now()]);
      await db.run("UPDATE studio_messages SET status='pending' WHERE to_ai='world' AND status='queued'");
    },

    /** Génère, valide, persiste et propose les fichiers. params : voir normalizeParams. */
    async generate({ project_id, params, task_id = null }) {
      await workspace.getProject(project_id);
      const P = normalizeParams(params || {});
      const w = generateWorld(P);
      const id = uid('wld_'), slug = slugify(P.name) || 'monde', folder = `world/${slug}-${id.slice(-6)}`;
      const contents = { 'world.json': JSON.stringify(w), 'world.obj': toObj(w), 'preview.svg': toSvg(w) };
      fs.mkdirSync(wdir(project_id), { recursive: true });
      for (const [n, c] of Object.entries(contents)) fs.writeFileSync(fpath(project_id, id, n), c);
      let mode = 'none';
      if (w.validation.ok) mode = await deliver(project_id, folder, [...Object.entries(contents).map(([name, content]) => ({ name, content })), { name: 'README.md', content: readme(w, id, folder) }], task_id);
      await db.run('INSERT INTO worlds(id,project_id,name,seed,params,stats,valid,issues,folder,files_mode,task_id,created) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)', [id, project_id, P.name, P.seed, j(P), j(w.stats), w.validation.ok ? 1 : 0, j(w.validation.issues), folder, mode, task_id, now()]);
      await workspace.log(project_id, 'world', 'world.generate', `${P.name} seed=${P.seed} → ${w.stats.buildings} bâtiments, valide=${w.validation.ok}, fichiers=${mode}`);
      events.emit('world', { id, project_id });
      return { world: pub(await getRow(id)), validation: w.validation };
    },

    deliver,
    async list(pid) { return (await db.all(`SELECT * FROM worlds ${pid ? 'WHERE project_id=?' : ''} ORDER BY created DESC LIMIT 200`, pid ? [pid] : [])).map(pub); },
    async get(id) { return pub(await getRow(id)); },
    async file(id, kind) {
      const r = await getRow(id); const name = { json: 'world.json', obj: 'world.obj', svg: 'preview.svg' }[kind];
      if (!name) throw new HttpError(400, 'kind : json | obj | svg');
      const p = fpath(r.project_id, id, name);
      if (!fs.existsSync(p)) throw new HttpError(404, 'Fichier introuvable');
      return { buf: fs.readFileSync(p), name: `${path.basename(r.folder)}-${name}`, mime: FILES.find((f) => f[0] === name)[1] };
    },

    /** Brief en langage naturel → paramètres validés (nécessite un fournisseur IA réel ; JSON invalide → 502, jamais de valeur inventée). */
    async paramsFromBrief(brief, extra = '') {
      const r = await chatWithCentral(await agent(), [{ role: 'system', content: `${WORLD_PROMPT}\n\n${aaaDetailContract('world')}` }, { role: 'user', content: `PARAMÈTRES JSON pour ce brief de monde :\n${trunc(brief, 6000)}\n${extra ? '\nCONTEXTE :\n' + trunc(extra, 6000) + '\n' : ''}\nRéponds UNIQUEMENT par un objet JSON avec les clés utiles parmi : name, seed, size, theme, water, density, districts, landmarks, target.` }]);
      let parsed;
      try { parsed = extractJson(r.text); } catch { parsed = null; }
      if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) throw new HttpError(502, 'WORLD AI n’a pas renvoyé de paramètres JSON exploitables', 'bad_ai_output');
      const allowed = ['name', 'seed', 'size', 'theme', 'water', 'density', 'districts', 'landmarks', 'target'];
      const clean = Object.fromEntries(Object.entries(parsed).filter(([k]) => allowed.includes(k)));
      try { return normalizeParams(clean); } catch (e) { throw new HttpError(502, `Paramètres proposés par WORLD AI refusés : ${e.message}`, 'bad_ai_output'); }
    },
    async fromBrief({ project_id, brief }) {
      if (!String(brief || '').trim()) throw new HttpError(400, 'Brief vide');
      const params = await api.paramsFromBrief(brief);
      return { params, ...(await api.generate({ project_id, params })) };
    },

    /** Exécution d'une tâche du plan de production (appelée par le Director). Retourne le livrable markdown. */
    async executeTask({ task, plan, deps, decisions }) {
      const inbox = await db.all("SELECT * FROM studio_messages WHERE to_ai='world' AND project_id=? AND status='pending' ORDER BY created", [task.project_id]);
      const extra = [
        `Plan : ${plan.title}\nBrief du plan : ${plan.brief || '(aucun)'}\nTâche : ${task.title}\n${task.description || ''}`,
        deps.length ? 'Résultats précédents :\n' + deps.map((d) => `--- ${d.title} ---\n${trunc(d.result, 2500)}`).join('\n') : '',
        inbox.length ? 'Messages reçus :\n' + inbox.map((m) => `[${m.from_ai}/${m.kind}] ${trunc(m.body, 1500)}`).join('\n') : '',
        decisions.length ? 'Décisions du projet :\n' + decisions.map((d) => `- ${d.key.replace('décision : ', '')} : ${trunc(d.value, 300)}`).join('\n') : '',
      ].filter(Boolean).join('\n\n');
      const params = await api.paramsFromBrief(`${plan.brief || plan.title}\n${task.title}\n${task.description || ''}`, extra);
      const { world: w, validation } = await api.generate({ project_id: task.project_id, params, task_id: task.id });
      if (inbox.length) await db.run(`UPDATE studio_messages SET status='read' WHERE id IN (${inbox.map(() => '?').join(',')})`, inbox.map((m) => m.id));
      const s = w.stats;
      return `## Monde « ${w.name} » généré par OPS WORLD AI\n\n- Graine : \`${w.seed}\` · taille ${s.size_m} m · thème ${w.params.theme} · eau ${w.params.water} · cible ${w.params.target}\n- ${s.buildings} bâtiments (${Object.entries(s.by_type).map(([k, v]) => `${k} ${v}`).join(', ')}), ${s.parks} parcs, ${s.road_cells} cellules de route (${s.bridges} pont(s)), ${s.districts} quartiers\n- Triangles estimés : ${s.triangles}/${s.triangle_budget}\n- Validation : ${validation.ok ? 'OK' : 'ÉCHEC — ' + validation.issues.filter((i) => i.level === 'error').map((i) => i.msg).slice(0, 3).join(' ; ')}${validation.issues.some((i) => i.level === 'warn') ? '\n- Avertissements : ' + validation.issues.filter((i) => i.level === 'warn').map((i) => i.msg).join(' ; ') : ''}\n- Fichiers : \`${w.folder}/\` — ${w.files_mode === 'written' ? 'écrits dans le workspace' : w.files_mode === 'proposed' ? 'proposés (à approuver dans « Approbations »)' : 'non livrés (monde invalide)'}\n- ID monde : \`${w.id}\`\n\nÀ suivre : volumes de bâtiments simples à ce stade ; les détails de géométrie sont confiés à MODELING AI, les matériaux à GRAPHICS AI, les collisions à PHYSICS AI et les comportements à NPC AI.`;
    },

    /** Conversation directe avec WORLD AI. Balise d'action : <ops-generate name=".." seed=".." size=".." theme=".." water=".." density=".." districts=".." landmarks=".." target=".."/> (max 2). */
    async chat(pid, text) {
      text = String(text || '').trim();
      if (!text) throw new HttpError(400, 'Message vide');
      if (text.length > 20000) throw new HttpError(413, 'Message trop long');
      await workspace.getProject(pid);
      const hist = (await db.all("SELECT role,content FROM messages WHERE project_id=? AND agent_id='world' ORDER BY created DESC LIMIT 10", [pid])).reverse().map((m) => ({ role: m.role === 'user' ? 'user' : 'assistant', content: trunc(m.content, 3000) }));
      const worlds = (await api.list(pid)).slice(0, 8).map((w) => ({ id: w.id, name: w.name, seed: w.seed, size: w.params.size, buildings: w.stats.buildings, valid: w.valid }));
      const sys = `${WORLD_PROMPT}\n\nMODE CONVERSATION DIRECTE avec l'utilisateur. Mondes existants dans ce projet (données réelles) : ${JSON.stringify(worlds)}\nPour générer un monde, émets <ops-generate name="…" seed="…" size="…" theme="…" water="…" density="0.6" districts="5" landmarks="3" target="mobile"/> (max 2 par message ; attributs optionnels). N'affirme avoir généré un monde que si tu émets la balise : le système te rapportera le résultat réel.`;
      const mid = () => uid('m_');
      await db.run('INSERT INTO messages(id,project_id,run_id,agent_id,role,content,created) VALUES(?,?,NULL,?,?,?,?)', [mid(), pid, 'world', 'user', text, now()]);
      const r = await chatWithCentral(await agent(), [{ role: 'system', content: sys }, ...hist, { role: 'user', content: text }]);
      const todo = [];
      let reply = r.text.replace(/<ops-generate\b([^>]*?)\/?>(?:<\/ops-generate>)?/g, (_, attrs) => { const o = {}; for (const m of attrs.matchAll(ATTR)) o[m[1]] = m[2]; todo.push(o); return ''; }).trim();
      const actions = [];
      for (const o of todo.slice(0, 2)) {
        try { const g = await api.generate({ project_id: pid, params: o }); actions.push({ ok: true, id: g.world.id, detail: `Monde « ${g.world.name} » : ${g.world.stats.buildings} bâtiments, ${g.world.valid ? 'valide' : 'INVALIDE'}, fichiers ${g.world.files_mode === 'proposed' ? 'proposés (à approuver)' : g.world.files_mode === 'written' ? 'écrits' : 'non livrés'}` }); }
        catch (e) { actions.push({ ok: false, detail: `Échec : ${e.message}` }); }
      }
      if (todo.length > 2) actions.push({ ok: false, detail: `${todo.length - 2} génération(s) ignorée(s) (maximum 2 par message)` });
      if (actions.length) reply += '\n\n**Actions effectuées**\n' + actions.map((a) => `- ${a.ok ? '✅' : '⛔'} ${a.detail}`).join('\n');
      await db.run('INSERT INTO messages(id,project_id,run_id,agent_id,role,content,created) VALUES(?,?,NULL,?,?,?,?)', [mid(), pid, 'world', 'assistant', reply, now()]);
      events.emit('world', { project_id: pid });
      return { reply, actions };
    },
  };
  return api;
}
