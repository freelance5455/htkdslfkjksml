import { createApp } from './app.mjs';

if (Number(process.versions.node.split('.')[0]) < 22) {
  console.error('OPS MASTER AI CHAT nécessite Node.js 22 ou plus récent (SQLite intégré).');
  process.exit(1);
}
process.removeAllListeners('warning');
process.on('warning', (w) => { if (w.name !== 'ExperimentalWarning') console.warn(w); });

const app = await createApp();
const port = await app.listen();
const { config } = app;
console.log(`\n  OPS MASTER AI CHAT v${config.version}`);
console.log(`  Interface : http://${config.host === '0.0.0.0' ? 'localhost' : config.host}:${port}`);
console.log(`  Base      : ${app.ctx.db.kind}   Données : ${config.dataDir}`);
if (config.firstToken) console.log(`  Jeton d'accès (premier lancement, aussi dans data/.token) :\n    ${config.token}`);
else console.log('  Jeton d\'accès : voir OPS_TOKEN ou data/.token');
if (config.host !== '127.0.0.1' && config.host !== 'localhost') console.log('  ⚠ Écoute hors machine locale : placez le serveur derrière HTTPS.');
console.log('');
for (const sig of ['SIGINT', 'SIGTERM']) process.on(sig, async () => { await app.close(); process.exit(0); });
