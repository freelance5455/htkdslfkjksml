/** Normalise compiler/test output into actionable, evidence-backed diagnostics.
 * Parsing only: this module never executes compilers, scripts, or project code.
 */
const RULES = [
  { type: 'typescript', re: /^(.*?\.(?:[cm]?[jt]sx?))\((\d+),(\d+)\):\s*error\s*(TS\d+):\s*(.+)$/i },
  { type: 'eslint', re: /^(.*?\.(?:[cm]?[jt]sx?)):(\d+):(\d+):\s*(error|warning)\s+(.+?)\s+([\w/-]+)$/i },
  { type: 'python', re: /^\s*File "(.+?)", line (\d+)(?:, in .*)?$/i },
  { type: 'rust', re: /^\s*-->\s+(.+?):(\d+):(\d+)\s*$/i },
  { type: 'go', re: /^(.*?\.go):(\d+)(?::(\d+))?:\s*(.+)$/i },
  { type: 'java', re: /^(.*?\.java):(\d+):\s*error:\s*(.+)$/i },
  { type: 'csharp', re: /^(.+?)\((\d+),(\d+)\):\s*(error|warning)\s+(CS\d+):\s*(.+)$/i },
  { type: 'generic', re: /^(?:ERROR|Error|error):\s*(.+)$/ }
];

function safePath(value) {
  const p = String(value || '').trim().replaceAll('\\', '/');
  if (!p || p.length > 240 || p.startsWith('/') || /^[a-z]:\//i.test(p) || p.split('/').includes('..')) return '';
  return p;
}

export function parseCompilerDiagnostics(output, { maxItems = 100 } = {}) {
  const text = String(output ?? '').slice(0, 250_000);
  const lines = text.split(/\r?\n/);
  const found = [];
  let pendingPython = null;
  for (let i = 0; i < lines.length && found.length < Math.max(1, Math.min(250, maxItems)); i++) {
    const line = lines[i].trimEnd();
    if (!line.trim()) continue;
    let match;
    if ((match = line.match(RULES[0].re))) {
      found.push({ language:'typescript', severity:'error', path:safePath(match[1]), line:Number(match[2]), column:Number(match[3]), code:match[4], message:match[5].trim(), source_line:i+1 });
    } else if ((match = line.match(RULES[1].re))) {
      found.push({ language:'javascript', severity:match[4].toLowerCase(), path:safePath(match[1]), line:Number(match[2]), column:Number(match[3]), code:match[6], message:match[5].trim(), source_line:i+1 });
    } else if ((match = line.match(RULES[2].re))) {
      pendingPython = { language:'python', severity:'error', path:safePath(match[1]), line:Number(match[2]), column:null, code:'PYTHON_TRACEBACK', message:'Traceback Python : consulter la dernière ligne de l’exception.', source_line:i+1 };
    } else if ((match = line.match(RULES[3].re))) {
      found.push({ language:'rust', severity:'error', path:safePath(match[1]), line:Number(match[2]), column:Number(match[3]), code:'RUST_DIAGNOSTIC', message:lines.slice(Math.max(0,i-2),i).join(' ').trim().slice(-500) || 'Erreur Rust signalée à cet emplacement.', source_line:i+1 });
    } else if ((match = line.match(RULES[4].re))) {
      found.push({ language:'go', severity:'error', path:safePath(match[1]), line:Number(match[2]), column:match[3] ? Number(match[3]) : null, code:'GO_DIAGNOSTIC', message:match[4].trim(), source_line:i+1 });
    } else if ((match = line.match(RULES[5].re))) {
      found.push({ language:'java', severity:'error', path:safePath(match[1]), line:Number(match[2]), column:null, code:'JAVA_COMPILER', message:match[3].trim(), source_line:i+1 });
    } else if ((match = line.match(RULES[6].re))) {
      found.push({ language:'csharp', severity:match[4].toLowerCase(), path:safePath(match[1]), line:Number(match[2]), column:Number(match[3]), code:match[5], message:match[6].trim(), source_line:i+1 });
    } else if ((match = line.match(RULES[7].re))) {
      found.push({ language:'unknown', severity:'error', path:'', line:null, column:null, code:'GENERIC_ERROR', message:match[1].trim().slice(0,1000), source_line:i+1 });
    }
    if (pendingPython && /^(?:\w+(?:Error|Exception)|SyntaxError|IndentationError):/.test(line.trim())) {
      pendingPython.message = line.trim().slice(0,1000);
      found.push(pendingPython);
      pendingPython = null;
    }
  }
  const seen = new Set();
  return found.filter((item) => {
    const key = [item.path,item.line,item.column,item.code,item.message].join('|');
    if (seen.has(key)) return false;
    seen.add(key); return true;
  });
}

export function buildCompilerRepairContext(output, options) {
  const diagnostics = parseCompilerDiagnostics(output, options);
  if (!diagnostics.length) return { diagnostics:[], context:'Aucun diagnostic compilateur structuré reconnu. Ne pas inventer de fichier ou de ligne ; analyser le journal brut et signaler les limites.' };
  const context = diagnostics.map((d,i) => `${i+1}. [${d.severity}] ${d.language} ${d.path || '(fichier non identifié)'}${d.line ? `:${d.line}${d.column ? `:${d.column}` : ''}` : ''} ${d.code}: ${d.message}`).join('\n');
  return { diagnostics, context:`DIAGNOSTICS COMPILATEUR NORMALISÉS (indices extraits du rapport, à confirmer dans les sources)\n${context}\n\nPrioriser les erreurs bloquantes, ouvrir les lignes concernées et leur contexte, corriger la cause racine, puis relancer uniquement les validations autorisées et disponibles. Ne prétends pas avoir compilé si aucun compilateur n'a été exécuté.` };
}
