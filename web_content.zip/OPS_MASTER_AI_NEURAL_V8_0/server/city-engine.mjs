import { uid, HttpError } from './util.mjs';

function rng(seed) { let x = 2166136261; for (const c of String(seed)) x = Math.imul(x ^ c.charCodeAt(0), 16777619); return () => { x += 0x6D2B79F5; let t=x; t=Math.imul(t^t>>>15,t|1); t^=t+Math.imul(t^t>>>7,t|61); return ((t^t>>>14)>>>0)/4294967296; }; }

/** Générateur urbain déterministe : données spatiales exploitables par un moteur de rendu, sans prétendre produire des meshes finaux. */
export function generateCity({ name = 'OPS Generated City', seed = 'ops-city', blocks = 8, blockSize = 120, roadWidth = 16, buildingDensity = 0.72, districts = ['residential','commercial','industrial','park'] } = {}) {
  blocks = Math.max(2, Math.min(40, Math.floor(Number(blocks) || 8)));
  blockSize = Math.max(40, Math.min(500, Number(blockSize) || 120));
  roadWidth = Math.max(6, Math.min(50, Number(roadWidth) || 16));
  buildingDensity = Math.max(0.1, Math.min(1, Number(buildingDensity) || .72));
  const rand = rng(seed), roads = [], buildings = [], zones = [];
  const extent = blocks * (blockSize + roadWidth);
  for (let i=0;i<=blocks;i++) {
    const p = i*(blockSize+roadWidth);
    roads.push({ id:`road-x-${i}`, axis:'x', x:extent/2, z:p, width:roadWidth, length:extent, lanes: i%4===0?4:2, type:i%4===0?'arterial':'local' });
    roads.push({ id:`road-z-${i}`, axis:'z', x:p, z:extent/2, width:roadWidth, length:extent, lanes: i%4===0?4:2, type:i%4===0?'arterial':'local' });
  }
  let bi=0;
  for(let x=0;x<blocks;x++) for(let z=0;z<blocks;z++) {
    const district = districts[(x*3+z*5)%districts.length] || 'residential';
    const cx=x*(blockSize+roadWidth)+blockSize/2, cz=z*(blockSize+roadWidth)+blockSize/2;
    zones.push({id:`zone-${x}-${z}`,district,center:{x:cx,z:cz},size:{x:blockSize,z:blockSize}});
    if(district==='park') continue;
    const slots = rand()<buildingDensity ? 1+Math.floor(rand()*4) : 0;
    for(let k=0;k<slots;k++) {
      const w=18+rand()*25, d=18+rand()*25;
      buildings.push({id:`building-${++bi}`,district,position:{x:cx+(rand()-.5)*(blockSize-40),y:0,z:cz+(rand()-.5)*(blockSize-40)},dimensions:{width:w,depth:d,height:district==='commercial'?18+rand()*100:district==='industrial'?8+rand()*24:6+rand()*28},floors:1+Math.floor(rand()*18),interior:{generated:false,profile:district==='commercial'?'retail-office':district==='industrial'?'warehouse':'residential'},lod:[0,1,2]});
    }
  }
  return {schema:'ops-city/1',id:uid('city_'),name,seed:String(seed),generator:'OPS CITY ENGINE procedural-grid v1',units:'meters',bounds:{width:extent,depth:extent},stats:{blocks:blocks*blocks,roads:roads.length,buildings:buildings.length,zones:zones.length,interiors_pending:buildings.length},roads,zones,buildings,limitations:['Géométrie spatiale descriptive : meshes, matériaux PBR et intérieurs détaillés à générer par les moteurs 3D dédiés.','Réseau routier en grille déterministe ; pas encore de trafic simulé ni de validation de circulation.']};
}

export function createCityEngine(ctx) {
  return {
    async generate(project_id, options = {}) {
      await ctx.workspace.getProject(project_id);
      const city = generateCity(options);
      const base = `generated/cities/${city.id}`;
      await ctx.workspace.writeFile(project_id, `${base}/city.json`, JSON.stringify(city,null,2), {actor:'OPS_CITY_ENGINE'});
      await ctx.workspace.writeFile(project_id, `${base}/README.md`, `# ${city.name}\n\nDonnées générées par OPS CITY ENGINE.\n\n- Blocs : ${city.stats.blocks}\n- Routes : ${city.stats.roads}\n- Bâtiments descriptifs : ${city.stats.buildings}\n\nLes bâtiments et routes sont des données spatiales destinées aux moteurs de rendu/physique. Les meshes et intérieurs détaillés restent à construire.\n`, {actor:'OPS_CITY_ENGINE'});
      await ctx.workspace.log(project_id,'OPS_CITY_ENGINE','city.generate',`${city.name}: ${city.stats.buildings} bâtiments, ${city.stats.roads} routes`);
      ctx.events?.emit('ops:city:generated',{project_id,city_id:city.id,stats:city.stats});
      return {city, files:[`${base}/city.json`,`${base}/README.md`]};
    }
  };
}
