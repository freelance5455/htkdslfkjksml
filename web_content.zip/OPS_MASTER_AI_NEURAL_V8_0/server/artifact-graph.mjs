import path from 'node:path';

const SOURCE_RE = /\.(?:[cm]?[jt]sx?|vue|svelte)$/i;
const HTML_RE = /\.html?$/i;

function cleanPath(value) {
  const normalized = path.posix.normalize(String(value || '').replace(/\\/g, '/').replace(/^\.\//, ''));
  if (!normalized || normalized === '.' || normalized.startsWith('../') || normalized.startsWith('/')) return null;
  return normalized;
}

function candidates(from, specifier) {
  const base = path.posix.normalize(path.posix.join(path.posix.dirname(from), specifier));
  const ext = path.posix.extname(base);
  return ext ? [base, `${base}/index.js`, `${base}/index.ts`] : [base, ...['.js','.mjs','.cjs','.ts','.jsx','.tsx','.json','.css','.html'].map((e) => base + e), ...['index.js','index.mjs','index.ts','index.jsx','index.tsx'].map((e) => `${base}/${e}`)];
}

/** Construit un graphe statique prudent des références locales entre fichiers livrés et workspace. */
export function analyzeArtifactGraph(proposedFiles = [], existingPaths = []) {
  const contents = new Map();
  for (const entry of existingPaths) {
    const p = cleanPath(typeof entry === 'string' ? entry : entry?.path);
    if (p) contents.set(p, null);
  }
  for (const file of proposedFiles) {
    const p = cleanPath(file?.path);
    if (p && typeof file.content === 'string') contents.set(p, file.content);
  }
  const edges = [], diagnostics = [];
  for (const [from, source] of contents) {
    if (typeof source !== 'string') continue;
    const refs = [];
    if (SOURCE_RE.test(from)) {
      const re = /(?:\bfrom\s*|\bimport\s*(?:\(\s*)?|\brequire\s*\(\s*)['"]([^'"]+)['"]/g;
      for (const m of source.matchAll(re)) refs.push({ specifier: m[1], kind: 'module' });
    }
    if (HTML_RE.test(from)) {
      for (const m of source.matchAll(/<(?:script|link)\b[^>]*(?:src|href)\s*=\s*['"]([^'"]+)['"]/gi)) refs.push({ specifier: m[1], kind: 'html-asset' });
    }
    for (const ref of refs) {
      if (!ref.specifier.startsWith('.') || ref.specifier.startsWith('./#')) continue;
      const options = candidates(from, ref.specifier).map(cleanPath).filter(Boolean);
      const target = options.find((p) => contents.has(p));
      if (target) edges.push({ from, to: target, kind: ref.kind, specifier: ref.specifier });
      else diagnostics.push({ severity: 'warning', code: 'LOCAL_REFERENCE_UNRESOLVED', from, specifier: ref.specifier, candidates: options.slice(0, 5) });
    }
  }
  const nodes = [...contents.keys()].sort();
  return { schema: 'ops-artifact-graph/1', nodes, edges, diagnostics, summary: { files: nodes.length, links: edges.length, warnings: diagnostics.length } };
}
