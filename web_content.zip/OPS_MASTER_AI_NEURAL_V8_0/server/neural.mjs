/** OPS NEURAL CORE — couche déterministe de calcul, mémoire et contrôle qualité.
 * Ce module n'est pas un modèle qui apprend seul : il fiabilise les agents existants
 * avec des outils vérifiables et un contexte commun.
 */
const FUNCTIONS = new Set(['sqrt', 'abs', 'round', 'floor', 'ceil']);

function tokenize(source) {
  const s = String(source).replace(/,/g, '.').replace(/[×·]/g, '*').replace(/[÷]/g, '/').replace(/−/g, '-');
  const out = []; let i = 0;
  while (i < s.length) {
    if (/\s/.test(s[i])) { i++; continue; }
    const n = s.slice(i).match(/^(?:\d+(?:\.\d*)?|\.\d+)(?:e[+-]?\d+)?/i);
    if (n) { out.push({ t: 'num', v: Number(n[0]) }); i += n[0].length; continue; }
    const id = s.slice(i).match(/^[a-z]+/i);
    if (id) { out.push({ t: 'id', v: id[0].toLowerCase() }); i += id[0].length; continue; }
    if ('+-*/^()%'.includes(s[i])) { out.push({ t: s[i++] }); continue; }
    throw new Error(`Symbole non pris en charge : ${s[i]}`);
  }
  return out;
}

function rationalApprox(value, maxDenominator = 1000000) {
  if (Number.isInteger(value)) return `${value}/1`;
  let bestN = Math.round(value), bestD = 1, bestErr = Math.abs(value - bestN);
  for (let d = 2; d <= maxDenominator; d++) {
    const n = Math.round(value * d), err = Math.abs(value - n / d);
    if (err < bestErr) { bestN = n; bestD = d; bestErr = err; }
    if (bestErr < 1e-12) break;
  }
  const gcd = (a,b) => b ? gcd(b, a % b) : Math.abs(a);
  const g = gcd(bestN, bestD);
  return `${bestN/g}/${bestD/g}`;
}

/** Analyse arithmétique sans eval(), Function() ni exécution de code. */
export function calculateExpression(expression) {
  const tokens = tokenize(expression); let i = 0;
  const peek = () => tokens[i]?.t;
  const take = (t) => { if (peek() !== t) throw new Error(`Expression incomplète (attendu ${t})`); return tokens[i++]; };
  const primary = () => {
    if (peek() === '+') { i++; return primary(); }
    if (peek() === '-') { i++; return -primary(); }
    if (peek() === 'num') return take('num').v;
    if (peek() === '(') { i++; const v = sum(); take(')'); return v; }
    if (peek() === 'id') {
      const fn = tokens[i++].v;
      if (!FUNCTIONS.has(fn)) throw new Error(`Fonction inconnue : ${fn}`);
      take('('); const x = sum(); take(')');
      if (fn === 'sqrt') { if (x < 0) throw new Error('Racine carrée négative impossible dans les réels'); return Math.sqrt(x); }
      if (fn === 'abs') return Math.abs(x);
      if (fn === 'round') return Math.round(x);
      if (fn === 'floor') return Math.floor(x);
      return Math.ceil(x);
    }
    throw new Error('Nombre ou parenthèse attendu');
  };
  const power = () => { let a = primary(); if (peek() === '^') { i++; a = a ** power(); } return a; };
  const product = () => { let a = power(); while (peek() === '*' || peek() === '/' || peek() === '%') { const op = tokens[i++].t, b = power(); if ((op === '/' || op === '%') && b === 0) throw new Error('Division par zéro'); a = op === '*' ? a*b : op === '/' ? a/b : a%b; } return a; };
  const sum = () => { let a = product(); while (peek() === '+' || peek() === '-') { const op = tokens[i++].t, b = product(); a = op === '+' ? a+b : a-b; } return a; };
  if (!tokens.length) throw new Error('Expression vide');
  const value = sum(); if (i !== tokens.length) throw new Error('Texte supplémentaire après le calcul');
  if (!Number.isFinite(value)) throw new Error('Résultat non fini');
  return { value, exact: Number.isInteger(value) ? String(value) : Number(value.toPrecision(12)).toString(), fraction: rationalApprox(value) };
}


/** Contrat V3 : mêmes exigences transversales, puis grille métier propre à chaque spécialiste. */
export function aaaDetailContract(agentId = 'general') {
  const common = `OPS NEURAL PRODUCTION CONTRACT V3.0 — OBLIGATOIRE
A. COMPRÉHENSION : reformule l'objectif, le périmètre, les contraintes explicites, les éléments à préserver et les inconnues. N'invente pas une réponse si une précision indispensable manque.
B. CONCEPTION : donne architecture, composants, flux de données, états, paramètres, entrées/sorties, dépendances, interfaces avec les autres spécialistes et ordre d'implémentation.
C. LIVRABLE : fournis une proposition exploitable, exemples concrets, valeurs de départ justifiées, cas normaux, limites, erreurs et récupération. Si tu modifies du code, livre le fichier complet et non un extrait incomplet.
D. INTÉGRATION : indique les agents/moteurs concernés, les contrats d'interface, les événements/API/formats partagés et les éléments qu'ils doivent recevoir. N'attends pas que l'utilisateur répète un contexte déjà disponible.
E. QUALITÉ : critères d'acceptation mesurables, tests positifs/négatifs, non-régression, performance, accessibilité et compatibilité pertinentes. Sépare tests exécutés et tests seulement proposés.
F. AUTO-AMÉLIORATION : effectue une première passe, critique-la, corrige les défauts de ton périmètre, puis fournis une seconde vérification. Si tu ne peux pas réellement corriger, explique exactement pourquoi.
G. PRÉSERVATION : ne supprime, ne remplace et ne simplifie aucune fonction, donnée, interface ou moteur existant. Inspecte avant modification, limite le diff et signale tout conflit. Toute suppression reste soumise à autorisation.
H. PREUVES : distingue explicitement EXISTANT, PROPOSÉ, MODIFIÉ, TESTÉ, NON VÉRIFIÉ. Ne prétends jamais qu'un fichier, asset, appel web, modèle IA, compilation ou test existe sans preuve.
I. FORMAT FINAL : Objectif compris ; Analyse ; Décisions ; Livrable détaillé ; Interfaces inter-IA ; Critères d'acceptation ; Tests/preuves ; Auto-critique et corrections ; Risques/limites ; Prochaine action.`;
  const focus = {
    director: 'Direction de production : découpage en lots, priorité, dépendances sans cycles, attribution multi-spécialités, chemin critique, arbitrage, gestion des blocages, jalons, intégration et décision de sortie. Assure que les spécialistes reçoivent les décisions pertinentes et que les résultats sont consolidés.',
    world: 'World building : échelle et métriques du monde, biomes, quartiers, parcelles, routes, navigation, streaming, intérieurs, points d’intérêt, densité, circulation, météo, jour/nuit, population, mémoire et budgets CPU/GPU.',
    modeling: 'Modélisation : références, échelle, silhouette, topologie, densité polygonale, UV, texel density, matériaux PBR, LOD, pivots, collisions, rig-ready, variantes, nomenclature, formats d’import/export et budgets d’assets.',
    satellite: 'Références géospatiales : provenance et date des images, résolution si connue, relief, hydrographie, végétation, empreinte urbaine, limites d’interprétation, incertitude et traduction en carte fictive. N’infère aucune donnée sensible sur des personnes ou des cibles.',
    webresearch: 'Recherche documentaire : formule les questions, recherche des sources primaires et officielles, compare au moins deux sources lorsque possible, note dates/versions, cite chaque affirmation, repère contradictions et obsolescence, transforme les résultats en recommandations intégrables. Ne prétends pas avoir consulté une URL inaccessible.',
    animation: 'Animation : squelette, hiérarchie, retargeting, IK/FK, state machines, blend spaces, transitions, root motion, synchronisation, événements, cinématiques, contraintes de contact et tests de glissement/rupture.',
    vehicle: 'Véhicules : architecture, moteur, transmission, suspension, pneus, adhérence, freinage, direction, caméra, contrôles, audio événementiel, intérieurs, animation entrée/sortie, consommation de ressources et tests de conduite.',
    npc: 'Moteur NPC : code réellement branché au jeu, cycle de vie des PNJ, états, perception, mémoire courte/longue bornée, navigation adaptée au moteur existant, réactions aux événements, LOD, budgets CPU et tests en jeu.',
    physics: 'Moteur physique : adaptateur vers le moteur réellement utilisé, corps/colliders, collisions, triggers, raycasts, gravité, synchronisation fixe, branchement au Game Loop et tests de non-régression.',
    gameplay: 'Gameplay : boucle principale, contrôles, feedback, états, règles, progression, missions, économie, inventaire, sauvegarde, équilibrage, accessibilité, tutoriel, reprise après échec et tests de scénarios.',
    graphics: 'Graphismes : pipeline de rendu, matériaux, shaders, éclairage, ombres, post-traitement, atmosphère, LOD, occlusion, résolution dynamique, profils par matériel, budgets GPU/VRAM et solutions de repli.',
    story: 'Narration : bible d’univers, chronologie, arcs, motivations, relations, dialogues, embranchements, objectifs, cinématiques, conséquences, localisation et contrôle de continuité.',
    qa: 'QA : matrice de couverture, préconditions, étapes, résultats attendus/observés, sévérité, reproductibilité, tests unitaires/intégration/système, performance, compatibilité, accessibilité, sécurité, sauvegardes et non-régression.'
  };
  const role = focus[agentId] || 'Analyse le domaine concerné et ses interfaces avec les autres métiers OPS.';
  return `${common}\n\nGRILLE MÉTIER ${agentId.toUpperCase()} : ${role}`;
}

const MATH_CUE = /\b(calcul|calcule|calculer|combien font|r[ée]sous|r[ée]soudre|simplifie|fraction|additionne|soustrais|multiplie|divise)\b/i;
export function extractMathExpression(text) {
  const raw = String(text || '').trim();
  if (!MATH_CUE.test(raw)) return null;
  // Garde uniquement une expression arithmétique explicite ; refuse les phrases mixtes.
  const candidates = raw.match(/(?:\d+(?:[.,]\d+)?|\.\d+|sqrt|abs|round|floor|ceil|[()+\-*/^%×÷·−\s])+/gi) || [];
  const candidate = candidates.map(x => x.trim()).filter(x => /\d/.test(x) && /[+*/^%×÷·−-]/.test(x)).sort((a,b)=>b.length-a.length)[0];
  if (!candidate) return null;
  try { return { expression: candidate, ...calculateExpression(candidate) }; } catch { return null; }
}

export function neuralSystemContext({ memories = [], history = [], math = null, analysis = null } = {}) {
  const memoryText = memories.slice(0, 30).map(m => `- ${m.agent_id || 'OPS'} / ${m.key}: ${String(m.value).slice(0, 500)}`).join('\n');
  const historyText = history.slice(-12).map(m => `${m.role}: ${String(m.content).slice(0, 700)}`).join('\n');
  return [
    'OPS NEURAL CORE — règles de fiabilité actives :',
    '1. Comprends la demande avant de répondre ; si une donnée manque, demande une seule précision au lieu de l inventer.',
    '2. Distingue faits vérifiés, hypothèses et éléments non testés. N affirme jamais avoir exécuté une action sans preuve.',
    '3. Pour les calculs, utilise le résultat exact fourni par OPS NEURAL MATH et montre les étapes utiles. Ne remplace pas un calcul vérifiable par une recherche web.',
    '4. Respecte les décisions antérieures du projet dans la mémoire partagée et l historique ci-dessous. En cas de contradiction, privilégie la consigne la plus récente et signale le conflit.',
    '5. Avant livraison, vérifie cohérence, unités, dépendances, fichiers existants et risques de régression. Ne supprime aucune fonctionnalité existante.',
    '6. Cherche un niveau de finition professionnel : détaille les comportements, critères d’acceptation, cas limites, intégration, optimisation et tests. Fais une auto-relecture et améliore ton livrable avant de le rendre.',
    '7. Si tu bloques ou prends trop de temps, expose précisément le blocage et demande l’assistance de OPS DIRECTOR AI plutôt que de livrer une réponse superficielle.',
    '8. Collaboration obligatoire : consigne les décisions qui impactent les autres métiers, nomme les destinataires, définis le contrat d’interface et transmets un résumé actionnable. Ne suppose jamais qu’un autre agent a reçu une information sans accusé ou trace.',
    '9. Gestion des conflits : conserve les exigences utilisateur explicites ; en cas de contradiction entre livrables, suspends l’intégration, décris les deux versions et propose une résolution sans écraser les fonctions.',
    '10. Optimisation : propose un profil de base stable, puis des niveaux de qualité/charge distincts lorsque le matériel ou le projet le nécessite.',
    memoryText ? `MÉMOIRE NEURONALE PARTAGÉE :\n${memoryText}` : 'MÉMOIRE NEURONALE PARTAGÉE : aucune note enregistrée.',
    historyText ? `CONTEXTE RÉCENT DU PROJET :\n${historyText}` : '',
    analysis ? `OPS NEURAL ANALYSIS — PROFIL DE LA DEMANDE :\n${JSON.stringify(analysis, null, 2)}\nTraite les risques et exigences indiqués, sans inventer de vérification.` : '',
    math ? `OPS NEURAL MATH — CALCUL VÉRIFIÉ : ${math.expression} = ${math.fraction} (${math.exact} en décimal). Ce résultat est prioritaire ; explique le calcul sans le modifier.` : ''
  ].filter(Boolean).join('\n\n');
}

/** Analyse déterministe préalable : elle aide le coordinateur à distribuer le travail,
 * sans prétendre remplacer le jugement des modèles configurés. */
const DOMAIN_RULES = [
  { agent: 'architect', label: 'architecture', re: /architect|architecture|structure|conception|module|syst[eè]me|int[eé]gration|refactor/i },
  { agent: 'engine3d', label: 'moteur 3D', re: /moteur|3d|webgl|webgpu|shader|rendu|render|fbx|gltf|physique/i },
  { agent: 'gameplay', label: 'gameplay', re: /gameplay|mission|combat|progression|inventaire|jouabilit[eé]/i },
  { agent: 'npc', label: 'moteur NPC', re: /npc|pnj|personnage non joueur|comportement.*personnage|foule|population/i },
  { agent: 'physics', label: 'moteur physique', re: /physique|collision|gravité|gravite|ragdoll|rigid.?body|raycast|trigger/i },
  { agent: 'art3d', label: 'création 3D', re: /mod[eè]le|texture|mat[eé]riau|environnement|asset|v[eé]hicule|b[aâ]timent|ville/i },
  { agent: 'animation', label: 'animation', re: /animation|squelette|rig|mouvement|locomotion|ragdoll|cin[eé]matique/i },
  { agent: 'audio', label: 'audio', re: /audio|son|voix|musique|spatialisation/i },
  { agent: 'frontend', label: 'interface', re: /interface|ui\b|[eé]cran|css|html|responsive|bouton|menu/i },
  { agent: 'backend', label: 'serveur et données', re: /api|serveur|base de donn[eé]es|sqlite|websocket|authentification/i },
  { agent: 'debug', label: 'diagnostic', re: /bug|erreur|corrig|crash|plante|r[eé]gression|optimis|performance/i },
  { agent: 'quality', label: 'qualité', re: /test|audit|v[eé]rif|qualit[eé]|s[eé]curit[eé]|validation/i },
  { agent: 'webresearch', label: 'recherche documentaire', re: /internet|web|recherche|documentation|source|comparaison|version actuelle/i },
  { agent: 'satellite', label: 'références géospatiales', re: /satellit|relief|terrain|topograph|imagerie|carte|g[eé]ospatial/i },
];

export function analyzeNeuralRequest(request, availableAgents = []) {
  const source = String(request || '').trim();
  const domains = DOMAIN_RULES.filter((r) => r.re.test(source) && (!availableAgents.length || availableAgents.includes(r.agent)));
  const text = source.toLowerCase();
  const risks = [];
  if (/supprim|effac|remplac|r[eé]initialis/.test(text)) risks.push({ id: 'preservation', level: 'high', label: 'Préservation des fonctions et fichiers existants' });
  if (/paiement|mot de passe|auth|compte|donn[eé]es personnelles|token|cl[eé] api/.test(text)) risks.push({ id: 'security', level: 'high', label: 'Sécurité et protection des données' });
  if (/android|mobile|t[eé]l[eé]phone|webgl|3d|jeu|game|ville ouverte/.test(text)) risks.push({ id: 'performance', level: 'medium', label: 'Performance et compatibilité mobile/3D' });
  if (/multijoueur|r[eé]seau|serveur|synchron/.test(text)) risks.push({ id: 'network', level: 'medium', label: 'Réseau, synchronisation et reprise sur erreur' });
  const complexity = Math.min(5, Math.max(1, domains.length + (source.length > 500 ? 1 : 0) + (risks.length > 1 ? 1 : 0)));
  return {
    version: '3.0-neural-analysis', complexity,
    domains: domains.map((d) => ({ agent: d.agent, label: d.label })),
    recommended_agents: domains.map((d) => d.agent), risks,
    requirements: [
      'Inspecter les fichiers et fonctions existants avant toute modification.',
      'Conserver les fonctionnalités existantes et limiter les changements au périmètre demandé.',
      'Partager les décisions, interfaces et livrables utiles avec les autres agents.',
      'Vérifier les résultats avec des tests réellement exécutables et signaler les limites.',
    ],
    confidence: domains.length ? 'règles de domaines détectées' : 'aucun domaine déterminé automatiquement',
  };
}

export function neuralQualityChecklist({ files = [], tasks = [], risks = [] } = {}) {
  const text = tasks.map((t) => `${t.title || ''} ${t.description || ''} ${t.result || ''}`).join('\n');
  const checks = [
    { id: 'coverage', label: 'La demande et ses sous-objectifs sont couverts', evidence: tasks.length > 0 && tasks.some((t) => t.status === 'done' || t.result) },
    { id: 'handoff', label: 'Les dépendances et transmissions entre agents sont identifiées', evidence: tasks.some((t) => (t.depends_on || []).length || /interface|transmission|handoff|autre agent/i.test(`${t.result || ''} ${t.description || ''}`)) || tasks.length <= 1 },
    { id: 'files', label: 'Les fichiers livrés sont identifiés', evidence: files.length > 0 },
    { id: 'preservation', label: 'La préservation des fonctions existantes est documentée', evidence: /préserv|non-régression|non regression|fonctionnalités existantes/i.test(text) },
    { id: 'risk', label: 'Les risques détectés sont explicitement traités', evidence: risks.length === 0 || /risque|limite|mitigation|solution de repli/i.test(text) },
    { id: 'tests', label: 'Les tests et preuves sont explicitement décrits', evidence: /test|preuve|vérifi|verification|validation/i.test(text) },
  ];
  return { checks, score: Math.round(checks.filter((c) => c.evidence).length / checks.length * 100), incomplete: checks.filter((c) => !c.evidence).map((c) => c.id) };
}

export const NEURAL_MODULES = [
  { id:'core', name:'OPS NEURAL CORE', role:'Coordination du raisonnement, des règles et du contexte partagé', mode:'actif' },
  { id:'reasoning', name:'OPS NEURAL REASONING', role:'Analyse des demandes, contraintes, hypothèses et étapes', mode:'actif' },
  { id:'math', name:'OPS NEURAL MATH', role:'Calcul déterministe : fractions, décimaux, priorités, puissances et racines', mode:'actif' },
  { id:'memory', name:'OPS NEURAL MEMORY', role:'Réutilisation de la mémoire et de l’historique du projet', mode:'actif' },
  { id:'verification', name:'OPS NEURAL VERIFICATION', role:'Contrôle de cohérence, preuves et affirmations', mode:'actif' },
  { id:'planner', name:'OPS NEURAL PLANNER', role:'Découpage des tâches, dépendances et spécialistes recommandés', mode:'actif' },
  { id:'collaboration', name:'OPS NEURAL COLLABORATION', role:'Partage du contexte, transmissions et coordination inter-agents', mode:'actif' },
  { id:'quality', name:'OPS NEURAL QUALITY GATE', role:'Contrôle des livrables, couverture et risques avant validation', mode:'actif' },
  { id:'preservation', name:'OPS NEURAL PRESERVATION', role:'Détection des risques de régression et protection des fonctions existantes', mode:'actif' },
  { id:'security', name:'OPS NEURAL SECURITY', role:'Repérage des sujets sensibles et vérifications de sécurité', mode:'actif' },
  { id:'performance', name:'OPS NEURAL PERFORMANCE', role:'Contrôles de performance, mémoire et compatibilité mobile/3D', mode:'actif' },
  { id:'recovery', name:'OPS NEURAL RECOVERY', role:'Reprise des tâches échouées et traçabilité des tentatives', mode:'actif' },
  { id:'consistency', name:'OPS NEURAL CONSISTENCY', role:'Cohérence des décisions, interfaces et résultats entre spécialistes', mode:'actif' },
  { id:'learning', name:'OPS NEURAL KNOWLEDGE', role:'Capitalisation contrôlée des décisions et retours de projet', mode:'actif' },
  { id:'interfaces', name:'OPS NEURAL INTERFACE CONTRACTS', role:'Contrats d’interface, formats et dépendances entre moteurs', mode:'actif' },
  { id:'evidence', name:'OPS NEURAL EVIDENCE TRACKER', role:'Traçabilité des preuves, sources, tests et limites', mode:'actif' },
  { id:'regression', name:'OPS NEURAL REGRESSION GUARD', role:'Comparaison avant/après et protection des fonctionnalités existantes', mode:'actif' },
  { id:'resource', name:'OPS NEURAL RESOURCE PLANNER', role:'Budgets CPU, GPU, mémoire, réseau et profils matériels', mode:'actif' },
];
