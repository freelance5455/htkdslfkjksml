import { now, pj, extractJson, trunc } from './util.mjs';
import { systemPromptFor } from './agents.mjs';

/** Suivi d'avancement, détection des tâches bloquées, relance, rapports et suggestions.
 *  Rien ici ne contourne les autorisations : l'automatisation ne peut ni approuver un fichier ni activer l'exécution de code. */
export function createAutomation(ctx) {
  const { db, workspace, orchestrator, providers } = ctx;
  let timer = null;

  async function progress(pid) {
    const p = await workspace.getProject(pid);
    const tasks = await db.all("SELECT status,COUNT(*) AS n FROM tasks WHERE project_id=? GROUP BY status", [pid]);
    const counts = Object.fromEntries(tasks.map((t) => [t.status, Number(t.n)]));
    const stalled = await db.all("SELECT id,agent_id,title,started FROM tasks WHERE project_id=? AND status='running' AND started<?", [pid, now() - ctx.config.stallMs]);
    const blocked = await db.all("SELECT id,agent_id,title,error FROM tasks WHERE project_id=? AND status IN ('blocked','error') ORDER BY updated DESC LIMIT 20", [pid]);
    const pending = Number((await db.get("SELECT COUNT(*) AS n FROM approvals WHERE project_id=? AND status='pending'", [pid])).n);
    const lastRun = await db.get('SELECT id,status,created,instruction FROM runs WHERE project_id=? ORDER BY created DESC LIMIT 1', [pid]);
    const lastTest = await db.get("SELECT ts,passed,kind FROM test_reports WHERE project_id=? ORDER BY ts DESC LIMIT 1", [pid]);
    const lastVersion = await db.get('SELECT created,label FROM versions WHERE project_id=? ORDER BY created DESC LIMIT 1', [pid]);
    const deps = await workspace.dependencies(pid);
    const agentErrors = await db.all("SELECT agent_id,COUNT(*) AS n FROM tasks WHERE project_id=? AND status='error' GROUP BY agent_id", [pid]);
    const files = workspace.tree(pid).filter((e) => e.type === 'file').length;

    const suggestions = [];
    if (pending) suggestions.push(`${pending} modification(s) de fichier attendent votre autorisation (écran Centre de développement).`);
    if (stalled.length) suggestions.push(`${stalled.length} tâche(s) semblent bloquées depuis plus de ${Math.round(ctx.config.stallMs / 60000)} min : relancez l'exécution.`);
    if (blocked.length) suggestions.push(`${blocked.length} tâche(s) en erreur/bloquées : vérifiez le fournisseur IA des agents concernés (${[...new Set(blocked.map((b) => b.agent_id))].join(', ')}).`);
    if (files && !lastVersion) suggestions.push('Aucune sauvegarde de version : créez-en une avant de laisser les agents modifier le projet.');
    if (files && (!lastTest || now() - lastTest.ts > 7 * 864e5)) suggestions.push('Aucun test récent : lancez le Centre de tests (syntaxe + non-régression).');
    if (lastTest && !lastTest.passed) suggestions.push('Le dernier test a échoué : corrigez avant de continuer (agent OPS SENIOR DEBUG CODER).');
    if (!files) suggestions.push("Le workspace est vide : importez des fichiers ou demandez à l'équipe de créer la structure initiale.");
    if (!suggestions.length) suggestions.push('Aucune alerte. Prochaine étape : donner une nouvelle instruction à l\'équipe.');
    return {
      project: { id: p.id, name: p.name }, files, task_counts: counts, stalled, blocked, pending_approvals: pending, last_run: lastRun, last_test: lastTest ? { ...lastTest, passed: !!lastTest.passed } : null,
      last_version: lastVersion, dependencies: deps, agent_errors: agentErrors, suggestions,
    };
  }

  /** Suggestions IA (coordinateur) à partir du rapport factuel — déclenché explicitement par l'utilisateur. */
  async function aiSuggestions(pid) {
    const rep = await progress(pid);
    const coord = await db.get("SELECT * FROM agents WHERE id='coordinator'");
    const r = await providers.chat(coord, [
      { role: 'system', content: systemPromptFor(coord) },
      { role: 'user', content: `Voici l'état factuel du projet :\n${trunc(JSON.stringify(rep), 6000)}\n\nPropose 3 à 6 prochaines améliorations priorisées, chacune avec l'agent OPS le plus adapté. Réponds en markdown, sans rien inventer au-delà de ces données.` },
    ]);
    return { report: rep, suggestions: r.text };
  }

  async function tick() {
    // tâches « running » sans activité depuis trop longtemps alors que l'exécution n'est plus active côté serveur
    const rows = await db.all("SELECT t.id,t.run_id FROM tasks t WHERE t.status='running' AND t.started<?", [now() - ctx.config.stallMs]);
    for (const t of rows) {
      if (orchestrator.isActive(t.run_id)) continue; // en cours réel : on laisse (timeout fournisseur)
      await db.run("UPDATE tasks SET status='error', error='Tâche bloquée (aucune exécution active)', updated=? WHERE id=?", [now(), t.id]);
      await workspace.log(null, 'automation', 'task.stalled', t.id);
    }
  }

  return {
    progress, aiSuggestions, tick,
    start() { if (!timer) { timer = setInterval(() => tick().catch(() => {}), 30000); timer.unref(); } },
    stop() { if (timer) clearInterval(timer); timer = null; },
  };
}
export { pj, extractJson };
