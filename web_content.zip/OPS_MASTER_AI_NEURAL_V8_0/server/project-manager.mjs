/** Gestionnaire de projet OPS : agrège les tâches, dépendances, agents et blocages. */
const TERMINAL = new Set(['done','cancelled','completed','failed']);
const ACTIVE = new Set(['queued','accepted','in_progress','running','review','blocked','pending']);
const asJson = (v, fallback = []) => { try { return typeof v === 'string' ? JSON.parse(v) : (v ?? fallback); } catch { return fallback; } };

export function buildProjectManagerReport({ project, tasks = [], directorTasks = [], workItems = [], agents = [], dependencies = [], claims = [], now = Date.now(), staleAfterMs = 20 * 60_000 }) {
  const agentMap = new Map(agents.map(a => [a.id, a]));
  const taskRows = tasks.map(t => ({ id:t.id, source:'orchestrator', title:t.title, agent_id:t.agent_id, status:t.status, updated:Number(t.updated || t.started || t.created || 0), error:t.error || null, depends_on:asJson(t.depends_on), priority:null }));
  const directorRows = directorTasks.map(t => ({ id:t.id, source:'director', title:t.title, agent_id:t.assignee, status:t.status, updated:Number(t.updated || t.started || t.created || 0), error:null, depends_on:asJson(t.depends_on), priority:Number(t.priority || 0), plan_id:t.plan_id }));
  const handoffRows = workItems.map(w => ({ id:w.id, source:'collaboration', title:w.title, agent_id:w.to_agent, from_agent:w.from_agent, status:w.status, updated:Number(w.updated || w.created || 0), error:null, depends_on:asJson(w.depends_on), priority:null }));
  const all = [...taskRows, ...directorRows, ...handoffRows];
  const stale = all.filter(t => ['running','in_progress'].includes(t.status) && t.updated > 0 && now - t.updated > staleAfterMs).map(t => ({ ...t, stale_minutes:Math.floor((now-t.updated)/60000) }));
  const blocked = all.filter(t => ['blocked','error','failed'].includes(t.status));
  const queued = all.filter(t => ['queued','pending','accepted','ready','waiting_deps'].includes(t.status));
  const busy = new Set(all.filter(t => ['running','in_progress'].includes(t.status)).map(t => t.agent_id).filter(Boolean));
  const availableAgents = agents.filter(a => !!a.enabled && !busy.has(a.id)).map(a => ({ id:a.id, name:a.name, role:a.role }));
  const recommendations = [];
  for (const t of stale) recommendations.push({ severity:'warning', code:'STALE_TASK', task_id:t.id, source:t.source, title:t.title, message:`Tâche sans mise à jour depuis ${t.stale_minutes} minutes. Vérifier son exécution avant de la relancer.`, suggested_agent:t.agent_id || null });
  for (const t of blocked) recommendations.push({ severity:'high', code:'BLOCKED_TASK', task_id:t.id, source:t.source, title:t.title, message:`Tâche ${t.status}${t.error ? ` : ${String(t.error).slice(0,180)}` : ''}. Identifier la cause et ses dépendances.`, suggested_agent:t.agent_id || null });
  const activeClaims = claims.filter(c => c.status === 'active');
  for (const c of activeClaims) recommendations.push({ severity:'info', code:'ACTIVE_FILE_CLAIM', title:c.path, message:`Fichier réservé par ${c.agent_id}. Éviter une modification concurrente.`, suggested_agent:c.agent_id });
  const pendingByAgent = new Map();
  for (const w of workItems.filter(w => !TERMINAL.has(w.status))) pendingByAgent.set(w.to_agent,(pendingByAgent.get(w.to_agent)||0)+1);
  const dependencyEdges = dependencies.map(d => ({ prerequisite:d.prerequisite, dependent:d.dependent, contract:d.contract || '' }));
  const load = agents.map(a => ({ id:a.id, name:a.name, enabled:!!a.enabled, running:all.filter(t=>t.agent_id===a.id && ['running','in_progress'].includes(t.status)).length, pending:pendingByAgent.get(a.id)||0, queued:all.filter(t=>t.agent_id===a.id && ['queued','pending','accepted'].includes(t.status)).length }));
  const priorityQueue = queued.map(t => ({ ...t, suggested_priority: t.status === 'waiting_deps' ? 'low' : (stale.some(s=>s.id===t.id)?'urgent':'normal'), agent_available: !!agentMap.get(t.agent_id)?.enabled && !busy.has(t.agent_id) })).sort((a,b) => (a.suggested_priority==='urgent'?-1:0)-(b.suggested_priority==='urgent'?-1:0) || a.updated-b.updated);
  const total = all.length, done = all.filter(t=>t.status==='done'||t.status==='completed').length;
  return { schema:'ops.project-manager.v1', project:{ id:project.id, name:project.name }, generated_at:now, summary:{ total, done, active:all.filter(t=>['running','in_progress','review'].includes(t.status)).length, queued:queued.length, blocked:blocked.length, stale:stale.length, active_file_claims:activeClaims.length, completion_percent:total?Math.round(done/total*100):0 }, tasks:{ blocked, stale, queue:priorityQueue }, agents:load, available_agents:availableAgents, dependencies:dependencyEdges, recommendations };
}

export function createProjectManager(ctx) {
  const { db, collaboration } = ctx;
  async function report(projectId) {
    const project = await db.get('SELECT id,name FROM projects WHERE id=?',[projectId]);
    if (!project) { const { HttpError } = await import('./util.mjs'); throw new HttpError(404,'Projet introuvable'); }
    const [tasks,directorTasks,workItems,agents,dependencies,claims] = await Promise.all([
      db.all('SELECT id,title,agent_id,status,updated,started,created,error,depends_on FROM tasks WHERE project_id=? ORDER BY created DESC LIMIT 500',[projectId]),
      db.all('SELECT id,plan_id,title,assignee,status,updated,started,created,priority,depends_on FROM director_tasks WHERE project_id=? ORDER BY created DESC LIMIT 500',[projectId]),
      collaboration.listWorkItems(projectId,{limit:250}),
      db.all('SELECT id,name,role,enabled FROM agents ORDER BY sort_order'),
      collaboration.listDependencies(projectId),
      collaboration.listArtifactClaims(projectId,{activeOnly:true}),
    ]);
    return buildProjectManagerReport({project,tasks,directorTasks,workItems,agents,dependencies,claims});
  }
  async function dispatch(projectId,{to,title,instruction,from='project_manager',depends_on=[]}={}) {
    const snapshot=await report(projectId);
    const agent=snapshot.available_agents.find(a=>a.id===to);
    if(!agent) { const { HttpError }=await import('./util.mjs'); throw new HttpError(409,'Agent indisponible ou déjà occupé'); }
    return collaboration.createWorkItem(projectId,{from,to,title,instruction,depends_on});
  }
  return { report, dispatch };
}
