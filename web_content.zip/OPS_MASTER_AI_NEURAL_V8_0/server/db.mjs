import fs from 'node:fs';
import path from 'node:path';

const SCHEMA = `
CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT);
CREATE TABLE IF NOT EXISTS providers(id TEXT PRIMARY KEY, name TEXT NOT NULL, kind TEXT NOT NULL, base_url TEXT, model TEXT, key_enc TEXT, key_hint TEXT, enabled INTEGER DEFAULT 1, max_tokens_day BIGINT DEFAULT 0, created BIGINT);
CREATE TABLE IF NOT EXISTS projects(id TEXT PRIMARY KEY, name TEXT NOT NULL, description TEXT, agents TEXT, dependencies TEXT, write_mode TEXT DEFAULT 'approval', allow_exec INTEGER DEFAULT 0, archived INTEGER DEFAULT 0, created BIGINT, updated BIGINT);
CREATE TABLE IF NOT EXISTS agents(id TEXT PRIMARY KEY, name TEXT, role TEXT, system_prompt TEXT, provider_id TEXT, model TEXT, enabled INTEGER DEFAULT 1, sort_order INTEGER);
CREATE TABLE IF NOT EXISTS runs(id TEXT PRIMARY KEY, project_id TEXT, instruction TEXT, mode TEXT, status TEXT, plan TEXT, report TEXT, error TEXT, created BIGINT, finished BIGINT);
CREATE TABLE IF NOT EXISTS tasks(id TEXT PRIMARY KEY, run_id TEXT, project_id TEXT, agent_id TEXT, title TEXT, instruction TEXT, status TEXT, depends_on TEXT, result TEXT, error TEXT, attempts INTEGER DEFAULT 0, round INTEGER DEFAULT 0, created BIGINT, started BIGINT, finished BIGINT, updated BIGINT);
CREATE TABLE IF NOT EXISTS messages(id TEXT PRIMARY KEY, project_id TEXT, run_id TEXT, agent_id TEXT, role TEXT, content TEXT, created BIGINT);
CREATE TABLE IF NOT EXISTS memory(id TEXT PRIMARY KEY, project_id TEXT, agent_id TEXT, key TEXT, value TEXT, created BIGINT);
CREATE TABLE IF NOT EXISTS experience_memory(id TEXT PRIMARY KEY, project_id TEXT, agent_id TEXT, domain TEXT, lesson TEXT, evidence TEXT, status TEXT DEFAULT 'pending', source_task TEXT, created BIGINT, reviewed BIGINT);
CREATE TABLE IF NOT EXISTS experience_events(id TEXT PRIMARY KEY, experience_id TEXT, project_id TEXT, task_id TEXT, event TEXT, created BIGINT);
CREATE TABLE IF NOT EXISTS benchmark_snapshots(id TEXT PRIMARY KEY, project_id TEXT NOT NULL, created BIGINT NOT NULL, report TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS supervisor_actions(id TEXT PRIMARY KEY, project_id TEXT NOT NULL, kind TEXT NOT NULL, task_id TEXT, path TEXT, agent_id TEXT, detail TEXT, created BIGINT);
CREATE INDEX IF NOT EXISTS idx_supervisor_project_created ON supervisor_actions(project_id, created);
CREATE TABLE IF NOT EXISTS collaboration_events(id TEXT PRIMARY KEY, project_id TEXT NOT NULL, type TEXT NOT NULL, from_agent TEXT NOT NULL, to_agent TEXT, payload TEXT NOT NULL, created BIGINT);
CREATE INDEX IF NOT EXISTS idx_collab_project_created ON collaboration_events(project_id, created);
CREATE TABLE IF NOT EXISTS collaboration_work_items(id TEXT PRIMARY KEY, project_id TEXT NOT NULL, from_agent TEXT NOT NULL, to_agent TEXT NOT NULL, title TEXT NOT NULL, instruction TEXT NOT NULL, status TEXT NOT NULL, depends_on TEXT NOT NULL, result TEXT, created BIGINT, updated BIGINT);
CREATE INDEX IF NOT EXISTS idx_collab_work_project_status ON collaboration_work_items(project_id, status, created);
CREATE INDEX IF NOT EXISTS idx_collab_work_recipient ON collaboration_work_items(project_id, to_agent, status);
CREATE TABLE IF NOT EXISTS collaboration_artifact_claims(id TEXT PRIMARY KEY, project_id TEXT NOT NULL, path TEXT NOT NULL, agent_id TEXT NOT NULL, work_item_id TEXT, status TEXT NOT NULL, created BIGINT, updated BIGINT, UNIQUE(project_id, path));
CREATE TABLE IF NOT EXISTS engine_dependencies(id TEXT PRIMARY KEY, project_id TEXT NOT NULL, prerequisite TEXT NOT NULL, dependent TEXT NOT NULL, contract TEXT, created BIGINT, UNIQUE(project_id, prerequisite, dependent));
CREATE TABLE IF NOT EXISTS production_pipelines(id TEXT PRIMARY KEY, project_id TEXT NOT NULL, run_id TEXT NOT NULL, title TEXT NOT NULL, brief TEXT NOT NULL, status TEXT NOT NULL, baseline_version_id TEXT NOT NULL, checks TEXT, final_version_id TEXT, created BIGINT, updated BIGINT);
CREATE TABLE IF NOT EXISTS bug_fix_jobs(id TEXT PRIMARY KEY, project_id TEXT NOT NULL, report_id TEXT NOT NULL, run_id TEXT NOT NULL, baseline_version_id TEXT NOT NULL, status TEXT NOT NULL, created BIGINT, updated BIGINT);
CREATE TABLE IF NOT EXISTS bug_fix_cycles(id TEXT PRIMARY KEY, job_id TEXT NOT NULL, cycle INTEGER NOT NULL, report_id TEXT NOT NULL, run_id TEXT NOT NULL, baseline_version_id TEXT NOT NULL, status TEXT NOT NULL, created BIGINT, updated BIGINT, UNIQUE(job_id, cycle));
CREATE INDEX IF NOT EXISTS idx_bug_fix_cycles_job ON bug_fix_cycles(job_id, cycle);
CREATE INDEX IF NOT EXISTS idx_production_project_created ON production_pipelines(project_id, created);
CREATE TABLE IF NOT EXISTS journal(id TEXT PRIMARY KEY, ts BIGINT, project_id TEXT, actor TEXT, action TEXT, detail TEXT);
CREATE TABLE IF NOT EXISTS approvals(id TEXT PRIMARY KEY, project_id TEXT, run_id TEXT, task_id TEXT, agent_id TEXT, kind TEXT, path TEXT, content TEXT, status TEXT, note TEXT, created BIGINT, decided BIGINT);
CREATE TABLE IF NOT EXISTS versions(id TEXT PRIMARY KEY, project_id TEXT, label TEXT, reason TEXT, files BIGINT, bytes BIGINT, created BIGINT);
CREATE TABLE IF NOT EXISTS changes(id TEXT PRIMARY KEY, project_id TEXT, path TEXT, action TEXT, before_file TEXT, after_hash TEXT, actor TEXT, undone INTEGER DEFAULT 0, ts BIGINT);
CREATE TABLE IF NOT EXISTS usage(id TEXT PRIMARY KEY, ts BIGINT, provider_id TEXT, agent_id TEXT, prompt_tokens BIGINT, completion_tokens BIGINT, ok INTEGER, error TEXT);
CREATE TABLE IF NOT EXISTS test_reports(id TEXT PRIMARY KEY, project_id TEXT, ts BIGINT, kind TEXT, passed INTEGER, summary TEXT, detail TEXT);
CREATE TABLE IF NOT EXISTS library_items(id TEXT PRIMARY KEY, name TEXT NOT NULL, mime TEXT, size BIGINT, sha1 TEXT, tags TEXT, description TEXT, project_id TEXT, created BIGINT);
CREATE TABLE IF NOT EXISTS studio_ais(id TEXT PRIMARY KEY, name TEXT, domain TEXT, status TEXT, provider_id TEXT, model TEXT, built_at BIGINT, validated_at BIGINT, sort_order INTEGER);
CREATE TABLE IF NOT EXISTS director_plans(id TEXT PRIMARY KEY, project_id TEXT, title TEXT, brief TEXT, source TEXT, status TEXT, created BIGINT);
CREATE TABLE IF NOT EXISTS director_tasks(id TEXT PRIMARY KEY, plan_id TEXT, project_id TEXT, title TEXT, description TEXT, assignee TEXT, priority INTEGER, status TEXT, depends_on TEXT, result TEXT, estimate_h REAL, created BIGINT, updated BIGINT, started BIGINT, finished BIGINT);
CREATE TABLE IF NOT EXISTS studio_messages(id TEXT PRIMARY KEY, project_id TEXT, task_id TEXT, from_ai TEXT, to_ai TEXT, kind TEXT, body TEXT, refs TEXT, status TEXT, created BIGINT);
CREATE TABLE IF NOT EXISTS worlds(id TEXT PRIMARY KEY, project_id TEXT, name TEXT, seed TEXT, params TEXT, stats TEXT, valid INTEGER, issues TEXT, folder TEXT, files_mode TEXT, task_id TEXT, created BIGINT);
CREATE TABLE IF NOT EXISTS assets(id TEXT PRIMARY KEY, project_id TEXT, type TEXT, name TEXT, params TEXT, stats TEXT, valid INTEGER, issues TEXT, folder TEXT, files TEXT, files_mode TEXT, world_id TEXT, task_id TEXT, created BIGINT);
CREATE TABLE IF NOT EXISTS engines(id TEXT PRIMARY KEY, project_id TEXT, name TEXT, kind TEXT, endpoint TEXT, exchange_dir TEXT, formats TEXT, status TEXT, last_check BIGINT, detail TEXT, created BIGINT);
CREATE INDEX IF NOT EXISTS idx_dtasks_plan ON director_tasks(plan_id);
CREATE INDEX IF NOT EXISTS idx_tasks_run ON tasks(run_id);
CREATE INDEX IF NOT EXISTS idx_msg_proj ON messages(project_id, created);
CREATE INDEX IF NOT EXISTS idx_journal_proj ON journal(project_id, ts);
`;

async function openSqlite(dataDir) {
  const { DatabaseSync } = await import('node:sqlite');
  const db = new DatabaseSync(path.join(dataDir, 'ops.db'));
  db.exec('PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON; PRAGMA busy_timeout=5000;');
  const plain = (r) => (r ? { ...r } : r);
  return {
    kind: 'sqlite',
    all: async (sql, p = []) => db.prepare(sql).all(...p).map(plain),
    get: async (sql, p = []) => plain(db.prepare(sql).get(...p)) ?? null,
    run: async (sql, p = []) => { const r = db.prepare(sql).run(...p); return { changes: Number(r.changes) }; },
    exec: async (sql) => db.exec(sql),
    close: async () => db.close(),
  };
}

/** Adaptateur PostgreSQL (OPS_DATABASE_URL). Nécessite `npm install pg`. Non testé dans l'environnement de livraison. */
async function openPg(url) {
  let pg;
  try { pg = await import('pg'); } catch { throw new Error("OPS_DATABASE_URL est défini mais le paquet 'pg' n'est pas installé (npm install pg)."); }
  const P = pg.default || pg;
  P.types.setTypeParser(20, (v) => Number(v));
  const pool = new P.Pool({ connectionString: url });
  const conv = (sql) => { let i = 0; return sql.replace(/\?/g, () => '$' + (++i)); };
  return {
    kind: 'postgresql',
    all: async (sql, p = []) => (await pool.query(conv(sql), p)).rows,
    get: async (sql, p = []) => (await pool.query(conv(sql), p)).rows[0] ?? null,
    run: async (sql, p = []) => ({ changes: (await pool.query(conv(sql), p)).rowCount }),
    exec: async (sql) => { for (const s of sql.split(';').map((x) => x.trim()).filter(Boolean)) await pool.query(s); },
    close: async () => pool.end(),
  };
}

export async function openDb(config) {
  fs.mkdirSync(config.dataDir, { recursive: true });
  const db = config.databaseUrl ? await openPg(config.databaseUrl) : await openSqlite(config.dataDir);
  await db.exec(SCHEMA);
  return db;
}
