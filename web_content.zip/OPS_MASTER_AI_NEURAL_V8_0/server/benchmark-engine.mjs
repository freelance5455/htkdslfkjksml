/** OPS AI Performance & Benchmark Engine — mesures observées, sans notes inventées. */
import { uid, now } from './util.mjs';

const n = (v) => Number(v || 0);
const pct = (a,b) => b ? Math.round(a / b * 100) : null;

export function scoreAgentMetrics({ total=0, done=0, failed=0, retries=0, avgDurationMs=null, tokens=0 } = {}) {
  const completed = n(done) + n(failed);
  const successRate = pct(done, completed);
  const retryRate = n(total) > 0 ? pct(retries, total) : null;
  // Score composite explicable ; les données absentes restent null et ne sont pas pénalisées.
  const components = [];
  if (successRate !== null) components.push({ weight: 0.65, value: successRate });
  if (retryRate !== null) components.push({ weight: 0.20, value: 100 - Math.min(100, retryRate) });
  if (avgDurationMs !== null) components.push({ weight: 0.15, value: Math.max(0, 100 - Math.min(100, avgDurationMs / 60000)) });
  const weight = components.reduce((s,x)=>s+x.weight,0);
  return { score: weight ? Math.round(components.reduce((s,x)=>s+x.weight*x.value,0)/weight) : null, success_rate: successRate, retry_rate: retryRate, sample_size: completed, confidence: completed >= 20 ? 'élevée' : completed >= 5 ? 'moyenne' : completed > 0 ? 'faible' : 'insuffisante' };
}

export function createBenchmarkEngine({ db, workspace }) {
  return {
    async report(projectId) {
      const rows = await db.all(`SELECT t.agent_id, COUNT(*) total,
        SUM(CASE WHEN t.status IN ('done','completed') THEN 1 ELSE 0 END) done,
        SUM(CASE WHEN t.status IN ('error','failed') THEN 1 ELSE 0 END) failed,
        SUM(CASE WHEN t.status IN ('done','completed','error','failed') THEN 1 ELSE 0 END) finished,
        SUM(CASE WHEN t.attempts>1 THEN t.attempts-1 ELSE 0 END) retries,
        AVG(CASE WHEN t.started IS NOT NULL AND t.finished IS NOT NULL AND t.finished>=t.started THEN t.finished-t.started END) avg_duration_ms
        FROM tasks t WHERE t.project_id=? GROUP BY t.agent_id ORDER BY t.agent_id`, [projectId]);
      const usage = await db.all(`SELECT agent_id, COUNT(*) calls, SUM(COALESCE(prompt_tokens,0)+COALESCE(completion_tokens,0)) tokens,
        SUM(CASE WHEN ok=1 THEN 1 ELSE 0 END) successful_calls,
        SUM(CASE WHEN ok=0 THEN 1 ELSE 0 END) failed_calls FROM usage WHERE agent_id IN (SELECT DISTINCT agent_id FROM tasks WHERE project_id=?) GROUP BY agent_id`, [projectId]);
      const byUsage = new Map(usage.map(x=>[x.agent_id,x]));
      const agents = rows.map(r => {
        const u=byUsage.get(r.agent_id)||{};
        const metrics=scoreAgentMetrics({total:r.total,done:r.done,failed:r.failed,retries:r.retries,avgDurationMs:r.avg_duration_ms==null?null:n(r.avg_duration_ms)});
        return {agent_id:r.agent_id,total:n(r.total),done:n(r.done),failed:n(r.failed),finished:n(r.finished),retries:n(r.retries),avg_duration_ms:r.avg_duration_ms==null?null:Math.round(n(r.avg_duration_ms)),tokens:n(u.tokens),provider_calls:n(u.calls),provider_success_rate:pct(n(u.successful_calls),n(u.calls)),...metrics};
      });
      const totals=agents.reduce((a,x)=>({tasks:a.tasks+x.total,done:a.done+x.done,failed:a.failed+x.failed,retries:a.retries+x.retries,tokens:a.tokens+x.tokens}),{tasks:0,done:0,failed:0,retries:0,tokens:0});
      const finished=totals.done+totals.failed;
      return {project_id:projectId,generated_at:now(),methodology:{score:'Score composite pondéré : réussite 65 %, faible taux de relance 20 %, durée 15 % lorsque mesurable. Les composantes absentes sont exclues.',limitations:['Les tâches encore en cours ne comptent pas comme réussites ou échecs.','La durée dépend des horodatages enregistrés et ne mesure pas la difficulté du travail.','Les tokens proviennent des journaux fournisseur disponibles ; leur absence ne signifie pas zéro consommation.','Le score ne compare pas équitablement des rôles ou difficultés différents.']},summary:{...totals,success_rate:pct(totals.done,finished),agents_measured:agents.length},agents};
    },
    async snapshot(projectId) {
      const report=await this.report(projectId); const id=uid('bench_');
      await db.run('INSERT INTO benchmark_snapshots(id,project_id,created,report) VALUES(?,?,?,?)',[id,projectId,now(),JSON.stringify(report)]);
      await workspace?.log(projectId,'OPS BENCHMARK','benchmark.snapshot',`${id} — ${report.summary.tasks} tâches observées`);
      return {id,report};
    },
    async history(projectId) { return db.all('SELECT id,created,report FROM benchmark_snapshots WHERE project_id=? ORDER BY created DESC LIMIT 30',[projectId]); }
  };
}
