import dns from 'node:dns/promises';
import net from 'node:net';
import { decrypt, encrypt } from './keys.mjs';
import { HttpError } from './util.mjs';

/** Recherche Web (Tavily ou Brave, clés côté serveur) et lecture de documentation avec protection SSRF. */

export function isPrivateIp(ip) {
  if (net.isIPv4(ip)) {
    const [a, b] = ip.split('.').map(Number);
    return a === 10 || a === 127 || a === 0 || (a === 169 && b === 254) || (a === 172 && b >= 16 && b <= 31) || (a === 192 && b === 168) || (a === 100 && b >= 64 && b <= 127) || a >= 224;
  }
  if (net.isIPv6(ip)) {
    const x = ip.toLowerCase();
    if (x === '::1' || x === '::' || x.startsWith('fe80') || x.startsWith('fc') || x.startsWith('fd')) return true;
    const m = x.match(/^::ffff:(\d+\.\d+\.\d+\.\d+)$/);
    return m ? isPrivateIp(m[1]) : false;
  }
  return true;
}

export async function assertPublicUrl(raw) {
  let u;
  try { u = new URL(raw); } catch { throw new HttpError(400, 'URL invalide'); }
  if (!/^https?:$/.test(u.protocol)) throw new HttpError(400, 'Seuls http(s) sont autorisés');
  if (u.username || u.password) throw new HttpError(400, "Identifiants dans l'URL interdits");
  const host = u.hostname.replace(/^\[|\]$/g, '');
  const addrs = net.isIP(host) ? [{ address: host }] : await dns.lookup(host, { all: true }).catch(() => { throw new HttpError(400, 'Hôte introuvable'); });
  if (!addrs.length || addrs.some((a) => isPrivateIp(a.address))) throw new HttpError(403, 'Adresse privée/locale refusée (protection SSRF)');
  return u;
}

function htmlToText(html) {
  return html.replace(/<(script|style|noscript|svg)[\s\S]*?<\/\1>/gi, ' ').replace(/<\/(p|div|h[1-6]|li|tr|br|pre)>/gi, '\n').replace(/<[^>]+>/g, ' ')
    .replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#39;/g, "'")
    .replace(/[ \t]+/g, ' ').replace(/\n\s*\n+/g, '\n\n').trim();
}

export function normalizeSearchResults(items, limit = 5) {
  const seen = new Set();
  const out = [];
  for (const item of Array.isArray(items) ? items : []) {
    let url;
    try { url = new URL(String(item.url || '')); } catch { continue; }
    if (!/^https?:$/.test(url.protocol) || seen.has(url.href)) continue;
    seen.add(url.href);
    out.push({ title: String(item.title || url.hostname).slice(0, 300), url: url.href, snippet: String(item.snippet || '').slice(0, 2400) });
    if (out.length >= Math.max(1, Math.min(10, Number(limit) || 5))) break;
  }
  return out;
}

export function createWeb(ctx) {
  const { db, config } = ctx;
  const cache = new Map();
  const inFlight = new Map();
  const CACHE_TTL = 5 * 60 * 1000;
  const CACHE_MAX = 100;
  const getSet = async (k) => (await db.get('SELECT value FROM settings WHERE key=?', [k]))?.value || '';
  return {
    async status() {
      const provider = (await getSet('web_provider')) || process.env.OPS_WEB_SEARCH_PROVIDER || '';
      const hasKey = !!(await getSet('web_key_enc')) || !!(provider === 'tavily' ? process.env.TAVILY_API_KEY : provider === 'brave' ? process.env.BRAVE_SEARCH_API_KEY : '');
      return { provider, configured: !!provider && hasKey };
    },
    async configure({ provider, api_key }) {
      if (provider && !['tavily', 'brave'].includes(provider)) throw new HttpError(400, 'provider : tavily ou brave');
      if (provider) await db.run("INSERT INTO settings(key,value) VALUES('web_provider',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", [provider]);
      if (api_key) await db.run("INSERT INTO settings(key,value) VALUES('web_key_enc',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", [encrypt(config.secret, api_key)]);
    },
    async search(query, limit = 5) {
      query = String(query || '').trim().slice(0, 500);
      if (!query) throw new HttpError(400, 'Requête vide');
      limit = Math.max(1, Math.min(10, Number.isFinite(Number(limit)) ? Math.trunc(Number(limit)) : 5));
      const provider = (await getSet('web_provider')) || process.env.OPS_WEB_SEARCH_PROVIDER || '';
      const enc = await getSet('web_key_enc');
      const key = enc ? decrypt(config.secret, enc) : provider === 'tavily' ? process.env.TAVILY_API_KEY : process.env.BRAVE_SEARCH_API_KEY;
      if (!provider || !key) throw new HttpError(503, 'Recherche Web non configurée : choisissez Tavily ou Brave et saisissez la clé dans Paramètres.', 'web_not_configured');
      const cacheKey = `${provider}:${limit}:${query.toLowerCase()}`;
      const cached = cache.get(cacheKey);
      if (cached && cached.expires > Date.now()) return cached.results.map((x) => ({ ...x, cached: true }));
      if (inFlight.has(cacheKey)) return (await inFlight.get(cacheKey)).map((x) => ({ ...x, cached: true }));
      const request = (async () => {
        let lastError;
        for (let attempt = 0; attempt < 3; attempt++) {
          try {
            let results;
            if (provider === 'tavily') {
              const r = await fetch('https://api.tavily.com/search', { method: 'POST', headers: { 'content-type': 'application/json', authorization: `Bearer ${key}` }, body: JSON.stringify({ query, max_results: limit }), signal: AbortSignal.timeout(20000) });
              if (!r.ok) { if ((r.status === 429 || r.status >= 500) && attempt < 2) { await new Promise((resolve) => setTimeout(resolve, 300 * (attempt + 1))); continue; } throw new HttpError(502, `Tavily HTTP ${r.status}`); }
              const d = await r.json();
              results = (d.results || []).map((x) => ({ title: x.title, url: x.url, snippet: x.content }));
            } else if (provider === 'brave') {
              const r = await fetch(`https://api.search.brave.com/res/v1/web/search?q=${encodeURIComponent(query)}&count=${limit}`, { headers: { 'x-subscription-token': key, accept: 'application/json' }, signal: AbortSignal.timeout(20000) });
              if (!r.ok) { if ((r.status === 429 || r.status >= 500) && attempt < 2) { await new Promise((resolve) => setTimeout(resolve, 300 * (attempt + 1))); continue; } throw new HttpError(502, `Brave HTTP ${r.status}`); }
              const d = await r.json();
              results = (d.web?.results || []).map((x) => ({ title: x.title, url: x.url, snippet: x.description }));
            } else throw new HttpError(400, 'Fournisseur Web inconnu');
            const normalized = normalizeSearchResults(results, limit);
            cache.set(cacheKey, { results: normalized, expires: Date.now() + CACHE_TTL });
            while (cache.size > CACHE_MAX) cache.delete(cache.keys().next().value);
            return normalized;
          } catch (e) {
            lastError = e;
            if (attempt >= 2 || (e instanceof HttpError) || e?.name === 'AbortError') throw e;
            await new Promise((resolve) => setTimeout(resolve, 300 * (attempt + 1)));
          }
        }
        throw lastError || new HttpError(502, 'Recherche Web échouée');
      })();
      inFlight.set(cacheKey, request);
      try { return await request; } finally { inFlight.delete(cacheKey); }
    },
    /** Lit une page publique (documentation) : redirections revalidées, 1 Mo max, texte uniquement. */
    async fetchDoc(raw) {
      let url = raw;
      for (let hop = 0; hop < 4; hop++) {
        const u = await assertPublicUrl(url);
        const r = await fetch(u, { redirect: 'manual', signal: AbortSignal.timeout(15000), headers: { 'user-agent': 'OPS-MasterAI/2.0', accept: 'text/html,text/plain,application/json' } });
        if (r.status >= 300 && r.status < 400 && r.headers.get('location')) { url = new URL(r.headers.get('location'), u).toString(); continue; }
        if (!r.ok) throw new HttpError(502, `HTTP ${r.status}`);
        const type = r.headers.get('content-type') || '';
        if (!/text\/|json|xml/.test(type)) throw new HttpError(415, `Type non supporté : ${type}`);
        const declared = Number(r.headers.get('content-length') || 0);
        if (declared > 1024 * 1024) throw new HttpError(413, 'Page > 1 Mo');
        const reader = r.body?.getReader();
        const chunks = []; let total = 0;
        if (reader) {
          for (;;) {
            const { done, value } = await reader.read();
            if (done) break;
            total += value.byteLength;
            if (total > 1024 * 1024) { await reader.cancel(); throw new HttpError(413, 'Page > 1 Mo'); }
            chunks.push(Buffer.from(value));
          }
        }
        const body = Buffer.concat(chunks, total).toString('utf8');
        return { url: u.toString(), type, text: /html/.test(type) ? htmlToText(body) : body };
      }
      throw new HttpError(508, 'Trop de redirections');
    },
  };
}
