import { STUDIO } from './director.mjs';

/** Contrôle factuel de l'opérationnalité : configuration, raccordements et dépendances présentes. */
export function createOperationalReadiness(ctx) {
  const { db } = ctx;
  return {
    async report(projectId = null) {
      const providers = await ctx.providers.list();
      const readyProviders = providers.filter(p => p.enabled && p.model && p.key_set);
      const defaultId = (await db.get("SELECT value FROM settings WHERE key='default_provider_id'"))?.value || '';
      const fallback = readyProviders.find(p => p.id === defaultId) || readyProviders[0] || null;
      const studio = await ctx.director.roster(projectId || undefined);
      const agents = await db.all('SELECT id,name,enabled,provider_id,model FROM agents ORDER BY sort_order');
      const studioChecks = studio.map(a => {
        const provider = readyProviders.find(p => p.id === a.provider_id) || fallback;
        const specialized = ['world','modeling'].includes(a.id);
        const status = a.status === 'planned' ? 'blocked' : (!provider ? 'blocked' : (a.status === 'validated' ? 'ready' : 'warning'));
        return { id:a.id, name:a.name, status, executable:status !== 'blocked', provider:provider?.name || null, provider_source:a.provider_id ? 'agent' : (fallback ? 'fallback' : null), validated:a.status === 'validated', specialty_handler:specialized ? 'integrated' : 'agent-runtime', note:!provider?'Aucun fournisseur actif avec modèle et clé/endpoint configurés':a.status==='validated'?'IA construite et validée':'IA construite ; validation utilisateur non effectuée' };
      });
      const agentChecks = agents.map(a => {
        const provider = readyProviders.find(p => p.id === a.provider_id) || fallback;
        const status = !a.enabled ? 'disabled' : (!provider ? 'blocked' : 'ready');
        return { id:a.id,name:a.name,status,provider:provider?.name||null,note:!a.enabled?'Agent désactivé':!provider?'Aucun fournisseur disponible':'Runtime agent et fournisseur configurables' };
      });
      const engines = await ctx.engines.list(projectId || undefined);
      const engineChecks = engines.map(e => ({id:e.id,name:e.name,status:e.status==='verified'?'ready':'warning',kind:e.kind,detail:e.status==='verified'?'Connexion précédemment vérifiée':`État ${e.status||'non vérifié'} — lancer un test réel`}));
      const project = projectId ? await ctx.workspace.getProject(projectId) : null;
      const checks = [
        {id:'database',name:'Base de données',status:'ready',detail:`${db.kind} opérationnelle`},
        {id:'provider',name:'Fournisseurs IA',status:readyProviders.length?'ready':'blocked',detail:`${readyProviders.length}/${providers.length} fournisseur(s) configuré(s) et activé(s)`},
        {id:'studio',name:'Studio IA',status:studioChecks.every(a=>a.status==='ready')?'ready':studioChecks.some(a=>a.status==='blocked')?'blocked':'warning',detail:`${studioChecks.filter(a=>a.status==='ready').length}/${studioChecks.length} spécialistes prêts et validés`},
        {id:'agents',name:'Agents développeurs',status:agentChecks.some(a=>a.status==='blocked')?'blocked':'ready',detail:`${agentChecks.filter(a=>a.status==='ready').length}/${agentChecks.length} agents activés avec fournisseur disponible`},
        {id:'web',name:'Recherche Web',status:(await ctx.web.status()).configured?'ready':'warning',detail:(await ctx.web.status()).configured?'Fournisseur de recherche configuré':'Configurer Tavily ou Brave pour la recherche Web'},
        {id:'project-exec',name:'Exécution scripts projet',status:project ? (project.allow_exec?'ready':'warning'):'warning',detail:project ? (project.allow_exec?'Autorisation explicite activée':'Désactivée par sécurité ; autoriser uniquement pour les projets de confiance'):'Sélectionner un projet pour vérifier ses autorisations'},
        {id:'engines',name:'Moteurs externes',status:engineChecks.length ? (engineChecks.every(e=>e.status==='ready')?'ready':'warning'):'warning',detail:engineChecks.length?`${engineChecks.filter(e=>e.status==='ready').length}/${engineChecks.length} moteur(s) vérifié(s)`:'Aucun moteur externe enregistré'},
      ];
      const counts = Object.fromEntries(['ready','warning','blocked','disabled'].map(k=>[k,checks.filter(x=>x.status===k).length]));
      return {generated_at:Date.now(),version:ctx.config.version,project:project?{id:project.id,name:project.name,allow_exec:!!project.allow_exec}:null,summary:{status:counts.blocked?'blocked':counts.warning?'partial':'ready',...counts,total:checks.length},checks,studio:studioChecks,agents:agentChecks,engines:engineChecks,limitations:['Un fournisseur configuré n’est pas nécessairement joignable : utilisez « Tester la connexion » pour le vérifier en direct.','Un moteur externe doit réussir son test depuis son écran de configuration.','Les capacités dépendant de clés, fichiers, navigateurs ou logiciels externes ne peuvent pas être activées sans ces ressources.','Les tests automatiques ne prouvent pas la qualité des réponses des modèles IA.']};
    }
  };
}
