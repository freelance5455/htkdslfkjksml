import { HttpError } from './util.mjs';
import zlib from 'node:zlib';

/**
 * OPS MODELING AI — génération procédurale de modèles 3D prêts pour un moteur (fonctions pures, déterministes).
 * Conventions du contrat « ops-assets » v1 : mètres, Y vers le haut, repère droit (comme glTF 2.0), base du modèle à y = 0,
 * triangles anti-horaires vus de l'extérieur, normales unitaires, UV en mètres / UV_TILE (tuilage : valeurs hors 0–1 voulues),
 * matériaux PBR (metal/rough), 3 LOD (0 détaillé, 1 intermédiaire, 2 volumes), collisions en boîtes convexes.
 */
export const UV_TILE = 4;
export const BUILDING_KINDS = ['house', 'office', 'factory', 'warehouse', 'tower', 'cityhall', 'stadium', 'cathedral', 'museum', 'market', 'station'];
export const PROP_KINDS = ['tree', 'streetlight', 'bench', 'crate'];
export const ALL_KINDS = [...BUILDING_KINDS, ...PROP_KINDS];
export const STYLES = ['verre', 'béton', 'crépi', 'bois', 'adobe', 'grès', 'brique', 'ardoise'];
const WALL = { verre: [[0.55, 0.68, 0.78], 0.15, 0.25], béton: [[0.62, 0.62, 0.6], 0, 0.9], crépi: [[0.86, 0.8, 0.68], 0, 0.85], bois: [[0.5, 0.35, 0.2], 0, 0.8], adobe: [[0.78, 0.6, 0.4], 0, 0.95], grès: [[0.72, 0.62, 0.45], 0, 0.9], brique: [[0.6, 0.27, 0.2], 0, 0.85], ardoise: [[0.32, 0.34, 0.38], 0, 0.75] };
export const BUDGET = { building: { lod0: 9000, lod2: 400 }, prop: { lod0: 1500, lod2: 40 } };
const r3 = (v) => Math.round(v * 1000) / 1000;
const sub = (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
const cross = (u, v) => [u[1] * v[2] - u[2] * v[1], u[2] * v[0] - u[0] * v[2], u[0] * v[1] - u[1] * v[0]];
const norm = (v) => { const l = Math.hypot(...v) || 1; return [v[0] / l, v[1] / l, v[2] / l]; };
function hash(str) { let h = 2166136261; for (const c of String(str)) { h ^= c.charCodeAt(0); h = Math.imul(h, 16777619); } return h >>> 0; }

// ---------- matériaux ----------
export function materialLibrary(style = 'béton') {
  const w = WALL[style] || WALL.béton;
  return [
    { id: 'wall', name: `MI_wall_${style}`, baseColor: [...w[0], 1], metallic: w[1], roughness: w[2] },
    { id: 'window', name: 'MI_window_glass', baseColor: [0.12, 0.2, 0.3, 1], metallic: 0.3, roughness: 0.08 },
    { id: 'roof', name: 'MI_roof', baseColor: [0.36, 0.2, 0.17, 1], metallic: 0, roughness: 0.8 },
    { id: 'door', name: 'MI_door_wood', baseColor: [0.3, 0.2, 0.12, 1], metallic: 0, roughness: 0.7 },
    { id: 'trim', name: 'MI_trim', baseColor: [Math.min(1, w[0][0] + 0.12), Math.min(1, w[0][1] + 0.12), Math.min(1, w[0][2] + 0.12), 1], metallic: 0, roughness: 0.7 },
    { id: 'grass', name: 'MI_grass', baseColor: [0.25, 0.5, 0.2, 1], metallic: 0, roughness: 1 },
    { id: 'bark', name: 'MI_bark', baseColor: [0.32, 0.22, 0.14, 1], metallic: 0, roughness: 0.95 },
    { id: 'leaf', name: 'MI_leaf', baseColor: [0.18, 0.45, 0.16, 1], metallic: 0, roughness: 0.9 },
    { id: 'metal', name: 'MI_metal_dark', baseColor: [0.2, 0.21, 0.23, 1], metallic: 0.9, roughness: 0.4 },
    { id: 'lamp', name: 'MI_lamp_emissive', baseColor: [1, 0.95, 0.75, 1], metallic: 0, roughness: 0.3, emissive: [1, 0.9, 0.6] },
  ];
}

// ---------- constructeur de maillage ----------
class MB {
  constructor() { this.prims = new Map(); this.xf = false; }
  prim(m) { if (!this.prims.has(m)) this.prims.set(m, { material: m, pos: [], nrm: [], uv: [], idx: [] }); return this.prims.get(m); }
  /** polygone convexe anti-horaire vu de l'extérieur ; normales explicites facultatives (sinon normale de face) */
  poly(m, pts, uvs, nrms) {
    if (this.xf) { pts = pts.map((p) => [p[2], p[1], p[0]]).reverse(); uvs = uvs && [...uvs].reverse(); nrms = nrms && nrms.map((n) => [n[2], n[1], n[0]]).reverse(); }
    const P = this.prim(m), base = P.pos.length / 3, fn = norm(cross(sub(pts[1], pts[0]), sub(pts[2], pts[0])));
    pts.forEach((p, i) => { P.pos.push(r3(p[0]), r3(p[1]), r3(p[2])); const n = nrms ? nrms[i] : fn; P.nrm.push(r3(n[0]), r3(n[1]), r3(n[2])); const t = uvs ? uvs[i] : [0, 0]; P.uv.push(r3(t[0]), r3(t[1])); });
    for (let i = 1; i < pts.length - 1; i++) P.idx.push(base, base + i, base + i + 1);
  }
  box(m, cx, y0, cz, w, h, d, { top = true, bottom = false } = {}) {
    const x0 = cx - w / 2, x1 = cx + w / 2, z0 = cz - d / 2, z1 = cz + d / 2, y1 = y0 + h, T = UV_TILE;
    const f = (pts, u, v) => this.poly(m, pts, [[0, 0], [u / T, 0], [u / T, v / T], [0, v / T]]);
    f([[x0, y0, z1], [x1, y0, z1], [x1, y1, z1], [x0, y1, z1]], w, h); f([[x1, y0, z0], [x0, y0, z0], [x0, y1, z0], [x1, y1, z0]], w, h);
    f([[x1, y0, z1], [x1, y0, z0], [x1, y1, z0], [x1, y1, z1]], d, h); f([[x0, y0, z0], [x0, y0, z1], [x0, y1, z1], [x0, y1, z0]], d, h);
    if (top) f([[x0, y1, z1], [x1, y1, z1], [x1, y1, z0], [x0, y1, z0]], w, d);
    if (bottom) f([[x0, y0, z0], [x1, y0, z0], [x1, y0, z1], [x0, y0, z1]], w, d);
  }
  gable(m, cx, y, cz, w, d, r, alongZ = false) {
    if (alongZ) { const old = this.xf; this.xf = !old; this.gable(m, cz, y, cx, d, w, r, false); this.xf = old; return; }
    const x0 = cx - w / 2, x1 = cx + w / 2, z0 = cz - d / 2, z1 = cz + d / 2, T = UV_TILE, s = Math.hypot(d / 2, r);
    this.poly(m, [[x0, y, z1], [x1, y, z1], [x1, y + r, cz], [x0, y + r, cz]], [[0, 0], [w / T, 0], [w / T, s / T], [0, s / T]]);
    this.poly(m, [[x1, y, z0], [x0, y, z0], [x0, y + r, cz], [x1, y + r, cz]], [[0, 0], [w / T, 0], [w / T, s / T], [0, s / T]]);
    this.poly('wall', [[x1, y, z1], [x1, y, z0], [x1, y + r, cz]], [[0, 0], [d / T, 0], [d / 2 / T, r / T]]);
    this.poly('wall', [[x0, y, z0], [x0, y, z1], [x0, y + r, cz]], [[0, 0], [d / T, 0], [d / 2 / T, r / T]]);
  }
  pyramid(m, cx, y, cz, w, d, h) {
    const x0 = cx - w / 2, x1 = cx + w / 2, z0 = cz - d / 2, z1 = cz + d / 2, a = [cx, y + h, cz], T = UV_TILE;
    const tri = (p, q) => this.poly(m, [p, q, a], [[0, 0], [w / T, 0], [w / 2 / T, h / T]]);
    tri([x0, y, z1], [x1, y, z1]); tri([x1, y, z1], [x1, y, z0]); tri([x1, y, z0], [x0, y, z0]); tri([x0, y, z0], [x0, y, z1]);
  }
  cylinder(m, cx, y0, cz, r, h, n, { cap = true } = {}) {
    const T = UV_TILE, p = (a, y) => [cx + r * Math.cos(a), y, cz + r * Math.sin(a)], nr = (a) => [Math.cos(a), 0, Math.sin(a)];
    for (let i = 0; i < n; i++) {
      const a0 = (i / n) * 2 * Math.PI, a1 = ((i + 1) / n) * 2 * Math.PI, u0 = (i / n) * 2 * Math.PI * r / T, u1 = ((i + 1) / n) * 2 * Math.PI * r / T;
      this.poly(m, [p(a1, y0), p(a0, y0), p(a0, y0 + h), p(a1, y0 + h)], [[u1, 0], [u0, 0], [u0, h / T], [u1, h / T]], [nr(a1), nr(a0), nr(a0), nr(a1)]);
      if (cap) this.poly(m, [[cx, y0 + h, cz], p(a1, y0 + h), p(a0, y0 + h)], [[0, 0], [1, 0], [0, 1]], [[0, 1, 0], [0, 1, 0], [0, 1, 0]]);
    }
  }
  cone(m, cx, y0, cz, r, h, n) {
    const p = (a) => [cx + r * Math.cos(a), y0, cz + r * Math.sin(a)], k = r / Math.hypot(r, h), kh = h / Math.hypot(r, h);
    for (let i = 0; i < n; i++) {
      const a0 = (i / n) * 2 * Math.PI, a1 = ((i + 1) / n) * 2 * Math.PI, am = (a0 + a1) / 2;
      this.poly(m, [p(a1), p(a0), [cx, y0 + h, cz]], [[(i + 1) / n, 0], [i / n, 0], [(i + 0.5) / n, 1]], [[Math.cos(a1) * kh, k, Math.sin(a1) * kh], [Math.cos(a0) * kh, k, Math.sin(a0) * kh], [Math.cos(am) * kh, k, Math.sin(am) * kh]]);
    }
  }
  ring(m, cx, cz, rOut, rIn, y0, h, n) {
    const T = UV_TILE, y1 = y0 + h, P = (r, a, y) => [cx + r * Math.cos(a), y, cz + r * Math.sin(a)], N = (a) => [Math.cos(a), 0, Math.sin(a)];
    for (let i = 0; i < n; i++) {
      const a0 = (i / n) * 2 * Math.PI, a1 = ((i + 1) / n) * 2 * Math.PI, u0 = a0 * rOut / T, u1 = a1 * rOut / T, v = h / T;
      this.poly(m, [P(rOut, a1, y0), P(rOut, a0, y0), P(rOut, a0, y1), P(rOut, a1, y1)], [[u1, 0], [u0, 0], [u0, v], [u1, v]], [N(a1), N(a0), N(a0), N(a1)]);
      const ni = (a) => N(a).map((c) => -c);
      this.poly(m, [P(rIn, a0, y0), P(rIn, a1, y0), P(rIn, a1, y1), P(rIn, a0, y1)], [[u0, 0], [u1, 0], [u1, v], [u0, v]], [ni(a0), ni(a1), ni(a1), ni(a0)]);
      this.poly('trim', [P(rIn, a1, y1), P(rOut, a1, y1), P(rOut, a0, y1), P(rIn, a0, y1)], [[0, 0], [1, 0], [1, 1], [0, 1]]);
    }
  }
  disc(m, cx, y, cz, r, n) {
    for (let i = 0; i < n; i++) { const a0 = (i / n) * 2 * Math.PI, a1 = ((i + 1) / n) * 2 * Math.PI; this.poly(m, [[cx, y, cz], [cx + r * Math.cos(a1), y, cz + r * Math.sin(a1)], [cx + r * Math.cos(a0), y, cz + r * Math.sin(a0)]], [[0.5, 0.5], [0.5 + 0.5 * Math.cos(a1), 0.5 + 0.5 * Math.sin(a1)], [0.5 + 0.5 * Math.cos(a0), 0.5 + 0.5 * Math.sin(a0)]], [[0, 1, 0], [0, 1, 0], [0, 1, 0]]); }
  }
  result() { return [...this.prims.values()].filter((p) => p.idx.length); }
}

// ---------- façades : fenêtres (LOD0), bandeaux (LOD1), rien (LOD2) ----------
function facades(b, lod, cx, cz, w, d, y0, floors, fh, { door = false } = {}) {
  if (lod >= 2) return;
  const sides = [[[0, 0, 1], w], [[1, 0, 0], d], [[0, 0, -1], w], [[-1, 0, 0], d]]; // normales sortantes, longueur du côté
  const start = [[cx - w / 2, cz + d / 2], [cx + w / 2, cz + d / 2], [cx + w / 2, cz - d / 2], [cx - w / 2, cz - d / 2]];
  const off = 0.03;
  sides.forEach(([n, L], si) => {
    const t = [n[2], 0, -n[0]]; // tangente = haut × normale
    const o = start[si], cols = Math.max(1, Math.floor((L - 2) / 3)), pitch = L / cols;
    const at = (s, y, push = off) => [o[0] + t[0] * s + n[0] * push, y, o[1] + t[2] * s + n[2] * push];
    for (let f = 0; f < floors; f++) {
      const ya = y0 + f * fh + 0.9, yb = ya + Math.min(1.6, fh - 1.3);
      if (lod === 1) { if (f === 0 && door && si === 0) continue; b.poly('window', [at(1, ya), at(L - 1, ya), at(L - 1, yb), at(1, yb)], [[0, 0], [1, 0], [1, 1], [0, 1]]); continue; }
      for (let c = 0; c < cols; c++) {
        if (f === 0 && door && si === 0 && c === Math.floor(cols / 2)) continue;
        const s0 = c * pitch + pitch / 2 - 0.7, s1 = s0 + 1.4;
        b.poly('window', [at(s0, ya), at(s1, ya), at(s1, yb), at(s0, yb)], [[0, 0], [1, 0], [1, 1], [0, 1]]);
      }
    }
    if (door && si === 0 && lod === 0) { const s0 = Math.floor(cols / 2) * pitch + pitch / 2 - 0.6; b.poly('door', [at(s0, y0, 0.04), at(s0 + 1.2, y0, 0.04), at(s0 + 1.2, y0 + 2.2, 0.04), at(s0, y0 + 2.2, 0.04)], [[0, 0], [1, 0], [1, 1], [0, 1]]); }
  });
  if (lod === 0) for (let f = 1; f < floors; f++) { const y = y0 + f * fh - 0.12; b.box('trim', cx, y, cz, w + 0.3, 0.25, d + 0.3, { top: true }); }
}

const SEG = [16, 8, 6];
const QUALITY_SEGMENTS = { balanced: [16, 8, 6], high: [24, 12, 8], ultra: [32, 16, 10] };
const FLOOR_H = { house: 3, office: 3.2, factory: 3.6, warehouse: 3.6, tower: 3.4, cityhall: 4.5, stadium: 7, cathedral: 7, museum: 5, market: 4, station: 4 };

/** Construit un bâtiment/monument : retourne {prims, collision, height} pour le LOD demandé. */
function buildBuilding(spec, lod) {
  const { kind, floors, footprint: [w, d] } = spec, fh = FLOOR_H[kind] || 3.2, H = floors * fh, b = new MB(), col = [];
  const SEG = QUALITY_SEGMENTS[spec.quality] || QUALITY_SEGMENTS.balanced;
  const hull = (cx, y0, cz, bw, bh, bd, rot = 0) => col.push({ type: 'box', center: [r3(cx), r3(y0 + bh / 2), r3(cz)], half: [r3(bw / 2), r3(bh / 2), r3(bd / 2)], rotation_y: r3(rot) });
  const walls = (cx, cz, bw, bd, y0, nf, o = {}) => { b.box('wall', cx, y0, cz, bw, nf * fh, bd, { top: false }); facades(b, lod, cx, cz, bw, bd, y0, nf, fh, o); };
  const flatRoof = (cx, cz, bw, bd, y) => { b.poly('roof', [[cx - bw / 2, y, cz + bd / 2], [cx + bw / 2, y, cz + bd / 2], [cx + bw / 2, y, cz - bd / 2], [cx - bw / 2, y, cz - bd / 2]], [[0, 0], [bw / UV_TILE, 0], [bw / UV_TILE, bd / UV_TILE], [0, bd / UV_TILE]]); if (lod === 0) { const p = 0.5, hgt = 0.7; b.box('trim', cx, y, cz + bd / 2 - p / 2, bw, hgt, p); b.box('trim', cx, y, cz - bd / 2 + p / 2, bw, hgt, p); b.box('trim', cx - bw / 2 + p / 2, y, cz, p, hgt, bd - 2 * p); b.box('trim', cx + bw / 2 - p / 2, y, cz, p, hgt, bd - 2 * p); } };
  const gableRoof = (cx, cz, bw, bd, y, rise) => b.gable('roof', cx, y, cz, bw, bd, rise, bd > bw);
  if (kind === 'house' || kind === 'warehouse') { walls(0, 0, w, d, 0, floors, { door: true }); gableRoof(0, 0, w + 0.4, d + 0.4, H, kind === 'house' ? Math.min(w, d) * 0.3 : 2); hull(0, 0, 0, w, H, d); }
  else if (kind === 'office' || kind === 'factory') {
    walls(0, 0, w, d, 0, floors, { door: true }); flatRoof(0, 0, w, d, H); hull(0, 0, 0, w, H, d);
    if (kind === 'factory') { b.cylinder('trim', w * 0.28, H, -d * 0.25, 1.1, 9, SEG[lod]); hull(w * 0.28, H, -d * 0.25, 2.2, 9, 2.2); }
  } else if (kind === 'tower') {
    const tiers = [[1, 0.55], [0.72, 0.3], [0.5, 0.15]]; let y = 0;
    tiers.forEach(([s, share], i) => { const nf = Math.max(1, Math.round(floors * share)), tw = w * 0.6 * s, td = d * 0.6 * s; walls(0, 0, tw, td, y, nf, { door: i === 0 }); hull(0, y, 0, tw, nf * fh, td); y += nf * fh; if (i === 2) { b.pyramid('metal', 0, y, 0, tw, td, H * 0.18); b.box('metal', 0, y, 0, 0.1, 0.1, 0.1, { top: false }); } else { flatRoof(0, 0, tw, td, y); } });
  } else if (kind === 'cityhall') {
    walls(0, 0, w * 0.8, d * 0.6, 0, floors, { door: true }); b.gable('roof', 0, H, 0, w * 0.8 + 0.4, d * 0.6 + 0.4, 3, false); hull(0, 0, 0, w * 0.8, H, d * 0.6);
    for (let i = 0; i < 4; i++) b.cylinder('trim', -w * 0.24 + i * w * 0.16, 0, d * 0.3 + 2.2, 0.55, fh * 2.2, SEG[lod] + 4);
    b.box('wall', 0, fh * 2.2, d * 0.3 + 2.2, w * 0.56, 1, 3, { top: true }); b.box('wall', 0, H + 3, 0, 4, 6, 4, { top: false }); b.pyramid('roof', 0, H + 9, 0, 4.4, 4.4, 5); hull(0, H, 0, 4, 9, 4);
  } else if (kind === 'stadium') {
    const ro = Math.min(w, d) * 0.46, ri = ro * 0.66, n = SEG[lod] * 2;
    b.ring('wall', 0, 0, ro, ri, 0, H, n); b.disc('grass', 0, 0.05, 0, ri, n);
    for (let i = 0; i < n; i++) { const a = ((i + 0.5) / n) * 2 * Math.PI, rm = (ro + ri) / 2, ch = 2 * rm * Math.sin(Math.PI / n); hull(rm * Math.cos(a), 0, rm * Math.sin(a), ro - ri, H, ch, -a + Math.PI / 2); }
  } else if (kind === 'cathedral') {
    const nw = w * 0.45; walls(0, 0, nw, d * 0.85, 0, floors, { door: true }); gableRoof(0, 0, nw + 0.4, d * 0.85 + 0.4, H, nw * 0.4); hull(0, 0, 0, nw, H, d * 0.85);
    const tw = w * 0.2, th = H * 1.7, tz = d * 0.85 / 2 - tw / 2; b.box('wall', 0, 0, tz, tw, th, tw, { top: false }); b.pyramid('roof', 0, th, tz, tw, tw, th * 0.45); hull(0, 0, tz, tw, th, tw);
    if (lod === 0) for (let i = 0; i < 3; i++) b.box('window', 0, th * 0.6 + i * 3, tz + tw / 2 + 0.03, 1, 1.8, 0.02, { top: false });
  } else if (kind === 'museum' || kind === 'station' || kind === 'market') {
    walls(0, 0, w * 0.9, d * 0.7, 0, floors, { door: true });
    if (kind === 'museum') { flatRoof(0, 0, w * 0.9, d * 0.7, H); for (let i = 0; i < 3; i++) b.box('trim', 0, i * 0.3, d * 0.35 + 1.2 - i * 0.4, w * 0.6, 0.3, 2.4 + i * 0.4, { top: true }); for (let i = 0; i < 6; i++) b.cylinder('trim', -w * 0.25 + i * w * 0.1, 0.9, d * 0.35 + 1, 0.45, fh * 0.9, SEG[lod] + 4); }
    else { gableRoof(0, 0, w * 0.9 + 0.4, d * 0.7 + 0.4, H, kind === 'market' ? 2 : 4); if (kind === 'station') { b.box('wall', w * 0.3, H, 0, 3, 7, 3, { top: false }); b.pyramid('roof', w * 0.3, H + 7, 0, 3.4, 3.4, 3); hull(w * 0.3, H, 0, 3, 7, 3); } }
    hull(0, 0, 0, w * 0.9, H, d * 0.7);
  } else throw new HttpError(400, `kind de bâtiment inconnu : ${kind}`);
  return { prims: b.result(), collision: col, height: H };
}

function buildProp(spec, lod) {
  const b = new MB(), col = [], SEG = QUALITY_SEGMENTS[spec.quality] || QUALITY_SEGMENTS.balanced, s = SEG[lod], k = spec.kind;
  const hull = (cx, y0, cz, bw, bh, bd) => col.push({ type: 'box', center: [r3(cx), r3(y0 + bh / 2), r3(cz)], half: [r3(bw / 2), r3(bh / 2), r3(bd / 2)], rotation_y: 0 });
  if (k === 'tree') { const h = spec.height || 7; b.cylinder('bark', 0, 0, 0, 0.25, h * 0.4, Math.max(5, s / 2), { cap: false }); if (lod >= 2) b.cone('leaf', 0, h * 0.25, 0, h * 0.28, h * 0.75, 4); else { b.cone('leaf', 0, h * 0.3, 0, h * 0.3, h * 0.45, s); b.cone('leaf', 0, h * 0.55, 0, h * 0.22, h * 0.45, s); } hull(0, 0, 0, 0.5, h * 0.4, 0.5); }
  else if (k === 'streetlight') { const h = 6; b.cylinder('metal', 0, 0, 0, 0.1, h, [8, 6, 4][lod], { cap: lod < 2 }); if (lod < 2) b.box('metal', 0.7, h - 0.1, 0, 1.5, 0.12, 0.12); if (lod === 0) b.box('metal', 0, 0, 0, 0.35, 0.3, 0.35); b.box('lamp', 1.35, h - 0.3, 0, 0.5, 0.2, 0.3, { top: lod < 2 }); hull(0, 0, 0, 0.3, h, 0.3); }
  else if (k === 'bench') { if (lod === 2) b.box('door', 0, 0, 0, 1.6, 1.0, 0.45); else { b.box('door', 0, 0.45, 0, 1.6, 0.08, 0.45); b.box('door', 0, 0.55, -0.2, 1.6, 0.5, 0.06); for (const sx of [-0.7, 0.7]) for (const sz of (lod === 0 ? [-0.15, 0.15] : [0])) b.box('metal', sx, 0, sz, 0.06, 0.45, lod === 0 ? 0.06 : 0.4); } hull(0, 0, 0, 1.6, 1.05, 0.5); }
  else if (k === 'crate') { b.box('door', 0, 0, 0, 1, 1, 1, { top: true }); if (lod < 2) for (const y of (lod === 0 ? [0.05, 0.8] : [0.45])) b.box('trim', 0, y, 0, 1.04, 0.15, 1.04, { top: false }); hull(0, 0, 0, 1, 1, 1); }
  else throw new HttpError(400, `prop inconnu : ${k}`);
  return { prims: b.result(), collision: col, height: spec.height || { tree: 7, streetlight: 6, bench: 1.05, crate: 1 }[k] };
}

const countTris = (prims) => prims.reduce((n, p) => n + p.idx.length / 3, 0);
const countVerts = (prims) => prims.reduce((n, p) => n + p.pos.length / 3, 0);

export function normalizeAssetParams(p = {}) {
  const bad = (m) => { throw new HttpError(400, m, 'bad_params'); };
  const kind = p.kind ?? 'house'; if (!ALL_KINDS.includes(kind)) bad(`kind : ${ALL_KINDS.join(' | ')}`);
  const style = p.style ?? 'béton'; if (!STYLES.includes(style)) bad(`style : ${STYLES.join(' | ')}`);
  const quality = p.quality ?? 'balanced'; if (!Object.hasOwn(QUALITY_SEGMENTS, quality)) bad('quality : balanced | high | ultra');
  const textureResolution = p.texture_resolution === undefined ? 512 : Number(p.texture_resolution); if (![64,128,256,512,1024,2048].includes(textureResolution)) bad('texture_resolution : 64 | 128 | 256 | 512 | 1024 | 2048');
  const num = (k, d, lo, hi) => { const v = p[k] === undefined || p[k] === '' ? d : Number(p[k]); if (!Number.isFinite(v) || v < lo || v > hi) bad(`${k} : nombre entre ${lo} et ${hi}`); return v; };
  const isProp = PROP_KINDS.includes(kind);
  const out = { kind, style, quality, texture_resolution: textureResolution };
  if (isProp) { out.height = r3(num('height', { tree: 7, streetlight: 6, bench: 1.05, crate: 1 }[kind], 0.5, 30)); out.floors = 1; out.footprint = [1, 1]; }
  else { out.floors = Math.round(num('floors', kind === 'house' ? 2 : 4, 1, 60)); out.footprint = [r3(num('width', 14, 6, 80)), r3(num('depth', 14, 6, 80))]; }
  const given = String(p.name ?? '').trim().replace(/[^\p{L}\p{N}_.-]/gu, '_').replace(/\.{2,}/g, '_').replace(/^[._-]+/, '').slice(0, 56);
  out.name = (given ? (given.startsWith('SM_') ? given : 'SM_' + given) : '') || `SM_${kind}_${style}_${isProp ? 'h' + out.height : out.floors + 'f_' + Math.round(out.footprint[0]) + 'x' + Math.round(out.footprint[1])}`.replace(/[^\p{L}\p{N}_.-]/gu, '_');
  return out;
}

/** Génère un asset complet : 3 LOD, collisions, matériaux, bornes, validation. */
export function generateAsset(raw) {
  const s = normalizeAssetParams(raw), isProp = PROP_KINDS.includes(s.kind);
  const lods = [0, 1, 2].map((lod) => { const m = isProp ? buildProp(s, lod) : buildBuilding(s, lod); return { lod, prims: m.prims, tris: countTris(m.prims), verts: countVerts(m.prims), _m: m }; });
  const collision = lods[0]._m.collision, height = lods[0]._m.height;
  const used = [...new Set(lods.flatMap((l) => l.prims.map((p) => p.material)))];
  const mats = materialLibrary(s.style).filter((m) => used.includes(m.id));
  const min = [Infinity, Infinity, Infinity], max = [-Infinity, -Infinity, -Infinity];
  for (const p of lods[0].prims) for (let i = 0; i < p.pos.length; i += 3) for (let k = 0; k < 3; k++) { min[k] = Math.min(min[k], p.pos[i + k]); max[k] = Math.max(max[k], p.pos[i + k]); }
  const asset = { name: s.name, kind: s.kind, style: s.style, quality: s.quality, textureResolution: s.texture_resolution, floors: s.floors, footprint: s.footprint, height: r3(height), bounds: { min: min.map(r3), max: max.map(r3) }, materials: mats, collision, lods: lods.map(({ lod, prims, tris, verts }) => ({ lod, prims, tris, verts })) };
  asset.validation = validateAsset(asset);
  return asset;
}

/** Contrôle qualité indépendant : lit uniquement l'asset produit. */
export function validateAsset(a) {
  const issues = [], err = (m) => issues.push({ level: 'error', msg: m }), warn = (m) => issues.push({ level: 'warn', msg: m });
  const ids = new Set(a.materials.map((m) => m.id)), isProp = PROP_KINDS.includes(a.kind), bud = isProp ? BUDGET.prop : BUDGET.building;
  if (!/^[\p{L}\p{N}_.-]+$/u.test(a.name)) err('nom invalide (lettres, chiffres, _ . - seulement)');
  if (!a.name.startsWith('SM_')) warn('convention : le nom devrait commencer par SM_');
  for (const l of a.lods) {
    let degenerate = 0, flipped = 0, badN = 0, badUv = 0;
    if (!l.prims.length) err(`LOD${l.lod} vide`);
    for (const p of l.prims) {
      const nv = p.pos.length / 3;
      if (!ids.has(p.material)) err(`LOD${l.lod} : matériau inconnu « ${p.material} »`);
      if (p.nrm.length !== p.pos.length || p.uv.length / 2 !== nv) err(`LOD${l.lod} : tailles POSITION/NORMAL/UV incohérentes`);
      if (p.idx.length % 3) err(`LOD${l.lod} : indices non multiples de 3`);
      if (p.pos.some((v) => !Number.isFinite(v)) || p.uv.some((v) => !Number.isFinite(v))) badUv++;
      for (let i = 0; i < nv; i++) { const n = Math.hypot(p.nrm[3 * i], p.nrm[3 * i + 1], p.nrm[3 * i + 2]); if (Math.abs(n - 1) > 0.02) badN++; }
      for (let t = 0; t < p.idx.length; t += 3) {
        const [i, j, k] = [p.idx[t], p.idx[t + 1], p.idx[t + 2]];
        if (![i, j, k].every((x) => Number.isInteger(x) && x >= 0 && x < nv)) { err(`LOD${l.lod} : indice hors limites`); break; }
        const P = (x) => [p.pos[3 * x], p.pos[3 * x + 1], p.pos[3 * x + 2]], fn = cross(sub(P(j), P(i)), sub(P(k), P(i))), area = Math.hypot(...fn) / 2;
        if (area < 1e-7) { degenerate++; continue; }
        const vn = [0, 1, 2].map((q) => p.nrm[3 * i + q] + p.nrm[3 * j + q] + p.nrm[3 * k + q]);
        if (fn[0] * vn[0] + fn[1] * vn[1] + fn[2] * vn[2] <= 0) flipped++;
      }
    }
    if (degenerate) err(`LOD${l.lod} : ${degenerate} triangle(s) dégénéré(s)`);
    if (flipped) err(`LOD${l.lod} : ${flipped} triangle(s) dont l'orientation contredit la normale`);
    if (badN) err(`LOD${l.lod} : ${badN} normale(s) non unitaire(s)`);
    if (badUv) err(`LOD${l.lod} : valeurs non finies (position/UV)`);
  }
  const [l0, l1, l2] = a.lods;
  if (!(l1.tris < l0.tris && l2.tris < l1.tris)) err(`LOD non décroissants (${a.lods.map((l) => l.tris).join(' > ')})`);
  if (l0.tris > bud.lod0) err(`budget LOD0 dépassé (${l0.tris}/${bud.lod0})`);
  if (l2.tris > bud.lod2) err(`budget LOD2 dépassé (${l2.tris}/${bud.lod2})`);
  if (!(a.height > 0)) err('hauteur invalide');
  if (Math.abs(a.bounds.min[1]) > 0.011) err(`la base doit être à y = 0 (min y = ${a.bounds.min[1]})`);
  if (!a.collision.length) err('aucune collision');
  for (const c of a.collision) if (![...c.center, ...c.half, c.rotation_y].every(Number.isFinite) || c.half.some((h) => h <= 0)) err('collision invalide');
  const ex = a.bounds.max.map((v, i) => v - a.bounds.min[i]);
  if (!isProp && (ex[0] > a.footprint[0] * 1.35 + 4 || ex[2] > a.footprint[1] * 1.35 + 4)) warn('le modèle dépasse nettement son emprise annoncée');
  return { ok: !issues.some((i) => i.level === 'error'), issues };
}

// ---------- textures PBR procédurales (PNG déterministes, sans dépendance externe) ----------
const CRC_TABLE = (() => { const t = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = (c & 1) ? (0xedb88320 ^ (c >>> 1)) : (c >>> 1); t[n] = c >>> 0; } return t; })();
function crc32(buf) { let c = 0xffffffff; for (const b of buf) c = CRC_TABLE[(c ^ b) & 255] ^ (c >>> 8); return (c ^ 0xffffffff) >>> 0; }
function pngChunk(type, data) { const name = Buffer.from(type), len = Buffer.alloc(4); len.writeUInt32BE(data.length); const crc = Buffer.alloc(4); crc.writeUInt32BE(crc32(Buffer.concat([name, data]))); return Buffer.concat([len, name, data, crc]); }
function encodePng(width, height, pixels) {
  const rows = Buffer.alloc((width * 4 + 1) * height);
  for (let y = 0; y < height; y++) { const off = y * (width * 4 + 1); rows[off] = 0; pixels.copy(rows, off + 1, y * width * 4, (y + 1) * width * 4); }
  const ihdr = Buffer.alloc(13); ihdr.writeUInt32BE(width, 0); ihdr.writeUInt32BE(height, 4); ihdr[8] = 8; ihdr[9] = 6;
  return Buffer.concat([Buffer.from([137,80,78,71,13,10,26,10]), pngChunk('IHDR', ihdr), pngChunk('IDAT', zlib.deflateSync(rows, { level: 6 })), pngChunk('IEND', Buffer.alloc(0))]);
}
const clamp8 = (v) => Math.max(0, Math.min(255, Math.round(v)));
function texturePixels(material, channel, size = 64) {
  const out = Buffer.alloc(size * size * 4), seed = hash(`${material.name}:${channel}`), color = material.baseColor.slice(0, 3).map((v) => v * 255);
  const rough = material.roughness, metal = material.metallic;
  for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) {
    const i = (y * size + x) * 4, n = ((Math.imul(x + 17, 374761393) ^ Math.imul(y + 31, 668265263) ^ seed) >>> 0), noise = ((n ^ (n >>> 13)) & 255) / 255 - 0.5;
    if (channel === 'baseColor') {
      const grain = noise * (material.id === 'window' ? 3 : 15), mortar = material.id === 'wall' && material.name.includes('brique') && y % 12 < 1 ? -24 : 0;
      out[i] = clamp8(color[0] + grain + mortar); out[i + 1] = clamp8(color[1] + grain + mortar); out[i + 2] = clamp8(color[2] + grain + mortar); out[i + 3] = 255;
    } else if (channel === 'normal') {
      const h = Math.sin(x * 0.61 + seed % 13) * Math.cos(y * 0.53 + seed % 7) * 3 + noise * 2;
      out[i] = clamp8(128 + h); out[i + 1] = clamp8(128 - h * 0.7); out[i + 2] = 255; out[i + 3] = 255;
    } else {
      out[i] = 255; out[i + 1] = clamp8(rough * 255 + noise * 3); out[i + 2] = clamp8(metal * 255); out[i + 3] = 255;
    }
  }
  return out;
}
export function generatePbrTextures(material, size = 64) {
  if (!material || !Array.isArray(material.baseColor) || !Number.isInteger(size) || size < 16 || size > 2048) throw new Error('matériau ou résolution texture invalide');
  const make = (channel) => encodePng(size, size, texturePixels(material, channel, size));
  return { baseColor: make('baseColor'), normal: make('normal'), orm: make('orm'), width: size, height: size };
}
export function toTextureFiles(a, size = a.textureResolution || 512) {
  return a.materials.flatMap((m) => { const t = generatePbrTextures(m, size), prefix = `${a.name}_${m.id}`; return [
    { name: `${prefix}_BaseColor.png`, content: t.baseColor }, { name: `${prefix}_Normal.png`, content: t.normal }, { name: `${prefix}_ORM.png`, content: t.orm },
  ]; });
}

// ---------- exports ----------
export function toGltf(a) {
  const resolution = a.textureResolution || 512;
  const bufs = [], views = [], accessors = [], meshes = [], nodes = [], images = [], textures = [], gm = a.materials.map((m) => { const prefix = `${a.name}_${m.id}`, base = images.length; images.push({ name: `${m.name}_BaseColor`, uri: `${prefix}_BaseColor.png` }, { name: `${m.name}_Normal`, uri: `${prefix}_Normal.png` }, { name: `${m.name}_ORM`, uri: `${prefix}_ORM.png` }); textures.push({ source: base }, { source: base + 1 }, { source: base + 2 }); return { name: m.name, pbrMetallicRoughness: { baseColorFactor: m.baseColor, baseColorTexture: { index: textures.length - 3 }, metallicFactor: m.metallic, roughnessFactor: m.roughness, metallicRoughnessTexture: { index: textures.length - 1 } }, normalTexture: { index: textures.length - 2, scale: 0.35 }, occlusionTexture: { index: textures.length - 1, strength: 1 }, ...(m.emissive ? { emissiveFactor: m.emissive } : {}) }; });
  let off = 0;
  const push = (arr, Type, target) => { const b = Buffer.from(new Type(arr).buffer); const pad = (4 - (b.length % 4)) % 4; views.push({ buffer: 0, byteOffset: off, byteLength: b.length, target }); bufs.push(b, Buffer.alloc(pad)); off += b.length + pad; return views.length - 1; };
  const acc = (arr, Type, ct, type, target, mm) => { const v = push(arr, Type, target); accessors.push({ bufferView: v, componentType: ct, count: arr.length / ({ VEC3: 3, VEC2: 2, SCALAR: 1 }[type]), type, ...(mm || {}) }); return accessors.length - 1; };
  for (const l of a.lods) {
    const prims = l.prims.map((p) => {
      const mn = [Infinity, Infinity, Infinity], mx = [-Infinity, -Infinity, -Infinity];
      for (let i = 0; i < p.pos.length; i += 3) for (let k = 0; k < 3; k++) { mn[k] = Math.min(mn[k], p.pos[i + k]); mx[k] = Math.max(mx[k], p.pos[i + k]); }
      const small = p.pos.length / 3 < 65536;
      return { attributes: { POSITION: acc(p.pos, Float32Array, 5126, 'VEC3', 34962, { min: mn, max: mx }), NORMAL: acc(p.nrm, Float32Array, 5126, 'VEC3', 34962), TEXCOORD_0: acc(p.uv, Float32Array, 5126, 'VEC2', 34962) }, indices: small ? acc(p.idx, Uint16Array, 5123, 'SCALAR', 34963) : acc(p.idx, Uint32Array, 5125, 'SCALAR', 34963), material: a.materials.findIndex((m) => m.id === p.material), mode: 4 };
    });
    meshes.push({ name: `${a.name}_LOD${l.lod}`, primitives: prims });
    nodes.push({ name: `${a.name}_LOD${l.lod}`, mesh: l.lod, extras: { ops_lod: l.lod, triangles: l.tris } });
  }
  const data = Buffer.concat(bufs);
  return JSON.stringify({ asset: { version: '2.0', generator: 'OPS MODELING AI v1' }, scene: 0, scenes: [{ name: a.name, nodes: [0] }], nodes: [{ name: a.name, children: [1, 2, 3] }, ...nodes], meshes, materials: gm, images, textures, samplers: [{ magFilter: 9729, minFilter: 9987, wrapS: 10497, wrapT: 10497 }], accessors, bufferViews: views, buffers: [{ byteLength: data.length, uri: 'data:application/octet-stream;base64,' + data.toString('base64') }], extras: { ops_assets: 1, units: 'm', up: 'Y', uv_tile_m: UV_TILE, pbr_textures: `procedural BaseColor + tangent-space Normal + packed ORM; ${resolution}x${resolution}; external PNG files`, collision: a.collision, note: 'LOD1 et LOD2 sont des nœuds frères du LOD0 : un moteur doit n’afficher qu’un LOD à la fois.' } });
}

export function toObj(a, lod = 0) {
  const L = [`# OPS MODELING AI — ${a.name} LOD${lod}`, `mtllib ${a.name}.mtl`, `o ${a.name}_LOD${lod}`]; let base = 0;
  const l = a.lods[lod];
  for (const p of l.prims) { for (let i = 0; i < p.pos.length; i += 3) L.push(`v ${p.pos[i]} ${p.pos[i + 1]} ${p.pos[i + 2]}`); for (let i = 0; i < p.uv.length; i += 2) L.push(`vt ${p.uv[i]} ${p.uv[i + 1]}`); for (let i = 0; i < p.nrm.length; i += 3) L.push(`vn ${p.nrm[i]} ${p.nrm[i + 1]} ${p.nrm[i + 2]}`); L.push(`usemtl ${a.materials.find((m) => m.id === p.material).name}`); for (let t = 0; t < p.idx.length; t += 3) L.push('f ' + [0, 1, 2].map((q) => { const n = p.idx[t + q] + 1 + base; return `${n}/${n}/${n}`; }).join(' ')); base += p.pos.length / 3; }
  return L.join('\n') + '\n';
}
export const toMtl = (a) => a.materials.map((m) => `newmtl ${m.name}\nKd ${m.baseColor.slice(0, 3).join(' ')}\nKs ${m.metallic} ${m.metallic} ${m.metallic}\nNs ${Math.round((1 - m.roughness) * 200)}\nmap_Kd ${a.name}_${m.id}_BaseColor.png\n${m.emissive ? `Ke ${m.emissive.join(' ')}\n` : ''}`).join('\n');

const esc = (s) => String(s).replace(/[<>&"']/g, (c) => ({ '<': '&lt;', '>': '&gt;', '&': '&amp;', '"': '&quot;', "'": '&#39;' }[c]));
/** Aperçu isométrique (peintre + ombrage plat) du LOD0 : vérifiable visuellement sans moteur. */
export function toPreviewSvg(a, lod = 0) {
  const c = Math.cos(Math.PI / 6), s = 0.5, tris = [], mats = Object.fromEntries(a.materials.map((m) => [m.id, m.baseColor]));
  const proj = (x, y, z) => [(x - z) * c, (x + z) * s - y];
  for (const p of a.lods[lod].prims) for (let t = 0; t < p.idx.length; t += 3) {
    const v = [0, 1, 2].map((q) => { const i = p.idx[t + q]; return [p.pos[3 * i], p.pos[3 * i + 1], p.pos[3 * i + 2]]; });
    const n = norm(cross(sub(v[1], v[0]), sub(v[2], v[0]))); if (n[0] + n[1] + n[2] <= 0.0001) continue; // face dos à la caméra (placée en +x,+y,+z)
    const light = 0.45 + 0.55 * Math.max(0, n[0] * 0.35 + n[1] * 0.8 + n[2] * 0.5), col = mats[p.material];
    tris.push({ d: (v[0][0] + v[1][0] + v[2][0] + v[0][2] + v[1][2] + v[2][2]) / 3 + (v[0][1] + v[1][1] + v[2][1]) / 3, pts: v.map((q) => proj(...q)), fill: col.slice(0, 3).map((k) => Math.round(Math.min(1, k * light) * 255)) });
  }
  tris.sort((x, y) => x.d - y.d);
  const all = tris.flatMap((t) => t.pts), minx = Math.min(...all.map((q) => q[0])), maxx = Math.max(...all.map((q) => q[0])), miny = Math.min(...all.map((q) => q[1])), maxy = Math.max(...all.map((q) => q[1])), pad = 2, sc = 400 / Math.max(maxx - minx, maxy - miny, 1);
  const f = (q) => `${((q[0] - minx + pad) * sc).toFixed(1)},${((q[1] - miny + pad) * sc).toFixed(1)}`;
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${Math.ceil((maxx - minx + 2 * pad) * sc)}" height="${Math.ceil((maxy - miny + 2 * pad) * sc)}"><title>${esc(a.name)} LOD${lod} — ${a.lods[lod].tris} triangles</title>${tris.map((t) => `<polygon points="${t.pts.map(f).join(' ')}" fill="rgb(${t.fill.join(',')})" stroke="rgb(${t.fill.join(',')})" stroke-width="0.4"/>`).join('')}</svg>`;
}

// ---------- kit depuis un monde WORLD ----------
const TOL = Math.log(1.35), SLACK = 0.07;
/** Regroupe les bâtiments d'un monde ops-world en archétypes instanciables (≤ maxArchetypes) : fusion des variantes proches
 *  (erreur de forme bornée à ×1,35 sur largeur, profondeur, hauteur) ; les monuments ne sont jamais fusionnés. */
export function planKit(world, { maxArchetypes = 32 } = {}) {
  if (!world || world.format !== 'ops-world') throw new HttpError(400, 'Monde ops-world requis');
  const L = Math.log, fhOf = (k) => FLOOR_H[k] || 3.2;
  const clusters = new Map();
  for (const b of world.buildings) {
    const fh = fhOf(b.kind), fl = Math.max(1, Math.round(b.height / fh)), key = [b.kind, b.style, Math.round(b.footprint[0] / 2) * 2, Math.round(b.footprint[1] / 2) * 2, fl, b.landmark ? 'L' : ''].join('|');
    if (!clusters.has(key)) clusters.set(key, { kind: b.kind, style: b.style, lm: !!b.landmark, members: [], lo: [Infinity, Infinity, Infinity], hi: [-Infinity, -Infinity, -Infinity] });
    const c = clusters.get(key); c.members.push(b);
    [L(b.footprint[0]), L(b.footprint[1]), L(b.height)].forEach((v, i) => { c.lo[i] = Math.min(c.lo[i], v); c.hi[i] = Math.max(c.hi[i], v); });
  }
  let list = [...clusters.values()], merges = 0;
  const cost = (a, b) => Math.max(...[0, 1, 2].map((i) => (Math.max(a.hi[i], b.hi[i]) - Math.min(a.lo[i], b.lo[i])) / 2));
  while (list.length > maxArchetypes) {
    let best = null;
    const groups = new Map();
    for (const c of list) if (!c.lm) { const g = c.kind + '|' + c.style; (groups.get(g) || groups.set(g, []).get(g)).push(c); }
    for (const g of groups.values()) {
      g.sort((x, y) => x.lo[2] - y.lo[2] || x.lo[0] - y.lo[0] || x.lo[1] - y.lo[1]);
      for (let i = 0; i < g.length; i++) for (let k = i + 1; k < Math.min(g.length, i + 9); k++) { const c = cost(g[i], g[k]); if (c <= TOL - SLACK && (!best || c < best.c)) best = { c, a: g[i], b: g[k] }; }
    }
    if (!best) break;
    const m = { kind: best.a.kind, style: best.a.style, lm: false, members: [...best.a.members, ...best.b.members], lo: best.a.lo.map((v, i) => Math.min(v, best.b.lo[i])), hi: best.a.hi.map((v, i) => Math.max(v, best.b.hi[i])) };
    list = list.filter((c) => c !== best.a && c !== best.b); list.push(m); merges++;
  }
  const map = new Map(), placements = [];
  for (const c of list) {
    const mid = (i) => Math.exp((c.lo[i] + c.hi[i]) / 2), fh = fhOf(c.kind);
    const params = { kind: c.kind, style: c.style, floors: Math.max(1, Math.round(mid(2) / fh)), width: Math.max(6, Math.round(mid(0) * 2) / 2), depth: Math.max(6, Math.round(mid(1) * 2) / 2) };
    const key = JSON.stringify(params);
    if (!map.has(key)) map.set(key, params);
    for (const b of c.members) placements.push({ building_id: b.id, key, b });
  }
  placements.sort((x, y) => (x.b.id < y.b.id ? -1 : 1));
  return { map, placements, level: merges };
}
