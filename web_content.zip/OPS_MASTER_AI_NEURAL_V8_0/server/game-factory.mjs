/** Planificateur OPS Game Factory : blueprint déterministe, vérifiable et sans exécution de code. */
const clean = (value, max = 500) => String(value || '').replace(/\s+/g, ' ').trim().slice(0, max);

export function createGameFactoryBlueprint({ title, brief, constraints = [] }) {
  const requirements = String(brief || '')
    .split(/(?<=[.!?])\s+|\n+/)
    .map((line, index) => ({ id: `REQ-${String(index + 1).padStart(3, '0')}`, text: clean(line, 700) }))
    .filter((item) => item.text)
    .slice(0, 30);
  const streams = [
    { id: 'discovery', name: 'Cadrage et inventaire', owner: 'director', depends_on: [], outputs: ['inventaire des fichiers', 'exigences atomiques', 'risques et inconnues'] },
    { id: 'architecture', name: 'Architecture et contrats', owner: 'architecture', depends_on: ['discovery'], outputs: ['architecture cible', 'contrats inter-modules', 'points d’entrée'] },
    { id: 'world', name: 'Monde et ressources', owner: 'world', depends_on: ['architecture'], outputs: ['scènes et ressources', 'structure du monde'] },
    { id: 'gameplay', name: 'Gameplay et systèmes', owner: 'gameplay', depends_on: ['architecture'], outputs: ['boucles de jeu', 'interactions et règles'] },
    { id: 'specialists', name: 'Spécialistes et modules', owner: 'specialists', depends_on: ['world', 'gameplay'], outputs: ['modules spécialisés', 'contrats respectés'] },
    { id: 'integration', name: 'CODER — assemblage', owner: 'coder', depends_on: ['specialists'], outputs: ['fichiers intégrés', 'imports résolus', 'points d’entrée reliés'] },
    { id: 'debug', name: 'DEBUG — revue et corrections', owner: 'debug', depends_on: ['integration'], outputs: ['rapport de défauts', 'correctifs proposés', 'diffs vérifiés'] },
    { id: 'quality', name: 'QUALITY — validation indépendante', owner: 'quality', depends_on: ['debug'], outputs: ['tests', 'non-régression', 'limites connues'] },
    { id: 'delivery', name: 'Livraison et bilan', owner: 'director', depends_on: ['quality'], outputs: ['manifest des fichiers', 'exigences tracées', 'rapport de livraison'] },
  ].map((stream, index) => ({ ...stream, order: index + 1, status: 'planned' }));

  return {
    schema: 'ops.game-factory.v1',
    title: clean(title, 160),
    created_at: new Date().toISOString(),
    requirements,
    constraints: (Array.isArray(constraints) ? constraints : []).map((x) => clean(x, 500)).filter(Boolean).slice(0, 30),
    workstreams: streams,
    dependency_policy: 'Une étape ne peut être déclarée terminée que lorsque ses dépendances sont terminées et ses livrables vérifiables.',
    acceptance_gates: [
      { id: 'G1', name: 'Préservation', rule: 'Aucun fichier ou système existant supprimé sans autorisation explicite.' },
      { id: 'G2', name: 'Traçabilité', rule: 'Chaque exigence est liée à des fichiers, une preuve ou un statut non réalisé.' },
      { id: 'G3', name: 'Intégration', rule: 'Imports locaux et points d’entrée contrôlés.' },
      { id: 'G4', name: 'Qualité', rule: 'Tests disponibles exécutés ; limites et tests impossibles déclarés.' },
      { id: 'G5', name: 'Livraison', rule: 'Manifest des fichiers et version de référence conservés.' },
    ],
  };
}

export function buildFactoryDeliveryReport(blueprint, { files = [], diagnostics = [], regression = null, checks = null } = {}) {
  const paths = new Set(files.map((f) => typeof f === 'string' ? f : f.path).filter(Boolean));
  const blockers = diagnostics.filter((d) => d.severity === 'error');
  return {
    schema: 'ops.game-factory.delivery.v1',
    title: blueprint?.title || 'Production OPS',
    generated_at: new Date().toISOString(),
    requirement_tracking: (blueprint?.requirements || []).map((r) => ({ ...r, status: 'needs_review', evidence_files: [], note: 'La couverture fonctionnelle doit être confirmée par revue des livrables.' })),
    file_manifest: [...paths].sort(),
    integration: { diagnostics: diagnostics.length, blockers: blockers.length, passed: blockers.length === 0 },
    regression: regression ? { passed: Boolean(regression.ok), findings: regression.findings?.length || 0 } : { passed: null, findings: null },
    tests: checks ? { passed: Boolean(checks.passed), summary: checks.summary || null } : { passed: null, summary: null },
    delivery_status: blockers.length || regression?.ok === false || checks?.passed === false ? 'blocked' : 'review_required',
    honesty_rule: 'Aucune exigence ne devient « terminée » sans preuve vérifiable et validation.'
  };
}
