import { uid, now, HttpError } from './util.mjs';

const ACTIVE = new Set(['running','in_progress','accepted']);
const BAD = new Set(['blocked','error','failed']);
const asJson = (v) => { try { return typeof v === 'string' ? JSON.parse(v) : (v ?? []); } catch { return []; } };

export function mapDirectorPlanTasks(tasks, objective, projectName) {
  if (!Array.isArray(tasks) || tasks.length < 1 || tasks.length > 30) throw new HttpError(502, 'Le Director a produit un plan vide ou trop volumineux.');
  const ids = new Map(tasks.map((t, i) => [String(t.id), `agent_task_${i + 1}`]));
  if (ids.size !== tasks.length || tasks.some((t) => !t.id || !t.assignee || !String(t.title || '').trim())) throw new HttpError(502, 'Le plan du Director contient une tâche incomplète ou un identifiant dupliqué.');
  return tasks.map((t) => ({
    id: ids.get(String(t.id)), title: String(t.title).slice(0, 160),
    instruction: `${String(t.description || t.title)}\n\nObjectif global : ${String(objective)}\nProjet : ${String(projectName)}\nLivrable attendu : résultat concret, fichiers proposés via le circuit OPS existant si nécessaire, preuves de validation et limites restantes. Préserve tout travail existant et n’effectue aucune suppression non autorisée.`,
    agent_id: String(t.assignee),
    depends_on: (Array.isArray(t.depends_on) ? t.depends_on : []).map((id) => ids.get(String(id))).filter(Boolean),
  }));
}

/** Superviseur additif : observe les états enregistrés et ne réassigne jamais une tâche existante. */
export function buildSupervisorReport({ project, tasks = [], directorTasks = [], workItems = [], agents = [], claims = [], dependencies = [], files = [], approvedArtifacts = [], now: at = Date.now(), staleAfterMs = 20 * 60_000, actions = [] }) {
  const findings = [];
  const all = [
    ...tasks.map(t => ({ id:t.id, source:'orchestrator', title:t.title, agent_id:t.agent_id, status:t.status, updated:Number(t.updated||t.started||t.created||0), error:t.error||null, depends_on:asJson(t.depends_on) })),
    ...directorTasks.map(t => ({ id:t.id, source:'director', title:t.title, agent_id:t.assignee, status:t.status, updated:Number(t.updated||t.started||t.created||0), error:null, depends_on:asJson(t.depends_on) })),
    ...workItems.map(w => ({ id:w.id, source:'collaboration', title:w.title, agent_id:w.to_agent, status:w.status, updated:Number(w.updated||w.created||0), error:null, depends_on:asJson(w.depends_on) })),
  ];
  for (const t of all) {
    if (BAD.has(t.status)) findings.push({ severity:'high', code:'TASK_BLOCKED', task_id:t.id, source:t.source, agent_id:t.agent_id, title:t.title, message:`État ${t.status}${t.error ? ` : ${String(t.error).slice(0,180)}` : ''}` });
    if (ACTIVE.has(t.status) && t.updated > 0 && at-t.updated > staleAfterMs) findings.push({ severity:'warning', code:'TASK_STALE', task_id:t.id, source:t.source, agent_id:t.agent_id, title:t.title, stale_minutes:Math.floor((at-t.updated)/60000), message:'Aucune mise à jour récente ; vérifier que le processus est toujours actif.' });
  }
  for (const w of workItems.filter(x => ['queued','accepted'].includes(x.status))) findings.push({ severity:'info', code:'HANDOFF_PENDING', task_id:w.id, source:'collaboration', agent_id:w.to_agent, title:w.title, message:`Transmission ${w.status}, en attente de prise en charge.` });
  const fileSet = new Set(files.filter(f=>f.type==='file').map(f=>f.path));
  for (const a of approvedArtifacts) {
    if (a.path && !fileSet.has(a.path)) findings.push({ severity:'high', code:'APPROVED_FILE_MISSING', task_id:a.task_id, agent_id:a.agent_id, title:a.path, message:'Cette proposition est marquée approuvée, mais le fichier correspondant est absent du workspace : intégration à vérifier.' });
  }
  const busy = new Set(all.filter(t=>ACTIVE.has(t.status)).map(t=>t.agent_id).filter(Boolean));
  const available = agents.filter(a=>!!a.enabled&&!busy.has(a.id)).map(a=>({id:a.id,name:a.name,role:a.role}));
  const activeClaims = claims.filter(c=>c.status==='active');
  for (const c of activeClaims) findings.push({severity:'info',code:'FILE_CLAIM_ACTIVE',title:c.path,agent_id:c.agent_id,message:`Ressource réservée par ${c.agent_id}.`});
  return { schema:'ops.autonomous-supervisor.v1', project:{id:project.id,name:project.name}, generated_at:at, mode:'observation', summary:{findings:findings.length,critical:findings.filter(x=>x.severity==='high').length,warning:findings.filter(x=>x.severity==='warning').length,pending_handoffs:workItems.filter(x=>['queued','accepted'].includes(x.status)).length,active_claims:activeClaims.length}, findings, available_agents:available, dependency_count:dependencies.length, recent_actions:actions.slice(0,30) };
}

export function createAutonomousSupervisor(ctx) {
  const { db, collaboration, workspace } = ctx;
  async function collect(projectId) {
    const project=await db.get('SELECT id,name FROM projects WHERE id=?',[projectId]);
    if(!project) throw new HttpError(404,'Projet introuvable');
    const [tasks,directorTasks,workItems,agents,claims,dependencies,files,actions,approvedArtifacts]=await Promise.all([
      db.all('SELECT id,title,agent_id,status,updated,started,created,error,depends_on FROM tasks WHERE project_id=? ORDER BY created DESC LIMIT 500',[projectId]),
      db.all('SELECT id,title,assignee,status,updated,started,created,depends_on FROM director_tasks WHERE project_id=? ORDER BY created DESC LIMIT 500',[projectId]),
      collaboration.listWorkItems(projectId,{limit:250}),
      db.all('SELECT id,name,role,enabled FROM agents ORDER BY sort_order'),
      collaboration.listArtifactClaims(projectId,{activeOnly:true}),
      collaboration.listDependencies(projectId),
      workspace.tree(projectId),
      db.all('SELECT id,kind,task_id,path,agent_id,detail,created FROM supervisor_actions WHERE project_id=? ORDER BY created DESC LIMIT 50',[projectId]),
      db.all("SELECT task_id,agent_id,path,status FROM approvals WHERE project_id=? AND kind='write' AND status='approved' ORDER BY decided DESC LIMIT 500",[projectId]),
    ]);
    return {project,tasks,directorTasks,workItems,agents,claims,dependencies,files,actions,approvedArtifacts};
  }
  async function report(projectId) { const x=await collect(projectId); return buildSupervisorReport({...x,now:now()}); }
  /** Transforme un objectif en plan multi-agents via le Director, puis le lance dans le moteur d'exécution réel. */
  async function launchObjective(projectId, { objective, title, autoStart = true } = {}) {
    const clean = String(objective || '').trim();
    if (clean.length < 12) throw new HttpError(400, 'Décris un objectif d’au moins 12 caractères.');
    if (clean.length > 10000) throw new HttpError(413, 'Objectif trop long (10 000 caractères maximum).');
    if (!ctx.director || !ctx.orchestration) throw new HttpError(503, 'Director ou moteur d’orchestration indisponible.');
    const project = await db.get('SELECT id,name,description FROM projects WHERE id=?', [projectId]);
    if (!project) throw new HttpError(404, 'Projet introuvable');
    const brief = `${clean}

Contexte du projet : ${project.name}. ${project.description || ''}
Contraintes obligatoires : inspecter les fichiers avant modification ; préserver les fonctionnalités existantes ; ne pas remplacer le projet par un prototype ; répartir les tâches entre les IA réellement construites ; définir des livrables vérifiables et des critères d’acceptation ; terminer par une revue QA indépendante. Ne jamais déclarer une modification, un test ou une connexion qui n’a pas réellement été effectué.`;
    const directorPlan = await ctx.director.createPlan({ project_id: projectId, title: title || `Mission autonome · ${clean.slice(0, 90)}`, brief, ai: true });
    const detail = await ctx.director.view(directorPlan.plan.id);
    const tasks = mapDirectorPlanTasks(detail.tasks, clean, project.name);
    const execution = await ctx.orchestration.create(projectId, { title: title || directorPlan.plan.title, tasks });
    await db.run('INSERT INTO supervisor_actions(id,project_id,kind,task_id,path,agent_id,detail,created) VALUES(?,?,?,?,?,?,?,?)', [uid('sup_'), projectId, 'objective_launch', null, null, 'director', JSON.stringify({ director_plan_id: directorPlan.plan.id, orchestration_plan_id: execution.plan.id, task_count: tasks.length }), now()]);
    await collaboration.publish(projectId, { type: 'supervisor.objective.created', from: 'supervisor', payload: { director_plan_id: directorPlan.plan.id, orchestration_plan_id: execution.plan.id, task_count: tasks.length } });
    const started = autoStart ? await ctx.orchestration.start(execution.plan.id) : execution;
    return { objective: clean, director_plan: directorPlan.plan, execution: started, auto_started: !!autoStart, safeguards: { existing_tasks_reassigned: false, file_changes_follow_project_approval_mode: true, shell_commands_auto_executed: false } };
  }
  async function scan(projectId,{mode='observe'}={}) {
    if(!['observe','assist'].includes(mode)) throw new HttpError(400,'Mode invalide : observe ou assist');
    const x=await collect(projectId); const snapshot=buildSupervisorReport({...x,now:now()});
    const created=[];
    if(mode==='assist') {
      // Escalade limitée : aucune modification de tâche existante, 3 transmissions maximum par scan.
      for(const f of snapshot.findings.filter(v=>v.code==='TASK_BLOCKED'&&v.source==='orchestrator').slice(0,3)) {
        const original=x.tasks.find(t=>t.id===f.task_id); if(!original) continue;
        const target=snapshot.available_agents.find(a=>a.id!==original.agent_id);
        if(!target) continue;
        const recent=await db.get("SELECT id FROM supervisor_actions WHERE project_id=? AND task_id=? AND kind='escalation' AND created>? LIMIT 1",[projectId,f.task_id,now()-30*60_000]);
        if(recent) continue;
        const item=await collaboration.createWorkItem(projectId,{from:'supervisor',to:target.id,title:`Analyse de blocage : ${String(original.title||f.task_id).slice(0,100)}`,instruction:`Le superviseur OPS a détecté une tâche bloquée. Analyse la cause sans modifier ni écraser le travail existant. Consulte ses dépendances et les fichiers concernés, propose une correction isolée et signale les risques. Tâche source : ${f.task_id}. Agent initial : ${original.agent_id||'inconnu'}. Erreur : ${String(original.error||'non précisée').slice(0,500)}.`});
        await db.run('INSERT INTO supervisor_actions(id,project_id,kind,task_id,path,agent_id,detail,created) VALUES(?,?,?,?,?,?,?,?)',[uid('sup_'),projectId,'escalation',f.task_id,null,target.id,`Transmission ${item.id}`,now()]); created.push({task_id:f.task_id,agent_id:target.id,work_item_id:item.id});
      }
    }
    await db.run('INSERT INTO supervisor_actions(id,project_id,kind,task_id,path,agent_id,detail,created) VALUES(?,?,?,?,?,?,?,?)',[uid('sup_'),projectId,'scan',null,null,'supervisor',JSON.stringify({mode,findings:snapshot.findings.length,escalations:created.length}),now()]);
    await collaboration.publish(projectId,{type:'supervisor.scan',from:'supervisor',payload:{mode,findings:snapshot.findings.length,escalations:created.length}});
    return { ...await report(projectId), scan:{mode,escalations:created,automatic_reassignment:false,execution_enabled:false} };
  }
  return {report,scan,launchObjective};
}
