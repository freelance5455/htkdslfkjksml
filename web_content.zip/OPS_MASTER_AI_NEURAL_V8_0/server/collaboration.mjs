import { uid, now, HttpError } from './util.mjs';

const EVENT_RE = /^[a-z][a-z0-9_.:-]{1,79}$/;
const ENGINE_RE = /^[a-z][a-z0-9_-]{1,63}$/;
const AGENT_RE = /^[a-z][a-z0-9_-]{0,63}$/;
const WORK_STATES = new Set(['queued','accepted','in_progress','review','done','blocked','cancelled']);
const WORK_TRANSITIONS = { queued:['accepted','in_progress','blocked','cancelled'], accepted:['in_progress','blocked','cancelled'], in_progress:['review','done','blocked','cancelled'], review:['done','in_progress','blocked'], blocked:['queued','cancelled'], done:[], cancelled:['queued'] };
function safeProjectPath(value) { const p=String(value||'').replace(/\\/g,'/').trim(); if (!p || p.startsWith('/') || /^[a-z]:/i.test(p) || p.split('/').some(x=>!x || x==='.' || x==='..')) throw new HttpError(400,'Chemin de ressource invalide'); return p; }
const MAX_PAYLOAD = 24 * 1024;

function encodePayload(value) {
  let raw;
  try { raw = JSON.stringify(value ?? {}); } catch { throw new HttpError(400, 'Payload de collaboration non sérialisable'); }
  if (Buffer.byteLength(raw, 'utf8') > MAX_PAYLOAD) throw new HttpError(413, 'Payload de collaboration trop volumineux (24 Ko max)');
  return raw;
}

/** Bus OPS persistant et gestionnaire de dépendances entre moteurs. */
export function createCollaboration(ctx) {
  const { db, events } = ctx;

  async function publish(projectId, { type, from = 'system', to = null, payload = {} } = {}) {
    if (!projectId || !(await db.get('SELECT id FROM projects WHERE id=?', [projectId]))) throw new HttpError(404, 'Projet introuvable');
    const eventType = String(type || '').trim();
    const source = String(from || 'system').trim();
    const target = to == null || to === '' ? null : String(to).trim();
    if (!EVENT_RE.test(eventType)) throw new HttpError(400, 'Type d’événement invalide');
    if (!/^[a-z][a-z0-9_-]{0,63}$/.test(source)) throw new HttpError(400, 'Agent source invalide');
    if (target && !/^[a-z][a-z0-9_-]{0,63}$/.test(target)) throw new HttpError(400, 'Agent destinataire invalide');
    const body = encodePayload(payload);
    const row = { id: uid('bus_'), project_id: projectId, type: eventType, from_agent: source, to_agent: target, payload: JSON.parse(body), created: now() };
    await db.run('INSERT INTO collaboration_events(id,project_id,type,from_agent,to_agent,payload,created) VALUES(?,?,?,?,?,?,?)', [row.id, projectId, eventType, source, target, body, row.created]);
    events?.emit?.('collaboration.event', row);
    return row;
  }

  async function listEvents(projectId, { agentId = null, limit = 100, since = 0 } = {}) {
    if (!projectId || !(await db.get('SELECT id FROM projects WHERE id=?', [projectId]))) throw new HttpError(404, 'Projet introuvable');
    const n = Math.max(1, Math.min(250, Math.floor(Number(limit) || 100)));
    const rows = await db.all(`SELECT * FROM collaboration_events WHERE project_id=? AND created>=? ${agentId ? 'AND (to_agent IS NULL OR to_agent=?)' : ''} ORDER BY created DESC LIMIT ?`, agentId ? [projectId, Math.max(0, Number(since) || 0), agentId, n] : [projectId, Math.max(0, Number(since) || 0), n]);
    return rows.map((r) => ({ ...r, payload: JSON.parse(r.payload || '{}') }));
  }

  async function addDependency(projectId, prerequisite, dependent, contract = '') {
    if (!projectId || !(await db.get('SELECT id FROM projects WHERE id=?', [projectId]))) throw new HttpError(404, 'Projet introuvable');
    const from = String(prerequisite || '').trim(), to = String(dependent || '').trim();
    if (!ENGINE_RE.test(from) || !ENGINE_RE.test(to) || from === to) throw new HttpError(400, 'Dépendance moteur invalide');
    const edges = await db.all('SELECT prerequisite,dependent FROM engine_dependencies WHERE project_id=?', [projectId]);
    const graph = new Map();
    for (const e of edges) graph.set(e.prerequisite, [...(graph.get(e.prerequisite) || []), e.dependent]);
    const stack = [to], seen = new Set();
    while (stack.length) {
      const node = stack.pop();
      if (node === from) throw new HttpError(409, `Dépendance cyclique refusée : ${from} → ${to}`);
      if (seen.has(node)) continue;
      seen.add(node); stack.push(...(graph.get(node) || []));
    }
    await db.run(`INSERT INTO engine_dependencies(id,project_id,prerequisite,dependent,contract,created) VALUES(?,?,?,?,?,?) ON CONFLICT(project_id,prerequisite,dependent) DO UPDATE SET contract=excluded.contract`, [uid('dep_'), projectId, from, to, String(contract).slice(0, 1200), now()]);
    const result = { prerequisite: from, dependent: to, contract: String(contract).slice(0, 1200) };
    events?.emit?.('collaboration.dependency', { project_id: projectId, ...result });
    return result;
  }

  async function listDependencies(projectId) {
    if (!projectId || !(await db.get('SELECT id FROM projects WHERE id=?', [projectId]))) throw new HttpError(404, 'Projet introuvable');
    return db.all('SELECT prerequisite,dependent,contract,created FROM engine_dependencies WHERE project_id=? ORDER BY prerequisite,dependent', [projectId]);
  }

  async function createWorkItem(projectId, { from = 'coordinator', to, title, instruction, depends_on = [] } = {}) {
    if (!projectId || !(await db.get('SELECT id FROM projects WHERE id=?', [projectId]))) throw new HttpError(404, 'Projet introuvable');
    const source=String(from||'coordinator').trim(), target=String(to||'').trim();
    if (!AGENT_RE.test(source) || !AGENT_RE.test(target) || source===target) throw new HttpError(400,'Agents de transmission invalides');
    const cleanTitle=String(title||'Transmission inter-IA').trim().slice(0,160);
    const body=String(instruction||'').trim().slice(0,12000);
    if (!body) throw new HttpError(400,'Instruction de transmission obligatoire');
    const deps=[...new Set((Array.isArray(depends_on)?depends_on:[]).map(x=>String(x).slice(0,100)))].slice(0,30);
    const id=uid('handoff_'), ts=now();
    await db.run("INSERT INTO collaboration_work_items(id,project_id,from_agent,to_agent,title,instruction,status,depends_on,result,created,updated) VALUES(?,?,?,?,?,?,'queued',?,NULL,?,?)",[id,projectId,source,target,cleanTitle,body,JSON.stringify(deps),ts,ts]);
    await publish(projectId,{type:'work.handoff',from:source,to:target,payload:{work_item_id:id,title:cleanTitle,depends_on:deps}});
    return getWorkItem(id);
  }

  async function getWorkItem(id) {
    const r=await db.get('SELECT * FROM collaboration_work_items WHERE id=?',[id]);
    if(!r) throw new HttpError(404,'Transmission introuvable');
    return {...r,depends_on:JSON.parse(r.depends_on||'[]')};
  }

  async function listWorkItems(projectId,{agentId=null,status=null,limit=100}={}) {
    if(!projectId || !(await db.get('SELECT id FROM projects WHERE id=?',[projectId]))) throw new HttpError(404,'Projet introuvable');
    const clauses=['project_id=?'], params=[projectId];
    if(agentId){clauses.push('(to_agent=? OR from_agent=?)');params.push(agentId,agentId);}
    if(status){if(!WORK_STATES.has(status)) throw new HttpError(400,'État de transmission invalide');clauses.push('status=?');params.push(status);}
    params.push(Math.max(1,Math.min(250,Math.floor(Number(limit)||100))));
    const rows=await db.all(`SELECT * FROM collaboration_work_items WHERE ${clauses.join(' AND ')} ORDER BY created DESC LIMIT ?`,params);
    return rows.map(r=>({...r,depends_on:JSON.parse(r.depends_on||'[]')}));
  }

  async function updateWorkItem(id,{agentId,status,result}={}) {
    const item=await getWorkItem(id), actor=String(agentId||'').trim();
    if(actor!=='user' && actor!==item.to_agent && actor!==item.from_agent) throw new HttpError(403,'Seuls les agents concernés ou l’utilisateur peuvent modifier cette transmission');
    if(!WORK_STATES.has(status)) throw new HttpError(400,'État de transmission invalide');
    if(!WORK_TRANSITIONS[item.status].includes(status) && item.status!==status) throw new HttpError(409,`Transition interdite : ${item.status} → ${status}`);
    const value=result===undefined?item.result:String(result).slice(0,12000), ts=now();
    await db.run('UPDATE collaboration_work_items SET status=?,result=?,updated=? WHERE id=?',[status,value,ts,id]);
    await publish(item.project_id,{type:'work.status',from:actor==='user'?'coordinator':actor,to:null,payload:{work_item_id:id,status,result:value?String(value).slice(0,500):null}});
    return getWorkItem(id);
  }

  async function claimArtifacts(projectId,{agentId,workItemId=null,paths=[]}={}) {
    if(!projectId || !(await db.get('SELECT id FROM projects WHERE id=?',[projectId]))) throw new HttpError(404,'Projet introuvable');
    const agent=String(agentId||'').trim(); if(!AGENT_RE.test(agent)) throw new HttpError(400,'Agent invalide');
    const unique=[...new Set((Array.isArray(paths)?paths:[]).map(safeProjectPath))].slice(0,100);
    const claims=[];
    for(const filePath of unique){
      const current=await db.get('SELECT * FROM collaboration_artifact_claims WHERE project_id=? AND path=?',[projectId,filePath]);
      if(current && current.status==='active' && (current.agent_id!==agent || current.work_item_id!==workItemId)) {
        await publish(projectId,{type:'artifact.conflict',from:agent,to:current.agent_id,payload:{path:filePath,owner:current.agent_id,work_item_id:current.work_item_id,requesting_work_item_id:workItemId}});
        throw new HttpError(409,`Ressource déjà réservée par ${current.agent_id} : ${filePath}`,'artifact_conflict');
      }
      const id=current?.id||uid('claim_'),ts=now();
      await db.run(`INSERT INTO collaboration_artifact_claims(id,project_id,path,agent_id,work_item_id,status,created,updated) VALUES(?,?,?,?,?,'active',?,?) ON CONFLICT(project_id,path) DO UPDATE SET agent_id=excluded.agent_id,work_item_id=excluded.work_item_id,status='active',updated=excluded.updated`,[id,projectId,filePath,agent,workItemId,ts,ts]);
      claims.push({id,project_id:projectId,path:filePath,agent_id:agent,work_item_id:workItemId,status:'active'});
    }
    return claims;
  }

  async function releaseArtifacts(projectId,{agentId,paths=null,workItemId=null}={}) {
    const clauses=['project_id=?',"status='active'"],params=[projectId];
    if(agentId){clauses.push('agent_id=?');params.push(agentId);}
    if(workItemId){clauses.push('work_item_id=?');params.push(workItemId);}
    if(paths){const clean=[...new Set(paths.map(safeProjectPath))];if(!clean.length)return {released:0};clauses.push(`path IN (${clean.map(()=>'?').join(',')})`);params.push(...clean);}
    const rows=await db.all(`SELECT path,agent_id FROM collaboration_artifact_claims WHERE ${clauses.join(' AND ')}`,params);
    await db.run(`UPDATE collaboration_artifact_claims SET status='released',updated=? WHERE ${clauses.join(' AND ')}`,[now(),...params]);
    for(const r of rows) await publish(projectId,{type:'artifact.released',from:r.agent_id,payload:{path:r.path}});
    return {released:rows.length};
  }

  async function listArtifactClaims(projectId,{activeOnly=true}={}) {
    if(!projectId || !(await db.get('SELECT id FROM projects WHERE id=?',[projectId]))) throw new HttpError(404,'Projet introuvable');
    return db.all(`SELECT * FROM collaboration_artifact_claims WHERE project_id=? ${activeOnly?"AND status='active'":""} ORDER BY path`,[projectId]);
  }

  async function contextFor(projectId, agentId, limit = 12) {
    const rows = await listEvents(projectId, { agentId, limit });
    const inbox = agentId ? (await listWorkItems(projectId,{agentId,limit:50})).filter(w=>['queued','accepted','in_progress','review','blocked'].includes(w.status)).slice(0,20) : [];
    const claims = await listArtifactClaims(projectId,{activeOnly:true});
    const eventText=rows.reverse().map((e) => `[${e.type}] ${e.from_agent}${e.to_agent ? ` → ${e.to_agent}` : ' → équipe'} : ${JSON.stringify(e.payload).slice(0, 1200)}`).join('\n');
    const inboxText=inbox.map(w=>`[TRANSMISSION ${w.id} · ${w.status}] ${w.from_agent} → ${w.to_agent} : ${w.title} — ${w.instruction.slice(0,1000)}`).join('\n');
    const claimText=claims.map(c=>`${c.path} réservé par ${c.agent_id}`).join('\n');
    return [eventText,inboxText?`TRANSMISSIONS EN ATTENTE :\n${inboxText}`:'',claimText?`RESSOURCES ACTUELLEMENT RÉSERVÉES :\n${claimText}`:''].filter(Boolean).join('\n\n');
  }

  return { publish, listEvents, addDependency, listDependencies, contextFor, createWorkItem, getWorkItem, listWorkItems, updateWorkItem, claimArtifacts, releaseArtifacts, listArtifactClaims };
}
