import fs from 'node:fs';
import path from 'node:path';
import { uid, now, j, pj, HttpError } from './util.mjs';
import { analyzeArtifactGraph } from './artifact-graph.mjs';
import { createGameFactoryBlueprint, buildFactoryDeliveryReport } from './game-factory.mjs';

const treeFilesForReport = (tree) => tree.filter((entry) => entry.type === 'file').map((entry) => entry.path);

/** Pipeline de production OPS : snapshot, orchestration multi-agents, contrôles et version livrable. */
export function createProduction(ctx) {
  const { db, workspace, orchestrator, testing } = ctx;

  const STAGES = [
    { id: 'analysis', label: 'Analyse et cadrage' },
    { id: 'architecture', label: 'Architecture et contrats' },
    { id: 'specialists', label: 'Travail des spécialistes' },
    { id: 'implementation', label: 'Implémentation et assemblage CODER' },
    { id: 'review', label: 'Relecture et corrections' },
    { id: 'quality', label: 'Tests et non-régression' },
    { id: 'delivery', label: 'Rapport et livraison' },
  ];

  function stageProgress(run, pipelineStatus) {
    const tasks = run?.tasks || [];
    const total = tasks.length;
    const done = tasks.filter((t) => t.status === 'done').length;
    const failed = tasks.filter((t) => ['error', 'failed'].includes(t.status)).length;
    const active = tasks.filter((t) => ['running', 'in_progress'].includes(t.status)).length;
    const terminal = ['ready_for_review', 'quality_failed', 'development_failed', 'partial'].includes(pipelineStatus);
    const ratio = total ? Math.round(done / total * 100) : (pipelineStatus === 'running' ? 0 : 100);
    const idx = pipelineStatus === 'awaiting_approval' ? 4 : pipelineStatus === 'ready_for_review' ? 6 : pipelineStatus === 'quality_failed' ? 5 : Math.min(3, Math.floor(ratio / 25));
    return { percent: ratio, tasks: { total, done, active, failed }, current_stage: STAGES[idx]?.id || 'analysis', stages: STAGES.map((s, i) => ({ ...s, status: terminal ? (i < idx ? 'done' : i === idx ? (pipelineStatus === 'ready_for_review' ? 'done' : 'blocked') : 'pending') : i < idx ? 'done' : i === idx ? 'active' : 'pending' })) };
  }

  async function get(id) {
    const row = await db.get('SELECT * FROM production_pipelines WHERE id=?', [id]);
    if (!row) throw new HttpError(404, 'Pipeline de production introuvable');
    const pipeline = { ...row, brief: pj(row.brief, {}), checks: pj(row.checks, null) };
    let run = null;
    try { run = await orchestrator.getRun(row.run_id); } catch (error) { if (error?.status !== 404 && error?.statusCode !== 404) throw error; }
    return { ...pipeline, progress: stageProgress(run, row.status), run };
  }

  async function inspectIntegration(projectId, baselineId) {
    const tree = workspace.tree(projectId).filter((entry) => entry.type === 'file');
    const graphFiles = [];
    const supported = /\.(?:[cm]?[jt]sx?|vue|svelte|html?)$/i;
    for (const entry of tree) {
      if (!supported.test(entry.path)) continue;
      try {
        const file = workspace.readFile(projectId, entry.path, { maxBytes: 1024 * 1024 });
        if (!file.binary) graphFiles.push({ path: file.path, content: file.content });
      } catch { /* fichiers volumineux/illisibles signalés par les contrôles dédiés */ }
    }
    const graph = analyzeArtifactGraph(graphFiles, tree.map((entry) => entry.path));
    const regression = await workspace.regression(projectId, baselineId);
    const diagnostics = graph.diagnostics.slice(0, 200);
    return { graph: { summary: graph.summary, edges: graph.edges.slice(0, 500), diagnostics }, regression };
  }

  async function start({ project_id, title, brief, constraints = [] }) {
    const project = await workspace.getProject(project_id);
    const text = String(brief || '').trim();
    if (!text) throw new HttpError(400, 'Le cahier des charges du jeu est obligatoire');
    if (text.length > 18000) throw new HttpError(413, 'Cahier des charges trop long');
    const baseline = await workspace.createVersion(project_id, { label: `OPS — Avant production : ${title || project.name}`, reason: 'production-baseline' });
    const pipelineId = uid('prod_');
    const productionBrief = {
      title: String(title || project.name).slice(0, 160),
      requirements: text,
      constraints: Array.isArray(constraints) ? constraints.map(x => String(x).slice(0, 500)).slice(0, 30) : [],
      phases: ['analyse du cahier des charges', 'architecture et contrats moteurs', 'répartition parallèle des spécialistes', 'implémentation et assemblage par OPS CODER AI', 'relecture croisée et corrections', 'contrôles syntaxiques et non-régression', 'rapport de livraison'],
      rules: ['Préserver les fonctionnalités et fichiers existants.', 'Inspecter les fichiers avant toute modification.', 'Les moteurs restent indépendants et interconnectés.', 'Ne jamais déclarer une fonction terminée sans code relié au point d’entrée.', 'Signaler clairement les éléments non implémentés et les tests impossibles.'],
    };
    productionBrief.factory = createGameFactoryBlueprint({ title: productionBrief.title, brief: text, constraints: productionBrief.constraints });
    const factoryInstructions = productionBrief.factory.workstreams.map((w) => `${w.order}. ${w.name} [${w.owner}] — dépendances : ${w.depends_on.join(', ') || 'aucune'} — livrables : ${w.outputs.join(', ')}`).join('\n');
    const instruction = `MISSION OPS AUTONOMOUS GAME PRODUCTION\nTitre : ${productionBrief.title}\n\nCAHIER DES CHARGES :\n${text}\n\nCONTRAINTES :\n${productionBrief.constraints.map(x => `- ${x}`).join('\n') || '- Aucune contrainte supplémentaire.'}\n\nPIPELINE OBLIGATOIRE : ${productionBrief.phases.join(' → ')}.\n\nPLAN FACTORY STRUCTURÉ :\n${factoryInstructions}\n\nEXIGENCES À TRACER :\n${productionBrief.factory.requirements.map((r) => `${r.id}: ${r.text}`).join('\n')}\n\nRÈGLES NON NÉGOCIABLES : ${productionBrief.rules.join(' ')}\n\nOPS CODER AI doit être responsable de l'implémentation et de l'assemblage. Les spécialistes produisent des livrables compatibles avec des contrats explicites. Propose des fichiers concrets via les outils du workspace. Ne prétends pas avoir écrit un fichier si tu ne l'as pas réellement proposé. Termine avec la liste des fichiers, fonctions intégrées, validations, limites et tâches restant à approuver.`;
    const run_id = await orchestrator.start({ projectId: project_id, instruction, mode: 'team' });
    await db.run('INSERT INTO production_pipelines(id,project_id,run_id,title,brief,status,baseline_version_id,checks,final_version_id,created,updated) VALUES(?,?,?,?,?,?,?,?,?,?,?)', [pipelineId, project_id, run_id, productionBrief.title, j(productionBrief), 'running', baseline.id, null, null, now(), now()]);
    await workspace.log(project_id, 'production', 'production.start', `${productionBrief.title} / ${pipelineId}`);
    ctx.events?.emit('production', { project_id, pipeline_id: pipelineId, status: 'running' });
    return get(pipelineId);
  }

  async function refresh(id) {
    const p = await get(id);
    if (!['running', 'awaiting_approval'].includes(p.status)) return { ...p, run: await orchestrator.getRun(p.run_id) };
    const run = await orchestrator.getRun(p.run_id);
    if (!['done', 'partial', 'failed', 'cancelled', 'interrupted'].includes(run.status)) return { ...p, run };
    if (run.status !== 'done') {
      await db.run('UPDATE production_pipelines SET status=?, updated=? WHERE id=?', [run.status === 'partial' ? 'partial' : 'development_failed', now(), id]);
      return { ...(await get(id)), run };
    }
    const approvals = await db.get("SELECT SUM(CASE WHEN status='pending' THEN 1 ELSE 0 END) AS pending, SUM(CASE WHEN status='rejected' THEN 1 ELSE 0 END) AS rejected FROM approvals WHERE run_id=?", [p.run_id]);
    if (Number(approvals?.pending || 0) > 0) {
      await db.run('UPDATE production_pipelines SET status=?, updated=? WHERE id=?', ['awaiting_approval', now(), id]);
      return { ...(await get(id)), run, pending_approvals: Number(approvals.pending) };
    }
    if (Number(approvals?.rejected || 0) > 0) {
      await db.run('UPDATE production_pipelines SET status=?, checks=?, updated=? WHERE id=?', ['quality_failed', j({ passed: false, reason: 'Certaines propositions de fichiers ont été refusées.' }), now(), id]);
      return { ...(await get(id)), run, pending_approvals: 0 };
    }
    const checks = await testing.runChecks(p.project_id);
    const integration = await inspectIntegration(p.project_id, p.baseline_version_id);
    const regressionPassed = integration.regression.ok;
    const passed = checks.passed && regressionPassed;
    const factoryReport = buildFactoryDeliveryReport(p.brief?.factory, { files: treeFilesForReport(await workspace.tree(p.project_id)), diagnostics: integration.graph.diagnostics, regression: integration.regression, checks });
    let finalVersion = null;
    const status = passed ? 'ready_for_review' : 'quality_failed';
    if (passed) finalVersion = await workspace.createVersion(p.project_id, { label: `OPS — Livrable : ${p.title}`, reason: 'production-delivery' });
    await db.run('UPDATE production_pipelines SET status=?, checks=?, final_version_id=?, updated=? WHERE id=?', [status, j({ id: checks.id, passed, summary: checks.summary, integration, factory_report: factoryReport, gates: { static_tests: checks.passed, regression: regressionPassed, graph_warnings: integration.graph.summary.warnings } }), finalVersion?.id || null, now(), id]);
    await workspace.log(p.project_id, 'production', 'production.finalize', `${id} : ${status}`);
    ctx.events?.emit('production', { project_id: p.project_id, pipeline_id: id, status });
    return { ...(await get(id)), run, checks, integration, final_version: finalVersion };
  }

  /** Reprend une production arrêtée en conservant son brief, sa baseline et l'historique des tentatives. */
  async function resume(id) {
    const p = await get(id);
    if (['running', 'awaiting_approval'].includes(p.status)) {
      throw new HttpError(409, p.status === 'running' ? 'Cette production est déjà en cours.' : 'Validez ou refusez les propositions en attente avant de reprendre.', 'production_not_resumable');
    }
    if (p.status === 'ready_for_review') throw new HttpError(409, 'Cette production est déjà prête pour revue.', 'production_already_ready');
    if (!['partial', 'development_failed', 'quality_failed'].includes(p.status)) {
      throw new HttpError(409, `Le statut ${p.status} ne permet pas une reprise.`, 'production_not_resumable');
    }

    let previousRun = p.run;
    if (!previousRun) {
      try { previousRun = await orchestrator.getRun(p.run_id); } catch { previousRun = null; }
    }
    const history = Array.isArray(p.brief?.resume_history) ? [...p.brief.resume_history] : [];
    history.push({
      run_id: p.run_id,
      status: p.status,
      resumed_at: now(),
      report_excerpt: String(previousRun?.report || previousRun?.error || '').slice(0, 5000),
      task_summary: (previousRun?.tasks || []).map((task) => ({ id: task.id, title: task.title, agent_id: task.agent_id, status: task.status, error: task.error || null })).slice(0, 100),
      checks: p.checks ? { passed: p.checks.passed ?? null, reason: p.checks.reason || null, summary: p.checks.summary || null } : null,
    });
    const updatedBrief = { ...p.brief, resume_history: history.slice(-20), resume_count: Number(p.brief?.resume_count || 0) + 1 };
    const tree = workspace.tree(p.project_id).filter((entry) => entry.type === 'file').map((entry) => entry.path).slice(0, 500);
    const latestDiagnostics = await inspectIntegration(p.project_id, p.baseline_version_id);
    const retryInstruction = `REPRISE DE PRODUCTION OPS — ${p.title}

Cette production a déjà été commencée. NE RECOMMENCE PAS le projet depuis zéro et ne remplace pas les fonctionnalités existantes. Reprends exactement à partir de l'état actuel du workspace.

CAHIER DES CHARGES ORIGINAL :
${p.brief?.requirements || p.brief?.requirements_text || 'Voir le blueprint de production conservé.'}

CONTRAINTES :
${(p.brief?.constraints || []).map((x) => `- ${x}`).join('\n') || '- Préserver intégralement les systèmes existants.'}

ÉTAT ACTUEL DES FICHIERS :
${tree.map((x) => `- ${x}`).join('\n') || '- Aucun fichier détecté'}

RAPPORT DE LA TENTATIVE PRÉCÉDENTE :
${String(previousRun?.report || previousRun?.error || 'Aucun rapport exploitable.').slice(0, 7000)}

DIAGNOSTICS D’INTÉGRATION ACTUELS :
${JSON.stringify(latestDiagnostics.graph.diagnostics.slice(0, 80))}

HISTORIQUE DES REPRISES : ${history.length}

MISSION : inspecte d'abord le workspace actuel, identifie uniquement les exigences non terminées ou les défauts signalés, puis planifie les tâches restantes. Réutilise les fichiers déjà corrects. Modifie les fichiers de manière ciblée, conserve les sauvegardes et respecte le mode approval/auto du projet. Fais intervenir les spécialistes utiles, puis CODER, DEBUG et QUALITY. N'exécute aucun script du projet sans autorisation explicite. Termine par un bilan précis des tâches achevées, restantes, fichiers modifiés et tests réellement exécutés.`;
    const newRunId = await orchestrator.start({ projectId: p.project_id, instruction: retryInstruction, mode: 'team' });
    await db.run('UPDATE production_pipelines SET run_id=?, brief=?, status=?, checks=?, final_version_id=NULL, updated=? WHERE id=?', [newRunId, j(updatedBrief), 'running', j({ resumed_from: p.run_id, resume_count: updatedBrief.resume_count, previous_status: p.status }), now(), id]);
    await workspace.log(p.project_id, 'production', 'production.resume', `${id} : ${p.run_id} → ${newRunId}`);
    ctx.events?.emit('production', { project_id: p.project_id, pipeline_id: id, run_id: newRunId, status: 'running', resumed: true });
    return { ...(await get(id)), resumed: true, previous_run_id: p.run_id, run_id: newRunId, resume_count: updatedBrief.resume_count };
  }

  /** Exécution facultative des scripts du projet. Nécessite une autorisation explicite et une action utilisateur. */
  async function executeChecks(id) {
    const p = await get(id);
    if (p.status !== 'ready_for_review' && !(p.status === 'quality_failed' && p.checks?.runtime)) {
      throw new HttpError(409, 'Les contrôles d’exécution sont disponibles après la validation statique du pipeline.');
    }
    const project = await workspace.getProject(p.project_id);
    if (!project.allow_exec) {
      throw new HttpError(403, 'Autorisez d’abord « Exécution de code » dans les paramètres du projet.', 'exec_not_allowed');
    }
    const packagePath = path.join(workspace.wdir(p.project_id), 'package.json');
    let pkg;
    try { pkg = JSON.parse(fs.readFileSync(packagePath, 'utf8')); }
    catch { throw new HttpError(404, 'package.json absent ou invalide : aucun script ne peut être lancé.'); }
    const scripts = ['test', 'build'].filter((name) => typeof pkg.scripts?.[name] === 'string' && pkg.scripts[name].trim());
    if (!scripts.length) throw new HttpError(400, 'Aucun script npm test ou build trouvé dans package.json.');

    const executions = [];
    for (const script of scripts) {
      const result = await testing.runScript(p.project_id, script);
      executions.push({ script, passed: result.passed, exit_code: result.exit_code, timeout: result.timeout, duration_ms: result.duration_ms, output: String(result.output || '').slice(-12000) });
      if (!result.passed) break;
    }
    const passed = executions.length === scripts.length && executions.every((x) => x.passed);
    const checks = { ...(p.checks || {}), runtime: { passed, scripts, executions, executed_at: now() } };
    let finalVersion = null;
    if (passed) finalVersion = await workspace.createVersion(p.project_id, { label: `OPS — Livrable validé : ${p.title}`, reason: 'production-runtime-validation' });
    await db.run('UPDATE production_pipelines SET status=?, checks=?, final_version_id=?, updated=? WHERE id=?', [passed ? 'ready_for_review' : 'quality_failed', j(checks), finalVersion?.id || null, now(), id]);
    await workspace.log(p.project_id, 'production', 'production.runtime-checks', `${id} : ${passed ? 'réussite' : 'échec'}`);
    ctx.events?.emit('production', { project_id: p.project_id, pipeline_id: id, status: passed ? 'ready_for_review' : 'quality_failed' });
    return { ...(await get(id)), runtime: checks.runtime, final_version: finalVersion };
  }

  return {
    start, get: refresh, resume, executeChecks, inspectIntegration,
    async list(projectId) {
      const rows = await db.all('SELECT id,project_id,run_id,title,status,baseline_version_id,final_version_id,created,updated FROM production_pipelines WHERE project_id=? ORDER BY created DESC LIMIT 50', [projectId]);
      return rows;
    },
  };
}
