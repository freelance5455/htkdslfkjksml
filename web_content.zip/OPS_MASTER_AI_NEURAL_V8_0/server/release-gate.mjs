/** Release Gate OPS : synthèse factuelle avant livraison, sans exécuter de code projet. */
import { HttpError } from './util.mjs';

const ENTRY = /(^|\/)(index\.html|package\.json|src\/(main|index)\.[cm]?[jt]sx?|main\.[cm]?[jt]sx?)$/i;
const hasTestScript = (scripts) => Object.keys(scripts || {}).some(k => /^(test|check|lint)(:|$)/i.test(k));

export function buildReleaseGate({ project, files = [], supervisor = {}, benchmark = {}, readiness = {} }) {
  const checks = [];
  const fileRows = files.filter(f => f.type === 'file');
  const entrypoints = fileRows.filter(f => ENTRY.test(f.path));
  const packageFile = fileRows.find(f => f.path === 'package.json');
  let packageJson = null;
  let packageError = null;
  if (packageFile?.content) {
    try { packageJson = JSON.parse(packageFile.content); }
    catch (e) { packageError = String(e.message || e).slice(0, 180); }
  }
  checks.push({ id:'project', status: project ? 'pass' : 'block', detail: project ? `Projet « ${project.name} » trouvé` : 'Projet introuvable' });
  checks.push({ id:'entrypoint', status: entrypoints.length ? 'pass' : 'block', detail: entrypoints.length ? `${entrypoints.length} point(s) d’entrée détecté(s)` : 'Aucun point d’entrée HTML ou JavaScript détecté' });
  checks.push({ id:'package-json', status: packageError ? 'block' : packageFile ? 'pass' : 'review', detail: packageError ? `package.json invalide : ${packageError}` : packageFile ? 'package.json lisible' : 'Aucun package.json ; acceptable pour un projet HTML autonome' });
  const testScript = packageJson?.scripts && hasTestScript(packageJson.scripts);
  checks.push({ id:'test-command', status: testScript ? 'pass' : 'review', detail: testScript ? 'Commande de test déclarée (son exécution n’est pas attestée par ce contrôle)' : 'Aucune commande de test détectée' });
  const high = Number(supervisor.summary?.critical || 0);
  checks.push({ id:'supervisor', status: high ? 'block' : 'pass', detail: high ? `${high} anomalie(s) critique(s) détectée(s)` : 'Aucune anomalie critique remontée par le superviseur' });
  const tasks = Number(benchmark.summary?.tasks || 0);
  checks.push({ id:'execution-evidence', status: tasks > 0 ? 'pass' : 'review', detail: tasks > 0 ? `${tasks} tâche(s) observée(s) dans les benchmarks` : 'Aucune tâche mesurée ; preuves d’exécution insuffisantes' });
  const readinessStatus = readiness.summary?.status || 'unknown';
  checks.push({ id:'runtime-readiness', status: readinessStatus === 'blocked' ? 'review' : readinessStatus === 'ready' ? 'pass' : 'review', detail: readinessStatus === 'ready' ? 'Configuration opérationnelle déclarée prête' : readinessStatus === 'blocked' ? 'Des dépendances ou fournisseurs sont bloqués' : 'Configuration partielle ou non vérifiée' });
  const blocked = checks.some(x => x.status === 'block');
  const review = checks.some(x => x.status === 'review') || Number(supervisor.summary?.warning || 0) > 0 || Number(supervisor.summary?.pending_handoffs || 0) > 0;
  const status = blocked ? 'blocked' : review ? 'review' : 'candidate';
  return {
    schema:'ops.release-gate.v1', generated_at:Date.now(), project:{id:project?.id || null,name:project?.name || null},
    status, release_allowed:status === 'candidate',
    summary:{passed:checks.filter(x=>x.status==='pass').length,review:checks.filter(x=>x.status==='review').length,blocked:checks.filter(x=>x.status==='block').length,total:checks.length},
    checks, findings:(supervisor.findings || []).slice(0,100),
    evidence:{file_count:fileRows.length,entrypoints:entrypoints.map(x=>x.path),benchmark_tasks:tasks,supervisor_warnings:Number(supervisor.summary?.warning||0),pending_handoffs:Number(supervisor.summary?.pending_handoffs||0)},
    limitations:['Ce contrôle est statique et n’exécute aucun script du projet.','Une commande de test déclarée ne prouve pas qu’elle a été exécutée ni réussie.','Un statut « candidate » est une présélection interne, pas une certification de publication.','La qualité fonctionnelle, visuelle, mobile et la sécurité doivent encore être vérifiées sur les appareils et environnements cibles.']
  };
}

export function createReleaseGate(ctx) {
  return {
    async report(projectId) {
      const project = await ctx.workspace.getProject(projectId);
      if (!project) throw new HttpError(404, 'Projet introuvable');
      const [files, supervisor, benchmark, readiness] = await Promise.all([
        Promise.resolve(ctx.workspace.tree(projectId)), ctx.supervisor.report(projectId),
        ctx.benchmark.report(projectId), ctx.readiness.report(projectId)
      ]);
      const enriched = await Promise.all(files.filter(x=>x.type==='file' && x.path==='package.json').map(async x => ({...x,content:ctx.workspace.readFile(projectId,'package.json',{maxBytes:128*1024}).content})));
      return buildReleaseGate({project,files:files.map(x=>enriched.find(y=>y.path===x.path)||x),supervisor,benchmark,readiness});
    }
  };
}
