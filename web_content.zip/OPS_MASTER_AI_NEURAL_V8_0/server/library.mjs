import fs from 'node:fs';
import path from 'node:path';
import { uid, now, j, pj, sha1, HttpError } from './util.mjs';

const MAX_ITEM = 8 * 1024 * 1024; // limité par la taille maximale d'une requête JSON (base64)
const MIME = { txt: 'text/plain', md: 'text/markdown', json: 'application/json', js: 'text/javascript', mjs: 'text/javascript', html: 'text/html', css: 'text/css', csv: 'text/csv', png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', gif: 'image/gif', webp: 'image/webp', svg: 'image/svg+xml', pdf: 'application/pdf', zip: 'application/zip', glb: 'model/gltf-binary', gltf: 'model/gltf+json', fbx: 'application/octet-stream', obj: 'text/plain', mp3: 'audio/mpeg', wav: 'audio/wav', ogg: 'audio/ogg' };
const TEXT_EXT = new Set(['txt', 'md', 'json', 'js', 'mjs', 'html', 'css', 'csv', 'svg', 'gltf', 'obj', 'xml', 'yml', 'yaml', 'ts', 'glsl']);

export const cleanName = (n) => String(n || '').replace(/[\\/\0]/g, '_').replace(/^\.+/, '').trim().slice(0, 120);
const extOf = (n) => (n.split('.').pop() || '').toLowerCase();

/** Bibliothèque de fichiers : stockage central, global (partagé volontairement) ou propre à un projet (jamais mélangé). */
export function createLibrary(ctx) {
  const { db, config, workspace } = ctx;
  const dir = path.join(config.dataDir, 'library');
  const blob = (id) => path.join(dir, id + '.bin');
  fs.mkdirSync(path.join(dir, 'trash'), { recursive: true });

  const pub = (r) => r && { id: r.id, name: r.name, mime: r.mime, size: Number(r.size), sha1: r.sha1, tags: pj(r.tags, []), description: r.description || '', project_id: r.project_id || null, text: TEXT_EXT.has(extOf(r.name)), created: Number(r.created) };
  const get = async (id) => { const r = await db.get('SELECT * FROM library_items WHERE id=?', [id]); if (!r) throw new HttpError(404, 'Élément introuvable'); return r; };
  /** Un élément est visible s'il est global ou appartient au projet demandé. */
  const visible = (r, pid) => !r.project_id || r.project_id === pid;
  const tagsOf = (t) => (Array.isArray(t) ? t : String(t || '').split(',')).map((x) => String(x).trim().toLowerCase()).filter(Boolean).slice(0, 12);

  const api = {
    pub, get,
    async add({ name, buf, tags, description, project_id, actor = 'user' }) {
      name = cleanName(name);
      if (!name) throw new HttpError(400, 'Nom requis');
      if (!buf.length) throw new HttpError(400, 'Fichier vide');
      if (buf.length > MAX_ITEM) throw new HttpError(413, `Fichier > ${MAX_ITEM / 1048576} Mo refusé`);
      if (project_id) await workspace.getProject(project_id);
      const id = uid('lib_');
      fs.writeFileSync(blob(id), buf);
      await db.run('INSERT INTO library_items(id,name,mime,size,sha1,tags,description,project_id,created) VALUES(?,?,?,?,?,?,?,?,?)', [id, name, MIME[extOf(name)] || 'application/octet-stream', buf.length, sha1(buf), j(tagsOf(tags)), String(description || '').slice(0, 500), project_id || null, now()]);
      await workspace.log(project_id || null, actor, 'library.add', `${name} (${buf.length} o)`);
      ctx.events?.emit('library', { id });
      return pub(await get(id));
    },
    async list({ project_id, q, tag, scope } = {}) {
      let rows = (await db.all('SELECT * FROM library_items ORDER BY created DESC')).filter((r) => (scope === 'global' ? !r.project_id : scope === 'project' ? r.project_id === project_id : visible(r, project_id)));
      if (q) { const s = String(q).toLowerCase(); rows = rows.filter((r) => r.name.toLowerCase().includes(s) || (r.description || '').toLowerCase().includes(s) || r.tags.includes(s)); }
      if (tag) rows = rows.filter((r) => pj(r.tags, []).includes(String(tag).toLowerCase()));
      return rows.map(pub);
    },
    async update(id, b) {
      const r = await get(id);
      const name = b.name === undefined ? r.name : cleanName(b.name);
      if (!name) throw new HttpError(400, 'Nom requis');
      await db.run('UPDATE library_items SET name=?,tags=?,description=? WHERE id=?', [name, b.tags === undefined ? r.tags : j(tagsOf(b.tags)), b.description === undefined ? r.description : String(b.description).slice(0, 500), id]);
      await workspace.log(r.project_id, 'user', 'library.update', name);
      return pub(await get(id));
    },
    async read(id, pid) {
      const r = await get(id);
      if (!visible(r, pid)) throw new HttpError(403, 'Élément réservé à un autre projet');
      return { row: r, buf: fs.readFileSync(blob(id)) };
    },
    /** Suppression : confirmation obligatoire, exemplaire conservé dans library/trash. */
    async remove(id, { confirm = false } = {}) {
      if (!confirm) throw new HttpError(409, 'Suppression : confirmation explicite requise', 'confirm_required');
      const r = await get(id);
      fs.renameSync(blob(id), path.join(dir, 'trash', `${id}-${r.name}`));
      await db.run('DELETE FROM library_items WHERE id=?', [id]);
      await workspace.log(r.project_id, 'user', 'library.delete', r.name);
      return { ok: true };
    },
    /** Copie un élément dans le workspace d'un projet (sauvegarde + journal + annulable). Jamais de lien entre projets. */
    async importToProject(id, pid, dest) {
      const { row, buf } = await api.read(id, pid);
      await workspace.getProject(pid);
      const rel = dest ? String(dest) : `assets/${row.name}`;
      return workspace.writeFile(pid, rel, buf.toString('base64'), { actor: 'user:library', encoding: 'base64' });
    },
    async saveFromProject(pid, rel, { tags, description, global = false } = {}) {
      await workspace.getProject(pid);
      const { abs } = workspace.safePath(pid, rel);
      if (!fs.existsSync(abs) || !fs.statSync(abs).isFile()) throw new HttpError(404, 'Fichier introuvable');
      return api.add({ name: path.basename(abs), buf: fs.readFileSync(abs), tags, description, project_id: global ? null : pid });
    },
    /** Outils agents (lecture seule, texte, limité au projet + éléments globaux). */
    async toolSearch(pid, query) { return (await api.list({ project_id: pid, q: query })).slice(0, 20).map((i) => ({ id: i.id, name: i.name, size: i.size, tags: i.tags, text: i.text })); },
    async toolRead(pid, id) {
      const { row, buf } = await api.read(id, pid);
      if (!TEXT_EXT.has(extOf(row.name))) return '(élément binaire : lecture texte impossible)';
      return buf.subarray(0, 300 * 1024).toString('utf8');
    },
  };
  return api;
}
