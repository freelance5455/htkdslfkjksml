import crypto from 'node:crypto';

/** Serveur WebSocket minimal (RFC 6455) sans dépendance : texte, ping/pong, fermeture, fragmentation. */
const GUID = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11';
const MAX_PAYLOAD = 1024 * 1024;

export function encodeFrame(op, payload) {
  const len = payload.length;
  let h;
  if (len < 126) h = Buffer.from([0x80 | op, len]);
  else if (len < 65536) { h = Buffer.alloc(4); h[0] = 0x80 | op; h[1] = 126; h.writeUInt16BE(len, 2); }
  else { h = Buffer.alloc(10); h[0] = 0x80 | op; h[1] = 127; h.writeBigUInt64BE(BigInt(len), 2); }
  return Buffer.concat([h, payload]);
}

/** Décode les trames complètes présentes dans buf. Retourne { frames, rest }. */
export function decodeFrames(buf) {
  const frames = [];
  for (;;) {
    if (buf.length < 2) break;
    const fin = (buf[0] & 0x80) !== 0, op = buf[0] & 0x0f, masked = (buf[1] & 0x80) !== 0;
    let len = buf[1] & 0x7f, off = 2;
    if (len === 126) { if (buf.length < 4) break; len = buf.readUInt16BE(2); off = 4; }
    else if (len === 127) { if (buf.length < 10) break; len = Number(buf.readBigUInt64BE(2)); off = 10; }
    if (len > MAX_PAYLOAD) throw new Error('payload trop grand');
    const need = off + (masked ? 4 : 0) + len;
    if (buf.length < need) break;
    let payload = buf.subarray(off + (masked ? 4 : 0), need);
    if (masked) {
      const mask = buf.subarray(off, off + 4);
      payload = Buffer.from(payload.map((b, i) => b ^ mask[i % 4]));
    }
    frames.push({ fin, op, payload });
    buf = buf.subarray(need);
  }
  return { frames, rest: buf };
}

export function attachWs(server, { auth }) {
  const clients = new Set();
  server.on('upgrade', (req, socket) => {
    const url = new URL(req.url, 'http://localhost');
    const key = req.headers['sec-websocket-key'];
    if (url.pathname !== '/ws' || !key || !auth(req, url)) {
      socket.write('HTTP/1.1 401 Unauthorized\r\nConnection: close\r\n\r\n');
      return socket.destroy();
    }
    const origin = req.headers.origin;
    if (origin) { try { if (new URL(origin).host !== req.headers.host) { socket.write('HTTP/1.1 403 Forbidden\r\n\r\n'); return socket.destroy(); } } catch { return socket.destroy(); } }
    const accept = crypto.createHash('sha1').update(key + GUID).digest('base64');
    socket.write(['HTTP/1.1 101 Switching Protocols', 'Upgrade: websocket', 'Connection: Upgrade', `Sec-WebSocket-Accept: ${accept}`, '', ''].join('\r\n'));
    const c = { socket, alive: true };
    clients.add(c);
    let buf = Buffer.alloc(0), frag = [];
    const drop = () => { clients.delete(c); socket.destroy(); };
    socket.on('data', (d) => {
      try {
        const r = decodeFrames(Buffer.concat([buf, d]));
        buf = r.rest;
        for (const f of r.frames) {
          if (f.op === 8) { socket.write(encodeFrame(8, Buffer.alloc(0))); return drop(); }
          if (f.op === 9) socket.write(encodeFrame(10, f.payload));
          else if (f.op === 10) c.alive = true;
          else if (f.op === 1 || f.op === 0) { frag.push(f.payload); if (f.fin) { frag = []; } }
        }
      } catch { drop(); }
    });
    socket.on('close', () => clients.delete(c));
    socket.on('error', () => clients.delete(c));
    socket.write(encodeFrame(1, Buffer.from(JSON.stringify({ type: 'hello' }))));
  });
  const timer = setInterval(() => {
    for (const c of clients) {
      if (!c.alive) { c.socket.destroy(); clients.delete(c); continue; }
      c.alive = false;
      try { c.socket.write(encodeFrame(9, Buffer.alloc(0))); } catch { clients.delete(c); }
    }
  }, 25000);
  timer.unref();
  return {
    broadcast(obj) {
      const f = encodeFrame(1, Buffer.from(JSON.stringify(obj)));
      for (const c of clients) { try { c.socket.write(f); } catch { clients.delete(c); } }
    },
    count: () => clients.size,
    close() { clearInterval(timer); for (const c of clients) c.socket.destroy(); clients.clear(); },
  };
}
