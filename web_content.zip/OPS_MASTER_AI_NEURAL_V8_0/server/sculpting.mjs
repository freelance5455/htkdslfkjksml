import { validateAsset } from './modelgen.mjs';

const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const unit = (x, y, z) => { const n = Math.hypot(x, y, z) || 1; return [x / n, y / n, z / n]; };

/** Applies deterministic, bounded vertex-brush operations to every LOD. */
export function sculptAsset(asset, rawOperations = []) {
  if (!Array.isArray(rawOperations) || rawOperations.length < 1 || rawOperations.length > 32) throw Object.assign(new Error('1 à 32 opérations de sculpture sont requises'), { status: 400 });
  const operations = rawOperations.map((o, i) => {
    const mode = o?.mode || 'inflate';
    if (!['inflate', 'smooth', 'flatten'].includes(mode)) throw Object.assign(new Error(`mode invalide à l’opération ${i + 1}`), { status: 400 });
    const center = Array.isArray(o.center) ? o.center.map(Number) : [0, asset.height / 2, 0];
    const radius = Number(o.radius ?? 1.5), strength = Number(o.strength ?? 0.08);
    if (center.length !== 3 || !center.every(Number.isFinite) || !Number.isFinite(radius) || radius < 0.1 || radius > 30 || !Number.isFinite(strength) || Math.abs(strength) > 0.25) throw Object.assign(new Error(`paramètres hors limites à l’opération ${i + 1}`), { status: 400 });
    return { mode, center, radius, strength };
  });
  for (const lod of asset.lods) for (const mesh of lod.prims) {
    const count = mesh.pos.length / 3, baseVertices = Array.from({length: mesh.pos.length / 3}, (_, v) => mesh.pos[v*3+1] <= 0.001), neighbors = Array.from({ length: count }, () => new Set());
    for (let t = 0; t < mesh.idx.length; t += 3) { const [a,b,c] = mesh.idx.slice(t,t+3); neighbors[a].add(b); neighbors[a].add(c); neighbors[b].add(a); neighbors[b].add(c); neighbors[c].add(a); neighbors[c].add(b); }
    for (const op of operations) {
      const before = mesh.pos.slice();
      for (let v = 0; v < count; v++) {
        const k = v * 3, dx = before[k] - op.center[0], dy = before[k+1] - op.center[1], dz = before[k+2] - op.center[2], d = Math.hypot(dx,dy,dz);
        if (d >= op.radius) continue;
        const falloff = (1 - d / op.radius) ** 2;
        if (op.mode === 'inflate') { const n = unit(dx,dy,dz); mesh.pos[k] += n[0] * op.strength * falloff; mesh.pos[k+1] += n[1] * op.strength * falloff; mesh.pos[k+2] += n[2] * op.strength * falloff; }
        else if (op.mode === 'flatten') { mesh.pos[k+1] -= (before[k+1] - op.center[1]) * clamp(Math.abs(op.strength) * 4 * falloff, 0, 0.8); }
        else { const ns = [...neighbors[v]]; if (ns.length) { const avg = [0,0,0]; for (const n of ns) for (let q=0;q<3;q++) avg[q] += before[n*3+q] / ns.length; const f = clamp(Math.abs(op.strength) * 4 * falloff, 0, 0.65); for (let q=0;q<3;q++) mesh.pos[k+q] = before[k+q] * (1-f) + avg[q] * f; } }
      }
    }
    for (let v=0; v<count; v++) if (baseVertices[v]) mesh.pos[v*3+1] = 0;
    const normals = new Float64Array(mesh.pos.length);
    for (let t=0;t<mesh.idx.length;t+=3) { const a=mesh.idx[t],b=mesh.idx[t+1],c=mesh.idx[t+2], ax=mesh.pos[b*3]-mesh.pos[a*3], ay=mesh.pos[b*3+1]-mesh.pos[a*3+1], az=mesh.pos[b*3+2]-mesh.pos[a*3+2], bx=mesh.pos[c*3]-mesh.pos[a*3], by=mesh.pos[c*3+1]-mesh.pos[a*3+1], bz=mesh.pos[c*3+2]-mesh.pos[a*3+2], n=[ay*bz-az*by,az*bx-ax*bz,ax*by-ay*bx]; for (const v of [a,b,c]) for(let q=0;q<3;q++) normals[v*3+q]+=n[q]; }
    mesh.nrm = Array.from({length:count},(_,v)=>unit(normals[v*3],normals[v*3+1],normals[v*3+2])).flat();
  }
  const min=[Infinity,Infinity,Infinity],max=[-Infinity,-Infinity,-Infinity];
  for(const p of asset.lods[0].prims) for(let i=0;i<p.pos.length;i+=3) for(let q=0;q<3;q++){min[q]=Math.min(min[q],p.pos[i+q]);max[q]=Math.max(max[q],p.pos[i+q]);}
  asset.bounds={min,max}; asset.validation=validateAsset(asset);
  return { asset, operations, validation: asset.validation };
}
