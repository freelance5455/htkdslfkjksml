import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

export const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
export const VERSION = '8.0.0';

function loadEnv(file) {
  if (!fs.existsSync(file)) return;
  for (const line of fs.readFileSync(file, 'utf8').split(/\r?\n/)) {
    const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*?)\s*$/);
    if (!m || m[1] in process.env) continue;
    let v = m[2];
    if (/^(".*"|'.*')$/.test(v)) v = v.slice(1, -1);
    process.env[m[1]] = v;
  }
}

function secretFile(dir, name, env, bytes) {
  if (env) return env;
  const f = path.join(dir, name);
  if (fs.existsSync(f)) return fs.readFileSync(f, 'utf8').trim();
  const v = crypto.randomBytes(bytes).toString('hex');
  fs.writeFileSync(f, v, { mode: 0o600 });
  return v;
}

/** Construit la configuration (appelée au démarrage, permet aux tests de surcharger l'environnement). */
export function loadConfig(over = {}) {
  loadEnv(path.join(ROOT, '.env'));
  const e = { ...process.env, ...over.env };
  const dataDir = path.resolve(over.dataDir || e.OPS_DATA_DIR || path.join(ROOT, 'data'));
  fs.mkdirSync(dataDir, { recursive: true });
  const firstToken = !e.OPS_TOKEN && !fs.existsSync(path.join(dataDir, '.token'));
  const port = Number(over.port ?? e.PORT ?? 8800);
  if (!Number.isInteger(port) || port < 0 || port > 65535) throw new Error('PORT doit être un entier compris entre 0 et 65535');
  const maxBodyBytes = Number(e.OPS_MAX_BODY_BYTES || 12 * 1024 * 1024);
  if (!Number.isSafeInteger(maxBodyBytes) || maxBodyBytes < 1024 || maxBodyBytes > 64 * 1024 * 1024) throw new Error('OPS_MAX_BODY_BYTES doit être compris entre 1024 et 67108864');
  return {
    version: VERSION,
    port,
    host: over.host || e.OPS_HOST || '127.1.0.1',
    dataDir,
    publicDir: path.join(ROOT, 'public'),
    seedDir: path.join(ROOT, 'seed'),
    token: over.token || secretFile(dataDir, '.token', e.OPS_TOKEN, 24),
    firstToken,
    secret: secretFile(dataDir, '.secret', e.OPS_SECRET, 32),
    databaseUrl: e.OPS_DATABASE_URL || '',
    corsOrigin: e.OPS_CORS_ORIGIN || '',
    maxBodyBytes,
    automation: over.automation ?? (e.OPS_AUTOMATION !== '0'),
    localFallback: over.localFallback ?? (e.OPS_LOCAL_FALLBACK === '1'),
    stallMs: Number(e.OPS_STALL_MS || 6 * 60 * 1000),
    seedProjects: over.seedProjects ?? (e.OPS_SEED !== '0'),
  };
}
