/** Language-aware validation guidance for OPS CODER. This module plans checks;
 * it never executes project code or shell commands. */
const EXTENSIONS = {
  '.js':'javascript','.mjs':'javascript','.cjs':'javascript','.jsx':'javascript',
  '.ts':'typescript','.tsx':'typescript','.py':'python','.json':'json',
  '.html':'html','.htm':'html','.css':'css','.scss':'scss',
  '.glsl':'glsl','.vert':'glsl','.frag':'glsl','.wgsl':'wgsl',
  '.xml':'xml','.yaml':'yaml','.yml':'yaml','.md':'markdown',
  '.java':'java','.kt':'kotlin','.cs':'csharp','.cpp':'cpp','.h':'cpp','.hpp':'cpp',
  '.rs':'rust','.go':'go','.php':'php','.sql':'sql'
};
const CHECKS = {
  javascript: ['Syntaxe : node --check <fichier>', 'Tests : npm test ou la commande test déclarée dans package.json', 'Intégration : vérifier les imports/exports et les chemins relatifs'],
  typescript: ['Types et compilation : npx tsc --noEmit (si TypeScript est installé)', 'Tests : exécuter le runner déclaré par le projet', 'Intégration : vérifier tsconfig, alias et résolution des modules'],
  python: ['Syntaxe : python -m py_compile <fichier>', 'Qualité : exécuter le linter configuré (ruff/flake8) si présent', 'Tests : python -m pytest (si pytest est installé)'],
  json: ['Valider avec un parseur JSON strict', 'Vérifier le schéma attendu et les clés obligatoires', 'Contrôler les virgules finales, commentaires et types de valeurs'],
  html: ['Valider la structure HTML et les identifiants utilisés', 'Vérifier chaque script src, stylesheet href et ressource locale', 'Tester les états mobile, clavier, chargement et erreur'],
  css: ['Vérifier la syntaxe et les sélecteurs réellement utilisés', 'Contrôler les media queries, débordements et styles inutilisés', 'Tester clavier, tactile et tailles d’écran'],
  scss: ['Compiler avec le compilateur SCSS déjà configuré', 'Vérifier les imports et variables partagées', 'Contrôler le CSS généré et les media queries'],
  glsl: ['Compiler avec le compilateur GLSL du pipeline si disponible', 'Vérifier les attributs, uniforms, varyings et versions shader', 'Tester sur le contexte graphique cible et contrôler les erreurs GPU'],
  wgsl: ['Valider avec le compilateur WGSL du moteur utilisé', 'Vérifier les bindings, layouts et types', 'Tester sur l’adaptateur GPU réellement ciblé'],
  java: ['Compiler avec le JDK et le système de build du projet', 'Exécuter les tests configurés', 'Vérifier les versions Android/JVM et dépendances'],
  kotlin: ['Compiler avec Gradle et le plugin Kotlin du projet', 'Exécuter les tests configurés', 'Vérifier les versions Android/JVM et dépendances'],
  csharp: ['Compiler avec dotnet build ou le build system existant', 'Exécuter dotnet test si configuré', 'Vérifier le framework cible et les références'],
  cpp: ['Compiler avec le toolchain et les options CMake/Make existants', 'Exécuter les tests configurés', 'Vérifier ownership mémoire, ABI et plateformes'],
  rust: ['Vérifier avec cargo check', 'Exécuter cargo test', 'Lancer cargo clippy si configuré'],
  go: ['Vérifier avec go test ./...', 'Lancer go vet ./...', 'Contrôler les interfaces et la compatibilité du module'],
  php: ['Vérifier avec php -l <fichier>', 'Exécuter les tests configurés (ex. PHPUnit)', 'Contrôler types, entrées et erreurs'],
  sql: ['Valider la syntaxe sur le moteur SQL cible', 'Vérifier migrations, index, contraintes et rollback', 'Tester sur une base de test, jamais sur les données de production'],
  xml: ['Valider le document avec un parseur XML', 'Vérifier namespaces et schéma attendu', 'Contrôler les chemins de ressources référencées'],
  yaml: ['Valider avec le parseur YAML du projet', 'Vérifier indentation, types et clés attendues', 'Ne jamais charger de tags ou extensions non fiables'],
  go: ['Vérifier avec go test ./...', 'Lancer go vet ./...', 'Contrôler les interfaces et la compatibilité du module']
};

export function detectCoderLanguage(path = '') {
  const name = String(path).toLowerCase();
  const dot = name.lastIndexOf('.');
  return dot >= 0 ? (EXTENSIONS[name.slice(dot)] || 'unknown') : 'unknown';
}

export function buildCoderValidationPlan(paths = []) {
  const files = [...new Set((Array.isArray(paths) ? paths : []).map((p) => String(p || '').trim()).filter(Boolean))];
  const groups = {};
  for (const path of files) {
    const language = detectCoderLanguage(path);
    (groups[language] ||= []).push(path);
  }
  return Object.entries(groups).map(([language, groupedPaths]) => ({
    language, files: groupedPaths,
    checks: CHECKS[language] || ['Identifier le compilateur/linter officiel du projet avant toute validation', 'Vérifier les références et l’intégration dans le point d’entrée', 'Exécuter les tests du projet si un environnement adapté existe']
  }));
}

export function validateCoderJson(path, content) {
  if (detectCoderLanguage(path) !== 'json') return { applicable: false, valid: null, errors: [] };
  try { JSON.parse(String(content)); return { applicable: true, valid: true, errors: [] }; }
  catch (error) { return { applicable: true, valid: false, errors: [String(error.message || error)] }; }
}

export function buildCoderDiagnosticContext(paths = []) {
  const plan = buildCoderValidationPlan(paths);
  if (!plan.length) return 'Aucun fichier livré : demande les chemins concernés avant de prétendre avoir validé le code.';
  return plan.map((item) => `LANGAGE ${item.language.toUpperCase()} — ${item.files.join(', ')}\n${item.checks.map((check, i) => `${i + 1}. ${check}`).join('\n')}`).join('\n\n');
}
