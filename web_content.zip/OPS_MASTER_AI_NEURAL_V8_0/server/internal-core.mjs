/**
 * OPS INTERNAL COGNITIVE CORE V1.0
 * Moteur local déterministe : routage de compétences, calcul, planification,
 * contrôles de cohérence et réponses structurées. Aucun appel réseau, aucune API
 * de modèle tiers. Ce noyau n'est pas présenté comme un grand modèle génératif.
 */
import { extractMathExpression } from './neural.mjs';

export const INTERNAL_AGENTS = Object.freeze([
  ['coordinator','Coordination et arbitrage'],['architect','Architecture logicielle'],
  ['frontend','Interfaces et accessibilité'],['backend','Serveurs et API'],
  ['engine3d','Moteurs 3D et rendu'],['debug','Diagnostic et correction'],
  ['gameplay','Gameplay et simulation'],['art3d','Ressources et environnements 3D'],
  ['animation','Squelettes et animations'],['audio','Audio et voix'],
  ['quality','Assurance qualité et non-régression'],['director','Direction de production'],
  ['world','Génération de mondes'],['modeling','Modélisation 3D'],
]);

const clean = (s='') => String(s).replace(/\u0000/g,'').trim();
const lastUser = (messages=[]) => [...messages].reverse().find(m=>m.role==='user')?.content || '';
const systemText = (messages=[]) => messages.filter(m=>m.role==='system').map(m=>m.content).join('\n');
const wantsJSON = (s) => /uniquement.*json|objet json|json valide|réponds.*json/i.test(s);
const safeJSON = (value) => JSON.stringify(value, null, 2);

function classify(text) {
  const t=text.toLowerCase();
  const rules=[
    ['debug',/bug|erreur|exception|crash|corrig|débog|régression/],
    ['frontend',/interface|html|css|bouton|écran|responsive|navigation/],
    ['backend',/serveur|api|base de données|authentification|endpoint/],
    ['engine3d',/3d|webgl|webgpu|rendu|physique|moteur|maillage/],
    ['gameplay',/mission|joueur|npc|personnage|combat|véhicule|simulation/],
    ['animation',/animation|rig|squelette|mouvement|ik/],
    ['art3d',/texture|matériau|bâtiment|ville|asset|ressource/],
    ['audio',/audio|son|voix|micro|synthèse/],
    ['quality',/test|qualité|validation|sécurité|performance/],
    ['architect',/architecture|structure|module|dépendance/],
  ];
  return rules.filter(([,re])=>re.test(t)).map(([id])=>id);
}

function buildPlan(prompt) {
  const skills=classify(prompt);
  const ids=['architect',...(skills.length?skills:['backend','frontend']), 'quality'];
  const unique=[...new Set(ids)].slice(0,8);
  const names=Object.fromEntries(INTERNAL_AGENTS.map(([id,name])=>[id,name]));
  return {tasks:unique.map((assignee,i)=>({key:`local_${i+1}`,assignee,title:i===0?'Cadrage et analyse':i===unique.length-1?'Contrôle qualité et non-régression':`Analyse spécialisée : ${names[assignee]}`,description:`Analyser la demande « ${prompt.slice(0,220)} » sous l'angle ${names[assignee]}. Produire des constats vérifiables, les limites et les critères de validation. Ne pas prétendre modifier un fichier sans outil d'écriture.`,depends_on:i? [`local_${i}`]:[],estimate_h:1}))};
}

function structuredResponse(prompt, agentId) {
  if (/"tasks"|PLAN DE PRODUCTION JSON/i.test(prompt)) return buildPlan(prompt);
  if (/PARAMÈTRES JSON pour ce brief de modélisation/i.test(prompt)) {
    const text=prompt.slice(0,4000); const kind=/kit|ensemble|quartier/i.test(text)?'kit':'asset';
    return {scope:kind,world_id:null,max_archetypes:12,asset:{kind:'building',style:'à préciser',floors:2,width:12,depth:10,name:'Asset OPS à définir'},_internal_status:'planification déterministe, à valider avant génération'};
  }
  if (/PARAMÈTRES JSON pour ce brief de monde/i.test(prompt)) {
    return {name:'Monde OPS',seed:20261117,size:'medium',theme:'à préciser',water:'natural',density:'medium',districts:4,landmarks:[],target:'blueprint'};
  }
  return {status:'analysis_only',agent:agentId||'ops_internal',summary:'Le noyau interne a classé la demande et préparé une réponse locale.',detected_skills:classify(prompt),limitations:['Aucun modèle génératif externe ou local tiers n’est appelé.','La génération libre de code, de scènes 3D ou de longs textes n’est pas encore prise en charge par ce noyau.'],next_step:'Utiliser les moteurs OPS spécialisés et leurs validateurs pour produire un livrable concret.'};
}

function answerFor(agentId, prompt, system) {
  const math=extractMathExpression(prompt);
  if (math) return `OPS NEURAL MATH — calcul vérifié\n\n${math.expression} = ${math.exact}\nFraction : ${math.fraction}\n\nRésultat calculé localement, sans modèle externe.`;
  if (wantsJSON(prompt+'\n'+system)) return safeJSON(structuredResponse(prompt,agentId));
  const skills=classify(prompt);
  const role=INTERNAL_AGENTS.find(([id])=>id===agentId)?.[1]||'Assistant OPS interne';
  return [
    `# ${role} — OPS INTERNAL CORE`,
    '',
    '**Analyse locale :**',
    `- Demande reçue : ${prompt.slice(0,900)}`,
    `- Compétences concernées : ${skills.length?skills.join(', '):'coordination générale'}`,
    '- Mode : traitement déterministe interne, sans appel à un modèle tiers.',
    '',
    '**Décision :**',
    'La demande est classée et peut être transmise aux agents OPS spécialisés. Avant toute modification, le projet source doit être inspecté, les fichiers concernés identifiés et les fonctionnalités existantes préservées.',
    '',
    '**Limite honnête :**',
    'Ce noyau sait router, calculer, structurer des plans et appliquer des règles. Il ne possède pas encore les capacités génératives générales d’un grand modèle de langage ; il ne doit donc pas prétendre avoir écrit, exécuté ou réparé du code sans moteur spécialisé et preuve de validation.'
  ].join('\n');
}

export function createInternalCore() {
  return {
    id:'ops-internal-core-v1', mode:'local-only', externalModels:false,
    agents:INTERNAL_AGENTS.map(([id,name])=>({id,name,status:'available',mode:'rule-engine'})),
    async chat(agent,messages) {
      const prompt=clean(lastUser(messages));
      if (!prompt) return {text:'Décris la tâche à traiter.',usage:{prompt:0,completion:0},provider:'OPS INTERNAL CORE',model:'OPS-CORE-V1'};
      const system=systemText(messages);
      const text=answerFor(agent?.id,prompt,system);
      return {text,usage:{prompt:0,completion:0},provider:'OPS INTERNAL CORE',model:'OPS-CORE-V1'};
    },
    health(){return {ok:true,mode:'local-only',external_network_calls:0,agents:INTERNAL_AGENTS.length,capabilities:['classification','planning','math','structured-output','quality-rules']};}
  };
}
