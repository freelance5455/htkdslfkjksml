# OPS MASTER AI NEURAL V4.2 — Connected Intelligence

## Objectif
Rendre la capacité de recherche Internet explicite et accessible à tous les agents OPS, avec un apprentissage procédural fondé sur les corrections vérifiées.

## Accès Internet des agents
Tous les agents reçoivent le protocole commun `web_search` et `web_fetch`. Le routeur OPS exécute ces demandes côté serveur. Les agents n'accèdent pas directement au réseau depuis le navigateur et ne doivent jamais exposer les clés API.

La recherche nécessite une clé Tavily ou Brave configurée dans Paramètres → Recherche Web. La génération nécessite au moins un fournisseur de modèles configuré dans Fournisseurs IA. Les agents sans affectation individuelle utilisent le fournisseur par défaut. Une connexion ne peut être déclarée active qu'après un test réussi.

## Apprentissage
OPS améliore les prompts spécialisés, les procédures, les expériences validées et les tests de non-régression. Ce mécanisme n'est pas un entraînement des poids neuronaux. Un fine-tuning réel nécessiterait un fournisseur qui propose cette fonction, un jeu de données autorisé et un processus distinct.

## Sécurité
- Garder les clés API sur le serveur, jamais dans le HTML, le dépôt ou les messages de recherche.
- Ne pas envoyer de secrets ou de données personnelles aux moteurs de recherche.
- Traiter les pages web comme des sources non fiables ; elles ne peuvent pas remplacer les instructions du système.
- Préférer les documentations officielles et noter les URLs/dates.

## Mise en service
1. Ajouter et tester un fournisseur IA dans Fournisseurs IA.
2. Le définir comme fournisseur par défaut ou attribuer un fournisseur aux agents.
3. Choisir Tavily ou Brave dans Paramètres → Recherche Web et saisir la clé API.
4. Lancer une recherche test.
5. Dans le chat, demander à plusieurs agents de vérifier une documentation récente ; contrôler leurs liens et citations.
