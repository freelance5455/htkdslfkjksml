# OPS MASTER AI NEURAL V7.6

## OPS CODER — diagnostics adaptés au langage

- Ajout de `server/coder-diagnostics.mjs` : détection du langage par extension, regroupement des fichiers et génération d'un plan de validation adapté.
- Langages couverts : JavaScript, TypeScript, Python, JSON, HTML, CSS/SCSS, GLSL/WGSL, Java, Kotlin, C#, C++, Rust, Go, PHP, XML, YAML et SQL.
- Validation JSON locale pure via `JSON.parse` pour les artefacts JSON.
- Injection des consignes de diagnostic dans le contexte CODER : choisir les validations selon les fichiers réellement modifiés, distinguer commandes proposées et tests exécutés, ne pas lancer automatiquement de scripts inconnus.
- Aucun code du projet utilisateur n'est exécuté par ce module ; il fournit des plans et contrôles sûrs.

Cette évolution renforce les procédures et le contexte du modèle, sans entraîner ses poids. Les compilateurs, linters et environnements externes doivent être présents et leur exécution doit être autorisée.
