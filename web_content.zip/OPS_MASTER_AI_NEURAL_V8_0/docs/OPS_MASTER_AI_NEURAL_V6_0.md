# OPS MASTER AI NEURAL V6.0

## Manifeste de livraison vérifiable

La V6.0 conserve la chaîne multi-agents, les moteurs, la supervision, la reprise d'orchestration et le Release Gate de la V5.3. Elle ajoute un manifeste d'intégrité calculé depuis le workspace réel.

### Capacités
- Inventaire des fichiers avec tailles et empreintes SHA-256 individuelles.
- Empreinte racine SHA-256 stable pour un même contenu et un même ensemble de chemins.
- Détection de fichiers sensibles et de motifs de clés privées / secrets API.
- Repérage des points d'entrée, README et lockfiles.
- Snapshot versionné uniquement si aucun blocage de sécurité n'est signalé.
- Routes authentifiées : `GET /api/projects/:id/release-manifest` et `POST /api/projects/:id/release-manifest/snapshot`.

### Sécurité et limites
- Aucun script du projet n'est exécuté.
- Limites : 5 000 fichiers et 200 Mo par manifeste.
- Un secret détecté bloque le snapshot ; une documentation manquante demande une revue.
- Le manifeste prouve l'intégrité des fichiers au moment du calcul, pas leur qualité fonctionnelle ni l'absence absolue de secrets.
