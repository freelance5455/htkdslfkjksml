# Android (V6)
**État : application native non livrée.** Livré : interface responsive + PWA (manifest, service worker) → « Installer l'application » dans Chrome Android ; l'API REST/WebSocket est la base de l'app native future.
Options : (1) serveur sur PC/hébergement + PWA sur le téléphone ; (2) serveur dans Termux sur le téléphone ; (3) future app native (Capacitor/Kotlin) qui appellera la même API (`OPS_CORS_ORIGIN` pour l'autoriser). La synchronisation multi-appareils est déjà possible : tous les appareils partagent le même serveur et reçoivent les événements en temps réel.
Contrainte : un téléphone à 2 Go de RAM convient pour l'interface ; préférez héberger le serveur ailleurs.
