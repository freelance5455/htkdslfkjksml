# OPS WORLD AI — Étape 3 du studio (monde, villes, environnements)

## Ce qu'elle fait réellement
Génération **procédurale déterministe** (`server/worldgen.mjs`, aucune dépendance) : même paramètres + même graine = même monde, octet pour octet.
Le monde est une grille de n×n cellules de 24 m (petite 24 → 576 m, moyenne 40 → 960 m, grande 64 → 1 536 m) :
- **Terrain** : bruit fractal, plateau aplati sous la ville, côte (mer) ou rivière sinueuse creusée ; eau douce/salée détectée sous le niveau 0.
- **Routes** : grille de rues (artères toutes les 8 cellules), coupe des traversées de mer ou de plus de 5 cellules d'eau, **ponts** sur l'eau douce, réseau réduit à sa plus grande composante connexe.
- **Quartiers** (Voronoi, 3–8) : centre-ville, commercial, résidentiel, banlieue, industriel, port (côte) ; parcs ; bâtiments (étages, emprise, style selon thème et quartier) ; 0–7 **monuments** (tour, mairie, stade, cathédrale, musée, marché, gare) toujours conservés.
- **Budgets** : cible `mobile` (≤ 350 bâtiments, 60 000 triangles) ou `pc` (≤ 1 500, 400 000). Excédent retiré du bord vers le centre ; l'écart est reporté dans les stats.
- **Validation indépendante** (`validateWorld`, lit uniquement le monde produit) : bâtiments dans la carte, sur terrain constructible, sans chevauchement, adjacents à une route, ponts sur l'eau, réseau connexe, budgets. Un monde invalide est enregistré mais **ses fichiers ne sont pas livrés**.
- **Exports** : `world.json` (format `ops-world` v1, source de vérité), `world.obj` (terrain, eau, routes, volumes de bâtiments — indices de faces vérifiés), `preview.svg` (vue du dessus, noms échappés), plus un `README.md`.

## Rôle de l'IA (modèle de langage)
Le LLM n'invente pas la carte : il **choisit les paramètres** à partir d'un brief (utilisateur, tâche du plan, résultats précédents, décisions, messages reçus). Sa réponse JSON est filtrée (clés autorisées) puis validée ; sinon erreur 502 « WORLD AI n'a pas renvoyé de paramètres exploitables » et **rien n'est créé**. Sans fournisseur configuré : même erreur honnête.
La génération manuelle (formulaire / `POST /api/world/generate`) fonctionne **sans aucun fournisseur**.

## Livraison dans le projet
Fichiers sous `world/<nom>-<id6>/`. Mode projet « approbation » (défaut) : 4 demandes d'approbation (aucune écriture avant validation). Mode « auto » : sauvegarde de version puis écriture directe, journalisée. Le nom est « slugifié » (pas d'échappement de chemin possible).

## Intégration avec OPS DIRECTOR AI
- WORLD passe à « construite » ; les messages qui l'attendaient en file d'attente lui sont remis.
- Les tâches du plan attribuées à `world` sont **exécutables** (bouton « Exécuter » dans Director › Plans) : brief → paramètres → génération → résultat markdown → tâche terminée → **handoff** automatique vers les IA suivantes (en file d'attente tant qu'elles ne sont pas construites).
- Les messages reçus sont marqués lus à l'exécution ; en cas d'échec la tâche revient « à faire ».
- Chat direct : écran WORLD AI › Discuter (balise `<ops-generate …/>`, max 2 par message ; le résultat réel est rapporté, échecs compris).

## API
`POST /api/world/generate` `{project_id, params}` · `POST /api/world/from-brief` `{project_id, brief}` · `GET /api/world/worlds[?project_id]` · `GET /api/world/worlds/:id` · `GET /api/world/worlds/:id/download?kind=json|obj|svg` · `POST /api/studio/world/chat`.

## Limites connues (honnêtes)
- Bâtiments = **volumes simples** (boîtes) : la modélisation détaillée relève d’OPS MODELING AI. Les matériaux, collisions et comportements PNJ sont transmis aux spécialistes GRAPHICS, PHYSICS et NPC ; les routes courbes/intersections détaillées restent des axes d’amélioration du générateur.
- Aucun import dans un moteur réel (Unity/Unreal/Godot…) n'a été testé : seuls JSON/OBJ/SVG sont produits et vérifiés par les tests.
- Le choix des paramètres par LLM a été testé uniquement avec la fixture locale, pas avec un vrai modèle.
- Le monde est plat par cellule (altitude moyenne) : pas de terrassement fin sous les bâtiments en forte pente (pente max 3,5 m par cellule).
