# OPS AUTONOMOUS AI EXECUTION ENGINE — V3.26

La V3.26 prolonge le planificateur V3.25. Le planificateur ne se contente plus de créer des transmissions dans la boîte de collaboration : chaque tâche est remise au runtime réel d'un agent OPS et attend un résultat enregistré.

## Cycle d'exécution

1. Création d'un plan de 1 à 40 tâches, avec identifiants uniques, agents activés et graphe de dépendances sans cycle.
2. Démarrage explicite du plan. Les tâches sans prérequis deviennent éligibles.
3. Exécution via `ctx.orchestrator.start({ mode: 'agent' })` pour les agents développeurs ordinaires. Le runtime existant conserve ses fournisseurs, prompts, outils, propositions de fichiers, sauvegardes, contrôles CODER et mécanismes d'approbation.
4. Les agents du Studio sont routés vers `ctx.director.executeStandaloneTask`. WORLD et MODELING conservent leurs vrais handlers spécialisés et leurs générateurs procéduraux ; les autres IA du Studio utilisent le runtime du Director.
5. Le résultat est enregistré. Les tâches qui proposent des fichiers passent en `review` jusqu'à la décision humaine. Les propositions approuvées sont vérifiées dans le workspace avant de libérer les tâches dépendantes.
6. Les dépendances en échec sont bloquées ; elles peuvent redevenir éligibles après réparation et validation de leur prérequis. Les erreurs peuvent être relancées manuellement, avec un nombre de tentatives borné.

## États

- Plan : `draft`, `running`, `paused`, `waiting_approval`, `attention`, `done`.
- Tâche : `waiting_dependencies`, `ready`, `starting`, `executing`, `review`, `done`, `error`, `blocked`.
- La pause empêche de démarrer de nouvelles tâches. Les exécutions déjà lancées peuvent terminer.
- Les journaux, IDs de run, résultats, erreurs, tentatives et approbations sont persistés.

## API

- `POST /api/projects/:id/orchestration` — crée un plan (sans le démarrer).
- `GET /api/projects/:id/orchestration` — liste les plans.
- `GET /api/orchestration/:id` — rapport, tâches, résultats et journal.
- `POST /api/orchestration/:id/start` — démarre le plan.
- `POST /api/orchestration/:id/pause` — met en pause les nouveaux départs.
- `POST /api/orchestration/:id/resume` — reprend le plan et synchronise les approbations.
- `POST /api/orchestration/:id/tasks/:taskId/retry` — relance une tâche en erreur/bloquée.
- `POST /api/orchestration/:id/advance` — alias de compatibilité pour démarrer/reprendre.

## Sécurité et limites

- Le moteur n'exécute pas de scripts du projet, de commandes shell, de builds ni de tests du projet. `project.allow_exec` reste donc respecté : aucune exécution de ce type n'est déclenchée par V3.26.
- Les modes `approval` et `auto` restent appliqués par le runtime existant. En mode `approval`, les tâches qui produisent des fichiers attendent l'approbation. En mode `auto`, les écritures autorisées passent par les sauvegardes du workspace.
- Une réponse textuelle ne prouve pas qu'un fichier a été intégré. Les tâches CODER qui exigent du code restent soumises aux règles de livraison de fichiers du runtime OPS.
- Une IA du Studio n'est exécutable que si son état est construit/validé et que ses dépendances techniques (fournisseur, données de génération, monde source pour un kit) sont disponibles.
- La V3.26 ne garantit pas que tous les fournisseurs répondront : une absence de clé, de modèle ou de service produit une erreur explicite, jamais une réussite simulée.
- La progression automatique s'effectue pendant que le serveur OPS fonctionne. Après un redémarrage, une exécution interrompue doit être réconciliée puis relancée depuis l'interface ; aucun daemon distribué permanent n'est revendiqué.
- PostgreSQL reste soumis aux limites de test déjà documentées dans le projet.

## Vérifications

Les tests V3.26 utilisent le fournisseur stub de test pour vérifier : appel réel du runtime agent, conservation des IDs d'exécution et résultats, attente d'approbation, propagation du résultat validé, pause/reprise, refus d'une tâche sans fournisseur, et routage des tâches WORLD/MODELING vers leurs handlers spécialisés. Le stub n'est pas un fournisseur livré au produit.
