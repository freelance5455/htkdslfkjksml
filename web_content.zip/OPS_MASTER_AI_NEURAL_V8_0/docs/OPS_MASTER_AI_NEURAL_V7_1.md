# OPS MASTER AI NEURAL V7.1

## Éclairage studio procédural et matériaux

- Ajout de trois ambiances de studio (neutre, froide, chaude) dans le viewport WebGL 2.
- Réglage en temps réel de l’éclairage ambiant et de la lumière principale.
- Réglages non destructifs de rugosité et de réponse métallique, appliqués au rendu sans réécrire les textures sources.
- Éclairage hémisphérique stylisé, reflet spéculaire simplifié et rim light.
- Les maps BaseColor, Normal et ORM restent prises en charge.

Limites : ce système est un éclairage procédural temps réel, pas un véritable pipeline HDRI/IBL ni un moteur d’ombres portées. Le rendu doit être validé sur les appareils Android ciblés.
