# OPS MULTI-FILE ENGINE — V3.17

## But
Améliorer la cohérence des livraisons qui touchent plusieurs fichiers sans remplacer les moteurs existants ni contourner la validation utilisateur.

## Fonctionnement
- `server/artifact-graph.mjs` construit un graphe statique depuis les fichiers proposés et les chemins présents dans le workspace.
- Les références locales JavaScript/TypeScript prises en charge comprennent les imports depuis un module, les imports de côté, les imports dynamiques et `require`.
- Les fichiers HTML sont analysés pour les références `script[src]` et `link[href]`.
- Les chemins trouvés deviennent des arêtes `from → to` ; les références locales sans cible connue deviennent des avertissements `LOCAL_REFERENCE_UNRESOLVED`.
- Le rapport est ajouté au résultat de tâche. Les agents DEBUG/QUALITY peuvent l'utiliser avec les fichiers proposés transmis par les dépendances.

## Limites connues
Ce n'est pas un résolveur complet de modules. Les alias configurés dans Vite/Webpack/TypeScript, les imports bare (`three`, `react`), les chemins calculés, les ressources générées et les résolutions propres à certains frameworks ne sont pas validés. Un avertissement ne signifie pas automatiquement que le fichier est cassé. Une absence d'avertissement ne prouve pas que le projet compile ou fonctionne.

## Sécurité et validation
L'analyse est en lecture seule : elle ne lance aucun code, n'exécute aucun script et ne modifie pas les fichiers. Les propositions suivent le circuit existant `approval` ou `auto` avec sauvegarde. Les suppressions restent soumises à confirmation.

## Tests
`tests/artifact-graph.test.mjs` couvre les liens de modules, les références manquantes, les références HTML, les fichiers déjà présents et les chemins non sûrs.
