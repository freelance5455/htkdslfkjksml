# OPS CODER AI — workflow de patch V3.16

## Objectif
Permettre au CODER de modifier une partie d’un fichier existant sans régénérer tout le fichier, tout en préservant les éléments non ciblés.

## Protocole
Après lecture du fichier, l’agent peut livrer :

```xml
<ops-patch path="src/main.js">
[{"find":"bloc exact existant","replace":"bloc corrigé"}]
</ops-patch>
```

`find` doit être non vide et apparaître exactement une fois au moment de l’application. Les opérations sont appliquées dans l’ordre. Les patchs sont limités à 100 opérations, 50 000 caractères par contexte recherché, 100 000 caractères par remplacement et 5 Mo pour le fichier final.

## Contrôles
- Le chemin est résolu par le gestionnaire de workspace, qui refuse les chemins sortant du projet et les liens symboliques externes.
- Le fichier doit exister et être textuel.
- Un contexte absent, répété, invalide ou trop volumineux entraîne un refus explicite.
- Un même chemin ne peut pas recevoir simultanément un `<ops-file>` complet et un `<ops-patch>` dans une tâche.
- Les patchs sont appliqués au contenu réellement présent au moment de la préparation de la proposition.
- Le résultat final passe par `recordProposal`, puis par approval ou auto comme les fichiers complets.
- Chaque écriture effective conserve le système de sauvegarde, journal et annulation déjà présent.
- Les suppressions restent séparées et ne sont jamais automatisées.

## Limites connues
Ce protocole est un remplacement exact de texte, pas un moteur universel de fusion AST ni un algorithme de résolution de conflits sémantiques. Il peut refuser un patch quand le contexte a évolué ou n’est pas unique ; dans ce cas, l’agent doit relire le fichier et produire un patch plus précis ou un fichier complet. Les patchs ne garantissent pas la correction fonctionnelle du code : DEBUG et les tests du projet restent nécessaires.

## Vérification
Tests unitaires : parsing du protocole, application exacte, refus des contextes absents ou ambigus. Test d’intégration : proposition de patch sur un fichier existant, préservation d’une ligne non ciblée, approbation et vérification du contenu final.
