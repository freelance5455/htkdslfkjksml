# OPS MASTER AI NEURAL V7.0

## Viewport PBR

La V7.0 complète le viewport WebGL 2 avec le chargement des textures glTF externes référencées par les matériaux. Les UV `TEXCOORD_0` sont envoyées au GPU. Les maps BaseColor, Normal et ORM sont décodées localement avec `createImageBitmap`, uploadées en textures WebGL et munies de mipmaps.

Le fragment shader combine la couleur de base, l'occlusion, la rugosité et le canal métallique dans un éclairage temps réel simplifié (diffus + spéculaire). Si une texture est absente ou illisible, le rendu retombe sur la couleur du matériau.

## Préservation

La génération de modèles, les exports glTF/OBJ, les textures procédurales, le picking de surface, les traits de sculpture, les trois LOD, la validation serveur et les autres modules OPS sont conservés.

## Limites connues

Ce n'est pas encore un moteur PBR complet : pas d'IBL/HDRI, pas de pipeline tangent-space complet garanti pour tous les assets glTF, ni de validation physique sur appareil Android. Le viewport dépend de WebGL 2 et de `createImageBitmap`.
