# OPS MASTER AI NEURAL V3.1 — intégration directe des moteurs au jeu

## Agents principaux

`npc` (OPS NPC ENGINE AI) et `physics` (OPS PHYSICS ENGINE AI) sont désormais des agents de premier niveau du planificateur, et non de simples profils du module OPS DIRECTOR. Ils reçoivent leurs propres tâches, prompts métier, contexte projet, dépendances, propositions de fichiers et revue qualité.

## Contrat d'intégration obligatoire

Pour chaque projet de jeu, les agents spécialisés doivent :
1. inspecter le moteur et les fichiers d'entrée réellement utilisés ;
2. créer/modifier les modules du projet lui-même ;
3. fournir un bootstrap importé/appelé depuis le vrai point d'entrée du jeu ;
4. raccorder les mises à jour au Game Loop et partager les événements/contrats ;
5. fournir des tests et des étapes de vérification en jeu.

Une réponse textuelle ou un module isolé non appelé par le jeu ne compte pas comme une intégration terminée. L'agent doit signaler les dépendances ou API manquantes plutôt que prétendre que tout fonctionne.

## Runtime de référence portable

- `game-engines/npc-engine.mjs` : cycle de vie PNJ, états, mémoire bornée, adaptateurs de perception/navigation, événements et limite de mises à jour.
- `game-engines/physics-engine.mjs` : ordonnanceur physique à pas fixe, limitation des sous-pas, délégation au backend réel (moteur existant du projet).
- `game-engines/runtime-bridge.mjs` : façade commune et raccord au Game Loop via `subscribe`.

Ces modules sont un kit de référence réutilisable dans un projet. Ils ne sont pas automatiquement copiés dans tous les jeux : les agents doivent les adapter et les intégrer aux fichiers du jeu cible lors de chaque développement. Le backend physique concret reste celui du moteur du jeu ; le pont ne prétend pas remplacer un solveur physique complet.

## Collaboration

NPC expose ses changements d'état et événements ; PHYSICS expose les opérations de corps/colliders et son pas fixe ; GAMEPLAY consomme les événements ; ANIMATION réagit aux états ; WORLD fournit navigation/espaces ; QA vérifie les raccordements et non-régressions. Le planificateur demande explicitement NPC, PHYSICS et les spécialistes de jeu pour les demandes de création de jeu.
