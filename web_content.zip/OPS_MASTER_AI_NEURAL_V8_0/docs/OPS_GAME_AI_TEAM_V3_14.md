# OPS GAME AI TEAM — V3.14

## Objectif
Renforcer toute l’équipe qui participe à la création de jeux et rendre OPS CODER AI responsable de l’implémentation réelle, en binôme obligatoire avec OPS DEBUG AI. Les moteurs existants et les pipelines WORLD/MODELING restent en place.

## Rôles renforcés
- **COORDINATOR** : planifie les lots, contrats, dépendances et transferts.
- **ARCHITECT** : définit API, schémas, unités, événements et ordre d’initialisation.
- **CODER** : inspecte le projet, écrit les fichiers complets, relie les modules au bootstrap/Game Loop, ajoute tests et corrections.
- **FRONTEND** : menus, HUD, commandes et interface réellement reliés aux états du jeu.
- **BACKEND** : services, sauvegarde et réseau lorsque la demande l’exige.
- **ENGINE3D** : scène, rendu, caméra, ressources et budgets de performance.
- **GAMEPLAY** : règles, objectifs, progression et tests déterministes.
- **NPC** : comportements, perception bornée, navigation et réactions événementielles.
- **PHYSICS** : unités, collisions, triggers et synchronisation.
- **ART3D** : ressources, échelle, pivots, matériaux et LOD.
- **ANIMATION** : rigs, états, transitions et synchronisation.
- **AUDIO** : gestionnaire audio, volumes et activation utilisateur.
- **DEBUG** : audit indépendant des sources proposées, preuves, causes et tests de non-régression.
- **QUALITY** : validation indépendante de la traçabilité défaut → correction → test.

## Pipeline obligatoire de création de jeu
1. Les spécialistes disponibles préparent leurs contrats et contributions en parallèle.
2. **OPS CODER AI** reçoit leurs résultats et construit le jeu, écrit les fichiers et intègre les modules au véritable point d’entrée et au cycle de jeu.
3. **OPS DEBUG AI** reçoit les contenus exacts des fichiers proposés par CODER, même s’ils ne sont pas encore approuvés/appliqués au workspace. Il réalise un audit sans réécrire les sources.
4. **OPS CODER AI** reçoit à la fois ses sources initiales et le rapport DEBUG. Il corrige les défauts confirmés, justifie les constats non retenus et ajoute les tests de non-régression.
5. **OPS QUALITY TEAM** réalise la relecture indépendante déjà présente dans l’orchestrateur.
6. Les fichiers suivent toujours le mode d’écriture du projet et ses approbations. Les suppressions ne deviennent pas automatiques.

## Transfert de code entre tâches
`server/orchestrator.mjs` récupère les propositions `approvals` des tâches dont dépend un agent et les injecte comme sources de travail dans son contexte. Cela permet au correcteur d’auditer le vrai contenu et au codeur de corriger sur la base du rapport, sans appliquer prématurément les fichiers au workspace.

## Migration des projets existants
`seedAgents()` ajoute de façon additive tous les agents de production de jeu aux projets existants. Les agents déjà sélectionnés sont conservés et leur ordre reste inchangé. Aucun moteur ni fichier du projet utilisateur n’est supprimé.

## Limites et honnêteté
- OPS CODER AI reste un agent qui appelle le fournisseur/modèle configuré ; cette évolution ne modifie pas les poids du modèle externe et ne constitue pas un fine-tuning.
- La qualité du code généré dépend du fournisseur, du modèle, des outils disponibles et du contexte du projet.
- L’audit DEBUG est une revue IA des sources transmises ; il ne remplace pas les tests automatisés, l’exécution réelle du jeu ou une validation humaine.
- Un fichier proposé n’est pas considéré comme intégré tant que le mécanisme d’approbation/application ne l’a pas confirmé.

## Vérification
Tests ciblés : cycle CODER → DEBUG → CODER, dépendances, migration additive de l’équipe et prompts métier. Résultats de la suite complète consignés dans `RAPPORT_TESTS_V3_14.md`.
