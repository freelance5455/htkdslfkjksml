# OPS VISUAL GAME TESTING — V3.11

## Fonctionnalités livrées
- Audit statique et non intrusif des fichiers HTML, CSS et JavaScript/TypeScript du workspace.
- Détection d'indices d'application 3D/jeu (canvas, WebGL, Three.js/Babylon.js, boucle de rendu).
- Contrôles de préparation mobile : viewport, événements tactiles/pointeur, redimensionnement, tailles fixes et CSS responsive.
- Contrôles de structure d'interface : titre, zone principale, libellés accessibles.
- Rapport avec sévérités, preuves (chemins de fichiers), score heuristique et limites.
- Historique persistant dans `test_reports` avec le type `visual-static`.

## API
- `POST /api/projects/:id/visual-tests` : exécute un audit statique.
- `GET /api/projects/:id/visual-tests?limit=20` : retourne les rapports précédents.

## Interprétation
- `errors` : défauts détectés qui empêchent de considérer l'audit statique comme réussi.
- `warnings` : risques à examiner, notamment pour mobile et rendu de jeu.
- `information` : conseils ou indices de maintenance.
- `score` : indicateur heuristique (100 moins pénalités), non assimilable à une note graphique ou à une certification.

## Limites
Cette version n'exécute pas le code du jeu, n'ouvre pas de navigateur, ne simule pas les contrôles et ne produit pas de capture d'écran. Elle ne vérifie donc pas les FPS, les collisions, le rendu réel, les erreurs console, les shaders ou le comportement en jeu. Ces contrôles nécessitent un runner navigateur/3D dédié dans une prochaine version.
