# OPS SATELLITE AI

OPS SATELLITE AI est le 12e spécialiste du studio OPS. Son rôle est d'analyser des images satellitaires publiques fournies comme références pour le développement de mondes fictifs.

## Entrées prises en charge
- Image PNG, JPEG ou WEBP, jusqu'à 5 Mo depuis le chat Satellite.
- L'image doit être transmise par l'utilisateur ; le système ne prétend pas avoir un flux satellite en direct.
- NASA Worldview est proposé comme source publique de références : https://worldview.earthdata.nasa.gov/

## Analyse
Le spécialiste décrit les reliefs, cours d'eau, végétation, littoraux, densité bâtie, trames de rues et grandes zones d'occupation du sol. Il sépare les observations visibles des hypothèses, et signale les limites de résolution, de date ou de qualité lorsqu'elles sont connues.

## Partage automatique
Après chaque analyse dans le chat Satellite :
1. le dossier est conservé dans la mémoire du projet sous l'agent `satellite` ;
2. un message de type `report` est envoyé à chacune des 11 autres IA ;
3. les dossiers récents sont ajoutés au contexte partagé transmis aux IA lors des conversations et tâches suivantes ;
4. les plans de création de ville comportent désormais une étape satellitaire avant WORLD.

## Fournisseurs multimodaux
L'analyse des pixels nécessite un fournisseur et un modèle capables de traiter les images. Les adaptateurs compatibles OpenAI, Anthropic et Gemini reçoivent les images sous leur format multimodal respectif. Un modèle uniquement textuel ne pourra pas décrire les pixels correctement.

## Limites
Les images sont des références de conception et non des relevés topographiques certifiés. Les détails non visibles ne doivent pas être inventés. L'IA n'est pas conçue pour surveiller des personnes ni pour désigner des cibles réelles.
