# OPS NEURAL LEARNING ENGINE — V3.28

La V3.28 ajoute une capitalisation traçable des expériences. Un agent peut proposer une leçon en utilisant explicitement `LEÇON RÉUTILISABLE:` (ou `EXPÉRIENCE À CAPITALISER:`), avec `DOMAINE:` et `PREUVE:` facultatifs. La proposition est enregistrée en statut `pending`, jamais approuvée automatiquement. Les expériences approuvées sont déjà récupérées par le moteur d'orchestration de la V3.27 et injectées dans les tâches pertinentes.

API ajoutée : `GET /api/projects/:id/learning-stats`.

Limites : ce mécanisme n'entraîne pas les poids des modèles externes. Il constitue une mémoire d'expériences structurée, révisable et réutilisable. Une proposition sans preuve reste en attente de validation humaine.
