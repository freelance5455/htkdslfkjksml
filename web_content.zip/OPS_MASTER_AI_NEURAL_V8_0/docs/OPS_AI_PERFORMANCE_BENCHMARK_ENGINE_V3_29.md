# OPS AI PERFORMANCE & BENCHMARK ENGINE — V3.29

La V3.29 ajoute une couche de mesure fondée sur les données réellement enregistrées.

## Capacités
- Rapport par projet et par agent à partir des tâches (`tasks`) : volume, tâches terminées/échouées, relances et durée moyenne disponible.
- Agrégation des journaux fournisseur (`usage`) : appels et tokens journalisés.
- Score composite explicable : réussite 65 %, taux de relance 20 %, durée 15 % lorsqu'elle est mesurable. Les composantes indisponibles sont exclues.
- Indication de confiance selon la taille de l'échantillon (insuffisante, faible, moyenne, élevée).
- Instantanés historiques explicites, conservés dans `benchmark_snapshots`.
- Écran `AI Performance Benchmarks` et API projet.

## API
- `GET /api/projects/:id/benchmarks`
- `POST /api/projects/:id/benchmarks/snapshot`
- `GET /api/projects/:id/benchmarks/history`

## Limites d'interprétation
Les tâches en cours ne sont pas comptées comme réussites. La durée ne mesure pas la difficulté. La table `usage` ne porte pas de `project_id` : ses totaux par agent peuvent donc inclure d'autres projets utilisant le même agent. Les scores ne doivent pas servir à comparer des rôles ou des difficultés différentes sans normalisation. Un petit échantillon est explicitement marqué comme peu fiable. Aucune amélioration automatique des modèles ni modification de leurs poids n'est effectuée.
