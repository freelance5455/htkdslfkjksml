# OPS MASTER AI NEURAL V5.2

## Objectif

Rendre effective la politique de seconde tentative déjà prévue dans le moteur d’orchestration.

## Changements

1. Après un run d’agent, le moteur relit le statut réel de la tâche. Si le run a échoué ou si aucun résultat exploitable n’a été reçu, une seconde tentative est lancée lorsque l’erreur est récupérable.
2. WORLD et MODELING suivent le même principe lorsque leur artefact échoue à la validation.
3. Les erreurs de configuration, d’authentification, de quota/budget, les propositions rejetées et les approbations invalides restent bloquantes et ne sont pas répétées.
4. Le nouvel essai détache les anciens identifiants run/approbation et conserve le compteur d’essais.
5. Le journal décrit explicitement le motif et le numéro de la nouvelle tentative.

## Limites

- Deux tentatives automatiques maximum par tâche.
- Les tâches dépendantes restent bloquées tant que le résultat n’est pas validé.
- Une proposition de fichier en attente ou refusée ne peut pas être approuvée automatiquement.
- Les scripts du projet ne sont jamais exécutés sans autorisation explicite.
