# OPS MASTER AI NEURAL V6.7

## Viewport 3D interactif

Cette version ajoute un viewport WebGL 2 dans l’éditeur de sculpture. Il charge le fichier glTF 2.0 de l’asset, lit le buffer embarqué, affiche le LOD0 et utilise les couleurs de base des matériaux.

### Interactions
- Glissement à un doigt ou à la souris : rotation du modèle.
- Pincement à deux doigts ou molette : zoom.
- Changement d’asset : rechargement du maillage et recentrage de la vue.

### Limites connues
La sélection de sommets, la peinture/sculpture directement sur la surface et l’aperçu des textures PBR dans le viewport ne sont pas encore inclus. Les outils Inflate, Smooth et Flatten existants restent disponibles via le centre XYZ et sont validés côté serveur sur les trois LOD. WebGL 2 est requis.
