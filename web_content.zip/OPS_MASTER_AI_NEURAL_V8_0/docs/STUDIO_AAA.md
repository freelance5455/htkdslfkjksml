# OPS MASTER AI NEURAL — agents AAA

## Roster construit

- **OPS DIRECTOR AI** : direction, planification, arbitrage, mémoire et distribution.
- **OPS WORLD AI** : mondes ouverts, quartiers, routes, streaming et densité.
- **OPS MODELING AI** : maillages, UV, PBR, LOD, personnages, décors et exports.
- **OPS ANIMATION AI** : rigs, squelettes, retargeting, IK/FK, locomotion et cinématiques.
- **OPS NPC AI** : perception, mémoire, routines, navigation et comportements autonomes.
- **OPS PHYSICS AI** : collisions, contraintes, véhicules, interactions et stabilité.
- **OPS VEHICLE AI** : conduite, suspension, transmission, intérieurs et simulation.
- **OPS GAMEPLAY AI** : boucles de jeu, missions, progression, équilibrage et sauvegardes.
- **OPS GRAPHICS AI** : rendu, éclairage, shaders, matériaux, LOD et profils qualité.
- **OPS STORY AI** : univers, personnages, dialogues, arcs et continuité.
- **OPS QA AI** : tests, compatibilité, performance, sécurité et non-régression.

## Exécution et coopération

Chaque IA dispose d'un prompt spécialisé. Les tâches du Director sont exécutées par le spécialiste assigné, avec le fournisseur/modèle qui lui est propre ou, en repli, le fournisseur configuré pour le Director. WORLD et MODELING conservent leurs pipelines dédiés. Les autres spécialistes disposent d'un chat direct et peuvent exécuter les tâches du graphe de production.

Les dépendances conditionnent l'ordre d'exécution. À la fin d'une tâche, le résultat est transmis automatiquement aux IA qui en dépendent. Le paquet de contexte commun contient le projet, les décisions, les plans, les derniers résultats, les ressources et les moteurs déclarés.

Le statut « construite » indique que le rôle logiciel et son circuit d'exécution sont présents. Pour produire des réponses IA réelles, un fournisseur doit être configuré. L'application ne prétend pas qu'un test a été exécuté si ce n'est pas le cas.

- **OPS SATELLITE AI** : analyse d’images satellitaires publiques fournies par l’utilisateur, extraction de références de terrain/relief/urbanisme pour les mondes fictifs et diffusion du dossier à toutes les autres IA.
