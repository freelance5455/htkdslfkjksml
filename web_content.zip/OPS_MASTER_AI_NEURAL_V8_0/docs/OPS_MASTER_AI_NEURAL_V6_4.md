# OPS MASTER AI NEURAL V6.4

## Textures PBR haute résolution

La génération d'assets prend en charge des maps BaseColor, Normal et ORM aux résolutions 64, 128, 256, 512, 1024 et 2048 pixels. Les PNG sont externes et référencés par le glTF 2.0, ce qui évite de gonfler le JSON glTF avec des chaînes base64.

Les modèles individuels utilisent 512×512 par défaut. Les kits de villes utilisent 128×128 pour garder un volume de livraison raisonnable.

## Limites explicites

Les textures sont procédurales et les maillages sont générés par règles. Cette version n'ajoute pas de sculpting organique, de peinture 3D interactive, de retopologie manuelle, de rigging humain ni de validation visuelle dans un moteur externe. 2048×2048 est la résolution maximale supportée ; le 4K n'est pas activé.
