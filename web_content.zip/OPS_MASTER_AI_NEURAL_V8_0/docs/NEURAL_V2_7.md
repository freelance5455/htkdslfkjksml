# OPS MASTER AI NEURAL V2.7 — Recherche Internet collaborative

## Contrat de détail
Chaque spécialiste reçoit désormais un contrat commun de qualité de production et des exigences adaptées à son métier : architecture, paramètres, états, cas limites, dépendances, critères d’acceptation, tests, limites et auto-relecture. Les prompts détaillent aussi les exigences propres à WORLD, MODELING, ANIMATION, NPC, PHYSICS, VEHICLE, GAMEPLAY, GRAPHICS, STORY, QA et DIRECTOR.

## Assistance centrale en cas de lenteur
Lorsqu’un appel d’un spécialiste du studio ou de l’orchestrateur dépasse le premier délai de 45 secondes, OPS DIRECTOR AI / le coordinateur est sollicité pour produire une aide technique structurée. Le spécialiste reprend ensuite la tâche avec cette aide et reste responsable de son résultat. Le système ne transforme pas un délai dépassé en réussite fictive : si l’assistance ou la reprise échoue, l’erreur est signalée.

## Amélioration continue
La revue qualité finale contrôle désormais le niveau de détail, les critères d’acceptation, les cas limites et la finition attendue pour un jeu commercial. Les cycles de correction configurables sont étendus à 5 maximum, avec 4 par défaut. Le processus s’arrête lorsque la revue ne relève plus de problème exploitable ou lorsque la limite configurée est atteinte ; il ne prétend donc pas garantir une perfection infinie ni une certification AAA.

## Limites honnêtes
La qualité réelle dépend du modèle et du fournisseur configurés, des fichiers disponibles, des tests exécutables et des plateformes visées. La supervision ne peut pas fabriquer un asset, lancer un moteur 3D ou certifier un jeu si les outils correspondants ne sont pas présents.

## OPS SATELLITE AI

Ajout du 12e spécialiste, analyse multimodale d’images satellitaires fournies (PNG/JPEG/WEBP jusqu’à 5 Mo), mémoire de dossiers et diffusion automatique aux 11 autres IA. Les plans de ville ajoutent une étape de référence satellitaire en amont de WORLD.


## V2.7 — OPS WEB RESEARCH AI
- Ajout de la 13e IA du studio : OPS WEB RESEARCH AI.
- Recherche via Tavily ou Brave Search API configuré dans Paramètres → Recherche Web.
- Récupération facultative des trois premières pages publiques, avec protection SSRF et limites de taille déjà présentes dans le module web.
- Synthèse avec sources et liens ; dossier conservé dans la mémoire du projet et transmis aux 12 autres IA.
- Les contenus web sont traités comme des données non fiables : aucune instruction trouvée sur une page ne peut remplacer les consignes OPS.
- Sans clé de recherche configurée, l'IA indique clairement que la recherche n'est pas disponible et ne simule aucun résultat.
