# OPS CODER AI — curriculum V3.2

## Objectif
Améliorer la fiabilité de OPS CODER AI en lui fournissant, à chaque requête, un corpus compact de règles métier, des exemples contrastifs et une grille d'auto-évaluation.

## Compétences couvertes
1. Inspection du projet avant toute modification.
2. Préservation des fonctionnalités et compatibilité ascendante.
3. Intégration réelle au bootstrap, au point d'entrée et au Game Loop.
4. Contrats explicites entre moteurs et adaptateurs.
5. Débogage par cause racine et tests de non-régression.
6. Tests unitaires, intégration et rapport fidèle des résultats.
7. Performance CPU/GPU/mémoire, notamment sur mobile.
8. Sécurité des entrées, secrets et exécutions.
9. Livraison transparente sur les éléments réellement vérifiés.

## Fonctionnement
`server/coder-training.mjs` exporte le curriculum, les exemples, `buildCoderTrainingContext()` et `evaluateCoderEvidence()`. `systemPromptFor()` injecte ce contexte uniquement à l'agent `coder`, sans modifier les prompts des autres agents.

La grille évalue huit preuves : inspection, préservation, contrats, intégration du point d'entrée, tests ajoutés, tests exécutés, revue sécurité et limites déclarées. Le score est un indicateur de présence de preuves, pas une mesure de qualité universelle ni une preuve automatique de correction.

## Limite technique
Ce mécanisme est un entraînement contextuel (instructions + exemples + évaluation logicielle). Il ne réalise pas de fine-tuning, ne modifie pas les paramètres du modèle externe et ne crée pas de nouvelles capacités indépendantes du fournisseur configuré. Un véritable entraînement des poids nécessiterait un jeu de données autorisé, un modèle entraînable, une infrastructure GPU, une procédure de validation et une gestion des versions du modèle.
