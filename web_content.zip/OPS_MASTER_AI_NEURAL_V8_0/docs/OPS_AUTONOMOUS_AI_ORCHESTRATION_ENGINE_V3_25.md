# OPS AUTONOMOUS AI ORCHESTRATION ENGINE — V3.25

## Objectif

Ajouter un planificateur multi-IA explicite, complémentaire au Director, au Project Manager, au Supervisor et au Control Center. Les plans sont persistés dans `orchestration_plans` et `orchestration_plan_tasks`.

## Fonctionnalités

- Plans de 1 à 40 tâches, avec identifiants uniques et instructions bornées.
- Affectation explicite à un agent OPS activé ou sélection déterministe selon spécialité et charge connue.
- Validation des dépendances, des agents et des cycles avant création.
- Transmission des tâches éligibles par le bus de collaboration persistant.
- Blocage d'une tâche lorsque l'une de ses dépendances est bloquée.
- Synchronisation des états depuis les transmissions (queued, accepted, in_progress, review, done, blocked).
- Déverrouillage des tâches dépendantes lors d'un appel `advance` après la livraison d'un prérequis.
- Historique conservé dans les tables d'orchestration et dans le bus de collaboration.
- Interface dédiée permettant de créer, consulter et poursuivre les plans.

## API

- `GET /api/projects/:id/orchestration` — lister les plans.
- `POST /api/projects/:id/orchestration` — créer un plan `{ title, tasks }`.
- `GET /api/orchestration/:id` — rapport détaillé.
- `POST /api/orchestration/:id/advance` — synchroniser les transmissions et dispatcher les tâches devenues éligibles.

## Limites et garanties

- Le moteur crée des transmissions dans le bus OPS ; il ne prétend pas que le modèle destinataire a exécuté la tâche. Le destinataire doit traiter la transmission avec les mécanismes OPS existants.
- La progression des dépendances se fait lors de `advance` (appel API / bouton de l'interface), pas par un service d'exécution permanent en arrière-plan.
- Aucun script du projet n'est lancé par ce planificateur.
- Aucun fichier n'est modifié directement par l'orchestrateur.
- Les tâches existantes du Director et de l'Orchestrator ne sont ni remplacées ni supprimées.
- La sélection automatique ne prouve pas la disponibilité runtime d'un modèle ; elle se base sur les agents activés et la charge connue.

## Vérifications

Tests unitaires de validation (doublons, dépendances absentes, cycles, agents désactivés) et test API du cycle de vie de plan (création, transmission initiale, achèvement d'un prérequis, déblocage de la tâche suivante).
