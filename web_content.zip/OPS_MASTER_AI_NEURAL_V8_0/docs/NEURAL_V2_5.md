# OPS MASTER AI NEURAL V2.6 — Détail AAA et amélioration continue

## Contrat de détail
Chaque spécialiste reçoit désormais un contrat commun de qualité de production et des exigences adaptées à son métier : architecture, paramètres, états, cas limites, dépendances, critères d’acceptation, tests, limites et auto-relecture. Les prompts détaillent aussi les exigences propres à WORLD, MODELING, ANIMATION, NPC, PHYSICS, VEHICLE, GAMEPLAY, GRAPHICS, STORY, QA et DIRECTOR.

## Assistance centrale en cas de lenteur
Lorsqu’un appel d’un spécialiste du studio ou de l’orchestrateur dépasse le premier délai de 45 secondes, OPS DIRECTOR AI / le coordinateur est sollicité pour produire une aide technique structurée. Le spécialiste reprend ensuite la tâche avec cette aide et reste responsable de son résultat. Le système ne transforme pas un délai dépassé en réussite fictive : si l’assistance ou la reprise échoue, l’erreur est signalée.

## Amélioration continue
La revue qualité finale contrôle désormais le niveau de détail, les critères d’acceptation, les cas limites et la finition attendue pour un jeu commercial. Les cycles de correction configurables sont étendus à 5 maximum, avec 4 par défaut. Le processus s’arrête lorsque la revue ne relève plus de problème exploitable ou lorsque la limite configurée est atteinte ; il ne prétend donc pas garantir une perfection infinie ni une certification AAA.

## Limites honnêtes
La qualité réelle dépend du modèle et du fournisseur configurés, des fichiers disponibles, des tests exécutables et des plateformes visées. La supervision ne peut pas fabriquer un asset, lancer un moteur 3D ou certifier un jeu si les outils correspondants ne sont pas présents.
