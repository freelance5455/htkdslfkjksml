# OPS MASTER AI NEURAL V7.8

## Contrôle de non-régression après Bug Fixer

- Le Bug Fixer compare l’état du workspace à la sauvegarde créée avant la correction lorsque son orchestration est terminée.
- Le rapport expose les fichiers supprimés, les fonctions/classes détectées comme disparues et les fichiers fortement réduits.
- Une suppression de fichier est marquée `blocked`; une perte de symbole ou une réduction importante est marquée `review`; une comparaison sans signal structurel est `clean`.
- Si la comparaison échoue ou si la référence manque, le résultat est `unavailable` et ne prétend pas que la correction est sûre.
- Les tests fonctionnels restent indispensables : `clean` ne signifie pas que le programme fonctionne.
- Aucun rollback, déploiement ou script de projet n'est exécuté automatiquement. Les modes d'approbation existants restent applicables.

## Validation

Les tests unitaires vérifient les quatre états de revue. Le doctor vérifie l'alignement de version et la syntaxe locale. Les tests d'intégration nécessitant un serveur local doivent être exécutés dans un environnement où les sockets locales sont disponibles.
