# OPS MODELING AI — Étape 4 du studio (modélisation 3D)

## Objectif : des IA qui construisent un jeu AAA ensemble
Le point clé n'est pas un modèle isolé mais un **contrat d'échange commun**, `ops-assets` v1, que toutes les IA du studio liront :
- unités en mètres, Y vers le haut, repère droit (comme glTF 2.0), triangles anti-horaires vus de l'extérieur, base du modèle à y = 0 ;
- normales unitaires, UV en mètres / 4 (tuilage voulu), matériaux **PBR** (couleur, métal, rugosité, émissif) nommés `MI_*`, meshes nommés `SM_*` ;
- **3 LOD** (0 détaillé, 1 bandeaux de fenêtres, 2 volumes) ; **collisions** en boîtes convexes (centre, demi-dimensions, rotation Y) ;
- manifeste `*.ops-assets.json` : emprises, hauteurs, bornes, matériaux, collisions, triangles par LOD, nombre d'instances, **placements** dans le monde.
Qui lit quoi : WORLD fournit le monde (`world.json`) ; MODELING produit les assets et les placements ; GRAPHICS lira les matériaux ; PHYSICS les collisions ; NPC/VEHICLE les emprises et hauteurs ; QA validera le tout.

## Ce qu'elle fait réellement
`server/modelgen.mjs` (aucune dépendance, déterministe) :
- **11 bâtiments/monuments** : maison, bureau, usine, entrepôt, tour (gradins + flèche), mairie (colonnes, pédiment, clocher), stade (anneau, gradins, pelouse), cathédrale, musée, marché, gare — fenêtres, portes, corniches, toits (plat à acrotère, deux pentes, pyramide), cheminée.
- **4 props** : arbre, lampadaire, banc, caisse. **8 styles** de matériaux.
- **Kit depuis un monde WORLD** (`planKit`) : regroupe les bâtiments en ≤ 48 archétypes (4–64) par fusion des variantes proches, erreur de forme bornée à ×1,35 sur largeur/profondeur/hauteur, monuments jamais fusionnés ; calcule un placement (position, rotation, échelle) pour chaque bâtiment ; ajoute les 4 props. Sur les mondes de test : 650 bâtiments → 48 archétypes, LOD1 ≈ 5× moins de triangles que LOD0.
- **Validation indépendante** (`validateAsset`) : indices valides, tailles POSITION/NORMAL/UV cohérentes, valeurs finies, normales unitaires, orientation de chaque triangle cohérente avec sa normale, aucun triangle dégénéré, matériaux connus, LOD strictement décroissants, budgets (bâtiment : LOD0 ≤ 9 000 et LOD2 ≤ 400 triangles ; prop : 1 500 et 40), base à y = 0, collisions valides, nom valide. Un asset invalide est enregistré mais **ses fichiers ne sont pas livrés**.
- **Textures PBR** : génération déterministe de PNG BaseColor, Normal tangent-space et ORM (occlusion/roughness/metallic) en 64×64 pour chaque matériau. Les maps sont intégrées en data URI dans le glTF 2.0 ; les fichiers PNG sont aussi livrés séparément et le MTL référence la BaseColor. Les PNG traversent les approbations et les écritures binaires du workspace.

## Rôle de l'IA (modèle de langage)
Le LLM **choisit le plan** (un modèle ou un kit, ses paramètres) à partir du brief, des résultats précédents (le monde de WORLD), des décisions et des messages reçus ; sa réponse JSON est filtrée et validée, sinon 502 et rien n'est créé. Sans monde valide dans le projet, un kit est refusé (409) : rien n'est inventé. La génération manuelle fonctionne **sans fournisseur**.

## Intégration
- Livraison dans `models/<nom>-<id6>/` : approbations en mode « approbation », écriture directe avec version de sauvegarde en mode « auto ». Les noms fournis sont assainis.
- Director : les tâches attribuées à `modeling` sont exécutables ; le résultat est transmis aux IA suivantes (en file d'attente tant qu'elles ne sont pas construites). Les messages reçus (dont le handoff de WORLD) sont marqués lus.
- Chat : balises `<ops-model …/>` et `<ops-kit world="…" max="…"/>` (max 2 par message, résultats réels rapportés, échecs compris).
- API : `POST /api/modeling/{generate,kit,from-brief}`, `GET /api/modeling/assets[/:id]`, `GET /api/modeling/assets/:id/download?file=…` (liste blanche des fichiers de l'asset), `POST /api/studio/modeling/chat`.

## Limites connues (honnêtes)
- **Ce n’est pas encore du « AAA » artistique.** Les modèles restent procéduraux : volumes, fenêtres, toits et détails géométriques. Les textures actuelles sont synthétiques et limitées à 64×64 ; elles fournissent un pipeline PBR fonctionnel, pas des matériaux peints/scannés de qualité production. Il manque encore le sculpting haute résolution, les textures 2K/4K/8K, les détails de surface artistiques, les personnages/véhicules et les animations (autres spécialités). Les assets restent optimisés (LOD, instanciation, budgets).
- L'aperçu SVG est indicatif (tri des polygones « du peintre » : artefacts d'occlusion possibles sur les grands plans) ; la validité des meshes est contrôlée par le validateur, pas par l'image.
- Le kit étire légèrement les archétypes (échelle jusqu'à ×1,4) pour couvrir les variantes fusionnées ; plus de variantes = plus d'archétypes (jusqu'à 64).
- Aucun import dans Unity/Unreal/Godot n'a été testé : seuls les formats sont produits et vérifiés par des contrôles structurels (le glTF est contrôlé par un lecteur écrit pour les tests, pas par le validateur officiel Khronos, indisponible hors ligne).
- Les fichiers glTF sont en JSON avec tampon base64 (≈ +33 %), pas en .glb.
- Le choix du plan par LLM n'a été testé qu'avec la fixture locale, pas avec un vrai modèle.


## V6.2 — profils de finesse géométrique
Le générateur accepte désormais `quality: balanced | high | ultra` pour les assets individuels. Les profils augmentent progressivement le nombre de segments des éléments courbes (anneaux, cylindres, cônes et feuillages), avec des LOD recalculés et une validation complète conservée. Les anciens appels sans paramètre gardent `balanced` par défaut. L'interface propose `high` par défaut, `balanced` pour les appareils modestes et `ultra` pour les assets héros. Ces profils améliorent la finesse géométrique, mais **ne constituent pas à eux seuls une qualité artistique AAA** : sculpture, textures peintes, normal/roughness maps, personnages et validation dans un moteur temps réel restent des chantiers distincts.


## V6.3 — pipeline de textures PBR

Chaque matériau exporté reçoit trois textures PNG déterministes : BaseColor, Normal tangent-space et ORM (occlusion en R, roughness en G, metallic en B), résolution 64×64. Le glTF embarque ces maps en data URI et déclare les textures dans les matériaux PBR ; l’export OBJ/MTL référence les BaseColor et le dossier contient les trois fichiers par matériau. Le système d’approbation et l’écriture automatique savent préserver les PNG en binaire. Ces maps sont une base technique basse résolution, pas une promesse de textures AAA artistiques.

## Sculpture de maillage — V6.5

Une sculpture déterministe peut être appliquée à un asset existant via `POST /api/modeling/assets/:id/sculpt` avec `{ "operations": [...] }`. Chaque opération accepte `mode` (`inflate`, `smooth`, `flatten`), `center` `[x,y,z]`, `radius` (0.1–30 m) et `strength` (−0.25 à 0.25). Les modifications sont rejouées depuis les paramètres d'origine, appliquées aux trois LOD, puis les normales et bornes sont recalculées. La validation indépendante doit réussir avant que les exports glTF/OBJ/MTL et textures remplacent les fichiers de l'asset. Les kits ne sont pas sculptables directement. Limite : cet outil est un pinceau géométrique procédural, pas encore un éditeur sculpting interactif avec viewport, brosses de détail ou retopologie.
