# OPS MASTER AI NEURAL V7.3 — Éditeur PBR persistant

## Fonctionnalités
- Édition durable par matériau des facteurs BaseColor, metallic et roughness.
- Sélection d'un matériau du modèle dans l'éditeur de sculpture.
- Sauvegarde des modifications dans les paramètres de l'asset, l'export glTF 2.0, le fichier MTL et le manifeste OPS.
- Conservation des textures PNG PBR existantes ; les pixels des textures ne sont pas peints ni rééchantillonnés.
- Réapplication des overrides PBR après sculpture et préservation des opérations géométriques déjà enregistrées.
- Validation des identifiants de matériaux et des facteurs numériques dans [0,1].
- Prise en compte des facteurs metallic/roughness dans le viewport WebGL.

## Limites
- Pas encore de peinture de texture UV, de création de nouveaux matériaux, de graphe de shaders, de HDRI/IBL physique ou de rendu de production.
- L'export OBJ/MTL ne peut pas représenter toutes les propriétés PBR de glTF ; le glTF reste le format de référence.
- Le rendu WebGL et les interactions tactiles restent à vérifier sur un appareil Android physique.

## Tests ciblés
- Test de persistance PBR dans glTF et MTL.
- Test de validation des valeurs hors limites.
- Test de conservation des opérations de sculpture après une édition de matériau.
