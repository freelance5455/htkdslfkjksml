# OPS MASTER AI NEURAL V5.1

## Objectif
Rendre le contrôle de livraison directement accessible depuis chaque pipeline de production.

## Nouveautés
- Nouvelle route authentifiée `GET /api/production/:id/release-gate`.
- La route récupère le projet associé au pipeline puis produit le rapport OPS Release Gate existant.
- L'écran Production affiche le statut, le nombre de contrôles réussis/à vérifier/bloquants et le détail de chaque contrôle lorsque le pipeline a atteint un état terminal pertinent.
- En cas d'indisponibilité du rapport, le détail de production reste affiché.

## Limites explicites
- Le Release Gate est un contrôle statique et ne lance pas les scripts du projet.
- « candidate » signifie présélection interne, pas certification ni publication garantie.
- Les tests réels du projet restent une action distincte qui exige l'autorisation d'exécution du projet.
