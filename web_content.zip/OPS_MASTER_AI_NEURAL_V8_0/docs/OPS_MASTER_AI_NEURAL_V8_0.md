# OPS MASTER AI NEURAL V8.0 — Cartographie architecturale multi-fichiers

## Objectif
Renforcer OPS CODER AI pour qu’il comprenne mieux les dépendances d’un projet avant de modifier plusieurs fichiers et qu’il puisse expliquer l’impact des changements.

## Nouveautés
- `server/project-architecture.mjs` fournit une analyse statique en lecture seule : points d’entrée conventionnels, scripts/package.json, scripts HTML, graphe de dépendances, modules sources non atteignables, cycles et références locales non résolues.
- La carte d’impact remonte les dépendants directs et transitifs des fichiers modifiés.
- L’outil `inspect_project` expose maintenant un rapport d’architecture et ses données structurées au CODER et aux autres agents.
- Après une livraison multi-fichiers, l’orchestrateur ajoute un rapport d’architecture et d’impact au compte rendu.
- Les consignes CODER exigent de relier chaque nouveau module au vrai point d’entrée et de vérifier manuellement les alias, imports dynamiques et chargements runtime que l’analyse statique ne peut pas prouver.

## Sécurité et limites
- L’analyse est en lecture seule et n’exécute aucun code du projet.
- Les chemins sortant du workspace sont exclus.
- Un module déclaré orphelin est un indice à examiner, pas une preuve de défaut : plugins, auto-discovery, alias, imports dynamiques et chargements runtime peuvent être invisibles à l’analyse.
- Le graphe statique ne remplace ni les tests d’intégration ni une exécution sur les plateformes cibles.
- Aucun entraînement des poids du modèle fournisseur n’est effectué ; les améliorations portent sur les outils, les rapports et les consignes injectées au modèle.

## Tests
`tests/project-architecture.test.mjs` couvre les points d’entrée HTML, modules orphelins, cycles, impact transitif et chemins hors workspace.
