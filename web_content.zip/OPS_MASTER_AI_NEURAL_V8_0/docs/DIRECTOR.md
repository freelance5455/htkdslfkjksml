# OPS DIRECTOR AI — Étape 1 (statut : construite, en attente de validation)

## 1. Objectifs
Direction générale du studio : planifier, attribuer, coordonner, mémoriser, intégrer, rendre compte — sans jamais prétendre qu'une IA non construite ou un moteur non testé fonctionne.

## 2. Architecture (`server/director.mjs`, `server/exchange.mjs`)
- `studio_ais` : les 13 IA spécialistes officielles, statut `planned` → `built` → `validated` (la validation est un acte de l'utilisateur ; impossible sur une IA non construite).
- `director_plans` / `director_tasks` : plans et tâches (assignee ∈ 13 IA, priorité, estimation, dépendances). **L'état effectif est calculé, jamais stocké** : `ready`, `waiting_deps`, `waiting_ai` (IA non construite), `blocked` (dépendance annulée ou blocage manuel), `in_progress`, `review`, `done`, `cancelled`.
- Transitions contrôlées : une tâche terminée reste terminée (rien de détruit) ; terminer exige un résultat ; démarrer exige dépendances terminées **et** IA construite ; cycles refusés.
- `studio_messages` : bus inter-IA persisté (handoff, request, correction, result, report, note). Fin de tâche ⇒ messages de transmission automatiques vers les IA des tâches dépendantes ; destinataire non construit ⇒ statut `queued`.
- Mémoire : décisions stockées dans la mémoire partagée du projet (vue aussi par les agents OPS MASTER) ; `GET /api/director/context` = paquet de contexte (projet, plans, décisions, derniers résultats, bibliothèque, moteurs, statut des IA).
- Planification : 5 modèles déterministes (`city`, `vehicle`, `character`, `mission`, `game`) ou plan généré par le modèle du Director, **validé** (IA connues, dépendances, pas de cycle) ; JSON invalide ⇒ erreur 502, aucun plan partiel.
- Suivi : progression pondérée par estimations, chemin critique, alertes (blocages, tâches en attente d'IA, tâches sans mouvement > `director_stale_hours`, défaut 24 h), bilan markdown (+ analyse IA optionnelle).
- Moteurs : registre `engines` ; `verified` seulement après un test réel (GET HTTP 2xx ou aller-retour écriture/lecture dans le dossier d'échange du projet).
- Échange `ops-exchange` v1 : ZIP = `manifest.json` (format, version, assets[path,size,sha1,format]) + `files/…`. Import : tout est vérifié avant d'écrire (chemins, SHA-1, taille, anti zip-bomb), essai à blanc, conflits refusés sauf `overwrite`, écritures sauvegardées et annulables.

## 3. Fonctionnalités / 4. Fichiers
Écrans « Director » (Plans & tâches, Messages, Décisions, Moteurs, Échange, Bilan) et « Studio 13 IA AAA ». Fichiers créés : `server/director.mjs`, `server/exchange.mjs`, extension de `server/zip.mjs` (lecture), `public/app.js`, `tests/director.test.mjs`, ce document. Modifiés : `server/app.mjs`, `server/db.mjs`.

## Conversation directe avec le Director
Onglet « Discuter » (écran Director) ou bouton « Parler au Director » (écran Studio) ; API `POST /api/studio/director/chat {project_id, text}`. Le Director répond avec le contexte réel du projet (plans, décisions, moteurs, bibliothèque) et l'historique des 10 derniers messages (fil séparé du chat équipe, `GET /api/messages?agent_id=director`).
Il peut agir par balises, **non destructives**, max 5 par message : créer un plan (modèle), noter une décision, écrire à une autre IA (file d'attente si non construite), ajouter une tâche. Le résultat réel de chaque action (✅/⛔) est ajouté à la réponse ; il ne peut ni supprimer, ni annuler, ni terminer une tâche, ni valider une IA. Les IA non construites refusent la conversation (409). Sans fournisseur IA : erreur explicite (502).

## Limites et dépendances
- Le Director n'exécute lui-même que ses propres tâches (cadrage, synthèse, bilan) et nécessite un fournisseur IA réel configuré. Les tâches des autres IA restent planifiées (`waiting_ai`).
- Pas d'adaptateurs de conversion entre formats/moteurs (FBX↔glTF, etc.) : seul l'échange de fichiers vérifiés est livré ; chaque adaptateur viendra avec l'IA concernée.
- Test de moteur HTTP = simple vérification de disponibilité, pas de validation fonctionnelle du moteur.
- Pas encore de lien automatique avec les 11 agents « développeurs » d'OPS MASTER (ils partagent seulement la mémoire de projet et la bibliothèque).


## V3.0
Le roster du studio comprend 13 spécialistes AAA. Il reste distinct du roster des 11 agents développeurs (Coordinator, Architect, Frontend, Backend, Engine3D, Debug, Gameplay, Art3D, Animation, Audio, Quality). Les deux équipes conservent leurs rôles et leurs fonctions.
