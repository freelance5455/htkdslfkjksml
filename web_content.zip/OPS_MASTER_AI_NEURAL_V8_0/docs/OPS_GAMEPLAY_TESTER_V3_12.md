# OPS GAMEPLAY TESTER — V3.12

## Objectif

Ajouter un test de démarrage réel des projets web/HTML dans Chromium, en complément de l'audit statique V3.11. Le module est indépendant des autres moteurs OPS.

## Capacités

- Vérification de disponibilité de Playwright et Chromium sur le serveur OPS.
- Chargement d'un fichier d'entrée HTML dans un serveur statique temporaire lié à `127.0.0.1`.
- Viewport desktop (1280×720) ou mobile simulé (390×844, tactile).
- Capture d'écran JPEG.
- Collecte des erreurs JavaScript non interceptées, erreurs console et échecs de requêtes.
- Vérification du statut HTTP, du débordement horizontal, des canvas et de la présence d'un contexte WebGL.
- Historique des rapports dans `test_reports`.

## API

- `GET /api/projects/:id/gameplay-tests/status`
- `POST /api/projects/:id/gameplay-tests` avec `{ "viewport": "desktop" }` ou `{ "viewport": "mobile" }`, et optionnellement `entry`.
- `GET /api/projects/:id/gameplay-tests?limit=10`

## Activation

Le module nécessite Playwright et Chromium installés sur la machine qui héberge OPS. La dépendance est volontairement facultative : OPS continue de démarrer sans navigateur automatisé et indique clairement son indisponibilité. Installer Playwright/Chromium selon la documentation officielle Playwright pour la plateforme du serveur, puis redémarrer OPS.

L'option projet « Autoriser l'exécution de code » doit être activée. Le bouton demande une confirmation avant lancement. Le jeu est chargé dans un contexte Chromium éphémère ; les requêtes réseau vers les origines externes sont bloquées. Le serveur temporaire n'écoute que sur loopback, et ne sert que les fichiers du projet. Les téléchargements sont désactivés.

## Limites et sécurité

- Le code JavaScript du jeu est effectivement exécuté dans Chromium : n'activer l'autorisation que pour un projet de confiance.
- Cette isolation navigateur n'est pas une sandbox complète contre un projet malveillant ; OPS ne doit pas être exposé à des projets non fiables sur une machine sensible.
- Les tests n'effectuent pas de clics arbitraires, d'achats, de connexions ou d'actions destructrices.
- Une page d'entrée et une scène sont testées par exécution ; les interactions de gameplay, performances GPU, qualité artistique et compatibilité réelle sur téléphone ne sont pas garanties.
- Les ressources externes sont bloquées. Les projets dépendant de CDN ou de services externes peuvent donc ne pas démarrer comme en production.
- Les rapports distinguent les observations du navigateur des hypothèses ; le résultat n'est pas une certification de qualité.

### Installation facultative sur un serveur compatible

Depuis le dossier OPS, sur une machine compatible avec Chromium :

```bash
npm install --save-dev playwright
npx playwright install chromium
```

Puis redémarrer OPS et ouvrir Centre de tests. Sur Android/Termux, l'installation de Chromium via Playwright peut ne pas être prise en charge selon l'appareil et l'environnement ; le reste d'OPS fonctionne sans ce composant.
