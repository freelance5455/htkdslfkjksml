# OPS MASTER AI NEURAL V3.30 — Operational Readiness

## Objectif
V3.30 ajoute un diagnostic global vérifiable afin de distinguer le code raccordé des services qui nécessitent une configuration externe. Il ne contourne aucune sécurité et n'invente aucune disponibilité.

## API
`GET /api/system/readiness` retourne l'état global.
`GET /api/system/readiness?project_id=<id>` ajoute l'état des autorisations d'exécution et des moteurs enregistrés du projet.

États :
- `ready` : raccordement/configuration locale présents ; un test de connexion externe peut encore être requis.
- `warning` : composant présent mais configuration ou vérification supplémentaire nécessaire.
- `blocked` : prérequis absent, par exemple aucun fournisseur actif.
- `disabled` : agent désactivé.

Le rapport inclut les 13 spécialistes du Director, les agents développeurs, les fournisseurs utilisables, les moteurs externes, la recherche Web et l'autorisation d'exécution du projet.

## Interface
Un écran « État opérationnel » est disponible dans la navigation. Il actualise les contrôles et présente les actions de configuration à effectuer.

## Sécurité et limites
- Aucune clé API n'est affichée.
- Aucune connexion externe n'est déclenchée automatiquement par le diagnostic ; utiliser le test de connexion du fournisseur ou du moteur.
- `allow_exec` reste désactivé par défaut et doit être autorisé explicitement pour un projet de confiance.
- Les dépendances optionnelles (ex. navigateur automatisé) restent soumises à leur installation et à leur configuration.
- Un état prêt décrit les prérequis observés, pas une garantie de qualité des sorties du modèle.
