# OPS AI STUDIO COLLABORATION — V3.21

## Objectif
Renforcer la collaboration opérationnelle entre agents : transmissions persistantes, suivi de réception, partage du contexte et réservation exclusive des ressources de projet.

## Transmissions inter-IA
- `POST /api/projects/:id/collaboration/work` crée une transmission de `from` vers `to` avec titre, instruction et dépendances facultatives.
- `GET /api/projects/:id/collaboration/work?agent_id=npc&status=queued` consulte l'inbox d'un agent.
- `PATCH /api/collaboration/work/:id` permet aux agents concernés (ou à l'utilisateur via `agent_id: "user"`) de faire évoluer l'état.
- États : `queued`, `accepted`, `in_progress`, `review`, `done`, `blocked`, `cancelled`.
- Les transitions invalides sont refusées. Les événements de création et de statut sont conservés dans le bus de collaboration.
- Les `<ops-request>` produits pendant une tâche créent désormais une transmission persistante avant de planifier la tâche destinataire.

## Réservation des ressources
- `POST /api/projects/:id/collaboration/claims` réserve une liste de chemins relatifs pour un agent et une tâche.
- Une réservation active est exclusive au niveau `(project_id, path)` ; une tentative concurrente par un autre agent renvoie HTTP 409 et publie `artifact.conflict`.
- `POST /api/projects/:id/collaboration/claims/release` libère les réservations d'un agent, d'une tâche ou d'une liste de chemins.
- `GET /api/projects/:id/collaboration/claims` liste les réservations actives ; `?all=1` inclut l'historique.
- Les chemins absolus, chemins Windows et segments `.` / `..` sont refusés.

## Contexte agent
Le contexte de collaboration inclut les événements récents, les transmissions en attente destinées à l'agent et les ressources actuellement réservées. Les prompts rappellent de ne pas modifier une ressource détenue par un autre agent.

## Limites
La réservation de ressources est une coordination applicative, pas un verrou distribué pour les processus externes qui écrivent directement dans le workspace. Les agents doivent utiliser les API OPS et libérer les réservations après intégration ou revue. La qualité du travail produit dépend toujours des fournisseurs IA configurés.
