# OPS MASTER AI NEURAL V3.23 — AUTONOMOUS AI SUPERVISOR

## Ajout

La V3.23 ajoute `server/autonomous-supervisor.mjs` sans remplacer Project Manager AI, Director, Orchestrator ou Collaboration Bus.

### Fonctions
- Agrège les tâches de l'Orchestrator, du Director et les transmissions inter-agents.
- Détecte les tâches bloquées/en erreur, les tâches actives sans mise à jour depuis 20 minutes, les transmissions en attente et les réservations de fichiers.
- Compare les propositions de fichiers marquées `approved` avec l'arborescence réelle du workspace et signale les fichiers absents.
- Expose un rapport et un scan via `GET /api/projects/:id/supervisor` et `POST /api/projects/:id/supervisor/scan`.
- Ajoute un écran « Autonomous AI Supervisor ».
- En mode `assist`, crée au plus trois transmissions d'analyse par scan pour des tâches Orchestrator bloquées, vers un agent disponible différent, avec une fenêtre anti-répétition de 30 minutes.

### Garde-fous et limites
- Le mode par défaut est `observe` : aucune tâche ni fichier n'est modifié.
- Le mode `assist` ne réaffecte pas la tâche source et ne lance aucun script. Il crée uniquement une transmission tracée dans le bus OPS.
- Les escalades sont limitées à trois par scan et dédupliquées par tâche pendant 30 minutes.
- La disponibilité est calculée à partir des tâches enregistrées ; elle ne prouve pas qu'un processus externe est réellement vivant.
- Une proposition `approved` dont le chemin n'existe pas est signalée ; la présence d'un fichier ne garantit pas que son comportement est correct. Les tests et revues restent nécessaires.
- Le superviseur est déclenché par l'utilisateur via l'écran ou l'API ; aucun service périodique en arrière-plan n'est ajouté dans cette version.
- Le DAG des dépendances est observé, sans modification automatique de ses arêtes.
- Les fournisseurs IA externes ne sont pas réentraînés et leurs poids ne sont pas modifiés.

## API

- `GET /api/projects/:id/supervisor` : rapport de supervision.
- `POST /api/projects/:id/supervisor/scan` avec `{ "mode": "observe" }` : scan sans action.
- `POST /api/projects/:id/supervisor/scan` avec `{ "mode": "assist" }` : scan et escalades bornées.

## Stockage

La table `supervisor_actions` est ajoutée de façon additive pour conserver l'historique des scans et escalades. Les tables existantes et leurs données ne sont pas remplacées.
