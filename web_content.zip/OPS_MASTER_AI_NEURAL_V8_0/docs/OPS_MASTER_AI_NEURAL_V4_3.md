# OPS MASTER AI NEURAL V4.3 — Multi-Agent Intelligence

## Objectif
Renforcer le travail collaboratif des agents OPS et fiabiliser leur accès aux informations Internet sans prétendre entraîner les poids des modèles distants.

## Capacités
- Les 14 agents utilisent les outils communs `web_search` et `web_fetch` directement depuis leur boucle d'exécution.
- Tavily ou Brave est configuré dans Paramètres → Recherche Web. Les clés restent côté serveur et sont chiffrées dans les paramètres.
- Les agents doivent privilégier les documentations officielles, corroborer les décisions importantes, fournir les URLs et dates disponibles, et signaler les limites de recherche.
- Les résultats de recherche sont normalisés, dédupliqués, bornés à 10, mis en cache cinq minutes et les appels identiques simultanés sont mutualisés.
- Les erreurs réseau transitoires et réponses HTTP 429/5xx font l'objet de nouvelles tentatives bornées.
- Le téléchargement des pages publiques est plafonné à 1 Mo pendant la lecture du flux. La protection SSRF existante est conservée.
- Les livrables restent soumis aux circuits existants de propositions, sauvegardes, approbations, tests et revue qualité.

## Configuration nécessaire
1. Démarrer OPS sur Node.js >= 22.13.
2. Ajouter une clé Tavily ou Brave dans Paramètres → Recherche Web.
3. Vérifier le statut de la recherche Web dans le tableau de bord.
4. Ajouter et tester au moins un fournisseur IA dans Fournisseurs IA ; la recherche Web ne remplace pas les modèles de génération.
5. Affecter les agents au projet et utiliser le mode équipe pour les tâches multi-agents.

## Limites honnêtes
- Sans clé de recherche valide, aucun agent ne peut effectuer de recherche Internet via OPS.
- Sans fournisseur de modèle configuré, les agents ne génèrent pas de réponses IA.
- Le système améliore prompts, procédures, mémoire et vérification ; aucun fine-tuning des poids des modèles n'est effectué par cette version.
