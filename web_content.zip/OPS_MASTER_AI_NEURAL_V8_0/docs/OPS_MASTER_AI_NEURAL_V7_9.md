# OPS MASTER AI NEURAL V7.9 — Boucle de correction bornée

## Fonctionnement
- Une session Bug Fixer démarre au cycle 1 et conserve une sauvegarde de référence.
- Après la fin d'un cycle, l'utilisateur exécute un nouveau test et transmet un rapport échoué pour avancer.
- Chaque cycle suivant possède sa propre sauvegarde, son identifiant de rapport et son exécution IA.
- Maximum strict : 3 cycles par session. Aucun auto-rappel récursif ni boucle infinie.
- Un rapport réussi ne peut pas être utilisé pour continuer ; un rapport déjà consommé est refusé.
- Une régression bloquante de type fichier supprimé bloque le cycle suivant.
- Les tests ne sont pas lancés implicitement. Les commandes/scripts du projet conservent leurs autorisations existantes.

## API
- `POST /api/projects/:id/bug-fixes` démarre le cycle 1 avec `{ "report_id": "..." }`.
- `POST /api/bug-fixes/:id/advance` démarre le cycle suivant avec `{ "report_id": "nouveau-rapport-echoue" }`.
- `GET /api/bug-fixes/:id` expose `cycles`, `cycle_count`, `max_cycles` et `can_advance`.

## Limites
La réussite d'un cycle dépend du modèle fournisseur, de ses outils et des approbations du projet. Le moteur ne garantit pas qu'un défaut sera corrigé ; il exige un nouveau rapport réel avant chaque itération et conserve les limites d'exécution existantes.
