# OPS MASTER AI NEURAL V6.6

## Éditeur de sculpture

- Nouvel onglet `Éditeur de sculpture` dans MODELING AI.
- Sélection des modèles valides (les kits sont exclus).
- Aperçu du modèle et contrôles Inflate, Smooth, Flatten.
- Paramètres du pinceau : rayon, force et centre XYZ.
- Appel de l’API authentifiée `/api/modeling/assets/:id/sculpt`.
- Validation et recalcul des normales sur les trois LOD conservés par le moteur.

Limite : ce n’est pas encore un viewport WebGL interactif ni une peinture directe au stylet.
