# OPS RUNTIME QUALITY GATE — V3.10

## Objectif
Compléter les contrôles statiques du pipeline V3.9 par une étape facultative qui exécute réellement les scripts de test et de compilation du projet.

## Fonctionnement
1. Le pipeline atteint `ready_for_review` après la réussite de l'orchestration, des contrôles statiques et de la non-régression.
2. L'utilisateur déclenche explicitement **Exécuter les tests réels du projet** dans l'écran Production autonome.
3. L'interface demande une confirmation avant l'exécution.
4. Le serveur vérifie `allow_exec` sur le projet et lit les scripts disponibles dans `package.json`.
5. Les scripts présents parmi `test` et `build` sont exécutés séquentiellement par le centre de tests existant, dans son environnement épuré et avec ses limites de temps.
6. Le rapport de production enregistre le résultat, le code de sortie, le délai, l'expiration éventuelle et une sortie tronquée.
7. Une nouvelle version livrable est créée uniquement si tous les scripts disponibles réussissent. En cas d'échec, le pipeline passe à `quality_failed` et ne conserve pas de référence de livraison valide.

## API
- `POST /api/production/:id/execute-checks` — déclenche l'étape d'exécution après les contrôles statiques.

## Sécurité
- `allow_exec` doit être activé explicitement dans les paramètres du projet.
- L'interface demande une confirmation avant l'appel.
- Seuls les scripts `test` et `build` déclarés dans `package.json` sont lancés.
- Le centre de tests existant conserve ses limites de temps, son environnement sans clés API et ses sauvegardes avant exécution.
- Aucun script n'est lancé automatiquement à la fin d'une production.

## Limites
- L'exécution réelle dépend de Node/npm, des dépendances déjà présentes et de l'environnement serveur.
- La réussite de `npm test` et `npm run build` ne prouve pas à elle seule que le jeu fonctionne correctement dans un navigateur, sur Android ou dans un moteur 3D natif.
- Une revue humaine reste requise avant publication.
