# OPS MASTER AI NEURAL V7.2 — Bibliothèque de matériaux

## Fonctionnalités
- Six presets de prévisualisation : béton mat, métal peint, métal poli, bois verni, caoutchouc et pierre.
- Application immédiate au modèle sélectionné dans le viewport.
- Enregistrement et suppression de presets personnalisés dans le stockage local du navigateur, isolé par projet.
- Paramètres sauvegardés : ambiance studio, lumière ambiante, lumière principale, ajustement de rugosité et renfort métallique.

## Sécurité et limites
- Les presets sont des overrides d’aperçu non destructifs. Les fichiers glTF et PNG PBR d’origine ne sont pas modifiés.
- Les presets personnalisés restent sur le navigateur/appareil qui les a créés ; ils ne sont pas synchronisés entre appareils.
- Pas encore d’écriture de matériaux dans le glTF, de peinture UV, de nodes shader avancés ou de rendu HDRI/IBL.
