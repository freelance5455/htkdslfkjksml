# OPS AI INTELLIGENCE & SKILLS EVOLUTION — V3.27

## Objectif
Améliorer les agents existants par une couche de contexte spécialisée, additive et indépendante du fournisseur IA.

## Architecture
- `server/agent-intelligence.mjs` définit les profils, compétences prioritaires, méthodes métier et cycle de travail commun.
- `server/agents.mjs` injecte cette couche dans `systemPromptFor`.
- Les instructions personnalisées des agents, le protocole OPS, les améliorations métier et le curriculum CODER sont conservés.
- `tests/agent-intelligence.test.mjs` vérifie les 14 profils, l'injection dans les prompts et le comportement de repli.

## Méthode commune
1. Comprendre l'objectif, les contraintes et les critères.
2. Observer les fichiers, données et outils disponibles.
3. Décider en séparant faits, hypothèses et choix.
4. Produire le livrable du domaine et collaborer avec les autres agents.
5. Vérifier le résultat, les limites et les cas limites.
6. Rendre compte avec preuves et dépendances restantes.

## Limites
Cette couche améliore les consignes et le contexte envoyés aux modèles. Elle n'entraîne pas les poids des modèles, n'ajoute pas de capacité à un fournisseur qui ne la possède pas et ne garantit pas à elle seule une meilleure qualité. Les fournisseurs configurés, leurs modèles et leurs limites restent déterminants.
