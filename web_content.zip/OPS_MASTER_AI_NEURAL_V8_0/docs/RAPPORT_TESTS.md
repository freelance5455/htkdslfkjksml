# Rapport de tests — OPS MASTER AI CHAT V2.0

Mise à jour : 26 tests, dont la bibliothèque (isolation, import annulable, téléchargement, suppression). Première exécution : `npm test` (Node v22.23.4), 2026-11-15. Le fournisseur IA des tests est une **fixture locale** (tests/stub-provider.mjs) qui imite le protocole OpenAI : elle valide l'orchestration, pas la qualité de vrais modèles.

```
ok 1 - authentification : jeton requis, santé publique
ok 2 - WebSocket : refusé sans jeton, hello avec jeton, diffusion des événements
ok 3 - WebSocket : encodage/décodage de trames (masquées, 126 et 64 bits)
ok 4 - clés API : chiffrées au repos, jamais renvoyées
ok 5 - SSRF : adresses privées refusées, recherche non configurée honnête
ok 6 - fichiers : traversée de chemin et liens symboliques refusés, isolation entre projets
ok 7 - sauvegarde avant modification, annulation, suppression confirmée
ok 8 - versions : restauration avec sauvegarde de sécurité, diff, non-régression
ok 9 - export ZIP valide
ok 10 - centre de tests : erreurs de syntaxe JS/JSON/HTML détectées, exécution de code refusée par défaut
ok 11 - exécution npm test (après autorisation explicite) : env épuré sans clé API
ok 12 - fournisseur : test de connexion, erreur d'authentification classée, liste de modèles
ok 13 - fournisseur : retry sur 429, budget quotidien appliqué
ok 14 - les 11 agents sont créés avec leur spécialité
ok 15 - sans fournisseur configuré : échec explicite, aucune réponse simulée
ok 16 - mode équipe : plan, parallélisme, dépendances, relecture, conflit détecté puis fusionné, autorisations
ok 17 - relecture qualité : problème signalé → correction par l'agent fautif
ok 18 - plan IA invalide → repli par règles, signalé explicitement
ok 19 - mode direct : un agent, outils de lecture, isolation des projets
ok 20 - mode auto : application avec sauvegarde préalable ; suppression jamais automatique
ok 21 - annulation d'une exécution en cours
ok 22 - reprise : tâches en erreur relancées après correction du fournisseur
ok 23 - rapport d'avancement : alertes factuelles
ok 24 - parseAgentOutput / validatePlan / rulePlan
ok 25 - import du projet V3.8 fourni (seed) : préservé et versionné
# tests 25
# pass 25
# fail 0
# duration_ms 8824.467224
```

## Vérifications complémentaires (manuelles, Playwright + Chromium)
- Parcours UI complet sur la fixture : connexion, chat en mode équipe avec suivi en direct, rapport, écran Développement (diff, approbation → fichier réellement écrit), 11 écrans sans erreur console.
- Mobile 390 px : aucun débordement horizontal sur les 11 écrans.
- Bogues trouvés et corrigés pendant les tests : résultats des dépendances non transmis aux agents ; textes « null/false » parasites ; débordement mobile ; diff de nouveau fichier.

## Non testé / limites
- Aucun vrai fournisseur IA (OpenAI, Anthropic, Gemini) ni Tavily/Brave : pas de clé ni d'accès réseau ici. Les adaptateurs suivent les API documentées mais n'ont pas été appelés en réel.
- Adaptateur PostgreSQL non testé.
- Application Android native (V6) non réalisée ; PWA non testée sur un appareil.
- Lecture de pages Web externes non testée (seule la protection SSRF l'est).

## Étape 1 — OPS DIRECTOR AI
`tests/director.test.mjs` (10 tests) : roster et validation, états/chemin critique/cycles, plan « ville », cycle de vie et transmissions, progression, exécution sans/avec fournisseur (fixture), plan IA valide/invalide, messagerie/mémoire/contexte, moteurs (HTTP vrai serveur local + dossier), échange (aller-retour, dry-run, conflits, intégrité, chemins piégés, zip-bomb). Total : voir `npm test`.
Parcours navigateur (Playwright) : création de plan, exécution de la tâche du Director, affichage « IA non construite », 6 onglets, mobile 390 px sans débordement.
Non testé : moteurs OPS réels (aucun disponible ici) ; Director avec un vrai modèle.

Conversation directe : 2 tests (réponse réelle + historique + contexte, refus IA non construite/sans fournisseur, actions réelles, échecs rapportés, limite de 5). Total actuel : 38 tests, 0 échec. Navigateur : chat Director PC + mobile sans erreur ni débordement.


## Étape 3 — OPS WORLD AI
`tests/world.test.mjs` (11 tests) : déterminisme, validité sur 90 combinaisons (taille × eau × thème × graine), paramètres invalides, budget mobile, détection réelle des défauts par `validateWorld` (chevauchement, route, hors carte, bâtiment isolé, pont sans eau, budget, dimensions), exports OBJ/SVG/JSON, API (fichiers proposés puis approuvés, téléchargements authentifiés, mode auto + sauvegarde, chemins sûrs), brief→paramètres (sortie invalide/sans fournisseur → 502, rien créé), chat (actions réelles, échecs, limite 2), intégration Director↔WORLD (exécution, contexte transmis, messages lus, handoff en file vers MODELING, échec → tâche rouverte).
Total actuel : **49 tests, 0 échec**. Navigateur (Playwright) : écran WORLD AI sur PC et mobile, génération, aperçu SVG, chat, sans erreur console ni débordement horizontal. Bogues trouvés et corrigés : validation des ponts (test sur voisins au lieu du terrain sous le pont, 26/180 faux échecs) ; rafraîchissement WebSocket qui effaçait le formulaire.
Non testé : vrai fournisseur IA, import dans un moteur de jeu.


## Étape 4 — OPS MODELING AI
`tests/modeling.test.mjs` (12 tests) : déterminisme ; 15 types × 8 styles × gabarits valides (480 assets) ; refus honnête des gabarits hors budget ; paramètres invalides ; collisions ; **validateAsset détecte réellement** faces inversées, normales, triangles dégénérés, indices, matériau, UV/positions, LOD, base, collision, nom, budgets ; **glTF relu par un lecteur indépendant** (tampon, alignement, accessors, min/max exacts, indices) ; OBJ/MTL/SVG ; kit sur 3 mondes (≤ 48 archétypes, échelles dans [0,7 ; 1,4], monuments non fusionnés, un placement par bâtiment, positions/rotations identiques au monde) ; API (approbations, mode auto, téléchargements en liste blanche, authentification) ; brief → plan (sortie invalide, sans monde, sans fournisseur) ; chat (actions réelles, échecs, limite 2) ; collaboration Director → WORLD → MODELING (le kit utilise le monde produit, messages remis, handoff en file vers GRAPHICS, échec honnête sans monde).
Total actuel : **61 tests, 0 échec**. Navigateur (Playwright) : écran MODELING AI sur PC et mobile, génération d'un modèle et d'un kit, aperçu, chat, sans erreur console ni débordement. Bogues trouvés par les contrôles et corrigés : LOD non décroissants sur les props et petits bâtiments ; noms de fichiers non assainis ; échelles de kit hors limites avec la quantification fixe (remplacée par une fusion à erreur bornée) ; hauteurs d'étage divergentes entre WORLD et MODELING.
Non testé : vrai fournisseur IA, import dans un moteur, validateur glTF officiel.

## OPS MASTER AI NEURAL V2.3 — extension du studio AAA

- Suite complète exécutée avec `npm test` : **65 tests réussis, 0 échec**.
- Les 11 entrées du studio sont initialisées comme construites ; les anciennes entrées `planned` sont migrées au démarrage.
- Chaque spécialiste AAA possède un prompt métier distinct.
- Le graphe du Director peut exécuter les tâches des 11 spécialistes ; WORLD et MODELING conservent leurs pipelines dédiés.
- Chat direct ajouté pour les spécialistes ANIMATION, NPC, PHYSICS, VEHICLE, GAMEPLAY, GRAPHICS, STORY et QA.
- Interface Studio mise à jour : accès aux chats des spécialistes et bouton d'exécution pour toute tâche prête.
- Vérifications syntaxiques `node --check` effectuées sur les modules serveur et l'interface.
- Limite : les réponses réelles nécessitent un fournisseur IA configuré ; aucun test navigateur/WebGL n'est revendiqué.


## OPS MASTER AI NEURAL V2.4 — développement neuronal majeur

- Ajout de l'analyse préalable déterministe des demandes et des domaines spécialisés recommandés.
- Détection des risques de préservation, sécurité, performance mobile/3D et réseau.
- Injection du profil neuronal dans le plan du coordinateur et le contexte de chaque spécialiste.
- Ajout du OPS NEURAL QUALITY GATE dans le rapport final.
- Extension de 7 à 14 modules neuronaux documentés.
- Tests spécifiques : routage des domaines AAA, risques de préservation et score de couverture.
- Limite : aucune modification des poids des modèles ni apprentissage autonome ; les réponses génératives dépendent toujours des fournisseurs configurés.


## OPS MASTER AI NEURAL V2.5 — qualité détaillée et assistance centrale
- Contrat commun de détail et exigences métier propres aux 11 rôles du studio.
- Auto-relecture demandée à chaque spécialiste avant livraison.
- Assistance du coordinateur central lorsqu'un spécialiste dépasse le délai initial de 45 secondes ; reprise par le spécialiste avec l'aide reçue.
- Revue qualité élargie à la profondeur des livrables, aux cas limites, à la finition et aux critères d'acceptation.
- Cycles de correction configurables jusqu'à 5, 4 par défaut.
- Test unitaire ajouté pour vérifier la présence des exigences détaillées de chaque spécialité.
