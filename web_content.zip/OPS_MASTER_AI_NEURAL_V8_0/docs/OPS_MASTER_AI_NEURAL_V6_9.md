# OPS MASTER AI NEURAL V6.9

## Sculpture tactile par surface

La V6.9 remplace la sélection du sommet projeté le plus proche par un picking de surface : les triangles du LOD affiché sont projetés dans le viewport, les coordonnées barycentriques déterminent le point d'intersection écran et la profondeur choisit la surface la plus proche de la caméra. Le point obtenu est reconverti dans les coordonnées du modèle en mètres.

Le mode tactile permet aussi de tracer un trait sur la surface. Les points sont échantillonnés avec un espacement minimal, puis envoyés en une opération groupée de 32 points maximum. Le serveur existant applique les opérations et conserve la validation/reconstruction des normales et LOD. Les gestes à deux doigts restent réservés au zoom.

Limites : le picking est calculé en JavaScript sur les triangles CPU du LOD0 ; les très gros maillages peuvent réduire la fluidité. Un trait est limité à 32 points par envoi. La peinture des textures PBR dans le viewport, l'édition des UV et le sculpting GPU temps réel ne sont pas inclus. Le test sur appareils Android physiques reste nécessaire.
