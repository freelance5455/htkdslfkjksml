# OPS MASTER AI NEURAL V5.3

## Récupération automatique après redémarrage

La V5.3 ajoute une récupération des plans d'orchestration qui étaient encore actifs lorsque le serveur s'est arrêté.

### Comportement

1. Au démarrage, OPS réconcilie les tâches `starting` et `executing` avec les runs persistés.
2. Une tâche interrompue est remise en file uniquement si l'erreur est récupérable et si elle dispose encore d'un essai (deux tentatives maximum au total).
3. Les tâches en revue et les approbations en attente restent en attente.
4. Les refus, erreurs d'authentification, clés absentes, fournisseurs non configurés et problèmes de quota ne sont pas relancés automatiquement.
5. Les dépendances ne sont libérées qu'après validation effective du résultat.

### Limites

- La reprise concerne les plans d'orchestration persistés.
- Les exécutions qui dépendent d'un fournisseur externe restent soumises à sa disponibilité et à ses quotas.
- Les scripts du projet ne sont jamais lancés automatiquement par cette récupération.
