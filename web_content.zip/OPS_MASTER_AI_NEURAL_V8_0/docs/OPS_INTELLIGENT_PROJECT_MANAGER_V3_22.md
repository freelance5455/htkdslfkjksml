# OPS INTELLIGENT PROJECT MANAGER — V3.22

## Objectif

Ajouter un tableau de pilotage de projet qui agrège les tâches de l'orchestrateur, du Director et du bus de collaboration, puis signale les blocages, les tâches anciennes, la charge des agents et les fichiers réservés.

## Capacités

- Rapport projet `ops.project-manager.v1` via `GET /api/projects/:id/manager`.
- Vue graphique « Project Manager AI » dans la navigation OPS.
- Indicateurs : tâches totales/terminées/actives/en attente/bloquées/anciennes et réservations actives.
- Détection des tâches `running` ou `in_progress` sans mise à jour depuis 20 minutes (seuil de calcul configurable dans la fonction pure).
- Recommandations déterministes pour tâches bloquées, tâches anciennes et réservations actives.
- Charge des agents et liste des agents activés sans tâche active connue.
- Affichage des dépendances entre moteurs et de la file de travail.
- Transmission manuelle et explicite d'une tâche à un agent disponible via `POST /api/projects/:id/manager/dispatch`.

## Sécurité et limites

- Aucune tâche n'est lancée automatiquement en arrière-plan par le tableau de bord.
- La transmission crée un élément du bus de collaboration ; l'agent destinataire doit ensuite le traiter dans le flux OPS existant.
- Une transmission est refusée si l'agent est désactivé ou déjà occupé selon les tâches observées.
- Le rapport est une photographie des données enregistrées ; il ne prouve pas à lui seul qu'un processus externe est encore vivant.
- Les priorités sont proposées et affichées, pas réécrites automatiquement dans les plans du Director.

## Tests

`npm test` inclut `tests/project-manager.test.mjs` : agrégation des états, détection de tâche ancienne/bloquée, réservations, disponibilité et API de rapport/transmission.
