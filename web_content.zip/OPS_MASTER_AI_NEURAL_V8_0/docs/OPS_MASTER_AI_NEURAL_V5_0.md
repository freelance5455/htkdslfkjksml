# OPS MASTER AI NEURAL V5.0 — Release Gate & livraison contrôlée

## Objectif
Ajouter un contrôle de préparation à la livraison qui rassemble les preuves existantes sans exécuter arbitrairement les scripts d'un projet.

## Nouveau module
`server/release-gate.mjs` expose `createReleaseGate(ctx)` et `buildReleaseGate(...)`.

Endpoint authentifié :

`GET /api/projects/:id/release-gate`

Le rapport combine :
- existence du projet et détection des points d'entrée HTML/JavaScript ;
- lecture et validation syntaxique du `package.json` lorsqu'il existe ;
- présence déclarative d'une commande `test`, `check` ou `lint` ;
- anomalies critiques et avertissements connus du superviseur ;
- nombre de tâches réellement enregistrées dans les benchmarks ;
- état opérationnel déclaré par le module Readiness.

## États
- `blocked` : au moins un critère bloquant est détecté.
- `review` : il manque des preuves ou des vérifications doivent être faites.
- `candidate` : aucun blocage ni élément de revue détecté ; cela ne vaut pas certification de publication.

## Sécurité et limites
- Le Release Gate est en lecture seule.
- Il n'exécute aucun script ni code du workspace.
- Une commande de test déclarée n'est pas considérée comme exécutée.
- Une candidature doit encore être vérifiée fonctionnellement, visuellement, sur mobile/PC et dans les conditions de déploiement réelles.
- Les agents IA nécessitent toujours des fournisseurs configurés et testés ; la recherche Internet nécessite Tavily ou Brave.

## Vérification V5.0
- `npm test` : 162 tests réussis.
- `npm run doctor` : 6 contrôles OK, 0 alerte, 0 erreur.
- 76 fichiers JavaScript analysés par le Doctor, sans erreur de syntaxe.
