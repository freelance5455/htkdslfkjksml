# OPS MASTER AI NEURAL V6.8

## Sélection tactile de sommets dans le viewport

La V6.8 ajoute un mode tactile de sélection de sommet dans l'éditeur de sculpture WebGL 2.

- Le mode est activable séparément de la rotation du viewport.
- Un tap dans le canvas recherche le sommet dont la projection écran est la plus proche dans une tolérance de 22 pixels CSS.
- La position du sommet, normalisée pour le rendu, est reconvertie en coordonnées du modèle en mètres.
- Les champs Centre X/Y/Z sont mis à jour et l'utilisateur peut appliquer Inflate, Smooth ou Flatten via l'API de sculpture existante.
- Le rendu et la rotation restent indépendants du traitement géométrique serveur.

## Limites explicites

La sélection est fondée sur la proximité écran et ne fait pas encore de test de visibilité par rayon : un sommet situé derrière la surface peut parfois être sélectionné. Le pinceau n'est pas encore appliqué en continu pendant un glissement tactile. La validation finale, le recalcul des normales et la mise à jour des trois LOD restent effectués par le serveur.

## Vérifications effectuées

- `node --check public/app.js`
- `node --check server/config.mjs`
- Tests ciblés : modeling, sculpting, UI de manifeste et doctor.
