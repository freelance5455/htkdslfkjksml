# OPS CODER AI — curriculum avancé V3.3

## Niveau ajouté
Le curriculum V3.3 étend les règles de base avec 12 compétences avancées : traçabilité des exigences, cartographie d’impact, vérification des API réelles, changements réversibles, déterminisme, observabilité, budgets de performance, intégrité des données, résilience aux pannes, revue indépendante, accessibilité/UX et livraison reproductible.

## Injection et évaluation
`buildCoderTrainingContext()` injecte les leçons et cas contrastifs à chaque requête de OPS CODER AI. `evaluateCoderAdvancedEvidence()` évalue séparément 12 preuves avancées. Les preuves doivent être fournies par le processus de travail ; le score ne prouve pas à lui seul que le code est correct.

## Collaboration
CODER doit demander une revue indépendante à DEBUG et QUALITY pour les changements importants, partager les contrats avec les moteurs concernés et intégrer les retours avant la livraison.

## Limites honnêtes
Il s’agit d’un apprentissage contextuel logiciel : curriculum, exemples et évaluateur. Aucun poids du modèle fournisseur n’est modifié. Un fine-tuning réel exige un modèle entraînable, des données autorisées et nettoyées, des ressources GPU, une validation indépendante et une gestion des versions.
