# OPS CODER AI — Autonomous Game Build V3.4

## Objectif
Permettre à OPS CODER AI de construire un nouveau jeu dans un workspace vide ou existant, au lieu de produire uniquement des recommandations.

## Pipeline
1. Détection des demandes explicites de création d'un nouveau jeu.
2. Travail parallèle des spécialistes disponibles : architecture, moteur/rendu, gameplay, PNJ, physique, environnement/ressources et animation.
3. Transmission des résultats de spécialistes à la tâche finale CODER via les dépendances du graphe.
4. CODER écrit les fichiers complets, choisit/inspecte la technologie, construit un point d'entrée réel et assemble une version jouable.
5. Contrôle qualité OPS QUALITY TEAM et propositions de fichiers selon le mode d'écriture du projet.

## Critères de livraison CODER
- Démarrage réel depuis le point d'entrée.
- Boucle de jeu et contrôles fonctionnels.
- Mécaniques principales réellement jouables.
- Interface/HUD, pause/reprise et fin/recommencer selon le genre.
- Interactions/collisions adaptées au jeu.
- Contrôles tactiles si jeu navigateur mobile.
- Aucun asset référencé sans fichier correspondant ; procédural ou placeholder explicite si nécessaire.
- README et tests adaptés.
- Déclaration honnête des limites et validations non exécutées.

## Limites
OPS orchestre les modèles fournisseurs configurés et leurs sorties. Cette évolution ne réalise pas de fine-tuning des poids. La création de fichiers et leur application restent soumises au mode d'écriture du projet ; les tests locaux ne remplacent pas une validation sur appareil réel.
