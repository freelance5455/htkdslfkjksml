# OPS MASTER AI NEURAL V3.18 — Autonomous Game Production

## Objectif
Renforcer le pipeline de production autonome en rendant sa progression observable et en ajoutant des contrôles d'intégration/non-régression à la validation du livrable.

## Nouveautés
- Progression de pipeline exposée dans `GET /api/production/:id` : étapes, statut, pourcentage et compteurs de tâches.
- Sept étapes lisibles : cadrage, architecture, spécialistes, implémentation/assemblage, revue, qualité, livraison.
- Inspection des références locales JavaScript/TypeScript/Vue/Svelte et HTML avec le graphe d'artefacts existant.
- Contrôle de non-régression par comparaison avec la version de référence créée au démarrage.
- Le livrable `ready_for_review` n'est créé que si les contrôles statiques ET le contrôle de non-régression passent.
- Les références locales non résolues sont ajoutées au rapport comme avertissements ; elles ne bloquent pas seules le livrable afin d'éviter les faux positifs.
- Les suppressions de fichiers présents dans la version de référence bloquent la validation finale.

## API
- `POST /api/projects/:id/production` démarre la production et crée la sauvegarde de référence.
- `GET /api/production/:id` retourne désormais `progress`, `run`, `checks` et l'état de production.
- `GET /api/projects/:id/production` liste les pipelines.
- `POST /api/production/:id/execute-checks` conserve l'exécution explicite des scripts `test`/`build`, soumise à `allow_exec`.

## Limites
Le pipeline coordonne les agents et les livrables fournis par le modèle configuré. Cette version ne prétend pas créer automatiquement des ressources 3D natives, exécuter tous les moteurs de jeu, ni garantir une qualité AAA. Les avertissements de graphe sont statiques et ne remplacent pas un lancement réel du jeu. Les suppressions intentionnelles nécessitent encore une gestion explicite adaptée avant livraison.
