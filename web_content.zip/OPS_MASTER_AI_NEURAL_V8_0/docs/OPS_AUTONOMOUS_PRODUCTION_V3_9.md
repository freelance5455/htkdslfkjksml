# OPS AUTONOMOUS PRODUCTION PIPELINE — V3.9

## But
Ajouter une chaîne de production de jeu suivie, sans remplacer les moteurs ou workflows de la V3.8.

## Fonctionnement
1. L'utilisateur fournit un cahier des charges et des contraintes.
2. OPS crée une version de référence du workspace avant le lancement.
3. OPS lance une exécution d'équipe via l'orchestrateur existant. Le brief exige analyse, contrats entre moteurs, tâches spécialistes, implémentation/assemblage par OPS CODER AI, relecture et rapport.
4. L'utilisateur suit l'exécution via l'identifiant du pipeline et l'identifiant du run.
5. À la fin d'un run réussi, OPS exécute le centre de contrôles existant. Une version de livraison n'est créée que si les contrôles et la non-régression passent.
6. Si le run échoue ou si les contrôles échouent, le pipeline le signale et ne publie pas de version livrable.

## API
- `POST /api/projects/:id/production` — démarre une production (`title`, `brief`, `constraints`).
- `GET /api/projects/:id/production` — liste les pipelines du projet.
- `GET /api/production/:id` — récupère le pipeline et actualise son état ; déclenche la validation finale lorsqu'un run est terminé.

## Statuts
`running`, `awaiting_approval`, `ready_for_review`, `quality_failed`, `partial`, `development_failed`.
Les pipelines en `awaiting_approval` attendent la décision sur les propositions des agents ; les contrôles finaux ne démarrent qu’après résolution de ces propositions. Une proposition refusée empêche la création d’une version livrable automatique.
`ready_for_review` signifie que les contrôles automatisés sont passés ; une revue humaine reste nécessaire.

## Sécurité et limites
- Le pipeline ne contourne pas le mode d'approbation du workspace : les propositions de fichiers restent dans le circuit existant.
- Il n'exécute pas arbitrairement le code généré. Les contrôles existants analysent la syntaxe et la non-régression ; les scripts npm restent soumis à l'autorisation explicite du projet.
- Il ne garantit pas qu'un jeu complet est produit : le résultat dépend des fournisseurs IA configurés, des agents activés et des fichiers réellement proposés puis approuvés.
- La version livrable n'est créée qu'après un run `done` et des contrôles réussis.
- Cette évolution n'effectue pas de fine-tuning des poids des modèles externes.
