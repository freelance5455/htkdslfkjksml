# OPS MASTER AI NEURAL V7.4 — Missions autonomes multi-agents

La V7.4 ajoute un lancement d'objectif depuis OPS Autonomous AI Supervisor.

## Fonctionnement
- L'utilisateur formule un objectif global une seule fois.
- OPS DIRECTOR AI crée un plan de production multi-agents à partir du roster spécialisé configuré.
- Le plan est converti en tâches du moteur d'orchestration avec les dépendances conservées.
- Le moteur lance les agents configurés, transmet les résultats validés aux tâches dépendantes et journalise l'exécution.
- Le tableau de bord conserve la visibilité sur les tâches, résultats, erreurs et approbations.

## Sécurité et limites
- Les tâches existantes ne sont pas réaffectées par cette fonction.
- Les écritures restent soumises au mode d'approbation du projet.
- Les commandes système ne sont pas lancées automatiquement.
- Les agents dépendent des fournisseurs, modèles et clés API réellement configurés.
- La fonction ne modifie pas les poids des modèles ; elle automatise la planification et l'orchestration.
- Les scans du superviseur restent en observation/assistance ; cette fonction distincte démarre un plan uniquement après action explicite de l'utilisateur.

## API
`POST /api/projects/:id/supervisor/objective`

Corps : `{ "objective": "...", "title": "...", "autoStart": true }`

Retourne le plan Director, le plan d'exécution et les garde-fous appliqués.
