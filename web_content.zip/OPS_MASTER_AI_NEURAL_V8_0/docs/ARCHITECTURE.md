# Architecture

```
public/ (SPA + PWA) ──REST/WS──> server/app.mjs
  providers.mjs  adaptateurs openai | anthropic | gemini (retry, budget, usage)
  orchestrator.mjs  plan → graphe de tâches → exécution parallèle → relecture → corrections → fusion
  agents.mjs     11 agents développeurs + protocole OPS commun
  workspace.mjs  projets isolés, fichiers sandboxés, versions, annulation, non-régression
  testing.mjs    vérifications + npm test/build (autorisation)
  automation.mjs avancement, blocages, suggestions
  web.mjs        recherche Tavily/Brave, lecture de docs (anti-SSRF)
  db.mjs         SQLite (node:sqlite) | PostgreSQL (pg)      ws.mjs  WebSocket RFC 6455
```
## Protocole inter-IA
Chaque agent reçoit : projet, demande globale, sa sous-tâche, résultats des agents dont il dépend, mémoire partagée, arborescence. Il répond en texte avec des balises : `<ops-tool>` (lire fichiers, recherche Web), `<ops-file>` (livrer un fichier), `<ops-delete>`, `<ops-memory>`, `<ops-request agent="…">` (demander un travail/correction à un autre agent). Indépendant du fournisseur.
## Collaboration
1. Le coordinateur produit un plan JSON validé (agents autorisés, dépendances, pas de cycle) ; sinon repli par règles, signalé.
2. Tâches sans dépendance en parallèle (réglage « agents en parallèle »), 2 essais par tâche.
3. Relecture : détection automatique de deux versions différentes d'un même fichier + relecture OPS QUALITY ; chaque problème devient une tâche de correction pour l'agent fautif ; la correction remplace les propositions conflictuelles.
4. Le coordinateur fusionne en rapport ; les fichiers restent « en attente » (ou sont appliqués sans conflit en mode Auto, après sauvegarde).
## Données
Tables : providers, projects, agents, runs, tasks, messages, memory, journal, approvals, versions, changes, usage, test_reports, settings. Identifiants texte (portable SQLite/PostgreSQL).

## Bibliothèque de fichiers (`server/library.mjs`)
Blobs dans `data/library/<id>.bin`, métadonnées dans `library_items`. Portée : *global* (partagé volontairement) ou *projet* (invisible et non importable ailleurs : 403). Import vers un projet = `writeFile` (sauvegarde, journal, annulation). Téléchargement toujours en `attachment` + CSP `sandbox` (un HTML stocké ne s'exécute jamais). Suppression : confirmation + copie dans `data/library/trash`. Agents : outils `library_search` / `library_read` (texte seulement, limités au projet + global). Limite 8 Mo/fichier.

## Orchestration multi-IA V3.25

`server/orchestration-engine.mjs` est un module additif au-dessus du bus de collaboration. Il persiste des plans et tâches, vérifie le DAG, distribue les tâches prêtes et synchronise les états des work items avant de libérer les dépendances. Il n'exécute pas directement les agents et n'autorise aucun script.

## Exécution autonome multi-IA V3.26

Le moteur V3.26 utilise le runtime existant `orchestrator.start` pour les agents de développement et `director.executeStandaloneTask` pour les IA du Studio. Les tâches dépendantes ne démarrent qu'après un résultat réel enregistré ; les propositions de fichiers restent en revue jusqu'à approbation et vérification dans le workspace. L'interface et l'API permettent démarrage, pause, reprise et relance ciblée. Le moteur n'exécute aucun script de projet et n'ignore pas `allow_exec`.
