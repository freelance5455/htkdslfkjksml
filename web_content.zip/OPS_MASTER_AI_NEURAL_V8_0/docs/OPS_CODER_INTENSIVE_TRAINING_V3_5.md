# OPS CODER AI — Entraînement intensif V3.5

## Objectif
Renforcer la capacité de CODER à construire un jeu complet depuis un workspace vide ou à étendre un jeu existant sans régression.

## Parcours intensif
24 domaines couvrent game design, boucle de jeu, architecture de scène, commandes clavier/manette/tactile, caméra, collisions et physique, IA des PNJ, navigation, streaming du monde, rendu, pipeline d'assets, animation, audio, sauvegarde, missions, HUD, optimisation Android et PC, réseau, tests de gameplay, packaging, accessibilité, production de contenu et non-régression.

## Études de cas
Huit scénarios illustrent les méthodes attendues : jeu 3D vide, monde ouvert, PNJ autonomes, véhicules, Android, diagnostic de démarrage, amélioration graphique et livraison complète.

## Évaluation
`evaluateCoderIntensiveEvidence()` mesure 16 catégories de preuves. Le score est une grille de contrôle documentaire et ne garantit pas la correction du jeu. Chaque critère doit être coché seulement après observation d'une preuve ou exécution réelle.

## Limites honnêtes
Le curriculum est injecté dans le prompt à chaque requête. Il s'agit d'un entraînement contextuel logiciel : aucun poids de modèle externe n'est modifié. La qualité finale dépend du fournisseur configuré, des outils disponibles, du projet et des tests effectivement exécutés.
