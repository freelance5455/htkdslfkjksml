# OPS MASTER AI NEURAL V4.0 — Notes de version

## Objectif de cette première livraison
Renforcer la fiabilité et la maintenabilité de la base V3.30 sans remplacer ses moteurs existants.

## Changements livrés
- Version du package et version serveur alignées sur `4.1.0`.
- Ajout de `scripts/doctor.mjs`, un diagnostic local en lecture seule.
- Vérification du JSON de configuration et du manifeste PWA.
- Vérification de cohérence de version et du minimum Node déclaré.
- Contrôle syntaxique des fichiers JavaScript avec `node --check`.
- Vérification des références locales de l'interface principale.
- Ajout de tests automatisés dédiés au diagnostic.
- Aucun fournisseur IA, aucune clé API et aucun service externe requis pour lancer le diagnostic.

## Commandes
- `npm test` : suite de non-régression.
- `npm run doctor` : audit technique local.
- `npm start` : démarrage du serveur existant.

## Limites explicites
Cette livraison ne prétend pas fournir une application Android native, un modèle IA entraîné localement, ni une compilation universelle de jeux 3D. Les fournisseurs IA restent à configurer avec leurs propres accès. Le diagnostic statique ne remplace pas les tests d'intégration, les essais sur appareils Android ni les tests avec de vrais fournisseurs.
