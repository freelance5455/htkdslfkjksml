# OPS NEXT GENERATION — V3.8

## Audit de départ

Base auditée : OPS MASTER AI NEURAL V3.7. Avant modification, les 88 tests existants passaient. Le projet contenait déjà l'orchestrateur multi-agents, les mémoires de projet et d'expérience, le navigateur structurel avec aperçu HTML isolé, les générateurs procéduraux WORLD/MODELING, les moteurs NPC/PHYSICS, le centre de tests, les sauvegardes et les échanges de fichiers.

## Développements livrés

### OPS AI COMMUNICATION BUS
- Événements persistés dans SQLite par projet.
- Diffusion à toute l'équipe ou ciblage d'un agent.
- Filtrage de réception par agent.
- Payload JSON borné à 24 Ko.
- Événements publiés également sur le canal WebSocket de l'interface.
- Les agents peuvent émettre `<ops-bus type="..." to="...">{...}</ops-bus>` dans leur réponse.
- Les événements pertinents sont ajoutés au contexte des tâches suivantes.

### OPS DEPENDENCY MANAGER
- Contrats dirigés `prerequisite → dependent` entre moteurs.
- Persistance par projet.
- Détection des cycles avant enregistrement.
- Les contrats sont transmis au contexte des agents.
- Les agents peuvent déclarer une dépendance avec `<ops-dependency .../>`.

### API
- `GET/POST /api/projects/:id/collaboration/events`
- `GET/POST /api/projects/:id/collaboration/dependencies`

## Vérification

- Tests de départ : 88/88.
- Tests après développement : 91/91.
- Contrôle syntaxique des modules modifiés.
- Test du bus : persistance, ciblage et filtrage.
- Test des dépendances : contrats conservés et cycle refusé.

## Limites restantes

- Pas encore de panneau UI dédié au bus et au graphe de dépendances.
- Pas encore de capture visuelle automatique du jeu ni d'analyse vision intégrée à la boucle QA.
- Les moteurs graphiques, animation, audio, véhicules et compilation native nécessitent encore des backends et des pipelines concrets ; leur présence dans les prompts ou le roster ne signifie pas que tous sont déjà implémentés.
- La collaboration fonctionne au niveau du serveur OPS et de son stockage local ; ce n'est pas encore un bus distribué multi-serveurs.
