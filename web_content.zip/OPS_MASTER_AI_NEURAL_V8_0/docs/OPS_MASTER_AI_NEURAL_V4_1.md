# OPS MASTER AI NEURAL V4.1.0

## Objectif

Évolution de maintenance et de fiabilité de V4.0. Les modules métiers, projets intégrés, moteurs, agents, données et fonctionnalités existants sont conservés.

## Changements

- Version package/serveur alignée sur `4.1.0`.
- Validation stricte de `PORT` et ajout du réglage `OPS_MAX_BODY_BYTES` (1 KiB à 64 MiB ; défaut 12 MiB).
- En-têtes HTTP de protection appliqués de manière cohérente.
- Limiteur d'authentification : expiration effective de la fenêtre de blocage et remise à zéro après authentification valide.
- Rejet des corps HTTP trop volumineux sans détruire immédiatement la socket, afin de laisser le serveur retourner une réponse 413.
- Délais HTTP du serveur explicitement configurés et erreurs d'écoute propagées proprement.
- Requêtes `HEAD` statiques sans corps de réponse.
- Tests supplémentaires de configuration et de comportement HTTP.

## Vérifications exécutées

- `npm test` : 156 tests réussis, 0 échec.
- `npm run doctor` : contrôles d'intégrité et syntaxe JavaScript.

## Limites

Les tests automatisés et le Doctor vérifient la cohérence logicielle, pas la qualité réelle des réponses des fournisseurs IA, les performances sur tous les téléphones, ni une certification de sécurité externe. Les fournisseurs IA nécessitent leurs propres identifiants et paramètres.
