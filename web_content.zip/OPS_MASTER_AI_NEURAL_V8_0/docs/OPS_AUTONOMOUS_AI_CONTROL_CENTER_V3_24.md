# OPS MASTER AI NEURAL V3.24 — AUTONOMOUS AI CONTROL CENTER

## Objectif

Ajouter un tableau de contrôle global et en lecture seule qui rassemble les informations déjà stockées par les projets, agents, tâches, Director, collaboration, moteurs et IA du Studio. Le module ne remplace aucun sous-système existant et ne modifie pas les tâches.

## Fonctions

- Vue consolidée des projets actifs et de leur charge de tâches.
- État des agents activés, tâches actives/terminées/bloquées et boîte de réception.
- Suivi des transmissions et affichage des événements persistés du bus de collaboration.
- Inventaire des moteurs enregistrés et de leur dernier état connu.
- Inventaire des IA du Studio et indicateurs de disponibilité des fournisseurs configurés.
- Alertes globales sur les tâches bloquées, transmissions en attente et absence d'agents activés.
- Rafraîchissement de l'interface à la réception des événements WebSocket OPS et toutes les 15 secondes, avec bouton d'actualisation manuelle.

## API

- `GET /api/control-center` — rapport global en lecture seule.

Le rapport est calculé à la demande à partir des données enregistrées. Les états de moteurs et d'agents reflètent les dernières informations stockées, et ne constituent pas une preuve d'activité réelle d'un processus externe.

## Sécurité et limites

- Aucune écriture dans les projets ou les tâches.
- Aucun script exécuté et aucune tâche lancée automatiquement.
- Aucun appel à un fournisseur IA depuis ce tableau de bord.
- Les événements sont ceux déjà persistés dans le bus de collaboration ; les messages WebSocket déclenchent le rafraîchissement de l'écran mais ne sont pas archivés par ce module.
- Les moteurs externes ne sont affichés que s'ils sont enregistrés dans la table `engines`.
- Le module ne modifie ni les modèles externes ni leurs poids.
