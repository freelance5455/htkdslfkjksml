# Installation

## PC (Windows / Linux / macOS)
1. Installer Node.js ≥ 22.13. 2. Dézipper. 3. `scripts\start.bat` ou `scripts/start.sh`. 4. Ouvrir l'adresse affichée.
Données : dossier `data/` (base SQLite `ops.db`, `projects/<id>/workspace|versions|undo|reports`, `.token`, `.secret`). **Sauvegardez `data/` en entier** (sans `.secret`, les clés API enregistrées sont illisibles).

## Téléphone Android (sans PC)
Installer Termux, puis `pkg install nodejs`, copier le dossier, `bash scripts/termux.sh`, ouvrir `http://127.0.0.1:8800` dans Chrome → menu « Installer l'application ». Node 22 doit être disponible dans Termux (`node -v`).

## Serveur / hébergement
- `OPS_HOST=0.0.0.0`, un `OPS_TOKEN` long, et un reverse proxy **HTTPS** (Caddy/nginx) qui autorise les WebSocket (`/ws`).
- Docker : `docker build -t ops . && docker run -p 8800:8800 -v ops-data:/data -e OPS_TOKEN=... ops`
- PostgreSQL : `npm install pg` puis `OPS_DATABASE_URL=postgres://…` (non testé ici).

## Fournisseurs IA — ce qu'il faut connecter
| Besoin | À configurer |
|---|---|
| Agents IA | Au moins un fournisseur : clé API + modèle (OpenAI, Anthropic, Gemini, OpenRouter, Mistral, Groq, DeepSeek, Ollama/LM Studio via « Compatible OpenAI » + URL de base) |
| Recherche Web | Clé Tavily ou Brave (Paramètres) |
| Exécution `npm test/build` | Autoriser explicitement par projet |
