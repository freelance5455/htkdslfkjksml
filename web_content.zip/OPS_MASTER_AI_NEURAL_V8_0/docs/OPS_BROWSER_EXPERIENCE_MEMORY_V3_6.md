# OPS MASTER AI NEURAL V3.6 — Navigateur IA et mémoire d'expérience

## Navigateur intégré
- L'écran « Navigateur IA » parcourt les fichiers du projet et affiche les pages HTML dans une iframe avec sandbox sans `allow-same-origin`.
- Les ressources sont servies uniquement depuis le workspace du projet ; `safePath` protège contre `..`, les chemins absolus et les liens symboliques sortants.
- Les routes de ressources exigent le jeton OPS et renvoient une CSP restrictive. Les appels réseau depuis l'aperçu sont bloqués par la CSP du document.
- Les agents peuvent utiliser `inspect_project` pour recevoir l'arborescence et des extraits de points d'entrée/configurations. Ils peuvent ensuite demander `read_file` sur un chemin précis.

## Mémoire d'expérience
- `experience_memory` conserve domaine, leçon, preuve/origine, agent, projet, état et dates.
- Les agents soumettent une leçon via `<ops-experience domain="...">...</ops-experience>`.
- Toute leçon commence en `pending`. Un utilisateur la valide ou la refuse depuis « Mémoire expérience ».
- Seules les lignes `approved` sont injectées dans le contexte des tâches de l'équipe ; les leçons restent limitées au projet et aux expériences globales (project_id NULL).
- La validation humaine limite la propagation de mauvaises pratiques ou d'hallucinations. Il s'agit d'une mémoire logicielle persistante, pas d'un fine-tuning des poids du modèle.

## Tests
- Aperçu HTML et ressource locale authentifiés.
- Refus de servir une ressource sans jeton.
- Isolation des expériences en attente et validées.
- Extraction de la balise d'expérience des réponses agents.


## Extension V3.7 — Inspection et mémoire ciblée

`GET /api/projects/:id/inspection` fournit une vue structurelle déterministe : nombre de fichiers, octets, extensions, points d’entrée probables, ressources reconnues, arbre du projet et compteurs de mémoire.

Les leçons approuvées sont classées à chaque sous-tâche selon le recouvrement lexical entre la tâche et le domaine/contenu de la leçon. Au plus 12 expériences pertinentes sont injectées. Chaque récupération est inscrite dans `experience_events`, ce qui permet d’exposer des statistiques via `GET /api/projects/:id/experience-stats`. La pertinence lexicale n’est pas une preuve que la leçon est correcte : les validations humaines et les tests restent nécessaires.

Le navigateur présente le rapport structurel et conserve l’aperçu HTML isolé. Les IA ne reçoivent pas encore de capture d’écran visuelle du rendu ; elles analysent le code, l’arborescence et les rapports.
