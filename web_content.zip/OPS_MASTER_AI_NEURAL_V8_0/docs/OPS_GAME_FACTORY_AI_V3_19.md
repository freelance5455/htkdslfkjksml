# OPS GAME FACTORY AI — V3.19

## Objectif
Transformer le cahier des charges d'une production OPS en plan vérifiable, sans prétendre que le plan constitue à lui seul une implémentation.

## Blueprint
`server/game-factory.mjs` expose :
- `createGameFactoryBlueprint({ title, brief, constraints })` : exigences `REQ-###`, neuf flux de travail ordonnés, dépendances, livrables attendus et portes d'acceptation.
- `buildFactoryDeliveryReport(blueprint, evidence)` : manifeste de fichiers, diagnostics, résultats de non-régression et tests, avec statut de livraison prudent.

## Flux
Cadrage → Architecture → Monde et ressources / Gameplay → Spécialistes → Assemblage CODER → DEBUG → QUALITY → Livraison.

Les tâches spécialisées restent soumises aux agents et fournisseurs réellement configurés. Le blueprint n'exécute pas de code. Les exigences sont initialement `needs_review` : aucune n'est déclarée terminée sans preuve et validation.

## Sécurité et préservation
- Aucun script du projet n'est exécuté par le planificateur.
- L'exécution runtime reste soumise à l'autorisation explicite existante.
- Les contrôles de non-régression et l'approbation des fichiers restent actifs.
- Les éléments non vérifiables restent signalés comme tels.

## Validation
`npm test` : 120 tests réussis, 0 échec.
