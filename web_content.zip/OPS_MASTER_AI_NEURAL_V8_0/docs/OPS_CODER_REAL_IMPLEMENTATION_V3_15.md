# OPS CODER AI — implémentation réelle V3.15

## Défaut corrigé
L'orchestrateur ignorait les appels `<ops-tool>` dès qu'une réponse contenait également un ou plusieurs `<ops-file>`. Cela interrompait le cycle inspecter → lire → coder pour les modèles qui regroupent les outils et le code dans une seule réponse.

## Changements
- Les appels d'outils sont désormais exécutés même si la même réponse contient déjà du code.
- Les fichiers, demandes inter-agents, événements et propositions sont conservés entre les tours du modèle ; la dernière version d'un chemin remplace la version provisoire dans la collecte.
- OPS CODER reçoit une relance explicite lorsqu'une tâche de programmation ne contient aucun `<ops-file>`.
- Si aucun fichier n'est livré après cette relance, la tâche échoue explicitement et ne prétend plus que le code a été écrit.
- Le compte rendu de tâche liste les fichiers effectivement proposés.
- Le chat direct avec CODER applique également les fichiers en mode `auto`, avec création d’une version de sauvegarde préalable ; en mode `approval`, ils restent à valider.
- OPS DEBUG continue d'auditer les contenus de fichiers proposés par CODER, puis CODER reçoit les constats pour les corrections.

## Écriture dans le workspace
Le mode `approval` reste le mode sûr par défaut : les fichiers écrits par CODER deviennent des propositions à approuver. Le mode `auto` applique les propositions non conflictuelles avec sauvegarde et possibilité d'annulation. Aucun changement de politique d'écriture n'est effectué silencieusement.

## Limites
- Le code est généré par le fournisseur et le modèle configurés pour OPS CODER ; cette version ne modifie pas les poids du modèle externe.
- Un bloc `<ops-file>` est une proposition de contenu, pas une preuve que le jeu fonctionne. Les tests et l'exécution runtime restent nécessaires.
- Les suppressions ne sont jamais appliquées automatiquement.
