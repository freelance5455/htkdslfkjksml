# OPS MASTER AI NEURAL V6.1

La V6.1 conserve les modules V5.3/V6.0 et ajoute l’interface graphique du manifeste de livraison.

## Interface
- Navigation « Manifeste de livraison » dans les modules avancés.
- Résumé de l’état, du nombre de fichiers, de la taille et des alertes.
- Empreinte racine SHA-256 avec commande de copie.
- Liste filtrable des fichiers avec taille et empreinte individuelle.
- Affichage des points d’entrée, lockfiles, alertes et limites du contrôle.
- Création d’un snapshot versionné ; bouton désactivé si le manifeste est bloqué.

## Sécurité et limites
- Les appels API utilisent le client authentifié existant.
- Les valeurs affichées sont insérées comme texte, pas comme HTML.
- Aucun script du projet n’est exécuté par le manifeste.
- Le manifeste ne prouve pas le bon fonctionnement du projet.
- La plateforme reste une PWA + API Node.js ; aucun APK natif n’est produit par cette version.

## Validation
- `node --check public/app.js`
- `npm test`
- `npm run doctor`
