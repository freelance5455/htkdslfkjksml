# OPS AUTOMATIC BUG FIXER — V3.13

## Objectif
Transformer un rapport de test existant en mission de diagnostic et de correction coordonnée par l'équipe OPS.

## Fonctionnement
1. L'utilisateur choisit un rapport appartenant au projet courant.
2. OPS crée une version de sauvegarde avant toute intervention.
3. Le module collecte le résumé, les constats, les fichiers cités et des extraits limités des sources.
4. L'orchestrateur démarre une mission d'équipe ; OPS CODER AI et les spécialistes reçoivent le contexte et les contraintes de préservation.
5. Les propositions de fichiers utilisent les mécanismes normaux du workspace et respectent `write_mode` (approbation ou mode automatique explicitement configuré).
6. Les sessions sont persistées et visibles depuis le Centre de tests.

## Sécurité et limites
- Aucun script, binaire ou programme du projet n'est lancé par le Bug Fixer.
- Aucun fichier n'est supprimé par cette mission ; la consigne demande des corrections minimales et non destructives.
- Le mode d'écriture du projet reste la règle : en mode `approval`, les changements attendent une approbation humaine.
- La création d'une mission ne signifie pas que le défaut est corrigé. Il faut attendre le résultat de l'orchestrateur, examiner les propositions et relancer les tests.
- La qualité du diagnostic et des corrections dépend des fournisseurs IA configurés, des agents actifs et des preuves présentes dans le rapport.

## API
- `POST /api/projects/:id/bug-fixes` avec `{ "report_id": "..." }`
- `GET /api/projects/:id/bug-fixes`
- `GET /api/bug-fixes/:id`

## Conservation
Chaque mission conserve son rapport source, son identifiant d'exécution, sa sauvegarde de référence, son statut et ses horodatages.
