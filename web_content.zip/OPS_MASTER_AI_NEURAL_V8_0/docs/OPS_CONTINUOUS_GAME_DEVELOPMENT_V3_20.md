# OPS MASTER AI NEURAL V3.20 — CONTINUOUS GAME DEVELOPMENT

## Objectif
Permettre de reprendre une production de jeu interrompue ou échouée à partir de l'état réel du workspace, sans repartir de zéro.

## Fonctionnalités
- Nouvelle route `POST /api/production/:id/resume`.
- Reprise autorisée pour les statuts `partial`, `development_failed` et `quality_failed`.
- Refus explicite si la production est déjà `running`, `awaiting_approval` ou `ready_for_review`.
- Conservation de la baseline originale et des fichiers existants.
- Conservation d'un historique borné des tentatives précédentes dans `brief.resume_history`.
- Le nouveau run reçoit le brief original, les contraintes, le manifeste courant, les diagnostics d'intégration et le rapport précédent.
- Les tâches de reprise demandent aux agents d'inspecter le workspace et de ne traiter que le travail restant.
- Respect du mode `approval` / `auto` et des protections d'exécution existantes.
- Émission d'un événement `production` indiquant `resumed: true`.

## Utilisation
`POST /api/production/{pipeline_id}/resume`

La réponse contient le nouvel `run_id`, l'ancien `previous_run_id`, `resume_count` et l'état du pipeline.

## Limites
La reprise planifie un nouveau run d'équipe à partir des éléments conservés ; elle ne garantit pas que le fournisseur IA saura résoudre toutes les tâches. Les tests d'intégration utilisent le fournisseur simulé. Aucun script du projet n'est exécuté par cette reprise.
