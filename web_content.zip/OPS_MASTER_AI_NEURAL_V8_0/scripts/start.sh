#!/usr/bin/env bash
cd "$(dirname "$0")/.." || exit 1
command -v node >/dev/null || { echo "Node.js 22+ requis : https://nodejs.org"; exit 1; }
exec node server/index.mjs
