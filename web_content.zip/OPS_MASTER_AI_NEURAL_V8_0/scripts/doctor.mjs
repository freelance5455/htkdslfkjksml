import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const SKIP = new Set(['node_modules', '.git', 'data', 'coverage']);

function walk(dir, out = []) {
  for (const item of fs.readdirSync(dir, { withFileTypes: true })) {
    if (SKIP.has(item.name) || item.name.startsWith('.')) continue;
    const full = path.join(dir, item.name);
    if (item.isDirectory()) walk(full, out);
    else if (/\.(?:mjs|cjs|js)$/.test(item.name)) out.push(full);
  }
  return out;
}

/**
 * Read-only project integrity check. It never executes project code, writes files,
 * installs dependencies, or contacts external services.
 */
export async function inspectProject(root = ROOT) {
  const checks = [];
  const add = (id, status, message, file = null) => checks.push({ id, status, message, file });
  const readJson = (file, id) => {
    try {
      return JSON.parse(fs.readFileSync(path.join(root, file), 'utf8'));
    } catch (error) {
      add(id, 'error', `JSON illisible : ${error.message}`, file);
      return null;
    }
  };

  const pkg = readJson('package.json', 'package-json');
  const manifest = readJson('public/manifest.webmanifest', 'pwa-manifest');
  if (pkg) add('package-json', 'ok', `package.json valide — version ${pkg.version}`, 'package.json');
  if (manifest) add('pwa-manifest', 'ok', `Manifest PWA valide — ${manifest.name || 'nom absent'}`, 'public/manifest.webmanifest');

  if (pkg && pkg.engines?.node) {
    const major = Number(process.versions.node.split('.')[0]);
    const minimum = Number((pkg.engines.node.match(/\d+/) || ['0'])[0]);
    add('node-runtime', major >= minimum ? 'ok' : 'warning',
      `Node.js ${process.versions.node} ; version déclarée requise ${pkg.engines.node}`);
  }

  const configPath = path.join(root, 'server/config.mjs');
  if (pkg && fs.existsSync(configPath)) {
    const config = fs.readFileSync(configPath, 'utf8');
    const match = config.match(/export const VERSION = ['"]([^'"]+)['"]/);
    if (!match) add('version-alignment', 'error', 'Version serveur introuvable', 'server/config.mjs');
    else add('version-alignment', match[1] === pkg.version ? 'ok' : 'error',
      `package.json=${pkg.version} ; serveur=${match[1]}`, 'server/config.mjs');
  }

  const files = walk(root);
  let syntaxErrors = 0;
  for (const file of files) {
    const rel = path.relative(root, file);
    const result = spawnSync(process.execPath, ['--check', file], { encoding: 'utf8', timeout: 15000 });
    if (result.status !== 0) {
      syntaxErrors++;
      add(`syntax:${rel}`, 'error', (result.stderr || result.stdout || 'Échec node --check').trim().split('\n').slice(-3).join('\n'), rel);
    }
  }
  add('javascript-syntax', syntaxErrors ? 'error' : 'ok',
    `${files.length} fichiers JavaScript analysés ; ${syntaxErrors} erreur(s)`);

  const htmlPath = path.join(root, 'public/index.html');
  if (fs.existsSync(htmlPath)) {
    const html = fs.readFileSync(htmlPath, 'utf8');
    const refs = [...html.matchAll(/(?:src|href)=["']([^"'#]+)["']/g)].map(m => m[1])
      .filter(v => !/^(?:https?:|data:|mailto:|tel:|javascript:)/i.test(v));
    const missing = refs.filter(ref => {
      const clean = decodeURIComponent(ref.split('?')[0]);
      return !fs.existsSync(path.resolve(path.dirname(htmlPath), clean));
    });
    add('frontend-assets', missing.length ? 'warning' : 'ok',
      missing.length ? `Ressources locales introuvables : ${missing.join(', ')}` : `${refs.length} références locales vérifiées`,
      'public/index.html');
  } else add('frontend-entry', 'error', 'public/index.html absent');

  const errors = checks.filter(c => c.status === 'error').length;
  const warnings = checks.filter(c => c.status === 'warning').length;
  return {
    tool: 'OPS INTEGRITY DOCTOR',
    version: pkg?.version || null,
    generatedAt: new Date().toISOString(),
    mode: 'read-only',
    summary: { checks: checks.length, errors, warnings, passed: checks.length - errors - warnings },
    checks
  };
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const report = await inspectProject();
  console.log(`\nOPS INTEGRITY DOCTOR — ${report.version || 'version inconnue'}`);
  console.log(`Contrôles : ${report.summary.checks} | OK : ${report.summary.passed} | Alertes : ${report.summary.warnings} | Erreurs : ${report.summary.errors}\n`);
  for (const check of report.checks) {
    const mark = check.status === 'ok' ? '✓' : check.status === 'warning' ? '!' : '✗';
    console.log(`${mark} ${check.id} — ${check.message}`);
  }
  if (report.summary.errors) process.exitCode = 1;
}
