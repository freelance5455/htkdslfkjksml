@echo off
cd /d "%~dp0.."
where node >nul 2>nul || (echo Node.js 22+ requis : https://nodejs.org & pause & exit /b 1)
node server\index.mjs
pause
