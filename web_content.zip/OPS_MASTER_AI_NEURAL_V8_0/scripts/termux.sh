#!/data/data/com.termux/files/usr/bin/bash
# Lancement sur téléphone Android via Termux (pkg install nodejs). Écoute en local uniquement.
cd "$(dirname "$0")/.." || exit 1
exec node server/index.mjs
