// OPS MASTER AI CHAT — interface. Aucune injection HTML : tout le contenu dynamique passe par textContent.
// Ignore null/false lors de l'insertion de nœuds (évite d'afficher « null » ou « false »).
for (const m of ['replaceChildren', 'append']) { const o = Element.prototype[m]; Element.prototype[m] = function (...k) { return o.apply(this, k.flat(Infinity).filter((x) => x != null && x !== false)); }; }
const $ = (s, r = document) => r.querySelector(s);
function h(tag, props, ...kids) {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(props || {})) {
    if (v == null || v === false) continue;
    if (k === 'class') e.className = v;
    else if (k.startsWith('on')) e.addEventListener(k.slice(2), v);
    else if (k === 'value') e.value = v;
    else if (v === true) e.setAttribute(k, '');
    else e.setAttribute(k, v);
  }
  for (const k of kids.flat(Infinity)) { if (k == null || k === false) continue; e.append(k.nodeType ? k : document.createTextNode(String(k))); }
  return e;
}
const fmt = (ts) => (ts ? new Date(ts).toLocaleString('fr-FR', { dateStyle: 'short', timeStyle: 'short' }) : '—');
const pill = (s) => h('span', { class: 'pill ' + s }, s);

const S = { token: null, projects: [], project: null, agents: [], route: 'dashboard', ws: null, wsOn: false, state: null, run: null, chatMode: 'team', chatAgent: 'architect', specialistAgent: 'animation', cleanup: null };
const store = { get: () => { try { return sessionStorage.getItem('ops_token') || localStorage.getItem('ops_token'); } catch { return null; } }, set: (t, remember) => { try { sessionStorage.setItem('ops_token', t); if (remember) localStorage.setItem('ops_token', t); } catch { /* stockage indisponible */ } }, clear: () => { try { sessionStorage.removeItem('ops_token'); localStorage.removeItem('ops_token'); } catch { /* */ } } };

async function api(method, url, body) {
  const r = await fetch(url, { method, headers: { 'content-type': 'application/json', authorization: 'Bearer ' + S.token }, body: body === undefined ? undefined : JSON.stringify(body) });
  const data = await r.json().catch(() => ({}));
  if (r.status === 401) { logout(); throw new Error('Session expirée'); }
  if (!r.ok) { const e = new Error(data.error || r.statusText); e.code = data.code; e.status = r.status; throw e; }
  return data;
}
function toast(msg, err) { const t = h('div', { class: 'toast' + (err ? ' err' : '') }, msg); document.body.append(t); setTimeout(() => t.remove(), err ? 6000 : 2800); }
const guard = (fn) => async (...a) => { try { return await fn(...a); } catch (e) { toast(e.message, true); } };
function modal(title, ...content) {
  const bg = h('div', { class: 'modal-bg', onclick: (e) => { if (e.target === bg) bg.remove(); } }, h('div', { class: 'modal' }, h('div', { class: 'row sp' }, h('h2', {}, title), h('button', { class: 'small', onclick: () => bg.remove() }, 'Fermer')), ...content));
  document.body.append(bg); return bg;
}

// ---------- rendu markdown minimal et sûr ----------
function inline(text) {
  const out = []; const re = /(`[^`]+`|\*\*[^*]+\*\*)/g; let last = 0, m;
  while ((m = re.exec(text))) { if (m.index > last) out.push(text.slice(last, m.index)); const t = m[0]; out.push(t[0] === '`' ? h('code', {}, t.slice(1, -1)) : h('b', {}, t.slice(2, -2))); last = m.index + t.length; }
  if (last < text.length) out.push(text.slice(last)); return out;
}
function md(src) {
  const root = h('div'); const lines = String(src || '').split('\n'); let i = 0, list = null;
  while (i < lines.length) {
    const l = lines[i];
    if (/^```/.test(l)) { const buf = []; i++; while (i < lines.length && !/^```/.test(lines[i])) buf.push(lines[i++]); i++; root.append(h('pre', {}, buf.join('\n'))); list = null; continue; }
    const hd = l.match(/^(#{1,4})\s+(.*)/);
    if (hd) { root.append(h('h' + Math.min(3, hd[1].length), {}, inline(hd[2]))); list = null; }
    else if (/^\s*[-*]\s+/.test(l)) { if (!list) { list = h('ul'); root.append(list); } list.append(h('li', {}, inline(l.replace(/^\s*[-*]\s+/, '')))); }
    else if (/^---+$/.test(l.trim())) { root.append(h('hr')); list = null; }
    else if (l.trim()) { root.append(h('p', {}, inline(l))); list = null; } else list = null;
    i++;
  }
  return root;
}

// ---------- navigation ----------
const NAV = [
  ['dashboard', '🏠', 'Tableau de bord'], ['director', '🎬', 'Director'], ['world', '🌍', 'WORLD AI'], ['modeling', '🧱', 'MODELING AI'], ['studio', '🎮', 'Studio 11 IA'], ['chat', '💬', 'Chat'], ['agents', '🧠', 'Agents'], ['team', '👥', 'Mode équipe'], ['projects', '📁', 'Projets'],
  ['files', '🗂️', 'Fichiers'], ['library', '📚', 'Bibliothèque'], ['dev', '🛠️', 'Développement'], ['history', '🕘', 'Historique'], ['tests', '✅', 'Tests'], ['providers', '🔌', 'Fournisseurs IA'], ['settings', '⚙️', 'Paramètres'],
];
// Modules V3 conservés, regroupés dans un bloc replié pour garder le menu identique à la maquette.
const NAV_EXTRA = [
  ['readiness', '🩺', 'État opérationnel'], ['release', '📦', 'Manifeste de livraison'], ['benchmarks', '📊', 'AI Performance Benchmarks'], ['control-center', '🎛️', 'OPS Control Center'], ['orchestration', '🧩', 'AI Orchestration Engine'], ['manager', '🧭', 'Project Manager AI'], ['supervisor', '🛡️', 'Autonomous AI Supervisor'], ['production', '🏗️', 'Production autonome'], ['browser', '🌐', 'Navigateur IA'], ['experience', '🧠', 'Mémoire expérience'],
];

function logout() { store.clear(); S.token = null; if (S.ws) { S.ws.onclose = null; S.ws.close(); } S.ws = null; renderLogin(); }

function renderLogin(msg) {
  document.getElementById('root').replaceChildren(h('div', { class: 'login' },
    h('h1', {}, 'OPS MASTER AI CHAT'), h('p', { class: 'muted' }, "Centre de commande de l'organisation OPS. Saisissez le jeton d'accès affiché dans la console du serveur (ou dans data/.token)."),
    msg && h('div', { class: 'alert err' }, msg),
    h('label', {}, "Jeton d'accès"), h('input', { id: 'tok', type: 'password', autocomplete: 'current-password', onkeydown: (e) => e.key === 'Enter' && $('#go').click() }),
    h('label', { class: 'inline' }, h('input', { id: 'rem', type: 'checkbox' }), 'Mémoriser sur cet appareil'),
    h('button', { id: 'go', class: 'primary', onclick: async () => {
      const t = $('#tok').value.trim(); S.token = t;
      try { await api('GET', '/api/state'); store.set(t, $('#rem').checked); boot(); } catch (e) { S.token = null; renderLogin(e.message === 'Session expirée' ? 'Jeton invalide.' : e.message); }
    } }, 'Se connecter')));
}

function connectWs() {
  if (S.ws) return;
  const url = (location.protocol === 'https:' ? 'wss://' : 'ws://') + location.host + '/ws?token=' + encodeURIComponent(S.token);
  const ws = new WebSocket(url); S.ws = ws;
  ws.onopen = () => { S.wsOn = true; paintStatus(); };
  ws.onclose = () => { S.wsOn = false; S.ws = null; paintStatus(); if (S.token) setTimeout(connectWs, 3000); };
  let timer = null;
  ws.onmessage = (e) => { let m; try { m = JSON.parse(e.data); } catch { return; } if (m.type === 'hello') return; clearTimeout(timer); timer = setTimeout(() => { refreshBadges(); S.cleanup?.refresh?.(m); }, 250); };
}
function paintStatus() { const d = $('#wsdot'); if (d) { d.className = 'dot' + (S.wsOn ? ' on' : ''); d.title = S.wsOn ? 'Temps réel connecté' : 'Temps réel déconnecté'; } }
async function refreshBadges() { try { S.state = await api('GET', '/api/state'); const b = $('#badge-dev'); if (b) { b.textContent = S.state.pending_approvals || ''; b.style.display = S.state.pending_approvals ? '' : 'none'; } } catch { /* ignoré */ } }

async function boot() {
  S.projects = (await api('GET', '/api/projects')).filter((p) => !p.archived);
  S.agents = await api('GET', '/api/agents');
  const saved = (() => { try { return localStorage.getItem('ops_project'); } catch { return null; } })();
  S.project = S.projects.find((p) => p.id === (S.project?.id || saved)) || S.projects[0] || null;
  const root = document.getElementById('root');
  root.replaceChildren(h('div', { class: 'app' },
    h('div', { class: 'top' }, h('div', { class: 'brand' }, 'OPS MASTER AI CHAT', h('small', {}, 'CENTRE DE COMMANDE')), h('div', { class: 'sp' }),
      h('select', { id: 'projsel', 'aria-label': 'Projet actif', onchange: (e) => { S.project = S.projects.find((p) => p.id === e.target.value); try { localStorage.setItem('ops_project', S.project?.id || ''); } catch { /* */ } go(S.route); } }),
      h('span', { id: 'wsdot', class: 'dot' })),
    h('nav', {}, NAV.map(([id, ic, label]) => h('a', { 'data-r': id, onclick: () => go(id) }, h('span', { class: 'ic' }, ic), h('span', {}, label), id === 'dev' && h('span', { id: 'badge-dev', class: 'badge', style: 'display:none' }))),
      h('details', { class: 'more' }, h('summary', {}, h('span', { class: 'ic' }, '➕'), h('span', {}, 'Modules avancés')), NAV_EXTRA.map(([id, ic, label]) => h('a', { 'data-r': id, onclick: () => go(id) }, h('span', { class: 'ic' }, ic), h('span', {}, label))))),
    h('main', { id: 'main' })));
  paintProjectSelect(); paintStatus(); connectWs(); refreshBadges();
  go(location.hash.slice(1) || 'dashboard');
  if ('serviceWorker' in navigator) navigator.serviceWorker.register('sw.js').catch(() => {});
}
function paintProjectSelect() {
  const sel = $('#projsel'); if (!sel) return;
  sel.replaceChildren(...S.projects.map((p) => h('option', { value: p.id, selected: p.id === S.project?.id }, p.name)));
}
function go(route) {
  if (!SCREENS[route]) route = 'dashboard';
  S.route = route; location.hash = route;
  S.cleanup?.stop?.(); S.cleanup = null;
  document.querySelectorAll('nav a').forEach((a) => a.classList.toggle('on', a.dataset.r === route));
  { const mo = document.querySelector('nav details.more'); if (mo && NAV_EXTRA.some(([id]) => id === route)) mo.open = true; }
  const main = $('#main'); main.replaceChildren();
  if (!S.project && !['providers', 'settings', 'projects', 'agents'].includes(route)) { main.append(h('div', { class: 'alert' }, "Aucun projet : créez-en un dans l'écran Projets.")); return; }
  const r = SCREENS[route](main); if (r) S.cleanup = r;
}
const needsProvider = () => S.state && S.state.providers_ready === 0 ? h('div', { class: 'alert' }, 'Aucun fournisseur IA prêt. ', h('a', { href: '#providers', style: 'color:inherit;text-decoration:underline', onclick: () => go('providers') }, 'Configurez-en un'), " : sans lui, les agents ne peuvent pas répondre (aucune réponse n'est simulée).") : null;

// ---------- écrans ----------
const SCREENS = {};

// V6.1 — interface du manifeste de livraison. Les données restent échappées via h().
SCREENS.release = (main) => {
  const root = h('div');
  const projectId = S.project.id;
  const statusMeta = (status) => ({
    ready: ['ok', 'Prêt'], review: ['warn', 'À vérifier'], blocked: ['failed', 'Bloqué']
  }[status] || ['muted', status || 'Inconnu']);
  const load = guard(async () => {
    root.replaceChildren(h('p', { class: 'muted' }, 'Calcul des empreintes SHA-256…'));
    const r = await api('GET', `/api/projects/${encodeURIComponent(projectId)}/release-manifest`);
    const [cls, label] = statusMeta(r.status);
    const fmtBytes = (n) => n < 1024 ? `${n} o` : n < 1048576 ? `${(n/1024).toFixed(1)} Ko` : `${(n/1048576).toFixed(2)} Mo`;
    const summary = h('div', { class: 'grid' },
      h('div', { class: 'card' }, h('div', { class: 'muted small' }, 'État du manifeste'), h('h2', {}, pill(cls), ' ', label)),
      h('div', { class: 'card' }, h('div', { class: 'muted small' }, 'Fichiers analysés'), h('h2', {}, String(r.integrity.files))),
      h('div', { class: 'card' }, h('div', { class: 'muted small' }, 'Taille totale'), h('h2', {}, fmtBytes(r.integrity.total_bytes))),
      h('div', { class: 'card' }, h('div', { class: 'muted small' }, 'Alertes'), h('h2', {}, String(r.findings.length))));
    const hash = h('div', { class: 'card' }, h('div', { class: 'row sp' }, h('b', {}, 'Empreinte racine SHA-256'), h('button', { class: 'small', onclick: () => { navigator.clipboard?.writeText(r.integrity.root_sha256).then(() => toast('Empreinte copiée')).catch(() => toast('Copie non disponible', true)); } }, 'Copier')),
      h('code', { class: 'mono', style: 'display:block;overflow-wrap:anywhere;margin-top:8px' }, r.integrity.root_sha256),
      h('p', { class: 'small muted' }, `Algorithme : ${r.integrity.algorithm} · Généré le ${fmt(r.generated_at)} · Projet : ${r.project.name}`));
    const findings = r.findings.length ? h('div', { class: 'stack' }, ...r.findings.map(f => h('div', { class: 'task' },
      h('div', { class: 'row sp' }, h('b', {}, f.code), pill(f.severity === 'block' ? 'failed' : 'warn')),
      h('div', { class: 'small' }, f.detail), f.path && h('code', { class: 'small muted' }, f.path)))) : h('div', { class: 'alert info' }, 'Aucune alerte détectée par les contrôles du manifeste.');
    const files = h('div', { class: 'card' }, h('div', { class: 'row sp' }, h('h2', {}, `Inventaire (${r.files.length})`), h('input', { id: 'release-filter', placeholder: 'Filtrer les fichiers…', style: 'max-width:260px' })), h('div', { class: 'table-wrap' }, h('table', { id: 'release-files' },
      h('thead', {}, h('tr', {}, h('th', {}, 'Fichier'), h('th', {}, 'Taille'), h('th', {}, 'SHA-256'))),
      h('tbody', {}, ...r.files.map(f => h('tr', { 'data-path': f.path.toLowerCase() }, h('td', {}, h('code', {}, f.path)), h('td', {}, fmtBytes(f.size)), h('td', {}, h('code', { class: 'small' }, f.sha256))))))));
    const filter = $('#release-filter', files);
    filter.addEventListener('input', () => { const q = filter.value.trim().toLowerCase(); $('#release-files tbody', files).querySelectorAll('tr').forEach(tr => { tr.hidden = !tr.dataset.path.includes(q); }); });
    const snapshotLabel = h('input', { value: 'Snapshot de livraison V6', maxlength: '120', placeholder: 'Nom du snapshot' });
    const snapshotButton = h('button', { class: 'primary', disabled: r.status === 'blocked', onclick: guard(async () => {
      snapshotButton.disabled = true;
      try {
        const snap = await api('POST', `/api/projects/${encodeURIComponent(projectId)}/release-manifest/snapshot`, { label: snapshotLabel.value.trim() || 'Snapshot de livraison V6' });
        toast(`Snapshot créé : ${snap.snapshot?.id || 'version enregistrée'}`);
        await load();
      } finally { snapshotButton.disabled = false; }
    }) }, 'Créer un snapshot versionné');
    root.replaceChildren(summary,
      h('div', { class: 'card' }, h('div', { class: 'row sp' }, h('h2', {}, 'Contrôle d’intégrité'), h('button', { class: 'small', onclick: load }, 'Recalculer')), hash,
        h('div', { class: 'row', style: 'margin-top:10px' }, snapshotLabel, snapshotButton),
        r.status === 'blocked' && h('div', { class: 'alert err', style: 'margin-top:10px' }, 'Snapshot désactivé : des éléments bloquants doivent être examinés avant la création d’une version.')),
      h('div', { class: 'card' }, h('h2', {}, 'Points d’entrée'), ...(r.entrypoints.length ? [h('ul', {}, ...r.entrypoints.map(x => h('li', {}, h('code', {}, x))))] : [h('p', { class: 'muted' }, 'Aucun point d’entrée reconnu.')])),
      h('div', { class: 'card' }, h('h2', {}, 'Fichiers de verrouillage'), ...(r.lockfiles.length ? [h('ul', {}, ...r.lockfiles.map(x => h('li', {}, h('code', {}, x))))] : [h('p', { class: 'muted' }, 'Aucun lockfile détecté.')])),
      h('div', { class: 'card' }, h('h2', {}, 'Alertes et vérifications'), findings), files,
      h('div', { class: 'card' }, h('h2', {}, 'Limites du contrôle'), h('ul', {}, ...r.limitations.map(x => h('li', {}, x)))));
  });
  main.append(h('h1', {}, 'OPS — MANIFESTE DE LIVRAISON'), h('p', { class: 'muted' }, 'Inventaire et empreintes SHA-256 du projet actif. Ce contrôle n’exécute aucun script du projet et ne remplace pas les tests fonctionnels.'), root);
  load();
  return { refresh: () => load() };
};

SCREENS.readiness = (main) => {
  const root=h('div');
  const load=guard(async()=>{ root.replaceChildren(h('p',{class:'muted'},'Vérification des composants OPS…')); const r=await api('GET',`/api/system/readiness?project_id=${encodeURIComponent(S.project?.id||'')}`); const color=s=>s==='ready'?'ok':s==='blocked'?'failed':s==='disabled'?'muted':'warn'; const card=x=>h('div',{class:'task'},h('div',{class:'row sp'},h('b',{},x.name),pill(color(x.status))),h('div',{class:'small muted'},x.detail||x.note||'')); const studio=h('div',{class:'stack'},...r.studio.map(card)); const agents=h('div',{class:'stack'},...r.agents.map(card)); const engines=h('div',{class:'stack'},...(r.engines.length?r.engines.map(card):[h('p',{class:'muted'},'Aucun moteur externe enregistré.')])); root.replaceChildren(h('div',{class:'grid'},h('div',{class:'card'},h('b',{},`${r.summary.ready}/${r.summary.total}`),h('div',{class:'small muted'},'Contrôles prêts')),h('div',{class:'card'},h('b',{},r.summary.warning),h('div',{class:'small muted'},'À configurer / vérifier')),h('div',{class:'card'},h('b',{},r.summary.blocked),h('div',{class:'small muted'},'Bloquants'))),h('div',{class:'card'},h('div',{class:'row sp'},h('h2',{},'Composants système'),h('button',{class:'primary',onclick:load},'Actualiser')),h('div',{class:'stack'},...r.checks.map(card))),h('h2',{},'Studio IA'),studio,h('h2',{},'Agents développeurs'),agents,h('h2',{},'Moteurs externes'),engines,h('div',{class:'alert'},'Important : « prêt » signifie que la configuration et le raccordement local sont présents. Pour confirmer la disponibilité réelle d’un fournisseur ou moteur, lancez son test de connexion. Les éléments bloqués nécessitent une configuration ou une ressource externe.'),h('h3',{},'Limites connues'),h('ul',{},...r.limitations.map(x=>h('li',{},x)))); });
  main.append(h('h1',{},'OPS — ÉTAT OPÉRATIONNEL GLOBAL'),h('p',{class:'muted'},'Diagnostic de disponibilité de chaque couche : agents, fournisseurs, spécialistes, autorisations et moteurs externes.'),root); load(); return {refresh:load};
};

SCREENS.benchmarks = (main) => {
  const root = h('div');
  const render = async () => {
    root.replaceChildren(h('div', { class: 'muted' }, 'Chargement des mesures observées…'));
    try {
      const report = await api('GET', `/api/projects/${S.project.id}/benchmarks`);
      const hist = await api('GET', `/api/projects/${S.project.id}/benchmarks/history`);
      const cards = [['Tâches observées', report.summary.tasks], ['Réussites', report.summary.done], ['Échecs', report.summary.failed], ['Taux de réussite', report.summary.success_rate == null ? '—' : report.summary.success_rate + '%'], ['Relances', report.summary.retries], ['Tokens journalisés', report.summary.tokens]];
      const metrics = h('div', { class: 'grid' }, ...cards.map(([k, v]) => h('div', { class: 'card' }, h('div', { class: 'muted small' }, k), h('h2', {}, String(v)))));
      const agents = report.agents.length ? report.agents.map(a => h('div', { class: 'task' },
        h('div', { class: 'row sp' }, h('b', {}, a.agent_id), h('strong', {}, a.score == null ? 'Score —' : `Score ${a.score}/100`)),
        h('div', { class: 'small muted' }, `Échantillon : ${a.sample_size} tâches · confiance ${a.confidence}`),
        h('div', { class: 'small' }, `Réussite : ${a.success_rate == null ? '—' : a.success_rate + '%'} · relances : ${a.retries} · durée moyenne : ${a.avg_duration_ms == null ? '—' : Math.round(a.avg_duration_ms / 1000) + ' s'}`),
        h('div', { class: 'small' }, `Tokens journalisés : ${a.tokens || '—'} · appels fournisseur : ${a.provider_calls || '—'}`))) : h('div', { class: 'alert' }, 'Pas encore assez de tâches enregistrées pour établir un classement.');
      const history = hist.length ? hist.map(x => h('div', { class: 'task small' }, `${new Date(x.created).toLocaleString()} · ${x.id}`)) : h('p', { class: 'muted' }, 'Aucun instantané enregistré.');
      root.replaceChildren(metrics,
        h('div', { class: 'row' }, h('button', { class: 'primary', onclick: async () => { await api('POST', `/api/projects/${S.project.id}/benchmarks/snapshot`, {}); await render(); } }, 'Enregistrer un instantané'), h('span', { class: 'muted small' }, `Mesuré : ${new Date(report.generated_at).toLocaleString()}`)),
        h('h2', {}, 'Performances par IA'), agents,
        h('h2', {}, 'Méthodologie et limites'), h('p', { class: 'muted' }, report.methodology.score), h('ul', {}, ...report.methodology.limitations.map(x => h('li', {}, x))),
        h('h2', {}, 'Instantanés précédents'), ...history);
    } catch (e) { root.replaceChildren(h('div', { class: 'alert err' }, e.message)); }
  };
  main.append(h('h1', {}, 'OPS AI PERFORMANCE & BENCHMARK ENGINE'), h('p', { class: 'muted' }, 'Mesure les résultats réellement enregistrés. Les scores sont explicables et indiquent la taille de leur échantillon.'), root);
  render(); return { refresh: render };
};

SCREENS.orchestration = (main) => {
  const root = h('div');
  let activePlanId = null;
  let timer = null;
  main.append(h('h1', {}, 'OPS AUTONOMOUS AI EXECUTION ENGINE'), h('p', { class: 'muted' }, 'Les agents exécutent réellement leurs tâches via le runtime OPS. Les dépendances attendent un résultat reçu et, si nécessaire, les approbations des fichiers.'), root);
  const sample = [
    { id: 'architecture', title: 'Définir l’architecture', instruction: 'Analyser le projet et définir les contrats techniques.', agent_id: 'architect', depends_on: [] },
    { id: 'implementation', title: 'Implémenter les modules', instruction: 'Coder les modules selon les contrats validés, inspecter les fichiers et livrer les modifications réelles.', agent_id: 'coder', depends_on: ['architecture'] },
    { id: 'tests', title: 'Vérifier et tester', instruction: 'Auditer les changements et ajouter des tests de non-régression.', agent_id: 'quality', depends_on: ['implementation'] }
  ];
  const title = h('input', { value: 'Nouvelle production OPS', placeholder: 'Titre du plan' });
  const tasks = h('textarea', { rows: '12', style: 'width:100%;font-family:monospace', value: JSON.stringify(sample, null, 2) });
  const status = h('div', { class: 'stack' });
  const renderPlan = (r) => {
    activePlanId = r.plan.id;
    const taskNodes = r.tasks.map((t) => h('div', { class: 'task' },
      h('div', { class: 'row sp' }, h('b', {}, `${t.local_id} · ${t.title}`), pill(t.status)),
      h('div', { class: 'small muted' }, `Agent : ${t.agent_id || 'à attribuer'} · Tentatives : ${t.attempts || 0} · Dépendances : ${t.depends_on.join(', ') || 'aucune'}`),
      t.execution_run_id && h('div', { class: 'small muted' }, `Exécution : ${t.execution_run_id}`),
      t.approval_count > 0 && h('div', { class: 'small' }, `Approbations de fichiers : ${t.approval_count} · consulte la section Approbations du projet.`),
      t.error && h('div', { class: 'alert err small' }, t.error),
      t.result && h('details', {}, h('summary', {}, 'Afficher le résultat livré'), h('pre', { class: 'small', style: 'white-space:pre-wrap;overflow-wrap:anywhere;max-height:280px;overflow:auto' }, t.result)),
      ['error', 'blocked'].includes(t.status) && h('button', { class: 'small', onclick: guard(async () => renderPlan(await api('POST', `/api/orchestration/${r.plan.id}/tasks/${t.local_id}/retry`, {}))) }, 'Relancer cette tâche')
    ));
    const controls = [];
    if (['draft', 'paused', 'attention', 'waiting_approval'].includes(r.plan.status)) controls.push(h('button', { class: 'primary', onclick: guard(async () => renderPlan(await api('POST', `/api/orchestration/${r.plan.id}/start`, {}))) }, r.plan.status === 'draft' ? 'Démarrer les IA' : 'Reprendre l’exécution'));
    if (r.plan.status === 'running') controls.push(h('button', { class: 'danger', onclick: guard(async () => renderPlan(await api('POST', `/api/orchestration/${r.plan.id}/pause`, {}))) }, 'Mettre en pause'));
    controls.push(h('button', { class: 'small', onclick: guard(async () => renderPlan(await api('GET', `/api/orchestration/${r.plan.id}`))) }, 'Actualiser'));
    const logNodes = (r.logs || []).slice(-30).map((x) => h('div', { class: 'small task' }, h('div', { class: 'row sp' }, h('b', {}, x.level.toUpperCase()), h('span', { class: 'muted' }, fmt(x.created))), h('div', {}, x.message)));
    status.replaceChildren(h('div', { class: 'card' },
      h('div', { class: 'row sp' }, h('b', {}, r.plan.title), pill(r.plan.status)),
      h('p', { class: 'small muted' }, `Total : ${r.summary.total} · En attente : ${r.summary.waiting} · En exécution : ${r.summary.executing} · À approuver : ${r.summary.review} · Terminées : ${r.summary.done} · Erreurs : ${r.summary.error} · Bloquées : ${r.summary.blocked}`),
      h('div', { class: 'row', style: 'flex-wrap:wrap' }, ...controls),
      ...taskNodes,
      h('details', { class: 'card' }, h('summary', {}, `Journal d’exécution (${(r.logs || []).length})`), logNodes.length ? h('div', { class: 'stack' }, ...logNodes) : h('p', { class: 'muted' }, 'Aucun événement pour le moment.'))
    ));
  };
  const create = guard(async () => {
    let parsed; try { parsed = JSON.parse(tasks.value); } catch { throw new Error('Le JSON des tâches est invalide.'); }
    const r = await api('POST', `/api/projects/${S.project.id}/orchestration`, { title: title.value, tasks: parsed });
    renderPlan(r); toast('Plan créé. Appuie sur « Démarrer les IA » pour lancer les vraies exécutions.');
  });
  const refresh = guard(async () => {
    const plans = await api('GET', `/api/projects/${S.project.id}/orchestration`);
    const entries = plans.map((p) => h('div', { class: 'row sp' }, h('span', {}, `${p.title} · ${p.status} · ${fmt(p.created)}`), h('button', { class: 'small', onclick: guard(async () => renderPlan(await api('GET', `/api/orchestration/${p.id}`))) }, 'Ouvrir')));
    status.replaceChildren(h('div', { class: 'card' }, h('b', {}, 'Plans récents'), plans.length ? h('div', { class: 'stack' }, ...entries) : h('p', { class: 'muted' }, 'Aucun plan enregistré.')));
  });
  root.append(
    h('div', { class: 'card' }, h('h2', {}, 'Créer un plan de production'), h('label', {}, 'Titre'), title, h('label', {}, 'Tâches au format JSON'), tasks,
      h('p', { class: 'small muted' }, 'Chaque tâche possède un id, un title, une instruction, un agent_id facultatif et des dépendances depends_on. Les cycles sont refusés. Les agents exécutent une tâche par run OPS ; les scripts du projet ne sont jamais lancés automatiquement par ce moteur.'),
      h('div', { class: 'row' }, h('button', { class: 'primary', onclick: create }, 'Créer le plan'), h('button', { class: 'small', onclick: () => { tasks.value = JSON.stringify(sample, null, 2); } }, 'Charger exemple'))),
    h('div', { class: 'card' }, h('div', { class: 'row sp' }, h('h2', {}, 'Suivi des productions'), h('button', { class: 'small', onclick: refresh }, 'Actualiser')), status)
  );
  refresh();
  timer = setInterval(async () => {
    if (!activePlanId) return;
    try {
      const r = await api('GET', `/api/orchestration/${activePlanId}`);
      if (['running', 'waiting_approval'].includes(r.plan.status)) renderPlan(r);
    } catch { /* l’écran reste utilisable même si une actualisation échoue */ }
  }, 2500);
  return { stop: () => { if (timer) clearInterval(timer); } };
};

SCREENS['control-center'] = (main) => {
  const root=h('div'); main.append(h('h1',{},'OPS AUTONOMOUS AI CONTROL CENTER'),h('p',{class:'muted'},'Vue centrale des projets, agents, moteurs et transmissions. Actualisation automatique à la réception des événements OPS et toutes les 15 secondes.'),root);
  const load=guard(async()=>{
    const r=await api('GET','/api/control-center'),s=r.summary;
    const stat=(n,l)=>h('div',{class:'card stat'},h('b',{},String(n)),h('span',{},l));
    const projectTable=h('div',{class:'card'},h('h2',{},'Projets OPS'),r.projects.length?h('table',{},h('tr',{},['Projet','Tâches','Actives','Bloquées','Transmissions','Moteurs'].map(x=>h('th',{},x))),r.projects.map(p=>h('tr',{},h('td',{},h('b',{},p.name)),h('td',{},p.tasks),h('td',{},p.active),h('td',{},p.blocked),h('td',{},p.handoffs),h('td',{},p.engines)))):h('p',{class:'muted'},'Aucun projet actif.'));
    const agentCards=h('div',{class:'grid'},...r.agents.map(a=>h('div',{class:'card'},h('div',{class:'row sp'},h('b',{},a.name),pill(a.enabled?'activé':'désactivé')),h('div',{class:'small muted'},a.role||'Agent OPS'),h('p',{},`En cours : ${a.running} · Bloquées : ${a.failed} · Boîte de réception : ${a.pending_inbox} · Terminées : ${a.done}`))));
    const engineTable=h('div',{class:'card'},h('h2',{},'Moteurs connectés'),r.engines.length?h('table',{},h('tr',{},['Moteur','Type','État','Dernier contrôle'].map(x=>h('th',{},x))),r.engines.map(e=>h('tr',{},h('td',{},e.name),h('td',{},e.kind||'—'),h('td',{},pill(e.status||'inconnu')),h('td',{},fmt(e.last_check))))):h('p',{class:'muted'},'Aucun moteur externe enregistré.'));
    const studio=h('div',{class:'card'},h('h2',{},'IA du Studio'),r.studio_ais.length?h('div',{class:'row',style:'flex-wrap:wrap'},...r.studio_ais.map(a=>h('span',{class:'pill'},`${a.name} · ${a.status||'état inconnu'}`))):h('p',{class:'muted'},'Aucune IA de Studio enregistrée.'));
    const alerts=h('div',{class:'card'},h('h2',{},'Centre d’alertes'),r.alerts.length?h('div',{class:'stack'},...r.alerts.map(a=>h('div',{class:'alert '+(a.severity==='high'?'err':'warn')},h('b',{},a.code),h('div',{},a.message)))):h('p',{class:'muted'},'Aucune alerte globale détectée.'));
    const events=h('div',{class:'card'},h('h2',{},'Flux récent de collaboration'),r.recent_events.length?h('div',{class:'stack'},...r.recent_events.slice(0,30).map(e=>h('div',{class:'task'},h('div',{class:'row sp'},h('b',{},e.type),h('span',{class:'small muted'},fmt(e.created))),h('div',{class:'small'},`${e.from_agent}${e.to_agent?' → '+e.to_agent:''} · ${r.projects.find(p=>p.id===e.project_id)?.name||e.project_id}`),h('div',{class:'small muted'},String(e.payload||'').slice(0,220))))):h('p',{class:'muted'},'Aucun événement enregistré.'));
    root.replaceChildren(h('div',{class:'grid'},stat(s.projects,'Projets actifs'),stat(`${s.agents_enabled}/${s.agents}`,'Agents activés'),stat(s.active,'Tâches actives'),stat(s.blocked,'Tâches bloquées'),stat(s.pending_handoffs,'Transmissions en attente'),stat(`${s.engines_online}/${s.engines}`,'Moteurs en ligne'),stat(s.providers_ready,'Fournisseurs prêts')),alerts,projectTable,h('div',{class:'card'},h('h2',{},'Charge de travail des agents'),agentCards),engineTable,studio,events,h('div',{class:'row sp',style:'margin-top:12px'},h('span',{class:'small muted'},`Dernière actualisation : ${fmt(r.generated_at)} · Flux persistant + WebSocket OPS`),h('button',{class:'primary',onclick:load},'Actualiser maintenant')));
  });
  load(); const timer=setInterval(load,15000); return {refresh:load,stop:()=>clearInterval(timer)};
};

SCREENS.dashboard = (main) => {
  const box = h('div'); main.append(h('h1', {}, 'Tableau de bord OPS'), box);
  const load = guard(async () => {
    const [st, prog] = await Promise.all([api('GET', '/api/state'), api('GET', `/api/projects/${S.project.id}/progress`)]);
    S.state = st;
    const stat = (n, l) => h('div', { class: 'card stat' }, h('b', {}, n), h('span', {}, l));
    box.replaceChildren(needsProvider(),
      h('div', { class: 'grid' }, stat(`${st.providers_ready}/${st.providers}`, 'Fournisseurs IA prêts'), stat(st.web.configured ? st.web.provider : 'non configurée', 'Recherche Web'), stat(st.projects, 'Projets'), stat(st.active_runs, 'Exécutions en cours'), stat(st.pending_approvals, 'Autorisations en attente'), stat(st.tasks_error, 'Tâches en erreur')),
      h('h3', { style: 'margin-top:18px' }, `Projet : ${prog.project.name}`),
      h('div', { class: 'grid' },
        h('div', { class: 'card' }, h('h2', {}, 'Avancement'), h('p', {}, `${prog.files} fichier(s)`), h('p', { class: 'muted' }, Object.entries(prog.task_counts).map(([k, v]) => `${k} : ${v}`).join(' · ') || 'Aucune tâche'), prog.last_run && h('p', { class: 'small' }, 'Dernière exécution : ', pill(prog.last_run.status), ' ', fmt(prog.last_run.created)),
          h('p', { class: 'small' }, 'Dernière version : ', prog.last_version ? `${prog.last_version.label} (${fmt(prog.last_version.created)})` : 'aucune'), h('p', { class: 'small' }, 'Dernier test : ', prog.last_test ? [pill(prog.last_test.passed ? 'ok' : 'failed'), ' ', fmt(prog.last_test.ts)] : 'aucun')),
        h('div', { class: 'card' }, h('h2', {}, 'Alertes et suggestions'), h('ul', {}, prog.suggestions.map((s) => h('li', {}, s))), h('button', { class: 'small', onclick: guard(async (e) => { e.target.disabled = true; try { const r = await api('POST', `/api/projects/${S.project.id}/suggest`); modal('Suggestions du coordinateur', md(r.suggestions)); } finally { e.target.disabled = false; } }) }, 'Demander des suggestions à l’IA')),
        h('div', { class: 'card' }, h('h2', {}, 'Dépendances'), h('p', { class: 'small muted' }, 'Déclarées : ' + (prog.dependencies.declared.map((d) => d.name || d).join(', ') || 'aucune')), h('p', { class: 'small muted' }, 'npm : ' + (Object.keys(prog.dependencies.npm).join(', ') || 'aucune')))));
  });
  load();
  return { refresh: load };
};

SCREENS.chat = (main) => {
  let run = null, poll = null;
  const msgsEl = h('div', { class: 'msgs' }), live = h('div'), input = h('textarea', { rows: '2', placeholder: 'Donnez une instruction en langage naturel…', onkeydown: (e) => { if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) { e.preventDefault(); send(); } } });
  const modeSel = h('select', { onchange: (e) => { S.chatMode = e.target.value; load(); paintAgent(); } }, h('option', { value: 'team', selected: S.chatMode === 'team' }, 'Équipe (orchestrateur)'), h('option', { value: 'agent', selected: S.chatMode === 'agent' }, 'Agent direct'));
  const agentSel = h('select', { onchange: (e) => { S.chatAgent = e.target.value; load(); } }, S.agents.map((a) => h('option', { value: a.id, selected: a.id === S.chatAgent }, a.name)));
  const paintAgent = () => { agentSel.style.display = S.chatMode === 'agent' ? '' : 'none'; };
  const sendBtn = h('button', { class: 'primary', onclick: () => send() }, 'Envoyer'), stopBtn = h('button', { class: 'danger', style: 'display:none', onclick: guard(async () => { await api('POST', `/api/runs/${run.id}/cancel`); }) }, 'Arrêter');
  main.append(h('div', { class: 'chat' }, h('div', { class: 'row', style: 'margin-bottom:8px' }, h('h1', { style: 'margin:0;flex:1' }, 'Chat central'), modeSel, agentSel), needsProvider(), msgsEl, live, h('div', { class: 'composer' }, input, sendBtn, stopBtn)));
  paintAgent();
  const load = guard(async () => {
    const ms = await api('GET', `/api/messages?project_id=${S.project.id}&agent_id=${S.chatMode === 'agent' ? S.chatAgent : 'team'}`);
    msgsEl.replaceChildren(...ms.map((m) => h('div', { class: 'msg ' + m.role }, h('div', { class: 'who' }, m.role === 'user' ? 'Vous' : (S.agents.find((a) => a.id === m.agent_id)?.name || 'OPS COORDINATOR')), m.role === 'user' ? h('div', {}, m.content) : md(m.content))));
    if (!ms.length) msgsEl.append(h('div', { class: 'muted' }, S.chatMode === 'team' ? "Mode équipe : le coordinateur planifie, répartit le travail entre les agents, organise la relecture croisée et vous remet un rapport. Mentionnez le projet ou utilisez le sélecteur en haut." : 'Conversation directe avec un seul agent.'));
    msgsEl.scrollTop = msgsEl.scrollHeight;
  });
  const paintLive = guard(async () => {
    if (!run) { live.replaceChildren(); return; }
    const r = await api('GET', `/api/runs/${run.id}`); run = r;
    const act = r.active;
    stopBtn.style.display = act ? '' : 'none'; sendBtn.disabled = act;
    if (!act) { clearInterval(poll); poll = null; live.replaceChildren(); load(); refreshBadges(); run = null; return; }
    live.replaceChildren(h('div', { class: 'live' }, h('div', { class: 'row' }, h('span', { class: 'spin' }), h('b', {}, 'Équipe au travail'), pill(r.status)), r.plan?.summary && h('div', { class: 'small muted' }, r.plan.summary),
      r.tasks.map((t) => h('div', { class: 'task' }, pill(t.status), h('span', { class: 'nm' }, `${S.agents.find((a) => a.id === t.agent_id)?.name || t.agent_id} — ${t.title}`), t.round > 0 && h('span', { class: 'pill warn' }, 'correction')))));
  });
  const send = guard(async () => {
    const text = input.value.trim(); if (!text) return;
    const r = await api('POST', '/api/chat', { project_id: S.project.id, text, mode: S.chatMode, agent_id: S.chatMode === 'agent' ? S.chatAgent : undefined });
    input.value = ''; run = { id: r.run_id }; await load(); await paintLive(); clearInterval(poll); poll = setInterval(paintLive, 1500);
  });
  load();
  api('GET', '/api/runs?project_id=' + S.project.id).then((rs) => { const a = rs.find((x) => !['done', 'failed', 'partial', 'cancelled', 'interrupted'].includes(x.status)); if (a) { run = { id: a.id }; paintLive(); poll = setInterval(paintLive, 1500); } }).catch(() => {});
  return { stop: () => clearInterval(poll), refresh: () => { if (run) paintLive(); } };
};

SCREENS.agents = (main) => {
  const grid = h('div', { class: 'grid' }); main.append(h('h1', {}, 'Agents OPS'), h('p', { class: 'muted' }, 'Chaque agent peut utiliser un fournisseur/modèle différent : ils collaborent via le protocole commun OPS (contexte partagé, résultats transmis, relecture croisée).'), grid);
  const load = guard(async () => {
    const [agents, provs] = await Promise.all([api('GET', `/api/agents?project_id=${S.project?.id || ''}`), api('GET', '/api/providers')]);
    S.agents = agents;
    grid.replaceChildren(...agents.map((a) => {
      const ps = h('select', {}, h('option', { value: '' }, '(fournisseur par défaut)'), provs.providers.map((p) => h('option', { value: p.id, selected: p.id === a.provider_id }, p.name)));
      const model = h('input', { placeholder: 'modèle (optionnel)', value: a.model || '' });
      const prompt = h('textarea', { rows: '5' }); prompt.value = a.system_prompt;
      const en = h('input', { type: 'checkbox', checked: a.enabled ? true : null });
      return h('div', { class: 'card' }, h('h2', {}, a.name), h('p', { class: 'muted small' }, a.role),
        h('p', { class: 'small' }, `Tâches : ${a.stats.done} réussies · `, h('span', { style: a.stats.error ? 'color:var(--red)' : '' }, `${a.stats.error} en erreur`), a.stats.running ? ` · ${a.stats.running} en cours` : ''),
        h('label', {}, 'Fournisseur'), ps, h('label', {}, 'Modèle'), model, h('label', { class: 'inline' }, en, 'Activé'),
        h('details', {}, h('summary', {}, 'Instructions (prompt système)'), prompt),
        h('div', { class: 'row', style: 'margin-top:10px' },
          h('button', { class: 'small', onclick: guard(async () => { await api('PUT', `/api/agents/${a.id}`, { provider_id: ps.value, model: model.value, enabled: en.checked, system_prompt: prompt.value }); toast('Agent enregistré'); load(); }) }, 'Enregistrer'),
          h('button', { class: 'small', onclick: () => { S.chatMode = 'agent'; S.chatAgent = a.id; go('chat'); } }, 'Parler'),
          h('button', { class: 'small', onclick: guard(async () => { const hs = await api('GET', `/api/agents/${a.id}/history?project_id=${S.project?.id || ''}`); modal(`${a.name} — espace de travail`, h('h3', {}, 'Notes / mémoire de travail'), hs.notes.length ? h('ul', {}, hs.notes.map((n) => h('li', {}, h('b', {}, n.key + ' : '), n.value))) : h('p', { class: 'muted' }, 'Aucune note.'), h('h3', {}, 'Historique des tâches'), h('table', {}, hs.tasks.map((t) => h('tr', {}, h('td', {}, pill(t.status)), h('td', {}, t.title), h('td', { class: 'small muted' }, fmt(t.created)), h('td', { class: 'small', style: 'color:var(--red)' }, t.error || ''))))); }) }, 'Historique')));
    }));
  });
  load(); return { refresh: load };
};

SCREENS.manager = (main) => {
  const box = h('div');
  main.append(h('h1', {}, 'OPS INTELLIGENT PROJECT MANAGER'), h('p', { class:'muted' }, 'Surveillance des tâches, dépendances, agents disponibles et ressources réservées. Les recommandations ne modifient rien sans action explicite.'), box);
  const load = guard(async () => {
    const r = await api('GET', `/api/projects/${S.project.id}/manager`);
    const metric = (label,value) => h('div',{class:'card'},h('div',{class:'muted small'},label),h('h2',{style:'margin:6px 0 0'},String(value)));
    const recs = r.recommendations.length ? h('div',{class:'card'},h('h2',{},'Alertes et recommandations'),h('div',{class:'stack'},r.recommendations.map(x=>h('div',{class:'alert '+(x.severity==='high'?'err':x.severity==='warning'?'warn':'info')},h('b',{},x.code+' · '+(x.title||'')),h('div',{class:'small'},x.message))))) : h('div',{class:'card'},'Aucun blocage détecté dans les données disponibles.');
    const taskTable = (rows, empty) => rows.length ? h('table',{},h('tr',{},['Tâche','Agent','État','Priorité suggérée'].map(x=>h('th',{},x))),rows.map(t=>h('tr',{},h('td',{},h('b',{},t.title),h('div',{class:'muted small'},t.source+' · '+t.id)),h('td',{},t.agent_id||'—'),h('td',{},pill(t.status)),h('td',{},t.suggested_priority||'à examiner')))) : h('p',{class:'muted'},empty);
    const agents = h('div',{class:'card'},h('h2',{},'Charge des agents'),h('table',{},h('tr',{},['Agent','Actif','En attente','File'].map(x=>h('th',{},x))),r.agents.map(a=>h('tr',{},h('td',{},a.name||a.id),h('td',{},String(a.running)),h('td',{},String(a.pending)),h('td',{},String(a.queued))))));
    const dispatchAgent = h('select',{},h('option',{value:''},'Choisir un agent disponible'),r.available_agents.map(a=>h('option',{value:a.id},`${a.name} · ${a.role||a.id}`)));
    const dispatchTitle = h('input',{placeholder:'Titre de la tâche à transmettre'}), dispatchBody = h('textarea',{rows:3,placeholder:'Instruction claire et livrable attendu'});
    box.replaceChildren(h('div',{class:'row',style:'flex-wrap:wrap'},metric('Progression observée',r.summary.completion_percent+'%'),metric('Tâches actives',r.summary.active),metric('En attente',r.summary.queued),metric('Bloquées',r.summary.blocked),metric('Anciennes',r.summary.stale),metric('Fichiers réservés',r.summary.active_file_claims)),recs,
      h('div',{class:'grid'},h('div',{class:'card'},h('h2',{},'File de travail'),taskTable(r.tasks.queue,'Aucune tâche en attente.')),h('div',{},agents,h('div',{class:'card',style:'margin-top:12px'},h('h2',{},'Transmettre une tâche'),h('p',{class:'small muted'},'Le gestionnaire ne lance pas de travail en secret : cette action crée une transmission visible dans la collaboration.'),dispatchAgent,dispatchTitle,dispatchBody,h('button',{class:'primary',style:'margin-top:8px',onclick:guard(async()=>{if(!dispatchAgent.value||!dispatchTitle.value.trim()||!dispatchBody.value.trim()){toast('Choisis un agent et complète la tâche.',true);return;}await api('POST',`/api/projects/${S.project.id}/manager/dispatch`,{to:dispatchAgent.value,title:dispatchTitle.value,instruction:dispatchBody.value});toast('Transmission créée');load();})},'Transmettre la tâche')))),
      h('div',{class:'card',style:'margin-top:12px'},h('h2',{},'Dépendances entre moteurs'),r.dependencies.length?h('table',{},h('tr',{},['Prérequis','Moteur dépendant','Contrat'].map(x=>h('th',{},x))),r.dependencies.map(d=>h('tr',{},h('td',{},d.prerequisite),h('td',{},d.dependent),h('td',{class:'small muted'},d.contract||'—')))):h('p',{class:'muted'},'Aucune dépendance moteur enregistrée.')),
      h('div',{class:'card',style:'margin-top:12px'},h('h2',{},'Tâches bloquées'),taskTable(r.tasks.blocked,'Aucune tâche bloquée.')),
      h('div',{class:'row',style:'margin-top:12px'},h('button',{class:'primary',onclick:load},'Actualiser le tableau de bord')));
  });
  load(); return { refresh:load };
};

SCREENS.supervisor = (main) => {
  const box=h('div');
  const objective=h('textarea',{rows:4,placeholder:'Décris le résultat à obtenir. Le Director va analyser le projet, créer des tâches spécialisées, puis lancer les IA…'});
  const objectiveTitle=h('input',{placeholder:'Nom de la mission (facultatif)'});
  const launch=guard(async()=>{if(!objective.value.trim()){toast('Décris d’abord l’objectif de la mission.',true);return;}const r=await api('POST',`/api/projects/${S.project.id}/supervisor/objective`,{objective:objective.value,title:objectiveTitle.value,autoStart:true});toast(`Mission créée : ${r.execution.summary.total} tâches distribuées aux IA.`);load('report');});
  main.append(h('h1',{},'OPS AUTONOMOUS AI SUPERVISOR'),h('p',{class:'muted'},'Le Director peut transformer un objectif en plan multi-agents et démarrer les exécutions réelles. Les propositions de fichiers restent soumises au mode d’approbation du projet.'),h('div',{class:'card'},h('h2',{},'Donner un objectif aux IA'),h('label',{},'Nom de mission'),objectiveTitle,h('label',{},'Objectif détaillé'),objective,h('p',{class:'small muted'},'Le Director répartit le travail entre les IA spécialisées, transmet les dépendances et lance le moteur d’exécution. Les tâches et résultats restent visibles.'),h('button',{class:'primary',onclick:launch},'Créer et lancer la mission autonome')),box);
  const load=guard(async(mode='report')=>{
    const r=mode==='report'?await api('GET',`/api/projects/${S.project.id}/supervisor`):await api('POST',`/api/projects/${S.project.id}/supervisor/scan`,{mode});
    const metrics=h('div',{class:'row',style:'flex-wrap:wrap'},...[
      ['Constats',r.summary.findings],['Critiques',r.summary.critical],['Alertes',r.summary.warning],['Transmissions en attente',r.summary.pending_handoffs],['Fichiers réservés',r.summary.active_claims]
    ].map(([k,v])=>h('div',{class:'card'},h('div',{class:'small muted'},k),h('h2',{},String(v)))));
    const findings=r.findings.length?h('div',{class:'stack'},r.findings.map(f=>h('div',{class:'alert '+(f.severity==='high'?'err':f.severity==='warning'?'warn':'info')},h('b',{},`${f.code} · ${f.title||f.task_id||''}`),h('div',{class:'small'},f.message),h('div',{class:'small muted'},`${f.source||'supervision'} · ${f.agent_id||'agent non défini'}`)))):h('p',{class:'muted'},'Aucun constat détecté dans les données enregistrées.');
    box.replaceChildren(metrics,h('div',{class:'card',style:'margin-top:12px'},h('h2',{},'Diagnostic du superviseur'),findings),h('div',{class:'card',style:'margin-top:12px'},h('h2',{},'Actions de supervision'),h('p',{class:'small muted'},'Observer : analyse sans créer de tâche. Assistance : peut transmettre au maximum trois analyses de tâches bloquées par scan, sans toucher aux tâches sources.'),h('div',{class:'row',style:'flex-wrap:wrap'},h('button',{class:'primary',onclick:guard(()=>load('observe'))},'Lancer un scan · observation'),h('button',{onclick:guard(()=>load('assist'))},'Lancer un scan · assistance')),
      r.scan?h('p',{class:'small muted'},`Dernier scan : ${r.scan.mode} · ${r.scan.escalations.length} escalade(s) · aucune réaffectation automatique.`):null),h('div',{class:'small muted',style:'margin-top:10px'},`Dépendances moteur suivies : ${r.dependency_count} · Rapport généré : ${fmt(r.generated_at)}`));
  });
  load(); return {refresh:load};
};

SCREENS.production = (main) => {
  let selected = null, poll = null;
  const title = h('input', { placeholder: 'Nom du jeu / de la production', value: S.project.name });
  const brief = h('textarea', { rows: '7', placeholder: 'Décris le jeu à construire : genre, monde, gameplay, personnages, moteurs, plateformes, exigences…' });
  const constraints = h('textarea', { rows: '3', placeholder: 'Contraintes supplémentaires (une par ligne) : préserver les fonctions, mobile/PC, performances…' });
  const list = h('div'), detail = h('div');
  const refreshList = guard(async () => {
    const rows = await api('GET', `/api/projects/${S.project.id}/production`);
    list.replaceChildren(...rows.map(p => h('div', { class: 'card', style: 'margin-bottom:8px;cursor:pointer;' + (selected === p.id ? 'border-color:var(--accent)' : ''), onclick: () => { selected = p.id; refreshList(); refreshDetail(); } }, h('div', { class: 'row' }, h('b', {}, p.title), pill(p.status)), h('div', { class: 'small muted' }, fmt(p.created), ' · Pipeline ', p.id.slice(-9)))));
    if (!rows.length) list.append(h('p', { class: 'muted' }, 'Aucune production lancée pour ce projet.'));
    if (!selected && rows[0]) selected = rows[0].id;
  });
  const refreshDetail = guard(async () => {
    if (!selected) { detail.replaceChildren(); return; }
    const p = await api('GET', `/api/production/${selected}`);
    const run = p.run;
    let releaseGate = null;
    if (['ready_for_review', 'quality_failed', 'partial', 'development_failed'].includes(p.status)) {
      try { releaseGate = await api('GET', `/api/production/${selected}/release-gate`); } catch { /* le détail de production reste disponible si le contrôle est indisponible */ }
    }
    detail.replaceChildren(h('div', { class: 'card' }, h('div', { class: 'row' }, h('h2', { style: 'margin:0;flex:1' }, p.title), pill(p.status)),
      h('p', { class: 'small muted' }, `Pipeline : ${p.id} · Exécution IA : ${p.run_id}`),
      h('p', {}, `Sauvegarde de référence : ${p.baseline_version_id}`),
      p.final_version_id && h('p', {}, `Version livrable : ${p.final_version_id}`),
      p.checks && h('div', { class: p.checks.passed ? 'alert' : 'alert err' }, `Contrôles statiques : ${p.checks.passed ? 'réussis' : 'échec'} · ${p.checks.summary?.checked ?? 0} fichiers analysés · ${p.checks.summary?.failed ?? 0} erreur(s) · ${p.checks.summary?.regression_findings ?? 0} alerte(s) de régression`),
      releaseGate && h('div', { class: 'card' }, h('div', { class: 'row' }, h('b', {}, 'OPS RELEASE GATE'), pill(releaseGate.status)), h('p', { class: 'small muted' }, `${releaseGate.summary.passed}/${releaseGate.summary.total} contrôles réussis · ${releaseGate.summary.review} à vérifier · ${releaseGate.summary.blocked} bloquant(s)`), ...releaseGate.checks.map(c => h('div', { class: 'row', style: 'justify-content:space-between;border-top:1px solid var(--line);padding:6px 0' }, h('span', { class: 'small' }, c.detail), pill(c.status))), h('p', { class: 'small muted' }, releaseGate.limitations[2])),
      p.checks?.runtime && h('div', { class: p.checks.runtime.passed ? 'alert' : 'alert err' }, `Scripts du projet : ${p.checks.runtime.passed ? 'réussis' : 'échec'} · ${p.checks.runtime.executions.map(x => `${x.script} : ${x.passed ? 'OK' : 'ÉCHEC'}`).join(' · ')}`),
      ['partial', 'development_failed', 'quality_failed'].includes(p.status) && h('div', { class: 'card' }, h('b', {}, 'Reprendre cette production'), h('p', { class: 'small muted' }, `OPS conservera les fichiers actuels, la sauvegarde de référence et l’historique, puis demandera aux IA de poursuivre uniquement le travail restant. Reprises : ${p.brief?.resume_count || 0}.`), h('button', { class: 'primary', onclick: guard(async (e) => { if (!confirm('Reprendre cette production à partir de l’état actuel du projet ?')) return; e.target.disabled = true; try { const r = await api('POST', `/api/production/${selected}/resume`, {}); toast('Production reprise · ' + r.run_id); await refreshList(); await refreshDetail(); } finally { e.target.disabled = false; } }) }, 'Reprendre la production')), 
      ['ready_for_review', 'quality_failed'].includes(p.status) && h('div', { class: 'card' }, h('b', {}, 'Validation réelle du projet'), h('p', { class: 'small muted' }, 'Lance npm test et/ou npm run build du projet. Cette action exécute du code : elle exige que « Autoriser l’exécution de code » soit activé dans les paramètres du projet.'), h('button', { class: 'primary', onclick: guard(async (e) => { if (!confirm('Exécuter les scripts npm test/build de ce projet sur le serveur ?')) return; e.target.disabled = true; try { const r = await api('POST', `/api/production/${selected}/execute-checks`, {}); toast(r.runtime.passed ? 'Tests du projet réussis' : 'Échec des scripts du projet', !r.runtime.passed); await refreshDetail(); await refreshList(); } finally { e.target.disabled = false; } }) }, 'Exécuter les tests réels du projet')),
      run && h('div', {}, h('h3', {}, 'Équipe IA'), h('p', { class: 'small' }, `État de l’exécution : ${run.status}`), run.plan?.summary && h('p', { class: 'muted small' }, run.plan.summary), run.tasks?.map(t => h('details', { class: 'task' }, h('summary', {}, pill(t.status), ' ', t.agent_id, ' — ', t.title), t.error && h('div', { class: 'alert err' }, t.error), t.result && md(t.result))), run.report && h('div', {}, h('h3', {}, 'Rapport final'), md(run.report))),
      h('p', { class: 'muted small' }, '« Prêt pour revue » signifie que les contrôles automatiques ont réussi ; vérifie les livrables et les propositions de fichiers avant publication.')));
    clearInterval(poll);
    if (['running', 'awaiting_approval'].includes(p.status)) poll = setInterval(() => { refreshDetail(); refreshList(); }, 2500);
  });
  main.append(h('h1', {}, 'OPS AUTONOMOUS PRODUCTION'), needsProvider(),
    h('div', { class: 'card' }, h('h3', {}, 'Nouveau jeu / nouvelle production'), h('label', {}, 'Titre'), title, h('label', {}, 'Cahier des charges'), brief, h('label', {}, 'Contraintes'), constraints,
      h('p', { class: 'muted small' }, 'OPS sauvegarde le projet, mobilise les agents et moteurs, puis lance les contrôles. Les propositions de fichiers restent soumises au mode d’approbation du projet.'),
      h('button', { class: 'primary', onclick: guard(async () => { if (!brief.value.trim()) { toast('Décris le jeu à produire.', true); return; } const r = await api('POST', `/api/projects/${S.project.id}/production`, { title: title.value, brief: brief.value, constraints: constraints.value.split('\n').map(x => x.trim()).filter(Boolean) }); selected = r.id; toast('Production lancée · ' + r.id); brief.value = ''; await refreshList(); await refreshDetail(); }) }, 'Lancer la production autonome')),
    h('div', { class: 'row', style: 'align-items:flex-start;margin-top:12px' }, h('div', { style: 'flex:1 1 260px;min-width:0' }, h('h3', {}, 'Productions'), list), h('div', { style: 'flex:3 1 400px;min-width:0' }, detail)));
  refreshList().then(refreshDetail);
  return { stop: () => clearInterval(poll), refresh: () => { refreshList(); refreshDetail(); } };
};

SCREENS.team = (main) => {
  const list = h('div'), detail = h('div'); let sel = null, poll = null;
  const input = h('textarea', { rows: '3', placeholder: 'Instruction pour toute l’équipe (ex. « Ajoute un menu pause à OPÉRATION SURVIVANT 3D »)' });
  main.append(h('h1', {}, 'Mode équipe'), needsProvider(), h('div', { class: 'card' }, input, h('div', { class: 'row', style: 'margin-top:8px' }, h('button', { class: 'primary', onclick: guard(async () => { const t = input.value.trim(); if (!t) return; const r = await api('POST', '/api/chat', { project_id: S.project.id, text: t, mode: 'team' }); input.value = ''; sel = r.run_id; await loadList(); await loadDetail(); }) }, 'Lancer l’équipe'))), h('div', { class: 'row', style: 'align-items:flex-start;margin-top:12px' }, h('div', { style: 'flex:1 1 280px;min-width:0' }, h('h3', {}, 'Exécutions'), list), h('div', { style: 'flex:3 1 380px;min-width:0' }, detail)));
  const loadList = guard(async () => {
    const rs = await api('GET', '/api/runs?project_id=' + S.project.id);
    if (!sel && rs[0]) sel = rs[0].id;
    list.replaceChildren(...rs.map((r) => h('div', { class: 'card', style: 'margin-bottom:8px;cursor:pointer;' + (r.id === sel ? 'border-color:var(--accent)' : ''), onclick: () => { sel = r.id; loadList(); loadDetail(); } }, h('div', { class: 'row' }, pill(r.status), h('span', { class: 'small muted' }, fmt(r.created))), h('div', { class: 'small' }, r.instruction.slice(0, 110)))));
    if (!rs.length) list.append(h('p', { class: 'muted' }, 'Aucune exécution.'));
  });
  const loadDetail = guard(async () => {
    if (!sel) { detail.replaceChildren(); return; }
    const r = await api('GET', `/api/runs/${sel}`);
    const nameOf = (id) => S.agents.find((a) => a.id === id)?.name || id;
    detail.replaceChildren(h('div', { class: 'card' }, h('div', { class: 'row' }, h('h2', { style: 'margin:0;flex:1' }, 'Exécution'), pill(r.status),
      r.active && h('button', { class: 'danger small', onclick: guard(async () => { await api('POST', `/api/runs/${r.id}/cancel`); }) }, 'Annuler'),
      !r.active && r.tasks.some((t) => ['error', 'blocked', 'pending', 'cancelled'].includes(t.status)) && h('button', { class: 'small', onclick: guard(async () => { const x = await api('POST', `/api/runs/${r.id}/resume`); toast(`${x.relaunched} tâche(s) relancée(s)`); loadDetail(); }) }, 'Relancer les tâches en échec')),
      h('p', { class: 'small' }, r.instruction), r.plan?.by_rules && h('div', { class: 'alert' }, r.plan.summary), r.plan && !r.plan.by_rules && r.plan.summary && h('p', { class: 'muted small' }, 'Plan : ' + r.plan.summary),
      h('h3', {}, 'Tâches'), r.tasks.map((t) => h('details', { class: 'task', style: 'display:block' }, h('summary', {}, pill(t.status), ' ', nameOf(t.agent_id), ' — ', t.title, t.round > 0 ? ' (correction)' : '', t.depends_on.length ? ` · dépend de ${t.depends_on.length}` : ''), t.error && h('div', { class: 'alert err' }, t.error), t.result && md(t.result))),
      r.report && [h('h3', { style: 'margin-top:14px' }, 'Rapport final'), h('div', { class: 'msg' }, md(r.report))]));
    clearInterval(poll); if (r.active) poll = setInterval(() => { loadDetail(); loadList(); }, 2000);
  });
  loadList().then(loadDetail);
  return { stop: () => clearInterval(poll), refresh: () => { loadList(); loadDetail(); } };
};

function memBox(p) {
  const box = h('div');
  const show = guard(async () => {
    const ms = await api('GET', `/api/projects/${p.id}/memory`), k = h('input', { placeholder: 'clé' }), v = h('input', { placeholder: 'valeur' });
    box.replaceChildren(h('ul', {}, ms.map((m) => h('li', {}, h('b', {}, `${m.key} `), h('span', { class: 'muted small' }, `[${m.agent_id || 'vous'}] `), m.value, ' ', h('button', { class: 'small danger', onclick: guard(async () => { await api('DELETE', `/api/memory/${m.id}`); show(); }) }, '×')))), !ms.length && h('p', { class: 'muted small' }, 'Aucune entrée.'),
      h('div', { class: 'row' }, k, v, h('button', { class: 'small', onclick: guard(async () => { await api('POST', `/api/projects/${p.id}/memory`, { key: k.value, value: v.value }); show(); }) }, 'Ajouter')));
  });
  box.append(h('button', { class: 'small', onclick: show }, 'Afficher')); return box;
}

SCREENS.projects = (main) => {
  const box = h('div'); main.append(h('h1', {}, 'Gestionnaire de projets'), box);
  const download = guard(async (p) => { const r = await fetch(`/api/projects/${p.id}/export.zip`, { headers: { authorization: 'Bearer ' + S.token } }); if (!r.ok) throw new Error('Export impossible'); const a = h('a', { href: URL.createObjectURL(await r.blob()), download: p.id + '.zip' }); document.body.append(a); a.click(); a.remove(); });
  const load = guard(async () => {
    const ps = await api('GET', '/api/projects'); S.projects = ps.filter((p) => !p.archived); paintProjectSelect();
    const nameIn = h('input', { placeholder: 'Nom du projet' }), descIn = h('input', { placeholder: 'Description' });
    box.replaceChildren(h('div', { class: 'card', style: 'margin-bottom:12px' }, h('h2', {}, 'Nouveau projet'), h('div', { class: 'row' }, nameIn, descIn, h('button', { class: 'primary', onclick: guard(async () => { const p = await api('POST', '/api/projects', { name: nameIn.value, description: descIn.value }); S.project = p; toast('Projet créé'); await load(); }) }, 'Créer'))),
      h('div', { class: 'grid' }, ps.map((p) => {
        const wm = h('select', {}, h('option', { value: 'approval', selected: p.write_mode === 'approval' }, 'Autorisation pour chaque fichier'), h('option', { value: 'auto', selected: p.write_mode === 'auto' }, 'Auto (sauvegarde + annulable)'));
        const ex = h('input', { type: 'checkbox', checked: p.allow_exec ? true : null });
        const deps = h('input', { value: p.dependencies.map((d) => d.name || d).join(', '), placeholder: 'ex. Three.js, FBX SDK' });
        const ags = S.agents.map((a) => { const c = h('input', { type: 'checkbox', checked: p.agents.includes(a.id) ? true : null, 'data-a': a.id }); return h('label', { class: 'inline' }, c, a.name); });
        return h('div', { class: 'card', style: p.id === S.project?.id ? 'border-color:var(--accent)' : '' }, h('h2', {}, p.name), h('p', { class: 'muted small' }, p.description), h('code', { class: 'small' }, p.id),
          h('label', {}, 'Écriture des agents'), wm, h('label', { class: 'inline' }, ex, 'Autoriser l’exécution de code (npm test/build)'),
          h('label', {}, 'Dépendances déclarées'), deps, h('details', {}, h('summary', {}, 'Agents affectés'), ags),
          h('div', { class: 'row', style: 'margin-top:10px' },
            h('button', { class: 'small primary', onclick: guard(async () => {
              if (ex.checked && !p.allow_exec && !confirm("Autoriser l'exécution de code de ce projet sur le serveur ? Les scripts npm test/build s'exécuteront avec les droits du serveur (sans clés API).")) return;
              await api('PUT', `/api/projects/${p.id}`, { write_mode: wm.value, allow_exec: ex.checked, dependencies: deps.value.split(',').map((x) => x.trim()).filter(Boolean).map((name) => ({ name })), agents: ags.map((l) => l.firstChild).filter((c) => c.checked).map((c) => c.dataset.a) }); toast('Enregistré'); load();
            }) }, 'Enregistrer'),
            h('button', { class: 'small', onclick: () => { S.project = p; paintProjectSelect(); go('files'); } }, 'Ouvrir'), h('button', { class: 'small', onclick: () => download(p) }, 'Exporter ZIP'),
            h('button', { class: 'small danger', onclick: guard(async () => { if (!confirm(`Archiver « ${p.name} » ? Les fichiers et versions sont conservés.`)) return; await api('PUT', `/api/projects/${p.id}`, { archived: true }); if (S.project?.id === p.id) S.project = null; load(); }) }, 'Archiver')),
          h('details', {}, h('summary', {}, 'Mémoire partagée du projet'), memBox(p)));
      })));
  });
  load(); return { refresh: () => {} };
};

SCREENS.files = (main) => {
  let cur = null, dirty = false;
  const tree = h('div', { class: 'tree' }), ed = h('div', { class: 'editor' });
  main.append(h('div', { class: 'split' }, tree, ed));
  const loadTree = guard(async () => {
    const t = await api('GET', `/api/projects/${S.project.id}/files`);
    tree.replaceChildren(h('div', { class: 'row', style: 'padding:4px' }, h('button', { class: 'small', onclick: newFile }, '+ Fichier'), h('label', { class: 'small', style: 'margin:0;cursor:pointer;border:1px solid var(--line);border-radius:8px;padding:4px 8px' }, 'Importer', h('input', { type: 'file', multiple: true, style: 'display:none', onchange: upload }))),
      ...t.map((e) => h('div', { class: (e.type === 'dir' ? 'd ' : '') + (e.path === cur ? 'sel' : ''), style: `padding-left:${6 + 12 * (e.path.split('/').length - 1)}px`, title: e.path, onclick: () => e.type === 'file' && open(e.path) }, (e.type === 'dir' ? '📁 ' : '📄 ') + e.path.split('/').pop(), e.size != null ? h('span', { class: 'muted small' }, ' ' + (e.size > 1024 ? Math.round(e.size / 1024) + ' Ko' : e.size + ' o')) : '')));
    if (!t.length) tree.append(h('p', { class: 'muted small', style: 'padding:8px' }, 'Workspace vide. Créez ou importez des fichiers, ou laissez l’équipe en proposer.'));
  });
  const open = guard(async (p) => {
    if (dirty && !confirm('Modifications non enregistrées. Continuer ?')) return;
    const f = await api('GET', `/api/projects/${S.project.id}/file?path=${encodeURIComponent(p)}`); cur = p; dirty = false; loadTree();
    if (f.binary) { ed.replaceChildren(h('h2', {}, p), h('p', { class: 'muted' }, `Fichier binaire (${f.size} octets) : non modifiable ici.`), delBtn(p)); return; }
    const ta = h('textarea', { spellcheck: 'false', oninput: () => { dirty = true; } }); ta.value = f.content;
    ed.replaceChildren(h('div', { class: 'row' }, h('h2', { style: 'margin:0;flex:1' }, p), h('button', { onclick: guard(async () => { await api('POST', '/api/library/from-project', { project_id: S.project.id, path: p }); toast('Enregistré dans la bibliothèque (projet)'); }) }, '→ Bibliothèque'), h('button', { class: 'primary', onclick: guard(async () => { await api('PUT', `/api/projects/${S.project.id}/file`, { path: p, content: ta.value }); dirty = false; toast('Enregistré (sauvegarde créée, annulable)'); loadTree(); }) }, 'Enregistrer'), delBtn(p)), ta);
  });
  const delBtn = (p) => h('button', { class: 'danger', onclick: guard(async () => { if (!confirm(`Supprimer « ${p} » ? Une sauvegarde est conservée et la suppression reste annulable (Développement → Modifications).`)) return; await api('DELETE', `/api/projects/${S.project.id}/file?path=${encodeURIComponent(p)}&confirm=1`); cur = null; ed.replaceChildren(); loadTree(); }) }, 'Supprimer');
  const newFile = guard(async () => { const p = prompt('Chemin du nouveau fichier (ex. src/main.js)'); if (!p) return; await api('PUT', `/api/projects/${S.project.id}/file`, { path: p, content: '' }); await loadTree(); open(p); });
  const upload = guard(async (e) => { for (const f of e.target.files) { const buf = new Uint8Array(await f.arrayBuffer()); let bin = ''; for (let i = 0; i < buf.length; i += 0x8000) bin += String.fromCharCode(...buf.subarray(i, i + 0x8000)); await api('PUT', `/api/projects/${S.project.id}/file`, { path: f.name, content: btoa(bin), encoding: 'base64' }); } toast('Importé'); loadTree(); });
  loadTree(); return { refresh: (m) => { if (m?.type === 'files') loadTree(); } };
};

SCREENS.browser = (main) => {
  const tree = h('div', { class: 'tree' }), frame = h('iframe', { class: 'project-preview', title: 'Aperçu isolé du projet', sandbox: 'allow-scripts' });
  const pathBox = h('input', { value: 'index.html', placeholder: 'Chemin du fichier HTML à afficher' });
  const status = h('span', { class: 'muted small' }, 'Aperçu isolé : les scripts ne peuvent pas accéder à OPS ni à vos fichiers personnels.');
  const report = h('div', { class: 'card', style: 'margin:10px 0;display:none' });
  main.append(h('h1', {}, 'Navigateur IA — inspection et aperçu du projet'), h('p', { class: 'muted' }, 'Les agents peuvent inspecter l’arborescence et lire les fichiers via leur outil inspect_project. Ici, vous pouvez parcourir les fichiers et exécuter l’aperçu HTML dans un cadre isolé.'),
    h('div', { class: 'row', style: 'margin-bottom:10px' }, pathBox, h('button', { class: 'primary', onclick: guard(async () => preview(pathBox.value.trim())) }, 'Ouvrir l’aperçu'), h('button', { onclick: guard(async () => preview(pathBox.value.trim())) }, 'Actualiser'), h('button', { onclick: guard(async () => { const d=await api('GET',`/api/projects/${S.project.id}/inspection`); report.style.display='block'; report.replaceChildren(h('h3',{},'État réel du projet'),h('p',{},`${d.file_count} fichiers · ${(d.total_bytes/1024).toFixed(1)} Ko · ${d.assets.length} ressources détectées`),h('p',{},'Points d’entrée : '+(d.entrypoints.map(x=>x.path).join(', ')||'aucun détecté')),h('p',{},'Extensions : '+Object.entries(d.extensions).map(([k,v])=>`${k}: ${v}`).join(' · ')),h('p',{},`Mémoire : ${d.experience_memory.approved||0} validées · ${d.experience_memory.pending||0} en attente`)); toast('Inspection structurelle terminée'); }) }, 'Analyser la structure'), h('button', { onclick: guard(async () => { const r=await api('POST','/api/chat',{project_id:S.project.id,mode:'team',text:'Inspectez le projet avec inspect_project et read_file. Analysez les fichiers réels, les points d’entrée, les erreurs probables et les intégrations. Ne modifiez aucun fichier ; rendez un rapport factuel.'}); toast('Inspection IA lancée · '+r.run_id); go('history'); }) }, 'Inspection par les IA')),
    report, h('div', { class: 'browser-layout' }, tree, h('div', { class: 'browser-stage' }, frame)), status);
  const loadTree = guard(async () => {
    const files = await api('GET', `/api/projects/${S.project.id}/files`);
    tree.replaceChildren(h('b', { class: 'small' }, S.project.name), ...files.map((f) => h('div', { class: f.type === 'dir' ? 'd' : '', style: `padding-left:${6 + 10*(f.path.split('/').length-1)}px`, title:f.path, onclick: () => { if (f.type !== 'file') return; pathBox.value=f.path; if (/\.html?$/i.test(f.path)) preview(f.path); else openText(f.path); } }, (f.type === 'dir' ? '📁 ' : '📄 ') + f.path.split('/').pop())));
    if (!files.length) tree.append(h('p',{class:'muted small'},'Aucun fichier.'));
  });
  const openText = guard(async (path) => { const f = await api('GET', `/api/projects/${S.project.id}/file?path=${encodeURIComponent(path)}`); modal(path, f.binary ? `Fichier binaire · ${f.size} octets` : h('pre', {}, f.content.slice(0,50000))); });
  const preview = guard(async (path) => {
    if (!path) return; const f = await api('GET', `/api/projects/${S.project.id}/preview?path=${encodeURIComponent(path)}`);
    const root = path.includes('/') ? path.slice(0,path.lastIndexOf('/')) : '';
    const base = `/api/projects/${S.project.id}/preview-resource/?root=${encodeURIComponent(root)}&token=${encodeURIComponent(S.token)}`;
    let html = f.content;
    const meta = `<meta http-equiv="Content-Security-Policy" content="default-src 'self' data: blob:; connect-src 'none'; img-src 'self' data: blob:; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'">`;
    const baseTag = `<base href="${base}">`;
    if (/<head[^>]*>/i.test(html)) html = html.replace(/<head([^>]*)>/i, `<head$1>${meta}${baseTag}`); else html = `${meta}${baseTag}${html}`;
    frame.srcdoc = html; status.textContent = `Aperçu chargé : ${path} · hash ${f.hash.slice(0,12)} · environnement isolé`;
  });
  loadTree(); preview('index.html').catch(() => { status.textContent = 'Aucun index.html trouvé. Choisissez un fichier HTML dans l’arborescence.'; });
  return { refresh: (m) => { if (m?.type === 'files') loadTree(); } };
};

SCREENS.experience = (main) => {
  const box = h('div'), tabs = h('div',{class:'tabs'}); let status='pending';
  main.append(h('h1',{},'Mémoire d’expérience des IA'), h('p',{class:'muted'},'Les agents peuvent proposer des leçons tirées de leurs tâches. Seules les expériences validées sont réinjectées dans les prochains prompts de toute l’équipe OPS. Les propositions non vérifiées restent en attente.'), tabs, box);
  const load = guard(async () => {
    const rows = await api('GET',`/api/projects/${S.project.id}/experiences?status=${status}`);
    box.replaceChildren(...rows.map((x) => h('div',{class:'card',style:'margin-bottom:9px'},
      h('div',{class:'row sp'},h('b',{},x.domain),pill(x.status),h('span',{class:'small muted'},`${x.agent_id || 'Utilisateur'} · ${fmt(x.created)}`)),
      h('p',{},x.lesson), x.evidence && h('p',{class:'small muted'},'Preuve / origine : '+x.evidence),
      status==='pending' && h('div',{class:'row'},h('button',{class:'ok',onclick:guard(async()=>{await api('POST',`/api/experiences/${x.id}/review`,{approved:true});toast('Expérience validée pour ce projet');load();})},'Valider pour ce projet'),h('button',{class:'ok',onclick:guard(async()=>{await api('POST',`/api/experiences/${x.id}/review`,{approved:true,global:true});toast('Expérience partagée avec toutes les IA et tous les projets');load();})},'Partager globalement'),h('button',{class:'danger',onclick:guard(async()=>{await api('POST',`/api/experiences/${x.id}/review`,{approved:false});load();})},'Refuser')),
      status!=='pending' && h('button',{class:'small danger',onclick:guard(async()=>{if(!confirm('Supprimer cette expérience ?'))return;await api('DELETE',`/api/experiences/${x.id}`);load();})},'Supprimer'))));
    if(!rows.length) box.append(h('p',{class:'muted'},'Aucune expérience dans cette catégorie.'));
  });
  tabs.replaceChildren(...[['pending','À valider'],['approved','Validées'],['rejected','Refusées']].map(([v,l])=>h('button',{class:status===v?'on':'',onclick:()=>{status=v;tabs.querySelectorAll('button').forEach(b=>b.classList.toggle('on',b.textContent===l));load();}},l)));
  const domain=h('input',{placeholder:'Domaine (ex. Three.js, Android, physique)' }), lesson=h('textarea',{placeholder:'Leçon réutilisable, concrète et vérifiable',rows:3}), evidence=h('input',{placeholder:'Preuve ou contexte (facultatif)'});
  main.insertBefore(h('div',{class:'card',style:'margin:12px 0'},h('h2',{},'Ajouter une expérience'),h('label',{},'Domaine'),domain,h('label',{},'Leçon'),lesson,h('label',{},'Preuve'),evidence,h('button',{class:'primary',onclick:guard(async()=>{await api('POST',`/api/projects/${S.project.id}/experiences`,{domain:domain.value,lesson:lesson.value,evidence:evidence.value});domain.value='';lesson.value='';evidence.value='';status='pending';tabs.querySelectorAll('button').forEach(b=>b.classList.toggle('on',b.textContent==='À valider'));load();toast('Expérience ajoutée en attente de validation');})},'Soumettre pour validation')),tabs);
  load(); return {refresh:load};
};

SCREENS.library = (main) => {
  const box = h('div'); let q = '', scope = '';
  const b64 = async (f) => { const buf = new Uint8Array(await f.arrayBuffer()); let bin = ''; for (let i = 0; i < buf.length; i += 0x8000) bin += String.fromCharCode(...buf.subarray(i, i + 0x8000)); return btoa(bin); };
  const size = (n) => (n > 1048576 ? (n / 1048576).toFixed(1) + ' Mo' : n > 1024 ? Math.round(n / 1024) + ' Ko' : n + ' o');
  const fetchBlob = async (it) => { const r = await fetch(`/api/library/${it.id}/download?project_id=${S.project.id}`, { headers: { authorization: 'Bearer ' + S.token } }); if (!r.ok) throw new Error('Téléchargement impossible'); return r.blob(); };
  const upScope = h('select', {}, h('option', { value: 'project' }, 'Ce projet uniquement'), h('option', { value: 'global' }, 'Global (partagé entre projets)')), upTags = h('input', { placeholder: 'tags (séparés par des virgules)' });
  const search = h('input', { placeholder: 'Rechercher nom, tag, description…', oninput: (e) => { q = e.target.value; load(); } }), filt = h('select', { onchange: (e) => { scope = e.target.value; load(); } }, h('option', { value: '' }, 'Tout'), h('option', { value: 'project' }, 'Ce projet'), h('option', { value: 'global' }, 'Global'));
  main.append(h('h1', {}, 'Bibliothèque de fichiers'), h('p', { class: 'muted' }, 'Stockage central de vos ressources (modèles, textures, sons, documents). Un élément « projet » reste réservé à son projet ; un élément « global » est partagé volontairement. Les agents peuvent les consulter (texte) ; l’import dans un projet crée une copie sauvegardée et annulable. Max 8 Mo par fichier.'),
    h('div', { class: 'card', style: 'margin-bottom:12px' }, h('div', { class: 'row' }, upScope, upTags, h('label', { class: 'small', style: 'margin:0;cursor:pointer;border:1px solid var(--accent);border-radius:8px;padding:8px 12px;color:var(--txt)' }, 'Ajouter des fichiers', h('input', { type: 'file', multiple: true, style: 'display:none', onchange: guard(async (e) => { for (const f of e.target.files) await api('POST', '/api/library', { name: f.name, content: await b64(f), tags: upTags.value, project_id: upScope.value === 'project' ? S.project.id : null }); toast('Ajouté à la bibliothèque'); e.target.value = ''; load(); }) })))),
    h('div', { class: 'row', style: 'margin-bottom:10px' }, search, filt), box);
  const load = guard(async () => {
    const items = await api('GET', `/api/library?project_id=${S.project.id}&q=${encodeURIComponent(q)}${scope ? '&scope=' + scope : ''}`);
    box.replaceChildren(h('div', { class: 'grid' }, items.map((it) => h('div', { class: 'card' }, h('div', { class: 'row' }, h('b', { style: 'flex:1;overflow-wrap:anywhere' }, it.name), pill(it.project_id ? 'projet' : 'global')), h('p', { class: 'muted small' }, `${size(it.size)} · ${it.mime} · ${fmt(it.created)}`), it.description && h('p', { class: 'small' }, it.description), h('div', {}, it.tags.map((t) => h('span', { class: 'pill', style: 'margin-right:4px' }, t))),
      h('div', { class: 'row', style: 'margin-top:8px' },
        h('button', { class: 'small', onclick: guard(async () => { const d = await api('GET', `/api/library/${it.id}/preview?project_id=${S.project.id}`); if (d.content != null) modal(it.name, h('pre', {}, d.content), d.truncated && h('p', { class: 'muted small' }, 'Aperçu tronqué.')); else if (it.mime.startsWith('image/') && it.mime !== 'image/svg+xml') modal(it.name, h('img', { src: URL.createObjectURL(await fetchBlob(it)), style: 'max-width:100%' })); else modal(it.name, h('p', { class: 'muted' }, 'Pas d’aperçu pour ce type : téléchargez-le.')); }) }, 'Aperçu'),
        h('button', { class: 'small', onclick: guard(async () => { const a = h('a', { href: URL.createObjectURL(await fetchBlob(it)), download: it.name }); document.body.append(a); a.click(); a.remove(); }) }, 'Télécharger'),
        h('button', { class: 'small primary', onclick: guard(async () => { const dest = prompt(`Copier dans « ${S.project.name} » à quel chemin ?`, `assets/${it.name}`); if (!dest) return; await api('POST', `/api/library/${it.id}/import`, { project_id: S.project.id, path: dest }); toast('Copié dans le projet (annulable)'); }) }, 'Importer au projet'),
        h('button', { class: 'small', onclick: guard(async () => { const t = prompt('Tags (séparés par des virgules)', it.tags.join(', ')); if (t === null) return; await api('PUT', `/api/library/${it.id}`, { tags: t }); load(); }) }, 'Tags'),
        h('button', { class: 'small danger', onclick: guard(async () => { if (!confirm(`Supprimer « ${it.name} » de la bibliothèque ? Un exemplaire est conservé dans data/library/trash.`)) return; await api('DELETE', `/api/library/${it.id}?confirm=1`); load(); }) }, 'Supprimer'))))), !items.length && h('p', { class: 'muted' }, 'Aucun élément.'));
  });
  load(); return { refresh: (m) => { if (m?.type === 'library') load(); } };
};

SCREENS.dev = (main) => {
  let tab = 'approvals'; const body = h('div'), tabs = h('div', { class: 'tabs' });
  main.append(h('h1', {}, 'Centre de développement'), tabs, body);
  const paintTabs = () => tabs.replaceChildren(...[['approvals', 'Autorisations'], ['changes', 'Modifications'], ['versions', 'Versions & restauration']].map(([id, l]) => h('button', { class: tab === id ? 'on' : '', onclick: () => { tab = id; paintTabs(); load(); } }, l)));
  const diffView = (lines) => h('div', { class: 'diff' }, (lines || []).filter((l) => l[0] !== ' ').slice(0, 800).map((l) => h('div', { class: l[0] === '+' ? 'a' : 'r' }, l)));
  const load = guard(async () => {
    const pid = S.project.id;
    if (tab === 'approvals') {
      const a = await api('GET', `/api/approvals?project_id=${pid}`);
      body.replaceChildren(h('p', { class: 'muted' }, 'Aucune modification des agents n’est appliquée sans votre accord (sauf projets en mode « Auto », avec sauvegarde). Les suppressions demandent toujours votre autorisation.'),
        a.length > 1 && h('button', { class: 'ok', style: 'margin-bottom:10px', onclick: guard(async () => { if (!confirm(`Approuver ${a.filter((x) => x.kind === 'write').length} fichier(s) (hors suppressions) ?`)) return; for (const x of a.filter((y) => y.kind === 'write')) await api('POST', `/api/approvals/${x.id}/approve`); load(); refreshBadges(); }) }, 'Tout approuver (hors suppressions)'),
        ...a.map((x) => h('div', { class: 'card', style: 'margin-bottom:8px' }, h('div', { class: 'row' }, pill(x.kind === 'delete' ? 'danger' : 'pending'), h('b', {}, x.path), h('span', { class: 'muted small' }, `${S.agents.find((g) => g.id === x.agent_id)?.name || x.agent_id} · ${fmt(x.created)}`), h('span', { style: 'flex:1' }),
          h('button', { class: 'small', onclick: guard(async (e) => { const d = await api('GET', `/api/approvals/${x.id}/diff`); const holder = e.target.closest('.card').querySelector('.dv'); holder.replaceChildren(d.diff.lines ? diffView(d.diff.lines) : h('p', { class: 'muted' }, `+${d.diff.added} / −${d.diff.removed} lignes`), d.diff.deleted ? '' : h('details', {}, h('summary', {}, 'Contenu complet'), h('pre', {}, d.content))); }) }, 'Voir les changements'),
          h('button', { class: 'small ok', onclick: guard(async () => { await api('POST', `/api/approvals/${x.id}/approve`); toast('Appliqué'); load(); refreshBadges(); }) }, 'Approuver'), h('button', { class: 'small danger', onclick: guard(async () => { await api('POST', `/api/approvals/${x.id}/reject`); load(); refreshBadges(); }) }, 'Refuser')), h('div', { class: 'dv' }))),
        !a.length && h('p', { class: 'muted' }, 'Rien en attente.'));
    } else if (tab === 'changes') {
      const c = await api('GET', `/api/projects/${pid}/changes`);
      body.replaceChildren(h('table', {}, h('tr', {}, ['Date', 'Action', 'Fichier', 'Auteur', ''].map((x) => h('th', {}, x))), c.map((x) => h('tr', {}, h('td', { class: 'small' }, fmt(x.ts)), h('td', {}, x.action), h('td', {}, x.path), h('td', { class: 'small muted' }, x.actor), h('td', {}, x.undone ? pill('annulée') : h('button', { class: 'small', onclick: guard(async () => { await api('POST', `/api/projects/${pid}/changes/${x.id}/undo`, {}); toast('Annulée'); load(); }) }, 'Annuler'))))), !c.length && h('p', { class: 'muted' }, 'Aucune modification.'));
    } else {
      const vs = await api('GET', `/api/projects/${pid}/versions`);
      const label = h('input', { placeholder: 'Nom de la version (ex. avant refonte menu)' });
      body.replaceChildren(h('div', { class: 'row', style: 'margin-bottom:12px' }, label, h('button', { class: 'primary', onclick: guard(async () => { await api('POST', `/api/projects/${pid}/versions`, { label: label.value }); toast('Version sauvegardée'); load(); }) }, 'Sauvegarder maintenant')),
        ...vs.map((v) => h('div', { class: 'card', style: 'margin-bottom:8px' }, h('div', { class: 'row' }, h('b', {}, v.label), h('span', { class: 'muted small' }, `${fmt(v.created)} · ${v.files} fichiers · ${Math.round(v.bytes / 1024)} Ko · ${v.reason}`), h('span', { style: 'flex:1' }),
          h('button', { class: 'small', onclick: guard(async (e) => { const d = await api('GET', `/api/projects/${pid}/versions/${v.id}/diff`); e.target.closest('.card').querySelector('.dv').replaceChildren(h('p', { class: 'small' }, `Depuis cette version : +${d.added.length} ajouté(s), −${d.removed.length} supprimé(s), ${d.modified.length} modifié(s).`), d.removed.length ? h('p', { class: 'small', style: 'color:var(--red)' }, 'Supprimés : ' + d.removed.join(', ')) : '', d.added.length ? h('p', { class: 'small', style: 'color:var(--green)' }, 'Ajoutés : ' + d.added.join(', ')) : '', d.modified.length ? h('p', { class: 'small' }, 'Modifiés : ' + d.modified.map((m) => m.path).join(', ')) : ''); }) }, 'Comparer à l’actuel'),
          h('button', { class: 'small danger', onclick: guard(async () => { if (!confirm(`Restaurer « ${v.label} » ? L'état actuel est d'abord sauvegardé automatiquement.`)) return; await api('POST', `/api/projects/${pid}/versions/${v.id}/restore`, { confirm: true }); toast('Version restaurée'); load(); }) }, 'Restaurer')), h('div', { class: 'dv' }))), !vs.length && h('p', { class: 'muted' }, 'Aucune version sauvegardée.'));
    }
  });
  paintTabs(); load(); return { refresh: load };
};

SCREENS.history = (main) => {
  const box = h('div'); main.append(h('h1', {}, 'Historique'), box);
  const load = guard(async () => {
    const [runs, jr] = await Promise.all([api('GET', '/api/runs?project_id=' + S.project.id), api('GET', '/api/journal?project_id=' + S.project.id + '&limit=150')]);
    box.replaceChildren(h('h3', {}, 'Exécutions'), h('table', {}, runs.map((r) => h('tr', {}, h('td', {}, pill(r.status)), h('td', {}, r.instruction.slice(0, 100)), h('td', { class: 'small muted' }, r.mode), h('td', { class: 'small muted' }, fmt(r.created))))),
      h('h3', { style: 'margin-top:18px' }, 'Journal des actions (utilisateur, agents, système)'), h('table', {}, jr.map((x) => h('tr', {}, h('td', { class: 'small muted' }, fmt(x.ts)), h('td', { class: 'small' }, x.actor), h('td', {}, x.action), h('td', { class: 'small muted' }, String(x.detail || '').slice(0, 140))))));
  });
  load(); return { refresh: load };
};

SCREENS.tests = (main) => {
  const box = h('div'); main.append(h('h1', {}, 'Centre de tests'), box);
  const load = guard(async () => {
    const [reps, p, browserStatus, gameplayReports, bugFixJobs] = await Promise.all([api('GET', `/api/projects/${S.project.id}/tests`), api('GET', `/api/projects/${S.project.id}`), api('GET', `/api/projects/${S.project.id}/gameplay-tests/status`), api('GET', `/api/projects/${S.project.id}/gameplay-tests`), api('GET', `/api/projects/${S.project.id}/bug-fixes`)]);
    const out = h('div');
    const gameplayBox = h('div', { class:'card', style:'margin:12px 0' }, h('h3', {}, 'OPS GAMEPLAY TESTER — V3.12 + OPS AUTOMATIC BUG FIXER — V3.13'), h('p', { class:'small muted' }, 'Lance le jeu dans Chromium isolé, puis permet aux IA d’analyser les rapports et de préparer des corrections traçables. Les changements de fichiers suivent le mode d’approbation du projet.'), h('p', { class:'small' }, browserStatus.available ? 'Chromium prêt sur ce serveur.' : (browserStatus.instruction || 'Navigateur automatisé indisponible.')), h('div', { class:'row' }, h('button', { class:'primary', disabled:!browserStatus.available || !p.allow_exec, onclick:guard(async (e)=>{ if(!confirm('Autoriser OPS à exécuter le jeu dans un navigateur isolé ? Le code du projet sera chargé dans Chromium.')) return; e.target.disabled=true; try { const r=await api('POST', `/api/projects/${S.project.id}/gameplay-tests`, {viewport:'desktop'}); toast(r.passed?'Test navigateur terminé sans erreur bloquante':'Test terminé avec des erreurs',!r.passed); await load(); } finally { e.target.disabled=false; } }) }, 'Tester sur PC'), h('button', { disabled:!browserStatus.available || !p.allow_exec, onclick:guard(async(e)=>{ if(!confirm('Lancer le jeu en viewport mobile simulé ?')) return; e.target.disabled=true; try { const r=await api('POST', `/api/projects/${S.project.id}/gameplay-tests`, {viewport:'mobile'}); toast(r.passed?'Test mobile terminé':'Test mobile avec erreurs',!r.passed); await load(); } finally { e.target.disabled=false; } }) }, 'Tester sur mobile')), !p.allow_exec && h('p',{class:'small muted'},'Activez « Autoriser l’exécution de code » dans Projets pour lancer le jeu.'));
    const gameplayCards = gameplayReports.flatMap(r => [h('div',{class:'card',style:'margin:8px 0'},h('div',{class:'row'},pill(r.passed?'ok':'failed'),h('b',{},`Gameplay ${r.summary.viewport}`),h('span',{class:'small muted'},fmt(r.ts))),h('p',{class:'small'},`HTTP ${r.summary.http_status ?? '—'} · ${r.summary.duration_ms} ms · ${r.summary.page_errors} erreur(s) JS · ${r.summary.canvas_count} canvas · WebGL ${r.summary.webgl_detected?'détecté':'non détecté'}`),...(r.detail.findings||[]).map(f=>h('p',{class:'small'},`${f.severity.toUpperCase()} — ${f.message}`)),h('button',{class:'primary',onclick:guard(async(e)=>{if(!confirm('Créer une sauvegarde et demander aux IA OPS de diagnostiquer ce rapport et de proposer des corrections ? Aucun script du jeu ne sera exécuté.'))return;e.target.disabled=true;try{const job=await api('POST',`/api/projects/${S.project.id}/bug-fixes`,{report_id:r.id});toast('Mission de correction créée : '+job.id);await load();}finally{e.target.disabled=false;}})},'Analyser et préparer les corrections'),r.detail.screenshot_jpeg_base64 && h('img',{src:`data:image/jpeg;base64,${r.detail.screenshot_jpeg_base64}`,style:'width:100%;max-width:720px;border-radius:8px',alt:'Capture du test navigateur'}),h('details',{},h('summary',{},'Détails techniques'),h('pre',{},JSON.stringify({console_errors:r.detail.console_errors,page_errors:r.detail.page_errors,failed_requests:r.detail.failed_requests,blocked_origins:r.detail.blocked_origins},null,2))))]);
    const fixCards = bugFixJobs.map(jb=>h('div',{class:'card',style:'margin:8px 0'},h('div',{class:'row'},pill(jb.status),h('b',{},'OPS Automatic Bug Fixer'),h('span',{class:'small muted'},fmt(jb.created))),h('p',{class:'small'},`Rapport : ${jb.report_id} · Sauvegarde : ${jb.baseline_version_id} · Exécution IA : ${jb.run_id}`),h('p',{class:'small'},jb.run?.report||jb.run?.error||'Diagnostic en cours. Consultez les tâches et approbations dans Exécutions.'),jb.regression_review&&h('div',{class:'alert '+(jb.regression_review.status==='blocked'?'err':'info')},h('b',{},`Contrôle après correction : ${jb.regression_review.status}`),h('p',{class:'small'},jb.regression_review.summary||'Comparaison structurelle terminée.'),...(jb.regression_review.findings||[]).map(f=>h('p',{class:'small'},`${f.level.toUpperCase()} — ${f.path||'Projet'} : ${f.msg}`)),...(jb.regression_review.actions||[]).map(a=>h('p',{class:'small'},a)),h('p',{class:'small muted'},`Cycle ${jb.cycle_count||1}/${jb.max_cycles||3} · ${Math.max(0,(jb.max_cycles||3)-(jb.cycle_count||1))} tentative(s) restante(s)`),jb.can_advance && reps.some(r=>!r.passed && r.id!==jb.report_id && r.ts>(reps.find(x=>x.id===jb.report_id)?.ts||0)) && h('button',{class:'primary',onclick:guard(async(e)=>{const next=reps.find(r=>!r.passed&&r.id!==jb.report_id&&r.ts>(reps.find(x=>x.id===jb.report_id)?.ts||0));if(!next)return;e.target.disabled=true;try{const result=await api('POST',`/api/bug-fixes/${jb.id}/advance`,{report_id:next.id});toast(`Cycle ${result.cycle_count} lancé`);await load();}finally{e.target.disabled=false;}})},'Relancer après le nouveau rapport échoué'))));
    const runScript = (script) => guard(async (e) => { e.target.disabled = true; try { const r = await api('POST', `/api/projects/${S.project.id}/run`, { script }); out.replaceChildren(h('div', { class: 'alert ' + (r.passed ? 'info' : 'err') }, `npm run ${script} : ${r.passed ? 'réussi' : 'échec'} (code ${r.exit_code}, ${r.duration_ms} ms${r.timeout ? ', délai dépassé' : ''})`), h('pre', {}, r.output || '(aucune sortie)')); load(); } finally { e.target.disabled = false; } });
    box.replaceChildren(h('p', { class: 'muted' }, 'Vérifications sans exécution du code du projet : syntaxe JS/JSON/HTML (scripts inline), puis non-régression par rapport à la dernière version sauvegardée (fichiers perdus, fichiers réduits, fonctions disparues).'), gameplayBox, ...gameplayCards, h('h3',{},'Sessions de correction OPS'), ...fixCards,
      h('div', { class: 'row' }, h('button', { class: 'primary', onclick: guard(async (e) => { e.target.disabled = true; try { const r = await api('POST', `/api/projects/${S.project.id}/tests`); toast(r.passed ? 'Vérifications réussies' : 'Problèmes détectés', !r.passed); await load(); } finally { e.target.disabled = false; } }) }, 'Lancer les vérifications'), h('button', { disabled: !p.allow_exec, title: p.allow_exec ? '' : 'Autorisez l’exécution de code dans Projets', onclick: runScript('test') }, 'npm test'), h('button', { disabled: !p.allow_exec, onclick: runScript('build') }, 'npm run build')),
      !p.allow_exec && h('p', { class: 'muted small' }, 'npm test / build : exécution de code non autorisée pour ce projet (Projets → « Autoriser l’exécution de code »).'), out,
      h('h3', { style: 'margin-top:16px' }, 'Rapports'), ...reps.map((r) => h('div', { class: 'card', style: 'margin-bottom:8px' }, h('div', { class: 'row' }, pill(r.passed ? 'ok' : 'failed'), h('b', {}, r.kind), h('span', { class: 'muted small' }, fmt(r.ts)), h('span', { class: 'small' }, r.kind === 'checks' ? `${r.summary.checked} fichiers vérifiés · ${r.summary.failed} erreur(s) · ${r.summary.regression_findings} alerte(s) de régression` : `code ${r.summary.exit_code} · ${r.summary.duration_ms} ms`)),
        r.kind === 'checks' && h('details', {}, h('summary', {}, 'Détail'), r.detail.files.filter((f) => !f.ok).map((f) => h('div', { class: 'alert err' }, h('b', {}, f.path), ' — ', f.error)), r.detail.regression.findings.map((f) => h('div', { class: 'alert' }, h('b', {}, f.path), ' — ', f.msg)), !r.detail.files.some((f) => !f.ok) && !r.detail.regression.findings.length && h('p', { class: 'muted' }, 'Aucun problème.')),
        r.kind !== 'checks' && h('details', {}, h('summary', {}, 'Sortie'), h('pre', {}, r.detail.output || '')))), !reps.length && h('p', { class: 'muted' }, 'Aucun rapport.'));
  });
  load(); return { refresh: (m) => { if (m?.type === 'tests') load(); } };
};

SCREENS.providers = (main) => {
  const box = h('div'); main.append(h('h1', {}, 'Fournisseurs IA'), h('p', { class: 'muted' }, 'Les clés sont envoyées une seule fois au serveur, chiffrées au repos et ne sont jamais renvoyées au navigateur. Un fournisseur n’est « connecté » que si le test de connexion réussit.'), box);
  const load = guard(async () => {
    const d = await api('GET', '/api/providers');
    const kind = h('select', {}, Object.entries(d.kinds).map(([k, v]) => h('option', { value: k }, v.label))), name = h('input', { placeholder: 'Nom (ex. OpenAI, Claude, Gemini, Ollama)' }), url = h('input', { placeholder: 'URL de base (optionnel — ex. http://localhost:11434/v1)' }), model = h('input', { placeholder: 'Modèle' }), key = h('input', { type: 'password', placeholder: 'Clé API', autocomplete: 'off' }), lim = h('input', { type: 'number', min: '0', placeholder: 'Limite tokens/jour (0 = illimité)' });
    box.replaceChildren(h('div', { class: 'card', style: 'margin-bottom:12px' }, h('h2', {}, 'Ajouter un fournisseur'), h('div', { class: 'grid' }, h('div', {}, h('label', {}, 'Type'), kind, h('label', {}, 'Nom'), name, h('label', {}, 'URL de base'), url), h('div', {}, h('label', {}, 'Modèle'), model, h('label', {}, 'Clé API'), key, h('label', {}, 'Budget quotidien'), lim)),
      h('div', { style: 'margin-top:10px' }, h('button', { class: 'primary', onclick: guard(async () => { await api('POST', '/api/providers', { kind: kind.value, name: name.value, base_url: url.value, model: model.value, api_key: key.value, max_tokens_day: Number(lim.value) || 0 }); toast('Fournisseur ajouté'); load(); }) }, 'Ajouter'))),
      h('div', { class: 'grid' }, d.providers.map((p) => {
        const res = h('div', { class: 'small' }), mdl = h('input', { value: p.model || '', list: 'ml-' + p.id }), dl = h('datalist', { id: 'ml-' + p.id }), nk = h('input', { type: 'password', placeholder: 'Nouvelle clé (laisser vide pour conserver)', autocomplete: 'off' });
        return h('div', { class: 'card' }, h('div', { class: 'row' }, h('h2', { style: 'margin:0;flex:1' }, p.name), d.default_provider_id === p.id && pill('défaut'), p.enabled ? pill('ok') : pill('warn')), h('p', { class: 'muted small' }, `${d.kinds[p.kind]?.label} · ${p.base_url || d.kinds[p.kind]?.defaultBase} · clé ${p.key_set ? p.key_hint : 'absente'}`),
          h('p', { class: 'small' }, `Aujourd’hui : ${p.usage_today.calls} appel(s), ${p.usage_today.tokens} tokens${p.max_tokens_day ? ' / ' + p.max_tokens_day : ''}`), h('label', {}, 'Modèle'), mdl, dl, h('label', {}, 'Clé API'), nk,
          h('div', { class: 'row', style: 'margin-top:8px' },
            h('button', { class: 'small', onclick: guard(async () => { await api('PUT', `/api/providers/${p.id}`, { model: mdl.value, ...(nk.value ? { api_key: nk.value } : {}) }); toast('Enregistré'); load(); }) }, 'Enregistrer'),
            h('button', { class: 'small primary', onclick: guard(async (e) => { e.target.disabled = true; res.textContent = 'Test…'; try { const r = await api('POST', `/api/providers/${p.id}/test`); res.replaceChildren(h('div', { class: 'alert ' + (r.ok ? 'info' : 'err') }, r.ok ? `Connexion réussie (${r.latency_ms} ms, modèle ${r.model})` : `Échec [${r.code}] : ${r.error}`)); } finally { e.target.disabled = false; } }) }, 'Tester la connexion'),
            h('button', { class: 'small', onclick: guard(async () => { const r = await api('GET', `/api/providers/${p.id}/models`); if (!r.ok) { res.replaceChildren(h('div', { class: 'alert err' }, r.error)); return; } dl.replaceChildren(...r.models.map((m) => h('option', { value: m }))); res.textContent = `${r.models.length} modèle(s) : saisissez dans le champ Modèle pour choisir.`; }) }, 'Lister les modèles'),
            h('button', { class: 'small', onclick: guard(async () => { await api('PUT', '/api/settings', { default_provider_id: p.id }); load(); }) }, 'Par défaut'),
            h('button', { class: 'small', onclick: guard(async () => { await api('PUT', `/api/providers/${p.id}`, { enabled: !p.enabled }); load(); }) }, p.enabled ? 'Désactiver' : 'Activer'),
            h('button', { class: 'small danger', onclick: guard(async () => { if (confirm(`Supprimer « ${p.name} » ?`)) { await api('DELETE', `/api/providers/${p.id}`); load(); } }) }, 'Supprimer')), res);
      })));
    if (!d.providers.length) box.append(h('div', { class: 'alert' }, 'Aucun fournisseur. Ajoutez-en au moins un pour activer les agents.'));
  });
  load(); return { refresh: () => {} };
};

SCREENS.settings = (main) => {
  const box = h('div'); main.append(h('h1', {}, 'Paramètres'), box);
  const load = guard(async () => {
    const [s, pr] = await Promise.all([api('GET', '/api/settings'), api('GET', '/api/providers')]);
    const conc = h('input', { type: 'number', min: '1', max: '10', value: s.concurrency || 3 }), corr = h('input', { type: 'number', min: '0', max: '10', value: s.max_correction_rounds === '' ? 1 : s.max_correction_rounds }), def = h('select', {}, h('option', { value: '' }, '(premier disponible)'), pr.providers.map((p) => h('option', { value: p.id, selected: p.id === s.default_provider_id }, p.name)));
    const wp = h('select', {}, ['', 'tavily', 'brave'].map((x) => h('option', { value: x, selected: x === s.web.provider }, x || '(aucune)'))), wk = h('input', { type: 'password', placeholder: s.web.configured ? 'Clé enregistrée (laisser vide pour conserver)' : 'Clé API de recherche', autocomplete: 'off' });
    const q = h('input', { placeholder: 'Tester une recherche Web…' }), qr = h('div');
    box.replaceChildren(h('div', { class: 'grid' },
      h('div', { class: 'card' }, h('h2', {}, 'Orchestrateur'), h('label', {}, 'Agents en parallèle (1–10)'), conc, h('label', {}, 'Tours de correction après relecture (0–10)'), corr, h('label', {}, 'Fournisseur par défaut'), def, h('div', { style: 'margin-top:10px' }, h('button', { class: 'primary', onclick: guard(async () => { await api('PUT', '/api/settings', { concurrency: conc.value, max_correction_rounds: corr.value, default_provider_id: def.value }); toast('Enregistré'); }) }, 'Enregistrer'))),
      h('div', { class: 'card' }, h('h2', {}, 'Recherche Web (côté serveur)'), h('p', { class: 'small muted' }, s.web.configured ? `Configurée : ${s.web.provider}` : 'Non configurée : les agents n’ont pas accès à Internet tant qu’une clé Tavily ou Brave n’est pas saisie.'), h('label', {}, 'Service'), wp, h('label', {}, 'Clé'), wk, h('div', { class: 'row', style: 'margin-top:10px' }, h('button', { class: 'primary', onclick: guard(async () => { await api('PUT', '/api/settings', { web: { provider: wp.value, api_key: wk.value } }); toast('Enregistré'); load(); }) }, 'Enregistrer'), h('button', { onclick: guard(async () => { const r = await api('POST', '/api/web/search', { query: q.value }); qr.replaceChildren(...r.results.map((x) => h('p', { class: 'small' }, h('b', {}, x.title), h('br'), x.url, h('br'), x.snippet))); }) }, 'Tester')), q, qr),
      h('div', { class: 'card' }, h('h2', {}, 'Session'), h('p', { class: 'small muted' }, `Version ${S.state?.version || ''} · base ${S.state?.database || ''}`), h('button', { class: 'danger', onclick: logout }, 'Se déconnecter'))));
  });
  load(); return { refresh: () => {} };
};

const STATE_LABEL = { ready: 'prête', waiting_deps: 'attend dépendances', waiting_ai: "attend l'IA (non construite)", todo: 'à faire', in_progress: 'en cours', review: 'en revue', done: 'terminée', blocked: 'bloquée', cancelled: 'annulée' };
const spill = (st) => h('span', { class: 'pill ' + ({ ready: 'ok', done: 'done', in_progress: 'running', review: 'running', blocked: 'error', waiting_ai: 'warn', waiting_deps: '', cancelled: 'warn' }[st] || '') }, STATE_LABEL[st] || st);

SCREENS.studio = (main) => {
  const box = h('div'); main.append(h('h1', {}, 'Studio OPS — les 13 IA AAA'), h('p', { class: 'muted' }, 'Les 13 spécialistes sont construits : chacun possède son domaine, son prompt métier, un chat direct et peut exécuter les tâches qui lui sont attribuées. Ils partagent le contexte du projet et se transmettent automatiquement leurs livrables.'), box);
  const load = guard(async () => {
    const [st, provs] = await Promise.all([api('GET', `/api/studio?project_id=${S.project?.id || ''}`), api('GET', '/api/providers')]);
    box.replaceChildren(h('div', { class: 'grid' }, st.map((a, i) => {
      const ps = h('select', {}, h('option', { value: '' }, '(fournisseur par défaut)'), provs.providers.map((p) => h('option', { value: p.id, selected: p.id === a.provider_id }, p.name))), model = h('input', { placeholder: 'modèle (optionnel)', value: a.model || '' });
      return h('div', { class: 'card', style: a.status === 'planned' ? 'opacity:.7' : '' }, h('div', { class: 'row' }, h('h2', { style: 'margin:0;flex:1' }, `${i + 1}. ${a.name}`), a.status === 'validated' ? h('span', { class: 'pill ok' }, 'validée') : a.status === 'built' ? h('span', { class: 'pill pending' }, 'construite') : h('span', { class: 'pill warn' }, 'non construite')),
        h('p', { class: 'muted small' }, a.domain), h('p', { class: 'small' }, a.status === 'planned' ? 'Non construite — non exécutable' : a.status === 'built' ? 'Construite — en attente de votre validation' : `Validée le ${fmt(a.validated_at)}`),
        h('p', { class: 'small' }, `Tâches planifiées : ${a.tasks} (${a.tasks_done} terminées) · messages à traiter : ${a.inbox}`),
        a.id === 'director' && h('button', { class: 'small primary', style: 'margin-top:6px', onclick: () => { S.directorTab = 'chat'; go('director'); } }, 'Parler au Director'), a.id === 'world' && h('button', { class: 'small primary', style: 'margin-top:6px', onclick: () => { S.worldTab = 'chat'; go('world'); } }, 'Parler à WORLD AI'), a.id === 'modeling' && h('button', { class: 'small primary', style: 'margin-top:6px', onclick: () => { S.modelTab = 'chat'; go('modeling'); } }, 'Parler à MODELING AI'), !['director','world','modeling'].includes(a.id) && h('button', { class: 'small primary', style: 'margin-top:6px', onclick: () => { S.specialistAgent = a.id; go('specialist'); } }, `Parler à ${a.name}`), a.status !== 'planned' && [h('label', {}, 'Fournisseur'), ps, h('label', {}, 'Modèle'), model, h('div', { class: 'row', style: 'margin-top:8px' }, h('button', { class: 'small', onclick: guard(async () => { await api('PUT', `/api/studio/${a.id}`, { provider_id: ps.value, model: model.value }); toast('Enregistré'); }) }, 'Enregistrer'),
          a.status === 'built' ? h('button', { class: 'small ok', onclick: guard(async () => { if (!confirm(`Valider ${a.name} ? Cela autorise la construction de l'IA suivante.`)) return; await api('POST', `/api/studio/${a.id}/validate`, {}); load(); }) }, 'Valider cette IA') : h('button', { class: 'small', onclick: guard(async () => { await api('POST', `/api/studio/${a.id}/validate`, { validated: false }); load(); }) }, 'Retirer la validation'))]);
    })));
  });
  load(); return { refresh: load };
};

SCREENS.specialist = (main) => {
  const id = S.specialistAgent || 'animation';
  let roster = [];
  const title = h('h1', {}, 'IA spécialisée OPS');
  const description = h('p', { class: 'muted' }, 'Conversation directe avec le spécialiste. Il reçoit le contexte partagé du projet OPS.');
  const list = h('div', { class: 'msgs', style: 'max-height:58dvh;min-height:220px;overflow:auto;border:1px solid var(--line);border-radius:10px;padding:10px;background:#0a111b' });
  const input = h('textarea', { rows: '2', placeholder: id === 'satellite' ? 'Décris la région, la date et ce que tu veux extraire de l’image satellitaire…' : id === 'webresearch' ? 'Que dois-je rechercher sur Internet pour aider le studio OPS ?' : 'Écrire à cette IA…', onkeydown: (e) => { if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) { e.preventDefault(); send.click(); } } });
  const imagePick = id === 'satellite' ? h('input', { type: 'file', accept: 'image/png,image/jpeg,image/webp', style: 'max-width:100%;margin:8px 0' }) : null;
  const load = guard(async () => {
    const [r, ms] = await Promise.all([api('GET', '/api/studio'), api('GET', `/api/messages?project_id=${S.project?.id || ''}&agent_id=${id}`)]);
    roster = r; const a = roster.find(x => x.id === id); title.textContent = a?.name || 'IA spécialisée OPS';
    list.replaceChildren(...ms.map(m => h('div', { class: 'msg ' + m.role }, h('div', { class: 'who' }, m.role === 'user' ? 'Vous' : (a?.name || id)), m.role === 'user' ? h('div', {}, m.content) : md(m.content))));
    if (!ms.length) list.append(h('p', { class: 'muted' }, `Discute directement avec ${a?.name || id}. Demande-lui une analyse, un livrable ou une collaboration avec les autres IA.`));
    list.scrollTop = list.scrollHeight;
  });
  const send = h('button', { class: 'primary', onclick: guard(async () => { const text = input.value.trim(); if (!text) return; send.disabled = true; input.disabled = true; try { let image_data_url; if (imagePick?.files?.[0]) { const file = imagePick.files[0]; if (file.size > 5 * 1024 * 1024) throw new Error('Image trop volumineuse : maximum 5 Mo.'); image_data_url = await new Promise((resolve,reject) => { const reader = new FileReader(); reader.onload = () => resolve(reader.result); reader.onerror = reject; reader.readAsDataURL(file); }); } const result = await api('POST', `/api/studio/${id}/chat`, { project_id: S.project.id, text, image_data_url }); if (result.shared_with_studio) toast(`Dossier partagé avec ${result.shared_with_studio} autres IA.`); input.value = ''; if (imagePick) imagePick.value = ''; await load(); } finally { send.disabled = false; input.disabled = false; input.focus(); } }) }, 'Envoyer');
  main.append(title, description, h('div', { class: 'row', style: 'margin:10px 0' }, h('button', { class: 'small', onclick: () => go('studio') }, '← Retour au studio')), id === 'satellite' && h('div', { class: 'card' }, h('strong', {}, 'OPS SATELLITE AI — Analyse d’images satellitaires'), h('p', { class: 'muted small' }, 'Ajoute une image PNG/JPG/WEBP (5 Mo max). Le dossier est transmis aux autres IA.'), h('a', { href: 'https://worldview.earthdata.nasa.gov/', target: '_blank', rel: 'noopener' }, 'Ouvrir NASA Worldview pour obtenir une image de référence')), id === 'webresearch' && h('div', { class: 'card' }, h('strong', {}, 'OPS WEB RESEARCH AI — Recherche Internet pour tout le studio'), h('p', { class: 'muted small' }, 'Recherche les documentations et solutions récentes, compare les sources, récupère les pages publiques et transmet un dossier avec liens aux 12 autres IA. Configure Tavily ou Brave dans Paramètres → Recherche Web pour activer les recherches.'), h('a', { href: 'https://www.tavily.com/', target: '_blank', rel: 'noopener' }, 'Tavily'), ' · ', h('a', { href: 'https://brave.com/search/api/', target: '_blank', rel: 'noopener' }, 'Brave Search API')),  imagePick, list, h('div', { class: 'composer' }, input, send));
  load(); return { refresh: load };
};

SCREENS.world = (main) => {
  let tab = S.worldTab || 'generate'; S.worldTab = null;
  const tabs = h('div', { class: 'tabs' }), body = h('div');
  main.append(h('h1', {}, 'OPS WORLD AI'), h('p', { class: 'muted' }, 'Génération procédurale réelle de villes et d’environnements (terrain, eau, routes, quartiers, bâtiments en volumes simples), validée automatiquement et exportée en JSON / OBJ / SVG. Même graine = même monde.'), needsProvider(), tabs, body);
  const TABS = [['generate', 'Générer'], ['worlds', 'Mondes générés'], ['chat', 'Discuter']];
  const paintTabs = () => tabs.replaceChildren(...TABS.map(([id, l]) => h('button', { class: tab === id ? 'on' : '', onclick: () => { tab = id; paintTabs(); load(); } }, l)));
  const P = () => S.project.id;
  const fetchFile = async (id, kind) => { const r = await fetch(`/api/world/worlds/${id}/download?kind=${kind}`, { headers: { authorization: 'Bearer ' + S.token } }); if (!r.ok) throw new Error('Téléchargement impossible'); return r.blob(); };
  const save = guard(async (w, kind, name) => { const a = h('a', { href: URL.createObjectURL(await fetchFile(w.id, kind)), download: `${w.name}-${w.seed}.${name}` }); document.body.append(a); a.click(); a.remove(); });
  const opt = (v, list, labels = {}) => h('select', {}, list.map((x) => h('option', { value: x, selected: x === v }, labels[x] || x)));
  const worldCard = (w) => {
    const img = h('img', { alt: 'Aperçu ' + w.name, style: 'width:100%;max-width:420px;border-radius:8px;background:#0a111b;image-rendering:pixelated' });
    fetchFile(w.id, 'svg').then((b) => { img.src = URL.createObjectURL(b); }).catch(() => { img.alt = 'Aperçu indisponible'; });
    const s = w.stats;
    return h('div', { class: 'card', style: 'margin-bottom:12px' }, h('div', { class: 'row' }, h('h2', { style: 'margin:0;flex:1' }, w.name), w.valid ? h('span', { class: 'pill ok' }, 'valide') : h('span', { class: 'pill error' }, 'invalide')),
      h('div', { class: 'row', style: 'align-items:flex-start;margin-top:8px' }, img, h('div', { style: 'flex:1;min-width:220px' },
        h('p', { class: 'small' }, `Graine « ${w.seed} » · ${s.size_m} m · thème ${w.params.theme} · eau ${w.params.water} · cible ${w.params.target}`),
        h('p', { class: 'small' }, `${s.buildings} bâtiments · ${s.parks} parcs · ${s.road_cells} cellules de route · ${s.bridges} pont(s) · ${s.districts} quartiers · eau ${Math.round(s.water_ratio * 100)} %`),
        h('p', { class: 'small' }, `Triangles estimés : ${s.triangles} / ${s.triangle_budget}${s.trimmed ? ` · ${s.trimmed} bâtiment(s) retiré(s) pour le budget` : ''}`),
        s.landmarks.length > 0 && h('p', { class: 'small' }, 'Monuments : ' + s.landmarks.join(', ')),
        h('p', { class: 'small muted' }, w.files_mode === 'proposed' ? `Fichiers proposés dans « ${w.folder}/ » — à approuver dans Développement › Approbations.` : w.files_mode === 'written' ? `Fichiers écrits dans « ${w.folder}/ ».` : 'Fichiers non livrés (monde invalide).'),
        w.issues.map((i) => h('div', { class: 'alert ' + (i.level === 'error' ? 'err' : '') }, i.msg)),
        h('div', { class: 'row', style: 'margin-top:8px' }, h('button', { class: 'small', onclick: () => save(w, 'json', 'world.json') }, 'JSON'), h('button', { class: 'small', onclick: () => save(w, 'obj', 'obj') }, 'OBJ'), h('button', { class: 'small', onclick: () => save(w, 'svg', 'svg') }, 'SVG')))));
  };
  let seq = 0;
  const load = guard(async () => {
    const my = ++seq, put = (...n) => { if (my === seq) body.replaceChildren(...n); }; // une réponse tardive ne remplace jamais un rendu plus récent
    if (tab === 'generate') {
      const f = { name: h('input', { value: 'Ville OPS' }), seed: h('input', { placeholder: 'vide = aléatoire' }), size: opt('medium', ['small', 'medium', 'large'], { small: 'petite (576 m)', medium: 'moyenne (960 m)', large: 'grande (1 536 m)' }), theme: opt('modern', ['modern', 'coastal', 'desert', 'snow', 'rural']), water: opt('river', ['none', 'river', 'coast'], { none: 'aucune', river: 'rivière', coast: 'côte' }), target: opt('mobile', ['mobile', 'pc']),
        density: h('input', { type: 'number', min: '0.1', max: '1', step: '0.1', value: '0.6' }), districts: h('input', { type: 'number', min: '3', max: '8', value: '5' }), landmarks: h('input', { type: 'number', min: '0', max: '7', value: '3' }) };
      const lab = (t, el) => h('div', {}, h('label', {}, t), el);
      const out = h('div');
      const show = (r) => out.replaceChildren(worldCard(r.world));
      const brief = h('textarea', { rows: '3', placeholder: 'Ex. « Petite ville côtière, dense au centre, jouable sur Android, avec un port et deux monuments »' });
      put(
        h('div', { class: 'card', style: 'margin-bottom:12px' }, h('h2', {}, 'Paramètres'), h('div', { class: 'grid' }, lab('Nom', f.name), lab('Graine', f.seed), lab('Taille', f.size), lab('Thème', f.theme), lab('Eau', f.water), lab('Cible', f.target), lab('Densité (0,1–1)', f.density), lab('Quartiers (3–8)', f.districts), lab('Monuments (0–7)', f.landmarks)),
          h('div', { style: 'margin-top:10px' }, h('button', { class: 'primary', onclick: guard(async (e) => { e.target.disabled = true; try { const params = Object.fromEntries(Object.entries(f).map(([k, el]) => [k, el.value]).filter(([k, v]) => !(k === 'seed' && !v))); show(await api('POST', '/api/world/generate', { project_id: P(), params })); toast('Monde généré'); } finally { e.target.disabled = false; } }) }, 'Générer le monde'))),
        h('div', { class: 'card', style: 'margin-bottom:12px' }, h('h2', {}, 'Depuis un brief (IA)'), h('p', { class: 'muted small' }, 'WORLD AI choisit les paramètres avec le modèle configuré ; le monde est ensuite généré par le même algorithme. Nécessite un fournisseur IA réel.'), brief,
          h('div', { style: 'margin-top:6px' }, h('button', { onclick: guard(async (e) => { e.target.disabled = true; e.target.textContent = 'WORLD AI réfléchit…'; try { show(await api('POST', '/api/world/from-brief', { project_id: P(), brief: brief.value })); toast('Monde généré'); } finally { e.target.disabled = false; e.target.textContent = 'Générer depuis le brief'; } }) }, 'Générer depuis le brief'))), out);
    } else if (tab === 'worlds') {
      const ws = await api('GET', `/api/world/worlds?project_id=${P()}`);
      put(...(ws.length ? ws.map(worldCard) : [h('div', { class: 'card muted' }, 'Aucun monde généré pour ce projet.')]));
    } else {
      const ms = await api('GET', `/api/messages?project_id=${P()}&agent_id=world`);
      const list = h('div', { class: 'msgs', style: 'max-height:58dvh;min-height:200px;border:1px solid var(--line);border-radius:10px;padding:10px;background:#0a111b' }, ms.map((m) => h('div', { class: 'msg ' + m.role }, h('div', { class: 'who' }, m.role === 'user' ? 'Vous' : 'OPS WORLD AI'), m.role === 'user' ? h('div', {}, m.content) : md(m.content))), !ms.length && h('div', { class: 'muted' }, 'Parlez à WORLD AI : décrivez le monde voulu ; il le génère par action réelle (visible dans « Mondes générés ») et vous rapporte le résultat vérifié.'));
      const input = h('textarea', { rows: '2', placeholder: 'Écrire à WORLD AI…', onkeydown: (e) => { if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) { e.preventDefault(); send.click(); } } });
      const send = h('button', { class: 'primary', onclick: guard(async () => { const text = input.value.trim(); if (!text) return; send.disabled = true; input.disabled = true; list.append(h('div', { class: 'msg user' }, h('div', { class: 'who' }, 'Vous'), text), h('div', { class: 'msg' }, h('span', { class: 'spin' }), ' WORLD AI réfléchit…')); list.scrollTop = list.scrollHeight; input.value = ''; try { await api('POST', '/api/studio/world/chat', { project_id: P(), text }); } finally { load(); } }) }, 'Envoyer');
      put(h('div', {}, list, h('div', { class: 'composer' }, input, send))); list.scrollTop = list.scrollHeight;
    }
  });
  // les événements serveur ne rafraîchissent que la liste (sinon le formulaire et le brouillon de message seraient effacés)
  paintTabs(); load(); return { refresh: () => { if (tab === 'worlds') load(); } };
};

SCREENS.modeling = (main) => {
  let tab = S.modelTab || 'generate'; S.modelTab = null;
  const tabs = h('div', { class: 'tabs' }), body = h('div');
  main.append(h('h1', {}, 'OPS MODELING AI'), h('p', { class: 'muted' }, 'Modélisation procédurale réelle : 11 bâtiments/monuments et 4 props, 3 LOD, collisions, matériaux PBR et textures procédurales BaseColor / Normal / ORM, export glTF 2.0 / OBJ. Le « kit » transforme un monde WORLD AI en archétypes instanciables avec placements (contrat ops-assets, lisible par les autres IA).'), needsProvider(), tabs, body);
  const TABS = [['generate', 'Générer'], ['assets', 'Modèles & kits'], ['sculpt', 'Éditeur de sculpture'], ['chat', 'Discuter']];
  const paintTabs = () => tabs.replaceChildren(...TABS.map(([id, l]) => h('button', { class: tab === id ? 'on' : '', onclick: () => { tab = id; paintTabs(); load(); } }, l)));
  const P = () => S.project.id;
  const fetchFile = async (id, file) => { const r = await fetch(`/api/modeling/assets/${id}/download?file=${encodeURIComponent(file)}`, { headers: { authorization: 'Bearer ' + S.token } }); if (!r.ok) throw new Error('Téléchargement impossible'); return r.blob(); };
  const save = guard(async (a, file) => { const l = h('a', { href: URL.createObjectURL(await fetchFile(a.id, file)), download: file }); document.body.append(l); l.click(); l.remove(); });
  const opt = (v, list) => h('select', {}, list.map((x) => h('option', { value: x, selected: x === v }, x)));
  const KINDS = ['house', 'office', 'factory', 'warehouse', 'tower', 'cityhall', 'stadium', 'cathedral', 'museum', 'market', 'station', 'tree', 'streetlight', 'bench', 'crate'];
  const STYLES = ['béton', 'verre', 'crépi', 'bois', 'adobe', 'grès', 'brique', 'ardoise'];
  const QUALITIES = ['balanced', 'high', 'ultra'];
  const card = (a) => {
    const prev = a.files.find((f) => f.endsWith('_preview.svg')), img = prev && h('img', { alt: 'Aperçu ' + a.name, style: 'width:100%;max-width:300px;border-radius:8px;background:#0a111b' });
    if (img) fetchFile(a.id, prev).then((b) => { img.src = URL.createObjectURL(b); }).catch(() => { img.alt = 'Aperçu indisponible'; });
    const s = a.stats, isKit = a.type === 'kit';
    return h('div', { class: 'card', style: 'margin-bottom:12px' }, h('div', { class: 'row' }, h('h2', { style: 'margin:0;flex:1' }, a.name), h('span', { class: 'pill' }, isKit ? 'kit' : 'modèle'), a.valid ? h('span', { class: 'pill ok' }, 'valide') : h('span', { class: 'pill error' }, 'invalide')),
      h('div', { class: 'row', style: 'align-items:flex-start;margin-top:8px' }, img, h('div', { style: 'flex:1;min-width:220px' },
        isKit ? [h('p', { class: 'small' }, `Monde « ${s.world} » : ${s.buildings} bâtiments → ${s.archetypes} archétypes + ${s.props} props (${s.merged_variants} variantes fusionnées, écart de forme max ${Math.round(s.max_scale_error * 100)} %)`),
          h('p', { class: 'small' }, `Triangles instanciés : LOD0 ${s.instanced_triangles.lod0} · LOD1 ${s.instanced_triangles.lod1} · LOD2 ${s.instanced_triangles.lod2}`)]
          : [h('p', { class: 'small' }, `${s.kind} · style ${s.style} · qualité ${s.quality || 'balanced'} · ${s.floors} étage(s) · ${s.height} m · emprise ${s.footprint.join(' × ')} m`), h('p', { class: 'small' }, `Triangles par LOD : ${s.lods.map((l) => l.triangles).join(' / ')} · ${s.materials} matériaux PBR · ${s.texture_maps || 0} maps ${s.texture_resolution || '512x512'} · ${s.collision_hulls} collision(s)`)],
        h('p', { class: 'small muted' }, a.files_mode === 'proposed' ? `Fichiers proposés dans « ${a.folder}/ » — à approuver dans Développement › Approbations.` : a.files_mode === 'written' ? `Fichiers écrits dans « ${a.folder}/ ».` : 'Fichiers non livrés (invalide).'),
        a.issues.filter((i) => i.level === 'error').slice(0, 5).map((i) => h('div', { class: 'alert err' }, i.msg)),
        h('details', {}, h('summary', {}, `Télécharger (${a.files.length} fichiers)`), h('div', { class: 'row', style: 'margin-top:6px;flex-wrap:wrap' }, a.files.map((f) => h('button', { class: 'small', onclick: () => save(a, f) }, f)))))));
  };
  let seq = 0;
  const load = guard(async () => {
    const my = ++seq, put = (...n) => { if (my === seq) body.replaceChildren(...n); };
    if (tab === 'generate') {
      const worlds = (await api('GET', `/api/world/worlds?project_id=${P()}`)).filter((w) => w.valid);
      const f = { kind: opt('house', KINDS), style: opt('béton', STYLES), quality: opt('high', QUALITIES), floors: h('input', { type: 'number', min: '1', max: '60', value: '4' }), width: h('input', { type: 'number', min: '6', max: '80', value: '14' }), depth: h('input', { type: 'number', min: '6', max: '80', value: '14' }), name: h('input', { placeholder: 'optionnel (SM_…)' }), texture_resolution: opt('512', ['64','128','256','512','1024','2048']) };
      const wsel = h('select', {}, worlds.map((w) => h('option', { value: w.id }, `${w.name} — ${w.stats.buildings} bâtiments`))), maxA = h('input', { type: 'number', min: '4', max: '64', value: '48' });
      const lab = (t, el) => h('div', {}, h('label', {}, t), el), out = h('div'), show = (r) => out.replaceChildren(card(r.asset));
      const brief = h('textarea', { rows: '3', placeholder: 'Ex. « Une tour de verre de 30 étages » ou « le kit de bâtiments de la ville »' });
      put(h('div', { class: 'card', style: 'margin-bottom:12px' }, h('h2', {}, 'Un modèle'), h('p', { class: 'small muted' }, 'Profils de géométrie : Balanced pour mobile, High pour un meilleur niveau de détail, Ultra pour les assets héros. Les exports incluent désormais des maps PBR procédurales configurables de 64×64 à 2048×2048 (BaseColor, Normal, ORM), exportées en PNG externes référencés par glTF. La résolution élevée augmente fortement la taille et le temps de génération ; elle ne remplace pas la peinture artistique ni un sculpting dédié.'), h('div', { class: 'grid' }, lab('Type', f.kind), lab('Style', f.style), lab('Profil de qualité', f.quality), lab('Étages (bâtiments)', f.floors), lab('Largeur m', f.width), lab('Profondeur m', f.depth), lab('Résolution PBR', f.texture_resolution), lab('Nom', f.name)),
          h('div', { style: 'margin-top:10px' }, h('button', { class: 'primary', onclick: guard(async (e) => { e.target.disabled = true; try { const params = Object.fromEntries(Object.entries(f).map(([k, el]) => [k, el.value]).filter(([, v]) => v !== '')); show(await api('POST', '/api/modeling/generate', { project_id: P(), params })); toast('Modèle généré'); } finally { e.target.disabled = false; } }) }, 'Générer le modèle'))),
        h('div', { class: 'card', style: 'margin-bottom:12px' }, h('h2', {}, 'Kit pour un monde WORLD AI'), worlds.length ? [h('p', { class: 'muted small' }, 'Regroupe les bâtiments du monde en archétypes instanciables (formes proches fusionnées, écart limité à ×1,35) et calcule les placements.'), h('div', { class: 'grid' }, lab('Monde', wsel), lab('Archétypes max (4–64)', maxA)),
          h('div', { style: 'margin-top:10px' }, h('button', { class: 'primary', onclick: guard(async (e) => { e.target.disabled = true; e.target.textContent = 'Génération…'; try { show(await api('POST', '/api/modeling/kit', { project_id: P(), world_id: wsel.value, max_archetypes: Number(maxA.value) })); toast('Kit généré'); } finally { e.target.disabled = false; e.target.textContent = 'Générer le kit'; } }) }, 'Générer le kit'))] : h('p', { class: 'muted' }, 'Aucun monde valide dans ce projet : générez-en un avec WORLD AI d’abord.')),
        h('div', { class: 'card', style: 'margin-bottom:12px' }, h('h2', {}, 'Depuis un brief (IA)'), h('p', { class: 'muted small' }, 'MODELING AI choisit modèle ou kit et les paramètres avec le modèle configuré ; la génération reste celle de l’algorithme. Nécessite un fournisseur IA réel.'), brief,
          h('div', { style: 'margin-top:6px' }, h('button', { onclick: guard(async (e) => { e.target.disabled = true; e.target.textContent = 'MODELING AI réfléchit…'; try { show(await api('POST', '/api/modeling/from-brief', { project_id: P(), brief: brief.value })); toast('Généré'); } finally { e.target.disabled = false; e.target.textContent = 'Générer depuis le brief'; } }) }, 'Générer depuis le brief'))), out);
    } else if (tab === 'assets') {
      const as = await api('GET', `/api/modeling/assets?project_id=${P()}`);
      put(...(as.length ? as.map(card) : [h('div', { class: 'card muted' }, 'Aucun modèle ni kit pour ce projet.')]));
    } else if (tab === 'sculpt') {
      const as = (await api('GET', `/api/modeling/assets?project_id=${P()}`)).filter((a) => a.type === 'asset' && a.valid);
      if (!as.length) { put(h('div', { class: 'card muted' }, 'Générez d’abord un modèle valide dans l’onglet Générer. Les kits de ville ne sont pas sculptables individuellement.')); return; }
      const pick = h('select', {}, as.map((a) => h('option', { value: a.id }, `${a.name} · ${a.stats?.kind || 'modèle'}`)));
      const mode = opt('inflate', ['inflate', 'smooth', 'flatten']);
      const radius = h('input', { type: 'number', min: '0.1', max: '30', step: '0.1', value: '1.5' });
      const strength = h('input', { type: 'number', min: '-0.25', max: '0.25', step: '0.01', value: '0.08' });
      const cx = h('input', { type: 'number', step: '0.1', value: '0' }), cy = h('input', { type: 'number', step: '0.1', value: '2' }), cz = h('input', { type: 'number', step: '0.1', value: '0' });
      const status = h('div', { class: 'small muted' }, 'Choisissez un modèle, réglez le pinceau et appliquez une opération. La sauvegarde est non destructive par rapport aux paramètres d’origine et recalcule les trois LOD.');
      const viewport = h('div', { style: 'position:relative;width:100%;height: min(62vw,420px);min-height:260px;max-height:460px;background:radial-gradient(ellipse at 50% 42%,#26384c,#0a111b 72%);border:1px solid var(--line);border-radius:12px;overflow:hidden;touch-action:none' });
      const canvas = h('canvas', { 'aria-label': 'Viewport 3D interactif du modèle', style: 'display:block;width:100%;height:100%;touch-action:none' });
      const hint = h('div', { class: 'small muted', style: 'position:absolute;left:10px;bottom:8px;pointer-events:none;background:#07101dcc;padding:5px 8px;border-radius:6px' }, 'Glisser : tourner · Pincer / molette : zoom');
      viewport.append(canvas, hint);
      const current = () => as.find((a) => a.id === pick.value) || as[0];
      let glState = null, drag = null, pinchDistance = 0, rotX = -0.22, rotY = 0.55, zoom = 1; const activePointers = new Map();
      const compile = (gl, type, src) => { const sh = gl.createShader(type); gl.shaderSource(sh, src); gl.compileShader(sh); if (!gl.getShaderParameter(sh, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(sh) || 'Shader invalide'); return sh; };
      const initViewport = () => {
        const gl = canvas.getContext('webgl2', { antialias: true, alpha: true });
        if (!gl) throw new Error('WebGL 2 indisponible sur ce navigateur.');
        const vs = compile(gl, gl.VERTEX_SHADER, `#version 300 es
 in vec3 aPosition; in vec3 aNormal; in vec2 aUV; out vec2 vUV; uniform float uRX; uniform float uRY; uniform float uZoom; uniform float uAspect; out vec3 vNormal; out vec3 vPosition; void main(){ float cy=cos(uRY), sy=sin(uRY), cx=cos(uRX), sx=sin(uRX); vec3 p=vec3(aPosition.x*cy-aPosition.z*sy,aPosition.y,aPosition.x*sy+aPosition.z*cy); vec3 n=vec3(aNormal.x*cy-aNormal.z*sy,aNormal.y,aNormal.x*sy+aNormal.z*cy); p=vec3(p.x,p.y*cx-p.z*sx,p.y*sx+p.z*cx); n=vec3(n.x,n.y*cx-n.z*sx,n.y*sx+n.z*cx); float depth=3.4-p.z; float focal=2.15*uZoom; gl_Position=vec4(p.x*focal/uAspect,p.y*focal,(depth-0.15)/4.0,depth); vNormal=normalize(n); vPosition=p; vUV=aUV; }`);
        const fs = compile(gl, gl.FRAGMENT_SHADER, `#version 300 es
 precision highp float; uniform vec4 uColor; uniform sampler2D uBase; uniform sampler2D uNormalMap; uniform sampler2D uORM; uniform int uHasBase; uniform int uHasNormal; uniform int uHasORM; uniform float uEnvStrength; uniform float uKeyStrength; uniform float uRoughnessBias; uniform float uMetalBoost; uniform float uRoughFactor; uniform float uMetalFactor; uniform int uStudio; in vec3 vNormal; in vec3 vPosition; in vec2 vUV; out vec4 outColor; void main(){ vec3 base=uColor.rgb; if(uHasBase==1) base*=texture(uBase,vUV).rgb; vec3 n=normalize(vNormal); if(uHasNormal==1){ vec3 mapN=texture(uNormalMap,vUV).xyz*2.0-1.0; vec3 dp1=dFdx(vNormal),dp2=dFdy(vNormal); vec2 duv1=dFdx(vUV),duv2=dFdy(vUV); vec3 t=normalize(dp1*duv2.y-dp2*duv1.y); vec3 b=normalize(-dp1*duv2.x+dp2*duv1.x); n=normalize(mat3(t,b,n)*mapN); } float ao=1.0,rough=0.7,metal=0.0; if(uHasORM==1){vec3 orm=texture(uORM,vUV).rgb;ao=orm.r;rough=orm.g;metal=orm.b;} rough=clamp(rough*uRoughFactor+uRoughnessBias,0.06,1.0); metal=clamp(metal*uMetalFactor+uMetalBoost,0.0,1.0); vec3 key=uStudio==0?normalize(vec3(-0.45,0.8,0.55)):uStudio==1?normalize(vec3(0.55,0.65,0.72)):normalize(vec3(-0.15,0.95,-0.3)); vec3 viewDir=normalize(vec3(0.0,0.25,3.4)-vPosition); float hemi=mix(0.34,0.78,n.y*0.5+0.5); float ndl=max(dot(n,key),0.0); float diffuse=uEnvStrength*hemi+uKeyStrength*ndl; vec3 halfDir=normalize(key+viewDir); float specPow=mix(128.0,5.0,rough); float spec=pow(max(dot(n,halfDir),0.0),specPow)*mix(0.04,0.72,metal)*uKeyStrength; float rim=pow(1.0-max(dot(n,viewDir),0.0),3.0)*0.12*uEnvStrength; vec3 envTint=uStudio==1?vec3(0.78,0.88,1.0):uStudio==2?vec3(1.0,0.82,0.62):vec3(0.9,0.94,1.0); vec3 lit=base*diffuse*mix(0.55,1.0,ao)+envTint*(spec+rim); outColor=vec4(lit,uColor.a); }`);
        const program = gl.createProgram(); gl.attachShader(program,vs); gl.attachShader(program,fs); gl.linkProgram(program); if (!gl.getProgramParameter(program,gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(program)||'Programme 3D invalide');
        gl.enable(gl.DEPTH_TEST); gl.enable(gl.CULL_FACE); gl.useProgram(program);
        glState = { gl, program, meshes: [], uniforms: { rx:gl.getUniformLocation(program,'uRX'), ry:gl.getUniformLocation(program,'uRY'), zoom:gl.getUniformLocation(program,'uZoom'), aspect:gl.getUniformLocation(program,'uAspect'), color:gl.getUniformLocation(program,'uColor'), base:gl.getUniformLocation(program,'uBase'), normal:gl.getUniformLocation(program,'uNormalMap'), orm:gl.getUniformLocation(program,'uORM'), hasBase:gl.getUniformLocation(program,'uHasBase'), hasNormal:gl.getUniformLocation(program,'uHasNormal'), hasORM:gl.getUniformLocation(program,'uHasORM'), env:gl.getUniformLocation(program,'uEnvStrength'), key:gl.getUniformLocation(program,'uKeyStrength'), roughBias:gl.getUniformLocation(program,'uRoughnessBias'), metalBoost:gl.getUniformLocation(program,'uMetalBoost'), roughFactor:gl.getUniformLocation(program,'uRoughFactor'), metalFactor:gl.getUniformLocation(program,'uMetalFactor'), studio:gl.getUniformLocation(program,'uStudio') } };
        return glState;
      };
      const accessorArray = (doc, bin, index) => { const a=doc.accessors[index], v=doc.bufferViews[a.bufferView], off=(v.byteOffset||0)+(a.byteOffset||0), count=a.count, n=a.type==='VEC3'?3:a.type==='VEC2'?2:1, C={5120:Int8Array,5121:Uint8Array,5122:Int16Array,5123:Uint16Array,5125:Uint32Array,5126:Float32Array}[a.componentType]; if(!C) throw new Error('Type de sommet glTF non pris en charge'); return new C(bin,off,count*n); };
      const loadViewport = async () => {
        const a=current(), file=a.files.find((x)=>x.endsWith('.gltf')); if(!file) throw new Error('Fichier glTF absent pour ce modèle.');
        const detail=await api('GET', `/api/modeling/assets/${a.id}`); materialCatalog=detail.material_catalog||[]; refreshMaterialOptions();
        const blob=await fetchFile(a.id,file), doc=JSON.parse(await blob.text()), uri=doc.buffers?.[0]?.uri; if(!uri?.startsWith('data:')) throw new Error('Le buffer glTF intégré est introuvable.');
        const raw=atob(uri.slice(uri.indexOf(',')+1)), bin=new ArrayBuffer(raw.length), bytes=new Uint8Array(bin); for(let i=0;i<raw.length;i++) bytes[i]=raw.charCodeAt(i);
        const state=glState||initViewport(), gl=state.gl; state.meshes.forEach(m=>{gl.deleteBuffer(m.p);gl.deleteBuffer(m.n);gl.deleteBuffer(m.uv);gl.deleteBuffer(m.i);for(const t of [m.baseTexture,m.normalTexture,m.ormTexture])if(t)gl.deleteTexture(t)}); state.meshes=[];
        const nodes=doc.nodes||[], meshes=doc.meshes||[], node=nodes[0], meshIds=(node?.children||[]).filter(i=>nodes[i]?.extras?.ops_lod===0).map(i=>nodes[i]?.mesh).filter(Number.isInteger); const chosen=meshIds.length?meshIds:[0];
        const boundsMin=[Infinity,Infinity,Infinity],boundsMax=[-Infinity,-Infinity,-Infinity]; for(const mi of chosen) for(const prim of meshes[mi]?.primitives||[]){const ai=prim.attributes?.POSITION,a=doc.accessors?.[ai];if(a?.min&&a?.max)for(let k=0;k<3;k++){boundsMin[k]=Math.min(boundsMin[k],a.min[k]);boundsMax[k]=Math.max(boundsMax[k],a.max[k]);}} const center=boundsMin.map((v,k)=>(v+boundsMax[k])/2), extent=Math.max(...boundsMax.map((v,k)=>v-boundsMin[k]),0.001), scale=2.2/extent; state.modelTransform={center,scale};
        for(const mi of chosen){ const mesh=meshes[mi]; for(const prim of mesh?.primitives||[]){ if(prim.attributes?.POSITION===undefined||prim.indices===undefined) continue; const pos=new Float32Array(accessorArray(doc,bin,prim.attributes.POSITION)), nor=prim.attributes.NORMAL===undefined?new Float32Array(pos.length):accessorArray(doc,bin,prim.attributes.NORMAL), idx=accessorArray(doc,bin,prim.indices); for(let k=0;k<pos.length;k+=3){pos[k]=(pos[k]-center[0])*scale;pos[k+1]=(pos[k+1]-center[1])*scale;pos[k+2]=(pos[k+2]-center[2])*scale;} if(!nor.some(v=>v!==0)){for(let i=0;i<nor.length;i+=3)nor[i+1]=1;}
          const uv=prim.attributes?.TEXCOORD_0!==undefined?new Float32Array(accessorArray(doc,bin,prim.attributes.TEXCOORD_0)):new Float32Array(pos.length/3*2); const pbuf=gl.createBuffer(), nbuf=gl.createBuffer(), uvbuf=gl.createBuffer(), ibuf=gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER,pbuf); gl.bufferData(gl.ARRAY_BUFFER,pos,gl.STATIC_DRAW); gl.bindBuffer(gl.ARRAY_BUFFER,nbuf); gl.bufferData(gl.ARRAY_BUFFER,nor,gl.STATIC_DRAW); gl.bindBuffer(gl.ARRAY_BUFFER,uvbuf); gl.bufferData(gl.ARRAY_BUFFER,uv,gl.STATIC_DRAW); gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,ibuf); gl.bufferData(gl.ELEMENT_ARRAY_BUFFER,idx,gl.STATIC_DRAW);
          const material=doc.materials?.[prim.material]||{}, pbr=material.pbrMetallicRoughness||{}, texFor=(slot)=>{const ti=slot?.index,src=Number.isInteger(ti)?doc.textures?.[ti]?.source:null,img=Number.isInteger(src)?doc.images?.[src]:null;return img?.uri||null;}; const loadTexture=async(name)=>{if(!name)return null;try{const bitmap=await createImageBitmap(await fetchFile(a.id,name));const t=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,t);gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL,true);gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,gl.RGBA,gl.UNSIGNED_BYTE,bitmap);gl.generateMipmap(gl.TEXTURE_2D);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.LINEAR_MIPMAP_LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.REPEAT);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.REPEAT);bitmap.close?.();return t;}catch(err){console.warn('Texture PBR indisponible:',name,err);return null;}}; const [baseTexture,normalTexture,ormTexture]=await Promise.all([loadTexture(texFor(pbr.baseColorTexture)),loadTexture(texFor(material.normalTexture)),loadTexture(texFor(pbr.metallicRoughnessTexture)||texFor(material.occlusionTexture))]); const mat=pbr.baseColorFactor||[0.55,0.62,0.72,1]; state.meshes.push({p:pbuf,n:nbuf,uv:uvbuf,i:ibuf,count:idx.length,type:idx instanceof Uint32Array?gl.UNSIGNED_INT:idx instanceof Uint8Array?gl.UNSIGNED_BYTE:gl.UNSIGNED_SHORT,color:mat,roughnessFactor:pbr.roughnessFactor??1,metallicFactor:pbr.metallicFactor??1,baseTexture,normalTexture,ormTexture,vertices:pos,indices:idx});
        }}
        if(!state.meshes.length) throw new Error('Aucun maillage triangulé trouvé dans le glTF.'); drawViewport();
      };
      const drawViewport = () => { if(!glState)return; const {gl,program,meshes,uniforms:u}=glState, dpr=Math.min(window.devicePixelRatio||1,2), w=Math.max(1,Math.floor(canvas.clientWidth*dpr)), hgt=Math.max(1,Math.floor(canvas.clientHeight*dpr)); if(canvas.width!==w||canvas.height!==hgt){canvas.width=w;canvas.height=hgt;} gl.viewport(0,0,w,hgt); gl.clearColor(0.025,0.045,0.07,0); gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT); gl.useProgram(program); gl.uniform1f(u.rx,rotX);gl.uniform1f(u.ry,rotY);gl.uniform1f(u.zoom,zoom);gl.uniform1f(u.aspect,w/hgt);gl.uniform1f(u.env,Number(envStrength.value));gl.uniform1f(u.key,Number(keyStrength.value));gl.uniform1f(u.roughBias,Number(roughnessBias.value));gl.uniform1f(u.metalBoost,Number(metalBoost.value));gl.uniform1i(u.studio,studio.value==='cool'?1:studio.value==='warm'?2:0); for(const m of meshes){gl.bindBuffer(gl.ARRAY_BUFFER,m.p);const lp=gl.getAttribLocation(program,'aPosition');gl.enableVertexAttribArray(lp);gl.vertexAttribPointer(lp,3,gl.FLOAT,false,0,0);gl.bindBuffer(gl.ARRAY_BUFFER,m.n);const ln=gl.getAttribLocation(program,'aNormal');gl.enableVertexAttribArray(ln);gl.vertexAttribPointer(ln,3,gl.FLOAT,false,0,0);gl.bindBuffer(gl.ARRAY_BUFFER,m.uv);const lu=gl.getAttribLocation(program,'aUV');gl.enableVertexAttribArray(lu);gl.vertexAttribPointer(lu,2,gl.FLOAT,false,0,0);gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,m.i);gl.uniform4fv(u.color,m.color);gl.uniform1f(u.roughFactor,m.roughnessFactor);gl.uniform1f(u.metalFactor,m.metallicFactor);for(const [unit,tex,hasLoc,samplerLoc] of [[0,m.baseTexture,u.hasBase,u.base],[1,m.normalTexture,u.hasNormal,u.normal],[2,m.ormTexture,u.hasORM,u.orm]]){gl.activeTexture(gl.TEXTURE0+unit);gl.bindTexture(gl.TEXTURE_2D,tex||null);gl.uniform1i(hasLoc,tex?1:0);gl.uniform1i(samplerLoc,unit);}gl.drawElements(gl.TRIANGLES,m.count,m.type,0);} };
      const touchSculpt = h('input', { type:'checkbox' });
      const studio = opt('neutral', ['neutral','cool','warm']);
      const envStrength = h('input', { type:'range', min:'0.1', max:'1.5', step:'0.05', value:'0.65' });
      const keyStrength = h('input', { type:'range', min:'0.1', max:'2', step:'0.05', value:'1.0' });
      const roughnessBias = h('input', { type:'range', min:'-0.5', max:'0.5', step:'0.05', value:'0' });
      const metalBoost = h('input', { type:'range', min:'0', max:'0.5', step:'0.05', value:'0' });
      [studio,envStrength,keyStrength,roughnessBias,metalBoost].forEach(el=>el.addEventListener('input',drawViewport));
      // Material presets are local to this browser and project; they only adjust studio preview lighting.
      // Les fichiers glTF originaux restent inchangés tant que l'utilisateur n'enregistre pas un matériau PBR ci-dessous.
      const materialPresets = [
        {id:'concrete',name:'Béton mat',studio:'neutral',env:'0.78',key:'0.82',rough:'0.18',metal:'0'},
        {id:'painted-metal',name:'Métal peint',studio:'cool',env:'0.58',key:'1.35',rough:'-0.12',metal:'0.28'},
        {id:'polished-metal',name:'Métal poli',studio:'cool',env:'0.48',key:'1.65',rough:'-0.32',metal:'0.5'},
        {id:'wood',name:'Bois verni',studio:'warm',env:'0.72',key:'1.05',rough:'-0.08',metal:'0'},
        {id:'rubber',name:'Caoutchouc',studio:'neutral',env:'0.52',key:'0.7',rough:'0.35',metal:'0'},
        {id:'stone',name:'Pierre',studio:'warm',env:'0.7',key:'0.9',rough:'0.25',metal:'0'}
      ];
      const presetKey = `ops.material-presets.${P()}`;
      const readCustomPresets = () => { try { const v=JSON.parse(localStorage.getItem(presetKey)||'[]'); return Array.isArray(v)?v.filter(x=>x&&typeof x.name==='string'&&['neutral','cool','warm'].includes(x.studio)):[]; } catch { return []; } };
      const presetSelect = h('select', {}), presetName = h('input', {type:'text',maxLength:'32',placeholder:'Nom du preset personnalisé'});
      const refreshPresetOptions = (selected='') => { const all=[...materialPresets,...readCustomPresets()]; presetSelect.replaceChildren(...all.map(x=>h('option',{value:x.id,selected:x.id===selected},x.name))); };
      const applyMaterialPreset = (preset) => { if(!preset)return;studio.value=preset.studio;envStrength.value=preset.env;keyStrength.value=preset.key;roughnessBias.value=preset.rough;metalBoost.value=preset.metal;drawViewport();status.textContent=`Preset « ${preset.name} » appliqué à l’aperçu du modèle ${current().name}. Les fichiers glTF originaux restent inchangés.`; };
      refreshPresetOptions('concrete');
      const applyPresetButton = h('button',{class:'small primary',onclick:()=>{const all=[...materialPresets,...readCustomPresets()];applyMaterialPreset(all.find(x=>x.id===presetSelect.value));}},'Appliquer au modèle');
      const savePresetButton = h('button',{class:'small',onclick:()=>{const name=presetName.value.trim();if(!name){toast('Donnez un nom au preset',true);return;}const custom=readCustomPresets();const preset={id:`custom-${Date.now()}`,name,studio:studio.value,env:envStrength.value,key:keyStrength.value,rough:roughnessBias.value,metal:metalBoost.value};custom.push(preset);try{localStorage.setItem(presetKey,JSON.stringify(custom));presetName.value='';refreshPresetOptions(preset.id);toast('Preset enregistré sur cet appareil');}catch{toast('Stockage local indisponible ou saturé',true);}}},'Enregistrer le preset');
      const deletePresetButton = h('button',{class:'small',onclick:()=>{const custom=readCustomPresets().filter(x=>x.id!==presetSelect.value);try{localStorage.setItem(presetKey,JSON.stringify(custom));refreshPresetOptions('concrete');toast('Preset personnalisé supprimé');}catch{toast('Suppression impossible',true);}}},'Supprimer le preset personnalisé');
      let materialCatalog=[];
      const materialSelect=h('select',{}), materialColor=h('input',{type:'color',value:'#9e9e99'}), materialMetal=h('input',{type:'range',min:'0',max:'1',step:'0.01',value:'0'}), materialRough=h('input',{type:'range',min:'0',max:'1',step:'0.01',value:'0.8'});
      const refreshMaterialOptions=()=>{const selected=materialSelect.value;materialSelect.replaceChildren(...materialCatalog.map(m=>h('option',{value:m.id,selected:m.id===selected},m.name)));if(!materialCatalog.some(m=>m.id===selected)&&materialCatalog[0])materialSelect.value=materialCatalog[0].id;syncMaterialFields();};
      const syncMaterialFields=()=>{const m=materialCatalog.find(x=>x.id===materialSelect.value);if(!m)return;const c=m.baseColor||[.6,.6,.6,1];materialColor.value='#'+c.slice(0,3).map(v=>Math.round(v*255).toString(16).padStart(2,'0')).join('');materialMetal.value=String(m.metallic??0);materialRough.value=String(m.roughness??.8);};
      materialSelect.addEventListener('change',syncMaterialFields);
      const saveMaterialButton=h('button',{class:'small primary',onclick:guard(async(e)=>{const m=materialCatalog.find(x=>x.id===materialSelect.value);if(!m)return;e.target.disabled=true;try{const hex=materialColor.value, rgb=[1,3,5].map(i=>parseInt(hex.slice(i,i+2),16)/255);const r=await api('PUT',`/api/modeling/assets/${current().id}/materials/${encodeURIComponent(m.id)}`,{patch:{baseColor:[...rgb,1],metallic:Number(materialMetal.value),roughness:Number(materialRough.value)}});materialCatalog= r.asset.material_catalog||materialCatalog;const updated=materialCatalog.find(x=>x.id===m.id);if(updated)Object.assign(m,updated);await loadViewport();status.textContent=`Matériau ${m.name} enregistré dans le glTF et le MTL. Les textures PNG d'origine sont conservées.`;toast('Matériau enregistré durablement');}finally{e.target.disabled=false;}})},'Enregistrer le matériau');
      const selectedPoint = h('span', { class:'small muted' }, 'Aucun sommet sélectionné');
      const projectPoint = (x,y,z,aspect) => {
        const cY=Math.cos(rotY),sY=Math.sin(rotY),cX=Math.cos(rotX),sX=Math.sin(rotX);
        const px=x*cY-z*sY,pz=x*sY+z*cY,py=y*cX-pz*sX,pzz=y*sX+pz*cX,depth=3.4-pzz;
        if(depth<=0.15)return null;
        const focal=2.15*zoom;
        return {x:((px*focal/aspect/depth)+1)*0.5*canvas.clientWidth,y:(1-(py*focal/depth))*0.5*canvas.clientHeight,depth};
      };
      const barycentric = (p,a,b,c) => {
        const v0=[b.x-a.x,b.y-a.y],v1=[c.x-a.x,c.y-a.y],v2=[p.x-a.x,p.y-a.y],den=v0[0]*v1[1]-v1[0]*v0[1];
        if(Math.abs(den)<1e-8)return null;
        const v=(v2[0]*v1[1]-v1[0]*v2[1])/den,w=(v0[0]*v2[1]-v2[0]*v0[1])/den,u=1-v-w;
        return u>=-1e-5&&v>=-1e-5&&w>=-1e-5?[u,v,w]:null;
      };
      const pickSurface = (clientX,clientY) => {
        if(!glState?.meshes?.length||!glState.modelTransform)return null;
        const rect=canvas.getBoundingClientRect(),point={x:clientX-rect.left,y:clientY-rect.top},aspect=canvas.clientWidth/Math.max(1,canvas.clientHeight);
        let hit=null,nearest=Infinity;
        for(const mesh of glState.meshes){const pos=mesh.vertices,idx=mesh.indices;
          for(let t=0;t+2<idx.length;t+=3){const ids=[idx[t],idx[t+1],idx[t+2]],v=ids.map(i=>projectPoint(pos[i*3],pos[i*3+1],pos[i*3+2],aspect));if(v.some(x=>!x))continue;
            const weights=barycentric(point,v[0],v[1],v[2]);if(!weights)continue;
            const depth=weights[0]*v[0].depth+weights[1]*v[1].depth+weights[2]*v[2].depth;
            if(depth>=nearest)continue;nearest=depth;
            const local=[0,0,0];for(let j=0;j<3;j++)for(let k=0;k<3;k++)local[k]+=pos[ids[j]*3+k]*weights[j];
            const tr=glState.modelTransform,world=local.map((n,k)=>n/tr.scale+tr.center[k]);hit={world,local,depth};
          }
        }
        return hit;
      };
      const setSelectedPoint = (world) => {
        [cx,cy,cz].forEach((el,k)=>{el.value=world[k].toFixed(3)});
        selectedPoint.textContent=`Surface sélectionnée · X ${world[0].toFixed(2)} · Y ${world[1].toFixed(2)} · Z ${world[2].toFixed(2)} m`;
      };
      const pickVertex = (clientX,clientY) => {const hit=pickSurface(clientX,clientY);if(!hit)return false;setSelectedPoint(hit.world);status.textContent='Surface visible détectée par intersection triangle-écran avec priorité à la profondeur.';return true;};
      let stroke=[],strokePointer=null,lastStrokePoint=null,strokeBusy=false;
      const applyStroke = async () => {
        if(!stroke.length||strokeBusy)return;const ops=stroke.splice(0,32);strokeBusy=true;status.textContent=`Application du trait de sculpture (${ops.length} points)…`;
        try{const a=current(),r=await api('POST',`/api/modeling/assets/${a.id}/sculpt`,{operations:ops});Object.assign(a,r.asset);status.textContent=r.validation.ok?`Trait enregistré · ${r.operations.length} points · 3 LOD validés.`:'La validation a refusé le trait.';await loadPreview();toast('Trait de sculpture enregistré');}
        catch(err){status.textContent='Échec du trait : '+err.message;}
        finally{strokeBusy=false;}
      };
      const addStrokePoint = (x,y) => {if(stroke.length>=32)return false;const hit=pickSurface(x,y);if(!hit)return false;const w=hit.world;if(lastStrokePoint&&Math.hypot(w[0]-lastStrokePoint[0],w[1]-lastStrokePoint[1],w[2]-lastStrokePoint[2])<Math.max(0.035,Number(radius.value)*0.12))return true;
        setSelectedPoint(w);lastStrokePoint=w;stroke.push({mode:mode.value,center:w,radius:Number(radius.value),strength:Number(strength.value)});if(stroke.length>=32)status.textContent='Limite de 32 points atteinte pour ce trait. Relâchez puis recommencez.';return true;};
      canvas.addEventListener('pointerdown',(e)=>{activePointers.set(e.pointerId,{x:e.clientX,y:e.clientY});canvas.setPointerCapture(e.pointerId);if(activePointers.size===1){if(touchSculpt.checked){stroke=[];strokePointer=e.pointerId;lastStrokePoint=null;addStrokePoint(e.clientX,e.clientY);drag=null;}else drag={x:e.clientX,y:e.clientY,id:e.pointerId};}if(activePointers.size===2){const pts=[...activePointers.values()];pinchDistance=Math.hypot(pts[0].x-pts[1].x,pts[0].y-pts[1].y);strokePointer=null;stroke=[];drag=null;}});
      canvas.addEventListener('pointermove',(e)=>{if(!activePointers.has(e.pointerId))return;activePointers.set(e.pointerId,{x:e.clientX,y:e.clientY});if(activePointers.size>=2){const pts=[...activePointers.values()],d=Math.hypot(pts[0].x-pts[1].x,pts[0].y-pts[1].y);if(pinchDistance>0)zoom=Math.max(0.55,Math.min(2.8,zoom*d/pinchDistance));pinchDistance=d;drawViewport();return;}if(touchSculpt.checked&&strokePointer===e.pointerId){addStrokePoint(e.clientX,e.clientY);return;}if(!drag||drag.id!==e.pointerId)return;rotY+=(e.clientX-drag.x)*0.009;rotX=Math.max(-1.35,Math.min(1.35,rotX+(e.clientY-drag.y)*0.009));drag.x=e.clientX;drag.y=e.clientY;drawViewport()});
      const endPointer=(e)=>{activePointers.delete(e.pointerId);if(activePointers.size<2)pinchDistance=0;if(strokePointer===e.pointerId){strokePointer=null;lastStrokePoint=null;applyStroke();}drag=null;if(activePointers.size===1){const [id,pt]=[...activePointers.entries()][0];drag={x:pt.x,y:pt.y,id};}};canvas.addEventListener('pointerup',endPointer);canvas.addEventListener('pointercancel',endPointer);
      canvas.addEventListener('wheel',(e)=>{e.preventDefault();zoom=Math.max(0.55,Math.min(2.8,zoom*(e.deltaY>0?0.92:1.08)));drawViewport()},{passive:false});
      window.addEventListener('resize',drawViewport);
      const loadPreview = async () => { try { await loadViewport(); status.textContent='Viewport WebGL 2 prêt · textures BaseColor, Normal et ORM chargées si disponibles ; éclairage studio procédural réglable.'; } catch(err) { status.textContent='Viewport 3D : '+err.message; } };
      pick.addEventListener('change', guard(async()=>{rotX=-0.22;rotY=0.55;zoom=1;await loadPreview()})); await loadPreview();
      const field = (label, el) => h('div', {}, h('label', {}, label), el);
      const apply = h('button', { class: 'primary', onclick: guard(async (e) => { e.target.disabled = true; status.textContent = 'Sculpture en cours, recalcul des normales et validation des LOD…'; try { const a = current(); const r = await api('POST', `/api/modeling/assets/${a.id}/sculpt`, { operations: [{ mode: mode.value, center: [Number(cx.value), Number(cy.value), Number(cz.value)], radius: Number(radius.value), strength: Number(strength.value) }] }); Object.assign(a, r.asset); status.textContent = r.validation.ok ? `Sculpture enregistrée · ${r.operations.length} opération(s) · 3 LOD validés.` : 'La validation a refusé cette modification.'; await loadPreview(); toast('Sculpture appliquée et modèle validé'); } finally { e.target.disabled = false; } }) }, 'Appliquer la sculpture');
      const materialPanel = h('div',{class:'card',style:'margin-top:12px'},
        h('h3',{},'Bibliothèque de matériaux'),
        h('p',{class:'small muted'},'Presets prêts à appliquer : béton, métal peint, métal poli, bois verni, caoutchouc et pierre. Les presets personnalisés restent locaux au navigateur ; les modifications PBR ci-dessous sont enregistrées dans les exports du modèle.'),
        field('Preset',presetSelect),
        h('div',{class:'row',style:'flex-wrap:wrap;margin-top:8px'},applyPresetButton,deletePresetButton),
        h('div',{class:'row',style:'margin-top:8px'},presetName,savePresetButton),
        h('hr',{}),h('h3',{},'Édition PBR persistante'),
        h('p',{class:'small muted'},'Choisissez un matériau, modifiez sa couleur, son métallique et sa rugosité, puis enregistrez. Les facteurs sont écrits dans les exports glTF/MTL et conservés après une nouvelle sculpture.'),
        field('Matériau',materialSelect),field('Couleur BaseColor',materialColor),field('Métallique',materialMetal),field('Rugosité',materialRough),saveMaterialButton);
      const editorCard = h('div',{class:'card'},
        h('h2',{},'Éditeur de sculpture 3D — PBR'),
        h('p',{class:'small muted'},'Matériaux PBR : BaseColor, Normal et ORM avec éclairage studio temps réel réglable. Environnement procédural stylisé, sans fichier HDRI externe. Pinceaux géométriques : Inflate, Smooth et Flatten. Activez le mode tactile pour sélectionner la surface visible ou tracer un trait de sculpture ; les points sont calculés par intersection des triangles projetés et triés par profondeur. Le serveur applique et valide les opérations sur les trois LOD.'),
        field('Modèle',pick),h('div',{class:'row',style:'gap:8px;align-items:center;margin:10px 0'},touchSculpt,h('label',{},'Sculpter en glissant sur la surface'),selectedPoint),viewport,
        h('div',{class:'grid',style:'margin-top:12px'},field('Pinceau',mode),field('Rayon (m)',radius),field('Force (-0,25 à 0,25)',strength),field('Centre X',cx),field('Centre Y',cy),field('Centre Z',cz),field('Éclairage studio',studio),field('Ambiance',envStrength),field('Lumière principale',keyStrength),field('Ajustement rugosité',roughnessBias),field('Renfort métallique',metalBoost)),materialPanel);
      put(editorCard,h('div',{style:'margin-top:12px'},apply),status);
    } else {
      const ms = await api('GET', `/api/messages?project_id=${P()}&agent_id=modeling`);
      const list = h('div', { class: 'msgs', style: 'max-height:58dvh;min-height:200px;border:1px solid var(--line);border-radius:10px;padding:10px;background:#0a111b' }, ms.map((m) => h('div', { class: 'msg ' + m.role }, h('div', { class: 'who' }, m.role === 'user' ? 'Vous' : 'OPS MODELING AI'), m.role === 'user' ? h('div', {}, m.content) : md(m.content))), !ms.length && h('div', { class: 'muted' }, 'Parlez à MODELING AI : demandez un modèle (« une tour de verre de 30 étages ») ou le kit d’un monde ; il agit par actions réelles et rapporte le résultat vérifié.'));
      const input = h('textarea', { rows: '2', placeholder: 'Écrire à MODELING AI…', onkeydown: (e) => { if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) { e.preventDefault(); send.click(); } } });
      const send = h('button', { class: 'primary', onclick: guard(async () => { const text = input.value.trim(); if (!text) return; send.disabled = true; input.disabled = true; list.append(h('div', { class: 'msg user' }, h('div', { class: 'who' }, 'Vous'), text), h('div', { class: 'msg' }, h('span', { class: 'spin' }), ' MODELING AI réfléchit…')); list.scrollTop = list.scrollHeight; input.value = ''; try { await api('POST', '/api/studio/modeling/chat', { project_id: P(), text }); } finally { load(); } }) }, 'Envoyer');
      put(h('div', {}, list, h('div', { class: 'composer' }, input, send))); list.scrollTop = list.scrollHeight;
    }
  });
  paintTabs(); load(); return { refresh: () => { if (tab === 'assets' || tab === 'sculpt') load(); } };
};

SCREENS.director = (main) => {
  let tab = S.directorTab || 'chat', planId = null; S.directorTab = null;
  const tabs = h('div', { class: 'tabs' }), body = h('div');
  main.append(h('h1', {}, 'OPS DIRECTOR AI'), needsProvider(), tabs, body);
  const TABS = [['chat', 'Discuter'], ['plans', 'Plans & tâches'], ['messages', 'Messages inter-IA'], ['decisions', 'Décisions & mémoire'], ['engines', 'Moteurs'], ['exchange', 'Échange'], ['report', 'Bilan']];
  const paintTabs = () => tabs.replaceChildren(...TABS.map(([id, l]) => h('button', { class: tab === id ? 'on' : '', onclick: () => { tab = id; paintTabs(); load(); } }, l)));
  const pid = () => S.project.id;
  const aiName = (id) => id;
  const aiSelect = (val) => h('select', {}, ['director', 'world', 'modeling', 'animation', 'npc', 'physics', 'vehicle', 'gameplay', 'graphics', 'story', 'qa'].map((x) => h('option', { value: x, selected: x === val }, x)));
  const load = guard(async () => {
    const P = pid();
    if (tab === 'chat') {
      const ms = await api('GET', `/api/messages?project_id=${P}&agent_id=director`);
      const list = h('div', { class: 'msgs', style: 'max-height:58dvh;min-height:200px;border:1px solid var(--line);border-radius:10px;padding:10px;background:#0a111b' }, ms.map((m) => h('div', { class: 'msg ' + m.role }, h('div', { class: 'who' }, m.role === 'user' ? 'Vous' : 'OPS DIRECTOR AI'), m.role === 'user' ? h('div', {}, m.content) : md(m.content))), !ms.length && h('div', { class: 'muted' }, 'Parlez directement au Director : posez une question sur le projet, demandez un plan (« crée une ville »), une décision à noter, ou un message à une autre IA. Il agit seulement par actions non destructives et vous rapporte le résultat réel de chacune.'));
      const input = h('textarea', { rows: '2', placeholder: 'Écrire au Director…', onkeydown: (e) => { if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) { e.preventDefault(); send.click(); } } });
      const send = h('button', { class: 'primary', onclick: guard(async () => { const text = input.value.trim(); if (!text) return; send.disabled = true; input.disabled = true; list.append(h('div', { class: 'msg user' }, h('div', { class: 'who' }, 'Vous'), text), h('div', { class: 'msg' }, h('span', { class: 'spin' }), ' Le Director réfléchit…')); list.scrollTop = list.scrollHeight; input.value = ''; try { await api('POST', '/api/studio/director/chat', { project_id: P, text }); } finally { load(); } }) }, 'Envoyer');
      body.replaceChildren(h('div', {}, list, h('div', { class: 'composer' }, input, send)));
      list.scrollTop = list.scrollHeight;
    } else if (tab === 'plans') {
      const [plans, tpls] = await Promise.all([api('GET', `/api/director/plans?project_id=${P}`), api('GET', '/api/director/templates')]);
      if (!planId || !plans.some((p) => p.id === planId)) planId = plans[0]?.id || null;
      const tpl = h('select', {}, tpls.map((x) => h('option', { value: x.id }, `${x.label} (${x.tasks} tâches)`))), title = h('input', { placeholder: 'Titre (optionnel)' }), brief = h('textarea', { rows: '2', placeholder: 'Brief pour la planification par l’IA (ex. « Petite ville côtière jouable sur Android »)' });
      const create = (ai) => guard(async (e) => { e.target.disabled = true; try { const v = await api('POST', '/api/director/plans', { project_id: P, template: ai ? undefined : tpl.value, ai, title: title.value, brief: brief.value }); planId = v.plan.id; toast('Plan créé'); load(); } finally { e.target.disabled = false; } });
      let detail = null;
      if (planId) {
        const v = await api('GET', `/api/director/plans/${planId}`);
        const tn = (id) => v.tasks.find((t) => t.id === id)?.title || id;
        detail = h('div', {}, h('div', { class: 'row' }, h('h2', { style: 'margin:0;flex:1' }, v.plan.title), h('span', { class: 'muted small' }, v.plan.source), h('b', {}, v.progress + ' %')), h('div', { style: 'height:8px;background:#0c1420;border-radius:6px;margin:8px 0;overflow:hidden' }, h('div', { style: `height:100%;width:${v.progress}%;background:var(--green)` })),
          v.critical_path.path.length > 0 && h('p', { class: 'small muted' }, `Chemin critique (${v.critical_path.hours} h) : ${v.critical_path.path.map(tn).join(' → ')}`),
          v.issues.map((i) => h('div', { class: 'alert ' + (i.level === 'error' ? 'err' : '') }, i.msg)),
          h('table', {}, h('tr', {}, ['Tâche', 'IA', 'État', 'Dépend de', ''].map((x) => h('th', {}, x))), v.tasks.map((t) => h('tr', {}, h('td', {}, h('b', {}, t.title), h('div', { class: 'muted small' }, `${t.estimate_h} h · priorité ${t.priority}`), t.result && h('details', {}, h('summary', {}, 'Résultat'), md(t.result))), h('td', {}, t.assignee), h('td', {}, spill(t.state), t.reason && h('div', { class: 'muted small' }, t.reason)), h('td', { class: 'small muted' }, t.depends_on.map(tn).join(', ') || '—'),
            h('td', {}, h('div', { class: 'row' },
              t.state === 'ready' && h('button', { class: 'small primary', title: 'L’IA assignée exécute la tâche avec le modèle configuré', onclick: guard(async (e) => { e.target.disabled = true; e.target.textContent = '…'; try { await api('POST', `/api/director/tasks/${t.id}/run`); toast('Tâche exécutée'); } finally { load(); } }) }, 'Exécuter'),
              ['ready'].includes(t.state) && t.assignee !== 'director' && h('button', { class: 'small', onclick: guard(async () => { await api('PUT', `/api/director/tasks/${t.id}`, { status: 'in_progress' }); load(); }) }, 'Démarrer'),
              ['in_progress', 'review'].includes(t.state) && h('button', { class: 'small ok', onclick: guard(async () => { const r = prompt('Résultat / livrable de la tâche :'); if (!r) return; await api('PUT', `/api/director/tasks/${t.id}`, { status: 'done', result: r }); load(); }) }, 'Terminer'),
              !['done', 'cancelled'].includes(t.state) && h('button', { class: 'small', onclick: guard(async () => { const el = aiSelect(t.assignee); const bg = modal('Réattribuer', h('p', { class: 'muted small' }, t.title), el, h('div', { style: 'margin-top:10px' }, h('button', { class: 'primary', onclick: guard(async () => { await api('PUT', `/api/director/tasks/${t.id}`, { assignee: el.value }); bg.remove(); load(); }) }, 'Réattribuer'))); }) }, 'IA'),
              !['done', 'cancelled'].includes(t.state) && h('button', { class: 'small danger', onclick: guard(async () => { if (confirm('Annuler cette tâche ? Les tâches qui en dépendent seront bloquées.')) { await api('PUT', `/api/director/tasks/${t.id}`, { status: 'cancelled' }); load(); } }) }, 'Annuler'),
              t.state === 'cancelled' && h('button', { class: 'small', onclick: guard(async () => { await api('PUT', `/api/director/tasks/${t.id}`, { status: 'todo' }); load(); }) }, 'Rouvrir')))))),
          h('div', { class: 'row', style: 'margin-top:10px' }, h('button', { class: 'small', onclick: guard(async () => { const t = prompt('Titre de la nouvelle tâche'); if (!t) return; await api('POST', `/api/director/plans/${planId}/tasks`, { title: t }); load(); }) }, '+ Tâche')));
      }
      body.replaceChildren(h('div', { class: 'card', style: 'margin-bottom:12px' }, h('h2', {}, 'Nouveau plan de production'), h('div', { class: 'row' }, tpl, title, h('button', { class: 'primary', onclick: create(false) }, 'Depuis ce modèle')), h('div', { style: 'margin-top:8px' }, brief, h('div', { style: 'margin-top:6px' }, h('button', { onclick: create(true) }, 'Faire planifier par le Director (IA)')))),
        plans.length > 1 && h('div', { class: 'tabs' }, plans.map((p) => h('button', { class: p.id === planId ? 'on' : '', onclick: () => { planId = p.id; load(); } }, `${p.title} · ${p.progress}%`))), h('div', { class: 'card' }, detail || h('p', { class: 'muted' }, 'Aucun plan. Créez-en un à partir d’un modèle (ville, véhicule, personnage, mission, jeu) ou demandez au Director.')));
    } else if (tab === 'messages') {
      const ms = await api('GET', `/api/director/messages?project_id=${P}`);
      const from = aiSelect('director'), to = aiSelect('qa'), kind = h('select', {}, ['note', 'request', 'correction', 'result', 'report', 'handoff'].map((k) => h('option', { value: k }, k))), text = h('textarea', { rows: '2', placeholder: 'Message…' });
      body.replaceChildren(h('div', { class: 'card', style: 'margin-bottom:12px' }, h('div', { class: 'row' }, 'De', from, 'à', to, kind), text, h('button', { class: 'primary', style: 'margin-top:6px', onclick: guard(async () => { await api('POST', '/api/director/messages', { project_id: P, from: from.value, to: to.value, kind: kind.value, body: text.value }); text.value = ''; load(); }) }, 'Envoyer')),
        h('p', { class: 'muted small' }, '« queued » = destinataire non construit : le message est conservé et sera livré quand cette IA existera.'),
        ...ms.map((m) => h('div', { class: 'card', style: 'margin-bottom:8px' }, h('div', { class: 'row' }, h('b', {}, `${m.from_ai} → ${m.to_ai}`), pill(m.kind), h('span', { class: 'pill ' + (m.status === 'queued' ? 'warn' : m.status === 'read' ? 'done' : 'pending') }, m.status), h('span', { class: 'muted small' }, fmt(m.created)), h('span', { style: 'flex:1' }), m.status === 'pending' && h('button', { class: 'small', onclick: guard(async () => { await api('POST', `/api/director/messages/${m.id}/read`); load(); }) }, 'Marquer lu')), h('div', { class: 'small', style: 'white-space:pre-wrap;margin-top:4px' }, m.body.slice(0, 600)))), !ms.length && h('p', { class: 'muted' }, 'Aucun message.'));
    } else if (tab === 'decisions') {
      const ds = await api('GET', `/api/director/decisions?project_id=${P}`), ti = h('input', { placeholder: 'Décision (titre)' }), bo = h('textarea', { rows: '2', placeholder: 'Détail et justification' });
      body.replaceChildren(h('p', { class: 'muted' }, 'Les décisions rejoignent la mémoire partagée du projet : toutes les IA les reçoivent dans leur contexte.'), h('div', { class: 'card', style: 'margin-bottom:12px' }, ti, bo, h('button', { class: 'primary', style: 'margin-top:6px', onclick: guard(async () => { await api('POST', '/api/director/decisions', { project_id: P, title: ti.value, body: bo.value }); load(); }) }, 'Enregistrer la décision')),
        ds.map((d) => h('div', { class: 'card', style: 'margin-bottom:8px' }, h('b', {}, d.key.replace('décision : ', '')), h('span', { class: 'muted small' }, ' ' + fmt(d.created)), h('p', { class: 'small' }, d.value))),
        h('details', {}, h('summary', {}, 'Paquet de contexte partagé (ce que reçoit chaque IA)'), h('pre', {}, JSON.stringify(await api('GET', `/api/director/context?project_id=${P}`), null, 2))));
    } else if (tab === 'engines') {
      const es = await api('GET', `/api/engines?project_id=${P}`), name = h('input', { placeholder: 'Nom du moteur (ex. EUPHORIA 3D ENGINE)' }), kind = h('select', {}, h('option', { value: 'files' }, 'Dossier d’échange (fichiers)'), h('option', { value: 'http' }, 'API HTTP')), target = h('input', { placeholder: 'Dossier (ex. exchange/euphoria) ou URL de santé http(s)://…' }), fm = h('input', { placeholder: 'Formats (fbx, glb, json…)' });
      body.replaceChildren(h('p', { class: 'muted' }, 'Un moteur est « verified » uniquement après un test réel (réponse HTTP 2xx ou aller-retour écriture/lecture dans le dossier). Les adaptateurs de conversion entre moteurs incompatibles ne sont pas encore construits.'),
        h('div', { class: 'card', style: 'margin-bottom:12px' }, h('div', { class: 'row' }, name, kind), target, fm, h('button', { class: 'primary', style: 'margin-top:6px', onclick: guard(async () => { await api('POST', '/api/engines', { project_id: P, name: name.value, kind: kind.value, endpoint: target.value, exchange_dir: target.value, formats: fm.value }); load(); }) }, 'Déclarer')),
        es.map((e) => h('div', { class: 'card', style: 'margin-bottom:8px' }, h('div', { class: 'row' }, h('b', { style: 'flex:1' }, e.name), pill(e.kind), h('span', { class: 'pill ' + (e.status === 'verified' ? 'ok' : e.status === 'failed' ? 'failed' : '') }, e.status)), h('p', { class: 'small muted' }, `${e.endpoint || e.exchange_dir} · formats : ${e.formats.join(', ') || '—'}${e.last_check ? ' · ' + fmt(e.last_check) : ''}`), e.detail && h('p', { class: 'small' }, e.detail),
          h('div', { class: 'row' }, h('button', { class: 'small primary', onclick: guard(async () => { await api('POST', `/api/engines/${e.id}/check`); load(); }) }, 'Tester la connexion'), h('button', { class: 'small danger', onclick: guard(async () => { if (confirm('Retirer ce moteur du registre ?')) { await api('DELETE', `/api/engines/${e.id}?confirm=1`); load(); } }) }, 'Retirer')))), !es.length && h('p', { class: 'muted' }, 'Aucun moteur déclaré.'));
    } else if (tab === 'exchange') {
      const paths = h('input', { placeholder: 'Chemins à exporter (séparés par des virgules ; vide = tout)' }), out = h('div');
      body.replaceChildren(h('p', { class: 'muted' }, 'Format commun « ops-exchange » (ZIP + manifest.json avec empreintes SHA-1). L’import vérifie tout avant d’écrire, propose un essai à blanc et sauvegarde ce qu’il remplace.'),
        h('div', { class: 'card', style: 'margin-bottom:12px' }, h('h2', {}, 'Exporter'), paths, h('button', { class: 'primary', style: 'margin-top:6px', onclick: guard(async () => { const r = await fetch(`/api/projects/${P}/exchange.zip?paths=${encodeURIComponent(paths.value)}`, { headers: { authorization: 'Bearer ' + S.token } }); if (!r.ok) throw new Error((await r.json()).error); const a = h('a', { href: URL.createObjectURL(await r.blob()), download: `${P}.ops-exchange.zip` }); document.body.append(a); a.click(); a.remove(); }) }, 'Télécharger le paquet')),
        h('div', { class: 'card' }, h('h2', {}, 'Importer'), h('input', { type: 'file', accept: '.zip', onchange: guard(async (e) => {
          const f = e.target.files[0]; if (!f) return; const buf = new Uint8Array(await f.arrayBuffer()); let bin = ''; for (let i = 0; i < buf.length; i += 0x8000) bin += String.fromCharCode(...buf.subarray(i, i + 0x8000)); const content = btoa(bin);
          const d = await api('POST', `/api/projects/${P}/exchange/import`, { content, dry_run: true });
          out.replaceChildren(h('p', {}, `Paquet de « ${d.manifest.project || '?'} » : ${d.files.length} fichier(s), ${d.conflicts} conflit(s).`), h('table', {}, d.files.map((x) => h('tr', {}, h('td', {}, x.path), h('td', { class: 'small muted' }, x.format), h('td', {}, h('span', { class: 'pill ' + (x.status === 'conflict' ? 'warn' : x.status === 'new' ? 'ok' : '') }, x.status))))),
            h('button', { class: 'primary', style: 'margin-top:8px', onclick: guard(async () => { if (d.conflicts && !confirm(`${d.conflicts} fichier(s) existants seront remplacés (sauvegarde automatique, annulable). Continuer ?`)) return; const r = await api('POST', `/api/projects/${P}/exchange/import`, { content, overwrite: d.conflicts > 0 }); toast(`${r.written} fichier(s) importé(s)`); out.replaceChildren(); }) }, 'Importer'));
        }) }), out));
    } else {
      body.replaceChildren(h('div', { class: 'row', style: 'margin-bottom:10px' }, h('button', { class: 'primary', onclick: () => { tab = 'report'; load(); } }, 'Actualiser'), h('button', { onclick: guard(async (e) => { e.target.disabled = true; try { const r = await api('GET', `/api/director/report?project_id=${P}&ai=1`); body.querySelector('.rep').replaceChildren(md(r.markdown)); } finally { e.target.disabled = false; } }) }, 'Ajouter l’analyse du Director (IA)')), h('div', { class: 'card rep' }, md((await api('GET', `/api/director/report?project_id=${P}`)).markdown)));
    }
  });
  paintTabs(); load(); return { refresh: (m) => { if (['director', 'studio.message'].includes(m?.type)) load(); } };
};

// ---------- démarrage ----------
S.token = store.get();
if (S.token) api('GET', '/api/state').then(boot).catch(() => renderLogin()); else renderLogin();
window.addEventListener('hashchange', () => { const r = location.hash.slice(1); if (S.token && r && r !== S.route && SCREENS[r]) go(r); });
