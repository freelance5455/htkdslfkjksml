# OPS MASTER AI NEURAL — V6.1

Centre de commande de l'organisation OPS : un chat unique qui pilote plusieurs projets via **14 agents développeurs** pouvant utiliser des fournisseurs IA différents et collaborer (planification, exécution parallèle, relecture croisée, corrections, rapport final).

## V4.1 — Integrity Doctor & base de maintenance

- Version unifiée à `5.0.0` dans le package et la configuration serveur.
- `npm run doctor` : audit local en lecture seule (JSON, version, compatibilité Node, syntaxe JavaScript et références locales de l'interface).
- Le diagnostic n'exécute pas les modules du projet, ne modifie aucun fichier, n'installe rien et ne contacte aucun service externe.
- `npm test` inclut désormais les tests du diagnostic.


## V4.3 — MULTI-AGENT INTELLIGENCE

- Tous les agents, et pas seulement OPS WEB RESEARCH, reçoivent explicitement le droit de demander une recherche Internet via les outils `web_search` et `web_fetch`.
- Les agents doivent privilégier les documentations officielles, comparer les sources utiles, mentionner les URLs/dates et signaler tout échec de connexion.
- Le curriculum de chaque agent renforce l'apprentissage par les corrections confirmées, les tests de non-régression et les expériences validées.
- Cette amélioration entraîne les méthodes, prompts et mémoire de travail OPS ; elle ne réentraîne pas les poids des modèles externes.
- Connexion réelle requise : ajoute au moins un fournisseur IA avec une clé API dans **Fournisseurs IA**, puis configure **Paramètres → Recherche Web** avec une clé Tavily ou Brave. Le statut « configurée » ne signifie pas que la connexion a été testée ; utilise le bouton **Tester** dans les paramètres. Les clés restent côté serveur et ne doivent jamais être publiées.
- Tous les agents utilisent le fournisseur par défaut si aucun fournisseur individuel ne leur est attribué. Les fournisseurs/modèles individuels restent possibles.



## V5.0 — Release Gate & livraison contrôlée

- Nouvel endpoint authentifié `GET /api/projects/:id/release-gate` : synthèse du workspace, points d’entrée, validité du `package.json`, présence d’une commande de test, anomalies du superviseur, tâches mesurées et état opérationnel.
- Trois états explicites : `blocked` (critère bloquant), `review` (preuves ou vérifications manquantes), `candidate` (candidature interne sans blocage détecté).
- Le rapport indique les preuves observées et les limites : il n’exécute pas automatiquement le code du projet et ne certifie pas une publication.
- Les contrôles restent additifs : aucun agent, fichier, moteur ou fonctionnalité existante n’est supprimé.
- Nouveaux tests dédiés au Release Gate ; `npm test` vérifie désormais 169 scénarios.

Utilisation : `GET /api/projects/<project-id>/release-gate` avec le jeton d’accès OPS.

## V6.1 — Interface du manifeste de livraison

La V6.1 ajoute un écran mobile-adaptatif « Manifeste de livraison » : état ready/review/blocked, empreinte racine SHA-256 copiable, inventaire filtrable, points d’entrée, lockfiles, alertes et création de snapshots versionnés. Le snapshot reste désactivé si le manifeste est bloqué. Les routes V6.0 sont réutilisées ; aucune fonction existante n’est retirée.

## V6.0 — Manifeste de livraison vérifiable

- Inventaire des fichiers réels du workspace avec tailles et empreintes SHA-256 individuelles.
- Empreinte racine déterministe pour comparer deux états du même projet.
- Détection de fichiers sensibles et de motifs de clés privées / secrets API ; blocage du snapshot en cas d’alerte.
- Repérage des points d’entrée, README et fichiers lock.
- `GET /api/projects/:id/release-manifest` calcule le rapport sans modifier le workspace.
- `POST /api/projects/:id/release-manifest/snapshot` crée une version de sauvegarde si aucun blocage n’est détecté.
- Aucun script du projet n’est exécuté ; les empreintes attestent les octets observés, pas la qualité fonctionnelle.
- Suite de tests : 169 tests, tous réussis ; Integrity Doctor : 6 contrôles réussis.

Détails : `docs/OPS_MASTER_AI_NEURAL_V6_0.md`.

## Démarrage rapide
1. Installer **Node.js 22.13 ou plus** (SQLite est intégré, aucune dépendance npm).
2. Lancer : `scripts/start.sh` (Linux/macOS/Termux) ou `scripts\start.bat` (Windows) — ou `npm start`.
3. Ouvrir http://127.0.0.1:8800 et saisir le **jeton d'accès** affiché dans la console (aussi dans `data/.token`).
4. **Fournisseurs IA** → ajouter un fournisseur (clé API réelle), *Tester la connexion*, choisir le modèle.
5. **Chat** → donner une instruction (mode Équipe) ou parler à un agent (mode Direct).

Notes V4.0 : `docs/OPS_MASTER_AI_NEURAL_V4_0.md`. Détails : `docs/INSTALLATION.md`, `docs/ARCHITECTURE.md`, `docs/SECURITE.md`, `docs/ANDROID.md`, `docs/RAPPORT_TESTS.md`.

## Ce qui est réellement implémenté (V1 → V6 côté serveur + PWA)
| Version | Contenu |
|---|---|
| V1 | Chat central, passerelle fournisseurs (OpenAI-compatible, Anthropic, Gemini), clés chiffrées côté serveur, test de connexion, modèles, budgets/jour |
| V2 | 11 agents initiaux, orchestrateur : plan → sous-tâches → parallélisme par dépendances → relecture croisée (qualité + détection automatique des contradictions) → corrections → fusion → rapport |
| V3 | Gestionnaire de projets isolés (4 projets OPS créés), mémoire partagée, historique, versions, dépendances, agents affectés |
| V3+ | **Bibliothèque de fichiers** : stockage central (global ou par projet), tags, recherche, aperçu, téléchargement, import dans un projet (copie sauvegardée/annulable), lecture par les agents |
| V4 | Fichiers sandboxés, autorisations, sauvegarde avant écriture, annulation, restauration, non-régression, journal |
| V5 | Centre de tests (syntaxe JS/JSON/HTML + régression), `npm test/build` sur autorisation explicite, automatisation (blocages, relance, rapports, suggestions) |
| V3.7 | **Navigateur & inspection structurelle** : rapport automatique sur fichiers, points d’entrée, ressources et extensions ; **mémoire d’expérience pertinente** classée selon la tâche, avec journal des réutilisations et statistiques |
| V3.8 | **OPS AI COMMUNICATION BUS** persistant, événements ciblés ou diffusés, contrats de dépendances entre moteurs avec détection de cycles ; les événements et contrats déclarés par les agents sont transmis au contexte des tâches suivantes |
| V3.14 | **Équipe de production de jeu renforcée** : spécialistes dédiés (architecture, 3D, gameplay, PNJ, physique, art, animation, interface, audio et backend conditionnel), cycle obligatoire CODER → DEBUG → CODER, transfert des sources proposées entre tâches, correction après audit et contrôle qualité indépendant |
| V3.15 | **OPS CODER AI — implémentation réelle** : exécution des outils même lorsque la réponse contient aussi des fichiers, conservation des artefacts entre les tours, relance si aucun fichier de code n’est livré et échec explicite sans livrable |
| V3.16 | **OPS CODER AI — patchs multi-fichiers sécurisés** : patchs de remplacement exact, vérification du contexte unique, refus des patchs ambigus ou périmés, conservation du contenu non ciblé, sauvegarde et validation via le circuit approval/auto |
| V3.17 | **OPS MULTI-FILE ENGINE** : graphe statique des dépendances entre fichiers, détection des imports locaux non résolus, liens entre modules livrés et fichiers existants, vérification des scripts HTML et transmission du rapport d’intégration à DEBUG |
| V6.1 | Écran graphique du manifeste, inventaire filtrable et snapshots depuis l’interface ; conserve V6.0 |
| V6.0 | Manifeste de livraison SHA-256, détection de secrets potentiels, snapshot versionné protégé par contrôle ; PWA + API (APK natif non inclus) |

## ÉQUIPE DE CONSTRUCTION — 14 agents principaux

Le pipeline principal comprend 14 agents : COORDINATOR, ARCHITECT, CODER, FRONTEND, BACKEND, ENGINE3D, DEBUG, GAMEPLAY, NPC, PHYSICS, ART3D, ANIMATION, AUDIO et QUALITY. OPS CODER AI reçoit un curriculum de programmation contextualisé à chaque requête, des exemples de bonnes/mauvaises pratiques et une auto-évaluation fondée sur des preuves. NPC et PHYSICS sont des agents de premier niveau du planificateur, avec leurs propres prompts d’intégration et leurs tâches exécutables. Pour les nouveaux jeux, OPS CODER AI construit et assemble les fichiers, OPS DEBUG AI audite les sources proposées, puis CODER reprend les constats et livre les corrections avant le contrôle qualité indépendant. Les projets existants reçoivent l’équipe de jeu complète par migration additive. Chaque IA possède un prompt métier dédié, peut recevoir une tâche du graphe de production et dispose d'un chat direct (WORLD et MODELING conservent leurs interfaces de création spécialisées).

Le Director planifie les productions (ville, véhicule, personnage, mission, jeu ou plan IA), gère les dépendances et le chemin critique. Les résultats sont transmis automatiquement aux IA suivantes. Le contexte partagé inclut les décisions, les résultats précédents, les ressources et les moteurs du projet. Les fournisseurs et modèles peuvent être réglés par IA ; à défaut, le fournisseur du Director sert de repli.

Les pipelines de génération procédurale de WORLD et MODELING restent intacts. Le module Director conserve en parallèle ses 13 spécialistes métier : DIRECTOR, WORLD, MODELING, SATELLITE, WEB RESEARCH, ANIMATION, NPC, PHYSICS, VEHICLE, GAMEPLAY, GRAPHICS, STORY et QA. Les autres spécialistes produisent leurs livrables via leur modèle dédié et leurs prompts AAA, sans remplacer les fonctions existantes. QA vérifie les livrables et doit distinguer les tests exécutés des tests recommandés. Détails : `docs/DIRECTOR.md`, `docs/STUDIO_AAA.md` et `docs/OPS_GAME_AI_TEAM_V3_14.md`.

## OPS CODER AI — curriculum V3.2

Le module `server/coder-training.mjs` fournit un curriculum versionné : inspection avant modification, préservation, intégration au vrai point d’entrée, contrats inter-moteurs, débogage par cause racine, tests, performances mobiles, sécurité et livraison honnête. Des exemples contrastifs et une grille de preuves sont injectés dans le prompt de CODER à chaque exécution. Cette méthode améliore le comportement par contexte et évaluation ; elle ne modifie pas les poids du modèle fournisseur et ne constitue pas un entraînement neuronal supervisé.

## Honnêteté technique
- Aucun agent ne répond sans fournisseur réellement configuré : l'erreur est affichée, rien n'est simulé.
- Les agents ne « se connectent » pas entre eux directement : ils partagent un protocole texte commun et l'orchestrateur transmet contexte et résultats — ce qui fonctionne avec n'importe quel modèle.
- PostgreSQL : adaptateur écrit mais **non testé** (nécessite `npm install pg` et un serveur).
- Recherche Web : nécessite une clé Tavily ou Brave.
- Le projet CITY & VEHICLE STUDIO 3D V3.8 fourni est importé tel quel (copie) dans son projet, avec une version de sauvegarde.

## OPS NEURAL SYSTEM (v1)

La couche neuronale hybride est intégrée au serveur :
- `OPS NEURAL CORE` injecte un contexte commun aux agents ;
- `OPS NEURAL REASONING` impose l'analyse de la demande et la séparation faits/hypothèses ;
- `OPS NEURAL MATH` calcule localement les opérations arithmétiques détectées (priorités, parenthèses, fractions sous forme de divisions, puissances, modulo et fonctions sqrt/abs/round/floor/ceil), sans appel web ;
- `OPS NEURAL MEMORY` réinjecte les notes et les derniers échanges du projet ;
- `OPS NEURAL VERIFICATION` ajoute des consignes de contrôle et conserve la relecture qualité existante ;
- `OPS NEURAL PLANNER` renforce la planification existante ;
- `OPS NEURAL COLLABORATION` transmet mémoire et contexte aux agents exécutants.

État consultable via `GET /api/neural/status` (authentification OPS requise).

Limite importante : cette version est une architecture hybride de fiabilisation, pas un modèle neuronal qui entraîne automatiquement ses propres poids. Les capacités de rédaction et de génération restent liées au fournisseur/modèle configuré. Les tests du moteur neuronal sont inclus dans `npm test`.

## OPS NEURAL SUPERVISOR (V2.4 → V2.5)

Après l'exécution de toutes les tâches de l'équipe, OPS QUALITY TEAM agit comme superviseur neuronal final : il audite la demande, les résultats et le contenu des fichiers proposés, relève les défauts démontrables et demande aux agents responsables de les corriger. Le cycle est relancé après correction, avec une limite configurable (4 cycles par défaut, 5 maximum depuis V2.5). Le rapport distingue les problèmes relevés et les points qui n'ont pas pu être vérifiés. Cet audit par modèle ne remplace pas l'exécution réelle des tests : seuls les tests lancés et réussis sont annoncés comme tels.

## OPS MASTER AI NEURAL — studio AAA

Le roster du studio comprend 13 IA construites : DIRECTOR, WORLD, MODELING, SATELLITE, WEB RESEARCH, ANIMATION, NPC, PHYSICS, VEHICLE, GAMEPLAY, GRAPHICS, STORY et QA. Chaque spécialiste possède un prompt métier dédié. Les tâches du Director sont exécutables par les agents construits via le fournisseur configuré (modèle du spécialiste, ou fournisseur/modèle du Director en repli). WORLD et MODELING conservent leurs pipelines spécialisés de génération.

Les spécialistes partagent le contexte du projet, les décisions, les résultats des tâches dépendantes, les ressources et les moteurs déclarés. Les résultats sont transmis automatiquement aux agents suivants. Chaque IA spécialisée (hors Director, WORLD et MODELING qui gardent leurs interfaces dédiées) dispose aussi d'un chat direct via `POST /api/studio/:id/chat`. La disponibilité logicielle ne signifie pas qu'un fournisseur IA est déjà connecté : il faut configurer un fournisseur/modèle pour obtenir des réponses réelles. QA distingue systématiquement les tests exécutés des tests simplement recommandés.

## OPS NEURAL V2.4 — intelligence de coordination (socle conservé)

La couche OPS NEURAL ajoute une analyse déterministe préalable des demandes, la détection de domaines spécialisés, un repérage de risques (préservation, sécurité, performance mobile/3D et réseau), et transmet ce profil à chaque agent. Le planificateur IA reçoit les spécialistes recommandés sans être forcé de créer des tâches inutiles. Le rapport final comporte un OPS NEURAL QUALITY GATE qui distingue les contrôles renseignés des éléments à compléter.

Cette couche ne constitue pas un entraînement autonome des modèles : elle orchestre les fournisseurs configurés, les règles déterministes, la mémoire et les vérifications exécutables.


## OPS NEURAL V2.5 — détail de production et assistance centrale

Chaque IA reçoit maintenant un contrat de qualité AAA plus exigeant : détails techniques et fonctionnels, états et cas limites, dépendances, critères d’acceptation, tests, limites et auto-relecture. Les exigences sont spécialisées par métier (WORLD, MODELING, ANIMATION, NPC, PHYSICS, VEHICLE, GAMEPLAY, GRAPHICS, STORY, QA et DIRECTOR).

Si une réponse de spécialiste dépasse le premier délai de 45 secondes, le coordinateur central prépare une aide technique structurée ; le spécialiste reprend ensuite son travail avec cette aide et reste responsable du livrable. La revue finale examine aussi le niveau de détail, la finition et les critères d’acceptation. Les cycles de correction sont configurables jusqu’à 5 (4 par défaut) et s’arrêtent lorsque les problèmes exploitables sont résolus ou que la limite est atteinte.

Cette amélioration vise une qualité de production commerciale, mais ne certifie pas un jeu AAA : la qualité finale dépend des modèles configurés, des ressources réelles, du moteur et des tests exécutés.


## OPS SATELLITE AI

OPS SATELLITE AI accepte des images PNG/JPG/WEBP de référence (5 Mo max), analyse le relief, l’hydrographie, la végétation et les formes urbaines pour le world-building, puis diffuse son dossier aux 11 autres IA via la mémoire partagée et la messagerie du studio. Elle ne prétend pas accéder à un flux satellite en direct : l’utilisateur fournit l’image, par exemple depuis NASA Worldview. Les fournisseurs configurés doivent accepter les entrées multimodales pour interpréter les pixels.

### OPS SATELLITE AI — V2.6

Le studio comporte désormais 12 IA. OPS SATELLITE AI analyse les images PNG/JPG/WEBP fournies par l'utilisateur (5 Mo max), prépare un dossier de terrain et le transmet automatiquement aux 12 autres IA par messages et mémoire partagée. Le chat Satellite propose NASA Worldview comme source d'images. La lecture des pixels nécessite un modèle multimodal configuré.


### OPS WEB RESEARCH AI (V3.0)
OPS WEB RESEARCH AI conserve son rôle de spécialiste et peut préparer des dossiers documentés pour le studio. Depuis V4.3, tous les agents disposent également des outils web_search et web_fetch pour effectuer leurs propres recherches lorsque la tâche le nécessite. Tavily ou Brave doit être configuré dans Paramètres → Recherche Web ; sans clé valide, aucun agent ne prétend avoir effectué une recherche.


## V3.0 — Renforcement global des IA
Voir `docs/NEURAL_V3_0.md` : contrats de production renforcés pour les 13 spécialistes, collaboration inter-moteurs, contrats d’interface, suivi des preuves, garde-fou de régression et QA renforcée. Toutes les fonctions V2.7 sont conservées.

Note : les 11 agents développeurs et les 13 IA spécialistes AAA sont deux équipes distinctes de l’écosystème OPS. V3.0 renforce les deux sans en supprimer.


## OPS GAME ENGINE INTEGRATION — V3.1

NPC et PHYSICS sont intégrés au planificateur de construction de jeux. Pour les demandes de création de jeu, le plan de secours sélectionne automatiquement les spécialistes moteur 3D, gameplay, NPC, physique, art 3D et animation lorsqu'ils sont disponibles. Le coordinateur IA reçoit la même règle dans son contrat de planification.

Les projets existants reçoivent les agents `npc` et `physics` de façon additive au démarrage, sans retirer leurs agents déjà affectés. Les nouveaux projets les incluent dans la liste complète par défaut.

Le kit `game-engines/` fournit un moteur NPC portable (états, mémoire bornée, adaptateurs perception/navigation), un ordonnanceur physique à pas fixe qui délègue au backend réel du jeu et un pont runtime commun. Les agents doivent adapter ces modules au moteur détecté et les raccorder au point d'entrée/Game Loop du jeu. Un module non importé/appelé n'est pas considéré comme intégré. Le backend physique réel dépend toujours du moteur du projet.

Tests V3.1 : 77 tests réussis, dont les tests d'intégration runtime, d'affectation des agents, de migration additive et de sélection des spécialistes pour un nouveau jeu.


## V3.2 — OPS CODER AI

Ajout de l’agent `coder` au planificateur, migration additive des projets existants, sélection automatique pour les projets de jeu et documentation de son cycle d’implémentation. Voir `docs/GAME_CODING_TEAM_V3_2.md`.


## OPS CODER AI V3.3 — curriculum avancé

Le niveau avancé ajoute 12 compétences, des cas contrastifs multi-modules et un évaluateur séparé de 12 preuves. Voir `docs/OPS_CODER_TRAINING_V3_3.md`.


## OPS CODER AI — création autonome de nouveaux jeux (V3.4)

Lorsqu'une demande explicite de création d'un nouveau jeu est détectée, OPS lance un pipeline dédié : architecture, moteur/rendu, gameplay, PNJ, physique, monde/ressources et animations travaillent en parallèle selon les agents affectés au projet. OPS CODER AI attend leurs résultats, puis construit et assemble le jeu dans le workspace : fichiers complets, point d'entrée réel, boucle de jeu, contrôles adaptés, mécaniques jouables, interface, états de partie, tests et README de lancement. Le pipeline s'adapte aux spécialistes disponibles et refuse de prétendre qu'un jeu est terminé si les fichiers ou tests nécessaires manquent. Les propositions de fichiers respectent toujours le mode d'écriture du projet (validation ou automatique).

Ce mécanisme orchestre les modèles IA configurés ; il ne constitue pas un modèle de programmation entraîné localement et ne garantit pas l'exécution ou la validation visuelle sur chaque appareil.


## OPS CODER AI — entraînement intensif V3.5

Le curriculum de CODER comprend maintenant un parcours intensif de création de jeux : game design vers critères d’acceptation, boucle de jeu, architecture de scène, commandes multi-appareils, caméra, physique, IA PNJ, navigation, monde ouvert/streaming, rendu, ressources, animation, audio, sauvegardes, missions, HUD, optimisation mobile/PC, réseau, tests de gameplay, accessibilité et livraison. Huit études de cas et une grille de 16 preuves complètent le parcours.

Ce mécanisme injecte des leçons et exemples dans le contexte du modèle et évalue les preuves déclarées par l’orchestrateur ; il ne modifie pas les poids du modèle fournisseur et ne remplace pas les tests réels.


## V3.7 — Développement complet du navigateur et de la mémoire d’expérience

- **Navigateur de projet** : arborescence interactive, lecture de fichiers et aperçu HTML dans une iframe sandboxée. Les ressources du projet sont servies depuis le workspace avec authentification, chemins confinés et politique CSP restrictive.
- **Inspection par les agents** : outil `inspect_project` donnant l’arborescence et des extraits des points d’entrée/configurations ; les agents sont invités à inspecter avant modification et à vérifier imports/chemins après proposition.
- **Mémoire d’expérience persistante** : table `experience_memory`, propositions par balise `<ops-experience>`, états `pending/approved/rejected`, validation humaine et injection des leçons approuvées dans les prompts de tous les agents du projet.
- Les expériences proposées ne sont jamais utilisées avant validation ; la mémoire n’entraîne pas les poids du modèle fournisseur.


### V3.7 — Structure et apprentissage par expérience

- **Inspection structurelle API** : `GET /api/projects/:id/inspection` retourne un inventaire du workspace, les tailles, extensions, points d’entrée probables et ressources reconnues. Cette analyse est factuelle et ne prétend pas remplacer une exécution du jeu.
- **Navigateur** : ajout d’un panneau « Analyser la structure » qui présente ces résultats sans lancer de modification. L’inspection IA d’équipe reste disponible séparément.
- **Mémoire pertinente** : avant chaque sous-tâche, l’orchestrateur classe les expériences approuvées du projet et les expériences globales selon les mots-clés de la tâche ; seules les 12 leçons les plus pertinentes sont injectées.
- **Traçabilité** : nouvelle table `experience_events` enregistre chaque récupération d’une leçon. `GET /api/projects/:id/experience-stats` expose le nombre de leçons, récupérations et expériences les plus réutilisées.
- **Sécurité/préservation** : validation humaine conservée ; aucun apprentissage depuis une proposition en attente ou refusée ; aucune modification automatique des poids du modèle fournisseur.
- **Limite visuelle** : les agents inspectent les fichiers et les rapports de structure. La capture réelle de l’écran du navigateur et son envoi à un modèle multimodal ne sont pas inclus dans cette version.


## V3.8 — collaboration inter-moteurs persistante

Le module `server/collaboration.mjs` ajoute un bus d'événements persistant par projet et un gestionnaire de dépendances entre moteurs. Les agents peuvent publier des événements avec `<ops-bus type="asset.ready" to="graphics">{...}</ops-bus>` et déclarer des contrats avec `<ops-dependency prerequisite="world" dependent="npc" contract="..."/>`. Les événements diffusés ou ciblés sont conservés en SQLite, accessibles par API et injectés dans le contexte des agents concernés. Les dépendances cycliques sont refusées. API : `/api/projects/:id/collaboration/events` et `/api/projects/:id/collaboration/dependencies`. Cette livraison ne prétend pas encore fournir une UI dédiée de supervision du bus ni un transport inter-processus distribué.

## V3.9 — OPS Autonomous Production Pipeline

La V3.9 ajoute un pipeline de production de jeu : sauvegarde de référence, lancement coordonné de l'équipe IA, suivi d'exécution, contrôles syntaxiques/non-régression et création conditionnelle d'une version livrable. Voir `docs/OPS_AUTONOMOUS_PRODUCTION_V3_9.md`. La validation automatique ne remplace pas la revue humaine et les propositions restent soumises au mode d'approbation du projet.

Dans l'interface, ouvrir **Production autonome** dans la navigation pour lancer un cahier des charges, suivre les exécutions, voir les approbations en attente et consulter le résultat des contrôles.

## OPS VISUAL GAME TESTING — V3.11

Le module `server/visual-testing.mjs` ajoute un audit visuel statique des projets : présence du viewport mobile, structure HTML, indices de rendu 3D/canvas, boucle de rendu, gestion du redimensionnement, commandes tactiles/pointeur, sémantique et quelques risques CSS responsive. Il conserve les rapports dans `test_reports` et expose `POST /api/projects/:id/visual-tests` pour lancer un audit ainsi que `GET /api/projects/:id/visual-tests` pour consulter l'historique.

**Limite explicite :** V3.11 inspecte les sources, mais ne lance pas le jeu dans un navigateur automatisé et ne capture pas encore de captures d'écran. Son score est heuristique ; il ne mesure ni la qualité artistique ni les performances réelles. Les tests visuels réels par navigateur/capture restent une évolution ultérieure.


## OPS GAMEPLAY TESTER V3.12

V3.12 ajoute un test navigateur réel optionnel (Playwright + Chromium) : démarrage d'une page de jeu en contexte isolé, captures d'écran, erreurs JavaScript/console, viewport mobile/desktop et inspection canvas/WebGL. Voir `docs/OPS_GAMEPLAY_TESTER_V3_12.md`. Playwright/Chromium doit être installé sur le serveur et l'autorisation d'exécution du projet activée.

Rapport de validation V3.12 : `docs/RAPPORT_TESTS_V3_12.md`.

## OPS AUTOMATIC BUG FIXER V3.13
À partir d'un rapport de test, le Centre de tests peut créer une mission de diagnostic multi-agents. OPS sauvegarde le projet avant intervention, transmet les constats et extraits utiles à l'équipe, puis suit l'exécution. Les propositions de fichiers respectent le mode d'approbation du projet. Le module ne lance pas de scripts du jeu et ne prétend pas qu'un défaut est corrigé avant vérification et nouveau test. Voir `docs/OPS_AUTOMATIC_BUG_FIXER_V3_13.md`.


## OPS AUTOMATIC BUG FIXER V3.13
Le Centre de tests permet de lancer une mission de diagnostic multi-agents à partir d'un rapport Gameplay Tester. OPS crée une sauvegarde préalable, transmet les preuves et extraits de sources à l'équipe et suit l'exécution. Les propositions de fichiers respectent le mode d'approbation du projet. Aucun script du jeu n'est lancé par ce module. Une mission créée n'est pas une correction confirmée : les changements doivent être examinés puis les tests relancés. Voir `docs/OPS_AUTOMATIC_BUG_FIXER_V3_13.md`.

Rapport de validation V3.13 : `docs/RAPPORT_TESTS_V3_13.md`.


### OPS CODER AI V3.15 — écriture réelle du code

OPS CODER AI doit livrer des fichiers complets avec `<ops-file>`, pas uniquement décrire une solution. L’orchestrateur traite maintenant les appels d’inspection et les fichiers dans une même réponse, conserve les fichiers à travers les tours, puis transmet les sources à OPS DEBUG AI. Une tâche de programmation sans fichier est relancée ; si aucun fichier n’est finalement fourni, elle échoue explicitement. Le mode `approval` garde les changements en attente de validation ; le mode `auto` les applique avec sauvegarde et annulation. Voir `docs/OPS_CODER_REAL_IMPLEMENTATION_V3_15.md`.


### OPS CODER AI V3.16 — modifications ciblées

En plus des fichiers complets `<ops-file>`, le CODER peut proposer un patch `<ops-patch>` au format JSON : une liste d’opérations `find` / `replace`. Il doit d’abord lire le fichier. Chaque contexte recherché doit exister exactement une fois ; un contexte absent ou répété fait échouer la tâche plutôt que de risquer une modification incorrecte. Les patchs sont appliqués au contenu réellement présent dans le workspace, regroupés par chemin, puis convertis en propositions de fichiers complètes. Le même chemin ne peut pas être livré à la fois comme fichier complet et comme patch dans une même tâche.

Les modifications passent ensuite par le circuit de sauvegarde, d’approbation ou d’application automatique existant. Le mode `approval` reste la valeur sûre ; le mode `auto` applique avec sauvegarde et annulation. Les suppressions restent soumises à confirmation. Voir `docs/OPS_CODER_PATCH_WORKFLOW_V3_16.md`.


### OPS MULTI-FILE ENGINE V3.17 — graphe d’intégration

Après la collecte des fichiers complets et des patchs, l’orchestrateur construit un graphe statique des références locales détectables : imports/exports JavaScript et TypeScript, imports dynamiques, `require`, scripts HTML et feuilles de style référencées. Les cibles sont recherchées parmi les fichiers livrés et l’arborescence existante. Les liens trouvés et les références sans cible connue sont ajoutés au compte rendu de la tâche afin que DEBUG et QUALITY puissent les examiner.

Ce contrôle est volontairement statique : il ne remplace pas un bundler, un compilateur, un navigateur ou les tests du projet. Les imports conditionnels, alias de bundler, résolutions spécifiques à un framework et ressources générées peuvent nécessiter une vérification réelle. Les avertissements sont des pistes à examiner, pas une preuve automatique que le projet ne fonctionne pas. Voir `docs/OPS_MULTI_FILE_ENGINE_V3_17.md`.


## V3.19 — OPS GAME FACTORY AI

- Blueprint de production structuré en 9 flux de travail dépendants : cadrage, architecture, monde, gameplay, spécialistes, assemblage CODER, DEBUG, QUALITY et livraison.
- Extraction d'exigences atomiques avec identifiants stables (REQ-001, etc.) depuis le cahier des charges.
- Contrats de livrables et portes d'acceptation explicites.
- Instructions de production transmises aux agents avec dépendances et exigences traçables.
- Rapport de livraison Factory : manifest des fichiers, diagnostics d'intégration, non-régression, tests et exigences à revoir.
- Aucune exigence n'est automatiquement déclarée terminée sans preuve et validation.
- Le blueprint planifie le travail ; l'exécution réelle dépend toujours des agents/fournisseurs configurés et des validations autorisées.

Documentation V3.19 : `docs/OPS_GAME_FACTORY_AI_V3_19.md`.


## V3.20 — OPS CONTINUOUS GAME DEVELOPMENT

- Reprise d'une production interrompue ou échouée via `POST /api/production/:id/resume`.
- Conservation de la baseline originale, du brief, des contraintes et des fichiers existants.
- Historique borné des tentatives avec rapports et état des tâches précédentes.
- Nouveau run d'équipe contextualisé par le manifeste actuel et les diagnostics d'intégration.
- Reprise proposée dans l'interface Production pour les statuts `partial`, `development_failed` et `quality_failed`.
- Refus de reprise pendant une production active, en attente d'approbation ou déjà prête pour revue.
- Aucun script du projet n'est exécuté automatiquement.

Documentation V3.20 : `docs/OPS_CONTINUOUS_GAME_DEVELOPMENT_V3_20.md`.


## V3.21 — OPS AI STUDIO COLLABORATION

- Transmissions inter-IA persistantes avec inbox, accusés de réception, états de traitement, résultat et transitions contrôlées.
- Conversion des demandes `<ops-request>` en transmissions enregistrées avant la planification du travail destinataire.
- Réservation exclusive des fichiers/ressources par agent et tâche, détection des conflits HTTP 409 et événements `artifact.conflict`.
- Libération explicite des ressources après intégration ou revue.
- Injection des transmissions en attente et des ressources réservées dans le contexte des agents.
- Validation des identifiants d’agents, des états et des chemins relatifs ; refus des chemins absolus et traversées `..`.

Documentation V3.21 : `docs/OPS_AI_STUDIO_COLLABORATION_V3_21.md`.


## V3.22 — INTELLIGENT PROJECT MANAGER

Tableau de pilotage des projets : agrégation des tâches orchestrateur/Director/collaboration, détection de blocages et tâches anciennes, charge des agents, ressources réservées, dépendances moteurs et transmissions manuelles contrôlées. Voir `docs/OPS_INTELLIGENT_PROJECT_MANAGER_V3_22.md`.


## V3.23 — AUTONOMOUS AI SUPERVISOR

Ajout du superviseur multi-agents, des scans observation/assistance, de la détection de tâches bloquées ou anciennes, du suivi des transmissions et du contrôle de présence des fichiers approuvés. Voir `docs/OPS_AUTONOMOUS_AI_SUPERVISOR_V3_23.md` pour les limites et les API.

## V3.24 — AUTONOMOUS AI CONTROL CENTER

Ajout d'un centre de contrôle global en lecture seule : vue consolidée des projets, agents, tâches, transmissions, moteurs, IA du Studio et alertes. Le tableau se rafraîchit sur les événements OPS et périodiquement. Il n'exécute aucun travail et ne modifie aucune tâche. Voir `docs/OPS_AUTONOMOUS_AI_CONTROL_CENTER_V3_24.md`.

## V3.25 — Autonomous AI Orchestration Engine

La V3.25 ajoute un planificateur multi-IA avec dépendances validées, affectation par spécialité/charge, transmissions persistantes et déblocage des étapes suivantes. Voir `docs/OPS_AUTONOMOUS_AI_ORCHESTRATION_ENGINE_V3_25.md` pour les API, garanties et limites.

## OPS AUTONOMOUS AI ORCHESTRATION ENGINE — V3.25

La V3.25 ajoute un moteur d'orchestration multi-IA indépendant. Il valide les dépendances (dont les cycles), transmet les tâches sans prérequis en parallèle, puis débloque les suivantes lorsque les transmissions précédentes sont réellement terminées. Voir `docs/OPS_AUTONOMOUS_AI_ORCHESTRATION_ENGINE_V3_25.md`.

## V3.26 — Autonomous AI Execution Engine

La V3.26 fait évoluer l'orchestration V3.25 vers l'exécution réelle : les tâches sont lancées via le runtime agent OPS ou les handlers spécialisés du Director (WORLD/MODELING inclus), leurs résultats et identifiants de run sont persistés, et les dépendances restent bloquées tant qu'un livrable ou une approbation n'est pas validé. L'interface propose démarrer, pause, reprise, relance ciblée, consultation des résultats et journal d'exécution. Aucun script/build/test de projet n'est lancé automatiquement ; les autorisations et modes d'écriture existants restent maîtres. Détails : `docs/OPS_AUTONOMOUS_AI_EXECUTION_ENGINE_V3_26.md`.

## V3.27 — AI Intelligence & Skills Evolution

La V3.27 ajoute une couche additive de profils d'expertise et de méthode de travail pour chacun des 14 agents OPS. Le contexte spécialisé est injecté dans leur prompt système sans remplacer leurs instructions, le protocole commun, les contrats métier NEURAL ni le curriculum existant de CODER.

Cette évolution renforce la qualité du contexte (observation, décision, production, vérification, collaboration et compte rendu). Elle ne modifie pas les poids des modèles fournisseurs et ne constitue pas un fine-tuning. Voir `docs/OPS_AI_INTELLIGENCE_SKILLS_EVOLUTION_V3_27.md`.

## V3.28 — OPS NEURAL LEARNING ENGINE

Capitalisation des leçons explicitement signalées par les agents, stockage en attente de validation, traçabilité par tâche et statistiques d'apprentissage. Les expériences approuvées alimentent les contextes des tâches pertinentes ; aucune leçon n'est promue automatiquement et aucun poids de modèle externe n'est modifié.
Voir `docs/OPS_NEURAL_LEARNING_ENGINE_V3_28.md`.

## V3.29 — OPS AI PERFORMANCE & BENCHMARK ENGINE

Mesures par agent à partir des tâches et journaux fournisseur observés, score composite explicable, niveau de confiance selon l'échantillon et instantanés historiques. Les limites de comparaison et de portée des journaux fournisseur sont indiquées dans l'interface.

Voir `docs/OPS_AI_PERFORMANCE_BENCHMARK_ENGINE_V3_29.md`.


## V3.30 — OPS OPERATIONAL READINESS

- Diagnostic authentifié global et par projet : `GET /api/system/readiness` et `GET /api/system/readiness?project_id=<id>`.
- Contrôle des fournisseurs activés et utilisables, 13 IA du studio, agents développeurs, recherche Web, moteurs externes et autorisation d'exécution du projet.
- États explicites `ready`, `warning`, `blocked` et `disabled` ; aucune disponibilité externe n'est simulée.
- Écran « État opérationnel » dans la navigation.
- Tests API avec et sans fournisseur de test.

Documentation : `docs/OPS_OPERATIONAL_READINESS_V3_30.md`. Un diagnostic `ready` confirme les prérequis locaux observés ; il ne remplace pas le test de connexion réel ni une validation de qualité.

## IA locale — OPS INTERNAL CORE V1.0 (intégré en V3.30)

Noyau 100 % local (`server/internal-core.mjs`), sans réseau ni clé API : routage par spécialité (14 agents), calculs vérifiés, plans de tâches structurés, règles de contrôle.
- `GET /api/internal-core/status` et `POST /api/internal-core/chat` (`{ "agent_id": "debug", "message": "..." }`).
- `OPS_LOCAL_FALLBACK=1` : quand aucun fournisseur n'est configuré, les agents utilisent ce noyau au lieu d'échouer.

Limite honnête : c'est un moteur à règles, pas un grand modèle génératif. Il ne génère pas de code, de scènes 3D ni de longs textes libres ; pour cela, configurez un fournisseur (Ollama / LM Studio en local, via « Compatible OpenAI »).

## Maintenance V4.1.0 (socle conservé)

V4.1.0 conserve les modules de V4.0 et renforce la validation de configuration, les protections HTTP, la limitation des tentatives d'authentification, la gestion des requêtes volumineuses et les délais serveur. Voir `docs/OPS_MASTER_AI_NEURAL_V4_1.md`.


## V4.3 — Recherche connectée renforcée

- Les 14 agents conservent l’accès commun aux outils `web_search` et `web_fetch` via l’orchestrateur, dès qu’un fournisseur Tavily ou Brave est configuré.
- Recherche Web : validation et déduplication des URL, limite de résultats, cache court (5 minutes), mutualisation des requêtes identiques et nouvelles tentatives bornées sur les erreurs transitoires.
- Lecture de pages : plafond de 1 Mo contrôlé pendant le téléchargement, pas seulement après réception.
- Protocole commun : demander des sources officielles, corroborer les informations importantes, dater les constats quand la page le permet et traiter les pages externes comme des données non fiables.
- Ces améliorations renforcent les procédures et le contexte des agents ; elles ne modifient pas les poids neuronaux des modèles fournisseurs.

## V5.1 — Release Gate intégré au suivi de production
- Chaque pipeline terminé ou prêt pour revue peut ouvrir son rapport Release Gate directement depuis son détail.
- Le rapport distingue les contrôles réussis, les points à vérifier et les blocages, sans confondre présélection et certification de publication.
- Route : `GET /api/production/:id/release-gate`.
- Le contrôle reste statique et n'exécute aucun script du projet.


## V5.2 — Reprises réelles des tâches multi-agents

- Une tâche qui reçoit un run terminé en échec ou un résultat inexploitable déclenche maintenant la seconde tentative prévue, au lieu d’être immédiatement considérée comme définitivement terminée.
- La même règle s’applique aux moteurs spécialisés WORLD/MODELING lorsqu’un livrable échoue à sa validation.
- Les propositions rejetées, les approbations invalides et les erreurs de configuration/authentification ne sont pas relancées automatiquement.
- Chaque nouvelle tentative efface les identifiants d’exécution précédents afin de ne pas rattacher par erreur un ancien run au résultat courant.
- Les événements de reprise sont consignés dans le journal d’orchestration.

Cette amélioration conserve la limite actuelle de deux tentatives automatiques par tâche ; une relance manuelle reste disponible après intervention.


## V5.3 — Récupération des plans après redémarrage

- Au démarrage, OPS réconcilie les plans d'orchestration restés en cours avec l'état réel des exécutions.
- Les tâches interrompues ayant encore un essai et une erreur récupérable sont remises dans la file automatiquement.
- Les tâches en revue, les approbations en attente, les refus et les erreurs de configuration ne sont pas rejoués.
- Les résultats validés et les dépendances sont conservés ; la récupération ne recrée pas le projet.
- La reprise est journalisée et reste limitée à deux tentatives par tâche.

## V6.0 — Manifeste de livraison vérifiable

La V6.0 ajoute un manifeste de livraison calculé à partir des fichiers réels du workspace : inventaire trié, empreinte SHA-256 par fichier et empreinte racine, détection de fichiers/valeurs pouvant contenir des secrets, repérage des points d'entrée, fichiers README et lockfiles.

- `GET /api/projects/:id/release-manifest` : calcule le manifeste sans modifier le projet.
- `POST /api/projects/:id/release-manifest/snapshot` : crée un snapshot versionné si aucun élément bloquant n'est détecté.
- Le contrôle ne lance aucun script du projet. Une empreinte garantit l'intégrité des octets observés, pas la qualité fonctionnelle du logiciel.
- Les secrets détectés bloquent le snapshot ; les preuves documentaires manquantes demandent une revue.

## V6.2 — profils de modélisation géométrique
La section MODELING AI propose désormais trois profils de finesse géométrique (`balanced`, `high`, `ultra`). High est sélectionné par défaut dans l'interface ; Balanced convient aux appareils modestes et Ultra aux assets héros. Les paramètres sont conservés dans les données de l'asset et son manifeste. Cette évolution améliore la résolution des formes courbes tout en conservant les LOD et contrôles existants ; elle ne prétend pas fournir automatiquement des sculptures ou textures artistiques AAA.

Validation V6.2 : `npm test` (172 tests) et `npm run doctor` (6 contrôles, 0 alerte, 0 erreur).


## V6.3 — textures PBR exportées

Le studio MODELING produit désormais des maps PNG BaseColor, Normal et ORM (64×64) pour chaque matériau. Le glTF embarque les textures et les matériaux PBR ; les exports OBJ/MTL référencent les BaseColor. Les PNG sont téléchargeables individuellement et passent correctement par le système d’approbation et l’écriture binaire. Les textures sont procédurales et basse résolution : cette étape établit le pipeline technique, sans prétendre remplacer des textures artistiques 2K/4K/8K ou une finition AAA. Validation V6.3 : `npm test` (173 tests réussis) et `npm run doctor` (6 contrôles OK, 0 alerte, 0 erreur).


## V6.4 — Textures PBR haute résolution

- MODELING AI accepte les résolutions de textures 64, 128, 256, 512, 1024 et 2048 pixels.
- Les maps BaseColor, Normal et ORM sont exportées en PNG externes et référencées depuis glTF 2.0.
- Les kits de villes livrent aussi leurs textures (profil 128×128 pour maîtriser la taille).
- Les modèles individuels utilisent 512×512 par défaut ; les résolutions 1024/2048 sont optionnelles et augmentent fortement le temps et la taille des exports.
- Limite connue : les maillages restent procéduraux ; sculpting organique, peinture manuelle, retopologie et assets humains/vehicules détaillés ne sont pas inclus dans cette version.

## V6.5 — Sculpting géométrique procédural

Ajout d'une API de sculpture non destructive pour les assets existants : brosses inflate, smooth et flatten, modifications des trois LOD, recalcul des normales et bornes, validation avant mise à jour des exports. Voir `docs/MODELING.md`. Le viewport sculpting interactif et la retopologie ne sont pas inclus dans cette version.


## V6.6 — Éditeur de sculpture intégré

Ajout d’un onglet Éditeur de sculpture dans MODELING AI : sélection d’un asset valide, aperçu SVG, réglage du pinceau (inflate/smooth/flatten), rayon, force et centre XYZ, application via l’API authentifiée de sculpture, recalcul et validation des trois LOD. L’édition est une interface de commande de sculpture géométrique ; elle ne constitue pas encore un viewport 3D temps réel avec interaction au stylet.


## V6.7 — Viewport 3D interactif

- Ajout d’un viewport WebGL 2 intégré à l’éditeur de sculpture, sans CDN ni dépendance réseau.
- Chargement du maillage glTF 2.0 de l’asset sélectionné, rendu du LOD0, couleurs PBR de base et normalisation de l’échelle pour cadrer les modèles.
- Rotation par glissement tactile/souris et zoom par pincement ou molette.
- Les opérations Inflate / Smooth / Flatten restent appliquées côté serveur avec validation et recalcul des LOD. La sélection directe de sommets et la sculpture au pinceau directement sur la surface restent des étapes ultérieures.

## V6.8 — Sélection tactile de sommets

- Le viewport propose un mode de sélection au toucher distinct du mode rotation.
- Un tap près d'un sommet du maillage glTF sélectionne le point projeté le plus proche et reporte ses coordonnées dans le repère réel du modèle (mètres) dans le centre du pinceau.
- Le pinceau choisi peut ensuite être appliqué avec les contrôles existants ; les modifications passent toujours par l'API serveur, qui recalcule les normales et valide les trois LOD.
- Limite connue : la sélection est une sélection du sommet projeté le plus proche, pas encore un picking par rayon avec test d'occlusion ; la sculpture continue en glissant sur la surface n'est pas encore implémentée.

## V6.9 — Picking de surface et trait de sculpture tactile

- Remplacement de la sélection du sommet projeté le plus proche par un picking triangle-écran utilisant les coordonnées barycentriques et la profondeur pour retenir la surface la plus proche.
- Le point sélectionné est reconverti en coordonnées du modèle (mètres) et alimente le centre du pinceau.
- Le mode tactile permet de tracer un trait ; les points échantillonnés sont envoyés au endpoint de sculpture en un lot borné à 32 opérations, avec validation serveur et recalcul des LOD.
- Le zoom à deux doigts reste disponible. Limites : picking CPU sur le LOD0, lot de 32 points par trait, pas encore de peinture PBR/UV ni de sculpting GPU temps réel. Le test physique Android reste à effectuer.


## V7.0 — Matériaux PBR dans le viewport

- Le viewport WebGL 2 charge les PNG externes référencés par le glTF pour les maps BaseColor, Normal et ORM (occlusion, roughness, metallic).
- Ajout des UV `TEXCOORD_0`, des textures GPU, des mipmaps et d'un shader d'éclairage temps réel simplifié avec composante diffuse et spéculaire.
- Les textures restent facultatives : si une map manque ou ne peut pas être décodée, le matériau conserve un rendu de secours basé sur sa couleur.
- Le chargement utilise l'API authentifiée des assets ; aucun CDN ni service externe n'est requis.
- Limites : éclairage PBR simplifié, pas d'IBL/HDRI ni de gestion complète des tangentes glTF ; rendu physique sur Android à vérifier.


## V7.1 — Éclairage studio et réglages PBR

Le viewport dispose de trois ambiances de studio, de réglages temps réel pour l’éclairage ambiant et principal, ainsi que d’ajustements non destructifs de rugosité et de réponse métallique. L’environnement est procédural et stylisé : il ne s’agit pas encore d’un système HDRI/IBL ni d’ombres portées physiques.


## V7.2 — Bibliothèque de matériaux

- Ajout de presets de prévisualisation : béton mat, métal peint, métal poli, bois verni, caoutchouc et pierre.
- Possibilité d’enregistrer et supprimer des presets personnalisés, stockés localement par projet dans le navigateur.
- Application immédiate des paramètres au viewport : ambiance, intensité lumineuse, rugosité et réponse métallique.
- Fonctionnement non destructif : les fichiers glTF et les textures PBR source ne sont pas réécrits par l’application d’un preset.
- Limite : cette bibliothèque pilote l’aperçu et ne remplace pas encore un éditeur de matériaux qui réécrit les matériaux glTF ou peint les textures UV.


## V7.3 — Éditeur de matériaux PBR persistant

- Ajout d'une API authentifiée `PUT /api/modeling/assets/:id/materials/:materialId` pour modifier les facteurs PBR d'un matériau d'asset.
- Éditeur intégré : choix du matériau, couleur BaseColor, metallic et roughness.
- Écriture durable des facteurs dans les exports glTF 2.0 et MTL ; ajout des propriétés de matériaux au manifeste `.ops-asset.json`.
- Les textures PNG BaseColor / Normal / ORM restent intactes : les changements portent sur les facteurs de matériau, pas sur la peinture des pixels UV.
- Les overrides sont conservés dans les paramètres de l'asset et réappliqués après une sculpture ; les opérations de sculpture existantes ne sont pas perdues lors d'une édition PBR.
- Validation stricte des plages de valeurs (0–1), du matériau ciblé et du type d'asset.
- Le viewport applique également les facteurs metallic/roughness par matériau.

## V7.4 — Missions autonomes multi-agents

Ajout d'un lancement d'objectif depuis OPS Autonomous AI Supervisor : le Director transforme un objectif en plan spécialisé, les dépendances sont conservées lors de la conversion vers le moteur d'orchestration, puis les agents configurés peuvent démarrer sans saisie manuelle de chaque tâche. Les modifications de fichiers restent soumises au mode d'approbation du projet ; aucune commande système n'est lancée automatiquement. Voir `docs/OPS_MASTER_AI_NEURAL_V7_4.md`.

## V7.4 — Missions autonomes multi-agents

Ajout d'un lancement d'objectif depuis OPS Autonomous AI Supervisor : le Director transforme un objectif en plan spécialisé, les dépendances sont conservées lors de la conversion vers le moteur d'orchestration, puis les agents configurés peuvent démarrer sans saisie manuelle de chaque tâche. Les modifications de fichiers restent soumises au mode d'approbation du projet ; aucune commande système n'est lancée automatiquement. Voir `docs/OPS_MASTER_AI_NEURAL_V7_4.md`.

## V7.5 — OPS CODER AI renforcé

Le CODER reçoit désormais un protocole d'exécution plus strict : décomposition des exigences, recherche de la source de vérité, traitement des cas limites, implémentation réellement intégrée, vérification incrémentale et relecture des changements. Un test dédié vérifie que ces consignes sont présentes dans le prompt construit. Cette évolution améliore le contexte de travail ; elle ne réalise pas un fine-tuning des poids du modèle fournisseur. Voir `docs/OPS_MASTER_AI_NEURAL_V7_5.md`.


## V7.6 — Diagnostics CODER adaptés au langage

OPS CODER regroupe les fichiers modifiés par langage et prépare les vérifications adaptées (syntaxe, compilation, tests, intégration). Le diagnostic local valide également les artefacts JSON. Les commandes de projet ne sont pas exécutées automatiquement ; seules leurs sorties réelles peuvent être rapportées comme preuves. Voir `docs/OPS_MASTER_AI_NEURAL_V7_6.md`.

## V7.7 — Diagnostic compilateur et réparation ciblée
La V7.7 normalise les sorties de compilation/tests déjà enregistrées (TypeScript, ESLint, Python, Rust, Go, Java, C# et erreurs génériques), extrait les chemins/lignes/codes reconnus et les transmet au Bug Fixer comme indices à confirmer dans le code. Le parsing est borné et rejette les chemins de traversée. Aucun compilateur ni script de projet n'est lancé par ce module ; les modifications restent soumises aux approbations existantes. Voir `docs/OPS_MASTER_AI_NEURAL_V7_7.md`.


## V7.8 — Contrôle des régressions après correction
Après la fin d'une mission Bug Fixer, OPS compare le workspace à la sauvegarde créée avant correction et expose un bilan : fichiers supprimés, fonctions/classes disparues et fichiers fortement réduits. Les suppressions de fichiers sont signalées comme bloquantes ; les pertes de symboles et réductions importantes exigent une revue. Une comparaison propre ne remplace pas les tests fonctionnels. Aucun rollback, déploiement ou lancement de commande n'est automatique. Voir `docs/OPS_MASTER_AI_NEURAL_V7_8.md`.

## V7.9 — Boucle de correction bornée
OPS Automatic Bug Fixer peut poursuivre une correction à partir d'un nouveau rapport de test échoué. Chaque cycle possède sa propre sauvegarde et son historique. La boucle est limitée à trois cycles, refuse les rapports déjà utilisés et les rapports réussis, et bloque la poursuite si la comparaison détecte la disparition d'un fichier. L'exécution des tests reste explicite ; aucun script du projet n'est lancé automatiquement. Les modifications restent soumises au mode d'approbation du projet. Voir `docs/OPS_MASTER_AI_NEURAL_V7_9.md`.


## V8.0 — Cartographie architecturale multi-fichiers
OPS CODER AI reçoit une carte statique des points d’entrée, dépendances, cycles, références non résolues et modules sources non atteignables. L’analyse d’impact identifie les dépendants directs et transitifs des fichiers modifiés. `inspect_project` expose ces informations aux agents ; après livraison, l’orchestrateur ajoute un rapport d’architecture au résultat. Cette analyse reste indicative et ne remplace pas les tests runtime. Voir `docs/OPS_MASTER_AI_NEURAL_V8_0.md`.
