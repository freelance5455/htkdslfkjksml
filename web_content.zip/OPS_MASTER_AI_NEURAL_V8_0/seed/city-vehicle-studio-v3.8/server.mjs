import http from 'node:http';
import { readFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import { timingSafeEqual } from 'node:crypto';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.PORT || 8787);
const API_BASE = (process.env.OPS_AI_BASE_URL || 'https://api.openai.com/v1').replace(/\/$/, '');
const API_KEY = process.env.OPS_AI_API_KEY || '';
const MODEL = process.env.OPS_AI_MODEL || '';
const GATEWAY_TOKEN = process.env.OPS_GATEWAY_TOKEN || '';
const SEARCH_PROVIDER = (process.env.OPS_WEB_SEARCH_PROVIDER || (process.env.TAVILY_API_KEY ? 'tavily' : process.env.BRAVE_SEARCH_API_KEY ? 'brave' : '')).toLowerCase();
const TAVILY_KEY = process.env.TAVILY_API_KEY || '';
const BRAVE_KEY = process.env.BRAVE_SEARCH_API_KEY || '';
const MAX_BODY = 8 * 1024 * 1024;
const rate = new Map();

function send(res, status, data, type='application/json; charset=utf-8') {
  res.writeHead(status, {'Content-Type': type, 'X-Content-Type-Options':'nosniff', 'Cache-Control':'no-store', 'Referrer-Policy':'no-referrer'});
  res.end(type.startsWith('application/json') ? JSON.stringify(data) : data);
}
async function readBody(req) {
  let size=0, chunks=[];
  for await (const chunk of req) { size += chunk.length; if (size > MAX_BODY) throw new Error('PAYLOAD_TOO_LARGE'); chunks.push(chunk); }
  return JSON.parse(Buffer.concat(chunks).toString('utf8'));
}
function authorized(req) {
  if (!GATEWAY_TOKEN) return false;
  const supplied=Buffer.from(String(req.headers['x-ops-access-token']||''));
  const expected=Buffer.from(GATEWAY_TOKEN);
  return supplied.length===expected.length && timingSafeEqual(supplied,expected);
}
function rateLimit(req) {
  const ip=String(req.socket.remoteAddress||'unknown'); const now=Date.now();
  const row=rate.get(ip)||{start:now,count:0};
  if(now-row.start>60000){row.start=now;row.count=0;} row.count++; rate.set(ip,row);
  return row.count<=45;
}
function requireAccess(req,res) {
  if(!authorized(req)){send(res,401,{error:'Accès refusé. Vérifie le jeton d’accès OPS.'});return false;}
  if(!rateLimit(req)){send(res,429,{error:'Trop de requêtes. Réessaie dans une minute.'});return false;}
  return true;
}
async function callModel(messages, temperature=0.2) {
  if(!API_KEY||!MODEL) throw Object.assign(new Error('Configure OPS_AI_API_KEY et OPS_AI_MODEL sur le serveur.'),{status:503});
  if(!Array.isArray(messages)||!messages.length||messages.length>80) throw Object.assign(new Error('Liste de messages invalide.'),{status:400});
  const controller=new AbortController(); const timer=setTimeout(()=>controller.abort(),120000);
  const tools=[{type:'function',function:{name:'ops_web_search',description:'Recherche sur Internet des informations récentes ou de la documentation. Utilise cet outil quand la mission nécessite des informations externes, techniques ou actuelles. Retourne les sources et URLs.',parameters:{type:'object',properties:{query:{type:'string',description:'Requête précise à rechercher sur le Web.'}},required:['query'],additionalProperties:false}}}];
  async function request(payload){
    const upstream=await fetch(`${API_BASE}/chat/completions`,{method:'POST',headers:{'Authorization':`Bearer ${API_KEY}`,'Content-Type':'application/json'},body:JSON.stringify(payload),signal:controller.signal});
    const raw=await upstream.text();let data;try{data=JSON.parse(raw)}catch{data={rawText:raw.slice(0,1500)}};
    if(!upstream.ok) throw Object.assign(new Error(data?.error?.message||`Le fournisseur IA a répondu HTTP ${upstream.status}.`),{status:upstream.status});
    return data;
  }
  try {
    let conversation=messages.map(m=>({...m}));
    let data;
    try { data=await request({model:MODEL,temperature,messages:conversation,tools,tool_choice:'auto'}); }
    catch(e){
      // Compatibility fallback for OpenAI-compatible endpoints without tool calling.
      if(/tool|function|unsupported|not support|unknown parameter/i.test(e.message)) data=await request({model:MODEL,temperature,messages:conversation});
      else throw e;
    }
    for(let turn=0;turn<3;turn++){
      const message=data?.choices?.[0]?.message;
      const calls=message?.tool_calls||[];
      if(!calls.length)break;
      conversation.push(message);
      for(const call of calls){
        let args={};try{args=JSON.parse(call.function?.arguments||'{}')}catch{}
        let result;
        if(call.function?.name==='ops_web_search'){
          try{result=await webSearch(String(args.query||'').slice(0,1000));}
          catch(e){result={error:String(e.message||e),results:[]};}
        } else result={error:'Outil inconnu.'};
        conversation.push({role:'tool',tool_call_id:call.id,content:JSON.stringify(result).slice(0,14000)});
      }
      data=await request({model:MODEL,temperature,messages:conversation,tools,tool_choice:'auto'});
    }
    const content=data?.choices?.[0]?.message?.content;
    if(!content) throw Object.assign(new Error('Réponse vide du fournisseur IA.'),{status:502});
    return {content,model:MODEL,provider:new URL(API_BASE).host,usage:data.usage||null};
  } catch(e) { if(e.name==='AbortError')throw Object.assign(new Error('Délai fournisseur dépassé.'),{status:504}); throw e; }
  finally {clearTimeout(timer);}
}
async function webSearch(query) {
  if(SEARCH_PROVIDER==='tavily'&&TAVILY_KEY){
    const r=await fetch('https://api.tavily.com/search',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({api_key:TAVILY_KEY,query,search_depth:'basic',max_results:8,include_answer:false})});
    const d=await r.json();if(!r.ok)throw new Error(d?.detail||`Tavily HTTP ${r.status}`);
    return {provider:'Tavily',results:(d.results||[]).map(x=>({title:x.title,url:x.url,content:x.content,score:x.score,publishedDate:x.published_date||null}))};
  }
  if(SEARCH_PROVIDER==='brave'&&BRAVE_KEY){
    const url=new URL('https://api.search.brave.com/res/v1/web/search');url.searchParams.set('q',query);url.searchParams.set('count','8');
    const r=await fetch(url,{headers:{'X-Subscription-Token':BRAVE_KEY,'Accept':'application/json'}});const d=await r.json();if(!r.ok)throw new Error(d?.message||`Brave HTTP ${r.status}`);
    return {provider:'Brave Search',results:(d.web?.results||[]).map(x=>({title:x.title,url:x.url,content:x.description,publishedDate:x.page_age||null}))};
  }
  throw Object.assign(new Error('Recherche Web non configurée : ajoute TAVILY_API_KEY ou BRAVE_SEARCH_API_KEY.'),{status:503});
}
const server=http.createServer(async(req,res)=>{
  const url=new URL(req.url,'http://localhost');
  if(req.method==='GET'&&(url.pathname==='/'||url.pathname==='/index.html')){
    try{return send(res,200,await readFile(path.join(HERE,'index.html')),'text/html; charset=utf-8');}
    catch{return send(res,500,{error:'index.html introuvable à côté du serveur.'});}
  }
  if(req.method==='GET'&&url.pathname==='/api/ops-internet-status'){
    if(!requireAccess(req,res))return;
    return send(res,200,{ok:true,service:'OPS Universal Internet Gateway V3.8',aiConfigured:!!(API_KEY&&MODEL),searchConfigured:(SEARCH_PROVIDER==='tavily'&&!!TAVILY_KEY)||(SEARCH_PROVIDER==='brave'&&!!BRAVE_KEY),searchProvider:SEARCH_PROVIDER||null,provider:API_BASE?new URL(API_BASE).host:null,model:MODEL||null,allAgentsEndpoint:'/api/ops-ai',webSearchEndpoint:'/api/ops-web-search'});
  }
  if(req.method==='GET'&&url.pathname==='/health')return send(res,200,{ok:true,service:'OPS V3.8',aiConfigured:!!(API_KEY&&MODEL),searchConfigured:!!SEARCH_PROVIDER,accessTokenConfigured:!!GATEWAY_TOKEN});
  if(req.method!=='POST')return send(res,404,{error:'Route inconnue.'});
  if(url.pathname==='/api/ops-ai'){
    if(!requireAccess(req,res))return;
    try{const input=await readBody(req);const out=await callModel(input.messages,input.temperature);return send(res,200,{ok:true,content:out.content,model:out.model,provider:out.provider,usage:out.usage,createdAt:new Date().toISOString()});}
    catch(e){return send(res,e.status||500,{error:String(e.message||e).slice(0,700)});}
  }
  if(url.pathname==='/api/ops-web-search'){
    if(!requireAccess(req,res))return;
    try{const input=await readBody(req);const query=String(input.query||'').trim();if(!query||query.length>1000)return send(res,400,{error:'Requête de recherche vide ou trop longue.'});const out=await webSearch(query);return send(res,200,{ok:true,query,provider:out.provider,results:out.results,createdAt:new Date().toISOString()});}
    catch(e){return send(res,e.status||502,{error:String(e.message||e).slice(0,700)});}
  }
  if(url.pathname==='/api/ops-interior'){
    if(!requireAccess(req,res))return;
    try{
      const input=await readBody(req);
      if(input?.contract!=='OPS_INTERIOR_TASK_V2'||!input?.task?.brief||!input?.task?.source?.dataUrl)return send(res,400,{error:'Contrat OPS_INTERIOR_TASK_V2 invalide.'});
      const src=input.task.source;if(!['image/png','image/jpeg','image/webp'].includes(src.mimeType))return send(res,415,{error:'Format image non pris en charge.'});
      const match=String(src.dataUrl).match(/^data:(image\/(?:png|jpeg|webp));base64,([A-Za-z0-9+/=]+)$/);if(!match||match[1]!==src.mimeType)return send(res,400,{error:'Image base64 invalide.'});
      if(Buffer.from(match[2],'base64').length>5*1024*1024)return send(res,413,{error:'Image supérieure à 5 Mo.'});
      const system='Tu es OPS INTERIOR ARCHITECTURE AI. Analyse uniquement le plan fourni avec autorisation. N’infère pas de données privées, n’invente pas les dimensions. Sépare observations, hypothèses et inconnues. Réponds en français en JSON valide. Ne prétends pas avoir créé un fichier 3D.';
      const userText=`Mission : ${String(input.task.brief).slice(0,1800)}\nNom de la source : ${String(src.name||'image').slice(0,120)}\nSchéma : ${JSON.stringify(input.task.outputSchema||{})}\nRetourne JSON avec summary, rooms, walls, openings, furniture, assumptions, unknowns et confidence.`;
      const out=await callModel([{role:'system',content:system},{role:'user',content:[{type:'text',text:userText},{type:'image_url',image_url:{url:src.dataUrl,detail:'high'}}]}],0.2);
      let result;try{result=JSON.parse(typeof out.content==='string'?out.content:JSON.stringify(out.content))}catch{result={summary:'Réponse du modèle',raw:out.content}};
      return send(res,200,{ok:true,contract:'OPS_INTERIOR_RESULT_V2',providerModel:out.model,result,createdAt:new Date().toISOString()});
    }catch(e){return send(res,e.status||500,{error:String(e.message||e).slice(0,700)});}
  }
  return send(res,404,{error:'Route inconnue.'});
});
server.listen(PORT,'0.0.0.0',()=>console.log(`OPS V3.8 Gateway prêt sur le port ${PORT}. IA configurée: ${!!(API_KEY&&MODEL)} · Recherche: ${!!SEARCH_PROVIDER} · Jeton: ${!!GATEWAY_TOKEN}`));
