OPS CITY & VEHICLE STUDIO 3D — V3.8 UNIVERSAL INTERNET GATEWAY

CONTENU
- index.html : application OPS V3.8 complète (base V3.7 préservée + passerelle universelle)
- server.mjs : serveur Node.js, proxy IA commun, recherche Web et endpoint d'analyse de plans
- package.json : lancement Node.js >=18
- .env.example : variables à configurer côté serveur

MISE EN ROUTE (PC ou hébergement Node.js)
1. Installer Node.js 18 ou plus récent.
2. Copier .env.example vers .env (ne jamais publier .env).
3. Configurer OPS_AI_BASE_URL, OPS_AI_API_KEY, OPS_AI_MODEL et OPS_GATEWAY_TOKEN.
4. Pour la recherche Web, configurer OPS_WEB_SEARCH_PROVIDER=tavily + TAVILY_API_KEY, ou provider brave + BRAVE_SEARCH_API_KEY.
5. Lancer : npm start
6. Ouvrir l'adresse HTTPS du serveur, puis dans OPS UNIVERSAL INTERNET saisir la même adresse et OPS_GATEWAY_TOKEN.
7. Cliquer « Connecter toutes les IA ». Le test vérifie la passerelle et le modèle.

FONCTIONNEMENT
- Tous les agents qui utilisent opsAICall sont routés vers /api/ops-ai lorsque la passerelle est activée.
- La recherche Internet est exposée aux modules/agents via window.OPS_INTERNET.search(query).
- Le panneau permet aussi de lancer une recherche manuelle et de vérifier l'état de configuration.
- L'endpoint /api/ops-interior est protégé par le même jeton.
- Les clés fournisseur IA/recherche restent côté serveur. Le jeton OPS est saisi dans le panneau et conservé uniquement en mémoire de la page.

LIMITES ET SÉCURITÉ
- Le fichier HTML seul ne peut pas connecter les agents : le serveur doit être réellement hébergé et configuré.
- Un modèle connecté n'a pas forcément un outil de navigation intégré. Les recherches Web passent par Tavily ou Brave configuré sur le serveur.
- Certaines tâches nécessitent un modèle vision; l'API configurée doit accepter les images pour ces tâches.
- Les appels API peuvent être payants selon le fournisseur et le volume. Vérifier les conditions/limites du fournisseur.
- Déployer uniquement en HTTPS. Ne jamais mettre une clé API dans le HTML ou dans un dépôt public.
- Ajouter une authentification utilisateur/limites supplémentaires avant une mise en production publique à grande échelle.
- La recherche Web renvoie titres, extraits et URLs; vérifier les pages sources avant d'utiliser des faits critiques.

OUTIL WEB POUR LES AGENTS
Le serveur expose un outil de fonction ops_web_search à chaque appel modèle. Les modèles compatibles avec le function calling peuvent demander eux-mêmes des recherches Web pendant leur mission; le serveur exécute la recherche via Tavily ou Brave puis renvoie les sources au modèle. Si le fournisseur IA ne prend pas en charge les appels d'outils, l'appel modèle retombe en mode chat standard et l'agent peut toujours utiliser le panneau de recherche Web ou OPS_INTERNET.search depuis le code client.
