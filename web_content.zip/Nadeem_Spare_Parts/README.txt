NADEEM SPARE PARTS — QUICK START

1. Open index.html in a browser (Chrome recommended).
2. Add parts with purchase price, selling price, quantity, category and optional code.
3. Search/filter the parts list.
4. Tap "Share rate list" to share the current list through Android's share menu/WhatsApp.
5. Tap "Export backup" regularly to save a JSON backup.
6. To restore a backup, tap "Import backup".

IMPORTANT:
- This is a small browser-based starter app, not a Play Store APK.
- Data is stored in the browser on this device. Browser data clearing, private browsing, or switching devices may remove/make it unavailable.
- Export backups regularly. WhatsApp sharing depends on the browser/device share support.
- Shop name/phone number can be added later.
