# Сборка APK: «Укради яйцо 3D»

Нужны: Node.js 18+, Android Studio (с Android SDK) и интернет для первой установки.

1. `npm install`  — ставит Capacitor и three.js r128 и копирует `three.min.js` в `www/`.
2. `npx cap add android`
3. Откройте `android/app/src/main/AndroidManifest.xml` и в теге `<activity>` добавьте:
   `android:screenOrientation="sensorLandscape"`
4. (Полный экран без панелей) В `android/app/src/main/java/.../MainActivity.java` добавьте в `onCreate` после `super.onCreate(...)`:
   `getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION);`
   (и `import android.view.View;`)
5. `npx cap sync android`, затем `npx cap open android`.
6. В Android Studio: Build → Build Bundle(s) / APK(s) → Build APK(s).
   Файл появится в `android/app/build/outputs/apk/debug/app-debug.apk`.

Для Google Play нужен подписанный релиз: Build → Generate Signed Bundle / APK.
