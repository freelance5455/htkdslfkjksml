import { Capacitor } from '@capacitor/core';
import { FirebaseAuthentication } from '@capacitor-firebase/authentication';
import { initializeApp } from 'firebase/app';
import {
  getAuth, initializeAuth, indexedDBLocalPersistence, GoogleAuthProvider,
  signInWithPopup, signInWithCredential, createUserWithEmailAndPassword,
  signInWithEmailAndPassword, onAuthStateChanged, signOut
} from 'firebase/auth';
import {
  getFirestore, collection, addDoc, getDocs, query, orderBy, serverTimestamp, deleteDoc, doc
} from 'firebase/firestore';
import {
  getStorage, ref, uploadBytesResumable, getDownloadURL, deleteObject
} from 'firebase/storage';
import { firebaseConfig } from './firebase-config.js';
import './style.css';

const $ = id => document.getElementById(id);
const app = initializeApp(firebaseConfig);
let auth;
if (Capacitor.isNativePlatform()) {
  try { auth = initializeAuth(app, { persistence: indexedDBLocalPersistence }); }
  catch { auth = getAuth(app); }
} else auth = getAuth(app);
const db = getFirestore(app);
const storage = getStorage(app);
let user = null, allFiles = [], activeFilter = 'all';

function message(id, text, error=false) {
  const el=$(id); el.textContent=text; el.classList.toggle('error',error);
}
function showLogin() { $('login').classList.remove('hidden'); $('galleryView').classList.add('hidden'); $('logout').classList.add('hidden'); }
function showGallery() { $('login').classList.add('hidden'); $('galleryView').classList.remove('hidden'); $('logout').classList.remove('hidden'); }
function userMedia() { return collection(db, 'users', user.uid, 'media'); }

onAuthStateChanged(auth, async current => {
  user=current;
  if (user) { showGallery(); await loadGallery(); }
  else { showLogin(); allFiles=[]; }
});

$('google').addEventListener('click', async () => {
  $('google').disabled=true;
  try {
    if (Capacitor.isNativePlatform()) {
      const result = await FirebaseAuthentication.signInWithGoogle();
      const credential = GoogleAuthProvider.credential(result.credential?.idToken);
      await signInWithCredential(auth, credential);
    } else {
      const provider = new GoogleAuthProvider();
      await signInWithPopup(auth, provider);
    }
  } catch(e) { message('authMsg', e.message, true); }
  finally { $('google').disabled=false; }
});

$('loginBtn').onclick = async () => {
  try {
    await signInWithEmailAndPassword(auth, $('email').value.trim(), $('password').value);
    message('authMsg','');
  } catch(e) { message('authMsg', e.message, true); }
};
$('signupBtn').onclick = async () => {
  try {
    const p=$('password').value;
    if(p.length<6) throw new Error('Password कम से कम 6 अक्षर का होना चाहिए।');
    await createUserWithEmailAndPassword(auth, $('email').value.trim(), p);
    message('authMsg','Account बन गया।');
  } catch(e) { message('authMsg', e.message, true); }
};
$('logout').onclick = async () => {
  try {
    if (Capacitor.isNativePlatform()) await FirebaseAuthentication.signOut();
    await signOut(auth);
  } catch(e) { alert(e.message); }
};

$('files').onchange = async e => {
  const files=[...e.target.files]; e.target.value='';
  for(const file of files) {
    if(!file.type.startsWith('image/') && !file.type.startsWith('video/')) continue;
    try {
      const id=crypto.randomUUID();
      const safe=file.name.replace(/[^\w.\-() ]/g,'_');
      const path=`users/${user.uid}/${id}_${safe}`;
      const storageRef=ref(storage,path);
      const task=uploadBytesResumable(storageRef,file,{contentType:file.type});
      await new Promise((resolve,reject)=>{
        task.on('state_changed',
          s=>message('progress',`Uploading ${file.name}: ${Math.round(s.bytesTransferred/s.totalBytes*100)}%`),
          reject,resolve);
      });
      const url=await getDownloadURL(task.snapshot.ref);
      await addDoc(userMedia(), {
        name:file.name, type:file.type.startsWith('video/')?'video':'image',
        contentType:file.type, size:file.size, path, url,
        createdAt:serverTimestamp()
      });
    } catch(err) { message('progress',`Upload failed: ${err.message}`,true); }
  }
  message('progress','Upload पूरा हुआ।'); await loadGallery();
};
$('refresh').onclick=loadGallery;
document.querySelectorAll('.filter').forEach(b=>b.onclick=()=>{
  activeFilter=b.dataset.filter;
  document.querySelectorAll('.filter').forEach(x=>x.classList.toggle('active',x===b));
  render();
});

async function loadGallery() {
  if(!user)return;
  message('progress','Gallery लोड हो रही है…');
  try {
    const q=query(userMedia(),orderBy('createdAt','desc'));
    const snap=await getDocs(q);
    allFiles=snap.docs.map(d=>({id:d.id,...d.data()}));
    render(); message('progress','');
  } catch(e) { message('progress',`Load error: ${e.message}`,true); }
}
function render() {
  $('photos').textContent=allFiles.filter(x=>x.type==='image').length;
  $('videos').textContent=allFiles.filter(x=>x.type==='video').length;
  $('total').textContent=allFiles.length;
  const grid=$('grid'); grid.replaceChildren();
  const list=allFiles.filter(x=>activeFilter==='all'||x.type===activeFilter);
  if(!list.length) { grid.innerHTML='<div class="empty">☁️<h3>अभी कोई फाइल नहीं</h3><p>अपनी पहली फोटो या वीडियो अपलोड करें।</p></div>'; return; }
  for(const item of list) {
    const card=document.createElement('article'); card.className='card';
    const preview=document.createElement('div'); preview.className='thumb';
    if(item.type==='image') { const img=document.createElement('img'); img.src=item.url; img.alt=item.name; img.loading='lazy'; preview.append(img); }
    else preview.textContent='▶ VIDEO';
    preview.onclick=()=>openViewer(item);
    const details=document.createElement('div'); details.className='details';
    const name=document.createElement('div'); name.className='filename'; name.textContent=item.name;
    const actions=document.createElement('div'); actions.className='actions';
    const dl=document.createElement('button'); dl.textContent='↓ Download'; dl.onclick=()=>download(item);
    const del=document.createElement('button'); del.textContent='Delete'; del.className='delete'; del.onclick=()=>remove(item);
    actions.append(dl,del); details.append(name,actions); card.append(preview,details); grid.append(card);
  }
}
function openViewer(item) {
  $('viewname').textContent=item.name; $('viewbody').replaceChildren();
  let el;
  if(item.type==='image'){el=document.createElement('img');el.src=item.url;}
  else {el=document.createElement('video');el.src=item.url;el.controls=true;el.autoplay=true;}
  $('viewbody').append(el); $('viewer').classList.remove('hidden');
}
$('closeViewer').onclick=()=>{$('viewer').classList.add('hidden');$('viewbody').replaceChildren();};
async function download(item) {
  try {
    const a=document.createElement('a'); a.href=item.url; a.download=item.name; a.target='_blank';
    document.body.append(a); a.click(); a.remove();
  } catch(e) { alert('Download error: '+e.message); }
}
async function remove(item) {
  if(!confirm(`${item.name} को हमेशा के लिए delete करें?`))return;
  try {
    await deleteObject(ref(storage,item.path));
    await deleteDoc(doc(db,'users',user.uid,'media',item.id));
    await loadGallery();
  } catch(e) { alert(`Delete error: ${e.message}`); }
}
