# GMGALLERY — Website + Android APK source

यह एक तैयार **starter project/source code** है। यह अपने-आप APK नहीं बनाता: Firebase project configuration, Google OAuth setup और Android build/signing करना होगा। कोई भी AI/HTML फाइल बिना इन external credentials और build steps के 100% live cloud app नहीं बन सकती।

## शामिल फीचर
- GMGALLERY branding और GM logo
- Google login (Web पर Firebase popup; Android पर native Google sign-in)
- Email/password signup और login
- Firebase Storage में photo/video upload
- Firestore में file metadata
- Same account से दूसरे phone/browser पर gallery
- Preview, download, delete, Photos/Videos filters
- प्रति file 200 MB की Storage Rules सीमा (इसे अपनी जरूरत के अनुसार बदलें)

## 1. Firebase तैयार करें
1. https://console.firebase.google.com/ पर नया project बनाएं।
2. Authentication → Sign-in method में **Google** और **Email/Password** enable करें।
3. Authentication → Settings → Authorized domains में अपनी website domain जोड़ें।
4. Firestore Database बनाएं और `firestore.rules` publish करें।
5. Storage bucket बनाएं और `storage.rules` publish करें।
6. Project settings → Your apps → Web app से config लें और `src/firebase-config.js` में placeholders बदलें।
7. Storage billing/plan और region की उपलब्धता अपने Firebase Console में जांचें। बड़े backup के लिए लागत/quotas लागू हो सकते हैं।

## 2. Website चलाएं / deploy करें
Node.js 20+ install करें, फिर project folder में:
```bash
npm install
npm run dev
```
Local test के बाद:
```bash
npm run build
```
`dist/` folder को Firebase Hosting, Netlify या किसी HTTPS static host पर deploy करें। Firebase Authentication OAuth के लिए HTTPS और Authorized Domains configure करें।

## 3. Android APK बनाएं
Android Studio और Android SDK install करें:
```bash
npm install
npx cap add android
npm run android:sync
npx cap open android
```
Android Studio में Gradle sync करें, फिर Build → Build Bundle(s) / APK(s) → Build APK(s) चुनें। Release के लिए signed APK/AAB बनाएं।

### Android Google Login — आवश्यक Firebase सेटअप
1. Firebase Console → Project settings → Your apps → Android app जोड़ें।
2. Package ID वही रखें: `com.govindrawatt.gmgallery`।
3. Android app का SHA-1 और SHA-256 fingerprint Firebase project में जोड़ें।
4. `google-services.json` डाउनलोड करके `android/app/google-services.json` में रखें।
5. `android/variables.gradle` में `ext` block के अंदर जोड़ें:
```gradle
rgcfaIncludeGoogle = true
androidxCredentialsVersion = '1.3.0'
```
6. फिर चलाएं:
```bash
npx cap sync android
```
7. Google provider Firebase Authentication में enabled होना चाहिए।

## 4. महत्वपूर्ण सुरक्षा / Backup नोट्स
- Firebase config web app में दिखाई देती है; यह सामान्य है। असली सुरक्षा Firestore और Storage Rules से आती है। Rules को public (`allow read, write: if true`) न करें।
- अभी app manually चुनी गई files upload करता है। यह background auto-sync नहीं करता।
- Delete करने पर cloud से file हटती है; जरूरी data delete करने से पहले backup रखें।
- Uploads के लिए network और Firebase Storage access चाहिए। दूसरे मोबाइल पर उसी Google/email account से login करें।
- वीडियो के लिए device/browser support और storage quotas लागू हैं।
- यह starter project है, production launch से पहले वास्तविक devices पर Google login, uploads, downloads, deletion, quota, privacy policy और security rules test करें।

## Official setup references
- Firebase Google sign-in: https://firebase.google.com/docs/auth/web/google-signin
- Capacitor Firebase Authentication: https://github.com/capawesome-team/capacitor-firebase
- Capacitor Android: https://capacitorjs.com/docs/android
