# MTX source patch notes

## Fixes included

1. Android media uploads now use `POST /api/upload/chunk` and send sequential 4 MiB chunks instead of one large request.
2. The Node server validates chunk metadata, stores chunks temporarily, assembles the final file in order, and returns a URL only after assembly succeeds.
3. Full media URLs are no longer rewritten from the pre-production host to the development host. This prevents a successful upload on one candidate server from being saved with a URL pointing at another server.
4. Video catalogue synchronization uses longer network timeouts, and the admin UI distinguishes successful file upload from failed catalogue publication.
5. README documents the deployment requirements and the serverless-storage limitation.

## Deployment order

1. Deploy the updated `server.js` to the same cloud service used by the app.
2. Verify `GET /api/status` responds successfully.
3. Build and install the updated Android app source.
4. Test with a small video first, then a larger video.

## Important hosting limitation

The Node server stores media under its local `uploads/` directory. Local container storage on serverless platforms such as Cloud Run is ephemeral and may not be shared between instances. The chunked endpoint solves oversized single-request uploads; it does **not** make local filesystem storage durable. For reliable production media storage on Cloud Run, configure a persistent object-storage bucket and have the upload endpoint write to that bucket.

## Build limitation in supplied archive

The supplied ZIP did not include Android Gradle build files (`settings.gradle`, `build.gradle`, Gradle wrapper, or dependency declarations). Therefore this patch can be statically inspected and the Node endpoint tested, but the Android project cannot be compiled into an APK from this archive alone. Restore the original Android Studio Gradle project files to run a full Android build.
