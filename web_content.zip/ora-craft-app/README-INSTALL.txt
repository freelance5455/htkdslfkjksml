ORA CRAFT — Android installable web app (PWA)

This package is a Progressive Web App, not a signed APK.

To install on Android:
1. Upload all files in this folder to a static web host that serves HTTPS.
2. Open the hosted URL in Chrome on Android.
3. Open Chrome menu (⋮) and choose "Install app" or "Add to Home screen".
4. Confirm. ORA CRAFT will appear on your home screen and open in app-style mode.

For local testing, use a local web server. Service workers and PWA installation generally require HTTPS (localhost is allowed for development).

Features: manual follower growth tracking, caption/SEO helper, heuristic suspicious-follower review, CSV export.
No Instagram password, OTP, private follower scraping, fake-follower delivery, or automatic follow/like actions.
Data stays in the browser's local storage; it is not synced across devices.
