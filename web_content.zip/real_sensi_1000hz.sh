#!/system/bin/sh
# REAL SENSI — comandos visíveis nas imagens + solicitação de 1000 Hz
# Execute somente em um ambiente em que "settings" tenha permissão.
# O valor de 1000 Hz é solicitado ao Android; não aumenta fisicamente a taxa
# do painel se o hardware/driver não suportar esse modo.

set_cmd() {
    ns="$1"
    key="$2"
    value="$3"
    echo "[Real Sensi] settings put $ns $key $value"
    settings put "$ns" "$key" "$value"
}

echo "========================================"
echo " REAL SENSI — APLICAÇÃO"
echo "========================================"

# 1000 Hz solicitado
set_cmd system peak_refresh_rate 1000.0
set_cmd system min_refresh_rate 1000.0
set_cmd secure refresh_rate 1000
set_cmd secure refresh_rate_mode 1

# Comandos Secure visíveis nas imagens
set_cmd secure qs_auto_tiles "cast,night,saver"
set_cmd secure qs_show_brightness "null"
set_cmd secure reminder_exp_learned_hint_last_shown 0
set_cmd secure reminder_exp_learning_event_count 0
set_cmd secure reminder_exp_learning_time_elapsed 183478264
set_cmd secure screensaver_activate_on_dock 1
set_cmd secure screensaver_activate_on_sleep 1
set_cmd secure screensaver_components "com.google.android.deskclock/com.android.deskclock.Screensaver"
set_cmd secure screensaver_default_component "com.google.android.deskclock/com.android.deskclock.Screensaver"
set_cmd secure screensaver_enabled 1
set_cmd secure secure_frp_mode 0
set_cmd secure selected_input_method_subtype -1
set_cmd secure lockscreen.options "enable_facelock"
set_cmd secure long_press_timeout 100
set_cmd secure low_power_manual_activation_count 5
set_cmd secure low_power_warning_acknowledged 1
set_cmd secure manual_ringer_toggle_count 12
set_cmd secure masterLocationPackagePrefixBlacklist "com.google.com.semaphoremobile.zagat.android"
set_cmd secure masterLocationPackagePrefixWhitelist "com.google.android.gms"
set_cmd secure media_button_receiver "com.google.android.youtube/com.google.android.libraries.youtube.player.ui.mediasession.MediaButtonIntentReceiverProvider\$DefaultMediaButtonIntentReceiver"
set_cmd secure mock_location 0
set_cmd secure mount_play_not_snd 1
set_cmd secure mount_ums_autostart 0
set_cmd secure mount_ums_notify_enabled 1
set_cmd secure mount_ums_prompt 1
set_cmd secure mtklog_path "internal_sd"
set_cmd secure multi_press_timeout 100
set_cmd secure navigation_mode 2
set_cmd secure night_display_activated 0
set_cmd secure night_display_auto_mode 0
set_cmd secure night_display_color_temperature 2596
set_cmd secure night_display_last_activated_time "2023-01-05T11:11:05.287"
set_cmd secure notification_badging 0

echo "========================================"
echo " REAL SENSI — CONCLUÍDO"
echo "========================================"
