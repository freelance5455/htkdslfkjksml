WORK REGISTER - MULTI YEAR
1. Open index.html in Chrome.
2. Choose a year from 2027 to 2045.
3. Enter date and work amount, then Save Entry.
4. Local data is stored in this browser on this phone. Export CSV regularly as a backup.
Google Drive auto-sync is not active until Google OAuth Client ID and HTTPS hosting are configured.
