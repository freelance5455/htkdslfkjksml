# Loop Messenger Android project

This project wraps the current Loop HTML preview in an Android WebView. It is **not** the complete real-time messaging service: backend deployment and connecting the app to it are separate work. Do not treat local preview messages as messages delivered to other people.

## Build without owning a computer (GitHub Actions)

This project includes `.github/workflows/build-apk.yml`. GitHub's hosted runner can compile a debug APK in the cloud.

1. On your Android phone, download and extract `LoopAndroid-project.zip` using your file manager.
2. Sign in to GitHub in your browser and create a **private** repository named `loop-android`.
3. Upload the **contents** of the extracted `LoopAndroid` folder to the repository root. Include hidden files/folders such as `.github/workflows/build-apk.yml`. If the mobile upload interface does not show hidden folders, use GitHub's web editor to create `.github/workflows/build-apk.yml` and paste in the workflow from this project.
4. Open the repository's **Actions** tab and select **Build Loop APK**. Tap **Run workflow** if it has not started automatically.
5. Wait for the run to finish successfully. Open that run, scroll to **Artifacts**, and download `Loop-Messenger-debug-APK`. Extract the downloaded artifact ZIP; it contains `app-debug.apk`.
6. Tap `app-debug.apk` to install. Android may ask you to allow installs from your browser or file manager. Only enable that permission for the app you are using to install, and disable it afterward.

GitHub may require email verification or account setup. Workflow minutes and artifact retention are subject to GitHub's current account limits. Keep the repository private if you do not want to publish the source.

## Local build (if Android Studio is available)

Requires JDK 17 and Gradle 8.9:

```sh
gradle assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`.

## Current limits

- Android WebView shell and bundled HTML preview.
- Local preview storage only; no real cross-device messaging is connected yet.
- OTP, email verification, production authentication, E2EE, secure media storage, push notifications, WebRTC calls, group backend, and complete admin tools are not implemented in this Android shell.
- The generated debug APK is unsigned with a release key (Android debug-signed only). Do not distribute it as a production release.
