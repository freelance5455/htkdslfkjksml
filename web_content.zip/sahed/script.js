
    /* =========================================
       DATABASE SETTINGS
    ========================================= */

    const DATABASE_NAME = "OfflineDataCollection";

    const DATABASE_VERSION = 1;

    const STORE_NAME = "people";

    let database;


    /* =========================================
       OPEN DATABASE
    ========================================= */

    function openDatabase() {

        return new Promise((resolve, reject) => {

            const request = indexedDB.open(
                DATABASE_NAME,
                DATABASE_VERSION
            );


            request.onupgradeneeded = function(event) {

                const db = event.target.result;


                if (!db.objectStoreNames.contains(STORE_NAME)) {

                    const store = db.createObjectStore(
                        STORE_NAME,
                        {
                            keyPath: "id",
                            autoIncrement: true
                        }
                    );


                    store.createIndex(
                        "name",
                        "name",
                        {
                            unique: false
                        }
                    );


                    store.createIndex(
                        "village",
                        "village",
                        {
                            unique: false
                        }
                    );


                    store.createIndex(
                        "mobile",
                        "mobile",
                        {
                            unique: false
                        }
                    );

                }

            };


            request.onsuccess = function(event) {

                database = event.target.result;

                resolve(database);

            };


            request.onerror = function() {

                reject(request.error);

            };

        });

    }


    /* =========================================
       SAVE DATA
    ========================================= */

    function saveData(data) {

        return new Promise((resolve, reject) => {

            const transaction =
                database.transaction(
                    STORE_NAME,
                    "readwrite"
                );


            const store =
                transaction.objectStore(
                    STORE_NAME
                );


            let request;


            if (data.id) {

                request = store.put(data);

            } else {

                request = store.add(data);

            }


            request.onsuccess = function() {

                resolve(request.result);

            };


            request.onerror = function() {

                reject(request.error);

            };

        });

    }


    /* =========================================
       GET ALL DATA
    ========================================= */

    function getAllData() {

        return new Promise((resolve, reject) => {

            const transaction =
                database.transaction(
                    STORE_NAME,
                    "readonly"
                );


            const store =
                transaction.objectStore(
                    STORE_NAME
                );


            const request = store.getAll();


            request.onsuccess = function() {

                resolve(request.result);

            };


            request.onerror = function() {

                reject(request.error);

            };

        });

    }


    /* =========================================
       GET ONE DATA
    ========================================= */

    function getOneData(id) {

        return new Promise((resolve, reject) => {

            const transaction =
                database.transaction(
                    STORE_NAME,
                    "readonly"
                );


            const store =
                transaction.objectStore(
                    STORE_NAME
                );


            const request =
                store.get(Number(id));


            request.onsuccess = function() {

                resolve(request.result);

            };


            request.onerror = function() {

                reject(request.error);

            };

        });

    }


    /* =========================================
       DELETE DATA
    ========================================= */

    function deleteData(id) {

        return new Promise((resolve, reject) => {

            const transaction =
                database.transaction(
                    STORE_NAME,
                    "readwrite"
                );


            const store =
                transaction.objectStore(
                    STORE_NAME
                );


            const request =
                store.delete(Number(id));


            request.onsuccess = function() {

                resolve();

            };


            request.onerror = function() {

                reject(request.error);

            };

        });

    }


    /* =========================================
       DELETE ALL
    ========================================= */

    function deleteAllData() {

        return new Promise((resolve, reject) => {

            const transaction =
                database.transaction(
                    STORE_NAME,
                    "readwrite"
                );


            const store =
                transaction.objectStore(
                    STORE_NAME
                );


            const request =
                store.clear();


            request.onsuccess = function() {

                resolve();

            };


            request.onerror = function() {

                reject(request.error);

            };

        });

    }


    /* =========================================
       SHOW DATA
    ========================================= */

    async function displayData() {

        const allData = await getAllData();


        document.getElementById(
            "recordCount"
        ).textContent =
            allData.length.toLocaleString();


        const searchText =
            document
            .getElementById("search")
            .value
            .toLowerCase()
            .trim();


        let filteredData;


        if (searchText === "") {

            filteredData = allData;

        } else {

            filteredData =
                allData.filter(function(item) {

                    return (

                        String(item.name)
                        .toLowerCase()
                        .includes(searchText)

                        ||

                        String(item.fatherHusband)
                        .toLowerCase()
                        .includes(searchText)

                        ||

                        String(item.homeName)
                        .toLowerCase()
                        .includes(searchText)

                        ||

                        String(item.village)
                        .toLowerCase()
                        .includes(searchText)

                        ||

                        String(item.up)
                        .toLowerCase()
                        .includes(searchText)

                        ||

                        String(item.noCc)
                        .toLowerCase()
                        .includes(searchText)

                        ||

                        String(item.mobile)
                        .toLowerCase()
                        .includes(searchText)

                    );

                });

        }


        /*
            বড় data হলে পুরো ৫ লক্ষ record
            একসাথে table-এ দেখাব না।

            সর্বশেষ 200টি record দেখাব।
        */

        filteredData =
            filteredData
            .sort(function(a, b) {

                return b.id - a.id;

            })
            .slice(0, 200);


        const table =
            document.getElementById(
                "dataTable"
            );


        table.innerHTML = "";


        filteredData.forEach(function(item) {

            const row =
                document.createElement("tr");


            row.innerHTML = `

                <td>${item.id}</td>

                <td>${escapeHTML(item.name)}</td>

                <td>${escapeHTML(item.fatherHusband)}</td>

                <td>${escapeHTML(item.homeName)}</td>

                <td>${escapeHTML(item.village)}</td>

                <td>${escapeHTML(item.up)}</td>

                <td>${escapeHTML(item.noCc)}</td>

                <td>${escapeHTML(item.mobile)}</td>

                <td>

                    <button
                        class="edit-btn"
                        onclick="editRecord(${item.id})"
                    >
                        Edit
                    </button>

                    <button
                        class="delete-btn"
                        onclick="deleteRecordConfirm(${item.id})"
                    >
                        Delete
                    </button>

                </td>

            `;


            table.appendChild(row);

        });

    }


    /* =========================================
       ESCAPE HTML
    ========================================= */

    function escapeHTML(value) {

        return String(value || "")
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#039;");

    }


    /* =========================================
       FORM SUBMIT
    ========================================= */

    document
    .getElementById("dataForm")
    .addEventListener(
        "submit",
        async function(event) {

            event.preventDefault();


            const editId =
                document
                .getElementById("editId")
                .value;


            const data = {

                name:
                    document
                    .getElementById("name")
                    .value
                    .trim(),


                fatherHusband:
                    document
                    .getElementById("fatherHusband")
                    .value
                    .trim(),


                homeName:
                    document
                    .getElementById("homeName")
                    .value
                    .trim(),


                village:
                    document
                    .getElementById("village")
                    .value
                    .trim(),


                up:
                    document
                    .getElementById("up")
                    .value
                    .trim(),


                noCc:
                    document
                    .getElementById("noCc")
                    .value
                    .trim(),


                mobile:
                    document
                    .getElementById("mobile")
                    .value
                    .trim(),


                updatedAt:
                    new Date().toISOString()

            };


            if (editId) {

                data.id =
                    Number(editId);


                await saveData(data);


                showMessage(
                    "Data updated successfully."
                );

            } else {

                data.createdAt =
                    new Date().toISOString();


                await saveData(data);


                showMessage(
                    "Data saved on this mobile."
                );

            }


            document
            .getElementById("dataForm")
            .reset();


            document
            .getElementById("editId")
            .value = "";


            document
            .getElementById("saveButton")
            .textContent = "Save Data";


            await displayData();

        }
    );


    /* =========================================
       EDIT RECORD
    ========================================= */

    async function editRecord(id) {

        const data =
            await getOneData(id);


        if (!data) {

            return;

        }


        document
        .getElementById("editId")
        .value = data.id;


        document
        .getElementById("name")
        .value = data.name;


        document
        .getElementById("fatherHusband")
        .value = data.fatherHusband;


        document
        .getElementById("homeName")
        .value = data.homeName;


        document
        .getElementById("village")
        .value = data.village;


        document
        .getElementById("up")
        .value = data.up;


        document
        .getElementById("noCc")
        .value = data.noCc;


        document
        .getElementById("mobile")
        .value = data.mobile;


        document
        .getElementById("saveButton")
        .textContent = "Update Data";


        window.scrollTo({
            top: 0,
            behavior: "smooth"
        });

    }


    /* =========================================
       DELETE RECORD
    ========================================= */

    async function deleteRecordConfirm(id) {

        const confirmDelete =
            confirm(
                "Are you sure you want to delete this record?"
            );


        if (!confirmDelete) {

            return;

        }


        await deleteData(id);


        showMessage(
            "Record deleted."
        );


        await displayData();

    }


    /* =========================================
       SEARCH
    ========================================= */

    document
    .getElementById("search")
    .addEventListener(
        "input",
        displayData
    );


    /* =========================================
       DELETE ALL
    ========================================= */

    document
    .getElementById("deleteAllButton")
    .addEventListener(
        "click",
        async function() {

            const allData =
                await getAllData();


            if (allData.length === 0) {

                alert(
                    "There is no data."
                );

                return;

            }


            const confirmation =
                confirm(
                    "WARNING!\n\n" +
                    "You are going to delete ALL " +
                    allData.length.toLocaleString() +
                    " records.\n\n" +
                    "This cannot be undone.\n\n" +
                    "Continue?"
                );


            if (!confirmation) {

                return;

            }


            await deleteAllData();


            showMessage(
                "All data deleted."
            );


            await displayData();

        }
    );


    /* =========================================
       EXPORT CSV
    ========================================= */

    document
    .getElementById("exportButton")
    .addEventListener(
        "click",
        async function() {

            const allData =
                await getAllData();


            if (allData.length === 0) {

                alert(
                    "There is no data to export."
                );

                return;

            }


            let csv = "";


            csv +=
                "ID," +
                "Name," +
                "Father/Husband Name," +
                "Home Name," +
                "Village," +
                "UP," +
                "N/O CC," +
                "Mobile No," +
                "Created At\n";


            allData.forEach(function(item) {

                csv +=
                    csvValue(item.id) + "," +
                    csvValue(item.name) + "," +
                    csvValue(item.fatherHusband) + "," +
                    csvValue(item.homeName) + "," +
                    csvValue(item.village) + "," +
                    csvValue(item.up) + "," +
                    csvValue(item.noCc) + "," +
                    csvValue(item.mobile) + "," +
                    csvValue(item.createdAt) +
                    "\n";

            });


            const blob =
                new Blob(
                    ["\ufeff" + csv],
                    {
                        type:
                            "text/csv;charset=utf-8;"
                    }
                );


            const url =
                URL.createObjectURL(blob);


            const link =
                document.createElement("a");


            link.href = url;


            link.download =
                "data_backup_" +
                new Date()
                .toISOString()
                .slice(0, 10) +
                ".csv";


            link.click();


            URL.revokeObjectURL(url);

        }
    );


    /* =========================================
       CSV VALUE
    ========================================= */

    function csvValue(value) {

        return '"' +
            String(value || "")
            .replace(/"/g, '""') +
            '"';

    }


    /* =========================================
       MESSAGE
    ========================================= */

    function showMessage(message) {

        const element =
            document.getElementById(
                "message"
            );


        element.textContent =
            message;


        setTimeout(function() {

            element.textContent = "";

        }, 2500);

    }


    /* =========================================
       START DATABASE
    ========================================= */

    openDatabase()
    .then(function() {

        displayData();

    })
    .catch(function(error) {

        alert(
            "Database could not be opened.\n\n" +
            error
        );

    });




    /* =========================================
   BACKUP DATA
========================================= */

document
.getElementById("backupButton")
.addEventListener("click", async function () {

    const allData = await getAllData();

    if (allData.length === 0) {

        alert("There is no data to backup.");

        return;
    }


    const backup = {

        backupVersion: 1,

        createdAt:
            new Date().toISOString(),

        totalRecords:
            allData.length,

        records:
            allData

    };


    const json =
        JSON.stringify(
            backup,
            null,
            2
        );


    const blob =
        new Blob(
            [json],
            {
                type:
                    "application/json"
            }
        );


    const url =
        URL.createObjectURL(blob);


    const link =
        document.createElement("a");


    link.href = url;


    link.download =
        "offline_backup_" +
        new Date()
        .toISOString()
        .slice(0, 10) +
        ".json";


    link.click();


    URL.revokeObjectURL(url);


    showMessage(
        allData.length.toLocaleString() +
        " records backed up successfully."
    );

});


/* =========================================
   RESTORE BUTTON
========================================= */

document
.getElementById("restoreButton")
.addEventListener("click", function () {

    document
    .getElementById("restoreFile")
    .click();

});


/* =========================================
   RESTORE FILE
========================================= */

document
.getElementById("restoreFile")
.addEventListener(
    "change",
    async function (event) {

        const file =
            event.target.files[0];


        if (!file) {

            return;

        }


        try {

            const text =
                await file.text();


            const backup =
                JSON.parse(text);


            if (
                !backup.records ||
                !Array.isArray(
                    backup.records
                )
            ) {

                alert(
                    "Invalid backup file."
                );

                return;

            }


            const records =
                backup.records;


            const confirmation =
                confirm(

                    "Backup contains " +
                    records.length
                    .toLocaleString() +
                    " records.\n\n" +

                    "Restore these records?"

                );


            if (!confirmation) {

                return;

            }


            let restored = 0;


            for (
                const record of records
            ) {

                await saveData(record);

                restored++;

            }


            await displayData();


            showMessage(

                restored
                .toLocaleString() +
                " records restored successfully."

            );


        }
        catch (error) {

            alert(

                "Restore failed.\n\n" +
                error.message

            );

        }


        event.target.value = "";

    }
);