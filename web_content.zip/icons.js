window.FLAG='<path d="M3 6q6-3 12 0v10q-6-3-12 0z" fill="#f65314"/><path d="M17 6.5q6-3 12 0v10q-6-3-12 0z" fill="#7cbb00"/><path d="M3 18q6-3 12 0v10q-6-3-12 0z" fill="#00a1f1"/><path d="M17 18.5q6-3 12 0v10q-6-3-12 0z" fill="#ffbb00"/>';
(function(){
const mini=(x,y,s)=>`<g transform="translate(${x} ${y}) scale(${s})">${FLAG}</g>`;
const FOLD_BACK='<path d="M2 8.5A2 2 0 0 1 4 6.5h8l3 3h13a2 2 0 0 1 2 2V26a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2z" fill="#e6b53a" stroke="#a87a12"/>';
const FOLD_FRONT='<path d="M5 13h25l-2.2 14.2a1 1 0 0 1-1 .8H2.6z" fill="url(#gFold)" stroke="#a87a12" stroke-width=".8"/>';
const DRIVE='<path d="M4 11h24l2 7v6a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2v-6z" fill="url(#gDrive)" stroke="#4d4d4d"/><path d="M2 18h28" stroke="#888"/><rect x="5" y="20.5" width="11" height="2" rx="1" fill="#555"/><circle cx="26" cy="21.5" r="1.4" fill="#2fd12f"/>';
const BIN='<path d="M7 9h18l-2 19a2 2 0 0 1-2 2H11a2 2 0 0 1-2-2z" fill="url(#gBin)" stroke="#4a6585"/><path d="M12 13l1 14M16 13v14M20 13l-1 14" stroke="#7d96b6" fill="none"/><circle cx="16" cy="20" r="3.4" fill="none" stroke="#24a03a" stroke-width="1.6" stroke-dasharray="4.5 1.5"/>';
const RIM='<ellipse cx="16" cy="9" rx="10" ry="2.6" fill="#dbe6f2" stroke="#4a6585"/>';
let calcBtns='';for(let r=0;r<4;r++)for(let c=0;c<3;c++)calcBtns+=`<rect x="${9+c*5}" y="${13+r*4}" width="3.6" height="2.8" rx=".5" fill="${c===2?'#c84a3a':'#fff'}" stroke="#777" stroke-width=".4"/>`;
let petals='';for(let i=0;i<8;i++)petals+=`<ellipse cx="16" cy="7.5" rx="3" ry="5" fill="#ff6aa8" transform="rotate(${i*45} 16 13)"/>`;
window.IC={
pc:'<rect x="2" y="4" width="21" height="16" rx="1.5" fill="#e3e6ee" stroke="#4b5263"/><rect x="4" y="6" width="17" height="12" fill="url(#gScr)"/><path d="M4 6h17L4 14z" fill="#fff" opacity=".2"/><path d="M9 20h7l1.5 4h-10z" fill="#c3c8d3" stroke="#4b5263" stroke-width=".7"/><rect x="5" y="24" width="15" height="3" rx="1" fill="#d6dae3" stroke="#4b5263" stroke-width=".7"/><rect x="23" y="9" width="7" height="19" rx="1" fill="#eceef3" stroke="#4b5263"/><rect x="24.5" y="11" width="4" height="1.5" fill="#7a8292"/><rect x="24.5" y="14" width="4" height="1.5" fill="#7a8292"/><circle cx="26.5" cy="24.5" r="1" fill="#2fd12f"/>',
binE:BIN+RIM,
binF:BIN+RIM+'<path d="M9 9l2-6 5 2.5 3.5-3.5 2.5 4 2-1 .5 4z" fill="#fff" stroke="#888" stroke-width=".7"/><path d="M13 5l6 1.5" stroke="#bbb" stroke-width=".7"/>',
folder:FOLD_BACK+FOLD_FRONT,
winfolder:FOLD_BACK+FOLD_FRONT+mini(11,12,.42),
docs:FOLD_BACK+'<path d="M8 4h12l3 3v14H8z" fill="#fff" stroke="#888"/><path d="M11 9h8M11 12h8" stroke="#aab"/>'+FOLD_FRONT,
drive:DRIVE,
driveC:DRIVE+mini(4,2,.33),
cdrive:DRIVE+'<circle cx="16" cy="9" r="7" fill="url(#gCd)" stroke="#888"/><circle cx="16" cy="9" r="1.8" fill="#fff" stroke="#888"/>',
 kiva:'<image href="./img/kiva.png" x="1" y="1" width="30" height="30" preserveAspectRatio="xMidYMid meet"/>',
 memz:'<rect x="2" y="7" width="28" height="18" rx="1" fill="#111" stroke="#e01b1b" stroke-width="2"/><rect x="4.5" y="9.5" width="23" height="13" fill="none" stroke="#e01b1b" stroke-width=".6" opacity=".6"/><text x="16" y="19.3" text-anchor="middle" font-family="Arial Black,Arial,sans-serif" font-weight="900" font-size="7.6" fill="#ff3030">MEMZ</text>',
exe:'<rect x="3" y="5" width="26" height="22" rx="1.5" fill="#fff" stroke="#3f5f9f"/><rect x="3" y="5" width="26" height="5" fill="url(#gBlue)"/><rect x="6" y="13" width="8" height="10" fill="#d7e3f7"/><path d="M16 14h10M16 17h10M16 20h7" stroke="#8aa0c8"/>',
sysfile:'<path d="M7 3h13l6 6v20H7z" fill="#fff" stroke="#7a8291"/><path d="M20 3v6h6" fill="#e5e8ee" stroke="#7a8291"/><circle cx="16" cy="19" r="5" fill="none" stroke="#6a7484" stroke-width="2.4" stroke-dasharray="2.2 1.6"/>',
txt:'<path d="M7 3h13l6 6v20H7z" fill="#fff" stroke="#7a8291"/><path d="M20 3v6h6" fill="#e5e8ee" stroke="#7a8291"/><path d="M10 13h12M10 16h12M10 19h12M10 22h9" stroke="#9aa3b5"/>',
notepad:'<path d="M7 5h18v24H7z" fill="#fff" stroke="#4a6fb5"/><rect x="7" y="3" width="18" height="4" fill="#4a86d8" stroke="#2a4f95"/><path d="M10 11h12M10 14h12M10 17h12M10 20h12M10 23h8" stroke="#93a7cf"/>',
calc:'<rect x="6" y="2" width="20" height="28" rx="2" fill="#d9d9d4" stroke="#555"/><rect x="8.5" y="4.5" width="15" height="6" fill="#c9e3c0" stroke="#666" stroke-width=".6"/>'+calcBtns,
paint:'<path d="M16 3C8 3 3 8.5 3 15s4.5 12 11 12c2 0 2.5-1.5 2-3s0-3 2-3h4c4 0 7-3 7-7C29 8 23 3 16 3z" fill="#f2e2c3" stroke="#8a6a3a"/><circle cx="10" cy="12" r="2.2" fill="#e33"/><circle cx="15" cy="8.5" r="2.2" fill="#fc3"/><circle cx="21" cy="10" r="2.2" fill="#3a3"/><circle cx="9.5" cy="18.5" r="2.2" fill="#36f"/><path d="M30 2L18 18l-1.5 3 3-1.5L31 4z" fill="#8a5a2b" stroke="#4a2a0b" stroke-width=".6"/>',
cmd:'<rect x="2" y="4" width="28" height="24" rx="1.5" fill="#111" stroke="#666"/><rect x="2" y="4" width="28" height="5" fill="url(#gBlue)"/><text x="5" y="20" font-family="Courier New,monospace" font-size="8" font-weight="bold" fill="#ccc">C:\\&gt;_</text>',
ie:'<circle cx="16" cy="16" r="10" fill="url(#gBlue)"/><text x="16" y="23" text-anchor="middle" font-family="Times New Roman,serif" font-style="italic" font-weight="bold" font-size="22" fill="#fff">e</text><ellipse cx="16" cy="15" rx="14.5" ry="6" fill="none" stroke="#f2a20c" stroke-width="2.2" transform="rotate(-25 16 16)"/>',
mine:'<rect x="2" y="2" width="28" height="28" fill="#c0c0c0" stroke="#7b7b7b"/><path d="M16 6v20M6 16h20M9 9l14 14M23 9L9 23" stroke="#000" stroke-width="2"/><circle cx="16" cy="16" r="7" fill="#000"/><rect x="12.5" y="12.5" width="3" height="3" fill="#fff"/>',
download:'<rect x="3" y="20" width="26" height="8" rx="2" fill="#d5dbe6" stroke="#55607a"/><circle cx="25" cy="24" r="1.3" fill="#2fd12f"/><path d="M12 3h8v9h5l-9 9-9-9h5z" fill="url(#gGreen)" stroke="#1b6a1b"/>',
taskmgr:'<rect x="2" y="4" width="28" height="20" rx="1.5" fill="#000" stroke="#666"/><path d="M4 20l5-6 4 3 5-8 4 5 4-4 2 2" fill="none" stroke="#2fff2f" stroke-width="1.5"/><path d="M11 24h10l1.5 4h-13z" fill="#bbb"/>',
run:'<rect x="2" y="6" width="22" height="20" rx="1" fill="#fff" stroke="#3f5f9f"/><rect x="2" y="6" width="22" height="4" fill="url(#gBlue)"/><path d="M14 16h8v-4l8 7-8 7v-4h-8z" fill="url(#gGreen)" stroke="#1b6a1b" stroke-width=".7"/>',
control:'<rect x="3" y="4" width="26" height="22" rx="2" fill="#e9ecf2" stroke="#4b5263"/><rect x="6" y="8" width="9" height="7" fill="url(#gScr)"/><circle cx="22" cy="11.5" r="3.5" fill="#f2b632" stroke="#a37510"/><rect x="6" y="18" width="20" height="3" rx="1.5" fill="#9aa3b5"/><rect x="15" y="17" width="3" height="5" fill="#2a5bc0"/>',
help:'<circle cx="16" cy="16" r="13" fill="url(#gBlue)" stroke="#0a3a9c"/><text x="16" y="22.5" text-anchor="middle" font-family="Arial" font-weight="bold" font-size="18" fill="#fff">?</text>',
question:'<circle cx="16" cy="16" r="14" fill="#fff" stroke="#2a5bc0" stroke-width="2"/><text x="16" y="23" text-anchor="middle" font-family="Arial" font-weight="bold" font-size="19" fill="#2a5bc0">?</text>',
logoff:'<rect x="4" y="4" width="24" height="24" rx="4" fill="#f2b632" stroke="#a37510"/><path d="M12 11l-5 5 5 5M7 16h12M17 9h6v14h-6" fill="none" stroke="#fff" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/>',
power:'<rect x="4" y="4" width="24" height="24" rx="4" fill="url(#gRed)" stroke="#8a1a08"/><path d="M11.5 10.5a8 8 0 1 0 9 0" fill="none" stroke="#fff" stroke-width="2.6" stroke-linecap="round"/><path d="M16 7v9" stroke="#fff" stroke-width="2.6" stroke-linecap="round"/>',
restart:'<rect x="4" y="4" width="24" height="24" rx="4" fill="url(#gGreen)" stroke="#1b6a1b"/><path d="M22 16a6 6 0 1 1-2-4.5" fill="none" stroke="#fff" stroke-width="2.6" stroke-linecap="round"/><path d="M17 8h5v5" fill="none" stroke="#fff" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"/>',
standby:'<rect x="4" y="4" width="24" height="24" rx="4" fill="#f2b632" stroke="#a37510"/><path d="M19 9a7 7 0 1 0 5 11a6 6 0 0 1-5-11z" fill="#fff"/>',
error:'<circle cx="16" cy="16" r="14" fill="url(#gRed)" stroke="#8a1a08"/><path d="M10.5 10.5l11 11M21.5 10.5l-11 11" stroke="#fff" stroke-width="3.2" stroke-linecap="round"/>',
warn:'<path d="M16 2.5L30.5 28h-29z" fill="#ffd21a" stroke="#9a7a00" stroke-linejoin="round"/><path d="M16 11v8" stroke="#000" stroke-width="3" stroke-linecap="round"/><circle cx="16" cy="23.5" r="1.8"/>',
info:'<circle cx="16" cy="16" r="14" fill="#fff" stroke="#2a5bc0" stroke-width="2"/><circle cx="16" cy="9.5" r="2.2" fill="#2a5bc0"/><path d="M16 14v10" stroke="#2a5bc0" stroke-width="3.4" stroke-linecap="round"/>',
user:'<rect width="32" height="32" fill="#3d8ed8"/><path d="M0 26q16-6 32 0v6H0z" fill="#4caf3a"/><path d="M16 14v14" stroke="#2c7a22" stroke-width="2"/>'+petals+'<circle cx="16" cy="13" r="3.6" fill="#ffd21a"/>',
flag:FLAG,
back:'<circle cx="16" cy="16" r="14" fill="url(#gGreen)" stroke="#1b6a1b"/><path d="M19 9l-7 7 7 7" fill="none" stroke="#fff" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"/>',
fwd:'<circle cx="16" cy="16" r="14" fill="url(#gGreen)" stroke="#1b6a1b"/><path d="M13 9l7 7-7 7" fill="none" stroke="#fff" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"/>',
up:FOLD_BACK+FOLD_FRONT+'<path d="M16 26V15m-5 5l5-5 5 5" fill="none" stroke="#1b8a1b" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>',
search:'<circle cx="13" cy="13" r="8" fill="#cfe6ff" stroke="#3a5a8a" stroke-width="2.5"/><path d="M19 19l9 9" stroke="#8a5a2b" stroke-width="4" stroke-linecap="round"/>',
go:'<rect x="3" y="3" width="26" height="26" rx="4" fill="url(#gGreen)" stroke="#1b6a1b"/><path d="M9 16h12m-5-6l6 6-6 6" fill="none" stroke="#fff" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>',
clock:'<circle cx="16" cy="16" r="13" fill="#fff" stroke="#2a5bc0" stroke-width="2"/><path d="M16 8v8l5 4" stroke="#000" stroke-width="2" fill="none" stroke-linecap="round"/>',
display:'<rect x="3" y="4" width="26" height="19" rx="1.5" fill="#e3e6ee" stroke="#4b5263"/><rect x="5" y="6" width="22" height="15" fill="url(#gScr)"/><path d="M5 18q11-6 22 0v3H5z" fill="#55a52a"/><rect x="11" y="24" width="10" height="4" fill="#c3c8d3" stroke="#4b5263"/>',
volume:'<path d="M4 12h5l7-6v20l-7-6H4z" fill="#fff" stroke="#333"/><path d="M20 11q3 5 0 10M23 8q6 8 0 16" fill="none" stroke="#fff" stroke-width="2"/>',
net:'<rect x="3" y="5" width="14" height="11" fill="#bcd6ff" stroke="#fff" stroke-width="1.5"/><rect x="15" y="15" width="14" height="11" fill="#bcd6ff" stroke="#fff" stroke-width="1.5"/>',
kbd:'<rect x="1" y="9" width="30" height="15" rx="2" fill="#f4f4f4" stroke="#222"/><path d="M4 13h3M9 13h3M14 13h3M19 13h3M24 13h4M4 17h3M9 17h3M14 17h3M19 17h3M24 17h4M8 21h16" stroke="#333" stroke-width="2"/>',
desk:'<rect x="3" y="5" width="26" height="20" rx="1" fill="url(#gScr)" stroke="#fff"/><rect x="6" y="8" width="5" height="4" fill="#fff"/><rect x="6" y="14" width="5" height="4" fill="#ffd21a"/>',
users:'<circle cx="16" cy="10" r="6" fill="#f2c29a" stroke="#8a5a3a"/><path d="M5 29q11-18 22 0z" fill="#2a5bc0" stroke="#0a2a8f"/>',
addrem:'<rect x="4" y="8" width="20" height="18" fill="#c99a5a" stroke="#6a4a1a"/><path d="M4 8l4-5h20l-4 5M24 8l4-5v18l-4 5" fill="#e2b77a" stroke="#6a4a1a"/><circle cx="24" cy="24" r="6" fill="url(#gGreen)" stroke="#1b6a1b"/><path d="M21 24h6M24 21v6" stroke="#fff" stroke-width="2"/>'
};
window.svg=n=>`<svg class="i" viewBox="0 0 32 32" aria-hidden="true">${IC[n]||IC.exe}</svg>`;
window.ic=(n,s)=>`<span class="ic" style="width:${s}px;height:${s}px">${svg(n)}</span>`;
window.S_MIN='<svg viewBox="0 0 11 11"><rect x="1" y="8" width="6" height="2.4" fill="#fff"/></svg>';
window.S_MAX='<svg viewBox="0 0 11 11"><rect x="1.2" y="1.2" width="8.6" height="8.6" fill="none" stroke="#fff" stroke-width="1.4"/><rect x="1" y="1" width="9" height="2.6" fill="#fff"/></svg>';
window.S_X='<svg viewBox="0 0 11 11"><path d="M1.5 1.5l8 8M9.5 1.5l-8 8" stroke="#fff" stroke-width="2"/></svg>';
window.CUR_ARROW='<svg viewBox="0 0 13 21" width="13" height="21"><path d="M.5.5v16.5l4-4 3 7 2.3-1-3-6.8h5.6z" fill="#fff" stroke="#000" stroke-linejoin="round"/></svg>';
window.CUR_BUSY='<svg viewBox="0 0 13 21" width="13" height="21"><path d="M1 .5h11v2c0 4-4 6-4 8s4 4 4 8v2H1v-2c0-4 4-6 4-8s-4-4-4-8z" fill="#fff" stroke="#000"/><path d="M3 4h7l-3.5 5zM3.5 18.5l3-4 3 4z" fill="#d9a800"/></svg>';
window.FACE={
ok:'<svg viewBox="0 0 20 20"><circle cx="10" cy="10" r="8.5" fill="#ff0" stroke="#000"/><circle cx="7" cy="8" r="1.2"/><circle cx="13" cy="8" r="1.2"/><path d="M6 12q4 4 8 0" fill="none" stroke="#000" stroke-width="1.3"/></svg>',
dead:'<svg viewBox="0 0 20 20"><circle cx="10" cy="10" r="8.5" fill="#ff0" stroke="#000"/><path d="M5.5 6.5l3 3m0-3l-3 3M11.5 6.5l3 3m0-3l-3 3" stroke="#000" stroke-width="1.2"/><path d="M6 15q4-4 8 0" fill="none" stroke="#000" stroke-width="1.3"/></svg>',
cool:'<svg viewBox="0 0 20 20"><circle cx="10" cy="10" r="8.5" fill="#ff0" stroke="#000"/><path d="M3 7.5h14l-1 2.5h-4.5l-1.5-1.5L8.5 10H4z"/><path d="M6 12.5q4 3.5 8 0" fill="none" stroke="#000" stroke-width="1.3"/></svg>'
};
window.FLAG_SVG='<svg viewBox="0 0 16 16" width="14" height="14"><path d="M8 2v9" stroke="#000" stroke-width="1.5"/><path d="M8 2L3 5l5 3z" fill="#f00"/><path d="M4 13h8v1.5H4z"/></svg>';
window.MINE_SVG='<svg viewBox="0 0 16 16" width="14" height="14"><path d="M8 1v14M1 8h14M3 3l10 10M13 3L3 13" stroke="#000" stroke-width="1.4"/><circle cx="8" cy="8" r="4.5"/><rect x="6" y="6" width="2" height="2" fill="#fff"/></svg>';
})();
