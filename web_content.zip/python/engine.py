"""Шахматный движок на python-chess, построенный по алгоритмам Stockfish.

Поиск
    итеративное углубление, PVS (negamax), aspiration windows, MultiPV, таблица транспозиций
    (с «возрастом» и приоритетом глубины), mate-distance pruning, check/singular extensions,
    internal iterative reduction, razoring, reverse futility (static null move), null move
    с верификацией, ProbCut, futility, late move pruning, SEE-отсечения, LMR по таблице ln·ln
    (с поправками improving / cut-node / history), quiescence (SEE, delta, шахи), упорядочивание:
    TT-ход → хорошие взятия (SEE) → killers → counter-move → history + continuation history
    → плохие взятия. Менеджер времени (стабильность лучшего хода, падение оценки).

Оценка (классическая, как в Stockfish ≤ 11, с плавным переходом миттельшпиль → эндшпиль)
    материал + PST, мобильность, безопасность короля, угрозы, проходные/изолированные/сдвоенные/
    отсталые пешки (с кэшем пешечной структуры), форпосты, ладьи на линиях и 7-й, пространство,
    пара слонов, mop-up, масштабирование «ничейных» окончаний, затухание по правилу 50 ходов.

Прочее
    skill level как в Stockfish (pick_best по MultiPV), дебютная книга Polyglot, таблицы Syzygy,
    contempt, лимит узлов. Каждая возможность имеет свою настройку в Settings.

Силу по Эло подбирает settings_for_elo(); верхняя граница — MAX_ELO.
"""
from __future__ import annotations

import math
import os
import random
import time
from dataclasses import asdict, dataclass, field, fields
from typing import Callable, Dict, List, Optional, Tuple

import chess
import chess.polyglot

try:                                   # Syzygy нужен только если указан путь к таблицам
    import chess.syzygy as _syzygy
except Exception:                      # pragma: no cover
    _syzygy = None

# --------------------------------------------------------------------------- константы
MATE = 100_000
MATE_BOUND = MATE - 1000
TB_WIN = 50_000
TB_BOUND = TB_WIN - 1000
INF = 1_000_000
MAX_PLY = 96

MAX_ELO = 2500          # потолок по калибровке против Stockfish (см. README)
MIN_ELO = 100

EXACT, LOWER, UPPER = 0, 1, 2

PAWN, KNIGHT, BISHOP, ROOK, QUEEN, KING = chess.PAWN, chess.KNIGHT, chess.BISHOP, chess.ROOK, chess.QUEEN, chess.KING
# значения для SEE / упорядочивания (индекс — тип фигуры)
VAL = (0, 100, 325, 335, 500, 975, 20000)

_pc = chess.popcount
FILE_BB = chess.BB_FILES
RANK_BB = chess.BB_RANKS
BB_ALL = chess.BB_ALL
NOT_A = ~chess.BB_FILE_A & BB_ALL
NOT_H = ~chess.BB_FILE_H & BB_ALL
NULL = chess.Move.null()


# --------------------------------------------------------------------------- таблицы оценки
# Таблицы позиций (Michniewski). Первая строка — 8-я горизонталь (вид со стороны белых).
PST = {
    PAWN: [0, 0, 0, 0, 0, 0, 0, 0, 50, 50, 50, 50, 50, 50, 50, 50, 10, 10, 20, 30, 30, 20, 10, 10,
           5, 5, 10, 25, 25, 10, 5, 5, 0, 0, 0, 20, 20, 0, 0, 0, 5, -5, -10, 0, 0, -10, -5, 5,
           5, 10, 10, -20, -20, 10, 10, 5, 0, 0, 0, 0, 0, 0, 0, 0],
    KNIGHT: [-50, -40, -30, -30, -30, -30, -40, -50, -40, -20, 0, 0, 0, 0, -20, -40, -30, 0, 10, 15, 15, 10, 0, -30,
             -30, 5, 15, 20, 20, 15, 5, -30, -30, 0, 15, 20, 20, 15, 0, -30, -30, 5, 10, 15, 15, 10, 5, -30,
             -40, -20, 0, 5, 5, 0, -20, -40, -50, -40, -30, -30, -30, -30, -40, -50],
    BISHOP: [-20, -10, -10, -10, -10, -10, -10, -20, -10, 0, 0, 0, 0, 0, 0, -10, -10, 0, 5, 10, 10, 5, 0, -10,
             -10, 5, 5, 10, 10, 5, 5, -10, -10, 0, 10, 10, 10, 10, 0, -10, -10, 10, 10, 10, 10, 10, 10, -10,
             -10, 5, 0, 0, 0, 0, 5, -10, -20, -10, -10, -10, -10, -10, -10, -20],
    ROOK: [0, 0, 0, 0, 0, 0, 0, 0, 5, 10, 10, 10, 10, 10, 10, 5, -5, 0, 0, 0, 0, 0, 0, -5, -5, 0, 0, 0, 0, 0, 0, -5,
           -5, 0, 0, 0, 0, 0, 0, -5, -5, 0, 0, 0, 0, 0, 0, -5, -5, 0, 0, 0, 0, 0, 0, -5, 0, 0, 0, 5, 5, 0, 0, 0],
    QUEEN: [-20, -10, -10, -5, -5, -10, -10, -20, -10, 0, 0, 0, 0, 0, 0, -10, -10, 0, 5, 5, 5, 5, 0, -10,
            -5, 0, 5, 5, 5, 5, 0, -5, 0, 0, 5, 5, 5, 5, 0, -5, -10, 5, 5, 5, 5, 5, 0, -10,
            -10, 0, 5, 0, 0, 0, 0, -10, -20, -10, -10, -5, -5, -10, -10, -20],
    KING: [-30, -40, -40, -50, -50, -40, -40, -30] * 4 + [-20, -30, -30, -40, -40, -30, -30, -20,
           -10, -20, -20, -20, -20, -20, -20, -10, 20, 20, 0, 0, 0, 0, 20, 20, 20, 30, 10, 0, 0, 10, 30, 20],
}
KING_END = [-50, -40, -30, -20, -20, -30, -40, -50, -30, -20, -10, 0, 0, -10, -20, -30, -30, -10, 20, 30, 30, 20, -10, -30,
            -30, -10, 30, 40, 40, 30, -10, -30, -30, -10, 30, 40, 40, 30, -10, -30, -30, -10, 20, 30, 30, 20, -10, -30,
            -30, -30, 0, 0, 0, 0, -30, -30, -50, -30, -30, -30, -30, -30, -30, -50]

MAT_MG = (0, 100, 320, 335, 500, 950, 0)
MAT_EG = (0, 125, 300, 330, 540, 990, 0)
PAWN_EG_RANK = (0, 0, 2, 6, 14, 28, 50, 0)

# [цвет][тип][клетка] — материал + PST для миттельшпиля и эндшпиля
MGT = [[[0] * 64 for _ in range(7)] for _ in range(2)]
EGT = [[[0] * 64 for _ in range(7)] for _ in range(2)]
MGT_NOPST = [[[0] * 64 for _ in range(7)] for _ in range(2)]   # когда PST выключены — только материал
EGT_NOPST = [[[0] * 64 for _ in range(7)] for _ in range(2)]
for _c in (0, 1):
    for _sq in range(64):
        _r, _f = _sq >> 3, _sq & 7
        _idx = (7 - _r) * 8 + _f if _c else _r * 8 + _f
        _rr = _r if _c else 7 - _r
        for _pt in range(1, 7):
            MGT_NOPST[_c][_pt][_sq] = MAT_MG[_pt]
            EGT_NOPST[_c][_pt][_sq] = MAT_EG[_pt]
            if _pt == KING:
                MGT[_c][_pt][_sq] = PST[KING][_idx]
                EGT[_c][_pt][_sq] = KING_END[_idx]
            elif _pt == PAWN:
                MGT[_c][_pt][_sq] = MAT_MG[_pt] + PST[PAWN][_idx]
                EGT[_c][_pt][_sq] = MAT_EG[_pt] + PAWN_EG_RANK[_rr] + (PST[PAWN][_idx] // 4)
            else:
                MGT[_c][_pt][_sq] = MAT_MG[_pt] + PST[_pt][_idx]
                EGT[_c][_pt][_sq] = MAT_EG[_pt] + (PST[_pt][_idx] * 3) // 4

# (центр, мг за клетку, эг за клетку)
MOB = {KNIGHT: (4, 4, 4), BISHOP: (6, 3, 4), ROOK: (6, 2, 4), QUEEN: (11, 1, 2)}
KA_W = {KNIGHT: 2, BISHOP: 2, ROOK: 3, QUEEN: 5}
PASS_MG = (0, 4, 8, 16, 32, 56, 96, 0)
PASS_EG = (0, 8, 16, 32, 58, 96, 150, 0)


def _ranks_ahead(color: int, r: int) -> int:
    m = 0
    rng = range(r + 1, 8) if color else range(0, r)
    for x in rng:
        m |= RANK_BB[x]
    return m


def _ranks_behind_eq(color: int, r: int) -> int:
    m = 0
    rng = range(0, r + 1) if color else range(r, 8)
    for x in rng:
        m |= RANK_BB[x]
    return m


ADJ_FILES = [((FILE_BB[f - 1] if f > 0 else 0) | (FILE_BB[f + 1] if f < 7 else 0)) for f in range(8)]
PASSED_MASK = [[0] * 64 for _ in range(2)]
ADJ_AHEAD = [[0] * 64 for _ in range(2)]
ADJ_BEHIND = [[0] * 64 for _ in range(2)]
AHEAD_SAME = [[0] * 64 for _ in range(2)]
SHIELD = [[0] * 64 for _ in range(2)]
KING_ZONE = [0] * 64
CMD = [0] * 64                          # расстояние до центра (манхэттен)
SPACE_MASK = [0, 0]
for _c in (0, 1):
    for _sq in range(64):
        _r, _f = _sq >> 3, _sq & 7
        _ahead = _ranks_ahead(_c, _r)
        PASSED_MASK[_c][_sq] = (FILE_BB[_f] | ADJ_FILES[_f]) & _ahead
        ADJ_AHEAD[_c][_sq] = ADJ_FILES[_f] & _ahead
        ADJ_BEHIND[_c][_sq] = ADJ_FILES[_f] & _ranks_behind_eq(_c, _r)
        AHEAD_SAME[_c][_sq] = FILE_BB[_f] & _ahead
        _two = 0
        for _d in (1, 2):
            _rr2 = _r + _d if _c else _r - _d
            if 0 <= _rr2 < 8:
                _two |= RANK_BB[_rr2]
        SHIELD[_c][_sq] = (FILE_BB[_f] | ADJ_FILES[_f]) & _two
for _sq in range(64):
    KING_ZONE[_sq] = chess.BB_KING_ATTACKS[_sq] | chess.BB_SQUARES[_sq]
    _f, _r = _sq & 7, _sq >> 3
    CMD[_sq] = max(3 - _f, _f - 4) + max(3 - _r, _r - 4)
for _f in range(2, 6):
    for _rr in (1, 2, 3):
        SPACE_MASK[1] |= chess.BB_SQUARES[_rr * 8 + _f]
        SPACE_MASK[0] |= chess.BB_SQUARES[(7 - _rr) * 8 + _f]


def pawn_attacks_bb(color: int, pawns: int) -> int:
    if color:
        return (((pawns << 7) & NOT_H) | ((pawns << 9) & NOT_A)) & BB_ALL
    return ((pawns >> 9) & NOT_H) | ((pawns >> 7) & NOT_A)


# --------------------------------------------------------------------------- настройки
@dataclass
class Settings:
    """Все настройки движка. Часть из них подбирается по Эло (см. settings_for_elo)."""
    # --- сила и поведение ---
    depth: int = 12               # максимальная глубина (полуходы)
    time_ms: int = 3000           # жёсткий лимит времени на ход
    max_nodes: int = 0            # лимит узлов (0 — без лимита)
    candidates: int = 1           # сколько лучших ходов рассматривать (для слабых уровней)
    mistake_chance: float = 0.0   # вероятность «ошибки»
    noise: int = 0                # шум оценки (сантипешки)
    opening_variety: int = 6      # первые N полуходов — случайно среди равных
    use_skill: bool = False       # Skill Level как в Stockfish (pick_best по MultiPV)
    skill_level: float = 20.0     # 0..20
    contempt: int = 0             # >0 — избегать ничьих, <0 — стремиться к ним
    time_manager: bool = True     # досрочная остановка по стабильности хода
    time_fraction: int = 45       # «оптимальное» время, % от лимита
    move_overhead_ms: int = 30    # запас времени на ход
    # --- таблица транспозиций ---
    use_tt: bool = True
    hash_mb: int = 64
    # --- поиск ---
    quiescence: bool = True       # поиск взятий в листьях
    q_depth: int = 8
    q_checks: bool = False        # в quiescence пробовать шахи на первом уровне
    delta_pruning: bool = True
    check_ext: bool = True        # расширение при шахе
    singular_ext: bool = True     # singular extensions
    singular_depth: int = 8
    singular_margin: int = 4      # маржа на единицу глубины
    aspiration: bool = True       # окна aspiration
    aspiration_delta: int = 25
    iir: bool = True              # internal iterative reduction
    # --- отсечения ---
    razoring: bool = True
    razor_margin: int = 250
    rfp: bool = True              # reverse futility / static null move
    rfp_margin: int = 90
    null_move: bool = True
    null_verify: bool = True      # верификация null-move на большой глубине
    probcut: bool = True
    probcut_margin: int = 180
    futility: bool = True
    futility_margin: int = 70
    lmp: bool = True              # late move pruning
    see_pruning: bool = True
    lmr: bool = True              # сокращение поздних ходов
    lmr_strength: int = 100       # % от табличного сокращения
    # --- упорядочивание ходов ---
    killers: bool = True
    countermoves: bool = True
    history: bool = True
    cont_history: bool = True
    # --- оценка ---
    use_pst: bool = True
    bishop_pair: bool = True
    pawn_structure: bool = True
    passed_pawns: bool = True
    rook_files: bool = True
    mobility: bool = True
    king_safety: bool = True
    threats: bool = True
    space: bool = True
    outposts: bool = True
    mop_up: bool = True
    endgame_scale: bool = True
    rule50_scale: bool = True
    tempo_bonus: int = 10
    mobility_w: int = 100
    king_safety_w: int = 100
    threats_w: int = 100
    passed_w: int = 100
    space_w: int = 100
    lazy_eval: bool = True
    lazy_margin: int = 700
    eval_cache: bool = True
    # --- дебютная книга Polyglot и таблицы Syzygy ---
    use_book: bool = False
    book_path: str = ""
    book_best: bool = False       # True — всегда лучший по весу, False — случайно по весам
    book_max_ply: int = 20
    syzygy_path: str = ""
    syzygy_probe_depth: int = 1
    syzygy_max_pieces: int = 6
    syzygy_50move: bool = True
    # --- анализ / подсказки ---
    analysis_depth: int = 12
    analysis_time_ms: int = 1500
    arrows: int = 3               # количество стрелок-подсказок (0 — выкл)


ENGINE_KEYS = [f.name for f in fields(Settings) if not f.name.startswith(("analysis", "arrows"))]
# настройки, от которых зависит значение оценки (при их смене кэши очищаются)
EVAL_KEYS = ["use_pst", "bishop_pair", "pawn_structure", "passed_pawns", "rook_files", "mobility", "king_safety",
             "threats", "space", "outposts", "mop_up", "endgame_scale", "tempo_bonus", "mobility_w",
             "king_safety_w", "threats_w", "passed_w", "space_w", "lazy_eval", "lazy_margin"]


def clamp_elo(elo: int) -> int:
    return max(MIN_ELO, min(MAX_ELO, int(elo)))


def settings_for_elo(elo: int, base: Optional[Settings] = None) -> Settings:
    """Подбирает настройки под Эло (максимум MAX_ELO). Ручные параметры (хеш, книга, Syzygy,
    анализ, вес оценочных членов) берутся из base, чтобы не сбрасываться при смене Эло."""
    elo = clamp_elo(elo)
    t = (elo - MIN_ELO) / (MAX_ELO - MIN_ELO)
    weak = 1 - t
    s = Settings(**asdict(base)) if base else Settings()
    s.depth = max(1, round(1 + t * 13))
    s.time_ms = round(300 + t * 4700)
    s.max_nodes = 0
    s.quiescence = elo >= 700
    s.q_depth = round(2 + t * 8)
    s.q_checks = elo >= 2200
    s.delta_pruning = elo >= 1100
    s.use_tt = elo >= 900
    s.check_ext = elo >= 1300
    s.null_move = elo >= 1400
    s.null_verify = elo >= 2000
    s.lmr = elo >= 1600
    s.aspiration = elo >= 1500
    s.iir = elo >= 1700
    s.razoring = elo >= 1800
    s.rfp = elo >= 1500
    s.futility = elo >= 1700
    s.lmp = elo >= 1800
    s.see_pruning = elo >= 1900
    s.probcut = elo >= 2100
    s.singular_ext = elo >= 2300
    s.killers = elo >= 1000
    s.history = elo >= 1200
    s.countermoves = elo >= 1600
    s.cont_history = elo >= 1900
    s.time_manager = elo >= 1200
    s.noise = round(260 * weak * weak)
    s.mistake_chance = round(0.45 * weak ** 1.6, 2)
    s.candidates = 1 + round(5 * weak)
    s.opening_variety = 6 if elo >= 1800 else 8
    s.use_skill = 1300 <= elo < MAX_ELO
    s.skill_level = round(max(0.0, min(19.5, (elo - 1300) / (MAX_ELO - 1300) * 20)), 1) if s.use_skill else 20.0
    s.use_pst = elo >= 500
    s.bishop_pair = elo >= 1200
    s.pawn_structure = elo >= 1000
    s.passed_pawns = elo >= 1100
    s.rook_files = elo >= 1500
    s.mobility = elo >= 1300
    s.king_safety = elo >= 1600
    s.threats = elo >= 1700
    s.space = elo >= 1900
    s.outposts = elo >= 1800
    s.mop_up = elo >= 1000
    s.endgame_scale = elo >= 1800
    return s


# --------------------------------------------------------------------------- результаты
@dataclass
class Line:
    move: chess.Move
    score: int            # с точки зрения стороны, которая ходит
    pv: List[chess.Move] = field(default_factory=list)


@dataclass
class Info:
    depth: int
    nodes: int
    time_ms: int
    lines: List[Line]
    seldepth: int = 0
    hashfull: int = 0     # заполненность хеша, промилле
    tbhits: int = 0
    book: bool = False


class Stop(Exception):
    pass


# --------------------------------------------------------------------------- общее состояние
class Hash:
    """Таблица транспозиций и кэши оценки. Живёт между поисками (как Hash в Stockfish).

    Два поколения словарей: когда текущее заполнено, оно становится «старым», а новое
    начинается с пустого — устаревшие записи вымываются сами."""

    def __init__(self) -> None:
        self.cur: dict = {}
        self.old: dict = {}
        self.gen = 0
        self.cap = 150_000
        self.ecache: dict = {}
        self.pcache: dict = {}
        self.sig: Optional[tuple] = None

    def configure(self, s: Settings) -> None:
        self.cap = max(1000, int(s.hash_mb) * 2300)
        sig = tuple(getattr(s, k) for k in EVAL_KEYS)
        if sig != self.sig:
            self.sig = sig
            self.clear()

    def clear(self) -> None:
        self.cur, self.old = {}, {}
        self.ecache, self.pcache = {}, {}

    def get(self, key):
        e = self.cur.get(key)
        return e if e is not None else self.old.get(key)

    def put(self, key, depth: int, score: int, flag: int, move) -> None:
        e = self.cur.get(key)
        if e is not None:
            if move is None:
                move = e[3]
            if not (flag == EXACT or depth + 3 > e[0] or e[4] != self.gen):
                return
        elif len(self.cur) >= self.cap:
            self.old, self.cur = self.cur, {}
        self.cur[key] = (depth, score, flag, move, self.gen)

    def hashfull(self) -> int:
        return min(1000, len(self.cur) * 1000 // max(1, self.cap))


_TB_CACHE: Dict[str, object] = {}


def _open_tb(path: str):
    if not path or _syzygy is None:
        return None
    if path not in _TB_CACHE:
        try:
            _TB_CACHE[path] = _syzygy.open_tablebase(path)
        except Exception:
            _TB_CACHE[path] = None
    return _TB_CACHE[path]


# --------------------------------------------------------------------------- движок
_KN = chess.BB_KNIGHT_ATTACKS
_KA = chess.BB_KING_ATTACKS
_DM, _DA = chess.BB_DIAG_MASKS, chess.BB_DIAG_ATTACKS
_RM, _RA = chess.BB_RANK_MASKS, chess.BB_RANK_ATTACKS
_FM, _FA = chess.BB_FILE_MASKS, chess.BB_FILE_ATTACKS
_PATT = chess.BB_PAWN_ATTACKS
_SQ = chess.BB_SQUARES


class Engine:
    def __init__(self, settings: Settings, tt: Optional[Hash] = None):
        self.s = settings
        self.h = tt if tt is not None else Hash()
        self.h.configure(settings)
        self.stop_flag = False
        self.can_abort = False
        self.nodes = 0
        self.seldepth = 0
        self.tbhits = 0
        self.deadline = 0.0
        self.max_nodes = 0
        strength = settings.lmr_strength / 100
        self._lmr = [[0] * 64 for _ in range(64)]
        for d in range(1, 64):
            for m in range(1, 64):
                self._lmr[d][m] = int((0.75 + math.log(d) * math.log(m) / 2.25) * strength)
        self.tb = None
        self.tb_card = 0

    # ======================================================================= оценка
    def evaluate(self, b: chess.Board) -> int:
        """Оценка в сантипешках с точки зрения стороны, которая ходит."""
        s = self.s
        if s.eval_cache:
            key = (b.pawns, b.knights, b.bishops, b.rooks, b.queens, b.kings, b.occupied_co[True], b.turn)
            ec = self.h.ecache
            v = ec.get(key)
            if v is None:
                v = self._eval(b)
                if len(ec) > 300_000:
                    ec.clear()
                ec[key] = v
        else:
            v = self._eval(b)
        if s.rule50_scale and b.halfmove_clock > 8:
            v = int(v * (200 - b.halfmove_clock) / 200)
        return v

    def _pawn_eval(self, wp: int, bp: int):
        pc = self.h.pcache
        key = (wp, bp)
        r = pc.get(key)
        if r is not None:
            return r
        s = self.s
        ps, pp, pw = s.pawn_structure, s.passed_pawns, s.passed_w
        mg = eg = 0
        passed = [0, 0]
        for c in (1, 0):
            sg = 1 if c else -1
            own = wp if c else bp
            foe = bp if c else wp
            lm = le = 0
            bb = own
            while bb:
                lsb = bb & -bb
                sq = lsb.bit_length() - 1
                bb ^= lsb
                f = sq & 7
                r_ = sq >> 3
                rr = r_ if c else 7 - r_
                supported = own & _PATT[1 - c][sq]
                phalanx = own & ADJ_FILES[f] & RANK_BB[r_]
                if ps:
                    isolated = not (own & ADJ_FILES[f])
                    if isolated:
                        lm -= 12
                        le -= 16
                    elif not (own & ADJ_BEHIND[c][sq]) and rr < 6:
                        stop = sq + 8 if c else sq - 8
                        if foe & _PATT[c][stop]:
                            lm -= 10
                            le -= 12
                    if own & AHEAD_SAME[c][sq]:
                        lm -= 10
                        le -= 18
                    if phalanx:
                        lm += 3 + rr * 2
                        le += 2 + rr
                    if supported:
                        lm += 5 + rr * 2
                        le += 3 + rr
                if not (foe & PASSED_MASK[c][sq]):
                    passed[c] |= lsb
                    if pp:
                        lm += PASS_MG[rr] * pw // 100
                        le += PASS_EG[rr] * pw // 100
                        if supported or phalanx:
                            lm += PASS_MG[rr] // 4
                            le += PASS_EG[rr] // 4
            mg += sg * lm
            eg += sg * le
        res = (mg, eg, passed)
        if len(pc) > 100_000:
            pc.clear()
        pc[key] = res
        return res

    def _eval(self, b: chess.Board) -> int:
        s = self.s
        W, Bk = b.occupied_co[True], b.occupied_co[False]
        occ = b.occupied
        bbs = (0, b.pawns, b.knights, b.bishops, b.rooks, b.queens, b.kings)
        own_occ = (Bk, W)
        wp, bp = b.pawns & W, b.pawns & Bk
        pawns_c = (bp, wp)
        mgt = MGT if s.use_pst else MGT_NOPST
        egt = EGT if s.use_pst else EGT_NOPST
        mg = eg = 0
        phase = 0
        npm = [0, 0]          # материал без пешек
        ksq = [0, 0]
        # ---- 1. материал + PST + фаза ------------------------------------------------
        for c in (1, 0):
            sg = 1 if c else -1
            own = own_occ[c]
            mt, et = mgt[c], egt[c]
            lm = le = 0
            for pt in (1, 2, 3, 4, 5):
                bb = bbs[pt] & own
                if pt > 1 and bb:
                    n = _pc(bb)
                    phase += n * (1 if pt < 4 else 2 if pt == 4 else 4)
                    npm[c] += n * VAL[pt]
                while bb:
                    lsb = bb & -bb
                    sq = lsb.bit_length() - 1
                    bb ^= lsb
                    lm += mt[pt][sq]
                    le += et[pt][sq]
            k = (b.kings & own).bit_length() - 1
            ksq[c] = k
            lm += mt[6][k]
            le += et[6][k]
            if s.bishop_pair and _pc(b.bishops & own) >= 2:
                lm += 30
                le += 45
            mg += sg * lm
            eg += sg * le
        if s.pawn_structure or s.passed_pawns:
            pm, pe, passed = self._pawn_eval(wp, bp)
            mg += pm
            eg += pe
        else:
            passed = (0, 0)
        # ---- mop-up: загнать голого короля в угол --------------------------------------
        if s.mop_up:
            for c in (1, 0):
                a = 1 - c
                if npm[a] == 0 and not pawns_c[a] and npm[c] >= 500:
                    d = 10 * CMD[ksq[a]] + 4 * (14 - chess.square_manhattan_distance(ksq[0], ksq[1]))
                    eg += d if c else -d
        ph = phase if phase < 24 else 24
        if s.lazy_eval:
            core = int((mg * ph + eg * (24 - ph)) / 24)
            if core > s.lazy_margin or core < -s.lazy_margin:
                return core if b.turn else -core
        # ---- 2. мобильность, король, угрозы, пространство, форпосты ---------------------
        pa = (pawn_attacks_bb(0, bp), pawn_attacks_bb(1, wp))
        all_att = [pa[0] | _KA[ksq[0]], pa[1] | _KA[ksq[1]]]
        minor_att = [0, 0]
        rook_att = [0, 0]
        ka_cnt = [0, 0]
        ka_units = [0, 0]
        use_mob, use_ks, use_thr = s.mobility, s.king_safety, s.threats
        use_out, use_rook = s.outposts, s.rook_files
        mob_w = s.mobility_w
        for c in (1, 0):
            sg = 1 if c else -1
            own = own_occ[c]
            foe = own_occ[1 - c]
            area = BB_ALL & ~own & ~pa[1 - c]
            my_p, foe_p = pawns_c[c], pawns_c[1 - c]
            zone = KING_ZONE[ksq[1 - c]]
            fk_rr = (ksq[1 - c] >> 3) if c else 7 - (ksq[1 - c] >> 3)
            lm = le = 0
            for pt in (2, 3, 4, 5):
                bb = bbs[pt] & own
                while bb:
                    lsb = bb & -bb
                    sq = lsb.bit_length() - 1
                    bb ^= lsb
                    if pt == 2:
                        att = _KN[sq]
                    elif pt == 3:
                        att = _DA[sq][_DM[sq] & occ]
                    elif pt == 4:
                        att = _RA[sq][_RM[sq] & occ] | _FA[sq][_FM[sq] & occ]
                    else:
                        att = _DA[sq][_DM[sq] & occ] | _RA[sq][_RM[sq] & occ] | _FA[sq][_FM[sq] & occ]
                    all_att[c] |= att
                    if pt < 4:
                        minor_att[c] |= att
                    elif pt == 4:
                        rook_att[c] |= att
                    if use_mob:
                        ctr, a_, e_ = MOB[pt]
                        n = _pc(att & area) - ctr
                        lm += n * a_ * mob_w // 100
                        le += n * e_ * mob_w // 100
                    if use_ks:
                        z = att & zone
                        if z:
                            ka_cnt[c] += 1
                            ka_units[c] += KA_W[pt] * _pc(z)
                    if pt <= 3:
                        if use_out:
                            rr = (sq >> 3) if c else 7 - (sq >> 3)
                            if 3 <= rr <= 5 and (my_p & _PATT[1 - c][sq]) and not (foe_p & ADJ_AHEAD[c][sq]):
                                if pt == 2:
                                    lm += 22
                                    le += 14
                                else:
                                    lm += 10
                                    le += 6
                    elif pt == 4 and use_rook:
                        fm = FILE_BB[sq & 7]
                        if not (my_p & fm):
                            if not (foe_p & fm):
                                lm += 22
                                le += 10
                            else:
                                lm += 12
                                le += 8
                        rr = (sq >> 3) if c else 7 - (sq >> 3)
                        if rr == 6 and (fk_rr == 7 or (foe_p & RANK_BB[sq >> 3])):
                            lm += 15
                            le += 22
            # проходные пешки: близость королей и блокада
            if s.passed_pawns:
                pb = passed[c]
                while pb:
                    lsb = pb & -pb
                    sq = lsb.bit_length() - 1
                    pb ^= lsb
                    rr = (sq >> 3) if c else 7 - (sq >> 3)
                    stop = sq + 8 if c else sq - 8
                    if 0 <= stop < 64 and rr >= 2:
                        kd_f = chess.square_distance(ksq[1 - c], stop)
                        kd_o = chess.square_distance(ksq[c], stop)
                        le += ((kd_f if kd_f < 5 else 5) * 4 - (kd_o if kd_o < 5 else 5) * 2) * rr * s.passed_w // 400
                        if foe & _SQ[stop]:
                            lm -= PASS_MG[rr] // 3
                            le -= PASS_EG[rr] // 3
            # пространство
            if s.space:
                safe = SPACE_MASK[c] & ~my_p & ~pa[1 - c]
                w = _pc(own) - 3
                if w > 0:
                    lm += _pc(safe) * w * w // 32 * s.space_w // 100
            mg += sg * lm
            eg += sg * le
        # угрозы: наши фигуры под боем (считаются после того, как собраны карты атак обеих сторон)
        if use_thr:
            for c in (1, 0):
                a = 1 - c
                sg = 1 if c else -1
                own = own_occ[c]
                minors = (bbs[2] | bbs[3]) & own
                thr = (_pc(minors & pa[a]) * 28 + _pc(bbs[4] & own & pa[a]) * 45 + _pc(bbs[5] & own & pa[a]) * 55
                       + _pc(bbs[4] & own & minor_att[a]) * 22
                       + _pc(bbs[5] & own & (minor_att[a] | rook_att[a])) * 35)
                hanging = own & ~bbs[1] & ~bbs[6] & all_att[a] & ~all_att[c]
                thr += _pc(hanging) * 14
                mg -= sg * (thr * s.threats_w // 100)
                eg -= sg * (thr * s.threats_w // 130)
        # безопасность короля (защищающийся — c, атакующий — a)
        if use_ks:
            ksw = s.king_safety_w
            for c in (1, 0):
                a = 1 - c
                sg = 1 if c else -1
                term = 0
                cnt, units = ka_cnt[a], ka_units[a]
                if cnt >= 2 or (cnt == 1 and (bbs[5] & own_occ[a])):
                    pen = units * units // 6
                    if pen > 500:
                        pen = 500
                    if not (bbs[5] & own_occ[a]):
                        pen //= 3
                    term -= pen
                k = ksq[c]
                krr = (k >> 3) if c else 7 - (k >> 3)
                if krr <= 1:
                    my_p = pawns_c[c]
                    term += 8 * _pc(my_p & SHIELD[c][k]) - 24
                    if not (my_p & FILE_BB[k & 7]) and ((bbs[4] | bbs[5]) & own_occ[a]):
                        term -= 15
                else:
                    term -= 20
                mg += sg * term * ksw // 100
        # темп
        if s.tempo_bonus:
            if b.turn:
                mg += s.tempo_bonus
                eg += s.tempo_bonus // 2
            else:
                mg -= s.tempo_bonus
                eg -= s.tempo_bonus // 2
        # масштабирование «ничейных» окончаний
        if s.endgame_scale and eg:
            st = 1 if eg > 0 else 0          # сильная сторона
            wk = 1 - st
            if not pawns_c[st]:
                if npm[st] - npm[wk] <= 340:
                    eg = int(eg / 8)         # без пешек и перевес не больше лёгкой фигуры — почти ничья
            elif npm[0] == 335 and npm[1] == 335:
                # только по одному слону: при разноцветных — сильная ничейная тенденция
                if bool(b.bishops & W & chess.BB_DARK_SQUARES) != bool(b.bishops & Bk & chess.BB_DARK_SQUARES):
                    eg = int(eg / 2)
        score = int((mg * ph + eg * (24 - ph)) / 24)
        return score if b.turn else -score

    # ======================================================================= SEE
    def see_ge(self, b: chess.Board, m: chess.Move, threshold: int = 0) -> bool:
        """Static Exchange Evaluation: выигрывает ли размен на клетке хода не меньше threshold."""
        if m.promotion:
            return threshold <= 0
        frm, to = m.from_square, m.to_square
        att_pt = b.piece_type_at(frm)
        victim = b.piece_type_at(to)
        if victim is None:
            if att_pt == PAWN and to == b.ep_square:
                return threshold <= 0
            vv = 0
        else:
            vv = VAL[victim]
        swap = vv - threshold
        if swap < 0:
            return False
        swap = VAL[att_pt] - swap
        if swap <= 0:
            return True
        occ = b.occupied ^ _SQ[frm] ^ _SQ[to]
        stm = b.turn
        res = 1
        am = b.attackers_mask
        attackers = (am(True, to, occ) | am(False, to, occ)) & occ
        bbs = (0, b.pawns, b.knights, b.bishops, b.rooks, b.queens, b.kings)
        while True:
            stm = not stm
            attackers &= occ
            mine = attackers & b.occupied_co[stm]
            if not mine:
                break
            res ^= 1
            for pt in (1, 2, 3, 4, 5, 6):
                bb = mine & bbs[pt]
                if bb:
                    break
            if pt == KING:
                return bool(res ^ 1) if (attackers & ~b.occupied_co[stm]) else bool(res)
            swap = VAL[pt] - swap
            if swap < res:
                break
            occ ^= bb & -bb
            if pt != KNIGHT:
                attackers = (am(True, to, occ) | am(False, to, occ)) & occ
        return bool(res)

    # ======================================================================= служебное
    @staticmethod
    def _key(b: chess.Board):
        return (b.pawns, b.knights, b.bishops, b.rooks, b.queens, b.kings,
                b.occupied_co[True], b.occupied_co[False], b.turn, b.castling_rights, b.ep_square)

    def _draw(self, ply: int) -> int:
        c = self.s.contempt
        return -c if not (ply & 1) else c

    def _check_stop(self) -> None:
        if self.stop_flag or time.time() > self.deadline or (self.max_nodes and self.nodes >= self.max_nodes):
            raise Stop()

    def _store(self, key, depth: int, score: int, flag: int, move, ply: int) -> None:
        if score >= TB_BOUND:
            score += ply
        elif score <= -TB_BOUND:
            score -= ply
        self.h.put(key, depth, score, flag, move)

    # ======================================================================= упорядочивание ходов
    def _order(self, b: chess.Board, moves, tt_move, ply: int, prev):
        """Возвращает список (оценка, ход) по убыванию. Плохие по SEE взятия получают оценку < 0."""
        s = self.s
        turn = b.turn
        killers = self.killers[ply] if s.killers else ()
        counter = self.counter.get(turn * 512 + prev) if (s.countermoves and prev is not None) else None
        hist = self.hist if s.history else None
        cont = self.cont if (s.cont_history and prev is not None) else None
        ckey = (turn * 512 + prev) * 512 if cont is not None else 0
        pt_at = b.piece_type_at
        ep = b.ep_square
        out = []
        for m in moves:
            if m == tt_move:
                out.append((10_000_000, m))
                continue
            frm, to = m.from_square, m.to_square
            victim = pt_at(to)
            promo = m.promotion
            att = pt_at(frm)
            if victim is None and att == PAWN and ep == to:
                victim = PAWN
            if victim is not None:
                if VAL[victim] >= VAL[att] or self.see_ge(b, m, 0):
                    sc = 2_000_000 + VAL[victim] * 8 - att
                else:
                    sc = -500_000 + VAL[victim] * 8 - att
                if promo == QUEEN:
                    sc += 800_000
            elif promo:
                sc = 1_900_000 if promo == QUEEN else -600_000
            else:
                if m in killers:
                    sc = 900_000 - killers.index(m)
                elif m == counter:
                    sc = 800_000
                else:
                    sc = hist[(turn << 12) | (frm << 6) | to] if hist is not None else 0
                    if cont is not None:
                        sc += cont.get(ckey + ((att << 6) | to), 0)
            out.append((sc, m))
        out.sort(key=_first, reverse=True)
        return out

    def _quiet_score(self, b: chess.Board, m: chess.Move, piece: int, prev) -> int:
        s = self.s
        turn = b.turn
        sc = self.hist[(turn << 12) | (m.from_square << 6) | m.to_square] if s.history else 0
        if s.cont_history and prev is not None:
            sc += self.cont.get((turn * 512 + prev) * 512 + ((piece << 6) | m.to_square), 0)
        return sc

    def _update_quiet(self, b: chess.Board, ply: int, m: chess.Move, piece: int, depth: int, quiets, prev) -> None:
        s = self.s
        turn = b.turn
        if s.killers:
            ks = self.killers[ply]
            if m not in ks:
                ks.insert(0, m)
                del ks[2:]
        if s.countermoves and prev is not None:
            self.counter[turn * 512 + prev] = m
        bonus = 16 * depth * depth + 16 * depth
        if bonus > 1600:
            bonus = 1600
        if s.history:
            hl = self.hist
            i = (turn << 12) | (m.from_square << 6) | m.to_square
            hl[i] += bonus - hl[i] * bonus // 16384
            for _, f, t in quiets:
                j = (turn << 12) | (f << 6) | t
                hl[j] -= bonus + hl[j] * bonus // 16384
        if s.cont_history and prev is not None:
            ck = (turn * 512 + prev) * 512
            cont = self.cont
            i = ck + ((piece << 6) | m.to_square)
            v = cont.get(i, 0)
            cont[i] = v + bonus - v * bonus // 16384
            for pc, _, t in quiets:
                j = ck + ((pc << 6) | t)
                v = cont.get(j, 0)
                cont[j] = v - bonus - v * bonus // 16384

    # ======================================================================= quiescence
    def qsearch(self, b: chess.Board, alpha: int, beta: int, ply: int, qd: int) -> int:
        s = self.s
        self.nodes += 1
        if self.can_abort and not (self.nodes & 511):
            self._check_stop()
        if ply > self.seldepth:
            self.seldepth = ply
        if ply >= MAX_PLY - 1:
            return self.evaluate(b)
        in_check = b.is_check()
        if s.use_tt:
            e = self.h.get(self._key(b))
            if e is not None:
                sc, flag = e[1], e[2]
                if sc >= TB_BOUND:
                    sc -= ply
                elif sc <= -TB_BOUND:
                    sc += ply
                if flag == EXACT or (flag == LOWER and sc >= beta) or (flag == UPPER and sc <= alpha):
                    return sc
        if in_check:
            stand = None
            best = -MATE + ply
            moves = list(b.legal_moves)
            if not moves:
                return best
        else:
            stand = self.evaluate(b)
            if stand >= beta:
                return stand
            best = stand
            if stand > alpha:
                alpha = stand
            if qd >= s.q_depth:
                return stand
            if s.delta_pruning and stand + 1200 < alpha:
                return stand
            moves = list(b.generate_legal_captures())
            us = b.occupied_co[b.turn]
            p7 = b.pawns & us & (RANK_BB[6] if b.turn else RANK_BB[1])
            if p7:
                moves += [m for m in b.generate_legal_moves(p7, ~b.occupied & BB_ALL) if m.promotion == QUEEN]
            if s.q_checks and qd == 0:
                for m in b.legal_moves:
                    if not b.is_capture(m) and not m.promotion and b.gives_check(m):
                        moves.append(m)
        ply_i = ply if ply < MAX_PLY else MAX_PLY - 1
        for sc0, m in self._order(b, moves, None, ply_i, None):
            promo = m.promotion
            if promo and promo != QUEEN:
                continue
            if stand is not None:
                if sc0 < -100_000 and s.see_pruning:
                    break                                   # дальше только проигрышные по SEE взятия
                if s.delta_pruning and not promo:
                    v = b.piece_type_at(m.to_square)
                    if stand + (VAL[v] if v else 100) + 200 <= alpha:
                        continue
            b.push(m)
            sc = -self.qsearch(b, -beta, -alpha, ply + 1, qd + 1)
            b.pop()
            if sc > best:
                best = sc
                if sc > alpha:
                    alpha = sc
                    if sc >= beta:
                        break
        return best

    # ======================================================================= основной поиск
    def _ab(self, b: chess.Board, depth: int, alpha: int, beta: int, ply: int, cut: bool, null_ok: bool = True) -> int:
        """Обёртка узла: обнаружение ничьих (повторение, правило 50 ходов, нехватка материала)."""
        key = self._key(b)
        rep = self.rep
        if key in rep or b.halfmove_clock >= 100 or \
                (not (b.pawns | b.rooks | b.queens) and b.is_insufficient_material()):
            self.nodes += 1
            return self._draw(ply)
        rep.add(key)
        v = self._node(b, depth, alpha, beta, ply, cut, null_ok, None, key)
        rep.discard(key)
        return v

    def _node(self, b: chess.Board, depth: int, alpha: int, beta: int, ply: int, cut: bool,
              null_ok: bool, excluded, key) -> int:
        s = self.s
        h = self.h
        self.nodes += 1
        if self.can_abort and not (self.nodes & 511):
            self._check_stop()
        if ply > self.seldepth:
            self.seldepth = ply
        pv_node = beta - alpha > 1
        in_check = b.is_check()
        if ply >= MAX_PLY - 1:
            return 0 if in_check else self.evaluate(b)
        # --- mate distance pruning
        if alpha < -MATE + ply:
            alpha = -MATE + ply
        if beta > MATE - ply - 1:
            beta = MATE - ply - 1
        if alpha >= beta:
            return alpha
        if in_check and s.check_ext:
            depth += 1
        if depth <= 0:
            return self.qsearch(b, alpha, beta, ply, 0) if s.quiescence else self.evaluate(b)

        # --- таблица транспозиций
        tt_move = None
        tt_score = 0
        tt_depth = -1
        tt_flag = -1
        if s.use_tt:
            e = h.get(key)
            if e is not None:
                tt_depth, tt_score, tt_flag, tt_move = e[0], e[1], e[2], e[3]
                if tt_score >= TB_BOUND:
                    tt_score -= ply
                elif tt_score <= -TB_BOUND:
                    tt_score += ply
                if (not pv_node and excluded is None and tt_depth >= depth and b.halfmove_clock < 90 and
                        (tt_flag == EXACT or (tt_flag == LOWER and tt_score >= beta) or
                         (tt_flag == UPPER and tt_score <= alpha))):
                    return tt_score

        # --- таблицы Syzygy (WDL)
        if self.tb is not None and excluded is None and ply > 0 and b.halfmove_clock == 0 and not b.castling_rights:
            cnt = _pc(b.occupied)
            if cnt <= self.tb_card and (cnt < self.tb_card or depth >= s.syzygy_probe_depth):
                wdl = self._tb_wdl(b)
                if wdl is not None:
                    self.tbhits += 1
                    ds = 1 if s.syzygy_50move else 0
                    if wdl < -ds:
                        v = -TB_WIN + ply + 1
                    elif wdl > ds:
                        v = TB_WIN - ply - 1
                    else:
                        v = 2 * wdl * ds
                    self._store(key, min(MAX_PLY - 1, depth + 6), v, EXACT, None, ply)
                    return v

        # --- статическая оценка
        if in_check:
            static = None
            ev = None
            self.sev[ply] = None
            improving = 0
        else:
            static = self.evaluate(b)
            self.sev[ply] = static
            ev = static
            if tt_flag >= 0 and (tt_flag == EXACT or (tt_flag == LOWER and tt_score > ev) or
                                 (tt_flag == UPPER and tt_score < ev)) and abs(tt_score) < TB_BOUND:
                ev = tt_score
            p2 = self.sev[ply - 2] if ply >= 2 else None
            improving = 1 if (p2 is not None and static > p2) else 0

        us = b.occupied_co[b.turn]
        has_np = bool(us & ~(b.pawns | b.kings))

        # --- отсечения «до перебора ходов»
        if not pv_node and not in_check and excluded is None:
            if s.razoring and depth <= 3 and ev + s.razor_margin * depth < alpha:
                v = self.qsearch(b, alpha - 1, alpha, ply, 0) if s.quiescence else ev
                if v < alpha:
                    return v
            if s.rfp and depth <= 8 and has_np and ev < MATE_BOUND and ev - s.rfp_margin * (depth - improving) >= beta:
                return (ev + beta) // 2
            if s.null_move and null_ok and has_np and depth >= 3 and ev >= beta and beta > -MATE_BOUND:
                r = 3 + depth // 4 + min((ev - beta) // 200, 3)
                self.moved[ply] = None
                b.push(NULL)
                v = -self._ab(b, depth - r, -beta, -beta + 1, ply + 1, not cut, False)
                b.pop()
                if v >= beta:
                    if v >= TB_BOUND:
                        v = beta
                    if not s.null_verify or depth < 10:
                        return v
                    v2 = self._node(b, depth - r, beta - 1, beta, ply, False, False, None, key)
                    if v2 >= beta:
                        return v
            if s.probcut and depth >= 5 and abs(beta) < MATE_BOUND:
                pc_beta = beta + s.probcut_margin
                if not (tt_depth >= depth - 3 and tt_score < pc_beta and tt_flag != LOWER):
                    caps = list(b.generate_legal_captures())
                    tried = 0
                    for sc0, m in self._order(b, caps, tt_move, ply, None):
                        if sc0 < 1_000_000:
                            break
                        if m.promotion and m.promotion != QUEEN:
                            continue
                        if not self.see_ge(b, m, pc_beta - ev):
                            continue
                        tried += 1
                        self.moved[ply] = (b.piece_type_at(m.from_square) << 6) | m.to_square
                        b.push(m)
                        v = -self.qsearch(b, -pc_beta, -pc_beta + 1, ply + 1, 0)
                        if v >= pc_beta:
                            v = -self._ab(b, depth - 4, -pc_beta, -pc_beta + 1, ply + 1, not cut)
                        b.pop()
                        if v >= pc_beta:
                            self._store(key, depth - 3, v, LOWER, m, ply)
                            return v - (pc_beta - beta)
                        if tried >= 3:
                            break

        # --- internal iterative reduction
        if s.iir and tt_move is None and depth >= 5 and (pv_node or cut):
            depth -= 1

        moves = list(b.legal_moves)
        if not moves:
            return -MATE + ply if in_check else self._draw(ply)
        prev = self.moved[ply - 1] if ply > 0 else None
        ordered = self._order(b, moves, tt_move, ply, prev)
        killers = self.killers[ply]
        turn = b.turn
        alpha0 = alpha
        best = -INF
        best_move = None
        n = 0
        quiets: list = []
        prune_ok = ply > 0 and has_np
        singular_ok = (s.singular_ext and excluded is None and ply > 0 and depth >= s.singular_depth and
                       tt_move is not None and tt_depth >= depth - 3 and tt_flag in (LOWER, EXACT) and
                       abs(tt_score) < MATE_BOUND)
        lmr_tab = self._lmr
        dmin = depth if depth < 63 else 63

        for _, m in ordered:
            if m == excluded:
                continue
            n += 1
            frm, to = m.from_square, m.to_square
            piece = b.piece_type_at(frm)
            is_cap = b.piece_type_at(to) is not None or (piece == PAWN and to == b.ep_square)
            promo = m.promotion
            is_quiet = not is_cap and not promo
            hs = self._quiet_score(b, m, piece, prev) if is_quiet else 0

            # --- отсечения на малой глубине
            if prune_ok and best > -MATE_BOUND:
                if is_quiet:
                    if s.lmp and depth <= 8 and n > (3 + depth * depth) // (2 - improving):
                        continue
                    if s.lmr:
                        lmr_depth = depth - 1 - lmr_tab[dmin][n if n < 63 else 63]
                        if lmr_depth < 0:
                            lmr_depth = 0
                    else:
                        lmr_depth = depth - 1
                    if (s.futility and static is not None and lmr_depth <= 8 and
                            static + s.futility_margin * (lmr_depth + 1) + 40 <= alpha and not in_check):
                        b.push(m)
                        chk = b.is_check()
                        b.pop()
                        if not chk:
                            continue
                    if s.see_pruning and lmr_depth <= 6 and not self.see_ge(b, m, -15 * lmr_depth * lmr_depth):
                        continue
                elif is_cap and s.see_pruning and depth <= 6 and not self.see_ge(b, m, -90 * depth):
                    continue

            # --- расширения
            ext = 0
            if singular_ok and m == tt_move:
                sb = tt_score - s.singular_margin * depth
                sv = self._node(b, (depth - 1) // 2, sb - 1, sb, ply, cut, False, m, key)
                if sv < sb:
                    ext = 1
                    if not pv_node and sv < sb - 25:
                        ext = 2
                elif sb >= beta:
                    return sb
                elif tt_score >= beta:
                    ext = -1

            code = (piece << 6) | to
            self.moved[ply] = code
            b.push(m)
            gives = b.is_check()
            nd = depth - 1 + ext

            if s.lmr and depth >= 3 and n > 1:
                r = lmr_tab[dmin][n if n < 63 else 63]
                if is_cap:
                    r -= 1
                if pv_node:
                    r -= 1
                if cut:
                    r += 1
                if not improving:
                    r += 1
                if gives:
                    r -= 1
                if is_quiet:
                    if m in killers:
                        r -= 1
                    r -= hs // 6000
                if r < 0:
                    r = 0
                elif r > nd - 1:
                    r = nd - 1 if nd > 1 else 0
                sc = -self._ab(b, nd - r, -alpha - 1, -alpha, ply + 1, True)
                if sc > alpha and r > 0:
                    sc = -self._ab(b, nd, -alpha - 1, -alpha, ply + 1, not cut)
            elif not pv_node or n > 1:
                sc = -self._ab(b, nd, -alpha - 1, -alpha, ply + 1, not cut)
            if pv_node and (n == 1 or sc > alpha):
                sc = -self._ab(b, nd, -beta, -alpha, ply + 1, False)
            b.pop()

            if sc > best:
                best = sc
                best_move = m
                if sc > alpha:
                    alpha = sc
                    if sc >= beta:
                        if is_quiet:
                            self._update_quiet(b, ply, m, piece, depth, quiets, prev)
                        break
            if is_quiet:
                quiets.append((piece, frm, to))

        if n == 0:
            return alpha
        if best == -INF:                       # все ходы отсечены (не должно случаться)
            return alpha
        if excluded is None and s.use_tt:
            flag = UPPER if best <= alpha0 else (LOWER if best >= beta else EXACT)
            self._store(key, depth, best, flag, None if flag == UPPER else best_move, ply)
        return best

    # ======================================================================= корень
    def _root(self, b: chess.Board, depth: int, alpha: int, beta: int, moves: List[chess.Move]):
        s = self.s
        best, best_move = -INF, None
        lmr_tab = self._lmr
        dmin = depth if depth < 63 else 63
        n = 0
        for m in moves:
            n += 1
            piece = b.piece_type_at(m.from_square)
            is_cap = b.is_capture(m)
            self.moved[0] = (piece << 6) | m.to_square
            b.push(m)
            gives = b.is_check()
            nd = depth - 1
            if n == 1:
                sc = -self._ab(b, nd, -beta, -alpha, 1, False)
            else:
                r = 0
                if s.lmr and depth >= 3 and n > 2 and not is_cap and not m.promotion and not gives:
                    r = lmr_tab[dmin][n if n < 63 else 63] - 1
                    r = max(0, min(r, nd - 1))
                sc = -self._ab(b, nd - r, -alpha - 1, -alpha, 1, True)
                if sc > alpha and r > 0:
                    sc = -self._ab(b, nd, -alpha - 1, -alpha, 1, True)
                if alpha < sc < beta:
                    sc = -self._ab(b, nd, -beta, -alpha, 1, False)
            b.pop()
            self.root_res[m] = sc
            if sc > best:
                best, best_move = sc, m
                if sc > alpha:
                    alpha = sc
                    if alpha >= beta:
                        break
        return best, best_move

    def _pv(self, b: chess.Board, first: chess.Move, limit: int = 12) -> List[chess.Move]:
        """PV достраивается по таблице транспозиций."""
        pv = [first]
        b.push(first)
        pushed = 1
        seen = {self._key(b)}
        while len(pv) < limit and self.s.use_tt:
            e = self.h.get(self._key(b))
            mv = e[3] if e else None
            if mv is None or mv not in b.legal_moves:
                break
            pv.append(mv)
            b.push(mv)
            pushed += 1
            k = self._key(b)
            if k in seen:
                break
            seen.add(k)
        for _ in range(pushed):
            b.pop()
        return pv

    def search(self, board: chess.Board, depth: int, time_ms: int, multipv: int = 1,
               on_info: Optional[Callable[[Info], None]] = None) -> Optional[Info]:
        s = self.s
        b = board.copy()
        base = len(b.move_stack)
        self.nodes = 0
        self.seldepth = 0
        self.tbhits = 0
        self.can_abort = False
        t0 = time.time()
        hard = max(50, int(time_ms) - s.move_overhead_ms)
        self.deadline = t0 + hard / 1000
        self.max_nodes = s.max_nodes
        h = self.h
        h.gen += 1
        self.killers = [[] for _ in range(MAX_PLY + 4)]
        self.hist = [0] * 8192
        self.cont = {}
        self.counter = {}
        self.moved = [None] * (MAX_PLY + 4)
        self.sev = [None] * (MAX_PLY + 4)
        self.root_res: Dict[chess.Move, int] = {}
        self.tb_missing: set = set()
        # история позиций для обнаружения повторений
        rep = set()
        tmp = board.copy()
        for _ in range(min(tmp.halfmove_clock, len(tmp.move_stack))):
            tmp.pop()
            rep.add(self._key(tmp))
        rep.add(self._key(b))
        self.rep = rep
        self.tb = _open_tb(s.syzygy_path) if s.syzygy_path else None
        self.tb_card = max(3, min(7, s.syzygy_max_pieces))

        root = list(b.legal_moves)
        if not root:
            return None
        if self.tb is not None:
            direct, root = self._tb_root(b, root)
            if direct is not None:
                return direct
        k = max(1, min(multipv, len(root)))
        if s.use_skill and s.skill_level < 20:
            depth = min(depth, 1 + int(s.skill_level))
        rk = h.get(self._key(b))
        root = [m for _, m in self._order(b, root, rk[3] if rk else None, 0, None)]

        last: Optional[Info] = None
        best_prev = None
        prev_score = None
        stable = 0
        try:
            for d in range(1, depth + 1):
                self.can_abort = d > 1
                lines: List[Line] = []
                remaining = list(root)
                for pv_idx in range(k):
                    if not remaining:
                        break
                    if s.aspiration and d >= 5 and last is not None and pv_idx < len(last.lines) \
                            and abs(last.lines[pv_idx].score) < MATE_BOUND:
                        delta = max(5, s.aspiration_delta)
                        center = last.lines[pv_idx].score
                        alpha, beta = center - delta, center + delta
                    else:
                        delta = 0
                        alpha, beta = -INF, INF
                    while True:
                        sc, mv = self._root(b, d, alpha, beta, remaining)
                        if alpha > -INF and sc <= alpha:                    # fail low
                            beta = (alpha + beta) // 2
                            alpha = max(sc - delta, -INF)
                        elif beta < INF and sc >= beta:                     # fail high
                            beta = min(sc + delta, INF)
                            remaining.remove(mv)
                            remaining.insert(0, mv)
                        else:
                            break
                        delta += delta // 2 + 5
                        if delta > 600:
                            alpha, beta = -INF, INF
                    remaining.remove(mv)
                    lines.append(Line(mv, sc, self._pv(b, mv)))
                    if pv_idx == 0 and s.use_tt:
                        self._store(self._key(b), d, sc, EXACT, mv, 0)
                lines.sort(key=lambda l: l.score, reverse=True)
                remaining.sort(key=lambda m: self.root_res.get(m, -INF), reverse=True)
                root = [l.move for l in lines] + remaining
                last = Info(d, self.nodes, int((time.time() - t0) * 1000), lines,
                            self.seldepth, h.hashfull(), self.tbhits)
                if on_info:
                    on_info(last)
                top = lines[0]
                if abs(top.score) >= MATE_BOUND and MATE - abs(top.score) <= d:
                    break
                if len(root) == 1 and d >= 2:
                    break
                el = (time.time() - t0) * 1000
                if s.time_manager:
                    if top.move == best_prev:
                        stable += 1
                    else:
                        stable = 0
                    best_prev = top.move
                    scale = 1.0
                    if stable >= 6:
                        scale = 0.5
                    elif stable >= 3:
                        scale = 0.75
                    if prev_score is not None:
                        if top.score < prev_score - 30:
                            scale *= 1.6                                    # оценка падает — думаем дольше
                        elif top.score > prev_score + 60:
                            scale *= 0.85
                    prev_score = top.score
                    if el > hard * s.time_fraction / 100 * scale:
                        break
        except Stop:
            while len(b.move_stack) > base:
                b.pop()
        return last

    # ======================================================================= Syzygy
    def _tb_sig(self, b: chess.Board):
        return tuple(_pc(bb & c) for c in (b.occupied_co[True], b.occupied_co[False])
                     for bb in (b.pawns, b.knights, b.bishops, b.rooks, b.queens))

    def _tb_wdl(self, b: chess.Board) -> Optional[int]:
        sig = self._tb_sig(b)
        if sig in self.tb_missing:
            return None
        try:
            return self.tb.probe_wdl(b)
        except Exception:
            self.tb_missing.add(sig)
            return None

    def _tb_root(self, b: chess.Board, root: List[chess.Move]):
        """Фильтрация ходов в корне по WDL; при выигрыше — выбор хода по DTZ."""
        s = self.s
        try:
            if b.castling_rights or _pc(b.occupied) > self.tb_card:
                return None, root
            scored = []
            for m in root:
                b.push(m)
                try:
                    wdl = -self.tb.probe_wdl(b)
                    dtz = abs(self.tb.probe_dtz(b)) if wdl > 0 else 0
                    zeroing = b.halfmove_clock == 0
                finally:
                    b.pop()
                scored.append((wdl, 0 if zeroing else dtz, m))
            best_wdl = max(x[0] for x in scored)
            keep = [x for x in scored if x[0] == best_wdl]
            if best_wdl > 0 and (best_wdl > 1 or not s.syzygy_50move):
                keep.sort(key=lambda x: x[1])
                m = keep[0][2]
                self.tbhits += 1
                return Info(1, 1, 0, [Line(m, TB_WIN - keep[0][1], [m])], 1, 0, self.tbhits), root
            return None, [x[2] for x in keep]
        except Exception:
            return None, root

    # ======================================================================= книга
    def book_move(self, board: chess.Board) -> Optional[chess.Move]:
        s = self.s
        if not s.use_book or not s.book_path or board.ply() >= s.book_max_ply:
            return None
        try:
            with chess.polyglot.open_reader(os.path.expanduser(s.book_path)) as r:
                e = r.find(board) if s.book_best else r.weighted_choice(board)
                return e.move if e.move in board.legal_moves else None
        except Exception:
            return None

    # ======================================================================= выбор хода с учётом силы
    def multipv_for_play(self) -> int:
        s = self.s
        k = max(1, s.candidates)
        if s.use_skill and s.skill_level < 20:
            k = max(k, 4)
        return k

    def _skill_pick(self, lines: List[Line]) -> chess.Move:
        """pick_best из Stockfish: чем ниже уровень, тем сильнее «подталкиваются» слабые ходы."""
        level = self.s.skill_level
        top = lines[0].score
        delta = min(top - lines[-1].score, VAL[PAWN])
        weakness = max(1, int(120 - 2 * level))
        best_score, best = -INF, lines[0].move
        for l in lines:
            push = int((weakness * (top - l.score) + delta * random.randrange(weakness)) / 128)
            if l.score + push >= best_score:
                best_score, best = l.score + push, l.move
        return best

    def pick(self, info: Info, ply: int) -> chess.Move:
        s, lines = self.s, info.lines
        if len(lines) == 1 or lines[0].score > MATE_BOUND or lines[0].score >= TB_BOUND:
            return lines[0].move
        safe = lambda a: [l for l in a if l.score > -MATE_BOUND] or a
        if ply < s.opening_variety:
            return random.choice([l for l in lines if l.score >= lines[0].score - 30]).move
        if s.use_skill and s.skill_level < 20:
            pool = safe(lines)
            if len(pool) > 1:
                return self._skill_pick(pool)
        if random.random() < s.mistake_chance:
            return random.choice(safe(lines[:max(1, s.candidates)])).move
        if s.noise > 0:
            pool = safe(lines[:max(1, s.candidates)])
            return max(pool, key=lambda l: max(-5000, min(5000, l.score)) + random.gauss(0, s.noise)).move
        return lines[0].move


def _first(x):
    return x[0]


def score_text(cp: int) -> str:
    if abs(cp) > MATE_BOUND:
        return f"{'+' if cp > 0 else '-'}M{math.ceil((MATE - abs(cp)) / 2)}"
    if abs(cp) >= TB_BOUND:
        return f"{'+' if cp > 0 else '-'}TB"
    return f"{cp / 100:+.2f}"
