"""Шахматный движок с графическим интерфейсом (tkinter + python-chess).

Запуск:  pip install chess  &&  python main.py
"""
from __future__ import annotations

import math
import queue
import threading
import tkinter as tk
from dataclasses import asdict
from tkinter import filedialog
from tkinter import font as tkfont
from tkinter import ttk
from typing import List, Optional, Tuple

import chess

from engine import (MATE, MAX_ELO, Engine, Hash, Info, Settings, clamp_elo, score_text, settings_for_elo)

THEMES = {
    "Зелёная": ("#eeeed2", "#769656"),
    "Классика": ("#f0d9b5", "#b58863"),
    "Синяя": ("#dee3e6", "#8ca2ad"),
    "Серая": ("#e4e4e7", "#8f9199"),
}
ARROW_COLORS = ["#22c55e", "#3b82f6", "#f59e0b", "#a855f7", "#ec4899"]
GLYPH = {chess.KING: "\u265a", chess.QUEEN: "\u265b", chess.ROOK: "\u265c",
         chess.BISHOP: "\u265d", chess.KNIGHT: "\u265e", chess.PAWN: "\u265f\ufe0e"}
BG = "#18181b"
PANEL = "#27272a"
FG = "#e4e4e7"
ACCENT = "#10b981"

# (ключ, подпись, тип, мин, макс, шаг)  — типы: int, float, bool, path
SPECS = [
    ("Сила и поведение", None, None, None, None, None),
    ("depth", "Глубина поиска (полуходы)", "int", 1, 24, 1),
    ("time_ms", "Время на ход (мс)", "int", 100, 30000, 100),
    ("max_nodes", "Лимит узлов (0 — без лимита)", "int", 0, 2000000, 10000),
    ("candidates", "Рассматриваемые ходы", "int", 1, 8, 1),
    ("mistake_chance", "Шанс ошибки (0..0.8)", "float", 0, 0.8, 0.01),
    ("noise", "Шум оценки (сантипешки)", "int", 0, 500, 5),
    ("opening_variety", "Вариативность дебюта (полуходы)", "int", 0, 20, 1),
    ("use_skill", "Skill Level как в Stockfish", "bool", 0, 0, 0),
    ("skill_level", "Skill Level (0..20)", "float", 0, 20, 0.5),
    ("contempt", "Contempt (избегать ничьих, сп)", "int", -100, 100, 5),
    ("Время", None, None, None, None, None),
    ("time_manager", "Менеджер времени (ранняя остановка)", "bool", 0, 0, 0),
    ("time_fraction", "Оптимальное время (% от лимита)", "int", 10, 100, 5),
    ("move_overhead_ms", "Запас времени на ход (мс)", "int", 0, 500, 10),
    ("Таблица транспозиций", None, None, None, None, None),
    ("use_tt", "Таблица транспозиций", "bool", 0, 0, 0),
    ("hash_mb", "Размер хеша (МБ)", "int", 1, 512, 1),
    ("Алгоритм поиска", None, None, None, None, None),
    ("quiescence", "Поиск взятий (quiescence)", "bool", 0, 0, 0),
    ("q_depth", "Глубина поиска взятий", "int", 1, 16, 1),
    ("q_checks", "Шахи в quiescence", "bool", 0, 0, 0),
    ("delta_pruning", "Delta-отсечение в quiescence", "bool", 0, 0, 0),
    ("check_ext", "Расширение при шахе", "bool", 0, 0, 0),
    ("singular_ext", "Singular extensions", "bool", 0, 0, 0),
    ("singular_depth", "Мин. глубина singular", "int", 4, 16, 1),
    ("singular_margin", "Маржа singular (на ед. глубины)", "int", 1, 20, 1),
    ("aspiration", "Окна aspiration", "bool", 0, 0, 0),
    ("aspiration_delta", "Начальная ширина окна (сп)", "int", 5, 100, 5),
    ("iir", "Internal iterative reduction", "bool", 0, 0, 0),
    ("Отсечения", None, None, None, None, None),
    ("null_move", "Нулевой ход (null-move)", "bool", 0, 0, 0),
    ("null_verify", "Верификация null-move", "bool", 0, 0, 0),
    ("razoring", "Razoring", "bool", 0, 0, 0),
    ("razor_margin", "Маржа razoring (сп)", "int", 50, 600, 10),
    ("rfp", "Reverse futility (static null move)", "bool", 0, 0, 0),
    ("rfp_margin", "Маржа reverse futility (сп/глуб.)", "int", 30, 250, 5),
    ("probcut", "ProbCut", "bool", 0, 0, 0),
    ("probcut_margin", "Маржа ProbCut (сп)", "int", 50, 400, 10),
    ("futility", "Futility pruning", "bool", 0, 0, 0),
    ("futility_margin", "Маржа futility (сп/глуб.)", "int", 20, 200, 5),
    ("lmp", "Late move pruning", "bool", 0, 0, 0),
    ("see_pruning", "SEE-отсечения", "bool", 0, 0, 0),
    ("lmr", "Сокращение поздних ходов (LMR)", "bool", 0, 0, 0),
    ("lmr_strength", "Сила LMR (%)", "int", 25, 250, 5),
    ("Упорядочивание ходов", None, None, None, None, None),
    ("killers", "Killer-ходы", "bool", 0, 0, 0),
    ("countermoves", "Counter-move", "bool", 0, 0, 0),
    ("history", "History heuristic", "bool", 0, 0, 0),
    ("cont_history", "Continuation history", "bool", 0, 0, 0),
    ("Оценка позиции", None, None, None, None, None),
    ("use_pst", "Таблицы позиций фигур", "bool", 0, 0, 0),
    ("bishop_pair", "Пара слонов", "bool", 0, 0, 0),
    ("pawn_structure", "Структура пешек", "bool", 0, 0, 0),
    ("passed_pawns", "Проходные пешки", "bool", 0, 0, 0),
    ("passed_w", "Вес проходных (%)", "int", 0, 300, 5),
    ("rook_files", "Ладьи на открытых линиях / 7-я", "bool", 0, 0, 0),
    ("mobility", "Мобильность фигур", "bool", 0, 0, 0),
    ("mobility_w", "Вес мобильности (%)", "int", 0, 300, 5),
    ("king_safety", "Безопасность короля", "bool", 0, 0, 0),
    ("king_safety_w", "Вес безопасности короля (%)", "int", 0, 300, 5),
    ("threats", "Угрозы (фигуры под боем)", "bool", 0, 0, 0),
    ("threats_w", "Вес угроз (%)", "int", 0, 300, 5),
    ("space", "Пространство", "bool", 0, 0, 0),
    ("space_w", "Вес пространства (%)", "int", 0, 300, 5),
    ("outposts", "Форпосты коней/слонов", "bool", 0, 0, 0),
    ("mop_up", "Mop-up (добивание голого короля)", "bool", 0, 0, 0),
    ("endgame_scale", "Масштаб «ничейных» окончаний", "bool", 0, 0, 0),
    ("rule50_scale", "Затухание по правилу 50 ходов", "bool", 0, 0, 0),
    ("tempo_bonus", "Бонус хода (сп)", "int", 0, 40, 1),
    ("lazy_eval", "Lazy eval", "bool", 0, 0, 0),
    ("lazy_margin", "Порог lazy eval (сп)", "int", 200, 2000, 50),
    ("eval_cache", "Кэш оценки", "bool", 0, 0, 0),
    ("Дебютная книга (Polyglot .bin)", None, None, None, None, None),
    ("use_book", "Использовать книгу", "bool", 0, 0, 0),
    ("book_path", "Файл книги", "path", 0, 0, 0),
    ("book_best", "Всегда лучший ход книги", "bool", 0, 0, 0),
    ("book_max_ply", "Книга до полухода №", "int", 2, 60, 1),
    ("Таблицы Syzygy", None, None, None, None, None),
    ("syzygy_path", "Папка с таблицами", "path", 0, 0, 0),
    ("syzygy_probe_depth", "Мин. глубина для зондирования", "int", 1, 20, 1),
    ("syzygy_max_pieces", "Макс. фигур в таблицах", "int", 3, 7, 1),
    ("syzygy_50move", "Учитывать правило 50 ходов", "bool", 0, 0, 0),
    ("Анализ и подсказки", None, None, None, None, None),
    ("arrows", "Стрелок-подсказок (0 — выкл)", "int", 0, 5, 1),
    ("analysis_depth", "Глубина анализа", "int", 1, 24, 1),
    ("analysis_time_ms", "Время анализа (мс)", "int", 200, 30000, 100),
]


def squash(p: float) -> float:
    return math.copysign(abs(p) / (abs(p) + 2.5), p)


class App(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title("Шахматный движок")
        self.geometry("1180x760")
        self.minsize(900, 560)
        self.configure(bg=BG)

        self.board = chess.Board()
        self.sans: List[str] = []
        self.last_move: Optional[chess.Move] = None
        self.elo = 1500
        self.settings = settings_for_elo(self.elo)
        self.mode = "white"            # white | black | analysis (за кого играет человек)
        self.flipped = False
        self.selected: Optional[int] = None
        self.targets: List[chess.Move] = []
        self.info: Optional[Tuple[int, bool, Info]] = None   # (ply, turn, info)
        self.thinking = False
        self.job = 0
        self.cur_engine: Optional[Engine] = None
        self.hash = Hash()
        self.book_pending = False
        self.q: "queue.Queue" = queue.Queue()
        self._restart_id: Optional[str] = None
        self._syncing = False

        families = set(tkfont.families())
        self.piece_family = next((f for f in ("Segoe UI Symbol", "DejaVu Sans", "Noto Sans Symbols2",
                                              "Apple Symbols", "Arial Unicode MS") if f in families), "TkDefaultFont")

        self.vars: dict = {}
        self.show_eval = tk.BooleanVar(value=True)
        self.show_legal = tk.BooleanVar(value=True)
        self.show_coords = tk.BooleanVar(value=True)
        self.show_last = tk.BooleanVar(value=True)
        self.auto_flip = tk.BooleanVar(value=True)
        self.theme = tk.StringVar(value="Зелёная")

        self._style()
        self._build()
        self.bind("<f>", lambda e: self.flip())
        self.bind("<F>", lambda e: self.flip())
        self.after(60, self.poll)
        self.refresh()

    # ------------------------------------------------------------------ UI
    def _style(self) -> None:
        st = ttk.Style(self)
        try:
            st.theme_use("clam")
        except tk.TclError:
            pass
        st.configure("TNotebook", background=BG, borderwidth=0)
        st.configure("TNotebook.Tab", background=PANEL, foreground=FG, padding=(14, 6))
        st.map("TNotebook.Tab", background=[("selected", "#3f3f46")])
        st.configure("TFrame", background=BG)

    def _label(self, parent, text="", **kw) -> tk.Label:
        kw.setdefault("bg", parent["bg"] if "bg" in parent.keys() else BG)
        kw.setdefault("fg", FG)
        return tk.Label(parent, text=text, **kw)

    def _button(self, parent, text, cmd, **kw) -> tk.Button:
        return tk.Button(parent, text=text, command=cmd, bg="#3f3f46", fg=FG, activebackground="#52525b",
                         activeforeground=FG, relief="flat", bd=0, padx=8, pady=6, cursor="hand2", **kw)

    def _build(self) -> None:
        self.canvas = tk.Canvas(self, bg=BG, highlightthickness=0)
        self.canvas.pack(side="left", fill="both", expand=True)
        self.canvas.bind("<Configure>", lambda e: self.redraw())
        self.canvas.bind("<Button-1>", self.on_click)

        side = tk.Frame(self, bg=BG, width=380)
        side.pack(side="right", fill="y", padx=(0, 10), pady=10)
        side.pack_propagate(False)

        # --- строка Эло рядом с настройками ---
        top = tk.Frame(side, bg=PANEL)
        top.pack(fill="x", pady=(0, 8), ipady=4)
        self._label(top, "♞ Эло:", bg=PANEL, font=("TkDefaultFont", 11, "bold")).pack(side="left", padx=(10, 6))
        self.elo_var = tk.StringVar(value=str(self.elo))
        vcmd = (self.register(lambda s: s == "" or (s.isdigit() and len(s) <= 4)), "%P")
        self.elo_entry = tk.Entry(top, textvariable=self.elo_var, width=5, justify="center", validate="key",
                                  validatecommand=vcmd, bg="#3f3f46", fg="#6ee7b7", insertbackground=FG,
                                  relief="flat", font=("TkFixedFont", 12, "bold"))
        self.elo_entry.pack(side="left", ipady=3)
        self.elo_entry.bind("<Return>", lambda e: self.apply_elo())
        self._button(top, "OK", self.apply_elo).pack(side="left", padx=6)
        self.elo_note = self._label(top, f"макс. {MAX_ELO}", bg=PANEL, fg="#a1a1aa", font=("TkDefaultFont", 9))
        self.elo_note.pack(side="left", padx=4)

        nb = ttk.Notebook(side)
        nb.pack(fill="both", expand=True)
        game = tk.Frame(nb, bg=BG)
        sett = tk.Frame(nb, bg=BG)
        nb.add(game, text="Игра")
        nb.add(sett, text="Настройки")
        self._build_game(game)
        self._build_settings(sett)

    def _build_game(self, f: tk.Frame) -> None:
        self.status = self._label(f, "", bg=PANEL, anchor="w", padx=10, pady=8, font=("TkDefaultFont", 11, "bold"))
        self.status.pack(fill="x", pady=(8, 6))

        row = tk.Frame(f, bg=BG)
        row.pack(fill="x")
        for i, (m, name) in enumerate((("white", "Белыми"), ("black", "Чёрными"), ("analysis", "Анализ"))):
            self._button(row, name, lambda m=m: self.new_game(m)).grid(row=0, column=i, sticky="ew", padx=2)
            row.columnconfigure(i, weight=1)

        row2 = tk.Frame(f, bg=BG)
        row2.pack(fill="x", pady=6)
        for i, (name, cmd) in enumerate((("⇅ Развернуть (F)", self.flip), ("↶ Отменить ход", self.undo),
                                         ("★ Лучший ход", self.best_move),
                                         ("➚ Стрелки вкл/выкл", self.toggle_arrows))):
            self._button(row2, name, cmd).grid(row=i // 2, column=i % 2, sticky="ew", padx=2, pady=2)
            row2.columnconfigure(i % 2, weight=1)

        self._label(f, "АНАЛИЗ", fg=ACCENT, font=("TkDefaultFont", 9, "bold"), anchor="w").pack(fill="x", pady=(6, 0))
        self.ana_head = self._label(f, "—", fg="#a1a1aa", anchor="w", font=("TkFixedFont", 9))
        self.ana_head.pack(fill="x")
        self.ana_text = tk.Text(f, height=6, bg=PANEL, fg=FG, relief="flat", font=("TkFixedFont", 10),
                                state="disabled", wrap="word")
        self.ana_text.pack(fill="x", pady=(2, 6))
        for i, c in enumerate(ARROW_COLORS):
            self.ana_text.tag_configure(f"c{i}", foreground=c)

        self._label(f, "ХОДЫ", fg=ACCENT, font=("TkDefaultFont", 9, "bold"), anchor="w").pack(fill="x")
        self.moves_text = tk.Text(f, bg=PANEL, fg=FG, relief="flat", font=("TkFixedFont", 10), state="disabled")
        self.moves_text.pack(fill="both", expand=True, pady=(2, 0))

    def _build_settings(self, f: tk.Frame) -> None:
        canvas = tk.Canvas(f, bg=BG, highlightthickness=0)
        sb = ttk.Scrollbar(f, orient="vertical", command=canvas.yview)
        inner = tk.Frame(canvas, bg=BG)
        inner.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        win = canvas.create_window((0, 0), window=inner, anchor="nw")
        canvas.bind("<Configure>", lambda e: canvas.itemconfigure(win, width=e.width))
        canvas.configure(yscrollcommand=sb.set)
        canvas.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")
        canvas.bind_all("<MouseWheel>", lambda e: canvas.yview_scroll(int(-e.delta / 120), "units"))
        canvas.bind_all("<Button-4>", lambda e: canvas.yview_scroll(-1, "units"))
        canvas.bind_all("<Button-5>", lambda e: canvas.yview_scroll(1, "units"))

        for key, label, kind, lo, hi, step in SPECS:
            if kind is None:
                self._label(inner, key.upper(), fg=ACCENT, font=("TkDefaultFont", 9, "bold"),
                            anchor="w").pack(fill="x", padx=6, pady=(10, 2))
                continue
            val = getattr(self.settings, key)
            if kind == "bool":
                var = tk.BooleanVar(value=val)
                tk.Checkbutton(inner, text=label, variable=var, bg=BG, fg=FG, selectcolor=PANEL,
                               activebackground=BG, activeforeground=FG, anchor="w",
                               command=self.on_setting).pack(fill="x", padx=6)
            elif kind == "path":
                var = tk.StringVar(value=val)
                self._label(inner, label, anchor="w").pack(fill="x", padx=6)
                row = tk.Frame(inner, bg=BG)
                row.pack(fill="x", padx=6, pady=(0, 4))
                ent = tk.Entry(row, textvariable=var, bg=PANEL, fg=FG, insertbackground=FG, relief="flat")
                ent.pack(side="left", fill="x", expand=True, ipady=3)
                ent.bind("<Return>", lambda e: self.on_setting())
                ent.bind("<FocusOut>", lambda e: self.on_setting())
                self._button(row, "…", lambda v=var, k=key: self.browse(v, k)).pack(side="left", padx=(4, 0))
            else:
                var = tk.DoubleVar(value=val) if kind == "float" else tk.IntVar(value=val)
                tk.Scale(inner, label=label, variable=var, from_=lo, to=hi, resolution=step, orient="horizontal",
                         bg=BG, fg=FG, troughcolor=PANEL, highlightthickness=0, activebackground=ACCENT,
                         command=lambda _v: self.on_setting()).pack(fill="x", padx=6)
            self.vars[key] = var

        self._button(inner, "Очистить хеш", self.hash.clear).pack(fill="x", padx=6, pady=(10, 0))
        self._label(inner, "ДОСКА", fg=ACCENT, font=("TkDefaultFont", 9, "bold"),
                    anchor="w").pack(fill="x", padx=6, pady=(10, 2))
        om = tk.OptionMenu(inner, self.theme, *THEMES.keys(), command=lambda _v: self.redraw())
        om.configure(bg=PANEL, fg=FG, activebackground="#3f3f46", relief="flat", highlightthickness=0)
        om.pack(fill="x", padx=6, pady=2)
        for text, var in (("Шкала оценки", self.show_eval), ("Возможные ходы", self.show_legal),
                          ("Координаты", self.show_coords), ("Подсветка последнего хода", self.show_last),
                          ("Авто-разворот при выборе цвета", self.auto_flip)):
            tk.Checkbutton(inner, text=text, variable=var, bg=BG, fg=FG, selectcolor=PANEL, activebackground=BG,
                           activeforeground=FG, anchor="w",
                           command=lambda: (self.redraw(), self.schedule_restart())).pack(fill="x", padx=6)

    # ------------------------------------------------------------ settings
    def on_setting(self) -> None:
        if self._syncing:
            return
        for key, var in self.vars.items():
            try:
                setattr(self.settings, key, var.get())
            except tk.TclError:
                pass
        self.elo_note.config(text="настройки изменены вручную")
        self.schedule_restart()

    def browse(self, var: tk.StringVar, key: str) -> None:
        if key == "syzygy_path":
            p = filedialog.askdirectory(title="Папка с таблицами Syzygy")
        else:
            p = filedialog.askopenfilename(title="Книга Polyglot", filetypes=[("Polyglot", "*.bin"), ("Все", "*.*")])
        if p:
            var.set(p)
            self.on_setting()

    def apply_elo(self) -> None:
        txt = self.elo_var.get().strip()
        if not txt:
            self.elo_note.config(text="введите число")
            return
        raw = int(txt)
        self.elo = clamp_elo(raw)
        self.elo_var.set(str(self.elo))
        self.settings = settings_for_elo(self.elo, self.settings)
        self._syncing = True
        for key, var in self.vars.items():
            var.set(getattr(self.settings, key))
        self._syncing = False
        self.elo_note.config(text=f"максимум {MAX_ELO}: выставлено {self.elo}" if raw > MAX_ELO
                             else f"подобрано под Эло {self.elo}")
        self.schedule_restart()

    # --------------------------------------------------------------- state
    @property
    def engine_color(self) -> Optional[bool]:
        if self.mode == "analysis":
            return None
        return chess.BLACK if self.mode == "white" else chess.WHITE

    def engine_turn(self) -> bool:
        return not self.board.is_game_over() and self.board.turn == self.engine_color

    def human_turn(self) -> bool:
        return not self.board.is_game_over() and not self.engine_turn()

    def new_game(self, mode: str) -> None:
        self.mode = mode
        self.board = chess.Board()
        self.sans.clear()
        self.last_move = None
        self.info = None
        self.selected = None
        self.targets = []
        if self.auto_flip.get():
            self.flipped = mode == "black"
        self.refresh()

    def flip(self) -> None:
        self.flipped = not self.flipped
        self.redraw()

    def undo(self) -> None:
        if not self.board.move_stack:
            return
        n = 1 if self.mode == "analysis" or self.engine_turn() else 2
        for _ in range(min(n, len(self.board.move_stack))):
            self.board.pop()
            self.sans.pop()
        self.last_move = self.board.peek() if self.board.move_stack else None
        self.info = None
        self.selected = None
        self.targets = []
        self.refresh()

    def toggle_arrows(self) -> None:
        v = self.vars["arrows"]
        v.set(0 if self.settings.arrows > 0 else 3)
        self.on_setting()
        self.redraw()

    def best_move(self) -> None:
        lines = self.visible_lines()
        if lines and self.human_turn():
            self.make_move(lines[0].move)

    def make_move(self, move: chess.Move) -> None:
        self.sans.append(self.board.san(move))
        self.board.push(move)
        self.last_move = move
        self.selected = None
        self.targets = []
        self.refresh()

    def refresh(self) -> None:
        self.update_texts()
        self.redraw()
        self.restart_search()

    # -------------------------------------------------------------- search
    def schedule_restart(self) -> None:
        if self._restart_id:
            self.after_cancel(self._restart_id)
        self._restart_id = self.after(350, self.restart_search)

    def restart_search(self) -> None:
        self._restart_id = None
        if self.cur_engine:
            self.cur_engine.stop_flag = True
        self.job += 1
        self.thinking = False
        if self.board.is_game_over():
            self.update_texts()
            return
        s = self.settings
        eng_turn = self.engine_turn()
        if not eng_turn and s.arrows <= 0 and not self.show_eval.get():
            self.update_texts()
            return
        cfg = Settings(**asdict(s))
        engine = Engine(cfg, self.hash)
        if eng_turn:
            depth, tms, mpv = s.depth, s.time_ms, engine.multipv_for_play()
            mv = engine.book_move(self.board)
            if mv is not None:                      # ход из дебютной книги — без поиска
                self.thinking = False
                ply = len(self.board.move_stack)
                self.info = None
                self.after(350, lambda mv=mv, ply=ply: self.apply_engine_move(mv, ply))
                self.update_texts()
                return
        else:
            cfg.quiescence, cfg.q_depth, cfg.use_tt = True, max(8, s.q_depth), True
            cfg.check_ext, cfg.null_move, cfg.lmr = True, True, True
            cfg.use_skill, cfg.noise, cfg.mistake_chance = False, 0, 0.0   # подсказки — без искусственных ошибок
            depth, tms, mpv = s.analysis_depth, s.analysis_time_ms, max(1, s.arrows)
        self.cur_engine = engine
        job, board = self.job, self.board.copy()
        ply, turn = len(board.move_stack), board.turn
        self.thinking = True

        def run() -> None:
            res = engine.search(board, depth, tms, mpv,
                                on_info=lambda i: self.q.put(("info", job, ply, turn, i)))
            self.q.put(("done", job, ply, turn, res, eng_turn, engine))

        threading.Thread(target=run, daemon=True).start()
        self.update_texts()

    def poll(self) -> None:
        dirty = False
        try:
            while True:
                msg = self.q.get_nowait()
                if msg[1] != self.job:
                    continue
                if msg[0] == "info":
                    self.info = (msg[2], msg[3], msg[4])
                    dirty = True
                else:
                    _, _, ply, _, res, eng_turn, engine = msg
                    self.thinking = False
                    dirty = True
                    if eng_turn and res and ply == len(self.board.move_stack):
                        mv = engine.pick(res, ply)
                        self.after(350, lambda mv=mv, ply=ply: self.apply_engine_move(mv, ply))
        except queue.Empty:
            pass
        if dirty:
            self.update_texts()
            self.redraw()
        self.after(60, self.poll)

    def apply_engine_move(self, mv: chess.Move, ply: int) -> None:
        if ply == len(self.board.move_stack) and mv in self.board.legal_moves:
            self.make_move(mv)

    # ------------------------------------------------------------ geometry
    def layout(self):
        w, h = max(self.canvas.winfo_width(), 100), max(self.canvas.winfo_height(), 100)
        margin = 10
        bar_w = max(26, min(40, int((min(w, h) / 8) * 0.5))) if self.show_eval.get() else 0
        gap = 10 if bar_w else 0
        size = min(w - bar_w - gap - 2 * margin, h - 2 * margin)
        size = max(size, 80)
        cell = size / 8
        ox = margin + bar_w + gap
        oy = (h - size) / 2
        return ox, oy, cell, bar_w, margin

    def sq_xy(self, sq: int, ox: float, oy: float, cell: float) -> Tuple[float, float]:
        f, r = chess.square_file(sq), chess.square_rank(sq)
        col = 7 - f if self.flipped else f
        row = r if self.flipped else 7 - r
        return ox + col * cell, oy + row * cell

    def xy_sq(self, x: float, y: float) -> Optional[int]:
        ox, oy, cell, _, _ = self.layout()
        col, row = int((x - ox) // cell), int((y - oy) // cell)
        if not (0 <= col < 8 and 0 <= row < 8):
            return None
        f = 7 - col if self.flipped else col
        r = row if self.flipped else 7 - row
        return chess.square(f, r)

    # --------------------------------------------------------------- input
    def on_click(self, e) -> None:
        if not self.human_turn():
            return
        sq = self.xy_sq(e.x, e.y)
        if sq is None:
            return
        if self.selected is not None:
            moves = [m for m in self.targets if m.to_square == sq]
            if moves:
                move = moves[0]
                if move.promotion:
                    pt = self.ask_promotion()
                    move = chess.Move(move.from_square, sq, pt)
                self.make_move(move)
                return
        p = self.board.piece_at(sq)
        if p and p.color == self.board.turn and sq != self.selected:
            self.selected = sq
            self.targets = [m for m in self.board.legal_moves if m.from_square == sq]
        else:
            self.selected, self.targets = None, []
        self.redraw()

    def ask_promotion(self) -> int:
        win = tk.Toplevel(self)
        win.title("Превращение")
        win.configure(bg=BG)
        win.transient(self)
        result = {"pt": chess.QUEEN}

        def pick(pt: int) -> None:
            result["pt"] = pt
            win.destroy()

        for name, pt in (("Ферзь", chess.QUEEN), ("Ладья", chess.ROOK), ("Слон", chess.BISHOP), ("Конь", chess.KNIGHT)):
            self._button(win, name, lambda pt=pt: pick(pt)).pack(side="left", padx=6, pady=10)
        win.grab_set()
        self.wait_window(win)
        return result["pt"]

    # ------------------------------------------------------------- drawing
    def visible_lines(self):
        if not self.info or self.settings.arrows <= 0 or not self.human_turn():
            return []
        ply, _, inf = self.info
        if ply != len(self.board.move_stack) or not inf.lines:
            return []
        top = inf.lines[0].score
        return [l for l in inf.lines if l.score >= top - 300][: self.settings.arrows]

    def redraw(self) -> None:
        c = self.canvas
        c.delete("all")
        ox, oy, cell, bar_w, margin = self.layout()
        light, dark = THEMES[self.theme.get()]
        size = cell * 8

        for sq in chess.SQUARES:
            x, y = self.sq_xy(sq, ox, oy, cell)
            is_light = (chess.square_file(sq) + chess.square_rank(sq)) % 2 == 1
            c.create_rectangle(x, y, x + cell, y + cell, fill=light if is_light else dark, width=0)
            if self.show_last.get() and self.last_move and sq in (self.last_move.from_square, self.last_move.to_square):
                c.create_rectangle(x, y, x + cell, y + cell, fill="#f6e05e", stipple="gray50", width=0)
            if sq == self.selected:
                c.create_rectangle(x, y, x + cell, y + cell, fill="#60a5fa", stipple="gray50", width=0)

        if self.board.is_check():
            k = self.board.king(self.board.turn)
            if k is not None:
                x, y = self.sq_xy(k, ox, oy, cell)
                c.create_oval(x + cell * 0.08, y + cell * 0.08, x + cell * 0.92, y + cell * 0.92,
                              fill="#ef4444", stipple="gray50", width=0)

        # координаты (небольшие, в углах клеток)
        if self.show_coords.get():
            cf = (self.piece_family, -max(9, int(cell * 0.17)), "bold")
            for i in range(8):
                f = 7 - i if self.flipped else i
                sq_bottom = chess.square(f, 7 if self.flipped else 0)
                x, y = self.sq_xy(sq_bottom, ox, oy, cell)
                lt = (chess.square_file(sq_bottom) + chess.square_rank(sq_bottom)) % 2 == 1
                c.create_text(x + cell - 4, y + cell - 3, text="abcdefgh"[f], anchor="se", font=cf,
                              fill=dark if lt else light)
                r = i if self.flipped else 7 - i
                sq_left = chess.square(7 if self.flipped else 0, r)
                x, y = self.sq_xy(sq_left, ox, oy, cell)
                lt = (chess.square_file(sq_left) + chess.square_rank(sq_left)) % 2 == 1
                c.create_text(x + 3, y + 2, text=str(r + 1), anchor="nw", font=cf, fill=dark if lt else light)

        # возможные ходы
        if self.show_legal.get():
            for m in self.targets:
                x, y = self.sq_xy(m.to_square, ox, oy, cell)
                if self.board.is_capture(m):
                    c.create_oval(x + cell * 0.06, y + cell * 0.06, x + cell * 0.94, y + cell * 0.94,
                                  outline="#1f1f1f", width=max(2, int(cell * 0.07)), stipple="gray50")
                else:
                    r = cell * 0.15
                    c.create_oval(x + cell / 2 - r, y + cell / 2 - r, x + cell / 2 + r, y + cell / 2 + r,
                                  fill="#1f1f1f", stipple="gray50", width=0)

        # фигуры: размер ≈ 72% клетки — не огромные и не мелкие
        pf = (self.piece_family, -int(cell * 0.72))
        for sq, p in self.board.piece_map().items():
            x, y = self.sq_xy(sq, ox, oy, cell)
            cx, cy = x + cell / 2, y + cell / 2 + cell * 0.03
            g = GLYPH[p.piece_type]
            if p.color == chess.WHITE:
                for dx, dy in ((-1.3, 0), (1.3, 0), (0, -1.3), (0, 1.3), (-1, -1), (1, 1), (-1, 1), (1, -1)):
                    c.create_text(cx + dx, cy + dy, text=g, font=pf, fill="#111111")
                c.create_text(cx, cy, text=g, font=pf, fill="#ffffff")
            else:
                c.create_text(cx, cy, text=g, font=pf, fill="#1a1a1a")

        c.create_rectangle(ox, oy, ox + size, oy + size, outline="#000000")
        self.draw_arrows(ox, oy, cell)
        if bar_w:
            self.draw_eval(margin, oy, bar_w, size)

    def draw_arrows(self, ox: float, oy: float, cell: float) -> None:
        lines = self.visible_lines()
        for i in reversed(range(len(lines))):
            m = lines[i].move
            x1, y1 = self.sq_xy(m.from_square, ox, oy, cell)
            x2, y2 = self.sq_xy(m.to_square, ox, oy, cell)
            sx, sy, ex, ey = x1 + cell / 2, y1 + cell / 2, x2 + cell / 2, y2 + cell / 2
            dx, dy = ex - sx, ey - sy
            ln = math.hypot(dx, dy)
            if ln < 1:
                continue
            ux, uy = dx / ln, dy / ln
            nx, ny = -uy, ux
            w = max(0.07, 0.15 - i * 0.02) * cell / 2
            hw, hl = w * 2.6, cell * 0.34
            sx, sy = sx + ux * cell * 0.18, sy + uy * cell * 0.18
            ex, ey = ex - ux * cell * 0.08, ey - uy * cell * 0.08
            bx, by = ex - ux * hl, ey - uy * hl
            pts = [sx + nx * w, sy + ny * w, bx + nx * w, by + ny * w, bx + nx * hw, by + ny * hw, ex, ey,
                   bx - nx * hw, by - ny * hw, bx - nx * w, by - ny * w, sx - nx * w, sy - ny * w]
            self.canvas.create_polygon(pts, fill=ARROW_COLORS[i % 5], outline="#000000", width=1,
                                       stipple="" if i == 0 else "gray75")

    def eval_values(self) -> Tuple[Optional[float], Optional[int]]:
        """(пешки с точки зрения белых, мат-в-N или 0 при мате на доске)"""
        if self.board.is_checkmate():
            return None, 0
        if self.board.is_game_over():
            return 0.0, None
        if not self.info or not self.info[2].lines:
            return None, None
        _, turn, inf = self.info
        sign = 1 if turn == chess.WHITE else -1
        cp = inf.lines[0].score
        if abs(cp) > MATE - 1000:
            return None, sign * (1 if cp > 0 else -1) * math.ceil((MATE - abs(cp)) / 2)
        return cp * sign / 100, None

    def draw_eval(self, x: float, y: float, w: float, h: float) -> None:
        c = self.canvas
        pawns, mate = self.eval_values()
        if mate is not None:
            white_frac = 1.0 if (mate > 0 or (mate == 0 and self.board.turn == chess.BLACK)) else 0.0
            label = "#" if mate == 0 else f"M{abs(mate)}"
            white_leads = white_frac == 1.0
        elif pawns is not None:
            white_frac = 0.5 + 0.5 * squash(pawns)
            label = f"{pawns:+.1f}"
            white_leads = pawns >= 0
        else:
            white_frac, label, white_leads = 0.5, "—", True
        white_bottom = not self.flipped
        c.create_rectangle(x, y, x + w, y + h, fill="#27272a", width=0)
        if white_bottom:
            c.create_rectangle(x, y + h * (1 - white_frac), x + w, y + h, fill="#f4f4f5", width=0)
        else:
            c.create_rectangle(x, y, x + w, y + h * white_frac, fill="#f4f4f5", width=0)
        tf = (self.piece_family, -8, "bold")
        for t in (1, 2, 3, 5, 9):
            for sgn in (1, -1):
                frac = 0.5 + 0.5 * squash(sgn * t)
                py = y + h * ((1 - frac) if white_bottom else frac)
                inside_white = (frac <= white_frac)
                col = "#52525b" if inside_white else "#a1a1aa"
                c.create_line(x, py, x + w * 0.33, py, fill=col)
                c.create_text(x + w * 0.4, py, text=str(t), anchor="w", font=tf, fill=col)
        c.create_line(x, y + h / 2, x + w, y + h / 2, fill=ACCENT)
        at_bottom = white_leads == white_bottom
        c.create_text(x + w / 2, y + h - 8 if at_bottom else y + 8, text=label, font=(self.piece_family, -11, "bold"),
                      fill="#18181b" if white_leads else "#f4f4f5")
        c.create_rectangle(x, y, x + w, y + h, outline="#000000")

    # ---------------------------------------------------------------- text
    def update_texts(self) -> None:
        b = self.board
        if b.is_checkmate():
            st = f"Мат! Победили {'чёрные' if b.turn == chess.WHITE else 'белые'}"
        elif b.is_stalemate():
            st = "Пат — ничья"
        elif b.is_insufficient_material():
            st = "Ничья: недостаточно материала"
        elif b.is_game_over(claim_draw=True):
            st = "Ничья (повторение / 50 ходов)"
        else:
            st = f"Ход {'белых' if b.turn == chess.WHITE else 'чёрных'}{' — шах!' if b.is_check() else ''}"
            if self.engine_turn() and self.thinking:
                st += "  (движок думает…)"
        self.status.config(text=st)

        t = self.ana_text
        t.config(state="normal")
        t.delete("1.0", "end")
        if self.info and self.info[0] == len(b.move_stack) and self.info[2].lines:
            ply, turn, inf = self.info
            nps = int(inf.nodes / max(inf.time_ms, 1) * 1000)
            self.ana_head.config(text=f"глуб. {inf.depth}/{inf.seldepth} · {inf.nodes} узлов · {nps}/с · хеш {inf.hashfull // 10}%"
                                      + (f" · TB {inf.tbhits}" if inf.tbhits else "") + (" …" if self.thinking else ""))
            sign = 1 if turn == chess.WHITE else -1
            tmp = chess.Board(b.fen())
            for i, line in enumerate(inf.lines[: max(1, self.settings.arrows)]):
                pv_san = []
                for m in line.pv[:7]:
                    pv_san.append(tmp.san(m))
                    tmp.push(m)
                for _ in pv_san:
                    tmp.pop()
                t.insert("end", "● ", f"c{i % 5}")
                t.insert("end", f"{score_text(line.score * sign):>7}  {' '.join(pv_san)}\n")
        else:
            self.ana_head.config(text="—")
            t.insert("end", "Партия окончена" if b.is_game_over() else "Идёт расчёт…")
        t.config(state="disabled")

        mt = self.moves_text
        mt.config(state="normal")
        mt.delete("1.0", "end")
        for i in range(0, len(self.sans), 2):
            w = self.sans[i]
            bl = self.sans[i + 1] if i + 1 < len(self.sans) else ""
            mt.insert("end", f"{i // 2 + 1:>3}. {w:<8} {bl}\n")
        mt.see("end")
        mt.config(state="disabled")


if __name__ == "__main__":
    App().mainloop()
