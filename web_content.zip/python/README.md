# Шахматный движок (Python, tkinter + python-chess)

    pip install -r requirements.txt     # нужен Python 3.10+
    python main.py

## Что внутри

* `engine.py` — движок по мотивам Stockfish:
  * **поиск**: итеративное углубление, PVS, aspiration windows, MultiPV, таблица транспозиций
    (поколения + приоритет глубины, сохраняется между ходами), mate-distance pruning,
    расширения (шах, singular), IIR, razoring, reverse futility, null-move с верификацией,
    ProbCut, futility, late move pruning, SEE-отсечения, LMR (ln·ln, поправки improving / cut-node /
    history), quiescence (SEE, delta, шахи), killers, counter-move, history и continuation history,
    менеджер времени;
  * **оценка**: материал + PST, мобильность, безопасность короля, угрозы, пешечная структура
    (с кэшем), проходные, форпосты, ладьи, пространство, пара слонов, mop-up, масштаб ничейных
    окончаний, затухание по правилу 50 ходов, lazy eval, кэш оценки;
  * **сила**: Skill Level как в Stockfish (`pick_best`), шум / шанс ошибки / кандидаты, contempt;
  * **книга** Polyglot (`.bin`) и **таблицы Syzygy** (WDL в поиске, WDL/DTZ в корне).
* `main.py` — интерфейс: доска, стрелки-подсказки, шкала оценки, анализ, вкладка «Настройки»
  со всеми параметрами (у каждой функции — свой переключатель/ползунок), поле Эло.

## Эло

Поле Эло подбирает настройки автоматически (`settings_for_elo`), максимум — **2500**.
Калибровка: матчи против Stockfish 16 (`UCI_LimitStrength`) на одном ядре — при 1 с/ход движок
набирал ~50 % против UCI_Elo 1900 и 2200; верхний уровень в GUI думает до 5 с. Цифра ориентировочная
(малые выборки, шкала Stockfish ≠ шкала Lichess/FIDE).

## Заметки

* Потоков нет (GIL): Lazy SMP не реализован. Syzygy-код проверен только без реальных файлов таблиц.
* Веб-версия в корне проекта не менялась.
