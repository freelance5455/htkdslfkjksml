const http=require('http'),fs=require('fs'),path=require('path');
const P={},E={},U={soldiers:[4,10,250],tanks:[20,120,2500],rtanks:[299,1500,77777]},ON=20000;
const san=a=>{const o={};for(const k in U)o[k]=Math.max(0,Math.min(2000,Math.floor(Number(a&&a[k])||0)));return o};
const mk=a=>{const l=[];for(const k in U)for(let i=0;i<a[k];i++)l.push({k,d:U[k][0],h:U[k][1]});return l};
const hit=(l,d)=>{while(d>0&&l.length){if(d>=l[0].h){d-=l[0].h;l.shift()}else{l[0].h-=d;d=0}}};
const cnt=l=>{const o={soldiers:0,tanks:0,rtanks:0};l.forEach(u=>o[u.k]++);return o};
const diff=(a,b)=>{const o={};for(const k in U)o[k]=a[k]-b[k];return o};
function fight(a,d){const A=mk(a),D=mk(d);for(let r=0;r<1000&&A.length&&D.length;r++){const da=A.reduce((s,u)=>s+u.d,0),dd=D.reduce((s,u)=>s+u.d,0);hit(D,da);hit(A,dd)}
 const sa=cnt(A),sd=cnt(D);return{won:A.length>0&&D.length==0,sa,sd,lostA:diff(a,sa),lostD:diff(d,sd)}}
const val=l=>Object.keys(U).reduce((s,k)=>s+l[k]*U[k][2],0);
const body=req=>new Promise(r=>{let b='';req.on('data',c=>{b+=c;if(b.length>1e5)req.destroy()});req.on('end',()=>{try{r(JSON.parse(b||'{}'))}catch(e){r({})}})});
const send=(res,o,c=200)=>{res.writeHead(c,{'Content-Type':'application/json'});res.end(JSON.stringify(o))};
http.createServer(async(req,res)=>{
 res.setHeader('Access-Control-Allow-Origin','*');res.setHeader('Access-Control-Allow-Headers','Content-Type');if(req.method=='OPTIONS'){res.writeHead(204);return res.end()}
 if(req.method=='POST'&&req.url=='/api/sync'){const b=await body(req);if(!b.id)return send(res,{error:'bad'},400);
  P[b.id]={id:String(b.id).slice(0,16),name:String(b.name||'State').slice(0,16),lvl:Number(b.lvl)||0,army:san(b.army),seen:Date.now()};
  const now=Date.now(),players=Object.values(P).filter(p=>p.id!=b.id&&now-p.seen<ON);const events=E[b.id]||[];E[b.id]=[];return send(res,{players,events})}
 if(req.method=='POST'&&req.url=='/api/attack'){const b=await body(req),me=P[b.id],t=P[b.target];
  if(!me)return send(res,{error:'Sync first, try again in a few seconds'});if(!t||Date.now()-t.seen>=ON)return send(res,{error:'That player went offline'});
  me.army=san(b.army);const r=fight(me.army,t.army);me.army=r.sa;t.army=r.sd;
  const reward=r.won?500+Math.floor(val(r.lostD)/2):0;
  const msgA=r.won?`You beat ${t.name} and earned $${reward}`:`You lost to ${t.name}`;
  (E[t.id]=E[t.id]||[]).push({lost:r.lostD,defWon:!r.won,msg:r.won?`${me.name} attacked and won`:`${me.name} attacked and you held`});
  return send(res,{won:r.won,lostA:r.lostA,reward,msg:msgA})}
 if(req.method=='GET'&&req.url=='/icon.svg'){res.writeHead(200,{'Content-Type':'image/svg+xml'});return res.end(fs.readFileSync(path.join(__dirname,'icon.svg')))}
 if(req.method=='GET'&&req.url=='/icon.png'&&fs.existsSync(path.join(__dirname,'icon.png'))){res.writeHead(200,{'Content-Type':'image/png'});return res.end(fs.readFileSync(path.join(__dirname,'icon.png')))}
 if(req.method=='GET'){res.writeHead(200,{'Content-Type':'text/html'});return res.end(fs.readFileSync(path.join(__dirname,'index.html')))}
 res.writeHead(404);res.end()}).listen(process.env.PORT||3000,()=>console.log('States running on http://localhost:'+(process.env.PORT||3000)));
