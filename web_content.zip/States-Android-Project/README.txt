STATES - ANDROID APP STARTER
============================

This ZIP contains the States game (www/index.html) and a Capacitor Android wrapper project,
set up the same way as the Sam GPT project.

ANDROID BUILD (requires a computer with Node.js and Android Studio)
-------------------------------------------------------------------
1. Extract this ZIP.
2. Open a terminal in the extracted States-Android-Project folder.
3. Run: npm install
4. Run: npx cap add android
5. Run: npx cap sync android
6. Run: npx cap open android
7. In Android Studio, wait for Gradle sync, then build the APK using Build > Build Bundle(s) / APK(s) > Build APK(s).

If Android Studio says the Android platform already exists, skip step 4 and run npx cap sync android.

APP ICON
--------
assets/icon.png is the States icon (512x512). To apply it to the Android app after step 4, run:
npx @capacitor/assets generate --android
(this needs the icon at assets/icon.png, which is where it already is.)

TEST IN A BROWSER FIRST
-----------------------
Open www/index.html in a modern browser. The game saves to the browser every 30 seconds.

BATTLES WITH REAL PLAYERS (level 2)
-----------------------------------
Battles need an online server. Host server/server.js on any Node host (no packages needed:
node server/server.js), then open www/index.html and set the address on the first line of the script:
const SERVER='https://your-server.com';
Then run npx cap sync android again before building. With SERVER left empty the game works fully
offline and the Battle tab shows that battles need a server.
