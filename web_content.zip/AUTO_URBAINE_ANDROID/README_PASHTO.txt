AUTO URBAINE — د Android APK جوړولو پروژه

دا پروژه ستا موجوده ویب اپلیکیشن د Android WebView په وسیله په Android اپلیکیشن کې رانغاړي.

د APK جوړولو لپاره:
1) په کمپیوټر کې Android Studio نصب کړه.
2) Android Studio خلاص کړه او Open وټاکه.
3) د AUTO_URBAINE_ANDROID فولډر انتخاب کړه.
4) د Gradle Sync بشپړېدو ته انتظار وباسه.
5) له مینو Build > Build Bundle(s) / APK(s) > Build APK(s) وټاکه.
6) د جوړ شوي APK لپاره د خبرتیا پر Locate کلیک وکړه. عموماً مسیر app/build/outputs/apk/debug/app-debug.apk وي.

مهم:
- دا د APK د جوړولو Android Studio پروژه ده؛ APK په دې چاپېریال کې نه شو جوړولای، ځکه Android SDK/Build Tools نه شته.
- د اپلیکیشن د login، ثبت، booking، driver او admin API لپاره Backend سرور لا هم اړین دی.
- په app.js کې API_BASE اوس تش دی. د خپل فعال HTTPS API ادرس باید د اپلیکیشن د خپرولو مخکې تنظیم شي.
- د backend پرته به اپلیکیشن پرانیستل کېږي، خو د سرور پورې تړلي کارونه به کار نه کوي.
