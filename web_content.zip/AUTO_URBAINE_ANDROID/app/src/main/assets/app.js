/* AUTO URBAINE PWA frontend. Configure API_BASE below before connecting to a deployed backend. */
const API_BASE = (localStorage.getItem("au_api_base") || "").replace(/\/$/, "");
const $ = (s) => document.querySelector(s);
const $$ = (s) => [...document.querySelectorAll(s)];
const authView = $("#authView"), dashboardView = $("#dashboardView");
let mode = "login", session = null, installPrompt = null;
const statusLabels = {requested:"En attente",accepted:"Acceptée",driver_arriving:"Chauffeur en route",in_progress:"En cours",completed:"Terminée",cancelled:"Annulée",pending:"En attente",approved:"Approuvé",rejected:"Refusé",suspended:"Suspendu"};
const euro = n => new Intl.NumberFormat("fr-FR",{style:"currency",currency:"EUR"}).format(Number(n||0));
const esc = s => String(s ?? "").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
function message(el,text,type=""){el.textContent=text;el.className="message"+(type?" "+type:"");}
function showNotice(text){$("#notice").textContent=text;$("#notice").classList.remove("hidden");}
function hideNotice(){$("#notice").classList.add("hidden");}
function getToken(){return session?.token || localStorage.getItem("au_token");}
async function api(path, options={}){
  if(!API_BASE) throw new Error("Le serveur API n’est pas configuré. Définissez API_BASE dans app.js puis redéployez l’application.");
  const headers={"Content-Type":"application/json",...(options.headers||{})};
  if(getToken())headers.Authorization=`Bearer ${getToken()}`;
  const res=await fetch(API_BASE+path,{...options,headers});
  const data=await res.json().catch(()=>({}));
  if(!res.ok)throw new Error(data.error||`Erreur serveur (${res.status})`);
  return data;
}
function setMode(next){mode=next;$$(".tab").forEach(b=>b.classList.toggle("active",b.dataset.mode===mode));$("#nameWrap").classList.toggle("hidden",mode!=="register");$("#roleWrap").classList.toggle("hidden",mode!=="register");$("#authTitle").textContent=mode==="login"?"Bon retour":"Créer un compte";$("#authSubtitle").textContent=mode==="login"?"Connectez-vous pour continuer.":"Rejoignez AUTO URBAINE en quelques étapes.";$("#authSubmit").innerHTML=(mode==="login"?"Se connecter":"Créer mon compte")+' <span>→</span>';$("#authForm").elements.password.autocomplete=mode==="login"?"current-password":"new-password";message($("#authMessage"),"");}
$$(".tab").forEach(b=>b.addEventListener("click",()=>setMode(b.dataset.mode)));
$("#authForm").addEventListener("submit",async e=>{
  e.preventDefault();const f=new FormData(e.currentTarget);const payload={email:f.get("email"),password:f.get("password")};
  if(mode==="register"){payload.fullName=f.get("fullName");payload.phone=f.get("phone")||null;payload.role=f.get("role")||"passenger";}
  const btn=$("#authSubmit");btn.disabled=true;message($("#authMessage"),"Connexion au serveur…");
  try{
    const data=await api(mode==="login"?"/api/auth/login":"/api/auth/register",{method:"POST",body:JSON.stringify(payload)});
    const token=data.token||data.accessToken||data.access_token;
    const user=data.user||data;
    if(!token)throw new Error("Le serveur n’a pas renvoyé de jeton de connexion. Vérifiez le format de réponse de /api/auth.");
    session={token,user};localStorage.setItem("au_token",token);localStorage.setItem("au_user",JSON.stringify(user));renderDashboard();
  }catch(err){message($("#authMessage"),err.message,"error");}finally{btn.disabled=false;}
});
function restoreSession(){try{const token=localStorage.getItem("au_token"),user=JSON.parse(localStorage.getItem("au_user")||"null");if(token&&user){session={token,user};renderDashboard();}}catch{}}
function role(){return String(session?.user?.role||"passenger").toLowerCase();}
function renderDashboard(){
  authView.classList.add("hidden");dashboardView.classList.remove("hidden");$("#logoutBtn").classList.remove("hidden");
  const r=role(),user=session.user;$("#welcomeTitle").textContent=`Bonjour${user.full_name||user.fullName?" "+(user.full_name||user.fullName):""} 👋`;$("#roleBadge").textContent=({passenger:"PASSAGER",driver:"CHAUFFEUR",admin:"ADMINISTRATEUR"})[r]||r.toUpperCase();
  ["passenger","driver","admin"].forEach(x=>$("#"+x+"Panel").classList.toggle("hidden",r!==x));
  if(r==="passenger"){updateFare();loadPassengerBookings();}if(r==="driver")loadDriverBookings();if(r==="admin"){loadAdminSummary();loadAdminDrivers();}
}
function logout(){session=null;localStorage.removeItem("au_token");localStorage.removeItem("au_user");dashboardView.classList.add("hidden");authView.classList.remove("hidden");$("#logoutBtn").classList.add("hidden");hideNotice();}
$("#logoutBtn").addEventListener("click",logout);
function updateFare(){const f=$("#bookingForm");if(!f)return;const d=Number(f.elements.distanceKm.value),m=Number(f.elements.durationMin.value);const estimate=3+d*1.8+m*.3+1;$("#fareValue").textContent=euro(Math.round(estimate*100)/100);}
["distanceKm","durationMin"].forEach(n=>$("#bookingForm").elements[n].addEventListener("input",updateFare));
$("#bookingForm").addEventListener("submit",async e=>{
  e.preventDefault();const f=new FormData(e.currentTarget);const payload={pickup:f.get("pickup"),destination:f.get("destination"),pickupLat:Number(f.get("pickupLat")),pickupLng:Number(f.get("pickupLng")),destinationLat:Number(f.get("destinationLat")),destinationLng:Number(f.get("destinationLng")),distanceKm:Number(f.get("distanceKm")),durationMin:Number(f.get("durationMin")),paymentMethod:f.get("paymentMethod")};
  const btn=e.currentTarget.querySelector("button[type=submit]");btn.disabled=true;message($("#bookingMessage"),"Envoi de votre demande…");
  try{const booking=await api("/api/bookings",{method:"POST",body:JSON.stringify(payload)});message($("#bookingMessage"),"Demande envoyée ! "+(booking.nearbyDrivers?.length?`${booking.nearbyDrivers.length} chauffeur(s) proche(s) trouvé(s).`:"Nous recherchons un chauffeur."),"success");await loadPassengerBookings();}
  catch(err){message($("#bookingMessage"),err.message,"error");}finally{btn.disabled=false;}
});
function bookingCard(b,actions=""){
  const pickup=b.pickup||b.pickup_address||"Départ",dest=b.destination||b.destination_address||"Destination",price=b.estimatedFare??b.estimated_fare_eur;
  return `<article class="booking-card"><div><h3>${esc(pickup)} <span style="color:#9aa1a7">→</span> ${esc(dest)}</h3><p>Réf. ${esc(b.id||"—")} · ${esc(b.createdAt||b.created_at||"")}</p><span class="status ${esc(b.status)}">${esc(statusLabels[b.status]||b.status||"Inconnu")}</span>${actions}</div><div class="price">${euro(price)}</div></article>`;
}
async function loadPassengerBookings(){const box=$("#bookingList");box.innerHTML='<div class="empty">Chargement des réservations…</div>';try{const rows=await api("/api/bookings");box.innerHTML=rows.length?rows.map(b=>bookingCard(b)).join(""):'<div class="empty">Aucune réservation pour le moment. Votre prochain trajet commence ici.</div>';}catch(err){box.innerHTML=`<div class="empty">${esc(err.message)}</div>`;}}
$("#refreshBookings").addEventListener("click",loadPassengerBookings);
async function loadDriverBookings(){const box=$("#driverBookingList");box.innerHTML='<div class="empty">Chargement des courses…</div>';try{const rows=await api("/api/bookings");box.innerHTML=rows.length?rows.map(b=>{const action=b.status==="requested"?`<div class="card-actions"><button class="primary-btn" data-accept="${esc(b.id)}">Accepter la course →</button></div>`:b.driver_id===session.user.id||b.driverId===session.user.id?`<div class="card-actions"><select data-status="${esc(b.id)}"><option value="">Changer le statut…</option><option value="driver_arriving">Chauffeur en route</option><option value="in_progress">En cours</option><option value="completed">Terminée</option><option value="cancelled">Annulée</option></select></div>`:"";return bookingCard(b,action);}).join(""):'<div class="empty">Aucune course disponible pour le moment.</div>';}catch(err){box.innerHTML=`<div class="empty">${esc(err.message)}</div>`;}}
$("#refreshDriver").addEventListener("click",loadDriverBookings);
$("#driverBookingList").addEventListener("click",async e=>{const btn=e.target.closest("[data-accept]");if(!btn)return;btn.disabled=true;try{await api(`/api/bookings/${encodeURIComponent(btn.dataset.accept)}/accept`,{method:"PATCH",body:"{}"});await loadDriverBookings();}catch(err){alert(err.message);btn.disabled=false;}});
$("#driverBookingList").addEventListener("change",async e=>{const sel=e.target.closest("[data-status]");if(!sel||!sel.value)return;try{await api(`/api/bookings/${encodeURIComponent(sel.dataset.status)}/status`,{method:"PATCH",body:JSON.stringify({status:sel.value})});await loadDriverBookings();}catch(err){alert(err.message);}});
$("#locationForm").addEventListener("submit",async e=>{e.preventDefault();const f=new FormData(e.currentTarget);try{await api("/api/drivers/me/location",{method:"PUT",body:JSON.stringify({lat:Number(f.get("lat")),lng:Number(f.get("lng")),online:f.get("online")==="on"})});message($("#locationMessage"),"Position mise à jour.","success");}catch(err){message($("#locationMessage"),err.message,"error");}});
async function loadAdminSummary(){const box=$("#adminSummary");box.innerHTML='<div class="empty">Chargement…</div>';try{const d=await api("/api/admin/summary");const users=(d.users||[]).reduce((n,x)=>n+Number(x.count),0),bookings=(d.bookings||[]).reduce((n,x)=>n+Number(x.count),0),completed=(d.bookings||[]).find(x=>x.status==="completed")?.count||0;box.innerHTML=[["UTILISATEURS",users],["RÉSERVATIONS",bookings],["COURSES TERMINÉES",completed],["CHIFFRE ESTIMÉ",euro(d.completedFareTotalEUR)],["CHAUFFEURS", (d.drivers||[]).reduce((n,x)=>n+Number(x.count),0)]].map(x=>`<div class="summary-card"><small>${esc(x[0])}</small><strong>${esc(x[1])}</strong></div>`).join("");}catch(err){box.innerHTML=`<div class="empty">${esc(err.message)}</div>`;}}
async function loadAdminDrivers(){const box=$("#adminDriverList");box.innerHTML='<div class="empty">Chargement…</div>';try{const rows=await api("/api/admin/drivers");box.innerHTML=rows.length?rows.map(d=>`<article class="booking-card"><div><h3>${esc(d.fullName||d.full_name)} · ${esc(d.email)}</h3><p>${esc(d.vehicleMake||"Véhicule")} ${esc(d.vehicleModel||"")} · ${esc(d.vehicleRegistration||"Immatriculation non renseignée")}</p><span class="status ${esc(d.verificationStatus)}">${esc(statusLabels[d.verificationStatus]||d.verificationStatus)}</span><div class="card-actions"><button class="secondary-btn" data-verify="${esc(d.id)}" data-value="approved">Approuver</button><button class="secondary-btn" data-verify="${esc(d.id)}" data-value="rejected">Refuser</button><button class="secondary-btn" data-verify="${esc(d.id)}" data-value="suspended">Suspendre</button></div></div></article>`).join(""):'<div class="empty">Aucun profil chauffeur.</div>';}catch(err){box.innerHTML=`<div class="empty">${esc(err.message)}</div>`;}}
$("#refreshAdmin").addEventListener("click",()=>{loadAdminSummary();loadAdminDrivers();});
$("#adminDriverList").addEventListener("click",async e=>{const btn=e.target.closest("[data-verify]");if(!btn)return;btn.disabled=true;try{await api(`/api/admin/drivers/${encodeURIComponent(btn.dataset.verify)}/verification`,{method:"PATCH",body:JSON.stringify({status:btn.dataset.value})});await loadAdminDrivers();}catch(err){alert(err.message);btn.disabled=false;}});
window.addEventListener("beforeinstallprompt",e=>{e.preventDefault();installPrompt=e;$("#installBtn").classList.remove("hidden");});
$("#installBtn").addEventListener("click",async()=>{if(!installPrompt)return;installPrompt.prompt();await installPrompt.userChoice;installPrompt=null;$("#installBtn").classList.add("hidden");});
if("serviceWorker" in navigator && location.protocol.startsWith("http"))navigator.serviceWorker.register("./sw.js").catch(()=>{});
$("#year").textContent=new Date().getFullYear();
restoreSession();
