# VOLTRON XV6 - AI gold scalping bot

Folders
- site/       the VOLTRON XV6 website (index.html). The app is inside it at site/app/
- server/     voltron-server.js (broker connection, license keys, email)
- capacitor.config.json, package.json   to build an Android APK from site/app

## 1. Run the server (Node 22+)
ADMIN_PASSWORD='choose-a-strong-one' SMTP_PASS='gmail-app-password' node server/voltron-server.js
Real prices for demo users: TWELVEDATA_KEY or FINNHUB_KEY. Optional: CTRADER_CLIENT_ID + CTRADER_CLIENT_SECRET (cTrader), APP_URL, LIVE_ENABLED=1 (real money, leave off until tested).
Host it on an HTTPS service that runs Node.

## 2. Point the app at the server
Open site/app/index.html, find  const API='',  and put your server address in the quotes.

## 3. Put the site online
Upload the site folder to any HTTPS host. The website opens at your address and the app at your address/app/.
On Android, open the app address in Chrome, then menu > Install app.

## 4. Android APK
Easy: pwabuilder.com, enter your app address. Manual: npm install, npm run android, then Build APK in Android Studio.
After you have an APK, set APK_URL in site/index.html to enable the Download button.

The app has no AI service inside it and makes no calls to any AI company. Start on a demo account. No strategy guarantees profit.

## Markets
Gold (XAU/USD), USD/JPY, GBP/USD, Nasdaq 100 and US 30. Pick the market at the top of the Trade tab. Each market keeps its own stop-loss and spread settings. Market names on your broker can differ, and stock-index contract sizes vary, so check on a demo account first.

## MT5 for all users
Set METAAPI_TOKEN on the server (or save it in the Admin tab). Each user then enters only their MT5 login, password and server, and trades on their own account. MetaApi bills for the cloud accounts, and its free tier is small. Handling other people's broker logins is a serious responsibility.

## 24/7 bot and saved candles
- The server saves every 1-minute candle for all five markets to the data folder (DATA_DIR, default ./data) while each market is open. In the app, open Scan > Saved candles to review them or download a CSV.
- Start the bot with Bot > Start 24/7 bot. It then trades on the server while the app is closed. Users reconnect their broker after a server restart, because passwords are not saved.
- Render free plan: the service sleeps after 15 minutes without visits, which stops the bot and the collector, and the disk is wiped on every restart. For real 24/7 use a paid always-on instance with a persistent disk (set DATA_DIR to its mount path), or ping https://YOUR-ADDRESS/health every 5 minutes (for example with UptimeRobot) and download the CSV regularly.

## Smart-money strategies
Fair value gap, inverse FVG, order block, breaker block, liquidity sweep, break of structure, CHoCH, optimal trade entry, silver bullet, supply and demand, support and resistance, candle range theory and Power of 3 run on 1-minute candles, together with the earlier 7 strategies (the Breakout card is the range breakout). They are simple rule-based readings of those ideas, not official ICT definitions. KRM is not included yet. They need about 30 saved candles before they signal, and a trade needs agreement from at least 15% of the strategies that have a reading (never fewer than 2).

## Where things are in the app
Bottom menu: Trade (dashboard with the Start button), Scan (chart analysis and saved candles) and Settings. Settings holds Strategies (including the 24/7 server bot), Risk management, Broker management, Admin (admin only) and Sign out.

Update: the Home screen now shows the robot, a PAIRS / START / INFO bar, a data feed status pill and a Robot List. The candlestick chart was removed from Home (candles are still saved, and the Scan tab can still show them).

Update: the server address and the server admin password now live in Settings > Admin > Server connection (admin only). When the app is opened from your own server, it is already connected and the box shows the address.
