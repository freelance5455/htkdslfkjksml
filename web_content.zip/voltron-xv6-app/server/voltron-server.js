// VOLTRON XV6 backend. Node 18+, no dependencies.  Run: ADMIN_PASSWORD='...' node voltron-server.js
// MT5: METAAPI_TOKEN (or the admin saves it in the app). cTrader: CTRADER_CLIENT_ID + CTRADER_CLIENT_SECRET (openapi.ctrader.com app), Node 22+. Optional env: PORT, ADMIN_EMAIL, ALLOW_ORIGIN, LIVE_ENABLED=1 (required before any real-money order)
const path=require('path'),tls=require('tls'),http=require('http'),fs=require('fs'),crypto=require('crypto');
const ADMIN=(process.env.ADMIN_EMAIL||'dlaminiking11@gmail.com').toLowerCase(),PW=process.env.ADMIN_PASSWORD;
if(!PW||PW.length<8){console.error('Set ADMIN_PASSWORD (8+ chars) in the environment.');process.exit(1)}
const DATA=process.env.DATA_DIR||path.join(__dirname,'data');fs.mkdirSync(DATA,{recursive:true}); // history, keys and bot settings live here
const KF=path.join(DATA,'keys.json');if(!fs.existsSync(KF)&&fs.existsSync('keys.json'))fs.copyFileSync('keys.json',KF);
const keys=fs.existsSync(KF)?JSON.parse(fs.readFileSync(KF)):[],save=()=>fs.writeFileSync(KF,JSON.stringify(keys));
// Email via Gmail SMTP (port 465). Needs SMTP_PASS = a Google "App password" for the sending account (SMTP_USER, default = admin email).
const sendMail=(to,subject,text)=>new Promise((res,rej)=>{const u=process.env.SMTP_USER||ADMIN,pw=process.env.SMTP_PASS;
 if(!pw)return rej(Error('Server needs SMTP_PASS (Gmail app password)'));if(/[\r\n<>]/.test(to+subject))return rej(Error('Bad email address'));
 const sock=tls.connect(465,'smtp.gmail.com',{servername:'smtp.gmail.com'}),b64=x=>Buffer.from(x).toString('base64');sock.setEncoding('utf8');let buf='',n=0;
 const body=text.replace(/\r?\n/g,'\r\n').replace(/^\./gm,'..'),
 st=[['',220],['EHLO voltron',250],['AUTH LOGIN',334],[b64(u),334],[b64(pw),235],[`MAIL FROM:<${u}>`,250],[`RCPT TO:<${to}>`,250],['DATA',354],
 [`From: VOLTRON XV6 <${u}>\r\nTo: ${to}\r\nSubject: ${subject}\r\nContent-Type: text/plain; charset=utf-8\r\n\r\n${body}\r\n.`,250],['QUIT',221]];
 const t=setTimeout(()=>{sock.destroy();rej(Error('Email timed out'))},20000);
 sock.on('error',e=>{clearTimeout(t);rej(e)});
 sock.on('data',d=>{buf+=d;if(!buf.endsWith('\n'))return;const L=buf.trim().split('\r\n'),last=L[L.length-1];if(last[3]==='-')return;buf='';
  if(+last.slice(0,3)!==st[n][1]){clearTimeout(t);sock.destroy();return rej(Error(n===4?'Gmail rejected the login (use an app password)':'Email failed: '+last))}
  n++;if(n===st.length){clearTimeout(t);sock.end();return res()}sock.write(st[n][0]+'\r\n')})});
const sess=new Map(),broker={cfg:null},day={d:'',n:0,pl:0};
const eq=(a,b)=>{const x=Buffer.from(a),y=Buffer.from(b);return x.length===y.length&&crypto.timingSafeEqual(x,y)};
const HOST={practice:'https://api-fxpractice.oanda.com',live:'https://api-fxtrade.oanda.com'};
// ---- Markets. dg = price decimals, jpy = P/L is in yen, fx = forex hours ----
const SYM={XAUUSD:{u:.9,o:'XAU_USD',td:'XAU/USD',fh:'OANDA:XAU_USD',ct:['XAUUSD','GOLD'],cap:'GOLD',dg:2,ls:100},
 USDJPY:{u:.012,o:'USD_JPY',td:'USD/JPY',fh:'OANDA:USD_JPY',ct:['USDJPY'],cap:'USDJPY',dg:3,jpy:1,fx:1,ls:100000},
 GBPUSD:{u:.00012,o:'GBP_USD',td:'GBP/USD',fh:'OANDA:GBP_USD',ct:['GBPUSD'],cap:'GBPUSD',dg:5,fx:1,ls:100000},
 NAS100:{u:5,o:'NAS100_USD',td:'NDX',fh:'OANDA:NAS100_USD',ct:['US100','USTEC','NAS100','NDX100'],cap:'US100',dg:1,ls:1},
 US30:{u:9,o:'US30_USD',td:'DJI',fh:'OANDA:US30_USD',ct:['US30','DJ30','WS30'],cap:'US30',dg:1,ls:1}};
const symKey=k=>String(k||'XAUUSD').toUpperCase(),symOf=k=>{const y=SYM[symKey(k)];if(!y)throw Error('Unknown market');return y};
// ---- Price-only feeds (Twelve Data / Finnhub): real gold quotes, no trading ----
const etParts=d=>{const f=new Intl.DateTimeFormat('en-US',{timeZone:'America/New_York',weekday:'short',hour:'numeric',hour12:false}).formatToParts(d),g=t=>f.find(x=>x.type===t).value;return{w:['Sun','Mon','Tue','Wed','Thu','Fri','Sat'].indexOf(g('weekday')),h:+g('hour')%24}};
// Spot gold hours: Sun 18:00 ET to Fri 17:00 ET, with a daily break 17:00-18:00 ET. Holidays are not covered.
const mktOpen=(d=new Date(),fx=0)=>{const{w,h}=etParts(d);return fx?!(w===6||(w===5&&h>=17)||(w===0&&h<17)):!(w===6||(w===5&&h>=17)||(w===0&&h<18)||(w>=1&&w<=4&&h===17))};
const envFeed=()=>{const k=process.env.TWELVEDATA_KEY,f=process.env.FINNHUB_KEY;if(!k&&!f)return null;return envFeed.c||(envFeed.c=k?{provider:'feed',src:'twelvedata',key:k,ttl:10000}:{provider:'feed',src:'finnhub',key:f,ttl:2000})}; // real prices for demo users
const feedPrice=async(c=broker.cfg,sk)=>{const y=symOf(sk),h=(c.cache=c.cache||{})[y.o];if(h&&Date.now()-h.at<c.ttl)return h.v;let p;
 if(c.src==='finnhub'){const j=await(await fetch(`https://finnhub.io/api/v1/quote?symbol=${encodeURIComponent(y.fh)}&token=${encodeURIComponent(c.key)}`)).json();if(j.error)throw Error(j.error);p=+j.c}
 else{const j=await(await fetch(`https://api.twelvedata.com/price?symbol=${encodeURIComponent(y.td)}&apikey=${encodeURIComponent(c.key)}`)).json();if(j.status==='error')throw Error(j.message);p=+j.price}
 if(!(p>0))throw Error('No price returned (check the API key, plan and market)');const v={bid:p,ask:p,spread:0,time:new Date().toISOString()};c.cache[y.o]={v,at:Date.now()};return v};
// ---- cTrader Open API (JSON over WebSocket, port 5036). Needs Node 22+ for the built-in WebSocket ----
const ct={ws:null,pend:new Map(),acc:0,syms:{},px:{},list:null,day:'',start:0};
ct.send=(type,payload,ms=15000)=>new Promise((res,rej)=>{if(!ct.ws||ct.ws.readyState!==1)return rej(Error('cTrader not connected'));
 const id='m'+crypto.randomBytes(6).toString('hex'),t=setTimeout(()=>{ct.pend.delete(id);rej(Error('cTrader timeout'))},ms);
 ct.pend.set(id,{res,rej,t});ct.ws.send(JSON.stringify({clientMsgId:id,payloadType:type,payload}))});
ct.close=()=>{clearInterval(ct.hb);try{ct.ws&&ct.ws.close()}catch{}ct.ws=null;ct.bid=ct.ask=0};
ct.open=env=>new Promise((res,rej)=>{ct.close();const ws=new WebSocket(`wss://${env==='live'?'live':'demo'}.ctraderapi.com:5036`);ct.ws=ws;
 ws.onopen=res;ws.onerror=()=>rej(Error('Cannot reach cTrader'));
 ws.onmessage=e=>{const m=JSON.parse(e.data),p=m.payload||{};
  if(m.payloadType===2131){const x=ct.px[p.symbolId]||(ct.px[p.symbolId]={});if(p.bid)x.bid=p.bid/1e5;if(p.ask)x.ask=p.ask/1e5}
  const w=ct.pend.get(m.clientMsgId);if(w){clearTimeout(w.t);ct.pend.delete(m.clientMsgId);m.payloadType===2142?w.rej(Error(p.description||p.errorCode)):w.res(p)}};
 ct.hb=setInterval(()=>{try{ws.send(JSON.stringify({payloadType:51,payload:{}}))}catch{}},25000)});
const ctAcct=async()=>{const t=(await ct.send(2121,{ctidTraderAccountId:ct.acc})).trader,bal=t.balance/10**(t.moneyDigits||2),td=new Date().toISOString().slice(0,10);
 if(ct.day!==td)Object.assign(ct,{day:td,start:bal});return{balance:bal,unrealizedPL:bal-ct.start}}; // realized change only
const ctSym=async k=>{k=symKey(k);if(ct.syms[k])return ct.syms[k];const y=symOf(k);ct.list=ct.list||(await ct.send(2114,{ctidTraderAccountId:ct.acc})).symbol||[];
 const f=ct.list.find(x=>y.ct.includes(String(x.symbolName).toUpperCase()));if(!f)throw Error('Market not found on your cTrader account ('+y.ct.join(' / ')+')');
 const d=(await ct.send(2116,{ctidTraderAccountId:ct.acc,symbolId:[f.symbolId]})).symbol[0];await ct.send(2127,{ctidTraderAccountId:ct.acc,symbolId:[f.symbolId]});
 return ct.syms[k]={id:f.symbolId,min:+d.minVolume||100,step:+d.stepVolume||100}};
// ---- Capital.com REST API (demo or live). Session tokens last 10 minutes after the last request; the price poll keeps them alive ----
const CAPH={practice:'https://demo-api-capital.backend-capital.com',live:'https://api-capital.backend-capital.com'};
const cap=async(path,opt={})=>{const c=broker.cfg,r=await fetch(CAPH[c.env]+path,{...opt,headers:{'X-CAP-API-KEY':c.key,CST:c.cst,'X-SECURITY-TOKEN':c.xst,'Content-Type':'application/json'}});
 const j=await r.json().catch(()=>({}));if(!r.ok)throw Error(j.errorCode||'Capital.com error '+r.status);return j};
const capAcct=async()=>{const a=(await cap('/api/v1/accounts')).accounts[0].balance;return{balance:+a.balance,unrealizedPL:+a.profitLoss||0}};
// ---- MetaTrader 5 through MetaApi: the admin's one MetaApi key serves every user's own MT5 login ----
let MA_TOKEN=process.env.METAAPI_TOKEN||'';const MAH={prov:'https://mt-provisioning-api-v1.agiliumtrade.agiliumtrade.ai',cli:'https://mt-client-api-v1.new-york.agiliumtrade.ai'},sleep=ms=>new Promise(r=>setTimeout(r,ms)),ubr=new Map(),udays=new Map();
const mt=async(base,path,opt={})=>{if(!MA_TOKEN)throw Error('The admin has not added the MetaApi key yet');
 const r=await fetch(MAH[base]+path,{...opt,headers:{'auth-token':MA_TOKEN,'Content-Type':'application/json'}}),x=await r.text();let j={};try{j=JSON.parse(x)}catch{}
 if(!r.ok)throw Error(j.message||'MetaApi error '+r.status);return j};
const cfgOf=s=>ubr.get(s.e)||(s.role==='admin'?broker.cfg:null); // each user trades only on their own MT5 account
const oanda=async(path,opt={})=>{const c=broker.cfg;if(!c)throw Error('Broker not connected');
const r=await fetch(HOST[c.env]+path,{...opt,headers:{Authorization:'Bearer '+c.token,'Content-Type':'application/json'}});
const j=await r.json();if(!r.ok)throw Error(j.errorMessage||'Broker error '+r.status);return j};
const routes={
'POST /api/login':async b=>{const e=String(b.email||'').trim().toLowerCase();let role;
 if(e===ADMIN&&eq(String(b.password||''),PW))role='admin';
 else{const k=keys.find(x=>x.k===String(b.key||'').toUpperCase());
  if(!k||k.revoked||(k.email&&k.email!==e))throw Error('Invalid email or license key');k.email=e;save();role='user'}
 const t=crypto.randomBytes(24).toString('hex');sess.set(t,{e,role,at:Date.now()});return{token:t,role}},
'POST /api/keys':async(b,s)=>{if(s.role!=='admin')throw Error('Admin only');
 const k={k:'VXV6-'+[0,1,2].map(()=>crypto.randomBytes(2).toString('hex').toUpperCase()).join('-'),email:String(b.email||'').toLowerCase(),revoked:false};
 if(b.send&&!/^[^\s@,;<>]+@[^\s@,;<>]+\.[^\s@,;<>]+$/.test(k.email))throw Error('Enter a valid email');
 keys.unshift(k);save();
 if(b.send){try{await sendMail(k.email,'Your VOLTRON XV6 license key',`Welcome to VOLTRON XV6.\n\nYour license key: ${k.k}\n\nSign in with this email address and the key above.${process.env.APP_URL?'\n\nApp: '+process.env.APP_URL:''}\n\nKeep this key private.`);k.emailed=true}catch(e){k.emailed=false;k.mailError=e.message}}
 return k},
'POST /api/keys/revoke':async(b,s)=>{if(s.role!=='admin')throw Error('Admin only');const k=keys.find(x=>x.k===b.k);if(!k)throw Error('Key not found');k.revoked=!!b.revoked;save();return k},
'GET /api/keys':async(b,s)=>{if(s.role!=='admin')throw Error('Admin only');return keys},
'GET /api/history':async(b,s,url)=>{const p=new URL(url,'http://x').searchParams,k=symKey(p.get('s')),tf=[1,5,15,60].includes(+p.get('tf'))?+p.get('tf'):1;symOf(k);
 const all=agg(k,tf),lim=Math.min(Math.max(+p.get('limit')||120,10),2000),off=Math.max(+p.get('off')||0,0);
 return{total:all.length,off,candles:all.slice(Math.max(0,all.length-off-lim),all.length-off)}},
'GET /api/history.csv':async(b,s,url)=>{const p=new URL(url,'http://x').searchParams,k=symKey(p.get('s')),tf=[1,5,15,60].includes(+p.get('tf'))?+p.get('tf'):1;symOf(k);
 return'time_utc,open,high,low,close,ticks\n'+agg(k,tf).map(c=>[new Date(c.t).toISOString(),c.o,c.h,c.l,c.c,c.n].join(',')).join('\n')},
'POST /api/bot/config':async(b,s)=>{const k=symKey(b.symbol);symOf(k);const R=b.R||{},cfg={on:!!b.on,symbol:k,role:s.role,ST:Object.fromEntries(ST7.map(x=>[x,b.ST?(b.ST[x]?1:0):1])),
  R:{pct:Math.min(+R.pct||1,2),sl:+R.sl,rr:+R.rr||1.5,max:Math.min(+R.max||5,100),loss:+R.loss||3,spr:+R.spr||.5,hold:Math.min(Math.max(+R.hold||60,10),600),filt:!!R.filt}};
 if(cfg.on&&!(cfg.R.sl>0))throw Error('Set a stop-loss first');if(cfg.on&&!cfgOf(s))throw Error('Connect your broker first');
 const old=BOTS.get(s.e);BOTS.set(s.e,{...cfg,cd:0,log:old?old.log:[],sig:cfg.on?'Starting':'Stopped'});saveBots();return botStatus(s.e)},
'GET /api/bot/status':async(b,s)=>botStatus(s.e),
'POST /api/admin/metaapi':async(b,s)=>{if(s.role!=='admin')throw Error('Admin only');MA_TOKEN=String(b.token||'').trim();return{set:!!MA_TOKEN}},
'GET /api/admin/metaapi':async(b,s)=>{if(s.role!=='admin')throw Error('Admin only');return{set:!!MA_TOKEN}},
'POST /api/broker/connect':async(b,s)=>{
 if(b.provider==='mt5'){const srv=String(b.server||'').trim(),demo=/demo/i.test(srv),nm={XAUUSD:String(b.gold||'XAUUSD').trim()||'XAUUSD',USDJPY:'USDJPY',GBPUSD:'GBPUSD',NAS100:'US100',US30:'US30'};
  if(!b.login||!b.password||!srv)throw Error('Enter your login, password and server');
  if(!demo&&process.env.LIVE_ENABLED!=='1')throw Error('Live MT5 servers are disabled on this server. Use a demo server first.');
  const old=ubr.get(s.e);if(old){ubr.delete(s.e);try{await mt('prov','/users/current/accounts/'+old.id,{method:'DELETE'})}catch{}}
  const a=await mt('prov','/users/current/accounts',{method:'POST',body:JSON.stringify({login:String(b.login),password:String(b.password),server:srv,name:'voltron-'+s.e,platform:'mt5',magic:160006})}); // the password is passed on to MetaApi and not kept here
  ubr.set(s.e,{provider:'mt5',id:a.id,names:nm});const env=demo?'mt5 demo':'mt5 live';
  for(let i=0;i<8;i++){try{const x=await mt('cli',`/users/current/accounts/${a.id}/account-information`);return{connected:true,env,currency:x.currency,balance:+x.balance,nav:+x.equity}}catch(e){await sleep(5000)}}
  return{connected:true,env,currency:'-',balance:0,nav:0}}
 if(s.role!=='admin')throw Error('Admin only');
 if(b.provider==='feed'){const src=b.src==='finnhub'?'finnhub':'twelvedata';broker.cfg={provider:'feed',src,key:String(b.key||''),ttl:src==='finnhub'?2000:10000}; // key kept in server memory only
  try{const p=await feedPrice();return{connected:true,env:'price feed ('+src+')',currency:'XAU/USD',balance:p.bid,nav:p.bid}}catch(e){broker.cfg=null;throw e}}
 if(b.provider==='capital'){const env=b.env==='live'?'live':'practice';
  if(env==='live'&&process.env.LIVE_ENABLED!=='1')throw Error('Live trading is disabled on this server (LIVE_ENABLED=1 required). Use a demo account first.');
  const r=await fetch(CAPH[env]+'/api/v1/session',{method:'POST',headers:{'X-CAP-API-KEY':String(b.key),'Content-Type':'application/json'},body:JSON.stringify({identifier:String(b.login),password:String(b.password)})});
  const j=await r.json().catch(()=>({}));if(!r.ok)throw Error(j.errorCode||'Capital.com login failed ('+r.status+')');
  broker.cfg={provider:'capital',env,key:String(b.key),cst:r.headers.get('cst'),xst:r.headers.get('x-security-token'),epic:String(b.symbol||'GOLD')}; // password is not kept
  try{const a=(await cap('/api/v1/accounts')).accounts[0];return{connected:true,env:'capital '+env,currency:a.currency||'-',balance:+a.balance.balance,nav:+a.balance.balance}}catch(e){broker.cfg=null;throw e}}
 if(b.provider==='ctrader'){const env=b.env==='live'?'live':'demo';
  if(env==='live'&&process.env.LIVE_ENABLED!=='1')throw Error('Live trading is disabled on this server (LIVE_ENABLED=1 required). Use a demo account first.');
  if(!process.env.CTRADER_CLIENT_ID||!process.env.CTRADER_CLIENT_SECRET)throw Error('Server needs CTRADER_CLIENT_ID and CTRADER_CLIENT_SECRET');
  if(typeof WebSocket==='undefined')throw Error('cTrader needs Node 22 or newer on the server');
  try{await ct.open(env);ct.acc=+b.accountId;
   await ct.send(2100,{clientId:process.env.CTRADER_CLIENT_ID,clientSecret:process.env.CTRADER_CLIENT_SECRET});
   await ct.send(2102,{ctidTraderAccountId:ct.acc,accessToken:String(b.token)});
   ct.syms={};ct.px={};ct.list=null;try{await ctSym('XAUUSD')}catch(e){} // other markets load when first used
   broker.cfg={provider:'ctrader',env};const a=await ctAcct();return{connected:true,env:'cTrader '+env,currency:'-',balance:a.balance,nav:a.balance}}
  catch(e){ct.close();broker.cfg=null;throw e}}
 const env=b.env==='live'?'live':'practice';if(env==='live'&&process.env.LIVE_ENABLED!=='1')throw Error('Live trading is disabled on this server (LIVE_ENABLED=1 required)');
 broker.cfg={accountId:String(b.accountId),token:String(b.token),env};
 try{const a=(await oanda(`/v3/accounts/${broker.cfg.accountId}/summary`)).account;
  return{connected:true,env,currency:a.currency,balance:+a.balance,nav:+a.NAV}}catch(e){broker.cfg=null;throw e}},
'POST /api/broker/disconnect':async(b,s)=>{const u=ubr.get(s.e);if(u){ubr.delete(s.e);try{await mt('prov','/users/current/accounts/'+u.id,{method:'DELETE'})}catch{}return{connected:false}}if(s.role!=='admin')throw Error('Admin only');ct.close();broker.cfg=null;return{connected:false}},
'GET /api/price':async(b,s,url)=>{const k=symKey(new URL(url||'/','http://x').searchParams.get('s')),y=symOf(k),c=s?(cfgOf(s)||broker.cfg):broker.cfg,sp=(a,z)=>+(a-z).toFixed(y.dg+1);
 if(!c){const e=envFeed();if(e)return feedPrice(e,k);throw Error('No market data source on the server (set TWELVEDATA_KEY or FINNHUB_KEY)')}
 if(c.provider==='feed')return feedPrice(c,k);
 if(c.provider==='mt5'){const p=await mt('cli',`/users/current/accounts/${c.id}/symbols/${c.names[k]}/current-price`);return{bid:p.bid,ask:p.ask,spread:sp(p.ask,p.bid),time:p.time}}
 if(c.provider==='capital'){const m=(await cap('/api/v1/markets/'+encodeURIComponent(y.cap))).snapshot;return{bid:m.bid,ask:m.offer,spread:sp(m.offer,m.bid),time:new Date().toISOString()}}
 if(c.provider==='ctrader'){const x=ct.px[(await ctSym(k)).id]||{};if(!x.bid||!x.ask)throw Error('Waiting for first cTrader price');return{bid:x.bid,ask:x.ask,spread:sp(x.ask,x.bid),time:new Date().toISOString()}}
 const p=(await oanda(`/v3/accounts/${c.accountId}/pricing?instruments=${y.o}`)).prices[0],bid=+p.bids[0].price,ask=+p.asks[0].price;return{bid,ask,spread:sp(ask,bid),time:p.time}},
'GET /api/candles':async(b,s,url)=>{const p=new URL(url,'http://x').searchParams,tf=[1,5,15].includes(+p.get('tf'))?+p.get('tf'):1,y=symOf(p.get('s')),c=(s&&cfgOf(s))||broker.cfg||envFeed();
 if(!c)throw Error('No market data source on the server');
 if(c.provider==='ctrader'||c.provider==='capital'||c.provider==='mt5')throw Error('Candle history is built from live prices on this broker');
 if(c.provider==='feed'){if(c.src!=='twelvedata')throw Error('This price source has no candle history');
  const j=await(await fetch(`https://api.twelvedata.com/time_series?symbol=${encodeURIComponent(y.td)}&interval=${tf}min&outputsize=80&timezone=UTC&apikey=${encodeURIComponent(c.key)}`)).json();if(j.status==='error')throw Error(j.message);
  return j.values.reverse().map(v=>({t:Date.parse(v.datetime.replace(' ','T')+'Z'),o:+v.open,h:+v.high,l:+v.low,c:+v.close}))}
 const j=await oanda(`/v3/instruments/${y.o}/candles?granularity=M${tf}&count=80&price=M`);
 return j.candles.map(x=>({t:Date.parse(x.time),o:+x.mid.o,h:+x.mid.h,l:+x.mid.l,c:+x.mid.c}))},
'POST /api/order':async(b,s)=>{
 const c=cfgOf(s);if(!c)throw Error('Broker not connected');if(c.provider==='feed')throw Error('A price-only feed cannot place orders');
 const k=symKey(b.symbol),y=symOf(k),R={pct:Math.min(+b.pct||1,2),sl:+b.sl,rr:+b.rr||1.5,max:+b.max||5,loss:+b.loss||3,spr:+b.spr||.5},dir=b.side==='sell'?-1:1,f=v=>(+v).toFixed(y.dg);
 if(!mktOpen(new Date(),y.fx))throw Error('Market is closed');
 if(!(R.sl>0))throw Error('Stop-loss distance is required');
 const td=new Date().toISOString().slice(0,10);const dd=udays.get(s.e)||udays.set(s.e,{d:'',n:0}).get(s.e);if(dd.d!==td)Object.assign(dd,{d:td,n:0});
 if(dd.n>=R.max)throw Error('Daily trade limit reached');
 const CT=c.provider==='ctrader',CP=c.provider==='capital',M5=c.provider==='mt5',acct=M5?(x=>({balance:x.balance,unrealizedPL:x.equity-x.balance}))(await mt('cli',`/users/current/accounts/${c.id}/account-information`)):CT?await ctAcct():CP?await capAcct():(await oanda(`/v3/accounts/${c.accountId}/summary`)).account;
 if(+acct.unrealizedPL<=-(+acct.balance)*R.loss/100)throw Error('Daily loss limit reached');
 const px=await routes['GET /api/price'](null,s,'/?s='+k);if(px.spread>R.spr)throw Error('Spread too wide: '+px.spread);
 const entry=dir>0?px.ask:px.bid,units=Math.max(1,Math.floor(+acct.balance*R.pct/100/R.sl*(y.jpy?entry:1))); // units that risk about R.pct of the balance (yen pairs are converted)
 if(M5){const lots=Math.max(.01,+(units/y.ls).toFixed(2)); // lot = 100 oz gold, 100,000 forex units, 1 index contract (check your broker)
  const o=await mt('cli',`/users/current/accounts/${c.id}/trade`,{method:'POST',body:JSON.stringify({actionType:dir>0?'ORDER_TYPE_BUY':'ORDER_TYPE_SELL',symbol:c.names[k],volume:lots,stopLoss:+f(entry-dir*R.sl),takeProfit:+f(entry+dir*R.sl*R.rr)})});
  dd.n++;return{units:dir*lots*y.ls,entry,result:o.orderId||o.message||'submitted'}}
 if(CP){const size=Math.max(.1,+(+acct.balance*R.pct/100/R.sl*(y.jpy?entry:1)).toFixed(1)); // check your market's contract size on Capital.com
  const o=await cap('/api/v1/positions',{method:'POST',body:JSON.stringify({epic:y.cap,direction:dir>0?'BUY':'SELL',size,stopLevel:+f(entry-dir*R.sl),profitLevel:+f(entry+dir*R.sl*R.rr)})});
  dd.n++;return{units:dir*size,entry,result:o.dealReference||'submitted'}}
 if(CT){const m=await ctSym(k),vol=Math.max(m.min,Math.floor(units*100/m.step)*m.step); // volume is in 1/100 of a unit
  const o=await ct.send(2106,{ctidTraderAccountId:ct.acc,symbolId:m.id,orderType:1,tradeSide:dir>0?1:2,volume:vol,relativeStopLoss:Math.round(R.sl*1e5),relativeTakeProfit:Math.round(R.sl*R.rr*1e5)},20000);
  if(o.errorCode)throw Error(o.errorCode);dd.n++;return{units:dir*vol/100,entry,result:o.order?.orderId||o.executionType||'submitted'}}
 const o=await oanda(`/v3/accounts/${c.accountId}/orders`,{method:'POST',body:JSON.stringify({order:{type:'MARKET',instrument:y.o,units:String(dir*units),timeInForce:'FOK',
  stopLossOnFill:{price:f(entry-dir*R.sl)},takeProfitOnFill:{price:f(entry+dir*R.sl*R.rr)}}})});
 dd.n++;return{units:dir*units,entry,result:o.orderFillTransaction?.id||o.orderCancelTransaction?.reason||'submitted'}}};
// ---- Saved candles, price collector and the 24/7 bot. All of this keeps running while the app is closed ----
const C1={},CUR={},TK={},cf=k=>path.join(DATA,'candles-'+k+'.jsonl');
for(const k of Object.keys(SYM)){C1[k]=[];try{for(const l of fs.readFileSync(cf(k),'utf8').split('\n'))if(l)try{C1[k].push(JSON.parse(l))}catch{}}catch{}}
const feedTick=(k,p)=>{const m=Math.floor(Date.now()/6e4)*6e4,c=CUR[k];(TK[k]=TK[k]||[]).push(p);if(TK[k].length>150)TK[k].shift();
 if(c&&c.t===m){c.h=Math.max(c.h,p);c.l=Math.min(c.l,p);c.c=p;c.n++}
 else{if(c){C1[k].push(c);fs.appendFile(cf(k),JSON.stringify(c)+'\n',()=>{})}CUR[k]={t:m,o:p,h:p,l:p,c:p,n:1}}};
const agg=(k,tf)=>{const all=CUR[k]?[...C1[k],CUR[k]]:C1[k];if(tf===1)return all;const ms=tf*6e4,o=[];
 for(const c of all){const g=Math.floor(c.t/ms)*ms,q=o[o.length-1];if(q&&q.t===g){q.h=Math.max(q.h,c.h);q.l=Math.min(q.l,c.l);q.c=c.c;q.n+=c.n}else o.push({t:g,o:c.o,h:c.h,l:c.l,c:c.c,n:c.n})}return o};
let collecting=false;const SYS={e:'collector',role:'admin'};
const collect=async()=>{if(collecting)return;collecting=true;
 for(const k of Object.keys(SYM)){if(!mktOpen(new Date(),SYM[k].fx))continue;try{const p=await routes['GET /api/price'](null,SYS,'/?s='+k);feedTick(k,(p.bid+p.ask)/2)}catch(e){}}
 collecting=false};
const emaF=(a,n)=>{const k=2/(n+1);return a.reduce((x,v)=>x+(v-x)*k,a[0])};
// Smart-money signals on CLOSED 1-minute candles. cc = closed candles, px = current price, u = typical move of the market, now = Date.
// Each returns 1 (buy), -1 (sell) or 0. These are simple rule-based readings of the concepts, not official ICT definitions.
function smcSig(cc,px,u,now){const o={};if(cc.length<30)return o;const c=cc.slice(-60),m=c.length,last=c[m-1];
 const tr=c.slice(-15).map((q,i,a)=>i?Math.max(q.h-q.l,Math.abs(q.h-a[i-1].c),Math.abs(q.l-a[i-1].c)):q.h-q.l),atr=Math.max(tr.reduce((x,y)=>x+y,0)/tr.length,u*.05);
 const sh=[],sl=[];for(let i=2;i<m-2;i++){if(c[i].h>c[i-1].h&&c[i].h>c[i-2].h&&c[i].h>c[i+1].h&&c[i].h>c[i+2].h)sh.push(i);if(c[i].l<c[i-1].l&&c[i].l<c[i-2].l&&c[i].l<c[i+1].l&&c[i].l<c[i+2].l)sl.push(i)}
 const lsh=sh.length?c[sh[sh.length-1]].h:null,lsl=sl.length?c[sl[sl.length-1]].l:null;
 const fv=[];for(let i=Math.max(2,m-30);i<m;i++){if(c[i-2].h<c[i].l&&c[i].l-c[i-2].h>atr*.1)fv.push({d:1,lo:c[i-2].h,hi:c[i].l,i});if(c[i-2].l>c[i].h&&c[i-2].l-c[i].h>atr*.1)fv.push({d:-1,lo:c[i].h,hi:c[i-2].l,i})}
 const inZ=z=>px>=z.lo&&px<=z.hi,viol=z=>c.slice(z.i+1).some(q=>z.d>0?q.c<z.lo:q.c>z.hi),fr=fv.slice().reverse();
 {let s=0;for(const z of fr)if(inZ(z)&&!viol(z)){s=z.d;break}o.fvg=s}
 {let s=0;for(const z of fr)if(viol(z)&&inZ(z)){s=-z.d;break}o.ifvg=s}
 const ob=[];for(let j=Math.max(5,m-30);j<m;j++){const b=c[j].c-c[j].o;if(Math.abs(b)>=atr*1.5){const d=b>0?1:-1;for(let k=j-1;k>=j-5&&k>=0;k--)if((c[k].c-c[k].o)*d<0){ob.push({d,lo:c[k].l,hi:c[k].h,j});break}}}
 const oviol=z=>c.slice(z.j+1).some(q=>z.d>0?q.c<z.lo:q.c>z.hi),orv=ob.slice().reverse();
 {let s=0;for(const z of orv)if(!oviol(z)&&inZ(z)){s=z.d;break}o.ob=s}
 {let s=0;for(const z of orv)if(oviol(z)&&inZ(z)){s=-z.d;break}o.breaker=s}
 {let s=0;for(let j=m-3;j>=Math.max(3,m-30)&&!s;j--){const b=c[j].c-c[j].o;if(Math.abs(b)>=atr*1.5){const d=b>0?1:-1,base=c.slice(Math.max(0,j-3),j).filter(q=>q.h-q.l<atr*.8);if(base.length>=2){const lo=Math.min(...base.map(q=>q.l)),hi=Math.max(...base.map(q=>q.h));if(px>=lo&&px<=hi&&!c.slice(j+1).some(q=>d>0?q.c<lo:q.c>hi))s=d}}}o.sd=s}
 {let s=0;const ref=c.slice(-30,-3),rh=Math.max(...ref.map(q=>q.h)),rl=Math.min(...ref.map(q=>q.l));for(const q of c.slice(-3)){if(q.l<rl&&q.c>rl)s=1;if(q.h>rh&&q.c<rh)s=-1}o.sweep=s}
 o.bos=lsh!=null&&last.c>lsh&&c[m-2].c<=lsh?1:lsl!=null&&last.c<lsl&&c[m-2].c>=lsl?-1:0;
 {let s=0;if(sh.length>=2&&sl.length>=2){const h1=c[sh[sh.length-2]].h,h2=c[sh[sh.length-1]].h,l1=c[sl[sl.length-2]].l,l2=c[sl[sl.length-1]].l;if(h2<h1&&l2<l1&&last.c>h2&&c[m-2].c<=h2)s=1;if(h2>h1&&l2>l1&&last.c<l2&&c[m-2].c>=l2)s=-1}o.choch=s}
 {let s=0;if(sh.length&&sl.length){const a=sh[sh.length-1],b=sl[sl.length-1],hi=c[a].h,lo=c[b].l,r=hi-lo;if(r>=atr*3){if(a>b){const f=(hi-px)/r;if(f>=.62&&f<=.79&&last.c>last.o)s=1}else{const f=(px-lo)/r;if(f>=.62&&f<=.79&&last.c<last.o)s=-1}}}o.ote=s}
 {let s=0;const lv=[...sh.map(i=>c[i].h),...sl.map(i=>c[i].l)].sort((x,y)=>x-y),cl=[];for(const v of lv){const g=cl[cl.length-1];if(g&&v-g.v<atr*.3){g.v=(g.v*g.n+v)/(g.n+1);g.n++}else cl.push({v,n:1})}
  for(const g of cl)if(g.n>=2){if(last.l<=g.v+atr*.25&&last.l>=g.v-atr*.5&&last.c>g.v&&last.c>last.o)s=1;if(last.h>=g.v-atr*.25&&last.h<=g.v+atr*.5&&last.c<g.v&&last.c<last.o)s=-1}o.sr=s}
 {const a=c[m-2],b=last;o.crt=b.l<a.l&&b.c>a.l&&b.c<a.h?1:b.h>a.h&&b.c<a.h&&b.c>a.l?-1:0}
 {let s=0;const acc=c.slice(-30,-10),ah=Math.max(...acc.map(q=>q.h)),al=Math.min(...acc.map(q=>q.l)),rec=c.slice(-10);if(ah-al<atr*4){const mid=(ah+al)/2;if(Math.min(...rec.map(q=>q.l))<al-atr*.1&&px>mid)s=1;else if(Math.max(...rec.map(q=>q.h))>ah+atr*.1&&px<mid)s=-1}o.po3=s}
 {const{w,h}=etParts(now);o.silver=(w>=1&&w<=5&&(h===3||h===10||h===14))?(o.fvg||0):0}
 return o}
function sigS(k,ST){const t=TK[k]||[],n=t.length,o={},u=SYM[k].u;if(n<40)return o;const l=t[n-1],w40=t.slice(-40);
 if(ST.ema){const a=emaF(w40,8),b=emaF(w40,21);o.ema=a>b+u*.17?1:a<b-u*.17?-1:0}
 if(ST.vwap){const m=w40.reduce((x,y)=>x+y)/40,up=emaF(w40,21)>emaF(w40,8)?-1:1;o.vwap=l<m-u*.55&&up>0?1:l>m+u*.55&&up<0?-1:0}
 if(ST.brk){const w=t.slice(-31,-1);o.brk=l>Math.max(...w)?1:l<Math.min(...w)?-1:0}
 if(ST.rsi){let g=0,d=0;t.slice(-15).forEach((v,i,a)=>{if(i){const c=v-a[i-1];c>0?g+=c:d-=c}});const r=100-100/(1+g/(d||1e-9));o.rsi=r<25?1:r>75?-1:0}
 if(ST.tick){const s=t.slice(-6),up=s.every((v,i)=>!i||v>s[i-1]),dn=s.every((v,i)=>!i||v<s[i-1]);o.tick=up?1:dn?-1:0}
 if(ST.stoch){const w=t.slice(-14),hi=Math.max(...w),lo=Math.min(...w),kk=(l-lo)/((hi-lo)||1)*100,pk=(t[n-2]-lo)/((hi-lo)||1)*100;o.stoch=kk<20&&kk>pk?1:kk>80&&kk<pk?-1:0}
 if(ST.bbsq){const sd=a=>{const m=a.reduce((x,y)=>x+y)/a.length;return[m,Math.sqrt(a.reduce((x,y)=>x+(y-m)**2,0)/a.length)]},[m,d]=sd(t.slice(-20)),[,d2]=sd(t.slice(-40,-20));o.bbsq=d<d2*.7&&l>m+d*1.5?1:d<d2*.7&&l<m-d*1.5?-1:0}
 {const x=smcSig(C1[k].slice(-60),l,u,new Date());for(const q in x)if(ST[q])o[q]=x[q]}
 return o}
function anS(k){let c=agg(k,1).slice(-60);if(c.length<22){const t=TK[k]||[];c=[];for(let i=0;i+5<=t.length;i+=5){const s=t.slice(i,i+5);c.push({o:s[0],h:Math.max(...s),l:Math.min(...s),c:s[4]})}}
 if(c.length<10)return null;const cl=c.map(q=>q.c),last=cl[cl.length-1],e8=emaF(cl,8),e21=emaF(cl,21),up=e8>e21;
 let g=0,d=0;cl.slice(-15).forEach((v,i,x)=>{if(i){const z=v-x[i-1];z>0?g+=z:d-=z}});const rsi=100-100/(1+g/(d||1e-9));
 const tr=c.slice(-15).map((q,i,x)=>i?Math.max(q.h-q.l,Math.abs(q.h-x[i-1].c),Math.abs(q.l-x[i-1].c)):q.h-q.l),atr=tr.reduce((x,y)=>x+y,0)/tr.length;
 const w=c.slice(-21,-1),res=Math.max(...w.map(q=>q.h)),sup=Math.min(...w.map(q=>q.l));
 const q=c[c.length-1],p=c[c.length-2],body=Math.abs(q.c-q.o),rng=(q.h-q.l)||1e-9,lw=Math.min(q.o,q.c)-q.l,uw=q.h-Math.max(q.o,q.c);let sc=up?1:-1;
 if(Math.abs(e8-e21)>atr*.3)sc+=up?1:-1;sc+=rsi>70?-1:rsi<30?1:rsi>55?1:rsi<45?-1:0;if(last-sup<atr*.5&&last>=sup)sc+=1;if(res-last<atr*.5&&last<=res)sc-=1;
 if(lw>=body*2&&uw<=body&&body>0)sc+=1;if(uw>=body*2&&lw<=body&&body>0)sc-=1;
 if(p.c<p.o&&q.c>q.o&&q.c>=p.o&&q.o<=p.c)sc+=1;if(p.c>p.o&&q.c<q.o&&q.o>=p.c&&q.c<=p.o)sc-=1;return{score:sc}}
const BF=path.join(DATA,'bots.json'),BOTS=new Map(),ST7=['ema','vwap','brk','rsi','tick','stoch','bbsq','fvg','ob','sweep','bos','choch','ifvg','breaker','ote','silver','sd','sr','crt','po3'];
try{for(const[e,b]of Object.entries(JSON.parse(fs.readFileSync(BF,'utf8'))))BOTS.set(e,{...b,cd:0,log:[],sig:'-'})}catch{}
const saveBots=()=>fs.writeFile(BF,JSON.stringify(Object.fromEntries([...BOTS].map(([e,b])=>[e,{on:b.on,symbol:b.symbol,role:b.role,ST:b.ST,R:b.R}]))),()=>{});
const botStatus=e=>{const b=BOTS.get(e);return b?{on:b.on,symbol:b.symbol,sig:b.sig,connected:!!cfgOf({e,role:b.role}),log:b.log.slice(0,10)}:{on:false,connected:!!cfgOf({e,role:e===ADMIN?'admin':'user'}),sig:'-',log:[]}};
let engBusy=false;
const engine=async()=>{if(engBusy)return;engBusy=true;
 for(const[e,b]of BOTS){if(!b.on)continue;const s={e,role:b.role},add=m=>{b.log.unshift({t:new Date().toISOString(),m});if(b.log.length>50)b.log.pop()};
  try{
   if(b.role!=='admin'&&!keys.some(x=>x.email===e&&!x.revoked)){b.on=false;saveBots();add('Stopped: license revoked');continue}
   if(!mktOpen(new Date(),SYM[b.symbol].fx)){b.sig='Market closed';continue}
   const c=cfgOf(s);if(!c){b.sig='Connect your broker';continue}
   if(Date.now()<b.cd){b.sig='Cooling down';continue}
   const sg=sigS(b.symbol,b.ST),net=Object.values(sg).reduce((x,y)=>x+y,0);
   b.sig=Object.entries(sg).filter(x=>x[1]).map(x=>x[0]+(x[1]>0?' up':' down')).join(', ')||'no signal';
   if(Math.abs(net)<Math.max(2,Math.ceil(Object.keys(sg).length*.15)))continue;const d=Math.sign(net);
   if(b.R.filt){const a=anS(b.symbol);if(!a||a.score*d<2){b.sig+=' (blocked by chart analysis)';continue}}
   if(c.provider==='feed'){add((d>0?'BUY':'SELL')+' signal: '+b.sig+' (price feed, not traded)');b.cd=Date.now()+6e4;continue}
   const o=await routes['POST /api/order']({side:d>0?'buy':'sell',symbol:b.symbol,pct:b.R.pct,sl:b.R.sl,rr:b.R.rr,max:b.R.max,loss:b.R.loss,spr:b.R.spr},s);
   add((d>0?'BUY ':'SELL ')+b.symbol+' '+Math.abs(o.units)+' at '+o.entry+' ('+o.result+')');b.cd=Date.now()+(b.R.hold+15)*1000}
  catch(er){add('Order not sent: '+er.message);b.cd=Date.now()+(/limit|closed|spread/i.test(er.message)?6e5:3e4)}}
 engBusy=false};
setInterval(collect,+process.env.COLLECT_MS||5000);setInterval(engine,+process.env.ENGINE_MS||3000);
process.on('unhandledRejection',e=>console.error('unhandled',e));process.on('uncaughtException',e=>console.error('uncaught',e));
http.createServer(async(q,r)=>{const h={'Access-Control-Allow-Origin':process.env.ALLOW_ORIGIN||'*','Access-Control-Allow-Headers':'Content-Type,Authorization','Content-Type':'application/json'};
 if(q.method==='OPTIONS'){r.writeHead(204,h);return r.end()}
 if(q.url==='/health'){r.writeHead(200);return r.end('ok')} // for an uptime pinger
 if(q.method==='GET'&&!q.url.startsWith('/api/')){ // serves the app from the www folder, so one server hosts app + API
  const wd=[path.join(__dirname,'..','www'),path.join(__dirname,'www')].find(d=>fs.existsSync(d)),flat=!wd,root=wd||__dirname;let f; // flat = index.html sits next to this file
  try{f=path.normalize(path.join(root,decodeURIComponent(q.url.split('?')[0])))}catch{f=''}
  if(!f.startsWith(root+path.sep)||!fs.existsSync(f)||fs.statSync(f).isDirectory())f=path.join(root,'index.html');
  if(flat&&!['index.html','manifest.webmanifest','sw.js','icon-192.png','icon-512.png'].includes(path.basename(f)))f=path.join(root,'index.html'); // never serve keys.json or the server file
  if(!fs.existsSync(f)){r.writeHead(404);return r.end('Not found')}
  const T={'.html':'text/html; charset=utf-8','.js':'text/javascript','.json':'application/json','.webmanifest':'application/manifest+json','.png':'image/png','.webp':'image/webp'};
  if(path.basename(f)==='index.html'){const host=String(q.headers.host||'').replace(/[^\w.:\-]/g,''),o=(/^(localhost|127\.)/.test(host)?'http://':'https://')+host; // the app learns its own server address
   r.writeHead(200,{'Content-Type':T['.html'],'Cache-Control':'no-cache'});return r.end(fs.readFileSync(f,'utf8').replace(/(const|let) API='',/,"$1 API='"+o+"',"))}
  r.writeHead(200,{'Content-Type':T[path.extname(f)]||'application/octet-stream','Cache-Control':'no-cache'});return fs.createReadStream(f).pipe(r)}
 let body='';for await(const c of q){body+=c;if(body.length>1e5)return r.end()}
 try{const key=q.method+' '+q.url.split('?')[0],f=routes[key];if(!f){r.writeHead(404,h);return r.end('{"error":"Not found"}')}
  const s=sess.get((q.headers.authorization||'').replace('Bearer ',''));if(key!=='POST /api/login'&&(!s||Date.now()-s.at>12*36e5))throw Error('Sign in required');
  const out=await f(body?JSON.parse(body):{},s,q.url);if(typeof out==='string'){r.writeHead(200,{...h,'Content-Type':'text/csv'});r.end(out)}else{r.writeHead(200,h);r.end(JSON.stringify(out))}} // answer only after the route finished, so an error cannot crash the server
 catch(e){r.writeHead(400,h);r.end(JSON.stringify({error:e.message}))}
}).listen(process.env.PORT||8787,()=>console.log('VOLTRON XV6 backend on :'+(process.env.PORT||8787)));
