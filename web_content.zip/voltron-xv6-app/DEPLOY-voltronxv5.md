# Deploy to https://voltronxv5.n8n-hub.site
One Node server serves the app and the API on the same address (the app is already set to https://voltronxv5.n8n-hub.site).

1. Point the domain's DNS A record to your server's IP address.
2. Copy this whole folder to the server (Node 22+ or Docker).
3. Create the settings (never share these):
   export ADMIN_PASSWORD='a strong password'
   export SMTP_PASS='gmail app password'
   export APP_URL='https://voltronxv5.n8n-hub.site'
4. Start it:  node server/voltron-server.js     (or: docker build -t voltron . && docker run -d -p 8787:8787 -e ADMIN_PASSWORD -e SMTP_PASS -e APP_URL voltron)
5. Put HTTPS in front. With Caddy, use the included Caddyfile (it gets the certificate automatically).
6. Open https://voltronxv5.n8n-hub.site on your phone, sign in as the admin, then add it to the home screen.

Keep LIVE_ENABLED off until you have tested on a demo account. license keys are saved in keys.json next to where you start the server; back that file up.
