import type { CapacitorConfig } from "@capacitor/cli";

const config: CapacitorConfig = {
  appId: "ke.navakholo.ustawibiomanager",
  appName: "Ustawi Bio-Manager",
  webDir: "dist",
  bundledWebRuntime: false,
  server: { androidScheme: "https" },
  plugins: { CapacitorSQLite: { androidIsEncryption: false } }
};

export default config;
