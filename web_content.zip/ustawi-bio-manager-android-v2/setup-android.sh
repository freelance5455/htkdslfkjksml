#!/usr/bin/env bash
set -euo pipefail
npm install
npm run build
if [ ! -d android/app ]; then npx cap add android; fi
npx cap sync android
npx cap open android
