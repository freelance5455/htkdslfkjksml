import React, { useState } from "react";

export default function Login({ onLogin }) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [showHelp, setShowHelp] = useState(false);

  function submit(e) {
    e.preventDefault();
    const res = onLogin(username, password);
    if (!res.ok) setError(res.error);
  }

  return (
    <div className="login-screen">
      <div className="login-card">
        <div className="login-logo">🌱</div>
        <h1>Ustawi Bio-Manager</h1>
        <p className="login-sub">Ustawi Bio Committee</p>
        <form onSubmit={submit}>
          <label>Username</label>
          <input value={username} onChange={(e) => setUsername(e.target.value)} placeholder="e.g. admin" autoFocus />
          <label>Password</label>
          <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Password" />
          {error && <div className="form-error">{error}</div>}
          <button className="btn-primary" type="submit">Sign In</button>
        </form>
        <div className="demo-help"><div><b>admin</b> / ChangeMe123! — Administrator (replace immediately)</div><div><b>chair</b> / ChangeMe123! — Sample Chairperson</div><div><b>coordinator</b> / ChangeMe123! — Sample Coordinator</div><div><b>technical</b> / ChangeMe123! — Sample Technical Officer</div><div><b>production</b> / ChangeMe123! — Sample Production Officer</div><div><b>finance</b> / ChangeMe123! — Sample Finance Officer</div><div><b>member</b> / ChangeMe123! — Sample View-Only Member</div></div>
        <div className="login-footnote">Offline-first · Private deployment · Data stored securely on this device</div>
      </div>
    </div>
  );
}