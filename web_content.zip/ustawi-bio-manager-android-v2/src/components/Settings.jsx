import React, { useEffect, useState, useRef } from "react";
import { fmtDateTime, roleLabel } from "../lib/constants";
import { getSyncConfig, setSyncConfig, getLastSync } from "../lib/sync";

export default function Settings({ store, currentUser, onLogout }) {
  const [online, setOnline] = useState(navigator.onLine);
  const fileRef = useRef();
  const [syncMsg, setSyncMsg] = useState("");
  const [syncConfig, setSyncConfigState] = useState(getSyncConfig());

  useEffect(() => {
    const on = () => setOnline(true);
    const off = () => setOnline(false);
    window.addEventListener("online", on);
    window.addEventListener("offline", off);
    return () => {
      window.removeEventListener("online", on);
      window.removeEventListener("offline", off);
    };
  }, []);

  async function doSync() {
    setSyncMsg("Synchronizing…");
    const result = await store.syncNow();
    setSyncMsg(result.ok ? "Synchronization completed successfully." : (result.skipped ? "Sync is not configured or the device is offline." : `Sync failed: ${result.error}`));
  }

  function saveSyncSettings() {
    const next = setSyncConfig(syncConfig);
    setSyncConfigState(next);
    setSyncMsg("Sync settings saved. Data will synchronize automatically when online.");
    if (navigator.onLine && next.enabled) store.syncNow();
  }

  function doBackup() {
    const data = store.backupNow();
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `afrisoil_backup_${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    setSyncMsg("Backup saved to device and cloud sync marker updated.");
  }

  function handleRestore(e) {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      const res = store.restoreFromJSON(reader.result);
      setSyncMsg(res.ok ? "Data restored successfully." : res.error);
    };
    reader.readAsText(file);
  }

  return (
    <div className="module">
      <h2>Settings & Sync</h2>

      <div className="record-card">
        <div className="record-card-top">
          <div>
            <div className="record-title">{currentUser.name}</div>
            <div className="record-sub">{roleLabel(currentUser.role)} · @{currentUser.username}</div>
          </div>
        </div>
      </div>

      <h3 className="section-title">Connection Status</h3>
      <div className={`status-pill ${online ? "on" : "off"}`}>
        {online ? "🟢 Online — data will sync automatically" : "🔴 Offline — working from local device storage"}
      </div>

      <h3 className="section-title">Cloud Synchronization</h3>
      <p className="section-hint">Data is always captured on the device first. When internet access is available, pending changes can be synchronized with the configured Ustawi sync server.</p>
      <label>Sync server URL</label>
      <input value={syncConfig.url} onChange={(e) => setSyncConfigState({ ...syncConfig, url: e.target.value })} placeholder="https://your-ustawi-server.example" />
      <label>Sync server token</label>
      <input type="password" value={syncConfig.token || ""} onChange={(e) => setSyncConfigState({ ...syncConfig, token: e.target.value })} placeholder="Private server token" />
      <label className="checkbox-row"><input type="checkbox" checked={!!syncConfig.enabled} onChange={(e) => setSyncConfigState({ ...syncConfig, enabled: e.target.checked })} /> Enable automatic synchronization</label>
      <div className="form-actions">
        <button className="btn-secondary" onClick={saveSyncSettings}>Save Sync Settings</button>
        <button className="btn-primary" onClick={doSync}>Sync Now</button>
      </div>
      <p className="section-hint">Last successful sync: {getLastSync() ? fmtDateTime(getLastSync()) : "Never"}.</p>

      <h3 className="section-title">Backup & Recovery</h3>
      <p className="section-hint">
        Last backup: {store.state.lastBackup ? fmtDateTime(store.state.lastBackup) : "Never"}. Backups let you
        recover your account and data on a new device.
      </p>
      <div className="form-actions">
        <button className="btn-secondary" onClick={() => fileRef.current.click()}>Restore Backup</button>
        <button className="btn-primary" onClick={doBackup}>Backup Now</button>
      </div>
      <input ref={fileRef} type="file" accept="application/json" style={{ display: "none" }} onChange={handleRestore} />
      {syncMsg && <div className="sync-msg">{syncMsg}</div>}

      <h3 className="section-title">About</h3>
      <p className="section-hint">
        Ustawi Bio-Manager v2.0 — offline-first management system for the Ustawi Bio Committee.
        Optimized for entry-level Android devices. Privately deployed outside the Play Store.
      </p>

      <button className="btn-secondary logout-btn" onClick={onLogout}>Log Out</button>
    </div>
  );
}