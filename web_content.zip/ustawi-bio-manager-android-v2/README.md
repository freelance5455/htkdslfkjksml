# Ustawi Bio-Manager — Android Studio + Offline-First Cloud Sync

This project is prepared as a standalone Android application using React/Vite + Capacitor. HyperDev hosting is not required and its preview branding is not packaged into the Android application.

## Local/offline database

Android uses native SQLite through `@capacitor-community/sqlite`. The local database stores Ustawi records, tombstones for deletions, metadata, and a durable synchronization queue. If the network disappears, data entry continues and changes remain queued until synchronization succeeds. The browser development fallback uses localStorage.

## Cloud synchronization architecture

**Phone → SQLite → sync queue → HTTPS API → PostgreSQL → other phones**

The client uses pull + push synchronization with a server cursor. Each change has an ID, device ID and timestamp. The server is idempotent (repeated operation IDs are not applied twice) and uses last-write-wins for conflicting edits based on `updatedAt`. Deletions are retained as tombstones so they can propagate to other devices.

The included `server/` folder is a production-oriented reference API using PostgreSQL rather than a JSON file. Deploy it behind HTTPS and set:

```text
DATABASE_URL=postgresql://USER:PASSWORD@HOST:5432/ustawi
USTAWI_SYNC_TOKEN=<long-random-secret>
PORT=8787
```

Install and start the server:

```bash
cd server
npm install
npm start
```

For a real deployment, put the API behind HTTPS, use a managed PostgreSQL database with backups, and replace the shared token with per-user authentication before distributing sensitive financial data.

## Android Studio setup

Requirements: Node.js, Android Studio, Android SDK and a JDK compatible with the installed Capacitor/Android Gradle Plugin.

```bash
npm install
npm run build
npx cap sync android
npx cap open android
```

Then use Android Studio to build the debug APK for testing. Android's documentation confirms that Android Studio/Gradle can generate APKs and signed release APK/AAB packages. See the official Android release guidance.

## Application identity

- Application ID: `ke.navakholo.ustawibiomanager`
- Display name: `Ustawi Bio-Manager`
- Database: `ustawi_bio_manager`

## Temporary accounts

These are filler accounts only and should be changed by the Administrator:

| Username | Password | Role |
|---|---|---|
| admin | ChangeMe123! | Administrator |
| chair | ChangeMe123! | Chairperson |
| coordinator | ChangeMe123! | Project Coordinator |
| technical | ChangeMe123! | Technical Officer |
| production | ChangeMe123! | Production Officer |
| finance | ChangeMe123! | Finance Officer |
| member | ChangeMe123! | View-only Member |
