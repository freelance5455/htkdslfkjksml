# Ustawi cloud synchronization API

This API is intended to be hosted separately from the Android app.

## Production requirements

- PostgreSQL database
- HTTPS reverse proxy/domain
- Long random `USTAWI_SYNC_TOKEN`
- Regular PostgreSQL backups
- Firewall/network controls

## Environment

```env
DATABASE_URL=postgresql://USER:PASSWORD@HOST:5432/ustawi
USTAWI_SYNC_TOKEN=replace-with-a-long-random-secret
PORT=8787
```

Run:

```bash
npm install
npm start
```

The API exposes `GET /api/health` and `POST /api/sync`.
