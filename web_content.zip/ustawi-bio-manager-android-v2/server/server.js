import express from 'express';
import pg from 'pg';

const { Pool } = pg;
const app = express();
app.use(express.json({ limit:'10mb' }));
const PORT = process.env.PORT || 8787;
const TOKEN = process.env.USTAWI_SYNC_TOKEN;
const pool = new Pool({ connectionString: process.env.DATABASE_URL, ssl: process.env.DATABASE_URL?.includes('sslmode=require') ? { rejectUnauthorized:false } : undefined });

async function init(){
  if(!TOKEN) throw new Error('USTAWI_SYNC_TOKEN is required');
  await pool.query(`CREATE TABLE IF NOT EXISTS ustawi_records (
    entity TEXT NOT NULL,
    record_id TEXT NOT NULL,
    data_json JSONB,
    updated_at TIMESTAMPTZ NOT NULL,
    change_seq BIGINT NOT NULL DEFAULT 0,
    deleted BOOLEAN NOT NULL DEFAULT FALSE,
    PRIMARY KEY(entity,record_id)
  );
  CREATE TABLE IF NOT EXISTS ustawi_sync_log (
    seq BIGSERIAL PRIMARY KEY,
    operation_id TEXT UNIQUE NOT NULL,
    device_id TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
  );`);
}
function authorized(req){return !!TOKEN && req.get('x-ustawi-token')===TOKEN;}
function validEntity(e){return ['users','inventory','finance','production','technical','demoplots','governance'].includes(e);}

app.get('/api/health', async (req,res)=>{try{await pool.query('SELECT 1');res.json({ok:true,service:'ustawi-sync'});}catch(e){res.status(503).json({ok:false,error:'Database unavailable'});}});

app.post('/api/sync', async (req,res)=>{
  if(!authorized(req)) return res.status(401).json({ok:false,error:'Unauthorized'});
  const client=await pool.connect();
  try{
    await client.query('BEGIN');
    const acknowledged=[];
    for(const op of req.body.operations||[]){
      if(!op.id||!validEntity(op.entity)) continue;
      const existingLog=await client.query('SELECT operation_id FROM ustawi_sync_log WHERE operation_id=$1',[op.id]);
      if(existingLog.rowCount){acknowledged.push(op.id);continue;}
      const logRow=await client.query('INSERT INTO ustawi_sync_log(operation_id,device_id) VALUES($1,$2) RETURNING seq',[op.id,op.deviceId||'unknown']);
      const seq=logRow.rows[0].seq;
      const updatedAt=op.record?.updatedAt||op.createdAt||new Date().toISOString();
      const id=op.record?.id||op.id;
      const data=op.action==='delete'?null:op.record;
      await client.query(`INSERT INTO ustawi_records(entity,record_id,data_json,updated_at,change_seq,deleted) VALUES($1,$2,$3,$4,$5,$6)
        ON CONFLICT(entity,record_id) DO UPDATE SET data_json=EXCLUDED.data_json,updated_at=EXCLUDED.updated_at,change_seq=EXCLUDED.change_seq,deleted=EXCLUDED.deleted
        WHERE EXCLUDED.updated_at >= ustawi_records.updated_at`,[op.entity,id,data,updatedAt,seq,op.action==='delete']);
      acknowledged.push(op.id);
    }
    const cursor=String((await client.query('SELECT COALESCE(MAX(seq),0) seq FROM ustawi_sync_log')).rows[0].seq);
    const since=Number(req.body.cursor||0);
    const changes=await client.query(`SELECT entity,record_id AS id,data_json AS data,updated_at AS "updatedAt",deleted,change_seq AS seq
      FROM ustawi_records WHERE change_seq > $1 ORDER BY change_seq ASC`, [since]);
    await client.query('COMMIT');
    res.json({ok:true,cursor,acknowledgedOperationIds:acknowledged,changes:changes.rows.filter(x=>Number(x.seq)>since).map(x=>({...x,data:x.deleted?null:x.data}))});
  }catch(e){await client.query('ROLLBACK');res.status(500).json({ok:false,error:'Synchronization failed'});}finally{client.release();}
});

init().then(()=>app.listen(PORT,()=>console.log(`Ustawi sync server listening on ${PORT}`))).catch(e=>{console.error(e);process.exit(1);});
