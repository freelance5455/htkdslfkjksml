# Smart — Play Store Draft

Short description:
Your AI assistant for supported Android actions, automation and device control.

Full description:
Smart is an AI-powered Android assistant designed to help you perform supported phone actions using natural-language commands.

With Smart, you can:
• Open supported apps and websites
• Open Android Settings
• Start calls through the system dialer
• Compose SMS messages through Android's supported interface
• Set alarms
• Control supported media actions
• Use authorized accessibility features for Home, Back and Recent Apps
• Read notifications only after you explicitly enable Android notification access

Smart Pro is planned for higher usage limits and advanced features.

Privacy:
Smart should only request permissions required for features you choose to use. Do not enable Accessibility or Notification Access unless you understand why the feature needs it.
