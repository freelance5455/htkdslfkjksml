import 'dotenv/config';
import express from 'express';
import fs from 'fs';
import os from 'os';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { initDatabase, recordErrorLog } from './server/db.ts';
import { createApiRouter } from './server/routes.ts';

async function bootstrapServer() {
  initDatabase();

  const app = express();
  const PORT = Number(process.env.PORT) || 3000;

  // Security headers (allow same-origin iframe preview)
  app.use((_req, res, next) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-Frame-Options', 'SAMEORIGIN');
    res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
    next();
  });

  app.use(express.json({ limit: '10mb' }));
  app.use(express.urlencoded({ extended: true }));

  app.use('/api', createApiRouter());

  // Global API error handler with persistent error logging
  app.use((err: Error, req: express.Request, res: express.Response, next: express.NextFunction) => {
    if (!req.path.startsWith('/api')) {
      next(err);
      return;
    }
    console.error('[API Error]', err.message);
    recordErrorLog({
      source: 'api_middleware',
      level: 'error',
      message: err.message || 'Sunucu içi hata',
      stack: err.stack || null,
      path: `${req.method} ${req.originalUrl}`,
    });
    res.status(500).json({ error: err.message || 'Sunucu içi bir hata oluştu.' });
  });

  // Periodic cleanup of stale temporary build directories older than 1 hour
  setInterval(() => {
    try {
      const tmpRoot = os.tmpdir();
      const entries = fs.readdirSync(tmpRoot);
      const cutoff = Date.now() - 60 * 60 * 1000;
      for (const name of entries) {
        if (
          name.startsWith('apk-studio-build-') ||
          name.startsWith('apk-inspect-') ||
          name.startsWith('apk-admin-')
        ) {
          const full = path.join(tmpRoot, name);
          const stat = fs.statSync(full);
          if (stat.mtimeMs < cutoff) {
            fs.rmSync(full, { recursive: true, force: true });
          }
        }
      }
    } catch {
      // ignore cleanup errors
    }
  }, 15 * 60 * 1000);

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`HTML TO APK STUDIO sunucusu http://localhost:${PORT} adresinde çalışıyor.`);
  });
}

bootstrapServer().catch((err) => {
  console.error('Sunucu başlatılamadı:', err);
  process.exit(1);
});
