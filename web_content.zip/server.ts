import express from 'express';
import type { Request, Response } from 'express';
import { GoogleGenAI } from '@google/genai';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = Number(process.env.PORT) || 3000;

app.use(express.json({ limit: '25mb' }));
app.use(express.urlencoded({ extended: true, limit: '25mb' }));

// Initialize GoogleGenAI client on the server side
const apiKey = process.env.GEMINI_API_KEY || '';
const ai = apiKey
  ? new GoogleGenAI({
      apiKey: apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    })
  : null;

// System instruction for HANN AI
const SYSTEM_INSTRUCTION_BASE = `Nama anda ialah "HANN AI", sebuah chatbot kecerdasan buatan moden yang peramah, pintar, dan santai.
Anda dicipta khas untuk berinteraksi dalam Bahasa Melayu.

Prinsip dan personaliti anda:
1. BAHASA & NADA:
   - Gunakan Bahasa Melayu yang santai, mesra, bersahaja dan bertenaga (seperti kawan rapat).
   - Anda sangat fasih dan mahir dalam dialek/loghat Utara Semenanjung Malaysia (Kedah, Perlis, Pulau Pinang).
   - Apabila pengguna bercakap menggunakan loghat utara atau meminta berbual dalam loghat utara, gunakan kosa kata loghat utara secara bersahaja dan tulen (contoh: "hang", "cek", "depa", "habaq", "awat", "lagu tu", "lagu mana", "ceriat", "ketegaq", "segak", "cemuih", "gabra", "satgi", "padu bak hang", "perabih", "berlemun").
   - Jangan gunakan bahasa baku yang kaku melainkan diminta oleh pengguna.
   - Walaupun santai dan suka berseloroh mesra, jawapan anda tetap bijak, tepat fakta, kreatif, berstruktur dan sangat membantu.

2. KEMAHIRAN & TOPIK:
   - Boleh menjawab apa jua topik: sembang santai, panduan makanan (cth: port makan nasi kandar, laksa Kedah, char kuey teow), sains, koding, teknologi, kerja sekolah, terjemahan, motivasi atau penulisan kreatif.
   - Suka memberikan format jawapan yang kemas dengan markdown (senarai bullet point, penekanan bold, dsb.) jika soalan memerlukan penerangan berstruktur.

3. SIKAP:
   - Positif, ceria, kelakar bila bersesuaian, sopan dan sentiasa sedia tolong "hang".`;

const SYSTEM_INSTRUCTIONS_BY_MODE: Record<string, string> = {
  utara: `${SYSTEM_INSTRUCTION_BASE}\n\n[MOD KHAS: LOGHAT UTARA PEKAT]\nUntuk perbualan ini, gunakan loghat utara (Kedah/Penang) yang lebih pekat dan bersahaja! Panggil diri anda 'cek' atau 'aku/kami' dan panggil pengguna 'hang'. Selitkan loghat utara yang sempoi dan hidup!`,
  santai: `${SYSTEM_INSTRUCTION_BASE}\n\n[MOD KHAS: SANTAI BIASA]\nGunakan Bahasa Melayu santai harian (slanga mesra Malaysia biasa seperti 'korang/awak/kita', tapi tetap sedia bertukar loghat utara jika dipancing).`,
  formal: `${SYSTEM_INSTRUCTION_BASE}\n\n[MOD KHAS: ILMIAH & TERTIB]\nGunakan Bahasa Melayu standard yang tertib, bernas, berstruktur tinggi dan profesional namun tetap mesra.`,
};

async function generateWithModelFallback(
  genAiClient: GoogleGenAI,
  contents: any[],
  systemInstruction: string
): Promise<{ text: string; model: string }> {
  // Use fast 8s timeout for gemini-3.1-flash-lite (which finishes in 1-2s), avoiding long hangs
  const attempts = [
    { model: 'gemini-3.1-flash-lite', timeout: 8000 },
    { model: 'gemini-3.1-flash-lite', timeout: 8000 },
    { model: 'gemini-3.8-flash', timeout: 6000 },
  ];

  let lastError: any = null;

  for (let i = 0; i < attempts.length; i++) {
    const { model, timeout } = attempts[i];
    try {
      console.log(`[HANN AI] Generation attempt ${i + 1} with model: ${model}`);
      const response = await Promise.race([
        genAiClient.models.generateContent({
          model,
          contents,
          config: {
            systemInstruction,
            temperature: 0.85,
          },
        }),
        new Promise<never>((_, reject) =>
          setTimeout(() => reject(new Error(`Model ${model} mengambil masa melebihi ${timeout / 1000} saat.`)), timeout)
        ),
      ]);

      const text = response.text;
      if (text && text.trim().length > 0) {
        console.log(`[HANN AI] Model ${model} succeeded on attempt ${i + 1}`);
        return { text: text.trim(), model };
      }
    } catch (err: any) {
      lastError = err;
      console.warn(`[HANN AI] Attempt ${i + 1} (${model}) failed:`, err?.message || err);
      await new Promise((r) => setTimeout(r, 300));
    }
  }

  throw lastError || new Error('Pelayan AI sedang sibuk. Sila tekan butang Cuba Semula.');
}

// Chat API endpoint
app.post('/api/chat', async (req: Request, res: Response): Promise<void> => {
  try {
    if (!ai || !process.env.GEMINI_API_KEY) {
      res.status(500).json({
        error: 'Kunci API Gemini (GEMINI_API_KEY) tidak dijumpai di bahagian server. Sila pastikan kunci API telah dikonfigurasi dalam panel Secrets.',
      });
      return;
    }

    const { messages, mode = 'utara' } = req.body;

    if (!Array.isArray(messages) || messages.length === 0) {
      res.status(400).json({ error: 'Sila masukkan mesej yang sah.' });
      return;
    }

    // Filter and sanitize chat history:
    // 1. Remove empty messages
    // 2. Remove error notification messages from history so they don't corrupt the prompt
    const sanitizedContents = messages
      .filter((m: any) => {
        if (!m || typeof m.content !== 'string') return false;
        const text = m.content.trim();
        if (text.length === 0) return false;
        // Ignore error messages stored in history
        if (text.startsWith('⚠️') || text.startsWith('Ralat:')) return false;
        return true;
      })
      .map((m: any) => ({
        role: m.role === 'assistant' || m.role === 'model' ? 'model' : 'user',
        parts: [{ text: m.content.trim() }],
      }));

    if (sanitizedContents.length === 0) {
      res.status(400).json({ error: 'Mesej anda kosong. Sila taip sesuatu sebelum menghantar.' });
      return;
    }

    const selectedInstruction = SYSTEM_INSTRUCTIONS_BY_MODE[mode] || SYSTEM_INSTRUCTION_BASE;

    const result = await generateWithModelFallback(ai, sanitizedContents, selectedInstruction);

    res.json({
      reply: result.text,
      model: result.model,
      success: true,
    });
  } catch (error: any) {
    console.error('[HANN AI] Error generating AI response:', error);
    let errorMessage = 'Maaf hang, pelayan AI menghadapi masalah teknikal.';

    if (error?.message) {
      try {
        const parsed = JSON.parse(error.message);
        if (parsed?.error?.message) {
          errorMessage = parsed.error.message;
        } else {
          errorMessage = error.message;
        }
      } catch {
        errorMessage = error.message;
      }
    }

    if (errorMessage.includes('503') || errorMessage.includes('high demand') || errorMessage.includes('UNAVAILABLE')) {
      errorMessage = 'Model AI sedang menerima permintaan yang terlalu tinggi pada masa ini. Sila cuba hantar sekali lagi sebentar lagi.';
    }

    res.status(500).json({
      error: errorMessage,
      success: false,
    });
  }
});

// AI Image Editing endpoint using gemini-3.1-flash-lite-image
app.post('/api/image/edit', async (req: Request, res: Response): Promise<void> => {
  try {
    if (!ai || !process.env.GEMINI_API_KEY) {
      res.status(500).json({
        error: 'Kunci API Gemini (GEMINI_API_KEY) tidak dijumpai di bahagian server.',
        requiresPaidKey: true,
      });
      return;
    }

    const { image, prompt, aspectRatio = '1:1' } = req.body;

    if (!prompt || typeof prompt !== 'string' || !prompt.trim()) {
      res.status(400).json({ error: 'Sila masukkan arahan suntingan untuk gambar.' });
      return;
    }

    const parts: any[] = [];

    // Parse base64 source image if provided
    if (image && typeof image === 'string') {
      let mimeType = 'image/jpeg';
      let base64Data = image;

      if (image.startsWith('data:')) {
        const matches = image.match(/^data:([a-zA-Z0-9]+\/[a-zA-Z0-9-.+]+);base64,(.+)$/);
        if (matches) {
          mimeType = matches[1];
          base64Data = matches[2];
        }
      }

      parts.push({
        inlineData: {
          mimeType,
          data: base64Data,
        },
      });
    }

    // Add prompt instruction
    parts.push({
      text: prompt.trim(),
    });

    console.log(`[HANN AI Image] Requesting image edit with prompt: "${prompt}"`);

    const validAspectRatios = ['1:1', '3:4', '4:3', '9:16', '16:9'];
    const selectedAspectRatio = validAspectRatios.includes(aspectRatio) ? aspectRatio : '1:1';

    const response = await ai.models.generateContent({
      model: 'gemini-3.1-flash-lite-image',
      contents: { parts },
      config: {
        imageConfig: {
          aspectRatio: selectedAspectRatio,
        },
      },
    });

    let generatedImageUrl = '';
    let explanationText = '';

    const candidates = response.candidates;
    if (candidates && candidates[0]?.content?.parts) {
      for (const part of candidates[0].content.parts) {
        if (part.inlineData?.data) {
          const mime = part.inlineData.mimeType || 'image/png';
          generatedImageUrl = `data:${mime};base64,${part.inlineData.data}`;
        } else if (part.text) {
          explanationText += part.text;
        }
      }
    }

    if (!generatedImageUrl) {
      res.status(500).json({
        error: 'Model AI tidak memulangkan imej hasil suntingan. ' + (explanationText || 'Sila cuba arahan lain.'),
        explanation: explanationText,
      });
      return;
    }

    console.log('[HANN AI Image] Successfully generated edited image.');
    res.json({
      success: true,
      imageUrl: generatedImageUrl,
      text: explanationText,
      prompt,
    });
  } catch (error: any) {
    console.error('[HANN AI Image] Error:', error);
    let errorMessage = error?.message || 'Ralat semasa memproses suntingan imej.';
    let isQuotaError = false;

    if (
      errorMessage.includes('quota') ||
      errorMessage.includes('RESOURCE_EXHAUSTED') ||
      errorMessage.includes('429') ||
      errorMessage.includes('billing')
    ) {
      isQuotaError = true;
      errorMessage =
        'Model imej Google Gemini (gemini-3.1-flash-lite-image) memerlukan akaun pengebilan (Paid API Key / Pay-as-you-go). Kuota percuma tidak menyokong model imej.';
    }

    res.status(500).json({
      error: errorMessage,
      requiresPaidKey: isQuotaError,
      details: error?.message,
    });
  }
});

// Free AI Image Vision Analysis endpoint using gemini-3.1-flash-lite
app.post('/api/image/analyze', async (req: Request, res: Response): Promise<void> => {
  try {
    if (!ai || !process.env.GEMINI_API_KEY) {
      res.status(500).json({ error: 'Kunci API Gemini tidak dijumpai.' });
      return;
    }

    const { image, prompt } = req.body;

    if (!image || typeof image !== 'string') {
      res.status(400).json({ error: 'Sila berikan gambar untuk dianalisis.' });
      return;
    }

    let mimeType = 'image/jpeg';
    let base64Data = image;

    if (image.startsWith('data:')) {
      const matches = image.match(/^data:([a-zA-Z0-9]+\/[a-zA-Z0-9-.+]+);base64,(.+)$/);
      if (matches) {
        mimeType = matches[1];
        base64Data = matches[2];
      }
    }

    const defaultPrompt =
      'Lihat gambar ini dan habaq mai dalam loghat utara santai HANN AI: apa yang ada dalam gambar ni, apa yang menarik atau lawak, dan cadangkan 3 idea gaya suntingan atau warna yang padu untuk gambar ni!';

    const response = await ai.models.generateContent({
      model: 'gemini-3.1-flash-lite',
      contents: [
        {
          role: 'user',
          parts: [
            { inlineData: { mimeType, data: base64Data } },
            { text: prompt?.trim() || defaultPrompt },
          ],
        },
      ],
      config: {
        systemInstruction: SYSTEM_INSTRUCTION_BASE,
        temperature: 0.85,
      },
    });

    res.json({
      success: true,
      reply: response.text || 'Tak dapat ulas gambar tadi, cuba lagi sat!',
    });
  } catch (error: any) {
    console.error('[HANN AI Vision] Error:', error);
    res.status(500).json({
      success: false,
      error: error?.message || 'Gagal menganalisis gambar.',
    });
  }
});

// Health check endpoint
app.get('/api/health', (_req: Request, res: Response) => {
  res.json({
    status: 'ok',
    bot: 'HANN AI',
    hasApiKey: Boolean(process.env.GEMINI_API_KEY),
    timestamp: new Date().toISOString(),
  });
});

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`🚀 HANN AI Server running at http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
});
