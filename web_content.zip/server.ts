import express from 'express';
import { createServer } from 'http';
import path from 'path';
import { fileURLToPath } from 'url';
import { WebSocket, WebSocketServer } from 'ws';
import { generateStandaloneHtml } from './serverHtmlExport.ts';
import {
  calculateHandPoints,
  canPlayCard,
  chooseBestColorForHand,
  chooseBotMove,
  createUnoFlipDeck,
  formatFaceNameId,
  getCardFace,
  getDefaultColorForSide,
  isColorValidForSide,
  shuffleArray,
} from './src/shared/unoEngine.ts';
import {
  COLOR_LABELS_ID,
  type ActionLogEntry,
  type ActiveColor,
  type AvatarId,
  type ClientMessage,
  type EmoteBubble,
  type PublicPlayer,
  type PublicRoomState,
  type RoomPhase,
  type RoomSettings,
  type RoundSummary,
  type ServerMessage,
  type Side,
  type SoundCue,
  type UnoCardData,
} from './src/shared/unoTypes.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface ServerPlayer {
  id: string;
  name: string;
  avatar: AvatarId;
  isBot: boolean;
  isHost: boolean;
  connected: boolean;
  hand: UnoCardData[];
  score: number;
  calledUno: boolean;
  unoVulnerable: boolean;
  ws: WebSocket | null;
}

interface ServerRoom {
  code: string;
  phase: RoomPhase;
  settings: RoomSettings;
  roundNumber: number;
  activeSide: Side;
  activeColor: ActiveColor;
  direction: 1 | -1;
  currentTurnIndex: number;
  turnDeadline: number | null;
  drawPile: UnoCardData[];
  discardPile: UnoCardData[];
  players: ServerPlayer[];
  pendingDrawnCardId: string | null;
  pendingFlipColorPickerPlayerId: string | null;
  lastCue: { id: string; cue: SoundCue } | null;
  lastEventText: string;
  actionLog: ActionLogEntry[];
  emotes: EmoteBubble[];
  roundSummary: RoundSummary | null;
  matchWinnerId: string | null;
  botTimer: ReturnType<typeof setTimeout> | null;
  turnTimer: ReturnType<typeof setTimeout> | null;
  cleanupTimer: ReturnType<typeof setTimeout> | null;
}

const BOT_NAMES = ['Raka Bot', 'Sinta Bot', 'Bima Bot', 'Nadia Bot', 'Arka Bot'];
const BOT_AVATARS: AvatarId[] = ['diamond', 'flame', 'bolt', 'crown', 'prism'];

const rooms = new Map<string, ServerRoom>();
const socketSession = new WeakMap<WebSocket, { roomCode: string; playerId: string }>();

function generateId(prefix = 'id'): string {
  return `${prefix}_${Math.random().toString(36).slice(2, 10)}`;
}

function generateRoomCode(): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let code = '';
  for (let i = 0; i < 6; i++) {
    code += chars[Math.floor(Math.random() * chars.length)];
  }
  return rooms.has(code) ? generateRoomCode() : code;
}

function addLog(room: ServerRoom, text: string, tone: ActionLogEntry['tone'] = 'neutral'): void {
  room.lastEventText = text;
  room.actionLog.unshift({
    id: generateId('log'),
    text,
    timestamp: Date.now(),
    tone,
  });
  if (room.actionLog.length > 30) {
    room.actionLog.length = 30;
  }
}

function setCue(room: ServerRoom, cue: SoundCue): void {
  room.lastCue = { id: generateId('cue'), cue };
}

function clearRoomTimers(room: ServerRoom): void {
  if (room.botTimer) {
    clearTimeout(room.botTimer);
    room.botTimer = null;
  }
  if (room.turnTimer) {
    clearTimeout(room.turnTimer);
    room.turnTimer = null;
  }
}

function scheduleRoomCleanupIfEmpty(room: ServerRoom): void {
  if (room.cleanupTimer) {
    clearTimeout(room.cleanupTimer);
    room.cleanupTimer = null;
  }
  const hasConnectedHuman = room.players.some((p) => !p.isBot && p.connected);
  if (!hasConnectedHuman) {
    room.cleanupTimer = setTimeout(() => {
      const current = rooms.get(room.code);
      if (current && !current.players.some((p) => !p.isBot && p.connected)) {
        clearRoomTimers(current);
        rooms.delete(current.code);
      }
    }, 5 * 60 * 1000);
  }
}

function sendJson(ws: WebSocket | null, payload: ServerMessage): void {
  if (ws && ws.readyState === WebSocket.OPEN) {
    ws.send(JSON.stringify(payload));
  }
}

function serializeRoomForPlayer(room: ServerRoom, playerId: string): PublicRoomState {
  const me = room.players.find((p) => p.id === playerId);
  const now = Date.now();
  // Prune old emotes (> 4s)
  room.emotes = room.emotes.filter((e) => now - e.timestamp < 4500);

  const publicPlayers: PublicPlayer[] = room.players.map((p) => ({
    id: p.id,
    name: p.name,
    avatar: p.avatar,
    isBot: p.isBot,
    isHost: p.isHost,
    connected: p.connected,
    cardCount: p.hand.length,
    score: p.score,
    calledUno: p.calledUno,
    unoVulnerable: p.unoVulnerable,
  }));

  const topCard = room.discardPile.length > 0 ? room.discardPile[room.discardPile.length - 1] : null;
  const previousCard = room.discardPile.length > 1 ? room.discardPile[room.discardPile.length - 2] : null;

  return {
    code: room.code,
    phase: room.phase,
    settings: room.settings,
    roundNumber: room.roundNumber,
    activeSide: room.activeSide,
    activeColor: room.activeColor,
    direction: room.direction,
    currentTurnIndex: room.currentTurnIndex,
    turnDeadline: room.turnDeadline,
    drawPileCount: room.drawPile.length,
    topCard,
    previousCard,
    players: publicPlayers,
    myId: playerId,
    myHand: me ? me.hand : [],
    pendingDrawnCardId:
      me && room.players[room.currentTurnIndex]?.id === me.id ? room.pendingDrawnCardId : null,
    pendingFlipColorPickerPlayerId: room.pendingFlipColorPickerPlayerId,
    lastCue: room.lastCue,
    lastEventText: room.lastEventText,
    actionLog: room.actionLog,
    emotes: room.emotes,
    roundSummary: room.roundSummary,
    matchWinnerId: room.matchWinnerId,
  };
}

function broadcastRoom(room: ServerRoom): void {
  for (const player of room.players) {
    if (!player.isBot && player.ws) {
      sendJson(player.ws, {
        type: 'state_sync',
        state: serializeRoomForPlayer(room, player.id),
      });
    }
  }
}

function getNextIndex(room: ServerRoom, fromIndex: number, steps = 1): number {
  const n = room.players.length;
  return (((fromIndex + room.direction * steps) % n) + n) % n;
}

function drawFromPile(room: ServerRoom, count: number): UnoCardData[] {
  const drawn: UnoCardData[] = [];
  for (let i = 0; i < count; i++) {
    if (room.drawPile.length === 0) {
      if (room.discardPile.length > 1) {
        const top = room.discardPile.pop()!;
        room.drawPile = shuffleArray(room.discardPile);
        room.discardPile = [top];
      } else {
        break;
      }
    }
    const card = room.drawPile.pop();
    if (card) drawn.push(card);
  }
  return drawn;
}

function clearUnoVulnerabilities(room: ServerRoom, exceptPlayerId?: string): void {
  for (const p of room.players) {
    if (p.id !== exceptPlayerId) {
      p.unoVulnerable = false;
    }
  }
}

function startNewRound(room: ServerRoom, isFirstRound: boolean): void {
  clearRoomTimers(room);

  if (isFirstRound) {
    room.roundNumber = 1;
    for (const p of room.players) {
      p.score = 0;
    }
    room.matchWinnerId = null;
  } else {
    room.roundNumber += 1;
  }

  room.phase = 'PLAYING';
  room.activeSide = 'light';
  room.direction = 1;
  room.pendingDrawnCardId = null;
  room.pendingFlipColorPickerPlayerId = null;
  room.roundSummary = null;

  const deck = createUnoFlipDeck();
  for (const p of room.players) {
    p.hand = deck.splice(0, 7);
    p.calledUno = false;
    p.unoVulnerable = false;
  }

  // Pick a non-wild starting card on light side for clean round starts
  let startIdx = deck.findIndex((c) => c.light.color !== 'wild' && c.light.value !== 'flip');
  if (startIdx === -1) startIdx = 0;
  const [firstCard] = deck.splice(startIdx, 1);

  room.drawPile = deck;
  room.discardPile = [firstCard];
  room.activeColor =
    firstCard.light.color === 'wild'
      ? getDefaultColorForSide('light')
      : (firstCard.light.color as ActiveColor);

  room.currentTurnIndex = Math.floor(Math.random() * room.players.length);
  const starter = room.players[room.currentTurnIndex];

  addLog(
    room,
    `Ronde ${room.roundNumber} dimulai! Giliran pertama: ${starter.name}.`,
    'neutral'
  );
  setCue(room, 'play');

  scheduleTurnHooks(room);
  broadcastRoom(room);
}

function handleRoundVictory(room: ServerRoom, winner: ServerPlayer): void {
  clearRoomTimers(room);
  room.turnDeadline = null;
  room.pendingDrawnCardId = null;
  room.pendingFlipColorPickerPlayerId = null;

  let pointsEarned = 0;
  const breakdowns = room.players.map((p) => {
    const handPts = p.id === winner.id ? 0 : calculateHandPoints(p.hand, room.activeSide);
    pointsEarned += handPts;
    return {
      playerId: p.id,
      playerName: p.name,
      remainingCards: p.hand.length,
      handPoints: handPts,
      totalScore: p.id === winner.id ? p.score : p.score,
    };
  });

  winner.score += pointsEarned;
  for (const b of breakdowns) {
    if (b.playerId === winner.id) {
      b.totalScore = winner.score;
    }
  }

  room.roundSummary = {
    roundNumber: room.roundNumber,
    winnerId: winner.id,
    winnerName: winner.name,
    pointsEarned,
    playerBreakdowns: breakdowns.sort((a, b) => b.totalScore - a.totalScore),
  };

  const reachedTarget =
    room.settings.targetScore === 0 || winner.score >= room.settings.targetScore;

  if (reachedTarget) {
    room.phase = 'GAME_OVER';
    room.matchWinnerId = winner.id;
    addLog(
      room,
      `${winner.name} memenangkan pertandingan dengan ${winner.score} poin!`,
      'win'
    );
  } else {
    room.phase = 'ROUND_OVER';
    addLog(
      room,
      `${winner.name} memenangkan Ronde ${room.roundNumber} (+${pointsEarned} poin)!`,
      'win'
    );
  }

  setCue(room, 'win');
  broadcastRoom(room);
}

function scheduleTurnHooks(room: ServerRoom): void {
  clearRoomTimers(room);
  if (room.phase !== 'PLAYING') return;

  const current = room.players[room.currentTurnIndex];
  if (!current) return;

  // If awaiting flip wild color picker from human or bot
  if (room.pendingFlipColorPickerPlayerId) {
    const picker = room.players.find((p) => p.id === room.pendingFlipColorPickerPlayerId);
    if (picker?.isBot) {
      room.botTimer = setTimeout(() => {
        if (room.phase !== 'PLAYING' || !room.pendingFlipColorPickerPlayerId) return;
        const best = chooseBestColorForHand(picker.hand, room.activeSide);
        applyFlipWildColor(room, picker.id, best);
      }, 750);
    }
    return;
  }

  // Set turn timer if enabled and player is human
  if (room.settings.turnSeconds > 0 && !current.isBot) {
    room.turnDeadline = Date.now() + room.settings.turnSeconds * 1000;
    room.turnTimer = setTimeout(() => {
      if (room.phase !== 'PLAYING') return;
      const activePlayer = room.players[room.currentTurnIndex];
      if (!activePlayer || activePlayer.id !== current.id) return;

      if (room.pendingDrawnCardId) {
        performPassAfterDraw(room, current.id);
      } else {
        const drawn = drawFromPile(room, 1);
        current.hand.push(...drawn);
        current.calledUno = false;
        current.unoVulnerable = false;
        addLog(room, `${current.name} kehabisan waktu dan mengambil 1 kartu.`, 'neutral');
        room.currentTurnIndex = getNextIndex(room, room.currentTurnIndex, 1);
        setCue(room, 'draw');
        scheduleTurnHooks(room);
        broadcastRoom(room);
      }
    }, room.settings.turnSeconds * 1000);
  } else {
    room.turnDeadline = null;
  }

  // Bot automatic play
  if (current.isBot) {
    const delay = 750 + Math.floor(Math.random() * 450);
    room.botTimer = setTimeout(() => {
      executeBotTurn(room, current.id);
    }, delay);
  }
}

function executeBotTurn(room: ServerRoom, botId: string): void {
  if (room.phase !== 'PLAYING') return;
  const current = room.players[room.currentTurnIndex];
  if (!current || current.id !== botId) return;

  const topCard = room.discardPile[room.discardPile.length - 1] ?? null;
  const nextPlayer = room.players[getNextIndex(room, room.currentTurnIndex, 1)];
  const move = chooseBotMove(
    current.hand,
    topCard,
    room.activeColor,
    room.activeSide,
    nextPlayer ? nextPlayer.hand.length : 7
  );

  if (move) {
    // 85% chance bot remembers to call UNO when dropping to 1 card
    if (current.hand.length === 2 && Math.random() < 0.85) {
      current.calledUno = true;
    }
    performPlayCard(room, botId, move.card.id, move.chosenColor);
  } else {
    // Draw 1 card; if playable, play it immediately
    const [drawn] = drawFromPile(room, 1);
    if (!drawn) {
      room.currentTurnIndex = getNextIndex(room, room.currentTurnIndex, 1);
      scheduleTurnHooks(room);
      broadcastRoom(room);
      return;
    }
    current.hand.push(drawn);
    current.calledUno = false;
    current.unoVulnerable = false;

    if (canPlayCard(drawn, topCard, room.activeColor, room.activeSide)) {
      const face = getCardFace(drawn, room.activeSide);
      const chosenColor =
        face.color === 'wild'
          ? chooseBestColorForHand(
              current.hand.filter((c) => c.id !== drawn.id),
              room.activeSide
            )
          : undefined;
      addLog(room, `${current.name} mengambil kartu dan langsung memainkannya!`, 'neutral');
      performPlayCard(room, botId, drawn.id, chosenColor);
    } else {
      addLog(room, `${current.name} mengambil 1 kartu.`, 'neutral');
      setCue(room, 'draw');
      room.currentTurnIndex = getNextIndex(room, room.currentTurnIndex, 1);
      scheduleTurnHooks(room);
      broadcastRoom(room);
    }
  }
}

function applyFlipWildColor(room: ServerRoom, playerId: string, chosenColor: ActiveColor): void {
  if (room.pendingFlipColorPickerPlayerId !== playerId) return;
  if (!isColorValidForSide(chosenColor, room.activeSide)) return;

  const player = room.players.find((p) => p.id === playerId);
  room.activeColor = chosenColor;
  room.pendingFlipColorPickerPlayerId = null;
  addLog(
    room,
    `${player?.name ?? 'Pemain'} memilih warna ${COLOR_LABELS_ID[chosenColor]} setelah FLIP.`,
    'flip'
  );
  room.currentTurnIndex = getNextIndex(room, room.currentTurnIndex, 1);
  setCue(room, 'action');
  scheduleTurnHooks(room);
  broadcastRoom(room);
}

function performPlayCard(
  room: ServerRoom,
  playerId: string,
  cardId: string,
  chosenColor?: ActiveColor
): string | null {
  if (room.phase !== 'PLAYING') return 'Permainan belum dimulai.';
  if (room.pendingFlipColorPickerPlayerId) return 'Menunggu pemilihan warna hasil FLIP.';

  const player = room.players[room.currentTurnIndex];
  if (!player || player.id !== playerId) return 'Bukan giliran kamu.';

  const cardIdx = player.hand.findIndex((c) => c.id === cardId);
  if (cardIdx === -1) return 'Kartu tidak ditemukan di tangan.';

  const card = player.hand[cardIdx];
  const topCard = room.discardPile[room.discardPile.length - 1] ?? null;

  if (!canPlayCard(card, topCard, room.activeColor, room.activeSide)) {
    return 'Kartu tidak cocok dengan warna atau simbol di meja.';
  }

  const face = getCardFace(card, room.activeSide);
  if (face.color === 'wild') {
    if (!chosenColor || !isColorValidForSide(chosenColor, room.activeSide)) {
      return 'Pilih warna yang sesuai sisi meja aktif.';
    }
  }

  // Clear previous player's UNO vulnerability once someone makes a move
  clearUnoVulnerabilities(room, player.id);

  // Remove card from hand & push to discard
  player.hand.splice(cardIdx, 1);
  room.discardPile.push(card);
  room.pendingDrawnCardId = null;

  // Check UNO status if player now has 1 card
  if (player.hand.length === 1) {
    if (!player.calledUno) {
      player.unoVulnerable = true;
    }
  } else {
    player.calledUno = false;
    player.unoVulnerable = false;
  }

  // Immediate win check (even if last card is an action card!)
  if (player.hand.length === 0) {
    handleRoundVictory(room, player);
    return null;
  }

  // Update active color
  if (face.color === 'wild') {
    room.activeColor = chosenColor!;
  } else {
    room.activeColor = face.color as ActiveColor;
  }

  // Resolve special card effects
  const playerCount = room.players.length;
  let stepAdvance = 1;
  let cue: SoundCue = 'play';

  switch (face.value) {
    case 'draw1': {
      const victimIdx = getNextIndex(room, room.currentTurnIndex, 1);
      const victim = room.players[victimIdx];
      const drawn = drawFromPile(room, 1);
      victim.hand.push(...drawn);
      victim.calledUno = false;
      victim.unoVulnerable = false;
      stepAdvance = 2;
      cue = 'action';
      addLog(
        room,
        `${player.name} memainkan Ambil +1! ${victim.name} mengambil 1 kartu & dilewati.`,
        'action'
      );
      break;
    }
    case 'draw5': {
      const victimIdx = getNextIndex(room, room.currentTurnIndex, 1);
      const victim = room.players[victimIdx];
      const drawn = drawFromPile(room, 5);
      victim.hand.push(...drawn);
      victim.calledUno = false;
      victim.unoVulnerable = false;
      stepAdvance = 2;
      cue = 'action';
      addLog(
        room,
        `${player.name} melempar +5! ${victim.name} menarik 5 kartu & dilewati.`,
        'action'
      );
      break;
    }
    case 'skip': {
      const skipped = room.players[getNextIndex(room, room.currentTurnIndex, 1)];
      stepAdvance = 2;
      cue = 'action';
      addLog(room, `${player.name} memainkan Skip! ${skipped.name} dilewati.`, 'action');
      break;
    }
    case 'skip_all': {
      stepAdvance = 0; // Same player goes again!
      cue = 'action';
      addLog(
        room,
        `${player.name} memainkan Skip Semua! Semua lawan dilewati, main lagi!`,
        'action'
      );
      break;
    }
    case 'reverse': {
      room.direction = room.direction === 1 ? -1 : 1;
      cue = 'action';
      if (playerCount === 2) {
        stepAdvance = 0;
        addLog(room, `${player.name} memutar arah (2 pemain: main lagi!).`, 'action');
      } else {
        stepAdvance = 1;
        addLog(room, `${player.name} memutar arah permainan!`, 'action');
      }
      break;
    }
    case 'wild': {
      cue = 'action';
      addLog(
        room,
        `${player.name} memainkan Wild & memilih warna ${COLOR_LABELS_ID[room.activeColor]}.`,
        'action'
      );
      break;
    }
    case 'wild_draw2': {
      const victimIdx = getNextIndex(room, room.currentTurnIndex, 1);
      const victim = room.players[victimIdx];
      const drawn = drawFromPile(room, 2);
      victim.hand.push(...drawn);
      victim.calledUno = false;
      victim.unoVulnerable = false;
      stepAdvance = 2;
      cue = 'action';
      addLog(
        room,
        `${player.name} memainkan Wild +2 (${COLOR_LABELS_ID[room.activeColor]})! ${victim.name} menarik 2 kartu.`,
        'action'
      );
      break;
    }
    case 'wild_draw_color': {
      const victimIdx = getNextIndex(room, room.currentTurnIndex, 1);
      const victim = room.players[victimIdx];
      const targetColor = room.activeColor;
      let drawnCount = 0;
      while (drawnCount < 16) {
        const [d] = drawFromPile(room, 1);
        if (!d) break;
        victim.hand.push(d);
        drawnCount += 1;
        if (d.dark.color === targetColor) {
          break;
        }
      }
      victim.calledUno = false;
      victim.unoVulnerable = false;
      stepAdvance = 2;
      cue = 'action';
      addLog(
        room,
        `${player.name} memainkan Wild +Warna (${COLOR_LABELS_ID[targetColor]})! ${victim.name} menarik ${drawnCount} kartu.`,
        'action'
      );
      break;
    }
    case 'flip': {
      const newSide: Side = room.activeSide === 'light' ? 'dark' : 'light';
      room.activeSide = newSide;
      // Official UNO Flip rule: flip the discard pile upside down so bottom card becomes new top card
      if (room.discardPile.length > 1) {
        room.discardPile.reverse();
      }
      // Flip draw pile order as well
      room.drawPile.reverse();

      const newTop = room.discardPile[room.discardPile.length - 1];
      const newTopFace = getCardFace(newTop, newSide);
      cue = newSide === 'dark' ? 'flip_dark' : 'flip_light';

      if (newTopFace.color === 'wild') {
        room.activeColor = getDefaultColorForSide(newSide);
        room.pendingFlipColorPickerPlayerId = player.id;
        addLog(
          room,
          `FLIP! Meja berbalik ke ${newSide === 'dark' ? 'Sisi Gelap' : 'Sisi Terang'}! ${player.name} memilih warna baru.`,
          'flip'
        );
        setCue(room, cue);
        scheduleTurnHooks(room);
        broadcastRoom(room);
        return null;
      } else {
        room.activeColor = newTopFace.color as ActiveColor;
        addLog(
          room,
          `FLIP! ${player.name} membalik meja ke ${newSide === 'dark' ? 'Sisi Gelap' : 'Sisi Terang'} (${COLOR_LABELS_ID[room.activeColor]}).`,
          'flip'
        );
      }
      break;
    }
    default: {
      addLog(
        room,
        `${player.name} memainkan ${COLOR_LABELS_ID[room.activeColor]} ${formatFaceNameId(face)}.`,
        'neutral'
      );
      break;
    }
  }

  room.currentTurnIndex = getNextIndex(room, room.currentTurnIndex, stepAdvance);
  setCue(room, cue);
  scheduleTurnHooks(room);
  broadcastRoom(room);
  return null;
}

function performDrawCard(room: ServerRoom, playerId: string): string | null {
  if (room.phase !== 'PLAYING') return 'Permainan belum dimulai.';
  if (room.pendingFlipColorPickerPlayerId) return 'Menunggu pemilihan warna hasil FLIP.';
  const player = room.players[room.currentTurnIndex];
  if (!player || player.id !== playerId) return 'Bukan giliran kamu.';
  if (room.pendingDrawnCardId) return 'Kamu sudah mengambil 1 kartu, mainkan atau lewati.';

  clearUnoVulnerabilities(room, player.id);

  const [drawn] = drawFromPile(room, 1);
  if (!drawn) {
    addLog(room, `Tumpukan kartu habis, giliran ${player.name} dilewati.`, 'neutral');
    room.currentTurnIndex = getNextIndex(room, room.currentTurnIndex, 1);
    scheduleTurnHooks(room);
    broadcastRoom(room);
    return null;
  }

  player.hand.push(drawn);
  player.calledUno = false;
  player.unoVulnerable = false;
  setCue(room, 'draw');

  const topCard = room.discardPile[room.discardPile.length - 1] ?? null;
  if (canPlayCard(drawn, topCard, room.activeColor, room.activeSide)) {
    room.pendingDrawnCardId = drawn.id;
    addLog(room, `${player.name} mengambil 1 kartu (bisa langsung dimainkan).`, 'neutral');
    broadcastRoom(room);
  } else {
    addLog(room, `${player.name} mengambil 1 kartu.`, 'neutral');
    room.currentTurnIndex = getNextIndex(room, room.currentTurnIndex, 1);
    scheduleTurnHooks(room);
    broadcastRoom(room);
  }
  return null;
}

function performPassAfterDraw(room: ServerRoom, playerId: string): string | null {
  if (room.phase !== 'PLAYING') return 'Permainan belum dimulai.';
  const player = room.players[room.currentTurnIndex];
  if (!player || player.id !== playerId) return 'Bukan giliran kamu.';
  if (!room.pendingDrawnCardId) return 'Tidak ada kartu yang baru diambil.';

  room.pendingDrawnCardId = null;
  addLog(room, `${player.name} menyimpan kartu dan melewati giliran.`, 'neutral');
  room.currentTurnIndex = getNextIndex(room, room.currentTurnIndex, 1);
  scheduleTurnHooks(room);
  broadcastRoom(room);
  return null;
}

async function startServer() {
  const app = express();
  app.use(express.json());

  app.get('/api/health', (_req, res) => {
    res.json({ ok: true, rooms: rooms.size });
  });

  app.get('/api/download-html', async (req, res) => {
    try {
      const proto = (req.headers['x-forwarded-proto'] as string) || req.protocol || 'http';
      const host = req.headers.host || 'localhost:3000';
      const origin = process.env.APP_URL || `${proto}://${host}`;
      const html = await generateStandaloneHtml(origin);
      res.setHeader('Content-Type', 'text/html; charset=utf-8');
      res.setHeader('Content-Disposition', 'attachment; filename="ari-uno.html"');
      res.send(html);
    } catch (err) {
      console.error('Failed to build standalone HTML:', err);
      res.status(500).json({ error: 'Gagal membuat file HTML.' });
    }
  });

  app.get('/ari-uno.html', async (req, res) => {
    try {
      const proto = (req.headers['x-forwarded-proto'] as string) || req.protocol || 'http';
      const host = req.headers.host || 'localhost:3000';
      const origin = process.env.APP_URL || `${proto}://${host}`;
      const html = await generateStandaloneHtml(origin);
      res.setHeader('Content-Type', 'text/html; charset=utf-8');
      res.send(html);
    } catch (err) {
      console.error('Failed to serve standalone HTML:', err);
      res.status(500).send('Gagal memuat Ari Uno HTML.');
    }
  });

  app.get('/api/rooms/:code', (req, res) => {
    const code = String(req.params.code || '').toUpperCase().trim();
    const room = rooms.get(code);
    if (!room) {
      res.status(404).json({ exists: false, message: 'Room tidak ditemukan.' });
      return;
    }
    res.json({
      exists: true,
      code: room.code,
      phase: room.phase,
      playerCount: room.players.length,
    });
  });

  const server = createServer(app);
  const wss = new WebSocketServer({ server, path: '/ws' });

  wss.on('connection', (ws) => {
    ws.on('message', (raw) => {
      let msg: ClientMessage;
      try {
        msg = JSON.parse(String(raw)) as ClientMessage;
      } catch {
        sendJson(ws, { type: 'error', message: 'Format pesan tidak valid.' });
        return;
      }

      if (msg.type === 'create_room') {
        const cleanName = (msg.name || 'Pemain').trim().slice(0, 18) || 'Pemain';
        const code = generateRoomCode();
        const playerId = generateId('p');
        const host: ServerPlayer = {
          id: playerId,
          name: cleanName,
          avatar: msg.avatar || 'spade',
          isBot: false,
          isHost: true,
          connected: true,
          hand: [],
          score: 0,
          calledUno: false,
          unoVulnerable: false,
          ws,
        };

        const room: ServerRoom = {
          code,
          phase: 'LOBBY',
          settings: { targetScore: 500, turnSeconds: 25 },
          roundNumber: 0,
          activeSide: 'light',
          activeColor: 'red',
          direction: 1,
          currentTurnIndex: 0,
          turnDeadline: null,
          drawPile: [],
          discardPile: [],
          players: [host],
          pendingDrawnCardId: null,
          pendingFlipColorPickerPlayerId: null,
          lastCue: null,
          lastEventText: `${cleanName} membuat room ${code}.`,
          actionLog: [],
          emotes: [],
          roundSummary: null,
          matchWinnerId: null,
          botTimer: null,
          turnTimer: null,
          cleanupTimer: null,
        };

        if (msg.soloWithBots) {
          room.settings.targetScore = 0; // quick 1-round default for solo instant play (can replay)
          for (let i = 0; i < 3; i++) {
            room.players.push({
              id: generateId('bot'),
              name: BOT_NAMES[i],
              avatar: BOT_AVATARS[i % BOT_AVATARS.length],
              isBot: true,
              isHost: false,
              connected: true,
              hand: [],
              score: 0,
              calledUno: false,
              unoVulnerable: false,
              ws: null,
            });
          }
        }

        rooms.set(code, room);
        socketSession.set(ws, { roomCode: code, playerId });
        sendJson(ws, { type: 'room_joined', code, playerId });

        if (msg.soloWithBots) {
          startNewRound(room, true);
        } else {
          addLog(room, `${cleanName} membuka meja mabar ${code}.`, 'neutral');
          broadcastRoom(room);
        }
        return;
      }

      if (msg.type === 'join_room') {
        const code = (msg.code || '').toUpperCase().trim();
        const room = rooms.get(code);
        if (!room) {
          sendJson(ws, { type: 'error', message: `Room ${code} tidak ditemukan.` });
          return;
        }

        // Attempt reconnect if matching playerId provided
        if (msg.playerId) {
          const existing = room.players.find((p) => p.id === msg.playerId);
          if (existing) {
            existing.ws = ws;
            existing.connected = true;
            if (room.cleanupTimer) {
              clearTimeout(room.cleanupTimer);
              room.cleanupTimer = null;
            }
            socketSession.set(ws, { roomCode: code, playerId: existing.id });
            sendJson(ws, { type: 'room_joined', code, playerId: existing.id });
            broadcastRoom(room);
            return;
          }
        }

        if (room.phase !== 'LOBBY') {
          sendJson(ws, { type: 'error', message: 'Permainan di room ini sudah berjalan.' });
          return;
        }

        if (room.players.length >= 6) {
          sendJson(ws, { type: 'error', message: 'Room sudah penuh (maksimal 6 pemain).' });
          return;
        }

        const cleanName = (msg.name || 'Pemain').trim().slice(0, 18) || 'Pemain';
        const playerId = generateId('p');
        const newPlayer: ServerPlayer = {
          id: playerId,
          name: cleanName,
          avatar: msg.avatar || 'diamond',
          isBot: false,
          isHost: false,
          connected: true,
          hand: [],
          score: 0,
          calledUno: false,
          unoVulnerable: false,
          ws,
        };

        room.players.push(newPlayer);
        if (room.cleanupTimer) {
          clearTimeout(room.cleanupTimer);
          room.cleanupTimer = null;
        }
        socketSession.set(ws, { roomCode: code, playerId });
        addLog(room, `${cleanName} bergabung ke meja.`, 'neutral');
        sendJson(ws, { type: 'room_joined', code, playerId });
        broadcastRoom(room);
        return;
      }

      if (msg.type === 'reconnect_room') {
        const code = (msg.code || '').toUpperCase().trim();
        const room = rooms.get(code);
        if (!room) {
          sendJson(ws, { type: 'left_room' });
          return;
        }
        const existing = room.players.find((p) => p.id === msg.playerId);
        if (!existing) {
          sendJson(ws, { type: 'left_room' });
          return;
        }
        existing.ws = ws;
        existing.connected = true;
        if (room.cleanupTimer) {
          clearTimeout(room.cleanupTimer);
          room.cleanupTimer = null;
        }
        socketSession.set(ws, { roomCode: code, playerId: existing.id });
        sendJson(ws, { type: 'room_joined', code, playerId: existing.id });
        broadcastRoom(room);
        return;
      }

      // All remaining actions require an active room session
      const sess = socketSession.get(ws);
      if (!sess) {
        sendJson(ws, { type: 'error', message: 'Kamu belum bergabung ke room.' });
        return;
      }
      const room = rooms.get(sess.roomCode);
      if (!room) {
        sendJson(ws, { type: 'left_room' });
        return;
      }
      const actor = room.players.find((p) => p.id === sess.playerId);
      if (!actor) return;

      switch (msg.type) {
        case 'leave_room': {
          socketSession.delete(ws);
          if (room.phase === 'LOBBY') {
            room.players = room.players.filter((p) => p.id !== actor.id);
            if (actor.isHost && room.players.length > 0) {
              const nextHuman = room.players.find((p) => !p.isBot) ?? room.players[0];
              nextHuman.isHost = true;
            }
            addLog(room, `${actor.name} keluar dari room.`, 'neutral');
          } else {
            actor.connected = false;
            actor.ws = null;
            // Convert leaving human mid-game to Bot so friends can finish the match!
            actor.isBot = true;
            actor.name = `${actor.name} (Bot)`;
            addLog(room, `${actor.name} digantikan Bot AI.`, 'neutral');
            if (room.players[room.currentTurnIndex]?.id === actor.id) {
              scheduleTurnHooks(room);
            }
          }
          sendJson(ws, { type: 'left_room' });
          scheduleRoomCleanupIfEmpty(room);
          broadcastRoom(room);
          break;
        }
        case 'add_bot': {
          if (!actor.isHost || room.phase !== 'LOBBY') return;
          if (room.players.length >= 6) {
            sendJson(ws, { type: 'error', message: 'Meja sudah penuh (6 pemain).' });
            return;
          }
          const botIdx = room.players.filter((p) => p.isBot).length;
          const botName = BOT_NAMES[botIdx % BOT_NAMES.length];
          room.players.push({
            id: generateId('bot'),
            name: botName,
            avatar: BOT_AVATARS[botIdx % BOT_AVATARS.length],
            isBot: true,
            isHost: false,
            connected: true,
            hand: [],
            score: 0,
            calledUno: false,
            unoVulnerable: false,
            ws: null,
          });
          addLog(room, `${botName} ditambahkan ke meja.`, 'neutral');
          broadcastRoom(room);
          break;
        }
        case 'remove_player': {
          if (!actor.isHost || room.phase !== 'LOBBY') return;
          if (msg.targetId === actor.id) return;
          const target = room.players.find((p) => p.id === msg.targetId);
          if (!target) return;
          room.players = room.players.filter((p) => p.id !== msg.targetId);
          if (target.ws) {
            socketSession.delete(target.ws);
            sendJson(target.ws, { type: 'left_room' });
          }
          addLog(room, `${target.name} dikeluarkan dari lobby.`, 'neutral');
          broadcastRoom(room);
          break;
        }
        case 'update_settings': {
          if (!actor.isHost || room.phase !== 'LOBBY') return;
          if (msg.settings.targetScore !== undefined) {
            room.settings.targetScore = msg.settings.targetScore === 0 ? 0 : 500;
          }
          if (msg.settings.turnSeconds !== undefined) {
            room.settings.turnSeconds = msg.settings.turnSeconds === 0 ? 0 : 25;
          }
          broadcastRoom(room);
          break;
        }
        case 'start_game': {
          if (!actor.isHost || room.phase !== 'LOBBY') return;
          if (room.players.length < 2) {
            sendJson(ws, {
              type: 'error',
              message: 'Butuh minimal 2 pemain (atau tambah Bot AI) untuk mulai.',
            });
            return;
          }
          startNewRound(room, true);
          break;
        }
        case 'play_card': {
          const err = performPlayCard(room, actor.id, msg.cardId, msg.chosenColor);
          if (err) sendJson(ws, { type: 'error', message: err });
          break;
        }
        case 'choose_flip_color': {
          applyFlipWildColor(room, actor.id, msg.chosenColor);
          break;
        }
        case 'draw_card': {
          const err = performDrawCard(room, actor.id);
          if (err) sendJson(ws, { type: 'error', message: err });
          break;
        }
        case 'play_drawn_card': {
          if (!room.pendingDrawnCardId) {
            sendJson(ws, { type: 'error', message: 'Tidak ada kartu yang baru diambil.' });
            return;
          }
          const err = performPlayCard(
            room,
            actor.id,
            room.pendingDrawnCardId,
            msg.chosenColor
          );
          if (err) sendJson(ws, { type: 'error', message: err });
          break;
        }
        case 'pass_after_draw': {
          const err = performPassAfterDraw(room, actor.id);
          if (err) sendJson(ws, { type: 'error', message: err });
          break;
        }
        case 'call_uno': {
          if (room.phase !== 'PLAYING') return;
          if (actor.hand.length <= 2) {
            actor.calledUno = true;
            actor.unoVulnerable = false;
            addLog(room, `${actor.name} berteriak UNO!!`, 'uno');
            setCue(room, 'uno');
            broadcastRoom(room);
          }
          break;
        }
        case 'catch_uno': {
          if (room.phase !== 'PLAYING') return;
          const target = room.players.find((p) => p.id === msg.targetId);
          if (!target || !target.unoVulnerable || target.hand.length !== 1) return;
          target.unoVulnerable = false;
          target.calledUno = false;
          const penalty = drawFromPile(room, 2);
          target.hand.push(...penalty);
          addLog(
            room,
            `TERTANGKAP! ${actor.name} menangkap ${target.name} yang lupa bilang UNO (+2 kartu)!`,
            'penalty'
          );
          setCue(room, 'penalty');
          broadcastRoom(room);
          break;
        }
        case 'send_emote': {
          const cleanText = (msg.text || '').trim().slice(0, 60);
          if (!cleanText) return;
          room.emotes.push({
            id: generateId('em'),
            playerId: actor.id,
            playerName: actor.name,
            text: cleanText,
            timestamp: Date.now(),
          });
          broadcastRoom(room);
          break;
        }
        case 'next_round': {
          if (!actor.isHost || room.phase !== 'ROUND_OVER') return;
          startNewRound(room, false);
          break;
        }
        case 'play_again': {
          if (!actor.isHost || (room.phase !== 'GAME_OVER' && room.phase !== 'ROUND_OVER')) return;
          startNewRound(room, true);
          break;
        }
      }
    });

    ws.on('close', () => {
      const sess = socketSession.get(ws);
      if (!sess) return;
      const room = rooms.get(sess.roomCode);
      if (!room) return;
      const player = room.players.find((p) => p.id === sess.playerId);
      if (player) {
        player.connected = false;
        player.ws = null;
        broadcastRoom(room);
      }
      scheduleRoomCleanupIfEmpty(room);
    });
  });

  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(__dirname, 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  const port = Number(process.env.PORT || 3000);
  server.listen(port, '0.0.0.0', () => {
    console.log(`FlipTable server running on http://0.0.0.0:${port}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start FlipTable server:', err);
  process.exit(1);
});
