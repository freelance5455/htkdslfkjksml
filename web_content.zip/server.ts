import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";

const app = express();
const PORT = 3000;

app.use(express.json({ limit: "1mb" }));

// Lazy initialization of GoogleGenAI
let aiClient: GoogleGenAI | null = null;
function getGenAI(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return null;
  }
  if (!aiClient) {
    try {
      aiClient = new GoogleGenAI({
        apiKey,
        httpOptions: {
          headers: {
            "User-Agent": "aistudio-build",
          },
        },
      });
    } catch (e) {
      console.warn("Failed to initialize GoogleGenAI client:", e);
      return null;
    }
  }
  return aiClient;
}

// Default exact rates specification
const DEFAULT_RATES: Record<string, number | null> = {
  "gypsum_ceiling": 65,
  "pvc_ceiling": 60,
  "grid_ceiling": 50,
  "wallpaper": 40,
  "fluted_panel": 90,
  "louver_panel": 90,
  "pop_ceiling": 120,
  "pvc_wall_panel": 50,
  "uv_marble_sheet": 120,
  "aluminium_window": null,
};

// Health Check API
app.get("/api/health", (_req, res) => {
  res.json({
    status: "ok",
    app: "Ceiling Calculation",
    timestamp: new Date().toISOString(),
    aiConfigured: Boolean(process.env.GEMINI_API_KEY),
  });
});

// Rates endpoint for initial sync
app.get("/api/rates", (_req, res) => {
  res.json({
    rates: DEFAULT_RATES,
    currency: "INR",
    symbol: "₹",
  });
});

// AI Chat endpoint
app.post("/api/ai/chat", async (req, res) => {
  const { message, history, rates } = req.body;

  if (!message || typeof message !== "string") {
    res.status(400).json({ error: "Message is required" });
    return;
  }

  const activeRates = rates && typeof rates === "object" ? rates : DEFAULT_RATES;

  const rateGuide = `
==================================================
EXACT BOQ FORMULAS & WORK RATES CONFIGURED IN APP
==================================================

ZERO MISMATCH RULE:
Top displayed rate, Detailed BOQ, and Grand Total must NEVER contradict each other.
Material Total = sum of all material items.
Labour Total = Area (or Rolls) × Labour Rate.
Grand Total = Material Total + Labour Total (plus 5% buffer ONLY if user explicitly requests it).
Do NOT automatically add 5% buffer to grand total.

1. WALLPAPER WORK (for 100 sq ft):
   - Wallpaper Rolls: 3 Rolls @ ₹1,500/Roll = ₹4,500
   - Material Total = ₹4,500
   - Labour: 3 Rolls @ ₹400/Roll = ₹1,200
   - Grand Total = ₹4,500 + ₹1,200 = ₹5,700

2. GRID / GREET CEILING (for 100 sq ft):
   - 2×2 Tile: 25 pieces @ ₹72 = ₹1,800
   - L / L Profile: 5 pieces @ ₹50 = ₹250
   - Manti: 2 pieces @ ₹100 = ₹200
   - 4 ft pieces: 8 pieces @ ₹25 = ₹200
   - 2 ft pieces: 15 pieces @ ₹7.50 = ₹112.50
   - Gitti: 1 packet @ ₹30 = ₹30
   - 35.8 Box: 1 box @ ₹50 = ₹50
   - Material Total = ₹2,642.50
   - Labour: 100 sq ft @ ₹10/sq ft = ₹1,000
   - Grand Total = ₹3,642.50

3. FLUTED PANEL (for 100 sq ft):
   - Fluted Panel (1 ft × 10 ft): 10 pieces @ ₹900 = ₹9,000
   - U Bedding: 4 pieces @ ₹45 = ₹180
   - Keel Packet: 1 packet @ ₹100 = ₹100
   - Material Total = ₹9,280
   - Labour: 100 sq ft @ ₹15/sq ft = ₹1,500
   - Grand Total = ₹10,780

4. LOUVER / LOWER PANEL (for 100 sq ft):
   - Louver Panel (6 inch × 9.5 ft): 20 pieces @ ₹855 = ₹17,100
   - L Profile / Section: 2 pieces @ ₹45 = ₹90
   - Keel Packet: 1 packet @ ₹100 = ₹100
   - Material Total = ₹17,290
   - Labour: 100 sq ft @ ₹15/sq ft = ₹1,500
   - Grand Total = ₹18,790

5. PVC WALL PANEL (for 100 sq ft):
   - PVC Wall Panel: 13 panels @ ₹170 = ₹2,210
   - U-Bedding: 4 pieces @ ₹45 = ₹180
   - 17 Number Keel Packet: 1 packet @ ₹100 = ₹100
   - Material Total = ₹2,490
   - Labour: 100 sq ft @ ₹12/sq ft = ₹1,200
   - Grand Total = ₹3,690

6. PVC CEILING (for 100 sq ft):
   - Base White Material: 100 sq ft @ ₹60 = ₹6,000
   - Material Total = ₹6,000
   - Labour: 100 sq ft @ ₹18 = ₹1,800
   - Grand Total = ₹7,800

7. GYPSUM CEILING (for 100 sq ft):
   - Base White Material: 100 sq ft @ ₹65 = ₹6,500
   - Material Total = ₹6,500 (If asked for itemized breakdown, clarify that Gypsum material BOQ is not fully configured)
   - Labour: 100 sq ft @ ₹20 = ₹2,000
   - Grand Total = ₹8,500

8. POP CEILING:
   - Base White Material: ₹120/sq ft + Labour: ₹25/sq ft

9. UV MARBLE SHEET (for 100 sq ft):
   - UV Marble Sheet (8 ft × 4 ft = 32 sq ft @ ₹120/sq ft): 1 sheet = ₹3,840
   - Lower Panel: 15 pieces (Size: 6 inch) - Rate not configured (do not invent price, show unset)
   - Lower L: 5 pieces @ ₹45 = ₹225
   - Bond Silicone: 2 pieces @ ₹300 = ₹600 (IMPORTANT: Must be named "Bond Silicone", NEVER "Dond". Included in Material Cost)
   - Material Total = ₹4,665
   - Labour: 100 sq ft @ ₹20/sq ft = ₹2,000
   - Grand Total = ₹6,665

10. ALUMINIUM WINDOW:
   - State clearly that the rate is not configured by default.

Scale proportionally for any other room area $A$ ($s = A / 100$).
Keep Material and Labour strictly separate.
Respond in simple Hindi / Hinglish or English as appropriate.
`;

  try {
    const ai = getGenAI();

    if (!ai) {
      // Graceful offline fallback answer without crashing
      const fallbackAnswer = generateSmartFallback(message, activeRates);
      res.json({
        reply: fallbackAnswer,
        source: "local-assistant",
      });
      return;
    }

    // Build chat contents
    const systemInstruction = `You are the expert AI Assistant inside the "Ceiling Calculation" mobile app.
Your job is to assist customers and contractors with ceiling and wall decoration decisions, material comparisons, and accurate cost calculations with separate Material BOQ and Labour totals.

${rateGuide}

Keep answers crisp, structured with clear bullet points, showing Material BOQ, Material Total, Labour Total, and Grand Total.`;

    const contents: Array<{ role?: "user" | "model"; parts: Array<{ text: string }> }> = [];

    // Add recent history if provided
    if (Array.isArray(history)) {
      for (const item of history.slice(-6)) {
        if (item && item.text && (item.role === "user" || item.role === "assistant" || item.role === "model")) {
          contents.push({
            role: item.role === "assistant" ? "model" : "user",
            parts: [{ text: String(item.text) }],
          });
        }
      }
    }

    // Add current user prompt
    contents.push({
      role: "user",
      parts: [{ text: message }],
    });

    // Call Gemini 3.7 Flash
    const response = await ai.models.generateContent({
      model: "gemini-3.7-flash",
      contents: contents as any,
      config: {
        systemInstruction,
        temperature: 0.7,
      },
    });

    const replyText = response.text || generateSmartFallback(message, activeRates);

    res.json({
      reply: replyText,
      source: "gemini-3.7-flash",
    });
  } catch (error: any) {
    console.error("AI Generation error:", error?.message || error);
    // Fallback safely to rule-based assistant so user never gets blocked
    const fallbackAnswer = generateSmartFallback(message, activeRates);
    res.json({
      reply: fallbackAnswer,
      source: "fallback",
      warning: "AI server temporarily busy, providing instant calculated answer.",
    });
  }
});

// Helper for instant local intelligent answers with exact BOQ math
function generateSmartFallback(prompt: string, rates: Record<string, number | null>): string {
  const lower = prompt.toLowerCase();

  // Check for dimension patterns like "10x10", "10*12", "10 by 12", "10 x 15", "100 sq ft"
  const dimMatch = lower.match(/(\d+(?:\.\d+)?)\s*(?:x|\*|by|×)\s*(\d+(?:\.\d+)?)/i);
  const sqftMatch = lower.match(/(\d+(?:\.\d+)?)\s*(?:sq\s*ft|sqft|square\s*feet|gaj)/i);

  let length = 10;
  let width = 10;
  let area = 100;

  if (dimMatch) {
    length = parseFloat(dimMatch[1]);
    width = parseFloat(dimMatch[2]);
    area = length * width;
  } else if (sqftMatch) {
    area = parseFloat(sqftMatch[1]);
    length = Math.round(Math.sqrt(area));
    width = Math.round(area / length);
  }

  const s = area / 100;

  // 1. Wallpaper
  if (lower.includes("wallpaper")) {
    const rolls = Number(((area / 100) * 3).toFixed(2));
    const matTotal = rolls * 1500;
    const labTotal = rolls * 400;
    const grand = matTotal + labTotal;

    return `📦 **WALLPAPER ESTIMATE & BOQ (${area} sq ft / ${length}×${width} ft):**\n\n` +
      `**A) Material BOQ:**\n` +
      `• Wallpaper Rolls: ${rolls} Rolls @ ₹1,500/Roll = **₹${matTotal.toLocaleString("en-IN")}**\n` +
      `**C) Material Total:** ₹${matTotal.toLocaleString("en-IN")}\n\n` +
      `**B) Labour:**\n` +
      `• Labour Charge: ${rolls} Rolls @ ₹400/Roll = **₹${labTotal.toLocaleString("en-IN")}**\n` +
      `**D) Labour Total:** ₹${labTotal.toLocaleString("en-IN")}\n\n` +
      `✨ **E) GRAND TOTAL:** **₹${grand.toLocaleString("en-IN")}** (Material ₹${matTotal.toLocaleString("en-IN")} + Labour ₹${labTotal.toLocaleString("en-IN")})`;
  }

  // 2. Grid Ceiling
  if (lower.includes("grid") || lower.includes("greet") || lower.includes("2x2")) {
    const matTotal = Number((2642.50 * s).toFixed(2));
    const labTotal = Number((area * 10).toFixed(2));
    const grand = Number((matTotal + labTotal).toFixed(2));

    return `📦 **GRID CEILING (2x2) ESTIMATE & BOQ (${area} sq ft):**\n\n` +
      `**A) Material BOQ:**\n` +
      `1. 2×2 Tile: ${(25 * s).toFixed(1)} pcs @ ₹72 = ₹${(1800 * s).toLocaleString("en-IN")}\n` +
      `2. L Profile: ${(5 * s).toFixed(1)} pcs @ ₹50 = ₹${(250 * s).toLocaleString("en-IN")}\n` +
      `3. Manti: ${(2 * s).toFixed(1)} pcs @ ₹100 = ₹${(200 * s).toLocaleString("en-IN")}\n` +
      `4. 4 ft pieces: ${(8 * s).toFixed(1)} pcs @ ₹25 = ₹${(200 * s).toLocaleString("en-IN")}\n` +
      `5. 2 ft pieces: ${(15 * s).toFixed(1)} pcs @ ₹7.50 = ₹${(112.50 * s).toLocaleString("en-IN")}\n` +
      `6. Gitti: ${(1 * s).toFixed(1)} pkt @ ₹30 = ₹${(30 * s).toLocaleString("en-IN")}\n` +
      `7. 35.8 Box: ${(1 * s).toFixed(1)} box @ ₹50 = ₹${(50 * s).toLocaleString("en-IN")}\n` +
      `**C) Material Total:** ₹${matTotal.toLocaleString("en-IN")}\n\n` +
      `**B) Labour:**\n` +
      `• Labour @ ₹10/sq ft: ${area} sq ft × ₹10 = **₹${labTotal.toLocaleString("en-IN")}**\n` +
      `**D) Labour Total:** ₹${labTotal.toLocaleString("en-IN")}\n\n` +
      `✨ **E) GRAND TOTAL:** **₹${grand.toLocaleString("en-IN")}**`;
  }

  // 3. Fluted Panel
  if (lower.includes("fluted")) {
    const matTotal = Number((9280 * s).toFixed(2));
    const labTotal = Number((area * 15).toFixed(2));
    const grand = Number((matTotal + labTotal).toFixed(2));

    return `📦 **FLUTED PANEL ESTIMATE & BOQ (${area} sq ft):**\n\n` +
      `**A) Material BOQ:**\n` +
      `1. Fluted Panel (1×10 ft): ${(10 * s).toFixed(1)} pcs @ ₹900 = ₹${(9000 * s).toLocaleString("en-IN")}\n` +
      `2. U Bedding: ${(4 * s).toFixed(1)} pcs @ ₹45 = ₹${(180 * s).toLocaleString("en-IN")}\n` +
      `3. Keel Packet: ${(1 * s).toFixed(1)} pkt @ ₹100 = ₹${(100 * s).toLocaleString("en-IN")}\n` +
      `**C) Material Total:** ₹${matTotal.toLocaleString("en-IN")}\n\n` +
      `**B) Labour:**\n` +
      `• Labour @ ₹15/sq ft: ${area} sq ft × ₹15 = **₹${labTotal.toLocaleString("en-IN")}**\n` +
      `**D) Labour Total:** ₹${labTotal.toLocaleString("en-IN")}\n\n` +
      `✨ **E) GRAND TOTAL:** **₹${grand.toLocaleString("en-IN")}**`;
  }

  // 4. Louver Panel
  if (lower.includes("louver") || lower.includes("lower")) {
    const matTotal = Number((17290 * s).toFixed(2));
    const labTotal = Number((area * 15).toFixed(2));
    const grand = Number((matTotal + labTotal).toFixed(2));

    return `📦 **LOUVER PANEL ESTIMATE & BOQ (${area} sq ft):**\n\n` +
      `**A) Material BOQ:**\n` +
      `1. Louver Panel (6\"×9.5'): ${(20 * s).toFixed(1)} pcs @ ₹855 = ₹${(17100 * s).toLocaleString("en-IN")}\n` +
      `2. L Profile: ${(2 * s).toFixed(1)} pcs @ ₹45 = ₹${(90 * s).toLocaleString("en-IN")}\n` +
      `3. Keel Packet: ${(1 * s).toFixed(1)} pkt @ ₹100 = ₹${(100 * s).toLocaleString("en-IN")}\n` +
      `**C) Material Total:** ₹${matTotal.toLocaleString("en-IN")}\n\n` +
      `**B) Labour:**\n` +
      `• Labour @ ₹15/sq ft: ${area} sq ft × ₹15 = **₹${labTotal.toLocaleString("en-IN")}**\n` +
      `**D) Labour Total:** ₹${labTotal.toLocaleString("en-IN")}\n\n` +
      `✨ **E) GRAND TOTAL:** **₹${grand.toLocaleString("en-IN")}**`;
  }

  // 5. PVC Wall Panel
  if (lower.includes("wall panel") || (lower.includes("pvc") && lower.includes("wall"))) {
    const matTotal = Number((2490 * s).toFixed(2));
    const labTotal = Number((area * 12).toFixed(2));
    const grand = Number((matTotal + labTotal).toFixed(2));

    return `📦 **PVC WALL PANEL ESTIMATE & BOQ (${area} sq ft):**\n\n` +
      `**A) Material BOQ:**\n` +
      `1. PVC Wall Panel: ${(13 * s).toFixed(1)} panels @ ₹170 = ₹${(2210 * s).toLocaleString("en-IN")}\n` +
      `2. U-Bedding: ${(4 * s).toFixed(1)} pcs @ ₹45 = ₹${(180 * s).toLocaleString("en-IN")}\n` +
      `3. 17 Number Keel: ${(1 * s).toFixed(1)} pkt @ ₹100 = ₹${(100 * s).toLocaleString("en-IN")}\n` +
      `**C) Material Total:** ₹${matTotal.toLocaleString("en-IN")}\n\n` +
      `**B) Labour:**\n` +
      `• Labour @ ₹12/sq ft: ${area} sq ft × ₹12 = **₹${labTotal.toLocaleString("en-IN")}**\n` +
      `**D) Labour Total:** ₹${labTotal.toLocaleString("en-IN")}\n\n` +
      `✨ **E) GRAND TOTAL:** **₹${grand.toLocaleString("en-IN")}**`;
  }

  // 6. PVC Ceiling
  if (lower.includes("pvc")) {
    const rate = rates["pvc_ceiling"] ?? 60;
    const matTotal = area * rate;
    const labTotal = area * 18;
    const grand = matTotal + labTotal;

    return `📐 **PVC CEILING ESTIMATE (${area} sq ft / ${length}×${width} ft):**\n\n` +
      `**A) Material BOQ:**\n` +
      `• PVC Ceiling White Material: ${area} sq ft @ ₹${rate}/sq ft = **₹${matTotal.toLocaleString("en-IN")}**\n` +
      `**C) Material Total:** ₹${matTotal.toLocaleString("en-IN")}\n\n` +
      `**B) Labour:**\n` +
      `• Labour Charge: ${area} sq ft @ ₹18/sq ft = **₹${labTotal.toLocaleString("en-IN")}**\n` +
      `**D) Labour Total:** ₹${labTotal.toLocaleString("en-IN")}\n\n` +
      `✨ **E) GRAND TOTAL:** **₹${grand.toLocaleString("en-IN")}**`;
  }

  // 7. Gypsum Ceiling
  if (lower.includes("gypsum")) {
    const rate = rates["gypsum_ceiling"] ?? 65;
    const matTotal = area * rate;
    const labTotal = area * 20;
    const grand = matTotal + labTotal;

    return `📐 **GYPSUM CEILING ESTIMATE (${area} sq ft / ${length}×${width} ft):**\n\n` +
      `**A) Material BOQ:**\n` +
      `• Gypsum Board & Framework (Base): ${area} sq ft @ ₹${rate}/sq ft = **₹${matTotal.toLocaleString("en-IN")}**\n` +
      `*(Note: Gypsum material BOQ not fully configured, using base material estimate)*\n` +
      `**C) Material Total:** ₹${matTotal.toLocaleString("en-IN")}\n\n` +
      `**B) Labour:**\n` +
      `• Labour Charge: ${area} sq ft @ ₹20/sq ft = **₹${labTotal.toLocaleString("en-IN")}**\n` +
      `**D) Labour Total:** ₹${labTotal.toLocaleString("en-IN")}\n\n` +
      `✨ **E) GRAND TOTAL:** **₹${grand.toLocaleString("en-IN")}**`;
  }

  // 8. POP Ceiling
  if (lower.includes("pop")) {
    const rate = rates["pop_ceiling"] ?? 120;
    const matTotal = area * rate;
    const labTotal = area * 25;
    const grand = matTotal + labTotal;

    return `📐 **POP CEILING ESTIMATE (${area} sq ft / ${length}×${width} ft):**\n\n` +
      `**A) Material BOQ:**\n` +
      `• POP Raw Material & Net: ${area} sq ft @ ₹${rate}/sq ft = **₹${matTotal.toLocaleString("en-IN")}**\n` +
      `**C) Material Total:** ₹${matTotal.toLocaleString("en-IN")}\n\n` +
      `**B) Labour:**\n` +
      `• Labour Charge: ${area} sq ft @ ₹25/sq ft = **₹${labTotal.toLocaleString("en-IN")}**\n` +
      `**D) Labour Total:** ₹${labTotal.toLocaleString("en-IN")}\n\n` +
      `✨ **E) GRAND TOTAL:** **₹${grand.toLocaleString("en-IN")}**`;
  }

  // 9. UV Marble Sheet
  if (lower.includes("uv") || lower.includes("marble")) {
    const sheetCount = Number((1 * s).toFixed(1));
    const sheetMat = Number((sheetCount * 32 * 120).toFixed(2));
    const lowerLMat = Number((5 * s * 45).toFixed(2));
    const siliconeMat = Number((2 * s * 300).toFixed(2));
    const matTotal = sheetMat + lowerLMat + siliconeMat;
    const labTotal = Number((area * 20).toFixed(2));
    const grand = matTotal + labTotal;

    return `📦 **UV MARBLE SHEET ESTIMATE & BOQ (${area} sq ft):**\n\n` +
      `**A) Material BOQ:**\n` +
      `1. UV Marble Sheet (8×4 ft / 32 sq ft): ${sheetCount} sheet @ ₹120/sq ft = ₹${sheetMat.toLocaleString("en-IN")}\n` +
      `2. Lower Panel (6 inch): ${(15 * s).toFixed(1)} pcs (Rate not configured)\n` +
      `3. Lower L: ${(5 * s).toFixed(1)} pcs @ ₹45 = ₹${lowerLMat.toLocaleString("en-IN")}\n` +
      `4. Bond Silicone: ${(2 * s).toFixed(1)} pcs @ ₹300 = ₹${siliconeMat.toLocaleString("en-IN")} *(included in material)*\n` +
      `**C) Material Total:** ₹${matTotal.toLocaleString("en-IN")}\n\n` +
      `**B) Labour:**\n` +
      `• Labour @ ₹20/sq ft: ${area} sq ft × ₹20 = **₹${labTotal.toLocaleString("en-IN")}**\n` +
      `**D) Labour Total:** ₹${labTotal.toLocaleString("en-IN")}\n\n` +
      `✨ **E) GRAND TOTAL:** **₹${grand.toLocaleString("en-IN")}**`;
  }

  // Default welcome / overview
  return `Namaste! Main **Ceiling Calculation** AI Assistant hoon. 
Main aapko har work type ka alag **Material BOQ**, **Labour Cost**, aur **Grand Total** calculate karke de sakta hoon.

Aap mujhse pooch sakte hain:
• *100 sq ft Wallpaper ka BOQ aur total kharcha kitna hoga?*
• *Grid Ceiling 2x2 ke 100 sq ft mein kaun kaun se material lagte hain?*
• *Fluted panel aur Louver panel ka exact rate breakdown kya hai?*
• *12×14 ft room mein PVC ceiling ka material aur labour kitna hoga?*

Aap mic daba kar bol bhi sakte hain!`;
}

// Explicit PWA and static file helpers for manifest & Service Worker
app.get(["/manifest.json", "/manifest.webmanifest"], (_req, res) => {
  const publicManifest = path.join(process.cwd(), "public", "manifest.json");
  const distManifest = path.join(process.cwd(), "dist", "manifest.json");
  res.setHeader("Content-Type", "application/manifest+json; charset=utf-8");
  res.setHeader("Access-Control-Allow-Origin", "*");
  if (process.env.NODE_ENV === "production") {
    res.sendFile(distManifest, (err) => {
      if (err) res.sendFile(publicManifest);
    });
  } else {
    res.sendFile(publicManifest);
  }
});

app.get(["/sw.js", "/dev-sw.js"], (_req, res, next) => {
  if (process.env.NODE_ENV === "production") {
    const distSw = path.join(process.cwd(), "dist", "sw.js");
    const publicSw = path.join(process.cwd(), "public", "sw.js");
    res.setHeader("Content-Type", "application/javascript; charset=utf-8");
    res.setHeader("Service-Worker-Allowed", "/");
    res.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
    res.sendFile(distSw, (err) => {
      if (err) res.sendFile(publicSw);
    });
  } else {
    // In dev mode, let Vite middleware handle or fallback to public/sw.js
    const publicSw = path.join(process.cwd(), "public", "sw.js");
    res.setHeader("Content-Type", "application/javascript; charset=utf-8");
    res.setHeader("Service-Worker-Allowed", "/");
    res.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
    res.sendFile(publicSw, (err) => {
      if (err) next();
    });
  }
});

// Serve public directory static assets
app.use(express.static(path.join(process.cwd(), "public")));

// Start Server & mount Vite
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Ceiling Calculation app running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error("Failed to start server:", err);
});
