import dotenv from 'dotenv';
import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT) || 3000;

interface IncomingAttachment {
  name: string;
  mimeType: string;
  kind: 'image' | 'text';
  content: string; // text content for text files, base64 (without data: prefix) for images
}

interface IncomingMessage {
  role: 'user' | 'assistant';
  content: string;
  attachments?: IncomingAttachment[];
}

interface ChatRequestBody {
  provider: 'google' | 'groq' | 'openrouter' | 'zhipu' | 'openai' | 'anthropic';
  modelId: string;
  systemPrompt: string;
  messages: IncomingMessage[];
  customApiKey?: string;
}

const DEPRECATED_GEMINI_MODELS = new Set([
  'gemini-1.5-flash',
  'gemini-1.5-pro',
  'gemini-pro',
  'gemini-2.0-flash',
  'gemini-2.0-pro',
  'gemini-2.0-flash-thinking',
]);

function normalizeGeminiModel(modelId: string): string {
  const trimmed = modelId.trim();
  if (DEPRECATED_GEMINI_MODELS.has(trimmed)) {
    return 'gemini-4-hydrogen';
  }
  return trimmed || 'gemini-4-hydrogen';
}

function writeSseEvent(res: express.Response, payload: Record<string, unknown>): void {
  if (!res.writableEnded) {
    res.write(`data: ${JSON.stringify(payload)}\n\n`);
  }
}

async function streamGemini(
  reqBody: ChatRequestBody,
  res: express.Response,
  signal: AbortSignal
): Promise<void> {
  const apiKey = reqBody.customApiKey?.trim() || process.env.GEMINI_API_KEY?.trim();
  if (!apiKey) {
    throw new Error(
      'Google AI Studio API key is not configured. Add one in Settings > API Keys & Models or configure GEMINI_API_KEY in AI Studio Secrets.'
    );
  }

  const ai = new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });

  const model = normalizeGeminiModel(reqBody.modelId);

  const contents = reqBody.messages.map((msg) => {
    const parts: Array<{ text?: string; inlineData?: { mimeType: string; data: string } }> = [];

    if (msg.attachments && msg.attachments.length > 0) {
      for (const att of msg.attachments) {
        if (att.kind === 'image' && att.content) {
          parts.push({
            inlineData: {
              mimeType: att.mimeType || 'image/png',
              data: att.content,
            },
          });
        } else if (att.kind === 'text' && att.content) {
          parts.push({
            text: `Attached file \`${att.name}\`:\n\`\`\`\n${att.content}\n\`\`\``,
          });
        }
      }
    }

    if (msg.content.trim()) {
      parts.push({ text: msg.content });
    } else if (parts.length === 0) {
      parts.push({ text: '' });
    }

    return {
      role: msg.role === 'assistant' ? 'model' : 'user',
      parts,
    };
  });

  const responseStream = await ai.models.generateContentStream({
    model,
    contents,
    config: {
      systemInstruction: reqBody.systemPrompt,
      abortSignal: signal,
    },
  });

  for await (const chunk of responseStream) {
    if (signal.aborted) break;
    const text = chunk.text;
    if (text) {
      writeSseEvent(res, { type: 'delta', text });
    }
  }
}

async function streamOpenAICompatible(
  endpoint: string,
  apiKey: string,
  reqBody: ChatRequestBody,
  res: express.Response,
  signal: AbortSignal,
  extraHeaders: Record<string, string> = {}
): Promise<void> {
  const formattedMessages: Array<{
    role: 'system' | 'user' | 'assistant';
    content: string | Array<{ type: string; text?: string; image_url?: { url: string } }>;
  }> = [
    { role: 'system', content: reqBody.systemPrompt },
    ...reqBody.messages.map((msg) => {
      const hasImages = msg.attachments?.some((a) => a.kind === 'image');
      const textFilesBlock = (msg.attachments || [])
        .filter((a) => a.kind === 'text' && a.content)
        .map((a) => `Attached file \`${a.name}\`:\n\`\`\`\n${a.content}\n\`\`\``)
        .join('\n\n');

      const combinedText = [textFilesBlock, msg.content].filter(Boolean).join('\n\n');

      if (!hasImages || msg.role === 'assistant') {
        return {
          role: msg.role,
          content: combinedText,
        };
      }

      const contentParts: Array<{ type: string; text?: string; image_url?: { url: string } }> = [];
      if (combinedText) {
        contentParts.push({ type: 'text', text: combinedText });
      }
      for (const att of msg.attachments || []) {
        if (att.kind === 'image' && att.content) {
          contentParts.push({
            type: 'image_url',
            image_url: {
              url: `data:${att.mimeType || 'image/png'};base64,${att.content}`,
            },
          });
        }
      }

      return {
        role: msg.role,
        content: contentParts,
      };
    }),
  ];

  const upstream = await fetch(endpoint, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${apiKey}`,
      ...extraHeaders,
    },
    body: JSON.stringify({
      model: reqBody.modelId,
      messages: formattedMessages,
      stream: true,
    }),
    signal,
  });

  if (!upstream.ok) {
    const errText = await upstream.text().catch(() => upstream.statusText);
    let message = `Provider error (${upstream.status}): ${errText}`;
    try {
      const parsed = JSON.parse(errText);
      if (parsed?.error?.message) {
        message = parsed.error.message;
      }
    } catch {
      // keep raw message
    }
    throw new Error(message);
  }

  if (!upstream.body) {
    throw new Error('Provider returned an empty response stream.');
  }

  const reader = upstream.body.getReader();
  const decoder = new TextDecoder();
  let buffer = '';

  while (true) {
    const { done, value } = await reader.read();
    if (done || signal.aborted) break;

    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split('\n');
    buffer = lines.pop() ?? '';

    for (const rawLine of lines) {
      const line = rawLine.trim();
      if (!line || !line.startsWith('data:')) continue;
      const dataStr = line.slice(5).trim();
      if (dataStr === '[DONE]') return;

      try {
        const parsed = JSON.parse(dataStr);
        const delta = parsed?.choices?.[0]?.delta;
        const reasoning = delta?.reasoning_content || delta?.reasoning;
        const content = delta?.content;
        if (reasoning && !content) {
          // Skip emitting raw reasoning unless needed, or keep code output crisp
        }
        if (typeof content === 'string' && content.length > 0) {
          writeSseEvent(res, { type: 'delta', text: content });
        }
      } catch {
        // Ignore partial JSON lines
      }
    }
  }
}

async function streamAnthropic(
  apiKey: string,
  reqBody: ChatRequestBody,
  res: express.Response,
  signal: AbortSignal
): Promise<void> {
  const formattedMessages = reqBody.messages.map((msg) => {
    const textFilesBlock = (msg.attachments || [])
      .filter((a) => a.kind === 'text' && a.content)
      .map((a) => `Attached file \`${a.name}\`:\n\`\`\`\n${a.content}\n\`\`\``)
      .join('\n\n');
    const combinedText = [textFilesBlock, msg.content].filter(Boolean).join('\n\n');

    const contentBlocks: Array<Record<string, unknown>> = [];
    for (const att of msg.attachments || []) {
      if (att.kind === 'image' && att.content) {
        contentBlocks.push({
          type: 'image',
          source: {
            type: 'base64',
            media_type: att.mimeType || 'image/png',
            data: att.content,
          },
        });
      }
    }
    contentBlocks.push({ type: 'text', text: combinedText || ' ' });

    return {
      role: msg.role,
      content: contentBlocks,
    };
  });

  const upstream = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': apiKey,
      'anthropic-version': '2023-06-01',
    },
    body: JSON.stringify({
      model: reqBody.modelId,
      max_tokens: 8192,
      system: reqBody.systemPrompt,
      messages: formattedMessages,
      stream: true,
    }),
    signal,
  });

  if (!upstream.ok) {
    const errText = await upstream.text().catch(() => upstream.statusText);
    let message = `Anthropic error (${upstream.status}): ${errText}`;
    try {
      const parsed = JSON.parse(errText);
      if (parsed?.error?.message) {
        message = parsed.error.message;
      }
    } catch {
      // keep raw
    }
    throw new Error(message);
  }

  if (!upstream.body) {
    throw new Error('Anthropic returned an empty response stream.');
  }

  const reader = upstream.body.getReader();
  const decoder = new TextDecoder();
  let buffer = '';

  while (true) {
    const { done, value } = await reader.read();
    if (done || signal.aborted) break;

    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split('\n');
    buffer = lines.pop() ?? '';

    for (const rawLine of lines) {
      const line = rawLine.trim();
      if (!line.startsWith('data:')) continue;
      const dataStr = line.slice(5).trim();
      if (!dataStr) continue;

      try {
        const parsed = JSON.parse(dataStr);
        if (parsed.type === 'content_block_delta' && parsed.delta?.type === 'text_delta') {
          const text = parsed.delta.text;
          if (typeof text === 'string' && text.length > 0) {
            writeSseEvent(res, { type: 'delta', text });
          }
        } else if (parsed.type === 'message_stop') {
          return;
        }
      } catch {
        // Ignore partial JSON
      }
    }
  }
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '25mb' }));

  app.get('/api/health', (_req, res) => {
    res.json({
      ok: true,
      hasServerGeminiKey: Boolean(process.env.GEMINI_API_KEY?.trim()),
    });
  });

  app.post('/api/chat', async (req, res) => {
    const body = req.body as ChatRequestBody;
    if (!body || !body.provider || !body.modelId || !Array.isArray(body.messages)) {
      res.status(400).json({ error: 'Invalid chat request payload.' });
      return;
    }

    res.setHeader('Content-Type', 'text/event-stream; charset=utf-8');
    res.setHeader('Cache-Control', 'no-cache, no-transform');
    res.setHeader('Connection', 'keep-alive');
    res.flushHeaders?.();

    const abortController = new AbortController();
    req.on('close', () => {
      if (!res.writableEnded) {
        abortController.abort();
      }
    });

    try {
      const customKey = body.customApiKey?.trim() || '';

      if (body.provider === 'google') {
        await streamGemini(body, res, abortController.signal);
      } else if (body.provider === 'groq') {
        if (!customKey) {
          throw new Error('Missing Groq API key. Add your Groq key in Three-Dots Menu > API Keys & Models.');
        }
        await streamOpenAICompatible(
          'https://api.groq.com/openai/v1/chat/completions',
          customKey,
          body,
          res,
          abortController.signal
        );
      } else if (body.provider === 'openrouter') {
        if (!customKey) {
          throw new Error('Missing OpenRouter API key. Add your OpenRouter key in Three-Dots Menu > API Keys & Models.');
        }
        await streamOpenAICompatible(
          'https://openrouter.ai/api/v1/chat/completions',
          customKey,
          body,
          res,
          abortController.signal,
          {
            'HTTP-Referer': process.env.APP_URL || 'http://localhost:3000',
            'X-Title': 'MyCode',
          }
        );
      } else if (body.provider === 'zhipu') {
        if (!customKey) {
          throw new Error('Missing Zhipu Z.ai API key. Add your Zhipu key in Three-Dots Menu > API Keys & Models.');
        }
        await streamOpenAICompatible(
          'https://open.bigmodel.cn/api/paas/v4/chat/completions',
          customKey,
          body,
          res,
          abortController.signal
        );
      } else if (body.provider === 'openai') {
        if (!customKey) {
          throw new Error('Missing OpenAI API key. Add your OpenAI key in Three-Dots Menu > API Keys & Models.');
        }
        await streamOpenAICompatible(
          'https://api.openai.com/v1/chat/completions',
          customKey,
          body,
          res,
          abortController.signal
        );
      } else if (body.provider === 'anthropic') {
        if (!customKey) {
          throw new Error('Missing Anthropic API key. Add your Anthropic key in Three-Dots Menu > API Keys & Models.');
        }
        await streamAnthropic(customKey, body, res, abortController.signal);
      } else {
        throw new Error(`Unsupported provider: ${body.provider}`);
      }

      writeSseEvent(res, { type: 'done' });
    } catch (err) {
      if (!abortController.signal.aborted) {
        const message = err instanceof Error ? err.message : 'Unexpected provider error.';
        writeSseEvent(res, { type: 'error', error: message });
      }
    } finally {
      if (!res.writableEnded) {
        res.end();
      }
    }
  });

  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(__dirname, 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`MyCode server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
