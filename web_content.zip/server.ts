import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI, Type } from '@google/genai';
import dotenv from 'dotenv';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = parseInt(process.env.PORT || '3000', 10);

app.use(express.json({ limit: '50mb' }));

// Server-side Gemini initialization
const apiKey = process.env.GEMINI_API_KEY;
const ai = apiKey
  ? new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    })
  : null;

// Health / Status check
app.get('/api/status', (req, res) => {
  res.json({
    status: 'ok',
    hasApiKey: !!apiKey,
    service: 'Hindi Video Translator Backend',
    supportedFeatures: [
      'local_video_playback',
      'hindi_subtitles',
      'tts_hindi_dubbing',
      'gemini_speech_translation',
      'manual_subtitle_editor',
      'android_studio_export',
    ],
  });
});

// Translation & Subtitle Generation endpoint
app.post('/api/translate-content', async (req, res) => {
  try {
    const { englishText, videoDuration, existingSubtitles } = req.body;

    if (!ai) {
      return res.status(503).json({
        error: 'Gemini API is not configured on the server. Please use the Local / Manual Subtitle Entry mode or configure GEMINI_API_KEY.',
      });
    }

    const prompt = `You are an expert audio-visual subtitle translator and Hindi localization engineer.
Translate the following video transcript or segments into natural, idiomatic Hindi (Devanagari script) subtitles with precise start and end timestamps in seconds.
Video total duration is approximately ${videoDuration || 30} seconds.

Input content to translate:
"""
${englishText || JSON.stringify(existingSubtitles || 'Sample greeting and explanation')}
"""

Requirements:
1. Provide accurate subtitle chunks of 3 to 6 seconds each.
2. Start times must begin at 0.0s and increase chronologically without overlaps.
3. Hindi translation must be natural spoken Hindi (Devanagari script), culturally fluent and accurate for video dubbing.
4. Also provide phonetic romanized Hindi (Hinglish) to help pronunciation.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              id: { type: Type.INTEGER },
              startTime: { type: Type.NUMBER, description: 'Start time in seconds' },
              endTime: { type: Type.NUMBER, description: 'End time in seconds' },
              hindiText: { type: Type.STRING, description: 'Translated Hindi text in Devanagari script' },
              originalText: { type: Type.STRING, description: 'Original English or source text' },
              romanizedHindi: { type: Type.STRING, description: 'Phonetic Hinglish pronunciation' },
            },
            required: ['id', 'startTime', 'endTime', 'hindiText', 'originalText'],
          },
        },
      },
    });

    const parsed = JSON.parse(response.text || '[]');
    return res.json({ success: true, subtitles: parsed });
  } catch (error: any) {
    console.error('Translation error:', error);
    return res.status(500).json({
      error: error.message || 'Failed to process translation request with Gemini.',
    });
  }
});

// Cloud TTS generation endpoint (optional high-fidelity voice)
app.post('/api/generate-hindi-tts', async (req, res) => {
  try {
    const { text, voiceName } = req.body;
    if (!ai) {
      return res.status(503).json({
        error: 'Gemini API not available. The application will use Android / Web TextToSpeech engine locally.',
      });
    }

    if (!text || text.trim().length === 0) {
      return res.status(400).json({ error: 'Text is required for TTS generation.' });
    }

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash-lite-tts',
      contents: [
        {
          role: 'user',
          parts: [
            {
              text: `Speak the following Hindi text in a clear, natural, expressive tone: ${text}`,
              speechMetadata: {
                style: 'Clear, natural, professional Hindi speaker',
              },
            },
          ],
        },
      ],
      config: {
        responseModalities: ['AUDIO'],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: voiceName || 'Kore' },
          },
        },
      },
    });

    const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    if (!base64Audio) {
      throw new Error('No audio returned by TTS model');
    }

    res.json({
      success: true,
      audioBase64: base64Audio,
      mimeType: 'audio/wav',
    });
  } catch (error: any) {
    console.error('TTS error:', error);
    res.status(500).json({
      error: error.message || 'Failed to generate Hindi TTS audio via cloud.',
    });
  }
});

async function startServer() {
  // Vite integration
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.join(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Hindi Video Translator server running at http://0.0.0.0:${PORT}`);
  });
}

startServer();
