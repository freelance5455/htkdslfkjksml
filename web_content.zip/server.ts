import express from 'express';
import http from 'http';
import path from 'path';
import { fileURLToPath } from 'url';
import { WebSocketServer, WebSocket } from 'ws';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import { db } from './server/db.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = parseInt(process.env.PORT || '3000', 10);
const isProd = process.env.NODE_ENV === 'production';

async function bootstrap() {
  const app = express();
  const server = http.createServer(app);

  app.use(express.json({ limit: '50mb' }));
  app.use(express.urlencoded({ extended: true, limit: '50mb' }));

  // WebSocket Server Setup with Multi-Tab Support & Call Signalling
  const wss = new WebSocketServer({ server });
  const activeSockets = new Map<string, Set<WebSocket>>(); // userId -> Set of ws

  function broadcastToUser(userId: string, data: unknown) {
    const sockets = activeSockets.get(userId);
    if (sockets && sockets.size > 0) {
      const payload = JSON.stringify(data);
      sockets.forEach(ws => {
        if (ws.readyState === WebSocket.OPEN) {
          try {
            ws.send(payload);
          } catch (err) {
            console.error('Error sending WS message to user:', userId, err);
          }
        }
      });
    }
  }

  function broadcastToAll(data: unknown) {
    const payload = JSON.stringify(data);
    wss.clients.forEach(client => {
      if (client.readyState === WebSocket.OPEN) {
        try {
          client.send(payload);
        } catch (err) {
          console.error('Error broadcasting WS message:', err);
        }
      }
    });
  }

  wss.on('connection', (ws: WebSocket) => {
    let currentUserId: string | null = null;

    ws.on('message', (raw) => {
      try {
        const payload = JSON.parse(raw.toString());
        const { type, ...data } = payload;

        switch (type) {
          case 'auth:identify': {
            if (data.userId) {
              currentUserId = data.userId;
              if (!activeSockets.has(data.userId)) {
                activeSockets.set(data.userId, new Set());
              }
              activeSockets.get(data.userId)!.add(ws);
              db.setUserOnlineStatus(data.userId, true);
              broadcastToAll({
                type: 'user:presence',
                userId: data.userId,
                online: true,
              });
            }
            break;
          }
          case 'chat:typing': {
            if (data.chatId && data.userId && data.participants) {
              data.participants.forEach((pid: string) => {
                if (pid !== data.userId) {
                  broadcastToUser(pid, {
                    type: 'chat:typing',
                    chatId: data.chatId,
                    userId: data.userId,
                    username: data.username,
                    isTyping: data.isTyping,
                  });
                }
              });
            }
            break;
          }
          // CALLING & WEBRTC SIGNALING
          case 'call:invite': {
            // data: { callId, callerId, callerName, callerAvatar, targetUserId, isVideo, chatId }
            if (data.targetUserId) {
              const targetOnline = activeSockets.has(data.targetUserId) && activeSockets.get(data.targetUserId)!.size > 0;
              broadcastToUser(data.targetUserId, {
                type: 'call:incoming',
                callId: data.callId,
                callerId: data.callerId,
                callerName: data.callerName,
                callerAvatar: data.callerAvatar,
                isVideo: Boolean(data.isVideo),
                chatId: data.chatId,
                timestamp: Date.now(),
              });
              // Inform caller whether user was reached
              broadcastToUser(data.callerId, {
                type: 'call:ringing',
                callId: data.callId,
                targetUserId: data.targetUserId,
                isTargetOnline: targetOnline,
              });
            }
            break;
          }
          case 'call:accept': {
            // data: { callId, callerId, acceptorId }
            if (data.callerId) {
              broadcastToUser(data.callerId, {
                type: 'call:accepted',
                callId: data.callId,
                acceptorId: data.acceptorId,
              });
            }
            break;
          }
          case 'call:reject': {
            // data: { callId, callerId, targetUserId, reason }
            if (data.callerId) {
              broadcastToUser(data.callerId, {
                type: 'call:rejected',
                callId: data.callId,
                reason: data.reason || 'Decline',
              });
            }
            break;
          }
          case 'call:end': {
            // data: { callId, targetUserId, senderId }
            if (data.targetUserId) {
              broadcastToUser(data.targetUserId, {
                type: 'call:ended',
                callId: data.callId,
                senderId: data.senderId,
              });
            }
            break;
          }
          case 'call:signal': {
            // WebRTC SDP and ICE Candidate relay: data: { targetUserId, senderId, signal, callId }
            if (data.targetUserId) {
              broadcastToUser(data.targetUserId, {
                type: 'call:signal',
                senderId: data.senderId,
                signal: data.signal,
                callId: data.callId,
              });
            }
            break;
          }
          default:
            break;
        }
      } catch (err) {
        console.error('WS Error:', err);
      }
    });

    ws.on('close', () => {
      if (currentUserId && activeSockets.has(currentUserId)) {
        const set = activeSockets.get(currentUserId)!;
        set.delete(ws);
        if (set.size === 0) {
          activeSockets.delete(currentUserId);
          db.setUserOnlineStatus(currentUserId, false);
          broadcastToAll({
            type: 'user:presence',
            userId: currentUserId,
            online: false,
          });
        }
      }
    });
  });

  // GEMINI AI AGENT CLIENT & LOGIC
  let geminiClient: GoogleGenAI | null = null;
  function getGeminiClient(): GoogleGenAI | null {
    if (!geminiClient && process.env.GEMINI_API_KEY) {
      geminiClient = new GoogleGenAI({
        apiKey: process.env.GEMINI_API_KEY,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          },
        },
      });
    }
    return geminiClient;
  }

  async function generateAIAgentResponse(promptText: string, customConfig?: any): Promise<string> {
    const config = customConfig || db.getAIAgentConfig();
    const client = getGeminiClient();

    if (client) {
      try {
        const fullInstruction = `${config.systemPrompt}

ADMIN TRAINED KNOWLEDGE BASE & TOURNAMENT RULES:
${config.knowledgeBase}

INSTRUCTIONS:
1. Provide accurate information based on the Admin's trained knowledge base.
2. If asked about a user's ban or unban appeal, explain that only Admin can unban via WhatsApp (03260715961) or the in-app appeal button.
3. If asked about reporting someone, explain that they can tap on the message or user profile and select "Report Gamer".
4. You can reply in the same language as the user (Urdu, Roman Urdu, or English). Keep answers helpful, esports-focused, and concise.`;

        const response = await client.models.generateContent({
          model: 'gemini-3.8-flash',
          contents: promptText,
          config: {
            systemInstruction: fullInstruction,
          },
        });

        if (response.text?.trim()) {
          return response.text.trim();
        }
      } catch (err) {
        console.error('Gemini API call error:', err);
      }
    }

    // Smart Fallback engine if Gemini API Key is not yet configured or offline
    const lower = promptText.toLowerCase();
    if (lower.includes('ban') || lower.includes('بین') || lower.includes('unban')) {
      return 'Unknown Gamer Rules ke mutabiq account ban ka faisla sirf Admin karta hai. Agar aapka account ban ho gaya hai ya kisi ko report karna chahte hain to Admin se official WhatsApp par rabta karein: 03260715961 ya chat menu mein Report button use karein.';
    }
    if (lower.includes('report') || lower.includes('شکایت') || lower.includes('cheater') || lower.includes('hack')) {
      return 'Kisi player ko report karne ke liye uske message par tap karein ya 3 dots menu se "Report Gamer" select karein. Hamari admin team audit review ke baad action legi.';
    }
    if (lower.includes('whatsapp') || lower.includes('contact') || lower.includes('number')) {
      return 'Official Unknown Gamer WhatsApp Helpdesk Number hai: 03260715961 (https://wa.me/923260715961). Aap kisi bhi waqt rabta kar sakte hain.';
    }
    if (lower.includes('blue tick') || lower.includes('verify') || lower.includes('badge')) {
      return 'Unknown Gamer Verified Blue Tick sirf authorized Admin assign karta hai. Verification ke liye Admin se WhatsApp par rabta karein.';
    }
    if (lower.includes('call') || lower.includes('video') || lower.includes('voice')) {
      return 'Aap kisi bhi gamer ke sath direct 1-to-1 chat mein top bar par Phone (Voice Call) ya Camera (Video Call) icon dabba kar real-time call kar sakte hain.';
    }
    if (lower.includes('apk') || lower.includes('ایپ کے') || lower.includes('share apk') || lower.includes('download')) {
      return 'Haan ji! Unknown Gamer app mein aap direct Android APK files (.apk) aur gaming mods chat mein share kar sakte hain! Chat input ke sath 📎 Attachment ya 📦 APK button par click karein aur file select karein. Samnay wala player usay foran 1-click se download aur install kar sakta hai.';
    }
    return `Salam Gamer! Main Unknown Gamer ka official AI Support Agent hoon. Admin ki taraf se mujhe train kiya گیا hai taake main aapke masayel, ban queries, tournament rules, aur reports mein madad kar sakoon. Admin WhatsApp helpline: 03260715961.`;
  }

  // REST API ROUTES

  // Auth: Login
  app.post('/api/auth/login', (req, res) => {
    const { username, password } = req.body;
    if (!username || !password) {
      return res.status(400).json({ error: 'Username and password are required' });
    }

    const result = db.authenticateUser(username, password);
    if (!result.success) {
      return res.status(401).json(result);
    }

    res.json(result);
  });

  // Auth: Change password
  app.post('/api/auth/change-password', (req, res) => {
    const { userId, currentPassword, newPassword } = req.body;
    if (!userId || !currentPassword || !newPassword) {
      return res.status(400).json({ error: 'Missing parameters' });
    }

    const result = db.changeUserPassword(userId, currentPassword, newPassword);
    if (!result.success) {
      return res.status(400).json(result);
    }

    res.json(result);
  });

  // Secret Admin Authentication
  app.post('/api/admin/verify-key', (req, res) => {
    const { adminKey } = req.body;
    if (!adminKey) {
      return res.status(400).json({ error: 'Admin Key is required' });
    }

    const isValid = db.verifyAdminKey(adminKey);
    if (!isValid) {
      return res.status(401).json({ error: 'Invalid Admin Key' });
    }

    const adminToken = 'admin_sess_' + Date.now() + Math.random().toString(36).substring(2, 8);
    db.addAuditLog('ADMIN_LOGIN_SUCCESS', undefined, undefined, 'Admin logged in via secret Admin Key.');
    res.json({ success: true, adminToken });
  });

  // Admin Change Secret Key
  app.post('/api/admin/change-key', (req, res) => {
    const { currentKey, newKey } = req.body;
    if (!db.verifyAdminKey(currentKey)) {
      return res.status(401).json({ error: 'Current Admin Key is incorrect' });
    }
    if (!newKey || newKey.length < 3) {
      return res.status(400).json({ error: 'New Admin Key must be at least 3 characters' });
    }
    db.updateAdminKey(newKey);
    res.json({ success: true });
  });

  // Admin: Get App Settings & Stats
  app.get('/api/admin/settings', (_req, res) => {
    res.json(db.getSettings());
  });

  app.post('/api/admin/settings', (req, res) => {
    const updated = db.updateSettings(req.body);
    res.json(updated);
  });

  app.get('/api/admin/stats', (_req, res) => {
    const users = db.getAllUsers();
    const reports = db.getReports();
    const chats = db.getChatsForUser('usr_shadow_01'); // all
    const bans = db.getBanRecords();
    const activeBans = users.filter(u => u.status === 'banned').length;
    const verifiedUsers = users.filter(u => u.verifiedBlueTick).length;

    res.json({
      totalUsers: users.length,
      activeUsers: users.filter(u => u.status === 'active').length,
      onlineUsers: users.filter(u => u.online).length,
      bannedUsers: activeBans,
      verifiedGamers: verifiedUsers,
      totalReports: reports.length,
      pendingReports: reports.filter(r => r.status === 'pending').length,
      totalBanRecords: bans.length,
    });
  });

  // Admin: User Management
  app.get('/api/admin/users', (_req, res) => {
    res.json(db.getAllUsers());
  });

  app.post('/api/admin/users', (req, res) => {
    const result = db.createUser(req.body);
    if (!result.success) {
      return res.status(400).json(result);
    }
    // Broadcast to all users so Directory updates immediately
    broadcastToAll({ type: 'directory:user_created', user: result.user });
    res.json(result);
  });

  app.put('/api/admin/users/:id', (req, res) => {
    const result = db.updateUser(req.params.id, req.body);
    if (!result.success) {
      return res.status(400).json(result);
    }
    broadcastToAll({ type: 'directory:user_updated', user: result.user });
    res.json(result);
  });

  app.post('/api/admin/users/:id/reset-password', (req, res) => {
    const { newPassword } = req.body;
    const result = db.resetUserPassword(req.params.id, newPassword);
    if (!result.success) {
      return res.status(400).json(result);
    }
    res.json(result);
  });

  app.post('/api/admin/users/:id/ban', (req, res) => {
    const { banType, durationDays, reason } = req.body;
    const result = db.banUser(req.params.id, {
      banType: banType || 'temporary',
      durationDays: durationDays ? parseInt(durationDays, 10) : undefined,
      reason: reason || 'Policy violation',
    });

    if (!result.success) {
      return res.status(400).json(result);
    }

    // Immediately kick and alert the user via WebSocket
    broadcastToUser(req.params.id, {
      type: 'user:banned',
      banRecord: result.banRecord,
    });
    broadcastToAll({
      type: 'directory:user_banned',
      userId: req.params.id,
    });

    res.json(result);
  });

  app.post('/api/admin/users/:id/unban', (req, res) => {
    const result = db.unbanUser(req.params.id);
    if (!result.success) {
      return res.status(400).json(result);
    }

    broadcastToUser(req.params.id, { type: 'user:unbanned' });
    broadcastToAll({ type: 'directory:user_unbanned', userId: req.params.id });
    res.json(result);
  });

  app.delete('/api/admin/users/:id', (req, res) => {
    const result = db.deleteUser(req.params.id);
    if (!result.success) {
      return res.status(400).json(result);
    }
    broadcastToAll({ type: 'directory:user_deleted', userId: req.params.id });
    res.json(result);
  });

  app.post('/api/admin/users/:id/blue-tick', (req, res) => {
    const { granted, note } = req.body;
    const result = db.setBlueTick(req.params.id, Boolean(granted), note);
    if (!result.success) {
      return res.status(400).json(result);
    }
    broadcastToAll({
      type: 'directory:blue_tick_updated',
      userId: req.params.id,
      verifiedBlueTick: Boolean(granted),
    });
    res.json(result);
  });

  // Admin: Reports & Moderation
  app.get('/api/admin/reports', (_req, res) => {
    res.json(db.getReports());
  });

  app.post('/api/admin/reports/:id/resolve', (req, res) => {
    const { status, note } = req.body;
    const success = db.resolveReport(req.params.id, status, note);
    res.json({ success });
  });

  // Admin: Audit Logs & Ban History
  app.get('/api/admin/audit-logs', (_req, res) => {
    res.json(db.getAuditLogs());
  });

  app.get('/api/admin/ban-records', (_req, res) => {
    res.json(db.getBanRecords());
  });

  // Users Directory & Profile
  app.get('/api/users', (_req, res) => {
    res.json(db.getAllUsers());
  });

  app.get('/api/users/:id', (req, res) => {
    const user = db.getUserById(req.params.id);
    if (!user) return res.status(404).json({ error: 'User not found' });
    res.json(user);
  });

  app.put('/api/users/:id/profile', (req, res) => {
    const result = db.updateUser(req.params.id, req.body);
    if (!result.success) {
      return res.status(400).json(result);
    }
    broadcastToAll({ type: 'directory:user_updated', user: result.user });
    res.json(result);
  });

  // Chat Endpoints
  app.get('/api/chats', (req, res) => {
    const userId = req.query.userId as string;
    if (!userId) {
      return res.status(400).json({ error: 'userId is required' });
    }
    res.json(db.getChatsForUser(userId));
  });

  app.post('/api/chats/direct', (req, res) => {
    const { userA, userB } = req.body;
    if (!userA || !userB) {
      return res.status(400).json({ error: 'Both user IDs required' });
    }
    const chat = db.createDirectChat(userA, userB);
    res.json(chat);
  });

  app.post('/api/chats/group', (req, res) => {
    const { creatorId, name, participantIds, avatar, description } = req.body;
    if (!creatorId || !name || !participantIds?.length) {
      return res.status(400).json({ error: 'creatorId, name, and participants are required' });
    }
    const chat = db.createGroupChat(creatorId, name, participantIds, avatar, description);
    chat.participants.forEach(pid => {
      broadcastToUser(pid, { type: 'chat:new_group', chat });
    });
    res.json(chat);
  });

  app.delete('/api/admin/groups/:id', (req, res) => {
    const success = db.deleteGroup(req.params.id);
    if (success) {
      broadcastToAll({ type: 'chat:group_deleted', chatId: req.params.id });
    }
    res.json({ success });
  });

  app.get('/api/chats/:id/messages', (req, res) => {
    const userId = req.query.userId as string;
    if (!userId) return res.status(400).json({ error: 'userId is required' });
    res.json(db.getMessages(req.params.id, userId));
  });

  app.post('/api/chats/:id/messages', (req, res) => {
    const { senderId, text, mediaUrl, mediaType, fileName, fileSize, replyTo } = req.body;
    if (!senderId || (!text && !mediaUrl)) {
      return res.status(400).json({ error: 'senderId and message content are required' });
    }

    try {
      const { message, chat } = db.addMessage({
        chatId: req.params.id,
        senderId,
        text: text || '',
        mediaUrl,
        mediaType,
        fileName,
        fileSize,
        replyTo,
      });

      // Real-time broadcast to all participants via WebSocket
      chat.participants.forEach(pid => {
        broadcastToUser(pid, {
          type: 'message:new',
          chatId: chat.id,
          message,
          chat,
        });
      });

      // AI AGENT AUTOMATED RESPONSE HOOK
      if (chat.participants.includes('usr_ug_ai_agent') && senderId !== 'usr_ug_ai_agent') {
        const aiConfig = db.getAIAgentConfig();
        if (aiConfig.isActive) {
          setTimeout(async () => {
            try {
              // Send typing indicator
              chat.participants.forEach(pid => {
                broadcastToUser(pid, {
                  type: 'chat:typing',
                  chatId: chat.id,
                  userId: 'usr_ug_ai_agent',
                  username: 'UGAgent',
                  isTyping: true,
                });
              });

              const replyText = await generateAIAgentResponse(text || 'Salam');

              // Stop typing
              chat.participants.forEach(pid => {
                broadcastToUser(pid, {
                  type: 'chat:typing',
                  chatId: chat.id,
                  userId: 'usr_ug_ai_agent',
                  username: 'UGAgent',
                  isTyping: false,
                });
              });

              const aiResult = db.addMessage({
                chatId: chat.id,
                senderId: 'usr_ug_ai_agent',
                text: replyText,
              });

              chat.participants.forEach(pid => {
                broadcastToUser(pid, {
                  type: 'message:new',
                  chatId: chat.id,
                  message: aiResult.message,
                  chat: aiResult.chat,
                });
              });
            } catch (aiErr) {
              console.error('AI automated reply error:', aiErr);
            }
          }, 1200);
        }
      }

      res.json({ success: true, message, chat });
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Failed to send message';
      res.status(400).json({ error: message });
    }
  });

  // Admin AI Agent Training Endpoints
  app.get('/api/admin/ai-agent', (_req, res) => {
    res.json(db.getAIAgentConfig());
  });

  app.post('/api/admin/ai-agent', (req, res) => {
    const updated = db.updateAIAgentConfig(req.body);
    broadcastToAll({
      type: 'directory:user_updated',
      user: db.getUserById('usr_ug_ai_agent'),
    });
    res.json({ success: true, config: updated });
  });

  app.post('/api/admin/ai-agent/test', async (req, res) => {
    const { prompt, customPrompt, customKnowledge } = req.body;
    try {
      const reply = await generateAIAgentResponse(prompt || 'Test prompt', {
        systemPrompt: customPrompt,
        knowledgeBase: customKnowledge,
      });
      res.json({ success: true, reply });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  });

  app.post('/api/chats/:id/read', (req, res) => {
    const { userId } = req.body;
    if (!userId) return res.status(400).json({ error: 'userId required' });

    const updatedIds = db.markChatRead(req.params.id, userId);
    const chat = db.getChatById(req.params.id);

    if (chat) {
      chat.participants.forEach(pid => {
        if (pid !== userId) {
          broadcastToUser(pid, {
            type: 'message:read_receipt',
            chatId: req.params.id,
            readByUserId: userId,
            messageIds: updatedIds,
          });
        }
      });
    }

    res.json({ success: true, updatedIds });
  });

  app.delete('/api/messages/:id', (req, res) => {
    const { userId, forEveryone } = req.body;
    if (!userId) return res.status(400).json({ error: 'userId required' });

    const result = db.deleteMessage(req.params.id, userId, Boolean(forEveryone));
    if (!result.success) {
      return res.status(400).json(result);
    }

    if (result.isForEveryone) {
      broadcastToAll({
        type: 'message:deleted_for_everyone',
        messageId: req.params.id,
      });
    }

    res.json(result);
  });

  // Report User / Message
  app.post('/api/reports', (req, res) => {
    const report = db.createReport(req.body);
    res.json({ success: true, report });
  });

  // Status Stories
  app.get('/api/status', (_req, res) => {
    res.json(db.getStatuses());
  });

  app.post('/api/status', (req, res) => {
    const { userId, caption, mediaUrl } = req.body;
    if (!userId || !caption) {
      return res.status(400).json({ error: 'userId and caption required' });
    }
    const story = db.createStatus(userId, caption, mediaUrl);
    broadcastToAll({ type: 'status:new', story });
    res.json({ success: true, story });
  });

  app.post('/api/status/:id/view', (req, res) => {
    const { userId } = req.body;
    if (userId) {
      db.viewStatus(req.params.id, userId);
    }
    res.json({ success: true });
  });

  // Safe file / image upload handler (creates compressed safe data URL or returns URL)
  app.post('/api/upload', (req, res) => {
    const { dataUrl, filename } = req.body;
    if (!dataUrl) {
      return res.status(400).json({ error: 'dataUrl required' });
    }
    // Return the safe dataUrl directly
    res.json({ success: true, url: dataUrl, filename });
  });

  // Vite or Static Assets handling
  if (!isProd) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  server.listen(PORT, '0.0.0.0', () => {
    console.log(`[Unknown Gamer Server] Running on http://0.0.0.0:${PORT}`);
  });
}

bootstrap().catch(err => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
