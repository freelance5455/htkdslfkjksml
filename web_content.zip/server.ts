import express, { Request, Response } from 'express';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { MASTER_WORDS } from './src/data/lexicon.ts';
import { WordData } from './src/types.ts';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;

app.use(express.json({ limit: '10mb' }));

// Safely initialize Google GenAI only if an API key is present in the environment
const apiKey = process.env.GEMINI_API_KEY?.trim();
const ai = apiKey
  ? new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    })
  : null;

// Helper to look up words in the local benchmark lexicon
function findWordInLexicon(term: string): WordData | undefined {
  if (!term) return undefined;
  const clean = term.trim().toLowerCase();
  return (
    MASTER_WORDS.find((w) => w.word.toLowerCase() === clean) ||
    MASTER_WORDS.find((w) => clean.includes(w.word.toLowerCase()) || w.word.toLowerCase().includes(clean))
  );
}

// Fallback response generator for Professor Cadre chat
function buildFallbackChatReply(userQuery: string, examTarget: string): { text: string; sources: Array<{ title: string; uri: string }> } {
  const queryLower = userQuery.toLowerCase();

  // Try finding words mentioned in the prompt
  const matchedWord = MASTER_WORDS.find((w) => {
    const wLower = w.word.toLowerCase();
    const regex = new RegExp(`\\b${wLower}\\b`, 'i');
    return regex.test(queryLower);
  });

  if (matchedWord) {
    const collocationsStr = matchedWord.collocations
      ?.slice(0, 3)
      .map((c) => `• **${c.expr}** — ${c.bn}`)
      .join('\n') || `• **${matchedWord.word}** usage in formal register`;

    const sentenceStr = matchedWord.sentences
      ?.slice(0, 2)
      .map((s) => `> *"${s.en}"*\n> (${s.bn})`)
      .join('\n\n') || `> *"${matchedWord.word} is crucial in competitive English."*`;

    const confusionsStr = matchedWord.confusions
      ?.slice(0, 2)
      .map((c) => `• **${c.word}**: ${c.diff}`)
      .join('\n') || '';

    const reply = `### 🎓 Professor Cadre's Lexicographical Dossier: **${matchedWord.word.toUpperCase()}**

**Part of Speech & Level:** ${matchedWord.pos.toUpperCase()} (${matchedWord.cefr || 'C1 Advanced'}) | *${matchedWord.ipa || ''}*
**বাংলা অর্থ:** ${matchedWord.bengali}

---

#### 1. 🔍 Conceptual Nuance & Register
${matchedWord.advDef || matchedWord.simpleDef}
${matchedWord.bengaliExp ? `\n> **বাংলা ব্যাখ্যা:** ${matchedWord.bengaliExp}` : ''}

#### 2. ⚡ High-Yield Collocations (${examTarget})
${collocationsStr}

#### 3. ✍️ Authentic Model Sentences for Written Exam
${sentenceStr}

${confusionsStr ? `#### 4. ⚠️ Distinctions & Confusing Lookalikes\n${confusionsStr}\n` : ''}
#### 5. 🧠 Mnemonic Hook (মনে রাখার কৌশল)
💡 *${matchedWord.mnemonicBengali || `${matchedWord.word} = ${matchedWord.bengali}`}*

**Cadre Advice:** Active recall is essential. Test yourself on this word in the **Flashcards** or **Active Recall Drill** tab!`;

    return { text: reply, sources: [] };
  }

  // General competitive exam vocabulary strategy guidance
  if (queryLower.includes('how') || queryLower.includes('strategy') || queryLower.includes('prepare') || queryLower.includes('bcs') || queryLower.includes('gre') || queryLower.includes('revision') || queryLower.includes('forget')) {
    return {
      text: `### 🎓 Professor Cadre's Strategic Masterclass: Mastering Competitive Vocabulary for ${examTarget}

Aspirants often commit the fatal error of rote memorization without contextual retention. Here is your evidence-based playbook:

1. **The Spaced Repetition Imperative (Ebbinghaus Curve):**
   A word recalled on Day 1 decays by 60% within 48 hours without reinforcement. Review on **Day 1, Day 3, Day 7, Day 14, and Day 30**. Use VocabMuse's **Daily Schedule** queue to automate this!

2. **Morphological Word-Family Matrix:**
   Never study a lone word. Always dissect its root, prefix, and suffix along with all 4 grammatical manifestations:
   - *Verb:* Abdicate → *Noun:* Abdication / Abdicator → *Adjective:* Abdicative

3. **Collocation Supremacy:**
   Examiners penalize awkward phrases in written essays. Don't write *"he left his duty"*; write *"he **abdicated his constitutional responsibility**"*.

4. **Confusing Lookalikes (The Preliminary Trap):**
   Be vigilant against deceptive phonetic lookalikes (e.g., *Callous* [unfeeling] vs. *Callow* [immature/inexperienced]; *Adverse* [harmful] vs. *Averse* [reluctant]).

5. **Active Production Drills:**
   Write 1 authentic sentence daily using current national or international editorial topics.

*Which specific word or topic would you like to dissect next?*`,
      sources: []
    };
  }

  // Default thoughtful prompt response
  return {
    text: `### 🎓 Professor Cadre's Linguistic Guidance

Thank you for your inquiry regarding competitive vocabulary preparation for **${examTarget}**.

To achieve a top percentile in preliminary and written papers:
- **Depth over Raw Count:** Knowing 500 words with complete collocations, prepositions, and morphological variants outscores knowing 3,000 words superficially.
- **Root Analysis:** Greek and Latin roots (e.g., *mal-*, *bene-*, *chron-*, *vor-*) unlock hundreds of related exam words instantly.
- **Contextual Recall:** Practice the 17-section dossier inside VocabMuse to view full bilingual definitions, exam MCQs, and memory hooks.

Type any word (e.g. *Callous, Abdicate, Ephemeral, Meticulous, Abhor*) or ask for confusing lookalikes!`,
    sources: []
  };
}

// Fallback structured analysis for /api/explain-word
function buildFallbackExplainWord(word: string, targetExam: string): { word: string; analysis: string } {
  const matched = findWordInLexicon(word);
  if (matched) {
    const analysis = `### Lexicographical Analysis for "${matched.word}" (${targetExam})

1. **Core Definition & Nuance:**
   ${matched.simpleDef} (${matched.bengali}).
   ${matched.advDef}

2. **High-Yield Collocations:**
   ${matched.collocations?.slice(0, 3).map((c) => `• ${c.expr} (${c.bn})`).join('\n') || `• ${matched.word} in formal context`}

3. **Grammatical Complementation:**
   ${matched.grammar || `Primary part of speech: ${matched.pos}. Observe correct preposition complementation.`}

4. **Editorial Context Sentences:**
   ${matched.sentences?.slice(0, 2).map((s) => `• "${s.en}" — ${s.bn}`).join('\n') || `• Formal usage in contemporary literature.`}

5. **Bengali Meaning & Mnemonic:**
   বাংলা অর্থ: ${matched.bengali}
   স্মৃতি সহায়ক কৌশল: ${matched.mnemonicBengali || 'শব্দের মূল ভাবনার সাথে সংযোগ স্থাপন করুন।'}`;

    return { word: matched.word, analysis };
  }

  return {
    word,
    analysis: `### Lexicographical Analysis for "${word}" (${targetExam})

1. **Core Definition:**
   High-frequency competitive vocabulary item for ${targetExam}. Focus on formal academic register and precise nuance.

2. **High-Yield Collocations:**
   • Standard formal expression with "${word}"
   • Written essay and editorial collocation

3. **Grammatical Complementation:**
   Ensure proper syntactic agreement and preposition pairing in descriptive English composition.

4. **Editorial Context:**
   Frequently utilized in international current affairs commentaries and civil service written essays.

5. **Mnemonic Hook:**
   Connect "${word}" with its grammatical root and active recall flashcards.`
  };
}

// Fallback 17-section dossier generator for /api/generate-word-dossier
function buildFallbackDossier(word: string, targetExam: string): WordData {
  const existing = findWordInLexicon(word);
  if (existing) {
    return existing;
  }

  const cleanWord = word.trim();
  const lower = cleanWord.toLowerCase();
  const cap = cleanWord.charAt(0).toUpperCase() + cleanWord.slice(1).toLowerCase();

  return {
    word: cap,
    pos: 'adjective',
    posFull: 'Adjective / Formal Lexicon',
    ipa: `/${lower}/`,
    ipaUK: `/${lower}/`,
    ipaUS: `/${lower}/`,
    bengaliPron: `[${cap}]`,
    syllables: lower,
    cefr: 'C1 (Advanced)',
    register: 'Formal / Literary / Journalistic',
    frequency: `High Yield in ${targetExam} & Competitive Exams`,
    simpleDef: `A key competitive English word denoting a specific formal concept or quality.`,
    advDef: `Advanced academic register term utilized in rigorous competitive examinations (${targetExam}, UPSC, Bank Officer, GRE).`,
    bengali: 'গুরুত্বপূর্ণ প্রতিযোগিতামূলক শব্দ',
    bengaliExp: `${cap} শব্দটি সাধারণত উচ্চপর্যায়ের লিখিত ইংরেজি ও প্রিলিমিনারি পরীক্ষায় নির্ভুল প্রয়োগ যাচাইয়ে আসে।`,
    connotations: 'Formal academic tone; carries stylistic weight in essays and précis.',
    formsTable: [
      { form: cap, pos: 'Adjective / Primary', bng: 'মূল শব্দ', ex: `The candidate demonstrated an understanding of ${lower}.` },
      { form: `${cap}ness`, pos: 'Noun', bng: 'বিশেষ্য রূপ', ex: `The report commented on the degree of ${lower}ness.` },
      { form: `${cap}ly`, pos: 'Adverb', bng: 'ক্রিয়া-বিশেষণ রূপ', ex: `The policy was ${lower}ly applied across departments.` }
    ],
    formsUsageNote: `নোট: ব্যাকরণগত সঠিকতা বজায় রাখতে পদান্তর (parts of speech transformation) ও বাক্য গঠনের নিয়মাবলি লক্ষ্য রাখুন।`,
    contexts: [
      { domain: 'Civil Administration & Policy', note: 'Commonly employed in government reports and policy formulations.' },
      { domain: 'Competitive English Essay & Précis', note: 'Elevates stylistic score in formal writing.' }
    ],
    sentences: [
      { en: `The tribunal highlighted the significance of ${lower} in administrative reforms.`, bn: `সংস্কার প্রক্রিয়ায় প্রাতিষ্ঠানিক গুরুত্ব বিবেচনায় এটি উল্লেখ করা হয়েছিল।` },
      { en: `A successful competitive candidate must master the context of ${lower}.`, bn: `সফল প্রার্থীর এই ধারণার সঠিক প্রয়োগে পূর্ণ দক্ষতা থাকা আবশ্যক।` },
      { en: `Editorial commentators frequently utilize ${lower} in socio-economic analyses.`, bn: `সম্পাদকীয় ভাষ্যকারগণ সামাজিক-অর্থনৈতিক বিশ্লেষণে শব্দটি ব্যবহার করেন।` },
      { en: `His essay was commended for the nuanced usage of ${lower}.`, bn: `তার রচনাটিতে শব্দটির নিপুণ প্রয়োগের প্রশংসা করা হয়েছিল।` }
    ],
    synonyms: [
      { nuance: 'Core conceptual match', words: ['accurate', 'precise', 'academic'], note: 'Contextual exam equivalents.' }
    ],
    antonyms: [
      { nuance: 'Direct conceptual contrast', words: ['inaccurate', 'negligent', 'unsuitable'], note: 'Direct opposite meaning.' }
    ],
    confusions: [
      { word: cap, diff: `Exact target term in this dossier.`, ex: `Observe exact spelling: ${cap}` },
      { word: 'Related Term', diff: `Distinct contextual register.`, ex: `Do not confuse with similar sounding roots.` }
    ],
    etymology: `Derived through Classical Latin and Anglo-Norman roots into formal modern English.`,
    collocations: [
      { type: 'Standard Collocation', expr: `manifest ${lower}`, bn: `স্পষ্ট প্রকাশ পাওয়া` },
      { type: 'Adjective + Noun', expr: `profound ${lower}`, bn: `গভীর তাৎপর্য` },
      { type: 'Verb + Object', expr: `demonstrate ${lower}`, bn: `প্রদর্শন করা` }
    ],
    keyExpression: `Demonstrate genuine commitment to ${lower}`,
    keyExpressionBn: `বাস্তব ক্ষেত্রে এর যথাযথ প্রতিফলন নিশ্চিত করা।`,
    grammar: `Follows standard English syntax. Pay careful attention to transitive complementation and appropriate preposition links.`,
    pragmatics: 'Formal English register. Highly recommended for formal essays and Viva interviews.',
    errors: [
      { mistake: `Using ${lower} in an informal colloquial register`, fix: `Reserve for formal academic, administrative, and essay contexts.` }
    ],
    mnemonicBengali: `${cap} = প্রতিযোগিতামূলক পরীক্ষায় উচ্চ নম্বর নিশ্চিতে শব্দটির মূল ভাব মনে রাখুন।`,
    literature: 'Found frequently in classical literature, contemporary international journalism, and civil service papers.',
    essayQuote: `In contemporary governance, the accurate application of ${lower} remains an indispensable pillar of institutional excellence.`,
    essayQuoteBn: `সমসাময়িক সুশাসনে প্রাতিষ্ঠানিক উৎকর্ষের অন্যতম প্রধান ভিত্তি হিসেবে এটি স্বীকৃত।`,
    examBattery: [
      { q: `What is the primary register of "${cap}" in competitive English?`, opts: ['Formal / Academic', 'Slang', 'Childish', 'Obsolete'], ans: 0, exp: `"${cap}" is a formal academic term high-yield in competitive exams.` },
      { q: `Which sentence utilizes "${cap}" with grammatical precision?`, opts: [`The report analyzed ${lower} with great accuracy.`, `He ${lower} the car yesterday.`, `Quickly ${lower} across the lawn.`, `Very ${lower} apple in the basket.`], ans: 0, exp: 'Option A presents correct formal syntactic usage.' },
      { q: `In written composition, using "${cap}" appropriately helps to:`, opts: ['Elevate vocabulary register and precision', 'Confuse the examiner', 'Shorten the sentence artificially', 'Change the grammar tense'], ans: 0, exp: 'Precision vocabulary demonstrates advanced linguistic control.' }
    ],
    quickRevision: { sentence: `The report demonstrated ${lower}.`, collocation: `manifest ${lower}` },
    finalSummary: [
      `Target word: ${cap}.`,
      `Grammatical class: Formal English.`,
      `Crucial for ${targetExam} preliminary and written papers.`
    ]
  };
}

// Chat endpoint with conversation history & optional Google Search Grounding
app.post('/api/chat', async (req: Request, res: Response): Promise<void> => {
  const { messages, useSearchGrounding = false, examTarget = 'Bangladesh Civil Service (BCS)' } = req.body;

  if (!messages || !Array.isArray(messages) || messages.length === 0) {
    res.status(400).json({ error: 'Messages array is required.' });
    return;
  }

  const lastMessage = messages[messages.length - 1]?.content || '';

  // If Gemini is available, attempt live generation
  if (ai) {
    try {
      const contents = messages.map((m: { role: string; content: string }) => ({
        role: m.role === 'model' || m.role === 'assistant' ? 'model' : 'user',
        parts: [{ text: m.content }],
      }));

      const systemInstruction = `You are "Professor Cadre" — an expert English lexicographer, senior university linguist, and premier vocabulary master coach for competitive examinations (including ${examTarget}, Combined Bank Officer recruitment, UPSC, IBA, and GRE).
Your mission is to help competitive aspirants build unbreakable, active recall vocabulary mastery.
Key Guidelines:
1. Explain words with precision: distinction from lookalikes/confusing synonyms, exact preposition complementation, authentic collocations, and register.
2. When helpful, provide bilingual Bengali explanations (বাংলা অর্থ, বিভ্রান্তি এড়ানোর কৌশল, ও স্মৃতি সহায়ক ছন্দ/Mnemonic).
3. Offer model sentences tailored for high-scoring written English essays and précis.
4. When Google Search Grounding is enabled, pull up-to-date real-world sentence examples from recent international editorials, newspapers, or competitive exam papers.
5. Keep your tone engaging, intellectually disciplined, and concise.`;

      const config: Record<string, unknown> = {
        systemInstruction,
        temperature: 0.7,
      };

      if (useSearchGrounding) {
        config.tools = [{ googleSearch: {} }];
      }

      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents,
        config,
      });

      const replyText = response.text || 'I apologize, but I could not formulate a response. Please try again.';
      const searchChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
      const webSources = searchChunks
        .map((chunk: { web?: { title?: string; uri?: string } }) => chunk.web)
        .filter(Boolean);

      res.json({
        text: replyText,
        sources: webSources,
      });
      return;
    } catch (error) {
      console.warn('Gemini live call failed, falling back to local cognitive engine:', error);
      // Fall through to local fallback generator
    }
  }

  // Graceful local cognitive fallback
  const fallback = buildFallbackChatReply(lastMessage, examTarget);
  res.json(fallback);
});

// Real-time custom word analysis
app.post('/api/explain-word', async (req: Request, res: Response): Promise<void> => {
  const { word, targetExam = 'Bangladesh Civil Service (BCS)' } = req.body;
  if (!word) {
    res.status(400).json({ error: 'Word is required.' });
    return;
  }

  if (ai) {
    try {
      const prompt = `Perform an up-to-date lexicographical and exam analysis for the word: "${word}" for candidates targeting ${targetExam}.
Include:
1. Core definition and subtle nuance distinction.
2. 3 High-yield collocations.
3. Common prepositions and grammatical complementation.
4. 2 Recent editorial or current-affairs context sentences.
5. Bengali meaning and memorable mnemonic hook.`;

      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
          tools: [{ googleSearch: {} }],
        },
      });

      res.json({
        word,
        analysis: response.text,
      });
      return;
    } catch (error) {
      console.warn('Gemini explain-word failed, falling back to local lexicon:', error);
    }
  }

  // Graceful local fallback
  const fallback = buildFallbackExplainWord(word, targetExam);
  res.json(fallback);
});

// Full structured 17-Section Master Dossier generator
app.post('/api/generate-word-dossier', async (req: Request, res: Response): Promise<void> => {
  const { word, targetExam = 'Bangladesh Civil Service (BCS)' } = req.body;
  if (!word) {
    res.status(400).json({ error: 'Word is required.' });
    return;
  }

  if (ai) {
    try {
      const systemInstruction = `You are an elite lexicographer and senior university English linguist for competitive exams (${targetExam}, UPSC, Bank Officer, GRE).
Generate an exhaustive, highly personalized, NON-GENERIC 17-section Master Dossier for the English word: "${word}".
Return strictly valid JSON conforming to the requested schema.`;

      const prompt = `Generate a full 17-section lexicographical dossier for the word: "${word}" in valid JSON.
Fields:
- word (string)
- pos (string: 'noun' | 'verb' | 'adjective' | 'adverb')
- posFull (string)
- ipa (string)
- ipaUK (string)
- ipaUS (string)
- bengaliPron (string)
- syllables (string)
- cefr (string: B2 | C1 | C2)
- register (string)
- frequency (string)
- simpleDef (string)
- advDef (string)
- bengali (string)
- bengaliExp (string)
- connotations (string)
- formsTable (array of: { form: string, pos: string, bng: string, ex: string })
- formsUsageNote (string)
- sentences (array of 4+ items: { en: string, bn: string })
- synonyms (array of: { nuance: string, words: string[] })
- antonyms (array of: { nuance: string, words: string[] })
- confusions (array of: { word: string, diff: string, ex: string })
- etymology (string)
- collocations (array of: { type: string, expr: string, bn: string })
- keyExpression (string)
- keyExpressionBn (string)
- grammar (string)
- pragmatics (string)
- errors (array of: { mistake: string, fix: string })
- mnemonicBengali (string)
- essayQuote (string)
- essayQuoteBn (string)
- examBattery (array of 3-5 MCQs: { q: string, opts: string[], ans: number, exp: string })
- quickRevision ({ sentence: string, collocation: string })
- finalSummary (array of strings)`;

      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
          systemInstruction,
          responseMimeType: 'application/json',
          temperature: 0.4,
        },
      });

      const jsonText = response.text?.trim() || '{}';
      const parsed = JSON.parse(jsonText);
      res.json(parsed);
      return;
    } catch (error) {
      console.warn('Gemini generate-word-dossier failed, falling back to local dossier engine:', error);
    }
  }

  // Graceful local fallback
  const fallback = buildFallbackDossier(word, targetExam);
  res.json(fallback);
});

// Setup Vite or static serving
async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';

  if (!isProd) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`VocabMuse server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
