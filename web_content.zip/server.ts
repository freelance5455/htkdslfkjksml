import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import fs from 'fs';
import { GoogleGenAI, Type } from '@google/genai';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;
const isProduction = process.env.NODE_ENV === 'production';

// Allow large payloads for image uploads (photo of question papers)
app.use(express.json({ limit: '25mb' }));
app.use(express.urlencoded({ extended: true, limit: '25mb' }));

// Initialize GoogleGenAI SDK with server-side API Key
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

// Seed data storage
const DATA_DIR = path.resolve(process.cwd(), 'data');
const DATA_FILE = path.join(DATA_DIR, 'quizzes.json');

const INITIAL_QUIZZES = [
  {
    id: 'quiz_raj_gk_1',
    subjectId: 'rajasthan_gk',
    subCategoryId: 'raj_art_culture',
    title: 'राजस्थान कला एवं संस्कृति: प्रमुख दुर्ग व महल (Mock 1)',
    description: 'चित्तौड़गढ़, कुम्भलगढ़, मेहरानगढ़ और हवामहल से संबंधित महत्वपूर्ण परीक्षा प्रश्न।',
    createdAt: Date.now() - 86400000 * 2,
    questions: [
      {
        text: 'चित्तौड़गढ़ दुर्ग में स्थित प्रसिद्ध "विजय स्तम्भ" का निर्माण किस शासक ने करवाया था?',
        options: ['महाराणा प्रताप', 'महाराणा कुंभा', 'राणा सांगा', 'महाराणा उदयसिंह'],
        correctIndex: 1,
        explanation: 'विजय स्तम्भ का निर्माण महाराणा कुंभा ने मालवा के सुल्तान महमूद खिलजी पर विजय (सारंगपुर युद्ध 1437) के उपलक्ष्य में 1440-1448 के मध्य करवाया था। इसे भारतीय मूर्तिकला का विश्वकोश भी कहा जाता है।'
      },
      {
        text: 'विश्व धरोहर सूची (UNESCO World Heritage) में राजस्थान के कितने पहाड़ी दुर्ग (Hill Forts) शामिल हैं?',
        options: ['4 दुर्ग', '5 दुर्ग', '6 दुर्ग', '7 दुर्ग'],
        correctIndex: 2,
        explanation: '2013 में कंबोडिया के नोम पेन्ह में यूनेस्को द्वारा राजस्थान के 6 पहाड़ी दुर्गों को शामिल किया गया था: चित्तौड़गढ़, कुम्भलगढ़, रणथंभौर, गागरोन, आमेर और जैसलमेर (ट्रिक: चीकू गाजर आम)।'
      },
      {
        text: 'जयपुर स्थित "हवामहल" का निर्माण किसने और किस वर्ष करवाया था?',
        options: ['सवाई जयसिंह (1727)', 'सवाई प्रताप सिंह (1799)', 'सवाई माधोसिंह (1763)', 'सवाई रामसिंह (1835)'],
        correctIndex: 1,
        explanation: 'हवामहल का निर्माण 1799 ई. में सवाई प्रताप सिंह ने करवाया था। इसके वास्तुकार लालचंद उस्ता थे। यह 5 मंजिला महल भगवान श्रीकृष्ण के मुकुट जैसा दिखता है और इसमें 953 झरोखे हैं।'
      },
      {
        text: 'राजस्थान का कौन-सा दुर्ग "जल दुर्ग" (औदक दुर्ग) की श्रेणी का सर्वश्रेष्ठ उदाहरण है?',
        options: ['मेहरानगढ़ दुर्ग', 'तारागढ़ दुर्ग', 'गागरोन दुर्ग', 'भटनेर दुर्ग'],
        correctIndex: 2,
        explanation: 'झालावाड़ में स्थित गागरोन दुर्ग आहु और कालीसिंध नदियों के संगम पर बिना किसी नींव के एक विशाल चट्टान पर स्थित है। यह जल दुर्ग का सर्वोत्तम उदाहरण है।'
      },
      {
        text: 'कुम्भलगढ़ दुर्ग की उस प्राचीर (दीवार) की लंबाई कितनी है जिसे "भारत की महान दीवार" कहा जाता है?',
        options: ['21 किलोमीटर', '36 किलोमीटर', '52 किलोमीटर', '65 किलोमीटर'],
        correctIndex: 1,
        explanation: 'कुम्भलगढ़ दुर्ग की परकोटे की दीवार लगभग 36 किमी लंबी है और यह इतनी चौड़ी है कि इस पर 4 घुड़सवार एक साथ चल सकते हैं। इसे "द ग्रेट वॉल ऑफ इंडिया" कहा जाता है।'
      }
    ]
  },
  {
    id: 'quiz_maths_1',
    subjectId: 'maths',
    subCategoryId: 'maths_arithmetic',
    title: 'अंकगणित: प्रतिशतता एवं लाभ-हानि (Arithmetic Mastery)',
    description: 'प्रतियोगी परीक्षाओं में बार-बार पूछे जाने वाले प्रतिशत और लाभ-हानि के प्रश्न।',
    createdAt: Date.now() - 86400000,
    questions: [
      {
        text: 'एक वस्तु को ₹960 में बेचने पर एक दुकानदार को 20% का लाभ होता है। वस्तु का क्रय मूल्य (Cost Price) ज्ञात कीजिए:',
        options: ['₹750', '₹800', '₹820', '₹850'],
        correctIndex: 1,
        explanation: 'विक्रय मूल्य = क्रय मूल्य × (100 + लाभ%) / 100 => 960 = CP × 120 / 100 => CP = 960 × 100 / 120 = ₹800।'
      },
      {
        text: 'यदि A की आय B की आय से 25% अधिक है, तो B की आय A की आय से कितने प्रतिशत कम है?',
        options: ['20%', '25%', '16.66%', '30%'],
        correctIndex: 0,
        explanation: 'फॉर्मूला: [R / (100 + R)] × 100 => [25 / 125] × 100 = 1/5 × 100 = 20% कम है।'
      },
      {
        text: 'किसी परीक्षा में उत्तीर्ण होने के लिए 36% अंक चाहिए। एक छात्र ने 145 अंक प्राप्त किए और 35 अंकों से अनुत्तीर्ण हो गया। परीक्षा के कुल पूर्णांक ज्ञात करें:',
        options: ['450', '500', '550', '600'],
        correctIndex: 1,
        explanation: 'उत्तीर्णांक = 145 + 35 = 180 अंक। 36% = 180 अंक => 1% = 5 अंक => 100% (कुल पूर्णांक) = 500 अंक।'
      }
    ]
  },
  {
    id: 'quiz_hindi_1',
    subjectId: 'hindi',
    subCategoryId: 'hindi_vyakaran',
    title: 'हिंदी व्याकरण: संधि एवं समास अभ्यास सेट',
    description: 'स्वर, व्यंजन, विसर्ग संधि और समास विग्रह के मानक प्रश्न।',
    createdAt: Date.now(),
    questions: [
      {
        text: '"पवन" शब्द का सही संधि-विच्छेद क्या होगा?',
        options: ['पौ + अन', 'पो + अन', 'प + वन', 'पा + वन'],
        correctIndex: 1,
        explanation: 'पो + अन = पवन (अयादि स्वर संधि का नियम: ओ + अ = अव्)। ध्यान दें: पौ + अन = पावन होता है।'
      },
      {
        text: '"त्रिफला" शब्द में कौन-सा समास है?',
        options: ['द्वंद्व समास', 'कर्मधारय समास', 'द्विगु समास', 'बहुव्रीहि समास'],
        correctIndex: 2,
        explanation: 'त्रिफला का विग्रह "तीन फलों का समाहार" है। जिस समास का पहला पद संख्यावाचक विशेषण हो, वह द्विगु समास कहलाता है।'
      },
      {
        text: '"अत्याचार" शब्द में किस उपसर्ग का प्रयोग हुआ है?',
        options: ['अति', 'अत्', 'अत्या', 'अ'],
        correctIndex: 0,
        explanation: 'अत्याचार = अति + आचार (यण स्वर संधि)। इसमें "अति" उपसर्ग का प्रयोग हुआ है जिसका अर्थ "अधिक" या "परे" होता है।'
      }
    ]
  }
];

function getStoredQuizzes() {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    if (!fs.existsSync(DATA_FILE)) {
      fs.writeFileSync(DATA_FILE, JSON.stringify(INITIAL_QUIZZES, null, 2), 'utf-8');
      return INITIAL_QUIZZES;
    }
    const content = fs.readFileSync(DATA_FILE, 'utf-8');
    const parsed = JSON.parse(content);
    return Array.isArray(parsed) && parsed.length > 0 ? parsed : INITIAL_QUIZZES;
  } catch (err) {
    console.error('Error reading quizzes data file:', err);
    return INITIAL_QUIZZES;
  }
}

function saveStoredQuizzes(quizzes: any[]) {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    fs.writeFileSync(DATA_FILE, JSON.stringify(quizzes, null, 2), 'utf-8');
  } catch (err) {
    console.error('Error writing quizzes data file:', err);
  }
}

// ================= API ENDPOINTS =================

// 1. Health & Connection status check
app.get('/api/status', (req, res) => {
  const hasKey = Boolean(process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY !== 'MY_GEMINI_API_KEY');
  res.json({
    status: 'ok',
    geminiConfigured: hasKey,
    timestamp: new Date().toISOString(),
    message: hasKey
      ? 'Google Gemini API is connected and active on server.'
      : 'Google Gemini API key is missing or default.',
  });
});

// 2. Fetch all quizzes
app.get('/api/quizzes', (req, res) => {
  const quizzes = getStoredQuizzes();
  res.json({ success: true, quizzes });
});

// 3. Save or update quiz
app.post('/api/quizzes', (req, res) => {
  try {
    const quizData = req.body;
    if (!quizData || !quizData.title || !Array.isArray(quizData.questions) || quizData.questions.length === 0) {
      return res.status(400).json({ success: false, error: 'शीर्षक और कम से कम एक प्रश्न होना अनिवार्य है।' });
    }

    const quizId = quizData.id || `quiz_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    const fullQuiz = {
      ...quizData,
      id: quizId,
      createdAt: quizData.createdAt || Date.now(),
    };

    const currentQuizzes = getStoredQuizzes();
    const existingIndex = currentQuizzes.findIndex((q: any) => q.id === quizId);

    if (existingIndex >= 0) {
      currentQuizzes[existingIndex] = fullQuiz;
    } else {
      currentQuizzes.unshift(fullQuiz);
    }

    saveStoredQuizzes(currentQuizzes);
    res.json({ success: true, quiz: fullQuiz });
  } catch (error: any) {
    console.error('Error saving quiz:', error);
    res.status(500).json({ success: false, error: error.message || 'क्विज़ सेव करने में समस्या आई।' });
  }
});

// 4. Delete quiz
app.delete('/api/quizzes/:id', (req, res) => {
  try {
    const { id } = req.params;
    const currentQuizzes = getStoredQuizzes();
    const updated = currentQuizzes.filter((q: any) => q.id !== id);
    saveStoredQuizzes(updated);
    res.json({ success: true, message: 'Quiz deleted successfully' });
  } catch (error: any) {
    console.error('Error deleting quiz:', error);
    res.status(500).json({ success: false, error: error.message || 'क्विज़ हटाने में त्रुटि।' });
  }
});

// 5. Generate Questions with Gemini AI API
app.post('/api/gemini/generate-questions', async (req, res) => {
  try {
    const {
      topic = '',
      text = '',
      image,
      count = 5,
      subjectName = 'सामान्य प्रतियोगी परीक्षा',
      difficulty = 'मध्यम (Moderate)',
    } = req.body;

    if (!topic && !text && !image) {
      return res.status(400).json({
        success: false,
        error: 'कृपया कोई विषय, टेक्स्ट या प्रश्न-पत्र की फोटो अपलोड करें।',
      });
    }

    const numQuestions = Math.min(Math.max(parseInt(count, 10) || 5, 1), 15);

    const parts: any[] = [];

    // System guidance instructions
    const promptInstruction = `
आप एक अनुभवी प्रतियोगी परीक्षा विशेषज्ञ और परीक्षक (Exam Examiner) हैं।
विषय / संदर्भ: "${subjectName}"
कठिनाई स्तर: "${difficulty}"

निर्देश:
1. दिए गए टॉपिक, टेक्स्ट या अपलोड की गई इमेज से ठीक ${numQuestions} बहुविकल्पीय प्रश्न (MCQs) तैयार करें।
2. प्रत्येक प्रश्न के ठीक 4 स्पष्ट और प्रामाणिक विकल्प (Options: A, B, C, D) होने चाहिए।
3. 'correctIndex' 0 से 3 के बीच एक पूर्णांक होना चाहिए जो सही विकल्प को दर्शाता हो (0 = Option 1, 1 = Option 2, etc.)।
4. 'explanation' (व्याख्या) में प्रश्न का उत्तर सही क्यों है, इसका स्पष्ट, तथ्यात्मक और प्रामाणिक विवरण हिन्दी में दें।
5. भाषा शुद्ध, स्पष्ट और मानक होनी चाहिए (हिन्दी/देवनागरी)।
`;

    parts.push({ text: promptInstruction });

    if (topic || text) {
      parts.push({
        text: `\n--- उपयोगकर्ता द्वारा दिया गया टॉपिक/टेक्स्ट ---\n${topic ? 'विषय: ' + topic + '\n' : ''}${text ? 'सामग्री: ' + text : ''}`,
      });
    }

    if (image && image.data) {
      let cleanBase64 = image.data;
      if (cleanBase64.includes('base64,')) {
        cleanBase64 = cleanBase64.split('base64,')[1];
      }
      parts.push({
        inlineData: {
          mimeType: image.mimeType || 'image/jpeg',
          data: cleanBase64,
        },
      });
    }

    // Call Gemini with automatic retry and model fallback for resilience
    const modelsToTry = ['gemini-3.8-flash', 'gemini-3.1-flash-lite'];
    let lastError: any = null;
    let response: any = null;

    for (const modelName of modelsToTry) {
      try {
        response = await ai.models.generateContent({
          model: modelName,
          contents: { parts },
          config: {
            systemInstruction: 'You are an elite academic test creator. Always output valid JSON strictly complying with the schema.',
            responseMimeType: 'application/json',
            responseSchema: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  text: {
                    type: Type.STRING,
                    description: 'The question text in Hindi/English',
                  },
                  options: {
                    type: Type.ARRAY,
                    items: { type: Type.STRING },
                    description: 'Array of exactly 4 choices',
                  },
                  correctIndex: {
                    type: Type.INTEGER,
                    description: '0-based index of the correct answer (0, 1, 2, or 3)',
                  },
                  explanation: {
                    type: Type.STRING,
                    description: 'Detailed explanation/व्याख्या for why this answer is correct',
                  },
                },
                required: ['text', 'options', 'correctIndex', 'explanation'],
              },
            },
          },
        });
        if (response && response.text) {
          break; // successfully generated
        }
      } catch (err: any) {
        console.warn(`Model ${modelName} attempt failed:`, err.message || err);
        lastError = err;
        // brief delay before next model
        await new Promise((r) => setTimeout(r, 800));
      }
    }

    if (!response || !response.text) {
      throw lastError || new Error('Gemini API सेवा वर्तमान में व्यस्त है। कृपया कुछ पलों बाद पुनः प्रयास करें।');
    }

    const responseText = response.text?.trim() || '[]';
    let questionsList = [];

    try {
      questionsList = JSON.parse(responseText);
    } catch (parseErr) {
      console.warn('JSON direct parse failed, attempting extraction:', parseErr);
      const jsonMatch = responseText.match(/\[[\s\S]*\]/);
      if (jsonMatch) {
        questionsList = JSON.parse(jsonMatch[0]);
      } else {
        throw new Error('AI उत्तर को JSON प्रारूप में नहीं बदला जा सका।');
      }
    }

    if (!Array.isArray(questionsList) || questionsList.length === 0) {
      throw new Error('AI द्वारा कोई प्रश्न उत्पन्न नहीं किया जा सका। कृपया पुनः प्रयास करें।');
    }

    res.json({
      success: true,
      questions: questionsList,
      count: questionsList.length,
    });
  } catch (error: any) {
    console.error('Error generating questions with Gemini:', error);
    res.status(500).json({
      success: false,
      error: error.message || 'AI प्रश्न निर्माण में त्रुटि हुई। कृपया दोबारा प्रयास करें।',
    });
  }
});

// Setup Vite in Development or Static Server in Production
async function setupServer() {
  if (!isProduction) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, () => {
    console.log(`Server listening on port ${PORT} (dev mode: ${!isProduction})`);
  });
}

setupServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
