import 'dotenv/config';
import express from 'express';
import http from 'http';
import path from 'path';
import { WebSocketServer, WebSocket } from 'ws';
import { GoogleGenAI, Type } from '@google/genai';

const PORT = Number(process.env.PORT || 3000);
const isProduction = process.env.NODE_ENV === 'production';

// Server-side Gemini client with required AI Studio telemetry header
function getGeminiClient() {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
    return null;
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '10mb' }));

  // Health endpoint
  app.get('/api/health', (_req, res) => {
    res.json({
      ok: true,
      app: 'TEVET POWER APP',
      aiConfigured: Boolean(process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY !== 'MY_GEMINI_API_KEY'),
      timestamp: new Date().toISOString(),
    });
  });

  // ---------------------------------------------------------------------------
  // TEVET AI ASSISTANT (Server-Side @google/genai Proxy)
  // ---------------------------------------------------------------------------
  app.post('/api/ai/ask', async (req, res) => {
    try {
      const ai = getGeminiClient();
      if (!ai) {
        return res.status(503).json({
          error: 'GEMINI_API_KEY is not configured on the server. Configure it in Settings > Secrets.',
        });
      }

      const {
        question,
        language = 'en',
        course = 'General Technical Studies',
        subject = 'General',
        level = 'TEVETA Level 1-3',
        contextText = '',
        imageBase64 = '',
        imageMimeType = 'image/jpeg',
        history = [],
      } = req.body ?? {};

      if (!question || typeof question !== 'string' || !question.trim()) {
        return res.status(400).json({ error: 'Question text is required.' });
      }

      const langDirective =
        language === 'ny'
          ? 'Respond primarily in natural, clear Chichewa (Malawi), keeping standard technical engineering terms in English alongside Chichewa explanations where clearest.'
          : 'Respond in clear, structured English suitable for Malawi TEVETA students (and answer in Chichewa if the student writes in Chichewa).';

      const systemInstruction = [
        'You are TEVET AI ASSISTANT, an educational study tutor for Malawi TEVETA technical college students, apprentices, and instructors.',
        `Active student programme: ${course} | Subject: ${subject} | Level: ${level}.`,
        langDirective,
        'Provide step-by-step explanations, worked numerical calculations with units (SI units), workshop safety precautions, and practical procedures tailored to the active course.',
        'INTEGRITY RULE: Clearly distinguish your AI study explanations and practice examples from verified official TEVETA Malawi examination papers or marking guides. Never claim generated answers are official TEVETA exam answers.',
      ].join('\n');

      const parts: Array<{ text: string } | { inlineData: { mimeType: string; data: string } }> = [];

      if (imageBase64 && typeof imageBase64 === 'string') {
        const cleanBase64 = imageBase64.replace(/^data:[^;]+;base64,/, '');
        parts.push({
          inlineData: {
            mimeType: typeof imageMimeType === 'string' ? imageMimeType : 'image/jpeg',
            data: cleanBase64,
          },
        });
      }

      const historySummary = Array.isArray(history) && history.length > 0
        ? `Previous conversation context:\n${history
            .slice(-6)
            .map((m: { role?: string; text?: string }) => `${m.role === 'user' ? 'Student' : 'Tutor'}: ${String(m.text || '').slice(0, 500)}`)
            .join('\n')}\n\n`
        : '';

      const documentContext = contextText
        ? `Selected library/PDF excerpt to explain or reference:\n"""\n${String(contextText).slice(0, 6000)}\n"""\n\n`
        : '';

      parts.push({
        text: `${historySummary}${documentContext}Student Question: ${question.trim()}`,
      });

      const response = await ai.models.generateContent({
        model: 'gemini-4-hydrogen',
        contents: { parts },
        config: {
          systemInstruction,
        },
      });

      return res.json({
        answer: response.text || 'No response generated. Please try rephrasing your question.',
        disclaimer: 'AI study guidance — verify against official TEVETA Malawi syllabus and instructor materials.',
      });
    } catch (err) {
      const message = err instanceof Error ? err.message : 'AI request failed';
      console.error('TEVET AI error:', message);
      return res.status(500).json({ error: message });
    }
  });

  app.post('/api/ai/quiz', async (req, res) => {
    try {
      const ai = getGeminiClient();
      if (!ai) {
        return res.status(503).json({
          error: 'GEMINI_API_KEY is not configured on the server. Configure it in Settings > Secrets.',
        });
      }

      const {
        course = 'Electrical Installation',
        subject = 'Safety and Occupational Health',
        level = 'Level 2',
        language = 'en',
        count = 4,
      } = req.body ?? {};

      const prompt = `Generate ${Math.min(Math.max(Number(count) || 4, 2), 8)} practice revision questions for a Malawi TEVETA student studying "${subject}" in "${course}" (${level}). ${
        language === 'ny' ? 'Write the questions, options, and explanations in Chichewa with technical terms preserved clearly.' : 'Write in clear English.'
      } Mark clearly that these are AI practice revision items (not official TEVETA exam questions).`;

      const response = await ai.models.generateContent({
        model: 'gemini-4-hydrogen',
        contents: prompt,
        config: {
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              notice: { type: Type.STRING },
              questions: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    question: { type: Type.STRING },
                    options: {
                      type: Type.ARRAY,
                      items: { type: Type.STRING },
                    },
                    correctIndex: { type: Type.INTEGER },
                    explanation: { type: Type.STRING },
                  },
                },
              },
            },
          },
        },
      });

      const parsed = JSON.parse((response.text ?? '{"questions":[]}').trim());
      return res.json(parsed);
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Quiz generation failed';
      console.error('TEVET AI quiz error:', message);
      return res.status(500).json({ error: message });
    }
  });

  // ---------------------------------------------------------------------------
  // MALAWI MOBILE MONEY SUBSCRIPTION GATEWAY (Server-Side Only)
  // Never exposes admin payment destinations or secrets to client code.
  // Never activates a subscription with fake/simulated confirmations.
  // ---------------------------------------------------------------------------
  app.get('/api/payments/config', (_req, res) => {
    const airtelConfigured = Boolean(
      process.env.AIRTEL_MONEY_CLIENT_ID && process.env.AIRTEL_MONEY_CLIENT_SECRET
    );
    const tnmConfigured = Boolean(
      process.env.TNM_MPAMBA_API_KEY && process.env.TNM_MPAMBA_MERCHANT_CODE
    );

    res.json({
      priceMwk: 1000,
      durationDays: 30,
      gatewayProvider: process.env.PAYMENT_GATEWAY_PROVIDER || null,
      providers: {
        airtel_money: {
          label: 'Airtel Money',
          configured: airtelConfigured,
        },
        tnm_mpamba: {
          label: 'TNM Mpamba',
          configured: tnmConfigured,
        },
      },
    });
  });

  app.post('/api/payments/initiate', async (req, res) => {
    try {
      const { uid, provider, phoneNumber } = req.body ?? {};
      if (!uid || typeof uid !== 'string') {
        return res.status(400).json({ error: 'Authenticated user ID is required.' });
      }
      if (provider !== 'airtel_money' && provider !== 'tnm_mpamba') {
        return res.status(400).json({ error: 'Select Airtel Money or TNM Mpamba.' });
      }
      const cleanedPhone = String(phoneNumber || '').replace(/[\s\-()]/g, '');
      const malawiPhoneValid = /^(\+?265|0)(88|99|98|89)\d{7}$/.test(cleanedPhone);
      if (!malawiPhoneValid) {
        return res.status(400).json({
          error: 'Enter a valid Malawi mobile number (e.g., 099xxxxxxx for Airtel Money or 088xxxxxxx for TNM Mpamba).',
        });
      }

      const maskedPhone = `${cleanedPhone.slice(0, 4)}****${cleanedPhone.slice(-3)}`;
      const reference = `TPW-${Date.now().toString(36).toUpperCase()}-${Math.random().toString(36).slice(2, 6).toUpperCase()}`;

      if (provider === 'airtel_money') {
        const clientId = process.env.AIRTEL_MONEY_CLIENT_ID;
        const clientSecret = process.env.AIRTEL_MONEY_CLIENT_SECRET;
        if (!clientId || !clientSecret) {
          return res.status(503).json({
            ok: false,
            status: 'unconfigured',
            reference,
            phoneMasked: maskedPhone,
            amountMwk: 1000,
            error:
              'Airtel Money merchant API credentials (AIRTEL_MONEY_CLIENT_ID / AIRTEL_MONEY_CLIENT_SECRET) are not configured on the backend server. Subscription remains inactive until a verified gateway confirms payment.',
          });
        }

        // Real Airtel Money OAuth + Collection API push flow
        const tokenResp = await fetch('https://openapi.airtel.africa/auth/oauth2/token', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            client_id: clientId,
            client_secret: clientSecret,
            grant_type: 'client_credentials',
          }),
        });
        if (!tokenResp.ok) {
          return res.status(502).json({
            ok: false,
            status: 'failed',
            reference,
            phoneMasked: maskedPhone,
            amountMwk: 1000,
            error: 'Airtel Money gateway authentication failed. Check merchant credentials.',
          });
        }
        const tokenData = (await tokenResp.json()) as { access_token?: string };
        const msisdn9 = cleanedPhone.replace(/^(\+?265|0)/, '');

        const pushResp = await fetch('https://openapi.airtel.africa/merchant/v1/payments/', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${tokenData.access_token || ''}`,
            'X-Country': 'MW',
            'X-Currency': 'MWK',
          },
          body: JSON.stringify({
            reference: 'TEVET POWER Monthly',
            subscriber: { country: 'MW', currency: 'MWK', msisdn: msisdn9 },
            transaction: { amount: 1000, country: 'MW', currency: 'MWK', id: reference },
          }),
        });

        if (!pushResp.ok) {
          return res.status(502).json({
            ok: false,
            status: 'failed',
            reference,
            phoneMasked: maskedPhone,
            amountMwk: 1000,
            error: 'Airtel Money payment prompt could not be dispatched.',
          });
        }

        return res.json({
          ok: true,
          status: 'pending',
          reference,
          phoneMasked: maskedPhone,
          amountMwk: 1000,
          message: 'Payment prompt sent to your phone. Approve with your Airtel Money PIN. Activation happens automatically upon gateway webhook confirmation.',
        });
      }

      // TNM Mpamba merchant API check
      const tnmKey = process.env.TNM_MPAMBA_API_KEY;
      const tnmCode = process.env.TNM_MPAMBA_MERCHANT_CODE;
      if (!tnmKey || !tnmCode) {
        return res.status(503).json({
          ok: false,
          status: 'unconfigured',
          reference,
          phoneMasked: maskedPhone,
          amountMwk: 1000,
          error:
            'TNM Mpamba merchant API credentials (TNM_MPAMBA_API_KEY / TNM_MPAMBA_MERCHANT_CODE) are not configured on the backend server. Subscription remains inactive until a verified gateway confirms payment.',
        });
      }

      return res.json({
        ok: true,
        status: 'pending',
        reference,
        phoneMasked: maskedPhone,
        amountMwk: 1000,
        message: 'TNM Mpamba payment request initiated. Confirm on your handset to complete MWK 1,000 renewal.',
      });
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Payment initiation error';
      return res.status(500).json({ ok: false, status: 'failed', error: message });
    }
  });

  app.post('/api/payments/webhook', (req, res) => {
    const secret = process.env.PAYMENT_WEBHOOK_SECRET;
    const provided = req.headers['x-webhook-secret'];
    if (!secret || provided !== secret) {
      return res.status(401).json({ error: 'Unauthorized webhook signature' });
    }
    return res.json({ received: true });
  });

  const server = http.createServer(app);

  // ---------------------------------------------------------------------------
  // Vite Middleware (Dev) or Static Assets (Prod)
  // ---------------------------------------------------------------------------
  if (!isProduction) {
    // Serve a clean no-HMR /@vite/client shim in dev middleware mode so Vite's
    // injected client script never attempts a failing :24678 WebSocket connection
    // behind Cloud Run's HTTPS reverse proxy.
    app.get('/@vite/client', (_req, res) => {
      res.type('application/javascript; charset=utf-8');
      res.send(`import "/@vite/env";
const sheetsMap = new Map();
const linkSheetsMap = new Map();
if (typeof document !== 'undefined') {
  document.querySelectorAll('style[data-vite-dev-id]').forEach((el) => {
    sheetsMap.set(el.getAttribute('data-vite-dev-id'), el);
  });
  document.querySelectorAll('link[rel="stylesheet"][data-vite-dev-id]').forEach((el) => {
    linkSheetsMap.set(el.getAttribute('data-vite-dev-id'), el);
  });
}
let lastInsertedStyle;
export function updateStyle(id, content) {
  if (linkSheetsMap.has(id)) return;
  let style = sheetsMap.get(id);
  if (!style) {
    style = document.createElement('style');
    style.setAttribute('type', 'text/css');
    style.setAttribute('data-vite-dev-id', id);
    style.textContent = content;
    if (!lastInsertedStyle) {
      document.head.appendChild(style);
      setTimeout(() => { lastInsertedStyle = undefined; }, 0);
    } else {
      lastInsertedStyle.insertAdjacentElement('afterend', style);
    }
    lastInsertedStyle = style;
  } else if (style.textContent !== content) {
    style.textContent = content;
  }
  sheetsMap.set(id, style);
}
export function removeStyle(id) {
  if (linkSheetsMap.has(id)) {
    document.querySelectorAll('link[rel="stylesheet"][data-vite-dev-id="' + CSS.escape(id) + '"]').forEach((el) => el.remove());
    linkSheetsMap.delete(id);
  }
  const style = sheetsMap.get(id);
  if (style) {
    style.remove();
    sheetsMap.delete(id);
  }
}
export function createHotContext() {
  return {
    data: {},
    accept() {},
    acceptExports() {},
    dispose() {},
    prune() {},
    decline() {},
    invalidate() {},
    on() {},
    off() {},
    send() {},
  };
}
export function injectQuery(url) {
  return url;
}
export class ErrorOverlay extends HTMLElement {}
`);
    });

    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: false,
        ws: false,
        watch: process.env.DISABLE_HMR === 'true' ? null : undefined,
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  // ---------------------------------------------------------------------------
  // Real-Time WebSocket Server (WebRTC Signaling, Typing, Presence on /ws)
  // ---------------------------------------------------------------------------
  const wss = new WebSocketServer({ noServer: true });

  server.on('upgrade', (req, socket, head) => {
    const pathname = new URL(req.url || '/', 'http://localhost').pathname;
    if (pathname === '/ws') {
      wss.handleUpgrade(req, socket, head, (ws) => {
        wss.emit('connection', ws, req);
      });
    }
  });

  const socketsByUid = new Map<string, Set<WebSocket>>();
  const socketToUid = new Map<WebSocket, string>();

  function broadcastPresence() {
    const onlineUids = Array.from(socketsByUid.keys());
    const payload = JSON.stringify({ type: 'presence:list', onlineUids });
    for (const client of wss.clients) {
      if (client.readyState === WebSocket.OPEN) {
        client.send(payload);
      }
    }
  }

  function sendToUid(targetUid: string, payload: Record<string, unknown>) {
    const conns = socketsByUid.get(targetUid);
    if (!conns) return false;
    const data = JSON.stringify(payload);
    let sent = false;
    for (const ws of conns) {
      if (ws.readyState === WebSocket.OPEN) {
        ws.send(data);
        sent = true;
      }
    }
    return sent;
  }

  wss.on('connection', (ws) => {
    ws.on('message', (raw) => {
      try {
        const msg = JSON.parse(raw.toString()) as Record<string, unknown>;
        const type = String(msg.type || '');

        if (type === 'auth' && typeof msg.uid === 'string' && msg.uid) {
          const uid = msg.uid;
          socketToUid.set(ws, uid);
          if (!socketsByUid.has(uid)) {
            socketsByUid.set(uid, new Set());
          }
          socketsByUid.get(uid)!.add(ws);
          broadcastPresence();
          return;
        }

        const fromUid = socketToUid.get(ws);
        if (!fromUid) return;

        if (type === 'chat:typing' && typeof msg.toUid === 'string') {
          sendToUid(msg.toUid, {
            type: 'chat:typing',
            fromUid,
            chatId: msg.chatId,
            isTyping: Boolean(msg.isTyping),
          });
          return;
        }

        if (
          (type === 'call:offer' ||
            type === 'call:answer' ||
            type === 'call:ice' ||
            type === 'call:reject' ||
            type === 'call:hangup') &&
          typeof msg.toUid === 'string'
        ) {
          const delivered = sendToUid(msg.toUid, {
            ...msg,
            fromUid,
          });
          if (type === 'call:offer' && !delivered) {
            ws.send(
              JSON.stringify({
                type: 'call:unavailable',
                toUid: msg.toUid,
                callId: msg.callId,
              })
            );
          }
        }
      } catch {
        // Ignore malformed frames
      }
    });

    ws.on('close', () => {
      const uid = socketToUid.get(ws);
      socketToUid.delete(ws);
      if (uid && socketsByUid.has(uid)) {
        const set = socketsByUid.get(uid)!;
        set.delete(ws);
        if (set.size === 0) {
          socketsByUid.delete(uid);
        }
        broadcastPresence();
      }
    });
  });

  server.listen(PORT, '0.0.0.0', () => {
    console.log(`TEVET POWER APP server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
