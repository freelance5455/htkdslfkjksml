import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { apiRouter } from './src/server/apiRouter.ts';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = Number(process.env.PORT) || 3000;

  // Body parsing middleware for JSON and form data (skip raw binary chunk uploads)
  app.use((req, res, next) => {
    if (req.path.startsWith('/api/storage/chunk/')) {
      return next();
    }
    express.json({ limit: '50mb' })(req, res, next);
  });
  app.use((req, res, next) => {
    if (req.path.startsWith('/api/storage/chunk/')) {
      return next();
    }
    express.urlencoded({ extended: true, limit: '50mb' })(req, res, next);
  });

  // Mount API router for full-stack AI and operations endpoints
  app.use('/api', apiRouter);

  // Service Worker route with proper scope header
  app.get('/sw.js', (_req, res) => {
    res.setHeader('Content-Type', 'application/javascript');
    res.setHeader('Service-Worker-Allowed', '/');
    res.sendFile(path.resolve(__dirname, 'public/sw.js'));
  });

  // In development, mount Vite middleware; in production, serve built static assets
  if (process.env.NODE_ENV === 'production') {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  } else {
    const { createServer } = await import('vite');
    const vite = await createServer({
      server: {
        middlewareMode: true,
        host: '0.0.0.0',
        port: PORT,
        hmr: process.env.DISABLE_HMR !== 'true',
        watch: process.env.DISABLE_HMR === 'true' ? null : {},
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`FieldFlow server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start FieldFlow server:', err);
  process.exit(1);
});
