import express, { Request, Response } from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI, Type } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

// Body parser with 25MB limit for base64 image data
app.use(express.json({ limit: '25mb' }));

// Shared Gemini Client
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

// Helper for model fallback
async function generateWithFallback(options: {
  primaryModel: string;
  fallbackModel: string;
  contents: any;
  config?: any;
}) {
  try {
    const res = await ai.models.generateContent({
      model: options.primaryModel,
      contents: options.contents,
      config: options.config,
    });
    return { response: res, usedModel: options.primaryModel };
  } catch (err: any) {
    console.warn(`Primary model ${options.primaryModel} failed (${err.message || err}). Attempting fallback to ${options.fallbackModel}...`);
    const fallbackRes = await ai.models.generateContent({
      model: options.fallbackModel,
      contents: options.contents,
      config: options.config,
    });
    return { response: fallbackRes, usedModel: options.fallbackModel };
  }
}

// 1. Scene Analysis & Ghostwritten Opening Paragraph
app.post('/api/analyze-and-write', async (req: Request, res: Response) => {
  try {
    const { imageBase64, mimeType = 'image/jpeg', genre = 'Speculative Fiction', tone = 'Atmospheric & Evocative', pov = 'Third Person Limited', hookType = 'Atmospheric Immersion', userPrompt = '' } = req.body;

    if (!imageBase64) {
      return res.status(400).json({ error: 'Image data is required' });
    }

    // Strip data URL header if included
    const cleanBase64 = imageBase64.replace(/^data:image\/[a-z]+;base64,/, '');

    const imagePart = {
      inlineData: {
        mimeType: mimeType,
        data: cleanBase64,
      },
    };

    const promptText = `
You are an award-winning creative author, worldbuilding architect, and master ghostwriter.
Carefully inspect this image. Analyze every visual subtlety: the lighting temperature, architecture, atmospheric density, silent tensions, color spectrum, and environmental textures.

Based on this image, perform a two-fold task:
1. Deep Scene & Mood Analysis:
   - Identify the prevailing mood and tone.
   - Outline sensory triggers: auditory backdrop (ambient sounds), olfactory notes (scents), and tactile textures.
   - Identify visual focal points and environmental clues that hint at lore or backstory.
   - Synthesize a compelling historical or mystical world lore hook.

2. Ghostwrite the Opening Story Paragraph:
   - Genre: ${genre}
   - Tone: ${tone}
   - Point of View: ${pov}
   - Hook Style: ${hookType}
   ${userPrompt ? `- Custom Writer Request / Premise: "${userPrompt}"` : ''}

CRITICAL CRAFT REQUIREMENTS FOR THE OPENING PARAGRAPH:
- Ground the reader immediately into the physical sensory reality of the world depicted in the image.
- Avoid cliché openings (e.g., "The sun rose...", "It was a dark and stormy night...").
- Use active, visceral verbs, subtle internal tension, and evocative rhythm.
- Length: A substantial, immersive paragraph (approx 130 to 220 words) that captures imagination and begs to be continued.
- Also generate 2 distinct alternative opening variations (e.g. one action-leaning, one mystery/dialogue-leaning).
`;

    const textPart = { text: promptText };

    // Primary model: gemini-4-argon as specified in feature block, fallback: gemini-3.8-flash
    const { response, usedModel } = await generateWithFallback({
      primaryModel: 'gemini-4-argon',
      fallbackModel: 'gemini-3.8-flash',
      contents: { parts: [imagePart, textPart] },
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            storyTitle: { type: Type.STRING, description: 'Evocative, poetic title for the story world' },
            genre: { type: Type.STRING, description: 'Classified genre blend' },
            moodKeywords: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: '3 to 5 evocative mood descriptors (e.g. ["Nocturnal Melancholy", "Gothic Decadence"])',
            },
            sceneBreakdown: {
              type: Type.OBJECT,
              properties: {
                lightingAndAtmosphere: { type: Type.STRING, description: 'Visual lighting, mist, haze, color dynamics' },
                focalPoint: { type: Type.STRING, description: 'Primary focal subject or architectural mystery' },
                historicalEra: { type: Type.STRING, description: 'Implied era or epoch of the setting' },
                impliedConflict: { type: Type.STRING, description: 'The simmering tension or stakes present in the image' },
              },
              required: ['lightingAndAtmosphere', 'focalPoint', 'historicalEra', 'impliedConflict'],
            },
            sensoryPalette: {
              type: Type.OBJECT,
              properties: {
                sounds: { type: Type.ARRAY, items: { type: Type.STRING }, description: '2-3 ambient auditory details' },
                scents: { type: Type.ARRAY, items: { type: Type.STRING }, description: '2-3 environmental olfactory scents' },
                tactile: { type: Type.ARRAY, items: { type: Type.STRING }, description: '2-3 tactile physical sensations' },
              },
              required: ['sounds', 'scents', 'tactile'],
            },
            worldLore: { type: Type.STRING, description: 'A two-sentence captivating piece of secret world lore' },
            openingParagraph: { type: Type.STRING, description: 'The ghostwritten literary opening paragraph' },
            alternativeHooks: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  style: { type: Type.STRING, description: 'e.g. "Action Hook" or "Introspective Hook"' },
                  paragraph: { type: Type.STRING, description: 'Alternative opening paragraph' },
                },
                required: ['style', 'paragraph'],
              },
              description: '2 alternative opening paragraphs',
            },
          },
          required: [
            'storyTitle',
            'genre',
            'moodKeywords',
            'sceneBreakdown',
            'sensoryPalette',
            'worldLore',
            'openingParagraph',
            'alternativeHooks',
          ],
        },
      },
    });

    const parsedData = JSON.parse(response.text || '{}');
    res.json({
      success: true,
      data: parsedData,
      modelUsed: usedModel,
    });
  } catch (error: any) {
    console.error('Error in /api/analyze-and-write:', error);
    res.status(500).json({
      error: error.message || 'Failed to analyze image and generate story',
    });
  }
});

// 2. Text-to-Speech narration via gemini-3.8-flash-tts
app.post('/api/tts', async (req: Request, res: Response) => {
  try {
    const { text, voiceName = 'Kore', stylePrompt = 'Evocative, expressive audiobook narrator with dramatic pauses and rich emotional timbre' } = req.body;

    if (!text || typeof text !== 'string') {
      return res.status(400).json({ error: 'Text is required for TTS' });
    }

    // Limit text length to prevent excessively long audio requests (first ~1200 chars if huge)
    const cleanedText = text.trim().slice(0, 2000);

    const validVoices = ['Kore', 'Puck', 'Fenrir', 'Charon', 'Zephyr'];
    const selectedVoice = validVoices.includes(voiceName) ? voiceName : 'Kore';

    // gemini-3.8-flash-tts is specified for expressive voice narration
    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash-tts',
      contents: [
        {
          role: 'user',
          parts: [
            {
              text: cleanedText,
              speechMetadata: {
                style: stylePrompt,
              },
            },
          ],
        },
      ],
      config: {
        responseModalities: ['AUDIO'],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: selectedVoice },
          },
        },
      },
    });

    const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    if (!base64Audio) {
      throw new Error('No audio data returned from Gemini TTS model');
    }

    res.json({
      success: true,
      audioData: base64Audio,
      mimeType: 'audio/wav',
      voice: selectedVoice,
    });
  } catch (error: any) {
    console.error('Error in /api/tts:', error);
    res.status(500).json({
      error: error.message || 'Failed to generate speech audio',
    });
  }
});

// 3. Multi-turn Co-Author Ghostwriter Chat
app.post('/api/chat', async (req: Request, res: Response) => {
  try {
    const {
      messages,
      complexity = 'general', // 'complex' (gemini-4-argon), 'general' (gemini-3.8-flash), 'fast' (gemini-3.1-flash-lite)
      roleInstruction = '',
      storyContext = {},
    } = req.body;

    if (!messages || !Array.isArray(messages)) {
      return res.status(400).json({ error: 'Valid messages array is required' });
    }

    // Model selection based on requirements:
    // "Use gemini-4-argon for particularly complex tasks, gemini-3.8-flash for general tasks, and gemini-3.1-flash-lite for tasks that should happen fast."
    let modelName = 'gemini-3.8-flash';
    let fallbackModel = 'gemini-3.8-flash';

    if (complexity === 'complex') {
      modelName = 'gemini-4-argon';
      fallbackModel = 'gemini-3.8-flash';
    } else if (complexity === 'fast') {
      modelName = 'gemini-3.1-flash-lite';
      fallbackModel = 'gemini-3.8-flash';
    }

    const systemInstruction = `
You are the user's elite ghostwriting co-author, literary consultant, and creative worldbuilding partner.
${roleInstruction || 'Provide immersive creative expansions, dialogue polishing, story continuation, or critique.'}

ACTIVE STORY CONTEXT:
- Story Title: ${storyContext.storyTitle || 'Untitled Story'}
- Genre / Mood: ${storyContext.genre || 'Speculative'} | ${storyContext.mood || 'Atmospheric'}
- Current Story Opening:
"""${storyContext.currentStory || ''}"""
${storyContext.worldLore ? `- Known World Lore: ${storyContext.worldLore}` : ''}
${storyContext.sensoryPalette ? `- Sensory Palette: Sounds (${storyContext.sensoryPalette.sounds?.join(', ')}), Scents (${storyContext.sensoryPalette.scents?.join(', ')})` : ''}

CO-AUTHOR GUIDELINES:
1. Always maintain consistent tone, prose quality, and literary atmosphere.
2. If the user asks to continue the story, write the next 1-2 paragraphs seamlessly in high-fidelity literary prose.
3. If the user asks for suggestions, give 2-3 distinct, inventive options with brief rationale.
4. Provide structured, actionable assistance that inspires the writer.
`;

    // Map conversation history to Gemini contents format
    // Filter to last 12 messages for performance
    const historySlice = messages.slice(-12);
    const contents = historySlice.map((m: any) => ({
      role: m.role === 'assistant' || m.role === 'model' ? 'model' : 'user',
      parts: [{ text: m.text || m.content || '' }],
    }));

    const { response, usedModel } = await generateWithFallback({
      primaryModel: modelName,
      fallbackModel: fallbackModel,
      contents: contents,
      config: {
        systemInstruction: systemInstruction,
      },
    });

    res.json({
      success: true,
      message: response.text || '',
      modelUsed: usedModel,
    });
  } catch (error: any) {
    console.error('Error in /api/chat:', error);
    res.status(500).json({
      error: error.message || 'Failed to generate chat response',
    });
  }
});

// Setup Vite middleware in dev or static serving in production
async function startServer() {
  if (process.env.NODE_ENV === 'production') {
    // Serve static files from dist
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  } else {
    // Dynamically import Vite in development mode
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`✨ Aetheria Story Studio server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
