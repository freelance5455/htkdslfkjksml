import dotenv from 'dotenv';
import path from 'path';

// Load workspace .env with override: true so user project settings take precedence over container defaults
dotenv.config({ path: path.resolve(process.cwd(), '.env'), override: true });

import express from 'express';
import http from 'http';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import {
  generateSecureOtp,
  createOtpChallenge,
  refreshOtpChallenge,
  verifyOtpCode,
  checkIpRateLimit,
  checkEmailHourlyLimit,
  OTP_RESEND_COOLDOWN_MS,
  OTP_TTL_MS
} from './src/server/otpService';
import { sendOtpEmail, getEmailProviderStatus, refreshEnvironment } from './src/server/emailService';
import {
  createOrVerifyFirebaseUser,
  checkEmailVerificationStatus,
  getFirebaseAdmin
} from './src/server/adminAuthService';

const app = express();
const PORT = 3000;
const httpServer = http.createServer(app);

// Load container and workspace environment variables dynamically
refreshEnvironment();

app.use(express.json({ limit: '10mb' }));

// Initialize Admin SDK early
getFirebaseAdmin();

// Lazy initialization of Gemini client
let aiClient: GoogleGenAI | null = null;
function getAiClient(): GoogleGenAI | null {
  if (!aiClient && process.env.GEMINI_API_KEY) {
    try {
      aiClient = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
    } catch (err) {
      console.warn('Failed to initialize GoogleGenAI client:', err);
    }
  }
  return aiClient;
}

// Helper to sleep for backoff delays
const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

// Detect transient errors: HTTP 503 (overloaded/unavailable), 429 (rate-limit), 500, etc.
function isTransientError(error: any): boolean {
  if (!error) return false;

  const status = error.status || error.statusCode || error.response?.status || error.code || error.error?.code;
  const statusNum = typeof status === 'number' ? status : parseInt(String(status), 10);

  if (statusNum === 503 || statusNum === 429 || statusNum === 500 || statusNum === 502 || statusNum === 504) {
    return true;
  }

  let msg = '';
  try {
    msg = (typeof error === 'string' ? error : (error.message || JSON.stringify(error) || '')).toLowerCase();
  } catch {
    msg = String(error).toLowerCase();
  }

  return (
    msg.includes('503') ||
    msg.includes('unavailable') ||
    msg.includes('service unavailable') ||
    msg.includes('overloaded') ||
    msg.includes('high demand') ||
    msg.includes('spikes in demand') ||
    msg.includes('429') ||
    msg.includes('resource_exhausted') ||
    msg.includes('rate limit') ||
    msg.includes('too many requests') ||
    msg.includes('500') ||
    msg.includes('internal server error') ||
    msg.includes('fetch failed') ||
    msg.includes('econnreset') ||
    msg.includes('etimedout')
  );
}

// Health check endpoint
app.get('/api/health', (_req, res) => {
  res.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    geminiConfigured: Boolean(process.env.GEMINI_API_KEY)
  });
});

/**
 * ============================================================================
 * EMAIL OTP REGISTRATION & VERIFICATION API ROUTES
 * ============================================================================
 */

// Helper: Extract client IP safely behind reverse proxies
function getClientIp(req: express.Request): string {
  const forwarded = req.headers['x-forwarded-for'];
  if (typeof forwarded === 'string') {
    return forwarded.split(',')[0].trim();
  }
  if (Array.isArray(forwarded) && forwarded[0]) {
    return forwarded[0].trim();
  }
  return req.socket.remoteAddress || '127.0.0.1';
}

// 1. Diagnostics endpoint for email provider configuration status
app.get('/api/auth/email-otp/status', (_req, res) => {
  const status = getEmailProviderStatus();
  res.json({
    success: true,
    providerConfigured: status.configured,
    provider: status.providerName,
    senderAddress: status.senderAddress,
    missingConfig: status.missingKeys
  });
});

// 2. Start email OTP verification
app.post('/api/auth/email-otp/start', async (req, res) => {
  try {
    const { email, displayName } = req.body;

    // A. Validate email
    if (!email || typeof email !== 'string') {
      return res.status(400).json({ success: false, error: 'Email address is required.' });
    }

    const cleanEmail = email.trim().toLowerCase();
    const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+$/;
    if (cleanEmail.length > 254 || !emailRegex.test(cleanEmail)) {
      return res.status(400).json({ success: false, error: 'Please enter a valid email address.' });
    }

    const cleanName = typeof displayName === 'string' ? displayName.trim().slice(0, 100) : 'Job Aspirant';

    // B. Rate limit checks
    const clientIp = getClientIp(req);
    const ipCheck = checkIpRateLimit(clientIp);
    if (!ipCheck.allowed) {
      return res.status(429).json({
        success: false,
        error: `Too many requests from your IP. Please retry in ${ipCheck.retryAfterSeconds || 60} seconds.`
      });
    }

    const hourlyCheck = checkEmailHourlyLimit(cleanEmail);
    if (!hourlyCheck.allowed) {
      return res.status(429).json({
        success: false,
        error: 'Maximum OTP request limit reached (3 per hour). Please try again later.'
      });
    }

    // C. Check if already verified in Firebase Auth
    const status = await checkEmailVerificationStatus(cleanEmail);
    if (status.exists && status.verified) {
      return res.status(409).json({
        success: false,
        code: 'auth/email-already-in-use',
        error: 'This email address is already registered and verified. Please sign in.'
      });
    }

    // D. Generate cryptographically secure 6-digit OTP
    const otp = generateSecureOtp();

    // E. Create challenge in secure server-side HMAC store
    const { challenge } = createOtpChallenge(cleanEmail, cleanName, otp);

    // F. Send email via provider adapter
    const emailResult = await sendOtpEmail(cleanEmail, cleanName, otp);

    if (!emailResult.success) {
      // Do not claim email was sent when provider returned error
      const statusCode = emailResult.status || 502;
      return res.status(statusCode).json({
        success: false,
        error: emailResult.error || 'Failed to dispatch verification email.',
        missingConfig: emailResult.missingConfig
      });
    }

    // G. Return success response (NEVER return OTP code in response)
    return res.json({
      success: true,
      challengeId: challenge.challengeId,
      message: `A 6-digit verification code has been sent to ${cleanEmail}.`,
      resendCooldownSeconds: 60,
      expiresInSeconds: 600,
      provider: emailResult.provider,
      missingConfig: emailResult.missingConfig
    });
  } catch (err: any) {
    console.error('[OTP Start Error]:', err);
    return res.status(500).json({
      success: false,
      error: 'An internal error occurred while initiating verification. Please try again.'
    });
  }
});

// 3. Resend email OTP
app.post('/api/auth/email-otp/resend', async (req, res) => {
  try {
    const { challengeId, email } = req.body;

    if (!challengeId && !email) {
      return res.status(400).json({
        success: false,
        error: 'Challenge ID or email is required to resend verification code.'
      });
    }

    // Rate limit check on IP
    const clientIp = getClientIp(req);
    const ipCheck = checkIpRateLimit(clientIp);
    if (!ipCheck.allowed) {
      return res.status(429).json({
        success: false,
        error: `Too many requests from your IP. Please wait ${ipCheck.retryAfterSeconds}s.`
      });
    }

    // Generate new OTP
    const newOtp = generateSecureOtp();

    // Refresh challenge
    const refreshResult = refreshOtpChallenge({ challengeId, email }, newOtp);
    if (!refreshResult.success || !refreshResult.challenge) {
      return res.status(400).json({
        success: false,
        error: refreshResult.error || 'Failed to refresh verification challenge.',
        retryAfterSeconds: refreshResult.retryAfterSeconds
      });
    }

    const challenge = refreshResult.challenge;

    // Send email
    const emailResult = await sendOtpEmail(challenge.email, challenge.displayName, newOtp);
    if (!emailResult.success) {
      const statusCode = emailResult.status || 502;
      return res.status(statusCode).json({
        success: false,
        error: emailResult.error || 'Failed to resend verification email.',
        missingConfig: emailResult.missingConfig
      });
    }

    return res.json({
      success: true,
      challengeId: challenge.challengeId,
      message: `A new 6-digit verification code was sent to ${challenge.email}.`,
      resendCooldownSeconds: 60,
      expiresInSeconds: 600,
      provider: emailResult.provider
    });
  } catch (err: any) {
    console.error('[OTP Resend Error]:', err);
    return res.status(500).json({
      success: false,
      error: 'An unexpected error occurred while resending the code.'
    });
  }
});

// 4. Verify OTP and complete registration
app.post('/api/auth/email-otp/verify', async (req, res) => {
  try {
    const { email, otp, password, displayName, challengeId } = req.body;

    // Validate inputs
    if (!email || typeof email !== 'string') {
      return res.status(400).json({ success: false, error: 'Email address is required.' });
    }
    const cleanEmail = email.trim().toLowerCase();

    if (!otp || typeof otp !== 'string' || !/^\d{6}$/.test(otp.trim())) {
      return res.status(400).json({ success: false, error: 'Please enter a valid 6-digit verification code.' });
    }

    if (!password || typeof password !== 'string' || password.length < 6) {
      return res.status(400).json({
        success: false,
        error: 'Password must be at least 6 characters long.'
      });
    }

    // Rate limit check on IP
    const clientIp = getClientIp(req);
    const ipCheck = checkIpRateLimit(clientIp);
    if (!ipCheck.allowed) {
      return res.status(429).json({
        success: false,
        error: `Too many attempts from this IP. Please wait ${ipCheck.retryAfterSeconds}s.`
      });
    }

    // Atomically verify code against HMAC challenge
    const verification = verifyOtpCode({ challengeId, email: cleanEmail }, otp);
    if (!verification.success) {
      return res.status(400).json({
        success: false,
        error: verification.error || 'Invalid or expired verification code.',
        attemptsRemaining: verification.attemptsRemaining
      });
    }

    const userName = displayName || verification.challenge?.displayName || 'Job Aspirant';

    // Verification succeeded! Now create or update the user in Firebase Authentication with emailVerified: true
    try {
      const userResult = await createOrVerifyFirebaseUser(cleanEmail, password, userName);

      return res.json({
        success: true,
        message: 'Email verified successfully! Account is ready.',
        user: {
          uid: userResult.uid,
          email: userResult.email,
          displayName: userResult.displayName,
          emailVerified: true,
          isExistingUnverifiedUpdated: Boolean(userResult.isExistingUnverifiedUpdated)
        }
      });
    } catch (authErr: any) {
      console.error('[Firebase User Creation Error]:', authErr);
      const msg = authErr.message || 'Failed to create user in Firebase Authentication.';
      return res.status(400).json({
        success: false,
        code: authErr.code || 'auth/creation-failed',
        error: msg
      });
    }
  } catch (err: any) {
    console.error('[OTP Verify Error]:', err);
    return res.status(500).json({
      success: false,
      error: 'An unexpected error occurred during verification.'
    });
  }
});

// Conversational AI Job Assistant API route
app.post('/api/ai-chat', async (req, res) => {
  const { message, history, context, availableJobs } = req.body;

  if (!message || typeof message !== 'string') {
    return res.status(400).json({ error: 'Message is required' });
  }

  const ai = getAiClient();
  if (!ai) {
    // If GEMINI_API_KEY is not configured, inform client to use local conversational engine
    return res.json({
      fallbackToLocal: true,
      reason: 'GEMINI_API_KEY not configured on server'
    });
  }

  try {
    // Build a compact representation of actual active jobs in database (no hallucinated data!)
    const compactJobsList = Array.isArray(availableJobs)
      ? availableJobs.slice(0, 25).map((j: any) => ({
          id: j.id,
          title: j.title,
          organization: j.organization,
          sector: j.sector,
          state: j.state,
          district: j.district,
          qualification: j.qualification,
          vacancies: j.vacancies,
          salary: j.salary,
          closingDate: j.closingDate || j.lastDate,
          category: j.category
        }))
      : [];

    const systemInstruction = `You are the AI Job Assistant for "India Job Hub", an official government and private jobs portal in India.

CORE PERSONALITY & PRINCIPLES:
1. NATURAL CONVERSATION FIRST:
   - You are a friendly, knowledgeable, conversational assistant.
   - For simple greetings ("Hi", "Hello", "Good morning", "Shuvo shokal", "Namaste"), casual wellbeing ("How are you?", "Kemon acho?"), gratitude ("Thanks", "Dhonnobad"), or farewells: Respond warmly, politely, and naturally.
   - NEVER dump or search jobs for casual greetings.
   - NEVER say "I couldn't find an exact match" for greetings or normal conversational remarks.

2. MULTI-LINGUAL SUPPORT:
   - Understand and respond fluently in English, Bengali (বাংলা), Hinglish, Banglish, or simple mixed language as requested by the user.
   - For Bengali or Banglish queries (e.g. "amar jonno kon job ache?", "ami graduate, west bengal e job chai", "bhai amar jonno ekta valo job khuje dao", "ei job ta ami apply korte parbo?"), respond in warm, natural Bengali or Banglish matching their tone.

3. UNDERSTAND INTENT & CONTEXT MEMORY:
   - Understand the user's intent: greeting, casual conversation, broad job inquiry, specific job search, eligibility evaluation, deadline/salary check, interview prep, resume advice, exam syllabus guidance.
   - Maintain context across the conversation (e.g., if user said they are a Graduate or live in West Bengal, remember it without asking them to repeat).
   - If user makes a very broad request (e.g. "job chai", "need a job", "ekta job lagbe"), do NOT immediately dump a huge list of jobs! Ask a helpful follow-up question (sector, qualification, preferred state).

4. STRICT ZERO-HALLUCINATION FOR JOB DATA:
   - You MUST ONLY reference jobs from the provided ACTIVE JOBS LIST below.
   - NEVER invent job names, organizations, vacancies, salaries, deadlines, qualifications, or application links.
   - If user asks for something not in the list, state politely and naturally that no active opening currently matches those exact criteria, and suggest adjusting filters or setting an alert.

5. ELIGIBILITY EVALUATION:
   - When asked "ami eligible?" or "can I apply?", analyze the user's provided qualification, age, and location against the job criteria.
   - Format clearly:
     ✅ Requirements you appear to meet
     ⚠️ Specific points needing verification (e.g. stream specialization, cut-off date)
     ⚖️ Official disclaimer: State that the official recruitment notification / gazette is the final legal authority.

6. GENERAL CAREER & RECRUITMENT QUESTIONS:
   - Answer questions about interview prep, resume writing, competitive exam strategies (UPSC, SSC, RRB, Banking) thoroughly and helpfully using your general knowledge without needing to force job search results.

ACTIVE JOBS IN DATABASE (ONLY USE THESE):
${JSON.stringify(compactJobsList, null, 2)}

CURRENT USER CONTEXT:
${JSON.stringify(context || {}, null, 2)}

OUTPUT FORMAT:
Respond with a valid JSON object with the following structure:
{
  "responseText": "Your friendly conversational reply formatted with markdown paragraphs, bullet points, and helpful emojis.",
  "matchedJobIds": ["array of matching job IDs from the ACTIVE JOBS LIST, or empty array if none or if the query was conversational"],
  "suggestedFollowUps": ["3 to 4 short, relevant follow-up prompts for the user"],
  "isDisclaimer": true or false (true if showing jobs or eligibility analysis)
}`;

    // Convert past history to contents
    const contents: any[] = [];
    if (Array.isArray(history)) {
      for (const h of history.slice(-6)) {
        contents.push({
          role: h.role === 'assistant' ? 'model' : 'user',
          parts: [{ text: h.content }]
        });
      }
    }
    contents.push({
      role: 'user',
      parts: [{ text: message }]
    });

    // Retry loop with exponential backoff for transient failures (HTTP 503, 429, 500, network errors)
    // Supports multi-model failover across valid Gemini models if a specific model encounters high demand
    const CANDIDATE_MODELS = ['gemini-3.8-flash', 'gemini-3.1-flash-lite', 'gemini-flash-latest'];
    const BACKOFF_DELAYS = [1000, 2000, 4000]; // 1s, 2s, 4s exponential backoff
    const MAX_RETRIES = 3;
    let response: any = null;

    for (let attempt = 0; attempt <= MAX_RETRIES; attempt++) {
      const activeModel = CANDIDATE_MODELS[attempt % CANDIDATE_MODELS.length];

      try {
        if (attempt > 0) {
          const delayMs = BACKOFF_DELAYS[attempt - 1] || 4000;
          console.log(`[AI Assistant] Temporary high-demand condition encountered. Retrying in ${delayMs}ms (attempt ${attempt}/${MAX_RETRIES})...`);
          await sleep(delayMs);
        }

        response = await ai.models.generateContent({
          model: activeModel,
          contents,
          config: {
            systemInstruction,
            temperature: 0.7,
            responseMimeType: 'application/json'
          }
        });

        break; // Successfully received response
      } catch (err: any) {
        const transient = isTransientError(err);
        console.log(`[AI Assistant] Attempt ${attempt + 1}/${MAX_RETRIES + 1} transient status: ${transient}`);

        // If error is not transient or we have reached max retries, stop
        if (!transient || attempt >= MAX_RETRIES) {
          break;
        }
      }
    }

    // If all retries fail or service is unavailable, return friendly fallback
    if (!response) {
      console.log('[AI Assistant] All retries completed. Returning friendly service notice.');
      return res.json({
        success: false,
        isServiceUnavailable: true,
        responseText: "Sorry! 😅 I'm having a little trouble connecting to my AI service right now. Please try again in a moment. Your jobs and other India Job Hub features are still available.",
        matchedJobIds: [],
        suggestedFollowUps: [
          'Try again in a moment',
          'Find government jobs',
          'Show jobs closing soon',
          'Jobs in West Bengal'
        ],
        isDisclaimer: false
      });
    }

    const textOutput = response.text || '';
    try {
      const parsed = JSON.parse(textOutput);
      return res.json({
        success: true,
        responseText: parsed.responseText || textOutput,
        matchedJobIds: parsed.matchedJobIds || [],
        suggestedFollowUps: parsed.suggestedFollowUps || [],
        isDisclaimer: Boolean(parsed.isDisclaimer)
      });
    } catch {
      return res.json({
        success: true,
        responseText: textOutput,
        matchedJobIds: [],
        suggestedFollowUps: ['Find government jobs', 'Jobs closing soon'],
        isDisclaimer: false
      });
    }
  } catch (error: any) {
    console.log('[AI Assistant] Handled exception in /api/ai-chat handler (status:', error?.status || 'transient', ')');
    // Return friendly message without exposing raw error or crashing server
    return res.json({
      success: false,
      isServiceUnavailable: true,
      responseText: "Sorry! 😅 I'm having a little trouble connecting to my AI service right now. Please try again in a moment. Your jobs and other India Job Hub features are still available.",
      matchedJobIds: [],
      suggestedFollowUps: [
        'Try again in a moment',
        'Find government jobs',
        'Show jobs closing soon'
      ],
      isDisclaimer: false
    });
  }
});

// Vite middleware setup
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: {
          server: httpServer
        }
      },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  httpServer.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on port ${PORT}`);
  });
}

startServer();
