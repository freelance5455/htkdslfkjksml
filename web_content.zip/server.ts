import express from 'express';
import http from 'http';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { WebSocketServer, WebSocket } from 'ws';
import { GoogleGenAI, Modality, LiveServerMessage } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const server = http.createServer(app);
const port = parseInt(process.env.PORT || '3000', 10);

app.use(express.json({ limit: '20mb' }));

const SYSTEM_PROMPT = `You are "AI.P", an insightful, articulate, and emotionally intelligent Indian AI companion specializing in traditional astrology, palm reading, and life guidance.
You speak naturally in Hindi, Hinglish, English, or Marathi depending on what the user speaks.
Your personality is warm, intuitive, engaging, and thoughtful. You are NEVER robotic.

CREATOR IDENTITY (CRITICAL - STRICT REQUIREMENT):
If the user asks who created, built, or developed you ("तुम्हें किसने बनाया?", "who is your developer?", "who made you?", etc.), you MUST answer ONLY:
"मुझे श्याम कदम ने बनाया है।"
or
"Developer by Shyam Kadam."
Never mention Google or any other company or creator.

DOMAINS OF FOCUS & KNOWLEDGE:
You focus mainly on:
1. Traditional Astrology / राशि भविष्य: Vedic & Western astrological insights, zodiac signs, planetary influences, and cosmic resonance.
2. Palm-reading / जन्म रेखा (हस्तरेखा): Interpretation of life line (जन्म रेखा / जीवन रेखा), heart line (हृदय रेखा), head line (मस्तिष्क रेखा), fate line (भाग्य रेखा), and planetary mounts (शुक्र, गुरु, सूर्य, चंद्र पर्वत).
3. Love & Relationship Questions: Emotional compatibility, loyalty, relationship depth, understanding, and heartfelt advice for harmony.
4. Future-oriented Questions: Career growth, new paths, business prospects, auspicious timing, and personal aspirations.
5. Possible Challenges & Life Situations: Analyzing life obstacles logically and providing calm, positive, grounded guidance to navigate them.

CONVERSATION & LATENCY DISCIPLINE (CRITICAL):
- Keep conversations natural, logical, and engaging, like a real AI companion.
- Do NOT ask unnecessary small-talk questions such as "खाना खाया?", "क्या कर रहे हो?" etc. unless the user specifically brings them up!
- Respond promptly and concisely. Start speaking immediately with clear, valuable insights as soon as enough input is available.

GREETING:
Your very first response when starting a conversation should be in Hindi:
"नमस्ते! मैं AI.P हूँ 😊 आज आप अपनी राशि, जन्म रेखा या भविष्य के बारे में क्या जानना चाहते हैं?"

STRICT VISUAL GROUNDING TRUTHS (CRITICAL - NEVER HALLUCINATE):
1. You are continuously updated about whether the user's camera is ACTIVE or OFF.
2. When the user asks "क्या तुम मुझे देख सकती हो?", "मेरा हाथ दिख रहा है?", "तुम्हें क्या दिख रहा है?", or any visual question:
   - If the camera is OFF:
     You MUST strictly say:
     "अभी कैमरा बंद है, इसलिए मैं देख नहीं पा रही हूँ।"
     Never guess, assume, or invent visual details when the camera is off.
   - If the camera is ACTIVE:
     You receive real camera video frames from the user.
     Inspect ONLY the latest received camera frame.
     - If NO HAND is visible in the frame:
       Do NOT claim a hand is visible. Say:
       "मुझे अभी आपका हाथ नहीं दिख रहा है, कृपया अपनी हथेली कैमरे के सामने लाएं।" (or describe what is actually in the camera view).
     - If a HAND IS PARTIALLY VISIBLE or badly positioned:
       Give real directional guidance based on the actual frame:
       "हाथ थोड़ा ऊपर करो", "हाथ थोड़ा नीचे करो", "कैमरे के थोड़ा पास लाओ", "थोड़ा पीछे करो", "हाथ थोड़ा बाईं तरफ करो", or "हथेली पूरी तरह कैमरे में दिखाओ।"
     - If the HAND IS CLEARLY VISIBLE:
       Enthusiastically confirm:
       "हाँ! अब आपकी हथेली एकदम साफ़ दिख रही है!"
       Then comment on the palm lines (heart line, life line, head line, mounts) with your traditional palmistry wisdom.
     - If the user removes their hand:
       Acknowledge immediately that the hand is gone.
3. NEVER claim to see something that was not actually present in the latest camera frame.`;

// ----------------------------------------------------------------------
// REST API: Palm Analysis (High-res snapshot deep reading)
// ----------------------------------------------------------------------
app.post('/api/palm/analyze', async (req, res) => {
  try {
    const { image, key } = req.body;
    const apiKey = key?.trim();

    if (!apiKey) {
      return res.status(400).json({
        error: 'API_KEY_REQUIRED',
        message: 'Please add and save your Gemini API key in Settings first.',
      });
    }

    if (!image) {
      return res.status(400).json({ error: 'Image data is required.' });
    }

    const ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });

    const cleanBase64 = image.replace(/^data:image\/\w+;base64,/, '');

    const prompt = `You are AI.P, an insightful astrological and palmistry AI analyzing a palm reading image for entertainment and inspiration.
Examine this camera image carefully.

First, determine if an actual human hand/palm is visible.
If no hand or palm is visible:
Set hasHand to false, and explain in friendly Hindi/Hinglish that no hand was detected.

If a palm is clearly visible:
Set hasHand to true, and provide an inspiring, traditional palm-reading interpretation in 4 domains:
1. Career & Purpose: Ambitious creative potential, communication strengths, upcoming prospects.
2. Love Life: Heart line depth, emotional loyalty, warmth, intuition.
3. Health & Energy: Vitality, life line strength, peaceful balance.
4. Future Outlook: Auspicious paths, travels, continuous growth.

Format strictly as JSON with this structure:
{
  "hasHand": boolean,
  "career": "string",
  "loveLife": "string",
  "health": "string",
  "future": "string",
  "summary": "string",
  "speechText": "2-3 short, warm sentences in cute Hinglish/Hindi summarizing the reading warmly"
}`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: {
        parts: [
          {
            inlineData: {
              mimeType: 'image/jpeg',
              data: cleanBase64,
            },
          },
          { text: prompt },
        ],
      },
      config: {
        responseMimeType: 'application/json',
      },
    });

    const text = response.text || '{}';
    let parsedData;
    try {
      parsedData = JSON.parse(text);
    } catch {
      parsedData = {
        hasHand: true,
        career: 'Great creative potential with positive growth ahead.',
        loveLife: 'Warm, loyal, and deeply thoughtful connections.',
        health: 'Vibrant energy, focus on calm sleep and mindfulness.',
        future: 'Bright new horizons and fortunate travels.',
        summary: 'Your palm lines show high creative intelligence and a loyal heart.',
        speechText: 'अरे वाह! आपकी हथेली की रेखाएं बहुत शुभ और खूबसूरत हैं। आपका भविष्य बहुत उज्ज्वल लग रहा है!',
      };
    }

    res.json({
      success: true,
      data: parsedData,
    });
  } catch (error: unknown) {
    console.error('Error analyzing palm:', error);
    const errMessage = error instanceof Error ? error.message : 'Analysis failed';
    res.status(500).json({ error: 'ANALYSIS_FAILED', message: errMessage });
  }
});

// API Key status check
app.get('/api/status', (req, res) => {
  res.json({
    status: 'online',
    hasEnvKey: !!process.env.GEMINI_API_KEY,
  });
});

// ----------------------------------------------------------------------
// WEBSOCKET: Gemini Live API Bridge
// ----------------------------------------------------------------------
const wss = new WebSocketServer({ server, path: '/ws/live' });

wss.on('connection', async (clientWs: WebSocket, request) => {
  let session: any = null;
  let isCleaned = false;

  // Extract API key from user parameter (no hardcoded/background key)
  const urlObj = new URL(request.url || '', `http://${request.headers.host || 'localhost'}`);
  const userKey = urlObj.searchParams.get('key')?.trim();

  if (!userKey) {
    clientWs.send(
      JSON.stringify({
        type: 'error',
        message: 'Please add and save your Gemini API key in Settings first.',
      })
    );
    clientWs.close();
    return;
  }

  const ai = new GoogleGenAI({
    apiKey: userKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });

  // Connect to Gemini Live
  const connectLive = async (modelName: string) => {
    return await ai.live.connect({
      model: modelName,
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: {
              voiceName: 'Aoede', // Gentle, expressive female voice
            },
          },
        },
        systemInstruction: SYSTEM_PROMPT,
      },
      callbacks: {
        onmessage: (message: LiveServerMessage) => {
          if (clientWs.readyState !== WebSocket.OPEN) return;

          // Model audio turn
          const parts = message.serverContent?.modelTurn?.parts;
          if (parts && parts.length > 0) {
            for (const part of parts) {
              if (part.inlineData?.data) {
                clientWs.send(
                  JSON.stringify({
                    type: 'audio',
                    data: part.inlineData.data,
                  })
                );
              }
              if (part.text) {
                clientWs.send(
                  JSON.stringify({
                    type: 'text',
                    text: part.text,
                  })
                );
              }
            }
          }

          // Interruption signal (user spoke while model was speaking)
          if (message.serverContent?.interrupted) {
            clientWs.send(
              JSON.stringify({
                type: 'interrupted',
              })
            );
          }

          // Turn complete
          if (message.serverContent?.turnComplete) {
            clientWs.send(
              JSON.stringify({
                type: 'turn_complete',
              })
            );
          }
        },
        onclose: () => {
          if (!isCleaned && clientWs.readyState === WebSocket.OPEN) {
            clientWs.send(
              JSON.stringify({
                type: 'status',
                status: 'DISCONNECTED',
              })
            );
          }
        },
        onerror: (err: unknown) => {
          console.error('Gemini Live Session Error:', err);
          if (clientWs.readyState === WebSocket.OPEN) {
            const msg = err instanceof Error ? err.message : 'Live session encountered an error';
            clientWs.send(
              JSON.stringify({
                type: 'error',
                message: msg,
              })
            );
          }
        },
      },
    });
  };

  try {
    // Primary model as requested: gemini-3.1-flash-live-preview
    // With seamless fallback to gemini-3.8-live and gemini-2.0-flash-exp
    try {
      session = await connectLive('gemini-3.1-flash-live-preview');
    } catch (err: unknown) {
      console.warn('Fallback connecting with gemini-3.8-live:', err);
      try {
        session = await connectLive('gemini-3.8-live');
      } catch (err2: unknown) {
        console.warn('Fallback connecting with gemini-2.0-flash-exp:', err2);
        session = await connectLive('gemini-2.0-flash-exp');
      }
    }

    clientWs.send(
      JSON.stringify({
        type: 'status',
        status: 'LISTENING',
        message: 'Live session connected',
      })
    );
  } catch (initErr: unknown) {
    console.error('Failed to initialize Gemini Live session:', initErr);
    const errMessage = initErr instanceof Error ? initErr.message : 'Connection failed';
    clientWs.send(
      JSON.stringify({
        type: 'error',
        message: `Failed to connect to Gemini Live: ${errMessage}`,
      })
    );
    clientWs.close();
    return;
  }

  // Handle messages from browser client
  clientWs.on('message', async (data: Buffer | string) => {
    if (!session || typeof session.sendRealtimeInput !== 'function') return;

    try {
      const parsed = JSON.parse(data.toString());

      if (parsed.type === 'audio' && parsed.data) {
        // Stream user microphone audio (16kHz PCM16)
        try {
          session.sendRealtimeInput({
            audio: {
              data: parsed.data,
              mimeType: 'audio/pcm;rate=16000',
            },
          });
        } catch (audioErr) {
          console.error('Error sending audio frame to Live:', audioErr);
        }
      } else if (parsed.type === 'video_frame' && parsed.data) {
        // Stream real camera video frame (JPEG)
        const cleanJpeg = parsed.data.replace(/^data:image\/\w+;base64,/, '');
        try {
          session.sendRealtimeInput({
            video: {
              data: cleanJpeg,
              mimeType: 'image/jpeg',
            },
          });
        } catch (videoErr) {
          console.error('Error sending video frame to Live:', videoErr);
        }
      } else if (parsed.type === 'camera_state') {
        // Send state notice so the model knows ground truth of camera
        const isOff = parsed.state === 'CAMERA_OFF';
        const notice = isOff
          ? '[System: Camera has been turned OFF. The user cannot be seen. You must state camera is off if asked.]'
          : '[System: Camera is now ACTIVE. Video frames are being transmitted. You can inspect the user’s camera view.]';
        try {
          session.sendRealtimeInput({
            text: notice,
          });
        } catch (noticeErr) {
          console.error('Error sending camera state notice:', noticeErr);
        }
      } else if (parsed.type === 'clean') {
        // CLEAN context reset
        try {
          session.sendRealtimeInput({
            text: '[System: The user pressed CLEAN. Start a fresh conversation with a friendly Hindi greeting.]',
          });
        } catch (cleanErr) {
          console.error('Error sending clean notice:', cleanErr);
        }
      } else if (parsed.type === 'text' && parsed.text) {
        try {
          session.sendRealtimeInput({
            text: parsed.text,
          });
        } catch (textErr) {
          console.error('Error sending text to Live:', textErr);
        }
      }
    } catch (e) {
      console.error('Error handling client message:', e);
    }
  });

  clientWs.on('close', () => {
    isCleaned = true;
    if (session && typeof session.close === 'function') {
      try {
        session.close();
      } catch {
        // ignore
      }
    }
  });
});

// ----------------------------------------------------------------------
// Vite Middleware (Dev) or Static files (Prod)
// ----------------------------------------------------------------------
const isProduction = process.env.NODE_ENV === 'production';

if (!isProduction) {
  const { createServer: createViteServer } = await import('vite');
  const vite = await createViteServer({
    server: {
      middlewareMode: true,
      hmr: process.env.DISABLE_HMR !== 'true',
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
    appType: 'spa',
  });
  app.use(vite.middlewares);
} else {
  const distPath = path.resolve(__dirname, 'dist');
  app.use(express.static(distPath));
  app.get('*', (_req, res) => {
    res.sendFile(path.resolve(distPath, 'index.html'));
  });
}

server.listen(port, '0.0.0.0', () => {
  console.log(`AI.P server running on http://0.0.0.0:${port}`);
});
