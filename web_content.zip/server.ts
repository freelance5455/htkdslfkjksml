import 'dotenv/config';
import express, { NextFunction, Request, Response } from 'express';
import fs from 'node:fs';
import path from 'node:path';
import { createServer as createViteServer } from 'vite';
import {
  CocApiError,
  clearApiCache,
  getActiveSecretName,
  getCacheStats,
  getCapitalRaidSeasonsOfficial,
  getClanByTagOfficial,
  getClanMembersOfficial,
  getCurrentWarOfficial,
  getPlayerByTagOfficial,
  getSecretCandidates,
  getWarLogOfficial,
  hasValidServerCocToken,
  loadClanFromSupercellApi,
  searchClansOfficial,
  testSupercellApiConnection,
  validateCocTag,
} from './server/supercellCocApi.ts';
import {
  ActiveBuilder,
  ActiveUpgradeEntry,
  CapitalRaidSeason,
  ClanDashboardState,
  ClanEvent,
  ClanInfo,
  ClanSnapshot,
  ClanWarEntry,
  CurrentWarInfo,
  CwlGroupInfo,
  HistoryPoint,
  JsonObjectSnapshotEntry,
  PlayerCombatStats,
  PlayerJsonVillageState,
  PlayerProfile,
  SyncConfig,
  SyncProgressInfo,
  SyncRunSummary,
  UpgradeEvent,
  VILLAGE_ENTITIES,
  VillageCategory,
  VillageId,
  calculatePlayerProgress,
  computeClanAggregateStats,
  getCapForTh,
  getWallCapForTh,
  groupPlayersByTownHall,
  parseSupercellVillageJson,
} from './src/shared/cocData.ts';
import { parseFullSupercellExportJson } from './src/shared/cocExportCatalog.ts';

interface PersistedStore {
  clan: ClanInfo | null;
  players: PlayerProfile[];
  events: UpgradeEvent[];
  activeUpgrades: ActiveUpgradeEntry[];
  clanEvents: ClanEvent[];
  history: HistoryPoint[];
  snapshots: ClanSnapshot[];
  wars: ClanWarEntry[];
  currentWar: CurrentWarInfo | null;
  cwl: CwlGroupInfo | null;
  capitalRaids: CapitalRaidSeason[];
  syncConfig: SyncConfig;
}

const DATA_DIR = path.resolve(process.cwd(), 'data');
const STORE_PATH = path.join(DATA_DIR, 'clan-store.json');

function defaultSyncConfig(): SyncConfig {
  return {
    autoSyncEnabled: true,
    intervalMinutes: 360,
    lastSyncAt: null,
    lastSyncStatus: 'idle',
    lastSyncError: null,
  };
}

function createEmptyStore(): PersistedStore {
  return {
    clan: null,
    players: [],
    events: [],
    activeUpgrades: [],
    clanEvents: [],
    history: [],
    snapshots: [],
    wars: [],
    currentWar: null,
    cwl: null,
    capitalRaids: [],
    syncConfig: defaultSyncConfig(),
  };
}

function emptyCombatStats(): PlayerCombatStats {
  return {
    attacksWon: 0,
    defensesWon: 0,
    warAttacksUsed: 0,
    warStarsEarned: 0,
    warThreeStars: 0,
    warAvgDestruction: 0,
    warDefensesFaced: 0,
    warStarsConceded: 0,
    warDefenseHoldRate: 0,
  };
}

let store: PersistedStore = loadOrInitStore();
const sseClients = new Set<Response>();
let syncInFlight: Promise<{ state: ClanDashboardState; summary: SyncRunSummary }> | null = null;
let currentSyncProgress: SyncProgressInfo = {
  inProgress: false,
  stage: 'idle',
  statusText: 'Ожидание проверки',
  checkedMembers: 0,
  totalMembers: 0,
  upgradesFound: 0,
  errorsCount: 0,
  lastError: null,
};

function loadOrInitStore(): PersistedStore {
  try {
    if (fs.existsSync(STORE_PATH)) {
      const raw = fs.readFileSync(STORE_PATH, 'utf-8');
      const parsed = JSON.parse(raw) as Partial<PersistedStore> & {
        clan?: (ClanInfo & { isDemo?: boolean }) | null;
      };
      if (parsed && parsed.clan) {
        if (parsed.clan.isDemo || parsed.clan.tag === '#2QG8Y9VPL') {
          const empty = createEmptyStore();
          saveStore(empty);
          return empty;
        }
        return {
          clan: parsed.clan,
          players: Array.isArray(parsed.players) ? parsed.players : [],
          events: Array.isArray(parsed.events) ? parsed.events : [],
          activeUpgrades: Array.isArray(parsed.activeUpgrades) ? parsed.activeUpgrades : [],
          clanEvents: Array.isArray(parsed.clanEvents) ? parsed.clanEvents : [],
          history: Array.isArray(parsed.history) ? parsed.history : [],
          snapshots: Array.isArray(parsed.snapshots) ? parsed.snapshots : [],
          wars: Array.isArray(parsed.wars) ? parsed.wars : [],
          currentWar: parsed.currentWar ?? null,
          cwl: parsed.cwl ?? null,
          capitalRaids: Array.isArray(parsed.capitalRaids) ? parsed.capitalRaids : [],
          syncConfig: {
            ...defaultSyncConfig(),
            ...(parsed.syncConfig ?? {}),
          },
        };
      }
      if (parsed && parsed.syncConfig) {
        const loadedInterval = parsed.syncConfig.intervalMinutes;
        return {
          ...createEmptyStore(),
          syncConfig: {
            ...defaultSyncConfig(),
            ...parsed.syncConfig,
            intervalMinutes: loadedInterval === 15 ? 360 : (loadedInterval ?? 360),
          },
        };
      }
    }
  } catch (err) {
    console.warn('Could not read persisted clan store, starting clean:', err);
  }
  const initial = createEmptyStore();
  saveStore(initial);
  return initial;
}

function saveStore(next: PersistedStore) {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    const tmpPath = `${STORE_PATH}.tmp`;
    fs.writeFileSync(tmpPath, JSON.stringify(next, null, 2), 'utf-8');
    fs.renameSync(tmpPath, STORE_PATH);
  } catch {
    // Non-fatal on read-only FS
  }
}

function getFullState(): ClanDashboardState {
  const thGroups = groupPlayersByTownHall(store.players, store.events);
  const clanStats = computeClanAggregateStats(store.players, store.wars);
  const cacheStats = getCacheStats();
  return {
    clan: store.clan,
    players: store.players,
    events: store.events.slice(0, 5000),
    activeUpgrades: (store.activeUpgrades ?? []).slice(0, 300),
    clanEvents: store.clanEvents.slice(0, 500),
    history: store.history,
    snapshots: store.snapshots,
    wars: store.wars,
    currentWar: store.currentWar,
    cwl: store.cwl,
    capitalRaids: store.capitalRaids,
    clanStats,
    thGroups,
    hasApiToken: hasValidServerCocToken(),
    syncConfig: {
      ...store.syncConfig,
      cacheEntriesCount: cacheStats.entries,
      cacheTtlSeconds: cacheStats.ttlSeconds,
    },
  };
}

function broadcastSse(eventName: string, payload: unknown) {
  const data = `event: ${eventName}\ndata: ${JSON.stringify(payload)}\n\n`;
  for (const res of sseClients) {
    try {
      res.write(data);
    } catch {
      sseClients.delete(res);
    }
  }
}

function sendCocError(res: Response, err: unknown, fallbackMessage: string) {
  if (err instanceof CocApiError) {
    res.status(err.statusCode).json({
      error: err.message,
      statusCode: err.statusCode,
      reason: err.reason,
    });
    return;
  }
  res.status(500).json({
    error: err instanceof Error ? err.message : fallbackMessage,
    statusCode: 500,
  });
}

async function performClanSync(
  rawTag: string,
  options?: { bypassCache?: boolean; reason?: string }
): Promise<{ state: ClanDashboardState; summary: SyncRunSummary }> {
  if (syncInFlight) {
    return syncInFlight;
  }

  syncInFlight = (async () => {
    const startedAt = new Date().toISOString();
    const updateProgress = (partial: Partial<SyncProgressInfo>) => {
      currentSyncProgress = {
        ...currentSyncProgress,
        ...partial,
      };
      broadcastSse('sync_progress', currentSyncProgress);
    };

    updateProgress({
      inProgress: true,
      stage: 'fetching_clan',
      statusText: 'Подключение к Supercell API...',
      checkedMembers: 0,
      totalMembers: store.players.length,
      upgradesFound: 0,
      errorsCount: 0,
      startedAt,
      completedAt: undefined,
      lastError: null,
    });

    try {
      const existingMap = new Map<string, PlayerProfile>(
        store.players.map((p) => [p.tag, p])
      );
      const realData = await loadClanFromSupercellApi(
        rawTag,
        existingMap,
        store.history,
        store.snapshots,
        store.clan?.tag ?? null,
        store.events,
        store.clanEvents,
        store.wars,
        Boolean(options?.bypassCache),
        (p) => updateProgress({ ...p, inProgress: true }),
        store.clan
      );

      // Reconcile existing activeUpgrades against fresh Supercell API levels
      const isSameClanSync = store.clan?.tag === realData.clan.tag;
      const freshPlayerByTag = new Map(realData.players.map((p) => [p.tag, p]));
      const reconciledActive: ActiveUpgradeEntry[] = isSameClanSync
        ? (store.activeUpgrades ?? []).map((au) => {
            if (au.status === 'completed') return au;
            const fp = freshPlayerByTag.get(au.playerTag);
            if (!fp) return au;

            let apiCurLevel: number | null = null;
            if (au.detailType === 'townhall' && au.village === 'home') {
              apiCurLevel = fp.townHallLevel;
            } else if (au.detailType === 'townhall' && au.village === 'builderBase') {
              apiCurLevel = fp.builderHallLevel;
            } else {
              const allApiUnits = [
                ...fp.apiHeroes,
                ...fp.apiHeroEquipment,
                ...fp.apiTroops,
                ...fp.apiSpells,
                ...fp.apiSiegeMachines,
                ...fp.apiPets,
              ];
              const match = allApiUnits.find(
                (u) =>
                  u.name.toLowerCase() === au.objectName.toLowerCase() &&
                  (au.village === 'builderBase' ? u.village === 'builderBase' : u.village !== 'builderBase')
              );
              if (match) apiCurLevel = match.level;
            }

            if (apiCurLevel !== null && apiCurLevel >= au.toLevel) {
              return {
                ...au,
                status: 'completed' as const,
                lastConfirmedAt: realData.clan.lastSyncedAt,
              };
            }
            return au;
          })
        : [];

      store = {
        ...store,
        clan: realData.clan,
        players: realData.players,
        wars: realData.wars,
        currentWar: realData.currentWar,
        cwl: realData.cwl,
        capitalRaids: realData.capitalRaids,
        events: realData.events,
        activeUpgrades: reconciledActive,
        clanEvents: realData.clanEvents,
        history: realData.history,
        snapshots: realData.snapshots,
        syncConfig: {
          ...store.syncConfig,
          lastSyncAt: realData.clan.lastSyncedAt,
          lastSyncStatus: 'ok',
          lastSyncError: null,
        },
      };
      saveStore(store);

      const summary: SyncRunSummary = {
        checkedMembers: realData.checkedMembers,
        totalMembers: realData.totalMembers,
        upgradesFound: realData.newUpgrades.length,
        errorsCount: realData.errorsCount,
        completedAt: realData.clan.lastSyncedAt,
        newUpgrades: realData.newUpgrades,
        errorMessage: null,
      };

      updateProgress({
        inProgress: false,
        stage: 'done',
        statusText:
          summary.upgradesFound > 0
            ? `Проверка завершена. Обнаружено улучшений: ${summary.upgradesFound}`
            : 'Проверка завершена. Новых улучшений не обнаружено',
        checkedMembers: summary.checkedMembers,
        totalMembers: summary.totalMembers,
        upgradesFound: summary.upgradesFound,
        errorsCount: summary.errorsCount,
        completedAt: summary.completedAt,
        lastError: null,
      });

      const state = getFullState();
      broadcastSse('state_update', {
        reason: options?.reason ?? 'coc_api_synced',
        events: realData.newUpgrades.slice(0, 10),
        summary,
        state,
      });
      return { state, summary };
    } catch (err) {
      const errMsg = err instanceof Error ? err.message : 'Ошибка синхронизации';
      store.syncConfig = {
        ...store.syncConfig,
        lastSyncStatus: 'error',
        lastSyncError: errMsg,
      };
      saveStore(store);
      updateProgress({
        inProgress: false,
        stage: 'error',
        statusText: `Ошибка проверки: ${errMsg}`,
        lastError: errMsg,
        completedAt: new Date().toISOString(),
      });
      throw err;
    } finally {
      syncInFlight = null;
    }
  })();

  return syncInFlight;
}

function updateTodayHistoryPoint(newEvent?: UpgradeEvent) {
  if (store.players.length === 0) return;
  const todayIso = new Date().toISOString().slice(0, 10);
  const monthNames = ['янв', 'фев', 'мар', 'апр', 'май', 'июн', 'июл', 'авг', 'сен', 'окт', 'ноя', 'дек'];
  const nowObj = new Date();
  const label = `${nowObj.getUTCDate()} ${monthNames[nowObj.getUTCMonth()]}`;

  const byPlayer: Record<string, number> = {};
  const thBuckets: Record<number, number[]> = {};

  for (const p of store.players) {
    byPlayer[p.tag] = p.progress.overallPct;
    if (!thBuckets[p.townHallLevel]) thBuckets[p.townHallLevel] = [];
    thBuckets[p.townHallLevel].push(p.progress.overallPct);
  }

  const byTownHall: Record<number, number> = {};
  for (const [thStr, vals] of Object.entries(thBuckets)) {
    byTownHall[Number(thStr)] = Number((vals.reduce((a, b) => a + b, 0) / vals.length).toFixed(1));
  }

  const pCount = Math.max(1, store.players.length);
  const avgField = (fn: (p: PlayerProfile) => number) =>
    Number((store.players.reduce((s, p) => s + fn(p), 0) / pCount).toFixed(1));

  const clanAvgPct = avgField((p) => p.progress.overallPct);
  const clanDefensesPct = avgField((p) => p.progress.defensesPct);
  const clanHeroesPct = avgField((p) => p.progress.heroesPct);
  const clanLabPct = avgField((p) => p.progress.labPct);
  const clanWallsPct = avgField((p) => p.progress.wallsPct);

  const last = store.history[store.history.length - 1];
  if (last && last.date === todayIso) {
    last.clanAvgPct = clanAvgPct;
    last.clanDefensesPct = clanDefensesPct;
    last.clanHeroesPct = clanHeroesPct;
    last.clanLabPct = clanLabPct;
    last.clanWallsPct = clanWallsPct;
    last.byTownHall = byTownHall;
    last.byPlayer = byPlayer;
    if (newEvent) {
      last.upgradesCount += 1;
      last.upgradesByCategory[newEvent.category] = (last.upgradesByCategory[newEvent.category] ?? 0) + 1;
    }
  } else {
    const baseCats: Record<VillageCategory | 'townhall', number> = {
      defenses: 0,
      heroes: 0,
      lab: 0,
      traps: 0,
      resources: 0,
      walls: 0,
      townhall: 0,
    };
    if (newEvent) {
      baseCats[newEvent.category] = 1;
    }
    store.history.push({
      date: todayIso,
      label,
      clanAvgPct,
      clanDefensesPct,
      clanHeroesPct,
      clanLabPct,
      clanWallsPct,
      byTownHall,
      byPlayer,
      upgradesCount: newEvent ? 1 : 0,
      upgradesByCategory: baseCats,
    });
    if (store.history.length > 120) {
      store.history = store.history.slice(-120);
    }
  }
}

function recordUpgradeEvent(evt: Omit<UpgradeEvent, 'id' | 'timestamp'>): UpgradeEvent {
  const fullEvent: UpgradeEvent = {
    ...evt,
    id: `evt-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
    timestamp: new Date().toISOString(),
  };
  store.events.unshift(fullEvent);
  if (store.events.length > 1000) {
    store.events = store.events.slice(0, 1000);
  }
  if (store.clan) {
    store.clan.lastSyncedAt = fullEvent.timestamp;
  }
  updateTodayHistoryPoint(fullEvent);
  return fullEvent;
}

function completeBuilderOnPlayer(player: PlayerProfile, builderId: string, source: UpgradeEvent['source'] = 'live_builder') {
  const bIdx = player.activeBuilders.findIndex((b) => b.id === builderId);
  if (bIdx === -1) return null;
  const builder = player.activeBuilders[bIdx];
  player.activeBuilders.splice(bIdx, 1);

  const item = player.items.find((i) => i.id === builder.itemId);
  if (item && builder.instanceIndex < item.levels.length) {
    const cur = item.levels[builder.instanceIndex];
    if (cur < item.maxLevelForTh) {
      item.levels[builder.instanceIndex] = Math.min(item.maxLevelForTh, builder.toLevel);
    }
  }
  player.progress = calculatePlayerProgress(player.townHallLevel, player.items, player.walls);
  player.lastSyncedAt = new Date().toISOString();

  const evt = recordUpgradeEvent({
    playerTag: player.tag,
    playerName: player.name,
    townHallLevel: player.townHallLevel,
    category: builder.category,
    itemId: builder.itemId,
    itemNameRu: builder.itemNameRu,
    instanceNumber: item && item.levels.length > 1 ? builder.instanceIndex + 1 : undefined,
    fromLevel: builder.fromLevel,
    toLevel: builder.toLevel,
    source,
  });

  return evt;
}

// Background timer 1: auto-complete finished active builders
setInterval(() => {
  const now = Date.now();
  let changed = false;
  const completedEvents: UpgradeEvent[] = [];

  for (const player of store.players) {
    const finishedIds = player.activeBuilders
      .filter((b) => new Date(b.finishesAt).getTime() <= now)
      .map((b) => b.id);

    for (const bid of finishedIds) {
      const evt = completeBuilderOnPlayer(player, bid, 'live_builder');
      if (evt) {
        changed = true;
        completedEvents.push(evt);
      }
    }
  }

  if (changed) {
    saveStore(store);
    broadcastSse('state_update', {
      reason: 'builder_completed',
      events: completedEvents,
      state: getFullState(),
    });
  }
}, 4000);

// Background timer 2: scheduled automatic clan sync on the server
async function runScheduledAutoSyncIfDue() {
  if (!store.clan || !store.syncConfig.autoSyncEnabled || !hasValidServerCocToken()) return;
  if (syncInFlight) return;

  const intervalMs = Math.max(5, store.syncConfig.intervalMinutes) * 60 * 1000;
  const lastMs = store.syncConfig.lastSyncAt
    ? new Date(store.syncConfig.lastSyncAt).getTime()
    : 0;

  if (Date.now() - lastMs >= intervalMs) {
    try {
      await performClanSync(store.clan.tag, { bypassCache: true, reason: 'scheduled_sync' });
    } catch {
      // Error state already captured safely inside performClanSync
    }
  }
}

setInterval(() => {
  void runScheduledAutoSyncIfDue();
}, 60000);

// Catch-up sync shortly after server start if the previous interval elapsed while offline
setTimeout(() => {
  void runScheduledAutoSyncIfDue();
}, 8000);

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '4mb' }));

  // Safe API request logging (never logs secrets, headers, or tokens)
  app.use('/api', (req: Request, res: Response, next: NextFunction) => {
    if (req.path === '/stream') {
      next();
      return;
    }
    const startedAt = Date.now();
    res.on('finish', () => {
      const elapsedMs = Date.now() - startedAt;
      console.info(
        `[API] ${new Date().toISOString()} | ${req.method} ${req.originalUrl.split('?')[0]} | status=${res.statusCode} | ${elapsedMs}ms`
      );
    });
    next();
  });

  // Health & token status check (never reveals token value)
  app.get('/api/health', (_req: Request, res: Response) => {
    res.json({
      ok: true,
      hasApiToken: hasValidServerCocToken(),
      activeSecretName: getActiveSecretName(),
      configuredSecretNames: getSecretCandidates().map((c) => c.name),
      cache: getCacheStats(),
      clanConnected: Boolean(store.clan),
    });
  });

  // SSE Stream
  app.get('/api/stream', (req: Request, res: Response) => {
    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');
    res.flushHeaders?.();

    res.write(`event: connected\ndata: ${JSON.stringify({ ok: true, ts: Date.now() })}\n\n`);
    sseClients.add(res);

    const keepAlive = setInterval(() => {
      try {
        res.write(': ping\n\n');
      } catch {
        clearInterval(keepAlive);
      }
    }, 20000);

    req.on('close', () => {
      clearInterval(keepAlive);
      sseClients.delete(res);
    });
  });

  // Full dashboard state
  app.get('/api/state', (_req: Request, res: Response) => {
    res.json(getFullState());
  });

  // Search clans with pagination (GET /clans?name=... or GET /clans/{clanTag})
  app.get('/api/coc/search', async (req: Request, res: Response) => {
    try {
      const q = String(req.query.query ?? req.query.name ?? '').trim();
      if (!q) {
        res.json({ items: [] });
        return;
      }
      const limit = req.query.limit ? Math.min(50, Math.max(1, Number(req.query.limit))) : 15;
      const after = req.query.after ? String(req.query.after) : undefined;
      const before = req.query.before ? String(req.query.before) : undefined;
      const result = await searchClansOfficial(q, { limit, after, before });
      res.json(result);
    } catch (err) {
      sendCocError(res, err, 'Ошибка поиска клана в Clash of Clans API');
    }
  });

  // Direct query-param endpoint for GET /clans?tag=... or GET /clans?name=...
  app.get('/api/coc/clans', async (req: Request, res: Response) => {
    try {
      const rawTag = String(req.query.tag || '').trim();
      if (rawTag) {
        const { valid, normalized } = validateCocTag(rawTag);
        if (!valid) {
          res.status(400).json({
            error: 'Ошибка 400: некорректный формат тега клана (допустимые символы: 0, 2, 8, 9, C, G, J, L, P, Q, R, U, V, Y).',
            statusCode: 400,
          });
          return;
        }
        const clan = await getClanByTagOfficial(normalized);
        res.json(clan);
        return;
      }

      const nameQuery = String(req.query.name ?? req.query.query ?? '').trim();
      if (!nameQuery) {
        res.json({ items: [] });
        return;
      }
      const limit = req.query.limit ? Math.min(50, Math.max(1, Number(req.query.limit))) : 15;
      const after = req.query.after ? String(req.query.after) : undefined;
      const before = req.query.before ? String(req.query.before) : undefined;
      const result = await searchClansOfficial(nameQuery, { limit, after, before });
      res.json(result);
    } catch (err) {
      sendCocError(res, err, 'Ошибка получения данных клана из Clash of Clans API');
    }
  });

  // Direct proxy for GET /clans/{clanTag}
  app.get('/api/coc/clans/:clanTag', async (req: Request, res: Response) => {
    try {
      const rawTag = String(req.params.clanTag || '').trim();
      if (!rawTag) {
        res.status(400).json({ error: 'Укажите тег клана', statusCode: 400 });
        return;
      }
      const { valid, normalized } = validateCocTag(rawTag);
      if (!valid) {
        res.status(400).json({
          error: 'Ошибка 400: некорректный формат тега клана (пример: #2UPULGJVC).',
          statusCode: 400,
        });
        return;
      }
      const clan = await getClanByTagOfficial(normalized);
      res.json(clan);
    } catch (err) {
      sendCocError(res, err, 'Ошибка получения данных клана из Clash of Clans API');
    }
  });

  // Paginated members endpoint: GET /clans/{clanTag}/members
  app.get('/api/coc/clans/:clanTag/members', async (req: Request, res: Response) => {
    try {
      const rawTag = String(req.params.clanTag || '').trim();
      if (!rawTag) {
        res.status(400).json({ error: 'Укажите тег клана', statusCode: 400 });
        return;
      }
      const { valid, normalized } = validateCocTag(rawTag);
      if (!valid) {
        res.status(400).json({ error: 'Ошибка 400: некорректный формат тега клана.', statusCode: 400 });
        return;
      }
      const limit = req.query.limit ? Math.min(50, Math.max(1, Number(req.query.limit))) : 50;
      const after = req.query.after ? String(req.query.after) : undefined;
      const before = req.query.before ? String(req.query.before) : undefined;
      const result = await getClanMembersOfficial(normalized, { limit, after, before });
      res.json(result);
    } catch (err) {
      sendCocError(res, err, 'Ошибка получения участников клана из Clash of Clans API');
    }
  });

  // Direct query-param player lookup: GET /api/coc/players?tag=#2PP
  app.get('/api/coc/players', async (req: Request, res: Response) => {
    try {
      const rawTag = String(req.query.tag || '').trim();
      if (!rawTag) {
        res.status(400).json({
          error: 'Укажите игровой тег игрока (например, #2PP)',
          statusCode: 400,
        });
        return;
      }
      const { valid, normalized } = validateCocTag(rawTag);
      if (!valid) {
        res.status(400).json({
          error: 'Ошибка 400: некорректный игровой тег игрока (допустимые символы: 0, 2, 8, 9, C, G, J, L, P, Q, R, U, V, Y, например #2PP).',
          statusCode: 400,
        });
        return;
      }
      const player = await getPlayerByTagOfficial(normalized);
      res.json({ player });
    } catch (err) {
      sendCocError(res, err, 'Ошибка получения профиля игрока из Clash of Clans API');
    }
  });

  // Direct player lookup via GET /players/{playerTag}
  app.get('/api/coc/players/:playerTag', async (req: Request, res: Response) => {
    try {
      const rawTag = String(req.params.playerTag || '').trim();
      if (!rawTag) {
        res.status(400).json({
          error: 'Укажите игровой тег игрока (например, #2PP)',
          statusCode: 400,
        });
        return;
      }
      const { valid, normalized } = validateCocTag(rawTag);
      if (!valid) {
        res.status(400).json({
          error: 'Ошибка 400: некорректный игровой тег игрока (допустимые символы: 0, 2, 8, 9, C, G, J, L, P, Q, R, U, V, Y, например #2PP).',
          statusCode: 400,
        });
        return;
      }
      const player = await getPlayerByTagOfficial(normalized);
      res.json({ player });
    } catch (err) {
      sendCocError(res, err, 'Ошибка получения профиля игрока из Clash of Clans API');
    }
  });

  // Direct proxy for GET /clans/{clanTag}/currentwar
  app.get('/api/coc/clans/:clanTag/currentwar', async (req: Request, res: Response) => {
    try {
      const rawTag = String(req.params.clanTag || '').trim();
      if (!rawTag) {
        res.status(400).json({ error: 'Укажите тег клана', statusCode: 400 });
        return;
      }
      const { valid, normalized } = validateCocTag(rawTag);
      if (!valid) {
        res.status(400).json({ error: 'Ошибка 400: некорректный формат тега клана.', statusCode: 400 });
        return;
      }
      const war = await getCurrentWarOfficial(normalized);
      res.json(war);
    } catch (err) {
      sendCocError(res, err, 'Ошибка получения текущей войны из Clash of Clans API');
    }
  });

  // Direct proxy for GET /clans/{clanTag}/warlog
  app.get('/api/coc/clans/:clanTag/warlog', async (req: Request, res: Response) => {
    try {
      const rawTag = String(req.params.clanTag || '').trim();
      if (!rawTag) {
        res.status(400).json({ error: 'Укажите тег клана', statusCode: 400 });
        return;
      }
      const { valid, normalized } = validateCocTag(rawTag);
      if (!valid) {
        res.status(400).json({ error: 'Ошибка 400: некорректный формат тега клана.', statusCode: 400 });
        return;
      }
      const limit = req.query.limit ? Number(req.query.limit) : 20;
      const warlog = await getWarLogOfficial(normalized, limit);
      res.json(warlog);
    } catch (err) {
      sendCocError(res, err, 'Ошибка получения истории войн из Clash of Clans API');
    }
  });

  // Direct proxy for GET /clans/{clanTag}/capitalraidseasons
  app.get('/api/coc/clans/:clanTag/capitalraidseasons', async (req: Request, res: Response) => {
    try {
      const rawTag = String(req.params.clanTag || '').trim();
      if (!rawTag) {
        res.status(400).json({ error: 'Укажите тег клана', statusCode: 400 });
        return;
      }
      const { valid, normalized } = validateCocTag(rawTag);
      if (!valid) {
        res.status(400).json({ error: 'Ошибка 400: некорректный формат тега клана.', statusCode: 400 });
        return;
      }
      const limit = req.query.limit ? Number(req.query.limit) : 5;
      const raids = await getCapitalRaidSeasonsOfficial(normalized, limit);
      res.json(raids);
    } catch (err) {
      sendCocError(res, err, 'Ошибка получения рейдов Столицы из Clash of Clans API');
    }
  });

  // Live Supercell API connectivity test
  app.get('/api/coc/test-connection', async (_req: Request, res: Response) => {
    try {
      const result = await testSupercellApiConnection();
      res.json(result);
    } catch (err) {
      sendCocError(res, err, 'Ошибка проверки подключения к Supercell Clash of Clans API');
    }
  });

  // Connect & save a real clan + initial snapshot
  app.post('/api/coc/connect', async (req: Request, res: Response) => {
    try {
      const rawTag = String(req.body?.clanTag || '').trim();
      if (!rawTag) {
        res.status(400).json({ error: 'Укажите тег клана (например, #2UPULGJVC)', statusCode: 400 });
        return;
      }
      const { valid, normalized } = validateCocTag(rawTag);
      if (!valid) {
        res.status(400).json({
          error: 'Ошибка 400: некорректный формат тега клана (допустимые символы: 0, 2, 8, 9, C, G, J, L, P, Q, R, U, V, Y, например #2UPULGJVC).',
          statusCode: 400,
        });
        return;
      }
      const { state, summary } = await performClanSync(normalized, {
        bypassCache: false,
        reason: 'clan_connected',
      });
      res.json({ state, summary });
    } catch (err) {
      sendCocError(res, err, 'Не удалось загрузить клан из Clash of Clans API');
    }
  });

  // Manual full sync (bypasses cache & saves updated levels)
  app.post('/api/coc/sync', async (req: Request, res: Response) => {
    try {
      const rawTag = String(req.body?.clanTag || store.clan?.tag || '').trim();
      if (!rawTag) {
        res.status(400).json({ error: 'Укажите тег клана для синхронизации', statusCode: 400 });
        return;
      }
      const { valid, normalized } = validateCocTag(rawTag);
      if (!valid) {
        res.status(400).json({ error: 'Ошибка 400: некорректный формат тега клана.', statusCode: 400 });
        return;
      }
      const { state, summary } = await performClanSync(normalized, {
        bypassCache: true,
        reason: 'coc_api_synced',
      });
      res.json({ syncedPlayers: state.players.length, events: state.events, summary, state });
    } catch (err) {
      sendCocError(res, err, 'Сбой подключения к официальному Clash of Clans API');
    }
  });

  // Current sync progress endpoint
  app.get('/api/sync/status', (_req: Request, res: Response) => {
    res.json(currentSyncProgress);
  });

  // Refresh connected clan button ("Проверить улучшения")
  app.post('/api/sync/tick', async (_req: Request, res: Response) => {
    if (!store.clan) {
      res.status(400).json({ error: 'Сначала выберите и подключите клан через Clash of Clans API' });
      return;
    }
    try {
      const { state, summary } = await performClanSync(store.clan.tag, {
        bypassCache: true,
        reason: 'manual_refresh',
      });
      res.json({ event: summary.newUpgrades[0] ?? null, summary, state });
    } catch (err) {
      sendCocError(res, err, 'Ошибка синхронизации с Clash of Clans API');
    }
  });

  // Update auto-sync settings
  app.post('/api/settings/sync', (req: Request, res: Response) => {
    const { autoSyncEnabled, intervalMinutes } = req.body ?? {};
    if (typeof autoSyncEnabled === 'boolean') {
      store.syncConfig.autoSyncEnabled = autoSyncEnabled;
    }
    if (intervalMinutes !== undefined) {
      const mins = Math.min(1440, Math.max(5, Number(intervalMinutes) || 360));
      store.syncConfig.intervalMinutes = mins;
    }
    saveStore(store);
    const state = getFullState();
    broadcastSse('state_update', { reason: 'settings_updated', events: [], state });
    res.json({ state });
  });

  // Mark notification(s) in Event Center as read
  app.post('/api/events/mark-read', (req: Request, res: Response) => {
    const { eventId, markAll } = req.body ?? {};
    let updated = false;
    if (markAll) {
      for (const ev of store.clanEvents) {
        if (!ev.read) {
          ev.read = true;
          updated = true;
        }
      }
    } else if (typeof eventId === 'string' && eventId) {
      const found = store.clanEvents.find((ev) => ev.id === eventId);
      if (found && !found.read) {
        found.read = true;
        updated = true;
      }
    }
    if (updated) {
      saveStore(store);
    }
    const state = getFullState();
    if (updated) {
      broadcastSse('state_update', { reason: 'events_read', events: [], state });
    }
    res.json({ ok: true, state });
  });

  // Clear server API cache
  app.post('/api/cache/clear', (_req: Request, res: Response) => {
    clearApiCache();
    res.json({ ok: true, state: getFullState() });
  });

  // Complete a specific active builder
  app.post('/api/players/:tag/builders/:builderId/complete', (req: Request, res: Response) => {
    const tag = decodeURIComponent(String(req.params.tag));
    const builderId = String(req.params.builderId);
    const player = store.players.find((p) => p.tag === tag);
    if (!player) {
      res.status(404).json({ error: 'Игрок не найден' });
      return;
    }

    const evt = completeBuilderOnPlayer(player, builderId, 'manual');
    if (!evt) {
      res.status(404).json({ error: 'Активный строитель не найден' });
      return;
    }

    saveStore(store);
    const state = getFullState();
    broadcastSse('state_update', { reason: 'builder_completed', events: [evt], state });
    res.json({ event: evt, state });
  });

  // Upgrade a specific building / hero / troop / wall
  app.post('/api/players/:tag/upgrade', (req: Request, res: Response) => {
    const tag = decodeURIComponent(String(req.params.tag));
    const player = store.players.find((p) => p.tag === tag);
    if (!player) {
      res.status(404).json({ error: 'Игрок не найден' });
      return;
    }

    const { itemId, instanceIndex = 0, mode = 'instant', durationSeconds = 120, wallFromLevel, wallCount = 10 } = req.body ?? {};

    if (itemId === 'walls') {
      const cap = getWallCapForTh(player.townHallLevel);
      const fromLv = Number(wallFromLevel);
      const available = player.walls.byLevel[fromLv] ?? 0;
      if (!fromLv || available <= 0 || fromLv >= cap.maxLevel) {
        res.status(400).json({ error: 'Нет стен этого уровня для улучшения' });
        return;
      }
      const qty = Math.min(available, Math.max(1, Number(wallCount)));
      player.walls.byLevel[fromLv] = available - qty;
      if (player.walls.byLevel[fromLv] <= 0) delete player.walls.byLevel[fromLv];
      player.walls.byLevel[fromLv + 1] = (player.walls.byLevel[fromLv + 1] ?? 0) + qty;
      player.progress = calculatePlayerProgress(player.townHallLevel, player.items, player.walls);
      player.lastSyncedAt = new Date().toISOString();

      const evt = recordUpgradeEvent({
        playerTag: player.tag,
        playerName: player.name,
        townHallLevel: player.townHallLevel,
        category: 'walls',
        itemId: 'walls',
        itemNameRu: `Стены (${qty} шт.)`,
        fromLevel: fromLv,
        toLevel: fromLv + 1,
        source: 'manual',
      });

      saveStore(store);
      const state = getFullState();
      broadcastSse('state_update', { reason: 'upgrade_logged', events: [evt], state });
      res.json({ event: evt, state });
      return;
    }

    if (itemId === 'town_hall') {
      if (player.townHallLevel >= 18) {
        res.status(400).json({ error: 'Ратуша уже максимального 18 уровня' });
        return;
      }
      const oldTh = player.townHallLevel;
      const newTh = oldTh + 1;
      player.townHallLevel = newTh;

      for (const def of VILLAGE_ENTITIES) {
        const cap = getCapForTh(def, newTh);
        if (cap.maxLevel === 0 || cap.count === 0) continue;
        const existing = player.items.find((i) => i.id === def.id);
        if (existing) {
          existing.maxLevelForTh = cap.maxLevel;
          existing.expectedCount = cap.count;
          while (existing.levels.length < cap.count) existing.levels.push(0);
        } else if (player.buildingsVerified) {
          player.items.push({
            id: def.id,
            nameRu: def.nameRu,
            category: def.category,
            levels: Array(cap.count).fill(0),
            maxLevelForTh: cap.maxLevel,
            expectedCount: cap.count,
            supercellId: def.supercellIds[0],
          });
        }
      }
      const newWallCap = getWallCapForTh(newTh);
      player.walls.maxLevelForTh = newWallCap.maxLevel;

      player.progress = calculatePlayerProgress(newTh, player.items, player.walls);
      player.lastSyncedAt = new Date().toISOString();

      const evt = recordUpgradeEvent({
        playerTag: player.tag,
        playerName: player.name,
        townHallLevel: newTh,
        category: 'townhall',
        itemId: 'town_hall',
        itemNameRu: 'Ратуша',
        fromLevel: oldTh,
        toLevel: newTh,
        source: 'manual',
      });

      saveStore(store);
      const state = getFullState();
      broadcastSse('state_update', { reason: 'townhall_upgraded', events: [evt], state });
      res.json({ event: evt, state });
      return;
    }

    const item = player.items.find((i) => i.id === itemId);
    if (!item) {
      res.status(404).json({ error: 'Постройка или юнит не найдены' });
      return;
    }

    const idx = Math.max(0, Math.min(item.levels.length - 1, Number(instanceIndex)));
    const curLevel = item.levels[idx];
    if (curLevel >= item.maxLevelForTh) {
      res.status(400).json({ error: `${item.nameRu} уже максимального уровня для TH${player.townHallLevel}` });
      return;
    }

    if (mode === 'builder') {
      const existingBuilder = player.activeBuilders.find(
        (b) => b.itemId === item.id && b.instanceIndex === idx
      );
      if (existingBuilder) {
        res.status(400).json({ error: 'Этот объект уже строится' });
        return;
      }
      const now = Date.now();
      const builder: ActiveBuilder = {
        id: `bld-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
        itemId: item.id,
        itemNameRu: item.nameRu,
        category: item.category,
        instanceIndex: idx,
        fromLevel: curLevel,
        toLevel: curLevel + 1,
        startedAt: new Date(now).toISOString(),
        finishesAt: new Date(now + Math.max(10, Number(durationSeconds)) * 1000).toISOString(),
      };
      player.activeBuilders.push(builder);
      saveStore(store);
      const state = getFullState();
      broadcastSse('state_update', { reason: 'builder_started', builder, state });
      res.json({ builder, state });
      return;
    }

    item.levels[idx] = curLevel + 1;
    player.activeBuilders = player.activeBuilders.filter(
      (b) => !(b.itemId === item.id && b.instanceIndex === idx)
    );
    player.progress = calculatePlayerProgress(player.townHallLevel, player.items, player.walls);
    player.lastSyncedAt = new Date().toISOString();

    const evt = recordUpgradeEvent({
      playerTag: player.tag,
      playerName: player.name,
      townHallLevel: player.townHallLevel,
      category: item.category,
      itemId: item.id,
      itemNameRu: item.nameRu,
      instanceNumber: item.levels.length > 1 ? idx + 1 : undefined,
      fromLevel: curLevel,
      toLevel: curLevel + 1,
      source: 'manual',
    });

    saveStore(store);
    const state = getFullState();
    broadcastSse('state_update', { reason: 'upgrade_logged', events: [evt], state });
    res.json({ event: evt, state });
  });

  // Preview diff for Clash of Clans Village JSON Export (Home Village + Builder Base + Active Timers)
  app.post('/api/import/preview', (req: Request, res: Response) => {
    try {
      const { jsonText, targetTag } = req.body ?? {};
      const rawStr = String(jsonText || '');
      const fullParsed = parseFullSupercellExportJson(rawStr);
      const legacyParsed = parseSupercellVillageJson(rawStr);
      const lookupTagRaw = targetTag ? String(targetTag).trim().toUpperCase() : fullParsed.tag;
      const lookupTag = lookupTagRaw.startsWith('#') ? lookupTagRaw : `#${lookupTagRaw}`;
      const existing = store.players.find((p) => p.tag === lookupTag);

      const diffs: Array<{
        village: VillageId;
        itemId: string;
        apiName: string;
        itemNameRu: string;
        category: VillageCategory | 'townhall';
        instanceNumber?: number;
        fromLevel: number;
        toLevel: number;
      }> = [];

      const compareJsonLists = (
        prevList: JsonObjectSnapshotEntry[],
        curList: JsonObjectSnapshotEntry[],
        village: VillageId
      ) => {
        const prevMap = new Map(prevList.map((e) => [e.dataId, e.levels]));
        for (const cur of curList) {
          const prevLevels = prevMap.get(cur.dataId) ?? [];
          const len = Math.min(cur.levels.length, prevLevels.length);
          for (let i = 0; i < len; i++) {
            if (cur.levels[i] > prevLevels[i]) {
              diffs.push({
                village,
                itemId: `json_${village}_${cur.dataId}`,
                apiName: cur.name,
                itemNameRu: cur.nameRu,
                category: cur.detailType === 'townhall' ? 'townhall' : cur.detailType === 'hero' ? 'heroes' : cur.detailType === 'troop' || cur.detailType === 'spell' || cur.detailType === 'pet' || cur.detailType === 'siege' ? 'lab' : cur.categoryGroup === 'trap' ? 'traps' : cur.categoryGroup === 'resource_army' ? 'resources' : 'defenses',
                instanceNumber: cur.levels.length > 1 ? i + 1 : undefined,
                fromLevel: prevLevels[i],
                toLevel: cur.levels[i],
              });
            }
          }
          // Newly built structures
          if (prevList.length > 0 && cur.levels.length > prevLevels.length) {
            for (let i = prevLevels.length; i < cur.levels.length; i++) {
              if (cur.levels[i] > 0) {
                diffs.push({
                  village,
                  itemId: `json_${village}_${cur.dataId}`,
                  apiName: cur.name,
                  itemNameRu: cur.nameRu,
                  category: cur.categoryGroup === 'trap' ? 'traps' : cur.categoryGroup === 'resource_army' ? 'resources' : 'defenses',
                  instanceNumber: cur.levels.length > 1 ? i + 1 : undefined,
                  fromLevel: 0,
                  toLevel: cur.levels[i],
                });
              }
            }
          }
        }
      };

      if (existing) {
        if (fullParsed.home.townHallLevel > 0 && fullParsed.home.townHallLevel > existing.townHallLevel) {
          diffs.push({
            village: 'home',
            itemId: 'town_hall',
            apiName: 'Town Hall',
            itemNameRu: 'Ратуша',
            category: 'townhall',
            fromLevel: existing.townHallLevel,
            toLevel: fullParsed.home.townHallLevel,
          });
        }
        if (
          fullParsed.builderBase.hasData &&
          fullParsed.builderBase.builderHallLevel > 0 &&
          existing.builderHallLevel > 0 &&
          fullParsed.builderBase.builderHallLevel > existing.builderHallLevel
        ) {
          diffs.push({
            village: 'builderBase',
            itemId: 'builder_hall',
            apiName: 'Builder Hall',
            itemNameRu: 'Дом строителя',
            category: 'townhall',
            fromLevel: existing.builderHallLevel,
            toLevel: fullParsed.builderBase.builderHallLevel,
          });
        }

        if (existing.jsonVillage) {
          compareJsonLists(existing.jsonVillage.homeBuildings, fullParsed.home.buildings, 'home');
          compareJsonLists(existing.jsonVillage.homeTraps, fullParsed.home.traps, 'home');
          compareJsonLists(existing.jsonVillage.builderBuildings, fullParsed.builderBase.buildings, 'builderBase');
          compareJsonLists(existing.jsonVillage.builderTraps, fullParsed.builderBase.traps, 'builderBase');
          compareJsonLists(existing.jsonVillage.builderHeroes, fullParsed.builderBase.heroes, 'builderBase');
          compareJsonLists(existing.jsonVillage.builderTroops, fullParsed.builderBase.troops, 'builderBase');
        }
      }

      const effectiveTh = fullParsed.home.townHallLevel || legacyParsed.townHallLevel;
      const newProgress = calculatePlayerProgress(effectiveTh, legacyParsed.items, legacyParsed.walls);

      res.json({
        parsed: {
          tag: lookupTag,
          townHallLevel: effectiveTh,
          builderHallLevel: fullParsed.builderBase.builderHallLevel,
          hasBuilderBase: fullParsed.builderBase.hasData,
          exportTimestampIso: fullParsed.exportTimestampIso,
          recognizedCount: fullParsed.totalObjectsCount,
          homeBuildingsCount: fullParsed.home.buildings.reduce((s, b) => s + b.levels.length, 0),
          homeTrapsCount: fullParsed.home.traps.reduce((s, b) => s + b.levels.length, 0),
          homeWallsTotal: fullParsed.home.wallsTotal,
          builderBuildingsCount: fullParsed.builderBase.buildings.reduce((s, b) => s + b.levels.length, 0),
          builderTrapsCount: fullParsed.builderBase.traps.reduce((s, b) => s + b.levels.length, 0),
          builderWallsTotal: fullParsed.builderBase.wallsTotal,
          progress: newProgress,
        },
        activeTimers: fullParsed.activeTimers,
        missingFields: fullParsed.missingFields,
        matchedPlayer: existing
          ? {
              tag: existing.tag,
              name: existing.name,
              oldPct: existing.progress.overallPct,
              lastJsonImportAt: existing.lastJsonImportAt,
            }
          : null,
        diffs,
      });
    } catch (err) {
      res.status(400).json({ error: err instanceof Error ? err.message : 'Ошибка разбора JSON' });
    }
  });

  // Commit Clash of Clans Village JSON Export (Home Village + Builder Base + Active Timers)
  app.post('/api/import/village', (req: Request, res: Response) => {
    try {
      const { jsonText, targetTag, playerName } = req.body ?? {};
      const rawStr = String(jsonText || '');
      const fullParsed = parseFullSupercellExportJson(rawStr);
      const legacyParsed = parseSupercellVillageJson(rawStr);
      const finalTag = (targetTag ? String(targetTag).trim() : fullParsed.tag).toUpperCase();
      const normalizedTag = finalTag.startsWith('#') ? finalTag : `#${finalTag}`;

      const nowIso = new Date().toISOString();
      const baseTimerMs = fullParsed.exportTimestampIso
        ? new Date(fullParsed.exportTimestampIso).getTime()
        : Date.now();

      let existing = store.players.find((p) => p.tag === normalizedTag);
      const createdEvents: UpgradeEvent[] = [];
      const existingDedupKeys = new Set(
        store.events.map((e) => e.dedupKey).filter((x): x is string => Boolean(x))
      );

      const pushJsonCompletedEvent = (evt: Omit<UpgradeEvent, 'id' | 'timestamp'>) => {
        if (evt.dedupKey && existingDedupKeys.has(evt.dedupKey)) return;
        if (evt.dedupKey) existingDedupKeys.add(evt.dedupKey);
        const full = recordUpgradeEvent({
          ...evt,
          detectedAt: nowIso,
          lastConfirmedAt: nowIso,
          status: 'completed',
        });
        createdEvents.push(full);
      };

      const newJsonVillage: PlayerJsonVillageState = {
        importedAt: nowIso,
        exportTimestampIso: fullParsed.exportTimestampIso,
        source: 'json_import',
        homeTownHallLevel: fullParsed.home.townHallLevel || legacyParsed.townHallLevel,
        homeBuildings: fullParsed.home.buildings.map(({ dataId, name, nameRu, detailType, categoryGroup, levels }) => ({
          dataId,
          name,
          nameRu,
          detailType,
          categoryGroup,
          levels,
        })),
        homeTraps: fullParsed.home.traps.map(({ dataId, name, nameRu, detailType, categoryGroup, levels }) => ({
          dataId,
          name,
          nameRu,
          detailType,
          categoryGroup,
          levels,
        })),
        homeWallsByLevel: fullParsed.home.wallsByLevel,
        homeWallsTotal: fullParsed.home.wallsTotal,
        builderHallLevel: fullParsed.builderBase.builderHallLevel || existing?.builderHallLevel,
        builderBuildings: fullParsed.builderBase.buildings.map(({ dataId, name, nameRu, detailType, categoryGroup, levels }) => ({
          dataId,
          name,
          nameRu,
          detailType,
          categoryGroup,
          levels,
        })),
        builderTraps: fullParsed.builderBase.traps.map(({ dataId, name, nameRu, detailType, categoryGroup, levels }) => ({
          dataId,
          name,
          nameRu,
          detailType,
          categoryGroup,
          levels,
        })),
        builderWallsByLevel: fullParsed.builderBase.wallsByLevel,
        builderWallsTotal: fullParsed.builderBase.wallsTotal,
        builderHeroes: fullParsed.builderBase.heroes.map(({ dataId, name, nameRu, detailType, categoryGroup, levels }) => ({
          dataId,
          name,
          nameRu,
          detailType,
          categoryGroup,
          levels,
        })),
        builderTroops: fullParsed.builderBase.troops.map(({ dataId, name, nameRu, detailType, categoryGroup, levels }) => ({
          dataId,
          name,
          nameRu,
          detailType,
          categoryGroup,
          levels,
        })),
        activeTimersCount: fullParsed.activeTimers.length,
        missingFields: fullParsed.missingFields,
      };

      if (existing) {
        const effTh = fullParsed.home.townHallLevel || existing.townHallLevel;
        if (fullParsed.home.townHallLevel > existing.townHallLevel) {
          pushJsonCompletedEvent({
            dedupKey: `json:${existing.tag}:townhall:${existing.townHallLevel}->${fullParsed.home.townHallLevel}`,
            playerTag: existing.tag,
            playerName: existing.name,
            townHallLevel: effTh,
            category: 'townhall',
            detailType: 'townhall',
            itemId: 'town_hall',
            apiName: 'Town Hall',
            itemNameRu: 'Ратуша',
            village: 'home',
            fromLevel: existing.townHallLevel,
            toLevel: fullParsed.home.townHallLevel,
            source: 'json_import',
          });
        }

        if (
          fullParsed.builderBase.hasData &&
          fullParsed.builderBase.builderHallLevel > 0 &&
          existing.builderHallLevel > 0 &&
          fullParsed.builderBase.builderHallLevel > existing.builderHallLevel
        ) {
          pushJsonCompletedEvent({
            dedupKey: `json:${existing.tag}:builder_hall:${existing.builderHallLevel}->${fullParsed.builderBase.builderHallLevel}`,
            playerTag: existing.tag,
            playerName: existing.name,
            townHallLevel: effTh,
            category: 'townhall',
            detailType: 'townhall',
            itemId: 'builder_hall',
            apiName: 'Builder Hall',
            itemNameRu: 'Дом строителя',
            village: 'builderBase',
            fromLevel: existing.builderHallLevel,
            toLevel: fullParsed.builderBase.builderHallLevel,
            source: 'json_import',
          });
        }

        const compareCommitLists = (
          prevList: JsonObjectSnapshotEntry[],
          curList: JsonObjectSnapshotEntry[],
          village: VillageId
        ) => {
          const prevMap = new Map(prevList.map((e) => [e.dataId, e.levels]));
          for (const cur of curList) {
            const prevLevels = prevMap.get(cur.dataId) ?? [];
            const len = Math.min(cur.levels.length, prevLevels.length);
            for (let i = 0; i < len; i++) {
              if (cur.levels[i] > prevLevels[i]) {
                const inst = cur.levels.length > 1 ? i + 1 : undefined;
                pushJsonCompletedEvent({
                  dedupKey: `json:${existing!.tag}:${village}:${cur.dataId}:${inst ?? 0}:${prevLevels[i]}->${cur.levels[i]}`,
                  playerTag: existing!.tag,
                  playerName: existing!.name,
                  townHallLevel: effTh,
                  category:
                    cur.detailType === 'townhall'
                      ? 'townhall'
                      : cur.detailType === 'hero'
                      ? 'heroes'
                      : cur.detailType === 'troop' || cur.detailType === 'spell' || cur.detailType === 'pet' || cur.detailType === 'siege'
                      ? 'lab'
                      : cur.categoryGroup === 'trap'
                      ? 'traps'
                      : cur.categoryGroup === 'resource_army'
                      ? 'resources'
                      : 'defenses',
                  detailType: cur.detailType,
                  itemId: `json_${village}_${cur.dataId}`,
                  apiName: cur.name,
                  itemNameRu: cur.nameRu,
                  village,
                  instanceNumber: inst,
                  fromLevel: prevLevels[i],
                  toLevel: cur.levels[i],
                  source: 'json_import',
                });
              }
            }
          }
        };

        if (existing.jsonVillage) {
          compareCommitLists(existing.jsonVillage.homeBuildings, newJsonVillage.homeBuildings, 'home');
          compareCommitLists(existing.jsonVillage.homeTraps, newJsonVillage.homeTraps, 'home');
          compareCommitLists(existing.jsonVillage.builderBuildings, newJsonVillage.builderBuildings, 'builderBase');
          compareCommitLists(existing.jsonVillage.builderTraps, newJsonVillage.builderTraps, 'builderBase');
          compareCommitLists(existing.jsonVillage.builderHeroes, newJsonVillage.builderHeroes, 'builderBase');
          compareCommitLists(existing.jsonVillage.builderTroops, newJsonVillage.builderTroops, 'builderBase');
        }

        existing.townHallLevel = effTh;
        if (fullParsed.builderBase.builderHallLevel > 0) {
          existing.builderHallLevel = fullParsed.builderBase.builderHallLevel;
        }
        existing.items = legacyParsed.items;
        existing.walls = legacyParsed.walls;
        existing.buildingsVerified = true;
        existing.lastJsonImportAt = nowIso;
        existing.jsonVillage = newJsonVillage;
        existing.progress = calculatePlayerProgress(effTh, legacyParsed.items, legacyParsed.walls);
        existing.lastSyncedAt = nowIso;
      } else {
        const effTh = fullParsed.home.townHallLevel || legacyParsed.townHallLevel || 1;
        const progress = calculatePlayerProgress(effTh, legacyParsed.items, legacyParsed.walls);
        const newPlayer: PlayerProfile = {
          tag: normalizedTag,
          name: (playerName && String(playerName).trim()) || `Игрок ${normalizedTag}`,
          role: 'member',
          townHallLevel: effTh,
          builderHallLevel: fullParsed.builderBase.builderHallLevel || 0,
          expLevel: 0,
          trophies: 0,
          bestTrophies: 0,
          builderBaseTrophies: 0,
          bestBuilderBaseTrophies: 0,
          warStars: 0,
          donations: 0,
          donationsReceived: 0,
          clanCapitalContributions: 0,
          apiHeroes: [],
          apiHeroEquipment: [],
          apiTroops: [],
          apiSpells: [],
          apiSiegeMachines: [],
          apiPets: [],
          achievements: [],
          lastSyncedAt: nowIso,
          lastJsonImportAt: nowIso,
          jsonVillage: newJsonVillage,
          items: legacyParsed.items,
          walls: legacyParsed.walls,
          activeBuilders: [],
          progress,
          combat: emptyCombatStats(),
          buildingsVerified: true,
        };
        store.players.push(newPlayer);
        existing = newPlayer;
      }

      // Update activeUpgrades for this player:
      // 1) Mark previous in-progress JSON timers for this player as completed if confirmed in new export
      const prevPlayerActive = (store.activeUpgrades ?? []).filter(
        (au) => au.playerTag === existing!.tag
      );
      const otherPlayersActive = (store.activeUpgrades ?? []).filter(
        (au) => au.playerTag !== existing!.tag
      );

      const newTimerEntries: ActiveUpgradeEntry[] = fullParsed.activeTimers.map((t) => {
        const dedupKey = `active:${existing!.tag}:${t.village}:${t.dataId}:${t.fromLevel}->${t.toLevel}`;
        const prevMatch = prevPlayerActive.find((p) => p.dedupKey === dedupKey);
        const finishesIso = new Date(baseTimerMs + t.timerSeconds * 1000).toISOString();
        return {
          id: prevMatch?.id ?? `act-${existing!.tag}-${t.village}-${t.dataId}-${t.toLevel}-${Date.now()}-${Math.random().toString(36).slice(2, 5)}`,
          dedupKey,
          village: t.village,
          playerTag: existing!.tag,
          playerName: existing!.name,
          townHallLevel: existing!.townHallLevel,
          builderHallLevel: existing!.builderHallLevel,
          objectName: t.objectName,
          objectNameRu: t.objectNameRu,
          detailType: t.detailType,
          fromLevel: t.fromLevel,
          toLevel: t.toLevel,
          status: 'in_progress',
          source: 'json_import',
          detectedAt: prevMatch?.detectedAt ?? nowIso,
          lastConfirmedAt: nowIso,
          timerSecondsInitial: t.timerSeconds,
          exportTimestampIso: fullParsed.exportTimestampIso,
          estimatedFinishesAt: finishesIso,
        };
      });

      const newTimerDedupSet = new Set(newTimerEntries.map((x) => x.dedupKey));
      const keptCompletedFromPrev = prevPlayerActive
        .filter((au) => !newTimerDedupSet.has(au.dedupKey))
        .map((au) => {
          if (au.status === 'completed') return au;
          // Check if the imported JSON shows an object now at >= au.toLevel
          const pool =
            au.village === 'builderBase'
              ? [
                  ...newJsonVillage.builderBuildings,
                  ...newJsonVillage.builderTraps,
                  ...newJsonVillage.builderHeroes,
                  ...newJsonVillage.builderTroops,
                ]
              : [
                  ...newJsonVillage.homeBuildings,
                  ...newJsonVillage.homeTraps,
                ];
          const confirmedReached = pool.some(
            (obj) =>
              obj.name.toLowerCase() === au.objectName.toLowerCase() &&
              obj.levels.some((lv) => lv >= au.toLevel)
          );
          if (confirmedReached) {
            return {
              ...au,
              status: 'completed' as const,
              lastConfirmedAt: nowIso,
            };
          }
          return null;
        })
        .filter((x): x is ActiveUpgradeEntry => Boolean(x))
        .slice(0, 30);

      store.activeUpgrades = [...newTimerEntries, ...keptCompletedFromPrev, ...otherPlayersActive].slice(0, 300);

      updateTodayHistoryPoint();
      saveStore(store);
      const state = getFullState();
      broadcastSse('state_update', {
        reason: 'village_imported',
        events: createdEvents,
        state,
      });

      res.json({
        player: existing,
        eventsCreated: createdEvents.length,
        activeTimersCount: newTimerEntries.length,
        missingFields: fullParsed.missingFields,
        events: createdEvents,
        activeTimers: newTimerEntries,
        state,
      });
    } catch (err) {
      res.status(400).json({ error: err instanceof Error ? err.message : 'Ошибка импорта' });
    }
  });

  // Disconnect / clear current clan store
  app.post('/api/reset', (_req: Request, res: Response) => {
    const syncCfg = store.syncConfig;
    store = {
      ...createEmptyStore(),
      syncConfig: {
        ...syncCfg,
        lastSyncStatus: 'idle',
        lastSyncError: null,
      },
    };
    saveStore(store);
    const state = getFullState();
    broadcastSse('state_update', { reason: 'reset', events: [], state });
    res.json(state);
  });

  // Ensure unmatched /api/* routes always return JSON instead of SPA index.html
  app.use('/api', (_req: Request, res: Response) => {
    res.status(404).json({ error: 'API маршрут не найден', statusCode: 404 });
  });

  // Express JSON error middleware (handles malformed JSON bodies & uncaught errors cleanly)
  app.use((err: unknown, req: Request, res: Response, next: NextFunction) => {
    if (!req.path.startsWith('/api')) {
      next(err);
      return;
    }
    if (err instanceof SyntaxError && 'body' in err) {
      res.status(400).json({ error: 'Некорректный JSON в теле запроса', statusCode: 400 });
      return;
    }
    if (err instanceof CocApiError) {
      res.status(err.statusCode).json({
        error: err.message,
        statusCode: err.statusCode,
        reason: err.reason,
      });
      return;
    }
    console.error(`[API Error] ${new Date().toISOString()} | ${req.method} ${req.originalUrl.split('?')[0]}`, err);
    res.status(500).json({ error: 'Внутренняя ошибка сервера (500)', statusCode: 500 });
  });

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  const port = Number(process.env.PORT) || 3000;
  app.listen(port, '0.0.0.0', () => {
    console.log(`Clash Analytics server listening on http://0.0.0.0:${port}`);
  });
}

startServer();
