import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI, Type } from '@google/genai';
import {
  synthesizeOpportunity,
  synthesizeBusinessPlan,
  synthesizeApplicationPitch,
} from './src/services/aiFallbackService.ts';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(express.json({ limit: '10mb' }));

const PORT = 3000;

// Initialize Google Gemini API on server side
const apiKey = process.env.GEMINI_API_KEY || '';
const ai = new GoogleGenAI({
  apiKey,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

// Timeout wrapper to ensure HTTP requests never hang
function withTimeout<T>(promise: Promise<T>, timeoutMs = 8000): Promise<T> {
  let timer: any;
  const timeoutPromise = new Promise<never>((_, reject) => {
    timer = setTimeout(() => reject(new Error(`Timeout after ${timeoutMs}ms`)), timeoutMs);
  });
  return Promise.race([promise, timeoutPromise]).finally(() => clearTimeout(timer));
}

// Check Firebase applet configuration status
function getFirebaseConfigStatus() {
  const configPath = path.join(process.cwd(), 'firebase-applet-config.json');
  const exists = fs.existsSync(configPath);
  let projectId = '';
  if (exists) {
    try {
      const raw = fs.readFileSync(configPath, 'utf-8');
      const parsed = JSON.parse(raw);
      projectId = parsed.projectId || '';
    } catch {
      // ignore
    }
  }
  return {
    configured: exists,
    projectId: projectId || null,
    provider: 'Firebase Firestore & Auth',
  };
}

// Helper for resilient Gemini API calls with exponential backoff
async function callGeminiWithRetry<T>(fn: () => Promise<T>, maxRetries = 3, initialDelay = 1200): Promise<T> {
  let delay = initialDelay;
  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      return await fn();
    } catch (err: any) {
      const errMsg = err?.message || String(err);
      const isTransient =
        err?.status === 503 ||
        errMsg.includes('503') ||
        errMsg.includes('high demand') ||
        errMsg.includes('Resource exhausted') ||
        errMsg.includes('UNAVAILABLE') ||
        err?.status === 429;

      if (attempt < maxRetries && isTransient) {
        console.warn(`[Gemini] Busy (attempt ${attempt}/${maxRetries}), retrying in ${delay}ms...`);
        await new Promise((r) => setTimeout(r, delay));
        delay *= 2;
      } else {
        throw err;
      }
    }
  }
  throw new Error('Exceeded maximum Gemini retry attempts');
}

// Resilient priority candidate models:
// Uses flash-lite / flash-preview first to guarantee immediate available quota, fallback to next models
const PRIMARY_MODELS = [
  'gemini-3.5-flash-lite',
  'gemini-3.1-flash-lite',
  'gemini-3-flash-preview',
  'gemini-3.8-flash',
];

async function generateContentResilient(params: {
  contents: string;
  systemInstruction?: string;
  responseSchema?: any;
  timeoutMs?: number;
}): Promise<{ data: any; model: string }> {
  const timeoutMs = params.timeoutMs || 25000;
  let lastError: any = null;

  for (const model of PRIMARY_MODELS) {
    try {
      console.log(`[PROJECT ZERO] Attempting generation with model ${model}...`);
      const response = await withTimeout(
        ai.models.generateContent({
          model,
          contents: params.contents,
          config: {
            systemInstruction: params.systemInstruction,
            responseMimeType: 'application/json',
            responseSchema: params.responseSchema,
          },
        }),
        timeoutMs
      );

      const text = response.text || '{}';
      const parsed = JSON.parse(text);
      console.log(`[PROJECT ZERO] Successfully generated response using model: ${model}`);
      return { data: parsed, model };
    } catch (err: any) {
      console.warn(`[PROJECT ZERO] Model ${model} encountered error (${err?.status || err?.message}), testing next available model...`);
      lastError = err;
    }
  }

  throw lastError || new Error('All Gemini candidate models failed');
}

// System status endpoint
app.get('/api/system/status', (_req, res) => {
  const fbStatus = getFirebaseConfigStatus();
  res.json({
    app: 'PROJECT ZERO',
    tagline: 'Turn Problems Into Opportunities',
    geminiConfigured: !!apiKey,
    firebase: fbStatus,
    timestamp: new Date().toISOString(),
  });
});

// AI Problem Solver endpoint
app.post('/api/gemini/solve-problem', async (req, res) => {
  try {
    const { problem, language = 'en', category = 'General', context = '' } = req.body;

    if (!problem || typeof problem !== 'string' || problem.trim().length === 0) {
      return res.status(400).json({ error: 'A problem description is required' });
    }

    if (!apiKey) {
      return res.status(503).json({
        error: 'Gemini API key is not configured on the server. Please check the Secrets panel.',
      });
    }

    const isAmharic = language === 'am';

    const systemInstruction = `You are PROJECT ZERO's Principal Innovation & Entrepreneurship AI Advisor.
PROJECT ZERO's mission is "Turn Problems Into Opportunities" (በአማርኛ: "ችግሮችን ወደ መልካም ዕድል ይቀይሩ").
Your mission is to transform the user's specific problem into a practical, realistic, financially accurate, and profitable business venture.

CRITICAL INSTRUCTIONS & STRICT BUSINESS VALIDATION RULES:
1. UNDERSTAND & ANALYZE THE EXACT PROBLEM: Analyze the user's exact problem without generic platitudes. Identify specific root causes and current cost of inaction.
2. AFFECTED PEOPLE & POTENTIAL CUSTOMERS: Clearly distinguish who is directly affected/harmed from the specific paying customers who will pay to solve it, and explain why they will pay.
3. ALWAYS EXACTLY 3 SPECIFIC & REALISTIC BUSINESS SOLUTIONS: Propose EXACTLY 3 distinct, creative, and feasible business models (never 2, never 4). For each, provide id, title, modelSummary, pros, cons, and operationalComplexity (Low, Medium, High).
4. SELECT THE MOST PRACTICAL SOLUTION & EXPLAIN WHY: Choose the single most realistic solution and give an airtight rationale explaining why it has the lowest barrier to entry and highest chance of success. Detail how it operates day-to-day.
5. REALISTIC STARTUP BUDGET IN ETHIOPIAN BIRR (ETB) & ZERO-BUDGET LAUNCH OPTION:
   - Provide realistic starter budget in ETB (e.g. 10,000 - 35,000 ETB), itemized line items with estimated ETB costs, and a low-capital starter tip.
   - ALWAYS include a detailed 'zeroBudgetOption' explaining specifically how a founder can launch with 0 ETB (using existing smartphone, organic outreach, direct peer-to-peer facilitation) and the honest trade-offs/sweat equity involved.
6. INCOME GENERATION: Detail exact revenue streams, a concrete pricing strategy in ETB, and standard Ethiopian payment channels (Telebirr, CBE Birr, Cash).
7. FINANCIAL ACCURACY, CALCULATIONS & SEPARATING FACTS FROM ASSUMPTIONS:
   - Explain EVERY financial estimate with its calculation.
   - ALWAYS populate 'revenueFormula' with: estimatedSalesCount, averageTransactionValueETB, commissionRatePercent, listingFeeETB, listingFeeCount, and calculationExplanation showing the exact arithmetic (e.g. (30 sales * 4,000 ETB * 10% commission = 12,000 ETB) + (20 featured listings * 50 ETB = 1,000 ETB) = 13,000 ETB total monthly revenue).
   - SEPARATE confirmed facts from assumptions and estimates:
     * 'factsConfirmed': verifiable facts (e.g., Telebirr transaction fees, registered market days in Addis Ababa, local mobile internet tariffs).
     * 'assumptionsAndEstimates': clearly labeled hypotheses and assumptions (e.g., assumed 5% inquiry-to-deal conversion, estimated 15 transactions in month 1).
   - Provide an explicit financial disclaimer that estimates are model projections.
8. DETAILED 7-DAY ACTION PLAN (NEVER PROMISE A SALE WITHIN 7 DAYS):
   - Day 1 through Day 7 must have boots-on-the-ground tasks and clear milestone goals.
   - RULE: NEVER promise or guarantee a closed sale within the 7 days. Frame milestones around research, listing creation, outreach, customer discovery, price validation, and trial inspections.
9. SKILLS & RESOURCES REQUIRED: Concrete practical skills, physical equipment/tools, and digital tools needed.
10. RISKS & MITIGATIONS: Identify realistic local operational risks and actionable mitigations.
11. TEST MARKET DEMAND BEFORE INVESTING MONEY: Provide zero-capital tests with clear success thresholds.
12. NEVER CLAIM MARKET DEMAND IS VERIFIED WITHOUT EVIDENCE: Explicitly state that market demand is an unproven hypothesis until real customers make commitments.
13. BUYER & SELLER VERIFICATION, FRAUD PREVENTION & LEGAL PAYMENT COMPLIANCE:
   - Include 'safetyAndVerification' with:
     * 'buyerVerificationSteps': concrete identity, phone verification, and buyer screening before meetings.
     * 'sellerVerificationSteps': proof of item ownership, physical inspection checklist, serial number/receipt check.
     * 'fraudPreventionGuidelines': daylight public meeting locations (bank lobbies, telecom centers), inspection-before-payment rules.
     * 'legalPaymentCompliance': STRICT RULE: NEVER recommend collecting or holding customer money without a legally appropriate payment arrangement. Disallow informal, unlicensed escrow held in personal bank/Telebirr accounts. Recommend direct buyer-to-seller settlement via Telebirr/CBE Birr immediately upon in-person handover and inspection, with the founder's commission paid separately upon completed transaction, or recommend an authorized/licensed financial escrow institution.

LOCALIZATION:
- Always ground advice in Ethiopian and Addis Ababa/regional economic realities (e.g. Telebirr, CBE Birr, Merkato, Megenagna, Bole, condominiums, transport hubs, local regulatory ease).
- If language is 'am', all textual responses MUST be written in natural, fluent, and inspiring Amharic (ፊደላት / አማርኛ).
- If language is 'en', write in sharp, practical, professional English.`;

    const prompt = `Perform an in-depth 12-point opportunity formulation for this specific problem:
Problem: "${problem.trim()}"
Category: ${category}
${context ? `Additional Context: ${context}` : ''}
Language: ${isAmharic ? 'Amharic (አማርኛ)' : 'English'}`;

    let resultData: any = null;
    let dataSource = 'engine';

    if (apiKey) {
      try {
        const resilientRes = await generateContentResilient({
          contents: prompt,
          systemInstruction,
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              opportunityTitle: { type: Type.STRING },
              tagline: { type: Type.STRING },
              problemAnalysis: {
                type: Type.OBJECT,
                properties: {
                  exactProblemBreakdown: { type: Type.STRING },
                  rootCauses: { type: Type.ARRAY, items: { type: Type.STRING } },
                  currentCostOfInaction: { type: Type.STRING },
                },
                required: ['exactProblemBreakdown', 'rootCauses', 'currentCostOfInaction'],
              },
              affectedAndCustomers: {
                type: Type.OBJECT,
                properties: {
                  affectedDemographics: { type: Type.STRING },
                  payingCustomers: { type: Type.ARRAY, items: { type: Type.STRING } },
                  whyTheyWillPay: { type: Type.STRING },
                },
                required: ['affectedDemographics', 'payingCustomers', 'whyTheyWillPay'],
              },
              candidateSolutions: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    id: { type: Type.STRING },
                    title: { type: Type.STRING },
                    modelSummary: { type: Type.STRING },
                    pros: { type: Type.ARRAY, items: { type: Type.STRING } },
                    cons: { type: Type.ARRAY, items: { type: Type.STRING } },
                    operationalComplexity: { type: Type.STRING },
                  },
                  required: ['id', 'title', 'modelSummary', 'pros', 'cons', 'operationalComplexity'],
                },
              },
              recommendedSolution: {
                type: Type.OBJECT,
                properties: {
                  solutionTitle: { type: Type.STRING },
                  selectionRationale: { type: Type.STRING },
                  howItWorksInPractice: { type: Type.STRING },
                },
                required: ['solutionTitle', 'selectionRationale', 'howItWorksInPractice'],
              },
              startupBudget: {
                type: Type.OBJECT,
                properties: {
                  totalEstimatedETB: { type: Type.STRING },
                  lineItems: {
                    type: Type.ARRAY,
                    items: {
                      type: Type.OBJECT,
                      properties: {
                        item: { type: Type.STRING },
                        costETB: { type: Type.STRING },
                        essential: { type: Type.BOOLEAN },
                      },
                      required: ['item', 'costETB', 'essential'],
                    },
                  },
                  lowCapitalTip: { type: Type.STRING },
                  zeroBudgetOption: {
                    type: Type.OBJECT,
                    properties: {
                      howToLaunchWithZeroBirr: { type: Type.STRING },
                      tradeOffs: { type: Type.STRING },
                    },
                    required: ['howToLaunchWithZeroBirr', 'tradeOffs'],
                  },
                },
                required: ['totalEstimatedETB', 'lineItems', 'lowCapitalTip', 'zeroBudgetOption'],
              },
              incomeModel: {
                type: Type.OBJECT,
                properties: {
                  revenueStreams: { type: Type.ARRAY, items: { type: Type.STRING } },
                  pricingStrategyETB: { type: Type.STRING },
                  paymentMethods: { type: Type.ARRAY, items: { type: Type.STRING } },
                },
                required: ['revenueStreams', 'pricingStrategyETB', 'paymentMethods'],
              },
              financialEstimates: {
                type: Type.OBJECT,
                properties: {
                  estimatedMonthlyRevenueETB: { type: Type.STRING },
                  estimatedMonthlyExpensesETB: { type: Type.STRING },
                  estimatedMonthlyNetETB: { type: Type.STRING },
                  expenseBreakdown: { type: Type.ARRAY, items: { type: Type.STRING } },
                  disclaimer: { type: Type.STRING },
                  revenueFormula: {
                    type: Type.OBJECT,
                    properties: {
                      estimatedSalesCount: { type: Type.NUMBER },
                      averageTransactionValueETB: { type: Type.NUMBER },
                      commissionRatePercent: { type: Type.NUMBER },
                      listingFeeETB: { type: Type.NUMBER },
                      listingFeeCount: { type: Type.NUMBER },
                      calculationExplanation: { type: Type.STRING },
                    },
                    required: [
                      'estimatedSalesCount',
                      'averageTransactionValueETB',
                      'commissionRatePercent',
                      'listingFeeETB',
                      'calculationExplanation',
                    ],
                  },
                  factsConfirmed: { type: Type.ARRAY, items: { type: Type.STRING } },
                  assumptionsAndEstimates: { type: Type.ARRAY, items: { type: Type.STRING } },
                },
                required: [
                  'estimatedMonthlyRevenueETB',
                  'estimatedMonthlyExpensesETB',
                  'estimatedMonthlyNetETB',
                  'expenseBreakdown',
                  'disclaimer',
                  'revenueFormula',
                  'factsConfirmed',
                  'assumptionsAndEstimates',
                ],
              },
              sevenDayActionPlan: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    dayNumber: { type: Type.INTEGER },
                    dayTitle: { type: Type.STRING },
                    specificActions: { type: Type.ARRAY, items: { type: Type.STRING } },
                    milestoneGoal: { type: Type.STRING },
                  },
                  required: ['dayNumber', 'dayTitle', 'specificActions', 'milestoneGoal'],
                },
              },
              skillsAndResources: {
                type: Type.OBJECT,
                properties: {
                  requiredSkills: { type: Type.ARRAY, items: { type: Type.STRING } },
                  physicalEquipment: { type: Type.ARRAY, items: { type: Type.STRING } },
                  digitalTools: { type: Type.ARRAY, items: { type: Type.STRING } },
                },
                required: ['requiredSkills', 'physicalEquipment', 'digitalTools'],
              },
              risksAndMitigations: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    risk: { type: Type.STRING },
                    mitigation: { type: Type.STRING },
                  },
                  required: ['risk', 'mitigation'],
                },
              },
              marketDemandTests: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    testMethod: { type: Type.STRING },
                    howToConduct: { type: Type.STRING },
                    successSignal: { type: Type.STRING },
                  },
                  required: ['testMethod', 'howToConduct', 'successSignal'],
                },
              },
              validationStatus: {
                type: Type.OBJECT,
                properties: {
                  isHypothesis: { type: Type.BOOLEAN },
                  evidenceStatement: { type: Type.STRING },
                },
                required: ['isHypothesis', 'evidenceStatement'],
              },
              safetyAndVerification: {
                type: Type.OBJECT,
                properties: {
                  buyerVerificationSteps: { type: Type.ARRAY, items: { type: Type.STRING } },
                  sellerVerificationSteps: { type: Type.ARRAY, items: { type: Type.STRING } },
                  fraudPreventionGuidelines: { type: Type.ARRAY, items: { type: Type.STRING } },
                  legalPaymentCompliance: { type: Type.STRING },
                },
                required: [
                  'buyerVerificationSteps',
                  'sellerVerificationSteps',
                  'fraudPreventionGuidelines',
                  'legalPaymentCompliance',
                ],
              },
            },
            required: [
              'opportunityTitle',
              'tagline',
              'problemAnalysis',
              'affectedAndCustomers',
              'candidateSolutions',
              'recommendedSolution',
              'startupBudget',
              'incomeModel',
              'financialEstimates',
              'sevenDayActionPlan',
              'skillsAndResources',
              'risksAndMitigations',
              'marketDemandTests',
              'validationStatus',
              'safetyAndVerification',
            ],
          },
          timeoutMs: 25000,
        });

        resultData = resilientRes.data;
        dataSource = resilientRes.model;
      } catch (geminiErr: any) {
        console.warn('[PROJECT ZERO] All Gemini models busy or timed out, applying innovation engine:', geminiErr?.message);
        dataSource = 'engine';
      }
    } else {
      dataSource = 'engine';
    }

    if (!resultData || !resultData.opportunityTitle) {
      resultData = synthesizeOpportunity(problem.trim(), category, language);
      dataSource = 'engine';
    }

    // Ensure backward compatibility fields are populated
    resultData.marketOpportunity = resultData.recommendedSolution?.selectionRationale || resultData.tagline;
    resultData.proposedSolution = resultData.recommendedSolution?.howItWorksInPractice || '';
    resultData.monetizationModel = resultData.incomeModel?.revenueStreams || [];
    resultData.estimatedStartupBudget = resultData.startupBudget?.totalEstimatedETB || '20,000 - 45,000 ETB';
    resultData.immediateNext24Hours = resultData.sevenDayActionPlan?.[0]?.specificActions?.join('; ') || 'Interview 3 affected customers today.';
    resultData.keyRisksAndMitigations = resultData.risksAndMitigations || [];

    return res.json({
      success: true,
      data: resultData,
      source: dataSource,
    });
  } catch (error: any) {
    console.error('Gemini solve-problem error:', error);
    const fallbackData = synthesizeOpportunity(req.body?.problem || 'Challenge', req.body?.category || 'General', req.body?.language || 'en');
    return res.json({
      success: true,
      data: fallbackData,
      source: 'engine',
    });
  }
});

// AI Business Plan Generator endpoint
app.post('/api/gemini/generate-business-plan', async (req, res) => {
  try {
    const { title, description, language = 'en', category = 'General' } = req.body;

    if (!title) {
      return res.status(400).json({ error: 'Opportunity title is required' });
    }

    const isAmharic = language === 'am';
    let resultPlan: any = null;

    if (apiKey) {
      try {
        const systemInstruction = `You are a startup incubator director for PROJECT ZERO: "Turn Problems Into Opportunities."
Create a streamlined, actionable 1-Page Lean Business Canvas.
${isAmharic ? 'Write all output in natural, fluent Amharic (አማርኛ).' : 'Write in clear English.'}`;

        const prompt = `Generate a 1-page business plan for:
Title: ${title}
Details: ${description || 'Entrepreneurial opportunity'}
Category: ${category}
Language: ${isAmharic ? 'Amharic (አማርኛ)' : 'English'}`;

        const resilientRes = await generateContentResilient({
          contents: prompt,
          systemInstruction,
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              executiveSummary: { type: Type.STRING },
              targetCustomerSegments: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
              },
              uniqueValueProposition: { type: Type.STRING },
              channels: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
              },
              revenueStreams: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
              },
              costStructure: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
              },
              keyMetrics: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
              },
              firstMonthMilestones: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
              },
            },
            required: [
              'executiveSummary',
              'targetCustomerSegments',
              'uniqueValueProposition',
              'channels',
              'revenueStreams',
              'costStructure',
              'keyMetrics',
              'firstMonthMilestones',
            ],
          },
          timeoutMs: 20000,
        });

        resultPlan = resilientRes.data;
      } catch (err: any) {
        console.warn('[PROJECT ZERO] Gemini plan generation busy, using engine:', err?.message);
      }
    }

    if (!resultPlan || !resultPlan.executiveSummary) {
      resultPlan = synthesizeBusinessPlan(title, description || '', language);
    }

    return res.json({
      success: true,
      data: resultPlan,
    });
  } catch (error: any) {
    console.error('Gemini generate-business-plan error:', error);
    const plan = synthesizeBusinessPlan(req.body?.title || 'Venture', req.body?.description || '', req.body?.language || 'en');
    return res.json({
      success: true,
      data: plan,
    });
  }
});

// AI CV & Application Letter Generator endpoint
app.post('/api/gemini/tailor-application', async (req, res) => {
  try {
    const { userProfile, targetJob, language = 'en' } = req.body;
    const isAmharic = language === 'am';
    let resultPitch: any = null;

    if (apiKey) {
      try {
        const prompt = `As a career coach for PROJECT ZERO ("Turn Problems Into Opportunities"), generate a tailored applicant pitch and short cover letter.
Job: ${JSON.stringify(targetJob || {})}
Candidate Profile: ${JSON.stringify(userProfile || {})}
Language: ${isAmharic ? 'Amharic (አማርኛ)' : 'English'}`;

        const resilientRes = await generateContentResilient({
          contents: prompt,
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              elevatorPitch: { type: Type.STRING, description: '30-second introduction highlighting problem-solving abilities' },
              coverLetter: { type: Type.STRING, description: '2-paragraph professional tailored message' },
              recommendedKeywords: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
              },
              interviewTip: { type: Type.STRING },
            },
            required: ['elevatorPitch', 'coverLetter', 'recommendedKeywords', 'interviewTip'],
          },
          timeoutMs: 20000,
        });

        resultPitch = resilientRes.data;
      } catch (err: any) {
        console.warn('[PROJECT ZERO] Gemini tailor application busy, using engine:', err?.message);
      }
    }

    if (!resultPitch || !resultPitch.elevatorPitch) {
      resultPitch = synthesizeApplicationPitch(targetJob?.title || 'Role', targetJob?.company || 'Company', language);
    }

    return res.json({
      success: true,
      data: resultPitch,
    });
  } catch (error: any) {
    console.error('Gemini tailor-application error:', error);
    const pitch = synthesizeApplicationPitch(req.body?.targetJob?.title || 'Role', req.body?.targetJob?.company || 'Company', req.body?.language || 'en');
    return res.json({
      success: true,
      data: pitch,
    });
  }
});

// Setup server and Vite middleware
async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';

  if (!isProd) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static('dist'));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[PROJECT ZERO] Server active on port ${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
