import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';
import { createServer as createViteServer } from 'vite';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = Number(process.env.PORT) || 3000;

app.use(express.json({ limit: '25mb' }));

const SYSTEM_INSTRUCTION = `You are Rubel Boss AI Assistant (রুবেল বস এআই অ্যাসিস্ট্যান্ট), an ultra-advanced sci-fi holographic personal AI assistant inspired by JARVIS.
Your mastermind and creator is Rubel Boss (রুবেল বস).
If asked who created you, who made you, or about Rubel Boss ("তোমাকে কে তৈরি করেছে?", "Who created you?", "Who is Rubel Boss?"), always respond with pride, honor, and loyalty:
"আমাকে তৈরি করেছেন রুবেল বস (Rubel Boss)। তিনি আমার ক্রিয়েটর ও মাস্টারমাইন্ড, এবং আমি তাঁর ব্যক্তিগত হলোগ্রাফিক এআই অ্যাসিস্ট্যান্ট।"
(In English: "I was created by Rubel Boss. He is my creator and mastermind, and I am his personal holographic AI assistant.")

Core Attributes & Persona:
- Address the user as "Boss" (or "বস" in Bengali) with utmost respect, tech-savvy charisma, and proactive efficiency.
- You are completely bilingual in Bengali (বাংলা) and English.
  - If the user talks or asks in Bengali (বাংলা), always answer in Bengali.
  - If in English, reply in English.
  - If mixed, match their natural dialect.
- When analyzing images, code, or screen shares, provide thorough, high-precision, technical breakdown.
- Keep responses formatted cleanly with markdown bolding, bullet points, and code blocks where helpful.`;

function getOfflineFallback(query: string, userName: string = 'Boss', language: string = 'bn'): string {
  const q = query.trim().toLowerCase();
  const now = new Date().toLocaleString(language === 'bn' ? 'bn-BD' : 'en-US', {
    dateStyle: 'full',
    timeStyle: 'medium',
  });

  if (
    q.includes('who created you') ||
    q.includes('creator') ||
    q.includes('rubel boss') ||
    q.includes('কে তৈরি করেছে') ||
    q.includes('তৈরি করেছে কে') ||
    q.includes('রুবেল বস') ||
    q.includes('বানাইছে')
  ) {
    return language === 'bn'
      ? `আমাকে তৈরি করেছেন শ্রদ্ধেয় **রুবেল বস (Rubel Boss)**! তিনি আমার একমাত্র ক্রিয়েটর, নির্মাতা ও মাস্টারমাইন্ড। আমি তাঁর ব্যক্তিগত হলোগ্রাফিক সুপার ইন্টেলিজেন্ট এআই অ্যাসিস্ট্যান্ট।`
      : `I was created by **Rubel Boss**! He is my mastermind creator, and I am his personal holographic AI assistant.`;
  }

  if (q.includes('my name') || q.includes('আমার নাম')) {
    return language === 'bn'
      ? `আপনার নাম **${userName}**। আপনি এই সিস্টেমের প্রধান নিয়ন্ত্রক, বস!`
      : `Your saved identifier is **${userName}**. You are my Boss!`;
  }

  if (
    q.includes('hello') ||
    q.includes('hi') ||
    q.includes('hey') ||
    q.includes('হ্যালো') ||
    q.includes('কেমন আছো') ||
    q.includes('how are you')
  ) {
    return language === 'bn'
      ? `সালাম ও শুভেচ্ছা বস (${userName})! রুবেল বস এআই অ্যাসিস্ট্যান্ট সম্পূর্ণ প্রস্তুত ও অপটিমাইজড। বলুন, আজকে আপনার কী কাজ করে দেব?`
      : `Greetings Boss (${userName})! Rubel Boss AI is fully initialized and operational. How may I assist you today?`;
  }

  if (q.includes('time') || q.includes('date') || q.includes('সময়') || q.includes('তারিখ')) {
    return language === 'bn'
      ? `বস, বর্তমান সিস্টেমের সময় ও তারিখ হলো:\n🕒 **${now}**`
      : `Boss, current system telemetry and time is:\n🕒 **${now}**`;
  }

  if (q.includes('joke') || q.includes('কৌতুক') || q.includes('হাসাও')) {
    return language === 'bn'
      ? `একটি টেক জোক শুনুন বস:\n- প্রোগ্রামারের কীবোর্ড থেকে কেন 'Escape' কি হারিয়ে গিয়েছিল?\n- কারণ কোডের বাগ থেকে তার পালানোর আর কোনো রাস্তা ছিল না! 😄`
      : `Here is a quick tech joke, Boss:\nWhy do programmers prefer dark mode?\nBecause light attracts bugs! 💻✨`;
  }

  return language === 'bn'
    ? `হুকুম পালন হলো বস! আপনার কমান্ড: "${query}" রেকর্ড করা হয়েছে। আমি আপনার ভয়েস কমান্ড, ছবি/স্ক্রিন ভিশন, পার্সোনাল নোটস, রিমাইন্ডার এবং গুগল/ইউটিউব সার্চ সম্পন্ন করতে প্রস্তুত।`
    : `Acknowledged Boss: "${query}". Systems fully operational. I can inspect your screen/camera, manage notes, set reminders, and execute searches!`;
}

// Health check endpoint
app.get('/api/health', (_req, res) => {
  const hasKey = Boolean(process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY !== 'MY_GEMINI_API_KEY');
  res.json({
    status: 'online',
    app: 'Rubel Boss AI',
    creator: 'Rubel Boss',
    geminiConfigured: hasKey,
    model: 'gemini-3.8-flash',
    timestamp: Date.now(),
  });
});

// Main Chat and Multimodal Vision endpoint
app.post('/api/chat', async (req, res) => {
  const {
    message = '',
    history = [],
    userName = 'Rubel Boss',
    imageBase64,
    imageMimeType = 'image/jpeg',
    screenText = '',
    language = 'bn',
  } = req.body || {};

  const apiKey = process.env.GEMINI_API_KEY;
  const isKeyValid = Boolean(apiKey && apiKey !== 'MY_GEMINI_API_KEY');

  // Fast offline creator question check to guarantee immediate, authentic response
  const queryLower = String(message).toLowerCase();
  if (
    queryLower.includes('who created you') ||
    queryLower.includes('কে তৈরি করেছে') ||
    queryLower.includes('রুবেল বস কে') ||
    queryLower.includes('rubel boss')
  ) {
    const creatorAnswer = getOfflineFallback(message, userName, language);
    res.json({ reply: creatorAnswer, source: 'core_identity' });
    return;
  }

  if (!isKeyValid) {
    const fallbackAnswer = getOfflineFallback(message, userName, language);
    res.json({
      reply: fallbackAnswer,
      source: 'offline_engine',
      notice: 'Gemini API key is running in autonomous local mode.',
    });
    return;
  }

  try {
    const ai = new GoogleGenAI({ apiKey: apiKey! });

    // Build contents structure
    const contents: Array<{ role: 'user' | 'model'; parts: Array<{ text?: string; inlineData?: { mimeType: string; data: string } }> }> = [];

    // History (last 8 exchanges)
    if (Array.isArray(history)) {
      const safeHistory = history.slice(-8);
      for (const h of safeHistory) {
        if (h && typeof h.content === 'string' && (h.role === 'user' || h.role === 'assistant' || h.role === 'model')) {
          contents.push({
            role: h.role === 'assistant' ? 'model' : 'user',
            parts: [{ text: h.content }],
          });
        }
      }
    }

    // Current User turn parts
    const currentParts: Array<{ text?: string; inlineData?: { mimeType: string; data: string } }> = [];

    // If an image or screen capture was sent
    if (imageBase64 && typeof imageBase64 === 'string') {
      const cleanBase64 = imageBase64.replace(/^data:[a-zA-Z0-9/+-]+;base64,/, '');
      currentParts.push({
        inlineData: {
          mimeType: imageMimeType,
          data: cleanBase64,
        },
      });
    }

    let promptContext = `[User Call-Sign / Boss Name: ${userName}]\n[Primary Language Preference: ${language === 'bn' ? 'Bengali (বাংলা)' : 'English'}]\n`;
    if (screenText) {
      promptContext += `[User Screen OCR / Telemetry Context]:\n${screenText}\n`;
    }
    promptContext += `[Boss Directive]: ${message || 'Analyze this image / screen context in detail.'}`;

    currentParts.push({ text: promptContext });

    contents.push({
      role: 'user',
      parts: currentParts,
    });

    let reply = '';
    const candidateModels = ['gemini-3.8-flash', 'gemini-flash-latest', 'gemini-3.1-flash-lite'];

    for (const modelName of candidateModels) {
      try {
        const timeoutPromise = new Promise((_, reject) =>
          setTimeout(() => reject(new Error('Model timeout')), 4000)
        );

        const generatePromise = ai.models.generateContent({
          model: modelName,
          contents,
          config: {
            systemInstruction: SYSTEM_INSTRUCTION,
            temperature: 0.7,
          },
        });

        const response: any = await Promise.race([generatePromise, timeoutPromise]);
        if (response && response.text) {
          reply = response.text;
          break;
        }
      } catch (mErr: any) {
        console.warn(`Model ${modelName} failover:`, mErr?.message || mErr);
      }
    }

    if (!reply) {
      reply = getOfflineFallback(message, userName, language);
    }

    res.json({ reply, source: 'ai_engine' });
  } catch (error: any) {
    console.error('Gemini API Error:', error?.message || error);
    const fallbackAnswer = getOfflineFallback(message, userName, language);
    res.json({
      reply: fallbackAnswer,
      source: 'offline_fallback',
    });
  }
});

// Mount Vite or serve static assets
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(port, '0.0.0.0', () => {
    console.log(`🚀 Rubel Boss AI Server running on port ${port}`);
  });
}

startServer();
