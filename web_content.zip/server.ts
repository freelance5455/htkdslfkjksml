import express, { Request, Response } from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json({ limit: "2mb" }));

const SYSTEM_INSTRUCTION =
  "You are a master Urdu poet, lyricist, and literary expert. Your job is to compose high-quality original Urdu poetry (Ghazals, Nazms, Shayari), song lyrics, and competitive poetry verses. Ensure strong rhyme (Qafiya), refrain (Radeef), and poetic rhythm. Always respond clearly with beautifully structured Urdu text.";

interface GenerateRequestBody {
  mode: "ghazal_shayari" | "song_lyrics" | "bait_bazi" | "rhyme_meter";
  topic?: string;
  tone?: "romantic" | "emotional" | "philosophical" | "motivational" | "sufi";
  style?: "simple" | "classic";
  format?: "sher_2_line" | "qata_4_line" | "full_ghazal";
  genre?: "sufi" | "pop" | "classical" | "rap";
  letter?: string;
  baziType?: "counter_sher" | "powerful_verse" | "rare_gem";
  toolType?: "complete_sher" | "qafiya_finder" | "meter_check";
  userLine?: string;
}

// API Health / Config status
app.get("/api/health", (req: Request, res: Response) => {
  const hasEnvKey = Boolean(process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY !== "MY_GEMINI_API_KEY");
  res.json({
    status: "ok",
    hasServerKey: hasEnvKey,
    model: "gemini-3.8-flash"
  });
});

// Generation endpoint
app.post("/api/generate", async (req: Request, res: Response) => {
  try {
    const customKey = req.headers["x-gemini-api-key"] as string | undefined;
    const apiKey = (customKey && customKey.trim().length > 0)
      ? customKey.trim()
      : process.env.GEMINI_API_KEY;

    if (!apiKey || apiKey === "MY_GEMINI_API_KEY") {
      return res.status(401).json({
        error: "کوئی Gemini API Key دستیاب نہیں ہے۔ برائے مہربانی ایپ کی سیٹنگز میں اپنی Gemini API Key درج کریں یا ماحولیاتی متغیر سیٹ کریں۔",
        code: "MISSING_API_KEY",
        detail: "No valid Gemini API key found. Please provide one in the Settings tab."
      });
    }

    const {
      mode = "ghazal_shayari",
      topic = "عشق و محبت",
      tone = "romantic",
      style = "classic",
      format = "sher_2_line",
      genre = "sufi",
      letter = "ن",
      baziType = "counter_sher",
      toolType = "complete_sher",
      userLine = ""
    } = req.body as GenerateRequestBody;

    const toneMap: Record<string, string> = {
      romantic: "رومانوی اور پرکشش (Romantic & Passionate)",
      emotional: "حزنیہ، پردرد اور جذباتی (Emotional & Melancholic)",
      philosophical: "فلسفیانہ اور فکری (Philosophical & Thought-provoking)",
      motivational: "حوصلہ افزا، ولولہ انگیز اور انقلابی (Motivational & Inspiring)",
      sufi: "صوفیانہ، روحانی اور عارفانہ (Sufi & Spiritual)"
    };

    const styleMap: Record<string, string> = {
      simple: "سادہ اور عام فہم اردو (Simple modern Urdu with natural flow)",
      classic: "کلاسیکی، فصیح و بلیغ ادبی اردو (Classic literary Urdu with rich metaphors like Mir, Ghalib, Iqbal)"
    };

    let userPrompt = "";

    if (mode === "ghazal_shayari") {
      const formatMap: Record<string, string> = {
        sher_2_line: "ایک انتہائی لاجواب اور یادگار ۲ سطری شعر (2-line Sher with exact rhyme and meter)",
        qata_4_line: "ایک بامقصد اور گہرا ۴ سطری قطعہ (4-line Qat'a)",
        full_ghazal: "ایک مکمل اور مربوط غزل (Full Ghazal consisting of 5 to 7 couplets, including Matla مطلع with double rhyme and Maqta مقطع with Takhallus تخلص)"
      };

      userPrompt = `Compose an original, master-level Urdu poetry piece:
- Type / Format: ${formatMap[format] || "2-line Sher"}
- Central Topic / Theme: "${topic}"
- Tone / Emotion: ${toneMap[tone] || tone}
- Linguistic Style: ${styleMap[style] || style}

Instructions:
1. Provide the main Urdu poetry prominently formatted with proper line breaks.
2. Clearly identify the Qafiya (قافیہ) and Radeef (ردیف).
3. State the Behr/Meter (بحر / وزن) or rhythmic cadence.
4. Give a brief Roman Urdu transliteration so recitation is easy.
5. Provide a 1-2 sentence literary appreciation/meaning (شرح / مفہوم).`;
    } else if (mode === "song_lyrics") {
      const genreMap: Record<string, string> = {
        sufi: "صوفی کلام / قوالی طرز (Sufi Mystic Song with deep trance-like spiritual hook)",
        pop: "جدید پاپ سانگ (Modern Pop Song with catchy rhythmic grooves)",
        classical: "کلاسیکی غزل نما گیت / ٹھمری انداز (Semi-classical lyrical composition)",
        rap: "اردو ہپ ہاپ / ریپ لیرکس (Urdu Hip-Hop / Rap with intricate internal multisyllabic rhymes and hard-hitting flow)"
      };

      userPrompt = `Write complete, professional song lyrics in Urdu:
- Music Genre: ${genreMap[genre] || genre}
- Song Theme / Story: "${topic}"
- Tone / Mood: ${toneMap[tone] || tone}
- Vocabulary Style: ${styleMap[style] || style}

Structure required:
- Hook / Mukhda (مکھڑا / ٹیک) - Catchy and memorable
- Verse 1 (پہلا بند / انترہ) - Developing the narrative
- Chorus (کورَس / استھائی) - High emotional energy
- Verse 2 (دوسرا بند) - Climax and resolution
- Outro (اختتامیہ) - Echoing fade-out

Also include BPM / tempo recommendation and vocal delivery notes for the singer/artist.`;
    } else if (mode === "bait_bazi") {
      userPrompt = `Generate victory-grade competitive Urdu poetry for Bait Bazi (بیت بازی و مقابلہ):
- Required Starting Letter (حرف): "${letter}" (The verse MUST strictly start with this Urdu letter!)
- Preferred Topic / Flavor: "${topic || "فکری و یادگار"}"
- Category: ${baziType === "counter_sher" ? "فوری جوابی شعر (Quick Counter Verse)" : baziType === "rare_gem" ? "نایاب و پر اثر شعر (Rare Classic Gem)" : "طاقتور مقابلہ جاتی شعر (Powerful Competition Winner)"}
- Tone: ${toneMap[tone] || tone}
- Style: ${styleMap[style] || style}

Requirements:
1. The first misra (مصرعِ اول) MUST begin with the letter "${letter}".
2. The verse must be extremely powerful, rhythmically flawless, and impactful in a competition.
3. State whether it is by a legendary master poet (e.g. Allama Iqbal, Mirza Ghalib, Mir Taqi Mir, Faiz Ahmad Faiz, Ahmad Faraz, Parveen Shakir) or an authentic original composition.
4. Provide the ending letter of the second line so the competitor knows what letter their opponent will have to respond with!`;
    } else if (mode === "rhyme_meter") {
      if (toolType === "complete_sher") {
        userPrompt = `The user has an incomplete Urdu poetry line or concept:
User Line (نامکمل مصرع / خیال): "${userLine || topic}"
Desired Tone: ${toneMap[tone] || tone}
Style: ${styleMap[style] || style}

Task:
1. Provide 3 brilliant options to complete this sher (مصرعِ ثانی کے ۳ لاجواب متبادل).
2. Ensure both lines adhere to the exact same poetic meter (بحر و وزن) and provide crisp Qafiya & Radeef.
3. Explain which option is best suited for what context.`;
      } else if (toolType === "qafiya_finder") {
        userPrompt = `Find rich, poetic rhyming words (ہم قافیہ الفاظ) in Urdu for:
Base word / sound or user line: "${userLine || topic}"
Poetic Style: ${styleMap[style] || style}

Task:
1. Provide a curated list of 10-15 high-caliber Urdu rhyming words (قافیہ).
2. Group them by category (Emotional/Sad, Romantic, Philosophical).
3. Demonstrate 2 sample couplets using these Qafiyas with matching Radeef (ردیف).`;
      } else {
        userPrompt = `Analyze and refine the meter (بحر، وزن اور تقطیع) of this Urdu poetry line:
User Verse: "${userLine || topic}"

Task:
1. Evaluate the rhythmic balance (وزن و آہنگ).
2. Point out any syllable flaws (سکوت یا عیبِ تقطیع) if present, or confirm if it is in perfect rhythm.
3. Suggest the polished, rhythmically perfected version.`;
      }
    }

    const ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build"
        }
      }
    });

    // Try high-speed and responsive flash models
    const candidateModels = ["gemini-3.1-flash-lite", "gemini-3.8-flash", "gemini-flash-latest"];
    let rawText = "";
    let lastError: any = null;

    for (const modelName of candidateModels) {
      try {
        const response = await ai.models.generateContent({
          model: modelName,
          contents: userPrompt,
          config: {
            systemInstruction: SYSTEM_INSTRUCTION,
            temperature: 0.85
          }
        });

        if (response.text && response.text.trim().length > 0) {
          rawText = response.text;
          break;
        }
      } catch (err: any) {
        lastError = err;
        console.warn(`Model ${modelName} failed, attempting next candidate...`, err?.message || err);
      }
    }

    if (!rawText && lastError) {
      throw lastError;
    }

    res.json({
      success: true,
      text: rawText,
      mode,
      topic,
      timestamp: new Date().toISOString()
    });
  } catch (err: any) {
    console.error("Gemini API Error in /api/generate:", err);

    let clientMessage = "شاعری کی تخلیق کے دوران ایک غیر متوقع خرابی پیش آئی ہے۔ برائے مہربانی دوبارہ کوشش کریں۔";
    const errorMessage = err?.message || String(err);

    if (errorMessage.includes("API key not valid") || errorMessage.includes("INVALID_ARGUMENT") || errorMessage.includes("401")) {
      clientMessage = "درج شدہ Gemini API Key درست نہیں ہے۔ برائے مہربانی Settings میں جا کر درست کلید کی تصدیق کریں۔";
    } else if (errorMessage.includes("RESOURCE_EXHAUSTED") || errorMessage.includes("429") || errorMessage.includes("quota")) {
      clientMessage = "API کے استعمال کی حد (Quota Limit) مکمل ہو گئی ہے۔ براہ کرم تھوڑی دیر بعد کوشش کریں۔";
    } else if (errorMessage.includes("fetch failed") || errorMessage.includes("network") || errorMessage.includes("ECONNREFUSED")) {
      clientMessage = "انٹرنیٹ کنکشن منقطع ہو گیا ہے یا سرور سے رابطہ نہیں ہو پا رہا ہے۔";
    }

    res.status(500).json({
      error: clientMessage,
      detail: errorMessage,
      code: "GENERATION_FAILED"
    });
  }
});

async function startServer() {
  // Vite middleware in dev
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Hassan's MisraSaaz AI server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
