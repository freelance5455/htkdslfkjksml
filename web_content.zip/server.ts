import express from 'express';
import path from 'path';
import fs from 'fs';
import crypto from 'crypto';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';

dotenv.config();

const HASH_SALT_SECRET = 'onu_finance_cloud_sync_salt_2026';

function hashPassword(password: string): string {
  return crypto.pbkdf2Sync(password, HASH_SALT_SECRET, 1000, 64, 'sha512').toString('hex');
}

const USERS_DIR = path.join(process.cwd(), 'data', 'users');
if (!fs.existsSync(USERS_DIR)) {
  fs.mkdirSync(USERS_DIR, { recursive: true });
}

function getSafeUserId(userId: string): string {
  return (userId || '')
    .trim()
    .toLowerCase()
    .replace(/[\/\\:*?"<>|\x00-\x1F\s]/g, '_')
    .replace(/\.{2,}/g, '_');
}

function getUserFilePath(userId: string): string {
  const safeId = getSafeUserId(userId);
  return path.join(USERS_DIR, `${safeId}.json`);
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Set permissive CORS headers for all incoming requests (including iframe embedding)
  app.use((req, res, next) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
    if (req.method === 'OPTIONS') {
      return res.sendStatus(200);
    }
    next();
  });

  app.use(express.json({ limit: '10mb' }));

  // Service Worker and registration script handler
  app.get(['/registerSW.js', '/dev-sw.js'], (req, res) => {
    res.setHeader('Content-Type', 'application/javascript; charset=utf-8');
    if (process.env.NODE_ENV === 'production') {
      const distFilePath = path.join(process.cwd(), 'dist', 'registerSW.js');
      if (fs.existsSync(distFilePath)) {
        return res.sendFile(distFilePath);
      }
    }
    // In dev mode or fallback: safely unregister any lingering service worker
    return res.send(`if (typeof navigator !== 'undefined' && 'serviceWorker' in navigator) {
  navigator.serviceWorker.getRegistrations().then(function(regs) {
    for (var i = 0; i < regs.length; i++) { regs[i].unregister(); }
  }).catch(function() {});
}\n`);
  });

  app.get('/sw.js', (req, res) => {
    res.setHeader('Content-Type', 'application/javascript; charset=utf-8');
    if (process.env.NODE_ENV === 'production') {
      const distFilePath = path.join(process.cwd(), 'dist', 'sw.js');
      if (fs.existsSync(distFilePath)) {
        return res.sendFile(distFilePath);
      }
    }
    // In dev mode: clean unregistration without precache errors
    return res.send(`self.addEventListener('install', function() { self.skipWaiting(); });
self.addEventListener('activate', function(e) {
  e.waitUntil(self.registration.unregister().then(function() { return self.clients.claim(); }));
});\n`);
  });

  // Handle workbox scripts directly
  app.get(['/workbox-*.js', '*/workbox-*.js'], (req, res) => {
    const filename = path.basename(req.path);
    const distFilePath = path.join(process.cwd(), 'dist', filename);
    const publicFilePath = path.join(process.cwd(), 'public', filename);

    if (fs.existsSync(distFilePath)) {
      res.setHeader('Content-Type', 'application/javascript; charset=utf-8');
      return res.sendFile(distFilePath);
    }
    if (fs.existsSync(publicFilePath)) {
      res.setHeader('Content-Type', 'application/javascript; charset=utf-8');
      return res.sendFile(publicFilePath);
    }

    res.setHeader('Content-Type', 'application/javascript; charset=utf-8');
    return res.send('// Workbox placeholder\n');
  });

  // Prevent missing root scripts or style assets from falling through to HTML index
  app.use((req, res, next) => {
    if (req.path.endsWith('.js') || req.path.endsWith('.mjs') || req.path.endsWith('.css') || req.path.endsWith('.map')) {
      if (req.path.startsWith('/@') || req.path.startsWith('/src') || req.path.startsWith('/node_modules')) {
        return next();
      }
      const publicPath = path.join(process.cwd(), 'public', req.path);
      const distPath = path.join(process.cwd(), 'dist', req.path);
      if (fs.existsSync(publicPath)) {
        return res.sendFile(publicPath);
      }
      if (fs.existsSync(distPath)) {
        return res.sendFile(distPath);
      }
      res.setHeader('Content-Type', req.path.endsWith('.css') ? 'text/css; charset=utf-8' : 'application/javascript; charset=utf-8');
      return res.status(404).send('// Static asset not found\n');
    }
    next();
  });

  // Initialize Gemini lazily inside route handler
  const getGeminiClient = () => {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error('GEMINI_API_KEY is not configured');
    }
    return new GoogleGenAI({ apiKey });
  };

  // Health check API
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', app: 'TakaTracker Bangla Finance' });
  });

  // AI Financial Advisor Endpoint
  app.post('/api/advisor', async (req, res) => {
    try {
      const { income, expense, topCategories, month, budgetStatus, customQuestion } = req.body;

      const ai = getGeminiClient();
      
      const prompt = `
আপনি একজন অত্যন্ত অভিজ্ঞ বাংলাদেশী ব্যক্তিগত অর্থ উপদেষ্টা (Personal Financial Advisor).
ব্যবহারকারীর মাসিক হিসাব সম্পর্কিত নিম্নরূপ তথ্য দেওয়া হয়েছে:
- মাস: ${month || 'চলতি মাস'}
- মোট আয়: ৳${income || 0}
- মোট খরচ: ৳${expense || 0}
- প্রধান খরচের খাতসমূহ: ${JSON.stringify(topCategories || [])}
- বাজেট অবস্থা: ${budgetStatus || 'স্বাভাবিক'}
${customQuestion ? `- ব্যবহারকারীর অতিরিক্ত প্রশ্ন: "${customQuestion}"` : ''}

অনুগ্রহ করে অত্যন্ত সহজ, বন্ধুত্বপূর্ণ ও চমৎকার বাংলা ভাষায় ৪টি পয়েন্টে বাস্তবসম্মত অর্থ সাশ্রয় ও বাজেট পরামর্শ প্রদান করুন:
১. আয় ও খরচের সামঞ্জস্যের ওপর সংক্ষেপ মন্তব্য।
২. খরচের খাত বিশ্লেষণ (কোথায় অযথা খরচ বা বাজেট অতিরিক্ত হচ্ছে)।
৩. ৩টি বাস্তবসম্মত অর্থ সাশ্রয়ের টিপস (বিশেষ করে বর্তমান বাংলাদেশ প্রেক্ষাপট অনুযায়ী)।
৪. জরুরি ফান্ডের (Emergency Fund) জন্য ১টি সুস্পষ্ট পরামর্শ।

উত্তরের ভাষা হবে প্রাঞ্জল, উৎসাহব্যঞ্জক ও গঠনমূলক।
`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.1-flash-lite',
        contents: prompt,
      });

      res.json({
        success: true,
        advice: response.text || 'আর্থিক পরামর্শ তৈরি করা সম্ভব হয়নি।',
      });
    } catch (error: any) {
      console.error('Advisor API error:', error);
      res.status(500).json({
        success: false,
        error: error?.message || 'Gemini API Error',
      });
    }
  });

  // ==========================================
  // Cloud User ID & Multi-Device Sync APIs
  // ==========================================

  // Check if a User ID is available
  app.get('/api/auth/check-user', (req, res) => {
    try {
      const rawUserId = String(req.query.userId || '').trim();
      if (!rawUserId) {
        return res.status(400).json({ success: false, error: 'User ID is required' });
      }
      const safeId = getSafeUserId(rawUserId);
      if (safeId.length < 3) {
        return res.status(400).json({ success: false, error: 'User ID must be at least 3 characters' });
      }
      const filePath = getUserFilePath(safeId);
      const exists = fs.existsSync(filePath);
      return res.json({ success: true, userId: safeId, exists, available: !exists });
    } catch (err: any) {
      console.error('Check user error:', err);
      return res.status(500).json({ success: false, error: 'Failed to verify User ID' });
    }
  });

  // Register / Create a new User ID with Cloud Sync
  app.post('/api/auth/register', (req, res) => {
    try {
      const { userId, password, profile, dataEnvelope } = req.body || {};
      const cleanUserId = getSafeUserId(userId);

      if (!cleanUserId || cleanUserId.length < 3) {
        return res.status(400).json({
          success: false,
          error: 'ইউজার আইডি কমপক্ষে ৩ অক্ষরের হতে হবে (User ID must be at least 3 characters)',
        });
      }

      if (!password || String(password).trim().length < 4) {
        return res.status(400).json({
          success: false,
          error: 'পাসওয়ার্ড কমপক্ষে ৪ অক্ষরের হতে হবে (Password must be at least 4 characters)',
        });
      }

      const userFilePath = getUserFilePath(cleanUserId);
      if (fs.existsSync(userFilePath)) {
        return res.status(409).json({
          success: false,
          error: 'এই ইউজার আইডিটি ইতিমধ্যে ব্যবহৃত হয়েছে। অনুগ্রহ করে অন্য আইডি দিন অথবা লগইন করুন। (User ID already exists)',
        });
      }

      const nowIso = new Date().toISOString();
      const userRecord = {
        userId: cleanUserId,
        passwordHash: hashPassword(String(password).trim()),
        createdAt: nowIso,
        updatedAt: nowIso,
        profile: {
          ...(profile || {}),
          userId: cleanUserId,
          isProfileCompleted: true,
          lastSyncedAt: nowIso,
        },
        dataEnvelope: dataEnvelope || null,
      };

      fs.writeFileSync(userFilePath, JSON.stringify(userRecord, null, 2), 'utf-8');
      console.log(`[Cloud Sync] New user registered: ${cleanUserId}`);

      return res.json({
        success: true,
        userId: cleanUserId,
        profile: userRecord.profile,
        lastSyncedAt: nowIso,
        message: 'ইউজার আইডি সফলভাবে তৈরি হয়েছে এবং ক্লাউডে সংরক্ষিত হয়েছে।',
      });
    } catch (err: any) {
      console.error('Register user error:', err);
      return res.status(500).json({
        success: false,
        error: 'ইউজার আইডি রেজিস্ট্রেশন করতে ব্যর্থ হয়েছে: ' + (err?.message || 'Server error'),
      });
    }
  });

  // Login with existing User ID and fetch all previous data for auto-sync across devices
  app.post('/api/auth/login', (req, res) => {
    try {
      const { userId, password } = req.body || {};
      const cleanUserId = getSafeUserId(userId);

      if (!cleanUserId || !password) {
        return res.status(400).json({
          success: false,
          error: 'ইউজার আইডি ও পাসওয়ার্ড উভয়ই আবশ্যক (Both User ID and Password are required)',
        });
      }

      const userFilePath = getUserFilePath(cleanUserId);
      if (!fs.existsSync(userFilePath)) {
        return res.status(404).json({
          success: false,
          error: 'এই ইউজার আইডিটি পাওয়া যায়নি। অনুগ্রহ করে সঠিক আইডি লিখুন বা নতুন আইডি তৈরি করুন। (User ID not found)',
        });
      }

      const raw = fs.readFileSync(userFilePath, 'utf-8');
      const userRecord = JSON.parse(raw);

      const computedHash = hashPassword(String(password).trim());
      if (computedHash !== userRecord.passwordHash) {
        return res.status(401).json({
          success: false,
          error: 'ভুল পাসওয়ার্ড! অনুগ্রহ করে সঠিক পাসওয়ার্ড দিন। (Incorrect password)',
        });
      }

      console.log(`[Cloud Sync] User authenticated & data synced: ${cleanUserId}`);

      return res.json({
        success: true,
        userId: cleanUserId,
        profile: userRecord.profile,
        data: userRecord.dataEnvelope,
        lastSyncedAt: userRecord.updatedAt,
        message: 'সফলভাবে লগইন হয়েছে এবং সকল তথ্য সিঙ্ক সম্পন্ন হয়েছে।',
      });
    } catch (err: any) {
      console.error('Login error:', err);
      return res.status(500).json({
        success: false,
        error: 'লগইন প্রক্রিয়ায় সমস্যা হয়েছে: ' + (err?.message || 'Server error'),
      });
    }
  });

  // Push latest data updates from device to cloud
  app.post('/api/sync/push', (req, res) => {
    try {
      const { userId, password, dataEnvelope, profile } = req.body || {};
      const cleanUserId = getSafeUserId(userId);

      if (!cleanUserId || !password) {
        return res.status(400).json({ success: false, error: 'Authentication required' });
      }

      const userFilePath = getUserFilePath(cleanUserId);
      if (!fs.existsSync(userFilePath)) {
        return res.status(404).json({ success: false, error: 'User ID not found' });
      }

      const userRecord = JSON.parse(fs.readFileSync(userFilePath, 'utf-8'));
      if (hashPassword(String(password).trim()) !== userRecord.passwordHash) {
        return res.status(401).json({ success: false, error: 'Unauthorized credentials' });
      }

      const nowIso = new Date().toISOString();
      if (dataEnvelope) {
        userRecord.dataEnvelope = dataEnvelope;
      }
      if (profile) {
        userRecord.profile = {
          ...userRecord.profile,
          ...profile,
          userId: cleanUserId,
          lastSyncedAt: nowIso,
        };
      }
      userRecord.updatedAt = nowIso;

      fs.writeFileSync(userFilePath, JSON.stringify(userRecord, null, 2), 'utf-8');

      return res.json({
        success: true,
        lastSyncedAt: nowIso,
        message: 'ক্লাউডে সফলভাবে সকল তথ্য সিঙ্ক হয়েছে।',
      });
    } catch (err: any) {
      console.error('Push sync error:', err);
      return res.status(500).json({ success: false, error: 'Failed to push sync: ' + err?.message });
    }
  });

  // Pull latest data updates from cloud to device
  app.post('/api/sync/pull', (req, res) => {
    try {
      const { userId, password } = req.body || {};
      const cleanUserId = getSafeUserId(userId);

      if (!cleanUserId || !password) {
        return res.status(400).json({ success: false, error: 'Authentication required' });
      }

      const userFilePath = getUserFilePath(cleanUserId);
      if (!fs.existsSync(userFilePath)) {
        return res.status(404).json({ success: false, error: 'User ID not found' });
      }

      const userRecord = JSON.parse(fs.readFileSync(userFilePath, 'utf-8'));
      if (hashPassword(String(password).trim()) !== userRecord.passwordHash) {
        return res.status(401).json({ success: false, error: 'Unauthorized credentials' });
      }

      return res.json({
        success: true,
        userId: cleanUserId,
        profile: userRecord.profile,
        data: userRecord.dataEnvelope,
        lastSyncedAt: userRecord.updatedAt,
      });
    } catch (err: any) {
      console.error('Pull sync error:', err);
      return res.status(500).json({ success: false, error: 'Failed to pull sync: ' + err?.message });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      // Do not serve index.html for requests targeting missing static files (scripts, stylesheets, images)
      if (req.path.includes('.') && !req.path.endsWith('.html')) {
        return res.status(404).end();
      }
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`TakaTracker Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
});
