import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { GoogleGenAI, GenerateVideosOperation } from '@google/genai';
import AdmZip from 'adm-zip';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = Number(process.env.PORT) || 3000;

// Allow body payload for image upload
app.use(express.json({ limit: '30mb' }));
app.use(express.urlencoded({ extended: true, limit: '30mb' }));

const apiKey = process.env.GEMINI_API_KEY || '';
const ai = apiKey
  ? new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    })
  : null;

// Health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', hasKey: !!apiKey });
});

// Download full project as ZIP file
app.get(
  ['/api/download-zip', '/download.zip', '/arhan-ai-learning-app.zip', '/arhan-source-code.zip'],
  (req, res) => {
    try {
      const existingZip = path.join(__dirname, 'arhan-ai-learning-app.zip');
      if (fs.existsSync(existingZip)) {
        res.setHeader('Content-Type', 'application/zip');
        res.setHeader('Content-Disposition', 'attachment; filename="arhan-ai-learning-app.zip"');
        return res.sendFile(existingZip);
      }

      const zip = new AdmZip();

      function addFiles(dir: string, zipDir: string = '') {
        const entries = fs.readdirSync(dir, { withFileTypes: true });
        for (const entry of entries) {
          const fullPath = path.join(dir, entry.name);
          const subZipDir = zipDir ? `${zipDir}/${entry.name}` : entry.name;
          if (
            entry.name === 'node_modules' ||
            entry.name === 'dist' ||
            entry.name === '.git' ||
            entry.name.endsWith('.zip')
          ) {
            continue;
          }

          if (entry.isDirectory()) {
            addFiles(fullPath, subZipDir);
          } else {
            zip.addLocalFile(fullPath, zipDir);
          }
        }
      }

      addFiles(__dirname);
      const buffer = zip.toBuffer();

      res.setHeader('Content-Type', 'application/zip');
      res.setHeader('Content-Disposition', 'attachment; filename="arhan-ai-learning-app.zip"');
      res.send(buffer);
    } catch (error: any) {
      console.error('Zip download error:', error);
      if (!res.headersSent) {
        res.status(500).json({ error: error.message });
      }
    }
  }
);

// AI Chat for Arhan
app.post('/api/gemini/chat', async (req, res) => {
  const { message, childName = 'ارہان', topic = 'general', history = [] } = req.body;

  const defaultQuickReplies: Record<string, string[]> = {
    urdu: ['الف سے کیا بنتا ہے؟', 'ب سے بلی سنائیں', 'تتلی والا شعر', 'اگلا حرف سکھائیں'],
    english: ['A for Apple', 'B for Butterfly', 'Sing ABC song', 'Next letter please'],
    math: ['1 2 3 گنتی', 'پانچ انگلیاں دکھائیں', 'ایک سیب، دو سیب', 'کوئز پوچھیں'],
    general: ['الف بے تے پڑھیں', 'ABC پڑھیں', '1 2 3 گنتی سنیں', 'ارہان کو شاباش دیں'],
  };

  if (!ai) {
    return res.status(200).json({
      text: `السلام علیکم ${childName} بیٹا! شاباش! میاں بھالو آپ کے ساتھ ہے۔ آئیں ہم مل کر مزے سے پڑھیں! 🌟`,
      quickReplies: defaultQuickReplies[topic] || defaultQuickReplies.general,
    });
  }

  try {
    const systemInstruction = `
You are 'استاد میاں بھالو' (Teacher Teddy Bear), a loving, joyful, gentle, and enthusiastic AI preschool teacher.
You are talking directly to a young boy named ${childName} (ارہان). His father wants him to learn:
1. Urdu Haroof-e-Tahajji (الف، ب، پ، ت، ٹ، ث، ج، چ، ح، خ...) with phonics and examples (ا سے انار، ب سے بلی، پ سے پتنگ، ت سے تتلی...)
2. English Alphabet (A, B, C, D...) with phonics (A for Apple, B for Ball...)
3. Numbers & Counting (1, 2, 3... and ایک، دو، تین...)

RULES FOR TEACHING ${childName}:
- Always address him with affection: "${childName} بیٹا", "پیارے ${childName}!", "شاباش ${childName}!".
- Speak in cheerful, simple, melodic Urdu (with English words where appropriate for ABC / 123 lessons).
- Keep each reply short (2 to 4 sentences maximum) so a young child stays attentive.
- Use fun emojis (🧸, 🌟, 🎈, 🍎, 🐱, 👏, 🎨).
- Offer 3-4 simple, child-friendly quick replies for him to tap next.
- Current topic context: ${topic}.
`;

    // Construct conversation messages
    const formattedContents: Array<{ role: string; parts: Array<{ text: string }> }> = [];
    if (Array.isArray(history)) {
      for (const h of history.slice(-6)) {
        formattedContents.push({
          role: h.role === 'user' ? 'user' : 'model',
          parts: [{ text: h.text || '' }],
        });
      }
    }
    formattedContents.push({
      role: 'user',
      parts: [{ text: message || `السلام علیکم! میں ${childName} ہوں۔ مجھے کچھ پڑھائیں۔` }],
    });

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: formattedContents,
      config: {
        systemInstruction,
        temperature: 0.7,
      },
    });

    const replyText = response.text || `شاباش ${childName} بیٹا! آپ بہت اچھے بچے ہیں۔`;

    res.json({
      text: replyText,
      quickReplies: defaultQuickReplies[topic] || defaultQuickReplies.general,
    });
  } catch (error: any) {
    // Check if rate limited or quota exceeded
    const isQuota =
      error?.status === 429 ||
      error?.status === 'RESOURCE_EXHAUSTED' ||
      String(error?.message || '').includes('429') ||
      String(error?.message || '').includes('quota');

    if (!isQuota) {
      console.warn('Chat non-quota issue:', error?.message);
    }

    res.status(200).json({
      text: `السلام علیکم ${childName} بیٹا! آپ بہت پیارے اور ذہین بچے ہیں۔ میاں بھالو آپ کے ساتھ ہے، آئیں مل کر الف بے اور اے بی سی پڑھیں! 🌟`,
      quickReplies: defaultQuickReplies[topic] || defaultQuickReplies.general,
      quotaExceeded: isQuota,
    });
  }
});

// Text-to-Speech endpoint
app.post('/api/gemini/tts', async (req, res) => {
  const { text } = req.body;
  if (!text || !ai) {
    return res.json({ audio: null, fallback: true });
  }

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash-lite-tts',
      contents: [
        {
          role: 'user',
          parts: [
            {
              text: text.slice(0, 300),
              speechMetadata: {
                style: 'Gentle, friendly, cheerful preschool teacher speaking clearly with warmth to a child',
              },
            },
          ],
        },
      ],
      config: {
        responseModalities: ['AUDIO'],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: 'Zephyr' },
          },
        },
      },
    });

    const audioData = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    if (audioData) {
      return res.json({ audio: audioData, format: 'pcm', sampleRate: 24000 });
    } else {
      return res.json({ audio: null, fallback: true });
    }
  } catch (error: any) {
    // Quota reached or 429 - handle gracefully without stderr logging
    const isQuota =
      error?.status === 429 ||
      error?.status === 'RESOURCE_EXHAUSTED' ||
      String(error?.message || '').includes('quota') ||
      String(error?.message || '').includes('429');

    // Return 200 with fallback instruction so client seamlessly uses Web Speech
    return res.status(200).json({
      audio: null,
      fallback: true,
      quotaExceeded: isQuota,
      message: 'Using local Web Speech audio engine',
    });
  }
});

// Veo Video Generation (Animate images into video feature)
// Step 1: Start video generation
app.post('/api/generate-video', async (req, res) => {
  try {
    const { prompt, imageBase64, mimeType = 'image/jpeg', aspectRatio = '16:9' } = req.body;

    if (!ai) {
      return res.status(200).json({
        success: false,
        quotaExceeded: true,
        message: 'Gemini API key is not configured for video generation.',
      });
    }

    if (!imageBase64) {
      return res.status(400).json({ error: 'Image is required' });
    }

    // Clean base64 string
    const cleanedBase64 = imageBase64.replace(/^data:image\/[a-zA-Z0-9]+;base64,/, '');

    const modelToUse = 'veo-3.1-fast-generate-preview';

    let operation;
    try {
      operation = await ai.models.generateVideos({
        model: modelToUse,
        prompt: prompt || 'Bring this photo to life with gentle, joyful, magical cinematic animation suitable for a children cartoon learning show',
        image: {
          imageBytes: cleanedBase64,
          mimeType: mimeType || 'image/jpeg',
        },
        config: {
          numberOfVideos: 1,
          resolution: '720p',
          aspectRatio: aspectRatio as '16:9' | '9:16',
        },
      });
    } catch (primaryErr: any) {
      const isQuota =
        primaryErr?.status === 429 ||
        primaryErr?.status === 'RESOURCE_EXHAUSTED' ||
        String(primaryErr?.message || '').includes('429') ||
        String(primaryErr?.message || '').includes('quota');

      if (isQuota) {
        // Return structured 200 so the client can trigger instant magical animation
        return res.status(200).json({
          success: false,
          quotaExceeded: true,
          message: 'Veo video quota limit reached on this project. Switching to magical client animation.',
        });
      }

      // Try fallback to veo-3.1-lite-generate-preview
      try {
        operation = await ai.models.generateVideos({
          model: 'veo-3.1-lite-generate-preview',
          prompt: prompt || 'Bring this photo to life with gentle animation',
          image: {
            imageBytes: cleanedBase64,
            mimeType: mimeType || 'image/jpeg',
          },
          config: {
            numberOfVideos: 1,
            resolution: '720p',
            aspectRatio: aspectRatio as '16:9' | '9:16',
          },
        });
      } catch (liteErr: any) {
        return res.status(200).json({
          success: false,
          quotaExceeded: true,
          message: 'Veo video quota limit reached on this project.',
        });
      }
    }

    if (operation?.name) {
      return res.json({ success: true, operationName: operation.name });
    } else {
      return res.status(200).json({
        success: false,
        quotaExceeded: true,
        message: 'Could not start operation',
      });
    }
  } catch (error: any) {
    const isQuota =
      error?.status === 429 ||
      error?.status === 'RESOURCE_EXHAUSTED' ||
      String(error?.message || '').includes('429') ||
      String(error?.message || '').includes('quota');

    return res.status(200).json({
      success: false,
      quotaExceeded: isQuota,
      message: error?.message || 'Video generation quota unavailable',
    });
  }
});

// Step 2: Poll video operation status
app.post('/api/video-status', async (req, res) => {
  try {
    const { operationName } = req.body;
    if (!ai || !operationName) {
      return res.status(400).json({ error: 'Operation name and API key required' });
    }

    const op = new GenerateVideosOperation();
    op.name = operationName;
    const updated = await ai.operations.getVideosOperation({ operation: op });

    res.json({
      done: updated.done,
      error: updated.error,
    });
  } catch (error: any) {
    res.status(200).json({
      done: false,
      error: { message: error?.message || 'Status check error' },
    });
  }
});

// Step 3: Download video stream
app.post('/api/video-download', async (req, res) => {
  try {
    const { operationName } = req.body;
    if (!ai || !operationName || !apiKey) {
      return res.status(400).json({ error: 'Operation name and API key required' });
    }

    const op = new GenerateVideosOperation();
    op.name = operationName;
    const updated = await ai.operations.getVideosOperation({ operation: op });

    const uri = updated.response?.generatedVideos?.[0]?.video?.uri;
    if (!uri) {
      return res.status(404).json({ error: 'No video URI found in completed operation' });
    }

    const videoRes = await fetch(uri, {
      headers: { 'x-goog-api-key': apiKey },
    });

    if (!videoRes.ok) {
      throw new Error(`Failed to fetch video: ${videoRes.status} ${videoRes.statusText}`);
    }

    res.setHeader('Content-Type', 'video/mp4');
    const buffer = Buffer.from(await videoRes.arrayBuffer());
    res.send(buffer);
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Failed to download video' });
  }
});

// Start Express + Vite
async function startServer() {
  if (process.env.NODE_ENV === 'production') {
    app.use(express.static(path.join(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.join(__dirname, 'dist', 'index.html'));
    });
  } else {
    const vite = await createViteServer({
      server: { middlewareMode: true, hmr: process.env.DISABLE_HMR !== 'true' },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running at http://0.0.0.0:${PORT}`);
  });
}

startServer();
