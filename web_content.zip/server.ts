import express, { Request, Response } from 'express';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import multer from 'multer';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;
const isProd = process.env.NODE_ENV === 'production';

// Ensure data and uploads directory exist
const DATA_DIR = path.resolve(__dirname, 'data');
const UPLOADS_DIR = path.resolve(__dirname, 'uploads');
const VIDEOS_UPLOAD_DIR = path.resolve(UPLOADS_DIR, 'videos');
const THUMBS_UPLOAD_DIR = path.resolve(UPLOADS_DIR, 'thumbnails');

[DATA_DIR, UPLOADS_DIR, VIDEOS_UPLOAD_DIR, THUMBS_UPLOAD_DIR].forEach((dir) => {
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
});

const VIDEOS_FILE = path.resolve(DATA_DIR, 'videos.json');
const USER_DATA_FILE = path.resolve(DATA_DIR, 'user_data.json');

// Initialize user data file if not present
if (!fs.existsSync(USER_DATA_FILE)) {
  fs.writeFileSync(
    USER_DATA_FILE,
    JSON.stringify(
      {
        myList: ['vid-tears-of-steel', 'vid-sintel'],
        likedVideos: ['vid-tears-of-steel'],
        dislikedVideos: [],
        watchHistory: [
          {
            videoId: 'vid-tears-of-steel',
            currentTime: 142,
            duration: 734,
            updatedAt: new Date().toISOString(),
          },
        ],
      },
      null,
      2
    )
  );
}

// Multer storage setup
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    if (file.fieldname === 'thumbnail') {
      cb(null, THUMBS_UPLOAD_DIR);
    } else {
      cb(null, VIDEOS_UPLOAD_DIR);
    }
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname);
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1e9);
    cb(null, `${file.fieldname}-${uniqueSuffix}${ext}`);
  },
});

const upload = multer({
  storage,
  limits: {
    fileSize: 500 * 1024 * 1024, // 500MB max per video
  },
});

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve static uploaded assets
app.use('/uploads', express.static(UPLOADS_DIR));

// Helper functions for Database
function getVideos() {
  try {
    if (fs.existsSync(VIDEOS_FILE)) {
      const data = fs.readFileSync(VIDEOS_FILE, 'utf-8');
      return JSON.parse(data);
    }
  } catch (err) {
    console.error('Error reading videos:', err);
  }
  return [];
}

function saveVideos(videos: any[]) {
  fs.writeFileSync(VIDEOS_FILE, JSON.stringify(videos, null, 2));
}

function getUserData() {
  try {
    if (fs.existsSync(USER_DATA_FILE)) {
      const data = fs.readFileSync(USER_DATA_FILE, 'utf-8');
      return JSON.parse(data);
    }
  } catch (err) {
    console.error('Error reading user data:', err);
  }
  return { myList: [], likedVideos: [], dislikedVideos: [], watchHistory: [] };
}

function saveUserData(data: any) {
  fs.writeFileSync(USER_DATA_FILE, JSON.stringify(data, null, 2));
}

// ---------------- API ROUTES ----------------

// GET /api/videos - List all videos with search & filters
app.get('/api/videos', (req: Request, res: Response) => {
  let videos = getVideos();
  const { category, search, uploadedOnly } = req.query;

  if (category && typeof category === 'string' && category !== 'all') {
    videos = videos.filter((v: any) => v.category === category);
  }

  if (uploadedOnly === 'true') {
    videos = videos.filter((v: any) => v.isUploaded === true);
  }

  if (search && typeof search === 'string') {
    const q = search.toLowerCase();
    videos = videos.filter(
      (v: any) =>
        v.title.toLowerCase().includes(q) ||
        v.description.toLowerCase().includes(q) ||
        (v.cast && v.cast.some((c: string) => c.toLowerCase().includes(q))) ||
        (v.tags && v.tags.some((t: string) => t.toLowerCase().includes(q)))
    );
  }

  res.json(videos);
});

// GET /api/videos/:id - Single video detail
app.get('/api/videos/:id', (req: Request, res: Response) => {
  const videos = getVideos();
  const video = videos.find((v: any) => v.id === req.params.id);
  if (!video) {
    return res.status(404).json({ error: 'Video not found' });
  }
  res.json(video);
});

// GET /api/stream/:id - HTTP 206 Range-Request Video Streaming
app.get('/api/stream/:id', (req: Request, res: Response) => {
  const videos = getVideos();
  const video = videos.find((v: any) => v.id === req.params.id);

  if (!video) {
    return res.status(404).json({ error: 'Video not found' });
  }

  // If this is an external hosted video, redirect or handle directly
  if (video.videoUrl.startsWith('http://') || video.videoUrl.startsWith('https://')) {
    return res.redirect(video.videoUrl);
  }

  // Local file streaming
  const localFileName = path.basename(video.videoUrl);
  const filePath = path.resolve(VIDEOS_UPLOAD_DIR, localFileName);

  if (!fs.existsSync(filePath)) {
    return res.status(404).json({ error: 'Video file missing on server' });
  }

  const stat = fs.statSync(filePath);
  const fileSize = stat.size;
  const range = req.headers.range;

  const ext = path.extname(filePath).toLowerCase();
  const mimeMap: Record<string, string> = {
    '.mp4': 'video/mp4',
    '.webm': 'video/webm',
    '.mkv': 'video/x-matroska',
    '.mov': 'video/quicktime',
    '.ogg': 'video/ogg',
  };
  const contentType = mimeMap[ext] || 'video/mp4';

  if (range) {
    const parts = range.replace(/bytes=/, '').split('-');
    const start = parseInt(parts[0], 10);
    const end = parts[1] ? parseInt(parts[1], 10) : fileSize - 1;

    if (start >= fileSize) {
      res.status(416).send('Requested range not satisfiable\n' + start + ' >= ' + fileSize);
      return;
    }

    const chunksize = end - start + 1;
    const file = fs.createReadStream(filePath, { start, end });
    const head = {
      'Content-Range': `bytes ${start}-${end}/${fileSize}`,
      'Accept-Ranges': 'bytes',
      'Content-Length': chunksize,
      'Content-Type': contentType,
    };

    res.writeHead(206, head);
    file.pipe(res);
  } else {
    const head = {
      'Content-Length': fileSize,
      'Content-Type': contentType,
      'Accept-Ranges': 'bytes',
    };
    res.writeHead(200, head);
    fs.createReadStream(filePath).pipe(res);
  }
});

// POST /api/videos/upload - Upload new video with metadata
app.post(
  '/api/videos/upload',
  upload.fields([
    { name: 'video', maxCount: 1 },
    { name: 'thumbnail', maxCount: 1 },
  ]),
  (req: Request, res: Response) => {
    try {
      const files = req.files as { [fieldname: string]: Express.Multer.File[] };
      const videoFile = files?.video?.[0];
      const thumbFile = files?.thumbnail?.[0];

      if (!videoFile) {
        return res.status(400).json({ error: 'Video file is required' });
      }

      const {
        title,
        description,
        category = 'uploaded',
        tags = '',
        rating = '13+',
        cast = '',
        director = '',
        uploaderName = 'Community User',
        duration = 0,
        thumbnailDataUrl,
      } = req.body;

      const videoId = `vid-user-${Date.now()}`;
      const videoUrl = `/api/stream/${videoId}`;

      let thumbnailUrl = 'https://images.unsplash.com/photo-1536440136628-849c177e76a1?w=800&auto=format&fit=crop&q=80';

      if (thumbFile) {
        thumbnailUrl = `/uploads/thumbnails/${thumbFile.filename}`;
      } else if (thumbnailDataUrl && thumbnailDataUrl.startsWith('data:image')) {
        // Save canvas-extracted snapshot base64
        const base64Data = thumbnailDataUrl.replace(/^data:image\/\w+;base64,/, '');
        const thumbName = `thumb-${Date.now()}.jpg`;
        const thumbPath = path.resolve(THUMBS_UPLOAD_DIR, thumbName);
        fs.writeFileSync(thumbPath, Buffer.from(base64Data, 'base64'));
        thumbnailUrl = `/uploads/thumbnails/${thumbName}`;
      }

      const tagsList = typeof tags === 'string'
        ? tags.split(',').map((t: string) => t.trim()).filter(Boolean)
        : Array.isArray(tags) ? tags : ['Uploaded', 'Community'];

      const castList = typeof cast === 'string'
        ? cast.split(',').map((c: string) => c.trim()).filter(Boolean)
        : [];

      const newVideo = {
        id: videoId,
        title: title || path.parse(videoFile.originalname).name,
        description: description || 'Uploaded video content on CineStream.',
        videoUrl,
        thumbnailUrl,
        backdropUrl: thumbnailUrl,
        category: category || 'uploaded',
        tags: tagsList.length ? tagsList : ['Uploaded', 'HD'],
        duration: Number(duration) || 120,
        releaseYear: new Date().getFullYear(),
        matchScore: Math.floor(Math.random() * 11) + 90, // 90 - 100%
        rating: rating || '13+',
        quality: 'Full HD',
        cast: castList.length ? castList : [uploaderName],
        director: director || uploaderName,
        isUploaded: true,
        uploadedAt: new Date().toISOString(),
        uploaderName: uploaderName || 'User',
        views: 1,
        likes: 1,
        dislikes: 0,
        audioLanguage: 'Original',
        fileName: videoFile.filename,
      };

      const videos = getVideos();
      // Prepend to show immediately at the top
      videos.unshift(newVideo);
      saveVideos(videos);

      return res.status(201).json({ success: true, video: newVideo });
    } catch (err: any) {
      console.error('Upload error:', err);
      return res.status(500).json({ error: err.message || 'Failed to process video upload' });
    }
  }
);

// DELETE /api/videos/:id - Delete an uploaded video
app.delete('/api/videos/:id', (req: Request, res: Response) => {
  const videos = getVideos();
  const videoIndex = videos.findIndex((v: any) => v.id === req.params.id);

  if (videoIndex === -1) {
    return res.status(404).json({ error: 'Video not found' });
  }

  const video = videos[videoIndex];
  if (video.isUploaded && video.fileName) {
    const filePath = path.resolve(VIDEOS_UPLOAD_DIR, video.fileName);
    if (fs.existsSync(filePath)) {
      try {
        fs.unlinkSync(filePath);
      } catch (e) {
        console.error('Error removing video file:', e);
      }
    }
  }

  videos.splice(videoIndex, 1);
  saveVideos(videos);

  res.json({ success: true, message: 'Video deleted' });
});

// GET /api/user/data - Get watchlist, history, likes
app.get('/api/user/data', (req: Request, res: Response) => {
  const data = getUserData();
  res.json(data);
});

// POST /api/user/watchlist - Toggle watchlist
app.post('/api/user/watchlist', (req: Request, res: Response) => {
  const { videoId } = req.body;
  if (!videoId) return res.status(400).json({ error: 'videoId required' });

  const data = getUserData();
  const existsIndex = data.myList.indexOf(videoId);

  let added = false;
  if (existsIndex > -1) {
    data.myList.splice(existsIndex, 1);
  } else {
    data.myList.unshift(videoId);
    added = true;
  }

  saveUserData(data);
  res.json({ success: true, myList: data.myList, added });
});

// POST /api/user/like - Like or dislike
app.post('/api/videos/:id/react', (req: Request, res: Response) => {
  const { action } = req.body; // 'like' | 'dislike' | 'none'
  const videoId = req.params.id;
  const data = getUserData();
  const videos = getVideos();
  const video = videos.find((v: any) => v.id === videoId);

  if (!video) return res.status(404).json({ error: 'Video not found' });

  data.likedVideos = data.likedVideos.filter((id: string) => id !== videoId);
  data.dislikedVideos = data.dislikedVideos.filter((id: string) => id !== videoId);

  if (action === 'like') {
    data.likedVideos.push(videoId);
    video.likes = (video.likes || 0) + 1;
  } else if (action === 'dislike') {
    data.dislikedVideos.push(videoId);
    video.dislikes = (video.dislikes || 0) + 1;
  }

  saveUserData(data);
  saveVideos(videos);

  res.json({
    success: true,
    action,
    likes: video.likes,
    dislikes: video.dislikes,
    userLiked: data.likedVideos.includes(videoId),
    userDisliked: data.dislikedVideos.includes(videoId),
  });
});

// POST /api/user/progress - Save watch progress
app.post('/api/user/progress', (req: Request, res: Response) => {
  const { videoId, currentTime, duration } = req.body;
  if (!videoId) return res.status(400).json({ error: 'videoId required' });

  const data = getUserData();
  const existingIndex = data.watchHistory.findIndex((h: any) => h.videoId === videoId);

  const entry = {
    videoId,
    currentTime: Math.floor(currentTime || 0),
    duration: Math.floor(duration || 0),
    updatedAt: new Date().toISOString(),
  };

  if (existingIndex > -1) {
    data.watchHistory.splice(existingIndex, 1);
  }
  data.watchHistory.unshift(entry);

  // Keep last 30 entries
  if (data.watchHistory.length > 30) {
    data.watchHistory = data.watchHistory.slice(0, 30);
  }

  saveUserData(data);
  res.json({ success: true, watchHistory: data.watchHistory });
});

// GET /api/stats
app.get('/api/stats', (req: Request, res: Response) => {
  const videos = getVideos();
  const uploaded = videos.filter((v: any) => v.isUploaded);
  res.json({
    totalVideos: videos.length,
    uploadedVideos: uploaded.length,
    categories: ['trending', 'movies', 'series', 'action', 'scifi', 'comedy', 'documentary', 'uploaded'],
  });
});

// ---------------- VITE MIDDLEWARE SETUP ----------------
async function startServer() {
  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`🎬 CineStream Netflix server running at http://localhost:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Fatal server startup error:', err);
});
