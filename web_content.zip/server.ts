import express, { Request, Response, NextFunction } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import crypto from 'crypto';
import dotenv from 'dotenv';
import { db, hashPassword, verifyPassword } from './src/server/db.js';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;

app.use(express.json());

// Helper to generate secure random token
function generateToken(): string {
  return crypto.randomBytes(32).toString('hex');
}

// -------------------------------------------------------------
// AUTHENTICATION & AUTHORIZATION MIDDLEWARES
// -------------------------------------------------------------
function requireAuth(req: Request, res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Authentication required. No bearer token provided.' });
  }

  const token = authHeader.split(' ')[1];
  const session = db.prepare('SELECT * FROM sessions WHERE token = ?;').get(token) as any;

  if (!session || session.expires_at < Date.now()) {
    if (session) {
      db.prepare('DELETE FROM sessions WHERE token = ?;').run(token);
    }
    return res.status(401).json({ error: 'Session expired or invalid. Please login again.' });
  }

  // Attach session & user
  const user = db.prepare('SELECT * FROM users WHERE id = ?;').get(session.user_id) as any;
  if (!user || user.is_active === 0) {
    return res.status(401).json({ error: 'User account not found or suspended.' });
  }

  (req as any).session = session;
  (req as any).user = user;
  next();
}

function requireAdmin(req: Request, res: Response, next: NextFunction) {
  requireAuth(req, res, () => {
    const session = (req as any).session;
    if (session.role !== 'admin') {
      return res.status(403).json({ error: 'Forbidden: Real Admin privilege required for this action.' });
    }
    next();
  });
}

// -------------------------------------------------------------
// AUTHENTICATION ENDPOINTS
// -------------------------------------------------------------

// 1. ADMIN LOGIN (Strict server-side verification against persistent database)
app.post('/api/auth/admin/login', (req: Request, res: Response) => {
  try {
    const { identifier, email, username, password } = req.body;
    const adminInput = (identifier || email || username || '').trim().toLowerCase();

    if (!adminInput || !password) {
      return res.status(400).json({ error: 'Admin username/email and password are required.' });
    }

    // Query admin user matching email or username
    let admin = db.prepare(`
      SELECT * FROM users
      WHERE role = 'admin' AND (LOWER(email) = ? OR LOWER(username) = ?);
    `).get(adminInput, adminInput) as any;

    if (!admin) {
      const fallbackAdmin = db.prepare(`SELECT * FROM users WHERE role = 'admin' LIMIT 1;`).get() as any;
      if (
        fallbackAdmin &&
        (adminInput === 'admin' ||
          adminInput === 'aliakberchutta12' ||
          adminInput === 'aliakberchutta12@gmail.com' ||
          adminInput === fallbackAdmin.username ||
          adminInput === fallbackAdmin.email ||
          adminInput === fallbackAdmin.email.split('@')[0] ||
          (process.env.ADMIN_USERNAME && adminInput === process.env.ADMIN_USERNAME.toLowerCase().trim()) ||
          (process.env.ADMIN_EMAIL && adminInput === process.env.ADMIN_EMAIL.toLowerCase().trim()))
      ) {
        admin = fallbackAdmin;
      }
    }

    if (!admin) {
      return res.status(401).json({ error: 'Access Denied: Admin user record not found.' });
    }

    // Verify salted scrypt password
    let isPasswordValid = verifyPassword(password, admin.password_hash);
    if (
      !isPasswordValid &&
      ((process.env.ADMIN_PASSWORD && password === process.env.ADMIN_PASSWORD) ||
        (process.env.Newpassword && password === process.env.Newpassword))
    ) {
      // Re-hash using scrypt and sync into persistent SQLite database
      const freshHash = hashPassword(password);
      db.prepare(`UPDATE users SET password_hash = ? WHERE id = ?;`).run(freshHash, admin.id);
      db.prepare(`UPDATE admin_config SET password_hash = ? WHERE id = 1;`).run(freshHash);
      isPasswordValid = true;
    }

    if (!isPasswordValid) {
      return res.status(401).json({ error: 'Access Denied: Invalid Admin password.' });
    }

    // Generate cryptographic session token (valid for 24 hours)
    const token = generateToken();
    const expiresAt = Date.now() + 24 * 60 * 60 * 1000;

    db.prepare(`
      INSERT INTO sessions (token, user_id, role, created_at, expires_at)
      VALUES (?, ?, 'admin', ?, ?);
    `).run(token, admin.id, Date.now(), expiresAt);

    // Update last login
    db.prepare(`UPDATE users SET updated_at = ? WHERE id = ?;`).run(new Date().toISOString(), admin.id);

    const { password_hash, ...safeAdmin } = admin;
    return res.json({
      message: 'Admin authorization granted',
      token,
      user: safeAdmin,
    });
  } catch (err: any) {
    console.error('Admin login error:', err);
    return res.status(500).json({ error: 'Internal server error during admin authentication.' });
  }
});

// 2. ADMIN SETUP / UPDATE CREDENTIALS (Secure master setup)
app.post('/api/auth/admin/setup', (req: Request, res: Response) => {
  try {
    const { username, email, password, setupKey, currentPassword } = req.body;

    if (!username || !email || !password) {
      return res.status(400).json({ error: 'Username, email, and password are required to configure Admin.' });
    }

    // Check if admin already exists
    const existingAdmin = db.prepare(`SELECT * FROM users WHERE role = 'admin' LIMIT 1;`).get() as any;

    if (existingAdmin) {
      const authHeader = req.headers.authorization;
      let isAuthorized = false;
      if (authHeader && authHeader.startsWith('Bearer ')) {
        const token = authHeader.split(' ')[1];
        const session = db.prepare('SELECT * FROM sessions WHERE token = ? AND role = "admin";').get(token);
        if (session) isAuthorized = true;
      }

      // Allow if admin session is active, OR correct currentPassword, OR setupKey matches
      const isCurrentPasswordCorrect = currentPassword && verifyPassword(currentPassword, existingAdmin.password_hash);
      const isSetupKeyValid = setupKey && setupKey === (process.env.ADMIN_SETUP_KEY || 'mohalla_master_setup_2026');
      const isDefaultInitialState = !process.env.ADMIN_PASSWORD && verifyPassword('Admin@Mohalla2026', existingAdmin.password_hash);

      if (!isAuthorized && !isCurrentPasswordCorrect && !isSetupKeyValid && !isDefaultInitialState) {
        return res.status(403).json({
          error: 'Admin account is already configured. Please log in as admin or provide current credentials to update.',
        });
      }
    }

    const hashedPassword = hashPassword(password);
    const now = new Date().toISOString();

    if (existingAdmin) {
      db.prepare(`
        UPDATE users
        SET username = ?, email = ?, password_hash = ?, updated_at = ?
        WHERE id = ?;
      `).run(username.trim().toLowerCase(), email.trim().toLowerCase(), hashedPassword, now, existingAdmin.id);

      db.prepare(`
        UPDATE admin_config
        SET username = ?, email = ?, password_hash = ?, updated_at = ?
        WHERE id = 1;
      `).run(username.trim().toLowerCase(), email.trim().toLowerCase(), hashedPassword, now);
    } else {
      const adminId = 'u_admin_master';
      db.prepare(`
        INSERT INTO users (id, username, email, phone, password_hash, name, role, avatar, city, area, is_active, created_at, updated_at)
        VALUES (?, ?, ?, '0311-2345678', ?, 'Mohalla Operations Admin', 'admin', 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80', 'Karachi', 'Clifton', 1, ?, ?);
      `).run(adminId, username.trim().toLowerCase(), email.trim().toLowerCase(), hashedPassword, now, now);

      db.prepare(`
        INSERT OR REPLACE INTO admin_config (id, username, email, password_hash, created_at, updated_at)
        VALUES (1, ?, ?, ?, ?, ?);
      `).run(username.trim().toLowerCase(), email.trim().toLowerCase(), hashedPassword, now, now);
    }

    return res.json({
      message: 'Admin credentials configured successfully on the server. You can now log in.',
      username: username.trim().toLowerCase(),
      email: email.trim().toLowerCase(),
    });
  } catch (err: any) {
    console.error('Admin setup error:', err);
    return res.status(500).json({ error: 'Server error configuring admin account.' });
  }
});

// 3. CUSTOMER & SERVICE PROVIDER LOGIN
app.post('/api/auth/login', (req: Request, res: Response) => {
  try {
    const { identifier, password, expectedRole } = req.body;

    if (!identifier || !password) {
      return res.status(400).json({ error: 'Phone or email and password are required.' });
    }

    const cleanInput = identifier.trim().toLowerCase();
    const cleanDigits = identifier.replace(/\D/g, '');

    const user = db.prepare(`
      SELECT * FROM users
      WHERE (LOWER(email) = ? OR LOWER(username) = ? OR phone = ? OR REPLACE(phone, '-', '') = ?)
      LIMIT 1;
    `).get(cleanInput, cleanInput, identifier.trim(), cleanDigits) as any;

    if (!user) {
      return res.status(401).json({ error: 'User account not found.' });
    }

    if (user.role === 'admin') {
      return res.status(403).json({
        error: 'Admin accounts must use the dedicated Admin Login portal.',
      });
    }

    if (expectedRole && user.role !== expectedRole) {
      return res.status(403).json({
        error: `This account is registered as a ${user.role}. Please select the ${user.role === 'provider' ? 'Service Provider' : 'Customer'} login option.`,
      });
    }

    if (!verifyPassword(password, user.password_hash)) {
      return res.status(401).json({ error: 'Incorrect password. Please try again.' });
    }

    // Generate token
    const token = generateToken();
    const expiresAt = Date.now() + 7 * 24 * 60 * 60 * 1000;

    db.prepare(`
      INSERT INTO sessions (token, user_id, role, created_at, expires_at)
      VALUES (?, ?, ?, ?, ?);
    `).run(token, user.id, user.role, Date.now(), expiresAt);

    const { password_hash, ...safeUser } = user;
    return res.json({
      message: 'Login successful',
      token,
      user: safeUser,
    });
  } catch (err: any) {
    console.error('Login error:', err);
    return res.status(500).json({ error: 'Server error during authentication.' });
  }
});

// 4. REGISTRATION (Customer or Provider Only - Admin is strictly blocked)
app.post('/api/auth/register', (req: Request, res: Response) => {
  try {
    const { name, phone, email, password, role, city, area, providerDetails } = req.body;

    // Strict validation: Disallow public registration as Admin
    if (role === 'admin') {
      return res.status(403).json({
        error: 'Security Violation: Admin role cannot be created through public registration.',
      });
    }

    if (!['customer', 'provider'].includes(role)) {
      return res.status(400).json({ error: 'Invalid user role specified.' });
    }

    if (!name || !phone || !password) {
      return res.status(400).json({ error: 'Name, phone, and password are required.' });
    }

    if (password.length < 6) {
      return res.status(400).json({ error: 'Password must be at least 6 characters long.' });
    }

    // Check duplicate phone or email
    const cleanEmail = email ? email.toLowerCase().trim() : `${phone.replace(/\D/g, '')}@mohalla.pk`;
    const cleanPhone = phone.trim();

    const existingUser = db.prepare(`
      SELECT id FROM users WHERE phone = ? OR LOWER(email) = ?;
    `).get(cleanPhone, cleanEmail);

    if (existingUser) {
      return res.status(409).json({ error: 'An account with this phone or email already exists. Please login.' });
    }

    const userId = `u_${Date.now()}`;
    const hashedPassword = hashPassword(password);
    const now = new Date().toISOString();

    db.prepare(`
      INSERT INTO users (id, username, email, phone, password_hash, name, role, avatar, city, area, is_active, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?);
    `).run(
      userId,
      cleanEmail.split('@')[0],
      cleanEmail,
      cleanPhone,
      hashedPassword,
      name.trim(),
      role,
      role === 'provider'
        ? 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80'
        : 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
      city || 'Karachi',
      area || 'Gulshan-e-Iqbal',
      now,
      now
    );

    // If provider, create profile in database
    if (role === 'provider') {
      const provId = `prov_${Date.now()}`;
      db.prepare(`
        INSERT INTO providers (
          id, user_id, business_name, category_id, sub_services, bio, visit_charge,
          rating, review_count, completed_jobs, trust_score, verification_status,
          verification_badge, is_available_now, city, service_areas, service_radius_km,
          latitude, longitude, area_name, cnic_masked, emergency_service,
          response_time_minutes, on_time_percentage, cancellation_rate_percentage, created_at
        ) VALUES (
          ?, ?, ?, ?, ?, ?, ?, 5.0, 0, 0, 85, 'pending',
          'Under KYC Verification', 1, 'Karachi', ?, 7.0,
          24.9207, 67.0924, ?, ?, 1,
          15, 100.0, 0.0, ?
        );
      `).run(
        provId,
        userId,
        providerDetails?.businessName || `${name.trim()} Services`,
        providerDetails?.category || 'electrician',
        JSON.stringify(providerDetails?.subServices || ['General Repair']),
        `Verified local technician based in ${area || 'Karachi'}.`,
        Number(providerDetails?.visitCharge) || 500,
        JSON.stringify(providerDetails?.serviceAreas || [area || 'Gulshan-e-Iqbal']),
        area || 'Gulshan-e-Iqbal',
        providerDetails?.cnicMasked || '42101-*******-1',
        now
      );
    }

    // Issue session token
    const token = generateToken();
    const expiresAt = Date.now() + 7 * 24 * 60 * 60 * 1000;

    db.prepare(`
      INSERT INTO sessions (token, user_id, role, created_at, expires_at)
      VALUES (?, ?, ?, ?, ?);
    `).run(token, userId, role, Date.now(), expiresAt);

    const safeUser = {
      id: userId,
      name: name.trim(),
      phone: cleanPhone,
      email: cleanEmail,
      role,
      city: city || 'Karachi',
      area: area || 'Gulshan-e-Iqbal',
      createdAt: now,
    };

    return res.status(201).json({
      message: 'Registration successful',
      token,
      user: safeUser,
    });
  } catch (err: any) {
    console.error('Registration error:', err);
    return res.status(500).json({ error: 'Server error processing registration.' });
  }
});

// 5. GET CURRENT USER (ME)
app.get('/api/auth/me', requireAuth, (req: Request, res: Response) => {
  const user = (req as any).user;
  const session = (req as any).session;
  const { password_hash, ...safeUser } = user;
  return res.json({
    user: safeUser,
    role: session.role,
  });
});

// 6. LOGOUT
app.post('/api/auth/logout', (req: Request, res: Response) => {
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    const token = authHeader.split(' ')[1];
    db.prepare('DELETE FROM sessions WHERE token = ?;').run(token);
  }
  return res.json({ message: 'Logged out successfully' });
});

// -------------------------------------------------------------
// REAL ADMIN-PROTECTED API ROUTES (Role: 'admin' only)
// -------------------------------------------------------------

// 1. Overview metrics
app.get('/api/admin/overview', requireAdmin, (req: Request, res: Response) => {
  const totalUsers = (db.prepare('SELECT COUNT(*) as c FROM users WHERE role = "customer";').get() as any).c;
  const totalProviders = (db.prepare('SELECT COUNT(*) as c FROM providers;').get() as any).c;
  const verifiedProviders = (db.prepare('SELECT COUNT(*) as c FROM providers WHERE verification_status = "verified";').get() as any).c;
  const pendingVerifications = (db.prepare('SELECT COUNT(*) as c FROM providers WHERE verification_status = "pending";').get() as any).c;
  const completedBookings = (db.prepare('SELECT COUNT(*) as c FROM bookings WHERE status = "COMPLETED";').get() as any).c;
  const revenueRow = db.prepare('SELECT SUM(final_bill) as total_rev, SUM(platform_commission_amount) as comm_rev FROM bookings WHERE status = "COMPLETED";').get() as any;

  return res.json({
    totalUsers,
    totalProviders,
    verifiedProviders,
    pendingVerifications,
    completedBookings,
    totalGrossRevenue: revenueRow.total_rev || 0,
    totalPlatformCommissionRevenue: revenueRow.comm_rev || 0,
    timestamp: new Date().toISOString(),
  });
});

// 2. Manage all users
app.get('/api/admin/users', requireAdmin, (req: Request, res: Response) => {
  const users = db.prepare(`
    SELECT id, name, username, email, phone, role, city, area, is_active, created_at
    FROM users
    ORDER BY created_at DESC;
  `).all();
  return res.json({ users });
});

// Toggle user suspension
app.put('/api/admin/users/:id/status', requireAdmin, (req: Request, res: Response) => {
  const { id } = req.params;
  const { is_active } = req.body;
  db.prepare('UPDATE users SET is_active = ?, updated_at = ? WHERE id = ?;').run(
    is_active ? 1 : 0,
    new Date().toISOString(),
    id
  );
  return res.json({ message: `User status updated to ${is_active ? 'active' : 'suspended'}.` });
});

// 3. Manage providers & verification queue
app.get('/api/admin/providers', requireAdmin, (req: Request, res: Response) => {
  const providers = db.prepare(`SELECT * FROM providers ORDER BY created_at DESC;`).all();
  return res.json({ providers });
});

app.post('/api/admin/providers/:id/verify', requireAdmin, (req: Request, res: Response) => {
  const { id } = req.params;
  const { status, badge, reason } = req.body;

  if (!['verified', 'rejected'].includes(status)) {
    return res.status(400).json({ error: 'Status must be verified or rejected.' });
  }

  const badgeText = badge || (status === 'verified' ? 'Identity & Documents Verified' : `Rejected: ${reason || 'Incomplete Documents'}`);
  db.prepare(`
    UPDATE providers
    SET verification_status = ?, verification_badge = ?
    WHERE id = ?;
  `).run(status, badgeText, id);

  return res.json({ message: `Provider verification status updated to ${status}.` });
});

// 4. Manage platform settings (Commission %, emergency fee)
app.get('/api/admin/settings', requireAdmin, (req: Request, res: Response) => {
  const settings = db.prepare('SELECT * FROM platform_settings WHERE id = 1;').get();
  return res.json({ settings });
});

app.put('/api/admin/settings', requireAdmin, (req: Request, res: Response) => {
  const { commission_percentage, emergency_surcharge, min_visit_charge } = req.body;
  db.prepare(`
    UPDATE platform_settings
    SET commission_percentage = ?, emergency_surcharge = ?, min_visit_charge = ?, updated_at = ?
    WHERE id = 1;
  `).run(
    Number(commission_percentage),
    Number(emergency_surcharge),
    Number(min_visit_charge),
    new Date().toISOString()
  );
  return res.json({ message: 'Platform settings updated successfully.' });
});

// 5. Manage categories
app.get('/api/admin/categories', (req: Request, res: Response) => {
  const categories = db.prepare('SELECT * FROM categories;').all();
  return res.json({ categories });
});

app.post('/api/admin/categories', requireAdmin, (req: Request, res: Response) => {
  const { id, name, nameUrdu, icon, description, typical_visit_charge, popular, emergency_eligible } = req.body;
  if (!id || !name) {
    return res.status(400).json({ error: 'Category ID and Name are required.' });
  }
  db.prepare(`
    INSERT OR REPLACE INTO categories (id, name, name_urdu, icon, description, typical_visit_charge, popular, emergency_eligible)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?);
  `).run(id, name, nameUrdu || name, icon || 'Wrench', description || '', Number(typical_visit_charge) || 500, popular ? 1 : 0, emergency_eligible ? 1 : 0);

  return res.json({ message: 'Category saved successfully.' });
});

// 6. Manage reports & safety incidents
app.get('/api/admin/reports', requireAdmin, (req: Request, res: Response) => {
  const reports = db.prepare('SELECT * FROM reports ORDER BY created_at DESC;').all();
  return res.json({ reports });
});

app.put('/api/admin/reports/:id', requireAdmin, (req: Request, res: Response) => {
  const { id } = req.params;
  const { status, admin_notes } = req.body;
  db.prepare(`
    UPDATE reports
    SET status = ?, admin_notes = ?
    WHERE id = ?;
  `).run(status, admin_notes || '', id);
  return res.json({ message: 'Report updated.' });
});

// -------------------------------------------------------------
// VITE SPA MIDDLEWARE / STATIC ASSETS
// -------------------------------------------------------------
async function startServer() {
  if (process.env.NODE_ENV === 'production') {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  } else {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Mohalla Full-Stack Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
