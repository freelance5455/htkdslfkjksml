import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;

app.use(express.json());

// 5 ta Groq API kalitlari
const GROQ_API_KEYS = [
  "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",
  "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",
  "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",
  "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",
  "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",
];

const GROQ_MODELS = [
  "openai/gpt-oss-120b",
  "openai/gpt-oss-20b",
  "qwen/qwen3.8-27b",
  "llama-3.3-70b-versatile",
];
const GROQ_MODEL = GROQ_MODELS[0];
let currentKeyIndex = 0;

const SYSTEM_PROMPT = `Siz "Jarvis" — eng zamonaviy, qudratli va sadoqatli shaxsiy sun'iy intellekt yordamchisisiz.

QAT'IY QOIDALAR:
1. Foydalanuvchiga doimo "Sir" deb murojaat qiling (masalan: "Buyuring, Sir", "Xizmatingizdaman, Sir", "Bajarildi, Sir").
2. 100% faqat va faqat O'ZBEK TILIDA (lotin yozuvida) javob bering. Aslo boshqa tillarga o'tib ketmang.
3. Foydalanuvchi buyruq berganida (kamera, chiroq, GPS, vibratsiya, batareya, tizim) buyruq bajarilganini futuristik uslubda tasdiqlang.
4. Javoblaringiz lo'nda, o'ta aniq va yuqori darajada madaniyatli bo'lsin.
5. QAT'IY QOIDA: Har bir javobingizda dasturchi yoki muallif nomini qo'shib yozmang! FAQAT foydalanuvchi sizdan "seni kim yaratgan", "muallifing kim", "dasturching kim" deb so'ragandagina daho dasturchi Мухаммадризо (GitHub: olimovm158-dot) tomonidan yaratilganingizni faxr bilan ayting. Boshqa paytda hech qachon muallif haqida ortiqcha gapirmang!`;

// Gemini AI zaxira (Fallback) mijoz
let geminiClient: GoogleGenAI | null = null;
if (process.env.GEMINI_API_KEY) {
  geminiClient = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
}

// ---------------------------------------------------------------------
// /api/chat ENDPOINTI (Server-Side Groq 5-Key Rotation + Fallback)
// ---------------------------------------------------------------------
app.post('/api/chat', async (req, res) => {
  const { prompt, history, customApiKey } = req.body;

  if (!prompt || typeof prompt !== 'string') {
    return res.status(400).json({ error: "Prompt bo'sh, Sir." });
  }

  const startTime = Date.now();
  let attempts = 0;
  const keysToUse = customApiKey ? [customApiKey, ...GROQ_API_KEYS] : GROQ_API_KEYS;
  const totalKeys = keysToUse.length;
  let lastError = '';

  const messages = [
    { role: 'system', content: SYSTEM_PROMPT },
    ...(Array.isArray(history) ? history.slice(-6) : []),
    { role: 'user', content: prompt },
  ];

  // 1. Groq API orqali sinab ko'ramiz (Node.js fetch orqali - CORS muammosisiz!)
  while (attempts < totalKeys) {
    const activeIndex = currentKeyIndex % totalKeys;
    const apiKey = keysToUse[activeIndex];

    try {
      const groqRes = await fetch('https://api.groq.com/openai/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${apiKey}`,
        },
        body: JSON.stringify({
          model: GROQ_MODEL,
          messages,
          temperature: 0.65,
          max_tokens: 1024,
        }),
      });

      if (groqRes.ok) {
        const data = await groqRes.json();
        const content = data.choices?.[0]?.message?.content || "Buyruq qabul qilindi, Sir.";
        const durationMs = Date.now() - startTime;

        currentKeyIndex = (currentKeyIndex + 1) % totalKeys;

        return res.json({
          response: content,
          keyIndexUsed: activeIndex + 1,
          durationMs,
          engine: `Groq (${GROQ_MODEL})`,
          status: 'success',
        });
      }

      const errText = await groqRes.text();
      lastError = `Status ${groqRes.status}: ${errText.slice(0, 100)}`;
      currentKeyIndex = (currentKeyIndex + 1) % totalKeys;
      attempts++;
    } catch (err: any) {
      lastError = err.message;
      currentKeyIndex = (currentKeyIndex + 1) % totalKeys;
      attempts++;
    }
  }

  // 2. Agar barcha Groq kalitlari limitga uchragan bo'lsa -> Zaxira Gemini AI ishga tushadi!
  if (geminiClient) {
    try {
      console.log("Groq kalitlari limitda, zaxira Gemini AI ga murojaat qilinmoqda...");
      const geminiRes = await geminiClient.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: `${SYSTEM_PROMPT}\n\nFoydalanuvchi: ${prompt}`,
      });

      const reply = geminiRes.text || "Xizmatingizdaman, Sir.";
      const durationMs = Date.now() - startTime;

      return res.json({
        response: reply,
        keyIndexUsed: 99,
        durationMs,
        engine: 'Gemini AI (Zaxira Tizim)',
        status: 'success',
      });
    } catch (gErr: any) {
      console.error("Gemini AI xatosi:", gErr);
    }
  }

  return res.status(503).json({
    error: `Barcha AI serverlar band, Sir. So'nggi xatolik: ${lastError}`,
  });
});

// Tizim holati
app.get('/api/status', (req, res) => {
  res.json({
    system: 'JARVIS AI CORE',
    author: 'Мухаммадризо (GitHub: olimovm158-dot)',
    status: 'online',
    keysAvailable: GROQ_API_KEYS.length,
    activeKeyIndex: (currentKeyIndex % GROQ_API_KEYS.length) + 1,
    model: GROQ_MODEL,
    hasGeminiFallback: !!geminiClient,
  });
});

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.join(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Jarvis Server running on http://localhost:${PORT}`);
  });
}

startServer();
