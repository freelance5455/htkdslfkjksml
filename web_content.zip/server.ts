import express from 'express';
import path from 'path';
import fs from 'fs';
import { createServer as createViteServer } from 'vite';

interface SyncRoom {
  roomId: string;
  pin: string;
  data: any;
  updatedAt: number;
  devices: string[];
}

const syncStore = new Map<string, SyncRoom>();

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: '10mb' }));

  // API Routes
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', time: new Date().toISOString() });
  });

  // Serve compiled webOS IPK installer package for direct client downloads
  app.get('/api/download-ipk', (req, res) => {
    const ipkPath = path.join(process.cwd(), 'hebrew-calendar_1.0.0_all.ipk');
    res.download(ipkPath, 'hebrew-calendar_1.0.0_all.ipk', (err) => {
      if (err) {
        res.status(404).send('IPK installer package is currently being generated or not found.');
      }
    });
  });

  // Serve complete project source code ZIP archive for direct download
  app.get(['/api/download-zip', '/api/download-project-zip'], async (req, res) => {
    try {
      const AdmZip = (await import('adm-zip')).default;
      const rootDir = process.cwd();
      const zip = new AdmZip();

      const excludeList = new Set([
        'node_modules',
        '.git',
        'dist',
        'dist.zip',
        'project.zip',
        'hebrew-calendar_1.0.0_all.ipk',
        'app-export.tar.gz'
      ]);

      function addDirectoryRecursively(currentPath: string, zipPath = '') {
        const items = fs.readdirSync(currentPath);
        for (const item of items) {
          if (excludeList.has(item)) continue;
          const fullPath = path.join(currentPath, item);
          const entryZipPath = zipPath ? `${zipPath}/${item}` : item;
          const stat = fs.statSync(fullPath);
          if (stat.isDirectory()) {
            addDirectoryRecursively(fullPath, entryZipPath);
          } else {
            zip.addLocalFile(fullPath, zipPath);
          }
        }
      }

      addDirectoryRecursively(rootDir);
      const zipBuffer = zip.toBuffer();

      res.set({
        'Content-Type': 'application/zip',
        'Content-Disposition': 'attachment; filename="hebrew-calendar-source.zip"',
        'Content-Length': zipBuffer.length,
      });
      res.send(zipBuffer);
    } catch (err) {
      console.error('Error generating project zip:', err);
      const fallbackPath = path.join(process.cwd(), 'project.zip');
      if (fs.existsSync(fallbackPath)) {
        res.download(fallbackPath, 'hebrew-calendar-source.zip');
      } else {
        res.status(500).send('Could not generate project ZIP file.');
      }
    }
  });

  // Multi-Device Sync: Fetch Room
  app.get('/api/sync/room/:roomId', (req, res) => {
    const { roomId } = req.params;
    const pin = (req.query.pin as string) || '';

    const cleanRoomId = roomId.toUpperCase().trim();
    const room = syncStore.get(cleanRoomId);

    if (!room) {
      return res.status(404).json({ error: 'Sync room not found. You can create a new room with this ID.' });
    }

    if (room.pin && room.pin !== pin) {
      return res.status(401).json({ error: 'Incorrect room PIN / Passphrase.' });
    }

    return res.json({
      success: true,
      roomId: cleanRoomId,
      updatedAt: room.updatedAt,
      devices: room.devices,
      data: room.data,
    });
  });

  // Multi-Device Sync: Update / Create Room
  app.post('/api/sync/room/:roomId', (req, res) => {
    const { roomId } = req.params;
    const { pin, data } = req.body;

    const cleanRoomId = roomId.toUpperCase().trim();
    const existing = syncStore.get(cleanRoomId);

    if (existing && existing.pin && existing.pin !== (pin || '')) {
      return res.status(401).json({ error: 'Incorrect room PIN.' });
    }

    const deviceName = data?.deviceName || 'Unknown Device';
    const devices = existing?.devices || [];
    if (!devices.includes(deviceName)) {
      devices.push(deviceName);
    }

    const updatedRoom: SyncRoom = {
      roomId: cleanRoomId,
      pin: pin || '',
      data: data || {},
      updatedAt: Date.now(),
      devices,
    };

    syncStore.set(cleanRoomId, updatedRoom);

    return res.json({
      success: true,
      roomId: cleanRoomId,
      timestamp: updatedRoom.updatedAt,
      devicesCount: devices.length,
    });
  });

  // Never cache PWA service worker and manifest
  app.get(['/sw.js', '/manifest.json'], (req, res, next) => {
    res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
    res.setHeader('Pragma', 'no-cache');
    res.setHeader('Expires', '0');
    next();
  });

  // Asset Serving & Fallback: Guarantee that ANY /assets/*.js or /assets/*.css request
  // will receive a valid JavaScript or CSS response, even if an old PWA client requests a legacy hash.
  const distAssetsPath = path.join(process.cwd(), 'dist', 'assets');
  app.use('/assets', express.static(distAssetsPath));

  app.get('/assets/:file', (req, res, next) => {
    const fileName = req.params.file;
    if (fs.existsSync(distAssetsPath)) {
      const allAssets = fs.readdirSync(distAssetsPath);
      if (fileName.endsWith('.js')) {
        const targetJs = allAssets.find((f) => f.startsWith('index-') && f.endsWith('.js')) || allAssets.find((f) => f.endsWith('.js'));
        if (targetJs) {
          res.setHeader('Content-Type', 'text/javascript');
          return res.sendFile(path.join(distAssetsPath, targetJs));
        }
      }
      if (fileName.endsWith('.css')) {
        const targetCss = allAssets.find((f) => f.startsWith('index-') && f.endsWith('.css')) || allAssets.find((f) => f.endsWith('.css'));
        if (targetCss) {
          res.setHeader('Content-Type', 'text/css');
          return res.sendFile(path.join(distAssetsPath, targetCss));
        }
      }
    }
    next();
  });

  // Vite middleware for development vs Static file server for production
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Hebrew Calendar App server listening on port ${PORT}`);
  });
}

startServer();
