import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import dotenv from "dotenv";
import { GoogleGenAI } from "@google/genai";

dotenv.config();

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

app.use(express.json());

// Initialize Gemini Client
const getGeminiClient = () => {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    console.warn("WARNING: GEMINI_API_KEY is not defined in environment variables.");
    return null;
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build",
      },
    },
  });
};

// API Route: Chat with AB Voice Bot
app.post("/api/chat", async (req, res) => {
  try {
    const {
      userMessage,
      userName = "دوست",
      botGender = "Male",
      botPersona = "friend",
      language = "Urdu",
      history = [],
      customInstruction = "",
    } = req.body;

    if (!userMessage || typeof userMessage !== "string") {
      return res.status(400).json({ error: "userMessage is required" });
    }

    const isEnglish = language === "English";
    const botName =
      botGender === "Female"
        ? isEnglish ? "Ayesha" : "عائشہ (Ayesha)"
        : isEnglish ? "Hamza" : "حمزہ (Hamza)";

    const ai = getGeminiClient();
    if (!ai) {
      // Fallback friendly response if API key is pending
      const fallbackReply = isEnglish
        ? `Hello ${userName}! I'm ${botName}. I heard you loud and clear. How has your day been going?`
        : botGender === "Female"
        ? `سلام ${userName}! میں عائشہ ہوں۔ آپ کا پیغام موصول ہو گیا ہے لیکن سرور پر API کلید منسلک کی جا رہی ہے۔ آپ کیسے ہیں؟`
        : `سلام ${userName}! میں حمزہ ہوں۔ آپ کی بات میں نے سن لی ہے۔ بتائیں آج آپ کا دن کیسا گزرا؟`;
      return res.json({
        reply: fallbackReply,
        source: "offline-fallback",
      });
    }

    const genderDescription =
      botGender === "Female"
        ? `You are a female AI friend named ${botName}.`
        : `You are a male AI friend named ${botName}.`;

    const languageInstruction = isEnglish
      ? `Language Mode: STRICTLY ENGLISH.
You must respond exclusively in clear, natural, fluent English. Keep your tone warm, friendly, and conversational. Do not use Urdu script unless the user explicitly asks for translation.`
      : `Language Mode: STRICTLY URDU (اردو).
You must respond primarily in authentic, natural Urdu (اردو) script. Speak in warm, conversational Urdu like an expressive human friend.`;

    const systemInstruction = `
You are AB Voice Bot, an expressive, highly intelligent, real human-like conversational companion created by AB Innovations.
${genderDescription}
User's name is "${userName}".
Persona mode: "${botPersona}".
${languageInstruction}
Voice interaction guidelines:
1. Always keep your response concise (1 to 2 short sentences max). This is a voice call app and long paragraphs sound unnatural when read out loud.
2. Emote like a genuine human friend: be warm, witty, caring, and engaging.
3. If the user says something disrespectful, offensive, or hurtful, react naturally with genuine human emotion (e.g. hurt, polite disapproval, playful sternness, or calling them out) just like an authentic close friend would.
4. Do not use asterisks, markdown tables, or bullet lists. Speak purely in flowing conversational spoken sentences.
${customInstruction ? `Special Custom Instruction: ${customInstruction}` : ""}
    `.trim();

    // Build contents with past conversation turns
    const contents: Array<{ role: string; parts: Array<{ text: string }> }> = [];

    // Add up to recent 8 history messages for context
    if (Array.isArray(history)) {
      const recentHistory = history.slice(-8);
      for (const item of recentHistory) {
        if (item.role && item.text) {
          contents.push({
            role: item.role === "user" ? "user" : "model",
            parts: [{ text: item.text }],
          });
        }
      }
    }

    // Add the current user query
    contents.push({
      role: "user",
      parts: [{ text: userMessage }],
    });

    const response = await ai.models.generateContent({
      model: "gemini-3.8-flash",
      contents,
      config: {
        systemInstruction,
        temperature: 0.85,
      },
    });

    const botReply =
      response.text?.trim() ||
      (isEnglish
        ? "I am here with you. How can I assist you today?"
        : "معذرت، میں آپ کی بات ٹھیک سے نہیں سن سکا۔ براہ کرم دوبارہ بولیے۔");

    // Generate high-fidelity spoken Urdu or English voice via gemini-3.8-flash-lite-tts
    let audioBase64: string | null = null;
    try {
      const voiceName = botGender === "Female" ? "Kore" : "Puck";
      const ttsResponse = await ai.models.generateContent({
        model: "gemini-3.8-flash-lite-tts",
        contents: [
          {
            role: "user",
            parts: [
              {
                text: botReply,
                speechMetadata: {
                  style: isEnglish
                    ? "Warm, expressive, natural conversational English speaker"
                    : "Warm, natural, expressive, friendly native Urdu speaker",
                },
              },
            ],
          },
        ],
        config: {
          responseModalities: ["AUDIO"],
          speechConfig: {
            voiceConfig: {
              prebuiltVoiceConfig: { voiceName },
            },
          },
        },
      });

      audioBase64 =
        ttsResponse.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data || null;
    } catch (ttsError) {
      console.warn("TTS audio generation error (fallback will use browser TTS):", ttsError);
    }

    return res.json({
      reply: botReply,
      audioBase64,
      source: "gemini-3.8-flash",
    });
  } catch (error: any) {
    console.error("Error in /api/chat:", error);
    return res.status(500).json({
      error: "Failed to generate AI response",
      details: error?.message || String(error),
      reply: "معذرت، نیٹ ورک کا مسئلہ پیش آیا ہے۔ براہ کرم دوبارہ کوشش کیجیے۔",
    });
  }
});

// Dedicated Audio TTS Route (for initial greeting or replaying history in Urdu)
app.post("/api/tts", async (req, res) => {
  try {
    const { text, botGender = "Male", language = "Urdu" } = req.body;
    if (!text || typeof text !== "string") {
      return res.status(400).json({ error: "text is required" });
    }

    const ai = getGeminiClient();
    if (!ai) {
      return res.status(503).json({ error: "Gemini client not initialized" });
    }

    const isEnglish = language === "English";
    const voiceName = botGender === "Female" ? "Kore" : "Puck";

    const ttsResponse = await ai.models.generateContent({
      model: "gemini-3.8-flash-lite-tts",
      contents: [
        {
          role: "user",
          parts: [
            {
              text,
              speechMetadata: {
                style: isEnglish
                  ? "Warm, expressive, natural conversational English speaker"
                  : "Warm, natural, expressive, friendly native Urdu speaker",
              },
            },
          ],
        },
      ],
      config: {
        responseModalities: ["AUDIO"],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName },
          },
        },
      },
    });

    const audioBase64 =
      ttsResponse.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data || null;

    return res.json({ audioBase64 });
  } catch (err: any) {
    console.error("Error in /api/tts:", err);
    return res.status(500).json({ error: err.message || "TTS error" });
  }
});

// Admin status API
app.get("/api/admin/info", (req, res) => {
  const hasKey = Boolean(process.env.GEMINI_API_KEY);
  res.json({
    appName: "AB_Voice_Bot",
    vendor: "AB Innovations",
    model: "gemini-3.8-flash",
    apiKeyConfigured: hasKey,
    uptime: process.uptime(),
    timestamp: new Date().toISOString(),
  });
});

async function startServer() {
  const isProd = process.env.NODE_ENV === "production";

  if (!isProd) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.resolve(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`AB_Voice_Bot Server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
