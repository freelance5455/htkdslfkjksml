import express, { Request, Response, NextFunction } from 'express';
import path from 'path';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';
import { createServer as createViteServer } from 'vite';
import { db } from './server/db.js';

dotenv.config();

const app = express();
const PORT = 3000;

// Body parsing middleware (support json & larger payload for avatar image dataURLs)
app.use(express.json({ limit: '15mb' }));
app.use(express.urlencoded({ extended: true, limit: '15mb' }));

// Lazy/Safe Gemini SDK initialization
let aiClient: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI {
  if (!aiClient) {
    aiClient = new GoogleGenAI({
      apiKey: process.env.GEMINI_API_KEY,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return aiClient;
}

// Extend Express Request for authenticated user
interface AuthRequest extends Request {
  userId?: string;
  user?: any;
}

// Authentication Middleware
function requireAuth(req: AuthRequest, res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization;
  const token = authHeader?.startsWith('Bearer ')
    ? authHeader.substring(7)
    : (req.headers['x-session-token'] as string) || (req.query.token as string);

  if (!token) {
    return res.status(401).json({ error: 'Authentication required. Please sign in.' });
  }

  const session = db.getSession(token);
  if (!session) {
    return res.status(401).json({ error: 'Session expired or invalid. Please sign in again.' });
  }

  const user = db.findUserById(session.userId);
  if (!user) {
    return res.status(401).json({ error: 'User account not found.' });
  }

  req.userId = user.id;
  const { passwordHash, salt, verificationCode, resetToken, resetTokenExpires, ...safeUser } = user;
  req.user = safeUser;
  next();
}

// ==========================================
// 1. HEALTH & METADATA
// ==========================================
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    app: 'AI Pocket Chat',
    owner: 'Ali ABDULLAH',
    time: new Date().toISOString(),
  });
});

// ==========================================
// 2. AUTHENTICATION ROUTES
// ==========================================

// Register
const handleRegister = (req: express.Request, res: express.Response) => {
  try {
    const { name, email, password, confirmPassword } = req.body;

    if (!name || !name.trim()) {
      return res.status(400).json({ error: 'Full Name is required.' });
    }
    if (!email || !email.trim()) {
      return res.status(400).json({ error: 'Email address is required.' });
    }
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email.trim())) {
      return res.status(400).json({ error: 'Please enter a valid email address.' });
    }
    if (!password || password.length < 6) {
      return res.status(400).json({ error: 'Password must be at least 6 characters long.' });
    }
    if (confirmPassword && password !== confirmPassword) {
      return res.status(400).json({ error: 'Passwords do not match.' });
    }

    const { user, verificationCode } = db.createUser({
      name: name.trim(),
      email: email.trim(),
      password,
    });

    const token = db.createSession(user.id);
    const preferences = db.getPreferences(user.id);

    return res.status(201).json({
      success: true,
      user,
      token,
      preferences,
      verificationCode, // Available for the verification flow
      message: 'Account created successfully! Please verify your email.',
    });
  } catch (err: any) {
    return res.status(400).json({ error: err.message || 'Registration failed.' });
  }
};

app.post('/api/auth/register', handleRegister);
app.post('/api/auth/signup', handleRegister);

// Login
app.post('/api/auth/login', (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !email.trim()) {
      return res.status(400).json({ error: 'Email address is required.' });
    }
    if (!password) {
      return res.status(400).json({ error: 'Password is required.' });
    }

    const userRecord = db.findUserByEmail(email);
    if (!userRecord) {
      return res.status(401).json({ error: 'No account found with this email. Please sign up.' });
    }

    const isValid = db.verifyPassword(password, userRecord.passwordHash, userRecord.salt);
    if (!isValid) {
      return res.status(401).json({ error: 'Incorrect password. Please try again or reset your password.' });
    }

    // Auto-verify email upon successful login with correct email + password
    if (!userRecord.emailVerified) {
      db.verifyUserEmail(userRecord.id);
      userRecord.emailVerified = true;
    }

    const token = db.createSession(userRecord.id);
    const preferences = db.getPreferences(userRecord.id);
    const { passwordHash, salt, verificationCode, resetToken, resetTokenExpires, ...safeUser } = userRecord;

    return res.json({
      success: true,
      user: safeUser,
      token,
      preferences,
      message: 'Welcome back to AI Pocket Chat!',
    });
  } catch (err: any) {
    return res.status(500).json({ error: err.message || 'Login failed.' });
  }
});

// Logout
app.post('/api/auth/logout', requireAuth, (req: AuthRequest, res) => {
  const authHeader = req.headers.authorization;
  const token = authHeader?.startsWith('Bearer ')
    ? authHeader.substring(7)
    : (req.headers['x-session-token'] as string);
  if (token) {
    db.deleteSession(token);
  }
  res.json({ success: true, message: 'Logged out successfully.' });
});

// Get Current User Profile & Preferences
app.get('/api/auth/me', requireAuth, (req: AuthRequest, res) => {
  const preferences = db.getPreferences(req.userId!);
  res.json({
    user: req.user,
    preferences,
  });
});

// Email Verification
app.post('/api/auth/verify-email', requireAuth, (req: AuthRequest, res) => {
  const { code } = req.body;
  const ok = db.verifyUserEmail(req.userId!, code);
  if (!ok) {
    return res.status(400).json({ error: 'Invalid verification code. Please check and try again.' });
  }
  const user = db.findUserById(req.userId!);
  const { passwordHash, salt, verificationCode, resetToken, resetTokenExpires, ...safeUser } = user!;
  res.json({ success: true, user: safeUser, message: 'Email verified successfully!' });
});

// Resend Verification Email / Code
app.post('/api/auth/resend-verification', requireAuth, (req: AuthRequest, res) => {
  const newCode = db.regenerateVerificationCode(req.userId!);
  if (!newCode) {
    return res.status(400).json({ error: 'Unable to resend verification code.' });
  }
  res.json({
    success: true,
    verificationCode: newCode,
    message: 'A new 6-digit verification code has been dispatched to your email.',
  });
});

// Forgot Password (Request Reset)
app.post('/api/auth/forgot-password', (req, res) => {
  const { email } = req.body;
  if (!email || !email.trim()) {
    return res.status(400).json({ error: 'Please enter your registered email address.' });
  }

  const result = db.createPasswordReset(email.trim());
  if (!result) {
    // For privacy, return confirmation even if not found, but indicate for user clarity
    return res.json({
      success: true,
      message: 'If an account exists with this email, a password reset link and code has been sent.',
    });
  }

  return res.json({
    success: true,
    resetToken: result.token,
    resetCode: result.code,
    message: 'Password reset code generated. Use the code or reset token to set a new password.',
  });
});

// Reset Password with Token / Code
app.post('/api/auth/reset-password', (req, res) => {
  const { identifier, newPassword, confirmPassword } = req.body;
  if (!identifier) {
    return res.status(400).json({ error: 'Reset token or verification code is required.' });
  }
  if (!newPassword || newPassword.length < 6) {
    return res.status(400).json({ error: 'New password must be at least 6 characters long.' });
  }
  if (newPassword !== confirmPassword) {
    return res.status(400).json({ error: 'Passwords do not match.' });
  }

  const ok = db.resetPasswordWithTokenOrCode(identifier.trim(), newPassword);
  if (!ok) {
    return res.status(400).json({ error: 'Invalid or expired reset token/code. Please request a new one.' });
  }

  res.json({ success: true, message: 'Password has been reset successfully! You can now log in.' });
});

// Change Password (Authenticated)
app.post('/api/auth/change-password', requireAuth, (req: AuthRequest, res) => {
  const { currentPassword, newPassword, confirmNewPassword } = req.body;
  if (!currentPassword) {
    return res.status(400).json({ error: 'Current password is required.' });
  }
  if (!newPassword || newPassword.length < 6) {
    return res.status(400).json({ error: 'New password must be at least 6 characters long.' });
  }
  if (newPassword !== confirmNewPassword) {
    return res.status(400).json({ error: 'New passwords do not match.' });
  }

  const ok = db.changePassword(req.userId!, currentPassword, newPassword);
  if (!ok) {
    return res.status(400).json({ error: 'Current password does not match.' });
  }

  res.json({ success: true, message: 'Password updated successfully.' });
});

// Delete Account
app.delete('/api/auth/delete-account', requireAuth, (req: AuthRequest, res) => {
  const { confirmText } = req.body;
  if (confirmText !== 'DELETE') {
    return res.status(400).json({ error: 'Please type DELETE to confirm account removal.' });
  }

  const ok = db.deleteUserAccount(req.userId!);
  if (!ok) {
    return res.status(400).json({ error: 'Unable to delete account.' });
  }

  res.json({ success: true, message: 'Your account and all associated data have been permanently deleted.' });
});

// ==========================================
// 2.5 ADMIN PANEL & SUPPORT TICKET ROUTES
// ==========================================

// Admin Authentication Middleware
function requireAdminAuth(req: Request, res: Response, next: NextFunction) {
  const adminPass =
    req.headers['x-admin-password'] ||
    req.query.adminPassword ||
    (req.body && req.body.adminPassword);
  const authHeader = req.headers.authorization;
  const tokenPass = authHeader?.startsWith('Bearer ') ? authHeader.substring(7) : null;

  if (adminPass === 'ALIOWNERHA' || tokenPass === 'ALIOWNERHA') {
    return next();
  }
  return res.status(401).json({ error: 'Unauthorized: Incorrect Admin Password!' });
}

// Admin Login
app.post('/api/admin/login', (req, res) => {
  const { password } = req.body;
  if (password === 'ALIOWNERHA') {
    return res.json({
      success: true,
      adminToken: 'ALIOWNERHA',
      message: 'Admin access granted!',
    });
  }
  return res.status(401).json({ error: 'Incorrect Admin Password!' });
});

// Admin: Get All Users
app.get('/api/admin/users', requireAdminAuth, (req, res) => {
  const users = db.getAllUsersForAdmin();
  res.json({ success: true, users });
});

// Admin: Get All Support Feedback / Tickets
app.get('/api/admin/feedback', requireAdminAuth, (req, res) => {
  const tickets = db.getAllTicketsForAdmin();
  res.json({ success: true, tickets });
});

// Admin: Reply to Support Ticket / Feedback
app.post('/api/admin/feedback/reply', requireAdminAuth, (req, res) => {
  const { ticketId, replyMessage } = req.body;
  if (!ticketId || !replyMessage || !replyMessage.trim()) {
    return res.status(400).json({ error: 'Ticket ID and Reply Message are required.' });
  }

  const updatedTicket = db.replyToTicket(ticketId, replyMessage.trim());
  if (!updatedTicket) {
    return res.status(404).json({ error: 'Support ticket not found.' });
  }

  res.json({
    success: true,
    message: 'Reply sent successfully!',
    ticket: updatedTicket,
  });
});

// Admin: Get All System Notifications
app.get('/api/admin/notifications', requireAdminAuth, (req, res) => {
  const notifications = db.getUserNotifications();
  res.json({ success: true, notifications });
});

// Admin: Broadcast / Send Notification to User(s)
app.post('/api/admin/notifications/broadcast', requireAdminAuth, (req, res) => {
  const { title, message, targetUserId } = req.body;
  if (!title || !message) {
    return res.status(400).json({ error: 'Title and Message are required.' });
  }

  const notification = db.addNotification({ title, message, targetUserId });
  res.json({
    success: true,
    message: 'Notification sent successfully!',
    notification,
  });
});

// Public / User Support Ticket Submission
app.post('/api/support/feedback', (req, res) => {
  const { name, email, subject, category, message, userId } = req.body;

  if (!name || !name.trim()) {
    return res.status(400).json({ error: 'Name is required.' });
  }
  if (!email || !email.trim()) {
    return res.status(400).json({ error: 'Email is required.' });
  }
  if (!subject || !subject.trim()) {
    return res.status(400).json({ error: 'Subject is required.' });
  }
  if (!message || !message.trim()) {
    return res.status(400).json({ error: 'Message is required.' });
  }

  const ticket = db.createSupportTicket({
    userId,
    userName: name,
    userEmail: email,
    subject,
    category,
    message,
  });

  res.status(201).json({
    success: true,
    message: 'Thank you! Your support request/feedback has been received by our team.',
    ticket,
  });
});

// User: Get My Support Tickets & Admin Replies
app.get('/api/support/my-tickets', (req, res) => {
  const email = (req.query.email as string) || '';
  const userId = (req.query.userId as string) || '';

  if (!email && !userId) {
    return res.json({ tickets: [] });
  }

  const tickets = db.getUserTickets(email, userId);
  res.json({ success: true, tickets });
});

// User: Get Notifications
app.get('/api/user/notifications', (req, res) => {
  const userId = (req.query.userId as string) || '';
  const notifications = db.getUserNotifications(userId);
  res.json({ success: true, notifications });
});

// ==========================================
// 3. USER PROFILE & PREFERENCES
// ==========================================
app.patch('/api/user/profile', requireAuth, (req: AuthRequest, res) => {
  const { name, bio, photoURL } = req.body;
  const updatedUser = db.updateUserProfile(req.userId!, { name, bio, photoURL });
  if (!updatedUser) {
    return res.status(404).json({ error: 'User not found.' });
  }
  res.json({ success: true, user: updatedUser });
});

app.get('/api/user/preferences', requireAuth, (req: AuthRequest, res) => {
  const preferences = db.getPreferences(req.userId!);
  res.json({ preferences });
});

app.put('/api/user/preferences', requireAuth, (req: AuthRequest, res) => {
  const updated = db.updatePreferences(req.userId!, req.body);
  res.json({ success: true, preferences: updated });
});

// ==========================================
// 4. CONVERSATIONS & CHAT HISTORY
// ==========================================

// List conversations
app.get('/api/conversations', requireAuth, (req: AuthRequest, res) => {
  const convs = db.getConversations(req.userId!);
  res.json({ conversations: convs });
});

// Create new conversation
app.post('/api/conversations', requireAuth, (req: AuthRequest, res) => {
  const { title } = req.body;
  const conv = db.createConversation(req.userId!, title);
  res.status(201).json({ conversation: conv });
});

// Get specific conversation and its messages
app.get('/api/conversations/:id', requireAuth, (req: AuthRequest, res) => {
  const conv = db.getConversationById(req.params.id, req.userId!);
  if (!conv) {
    return res.status(404).json({ error: 'Conversation not found.' });
  }
  const messages = db.getMessages(conv.id, req.userId!);
  res.json({ conversation: conv, messages });
});

// Rename conversation
app.patch('/api/conversations/:id', requireAuth, (req: AuthRequest, res) => {
  const { title } = req.body;
  if (!title || !title.trim()) {
    return res.status(400).json({ error: 'Title cannot be empty.' });
  }
  const conv = db.renameConversation(req.params.id, req.userId!, title);
  if (!conv) {
    return res.status(404).json({ error: 'Conversation not found.' });
  }
  res.json({ success: true, conversation: conv });
});

// Delete specific conversation
app.delete('/api/conversations/:id', requireAuth, (req: AuthRequest, res) => {
  const ok = db.deleteConversation(req.params.id, req.userId!);
  if (!ok) {
    return res.status(404).json({ error: 'Conversation not found.' });
  }
  res.json({ success: true, message: 'Conversation deleted.' });
});

// Delete all conversations for user
app.delete('/api/conversations', requireAuth, (req: AuthRequest, res) => {
  db.deleteAllConversations(req.userId!);
  res.json({ success: true, message: 'All conversations have been deleted.' });
});

// Message feedback (like/dislike)
app.post('/api/messages/:id/feedback', requireAuth, (req: AuthRequest, res) => {
  const { feedback } = req.body;
  const ok = db.setMessageFeedback(req.params.id, req.userId!, feedback);
  if (!ok) {
    return res.status(404).json({ error: 'Message not found.' });
  }
  res.json({ success: true });
});

// Search conversations and messages
app.get('/api/search', requireAuth, (req: AuthRequest, res) => {
  const query = (req.query.q as string) || '';
  const results = db.searchChats(req.userId!, query);
  res.json({ results });
});

// ==========================================
// 5. AI CHAT & STREAMING ENDPOINTS
// ==========================================

// Helper: Build System Instruction with Personalization
function buildSystemInstruction(prefs: any): string {
  const aiName = prefs?.personalization?.aiName || 'AI Pocket Chat';
  const style = prefs?.personalization?.responseStyle || 'Friendly';
  const length = prefs?.personalization?.responseLength || 'Balanced';
  const language = prefs?.personalization?.preferredLanguage || 'English';
  const custom = prefs?.personalization?.customInstructions || '';

  return `You are "${aiName}", an intelligent, modern, and friendly AI assistant inside AI Pocket Chat (built by Ali ABDULLAH).
Persona & Guidelines:
- Style: ${style} (adjust tone accordingly).
- Length: ${length} (be concise if Short, comprehensive if Detailed, clear and balanced if Balanced).
- Preferred Language: ${language} (respond in this language unless the user asks otherwise).
${custom ? `- User Custom Instructions: "${custom}"` : ''}
- Always format answers clearly using clean Markdown (bullet points, bold text, code blocks where suitable).
- Be polite, helpful, direct, and fast. Avoid unnecessary filler words.`;
}

// Generate smart title
app.post('/api/chat/title', requireAuth, async (req: AuthRequest, res) => {
  try {
    const { prompt } = req.body;
    if (!prompt) {
      return res.json({ title: 'New Conversation' });
    }
    const ai = getGeminiClient();
    const result = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: `Generate a concise, catchy 2-4 word title for a conversation that begins with: "${prompt.slice(0, 200)}". Output ONLY the title, no quotation marks, punctuation, or preamble.`,
    });
    const title = result.text?.trim().replace(/^["']|["']$/g, '') || 'New Conversation';
    res.json({ title: title.slice(0, 40) });
  } catch (err: any) {
    console.error('Title generation error:', err);
    res.json({ title: 'New Conversation' });
  }
});

// Streaming AI Chat Endpoint (SSE)
app.post('/api/chat/stream', requireAuth, async (req: AuthRequest, res) => {
  const { conversationId, content, regenerate } = req.body;

  if (!content || !content.trim()) {
    return res.status(400).json({ error: 'Message content cannot be empty.' });
  }

  // Ensure conversation exists or create one
  let conv = conversationId ? db.getConversationById(conversationId, req.userId!) : null;
  let isFirstMessage = false;

  if (!conv) {
    conv = db.createConversation(req.userId!, 'New Conversation');
    isFirstMessage = true;
  }

  // If not regenerating, add user's message
  let userMessage = null;
  if (!regenerate) {
    userMessage = db.addMessage({
      conversationId: conv.id,
      userId: req.userId!,
      role: 'user',
      content: content.trim(),
    });
  }

  // Check if conversation has only 1 or 2 messages for title generation
  const existingMessages = db.getMessages(conv.id, req.userId!);
  if (existingMessages.length <= 2 && (conv.title === 'New Conversation' || isFirstMessage)) {
    isFirstMessage = true;
  }

  // Get user preferences for AI personality
  const prefs = db.getPreferences(req.userId!);
  const systemInstruction = buildSystemInstruction(prefs);

  // Set SSE Headers
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.flushHeaders?.();

  // Send conversation info to client
  res.write(`data: ${JSON.stringify({ type: 'init', conversationId: conv.id, userMessage })}\n\n`);

  let accumulatedContent = '';

  try {
    const ai = getGeminiClient();

    // Prepare message history (last 12 messages for fast context)
    const recentMessages = existingMessages.slice(-12);
    const contentsPayload: any[] = recentMessages.map(m => ({
      role: m.role === 'model' ? 'model' : 'user',
      parts: [{ text: m.content }],
    }));

    // If this was a new message not yet in recentMessages, add it
    if (!regenerate && userMessage && !recentMessages.find(m => m.id === userMessage.id)) {
      contentsPayload.push({
        role: 'user',
        parts: [{ text: content.trim() }],
      });
    }

    let responseStream: any = null;
    const requestedModel = prefs.aiSettings?.model || 'gemini-3.8-flash';
    const fallbackModels = [requestedModel, 'gemini-2.5-flash'].filter((v, i, a) => a.indexOf(v) === i);

    let lastError: any = null;
    for (const modelToTry of fallbackModels) {
      try {
        responseStream = await ai.models.generateContentStream({
          model: modelToTry,
          contents: contentsPayload.length > 0 ? contentsPayload : content.trim(),
          config: {
            systemInstruction,
            temperature: prefs.aiSettings?.temperature ?? 0.7,
          },
        });
        if (responseStream) break;
      } catch (err: any) {
        lastError = err;
        console.warn(`Model ${modelToTry} attempt failed, trying fallback:`, err?.message || err);
      }
    }

    if (!responseStream && lastError) {
      throw lastError;
    }

    for await (const chunk of responseStream) {
      const chunkText = chunk.text || '';
      if (chunkText) {
        accumulatedContent += chunkText;
        res.write(`data: ${JSON.stringify({ type: 'chunk', text: chunkText })}\n\n`);
      }
    }

    // Save final assistant message to database
    const assistantMessage = db.addMessage({
      conversationId: conv.id,
      userId: req.userId!,
      role: 'model',
      content: accumulatedContent || 'No response generated.',
    });

    // Auto-generate title if this is the first turn
    let newTitle: string | null = null;
    if (isFirstMessage) {
      try {
        const titleRes = await ai.models.generateContent({
          model: 'gemini-3.8-flash',
          contents: `Generate a short, descriptive 2-4 word title for this conversation. First message was: "${content.slice(0, 150)}". Output ONLY the title text, nothing else.`,
        });
        const generated = titleRes.text?.trim().replace(/^["']|["']$/g, '');
        if (generated && generated.length > 0) {
          newTitle = generated.slice(0, 40);
          db.renameConversation(conv.id, req.userId!, newTitle);
        }
      } catch (tErr) {
        console.warn('Auto-title generation failed:', tErr);
      }
    }

    // Send complete event
    res.write(
      `data: ${JSON.stringify({
        type: 'done',
        message: assistantMessage,
        title: newTitle,
      })}\n\n`
    );
    res.end();
  } catch (streamError: any) {
    console.error('AI streaming error:', streamError);
    let errorMsg = 'AI service temporarily unavailable. Please try again.';
    if (typeof streamError?.message === 'string') {
      try {
        const parsed = JSON.parse(streamError.message);
        if (parsed?.error?.message) {
          const inner = typeof parsed.error.message === 'string' && parsed.error.message.startsWith('{')
            ? JSON.parse(parsed.error.message)
            : parsed.error;
          errorMsg = inner?.error?.message || inner?.message || errorMsg;
        }
      } catch {
        errorMsg = streamError.message;
      }
    }
    res.write(`data: ${JSON.stringify({ type: 'error', error: errorMsg })}\n\n`);
    res.end();
  }
});

// Non-streaming fallback endpoint
app.post('/api/chat/generate', requireAuth, async (req: AuthRequest, res) => {
  const { conversationId, content } = req.body;
  if (!content || !content.trim()) {
    return res.status(400).json({ error: 'Message content cannot be empty.' });
  }

  let conv = conversationId ? db.getConversationById(conversationId, req.userId!) : null;
  if (!conv) {
    conv = db.createConversation(req.userId!, 'New Conversation');
  }

  const userMessage = db.addMessage({
    conversationId: conv.id,
    userId: req.userId!,
    role: 'user',
    content: content.trim(),
  });

  const prefs = db.getPreferences(req.userId!);
  const systemInstruction = buildSystemInstruction(prefs);

  try {
    const ai = getGeminiClient();
    const result = await ai.models.generateContent({
      model: prefs.aiSettings?.model || 'gemini-3.8-flash',
      contents: content.trim(),
      config: {
        systemInstruction,
        temperature: prefs.aiSettings?.temperature ?? 0.7,
      },
    });

    const reply = result.text || 'No response generated.';
    const modelMessage = db.addMessage({
      conversationId: conv.id,
      userId: req.userId!,
      role: 'model',
      content: reply,
    });

    res.json({
      conversationId: conv.id,
      userMessage,
      modelMessage,
    });
  } catch (err: any) {
    console.error('AI generate error:', err);
    res.status(500).json({ error: err.message || 'Failed to generate AI response.' });
  }
});

// ==========================================
// 6. VITE MIDDLEWARE & STATIC ASSET SERVING
// ==========================================
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`AI Pocket Chat server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
