import express from 'express';
import path from 'path';
import fs from 'fs';
import { GoogleGenAI } from '@google/genai';
import { synthesizeViaEdgeWs } from './server/edgeNeuralClient.ts';
import { Mp3Encoder } from '@breezystack/lamejs';
import { TELUGU_VOICES, NARRATION_STYLES } from './src/data/voicesAndStyles.ts';
import { processTeluguText, splitIntoTeluguSentences } from './src/utils/textProcessor.ts';
import {
  generateYiuVoiceFilename,
  normalizePcm,
  scaleVolume,
  concatenatePcmWithPauses,
  createSilenceBuffer,
  applyDspEffect,
} from './src/audio/audioProcessor.ts';
import { encodePcmToMp3, encodePcmToWav } from './src/audio/mp3Encoder.ts';

const appDir = typeof __dirname !== 'undefined' ? __dirname : process.cwd();

const app = express();
const PORT = 3000;

app.use(express.json({ limit: '20mb' }));

// Lazy Google GenAI initialization
let aiClient: GoogleGenAI | null = null;
let geminiQuotaExhaustedUntil: number = 0;

function isGeminiQuotaExhausted(): boolean {
  return Date.now() < geminiQuotaExhaustedUntil;
}

function markGeminiQuotaExhausted(cooldownMs = 60 * 60 * 1000) {
  geminiQuotaExhaustedUntil = Date.now() + cooldownMs;
}

function getGenAI(): GoogleGenAI | null {
  if (!process.env.GEMINI_API_KEY) {
    return null;
  }
  if (!aiClient) {
    aiClient = new GoogleGenAI({
      apiKey: process.env.GEMINI_API_KEY,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return aiClient;
}

// API: Health & Status
app.get('/api/tts/status', (req, res) => {
  const isExhausted = isGeminiQuotaExhausted();
  res.json({
    status: 'ok',
    hasEdgeNeural: true,
    hasGemini: !!process.env.GEMINI_API_KEY && !isExhausted,
    isQuotaExhausted: isExhausted,
    recommendedEngine: 'edge-neural',
    engines: ['edge-neural', 'gemini-neural', 'native-telugu', 'browser-speech'],
    version: '1.2.0',
    model: 'Realistic Neural Studio (te-IN-MohanNeural / te-IN-ShrutiNeural) & Gemini 3.1 Flash',
  });
});

// API: Voices Catalog
app.get('/api/tts/voices', (req, res) => {
  res.json({
    voices: TELUGU_VOICES,
    styles: NARRATION_STYLES,
  });
});

// API: Download Android APK
app.get('/api/download/apk', (req, res) => {
  const apkPath = path.join(process.cwd(), 'public', 'yiuvoice-app.apk');
  if (fs.existsSync(apkPath)) {
    res.setHeader('Content-Type', 'application/vnd.android.package-archive');
    res.setHeader('Content-Disposition', 'attachment; filename="yiuvoice-v1.2.0.apk"');
    res.sendFile(apkPath);
  } else {
    res.status(404).json({ error: 'APK file not found' });
  }
});

// API: Download Android Studio Project ZIP
app.get('/api/download/android-project', (req, res) => {
  const projPath = path.join(process.cwd(), 'public', 'yiuvoice-android-project.zip');
  if (fs.existsSync(projPath)) {
    res.setHeader('Content-Type', 'application/zip');
    res.setHeader('Content-Disposition', 'attachment; filename="yiuvoice-android-project.zip"');
    res.sendFile(projPath);
  } else {
    res.status(404).json({ error: 'Project archive not found' });
  }
});

// Helper to synthesize native Google te-IN speech chunks
async function fetchGoogleNativeTeluguAudio(text: string): Promise<Buffer> {
  const clean = text.replace(/[\r\n\t]+/g, ' ').trim();
  if (!clean) return Buffer.alloc(0);

  // Split into chunks if longer than 120 chars for Google TTS
  const chunks: string[] = [];
  if (clean.length <= 120) {
    chunks.push(clean);
  } else {
    // Split by punctuation or spaces
    const words = clean.split(/\s+/);
    let current = '';
    for (const w of words) {
      if ((current + ' ' + w).length <= 120) {
        current = current ? current + ' ' + w : w;
      } else {
        if (current) chunks.push(current);
        current = w;
      }
    }
    if (current) chunks.push(current);
  }

  const audioBuffers: Buffer[] = [];
  for (const chunk of chunks) {
    try {
      const url = `https://translate.google.com/translate_tts?ie=UTF-8&q=${encodeURIComponent(chunk)}&tl=te&client=tw-ob`;
      const response = await fetch(url, {
        headers: {
          'User-Agent':
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        },
      });
      if (response.ok) {
        const arrayBuf = await response.arrayBuffer();
        audioBuffers.push(Buffer.from(arrayBuf));
      } else {
        console.warn(`Native Telugu TTS chunk returned status ${response.status} for chunk "${chunk.substring(0, 30)}..."`);
      }
    } catch (chunkErr: any) {
      console.warn('Native chunk fetch failed:', chunkErr.message);
    }
  }

  if (audioBuffers.length === 0) {
    throw new Error('నేటివ్ తెలుగు ఆడియో రూపొందించడంలో సాంకేతిక లోపం ఏర్పడింది. (Native Telugu synthesis temporarily unavailable)');
  }

  return Buffer.concat(audioBuffers);
}

// Map Voice ID to Gemini voice name
function resolveGeminiVoiceName(voiceId: string): string {
  const found = TELUGU_VOICES.find((v) => v.id === voiceId);
  if (found?.nativeVoiceName) {
    const valid = ['Puck', 'Charon', 'Kore', 'Fenrir', 'Zephyr', 'Aoede'];
    if (valid.includes(found.nativeVoiceName)) {
      return found.nativeVoiceName;
    }
  }

  if (voiceId.includes('male')) {
    if (voiceId.includes('deep') || voiceId.includes('storyteller')) return 'Charon';
    if (voiceId.includes('powerful') || voiceId.includes('news')) return 'Fenrir';
    if (voiceId.includes('calm')) return 'Zephyr';
    return 'Puck';
  } else {
    if (voiceId.includes('soft') || voiceId.includes('emotional')) return 'Aoede';
    return 'Kore';
  }
}

interface EdgeVoiceSynthesisConfig {
  edgeVoiceName: 'te-IN-MohanNeural' | 'te-IN-ShrutiNeural';
  pitchOffsetHz?: number;
  rateOffsetPercent?: number;
}

function resolveVoiceConfig(voiceId: string) {
  const voice = TELUGU_VOICES.find((v) => v.id === voiceId);
  const isMale = voice?.category === 'male' || voiceId.includes('male');
  const edgeVoiceName: 'te-IN-MohanNeural' | 'te-IN-ShrutiNeural' = isMale
    ? 'te-IN-MohanNeural'
    : 'te-IN-ShrutiNeural';

  return {
    voice,
    edgeVoiceName,
    pitchOffsetHz: voice?.pitchOffsetHz ?? 0,
    rateOffsetPercent: voice?.rateOffsetPercent ?? 0,
    geminiVoiceName: resolveGeminiVoiceName(voiceId),
  };
}

// Escape text for valid SSML
function escapeXml(unsafe: string): string {
  return unsafe
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

// Build human-like SSML with realistic breathing, comma breaks, sentence pauses, and paragraph timing
function buildTeluguSsml(
  rawText: string,
  voiceName: string,
  rateStr: string,
  pitchStr: string,
  volumeStr: string,
  sentencePauseMs: number,
  paragraphPauseMs: number,
  sentences?: Array<{ text: string; pauseAfter?: number; emphasis?: string }>
): string {
  let contentXml = '';

  if (sentences && sentences.length > 0) {
    const parts: string[] = [];
    for (const s of sentences) {
      if (!s.text || !s.text.trim()) continue;
      let clean = escapeXml(s.text.trim());
      // Natural comma and colon breath micro-pauses
      clean = clean
        .replace(/,\s*/g, ', <break time="220ms"/> ')
        .replace(/;\s*/g, '; <break time="340ms"/> ')
        .replace(/:\s*/g, ': <break time="340ms"/> ');

      const pauseMs = s.pauseAfter ? Math.round(s.pauseAfter * 1000) : sentencePauseMs;

      let wrapped = clean;
      if (s.emphasis === 'dramatic' || s.emphasis === 'urgent') {
        wrapped = `<emphasis level="strong">${clean}</emphasis>`;
      } else if (s.emphasis === 'high') {
        wrapped = `<emphasis level="moderate">${clean}</emphasis>`;
      } else if (s.emphasis === 'soft') {
        wrapped = `<emphasis level="reduced">${clean}</emphasis>`;
      }

      parts.push(`${wrapped} <break time="${pauseMs}ms"/>`);
    }
    contentXml = parts.join(' ');
  } else {
    // Process paragraphs
    const paragraphs = rawText.split(/\n\s*\n/).filter((p) => p.trim().length > 0);
    const paraXmls: string[] = [];

    for (const para of paragraphs) {
      // Split into sentences preserving punctuation (. ! ? | । ॥)
      const sentenceTokens = para
        .split(/(?<=[.!?|।॥])\s+/)
        .map((s) => s.trim())
        .filter(Boolean);

      if (sentenceTokens.length === 0) {
        sentenceTokens.push(para.trim());
      }

      const sentXmls: string[] = [];
      for (const sent of sentenceTokens) {
        let sentText = escapeXml(sent);

        // Add human micro-pauses at commas and semicolons for natural breath cadence
        sentText = sentText
          .replace(/,\s*/g, ', <break time="220ms"/> ')
          .replace(/;\s*/g, '; <break time="340ms"/> ')
          .replace(/:\s*/g, ': <break time="340ms"/> ');

        sentXmls.push(`${sentText} <break time="${sentencePauseMs}ms"/>`);
      }
      paraXmls.push(sentXmls.join(' '));
    }
    contentXml = paraXmls.join(` <break time="${paragraphPauseMs}ms"/> `);
  }

  return `<speak version="1.0" xmlns="http://www.w3.org/2001/10/synthesis" xml:lang="te-IN"><voice name="${voiceName}"><prosody rate="${rateStr}" pitch="${pitchStr}" volume="${volumeStr}">${contentXml}</prosody></voice></speak>`;
}

// Synthesize hyper-realistic Telugu audio via Edge Neural Studio with SSML prosody and human cadence
async function synthesizeEdgeNeuralAudio(
  text: string,
  config: EdgeVoiceSynthesisConfig,
  userSettings: {
    speed?: number;
    pitch?: number;
    volume?: number;
    sentencePause?: number;
    paragraphPause?: number;
    emphasis?: string;
  } = {},
  matchedStyle?: (typeof NARRATION_STYLES)[0],
  sentences?: Array<{ text: string; pauseAfter?: number; emphasis?: string }>
): Promise<{ buffer: Buffer; durationSec: number }> {
  // Combine voice intrinsic tuning + user slider + style multipliers
  const styleSpeed = matchedStyle ? matchedStyle.speedMultiplier : 1.0;
  const combinedSpeed = (userSettings.speed ?? 1.0) * styleSpeed;
  const userRatePercent = Math.round((combinedSpeed - 1.0) * 100);
  const totalRate = Math.max(-50, Math.min(100, (config.rateOffsetPercent || 0) + userRatePercent));
  const rateStr = totalRate >= 0 ? `+${totalRate}%` : `${totalRate}%`;

  const stylePitch = matchedStyle ? matchedStyle.pitchOffset : 0;
  const combinedPitch = (userSettings.pitch ?? 0) + stylePitch;
  const userPitchHz = Math.round(combinedPitch * 3);
  const totalPitch = Math.max(-50, Math.min(50, (config.pitchOffsetHz || 0) + userPitchHz));
  const pitchStr = totalPitch >= 0 ? `+${totalPitch}Hz` : `${totalPitch}Hz`;

  const userVolPercent = Math.max(10, Math.min(100, userSettings.volume ?? 100));
  const volOffset = Math.round(userVolPercent - 100);
  const volumeStr = volOffset >= 0 ? `+${volOffset}%` : `${volOffset}%`;

  // Pause duration calculation with style defaults and user overrides
  const baseSentencePauseMs = matchedStyle ? matchedStyle.sentencePauseMs : 400;
  const sentencePauseMs =
    userSettings.sentencePause !== undefined && userSettings.sentencePause !== 0.4
      ? Math.round(userSettings.sentencePause * 1000)
      : baseSentencePauseMs;

  const baseParagraphPauseMs = matchedStyle ? matchedStyle.paragraphPauseMs : 800;
  const paragraphPauseMs =
    userSettings.paragraphPause !== undefined && userSettings.paragraphPause !== 0.8
      ? Math.round(userSettings.paragraphPause * 1000)
      : baseParagraphPauseMs;

  // Build realistic Telugu SSML
  const ssml = buildTeluguSsml(
    text,
    config.edgeVoiceName,
    rateStr,
    pitchStr,
    volumeStr,
    sentencePauseMs,
    paragraphPauseMs,
    sentences
  );

  const estimatedDuration = Math.max(0.6, Math.round((text.length / 13) * 10) / 10);

  try {
    const buffer = await synthesizeViaEdgeWs(ssml, 'audio-24khz-96kbitrate-mono-mp3');
    return { buffer, durationSec: estimatedDuration };
  } catch (ssmlErr: any) {
    console.warn('SSML synthesis had warning, using direct prosody fallback:', ssmlErr?.message);
    const plainSsml = `<speak version="1.0" xmlns="http://www.w3.org/2001/10/synthesis" xml:lang="te-IN"><voice name="${config.edgeVoiceName}"><prosody rate="${rateStr}" pitch="${pitchStr}" volume="${volumeStr}">${escapeXml(text)}</prosody></voice></speak>`;
    const fallbackBuffer = await synthesizeViaEdgeWs(plainSsml, 'audio-24khz-96kbitrate-mono-mp3');
    return {
      buffer: fallbackBuffer,
      durationSec: estimatedDuration,
    };
  }
}

// API: Generate Speech
app.post('/api/tts/generate', async (req, res) => {
  try {
    const {
      text,
      voiceId = 'te-male-mohan',
      engine = 'edge-neural',
      narrationStyle = 'normal',
      settings = { speed: 1.0, pitch: 0, volume: 100, sentencePause: 0.4 },
      audioSettings = { format: 'mp3', bitrate: 192, sampleRate: 24000, normalizeVolume: true },
      textSettings = {
        autoPunctuation: true,
        numberPronunciation: true,
        englishLoanwordTransliteration: true,
        abbreviationHandling: true,
        currencyPronunciation: true,
      },
      pronunciationRules = [],
      sentences = [],
    } = req.body;

    if (!text || !text.trim()) {
      res.status(400).json({ error: 'దయచేసి తెలుగు టెక్స్ట్ నమోదు చేయండి. (Please enter some Telugu text.)' });
      return;
    }

    // Step 1: Pre-process text (Pronunciation rules, numbers -> Telugu words, punctuation)
    const processedText = processTeluguText(text, textSettings, pronunciationRules);
    if (!processedText) {
      res.status(400).json({ error: 'Text processing produced empty result.' });
      return;
    }

    const cfg = resolveVoiceConfig(voiceId);
    const matchedStyle = NARRATION_STYLES.find((s) => s.id === narrationStyle) || NARRATION_STYLES[0];
    const filename = generateYiuVoiceFilename(audioSettings.format || 'mp3');

    // Choice of TTS engine:
    // If the voice is a realistic voice or engine is edge-neural or gemini quota is out:
    const isQuotaOut = isGeminiQuotaExhausted();
    const isRealisticVoice =
      cfg.voice?.isRealistic ||
      cfg.voice?.engine === 'edge-neural' ||
      engine === 'edge-neural';

    if (isRealisticVoice || (engine === 'gemini-neural' && isQuotaOut)) {
      try {
        const { buffer, durationSec } = await synthesizeEdgeNeuralAudio(
          processedText,
          cfg,
          settings,
          matchedStyle,
          sentences && sentences.length > 0 ? sentences : undefined
        );
        res.json({
          audioBase64: buffer.toString('base64'),
          format: 'mp3',
          durationSec,
          filename,
          voiceUsed: voiceId,
          engineUsed: 'edge-neural',
          narrationStyleUsed: narrationStyle,
          processedText,
          generatedAt: new Date().toISOString(),
          fallbackNote:
            engine === 'gemini-neural' && isQuotaOut
              ? 'జెమిని కోటా పరిమితి కారణంగా అత్యున్నత నాణ్యత గల రియలిస్టిక్ న్యూరల్ స్టూడియో గళంతో ఆడియో రూపొందించబడింది.'
              : undefined,
        });
        return;
      } catch (edgeErr: any) {
        console.warn('Edge neural synthesis failed, attempting fallback:', edgeErr.message);
      }
    }

    // Choice of TTS engine for Gemini Neural
    const ai = getGenAI();
    const canUseGemini = engine === 'gemini-neural' && !!ai && !isQuotaOut;
    let fallbackNote: string | undefined = undefined;

    if (canUseGemini) {
      try {
        // Use Studio-grade Gemini Neural TTS
        const voiceName = cfg.geminiVoiceName;
        const styleDirective = matchedStyle.promptDirective;
        const prompt = `Read the following Telugu text with natural pronunciation and cadence. Voice style directive: ${styleDirective}\n\nTelugu text:\n${processedText}`;

        const response = await ai.models.generateContent({
          model: 'gemini-3.8-flash-lite-tts',
          contents: [{ parts: [{ text: prompt }] }],
          config: {
            responseModalities: ['AUDIO'],
            speechConfig: {
              voiceConfig: {
                prebuiltVoiceConfig: { voiceName },
              },
            },
          },
        });

        const audioPart = response.candidates?.[0]?.content?.parts?.[0];
        const rawBase64 = audioPart?.inlineData?.data;

        if (!rawBase64) {
          throw new Error('Gemini TTS did not return audio data.');
        }

        // Raw audio is 24000Hz mono 16-bit PCM
        const rawBuffer = Buffer.from(rawBase64, 'base64');
        const pcmArrayBuffer = rawBuffer.buffer.slice(
          rawBuffer.byteOffset,
          rawBuffer.byteOffset + rawBuffer.byteLength
        );
        let pcmSamples: Int16Array<any> = new Int16Array(pcmArrayBuffer);

        // Apply volume scale / normalization
        const volFactor = (settings.volume || 100) / 100;
        if (audioSettings.normalizeVolume) {
          pcmSamples = normalizePcm(pcmSamples, volFactor);
        } else if (volFactor !== 1.0) {
          pcmSamples = scaleVolume(pcmSamples, volFactor);
        }

        const sampleRate = 24000;

        if (settings.dspEffect && settings.dspEffect !== 'none') {
          pcmSamples = applyDspEffect(pcmSamples, settings.dspEffect, sampleRate);
        }

        const durationSec = Math.round((pcmSamples.length / sampleRate) * 100) / 100;

        let finalAudioBytes: Uint8Array;
        if (audioSettings.format === 'wav') {
          finalAudioBytes = encodePcmToWav(pcmSamples, sampleRate, 1);
        } else {
          finalAudioBytes = encodePcmToMp3(
            pcmSamples,
            sampleRate,
            audioSettings.bitrate || 192,
            1
          );
        }

        const audioBase64 = Buffer.from(finalAudioBytes).toString('base64');

        res.json({
          audioBase64,
          format: audioSettings.format || 'mp3',
          durationSec,
          filename,
          voiceUsed: voiceId,
          engineUsed: 'gemini-neural',
          narrationStyleUsed: narrationStyle,
          processedText,
          generatedAt: new Date().toISOString(),
        });
        return;
      } catch (geminiErr: any) {
        const isQuota =
          geminiErr.status === 429 ||
          geminiErr.message?.includes('429') ||
          geminiErr.message?.includes('quota') ||
          geminiErr.message?.includes('RESOURCE_EXHAUSTED');
        if (isQuota) {
          markGeminiQuotaExhausted(60 * 60 * 1000);
        }

        // Seamless fallback to Realistic Edge Neural
        try {
          const { buffer, durationSec } = await synthesizeEdgeNeuralAudio(
            processedText,
            cfg,
            settings,
            matchedStyle,
            sentences && sentences.length > 0 ? sentences : undefined
          );
          res.json({
            audioBase64: buffer.toString('base64'),
            format: 'mp3',
            durationSec,
            filename,
            voiceUsed: voiceId,
            engineUsed: 'edge-neural',
            narrationStyleUsed: narrationStyle,
            processedText,
            fallbackNote:
              'జెమిని కోటా పరిమితి కారణంగా అత్యున్నత నాణ్యత గల రియలిస్టిక్ న్యూరల్ స్టూడియో గళంతో ఆడియో రూపొందించబడింది.',
            generatedAt: new Date().toISOString(),
          });
          return;
        } catch {}

        fallbackNote = isQuota
          ? 'Gemini 3.1 TTS ఉచిత కోటా ముగిసింది. మీ ఆడియో హై-క్వాలిటీ నేటివ్ తెలుగు ఇంజిన్ ద్వారా విజయవంతంగా సిద్ధమైంది.'
          : 'జెమిని సర్వీస్ అందుబాటులో లేనందున నేటివ్ తెలుగు ఇంజిన్ ద్వారా ధ్వని విజయవంతంగా రూపొందించబడింది.';
      }
    }

    // Fallback or explicit Native Engine (Google te-IN)
    const nativeMp3Buffer = await fetchGoogleNativeTeluguAudio(processedText);
    const durationSec = Math.max(1, Math.round((processedText.length / 14) * 10) / 10);
    const audioBase64 = nativeMp3Buffer.toString('base64');

    res.json({
      audioBase64,
      format: 'mp3',
      durationSec,
      filename,
      voiceUsed: voiceId,
      engineUsed: 'native-telugu',
      narrationStyleUsed: narrationStyle,
      processedText,
      fallbackNote,
      generatedAt: new Date().toISOString(),
    });
  } catch (err: any) {
    res.status(500).json({
      error: err.message || 'ధ్వని ఉత్పత్తిలో లోపం సంభవించింది. (Voice generation failed. Please try again.)',
    });
  }
});

// Single Sentence Preview & Voice Sample Preview
app.post('/api/tts/preview-sentence', async (req, res) => {
  try {
    const { text, voiceId = 'te-male-mohan', narrationStyle = 'normal' } = req.body;
    if (!text || !text.trim()) {
      res.status(400).json({ error: 'No sentence provided' });
      return;
    }

    const cfg = resolveVoiceConfig(voiceId);
    const matchedStyle = NARRATION_STYLES.find((s) => s.id === narrationStyle);

    // Tier 1: Try Realistic Neural Studio Engine (Edge Neural with SSML)
    try {
      const { buffer, durationSec } = await synthesizeEdgeNeuralAudio(
        text,
        cfg,
        {},
        matchedStyle
      );
      res.json({
        audioBase64: buffer.toString('base64'),
        format: 'mp3',
        durationSec,
        engineUsed: 'edge-neural',
      });
      return;
    } catch (edgeErr: any) {
      console.warn('Preview Edge neural tier had issue, trying Gemini fallback:', edgeErr?.message);
    }

    // Tier 2: Try Gemini 3.8 Flash Lite TTS
    const ai = getGenAI();
    if (ai && !isGeminiQuotaExhausted()) {
      try {
        const voiceName = cfg.geminiVoiceName;
        const prompt = `Say in clear Telugu: ${text}`;
        const response = await ai.models.generateContent({
          model: 'gemini-3.8-flash-lite-tts',
          contents: [{ parts: [{ text: prompt }] }],
          config: {
            responseModalities: ['AUDIO'],
            speechConfig: {
              voiceConfig: {
                prebuiltVoiceConfig: { voiceName },
              },
            },
          },
        });

        const audioPart = response.candidates?.[0]?.content?.parts?.[0];
        const rawBase64 = audioPart?.inlineData?.data;
        if (rawBase64) {
          const rawBuffer = Buffer.from(rawBase64, 'base64');
          const pcmSamples = new Int16Array(
            rawBuffer.buffer,
            rawBuffer.byteOffset,
            rawBuffer.byteLength / 2
          );
          const mp3Bytes = encodePcmToMp3(pcmSamples, 24000, 192, 1);
          res.json({
            audioBase64: Buffer.from(mp3Bytes).toString('base64'),
            format: 'mp3',
            durationSec: pcmSamples.length / 24000,
            engineUsed: 'gemini-neural',
          });
          return;
        }
      } catch (geminiErr: any) {
        console.warn('Preview Gemini tier had issue:', geminiErr?.message);
        const isQuota =
          geminiErr.status === 429 ||
          geminiErr.message?.includes('429') ||
          geminiErr.message?.includes('quota') ||
          geminiErr.message?.includes('RESOURCE_EXHAUSTED');
        if (isQuota) {
          markGeminiQuotaExhausted(60 * 60 * 1000);
        }
      }
    }

    // Tier 3: Guaranteed Google Native Telugu Fallback
    try {
      const nativeBuf = await fetchGoogleNativeTeluguAudio(text);
      res.json({
        audioBase64: nativeBuf.toString('base64'),
        format: 'mp3',
        durationSec: Math.max(1, Math.round((text.length / 15) * 10) / 10),
        engineUsed: 'native-telugu',
      });
      return;
    } catch (nativeErr: any) {
      console.error('All TTS preview tiers failed:', nativeErr?.message);
      res.status(500).json({ error: 'Preview audio temporarily unavailable' });
    }
  } catch (err: any) {
    console.error('Unhandled error in preview endpoint:', err);
    res.status(500).json({ error: err.message || 'Preview generation failed' });
  }
});

// Setup Vite or Static File Serving
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`YiuVoice Telugu Studio Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
