import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { GoogleGenAI, ThinkingLevel } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;

app.use(express.json({ limit: '2mb' }));

// Reusable Gemini client factory
function getGeminiClient() {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return null;
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// Health check
app.get('/api/health', (_req: Request, res: Response) => {
  res.json({ ok: true, timestamp: Date.now() });
});

// Real HTTP Ping endpoint for RTT & jitter measurement
app.get('/api/network/ping', (_req: Request, res: Response) => {
  res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate');
  res.json({ pong: true, serverTime: Date.now() });
});

// Real HTTP Download throughput test endpoint (streams N KB of non-compressible pseudo-random bytes)
app.get('/api/network/download', (req: Request, res: Response) => {
  const sizeKb = Math.min(Math.max(Number(req.query.sizeKb) || 2048, 256), 8192);
  const totalBytes = sizeKb * 1024;
  const buffer = Buffer.allocUnsafe(totalBytes);
  // Fill with repeating fast pattern to prevent transparent zero-compression skew
  for (let i = 0; i < totalBytes; i += 4) {
    buffer.writeUInt32LE((i * 2654435761) >>> 0, i);
  }
  res.setHeader('Content-Type', 'application/octet-stream');
  res.setHeader('Content-Length', totalBytes.toString());
  res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate');
  res.send(buffer);
});

// Real HTTP Upload throughput test endpoint
app.post(
  '/api/network/upload',
  express.raw({ type: 'application/octet-stream', limit: '8mb' }),
  (req: Request, res: Response) => {
    const start = performance.now();
    const receivedBytes = Buffer.isBuffer(req.body) ? req.body.length : 0;
    const elapsedMs = Math.max(performance.now() - start, 0.1);
    res.setHeader('Cache-Control', 'no-store');
    res.json({
      receivedBytes,
      serverProcessMs: Number(elapsedMs.toFixed(2)),
      timestamp: Date.now(),
    });
  }
);

// AI Game Coach powered by Gemini
app.post('/api/coach', async (req: Request, res: Response) => {
  try {
    const ai = getGeminiClient();
    if (!ai) {
      res.status(503).json({
        error: 'GEMINI_API_KEY is not configured in Settings > Secrets.',
      });
      return;
    }

    const { messages, deviceContext, language } = req.body as {
      messages?: Array<{ role: 'user' | 'assistant'; content: string }>;
      deviceContext?: Record<string, unknown>;
      language?: string;
    };

    if (!Array.isArray(messages) || messages.length === 0) {
      res.status(400).json({ error: 'Messages array is required.' });
      return;
    }

    const systemInstruction = `You are the AI Game Coach inside "Gaming Mode – Game Booster PRO", a precision mobile & browser gaming performance assistant.
Your tone is concise, authoritative, practical, and technically honest.
Rules:
1. Never claim you can overclock CPU/GPU clocks, unlock root kernel governors, or alter system files without Android system permissions. Clearly separate app-level or in-game graphics/network settings from OS-restricted hardware settings.
2. When device telemetry is provided, tailor advice specifically to the user's real hardware (CPU cores, RAM tier, measured FPS, screen Hz, battery level, measured ping/download/upload, and selected game).
3. Structure recommendations cleanly with short headings or numbered steps (no code-comment syntax like // or fake system statuses).
4. Keep responses focused and actionable (roughly 120–260 words unless the user asks for an in-depth guide).
5. Respond in the user's selected language code if specified (${language || 'en'}).`;

    const contextPrefix = deviceContext
      ? `Current Live Device & Network Context:\n${JSON.stringify(deviceContext, null, 2)}\n\n`
      : '';

    const contents = messages.map((m, idx) => ({
      role: m.role === 'assistant' ? 'model' : 'user',
      parts: [
        {
          text:
            idx === 0 && m.role === 'user' && contextPrefix
              ? `${contextPrefix}User Request: ${m.content}`
              : m.content,
        },
      ],
    }));

    const response = await ai.models.generateContent({
      model: 'gemini-4-hydrogen',
      contents,
      config: {
        systemInstruction,
        thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
      },
    });

    res.json({
      reply: response.text ?? 'Unable to generate a coaching response right now.',
      model: 'gemini-4-hydrogen',
    });
  } catch (err: unknown) {
    const message =
      err instanceof Error ? err.message : 'Failed to communicate with Gemini API.';
    const status = message.includes('403') || message.includes('PERMISSION_DENIED')
      ? 403
      : message.includes('429') || message.includes('RESOURCE_EXHAUSTED')
      ? 429
      : 500;
    res.status(status).json({ error: message });
  }
});

async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';

  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('/{*splat}', (_req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Gaming Mode – Game Booster PRO running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
