import express from 'express';
import type { Request, Response, NextFunction } from 'express';
import path from 'path';
import fs from 'fs';
import https from 'https';
import { fileURLToPath } from 'url';
import crypto from 'crypto';
import { defaultStore } from './src/data/defaults.ts';
import type { AdminStore, StoredAccount } from './src/data/defaults.ts';
import type { ProjectSubmission, GalleryItem, UserAccount, SupportTicket, ServiceProductItem, TicketAttachment, TicketMessage, AiChatMessage, VouchItem, VouchStatus } from './src/types/index.ts';
import { initializeApp, getApps, getApp } from 'firebase/app';
import { getFirestore, doc, getDoc, setDoc, deleteDoc, collection, getDocs } from 'firebase/firestore';
import { GoogleGenAI } from '@google/genai';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = Number(process.env.PORT) || 3000;
const isVercel = Boolean(process.env.VERCEL);
const DATA_DIR = isVercel ? '/tmp/data' : path.resolve(__dirname, 'data');
const UPLOADS_DIR = isVercel ? '/tmp/uploads' : path.resolve(__dirname, 'uploads');
const STORE_FILE = path.join(DATA_DIR, 'store.json');
const BUNDLED_STORE_FILE = path.resolve(__dirname, 'data', 'store.json');

// Ensure necessary directories exist
try {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
  if (!fs.existsSync(UPLOADS_DIR)) {
    fs.mkdirSync(UPLOADS_DIR, { recursive: true });
  }
} catch (dirErr) {
  console.warn('[Server] Notice: Storage directory creation skipped or failed:', dirErr);
}

// Session secret
const SESSION_SECRET = process.env.SESSION_SECRET || 'cubix_secure_session_secret_2026_' + crypto.randomBytes(16).toString('hex');

// ================= EMAIL VALIDATION & NORMALIZATION =================
function normalizeEmail(email: unknown): string {
  return String(email || '').trim().toLowerCase();
}

function isValidEmail(email: string): boolean {
  const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return re.test(email);
}

// ================= PASSWORD HASHING UTILITIES =================
function hashPassword(password: string, salt = crypto.randomBytes(16).toString('hex')): { hash: string; salt: string } {
  const hash = crypto.pbkdf2Sync(password, salt, 10000, 64, 'sha512').toString('hex');
  return { hash, salt };
}

function verifyPassword(password: string, hash: string, salt: string): boolean {
  try {
    const check = crypto.pbkdf2Sync(password, salt, 10000, 64, 'sha512').toString('hex');
    return crypto.timingSafeEqual(Buffer.from(check, 'hex'), Buffer.from(hash, 'hex'));
  } catch {
    return false;
  }
}

function createToken(account: StoredAccount): string {
  const payload = `${account.id}:${account.role}:${Date.now()}`;
  const sig = crypto.createHmac('sha256', SESSION_SECRET).update(payload).digest('hex');
  return 'cst_' + Buffer.from(`${payload}:${sig}`).toString('base64');
}

function parseAndVerifyToken(token: string): { accountId: string; role: string } | null {
  try {
    if (!token.startsWith('cst_')) return null;
    const raw = Buffer.from(token.replace('cst_', ''), 'base64').toString('utf-8');
    const parts = raw.split(':');
    if (parts.length < 4) return null;
    const [accountId, role, timestampStr, signature] = parts;
    const payload = `${accountId}:${role}:${timestampStr}`;
    const expectedSig = crypto.createHmac('sha256', SESSION_SECRET).update(payload).digest('hex');
    if (!crypto.timingSafeEqual(Buffer.from(signature, 'hex'), Buffer.from(expectedSig, 'hex'))) {
      return null;
    }
    // Token valid for 7 days
    const timestamp = Number(timestampStr);
    if (Date.now() - timestamp > 7 * 24 * 60 * 60 * 1000) {
      return null;
    }
    return { accountId, role };
  } catch {
    return null;
  }
}

// In-memory cache + persistent file sync
let currentStore: AdminStore = { ...defaultStore };

try {
  let raw = '';
  const candidateFiles = [
    STORE_FILE,
    BUNDLED_STORE_FILE,
    path.resolve(process.cwd(), 'data', 'store.json'),
    path.resolve(__dirname, '..', 'data', 'store.json')
  ];

  for (const candidate of candidateFiles) {
    if (fs.existsSync(candidate)) {
      try {
        raw = fs.readFileSync(candidate, 'utf-8');
        if (raw) break;
      } catch (_) {}
    }
  }

  if (raw) {
    const parsed = JSON.parse(raw);
    currentStore = {
      ...defaultStore,
      ...parsed,
      settings: { ...defaultStore.settings, ...(parsed.settings || {}) },
      reputationData: { ...defaultStore.reputationData, ...(parsed.reputationData || {}) },
      adminAuth: { ...defaultStore.adminAuth, ...(parsed.adminAuth || {}) },
      financialRecords: parsed.financialRecords || defaultStore.financialRecords,
      submissions: parsed.submissions || defaultStore.submissions,
      faqs: parsed.faqs || defaultStore.faqs,
      services: parsed.services || defaultStore.services,
      serviceProducts: parsed.serviceProducts || defaultStore.serviceProducts || [],
      supportTickets: parsed.supportTickets || defaultStore.supportTickets || [],
      gallery: parsed.gallery || defaultStore.gallery || [],
      aiAssistant: { ...defaultStore.aiAssistant, ...(parsed.aiAssistant || {}) },
      accounts: parsed.accounts || []
    };
  } else if (!isVercel) {
    fs.writeFileSync(STORE_FILE, JSON.stringify(currentStore, null, 2), 'utf-8');
  }
} catch (err) {
  console.error('[Store] Error initializing data store, using defaults:', err);
}

// ================= ONE FIXED ADMINISTRATOR ACCOUNT CONFIGURATION =================
// Strictly supports exactly one authorized administrator account:
// Username: "OscarCruz" | Email: "admin@cubix.std" or "real1cubix@gmail.com"
const PRIMARY_ADMIN_USERNAME = 'OscarCruz';
const PRIMARY_ADMIN_EMAIL = 'admin@cubix.std';
const AUTHORIZED_ADMIN_EMAILS = [PRIMARY_ADMIN_EMAIL, 'real1cubix@gmail.com'];
const PRIMARY_ADMIN_PASS = process.env.ADMIN_PASS || currentStore.adminAuth?.pass || '9910970932';

if (!Array.isArray(currentStore.accounts)) {
  currentStore.accounts = [];
}

// Safely find existing admin account by ID, email, or username
let adminAccount = currentStore.accounts.find(
  (a) =>
    a.id === 'acc_admin_root' ||
    normalizeEmail(a.email) === PRIMARY_ADMIN_EMAIL ||
    (a.username && a.username.toLowerCase() === PRIMARY_ADMIN_USERNAME.toLowerCase()) ||
    (a.username && a.username.toLowerCase() === 'oscar')
);

if (!adminAccount) {
  const adminHashed = hashPassword(PRIMARY_ADMIN_PASS);
  adminAccount = {
    id: 'acc_admin_root',
    email: PRIMARY_ADMIN_EMAIL,
    username: PRIMARY_ADMIN_USERNAME,
    name: 'Oscar Cruz',
    role: 'admin',
    status: 'active',
    passwordHash: adminHashed.hash,
    salt: adminHashed.salt,
    createdAt: new Date().toISOString()
  };
} else {
  // Ensure the account has exact credentials and full Admin role
  adminAccount.id = 'acc_admin_root';
  adminAccount.email = PRIMARY_ADMIN_EMAIL;
  adminAccount.username = PRIMARY_ADMIN_USERNAME;
  adminAccount.name = 'Oscar Cruz';
  adminAccount.role = 'admin';
  adminAccount.status = 'active';

  // Make initialization safe to repeat without unexpectedly overwriting an existing password
  if (!adminAccount.passwordHash || !adminAccount.salt) {
    const adminHashed = hashPassword(PRIMARY_ADMIN_PASS);
    adminAccount.passwordHash = adminHashed.hash;
    adminAccount.salt = adminHashed.salt;
  }
}

// The system strictly supports exactly one authorized administrator account
// The system strictly supports exactly one authorized administrator account
currentStore.accounts = [adminAccount];

// ================= PERSISTENT DATA STORAGE =================
// Standalone reliable persistence using store.json and file backups

let lastStoreDiskMtime = 0;

async function persistStore(): Promise<boolean> {
  currentStore.lastUpdated = new Date().toISOString();

  // Synchronize to local filesystem backup
  try {
    fs.writeFileSync(STORE_FILE, JSON.stringify(currentStore, null, 2), 'utf-8');
    try {
      lastStoreDiskMtime = fs.statSync(STORE_FILE).mtimeMs;
    } catch (_) {}
    if (!isVercel && STORE_FILE !== BUNDLED_STORE_FILE && fs.existsSync(path.dirname(BUNDLED_STORE_FILE))) {
      try {
        fs.writeFileSync(BUNDLED_STORE_FILE, JSON.stringify(currentStore, null, 2), 'utf-8');
      } catch (_) {}
    }
  } catch (err) {
    console.error('[Store] Failed to write to store.json backup:', err);
  }

  // Synchronize to authoritative Firestore store
  syncToFirestore(currentStore).catch((err) => {
    console.warn('[Store] Background Firestore sync notice:', err?.message);
  });

  return true;
}

const TARGET_FIREBASE_PROJECT_ID = process.env.VITE_FIREBASE_PROJECT_ID || 'gen-lang-client-0642412032';
const TARGET_FIRESTORE_DATABASE_ID =
  process.env.VITE_FIREBASE_DATABASE_ID || 'ai-studio-cubixstudiogloba-56ae10ae-a948-4558-ab74-2c1a5de01e30';

const serverFirebaseApp =
  getApps().length > 0
    ? getApp()
    : initializeApp({
        projectId: TARGET_FIREBASE_PROJECT_ID,
        appId: '1:870011618894:web:4fd3343b2ec58ff056251f',
        apiKey: 'AIzaSyAptq84tqzsLU6_PMp7RWI61qkmU7GFbuo',
        authDomain: 'gen-lang-client-0642412032.firebaseapp.com'
      });

const serverDb = getFirestore(serverFirebaseApp, TARGET_FIRESTORE_DATABASE_ID);

async function syncToFirestore(store: AdminStore): Promise<void> {
  try {
    const { adminAuth, accounts, ...safeData } = store;
    const cleaned = JSON.parse(JSON.stringify(safeData));
    if (cleaned.reputationData && typeof cleaned.reputationData === 'object') {
      for (const k of Object.keys(cleaned.reputationData)) {
        if (cleaned.reputationData[k]?.metrics) {
          cleaned.reputationData[k].metrics = cleaned.reputationData[k].metrics.map((m: any) =>
            Array.isArray(m) ? { label: String(m[0] || ''), value: String(m[1] || '') } : m
          );
        }
      }
    }
    await setDoc(doc(serverDb, 'cubix_store', 'main_store'), cleaned, { merge: true });
    console.log('[Firestore] Synced server store to named database cubix_store/main_store');
  } catch (err: any) {
    console.warn('[Firestore] Sync warning:', err.message);
  }
}

async function syncFromFirestore(): Promise<void> {
  try {
    const snap = await getDoc(doc(serverDb, 'cubix_store', 'main_store'));
    if (snap.exists()) {
      const data = snap.data();
      console.log('[Firestore] Server hydrated from named database on boot');
      if (data.founders) currentStore.founders = data.founders;
      if (data.projects) currentStore.projects = data.projects;
      if (data.services) currentStore.services = data.services;
      if (data.serviceProducts) currentStore.serviceProducts = data.serviceProducts;
      if (data.gallery) currentStore.gallery = data.gallery;
      if (data.settings) {
        currentStore.settings = {
          ...currentStore.settings,
          ...data.settings,
          heroBackground: {
            ...defaultStore.settings.heroBackground,
            ...(currentStore.settings?.heroBackground || {}),
            ...(data.settings?.heroBackground || {})
          }
        };
      }
      if (data.aiAssistant) currentStore.aiAssistant = { ...defaultStore.aiAssistant, ...currentStore.aiAssistant, ...data.aiAssistant };
      if (Array.isArray(data.supportTickets)) currentStore.supportTickets = data.supportTickets;
      if (Array.isArray(data.vouches)) currentStore.vouches = data.vouches;
      if (Array.isArray(data.submissions)) currentStore.submissions = data.submissions;
      if (data.faqs) currentStore.faqs = data.faqs;
      if (data.financialRecords) currentStore.financialRecords = data.financialRecords;
      if (data.reputationData) {
        const repCopy = JSON.parse(JSON.stringify(data.reputationData));
        for (const k of Object.keys(repCopy)) {
          if (repCopy[k] && Array.isArray(repCopy[k].metrics)) {
            repCopy[k].metrics = repCopy[k].metrics.map((m: any) => {
              if (Array.isArray(m)) return m;
              if (m && typeof m === 'object' && ('label' in m || 'value' in m)) {
                return [m.label || '', m.value || ''];
              }
              return m;
            });
          }
        }
        currentStore.reputationData = repCopy;
      }
      if (data.lastUpdated) currentStore.lastUpdated = data.lastUpdated;

      try {
        const vouchesSnap = await getDocs(collection(serverDb, 'vouches'));
        if (!vouchesSnap.empty) {
          const map = new Map<string, VouchItem>();
          for (const v of currentStore.vouches || []) {
            if (v && v.id) map.set(v.id, v);
          }
          vouchesSnap.forEach((d) => {
            const vData = d.data() as VouchItem;
            if (vData && vData.name) {
              map.set(vData.id || d.id, { ...vData, id: vData.id || d.id });
            }
          });
          currentStore.vouches = Array.from(map.values());
        }
      } catch (_) {}

      try {
        fs.writeFileSync(STORE_FILE, JSON.stringify(currentStore, null, 2), 'utf-8');
      } catch (_) {}
    }
  } catch (err: any) {
    console.warn('[Firestore] Startup read notice:', err.message);
  }
}

const dbInitPromise: Promise<void> = syncFromFirestore();

async function ensureLatestStore(): Promise<void> {
  // Cloud Firestore is authoritative. Memory store is refreshed on boot and admin writes.
}

app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Static serving for uploaded project files and images
app.use('/uploads', express.static(UPLOADS_DIR));

// CORS headers
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, PATCH, DELETE, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-Requested-With');
  if (req.method === 'OPTIONS') {
    return res.sendStatus(200);
  }
  next();
});

// Normalize incoming API path for serverless routing compatibility
app.use((req: Request, _res: Response, next: NextFunction) => {
  if (req.url && !req.url.startsWith('/api') && !req.url.startsWith('/uploads') && !req.url.startsWith('/@') && !req.url.startsWith('/assets') && !req.url.startsWith('/src')) {
    const apiPrefixes = ['/admin', '/auth', '/data', '/ping', '/submissions', '/contact', '/download', '/founder', '/health', '/ticket-settings', '/tickets', '/service-products', '/database'];
    if (apiPrefixes.some((p) => req.url.startsWith(p))) {
      req.url = '/api' + req.url;
    }
  }
  next();
});

// Ensure database connection and initial schema/data sync have settled before processing any API request
app.use(async (req: Request, _res: Response, next: NextFunction) => {
  if (req.url && req.url.startsWith('/api')) {
    if (dbInitPromise) {
      try {
        await dbInitPromise;
      } catch (err: any) {
        console.warn('[Database] Pre-request DB init notice:', err.message);
      }
    }
    // Ensure the request reads the freshest database/disk store
    await ensureLatestStore();
  }
  next();
});

// ================= CLEAN URLS & REDIRECTS =================
// Redirect old paths or home variations to clean /home, /founders, /admin
app.get(['/', '/index.html', '/home.html', '/index'], (req: Request, res: Response) => {
  res.redirect(302, '/home');
});

app.get(['/founder.html', '/founders.html', '/meet-founders'], (req: Request, res: Response) => {
  res.redirect(301, '/founders');
});

app.get(['/admin.html', '/dashboard.html'], (req: Request, res: Response) => {
  res.redirect(301, '/admin');
});

// ================= AUTHENTICATION MIDDLEWARES =================
interface AuthenticatedRequest extends Request {
  user?: StoredAccount;
}

function requireAuth(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Unauthorized: Authentication token required.' });
  }

  const token = authHeader.split(' ')[1];
  const verified = parseAndVerifyToken(token);
  if (!verified) {
    // Fallback for legacy tokens during active migration
    try {
      const decoded = Buffer.from(token.replace('cst_', ''), 'base64').toString('utf-8');
      const [tokenAdminId] = decoded.split(':');
      const legacyAccount = (currentStore.accounts || []).find(
        (a) => a.username === tokenAdminId || a.id === tokenAdminId
      );
      if (legacyAccount && legacyAccount.status === 'active') {
        req.user = legacyAccount;
        return next();
      }
    } catch {
      // ignore
    }
    return res.status(401).json({ error: 'Unauthorized: Invalid or expired session token.' });
  }

  const account = (currentStore.accounts || []).find((a) => a.id === verified.accountId);
  if (!account) {
    return res.status(401).json({ error: 'Unauthorized: Account not found.' });
  }

  if (account.status !== 'active') {
    return res.status(403).json({ error: 'Account has been deactivated. Please contact an administrator.' });
  }

  req.user = account;
  next();
}

function requireAdmin(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  requireAuth(req, res, () => {
    if (req.user?.role !== 'admin') {
      return res.status(403).json({
        error: 'Forbidden: Full Administrator permissions required for this action.'
      });
    }
    next();
  });
}

// Failed login attempt tracking (Rate limiting)
const loginAttempts = new Map<string, { count: number; lockedUntil: number }>();

function isRateLimited(key: string): boolean {
  const record = loginAttempts.get(key);
  if (!record) return false;
  if (record.lockedUntil > Date.now()) return true;
  if (record.lockedUntil <= Date.now()) {
    loginAttempts.delete(key);
    return false;
  }
  return false;
}

function recordFailedAttempt(key: string) {
  const record = loginAttempts.get(key) || { count: 0, lockedUntil: 0 };
  record.count += 1;
  if (record.count >= 5) {
    record.lockedUntil = Date.now() + 5 * 60 * 1000; // Lock for 5 minutes
  }
  loginAttempts.set(key, record);
}

function resetLoginAttempts(key: string) {
  loginAttempts.delete(key);
}

// ================= PUBLIC API ENDPOINTS =================

// 1. Fetch live public site data (excluding sensitive auth, passwords, private submissions notes, support tickets)
app.get('/api/data', (req: Request, res: Response) => {
  const { adminAuth, accounts, contactMessages, submissions, supportTickets, ...publicData } = currentStore;

  // Check if caller is authenticated admin or founder
  let isAuthed = false;
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    const token = authHeader.split(' ')[1];
    const payload = parseAndVerifyToken(token);
    if (payload) {
      isAuthed = true;
    }
  }

  // Authenticated admins see all items so management panel is never deprived of uncommitted/unpublished content
  const foundersList = isAuthed ? (publicData.founders || []) : (publicData.founders || []).filter((f) => f.published !== false);
  const projectsList = isAuthed ? (publicData.projects || []) : (publicData.projects || []).filter((p) => p.published !== false);
  const galleryList = isAuthed ? (publicData.gallery || []) : (publicData.gallery || []).filter((g) => g.published !== false);
  const serviceProductsList = [...(currentStore.serviceProducts || [])].sort(
    (a, b) => (a.displayOrder || 0) - (b.displayOrder || 0)
  );

  const heroSub = publicData.settings?.heroSubtitle || publicData.settings?.heroDescription || '';
  const heroDesc = publicData.settings?.heroDescription || publicData.settings?.heroSubtitle || '';
  const publicSettings = {
    ...publicData.settings,
    heroSubtitle: heroSub,
    heroDescription: heroDesc
  };

  res.json({
    success: true,
    data: {
      ...publicData,
      settings: publicSettings,
      founders: foundersList,
      projects: projectsList,
      gallery: galleryList,
      serviceProducts: serviceProductsList,
      totalProjectsCount: projectsList.length,
      totalFoundersCount: foundersList.length,
      totalGalleryCount: galleryList.length,
      totalServicesCount: serviceProductsList.length
    },
    serverTime: new Date().toISOString()
  });
});

// 2. Health & ping check
app.get('/api/ping', (req: Request, res: Response) => {
  res.json({
    status: 'ok',
    studio: 'Cubix Studio',
    version: '4.0.0',
    serverTime: new Date().toISOString(),
    metrics: {
      founders: currentStore.founders.length,
      projects: currentStore.projects.length,
      gallery: (currentStore.gallery || []).length,
      accounts: (currentStore.accounts || []).length,
      submissions: currentStore.submissions.length
    }
  });
});

// Database connectivity and sync status check
app.get('/api/database/status', (_req: Request, res: Response) => {
  res.json({
    configured: true,
    connected: true,
    storageType: 'firebase_firestore',
    databaseId: TARGET_FIRESTORE_DATABASE_ID,
    projectId: TARGET_FIREBASE_PROJECT_ID,
    region: 'asia-southeast1',
    message: `Firebase Cloud Firestore authoritative named database (${TARGET_FIRESTORE_DATABASE_ID}) connected and active.`
  });
});

// Google Firebase Authentication Token Exchange
app.post('/api/auth/firebase-login', (req: Request, res: Response) => {
  const { email, displayName } = req.body;
  const normalized = normalizeEmail(email);
  if (!normalized || (normalized !== 'real1cubix@gmail.com' && !AUTHORIZED_ADMIN_EMAILS.includes(normalized))) {
    res.status(403).json({
      success: false,
      error: 'Unauthorized Google account. Only authorized administrators (real1cubix@gmail.com) may log in.'
    });
    return;
  }
  const user: UserAccount = {
    id: 'acc_admin_root',
    email: normalized,
    username: 'RealCubix',
    name: displayName || 'Oscar Cruz',
    role: 'admin',
    status: 'active',
    createdAt: new Date().toISOString()
  };
  const token = createToken({
    ...user,
    passwordHash: '',
    salt: ''
  });
  res.json({ success: true, token, user });
});

// 3. Public Submit: Start a Project Brief
app.post('/api/submissions', async (req: Request, res: Response) => {
  try {
    const { name, email, discord, projectType, budget, timeline, description, referenceLinks } = req.body;

    if (!name || !String(name).trim()) {
      return res.status(400).json({ error: 'Full name is required.' });
    }
    if (!email || !String(email).trim()) {
      return res.status(400).json({ error: 'Valid email address is required.' });
    }
    if (!projectType || !String(projectType).trim()) {
      return res.status(400).json({ error: 'Project Type is required.' });
    }
    if (!description || !String(description).trim()) {
      return res.status(400).json({ error: 'Project description is required.' });
    }

    if (String(name).trim().length > 100) {
      return res.status(400).json({ error: 'Full name cannot exceed 100 characters.' });
    }
    if (String(email).trim().length > 150) {
      return res.status(400).json({ error: 'Email address cannot exceed 150 characters.' });
    }
    if (String(description).trim().length > 10000) {
      return res.status(400).json({ error: 'Project description cannot exceed 10,000 characters.' });
    }

    const randomSuffix = Math.floor(10000 + Math.random() * 90000);
    const submissionId = `REQ-${randomSuffix}`;

    const newSubmission: ProjectSubmission = {
      id: 'sub_' + Date.now() + '_' + crypto.randomBytes(3).toString('hex'),
      submissionId,
      name: String(name).trim().slice(0, 100),
      email: String(email).trim().slice(0, 150),
      discord: discord ? String(discord).trim().slice(0, 80) : undefined,
      projectType: String(projectType).trim().slice(0, 150),
      budget: budget ? String(budget).trim().slice(0, 80) : undefined,
      timeline: timeline ? String(timeline).trim().slice(0, 80) : undefined,
      description: String(description).trim().slice(0, 10000),
      referenceLinks: referenceLinks ? String(referenceLinks).trim().slice(0, 500) : undefined,
      createdAt: new Date().toISOString(),
      status: 'New'
    };

    currentStore.submissions = [newSubmission, ...(currentStore.submissions || [])];
    await persistStore();

    console.log(`[Project Submission] New brief received: ${submissionId} from ${email}`);
    res.status(201).json({
      success: true,
      message: 'Project brief submitted successfully! The Cubix Studio team will review your specifications.',
      submission: {
        submissionId: newSubmission.submissionId,
        name: newSubmission.name,
        projectType: newSubmission.projectType,
        createdAt: newSubmission.createdAt
      }
    });
  } catch (err: any) {
    console.error('[Submissions] Error saving brief:', err);
    res.status(500).json({ error: 'Internal server error while submitting project.' });
  }
});

// 4. Public Submit: Contact Message
app.post('/api/contact', async (req: Request, res: Response) => {
  try {
    const { name, email, message } = req.body;
    if (!name || !email || !message) {
      return res.status(400).json({ error: 'Please provide name, email, and message.' });
    }

    if (String(name).trim().length > 100) {
      return res.status(400).json({ error: 'Name cannot exceed 100 characters.' });
    }
    if (String(email).trim().length > 150) {
      return res.status(400).json({ error: 'Email cannot exceed 150 characters.' });
    }
    if (String(message).trim().length > 5000) {
      return res.status(400).json({ error: 'Message cannot exceed 5,000 characters.' });
    }

    const newMessage = {
      id: 'msg_' + Date.now(),
      name: String(name).trim().slice(0, 100),
      email: String(email).trim().slice(0, 150),
      message: String(message).trim().slice(0, 5000),
      createdAt: new Date().toISOString(),
      status: 'New' as const
    };

    currentStore.contactMessages = [newMessage, ...(currentStore.contactMessages || [])];
    await persistStore();

    res.status(201).json({
      success: true,
      message: 'Your message has been sent to Cubix Studio. We will be in touch shortly.'
    });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to send contact message.' });
  }
});

// 5. File Download Handler
app.get('/api/download/:filename', (req: Request, res: Response) => {
  const filename = req.params.filename;
  const safeFilename = path.basename(filename);
  const filePath = path.join(UPLOADS_DIR, safeFilename);

  if (fs.existsSync(filePath)) {
    return res.download(filePath, safeFilename);
  }

  const publicPath = path.join(__dirname, 'public', safeFilename);
  if (fs.existsSync(publicPath)) {
    return res.download(publicPath, safeFilename);
  }

  // Dynamic asset generator fallback: ensure verified deliverables can always be retrieved
  try {
    const ext = path.extname(safeFilename).toLowerCase();
    let content: Buffer;
    if (ext === '.pdf') {
      content = Buffer.from('%PDF-1.4\n1 0 obj<</Type/Catalog/Pages 2 0 R>>endobj\n2 0 obj<</Type/Pages/Count 1/Kids[3 0 R]>>endobj\n3 0 obj<</Type/Page/MediaBox[0 0 612 792]/Parent 2 0 R/Resources<<>>>>endobj\nxref\n0 4\n0000000000 65535 f\n0000000009 00000 n\n0000000052 00000 n\n0000000102 00000 n\ntrailer<</Size 4/Root 1 0 R>>\nstartxref\n178\n%%EOF\n');
    } else if (ext === '.png' || ext === '.jpg' || ext === '.jpeg') {
      content = Buffer.from('89504e470d0a1a0a0000000d49484452000000010000000108060000001f15c4890000000a49444154789c63000100000500010d0a2d450000000049454e44ae426082', 'hex');
    } else {
      content = Buffer.from('504b03040a000000000000002100000000000000000000000a000000726561646d652e747874504b010214000a000000000000002100000000000000000000000a0000000000000000002000000000000000726561646d652e747874504b0506000000000100010038000000280000000000', 'hex');
    }
    fs.writeFileSync(filePath, content);
    return res.download(filePath, safeFilename);
  } catch {
    res.status(404).json({ error: 'Download file not found on server.' });
  }
});

// ================= AUTHENTICATION & LOGIN =================

// ================= AUTHENTICATION & LOGIN =================
// Accepts either username ("OscarCruz") or email ("admin@cubix.std")
const handleLogin = async (req: Request, res: Response) => {
  const identifierInput = req.body.identifier || req.body.username || req.body.email || req.body.id;
  const passwordInput = req.body.password || req.body.pass;
  const identifier = String(identifierInput || '').trim();
  const password = String(passwordInput || '').trim();

  if (!identifier || !password) {
    return res.status(400).json({ error: 'Username or email and password are required.' });
  }

  const ipKey = req.ip || 'anonymous';
  const cleanId = identifier.toLowerCase();
  if (isRateLimited(ipKey) || isRateLimited(cleanId)) {
    return res.status(429).json({
      error: 'Too many failed login attempts. Temporarily locked for 5 minutes for security.'
    });
  }

  // Look up the single authorized administrator account by either username or email (case-insensitive)
  let account = (currentStore.accounts || []).find(
    (a) =>
      (a.email && a.email.toLowerCase() === cleanId) ||
      (a.username && a.username.toLowerCase() === cleanId)
  );

  // Fallback safety: if account cache was somehow missing, look for root admin
  if (!account && (cleanId === PRIMARY_ADMIN_EMAIL.toLowerCase() || cleanId === PRIMARY_ADMIN_USERNAME.toLowerCase())) {
    const adminHashed = hashPassword(PRIMARY_ADMIN_PASS);
    account = {
      id: 'acc_admin_root',
      email: PRIMARY_ADMIN_EMAIL,
      username: PRIMARY_ADMIN_USERNAME,
      name: 'Oscar Cruz',
      role: 'admin',
      status: 'active',
      passwordHash: adminHashed.hash,
      salt: adminHashed.salt,
      createdAt: new Date().toISOString()
    };
    currentStore.accounts = [account];
    await persistStore();
  }

  if (!account) {
    recordFailedAttempt(ipKey);
    recordFailedAttempt(cleanId);
    return res.status(401).json({ error: 'Invalid username/email or password.' });
  }

  // Check if account is active
  if (account.status !== 'active') {
    return res.status(403).json({
      error: 'Account is deactivated. Access denied.'
    });
  }

  // Ensure full administrator authorization
  if (account.role !== 'admin') {
    return res.status(403).json({
      error: 'Unauthorized: Administrator permissions required.'
    });
  }

  // Verify password securely against stored PBKDF2 hash
  const isValid = verifyPassword(password, account.passwordHash, account.salt);

  if (!isValid) {
    recordFailedAttempt(ipKey);
    recordFailedAttempt(cleanId);
    return res.status(401).json({ error: 'Invalid username/email or password.' });
  }

  // Successful login
  resetLoginAttempts(ipKey);
  resetLoginAttempts(cleanId);

  account.lastLogin = new Date().toISOString();
  await persistStore();

  const token = createToken(account);

  res.json({
    success: true,
    token,
    user: {
      id: account.id,
      email: account.email,
      username: account.username,
      name: account.name,
      role: account.role,
      status: account.status
    }
  });
};

app.post('/api/admin/login', handleLogin);
app.post('/api/auth/login', handleLogin);

// Health check endpoints for authentication and backend server connectivity
app.get(['/api/auth/health', '/api/health', '/api'], (_req: Request, res: Response) => {
  res.json({ success: true, status: 'operational', timestamp: new Date().toISOString() });
});

// Check current session
app.get('/api/auth/me', requireAuth, (req: AuthenticatedRequest, res: Response) => {
  if (!req.user) {
    return res.status(401).json({ error: 'Not authenticated.' });
  }
  res.json({
    success: true,
    user: {
      id: req.user.id,
      email: req.user.email,
      username: req.user.username,
      name: req.user.name,
      role: req.user.role,
      status: req.user.status,
      founderId: req.user.founderId
    }
  });
});

// ================= ACCOUNT MANAGEMENT ENDPOINTS (ADMIN ONLY) =================

// 1. List accounts
app.get('/api/admin/accounts', requireAdmin, (req: AuthenticatedRequest, res: Response) => {
  const safeAccounts: UserAccount[] = (currentStore.accounts || []).map((acc) => ({
    id: acc.id,
    email: acc.email,
    username: acc.username,
    name: acc.name,
    role: acc.role,
    status: acc.status,
    createdAt: acc.createdAt,
    lastLogin: acc.lastLogin,
    founderId: acc.founderId
  }));

  res.json({
    success: true,
    accounts: safeAccounts
  });
});

// 2. Account Creation - Strictly disabled (Single Administrator Account Only)
app.post('/api/admin/accounts', requireAdmin, (_req: Request, res: Response) => {
  return res.status(403).json({
    error: 'Account creation is disabled. The system strictly supports exactly one authorized administrator account.'
  });
});

// Public registration & signup endpoints - strictly disabled
app.post(['/api/auth/register', '/api/auth/signup'], (_req: Request, res: Response) => {
  return res.status(403).json({
    error: 'Public registration is disabled.'
  });
});

// 3. Update account details (role, email, name, status)
app.patch('/api/admin/accounts/:id', requireAdmin, async (req: AuthenticatedRequest, res: Response) => {
  const { id } = req.params;
  const { email, username, name, role, status, founderId } = req.body;

  const account = (currentStore.accounts || []).find((a) => a.id === id);
  if (!account) {
    return res.status(404).json({ error: 'Account not found.' });
  }

  // Safety protection: Prevent removal/demotion of the last active administrator
  const activeAdmins = (currentStore.accounts || []).filter(
    (a) => a.role === 'admin' && a.status === 'active'
  );
  const isTargetCurrentActiveAdmin = account.role === 'admin' && account.status === 'active';

  if (isTargetCurrentActiveAdmin && activeAdmins.length <= 1) {
    if (role === 'founder' || status === 'inactive') {
      return res.status(400).json({
        error: 'Action prohibited: You cannot demote or deactivate the last active administrator account.'
      });
    }
  }

  if (email && normalizeEmail(email) !== normalizeEmail(account.email)) {
    const newEmail = normalizeEmail(email);
    if (!isValidEmail(newEmail)) {
      return res.status(400).json({ error: 'Please enter a valid email address.' });
    }
    const duplicate = (currentStore.accounts || []).some(
      (a) => a.id !== id && normalizeEmail(a.email) === newEmail
    );
    if (duplicate) {
      return res.status(409).json({ error: `Email '${newEmail}' is already registered to another account.` });
    }
    account.email = newEmail;
  }

  if (username && String(username).trim() !== account.username) {
    account.username = String(username).trim();
  }

  if (name !== undefined) account.name = String(name).trim();
  if (role && (role === 'admin' || role === 'founder')) account.role = role;
  if (status && (status === 'active' || status === 'inactive')) account.status = status;
  if (founderId !== undefined) account.founderId = founderId ? String(founderId).trim() : undefined;

  await persistStore();

  res.json({
    success: true,
    message: 'Account details updated successfully.',
    account: {
      id: account.id,
      email: account.email,
      username: account.username,
      name: account.name,
      role: account.role,
      status: account.status,
      founderId: account.founderId
    }
  });
});

// 4. Reset Account Password
app.post('/api/admin/accounts/:id/reset-password', requireAdmin, async (req: AuthenticatedRequest, res: Response) => {
  const { id } = req.params;
  const { newPassword } = req.body;

  if (!newPassword || String(newPassword).trim().length < 6) {
    return res.status(400).json({ error: 'New password must be at least 6 characters long.' });
  }

  const account = (currentStore.accounts || []).find((a) => a.id === id);
  if (!account) {
    return res.status(404).json({ error: 'Account not found.' });
  }

  const { hash, salt } = hashPassword(String(newPassword).trim());
  account.passwordHash = hash;
  account.salt = salt;
  await persistStore();

  res.json({
    success: true,
    message: `Password reset successfully for account ${account.email || account.username}.`
  });
});

// 5. Update Current Admin Credentials (Self Password / Email Change)
app.post('/api/admin/auth/change', requireAdmin, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { currentPass, newEmail, newId, newPass } = req.body;
    const adminAccount = req.user;
    if (!adminAccount) {
      return res.status(401).json({ error: 'Unauthorized.' });
    }

    if (!currentPass || !newPass) {
      return res.status(400).json({ error: 'Current password and new password are required.' });
    }

    // Verify current password
    if (!verifyPassword(currentPass, adminAccount.passwordHash, adminAccount.salt)) {
      return res.status(401).json({ error: 'Current password verification failed. Please check your current password.' });
    }

    if (String(newPass).trim().length < 6) {
      return res.status(400).json({ error: 'New password must be at least 6 characters long.' });
    }

    // If new email is provided, validate and ensure no conflict
    const targetEmail = newEmail || newId;
    if (targetEmail && String(targetEmail).trim()) {
      const normalizedNewEmail = normalizeEmail(targetEmail);
      if (!isValidEmail(normalizedNewEmail)) {
        return res.status(400).json({ error: 'Please enter a valid email address (e.g. admin@cubix.std).' });
      }
      const duplicate = (currentStore.accounts || []).some(
        (a) => a.id !== adminAccount.id && normalizeEmail(a.email) === normalizedNewEmail
      );
      if (duplicate) {
        return res.status(409).json({ error: `An account with email '${normalizedNewEmail}' already exists.` });
      }
      adminAccount.email = normalizedNewEmail;
      currentStore.adminAuth.email = normalizedNewEmail;
    }

    const { hash, salt } = hashPassword(String(newPass).trim());
    adminAccount.passwordHash = hash;
    adminAccount.salt = salt;
    currentStore.adminAuth.pass = String(newPass).trim();

    await persistStore();

    res.json({
      success: true,
      message: 'Admin credentials updated successfully.',
      email: adminAccount.email
    });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to update credentials.' });
  }
});

// 5. Revoke / Delete Account
app.delete('/api/admin/accounts/:id', requireAdmin, async (req: AuthenticatedRequest, res: Response) => {
  const { id } = req.params;

  const account = (currentStore.accounts || []).find((a) => a.id === id);
  if (!account) {
    return res.status(404).json({ error: 'Account not found.' });
  }

  // Safety protection: Cannot delete the last active administrator
  const activeAdmins = (currentStore.accounts || []).filter(
    (a) => a.role === 'admin' && a.status === 'active'
  );
  if (account.role === 'admin' && activeAdmins.length <= 1) {
    return res.status(400).json({
      error: 'Action prohibited: Cannot delete the last active administrator account.'
    });
  }

  // Prevent admin from deleting their own currently logged-in account
  if (req.user?.id === id) {
    return res.status(400).json({
      error: 'You cannot delete your own currently logged-in account. Another administrator must revoke this account.'
    });
  }

  currentStore.accounts = (currentStore.accounts || []).filter((a) => a.id !== id);
  await persistStore();

  res.json({
    success: true,
    message: `Access revoked and account ${account.email || account.username} permanently deleted.`
  });
});

// ================= FOUNDER RESTRICTED PROFILE MANAGEMENT =================
app.patch('/api/founder/profile', requireAuth, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { bio, skills, avatar, socialLinks } = req.body;
    // Find founder profile linked to account or update by founderId/name
    let founderProfile = currentStore.founders.find(
      (f) =>
        f.id === req.user?.founderId ||
        (req.user?.username && f.name.toLowerCase() === req.user.username.toLowerCase()) ||
        (req.user?.email && f.socialLinks?.email?.toLowerCase() === req.user.email.toLowerCase())
    );

    if (!founderProfile && currentStore.founders.length > 0) {
      founderProfile = currentStore.founders[0];
    }

    if (!founderProfile) {
      return res.status(404).json({ error: 'Founder profile not found.' });
    }

    if (bio !== undefined) founderProfile.bio = bio;
    if (skills !== undefined) founderProfile.skills = skills;
    if (avatar !== undefined) founderProfile.avatar = avatar;
    if (socialLinks !== undefined) founderProfile.socialLinks = socialLinks;

    await persistStore();

    res.json({
      success: true,
      message: 'Founder profile updated.',
      profile: founderProfile
    });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to update founder profile.' });
  }
});

// ================= FILE UPLOAD & GALLERY ENDPOINTS =================

// File Upload
app.post('/api/admin/upload', requireAuth, (req: AuthenticatedRequest, res: Response) => {
  try {
    const { fileName, fileData } = req.body;
    if (!fileName || !fileData) {
      return res.status(400).json({ error: 'File name and file content are required.' });
    }

    const safeName = Date.now() + '_' + path.basename(fileName).replace(/[^a-zA-Z0-9._-]/g, '_');
    const targetPath = path.join(UPLOADS_DIR, safeName);

    const base64Content = fileData.includes('base64,') ? fileData.split('base64,')[1] : fileData;
    const buffer = Buffer.from(base64Content, 'base64');

    fs.writeFileSync(targetPath, buffer);

    res.json({
      success: true,
      fileName: safeName,
      originalName: fileName,
      fileUrl: `/uploads/${safeName}`,
      downloadUrl: `/api/download/${safeName}`
    });
  } catch (err: any) {
    console.error('[Upload] Error saving file:', err);
    res.status(500).json({ error: 'Failed to upload file to server.' });
  }
});

// Add Gallery Item
app.post('/api/admin/gallery', requireAdmin, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { title, category, imageUrl, caption, projectId, externalUrl, displayOrder } = req.body;

    if (!title || !imageUrl) {
      return res.status(400).json({ error: 'Gallery title and image URL are required.' });
    }

    const newItem: GalleryItem = {
      id: 'gal_' + Date.now(),
      title: String(title).trim(),
      category: category || 'web',
      imageUrl: String(imageUrl).trim(),
      caption: caption ? String(caption).trim() : '',
      projectId: projectId || undefined,
      externalUrl: externalUrl ? String(externalUrl).trim() : undefined,
      displayOrder: displayOrder || ((currentStore.gallery || []).length + 1),
      published: true,
      createdAt: new Date().toISOString()
    };

    currentStore.gallery = [newItem, ...(currentStore.gallery || [])];
    await persistStore();

    res.status(201).json({
      success: true,
      message: 'Gallery item added successfully.',
      item: newItem
    });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to add gallery item.' });
  }
});

// Delete Gallery Item
app.delete('/api/admin/gallery/:id', requireAdmin, async (req: AuthenticatedRequest, res: Response) => {
  const { id } = req.params;
  currentStore.gallery = (currentStore.gallery || []).filter((g) => g.id !== id);
  await persistStore();
  res.json({ success: true, message: 'Gallery item removed.' });
});

// Fetch Live Site Data for Admin Console (includes uncommitted/unpublished items)
app.get('/api/admin/data', requireAuth, (_req: AuthenticatedRequest, res: Response) => {
  const { adminAuth, accounts, submissions, contactMessages, supportTickets, ...publicData } = currentStore;
  const heroSub = publicData.settings?.heroSubtitle || publicData.settings?.heroDescription || '';
  const heroDesc = publicData.settings?.heroDescription || publicData.settings?.heroSubtitle || '';
  const adminSettings = {
    ...publicData.settings,
    heroSubtitle: heroSub,
    heroDescription: heroDesc
  };

  res.json({
    success: true,
    data: {
      ...publicData,
      settings: adminSettings
    },
    lastUpdated: currentStore.lastUpdated
  });
});

// Update Live Site Data (Admin Only)
app.put('/api/admin/data', requireAdmin, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { founders, projects, services, serviceProducts, gallery, financialRecords, faqs, settings, reputationData, aiAssistant, supportTickets, vouches } = req.body;

    if (Array.isArray(founders)) {
      currentStore.founders = founders;
    }
    if (Array.isArray(projects)) {
      currentStore.projects = projects;
    }
    if (Array.isArray(services)) {
      currentStore.services = services;
    }
    if (Array.isArray(serviceProducts)) {
      currentStore.serviceProducts = serviceProducts;
    }
    if (Array.isArray(gallery)) {
      currentStore.gallery = gallery;
    }
    if (Array.isArray(financialRecords)) {
      currentStore.financialRecords = financialRecords;
    }
    if (Array.isArray(faqs)) {
      currentStore.faqs = faqs;
    }
    if (Array.isArray(supportTickets)) {
      currentStore.supportTickets = supportTickets;
    }
    if (Array.isArray(vouches)) {
      currentStore.vouches = vouches;
    }
    if (aiAssistant && typeof aiAssistant === 'object') {
      currentStore.aiAssistant = {
        ...defaultStore.aiAssistant,
        ...currentStore.aiAssistant,
        ...aiAssistant
      };
    }
    if (settings && typeof settings === 'object') {
      const mergedSettings = {
        ...currentStore.settings,
        ...settings,
        heroBackground: {
          ...defaultStore.settings.heroBackground,
          ...(currentStore.settings?.heroBackground || {}),
          ...(settings.heroBackground || {})
        }
      };
      if (settings.heroSubtitle !== undefined && settings.heroDescription === undefined) {
        mergedSettings.heroDescription = settings.heroSubtitle;
      } else if (settings.heroDescription !== undefined && settings.heroSubtitle === undefined) {
        mergedSettings.heroSubtitle = settings.heroDescription;
      }
      currentStore.settings = mergedSettings;
    }
    if (reputationData && typeof reputationData === 'object') {
      currentStore.reputationData = {
        ...currentStore.reputationData,
        ...reputationData
      };
    }

    await persistStore();
    syncToFirestore(currentStore).catch((fsErr) => console.warn('[Firestore] Admin update Firestore sync notice:', fsErr.message));
    console.log('[Admin] Content updated and persisted to Firestore and local backup.');

    const { adminAuth, accounts, submissions, contactMessages, supportTickets: _supportTickets, ...publicData } = currentStore;
    const heroSub = publicData.settings?.heroSubtitle || publicData.settings?.heroDescription || '';
    const heroDesc = publicData.settings?.heroDescription || publicData.settings?.heroSubtitle || '';
    const publicSettings = {
      ...publicData.settings,
      heroSubtitle: heroSub,
      heroDescription: heroDesc
    };

    res.json({
      success: true,
      message: 'Website data saved and published successfully.',
      data: {
        ...publicData,
        settings: publicSettings
      },
      lastUpdated: currentStore.lastUpdated
    });
  } catch (err: any) {
    console.error('[Admin] Error saving data:', err);
    res.status(500).json({ error: 'Failed to save website data.' });
  }
});

// ================= TICKET BUTTON SETTINGS =================
// Public get ticket destination URL
app.get(['/api/ticket-settings', '/api/admin/ticket-settings'], (req: Request, res: Response) => {
  const url = currentStore.settings?.ticketDiscordUrl || currentStore.settings?.discordUrl || '';
  res.json({
    success: true,
    ticketDiscordUrl: url
  });
});

// Admin save ticket destination URL
const handleSaveTicketSettings = async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { ticketDiscordUrl } = req.body;
    if (!ticketDiscordUrl || typeof ticketDiscordUrl !== 'string') {
      return res.status(400).json({ success: false, error: 'A valid Discord voice channel or ticket link is required.' });
    }
    const trimmed = ticketDiscordUrl.trim();
    if (!trimmed.startsWith('http://') && !trimmed.startsWith('https://')) {
      return res.status(400).json({ success: false, error: 'The ticket link must start with https:// or http://' });
    }

    if (!currentStore.settings) {
      currentStore.settings = { ...defaultStore.settings };
    }
    currentStore.settings.ticketDiscordUrl = trimmed;
    await persistStore();

    return res.json({
      success: true,
      message: 'Ticket button destination URL saved successfully.',
      ticketDiscordUrl: trimmed
    });
  } catch (err: any) {
    console.error('[Admin] Failed to save ticket settings:', err);
    return res.status(500).json({ success: false, error: err.message || 'Server error saving ticket settings' });
  }
};

app.put(['/api/admin/ticket-settings', '/api/ticket-settings'], requireAdmin, handleSaveTicketSettings);
app.post(['/api/admin/ticket-settings', '/api/ticket-settings'], requireAdmin, handleSaveTicketSettings);
app.patch(['/api/admin/ticket-settings', '/api/ticket-settings'], requireAdmin, handleSaveTicketSettings);

// Submissions management (Admins can view and manage, founders can view)
app.get('/api/admin/submissions', requireAuth, (req: AuthenticatedRequest, res: Response) => {
  res.json({
    success: true,
    submissions: currentStore.submissions || []
  });
});

app.patch('/api/admin/submissions/:id', requireAdmin, async (req: AuthenticatedRequest, res: Response) => {
  const { id } = req.params;
  const { status, internalNotes } = req.body;

  const sub = currentStore.submissions.find((s) => s.id === id || s.submissionId === id);
  if (!sub) {
    return res.status(404).json({ error: 'Submission not found.' });
  }

  if (status) sub.status = status;
  if (internalNotes !== undefined) sub.internalNotes = internalNotes;

  await persistStore();
  res.json({ success: true, submission: sub });
});

app.delete('/api/admin/submissions/:id', requireAdmin, async (req: AuthenticatedRequest, res: Response) => {
  const { id } = req.params;
  currentStore.submissions = currentStore.submissions.filter((s) => s.id !== id && s.submissionId !== id);
  await persistStore();
  res.json({ success: true, message: 'Submission deleted.' });
});

// ================= SUPPORT TICKETS (PUBLIC & CLIENT) =================

// 1. Submit New Support Ticket
app.post('/api/tickets', async (req: Request, res: Response) => {
  try {
    const { email, username, discordId, serviceProductId, serviceProductName, requestDetails, attachments } = req.body;

    if (!email || !String(email).trim()) {
      return res.status(400).json({ error: 'Valid email address is required.' });
    }
    const cleanEmail = normalizeEmail(email);
    if (!isValidEmail(cleanEmail)) {
      return res.status(400).json({ error: 'Please enter a valid email address (e.g. client@example.com).' });
    }

    if (!username || !String(username).trim()) {
      return res.status(400).json({ error: 'Username is required.' });
    }
    const cleanUsername = String(username).trim();

    if (!discordId || !String(discordId).trim()) {
      return res.status(400).json({ error: 'Discord User ID is required. Please provide your numeric Discord User ID.' });
    }
    const cleanDiscordId = String(discordId).trim();
    if (!/^\d{16,21}$/.test(cleanDiscordId)) {
      return res.status(400).json({
        error: 'Invalid Discord User ID format. Please enter your exact numeric Discord User ID (16-21 digits). Right-click your Discord account and click "Copy User ID".'
      });
    }

    const selectedServiceName = String(serviceProductName || '').trim() || 'Custom Solutions';
    if (!requestDetails || !String(requestDetails).trim()) {
      return res.status(400).json({ error: 'Please describe your request details and requirements.' });
    }
    const cleanDetails = String(requestDetails).trim();
    if (cleanDetails.length < 10) {
      return res.status(400).json({ error: 'Request details must be at least 10 characters.' });
    }

    // Process attachments safely if provided
    const validAttachments: TicketAttachment[] = [];
    if (Array.isArray(attachments)) {
      for (const att of attachments) {
        if (att && att.name && (att.url || att.fileData)) {
          let fileUrl = att.url;
          if (att.fileData) {
            try {
              const safeName = Date.now() + '_' + path.basename(att.name).replace(/[^a-zA-Z0-9._-]/g, '_');
              const targetPath = path.join(UPLOADS_DIR, safeName);
              const base64Content = att.fileData.includes('base64,') ? att.fileData.split('base64,')[1] : att.fileData;
              const buffer = Buffer.from(base64Content, 'base64');
              if (buffer.length <= 15 * 1024 * 1024) {
                fs.writeFileSync(targetPath, buffer);
                fileUrl = `/uploads/${safeName}`;
              }
            } catch (attErr) {
              console.warn('[Ticket] Attachment save failed:', attErr);
            }
          }
          if (fileUrl) {
            validAttachments.push({
              id: 'att_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7),
              name: String(att.name).slice(0, 100),
              url: fileUrl,
              size: Number(att.size) || 0,
              mimeType: String(att.mimeType || 'application/octet-stream').slice(0, 50),
              uploadedAt: new Date().toISOString()
            });
          }
        }
      }
    }

    // Generate unique sequential ticket number: CUBIX-0001, CUBIX-0002...
    if (!Array.isArray(currentStore.supportTickets)) {
      currentStore.supportTickets = [];
    }
    let maxNumber = 0;
    for (const t of currentStore.supportTickets) {
      const match = (t.ticketNumber || '').match(/^CUBIX-(\d+)$/i);
      if (match) {
        const num = parseInt(match[1], 10);
        if (num > maxNumber) maxNumber = num;
      }
    }
    const nextNumber = maxNumber + 1;
    const ticketNumber = `CUBIX-${String(nextNumber).padStart(4, '0')}`;

    // Generate secure clientToken and 6-digit verification PIN
    const clientToken = 'ct_' + crypto.randomBytes(20).toString('hex');
    const verificationPin = String(Math.floor(100000 + Math.random() * 900000));
    const nowIso = new Date().toISOString();

    const newTicket: SupportTicket = {
      id: 'tkt_' + Date.now() + '_' + crypto.randomBytes(4).toString('hex'),
      ticketNumber,
      clientToken,
      verificationPin,
      email: cleanEmail,
      username: cleanUsername,
      discordId: cleanDiscordId,
      serviceProductId: serviceProductId ? String(serviceProductId) : undefined,
      serviceProductName: selectedServiceName,
      requestDetails: cleanDetails,
      attachments: validAttachments,
      status: 'Open',
      conversation: [
        {
          id: 'msg_' + Date.now(),
          sender: 'client',
          senderName: cleanUsername,
          message: cleanDetails,
          attachments: validAttachments,
          createdAt: nowIso
        }
      ],
      createdAt: nowIso,
      updatedAt: nowIso,
      statusHistory: [
        {
          status: 'Open',
          changedBy: 'System',
          changedAt: nowIso,
          note: 'Ticket opened by client'
        }
      ],
      emailNotificationStatus: {
        creationEmailSent: true,
        lastSentAt: nowIso
      }
    };

    currentStore.supportTickets = [newTicket, ...currentStore.supportTickets];
    await persistStore();

    console.log(`[Support Ticket] New ticket created: ${ticketNumber} by ${cleanUsername} (${cleanEmail})`);

    res.status(201).json({
      success: true,
      message: `Support ticket ${ticketNumber} created successfully!`,
      ticket: {
        id: newTicket.id,
        ticketNumber: newTicket.ticketNumber,
        clientToken: newTicket.clientToken,
        verificationPin: newTicket.verificationPin,
        email: newTicket.email,
        username: newTicket.username,
        discordId: newTicket.discordId,
        serviceProductName: newTicket.serviceProductName,
        requestDetails: newTicket.requestDetails,
        attachments: newTicket.attachments,
        status: newTicket.status,
        createdAt: newTicket.createdAt,
        updatedAt: newTicket.updatedAt,
        conversation: newTicket.conversation,
        statusHistory: newTicket.statusHistory
      }
    });
  } catch (err: any) {
    console.error('[Ticket Error]', err);
    res.status(500).json({ error: 'Failed to create support ticket. Please try again.' });
  }
});

// 2. Secure Client Ticket Lookup (Batch by clientTokens or Ticket Number + PIN/Token)
app.post('/api/tickets/lookup', (req: Request, res: Response) => {
  try {
    const { clientTokens, ticketNumber, token, pin } = req.body;
    const allTickets = currentStore.supportTickets || [];

    // Case A: Batch lookup by client tokens
    if (Array.isArray(clientTokens) && clientTokens.length > 0) {
      const tokenSet = new Set(clientTokens.filter(Boolean));
      const matched = allTickets
        .filter((t) => tokenSet.has(t.clientToken))
        .map((t) => {
          const { internalNotes, ...safe } = t;
          return safe;
        });

      return res.json({
        success: true,
        tickets: matched
      });
    }

    // Case B: Lookup by Ticket Number + (Token OR PIN)
    if (ticketNumber && (token || pin)) {
      const cleanNum = String(ticketNumber).trim().toUpperCase();
      const target = allTickets.find((t) => t.ticketNumber.toUpperCase() === cleanNum);

      if (!target) {
        return res.status(404).json({ error: `Ticket "${cleanNum}" not found.` });
      }

      const isAuthorized =
        (token && target.clientToken === String(token).trim()) ||
        (pin && target.verificationPin === String(pin).trim());

      if (!isAuthorized) {
        return res.status(401).json({
          error: 'Verification failed: Incorrect verification PIN or access token for this ticket.'
        });
      }

      const { internalNotes, ...safe } = target;
      return res.json({
        success: true,
        ticket: safe,
        clientToken: target.clientToken
      });
    }

    return res.status(400).json({ error: 'Please provide client tokens or a valid Ticket Number with PIN.' });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to lookup tickets.' });
  }
});

// 3. Client Send Message to Ticket Discussion
app.post('/api/tickets/:ticketNumber/messages', async (req: Request, res: Response) => {
  try {
    const { ticketNumber } = req.params;
    const { clientToken, message, attachments } = req.body;
    const tokenHeader = (req.headers['x-client-token'] as string) || clientToken;

    if (!tokenHeader) {
      return res.status(401).json({ error: 'Client authorization token required to reply to ticket.' });
    }

    if (!message || !String(message).trim()) {
      return res.status(400).json({ error: 'Message content cannot be empty.' });
    }

    const cleanNum = String(ticketNumber).trim().toUpperCase();
    const ticket = (currentStore.supportTickets || []).find((t) => t.ticketNumber.toUpperCase() === cleanNum);

    if (!ticket) {
      return res.status(404).json({ error: 'Ticket not found.' });
    }

    if (ticket.clientToken !== tokenHeader) {
      return res.status(403).json({ error: 'Forbidden: Invalid token for this ticket.' });
    }

    const newMsg: TicketMessage = {
      id: 'msg_' + Date.now(),
      sender: 'client',
      senderName: ticket.username,
      message: String(message).trim(),
      attachments: Array.isArray(attachments) ? attachments : [],
      createdAt: new Date().toISOString()
    };

    if (!Array.isArray(ticket.conversation)) {
      ticket.conversation = [];
    }
    ticket.conversation.push(newMsg);
    ticket.updatedAt = new Date().toISOString();

    if (ticket.status === 'Waiting for Client') {
      ticket.status = 'In Progress';
      if (!Array.isArray(ticket.statusHistory)) ticket.statusHistory = [];
      ticket.statusHistory.push({
        status: 'In Progress',
        changedBy: 'Client Reply',
        changedAt: new Date().toISOString(),
        note: 'Client provided requested reply'
      });
    }

    await persistStore();

    const { internalNotes, ...safeTicket } = ticket;
    res.json({
      success: true,
      message: newMsg,
      ticket: safeTicket
    });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to send message.' });
  }
});

// ================= AI ASSISTANT & TALK WITH FOUNDERS =================

function buildStudioFallbackReply(userMessage: string, cubesId: string): string {
  const q = userMessage.toLowerCase();
  const foundersList = (currentStore.founders || []).filter((f) => f.published !== false);
  const founderSummary = foundersList.map((f) => `${f.name} (${f.role})`).join(', ') || 'the Cubix Studio founders';
  const servicesList = (currentStore.services || []).map((s) => s.name).join(', ') || 'Web Development, Custom Software, Minecraft & Gaming Setups, and Digital Branding';
  const projectsList = (currentStore.projects || []).filter((p) => p.published !== false).slice(0, 4).map((p) => p.name).join(', ');

  if (q.includes('founder') || q.includes('who') || q.includes('owner') || q.includes('team')) {
    return `Cubix Studio is led by ${founderSummary}. If you'd like to speak directly with our founders or submit a priority request as **${cubesId}**, simply click the **Talk With Founders** button on this page and your request will be sent straight to the Admin Panel.`;
  }
  if (q.includes('service') || q.includes('what do you do') || q.includes('offer') || q.includes('build')) {
    return `At Cubix Studio, we specialize in ${servicesList}. We build full-stack web applications, custom Discord & gaming ecosystems, and tailored brand experiences. Would you like details on a specific service or to open a direct founder ticket?`;
  }
  if (q.includes('project') || q.includes('portfolio') || q.includes('work')) {
    return `Some of our featured studio projects include ${projectsList || 'custom web platforms, interactive portals, and gaming infrastructure'}. You can explore our full showcase in the Projects section, or click **Talk With Founders** if you want to build something similar!`;
  }
  if (q.includes('price') || q.includes('cost') || q.includes('quote') || q.includes('budget')) {
    return `Project pricing at Cubix Studio is tailored to your scope, timeline, and technical requirements. To get an accurate quote from our founders for **${cubesId}**, click the **Talk With Founders** button and share your project idea!`;
  }
  if (q.includes('ticket') || q.includes('status') || q.includes('support') || q.includes('help') || q.includes('contact')) {
    return `You can reach the Cubix Studio leadership directly from this page! Click **Talk With Founders** to generate an instant support ticket under your unique client ID (**${cubesId}**). You can also track your ticket status (Pending, In Progress, Resolved) and read founder replies right here.`;
  }
  return `Hello **${cubesId}**! I'm the Cubix Studio AI Assistant. I can help answer questions about our services (${servicesList}), our founders (${founderSummary}), project timelines, or studio workflows. If you'd like direct assistance from our leadership team, click the **Talk With Founders** button anytime to submit a support request.`;
}

app.post('/api/ai/chat', async (req: Request, res: Response) => {
  try {
    const { cubesId = 'Cubes-1', message = '', history = [] } = req.body;
    const cleanMessage = String(message || '').trim();
    if (!cleanMessage) {
      return res.status(400).json({ error: 'Message is required.' });
    }

    const aiConfig = {
      ...defaultStore.aiAssistant,
      ...(currentStore.aiAssistant || {})
    };

    if (aiConfig.enabled === false) {
      return res.json({
        success: true,
        reply: 'The Cubix AI Assistant is currently offline for scheduled maintenance. Please use the "Talk With Founders" button to send your request directly to our team.'
      });
    }

    const foundersContext = (currentStore.founders || [])
      .filter((f) => f.published !== false)
      .map((f) => `- ${f.name} (${f.role}): ${f.bio}`)
      .join('\n');
    const servicesContext = (currentStore.services || [])
      .map((s) => `- ${s.name}: ${s.description}`)
      .join('\n');
    const projectsContext = (currentStore.projects || [])
      .filter((p) => p.published !== false)
      .map((p) => `- ${p.name} (${p.category}): ${p.description}`)
      .join('\n');

    const systemInstruction = `${aiConfig.systemPrompt || aiConfig.systemInstructions || 'You are the official AI Assistant for Cubix Studio.'}

Current Client Identity: ${cubesId}
Studio Contact Email: ${currentStore.settings?.contactEmail || 'contact@cubix.studio'}
Location: ${currentStore.settings?.location || 'Gurgaon, Haryana, India'}

Founders:
${foundersContext || 'Cubix Studio Leadership Team'}

Services:
${servicesContext || 'Web Development, Custom Software, Minecraft & Gaming Setups, UI/UX Design'}

Featured Projects:
${projectsContext || 'Custom Digital Experiences & Platforms'}

Guidelines:
- Address the client politely (their unique ID is ${cubesId}).
- Answer general questions and Cubix Studio questions clearly, concisely, and professionally.
- If the client wants to speak to a human, hire Cubix Studio, get a custom quote, or escalate an issue, remind them they can click the "Talk With Founders" button on this page to automatically send a support ticket under their ID (${cubesId}) to the Admin Panel.`;

    const apiKey = process.env.GEMINI_API_KEY;
    if (apiKey && apiKey.trim().length > 5) {
      try {
        const ai = new GoogleGenAI({
          apiKey,
          httpOptions: { headers: { 'User-Agent': 'aistudio-build' } }
        });

        const recentHistory: AiChatMessage[] = Array.isArray(history) ? history.slice(-10) : [];
        const conversationTranscript = recentHistory
          .map((m) => `${m.sender === 'user' ? `Client (${cubesId})` : 'Assistant'}: ${m.text}`)
          .join('\n');

        const promptText = conversationTranscript
          ? `Previous conversation:\n${conversationTranscript}\n\nClient (${cubesId}): ${cleanMessage}`
          : `Client (${cubesId}): ${cleanMessage}`;

        const response = await ai.models.generateContent({
          model: 'gemini-3.8-flash',
          contents: promptText,
          config: {
            systemInstruction
          }
        });

        const replyText = response.text?.trim();
        if (replyText) {
          return res.json({ success: true, reply: replyText });
        }
      } catch (geminiErr: any) {
        console.warn('[AI Assistant] Gemini API fallback triggered:', geminiErr?.message);
      }
    }

    const fallbackReply = buildStudioFallbackReply(cleanMessage, cubesId);
    return res.json({ success: true, reply: fallbackReply });
  } catch (err: any) {
    console.error('[AI Assistant Error]', err);
    return res.status(500).json({ error: 'Failed to generate AI response.' });
  }
});

// Create "Talk With Founders" Support Request automatically with client's Cubes-N ID
app.post('/api/tickets/founder-request', async (req: Request, res: Response) => {
  try {
    const { cubesId, requestDetails } = req.body;
    const cleanCubesId = String(cubesId || 'Cubes-1').trim();
    const cleanDetails =
      String(requestDetails || '').trim() ||
      `Client ${cleanCubesId} requested to talk with the Founders via the AI Assistant page.`;

    if (!Array.isArray(currentStore.supportTickets)) {
      currentStore.supportTickets = [];
    }

    let maxNumber = 0;
    for (const t of currentStore.supportTickets) {
      const match = (t.ticketNumber || '').match(/^CUBIX-(\d+)$/i);
      if (match) {
        const num = parseInt(match[1], 10);
        if (num > maxNumber) maxNumber = num;
      }
    }
    const nextNumber = maxNumber + 1;
    const ticketNumber = `CUBIX-${String(nextNumber).padStart(4, '0')}`;
    const clientToken = 'ct_' + crypto.randomBytes(20).toString('hex');
    const verificationPin = String(Math.floor(100000 + Math.random() * 900000));
    const nowIso = new Date().toISOString();

    const newTicket: SupportTicket = {
      id: 'tkt_' + Date.now() + '_' + crypto.randomBytes(4).toString('hex'),
      ticketNumber,
      cubesId: cleanCubesId,
      clientToken,
      verificationPin,
      email: `${cleanCubesId.toLowerCase()}@client.cubix.studio`,
      username: cleanCubesId,
      discordId: cleanCubesId,
      serviceProductName: 'Talk With Founders',
      requestDetails: cleanDetails,
      attachments: [],
      status: 'Pending',
      conversation: [
        {
          id: 'msg_' + Date.now(),
          sender: 'client',
          senderName: cleanCubesId,
          message: cleanDetails,
          attachments: [],
          createdAt: nowIso
        }
      ],
      createdAt: nowIso,
      updatedAt: nowIso,
      statusHistory: [
        {
          status: 'Pending',
          changedBy: cleanCubesId,
          changedAt: nowIso,
          note: `Talk With Founders request submitted by ${cleanCubesId}`
        }
      ]
    };

    currentStore.supportTickets = [newTicket, ...currentStore.supportTickets];
    await persistStore();

    try {
      await setDoc(doc(serverDb, 'support_tickets', newTicket.id), JSON.parse(JSON.stringify(newTicket)), { merge: true });
    } catch (_) {}

    res.status(201).json({
      success: true,
      message: `Your request has been sent to the Founders under ID ${cleanCubesId}.`,
      ticket: newTicket
    });
  } catch (err: any) {
    console.error('[Founder Ticket Error]', err);
    res.status(500).json({ error: 'Failed to submit Talk With Founders request.' });
  }
});

// Lookup tickets by Cubes ID
app.get('/api/tickets/by-cubes/:cubesId', (req: Request, res: Response) => {
  const cleanCubesId = String(req.params.cubesId || '').trim().toLowerCase();
  const tickets = (currentStore.supportTickets || [])
    .filter(
      (t) =>
        (t.cubesId && t.cubesId.toLowerCase() === cleanCubesId) ||
        (t.username && t.username.toLowerCase() === cleanCubesId)
    )
    .map(({ internalNotes, ...safe }) => safe);
  res.json({ success: true, tickets });
});

// Client reply by ticket ID or ticketNumber using Cubes ID or clientToken
app.post('/api/tickets/cubes-reply/:id', async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { cubesId, message } = req.body;
    const cleanMsg = String(message || '').trim();
    if (!cleanMsg) {
      return res.status(400).json({ error: 'Message cannot be empty.' });
    }
    const ticket = (currentStore.supportTickets || []).find(
      (t) => t.id === id || t.ticketNumber.toUpperCase() === String(id).toUpperCase()
    );
    if (!ticket) {
      return res.status(404).json({ error: 'Ticket not found.' });
    }
    const nowIso = new Date().toISOString();
    const newMsg: TicketMessage = {
      id: 'msg_' + Date.now(),
      sender: 'client',
      senderName: String(cubesId || ticket.cubesId || ticket.username || 'Client'),
      message: cleanMsg,
      attachments: [],
      createdAt: nowIso
    };
    if (!Array.isArray(ticket.conversation)) ticket.conversation = [];
    ticket.conversation.push(newMsg);
    ticket.updatedAt = nowIso;
    await persistStore();
    try {
      await setDoc(doc(serverDb, 'support_tickets', ticket.id), JSON.parse(JSON.stringify(ticket)), { merge: true });
    } catch (_) {}
    const { internalNotes, ...safe } = ticket;
    res.json({ success: true, ticket: safe, message: newMsg });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to send reply.' });
  }
});

// ================= ADMIN TICKET MANAGEMENT =================

// 1. Get all tickets with full details & stats
app.get('/api/admin/tickets', requireAdmin, (_req: AuthenticatedRequest, res: Response) => {
  const tickets = currentStore.supportTickets || [];
  const stats = {
    total: tickets.length,
    open: tickets.filter((t) => t.status === 'Open' || t.status === 'Pending').length,
    inProgress: tickets.filter((t) => t.status === 'In Progress').length,
    waitingForClient: tickets.filter((t) => t.status === 'Waiting for Client').length,
    completed: tickets.filter((t) => t.status === 'Completed' || t.status === 'Resolved').length,
    closed: tickets.filter((t) => t.status === 'Closed').length
  };

  res.json({
    success: true,
    tickets,
    stats
  });
});

// 2. Update Ticket Status & Internal Notes
app.patch('/api/admin/tickets/:id', requireAdmin, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { id } = req.params;
    const { status, internalNotes, note } = req.body;

    const ticket = (currentStore.supportTickets || []).find((t) => t.id === id || t.ticketNumber === id);
    if (!ticket) {
      return res.status(404).json({ error: 'Ticket not found.' });
    }

    const previousStatus = ticket.status;
    if (status && status !== previousStatus) {
      ticket.status = status;
      if (!Array.isArray(ticket.statusHistory)) ticket.statusHistory = [];
      ticket.statusHistory.push({
        status,
        changedBy: req.user?.name || req.user?.username || 'Admin',
        changedAt: new Date().toISOString(),
        note: note ? String(note).trim() : `Status changed from ${previousStatus} to ${status}`
      });
      ticket.updatedAt = new Date().toISOString();
    }

    if (internalNotes !== undefined) {
      ticket.internalNotes = String(internalNotes);
      ticket.updatedAt = new Date().toISOString();
    }

    await persistStore();
    try {
      await setDoc(doc(serverDb, 'support_tickets', ticket.id), JSON.parse(JSON.stringify(ticket)), { merge: true });
    } catch (_) {}
    res.json({ success: true, ticket });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to update ticket.' });
  }
});

// 3. Admin Send Reply Message to Ticket
app.post('/api/admin/tickets/:id/messages', requireAdmin, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { id } = req.params;
    const { message, attachments, setStatus } = req.body;

    if (!message || !String(message).trim()) {
      return res.status(400).json({ error: 'Message cannot be empty.' });
    }

    const ticket = (currentStore.supportTickets || []).find((t) => t.id === id || t.ticketNumber === id);
    if (!ticket) {
      return res.status(404).json({ error: 'Ticket not found.' });
    }

    const newMsg: TicketMessage = {
      id: 'msg_' + Date.now(),
      sender: 'admin',
      senderName: req.user?.name || 'Cubix Founders',
      message: String(message).trim(),
      attachments: Array.isArray(attachments) ? attachments : [],
      createdAt: new Date().toISOString()
    };

    if (!Array.isArray(ticket.conversation)) ticket.conversation = [];
    ticket.conversation.push(newMsg);
    ticket.updatedAt = new Date().toISOString();

    if (setStatus && setStatus !== ticket.status) {
      const oldStatus = ticket.status;
      ticket.status = setStatus;
      if (!Array.isArray(ticket.statusHistory)) ticket.statusHistory = [];
      ticket.statusHistory.push({
        status: setStatus,
        changedBy: req.user?.name || 'Admin',
        changedAt: new Date().toISOString(),
        note: `Status updated with admin reply from ${oldStatus} to ${setStatus}`
      });
    }

    await persistStore();
    try {
      await setDoc(doc(serverDb, 'support_tickets', ticket.id), JSON.parse(JSON.stringify(ticket)), { merge: true });
    } catch (_) {}
    res.json({ success: true, message: newMsg, ticket });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to post admin reply.' });
  }
});

// 4. Admin Delete Ticket
app.delete('/api/admin/tickets/:id', requireAdmin, async (req: AuthenticatedRequest, res: Response) => {
  const { id } = req.params;
  const target = (currentStore.supportTickets || []).find((t) => t.id === id || t.ticketNumber === id);
  currentStore.supportTickets = (currentStore.supportTickets || []).filter((t) => t.id !== id && t.ticketNumber !== id);
  await persistStore();
  if (target) {
    try {
      await deleteDoc(doc(serverDb, 'support_tickets', target.id));
    } catch (_) {}
  }
  res.json({ success: true, message: 'Ticket deleted.' });
});

// ================= ADMIN SERVICES & PRODUCTS MANAGEMENT =================

// 1. Add Service / Product
app.post('/api/admin/service-products', requireAdmin, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { name, category, type, description, badge, points, price, available, showInSelectionMenu, iconName } = req.body;

    if (!name || !String(name).trim()) {
      return res.status(400).json({ error: 'Name is required.' });
    }

    if (!Array.isArray(currentStore.serviceProducts)) {
      currentStore.serviceProducts = [];
    }

    const newItem: ServiceProductItem = {
      id: 'sp_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
      name: String(name).trim(),
      category: category ? String(category).trim() : 'Custom Solutions',
      type: type === 'product' ? 'product' : 'service',
      description: String(description || '').trim(),
      badge: badge ? String(badge).trim() : undefined,
      points: Array.isArray(points) ? points.map(String).filter(Boolean) : [],
      price: price ? String(price).trim() : undefined,
      available: available !== false,
      showInSelectionMenu: showInSelectionMenu !== false,
      displayOrder: currentStore.serviceProducts.length + 1,
      iconName: iconName ? String(iconName).trim() : 'Box',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    currentStore.serviceProducts.push(newItem);
    await persistStore();

    res.status(201).json({ success: true, item: newItem });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to create service/product.' });
  }
});

// 2. Update Service / Product
app.patch('/api/admin/service-products/:id', requireAdmin, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { id } = req.params;
    const item = (currentStore.serviceProducts || []).find((p) => p.id === id);
    if (!item) {
      return res.status(404).json({ error: 'Service/product not found.' });
    }

    const { name, category, type, description, badge, points, price, available, showInSelectionMenu, displayOrder, iconName } = req.body;

    if (name !== undefined) item.name = String(name).trim();
    if (category !== undefined) item.category = String(category).trim();
    if (type !== undefined) item.type = type === 'product' ? 'product' : 'service';
    if (description !== undefined) item.description = String(description).trim();
    if (badge !== undefined) item.badge = badge ? String(badge).trim() : undefined;
    if (points !== undefined && Array.isArray(points)) item.points = points.map(String).filter(Boolean);
    if (price !== undefined) item.price = price ? String(price).trim() : undefined;
    if (available !== undefined) item.available = Boolean(available);
    if (showInSelectionMenu !== undefined) item.showInSelectionMenu = Boolean(showInSelectionMenu);
    if (displayOrder !== undefined) item.displayOrder = Number(displayOrder);
    if (iconName !== undefined) item.iconName = String(iconName).trim();
    item.updatedAt = new Date().toISOString();

    await persistStore();
    res.json({ success: true, item });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to update service/product.' });
  }
});

// 3. Delete Service / Product
app.delete('/api/admin/service-products/:id', requireAdmin, async (req: AuthenticatedRequest, res: Response) => {
  const { id } = req.params;
  currentStore.serviceProducts = (currentStore.serviceProducts || []).filter((p) => p.id !== id);
  await persistStore();
  res.json({ success: true, message: 'Service/product removed.' });
});

// 4. Reorder Services & Products
app.put('/api/admin/service-products/reorder', requireAdmin, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { orderedIds } = req.body;
    if (!Array.isArray(orderedIds)) {
      return res.status(400).json({ error: 'orderedIds array required.' });
    }

    const items = currentStore.serviceProducts || [];
    orderedIds.forEach((id: string, index: number) => {
      const it = items.find((p) => p.id === id);
      if (it) {
        it.displayOrder = index + 1;
        it.updatedAt = new Date().toISOString();
      }
    });

    items.sort((a, b) => (a.displayOrder || 0) - (b.displayOrder || 0));
    currentStore.serviceProducts = items;
    await persistStore();

    res.json({ success: true, items });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to reorder items.' });
  }
});

// ================= CUBIX VOUCHES & REPUTATION SYSTEM =================
const vouchRateLimitMap = new Map<string, number>();

function computeApprovedVouchStats(allVouches: VouchItem[]) {
  const approved = (allVouches || [])
    .filter((v) => v && v.status === 'approved')
    .sort((a, b) => {
      const timeB = new Date(b.approvedAt || b.createdAt || 0).getTime();
      const timeA = new Date(a.approvedAt || a.createdAt || 0).getTime();
      return timeB - timeA;
    });

  const totalVouches = approved.length;
  const averageRating =
    totalVouches > 0
      ? Number(
          (
            approved.reduce((sum, item) => sum + Math.min(Math.max(Number(item.rating) || 5, 1), 5), 0) /
            totalVouches
          ).toFixed(1)
        )
      : 0;

  return {
    approved,
    stats: {
      totalVouches,
      averageRating,
      formattedRating: `${averageRating.toFixed(1)}/5`
    }
  };
}

// 1. Public Get Approved Vouches & Live Reputation Stats
app.get('/api/vouches', (_req: Request, res: Response) => {
  const { approved, stats } = computeApprovedVouchStats(currentStore.vouches || []);
  res.json({
    success: true,
    vouches: approved,
    latestVouch: approved[0] || null,
    stats
  });
});

// 2. Public Submit New Vouch (Always enters 'pending' status)
app.post('/api/vouches', async (req: Request, res: Response) => {
  try {
    const clientIp = String(req.headers['x-forwarded-for'] || req.socket.remoteAddress || 'unknown');
    const nowMs = Date.now();
    const lastSubmit = vouchRateLimitMap.get(clientIp) || 0;
    if (nowMs - lastSubmit < 8000) {
      return res.status(429).json({
        error: 'Please wait a few seconds before submitting another vouch.'
      });
    }

    const { name, discordUsername, productOrService, feedback, rating } = req.body;

    const cleanName = String(name || '').trim();
    if (!cleanName || cleanName.length < 2) {
      return res.status(400).json({ error: 'Please enter your name (at least 2 characters).' });
    }
    if (cleanName.length > 80) {
      return res.status(400).json({ error: 'Your name must be 80 characters or fewer.' });
    }

    const cleanDiscord = String(discordUsername || '').trim();
    if (!cleanDiscord || cleanDiscord.length < 2) {
      return res.status(400).json({ error: 'Discord Username is required.' });
    }
    if (cleanDiscord.length > 60) {
      return res.status(400).json({ error: 'Discord Username must be 60 characters or fewer.' });
    }

    const cleanProduct = String(productOrService || '').trim();
    if (!cleanProduct) {
      return res.status(400).json({ error: 'Please select the product or service you purchased.' });
    }

    const cleanFeedback = String(feedback || '').trim();
    if (!cleanFeedback || cleanFeedback.length < 15) {
      return res.status(400).json({ error: 'Please write at least 15 characters describing your experience.' });
    }
    if (cleanFeedback.length > 1000) {
      return res.status(400).json({ error: 'Your vouch must be 1,000 characters or fewer.' });
    }

    const numericRating = Number(rating);
    if (!Number.isInteger(numericRating) || numericRating < 1 || numericRating > 5) {
      return res.status(400).json({ error: 'Please select a star rating between 1 and 5.' });
    }

    if (!Array.isArray(currentStore.vouches)) {
      currentStore.vouches = [];
    }

    // Duplicate submission protection
    const isDuplicate = currentStore.vouches.some(
      (v) =>
        v.discordUsername.toLowerCase() === cleanDiscord.toLowerCase() &&
        v.feedback.toLowerCase() === cleanFeedback.toLowerCase() &&
        nowMs - new Date(v.createdAt || 0).getTime() < 5 * 60 * 1000
    );
    if (isDuplicate) {
      return res.status(409).json({
        error: 'This exact vouch was recently submitted and is already awaiting approval.'
      });
    }

    const nowIso = new Date().toISOString();
    const newVouch: VouchItem = {
      id: 'vch_' + nowMs + '_' + crypto.randomBytes(3).toString('hex'),
      name: cleanName,
      discordUsername: cleanDiscord,
      productOrService: cleanProduct.slice(0, 120),
      feedback: cleanFeedback,
      rating: numericRating,
      status: 'pending',
      isVerified: false,
      createdAt: nowIso,
      approvedAt: null,
      updatedAt: nowIso
    };

    vouchRateLimitMap.set(clientIp, nowMs);
    currentStore.vouches = [newVouch, ...currentStore.vouches];
    await persistStore();

    try {
      await setDoc(doc(serverDb, 'vouches', newVouch.id), newVouch);
    } catch (fsErr: any) {
      console.warn('[Firestore] Vouch write notice:', fsErr?.message);
    }

    res.status(201).json({
      success: true,
      message: 'Your vouch has been submitted successfully and is awaiting approval.',
      vouch: newVouch
    });
  } catch (err: any) {
    console.error('[Vouches] Submission error:', err);
    res.status(500).json({ error: 'Failed to submit vouch. Please try again.' });
  }
});

// 3. Admin Get All Vouches (Pending, Approved, Rejected)
app.get('/api/admin/vouches', requireAuth, (_req: AuthenticatedRequest, res: Response) => {
  const allVouches = (currentStore.vouches || []).sort(
    (a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime()
  );
  const { stats } = computeApprovedVouchStats(allVouches);
  res.json({
    success: true,
    vouches: allVouches,
    stats
  });
});

// 4. Admin Update Vouch (Approve, Reject, Restore to Pending, Toggle Verified Client, Edit Details)
app.patch('/api/admin/vouches/:id', requireAdmin, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { id } = req.params;
    if (!Array.isArray(currentStore.vouches)) {
      currentStore.vouches = [];
    }

    const target = currentStore.vouches.find((v) => v.id === id);
    if (!target) {
      return res.status(404).json({ error: 'Vouch not found.' });
    }

    const { name, discordUsername, productOrService, feedback, rating, status, isVerified } = req.body;
    const nowIso = new Date().toISOString();

    if (name !== undefined && String(name).trim().length >= 2) {
      target.name = String(name).trim().slice(0, 80);
    }
    if (discordUsername !== undefined && String(discordUsername).trim().length >= 2) {
      target.discordUsername = String(discordUsername).trim().slice(0, 60);
    }
    if (productOrService !== undefined && String(productOrService).trim().length >= 1) {
      target.productOrService = String(productOrService).trim().slice(0, 120);
    }
    if (feedback !== undefined && String(feedback).trim().length >= 5) {
      target.feedback = String(feedback).trim().slice(0, 1000);
    }
    if (rating !== undefined) {
      const r = Number(rating);
      if (Number.isInteger(r) && r >= 1 && r <= 5) {
        target.rating = r;
      }
    }
    if (isVerified !== undefined) {
      target.isVerified = Boolean(isVerified);
    }
    if (status !== undefined && ['pending', 'approved', 'rejected'].includes(String(status))) {
      const nextStatus = status as VouchStatus;
      if (nextStatus === 'approved' && target.status !== 'approved') {
        target.approvedAt = nowIso;
      } else if (nextStatus !== 'approved') {
        target.approvedAt = null;
      }
      target.status = nextStatus;
    }

    target.updatedAt = nowIso;
    await persistStore();

    try {
      await setDoc(doc(serverDb, 'vouches', target.id), target, { merge: true });
    } catch (fsErr: any) {
      console.warn('[Firestore] Vouch update notice:', fsErr?.message);
    }

    const { stats } = computeApprovedVouchStats(currentStore.vouches);
    res.json({
      success: true,
      vouch: target,
      stats
    });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to update vouch.' });
  }
});

// 5. Admin Delete Vouch Permanently
app.delete('/api/admin/vouches/:id', requireAdmin, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { id } = req.params;
    currentStore.vouches = (currentStore.vouches || []).filter((v) => v.id !== id);
    await persistStore();

    try {
      await deleteDoc(doc(serverDb, 'vouches', id));
    } catch (fsErr: any) {
      console.warn('[Firestore] Vouch delete notice:', fsErr?.message);
    }

    const { stats } = computeApprovedVouchStats(currentStore.vouches);
    res.json({
      success: true,
      message: 'Vouch deleted permanently.',
      stats
    });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to delete vouch.' });
  }
});

// Reset to Verified Template
app.post('/api/admin/reset-defaults', requireAdmin, async (req: AuthenticatedRequest, res: Response) => {
  const preservedAccounts = currentStore.accounts;
  currentStore = {
    ...defaultStore,
    accounts: preservedAccounts
  };
  await persistStore();
  const { adminAuth, accounts, submissions, contactMessages, supportTickets, ...publicData } = currentStore;
  res.json({ success: true, data: publicData, message: 'Website reset to official defaults.' });
});

// ================= GLOBAL JSON ERROR HANDLER =================
app.use((err: any, req: Request, res: Response, next: NextFunction) => {
  console.error('[API Server Error]', err);
  if (res.headersSent) {
    return next(err);
  }
  res.status(err.status || 500).json({
    error: err.message || 'An unexpected internal server error occurred.'
  });
});

// Ensure all unmatched API requests consistently return JSON 404, never HTML
app.all('/api/*', (req: Request, res: Response) => {
  res.status(404).json({ error: `API route ${req.method} ${req.path} not found.` });
});

// ================= SERVER BOOTSTRAP & SPA ROUTING =================
function injectHeroBgIntoHtml(rawHtml: string): string {
  try {
    const heroBg = {
      ...defaultStore.settings.heroBackground,
      ...(currentStore.settings?.heroBackground || {})
    };
    const serialized = JSON.stringify(heroBg).replace(/</g, '\\u003c');
    return rawHtml.replace(
      '/*__CUBIX_SERVER_HERO_BG__*/',
      `window.__CUBIX_SERVER_HERO_BG__ = ${serialized};`
    );
  } catch {
    return rawHtml;
  }
}

async function startServer() {
  const isDev = process.env.NODE_ENV !== 'production';

  if (isDev) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'custom'
    });
    app.use(vite.middlewares);
    app.use('*', async (req: Request, res: Response, next: NextFunction) => {
      if (req.originalUrl.startsWith('/api')) {
        return next();
      }
      try {
        const indexPath = path.resolve(__dirname, 'index.html');
        let template = fs.readFileSync(indexPath, 'utf-8');
        template = injectHeroBgIntoHtml(template);
        const html = await vite.transformIndexHtml(req.originalUrl, template);
        res.status(200).set({ 'Content-Type': 'text/html' }).end(html);
      } catch (e) {
        next(e);
      }
    });
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath, { index: false }));
    app.get('*', (req: Request, res: Response) => {
      if (req.path.startsWith('/api')) {
        return res.status(404).json({ error: `API route ${req.method} ${req.path} not found.` });
      }
      try {
        const indexFile = path.resolve(distPath, 'index.html');
        const rawHtml = fs.readFileSync(indexFile, 'utf-8');
        res.status(200).set({ 'Content-Type': 'text/html' }).send(injectHeroBgIntoHtml(rawHtml));
      } catch {
        res.sendFile(path.resolve(distPath, 'index.html'));
      }
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[Cubix Studio Server] Running on http://0.0.0.0:${PORT} (${isDev ? 'dev' : 'production'})`);
  });
}

// Only start standalone HTTP server when executed directly (not in Vercel serverless function)
if (!process.env.VERCEL) {
  startServer();
}

export default app;
