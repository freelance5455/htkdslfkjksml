import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';
import { createServer as createViteServer } from 'vite';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

app.use(express.json({ limit: '10mb' }));

// Initialize GoogleGenAI SDK with server-side API Key
const apiKey = process.env.GEMINI_API_KEY || '';
const ai = new GoogleGenAI({
  apiKey,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

// ==========================================
// 1. Health & Connection Status
// ==========================================
app.get('/api/gemini/status', async (_req, res) => {
  try {
    if (!apiKey) {
      return res.json({
        connected: false,
        status: 'missing_key',
        model: 'gemini-3.8-flash',
        message: 'مفتاح Gemini API غير معرف في متغيرات السيرفر.',
      });
    }

    return res.json({
      connected: true,
      status: 'active',
      model: 'gemini-3.8-flash',
      message: 'محرك Gemini AI متصل بنجاح وجاهز لمعالجة الطلبات التحليلية والذكية.',
      timestamp: new Date().toISOString(),
    });
  } catch (error: any) {
    return res.status(500).json({
      connected: false,
      error: error.message || 'فشل في الاتصال بمحرك الذكاء الاصطناعي',
    });
  }
});

// ==========================================
// 2. Audit Log & Security Deep Analysis
// ==========================================
app.post('/api/gemini/analyze-audit', async (req, res) => {
  try {
    const { logs, stats } = req.body;

    if (!apiKey) {
      return res.status(503).json({
        error: 'Gemini API Key is not configured on the server.',
      });
    }

    const prompt = `
أنت كبير مسؤولي أمن النظم ومكافحة الاحتيال المالي وإساءة استخدام ألعاب الورق في منصة "تابيونا" (TABEONA Royal Gaming).
المطلوب: تحليل دقيق لسجل التدقيق والعمليات (Audit Log) والأنشطة المشبوهة المرفقة، وتقديم تقرير أمني واقتصادي استراتيجي باللغة العربية.

البيانات المقدمة للتحليل:
- إحصائيات عامة: ${JSON.stringify(stats || {})}
- سجل العمليات الأخيرة المشبوهة/الهامة:
${JSON.stringify((logs || []).slice(0, 30), null, 2)}

المطلوب إرجاع رد بصيغة JSON حصراً بدون علامات markdown، بالمخطط التالي:
{
  "threatLevel": "LOW" | "MEDIUM" | "HIGH" | "CRITICAL",
  "threatScore": number (0 to 100),
  "executiveSummary": "ملخص تنفيذي مركز عن الوضع الأمني وسلامة الاقتصاد في المنصة",
  "detectedAnomalies": [
    "ملاحظة 1 حول أي تلاعب بالأرصدة أو عمليات مشبوهة",
    "ملاحظة 2 حول تحويلات الكاشير أو اللاعبين"
  ],
  "flaggedPlayers": [
    {
      "playerId": "string",
      "playerName": "string",
      "reason": "سبب الاشتباه الفني",
      "severity": "HIGH" | "MEDIUM" | "LOW"
    }
  ],
  "recommendedActions": [
    "إجراء 1 فوري موصى به للمشرف",
    "إجراء 2 لتعزيز الأمان"
  ],
  "systemIntegrityVerdict": "SAFE" | "NEEDS_ATTENTION" | "ALERT"
}
`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        temperature: 0.2,
      },
    });

    const text = response.text || '{}';
    let parsedData;
    try {
      parsedData = JSON.parse(text);
    } catch {
      parsedData = {
        threatLevel: 'MEDIUM',
        threatScore: 45,
        executiveSummary: text,
        detectedAnomalies: ['تم استلام التحليل كنص'],
        flaggedPlayers: [],
        recommendedActions: ['مراجعة العمليات يدوياً'],
        systemIntegrityVerdict: 'NEEDS_ATTENTION',
      };
    }

    return res.json({
      success: true,
      analysis: parsedData,
      analyzedAt: new Date().toISOString(),
    });
  } catch (error: any) {
    console.error('Error analyzing audit logs with Gemini:', error);
    return res.status(500).json({
      success: false,
      error: error.message || 'حدث خطأ أثناء معالجة التحليل بالذكاء الاصطناعي',
    });
  }
});

// ==========================================
// 3. Player Anti-Cheat & Behavior Forensics
// ==========================================
app.post('/api/gemini/analyze-player', async (req, res) => {
  try {
    const { player, incidents, matchHistory } = req.body;

    if (!apiKey) {
      return res.status(503).json({
        error: 'Gemini API Key is not configured on the server.',
      });
    }

    const prompt = `
أنت خبير كشف بوتات الغش والتواطؤ (Collusion) في ألعاب الورق الجماعية (طرنيب وتركس وبلوت).
قم بفحص بيانات اللاعب وسجل مبارياته ومؤشرات الذكاء الاصطناعي التالية:
- بيانات اللاعب: ${JSON.stringify(player || {})}
- حوادث الشبهة المسجلة: ${JSON.stringify(incidents || [])}
- عينة من سجل المباريات: ${JSON.stringify(matchHistory || [])}

أرجع تقرير JSON حصرياً بالمخطط التالي:
{
  "isBot": boolean,
  "cheatProbability": number (0-100),
  "verdict": "CLEAN" | "SUSPICIOUS" | "CONFIRMED_CHEAT",
  "reasoningArabic": "شرح تحليلي مفصل لسلوك اللاعب وطريقة لعبه بالأدلة",
  "recommendedAction": "BAN" | "FREEZE_FUNDS" | "WARN" | "MONITOR_ONLY" | "CLEAR",
  "evidencePoints": ["نقطة 1", "نقطة 2"]
}
`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        temperature: 0.1,
      },
    });

    const parsed = JSON.parse(response.text || '{}');
    return res.json({ success: true, report: parsed });
  } catch (error: any) {
    console.error('Error in player forensics:', error);
    return res.status(500).json({
      success: false,
      error: error.message || 'فشل في تحليل سلوك اللاعب',
    });
  }
});

// ==========================================
// 4. Tarneeb Smart Tactical Advisor
// ==========================================
app.post('/api/gemini/tarneeb-hint', async (req, res) => {
  try {
    const { hand, trumpSuit, currentTrick, playerIndex, currentScore, bid } = req.body;

    if (!apiKey) {
      return res.status(503).json({
        error: 'Gemini API Key is not configured on the server.',
      });
    }

    const prompt = `
أنت بطل محترف ومدرب استراتيجي في لعبة الطرنيب السورية والعربية 41.
وضعية اللعبة الحالية:
- نوع الطرنيب (الحكم): ${trumpSuit || 'غير محدد'}
- طلب المزايدة (Bid): ${bid ? `${bid.tricks} من قبل ${bid.player}` : 'غير معروف'}
- النتيجة الحالية: فريقنا ${currentScore?.ourTeam || 0} ضد الخصم ${currentScore?.theirTeam || 0}
- اللطخة الحالية على الطاولة: ${JSON.stringify(currentTrick || [])}
- بطاقات يد اللاعب الحالية: ${JSON.stringify(hand || [])}
- دور اللاعب: ${playerIndex ?? 0}

المطلوب: اقتراح أفضل كرت يجب أن يلعبه اللاعب الآن مع شرح تكتيكي مختصر ومقنع (لماذا هذا الكرت هو الخيار الأفضل لحماية الأكلة أو التخلص من كرت ضعيف أو سحب الطرنيب).

أرجع JSON حصراً:
{
  "suggestedCard": {
    "suit": "HEARTS" | "DIAMONDS" | "CLUBS" | "SPADES",
    "rank": "2" | "3" | "4" | "5" | "6" | "7" | "8" | "9" | "10" | "J" | "Q" | "K" | "A"
  },
  "tacticalReason": "الشرح التكتيكي باللغة العربية (جملتين كحد أقصى)",
  "riskRating": "LOW" | "BALANCED" | "AGGRESSIVE"
}
`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        temperature: 0.2,
      },
    });

    const parsed = JSON.parse(response.text || '{}');
    return res.json({ success: true, hint: parsed });
  } catch (error: any) {
    console.error('Error generating Tarneeb hint:', error);
    return res.status(500).json({
      success: false,
      error: error.message || 'فشل في توليد نصيحة الطرنيب الذكية',
    });
  }
});

// ==========================================
// 5. Customer Support AI Assistant Smart Reply
// ==========================================
app.post('/api/gemini/support-reply', async (req, res) => {
  try {
    const { ticket, lastPlayerMessage, chatHistory, tone } = req.body;

    if (!apiKey) {
      return res.status(503).json({
        error: 'Gemini API Key is not configured on the server.',
      });
    }

    const prompt = `
أنت المشرف الأول لخدمة عملاء ودعم كبار الشخصيات (VIP Customer Support) في منصة ألعاب الورق الملكية "تابيونا" (TABEONA).
المهمة: كتابة رد رسمي، ودود، فوري واحترافي باللغة العربية على استفسار اللاعب أدناه.

تفاصيل تذكرة الدعم:
- عنوان التذكرة: ${ticket?.subject || 'استفسار عام'}
- التصنيف: ${ticket?.category || 'عام'}
- اسم اللاعب: ${ticket?.playerName || 'عزيزنا اللاعب'}
- رتبة اللاعب / VIP: ${ticket?.playerVip ? `VIP Level ${ticket.playerVip}` : 'لاعب عادي'}
- رسالة اللاعب الأخيرة: "${lastPlayerMessage || ''}"
- نبرة الرد المطلوبة: ${tone || 'مهذبة، واثقة، ومطمئنة للاعب'}
- سجل المحادثة السابقة:
${JSON.stringify((chatHistory || []).slice(-6), null, 2)}

إرشادات صياغة الرد:
1. ابدأ بتحية تليق بالمنصة الملكية (مثل: "أهلاً بك عزيزنا [اسم اللاعب] في دعم TABEONA الملكي").
2. أجب مباشرة على استفساره بدقة (سواء كان استفسار كاشير، سحب USDT، رصيد مفقود، أو مشكلة في لعبة طرنيب).
3. كن مطمئناً واعرض حلاً ملموساً أو أكد له متابعة الفريق الفني/المالي لطلبه فوراً.
4. حافظ على الأسلوب المهني اللائق بدون تكلف مفرط.

المطلوب إرجاع رد بصيغة JSON فقط:
{
  "suggestedReply": "نص الرد الكامل باللغة العربية",
  "suggestedAction": "NONE" | "GRANT_COMPENSATION" | "FORWARD_TO_CASHIER" | "RESOLVE_TICKET",
  "recommendedCompensationAmount": number | null,
  "confidenceScore": number
}
`;

    const timeoutPromise = new Promise((_, reject) =>
      setTimeout(() => reject(new Error('Gemini API timeout')), 5000)
    );

    const response: any = await Promise.race([
      ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: prompt,
        config: {
          responseMimeType: 'application/json',
          temperature: 0.3,
        },
      }),
      timeoutPromise,
    ]);

    const parsed = JSON.parse(response.text || '{}');
    return res.json({ success: true, replyData: parsed });
  } catch (error: any) {
    console.error('Error generating support reply with Gemini, activating intelligent fallback:', error?.message);
    const playerName = req.body?.ticket?.playerName || 'عزيزنا اللاعب';
    const subject = req.body?.ticket?.subject || 'طلبك';
    const category = req.body?.ticket?.category;

    let fallbackText = `أهلاً بك عزيزنا ${playerName} في خدمة عملاء TABEONA الملكية! بخصوص استفسارك حول "${subject}"، طلبك قيد المتابعة الفورية وسنوافيك بالحل مباشرة.`;
    if (category === 'FINANCIAL') {
      fallbackText = `أهلاً بك عزيزنا ${playerName} في دعم TABEONA الملكي. بخصوص استفسارك المالي عن "${subject}"، تم إرسال إشعار مباشر لقسم الكاشير المركزي للتدقيق واعتماد التحويل في أسرع وقت.`;
    } else if (category === 'GAMEPLAY') {
      fallbackText = `أهلاً بك عزيزنا ${playerName}. نعتذر عن أي خلل واجهته في جولة الطرنيب، يجري فحص سجل المباراة لضمان حقوقك وتعويضك على الفور.`;
    }

    return res.json({
      success: true,
      replyData: {
        suggestedReply: fallbackText,
        suggestedAction: 'NONE',
        recommendedCompensationAmount: null,
        confidenceScore: 92,
      },
      fallback: true,
    });
  }
});

// ==========================================
// 6. Mount Vite or Serve Static Files
// ==========================================
async function bootstrap() {
  const isProd = process.env.NODE_ENV === 'production';

  if (!isProd) {
    console.log('Mounting Vite dev server middleware in Express...');
    const vite = await createViteServer({
      server: { middlewareMode: true, hmr: process.env.DISABLE_HMR !== 'true' },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`🚀 TABEONA Full-Stack Server running on http://0.0.0.0:${PORT}`);
    console.log(`🧠 Gemini AI Engine Status: ${apiKey ? 'Configured & Active' : 'Missing Key'}`);
  });
}

bootstrap().catch((err) => {
  console.error('Fatal server boot error:', err);
  process.exit(1);
});
