import 'dotenv/config';
import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI, ThinkingLevel } from '@google/genai';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

let cachedDefaultAi: GoogleGenAI | null = null;

function getDefaultAi(): GoogleGenAI {
  if (!cachedDefaultAi) {
    cachedDefaultAi = new GoogleGenAI({
      apiKey: process.env.GEMINI_API_KEY || 'missing-api-key',
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return cachedDefaultAi;
}

// Prioritize the exact model from the user's original app (gemini-3-flash-preview) and fast flash aliases
const TEXT_MODELS = [
  'gemini-3-flash-preview',
  'gemini-flash-latest',
  'gemini-3.1-flash-lite',
  'gemini-3.8-flash',
];

async function generateWithFallback(params: {
  contents: any;
  config?: Record<string, any>;
}) {
  const aiClient = getDefaultAi();
  let lastError: any = null;
  for (const model of TEXT_MODELS) {
    try {
      const isGemini3 = model.startsWith('gemini-3');
      const response = await aiClient.models.generateContent({
        model,
        contents: params.contents,
        config: {
          ...(isGemini3 ? { thinkingConfig: { thinkingLevel: ThinkingLevel.LOW } } : {}),
          ...(params.config || {}),
        },
      });
      if (response && response.text) {
        return response;
      }
    } catch (err: any) {
      lastError = err;
      continue;
    }
  }
  throw lastError || new Error('AI request failed');
}

const EXPECTED_GATE_PASSWORD = process.env.APP_GATE_PASSWORD || 'YtY.0YinToYou.1YtY';

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '15mb' }));

  // Block all AI/TTS API calls unless the valid password gate header is provided
  app.use('/api/gemini', (req, res, next) => {
    const provided = req.headers['x-gate-password'];
    if (provided !== EXPECTED_GATE_PASSWORD) {
      res.status(401).json({ error: 'App ist gesperrt. Bitte zuerst das Passwort eingeben.' });
      return;
    }
    next();
  });

  app.post('/api/gemini/json', async (req, res) => {
    try {
      const { prompt, schema } = req.body;
      if (!prompt) {
        res.status(400).json({ error: 'Missing prompt' });
        return;
      }

      const response = await generateWithFallback({
        contents: prompt,
        config: {
          responseMimeType: 'application/json',
          ...(schema ? { responseSchema: schema } : {}),
        },
      });

      const raw = response.text || '{}';
      res.json({ data: JSON.parse(raw) });
    } catch (error: any) {
      console.error('Gemini JSON Error:', error?.message || error);
      res.status(500).json({ error: error?.message || 'AI request failed' });
    }
  });

  app.post('/api/gemini/text', async (req, res) => {
    try {
      const { prompt } = req.body;
      if (!prompt) {
        res.status(400).json({ error: 'Missing prompt' });
        return;
      }

      const response = await generateWithFallback({
        contents: prompt,
      });

      res.json({ text: response.text || '' });
    } catch (error: any) {
      console.error('Gemini Text Error:', error?.message || error);
      res.status(500).json({ error: error?.message || 'AI request failed' });
    }
  });

  app.post('/api/gemini/audio-eval', async (req, res) => {
    try {
      const { targetText, langName, audioBase64, mimeType } = req.body;
      if (!audioBase64 || !targetText) {
        res.status(400).json({ error: 'Missing audio or targetText' });
        return;
      }

      const response = await generateWithFallback({
        contents: {
          parts: [
            {
              text: `Sprache: ${langName || 'Japanisch'}. Gelesener Zieltext: "${targetText}". PrüfeAussprache kurz auf Deutsch.`,
            },
            {
              inlineData: {
                mimeType: mimeType || 'audio/webm',
                data: audioBase64,
              },
            },
          ],
        },
      });

      res.json({ text: response.text || 'Auswertung beendet.' });
    } catch (error: any) {
      console.error('Gemini Audio Eval Error:', error?.message || error);
      res.status(500).json({ error: error?.message || 'Audio evaluation failed' });
    }
  });

  // Expressive neural TTS endpoint supporting both Gemini TTS (with speechMetadata emphasis) and Google Cloud Neural2/Wavenet TTS when a custom Google API key is provided
  app.post('/api/gemini/tts', async (req, res) => {
    try {
      const { text, lang, voiceName, stylePrompt, customApiKey } = req.body;
      const cleanText = String(text || '').replace(/\[____\]/g, '').trim();
      if (!cleanText) {
        res.status(400).json({ error: 'Missing text' });
        return;
      }

      const trimmedCustomKey = typeof customApiKey === 'string' ? customApiKey.trim() : '';
      const targetLang: 'ja' | 'ko' = lang === 'ko' ? 'ko' : 'ja';
      const selectedVoice = typeof voiceName === 'string' && voiceName.trim() ? voiceName.trim() : 'Kore';
      const expressiveStyle =
        typeof stylePrompt === 'string' && stylePrompt.trim()
          ? stylePrompt.trim()
          : targetLang === 'ko'
          ? 'Warm, natural, expressive native Korean speaker with authentic prosody, clear phrase-level emphasis, and lifelike conversational flow'
          : 'Warm, natural, expressive native Japanese speaker with authentic Tokyo pitch accent, clear sentence-level emphasis on key words, and lifelike conversational flow';

      // 1. If the user entered a custom Google API Key, try Google Cloud Text-to-Speech API (Chirp3-HD / Neural2) first
      if (trimmedCustomKey) {
        try {
          const cloudVoiceMap: Record<'ja' | 'ko', Record<string, { name: string; ssmlGender: string }>> = {
            ja: {
              Kore: { name: 'ja-JP-Neural2-B', ssmlGender: 'FEMALE' },
              Aoede: { name: 'ja-JP-Wavenet-A', ssmlGender: 'FEMALE' },
              Zephyr: { name: 'ja-JP-Wavenet-B', ssmlGender: 'FEMALE' },
              Puck: { name: 'ja-JP-Neural2-C', ssmlGender: 'MALE' },
              Charon: { name: 'ja-JP-Neural2-D', ssmlGender: 'MALE' },
              Fenrir: { name: 'ja-JP-Wavenet-D', ssmlGender: 'MALE' },
            },
            ko: {
              Kore: { name: 'ko-KR-Neural2-A', ssmlGender: 'FEMALE' },
              Aoede: { name: 'ko-KR-Neural2-B', ssmlGender: 'FEMALE' },
              Zephyr: { name: 'ko-KR-Wavenet-A', ssmlGender: 'FEMALE' },
              Puck: { name: 'ko-KR-Neural2-C', ssmlGender: 'MALE' },
              Charon: { name: 'ko-KR-Wavenet-C', ssmlGender: 'MALE' },
              Fenrir: { name: 'ko-KR-Wavenet-D', ssmlGender: 'MALE' },
            },
          };

          const cloudVoice =
            cloudVoiceMap[targetLang][selectedVoice] || cloudVoiceMap[targetLang].Kore;
          const escapedSsml = cleanText
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;');
          const ssml = `<speak><prosody rate="98%" pitch="+0.5st"><emphasis level="moderate">${escapedSsml}</emphasis></prosody></speak>`;

          const cloudRes = await fetch(
            `https://texttospeech.googleapis.com/v1/text:synthesize?key=${encodeURIComponent(
              trimmedCustomKey
            )}`,
            {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                input: { ssml },
                voice: {
                  languageCode: targetLang === 'ko' ? 'ko-KR' : 'ja-JP',
                  name: cloudVoice.name,
                  ssmlGender: cloudVoice.ssmlGender,
                },
                audioConfig: {
                  audioEncoding: 'LINEAR16',
                  sampleRateHertz: 24000,
                },
              }),
            }
          );

          if (cloudRes.ok) {
            const cloudData = (await cloudRes.json()) as { audioContent?: string };
            if (cloudData?.audioContent) {
              res.json({
                audioBase64: cloudData.audioContent,
                mimeType: 'audio/wav',
                provider: 'google-cloud-neural2',
              });
              return;
            }
          }
        } catch {
          // If the custom key is a Gemini API key rather than a Cloud TTS key, fall through to Gemini TTS below
        }
      }

      // 2. Gemini Neural TTS (uses customApiKey if provided, otherwise falls back to server GEMINI_API_KEY)
      const defaultAi = getDefaultAi();
      const clientCandidates = trimmedCustomKey
        ? [
            new GoogleGenAI({
              apiKey: trimmedCustomKey,
              httpOptions: { headers: { 'User-Agent': 'aistudio-build' } },
            }),
            defaultAi,
          ]
        : [defaultAi];

      const ttsAttempts: Array<{ model: string; useSpeechMetadata: boolean }> = [
        { model: 'gemini-3.8-flash-tts', useSpeechMetadata: true },
        { model: 'gemini-3.8-flash-lite-tts', useSpeechMetadata: true },
        { model: 'gemini-2.5-flash-preview-tts', useSpeechMetadata: false },
        { model: 'gemini-3.8-flash-lite-tts', useSpeechMetadata: false },
      ];

      let lastErr: any = null;

      for (const client of clientCandidates) {
        for (const attempt of ttsAttempts) {
          try {
            const contents = attempt.useSpeechMetadata
              ? [
                  {
                    role: 'user',
                    parts: [
                      {
                        text: cleanText,
                        speechMetadata: {
                          style: expressiveStyle,
                        },
                      } as any,
                    ],
                  },
                ]
              : [{ parts: [{ text: cleanText }] }];

            const response = await client.models.generateContent({
              model: attempt.model,
              contents,
              config: {
                responseModalities: ['AUDIO'],
                speechConfig: {
                  voiceConfig: {
                    prebuiltVoiceConfig: { voiceName: selectedVoice },
                  },
                },
              },
            });

            const part = response.candidates?.[0]?.content?.parts?.[0];
            const b64 = part?.inlineData?.data;
            const mimeType = part?.inlineData?.mimeType || 'audio/L16;rate=24000';
            if (b64) {
              res.json({
                audioBase64: b64,
                mimeType,
                provider: attempt.model,
              });
              return;
            }
          } catch (err) {
            lastErr = err;
          }
        }
      }

      res.status(500).json({ error: lastErr?.message || 'No audio returned' });
    } catch (error: any) {
      console.error('Gemini TTS Error:', error?.message || error);
      res.status(500).json({ error: error?.message || 'TTS failed' });
    }
  });

  if (process.env.NODE_ENV === 'production') {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  } else {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  const PORT = Number(process.env.PORT) || 3000;
  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
