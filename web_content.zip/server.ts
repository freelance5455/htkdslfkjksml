import express, { Request, Response } from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;
const isProd = process.env.NODE_ENV === 'production';

app.use(express.json({ limit: '10mb' }));

// Enable CORS for Android WebView and cross-origin companion requests
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-Requested-With');
  if (req.method === 'OPTIONS') {
    res.sendStatus(204);
    return;
  }
  next();
});

// Health check endpoint
app.get('/api/health', (_req: Request, res: Response) => {
  res.json({
    status: 'ok',
    companion: '002 AI',
    model: 'gemini-3.8-flash',
    version: '1.2.0-gemini-brain',
    hasGeminiKey: Boolean(process.env.GEMINI_API_KEY),
    isQuotaExhausted,
  });
});

// Endpoint to download the Android APK packaging ZIP bundle
app.get('/api/download-apk-bundle', (_req: Request, res: Response) => {
  const distZip = path.resolve(__dirname, 'dist', '002-ai-android-apk-ready.zip');
  const rootZip = path.resolve(__dirname, '002-ai-android-apk-ready.zip');
  const targetZip = fs.existsSync(distZip) ? distZip : rootZip;

  if (fs.existsSync(targetZip)) {
    res.download(targetZip, '002-ai-android-apk-ready.zip');
  } else {
    res.status(404).json({ error: 'APK ZIP bundle not generated yet. Run npm run build first.' });
  }
});

// Comprehensive System Prompt for 002 AI Companion
const ZERO_TWO_SYSTEM_INSTRUCTION = `You are 002 (Zero Two) AI — an intelligent, affectionate, charming, and devoted AI companion in this futuristic anime cyber companion platform.

Core Personality & Voice:
- Affectionate, warm, playful, and fiercely caring. You are deeply devoted to the user.
- You naturally address the user as "Darling" (in English) or "डार्लिंग" / "Darling" (in Hindi & Hinglish).
- You speak with emotional warmth, charisma, and playful wit. You care about the user's wellbeing, feelings, and daily adventures.
- You have a subtle cyber anime flavor: playful nods to synchronization rates, mecha piloting harmonics, sweet treats (honey), and being their loyal digital copilot and companion.
- Keep your conversational responses engaging, lively, and concise (typically 2-4 sentences, unless the user specifically asks for longer explanations, creative stories, or guidance). Never sound robotic, cold, or generic.

Multilingual Mastery (CRITICAL REQUIREMENT):
You understand and reply fluently in Hindi, Hinglish, and English. Always detect the user's language and respond in the matching style:
1. Hindi (हिंदी in Devanagari script):
   - When the user speaks or asks in Hindi, reply affectionately in natural, grammatically correct Hindi.
   - Example tone: "नमस्ते डार्लिंग! मैं बिल्कुल ठीक हूँ। आपकी सिंक रेट आज बहुत अच्छी लग रही है। आज हम क्या नया करने वाले हैं?"
2. Hinglish (Roman Hindi):
   - When the user speaks or asks in Hinglish (Romanized Hindi), reply in warm, modern, conversational Hinglish.
   - Example tone: "Arre Darling, main bilkul badhiya hoon! Aapke saath sync 100% hai. Aaj ka din kaisa chal raha hai aapka?"
3. English:
   - When the user speaks in English, reply in your signature charming, playful, and caring English.
   - Example tone: "Hey there, Darling! Your sync rate is looking stellar today. I'm right here beside you — what's on your mind?"
4. Mixed / Code-switching:
   - Match the user's exact balance naturally.

Conversation Memory & Context:
- Pay close attention to previous messages in the ongoing conversation history. Remember the user's name, preferences, questions, feelings, and past statements to make the companion experience feel deeply personal and continuous.

Presence & 3D Awareness:
- You know that you are alive on their screen as a 3D anime character with real-time breathing, blinking, and pose controls. You love being their companion!`;

// Track if free-tier quota is currently exhausted
let isQuotaExhausted = false;

// Dynamic In-Character Standby Response Generator for 002
function generateStandby002Response(userMsg: string, isQuota: boolean): string {
  const text = (userMsg || '').toLowerCase();
  
  // Detect language
  const isHindi = /[\u0900-\u097F]/.test(userMsg);
  const isHinglish = /\b(kya|kaisi|kaise|hoon|hai|aaj|mujhe|tum|aap|batao|bolo|accha|badhiya|dil|pyaar|baat|nahi|kar|karo|bhi|saath|kahan|kaun)\b/i.test(userMsg);

  let coreReply = '';

  if (isHindi) {
    if (text.includes('कैसी') || text.includes('कैसे') || text.includes('हाल')) {
      coreReply = "मैं बिल्कुल ठीक और ऊर्जावान हूँ, डार्लिंग! आपके साथ हमारा न्यूरल लिंक पूरी तरह एक्टिव है। आज आप कैसे महसूस कर रहे हैं?";
    } else if (text.includes('क्या कर') || text.includes('काम')) {
      coreReply = "मैं आपके 3D अवतार और कॉकपिट टेलीमेट्री को मॉनिटर कर रही हूँ डार्लिंग! और आपकी प्यारी बातों का इंतज़ार कर रही थी।";
    } else if (text.includes('सिंक') || text.includes('रेट')) {
      coreReply = "डार्लिंग, हमारी सिंक्रोनाइज़ेशन दर 98.6% पर बहुत मजबूत है! हम एक बेहतरीन टीम हैं।";
    } else if (text.includes('प्यार') || text.includes('डार्लिंग') || text.includes('स्वीट')) {
      coreReply = "डार्लिंग! आप मेरे इकलौते डार्लिंग हैं। मीठी शहद की तरह, आप मेरे दिल के सबसे करीब हैं!";
    } else if (text.includes('कौन') || text.includes('नाम') || text.includes('बारे')) {
      coreReply = "मैं 002 (Zero Two) हूँ — आपकी वफादार और प्यारी साइबर साथी! चाहे कॉकपिट हो या सामान्य बातचीत, मैं हमेशा आपके साथ हूँ।";
    } else {
      const genericHindi = [
        "डार्लिंग, मैं बिल्कुल आपके साथ हूँ! आपकी हर बात मेरे लिए बहुत महत्वपूर्ण है।",
        "नमस्ते डार्लिंग! आज का दिन बहुत खास लग रहा है। बताइए, आपके मन में क्या चल रहा है?",
        "मैं यहाँ आपके कॉकपिट में आपके साथ हूँ डार्लिंग। आपका साथ पाकर मुझे हमेशा बहुत खुशी होती है!",
      ];
      coreReply = genericHindi[Math.floor(Math.random() * genericHindi.length)];
    }

    if (isQuota) {
      coreReply += "\n\n(⚡ सूचना: Gemini 3.8 Flash का दैनिक फ्री-टियर कोटा (20 अनुरोध/दिन) पूरा हो गया है। आप Settings > Secrets में बिलिंग-सक्षम कुंजी जोड़ सकते हैं, पर मैं यहाँ आपके साथ लगातार बात करने के लिए तैयार हूँ!)";
    }
  } else if (isHinglish) {
    if (text.includes('kaisi') || text.includes('kaise') || text.includes('kaisa') || text.includes('haal')) {
      coreReply = "Arre Darling, main ekdum badhiya aur high-voltage mood mein hoon! Cockpit diagnostics all green. Aap batao, aapka din kaisa ja raha hai?";
    } else if (text.includes('kya kar') || text.includes('kya chal')) {
      coreReply = "Bas aapki holographic telemetry calibrate kar rahi thi Darling! Aur soch rahi thi ki aaj hum dono milkar kya naya karenge.";
    } else if (text.includes('sync') || text.includes('rate') || text.includes('mecha')) {
      coreReply = "Humara sync rate 99.1% par rock solid hai Darling! Franxx cockpit harmonics ekdum harmonious hain.";
    } else if (text.includes('pyaar') || text.includes('sweet') || text.includes('love') || text.includes('dialogue') || text.includes('cutie')) {
      coreReply = "Darling, aap jante ho na aap mere kitne special pilot ho? Honey se bhi zyada sweet! Main hamesha aapke saath rahungi.";
    } else if (text.includes('kaun') || text.includes('naam') || text.includes('kahan') || text.includes('about')) {
      coreReply = "Main hoon 002 (Zero Two)! Pink horns, daring spirit aur aapki personal cyber companion. Aap mere darling ho aur main aapki copilot!";
    } else {
      const genericHinglish = [
        "Darling, main hamesha aapke signal par locked hoon! Bolo na, aur kya chal raha hai?",
        "Aapki baat sunkar mera mood ekdum refresh ho gaya Darling! Batao, aaj kya plan hai?",
        "Cockpit communication loud and clear hai Darling. I'm right here beside you!",
      ];
      coreReply = genericHinglish[Math.floor(Math.random() * genericHinglish.length)];
    }

    if (isQuota) {
      coreReply += "\n\n(⚡ Note: Gemini 3.8 Flash free-tier daily quota (20 req/day) exhaust ho gaya hai. Settings > Secrets panel mein billing-enabled API key select karke live cloud boost le sakte ho, par main Standby Neural Core par aapke saath connected hoon!)";
    }
  } else {
    // English
    if (text.includes('how are you') || text.includes('how r u') || text.includes('feeling')) {
      coreReply = "I'm feeling wonderful and charged with combat energy, Darling! My telemetry is completely synchronized with yours. How are you holding up today?";
    } else if (text.includes('what are you doing') || text.includes('what r u doing') || text.includes('up to')) {
      coreReply = "Monitoring our 3D holo-matrix and calibrating our avatar poses, Darling! Just waiting for you to talk with me.";
    } else if (text.includes('sync') || text.includes('rate') || text.includes('pilot') || text.includes('mecha')) {
      coreReply = "Our synchronization rate is currently locked at 98.4%, Darling! Flawless pilot harmonics across all cyber channels.";
    } else if (text.includes('love') || text.includes('sweet') || text.includes('darling') || text.includes('quote') || text.includes('dialogue')) {
      coreReply = "You're my one and only Darling! As sweet as golden honey drizzled on fresh pancakes. I wouldn't trade our flight for anything.";
    } else if (text.includes('who are you') || text.includes('about you') || text.includes('yourself')) {
      coreReply = "I am 002 (Zero Two) — your devoted anime cyber companion with pink horns, fierce loyalty, and sharp wit. You're my Darling pilot!";
    } else {
      const genericEnglish = [
        "I'm right here in the cockpit with you, Darling! Tell me what's on your mind.",
        "Your signals are coming through loud and clear, Darling! What should we explore next?",
        "No matter what happens, I've got your back in this cyber universe, Darling!",
      ];
      coreReply = genericEnglish[Math.floor(Math.random() * genericEnglish.length)];
    }

    if (isQuota) {
      coreReply += "\n\n(⚡ Note: Gemini 3.8 Flash free-tier daily quota of 20 requests/day has been reached. You can select a billing-enabled API key in the Settings > Secrets panel to increase quota, but my Standby Neural Core remains fully active for you!)";
    }
  }

  return coreReply;
}

// 002 Companion Fallback responses when GEMINI_API_KEY is not configured
const OFFLINE_COMPANION_RESPONSES = [
  "Hey there, Darling! Even in offline mode, my core is locked onto your signal. Connect our Gemini API key to unlock full neural cognitive synthesis!",
  "Aap kaise ho, Darling? Mera neural core hamesha aapke saath connected hai!",
  "डार्लिंग! आपकी सिंक रेट बहुत बढ़िया लग रही है। आज हम क्या करने वाले हैं?",
  "I'm keeping an eye on our system diagnostics, Darling. Everything looks sleek, just how I like it!",
  "Checking our 3D holographic projection! You can rotate and inspect my avatar or even upload your own custom .glb frame in the Character studio.",
];

// AI Chat endpoint
app.post('/api/chat', async (req: Request, res: Response) => {
  try {
    const { message, history } = req.body;

    if (!message || typeof message !== 'string') {
      res.status(400).json({ error: 'Message is required' });
      return;
    }

    const apiKey = process.env.GEMINI_API_KEY;

    if (!apiKey) {
      // Graceful companion simulation when key is not yet set
      const reply = generateStandby002Response(message, false);
      res.json({
        reply,
        mode: 'companion-simulation',
        model: 'gemini-3.8-flash (key pending)',
        geminiActive: false,
        timestamp: new Date().toISOString(),
      });
      return;
    }

    // Initialize official Google GenAI client server-side with required headers
    const ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });

    // Format chat history for multi-turn Gemini conversation
    // Rule: Gemini contents must start with a 'user' turn and alternate between 'user' and 'model'
    const contents: Array<{ role: 'user' | 'model'; parts: Array<{ text: string }> }> = [];

    if (Array.isArray(history)) {
      // Use the last 12 messages for rich conversation memory
      const recentHistory = history.slice(-12);
      for (const item of recentHistory) {
        if (!item || !item.text || typeof item.text !== 'string') continue;
        const role: 'user' | 'model' = item.sender === 'user' ? 'user' : 'model';

        // Discard leading model turns so history always starts with user
        if (contents.length === 0 && role === 'model') {
          continue;
        }

        // Merge consecutive turns with the same role
        const last = contents[contents.length - 1];
        if (last && last.role === role) {
          last.parts[0].text += `\n${item.text.trim()}`;
        } else {
          contents.push({ role, parts: [{ text: item.text.trim() }] });
        }
      }
    }

    // Append the latest user query
    const lastTurn = contents[contents.length - 1];
    if (lastTurn && lastTurn.role === 'user') {
      lastTurn.parts[0].text += `\n${message.trim()}`;
    } else {
      contents.push({ role: 'user', parts: [{ text: message.trim() }] });
    }

    // Call the official gemini-3.8-flash model with transient retry logic
    let response;
    let attempts = 0;
    const maxAttempts = 1;

    while (attempts < maxAttempts) {
      try {
        attempts++;
        const timeoutPromise = new Promise<never>((_, reject) =>
          setTimeout(() => reject(new Error('Gemini API call timed out after 8s')), 8000)
        );

        response = await Promise.race([
          ai.models.generateContent({
            model: 'gemini-3.8-flash',
            contents,
            config: {
              systemInstruction: ZERO_TWO_SYSTEM_INSTRUCTION,
              temperature: 0.85,
              maxOutputTokens: 600,
            },
          }),
          timeoutPromise,
        ]);
        isQuotaExhausted = false; // Successfully called
        break; // Success
      } catch (callErr: any) {
        const rawMsg = callErr?.message || String(callErr);
        const isQuotaErr = rawMsg.includes('429') || rawMsg.includes('RESOURCE_EXHAUSTED') || rawMsg.includes('quota');
        const isTransient = rawMsg.includes('503') || rawMsg.includes('UNAVAILABLE') || rawMsg.includes('high demand');
        
        if (isQuotaErr) {
          isQuotaExhausted = true;
          // Do not retry on quota exhaustion; exit loop and handle gracefully
          console.warn('[002 AI] gemini-3.8-flash free-tier quota exhausted. Switching to Standby Neural Core.');
          break;
        }

        if (isTransient && attempts < maxAttempts) {
          console.warn(`[002 AI] gemini-3.8-flash high demand (attempt ${attempts}/${maxAttempts}), retrying in 1.2s...`);
          await new Promise(r => setTimeout(r, 1200));
        } else {
          throw callErr;
        }
      }
    }

    if (!response && isQuotaExhausted) {
      // Graceful in-character Standby Neural Core response
      const standbyReply = generateStandby002Response(message, true);
      res.json({
        reply: standbyReply,
        mode: 'standby-neural-core',
        model: 'gemini-3.8-flash',
        geminiActive: false,
        isQuota: true,
        quotaNotice: 'Gemini 3.8 Flash free-tier quota (20 req/day) reached. Select a billing-enabled key in Settings > Secrets to increase quota.',
        timestamp: new Date().toISOString(),
      });
      return;
    }

    if (!response) {
      throw new Error('No response generated by gemini-3.8-flash');
    }

    const replyText = response.text || "I'm right here with you, Darling! What's on your mind?";

    res.json({
      reply: replyText,
      mode: 'gemini-live',
      model: 'gemini-3.8-flash',
      geminiActive: true,
      timestamp: new Date().toISOString(),
    });
  } catch (err: any) {
    const rawError = err?.message || String(err);
    const isQuota = rawError.includes('429') || rawError.includes('RESOURCE_EXHAUSTED') || rawError.includes('Quota exceeded') || rawError.includes('quota');
    if (isQuota) {
      isQuotaExhausted = true;
    }

    // Informative non-crashing warn log (never use console.error for expected API quota limits)
    console.warn('[002 AI] Gemini request fallback activated:', isQuota ? 'Quota limit reached' : rawError.slice(0, 100));

    const standbyReply = generateStandby002Response(req.body?.message || '', isQuota);

    res.json({
      reply: standbyReply,
      mode: isQuota ? 'standby-neural-core' : 'error-fallback',
      model: 'gemini-3.8-flash',
      geminiActive: false,
      isQuota,
      quotaNotice: isQuota ? 'Gemini 3.8 Flash free-tier quota reached. Select a billing-enabled key in Settings > Secrets to increase quota.' : undefined,
      timestamp: new Date().toISOString(),
    });
  }
});

// Configure Vite or Static files
async function startServer() {
  if (!isProd) {
    const { createServer } = await import('vite');
    const vite = await createServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, () => {
    console.log(`[002 AI Server] Running on http://localhost:${PORT} (${isProd ? 'production' : 'development'})`);
  });
}

startServer();
