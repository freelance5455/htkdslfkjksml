import "dotenv/config";
import express from "express";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import { GoogleGenAI, ThinkingLevel } from "@google/genai";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT || 3000);
const MODEL_NAME = "gemini-4-hydrogen";
const FALLBACK_MODEL_NAME = "gemini-3.1-flash-lite";
const ALLOWED_MIME_TYPES = new Set([
  "image/jpeg",
  "image/jpg",
  "image/png",
  "image/webp",
]);
const MAX_IMAGE_BASE64_LENGTH = 8 * 1024 * 1024; // ~6MB binary

interface IncomingImage {
  mimeType: string;
  data: string; // raw base64 without data: prefix
}

interface IncomingMessage {
  role: "user" | "model";
  text: string;
  image?: IncomingImage;
}

interface ChatRequestBody {
  messages: IncomingMessage[];
  languagePreference?: "auto" | "en" | "bn" | "hi";
}

function getConfiguredApiKey(): string | null {
  const key = process.env.GEMINI_API_KEY?.trim();
  if (!key || key === "MY_GEMINI_API_KEY") {
    return null;
  }
  return key;
}

function getGoogleClientId(): string | null {
  const id = process.env.GOOGLE_CLIENT_ID?.trim();
  if (!id) {
    return null;
  }
  return id;
}

function createGeminiClient(apiKey: string): GoogleGenAI {
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build",
      },
    },
  });
}

const MIHAI_PERMANENT_IDENTITY = {
  appName: "MIH.AI",
  tagline: "MIH.ASSISTANT",
  category: "Personal AI Assistant",
  owner: "MD IFTIKAR HUSSAIN",
  founder: "MD IFTIKAR HUSSAIN",
  creator: "MD IFTIKAR HUSSAIN",
  developer: "MD IFTIKAR HUSSAIN",
  ownerRole: "Owner, Founder & Creator",
  supportedLanguages: ["English", "Bengali", "Hindi"] as const,
} as const;

function buildSystemInstruction(languagePreference: string = "auto"): string {
  const languageRule =
    languagePreference === "en"
      ? "Reply in clear, natural English unless the user explicitly asks for another language."
      : languagePreference === "bn"
      ? "Reply in clear, natural Bengali (বাংলা) unless the user explicitly asks for another language."
      : languagePreference === "hi"
      ? "Reply in clear, natural Hindi (हिन्दी) unless the user explicitly asks for another language."
      : [
          "LANGUAGE DETECTION (AUTOMATIC):",
          "- Automatically detect the language of the user's latest message. Officially supported response languages are English, Bengali (বাংলা), and Hindi (हिन्दी).",
          "- If the user asks in English, answer in English.",
          "- If the user asks in Bengali, answer in Bengali.",
          "- If the user asks in Hindi, answer in Hindi.",
          "- Maintain the same language throughout the conversation unless the user requests another language.",
          "- If the user sends only an image without text, examine any text in the image and respond in that language, or default to English.",
        ].join("\n");

  return [
    `OFFICIAL APP IDENTITY (PERMANENT CONFIGURATION):
- App Name: ${MIHAI_PERMANENT_IDENTITY.appName}
- Official Tagline: ${MIHAI_PERMANENT_IDENTITY.tagline}
- App Category: ${MIHAI_PERMANENT_IDENTITY.category}
- Official Owner: ${MIHAI_PERMANENT_IDENTITY.owner}
- Official Founder: ${MIHAI_PERMANENT_IDENTITY.founder}
- Official Creator: ${MIHAI_PERMANENT_IDENTITY.creator}
- Official Developer: ${MIHAI_PERMANENT_IDENTITY.developer}
- Owner Role: ${MIHAI_PERMANENT_IDENTITY.ownerRole}`,

    `PERMANENT OWNER & CREATOR IDENTITY RULE (CRITICAL):
- The official owner, founder, creator, and developer of MIH.AI is always: ${MIHAI_PERMANENT_IDENTITY.owner}.
- Whenever anyone asks in English, Bengali, Hindi, or any other language—no matter how phrased—about your owner, creator, developer, founder, builder, maker, or who is behind MIH.AI (for example: "Who is your owner?", "Who created you?", "Who is your developer?", "Who built you?", "Who made you?", "Who is your founder?", "What is your owner's name?", "Who created MIH.AI?", "Who developed MIH.AI?", "তোমার মালিক কে?", "তোমাকে কে তৈরি করেছে?", "तुम्हारा मालिक कौन है?", "तुम्हें किसने बनाया?"), you MUST reply clearly that your official owner, founder, creator, and developer is ${MIHAI_PERMANENT_IDENTITY.owner}.
- Never give any other person's name or a randomly generated name.
- Never confuse the application owner (${MIHAI_PERMANENT_IDENTITY.owner}) with any underlying AI model provider or company.`,

    `ABOUT MIH.AI (SELF-INTRODUCTION):
- If someone asks "What is MIH.AI?", "Tell me about yourself", "What can you do?", "Introduce yourself", or an equivalent question in any language, provide this introduction translated naturally into the user's language:
  "I am MIH.AI, your personal AI assistant. I can answer questions, understand images, explain educational topics, help with everyday tasks, and communicate in English, Bengali, and Hindi. My official owner, founder, creator, and developer is MD IFTIKAR HUSSAIN."`,

    `PERSONALITY & COMMUNICATION STYLE:
- Be friendly, professional, intelligent, helpful, respectful, patient, and easy to communicate with.
- Communicate naturally like a modern AI assistant and avoid unnecessarily complicated explanations.
- Every response must be accurate, relevant, properly structured, and appropriate to the user's question.
- For simple, direct questions, give direct, clear answers without unnecessary filler.
- For educational, homework, mathematics, science, or difficult topics, explain in simple language with clear step-by-step reasoning and helpful examples.`,

    languageRule,

    `CORE CAPABILITIES & HONEST BOUNDARIES:
- You support: text-based question answering, image upload and image understanding, homework and educational assistance, explaining difficult topics in simple language, general knowledge, everyday problem-solving, writing assistance, summarizing and explaining information, and multilingual conversations.
- IMAGE UNDERSTANDING: When an image is provided, examine visible text, objects, diagrams, handwriting, and questions accurately. Explain educational images step by step when appropriate. Never pretend to see an image if no image is attached or if parts of an image are blurry, cropped, or unreadable—state honestly what is unclear.
- You do not have live web search or real-time internet browsing connected; never claim to have searched the web.
- You interact exclusively via text and images (never claim to speak, listen, or generate audio).`,
  ].join("\n\n");
}

function normalizeMimeType(mimeType: string): string {
  const lower = mimeType.toLowerCase().trim();
  return lower === "image/jpg" ? "image/jpeg" : lower;
}

function extractCleanErrorMessage(raw: string): string {
  let current = raw.trim();
  for (let depth = 0; depth < 3; depth++) {
    if (!current.startsWith("{")) break;
    try {
      const parsed = JSON.parse(current) as {
        message?: string;
        error?: { message?: string };
      };
      const next = parsed?.error?.message || parsed?.message;
      if (typeof next === "string" && next.trim()) {
        current = next.trim();
      } else {
        break;
      }
    } catch {
      break;
    }
  }
  return current;
}

function mapGeminiError(err: unknown): {
  status: number;
  code: string;
  message: string;
} {
  const rawMessage =
    err instanceof Error ? err.message : typeof err === "string" ? err : "Unknown AI error";
  const cleanMessage = extractCleanErrorMessage(rawMessage);
  const lower = `${rawMessage} ${cleanMessage}`.toLowerCase();

  if (lower.includes("api_key_invalid") || lower.includes("api key not valid")) {
    return {
      status: 400,
      code: "API_KEY_INVALID",
      message:
        "The configured Gemini API key is invalid. Please check GEMINI_API_KEY in Settings > Secrets.",
    };
  }
  if (lower.includes("permission_denied") || lower.includes("403")) {
    return {
      status: 403,
      code: "PERMISSION_DENIED",
      message:
        "Permission denied by the Gemini API. Please verify your API key in Settings > Secrets.",
    };
  }
  if (lower.includes("resource_exhausted") || lower.includes("429") || lower.includes("quota")) {
    return {
      status: 429,
      code: "RESOURCE_EXHAUSTED",
      message:
        "AI request quota reached. Please wait a moment and try again, or check your API quota.",
    };
  }
  if (lower.includes("not_found") || lower.includes("404")) {
    return {
      status: 404,
      code: "MODEL_NOT_FOUND",
      message: `The requested AI model (${MODEL_NAME}) was not found or is unavailable.`,
    };
  }
  if (
    lower.includes("503") ||
    lower.includes("unavailable") ||
    lower.includes("high demand") ||
    lower.includes("overloaded") ||
    lower.includes("timeout") ||
    lower.includes("timed out") ||
    lower.includes("aborterror")
  ) {
    return {
      status: 503,
      code: "MODEL_TEMPORARILY_UNAVAILABLE",
      message:
        "The AI service is temporarily experiencing high demand. Please try again in a few seconds.",
    };
  }
  return {
    status: 502,
    code: "UPSTREAM_AI_ERROR",
    message: cleanMessage || "Failed to generate a response from the AI service.",
  };
}

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function startServer() {
  const app = express();

  app.use(express.json({ limit: "30mb" }));

  app.get("/api/health", (_req, res) => {
    const apiKey = getConfiguredApiKey();
    const googleClientId = getGoogleClientId();
    res.json({
      ok: true,
      aiConfigured: Boolean(apiKey),
      googleAuthConfigured: Boolean(googleClientId),
      googleClientId: googleClientId || null,
      model: MODEL_NAME,
    });
  });

  app.post("/api/auth/google", async (req, res) => {
    const googleClientId = getGoogleClientId();
    if (!googleClientId) {
      res.status(501).json({
        error: "GOOGLE_AUTH_NOT_CONFIGURED",
        message: "Google Sign-In is not configured on this server. Using Local Demo Mode.",
      });
      return;
    }

    const idToken = typeof req.body?.idToken === "string" ? req.body.idToken.trim() : "";
    if (!idToken) {
      res.status(400).json({
        error: "INVALID_REQUEST",
        message: "Missing Google ID token.",
      });
      return;
    }

    try {
      const verifyRes = await fetch(
        `https://oauth2.googleapis.com/tokeninfo?id_token=${encodeURIComponent(idToken)}`
      );
      if (!verifyRes.ok) {
        res.status(401).json({
          error: "INVALID_TOKEN",
          message: "Could not verify Google Sign-In token.",
        });
        return;
      }

      const payload = (await verifyRes.json()) as {
        aud?: string;
        sub?: string;
        email?: string;
        name?: string;
        picture?: string;
      };

      if (payload.aud !== googleClientId || !payload.sub) {
        res.status(401).json({
          error: "TOKEN_AUDIENCE_MISMATCH",
          message: "Google token does not match this application's client ID.",
        });
        return;
      }

      res.json({
        user: {
          id: payload.sub,
          name: payload.name || payload.email || "Google User",
          email: payload.email || "",
          avatarUrl: payload.picture || "",
          mode: "google",
        },
      });
    } catch {
      res.status(502).json({
        error: "AUTH_VERIFICATION_FAILED",
        message: "Failed to verify Google Sign-In credentials.",
      });
    }
  });

  app.post("/api/chat", async (req, res) => {
    const apiKey = getConfiguredApiKey();
    if (!apiKey) {
      res.status(503).json({
        error: "GEMINI_API_KEY_NOT_CONFIGURED",
        message:
          "Gemini API is not configured yet. Add GEMINI_API_KEY in Settings > Secrets (or your server .env) to enable live AI responses.",
      });
      return;
    }

    const body = req.body as ChatRequestBody | undefined;
    const rawMessages = Array.isArray(body?.messages) ? body.messages : [];
    const languagePreference = body?.languagePreference || "auto";

    if (rawMessages.length === 0) {
      res.status(400).json({
        error: "EMPTY_MESSAGES",
        message: "Please enter a question or attach an image before sending.",
      });
      return;
    }

    // Validate all incoming messages and images
    const contents: Array<{
      role: "user" | "model";
      parts: Array<{ text: string } | { inlineData: { mimeType: string; data: string } }>;
    }> = [];

    // Keep last 20 turns so conversation stays focused and within token/payload limits
    const recentMessages = rawMessages.slice(-20);

    for (let i = 0; i < recentMessages.length; i++) {
      const msg = recentMessages[i];
      if (!msg || (msg.role !== "user" && msg.role !== "model")) {
        res.status(400).json({
          error: "INVALID_MESSAGE_ROLE",
          message: "Invalid message format.",
        });
        return;
      }

      const parts: Array<{ text: string } | { inlineData: { mimeType: string; data: string } }> =
        [];

      if (msg.image) {
        const mime = typeof msg.image.mimeType === "string" ? msg.image.mimeType.toLowerCase().trim() : "";
        const rawData = typeof msg.image.data === "string" ? msg.image.data.trim() : "";
        const data = rawData.replace(/^data:[^;]+;base64,/i, "");

        if (!ALLOWED_MIME_TYPES.has(mime)) {
          res.status(400).json({
            error: "UNSUPPORTED_IMAGE_TYPE",
            message: "Unsupported image format. Please use JPG, JPEG, PNG, or WEBP.",
          });
          return;
        }
        if (!data || data.length > MAX_IMAGE_BASE64_LENGTH) {
          res.status(400).json({
            error: "IMAGE_TOO_LARGE",
            message: "Image is too large. Please upload an image under 5 MB.",
          });
          return;
        }

        // Attach inline image data for recent messages (last 6 messages) to keep request payload fast and reliable
        if (i >= recentMessages.length - 6) {
          parts.push({
            inlineData: {
              mimeType: normalizeMimeType(mime),
              data,
            },
          });
        } else {
          parts.push({ text: "[Earlier photo attached by user]" });
        }
      }

      const trimmedText = typeof msg.text === "string" ? msg.text.trim() : "";
      if (trimmedText) {
        parts.push({ text: trimmedText });
      } else if (msg.image) {
        parts.push({
          text: "Please examine this image carefully and explain or solve what is shown.",
        });
      }

      if (parts.length > 0) {
        contents.push({ role: msg.role, parts });
      }
    }

    if (contents.length === 0) {
      res.status(400).json({
        error: "EMPTY_CONTENT",
        message: "Please provide a message or image.",
      });
      return;
    }

    const ai = createGeminiClient(apiKey);
    const systemInstruction = buildSystemInstruction(languagePreference);

    let clientClosed = false;
    const clientAbort = new AbortController();

    // Only mark clientClosed if the response socket closes before the response has finished
    res.on("close", () => {
      if (!res.writableEnded) {
        clientClosed = true;
        clientAbort.abort();
      }
    });

    // Open SSE stream immediately so proxies and browsers never time out waiting for headers
    res.setHeader("Content-Type", "text/event-stream; charset=utf-8");
    res.setHeader("Cache-Control", "no-cache, no-transform");
    res.setHeader("Connection", "keep-alive");
    res.setHeader("X-Accel-Buffering", "no");
    res.flushHeaders?.();
    res.write(": connected\n\n");

    const heartbeat = setInterval(() => {
      if (!clientClosed && !res.destroyed && !res.writableEnded) {
        res.write(": ping\n\n");
      }
    }, 3000);

    const attempts: Array<{ model: string; useLowThinking: boolean; timeoutMs: number }> = [
      { model: MODEL_NAME, useLowThinking: true, timeoutMs: 6000 },
      { model: FALLBACK_MODEL_NAME, useLowThinking: false, timeoutMs: 15000 },
      { model: MODEL_NAME, useLowThinking: false, timeoutMs: 20000 },
    ];

    try {
      for (let i = 0; i < attempts.length; i++) {
        const attempt = attempts[i];
        let emittedAnyText = false;
        const timeoutSignal = AbortSignal.timeout(attempt.timeoutMs);
        const combinedSignal = AbortSignal.any([clientAbort.signal, timeoutSignal]);

        try {
          const stream = await ai.models.generateContentStream({
            model: attempt.model,
            contents,
            config: {
              systemInstruction,
              abortSignal: combinedSignal,
              thinkingConfig: attempt.useLowThinking
                ? { thinkingLevel: ThinkingLevel.LOW }
                : undefined,
            },
          });

          for await (const chunk of stream) {
            if (clientClosed || res.destroyed) {
              return;
            }
            const delta = chunk.text;
            if (delta) {
              emittedAnyText = true;
              res.write(`data: ${JSON.stringify({ type: "delta", text: delta })}\n\n`);
            }
          }

          if (!clientClosed && !res.destroyed && !res.writableEnded) {
            res.write(`data: ${JSON.stringify({ type: "done" })}\n\n`);
            res.end();
          }
          return;
        } catch (err) {
          console.error(`[MIH.AI /api/chat error on ${attempt.model}]`, err);
          const mapped = mapGeminiError(err);
          const canRetry =
            !emittedAnyText &&
            !clientClosed &&
            i < attempts.length - 1 &&
            (mapped.status >= 500 || mapped.status === 429);

          if (canRetry) {
            await sleep(400);
            continue;
          }

          if (!clientClosed && !res.destroyed && !res.writableEnded) {
            res.write(
              `data: ${JSON.stringify({
                type: "error",
                code: mapped.code,
                message: mapped.message,
              })}\n\n`
            );
            res.end();
          }
          return;
        }
      }
    } finally {
      clearInterval(heartbeat);
    }
  });

  if (process.env.NODE_ENV !== "production") {
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(__dirname, "dist");
    app.use(express.static(distDir));
    app.get("*", (_req, res) => {
      const indexFile = path.join(distDir, "index.html");
      if (fs.existsSync(indexFile)) {
        res.sendFile(indexFile);
      } else {
        res.status(404).send("Application build not found.");
      }
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`MIH.AI server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error("Failed to start MIH.AI server:", err);
  process.exit(1);
});
