import express from 'express';
import fs from 'fs';
import http from 'http';
import path from 'path';
import { fileURLToPath } from 'url';
import zlib from 'zlib';
import { WebSocketServer, WebSocket } from 'ws';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT || 3000);
const isProd = process.env.NODE_ENV === 'production';

interface RemotePlayerState {
  id: string;
  name: string;
  x: number;
  y: number;
  z: number;
  yaw: number;
  anim: string;
  level: number;
  hp: number;
  maxHp: number;
  hairColor: string;
  skinColor: string;
  armorColor: string;
  weaponType: string;
  mounted: boolean;
}

interface RoomState {
  code: string;
  players: Map<string, RemotePlayerState>;
  clients: Map<string, WebSocket>;
  bossHp: Record<string, number>;
  structures: Array<{ id: string; type: string; x: number; y: number; z: number; ry: number; owner: string }>;
}

const rooms = new Map<string, RoomState>();

function getOrCreateRoom(code: string): RoomState {
  const normalized = code.toUpperCase().slice(0, 16) || 'REALM-1';
  let room = rooms.get(normalized);
  if (!room) {
    room = {
      code: normalized,
      players: new Map(),
      clients: new Map(),
      bossHp: {},
      structures: [],
    };
    rooms.set(normalized, room);
  }
  return room;
}

function broadcastToRoom(room: RoomState, payload: unknown, excludeId?: string) {
  const raw = JSON.stringify(payload);
  for (const [cid, ws] of room.clients.entries()) {
    if (cid !== excludeId && ws.readyState === WebSocket.OPEN) {
      ws.send(raw);
    }
  }
}

const CRC_TABLE = (() => {
  const t = new Uint32Array(256);
  for (let i = 0; i < 256; i++) {
    let c = i;
    for (let k = 0; k < 8; k++) {
      c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    }
    t[i] = c >>> 0;
  }
  return t;
})();

function crc32(buf: Buffer): number {
  let c = 0xffffffff;
  for (let i = 0; i < buf.length; i++) {
    c = CRC_TABLE[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  }
  return (c ^ 0xffffffff) >>> 0;
}

const SKIP_DIRS = new Set(['node_modules', '.git', '.aistudio', 'dist', 'dev-dist']);

function collectProjectFiles(rootDir: string, relDir = ''): Array<{ relPath: string; data: Buffer }> {
  const absDir = relDir ? path.join(rootDir, relDir) : rootDir;
  const entries = fs.readdirSync(absDir, { withFileTypes: true });
  const results: Array<{ relPath: string; data: Buffer }> = [];

  for (const entry of entries) {
    if (entry.name.startsWith('.DS_Store') || entry.name.endsWith('.zip')) continue;
    const nextRel = relDir ? `${relDir}/${entry.name}` : entry.name;
    if (entry.isDirectory()) {
      if (SKIP_DIRS.has(entry.name)) continue;
      results.push(...collectProjectFiles(rootDir, nextRel));
    } else if (entry.isFile()) {
      results.push({
        relPath: `fantasy-world-rpg/${nextRel}`,
        data: fs.readFileSync(path.join(rootDir, nextRel)),
      });
    }
  }
  return results;
}

function buildProjectZipBuffer(rootDir: string): Buffer {
  const files = collectProjectFiles(rootDir);
  const runGuide = [
    'Fantasy World RPG — Quick Start Guide',
    '======================================',
    '1. Install Node.js 20+ (https://nodejs.org/)',
    '2. Open terminal inside this folder and run:',
    '   npm install',
    '   npm run dev',
    '3. Open http://localhost:3000 in Google Chrome.',
    '',
    'For production build:',
    '   npm run build && npm start',
    '',
  ].join('\n');
  files.push({
    relPath: 'fantasy-world-rpg/RUN_GAME.txt',
    data: Buffer.from(runGuide, 'utf8'),
  });

  const localParts: Buffer[] = [];
  const centralParts: Buffer[] = [];
  let offset = 0;

  for (const file of files) {
    const nameBuf = Buffer.from(file.relPath, 'utf8');
    const raw = file.data;
    const compressed = zlib.deflateRawSync(raw);
    const useStore = compressed.length >= raw.length;
    const payload = useStore ? raw : compressed;
    const method = useStore ? 0 : 8;
    const crc = crc32(raw);

    const localHeader = Buffer.alloc(30);
    localHeader.writeUInt32LE(0x04034b50, 0);
    localHeader.writeUInt16LE(20, 4);
    localHeader.writeUInt16LE(0x0800, 6);
    localHeader.writeUInt16LE(method, 8);
    localHeader.writeUInt16LE(0, 10);
    localHeader.writeUInt16LE(0x5421, 12);
    localHeader.writeUInt32LE(crc, 14);
    localHeader.writeUInt32LE(payload.length, 18);
    localHeader.writeUInt32LE(raw.length, 22);
    localHeader.writeUInt16LE(nameBuf.length, 26);
    localHeader.writeUInt16LE(0, 28);

    localParts.push(localHeader, nameBuf, payload);

    const centralHeader = Buffer.alloc(46);
    centralHeader.writeUInt32LE(0x02014b50, 0);
    centralHeader.writeUInt16LE(20, 4);
    centralHeader.writeUInt16LE(20, 6);
    centralHeader.writeUInt16LE(0x0800, 8);
    centralHeader.writeUInt16LE(method, 10);
    centralHeader.writeUInt16LE(0, 12);
    centralHeader.writeUInt16LE(0x5421, 14);
    centralHeader.writeUInt32LE(crc, 16);
    centralHeader.writeUInt32LE(payload.length, 20);
    centralHeader.writeUInt32LE(raw.length, 24);
    centralHeader.writeUInt16LE(nameBuf.length, 28);
    centralHeader.writeUInt16LE(0, 30);
    centralHeader.writeUInt16LE(0, 32);
    centralHeader.writeUInt16LE(0, 34);
    centralHeader.writeUInt16LE(0, 36);
    centralHeader.writeUInt32LE(0, 38);
    centralHeader.writeUInt32LE(offset, 42);

    centralParts.push(centralHeader, nameBuf);
    offset += localHeader.length + nameBuf.length + payload.length;
  }

  const centralSize = centralParts.reduce((acc, b) => acc + b.length, 0);
  const eocd = Buffer.alloc(22);
  eocd.writeUInt32LE(0x06054b50, 0);
  eocd.writeUInt16LE(0, 4);
  eocd.writeUInt16LE(0, 6);
  eocd.writeUInt16LE(files.length, 8);
  eocd.writeUInt16LE(files.length, 10);
  eocd.writeUInt32LE(centralSize, 12);
  eocd.writeUInt32LE(offset, 16);
  eocd.writeUInt16LE(0, 20);

  return Buffer.concat([...localParts, ...centralParts, eocd]);
}

async function startServer() {
  const app = express();
  app.use(express.json());

  app.get('/api/health', (_req, res) => {
    res.json({ ok: true, rooms: rooms.size });
  });

  app.get('/api/rooms', (_req, res) => {
    const list = Array.from(rooms.values()).map((r) => ({
      code: r.code,
      playerCount: r.players.size,
    }));
    res.json({ rooms: list });
  });

  app.get('/api/download-game.zip', (_req, res) => {
    try {
      const zipBuf = buildProjectZipBuffer(__dirname);
      res.setHeader('Content-Type', 'application/zip');
      res.setHeader('Content-Disposition', 'attachment; filename="fantasy-world-rpg.zip"');
      res.setHeader('Content-Length', String(zipBuf.length));
      res.setHeader('Cache-Control', 'no-store');
      res.send(zipBuf);
    } catch (err) {
      console.error('ZIP build failed:', err);
      res.status(500).json({ error: 'Failed to package game archive' });
    }
  });

  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(__dirname, 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  const server = http.createServer(app);
  const wss = new WebSocketServer({ server, path: '/ws' });

  wss.on('connection', (ws) => {
    let clientId = `p_${Math.random().toString(36).slice(2, 10)}`;
    let currentRoom: RoomState | null = null;

    ws.on('message', (data) => {
      let msg: Record<string, unknown>;
      try {
        msg = JSON.parse(String(data));
      } catch {
        return;
      }

      const type = String(msg.type || '');
      if (type === 'room:join') {
        const roomCode = String(msg.roomCode || 'REALM-1');
        const player = msg.player as RemotePlayerState | undefined;
        if (!player) return;

        // Leave previous room if any
        if (currentRoom) {
          currentRoom.players.delete(clientId);
          currentRoom.clients.delete(clientId);
          broadcastToRoom(currentRoom, { type: 'player:leave', id: clientId });
        }

        currentRoom = getOrCreateRoom(roomCode);
        const joinedPlayer: RemotePlayerState = { ...player, id: clientId };
        currentRoom.players.set(clientId, joinedPlayer);
        currentRoom.clients.set(clientId, ws);

        // Send initial room state to joining player
        ws.send(
          JSON.stringify({
            type: 'room:init',
            selfId: clientId,
            roomCode: currentRoom.code,
            players: Array.from(currentRoom.players.values()),
            bossHp: currentRoom.bossHp,
            structures: currentRoom.structures,
          })
        );

        // Notify existing players
        broadcastToRoom(currentRoom, { type: 'player:join', player: joinedPlayer }, clientId);
        return;
      }

      if (!currentRoom) return;

      if (type === 'player:state') {
        const prev = currentRoom.players.get(clientId);
        if (!prev) return;
        const updated: RemotePlayerState = {
          ...prev,
          x: Number(msg.x ?? prev.x),
          y: Number(msg.y ?? prev.y),
          z: Number(msg.z ?? prev.z),
          yaw: Number(msg.yaw ?? prev.yaw),
          anim: String(msg.anim ?? prev.anim),
          level: Number(msg.level ?? prev.level),
          hp: Number(msg.hp ?? prev.hp),
          maxHp: Number(msg.maxHp ?? prev.maxHp),
          weaponType: String(msg.weaponType ?? prev.weaponType),
          mounted: Boolean(msg.mounted ?? prev.mounted),
        };
        currentRoom.players.set(clientId, updated);
        broadcastToRoom(currentRoom, { type: 'player:state', player: updated }, clientId);
      } else if (type === 'player:action') {
        broadcastToRoom(
          currentRoom,
          {
            type: 'player:action',
            id: clientId,
            action: msg.action,
            element: msg.element,
            spellId: msg.spellId,
            tx: msg.tx,
            ty: msg.ty,
            tz: msg.tz,
          },
          clientId
        );
      } else if (type === 'chat:message') {
        const sender = currentRoom.players.get(clientId);
        const text = String(msg.text || '').trim().slice(0, 180);
        if (!text) return;
        const chatPayload = {
          type: 'chat:message',
          id: `${Date.now()}_${clientId}`,
          senderId: clientId,
          senderName: sender?.name || 'Adventurer',
          text,
          timestamp: Date.now(),
        };
        broadcastToRoom(currentRoom, chatPayload);
      } else if (type === 'boss:damage') {
        const bossId = String(msg.bossId || '');
        const newHp = Math.max(0, Number(msg.hp ?? 0));
        if (bossId) {
          currentRoom.bossHp[bossId] = newHp;
          broadcastToRoom(currentRoom, { type: 'boss:sync', bossId, hp: newHp }, clientId);
        }
      } else if (type === 'world:structure') {
        const s = msg.structure as { id: string; type: string; x: number; y: number; z: number; ry: number } | undefined;
        if (s && s.id && !currentRoom.structures.some((item) => item.id === s.id)) {
          const sender = currentRoom.players.get(clientId);
          const entry = { ...s, owner: sender?.name || 'Player' };
          currentRoom.structures.push(entry);
          broadcastToRoom(currentRoom, { type: 'world:structure', structure: entry }, clientId);
        }
      }
    });

    ws.on('close', () => {
      if (currentRoom) {
        currentRoom.players.delete(clientId);
        currentRoom.clients.delete(clientId);
        broadcastToRoom(currentRoom, { type: 'player:leave', id: clientId });
        if (currentRoom.players.size === 0 && currentRoom.structures.length === 0) {
          rooms.delete(currentRoom.code);
        }
      }
    });
  });

  server.listen(PORT, '0.0.0.0', () => {
    console.log(`Fantasy World RPG server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
