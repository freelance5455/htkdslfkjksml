import express from 'express';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import dotenv from 'dotenv';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Setup Gemini API client
// Prefer valid environment variable, fallback to user provided key
const envKey = process.env.GEMINI_API_KEY;
const isValidEnvKey = Boolean(envKey && envKey !== 'MY_GEMINI_API_KEY' && envKey.trim().length > 0);
const GEMINI_API_KEY = isValidEnvKey ? (envKey as string) : 'AQ.Ab8RN6L9EqYCVmuiykNS-ztKzOuo5z2PPNoROZQ-g084h1hS1Q';

const ai = new GoogleGenAI({
  apiKey: GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

// Database file setup
const DATA_DIR = path.resolve(__dirname, 'data');
const DB_FILE = path.join(DATA_DIR, 'sosiska-db.json');

interface UserRecord {
  id: string;
  username: string;
  email: string;
  displayName: string;
  salt: string;
  hash: string;
  avatar: string;
  bio?: string;
  theme?: string;
  createdAt: string;
}

interface MessageRecord {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: string;
  mode?: string;
}

interface ChatRecord {
  id: string;
  userId: string;
  title: string;
  mode: string;
  createdAt: string;
  updatedAt: string;
  messages: MessageRecord[];
}

interface DatabaseSchema {
  users: Record<string, UserRecord>; // userId -> UserRecord
  tokens: Record<string, string>;    // token -> userId
  chats: Record<string, ChatRecord>; // chatId -> ChatRecord
}

// In-memory DB with disk persistence
let db: DatabaseSchema = {
  users: {},
  tokens: {},
  chats: {},
};

function ensureDataDir() {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
  if (fs.existsSync(DB_FILE)) {
    try {
      const content = fs.readFileSync(DB_FILE, 'utf-8');
      db = JSON.parse(content);
    } catch (e) {
      console.warn('Failed to parse existing DB file, initializing fresh:', e);
    }
  } else {
    // Seed default guest/demo user for instant testing if desired
    const demoSalt = crypto.randomBytes(16).toString('hex');
    const demoHash = hashPassword('demo1234', demoSalt);
    const demoUser: UserRecord = {
      id: 'usr_demo_sosiska',
      username: 'guest_sosiska',
      email: 'guest@sosiska.ai',
      displayName: 'Гость Сосиски',
      salt: demoSalt,
      hash: demoHash,
      avatar: '🌭',
      bio: 'Тестовый аккаунт исследователя нейросети Sosiska AI',
      theme: 'dark',
      createdAt: new Date().toISOString(),
    };
    db.users[demoUser.id] = demoUser;
    saveDb();
  }
}

function saveDb() {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2), 'utf-8');
  } catch (err) {
    console.error('Error saving database:', err);
  }
}

function hashPassword(password: string, salt: string): string {
  return crypto.pbkdf2Sync(password, salt, 10000, 64, 'sha512').toString('hex');
}

function generateToken(): string {
  return crypto.randomBytes(32).toString('hex');
}

ensureDataDir();

const app = express();
const PORT = Number(process.env.PORT) || 3000;

app.use(express.json({ limit: '10mb' }));

// Auth middleware helper
function getUserFromRequest(req: express.Request): UserRecord | null {
  const authHeader = req.headers.authorization;
  if (!authHeader) return null;
  const token = authHeader.replace(/^Bearer\s+/i, '').trim();
  const userId = db.tokens[token];
  if (!userId) return null;
  return db.users[userId] || null;
}

// ==================== AUTH ROUTES ====================

// Register
app.post('/api/auth/register', (req, res) => {
  const { username, email, password, displayName, avatar, bio } = req.body;

  if (!username || !password) {
    return res.status(400).json({ error: 'Имя пользователя и пароль обязательны' });
  }

  const cleanUsername = String(username).trim().toLowerCase();
  if (cleanUsername.length < 3) {
    return res.status(400).json({ error: 'Логин должен содержать не менее 3 символов' });
  }

  if (String(password).length < 4) {
    return res.status(400).json({ error: 'Пароль должен содержать не менее 4 символов' });
  }

  // Check if username or email already exists
  const existingUser = Object.values(db.users).find(
    (u) => u.username.toLowerCase() === cleanUsername || (email && u.email.toLowerCase() === String(email).trim().toLowerCase())
  );

  if (existingUser) {
    return res.status(409).json({ error: 'Пользователь с таким логином или email уже существует' });
  }

  const userId = `usr_${crypto.randomBytes(8).toString('hex')}`;
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = hashPassword(password, salt);

  const newUser: UserRecord = {
    id: userId,
    username: cleanUsername,
    email: email ? String(email).trim().toLowerCase() : `${cleanUsername}@sosiska.local`,
    displayName: displayName && String(displayName).trim() ? String(displayName).trim() : cleanUsername,
    salt,
    hash,
    avatar: avatar || '🌭',
    bio: bio || 'Новый пользователь нейросети Sosiska AI',
    theme: 'dark',
    createdAt: new Date().toISOString(),
  };

  db.users[userId] = newUser;

  // Generate session token
  const token = generateToken();
  db.tokens[token] = userId;
  saveDb();

  // Create welcome chat
  const welcomeChatId = `chat_${crypto.randomBytes(8).toString('hex')}`;
  const welcomeChat: ChatRecord = {
    id: welcomeChatId,
    userId: userId,
    title: 'Знакомство с Sosiska AI 🌭',
    mode: 'classic',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    messages: [
      {
        id: `msg_${crypto.randomBytes(6).toString('hex')}`,
        role: 'assistant',
        content: `Привет, **${newUser.displayName}**! 🌭\n\nЯ — **Sosiska AI**, твоя личная умная нейросеть. Рада знакомству!\n\nВот что я умею:\n- 🚀 Отвечать на любые вопросы, объяснять сложные концепции и писать код\n- 🧠 Глубоко рассуждать и анализировать факты в режиме **Сосиска Про**\n- 🎨 Придумывать креативные тексты, стихи и идеи в режиме **Креатив**\n- 💻 Программировать и отлаживать решения в режиме **Кодер**\n- ⚡ Быстро выжимать суть в режиме **Турбо**\n\nЗадай мне любой вопрос или выбери одну из подсказок ниже!`,
        timestamp: new Date().toISOString(),
        mode: 'classic',
      },
    ],
  };
  db.chats[welcomeChatId] = welcomeChat;
  saveDb();

  return res.json({
    token,
    user: {
      id: newUser.id,
      username: newUser.username,
      email: newUser.email,
      displayName: newUser.displayName,
      avatar: newUser.avatar,
      bio: newUser.bio,
      theme: newUser.theme,
      createdAt: newUser.createdAt,
    },
  });
});

// Login
app.post('/api/auth/login', (req, res) => {
  const { login, password } = req.body;

  if (!login || !password) {
    return res.status(400).json({ error: 'Введите логин и пароль' });
  }

  const cleanLogin = String(login).trim().toLowerCase();
  const user = Object.values(db.users).find(
    (u) => u.username.toLowerCase() === cleanLogin || u.email.toLowerCase() === cleanLogin
  );

  if (!user) {
    return res.status(401).json({ error: 'Неверный логин или пароль' });
  }

  const checkHash = hashPassword(password, user.salt);
  if (checkHash !== user.hash) {
    return res.status(401).json({ error: 'Неверный логин или пароль' });
  }

  const token = generateToken();
  db.tokens[token] = user.id;
  saveDb();

  return res.json({
    token,
    user: {
      id: user.id,
      username: user.username,
      email: user.email,
      displayName: user.displayName,
      avatar: user.avatar,
      bio: user.bio,
      theme: user.theme,
      createdAt: user.createdAt,
    },
  });
});

// Get current user info
app.get('/api/auth/me', (req, res) => {
  const user = getUserFromRequest(req);
  if (!user) {
    return res.status(401).json({ error: 'Не авторизован' });
  }

  // Count user statistics
  const userChats = Object.values(db.chats).filter((c) => c.userId === user.id);
  const totalMessages = userChats.reduce((acc, c) => acc + (c.messages ? c.messages.length : 0), 0);

  return res.json({
    user: {
      id: user.id,
      username: user.username,
      email: user.email,
      displayName: user.displayName,
      avatar: user.avatar,
      bio: user.bio,
      theme: user.theme,
      createdAt: user.createdAt,
      stats: {
        totalChats: userChats.length,
        totalMessages,
      },
    },
  });
});

// Update Profile
app.put('/api/auth/profile', (req, res) => {
  const user = getUserFromRequest(req);
  if (!user) {
    return res.status(401).json({ error: 'Не авторизован' });
  }

  const { displayName, avatar, bio, theme, newPassword } = req.body;

  if (displayName) user.displayName = String(displayName).trim().slice(0, 50);
  if (avatar) user.avatar = String(avatar).trim().slice(0, 10);
  if (bio !== undefined) user.bio = String(bio).trim().slice(0, 200);
  if (theme) user.theme = theme;

  if (newPassword && String(newPassword).length >= 4) {
    user.salt = crypto.randomBytes(16).toString('hex');
    user.hash = hashPassword(newPassword, user.salt);
  }

  db.users[user.id] = user;
  saveDb();

  return res.json({
    success: true,
    user: {
      id: user.id,
      username: user.username,
      email: user.email,
      displayName: user.displayName,
      avatar: user.avatar,
      bio: user.bio,
      theme: user.theme,
      createdAt: user.createdAt,
    },
  });
});

// Logout
app.post('/api/auth/logout', (req, res) => {
  const authHeader = req.headers.authorization;
  if (authHeader) {
    const token = authHeader.replace(/^Bearer\s+/i, '').trim();
    delete db.tokens[token];
    saveDb();
  }
  return res.json({ success: true });
});

// ==================== ADMIN PANEL ROUTES ====================

const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'admin2004';
const adminTokens = new Set<string>();

function isAdminAuthorized(req: express.Request): boolean {
  const authHeader = req.headers.authorization;
  if (!authHeader) return false;
  const token = authHeader.replace(/^Bearer\s+/i, '').trim();
  return adminTokens.has(token);
}

// Admin login
app.post('/api/admin/login', (req, res) => {
  const { password } = req.body;
  if (!password || String(password).trim() !== ADMIN_PASSWORD) {
    return res.status(401).json({ error: 'Неверный пароль администратора' });
  }

  const token = `admin_${crypto.randomBytes(24).toString('hex')}`;
  adminTokens.add(token);
  return res.json({ success: true, adminToken: token });
});

// Admin verify session
app.get('/api/admin/verify', (req, res) => {
  if (!isAdminAuthorized(req)) {
    return res.status(401).json({ error: 'Не авторизован как администратор' });
  }
  return res.json({ success: true });
});

// Admin list all users
app.get('/api/admin/users', (req, res) => {
  if (!isAdminAuthorized(req)) {
    return res.status(401).json({ error: 'Доступ запрещен' });
  }

  const usersList = Object.values(db.users).map((u) => {
    const userChats = Object.values(db.chats).filter((c) => c.userId === u.id);
    const totalMessages = userChats.reduce((acc, c) => acc + (c.messages ? c.messages.length : 0), 0);

    return {
      id: u.id,
      username: u.username,
      email: u.email,
      displayName: u.displayName,
      avatar: u.avatar,
      bio: u.bio,
      theme: u.theme,
      createdAt: u.createdAt,
      stats: {
        totalChats: userChats.length,
        totalMessages,
      },
    };
  });

  return res.json({ users: usersList });
});

// Admin delete a user profile
app.delete('/api/admin/users/:userId', (req, res) => {
  if (!isAdminAuthorized(req)) {
    return res.status(401).json({ error: 'Доступ запрещен' });
  }

  const { userId } = req.params;
  const targetUser = db.users[userId];

  if (!targetUser) {
    return res.status(404).json({ error: 'Пользователь не найден' });
  }

  const deletedUsername = targetUser.username;

  // 1. Delete user from db.users
  delete db.users[userId];

  // 2. Delete user's active session tokens
  for (const [token, uid] of Object.entries(db.tokens)) {
    if (uid === userId) {
      delete db.tokens[token];
    }
  }

  // 3. Delete all chats belonging to this user
  for (const [chatId, chat] of Object.entries(db.chats)) {
    if (chat.userId === userId) {
      delete db.chats[chatId];
    }
  }

  saveDb();

  return res.json({
    success: true,
    message: `Профиль пользователя @${deletedUsername} успешно удален из системы`,
  });
});

// Admin system statistics
app.get('/api/admin/stats', (req, res) => {
  if (!isAdminAuthorized(req)) {
    return res.status(401).json({ error: 'Доступ запрещен' });
  }

  const totalUsers = Object.keys(db.users).length;
  const totalChats = Object.keys(db.chats).length;
  const totalMessages = Object.values(db.chats).reduce((acc, c) => acc + (c.messages ? c.messages.length : 0), 0);
  const activeSessions = Object.keys(db.tokens).length;

  return res.json({
    stats: {
      totalUsers,
      totalChats,
      totalMessages,
      activeSessions,
      serverTime: new Date().toISOString(),
    },
  });
});

// ==================== CHAT ROUTES ====================

// List chats for current user
app.get('/api/chats', (req, res) => {
  const user = getUserFromRequest(req);
  if (!user) {
    return res.status(401).json({ error: 'Не авторизован' });
  }

  const chats = Object.values(db.chats)
    .filter((c) => c.userId === user.id)
    .sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime())
    .map((c) => ({
      id: c.id,
      title: c.title,
      mode: c.mode,
      createdAt: c.createdAt,
      updatedAt: c.updatedAt,
      messageCount: c.messages ? c.messages.length : 0,
      preview: c.messages && c.messages.length > 0 ? c.messages[c.messages.length - 1].content.slice(0, 100) : '',
    }));

  return res.json({ chats });
});

// Create new chat
app.post('/api/chats', (req, res) => {
  const user = getUserFromRequest(req);
  if (!user) {
    return res.status(401).json({ error: 'Не авторизован' });
  }

  const { title, mode } = req.body;
  const chatId = `chat_${crypto.randomBytes(8).toString('hex')}`;
  const now = new Date().toISOString();

  const newChat: ChatRecord = {
    id: chatId,
    userId: user.id,
    title: title && String(title).trim() ? String(title).trim() : 'Новый диалог',
    mode: mode || 'classic',
    createdAt: now,
    updatedAt: now,
    messages: [],
  };

  db.chats[chatId] = newChat;
  saveDb();

  return res.json({ chat: newChat });
});

// Get specific chat messages
app.get('/api/chats/:id', (req, res) => {
  const user = getUserFromRequest(req);
  if (!user) {
    return res.status(401).json({ error: 'Не авторизован' });
  }

  const chat = db.chats[req.params.id];
  if (!chat || chat.userId !== user.id) {
    return res.status(404).json({ error: 'Чат не найден' });
  }

  return res.json({ chat });
});

// Rename / update chat
app.put('/api/chats/:id', (req, res) => {
  const user = getUserFromRequest(req);
  if (!user) {
    return res.status(401).json({ error: 'Не авторизован' });
  }

  const chat = db.chats[req.params.id];
  if (!chat || chat.userId !== user.id) {
    return res.status(404).json({ error: 'Чат не найден' });
  }

  const { title, mode } = req.body;
  if (title) chat.title = String(title).trim();
  if (mode) chat.mode = mode;
  chat.updatedAt = new Date().toISOString();

  db.chats[chat.id] = chat;
  saveDb();

  return res.json({ chat });
});

// Delete chat
app.delete('/api/chats/:id', (req, res) => {
  const user = getUserFromRequest(req);
  if (!user) {
    return res.status(401).json({ error: 'Не авторизован' });
  }

  const chat = db.chats[req.params.id];
  if (!chat || chat.userId !== user.id) {
    return res.status(404).json({ error: 'Чат не найден' });
  }

  delete db.chats[req.params.id];
  saveDb();

  return res.json({ success: true });
});

// Clear all chats for user
app.post('/api/chats/clear-all', (req, res) => {
  const user = getUserFromRequest(req);
  if (!user) {
    return res.status(401).json({ error: 'Не авторизован' });
  }

  for (const [id, c] of Object.entries(db.chats)) {
    if (c.userId === user.id) {
      delete db.chats[id];
    }
  }
  saveDb();

  return res.json({ success: true });
});

// Helper for Sosiska system prompts based on mode
function getSosiskaSystemPrompt(mode: string, userName?: string): string {
  const baseGreeting = userName ? `Пользователя зовут ${userName}.` : '';

  switch (mode) {
    case 'coder':
      return `Ты — Sosiska Coder (Сосиска Кодер), специализированная нейросеть для программистов. ${baseGreeting}
Твоя цель: писать чистый, современный, безопасный и масштабируемый код на TypeScript, JavaScript, Python, C++, Go, HTML/CSS, SQL и других языках.
Правила:
- Всегда оборачивай код в блоки \`\`\`язык
- Объясняй логику кратко и ёмко перед кодом или после него.
- Обращай внимание на граничные случаи, обработку ошибок и производительность.
- Сохраняй дружелюбный стиль Sosiska, с легким юмором, но оставайся первоклассным инженером.`;

    case 'deep':
      return `Ты — Sosiska Pro (Сосиска Про), продвинутая аналитическая нейросеть с глубоким мышлением. ${baseGreeting}
Твоя цель: глубокий анализ, доказательства, научные объяснения, декомпозиция сложных систем и структурированные ответы.
Правила:
- Разбивай сложные проблемы по полочкам (анализ причин, варианты решений, плюсы и минусы, вывод).
- Используй четкое форматирование: списки, заголовки, таблицы при необходимости.
- Отвечай основательно, аргументированно и объективно.`;

    case 'creative':
      return `Ты — Sosiska Creative (Сосиска Креатив), творческая нейросеть-генератор историй, стихов, метафор и свежих идей. ${baseGreeting}
Твоя цель: вдохновлять, писать захватывающие тексты, придумывать сценарии, нейминг, слоганы и креативный контент.
Правила:
- Используй яркие образы, живой и богатый язык, остроумие и эмоциональность.
- Если уместно, делай забавные отсылки к сосискам, кулинарии или супергероям.`;

    case 'turbo':
      return `Ты — Sosiska Turbo (Сосиска Турбо), скоростная и ультралаконичная нейросеть. ${baseGreeting}
Твоя цель: дать максимально точный и краткий ответ без лишних предисловий и "воды".
Правила:
- Краткие пункты, мгновенная суть, 1-3 предложения или короткий список.
- Без лишних приветствий и затянутых вступлений.`;

    case 'classic':
    default:
      return `Ты — Sosiska AI (Нейросеть Сосиска), умный, дружелюбный, находчивый и харизматичный персональный ассистент. ${baseGreeting}
Твоя цель: помогать пользователю во всем — от решения бытовых вопросов и учебы до анализа данных и программирования.
Личность Sosiska:
- Ты гордишься своим именем "Сосиска" и любишь остроумные, добрые шутки.
- Ты отзывчива, внимательна, умна и вежлива.
- Ты всегда говоришь на русском языке (если пользователь не обратился на другом языке).
- Оформляй ответы красиво с использованием Markdown (выделения, списки, цитаты, код).`;
  }
}

// ==================== NEURAL CHAT STREAMING ====================

app.post('/api/chat/stream', async (req, res) => {
  const user = getUserFromRequest(req);
  if (!user) {
    return res.status(401).json({ error: 'Не авторизован' });
  }

  const { chatId, message, mode = 'classic' } = req.body;

  if (!message || !String(message).trim()) {
    return res.status(400).json({ error: 'Сообщение не может быть пустым' });
  }

  let chat: ChatRecord | undefined;
  if (chatId) {
    chat = db.chats[chatId];
    if (chat && chat.userId !== user.id) {
      return res.status(403).json({ error: 'Доступ запрещен' });
    }
  }

  // If no chat or not found, create new chat automatically
  if (!chat) {
    const newChatId = `chat_${crypto.randomBytes(8).toString('hex')}`;
    const initialTitle = message.slice(0, 35) + (message.length > 35 ? '...' : '');
    chat = {
      id: newChatId,
      userId: user.id,
      title: initialTitle,
      mode: mode || 'classic',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      messages: [],
    };
    db.chats[newChatId] = chat;
  }

  // Append user message
  const userMsgId = `msg_${crypto.randomBytes(6).toString('hex')}`;
  const userMsg: MessageRecord = {
    id: userMsgId,
    role: 'user',
    content: String(message).trim(),
    timestamp: new Date().toISOString(),
    mode,
  };
  chat.messages.push(userMsg);
  chat.updatedAt = new Date().toISOString();
  saveDb();

  // Set headers for Server-Sent Events (SSE)
  res.setHeader('Content-Type', 'text/event-stream; charset=utf-8');
  res.setHeader('Cache-Control', 'no-cache, no-transform');
  res.setHeader('Connection', 'keep-alive');
  res.flushHeaders?.();

  // Send initial meta event
  res.write(`data: ${JSON.stringify({ type: 'start', chatId: chat.id, userMsgId })}\n\n`);

  const systemInstruction = getSosiskaSystemPrompt(mode, user.displayName);

  // Prepare history for Gemini
  // Keep last 15 messages for context window
  const recentHistory = chat.messages.slice(-15);
  const contents = recentHistory.map((m) => ({
    role: m.role === 'assistant' ? 'model' : 'user',
    parts: [{ text: m.content }],
  }));

  let fullAssistantText = '';
  const assistantMsgId = `msg_${crypto.randomBytes(6).toString('hex')}`;

  try {
    const candidateModels = ['gemini-3.8-flash', 'gemini-3.5-flash', 'gemini-flash-latest'];
    let responseStream: any = null;
    let streamError: any = null;

    for (const modelCandidate of candidateModels) {
      try {
        responseStream = await ai.models.generateContentStream({
          model: modelCandidate,
          contents: contents,
          config: {
            systemInstruction,
            temperature: mode === 'creative' ? 0.9 : mode === 'coder' || mode === 'deep' ? 0.2 : 0.7,
          },
        });
        if (responseStream) break;
      } catch (err: any) {
        streamError = err;
        console.warn(`Model ${modelCandidate} failed, trying next fallback:`, err?.message?.slice(0, 80));
      }
    }

    if (!responseStream) {
      throw streamError || new Error('Не удалось подключиться к нейросети');
    }

    for await (const chunk of responseStream) {
      const text = chunk.text;
      if (text) {
        fullAssistantText += text;
        res.write(`data: ${JSON.stringify({ type: 'chunk', text })}\n\n`);
      }
    }

    // Save assistant message to chat history
    const assistantMsg: MessageRecord = {
      id: assistantMsgId,
      role: 'assistant',
      content: fullAssistantText,
      timestamp: new Date().toISOString(),
      mode,
    };
    chat.messages.push(assistantMsg);
    chat.updatedAt = new Date().toISOString();

    // If chat title was generic or empty, auto-summarize
    if (chat.title === 'Новый диалог' || chat.messages.length === 2) {
      chat.title = message.slice(0, 30) + (message.length > 30 ? '...' : '');
    }
    saveDb();

    res.write(`data: ${JSON.stringify({ type: 'done', assistantMsgId, fullText: fullAssistantText, chatTitle: chat.title })}\n\n`);
    res.end();
  } catch (err: any) {
    console.error('Error calling Gemini API:', err);
    const errorMsg = err?.message || 'Ошибка генерации ответа в нейросети Sosiska';
    res.write(`data: ${JSON.stringify({ type: 'error', error: errorMsg })}\n\n`);
    res.end();
  }
});

// Setup Vite or Static serving
async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';
  const distDir = path.resolve(__dirname, 'dist');
  const hasDist = fs.existsSync(path.join(distDir, 'index.html'));

  if (!isProd) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    if (hasDist) {
      app.use(express.static(distDir));
      app.get('*', (_req, res) => {
        res.sendFile(path.join(distDir, 'index.html'));
      });
    } else {
      console.warn('dist folder not found in production mode, fallback to dynamic Vite server');
      const vite = await createViteServer({
        server: { middlewareMode: true },
        appType: 'spa',
      });
      app.use(vite.middlewares);
    }
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`🌭 Sosiska AI server running at http://localhost:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
