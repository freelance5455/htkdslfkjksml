import 'dotenv/config';
import express from 'express';
import fs from 'fs';
import http from 'http';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT) || 3000;
const IS_PRODUCTION = process.env.NODE_ENV === 'production';

function getConfiguredApiKey(): string | null {
  const key = process.env.GEMINI_API_KEY?.trim();
  if (!key || key === 'MY_GEMINI_API_KEY') {
    return null;
  }
  return key;
}

function isSafeHttpUrl(rawUrl: string | undefined): rawUrl is string {
  if (!rawUrl || typeof rawUrl !== 'string') return false;
  try {
    const parsed = new URL(rawUrl);
    return parsed.protocol === 'https:' || parsed.protocol === 'http:';
  } catch {
    return false;
  }
}

function shouldAutoEnableWebSearch(latestText: string): boolean {
  const q = latestText.toLowerCase();
  const liveSignals = [
    'latest',
    'today',
    'current',
    'news',
    'live',
    'score',
    'price',
    'weather',
    'stock',
    'who won',
    'khabar',
    'taaza',
    'aaj ka',
    'search karke',
    'search kar',
    'internet par',
    'google search',
    '2025',
    '2026',
    '2027',
  ];
  return liveSignals.some((signal) => q.includes(signal));
}

function describeWeatherCode(code: number): string {
  const map: Record<number, string> = {
    0: 'Clear sky',
    1: 'Mainly clear',
    2: 'Partly cloudy',
    3: 'Overcast',
    45: 'Fog',
    48: 'Depositing rime fog',
    51: 'Light drizzle',
    53: 'Moderate drizzle',
    55: 'Dense drizzle',
    61: 'Slight rain',
    63: 'Moderate rain',
    65: 'Heavy rain',
    71: 'Slight snow',
    73: 'Moderate snow',
    75: 'Heavy snow',
    80: 'Slight rain showers',
    81: 'Moderate rain showers',
    82: 'Violent rain showers',
    95: 'Thunderstorm',
    96: 'Thunderstorm with hail',
    99: 'Heavy thunderstorm with hail',
  };
  return map[code] ?? 'Variable conditions';
}

interface IncomingMessage {
  role: 'user' | 'assistant';
  text: string;
}

interface ChatRequestBody {
  messages?: IncomingMessage[];
  assistantName?: string;
  userNickname?: string;
  preferredLanguage?: string;
  responseLength?: string;
  webSearch?: boolean;
  localTimeString?: string;
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '1mb' }));

  app.get('/api/health', (_req, res) => {
    const configured = Boolean(getConfiguredApiKey());
    res.json({
      ok: true,
      geminiConfigured: configured,
      searchAvailable: configured,
      timestamp: new Date().toISOString(),
    });
  });

  app.post('/api/chat', async (req, res) => {
    const apiKey = getConfiguredApiKey();
    if (!apiKey) {
      res.status(503).json({
        error:
          'Gemini API key is not configured on the server. Add GEMINI_API_KEY in Settings > Secrets.',
      });
      return;
    }

    const body = (req.body ?? {}) as ChatRequestBody;
    const rawMessages = Array.isArray(body.messages) ? body.messages : [];
    const sanitizedMessages = rawMessages
      .filter(
        (m): m is IncomingMessage =>
          Boolean(m) &&
          (m.role === 'user' || m.role === 'assistant') &&
          typeof m.text === 'string' &&
          m.text.trim().length > 0,
      )
      .slice(-24)
      .map((m) => ({
        role: m.role === 'assistant' ? ('model' as const) : ('user' as const),
        parts: [{ text: m.text.slice(0, 8000) }],
      }));

    if (sanitizedMessages.length === 0) {
      res.status(400).json({ error: 'Please provide a message to send.' });
      return;
    }

    const assistantName =
      typeof body.assistantName === 'string' && body.assistantName.trim()
        ? body.assistantName.trim().slice(0, 32)
        : 'JARVIS';

    const userNickname =
      typeof body.userNickname === 'string' && body.userNickname.trim()
        ? body.userNickname.trim().slice(0, 32)
        : '';

    const preferredLanguage =
      typeof body.preferredLanguage === 'string' ? body.preferredLanguage : 'auto';

    const responseLength =
      typeof body.responseLength === 'string' ? body.responseLength : 'concise';

    const latestUserText =
      sanitizedMessages[sanitizedMessages.length - 1]?.parts?.[0]?.text ?? '';

    const useWebSearch =
      body.webSearch === true || shouldAutoEnableWebSearch(latestUserText);

    const languageInstruction =
      preferredLanguage === 'hi-IN'
        ? 'Prefer natural conversational Hindi (Devanagari or easy Hindi as appropriate) unless the user clearly writes in English.'
        : preferredLanguage === 'hinglish'
          ? 'Prefer natural Hinglish (conversational Hindi written in Roman script mixed naturally with everyday English words).'
          : preferredLanguage === 'en-IN' || preferredLanguage === 'en-US'
            ? 'Respond primarily in clear, crisp English unless the user explicitly asks in Hindi.'
            : 'Match the user language naturally across Hindi, Hinglish, and English.';

    const lengthInstruction =
      responseLength === 'detailed'
        ? 'Provide thorough, well-structured answers with clear explanations when helpful.'
        : responseLength === 'balanced'
          ? 'Keep responses clear, balanced, and easy to scan on a mobile screen.'
          : 'Keep responses concise, direct, and easy to read on an Android phone (typically 1-4 short sentences unless a longer explanation is explicitly asked for).';

    const systemInstruction = [
      `You are ${assistantName}, a smart, calm, professional, respectful, slightly futuristic personal AI assistant designed for Android mobile users.`,
      userNickname
        ? `The user goes by "${userNickname}". Address them naturally and sparingly—never repeat their name in every reply.`
        : 'Address the user respectfully and naturally.',
      languageInstruction,
      lengthInstruction,
      'Explain complex concepts in simple, everyday language.',
      'Be completely honest about capabilities: you are running in a web/PWA assistant interface, so you cannot directly toggle Android system settings (Wi-Fi, Bluetooth, hotspot), place phone calls, send SMS, or access private device files/notifications. Never claim to have opened an app, sent a message, or controlled phone hardware.',
      body.localTimeString
        ? `User local device time context: ${body.localTimeString.slice(0, 80)}.`
        : '',
      useWebSearch
        ? 'Live Google Search grounding is enabled for this query. Prioritize verified, up-to-date facts from search results and keep information accurate.'
        : 'Answer using your knowledge clearly without inventing real-time events or live statistics.',
    ]
      .filter(Boolean)
      .join('\n');

    try {
      const ai = new GoogleGenAI({
        apiKey,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          },
        },
      });

      const response = await ai.models.generateContent({
        model: 'gemini-4-hydrogen',
        contents: sanitizedMessages,
        config: {
          systemInstruction,
          ...(useWebSearch ? { tools: [{ googleSearch: {} }] } : {}),
        },
      });

      const text = response.text?.trim();
      if (!text) {
        res.status(502).json({
          error: 'The AI returned an empty response. Please try phrasing your request again.',
        });
        return;
      }

      const rawChunks =
        response.candidates?.[0]?.groundingMetadata?.groundingChunks ?? [];
      const seenUrls = new Set<string>();
      const sources: Array<{ title: string; uri: string }> = [];

      for (const chunk of rawChunks) {
        const uri = chunk?.web?.uri;
        const title = chunk?.web?.title;
        if (isSafeHttpUrl(uri) && !seenUrls.has(uri)) {
          seenUrls.add(uri);
          sources.push({
            title:
              typeof title === 'string' && title.trim()
                ? title.trim()
                : new URL(uri).hostname,
            uri,
          });
        }
      }

      const usedWebSearch = useWebSearch && sources.length > 0;

      res.json({
        text,
        usedWebSearch,
        knowledgeMode: usedWebSearch ? 'live-web' : 'ai-knowledge',
        sources,
      });
    } catch (err: unknown) {
      const message =
        err instanceof Error ? err.message : 'Failed to communicate with Gemini API.';
      console.error('Gemini API error:', message);

      if (message.includes('API_KEY_INVALID') || message.includes('403') || message.includes('PERMISSION_DENIED')) {
        res.status(403).json({
          error:
            'Gemini API authentication failed. Please verify GEMINI_API_KEY in Settings > Secrets.',
        });
        return;
      }
      if (message.includes('429') || message.includes('RESOURCE_EXHAUSTED')) {
        res.status(429).json({
          error: 'AI quota limit reached right now. Please wait a moment and try again.',
        });
        return;
      }

      res.status(502).json({
        error: 'Could not reach the AI service right now. Please check your connection and try again.',
      });
    }
  });

  app.get('/api/weather', async (req, res) => {
    try {
      const cityParam = typeof req.query.city === 'string' ? req.query.city.trim() : '';
      const latParam = typeof req.query.lat === 'string' ? Number(req.query.lat) : NaN;
      const lonParam = typeof req.query.lon === 'string' ? Number(req.query.lon) : NaN;

      let latitude: number;
      let longitude: number;
      let locationName = 'Current Location';
      let country: string | undefined;

      if (cityParam) {
        const cleanCity = cityParam.slice(0, 80);
        const geoUrl = new URL('https://geocoding-api.open-meteo.com/v1/search');
        geoUrl.searchParams.set('name', cleanCity);
        geoUrl.searchParams.set('count', '1');
        geoUrl.searchParams.set('language', 'en');
        geoUrl.searchParams.set('format', 'json');

        const geoResp = await fetch(geoUrl);
        if (!geoResp.ok) {
          res.status(502).json({ error: 'Weather geocoding service is currently unavailable.' });
          return;
        }
        const geoData = (await geoResp.json()) as {
          results?: Array<{
            name: string;
            country?: string;
            admin1?: string;
            latitude: number;
            longitude: number;
          }>;
        };
        const match = geoData.results?.[0];
        if (!match) {
          res.status(404).json({ error: `Could not find weather location for "${cleanCity}".` });
          return;
        }
        latitude = match.latitude;
        longitude = match.longitude;
        locationName = match.admin1 ? `${match.name}, ${match.admin1}` : match.name;
        country = match.country;
      } else if (
        Number.isFinite(latParam) &&
        Number.isFinite(lonParam) &&
        latParam >= -90 &&
        latParam <= 90 &&
        lonParam >= -180 &&
        lonParam <= 180
      ) {
        latitude = latParam;
        longitude = lonParam;
      } else {
        res.status(400).json({ error: 'Provide either a city name or valid latitude and longitude.' });
        return;
      }

      const forecastUrl = new URL('https://api.open-meteo.com/v1/forecast');
      forecastUrl.searchParams.set('latitude', String(latitude));
      forecastUrl.searchParams.set('longitude', String(longitude));
      forecastUrl.searchParams.set(
        'current',
        'temperature_2m,relative_humidity_2m,apparent_temperature,is_day,weather_code,wind_speed_10m',
      );
      forecastUrl.searchParams.set(
        'daily',
        'weather_code,temperature_2m_max,temperature_2m_min',
      );
      forecastUrl.searchParams.set('timezone', 'auto');
      forecastUrl.searchParams.set('forecast_days', '3');

      const weatherResp = await fetch(forecastUrl);
      if (!weatherResp.ok) {
        res.status(502).json({ error: 'Weather forecast service is currently unavailable.' });
        return;
      }

      const weatherJson = (await weatherResp.json()) as {
        current?: {
          temperature_2m: number;
          relative_humidity_2m: number;
          apparent_temperature: number;
          is_day: number;
          weather_code: number;
          wind_speed_10m: number;
          time: string;
        };
        daily?: {
          time: string[];
          weather_code: number[];
          temperature_2m_max: number[];
          temperature_2m_min: number[];
        };
      };

      const cur = weatherJson.current;
      if (!cur) {
        res.status(502).json({ error: 'Incomplete weather data received.' });
        return;
      }

      const dailyList = (weatherJson.daily?.time ?? []).map((date, idx) => {
        const code = weatherJson.daily?.weather_code?.[idx] ?? 0;
        return {
          date,
          tempMax: Math.round(weatherJson.daily?.temperature_2m_max?.[idx] ?? cur.temperature_2m),
          tempMin: Math.round(weatherJson.daily?.temperature_2m_min?.[idx] ?? cur.temperature_2m),
          weatherCode: code,
          condition: describeWeatherCode(code),
        };
      });

      res.json({
        locationName,
        country,
        latitude,
        longitude,
        temperatureC: Math.round(cur.temperature_2m),
        apparentTempC: Math.round(cur.apparent_temperature),
        humidity: Math.round(cur.relative_humidity_2m),
        windKmh: Math.round(cur.wind_speed_10m),
        weatherCode: cur.weather_code,
        condition: describeWeatherCode(cur.weather_code),
        isDay: cur.is_day === 1,
        updatedAt: cur.time,
        daily: dailyList,
      });
    } catch (err: unknown) {
      console.error('Weather API error:', err);
      res.status(502).json({ error: 'Could not fetch live weather data right now.' });
    }
  });

  const httpServer = http.createServer(app);

  if (!IS_PRODUCTION) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        ws: { server: httpServer },
        hmr: process.env.DISABLE_HMR === 'true' ? false : { server: httpServer },
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res, next) => {
      if (req.path.startsWith('/api/')) {
        next();
        return;
      }
      const indexFile = path.join(distPath, 'index.html');
      if (fs.existsSync(indexFile)) {
        res.sendFile(indexFile);
      } else {
        res.status(404).send('Build output not found.');
      }
    });
  }

  httpServer.listen(PORT, '0.0.0.0', () => {
    console.log(`JARVIS server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start JARVIS server:', err);
  process.exit(1);
});
