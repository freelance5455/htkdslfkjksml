import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';
import WebSocket from 'ws';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const DEFAULT_HOST = 'mchelden3.modrinth.gg';
const DEFAULT_PORT = '25809';
const DEFAULT_KEY = 'change_me';

interface ServerChatMessage {
  id: string;
  sender: string;
  text: string;
  timestamp: number;
  platform: 'bedrock' | 'java';
  isOffline?: boolean;
}

const chatHistory: ServerChatMessage[] = [];
const sseClients = new Set<express.Response>();

function broadcastSSE(msg: ServerChatMessage) {
  const payload = `data: ${JSON.stringify(msg)}\n\n`;
  for (const client of sseClients) {
    try {
      client.write(payload);
    } catch {
      sseClients.delete(client);
    }
  }
}

function cleanAnsi(str: string) {
  return str.replace(/\u001b\[[0-9;]*[a-zA-Z]/g, '').trim();
}

let tapWs: WebSocket | null = null;
let tapWsReconnectTimer: NodeJS.Timeout | null = null;

function connectServerTapWs() {
  if (tapWsReconnectTimer) clearTimeout(tapWsReconnectTimer);

  const wsUrl = `ws://${DEFAULT_HOST}:${DEFAULT_PORT}/v1/ws/console?key=${DEFAULT_KEY}`;
  try {
    tapWs = new WebSocket(wsUrl);

    tapWs.on('open', () => {
      console.log('Connected to ServerTap console WebSocket');
    });

    tapWs.on('message', (raw) => {
      try {
        const data = JSON.parse(raw.toString());
        if (!data || typeof data.message !== 'string') return;

        const clean = cleanAnsi(data.message);
        if (!clean) return;

        let parsedMsg: ServerChatMessage | null = null;

        // Check for offline web broadcast: [Offline] PlayerName: Message
        const offlineMatch = clean.match(/^\[Offline\]\s*([a-zA-Z0-9_.]+):\s*(.+)$/);
        if (offlineMatch) {
          const sender = offlineMatch[1].trim();
          const text = offlineMatch[2].trim();
          parsedMsg = {
            id: `${data.timestampMillis || Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
            sender,
            text,
            timestamp: data.timestampMillis || Date.now(),
            platform: sender.startsWith('.') ? 'bedrock' : 'java',
            isOffline: true,
          };
        } else {
          // Check for regular player chat in Minecraft: <PlayerName> Message
          const playerMatch = clean.match(/^<([a-zA-Z0-9_.]+)>[\s:](.+)$/);
          if (playerMatch) {
            const sender = playerMatch[1].trim();
            const text = playerMatch[2].trim();
            parsedMsg = {
              id: `${data.timestampMillis || Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
              sender,
              text,
              timestamp: data.timestampMillis || Date.now(),
              platform: sender.startsWith('.') ? 'bedrock' : 'java',
              isOffline: false,
            };
          }
        }

        if (parsedMsg) {
          // Avoid immediate duplicates within 500ms
          const isDuplicate = chatHistory.some(
            (m) =>
              m.sender === parsedMsg!.sender &&
              m.text === parsedMsg!.text &&
              Math.abs(m.timestamp - parsedMsg!.timestamp) < 1500
          );

          if (!isDuplicate) {
            chatHistory.push(parsedMsg);
            if (chatHistory.length > 100) {
              chatHistory.shift();
            }
            broadcastSSE(parsedMsg);
          }
        }
      } catch {
        // ignore parse errors
      }
    });

    tapWs.on('error', (err) => {
      console.error('ServerTap WS error:', err.message);
    });

    tapWs.on('close', () => {
      tapWsReconnectTimer = setTimeout(connectServerTapWs, 4000);
    });
  } catch (err: any) {
    console.error('Failed to initialize ServerTap WS:', err.message);
    tapWsReconnectTimer = setTimeout(connectServerTapWs, 4000);
  }
}

// Start live console listener
connectServerTapWs();

async function startServer() {
  const app = express();
  const PORT = parseInt(process.env.PORT || '3000', 10);

  app.use(express.json());

  // GET /api/players - Proxies ServerTap player list
  app.get('/api/players', async (req, res) => {
    const host = (req.query.host as string) || DEFAULT_HOST;
    const port = (req.query.port as string) || DEFAULT_PORT;
    const key = (req.query.key as string) || DEFAULT_KEY;
    const protocol = (req.query.protocol as string) || 'http';

    const targetUrl = `${protocol}://${host}:${port}/v1/players`;

    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 7000);

      const response = await fetch(targetUrl, {
        headers: {
          'Key': key,
          'Accept': 'application/json'
        },
        signal: controller.signal
      });

      clearTimeout(timeoutId);

      if (!response.ok) {
        const errorText = await response.text().catch(() => '');
        return res.status(response.status).json({
          error: `ServerTap Status ${response.status}`,
          details: errorText || response.statusText,
          online: false
        });
      }

      const players = await response.json();
      return res.json({
        success: true,
        online: true,
        count: Array.isArray(players) ? players.length : 0,
        players: Array.isArray(players) ? players : []
      });
    } catch (err: any) {
      console.error('ServerTap /v1/players connection error:', err.message);
      return res.status(502).json({
        error: err.name === 'AbortError' ? 'Timeout beim Verbinden mit ServerTap' : (err.message || 'Verbindungsfehler'),
        online: false,
        players: []
      });
    }
  });

  // GET /api/server - Proxies ServerTap server info (MOTD, TPS, maxPlayers, etc.)
  app.get('/api/server', async (req, res) => {
    const host = (req.query.host as string) || DEFAULT_HOST;
    const port = (req.query.port as string) || DEFAULT_PORT;
    const key = (req.query.key as string) || DEFAULT_KEY;
    const protocol = (req.query.protocol as string) || 'http';

    const targetUrl = `${protocol}://${host}:${port}/v1/server`;

    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 7000);

      const response = await fetch(targetUrl, {
        headers: {
          'Key': key,
          'Accept': 'application/json'
        },
        signal: controller.signal
      });

      clearTimeout(timeoutId);

      if (!response.ok) {
        return res.status(response.status).json({
          online: false,
          error: `ServerTap Status ${response.status}`
        });
      }

      const serverInfo = await response.json();
      return res.json({
        online: true,
        ...serverInfo
      });
    } catch (err: any) {
      return res.status(502).json({
        online: false,
        error: err.name === 'AbortError' ? 'Timeout beim Abrufen des Server-Status' : err.message
      });
    }
  });

  // POST /api/chat - Broadcasts chat message to Minecraft server via ServerTap
  app.post('/api/chat', async (req, res) => {
    const { sender, message, platform } = req.body;
    const host = (req.query.host as string) || DEFAULT_HOST;
    const port = (req.query.port as string) || DEFAULT_PORT;
    const key = (req.query.key as string) || DEFAULT_KEY;
    const protocol = (req.query.protocol as string) || 'http';

    if (!message || typeof message !== 'string' || !message.trim()) {
      return res.status(400).json({ error: 'Nachricht ist erforderlich' });
    }
    if (!sender || typeof sender !== 'string' || !sender.trim()) {
      return res.status(400).json({ error: 'Spielername ist erforderlich' });
    }

    const cleanSender = sender.trim();
    const cleanMsg = message.trim();
    const fullBroadcast = `[Offline] ${cleanSender}: ${cleanMsg}`;

    const targetUrl = `${protocol}://${host}:${port}/v1/chat/broadcast`;

    try {
      const formData = new URLSearchParams();
      formData.append('message', fullBroadcast);

      const response = await fetch(targetUrl, {
        method: 'POST',
        headers: {
          'Key': key,
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: formData.toString(),
      });

      if (!response.ok) {
        const errText = await response.text().catch(() => '');
        return res.status(response.status).json({
          error: `ServerTap Fehler: ${errText || response.statusText}`
        });
      }

      return res.json({
        success: true,
        sender: cleanSender,
        message: cleanMsg,
        timestamp: Date.now()
      });
    } catch (err: any) {
      console.error('Chat broadcast error:', err.message);
      return res.status(502).json({
        error: err.message || 'Konnte Nachricht nicht an den Server senden'
      });
    }
  });

  // GET /api/chat/messages - Returns recent messages captured from server chat
  app.get('/api/chat/messages', (_req, res) => {
    return res.json({
      success: true,
      messages: chatHistory
    });
  });

  // GET /api/chat/stream - Server-Sent Events (SSE) for live chat stream
  app.get('/api/chat/stream', (req, res) => {
    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');
    if (res.flushHeaders) res.flushHeaders();

    // Send initial history
    res.write(`data: ${JSON.stringify({ type: 'init', messages: chatHistory })}\n\n`);

    sseClients.add(res);

    req.on('close', () => {
      sseClients.delete(res);
    });
  });

  // GET /api/skin - Resolves skin / texture ID for Bedrock (.name) or Java players
  app.get('/api/skin/:name', async (req, res) => {
    const rawName = req.params.name;
    const isBedrock = rawName.startsWith('.');
    const cleanName = rawName.replace(/^[.*_]/, '');

    try {
      if (isBedrock) {
        // Resolve Bedrock XUID
        const xuidRes = await fetch(`https://api.geysermc.org/v2/xbox/xuid/${encodeURIComponent(cleanName)}`);
        if (xuidRes.ok) {
          const xuidData = await xuidRes.json();
          if (xuidData.xuid) {
            const skinRes = await fetch(`https://api.geysermc.org/v2/skin/${xuidData.xuid}`);
            if (skinRes.ok) {
              const skinData = await skinRes.json();
              if (skinData.texture_id) {
                return res.redirect(`https://mc-heads.net/avatar/${skinData.texture_id}/64`);
              }
            }
          }
        }
      }

      // Default redirect to mc-heads
      return res.redirect(`https://mc-heads.net/avatar/${encodeURIComponent(cleanName || rawName)}/64`);
    } catch {
      return res.redirect(`https://mc-heads.net/avatar/${encodeURIComponent(cleanName || rawName)}/64`);
    }
  });

  // Serve /symbols directory directly
  app.use('/symbols', express.static(path.resolve(__dirname, 'symbols')));

  // Serve static files in production or Vite middleware in development
  const isProd = process.env.NODE_ENV === 'production';
  if (!isProd) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server listening on port ${PORT}`);
  });
}

startServer().catch(err => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
