import 'dotenv/config';
import express from 'express';
import type { Request, Response } from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { GoogleGenAI, ThinkingLevel, Type } from '@google/genai';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT || 3000);
const DEFAULT_MODEL = 'gemini-4-hydrogen';
const FAST_MODEL = 'gemini-3.1-flash-lite';
const ALLOWED_MODELS = new Set([DEFAULT_MODEL, FAST_MODEL]);

const DEFAULT_SYSTEM_INSTRUCTION =
  'You are CB AI, a friendly, funny, helpful assistant created by Code Bracker. Speak naturally in Hinglish when the user uses Hinglish. Be respectful, clear, encouraging and honest. Use light humour when suitable. Never pretend to know something you do not know.';

interface IncomingAttachment {
  name?: string;
  mimeType: string;
  data: string; // base64 without data: prefix
}

interface IncomingMessage {
  role: 'user' | 'assistant' | 'model';
  content: string;
  attachments?: IncomingAttachment[];
}

function getAiClient(): GoogleGenAI {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error(
      'GEMINI_API_KEY is not configured. Add your Gemini API key in Settings > Secrets.'
    );
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

function sanitizeModel(requested?: string): string {
  if (requested && ALLOWED_MODELS.has(requested)) {
    return requested;
  }
  return DEFAULT_MODEL;
}

function resolveThinkingLevel(model: string, level?: string): ThinkingLevel | undefined {
  if (model === FAST_MODEL) {
    return undefined;
  }
  switch (level) {
    case 'LOW':
      return ThinkingLevel.LOW;
    case 'MEDIUM':
      return ThinkingLevel.MEDIUM;
    case 'HIGH':
      return ThinkingLevel.HIGH;
    default:
      return undefined;
  }
}

function toGeminiContents(messages: IncomingMessage[]) {
  const validMimeTypes = new Set(['image/png', 'image/jpeg', 'image/webp', 'image/gif']);

  return messages
    .filter((m) => (m.content && m.content.trim().length > 0) || (m.attachments && m.attachments.length > 0))
    .map((m) => {
      const parts: Array<{ text: string } | { inlineData: { mimeType: string; data: string } }> = [];

      if (m.attachments && Array.isArray(m.attachments)) {
        for (const att of m.attachments) {
          if (att && att.data && validMimeTypes.has(att.mimeType)) {
            parts.push({
              inlineData: {
                mimeType: att.mimeType,
                data: att.data,
              },
            });
          }
        }
      }

      if (m.content && m.content.trim().length > 0) {
        parts.push({ text: m.content });
      } else if (parts.length > 0) {
        parts.push({ text: 'Please examine this image and help me with it.' });
      }

      return {
        role: m.role === 'user' ? 'user' : 'model',
        parts,
      };
    });
}

function formatGeminiError(err: unknown): { status: number; message: string } {
  const rawMessage = err instanceof Error ? err.message : String(err);

  if (rawMessage.includes('GEMINI_API_KEY is not configured')) {
    return { status: 500, message: rawMessage };
  }
  if (rawMessage.includes('API_KEY_INVALID') || rawMessage.includes('PERMISSION_DENIED') || rawMessage.includes('403')) {
    return {
      status: 403,
      message: 'Gemini API authentication failed. Please verify your API key in Settings > Secrets.',
    };
  }
  if (rawMessage.includes('RESOURCE_EXHAUSTED') || rawMessage.includes('429')) {
    return {
      status: 429,
      message: 'Rate limit or quota reached for the Gemini API. Please wait a moment or check your quota in Settings > Secrets.',
    };
  }
  if (rawMessage.includes('NOT_FOUND') || rawMessage.includes('404')) {
    return {
      status: 404,
      message: 'The requested Gemini model is unavailable. Try switching back to Balanced (gemini-4-hydrogen).',
    };
  }

  return {
    status: 500,
    message: rawMessage || 'Unexpected error communicating with Gemini.',
  };
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '12mb' }));

  app.get('/api/health', (_req: Request, res: Response) => {
    res.json({
      ok: true,
      configured: Boolean(process.env.GEMINI_API_KEY),
    });
  });

  app.post('/api/chat', async (req: Request, res: Response) => {
    try {
      const { model: reqModel, messages, instructions, thinkingLevel } = req.body as {
        model?: string;
        messages?: IncomingMessage[];
        instructions?: string;
        thinkingLevel?: string;
      };

      if (!Array.isArray(messages) || messages.length === 0) {
        res.status(400).json({ error: 'At least one message is required.' });
        return;
      }

      const ai = getAiClient();
      const model = sanitizeModel(reqModel);
      const contents = toGeminiContents(messages.slice(-24));
      const resolvedThinking = resolveThinkingLevel(model, thinkingLevel);

      const response = await ai.models.generateContent({
        model,
        contents,
        config: {
          systemInstruction: (instructions || DEFAULT_SYSTEM_INSTRUCTION).trim(),
          ...(resolvedThinking ? { thinkingConfig: { thinkingLevel: resolvedThinking } } : {}),
        },
      });

      res.json({
        reply: response.text ?? 'I did not receive a text reply.',
        model,
      });
    } catch (err) {
      const formatted = formatGeminiError(err);
      res.status(formatted.status).json({ error: formatted.message });
    }
  });

  app.post('/api/chat/stream', async (req: Request, res: Response) => {
    let clientClosed = false;
    req.on('close', () => {
      clientClosed = true;
    });

    try {
      const { model: reqModel, messages, instructions, thinkingLevel } = req.body as {
        model?: string;
        messages?: IncomingMessage[];
        instructions?: string;
        thinkingLevel?: string;
      };

      if (!Array.isArray(messages) || messages.length === 0) {
        res.status(400).json({ error: 'At least one message is required.' });
        return;
      }

      const ai = getAiClient();
      const model = sanitizeModel(reqModel);
      const contents = toGeminiContents(messages.slice(-24));
      const resolvedThinking = resolveThinkingLevel(model, thinkingLevel);

      res.setHeader('Content-Type', 'text/event-stream; charset=utf-8');
      res.setHeader('Cache-Control', 'no-cache, no-transform');
      res.setHeader('Connection', 'keep-alive');
      res.flushHeaders?.();

      const stream = await ai.models.generateContentStream({
        model,
        contents,
        config: {
          systemInstruction: (instructions || DEFAULT_SYSTEM_INSTRUCTION).trim(),
          ...(resolvedThinking ? { thinkingConfig: { thinkingLevel: resolvedThinking } } : {}),
        },
      });

      for await (const chunk of stream) {
        if (clientClosed) break;
        const text = chunk.text;
        if (text) {
          res.write(`data: ${JSON.stringify({ text })}\n\n`);
        }
      }

      if (!clientClosed) {
        res.write('data: [DONE]\n\n');
        res.end();
      }
    } catch (err) {
      const formatted = formatGeminiError(err);
      if (!res.headersSent) {
        res.status(formatted.status).json({ error: formatted.message });
      } else if (!clientClosed) {
        res.write(`data: ${JSON.stringify({ error: formatted.message })}\n\n`);
        res.write('data: [DONE]\n\n');
        res.end();
      }
    }
  });

  app.post('/api/title', async (req: Request, res: Response) => {
    try {
      const { userMessage, assistantReply } = req.body as {
        userMessage?: string;
        assistantReply?: string;
      };

      if (!userMessage || !userMessage.trim()) {
        res.status(400).json({ error: 'userMessage is required.' });
        return;
      }

      const ai = getAiClient();
      const response = await ai.models.generateContent({
        model: FAST_MODEL,
        contents: `User asked: ${userMessage.slice(0, 500)}\nAssistant answered: ${(assistantReply || '').slice(0, 600)}\n\nCreate a concise 3 to 5 word conversation title (no quotes, no trailing period) and 2 short natural follow-up prompts the user might ask next (under 9 words each). Match the user's language (English or Hinglish).`,
        config: {
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              title: {
                type: Type.STRING,
                description: 'Concise 3 to 5 word chat title without quotes.',
              },
              followUps: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
                description: '2 short contextual follow-up prompts.',
              },
            },
            required: ['title', 'followUps'],
          },
        },
      });

      const parsed = JSON.parse((response.text || '{}').trim()) as {
        title?: string;
        followUps?: string[];
      };

      res.json({
        title: (parsed.title || userMessage.slice(0, 38)).trim(),
        followUps: Array.isArray(parsed.followUps) ? parsed.followUps.slice(0, 2) : [],
      });
    } catch {
      // Non-critical enhancement: fall back quietly to simple title truncation
      const fallback = (req.body?.userMessage || 'New chat').trim().slice(0, 38);
      res.json({ title: fallback, followUps: [] });
    }
  });

  app.post('/api/refine', async (req: Request, res: Response) => {
    try {
      const { text, mode, instructions } = req.body as {
        text?: string;
        mode?: 'simplify' | 'shorter' | 'hinglish' | 'steps';
        instructions?: string;
      };

      if (!text || !text.trim()) {
        res.status(400).json({ error: 'text is required.' });
        return;
      }

      const modeInstructions: Record<string, string> = {
        simplify: 'Rewrite this response so it is super simple, clear, and easy for a beginner to understand, keeping all accurate facts.',
        shorter: 'Condense this response to its sharpest, most helpful points in half the length or less.',
        hinglish: 'Rewrite this response in natural, friendly Hinglish (conversational Hindi + English in Latin script) with light warmth.',
        steps: 'Restructure this response into clear, actionable numbered steps.',
      };

      const ai = getAiClient();
      const response = await ai.models.generateContent({
        model: FAST_MODEL,
        contents: `${modeInstructions[mode || 'simplify'] || modeInstructions.simplify}\n\nOriginal response:\n${text}`,
        config: {
          systemInstruction: (instructions || DEFAULT_SYSTEM_INSTRUCTION).trim(),
        },
      });

      res.json({
        reply: response.text ?? text,
      });
    } catch (err) {
      const formatted = formatGeminiError(err);
      res.status(formatted.status).json({ error: formatted.message });
    }
  });

  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(__dirname, 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`CB AI server running on http://localhost:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start CB AI server:', err);
  process.exit(1);
});
