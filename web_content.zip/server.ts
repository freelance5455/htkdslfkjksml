/**
 * JARVIS Full-Stack Operating System Entry Point
 * Express Server with Modular API Architecture and Vite SPA Middleware
 */

import dotenv from 'dotenv';
import express from 'express';
import type { NextFunction, Request, Response } from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';

import { apiRouter } from './server/api/index.ts';
import { config } from './server/config/index.ts';
import { initializeDatabase } from './server/db/database.ts';

dotenv.config();

async function startServer() {
  const app = express();
  const PORT = config.server.port;

  // Global request parsing and security middleware
  app.use(express.json({ limit: config.server.bodyLimit }));
  app.use((req, res, next) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-Frame-Options', 'SAMEORIGIN');
    res.setHeader('Access-Control-Allow-Origin', config.server.corsOrigin);
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
    if (req.method === 'OPTIONS') {
      res.sendStatus(204);
      return;
    }
    next();
  });

  // Initialize persistent database
  await initializeDatabase();

  // Mount modular API routes
  app.use(apiRouter);

  // Global API error handler
  app.use('/api', (err: any, req: Request, res: Response, next: NextFunction) => {
    console.error('[API ERROR]', err);
    if (!res.headersSent) {
      res.status(500).json({ error: err?.message || 'Internal Server Error' });
    }
  });

  // Vite development middleware or static asset serving
  if (!config.runtime.isProduction) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, config.server.host, () => {
    console.log(
      `JARVIS Autonomous Operating System [${config.runtime.nodeEnv}] online on http://${config.server.host}:${PORT}`
    );
  });
}

startServer().catch((err) => {
  console.error('Fatal JARVIS server boot error:', err);
  process.exit(1);
});
