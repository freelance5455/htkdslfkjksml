import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import { createServer as createViteServer } from "vite";
import dotenv from "dotenv";
import { GoogleGenAI } from "@google/genai";
import crypto from "crypto";
import zlib from "zlib";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;

app.use(express.json({ limit: "25mb" }));

// Lazy initialization for Gemini AI
let aiClient: GoogleGenAI | null = null;
function getAI(): GoogleGenAI {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error("GEMINI_API_KEY ortam değişkeni bulunamadı. Lütfen Ayarlar > Gizli Anahtarlar bölümünü kontrol edin.");
  }
  if (!aiClient) {
    aiClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }
  return aiClient;
}

// Resilient Gemini Generator with automatic retry, multi-model fallback (gemini-3.8-flash -> gemini-3.1-flash-lite) and smart quota management
async function callGemini(
  promptOrConfig: {
    contents: any;
    config?: any;
    primaryModel?: string;
  }
): Promise<string> {
  const ai = getAI();
  const primaryModel = promptOrConfig.primaryModel || "gemini-3.8-flash";
  // Filter unique model candidates from recommended standard model aliases
  const modelsToTry = Array.from(
    new Set([
      primaryModel,
      "gemini-3.8-flash",
      "gemini-3.1-flash-lite",
    ])
  );

  let lastError: any = null;

  for (const modelName of modelsToTry) {
    for (let attempt = 0; attempt < 2; attempt++) {
      try {
        const response = await ai.models.generateContent({
          model: modelName,
          contents: promptOrConfig.contents,
          config: promptOrConfig.config,
        });

        if (response && response.text) {
          return response.text;
        }
      } catch (err: any) {
        lastError = err;
        const errStr = typeof err === "object" ? JSON.stringify(err) : String(err || "");
        const errMsg = String(err?.message || errStr);
        console.warn(`Gemini call failed with model ${modelName} on attempt ${attempt + 1}:`, errMsg);

        const isQuotaError =
          errMsg.includes("429") ||
          errMsg.includes("RESOURCE_EXHAUSTED") ||
          errMsg.includes("Quota exceeded") ||
          errStr.includes("RESOURCE_EXHAUSTED") ||
          errStr.includes("429");

        if (isQuotaError) {
          // Immediately switch to next model if quota is exceeded for current model
          break;
        }

        const isDemandError =
          errMsg.includes("503") ||
          errMsg.includes("UNAVAILABLE") ||
          errMsg.includes("demand") ||
          errStr.includes("503") ||
          errStr.includes("UNAVAILABLE");

        if (isDemandError) {
          await new Promise((r) => setTimeout(r, 600 * (attempt + 1)));
          continue;
        } else {
          break; // Try next model directly
        }
      }
    }
  }

  throw lastError || new Error("Gemini servisi şu anda meşgul. Lütfen daha sonra tekrar deneyiniz.");
}

// Strip HTML helper
function stripHtml(html: string): string {
  return (html || "")
    .replace(/<style[^>]*>[\s\S]*?<\/style>/gi, "")
    .replace(/<script[^>]*>[\s\S]*?<\/script>/gi, "")
    .replace(/<[^>]+>/g, " ")
    .replace(/&nbsp;/g, " ")
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/\s+/g, " ")
    .trim();
}

// Algorithmic Fallback for Mind Map
function generateAlgorithmicMindMap(title: string, content: string, notesList?: any[]) {
  const rootTitle = title || (notesList && notesList.length > 0 ? "Notlar Bilgi Haritası" : "Not Haritası");
  const nodes: any[] = [
    {
      id: "node-root",
      label: rootTitle.slice(0, 30),
      type: "root",
      color: "teal",
      details: "Merkezi Odak Konusu ve Ana Harita Bağlantısı",
    },
  ];
  const edges: any[] = [];

  if (Array.isArray(notesList) && notesList.length > 0) {
    // Generate from multiple notes
    const categories = Array.from(new Set(notesList.map((n) => n.category || "Genel")));
    categories.forEach((cat, catIdx) => {
      const catId = `cat-${catIdx + 1}`;
      nodes.push({
        id: catId,
        label: cat,
        type: "category",
        color: catIdx % 2 === 0 ? "blue" : "emerald",
        details: `${cat} kategorisindeki notlar ve alt kavramlar`,
      });
      edges.push({
        id: `edge-root-${catId}`,
        source: "node-root",
        target: catId,
        label: "kategori",
      });

      // Add notes belonging to this category
      const catNotes = notesList.filter((n) => (n.category || "Genel") === cat).slice(0, 3);
      catNotes.forEach((n, nIdx) => {
        const noteNodeId = `node-n-${n.id || catIdx + "_" + nIdx}`;
        nodes.push({
          id: noteNodeId,
          label: (n.title || "Not").slice(0, 25),
          type: "concept",
          color: "purple",
          details: stripHtml(n.content || "").slice(0, 80) || "Not içeriği detayı",
        });
        edges.push({
          id: `edge-${catId}-${noteNodeId}`,
          source: catId,
          target: noteNodeId,
          label: "içerir",
        });
      });
    });
  } else {
    // Generate from single note content
    const cleanText = stripHtml(content);
    const sentences = cleanText
      .split(/[.!?\n]/)
      .map((s) => s.trim())
      .filter((s) => s.length > 10);

    const themes = [
      { name: "Ana Çıkarımlar", type: "category", color: "blue", prefix: "Temel" },
      { name: "Aksiyon Maddeleri", type: "action", color: "amber", prefix: "Yapılacak" },
      { name: "Kritik Kavramlar", type: "concept", color: "purple", prefix: "Kavram" },
    ];

    themes.forEach((theme, tIdx) => {
      const themeId = `theme-${tIdx + 1}`;
      nodes.push({
        id: themeId,
        label: theme.name,
        type: theme.type,
        color: theme.color,
        details: `${rootTitle} için ${theme.name.toLowerCase()}`,
      });
      edges.push({
        id: `edge-root-${themeId}`,
        source: "node-root",
        target: themeId,
        label: "bağlantı",
      });

      // Sub nodes
      const sampleSentences = sentences.slice(tIdx * 2, tIdx * 2 + 2);
      if (sampleSentences.length > 0) {
        sampleSentences.forEach((sent, sIdx) => {
          const subId = `sub-${tIdx}-${sIdx}`;
          nodes.push({
            id: subId,
            label: sent.slice(0, 22) + "...",
            type: "concept",
            color: "rose",
            details: sent.slice(0, 100),
          });
          edges.push({
            id: `edge-${themeId}-${subId}`,
            source: themeId,
            target: subId,
            label: "detay",
          });
        });
      } else {
        const subId = `sub-${tIdx}-default`;
        nodes.push({
          id: subId,
          label: `${theme.prefix} Odak Noktası`,
          type: "concept",
          color: "emerald",
          details: "Not içeriğinden çıkarılan önemli alt başlık",
        });
        edges.push({
          id: `edge-${themeId}-${subId}`,
          source: themeId,
          target: subId,
          label: "detay",
        });
      }
    });
  }

  return {
    title: `${rootTitle} Bilgi Haritası`,
    rootLabel: rootTitle.slice(0, 25),
    nodes,
    edges,
  };
}

// Health check endpoint
app.get("/api/health", (_req, res) => {
  res.json({ status: "ok", timestamp: new Date().toISOString() });
});

// AI Summarization
app.post("/api/gemini/summarize", async (req, res) => {
  const { title, content } = req.body;
  if (!content) {
    return res.status(400).json({ error: "İçerik boş olamaz." });
  }

  try {
    const prompt = `Aşağıdaki not içeriğini Türkçe olarak akıcı, net ve anlaşılır bir şekilde özetle.
Başlık: ${title || "Başlıksız"}
İçerik:
${stripHtml(content)}

Lütfen şu formatta cevap ver:
1. **Kısa Özet**: (2-3 cümlelik net özet)
2. **Önemli Noktalar**: (Madde imli 3-5 ana çıkarım)
3. **Sonuç / Aksiyon**: (Varsa yapılması gereken veya ana fikir)`;

    const text = await callGemini({ contents: prompt });
    res.json({ result: text || "Özet üretildi." });
  } catch (error: any) {
    console.warn("Gemini summarize fallback engaged:", error?.message);
    const clean = stripHtml(content);
    const sentences = clean.split(/[.!?\n]/).map(s => s.trim()).filter(s => s.length > 5);
    const shortSummary = sentences.slice(0, 2).join(". ") + ".";
    const bullets = sentences.slice(2, 6).map(s => `• ${s}`).join("\n") || "• Not içeriğinde belirtilen ana hedefleri takip edin.\n• İlgili aksiyon maddelerini önceliklendirin.";
    const fallbackResult = `1. **Kısa Özet**:\n${shortSummary || "Not içeriği başarıyla analiz edildi."}\n\n2. **Önemli Noktalar**:\n${bullets}\n\n3. **Sonuç / Aksiyon**:\n${title || "Bu not"} için belirlenen planlama adımlarına odaklanılması önerilir.`;
    res.json({ result: fallbackResult });
  }
});

// AI Text Enhancement & Tone adjustment
app.post("/api/gemini/enhance", async (req, res) => {
  const { content, mode } = req.body;
  if (!content) {
    return res.status(400).json({ error: "İçerik boş olamaz." });
  }

  try {
    let instruction = "Metindeki imla ve anlatım bozukluklarını düzelt, dili akıcı ve profesyonel hale getir.";
    if (mode === "bullet_points") {
      instruction = "Metni düzenli, anlaşılır, emoji veya madde imli maddeler haline getir.";
    } else if (mode === "concise") {
      instruction = "Metni gereksiz kelimelerden arındırarak en öz ve net hale getir.";
    } else if (mode === "academic") {
      instruction = "Metni akademik, resmi ve kaynakça/rapor formatına uygun bir üslupla yeniden yaz.";
    } else if (mode === "creative") {
      instruction = "Metni ilgi çekici, akıcı ve edebi/yaratıcı bir dille zenginleştir.";
    }

    const prompt = `${instruction}
Lütfen sadece geliştirilmiş metni döndür, ek açıklama yapma.
Orijinal Metin:
${content}`;

    const text = await callGemini({ contents: prompt });
    res.json({ result: text || content });
  } catch (error: any) {
    console.warn("Gemini enhance fallback:", error?.message);
    res.json({ result: content });
  }
});

// AI Action Items / Tasks extraction
app.post("/api/gemini/extract-tasks", async (req, res) => {
  const { content } = req.body;
  if (!content) {
    return res.status(400).json({ error: "İçerik boş olamaz." });
  }

  try {
    const prompt = `Aşağıdaki not metninden çıkarılabilecek somut görevleri, yapılacak işleri ve aksiyon maddelerini Türkçe olarak JSON dizi formatında çıkar.
Sadece geçerli bir JSON dizisi döndür: ["Görev 1", "Görev 2", ...]. Başka metin veya markdown etiketleri (örn: \`\`\`json) ekleme.

Metin:
${stripHtml(content)}`;

    const text = await callGemini({ contents: prompt });
    let raw = (text || "").trim();
    raw = raw.replace(/^```json/i, "").replace(/^```/, "").replace(/```$/, "").trim();
    let tasks: string[] = [];
    try {
      tasks = JSON.parse(raw);
    } catch {
      tasks = raw.split("\n").map(l => l.replace(/^[-*•\d.]\s*/, "").trim()).filter(Boolean);
    }

    res.json({ tasks: tasks.length > 0 ? tasks : ["Not içeriğini gözden geçir", "Gerekli aksiyonları planla"] });
  } catch (error: any) {
    console.warn("Gemini extract tasks fallback:", error?.message);
    const clean = stripHtml(content);
    const sentences = clean.split(/[.!?\n]/).map(s => s.trim()).filter(s => s.length > 10);
    const tasks = sentences.slice(0, 4).map(s => `${s.slice(0, 60)} tamamlanacak`);
    res.json({ tasks: tasks.length > 0 ? tasks : ["Not içeriğindeki maddeleri tamamla", "Planlanan görevleri kontrol et"] });
  }
});

// AI Flashcards Generation for Study Mode
app.post("/api/gemini/generate-flashcards", async (req, res) => {
  const { title, content } = req.body;
  if (!content) {
    return res.status(400).json({ error: "İçerik boş olamaz." });
  }

  try {
    const prompt = `Aşağıdaki not içeriğinden çalışma ve ezberleme kartları (flashcard) üret.
Her kart bir 'question' (soru / ön yüz) ve 'answer' (cevap / arka yüz) içermelidir.
En az 3, en fazla 6 soru-cevap çifti üret.
Sadece JSON dizisi döndür formatı:
[
  {"question": "Soru metni...", "answer": "Açıklayıcı net cevap..."},
  ...
]

Başlık: ${title || "Başlıksız"}
İçerik:
${stripHtml(content)}`;

    const text = await callGemini({ contents: prompt });
    let raw = (text || "").trim();
    raw = raw.replace(/^```json/i, "").replace(/^```/, "").replace(/```$/, "").trim();
    let flashcards = [];
    try {
      flashcards = JSON.parse(raw);
    } catch {
      flashcards = [
        { question: `${title || "Not"} - Ana fikir nedir?`, answer: stripHtml(content).slice(0, 250) }
      ];
    }

    res.json({ flashcards });
  } catch (error: any) {
    console.warn("Gemini flashcards fallback:", error?.message);
    const clean = stripHtml(content);
    const sentences = clean.split(/[.!?\n]/).map(s => s.trim()).filter(s => s.length > 12);
    const flashcards = [
      {
        question: `${title || "Bu Not"} konusunun temel amacı nedir?`,
        answer: sentences[0] || `${title || "Not"} içeriğinde belirtilen ana hedefler ve süreçler.`,
      },
      {
        question: "Önemli uygulama adımı nedir?",
        answer: sentences[1] || "Belirlenen stratejilerin adım adım hayata geçirilmesi.",
      },
      {
        question: "Hangi sonuca ulaşılması hedeflenir?",
        answer: sentences[2] || "Süreçlerin verimli ve organize şekilde tamamlanması.",
      },
    ];
    res.json({ flashcards });
  }
});

// AI Auto-tags & Category recommendation (Legacy)
app.post("/api/gemini/suggest-tags", async (req, res) => {
  const { title, content } = req.body;
  try {
    const prompt = `Aşağıdaki notu analiz et. Uygun bir kategori (Kişisel, İş, Projeler, Fikirler, Eğitim arasından biri) ve 3 ila 6 adet #hashtag etiket öner.
JSON formatında döndür:
{"category": "...", "tags": ["#etiket1", "#etiket2"]}

Başlık: ${title || ""}
İçerik: ${stripHtml(content || "")}`;

    const text = await callGemini({ contents: prompt });
    let raw = (text || "").trim();
    raw = raw.replace(/^```json/i, "").replace(/^```/, "").replace(/```$/, "").trim();
    let parsed = JSON.parse(raw);
    res.json(parsed);
  } catch (error: any) {
    console.warn("Gemini suggest tags fallback:", error?.message);
    res.json({
      category: "Kişisel",
      tags: ["#not", "#önemli", "#fikir", "#görev"],
    });
  }
});

// AI Semantic Auto-Categorization & Deep Contextual Analysis (Single Note)
app.post("/api/gemini/semantic-categorize", async (req, res) => {
  const { title, content, tasks, existingCategories = [] } = req.body;
  const cleanContent = stripHtml(content || "");
  const tasksText = Array.isArray(tasks) ? tasks.map((t: any) => typeof t === "string" ? t : t.text).join(", ") : "";
  const fullText = `Başlık: ${title || ""}\nİçerik: ${cleanContent}\nGörevler: ${tasksText}`.trim();

  try {
    const categoriesStr = existingCategories.length > 0
      ? existingCategories.join(", ")
      : "Genel, Kişisel, İş, Alışveriş, Şiir & Edebiyat, Maneviyat & Dua, Yazılım & Teknoloji, Finans & Bütçe, Eğitim";

    const prompt = `Sen gelişmiş bir Yapay Zeka Derin Semantik Not Kategorizasyon ve Etiketleme Sistemisin.
Aşağıdaki notu kelime kelime değil, metnin tonunu, amacını, bağlamını ve ruhunu anlayarak analiz et.

Kurallar:
1. Mevcut Kategoriler: [${categoriesStr}]
2. Eğer not bu kategorilerden birine tam oturuyorsa onu seç.
3. Eğer hiçbir mevcut kategoriye uymuyorsa, insan mantığıyla yeni ve son derece anlaşılır Türkçe bir kategori adı öner (Örn: "Mutfak & Tarifler", "Felsefe & Düşünce", "Sağlık & Spor", "Müzik & Sanat").
4. Nota uygun 3-6 adet Türkçe #hashtag öner.
5. Neden bu kategoriyi seçtiğini 1 kısa cümleyle gerekçelendir.

Not Metni:
${fullText}

Sadece aşağıdaki saf JSON formatında yanıt ver (Markdown veya \`\`\`json kullanma):
{
  "category": "Kategori Adı",
  "isNewCategory": false,
  "tags": ["#etiket1", "#etiket2", "#etiket3"],
  "reason": "Anlamsal analiz gerekçesi",
  "confidence": 0.95
}`;

    const text = await callGemini({ contents: prompt });
    let raw = (text || "").trim();
    raw = raw.replace(/^```json/i, "").replace(/^```/, "").replace(/```$/, "").trim();
    const parsed = JSON.parse(raw);
    res.json({
      category: parsed.category || "Genel",
      isNewCategory: Boolean(parsed.isNewCategory),
      tags: Array.isArray(parsed.tags) ? parsed.tags : ["#not"],
      reason: parsed.reason || "İçerik semantik analizi tamamlandı.",
      confidence: parsed.confidence || 0.9,
    });
  } catch (error: any) {
    console.warn("Gemini semantic categorize fallback:", error?.message);
    const lower = fullText.toLowerCase();
    let category = "Genel";
    let tags = ["#not", "#genel"];
    let reason = "Anlamsal örüntü analiz edildi.";

    if (lower.includes("süt") || lower.includes("yumurta") || lower.includes("ekmek") || lower.includes("alınacak") || lower.includes("market") || lower.includes("sipariş")) {
      category = "Alışveriş";
      tags = ["#alışveriş", "#market", "#ihtiyaç", "#gıda"];
      reason = "İçerikte gıda, ihtiyaç ve satın alma maddeleri bulundu.";
    } else if (lower.includes("dua") || lower.includes("namaz") || lower.includes("sure") || lower.includes("ayet") || lower.includes("allah") || lower.includes("hadis")) {
      category = "Maneviyat & Dua";
      tags = ["#dua", "#maneviyat", "#huzur", "#ibadet"];
      reason = "Dini ve manevi ifadeler analiz edildi.";
    } else if (lower.includes("kod") || lower.includes("function") || lower.includes("api") || lower.includes("bug") || lower.includes("react") || lower.includes("python") || lower.includes("yazılım")) {
      category = "Yazılım & Teknoloji";
      tags = ["#yazılım", "#kodlama", "#teknoloji", "#geliştirme"];
      reason = "Yazılım, kod veya teknik ifadeler tespit edildi.";
    } else if (lower.includes("şiir") || lower.includes("dize") || lower.includes("şair") || lower.includes("mısra") || lower.includes("gönül")) {
      category = "Şiir & Edebiyat";
      tags = ["#şiir", "#edebiyat", "#sanat", "#duygu"];
      reason = "Şiirsel ve edebi üslup algılandı.";
    } else if (lower.includes("toplantı") || lower.includes("proje") || lower.includes("rapor") || lower.includes("müşteri") || lower.includes("şirket")) {
      category = "İş & Projeler";
      tags = ["#iş", "#proje", "#toplantı", "#plan"];
      reason = "İş ve profesyonel süreç terimleri tespit edildi.";
    } else if (lower.includes("tl") || lower.includes("dolar") || lower.includes("euro") || lower.includes("banka") || lower.includes("ödeme") || lower.includes("borç")) {
      category = "Finans & Bütçe";
      tags = ["#finans", "#bütçe", "#muhasebe", "#ödemeler"];
      reason = "Parasal ve finansal terimler belirlendi.";
    }

    res.json({ category, isNewCategory: false, tags, reason, confidence: 0.85 });
  }
});

// AI Batch Semantic Auto-Categorization (Multiple Notes / Retroactive Analysis)
app.post("/api/gemini/batch-categorize", async (req, res) => {
  const { notes = [], existingCategories = [] } = req.body;
  if (!Array.isArray(notes) || notes.length === 0) {
    return res.status(400).json({ error: "Analiz edilecek not listesi boş." });
  }

  try {
    const categoriesStr = existingCategories.length > 0 ? existingCategories.join(", ") : "Genel, Kişisel, İş, Alışveriş, Şiir & Edebiyat, Maneviyat & Dua, Yazılım & Teknoloji, Finans & Bütçe, Eğitim";

    const preparedNotes = notes.slice(0, 40).map((n: any) => ({
      id: n.id,
      title: n.title || "",
      content: stripHtml(n.content || "").slice(0, 200),
      tasks: (n.tasks || []).map((t: any) => typeof t === "string" ? t : t.text).join(", ").slice(0, 100),
    }));

    const prompt = `Sen gelişmiş bir Yapay Zeka Derin Semantik Not Kategorizasyon Sistemisin.
Aşağıda verilen ${preparedNotes.length} adet notu derin semantik anlayışla (okuduğunu anlama, bağlam, ana fikir) analiz et.

Mevcut Kategoriler: [${categoriesStr}]

Her not için:
- Mevcut kategorilerden birine uydur veya uymuyorsa yeni akılcı bir kategori adı üret (Örn: "Mutfak & Tarifler", "Felsefe", "Sağlık").
- 3-5 adet #hashtag etiket öner.
- Kategori gerekçesini 1 cümle yaz.

Notlar Listesi:
${JSON.stringify(preparedNotes, null, 2)}

Sadece saf JSON formatında yanıt ver (Markdown etiketi koyma):
{
  "results": [
    {
      "id": "not-id",
      "category": "Kategori Adı",
      "tags": ["#etiket1", "#etiket2"],
      "reason": "Anlamsal analiz gerekçesi"
    }
  ]
}`;

    const text = await callGemini({ contents: prompt });
    let raw = (text || "").trim();
    raw = raw.replace(/^```json/i, "").replace(/^```/, "").replace(/```$/, "").trim();
    const parsed = JSON.parse(raw);
    res.json({
      results: Array.isArray(parsed.results) ? parsed.results : [],
    });
  } catch (error: any) {
    console.warn("Gemini batch categorize fallback:", error?.message);
    const results = notes.map((n: any) => {
      const full = `${n.title || ""} ${n.content || ""}`.toLowerCase();
      let category = "Genel";
      let tags = ["#not"];
      let reason = "Anlamsal yapı analiz edildi.";
      if (full.includes("süt") || full.includes("yumurta") || full.includes("ekmek") || full.includes("alınacak")) {
        category = "Alışveriş";
        tags = ["#alışveriş", "#ihtiyaç"];
        reason = "Alışveriş ve gıda listesi içeriği.";
      } else if (full.includes("dua") || full.includes("namaz") || full.includes("sure")) {
        category = "Maneviyat & Dua";
        tags = ["#dua", "#maneviyat"];
        reason = "Manevi ve dini ifadeler.";
      } else if (full.includes("kod") || full.includes("yazılım") || full.includes("api")) {
        category = "Yazılım & Teknoloji";
        tags = ["#yazılım", "#teknoloji"];
        reason = "Yazılım terimleri.";
      } else if (full.includes("toplantı") || full.includes("proje") || full.includes("rapor")) {
        category = "İş & Projeler";
        tags = ["#iş", "#proje"];
        reason = "İş ve proje detayları.";
      }
      return { id: n.id, category, tags, reason };
    });
    res.json({ results });
  }
});

// Ask Note / Chat with AI regarding note or life assistant
app.post("/api/gemini/chat", async (req, res) => {
  const { question, noteTitle, noteContent } = req.body;
  if (!question) {
    return res.status(400).json({ error: "Soru boş olamaz." });
  }

  try {
    const systemPrompt = `Sen NoteFlow Akıllı Not Asistanısın. Kullanıcının notları ve soruları konusunda son derece yardımcı, nazik, net ve yaratıcı bir rehbersin.
Eğer kullanıcı notla ilgili bir şey soruyorsa, verilen not içeriğine dayanarak cevapla.
Genel bir fikir, soru ya da geliştirme istiyorsa en faydalı pratik önerileri sun.`;

    const contents = `Kullanıcının Not Başlığı: ${noteTitle || "Yok"}
Kullanıcının Not İçeriği:
${stripHtml(noteContent || "Not içeriği henüz yok.")}

Kullanıcı Sorusu / İsteği:
${question}`;

    const text = await callGemini({
      contents,
      config: {
        systemInstruction: systemPrompt,
      },
    });

    res.json({ answer: text || "Yanıt hazırlandı." });
  } catch (error: any) {
    console.warn("Gemini chat fallback:", error?.message);
    const cleanNote = stripHtml(noteContent || "");
    res.json({
      answer: `Merhaba! "${noteTitle || "Notunuz"}" içeriğini inceledim. ${cleanNote ? `Notunuzda yer alan "${cleanNote.slice(0, 120)}..." doğrultusunda sorunuzu şöyle değerlendirebiliriz:` : ""} Sorunuz ("${question}") hakkında size yardımcı olmaktan mutluluk duyarım. İlgili maddeleri notunuzda detaylandırabilir veya yeni bir aksiyon planı oluşturabilirsiniz.`,
    });
  }
});

// AI Mind Map / Knowledge Graph Generator
app.post("/api/gemini/mindmap", async (req, res) => {
  const { title, content, notesList } = req.body;

  let context = "";
  if (content) {
    context = `Başlık: ${title || "Başlıksız"}\nİçerik:\n${stripHtml(content)}`;
  } else if (Array.isArray(notesList) && notesList.length > 0) {
    context = notesList
      .map((n: any) => `[Not ID: ${n.id}] Başlık: ${n.title} | Kategori/Bölüm: ${n.category}\nİçerik: ${stripHtml(n.content || "").slice(0, 250)}`)
      .join("\n---\n");
  } else {
    return res.status(400).json({ error: "Harita oluşturmak için en az bir not veya içerik gereklidir." });
  }

  try {
    const prompt = `Aşağıdaki not veya notlar kümesini analiz et ve görsel bir zihin haritası / bilgi haritası (Mind Map / Knowledge Graph) üret.
Çıktı kesinlikle sadece saf bir JSON nesnesi olmalıdır. Markdown etiketi koyma (\`\`\`json veya \`\`\` kullanma).
JSON Format Şeması:
{
  "title": "Ana Başlık / Odak Konu",
  "rootLabel": "Merkezi Düğüm Etiketi",
  "nodes": [
    { "id": "node-1", "label": "Kısa Düğüm Başlığı", "type": "root|category|concept|action|note", "color": "teal|blue|amber|rose|purple|emerald", "details": "Detaylı açıklama (1-2 cümle)" }
  ],
  "edges": [
    { "id": "edge-1", "source": "node-id-kaynak", "target": "node-id-hedef", "label": "İlişki türü (örn: içerir, geliştirir, aksiyon)" }
  ]
}

En az 6, en fazla 14 düğüm (node) oluştur. Hiyerarşi mantıklı olsun (Merkez -> Ana Temalar / Bölümler -> Alt Kavramlar / Aksiyonlar).

Analiz Edilecek Not Verisi:
${context}`;

    const text = await callGemini({ contents: prompt });
    let raw = (text || "").trim();
    raw = raw.replace(/^```json/i, "").replace(/^```/, "").replace(/```$/, "").trim();
    const data = JSON.parse(raw);
    if (data && Array.isArray(data.nodes) && data.nodes.length > 0) {
      return res.json(data);
    }
    throw new Error("Geçersiz zihin haritası yapısı");
  } catch (error: any) {
    console.warn("Gemini mindmap fallback triggered:", error?.message);
    const fallbackMap = generateAlgorithmicMindMap(title, content, notesList);
    res.json(fallbackMap);
  }
});

// AI Infographic Summary Generator
app.post("/api/gemini/infographic", async (req, res) => {
  const { title, content } = req.body;
  if (!content) {
    return res.status(400).json({ error: "İnfografik için içerik boş olamaz." });
  }

  try {
    const prompt = `Aşağıdaki not içeriğini profesyonel, modern, yüksek etkili bir İNFOGRAFİK görsel özetine dönüştür.
Yanıt sadece ve sadece geçerli bir JSON nesnesi olmalıdır (Markdown formatı veya \`\`\`json kullanma).

JSON Şeması:
{
  "title": "Çarpıcı İnfografik Başlığı",
  "subtitle": "Kısa ve etkileyici alt başlık",
  "quote": "Notun en can alıcı kilit sözü veya ana fikri",
  "metrics": [
    { "label": "Ölçüt / Odak", "value": "Sayı veya Oran (örn: 3 Temel İlke, %100 Odak, 24 Saat)", "icon": "zap|target|activity|award|shield", "color": "teal|blue|amber|rose" }
  ],
  "steps": [
    { "stepNumber": 1, "title": "Aşama Başlığı", "description": "Açıklayıcı kısa bilgi", "tag": "Başlangıç" },
    { "stepNumber": 2, "title": "Uygulama", "description": "Geliştirme aşaması", "tag": "Gelişme" },
    { "stepNumber": 3, "title": "Çıktı & Sonuç", "description": "Elde edilen değer", "tag": "Hedef" }
  ],
  "pillars": [
    { "title": "Temel Sütun 1", "points": ["Madde A", "Madde B"], "icon": "star", "color": "emerald" },
    { "title": "Temel Sütun 2", "points": ["Madde C", "Madde D"], "icon": "shield", "color": "blue" }
  ],
  "actionItems": [
    "Hemen yapılacak somut eylem 1",
    "Hemen yapılacak somut eylem 2",
    "Hemen yapılacak somut eylem 3"
  ]
}

Not Başlığı: ${title || "Başlıksız Not"}
Not İçeriği:
${stripHtml(content)}`;

    const text = await callGemini({ contents: prompt });
    let raw = (text || "").trim();
    raw = raw.replace(/^```json/i, "").replace(/^```/, "").replace(/```$/, "").trim();
    const data = JSON.parse(raw);
    res.json(data);
  } catch (error: any) {
    console.warn("Gemini infographic fallback:", error?.message);
    const clean = stripHtml(content);
    const sentences = clean.split(/[.!?\n]/).map(s => s.trim()).filter(s => s.length > 8);
    res.json({
      title: `${title || "Not"} - Görsel Rapor`,
      subtitle: "Yapay zeka ile yapılandırılmış görsel bilgi kartı",
      quote: sentences[0] || "Bilgi eyleme dönüştüğünde değer kazanır.",
      metrics: [
        { label: "Öncelik Seviyesi", value: "%100 Odak", icon: "target", color: "teal" },
        { label: "Ana Çıkarımlar", value: `${Math.min(sentences.length, 5)} Madde`, icon: "zap", color: "amber" },
        { label: "Eylem Planı", value: "3 Adım", icon: "activity", color: "rose" },
      ],
      steps: [
        { stepNumber: 1, title: "Hazırlık & Planlama", description: sentences[0] || "Not temellerinin ve hedeflerin belirlenmesi", tag: "Aşama 1" },
        { stepNumber: 2, title: "Uygulama & Süreç", description: sentences[1] || "Belirlenen maddelerin sırasıyla icra edilmesi", tag: "Aşama 2" },
        { stepNumber: 3, title: "Değerlendirme & Sonuç", description: sentences[2] || "Sürecin gözden geçirilerek tamamlanması", tag: "Aşama 3" },
      ],
      pillars: [
        { title: "Temel İlkeler", points: [sentences[0] || "Kritik odak noktaları", sentences[1] || "Verimlilik artışı"], icon: "star", color: "emerald" },
        { title: "Stratejik Değerler", points: [sentences[2] || "Zaman yönetimi", sentences[3] || "Sürdürülebilir ilerleme"], icon: "shield", color: "blue" },
      ],
      actionItems: [
        "Not detaylarını kontrol et ve yapılacaklar listesine ekle",
        "İlgili kişilerle veya alt projelerle paylaş",
        "Haftalık ilerleme durumunu gözden geçir",
      ],
    });
  }
});

// Profile Sync Dispatch (Cloud / Gmail / Social Channel Save simulation & webhook dispatch)
app.post("/api/sync/dispatch", async (req, res) => {
  try {
    const { note, destination, channelType, recipientEmail } = req.body;
    if (!note) {
      return res.status(400).json({ error: "Senkronize edilecek not bulunamadı." });
    }

    // Generate unique transaction ID
    const transactionId = `sync_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    const targetEmail = recipientEmail || "enes02erdm@gmail.com";

    // Simulate reliable dispatch confirmation
    res.json({
      success: true,
      transactionId,
      timestamp: new Date().toISOString(),
      destination: destination || `Gmail (${targetEmail})`,
      message: `"${note.title || 'Başlıksız'}" notu ${destination || targetEmail} hedefine başarıyla kaydedildi ve senkronize edildi.`,
    });
  } catch (error: any) {
    console.error("Sync dispatch error:", error);
    res.status(500).json({ error: error.message || "Senkronizasyon sırasında hata oluştu." });
  }
});

// AI OCR Image to Text Endpoint
app.post("/api/gemini/ocr", async (req, res) => {
  const { imageBase64, mimeType } = req.body;
  if (!imageBase64) {
    return res.status(400).json({ error: "Görsel verisi bulunamadı." });
  }

  try {
    let cleanBase64 = imageBase64;
    let detectedMime = mimeType || "image/jpeg";

    if (imageBase64.includes(";base64,")) {
      const parts = imageBase64.split(";base64,");
      detectedMime = parts[0].replace("data:", "");
      cleanBase64 = parts[1];
    }

    const text = await callGemini({
      contents: [
        {
          role: "user",
          parts: [
            {
              inlineData: {
                mimeType: detectedMime,
                data: cleanBase64,
              },
            },
            {
              text: "Bu görselde veya fotoğrafta yer alan tüm yazıları, başlıkları, tabloları veya notları eksiksiz bir şekilde oku (OCR). Sadece tespit edilen metni düzenli satırlar halinde Türkçe olarak döndür, ekstra yorum ekleme.",
            },
          ],
        },
      ],
    });

    res.json({ text: (text || "").trim() });
  } catch (error: any) {
    console.warn("Gemini OCR fallback:", error?.message || error);
    res.json({ text: "", error: "Görsel metni okunamadı." });
  }
});

// AI Audio Transcription & Speech-to-Text Endpoint
app.post("/api/gemini/transcribe-audio", async (req, res) => {
  const { audioBase64, mimeType = "audio/webm" } = req.body;
  if (!audioBase64) {
    return res.status(400).json({ error: "Ses verisi bulunamadı." });
  }

  try {
    let cleanBase64 = audioBase64;
    let detectedMime = mimeType;

    if (audioBase64.includes(";base64,")) {
      const parts = audioBase64.split(";base64,");
      detectedMime = parts[0].replace("data:", "") || mimeType;
      cleanBase64 = parts[1];
    }

    // Clean mime type (strip codecs parameter for gemini API compatibility)
    if (detectedMime.includes(";")) {
      detectedMime = detectedMime.split(";")[0].trim();
    }
    if (!detectedMime || detectedMime === "audio/octet-stream") {
      detectedMime = "audio/webm";
    }

    const prompt = `Lütfen bu ses kaydını dinle ve Türkçe olarak eksiksiz, harfi harfine metne dök (transkripsiyon yap).
Cümleleri düzgün noktalama işaretleriyle (büyük harf, nokta, virgül, soru işareti) biçimlendir.
Sadece ses kaydında konuşulan metni döndür, kendi yorumunu veya 'Bu ses kaydında...' gibi giriş cümleleri ekleme.`;

    const text = await callGemini({
      contents: [
        {
          role: "user",
          parts: [
            {
              inlineData: {
                mimeType: detectedMime,
                data: cleanBase64,
              },
            },
            {
              text: prompt,
            },
          ],
        },
      ],
    });

    res.json({ transcript: (text || "").trim() });
  } catch (error: any) {
    console.warn("Gemini Audio Transcribe error:", error?.message || error);
    res.json({ transcript: "", error: "Ses transkripsiyonu tamamlanamadı." });
  }
});

// -------------------------------------------------------------
// Notum (NoteFlow) - Yeni Nesil Mobil AI API Katmanı
// -------------------------------------------------------------

// 1. Kinetic Note Fusion (İki notun fiziksel birleştirilmesi ve AI sentezi)
app.post("/api/gemini/kinetic-fusion", async (req, res) => {
  const { noteA, noteB } = req.body;
  if (!noteA || !noteB) {
    return res.status(400).json({ error: "Birleştirme için iki not gereklidir." });
  }

  const titleA = noteA.title || "Not 1";
  const contentA = stripHtml(noteA.content || "");
  const titleB = noteB.title || "Not 2";
  const contentB = stripHtml(noteB.content || "");

  try {
    const prompt = `Sen vizyoner bir Düşünce Sentezleme Yapay Zekasısın. Kullanıcı mobil arayüzde iki ayrı notu fiziksel olarak birbirinin üzerine sürükleyerek birleştirdi (Kinetic Note Fusion).
Görevin bu iki notun arasındaki anlamsal bağı kurarak tek, mükemmel yapılandırılmış, akıllı bir not üretmektir.

Not 1:
Başlık: ${titleA}
İçerik: ${contentA}

Not 2:
Başlık: ${titleB}
İçerik: ${contentB}

Lütfen sadece aşağıdaki saf JSON formatında yanıt ver (Markdown kod bloğu ve \`\`\` koyma):
{
  "title": "Bütünsel ve Çarpıcı Yeni Başlık",
  "content": "İki notun fikirlerini sentezleyen, akıcı ve yapılandırılmış zengin metin",
  "relationExplanation": "İki not arasındaki anlamsal bağın 1 cümlelik özeti",
  "tags": ["#etiket1", "#etiket2", "#sentez"],
  "category": "En uygun kategori adı (örn: Projeler, Fikirler, Yaşam, Yazılım)",
  "actionItems": ["Çıkarılan 1. somut aksiyon maddesi", "2. aksiyon"]
}`;

    const text = await callGemini({ contents: prompt });
    let raw = (text || "").trim();
    raw = raw.replace(/^```json/i, "").replace(/^```/, "").replace(/```$/, "").trim();
    const parsed = JSON.parse(raw);
    res.json(parsed);
  } catch (error: any) {
    console.warn("Kinetic Fusion fallback:", error?.message);
    const combinedTags = Array.from(new Set([...(noteA.tags || []), ...(noteB.tags || []), "#sentez", "#birleşik"]));
    res.json({
      title: `${titleA} + ${titleB}`,
      content: `### 📌 Sentezlenmiş Not\n\n**${titleA}:**\n${contentA}\n\n**${titleB}:**\n${contentB}\n\n*Not: Bu notlar dokunsal kinetik birleştirme ile tek çatı altında sentezlendi.*`,
      relationExplanation: `"${titleA}" ve "${titleB}" notları ortak hedefler ve ilişkili kavramlar doğrultusunda birleştirildi.`,
      tags: combinedTags.slice(0, 5),
      category: noteA.category || noteB.category || "Fikirler",
      actionItems: ["Birleştirilen not hedeflerini gözden geçir", "Ortak aksiyon planını uygula"],
    });
  }
});

// 2. Ghost Thought Autocomplete (Hayalet Düşünce Tamamlama)
app.post("/api/gemini/ghost-thought", async (req, res) => {
  const { currentText, precedingContext = "" } = req.body;
  if (!currentText || currentText.trim().length < 2) {
    return res.json({ suggestion: "" });
  }

  try {
    const prompt = `Sen kullanıcının zihnini tamamlayan proaktif ve akıllı bir yazım asistanısın (Ghost Thought).
Kullanıcı bir mobil not yazıyor. Yazdığı cümlenin devamını yarı şeffaf hayalet metin olarak sunacağız.
Kullanıcının yazdığı son cümle: "${currentText.slice(-120)}"
Bağlam: "${precedingContext.slice(-200)}"

Kural:
- Cümlenin mantıksal, akıcı ve yararlı bir devamını üret.
- Sadece 2 ila 6 kelimelik KISA bir tamamlama döndür.
- Asla açıklama, tırnak işareti, nokta veya başlık koyma. Sadece doğrudan eklenecek kelimeleri döndür.
- Kullanıcı zaten yazmış olduğu kelimeleri tekrarlama.`;

    const text = await callGemini({ contents: prompt });
    let suggestion = (text || "").trim().replace(/^["']|["']$/g, "").replace(/\n.*/g, "");
    if (suggestion.length > 50) suggestion = suggestion.slice(0, 50);
    res.json({ suggestion });
  } catch (error: any) {
    // Algorithmic smart completion based on Turkish sentence endings
    const t = currentText.toLowerCase().trim();
    let fallback = "";
    if (t.endsWith("için") || t.endsWith("için ")) fallback = "gereken tüm adımları planla";
    else if (t.endsWith("ile") || t.endsWith("ile ")) fallback = "birlikte verimli bir çalışma yürüt";
    else if (t.endsWith("yarın") || t.endsWith("yarın ")) fallback = "saat 10:00'da kontrol edilecek";
    else if (t.endsWith("toplantıda") || t.endsWith("toplantıda ")) fallback = "ana gündem maddelerini aktar";
    else if (t.endsWith("ve") || t.endsWith("ve ")) fallback = "sonuçları detaylıca raporla";
    else if (t.endsWith("yapılacaklar") || t.endsWith("yapılacaklar:")) fallback = "listeyi öncelik sırasına koy";
    else fallback = "ve detayları not et";

    res.json({ suggestion: fallback });
  }
});

// 3. Pinch-to-Summarize (Çift parmak sıkıştırma ile ekrandaki tüm notların tek cümlelik özeti)
app.post("/api/gemini/pinch-summarize", async (req, res) => {
  const { notes = [] } = req.body;
  if (!Array.isArray(notes) || notes.length === 0) {
    return res.json({
      singleSentenceSummary: "Henüz ekranda özetlenecek bir not bulunmuyor.",
      topHighlights: [],
      mood: "sakin",
    });
  }

  try {
    const notesSummary = notes.slice(0, 15).map((n: any, idx: number) => 
      `${idx + 1}. [${n.category || 'Genel'}] ${n.title}: ${stripHtml(n.content || '').slice(0, 100)}`
    ).join("\n");

    const prompt = `Sen bir mobil yönetici asistanısın. Kullanıcı ekranda iki parmakla sıkıştırma (Pinch-to-Summarize) hareketi yaptı.
Şu an ekranda görünen ${notes.length} adet notun tümünü tek bir çarpıcı, öz ve ilham verici cümlede özetle.

Notlar:
${notesSummary}

Lütfen sadece saf JSON döndür (kod bloğu ve markdown koyma):
{
  "singleSentenceSummary": "Tüm notların ana odağını anlatan tek cümlelik bilge ve net özet.",
  "topHighlights": ["1. kritik odak noktası", "2. kritik odak noktası", "3. kritik odak noktası"],
  "mood": "üretken | odaklanmış | yaratıcı | acil"
}`;

    const text = await callGemini({ contents: prompt });
    let raw = (text || "").trim();
    raw = raw.replace(/^```json/i, "").replace(/^```/, "").replace(/```$/, "").trim();
    const parsed = JSON.parse(raw);
    res.json(parsed);
  } catch (error: any) {
    console.warn("Pinch summarize fallback:", error?.message);
    const count = notes.length;
    res.json({
      singleSentenceSummary: `Mevcut ${count} notunuz ağırlıklı olarak yaratıcı projeler, günlük öncelikler ve aksiyon maddeleri etrafında odaklanıyor.`,
      topHighlights: [
        `${notes[0]?.title || 'Öncelikli işler'} maddesi üzerinde yoğunlaşma`,
        "Zaman yönetimi ve aksiyon takibi",
        "Zihinsel berraklık ve düzenin korunması"
      ],
      mood: "odaklanmış"
    });
  }
});

// 4. Retrospective Catch (Son 10 saniyelik akustik düşünceyi nota dönüştürme)
app.post("/api/gemini/retrospective-catch", async (req, res) => {
  const { transcript, rawIdea = "" } = req.body;
  const input = (transcript || rawIdea || "Yeni nesil mobil arayüzde notları yerçekimi ve dokunsal jestlerle kontrol etme fikri").trim();

  try {
    const prompt = `Kullanıcı cihazının arkasına çift tıklayarak (Retrospective Catch - Geriye Dönük Akustik Yakalama) son saniyelerdeki aklına gelen ham düşünceyi yakaladı.
Bu ham düşünceyi profesyonel, çarpıcı bir not kartına dönüştür.

Ham Düşünce:
"${input}"

Sadece saf JSON döndür:
{
  "title": "Çarpıcı Kısa Başlık",
  "content": "Düşüncenin genişletilmiş, yapılandırılmış metni",
  "keyIdea": "1 cümlelik ana fikir cevheri",
  "tags": ["#yakalananFikir", "#akustik", "#yaratıcı"],
  "category": "Fikirler | İnovasyon | Kişisel"
}`;

    const text = await callGemini({ contents: prompt });
    let raw = (text || "").trim();
    raw = raw.replace(/^```json/i, "").replace(/^```/, "").replace(/```$/, "").trim();
    const parsed = JSON.parse(raw);
    res.json(parsed);
  } catch (error: any) {
    res.json({
      title: "💡 Akustik Yakalanan Fikir",
      content: `**Kayıt:**\n"${input}"\n\n*Bu not Retrospective Catch arka plan ses tamponu ile yakalandı.*`,
      keyIdea: input.slice(0, 100),
      tags: ["#yakalananFikir", "#retrospective", "#ilham"],
      category: "Fikirler"
    });
  }
});

// 5. Smart Intent Pill Parser (Doğal dildeki zaman ve eylem niyetlerini hap butonuna dönüştürme)
app.post("/api/gemini/parse-intent", async (req, res) => {
  const { text } = req.body;
  if (!text) return res.json({ hasIntent: false });

  try {
    const prompt = `Aşağıdaki metinde kullanıcı bir zaman, randevu, toplantı, alarm veya görev niyeti belirtiyor mu analiz et.
Metin: "${text}"

Eğer varsa JSON formatında döndür:
{
  "hasIntent": true,
  "intentType": "reminder | calendar | alarm | task",
  "label": "Yarın 14:00 Toplantısı",
  "timeHint": "Yarın 14:00",
  "suggestedAction": "Takvime Ekle | Hatırlatıcı Kur"
}
Yoksa:
{
  "hasIntent": false
}`;

    const response = await callGemini({ contents: prompt });
    let raw = (response || "").trim().replace(/^```json/i, "").replace(/^```/, "").replace(/```$/, "").trim();
    res.json(JSON.parse(raw));
  } catch (error: any) {
    // Regex fallback for common Turkish patterns
    const t = text.toLowerCase();
    if (t.includes("yarın") || t.includes("saat") || t.includes("toplantı") || t.includes("pazartesi") || t.includes("haftaya") || t.includes("akşam")) {
      res.json({
        hasIntent: true,
        intentType: "reminder",
        label: "🗓️ Zamanlanmış Hatırlatıcı",
        timeHint: t.includes("yarın") ? "Yarın" : "Belirtilen Saatte",
        suggestedAction: "Hatırlatıcı Oluştur"
      });
    } else {
      res.json({ hasIntent: false });
    }
  }
});

// -------------------------------------------------------------
// ColorNote .BIN Decryption & Import Pipeline
// Supports: OpenSSL PBE EVP_BytesToKey, PBKDF2 (SHA-1/SHA-256), AES-128-CBC,
// GZIP / ZLIB decompression, embedded SQLite 3 database parsing, and JSON streams.
// -------------------------------------------------------------

function deriveOpenSslKeyAndIV(password: string, salt: Buffer): { key: Buffer; iv: Buffer } {
  const passwordBytes = Buffer.from(password, "utf-8");
  
  // Hash 1: MD5(password + salt) -> 16 bytes key
  const h1 = crypto.createHash("md5");
  h1.update(passwordBytes);
  h1.update(salt);
  const key = h1.digest();

  // Hash 2: MD5(key + password + salt) -> 16 bytes iv
  const h2 = crypto.createHash("md5");
  h2.update(key);
  h2.update(passwordBytes);
  h2.update(salt);
  const iv = h2.digest();

  return { key, iv };
}

function derivePbkdf2KeyAndIV(
  password: string,
  salt: Buffer,
  iterations = 1000,
  keyLen = 16,
  ivLen = 16,
  digest = "sha1"
): { key: Buffer; iv: Buffer } {
  const derived = crypto.pbkdf2Sync(password, salt, iterations, keyLen + ivLen, digest);
  return {
    key: derived.subarray(0, keyLen),
    iv: derived.subarray(keyLen, keyLen + ivLen),
  };
}

// SQLite 3 varint decoder
function readSqliteVarint(buf: Buffer, offset: number): { value: number; bytesRead: number } {
  let res = 0;
  let bytesRead = 0;
  for (let i = 0; i < 9; i++) {
    if (offset + i >= buf.length) break;
    const b = buf[offset + i];
    bytesRead++;
    if (i === 8) {
      res = (res << 8) | b;
      break;
    } else {
      res = (res << 7) | (b & 0x7f);
      if ((b & 0x80) === 0) break;
    }
  }
  return { value: res, bytesRead };
}

function getSqliteSerialTypeSize(st: number): number {
  if (st === 0) return 0; // null
  if (st === 1) return 1; // 1-byte int
  if (st === 2) return 2; // 2-byte int
  if (st === 3) return 3; // 3-byte int
  if (st === 4) return 4; // 4-byte int
  if (st === 5) return 6; // 6-byte int
  if (st === 6) return 8; // 8-byte int
  if (st === 7) return 8; // 8-byte float
  if (st === 8 || st === 9) return 0; // constant 0 or 1
  if (st >= 12 && st % 2 === 0) return (st - 12) / 2; // blob
  if (st >= 13 && st % 2 === 1) return (st - 13) / 2; // string
  return 0;
}

// Extract ColorNote records directly from SQLite 3 B-Tree pages
function extractColorNoteFromSqliteBuffer(buf: Buffer): any[] {
  const results: any[] = [];
  const sqliteHeader = Buffer.from("SQLite format 3\0", "binary");
  const headerIdx = buf.indexOf(sqliteHeader);
  if (headerIdx === -1) return results;

  const dbBuf = headerIdx === 0 ? buf : buf.subarray(headerIdx);
  if (dbBuf.length < 512) return results;

  try {
    const rawPageSize = dbBuf.readUInt16BE(16);
    const pageSize = rawPageSize === 1 ? 65536 : rawPageSize >= 512 ? rawPageSize : 4096;
    const pageCount = Math.floor(dbBuf.length / pageSize);

    for (let p = 0; p < pageCount; p++) {
      const pageStart = p * pageSize;
      const headerOffset = p === 0 ? 100 : 0;
      if (pageStart + headerOffset >= dbBuf.length) break;

      const pageType = dbBuf[pageStart + headerOffset];
      if (pageType !== 0x0d) continue; // 0x0d = Leaf Table Page containing row data

      const cellCount = dbBuf.readUInt16BE(pageStart + headerOffset + 3);
      const cellPtrArrayStart = pageStart + headerOffset + 8;

      for (let c = 0; c < cellCount; c++) {
        if (cellPtrArrayStart + c * 2 + 2 > dbBuf.length) break;
        const cellOffsetInPage = dbBuf.readUInt16BE(cellPtrArrayStart + c * 2);
        const cellAbsoluteOffset = pageStart + cellOffsetInPage;
        if (cellAbsoluteOffset >= dbBuf.length) continue;

        try {
          let cur = cellAbsoluteOffset;
          const payloadLenVar = readSqliteVarint(dbBuf, cur);
          cur += payloadLenVar.bytesRead;

          const rowidVar = readSqliteVarint(dbBuf, cur);
          cur += rowidVar.bytesRead;

          const recordHeaderVar = readSqliteVarint(dbBuf, cur);
          const headerLen = recordHeaderVar.value;
          const headerEnd = cur + headerLen;
          cur += recordHeaderVar.bytesRead;

          const serialTypes: number[] = [];
          while (cur < headerEnd && cur < dbBuf.length) {
            const stVar = readSqliteVarint(dbBuf, cur);
            serialTypes.push(stVar.value);
            cur += stVar.bytesRead;
          }

          let valCur = headerEnd;
          const colValues: any[] = [];
          for (const st of serialTypes) {
            const size = getSqliteSerialTypeSize(st);
            if (valCur + size > dbBuf.length) break;

            if (st === 0) {
              colValues.push(null);
            } else if (st === 8) {
              colValues.push(0);
            } else if (st === 9) {
              colValues.push(1);
            } else if (st >= 13 && st % 2 === 1) {
              colValues.push(dbBuf.subarray(valCur, valCur + size).toString("utf-8"));
            } else if (st === 1) {
              colValues.push(dbBuf.readInt8(valCur));
            } else if (st === 2) {
              colValues.push(dbBuf.readInt16BE(valCur));
            } else if (st === 3) {
              colValues.push((dbBuf.readInt8(valCur) << 16) | dbBuf.readUInt16BE(valCur + 1));
            } else if (st === 4) {
              colValues.push(dbBuf.readInt32BE(valCur));
            } else if (st === 5 || st === 6) {
              try {
                colValues.push(Number(dbBuf.readBigInt64BE(valCur)));
              } catch {
                colValues.push(dbBuf.readInt32BE(valCur));
              }
            } else if (st >= 12 && st % 2 === 0) {
              // Extract SQLite BLOB payload (e.g. encrypted or binary note content)
              const blobBuf = dbBuf.subarray(valCur, valCur + size);
              try {
                const textCand = blobBuf.toString("utf-8");
                if (textCand && /^[\x20-\x7E\r\n\t\u00A0-\uFFFF]+$/.test(textCand.slice(0, 30))) {
                  colValues.push(textCand);
                } else {
                  colValues.push(blobBuf.toString("base64"));
                }
              } catch {
                colValues.push(blobBuf.toString("base64"));
              }
            } else {
              colValues.push(null);
            }
            valCur += size;
          }

          const strings = colValues.filter((v) => typeof v === "string" && v.trim().length > 0);
          const numbers = colValues.filter((v) => typeof v === "number");

          if (strings.length >= 1) {
            let title = "";
            let note = "";
            if (strings.length === 1) {
              note = strings[0];
              title = note.split("\n")[0].slice(0, 50);
            } else {
              title = strings[0];
              note = strings[1];
            }

            let created_date = Date.now();
            let modified_date = Date.now();
            let color_index = 3;
            let noteType = 0;

            for (const num of numbers) {
              if (num > 1000000000000 && num < 2500000000000) {
                if (created_date === Date.now()) {
                  created_date = num;
                } else {
                  modified_date = num;
                }
              } else if (num >= 0 && num <= 8 && color_index === 3) {
                color_index = num;
              } else if ((num === 16 || num === 1 || num === 0) && noteType === 0) {
                noteType = num;
              }
            }

            if (title || note) {
              results.push({
                _id: rowidVar.value,
                title: title || "Başlıksız Not",
                note: note || "",
                created_date,
                modified_date,
                color_index,
                type: noteType,
              });
            }
          }
        } catch {
          // ignore cell parse error and continue
        }
      }
    }
  } catch (err) {
    console.warn("SQLite B-Tree parsing notice:", err);
  }

  return results;
}

// Extract ColorNote JSON objects from buffer
function extractColorNoteJsonFromBuffer(buf: Buffer): any[] {
  const results: any[] = [];
  const text = buf.toString("utf-8");

  // 1. Chunk length format (>L: 4-byte big-endian unsigned long)
  for (const startIdx of [16, 0, 4, 8, 12, 20, 24, 28, 32]) {
    let idx = startIdx;
    let foundCount = 0;
    while (idx + 4 < buf.length) {
      if (
        buf[idx] === buf[idx + 1] &&
        buf[idx + 1] === buf[idx + 2] &&
        buf[idx + 2] === buf[idx + 3]
      ) {
        break;
      }
      const chunkLen = buf.readUInt32BE(idx);
      if (chunkLen > 2 && chunkLen < 2000000 && idx + 4 + chunkLen <= buf.length) {
        const chunkStr = buf.subarray(idx + 4, idx + 4 + chunkLen).toString("utf-8");
        try {
          const parsed = JSON.parse(chunkStr);
          if (parsed && typeof parsed === "object") {
            results.push(parsed);
            foundCount++;
            idx += 4 + chunkLen;
            continue;
          }
        } catch {
          // not this chunk
        }
      }
      break;
    }
    if (foundCount > 0) return results;
  }

  // 2. Bracket balancing search for { ... }
  let depth = 0;
  let start = -1;
  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    if (ch === "{") {
      if (depth === 0) start = i;
      depth++;
    } else if (ch === "}") {
      if (depth > 0) {
        depth--;
        if (depth === 0 && start !== -1) {
          const candidate = text.slice(start, i + 1);
          try {
            const parsed = JSON.parse(candidate);
            if (
              parsed &&
              typeof parsed === "object" &&
              (parsed.title !== undefined || parsed.note !== undefined || parsed._id !== undefined)
            ) {
              results.push(parsed);
            }
          } catch {
            // ignore
          }
          start = -1;
        }
      }
    }
  }

  if (results.length > 0) return results;

  // 3. JSON Array [ { ... }, ... ]
  const arrayStart = text.indexOf("[");
  const arrayEnd = text.lastIndexOf("]");
  if (arrayStart !== -1 && arrayEnd > arrayStart) {
    try {
      const parsedArray = JSON.parse(text.slice(arrayStart, arrayEnd + 1));
      if (Array.isArray(parsedArray) && parsedArray.length > 0) {
        return parsedArray;
      }
    } catch {
      // ignore
    }
  }

  // 4. Null separator split
  const records = text.split(/\0\0../);
  for (const rec of records) {
    const first = rec.indexOf("{");
    const last = rec.lastIndexOf("}");
    if (first !== -1 && last > first) {
      try {
        const parsed = JSON.parse(rec.slice(first, last + 1));
        if (
          parsed &&
          typeof parsed === "object" &&
          (parsed.title !== undefined || parsed.note !== undefined || parsed._id !== undefined)
        ) {
          results.push(parsed);
        }
      } catch {
        // ignore
      }
    }
  }

  return results;
}

// Decompress GZIP or ZLIB stream if present
function decompressBufferIfCompressed(buf: Buffer): Buffer[] {
  const buffers: Buffer[] = [buf];

  // Try GZIP (0x1F 0x8B) at multiple offsets
  for (let i = 0; i < Math.min(buf.length - 2, 64); i++) {
    if (buf[i] === 0x1f && buf[i + 1] === 0x8b) {
      try {
        const decompressed = zlib.gunzipSync(buf.subarray(i));
        if (decompressed && decompressed.length > 0) {
          buffers.push(decompressed);
        }
      } catch {}
    }
  }

  // Try ZLIB (0x78 0x9C, 0x78 0x01, 0x78 0xDA, 0x78 0x5E) at multiple offsets
  for (let i = 0; i < Math.min(buf.length - 2, 64); i++) {
    if (
      buf[i] === 0x78 &&
      (buf[i + 1] === 0x9c || buf[i + 1] === 0x01 || buf[i + 1] === 0xda || buf[i + 1] === 0x5e)
    ) {
      try {
        const decompressed = zlib.inflateSync(buf.subarray(i));
        if (decompressed && decompressed.length > 0) {
          buffers.push(decompressed);
        }
      } catch {}
    }
  }

  // Try raw inflate
  try {
    const rawDecompressed = zlib.inflateRawSync(buf);
    if (rawDecompressed && rawDecompressed.length > 0) {
      buffers.push(rawDecompressed);
    }
  } catch {}

  return buffers;
}

// Decrypt individual locked ColorNote notes (passwords, secret notes)
function decryptColorNoteLockedBody(rawBody: string, candidatePasswords: string[]): string | null {
  if (!rawBody) return null;
  const trimmed = rawBody.trim();

  // 1. Direct JSON check
  if (trimmed.startsWith("{") && trimmed.endsWith("}")) {
    try {
      const j = JSON.parse(trimmed);
      if (j.note) return j.note;
      if (j._body) return j._body;
    } catch {}
  }

  let buf: Buffer;
  try {
    buf = Buffer.from(trimmed, "base64");
  } catch {
    return null;
  }

  if (buf.length < 16) return null;

  // 2. Direct inflate in case of compressed plain text
  try {
    const inflated = zlib.inflateSync(buf);
    const text = inflated.toString("utf-8");
    if (text && text.length > 0) {
      try {
        const pj = JSON.parse(text);
        if (pj.note) return pj.note;
        if (pj._body) return pj._body;
      } catch {}
      return text;
    }
  } catch {}

  // 3. Decrypt with candidate passwords using AES-128-CBC
  for (const pwd of candidatePasswords) {
    if (pwd === undefined || pwd === null) continue;

    const sha1Key = crypto.createHash("sha1").update(Buffer.from(pwd, "utf-8")).digest().subarray(0, 16);
    const md5Key = crypto.createHash("md5").update(Buffer.from(pwd, "utf-8")).digest();
    const pbkdf2Key = crypto.pbkdf2Sync(pwd, Buffer.from("ColorNote Fixed Salt", "utf-8"), 1000, 16, "sha1");

    const keys = [sha1Key, md5Key, pbkdf2Key];

    for (const key of keys) {
      const ivCandidates = [
        buf.subarray(0, 16),
        Buffer.alloc(16, 0),
        Buffer.from("ColorNote Fixed ", "utf-8"),
      ];

      for (const iv of ivCandidates) {
        const payloadStarts = iv === buf.subarray(0, 16) ? [16] : [0, 16];
        for (const start of payloadStarts) {
          if (start >= buf.length) continue;
          const cipherSlice = buf.subarray(start);
          const validLen = cipherSlice.length - (cipherSlice.length % 16);
          if (validLen <= 0) continue;

          try {
            const decipher = crypto.createDecipheriv("aes-128-cbc", key, iv);
            decipher.setAutoPadding(false);
            const dec = Buffer.concat([decipher.update(cipherSlice.subarray(0, validLen)), decipher.final()]);

            let candText = "";
            try {
              candText = zlib.inflateSync(dec).toString("utf-8");
            } catch {
              try {
                candText = zlib.gunzipSync(dec).toString("utf-8");
              } catch {
                const pad = dec[dec.length - 1];
                if (pad > 0 && pad <= 16) {
                  candText = dec.subarray(0, dec.length - pad).toString("utf-8");
                } else {
                  candText = dec.toString("utf-8");
                }
              }
            }

            if (candText && candText.length > 0) {
              try {
                const pj = JSON.parse(candText);
                if (pj.note) return pj.note;
                if (pj._body) return pj._body;
              } catch {}
              const printable = candText.split("").filter((c) => {
                const code = c.charCodeAt(0);
                return code >= 32 || code === 10 || code === 13 || code === 9;
              }).length;
              if (printable / candText.length > 0.75) {
                return candText;
              }
            }
          } catch {}
        }
      }
    }
  }

  return null;
}

// Carve readable notes, passwords, and text records from binary buffers (.BIN)
function carveReadableNotesFromBinary(buf: Buffer): any[] {
  const results: any[] = [];
  const text = buf.toString("utf-8");

  // 1. JSON records
  const jsonMatches = text.match(/\{[^{}]{15,}\}/g) || [];
  for (const jm of jsonMatches) {
    try {
      const p = JSON.parse(jm);
      if (p && typeof p === "object" && (p.title || p.note || p.text || p.password || p.content || p._body)) {
        results.push({
          title: p.title || "Çözümlenen Not",
          note: p.note || p.content || p.text || p._body || (p.password ? `Şifre: ${p.password}` : JSON.stringify(p)),
          created_date: Date.now(),
          modified_date: Date.now(),
          color_index: 3,
          type: 0,
        });
      }
    } catch {}
  }

  if (results.length > 0) return results;

  // 2. Carve printable text chunks separated by control characters or nulls
  const lines = text.split(/[\x00-\x08\x0B\x0C\x0E-\x1F]+/);
  const validChunks: string[] = [];

  for (const rawChunk of lines) {
    const chunk = rawChunk.trim();
    if (chunk.length >= 15) {
      const letters = (chunk.match(/[\p{L}\p{N}]/gu) || []).length;
      if (letters >= 8 && letters / chunk.length > 0.35) {
        validChunks.push(chunk);
      }
    }
  }

  const uniqueChunks = Array.from(new Set(validChunks)).slice(0, 80);
  for (let i = 0; i < uniqueChunks.length; i++) {
    const chunk = uniqueChunks[i];
    const firstLine = chunk.split("\n")[0].slice(0, 50).trim();
    results.push({
      _id: i + 1,
      title: firstLine || `Ayrıştırılan Not #${i + 1}`,
      note: chunk,
      created_date: Date.now(),
      modified_date: Date.now(),
      color_index: (i % 8),
      type: 0,
    });
  }

  return results;
}

// Unified ColorNote extraction from any plaintext or decompressed stream
function extractAllColorNoteRecords(buf: Buffer): any[] {
  const decompressedCandidates = decompressBufferIfCompressed(buf);

  for (const candidate of decompressedCandidates) {
    // Try SQLite first
    const sqliteNotes = extractColorNoteFromSqliteBuffer(candidate);
    if (sqliteNotes.length > 0) {
      return sqliteNotes;
    }

    // Try JSON
    const jsonNotes = extractColorNoteJsonFromBuffer(candidate);
    if (jsonNotes.length > 0) {
      return jsonNotes;
    }
  }

  return [];
}

app.post("/api/colornote/decrypt", async (req, res) => {
  const { fileBase64, password, offset } = req.body;

  if (!fileBase64) {
    return res.status(400).json({ error: "Dosya verisi (Base64) bulunamadı." });
  }

  try {
    let cleanBase64 = fileBase64;
    if (fileBase64.includes(";base64,")) {
      cleanBase64 = fileBase64.split(";base64,")[1];
    }
    const fileBuffer = Buffer.from(cleanBase64, "base64");

    if (fileBuffer.length < 16) {
      return res.status(400).json({ error: "Dosya boyutu ColorNote yedeği için çok küçük." });
    }

    // Check magic signature 'NOTE' (0x4E, 0x4F, 0x54, 0x45)
    const hasNoteSignature =
      fileBuffer.length >= 4 &&
      fileBuffer[0] === 0x4e &&
      fileBuffer[1] === 0x4f &&
      fileBuffer[2] === 0x54 &&
      fileBuffer[3] === 0x45;

    // Check if the file is directly unencrypted SQLite or JSON
    const directNotes = extractAllColorNoteRecords(fileBuffer);
    if (directNotes.length > 0) {
      return processAndReturnNotes(directNotes, "unencrypted", 0, res);
    }

    const candidatePasswords = password
      ? [password, "0000", "", "colornote", "1234"]
      : ["0000", "", "colornote", "1234"];
    const passwordsToTry = Array.from(new Set(candidatePasswords));

    // Standard ColorNote V2 has 28 bytes header. Other variations may have 0, 16, 24, 32 bytes.
    const requestedOffset = typeof offset === "number" ? offset : (hasNoteSignature ? 28 : 0);
    const offsetsToTry = Array.from(new Set([requestedOffset, 28, 16, 0, 24, 32])).filter(
      (off) => off < fileBuffer.length
    );

    const defaultSalt = Buffer.from("ColorNote Fixed Salt", "utf-8");
    const headerSalt = fileBuffer.length >= 20 ? fileBuffer.subarray(4, 20) : defaultSalt;
    const saltsToTry = [defaultSalt, headerSalt];

    let decryptedNotes: any[] = [];
    let successfulPassword = "";
    let successfulOffset = 28;

    passwordLoop: for (const pwd of passwordsToTry) {
      for (const salt of saltsToTry) {
        // Strategy A: OpenSSL EVP_BytesToKey (MD5) + AES-128-CBC
        const { key: openSslKey, iv: openSslIv } = deriveOpenSslKeyAndIV(pwd, salt);

        // Strategy B: PBKDF2 (SHA-1) + AES-128-CBC
        const { key: pbkdf2KeySha1, iv: pbkdf2IvSha1 } = derivePbkdf2KeyAndIV(pwd, salt, 1000, 16, 16, "sha1");

        // Strategy C: PBKDF2 (SHA-256) + AES-128-CBC
        const { key: pbkdf2KeySha256, iv: pbkdf2IvSha256 } = derivePbkdf2KeyAndIV(pwd, salt, 1000, 16, 16, "sha256");

        const cipherConfigs = [
          { name: "openssl-md5", key: openSslKey, iv: openSslIv },
          { name: "pbkdf2-sha1", key: pbkdf2KeySha1, iv: pbkdf2IvSha1 },
          { name: "pbkdf2-sha256", key: pbkdf2KeySha256, iv: pbkdf2IvSha256 },
        ];

        for (const off of offsetsToTry) {
          const encPayload = fileBuffer.subarray(off);
          if (encPayload.length < 16) continue;
          const validLen = encPayload.length - (encPayload.length % 16);
          if (validLen <= 0) continue;

          for (const cfg of cipherConfigs) {
            try {
              const decipher = crypto.createDecipheriv("aes-128-cbc", cfg.key, cfg.iv);
              decipher.setAutoPadding(false);
              const decrypted = Buffer.concat([
                decipher.update(encPayload.subarray(0, validLen)),
                decipher.final(),
              ]);

              const parsedList = extractAllColorNoteRecords(decrypted);
              if (parsedList.length > 0) {
                decryptedNotes = parsedList;
                successfulPassword = pwd;
                successfulOffset = off;
                break passwordLoop;
              }
            } catch {
              // Try next config/offset
            }
          }
        }
      }
    }

    if (decryptedNotes.length === 0) {
      // Carve readable notes, credentials, and JSON from the binary file stream
      const carvedNotes = carveReadableNotesFromBinary(fileBuffer);
      if (carvedNotes.length > 0) {
        return processAndReturnNotes(carvedNotes, "carved", 0, res);
      }

      return res.status(401).json({
        success: false,
        error: "ColorNote şifresi çözülemedi. Dosya özel bir ana şifre ile kilitlenmiş olabilir.",
        requiresCustomPassword: true,
        hasNoteSignature,
      });
    }

    return processAndReturnNotes(decryptedNotes, successfulPassword, successfulOffset, res);
  } catch (error: any) {
    console.error("ColorNote decryption error:", error);
    res.status(500).json({
      success: false,
      error: error.message || "ColorNote dosyası çözülürken beklenmeyen bir hata oluştu.",
    });
  }
});

function processAndReturnNotes(
  decryptedNotes: any[],
  successfulPassword: string,
  successfulOffset: number,
  res: any
) {
  // Color palette mapping (0..8)
  const colorMap: Record<number, { name: string; themeColor: string }> = {
    0: { name: "Mavi", themeColor: "blue" },
    1: { name: "Kırmızı", themeColor: "rose" },
    2: { name: "Turuncu", themeColor: "amber" },
    3: { name: "Sarı", themeColor: "amber" },
    4: { name: "Yeşil", themeColor: "emerald" },
    5: { name: "Camgöbeği", themeColor: "teal" },
    6: { name: "Mor", themeColor: "purple" },
    7: { name: "Gri", themeColor: "slate" },
    8: { name: "Koyu", themeColor: "slate" },
  };

  const mappedNotes = decryptedNotes.map((cn: any, idx: number) => {
    const title = (cn.title || `ColorNote Notu #${idx + 1}`).trim();
    let body = (cn.note || "").trim();

    // HTML entity decode
    body = body
      .replace(/&amp;/g, "&")
      .replace(/&lt;/g, "<")
      .replace(/&gt;/g, ">")
      .replace(/&quot;/g, '"')
      .replace(/&#39;/g, "'");

    let isLocked = Boolean(
      cn.encrypted ||
      cn.is_encrypted ||
      cn.lock ||
      cn.password ||
      (typeof cn.flags === "number" && (cn.flags & 16) !== 0) ||
      (typeof cn.enc_type === "number" && cn.enc_type > 0)
    );

    // Auto-parse JSON string bodies
    if (body.startsWith("{") && body.endsWith("}")) {
      try {
        const pj = JSON.parse(body);
        if (pj.note || pj._body) {
          body = pj.note || pj._body;
        }
      } catch {}
    }

    // Auto-decrypt locked note content if present
    if (isLocked || (body.length > 20 && /^[A-Za-z0-9+/=\r\n]+$/.test(body) && !body.includes(" "))) {
      const candidates = [successfulPassword, "0000", "", "1234", "colornote"];
      const dec = decryptColorNoteLockedBody(body, candidates);
      if (dec && dec.length > 0) {
        body = dec;
        isLocked = false;
      }
    }

    const colorIdx = typeof cn.color_index === "number" ? cn.color_index : 3;
    const colorInfo = colorMap[colorIdx] || { name: "Sarı", themeColor: "amber" };

    // Parse URLs (especially YouTube Shorts & regular videos)
    const urlRegex = /(https?:\/\/[^\s<>"{}|\^~`\[\]]+)/gi;
    const urlsFound: string[] = Array.from(new Set(body.match(urlRegex) || []));
    const links = urlsFound.map((u: string) => {
      let isYouTube = false;
      let isShorts = false;
      let videoId: string | undefined;
      let domain = "";
      try {
        const parsed = new URL(u);
        domain = parsed.hostname.replace(/^www\./, "");
        if (domain.includes("youtube.com") || domain.includes("youtu.be")) {
          isYouTube = true;
          if (parsed.pathname.includes("/shorts/")) {
            isShorts = true;
            videoId = parsed.pathname.split("/shorts/")[1]?.split(/[?#&]/)[0];
          } else if (parsed.pathname.includes("/watch")) {
            videoId = parsed.searchParams.get("v") || undefined;
          } else if (domain.includes("youtu.be")) {
            videoId = parsed.pathname.slice(1).split(/[?#&]/)[0];
          }
        }
      } catch {
        domain = u.split("/")[2] || "web";
      }
      return {
        url: u,
        isYouTube,
        isShorts,
        videoId,
        thumbnailUrl: videoId ? `https://img.youtube.com/vi/${videoId}/hqdefault.jpg` : undefined,
        embedUrl: videoId ? `https://www.youtube.com/embed/${videoId}` : undefined,
        domain,
      };
    });

    // Parse checklist tasks
    const tasks: any[] = [];
    const lines = body.split(/\r?\n/);
    const isChecklist =
      cn.type === 16 ||
      cn.type === 1 ||
      lines.some((l: string) => /^\s*\[([ vVxX\-])\]/.test(l) || /^\s*-\s*\[([ xX])\]/.test(l));

    lines.forEach((l: string, lIdx: number) => {
      const trimmed = l.trim();
      if (!trimmed) return;
      const checkMatch = trimmed.match(/^\[([ vVxX\-])\]\s*(.*)$/) || trimmed.match(/^-\s*\[([ xX ])\]\s*(.*)$/);
      if (checkMatch) {
        const mark = checkMatch[1].toLowerCase();
        tasks.push({
          id: `task-${Date.now()}-${idx}-${lIdx}`,
          text: checkMatch[2] || trimmed,
          completed: mark === "v" || mark === "x",
        });
      } else if (isChecklist) {
        tasks.push({
          id: `task-${Date.now()}-${idx}-${lIdx}`,
          text: trimmed,
          completed: false,
        });
      }
    });

    // Created / Modified Dates
    let createdDate = new Date().toISOString();
    let modifiedDate = new Date().toISOString();
    if (cn.created_date) {
      try {
        createdDate = new Date(cn.created_date).toISOString();
      } catch {}
    }
    if (cn.modified_date) {
      try {
        modifiedDate = new Date(cn.modified_date).toISOString();
      } catch {}
    }

    return {
      id: cn.uuid || cn._id ? `cn-${cn.uuid || cn._id}` : `cn-${Date.now()}-${idx}`,
      title,
      content: body,
      rawType: cn.type || 0,
      isChecklist,
      isLocked,
      tasks,
      colorIndex: colorIdx,
      colorName: colorInfo.name,
      themeColor: colorInfo.themeColor,
      links,
      createdDate,
      modifiedDate,
      tags: ["#ColorNote", `#${colorInfo.name}`, ...(isChecklist ? ["#Yapılacaklar"] : [])],
    };
  });

  return res.json({
    success: true,
    notes: mappedNotes,
    total: mappedNotes.length,
    passwordUsed: successfulPassword,
    offsetUsed: successfulOffset,
    message: `${mappedNotes.length} adet ColorNote notu başarıyla çözüldü ve ayrıştırıldı.`,
  });
}

// Setup Vite middleware or static serving
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`NoteFlow server running on http://localhost:${PORT}`);
  });
}

startServer();
