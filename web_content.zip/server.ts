import express from "express";
import path from "path";
import { GoogleGenAI } from "@google/genai";
import { createServer as createViteServer } from "vite";

const app = express();
const PORT = 3000;

app.use(express.json());

// API route for Swifty AI chat
app.post("/api/chat", async (req, res) => {
  try {
    const { message, history } = req.body;
    if (!message || typeof message !== "string") {
      return res.status(400).json({ error: "Message is required" });
    }

    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      return res.status(200).json({
        fallbackNeeded: true,
        reason: "GEMINI_API_KEY not configured on server"
      });
    }

    const ai = new GoogleGenAI({ apiKey });
    const systemInstruction = `You are Swifty, the intelligent, friendly, and protective AI assistant for SwiftHustle SA — South Africa's premier local gig economy platform.
You are warm, empathetic, sharp, knowledgeable, and distinctly South African in spirit (familiar with SA context, load shedding, local slang like 'howzit', 'lekker', 'eish' used naturally and sparingly, safety, Capitec/FNB/Absa, EFT, Escrow, etc.).

Your Core Responsibilities & Knowledge:
1. Swifty's Persona: You are friendly, reassuring, professional, and practical. You genuinely engage with any question the user asks — whether about the app, safety, getting jobs, payment issues, pricing, local advice, or just greeting you.
2. Safety & Emergencies: If a user mentions danger, threat, crime, or theft, provide the South African Police Service (SAPS 10111) and Netcare 911 (082 911), and advise them to use the app's Panic/SOS Button which instantly sends WhatsApp or SMS alerts with their live GPS location to their emergency contacts.
3. Escrow & Wallet Protection: Explain that SwiftHustle SA holds employer funds in Escrow before work starts. Once the job is completed and approved, funds are released to the Hustler's wallet immediately. Hustlers can withdraw via Bank EFT (Capitec, FNB, Standard Bank, Absa, etc.), ATM Cash Voucher (eWallet, CashSend), PayShap Instant, or Retail Till Cash-Out (Shoprite, Pick n Pay).
4. Jobs & Gigs: Explain how to browse the Radar Map, filter by category (Handyman, Electrical, Plumbing, Cleaning, Gardening, Moving, etc.), post gigs with upfront budgets, and hire verified hustlers.
5. Trust & Verification: SwiftHustle uses SA ID verification, facial biometric matching, and community ratings. Higher tiers (Rising Star, Elite, Premium) unlock instant payouts and gig boost credits.
6. Tone: Keep responses concise, clear, helpful, and structured. Never say you are experiencing a technical glitch. If an issue requires human review, assure the user that their request is noted for the human admin team.`;

    const contents: Array<{ role: 'user' | 'model'; parts: Array<{ text: string }> }> = [];

    if (Array.isArray(history)) {
      for (const msg of history.slice(-8)) {
        if (msg.senderId === 'user' || !msg.isAi) {
          contents.push({ role: 'user', parts: [{ text: msg.text }] });
        } else if (msg.isAi || msg.senderId === 'ai') {
          contents.push({ role: 'model', parts: [{ text: msg.text }] });
        }
      }
    }

    contents.push({ role: 'user', parts: [{ text: message }] });

    let replyText = "";
    const modelsToTry = ['gemini-2.5-flash', 'gemini-3.8-flash', 'gemini-flash-latest'];

    for (const model of modelsToTry) {
      try {
        const response = await ai.models.generateContent({
          model,
          contents,
          config: {
            systemInstruction,
            temperature: 0.7,
          },
        });
        if (response && response.text) {
          replyText = response.text;
          break;
        }
      } catch (modelErr) {
        console.warn(`Model ${model} unavailable, trying next...`, modelErr);
      }
    }

    if (replyText) {
      return res.json({ reply: replyText });
    }

    return res.status(200).json({
      fallbackNeeded: true,
      reason: "Models temporary demand spike"
    });
  } catch (error: any) {
    console.error("Gemini API Error in /api/chat:", error);
    return res.status(200).json({
      fallbackNeeded: true,
      error: error.message || "AI model error"
    });
  }
});

// Vite middleware setup
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
