import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json({ limit: '15mb' }));

// Initialize Google GenAI
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY || '',
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

// Voice Audio Transcription & Emergency Intent API
app.post('/api/transcribe-voice', async (req, res) => {
  try {
    const { audioBase64, mimeType = 'audio/webm' } = req.body;

    if (!audioBase64) {
      return res.status(400).json({ error: 'No audio data provided' });
    }

    if (!process.env.GEMINI_API_KEY) {
      return res.status(503).json({
        error: 'GEMINI_API_KEY not configured',
        fallback: true,
      });
    }

    const audioPart = {
      inlineData: {
        mimeType: mimeType.split(';')[0], // e.g. audio/webm or audio/wav
        data: audioBase64,
      },
    };

    const prompt = `Listen carefully to this audio recording of a person speaking.
Your tasks:
1. Accurately transcribe exactly what the person is saying.
2. Determine if the speech indicates a safety emergency, distress, stalking, attack, threat, or need for urgent help (e.g. phrases like "help me", "someone is following me", "danger", "police", "leave me alone", "stop", "save me", or urgent distress tone).

Respond strictly in JSON format with this schema:
{
  "transcript": "exact spoken words in English/transliteration",
  "isEmergency": true | false,
  "detectedPhrase": "the specific keyword or reason for emergency detection, or null",
  "confidence": 0.0 to 1.0
}`;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: {
        parts: [audioPart, { text: prompt }],
      },
      config: {
        responseMimeType: 'application/json',
      },
    });

    const responseText = response.text || '{}';
    let parsedResult;
    try {
      parsedResult = JSON.parse(responseText.trim());
    } catch (_) {
      parsedResult = {
        transcript: responseText,
        isEmergency: /help|follow|danger|police|attack|save/i.test(responseText),
        detectedPhrase: null,
      };
    }

    return res.json(parsedResult);
  } catch (error: any) {
    console.error('Transcription error:', error);
    return res.status(500).json({
      error: error.message || 'Failed to process audio recording',
    });
  }
});

// AI Copilot Advice API
app.post('/api/copilot-chat', async (req, res) => {
  try {
    const { query } = req.body;
    if (!query) {
      return res.status(400).json({ error: 'Query is required' });
    }

    if (!process.env.GEMINI_API_KEY) {
      return res.status(503).json({ error: 'API key not configured' });
    }

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: query,
      config: {
        systemInstruction: `You are the SafeHer AI Emergency Response and Women Safety Copilot.
Provide concise, practical, high-priority safety guidance for personal security situations (stalking, night travel, assault threat, public transit).
Format your response with:
1. Immediate action step
2. Safety guidelines (3-4 bullet points)
3. Direct helpline to call (e.g. Police 100 or National Emergency 112)
Keep your response short, calm, actionable, and clear.`,
      },
    });

    return res.json({ text: response.text });
  } catch (error: any) {
    console.error('Copilot API error:', error);
    return res.status(500).json({ error: error.message });
  }
});

// Vite middleware in dev or static files in production
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, () => {
    console.log(`SafeHer AI Server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
