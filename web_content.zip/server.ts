import 'dotenv/config';
import http from 'node:http';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import express from 'express';
import { WebSocketServer, WebSocket } from 'ws';
import { GoogleGenAI, LiveServerMessage, Modality, ThinkingLevel } from '@google/genai';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

function getGeminiClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
    return null;
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

function extractReadableError(error: unknown, fallback: string): string {
  const raw = error instanceof Error ? error.message : String(error ?? '');
  try {
    const parsed = JSON.parse(raw) as { error?: { message?: string } };
    if (parsed?.error?.message) {
      return parsed.error.message;
    }
  } catch {
    // Plain message
  }
  return raw.trim() || fallback;
}

async function generateTextWithRetry(
  ai: GoogleGenAI,
  contents: string,
  systemInstruction?: string
): Promise<string> {
  const attempts: Array<{ model: string; thinking: ThinkingLevel }> = [
    { model: 'gemini-4-hydrogen', thinking: ThinkingLevel.LOW },
    { model: 'gemini-3.1-flash-lite', thinking: ThinkingLevel.MINIMAL },
    { model: 'gemini-4-hydrogen', thinking: ThinkingLevel.LOW },
  ];

  let lastError: unknown;
  for (let i = 0; i < attempts.length; i += 1) {
    const attempt = attempts[i];
    try {
      const response = await ai.models.generateContent({
        model: attempt.model,
        contents,
        config: {
          ...(systemInstruction ? { systemInstruction } : {}),
          thinkingConfig: { thinkingLevel: attempt.thinking },
        },
      });
      return (response.text ?? '').trim();
    } catch (err) {
      lastError = err;
      const msg = err instanceof Error ? err.message : '';
      const isTransient =
        msg.includes('503') ||
        msg.includes('UNAVAILABLE') ||
        msg.includes('429') ||
        msg.includes('RESOURCE_EXHAUSTED');
      if (!isTransient) {
        throw err;
      }
      if (i < attempts.length - 1) {
        await new Promise((resolve) => setTimeout(resolve, 400 * (i + 1)));
      }
    }
  }
  throw lastError ?? new Error('AI service is temporarily unavailable.');
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '16mb' }));

  app.get('/api/health', (_req, res) => {
    const ai = getGeminiClient();
    res.json({
      ok: true,
      geminiConfigured: ai !== null,
    });
  });

  // Fast overlapping audio-buffer transcription for live fallback (no files saved)
  app.post('/api/transcribe-chunk', async (req, res) => {
    const ai = getGeminiClient();
    if (!ai) {
      res.status(503).json({ error: 'Gemini API key is not configured.' });
      return;
    }

    const {
      audioBase64,
      mimeType = 'audio/wav',
      speakingLangName = 'Urdu',
      speakingLangCode = 'ur-PK',
      outputLangName = 'Urdu',
      outputLangCode = 'same',
    } = req.body ?? {};

    if (typeof audioBase64 !== 'string' || audioBase64.length < 32) {
      res.json({ transcript: '', translation: '' });
      return;
    }

    try {
      const prompt =
        speakingLangCode === 'auto'
          ? 'Transcribe any spoken words in this short audio clip accurately in their original script (Urdu Nastaliq, English, etc.). Do not cut off partial words; reconstruct natural word spacing. If only silence or background noise, return an empty string.'
          : `Transcribe any spoken ${speakingLangName} (${speakingLangCode}) words in this short audio clip verbatim and accurately. Preserve Urdu Nastaliq script and any code-switched English words naturally. If only silence or background noise, return an empty string.`;

      const cleanChunkMime =
        String(mimeType || 'audio/wav').split(';')[0].trim() || 'audio/wav';

      const transcribeRes = await ai.models.generateContent({
        model: 'gemini-3.5-transcribe',
        contents: {
          parts: [
            { inlineData: { mimeType: cleanChunkMime, data: audioBase64 } },
            { text: prompt },
          ],
        },
      });

      const transcript = (transcribeRes.text ?? '').trim();
      if (!transcript) {
        res.json({ transcript: '', translation: '' });
        return;
      }

      const shouldTranslate =
        outputLangCode !== 'same' && outputLangCode !== speakingLangCode;

      if (!shouldTranslate) {
        res.json({ transcript, translation: transcript });
        return;
      }

      const translated = await generateTextWithRetry(
        ai,
        `Translate this spoken phrase accurately and naturally into ${outputLangName}. Return ONLY the translated text without quotes or explanations:\n\n${transcript}`
      );

      res.json({
        transcript,
        translation: translated || transcript,
      });
    } catch {
      res.json({ transcript: '', translation: '' });
    }
  });

  // Called on "Next" / Stop commit to add punctuation, capitalization, clean word placement, and translate if needed
  app.post('/api/finalize-segment', async (req, res) => {
    const ai = getGeminiClient();
    const {
      rawText = '',
      speakingLangName = 'Urdu',
      speakingLangCode = 'ur-PK',
      outputLangName = 'Urdu',
      outputLangCode = 'same',
    } = req.body ?? {};

    const cleanedInput = typeof rawText === 'string' ? rawText.trim() : '';
    if (!cleanedInput) {
      res.json({ finalText: '' });
      return;
    }

    if (!ai) {
      res.json({ finalText: cleanedInput });
      return;
    }

    const shouldTranslate =
      outputLangCode !== 'same' && outputLangCode !== speakingLangCode;

    try {
      const instruction = shouldTranslate
        ? [
            `You are a precise real-time voice dictation formatter and translator.`,
            `Input was spoken in ${speakingLangName}. Target output language is ${outputLangName}.`,
            `1. Reconstruct any half-cut or phonetically misheard words from live speech-to-text without inventing new facts.`,
            `2. Translate the complete thought accurately and naturally into ${outputLangName}.`,
            `3. Automatically apply accurate punctuation (periods, commas, question marks, or native Urdu "۔" / "،" / "؟") and proper capitalization (sentence starts, proper nouns, English acronyms, and "I").`,
            `4. Return ONLY the final formatted text in ${outputLangName}. No markdown, no quotes, no commentary.`,
          ].join('\n')
        : [
            `You are a precise real-time voice dictation formatter specializing in ${speakingLangName} (including natural Urdu-English code-switching).`,
            `1. Automatically add accurate punctuation (use Urdu "۔" / "،" / "؟" for Urdu script, and standard "." / "," / "?" / "!" for Latin script) and proper capitalization (capitalize sentence starts, proper nouns, "I", and technical acronyms).`,
            `2. Reconstruct any half-cut words and fix awkward spacing/placement without changing the speaker's intent or inventing details.`,
            `3. Return ONLY the final formatted text. No markdown, no quotes, no commentary.`,
          ].join('\n');

      const finalText =
        (await generateTextWithRetry(ai, cleanedInput, instruction)) || cleanedInput;
      res.json({ finalText });
    } catch (error) {
      const message = extractReadableError(error, 'Failed to finalize segment.');
      res.status(502).json({ error: message, finalText: cleanedInput });
    }
  });

  // AI Enhance: repairs broken, garbled, half-cut, or phonetic speech-to-text words across the written sheet
  app.post('/api/enhance-text', async (req, res) => {
    const ai = getGeminiClient();
    const {
      text = '',
      languageName = 'Urdu',
      languageCode = 'ur-PK',
    } = req.body ?? {};
    const cleaned = typeof text === 'string' ? text.trim() : '';

    if (!cleaned) {
      res.json({ enhancedText: '' });
      return;
    }

    if (!ai) {
      res.status(503).json({
        error: 'Gemini API key is not configured.',
      });
      return;
    }

    try {
      const instruction = [
        `You are an expert speech-to-text restoration and clarity editor specializing in ${languageName} (${languageCode}) as well as natural Urdu-English code-switching.`,
        `The user dictated this text by voice, so it may contain broken words, half-cut words, phonetic mishearings, merged/split words, missing capitalization, or missing punctuation.`,
        `Your job:`,
        `1. Repair every broken, garbled, misspelled, or half-cut word into the clear, intended word based on context.`,
        `2. Fix grammar, sentence flow, spacing, capitalization (sentence starts, proper nouns, acronyms), and punctuation (use Urdu "۔" / "،" / "؟" for Urdu script, standard "." / "," / "?" for Latin script) so the text reads as if captured from a crystal-clear voice.`,
        `3. Preserve all paragraph breaks and keep the exact original meaning—never invent new facts or remove ideas.`,
        `4. Keep the output in ${languageName} (preserving natural code-switched technical terms where appropriate).`,
        `5. Return ONLY the enhanced text with zero quotes, labels, or explanations.`,
      ].join('\n');

      const enhancedText =
        (await generateTextWithRetry(ai, cleaned, instruction)) || cleaned;
      res.json({ enhancedText });
    } catch (error) {
      const message = extractReadableError(error, 'AI Enhance failed.');
      res.status(502).json({ error: message });
    }
  });

  // Automatically translates existing written text when the user selects a new target language
  app.post('/api/translate-text', async (req, res) => {
    const ai = getGeminiClient();
    const { text = '', targetLangName = 'English' } = req.body ?? {};
    const cleaned = typeof text === 'string' ? text.trim() : '';

    if (!cleaned) {
      res.json({ translatedText: '' });
      return;
    }

    if (!ai) {
      res.status(503).json({
        error: 'Gemini API key is not configured.',
      });
      return;
    }

    try {
      const instruction = [
        `Translate the user's text accurately and naturally into ${targetLangName}.`,
        `Preserve all paragraph breaks and line structure exactly.`,
        `Use proper punctuation, capitalization, and native script for ${targetLangName} (e.g., Nastaliq Urdu script with "۔" for Urdu).`,
        `Return ONLY the translated text with zero explanations or quotes.`,
      ].join('\n');

      const translatedText =
        (await generateTextWithRetry(ai, cleaned, instruction)) || cleaned;
      res.json({ translatedText });
    } catch (error) {
      const message = extractReadableError(error, 'Translation failed.');
      res.status(502).json({ error: message });
    }
  });

  const server = http.createServer(app);
  const wss = new WebSocketServer({ server, path: '/ws/live' });

  wss.on('connection', async (clientWs: WebSocket, req) => {
    const ai = getGeminiClient();
    if (!ai) {
      clientWs.send(
        JSON.stringify({
          type: 'fallback',
          message: 'Live streaming unavailable without configured Gemini key.',
        })
      );
      return;
    }

    const reqUrl = new URL(req.url ?? '/ws/live', 'http://localhost');
    const speakingLang = reqUrl.searchParams.get('speakingLang') ?? 'ur-PK';
    const outputLang = reqUrl.searchParams.get('outputLang') ?? 'same';
    const outputLangName = reqUrl.searchParams.get('outputLangName') ?? 'Urdu';
    const shouldTranslate = outputLang !== 'same' && outputLang !== speakingLang;

    let session: Awaited<ReturnType<typeof ai.live.connect>> | null = null;

    try {
      const languageCodes = speakingLang === 'auto' ? [] : [speakingLang];
      session = await ai.live.connect({
        model: 'gemini-3.5-transcribe-live',
        config: {
          responseModalities: [Modality.TEXT],
          inputAudioTranscription: {
            languageCodes,
          },
        },
        callbacks: {
          onmessage: (message: LiveServerMessage) => {
            if (clientWs.readyState !== WebSocket.OPEN) return;
            const content = message.serverContent;
            if (content?.interimInputTranscription?.text) {
              clientWs.send(
                JSON.stringify({
                  type: 'interim',
                  text: content.interimInputTranscription.text,
                })
              );
            }
            if (content?.inputTranscription?.text) {
              const phrase = content.inputTranscription.text.trim();
              if (!phrase) return;
              clientWs.send(
                JSON.stringify({
                  type: 'transcript',
                  text: phrase,
                })
              );

              if (shouldTranslate) {
                ai.models
                  .generateContent({
                    model: 'gemini-4-hydrogen',
                    contents: `Translate this spoken phrase accurately into ${outputLangName}. Return only the translation:\n\n${phrase}`,
                    config: {
                      thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
                    },
                  })
                  .then((trRes) => {
                    const translated = (trRes.text ?? '').trim();
                    if (translated && clientWs.readyState === WebSocket.OPEN) {
                      clientWs.send(
                        JSON.stringify({
                          type: 'translation',
                          text: translated,
                        })
                      );
                    }
                  })
                  .catch(() => {
                    // Ignore transient live translation errors
                  });
              }
            }
          },
          onerror: () => {
            if (clientWs.readyState === WebSocket.OPEN) {
              clientWs.send(
                JSON.stringify({
                  type: 'fallback',
                  message: 'Live stream interrupted; using seamless chunk fallback.',
                })
              );
            }
          },
        },
      });

      if (clientWs.readyState === WebSocket.OPEN) {
        clientWs.send(JSON.stringify({ type: 'ready' }));
      }
    } catch {
      if (clientWs.readyState === WebSocket.OPEN) {
        clientWs.send(
          JSON.stringify({
            type: 'fallback',
            message: 'Using seamless live chunk transcription.',
          })
        );
      }
    }

    clientWs.on('message', (rawData) => {
      if (!session) return;
      try {
        const parsed = JSON.parse(rawData.toString()) as { audio?: string };
        if (parsed.audio) {
          session.sendRealtimeInput({
            audio: { data: parsed.audio, mimeType: 'audio/pcm;rate=16000' },
          });
        }
      } catch {
        // Ignore malformed frame
      }
    });

    clientWs.on('close', () => {
      try {
        session?.close();
      } catch {
        // Ignore close errors
      }
      session = null;
    });
  });

  // Always return JSON for /api/* (never SPA HTML fallback)
  app.use('/api', (_req, res) => {
    res.status(404).json({ error: 'API endpoint not found.' });
  });

  app.use(
    '/api',
    (
      err: unknown,
      _req: express.Request,
      res: express.Response,
      _next: express.NextFunction
    ) => {
      const status =
        typeof err === 'object' &&
        err !== null &&
        'status' in err &&
        typeof (err as { status: unknown }).status === 'number'
          ? (err as { status: number }).status
          : 500;
      const message =
        err instanceof Error ? err.message : 'Unexpected server error.';
      res.status(status).json({ error: message });
    }
  );

  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  const port = Number(process.env.PORT) || 3000;
  server.listen(port, '0.0.0.0', () => {
    console.log(`Sk Voice listening on http://localhost:${port}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
