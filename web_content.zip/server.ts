import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: "10mb" }));

  // Initialize Gemini AI Client lazily/safely
  const getAiClient = () => {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      console.warn("GEMINI_API_KEY is not set. AI features will run with fallback responses.");
      return null;
    }
    return new GoogleGenAI({
      apiKey: apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  };

  // API Route: AI Character Chat
  app.post("/api/chat", async (req, res) => {
    try {
      const {
        characterName,
        systemPrompt,
        userMessage,
        chatHistory = [],
        model = "gemini-3.6-flash",
      } = req.body;

      const ai = getAiClient();

      if (!ai) {
        // Fallback response if key is missing
        const fallbackText = `(${characterName} ينظر إليك باهتمام ويرد) أهلاً بك! أنا أسمعك جيداً. يسعدني التواصل معك في PinkVerse AI!`;
        return res.json({ text: fallbackText });
      }

      // Format conversation history
      const formattedPrompt = `
System Instruction / Character Roleplay:
${systemPrompt || `You are ${characterName}, an interactive AI character.`}

Format guidelines:
- Always stay strictly in character as ${characterName}.
- Express actions, feelings and facial expressions inside parentheses, e.g., (بتسم بترحيب وشغف).
- Respond in rich Arabic or Darija depending on the character prompt.

Recent Conversation History:
${chatHistory
  .slice(-6)
  .map(
    (msg: any) =>
      `${msg.sender === "user" ? "User" : characterName}: ${msg.text}`
  )
  .join("\n")}

User: ${userMessage}
${characterName}:`;

      const response = await ai.models.generateContent({
        model: "gemini-3.6-flash",
        contents: formattedPrompt,
      });

      const replyText =
        response.text || `(${characterName} يبدّي اهتماماً ولطفاً) أهلاً بك وسهلاً!`;

      res.json({ text: replyText });
    } catch (error: any) {
      console.error("Error calling Gemini API in /api/chat:", error);
      res.status(500).json({
        error: "Failed to generate AI response",
        details: error?.message || "Unknown error",
        text: "(انقطع الاتصال برهة، ثم تنفس بعمق وقال) عفواً، هل يمكنك إعادة ما قلته؟",
      });
    }
  });

  // API Route: Image Generation / Avatar Generation
  app.post("/api/generate-image", async (req, res) => {
    try {
      const { prompt } = req.body;
      const ai = getAiClient();

      if (!ai) {
        return res.json({
          imageUrl: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=500&auto=format&fit=crop&q=80",
        });
      }

      const response = await ai.models.generateContent({
        model: "gemini-3.1-flash-lite-image",
        contents: {
          parts: [{ text: prompt || "A stylish anime character avatar, high quality" }],
        },
        config: {
          imageConfig: {
            aspectRatio: "1:1",
          },
        },
      });

      let imageUrl = "";
      if (response.candidates?.[0]?.content?.parts) {
        for (const part of response.candidates[0].content.parts) {
          if (part.inlineData?.data) {
            imageUrl = `data:image/png;base64,${part.inlineData.data}`;
            break;
          }
        }
      }

      if (!imageUrl) {
        imageUrl = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=500&auto=format&fit=crop&q=80";
      }

      res.json({ imageUrl });
    } catch (err: any) {
      console.error("Image generation error:", err);
      res.json({
        imageUrl: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=500&auto=format&fit=crop&q=80",
      });
    }
  });

  // Health check
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", app: "PinkVerse AI" });
  });

  // Vite middleware for development vs static serve for production
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`PinkVerse AI server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
