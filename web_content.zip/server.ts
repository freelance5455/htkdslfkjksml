import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import express from 'express';
import * as cheerio from 'cheerio';
import type {
  ApkBuildConfig,
  BuildArtifactSummary,
  UrlInspectionResult,
} from './src/types/apk.ts';
import { buildSignedApkBinary } from './src/lib/apkCore/apkPackager.ts';
import { buildGradleProjectZip } from './src/lib/apkCore/gradlePackager.ts';
import { generateServerFallbackPngIcon } from './server/iconFallback.ts';

interface StoredBuild {
  summary: BuildArtifactSummary;
  apkBuffer: Buffer;
  gradleBuffer: Buffer;
  filenameBase: string;
}

const MAX_STORED_BUILDS = 20;
const buildStore = new Map<string, StoredBuild>();

function isPrivateOrLocalHost(hostname: string): boolean {
  const lower = hostname.toLowerCase();
  if (
    lower === 'localhost' ||
    lower === '127.0.0.1' ||
    lower === '0.0.0.0' ||
    lower === '::1' ||
    lower.endsWith('.local') ||
    lower.endsWith('.internal')
  ) {
    return true;
  }
  if (/^10\.\d+\.\d+\.\d+$/.test(lower)) return true;
  if (/^192\.168\.\d+\.\d+$/.test(lower)) return true;
  if (/^172\.(1[6-9]|2\d|3[0-1])\.\d+\.\d+$/.test(lower)) return true;
  if (/^169\.254\.\d+\.\d+$/.test(lower)) return true;
  return false;
}

function suggestPackageIdFromHostname(hostname: string): string {
  const parts = hostname
    .toLowerCase()
    .replace(/^www\./, '')
    .split('.')
    .filter(Boolean)
    .map((seg) => {
      let cleaned = seg.replace(/[^a-z0-9_]/g, '_');
      if (!/^[a-z]/.test(cleaned)) cleaned = `app_${cleaned}`;
      return cleaned;
    });

  if (parts.length >= 2) {
    return parts.slice().reverse().join('.');
  }
  if (parts.length === 1) {
    return `com.${parts[0]}.webapp`;
  }
  return 'com.example.webapp';
}

function validateBuildConfig(config: ApkBuildConfig): string | null {
  if (!config || typeof config !== 'object') {
    return 'Invalid build payload.';
  }
  if (!config.appName || config.appName.trim().length === 0) {
    return 'Application name is required.';
  }
  if (!/^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+$/.test(config.packageId)) {
    return 'Package ID must follow reverse-domain notation (e.g. com.company.app).';
  }
  if (!config.versionName || config.versionName.trim().length === 0) {
    return 'Version name is required.';
  }
  if (!Number.isInteger(config.versionCode) || config.versionCode < 1) {
    return 'Version code must be a positive integer.';
  }
  if (config.sourceMode === 'url') {
    try {
      const parsed = new URL(config.websiteUrl);
      if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
        return 'Website URL must start with http:// or https://.';
      }
    } catch {
      return 'Please enter a valid Website URL.';
    }
  } else if (config.sourceMode === 'code') {
    if (!config.rawHtmlCode || config.rawHtmlCode.trim().length === 0) {
      return 'Please paste or write HTML code before compiling.';
    }
  } else if (config.sourceMode === 'html') {
    if (!Array.isArray(config.htmlFiles) || config.htmlFiles.length === 0) {
      return 'Please provide at least one HTML file for HTML Bundle mode.';
    }
  } else {
    return 'Unsupported source mode.';
  }
  return null;
}

async function createServer() {
  const app = express();
  app.use(express.json({ limit: '32mb' }));

  app.post('/api/inspect-url', async (req, res) => {
    const rawUrl = typeof req.body?.url === 'string' ? req.body.url.trim() : '';
    let parsed: URL;
    try {
      parsed = new URL(rawUrl.startsWith('http') ? rawUrl : `https://${rawUrl}`);
      if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
        res.status(400).json({ error: 'URL must use http:// or https://.' });
        return;
      }
      if (isPrivateOrLocalHost(parsed.hostname)) {
        res.status(400).json({ error: 'Local or private network URLs cannot be inspected.' });
        return;
      }
    } catch {
      res.status(400).json({ error: 'Please enter a valid website URL.' });
      return;
    }

    try {
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), 8000);
      const response = await fetch(parsed.toString(), {
        redirect: 'follow',
        signal: controller.signal,
        headers: {
          'User-Agent':
            'Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36',
          Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        },
      });
      clearTimeout(timer);

      const finalUrl = response.url || parsed.toString();
      const finalParsed = new URL(finalUrl);
      const html = await response.text();
      const $ = cheerio.load(html);

      const rawTitle =
        $('meta[property="og:site_name"]').attr('content') ||
        $('meta[name="application-name"]').attr('content') ||
        $('title').first().text() ||
        finalParsed.hostname.replace(/^www\./, '');
      const title = rawTitle.trim().slice(0, 40) || finalParsed.hostname;

      const description = (
        $('meta[name="description"]').attr('content') ||
        $('meta[property="og:description"]').attr('content') ||
        ''
      ).trim();

      const themeColorRaw = $('meta[name="theme-color"]').attr('content')?.trim() || null;
      const themeColor =
        themeColorRaw && /^#[0-9a-fA-F]{6}$/.test(themeColorRaw) ? themeColorRaw : null;

      const iconHref =
        $('link[rel="apple-touch-icon"]').attr('href') ||
        $('link[rel="icon"][sizes="192x192"]').attr('href') ||
        $('link[rel="icon"]').attr('href') ||
        $('link[rel="shortcut icon"]').attr('href') ||
        '/favicon.ico';

      let faviconUrl: string | null = null;
      let faviconBase64Png: string | null = null;
      if (iconHref) {
        try {
          faviconUrl = new URL(iconHref, finalUrl).toString();
          const iconCtrl = new AbortController();
          const iconTimer = setTimeout(() => iconCtrl.abort(), 4000);
          const iconRes = await fetch(faviconUrl, { signal: iconCtrl.signal });
          clearTimeout(iconTimer);
          const contentType = iconRes.headers.get('content-type') || '';
          if (iconRes.ok && contentType.includes('image/png')) {
            const arrBuf = await iconRes.arrayBuffer();
            if (arrBuf.byteLength > 0 && arrBuf.byteLength <= 512 * 1024) {
              faviconBase64Png = Buffer.from(arrBuf).toString('base64');
            }
          }
        } catch {
          // Ignore icon fetch failures gracefully
        }
      }

      const xFrame = (response.headers.get('x-frame-options') || '').toLowerCase();
      const csp = (response.headers.get('content-security-policy') || '').toLowerCase();
      let frameBlocked = false;
      let frameHeaderReason: string | null = null;

      if (xFrame.includes('deny') || xFrame.includes('sameorigin')) {
        frameBlocked = true;
        frameHeaderReason = `X-Frame-Options: ${xFrame.toUpperCase()}`;
      } else if (csp.includes('frame-ancestors')) {
        const match = csp.match(/frame-ancestors\s+([^;]+)/);
        const directive = match ? match[1].trim() : '';
        if (directive && !directive.includes('*')) {
          frameBlocked = true;
          frameHeaderReason = `CSP frame-ancestors ${directive}`;
        }
      }

      const result: UrlInspectionResult = {
        finalUrl,
        title,
        description,
        themeColor,
        faviconUrl,
        faviconBase64Png,
        suggestedPackageId: suggestPackageIdFromHostname(finalParsed.hostname),
        isHttps: finalParsed.protocol === 'https:',
        frameBlocked,
        frameHeaderReason,
        statusCode: response.status,
      };

      res.json(result);
    } catch (err) {
      const msg =
        err instanceof Error && err.name === 'AbortError'
          ? 'Connection timed out while fetching target URL.'
          : 'Could not reach target website from server.';
      res.status(502).json({ error: msg });
    }
  });

  app.post('/api/build', async (req, res) => {
    const config = req.body as ApkBuildConfig;
    const validationError = validateBuildConfig(config);
    if (validationError) {
      res.status(400).json({ error: validationError });
      return;
    }

    try {
      const buildId = crypto.randomUUID();
      const [{ apkBytes, summary }, gradleBytes] = await Promise.all([
        buildSignedApkBinary(config, buildId, generateServerFallbackPngIcon),
        buildGradleProjectZip(config, generateServerFallbackPngIcon),
      ]);

      const apkBuffer = Buffer.from(apkBytes);
      const gradleBuffer = Buffer.from(gradleBytes);

      const fullSummary: BuildArtifactSummary = {
        ...summary,
        gradleSizeBytes: gradleBuffer.length,
      };

      const slug =
        config.appName
          .toLowerCase()
          .replace(/[^a-z0-9]+/g, '-')
          .replace(/^-|-$/g, '') || 'webapp';

      buildStore.set(buildId, {
        summary: fullSummary,
        apkBuffer,
        gradleBuffer,
        filenameBase: `${slug}-v${config.versionName.replace(/[^a-zA-Z0-9._-]/g, '_')}`,
      });

      while (buildStore.size > MAX_STORED_BUILDS) {
        const oldestKey = buildStore.keys().next().value;
        if (oldestKey) buildStore.delete(oldestKey);
      }

      res.json(fullSummary);
    } catch (err) {
      console.error('APK build failed:', err);
      res.status(500).json({
        error: err instanceof Error ? err.message : 'Failed to package APK.',
      });
    }
  });

  app.get('/api/builds', (_req, res) => {
    const list = Array.from(buildStore.values())
      .map((item) => item.summary)
      .reverse();
    res.json(list);
  });

  app.get('/api/builds/:id/apk', (req, res) => {
    const record = buildStore.get(req.params.id);
    if (!record) {
      res.status(404).json({ error: 'Build artifact expired or not found.' });
      return;
    }
    res.setHeader('Content-Type', 'application/vnd.android.package-archive');
    res.setHeader(
      'Content-Disposition',
      `attachment; filename="${record.filenameBase}.apk"`
    );
    res.setHeader('Content-Length', String(record.apkBuffer.length));
    res.send(record.apkBuffer);
  });

  app.get('/api/builds/:id/gradle', (req, res) => {
    const record = buildStore.get(req.params.id);
    if (!record) {
      res.status(404).json({ error: 'Build artifact expired or not found.' });
      return;
    }
    res.setHeader('Content-Type', 'application/zip');
    res.setHeader(
      'Content-Disposition',
      `attachment; filename="${record.filenameBase}-android-studio.zip"`
    );
    res.setHeader('Content-Length', String(record.gradleBuffer.length));
    res.send(record.gradleBuffer);
  });

  const isProd = process.env.NODE_ENV === 'production';
  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(process.cwd(), 'dist');
    if (fs.existsSync(distPath)) {
      app.use(express.static(distPath));
      app.get('*', (_req, res) => {
        res.sendFile(path.join(distPath, 'index.html'));
      });
    }
  }

  const port = Number(process.env.PORT) || 3000;
  app.listen(port, '0.0.0.0', () => {
    console.log(`Web2APK Studio server listening on http://0.0.0.0:${port}`);
  });
}

createServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
