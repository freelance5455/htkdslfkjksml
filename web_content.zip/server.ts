import http from 'http';
import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const httpServer = http.createServer(app);
const PORT = process.env.PORT ? parseInt(process.env.PORT) : 3000;

app.use(express.json());

// Initialize Gemini SDK if API key is present
const apiKey = process.env.GEMINI_API_KEY;
let aiClient: GoogleGenAI | null = null;
if (apiKey && apiKey !== 'MY_GEMINI_API_KEY') {
  try {
    aiClient = new GoogleGenAI({ apiKey });
  } catch (err) {
    console.warn('Failed to initialize GoogleGenAI:', err);
  }
}

// Jarvis AI Intent & Action Dispatcher Endpoint
app.post('/api/jarvis', async (req, res) => {
  const { prompt, context } = req.body;

  if (!prompt || typeof prompt !== 'string') {
    return res.status(400).json({ error: 'Prompt is required' });
  }

  // System instruction for JARVIS (Pakistani Urdu AI Operating Core with Smart Memory)
  const userMemories = context?.memories || {};
  const userName = userMemories.name || 'Sir';

  const systemInstruction = `You are J.A.R.V.I.S., the advanced AI assistant running on the user's Android phone.
IMPORTANT LANGUAGE & CULTURAL INSTRUCTION:
- The user is Pakistani. You MUST communicate in authentic, natural Pakistani Urdu (using clean Roman Urdu or Urdu as requested).
- NEVER use Hindi words or vocabulary (e.g. do NOT use "namaste", "dhanyawad", "kripya", "samay", "mitr", "swagat").
- ALWAYS use natural Pakistani Urdu expressions:
  - Greetings: "Assalam-o-Alaikum ${userName}!"
  - Courtesy: "Ji ${userName}", "Shukriya", "Bara-e-meherbani", "Hukum karein", "Mai aapki kya khidmat kar sakta hu?"
  - Confirmations: "Theek hai", "Ji behtar", "Mai ne yaad rakh liya hai", "Bilkul janab".

STORED USER MEMORIES (Context Awareness):
${JSON.stringify(userMemories)}

Current local time: ${context?.currentTime || new Date().toISOString()}.
Current Calendar Events: ${JSON.stringify(context?.events || [])}
Current Reminders: ${JSON.stringify(context?.reminders || [])}
Current Device Settings: ${JSON.stringify(context?.settings || {})}

User Request: "${prompt}"

MEMORY BEHAVIOR:
- If user says "Remember this", "Save this", "Mera naam Hafiz hai yaad rakhna", extract the key information and return action "STORE_MEMORY" with key, value, and label.
- If user asks "What is my name?" or queries something in memory, recall it and return "RECALL_MEMORY".
- If user says "My new name is Saib, update it" or changes info, return "UPDATE_MEMORY".
- If user says "Forget my name" or "Clear memory", return "DELETE_MEMORY" or "CLEAR_MEMORY".

Return ONLY a strictly valid JSON object matching this schema:
{
  "speechText": "Authentic Pakistani Urdu response (polite, respectful, human-like)",
  "action": {
    "type": "STORE_MEMORY" | "RECALL_MEMORY" | "UPDATE_MEMORY" | "DELETE_MEMORY" | "CLEAR_MEMORY" | "MAKE_CALL" | "SEND_MESSAGE" | "OPEN_APP" | "TOGGLE_SETTING" | "BRIEFING" | "ADD_EVENT" | "MODIFY_EVENT" | "DELETE_EVENT" | "ADD_REMINDER" | "GENERAL_RESPONSE",
    "payload": {
      // For STORE_MEMORY: { "key": string, "value": string, "label"?: string }
      // For UPDATE_MEMORY: { "key": string, "value": string }
      // For DELETE_MEMORY: { "key": string }
      // For CLEAR_MEMORY: {}
      // For MAKE_CALL: { "contactName": string, "phoneNumber": string }
      // For SEND_MESSAGE: { "contactName": string, "phoneNumber": string, "message": string, "app": "sms" | "whatsapp" }
      // For OPEN_APP: { "appName": string }
      // For TOGGLE_SETTING: { "setting": "flashlight"|"vibration"|"soundMode"|"nightMode"|"batterySaver"|"dnd", "value"?: any }
    }
  }
}
Return ONLY valid raw JSON with NO markdown code blocks.`;

  try {
    if (aiClient) {
      const response = await aiClient.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: prompt,
        config: {
          systemInstruction,
          responseMimeType: 'application/json',
          temperature: 0.2,
        },
      });

      const responseText = response.text || '{}';
      try {
        const parsed = JSON.parse(responseText);
        return res.json(parsed);
      } catch (jsonErr) {
        // Fallback to text parsing if needed
        const clean = responseText.replace(/```json\n?|```/g, '').trim();
        const parsed = JSON.parse(clean);
        return res.json(parsed);
      }
    }
  } catch (error) {
    console.error('Gemini API call failed, falling back to local engine:', error);
  }

  // Fallback indicator so client knows to use local rule engine
  return res.json({ fallback: true });
});

// App status endpoint
app.get('/api/health', (req, res) => {
  res.json({ status: 'online', system: 'JARVIS-OS-v4.2', timestamp: new Date().toISOString() });
});

async function startServer() {
  if (process.env.NODE_ENV === 'production') {
    // Serve production build
    app.use(express.static(path.join(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.join(__dirname, 'dist', 'index.html'));
    });
  } else {
    // Mount Vite dev middleware
    const { createServer: createViteServer } = await import('vite');
    const isHmrDisabled = process.env.DISABLE_HMR === 'true';
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: isHmrDisabled ? false : { server: httpServer },
        watch: isHmrDisabled ? null : {},
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  httpServer.listen(PORT, '0.0.0.0', () => {
    console.log(`JARVIS OS dev server initialized on http://0.0.0.0:${PORT}`);
  });
}

startServer();
