import 'dotenv/config';
import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export interface SearchResultItem {
  id: string;
  title: string;
  url: string;
  snippet: string;
  domain: string;
}

export interface PageBlock {
  type: 'heading' | 'paragraph' | 'link';
  text: string;
  href?: string;
}

export interface PageLinkItem {
  title: string;
  url: string;
  domain: string;
}

function decodeHtmlEntities(input: string): string {
  return input
    .replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, '$1')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;|&apos;/g, "'")
    .replace(/&nbsp;/g, ' ')
    .replace(/&#(\d+);/g, (_m, dec) => String.fromCharCode(Number(dec)))
    .replace(/&#x([0-9a-f]+);/gi, (_m, hex) => String.fromCharCode(parseInt(hex, 16)))
    .replace(/\s+/g, ' ')
    .trim();
}

function stripTags(html: string): string {
  return decodeHtmlEntities(html.replace(/<[^>]*>/g, ' '));
}

function isSafePublicUrl(rawUrl: string): boolean {
  try {
    const parsed = new URL(rawUrl);
    if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') return false;
    const host = parsed.hostname.toLowerCase();
    if (
      host === 'localhost' ||
      host === '127.0.0.1' ||
      host === '0.0.0.0' ||
      host === '[::1]' ||
      host.startsWith('10.') ||
      host.startsWith('192.168.') ||
      host.startsWith('169.254.') ||
      host.endsWith('.local')
    ) {
      return false;
    }
    return true;
  } catch {
    return false;
  }
}

async function fetchWithTimeout(url: string, timeoutMs = 5500): Promise<Response> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(url, {
      signal: controller.signal,
      redirect: 'follow',
      headers: {
        'User-Agent':
          'Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36',
        Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'ar,en-US;q=0.9,en;q=0.8',
      },
    });
  } finally {
    clearTimeout(timer);
  }
}

function unwrapSearchUrl(rawLink: string): string {
  try {
    const parsed = new URL(rawLink);
    if (parsed.hostname.endsWith('bing.com') && parsed.pathname.startsWith('/ck/')) {
      const encoded = parsed.searchParams.get('u');
      if (encoded && encoded.startsWith('a1')) {
        const b64 = encoded.slice(2).replace(/-/g, '+').replace(/_/g, '/');
        const decoded = Buffer.from(b64, 'base64').toString('utf8');
        if (isSafePublicUrl(decoded)) return decoded;
      }
    }
  } catch {
    // Keep original URL if decoding fails
  }
  return rawLink;
}

function parseRssItems(xml: string, idPrefix: string, limit = 8): SearchResultItem[] {
  const items: SearchResultItem[] = [];
  const itemRegex = /<item>([\s\S]*?)<\/item>/gi;
  let match: RegExpExecArray | null;

  while ((match = itemRegex.exec(xml)) !== null && items.length < limit) {
    const block = match[1];
    const titleMatch = block.match(/<title>([\s\S]*?)<\/title>/i);
    const linkMatch = block.match(/<link>([\s\S]*?)<\/link>/i);
    const descMatch = block.match(/<description>([\s\S]*?)<\/description>/i);

    const rawLink = unwrapSearchUrl(linkMatch ? decodeHtmlEntities(linkMatch[1]) : '');
    const title = titleMatch ? stripTags(titleMatch[1]) : '';
    const snippet = descMatch ? stripTags(descMatch[1]) : '';

    if (title && isSafePublicUrl(rawLink)) {
      const domain = new URL(rawLink).hostname.replace(/^www\./, '');
      items.push({
        id: `${idPrefix}-${items.length}`,
        title,
        url: rawLink,
        snippet: snippet || title,
        domain,
      });
    }
  }
  return items;
}

function buildOfflineResults(query: string): SearchResultItem[] {
  const encoded = encodeURIComponent(query);
  return [
    {
      id: 'res-wiki-ar',
      title: `${query} — ويكيبيديا الموسوعة الحرة`,
      url: `https://ar.wikipedia.org/wiki/${encoded}`,
      snippet: `مقالة موسوعية باللغة العربية تتناول موضوع ${query} ومفاهيمه الأساسية.`,
      domain: 'ar.wikipedia.org',
    },
    {
      id: 'res-wiki-en',
      title: `${query} — Wikipedia`,
      url: `https://en.wikipedia.org/wiki/${encoded}`,
      snippet: `Comprehensive encyclopedia overview and references about ${query}.`,
      domain: 'en.wikipedia.org',
    },
    {
      id: 'res-google',
      title: `نتائج بحث جوجل: ${query}`,
      url: `https://www.google.com/search?q=${encoded}`,
      snippet: `البحث المباشر عبر الويب حول "${query}".`,
      domain: 'google.com',
    },
  ];
}

async function performWebSearch(query: string): Promise<{
  results: SearchResultItem[];
  source: 'live' | 'fallback';
}> {
  const results: SearchResultItem[] = [];
  const seenUrls = new Set<string>();
  const addResult = (item: SearchResultItem) => {
    if (!seenUrls.has(item.url)) {
      seenUrls.add(item.url);
      results.push(item);
    }
  };

  const isArabic = /[\u0600-\u06FF]/.test(query);

  // Run Bing Live Web Search RSS + Wikipedia API in parallel for speed & completeness
  const [bingRes, wikiRes] = await Promise.allSettled([
    fetchWithTimeout(
      `https://www.bing.com/search?q=${encodeURIComponent(query)}&format=rss&setlang=${
        isArabic ? 'ar' : 'en'
      }`,
      4500
    ).then((r) => (r.ok ? r.text() : '')),
    fetchWithTimeout(
      `https://${isArabic ? 'ar' : 'en'}.wikipedia.org/w/api.php?action=query&list=search&srsearch=${encodeURIComponent(
        query
      )}&format=json&srlimit=3&utf8=1`,
      3800
    ).then((r) => (r.ok ? r.json() : null)),
  ]);

  if (bingRes.status === 'fulfilled' && bingRes.value) {
    for (const item of parseRssItems(bingRes.value, 'bing', 6)) {
      addResult(item);
    }
  }

  if (wikiRes.status === 'fulfilled' && wikiRes.value) {
    const lang = isArabic ? 'ar' : 'en';
    const data = wikiRes.value as {
      query?: { search?: Array<{ title: string; snippet: string }> };
    };
    const items = data?.query?.search ?? [];
    for (let i = 0; i < items.length; i++) {
      const item = items[i];
      const titleUrl = `https://${lang}.wikipedia.org/wiki/${encodeURIComponent(
        item.title.replace(/ /g, '_')
      )}`;
      addResult({
        id: `wiki-${i}`,
        title: `${item.title} — ويكيبيديا`,
        url: titleUrl,
        snippet: stripTags(item.snippet),
        domain: `${lang}.wikipedia.org`,
      });
    }
  }

  // Supplement with Google News RSS if results are still sparse
  if (results.length < 4) {
    try {
      const gnewsUrl = `https://news.google.com/rss/search?q=${encodeURIComponent(
        query
      )}&hl=${isArabic ? 'ar' : 'en'}&gl=${isArabic ? 'EG' : 'US'}&ceid=${
        isArabic ? 'EG:ar' : 'US:en'
      }`;
      const r = await fetchWithTimeout(gnewsUrl, 3800);
      if (r.ok) {
        const xml = await r.text();
        for (const item of parseRssItems(xml, 'gnews', 4)) {
          addResult(item);
        }
      }
    } catch {
      // Ignore
    }
  }

  if (results.length > 0) {
    return { results: results.slice(0, 8), source: 'live' };
  }

  return { results: buildOfflineResults(query), source: 'fallback' };
}

async function fetchWikipediaArticle(parsedUrl: URL): Promise<{
  title: string;
  url: string;
  blocks: PageBlock[];
  links: PageLinkItem[];
  live: boolean;
} | null> {
  const langMatch = parsedUrl.hostname.match(/^([a-z]{2,3})\.wikipedia\.org$/i);
  if (!langMatch || !parsedUrl.pathname.startsWith('/wiki/')) return null;

  const lang = langMatch[1].toLowerCase();
  const rawTitle = decodeURIComponent(parsedUrl.pathname.replace(/^\/wiki\//, ''));
  if (!rawTitle || rawTitle.includes(':')) return null;

  try {
    const apiUrl = `https://${lang}.wikipedia.org/w/api.php?action=query&prop=extracts|links&explaintext=true&exsectionformat=plain&pllimit=6&plnamespace=0&redirects=1&titles=${encodeURIComponent(
      rawTitle
    )}&format=json&utf8=1`;
    const res = await fetchWithTimeout(apiUrl, 4500);
    if (!res.ok) return null;

    const data = (await res.json()) as {
      query?: {
        pages?: Record<
          string,
          {
            title?: string;
            extract?: string;
            links?: Array<{ title: string }>;
          }
        >;
      };
    };
    const pages = data?.query?.pages;
    if (!pages) return null;
    const page = Object.values(pages)[0];
    if (!page || !page.extract) return null;

    const blocks: PageBlock[] = [];
    const lines = page.extract
      .split(/\n+/)
      .map((l) => l.trim())
      .filter((l) => l.length > 0);

    for (const line of lines) {
      if (blocks.length >= 22) break;
      if (line.length < 48 && !line.endsWith('.') && !line.endsWith('؟')) {
        blocks.push({ type: 'heading', text: line });
      } else {
        blocks.push({ type: 'paragraph', text: line });
      }
    }

    const links: PageLinkItem[] = (page.links ?? []).slice(0, 4).map((l) => ({
      title: l.title,
      url: `https://${lang}.wikipedia.org/wiki/${encodeURIComponent(
        l.title.replace(/ /g, '_')
      )}`,
      domain: `${lang}.wikipedia.org`,
    }));

    return {
      title: `${page.title || rawTitle} — ويكيبيديا`,
      url: parsedUrl.toString(),
      blocks,
      links,
      live: true,
    };
  } catch {
    return null;
  }
}

async function fetchReadablePage(targetUrl: string): Promise<{
  title: string;
  url: string;
  blocks: PageBlock[];
  links: PageLinkItem[];
  videoUrl?: string;
  imageUrl?: string;
  live: boolean;
}> {
  if (!isSafePublicUrl(targetUrl)) {
    return {
      title: 'رابط غير مدعوم',
      url: targetUrl,
      blocks: [
        {
          type: 'paragraph',
          text: 'الرابط المطلوب غير صالح أو محجوب لأسباب الأمان. جرّب كتابة اسم موقع عام أو البحث في جوجل.',
        },
      ],
      links: [],
      live: false,
    };
  }

  const parsedUrl = new URL(targetUrl);

  // Handle Google search & Google homepage directly with clean live search results
  if (/^(www\.)?google\.[a-z.]+$/i.test(parsedUrl.hostname)) {
    const q = parsedUrl.searchParams.get('q')?.trim() || 'أخبار التقنية والواقع الافتراضي';
    const search = await performWebSearch(q);
    const blocks: PageBlock[] = [
      { type: 'heading', text: `نتائج بحث جوجل: ${q}` },
    ];
    const links: PageLinkItem[] = [];
    for (const r of search.results.slice(0, 6)) {
      blocks.push({ type: 'heading', text: r.title });
      blocks.push({ type: 'paragraph', text: `${r.domain} — ${r.snippet}` });
      if (links.length < 4) {
        links.push({ title: r.title, url: r.url, domain: r.domain });
      }
    }
    return {
      title: `بحث Google: ${q}`,
      url: targetUrl,
      blocks,
      links,
      live: search.source === 'live',
    };
  }

  // Fast, structured path for Wikipedia articles
  const wikiResult = await fetchWikipediaArticle(parsedUrl);
  if (wikiResult) {
    return wikiResult;
  }

  try {
    const res = await fetchWithTimeout(targetUrl, 5500);
    const finalUrl = res.url || targetUrl;
    if (!res.ok) {
      throw new Error(`HTTP ${res.status}`);
    }
    const html = await res.text();
    const cleanedMeta = html
      .replace(/<script[\s\S]*?<\/script>/gi, '')
      .replace(/<style[\s\S]*?<\/style>/gi, '')
      .replace(/<noscript[\s\S]*?<\/noscript>/gi, '')
      .replace(/<svg[\s\S]*?<\/svg>/gi, '');

    const titleMatch = cleanedMeta.match(/<title[^>]*>([\s\S]*?)<\/title>/i);
    const metaDescMatch =
      cleanedMeta.match(/<meta[^>]*name=["']description["'][^>]*content=["']([^"']+)["']/i) ||
      cleanedMeta.match(/<meta[^>]*property=["']og:description["'][^>]*content=["']([^"']+)["']/i);
    const ogImageMatch =
      cleanedMeta.match(/<meta[^>]*property=["']og:image["'][^>]*content=["']([^"']+)["']/i) ||
      cleanedMeta.match(/<meta[^>]*name=["']twitter:image["'][^>]*content=["']([^"']+)["']/i);
    const title = titleMatch ? stripTags(titleMatch[1]) : parsedUrl.hostname;
    const imageUrl =
      ogImageMatch && isSafePublicUrl(ogImageMatch[1]) ? ogImageMatch[1] : undefined;

    // Focus extraction on main article/body by stripping nav, header, footer, aside menus
    const cleaned = cleanedMeta
      .replace(/<nav[\s\S]*?<\/nav>/gi, '')
      .replace(/<header[\s\S]*?<\/header>/gi, '')
      .replace(/<footer[\s\S]*?<\/footer>/gi, '')
      .replace(/<aside[\s\S]*?<\/aside>/gi, '')
      .replace(/<form[\s\S]*?<\/form>/gi, '');

    const blocks: PageBlock[] = [];
    if (metaDescMatch) {
      const desc = decodeHtmlEntities(metaDescMatch[1]);
      if (desc.length > 15) {
        blocks.push({ type: 'heading', text: 'نبذة عن الصفحة' });
        blocks.push({ type: 'paragraph', text: desc });
      }
    }

    const blockRegex = /<(h1|h2|h3|h4|p|li|blockquote)[^>]*>([\s\S]*?)<\/\1>/gi;
    let m: RegExpExecArray | null;
    const seenText = new Set<string>();
    while ((m = blockRegex.exec(cleaned)) !== null && blocks.length < 24) {
      const tag = m[1].toLowerCase();
      const text = stripTags(m[2]);
      if (text.length < 18 || seenText.has(text)) continue;
      seenText.add(text);
      if (tag === 'h1' || tag === 'h2' || tag === 'h3' || tag === 'h4') {
        blocks.push({ type: 'heading', text });
      } else {
        blocks.push({ type: 'paragraph', text });
      }
    }

    // Extract clickable page links so the user can surf to related pages by gaze
    const links: PageLinkItem[] = [];
    const seenHrefs = new Set<string>([finalUrl]);
    const anchorRegex = /<a[^>]*href=["']([^"'#]+)["'][^>]*>([\s\S]*?)<\/a>/gi;
    let am: RegExpExecArray | null;
    while ((am = anchorRegex.exec(cleaned)) !== null && links.length < 6) {
      const rawHref = decodeHtmlEntities(am[1]);
      const linkText = stripTags(am[2]);
      if (!linkText || linkText.length < 4 || linkText.length > 72) continue;
      try {
        const resolved = new URL(rawHref, finalUrl).toString();
        if (!isSafePublicUrl(resolved) || seenHrefs.has(resolved)) continue;
        seenHrefs.add(resolved);
        links.push({
          title: linkText,
          url: resolved,
          domain: new URL(resolved).hostname.replace(/^www\./, ''),
        });
      } catch {
        // Skip invalid href
      }
    }

    // Detect direct MP4/WebM media link if present
    const videoMatch = cleanedMeta.match(/https?:\/\/[^"'\s<>]+\.(?:mp4|webm)(?:\?[^"'\s<>]*)?/i);
    const videoUrl = videoMatch && isSafePublicUrl(videoMatch[0]) ? videoMatch[0] : undefined;

    if (blocks.length === 0) {
      const siteSearch = await performWebSearch(`site:${parsedUrl.hostname}`);
      for (const item of siteSearch.results.slice(0, 4)) {
        blocks.push({ type: 'heading', text: item.title });
        blocks.push({ type: 'paragraph', text: item.snippet });
        if (links.length < 4) {
          links.push({ title: item.title, url: item.url, domain: item.domain });
        }
      }
    }

    if (blocks.length === 0) {
      blocks.push({
        type: 'paragraph',
        text: 'تم فتح الصفحة بنجاح ولكنها تعتمد على واجهات برمجية لا تعرض نصوصاً مباشرة. يمكنك حفظ الرابط أو تصفح الروابط المجاورة.',
      });
    }

    return { title, url: finalUrl, blocks, links, videoUrl, imageUrl, live: true };
  } catch {
    // Graceful site-search fallback so user still sees rich info about the domain
    const host = parsedUrl.hostname.replace(/^www\./, '');
    const fallbackSearch = await performWebSearch(host);
    const blocks: PageBlock[] = [
      {
        type: 'heading',
        text: `ملخص الموقع (${host})`,
      },
      {
        type: 'paragraph',
        text: 'هذا الموقع يمنع القراءة المباشرة للخوادم الوسيطة، لذا عرضنا لك أبرز صفحاته ونتائجه المتاحة:',
      },
    ];
    const links: PageLinkItem[] = [];
    for (const r of fallbackSearch.results.slice(0, 4)) {
      blocks.push({ type: 'heading', text: r.title });
      blocks.push({ type: 'paragraph', text: r.snippet });
      links.push({ title: r.title, url: r.url, domain: r.domain });
    }
    return {
      title: host,
      url: targetUrl,
      blocks,
      links,
      live: false,
    };
  }
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  app.get('/api/health', (_req, res) => {
    res.json({ status: 'ok', app: 'Nazar VR' });
  });

  app.get('/api/browser/search', async (req, res) => {
    const q = String(req.query.q ?? '').trim();
    if (!q) {
      return res.status(400).json({ error: 'يرجى إدخال عبارة للبحث' });
    }
    const payload = await performWebSearch(q);
    res.json({ query: q, ...payload });
  });

  app.get('/api/browser/page', async (req, res) => {
    const url = String(req.query.url ?? '').trim();
    if (!url) {
      return res.status(400).json({ error: 'يرجى تحديد رابط الصفحة' });
    }
    const page = await fetchReadablePage(url);
    res.json(page);
  });

  if (process.env.NODE_ENV !== 'production') {
    process.env.DISABLE_HMR = 'true';
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true, hmr: false, ws: false },
      appType: 'spa',
    });

    // Prevent Vite 8 @vite/client from opening a failing WebSocket when HMR is disabled
    app.get('/@vite/client', (_req, res) => {
      res.type('application/javascript').send(`
export function createHotContext() {
  return {
    data: {},
    accept() {},
    acceptExports() {},
    dispose() {},
    prune() {},
    decline() {},
    invalidate() {},
    on() {},
    off() {},
    send() {},
  };
}
export function updateStyle(id, content) {
  let style = document.querySelector(\`style[data-vite-dev-id="\${id}"]\`);
  if (!style) {
    style = document.createElement('style');
    style.setAttribute('data-vite-dev-id', id);
    document.head.appendChild(style);
  }
  style.textContent = content;
}
export function removeStyle(id) {
  const style = document.querySelector(\`style[data-vite-dev-id="\${id}"]\`);
  if (style) style.remove();
}
export function injectQuery(url) { return url; }
`);
    });

    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Nazar VR server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
