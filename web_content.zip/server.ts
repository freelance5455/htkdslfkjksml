import 'dotenv/config';
import express from 'express';
import type { Request, Response } from 'express';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import JSZip from 'jszip';
import { GoogleGenAI } from '@google/genai';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT) || 3000;
const MODEL_NAME = 'gemini-4-hydrogen';

interface IncomingMessage {
  role: 'user' | 'assistant';
  content: string;
}

interface ChatRequestBody {
  messages?: IncomingMessage[];
  replyLanguage?: 'amharic' | 'english';
}

function getGeminiClient(): GoogleGenAI {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error('GEMINI_API_KEY is not configured on the server.');
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

function buildSystemInstruction(replyLanguage: 'amharic' | 'english'): string {
  const base =
    'You are Dawitai, a helpful, respectful, accurate, and clear AI assistant. ' +
    'Users can ask questions in Amharic (አማርኛ) or English. ' +
    'Format answers cleanly using short paragraphs or bullet points when helpful so they are easy to read on mobile phones.';

  if (replyLanguage === 'english') {
    return (
      base +
      ' The user has selected English as their reply language preference. ' +
      'Respond clearly in English, unless the user explicitly asks you inside their message to write in Amharic.'
    );
  }

  return (
    base +
    ' By default, ALWAYS answer in natural, clear, idiomatic Amharic (አማርኛ) using proper Ge’ez/Ethiopic script—even when the user asks their question in English. ' +
    'Only switch to English if the user explicitly asks in their message for an English answer (for example, "reply in English" or "explain in English").'
  );
}

function formatApiError(err: unknown): { status: number; message: string } {
  if (err && typeof err === 'object') {
    const anyErr = err as { status?: number; message?: string };
    const status = typeof anyErr.status === 'number' ? anyErr.status : 500;
    const rawMsg = anyErr.message || 'Failed to generate a response.';

    if (status === 400 || rawMsg.includes('API_KEY_INVALID')) {
      return {
        status: 400,
        message: 'Invalid Gemini API key. Please check your key in Settings > Secrets.',
      };
    }
    if (status === 403 || rawMsg.includes('PERMISSION_DENIED')) {
      return {
        status: 403,
        message: 'Gemini API permission denied. Please verify your API key in Settings > Secrets.',
      };
    }
    if (status === 429 || rawMsg.includes('RESOURCE_EXHAUSTED')) {
      return {
        status: 429,
        message: 'Rate limit reached. Please wait a moment and try again.',
      };
    }
    return { status, message: rawMsg };
  }
  return { status: 500, message: 'Unexpected server error while contacting Dawitai AI.' };
}

async function createServer() {
  const app = express();
  app.use(express.json({ limit: '2mb' }));

  app.get('/api/health', (_req: Request, res: Response) => {
    res.json({ ok: true, app: 'Dawitai' });
  });

  app.get('/api/export/android', async (req: Request, res: Response) => {
    try {
      const requestedOrigin =
        typeof req.query.origin === 'string' && /^https?:\/\//i.test(req.query.origin)
          ? req.query.origin.replace(/\/+$/, '')
          : '';
      const fallbackOrigin =
        process.env.APP_URL ||
        `${req.protocol}://${req.get('host') || 'localhost:3000'}`;
      const appOrigin = (requestedOrigin || fallbackOrigin).replace(/\/+$/, '');
      const parsedOrigin = new URL(appOrigin);

      const zip = new JSZip();

      const addDirRecursive = (dirPath: string, zipFolder: string) => {
        if (!fs.existsSync(dirPath)) return;
        for (const entry of fs.readdirSync(dirPath, { withFileTypes: true })) {
          const fullPath = path.join(dirPath, entry.name);
          const relZipPath = zipFolder ? `${zipFolder}/${entry.name}` : entry.name;
          if (entry.isDirectory()) {
            addDirRecursive(fullPath, relZipPath);
          } else if (entry.isFile()) {
            zip.file(relZipPath, fs.readFileSync(fullPath));
          }
        }
      };

      const rootFiles = [
        'package.json',
        'tsconfig.json',
        'vite.config.ts',
        'index.html',
        'server.ts',
        'metadata.json',
        '.env.example',
      ];
      for (const fileName of rootFiles) {
        const filePath = path.join(__dirname, fileName);
        if (fs.existsSync(filePath)) {
          zip.file(fileName, fs.readFileSync(filePath));
        }
      }

      addDirRecursive(path.join(__dirname, 'src'), 'src');
      addDirRecursive(path.join(__dirname, 'public'), 'public');

      const capacitorConfig = {
        appId: 'com.dawitai.app',
        appName: 'Dawitai',
        webDir: 'dist',
        server: {
          url: appOrigin,
          cleartext: appOrigin.startsWith('http://'),
        },
        android: {
          allowMixedContent: false,
        },
      };
      zip.file('capacitor.config.json', JSON.stringify(capacitorConfig, null, 2));

      const twaManifest = {
        packageId: 'com.dawitai.app',
        host: parsedOrigin.host,
        name: 'Dawitai',
        launcherName: 'Dawitai',
        display: 'standalone',
        themeColor: '#0F766E',
        navigationColor: '#0F766E',
        backgroundColor: '#F8FAFC',
        enableNotifications: false,
        startUrl: '/',
        iconUrl: `${appOrigin}/pwa-512x512.png`,
        maskableIconUrl: `${appOrigin}/pwa-maskable-512x512.png`,
        splashScreenFadeOutDuration: 300,
        appVersionName: '1.0.0',
        appVersionCode: 1,
        shortcuts: [],
        generatorApp: 'dawitai-export',
        webManifestUrl: `${appOrigin}/manifest.webmanifest`,
        fallbackType: 'customtabs',
        features: {},
        alphaDependencies: { enabled: false },
        enableSiteSettingsShortcut: true,
        isChromeOSOnly: false,
        orientation: 'portrait',
      };
      zip.file('twa-manifest.json', JSON.stringify(twaManifest, null, 2));

      const buildScript = `#!/usr/bin/env bash
set -euo pipefail

echo "=== Dawitai Android APK Build Helper ==="
echo "1) Installing dependencies..."
npm install

echo "2) Building web assets..."
npm run build

echo "3) Setting up Capacitor Android project..."
if [ ! -d "android" ]; then
  npm install @capacitor/core @capacitor/cli @capacitor/android
  npx cap add android
fi

npx cap sync android
echo "Done! Open ./android in Android Studio or run: cd android && ./gradlew assembleDebug"
`;
      zip.file('build-android-apk.sh', buildScript, { unixPermissions: '755' });

      const guide = `# Installing Dawitai on Android

You have three ways to install Dawitai on your Android phone:

## Option 1: Direct Install from Chrome (Fastest — No Computer Needed)
1. Open ${appOrigin} in **Google Chrome** on your Android phone.
2. Tap **Get App** inside Dawitai (or tap Chrome's **⋮** menu -> **Install app**).
3. Confirm **Install**. Dawitai will appear in your Android app drawer with its own icon and full-screen window.

## Option 2: Build a Standalone .APK Using Bubblewrap (Recommended for APK)
Requires Node.js 18+ and Java JDK 17 + Android Command Line Tools (Bubblewrap can download them automatically):
\`\`\`bash
npm install -g @bubblewrap/cli
bubblewrap init --manifest=${appOrigin}/manifest.webmanifest
bubblewrap build
\`\`\`
Or use the included \`twa-manifest.json\` directly:
\`\`\`bash
bubblewrap update
bubblewrap build
\`\`\`
This outputs \`app-release-signed.apk\` which you can transfer to your Android phone and install.

## Option 3: Build an Android Studio / Capacitor Project
This archive includes the full Dawitai app source code and \`capacitor.config.json\` pointing to \`${appOrigin}\` (so AI requests continue to work securely through your hosted server).
\`\`\`bash
chmod +x build-android-apk.sh
./build-android-apk.sh
cd android && ./gradlew assembleDebug
\`\`\`
Your debug APK will be created at:
\`android/app/build/outputs/apk/debug/app-debug.apk\`
`;
      zip.file('ANDROID-INSTALL-GUIDE.md', guide);

      const zipBuffer = await zip.generateAsync({
        type: 'nodebuffer',
        compression: 'DEFLATE',
        compressionOptions: { level: 6 },
      });

      res.setHeader('Content-Type', 'application/zip');
      res.setHeader(
        'Content-Disposition',
        'attachment; filename="dawitai-android-export.zip"'
      );
      res.setHeader('Content-Length', String(zipBuffer.length));
      res.send(zipBuffer);
    } catch (err) {
      const message =
        err instanceof Error ? err.message : 'Failed to build Android export ZIP.';
      res.status(500).json({ error: message });
    }
  });

  app.post('/api/chat', async (req: Request, res: Response) => {
    const body = (req.body || {}) as ChatRequestBody;
    const rawMessages = Array.isArray(body.messages) ? body.messages : [];
    const replyLanguage = body.replyLanguage === 'english' ? 'english' : 'amharic';

    const validMessages = rawMessages.filter(
      (m) =>
        m &&
        (m.role === 'user' || m.role === 'assistant') &&
        typeof m.content === 'string' &&
        m.content.trim().length > 0
    );

    if (validMessages.length === 0) {
      res.status(400).json({ error: 'Please enter a question before sending.' });
      return;
    }

    let ai: GoogleGenAI;
    try {
      ai = getGeminiClient();
    } catch (err) {
      const formatted = formatApiError(err);
      res.status(formatted.status).json({ error: formatted.message });
      return;
    }

    res.setHeader('Content-Type', 'text/event-stream; charset=utf-8');
    res.setHeader('Cache-Control', 'no-cache, no-transform');
    res.setHeader('Connection', 'keep-alive');
    res.flushHeaders?.();

    const contents = validMessages.map((msg) => ({
      role: msg.role === 'assistant' ? 'model' : 'user',
      parts: [{ text: msg.content.trim() }],
    }));

    const abortController = new AbortController();
    req.on('close', () => {
      abortController.abort();
    });

    try {
      const responseStream = await ai.models.generateContentStream({
        model: MODEL_NAME,
        contents,
        config: {
          systemInstruction: buildSystemInstruction(replyLanguage),
        },
      });

      for await (const chunk of responseStream) {
        if (abortController.signal.aborted) {
          break;
        }
        const text = chunk.text;
        if (text) {
          res.write(`data: ${JSON.stringify({ text })}\n\n`);
        }
      }

      if (!abortController.signal.aborted) {
        res.write('data: [DONE]\n\n');
        res.end();
      }
    } catch (err) {
      if (abortController.signal.aborted) {
        return;
      }
      const formatted = formatApiError(err);
      res.write(`data: ${JSON.stringify({ error: formatted.message })}\n\n`);
      res.write('data: [DONE]\n\n');
      res.end();
    }
  });

  if (process.env.NODE_ENV === 'production') {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('/{*splat}', (_req: Request, res: Response) => {
      const indexHtml = path.join(distPath, 'index.html');
      if (fs.existsSync(indexHtml)) {
        res.sendFile(indexHtml);
      } else {
        res.status(404).send('Build output not found.');
      }
    });
  } else {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Dawitai server listening on http://0.0.0.0:${PORT}`);
  });
}

createServer().catch((err) => {
  console.error('Failed to start Dawitai server:', err);
  process.exit(1);
});
