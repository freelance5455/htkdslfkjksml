import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';
import dotenv from 'dotenv';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = parseInt(process.env.PORT || '3000', 10);
const ANIMES_FILE = path.resolve(__dirname, 'data', 'animes.json');
const SECRET_CODE = '8421459082hiteshYS';

app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Helper to read animes
function getAnimesList(): any[] {
  try {
    if (fs.existsSync(ANIMES_FILE)) {
      const data = fs.readFileSync(ANIMES_FILE, 'utf-8');
      return JSON.parse(data);
    }
  } catch (err) {
    console.error('Error reading animes file:', err);
  }
  return [];
}

// Helper to save animes
function saveAnimesList(animes: any[]): boolean {
  try {
    fs.writeFileSync(ANIMES_FILE, JSON.stringify(animes, null, 2), 'utf-8');
    return true;
  } catch (err) {
    console.error('Error saving animes file:', err);
    return false;
  }
}

function isAuthorized(req: Request): boolean {
  const code =
    req.body?.secretCode ||
    (req.headers['x-secret-code'] as string) ||
    (req.query.secret as string) ||
    (req.query.secretCode as string);
  return code === SECRET_CODE;
}

// 1. GET /api/animes - Public feed for all visitors
app.get('/api/animes', (_req: Request, res: Response) => {
  const animes = getAnimesList();
  res.json({ success: true, animes });
});

// 2. POST /api/animes - Secret Admin adds new Anime
app.post('/api/animes', (req: Request, res: Response) => {
  if (!isAuthorized(req)) {
    return res.status(403).json({ error: 'Unauthorized. Invalid secret key.' });
  }

  const { title, description, poster, genres } = req.body;

  if (!title || !title.trim()) {
    return res.status(400).json({ error: 'Anime title is required.' });
  }

  const cleanTitle = title.trim();
  const cleanDesc = (description || 'Exciting anime series streaming now.').trim();
  const cleanPoster = (poster || 'https://images.unsplash.com/photo-1578632767115-351597cf2477?w=800&auto=format&fit=crop&q=80').trim();

  const newAnime = {
    id: 'anime-' + Date.now() + '-' + Math.random().toString(36).substring(2, 6),
    title: cleanTitle,
    description: cleanDesc,
    poster: cleanPoster,
    genres: Array.isArray(genres) && genres.length > 0 ? genres : ['Action', 'Fantasy'],
    createdAt: Date.now(),
    seasons: [
      {
        id: 'season-' + Date.now() + '-1',
        seasonNumber: 1,
        title: 'Season 1',
        episodes: [],
      },
    ],
  };

  const animes = getAnimesList();
  animes.unshift(newAnime);
  saveAnimesList(animes);

  return res.json({ success: true, anime: newAnime });
});

// 3. DELETE /api/animes/:id - Delete an entire Anime
app.delete('/api/animes/:id', (req: Request, res: Response) => {
  if (!isAuthorized(req)) {
    return res.status(403).json({ error: 'Unauthorized.' });
  }

  const { id } = req.params;
  let animes = getAnimesList();
  const beforeCount = animes.length;
  animes = animes.filter((a: any) => a.id !== id);

  if (animes.length === beforeCount) {
    return res.status(404).json({ error: 'Anime not found.' });
  }

  saveAnimesList(animes);
  return res.json({ success: true, message: 'Anime deleted' });
});

// 4. POST /api/animes/:id/seasons - Add a Season to Anime
app.post('/api/animes/:id/seasons', (req: Request, res: Response) => {
  if (!isAuthorized(req)) {
    return res.status(403).json({ error: 'Unauthorized.' });
  }

  const { id } = req.params;
  const { title, seasonNumber } = req.body;

  const animes = getAnimesList();
  const anime = animes.find((a: any) => a.id === id);
  if (!anime) {
    return res.status(404).json({ error: 'Anime not found.' });
  }

  if (!Array.isArray(anime.seasons)) {
    anime.seasons = [];
  }

  const nextNum = seasonNumber ? Number(seasonNumber) : anime.seasons.length + 1;
  const newSeason = {
    id: 'season-' + Date.now() + '-' + nextNum,
    seasonNumber: nextNum,
    title: (title || `Season ${nextNum}`).trim(),
    episodes: [],
  };

  anime.seasons.push(newSeason);
  saveAnimesList(animes);

  return res.json({ success: true, season: newSeason, anime });
});

// 5. POST /api/animes/:id/seasons/:seasonId/episodes - Add Episode to Season
app.post('/api/animes/:id/seasons/:seasonId/episodes', (req: Request, res: Response) => {
  if (!isAuthorized(req)) {
    return res.status(403).json({ error: 'Unauthorized.' });
  }

  const { id, seasonId } = req.params;
  const { episodeNumber, title, link, description } = req.body;

  if (!link || !link.trim()) {
    return res.status(400).json({ error: 'Episode video/pCloud link is required.' });
  }

  const animes = getAnimesList();
  const anime = animes.find((a: any) => a.id === id);
  if (!anime) {
    return res.status(404).json({ error: 'Anime not found.' });
  }

  const season = anime.seasons.find((s: any) => s.id === seasonId);
  if (!season) {
    return res.status(404).json({ error: 'Season not found.' });
  }

  if (!Array.isArray(season.episodes)) {
    season.episodes = [];
  }

  const epNum = episodeNumber ? Number(episodeNumber) : season.episodes.length + 1;
  const epTitle = (title || `Episode ${epNum}`).trim();

  const newEpisode = {
    id: 'ep-' + Date.now() + '-' + epNum,
    episodeNumber: epNum,
    title: epTitle,
    link: link.trim(),
    description: (description || `Episode ${epNum}`).trim(),
  };

  season.episodes.push(newEpisode);
  saveAnimesList(animes);

  return res.json({ success: true, episode: newEpisode, anime });
});

// 6. DELETE Season
app.delete('/api/animes/:id/seasons/:seasonId', (req: Request, res: Response) => {
  if (!isAuthorized(req)) {
    return res.status(403).json({ error: 'Unauthorized.' });
  }

  const { id, seasonId } = req.params;
  const animes = getAnimesList();
  const anime = animes.find((a: any) => a.id === id);
  if (!anime) return res.status(404).json({ error: 'Anime not found.' });

  anime.seasons = (anime.seasons || []).filter((s: any) => s.id !== seasonId);
  saveAnimesList(animes);

  return res.json({ success: true, message: 'Season deleted', anime });
});

// 7. DELETE Episode
app.delete('/api/animes/:id/seasons/:seasonId/episodes/:episodeId', (req: Request, res: Response) => {
  if (!isAuthorized(req)) {
    return res.status(403).json({ error: 'Unauthorized.' });
  }

  const { id, seasonId, episodeId } = req.params;
  const animes = getAnimesList();
  const anime = animes.find((a: any) => a.id === id);
  if (!anime) return res.status(404).json({ error: 'Anime not found.' });

  const season = anime.seasons.find((s: any) => s.id === seasonId);
  if (!season) return res.status(404).json({ error: 'Season not found.' });

  season.episodes = (season.episodes || []).filter((e: any) => e.id !== episodeId);
  saveAnimesList(animes);

  return res.json({ success: true, message: 'Episode deleted', anime });
});

// Helper to extract pCloud code
function extractPcloudCode(rawUrl: string): { code: string; isEu: boolean } {
  const trimmed = rawUrl.trim();
  const isEu = /e\.pcloud\.link|eapi\.pcloud\.com/i.test(trimmed);

  if (/^[a-zA-Z0-9_-]{5,40}$/.test(trimmed)) {
    return { code: trimmed, isEu };
  }

  try {
    const parsed = new URL(trimmed);
    const codeParam = parsed.searchParams.get('code');
    if (codeParam) return { code: codeParam, isEu };

    const pathParts = parsed.pathname.split('/').filter(Boolean);
    const last = pathParts[pathParts.length - 1];
    if (last && last.length >= 6) {
      return { code: last, isEu };
    }
  } catch {
    const match = trimmed.match(/code=([a-zA-Z0-9_-]+)/i);
    if (match) return { code: match[1], isEu };
  }
  return { code: '', isEu };
}

// 7. GET /api/resolve - Resolves pCloud and direct video links
app.get('/api/resolve', async (req: Request, res: Response) => {
  const targetUrl = (req.query.url as string || '').trim();

  if (!targetUrl) {
    return res.status(400).json({ error: 'Please provide a valid video link.' });
  }

  // Direct video
  const isDirectVideo = /\.(mp4|mkv|webm|m3u8|mov)(\?.*)?$/i.test(targetUrl);
  if (isDirectVideo) {
    const fileName = targetUrl.split('/').pop()?.split('?')[0] || 'video.mp4';
    return res.json({
      success: true,
      provider: 'direct',
      type: 'stream',
      title: decodeURIComponent(fileName),
      stream_url: targetUrl,
      proxy_url: `/api/proxy-stream?url=${encodeURIComponent(targetUrl)}`,
    });
  }

  // pCloud
  const isPcloud = /pcloud\.(link|com)|publink/i.test(targetUrl) || extractPcloudCode(targetUrl).code !== '';
  if (isPcloud) {
    const { code, isEu } = extractPcloudCode(targetUrl);
    if (!code) {
      return res.status(400).json({ error: 'Could not extract pCloud code from link.' });
    }

    const apiDomains = isEu
      ? ['https://eapi.pcloud.com', 'https://api.pcloud.com']
      : ['https://api.pcloud.com', 'https://eapi.pcloud.com'];

    for (const domain of apiDomains) {
      try {
        const metaRes = await fetch(`${domain}/showpublink?code=${encodeURIComponent(code)}`);
        const metaData = await metaRes.json();

        if (metaData?.result === 0 && metaData.metadata) {
          const item = metaData.metadata.isfolder && Array.isArray(metaData.metadata.contents)
            ? metaData.metadata.contents.find((f: any) => !f.isfolder) || metaData.metadata.contents[0]
            : metaData.metadata;

          const fileId = item.fileid;
          const fileName = item.name || 'Anime Episode';
          const fileSize = item.size;

          const dlRes = await fetch(
            `${domain}/getpublinkdownload?code=${encodeURIComponent(code)}${fileId ? `&fileid=${fileId}` : ''}`
          );
          const dlData = await dlRes.json();

          if (dlData?.result === 0 && Array.isArray(dlData.hosts) && dlData.hosts.length > 0 && dlData.path) {
            const host = dlData.hosts[0];
            const directStreamUrl = `https://${host}${dlData.path}`;

            return res.json({
              success: true,
              provider: 'pcloud',
              type: 'stream',
              title: fileName,
              stream_url: directStreamUrl,
              proxy_url: `/api/proxy-stream?url=${encodeURIComponent(directStreamUrl)}`,
              size: fileSize,
              code,
            });
          }
        }
      } catch {
        // try next
      }
    }

    const embedUrl = `https://${isEu ? 'e' : 'u'}.pcloud.link/publink/show?code=${encodeURIComponent(code)}`;
    return res.json({
      success: true,
      provider: 'pcloud',
      type: 'embed_fallback',
      title: 'pCloud Video',
      embed_url: embedUrl,
      code,
    });
  }

  // Fallback direct
  return res.json({
    success: true,
    provider: 'direct',
    type: 'stream',
    title: 'Streaming Video',
    stream_url: targetUrl,
    proxy_url: `/api/proxy-stream?url=${encodeURIComponent(targetUrl)}`,
  });
});

// 8. GET /api/proxy-stream - Range byte-chunk streamer for progressive buffering
app.get('/api/proxy-stream', async (req: Request, res: Response) => {
  const streamUrl = req.query.url as string;
  if (!streamUrl) {
    return res.status(400).send('Missing url parameter');
  }

  try {
    const rangeHeader = req.headers.range;
    const fetchHeaders: Record<string, string> = {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
      'Accept': '*/*',
    };

    if (rangeHeader) {
      fetchHeaders['Range'] = rangeHeader;
    }

    const videoResponse = await fetch(streamUrl, {
      headers: fetchHeaders,
      redirect: 'follow',
    });

    if (!videoResponse.ok && videoResponse.status !== 206) {
      return res.status(videoResponse.status).send(`Stream error: ${videoResponse.statusText}`);
    }

    res.status(videoResponse.status);
    const contentType = videoResponse.headers.get('content-type') || 'video/mp4';
    const contentLength = videoResponse.headers.get('content-length');
    const contentRange = videoResponse.headers.get('content-range');
    const acceptRanges = videoResponse.headers.get('accept-ranges') || 'bytes';

    res.setHeader('Content-Type', contentType);
    res.setHeader('Accept-Ranges', acceptRanges);
    res.setHeader('Access-Control-Allow-Origin', '*');

    if (contentLength) res.setHeader('Content-Length', contentLength);
    if (contentRange) res.setHeader('Content-Range', contentRange);

    if (videoResponse.body) {
      const reader = videoResponse.body.getReader();
      const pump = async () => {
        try {
          while (true) {
            const { done, value } = await reader.read();
            if (done) {
              res.end();
              break;
            }
            if (!res.write(value)) {
              await new Promise((resolve) => res.once('drain', resolve));
            }
          }
        } catch {
          res.end();
        }
      };
      await pump();
    } else {
      res.end();
    }
  } catch (err: any) {
    if (!res.headersSent) {
      res.status(500).send('Streaming error: ' + err.message);
    }
  }
});

// Start server
async function startServer() {
  const isDev = process.env.NODE_ENV !== 'production';

  if (isDev) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Anime Streaming Platform running on port ${PORT}`);
  });
}

startServer();
