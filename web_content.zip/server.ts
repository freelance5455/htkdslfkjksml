import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import dotenv from "dotenv";
import { GoogleGenAI } from "@google/genai";

dotenv.config();

async function startServer() {
  const app = express();
  app.use(express.json());

  const ai = new GoogleGenAI({
    apiKey: process.env.GEMINI_API_KEY || "",
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      }
    }
  });

  // API endpoint for Gemini AI shopping assistant / guide
  app.post("/api/gemini/chat", async (req, res) => {
    try {
      const { prompt } = req.body;
      const response = await ai.models.generateContent({
        model: "gemini-3.8-flash",
        contents: prompt || "Hello",
        config: {
          systemInstruction: "You are Daraz Nepal's official AI shopping assistant. You help Nepali customers find quality products (clothes, electronics, groceries, local handicrafts) priced in Nepali Rupees (NRS / रू). You give friendly recommendations, tips on shopping during Nepali festivals like Dashain/Tihar, and delivery info across Kathmandu, Pokhara, Lalitpur, Biratnagar, and all over Nepal."
        }
      });
      res.json({ text: response.text || "Namaste! How can I help you shop on Daraz Nepal today?" });
    } catch (err: any) {
      console.error("Gemini API error:", err);
      res.status(500).json({ error: err.message || "Failed to generate AI response" });
    }
  });

  // Vite middleware for development
  const vite = await createViteServer({
    server: { middlewareMode: true },
    appType: "spa",
  });
  app.use(vite.middlewares);

  const port = Number(process.env.PORT) || 3000;
  app.listen(port, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${port}`);
  });
}

startServer();
