import express from "express";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { createServer as createViteServer } from "vite";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT) || 3000;
const WIKI_USER_AGENT = "GulzorBotanicalEncyclopedia/1.0 (botanical-gift-app)";

interface CachedMedia {
  imageUrl: string | null;
  fullImageUrl: string | null;
  extract: string | null;
  wikiTitle: string | null;
  sourceUrl: string | null;
  timestamp: number;
}

const mediaCache = new Map<string, CachedMedia>();
const MAX_CACHE_SIZE = 2500;

function setCache(key: string, value: CachedMedia): void {
  if (mediaCache.size >= MAX_CACHE_SIZE) {
    const firstKey = mediaCache.keys().next().value;
    if (firstKey) {
      mediaCache.delete(firstKey);
    }
  }
  mediaCache.set(key, value);
}

async function fetchWithTimeout(url: string, timeoutMs = 4500): Promise<Response> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(url, {
      signal: controller.signal,
      headers: {
        "User-Agent": WIKI_USER_AGENT,
        Accept: "application/json",
      },
    });
  } finally {
    clearTimeout(timer);
  }
}

async function queryWikipediaSummary(title: string): Promise<CachedMedia | null> {
  const cleanTitle = title.trim().replace(/\s+/g, "_");
  if (!cleanTitle) return null;

  try {
    const url = `https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(cleanTitle)}`;
    const res = await fetchWithTimeout(url);
    if (!res.ok) return null;

    const data = (await res.json()) as {
      type?: string;
      title?: string;
      extract?: string;
      thumbnail?: { source?: string };
      originalimage?: { source?: string };
      content_urls?: { desktop?: { page?: string } };
    };

    if (data.type === "disambiguation") return null;

    const thumb = data.thumbnail?.source || null;
    const orig = data.originalimage?.source || thumb;
    if (!thumb && !data.extract) return null;

    return {
      imageUrl: thumb,
      fullImageUrl: orig,
      extract: data.extract || null,
      wikiTitle: data.title || title,
      sourceUrl: data.content_urls?.desktop?.page || null,
      timestamp: Date.now(),
    };
  } catch {
    return null;
  }
}

async function searchWikipediaFlower(query: string): Promise<CachedMedia | null> {
  try {
    const searchUrl = `https://en.wikipedia.org/w/api.php?action=query&generator=search&gsrsearch=${encodeURIComponent(
      query
    )}&gsrlimit=3&prop=pageimages|extracts|info&inprop=url&exintro=1&explaintext=1&exsentences=3&piprop=thumbnail|original&pithumbsize=700&format=json&origin=*`;

    const res = await fetchWithTimeout(searchUrl);
    if (!res.ok) return null;

    const data = (await res.json()) as {
      query?: {
        pages?: Record<
          string,
          {
            index?: number;
            title?: string;
            extract?: string;
            fullurl?: string;
            thumbnail?: { source?: string };
            original?: { source?: string };
          }
        >;
      };
    };

    const pages = Object.values(data.query?.pages || {}).sort(
      (a, b) => (a.index ?? 99) - (b.index ?? 99)
    );

    for (const page of pages) {
      if (page.thumbnail?.source) {
        return {
          imageUrl: page.thumbnail.source,
          fullImageUrl: page.original?.source || page.thumbnail.source,
          extract: page.extract || null,
          wikiTitle: page.title || query,
          sourceUrl: page.fullurl || null,
          timestamp: Date.now(),
        };
      }
    }

    if (pages[0]) {
      return {
        imageUrl: null,
        fullImageUrl: null,
        extract: pages[0].extract || null,
        wikiTitle: pages[0].title || query,
        sourceUrl: pages[0].fullurl || null,
        timestamp: Date.now(),
      };
    }

    return null;
  } catch {
    return null;
  }
}

async function resolveFlowerMedia(candidates: string[]): Promise<CachedMedia> {
  const unique = Array.from(
    new Set(candidates.map((c) => c.trim()).filter((c) => c.length > 1))
  );

  for (const candidate of unique) {
    // Strip cultivar quotes like Rosa 'Black Baccara' -> also check genus/species fallback
    const exact = await queryWikipediaSummary(candidate);
    if (exact && exact.imageUrl) {
      return exact;
    }
  }

  for (const candidate of unique) {
    const searched = await searchWikipediaFlower(`${candidate} flower`);
    if (searched && searched.imageUrl) {
      return searched;
    }
  }

  // Fallback to genus if binomial/cultivar did not return an image
  for (const candidate of unique) {
    const words = candidate.replace(/['"×]/g, " ").trim().split(/\s+/);
    if (words.length >= 2) {
      const genus = await queryWikipediaSummary(words[0]);
      if (genus && genus.imageUrl) {
        return genus;
      }
    }
  }

  return {
    imageUrl: null,
    fullImageUrl: null,
    extract: null,
    wikiTitle: null,
    sourceUrl: null,
    timestamp: Date.now(),
  };
}

async function startServer(): Promise<void> {
  const app = express();
  app.use(express.json());

  app.get("/api/health", (_req, res) => {
    res.json({ status: "ok", cachedFlowers: mediaCache.size });
  });

  app.get("/api/flower-media", async (req, res) => {
    const q = String(req.query.q || "");
    const latin = String(req.query.latin || "");
    const en = String(req.query.en || "");

    const cacheKey = `${q}|${latin}|${en}`.toLowerCase();
    const cached = mediaCache.get(cacheKey);
    if (cached && Date.now() - cached.timestamp < 1000 * 60 * 60 * 24) {
      res.json(cached);
      return;
    }

    // Build ordered candidate queries for accurate botanical image lookup
    const cleanLatin = latin.replace(/['"×]/g, " ").replace(/\s+/g, " ").trim();
    const genusOnly = cleanLatin.split(" ")[0] || "";
    const candidates = [q, cleanLatin, en, genusOnly].filter(Boolean);

    const result = await resolveFlowerMedia(candidates);
    setCache(cacheKey, result);
    res.json(result);
  });

  app.get("/api/image-proxy", async (req, res) => {
    const target = String(req.query.url || "");
    if (!target.startsWith("https://upload.wikimedia.org/")) {
      res.status(400).send("Invalid image source");
      return;
    }

    try {
      const upstream = await fetch(target, {
        headers: { "User-Agent": WIKI_USER_AGENT },
      });
      if (!upstream.ok) {
        res.status(upstream.status).send("Upstream image error");
        return;
      }
      const contentType = upstream.headers.get("content-type") || "image/jpeg";
      const buffer = Buffer.from(await upstream.arrayBuffer());
      res.setHeader("Content-Type", contentType);
      res.setHeader("Cache-Control", "public, max-age=86400");
      res.send(buffer);
    } catch {
      res.status(502).send("Image proxy failed");
    }
  });

  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
