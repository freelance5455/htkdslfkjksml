import express, { Request, Response } from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = parseInt(process.env.PORT || '3000', 10);

app.use(express.json({ limit: '50mb' }));

// Server-side Google GenAI initialization with required telemetry header
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

// GET /api/health - Diagnostic endpoint
app.get('/api/health', (_req: Request, res: Response) => {
  res.json({
    status: 'ok',
    hasApiKey: Boolean(process.env.GEMINI_API_KEY),
    timestamp: new Date().toISOString(),
  });
});

// GET /api/voices - List available prebuilt voice configurations
app.get('/api/voices', (_req: Request, res: Response) => {
  res.json({
    voices: [
      { id: 'Puck', nameBn: 'পাক (Puck)', nameEn: 'Puck', tone: 'উৎসাহী ও ডায়নামিক (Energetic & Dynamic)', gender: 'Male', bestFor: 'Shorts, Reels, Tech Hype' },
      { id: 'Kore', nameBn: 'কোরে (Kore)', nameEn: 'Kore', tone: 'স্পষ্ট ও প্রফেশনাল (Clear & Articulate)', gender: 'Female', bestFor: 'Documentary, Career Guide' },
      { id: 'Zephyr', nameBn: 'জেফির (Zephyr)', nameEn: 'Zephyr', tone: 'বন্ধুত্বপূর্ণ ও সাবলীল (Warm & Conversational)', gender: 'Female', bestFor: 'Storytelling, Mentorship' },
      { id: 'Fenrir', nameBn: 'ফেনরির (Fenrir)', nameEn: 'Fenrir', tone: 'গম্ভীর ও নির্ভরযোগ্য (Deep & Authoritative)', gender: 'Male', bestFor: 'Market Analysis, Serious Overview' },
      { id: 'Charon', nameBn: 'ক্যারন (Charon)', nameEn: 'Charon', tone: 'শান্ত ও বর্ণনামূলক (Calm & Reflective)', gender: 'Male', bestFor: 'Educational, Long-form' },
    ],
  });
});

// POST /api/tts - Convert text to speech using gemini-3.8-flash-tts
app.post('/api/tts', async (req: Request, res: Response) => {
  try {
    const { text, voiceName = 'Puck', style = 'Inspiring Bengali presenter, engaging pacing', speaker = 'Narrator' } = req.body;

    if (!text || typeof text !== 'string' || text.trim() === '') {
      res.status(400).json({ error: 'Text prompt is required.' });
      return;
    }

    if (!process.env.GEMINI_API_KEY) {
      res.status(500).json({
        error: 'GEMINI_API_KEY is not configured in the server environment.',
      });
      return;
    }

    // Call Gemini 3.8 Flash TTS
    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash-tts',
      contents: [
        {
          role: 'user',
          parts: [
            {
              text: text.trim(),
              speechMetadata: {
                speaker,
                style,
              },
            },
          ],
        },
      ],
      config: {
        responseModalities: ['AUDIO'],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName },
          },
        },
      },
    });

    const candidate = response.candidates?.[0];
    const audioPart = candidate?.content?.parts?.find(
      (part: any) => part.inlineData && part.inlineData.data
    );

    if (!audioPart || !audioPart.inlineData?.data) {
      res.status(502).json({
        error: 'Model did not return valid audio data.',
        details: candidate?.finishReason || 'Unknown model response structure',
      });
      return;
    }

    res.json({
      success: true,
      audioBase64: audioPart.inlineData.data,
      mimeType: audioPart.inlineData.mimeType || 'audio/wav',
      voiceName,
      speaker,
    });
  } catch (error: any) {
    console.error('Error generating TTS:', error);
    res.status(500).json({
      error: 'TTS generation failed.',
      message: error.message || 'Unknown Gemini API error',
    });
  }
});

// POST /api/music - Generate background music using lyria-3-clip-preview or lyria-3-pro-preview
app.post('/api/music', async (req: Request, res: Response) => {
  try {
    const { prompt, model = 'lyria-3-clip-preview' } = req.body;

    if (!prompt || typeof prompt !== 'string' || prompt.trim() === '') {
      res.status(400).json({ error: 'Music prompt is required.' });
      return;
    }

    const selectedModel =
      model === 'lyria-3-pro-preview' ? 'lyria-3-pro-preview' : 'lyria-3-clip-preview';

    if (!process.env.GEMINI_API_KEY) {
      res.status(500).json({
        error: 'GEMINI_API_KEY is not configured in the server environment.',
      });
      return;
    }

    const responseStream = await ai.models.generateContentStream({
      model: selectedModel,
      contents: prompt.trim(),
    });

    let audioBase64 = '';
    let lyrics = '';
    let mimeType = 'audio/wav';

    for await (const chunk of responseStream) {
      const parts = chunk.candidates?.[0]?.content?.parts;
      if (!parts) continue;
      for (const part of parts) {
        if (part.inlineData?.data) {
          if (!audioBase64 && part.inlineData.mimeType) {
            mimeType = part.inlineData.mimeType;
          }
          audioBase64 += part.inlineData.data;
        }
        if (part.text && !lyrics) {
          lyrics = part.text;
        }
      }
    }

    if (!audioBase64) {
      res.status(502).json({
        error: 'Music generation returned empty audio data.',
      });
      return;
    }

    res.json({
      success: true,
      audioBase64,
      mimeType,
      lyrics,
      model: selectedModel,
    });
  } catch (error: any) {
    console.error('Error generating Lyria music:', error);
    res.status(500).json({
      error: 'Music generation failed.',
      message: error.message || 'Unknown Lyria error',
    });
  }
});

// Mount Vite or serve static assets
async function startServer() {
  const isProduction = process.env.NODE_ENV === 'production';

  if (!isProduction) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(port, '0.0.0.0', () => {
    console.log(`Server listening on http://0.0.0.0:${port}`);
  });
}

startServer();
