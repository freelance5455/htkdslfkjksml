import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';
import { createServer as createViteServer } from 'vite';
import { INITIAL_PAPERS, INITIAL_POSTS, INITIAL_USERS, SYSTEM_STATS } from './src/data/mockData.js';
import { Paper, Post, User, Comment, Message, Notification } from './src/types/index.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// In-memory data store for server runtime state
let papersStore: Paper[] = [...INITIAL_PAPERS];
let postsStore: Post[] = [...INITIAL_POSTS];
let usersStore: User[] = [...INITIAL_USERS];
let messagesStore: Message[] = [
  {
    id: 'msg_1',
    senderId: 'usr_1',
    receiverId: 'usr_2',
    content: 'Hi Dilani! Did you check the new Combined Maths model paper uploaded for A/L 2025?',
    timestamp: '2024-07-23T14:30:00Z',
    isRead: true
  },
  {
    id: 'msg_2',
    senderId: 'usr_2',
    receiverId: 'usr_1',
    content: 'Yes Sir! Thank you so much for the marking scheme. It helped clarify the calculus part!',
    timestamp: '2024-07-23T14:32:00Z',
    isRead: true
  }
];

// Initialize Gemini Client safely
const getGeminiClient = () => {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return null;
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build'
      }
    }
  });
};

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: '10mb' }));

  // CORS headers
  app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
    res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
    if (req.method === 'OPTIONS') {
      res.sendStatus(200);
      return;
    }
    next();
  });

  // Health check endpoint
  app.get('/api/health', (req, res) => {
    res.json({
      status: 'ok',
      service: 'LankaPaperHub Enterprise Server',
      timestamp: new Date().toISOString()
    });
  });

  // Auth endpoints
  app.post('/api/auth/login', (req, res) => {
    const { email, role } = req.body;
    let user = usersStore.find((u) => u.email === email);
    if (!user) {
      user = usersStore[0]; // fallback
    }
    if (role && user) {
      user = { ...user, role };
    }
    res.json({ success: true, user, token: `jwt-mock-token-${user.id}` });
  });

  app.get('/api/auth/me', (req, res) => {
    res.json({ user: usersStore[0] });
  });

  // Papers CRUD & Search
  app.get('/api/papers', (req, res) => {
    const {
      grade,
      subject,
      medium,
      year,
      province,
      school,
      paperType,
      fileFormat,
      sortBy,
      searchQuery,
      status
    } = req.query;

    let filtered = [...papersStore];

    // Filter by approval status if requested or default to APPROVED for public
    if (status) {
      filtered = filtered.filter((p) => p.status === status);
    } else {
      filtered = filtered.filter((p) => p.status === 'APPROVED');
    }

    if (grade && grade !== 'ALL') {
      filtered = filtered.filter((p) => p.grade === grade);
    }
    if (subject && subject !== 'ALL') {
      filtered = filtered.filter((p) => p.subject.toLowerCase().includes((subject as string).toLowerCase()));
    }
    if (medium && medium !== 'ALL') {
      filtered = filtered.filter((p) => p.medium === medium);
    }
    if (year && year !== 'ALL') {
      filtered = filtered.filter((p) => p.year === parseInt(year as string));
    }
    if (province && province !== 'ALL') {
      filtered = filtered.filter((p) => p.province === province);
    }
    if (school && school !== 'ALL') {
      filtered = filtered.filter((p) => p.school.toLowerCase().includes((school as string).toLowerCase()));
    }
    if (paperType && paperType !== 'ALL') {
      filtered = filtered.filter((p) => p.paperType === paperType);
    }
    if (fileFormat && fileFormat !== 'ALL') {
      filtered = filtered.filter((p) => p.fileFormat === fileFormat);
    }

    if (searchQuery) {
      const q = (searchQuery as string).toLowerCase().trim();
      filtered = filtered.filter(
        (p) =>
          p.title.toLowerCase().includes(q) ||
          p.subject.toLowerCase().includes(q) ||
          p.school.toLowerCase().includes(q) ||
          p.uploaderName.toLowerCase().includes(q) ||
          p.tags.some((t) => t.toLowerCase().includes(q))
      );
    }

    // Sort
    if (sortBy === 'popular') {
      filtered.sort((a, b) => b.viewsCount - a.viewsCount);
    } else if (sortBy === 'downloads') {
      filtered.sort((a, b) => b.downloadCount - a.downloadCount);
    } else if (sortBy === 'trending') {
      filtered.sort((a, b) => b.likesCount - a.likesCount);
    } else {
      // newest
      filtered.sort((a, b) => new Date(b.uploadedDate).getTime() - new Date(a.uploadedDate).getTime());
    }

    res.json({ success: true, count: filtered.length, papers: filtered });
  });

  // Paper Upload (Upload workflow with status PENDING for student, APPROVED for teachers/admins)
  app.post('/api/papers', (req, res) => {
    const paperData = req.body;
    const newPaper: Paper = {
      id: `p_${Date.now()}`,
      title: paperData.title || 'Untitled Exam Paper',
      subject: paperData.subject || 'General',
      grade: paperData.grade || 'G.C.E. A/L',
      medium: paperData.medium || 'English',
      year: parseInt(paperData.year) || 2024,
      province: paperData.province || 'Western',
      school: paperData.school || 'National School',
      paperType: paperData.paperType || 'Past Paper',
      termTest: paperData.termTest || '3rd Term',
      hasAnswers: Boolean(paperData.hasAnswers),
      hasMarkingScheme: Boolean(paperData.hasMarkingScheme),
      fileFormat: paperData.fileFormat || 'PDF',
      fileUrl: paperData.fileUrl || 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf',
      fileSize: paperData.fileSize || '3.5 MB',
      pagesCount: paperData.pagesCount || 10,
      downloadCount: 0,
      viewsCount: 1,
      uploadedDate: new Date().toISOString().split('T')[0],
      uploaderId: paperData.uploaderId || 'usr_1',
      uploaderName: paperData.uploaderName || 'Anonymous',
      uploaderAvatar: paperData.uploaderAvatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150',
      uploaderRole: paperData.uploaderRole || 'STUDENT',
      status: paperData.uploaderRole === 'TEACHER' || paperData.uploaderRole === 'ADMIN' ? 'APPROVED' : 'PENDING',
      tags: paperData.tags || ['SriLankaPaper', 'ExamPrep'],
      description: paperData.description || 'Uploaded examination paper for Sri Lankan curriculum.',
      previewPagesText: [
        `EXAMINATION PAPER - ${paperData.title}\nSubject: ${paperData.subject} (${paperData.medium} Medium)\nGrade: ${paperData.grade} | Year: ${paperData.year}\nSchool: ${paperData.school}\n\n[SECTION A] Multiple Choice Questions (Answer All Questions)\n1. Evaluate the primary principles covered in ${paperData.subject} for the Sri Lankan syllabus.\n2. State two key applications of this model paper for term test preparation.\n\n[SECTION B] Essay & Structured Questions\n3. (a) Derive the fundamental formula or theorem.\n   (b) Explain step-by-step with practical examples.`
      ],
      likesCount: 0
    };

    papersStore.unshift(newPaper);
    res.json({ success: true, paper: newPaper });
  });

  // Increment download counter
  app.post('/api/papers/:id/download', (req, res) => {
    const { id } = req.params;
    const paper = papersStore.find((p) => p.id === id);
    if (paper) {
      paper.downloadCount += 1;
      SYSTEM_STATS.totalDownloads += 1;
      res.json({ success: true, downloadCount: paper.downloadCount, fileUrl: paper.fileUrl });
    } else {
      res.status(404).json({ success: false, message: 'Paper not found' });
    }
  });

  // Like paper
  app.post('/api/papers/:id/like', (req, res) => {
    const { id } = req.params;
    const paper = papersStore.find((p) => p.id === id);
    if (paper) {
      paper.likesCount += 1;
      res.json({ success: true, likesCount: paper.likesCount });
    } else {
      res.status(404).json({ success: false, message: 'Paper not found' });
    }
  });

  // Community Posts
  app.get('/api/posts', (req, res) => {
    res.json({ success: true, posts: postsStore });
  });

  app.post('/api/posts', (req, res) => {
    const { authorId, authorName, authorAvatar, authorRole, content, poll } = req.body;
    const newPost: Post = {
      id: `post_${Date.now()}`,
      authorId: authorId || 'usr_1',
      authorName: authorName || 'Kasun Perera',
      authorAvatar: authorAvatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150',
      authorRole: authorRole || 'TEACHER',
      content,
      createdAt: new Date().toISOString(),
      likesCount: 0,
      likedUserIds: [],
      commentsCount: 0,
      hashtags: content.match(/#[a-zA-Z0-9_]+/g) || [],
      poll: poll || undefined
    };
    postsStore.unshift(newPost);
    res.json({ success: true, post: newPost });
  });

  app.post('/api/posts/:id/like', (req, res) => {
    const { id } = req.params;
    const { userId } = req.body;
    const post = postsStore.find((p) => p.id === id);
    if (post) {
      const idx = post.likedUserIds.indexOf(userId);
      if (idx > -1) {
        post.likedUserIds.splice(idx, 1);
        post.likesCount = Math.max(0, post.likesCount - 1);
      } else {
        post.likedUserIds.push(userId);
        post.likesCount += 1;
      }
      res.json({ success: true, likesCount: post.likesCount, likedUserIds: post.likedUserIds });
    } else {
      res.status(404).json({ success: false, message: 'Post not found' });
    }
  });

  app.post('/api/posts/:id/vote', (req, res) => {
    const { id } = req.params;
    const { optionId, userId } = req.body;
    const post = postsStore.find((p) => p.id === id);
    if (post && post.poll) {
      post.poll.options.forEach((opt) => {
        if (opt.id === optionId) {
          if (!opt.votedUserIds.includes(userId)) {
            opt.votes += 1;
            opt.votedUserIds.push(userId);
          }
        }
      });
      res.json({ success: true, poll: post.poll });
    } else {
      res.status(400).json({ success: false, message: 'Poll not found' });
    }
  });

  // Messages
  app.get('/api/messages', (req, res) => {
    res.json({ success: true, messages: messagesStore });
  });

  app.post('/api/messages', (req, res) => {
    const { senderId, receiverId, content } = req.body;
    const newMsg: Message = {
      id: `msg_${Date.now()}`,
      senderId,
      receiverId,
      content,
      timestamp: new Date().toISOString(),
      isRead: false
    };
    messagesStore.push(newMsg);
    res.json({ success: true, message: newMsg });
  });

  // Admin Panel endpoints
  app.get('/api/admin/stats', (req, res) => {
    const pendingCount = papersStore.filter((p) => p.status === 'PENDING').length;
    res.json({
      success: true,
      stats: {
        ...SYSTEM_STATS,
        totalPapers: papersStore.length,
        pendingApprovals: pendingCount
      }
    });
  });

  app.post('/api/admin/papers/:id/status', (req, res) => {
    const { id } = req.params;
    const { status } = req.body;
    const paper = papersStore.find((p) => p.id === id);
    if (paper) {
      paper.status = status;
      res.json({ success: true, paper });
    } else {
      res.status(404).json({ success: false, message: 'Paper not found' });
    }
  });

  // AI Endpoints using Gemini SDK
  app.post('/api/ai/smart-search', async (req, res) => {
    const { query } = req.body;
    const ai = getGeminiClient();

    if (!ai || !query) {
      // Fallback mock smart filter parse
      res.json({
        success: true,
        extractedFilters: {
          subject: query.toLowerCase().includes('math') ? 'Combined Mathematics' : 'All',
          grade: query.toLowerCase().includes('o/l') ? 'G.C.E. O/L' : 'G.C.E. A/L',
          year: query.match(/\b(20[0-2][0-9])\b/)?.[0] || 'ALL',
          keywords: query
        }
      });
      return;
    }

    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3.6-flash',
        contents: `You are an AI search assistant for Sri Lankan education platform LankaPaperHub. Parse the following search query into JSON matching Sri Lankan syllabus structure: "${query}". Return JSON with keys: "subject", "grade" (Grade 6..9, G.C.E. O/L, G.C.E. A/L), "year", "medium" (Sinhala, English, Tamil), "province", "paperType" (Past Paper, Term Test, Model Paper), "suggestedTags" (array of 3 tags).`,
        config: { responseMimeType: 'application/json' }
      });

      const parsed = JSON.parse(response.text || '{}');
      res.json({ success: true, extractedFilters: parsed });
    } catch (err) {
      console.error('Gemini smart search error:', err);
      res.json({
        success: true,
        extractedFilters: {
          subject: 'All',
          grade: 'G.C.E. A/L',
          keywords: query
        }
      });
    }
  });

  app.post('/api/ai/study-assistant', async (req, res) => {
    const { subject, grade, prompt, topic } = req.body;
    const ai = getGeminiClient();

    if (!ai) {
      res.json({
        success: true,
        advice: `📌 Study Guide for ${subject} (${grade}):\n1. Focus heavily on core past paper questions from 2018–2024.\n2. Review official marking schemes to understand step-by-step point allocation.\n3. Practice timed paper sessions to manage exam pressure effectively.`,
        quizQuestions: [
          {
            question: `What is the key principle tested in ${subject} for ${grade}?`,
            options: ['Fundamental definition & theorem', 'Practical application', 'Analytical proof', 'All of the above'],
            answerIndex: 3
          }
        ]
      });
      return;
    }

    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3.6-flash',
        contents: `You are LankaPaperHub AI Study Assistant for Sri Lankan school students (${grade} - ${subject}).
User question/topic: "${prompt || topic || 'How to prepare for exam?'}".
Provide a clear, structured response with 3 study tips, key paper breakdown concepts, and 2 sample practice questions with answers suitable for Sri Lankan Department of Examinations standards. Keep formatting clean with bullet points.`,
        config: {
          systemInstruction: 'You are an expert Sri Lankan national curriculum exam tutor fluent in English and Sinhala educational terms.'
        }
      });

      res.json({ success: true, advice: response.text });
    } catch (err) {
      console.error('Gemini study assistant error:', err);
      res.status(500).json({ success: false, message: 'AI Assistant temporarily unavailable.' });
    }
  });

  app.post('/api/ai/auto-tags', async (req, res) => {
    const { title, description } = req.body;
    const ai = getGeminiClient();

    if (!ai) {
      res.json({ success: true, tags: ['SriLankaExams', 'ModelPaper', 'ExamPrep'] });
      return;
    }

    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3.6-flash',
        contents: `Generate 5 relevant hashtags or tags (without spaces) for an educational paper titled "${title}" with description "${description}". Return JSON array of strings under key "tags".`,
        config: { responseMimeType: 'application/json' }
      });
      const parsed = JSON.parse(response.text || '{"tags":[]}');
      res.json({ success: true, tags: parsed.tags || [] });
    } catch (err) {
      res.json({ success: true, tags: ['ExamPrep', 'SriLankaEducation', 'PastPaper'] });
    }
  });

  // Vite middleware setup
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*all', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`LankaPaperHub server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
