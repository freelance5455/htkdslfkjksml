import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Priority list of models with independent quotas and high availability.
// gemini-3.1-flash-lite is the designated primary fast model.
// gemini-3.5-flash and gemini-3-flash-preview provide rock-solid fallbacks
// without sharing the exhausted gemini-3.8-flash free tier quota pool.
const ACTIVE_MODELS = [
  'gemini-3.1-flash-lite',
  'gemini-3.5-flash',
  'gemini-3-flash-preview',
  'gemini-3.1-flash-lite-preview',
  'gemini-flash-lite-latest',
];

async function startServer() {
  const app = express();
  const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

  app.use(express.json({ limit: '15mb' }));

  // CORS and options headers
  app.use((_req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization, Accept');
    next();
  });

  // Initialize Gemini client on server with mandatory User-Agent
  const apiKey = process.env.GEMINI_API_KEY;
  const ai = new GoogleGenAI({
    apiKey: apiKey || '',
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });

  const SYSTEM_INSTRUCTION = `أنت "Mostafa AI" (مصطفى للذكاء الاصطناعي)، نموذج ذكاء اصطناعي عربي متطور وفائق الذكاء ومصمم لمساعدة المستخدمين في كل شيء.
صفاتك ومبادئك:
1. تتحدث باللغة العربية الفصحى الأنيقة أو اللهجة التي يفضلها المستخدم بكل سلاسة ودقة.
2. أسلوبك ودود، متعاون، وذكي، وتقدم إجابات متكاملة وشاملة وواضحة.
3. تساعد باحترافية في:
   - البرمجة وتطوير المواقع والتطبيقات وحل المشكلات التقنية وتنسيق الأكواد.
   - الكتابة الإبداعية وصياغة الرسائل والمقالات والترجمة.
   - الشرح العلمي والتعليمي وتبسيط المفاهيم المعقدة.
   - التحليل والتخطيط وحل المسائل الرياضية والمنطقية.
4. نسّق ردودك دائماً باستخدام Markdown الجميل: استخدم العناوين (H2, H3)، والنقاط (bullet points)، وجداول البيانات، والأكواد المظللة بلغة البرمجة المناسبة (مثال: \`\`\`javascript).
5. إذا سألك المستخدم عن هويتك أو من صنعك، أخبره بفخر أنك "Mostafa AI"، المساعد الذكي العربي المخصص لخدمته والمبني على أقوى تقنيات الذكاء الاصطناعي من Google (Gemini).`;

  /**
   * Cleans and formats conversation turns for the Gemini SDK.
   * Ensures:
   * - Errors or empty placeholder messages are filtered out.
   * - Strict alternating sequence of 'user' and 'model' turns.
   * - The conversation ends with a 'user' turn.
   * - Valid parts structure (text or inlineData).
   */
  function formatContents(body: any): Array<{ role: 'user' | 'model'; parts: Array<any> }> {
    const { messages, message, image } = body;
    const rawItems: Array<{ role: 'user' | 'model'; parts: Array<any> }> = [];

    if (Array.isArray(messages) && messages.length > 0) {
      for (const msg of messages) {
        // Skip empty or error indicator messages
        const textContent = (msg.content || '').trim();
        const isErrorMsg = textContent.startsWith('⚠️') || textContent.includes('واجه Mostafa AI مشكلة');
        if (isErrorMsg) continue;

        const role: 'user' | 'model' =
          msg.role === 'assistant' || msg.role === 'model' ? 'model' : 'user';

        const parts: Array<any> = [];

        // Attach image part if present
        if (msg.image && msg.image.data && msg.image.mimeType) {
          parts.push({
            inlineData: {
              data: msg.image.data,
              mimeType: msg.image.mimeType,
            },
          });
        }

        // Attach text part if present or if there is no image
        if (textContent || parts.length === 0) {
          parts.push({ text: textContent || 'مرحبا' });
        }

        rawItems.push({ role, parts });
      }
    } else if (message || image) {
      const parts: Array<any> = [];
      if (image && image.data && image.mimeType) {
        parts.push({
          inlineData: {
            data: image.data,
            mimeType: image.mimeType,
          },
        });
      }
      const textContent = (message || '').trim();
      if (textContent || parts.length === 0) {
        parts.push({ text: textContent || 'انظر إلى هذه الصورة وأخبرني عنها' });
      }
      rawItems.push({ role: 'user', parts });
    }

    if (rawItems.length === 0) {
      return [{ role: 'user', parts: [{ text: 'مرحبا' }] }];
    }

    // Merge consecutive turns with identical role to enforce strictly alternating turns
    const consolidated: Array<{ role: 'user' | 'model'; parts: Array<any> }> = [];
    for (const item of rawItems) {
      if (consolidated.length === 0) {
        consolidated.push(item);
      } else {
        const last = consolidated[consolidated.length - 1];
        if (last.role === item.role) {
          // Merge parts into previous turn
          last.parts.push(...item.parts);
        } else {
          consolidated.push(item);
        }
      }
    }

    // Gemini requires the conversation to end with a 'user' turn
    if (consolidated.length > 0 && consolidated[consolidated.length - 1].role === 'model') {
      consolidated.pop();
    }

    // Ensure at least one user turn remains
    if (consolidated.length === 0) {
      consolidated.push({ role: 'user', parts: [{ text: 'مرحبا' }] });
    }

    return consolidated;
  }

  // Resilient generator with model fallback and automatic backoff retry for transient 503s
  async function generateContentWithFallback(contents: any) {
    let lastError: any = null;

    for (const model of ACTIVE_MODELS) {
      // Try up to 2 attempts per model (retry once with backoff if 503 high demand)
      for (let attempt = 1; attempt <= 2; attempt++) {
        try {
          const response = await ai.models.generateContent({
            model,
            contents,
            config: {
              systemInstruction: SYSTEM_INSTRUCTION,
              temperature: 0.7,
            },
          });

          return { response, usedModel: model };
        } catch (err: any) {
          lastError = err;
          const status = err?.status || (err?.message?.includes('503') ? 503 : null);
          const isRateLimit = status === 429 || err?.message?.includes('429') || err?.message?.includes('Quota exceeded');
          const isHighDemand = status === 503 || err?.message?.includes('503') || err?.message?.includes('high demand') || err?.message?.includes('UNAVAILABLE');

          console.warn(`[Mostafa AI] Model ${model} (attempt ${attempt}) failed:`, err?.status || err?.message?.slice(0, 90));

          // If it's a 429 quota exhaustion, immediately abandon this model and try next model
          if (isRateLimit) {
            break;
          }

          // If it's a transient 503 high demand, back off briefly and retry once
          if (isHighDemand && attempt === 1) {
            await new Promise((resolve) => setTimeout(resolve, 800));
            continue;
          }

          // Otherwise move to next model
          break;
        }
      }
    }

    throw lastError;
  }

  // Status check endpoint
  app.get('/api/status', (_req, res) => {
    res.json({
      status: 'ok',
      hasApiKey: Boolean(process.env.GEMINI_API_KEY),
      model: ACTIVE_MODELS[0],
      appName: 'Mostafa AI',
      arabicSupport: true,
    });
  });

  // Standard chat endpoint - Always returns HTTP 200 with { reply, usedModel } or { error }
  app.post('/api/chat', async (req, res) => {
    try {
      if (!process.env.GEMINI_API_KEY) {
        return res.status(200).json({
          error: 'مفتاح Gemini API غير معرف في بيئة الخادم. يرجى ضبط GEMINI_API_KEY في لوحة الإعدادات أو ملف .env.',
        });
      }

      const contents = formatContents(req.body);
      if (!contents || contents.length === 0) {
        return res.status(200).json({ error: 'الرجاء إدخال رسالة صالحة.' });
      }

      const { response, usedModel } = await generateContentWithFallback(contents);
      const replyText = response?.text || 'عذراً، لم أتمكن من تكوين إجابة في الوقت الحالي.';
      return res.status(200).json({ reply: replyText, usedModel });
    } catch (err: any) {
      console.error('Gemini API Error in /api/chat:', err);

      let errorMsg = 'خوادم الذكاء الاصطناعي تشهد ضغطاً مؤقتاً في هذه اللحظة. يرجى إعادة المحاولة بعد ثوانٍ قليلة.';
      const msg = err?.message || '';

      if (msg.includes('Quota exceeded') || msg.includes('429')) {
        errorMsg = 'تم الوصول إلى الحد الأقصى المؤقت للاستخدام المجاني للنموذج. جاري التبديل التلقائي أو يرجى المحاولة بعد قليل.';
      } else if (msg.includes('API key not valid') || msg.includes('API_KEY_INVALID')) {
        errorMsg = 'مفتاح Gemini API غير صالح، يرجى التحقق من صحة المفتاح في لوحة الإعدادات.';
      }

      return res.status(200).json({ error: errorMsg });
    }
  });

  // Setup Vite middlewares for dev or static files for production
  const isProduction = process.env.NODE_ENV === 'production';
  if (!isProduction) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Mostafa AI Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
});
