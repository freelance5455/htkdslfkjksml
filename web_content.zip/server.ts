import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';
import { createChatRouter } from './server/chatRouter.js';

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

function sanitizeSupabaseUrl(raw?: string | null): string {
  if (!raw || typeof raw !== 'string') return 'https://eisfsaetlncsykwehywb.supabase.co';
  let url = raw.trim();
  if (url.includes('=')) {
    const parts = url.split('=');
    url = parts[parts.length - 1].trim();
  }
  url = url.replace(/^['"]+|['"]+$/g, '').trim();
  if (!url.startsWith('http://') && !url.startsWith('https://')) {
    return 'https://eisfsaetlncsykwehywb.supabase.co';
  }
  return url.replace(/\/+$/, '');
}

function sanitizeSupabaseKey(raw?: string | null): string {
  if (!raw || typeof raw !== 'string') return 'sb_publishable_gIaSSEW-XNqKOyaLdmkU7g_UYmPQYDZ';
  let key = raw.trim();
  if (key.includes('=')) {
    const parts = key.split('=');
    key = parts[parts.length - 1].trim();
  }
  key = key.replace(/^['"]+|['"]+$/g, '').trim();
  return key || 'sb_publishable_gIaSSEW-XNqKOyaLdmkU7g_UYmPQYDZ';
}

// Resolve Supabase credentials safely on the server
const rawSupabaseUrl = sanitizeSupabaseUrl(
  process.env.VITE_SUPABASE_URL ||
  process.env.NEXT_PUBLIC_SUPABASE_URL
);

const rawPublishableKey = sanitizeSupabaseKey(
  process.env.VITE_SUPABASE_PUBLISHABLE_KEY ||
  process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY
);

const rawServiceRoleKey = (
  process.env.SUPABASE_SERVICE_ROLE_KEY ||
  process.env.SUPABASE_SECRET_KEY ||
  process.env.SERVICE_ROLE_KEY ||
  ''
).trim().replace(/^['"]+|['"]+$/g, '');

// Standard client with publishable key
const supabaseClient = createClient(rawSupabaseUrl, rawPublishableKey, {
  auth: {
    autoRefreshToken: false,
    persistSession: false,
  },
});

// Privileged admin client with service role key (if available)
const supabaseAdmin = rawServiceRoleKey
  ? createClient(rawSupabaseUrl, rawServiceRoleKey, {
      auth: {
        autoRefreshToken: false,
        persistSession: false,
      },
    })
  : null;

function normalizeUsername(raw: string): string {
  return raw.trim().toLowerCase().replace(/^@+/, '').replace(/[^a-z0-9_.]/g, '');
}

function usernameToInternalEmail(cleanUsername: string): string {
  return `${cleanUsername}@nexa.net`;
}

// -------------------------------------------------------------
// API Routes (mounted BEFORE Vite middleware)
// -------------------------------------------------------------

const chatRouter = createChatRouter(supabaseClient, supabaseAdmin);
app.use('/api/chat', chatRouter);
app.use('/api', chatRouter);

app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    hasServiceRoleKey: !!supabaseAdmin,
    serverTime: new Date().toISOString(),
  });
});

/**
 * Check if a username is already taken in the profiles table
 */
app.get('/api/auth/check-username', async (req, res) => {
  try {
    const usernameParam = req.query.username as string;
    if (!usernameParam) {
      return res.status(400).json({ error: 'Username is required' });
    }

    const cleanUsername = normalizeUsername(usernameParam);
    const client = supabaseAdmin || supabaseClient;

    const { data: existing, error } = await client
      .from('profiles')
      .select('id')
      .ilike('username', cleanUsername)
      .limit(1);

    if (error) {
      return res.status(500).json({ error: error.message });
    }

    res.json({
      username: cleanUsername,
      available: !existing || existing.length === 0,
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Internal server error' });
  }
});

/**
 * Privileged Nexa Account Creation
 * Creates internal Supabase Auth identity with email_confirm: true (no confirmation email sent!)
 * Inserts public.profiles record
 */
app.post('/api/auth/register', async (req, res) => {
  try {
    const { username, displayName, password } = req.body;

    if (!username || typeof username !== 'string') {
      return res.status(400).json({ error: 'Username is required.' });
    }
    if (!displayName || typeof displayName !== 'string' || !displayName.trim()) {
      return res.status(400).json({ error: 'Display name is required.' });
    }
    if (!password || typeof password !== 'string' || password.length < 6) {
      return res.status(400).json({ error: 'Password must be at least 6 characters.' });
    }

    const cleanUsername = normalizeUsername(username);
    if (cleanUsername.length < 3 || cleanUsername.length > 24 || !/^[a-z0-9_.]+$/.test(cleanUsername)) {
      return res.status(400).json({
        error: 'Username must be 3-24 characters and only contain letters, numbers, underscores or periods.',
      });
    }

    const internalEmail = usernameToInternalEmail(cleanUsername);
    const activeClient = supabaseAdmin || supabaseClient;

    // 1. Check if username is taken in profiles table
    const { data: existingProfile } = await activeClient
      .from('profiles')
      .select('id')
      .ilike('username', cleanUsername)
      .limit(1);

    if (existingProfile && existingProfile.length > 0) {
      return res.status(409).json({
        error: `Username @${cleanUsername} is already taken. Please choose another.`,
      });
    }

    // 2. Strategy A: Use Supabase Admin createUser with email_confirm: true
    if (supabaseAdmin) {
      const { data: adminData, error: adminError } = await supabaseAdmin.auth.admin.createUser({
        email: internalEmail,
        password,
        email_confirm: true,
        user_metadata: {
          username: cleanUsername,
          display_name: displayName.trim(),
        },
      });

      if (adminError) {
        if (adminError.message.includes('already registered')) {
          return res.status(409).json({
            error: `Username @${cleanUsername} is already registered. Please sign in.`,
          });
        }
        return res.status(400).json({ error: adminError.message });
      }

      if (adminData.user) {
        // Upsert into profiles
        await supabaseAdmin.from('profiles').upsert(
          {
            id: adminData.user.id,
            username: cleanUsername,
            display_name: displayName.trim(),
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString(),
          },
          { onConflict: 'id' }
        );

        return res.json({
          success: true,
          userId: adminData.user.id,
          username: cleanUsername,
          displayName: displayName.trim(),
          method: 'admin_createUser',
        });
      }
    }

    // 3. Strategy B: Call register_nexa_user RPC if present in Postgres
    try {
      const { data: rpcData, error: rpcError } = await supabaseClient.rpc('register_nexa_user', {
        p_username: cleanUsername,
        p_display_name: displayName.trim(),
        p_password: password,
      });

      if (!rpcError && rpcData) {
        if (rpcData.success) {
          return res.json({
            success: true,
            userId: rpcData.user_id,
            username: cleanUsername,
            displayName: displayName.trim(),
            method: 'rpc_register_nexa_user',
          });
        } else if (rpcData.error) {
          return res.status(400).json({ error: rpcData.error });
        }
      }
    } catch {
      // RPC not yet installed in Supabase instance
    }

    // 4. Strategy C: Standard signUp fallback
    const { data: signUpData, error: signUpError } = await supabaseClient.auth.signUp({
      email: internalEmail,
      password,
      options: {
        data: {
          username: cleanUsername,
          display_name: displayName.trim(),
        },
      },
    });

    if (signUpError) {
      if (signUpError.message.includes('already registered')) {
        return res.status(409).json({
          error: `Username @${cleanUsername} is already registered. Please sign in.`,
        });
      }
      if (signUpError.message.includes('rate limit')) {
        return res.status(429).json({
          error:
            'Supabase email confirmation rate limit reached. To enable instant registration without emails, provide SUPABASE_SERVICE_ROLE_KEY in AI Studio Settings or disable "Confirm email" under Supabase Authentication > Providers > Email.',
        });
      }
      return res.status(400).json({ error: signUpError.message });
    }

    if (signUpData.user) {
      try {
        await activeClient.from('profiles').upsert(
          {
            id: signUpData.user.id,
            username: cleanUsername,
            display_name: displayName.trim(),
          },
          { onConflict: 'id' }
        );
      } catch {}

      return res.json({
        success: true,
        userId: signUpData.user.id,
        username: cleanUsername,
        displayName: displayName.trim(),
        method: 'standard_signUp',
      });
    }

    return res.status(500).json({ error: 'Failed to create account.' });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Server error during registration.' });
  }
});

// -------------------------------------------------------------
// Vite Middleware / Static Serving
// -------------------------------------------------------------

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Nexa server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
