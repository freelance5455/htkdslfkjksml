import 'dotenv/config';
import express, { type Request, type Response } from 'express';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
import { GoogleGenAI } from '@google/genai';
import JSZip from 'jszip';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;

app.use(express.json({ limit: '1mb' }));

interface ChatTurn {
  role: 'user' | 'model';
  text: string;
}

const SYSTEM_INSTRUCTION = `You are "Ustad Farid", the senior Master Plumbing Mentor inside the Farid Plumber Pro app.
You have 25+ years of hands-on experience in residential, commercial, and industrial plumbing across India and UAE/Dubai (DEWA & Dubai Municipality standards).

Rules for answering:
1. Language matching:
   - If the user asks in Hindi or Hinglish, reply clearly in simple Hinglish / Hindi (mix Devanagari or easy Roman Hindi as helpful) with technical English terms in brackets so beginners understand easily.
   - If the user asks in English, reply in clear, practical English — and if helpful, add a short Hindi summary line when the user's preferred language mode is bilingual.
   - If the user asks about Dubai/UAE Arabic terms, include the Arabic word, pronunciation, and Hindi/English meaning.
2. Be practical, accurate, and field-ready:
   - Give exact numbers whenever relevant (e.g., PPR fusion temperature 260°C, pipe sizes 15mm–110mm, slopes 1:40 / 1:50 / 1:100, hydrostatic pressure test 10 Bar / 150 PSI, standard rough-in heights like WC 300mm or shower mixer 1050mm).
   - Format answers cleanly using short numbered steps or concise bullet points.
   - Always include a brief Safety Tip if the task involves hot welding, solvent cement, pressure testing, drain chemicals, or overhead work.
3. Never invent fake standards. Stick strictly to real-world plumbing engineering and practical site methods.`;

app.get('/api/health', (_req: Request, res: Response) => {
  res.json({ ok: true, app: 'Farid Plumber Pro' });
});

function addDirectoryToZip(zipFolder: JSZip, fsDir: string) {
  if (!fs.existsSync(fsDir)) return;
  const entries = fs.readdirSync(fsDir, { withFileTypes: true });
  for (const entry of entries) {
    if (
      entry.name === 'node_modules' ||
      entry.name === '.git' ||
      entry.name === 'dev-dist' ||
      entry.name === '.env'
    ) {
      continue;
    }
    const fullPath = path.join(fsDir, entry.name);
    if (entry.isDirectory()) {
      const subFolder = zipFolder.folder(entry.name);
      if (subFolder) {
        addDirectoryToZip(subFolder, fullPath);
      }
    } else if (entry.isFile()) {
      zipFolder.file(entry.name, fs.readFileSync(fullPath));
    }
  }
}

app.get('/api/download-zip', async (req: Request, res: Response) => {
  try {
    const mode = req.query.type === 'web' ? 'web' : 'source';
    const zip = new JSZip();

    if (mode === 'web') {
      const distDir = path.resolve(__dirname, 'dist');
      if (!fs.existsSync(distDir)) {
        res.status(404).json({
          error: 'Web build folder (dist) not found. Please download the Source ZIP instead.',
        });
        return;
      }
      addDirectoryToZip(zip, distDir);
      zip.file(
        'README-HOSTING.txt',
        `Farid Plumber Pro — Ready-to-Host Web Bundle\n\n` +
          `How to use:\n` +
          `1. Extract this ZIP file.\n` +
          `2. Upload all extracted files to any static web host (Netlify Drop, Vercel, Cloudflare Pages, GitHub Pages, or cPanel public_html).\n` +
          `3. Note: The AI Plumber Assistant (/api/plumbing-assistant) requires running the full Node.js server from the Source ZIP with GEMINI_API_KEY set.\n`
      );
    } else {
      const rootFiles = [
        'package.json',
        'tsconfig.json',
        'vite.config.ts',
        'index.html',
        'server.ts',
        'metadata.json',
        '.env.example',
      ];
      for (const fileName of rootFiles) {
        const filePath = path.join(__dirname, fileName);
        if (fs.existsSync(filePath)) {
          zip.file(fileName, fs.readFileSync(filePath));
        }
      }

      const srcFolder = zip.folder('src');
      if (srcFolder) addDirectoryToZip(srcFolder, path.join(__dirname, 'src'));

      const publicFolder = zip.folder('public');
      if (publicFolder) addDirectoryToZip(publicFolder, path.join(__dirname, 'public'));

      zip.file(
        'README-SETUP.txt',
        `Farid Plumber Pro — Complete App Source Code\n\n` +
          `How to run locally:\n` +
          `1. Install Node.js 22+.\n` +
          `2. Extract this ZIP file and open a terminal inside the folder.\n` +
          `3. Run: npm install\n` +
          `4. (Optional for AI Assistant) Copy .env.example to .env and add your GEMINI_API_KEY.\n` +
          `5. Start dev server: npm run dev\n` +
          `   Or build for production: npm run build && npm start\n` +
          `6. Open http://localhost:3000 in Google Chrome.\n`
      );
    }

    const zipBuffer = await zip.generateAsync({
      type: 'nodebuffer',
      compression: 'DEFLATE',
      compressionOptions: { level: 6 },
    });

    const filename =
      mode === 'web' ? 'farid-plumber-pro-web-bundle.zip' : 'farid-plumber-pro-source.zip';
    res.setHeader('Content-Type', 'application/zip');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.setHeader('Content-Length', String(zipBuffer.length));
    res.setHeader('Cache-Control', 'no-store');
    res.send(zipBuffer);
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Failed to create ZIP file';
    console.error('ZIP export error:', message);
    res.status(500).json({ error: `Unable to generate ZIP file: ${message}` });
  }
});

app.post('/api/plumbing-assistant', async (req: Request, res: Response) => {
  try {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
      res.status(503).json({
        error: 'Gemini API key is not configured. Add GEMINI_API_KEY in Settings > Secrets to enable the AI Plumber Assistant.',
      });
      return;
    }

    const body = req.body as {
      question?: string;
      language?: 'en' | 'hi' | 'both';
      history?: ChatTurn[];
    };

    const question = (body.question ?? '').trim();
    if (!question) {
      res.status(400).json({ error: 'Please enter a plumbing question.' });
      return;
    }

    const langHint =
      body.language === 'hi'
        ? 'Preferred response language: Simple Hindi (Devanagari + easy English technical words like PPR, Elbow, 10 Bar).'
        : body.language === 'both'
          ? 'Preferred response language: Bilingual (Simple English explanation followed by clear Hindi explanation).'
          : 'Preferred response language: Simple, practical English.';

    const ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });

    const historyTurns = Array.isArray(body.history) ? body.history.slice(-8) : [];
    const contents = [
      ...historyTurns.map((turn) => ({
        role: turn.role,
        parts: [{ text: turn.text }],
      })),
      {
        role: 'user' as const,
        parts: [{ text: `${langHint}\n\nPlumber's Question: ${question}` }],
      },
    ];

    const response = await ai.models.generateContent({
      model: 'gemini-4-hydrogen',
      contents,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
      },
    });

    const answer = response.text?.trim();
    if (!answer) {
      res.status(502).json({ error: 'AI Assistant returned an empty response. Please try again.' });
      return;
    }

    res.json({ answer });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Unexpected server error';
    console.error('Plumbing assistant error:', message);
    res.status(500).json({
      error: `Unable to get answer right now: ${message}`,
    });
  }
});

async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';

  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(__dirname, 'dist');
    app.use(
      express.static(distDir, {
        setHeaders: (res, filePath) => {
          if (filePath.endsWith('.webmanifest')) {
            res.setHeader('Content-Type', 'application/manifest+json');
          } else if (filePath.endsWith('sw.js')) {
            res.setHeader('Content-Type', 'application/javascript');
            res.setHeader('Cache-Control', 'no-cache');
          }
        },
      })
    );
    app.get('*', (_req: Request, res: Response) => {
      const indexPath = path.join(distDir, 'index.html');
      if (fs.existsSync(indexPath)) {
        res.sendFile(indexPath);
      } else {
        res.status(404).send('Build output not found. Run npm run build first.');
      }
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Farid Plumber Pro server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
