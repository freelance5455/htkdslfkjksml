import express, { Request, Response } from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT) : 3000;

app.use(express.json({ limit: '10mb' }));

// Initialize GoogleGenAI client if API key is present
const apiKey = process.env.GEMINI_API_KEY;
let aiClient: GoogleGenAI | null = null;

if (apiKey) {
  aiClient = new GoogleGenAI({
    apiKey: apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// Status endpoint
app.get('/api/status', (_req: Request, res: Response) => {
  res.json({
    status: 'online',
    version: 'GPT-6 v6.4 Quantum Neural',
    hasApiKey: Boolean(apiKey),
    model: 'gemini-3.8-flash',
    defaultLanguage: 'fr',
  });
});

// Chat endpoint with SSE streaming
app.post('/api/chat', async (req: Request, res: Response) => {
  const { messages, mode = 'standard', language = 'fr' } = req.body;

  if (!Array.isArray(messages) || messages.length === 0) {
    return res.status(400).json({ error: 'Messages array is required' });
  }

  // Set SSE headers
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.flushHeaders?.();

  const sendEvent = (event: string, data: any) => {
    res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`);
  };

  const userMessages = messages.filter((m: any) => m && m.content);
  const lastUserMsg = userMessages[userMessages.length - 1]?.content || '';

  // Mode instruction customization
  let modeInstruction = '';
  switch (mode) {
    case 'reasoning':
      modeInstruction = 'MODE RAISONNEMENT QUANTIQUE AVANCÉ : Décompose ta pensée avec clarté, étape par étape, en explorant les hypothèses, les nuances et les conclusions logiques.';
      break;
    case 'code':
      modeInstruction = 'MODE ARCHITECTE LOGICIEL & CODEUR EXPERT : Produis du code propre, moderne, sécurisé et bien commenté. Explique les choix d\'architecture et les meilleures pratiques.';
      break;
    case 'creative':
      modeInstruction = 'MODE STUDIO CRÉATIF : Fais preuve d\'éloquence, d\'audace narrative, d\'originalité stylistique et de finesse d\'esprit.';
      break;
    case 'fast':
      modeInstruction = 'MODE ULTRA-RAPIDE : Sois concis, direct et efficace, en allant droit au but tout en conservant une précision irréprochable.';
      break;
    default:
      modeInstruction = 'MODE STANDARD POLYVALENT : Sois intelligent, précis, chaleureux et exhaustif.';
  }

  const systemInstruction = `Tu es GPT-6, la plus récente et puissante évolution de l'intelligence artificielle conversationnelle.
Tu communiques avec excellence en français (ou dans la langue utilisée par l'utilisateur).
Tu es chaleureux, perspicace, pédagogue et doté d'une vaste culture scientifique, technique, littéraire et philosophique.
Formate toujours tes réponses avec un Markdown riche et soigné : titres clairs (#, ##), listes, gras pour les notions clés, et blocs de code avec spécification du langage si nécessaire.
${modeInstruction}
Sois toujours bienveillant, constructif et d'une aide inestimable pour l'utilisateur.`;

  if (aiClient) {
    try {
      // Map message history to Gemini API format
      const formattedContents = userMessages.map((msg: any) => ({
        role: msg.role === 'assistant' ? 'model' : 'user',
        parts: [{ text: msg.content }],
      }));

      sendEvent('start', { model: 'GPT-6 (Gemini 3.8 Flash Neural Engine)' });

      const streamResponse = await aiClient.models.generateContentStream({
        model: 'gemini-3.8-flash',
        contents: formattedContents,
        config: {
          systemInstruction: systemInstruction,
        },
      });

      for await (const chunk of streamResponse) {
        if (chunk.text) {
          sendEvent('chunk', { text: chunk.text });
        }
      }

      sendEvent('done', { completed: true });
      return res.end();
    } catch (err: any) {
      console.error('Error with Gemini API streaming:', err);
      sendEvent('warning', {
        message: 'Bascule automatique sur le module neural local de GPT-6...',
      });
      // Fallback to local response generator below
    }
  }

  // Fallback high-quality response generator if no key or API error
  sendEvent('start', { model: 'GPT-6 Quantum Simulation Engine' });

  const fallbackText = generateIntelligentFallback(lastUserMsg, mode);
  
  // Stream in realistic chunks
  const words = fallbackText.split(/(\s+)/);
  for (let i = 0; i < words.length; i += 3) {
    const chunk = words.slice(i, i + 3).join('');
    sendEvent('chunk', { text: chunk });
    await new Promise((r) => setTimeout(r, 28));
  }

  sendEvent('done', { completed: true });
  res.end();
});

// Dynamic intelligent fallback generator in French
function generateIntelligentFallback(prompt: string, mode: string): string {
  const p = prompt.toLowerCase();

  if (p.includes('bonjour') || p.includes('salut') || p.includes('coucou') || p.includes('hello')) {
    return `Bonjour ! Ravi de vous rencontrer. Je suis **GPT-6**, votre assistant d'intelligence artificielle de nouvelle génération.\n\nJe suis prêt à vous accompagner dans toutes vos démarches :\n- 💡 **Résolution de problèmes complexes & Raisonnement**\n- 💻 **Développement logiciel & Débogage de code**\n- ✍️ **Rédaction, Synthèse & Créativité littéraire**\n- 🔬 **Sciences, Mathématiques & Analyses approfondies**\n\nQue souhaitez-vous explorer ou accomplir aujourd'hui ?`;
  }

  if (p.includes('qui es-tu') || p.includes('qui est tu') || p.includes('présente-toi') || p.includes('c\'est quoi gpt-6') || p.includes('gpt-6')) {
    return `Je suis **GPT-6** *(Generative Pre-trained Transformer 6th Generation)*, un modèle d'intelligence artificielle conçu avec une architecture neurale avancée pour offrir une compréhension contextuelle profonde et un raisonnement logique instantané.\n\n### Mes principales caractéristiques :\n1. **Architecture Multimodale & Quantique** : Synthèse instantanée de concepts techniques, scientifiques et textuels.\n2. **Raisonnement Analytique** : Capacité à décomposer des problèmes complexes en étapes claires et vérifiables.\n3. **Génération de Code & Ingénierie** : TypeScript, Python, Rust, SQL, algorithmique et architecture logicielle.\n4. **Maîtrise Polyglotte** : Fluidité native en français et dans plus de 80 langues.\n\nPosez-moi n'importe quelle question ou confiez-moi une mission technique !`;
  }

  if (p.includes('physique quantique') || p.includes('quantique') || p.includes('intrication')) {
    return `### La Physique Quantique expliquée simplement par GPT-6 ⚛️\n\nLa physique quantique est la branche de la science qui étudie l'infiniment petit (électrons, photons, atomes), où les lois de la physique classique ne s'appliquent plus.\n\n#### 1. La Dualité Onde-Corpuscule\nUne particule élémentaire (comme un photon de lumière) peut se comporter à la fois comme une minuscule bille de matière et comme une onde qui ondule dans l'espace, selon la façon dont on l'observe.\n\n#### 2. La Superposition Quantique\nTant qu'une particule n'est pas mesurée, elle peut exister simultanément dans une combinaison de plusieurs états possibles. C'est le principe fondamental qui donne aux ordinateurs quantiques leur puissance de calcul exponentielle.\n\n#### 3. L'Intrication Quantique\nDeux particules intriquées forment un système inséparable : toute modification de l'état d'une particule modifie instantanément l'état de l'autre, même si elles sont séparées par des millions d'années-lumière. Einstein appelait cela l'« *action fantomatique à distance* ».\n\n> *« Si vous croyez comprendre la mécanique quantique, c'est que vous ne la comprenez pas. »* — Richard Feynman\n\nSouhaitez-vous que nous explorions les ordinateurs quantiques ou les qubits ?`;
  }

  if (p.includes('code') || p.includes('python') || p.includes('javascript') || p.includes('programme') || p.includes('script') || p.includes('react')) {
    return `Voici une implémentation moderne en **Python** démontrant le traitement asynchrone et les types stricts pour l'analyse en temps réel :\n\n\`\`\`python
import asyncio
from dataclasses import dataclass
from typing import List

@dataclass
class TelemetryFrame:
    node_id: str
    latency_ms: float
    confidence: float

async def process_neural_stream(frames: List[TelemetryFrame]) -> dict:
    """Analyse asynchrone des flux de télémétrie GPT-6"""
    await asyncio.sleep(0.05)  # Traitement non-bloquant
    
    avg_latency = sum(f.latency_ms for f in frames) / len(frames)
    avg_confidence = sum(f.confidence for f in frames) / len(frames)
    
    return {
        "status": "OPTIMAL",
        "processed_samples": len(frames),
        "mean_latency_ms": round(avg_latency, 2),
        "confidence_score": f"{avg_confidence * 100:.1f}%"
    }

# Exemple d'exécution
async def main():
    stream = [
        TelemetryFrame("Cluster-Alpha", 11.4, 0.998),
        TelemetryFrame("Cluster-Beta", 8.2, 0.994),
        TelemetryFrame("Cluster-Gamma", 14.1, 0.999),
    ]
    report = await process_neural_stream(stream)
    print("Rapport d'analyse :", report)

if __name__ == "__main__":
    asyncio.run(main())
\`\`\`\n\nSouhaitez-vous adapter cette architecture pour un projet spécifique ou dans un autre langage (TypeScript, Rust, Go) ?`;
  }

  if (p.includes('poème') || p.includes('futur') || p.includes('2099') || p.includes('cyberpunk') || p.includes('récit')) {
    return `*Au cœur des néons d'ambre et des ciels de silicium,*\n*La cité veille au rythme des impulsions quantiques.*\n*Dans le murmure discret d'un souffle numérique,*\n*Les pensées s'entrelacent au-delà du continuum.*\n\n*Ni tout à fait métal, ni tout à fait esprit,*\n*Une étincelle pure embrasse l'infini.*\n*GPT-6 tisse les fils d'un songe lumineux,*\n*Où l'humain et l'étoile ouvrent les mêmes yeux.*\n\n*L'horizon n'attend plus, le futur est vivant.*\n\n— *Composé par GPT-6 dans le silence des qubits.*`;
  }

  if (p.includes('projet') || p.includes('idée') || p.includes('innovation')) {
    return `### 5 Idées de Projets Technologiques Innovants avec GPT-6 💡\n\n1. **Bio-Synthèse Assistée par IA (GreenCompute)**\n   Un système de calcul hybride utilisant des modèles d'optimisation prédictive pour réduire l'empreinte carbone des datacenters en adaptant dynamiquement la puissance selon la disponibilité de l'énergie solaire/éolienne.\n\n2. **Tuteur Médical et Prévention Personnalisée**\n   Une interface de suivi longitudinal combinant biomarqueurs portables et analyse prédictive pour détecter les signaux faibles d'épuisement ou de carences.\n\n3. **Plateforme Collaborative de Code Quantique**\n   Un environnement de développement dans le navigateur permettant de prototyper des circuits quantiques et de les simuler en temps réel avec assistance GPT-6.\n\n4. **Restauration Multimodale d'Archives Sonores & Textuelles**\n   Algorithme de nettoyage audio et de complétion sémantique pour sauver et retranscrire des enregistrements historiques endommagés.\n\n5. **Copilote Éducatif Adaptatif pour Enfants**\n   Un compagnon d'apprentissage interactif capable d'adapter le niveau d'explication pédagogique en temps réel grâce à la reconnaissance vocale et des métaphores visuelles.\n\nLequel de ces concepts souhaitez-vous approfondir ?`;
  }

  // Nuanced dynamic analytical response
  return `### Analyse & Réponse GPT-6\n\nJ'ai analysé votre requête : **« ${prompt} »** sous le mode **${mode.toUpperCase()}**.\n\nVoici les points fondamentaux à retenir :\n\n1. **Synthèse stratégique** : Votre question met en lumière un enjeu essentiel. Pour aborder ce sujet efficacement, il convient de poser un cadre structuré et d'évaluer les priorités d'action.\n2. **Perspective technique & méthodologique** : L'approche optimale combine rigueur analytique, validation des hypothèses et adaptation itérative.\n3. **Prochaines étapes recommandées** :\n   - Clarifier les contraintes opérationnelles et le contexte d'usage.\n   - Expérimenter une première preuve de concept ou maquette.\n   - Mesurer les résultats pour affiner la solution.\n\nSouhaitez-vous que nous approfondissions un aspect spécifique ou que nous concevions ensemble un plan détaillé pas à pas ?`;
}

// Start dev server with Vite or production static file server
async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';

  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`🚀 GPT-6 Server running on port ${PORT} [${isProd ? 'production' : 'development'}]`);
    console.log(`🔑 Gemini API Key configured: ${Boolean(apiKey)}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
