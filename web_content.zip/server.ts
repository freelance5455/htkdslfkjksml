import 'dotenv/config';
import express from 'express';
import http from 'node:http';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createServer as createViteServer } from 'vite';
import { aiRegistry } from './server/ai/registry';
import {
  extractDurableMemoriesFromTurn,
  transcribeVoiceClip,
} from './server/ai/providers/geminiProvider';
import { buildProjectSourceZipBuffer } from './server/export/projectExporter';
import { integrationRegistry } from './server/integrations/registry';
import { memoryStore } from './server/storage/memoryStore';
import { resolveConversationalLanguage } from './src/lib/language';
import { hasExplicitMemorySaveIntent, selectRelevantMemories } from './src/lib/memoryLogic';
import { getStreamSafeVisibleText } from './src/lib/streamParser';
import type {
  AssistantDomain,
  AttachmentContext,
  ConversationThread,
  ExplanationDepth,
  LanguagePreference,
  MemoryCategory,
} from './src/lib/jarvisTypes';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const PORT = Number(process.env.PORT || 3000);

function formatApiError(err: unknown): { status: number; message: string } {
  const raw = err instanceof Error ? err.message : String(err);

  let extractedMessage = raw;
  try {
    const outer = JSON.parse(raw);
    const innerRaw = outer?.error?.message ?? outer?.message;
    if (typeof innerRaw === 'string') {
      try {
        const inner = JSON.parse(innerRaw);
        extractedMessage = inner?.error?.message || inner?.message || innerRaw;
      } catch {
        extractedMessage = innerRaw;
      }
    }
  } catch {
    // Raw string is not JSON
  }

  if (raw.includes('GEMINI_API_KEY') || raw.includes('API_KEY_INVALID') || raw.includes('API key not valid')) {
    return {
      status: 400,
      message: 'API key missing or invalid. Check your GEMINI_API_KEY in Settings > Secrets.',
    };
  }
  if (raw.includes('timed out')) {
    return {
      status: 504,
      message: 'The response took longer than expected and timed out. Please try again.',
    };
  }
  if (raw.includes('400') || raw.includes('INVALID_ARGUMENT')) {
    return {
      status: 400,
      message: extractedMessage || 'Invalid request parameters.',
    };
  }
  if (raw.includes('PERMISSION_DENIED') || raw.includes('403')) {
    return {
      status: 403,
      message: 'Permission denied by Gemini API. Verify your key in Settings > Secrets.',
    };
  }
  if (raw.includes('RESOURCE_EXHAUSTED') || raw.includes('429')) {
    return {
      status: 429,
      message: 'Rate limit reached. Please wait a moment and try again.',
    };
  }
  if (raw.includes('503') || raw.includes('UNAVAILABLE')) {
    return {
      status: 503,
      message: 'The AI model is temporarily busy due to high demand. Please retry in a moment.',
    };
  }
  return {
    status: 500,
    message: extractedMessage || 'Failed to process AI request.',
  };
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '2mb' }));

  app.get('/api/health', (_req, res) => {
    res.json({
      ok: true,
      hasGeminiKey: Boolean(process.env.GEMINI_API_KEY),
      adapters: aiRegistry.listAllInfo().length,
      integrations: integrationRegistry.list().length,
    });
  });

  app.get('/api/models', (_req, res) => {
    res.json({
      models: aiRegistry.listAllInfo(),
      defaultModelId: aiRegistry.getDefault().info.id,
    });
  });

  app.get('/api/integrations', (_req, res) => {
    res.json({
      integrations: integrationRegistry.list(),
    });
  });

  app.get('/api/project/export', async (_req, res) => {
    try {
      const { buffer, fileCount } = await buildProjectSourceZipBuffer(__dirname);
      res.setHeader('Content-Type', 'application/zip');
      res.setHeader('Content-Disposition', 'attachment; filename="jarvis-ai-source.zip"');
      res.setHeader('Cache-Control', 'no-store');
      res.setHeader('X-Jarvis-Export-Files', String(fileCount));
      res.setHeader('Access-Control-Expose-Headers', 'X-Jarvis-Export-Files, Content-Disposition');
      res.send(buffer);
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Failed to package project source.';
      console.error(`[JARVIS API] /api/project/export failed: ${msg}`);
      res.status(500).json({ error: 'Unable to export project archive right now.' });
    }
  });

  // Persistent Conversation Threads API
  app.get('/api/threads', (_req, res) => {
    res.json({ threads: memoryStore.listThreads() });
  });

  app.post('/api/threads', (req, res) => {
    const thread = req.body?.thread as ConversationThread | undefined;
    if (!thread || !thread.id) {
      res.status(400).json({ error: 'Valid thread payload is required.' });
      return;
    }
    const saved = memoryStore.upsertThread(thread);
    res.json({ thread: saved });
  });

  app.post('/api/threads/migrate', (req, res) => {
    const incoming = req.body?.threads as ConversationThread[] | undefined;
    if (!Array.isArray(incoming)) {
      res.status(400).json({ error: 'threads array is required.' });
      return;
    }
    const threads = memoryStore.migrateThreads(incoming);
    res.json({ threads });
  });

  app.delete('/api/threads/:id', (req, res) => {
    const deleted = memoryStore.deleteThread(req.params.id);
    res.json({ deleted });
  });

  app.delete('/api/threads', (_req, res) => {
    memoryStore.clearThreads();
    res.json({ cleared: true });
  });

  // Persistent Long-Term User Memory API
  app.get('/api/memories', (_req, res) => {
    res.json({ memories: memoryStore.listMemories() });
  });

  app.post('/api/memories', (req, res) => {
    const { category, content, sourceThreadId, completed } = req.body as {
      category?: MemoryCategory;
      content?: string;
      sourceThreadId?: string;
      completed?: boolean;
    };

    if (!content || typeof content !== 'string' || !content.trim()) {
      res.status(400).json({ error: 'Memory content is required.' });
      return;
    }

    try {
      const result = memoryStore.addMemory({
        category: category || 'fact',
        content,
        sourceThreadId,
        completed,
      });
      res.status(result.created ? 201 : 200).json(result);
    } catch (err) {
      res.status(400).json({
        error: err instanceof Error ? err.message : 'Could not save memory.',
      });
    }
  });

  app.patch('/api/memories/:id', (req, res) => {
    const { content, category, completed } = req.body as {
      content?: string;
      category?: MemoryCategory;
      completed?: boolean;
    };
    try {
      const updated = memoryStore.updateMemory(req.params.id, {
        content,
        category,
        completed,
      });
      if (!updated) {
        res.status(404).json({ error: 'Memory not found.' });
        return;
      }
      res.json({ item: updated });
    } catch (err) {
      res.status(400).json({
        error: err instanceof Error ? err.message : 'Invalid memory update.',
      });
    }
  });

  app.delete('/api/memories/:id', (req, res) => {
    const deleted = memoryStore.deleteMemory(req.params.id);
    res.json({ deleted });
  });

  app.delete('/api/memories', (_req, res) => {
    memoryStore.clearMemories();
    res.json({ cleared: true });
  });

  // Optional voice transcription fallback for browsers without native Web SpeechRecognition
  app.post('/api/voice/transcribe', async (req, res) => {
    const { audioBase64, mimeType = 'audio/webm', languagePreference = 'auto' } = req.body as {
      audioBase64?: string;
      mimeType?: string;
      languagePreference?: LanguagePreference;
    };

    if (!audioBase64 || typeof audioBase64 !== 'string') {
      res.status(400).json({ error: 'Audio payload is required.' });
      return;
    }
    if (audioBase64.length > 6_000_000) {
      res.status(400).json({ error: 'Audio clip exceeds maximum allowed size.' });
      return;
    }

    try {
      const transcript = await transcribeVoiceClip({
        audioBase64,
        mimeType,
        languagePreference,
      });
      res.json({ transcript });
    } catch (err) {
      const formatted = formatApiError(err);
      console.error(`[JARVIS API] /api/voice/transcribe failed (${formatted.status}): ${formatted.message}`);
      res.status(formatted.status).json({ error: formatted.message });
    }
  });

  // Streaming AI Chat Endpoint with Memory Injection & Background Memory Extraction
  app.post('/api/chat/stream', async (req, res) => {
    const {
      message,
      history = [],
      modelId = 'gemini-3.1-flash-lite',
      domain = 'general',
      depth = 'balanced',
      languagePreference = 'auto',
      threadId,
      autoExtractMemory = true,
      attachment = null,
      inputMode = 'text',
      listeningActive = false,
    } = req.body as {
      message?: string;
      history?: Array<{ role: 'user' | 'assistant'; content: string }>;
      modelId?: string;
      domain?: AssistantDomain;
      depth?: ExplanationDepth;
      languagePreference?: LanguagePreference;
      threadId?: string;
      autoExtractMemory?: boolean;
      attachment?: AttachmentContext | null;
      inputMode?: 'text' | 'voice';
      listeningActive?: boolean;
    };

    if (!message || typeof message !== 'string' || !message.trim()) {
      res.status(400).json({ error: 'Message text is required.' });
      return;
    }

    if (message.length > 16000) {
      res.status(400).json({ error: 'Message exceeds maximum length (16,000 characters).' });
      return;
    }

    const adapter = aiRegistry.get(modelId) ?? aiRegistry.getDefault();
    const safeHistory = Array.isArray(history) ? history : [];
    const detectedLanguage = resolveConversationalLanguage({
      message,
      history: safeHistory,
      preference: languagePreference,
    });
    const allMemories = memoryStore.listMemories();
    const relevantMemories = selectRelevantMemories(allMemories, message, 16);

    res.setHeader('Content-Type', 'text/event-stream; charset=utf-8');
    res.setHeader('Cache-Control', 'no-cache, no-transform');
    res.setHeader('Connection', 'keep-alive');
    res.flushHeaders?.();

    const abortController = new AbortController();
    res.on('close', () => {
      if (!res.writableEnded) {
        abortController.abort();
      }
    });

    const sendEvent = (event: string, data: unknown) => {
      if (!res.writableEnded) {
        res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`);
      }
    };

    try {
      sendEvent('meta', {
        modelId: adapter.info.id,
        detectedUserLanguage: detectedLanguage,
        memoriesUsed: relevantMemories.length,
      });

      const explicitSaveRequested = hasExplicitMemorySaveIntent(message);
      const shouldExtractNow = Boolean(
        autoExtractMemory && explicitSaveRequested && !abortController.signal.aborted,
      );

      const memoryExtractionPromise: Promise<Array<{ category: MemoryCategory; content: string }>> =
        shouldExtractNow
          ? Promise.race([
              extractDurableMemoriesFromTurn({
                userMessage: message.trim(),
                existingMemories: allMemories,
              }),
              new Promise<Array<{ category: MemoryCategory; content: string }>>((resolve) =>
                setTimeout(() => resolve([]), 3500),
              ),
            ])
          : Promise.resolve([]);

      let lastSentText = '';
      const result = await adapter.streamChat(
        {
          message: message.trim(),
          history: Array.isArray(history) ? history : [],
          memories: relevantMemories,
          attachment:
            attachment && typeof attachment.content === 'string'
              ? {
                  name: String(attachment.name || 'file.txt').slice(0, 120),
                  content: attachment.content.slice(0, 18000),
                  sizeBytes: Number(attachment.sizeBytes) || attachment.content.length,
                }
              : null,
          domain,
          depth,
          languagePreference,
          detectedLanguage,
          inputMode: inputMode === 'voice' ? 'voice' : 'text',
          listeningActive: Boolean(listeningActive),
          explicitMemoryRequested: explicitSaveRequested,
          allowExplicitMemorySave: Boolean(autoExtractMemory),
        },
        (accumulatedRaw) => {
          const safeVisible = getStreamSafeVisibleText(accumulatedRaw);
          if (safeVisible !== lastSentText) {
            lastSentText = safeVisible;
            sendEvent('chunk', { text: safeVisible });
          }
        },
        abortController.signal,
      );

      const newlySaved: string[] = [];
      if (shouldExtractNow && !abortController.signal.aborted) {
        const candidates = await memoryExtractionPromise;
        for (const candidate of candidates) {
          const added = memoryStore.addMemory({
            category: candidate.category,
            content: candidate.content,
            sourceThreadId: threadId,
          });
          if (added.created) {
            newlySaved.push(added.item.content);
          }
        }
      }

      sendEvent('done', {
        text: result.fullText,
        followUps: result.followUps,
        detectedLanguage: result.detectedLanguage,
        modelId: result.modelId ?? adapter.info.id,
        savedMemories: newlySaved,
      });
      res.end();
    } catch (err) {
      if (abortController.signal.aborted) {
        res.end();
        return;
      }
      const formatted = formatApiError(err);
      console.error(`[JARVIS API] /api/chat/stream failed (${formatted.status}): ${formatted.message}`);
      sendEvent('error', { message: formatted.message, status: formatted.status });
      res.end();
    }
  });

  const server = http.createServer(app);

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: process.env.DISABLE_HMR !== 'true' ? { server } : false,
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(__dirname, 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  server.listen(PORT, '0.0.0.0', () => {
    console.log(`JARVIS AI server listening on http://localhost:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start JARVIS AI server:', err);
  process.exit(1);
});
