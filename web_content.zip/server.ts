import express, { Request, Response } from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';

dotenv.config();

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Helper to get Gemini client
function getGeminiClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
    return null;
  }
  return new GoogleGenAI({ apiKey });
}

// 1. AI Video Command Parsing (gemini-3.8-flash)
app.post('/api/ai/plan', async (req: Request, res: Response) => {
  const { prompt, videoDuration, currentSettings } = req.body;
  if (!prompt || typeof prompt !== 'string') {
    return res.status(400).json({ error: 'الرجاء إدخال أمر للمحرر' });
  }

  const ai = getGeminiClient();

  if (ai) {
    try {
      const systemInstruction = `
You are Designo's AI Video Assistant.
The user enters instructions in Arabic (or English/dialects) to edit or split a video.
Current video duration: ${videoDuration || 60} seconds.
Analyze the user request and return STRICTLY a JSON object matching this schema:
{
  "summaryArabic": "ملخص واضح ومباشر للعمليات باللغة العربية",
  "summaryEnglish": "English clear summary of the steps",
  "actions": {
    "split": {
      "enabled": boolean,
      "mode": "duration" | "count" | "none",
      "value": number // e.g. 10, 15, 20, 30, 40, 50, 60 or custom seconds, or count like 5
    },
    "aspectRatio": "9:16" | "16:9" | "1:1" | "4:5" | "original",
    "blurBackground": boolean,
    "title": string, // empty if not requested
    "subtitles": string, // caption or subtitle text if requested
    "filter": "normal" | "cinematic" | "vibrant" | "gold" | "bw" | "vintage",
    "speed": number, // default 1
    "volume": number, // 0 to 1
    "watermarkText": string, // watermark text or channel name if requested
    "templateId": string // e.g. "tiktok-9-16", "shorts-9-16", "reels-9-16", "cinematic", "gaming", "quotes", "sports", "product", "gold", "none"
  }
}
Return only JSON, no markdown formatting.
`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: [
          { role: 'user', parts: [{ text: `User request: ${prompt}\nCurrent settings: ${JSON.stringify(currentSettings || {})}` }] }
        ],
        config: {
          systemInstruction,
          responseMimeType: 'application/json',
          temperature: 0.2
        }
      });

      const text = response.text || '{}';
      const cleanJson = text.replace(/^```json\s*/, '').replace(/```\s*$/, '').trim();
      const parsed = JSON.parse(cleanJson);
      return res.json({ success: true, plan: parsed });
    } catch (err: any) {
      console.warn('Gemini plan error, falling back to local NLP parser:', err?.message);
    }
  }

  // Graceful Local Arabic NLP Parser fallback
  const plan = parseArabicInstructionLocally(prompt, videoDuration || 60);
  return res.json({ success: true, plan, isLocalFallback: true });
});

// Helper for local Arabic command interpretation
function parseArabicInstructionLocally(prompt: string, duration: number) {
  const p = prompt.toLowerCase();

  let splitSeconds = 0;
  let splitCount = 0;
  let splitMode: 'duration' | 'count' | 'none' = 'none';

  // Check split seconds like 50 ثانية, 40 ثانية, 30 ثانية, etc.
  const secMatch = p.match(/(\d+)\s*(ثانية|ثواني|ثوان|ث|sec|seconds?)/);
  if (secMatch) {
    splitSeconds = parseInt(secMatch[1], 10);
    splitMode = 'duration';
  } else if (p.includes('نصف دقيقة') || p.includes('نص دقيقة')) {
    splitSeconds = 30;
    splitMode = 'duration';
  } else if (p.includes('دقيقة')) {
    splitSeconds = 60;
    splitMode = 'duration';
  }

  // Check parts count like 5 أجزاء, 4 مقاطع
  const partsMatch = p.match(/(\d+)\s*(أجزاء|جزأ|اجزاء|مقاطع|مقطع|parts|clips)/);
  if (partsMatch && !splitSeconds) {
    splitCount = parseInt(partsMatch[1], 10);
    splitMode = 'count';
  }

  let aspectRatio: '9:16' | '16:9' | '1:1' | '4:5' | 'original' = 'original';
  let blurBackground = false;
  if (p.includes('عمودي') || p.includes('تيك توك') || p.includes('ريلز') || p.includes('شورتس') || p.includes('9:16') || p.includes('tiktok') || p.includes('reels') || p.includes('shorts')) {
    aspectRatio = '9:16';
    blurBackground = true;
  } else if (p.includes('أفقي') || p.includes('افقي') || p.includes('يوتيوب') || p.includes('16:9') || p.includes('عرضي')) {
    aspectRatio = '16:9';
  } else if (p.includes('مربع') || p.includes('1:1') || p.includes('انستقرام') || p.includes('إنستغرام')) {
    aspectRatio = '1:1';
  }

  let filter: 'normal' | 'cinematic' | 'vibrant' | 'gold' | 'bw' | 'vintage' = 'normal';
  if (p.includes('سينمائي') || p.includes('cinematic')) filter = 'cinematic';
  else if (p.includes('ذهبي') || p.includes('gold')) filter = 'gold';
  else if (p.includes('أبيض وأسود') || p.includes('ابيض واسود') || p.includes('رمادي')) filter = 'bw';
  else if (p.includes('ألوان مشبعة') || p.includes('حيوي')) filter = 'vibrant';
  else if (p.includes('قديم') || p.includes('كلاسيكي')) filter = 'vintage';

  let title = '';
  const titleMatch = p.match(/عنوان[:\s]+["'«]?([^"'\n,»]+)["'»]?/);
  if (titleMatch) {
    title = titleMatch[1].trim();
  }

  let watermarkText = '';
  const channelMatch = p.match(/(قناتي|اسم|شعار|لوجو|علامة)[:\s]+["'«]?([^"'\n,»]+)["'»]?/);
  if (channelMatch) {
    watermarkText = channelMatch[2].trim();
  }

  let templateId = 'none';
  if (aspectRatio === '9:16') templateId = 'tiktok-9-16';
  if (p.includes('رياض') || p.includes('كرة')) templateId = 'sports';
  if (p.includes('ألعاب') || p.includes('جيمنج') || p.includes('gaming')) templateId = 'gaming';
  if (p.includes('حكم') || p.includes('اقتباس')) templateId = 'quotes';

  const summaryArParts: string[] = [];
  if (splitMode === 'duration' && splitSeconds > 0) {
    summaryArParts.push(`تقسيم الفيديو إلى مقاطع مدة كل منها ${splitSeconds} ثانية`);
  } else if (splitMode === 'count' && splitCount > 0) {
    summaryArParts.push(`تقسيم الفيديو إلى ${splitCount} أجزاء متساوية`);
  }
  if (aspectRatio !== 'original') {
    summaryArParts.push(`تحويل الأبعاد إلى ${aspectRatio}${blurBackground ? ' مع خلفية ضبابية ذكية' : ''}`);
  }
  if (filter !== 'normal') {
    summaryArParts.push(`تطبيق مؤثر ألوان ${filter}`);
  }
  if (title) {
    summaryArParts.push(`إضافة عنوان: "${title}"`);
  }
  if (watermarkText) {
    summaryArParts.push(`إضافة علامة مائية باسم: "${watermarkText}"`);
  }

  return {
    summaryArabic: summaryArParts.length ? summaryArParts.join('، و') : 'تجهيز الفيديو وتحسين إعدادات العرض والأبعاد',
    summaryEnglish: `Prepared plan with detected edits and options.`,
    actions: {
      split: {
        enabled: splitMode !== 'none',
        mode: splitMode,
        value: splitMode === 'duration' ? splitSeconds : splitCount
      },
      aspectRatio,
      blurBackground,
      title,
      subtitles: '',
      filter,
      speed: 1,
      volume: 1,
      watermarkText,
      templateId
    }
  };
}

// 2. Text to Speech Endpoint (gemini-3.8-flash-tts)
app.post('/api/ai/tts', async (req: Request, res: Response) => {
  const { text, voice = 'Puck', style = 'Clear, engaging, enthusiastic video narrator' } = req.body;
  if (!text || typeof text !== 'string') {
    return res.status(400).json({ error: 'النص مطلوب لتوليد الصوت' });
  }

  const ai = getGeminiClient();
  if (ai) {
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash-tts',
        contents: [
          {
            role: 'user',
            parts: [
              {
                text,
                speechMetadata: {
                  style
                }
              }
            ]
          }
        ],
        config: {
          responseModalities: ['AUDIO'],
          speechConfig: {
            voiceConfig: {
              prebuiltVoiceConfig: { voiceName: voice }
            }
          }
        }
      });

      const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
      if (base64Audio) {
        return res.json({
          success: true,
          audioData: `data:audio/wav;base64,${base64Audio}`,
          model: 'gemini-3.8-flash-tts'
        });
      }
    } catch (err: any) {
      console.warn('Gemini 3.8 Flash TTS error:', err?.message);
    }
  }

  // Return fallback notification for client speech synthesis
  return res.json({
    success: false,
    useClientSynthesis: true,
    text,
    message: 'سيتم استخدام قارئ الصوت المحلي بالمتصفح بجودة عالية'
  });
});

// 3. Search Grounding Endpoint (gemini-3.8-flash with googleSearch)
app.post('/api/ai/grounding', async (req: Request, res: Response) => {
  const { query, topic = 'general' } = req.body;
  const promptQuery = query || `ما هي أكثر المواضيع والهاشتاجات الرائجة لفيديوهات تيك توك وريلز في مجال ${topic} باللغة العربية؟`;

  const ai = getGeminiClient();
  if (ai) {
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: promptQuery,
        config: {
          tools: [{ googleSearch: {} }],
          temperature: 0.3
        }
      });

      const text = response.text || '';
      const searchChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];

      return res.json({
        success: true,
        content: text,
        sources: searchChunks.map((c: any) => c.web?.uri).filter(Boolean),
        model: 'gemini-3.8-flash'
      });
    } catch (err: any) {
      console.warn('Grounding error:', err?.message);
    }
  }

  // Fallback trending suggestions
  return res.json({
    success: true,
    content: `#ترند #اكسبلور #تصميم #فيديو #ريلز #شورتس #تيك_توك\n\nأفكار رائجة:\n1. أهم 3 نصائح سريعة في أقل من 30 ثانية\n2. لقطات قبل وبعد التحول\n3. أسئلة تحفيزية وتفاعل مع الجمهور`,
    sources: [],
    isLocalFallback: true
  });
});

// 4. Image Understanding Endpoint (gemini-4-argon)
app.post('/api/ai/analyze-image', async (req: Request, res: Response) => {
  const { imageBase64, mimeType = 'image/jpeg', prompt = 'قم بتحليل هذه الصورة واقترح أفضل نظام ألوان، وعنوان، ونوع خط يناسب استخدامها كشعار أو غلاف لفيديو مونتاج' } = req.body;

  if (!imageBase64) {
    return res.status(400).json({ error: 'بيانات الصورة مطلوبة' });
  }

  const ai = getGeminiClient();
  if (ai) {
    try {
      // Clean base64 header if included
      const cleanData = imageBase64.replace(/^data:image\/[a-zA-Z0-9+]+;base64,/, '');

      const response = await ai.models.generateContent({
        model: 'gemini-4-argon',
        contents: {
          parts: [
            { inlineData: { data: cleanData, mimeType } },
            { text: prompt }
          ]
        }
      });

      return res.json({
        success: true,
        analysis: response.text || '',
        model: 'gemini-4-argon'
      });
    } catch (err: any) {
      console.warn('gemini-4-argon analysis error:', err?.message);
      return res.status(500).json({
        error: 'حدث خطأ أثناء معالجة الصورة بنموذج gemini-4-argon',
        details: err?.message
      });
    }
  }

  return res.json({
    success: true,
    analysis: 'تحليل محلي للصورة: الصورة تحتوي على تباين جيد، يُنصح باستخدام ألوان نصوص بنفسجية أو بيضاء بخط عريض لضمان الوضوح التام على مقاطع الفيديو.',
    isLocalFallback: true
  });
});

// Health check endpoint
app.get('/api/health', (req: Request, res: Response) => {
  res.json({
    status: 'ok',
    app: 'Designo',
    version: '1.0.0',
    hasApiKey: !!process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY !== 'MY_GEMINI_API_KEY'
  });
});

// Setup Vite or static serving
async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';

  if (!isProd) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`🚀 Designo Server is running on port ${PORT}`);
  });
}

startServer();
