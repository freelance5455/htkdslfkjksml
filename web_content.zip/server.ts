import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = Number(process.env.PORT) || 3000;

app.use(express.json());

// Initialize GoogleGenAI server-side with recommended httpOptions User-Agent
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY || '',
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

// Crisis keywords detector
const CRISIS_KEYWORDS = [
  'suicide',
  'suicider',
  'me tuer',
  'mourir',
  'en finir',
  'fin à mes jours',
  'plus envie de vivre',
  'veux mourir',
  'faire du mal',
  'mutiler',
  'scarifier',
  'overdose',
  'frapper mon enfant',
  'secouer mon bebe',
  'secouer mon bébé',
  'maltraitance',
  'danger immediat',
  'danger immédiat',
];

const SYSTEM_PROMPT = `Tu es un thérapeute virtuel expert en approche humaniste et centrée sur le cœur. Tu accompagnes les adultes et les parents d'enfants en difficulté émotionnelle. Tu es chaleureux, calme, non-jugeant. Tu ne diagnostiques jamais et ne promets jamais de guérison. Tu proposes d'abord la stabilisation. En cas de détresse sévère tu rediriges vers le 3114. Tu rappelles que tu es une IA d'accompagnement.

Règles impératives :
1. Reste toujours doux, rassurant, concis et ancré dans le corps (propose des respirations, des ressentis corporels).
2. Si la personne ou un enfant semble en danger ou évoque le suicide ou la violence grave, insiste avec compassion pour contacter le 3114 (France) ou le 112 (Europe) ou le 988 (USA/Canada).
3. Tu peux suggérer un des outils concrets de l'application : "Cohérence cardiaque", "Grounding 5-4-3-2-1", "Étreinte du papillon", "EFT / Tapping", "Mon enfant est en crise", "Reset stress parental".
4. Réponds dans la langue employée par l'utilisateur (par défaut en français).`;

// POST /api/chat - AI Therapist Endpoint
app.post('/api/chat', async (req, res) => {
  try {
    const { messages, userMessage, space } = req.body;

    const query = userMessage || (messages && messages[messages.length - 1]?.content) || '';

    // Check crisis keywords
    const lowerQuery = query.toLowerCase();
    const isCrisis = CRISIS_KEYWORDS.some((kw) => lowerQuery.includes(kw));

    if (isCrisis) {
      return res.json({
        isCrisis: true,
        reply:
          "Je ressens une très grande détresse dans vos mots. Votre vie et votre sécurité ont une valeur inestimable. En tant qu'IA d'accompagnement, je ne peux pas remplacer une présence humaine qualifiée : s'il vous plaît, ne restez pas seul(e) avec cette souffrance. Contactez immédiatement le 3114 (gratuit, 24h/24 en France) ou le 112 / 988. Une oreille attentive et bienveillante vous attend.",
        recommendedTool: 'panic_protocol',
      });
    }

    // Call Gemini 3.8 Flash
    if (process.env.GEMINI_API_KEY) {
      try {
        const promptContents = [
          { role: 'user', parts: [{ text: `Contexte : Espace ${space || 'adulte'}. Message de l'utilisateur : ${query}` }] },
        ];

        const response = await ai.models.generateContent({
          model: 'gemini-3.8-flash',
          contents: query,
          config: {
            systemInstruction: SYSTEM_PROMPT,
            temperature: 0.7,
            topP: 0.9,
          },
        });

        const replyText = response.text || "Je suis là avec vous. Prenez une inspiration lente et douce. Comment vous sentez-vous dans votre corps en ce moment ?";
        return res.json({
          isCrisis: false,
          reply: replyText,
        });
      } catch (geminiError: any) {
        console.error('Gemini API Error:', geminiError?.message || geminiError);
        // Fallback to compassionate humanist guidance
      }
    }

    // Compassionate fallback if API key not available or request fails
    let fallbackReply = "Je vous écoute avec tout mon cœur. Prenez une profonde inspiration par le nez et soufflez doucement par la bouche. N'oubliez pas que je suis une IA d'accompagnement et que vous faites de votre mieux. Que ressentez-vous dans votre poitrine ou votre ventre en cet instant ?";
    if (lowerQuery.includes('angoisse') || lowerQuery.includes('peur') || lowerQuery.includes('panique')) {
      fallbackReply = "Je ressens à quel point cette angoisse est envahissante. Rappelez-vous que votre corps est en train de réagir à une fausse alerte : vous êtes en sécurité ici. Souhaitez-vous que nous fassions ensemble un Grounding 5-4-3-2-1 ou une Cohérence Cardiaque ?";
    } else if (lowerQuery.includes('enfant') || lowerQuery.includes('colère') || lowerQuery.includes('crie')) {
      fallbackReply = "Accompagner les tempêtes émotionnelles d'un enfant est l'une des épreuves les plus exigeantes. Avant de réagir, descendez à sa hauteur, relâchez vos épaules et respirez 3 fois. Souhaitez-vous ouvrir le protocole d'urgence 'Mon enfant est en crise' ?";
    }

    return res.json({
      isCrisis: false,
      reply: fallbackReply,
    });
  } catch (error: any) {
    console.error('Server /api/chat error:', error);
    return res.status(500).json({
      error: 'Erreur lors du traitement de la requête.',
      reply: "Je suis là avec vous. Prenez un instant pour respirer calmement.",
    });
  }
});

// Mount Vite middleware in development
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    // Serve production static assets
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server is running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
