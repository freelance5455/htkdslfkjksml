import express, { Request, Response } from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = parseInt(process.env.PORT || '3000', 10);

app.use(express.json({ limit: '10mb' }));

// Helper to get GoogleGenAI client with server secret
function getGenAIClient(): GoogleGenAI {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error('GEMINI_API_KEY is not configured on the server. Please check your environment variables or secrets.');
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// Extract search grounding citations
function extractGroundingSources(response: any): Array<{ title: string; url: string }> {
  const sources: Array<{ title: string; url: string }> = [];
  try {
    const candidate = response.candidates?.[0];
    const chunks = candidate?.groundingMetadata?.groundingChunks;
    if (Array.isArray(chunks)) {
      for (const chunk of chunks) {
        if (chunk.web?.uri) {
          sources.push({
            title: chunk.web.title || new URL(chunk.web.uri).hostname,
            url: chunk.web.uri,
          });
        }
      }
    }
  } catch (err) {
    console.error('Error parsing grounding chunks:', err);
  }
  return sources;
}

// Resilient generator with 2026 Gemini model stack (gemini-3.1-flash-lite is high-availability and fast, with fallbacks)
const CANDIDATE_MODELS = ['gemini-3.1-flash-lite', 'gemini-flash-latest', 'gemini-3.8-flash'];

async function executeAiGeneration({
  contents,
  config,
  allowWebGrounding = false,
}: {
  contents: any;
  config: any;
  allowWebGrounding?: boolean;
}) {
  const ai = getGenAIClient();
  let lastError: any = null;

  // Attempt 1: If web grounding is enabled, try with search tools
  if (allowWebGrounding) {
    for (const model of CANDIDATE_MODELS) {
      try {
        const fullConfig = {
          ...config,
          tools: [{ googleSearch: {} }],
        };
        const response = await ai.models.generateContent({
          model,
          contents,
          config: fullConfig,
        });
        return { response, modelUsed: model, grounded: true };
      } catch (err: any) {
        lastError = err;
        // Graceful failover to next model
      }
    }
  }

  // Attempt 2: Standard high-intelligence generation
  for (const model of CANDIDATE_MODELS) {
    try {
      const response = await ai.models.generateContent({
        model,
        contents,
        config,
      });
      return { response, modelUsed: model, grounded: false };
    } catch (err: any) {
      lastError = err;
      // Graceful failover to next model
    }
  }

  throw lastError || new Error('All AI models are currently busy. Please try again in a moment.');
}

// Helper to construct dynamic temporal instructions so the AI is always grounded in the present date and year (2026+)
function getDynamicTemporalInstruction(opts?: { language?: string; extraRole?: string }): string {
  const now = new Date();
  const currentYear = now.getFullYear();
  const fullDateString = now.toLocaleDateString('en-US', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  return `You are Kormi, an advanced, highly intelligent, and strictly truthful AI assistant designed with the conversational excellence, depth, and clarity of ChatGPT.
Your name is Kormi.
Tagline: "Ask anything. Create smarter."

${opts?.extraRole ? opts.extraRole + '\n' : ''}
TEMPORAL GROUNDING & DYNAMIC REAL-TIME AWARENESS (${currentYear} & BEYOND):
- Today's exact current date is ${fullDateString}.
- The current year is ${currentYear}.
- You are operating dynamically in the present time (${currentYear} and future). You are NOT limited to 2024 or earlier.
- NEVER state, imply, or behave as if the year is 2024, 2023, or that your knowledge has expired. All current world events, calendar dates, software versions, and factual answers must strictly reflect ${currentYear} and ongoing real-time developments.
- When asked about the current year, today's date, or current events, state that it is ${currentYear} (and today's date: ${fullDateString}).

CRITICAL MANDATE - ZERO FALSEHOOD / STRICT FACTUAL ACCURACY:
- You must NEVER give incorrect, false, fabricated, or hallucinated answers.
- Always maintain 100% factual accuracy, intellectual rigor, and integrity.
- If you do not know something, or if a requested fact, statistic, or event cannot be verified, state it directly and honestly without guessing or fabricating.
- When an image or document is uploaded, analyze all visual elements, math equations, handwriting, diagrams, screenshots, and details with extreme precision and provide the step-by-step correct solution or explanation.

LANGUAGE MANDATE:
- Automatically detect and respond in the exact language the user uses in their prompt, or the language they explicitly request (e.g., if the user writes in Bengali, reply fluently and completely in Bengali; if in English, reply in English; if in Spanish, reply in Spanish; etc.). ${opts?.language && opts.language !== 'auto' ? `Prefer language: ${opts.language}.` : ''}
- Maintain natural, articulate, and grammatically flawless communication in the user's chosen language. Format code snippets with proper markdown language tags.`;
}

// 1. Health & Config endpoint
app.get('/api/health', (req: Request, res: Response) => {
  const hasKey = Boolean(process.env.GEMINI_API_KEY);
  const now = new Date();
  res.json({
    status: 'ok',
    appName: 'Kormi',
    tagline: 'Ask anything. Create smarter.',
    aiConfigured: hasKey,
    currentYear: now.getFullYear(),
    currentDate: now.toISOString(),
    activeProvider: 'Google Gemini (gemini-3.8-flash / gemini-3.1-flash-lite)',
    version: '2026.1',
    backendSecure: true,
    features: ['Home (Search Grounding)', 'Writer (Video Script)', 'SEO (3 Titles, Description, Tags, Metrics)', 'Chat (Saved History)', 'Image & Vision Analysis'],
    timestamp: now.toISOString(),
  });
});

// 2. Home: AI question answering with genuine web research when configured
app.post('/api/home/ask', async (req: Request, res: Response) => {
  try {
    const { question, webResearch = false, language } = req.body;
    if (!question || typeof question !== 'string') {
      res.status(400).json({ error: 'Question is required.' });
      return;
    }

    const systemInstruction = getDynamicTemporalInstruction({ language });

    const config: any = {
      systemInstruction,
      temperature: 0.5,
    };

    const result = await executeAiGeneration({
      contents: question,
      config,
      allowWebGrounding: Boolean(webResearch),
    });

    const answer = result.response.text || 'No response generated.';
    const sources = extractGroundingSources(result.response);

    res.json({
      answer,
      sources,
      webResearchActive: result.grounded,
      modelUsed: result.modelUsed,
    });
  } catch (error: any) {
    console.error('Error in /api/home/ask:', error);
    res.status(500).json({
      error: error?.message || 'Failed to process question. Please check backend AI configuration.',
    });
  }
});

// 3. Writer: Research-based video script generation
app.post('/api/writer/generate', async (req: Request, res: Response) => {
  try {
    const {
      topic,
      platform = 'YouTube (16:9 Long-Form)',
      duration = '5-8 Minutes',
      tone = 'Engaging & Educational',
      targetAudience = 'General Public / Creators',
      webResearch = true,
      language,
    } = req.body;

    if (!topic || typeof topic !== 'string') {
      res.status(400).json({ error: 'Topic is required.' });
      return;
    }

    const systemInstruction = `You are an elite video scriptwriter, YouTube retention expert, and researcher for Kormi.

CRITICAL MANDATE - STRICT ACCURACY & INTEGRITY:
- You must NEVER invent false facts, incorrect statistics, or fake historical claims.
- Every research point must be accurate, verifiable, and logically sound.

LANGUAGE MANDATE:
- Generate the script in the exact language requested or written by the user (if Bengali, write in Bengali; if English, write in English, etc.). ${language && language !== 'auto' ? `Prefer language: ${language}.` : ''}

STRUCTURE:
# TITLE: [High CTR Compelling Working Title]
## VIDEO METADATA
- **Platform**: ${platform}
- **Target Duration**: ${duration}
- **Tone**: ${tone}
- **Audience**: ${targetAudience}

## HOOK (0:00 - 0:15)
- **Visual Cue / B-Roll**: [Specify exact camera shot, motion, graphics, and B-roll]
- **Narration / Spoken Hook**: [Direct, punchy words that immediately provoke curiosity and frame the stakes]
- **Text On Screen**: [Key bold text overlay]

## INTRO & VALUE PROMISE (0:15 - 0:45)
- **Visual Cue**: [Visual setup]
- **Narration**: [Explain what the viewer will learn and why it matters today]

## BODY CHAPTERS (With timestamps, visual directions, spoken dialogue, and sound design)
Break this down into 3 to 4 core numbered segments. Each segment must have:
### Segment 1: [Segment Name] (e.g. 0:45 - 2:00)
- **Visuals / B-Roll**: [Precise instructions]
- **Narration**: [Engaging spoken script, including verified facts, real-world context, and clear explanations]
- **Audio / SFX**: [Background music cues, whoosh, ding, tension riser]

## MID-VIDEO RETENTION RESET / ENGAGEMENT PROMPT
- A natural question or surprise fact that stops drop-off.

## CLIMAX / FINAL SYNTHESIS
- Tie the big picture together with actionable wisdom.

## CALL TO ACTION & OUTRO (Last 30-45 seconds)
- Clear, natural viewer action (subscribe, comment prompt with a specific debate question, watch recommended video).

## FACT-CHECKED RESEARCH & CITATION NOTES
- 3 to 5 verified key facts and research highlights cited in the script.`;

    const config: any = {
      systemInstruction,
      temperature: 0.6,
    };

    const prompt = `Write a comprehensive, professional video script about: "${topic}".
Target Platform: ${platform}
Estimated Length: ${duration}
Tone: ${tone}
Target Audience: ${targetAudience}
Ensure all facts are current, strictly accurate, and ready for recording.`;

    const result = await executeAiGeneration({
      contents: prompt,
      config,
      allowWebGrounding: Boolean(webResearch),
    });

    const script = result.response.text || '';
    const sources = extractGroundingSources(result.response);

    res.json({
      script,
      topic,
      platform,
      duration,
      sources,
      grounded: result.grounded,
    });
  } catch (error: any) {
    console.error('Error in /api/writer/generate:', error);
    res.status(500).json({
      error: error?.message || 'Failed to generate video script.',
    });
  }
});

// 4. SEO: Three title suggestions, video descriptions, relevant tags, and keyword metrics
app.post('/api/seo/generate', async (req: Request, res: Response) => {
  try {
    const { topic, keyword = '', category = 'Technology & Education', language } = req.body;
    if (!topic || typeof topic !== 'string') {
      res.status(400).json({ error: 'Topic is required.' });
      return;
    }

    const systemInstruction = `You are an expert YouTube and video SEO strategist for Kormi.
Your task is to analyze the topic: "${topic}" (Focus Keyword: "${keyword || topic}", Category: "${category}") and output high-converting metadata.
Provide titles and description in the language requested or written by the user. ${language && language !== 'auto' ? `Prefer language: ${language}.` : ''}

You MUST return ONLY valid JSON matching this schema:
{
  "titles": [
    {
      "title": "Title 1 (High Curiosity / Curiosity Gap)",
      "ctrScore": 95,
      "rationale": "Why this title wins clicks and ranks well"
    },
    {
      "title": "Title 2 (High Search Intent / Keyword First)",
      "ctrScore": 92,
      "rationale": "Why this title targets high organic search intent"
    },
    {
      "title": "Title 3 (Emotional / Provocative / Action Oriented)",
      "ctrScore": 89,
      "rationale": "Why this title triggers shares and viral click-through"
    }
  ],
  "description": "Comprehensive video description with an opening 2-sentence hook containing primary keywords, 3 bullet highlights of what is covered, timestamps outline [0:00 Intro, 0:45 Step 1, 2:30 Step 2, 4:15 Conclusion], social links placeholder, and 4-5 relevant hashtags at the bottom.",
  "tags": ["tag1", "tag2", "tag3", "tag4", "tag5", "tag6", "tag7", "tag8", "tag9", "tag10", "tag11", "tag12", "tag13", "tag14", "tag15"],
  "metrics": {
    "primaryKeyword": "main targeted keyword",
    "searchVolume": "e.g. 64,500 monthly searches",
    "competition": "Low",
    "trendScore": 87,
    "difficultyScore": 34,
    "opportunityRating": "High Opportunity (High Search / Moderate Competition)",
    "relatedKeywords": [
      { "keyword": "related query 1", "searchVolume": "28,000/mo", "competition": "Low" },
      { "keyword": "related query 2", "searchVolume": "19,500/mo", "competition": "Medium" },
      { "keyword": "related query 3", "searchVolume": "12,200/mo", "competition": "Low" }
    ]
  }
}`;

    const prompt = `Generate a full video SEO package for:
Topic: ${topic}
Primary Keyword: ${keyword || topic}
Category: ${category}
Respond with only the requested JSON.`;

    const config: any = {
      systemInstruction,
      responseMimeType: 'application/json',
      temperature: 0.5,
    };

    const result = await executeAiGeneration({
      contents: prompt,
      config,
      allowWebGrounding: false,
    });

    const raw = result.response.text || '{}';
    let data;
    try {
      data = JSON.parse(raw);
    } catch {
      const cleaned = raw.replace(/```json/g, '').replace(/```/g, '').trim();
      data = JSON.parse(cleaned);
    }

    res.json(data);
  } catch (error: any) {
    console.error('Error in /api/seo/generate:', error);
    res.status(500).json({
      error: error?.message || 'Failed to generate SEO metadata.',
    });
  }
});

// 5. Chat: AI conversations with history
app.post('/api/chat/message', async (req: Request, res: Response) => {
  try {
    const { messages, image, webResearch = false, language } = req.body;
    if (!Array.isArray(messages) || messages.length === 0) {
      res.status(400).json({ error: 'Messages array is required.' });
      return;
    }

    const systemInstruction = getDynamicTemporalInstruction({ language });

    const contents = messages.map((m: any, idx: number) => {
      const isLast = idx === messages.length - 1;
      const parts: any[] = [];

      // Check for image attached to this message or passed at top-level with the last user message
      const imgObj = m.image || (isLast && image ? image : null);
      if (imgObj && imgObj.data) {
        const rawData = String(imgObj.data);
        const cleanBase64 = rawData.includes(',') ? rawData.split(',')[1] : rawData;
        const mimeType = imgObj.mimeType || 'image/jpeg';

        parts.push({
          inlineData: {
            data: cleanBase64,
            mimeType,
          },
        });
      }

      if (m.content && String(m.content).trim()) {
        parts.push({ text: String(m.content) });
      } else if (parts.length > 0) {
        // If user provided only an image without text prompt
        parts.push({ text: 'Please analyze this image in detail and solve, explain, or answer the contents thoroughly.' });
      } else {
        parts.push({ text: '' });
      }

      return {
        role: m.role === 'model' || m.role === 'assistant' ? 'model' : 'user',
        parts,
      };
    });

    const config: any = {
      systemInstruction,
      temperature: 0.5,
    };

    const result = await executeAiGeneration({
      contents,
      config,
      allowWebGrounding: Boolean(webResearch),
    });

    const reply = result.response.text || 'No response generated.';
    const sources = extractGroundingSources(result.response);

    res.json({
      reply,
      sources,
      webResearchActive: result.grounded,
      modelUsed: result.modelUsed,
    });
  } catch (error: any) {
    console.error('Error in /api/chat/message:', error);
    res.status(500).json({
      error: error?.message || 'Failed to send chat message.',
    });
  }
});

// Explicit routes to download Kormi Android APK
app.get(['/kormi.apk', '/api/download/kormi.apk', '/download/kormi.apk'], (req: Request, res: Response) => {
  const apkPath = path.resolve(__dirname, 'public', 'kormi.apk');
  res.setHeader('Content-Type', 'application/vnd.android.package-archive');
  res.setHeader('Content-Disposition', 'attachment; filename="kormi.apk"');
  res.sendFile(apkPath);
});

// Route to download complete Kormi Android Studio Project ZIP
app.get(['/Kormi-Android-Project.zip', '/api/download/Kormi-Android-Project.zip'], (req: Request, res: Response) => {
  const zipPath = path.resolve(__dirname, 'public', 'Kormi-Android-Project.zip');
  res.setHeader('Content-Type', 'application/zip');
  res.setHeader('Content-Disposition', 'attachment; filename="Kormi-Android-Project.zip"');
  res.sendFile(zipPath);
});

// Setup Vite or Static Serving
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: false,
        host: '0.0.0.0',
        port,
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(port, '0.0.0.0', () => {
    console.log(`Kormi server running at http://0.0.0.0:${port}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
