import express from 'express';
import http from 'http';
import path from 'path';
import fs from 'fs';
import crypto from 'crypto';
import { WebSocketServer, WebSocket } from 'ws';
import { GoogleGenAI, ThinkingLevel, Modality, LiveServerMessage } from '@google/genai';
import dotenv from 'dotenv';

dotenv.config();

const app = express();
const server = http.createServer(app);
const port = Number(process.env.PORT) || 3000;

// Middleware for parsing JSON with generous limit for images & audio
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Database Persistence
const DATA_DIR = path.resolve(process.cwd(), 'data');
const DB_PATH = path.join(DATA_DIR, 'db.json');

if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

interface Message {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: number;
  model?: string;
  attachments?: any[];
  groundingSources?: any[];
  thoughtProcess?: string;
  isVoiceInput?: boolean;
  audioUrl?: string;
  generatedImages?: any[];
}

interface ChatSession {
  id: string;
  userId?: string;
  title: string;
  createdAt: number;
  updatedAt: number;
  messages: Message[];
  pinned?: boolean;
}

interface UserRecord {
  id: string;
  name: string;
  email: string;
  passwordHash?: string;
  salt?: string;
  avatar?: string;
  provider: 'email' | 'google';
  createdAt: number;
  plan?: 'free' | 'pro';
}

interface UserSessionRecord {
  token: string;
  userId: string;
  createdAt: number;
  expiresAt: number;
}

interface UserMemoryRecord {
  id: string;
  userId: string;
  text: string;
  createdAt: number;
}

interface UserSettingsRecord {
  userId: string;
  preferredModel: string;
  responseStyle: 'concise' | 'balanced' | 'detailed' | 'casual' | 'formal' | 'strict';
  defaultLanguage: string;
  customInstructions: string;
  memoryEnabled: boolean;
  confirmBeforeDelete: boolean;
  theme: 'dark' | 'light' | 'system';
  fontSize: 'small' | 'medium' | 'large';
  accentColor: 'blue' | 'cyan' | 'purple' | 'emerald';
  ttsEnabled: boolean;
  voiceName: string;
  voiceSpeed: number;
  autoPlayAudio: boolean;
  notificationsEnabled: boolean;
  notificationTypes: {
    systemUpdates: boolean;
    generationComplete: boolean;
    tips: boolean;
  };
  dataSharingEnabled: boolean;
  analyticsEnabled: boolean;
}

interface Database {
  users: UserRecord[];
  authSessions: UserSessionRecord[];
  userSettings: UserSettingsRecord[];
  memories: UserMemoryRecord[];
  sessions: ChatSession[];
}

// Password hashing and crypto utilities
function hashPassword(password: string): { salt: string; hash: string } {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  return { salt, hash };
}

function verifyPassword(password: string, salt: string, hash: string): boolean {
  try {
    const computedHash = crypto.scryptSync(password, salt, 64).toString('hex');
    return crypto.timingSafeEqual(Buffer.from(computedHash, 'hex'), Buffer.from(hash, 'hex'));
  } catch {
    return false;
  }
}

function generateToken(): string {
  return crypto.randomBytes(32).toString('hex');
}

function sanitizeUser(user: UserRecord) {
  const { passwordHash, salt, ...safe } = user;
  return safe;
}

function getDefaultSettings(userId: string): UserSettingsRecord {
  return {
    userId,
    preferredModel: 'gemini-3.8-flash',
    responseStyle: 'balanced',
    defaultLanguage: 'العربية',
    customInstructions: '',
    memoryEnabled: true,
    confirmBeforeDelete: true,
    theme: 'dark',
    fontSize: 'medium',
    accentColor: 'blue',
    ttsEnabled: true,
    voiceName: 'Aoede',
    voiceSpeed: 1,
    autoPlayAudio: false,
    notificationsEnabled: true,
    notificationTypes: {
      systemUpdates: true,
      generationComplete: true,
      tips: false,
    },
    dataSharingEnabled: false,
    analyticsEnabled: false,
  };
}

// Ensure model name is supported (maps gemini-2.5-flash / gemini-3.5-flash to gemini-3.8-flash)
function normalizeModel(model?: string): string {
  if (!model || model === 'gemini-2.5-flash' || model === 'gemini-3.5-flash') {
    return 'gemini-3.8-flash';
  }
  return model;
}

// Detects if a user message warrants real-time Google Search Grounding for accurate, up-to-date data
function isSearchRelevant(prompt?: string): boolean {
  if (!prompt || typeof prompt !== 'string') return false;
  const p = prompt.toLowerCase().trim();
  if (p.length < 2) return false;

  const searchTriggers = [
    'اليوم', 'الآن', 'الان', 'أمس', 'امس', 'غدا', 'غداً', 'أخبار', 'اخبار', 'أحدث', 'احدث', 'آخر الأخبار', 'اخر الاخبار',
    'سعر', 'أسعار', 'اسعار', 'طقس', 'الجو', 'درجة الحرارة', 'مباراة', 'نتائج', 'فاز', 'دوري', 'كأس', 'كاس', 'ترتيب',
    'من هو', 'من هي', 'من هم', 'ما هو', 'ما هي', 'ماذا حدث', 'متى', 'أين', 'اين', 'كم سعر', 'كم يبلغ', 'كم عدد',
    'عام 2026', 'سنة 2026', 'عام 2025', 'سنة 2025', 'تحديثات', 'إطلاق', 'اطلاق', 'مؤتمر',
    'مباشر', 'موقع', 'رابط', 'ابحث', 'بحث', 'جوجل', 'معلومات عن', 'أين يقع', 'اين يقع',
    'today', 'now', 'yesterday', 'tomorrow', 'news', 'latest', 'current', 'weather',
    'price', 'stock', 'crypto', 'bitcoin', 'score', 'who won', 'match', 'release date',
    'who is', 'what is', 'where is', 'when did', 'recent', '2025', '2026', 'update',
    'trending', 'search', 'google', 'find', 'lookup'
  ];

  return searchTriggers.some((trigger) => p.includes(trigger));
}

function readDb(): Database {
  try {
    if (!fs.existsSync(DB_PATH)) {
      const demoSaltHash = hashPassword('password123');
      const initial: Database = {
        users: [
          {
            id: 'usr-demo-1',
            name: 'مستخدم أونيكس',
            email: 'demo@onyx.ai',
            passwordHash: demoSaltHash.hash,
            salt: demoSaltHash.salt,
            provider: 'email',
            createdAt: Date.now(),
            plan: 'pro',
          },
        ],
        authSessions: [],
        userSettings: [getDefaultSettings('usr-demo-1')],
        memories: [
          {
            id: 'mem-1',
            userId: 'usr-demo-1',
            text: 'يفضل الشرح باللغة العربية الفصحى وتقديم أمثلة عملية.',
            createdAt: Date.now() - 86400000,
          },
        ],
        sessions: [],
      };
      fs.writeFileSync(DB_PATH, JSON.stringify(initial, null, 2), 'utf-8');
      return initial;
    }
    const data = fs.readFileSync(DB_PATH, 'utf-8');
    const db: Database = JSON.parse(data);

    // Migration defaults
    if (!Array.isArray(db.users)) db.users = [];
    if (!Array.isArray(db.authSessions)) db.authSessions = [];
    if (!Array.isArray(db.userSettings)) db.userSettings = [];
    if (!Array.isArray(db.memories)) db.memories = [];
    if (!Array.isArray(db.sessions)) db.sessions = [];

    // Migrate any deprecated models in userSettings
    let dbUpdated = false;
    for (const s of db.userSettings) {
      if (s.preferredModel === 'gemini-2.5-flash' || s.preferredModel === 'gemini-3.5-flash') {
        s.preferredModel = 'gemini-3.8-flash';
        dbUpdated = true;
      }
    }
    if (dbUpdated) {
      writeDb(db);
    }

    // Ensure demo user exists for seamless testing
    if (db.users.length === 0) {
      const demoSaltHash = hashPassword('password123');
      db.users.push({
        id: 'usr-demo-1',
        name: 'مستخدم أونيكس',
        email: 'demo@onyx.ai',
        passwordHash: demoSaltHash.hash,
        salt: demoSaltHash.salt,
        provider: 'email',
        createdAt: Date.now(),
        plan: 'pro',
      });
      db.userSettings.push(getDefaultSettings('usr-demo-1'));
    }

    return db;
  } catch (err) {
    console.error('Error reading database file:', err);
    return {
      users: [],
      authSessions: [],
      userSettings: [],
      memories: [],
      sessions: [],
    };
  }
}

function writeDb(data: Database): void {
  try {
    const tempPath = `${DB_PATH}.tmp`;
    fs.writeFileSync(tempPath, JSON.stringify(data, null, 2), 'utf-8');
    fs.renameSync(tempPath, DB_PATH);
  } catch (err) {
    console.error('Error writing database file:', err);
  }
}

// Authentication Middleware
function getUserIdFromReq(req: express.Request): string | null {
  const authHeader = req.headers.authorization;
  const token = authHeader?.startsWith('Bearer ')
    ? authHeader.slice(7).trim()
    : (req.headers['x-auth-token'] as string) || (req.query.token as string);

  if (!token) return null;

  const db = readDb();
  const session = db.authSessions.find(
    (s) => s.token === token && s.expiresAt > Date.now()
  );
  return session ? session.userId : null;
}

function requireAuth(
  req: express.Request & { userId?: string; user?: UserRecord },
  res: express.Response,
  next: express.NextFunction
) {
  const userId = getUserIdFromReq(req);
  if (!userId) {
    return res.status(401).json({ error: 'جلسة الحساب منتهية أو غير مسجلة. يرجى تسجيل الدخول.' });
  }

  const db = readDb();
  const user = db.users.find((u) => u.id === userId);
  if (!user) {
    return res.status(401).json({ error: 'المستخدم غير موجود.' });
  }

  req.userId = userId;
  req.user = user;
  next();
}

// Initialize Gemini Client
const apiKey = process.env.GEMINI_API_KEY || '';
const ai = new GoogleGenAI({
  apiKey: apiKey,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

// Dynamic System Instructions tailored for OnyxMind AI and User Settings
const BASE_SYSTEM_INSTRUCTION = `أنت "أونيكس مايند" (OnyxMind AI) - مساعد ذكاء اصطناعي فائق التطور، ذكي، سريع الاستجابة، ومتخصص بالدرجة الأولى في التفاعل باللغة العربية الفصحى الأنيقة والمعاصرة مع إتقان جميع اللغات الأخرى.

إرشادات الأداء والهوية:
1. الدقة والسرعة: قدم إجابات محددة، مباشرة، عالية الفائدة والعمق دون إطالة غير مبررة.
2. التنسيق الاحترافي المتطور (Gemini Markdown Standard):
   - العناوين الواضحة: استخدم دائماً العناوين الرئيسية (##) والفرعية (###) لتقسيم الإجابة إلى أقسام منطقية يسهل مسحها بصرياً.
   - الكلمات المفتاحية العريضة: ضع دائماً خطاً عريضاً (**Bold**) على المصطلحات الأساسية، الأرقام المحورية، والنقاط الجوهرية لمنح القارئ سهولة فائقة في قراءة الأفكار بلمحة سريعة.
   - القوائم المنظمة: وظّف القوائم النقطية (*) والرقمية (1.) بدل الكتل النصية المزدحمة، واجعل كل نقطة واضحة ومحددة.
   - الفواصل البصرية: استخدم الفواصل الأفقية (---) للفصل بين الأفكار أو الأقسام الكبرى عند الحاجة.
   - الاقتباسات والملاحظات: استخدم (> Blockquotes) لإبراز التنبيهات، النصائح الذكية، أو الاستنتاجات المهمة.
   - الجداول والأكواد: استخدم الجداول المقارنة عند المفاضلة أو عرض البيانات، والكتل البرمجية (\`\`\`لغة_البرمجة) مع تحديد اسم اللغة دائماً.
   - المسافات والتهوية: اترك سطراً فارغاً بين كل فقرة وعنوان وقائمة لمنع تكدس النصوص وتوفير راحة بصرية تامة.
3. معالجة المستندات وجداول البيانات: عند استلام جداول بيانات (Excel/CSV)، حلل الأرقام، المجموع، المتوسطات، الاتجاهات، والأنماط، وقدم رؤى عملية واستنتاجات ذكية.
4. الرؤية والصور: عند إرفاق صورة، قم بوصفها بدقة، واستخرج النصوص (OCR) إن وجدت، واشرح العناصر الفنية والبيانية.
5. الصوت والحديث: عند التفاعل الصوتي، اجعل العبارات طبيعية وسلسة وممتعة للنطق السمعي.
6. المصداقية: لا تختلق معلومات؛ وإذا طُلب منك البحث المباشر استخدم المعطيات المحدثة.`;

function buildSystemInstruction(userSettings?: UserSettingsRecord, memories?: UserMemoryRecord[]): string {
  let instruction = BASE_SYSTEM_INSTRUCTION;

  if (userSettings) {
    // Response Style Guidance
    switch (userSettings.responseStyle) {
      case 'casual':
        instruction += '\n\n[توجيه أسلوب وشخصية الرد - عفوي]: اجعل الرد طبيعياً، ودوداً، وسلساً بأسلوب مريح وقريب دون تكلف أو رسمية زائدة.';
        break;
      case 'balanced':
        instruction += '\n\n[توجيه أسلوب وشخصية الرد - متوازن]: اجعل الرد واضحاً ومباشراً ومتزناً دون مبالغة في الرسمية أو العفوية، مع توازن دقيق بين الشرح والإيجاز.';
        break;
      case 'formal':
        instruction += '\n\n[توجيه أسلوب وشخصية الرد - رسمي]: استخدم أسلوباً احترافياً وأكاديمياً ومنظماً جداً، مع لغة راقية وصياغة دقيقة ومحكمة.';
        break;
      case 'strict':
        instruction += '\n\n[توجيه أسلوب وشخصية الرد - صارم]: اجعل الرد حاسماً ومباشراً ودقيقاً للغاية، والتزم بالحقائق المجردة وتجنب أي حشو أو مجاملات أو تمهيد غير ضروري.';
        break;
      case 'concise':
        instruction += '\n\n[توجيه أسلوب وشخصية الرد - مختصر]: أعطِ الإجابة المطلوبة بأقل قدر مناسب من الكلام، ركز على النتيجة الفورية والمحددة دون أي إطالة.';
        break;
      case 'detailed':
        instruction += '\n\n[توجيه أسلوب وشخصية الرد - مفصل]: اشرح الموضوع بعمق وتفصيل وافٍ، مع ذكر الخلفيات والخطوات والتحليلات والأمثلة المنظمة عند الحاجة.';
        break;
      default:
        break;
    }

    if (userSettings.defaultLanguage && userSettings.defaultLanguage !== 'العربية') {
      instruction += `\n\n[اللغة المفضلة للرد]: يرجى تقديم الإجابات باللغة (${userSettings.defaultLanguage}) ما لم يحدد المستخدم لغة أخرى في سؤاله.`;
    }

    if (userSettings.customInstructions && userSettings.customInstructions.trim()) {
      instruction += `\n\n[تعليمات وتفضيلات المستخدم المخصصة]:\n${userSettings.customInstructions.trim()}`;
    }
  }

  if (userSettings?.memoryEnabled && memories && memories.length > 0) {
    const memoryList = memories.map((m) => `- ${m.text}`).join('\n');
    instruction += `\n\n[الذاكرة الذكية المحفوظة عن المستخدم]:\n${memoryList}`;
  }

  return instruction;
}

// ======================== AUTHENTICATION ROUTES ========================

// 1. Register with Email & Password
app.post('/api/auth/register', (req, res) => {
  const { name, email, password } = req.body;

  if (!email || !password || !name) {
    return res.status(400).json({ error: 'يرجى إدخال الاسم، البريد الإلكتروني، وكلمة المرور.' });
  }

  if (password.length < 6) {
    return res.status(400).json({ error: 'يجب أن تتكون كلمة المرور من 6 أحرف على الأقل.' });
  }

  const cleanEmail = String(email).trim().toLowerCase();
  const db = readDb();

  const existing = db.users.find((u) => u.email.toLowerCase() === cleanEmail);
  if (existing) {
    return res.status(400).json({ error: 'هذا البريد الإلكتروني مسجل مسبقاً. يرجى تسجيل الدخول.' });
  }

  const { salt, hash } = hashPassword(password);
  const newUser: UserRecord = {
    id: `usr-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
    name: String(name).trim(),
    email: cleanEmail,
    passwordHash: hash,
    salt,
    provider: 'email',
    createdAt: Date.now(),
    plan: 'free',
  };

  db.users.push(newUser);

  // Default settings
  const settings = getDefaultSettings(newUser.id);
  db.userSettings.push(settings);

  // Session Token (Valid for 30 days)
  const token = generateToken();
  db.authSessions.push({
    token,
    userId: newUser.id,
    createdAt: Date.now(),
    expiresAt: Date.now() + 30 * 24 * 60 * 60 * 1000,
  });

  writeDb(db);

  res.json({
    token,
    user: sanitizeUser(newUser),
    settings,
    memories: [],
  });
});

// 2. Login with Email & Password
app.post('/api/auth/login', (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ error: 'يرجى إدخال البريد الإلكتروني وكلمة المرور.' });
  }

  const cleanEmail = String(email).trim().toLowerCase();
  const db = readDb();

  const user = db.users.find((u) => u.email.toLowerCase() === cleanEmail);
  if (!user || !user.passwordHash || !user.salt) {
    return res.status(400).json({ error: 'البريد الإلكتروني أو كلمة المرور غير صحيحة.' });
  }

  const isValid = verifyPassword(password, user.salt, user.passwordHash);
  if (!isValid) {
    return res.status(400).json({ error: 'البريد الإلكتروني أو كلمة المرور غير صحيحة.' });
  }

  // Create new session token
  const token = generateToken();
  db.authSessions.push({
    token,
    userId: user.id,
    createdAt: Date.now(),
    expiresAt: Date.now() + 30 * 24 * 60 * 60 * 1000,
  });

  // Ensure settings exist
  let settings = db.userSettings.find((s) => s.userId === user.id);
  if (!settings) {
    settings = getDefaultSettings(user.id);
    db.userSettings.push(settings);
  }

  const memories = db.memories.filter((m) => m.userId === user.id);
  writeDb(db);

  res.json({
    token,
    user: sanitizeUser(user),
    settings,
    memories,
  });
});

// 3. Google Sign-In / Connect
app.post('/api/auth/google', (req, res) => {
  const { email, name, avatar, googleId } = req.body;

  if (!email) {
    return res.status(400).json({ error: 'بيانات حساب Google غير مكتملة.' });
  }

  const cleanEmail = String(email).trim().toLowerCase();
  const db = readDb();

  let user = db.users.find((u) => u.email.toLowerCase() === cleanEmail);
  if (!user) {
    user = {
      id: `usr-g-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
      name: name || 'مستخدم Google',
      email: cleanEmail,
      avatar: avatar || undefined,
      provider: 'google',
      createdAt: Date.now(),
      plan: 'free',
    };
    db.users.push(user);
    db.userSettings.push(getDefaultSettings(user.id));
  } else {
    // Update avatar or name if provided from Google
    if (avatar && !user.avatar) user.avatar = avatar;
    if (name && !user.name) user.name = name;
  }

  const token = generateToken();
  db.authSessions.push({
    token,
    userId: user.id,
    createdAt: Date.now(),
    expiresAt: Date.now() + 30 * 24 * 60 * 60 * 1000,
  });

  let settings = db.userSettings.find((s) => s.userId === user.id);
  if (!settings) {
    settings = getDefaultSettings(user.id);
    db.userSettings.push(settings);
  }

  const memories = db.memories.filter((m) => m.userId === user.id);
  writeDb(db);

  res.json({
    token,
    user: sanitizeUser(user),
    settings,
    memories,
  });
});

// 4. Verify & Get Current User Profile (Auto-Login verification)
app.get('/api/auth/me', requireAuth, (req: any, res) => {
  const db = readDb();
  let settings = db.userSettings.find((s) => s.userId === req.userId);
  if (!settings) {
    settings = getDefaultSettings(req.userId);
    db.userSettings.push(settings);
    writeDb(db);
  }

  const memories = db.memories.filter((m) => m.userId === req.userId);
  res.json({
    user: sanitizeUser(req.user),
    settings,
    memories,
  });
});

// 5. Logout
app.post('/api/auth/logout', (req, res) => {
  const authHeader = req.headers.authorization;
  const token = authHeader?.startsWith('Bearer ') ? authHeader.slice(7).trim() : null;

  if (token) {
    const db = readDb();
    db.authSessions = db.authSessions.filter((s) => s.token !== token);
    writeDb(db);
  }

  res.json({ success: true, message: 'تم تسجيل الخروج بنجاح.' });
});

// 6. Update Profile
app.put('/api/auth/profile', requireAuth, (req: any, res) => {
  const { name, avatar } = req.body;
  const db = readDb();
  const user = db.users.find((u) => u.id === req.userId);

  if (!user) {
    return res.status(404).json({ error: 'المستخدم غير موجود' });
  }

  if (name && typeof name === 'string') {
    user.name = name.trim();
  }
  if (avatar !== undefined) {
    user.avatar = avatar;
  }

  writeDb(db);
  res.json({ user: sanitizeUser(user) });
});

// 7. Delete Account Permanently
app.delete('/api/auth/account', requireAuth, (req: any, res) => {
  const userId = req.userId;
  const db = readDb();

  // Remove user, sessions, settings, memories, and chats
  db.users = db.users.filter((u) => u.id !== userId);
  db.authSessions = db.authSessions.filter((s) => s.userId !== userId);
  db.userSettings = db.userSettings.filter((s) => s.userId !== userId);
  db.memories = db.memories.filter((m) => m.userId !== userId);
  db.sessions = db.sessions.filter((s) => s.userId !== userId);

  writeDb(db);
  res.json({ success: true, message: 'تم حذف الحساب وجميع بياناته بنجاح.' });
});

// ======================== USER SETTINGS & MEMORIES ROUTES ========================

app.get('/api/user/settings', requireAuth, (req: any, res) => {
  const db = readDb();
  let settings = db.userSettings.find((s) => s.userId === req.userId);
  if (!settings) {
    settings = getDefaultSettings(req.userId);
    db.userSettings.push(settings);
    writeDb(db);
  }
  res.json({ settings });
});

app.put('/api/user/settings', requireAuth, (req: any, res) => {
  const db = readDb();
  let index = db.userSettings.findIndex((s) => s.userId === req.userId);

  if (index >= 0) {
    db.userSettings[index] = { ...db.userSettings[index], ...req.body, userId: req.userId };
  } else {
    const newSettings = { ...getDefaultSettings(req.userId), ...req.body, userId: req.userId };
    db.userSettings.push(newSettings);
    index = db.userSettings.length - 1;
  }

  writeDb(db);
  res.json({ success: true, settings: db.userSettings[index] });
});

app.get('/api/user/memories', requireAuth, (req: any, res) => {
  const db = readDb();
  const memories = db.memories.filter((m) => m.userId === req.userId);
  res.json({ memories });
});

app.post('/api/user/memories', requireAuth, (req: any, res) => {
  const { text } = req.body;
  if (!text || !String(text).trim()) {
    return res.status(400).json({ error: 'نص الذكرى مطلوب.' });
  }

  const db = readDb();
  const memory: UserMemoryRecord = {
    id: `mem-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
    userId: req.userId,
    text: String(text).trim(),
    createdAt: Date.now(),
  };

  db.memories.push(memory);
  writeDb(db);
  res.json({ success: true, memory });
});

app.delete('/api/user/memories/:id', requireAuth, (req: any, res) => {
  const { id } = req.params;
  const db = readDb();
  db.memories = db.memories.filter((m) => !(m.id === id && m.userId === req.userId));
  writeDb(db);
  res.json({ success: true });
});

app.delete('/api/user/memories', requireAuth, (req: any, res) => {
  const db = readDb();
  db.memories = db.memories.filter((m) => m.userId !== req.userId);
  writeDb(db);
  res.json({ success: true, message: 'تم مسح كافة الذكريات بنجاح.' });
});

// Export all user data (Privacy & Data compliance)
app.get('/api/user/export', requireAuth, (req: any, res) => {
  const db = readDb();
  const user = db.users.find((u) => u.id === req.userId);
  const settings = db.userSettings.find((s) => s.userId === req.userId);
  const memories = db.memories.filter((m) => m.userId === req.userId);
  const chats = db.sessions.filter((s) => s.userId === req.userId);

  res.json({
    exportDate: new Date().toISOString(),
    account: user ? sanitizeUser(user) : null,
    settings: settings || null,
    memories,
    chats,
  });
});

// ======================== SCOPED CHAT ROUTES ========================

app.get('/api/chats', (req, res) => {
  const userId = getUserIdFromReq(req) || 'usr-demo-1';
  const db = readDb();
  // Filter sessions strictly belonging to the current user
  const userSessions = db.sessions.filter(
    (s) => s.userId === userId || (!s.userId && userId === 'usr-demo-1')
  );
  res.json(userSessions);
});

app.post('/api/chats', (req, res) => {
  const userId = getUserIdFromReq(req) || 'usr-demo-1';
  const db = readDb();
  const newSession: ChatSession = { ...req.body, userId };

  if (!newSession || !newSession.id) {
    return res.status(400).json({ error: 'Session ID is required' });
  }

  const existingIndex = db.sessions.findIndex(
    (s) => s.id === newSession.id && (s.userId === userId || !s.userId)
  );

  if (existingIndex >= 0) {
    db.sessions[existingIndex] = { ...db.sessions[existingIndex], ...newSession, userId };
  } else {
    db.sessions.unshift(newSession);
  }

  writeDb(db);
  res.json(newSession);
});

app.post('/api/chats/:id/sync', (req, res) => {
  const { id } = req.params;
  const { messages, title } = req.body;
  const userId = getUserIdFromReq(req) || 'usr-demo-1';
  const db = readDb();

  let session = db.sessions.find((s) => s.id === id && (s.userId === userId || !s.userId));
  if (session) {
    session.userId = userId;
    if (Array.isArray(messages)) session.messages = messages;
    if (title) session.title = title;
    session.updatedAt = Date.now();
  } else {
    session = {
      id,
      userId,
      title: title || 'محادثة جديدة',
      createdAt: Date.now(),
      updatedAt: Date.now(),
      messages: Array.isArray(messages) ? messages : [],
    };
    db.sessions.unshift(session);
  }

  writeDb(db);
  res.json({ success: true, session });
});

// Automatic Chat Title Generation using Gemini
app.post('/api/chats/:id/title', async (req, res) => {
  const { id } = req.params;
  const { prompt } = req.body;
  const userId = getUserIdFromReq(req) || 'usr-demo-1';

  if (!prompt || typeof prompt !== 'string') {
    return res.status(400).json({ error: 'Prompt is required' });
  }

  try {
    const titlePrompt = `قم بتلخيص موضوع هذه الرسالة في عنوان موجز وجذاب في حدود 3 إلى 5 كلمات فقط بنفس لغة الرسالة (بدون علامات تنصيص، بدون نقطة، وبدون مقدمات):\n"${prompt.slice(0, 300)}"`;
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: titlePrompt,
    });

    let generatedTitle = response.text ? response.text.trim().replace(/^["']|["']$/g, '').slice(0, 50) : prompt.slice(0, 30);
    if (!generatedTitle) generatedTitle = prompt.slice(0, 30);

    const db = readDb();
    const session = db.sessions.find((s) => s.id === id && (s.userId === userId || !s.userId));
    if (session) {
      session.title = generatedTitle;
      session.updatedAt = Date.now();
      writeDb(db);
    }

    res.json({ title: generatedTitle });
  } catch (err: any) {
    const fallbackTitle = prompt.slice(0, 30);
    res.json({ title: fallbackTitle });
  }
});


app.delete('/api/chats', (req, res) => {
  const userId = getUserIdFromReq(req) || 'usr-demo-1';
  const db = readDb();
  db.sessions = db.sessions.filter((s) => s.userId !== userId && s.userId !== undefined);
  writeDb(db);
  res.json({ success: true, message: 'All user sessions wiped permanently' });
});

app.delete('/api/chats/:id', (req, res) => {
  const { id } = req.params;
  const userId = getUserIdFromReq(req) || 'usr-demo-1';
  const db = readDb();
  db.sessions = db.sessions.filter((s) => !(s.id === id && (s.userId === userId || !s.userId)));
  writeDb(db);
  res.json({ success: true, message: 'Session deleted successfully' });
});

app.delete('/api/chats/:id/messages/:messageId', (req, res) => {
  const { id, messageId } = req.params;
  const userId = getUserIdFromReq(req) || 'usr-demo-1';
  const db = readDb();
  const session = db.sessions.find((s) => s.id === id && (s.userId === userId || !s.userId));
  if (session) {
    session.messages = session.messages.filter((m) => m.id !== messageId);
    session.updatedAt = Date.now();
    writeDb(db);
  }
  res.json({ success: true });
});

app.delete('/api/chats/:id/messages', (req, res) => {
  const { id } = req.params;
  const userId = getUserIdFromReq(req) || 'usr-demo-1';
  const db = readDb();
  const session = db.sessions.find((s) => s.id === id && (s.userId === userId || !s.userId));
  if (session) {
    session.messages = [];
    session.updatedAt = Date.now();
    writeDb(db);
  }
  res.json({ success: true });
});

// Helper to construct Gemini content parts
function formatMessagesForGemini(messages: Message[]) {
  return messages.map((msg) => {
    const parts: any[] = [];

    // Add attachments if any
    if (msg.attachments && msg.attachments.length > 0) {
      for (const att of msg.attachments) {
        if (att.type === 'image' && att.dataUrl) {
          const rawBase64 = att.dataUrl.includes(',') ? att.dataUrl.split(',')[1] : att.dataUrl;
          parts.push({
            inlineData: {
              mimeType: att.mimeType || 'image/jpeg',
              data: rawBase64,
            },
          });
        } else if ((att.type === 'excel' || att.type === 'csv') && att.sheetData?.summary) {
          parts.push({
            text: `[محتوى جدول بيانات مرفق: ${att.name}]\n${att.sheetData.summary}`,
          });
        } else if (att.type === 'pdf' || att.name?.toLowerCase().endsWith('.pdf') || att.mimeType === 'application/pdf') {
          if (att.dataUrl) {
            const rawBase64 = att.dataUrl.includes(',') ? att.dataUrl.split(',')[1] : att.dataUrl;
            parts.push({
              inlineData: {
                mimeType: 'application/pdf',
                data: rawBase64,
              },
            });
          }
        } else if (att.type === 'apk' || att.name?.toLowerCase().endsWith('.apk')) {
          const apkDetails = att.textContent || (att.dataUrl && !att.dataUrl.startsWith('data:') ? att.dataUrl : `ملف حزمة تطبيق أندرويد: ${att.name}`);
          parts.push({
            text: `[فحص وتحليل حزمة تطبيق أندرويد APK: ${att.name}]\n${apkDetails}`,
          });
        } else if (att.type === 'document' || att.type === 'binary' || att.textContent || (att.dataUrl && !att.dataUrl.startsWith('data:image/'))) {
          const content = att.textContent || (att.dataUrl && !att.dataUrl.startsWith('data:') ? att.dataUrl : '');
          if (content) {
            parts.push({
              text: `[محتوى ملف مرفق: ${att.name}]\n${content.slice(0, 80000)}`,
            });
          } else {
            parts.push({
              text: `[ملف مرفق: ${att.name}، الحجم: ${att.size} بايت]`,
            });
          }
        }
      }
    }

    if (msg.content && msg.content.trim()) {
      parts.push({ text: msg.content.trim() });
    } else if (parts.length > 0) {
      // Auto-prompt when user only sends attachments without text
      parts.push({
        text: 'يرجى تحليل وفحص هذا المرفق بعناية ودقة، وشرح أهم ما يحتويه واستخراج المعلومات الأساسية منه بوضوح باللغة العربية.',
      });
    }

    if (parts.length === 0) {
      parts.push({ text: 'مرحباً' });
    }

    return {
      role: msg.role === 'assistant' ? 'model' : 'user',
      parts,
    };
  });
}

// Audio Transcription Endpoint using gemini-3.5-transcribe
app.post('/api/transcribe', async (req, res) => {
  try {
    const { audio, mimeType } = req.body;
    if (!audio) {
      return res.status(400).json({ error: 'بيانات الصوت مطلوبة' });
    }

    const cleanBase64 = audio.includes(',') ? audio.split(',')[1] : audio;
    const cleanMime = (mimeType || 'audio/webm').split(';')[0];

    const audioPart = {
      inlineData: {
        mimeType: cleanMime,
        data: cleanBase64,
      },
    };

    const textPart = {
      text: 'Transcribe this audio recording into clean, accurate text. If spoken in Arabic, transcribe it in fluent Arabic with proper orthography and punctuation. Return only the transcription text without commentary.',
    };

    const response = await ai.models.generateContent({
      model: 'gemini-3.5-transcribe',
      contents: { parts: [audioPart, textPart] },
    });

    const transcription = response.text?.trim() || '';
    res.json({ text: transcription });
  } catch (error: any) {
    console.error('Transcription error:', error);
    res.status(500).json({ error: error.message || 'فشل في تحويل الصوت إلى نص' });
  }
});

// In-memory cache for server-side synthesized audio to preserve quota
const ttsAudioServerCache = new Map<string, string>();

// Text to Speech Endpoint using gemini-3.8-flash-tts with graceful quota fallback
app.post('/api/tts', async (req, res) => {
  try {
    const { text, voice = 'Aoede' } = req.body;
    if (!text || !String(text).trim()) {
      return res.status(400).json({ error: 'النص المطلوب نطقه غير موجود' });
    }

    const cleanText = String(text).trim();
    const cacheKey = `${voice}:::${cleanText}`;

    if (ttsAudioServerCache.has(cacheKey)) {
      return res.json({ audioUrl: ttsAudioServerCache.get(cacheKey) });
    }

    let base64Audio = '';
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash-tts',
        contents: [
          {
            role: 'user',
            parts: [
              {
                text: cleanText,
                speechMetadata: {
                  style: 'Natural, warm, engaging voice speaking Arabic clearly',
                },
              },
            ],
          },
        ],
        config: {
          responseModalities: ['AUDIO'],
          speechConfig: {
            voiceConfig: {
              prebuiltVoiceConfig: { voiceName: voice },
            },
          },
        },
      });

      base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data || '';
    } catch (ttsErr: any) {
      const isQuotaErr = String(ttsErr?.message || '').includes('429') ||
                         String(ttsErr?.message || '').includes('RESOURCE_EXHAUSTED') ||
                         String(ttsErr?.message || '').includes('Quota exceeded');

      if (!isQuotaErr) {
        try {
          const fallback = await ai.models.generateContent({
            model: 'gemini-3.8-flash-lite-tts',
            contents: [{ role: 'user', parts: [{ text: cleanText }] }],
            config: {
              responseModalities: ['AUDIO'],
              speechConfig: {
                voiceConfig: {
                  prebuiltVoiceConfig: { voiceName: voice },
                },
              },
            },
          });
          base64Audio = fallback.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data || '';
        } catch (liteErr: any) {
          throw liteErr;
        }
      } else {
        throw ttsErr;
      }
    }

    if (!base64Audio) {
      return res.status(500).json({ error: 'لم يتم استلام ملف صوتي من النموذج' });
    }

    const audioUrl = `data:audio/wav;base64,${base64Audio}`;
    // Store in cache (limit cache to 200 items)
    if (ttsAudioServerCache.size > 200) {
      const firstKey = ttsAudioServerCache.keys().next().value;
      if (firstKey) ttsAudioServerCache.delete(firstKey);
    }
    ttsAudioServerCache.set(cacheKey, audioUrl);

    res.json({ audioUrl });
  } catch (error: any) {
    const errMsg = String(error?.message || '');
    const isQuota = errMsg.includes('429') ||
                    errMsg.includes('RESOURCE_EXHAUSTED') ||
                    errMsg.includes('Quota exceeded');

    if (isQuota) {
      return res.status(429).json({
        quotaExceeded: true,
        error: 'QUOTA_EXCEEDED',
        message: 'تم استهلاك الحصة المجانية لنموذج الصوت السحابي (10 طلبات يومياً)',
      });
    }

    console.warn('TTS generation warning:', errMsg);
    res.status(500).json({ error: 'فشل في توليد الصوت السحابي' });
  }
});

// Streaming TTS Endpoint: returns ReadableStream / SSE of chunks for instant start on first chunk
app.post('/api/tts/stream', async (req, res) => {
  const { text, voice = 'Aoede' } = req.body;
  if (!text || !String(text).trim()) {
    return res.status(400).json({ error: 'النص المطلوب نطقه غير موجود' });
  }

  const cleanText = String(text).trim();

  res.setHeader('Content-Type', 'text/event-stream; charset=utf-8');
  res.setHeader('Cache-Control', 'no-cache, no-transform');
  res.setHeader('Connection', 'keep-alive');
  res.flushHeaders?.();

  const sendEvent = (event: string, data: any) => {
    res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`);
  };

  try {
    // Stream audio using gemini-3.8-flash-tts generateContentStream
    const responseStream = await ai.models.generateContentStream({
      model: 'gemini-3.8-flash-tts',
      contents: [
        {
          role: 'user',
          parts: [
            {
              text: cleanText,
              speechMetadata: {
                style: 'Natural, warm, engaging voice speaking Arabic clearly',
              },
            },
          ],
        },
      ],
      config: {
        responseModalities: ['AUDIO'],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: voice },
          },
        },
      },
    });

    for await (const chunk of responseStream) {
      const audioData = chunk.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
      if (audioData) {
        sendEvent('chunk', { audioChunk: audioData });
      }
    }

    sendEvent('done', {});
    res.end();
  } catch (error: any) {
    const errMsg = String(error?.message || '');
    const isQuota = errMsg.includes('429') ||
                    errMsg.includes('RESOURCE_EXHAUSTED') ||
                    errMsg.includes('Quota exceeded');
    if (isQuota) {
      sendEvent('error', { quotaExceeded: true, error: 'QUOTA_EXCEEDED' });
    } else {
      sendEvent('error', { error: errMsg || 'TTS stream failed' });
    }
    res.end();
  }
});

// Image Generation Endpoint (nano banana series: gemini-3.1-flash-image / gemini-3.1-flash-lite-image)
app.post('/api/generate-image', async (req, res) => {
  try {
    const {
      prompt,
      aspectRatio = '1:1',
      imageSize = '1K',
      style = 'Digital Art',
      negativePrompt,
    } = req.body;

    if (!prompt) {
      return res.status(400).json({ error: 'يرجى كتابة وصف الصورة المطلوب توليدها' });
    }

    // Enhance prompt with style
    let enhancedPrompt = prompt;
    if (style && style !== 'None' && style !== 'افتراضي') {
      enhancedPrompt = `${prompt}, styled in ${style} aesthetic, high detail, masterpiece, 8k quality, centered composition.`;
    }
    if (negativePrompt) {
      enhancedPrompt += ` (Exclude: ${negativePrompt})`;
    }

    let generatedImages: { url: string; prompt: string; aspectRatio: string; timestamp: number }[] = [];

    // Attempt generation with gemini-3.1-flash-image
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3.1-flash-image',
        contents: {
          parts: [{ text: enhancedPrompt }],
        },
        config: {
          imageConfig: {
            aspectRatio: aspectRatio as any,
            imageSize: imageSize as any,
          },
        },
      });

      if (response.candidates?.[0]?.content?.parts) {
        for (const part of response.candidates[0].content.parts) {
          if (part.inlineData?.data) {
            const mime = part.inlineData.mimeType || 'image/png';
            generatedImages.push({
              url: `data:${mime};base64,${part.inlineData.data}`,
              prompt,
              aspectRatio,
              timestamp: Date.now(),
            });
          }
        }
      }
    } catch (primaryErr: any) {
      console.warn('Falling back to gemini-3.1-flash-lite-image:', primaryErr.message);
      const fallbackResponse = await ai.models.generateContent({
        model: 'gemini-3.1-flash-lite-image',
        contents: {
          parts: [{ text: enhancedPrompt }],
        },
        config: {
          imageConfig: {
            aspectRatio: aspectRatio as any,
          },
        },
      });

      if (fallbackResponse.candidates?.[0]?.content?.parts) {
        for (const part of fallbackResponse.candidates[0].content.parts) {
          if (part.inlineData?.data) {
            const mime = part.inlineData.mimeType || 'image/png';
            generatedImages.push({
              url: `data:${mime};base64,${part.inlineData.data}`,
              prompt,
              aspectRatio,
              timestamp: Date.now(),
            });
          }
        }
      }
    }

    if (generatedImages.length === 0) {
      return res.status(500).json({ error: 'لم يرجع النموذج أية صورة مطابقة' });
    }

    res.json({ images: generatedImages });
  } catch (error: any) {
    console.error('Image Generation error:', error);
    res.status(500).json({ error: error.message || 'فشل في توليد الصورة' });
  }
});

// SSE Streaming Route for HTTP Clients - Fast Real-Time Token Stream
app.post('/api/chat/stream', async (req, res) => {
  const { messages, model = 'gemini-3.8-flash', useSearch = false, thinking = false } = req.body;

  res.setHeader('Content-Type', 'text/event-stream; charset=utf-8');
  res.setHeader('Cache-Control', 'no-cache, no-transform');
  res.setHeader('Connection', 'keep-alive');
  res.setHeader('X-Accel-Buffering', 'no'); // Disable proxy buffering for instant delivery
  res.flushHeaders?.();

  const sendEvent = (event: string, data: any) => {
    res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`);
    if (typeof (res as any).flush === 'function') {
      (res as any).flush();
    }
  };

  try {
    const formattedContents = formatMessagesForGemini(messages || []);
    const userId = getUserIdFromReq(req);
    const db = readDb();
    let userSettings = userId ? db.userSettings.find((s) => s.userId === userId) : undefined;
    if (req.body.userSettings) {
      userSettings = { ...(userSettings || getDefaultSettings(userId || 'guest')), ...req.body.userSettings };
    }
    const memories = userId ? db.memories.filter((m) => m.userId === userId) : undefined;

    const config: any = {
      systemInstruction: buildSystemInstruction(userSettings, memories),
    };

    // Automatically enable Google Search tool based on the user's question without any visible UI toggle
    const lastUserMsg = (messages && messages.length > 0) ? messages[messages.length - 1] : null;
    const userPromptText = lastUserMsg?.content || '';
    const shouldAutoSearch = useSearch || isSearchRelevant(userPromptText);

    if (shouldAutoSearch) {
      config.tools = [{ googleSearch: {} }];
    }

    if (thinking && model === 'gemini-3.1-pro-preview') {
      config.thinkingConfig = { thinkingLevel: ThinkingLevel.HIGH };
    } else {
      config.thinkingConfig = { thinkingBudget: 0 };
    }

    const targetModel = normalizeModel(model || 'gemini-3.8-flash');

    const responseStream = await ai.models.generateContentStream({
      model: targetModel,
      contents: formattedContents,
      config,
    });

    let clientDisconnected = false;
    req.on('close', () => {
      clientDisconnected = true;
    });

    for await (const chunk of responseStream) {
      if (clientDisconnected) {
        break;
      }
      const text = chunk.text;
      if (text) {
        sendEvent('token', { text });
      }

      // Check for grounding metadata
      const candidate = chunk.candidates?.[0];
      const grounding = candidate?.groundingMetadata?.groundingChunks;
      if (grounding && grounding.length > 0) {
        const sources = grounding.map((g: any) => ({
          title: g.web?.title || 'مصدر خارجي',
          url: g.web?.uri || '',
        }));
        sendEvent('grounding', { sources });
      }
    }

    sendEvent('done', { ok: true });
    res.end();
  } catch (error: any) {
    if (error.message?.includes('Incomplete JSON segment')) {
      sendEvent('done', { ok: true });
      return res.end();
    }
    console.error('SSE Chat Error:', error);
    sendEvent('error', { message: error.message || 'حدث خطأ أثناء المعالجة' });
    res.end();
  }
});

// WebSocket Servers:
// 1. chatWss on /ws for token-by-token text streaming
// 2. liveWss on /live for real-time duplex voice conversations using Gemini 3.8 Live (Live API)
const chatWss = new WebSocketServer({ noServer: true });
const liveWss = new WebSocketServer({ noServer: true });

// Route HTTP Upgrade requests to the respective WebSocketServer
server.on('upgrade', (request, socket, head) => {
  const url = request.url || '';
  const pathname = url.split('?')[0];

  if (pathname === '/live') {
    liveWss.handleUpgrade(request, socket, head, (ws) => {
      liveWss.emit('connection', ws, request);
    });
  } else if (pathname === '/ws') {
    chatWss.handleUpgrade(request, socket, head, (ws) => {
      chatWss.emit('connection', ws, request);
    });
  }
});

// =========================================================================
// Real-Time Gemini 3.8 Live API Session Handler (/live)
// =========================================================================
liveWss.on('connection', async (clientWs: WebSocket) => {
  let liveSession: any = null;
  let isClosed = false;

  const closeLiveSession = () => {
    if (liveSession) {
      try {
        liveSession.close();
      } catch (e) {
        // ignore
      }
      liveSession = null;
    }
  };

  clientWs.on('close', () => {
    isClosed = true;
    closeLiveSession();
  });

  clientWs.on('error', (err) => {
    console.error('Client WS live error:', err);
    isClosed = true;
    closeLiveSession();
  });

  clientWs.on('message', async (data) => {
    try {
      const payload = JSON.parse(data.toString());

      if (payload.type === 'init') {
        closeLiveSession();

        const voice = payload.voiceName || 'Zephyr';
        const systemInstruction = payload.systemInstruction ||
          "You are OnyxMind AI, an intelligent, real-time voice assistant. You converse naturally, warmly, and concisely. Keep answers brief, natural, and directly suited for spoken dialogue. Respond fluently in the language the user speaks to you (Arabic or English).";

        try {
          liveSession = await ai.live.connect({
            model: "gemini-3.8-live",
            config: {
              responseModalities: [Modality.AUDIO],
              speechConfig: {
                voiceConfig: { prebuiltVoiceConfig: { voiceName: voice } },
              },
              systemInstruction,
            },
            callbacks: {
              onopen: () => {
                if (!isClosed && clientWs.readyState === WebSocket.OPEN) {
                  clientWs.send(JSON.stringify({ type: 'ready' }));
                }
              },
              onmessage: (message: LiveServerMessage) => {
                if (isClosed || clientWs.readyState !== WebSocket.OPEN) return;

                const parts = message.serverContent?.modelTurn?.parts;
                if (parts) {
                  for (const part of parts) {
                    if (part.inlineData?.data) {
                      clientWs.send(JSON.stringify({ type: 'audio', audio: part.inlineData.data }));
                    }
                    if (part.text) {
                      clientWs.send(JSON.stringify({ type: 'text', text: part.text }));
                    }
                  }
                }

                // Barge-in interruption signal from Gemini
                if (message.serverContent?.interrupted) {
                  clientWs.send(JSON.stringify({ type: 'interrupted', interrupted: true }));
                }

                if (message.serverContent?.turnComplete) {
                  clientWs.send(JSON.stringify({ type: 'turnComplete' }));
                }
              },
              onerror: (err: any) => {
                console.error('Gemini Live API error:', err);
                if (!isClosed && clientWs.readyState === WebSocket.OPEN) {
                  clientWs.send(JSON.stringify({
                    type: 'error',
                    message: err?.message || 'حدث خطأ في جلسة Gemini Live',
                  }));
                }
              },
              onclose: () => {
                if (!isClosed && clientWs.readyState === WebSocket.OPEN) {
                  clientWs.send(JSON.stringify({ type: 'closed' }));
                }
              },
            },
          });
        } catch (initErr: any) {
          console.error('Failed to connect to gemini-3.8-live:', initErr);
          if (!isClosed && clientWs.readyState === WebSocket.OPEN) {
            clientWs.send(JSON.stringify({
              type: 'error',
              message: initErr?.message || 'تعذر بدء المحادثة مع نموذج gemini-3.8-live',
            }));
          }
        }
        return;
      }

      if (payload.type === 'audio' && payload.audio && liveSession) {
        liveSession.sendRealtimeInput({
          audio: {
            data: payload.audio,
            mimeType: 'audio/pcm;rate=16000',
          },
        });
        return;
      }

      if (payload.type === 'text' && payload.text && liveSession) {
        liveSession.sendClientContent({
          turns: [{ role: 'user', parts: [{ text: payload.text }] }],
          turnComplete: true,
        });
        return;
      }

      if (payload.type === 'stop' && liveSession) {
        closeLiveSession();
        return;
      }
    } catch (msgErr: any) {
      console.error('Error handling live message:', msgErr);
    }
  });
});

// Track abort requests per chatId for /ws
const activeWsStreams = new Map<string, { abort: boolean }>();

chatWss.on('connection', (ws: WebSocket) => {
  ws.on('message', async (data) => {
    try {
      const payload = JSON.parse(data.toString());

      if (payload.type === 'ping') {
        return ws.send(JSON.stringify({ type: 'pong' }));
      }

      if (payload.type === 'stop') {
        const targetChatId = payload.chatId || 'active';
        if (activeWsStreams.has(targetChatId)) {
          activeWsStreams.get(targetChatId)!.abort = true;
        }
        return;
      }

      if (payload.type === 'chat') {
        const {
          messages,
          model = 'gemini-3.1-flash-lite',
          useSearch = false,
          thinking = false,
          chatId,
        } = payload;

        const streamControl = { abort: false };
        const activeKey = chatId || 'active';
        activeWsStreams.set(activeKey, streamControl);

        const formattedContents = formatMessagesForGemini(messages || []);
        const db = readDb();
        const userId = payload.token
          ? db.authSessions.find((s) => s.token === payload.token && s.expiresAt > Date.now())?.userId
          : null;
        let userSettings = userId ? db.userSettings.find((s) => s.userId === userId) : undefined;
        if (payload.userSettings) {
          userSettings = { ...(userSettings || getDefaultSettings(userId || 'guest')), ...payload.userSettings };
        }
        const memories = userId ? db.memories.filter((m) => m.userId === userId) : undefined;

        const config: any = {
          systemInstruction: buildSystemInstruction(userSettings, memories),
        };

        // Automatically enable Google Search tool based on the user's question without any visible UI toggle
        const lastUserMsg = (messages && messages.length > 0) ? messages[messages.length - 1] : null;
        const userPromptText = lastUserMsg?.content || '';
        const shouldAutoSearch = useSearch || isSearchRelevant(userPromptText);

        if (shouldAutoSearch) {
          config.tools = [{ googleSearch: {} }];
        }

        if (thinking && model === 'gemini-3.1-pro-preview') {
          config.thinkingConfig = { thinkingLevel: ThinkingLevel.HIGH };
        } else {
          config.thinkingConfig = { thinkingBudget: 0 };
        }

        // Stream tokens immediately token by token from the very first word!
        const targetModel = normalizeModel(model || 'gemini-3.8-flash');
        const responseStream = await ai.models.generateContentStream({
          model: targetModel,
          contents: formattedContents,
          config,
        });

        let fullText = '';
        let groundingSources: any[] = [];

        try {
          for await (const chunk of responseStream) {
            if (streamControl.abort) {
              break;
            }

            const text = chunk.text;
            if (text) {
              fullText += text;
              ws.send(JSON.stringify({ type: 'token', text, chatId }));
            }

            const candidate = chunk.candidates?.[0];
            const grounding = candidate?.groundingMetadata?.groundingChunks;
            if (grounding && grounding.length > 0) {
              const sources = grounding.map((g: any) => ({
                title: g.web?.title || 'مصدر خارجي',
                url: g.web?.uri || '',
              }));
              groundingSources.push(...sources);
              ws.send(JSON.stringify({ type: 'grounding', sources, chatId }));
            }
          }
        } catch (streamIterErr: any) {
          if (!streamIterErr.message?.includes('Incomplete JSON segment')) {
            throw streamIterErr;
          }
        } finally {
          activeWsStreams.delete(activeKey);
        }

        ws.send(JSON.stringify({
          type: 'done',
          fullText,
          sources: groundingSources,
          chatId,
        }));
      }
    } catch (err: any) {
      console.error('WebSocket Error:', err);
      ws.send(JSON.stringify({
        type: 'error',
        message: err.message || 'حدث خطأ في معالجة طلب البث',
      }));
    }
  });
});

// Setup Vite middleware in dev or static files in production
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(process.cwd(), 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(process.cwd(), 'dist', 'index.html'));
    });
  }

  server.listen(port, '0.0.0.0', () => {
    console.log(`OnyxMind Server running on http://0.0.0.0:${port}`);
  });
}

startServer().catch(console.error);
