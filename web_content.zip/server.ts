import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT) : 3000;

app.use(express.json());

// Initialize Gemini SDK if API key is present
const apiKey = process.env.GEMINI_API_KEY;
let aiClient: GoogleGenAI | null = null;
if (apiKey && apiKey !== 'MY_GEMINI_API_KEY') {
  try {
    aiClient = new GoogleGenAI({ apiKey });
  } catch (err) {
    console.warn('Failed to initialize GoogleGenAI:', err);
  }
}

// Jarvis AI Intent & Action Dispatcher Endpoint
app.post('/api/jarvis', async (req, res) => {
  const { prompt, context } = req.body;

  if (!prompt || typeof prompt !== 'string') {
    return res.status(400).json({ error: 'Prompt is required' });
  }

  // System instruction for JARVIS
  const systemInstruction = `You are J.A.R.V.I.S., Tony Stark's advanced AI operating system, now integrated seamlessly into the user's Android phone.
Current local time is: ${context?.currentTime || new Date().toISOString()}.

User Request: "${prompt}"

Current Calendar Events: ${JSON.stringify(context?.events || [])}
Current Reminders: ${JSON.stringify(context?.reminders || [])}
Current Device Settings: ${JSON.stringify(context?.settings || {})}

Your goal is to parse user instructions accurately, sound like Jarvis (sophisticated, British polite, witty, concise), and return a strictly valid JSON object matching this schema:
{
  "speechText": "Spoken acknowledgment or answer (concise, crisp, authentic Jarvis)",
  "action": {
    "type": "ADD_EVENT" | "MODIFY_EVENT" | "DELETE_EVENT" | "ADD_REMINDER" | "MODIFY_REMINDER" | "DELETE_REMINDER" | "MAKE_CALL" | "SEND_MESSAGE" | "OPEN_APP" | "TOGGLE_SETTING" | "BRIEFING" | "QUERY_SCHEDULE" | "GENERAL_RESPONSE",
    "payload": {
      // For ADD_EVENT: { "id"?: string, "title": string, "startTime": "YYYY-MM-DDTHH:mm", "endTime"?: "YYYY-MM-DDTHH:mm", "location"?: string, "category"?: "work"|"personal"|"ops"|"health", "priority"?: "low"|"normal"|"high" }
      // For MODIFY_EVENT: { "targetQuery": string, "updatedFields": { ... } }
      // For DELETE_EVENT: { "targetQuery": string }
      // For ADD_REMINDER: { "id"?: string, "title": string, "dueTime": "YYYY-MM-DDTHH:mm" | null, "priority"?: "normal"|"urgent", "category"?: string }
      // For MODIFY_REMINDER: { "targetQuery": string, "completed"?: boolean, "updatedFields": { ... } }
      // For DELETE_REMINDER: { "targetQuery": string }
      // For MAKE_CALL: { "contactName": string, "phoneNumber": string }
      // For SEND_MESSAGE: { "contactName": string, "phoneNumber": string, "message": string, "app": "sms" | "whatsapp" }
      // For OPEN_APP: { "appName": string, "appId": string }
      // For TOGGLE_SETTING: { "setting": "flashlight"|"vibration"|"soundMode"|"nightMode"|"batterySaver"|"dnd", "value"?: any }
      // For BRIEFING: { "agendaSummary": string, "deviceStatus": string }
    }
  }
}
Return ONLY valid raw JSON with NO markdown code blocks.`;

  try {
    if (aiClient) {
      const response = await aiClient.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: prompt,
        config: {
          systemInstruction,
          responseMimeType: 'application/json',
          temperature: 0.2,
        },
      });

      const responseText = response.text || '{}';
      try {
        const parsed = JSON.parse(responseText);
        return res.json(parsed);
      } catch (jsonErr) {
        // Fallback to text parsing if needed
        const clean = responseText.replace(/```json\n?|```/g, '').trim();
        const parsed = JSON.parse(clean);
        return res.json(parsed);
      }
    }
  } catch (error) {
    console.error('Gemini API call failed, falling back to local engine:', error);
  }

  // Fallback indicator so client knows to use local rule engine
  return res.json({ fallback: true });
});

// App status endpoint
app.get('/api/health', (req, res) => {
  res.json({ status: 'online', system: 'JARVIS-OS-v4.2', timestamp: new Date().toISOString() });
});

async function startServer() {
  if (process.env.NODE_ENV === 'production') {
    // Serve production build
    app.use(express.static(path.join(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.join(__dirname, 'dist', 'index.html'));
    });
  } else {
    // Mount Vite dev middleware
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`JARVIS OS dev server initialized on http://0.0.0.0:${PORT}`);
  });
}

startServer();
