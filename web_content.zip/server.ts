import express, { Request, Response } from 'express';
import http from 'http';
import { WebSocketServer, WebSocket } from 'ws';
import path from 'path';
import fs from 'fs';
import { createServer as createViteServer } from 'vite';

import { db, CallLog } from './server/db.js';
import { authRouter } from './server/routes/auth.js';
import { postsRouter } from './server/routes/posts.js';
import { storiesRouter } from './server/routes/stories.js';
import { messagesRouter } from './server/routes/messages.js';
import { socialRouter } from './server/routes/social.js';
import { groupsRouter } from './server/routes/groups.js';
import { pagesRouter } from './server/routes/pages.js';
import { marketplaceRouter } from './server/routes/marketplace.js';
import { trendsRouter } from './server/routes/trends.js';
import { adminRouter } from './server/routes/admin.js';
import { exportRouter } from './server/routes/export.js';

const app = express();
const server = http.createServer(app);
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

// High body limit for image/voice note uploads
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Ensure uploads directory exists
const UPLOADS_DIR = path.resolve(process.cwd(), 'uploads');
if (!fs.existsSync(UPLOADS_DIR)) {
  fs.mkdirSync(UPLOADS_DIR, { recursive: true });
}
app.use('/uploads', express.static(UPLOADS_DIR));

// File / Media upload endpoint
app.post('/api/upload', (req: Request, res: Response) => {
  try {
    const { dataBase64, filename, mimeType } = req.body;
    if (!dataBase64) {
      return res.status(400).json({ error: 'Dados do ficheiro não fornecidos.' });
    }

    const matches = dataBase64.match(/^data:([A-Za-z-+\/]+);base64,(.+)$/);
    let buffer: Buffer;
    let ext = 'bin';

    if (matches && matches.length === 3) {
      const detectedMime = matches[1];
      buffer = Buffer.from(matches[2], 'base64');
      if (detectedMime.includes('image/png')) ext = 'png';
      else if (detectedMime.includes('image/jpeg')) ext = 'jpg';
      else if (detectedMime.includes('image/webp')) ext = 'webp';
      else if (detectedMime.includes('audio/webm') || detectedMime.includes('audio/ogg')) ext = 'webm';
      else if (detectedMime.includes('audio/mp3') || detectedMime.includes('audio/mpeg')) ext = 'mp3';
      else if (detectedMime.includes('video/mp4')) ext = 'mp4';
      else if (detectedMime.includes('video/webm')) ext = 'webm';
    } else {
      buffer = Buffer.from(dataBase64, 'base64');
    }

    const safeName = `upload_${Date.now()}_${Math.random().toString(36).substring(2, 6)}.${ext}`;
    const filePath = path.join(UPLOADS_DIR, safeName);
    fs.writeFileSync(filePath, buffer);

    const fileUrl = `/uploads/${safeName}`;
    return res.json({ success: true, url: fileUrl, filename: safeName, size: buffer.length });
  } catch (err: any) {
    return res.status(500).json({ error: 'Erro ao guardar ficheiro: ' + err.message });
  }
});

// Mount modular REST APIs
app.use('/api/auth', authRouter);
app.use('/api/posts', postsRouter);
app.use('/api/stories', storiesRouter);
app.use('/api/messages', messagesRouter);
app.use('/api/social', socialRouter);
app.use('/api/groups', groupsRouter);
app.use('/api/pages', pagesRouter);
app.use('/api/marketplace', marketplaceRouter);
app.use('/api/trends', trendsRouter);
app.use('/api/admin', adminRouter);
app.use('/api/export', exportRouter);

// WebSocket Real-Time Infrastructure (Chat, Typing, Presence, WebRTC Signaling)
const wss = new WebSocketServer({ server, path: '/ws' });

// Track connected clients: userId -> WebSocket
const connectedClients = new Map<string, WebSocket>();

function broadcast(payload: object) {
  const data = JSON.stringify(payload);
  for (const client of connectedClients.values()) {
    if (client.readyState === WebSocket.OPEN) {
      client.send(data);
    }
  }
}

function sendToUser(userId: string, payload: object) {
  const client = connectedClients.get(userId);
  if (client && client.readyState === WebSocket.OPEN) {
    client.send(JSON.stringify(payload));
    return true;
  }
  return false;
}

wss.on('connection', (ws: WebSocket) => {
  let authenticatedUserId: string | null = null;

  ws.on('message', (messageRaw: string) => {
    try {
      const data = JSON.parse(messageRaw.toString());

      // 1. Client connects & authenticates presence
      if (data.type === 'auth') {
        authenticatedUserId = data.userId;
        if (authenticatedUserId) {
          connectedClients.set(authenticatedUserId, ws);

          // Update user last seen
          const users = db.get('users');
          const user = users.find(u => u.id === authenticatedUserId);
          if (user) {
            user.lastSeenAt = new Date().toISOString();
            db.persist();
          }

          // Broadcast user online status
          broadcast({
            type: 'presence:update',
            userId: authenticatedUserId,
            status: 'online'
          });

          // Send current online user IDs to the connected client
          const onlineUserIds = Array.from(connectedClients.keys());
          ws.send(JSON.stringify({
            type: 'presence:init',
            onlineUserIds
          }));
        }
      }

      // 2. Typing status
      else if (data.type === 'typing') {
        const { conversationId, isTyping, recipientIds } = data;
        if (recipientIds && Array.isArray(recipientIds)) {
          for (const recipientId of recipientIds) {
            if (recipientId !== authenticatedUserId) {
              sendToUser(recipientId, {
                type: 'typing',
                conversationId,
                userId: authenticatedUserId,
                isTyping
              });
            }
          }
        }
      }

      // 3. New Message Broadcast to recipients
      else if (data.type === 'message:send') {
        const { message, recipientIds } = data;
        if (recipientIds && Array.isArray(recipientIds)) {
          for (const recipientId of recipientIds) {
            sendToUser(recipientId, {
              type: 'message:new',
              message
            });
          }
        }
      }

      // 4. WebRTC Signaling Relay
      else if (data.type === 'call:initiate') {
        const { toUserId, caller, callType, roomId } = data;
        sendToUser(toUserId, {
          type: 'call:incoming',
          caller,
          callType,
          roomId
        });
      }

      else if (data.type === 'call:accept') {
        const { callerId, roomId } = data;
        sendToUser(callerId, {
          type: 'call:accepted',
          receiverId: authenticatedUserId,
          roomId
        });
      }

      else if (data.type === 'call:reject') {
        const { callerId, reason } = data;
        sendToUser(callerId, {
          type: 'call:rejected',
          reason: reason || 'busy'
        });

        // Log rejected / missed call
        if (callerId && authenticatedUserId) {
          const logs = db.get('callLogs');
          logs.unshift({
            id: 'call_' + Date.now(),
            callerId,
            receiverId: authenticatedUserId,
            callType: data.callType || 'audio',
            status: 'rejected',
            durationSeconds: 0,
            timestamp: new Date().toISOString()
          });
          db.set('callLogs', logs);
        }
      }

      else if (data.type === 'call:signal') {
        // Relays SDP offer, answer, or ICE candidate
        const { toUserId, signal } = data;
        sendToUser(toUserId, {
          type: 'call:signal',
          fromUserId: authenticatedUserId,
          signal
        });
      }

      else if (data.type === 'call:end') {
        const { toUserId, durationSeconds, callType } = data;
        sendToUser(toUserId, {
          type: 'call:ended'
        });

        if (authenticatedUserId && toUserId) {
          const logs = db.get('callLogs');
          logs.unshift({
            id: 'call_' + Date.now(),
            callerId: authenticatedUserId,
            receiverId: toUserId,
            callType: callType || 'video',
            status: 'completed',
            durationSeconds: durationSeconds || 0,
            timestamp: new Date().toISOString()
          });
          db.set('callLogs', logs);
        }
      }

    } catch (err) {
      console.error('Error handling WebSocket message:', err);
    }
  });

  ws.on('close', () => {
    if (authenticatedUserId) {
      connectedClients.delete(authenticatedUserId);
      broadcast({
        type: 'presence:update',
        userId: authenticatedUserId,
        status: 'offline',
        lastSeenAt: new Date().toISOString()
      });
    }
  });
});

// Mount Vite or serve static files
async function startServer() {
  const isProduction = process.env.NODE_ENV === 'production';

  if (!isProduction) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  server.listen(PORT, '0.0.0.0', () => {
    console.log(`[Angola Connect 🇦🇴] Servidor a correr na porta ${PORT}`);
  });
}

startServer().catch(err => {
  console.error('Falha ao iniciar Angola Connect Server:', err);
});
