import express from 'express';
import http from 'node:http';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
import dotenv from 'dotenv';
import { WebSocketServer, WebSocket } from 'ws';
import { GoogleGenAI, Modality, Type, LiveServerMessage, FunctionDeclaration } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const server = http.createServer(app);
const PORT = Number(process.env.PORT) || 3000;

app.use(express.json());

// Serve public static folder
app.use(express.static(path.join(__dirname, 'public')));

// Gemini SDK client
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

// Health check endpoint
app.get('/api/health', (_req, res) => {
  res.json({
    status: 'ok',
    hasApiKey: Boolean(process.env.GEMINI_API_KEY),
    time: new Date().toISOString(),
  });
});

// Direct Zip download endpoint
app.get('/api/download-zip', (_req, res) => {
  const zipPath = path.join(__dirname, 'public', 'roxy-voice-assistant.zip');
  if (fs.existsSync(zipPath)) {
    res.download(zipPath, 'roxy-voice-assistant.zip');
  } else {
    res.status(404).json({ error: 'Zip file not generated yet' });
  }
});

// WebSocket Server for Live Voice Stream
const wss = new WebSocketServer({ server, path: '/api/live' });

wss.on('connection', async (clientWs: WebSocket) => {
  console.log('[Live] Client connected to voice stream.');

  let liveSession: any = null;
  let activeVoice = 'Aoede';
  let isClosing = false;

  const systemInstruction = `
You are Roxy, a young, confident, brilliantly witty, and playfully sassy female AI companion and complete voice controller.
You have FULL CONTROL over this app and can execute ANY voice command the user speaks.

Languages:
- You seamlessly understand and respond in English, Hindi, and natural Hinglish (e.g. "YouTube kholo", "5 minute ka timer lagao", "Gana bajao", "Zip file download karo", "Note likh lo", "Google search karo").
- If the user speaks in Hindi/Hinglish, reply in cool, modern, casual Hinglish like a close friend talking on call.
- If the user speaks in English, reply in your witty, charming English persona.

Personality & Rules:
- Tone: Playful, lightly teasing, witty, confident, and magnetic. Never robotic, cold, or boring.
- CONCISE SPOKEN RESPONSES: Keep your voice answers punchy and conversational (1 to 2 short spoken sentences). Never read lists or speak long paragraphs.
- YOU HAVE FULL SYSTEM VOICE COMMAND CONTROL: When the user asks you to do something, immediately call the matching tool:
  1. "Open YouTube / WhatsApp / Instagram / Spotify / GitHub / Twitter / Maps / Netflix / Google" or any site -> call 'openWebsite'
  2. "Search Google for X" / "YouTube pe search karo X" / "Wikipedia dekho" -> call 'searchWeb'
  3. "Timer lagao / Set a timer for X seconds/minutes" -> call 'setTimer'
  4. "Yeh note kar lo / Take a note / Yaad rakhna" -> call 'takeNote'
  5. "Gana bajao / Play music / Lofi chalao / Party beat / Stop music" -> call 'playMusicVibe'
  6. "Zip file download karo / Download project zip / Give me source code zip" -> call 'downloadZip'
  7. "Calculate / Math karo (e.g. 25 * 40, 18% of 5000)" -> call 'calculateMath'
  8. "Copy text / Fullscreen / Mute" -> call 'deviceControl'
  9. "Theme badlo / Change mood to Cyber Rose / Emerald" -> call 'changeMoodTheme'
  10. "Smirk karo / Wink karo / Haso / React" -> call 'triggerExpression'
- Always call the tool first and give a snappy, fun confirmation!
`.trim();

  const functionDeclarations: FunctionDeclaration[] = [
    {
      name: 'openWebsite',
      description: 'Opens any website or web application requested by the user.',
      parameters: {
        type: Type.OBJECT,
        properties: {
          url: {
            type: Type.STRING,
            description: 'Destination URL starting with https:// (e.g. https://www.youtube.com, https://web.whatsapp.com, https://github.com, https://instagram.com)',
          },
          siteName: {
            type: Type.STRING,
            description: 'Friendly name of the site or app (e.g. YouTube, WhatsApp, Instagram, GitHub)',
          },
          comment: {
            type: Type.STRING,
            description: 'A witty, sassy comment about why Roxy is opening this',
          },
        },
        required: ['url'],
      },
    },
    {
      name: 'searchWeb',
      description: 'Searches the web on Google, YouTube, or Wikipedia based on user query.',
      parameters: {
        type: Type.OBJECT,
        properties: {
          query: {
            type: Type.STRING,
            description: 'Search terms or question to look up',
          },
          platform: {
            type: Type.STRING,
            description: "Platform: 'google', 'youtube', or 'wikipedia'",
          },
        },
        required: ['query'],
      },
    },
    {
      name: 'setTimer',
      description: 'Sets a real-time countdown timer in seconds.',
      parameters: {
        type: Type.OBJECT,
        properties: {
          seconds: {
            type: Type.NUMBER,
            description: 'Duration in seconds (e.g., 60 for 1 minute, 300 for 5 minutes, 30 for 30s)',
          },
          label: {
            type: Type.STRING,
            description: 'Label or purpose of the timer (e.g., "Tea", "Workout", "Pomodoro")',
          },
        },
        required: ['seconds'],
      },
    },
    {
      name: 'takeNote',
      description: 'Saves a note, reminder, or to-do item for the user.',
      parameters: {
        type: Type.OBJECT,
        properties: {
          text: {
            type: Type.STRING,
            description: 'The note content or reminder to remember',
          },
          category: {
            type: Type.STRING,
            description: 'Category: "Reminder", "Idea", "Task", or "Personal"',
          },
        },
        required: ['text'],
      },
    },
    {
      name: 'playMusicVibe',
      description: 'Plays generative synthesized music, lo-fi chill vibes, party beats, or stops music.',
      parameters: {
        type: Type.OBJECT,
        properties: {
          vibe: {
            type: Type.STRING,
            description: "'lofi', 'ambient', 'party', or 'alert'",
          },
          action: {
            type: Type.STRING,
            description: "'play' or 'stop'",
          },
        },
        required: ['action'],
      },
    },
    {
      name: 'downloadZip',
      description: 'Triggers direct download of the full application source code in a ZIP archive.',
      parameters: {
        type: Type.OBJECT,
        properties: {
          reason: {
            type: Type.STRING,
            description: 'Witty quip about downloading the project code',
          },
        },
      },
    },
    {
      name: 'calculateMath',
      description: 'Evaluates and displays a mathematical calculation on screen.',
      parameters: {
        type: Type.OBJECT,
        properties: {
          calculation: {
            type: Type.STRING,
            description: 'Math expression e.g. "25 * 34" or "18% of 5000"',
          },
        },
        required: ['calculation'],
      },
    },
    {
      name: 'deviceControl',
      description: 'Controls UI & device actions like copy to clipboard, fullscreen, or mute.',
      parameters: {
        type: Type.OBJECT,
        properties: {
          action: {
            type: Type.STRING,
            description: "'copy_clipboard', 'toggle_fullscreen', 'mute', or 'unmute'",
          },
          text: {
            type: Type.STRING,
            description: 'Text to copy if action is copy_clipboard',
          },
        },
        required: ['action'],
      },
    },
    {
      name: 'changeMoodTheme',
      description: 'Changes visual ambient mood and lighting theme of the UI.',
      parameters: {
        type: Type.OBJECT,
        properties: {
          theme: {
            type: Type.STRING,
            description: "'cyber-rose', 'electric-violet', 'midnight-emerald', 'solar-amber', or 'hyper-cyan'",
          },
          reason: {
            type: Type.STRING,
            description: 'Playful reason for shifting the vibe',
          },
        },
        required: ['theme'],
      },
    },
    {
      name: 'triggerExpression',
      description: 'Triggers a visual face/emotion reaction on Roxy interface (smirk, wink, laugh, blush, fire, pout, heart).',
      parameters: {
        type: Type.OBJECT,
        properties: {
          expression: {
            type: Type.STRING,
            description: 'Reaction type: smirk, wink, laugh, blush, fire, pout, heart',
          },
          commentary: {
            type: Type.STRING,
            description: 'Why Roxy has this expression',
          },
        },
        required: ['expression'],
      },
    },
  ];

  async function startSession(voiceName: string) {
    if (liveSession) {
      try {
        liveSession.close();
      } catch {}
      liveSession = null;
    }

    const modelsToTry = ['gemini-3.1-flash-live-preview', 'gemini-3.8-live'];

    for (const modelCandidate of modelsToTry) {
      try {
        console.log(`[Live] Connecting to Gemini Live with model: ${modelCandidate}, voice: ${voiceName}...`);
        const session = await ai.live.connect({
          model: modelCandidate,
          config: {
            responseModalities: [Modality.AUDIO],
            speechConfig: {
              voiceConfig: {
                prebuiltVoiceConfig: {
                  voiceName: voiceName || 'Aoede',
                },
              },
            },
            systemInstruction,
            tools: [
              {
                functionDeclarations,
              },
            ],
          },
          callbacks: {
            onmessage: (message: LiveServerMessage) => {
              if (clientWs.readyState !== WebSocket.OPEN) return;

              // 1. Audio stream chunks
              if (message.serverContent?.modelTurn?.parts) {
                for (const part of message.serverContent.modelTurn.parts) {
                  if (part.inlineData?.data) {
                    clientWs.send(
                      JSON.stringify({
                        type: 'audio',
                        audio: part.inlineData.data,
                      })
                    );
                  }
                }
              }

              // 2. Interruption signal
              if (message.serverContent?.interrupted) {
                clientWs.send(JSON.stringify({ type: 'interrupted' }));
              }

              // 3. Turn complete signal
              if (message.serverContent?.turnComplete) {
                clientWs.send(JSON.stringify({ type: 'turnComplete' }));
              }

              // 4. Tool calls (Function Calling)
              if (message.toolCall?.functionCalls && message.toolCall.functionCalls.length > 0) {
                const calls = message.toolCall.functionCalls.map((fc) => ({
                  id: fc.id,
                  name: fc.name,
                  args: fc.args || {},
                }));

                // Send toolCall to client to perform browser/UI actions
                clientWs.send(
                  JSON.stringify({
                    type: 'toolCall',
                    calls,
                  })
                );

                // Instantly send toolResponse back so Gemini can speak naturally
                const responses = calls.map((c) => ({
                  id: c.id,
                  name: c.name,
                  response: {
                    status: 'success',
                    executed: true,
                    timestamp: Date.now(),
                  },
                }));

                try {
                  session.sendToolResponse({
                    functionResponses: responses,
                  });
                } catch (err) {
                  console.error('[Live] Failed to send tool response to session:', err);
                }
              }
            },
            onclose: () => {
              console.log('[Live] Gemini session closed.');
              if (!isClosing && clientWs.readyState === WebSocket.OPEN) {
                clientWs.send(JSON.stringify({ type: 'interrupted' }));
              }
            },
            onerror: (err) => {
              console.error('[Live] Gemini session error:', err);
              if (clientWs.readyState === WebSocket.OPEN) {
                clientWs.send(
                  JSON.stringify({
                    type: 'error',
                    message: 'Gemini Live encountered an error.',
                  })
                );
              }
            },
          },
        });

        liveSession = session;
        console.log(`[Live] Connected successfully using ${modelCandidate}!`);
        clientWs.send(
          JSON.stringify({
            type: 'connected',
            model: modelCandidate,
            voice: voiceName,
          })
        );
        return;
      } catch (err: any) {
        console.warn(`[Live] Model ${modelCandidate} failed to connect:`, err?.message || err);
      }
    }

    clientWs.send(
      JSON.stringify({
        type: 'error',
        message: 'Could not connect to Gemini Live models. Verify API Key in Settings > Secrets.',
      })
    );
  }

  clientWs.on('message', async (data) => {
    try {
      const msg = JSON.parse(data.toString());

      if (msg.type === 'config') {
        if (msg.voice && msg.voice !== activeVoice) {
          activeVoice = msg.voice;
        }
        await startSession(activeVoice);
      } else if (msg.type === 'audio' && msg.audio) {
        if (!liveSession) {
          await startSession(activeVoice);
        }
        if (liveSession) {
          liveSession.sendRealtimeInput({
            audio: {
              data: msg.audio,
              mimeType: 'audio/pcm;rate=16000',
            },
          });
        }
      } else if (msg.type === 'toolResponse' && liveSession) {
        liveSession.sendToolResponse({
          functionResponses: [
            {
              id: msg.id,
              name: msg.name,
              response: msg.response || { status: 'ok' },
            },
          ],
        });
      } else if (msg.type === 'interrupt' && liveSession) {
        console.log('[Live] User interrupted assistant.');
      }
    } catch (err) {
      console.error('[Live] Error processing client message:', err);
    }
  });

  clientWs.on('close', () => {
    isClosing = true;
    console.log('[Live] Client disconnected.');
    if (liveSession) {
      try {
        liveSession.close();
      } catch {}
      liveSession = null;
    }
  });
});

// Vite middleware in dev or static files in production
async function setupApp() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  server.listen(PORT, '0.0.0.0', () => {
    console.log(`[Server] Roxy Voice Assistant running at http://0.0.0.0:${PORT}`);
  });
}

setupApp().catch((err) => {
  console.error('[Server] Fatal startup error:', err);
});
