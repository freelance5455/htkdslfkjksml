import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { randomUUID } from 'node:crypto';
import { fileURLToPath } from 'url';
import { GoogleGenAI, Type, ThinkingLevel } from '@google/genai';
import { buildSystemInstruction, TUTOR_PERSONAS, TutorPersonaId, TeachingMode, AcademicLevel } from './src/utils/tutor-prompts.ts';
import { generateEducationalResponse, generateFallbackQuiz } from './src/utils/tutor-fallback.ts';
import { SUBSCRIPTION_PLANS } from './src/config/subscription-plans.ts';

dotenv.config();

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

app.use(express.json({ limit: '10mb' }));

// Initialize Google GenAI with telemetry header
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
    timeout: 10000,
  },
});

const DEFAULT_MODEL = 'gemini-3.8-flash';

// Progressive streaming for educational content
async function streamFallbackText(res: express.Response, fullText: string) {
  const words = fullText.split(' ');
  for (let i = 0; i < words.length; i += 3) {
    const chunk = words.slice(i, i + 3).join(' ') + ' ';
    res.write(`data: ${JSON.stringify({ text: chunk })}\n\n`);
    await new Promise((resolve) => setTimeout(resolve, 25));
  }
  res.write('data: [DONE]\n\n');
  res.end();
}

// Helper with race timeout
function withTimeout<T>(promise: Promise<T>, ms: number, timeoutMsg = 'Operation timed out'): Promise<T> {
  return Promise.race([
    promise,
    new Promise<T>((_, reject) => setTimeout(() => reject(new Error(timeoutMsg)), ms)),
  ]);
}

// SSE Streaming Chat Endpoint
app.post('/api/chat', async (req, res) => {
  const { messages, persona = 'general', teachingMode = 'direct', level = 'high_school' } = req.body;

  if (!Array.isArray(messages) || messages.length === 0) {
    res.status(400).json({ error: 'Messages array is required.' });
    return;
  }

  // Setup Server-Sent Events headers
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.flushHeaders?.();

  const lastUserMessage = messages[messages.length - 1]?.content || 'Hello';

  try {
    const systemInstruction = buildSystemInstruction({
      personaId: persona as TutorPersonaId,
      teachingMode: teachingMode as TeachingMode,
      level: level as AcademicLevel,
    });

    const contents = messages.map((m: { role: string; content: string }) => ({
      role: m.role === 'assistant' || m.role === 'model' ? 'model' : 'user',
      parts: [{ text: m.content }],
    }));

    // Connect to model with 4000ms timeout for initial stream connection
    const responseStream = await withTimeout(
      ai.models.generateContentStream({
        model: DEFAULT_MODEL,
        contents,
        config: {
          systemInstruction,
          temperature: 0.7,
          thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
        },
      }),
      4000,
      'Gemini stream initial response deadline'
    );

    let streamedAnyChunk = false;

    for await (const chunk of responseStream) {
      const text = chunk.text;
      if (text) {
        streamedAnyChunk = true;
        res.write(`data: ${JSON.stringify({ text })}\n\n`);
      }
    }

    if (!streamedAnyChunk) {
      throw new Error('Empty stream response');
    }

    res.write('data: [DONE]\n\n');
    res.end();
  } catch (error: any) {
    console.warn('Using intelligent tutor response (API error/timeout):', error?.message);
    const fallbackText = generateEducationalResponse(
      lastUserMessage,
      persona as TutorPersonaId,
      teachingMode as TeachingMode,
      level as AcademicLevel
    );
    await streamFallbackText(res, fallbackText);
  }
});

// Structured Quiz Generator Endpoint
app.post('/api/generate-quiz', async (req, res) => {
  const { topic, persona = 'general', level = 'high_school', count = 4 } = req.body;

  if (!topic) {
    res.status(400).json({ error: 'Topic is required.' });
    return;
  }

  try {
    const personaInfo = TUTOR_PERSONAS[persona as TutorPersonaId] || TUTOR_PERSONAS.general;
    const prompt = `Generate a ${count}-question multiple choice quiz on the topic: "${topic}".
Academic audience level: ${level}.
Subject domain: ${personaInfo.name}.
Each question must test conceptual understanding or problem solving. Include 4 plausible options, specify the 0-based index of the correct answer, and provide a helpful concise explanation and a subtle hint.`;

    const response = await withTimeout(
      ai.models.generateContent({
        model: DEFAULT_MODEL,
        contents: prompt,
        config: {
          responseMimeType: 'application/json',
          thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              topic: { type: Type.STRING },
              questions: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    id: { type: Type.STRING },
                    question: { type: Type.STRING },
                    options: {
                      type: Type.ARRAY,
                      items: { type: Type.STRING },
                    },
                    correctOptionIndex: { type: Type.INTEGER },
                    explanation: { type: Type.STRING },
                    hint: { type: Type.STRING },
                  },
                  required: ['id', 'question', 'options', 'correctOptionIndex', 'explanation', 'hint'],
                },
              },
            },
            required: ['topic', 'questions'],
          },
        },
      }),
      4500
    );

    const jsonText = response.text?.trim() || '{}';
    const parsed = JSON.parse(jsonText);
    res.json(parsed);
  } catch (error: any) {
    console.warn('Quiz generation using instant structured fallback:', error?.message);
    res.json({
      topic,
      questions: generateFallbackQuiz(topic),
    });
  }
});

// Flashcards Generator Endpoint
app.post('/api/generate-flashcards', async (req, res) => {
  const { topic, count = 5 } = req.body;

  if (!topic) {
    res.status(400).json({ error: 'Topic is required.' });
    return;
  }

  try {
    const prompt = `Generate ${count} high-yield study flashcards for mastering: "${topic}".
Front should be a key concept, term, or formula. Back should be a clear, memorable definition, intuition, or example.`;

    const response = await withTimeout(
      ai.models.generateContent({
        model: DEFAULT_MODEL,
        contents: prompt,
        config: {
          responseMimeType: 'application/json',
          thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              topic: { type: Type.STRING },
              flashcards: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    id: { type: Type.STRING },
                    front: { type: Type.STRING },
                    back: { type: Type.STRING },
                    category: { type: Type.STRING },
                  },
                  required: ['id', 'front', 'back'],
                },
              },
            },
            required: ['topic', 'flashcards'],
          },
        },
      }),
      4500
    );

    const jsonText = response.text?.trim() || '{}';
    const parsed = JSON.parse(jsonText);
    res.json(parsed);
  } catch (error: any) {
    console.warn('Flashcard generation fallback:', error?.message);
    res.json({
      topic,
      flashcards: [
        {
          id: 'fc_1',
          front: `${topic}: Core Principle`,
          back: `The fundamental rule and governing relationship for ${topic}. Keep invariant physical/mathematical symmetries in mind.`,
          category: 'Core Theory',
        },
        {
          id: 'fc_2',
          front: `${topic}: Problem-Solving Heuristic`,
          back: `Break down the problem into conservation constraints, boundary states, and simplify non-linear dependencies.`,
          category: 'Strategy',
        },
        {
          id: 'fc_3',
          front: `${topic}: Common Misconception`,
          back: `Assuming linear proportionality where exponential or inverse-square relationships dominate.`,
          category: 'Pitfalls',
        },
      ],
    });
  }
});

// Public plan catalog. Paid entitlements remain disabled until payment is verified.
app.get('/api/plans', (_req, res) => {
  res.json({ currency: 'INR', billingEnabled: false, plans: SUBSCRIPTION_PLANS });
});

/**
 * Create a one-time UPI intent for a selected plan. The UPI ID and support email
 * are read only from server environment variables and are never rendered as plain
 * text in the UI. A UPI intent is NOT proof of payment: this endpoint deliberately
 * does not activate a subscription or mark an order as paid.
 */
app.post('/api/billing/upi-intent', (req, res) => {
  const { planId, billingCycle } = req.body ?? {};
  const plan = SUBSCRIPTION_PLANS.find((candidate) => candidate.id === planId);

  if (!plan || plan.id === 'free') {
    res.status(400).json({ error: 'Choose a valid paid subscription plan.' });
    return;
  }
  if (billingCycle !== 'monthly' && billingCycle !== 'annual') {
    res.status(400).json({ error: 'Choose monthly or annual billing.' });
    return;
  }

  const upiId = process.env.PAYMENT_UPI_ID?.trim();
  const supportEmail = process.env.PAYMENT_SUPPORT_EMAIL?.trim();
  const displayName = process.env.PAYMENT_DISPLAY_NAME?.trim() || 'MindSparq';

  // Basic validation avoids generating malformed intent links. Keep values in the
  // server environment; never add them to a VITE_ variable or frontend source.
  const validUpiId = Boolean(upiId && /^[A-Za-z0-9._-]{2,128}@[A-Za-z0-9.-]{2,64}$/.test(upiId));
  const validEmail = Boolean(supportEmail && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(supportEmail));
  if (!validUpiId || !validEmail) {
    res.status(503).json({
      error: 'UPI payment setup is not configured. Add PAYMENT_UPI_ID and PAYMENT_SUPPORT_EMAIL in the server secret settings.',
    });
    return;
  }

  const amount = billingCycle === 'monthly' ? plan.monthlyPrice : plan.annualPrice;
  const paymentReference = `MSQ-${randomUUID().replace(/-/g, '').slice(0, 12).toUpperCase()}`;
  const paymentNote = `MindSparq ${plan.name} ${billingCycle} plan`;
  const upiParams = new URLSearchParams({
    pa: upiId,
    pn: displayName.slice(0, 50),
    am: amount.toFixed(2),
    cu: 'INR',
    tn: paymentNote.slice(0, 80),
    tr: paymentReference,
  });
  const emailSubject = `MindSparq payment reference - ${plan.name}`;
  const emailBody = [
    'Hello MindSparq,',
    '',
    'I have made a UPI payment and request manual verification.',
    `Plan: ${plan.name}`,
    `Billing cycle: ${billingCycle}`,
    `Amount: INR ${amount}`,
    `Payment reference: ${paymentReference}`,
    'UPI transaction ID / UTR: (please add it here)',
    '',
    'Please do not activate access until the payment has been independently verified.',
  ].join('\n');
  const supportMailto = `mailto:${supportEmail}?subject=${encodeURIComponent(emailSubject)}&body=${encodeURIComponent(emailBody)}`;

  res.json({
    planId: plan.id,
    planName: plan.name,
    billingCycle,
    amount,
    currency: 'INR',
    paymentReference,
    paymentUri: `upi://pay?${upiParams.toString()}`,
    supportMailto,
    paymentMode: 'manual-review',
    subscriptionActivated: false,
    renewsAutomatically: false,
  });
});

// Health check
app.get('/api/health', (_req, res) => {
  res.json({ status: 'ok', time: new Date().toISOString() });
});

// Mount Vite or serve static dist
async function startServer() {
  if (process.env.NODE_ENV === 'production') {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  } else {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`MindSparq AI Tutor server running at http://0.0.0.0:${PORT}`);
  });
}

startServer();
