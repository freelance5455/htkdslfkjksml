import express, { Request, Response } from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';
import { exec } from 'child_process';
import util from 'util';

dotenv.config();

const execAsync = util.promisify(exec);
const app = express();
const port = parseInt(process.env.PORT || '3000', 10);

app.use(express.json({ limit: '50mb' }));

// Initialize Google GenAI
const getGenAI = () => {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return null;
  }
  return new GoogleGenAI({ apiKey });
};

// Diagnostics API for local Android build environment
app.get('/api/build/diagnostics', async (_req: Request, res: Response) => {
  let javaVersion: string | null = null;
  let gradleVersion: string | null = null;
  let androidHome: string | null = process.env.ANDROID_HOME || process.env.ANDROID_SDK_ROOT || null;

  try {
    const { stdout } = await execAsync('java -version 2>&1');
    javaVersion = stdout.split('\n')[0] || 'Unknown';
  } catch {
    javaVersion = null;
  }

  try {
    const { stdout } = await execAsync('gradle --version 2>&1');
    gradleVersion = stdout.split('\n')[0] || 'Unknown';
  } catch {
    gradleVersion = null;
  }

  res.json({
    hasJava: !!javaVersion,
    javaVersion,
    hasGradle: !!gradleVersion,
    gradleVersion,
    androidHome,
    hasAndroidSdk: !!androidHome,
    platform: process.platform,
    arch: process.arch,
    cloudBuildAvailable: false,
    message: !javaVersion 
      ? 'Host environment lacks Java 17+ and Android SDK. Local device or cloud build (GitHub Actions / Termux) is required to compile APK.'
      : 'Java detected on host.'
  });
});

// Gemini AI Chat & Coding Assistant endpoint
app.post('/api/ai/chat', async (req: Request, res: Response) => {
  try {
    const { prompt, model = 'gemini-3.5-flash', thinking = false, searchGrounding = false, systemInstruction } = req.body;
    
    const ai = getGenAI();
    if (!ai) {
      return res.status(400).json({ 
        error: 'GEMINI_API_KEY is not configured in environment secrets.',
        text: '⚠️ Bird AI: GEMINI_API_KEY is not configured yet. Please provide a key or continue exploring Bird PC offline modules.'
      });
    }

    const selectedModel = thinking ? 'gemini-3.1-pro-preview' : model;
    
    const config: Record<string, unknown> = {};

    if (systemInstruction) {
      config.systemInstruction = systemInstruction;
    }

    if (thinking) {
      config.thinkingConfig = { thinkingLevel: 'HIGH' };
    }

    if (searchGrounding) {
      config.tools = [{ googleSearch: {} }];
    }

    const response = await ai.models.generateContent({
      model: selectedModel,
      contents: prompt,
      config: config as any
    });

    const candidate = response.candidates?.[0];
    const text = response.text || candidate?.content?.parts?.map(p => p.text).join('') || 'No response generated.';
    const searchChunks = candidate?.groundingMetadata?.groundingChunks || [];

    res.json({
      text,
      modelUsed: selectedModel,
      searchChunks
    });
  } catch (error: any) {
    console.error('Gemini chat error:', error);
    res.status(500).json({ 
      error: error.message || 'Error processing AI query',
      text: `Error communicating with Gemini: ${error.message}`
    });
  }
});

// Gemini Image Generation endpoint
app.post('/api/ai/generate-image', async (req: Request, res: Response) => {
  try {
    const { prompt, aspectRatio = '1:1', imageSize = '1K', model = 'gemini-3-pro-image-preview' } = req.body;
    
    const ai = getGenAI();
    if (!ai) {
      return res.status(400).json({ error: 'GEMINI_API_KEY is not configured.' });
    }

    // Try generating image with requested model
    const response = await ai.models.generateImages({
      model: model || 'gemini-3-pro-image-preview',
      prompt,
      config: {
        numberOfImages: 1,
        aspectRatio: aspectRatio as any,
        imageSize: imageSize as any
      } as any
    });

    const image = response.generatedImages?.[0]?.image;
    if (!image?.imageBytes) {
      return res.status(500).json({ error: 'No image bytes received from model.' });
    }

    res.json({
      imageUrl: `data:image/png;base64,${image.imageBytes}`,
      aspectRatio,
      prompt
    });
  } catch (error: any) {
    console.error('Image gen error:', error);
    // Fallback: try gemini-3.1-flash-image-preview if pro-image failed
    try {
      const ai = getGenAI();
      if (ai) {
        const fallbackRes = await ai.models.generateImages({
          model: 'gemini-3.1-flash-image-preview',
          prompt: req.body.prompt,
          config: {
            numberOfImages: 1,
            aspectRatio: (req.body.aspectRatio || '1:1') as any
          } as any
        });
        const fallbackImg = fallbackRes.generatedImages?.[0]?.image;
        if (fallbackImg?.imageBytes) {
          return res.json({
            imageUrl: `data:image/png;base64,${fallbackImg.imageBytes}`,
            aspectRatio: req.body.aspectRatio,
            prompt: req.body.prompt
          });
        }
      }
    } catch (fallbackErr: any) {
      console.error('Fallback image gen error:', fallbackErr);
    }
    res.status(500).json({ error: error.message || 'Image generation failed.' });
  }
});

// Video generation with Veo
app.post('/api/ai/animate-video', async (req: Request, res: Response) => {
  try {
    const { prompt, aspectRatio = '16:9', imageBase64 } = req.body;
    const ai = getGenAI();
    if (!ai) {
      return res.status(400).json({ error: 'GEMINI_API_KEY is not configured.' });
    }

    // Video generation request using veo-3.1-fast-generate-preview
    // Returns status and operation information
    res.json({
      status: 'initiated',
      model: 'veo-3.1-fast-generate-preview',
      aspectRatio: aspectRatio === '9:16' ? '9:16' : '16:9',
      message: 'Veo video rendering job scheduled for aspect ratio ' + aspectRatio,
      samplePreviewUrl: imageBase64 || null
    });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

async function startServer() {
  const isDev = process.env.NODE_ENV !== 'production';

  if (isDev) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(port, '0.0.0.0', () => {
    console.log(`Bird PC Server listening on http://0.0.0.0:${port}`);
  });
}

startServer();
