import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import { generateBrandMorphApk } from './src/utils/apkBuilder.ts';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;

// High payload limit for image & video base64
app.use(express.json({ limit: '60mb' }));
app.use(express.urlencoded({ extended: true, limit: '60mb' }));

// Serve static public folder (includes pre-built BrandMorph_Julli_v1.0.apk)
app.use(express.static(path.resolve(__dirname, 'public')));


// Initialize GoogleGenAI SDK with user agent telemetry
const getGenAIClient = (customKey?: string) => {
  const apiKey = customKey || process.env.GEMINI_API_KEY || '';
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
};

const defaultAi = getGenAIClient();

// Pollinations AI API Configuration
const POLLINATIONS_API_KEY = process.env.POLLINATIONS_API_KEY || 'sk_QiH5IPtAvEwXzZCzMsI31AWBt2MSffal';

function getDimensions(imageSize: string = '1K', aspectRatio: string = '1:1') {
  let base = 1024;
  if (imageSize === '2K') base = 1536;
  if (imageSize === '4K') base = 2048;

  switch (aspectRatio) {
    case '16:9':
      return { width: Math.round(base * 1.33), height: Math.round(base * 0.75) };
    case '9:16':
      return { width: Math.round(base * 0.75), height: Math.round(base * 1.33) };
    case '4:3':
      return { width: base, height: Math.round(base * 0.75) };
    case '3:4':
      return { width: Math.round(base * 0.75), height: base };
    case '1:1':
    default:
      return { width: base, height: base };
  }
}

/**
 * Sequential Pollinations AI image fetcher:
 * 1. https://gen.pollinations.ai/image/
 * 2. If fail -> https://image.pollinations.ai/prompt/
 * Using API Key: sk_QiH5IPtAvEwXzZCzMsI31AWBt2MSffal
 */
async function fetchPollinationsImage(prompt: string, width = 1024, height = 1024) {
  const seed = Math.floor(Math.random() * 99999999);
  const encodedPrompt = encodeURIComponent(prompt);

  // 1. Try Endpoint 1: https://gen.pollinations.ai/image/
  try {
    const url1 = `https://gen.pollinations.ai/image/${encodedPrompt}?width=${width}&height=${height}&seed=${seed}&nologo=true`;
    console.log(`[Pollinations] Trying Endpoint 1: ${url1}`);
    const res1 = await fetch(url1, {
      headers: {
        Authorization: `Bearer ${POLLINATIONS_API_KEY}`,
        'User-Agent': 'BrandMorph/1.0',
      },
    });

    if (res1.ok) {
      const arrayBuffer = await res1.arrayBuffer();
      const buffer = Buffer.from(arrayBuffer);
      const mimeType = res1.headers.get('content-type') || 'image/jpeg';
      const imageBase64 = buffer.toString('base64');
      return {
        success: true,
        imageUrl: `data:${mimeType};base64,${imageBase64}`,
        imageBase64,
        mimeType,
        endpointUsed: 'https://gen.pollinations.ai/image/',
      };
    }
    console.warn(`[Pollinations] Endpoint 1 returned ${res1.status}. Falling back to Endpoint 2...`);
  } catch (err1: any) {
    console.warn(`[Pollinations] Endpoint 1 failed: ${err1?.message}. Falling back to Endpoint 2...`);
  }

  // 2. Try Endpoint 2: https://image.pollinations.ai/prompt/
  try {
    const url2 = `https://image.pollinations.ai/prompt/${encodedPrompt}?width=${width}&height=${height}&seed=${seed}&nologo=true`;
    console.log(`[Pollinations] Trying Endpoint 2: ${url2}`);
    const res2 = await fetch(url2, {
      headers: {
        Authorization: `Bearer ${POLLINATIONS_API_KEY}`,
        'User-Agent': 'BrandMorph/1.0',
      },
    });

    if (res2.ok) {
      const arrayBuffer = await res2.arrayBuffer();
      const buffer = Buffer.from(arrayBuffer);
      const mimeType = res2.headers.get('content-type') || 'image/jpeg';
      const imageBase64 = buffer.toString('base64');
      return {
        success: true,
        imageUrl: `data:${mimeType};base64,${imageBase64}`,
        imageBase64,
        mimeType,
        endpointUsed: 'https://image.pollinations.ai/prompt/',
      };
    }
    console.warn(`[Pollinations] Endpoint 2 returned ${res2.status}.`);
  } catch (err2: any) {
    console.warn(`[Pollinations] Endpoint 2 failed: ${err2?.message}`);
  }

  throw new Error('Both Pollinations image generation endpoints failed.');
}

// Dedicated Pollinations Image Generation API route
app.post('/api/pollinations/image', async (req, res) => {
  try {
    const { prompt, width = 1024, height = 1024 } = req.body;
    if (!prompt) {
      return res.status(400).json({ error: 'Prompt is required.' });
    }
    const result = await fetchPollinationsImage(prompt, width, height);
    res.json(result);
  } catch (err: any) {
    console.error('Pollinations API error:', err);
    res.status(500).json({ error: err.message || 'Pollinations generation failed' });
  }
});

// Real Android APK Download Endpoint (delivers genuine .apk package)
const apkAliases = [
  '/api/download-apk',
  '/BrandMorph_Julli_v1.0.apk',
  '/download/apk',
  '/download',
  '/app.apk',
  '/julli.apk',
  '/BrandMorph.apk',
];

app.get(apkAliases, (req, res) => {
  try {
    const diskPath = path.resolve(__dirname, 'public', 'BrandMorph_Julli_v1.0.apk');
    if (fs.existsSync(diskPath)) {
      res.setHeader('Content-Type', 'application/vnd.android.package-archive');
      res.setHeader('Content-Disposition', 'attachment; filename="BrandMorph_Julli_v1.0.apk"');
      res.setHeader('Cache-Control', 'public, max-age=3600');
      return res.sendFile(diskPath);
    }

    const apkBuffer = generateBrandMorphApk();
    res.setHeader('Content-Type', 'application/vnd.android.package-archive');
    res.setHeader('Content-Disposition', 'attachment; filename="BrandMorph_Julli_v1.0.apk"');
    res.setHeader('Content-Length', apkBuffer.length);
    res.setHeader('Cache-Control', 'public, max-age=3600');
    res.send(apkBuffer);
  } catch (err: any) {
    console.error('APK generation error:', err);
    res.status(500).json({ error: 'Failed to generate APK archive' });
  }
});

// Full Project ZIP Download Endpoint
const zipAliases = [
  '/api/download-zip',
  '/apk.zip',
  '/BrandMorph_Project.zip',
  '/download/zip',
  '/project.zip',
  '/download-zip',
];

app.get(zipAliases, (req, res) => {
  try {
    let diskZipPath = path.resolve(__dirname, 'public', 'apk.zip');
    if (!fs.existsSync(diskZipPath)) {
      diskZipPath = path.resolve(__dirname, 'public', 'BrandMorph_Project.zip');
    }
    if (fs.existsSync(diskZipPath)) {
      res.setHeader('Content-Type', 'application/zip');
      res.setHeader('Content-Disposition', 'attachment; filename="apk.zip"');
      res.setHeader('Cache-Control', 'public, max-age=3600');
      return res.sendFile(diskZipPath);
    }
    res.status(404).json({ error: 'Zip file not found' });
  } catch (err: any) {
    console.error('ZIP download error:', err);
    res.status(500).json({ error: 'Failed to deliver zip archive' });
  }
});

// Standalone Single-File HTML Download Endpoint
const htmlAliases = [
  '/api/download-html',
  '/apk.html',
  '/BrandMorph_Standalone.html',
  '/app.html',
  '/standalone.html',
  '/download/html',
];

app.get(htmlAliases, (req, res) => {
  try {
    let diskHtmlPath = path.resolve(__dirname, 'public', 'apk.html');
    if (!fs.existsSync(diskHtmlPath)) {
      diskHtmlPath = path.resolve(__dirname, 'public', 'BrandMorph_Standalone.html');
    }
    if (fs.existsSync(diskHtmlPath)) {
      res.setHeader('Content-Type', 'text/html; charset=utf-8');
      res.setHeader('Content-Disposition', 'attachment; filename="apk.html"');
      return res.sendFile(diskHtmlPath);
    }
    res.status(404).json({ error: 'HTML file not found' });
  } catch (err: any) {
    console.error('HTML download error:', err);
    res.status(500).json({ error: 'Failed to deliver HTML file' });
  }
});



/**
 * 1. LOGO GENERATION ENDPOINT
 * Uses mandatory model: gemini-3-pro-image-preview
 * Supports user affordances for 1K, 2K, 4K image size and various aspect ratios
 */
app.post('/api/generate-logo', async (req, res) => {
  try {
    const {
      brandName,
      industry = 'General',
      style = 'Minimalist Vector',
      description = '',
      colors = [],
      tagline = '',
      imageSize = '1K', // '1K' | '2K' | '4K'
      aspectRatio = '1:1', // '1:1' | '16:9' | '9:16' | '4:3' | '3:4'
      customPrompt = '',
      apiKeyOverride,
      modelOverride,
    } = req.body;

    if (!brandName && !customPrompt) {
      return res.status(400).json({ error: 'Brand name or custom prompt is required.' });
    }

    const colorPhrase = colors.length > 0 ? `Color palette: ${colors.join(', ')}.` : '';
    const taglinePhrase = tagline ? `Tagline inclusion/motif: "${tagline}".` : '';

    const enrichedPrompt = customPrompt
      ? `${customPrompt}. Clean corporate logo design, high vector quality, centered, isolated on neutral background.`
      : `High-end professional vector logo design for brand named "${brandName}". Industry: ${industry}. Design Style: ${style}. ${colorPhrase} ${taglinePhrase} Concept details: ${description || 'Unique iconic emblem symbol with modern typography'}. Centered composition, flat vector icon or sharp 3D mark, clean geometry, isolated solid background, award winning brand identity, no mockups, crisp resolution.`;

    const client = getGenAIClient(apiKeyOverride);
    const targetModel = modelOverride || 'gemini-3-pro-image-preview';

    let imageUrl = '';
    let imageBase64 = '';
    let mimeType = 'image/png';
    let modelUsed = targetModel;

    try {
      // First attempt with gemini-3-pro-image-preview (supports imageSize: 1K, 2K, 4K)
      const response = await client.models.generateContent({
        model: targetModel,
        contents: {
          parts: [{ text: enrichedPrompt }],
        },
        config: {
          imageConfig: {
            aspectRatio: aspectRatio as any,
            imageSize: imageSize as any,
          },
        },
      });

      const candidate = response.candidates?.[0];
      if (candidate?.content?.parts) {
        for (const part of candidate.content.parts) {
          if (part.inlineData?.data) {
            imageBase64 = part.inlineData.data;
            mimeType = part.inlineData.mimeType || 'image/png';
            imageUrl = `data:${mimeType};base64,${imageBase64}`;
            break;
          }
        }
      }
    } catch (primaryErr: any) {
      console.warn(`Primary model ${targetModel} generation attempt error:`, primaryErr?.message);

      // If gemini-3-pro-image-preview hits a 404/quota or alias difference, fallback to gemini-nano-banana-2.1
      try {
        modelUsed = 'gemini-nano-banana-2.1';
        const fallbackRes = await client.models.generateContent({
          model: modelUsed,
          contents: {
            parts: [{ text: enrichedPrompt }],
          },
          config: {
            imageConfig: {
              aspectRatio: aspectRatio as any,
              imageSize: imageSize as any,
            },
          },
        });
        const candidate = fallbackRes.candidates?.[0];
        if (candidate?.content?.parts) {
          for (const part of candidate.content.parts) {
            if (part.inlineData?.data) {
              imageBase64 = part.inlineData.data;
              mimeType = part.inlineData.mimeType || 'image/png';
              imageUrl = `data:${mimeType};base64,${imageBase64}`;
              break;
            }
          }
        }
      } catch (fallbackErr: any) {
        console.warn('Fallback nano-banana generation error:', fallbackErr?.message);
        // Third fallback to gemini-3.1-flash-lite-image
        modelUsed = 'gemini-3.1-flash-lite-image';
        const thirdRes = await client.models.generateContent({
          model: modelUsed,
          contents: {
            parts: [{ text: enrichedPrompt }],
          },
        });
        const candidate = thirdRes.candidates?.[0];
        if (candidate?.content?.parts) {
          for (const part of candidate.content.parts) {
            if (part.inlineData?.data) {
              imageBase64 = part.inlineData.data;
              mimeType = part.inlineData.mimeType || 'image/png';
              imageUrl = `data:${mimeType};base64,${imageBase64}`;
              break;
            }
          }
        }
      }
    }

    // Pollinations AI image generation fallback (Endpoint 1 -> Endpoint 2)
    if (!imageUrl) {
      console.log('Generating logo with Pollinations AI (Endpoint 1 -> Endpoint 2)...');
      try {
        const { width, height } = getDimensions(imageSize, aspectRatio);
        const pollRes = await fetchPollinationsImage(enrichedPrompt, width, height);
        if (pollRes?.imageUrl) {
          imageUrl = pollRes.imageUrl;
          imageBase64 = pollRes.imageBase64;
          mimeType = pollRes.mimeType;
          modelUsed = `Pollinations AI (${pollRes.endpointUsed.includes('gen.pollinations.ai') ? 'Endpoint 1' : 'Endpoint 2'})`;
        }
      } catch (pollErr: any) {
        console.warn('Pollinations logo generation error:', pollErr?.message);
      }
    }

    // If still not generated, fallback to AI vector SVG generation
    if (!imageUrl) {
      console.log('Generating AI vector logo fallback with gemini-flash-latest...');
      try {
        const flashRes = await client.models.generateContent({
          model: 'gemini-flash-latest',
          contents: `You are a master corporate identity and logo designer.
Create a complete, modern, award-winning SVG vector logo for company: "${brandName}".
Industry: ${industry}. Style: ${style}. Concept: ${description || 'Clean geometric emblem'}.
Tagline: "${tagline}".
Brand Colors: ${colors.length > 0 ? colors.join(', ') : '#6366f1, #a855f7, #ec4899'}.
Output ONLY clean, raw, valid SVG code with viewBox="0 0 800 800" width="800" height="800".
Include sophisticated gradients (<defs><linearGradient...>), centered iconography, modern typography, and a dark sleek background rectangle (<rect width="800" height="800" fill="#090d16"/>).
Do not wrap in markdown or explanation, just the <svg>...</svg>.`,
        });

        let svgCode = flashRes.text?.trim() || '';
        if (svgCode.includes('<svg')) {
          svgCode = svgCode.substring(svgCode.indexOf('<svg'));
          if (svgCode.includes('</svg>')) {
            svgCode = svgCode.substring(0, svgCode.indexOf('</svg>') + 6);
          }
          const svgBase64 = Buffer.from(svgCode, 'utf-8').toString('base64');
          imageUrl = `data:image/svg+xml;base64,${svgBase64}`;
          imageBase64 = svgBase64;
          mimeType = 'image/svg+xml';
          modelUsed = 'gemini-flash-latest (AI Vector)';
        }
      } catch (svgErr: any) {
        console.warn('Gemini Flash SVG fallback error:', svgErr?.message);
      }
    }

    // Procedural SVG fallback if all network AI calls were refused
    if (!imageUrl) {
      const primaryColor = colors[0] || '#6366f1';
      const secondaryColor = colors[1] || '#a855f7';
      const initials = brandName.split(' ').map((w: string) => w[0]).join('').substring(0, 3).toUpperCase() || 'BM';
      const proceduralSvg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 800" width="800" height="800">
        <defs>
          <linearGradient id="bg" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stop-color="#070b14"/>
            <stop offset="100%" stop-color="#0f172a"/>
          </linearGradient>
          <linearGradient id="logoGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stop-color="${primaryColor}"/>
            <stop offset="100%" stop-color="${secondaryColor}"/>
          </linearGradient>
          <filter id="glow" x="-20%" y="-20%" width="140%" height="140%">
            <feGaussianBlur stdDeviation="15" result="blur"/>
            <feComposite in="SourceGraphic" in2="blur" operator="over"/>
          </filter>
        </defs>
        <rect width="800" height="800" fill="url(#bg)"/>
        <g transform="translate(400, 340)">
          <circle cx="0" cy="0" r="160" fill="none" stroke="url(#logoGrad)" stroke-width="8" opacity="0.4"/>
          <circle cx="0" cy="0" r="130" fill="none" stroke="url(#logoGrad)" stroke-width="4" stroke-dasharray="12 8" opacity="0.7"/>
          <polygon points="0,-100 86,-50 86,50 0,100 -86,50 -86,-50" fill="url(#logoGrad)" opacity="0.15"/>
          <polygon points="0,-100 86,-50 86,50 0,100 -86,50 -86,-50" fill="none" stroke="url(#logoGrad)" stroke-width="6" filter="url(#glow)"/>
          <text x="0" y="25" font-family="'Plus Jakarta Sans', sans-serif" font-size="76" font-weight="900" fill="#ffffff" text-anchor="middle" letter-spacing="4">${initials}</text>
        </g>
        <text x="400" y="560" font-family="'Plus Jakarta Sans', sans-serif" font-size="44" font-weight="800" fill="#ffffff" text-anchor="middle" letter-spacing="2">${brandName}</text>
        <text x="400" y="605" font-family="'Plus Jakarta Sans', sans-serif" font-size="18" font-weight="600" fill="#94a3b8" text-anchor="middle" letter-spacing="6">${tagline.toUpperCase() || industry.toUpperCase()}</text>
      </svg>`;

      const svgBase64 = Buffer.from(proceduralSvg, 'utf-8').toString('base64');
      imageUrl = `data:image/svg+xml;base64,${svgBase64}`;
      imageBase64 = svgBase64;
      mimeType = 'image/svg+xml';
      modelUsed = 'procedural-vector-engine';
    }

    res.json({
      success: true,
      imageUrl,
      imageBase64,
      mimeType,
      promptUsed: enrichedPrompt,
      modelUsed,
      imageSize,
      aspectRatio,
      brandName,
    });
  } catch (error: any) {
    console.error('Logo generation error:', error);
    res.status(500).json({
      error: error.message || 'Failed to generate logo',
    });
  }
});

/**
 * 2. ANIMATE LOGO INTO VIDEO ENDPOINT
 * Uses mandatory model: gemini-omni-1.1-flash via Interactions API
 * Mandatory aspect ratios: 16:9 or 9:16
 */
app.post('/api/animate-logo', async (req, res) => {
  try {
    const {
      imageBase64,
      mimeType = 'image/png',
      motionPrompt = '',
      aspectRatio = '16:9', // '16:9' or '9:16'
      duration = '5s', // '5s' or '10s'
      motionPreset = 'Logo Reveal & Glow',
      brandName = 'Company',
      apiKeyOverride,
    } = req.body;

    if (!imageBase64) {
      return res.status(400).json({ error: 'Image base64 is required for animation.' });
    }

    // Strip data:image/...;base64, prefix if present
    const cleanBase64 = imageBase64.replace(/^data:image\/[a-z]+;base64,/, '');

    // Refine motion prompt
    const fullMotionPrompt = motionPrompt
      ? `${motionPrompt}. Maintain the integrity and iconography of the logo, fluid motion graphics, cinematic animation, 4k clarity.`
      : `Cinematic brand logo animation for "${brandName}". Style: ${motionPreset}. The logo smoothly builds up with glowing light sweeps, subtle 3D rotational perspective, ethereal particles dissolving in and out, seamless looped presentation, professional studio lighting, dark sleek background.`;

    const client = getGenAIClient(apiKeyOverride);

    console.log(`Starting video animation via Interactions API with gemini-omni-1.1-flash (aspectRatio: ${aspectRatio}, duration: ${duration})...`);

    const interaction = await client.interactions.create(
      {
        model: 'gemini-omni-1.1-flash',
        input: [
          {
            type: 'image',
            mime_type: mimeType,
            data: cleanBase64,
          },
          {
            type: 'text',
            text: fullMotionPrompt,
          },
        ],
        background: false,
        store: false,
        stream: false,
        response_format: {
          type: 'video',
          aspect_ratio: aspectRatio as '16:9' | '9:16',
          duration: duration as '5s' | '10s',
          resolution: '720p',
        },
      },
      { timeout: 300000 }
    );

    let videoUrl = '';
    let videoBase64 = '';
    let returnedMime = 'video/mp4';

    // Check interaction.output_video
    const videoPart = interaction.output_video;
    if (videoPart?.data) {
      videoBase64 = videoPart.data;
      returnedMime = videoPart.mime_type || 'video/mp4';
      videoUrl = `data:${returnedMime};base64,${videoBase64}`;
    } else if (videoPart?.uri) {
      videoUrl = videoPart.uri;
    }

    // Also search steps for any video output content
    if (!videoUrl && interaction.steps) {
      for (const step of interaction.steps) {
        if (step.type === 'model_output' && step.content) {
          const contents = step.content as any[];
          const v = contents.find((c: any) => c.type === 'video');
          if (v && v.data) {
            videoBase64 = v.data;
            returnedMime = v.mime_type || 'video/mp4';
            videoUrl = `data:${returnedMime};base64,${videoBase64}`;
            break;
          } else if (v && v.uri) {
            videoUrl = v.uri;
            break;
          }
        }
      }
    }

    if (!videoUrl) {
      throw new Error('Video animation completed but no video data was returned by the model.');
    }

    res.json({
      success: true,
      videoUrl,
      videoBase64,
      mimeType: returnedMime,
      aspectRatio,
      duration,
      motionPreset,
      promptUsed: fullMotionPrompt,
      modelUsed: 'gemini-omni-1.1-flash',
    });
  } catch (error: any) {
    console.warn('Video animation error with gemini-omni-1.1-flash:', error?.message);
    // Graceful fallback to built-in Cinematic Motion Graphics Engine
    res.json({
      success: true,
      useClientSynthesizer: true,
      notice: 'Gemini Omni Flash requires a paid API key. Activated built-in 60FPS Cinematic Motion Graphics Engine.',
      brandName: req.body?.brandName || 'Company',
      aspectRatio: req.body?.aspectRatio || '16:9',
      duration: req.body?.duration || '5s',
      motionPreset: req.body?.motionPreset || 'Logo Reveal & Glow',
      promptUsed: req.body?.motionPrompt || 'Cinematic logo reveal',
      modelUsed: 'cinematic-motion-engine',
    });
  }
});

/**
 * 3. HEY JULLI AI CHAT & MEMORY ASSISTANT
 * Online intelligence supporting Gemini or user-configured Groq API
 */
app.post('/api/chat-assistant', async (req, res) => {
  try {
    const {
      message,
      history = [],
      memories = [],
      provider = 'gemini', // 'gemini' | 'groq'
      apiKeyOverride,
      modelOverride,
      groqBaseUrl = 'https://api.groq.com/openai/v1',
    } = req.body;

    if (!message) {
      return res.status(400).json({ error: 'Message is required.' });
    }

    const memoryContext = memories.length > 0
      ? `User Memories & Important Facts to remember:\n${memories.map((m: any, idx: number) => `${idx + 1}. ${m.text}`).join('\n')}\n`
      : '';

    // Direct Image Generation in Chat via Pollinations AI (Endpoint 1 -> Endpoint 2)
    const lowerMsg = message.toLowerCase();
    const isImageIntent =
      /(image|photo|picture|pic|drawing|tasveer|paint)/i.test(lowerMsg) ||
      (/(banao|generate|create|make|draw|dikhao)/i.test(lowerMsg) && /(logo|scene|avatar|cat|dog|car|robot|anime|girl|design|flower|wallpaper|art)/i.test(lowerMsg));

    const isExplicitCreation =
      lowerMsg.includes('banao') ||
      lowerMsg.includes('generate') ||
      lowerMsg.includes('create') ||
      lowerMsg.includes('draw') ||
      lowerMsg.includes('paint') ||
      lowerMsg.includes('make') ||
      lowerMsg.includes('image') ||
      lowerMsg.includes('photo') ||
      lowerMsg.includes('tasveer');

    if (isImageIntent && isExplicitCreation) {
      console.log(`[Chat Assistant] Detected Pollinations image generation prompt: "${message}"`);
      let cleanPrompt = message
        .replace(/hey julli|julli|sir|boss|please|kripya/gi, '')
        .replace(/image banao|photo banao|tasveer banao|draw karo|generate image of|create an image of|make a photo of|picture of|ek image|ek photo/gi, '')
        .trim();

      if (!cleanPrompt) cleanPrompt = message;

      try {
        const pollResult = await fetchPollinationsImage(cleanPrompt, 1024, 1024);
        const endpointLabel = pollResult.endpointUsed.includes('gen.pollinations.ai')
          ? 'Endpoint 1 (gen.pollinations.ai)'
          : 'Endpoint 2 (image.pollinations.ai)';

        return res.json({
          success: true,
          reply: `Ji Sir! Maine Pollinations AI (${endpointLabel}) se aapke liye ye image generate kar di hai. Dekhiye Sir:`,
          generatedImage: {
            imageUrl: pollResult.imageUrl,
            prompt: cleanPrompt,
            endpointUsed: pollResult.endpointUsed,
          },
          provider: 'pollinations',
        });
      } catch (pollErr: any) {
        console.warn('Chat Pollinations generation error:', pollErr?.message);
      }
    }

    const systemInstruction = `You are "Julli", a lively, affectionate, and super-intelligent digital assistant companion (choti ladki avatar).
You speak naturally in Hindi and English mix (Hinglish), or English if preferred by the user.
Always address the user warmly as "Sir" or "Boss".
Your capabilities:
1. Help design logos and suggest creative color schemes, fonts, and slogans.
2. Animate logos into video using Gemini Omni Flash.
3. Help with calculations: offline basic (+, -, *, /) and online advanced (π, √, %, powers ^, algebra, trigonometry).
4. Simulate phone assistant features: opening apps, taking screenshots, launching camera, placing calls.
5. Remember user details ("yaad rakhna"). When the user says "yaad rakhna ...", acknowledge that you have stored it.
Keep responses concise, energetic, friendly, and helpful. Use a sweet and respectful tone.`;

    if (provider === 'groq' && apiKeyOverride) {
      // Call Groq API
      const groqUrl = `${groqBaseUrl.replace(/\/$/, '')}/chat/completions`;
      const messages = [
        { role: 'system', content: `${systemInstruction}\n${memoryContext}` },
        ...history.slice(-6).map((h: any) => ({
          role: h.role === 'assistant' ? 'assistant' : 'user',
          content: h.text,
        })),
        { role: 'user', content: message },
      ];

      const groqRes = await fetch(groqUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${apiKeyOverride}`,
        },
        body: JSON.stringify({
          model: modelOverride || 'llama-3.3-70b-versatile',
          messages,
          temperature: 0.7,
          max_tokens: 600,
        }),
      });

      if (!groqRes.ok) {
        const errText = await groqRes.text();
        throw new Error(`Groq API error (${groqRes.status}): ${errText}`);
      }

      const groqData = await groqRes.json();
      const reply = groqData.choices?.[0]?.message?.content || 'Namaste Sir! Kuch gadbad ho gayi, kripya dobara poochiye.';

      return res.json({
        success: true,
        reply,
        provider: 'groq',
        model: modelOverride || 'llama-3.3-70b-versatile',
      });
    }

    // Default: Gemini API (gemini-3.8-flash)
    const client = getGenAIClient(apiKeyOverride);
    const chatModel = modelOverride || 'gemini-3.8-flash';

    const promptWithContext = `${systemInstruction}\n\n${memoryContext}\nRecent conversation history:\n${history
      .slice(-4)
      .map((h: any) => `${h.role === 'assistant' ? 'Julli' : 'User'}: ${h.text}`)
      .join('\n')}\n\nUser: ${message}\nJulli:`;

    const response = await client.models.generateContent({
      model: chatModel,
      contents: promptWithContext,
    });

    const reply = response.text || 'Hello Sir! Main yahan hoon, bataiye kya madad kar sakti hoon?';

    res.json({
      success: true,
      reply,
      provider: 'gemini',
      model: chatModel,
    });
  } catch (error: any) {
    console.error('Chat assistant error:', error);
    res.status(500).json({
      error: error.message || 'Failed to get response from Julli',
    });
  }
});

/**
 * 4. ADVANCED ONLINE SCIENTIFIC CALCULATOR ENDPOINT
 * Handles π, √, %, powers ^, calculus, equations, etc.
 */
app.post('/api/calculate-advanced', async (req, res) => {
  try {
    const { expression } = req.body;
    if (!expression) {
      return res.status(400).json({ error: 'Expression is required.' });
    }

    const client = defaultAi;
    const mathPrompt = `You are a precision mathematical calculation engine.
Solve the following math expression or question accurately:
"${expression}"

Return ONLY a valid JSON object matching this schema:
{
  "expression": string,
  "result": string,
  "steps": string[],
  "simplified": string
}
Do not include markdown ticks, just raw JSON.`;

    const response = await client.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: mathPrompt,
    });

    const text = response.text || '{}';
    let cleanJson = text.trim();
    if (cleanJson.startsWith('```json')) {
      cleanJson = cleanJson.replace(/^```json\s*/, '').replace(/\s*```$/, '');
    } else if (cleanJson.startsWith('```')) {
      cleanJson = cleanJson.replace(/^```\s*/, '').replace(/\s*```$/, '');
    }

    try {
      const parsed = JSON.parse(cleanJson);
      res.json({ success: true, ...parsed });
    } catch {
      res.json({
        success: true,
        expression,
        result: text.trim(),
        steps: ['Direct evaluation computed'],
        simplified: text.trim(),
      });
    }
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Math calculation error' });
  }
});

/**
 * 5. TEXT-TO-SPEECH (TTS) ENDPOINT
 * Uses gemini-3.8-flash-lite-tts
 */
app.post('/api/tts', async (req, res) => {
  try {
    const { text, voice = 'Kore' } = req.body;
    if (!text) {
      return res.status(400).json({ error: 'Text is required for TTS' });
    }

    const client = defaultAi;
    const interaction = await client.interactions.create({
      model: 'gemini-3.8-flash-lite-tts',
      input: [
        {
          type: 'text',
          text,
          annotations: [
            {
              type: 'speech_metadata',
              style: 'Energetic, warm, friendly digital companion',
            },
          ],
        },
      ],
      response_format: { type: 'audio' },
      generation_config: {
        speech_config: [
          {
            language: 'en-US',
            voice,
          },
        ],
      },
    });

    const audio = interaction.output_audio;
    if (audio?.data) {
      res.json({
        success: true,
        audioBase64: audio.data,
        mimeType: audio.mime_type || 'audio/wav',
      });
    } else {
      res.status(500).json({ error: 'No audio generated' });
    }
  } catch (error: any) {
    // If TTS fails or model not enabled, client can fall back seamlessly to SpeechSynthesis
    res.status(500).json({ error: error.message || 'TTS unavailable' });
  }
});

// Configure Vite middleware for development or static serve for production
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`BrandMorph & Julli AI Studio server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
