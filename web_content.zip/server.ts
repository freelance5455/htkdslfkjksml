import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = Number(process.env.PORT) || 3000;

app.use(express.json({ limit: '20mb' }));

// Server-side GoogleGenAI client
const apiKey = process.env.GEMINI_API_KEY;
let ai: GoogleGenAI | null = null;
if (apiKey) {
  ai = new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// AI Album Cover & Visualizer Backdrop Generation Endpoint
app.post('/api/generate-cover', async (req, res) => {
  const { prompt, aspectRatio = '1:1', imageSize = '1K', model = 'gemini-3-pro-image' } = req.body;

  if (!prompt) {
    return res.status(400).json({ error: 'Prompt is required' });
  }

  if (!ai) {
    return res.status(503).json({
      error: 'GEMINI_API_KEY is not configured on the server. Please check your Settings > Secrets panel.',
    });
  }

  try {
    // Supported models based on guidelines: gemini-3-pro-image or gemini-nano-banana-2.1 or gemini-3.1-flash-lite-image
    const chosenModel = model || 'gemini-3-pro-image';
    
    // Valid standard aspect ratios: 1:1, 3:4, 4:3, 9:16, 16:9
    // Additional supported by 3-pro-image: 1:4, 1:8, 4:1, 8:1, 21:9 (mapped if needed)
    let safeAspectRatio = aspectRatio;
    if (safeAspectRatio === '21:9') {
      safeAspectRatio = '16:9'; // fallback for standard models if 21:9 is requested
    } else if (safeAspectRatio === '2:3') {
      safeAspectRatio = '3:4';
    } else if (safeAspectRatio === '3:2') {
      safeAspectRatio = '4:3';
    }

    const response = await ai.models.generateContent({
      model: chosenModel,
      contents: {
        parts: [{ text: `High quality DJ music album art, club visualizer backdrop: ${prompt}. Vivid neon glowing lights, cyan, magenta purple, laser red, cinematic EDM stage aesthetic.` }],
      },
      config: {
        imageConfig: {
          aspectRatio: safeAspectRatio as any,
          imageSize: imageSize as any,
        },
      },
    });

    for (const part of response.candidates?.[0]?.content?.parts ?? []) {
      if (part.inlineData?.data) {
        const mime = part.inlineData.mimeType ?? 'image/png';
        const imageUrl = `data:${mime};base64,${part.inlineData.data}`;
        return res.json({ imageUrl, prompt, aspectRatio, imageSize });
      }
    }

    // If no inline image was returned, check text
    const textPart = response.candidates?.[0]?.content?.parts?.[0]?.text;
    return res.status(500).json({
      error: textPart || 'No image part was returned from the model.',
    });
  } catch (error: any) {
    console.error('Image generation error:', error);
    return res.status(500).json({
      error: error?.message || 'Failed to generate visual artwork.',
    });
  }
});

// Health check endpoint
app.get('/api/health', (_req, res) => {
  res.json({ status: 'ok', app: 'DJ SUNNY MUSIC', hasApiKey: !!apiKey });
});

async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';

  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`🎵 DJ SUNNY MUSIC server listening on port ${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
