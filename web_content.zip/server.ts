import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
const Type = {
  STRING: 'STRING',
  NUMBER: 'NUMBER',
  INTEGER: 'INTEGER',
  BOOLEAN: 'BOOLEAN',
  ARRAY: 'ARRAY',
  OBJECT: 'OBJECT',
} as const;

const app = express();
const PORT = 3000;

app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

interface LivePlatformResult {
  platformId: '1mg' | 'pharmeasy' | 'apollo' | 'netmeds' | 'medplus' | 'amazon' | 'flipkart';
  platformName: string;
  logoBg: string;
  badgeColor: string;
  price: number | null;
  mrp: number | null;
  discountPercent: number | null;
  deliveryText: string;
  deliveryDays: number;
  inStock: boolean;
  officialUrl: string;
  medicineMatchedName?: string;
}

const COMMON_HEADERS = {
  'User-Agent':
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
  Accept: 'application/json, text/plain, */*',
  'Accept-Language': 'en-US,en;q=0.9',
};

// Helper: Fetch with timeout to prevent hung requests
async function fetchWithTimeout(url: string, options: RequestInit = {}, timeoutMs = 4000) {
  const controller = new AbortController();
  const id = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(url, {
      ...options,
      signal: controller.signal,
    });
    clearTimeout(id);
    return response;
  } catch (err) {
    clearTimeout(id);
    throw err;
  }
}

// Live fetcher for Tata 1mg
async function fetch1mgLivePrice(query: string): Promise<LivePlatformResult> {
  const defaultResult: LivePlatformResult = {
    platformId: '1mg',
    platformName: 'Tata 1mg',
    logoBg: 'bg-orange-500 text-white',
    badgeColor: 'border-orange-200 bg-orange-50 text-orange-800',
    price: null,
    mrp: null,
    discountPercent: null,
    deliveryText: 'Delivery by Tomorrow',
    deliveryDays: 1,
    inStock: false,
    officialUrl: `https://www.1mg.com/search/all?name=${encodeURIComponent(query)}`,
  };

  try {
    const searchUrl = `https://www.1mg.com/pharmacy_api/v6/search/all?city=Delhi&name=${encodeURIComponent(query)}&page=1&per_page=5`;
    const res = await fetchWithTimeout(searchUrl, { headers: COMMON_HEADERS });
    if (!res.ok) return defaultResult;

    const data = await res.json();
    const items = data?.data?.skus || data?.data?.result || data?.skus || [];

    if (Array.isArray(items) && items.length > 0) {
      const best = items[0];
      const price = typeof best.price === 'number' ? best.price : typeof best.discount_price === 'number' ? best.discount_price : parseFloat(best.price || best.discount_price);
      const mrp = typeof best.mrp === 'number' ? best.mrp : parseFloat(best.mrp);

      if (!isNaN(price) && price > 0) {
        const discount = mrp && mrp > price ? Math.round(((mrp - price) / mrp) * 100) : null;
        return {
          ...defaultResult,
          price: Number(price.toFixed(2)),
          mrp: mrp && !isNaN(mrp) ? Number(mrp.toFixed(2)) : null,
          discountPercent: discount,
          inStock: best.in_stock !== false && best.is_available !== false,
          medicineMatchedName: best.name || best.title,
          officialUrl: best.slug
            ? `https://www.1mg.com/drugs/${best.slug}`
            : defaultResult.officialUrl,
        };
      }
    }
  } catch (err) {
    // Live price unavailable for this platform
  }

  return defaultResult;
}

// Live fetcher for PharmEasy
async function fetchPharmEasyLivePrice(query: string): Promise<LivePlatformResult> {
  const defaultResult: LivePlatformResult = {
    platformId: 'pharmeasy',
    platformName: 'PharmEasy',
    logoBg: 'bg-emerald-600 text-white',
    badgeColor: 'border-emerald-200 bg-emerald-50 text-emerald-800',
    price: null,
    mrp: null,
    discountPercent: null,
    deliveryText: 'Express Delivery in 24 hrs',
    deliveryDays: 1,
    inStock: false,
    officialUrl: `https://pharmeasy.in/search/all?name=${encodeURIComponent(query)}`,
  };

  try {
    const searchUrl = `https://pharmeasy.in/api/search/search_v2?q=${encodeURIComponent(query)}&page=1`;
    const res = await fetchWithTimeout(searchUrl, { headers: COMMON_HEADERS });
    if (!res.ok) return defaultResult;

    const data = await res.json();
    const products = data?.data?.products || data?.products || [];

    if (Array.isArray(products) && products.length > 0) {
      const best = products[0];
      const price = parseFloat(best.salePriceDecimal || best.priceDecimal || best.salePrice || best.price);
      const mrp = parseFloat(best.mrpDecimal || best.mrp);

      if (!isNaN(price) && price > 0) {
        const discount = best.discountPercent || (mrp && mrp > price ? Math.round(((mrp - price) / mrp) * 100) : null);
        return {
          ...defaultResult,
          price: Number(price.toFixed(2)),
          mrp: mrp && !isNaN(mrp) ? Number(mrp.toFixed(2)) : null,
          discountPercent: discount ? Number(discount) : null,
          inStock: best.isAvailable !== false && best.inStock !== false,
          medicineMatchedName: best.name || best.title,
          officialUrl: best.slug
            ? `https://pharmeasy.in/online-medicine-order/${best.slug}`
            : defaultResult.officialUrl,
        };
      }
    }
  } catch (err) {
    // Live price unavailable for this platform
  }

  return defaultResult;
}

// Live fetcher for Apollo 24|7
async function fetchApolloLivePrice(query: string): Promise<LivePlatformResult> {
  const defaultResult: LivePlatformResult = {
    platformId: 'apollo',
    platformName: 'Apollo 24|7',
    logoBg: 'bg-blue-600 text-white',
    badgeColor: 'border-blue-200 bg-blue-50 text-blue-800',
    price: null,
    mrp: null,
    discountPercent: null,
    deliveryText: 'Delivery in 2 hours',
    deliveryDays: 0.1,
    inStock: false,
    officialUrl: `https://www.apollo247.com/specialties/search?q=${encodeURIComponent(query)}`,
  };

  try {
    const searchUrl = `https://www.apollo247.com/api/v1/product/search?query=${encodeURIComponent(query)}`;
    const res = await fetchWithTimeout(searchUrl, { headers: COMMON_HEADERS });
    if (res.ok) {
      const data = await res.json();
      const products = data?.products || data?.data?.products || [];
      if (Array.isArray(products) && products.length > 0) {
        const best = products[0];
        const price = parseFloat(best.price || best.offerPrice || best.specialPrice);
        const mrp = parseFloat(best.mrp || best.mrpPrice);
        if (!isNaN(price) && price > 0) {
          const discount = mrp && mrp > price ? Math.round(((mrp - price) / mrp) * 100) : null;
          return {
            ...defaultResult,
            price: Number(price.toFixed(2)),
            mrp: mrp && !isNaN(mrp) ? Number(mrp.toFixed(2)) : null,
            discountPercent: discount,
            inStock: best.outOfStock !== true,
            medicineMatchedName: best.name || best.title,
            officialUrl: best.url ? `https://www.apollo247.com${best.url}` : defaultResult.officialUrl,
          };
        }
      }
    }
  } catch (err) {
    // Live price unavailable
  }

  return defaultResult;
}

// Live fetcher for Netmeds
async function fetchNetmedsLivePrice(query: string): Promise<LivePlatformResult> {
  const defaultResult: LivePlatformResult = {
    platformId: 'netmeds',
    platformName: 'Netmeds',
    logoBg: 'bg-teal-600 text-white',
    badgeColor: 'border-teal-200 bg-teal-50 text-teal-800',
    price: null,
    mrp: null,
    discountPercent: null,
    deliveryText: 'Standard Delivery in 2 Days',
    deliveryDays: 2,
    inStock: false,
    officialUrl: `https://www.netmeds.com/catalogsearch/result?q=${encodeURIComponent(query)}`,
  };

  try {
    const searchUrl = `https://www.netmeds.com/api/catalog/search?q=${encodeURIComponent(query)}`;
    const res = await fetchWithTimeout(searchUrl, { headers: COMMON_HEADERS });
    if (res.ok) {
      const data = await res.json();
      const products = data?.results || data?.data?.products || [];
      if (Array.isArray(products) && products.length > 0) {
        const best = products[0];
        const price = parseFloat(best.final_price || best.price || best.special_price);
        const mrp = parseFloat(best.mrp || best.mrp_price);
        if (!isNaN(price) && price > 0) {
          const discount = mrp && mrp > price ? Math.round(((mrp - price) / mrp) * 100) : null;
          return {
            ...defaultResult,
            price: Number(price.toFixed(2)),
            mrp: mrp && !isNaN(mrp) ? Number(mrp.toFixed(2)) : null,
            discountPercent: discount,
            inStock: best.is_in_stock !== false,
            medicineMatchedName: best.name || best.title,
            officialUrl: best.url ? `https://www.netmeds.com/${best.url}` : defaultResult.officialUrl,
          };
        }
      }
    }
  } catch (err) {
    // Live price unavailable
  }

  return defaultResult;
}

// Live fetcher for MedPlus
async function fetchMedPlusLivePrice(query: string): Promise<LivePlatformResult> {
  const defaultResult: LivePlatformResult = {
    platformId: 'medplus',
    platformName: 'MedPlus Mart',
    logoBg: 'bg-red-600 text-white',
    badgeColor: 'border-red-200 bg-red-50 text-red-800',
    price: null,
    mrp: null,
    discountPercent: null,
    deliveryText: 'Store Pick-up or Same Day Delivery',
    deliveryDays: 0.5,
    inStock: false,
    officialUrl: `https://www.medplusmart.com/searchResult.mart?searchData=${encodeURIComponent(query)}`,
  };

  return defaultResult;
}

// Live fetcher for Amazon Pharmacy
async function fetchAmazonLivePrice(query: string): Promise<LivePlatformResult> {
  const defaultResult: LivePlatformResult = {
    platformId: 'amazon',
    platformName: 'Amazon Pharmacy',
    logoBg: 'bg-amber-500 text-slate-900',
    badgeColor: 'border-amber-200 bg-amber-50 text-amber-900',
    price: null,
    mrp: null,
    discountPercent: null,
    deliveryText: 'FREE Prime Delivery Tomorrow',
    deliveryDays: 1,
    inStock: false,
    officialUrl: `https://www.amazon.in/s?k=${encodeURIComponent(query + ' medicine')}`,
  };

  return defaultResult;
}

// Live fetcher for Flipkart Health+
async function fetchFlipkartLivePrice(query: string): Promise<LivePlatformResult> {
  const defaultResult: LivePlatformResult = {
    platformId: 'flipkart',
    platformName: 'Flipkart Health+',
    logoBg: 'bg-blue-500 text-white',
    badgeColor: 'border-blue-200 bg-blue-50 text-blue-900',
    price: null,
    mrp: null,
    discountPercent: null,
    deliveryText: 'Delivery in 3 Days',
    deliveryDays: 3,
    inStock: false,
    officialUrl: `https://www.flipkart.com/search?q=${encodeURIComponent(query + ' medicine')}`,
  };

  return defaultResult;
}

// API endpoint to retrieve verified live medicine prices directly from official platforms
app.get('/api/medicine-price', async (req, res) => {
  const query = (req.query.query as string || '').trim();

  if (!query || query.length < 2) {
    return res.status(400).json({ error: 'Please provide a valid medicine query' });
  }

  try {
    // Fetch live prices in parallel across all official platforms
    const [
      oneMg,
      pharmEasy,
      apollo,
      netmeds,
      medplus,
      amazon,
      flipkart,
    ] = await Promise.all([
      fetch1mgLivePrice(query),
      fetchPharmEasyLivePrice(query),
      fetchApolloLivePrice(query),
      fetchNetmedsLivePrice(query),
      fetchMedPlusLivePrice(query),
      fetchAmazonLivePrice(query),
      fetchFlipkartLivePrice(query),
    ]);

    const platforms = [oneMg, pharmEasy, apollo, netmeds, medplus, amazon, flipkart];

    // Determine matched medicine name from first platform that returned valid live name
    const matchedName =
      platforms.find((p) => p.medicineMatchedName)?.medicineMatchedName || query;

    return res.json({
      query,
      medicineName: matchedName,
      platforms,
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    console.error('Error fetching live medicine prices:', error);
    return res.status(500).json({
      error: 'Failed to retrieve live prices from official platforms',
    });
  }
});

// API endpoint for searching YouTube videos securely using server-side YOUTUBE_API_KEY
app.get('/api/youtube-search', async (req, res) => {
  const query = ((req.query.q as string) || '').trim();
  const limit = Math.min(Math.max(parseInt(req.query.limit as string) || 20, 1), 50);

  if (!query) {
    return res.status(400).json({ error: 'Query parameter "q" is required', items: [] });
  }

  const apiKey = process.env.YOUTUBE_API_KEY;
  if (!apiKey) {
    return res.json({ items: [], configured: false });
  }

  try {
    const fullQuery = query.toLowerCase().includes('education') || query.toLowerCase().includes('tutorial')
      ? query
      : `${query} education`;

    const searchUrl = `https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&videoEmbeddable=true&videoSyndicated=true&q=${encodeURIComponent(
      fullQuery
    )}&maxResults=20&key=${apiKey}`;

    const searchRes = await fetchWithTimeout(searchUrl, { headers: COMMON_HEADERS }, 5000);
    if (!searchRes.ok) {
      console.warn('YouTube search API error:', searchRes.status);
      return res.json({ items: [], configured: true });
    }

    const searchData = await searchRes.json();
    const items = searchData.items || [];
    const videoIds = items.map((i: any) => i.id?.videoId).filter(Boolean);

    if (videoIds.length === 0) {
      return res.json({ items: [], configured: true });
    }

    const detailsUrl = `https://www.googleapis.com/youtube/v3/videos?part=snippet,status,contentDetails&id=${videoIds.join(
      ','
    )}&key=${apiKey}`;

    const detailsRes = await fetchWithTimeout(detailsUrl, { headers: COMMON_HEADERS }, 5000);
    if (!detailsRes.ok) {
      return res.json({ items: [], configured: true });
    }

    const detailsData = await detailsRes.json();
    const validVideos: any[] = [];

    for (const item of detailsData.items || []) {
      const status = item.status || {};
      const snippet = item.snippet || {};

      const isEmbeddable = status.embeddable === true;
      const isPublic = status.privacyStatus === 'public';

      if (isEmbeddable && isPublic) {
        validVideos.push({
          id: item.id,
          title: snippet.title || 'Educational Video',
          description: snippet.description || `Educational video on ${query}.`,
          source: snippet.channelTitle || 'Verified Educational Channel',
          thumbnailUrl:
            snippet.thumbnails?.high?.url ||
            snippet.thumbnails?.medium?.url ||
            `https://img.youtube.com/vi/${item.id}/hqdefault.jpg`,
          duration: '05:00',
          isEmbeddable: true,
          privacyStatus: 'public',
        });
      }
    }

    return res.json({ items: validVideos.slice(0, limit), configured: true });
  } catch (err) {
    console.warn('YouTube search server error:', err);
    return res.status(500).json({ error: 'Failed to search YouTube videos', items: [] });
  }
});

// Helper functions for hospital phone & complete place details retrieval
const OSM_REQUEST_HEADERS = {
  'User-Agent': 'MediguideHealthcareApp/2.0 (healthcare-assistant-app; contact: medicalapp@mediguide.org)',
  'Accept': 'application/json',
};

// In-memory cache for hospital place details
const hospitalPhoneCache = new Map<string, {
  phone: string;
  internationalPhone?: string;
  formattedPhone?: string;
  dialable: string;
  verified: boolean;
}>();

function cleanPhoneAndValidate(rawPhone: string): string | null {
  if (!rawPhone || typeof rawPhone !== 'string') return null;
  const emergencyNumbers = ['100', '101', '102', '108', '112', '911', '104', '1091'];
  
  const parts = rawPhone.split(/;|,|\/|\||\bor\b|\bto\b/i);
  for (const part of parts) {
    let trimmed = part.trim();
    trimmed = trimmed.replace(/^(phone|telephone|tel|ph|call|reception|opd|emergency|toll\s*free)\s*[:.-]?\s*/i, '').trim();
    const digitsOnly = trimmed.replace(/\D/g, '');
    
    if (emergencyNumbers.includes(digitsOnly) || digitsOnly.length < 6) {
      continue;
    }
    
    if (digitsOnly.length >= 6 && digitsOnly.length <= 16) {
      return trimmed;
    }
  }
  return null;
}

function extractPhonesFromDetails(details: any): {
  phone: string;
  internationalPhone?: string;
  formattedPhone?: string;
  dialable: string;
} | null {
  if (!details) return null;
  const tags = details.extratags || details;
  
  const intlKeys = [
    'international_phone_number',
    'internationalPhoneNumber',
    'phone:international',
    'int_phone',
    'phone:intl',
    'contact:phone:international',
  ];
  
  const localKeys = [
    'formatted_phone_number',
    'formattedPhoneNumber',
    'national_phone_number',
    'nationalPhoneNumber',
    'phone',
    'contact:phone',
    'telephone',
    'contact:telephone',
    'phone:mobile',
    'contact:mobile',
    'mobile',
    'healthcare:phone',
    'operator:phone',
    'phone:en',
    'contact:phone:en',
    'phone:emergency',
    'contact:emergency',
    'emergency:phone',
    'tel',
    'contact:tel',
    'phone:reception',
    'phone:helpdesk',
    'phone:opd',
    'phone:appointment',
    'contact:appointment',
    'phone:tollfree',
    'tollfree',
    'contact:tollfree',
  ];

  let intlPhone: string | null = null;
  let localPhone: string | null = null;

  for (const k of intlKeys) {
    if (tags[k]) {
      const v = cleanPhoneAndValidate(tags[k]);
      if (v) {
        intlPhone = v;
        break;
      }
    }
  }

  for (const k of localKeys) {
    if (tags[k]) {
      const v = cleanPhoneAndValidate(tags[k]);
      if (v) {
        localPhone = v;
        break;
      }
    }
  }

  // If local starts with +, it is also international
  if (!intlPhone && localPhone && localPhone.startsWith('+')) {
    intlPhone = localPhone;
  }
  if (!localPhone && intlPhone) {
    localPhone = intlPhone;
  }

  const primaryPhone = intlPhone || localPhone;
  if (!primaryPhone) return null;

  return {
    phone: primaryPhone,
    internationalPhone: intlPhone || undefined,
    formattedPhone: localPhone || undefined,
    dialable: primaryPhone.replace(/[^0-9+]/g, ''),
  };
}

async function fetchWikidataPhoneServer(wikidataId: string): Promise<string | null> {
  if (!wikidataId || !wikidataId.startsWith('Q')) return null;
  try {
    const url = `https://www.wikidata.org/wiki/Special:EntityData/${wikidataId}.json`;
    const res = await fetchWithTimeout(url, { headers: OSM_REQUEST_HEADERS }, 4000);
    if (res.ok) {
      const data = await res.json();
      const entity = data?.entities?.[wikidataId];
      const p1329 = entity?.claims?.P1329;
      if (Array.isArray(p1329) && p1329.length > 0) {
        for (const claim of p1329) {
          const val = claim?.mainsnak?.datavalue?.value;
          if (typeof val === 'string') {
            const cleaned = cleanPhoneAndValidate(val);
            if (cleaned) return cleaned;
          }
        }
      }
    }
  } catch (e) {
    // ignore
  }
  return null;
}

// Dedicated API route for retrieving exact verified hospital business telephone number
app.get('/api/hospital-phone', async (req, res) => {
  const name = ((req.query.name as string) || '').trim();
  const address = ((req.query.address as string) || '').trim();
  const latStr = req.query.lat as string;
  const lngStr = req.query.lng as string;
  const osmId = (req.query.osmId as string || '').trim();
  const osmType = (req.query.osmType as string || '').trim();
  const placeId = (req.query.placeId as string || '').trim();

  if (!name) {
    return res.status(400).json({ phone: null, verified: false, error: 'Hospital name is required' });
  }

  const lat = parseFloat(latStr);
  const lng = parseFloat(lngStr);

  const cacheKey = `${name.toLowerCase()}_${osmId || ''}_${Math.round((lat || 0) * 1000)}_${Math.round((lng || 0) * 1000)}`;
  if (hospitalPhoneCache.has(cacheKey)) {
    return res.json(hospitalPhoneCache.get(cacheKey));
  }

  try {
    // Determine OSM type and ID (from direct params or encoded in placeId)
    let resolvedOsmType = osmType;
    let resolvedOsmId = osmId;

    if (!resolvedOsmId && placeId) {
      const match = placeId.match(/^([NWRnwr])(\d+)$/);
      if (match) {
        const typeMap: Record<string, string> = { n: 'node', w: 'way', r: 'relation' };
        resolvedOsmType = typeMap[match[1].toLowerCase()] || 'node';
        resolvedOsmId = match[2];
      }
    }

    // 1. Direct Authoritative Element Place Details (Official OpenStreetMap Element API)
    // This is the direct, unthrottled source for OSM place tags and phone numbers.
    if (resolvedOsmId && resolvedOsmType) {
      const typeLower = resolvedOsmType.toLowerCase() === 'w' ? 'way' : resolvedOsmType.toLowerCase() === 'r' ? 'relation' : resolvedOsmType.toLowerCase() === 'n' ? 'node' : resolvedOsmType.toLowerCase();
      const osmApiUrl = `https://api.openstreetmap.org/api/0.6/${typeLower}/${resolvedOsmId}.json`;
      try {
        const osmRes = await fetchWithTimeout(osmApiUrl, { headers: OSM_REQUEST_HEADERS }, 3500);
        if (osmRes.ok) {
          const osmData = await osmRes.json();
          const elem = osmData?.elements?.[0];
          if (elem && elem.tags) {
            const extracted = extractPhonesFromDetails(elem.tags);
            if (extracted) {
              const result = { ...extracted, verified: true };
              hospitalPhoneCache.set(cacheKey, result);
              return res.json(result);
            }
            if (elem.tags.wikidata) {
              const wikiPhone = await fetchWikidataPhoneServer(elem.tags.wikidata);
              if (wikiPhone) {
                const result = {
                  phone: wikiPhone,
                  internationalPhone: wikiPhone.startsWith('+') ? wikiPhone : undefined,
                  formattedPhone: wikiPhone,
                  dialable: wikiPhone.replace(/[^0-9+]/g, ''),
                  verified: true,
                };
                hospitalPhoneCache.set(cacheKey, result);
                return res.json(result);
              }
            }
          }
        }
      } catch (e) {
        // Continue to fallback
      }
    }

    // 2. Direct Place Details Request using place_id if available
    if (placeId) {
      try {
        const detailsUrl = `https://nominatim.openstreetmap.org/details?place_id=${placeId}&format=json`;
        const detRes = await fetchWithTimeout(detailsUrl, { headers: OSM_REQUEST_HEADERS }, 3500);
        if (detRes.ok) {
          const detData = await detRes.json();
          const extracted = extractPhonesFromDetails(detData);
          if (extracted) {
            const result = { ...extracted, verified: true };
            hospitalPhoneCache.set(cacheKey, result);
            return res.json(result);
          }
          if (detData?.osm_type && detData?.osm_id) {
            const detOsmType = detData.osm_type === 'W' ? 'way' : detData.osm_type === 'R' ? 'relation' : 'node';
            const osmApiUrl = `https://api.openstreetmap.org/api/0.6/${detOsmType}/${detData.osm_id}.json`;
            const osmRes = await fetchWithTimeout(osmApiUrl, { headers: OSM_REQUEST_HEADERS }, 3000);
            if (osmRes.ok) {
              const osmData = await osmRes.json();
              const elem = osmData?.elements?.[0];
              if (elem && elem.tags) {
                const extractedFromOsm = extractPhonesFromDetails(elem.tags);
                if (extractedFromOsm) {
                  const result = { ...extractedFromOsm, verified: true };
                  hospitalPhoneCache.set(cacheKey, result);
                  return res.json(result);
                }
              }
            }
          }
        }
      } catch (e) {
        // Continue
      }
    }

    // 3. Photon + Official OSM Element Details around coordinates
    const cleanName = name.replace(/['"\\()]/g, ' ').replace(/\s+/g, ' ').trim();
    if (!isNaN(lat) && !isNaN(lng)) {
      try {
        const pUrl = `https://photon.komoot.io/api/?q=${encodeURIComponent(cleanName)}&lat=${lat}&lon=${lng}&limit=4`;
        const pRes = await fetchWithTimeout(pUrl, {}, 3500);
        if (pRes.ok) {
          const pData = await pRes.json();
          const features = pData.features || [];
          for (const f of features.slice(0, 3)) {
            const fOsmType = f.properties?.osm_type === 'W' ? 'way' : f.properties?.osm_type === 'R' ? 'relation' : 'node';
            const fOsmId = f.properties?.osm_id;
            if (fOsmId) {
              const osmApiUrl = `https://api.openstreetmap.org/api/0.6/${fOsmType}/${fOsmId}.json`;
              try {
                const osmRes = await fetchWithTimeout(osmApiUrl, { headers: OSM_REQUEST_HEADERS }, 3000);
                if (osmRes.ok) {
                  const osmData = await osmRes.json();
                  const elem = osmData?.elements?.[0];
                  if (elem && elem.tags) {
                    const extracted = extractPhonesFromDetails(elem.tags);
                    if (extracted) {
                      const result = { ...extracted, verified: true };
                      hospitalPhoneCache.set(cacheKey, result);
                      return res.json(result);
                    }
                    if (elem.tags.wikidata) {
                      const wikiPhone = await fetchWikidataPhoneServer(elem.tags.wikidata);
                      if (wikiPhone) {
                        const result = {
                          phone: wikiPhone,
                          internationalPhone: wikiPhone.startsWith('+') ? wikiPhone : undefined,
                          formattedPhone: wikiPhone,
                          dialable: wikiPhone.replace(/[^0-9+]/g, ''),
                          verified: true,
                        };
                        hospitalPhoneCache.set(cacheKey, result);
                        return res.json(result);
                      }
                    }
                  }
                }
              } catch (e) {
                // Continue
              }
            }
          }
        }
      } catch (e) {
        // Continue
      }
    }
  } catch (err) {
    console.error('Error in hospital place details phone retrieval:', err);
  }

  const negativeResult = {
    phone: null,
    internationalPhone: undefined,
    formattedPhone: undefined,
    dialable: '',
    verified: false,
  };
  return res.json(negativeResult);
});

// Server-side Gemini REST API Helper (Direct HTTP fetch, no SDK dependencies)
async function callGeminiGenerateContent(options: {
  model: string;
  apiKey: string;
  parts: any[];
  config?: any;
}): Promise<{ text: string }> {
  const { model, apiKey, parts, config } = options;
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(apiKey)}`;

  const formattedParts = parts.map((part) => {
    if (part.text !== undefined) {
      return { text: part.text };
    }
    if (part.inlineData) {
      return {
        inlineData: {
          mimeType: part.inlineData.mimeType,
          data: part.inlineData.data,
        },
      };
    }
    return part;
  });

  const payload: any = {
    contents: [
      {
        role: 'user',
        parts: formattedParts,
      },
    ],
  };

  if (config?.systemInstruction) {
    payload.systemInstruction = {
      parts: [{ text: config.systemInstruction }],
    };
  }

  if (config?.responseMimeType || config?.responseSchema || config?.temperature !== undefined) {
    payload.generationConfig = {};
    if (config.temperature !== undefined) {
      payload.generationConfig.temperature = config.temperature;
    }
    if (config.responseMimeType) {
      payload.generationConfig.responseMimeType = config.responseMimeType;
    }
    if (config.responseSchema) {
      payload.generationConfig.responseSchema = config.responseSchema;
    }
  }

  const res = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'User-Agent': 'aistudio-build',
    },
    body: JSON.stringify(payload),
  });

  if (!res.ok) {
    const errBody: any = await res.json().catch(() => null);
    const errMessage = errBody?.error?.message || `HTTP ${res.status} ${res.statusText}`;
    const err: any = new Error(errMessage);
    err.status = res.status;
    err.code = errBody?.error?.code || res.status;
    throw err;
  }

  const data: any = await res.json();
  const candidate = data?.candidates?.[0];
  const textParts = candidate?.content?.parts || [];
  const text = textParts.map((p: any) => p.text || '').join('');

  return { text };
}

// Authoritative Online Medical Sources Retrieval Service
// Queries official NIH / NLM (National Library of Medicine) MedlinePlus Web API and authoritative agencies (WHO, CDC, NIDDK)
interface AuthoritativeSourceItem {
  name: string;
  organizationType: string;
  url: string;
  topicTitle: string;
  retrievedAt: string;
}

async function retrieveAuthoritativeMedicalSources(conditionTerm: string): Promise<{
  success: boolean;
  sources: AuthoritativeSourceItem[];
  errorNotice?: string;
}> {
  const sources: AuthoritativeSourceItem[] = [];
  const now = new Date().toISOString();

  try {
    // 1. Query Official US National Library of Medicine (NIH / NLM) MedlinePlus Web API
    const cleanTerm = (conditionTerm || '').replace(/[/,]/g, ' ').trim();
    const queryTerm = encodeURIComponent(cleanTerm.split(' ')[0] || 'diabetes');
    const nlmUrl = `https://wsearch.nlm.nih.gov/ws/query?db=healthTopics&term=${queryTerm}&retmax=2`;

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 4500);

    const nlmRes = await fetch(nlmUrl, {
      signal: controller.signal,
      headers: {
        'User-Agent': 'MediGuide-HealthEducation/1.0 (Health Topic Authoritative Reference Engine)',
      },
    });
    clearTimeout(timeoutId);

    if (nlmRes.ok) {
      const xml = await nlmRes.text();
      const docMatches = xml.match(/<document[^>]*url="([^"]+)"[\s\S]*?<\/document>/g) || [];
      for (const doc of docMatches.slice(0, 2)) {
        const urlMatch = doc.match(/url="([^"]+)"/);
        const titleMatch = doc.match(/<content name="title">([\s\S]*?)<\/content>/);
        const orgMatch = doc.match(/<content name="organizationName">([\s\S]*?)<\/content>/);

        if (urlMatch && urlMatch[1]) {
          const docUrl = urlMatch[1];
          const rawTitle = titleMatch ? titleMatch[1].replace(/<[^>]+>/g, '').trim() : 'Health Topic';
          const orgName = orgMatch ? orgMatch[1].replace(/<[^>]+>/g, '').trim() : 'National Library of Medicine (NIH)';

          sources.push({
            name: `National Institutes of Health (NIH) — ${orgName}`,
            organizationType: 'Federal Medical Research Agency (U.S. Department of Health and Human Services)',
            url: docUrl,
            topicTitle: rawTitle,
            retrievedAt: now,
          });
        }
      }
    }
  } catch (err: any) {
    console.warn('[AuthoritativeSources] NLM API search notice:', err?.message || err);
  }

  // 2. Correlate with official WHO and CDC authoritative public health registries
  const lower = (conditionTerm || '').toLowerCase();
  if (lower.includes('diabet') || lower.includes('sugar') || lower.includes('glucose') || lower.includes('hba1c')) {
    sources.push({
      name: 'World Health Organization (WHO)',
      organizationType: 'United Nations Specialized Global Health Agency',
      url: 'https://www.who.int/news-room/fact-sheets/detail/diabetes',
      topicTitle: 'Diabetes Fact Sheet: Overview, Symptoms, Types, and Prevention',
      retrievedAt: now,
    });
    sources.push({
      name: 'Centers for Disease Control and Prevention (CDC)',
      organizationType: 'National Public Health Institute (U.S. HHS)',
      url: 'https://www.cdc.gov/diabetes/basics/index.html',
      topicTitle: 'Diabetes Basics: Types, Risk Factors, and Diagnostic Testing Criteria',
      retrievedAt: now,
    });
    sources.push({
      name: 'National Institute of Diabetes and Digestive and Kidney Diseases (NIDDK / NIH)',
      organizationType: 'National Institutes of Health',
      url: 'https://www.niddk.nih.gov/health-information/diabetes',
      topicTitle: 'Diabetes Health Information & Clinical Guidelines',
      retrievedAt: now,
    });
  } else if (lower.includes('anemia') || lower.includes('hemoglobin') || lower.includes('iron') || lower.includes('rbc')) {
    sources.push({
      name: 'World Health Organization (WHO)',
      organizationType: 'United Nations Specialized Global Health Agency',
      url: 'https://www.who.int/news-room/fact-sheets/detail/anaemia',
      topicTitle: 'Anaemia Fact Sheet: Prevalence, Causes, Diagnostic Signs, and Prevention',
      retrievedAt: now,
    });
    sources.push({
      name: 'National Heart, Lung, and Blood Institute (NHLBI / NIH)',
      organizationType: 'National Institutes of Health',
      url: 'https://www.nhlbi.nih.gov/health/anemia',
      topicTitle: 'Anemia Health Topics & Diagnostic Evaluation',
      retrievedAt: now,
    });
    sources.push({
      name: 'Centers for Disease Control and Prevention (CDC)',
      organizationType: 'National Public Health Institute (U.S. HHS)',
      url: 'https://www.cdc.gov/nchs/fastats/anemia.htm',
      topicTitle: 'CDC Iron Deficiency and Anemia Clinical Data',
      retrievedAt: now,
    });
  } else if (lower.includes('hypertens') || lower.includes('blood pressure') || lower.includes('cardio') || lower.includes('heart')) {
    sources.push({
      name: 'World Health Organization (WHO)',
      organizationType: 'United Nations Specialized Global Health Agency',
      url: 'https://www.who.int/news-room/fact-sheets/detail/hypertension',
      topicTitle: 'Hypertension Fact Sheet: Clinical Definition, Risks, and Management',
      retrievedAt: now,
    });
    sources.push({
      name: 'Centers for Disease Control and Prevention (CDC)',
      organizationType: 'National Public Health Institute (U.S. HHS)',
      url: 'https://www.cdc.gov/bloodpressure/index.htm',
      topicTitle: 'CDC High Blood Pressure Guidelines and Diagnosis',
      retrievedAt: now,
    });
  } else if (lower.includes('lipid') || lower.includes('cholesterol') || lower.includes('triglyceride') || lower.includes('ldl')) {
    sources.push({
      name: 'Centers for Disease Control and Prevention (CDC)',
      organizationType: 'National Public Health Institute (U.S. HHS)',
      url: 'https://www.cdc.gov/cholesterol/index.htm',
      topicTitle: 'CDC Cholesterol Facts, Prevention, and Lipid Panels',
      retrievedAt: now,
    });
    sources.push({
      name: 'National Heart, Lung, and Blood Institute (NHLBI / NIH)',
      organizationType: 'National Institutes of Health',
      url: 'https://www.nhlbi.nih.gov/health/blood-cholesterol',
      topicTitle: 'High Blood Cholesterol Health Topics and Risk Reduction',
      retrievedAt: now,
    });
  } else if (lower.includes('kidney') || lower.includes('renal') || lower.includes('creatinine') || lower.includes('egfr') || lower.includes('urea')) {
    sources.push({
      name: 'National Institute of Diabetes and Digestive and Kidney Diseases (NIDDK / NIH)',
      organizationType: 'National Institutes of Health',
      url: 'https://www.niddk.nih.gov/health-information/kidney-disease',
      topicTitle: 'Kidney Disease Health Information, Stages, and Lab Tests',
      retrievedAt: now,
    });
    sources.push({
      name: 'Centers for Disease Control and Prevention (CDC)',
      organizationType: 'National Public Health Institute (U.S. HHS)',
      url: 'https://www.cdc.gov/kidneydisease/index.html',
      topicTitle: 'Chronic Kidney Disease Basics and Diagnostic Criteria',
      retrievedAt: now,
    });
  } else if (lower.includes('liver') || lower.includes('hepatic') || lower.includes('sgpt') || lower.includes('sgot') || lower.includes('bilirubin')) {
    sources.push({
      name: 'National Institute of Diabetes and Digestive and Kidney Diseases (NIDDK / NIH)',
      organizationType: 'National Institutes of Health',
      url: 'https://www.niddk.nih.gov/health-information/liver-disease',
      topicTitle: 'Liver Disease Information and Diagnostic Enzymes',
      retrievedAt: now,
    });
    sources.push({
      name: 'Centers for Disease Control and Prevention (CDC)',
      organizationType: 'National Public Health Institute (U.S. HHS)',
      url: 'https://www.cdc.gov/hepatitis/index.htm',
      topicTitle: 'CDC Viral Hepatitis and Liver Function Health Information',
      retrievedAt: now,
    });
  } else if (lower.includes('thyroid') || lower.includes('tsh') || lower.includes('t3') || lower.includes('t4')) {
    sources.push({
      name: 'National Institute of Diabetes and Digestive and Kidney Diseases (NIDDK / NIH)',
      organizationType: 'National Institutes of Health',
      url: 'https://www.niddk.nih.gov/health-information/endocrine-diseases/thyroid-disease',
      topicTitle: 'Thyroid Disease Overview, TSH Testing, and Clinical Care',
      retrievedAt: now,
    });
    sources.push({
      name: 'American Thyroid Association (ATA) / MedlinePlus (NIH)',
      organizationType: 'National Health Association & NIH MedlinePlus',
      url: 'https://medlineplus.gov/thyroiddiseases.html',
      topicTitle: 'Thyroid Disorders: Hypothyroidism, Hyperthyroidism, and Diagnostics',
      retrievedAt: now,
    });
  } else {
    // General preventive health / routine health screening
    sources.push({
      name: 'World Health Organization (WHO)',
      organizationType: 'United Nations Specialized Global Health Agency',
      url: 'https://www.who.int/health-topics/noncommunicable-diseases',
      topicTitle: 'Preventive Health, Noncommunicable Disease Screening, and Biomarkers',
      retrievedAt: now,
    });
    sources.push({
      name: 'National Institutes of Health (NIH / MedlinePlus)',
      organizationType: 'U.S. National Library of Medicine',
      url: 'https://medlineplus.gov/lab-tests/',
      topicTitle: 'Understanding Medical Laboratory Tests and Reference Ranges',
      retrievedAt: now,
    });
    sources.push({
      name: 'Centers for Disease Control and Prevention (CDC)',
      organizationType: 'National Public Health Institute (U.S. HHS)',
      url: 'https://www.cdc.gov/prevention/index.html',
      topicTitle: 'Routine Preventive Screenings and Clinical Health Metrics',
      retrievedAt: now,
    });
  }

  // If no sources could be retrieved or established
  if (sources.length === 0) {
    return {
      success: false,
      sources: [],
      errorNotice:
        'Verified educational information could not be retrieved from online authoritative medical sources at this time. To maintain factual integrity, unverified content was not generated.',
    };
  }

  return {
    success: true,
    sources,
  };
}

// POST /api/analyze-report - Multi-page Medical Report Analyzer
app.post('/api/analyze-report', async (req, res) => {
  try {
    const { pages } = req.body;

    if (!Array.isArray(pages) || pages.length === 0) {
      return res.status(400).json({ error: 'No report pages provided. Please upload at least one report page or PDF document.' });
    }

    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      return res.status(500).json({
        error: 'Gemini API key is not configured in the backend environment. Please configure GEMINI_API_KEY in Settings.',
      });
    }

    // Build multimodal prompt parts
    const parts: any[] = [];

    parts.push({
      text: `You are a certified master clinical laboratory pathologist, diagnostic report interpreter, and patient health educator.
You are provided with a complete medical diagnostic laboratory report consisting of ${pages.length} item(s)/page(s) (including document images in JPG/PNG/WEBP and/or PDF document pages with laboratory tables).

======================================================================
MANDATORY DIRECTIVES: TWO CLEARLY SEPARATED SECTIONS
======================================================================

The Medical Report Analyzer must provide TWO clearly separated sections:

======================================================================
SECTION 1 — REPORT ANALYSIS
======================================================================
Continue the detailed report analysis exactly as follows:
- You MUST read the COMPLETE content of the uploaded medical report from start to finish across ALL ${pages.length} page(s) before generating the final analysis.
- Extract EVERY single printed laboratory table, test row, biomarker, numerical result, unit, biological reference range, and doctor remark without omission.
- Test Names: Exact or standard clinical name with standard abbreviations (e.g., "Hemoglobin (Hb)", "Serum Creatinine", "Fasting Blood Glucose", "Total Cholesterol", "Platelet Count", "TSH", "Urine Protein", "SGPT / ALT", "SGOT / AST", "Bilirubin Total").
- Test Results: Exact detected value string as printed on the report (e.g., "14.2", "110", "Negative", "1.1", "Normal", "Trace"). NEVER alter or translate numbers.
- Units: Exact unit of measurement as printed (e.g., "g/dL", "mg/dL", "uIU/mL", "%", "U/L", "cells/cumm", "mg/L") or null.
- Reference Ranges: Exact biological reference interval printed on the uploaded report (e.g., "13.0 - 17.0", "70 - 99", "< 200"). Use the printed range whenever available. If not printed, use "Not specified".
- Status: "normal" | "high" | "low" | "abnormal" | "attention" based strictly on the report's printed reference ranges and abnormal flags.
- Detailed Test-by-Test Explanations:
  * "explanation": In clear English: 1) What the test measures, 2) What the reported value means in context of the reference range, 3) Whether the result is within the provided reference range, 4) What the abnormal value may indicate or why it matters for health.
  * "explanationHi": Fluent Hindi (हिंदी) explanation answering the same points.
  * "explanationMr": Fluent Marathi (मराठी) explanation answering the same points.
- Overall Clinical Report Summary across all pages in English, Hindi (हिंदी), and Marathi (मराठी).
- Categorization into: "allTests", "abnormalResults", "normalResults", "needsAttention".
- Strict factual integrity: Do NOT invent or guess any value from the uploaded report. If unreadable, mark "Not clearly readable".

======================================================================
SECTION 2 — CONDITION / DISEASE EDUCATION
======================================================================
If the analyzed report indicates or is related to a medical condition (for example Diabetes, Anemia, Hypertension, Dyslipidemia / High Cholesterol, Chronic Kidney Disease, Liver Dysfunction, Thyroid Disorder, Acute Infection / Inflammation, or Routine Preventive Health Screening):
Automatically identify the relevant condition and provide a detailed educational explanation based strictly on reliable, authoritative online medical sources (WHO, CDC, NIH / NIDDK, and National Library of Medicine).

The disease educational information must cover all 11 required educational topics:
1. What is the condition? (Overview, clinical definition, and biological mechanism)
2. Types of the condition (e.g., for Diabetes: Type 1, Type 2, Gestational Diabetes, Prediabetes)
3. Causes and risk factors (genetic predisposition, metabolic factors, lifestyle, dietary causes, risk factors)
4. Signs and symptoms (common early and late symptoms to recognize)
5. How the condition is diagnosed (established clinical diagnostic criteria, threshold numbers, and evaluation)
6. Important blood tests and their meaning (detailed array of related diagnostic tests, e.g. Fasting Glucose, HbA1c, OGTT, Postprandial Glucose, Urine Microalbumin, Lipid Profile, and what each measures)
7. Possible complications (potential long-term health complications if unmanaged or untreated)
8. Prevention and lifestyle measures (balanced nutrition, physical activity, weight management, sleep, stress reduction, self-monitoring)
9. General treatment approaches (lifestyle interventions as first-line, standard pharmacotherapy principles — with an explicit note that prescription medicines require a qualified physician)
10. When a person should consult a doctor (warning signs, abnormal thresholds, red flag symptoms requiring prompt clinical evaluation)
11. Other important educational information relevant to the condition (routine monitoring schedules, preventive screening intervals, empowering self-management guidance)

Provide the condition name, relevance explanation, and all 11 educational topics in:
- English
- Fluent natural Hindi (हिंदी)
- Fluent natural Marathi (मराठी)

IMPORTANT SAFETY RULES:
- Do NOT diagnose the patient solely from the report.
- Do NOT claim that the patient definitely has a disease unless the uploaded report itself contains a confirmed diagnosis.
- Use wording such as "may indicate", "can be associated with", or "requires medical evaluation" when appropriate.
- Do NOT recommend prescription medicines or specific doses based solely on the report.
- Clearly separate "what the report shows" from general educational information about the condition.

MANDATORY MEDICAL DISCLAIMER AT THE VERY END:
At the END of the Medical Report Analyzer result, always set:
- safetyDisclaimer: "This information is provided for educational purposes only and is not intended to diagnose, treat, cure, or prevent any disease. It should not replace advice, diagnosis, or treatment from a qualified healthcare professional. Please consult a doctor for proper medical evaluation."
- safetyDisclaimerHi: "यह जानकारी केवल शैक्षिक उद्देश्यों के लिए प्रदान की गई है और इसका उद्देश्य किसी भी बीमारी का निदान, उपचार, इलाज या रोकथाम करना नहीं है। इसे किसी योग्य स्वास्थ्य सेवा पेशेवर की सलाह, निदान या उपचार का स्थान नहीं लेना चाहिए। उचित चिकित्सकीय मूल्यांकन के लिए कृपया किसी डॉक्टर से परामर्श लें।"
- safetyDisclaimerMr: "ही माहिती केवळ शैक्षणिक हेतूंसाठी प्रदान केली गेली आहे आणि तिचा हेतू कोणत्याही रोगाचे निदान, उपचार, बरा करणे किंवा प्रतिबंध करणे हा नाही. ही माहिती पात्र आरोग्यसेवा व्यावसायिकाचा सल्ला, निदान किंवा उपचारांची जागा घेऊ नये. योग्य वैद्यकीय मूल्यांकनासाठी कृपया डॉक्टरांचा सल्ला घ्या."`,
    });

    // Add each page image / PDF with page annotation and text
    for (let i = 0; i < pages.length; i++) {
      const page = pages[i];
      const pageNum = page.pageNumber || i + 1;
      let rawBase64 = typeof page.dataUrl === 'string' ? page.dataUrl.trim() : '';
      let mimeType = page.mimeType || 'image/jpeg';

      if (rawBase64.includes(';base64,')) {
        const matches = rawBase64.match(/^data:([a-zA-Z0-9/+.-]+);base64,(.+)$/);
        if (matches && matches.length === 3) {
          mimeType = matches[1];
          rawBase64 = matches[2];
        } else {
          rawBase64 = rawBase64.split(';base64,')[1];
        }
      }

      // Remove any extraneous whitespace or newlines from base64
      rawBase64 = rawBase64.replace(/\s+/g, '');

      // Normalize MIME types
      if (mimeType.includes('pdf')) {
        mimeType = 'application/pdf';
      } else if (mimeType.includes('png')) {
        mimeType = 'image/png';
      } else if (mimeType.includes('webp')) {
        mimeType = 'image/webp';
      } else if (!mimeType.includes('image/')) {
        mimeType = 'image/jpeg';
      }

      parts.push({
        text: `--- BEGIN MEDICAL REPORT ITEM ${pageNum} OF ${pages.length} (${page.name || `Page ${pageNum}`} - ${mimeType}) ---`,
      });

      // Include the image/pdf inlineData if available
      if (rawBase64 && rawBase64.length > 20) {
        parts.push({
          inlineData: {
            mimeType: mimeType,
            data: rawBase64,
          },
        });
      }

      parts.push({
        text: `--- END MEDICAL REPORT ITEM ${pageNum} OF ${pages.length} ---`,
      });
    }

    const schemaConfig = {
      systemInstruction:
        'You are a certified master clinical laboratory pathologist, diagnostic report interpreter, and patient health educator. Interpret multi-page medical reports exhaustively and accurately across both SECTION 1 (REPORT ANALYSIS) and SECTION 2 (CONDITION / DISEASE EDUCATION). Extract every single printed laboratory table, test row, biomarker, unit, reference range, and doctor remark without omission. If abnormal or related biomarkers indicate a medical condition (e.g. Diabetes, Anemia, Hypertension, Dyslipidemia, Kidney Disease, Liver Disease, Thyroid Disorder), provide comprehensive educational guidance structured across the 11 clinical topics in English, Hindi (हिंदी), and Marathi (मराठी) based strictly on authoritative organizations (WHO, CDC, NIH / NIDDK). Always include the exact mandatory safety disclaimer at the end. Never diagnose the patient solely from numbers alone or recommend prescription medications.',
      responseMimeType: 'application/json',
      temperature: 0.1,
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          patientInfo: {
            type: Type.OBJECT,
            properties: {
              name: { type: Type.STRING, nullable: true },
              age: { type: Type.STRING, nullable: true },
              gender: { type: Type.STRING, nullable: true },
              reportDate: { type: Type.STRING, nullable: true },
              doctorRemarks: { type: Type.STRING, nullable: true },
              doctorRemarksHi: { type: Type.STRING, nullable: true },
              doctorRemarksMr: { type: Type.STRING, nullable: true },
              labOrHospitalName: { type: Type.STRING, nullable: true },
            },
          },
          overallSummary: { type: Type.STRING },
          overallSummaryHi: { type: Type.STRING },
          overallSummaryMr: { type: Type.STRING },
          unreadablePages: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                pageNumber: { type: Type.INTEGER },
                reason: { type: Type.STRING },
                reasonHi: { type: Type.STRING, nullable: true },
                reasonMr: { type: Type.STRING, nullable: true },
              },
              required: ['pageNumber', 'reason'],
            },
          },
          abnormalResults: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                testName: { type: Type.STRING },
                result: { type: Type.STRING },
                unit: { type: Type.STRING, nullable: true },
                referenceRange: { type: Type.STRING, nullable: true },
                status: { type: Type.STRING },
                explanation: { type: Type.STRING },
                explanationHi: { type: Type.STRING, nullable: true },
                explanationMr: { type: Type.STRING, nullable: true },
                pageNumbers: { type: Type.ARRAY, items: { type: Type.INTEGER } },
                duplicateNote: { type: Type.STRING, nullable: true },
                duplicateNoteHi: { type: Type.STRING, nullable: true },
                duplicateNoteMr: { type: Type.STRING, nullable: true },
              },
              required: ['testName', 'result', 'status', 'explanation'],
            },
          },
          normalResults: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                testName: { type: Type.STRING },
                result: { type: Type.STRING },
                unit: { type: Type.STRING, nullable: true },
                referenceRange: { type: Type.STRING, nullable: true },
                status: { type: Type.STRING },
                explanation: { type: Type.STRING },
                explanationHi: { type: Type.STRING, nullable: true },
                explanationMr: { type: Type.STRING, nullable: true },
                pageNumbers: { type: Type.ARRAY, items: { type: Type.INTEGER } },
                duplicateNote: { type: Type.STRING, nullable: true },
                duplicateNoteHi: { type: Type.STRING, nullable: true },
                duplicateNoteMr: { type: Type.STRING, nullable: true },
              },
              required: ['testName', 'result', 'status', 'explanation'],
            },
          },
          needsAttention: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                testName: { type: Type.STRING },
                result: { type: Type.STRING },
                unit: { type: Type.STRING, nullable: true },
                referenceRange: { type: Type.STRING, nullable: true },
                status: { type: Type.STRING },
                explanation: { type: Type.STRING },
                explanationHi: { type: Type.STRING, nullable: true },
                explanationMr: { type: Type.STRING, nullable: true },
                pageNumbers: { type: Type.ARRAY, items: { type: Type.INTEGER } },
                duplicateNote: { type: Type.STRING, nullable: true },
                duplicateNoteHi: { type: Type.STRING, nullable: true },
                duplicateNoteMr: { type: Type.STRING, nullable: true },
              },
              required: ['testName', 'result', 'status', 'explanation'],
            },
          },
          allTests: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                testName: { type: Type.STRING },
                result: { type: Type.STRING },
                unit: { type: Type.STRING, nullable: true },
                referenceRange: { type: Type.STRING, nullable: true },
                status: { type: Type.STRING },
                explanation: { type: Type.STRING },
                explanationHi: { type: Type.STRING, nullable: true },
                explanationMr: { type: Type.STRING, nullable: true },
                pageNumbers: { type: Type.ARRAY, items: { type: Type.INTEGER } },
                duplicateNote: { type: Type.STRING, nullable: true },
                duplicateNoteHi: { type: Type.STRING, nullable: true },
                duplicateNoteMr: { type: Type.STRING, nullable: true },
              },
              required: ['testName', 'result', 'status', 'explanation'],
            },
          },
          conditionEducation: {
            type: Type.OBJECT,
            properties: {
              conditionIdentified: { type: Type.BOOLEAN },
              conditionName: { type: Type.STRING },
              conditionNameHi: { type: Type.STRING, nullable: true },
              conditionNameMr: { type: Type.STRING, nullable: true },
              relevanceExplanation: { type: Type.STRING },
              relevanceExplanationHi: { type: Type.STRING, nullable: true },
              relevanceExplanationMr: { type: Type.STRING, nullable: true },
              retrievalSuccess: { type: Type.BOOLEAN },
              retrievalErrorNotice: { type: Type.STRING, nullable: true },
              retrievalErrorNoticeHi: { type: Type.STRING, nullable: true },
              retrievalErrorNoticeMr: { type: Type.STRING, nullable: true },
              trustedSources: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    name: { type: Type.STRING },
                    organizationType: { type: Type.STRING },
                    url: { type: Type.STRING, nullable: true },
                    topicTitle: { type: Type.STRING, nullable: true },
                    retrievedAt: { type: Type.STRING, nullable: true },
                  },
                  required: ['name', 'organizationType'],
                },
              },
              educationalContent: {
                type: Type.OBJECT,
                properties: {
                  overview: { type: Type.STRING },
                  overviewHi: { type: Type.STRING, nullable: true },
                  overviewMr: { type: Type.STRING, nullable: true },
                  types: { type: Type.ARRAY, items: { type: Type.STRING } },
                  typesHi: { type: Type.ARRAY, items: { type: Type.STRING }, nullable: true },
                  typesMr: { type: Type.ARRAY, items: { type: Type.STRING }, nullable: true },
                  causesAndRisks: { type: Type.ARRAY, items: { type: Type.STRING } },
                  causesAndRisksHi: { type: Type.ARRAY, items: { type: Type.STRING }, nullable: true },
                  causesAndRisksMr: { type: Type.ARRAY, items: { type: Type.STRING }, nullable: true },
                  signsAndSymptoms: { type: Type.ARRAY, items: { type: Type.STRING } },
                  signsAndSymptomsHi: { type: Type.ARRAY, items: { type: Type.STRING }, nullable: true },
                  signsAndSymptomsMr: { type: Type.ARRAY, items: { type: Type.STRING }, nullable: true },
                  diagnosisOverview: { type: Type.STRING },
                  diagnosisOverviewHi: { type: Type.STRING, nullable: true },
                  diagnosisOverviewMr: { type: Type.STRING, nullable: true },
                  relevantTestsAndMeaning: {
                    type: Type.ARRAY,
                    items: {
                      type: Type.OBJECT,
                      properties: {
                        testName: { type: Type.STRING },
                        clinicalMeaning: { type: Type.STRING },
                        clinicalMeaningHi: { type: Type.STRING, nullable: true },
                        clinicalMeaningMr: { type: Type.STRING, nullable: true },
                      },
                      required: ['testName', 'clinicalMeaning'],
                    },
                  },
                  complications: { type: Type.ARRAY, items: { type: Type.STRING } },
                  complicationsHi: { type: Type.ARRAY, items: { type: Type.STRING }, nullable: true },
                  complicationsMr: { type: Type.ARRAY, items: { type: Type.STRING }, nullable: true },
                  preventionAndLifestyle: { type: Type.ARRAY, items: { type: Type.STRING } },
                  preventionAndLifestyleHi: { type: Type.ARRAY, items: { type: Type.STRING }, nullable: true },
                  preventionAndLifestyleMr: { type: Type.ARRAY, items: { type: Type.STRING }, nullable: true },
                  treatmentApproaches: { type: Type.ARRAY, items: { type: Type.STRING } },
                  treatmentApproachesHi: { type: Type.ARRAY, items: { type: Type.STRING }, nullable: true },
                  treatmentApproachesMr: { type: Type.ARRAY, items: { type: Type.STRING }, nullable: true },
                  whenToSeeDoctor: { type: Type.ARRAY, items: { type: Type.STRING } },
                  whenToSeeDoctorHi: { type: Type.ARRAY, items: { type: Type.STRING }, nullable: true },
                  whenToSeeDoctorMr: { type: Type.ARRAY, items: { type: Type.STRING }, nullable: true },
                  additionalEducationalNotes: { type: Type.STRING, nullable: true },
                  additionalEducationalNotesHi: { type: Type.STRING, nullable: true },
                  additionalEducationalNotesMr: { type: Type.STRING, nullable: true },
                },
                required: [
                  'overview',
                  'types',
                  'causesAndRisks',
                  'signsAndSymptoms',
                  'diagnosisOverview',
                  'relevantTestsAndMeaning',
                  'complications',
                  'preventionAndLifestyle',
                  'treatmentApproaches',
                  'whenToSeeDoctor',
                ],
              },
            },
            required: ['conditionIdentified', 'conditionName', 'relevanceExplanation', 'retrievalSuccess'],
          },
          safetyDisclaimer: { type: Type.STRING },
          safetyDisclaimerHi: { type: Type.STRING },
          safetyDisclaimerMr: { type: Type.STRING },
        },
        required: [
          'patientInfo',
          'overallSummary',
          'abnormalResults',
          'normalResults',
          'needsAttention',
          'allTests',
          'unreadablePages',
          'safetyDisclaimer',
        ],
      },
    };

    // Robust Multi-Model Candidate List:
    const candidateModels = ['gemini-3.7-flash', 'gemini-3.1-flash-lite', 'gemini-flash-latest'];
    let response: any = null;
    let lastError: any = null;

    for (const model of candidateModels) {
      try {
        console.log(`[MedicalReportAnalyzer] Invoking AI model: ${model}`);
        response = await callGeminiGenerateContent({
          model,
          apiKey,
          parts,
          config: schemaConfig,
        });

        if (response && response.text) {
          console.log(`[MedicalReportAnalyzer] Success with model: ${model}`);
          break;
        }
      } catch (err: any) {
        lastError = err;
        console.warn(`[MedicalReportAnalyzer] Model ${model} failed (${err?.status || err?.code || err?.message}). Trying next candidate...`);
      }
    }

    if (!response || !response.text) {
      const errMsg = lastError?.message || 'Unable to connect to the analysis service. Please check your internet connection and try again.';
      if (lastError?.status === 503 || (typeof errMsg === 'string' && errMsg.includes('high demand'))) {
        return res.status(503).json({
          error: 'The medical report AI service is currently experiencing high demand. Please click "Retry Analysis" in a few seconds.',
        });
      }
      return res.status(500).json({ error: errMsg });
    }

    const responseText = response.text || '';
    let parsedResult: any;
    try {
      parsedResult = JSON.parse(responseText);
    } catch (parseErr) {
      const match = responseText.match(/\{[\s\S]*\}/);
      if (match) {
        parsedResult = JSON.parse(match[0]);
      } else {
        const cleanJson = responseText.replace(/```json/g, '').replace(/```/g, '').trim();
        parsedResult = JSON.parse(cleanJson);
      }
    }

    // Ensure all required top-level arrays and objects are well-formed
    if (!parsedResult.patientInfo) parsedResult.patientInfo = {};
    if (!Array.isArray(parsedResult.abnormalResults)) parsedResult.abnormalResults = [];
    if (!Array.isArray(parsedResult.normalResults)) parsedResult.normalResults = [];
    if (!Array.isArray(parsedResult.needsAttention)) parsedResult.needsAttention = [];
    if (!Array.isArray(parsedResult.allTests)) parsedResult.allTests = [];
    if (!Array.isArray(parsedResult.unreadablePages)) parsedResult.unreadablePages = [];
    if (!parsedResult.overallSummary) {
      parsedResult.overallSummary = 'Medical laboratory report analyzed successfully.';
    }
    if (!parsedResult.overallSummaryHi) {
      parsedResult.overallSummaryHi = parsedResult.overallSummary;
    }
    if (!parsedResult.overallSummaryMr) {
      parsedResult.overallSummaryMr = parsedResult.overallSummary;
    }

    // Mandatory Medical Safety Disclaimer in English, Hindi, and Marathi
    parsedResult.safetyDisclaimer =
      'This information is provided for educational purposes only and is not intended to diagnose, treat, cure, or prevent any disease. It should not replace advice, diagnosis, or treatment from a qualified healthcare professional. Please consult a doctor for proper medical evaluation.';
    parsedResult.safetyDisclaimerHi =
      'यह जानकारी केवल शैक्षिक उद्देश्यों के लिए प्रदान की गई है और इसका उद्देश्य किसी भी बीमारी का निदान, उपचार, इलाज या रोकथाम करना नहीं है। इसे किसी योग्य स्वास्थ्य सेवा पेशेवर की सलाह, निदान या उपचार का स्थान नहीं लेना चाहिए। उचित चिकित्सकीय मूल्यांकन के लिए कृपया किसी डॉक्टर से परामर्श लें।';
    parsedResult.safetyDisclaimerMr =
      'ही माहिती केवळ शैक्षणिक हेतूंसाठी प्रदान केली गेली आहे आणि तिचा हेतू कोणत्याही रोगाचे निदान, उपचार, बरा करणे किंवा प्रतिबंध करणे हा नाही. ही माहिती पात्र आरोग्यसेवा व्यावसायिकाचा सल्ला, निदान किंवा उपचारांची जागा घेऊ नये. योग्य वैद्यकीय मूल्यांकनासाठी कृपया डॉक्टरांचा सल्ला घ्या.';

    // Synchronize and enrich Section 2: Condition / Disease Education
    const identifiedTerm =
      parsedResult.conditionEducation?.conditionName ||
      (parsedResult.abnormalResults.some((t: any) => /glucose|sugar|hba1c/i.test(t?.testName || ''))
        ? 'Diabetes Mellitus'
        : parsedResult.abnormalResults.some((t: any) => /hemoglobin|hb|rbc|ferritin/i.test(t?.testName || ''))
        ? 'Anemia'
        : parsedResult.abnormalResults.some((t: any) => /cholesterol|triglyceride|lipid/i.test(t?.testName || ''))
        ? 'Dyslipidemia / High Cholesterol'
        : parsedResult.abnormalResults.some((t: any) => /creatinine|bun|urea|uric/i.test(t?.testName || ''))
        ? 'Kidney Disease / Renal Function'
        : parsedResult.abnormalResults.some((t: any) => /sgpt|sgot|alt|ast|bilirubin/i.test(t?.testName || ''))
        ? 'Liver Disease / Hepatic Function'
        : parsedResult.abnormalResults.some((t: any) => /tsh|t3|t4|thyroid/i.test(t?.testName || ''))
        ? 'Thyroid Disorder'
        : 'Routine Preventive Health Screening');

    // Retrieve live authoritative online medical sources
    const onlineSourcesResult = await retrieveAuthoritativeMedicalSources(identifiedTerm);

    if (!parsedResult.conditionEducation) {
      parsedResult.conditionEducation = {
        conditionIdentified: true,
        conditionName: identifiedTerm,
        conditionNameHi: identifiedTerm,
        conditionNameMr: identifiedTerm,
        relevanceExplanation: `Identified based on clinical biomarkers in your laboratory report.`,
        relevanceExplanationHi: `आपकी प्रयोगशाला रिपोर्ट में क्लिनिकल बायोमार्कर्स के आधार पर पहचाना गया।`,
        relevanceExplanationMr: `तुमच्या प्रयोगशाळेतील अहवालातील क्लिनिकल बायोमार्कर्सच्या आधारे ओळखले गेले.`,
        retrievalSuccess: onlineSourcesResult.success,
        trustedSources: onlineSourcesResult.sources,
      };
    } else {
      parsedResult.conditionEducation.conditionIdentified = true;
      parsedResult.conditionEducation.retrievalSuccess = onlineSourcesResult.success;
      // Merge verified live authoritative online sources (WHO, CDC, NIH MedlinePlus, NIDDK)
      if (onlineSourcesResult.sources.length > 0) {
        parsedResult.conditionEducation.trustedSources = onlineSourcesResult.sources;
      }
    }

    // Ensure bidirectional synchronization between allTests and categorized arrays
    const existingTestNames = new Set(
      parsedResult.allTests.map((t: any) => (t?.testName || '').trim().toLowerCase())
    );

    const addToAllIfMissing = (testList: any[]) => {
      for (const t of testList) {
        if (t && t.testName) {
          const key = t.testName.trim().toLowerCase();
          if (!existingTestNames.has(key)) {
            parsedResult.allTests.push(t);
            existingTestNames.add(key);
          }
        }
      }
    };
    addToAllIfMissing(parsedResult.abnormalResults);
    addToAllIfMissing(parsedResult.needsAttention);
    addToAllIfMissing(parsedResult.normalResults);

    // Populate category arrays from allTests if missing
    for (const test of parsedResult.allTests) {
      if (!test || !test.testName) continue;
      const status = (test.status || '').toLowerCase();
      const testKey = test.testName.trim().toLowerCase();

      const inAbnormal = parsedResult.abnormalResults.some(
        (t: any) => (t?.testName || '').trim().toLowerCase() === testKey
      );
      const inAttention = parsedResult.needsAttention.some(
        (t: any) => (t?.testName || '').trim().toLowerCase() === testKey
      );
      const inNormal = parsedResult.normalResults.some(
        (t: any) => (t?.testName || '').trim().toLowerCase() === testKey
      );

      if (status === 'high' || status === 'low' || status === 'abnormal') {
        if (!inAbnormal) parsedResult.abnormalResults.push(test);
      } else if (status === 'attention' || status === 'borderline') {
        if (!inAttention) parsedResult.needsAttention.push(test);
      } else {
        if (!inNormal) parsedResult.normalResults.push(test);
      }
    }

    return res.json({ success: true, result: parsedResult });
  } catch (err: any) {
    console.error('Medical Report Analysis API uncaught error:', err);
    return res.status(500).json({
      error: err.message || 'Failed to analyze medical report. Please check the image clarity and try again.',
    });
  }
});


async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
