import express from "express";
import { jarvisCore } from "./server/core/jarvisCore.js";

const app = express();
app.use(express.json({ limit: "2mb" }));

app.get("/api/health", (_req, res) =>
  res.json({ ok: true, service: "JARVIS", version: "5.1.0" })
);

app.get("/api/status", (_req, res) =>
  res.json({ status: "HEALTHY", mode: "STANDBY_READY" })
);

app.get("/api/capabilities", (_req, res) =>
  res.json(jarvisCore.capabilities())
);

app.post("/api/chat", async (req, res) => {
  const result = await jarvisCore.handle(String(req.body?.message ?? ""));
  res.json(result);
});

const port = Number(process.env.PORT || 3000);
app.listen(port, "0.0.0.0", () =>
  console.log(`JARVIS listening on ${port}`)
);
