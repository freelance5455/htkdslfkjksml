import express, { Request, Response } from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

app.use(express.json({ limit: '50mb' }));

// Helper: Heuristic formatting analyzer when API key is unavailable or fails
function generateHeuristicAnalysis(text: string, templateType: string = 'general') {
  const lines = text.split('\n');
  const blocks: Array<{
    type: 'heading' | 'subheading' | 'paragraph' | 'list_item' | 'quote' | 'table' | 'reference';
    content: string;
    suggestedLevel?: number;
  }> = [];

  let inTable = false;
  let tableBuffer: string[] = [];

  for (let i = 0; i < lines.length; i++) {
    const rawLine = lines[i];
    const line = rawLine.trim();
    if (!line) continue;

    if (line.includes('|') && line.split('|').length > 2) {
      inTable = true;
      tableBuffer.push(line);
      continue;
    } else if (inTable) {
      blocks.push({ type: 'table', content: tableBuffer.join('\n') });
      inTable = false;
      tableBuffer = [];
    }

    if (/^(#|\d+\.\s+[A-Z]|[A-Z\s]{4,}$)/.test(line) && line.length < 80) {
      blocks.push({ type: 'heading', content: line.replace(/^#+\s*/, ''), suggestedLevel: 1 });
    } else if (/^(##|\d+\.\d+\s+[A-Z]|[A-Z][a-z0-9\s]{3,40}:?$)/.test(line) && line.length < 60) {
      blocks.push({ type: 'subheading', content: line.replace(/^#+\s*/, ''), suggestedLevel: 2 });
    } else if (/^([-*•]|\d+\.)\s+/.test(line)) {
      blocks.push({ type: 'list_item', content: line.replace(/^([-*•]|\d+\.)\s+/, '') });
    } else if (/^>|^(["“]).*(["”])$/.test(line)) {
      blocks.push({ type: 'quote', content: line.replace(/^>\s*/, '') });
    } else if (/^\[\d+\]|^doi:|^References?:?/i.test(line)) {
      blocks.push({ type: 'reference', content: line });
    } else {
      blocks.push({ type: 'paragraph', content: line });
    }
  }

  if (inTable && tableBuffer.length > 0) {
    blocks.push({ type: 'table', content: tableBuffer.join('\n') });
  }

  // Template suggestions
  const templateRecommendations: Record<string, any> = {
    academic: {
      fontFamily: 'Times New Roman',
      headingFont: 'Times New Roman',
      bodySize: 12,
      headingSize: 16,
      lineSpacing: 2.0,
      paragraphSpacing: 6,
      margins: { top: 1, bottom: 1, left: 1, right: 1 },
      align: 'left',
      indentFirstLine: true,
      accentColor: '#1A365D',
      rationale: 'Academic standard (APA/MLA) with Times New Roman 12pt, double spacing, 1-inch margins, and first-line indents.'
    },
    business: {
      fontFamily: 'Calibri',
      headingFont: 'Aptos',
      bodySize: 11,
      headingSize: 18,
      lineSpacing: 1.15,
      paragraphSpacing: 10,
      margins: { top: 1, bottom: 1, left: 1, right: 1 },
      align: 'left',
      indentFirstLine: false,
      accentColor: '#005FB8',
      rationale: 'Modern corporate clarity with Calibri/Aptos pairing, crisp 1.15 line spacing, and distinct paragraph blocks.'
    },
    report: {
      fontFamily: 'Georgia',
      headingFont: 'Arial',
      bodySize: 11,
      headingSize: 20,
      lineSpacing: 1.25,
      paragraphSpacing: 12,
      margins: { top: 1, bottom: 1, left: 1, right: 1 },
      align: 'left',
      indentFirstLine: false,
      accentColor: '#0F766E',
      rationale: 'Executive report styling with Georgia editorial body and clear Arial headers for scannability.'
    },
    letter: {
      fontFamily: 'Garamond',
      headingFont: 'Garamond',
      bodySize: 12,
      headingSize: 14,
      lineSpacing: 1.15,
      paragraphSpacing: 12,
      margins: { top: 1.25, bottom: 1.25, left: 1, right: 1 },
      align: 'left',
      indentFirstLine: false,
      accentColor: '#374151',
      rationale: 'Formal correspondence layout with elegant Garamond typography, generous top/bottom margins, and block paragraphs.'
    },
    general: {
      fontFamily: 'Arial',
      headingFont: 'Arial',
      bodySize: 11,
      headingSize: 18,
      lineSpacing: 1.2,
      paragraphSpacing: 8,
      margins: { top: 1, bottom: 1, left: 1, right: 1 },
      align: 'left',
      indentFirstLine: false,
      accentColor: '#2563EB',
      rationale: 'Universal clean presentation with high readability across all mobile and printed displays.'
    }
  };

  const chosenRec = templateRecommendations[templateType] || templateRecommendations.general;

  return {
    recommendations: chosenRec,
    structure: blocks,
    detectedElements: {
      headingsCount: blocks.filter(b => b.type === 'heading' || b.type === 'subheading').length,
      paragraphsCount: blocks.filter(b => b.type === 'paragraph').length,
      listItemsCount: blocks.filter(b => b.type === 'list_item').length,
      tablesCount: blocks.filter(b => b.type === 'table').length,
      quotesCount: blocks.filter(b => b.type === 'quote').length,
      referencesCount: blocks.filter(b => b.type === 'reference').length,
    },
    observations: [
      `Detected ${blocks.filter(b => b.type === 'heading').length} main section headers and ${blocks.filter(b => b.type === 'subheading').length} subsections.`,
      `Optimal typography selected: ${chosenRec.fontFamily} for high legibility in ${templateType} context.`,
      'Layout preserved verbatim without altering original author wording or meaning.'
    ]
  };
}

// AI Document Formatting Assistant endpoint
app.post('/api/ai/format-assistant', async (req: Request, res: Response) => {
  try {
    const { text, templateType = 'general', preserveWording = true } = req.body;

    if (!text || typeof text !== 'string') {
      return res.status(400).json({ error: 'Text content is required' });
    }

    const apiKey = process.env.GEMINI_API_KEY;

    if (!apiKey) {
      // Return high-quality heuristic analysis
      const result = generateHeuristicAnalysis(text, templateType);
      return res.json({
        ...result,
        source: 'local_heuristic',
        message: 'Analysis generated using built-in typography rules.'
      });
    }

    try {
      const ai = new GoogleGenAI();
      const prompt = `You are the DocuForge AI Document Formatting Assistant.
CRITICAL MANDATE:
1. You must inspect the provided document text and recommend professional typography, layout, structural hierarchy, and styling adjustments.
2. DO NOT invent facts. DO NOT remove information. DO NOT paraphrase or change the author's meaning.
3. Identify structural elements: headings (Level 1, 2, 3), paragraphs, numbered/bulleted lists, tables, quotations, and references.
4. Recommend appropriate font combinations (from: Times New Roman, Arial, Calibri, Aptos, Georgia, Garamond, Cambria, Verdana, Tahoma, Courier New), font sizes, line spacing, paragraph spacing, indentation, margins (inches), and alignment.
5. Provide a JSON response adhering strictly to the schema below.

Template requested: ${templateType}
Preserve wording strictly: ${preserveWording}

Return valid JSON ONLY matching this format:
{
  "recommendations": {
    "fontFamily": "Calibri",
    "headingFont": "Aptos",
    "bodySize": 11,
    "headingSize": 18,
    "lineSpacing": 1.15,
    "paragraphSpacing": 10,
    "margins": { "top": 1, "bottom": 1, "left": 1, "right": 1 },
    "align": "left",
    "indentFirstLine": false,
    "accentColor": "#005FB8",
    "rationale": "Clear corporate typography with balanced vertical rhythm."
  },
  "structure": [
    { "type": "heading", "content": "Exact text of heading", "suggestedLevel": 1 },
    { "type": "paragraph", "content": "Exact text of paragraph" }
  ],
  "detectedElements": {
    "headingsCount": 2,
    "paragraphsCount": 4,
    "listItemsCount": 3,
    "tablesCount": 0,
    "quotesCount": 0,
    "referencesCount": 0
  },
  "observations": [
    "Identified clear hierarchical structure",
    "Optimized font pairing for executive clarity"
  ]
}

Document text:
"""
${text.slice(0, 8000)}
"""`;

      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
          responseMimeType: 'application/json',
          temperature: 0.2
        }
      });

      const responseText = response.text || '';
      try {
        const parsed = JSON.parse(responseText);
        return res.json({
          ...parsed,
          source: 'gemini_ai',
          message: 'Professional layout suggestions generated by Gemini 2.5 Flash.'
        });
      } catch (parseErr) {
        console.warn('Failed to parse Gemini JSON output, falling back to heuristic:', parseErr);
        const fallback = generateHeuristicAnalysis(text, templateType);
        return res.json({
          ...fallback,
          source: 'local_heuristic',
          message: 'Analysis generated using built-in typography rules.'
        });
      }
    } catch (apiErr: any) {
      console.warn('Gemini API call failed, falling back to local heuristic analyzer:', apiErr?.message || apiErr);
      const fallback = generateHeuristicAnalysis(text, templateType);
      return res.json({
        ...fallback,
        source: 'local_heuristic',
        message: 'Analysis generated using built-in typography rules.'
      });
    }
  } catch (error: any) {
    console.error('Format assistant endpoint error:', error);
    res.status(500).json({ error: error.message || 'Internal server error' });
  }
});

// App status endpoint
app.get('/api/health', (req: Request, res: Response) => {
  res.json({
    status: 'ok',
    app: 'DocuForge',
    version: '1.0.0',
    hasGeminiKey: !!process.env.GEMINI_API_KEY
  });
});

async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';

  if (!isProd) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[DocuForge] Dev server running at http://0.0.0.0:${PORT}`);
  });
}

startServer();
