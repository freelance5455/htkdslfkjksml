import express from 'express';
import { createServer } from 'http';
import { WebSocketServer, WebSocket } from 'ws';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';
import { createServer as createViteServer } from 'vite';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const server = createServer(app);
  const wss = new WebSocketServer({ noServer: true });

  const PORT = 3000;
  
  // Allow the bundled HopWeb APK / browser frontend to call the backend.
  // Keep the Gemini API key server-side; never expose it in the APK.
  app.use((req, res, next) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET,POST,OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
    if (req.method === 'OPTIONS') return res.sendStatus(204);
    next();
  });
  app.use(express.json({ limit: '10mb' }));

  // Helper function to lazy initialize Gemini client
  function getGeminiClient(): GoogleGenAI | null {
    const key = process.env.GEMINI_API_KEY;
    if (!key) return null;
    return new GoogleGenAI({ apiKey: key });
  }

  // Health API
  app.get('/api/health', (_req, res) => {
    res.json({
      status: 'ok',
      service: 'Hinata AI Assistant Backend',
      hasApiKey: Boolean(process.env.GEMINI_API_KEY)
    });
  });

  // REST API Fallback for Chat
  app.post('/api/chat', async (req, res) => {
    try {
      const { message, audio } = req.body;
      const aiClient = getGeminiClient();

      if (!aiClient) {
        res.json({
          reply: "Hinata: GEMINI_API_KEY is not configured on the backend server. Please set GEMINI_API_KEY in environment settings."
        });
        return;
      }

      if (audio) {
        const response = await aiClient.models.generateContent({
          model: 'gemini-2.5-flash',
          contents: [
            {
              role: 'user',
              parts: [
                {
                  inlineData: {
                    mimeType: 'audio/webm',
                    data: audio
                  }
                },
                { text: 'Listen to this voice message. Respond concisely as Hinata, a warm and helpful AI Assistant.' }
              ]
            }
          ]
        });
        res.json({ reply: response.text || "I heard your voice message!" });
        return;
      }

      const response = await aiClient.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: [
          {
            role: 'user',
            parts: [{ text: `You are Hinata, a helpful, warm, and highly capable AI Assistant. Respond concisely to: ${message || ''}` }]
          }
        ]
      });

      res.json({ reply: response.text || "I am listening!" });
    } catch (error: any) {
      console.error('[Hinata API] Chat error:', error);
      res.status(500).json({ error: error.message || 'Failed to process chat message' });
    }
  });

  // Handle WebSocket upgrades for /ws/live
  server.on('upgrade', (request, socket, head) => {
    try {
      const pathname = new URL(request.url || '', 'http://localhost').pathname;
      if (pathname === '/ws/live') {
        wss.handleUpgrade(request, socket, head, (ws) => {
          wss.emit('connection', ws, request);
        });
      }
    } catch (e) {
      console.error('[Hinata Backend] Upgrade parse error:', e);
    }
  });

  wss.on('connection', (ws: WebSocket) => {
    console.log('[Hinata Backend] Client connected to /ws/live');

    ws.on('message', async (data: Buffer | string) => {
      try {
        const payload = JSON.parse(data.toString());
        const aiClient = getGeminiClient();

        if (payload.type === 'text') {
          if (!aiClient) {
            ws.send(JSON.stringify({
              type: 'text',
              content: "Hinata: GEMINI_API_KEY is not set on the backend. Please add GEMINI_API_KEY in environment settings.",
              isUser: false
            }));
            return;
          }

          const response = await aiClient.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: [
              {
                role: 'user',
                parts: [{ text: `You are Hinata, a helpful, warm, and highly capable AI Assistant. Respond concisely to: ${payload.content}` }]
              }
            ]
          });

          const textOutput = response.text || 'I am listening!';
          ws.send(JSON.stringify({ type: 'text', content: textOutput, isUser: false }));
        } else if (payload.type === 'audio') {
          if (!aiClient) {
            ws.send(JSON.stringify({
              type: 'text',
              content: "Hinata: GEMINI_API_KEY is not set on the backend.",
              isUser: false
            }));
            return;
          }

          const response = await aiClient.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: [
              {
                role: 'user',
                parts: [
                  {
                    inlineData: {
                      mimeType: 'audio/webm',
                      data: payload.data
                    }
                  },
                  { text: 'Respond concisely as Hinata, a warm and helpful AI Assistant.' }
                ]
              }
            ]
          });

          ws.send(JSON.stringify({ type: 'text', content: response.text || "I heard your audio stream!", isUser: false }));
        }
      } catch (err: any) {
        console.error('[Hinata Backend] Error handling WS message:', err);
        ws.send(JSON.stringify({ type: 'error', message: "Error processing request." }));
      }
    });

    ws.on('close', () => {
      console.log('[Hinata Backend] Client disconnected from /ws/live');
    });
  });

  // Vite middleware for development vs static serve for production
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  server.listen(PORT, '0.0.0.0', () => {
    console.log(`[Hinata Backend] Server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
