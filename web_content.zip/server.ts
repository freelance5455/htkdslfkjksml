import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = 3000;

function getGenAIClient(): GoogleGenAI {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error('GEMINI_API_KEY environment variable is not configured.');
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '60mb' }));

  // API endpoint for health check
  app.get('/api/health', (_req, res) => {
    res.json({ status: 'ok', app: 'JF Music Analyzer IA' });
  });

  // Multimodal general analysis endpoint
  app.post('/api/analyze-audio', async (req, res) => {
    try {
      const { metadata, prompt } = req.body;
      const ai = getGenAIClient();

      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: prompt || `Analyze audio metadata: ${JSON.stringify(metadata)} and generate a technical prompt for Suno AI.`,
      });

      res.json({ result: response.text });
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Analysis error';
      console.error('API Error:', msg);
      res.status(500).json({ error: msg });
    }
  });

  // FUNÇÃO: ANALISADOR DE VOZ PROFISSIONAL / COMANDO: /analisarvoz
  app.post('/api/analisar-voz', async (req, res) => {
    try {
      const {
        audioBase64,
        mimeType = 'audio/wav',
        fileName = 'audio.wav',
        clientDspMeasurements = null,
      } = req.body;

      if (!audioBase64) {
        res.status(400).json({ error: 'Nenhum dado de áudio fornecido para análise vocal.' });
        return;
      }

      const ai = getGenAIClient();

      const dspContextNote = clientDspMeasurements
        ? `\n[MEDIÇÕES DE SINAL DSP PRÉ-CALCULADAS NO NAVEGADOR]:
- Frequência Fundamental F0 Estimada: ${clientDspMeasurements.f0RangeHz || 'N/A'} (F0 Média: ${clientDspMeasurements.f0AverageHz ?? 'N/A'} Hz)
- Extensão em semitons observada: ${clientDspMeasurements.pitchRangeSemitones || 'N/A'}
- Estabilidade de Pitch / Jitter: ${clientDspMeasurements.vocalStabilityJitter || 'N/A'}
- Intensidade RMS da voz: ${clientDspMeasurements.vocalIntensityRmsDb || 'N/A'}
- Nota de Taxa de Amostragem: ${clientDspMeasurements.sampleRateNote || 'N/A'}
Use estes dados do sinal real como referência técnica para enriquecer a Análise Técnica Complementar.`
        : '';

      const prompt = `FUNÇÃO: ANALISADOR DE VOZ PROFISSIONAL
COMANDO ATIVADO: /analisarvoz
ARQUIVO: "${fileName}"
${dspContextNote}

Você é o especialista sênior em acústica vocal, fisiologia da fonação, análise de interpretação e engenharia reversa para inteligência artificial musical (especialmente Suno AI) do JF Music Analyzer IA.

OBJETIVO:
Ao receber este arquivo de áudio com voz cantada ou falada, analise detalhadamente as características vocais e gere um relatório técnico de altíssima precisão estruturado exatamente no seguinte FORMATO DO RELATÓRIO FINAL:

- Relatório de Análise Vocal:
  - A. Resumo vocal: Visão geral da interpretação e presença vocal, destaques e resumo conciso do perfil.
  - B. Timbre e registro: Classificação perceptiva (grave, média ou aguda), apresentação percebida (masculina, feminina, mista ou indeterminada somente quando houver evidências), descritores de timbre (encorpado, aveludado, brilhante, escuro, metálico, nasal, soproso, áspero, etc.), ressonância, projeção, articulação, clareza e diferenciação entre altura habitual e notas do canto.
  - C. Textura e rouquidão: Classificação (limpa, levemente rouca, moderadamente rouca, bastante rouca, soprosa ou granulada), textura e intensidade percebida, e diferenciação rigorosa entre características vocais naturais/drive vs efeitos de produção (distorção, saturação, compressão, equalização).
  - D. Emoção e interpretação: Emoções transmitidas (tristeza, nostalgia, serenidade, paixão, agressividade, alegria, melancolia, intensidade dramática, etc.), dinâmica vocal, expressividade, pausas, respirações e mudanças de intensidade.
  - E. Naturalidade e indícios de síntese artificial: Sinais de naturalidade ou artificialidade (variações naturais de timbre e intensidade, respirações e articulação, transições entre notas, continuidade vocal, vibrato uniforme, pronúncias, artefatos digitais). Classificação probabilística: 'Indícios Fracos', 'Indícios Moderados', 'Indícios Fortes' ou 'Inconclusivos'. NUNCA afirme que a voz é de IA apenas por soar perfeita, grave, rouca ou afinada; pondere autotune, compressão e edição digital.
  - Análise Técnica Complementar: Estime F0 (faixa e média), variação de altura em semitons, estabilidade e intensidade. REGRA CRUCIAL: Diferencie a frequência fundamental da voz (F0, ex: 100-350 Hz) da taxa de amostragem do arquivo de áudio (ex: 44.1 kHz ou 48 kHz). NUNCA apresente a taxa de amostragem como sendo a frequência da voz!
  - F. Características vocais recomendadas para recriação: Recomendações para configurar no Suno (tipo de timbre, textura/rouquidão, região vocal, estilo de interpretação/emoção, fraseado e nível de efeitos/processamento).
  - G. Prompt vocal completo em inglês: Prompt otimizado para o campo "Style of Music" do Suno descrevendo as características vocais com precisão. NÃO inclua instrumentos, gêneros ou BPM no prompt, a menos que sejam estritamente necessários para o estilo vocal.
  - H. Prompt vocal curto em inglês: Versão mais concisa e compacta em inglês focada exclusivamente nas palavras-chave essenciais de voz.
  - Versões em português: Versão traduzida em português tanto do prompt completo quanto do prompt curto.

INTEGRIDADE DOS DADOS:
Se o áudio não tiver voz humana discernível ou for puramente instrumental, defina hasVoice como false e forneça limitationNote com clareza. Evite qualquer afirmação categórica sem evidências.`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: {
          parts: [
            {
              inlineData: {
                mimeType,
                data: audioBase64,
              },
            },
            { text: prompt },
          ],
        },
        config: {
          systemInstruction:
            'Você é o motor especialista de análise vocal do JF Music Analyzer IA para a função "Analisar Voz" e comando /analisarvoz. Responda em JSON válido com precisão técnica inquestionável e rigor acústico.',
          responseMimeType: 'application/json',
          responseSchema: {
            type: 'OBJECT' as any,
            properties: {
              hasVoice: { type: 'BOOLEAN' as any },
              limitationNote: { type: 'STRING' as any },
              sectionA_resumoVocal: {
                type: 'OBJECT' as any,
                properties: {
                  overview: { type: 'STRING' as any },
                  keyHighlights: {
                    type: 'ARRAY' as any,
                    items: { type: 'STRING' as any },
                  },
                  vocalProfileSummary: { type: 'STRING' as any },
                },
                required: ['overview', 'keyHighlights', 'vocalProfileSummary'],
              },
              sectionB_timbreRegistro: {
                type: 'OBJECT' as any,
                properties: {
                  perceptualClassification: { type: 'STRING' as any },
                  perceivedPresentation: { type: 'STRING' as any },
                  timbreDescriptors: {
                    type: 'ARRAY' as any,
                    items: { type: 'STRING' as any },
                  },
                  timbreDescription: { type: 'STRING' as any },
                  resonanceAndProjection: { type: 'STRING' as any },
                  articulationAndClarity: { type: 'STRING' as any },
                  speechVsSingingPitchNote: { type: 'STRING' as any },
                },
                required: [
                  'perceptualClassification',
                  'perceivedPresentation',
                  'timbreDescriptors',
                  'timbreDescription',
                  'resonanceAndProjection',
                  'articulationAndClarity',
                  'speechVsSingingPitchNote',
                ],
              },
              sectionC_texturaRouquidao: {
                type: 'OBJECT' as any,
                properties: {
                  roughnessClassification: { type: 'STRING' as any },
                  textureAndPerceivedIntensity: { type: 'STRING' as any },
                  vocalCharacteristicsVsEffects: { type: 'STRING' as any },
                },
                required: [
                  'roughnessClassification',
                  'textureAndPerceivedIntensity',
                  'vocalCharacteristicsVsEffects',
                ],
              },
              sectionD_emocaoInterpretacao: {
                type: 'OBJECT' as any,
                properties: {
                  transmittedEmotions: {
                    type: 'ARRAY' as any,
                    items: { type: 'STRING' as any },
                  },
                  vocalDynamicsAndExpressiveness: { type: 'STRING' as any },
                  pausesAndBreathing: { type: 'STRING' as any },
                  vibratoAndArticulation: { type: 'STRING' as any },
                  intensityChanges: { type: 'STRING' as any },
                },
                required: [
                  'transmittedEmotions',
                  'vocalDynamicsAndExpressiveness',
                  'pausesAndBreathing',
                  'vibratoAndArticulation',
                  'intensityChanges',
                ],
              },
              sectionE_naturalidadeIndiciosIA: {
                type: 'OBJECT' as any,
                properties: {
                  observableSignsClassification: {
                    type: 'STRING' as any,
                    enum: [
                      'Indícios Fracos',
                      'Indícios Moderados',
                      'Indícios Fortes',
                      'Inconclusivos',
                    ],
                  },
                  classificationExplanation: { type: 'STRING' as any },
                  timbreAndIntensityVariations: { type: 'STRING' as any },
                  breathingAndArticulationNaturalness: { type: 'STRING' as any },
                  noteTransitionsAndContinuity: { type: 'STRING' as any },
                  vibratoUniformity: { type: 'STRING' as any },
                  pronunciationAndArtifacts: { type: 'STRING' as any },
                  autotuneAndStudioEffectsImpact: { type: 'STRING' as any },
                  limitationsOfEvaluation: { type: 'STRING' as any },
                },
                required: [
                  'observableSignsClassification',
                  'classificationExplanation',
                  'timbreAndIntensityVariations',
                  'breathingAndArticulationNaturalness',
                  'noteTransitionsAndContinuity',
                  'vibratoUniformity',
                  'pronunciationAndArtifacts',
                  'autotuneAndStudioEffectsImpact',
                  'limitationsOfEvaluation',
                ],
              },
              sectionComplementar_dsp: {
                type: 'OBJECT' as any,
                properties: {
                  f0RangeHz: { type: 'STRING' as any },
                  f0AverageHz: { type: 'NUMBER' as any },
                  pitchRangeSemitones: { type: 'STRING' as any },
                  vocalStabilityJitter: { type: 'STRING' as any },
                  vocalIntensityRmsDb: { type: 'STRING' as any },
                  sampleRateDistinctionNote: { type: 'STRING' as any },
                  spectralCharacteristics: { type: 'STRING' as any },
                },
                required: [
                  'f0RangeHz',
                  'pitchRangeSemitones',
                  'vocalStabilityJitter',
                  'vocalIntensityRmsDb',
                  'sampleRateDistinctionNote',
                  'spectralCharacteristics',
                ],
              },
              sectionF_caracteristicasRecriacao: {
                type: 'OBJECT' as any,
                properties: {
                  timbreType: { type: 'STRING' as any },
                  textureAndRoughness: { type: 'STRING' as any },
                  perceivedVocalRegister: { type: 'STRING' as any },
                  interpretationAndEmotion: { type: 'STRING' as any },
                  deliveryAndPhrasing: { type: 'STRING' as any },
                  desirableEffectsAndProcessingLevel: { type: 'STRING' as any },
                },
                required: [
                  'timbreType',
                  'textureAndRoughness',
                  'perceivedVocalRegister',
                  'interpretationAndEmotion',
                  'deliveryAndPhrasing',
                  'desirableEffectsAndProcessingLevel',
                ],
              },
              sectionG_promptCompletoIngles: { type: 'STRING' as any },
              sectionH_promptCurtoIngles: { type: 'STRING' as any },
              promptsPortugues: {
                type: 'OBJECT' as any,
                properties: {
                  promptCompleto: { type: 'STRING' as any },
                  promptCurto: { type: 'STRING' as any },
                },
                required: ['promptCompleto', 'promptCurto'],
              },
            },
            required: [
              'hasVoice',
              'sectionA_resumoVocal',
              'sectionB_timbreRegistro',
              'sectionC_texturaRouquidao',
              'sectionD_emocaoInterpretacao',
              'sectionE_naturalidadeIndiciosIA',
              'sectionComplementar_dsp',
              'sectionF_caracteristicasRecriacao',
              'sectionG_promptCompletoIngles',
              'sectionH_promptCurtoIngles',
              'promptsPortugues',
            ],
          },
          temperature: 0.25,
        },
      });

      const text = response.text;
      if (!text) {
        throw new Error('O modelo não retornou dados para a análise vocal.');
      }

      const report = JSON.parse(text.trim());
      res.json({ report });
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Erro ao processar a função Analisar Voz';
      console.error('Erro em /api/analisar-voz:', msg);
      res.status(500).json({ error: msg });
    }
  });

  if (process.env.NODE_ENV === 'production') {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  } else {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`JF Music Analyzer IA server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
