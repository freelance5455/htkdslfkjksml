import express from 'express';
import http from 'http';
import path from 'path';
import { fileURLToPath } from 'url';
import { WebSocketServer, WebSocket } from 'ws';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export interface MultiplayerPlayerState {
  id: string;
  name: string;
  roomCode: string;
  carId: string;
  paintHex: string;
  finishType: string;
  rimHex: string;
  caliperHex: string;
  aeroPreset: string;
  trackProgress: number; // 0..1 normalized lap spline progress
  lap: number;
  lateralOffset: number;
  speedKmh: number;
  worldX: number;
  worldY: number;
  worldZ: number;
  heading: number;
  driftAngle: number;
  isBraking: boolean;
  isNitro: boolean;
  finished: boolean;
  finishTimeMs: number | null;
  lastUpdated: number;
}

interface RoomState {
  code: string;
  levelIndex: number;
  status: 'lobby' | 'countdown' | 'racing' | 'finished';
  raceStartTime: number | null;
  players: Map<string, MultiplayerPlayerState>;
}

const rooms = new Map<string, RoomState>();

function getOrCreateRoom(code: string): RoomState {
  const normalized = (code || 'APEX-1').toUpperCase().slice(0, 12);
  let room = rooms.get(normalized);
  if (!room) {
    room = {
      code: normalized,
      levelIndex: 0,
      status: 'racing',
      raceStartTime: Date.now(),
      players: new Map(),
    };
    rooms.set(normalized, room);
  }
  return room;
}

async function startServer() {
  const app = express();
  app.use(express.json());

  const server = http.createServer(app);
  const wss = new WebSocketServer({ noServer: true });

  // Handle HTTP -> WebSocket upgrade on /ws
  server.on('upgrade', (request, socket, head) => {
    const url = new URL(request.url || '/', `http://${request.headers.host || 'localhost'}`);
    if (url.pathname === '/ws') {
      wss.handleUpgrade(request, socket, head, (ws) => {
        wss.emit('connection', ws, request);
      });
    } else {
      // Allow Vite HMR or other upgrades if applicable
    }
  });

  const clientMap = new Map<WebSocket, { playerId: string; roomCode: string }>();

  function broadcastToRoom(roomCode: string, payload: unknown, excludeWs?: WebSocket) {
    const message = JSON.stringify(payload);
    for (const [clientWs, meta] of clientMap.entries()) {
      if (meta.roomCode === roomCode && clientWs !== excludeWs && clientWs.readyState === WebSocket.OPEN) {
        clientWs.send(message);
      }
    }
  }

  wss.on('connection', (ws: WebSocket) => {
    ws.on('message', (raw) => {
      try {
        const msg = JSON.parse(String(raw));
        if (!msg || typeof msg.type !== 'string') return;

        if (msg.type === 'room:join') {
          const roomCode = String(msg.roomCode || 'APEX-1').toUpperCase();
          const playerId = String(msg.player?.id || `p_${Math.random().toString(36).slice(2, 9)}`);
          const room = getOrCreateRoom(roomCode);

          // Remove from previous room if switching
          const prev = clientMap.get(ws);
          if (prev && prev.roomCode !== roomCode) {
            const oldRoom = rooms.get(prev.roomCode);
            if (oldRoom) {
              oldRoom.players.delete(prev.playerId);
              broadcastToRoom(prev.roomCode, {
                type: 'player:left',
                playerId: prev.playerId,
              });
            }
          }

          const state: MultiplayerPlayerState = {
            id: playerId,
            name: String(msg.player?.name || 'Driver').slice(0, 20),
            roomCode,
            carId: String(msg.player?.carId || 'valkyrie-amr26'),
            paintHex: String(msg.player?.paintHex || '#EF4444'),
            finishType: String(msg.player?.finishType || 'metallic'),
            rimHex: String(msg.player?.rimHex || '#E2E8F0'),
            caliperHex: String(msg.player?.caliperHex || '#F59E0B'),
            aeroPreset: String(msg.player?.aeroPreset || 'gt3'),
            trackProgress: Number(msg.player?.trackProgress || 0),
            lap: Number(msg.player?.lap || 1),
            lateralOffset: Number(msg.player?.lateralOffset || 0),
            speedKmh: Number(msg.player?.speedKmh || 0),
            worldX: Number(msg.player?.worldX || 0),
            worldY: Number(msg.player?.worldY || 0),
            worldZ: Number(msg.player?.worldZ || 0),
            heading: Number(msg.player?.heading || 0),
            driftAngle: Number(msg.player?.driftAngle || 0),
            isBraking: Boolean(msg.player?.isBraking),
            isNitro: Boolean(msg.player?.isNitro),
            finished: false,
            finishTimeMs: null,
            lastUpdated: Date.now(),
          };

          room.players.set(playerId, state);
          clientMap.set(ws, { playerId, roomCode });

          // Send full authoritative room state to joining client
          ws.send(
            JSON.stringify({
              type: 'room:init',
              roomCode: room.code,
              levelIndex: room.levelIndex,
              status: room.status,
              raceStartTime: room.raceStartTime,
              players: Array.from(room.players.values()),
            })
          );

          // Broadcast idempotent join event to peers
          broadcastToRoom(
            roomCode,
            {
              type: 'player:joined',
              player: state,
            },
            ws
          );
        } else if (msg.type === 'player:update') {
          const meta = clientMap.get(ws);
          if (!meta) return;
          const room = rooms.get(meta.roomCode);
          if (!room) return;
          const existing = room.players.get(meta.playerId);
          if (!existing) return;

          if (typeof msg.name === 'string') existing.name = msg.name.slice(0, 20);
          if (typeof msg.carId === 'string') existing.carId = msg.carId;
          if (typeof msg.paintHex === 'string') existing.paintHex = msg.paintHex;
          if (typeof msg.finishType === 'string') existing.finishType = msg.finishType;
          if (typeof msg.rimHex === 'string') existing.rimHex = msg.rimHex;
          if (typeof msg.caliperHex === 'string') existing.caliperHex = msg.caliperHex;
          if (typeof msg.aeroPreset === 'string') existing.aeroPreset = msg.aeroPreset;
          if (typeof msg.trackProgress === 'number') existing.trackProgress = msg.trackProgress;
          if (typeof msg.lap === 'number') existing.lap = msg.lap;
          if (typeof msg.lateralOffset === 'number') existing.lateralOffset = msg.lateralOffset;
          if (typeof msg.speedKmh === 'number') existing.speedKmh = msg.speedKmh;
          if (typeof msg.worldX === 'number') existing.worldX = msg.worldX;
          if (typeof msg.worldY === 'number') existing.worldY = msg.worldY;
          if (typeof msg.worldZ === 'number') existing.worldZ = msg.worldZ;
          if (typeof msg.heading === 'number') existing.heading = msg.heading;
          if (typeof msg.driftAngle === 'number') existing.driftAngle = msg.driftAngle;
          if (typeof msg.isBraking === 'boolean') existing.isBraking = msg.isBraking;
          if (typeof msg.isNitro === 'boolean') existing.isNitro = msg.isNitro;
          if (typeof msg.finished === 'boolean') existing.finished = msg.finished;
          if (typeof msg.finishTimeMs === 'number') existing.finishTimeMs = msg.finishTimeMs;
          existing.lastUpdated = Date.now();

          broadcastToRoom(
            meta.roomCode,
            {
              type: 'player:updated',
              player: existing,
            },
            ws
          );
        } else if (msg.type === 'room:level') {
          const meta = clientMap.get(ws);
          if (!meta) return;
          const room = rooms.get(meta.roomCode);
          if (!room) return;
          const nextLevel = Math.max(0, Math.min(4, Number(msg.levelIndex || 0)));
          room.levelIndex = nextLevel;
          room.raceStartTime = Date.now();
          for (const p of room.players.values()) {
            p.lap = 1;
            p.trackProgress = 0;
            p.finished = false;
            p.finishTimeMs = null;
          }
          broadcastToRoom(meta.roomCode, {
            type: 'room:level_changed',
            levelIndex: room.levelIndex,
            raceStartTime: room.raceStartTime,
          });
        }
      } catch {
        // Ignore malformed packets
      }
    });

    ws.on('close', () => {
      const meta = clientMap.get(ws);
      if (meta) {
        clientMap.delete(ws);
        const room = rooms.get(meta.roomCode);
        if (room) {
          room.players.delete(meta.playerId);
          broadcastToRoom(meta.roomCode, {
            type: 'player:left',
            playerId: meta.playerId,
          });
        }
      }
    });
  });

  // REST endpoint for active rooms overview
  app.get('/api/rooms', (_req, res) => {
    const summary = Array.from(rooms.values()).map((r) => ({
      code: r.code,
      levelIndex: r.levelIndex,
      playerCount: r.players.size,
      players: Array.from(r.players.values()).map((p) => ({
        id: p.id,
        name: p.name,
        carId: p.carId,
        speedKmh: Math.round(p.speedKmh),
        lap: p.lap,
      })),
    }));
    res.json({ rooms: summary });
  });

  if (process.env.NODE_ENV === 'production') {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  } else {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  const PORT = 3000;
  server.listen(PORT, '0.0.0.0', () => {
    console.log(`Apex Horizon Server & WebSocket running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
