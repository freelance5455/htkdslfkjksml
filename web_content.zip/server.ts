import 'dotenv/config';
import express from 'express';
import type { Request, Response, NextFunction } from 'express';
import path from 'path';
import { Readable } from 'node:stream';
import type { ReadableStream as NodeWebReadableStream } from 'node:stream/web';
import { fileURLToPath } from 'url';
import { GoogleGenAI, ThinkingLevel, Type } from '@google/genai';
import type {
  CefrBand,
  ListeningCatalogResponse,
  ListeningQuizQuestion,
  ListeningVideoDetail,
  ListeningVideoItem,
  LocalizedGrammarPayload,
  UiLanguageCode,
  VideoCaptionCue,
  WordClipsPageResponse,
  WordHubData,
  WordVideoClip,
} from './src/types.ts';
import {
  LISTENING_LEVEL_MAP,
  TED_LANG_CODE_MAP,
  buildFallbackTranscriptQuiz,
} from './src/utils/listeningLogic.ts';
import {
  buildSentenceSearchQueries,
  cleanSentenceForVideoSearch,
  dedupeVideoClips,
  extractSentenceClipsFromCues,
  extractWordClipsFromCues,
  interleaveVideoSources,
  parseSrtOrVttToCues,
  type RawTranscriptCue,
  type SentenceVideoClipMatch,
  type SourceVideoMeta,
} from './src/utils/videoClipLogic.ts';
import { sanitizeWordHubData } from './src/utils/wordHubLogic.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT) || 3000;
const GEMINI_LITE_MODEL = 'gemini-3.1-flash-lite';
const GEMINI_MAIN_MODEL = 'gemini-4-hydrogen';

// Free anonymous open-weights model (GPT-OSS 20B via Pollinations) with cooldown tracking
const OPEN_LLM_URL = 'https://text.pollinations.ai/openai';
const OPEN_LLM_MODEL = 'openai-fast';
let openLlmCooldownUntil = 0;
const geminiModelCooldownUntil = new Map<string, number>();

const ALLOWED_AUDIO_MIMES = new Set([
  'audio/webm',
  'audio/mp4',
  'audio/ogg',
  'audio/wav',
  'audio/mpeg',
  'audio/aac',
]);

const ALLOWED_LEVELS = new Set(['A0', 'A1', 'A2', 'B1', 'B2', 'C1', 'C2']);

const SCENARIO_PROMPTS: Record<string, string> = {
  free: 'Friendly everyday English conversation about daily life, hobbies, goals, and interesting topics.',
  travel: 'Travel & Airport roleplay: you are a helpful airport/hotel staff member or travel companion.',
  interview: 'Job Interview roleplay: you are a supportive hiring manager asking realistic interview questions.',
  restaurant: 'Restaurant & Cafe roleplay: you are a polite waiter taking orders and recommending dishes.',
  shopping: 'Shopping roleplay: you are a helpful store assistant discussing sizes, prices, and recommendations.',
  doctor: 'Doctor Clinic roleplay: you are a caring clinic receptionist or doctor asking about symptoms and giving simple advice.',
  hotel: 'Hotel Reception roleplay: you are a friendly hotel receptionist helping with check-in, room requests, and local tips.',
  friends: 'Making New Friends roleplay: you are a warm new friend chatting about movies, food, work, and weekend plans.',
};

// Bounded server-side translation cache (English sentence -> Arabic translation)
const MAX_TRANSLATION_CACHE = 15000;
const translationCache = new Map<string, string>();

function setCachedTranslation(en: string, ar: string): void {
  if (translationCache.size >= MAX_TRANSLATION_CACHE) {
    const firstKey = translationCache.keys().next().value;
    if (firstKey !== undefined) {
      translationCache.delete(firstKey);
    }
  }
  translationCache.set(en, ar);
}

// Lightweight per-IP rate limiter for AI endpoints
const rateBuckets = new Map<string, { count: number; resetAt: number }>();
function rateLimitApi(req: Request, res: Response, next: NextFunction): void {
  const now = Date.now();
  const ip = req.ip || 'local';
  const entry = rateBuckets.get(ip);
  if (!entry || now > entry.resetAt) {
    rateBuckets.set(ip, { count: 1, resetAt: now + 60_000 });
    next();
    return;
  }
  if (entry.count >= 120) {
    res.status(429).json({ error: 'تم تجاوز الحد المسموح مؤقتاً، حاول بعد لحظات.' });
    return;
  }
  entry.count += 1;
  next();
}

let cachedAiClient: GoogleGenAI | null = null;
function getAiClient(): GoogleGenAI | null {
  const apiKey = (process.env.GEMINI_API_KEY || '').trim();
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
    return null;
  }
  if (!cachedAiClient) {
    cachedAiClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return cachedAiClient;
}

function normalizeAudioMime(rawMime: unknown): string | null {
  if (typeof rawMime !== 'string') return null;
  const base = rawMime.split(';')[0].trim().toLowerCase();
  if (ALLOWED_AUDIO_MIMES.has(base)) return base;
  return null;
}

function validateBase64Audio(raw: unknown): string | null {
  if (typeof raw !== 'string') return null;
  const trimmed = raw.trim();
  if (!trimmed || trimmed.length > 3_600_000) return null;
  if (!/^[A-Za-z0-9+/=]+$/.test(trimmed)) return null;
  return trimmed;
}

function parseSafeJson<T>(rawText: string | undefined): T | null {
  if (!rawText) return null;
  const trimmed = rawText
    .trim()
    .replace(/^```(?:json)?\s*/i, '')
    .replace(/\s*```$/, '')
    .trim();
  try {
    return JSON.parse(trimmed) as T;
  } catch {
    const firstBrace = trimmed.indexOf('{');
    const lastBrace = trimmed.lastIndexOf('}');
    if (firstBrace >= 0 && lastBrace > firstBrace) {
      try {
        return JSON.parse(trimmed.slice(firstBrace, lastBrace + 1)) as T;
      } catch {
        return null;
      }
    }
    return null;
  }
}

function withTimeout<T>(promise: Promise<T>, ms: number, label: string): Promise<T> {
  return new Promise<T>((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error(`${label} timed out after ${ms}ms`)), ms);
    promise.then(
      (val) => {
        clearTimeout(timer);
        resolve(val);
      },
      (err) => {
        clearTimeout(timer);
        reject(err);
      }
    );
  });
}

function isTransientErr(err: unknown): boolean {
  const msg = err instanceof Error ? err.message : String(err);
  return (
    msg.includes('503') ||
    msg.includes('429') ||
    msg.includes('UNAVAILABLE') ||
    msg.includes('RESOURCE_EXHAUSTED') ||
    msg.includes('timed out')
  );
}

function isDailyQuotaErr(err: unknown): boolean {
  const msg = err instanceof Error ? err.message : String(err);
  return (
    msg.includes('GenerateRequestsPerDay') ||
    msg.includes('RESOURCE_EXHAUSTED') ||
    msg.includes('quota exceeded') ||
    msg.includes('Quota exceeded')
  );
}

async function callGeminiStructured<T>(params: {
  contents: unknown;
  systemInstruction?: string;
  responseSchema: Record<string, unknown>;
  timeoutMs?: number;
  preferLite?: boolean;
}): Promise<{ data: T; modelUsed: string }> {
  const ai = getAiClient();
  if (!ai) {
    throw new Error('Gemini API key unavailable');
  }

  const orderedModels = params.preferLite
    ? [GEMINI_LITE_MODEL, GEMINI_MAIN_MODEL]
    : [GEMINI_MAIN_MODEL, GEMINI_LITE_MODEL];

  let lastErr: unknown = new Error('All Gemini models currently cooling down');
  const now = Date.now();

  for (const model of orderedModels) {
    const cooldown = geminiModelCooldownUntil.get(model) || 0;
    if (now < cooldown) continue;

    try {
      const config: Record<string, unknown> = {
        responseMimeType: 'application/json',
        responseSchema: params.responseSchema,
        thinkingConfig: {
          thinkingLevel: model === GEMINI_LITE_MODEL ? ThinkingLevel.MINIMAL : ThinkingLevel.LOW,
        },
      };
      if (params.systemInstruction) {
        config.systemInstruction = params.systemInstruction;
      }

      const response = await withTimeout(
        ai.models.generateContent({
          model,
          contents: params.contents as Parameters<typeof ai.models.generateContent>[0]['contents'],
          config: config as Parameters<typeof ai.models.generateContent>[0]['config'],
        }),
        params.timeoutMs ?? 12_000,
        model
      );

      const parsed = parseSafeJson<T>(response.text);
      if (parsed) {
        return { data: parsed, modelUsed: model };
      }
      throw new Error(`${model} returned non-JSON`);
    } catch (err) {
      lastErr = err;
      const errMsg = err instanceof Error ? err.message : String(err);
      if (isDailyQuotaErr(err)) {
        // Cool down daily-quota-exhausted model for 60m to prevent repeated 429 failures
        geminiModelCooldownUntil.set(model, Date.now() + 60 * 60_000);
        console.info(`[gemini:${model}] daily quota reached; cooling down 60m.`);
      } else if (errMsg.includes('timed out') || isTransientErr(err)) {
        // Brief circuit breaker on slow/overloaded model
        geminiModelCooldownUntil.set(model, Date.now() + 90_000);
        console.info(`[gemini:${model}] transient timeout/overload; cooling down 90s.`);
      }
    }
  }
  throw lastErr;
}

async function callOpenLlmJson<T>(
  systemPrompt: string,
  userPrompt: string,
  timeoutMs = 15000
): Promise<T> {
  if (Date.now() < openLlmCooldownUntil) {
    const secs = Math.ceil((openLlmCooldownUntil - Date.now()) / 1000);
    throw new Error(`OpenLLM cooling down (${secs}s)`);
  }

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(OPEN_LLM_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      signal: controller.signal,
      body: JSON.stringify({
        model: OPEN_LLM_MODEL,
        response_format: { type: 'json_object' },
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: userPrompt },
        ],
      }),
    });

    if (res.status === 402 || res.status === 429) {
      const retryHeader = parseInt(res.headers.get('retry-after') || '60', 10);
      const waitSec = Number.isFinite(retryHeader) && retryHeader > 0 ? Math.min(retryHeader, 300) : 60;
      openLlmCooldownUntil = Date.now() + waitSec * 1000;
      throw new Error(`OpenLLM rate-limited (${res.status}, retry after ${waitSec}s)`);
    }
    if (!res.ok) {
      openLlmCooldownUntil = Date.now() + 5 * 60_000;
      throw new Error(`OpenLLM HTTP ${res.status}`);
    }

    const rawBody = await res.text();
    let content: string | undefined;
    try {
      const data = JSON.parse(rawBody) as {
        choices?: Array<{ message?: { content?: string } }>;
      };
      content = data?.choices?.[0]?.message?.content;
    } catch {
      openLlmCooldownUntil = Date.now() + 10 * 60_000;
      throw new Error('OpenLLM returned non-JSON response');
    }

    const parsed = parseSafeJson<T>(content);
    if (!parsed) {
      openLlmCooldownUntil = Date.now() + 10 * 60_000;
      throw new Error('OpenLLM returned non-JSON response');
    }
    return parsed;
  } catch (err) {
    if (Date.now() >= openLlmCooldownUntil) {
      openLlmCooldownUntil = Date.now() + 5 * 60_000;
    }
    throw err;
  } finally {
    clearTimeout(timer);
  }
}

interface CoachJson {
  userTranscript?: string;
  replyEn?: string;
  replyAr?: string;
  hasErrors?: boolean;
  correctedEn?: string;
  explanationAr?: string;
  betterPhrasing?: string;
  score?: number;
  suggestions?: string[];
}

export function createApiApp(): express.Express {
  const app = express();
  app.disable('x-powered-by');
  app.use((_req: Request, res: Response, next: NextFunction) => {
    res.setHeader('Cross-Origin-Opener-Policy', 'same-origin-allow-popups');
    next();
  });
  app.use(express.json({ limit: '5mb' }));

  app.get('/api/health', (_req: Request, res: Response) => {
    res.json({
      ok: true,
      aiReady: true,
      geminiReady: Boolean(getAiClient()),
      openLlmReady: true,
    });
  });

  // Strict SSRF-safe validator for TED + open educational direct video CDNs
  function isAllowedOpenVideoUrl(raw: string): URL | null {
    try {
      const parsed = new URL(raw);
      if (parsed.protocol !== 'https:') return null;
      if (parsed.username || parsed.password) return null;
      const host = parsed.hostname.toLowerCase();
      const allowed =
        host === 'ted.com' ||
        host.endsWith('.ted.com') ||
        host === 'tedcdn.com' ||
        host.endsWith('.tedcdn.com') ||
        host === 'archive.org' ||
        host.endsWith('.archive.org') ||
        host === 'voanews.com' ||
        host.endsWith('.voanews.com') ||
        host === 'voa-video-ns.akamaized.net' ||
        host === 'upload.wikimedia.org' ||
        host === 'commons.wikimedia.org';
      if (!allowed) return null;
      return parsed;
    } catch {
      return null;
    }
  }

  // Range-capable streaming proxy for TED + Archive.org + VOA + Wikimedia MP4/WebM videos
  app.get('/api/video-proxy', async (req: Request, res: Response) => {
    const rawUrl = typeof req.query.url === 'string' ? req.query.url.trim() : '';
    const initialUrl = isAllowedOpenVideoUrl(rawUrl);
    if (!initialUrl) {
      res.status(400).json({ error: 'Invalid or disallowed video URL.' });
      return;
    }

    const controller = new AbortController();
    const onClose = () => controller.abort();
    req.on('close', onClose);
    let streamingStarted = false;

    try {
      const upstreamHeaders: Record<string, string> = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        Accept: '*/*',
      };
      const MAX_VERCEL_CHUNK_BYTES = 2_400_000;
      const rangeHeader = req.headers.range;
      if (typeof rangeHeader === 'string' && /^bytes=\d*-\d*(,\s*\d*-\d*)*$/i.test(rangeHeader)) {
        const singleMatch = /^bytes=(\d+)-(\d*)$/i.exec(rangeHeader.trim());
        if (singleMatch && process.env.VERCEL === '1') {
          const startByte = Number.parseInt(singleMatch[1], 10);
          const requestedEnd = singleMatch[2] ? Number.parseInt(singleMatch[2], 10) : Number.NaN;
          const cappedEnd =
            Number.isFinite(requestedEnd) && requestedEnd >= startByte
              ? Math.min(requestedEnd, startByte + MAX_VERCEL_CHUNK_BYTES)
              : startByte + MAX_VERCEL_CHUNK_BYTES;
          upstreamHeaders.Range = `bytes=${startByte}-${cappedEnd}`;
        } else {
          upstreamHeaders.Range = rangeHeader;
        }
      } else if (process.env.VERCEL === '1') {
        upstreamHeaders.Range = `bytes=0-${MAX_VERCEL_CHUNK_BYTES}`;
      }

      // Manually follow up to 4 redirects while strictly validating every hop against allowlist
      let currentUrl = initialUrl;
      let upstream: globalThis.Response | null = null;
      for (let hop = 0; hop < 5; hop++) {
        const resp = await fetch(currentUrl.toString(), {
          method: 'GET',
          headers: upstreamHeaders,
          redirect: 'manual',
          signal: controller.signal,
        });
        if (resp.status >= 300 && resp.status < 400) {
          const loc = resp.headers.get('location');
          if (!loc) {
            res.status(502).json({ error: 'Invalid redirect from video host.' });
            return;
          }
          const resolved = new URL(loc, currentUrl).toString();
          const nextValid = isAllowedOpenVideoUrl(resolved);
          if (!nextValid) {
            res.status(403).json({ error: 'Disallowed video redirect target.' });
            return;
          }
          currentUrl = nextValid;
          continue;
        }
        upstream = resp;
        break;
      }

      if (!upstream || (!upstream.ok && upstream.status !== 206) || !upstream.body) {
        res.status(upstream?.status || 502).end();
        return;
      }

      const contentType = upstream.headers.get('content-type') || 'video/mp4';
      if (!contentType.startsWith('video/') && !contentType.startsWith('application/octet-stream')) {
        res.status(415).json({ error: 'Upstream response is not a video stream.' });
        return;
      }

      res.status(upstream.status);
      res.setHeader('Content-Type', contentType);
      res.setHeader('Accept-Ranges', upstream.headers.get('accept-ranges') || 'bytes');
      const contentRange = upstream.headers.get('content-range');
      if (contentRange) res.setHeader('Content-Range', contentRange);
      const contentLength = upstream.headers.get('content-length');
      if (contentLength) res.setHeader('Content-Length', contentLength);
      res.setHeader('Cache-Control', 'public, max-age=86400, stale-while-revalidate=86400');

      const nodeStream = Readable.fromWeb(upstream.body as unknown as NodeWebReadableStream);
      const cleanup = () => {
        req.off('close', onClose);
      };
      res.once('finish', cleanup);
      res.once('close', cleanup);
      nodeStream.on('error', () => {
        cleanup();
        if (!res.headersSent) res.status(502).end();
        else res.end();
      });
      streamingStarted = true;
      nodeStream.pipe(res);
    } catch (err) {
      if (!controller.signal.aborted && !res.headersSent) {
        console.warn('[video-proxy] error:', err instanceof Error ? err.message : err);
        res.status(502).json({ error: 'Video proxy stream unavailable.' });
      }
    } finally {
      if (!streamingStarted) {
        req.off('close', onClose);
      }
    }
  });

  // Shared fast parallel Google GTX translator for instant multi-language fill
  const SERVER_GTX_TL: Record<string, string> = {
    ar: 'ar',
    hi: 'hi',
    zh: 'zh-CN',
    ru: 'ru',
    de: 'de',
    fr: 'fr',
    es: 'es',
    it: 'it',
    pt: 'pt',
    sv: 'sv',
  };
  const SERVER_LANG_NAMES: Record<string, string> = {
    ar: 'Arabic',
    hi: 'Hindi',
    zh: 'Simplified Chinese',
    ru: 'Russian',
    de: 'German',
    fr: 'French',
    es: 'Spanish',
    it: 'Italian',
    pt: 'Portuguese',
    sv: 'Swedish',
  };

  async function serverGtxTranslateBatch(
    items: string[],
    sourceLang: string,
    targetLang: string
  ): Promise<Record<string, string>> {
    const out: Record<string, string> = {};
    if (!items.length) return out;
    const tl = SERVER_GTX_TL[targetLang] || 'ar';
    const chunks: string[][] = [];
    for (let i = 0; i < items.length; i += 8) {
      chunks.push(items.slice(i, i + 8));
    }

    await Promise.all(
      chunks.map(async (chunk) => {
        const sep = '\n|||TMN|||\n';
        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort(), 4500);
        try {
          const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=${encodeURIComponent(
            sourceLang
          )}&tl=${encodeURIComponent(tl)}&dt=t&q=${encodeURIComponent(chunk.join(sep))}`;
          const r = await fetch(url, {
            headers: { 'User-Agent': 'Mozilla/5.0' },
            signal: controller.signal,
          });
          if (r.ok) {
            const j = (await r.json()) as unknown;
            if (Array.isArray(j) && Array.isArray(j[0])) {
              const joined = (j[0] as unknown[])
                .map((p) => (Array.isArray(p) && typeof p[0] === 'string' ? p[0] : ''))
                .join('');
              const parts = joined.split(/\s*\|\|\|\s*TMN\s*\|\|\|\s*/i);
              if (parts.length === chunk.length) {
                chunk.forEach((src, i) => {
                  const val = parts[i]?.trim();
                  if (val) out[src] = val;
                });
                return;
              }
            }
          }
          // Per-item parallel fallback if separator count drifted
          await Promise.all(
            chunk.map(async (src) => {
              try {
                const r2 = await fetch(
                  `https://translate.googleapis.com/translate_a/single?client=gtx&sl=${encodeURIComponent(
                    sourceLang
                  )}&tl=${encodeURIComponent(tl)}&dt=t&q=${encodeURIComponent(src)}`,
                  { headers: { 'User-Agent': 'Mozilla/5.0' }, signal: controller.signal }
                );
                if (!r2.ok) return;
                const j2 = (await r2.json()) as unknown;
                if (Array.isArray(j2) && Array.isArray(j2[0])) {
                  const val = (j2[0] as unknown[])
                    .map((p) => (Array.isArray(p) && typeof p[0] === 'string' ? p[0] : ''))
                    .join('')
                    .trim();
                  if (val) out[src] = val;
                }
              } catch {
                // ignore
              }
            })
          );
        } catch {
          // ignore chunk error
        } finally {
          clearTimeout(timer);
        }
      })
    );
    return out;
  }

  // Fast server-side batch translator (ar->lang and en->lang) with LRU cache and zero browser CORS issues
  const uiTransCache = new Map<string, string>();
  app.post('/api/translate-ui-batch', rateLimitApi, async (req: Request, res: Response) => {
    try {
      const body = req.body as { texts?: unknown; targetLang?: unknown; sourceLang?: unknown };
      const rawLang = typeof body?.targetLang === 'string' ? body.targetLang.trim().toLowerCase() : 'ar';
      const rawSrc =
        body?.sourceLang === 'en' || body?.sourceLang === 'auto' ? body.sourceLang : 'ar';
      if (!SERVER_GTX_TL[rawLang] || (rawSrc === 'ar' && rawLang === 'ar')) {
        res.json({ translations: {} });
        return;
      }
      if (!Array.isArray(body?.texts) || body.texts.length === 0) {
        res.json({ translations: {} });
        return;
      }

      const unique: string[] = [];
      const seen = new Set<string>();
      for (const item of body.texts.slice(0, 60)) {
        if (typeof item === 'string') {
          const clean = item.trim().slice(0, 420);
          if (clean && !seen.has(clean)) {
            seen.add(clean);
            unique.push(clean);
          }
        }
      }

      const translations: Record<string, string> = {};
      const missing: string[] = [];
      for (const text of unique) {
        const hit = uiTransCache.get(`${rawSrc}::${rawLang}::${text}`);
        if (hit) translations[text] = hit;
        else missing.push(text);
      }

      if (missing.length > 0) {
        let fresh = await serverGtxTranslateBatch(missing, rawSrc, rawLang);
        const stillMissing = missing.filter((m) => !fresh[m]);
        const ai = stillMissing.length > 0 ? getAiClient() : null;
        const liteCooldown = geminiModelCooldownUntil.get(GEMINI_LITE_MODEL) || 0;
        if (stillMissing.length > 0 && ai && Date.now() >= liteCooldown) {
          try {
            const targetLangName = SERVER_LANG_NAMES[rawLang] || rawLang;
            const sourceLangName = rawSrc === 'en' ? 'English' : 'Arabic';
            const prompt = `Translate each ${sourceLangName} UI/learning string into natural, concise ${targetLangName}. Return ONLY valid JSON mapping exact input string -> translated string.\nInputs:\n${JSON.stringify(stillMissing)}`;
            const gemPromise = ai.models.generateContent({
              model: GEMINI_LITE_MODEL,
              contents: prompt,
              config: {
                responseMimeType: 'application/json',
                thinkingConfig: { thinkingLevel: ThinkingLevel.MINIMAL },
              },
            });
            const timeoutPromise = new Promise<never>((_, rej) =>
              setTimeout(() => rej(new Error('timeout')), 5000)
            );
            const resp = await Promise.race([gemPromise, timeoutPromise]);
            const rawText = (resp.text || '').trim();
            if (rawText) {
              const parsed = parseSafeJson<Record<string, unknown>>(rawText);
              if (parsed && typeof parsed === 'object') {
                for (const src of stillMissing) {
                  const val = parsed[src];
                  if (typeof val === 'string' && val.trim()) {
                    fresh[src] = val.trim();
                  }
                }
              }
            }
          } catch (err) {
            if (isDailyQuotaErr(err)) {
              geminiModelCooldownUntil.set(GEMINI_LITE_MODEL, Date.now() + 60 * 60_000);
            }
            // Keep whatever GTX resolved
          }
        }
        for (const [k, v] of Object.entries(fresh)) {
          translations[k] = v;
          if (uiTransCache.size > 15_000) {
            const first = uiTransCache.keys().next().value;
            if (first) uiTransCache.delete(first);
          }
          uiTransCache.set(`${rawSrc}::${rawLang}::${k}`, v);
        }
      }

      res.json({ translations });
    } catch {
      res.json({ translations: {} });
    }
  });

  // 1) Batch translate visible English sentences into target language (crisp 6s AI timeout + instant GTX fill)
  app.post('/api/translate-sentences', rateLimitApi, async (req: Request, res: Response) => {
    try {
      const body = req.body as { sentences?: unknown; targetLang?: unknown };
      if (!Array.isArray(body?.sentences) || body.sentences.length === 0) {
        res.status(400).json({ error: 'قائمة الجمل غير صالحة.' });
        return;
      }

      const rawLang = typeof body?.targetLang === 'string' ? body.targetLang.trim().toLowerCase() : 'ar';
      const targetLang = SERVER_GTX_TL[rawLang] ? rawLang : 'ar';
      const targetLangName = SERVER_LANG_NAMES[targetLang] || 'Arabic';
      const keyPrefix = targetLang === 'ar' ? '' : `${targetLang}::`;

      const uniqueInput: string[] = [];
      const seen = new Set<string>();
      for (const item of body.sentences.slice(0, 30)) {
        if (typeof item === 'string') {
          const clean = item.trim().slice(0, 220);
          if (clean && !seen.has(clean)) {
            seen.add(clean);
            uniqueInput.push(clean);
          }
        }
      }

      if (uniqueInput.length === 0) {
        res.status(400).json({ error: 'لا توجد جمل صالحة للترجمة.' });
        return;
      }

      const translations: Record<string, string> = {};
      const missing: string[] = [];

      for (const s of uniqueInput) {
        const hit = translationCache.get(`${keyPrefix}${s}`);
        if (hit) {
          translations[s] = hit;
        } else {
          missing.push(s);
        }
      }

      if (missing.length === 0) {
        res.json({ translations });
        return;
      }

      // Step 1: Fast parallel Google GTX chunks (~250ms, preserves Gemini daily quota for interactive AI features)
      const gtxFilled = await serverGtxTranslateBatch(missing, 'en', targetLang);
      for (const [en, tr] of Object.entries(gtxFilled)) {
        if (tr) {
          translations[en] = tr;
          setCachedTranslation(`${keyPrefix}${en}`, tr);
        }
      }

      // Step 2: Fill any remaining untranslated items via Gemini Lite (only when not cooling down)
      const stillMissing = missing.filter((s) => !translations[s]);
      const nowMs = Date.now();
      const canUseGemini =
        stillMissing.length > 0 &&
        Boolean(getAiClient()) &&
        (nowMs >= (geminiModelCooldownUntil.get(GEMINI_LITE_MODEL) || 0) ||
          nowMs >= (geminiModelCooldownUntil.get(GEMINI_MAIN_MODEL) || 0));

      if (canUseGemini) {
        try {
          const numberedList = stillMissing.map((s, idx) => `${idx + 1}. ${s}`).join('\n');
          const prompt = `Translate these ${stillMissing.length} short English sentences into natural, accurate ${targetLangName}. Return JSON {"translations":[...]} with exact count ${stillMissing.length}.\n${numberedList}`;
          const resGemini = await callGeminiStructured<{ translations?: string[] }>({
            contents: prompt,
            timeoutMs: 6_000,
            preferLite: true,
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                translations: {
                  type: Type.ARRAY,
                  items: { type: Type.STRING },
                },
              },
              required: ['translations'],
            },
          });
          const arr = Array.isArray(resGemini.data?.translations) ? resGemini.data.translations : [];
          for (let i = 0; i < stillMissing.length; i++) {
            const tr = typeof arr[i] === 'string' ? arr[i].trim() : '';
            if (tr) {
              translations[stillMissing[i]] = tr;
              setCachedTranslation(`${keyPrefix}${stillMissing[i]}`, tr);
            }
          }
        } catch {
          // Graceful fallback: return whatever translations were resolved
        }
      }

      res.json({ translations });
    } catch (err) {
      console.error('[translate-sentences] error:', err instanceof Error ? err.message : err);
      res.status(500).json({ error: 'تعذر ترجمة الجمل حالياً. حاول مرة أخرى.' });
    }
  });

  // 2) Evaluate spoken pronunciation of a target English sentence (audio or transcript)
  app.post('/api/evaluate-speech', rateLimitApi, async (req: Request, res: Response) => {
    try {
      const body = req.body as {
        targetSentence?: unknown;
        spokenText?: unknown;
        audioBase64?: unknown;
        audioMimeType?: unknown;
      };

      const targetSentence =
        typeof body?.targetSentence === 'string' ? body.targetSentence.trim().slice(0, 240) : '';
      if (!targetSentence) {
        res.status(400).json({ error: 'الجملة المستهدفة مطلوبة.' });
        return;
      }

      const spokenText =
        typeof body?.spokenText === 'string' ? body.spokenText.trim().slice(0, 400) : '';
      const audioBase64 = validateBase64Audio(body?.audioBase64);
      const audioMimeType = normalizeAudioMime(body?.audioMimeType);

      if (!spokenText && (!audioBase64 || !audioMimeType)) {
        res.status(400).json({ error: 'يرجى تسجيل الصوت أو إرسال النص المنطوق.' });
        return;
      }

      const promptText = audioBase64
        ? `Listen carefully to the learner's English audio recording. Target sentence: "${targetSentence}". Return ONLY JSON with keys: heardText (exact English transcription), score (integer 0-100, fair & encouraging, contractions equivalent), isMatch (boolean, true if score>=75), feedbackAr (concise Arabic feedback), tipAr (1 short Arabic pronunciation tip).`
        : `Target English sentence: "${targetSentence}". Learner spoke: "${spokenText}". Return ONLY JSON with keys: heardText, score (0-100), isMatch (boolean, score>=75), feedbackAr (concise Arabic feedback), tipAr (1 short Arabic pronunciation tip).`;

      let parsed: {
        heardText?: string;
        score?: number;
        isMatch?: boolean;
        feedbackAr?: string;
        tipAr?: string;
      } | null = null;

      try {
        const contentsPayload =
          audioBase64 && audioMimeType
            ? {
                parts: [
                  { inlineData: { mimeType: audioMimeType, data: audioBase64 } },
                  { text: promptText },
                ],
              }
            : promptText;

        const resGemini = await callGeminiStructured<typeof parsed>({
          contents: contentsPayload,
          timeoutMs: 25_000,
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              heardText: { type: Type.STRING },
              score: { type: Type.NUMBER },
              isMatch: { type: Type.BOOLEAN },
              feedbackAr: { type: Type.STRING },
              tipAr: { type: Type.STRING },
            },
            required: ['heardText', 'score', 'isMatch', 'feedbackAr', 'tipAr'],
          },
        });
        parsed = resGemini.data;
      } catch (err) {
        console.warn('[evaluate-speech] Gemini fallback:', err instanceof Error ? err.message : err);
      }

      if (!parsed && spokenText) {
        try {
          parsed = await callOpenLlmJson(
            'You are an encouraging English pronunciation coach for Arabic speakers. Output ONLY valid JSON.',
            promptText,
            10_000
          );
        } catch {
          // Fall through to deterministic local transcript matcher below
        }
      }

      if (!parsed && spokenText) {
        const norm = (s: string) =>
          s
            .toLowerCase()
            .replace(/[^a-z0-9'\s]/g, ' ')
            .replace(/\s+/g, ' ')
            .trim();
        const tWords = norm(targetSentence).split(' ').filter(Boolean);
        const sWords = norm(spokenText).split(' ').filter(Boolean);
        const sSet = new Set(sWords);
        const matched = tWords.filter((w) => sSet.has(w)).length;
        const ratio = tWords.length > 0 ? matched / tWords.length : 0;
        const exactMatch = norm(targetSentence) === norm(spokenText);
        const localScore = exactMatch ? 100 : Math.round(ratio * 100);
        const isMatch = localScore >= 75;
        res.json({
          heardText: spokenText,
          score: localScore,
          isMatch,
          feedbackAr: isMatch
            ? 'ممتاز! نطقك واضح ومطابق للكلمة المستهدفة.'
            : 'محاولة جيدة! استمع للنطق الصحيح ببطء وحاول مجدداً.',
          tipAr: isMatch ? '' : `ركّز على نطق: ${targetSentence}`,
          source: 'local',
        });
        return;
      }

      if (!parsed) {
        const missingKey = !getAiClient();
        res.status(missingKey ? 503 : 502).json({
          code: missingKey ? 'NO_AI_AUDIO_KEY' : 'AUDIO_EVAL_UNAVAILABLE',
          error: missingKey
            ? 'تحليل التسجيل الصوتي بالذكاء الاصطناعي يحتاج تفعيل مفتاح GEMINI_API_KEY على الخادم، أو استخدم متصفح Chrome/Edge للتعرف الفوري على النطق.'
            : 'تعذر تحليل التسجيل الصوتي حالياً. حاول مجدداً.',
        });
        return;
      }

      const score = Math.max(0, Math.min(100, Math.round(Number(parsed.score) || 0)));
      res.json({
        heardText: (parsed.heardText || spokenText || '').trim(),
        score,
        isMatch: Boolean(parsed.isMatch ?? score >= 75),
        feedbackAr: (parsed.feedbackAr || 'أحسنت! استمر في التدريب.').trim(),
        tipAr: (parsed.tipAr || '').trim(),
        source: 'ai',
      });
    } catch (err) {
      console.error('[evaluate-speech] error:', err instanceof Error ? err.message : err);
      res.status(500).json({ error: 'حدث خطأ أثناء تقييم الصوت. حاول مرة أخرى.' });
    }
  });

  // 3) Interactive English AI Conversation Coach (Fast Free Multi-Engine: Open-Source GPT-OSS + Gemini Cascade)
  app.post('/api/ai-coach', rateLimitApi, async (req: Request, res: Response) => {
    try {
      const body = req.body as {
        scenario?: unknown;
        level?: unknown;
        provider?: unknown;
        history?: unknown;
        userText?: unknown;
        audioBase64?: unknown;
        audioMimeType?: unknown;
      };

      const scenario =
        typeof body?.scenario === 'string' && SCENARIO_PROMPTS[body.scenario]
          ? body.scenario
          : 'free';
      const level =
        typeof body?.level === 'string' && ALLOWED_LEVELS.has(body.level) ? body.level : 'A2';
      const providerPref: 'auto' | 'open' | 'gemini' =
        body?.provider === 'open' || body?.provider === 'gemini' ? body.provider : 'auto';

      const userText =
        typeof body?.userText === 'string' ? body.userText.trim().slice(0, 600) : '';
      const audioBase64 = validateBase64Audio(body?.audioBase64);
      const audioMimeType = normalizeAudioMime(body?.audioMimeType);

      if (!userText && (!audioBase64 || !audioMimeType)) {
        res.status(400).json({ error: 'يرجى كتابة رسالة بالإنجليزية أو تسجيل صوتك.' });
        return;
      }

      const rawHistory = Array.isArray(body?.history) ? body.history.slice(-12) : [];
      const historyLines: string[] = [];
      for (const item of rawHistory) {
        if (item && typeof item === 'object') {
          const rec = item as { role?: unknown; text?: unknown };
          const roleLabel = rec.role === 'model' ? 'Coach' : 'Learner';
          const text = typeof rec.text === 'string' ? rec.text.trim().slice(0, 400) : '';
          if (text) {
            historyLines.push(`${roleLabel}: ${text}`);
          }
        }
      }

      const systemInstruction = `You are a warm, fast, expert English speaking coach helping an Arabic-speaking learner practice real English conversation.
Scenario: ${SCENARIO_PROMPTS[scenario]}
Learner CEFR Level: ${level}. Match your vocabulary and sentence complexity to CEFR ${level}.

Return ONLY valid JSON with these exact keys:
- "userTranscript": exact English text of what the learner wrote or spoke (keep mistakes faithfully so we can correct them).
- "hasErrors": boolean (true if there is any grammar, tense, article, preposition, spelling, or phrasing mistake; false if completely natural).
- "correctedEn": corrected natural English version of the learner's message.
- "explanationAr": concise, friendly Arabic explanation of the mistakes (1-2 sentences), or short Arabic praise if hasErrors is false.
- "betterPhrasing": an even more natural native-speaker way to say it in English.
- "score": integer 0-100 for accuracy & clarity.
- "replyEn": your natural conversational English reply in character (1-2 short sentences) ending with a friendly follow-up question.
- "replyAr": accurate natural Arabic translation of replyEn.
- "suggestions": array of exactly 2 short example English replies the learner could say next.`;

      const contextBlock =
        historyLines.length > 0
          ? `Recent conversation:\n${historyLines.join('\n')}\n\n`
          : 'This is the start of the conversation.\n\n';

      const textTurnPrompt = `${contextBlock}Learner's new message: "${userText}"\nCorrect any mistakes with Arabic explanation and reply in character as JSON.`;
      const audioTurnPrompt = `${contextBlock}The learner sent the attached voice recording.${userText ? ` (Browser transcript hint: "${userText}")` : ''} Transcribe faithfully, correct any mistakes with Arabic explanation, and reply in character as JSON.`;

      const coachSchema = {
        type: Type.OBJECT,
        properties: {
          userTranscript: { type: Type.STRING },
          replyEn: { type: Type.STRING },
          replyAr: { type: Type.STRING },
          hasErrors: { type: Type.BOOLEAN },
          correctedEn: { type: Type.STRING },
          explanationAr: { type: Type.STRING },
          betterPhrasing: { type: Type.STRING },
          score: { type: Type.NUMBER },
          suggestions: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
          },
        },
        required: [
          'userTranscript',
          'replyEn',
          'replyAr',
          'hasErrors',
          'correctedEn',
          'explanationAr',
          'betterPhrasing',
          'score',
          'suggestions',
        ],
      };

      const runGemini = async (): Promise<{ data: CoachJson; label: string }> => {
        const contentsPayload =
          audioBase64 && audioMimeType
            ? {
                parts: [
                  { inlineData: { mimeType: audioMimeType, data: audioBase64 } },
                  { text: audioTurnPrompt },
                ],
              }
            : textTurnPrompt;

        const { data } = await callGeminiStructured<CoachJson>({
          contents: contentsPayload,
          systemInstruction,
          responseSchema: coachSchema,
          timeoutMs: 32_000,
        });

        if (!data || !data.replyEn) {
          throw new Error('Invalid JSON from Gemini');
        }
        return {
          data,
          label: 'Gemini',
        };
      };

      const runOpenLlm = async (): Promise<{ data: CoachJson; label: string }> => {
        if (!userText) {
          throw new Error('OpenLLM requires text input');
        }
        const parsed = await callOpenLlmJson<CoachJson>(systemInstruction, textTurnPrompt, 15_000);
        if (!parsed || !parsed.replyEn) {
          throw new Error('Invalid JSON from OpenLLM');
        }
        return { data: parsed, label: 'GPT-OSS المجاني' };
      };

      let result: { data: CoachJson; label: string } | null = null;
      const audioOnly = Boolean(audioBase64 && audioMimeType && !userText);

      // Smart routing: OpenLLM when ready (fast ~3s), automatic instant failover to Gemini cascade when cooling down!
      const runners: Array<() => Promise<{ data: CoachJson; label: string }>> = audioOnly
        ? [runGemini]
        : providerPref === 'gemini'
          ? [runGemini, runOpenLlm]
          : [runOpenLlm, runGemini];

      let lastErr: unknown;
      for (const runner of runners) {
        try {
          result = await runner();
          break;
        } catch (err) {
          lastErr = err;
          console.warn('[ai-coach] engine attempt failed, failing over:', err instanceof Error ? err.message : err);
        }
      }

      if (!result) {
        console.error('[ai-coach] all engines failed:', lastErr instanceof Error ? lastErr.message : lastErr);
        res.status(503).json({
          error: 'المدرب الذكي مشغول مؤقتاً، اضغط «إرسال» للمحاولة مجدداً أو بدّل النموذج بالأعلى.',
        });
        return;
      }

      const parsed = result.data;
      res.json({
        userTranscript: (parsed.userTranscript || userText || '').trim(),
        replyEn: (parsed.replyEn || '').trim(),
        replyAr: (parsed.replyAr || '').trim(),
        hasErrors: Boolean(parsed.hasErrors),
        correctedEn: (parsed.correctedEn || parsed.userTranscript || userText || '').trim(),
        explanationAr: (parsed.explanationAr || '').trim(),
        betterPhrasing: (parsed.betterPhrasing || '').trim(),
        score: Math.max(0, Math.min(100, Math.round(Number(parsed.score) || 85))),
        suggestions: Array.isArray(parsed.suggestions)
          ? parsed.suggestions
              .filter((s): s is string => typeof s === 'string' && s.trim().length > 0)
              .slice(0, 3)
          : [],
        providerLabel: result.label,
      });
    } catch (err) {
      console.error('[ai-coach] error:', err instanceof Error ? err.message : err);
      res.status(500).json({ error: 'حدث خطأ أثناء التواصل مع المدرب الذكي. حاول مرة أخرى.' });
    }
  });

  // 4) Check learner-built sentence using a specific target vocabulary word (voice or text)
  app.post('/api/check-word-sentence', rateLimitApi, async (req: Request, res: Response) => {
    try {
      const body = req.body as {
        targetWord?: unknown;
        targetMeaningAr?: unknown;
        sentence?: unknown;
        audioBase64?: unknown;
        audioMimeType?: unknown;
      };

      const targetWord =
        typeof body?.targetWord === 'string' ? body.targetWord.trim().slice(0, 80) : '';
      const targetMeaningAr =
        typeof body?.targetMeaningAr === 'string' ? body.targetMeaningAr.trim().slice(0, 120) : '';
      const sentence =
        typeof body?.sentence === 'string' ? body.sentence.trim().slice(0, 400) : '';
      const audioBase64 = validateBase64Audio(body?.audioBase64);
      const audioMimeType = normalizeAudioMime(body?.audioMimeType);

      if (!targetWord) {
        res.status(400).json({ error: 'الكلمة المستهدفة مطلوبة.' });
        return;
      }
      if (!sentence && (!audioBase64 || !audioMimeType)) {
        res.status(400).json({ error: 'يرجى كتابة جملة أو تسجيلها بصوتك.' });
        return;
      }

      const systemInstruction = `You are a precise, encouraging English grammar teacher for Arabic speakers.
The learner MUST build a correct English sentence containing the target word "${targetWord}"${targetMeaningAr ? ` (Arabic meaning: ${targetMeaningAr})` : ''} (or a valid grammatical inflection of it).
Analyze the learner's sentence carefully and return ONLY valid JSON with:
- "userSentence": exact English sentence written or spoken by the learner (keep original mistakes intact).
- "containsTargetWord": boolean (true if the learner actually used "${targetWord}" or a valid inflection of it in the sentence).
- "isCorrect": boolean (true ONLY if containsTargetWord is true AND grammar, spelling, word order, and usage of "${targetWord}" are correct).
- "score": integer 0-100.
- "correctedEn": the full corrected natural English sentence still using "${targetWord}".
- "wrongParts": array of the exact wrong words or short substrings from userSentence that should be underlined in red (empty array if no errors).
- "explanationAr": clear, friendly Arabic explanation of every mistake found (or praise if completely correct).
- "betterExampleEn": one extra natural example sentence using "${targetWord}".`;

      const promptText =
        audioBase64 && audioMimeType
          ? `Listen to the learner's spoken English sentence.${sentence ? ` (Browser transcript hint: "${sentence}")` : ''} Target word required: "${targetWord}". Transcribe faithfully and return the JSON evaluation.`
          : `Learner's sentence: "${sentence}"\nTarget word required: "${targetWord}". Evaluate and return JSON.`;

      const schema = {
        type: Type.OBJECT,
        properties: {
          userSentence: { type: Type.STRING },
          containsTargetWord: { type: Type.BOOLEAN },
          isCorrect: { type: Type.BOOLEAN },
          score: { type: Type.NUMBER },
          correctedEn: { type: Type.STRING },
          wrongParts: { type: Type.ARRAY, items: { type: Type.STRING } },
          explanationAr: { type: Type.STRING },
          betterExampleEn: { type: Type.STRING },
        },
        required: [
          'userSentence',
          'containsTargetWord',
          'isCorrect',
          'score',
          'correctedEn',
          'wrongParts',
          'explanationAr',
          'betterExampleEn',
        ],
      };

      type CheckResp = {
        userSentence?: string;
        containsTargetWord?: boolean;
        isCorrect?: boolean;
        score?: number;
        correctedEn?: string;
        wrongParts?: string[];
        explanationAr?: string;
        betterExampleEn?: string;
      };

      let parsed: CheckResp | null = null;
      const audioOnly = Boolean(audioBase64 && audioMimeType && !sentence);

      try {
        const contentsPayload =
          audioBase64 && audioMimeType
            ? {
                parts: [
                  { inlineData: { mimeType: audioMimeType, data: audioBase64 } },
                  { text: promptText },
                ],
              }
            : promptText;

        const resGemini = await callGeminiStructured<CheckResp>({
          contents: contentsPayload,
          systemInstruction,
          responseSchema: schema,
          timeoutMs: 22_000,
          preferLite: !audioOnly,
        });
        parsed = resGemini.data;
      } catch (err) {
        console.warn('[check-word-sentence] Gemini fallback:', err instanceof Error ? err.message : err);
      }

      if (!parsed && sentence) {
        parsed = await callOpenLlmJson<CheckResp>(systemInstruction, promptText, 14_000);
      }

      if (!parsed) {
        res.status(503).json({ error: 'تعذر فحص الجملة حالياً. حاول مرة أخرى.' });
        return;
      }

      res.json({
        userSentence: (parsed.userSentence || sentence || '').trim(),
        containsTargetWord: Boolean(parsed.containsTargetWord),
        isCorrect: Boolean(parsed.isCorrect),
        score: Math.max(0, Math.min(100, Math.round(Number(parsed.score) || 0))),
        correctedEn: (parsed.correctedEn || parsed.userSentence || sentence || '').trim(),
        wrongParts: Array.isArray(parsed.wrongParts)
          ? parsed.wrongParts.filter((s): s is string => typeof s === 'string' && s.trim().length > 0)
          : [],
        explanationAr: (parsed.explanationAr || '').trim(),
        betterExampleEn: (parsed.betterExampleEn || '').trim(),
      });
    } catch (err) {
      console.error('[check-word-sentence] error:', err instanceof Error ? err.message : err);
      res.status(500).json({ error: 'حدث خطأ أثناء تصحيح الجملة. حاول مرة أخرى.' });
    }
  });

  app.post('/api/evaluate-sentence-swap', rateLimitApi, async (req: Request, res: Response) => {
    try {
      const body = req.body as {
        originalSentence?: unknown;
        targetSlotType?: unknown;
        targetSlotText?: unknown;
        userSentence?: unknown;
        audioBase64?: unknown;
        audioMimeType?: unknown;
      };

      const originalSentence =
        typeof body?.originalSentence === 'string' ? body.originalSentence.trim().slice(0, 300) : '';
      const rawSlotType = typeof body?.targetSlotType === 'string' ? body.targetSlotType.trim() : 'free';
      const targetSlotType = ['subject', 'verb', 'object', 'preposition', 'free'].includes(rawSlotType)
        ? rawSlotType
        : 'free';
      const targetSlotText =
        typeof body?.targetSlotText === 'string' ? body.targetSlotText.trim().slice(0, 120) : '';
      const userSentence =
        typeof body?.userSentence === 'string' ? body.userSentence.trim().slice(0, 350) : '';
      const audioBase64 = validateBase64Audio(body?.audioBase64);
      const audioMimeType = normalizeAudioMime(body?.audioMimeType);

      if (!originalSentence) {
        res.status(400).json({ error: 'الجملة النموذجية مطلوبة.' });
        return;
      }
      if (!userSentence && (!audioBase64 || !audioMimeType)) {
        res.status(400).json({ error: 'يرجى نطق الجملة الجديدة أو كتابتها.' });
        return;
      }

      const systemInstruction = `You are a friendly, precise English speaking & grammar coach for Arabic speakers running a Pattern Substitution Drill.
The learner was given a model English sentence and asked to produce a NEW English sentence keeping the same grammatical pattern while swapping ONLY the requested slot (${targetSlotType}: "${targetSlotText}").
Evaluate the learner's response faithfully and return ONLY valid JSON:
- "heardText": exact English sentence spoken or typed by the learner (keep original mistakes intact).
- "swappedCorrectly": boolean (true if the learner kept the core pattern AND genuinely replaced "${targetSlotText}" with a different fitting word/phrase — false if they merely repeated the exact original sentence or completely abandoned the pattern).
- "isGrammaticallyCorrect": boolean (checks tense, subject-verb agreement like "He goes" vs "He go", prepositions, and articles).
- "score": integer 0-100.
- "correctedEn": natural, grammatically perfect English version of the learner's new sentence.
- "newSentenceAr": natural, accurate Arabic translation of correctedEn.
- "feedbackAr": warm, encouraging Arabic explanation praising what worked and gently explaining any mistake.
- "wrongParts": array of { "wrong": string, "right": string, "reasonAr": string } for any grammar slip (empty array if no errors).`;

      const promptText =
        audioBase64 && audioMimeType
          ? `Model sentence: "${originalSentence}"\nRequested swap slot (${targetSlotType}): "${targetSlotText}"\nListen to the learner's spoken English sentence.${userSentence ? ` (Browser transcript hint: "${userSentence}")` : ''} Transcribe faithfully and return the JSON evaluation.`
          : `Model sentence: "${originalSentence}"\nRequested swap slot (${targetSlotType}): "${targetSlotText}"\nLearner's new sentence: "${userSentence}"\nEvaluate and return JSON.`;

      const schema = {
        type: Type.OBJECT,
        properties: {
          heardText: { type: Type.STRING },
          swappedCorrectly: { type: Type.BOOLEAN },
          isGrammaticallyCorrect: { type: Type.BOOLEAN },
          score: { type: Type.NUMBER },
          correctedEn: { type: Type.STRING },
          newSentenceAr: { type: Type.STRING },
          feedbackAr: { type: Type.STRING },
          wrongParts: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                wrong: { type: Type.STRING },
                right: { type: Type.STRING },
                reasonAr: { type: Type.STRING },
              },
              required: ['wrong', 'right', 'reasonAr'],
            },
          },
        },
        required: [
          'heardText',
          'swappedCorrectly',
          'isGrammaticallyCorrect',
          'score',
          'correctedEn',
          'newSentenceAr',
          'feedbackAr',
          'wrongParts',
        ],
      };

      type SwapResp = {
        heardText?: string;
        swappedCorrectly?: boolean;
        isGrammaticallyCorrect?: boolean;
        score?: number;
        correctedEn?: string;
        newSentenceAr?: string;
        feedbackAr?: string;
        wrongParts?: Array<{ wrong?: string; right?: string; reasonAr?: string }>;
      };

      let parsed: SwapResp | null = null;
      const audioOnly = Boolean(audioBase64 && audioMimeType && !userSentence);

      try {
        const contentsPayload =
          audioBase64 && audioMimeType
            ? {
                parts: [
                  { inlineData: { mimeType: audioMimeType, data: audioBase64 } },
                  { text: promptText },
                ],
              }
            : promptText;

        const resGemini = await callGeminiStructured<SwapResp>({
          contents: contentsPayload,
          systemInstruction,
          responseSchema: schema,
          timeoutMs: 7_000,
          preferLite: !audioOnly,
        });
        parsed = resGemini.data;
      } catch (err) {
        console.warn('[evaluate-sentence-swap] Gemini fallback:', err instanceof Error ? err.message : err);
      }

      if (!parsed && userSentence) {
        try {
          parsed = await callOpenLlmJson<SwapResp>(systemInstruction, promptText, 6_500);
        } catch {
          parsed = null;
        }
      }

      if (!parsed) {
        res.status(503).json({ error: 'تعذر التقييم عبر الذكاء الاصطناعي حالياً.' });
        return;
      }

      const cleanWrongParts = Array.isArray(parsed.wrongParts)
        ? parsed.wrongParts
            .filter(
              (item): item is { wrong: string; right: string; reasonAr: string } =>
                Boolean(item && typeof item.wrong === 'string' && typeof item.right === 'string')
            )
            .map((item) => ({
              wrong: item.wrong.trim(),
              right: item.right.trim(),
              reasonAr: typeof item.reasonAr === 'string' ? item.reasonAr.trim() : '',
            }))
        : [];

      res.json({
        heardText: (parsed.heardText || userSentence || '').trim(),
        swappedCorrectly: Boolean(parsed.swappedCorrectly),
        isGrammaticallyCorrect: Boolean(parsed.isGrammaticallyCorrect),
        score: Math.max(0, Math.min(100, Math.round(Number(parsed.score) || 0))),
        correctedEn: (parsed.correctedEn || parsed.heardText || userSentence || '').trim(),
        newSentenceAr: (parsed.newSentenceAr || '').trim(),
        feedbackAr: (parsed.feedbackAr || '').trim(),
        wrongParts: cleanWrongParts,
      });
    } catch (err) {
      console.error('[evaluate-sentence-swap] error:', err instanceof Error ? err.message : err);
      res.status(500).json({ error: 'حدث خطأ أثناء تقييم الجملة.' });
    }
  });

  // 5) Evaluate multi-sentence AI Coach tasks: Picture Description, Topic Writing, Article Summary
  app.post('/api/evaluate-writing-task', rateLimitApi, async (req: Request, res: Response) => {
    try {
      const body = req.body as {
        taskType?: unknown;
        level?: unknown;
        contextTitle?: unknown;
        contextText?: unknown;
        userText?: unknown;
        audioBase64?: unknown;
        audioMimeType?: unknown;
      };

      const taskType =
        body?.taskType === 'picture' ||
        body?.taskType === 'topic' ||
        body?.taskType === 'article_summary'
          ? body.taskType
          : 'topic';
      const level =
        typeof body?.level === 'string' && ALLOWED_LEVELS.has(body.level) ? body.level : 'B1';
      const contextTitle =
        typeof body?.contextTitle === 'string' ? body.contextTitle.trim().slice(0, 200) : '';
      const contextText =
        typeof body?.contextText === 'string' ? body.contextText.trim().slice(0, 3500) : '';
      const userText =
        typeof body?.userText === 'string' ? body.userText.trim().slice(0, 2000) : '';
      const audioBase64 = validateBase64Audio(body?.audioBase64);
      const audioMimeType = normalizeAudioMime(body?.audioMimeType);

      if (!userText && (!audioBase64 || !audioMimeType)) {
        res.status(400).json({ error: 'يرجى كتابة جملك أو تسجيل صوتك أولاً.' });
        return;
      }

      const taskInstructions: Record<'picture' | 'topic' | 'article_summary', string> = {
        picture: `Task: Picture Description. The learner looked at a photo titled "${contextTitle}" (${contextText}) and spoke or wrote several English sentences describing what they see.`,
        topic: `Task: Topic Writing. The learner wrote several English sentences about the topic "${contextTitle}": ${contextText}`,
        article_summary: `Task: Reading Article Summary. The learner just read an English article titled "${contextTitle}". Original article excerpt:\n${contextText}\nThe learner then summarized the article in their own English words (by voice or writing). Evaluate BOTH English grammar/phrasing AND how accurately they summarized the main ideas of the article.`,
      };

      const systemInstruction = `You are a warm, thorough English writing & speaking coach for Arabic-speaking learners (CEFR level ${level}).
${taskInstructions[taskType]}

Evaluate EVERY sentence the learner produced and return ONLY valid JSON with these exact keys:
- "userText": exact English text written or spoken by the learner (preserve their original errors so they can learn).
- "hasErrors": boolean (true if there is any grammar, tense, spelling, punctuation, article, or phrasing issue).
- "score": integer 0-100.
- "overallFeedbackAr": encouraging Arabic summary of their performance (1-2 sentences).
- "contentFeedbackAr": concise Arabic note about how well they described the picture / covered the topic / captured the article's key points.
- "correctedText": the complete corrected version of the learner's text, preserving their ideas clearly.
- "wrongParts": array of the exact erroneous words or short phrases from userText to underline in red.
- "sentenceFeedback": array of objects (one per sentence the learner wrote/spoke), each with:
  - "original": the learner's original sentence
  - "corrected": the corrected sentence
  - "hasError": boolean
  - "explanationAr": clear Arabic explanation of what was fixed (or short praise if correct)
- "improvedVersionEn": a polished, natural native-level version of their paragraph/summary suitable for CEFR ${level}.
- "vocabularyTips": array of 3 useful English words/expressions with Arabic meanings formatted like "word — معنى" related to this task.`;

      const promptText =
        audioBase64 && audioMimeType
          ? `Listen carefully to the learner's English audio recording.${userText ? ` (Browser transcript hint: "${userText}")` : ''} Transcribe faithfully and evaluate every sentence as JSON.`
          : `Learner's response:\n"${userText}"\n\nEvaluate every sentence thoroughly and return JSON.`;

      const evalSchema = {
        type: Type.OBJECT,
        properties: {
          userText: { type: Type.STRING },
          hasErrors: { type: Type.BOOLEAN },
          score: { type: Type.NUMBER },
          overallFeedbackAr: { type: Type.STRING },
          contentFeedbackAr: { type: Type.STRING },
          correctedText: { type: Type.STRING },
          wrongParts: { type: Type.ARRAY, items: { type: Type.STRING } },
          sentenceFeedback: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                original: { type: Type.STRING },
                corrected: { type: Type.STRING },
                hasError: { type: Type.BOOLEAN },
                explanationAr: { type: Type.STRING },
              },
              required: ['original', 'corrected', 'hasError', 'explanationAr'],
            },
          },
          improvedVersionEn: { type: Type.STRING },
          vocabularyTips: { type: Type.ARRAY, items: { type: Type.STRING } },
        },
        required: [
          'userText',
          'hasErrors',
          'score',
          'overallFeedbackAr',
          'contentFeedbackAr',
          'correctedText',
          'wrongParts',
          'sentenceFeedback',
          'improvedVersionEn',
          'vocabularyTips',
        ],
      };

      type EvalResp = {
        userText?: string;
        hasErrors?: boolean;
        score?: number;
        overallFeedbackAr?: string;
        contentFeedbackAr?: string;
        correctedText?: string;
        wrongParts?: string[];
        sentenceFeedback?: Array<{
          original?: string;
          corrected?: string;
          hasError?: boolean;
          explanationAr?: string;
        }>;
        improvedVersionEn?: string;
        vocabularyTips?: string[];
      };

      let result: { data: EvalResp; label: string } | null = null;
      const audioOnly = Boolean(audioBase64 && audioMimeType && !userText);

      try {
        const contentsPayload =
          audioBase64 && audioMimeType
            ? {
                parts: [
                  { inlineData: { mimeType: audioMimeType, data: audioBase64 } },
                  { text: promptText },
                ],
              }
            : promptText;

        const resGemini = await callGeminiStructured<EvalResp>({
          contents: contentsPayload,
          systemInstruction,
          responseSchema: evalSchema,
          timeoutMs: 32_000,
          preferLite: !audioOnly,
        });
        result = { data: resGemini.data, label: 'Gemini' };
      } catch (err) {
        console.warn('[evaluate-writing-task] Gemini fallback:', err instanceof Error ? err.message : err);
      }

      if (!result && userText) {
        const openData = await callOpenLlmJson<EvalResp>(systemInstruction, promptText, 18_000);
        result = { data: openData, label: 'GPT-OSS المجاني' };
      }

      if (!result) {
        res.status(503).json({ error: 'تعذر تصحيح إجابتك حالياً. حاول مرة أخرى.' });
        return;
      }

      const d = result.data;
      res.json({
        userText: (d.userText || userText || '').trim(),
        hasErrors: Boolean(d.hasErrors),
        score: Math.max(0, Math.min(100, Math.round(Number(d.score) || 80))),
        overallFeedbackAr: (d.overallFeedbackAr || 'أحسنت! استمر في التدريب.').trim(),
        contentFeedbackAr: (d.contentFeedbackAr || '').trim(),
        correctedText: (d.correctedText || d.userText || userText || '').trim(),
        wrongParts: Array.isArray(d.wrongParts)
          ? d.wrongParts.filter((s): s is string => typeof s === 'string' && s.trim().length > 0)
          : [],
        sentenceFeedback: Array.isArray(d.sentenceFeedback)
          ? d.sentenceFeedback
              .filter((x) => x && typeof x.original === 'string')
              .map((x) => ({
                original: (x.original || '').trim(),
                corrected: (x.corrected || x.original || '').trim(),
                hasError: Boolean(x.hasError),
                explanationAr: (x.explanationAr || '').trim(),
              }))
          : [],
        improvedVersionEn: (d.improvedVersionEn || '').trim(),
        vocabularyTips: Array.isArray(d.vocabularyTips)
          ? d.vocabularyTips.filter((s): s is string => typeof s === 'string' && s.trim().length > 0).slice(0, 4)
          : [],
        providerLabel: result.label,
      });
    } catch (err) {
      console.error('[evaluate-writing-task] error:', err instanceof Error ? err.message : err);
      res.status(500).json({ error: 'حدث خطأ أثناء تقييم الإجابة. حاول مرة أخرى.' });
    }
  });

  // 6) Generate a fresh English writing topic prompt via AI
  app.post('/api/generate-topic-prompt', rateLimitApi, async (req: Request, res: Response) => {
    try {
      const body = req.body as { level?: unknown; previousTitles?: unknown };
      const level =
        typeof body?.level === 'string' && ALLOWED_LEVELS.has(body.level) ? body.level : 'B1';
      const prev = Array.isArray(body?.previousTitles)
        ? body.previousTitles.filter((x): x is string => typeof x === 'string').slice(-8)
        : [];

      const prompt = `Create ONE fresh, engaging English writing topic idea for an Arabic-speaking learner at CEFR level ${level}.
${prev.length ? `Avoid these previous titles: ${prev.join(', ')}.` : ''}
Return ONLY JSON with:
- "titleEn": short catchy English topic title
- "titleAr": accurate Arabic translation of the title
- "promptEn": 1-2 clear English sentences explaining what to write (3-5 sentences)
- "promptAr": clear Arabic instruction telling the learner what to write about
- "keywords": array of 5 helpful English words appropriate for CEFR ${level}`;

      const schema = {
        type: Type.OBJECT,
        properties: {
          titleEn: { type: Type.STRING },
          titleAr: { type: Type.STRING },
          promptEn: { type: Type.STRING },
          promptAr: { type: Type.STRING },
          keywords: { type: Type.ARRAY, items: { type: Type.STRING } },
        },
        required: ['titleEn', 'titleAr', 'promptEn', 'promptAr', 'keywords'],
      };

      type TopicResp = {
        titleEn?: string;
        titleAr?: string;
        promptEn?: string;
        promptAr?: string;
        keywords?: string[];
      };

      let data: TopicResp | null = null;
      try {
        const resG = await callGeminiStructured<TopicResp>({
          contents: prompt,
          responseSchema: schema,
          timeoutMs: 16_000,
          preferLite: true,
        });
        data = resG.data;
      } catch {
        data = await callOpenLlmJson<TopicResp>(
          'You create engaging English writing prompts for Arabic learners. Return ONLY valid JSON.',
          prompt,
          12_000
        );
      }

      if (!data?.titleEn) {
        res.status(503).json({ error: 'تعذر توليد فكرة موضوع جديدة حالياً.' });
        return;
      }

      res.json({
        id: `topic-ai-${Date.now()}`,
        titleEn: data.titleEn.trim(),
        titleAr: (data.titleAr || data.titleEn).trim(),
        promptEn: (data.promptEn || '').trim(),
        promptAr: (data.promptAr || '').trim(),
        keywords: Array.isArray(data.keywords) ? data.keywords.slice(0, 6) : [],
        level,
      });
    } catch (err) {
      console.error('[generate-topic-prompt] error:', err instanceof Error ? err.message : err);
      res.status(500).json({ error: 'تعذر توليد موضوع جديد حالياً.' });
    }
  });

  // 7) Search & generate readable English articles / short stories / texts on any topic
  app.post('/api/articles/search', rateLimitApi, async (req: Request, res: Response) => {
    try {
      const body = req.body as {
        query?: unknown;
        level?: unknown;
        contentType?: unknown;
      };
      const query =
        typeof body?.query === 'string' ? body.query.trim().slice(0, 140) : '';
      const level =
        typeof body?.level === 'string' && ALLOWED_LEVELS.has(body.level) ? body.level : 'B1';
      const contentType =
        body?.contentType === 'article' ||
        body?.contentType === 'story' ||
        body?.contentType === 'essay'
          ? body.contentType
          : 'all';

      if (!query) {
        res.status(400).json({ error: 'يرجى كتابة موضوع للبحث عنه.' });
        return;
      }

      const typeInstruction =
        contentType === 'story'
          ? 'All 3 items should be engaging short stories / narrative fiction.'
          : contentType === 'article'
            ? 'All 3 items should be informative, enjoyable articles.'
            : contentType === 'essay'
              ? 'All 3 items should be interesting cultural/educational reading passages.'
              : 'Include a rich variety: 1 informative article, 1 engaging short story, and 1 interesting reading passage/essay.';

      const prompt = `Create 3 engaging, well-written English reading pieces about the topic: "${query}" (the query may be in Arabic or English; always write the reading content in clear natural English matching CEFR level ${level}).
${typeInstruction}
Each piece must have 4 crisp, engaging paragraphs (around 150-220 words total per piece) with natural vocabulary for CEFR ${level}.
Return ONLY valid JSON: {"articles": [ { "title", "titleAr", "typeLabel" (in Arabic, e.g. "مقالة", "قصة قصيرة", "نص قرائي"), "readingMinutes" (2-4), "summaryHintAr" (1-sentence Arabic teaser), "paragraphs": [4 strings in English] } ] }.`;

      const schema = {
        type: Type.OBJECT,
        properties: {
          articles: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                title: { type: Type.STRING },
                titleAr: { type: Type.STRING },
                typeLabel: { type: Type.STRING },
                readingMinutes: { type: Type.NUMBER },
                summaryHintAr: { type: Type.STRING },
                paragraphs: { type: Type.ARRAY, items: { type: Type.STRING } },
              },
              required: ['title', 'titleAr', 'typeLabel', 'readingMinutes', 'summaryHintAr', 'paragraphs'],
            },
          },
        },
        required: ['articles'],
      };

      type ArticlesResp = {
        articles?: Array<{
          title?: string;
          titleAr?: string;
          typeLabel?: string;
          readingMinutes?: number;
          summaryHintAr?: string;
          paragraphs?: string[];
        }>;
      };

      let data: ArticlesResp | null = null;
      try {
        const resG = await callGeminiStructured<ArticlesResp>({
          contents: prompt,
          responseSchema: schema,
          timeoutMs: 28_000,
          preferLite: true,
        });
        data = resG.data;
      } catch (err) {
        console.warn('[articles/search] Gemini fallback:', err instanceof Error ? err.message : err);
        data = await callOpenLlmJson<ArticlesResp>(
          'You are an expert English reading editor creating engaging CEFR-leveled articles and short stories. Return ONLY valid JSON.',
          prompt,
          20_000
        );
      }

      const list = Array.isArray(data?.articles)
        ? data.articles
            .filter((a) => a && typeof a.title === 'string' && Array.isArray(a.paragraphs) && a.paragraphs.length > 0)
            .slice(0, 3)
            .map((a, idx) => ({
              id: `art-gen-${Date.now()}-${idx}`,
              title: (a.title || '').trim(),
              titleAr: (a.titleAr || a.title || '').trim(),
              topicId: 'search',
              typeLabel: (a.typeLabel || 'مقالة').trim(),
              level,
              readingMinutes: Math.max(1, Math.min(8, Math.round(Number(a.readingMinutes) || 3))),
              summaryHintAr: (a.summaryHintAr || '').trim(),
              paragraphs: (a.paragraphs || [])
                .filter((p): p is string => typeof p === 'string' && p.trim().length > 0)
                .map((p) => p.trim()),
            }))
        : [];

      if (list.length === 0) {
        res.status(503).json({ error: 'تعذر جلب نصوص لهذا الموضوع حالياً. حاول مرة أخرى.' });
        return;
      }

      res.json({ articles: list });
    } catch (err) {
      console.error('[articles/search] error:', err instanceof Error ? err.message : err);
      res.status(500).json({ error: 'حدث خطأ أثناء البحث عن المقالات. حاول مرة أخرى.' });
    }
  });

  // 8) Fast single-word translation for clickable words inside reading articles (6s timeout + GTX fallback)
  app.post('/api/translate-word', rateLimitApi, async (req: Request, res: Response) => {
    try {
      const body = req.body as { word?: unknown; contextSentence?: unknown; targetLang?: unknown };
      const word = typeof body?.word === 'string' ? body.word.trim().slice(0, 60) : '';
      const contextSentence =
        typeof body?.contextSentence === 'string' ? body.contextSentence.trim().slice(0, 260) : '';
      const rawLang = typeof body?.targetLang === 'string' ? body.targetLang.trim().toLowerCase() : 'ar';
      const targetLang = SERVER_GTX_TL[rawLang] ? rawLang : 'ar';
      const targetLangName = SERVER_LANG_NAMES[targetLang] || 'Arabic';

      if (!word) {
        res.status(400).json({ error: 'الكلمة مطلوبة.' });
        return;
      }

      const cacheKey = `word::${targetLang}::${word.toLowerCase()}::${contextSentence.slice(0, 80).toLowerCase()}`;
      const cached = translationCache.get(cacheKey);
      if (cached) {
        const [ar, posAr] = cached.split('|||');
        res.json({ word, ar, posAr: posAr || '' });
        return;
      }

      const prompt = `Translate the English word "${word}" into concise, natural ${targetLangName}${contextSentence ? ` as used in this sentence: "${contextSentence}"` : ''}.
Return ONLY JSON: {"ar": "concise translation (1-4 words) in ${targetLangName}", "posAr": "part of speech in ${targetLangName}"}`;

      const schema = {
        type: Type.OBJECT,
        properties: {
          ar: { type: Type.STRING },
          posAr: { type: Type.STRING },
        },
        required: ['ar', 'posAr'],
      };

      let parsed: { ar?: string; posAr?: string } | null = null;
      if (getAiClient()) {
        try {
          const resG = await callGeminiStructured<{ ar?: string; posAr?: string }>({
            contents: prompt,
            responseSchema: schema,
            timeoutMs: 5_000,
            preferLite: true,
          });
          parsed = resG.data;
        } catch {
          // Fall through to fast GTX
        }
      }

      let ar = (parsed?.ar || '').trim();
      const posAr = (parsed?.posAr || '').trim();
      if (!ar) {
        const gtx = await serverGtxTranslateBatch([word], 'en', targetLang);
        ar = (gtx[word] || '').trim();
      }
      if (!ar) {
        res.status(503).json({ error: 'تعذر ترجمة الكلمة حالياً.' });
        return;
      }
      setCachedTranslation(cacheKey, `${ar}|||${posAr}`);
      res.json({ word, ar, posAr });
    } catch (err) {
      console.error('[translate-word] error:', err instanceof Error ? err.message : err);
      res.status(500).json({ error: 'تعذر ترجمة الكلمة حالياً.' });
    }
  });

  // 9) Real spoken English video clips (±3s around exact spoken word) with 50+ clips & caching
  const WORD_CLIPS_CACHE_MAX = 500;
  const WORD_CLIPS_TTL_MS = 12 * 60 * 60 * 1000;
  const wordClipsCache = new Map<string, { data: WordClipsPageResponse; expiresAt: number }>();
  const wordClipsInflight = new Map<string, Promise<WordClipsPageResponse>>();

  function getCachedWordClips(key: string): WordClipsPageResponse | null {
    const hit = wordClipsCache.get(key);
    if (!hit) return null;
    if (Date.now() > hit.expiresAt) {
      wordClipsCache.delete(key);
      return null;
    }
    return hit.data;
  }

  function setCachedWordClips(key: string, data: WordClipsPageResponse): void {
    if (wordClipsCache.size >= WORD_CLIPS_CACHE_MAX) {
      const oldest = wordClipsCache.keys().next().value;
      if (oldest !== undefined) wordClipsCache.delete(oldest);
    }
    wordClipsCache.set(key, { data, expiresAt: Date.now() + WORD_CLIPS_TTL_MS });
  }

  function deriveFallbackSearchTerm(rawWord: string): string | null {
    const clean = rawWord.trim().toLowerCase().replace(/^to\s+/, '');
    if (clean.includes(' ')) {
      const tokens = clean.split(/\s+/).filter((t) => t.length >= 3);
      if (tokens.length > 0) return tokens.sort((a, b) => b.length - a.length)[0];
    }
    if (clean.length >= 7) {
      const stripped = clean
        .replace(/(ingly|edly|ation|ition|ness|ment|able|ible|less|ful|ous|ive|ing|ies|ied|ed|ly|es|s)$/, '');
      if (stripped.length >= 4 && stripped !== clean) return stripped;
    }
    return null;
  }

  async function fetchJsonWithTimeout<T>(
    url: string,
    init: RequestInit,
    timeoutMs = 10_000
  ): Promise<T | null> {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    try {
      const res = await fetch(url, { ...init, signal: controller.signal });
      if (!res.ok) return null;
      return (await res.json()) as T;
    } catch {
      return null;
    } finally {
      clearTimeout(timer);
    }
  }

  async function fetchTextWithTimeout(
    url: string,
    init: RequestInit = {},
    timeoutMs = 6_500,
    maxBytes = 1_400_000
  ): Promise<string | null> {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    try {
      const res = await fetch(url, { ...init, signal: controller.signal });
      if (!res.ok) return null;
      const contentLen = Number.parseInt(res.headers.get('content-length') || '0', 10);
      if (Number.isFinite(contentLen) && contentLen > maxBytes) return null;
      const text = await res.text();
      return text.length > maxBytes ? text.slice(0, maxBytes) : text;
    } catch {
      return null;
    } finally {
      clearTimeout(timer);
    }
  }

  function withSoftTimeout<T>(promise: Promise<T>, timeoutMs: number, fallback: T): Promise<T> {
    return new Promise<T>((resolve) => {
      let settled = false;
      const timer = setTimeout(() => {
        if (!settled) {
          settled = true;
          resolve(fallback);
        }
      }, timeoutMs);
      promise
        .then((val) => {
          if (!settled) {
            settled = true;
            clearTimeout(timer);
            resolve(val);
          }
        })
        .catch(() => {
          if (!settled) {
            settled = true;
            clearTimeout(timer);
            resolve(fallback);
          }
        });
    });
  }

  // ───────────────────────────────────────────────────────────────────────────
  // Open Educational Direct-MP4 Video Sources (alongside TED Talks):
  // 1) Internet Archive (archive.org): Classic Public-Domain Movies & Lectures + SRT/VTT
  // 2) VOA Learning English (av.voanews.com): Public-Domain English Lessons + VTT/SRT
  // 3) Wikimedia Commons TimedText (commons.wikimedia.org): Open Lectures & Docs + SRT
  // ───────────────────────────────────────────────────────────────────────────
  const OPEN_VIDEO_UA = 'TMN-English-Learning/1.0 (https://tmn-brown.vercel.app)';

  interface ResolvedOpenVideoSource {
    meta: SourceVideoMeta;
    subtitleUrl: string;
    cues?: RawTranscriptCue[];
  }

  const archiveSourceCache = new Map<
    string,
    { data: ResolvedOpenVideoSource | null; expiresAt: number }
  >();
  const archivePopularPoolCache: { ids: string[]; expiresAt: number } = { ids: [], expiresAt: 0 };
  const voaSourceCache = new Map<
    string,
    { data: ResolvedOpenVideoSource | null; expiresAt: number }
  >();
  const voaFeedUrlsCache: { urls: string[]; expiresAt: number } = { urls: [], expiresAt: 0 };
  const OPEN_SOURCE_TTL_MS = 12 * 60 * 60 * 1000;

  function encodeArchiveFilePath(filename: string): string {
    return filename
      .split('/')
      .map((seg) => encodeURIComponent(seg))
      .join('/');
  }

  function parseArchiveDurationSec(rawLen: unknown): number {
    if (typeof rawLen === 'number' && Number.isFinite(rawLen) && rawLen > 5) {
      return Math.round(rawLen);
    }
    if (typeof rawLen !== 'string') return 1800;
    const trimmed = rawLen.trim();
    if (/^\d+(\.\d+)?$/.test(trimmed)) {
      const n = Number.parseFloat(trimmed);
      return Number.isFinite(n) && n > 5 ? Math.round(n) : 1800;
    }
    const parts = trimmed.split(':').map((p) => Number.parseFloat(p));
    if (parts.every((p) => Number.isFinite(p))) {
      if (parts.length === 3) return Math.round(parts[0] * 3600 + parts[1] * 60 + parts[2]);
      if (parts.length === 2) return Math.round(parts[0] * 60 + parts[1]);
    }
    return 1800;
  }

  function isLikelyEnglishSubtitleFilename(name: string): boolean {
    const lower = name.toLowerCase();
    if (!/\.(srt|vtt)$/.test(lower)) return false;
    if (lower.startsWith('._') || lower.includes('/._')) return false;
    // Reject explicitly non-English subtitle suffixes
    if (
      /[._-](ar|arabic|es|spa|spanish|fr|fre|french|de|ger|german|ru|rus|russian|zh|chi|chinese|pt|por|portuguese|it|ita|italian|ja|jpn|ko|kor|hi|hin|tr|tur|pl|pol|nl|dut|sv|swe|uk|ukr|vi|vie|th|tha)\.(srt|vtt)$/i.test(
        lower
      )
    ) {
      return false;
    }
    return true;
  }

  interface ArchiveSearchDoc {
    identifier?: string;
    title?: string;
    creator?: string | string[];
    collection?: string | string[];
  }

  interface ArchiveMetadataFile {
    name?: string;
    format?: string;
    size?: string | number;
    length?: string | number;
  }

  interface ArchiveMetadataResponse {
    metadata?: {
      identifier?: string;
      title?: string;
      creator?: string | string[];
      collection?: string | string[];
    };
    files?: ArchiveMetadataFile[];
  }

  async function searchArchiveIdentifiers(
    luceneQuery: string,
    rows = 10,
    page = 1,
    sort = 'downloads desc'
  ): Promise<string[]> {
    const url =
      `https://archive.org/advancedsearch.php?q=${encodeURIComponent(luceneQuery)}` +
      `&fl[]=identifier&sort[]=${encodeURIComponent(sort)}` +
      `&rows=${rows}&page=${page}&output=json`;
    const data = await fetchJsonWithTimeout<{ response?: { docs?: ArchiveSearchDoc[] } }>(
      url,
      { headers: { 'User-Agent': OPEN_VIDEO_UA } },
      4_500
    );
    const ids: string[] = [];
    const seen = new Set<string>();
    for (const doc of data?.response?.docs || []) {
      const id = typeof doc.identifier === 'string' ? doc.identifier.trim() : '';
      if (id && /^[a-zA-Z0-9._-]+$/.test(id) && !seen.has(id)) {
        seen.add(id);
        ids.push(id);
      }
    }
    return ids;
  }

  async function getPopularCaptionedArchiveIds(): Promise<string[]> {
    if (archivePopularPoolCache.ids.length > 0 && Date.now() < archivePopularPoolCache.expiresAt) {
      return archivePopularPoolCache.ids;
    }
    const [movieIds, lectureIds] = await Promise.all([
      searchArchiveIdentifiers(
        'mediatype:movies AND format:"MPEG4" AND (format:"SubRip" OR format:"Web Video Text Tracks") AND collection:(feature_films OR classic_tv OR sci_fi_horror OR film_noir) AND language:(eng OR English)',
        14,
        1
      ),
      searchArchiveIdentifiers(
        'mediatype:movies AND format:"MPEG4" AND (format:"SubRip" OR format:"Web Video Text Tracks") AND collection:(opensource_movies OR academic_conferences OR educationalfilms OR mit_ocw OR prelinger)',
        10,
        1
      ),
    ]);
    const combined = Array.from(new Set([...movieIds, ...lectureIds])).slice(0, 20);
    if (combined.length > 0) {
      archivePopularPoolCache.ids = combined;
      archivePopularPoolCache.expiresAt = Date.now() + OPEN_SOURCE_TTL_MS;
    }
    return combined;
  }

  async function resolveArchiveVideoSource(
    identifier: string
  ): Promise<ResolvedOpenVideoSource | null> {
    const cached = archiveSourceCache.get(identifier);
    if (cached && Date.now() < cached.expiresAt) {
      return cached.data;
    }

    const metaRes = await fetchJsonWithTimeout<ArchiveMetadataResponse>(
      `https://archive.org/metadata/${encodeURIComponent(identifier)}`,
      { headers: { 'User-Agent': OPEN_VIDEO_UA } },
      4_500
    );
    const files = metaRes?.files || [];
    if (!files.length) {
      archiveSourceCache.set(identifier, { data: null, expiresAt: Date.now() + 60 * 60 * 1000 });
      return null;
    }

    // Pick web-playable MP4 (prefer h.264 / MPEG4 with reasonable size for instant byte-range seeking)
    const mp4Candidates = files
      .filter((f) => {
        const name = (f.name || '').toLowerCase();
        if (!name.endsWith('.mp4') || name.startsWith('._') || name.includes('/._')) return false;
        const size = Number(f.size || 0);
        if (Number.isFinite(size) && size > 0 && (size < 250_000 || size > 900_000_000)) return false;
        return true;
      })
      .sort((a, b) => {
        const score = (f: ArchiveMetadataFile) => {
          const fmt = (f.format || '').toLowerCase();
          const name = (f.name || '').toLowerCase();
          const size = Number(f.size || 0);
          let s = 0;
          if (fmt.includes('h.264') || fmt.includes('mpeg4')) s += 40;
          if (name.includes('512kb') || name.includes('360p') || name.includes('480p')) s += 30;
          if (size > 0 && size <= 180_000_000) s += 20;
          if (size > 350_000_000) s -= 20;
          return s;
        };
        return score(b) - score(a);
      });

    const subCandidates = files
      .filter((f) => typeof f.name === 'string' && isLikelyEnglishSubtitleFilename(f.name))
      .sort((a, b) => {
        const score = (f: ArchiveMetadataFile) => {
          const n = (f.name || '').toLowerCase();
          let s = 0;
          if (/[._-](en|eng|english)\.(srt|vtt)$/.test(n)) s += 50;
          if (n.endsWith('.vtt')) s += 10;
          if (n.endsWith('.srt')) s += 15;
          return s;
        };
        return score(b) - score(a);
      });

    const chosenMp4 = mp4Candidates[0];
    const chosenSub = subCandidates[0];
    if (!chosenMp4?.name || !chosenSub?.name) {
      archiveSourceCache.set(identifier, { data: null, expiresAt: Date.now() + 2 * 60 * 60 * 1000 });
      return null;
    }

    const md = metaRes?.metadata || {};
    const collections = Array.isArray(md.collection)
      ? md.collection.map((c) => c.toLowerCase())
      : typeof md.collection === 'string'
        ? [md.collection.toLowerCase()]
        : [];
    const isCinema = collections.some((c) =>
      /(feature_films|classic_tv|sci_fi_horror|film_noir|moviesandfilms|silent_films|comedy_films|drama)/.test(
        c
      )
    );

    const creatorRaw = Array.isArray(md.creator) ? md.creator[0] : md.creator;
    const speaker = (creatorRaw || (isCinema ? 'Classic Cinema' : 'Open Lecture'))
      .toString()
      .replace(/<[^>]+>/g, '')
      .trim()
      .slice(0, 80);
    const title = (md.title || identifier)
      .toString()
      .replace(/<[^>]+>/g, '')
      .trim()
      .slice(0, 120);

    const resolved: ResolvedOpenVideoSource = {
      meta: {
        videoId: `ia_${identifier.replace(/[^a-zA-Z0-9_-]/g, '_').slice(0, 40)}`,
        slug: identifier,
        title,
        speaker,
        sourceLabel: isCinema ? 'Archive.org · Classic Cinema' : 'Archive.org · Open Lectures',
        videoUrl: `https://archive.org/download/${encodeURIComponent(identifier)}/${encodeArchiveFilePath(chosenMp4.name)}`,
        posterUrl: `https://archive.org/services/img/${encodeURIComponent(identifier)}`,
        durationSec: parseArchiveDurationSec(chosenMp4.length),
      },
      subtitleUrl: `https://archive.org/download/${encodeURIComponent(identifier)}/${encodeArchiveFilePath(chosenSub.name)}`,
    };

    if (archiveSourceCache.size >= 180) {
      const oldest = archiveSourceCache.keys().next().value;
      if (oldest) archiveSourceCache.delete(oldest);
    }
    archiveSourceCache.set(identifier, {
      data: resolved,
      expiresAt: Date.now() + OPEN_SOURCE_TTL_MS,
    });
    return resolved;
  }

  async function ensureOpenSourceCues(source: ResolvedOpenVideoSource): Promise<RawTranscriptCue[]> {
    if (source.cues && source.cues.length > 0) return source.cues;
    const rawSub = await fetchTextWithTimeout(
      source.subtitleUrl,
      { headers: { 'User-Agent': OPEN_VIDEO_UA } },
      4_500,
      1_200_000
    );
    if (!rawSub) return [];
    const parsed = parseSrtOrVttToCues(rawSub);
    if (parsed.length > 0) {
      source.cues = parsed;
    }
    return parsed;
  }

  async function fetchArchiveOrgClips(
    targetQuery: string,
    mode: 'word' | 'sentence',
    page: number
  ): Promise<WordVideoClip[]> {
    const safeTerm = targetQuery.replace(/["\]/g, '').trim();
    if (!safeTerm) return [];
    const iaPage = Math.max(1, page + 1);

    const [cinemaIds, lectureIds] = await Promise.all([
      searchArchiveIdentifiers(
        `mediatype:movies AND format:"MPEG4" AND (format:"SubRip" OR format:"Web Video Text Tracks") AND collection:(feature_films OR classic_tv OR sci_fi_horror OR film_noir OR moviesandfilms) AND ("${safeTerm}")`,
        6,
        iaPage
      ),
      searchArchiveIdentifiers(
        `mediatype:movies AND format:"MPEG4" AND (format:"SubRip" OR format:"Web Video Text Tracks") AND collection:(opensource_movies OR academic_conferences OR educationalfilms OR mit_ocw OR prelinger) AND ("${safeTerm}")`,
        6,
        iaPage
      ),
    ]);

    let candidateIds = Array.from(new Set([...cinemaIds, ...lectureIds]));
    // For everyday words that rarely appear in film titles, also scan popular captioned public-domain films
    if (candidateIds.length < 5) {
      const popular = await getPopularCaptionedArchiveIds();
      const offset = (page * 4) % Math.max(1, popular.length);
      const rotated = [...popular.slice(offset), ...popular.slice(0, offset)];
      candidateIds = Array.from(new Set([...candidateIds, ...rotated])).slice(0, 7);
    } else {
      candidateIds = candidateIds.slice(0, 7);
    }

    const resolvedList = (
      await Promise.all(candidateIds.map((id) => resolveArchiveVideoSource(id).catch(() => null)))
    ).filter((s): s is ResolvedOpenVideoSource => Boolean(s));

    const perVideo = await Promise.all(
      resolvedList.map(async (src) => {
        const cues = await ensureOpenSourceCues(src);
        if (!cues.length) return [] as WordVideoClip[];
        return mode === 'sentence'
          ? (extractSentenceClipsFromCues(src.meta, cues, targetQuery, 2) as WordVideoClip[])
          : extractWordClipsFromCues(src.meta, cues, targetQuery, 3);
      })
    );

    return interleaveVideoSources(perVideo);
  }

  async function getVoaRecentVideoUrls(): Promise<string[]> {
    if (voaFeedUrlsCache.urls.length > 0 && Date.now() < voaFeedUrlsCache.expiresAt) {
      return voaFeedUrlsCache.urls;
    }
    // Official VOA Learning English video feeds (English in a Minute / Learning English TV / Everyday Grammar TV)
    const feedUrls = [
      'https://learningenglish.voanews.com/api/zkm-qem_ti',
      'https://learningenglish.voanews.com/api/z_y$qemoti',
    ];
    const xmls = await Promise.all(
      feedUrls.map((u) => fetchTextWithTimeout(u, { headers: { 'User-Agent': OPEN_VIDEO_UA } }, 3_800))
    );
    const urls: string[] = [];
    const seen = new Set<string>();
    const linkRx = /<link>(https:\/\/learningenglish\.voanews\.com\/a\/[^<]+)<\/link>/gi;
    for (const xml of xmls) {
      if (!xml) continue;
      let m: RegExpExecArray | null = null;
      while ((m = linkRx.exec(xml)) !== null) {
        const href = m[1].trim();
        if (href && !seen.has(href)) {
          seen.add(href);
          urls.push(href);
        }
      }
    }
    if (urls.length > 0) {
      voaFeedUrlsCache.urls = urls.slice(0, 24);
      voaFeedUrlsCache.expiresAt = Date.now() + 6 * 60 * 60 * 1000;
    }
    return voaFeedUrlsCache.urls;
  }

  async function resolveVoaVideoPage(pageUrl: string): Promise<ResolvedOpenVideoSource | null> {
    const cached = voaSourceCache.get(pageUrl);
    if (cached && Date.now() < cached.expiresAt) return cached.data;

    const html = await fetchTextWithTimeout(
      pageUrl,
      {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
          Accept: 'text/html,application/xhtml+xml',
        },
      },
      4_200,
      900_000
    );
    if (!html) {
      voaSourceCache.set(pageUrl, { data: null, expiresAt: Date.now() + 30 * 60 * 1000 });
      return null;
    }

    const mp4Matches = Array.from(
      new Set(
        (html.match(/https:\/\/(?:av\.voanews\.com|voa-video-ns\.akamaized\.net)\/[^\s"'<>\]+\.mp4/gi) || [])
          .map((u) => u.replace(/\u0026/g, '&'))
      )
    );
    const subMatches = Array.from(
      new Set(
        (html.match(/https:\/\/(?:av\.voanews\.com|learningenglish\.voanews\.com)\/[^\s"'<>\]+\.(?:vtt|srt)/gi) ||
          [])
          .map((u) => u.replace(/\u0026/g, '&'))
      )
    );

    if (!mp4Matches.length || !subMatches.length) {
      voaSourceCache.set(pageUrl, { data: null, expiresAt: Date.now() + 2 * 60 * 60 * 1000 });
      return null;
    }

    // Prefer medium/mobile MP4 bitrate for fast playback
    const bestMp4 =
      mp4Matches.find((u) => /(_mobile|_360p|_480p|_hq)/i.test(u)) || mp4Matches[0];
    const bestSub =
      subMatches.find((u) => /(_en|\.en\.|english)/i.test(u)) || subMatches[0];

    const titleMatch =
      /<meta\s+property=["']og:title["']\s+content=["']([^"']+)["']/i.exec(html) ||
      /<title>([^<]+)<\/title>/i.exec(html);
    const posterMatch =
      /<meta\s+property=["']og:image["']\s+content=["']([^"']+)["']/i.exec(html);
    const title = (titleMatch?.[1] || 'VOA Learning English')
      .replace(/\s*\|\s*VOA Learning English.*$/i, '')
      .replace(/&amp;/g, '&')
      .replace(/&#39;/g, "'")
      .replace(/&quot;/g, '"')
      .trim()
      .slice(0, 120);
    const slugMatch = /\/a\/([^/?#]+)/i.exec(pageUrl);
    const slug = (slugMatch?.[1] || 'voa').replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 40);

    const resolved: ResolvedOpenVideoSource = {
      meta: {
        videoId: `voa_${slug}`,
        slug,
        title,
        speaker: 'VOA Learning English',
        sourceLabel: 'VOA Learning English',
        videoUrl: bestMp4,
        posterUrl: posterMatch?.[1] && posterMatch[1].startsWith('https://') ? posterMatch[1] : '',
        durationSec: 240,
      },
      subtitleUrl: bestSub,
    };

    if (voaSourceCache.size >= 120) {
      const oldest = voaSourceCache.keys().next().value;
      if (oldest) voaSourceCache.delete(oldest);
    }
    voaSourceCache.set(pageUrl, { data: resolved, expiresAt: Date.now() + OPEN_SOURCE_TTL_MS });
    return resolved;
  }

  async function fetchVoaLearningEnglishClips(
    targetQuery: string,
    mode: 'word' | 'sentence',
    page: number
  ): Promise<WordVideoClip[]> {
    const clean = targetQuery.trim();
    if (!clean) return [];

    const searchHtml = await fetchTextWithTimeout(
      `https://learningenglish.voanews.com/s?k=${encodeURIComponent(clean)}&tab=video&pi=${page + 1}`,
      {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
          Accept: 'text/html,application/xhtml+xml',
        },
      },
      4_000,
      500_000
    );

    const urls: string[] = [];
    const seen = new Set<string>();
    if (searchHtml) {
      const rx = /href=["'](\/a\/[^"'?#]+\/\d+\.html)["']/gi;
      let m: RegExpExecArray | null = null;
      while ((m = rx.exec(searchHtml)) !== null && urls.length < 5) {
        const full = `https://learningenglish.voanews.com${m[1]}`;
        if (!seen.has(full)) {
          seen.add(full);
          urls.push(full);
        }
      }
    }

    if (urls.length < 3) {
      const recent = await getVoaRecentVideoUrls();
      const offset = (page * 3) % Math.max(1, recent.length);
      const rotated = [...recent.slice(offset), ...recent.slice(0, offset)];
      for (const u of rotated) {
        if (urls.length >= 4) break;
        if (!seen.has(u)) {
          seen.add(u);
          urls.push(u);
        }
      }
    }

    const resolvedList = (
      await Promise.all(urls.slice(0, 4).map((u) => resolveVoaVideoPage(u).catch(() => null)))
    ).filter((s): s is ResolvedOpenVideoSource => Boolean(s));

    const perVideo = await Promise.all(
      resolvedList.map(async (src) => {
        const cues = await ensureOpenSourceCues(src);
        if (!cues.length) return [] as WordVideoClip[];
        return mode === 'sentence'
          ? (extractSentenceClipsFromCues(src.meta, cues, targetQuery, 2) as WordVideoClip[])
          : extractWordClipsFromCues(src.meta, cues, targetQuery, 3);
      })
    );

    return interleaveVideoSources(perVideo);
  }

  interface WikimediaDerivative {
    src?: string;
    type?: string;
    shorttitle?: string;
    height?: number;
  }

  interface WikimediaPageNode {
    pageid?: number;
    title?: string;
    revisions?: Array<{
      slots?: { main?: { '*'?: string; content?: string } };
      '*'?: string;
    }>;
    videoinfo?: Array<{
      url?: string;
      thumburl?: string;
      duration?: number;
      mime?: string;
      derivatives?: WikimediaDerivative[];
    }>;
  }

  async function fetchWikimediaTimedTextClips(
    targetQuery: string,
    mode: 'word' | 'sentence',
    page: number
  ): Promise<WordVideoClip[]> {
    const clean = targetQuery.replace(/["\]/g, '').trim();
    if (!clean) return [];
    const srsearch = `intitle:".en.srt" "${clean}"`;
    const searchUrl =
      `https://commons.wikimedia.org/w/api.php?action=query&list=search&srnamespace=710` +
      `&srsearch=${encodeURIComponent(srsearch)}&srlimit=7&sroffset=${page * 6}&format=json`;

    const searchData = await fetchJsonWithTimeout<{
      query?: { search?: Array<{ title?: string }> };
    }>(searchUrl, { headers: { 'User-Agent': OPEN_VIDEO_UA } }, 4_500);

    const timedTitles = (searchData?.query?.search || [])
      .map((h) => h.title || '')
      .filter((t) => /^TimedText:.+\.en\.srt$/i.test(t))
      .slice(0, 6);

    if (!timedTitles.length) return [];

    const pairs = timedTitles.map((tt) => {
      const filePart = tt.replace(/^TimedText:/i, '').replace(/\.en\.srt$/i, '');
      return { timedTitle: tt, fileTitle: `File:${filePart}` };
    });

    const [srtRes, videoRes] = await Promise.all([
      fetchJsonWithTimeout<{ query?: { pages?: Record<string, WikimediaPageNode> } }>(
        `https://commons.wikimedia.org/w/api.php?action=query&prop=revisions&rvprop=content&rvslots=main&format=json&titles=${encodeURIComponent(
          pairs.map((p) => p.timedTitle).join('|')
        )}`,
        { headers: { 'User-Agent': OPEN_VIDEO_UA } },
        4_500
      ),
      fetchJsonWithTimeout<{ query?: { pages?: Record<string, WikimediaPageNode> } }>(
        `https://commons.wikimedia.org/w/api.php?action=query&prop=videoinfo&viprop=url|duration|derivatives|mime&viurlwidth=640&format=json&titles=${encodeURIComponent(
          pairs.map((p) => p.fileTitle).join('|')
        )}`,
        { headers: { 'User-Agent': OPEN_VIDEO_UA } },
        4_500
      ),
    ]);

    const srtByTitle = new Map<string, string>();
    for (const node of Object.values(srtRes?.query?.pages || {})) {
      if (!node?.title) continue;
      const rev = node.revisions?.[0];
      const text = rev?.slots?.main?.['*'] || rev?.slots?.main?.content || rev?.['*'] || '';
      if (text) srtByTitle.set(node.title.toLowerCase(), text);
    }

    const videoByTitle = new Map<string, WikimediaPageNode>();
    for (const node of Object.values(videoRes?.query?.pages || {})) {
      if (node?.title) videoByTitle.set(node.title.toLowerCase(), node);
    }

    const perVideo: WordVideoClip[][] = [];
    for (const pair of pairs) {
      const srtText = srtByTitle.get(pair.timedTitle.toLowerCase());
      const vNode = videoByTitle.get(pair.fileTitle.toLowerCase());
      const vi = vNode?.videoinfo?.[0];
      if (!srtText || !vi) continue;

      const derivatives = (vi.derivatives || []).filter(
        (d) => typeof d.src === 'string' && d.src.startsWith('https://')
      );
      // Prefer MP4 first, then fast 360p/480p WebM VP9 derivatives
      const picked =
        derivatives.find((d) => /\.mp4(\?|$)/i.test(d.src || '')) ||
        derivatives.find(
          (d) =>
            /webm/i.test(d.type || d.src || '') &&
            typeof d.height === 'number' &&
            d.height >= 360 &&
            d.height <= 480
        ) ||
        derivatives.find((d) => /webm/i.test(d.type || d.src || ''));

      const directUrl =
        picked?.src ||
        (vi.url && /\.(mp4|webm)(\?|$)/i.test(vi.url) ? vi.url : '');
      if (!directUrl || !directUrl.startsWith('https://')) continue;

      const cues = parseSrtOrVttToCues(srtText);
      if (!cues.length) continue;

      const cleanTitle = pair.fileTitle
        .replace(/^File:/i, '')
        .replace(/\.(webm|ogv|mp4|mov|mkv)$/i, '')
        .replace(/_/g, ' ')
        .trim()
        .slice(0, 110);

      const meta: SourceVideoMeta = {
        videoId: `wm_${vNode?.pageid || cleanTitle.replace(/[^a-zA-Z0-9]/g, '').slice(0, 24)}`,
        slug: cleanTitle.toLowerCase().replace(/[^a-z0-9]+/g, '-').slice(0, 40),
        title: cleanTitle || 'Open Educational Lecture',
        speaker: 'Open Educational Archive',
        sourceLabel: 'Open Lectures · Wikimedia',
        videoUrl: directUrl,
        posterUrl: vi.thumburl && vi.thumburl.startsWith('https://') ? vi.thumburl : '',
        durationSec: typeof vi.duration === 'number' && vi.duration > 6 ? Math.round(vi.duration) : 300,
      };

      const found =
        mode === 'sentence'
          ? (extractSentenceClipsFromCues(meta, cues, targetQuery, 2) as WordVideoClip[])
          : extractWordClipsFromCues(meta, cues, targetQuery, 3);
      if (found.length > 0) perVideo.push(found);
    }

    return interleaveVideoSources(perVideo);
  }

  interface TedZenithHit {
    slug?: string;
    name?: string;
    speakers?: string;
    duration?: number;
  }

  interface TedZenithResponse {
    results?: Array<{
      hits?: TedZenithHit[];
      nbHits?: number;
      nbPages?: number;
    }>;
  }

  async function searchTedSlugs(
    query: string,
    indexName: 'relevance' | 'popularity' | 'newest',
    startPage: number,
    numPages: number,
    hitsPerPage = 24
  ): Promise<{ slugs: string[]; totalFound: number; hasMorePages: boolean }> {
    const requests = Array.from({ length: numPages }, (_, idx) => ({
      indexName,
      params: `query=${encodeURIComponent(query)}&hitsPerPage=${hitsPerPage}&page=${startPage + idx}`,
    }));

    const data = await fetchJsonWithTimeout<TedZenithResponse>(
      'https://zenith-prod-alt.ted.com/api/search',
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        },
        body: JSON.stringify(requests),
      },
      9_500
    );

    const seen = new Set<string>();
    const slugs: string[] = [];
    let totalFound = 0;
    let hasMorePages = false;

    for (const r of data?.results || []) {
      if (typeof r.nbHits === 'number' && r.nbHits > totalFound) {
        totalFound = r.nbHits;
      }
      if (typeof r.nbPages === 'number' && startPage + numPages < r.nbPages) {
        hasMorePages = true;
      }
      for (const hit of r.hits || []) {
        const safeSlug = typeof hit.slug === 'string' ? hit.slug.replace(/[^a-zA-Z0-9_-]/g, '') : '';
        if (safeSlug && !seen.has(safeSlug)) {
          seen.add(safeSlug);
          slugs.push(safeSlug);
        }
      }
    }

    return { slugs, totalFound, hasMorePages };
  }

  interface TedGqlVideoNode {
    id?: string;
    slug?: string;
    title?: string;
    duration?: number;
    presenterDisplayName?: string;
    nativeDownloads?: { low?: string | null; medium?: string | null; high?: string | null } | null;
    playerData?: string | null;
    primaryImageSet?: Array<{ url?: string | null }> | null;
  }

  function extractTedMp4Url(node: TedGqlVideoNode | null | undefined, preferLowForSpeed = true): string {
    if (!node) return '';
    const nd = node.nativeDownloads;
    if (preferLowForSpeed) {
      if (nd?.low && nd.low.startsWith('https://')) return nd.low;
      if (nd?.medium && nd.medium.startsWith('https://')) return nd.medium;
    } else {
      if (nd?.medium && nd.medium.startsWith('https://')) return nd.medium;
      if (nd?.low && nd.low.startsWith('https://')) return nd.low;
    }

    // Parse playerData.resources.h264[] whenever nativeDownloads is missing/null
    if (node.playerData && typeof node.playerData === 'string') {
      try {
        const pd = JSON.parse(node.playerData) as {
          resources?: { h264?: Array<{ file?: string; bitrate?: number }> };
        };
        const list = (pd?.resources?.h264 || []).filter(
          (r) => typeof r?.file === 'string' && r.file.startsWith('https://')
        );
        if (list.length > 0) {
          // Prefer fast medium/low bitrates (~450k-950k) so clips start immediately
          const sorted = [...list].sort((a, b) => {
            const ba = typeof a.bitrate === 'number' ? a.bitrate : 900;
            const bb = typeof b.bitrate === 'number' ? b.bitrate : 900;
            const target = preferLowForSpeed ? 600 : 950;
            return Math.abs(ba - target) - Math.abs(bb - target);
          });
          if (sorted[0]?.file) return sorted[0].file;
        }
      } catch {
        // Ignore malformed playerData JSON
      }
    }

    if (nd?.high && nd.high.startsWith('https://')) return nd.high;
    return '';
  }

  async function fetchTedVideoMetadataBatch(slugs: string[]): Promise<SourceVideoMeta[]> {
    if (!slugs.length) return [];
    const chunkSize = 14;
    const chunks: string[][] = [];
    for (let i = 0; i < slugs.length; i += chunkSize) {
      chunks.push(slugs.slice(i, i + chunkSize));
    }

    const chunkResults = await Promise.all(
      chunks.map(async (chunk) => {
        const fields = chunk
          .map(
            (slug, i) =>
              `v${i}: video(slug: "${slug}") { id slug title duration presenterDisplayName nativeDownloads { low medium high } playerData primaryImageSet { url } }`
          )
          .join('\n');

        const gql = await fetchJsonWithTimeout<{ data?: Record<string, TedGqlVideoNode | null> }>(
          'https://www.ted.com/graphql',
          {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            },
            body: JSON.stringify({ query: `query { ${fields} }` }),
          },
          9_500
        );

        const metas: SourceVideoMeta[] = [];
        const rawData = gql?.data || {};
        for (const node of Object.values(rawData)) {
          if (!node || !node.id || !node.slug) continue;
          const videoUrl = extractTedMp4Url(node, true);
          if (!videoUrl || !videoUrl.startsWith('https://')) continue;
          const safeId = String(node.id).replace(/[^0-9]/g, '');
          if (!safeId) continue;
          const posterUrl =
            node.primaryImageSet?.find((img) => typeof img?.url === 'string' && img.url.startsWith('https://'))
              ?.url || '';

          metas.push({
            videoId: safeId,
            slug: node.slug,
            title: (node.title || 'English Talk').trim(),
            speaker: (node.presenterDisplayName || 'Native Speaker').trim(),
            sourceLabel: 'TED Talks',
            videoUrl,
            posterUrl,
            durationSec: typeof node.duration === 'number' && node.duration > 10 ? node.duration : 600,
          });
        }
        return metas;
      })
    );

    return chunkResults.flat();
  }

  interface TedGqlTranslationNode {
    paragraphs?: Array<{
      cues?: Array<{ time?: number; text?: string }> | null;
    }> | null;
  }

  async function extractClipsForVideos(
    metas: SourceVideoMeta[],
    matchWord: string,
    maxPerVideo = 5
  ): Promise<WordVideoClip[]> {
    if (!metas.length) return [];
    const chunkSize = 12;
    const chunks: SourceVideoMeta[][] = [];
    for (let i = 0; i < metas.length; i += chunkSize) {
      chunks.push(metas.slice(i, i + chunkSize));
    }

    const allClips = await Promise.all(
      chunks.map(async (chunk) => {
        const fields = chunk
          .map(
            (m, i) =>
              `t${i}: translation(videoId: "${m.videoId}", language: "en") { paragraphs { cues { time text } } }`
          )
          .join('\n');

        const gql = await fetchJsonWithTimeout<{
          data?: Record<string, TedGqlTranslationNode | null>;
        }>(
          'https://www.ted.com/graphql',
          {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            },
            body: JSON.stringify({ query: `query { ${fields} }` }),
          },
          11_000
        );

        const rawData = gql?.data || {};
        const perTalkClips: WordVideoClip[][] = [];
        chunk.forEach((meta, i) => {
          const trans = rawData[`t${i}`];
          if (!trans?.paragraphs?.length) return;
          const cues: RawTranscriptCue[] = [];
          for (const para of trans.paragraphs) {
            for (const cue of para?.cues || []) {
              if (typeof cue?.time === 'number' && typeof cue?.text === 'string') {
                cues.push({ time: cue.time, text: cue.text });
              }
            }
          }
          if (!cues.length) return;
          const found = extractWordClipsFromCues(meta, cues, matchWord, maxPerVideo);
          if (found.length > 0) perTalkClips.push(found);
        });
        return perTalkClips;
      })
    );

    // Round-robin interleave across talks so every Next/Swipe brings a fresh speaker & scene
    const talks = allClips.flat();
    const interleaved: WordVideoClip[] = [];
    const maxDepth = talks.reduce((acc, arr) => Math.max(acc, arr.length), 0);
    for (let depth = 0; depth < maxDepth; depth++) {
      for (const talkArr of talks) {
        if (talkArr[depth]) interleaved.push(talkArr[depth]);
      }
    }

    return dedupeVideoClips(interleaved);
  }

  async function fetchWordClipsPage(cleanWord: string, page: number): Promise<WordClipsPageResponse> {
    const indexOrder: Array<'relevance' | 'popularity' | 'newest'> = [
      'relevance',
      'relevance',
      'relevance',
      'popularity',
      'popularity',
      'newest',
      'newest',
    ];
    const indexName = indexOrder[page] || 'relevance';
    const indexStartPage =
      indexName === 'relevance'
        ? page * 2
        : indexName === 'popularity'
          ? (page - 3) * 2
          : (page - 5) * 2;

    const openTimeoutMs = page === 0 ? 6_200 : 8_200;
    const archivePromise = withSoftTimeout(
      fetchArchiveOrgClips(cleanWord, 'word', page),
      openTimeoutMs,
      []
    );
    const voaPromise = withSoftTimeout(
      fetchVoaLearningEnglishClips(cleanWord, 'word', page),
      openTimeoutMs,
      []
    );
    const wikimediaPromise = withSoftTimeout(
      fetchWikimediaTimedTextClips(cleanWord, 'word', page),
      openTimeoutMs,
      []
    );

    const slugLimit = page === 0 ? 14 : 22;
    const searchPages = page === 0 ? 1 : 2;
    const searchRes = await searchTedSlugs(cleanWord, indexName, Math.max(0, indexStartPage), searchPages, 20);
    let slugs = searchRes.slugs.slice(0, slugLimit);
    let matchTarget = cleanWord;
    let totalFound = searchRes.totalFound;
    let hasMore = searchRes.hasMorePages || page < 5;

    // For rare/compound words with sparse exact hits, expand to the base stem or core token
    if (slugs.length < 8) {
      const fallbackTerm = deriveFallbackSearchTerm(cleanWord);
      if (fallbackTerm) {
        const fbSearch = await searchTedSlugs(fallbackTerm, 'relevance', Math.max(0, page * 2), 1, 18);
        if (fbSearch.slugs.length > 0) {
          const merged = Array.from(new Set([...slugs, ...fbSearch.slugs])).slice(0, slugLimit);
          slugs = merged;
          if (searchRes.slugs.length === 0) {
            matchTarget = fallbackTerm;
          }
          totalFound = Math.max(totalFound, fbSearch.totalFound);
        }
      }
    }

    const metas = await fetchTedVideoMetadataBatch(slugs);
    let tedClips = await extractClipsForVideos(metas, matchTarget, page === 0 ? 5 : 4);

    // If strict exact match returned very few clips on a compound/rare word, try stem matching on the already-fetched metas
    if (tedClips.length < 12 && matchTarget === cleanWord) {
      const fallbackTerm = deriveFallbackSearchTerm(cleanWord);
      if (fallbackTerm && metas.length > 0) {
        const extra = await extractClipsForVideos(metas.slice(0, 14), fallbackTerm, 4);
        tedClips = dedupeVideoClips([...tedClips, ...extra]);
      }
    }

    const [archiveClips, voaClips, wikimediaClips] = await Promise.all([
      archivePromise,
      voaPromise,
      wikimediaPromise,
    ]);

    // Blend TED Talks with Archive.org Classic Movies/Lectures, VOA Learning English, and Wikimedia Open Lectures
    const clips = interleaveVideoSources([
      tedClips,
      archiveClips,
      voaClips,
      wikimediaClips,
    ]);

    if (page >= 6 || (slugs.length === 0 && clips.length === 0)) {
      hasMore = false;
    }

    return {
      word: cleanWord,
      page,
      clips,
      hasMore,
      totalFound: Math.max(totalFound, clips.length),
    };
  }

  app.get('/api/word-clips', rateLimitApi, async (req: Request, res: Response) => {
    try {
      const rawWord = typeof req.query.word === 'string' ? req.query.word : '';
      const cleanWord = rawWord
        .trim()
        .slice(0, 60)
        .replace(/[^a-zA-Z0-9'\-\s]/g, '')
        .trim();

      if (!cleanWord) {
        res.status(400).json({ error: 'الكلمة الإنجليزية مطلوبة.' });
        return;
      }

      const rawPage = Number.parseInt(String(req.query.page ?? '0'), 10);
      const page = Number.isFinite(rawPage) ? Math.max(0, Math.min(6, rawPage)) : 0;
      const cacheKey = `${cleanWord.toLowerCase()}::p${page}`;

      const cached = getCachedWordClips(cacheKey);
      if (cached) {
        res.setHeader('Cache-Control', 'public, max-age=3600');
        res.json(cached);
        return;
      }

      let pending = wordClipsInflight.get(cacheKey);
      if (!pending) {
        pending = fetchWordClipsPage(cleanWord, page)
          .then((result) => {
            if (result.clips.length > 0) {
              setCachedWordClips(cacheKey, result);
            }
            return result;
          })
          .finally(() => {
            wordClipsInflight.delete(cacheKey);
          });
        wordClipsInflight.set(cacheKey, pending);
      }

      const result = await pending;
      res.setHeader('Cache-Control', 'public, max-age=1800');
      res.json(result);
    } catch (err) {
      console.error('[word-clips] error:', err instanceof Error ? err.message : err);
      res.status(500).json({ error: 'تعذر تحميل مقاطع الفيديو حالياً.' });
    }
  });

  // ───────────────────────────────────────────────────────────────────────────
  // Full-Sentence Spoken Video Clips (/api/sentence-clips)
  // Matches the COMPLETE target sentence (or >=72% contiguous multi-word phrase)
  // across merged TED Talk transcript cues — never falls back to a single word.
  // ───────────────────────────────────────────────────────────────────────────
  async function extractSentenceClipsForVideos(
    metas: SourceVideoMeta[],
    targetSentence: string,
    maxPerVideo = 3
  ): Promise<WordVideoClip[]> {
    if (!metas.length) return [];
    const chunks: SourceVideoMeta[][] = [];
    for (let i = 0; i < metas.length; i += 6) {
      chunks.push(metas.slice(i, i + 6));
    }

    const allMatches = await Promise.all(
      chunks.map(async (chunk) => {
        const fields = chunk
          .map(
            (m, i) =>
              `t${i}: translation(videoId: "${m.videoId}", language: "en") { paragraphs { cues { time text } } }`
          )
          .join('\n');

        const gql = await fetchJsonWithTimeout<{
          data?: Record<string, TedGqlTranslationNode | null>;
        }>(
          'https://www.ted.com/graphql',
          {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            },
            body: JSON.stringify({ query: `query { ${fields} }` }),
          },
          11_500
        );

        const rawData = gql?.data || {};
        const perTalkMatches: SentenceVideoClipMatch[] = [];
        chunk.forEach((meta, i) => {
          const trans = rawData[`t${i}`];
          if (!trans?.paragraphs?.length) return;
          const cues: RawTranscriptCue[] = [];
          for (const para of trans.paragraphs) {
            for (const cue of para?.cues || []) {
              if (typeof cue?.time === 'number' && typeof cue?.text === 'string') {
                cues.push({ time: cue.time, text: cue.text });
              }
            }
          }
          if (!cues.length) return;
          const found = extractSentenceClipsFromCues(meta, cues, targetSentence, maxPerVideo);
          if (found.length > 0) perTalkMatches.push(...found);
        });
        return perTalkMatches;
      })
    );

    const ranked = allMatches
      .flat()
      .sort((a, b) => b.matchScore - a.matchScore);

    return dedupeVideoClips(ranked);
  }

  async function fetchSentenceClipsPage(
    cleanSentence: string,
    page: number
  ): Promise<WordClipsPageResponse> {
    const queries = buildSentenceSearchQueries(cleanSentence);
    if (!queries.length) {
      return { word: cleanSentence, page, clips: [], hasMore: false, totalFound: 0 };
    }

    const indexName: 'relevance' | 'popularity' | 'newest' =
      page <= 1 ? 'relevance' : page === 2 ? 'popularity' : 'newest';
    const startPage = page === 0 ? 0 : page === 1 ? 1 : 0;

    // Run prioritized full-sentence searches (exact quoted + contraction-expanded + unquoted)
    const slugSet = new Set<string>();
    const slugs: string[] = [];
    let totalFound = 0;
    let hasMorePages = false;

    const searchQueriesToRun = page === 0 ? queries.slice(0, 3) : queries.slice(0, 4);
    const searchResults = await Promise.all(
      searchQueriesToRun.map((q) =>
        searchTedSlugs(q, indexName, startPage, 1, 16).catch(() => ({
          slugs: [] as string[],
          totalFound: 0,
          hasMorePages: false,
        }))
      )
    );

    for (const sr of searchResults) {
      totalFound = Math.max(totalFound, sr.totalFound);
      if (sr.hasMorePages) hasMorePages = true;
      for (const s of sr.slugs) {
        if (!slugSet.has(s)) {
          slugSet.add(s);
          slugs.push(s);
        }
      }
    }

    const openTimeoutMs = page === 0 ? 6_500 : 8_500;
    const openSourcesPromise = Promise.all([
      withSoftTimeout(fetchArchiveOrgClips(cleanSentence, 'sentence', page), openTimeoutMs, []),
      withSoftTimeout(fetchVoaLearningEnglishClips(cleanSentence, 'sentence', page), openTimeoutMs, []),
      withSoftTimeout(fetchWikimediaTimedTextClips(cleanSentence, 'sentence', page), openTimeoutMs, []),
    ]);

    const cappedSlugs = slugs.slice(0, page === 0 ? 18 : 24);
    const metas = await fetchTedVideoMetadataBatch(cappedSlugs);
    const [tedClips, [archiveClips, voaClips, wikimediaClips]] = await Promise.all([
      extractSentenceClipsForVideos(metas, cleanSentence, 3),
      openSourcesPromise,
    ]);

    const clips = interleaveVideoSources([
      tedClips,
      archiveClips,
      voaClips,
      wikimediaClips,
    ]);

    return {
      word: cleanSentence,
      page,
      clips,
      hasMore: page < 3 && (hasMorePages || clips.length >= 4),
      totalFound: Math.max(totalFound, clips.length),
    };
  }

  app.get('/api/sentence-clips', rateLimitApi, async (req: Request, res: Response) => {
    try {
      const rawSentence = typeof req.query.sentence === 'string' ? req.query.sentence : '';
      const cleanSentence = cleanSentenceForVideoSearch(rawSentence.slice(0, 160));
      if (!cleanSentence || cleanSentence.length < 3) {
        res.status(400).json({ error: 'الجملة الإنجليزية مطلوبة.' });
        return;
      }

      const rawPage = Number.parseInt(String(req.query.page ?? '0'), 10);
      const page = Number.isFinite(rawPage) ? Math.max(0, Math.min(3, rawPage)) : 0;
      const cacheKey = `sentence::${cleanSentence.toLowerCase()}::p${page}`;

      const cached = getCachedWordClips(cacheKey);
      if (cached) {
        res.setHeader('Cache-Control', 'public, max-age=3600');
        res.json(cached);
        return;
      }

      let pending = wordClipsInflight.get(cacheKey);
      if (!pending) {
        pending = fetchSentenceClipsPage(cleanSentence, page)
          .then((result) => {
            if (result.clips.length > 0) {
              setCachedWordClips(cacheKey, result);
            }
            return result;
          })
          .finally(() => {
            wordClipsInflight.delete(cacheKey);
          });
        wordClipsInflight.set(cacheKey, pending);
      }

      const result = await pending;
      res.setHeader('Cache-Control', 'public, max-age=1800');
      res.json(result);
    } catch (err) {
      console.error('[sentence-clips] error:', err instanceof Error ? err.message : err);
      res.status(500).json({ error: 'تعذر تحميل مقاطع الفيديو لهذه الجملة حالياً.' });
    }
  });

  // ───────────────────────────────────────────────────────────────────────────
  // CEFR Listening Hub (A0–C2 Catalog, 11-Language Captions & Post-Video Quiz)
  // + 10-Language Grammar Localization
  // ───────────────────────────────────────────────────────────────────────────

  const VALID_UI_LANGS = new Set<UiLanguageCode>([
    'ar', 'hi', 'zh', 'ru', 'de', 'fr', 'es', 'it', 'pt', 'sv',
  ]);
  const GOOGLE_TL_MAP: Record<UiLanguageCode, string> = {
    ar: 'ar',
    hi: 'hi',
    zh: 'zh-CN',
    ru: 'ru',
    de: 'de',
    fr: 'fr',
    es: 'es',
    it: 'it',
    pt: 'pt',
    sv: 'sv',
  };
  const LANG_FULL_NAMES: Record<UiLanguageCode, string> = {
    ar: 'Arabic',
    hi: 'Hindi',
    zh: 'Simplified Chinese',
    ru: 'Russian',
    de: 'German',
    fr: 'French',
    es: 'Spanish',
    it: 'Italian',
    pt: 'Portuguese',
    sv: 'Swedish',
  };

  const listeningCatalogCache = new Map<string, { data: ListeningCatalogResponse; expiresAt: number }>();
  const listeningVideoCache = new Map<string, { data: ListeningVideoDetail; expiresAt: number }>();
  const openListeningSourceCache = new Map<
    string,
    { data: ResolvedOpenVideoSource; expiresAt: number }
  >();

  function setOpenListeningSource(slug: string, src: ResolvedOpenVideoSource): void {
    if (openListeningSourceCache.size >= 240) {
      const oldest = openListeningSourceCache.keys().next().value;
      if (oldest) openListeningSourceCache.delete(oldest);
    }
    openListeningSourceCache.set(slug, {
      data: src,
      expiresAt: Date.now() + 12 * 60 * 60 * 1000,
    });
  }

  function buildVoaListeningSlug(pageUrl: string, fallbackSlug: string): string {
    const m = /\/a\/([^/?#]+)\/(\d+)\.html/i.exec(pageUrl);
    if (m) {
      const safePart = m[1].replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 64);
      return `voa__${m[2]}__${safePart}`;
    }
    return `voa__${fallbackSlug.replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 80)}`;
  }

  async function resolveWikimediaListeningByPageId(
    pageId: string
  ): Promise<ResolvedOpenVideoSource | null> {
    const safePid = pageId.replace(/[^0-9]/g, '');
    if (!safePid) return null;
    const videoRes = await fetchJsonWithTimeout<{
      query?: { pages?: Record<string, WikimediaPageNode> };
    }>(
      `https://commons.wikimedia.org/w/api.php?action=query&pageids=${safePid}&prop=videoinfo&viprop=url|duration|derivatives|mime&viurlwidth=640&format=json`,
      { headers: { 'User-Agent': OPEN_VIDEO_UA } },
      4_500
    );
    const vNode = Object.values(videoRes?.query?.pages || {})[0];
    const vi = vNode?.videoinfo?.[0];
    if (!vNode?.title || !vi) return null;

    const derivatives = (vi.derivatives || []).filter(
      (d) => typeof d.src === 'string' && d.src.startsWith('https://')
    );
    const picked =
      derivatives.find((d) => /\.mp4(\?|$)/i.test(d.src || '')) ||
      derivatives.find(
        (d) =>
          /webm/i.test(d.type || d.src || '') &&
          typeof d.height === 'number' &&
          d.height >= 360 &&
          d.height <= 480
      ) ||
      derivatives.find((d) => /webm/i.test(d.type || d.src || ''));
    const directUrl =
      picked?.src || (vi.url && /\.(mp4|webm)(\?|$)/i.test(vi.url) ? vi.url : '');
    if (!directUrl || !directUrl.startsWith('https://')) return null;

    const filePart = vNode.title.replace(/^File:/i, '');
    const timedTitle = `TimedText:${filePart}.en.srt`;
    const srtRes = await fetchJsonWithTimeout<{
      query?: { pages?: Record<string, WikimediaPageNode> };
    }>(
      `https://commons.wikimedia.org/w/api.php?action=query&prop=revisions&rvprop=content&rvslots=main&format=json&titles=${encodeURIComponent(
        timedTitle
      )}`,
      { headers: { 'User-Agent': OPEN_VIDEO_UA } },
      4_500
    );
    const srtNode = Object.values(srtRes?.query?.pages || {})[0];
    const rev = srtNode?.revisions?.[0];
    const srtText = rev?.slots?.main?.['*'] || rev?.slots?.main?.content || rev?.['*'] || '';
    const cues = parseSrtOrVttToCues(srtText);

    const cleanTitle = filePart
      .replace(/\.(webm|ogv|mp4|mov|mkv)$/i, '')
      .replace(/_/g, ' ')
      .trim()
      .slice(0, 110);

    return {
      meta: {
        videoId: `wm_${safePid}`,
        slug: `wm__${safePid}`,
        title: cleanTitle || 'Open Educational Lecture',
        speaker: 'Open Educational Archive',
        sourceLabel: 'Open Lectures · Wikimedia',
        videoUrl: directUrl,
        posterUrl: vi.thumburl && vi.thumburl.startsWith('https://') ? vi.thumburl : '',
        durationSec:
          typeof vi.duration === 'number' && vi.duration > 30 ? Math.round(vi.duration) : 300,
      },
      subtitleUrl: '',
      cues,
    };
  }

  async function resolveOpenListeningVideoDetail(slug: string): Promise<ListeningVideoDetail | null> {
    let src: ResolvedOpenVideoSource | null = null;
    const cachedSrc = openListeningSourceCache.get(slug);
    if (cachedSrc && cachedSrc.expiresAt > Date.now()) {
      src = cachedSrc.data;
    }

    if (!src && slug.startsWith('ia__')) {
      const identifier = slug.slice(4);
      src = await resolveArchiveVideoSource(identifier);
      if (src) setOpenListeningSource(slug, src);
    } else if (!src && slug.startsWith('voa__')) {
      const parts = slug.slice(5).split('__');
      if (parts.length >= 2 && /^\d+$/.test(parts[0]) && parts[1]) {
        const reconstructedUrl = `https://learningenglish.voanews.com/a/${parts[1]}/${parts[0]}.html`;
        src = await resolveVoaVideoPage(reconstructedUrl);
        if (src) setOpenListeningSource(slug, src);
      }
    } else if (!src && slug.startsWith('wm__')) {
      src = await resolveWikimediaListeningByPageId(slug.slice(4));
      if (src) setOpenListeningSource(slug, src);
    }

    if (!src) return null;

    const rawCues =
      src.cues && src.cues.length > 0 ? src.cues : await ensureOpenSourceCues(src);
    const enCues = normalizeRawCuesToVideoCues(rawCues, src.meta.durationSec);

    return {
      id: src.meta.videoId,
      slug,
      title: src.meta.title,
      speaker: src.meta.speaker,
      sourceLabel: src.meta.sourceLabel,
      durationSec: src.meta.durationSec,
      videoUrl: src.meta.videoUrl,
      posterUrl: src.meta.posterUrl,
      enCues,
      translatedCues: {},
    };
  }

  async function fetchWikimediaListeningItems(
    topics: string[],
    band: CefrBand,
    limit = 4
  ): Promise<ListeningVideoItem[]> {
    const queryTopics = topics.slice(0, 2);
    const searchResults = await Promise.all(
      queryTopics.map((topic) =>
        fetchJsonWithTimeout<{ query?: { search?: Array<{ title?: string }> } }>(
          `https://commons.wikimedia.org/w/api.php?action=query&list=search&srnamespace=710&srsearch=${encodeURIComponent(
            `intitle:".en.srt" "${topic}"`
          )}&srlimit=5&format=json`,
          { headers: { 'User-Agent': OPEN_VIDEO_UA } },
          4_000
        )
      )
    );

    const timedTitles = Array.from(
      new Set(
        searchResults
          .flatMap((r) => r?.query?.search || [])
          .map((h) => h.title || '')
          .filter((t) => /^TimedText:.+\.en\.srt$/i.test(t))
      )
    ).slice(0, limit + 2);

    if (!timedTitles.length) return [];

    const pairs = timedTitles.map((tt) => {
      const filePart = tt.replace(/^TimedText:/i, '').replace(/\.en\.srt$/i, '');
      return { timedTitle: tt, fileTitle: `File:${filePart}` };
    });

    const [srtRes, videoRes] = await Promise.all([
      fetchJsonWithTimeout<{ query?: { pages?: Record<string, WikimediaPageNode> } }>(
        `https://commons.wikimedia.org/w/api.php?action=query&prop=revisions&rvprop=content&rvslots=main&format=json&titles=${encodeURIComponent(
          pairs.map((p) => p.timedTitle).join('|')
        )}`,
        { headers: { 'User-Agent': OPEN_VIDEO_UA } },
        4_200
      ),
      fetchJsonWithTimeout<{ query?: { pages?: Record<string, WikimediaPageNode> } }>(
        `https://commons.wikimedia.org/w/api.php?action=query&prop=videoinfo&viprop=url|duration|derivatives|mime&viurlwidth=640&format=json&titles=${encodeURIComponent(
          pairs.map((p) => p.fileTitle).join('|')
        )}`,
        { headers: { 'User-Agent': OPEN_VIDEO_UA } },
        4_200
      ),
    ]);

    const srtByTitle = new Map<string, string>();
    for (const node of Object.values(srtRes?.query?.pages || {})) {
      if (!node?.title) continue;
      const rev = node.revisions?.[0];
      const text = rev?.slots?.main?.['*'] || rev?.slots?.main?.content || rev?.['*'] || '';
      if (text) srtByTitle.set(node.title.toLowerCase(), text);
    }

    const videoByTitle = new Map<string, WikimediaPageNode>();
    for (const node of Object.values(videoRes?.query?.pages || {})) {
      if (node?.title) videoByTitle.set(node.title.toLowerCase(), node);
    }

    const items: ListeningVideoItem[] = [];
    for (const pair of pairs) {
      if (items.length >= limit) break;
      const srtText = srtByTitle.get(pair.timedTitle.toLowerCase());
      const vNode = videoByTitle.get(pair.fileTitle.toLowerCase());
      const vi = vNode?.videoinfo?.[0];
      if (!srtText || !vi || !vNode?.pageid) continue;

      const durationSec = typeof vi.duration === 'number' ? Math.round(vi.duration) : 0;
      if (durationSec < 60 || durationSec > 3600) continue;

      const derivatives = (vi.derivatives || []).filter(
        (d) => typeof d.src === 'string' && d.src.startsWith('https://')
      );
      const picked =
        derivatives.find((d) => /\.mp4(\?|$)/i.test(d.src || '')) ||
        derivatives.find(
          (d) =>
            /webm/i.test(d.type || d.src || '') &&
            typeof d.height === 'number' &&
            d.height >= 360 &&
            d.height <= 480
        ) ||
        derivatives.find((d) => /webm/i.test(d.type || d.src || ''));
      const directUrl =
        picked?.src || (vi.url && /\.(mp4|webm)(\?|$)/i.test(vi.url) ? vi.url : '');
      if (!directUrl || !directUrl.startsWith('https://')) continue;

      const cues = parseSrtOrVttToCues(srtText);
      if (cues.length < 4) continue;

      const cleanTitle = pair.fileTitle
        .replace(/^File:/i, '')
        .replace(/\.(webm|ogv|mp4|mov|mkv)$/i, '')
        .replace(/_/g, ' ')
        .trim()
        .slice(0, 110);

      const slug = `wm__${vNode.pageid}`;
      const resolved: ResolvedOpenVideoSource = {
        meta: {
          videoId: `wm_${vNode.pageid}`,
          slug,
          title: cleanTitle || 'Open Educational Lecture',
          speaker: 'Open Educational Archive',
          sourceLabel: 'Open Lectures · Wikimedia',
          videoUrl: directUrl,
          posterUrl: vi.thumburl && vi.thumburl.startsWith('https://') ? vi.thumburl : '',
          durationSec,
        },
        subtitleUrl: '',
        cues,
      };
      setOpenListeningSource(slug, resolved);

      items.push({
        id: resolved.meta.videoId,
        slug,
        title: resolved.meta.title,
        speaker: resolved.meta.speaker,
        sourceLabel: resolved.meta.sourceLabel,
        durationSec,
        posterUrl: resolved.meta.posterUrl,
        band,
        topicTag: queryTopics[0] || 'lecture',
      });
    }
    return items;
  }

  async function buildOpenListeningItemsForBand(band: CefrBand): Promise<ListeningVideoItem[]> {
    const cfg = LISTENING_LEVEL_MAP[band];
    const bandIdx = ['A0', 'A1', 'A2', 'B1', 'B2', 'C1', 'C2'].indexOf(band);

    // 1) VOA Learning English (ideal for A0–B2 clear everyday spoken English)
    const voaPromise = (async (): Promise<ListeningVideoItem[]> => {
      if (band === 'C2') return [];
      const recent = await getVoaRecentVideoUrls();
      if (!recent.length) return [];
      const offset = (Math.max(0, bandIdx) * 3) % recent.length;
      const rotated = [...recent.slice(offset), ...recent.slice(0, offset)].slice(0, 5);
      const resolved = await Promise.all(
        rotated.map(async (pageUrl) => {
          const src = await resolveVoaVideoPage(pageUrl).catch(() => null);
          return src ? { pageUrl, src } : null;
        })
      );
      const out: ListeningVideoItem[] = [];
      for (const entry of resolved) {
        if (!entry) continue;
        const slug = buildVoaListeningSlug(entry.pageUrl, entry.src.meta.slug);
        setOpenListeningSource(slug, entry.src);
        out.push({
          id: entry.src.meta.videoId,
          slug,
          title: entry.src.meta.title,
          speaker: entry.src.meta.speaker,
          sourceLabel: entry.src.meta.sourceLabel,
          durationSec: entry.src.meta.durationSec,
          posterUrl: entry.src.meta.posterUrl,
          band,
          topicTag: 'VOA',
        });
      }
      return out;
    })();

    // 2) Archive.org Classic Public-Domain Movies & Open Lectures (all bands, weighted by band topics)
    const archivePromise = (async (): Promise<ListeningVideoItem[]> => {
      const topicA = cfg.topics[0] || 'education';
      const topicB = cfg.topics[1] || 'science';
      const [topicIds, popularIds] = await Promise.all([
        searchArchiveIdentifiers(
          `mediatype:movies AND format:"MPEG4" AND (format:"SubRip" OR format:"Web Video Text Tracks") AND (${topicA} OR ${topicB}) AND language:(eng OR English)`,
          6,
          1
        ),
        getPopularCaptionedArchiveIds(),
      ]);
      const popOffset = (Math.max(0, bandIdx) * 3) % Math.max(1, popularIds.length);
      const rotatedPop = [...popularIds.slice(popOffset), ...popularIds.slice(0, popOffset)];
      const candidateIds = Array.from(new Set([...topicIds, ...rotatedPop])).slice(0, 7);

      const resolved = (
        await Promise.all(candidateIds.map((id) => resolveArchiveVideoSource(id).catch(() => null)))
      ).filter((s): s is ResolvedOpenVideoSource => Boolean(s));

      const out: ListeningVideoItem[] = [];
      for (const src of resolved) {
        if (out.length >= 5) break;
        const slug = `ia__${src.meta.slug}`;
        setOpenListeningSource(slug, src);
        out.push({
          id: src.meta.videoId,
          slug,
          title: src.meta.title,
          speaker: src.meta.speaker,
          sourceLabel: src.meta.sourceLabel,
          durationSec: Math.min(3600, Math.max(120, src.meta.durationSec)),
          posterUrl: src.meta.posterUrl,
          band,
          topicTag: topicA,
        });
      }
      return out;
    })();

    // 3) Wikimedia Commons Open Lectures & Documentaries
    const wikiPromise = fetchWikimediaListeningItems(cfg.topics, band, 4).catch(() => []);

    const [voaItems, archiveItems, wikiItems] = await Promise.all([
      voaPromise.catch(() => []),
      archivePromise.catch(() => []),
      wikiPromise,
    ]);

    // Interleave VOA, Archive.org, and Wikimedia evenly
    const merged: ListeningVideoItem[] = [];
    const groups = [voaItems, archiveItems, wikiItems].filter((g) => g.length > 0);
    const maxLen = groups.reduce((acc, g) => Math.max(acc, g.length), 0);
    for (let i = 0; i < maxLen; i++) {
      for (const g of groups) {
        if (g[i]) merged.push(g[i]);
      }
    }
    return merged;
  }
  const listeningCaptionsCache = new Map<string, { cues: VideoCaptionCue[]; expiresAt: number }>();
  const listeningQuizCache = new Map<string, { questions: ListeningQuizQuestion[]; expiresAt: number }>();
  const grammarLocalizeCache = new Map<string, { data: LocalizedGrammarPayload; expiresAt: number }>();

  function normalizeRawCuesToVideoCues(
    rawCues: Array<{ time?: number; text?: string }>,
    videoDurationSec: number
  ): VideoCaptionCue[] {
    const cleaned = rawCues
      .filter((c) => typeof c?.time === 'number' && typeof c?.text === 'string' && c.text.trim().length > 0)
      .map((c) => ({
        startSec: Math.max(0, Number(((c.time as number) / 1000).toFixed(2))),
        text: (c.text as string).replace(/\s+/g, ' ').trim(),
      }))
      .sort((a, b) => a.startSec - b.startSec);

    return cleaned.map((c, idx) => {
      const nextStart = idx + 1 < cleaned.length ? cleaned[idx + 1].startSec : videoDurationSec;
      const endSec = Math.max(c.startSec + 0.6, Math.min(nextStart, c.startSec + 7));
      return {
        startSec: c.startSec,
        endSec: Number(endSec.toFixed(2)),
        text: c.text,
      };
    });
  }

  function extractTedPhotoUrl(rawPhotos: unknown): string {
    if (!Array.isArray(rawPhotos)) return '';
    for (const item of rawPhotos) {
      if (typeof item === 'string' && item.startsWith('https://')) return item;
      if (item && typeof item === 'object') {
        const rec = item as Record<string, unknown>;
        if (typeof rec.url === 'string' && rec.url.startsWith('https://')) return rec.url;
        if (Array.isArray(rec.photo_sizes)) {
          // Prefer a landscape 16:9 or mid-width image for crisp fast card loading
          const sizes = rec.photo_sizes as Array<{ url?: string; width?: number }>;
          const preferred =
            sizes.find(
              (sz) =>
                typeof sz?.url === 'string' &&
                sz.url.startsWith('https://') &&
                typeof sz.width === 'number' &&
                sz.width >= 600 &&
                sz.width <= 1600
            ) ||
            sizes.find((sz) => typeof sz?.url === 'string' && sz.url.startsWith('https://'));
          if (preferred?.url) return preferred.url;
        }
        if (rec.photo && typeof rec.photo === 'object') {
          const inner = (rec.photo as Record<string, unknown>).url;
          if (typeof inner === 'string' && inner.startsWith('https://')) return inner;
        }
      }
    }
    return '';
  }

  async function translateLinesViaAiOrGtx(
    lines: string[],
    targetLang: UiLanguageCode
  ): Promise<string[]> {
    if (!lines.length) return [];
    const langName = LANG_FULL_NAMES[targetLang] || 'Arabic';
    const tl = GOOGLE_TL_MAP[targetLang] || 'ar';
    const chunkSize = 35;
    const chunks: string[][] = [];
    for (let i = 0; i < lines.length; i += chunkSize) {
      chunks.push(lines.slice(i, i + chunkSize));
    }

    const translatedChunks = await Promise.all(
      chunks.map(async (chunk) => {
        const sanitized = chunk.map((l) => l.replace(/\r?\n/g, ' ').trim() || '.');

        // 1) Try Gemini structured JSON translation
        try {
          const { data } = await callGeminiStructured<{ translations: string[] }>({
            contents: `Translate each English subtitle line below into natural, concise ${langName}. Return a JSON object {"translations":[...]} with EXACTLY ${sanitized.length} items in the same order.\nLines:\n${JSON.stringify(sanitized)}`,
            systemInstruction: `You are a professional subtitle translator. Translate strictly into ${langName} and preserve the exact array length (${sanitized.length}).`,
            preferLite: true,
            timeoutMs: 8500,
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                translations: { type: Type.ARRAY, items: { type: Type.STRING } },
              },
              required: ['translations'],
            },
          });
          if (Array.isArray(data?.translations) && data.translations.length >= sanitized.length) {
            return sanitized.map((orig, idx) => (data.translations[idx] || orig).trim());
          }
        } catch {
          // Try OpenLLM next
        }

        // 2) Try OpenLLM JSON translation
        try {
          const openRes = await callOpenLlmJson<{ translations?: string[] }>(
            `You are a professional subtitle translator. Translate each English line into ${langName}. Return strict JSON {"translations":[...]} with exact same array length.`,
            `Translate these ${sanitized.length} English lines into ${langName}:\n${JSON.stringify(sanitized)}`,
            8500
          );
          if (Array.isArray(openRes?.translations) && openRes.translations.length >= sanitized.length) {
            return sanitized.map((orig, idx) => (openRes.translations?.[idx] || orig).trim());
          }
        } catch {
          // Try Google GTX as last resort
        }

        // 3) Last-resort Google GTX endpoint
        const joined = sanitized.join('\n');
        const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=en&tl=${encodeURIComponent(
          tl
        )}&dt=t&q=${encodeURIComponent(joined)}`;
        try {
          const data = await fetchJsonWithTimeout<unknown[]>(
            url,
            { headers: { 'User-Agent': 'Mozilla/5.0' } },
            5000
          );
          if (Array.isArray(data) && Array.isArray(data[0])) {
            const fullText = (data[0] as unknown[])
              .map((seg) => (Array.isArray(seg) && typeof seg[0] === 'string' ? seg[0] : ''))
              .join('');
            const split = fullText.split(/\r?\n/);
            return chunk.map((orig, idx) => (split[idx] ? split[idx].trim() : orig));
          }
        } catch {
          // Keep original text on transient network error
        }
        return chunk;
      })
    );

    return translatedChunks.flat();
  }

  async function fetchTedTranslationCues(
    videoId: string,
    tedLang: string,
    durationSec: number
  ): Promise<VideoCaptionCue[]> {
    const safeId = videoId.replace(/[^0-9]/g, '');
    const safeLang = tedLang.replace(/[^a-zA-Z0-9_-]/g, '');
    if (!safeId || !safeLang) return [];

    const gql = await fetchJsonWithTimeout<{
      data?: { trans?: TedGqlTranslationNode | null };
    }>(
      'https://www.ted.com/graphql',
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        },
        body: JSON.stringify({
          query: `query { trans: translation(videoId: "${safeId}", language: "${safeLang}") { paragraphs { cues { time text } } } }`,
        }),
      },
      9_000
    );

    const paragraphs = gql?.data?.trans?.paragraphs;
    if (!Array.isArray(paragraphs) || !paragraphs.length) return [];
    const raw: Array<{ time?: number; text?: string }> = [];
    for (const p of paragraphs) {
      for (const c of p?.cues || []) {
        raw.push(c);
      }
    }
    return normalizeRawCuesToVideoCues(raw, durationSec);
  }

  async function getOrTranslateListeningCaptions(
    videoId: string,
    enCues: VideoCaptionCue[],
    lang: UiLanguageCode,
    durationSec: number
  ): Promise<VideoCaptionCue[]> {
    const cacheKey = `${videoId}::${lang}`;
    const hit = listeningCaptionsCache.get(cacheKey);
    if (hit && hit.expiresAt > Date.now()) {
      return hit.cues;
    }

    // 1) Try native human-curated TED translation first (only for numeric TED video IDs)
    const isTedNumericId = /^\d+$/.test(videoId);
    const tedLang = TED_LANG_CODE_MAP[lang] || lang;
    let cues = isTedNumericId ? await fetchTedTranslationCues(videoId, tedLang, durationSec) : [];

    // 2) Fallback: fast batched translation of the video's English cues so ALL 10 languages work on EVERY video
    if (!cues.length && enCues.length > 0) {
      const targetSlice = enCues.slice(0, 140);
      const translatedLines = await translateLinesViaAiOrGtx(
        targetSlice.map((c) => c.text),
        lang
      );
      cues = targetSlice.map((c, idx) => ({
        startSec: c.startSec,
        endSec: c.endSec,
        text: translatedLines[idx] || c.text,
      }));
    }

    if (cues.length > 0) {
      if (listeningCaptionsCache.size > 400) {
        const first = listeningCaptionsCache.keys().next().value;
        if (first) listeningCaptionsCache.delete(first);
      }
      listeningCaptionsCache.set(cacheKey, {
        cues,
        expiresAt: Date.now() + 12 * 60 * 60 * 1000,
      });
    }
    return cues;
  }

  interface ZenithListeningHit {
    objectID?: string;
    slug?: string;
    title?: string;
    name?: string;
    duration?: number | string;
    speakers?: string | Array<{ firstname?: string; lastname?: string; name?: string } | string>;
    photos?: unknown;
  }

  async function buildListeningCatalogForBand(band: CefrBand): Promise<ListeningCatalogResponse> {
    const cfg = LISTENING_LEVEL_MAP[band];
    const targetSec = cfg.requiredHours * 3600;

    // Build topic queries across pages (Zenith hard-caps hitsPerPage <= 24)
    const pagesPerTopic = cfg.requiredHours >= 25 ? 3 : 2;
    const rawRequests: Array<{ indexName: string; params: string; topicTag: string }> = [];
    for (let p = 0; p < pagesPerTopic; p++) {
      for (const topic of cfg.topics) {
        rawRequests.push({
          indexName: 'relevance',
          params: `query=${encodeURIComponent(topic)}&hitsPerPage=24&page=${p}`,
          topicTag: topic,
        });
      }
    }

    // Add extra general pages if C1/C2 need more hours
    if (cfg.requiredHours >= 25) {
      for (let p = 0; p < 5; p++) {
        rawRequests.push({
          indexName: 'relevance',
          params: `query=&hitsPerPage=24&page=${p + (band === 'C2' ? 6 : 1)}`,
          topicTag: 'featured',
        });
      }
    }

    // Batch Zenith requests in chunks of 12 in parallel (~500ms total)
    const batchSize = 12;
    const batches: Array<typeof rawRequests> = [];
    for (let i = 0; i < rawRequests.length; i += batchSize) {
      batches.push(rawRequests.slice(i, i + batchSize));
    }

    const openItemsPromise = withSoftTimeout(
      buildOpenListeningItemsForBand(band),
      6_000,
      [] as ListeningVideoItem[]
    );

    const batchResponses = await Promise.all(
      batches.map(async (batch) => {
        const data = await fetchJsonWithTimeout<{
          results?: Array<{ hits?: ZenithListeningHit[] }>;
        }>(
          'https://zenith-prod-alt.ted.com/api/search',
          {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            },
            body: JSON.stringify(
              batch.map((b) => ({ indexName: b.indexName, params: b.params }))
            ),
          },
          10_000
        );
        return { batch, results: data?.results || [] };
      })
    );

    const seen = new Set<string>();
    const preferred: ListeningVideoItem[] = [];
    const overflow: ListeningVideoItem[] = [];

    for (const { batch, results } of batchResponses) {
      results.forEach((r, idx) => {
        const topicTag = batch[idx]?.topicTag || '';
        for (const hit of r?.hits || []) {
          const safeSlug =
            typeof hit.slug === 'string' ? hit.slug.replace(/[^a-zA-Z0-9_-]/g, '') : '';
          const title = (typeof hit.title === 'string' ? hit.title : typeof hit.name === 'string' ? hit.name : '').trim();
          const parsedDur = Number(hit.duration);
          const durationSec = Number.isFinite(parsedDur) ? Math.round(parsedDur) : 0;
          if (!safeSlug || !title || durationSec < 120 || durationSec > 2400) continue;
          if (seen.has(safeSlug)) continue;
          if (/podcast|episode|trailer|teaser/i.test(safeSlug) || /podcast/i.test(title)) continue;
          seen.add(safeSlug);

          let speaker = 'TED Speaker';
          if (typeof hit.speakers === 'string' && hit.speakers.trim()) {
            speaker = hit.speakers.trim();
          } else if (Array.isArray(hit.speakers) && hit.speakers.length > 0) {
            const first = hit.speakers[0];
            if (typeof first === 'string' && first.trim()) {
              speaker = first.trim();
            } else if (first && typeof first === 'object') {
              const joined =
                first.name ||
                [first.firstname, first.lastname].filter(Boolean).join(' ').trim();
              if (joined) speaker = joined;
            }
          }

          const item: ListeningVideoItem = {
            id: String(hit.objectID || safeSlug),
            slug: safeSlug,
            title,
            speaker,
            sourceLabel: 'TED Talks',
            durationSec,
            posterUrl: extractTedPhotoUrl(hit.photos),
            band,
            topicTag,
          };

          if (durationSec >= cfg.minDurationSec && durationSec <= cfg.maxDurationSec) {
            preferred.push(item);
          } else {
            overflow.push(item);
          }
        }
      });
    }

    const openItems = (await openItemsPromise).filter((item) => {
      if (!item.slug || seen.has(item.slug)) return false;
      seen.add(item.slug);
      return true;
    });

    // Interleave TED Talks with Archive.org / VOA / Wikimedia open educational videos (2 TED : 1 Open)
    const tedPool = [...preferred, ...overflow];
    const blendedPool: ListeningVideoItem[] = [];
    let tIdx = 0;
    let oIdx = 0;
    while (tIdx < tedPool.length || oIdx < openItems.length) {
      if (tIdx < tedPool.length) blendedPool.push(tedPool[tIdx++]);
      if (tIdx < tedPool.length) blendedPool.push(tedPool[tIdx++]);
      if (oIdx < openItems.length) blendedPool.push(openItems[oIdx++]);
    }

    // Fill catalog until total duration >= requiredHours * 3600 (with small buffer so users can reach 100%)
    const selected: ListeningVideoItem[] = [];
    let totalDurationSec = 0;

    for (const item of blendedPool) {
      selected.push(item);
      totalDurationSec += item.durationSec;
      if (totalDurationSec >= targetSec + 900 && selected.length >= 24 && oIdx >= openItems.length) {
        break;
      }
    }

    return {
      band,
      requiredHours: cfg.requiredHours,
      totalDurationSec,
      videos: selected,
    };
  }

  app.get('/api/listening/catalog', rateLimitApi, async (req: Request, res: Response) => {
    try {
      const rawBand = typeof req.query.band === 'string' ? req.query.band.toUpperCase() : 'A0';
      if (!ALLOWED_LEVELS.has(rawBand)) {
        res.status(400).json({ error: 'Invalid CEFR level' });
        return;
      }
      const band = rawBand as CefrBand;
      const cached = listeningCatalogCache.get(band);
      if (cached && cached.expiresAt > Date.now()) {
        res.setHeader('Cache-Control', 'public, max-age=3600');
        res.json(cached.data);
        return;
      }

      const catalog = await buildListeningCatalogForBand(band);
      if (catalog.videos.length > 0) {
        listeningCatalogCache.set(band, {
          data: catalog,
          expiresAt: Date.now() + 12 * 60 * 60 * 1000,
        });
      }
      res.setHeader('Cache-Control', 'public, max-age=1800');
      res.json(catalog);
    } catch (err) {
      console.error('[listening/catalog] error:', err instanceof Error ? err.message : err);
      res.status(500).json({ error: 'تعذر تحميل مكتبة فيديوهات الاستماع حالياً.' });
    }
  });

  app.get('/api/listening/video', rateLimitApi, async (req: Request, res: Response) => {
    try {
      const rawSlug = typeof req.query.slug === 'string' ? req.query.slug : '';
      const slug = rawSlug.replace(/[^a-zA-Z0-9._-]/g, '').slice(0, 140);
      const rawLang = typeof req.query.lang === 'string' ? req.query.lang.toLowerCase() : 'ar';
      const lang: UiLanguageCode = VALID_UI_LANGS.has(rawLang as UiLanguageCode)
        ? (rawLang as UiLanguageCode)
        : 'ar';

      if (!slug) {
        res.status(400).json({ error: 'Video slug is required' });
        return;
      }

      const cached = listeningVideoCache.get(slug);
      let detail: ListeningVideoDetail | null =
        cached && cached.expiresAt > Date.now() ? cached.data : null;

      if (!detail && (slug.startsWith('ia__') || slug.startsWith('voa__') || slug.startsWith('wm__'))) {
        detail = await resolveOpenListeningVideoDetail(slug);
        if (!detail || !detail.videoUrl.startsWith('https://')) {
          res.status(404).json({ error: 'هذا الفيديو غير متاح للبث المباشر حالياً، جرّب فيديو آخر.' });
          return;
        }
        if (listeningVideoCache.size > 160) {
          const first = listeningVideoCache.keys().next().value;
          if (first) listeningVideoCache.delete(first);
        }
        listeningVideoCache.set(slug, {
          data: detail,
          expiresAt: Date.now() + 6 * 60 * 60 * 1000,
        });
      }

      if (!detail) {
        const gql = await fetchJsonWithTimeout<{
          data?: { video?: (TedGqlVideoNode & { playerData?: string | null }) | null };
        }>(
          'https://www.ted.com/graphql',
          {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            },
            body: JSON.stringify({
              query: `query { video(slug: "${slug}") { id slug title duration presenterDisplayName nativeDownloads { low medium high } playerData primaryImageSet { url } } }`,
            }),
          },
          10_000
        );

        const node = gql?.data?.video;
        const videoUrl = extractTedMp4Url(node, false);
        const safeId = node?.id ? String(node.id).replace(/[^0-9]/g, '') : '';

        if (!node || !safeId || !videoUrl.startsWith('https://')) {
          res.status(404).json({ error: 'هذا الفيديو غير متاح للبث المباشر، جرّب فيديو آخر.' });
          return;
        }

        const durationSec = typeof node.duration === 'number' && node.duration > 10 ? node.duration : 300;
        const posterUrl =
          node.primaryImageSet?.find(
            (img) => typeof img?.url === 'string' && img.url.startsWith('https://')
          )?.url || '';

        const enCues = await fetchTedTranslationCues(safeId, 'en', durationSec);

        detail = {
          id: safeId,
          slug: node.slug || slug,
          title: (node.title || 'English Talk').trim(),
          speaker: (node.presenterDisplayName || 'TED Speaker').trim(),
          sourceLabel: 'TED Talks',
          durationSec,
          videoUrl,
          posterUrl,
          enCues,
          translatedCues: {},
        };

        if (listeningVideoCache.size > 160) {
          const first = listeningVideoCache.keys().next().value;
          if (first) listeningVideoCache.delete(first);
        }
        listeningVideoCache.set(slug, {
          data: detail,
          expiresAt: Date.now() + 6 * 60 * 60 * 1000,
        });
      }

      if (!detail.translatedCues[lang]) {
        const trCues = await getOrTranslateListeningCaptions(
          detail.id,
          detail.enCues,
          lang,
          detail.durationSec
        );
        detail.translatedCues[lang] = trCues;
      }

      res.setHeader('Cache-Control', 'public, max-age=1800');
      res.json(detail);
    } catch (err) {
      console.error('[listening/video] error:', err instanceof Error ? err.message : err);
      res.status(500).json({ error: 'تعذر تحميل الفيديو والترجمات.' });
    }
  });

  app.get('/api/listening/captions', rateLimitApi, async (req: Request, res: Response) => {
    try {
      const videoId = String(req.query.videoId || '').replace(/[^a-zA-Z0-9._-]/g, '').slice(0, 140);
      const slug = String(req.query.slug || '').replace(/[^a-zA-Z0-9._-]/g, '').slice(0, 140);
      const rawLang = typeof req.query.lang === 'string' ? req.query.lang.toLowerCase() : 'ar';
      const lang: UiLanguageCode = VALID_UI_LANGS.has(rawLang as UiLanguageCode)
        ? (rawLang as UiLanguageCode)
        : 'ar';

      if (!videoId) {
        res.status(400).json({ error: 'videoId is required' });
        return;
      }

      let cachedVideo = slug ? listeningVideoCache.get(slug)?.data : undefined;
      if (!cachedVideo && (slug.startsWith('ia__') || slug.startsWith('voa__') || slug.startsWith('wm__'))) {
        const resolvedOpen = await resolveOpenListeningVideoDetail(slug);
        if (resolvedOpen) {
          cachedVideo = resolvedOpen;
          listeningVideoCache.set(slug, {
            data: resolvedOpen,
            expiresAt: Date.now() + 6 * 60 * 60 * 1000,
          });
        }
      }
      const durationSec = cachedVideo?.durationSec || 600;
      const enCues =
        cachedVideo?.enCues && cachedVideo.enCues.length > 0
          ? cachedVideo.enCues
          : /^\d+$/.test(videoId)
            ? await fetchTedTranslationCues(videoId, 'en', durationSec)
            : [];

      const cues = await getOrTranslateListeningCaptions(videoId, enCues, lang, durationSec);
      if (cachedVideo) {
        cachedVideo.translatedCues[lang] = cues;
      }

      res.setHeader('Cache-Control', 'public, max-age=3600');
      res.json({ videoId, lang, cues });
    } catch (err) {
      console.error('[listening/captions] error:', err instanceof Error ? err.message : err);
      res.status(500).json({ error: 'تعذر تحميل الترجمة لهذه اللغة.' });
    }
  });

  app.post('/api/listening/quiz', rateLimitApi, async (req: Request, res: Response) => {
    try {
      const body = req.body as {
        videoId?: string;
        title?: string;
        speaker?: string;
        band?: string;
        cues?: VideoCaptionCue[];
      };

      const videoId = String(body?.videoId || '').replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 80);
      const title = String(body?.title || '').trim().slice(0, 200);
      const speaker = String(body?.speaker || '').trim().slice(0, 120);
      const band = ALLOWED_LEVELS.has(String(body?.band || 'B1')) ? String(body?.band) : 'B1';
      const cues: VideoCaptionCue[] = Array.isArray(body?.cues)
        ? body.cues
            .filter(
              (c): c is VideoCaptionCue =>
                Boolean(c) && typeof c.text === 'string' && typeof c.startSec === 'number'
            )
            .slice(0, 120)
        : [];

      if (!videoId || !title) {
        res.status(400).json({ error: 'Video details required' });
        return;
      }

      const cacheKey = `${videoId}::${band}`;
      const cached = listeningQuizCache.get(cacheKey);
      if (cached && cached.expiresAt > Date.now()) {
        res.json({ questions: cached.questions });
        return;
      }

      const transcriptExcerpt = cues
        .map((c) => c.text)
        .join(' ')
        .slice(0, 4200);

      let questions: ListeningQuizQuestion[] | null = null;

      if (transcriptExcerpt.length >= 120) {
        const systemPrompt =
          'You are an expert CEFR English listening comprehension examiner. Create 5 clear, accurate, unambiguous multiple-choice questions strictly based on the provided talk transcript. Return strict JSON only.';
        const userPrompt = `Talk Title: "${title}"\nSpeaker: "${speaker}"\nTarget CEFR Level: ${band}\n\nTranscript Excerpt:\n${transcriptExcerpt}\n\nGenerate 5 English multiple-choice comprehension questions specifically testing facts, main idea, and details from this exact talk. Each question must have 4 concise options, correctIndex (0-3), and a short clear explanation.`;

        try {
          const { data } = await callGeminiStructured<{ questions: ListeningQuizQuestion[] }>({
            contents: userPrompt,
            systemInstruction: systemPrompt,
            preferLite: true,
            timeoutMs: 9_500,
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                questions: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      id: { type: Type.STRING },
                      question: { type: Type.STRING },
                      options: { type: Type.ARRAY, items: { type: Type.STRING } },
                      correctIndex: { type: Type.INTEGER },
                      explanation: { type: Type.STRING },
                    },
                    required: ['id', 'question', 'options', 'correctIndex', 'explanation'],
                  },
                },
              },
              required: ['questions'],
            },
          });
          if (Array.isArray(data?.questions) && data.questions.length >= 3) {
            questions = data.questions
              .filter(
                (q) =>
                  typeof q.question === 'string' &&
                  Array.isArray(q.options) &&
                  q.options.length === 4 &&
                  typeof q.correctIndex === 'number' &&
                  q.correctIndex >= 0 &&
                  q.correctIndex < 4
              )
              .slice(0, 5);
          }
        } catch {
          // Try OpenLLM next
        }

        if (!questions || questions.length < 3) {
          try {
            const openData = await callOpenLlmJson<{ questions?: ListeningQuizQuestion[] }>(
              systemPrompt,
              `${userPrompt}\nReturn JSON: {"questions":[{"id":"q1","question":"...","options":["A","B","C","D"],"correctIndex":0,"explanation":"..."}]}`,
              8_500
            );
            if (Array.isArray(openData?.questions) && openData.questions.length >= 3) {
              questions = openData.questions
                .filter(
                  (q) =>
                    typeof q.question === 'string' &&
                    Array.isArray(q.options) &&
                    q.options.length === 4 &&
                    typeof q.correctIndex === 'number' &&
                    q.correctIndex >= 0 &&
                    q.correctIndex < 4
                )
                .slice(0, 5);
            }
          } catch {
            // Fall back to transcript-grounded deterministic quiz
          }
        }
      }

      if (!questions || questions.length < 3) {
        questions = buildFallbackTranscriptQuiz(title, speaker, cues);
      }

      if (listeningQuizCache.size > 300) {
        const first = listeningQuizCache.keys().next().value;
        if (first) listeningQuizCache.delete(first);
      }
      listeningQuizCache.set(cacheKey, {
        questions,
        expiresAt: Date.now() + 24 * 60 * 60 * 1000,
      });

      res.json({ questions });
    } catch (err) {
      console.error('[listening/quiz] error:', err instanceof Error ? err.message : err);
      res.status(500).json({ error: 'تعذر إنشاء اختبار الفيديو حالياً.' });
    }
  });

  app.post('/api/grammar/localize', rateLimitApi, async (req: Request, res: Response) => {
    try {
      const body = req.body as {
        lessonId?: string;
        uiLang?: string;
        titleEn?: string;
        titleAr?: string;
        summaryAr?: string;
        howToUseAr?: string[];
        whenToUseAr?: string[];
        mistakeNotesAr?: string[];
        exampleNotesAr?: string[];
      };

      const lessonId = String(body?.lessonId || '').replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 80);
      const rawLang = typeof body?.uiLang === 'string' ? body.uiLang.toLowerCase() : 'ar';
      const uiLang: UiLanguageCode = VALID_UI_LANGS.has(rawLang as UiLanguageCode)
        ? (rawLang as UiLanguageCode)
        : 'ar';

      const fallbackPayload: LocalizedGrammarPayload = {
        title: String(body?.titleAr || body?.titleEn || ''),
        summary: String(body?.summaryAr || ''),
        howToUse: Array.isArray(body?.howToUseAr) ? body.howToUseAr : [],
        whenToUse: Array.isArray(body?.whenToUseAr) ? body.whenToUseAr : [],
        mistakeNotes: Array.isArray(body?.mistakeNotesAr) ? body.mistakeNotesAr : [],
        exampleNotes: Array.isArray(body?.exampleNotesAr) ? body.exampleNotesAr : [],
      };

      if (uiLang === 'ar' || !lessonId) {
        res.json(fallbackPayload);
        return;
      }

      const cacheKey = `${lessonId}::${uiLang}`;
      const cached = grammarLocalizeCache.get(cacheKey);
      if (cached && cached.expiresAt > Date.now()) {
        res.json(cached.data);
        return;
      }

      const langName = LANG_FULL_NAMES[uiLang];
      let localized: LocalizedGrammarPayload | null = null;

      try {
        const { data } = await callGeminiStructured<LocalizedGrammarPayload>({
          contents: `Translate this English grammar lesson explanation into natural, clear, pedagogical ${langName} (keep any English grammar keywords or formulas inside quotes intact).\nInput JSON:\n${JSON.stringify({
            titleEn: body.titleEn,
            title: fallbackPayload.title,
            summary: fallbackPayload.summary,
            howToUse: fallbackPayload.howToUse,
            whenToUse: fallbackPayload.whenToUse,
            mistakeNotes: fallbackPayload.mistakeNotes,
            exampleNotes: fallbackPayload.exampleNotes,
          })}`,
          systemInstruction: `You are an expert English grammar teacher writing crystal-clear explanations in ${langName}. Preserve array lengths exactly.`,
          preferLite: true,
          timeoutMs: 9_000,
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING },
              summary: { type: Type.STRING },
              howToUse: { type: Type.ARRAY, items: { type: Type.STRING } },
              whenToUse: { type: Type.ARRAY, items: { type: Type.STRING } },
              mistakeNotes: { type: Type.ARRAY, items: { type: Type.STRING } },
              exampleNotes: { type: Type.ARRAY, items: { type: Type.STRING } },
            },
            required: ['title', 'summary', 'howToUse', 'whenToUse', 'mistakeNotes', 'exampleNotes'],
          },
        });
        if (data?.title && data?.summary) {
          localized = data;
        }
      } catch {
        // Fallback to OpenLLM next
      }

      if (!localized) {
        try {
          const openLoc = await callOpenLlmJson<LocalizedGrammarPayload>(
            `You are an expert English grammar teacher writing crystal-clear explanations in ${langName}. Return strict JSON matching {"title":"...","summary":"...","howToUse":[...],"whenToUse":[...],"mistakeNotes":[...],"exampleNotes":[...]} with exact array lengths.`,
            `Translate this English grammar lesson into natural ${langName} (keep English grammar terms/examples intact):\n${JSON.stringify({
              titleEn: body.titleEn,
              title: fallbackPayload.title,
              summary: fallbackPayload.summary,
              howToUse: fallbackPayload.howToUse,
              whenToUse: fallbackPayload.whenToUse,
              mistakeNotes: fallbackPayload.mistakeNotes,
              exampleNotes: fallbackPayload.exampleNotes,
            })}`,
            9_000
          );
          if (openLoc?.title && openLoc?.summary) {
            localized = {
              title: openLoc.title,
              summary: openLoc.summary,
              howToUse: Array.isArray(openLoc.howToUse) ? openLoc.howToUse : fallbackPayload.howToUse,
              whenToUse: Array.isArray(openLoc.whenToUse)
                ? openLoc.whenToUse
                : fallbackPayload.whenToUse,
              mistakeNotes: Array.isArray(openLoc.mistakeNotes)
                ? openLoc.mistakeNotes
                : fallbackPayload.mistakeNotes,
              exampleNotes: Array.isArray(openLoc.exampleNotes)
                ? openLoc.exampleNotes
                : fallbackPayload.exampleNotes,
            };
          }
        } catch {
          // Fallback to Google GTX next
        }
      }

      if (!localized) {
        try {
          const allLines = [
            fallbackPayload.title,
            fallbackPayload.summary,
            ...fallbackPayload.howToUse,
            ...fallbackPayload.whenToUse,
            ...fallbackPayload.mistakeNotes,
            ...fallbackPayload.exampleNotes,
          ];
          const tl = GOOGLE_TL_MAP[uiLang];
          const joined = allLines.map((l) => l.replace(/\r?\n/g, ' ').trim() || '.').join('\n');
          const gUrl = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=ar&tl=${encodeURIComponent(
            tl
          )}&dt=t&q=${encodeURIComponent(joined)}`;
          const data = await fetchJsonWithTimeout<unknown[]>(
            gUrl,
            { headers: { 'User-Agent': 'Mozilla/5.0' } },
            6500
          );
          if (Array.isArray(data) && Array.isArray(data[0])) {
            const full = (data[0] as unknown[])
              .map((seg) => (Array.isArray(seg) && typeof seg[0] === 'string' ? seg[0] : ''))
              .join('');
            const parts = full.split(/\r?\n/).map((s) => s.trim());
            let cursor = 0;
            const take = (n: number, orig: string[]) => {
              const out = orig.map((o, idx) => parts[cursor + idx] || o);
              cursor += n;
              return out;
            };
            const title = parts[cursor++] || fallbackPayload.title;
            const summary = parts[cursor++] || fallbackPayload.summary;
            const howToUse = take(fallbackPayload.howToUse.length, fallbackPayload.howToUse);
            const whenToUse = take(fallbackPayload.whenToUse.length, fallbackPayload.whenToUse);
            const mistakeNotes = take(
              fallbackPayload.mistakeNotes.length,
              fallbackPayload.mistakeNotes
            );
            const exampleNotes = take(
              fallbackPayload.exampleNotes.length,
              fallbackPayload.exampleNotes
            );
            localized = { title, summary, howToUse, whenToUse, mistakeNotes, exampleNotes };
          }
        } catch {
          // Keep fallback
        }
      }

      const finalData = localized || fallbackPayload;
      if (grammarLocalizeCache.size > 500) {
        const first = grammarLocalizeCache.keys().next().value;
        if (first) grammarLocalizeCache.delete(first);
      }
      grammarLocalizeCache.set(cacheKey, {
        data: finalData,
        expiresAt: Date.now() + 7 * 24 * 60 * 60 * 1000,
      });

      res.json(finalData);
    } catch (err) {
      console.error('[grammar/localize] error:', err instanceof Error ? err.message : err);
      res.status(500).json({ error: 'Failed to localize grammar explanation.' });
    }
  });

  // ============================================================
  // Word Learning Hub — Grounded Lexicographical Profile API
  // ============================================================
  const wordHubCache = new Map<string, { data: WordHubData; expiresAt: number }>();

  interface FreeDictPhonetic {
    text?: string;
    audio?: string;
  }
  interface FreeDictDef {
    definition?: string;
    example?: string;
    synonyms?: string[];
    antonyms?: string[];
  }
  interface FreeDictMeaning {
    partOfSpeech?: string;
    definitions?: FreeDictDef[];
    synonyms?: string[];
    antonyms?: string[];
  }
  interface FreeDictEntry {
    word?: string;
    phonetic?: string;
    phonetics?: FreeDictPhonetic[];
    origin?: string;
    meanings?: FreeDictMeaning[];
  }

  const POS_AR_MAP: Record<string, { en: string; ar: string }> = {
    noun: { en: 'Noun', ar: 'اسم' },
    verb: { en: 'Verb', ar: 'فعل' },
    adjective: { en: 'Adjective', ar: 'صفة' },
    adverb: { en: 'Adverb', ar: 'ظرف' },
    pronoun: { en: 'Pronoun', ar: 'ضمير' },
    preposition: { en: 'Preposition', ar: 'حرف جر' },
    conjunction: { en: 'Conjunction', ar: 'أداة ربط' },
    interjection: { en: 'Interjection', ar: 'أداة تعجب' },
    exclamation: { en: 'Exclamation', ar: 'تعجب' },
  };

  app.post('/api/word-hub', rateLimitApi, async (req: Request, res: Response) => {
    try {
      const body = req.body as {
        word?: unknown;
        ar?: unknown;
        band?: unknown;
        uiLang?: unknown;
        skipAi?: unknown;
      };
      const rawWord = typeof body?.word === 'string' ? body.word.trim().slice(0, 80) : '';
      const rawAr = typeof body?.ar === 'string' ? body.ar.trim().slice(0, 160) : '';
      const rawBand = typeof body?.band === 'string' ? body.band.trim().slice(0, 4) : 'B1';
      const uiLang = typeof body?.uiLang === 'string' ? body.uiLang.trim().slice(0, 5) : 'ar';
      const skipAi = Boolean(body?.skipAi);

      if (!rawWord) {
        res.status(400).json({ error: 'Word is required.' });
        return;
      }

      const cacheKey = `${uiLang}:${rawWord.toLowerCase()}`;
      const hit = wordHubCache.get(cacheKey);
      if (hit && hit.expiresAt > Date.now()) {
        res.json(hit.data);
        return;
      }

      // Step 1: Ground in Free Dictionary API + Datamuse Lexical API in parallel for authentic IPA, US/UK studio MP3s, POS, definitions, and verified synonyms/antonyms/related words
      let dictPosEn = '';
      let dictPosAr = '';
      let dictIpaUs = '';
      let dictIpaUk = '';
      let dictAudioUs = '';
      let dictAudioUk = '';
      let dictOrigin = '';
      const dictDefs: Array<{ pos: string; def: string }> = [];
      const dictExamples: string[] = [];
      const dictSynonyms = new Set<string>();
      const dictAntonyms = new Set<string>();
      const dictRelated = new Set<string>();

      const lowerEncoded = encodeURIComponent(rawWord.toLowerCase());
      const [dictRes, dmSynRes, dmAntRes, dmRelRes] = await Promise.allSettled([
        fetchJsonWithTimeout<FreeDictEntry[]>(
          `https://api.dictionaryapi.dev/api/v2/entries/en/${lowerEncoded}`,
          { headers: { 'User-Agent': 'TMN-VocabHub/1.0' } },
          4000
        ),
        fetchJsonWithTimeout<Array<{ word?: string }>>(
          `https://api.datamuse.com/words?rel_syn=${lowerEncoded}&max=6`,
          { headers: { 'User-Agent': 'TMN-VocabHub/1.0' } },
          3200
        ),
        fetchJsonWithTimeout<Array<{ word?: string }>>(
          `https://api.datamuse.com/words?rel_ant=${lowerEncoded}&max=4`,
          { headers: { 'User-Agent': 'TMN-VocabHub/1.0' } },
          3200
        ),
        fetchJsonWithTimeout<Array<{ word?: string }>>(
          `https://api.datamuse.com/words?ml=${lowerEncoded}&max=6`,
          { headers: { 'User-Agent': 'TMN-VocabHub/1.0' } },
          3200
        ),
      ]);

      if (dmSynRes.status === 'fulfilled' && Array.isArray(dmSynRes.value)) {
        for (const item of dmSynRes.value) {
          if (item?.word && item.word.toLowerCase() !== rawWord.toLowerCase()) {
            dictSynonyms.add(item.word);
          }
        }
      }
      if (dmAntRes.status === 'fulfilled' && Array.isArray(dmAntRes.value)) {
        for (const item of dmAntRes.value) {
          if (item?.word && item.word.toLowerCase() !== rawWord.toLowerCase()) {
            dictAntonyms.add(item.word);
          }
        }
      }
      if (dmRelRes.status === 'fulfilled' && Array.isArray(dmRelRes.value)) {
        for (const item of dmRelRes.value) {
          const w = item?.word?.trim();
          if (w && w.toLowerCase() !== rawWord.toLowerCase() && !dictSynonyms.has(w)) {
            dictRelated.add(w);
          }
        }
      }

      if (dictRes.status === 'fulfilled' && Array.isArray(dictRes.value) && dictRes.value.length > 0) {
        const dictData = dictRes.value;
        for (const entry of dictData) {
          if (!dictOrigin && entry.origin) dictOrigin = entry.origin;
          for (const p of entry.phonetics || []) {
            const audioUrl = p.audio
              ? p.audio.startsWith('//')
                ? `https:${p.audio}`
                : p.audio
              : '';
            const txt = (p.text || '').trim();
            if (audioUrl && /-us\.mp3$/i.test(audioUrl)) {
              if (!dictAudioUs) dictAudioUs = audioUrl;
              if (!dictIpaUs && txt) dictIpaUs = txt;
            } else if (audioUrl && /-uk\.mp3$/i.test(audioUrl)) {
              if (!dictAudioUk) dictAudioUk = audioUrl;
              if (!dictIpaUk && txt) dictIpaUk = txt;
            } else if (audioUrl && !dictAudioUs) {
              dictAudioUs = audioUrl;
            }
            if (txt) {
              if (!dictIpaUs) dictIpaUs = txt;
              if (!dictIpaUk) dictIpaUk = txt;
            }
          }
          if (!dictIpaUs && entry.phonetic) dictIpaUs = entry.phonetic;
          if (!dictIpaUk && entry.phonetic) dictIpaUk = entry.phonetic;

          // Prefer the most prominent meaning (the one with the most definitions) for primary POS
          const sortedMeanings = [...(entry.meanings || [])].sort(
            (a, b) => (b.definitions?.length || 0) - (a.definitions?.length || 0)
          );
          for (const m of sortedMeanings) {
            const rawP = (m.partOfSpeech || '').toLowerCase();
            if (!dictPosEn && POS_AR_MAP[rawP]) {
              dictPosEn = POS_AR_MAP[rawP].en;
              dictPosAr = POS_AR_MAP[rawP].ar;
            }
            for (const s of m.synonyms || []) {
              if (s && s.toLowerCase() !== rawWord.toLowerCase()) dictSynonyms.add(s);
            }
            for (const a of m.antonyms || []) {
              if (a && a.toLowerCase() !== rawWord.toLowerCase()) dictAntonyms.add(a);
            }
            for (const d of m.definitions || []) {
              if (d.definition && dictDefs.length < 4) {
                dictDefs.push({ pos: POS_AR_MAP[rawP]?.en || m.partOfSpeech || '', def: d.definition });
              }
              if (d.example && dictExamples.length < 4) {
                dictExamples.push(d.example);
              }
              for (const s of d.synonyms || []) {
                if (s && s.toLowerCase() !== rawWord.toLowerCase()) dictSynonyms.add(s);
              }
              for (const a of d.antonyms || []) {
                if (a && a.toLowerCase() !== rawWord.toLowerCase()) dictAntonyms.add(a);
              }
            }
          }
        }
      }

      const groundingSummary = [
        `Build a complete Word Learning Hub profile for the English word: "${rawWord}"`,
        `Arabic meaning: "${rawAr || 'provide accurate Arabic meaning'}"`,
        `CEFR Band: ${rawBand}`,
        dictPosEn ? `Primary Part of Speech: ${dictPosEn}` : '',
        dictIpaUs ? `US IPA: ${dictIpaUs}` : '',
        dictIpaUk ? `UK IPA: ${dictIpaUk}` : '',
        dictDefs.length
          ? `Reference dictionary definitions:\n${dictDefs.map((d, i) => `${i + 1}. (${d.pos}) ${d.def}`).join('\n')}`
          : '',
        dictSynonyms.size
          ? `Reference real synonyms you may select from and enrich: ${Array.from(dictSynonyms).slice(0, 8).join(', ')}`
          : '',
        dictAntonyms.size
          ? `Reference real antonyms you may select from and enrich: ${Array.from(dictAntonyms).slice(0, 6).join(', ')}`
          : '',
        dictOrigin ? `Reference etymology: ${dictOrigin}` : '',
      ]
        .filter(Boolean)
        .join('\n');

      const systemInstruction = `You are a senior Oxford/Cambridge lexicographer building a rich, accurate Word Learning Hub for Arabic-speaking English learners.
COMPLETENESS & ACCURACY RULES:
1. USE YOUR FULL LEXICOGRAPHICAL KNOWLEDGE to populate every applicable section thoroughly:
   - "synonyms": Provide 2-4 real, natural English synonyms (never equal to the target word), each with Arabic meaning, clear Arabic nuance explaining the subtle difference in usage, plus a natural example sentence and its Arabic translation.
   - "antonyms": Whenever the word has genuine direct opposites (e.g., happy->sad/unhappy, big->small, fast->slow, accept->reject), provide 1-3 real antonyms with contrast explanation & example. ONLY return [] for words that genuinely have NO direct antonym (such as concrete physical nouns like "apple", "chair", "table", "water", "book").
   - "wordFamily": Include all genuine, standard English derivatives that truly exist (e.g. for "happy": happiness [Noun], happily [Adverb], unhappy [Adjective]; for "decide": decision [Noun], decisive [Adjective], decisively [Adverb]). Only use valid POS ("Noun", "Verb", "Adjective", "Adverb"). Never invent fake words.
   - "relatedWords": Provide 3-4 semantically related everyday English words with Arabic meaning and brief relation note.
   - "collocations": Provide 3-4 natural everyday English collocations (e.g., "happy ending", "feel happy", "peel an apple") with Arabic meaning, example sentence, and Arabic translation.
   - "examples": Provide 3-4 realistic everyday English sentences with natural Arabic translations and register ("neutral", "formal", or "informal").
   - "commonMistakes": Provide 1-2 genuine mistakes Arabic/ESL learners make with this word (wrong vs right + Arabic explanation).
   - "usageNotes": Provide 2-3 practical tips for using the word naturally.
   - "formalVsInformal": Always provide registerLabel ("Neutral", "Formal", or "Informal"), registerLabelAr, noteAr, and real formalAlt/informalAlt when applicable.
   - "idioms" & "phrasalVerbs": Include real, widely-used idioms or phrasal verbs containing the word when they genuinely exist; otherwise return [].
   - "wordOrigin": Brief accurate historical origin in Arabic (or "" if uncertain).
   - "memoryTip": A memorable, practical Arabic mnemonic tip to remember the word.
2. All explanations, nuances, Arabic translations, usage notes, wordOrigin, and memoryTip MUST be in clear, natural Arabic. Output ONLY valid JSON.`;

      let aiData: Partial<WordHubData> | null = null;
      const nowMs = Date.now();
      const anyGeminiAvailable =
        !skipAi &&
        Boolean(getAiClient()) &&
        (nowMs >= (geminiModelCooldownUntil.get(GEMINI_LITE_MODEL) || 0) ||
          nowMs >= (geminiModelCooldownUntil.get(GEMINI_MAIN_MODEL) || 0));

      if (anyGeminiAvailable) {
        try {
          const resGemini = await callGeminiStructured<Partial<WordHubData>>({
            systemInstruction,
            contents: groundingSummary,
            timeoutMs: 11_000,
            preferLite: true,
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                posEn: { type: Type.STRING },
                posAr: { type: Type.STRING },
                ipaUs: { type: Type.STRING },
                ipaUk: { type: Type.STRING },
                definitionEn: { type: Type.STRING },
                definitionAr: { type: Type.STRING },
                secondaryMeanings: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      posEn: { type: Type.STRING },
                      definitionEn: { type: Type.STRING },
                      ar: { type: Type.STRING },
                    },
                    required: ['posEn', 'definitionEn', 'ar'],
                  },
                },
                synonyms: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      word: { type: Type.STRING },
                      ar: { type: Type.STRING },
                      nuanceAr: { type: Type.STRING },
                      exampleEn: { type: Type.STRING },
                      exampleAr: { type: Type.STRING },
                    },
                    required: ['word', 'ar', 'nuanceAr', 'exampleEn', 'exampleAr'],
                  },
                },
                antonyms: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      word: { type: Type.STRING },
                      ar: { type: Type.STRING },
                      contrastAr: { type: Type.STRING },
                      exampleEn: { type: Type.STRING },
                      exampleAr: { type: Type.STRING },
                    },
                    required: ['word', 'ar', 'contrastAr', 'exampleEn', 'exampleAr'],
                  },
                },
                wordFamily: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      word: { type: Type.STRING },
                      pos: { type: Type.STRING },
                      posAr: { type: Type.STRING },
                      ar: { type: Type.STRING },
                      exampleEn: { type: Type.STRING },
                    },
                    required: ['word', 'pos', 'posAr', 'ar', 'exampleEn'],
                  },
                },
                relatedWords: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      word: { type: Type.STRING },
                      ar: { type: Type.STRING },
                      relationAr: { type: Type.STRING },
                    },
                    required: ['word', 'ar', 'relationAr'],
                  },
                },
                collocations: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      phrase: { type: Type.STRING },
                      ar: { type: Type.STRING },
                      exampleEn: { type: Type.STRING },
                      exampleAr: { type: Type.STRING },
                    },
                    required: ['phrase', 'ar', 'exampleEn', 'exampleAr'],
                  },
                },
                examples: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      en: { type: Type.STRING },
                      ar: { type: Type.STRING },
                      register: { type: Type.STRING },
                    },
                    required: ['en', 'ar'],
                  },
                },
                commonMistakes: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      wrong: { type: Type.STRING },
                      right: { type: Type.STRING },
                      noteAr: { type: Type.STRING },
                    },
                    required: ['wrong', 'right', 'noteAr'],
                  },
                },
                usageNotes: {
                  type: Type.ARRAY,
                  items: { type: Type.STRING },
                },
                formalVsInformal: {
                  type: Type.OBJECT,
                  properties: {
                    registerLabel: { type: Type.STRING },
                    registerLabelAr: { type: Type.STRING },
                    noteAr: { type: Type.STRING },
                    formalAlt: { type: Type.STRING },
                    informalAlt: { type: Type.STRING },
                  },
                  required: ['registerLabel', 'registerLabelAr', 'noteAr'],
                },
                idioms: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      phrase: { type: Type.STRING },
                      ar: { type: Type.STRING },
                      exampleEn: { type: Type.STRING },
                    },
                    required: ['phrase', 'ar', 'exampleEn'],
                  },
                },
                phrasalVerbs: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      phrase: { type: Type.STRING },
                      ar: { type: Type.STRING },
                      exampleEn: { type: Type.STRING },
                    },
                    required: ['phrase', 'ar', 'exampleEn'],
                  },
                },
                wordOrigin: { type: Type.STRING },
                memoryTip: { type: Type.STRING },
              },
              required: [
                'posEn',
                'posAr',
                'definitionEn',
                'definitionAr',
                'synonyms',
                'antonyms',
                'wordFamily',
                'relatedWords',
                'collocations',
                'examples',
                'commonMistakes',
                'usageNotes',
                'idioms',
                'phrasalVerbs',
                'wordOrigin',
                'memoryTip',
              ],
            },
          });
          aiData = resGemini.data;
        } catch {
          // Graceful fallback to authentic Free Dictionary + Datamuse grounding below
        }
      }

      if (!skipAi && !aiData && dictDefs.length === 0 && Date.now() >= openLlmCooldownUntil) {
        try {
          aiData = await callOpenLlmJson<Partial<WordHubData>>(
            systemInstruction,
            `${groundingSummary}\nReturn valid JSON with keys: posEn, posAr, ipaUs, ipaUk, definitionEn, definitionAr, secondaryMeanings, synonyms, antonyms, wordFamily, relatedWords, collocations, examples, commonMistakes, usageNotes, formalVsInformal, idioms, phrasalVerbs, wordOrigin, memoryTip.`,
            6_000
          );
        } catch {
          // OpenLLM circuit breaker tripped; fall back cleanly to dictionary grounding
        }
      }

      // Merge authentic Free Dictionary & Datamuse grounding with AI enrichment
      const mergedRaw: Partial<WordHubData> = {
        ...(aiData || {}),
        word: rawWord,
        posEn: aiData?.posEn || dictPosEn,
        posAr: aiData?.posAr || dictPosAr,
        ipaUs: dictIpaUs || aiData?.ipaUs || '',
        ipaUk: dictIpaUk || aiData?.ipaUk || dictIpaUs || '',
        audioUs: dictAudioUs || undefined,
        audioUk: dictAudioUk || undefined,
        definitionEn: aiData?.definitionEn || dictDefs[0]?.def || '',
        definitionAr: aiData?.definitionAr || rawAr,
        secondaryMeanings:
          aiData?.secondaryMeanings && aiData.secondaryMeanings.length > 0
            ? aiData.secondaryMeanings
            : dictDefs.slice(1, 3).map((d) => ({
                posEn: d.pos || dictPosEn,
                definitionEn: d.def,
                ar: rawAr || d.def,
              })),
        synonyms:
          aiData?.synonyms && aiData.synonyms.length > 0
            ? aiData.synonyms
            : Array.from(dictSynonyms)
                .slice(0, 4)
                .map((s) => ({
                  word: s,
                  ar: rawAr || s,
                  nuanceAr: '',
                  exampleEn: '',
                  exampleAr: '',
                })),
        antonyms:
          aiData?.antonyms && aiData.antonyms.length > 0
            ? aiData.antonyms
            : Array.from(dictAntonyms)
                .slice(0, 3)
                .map((a) => ({
                  word: a,
                  ar: `ضد ${rawAr || rawWord}`,
                  contrastAr: '',
                  exampleEn: '',
                  exampleAr: '',
                })),
        relatedWords:
          aiData?.relatedWords && aiData.relatedWords.length > 0
            ? aiData.relatedWords
            : Array.from(dictRelated)
                .slice(0, 4)
                .map((r) => ({
                  word: r,
                  ar: r,
                  relationAr: '',
                })),
        examples:
          aiData?.examples && aiData.examples.length > 0
            ? aiData.examples
            : dictExamples.map((e) => ({ en: e, ar: '', register: 'neutral' as const })),
        wordOrigin: aiData?.wordOrigin || dictOrigin || '',
        source: aiData ? 'dictionary+ai' : dictDefs.length > 0 ? 'dictionary' : 'offline',
      };

      const sanitized = sanitizeWordHubData(mergedRaw, rawWord, rawAr);

      if (wordHubCache.size > 600) {
        const oldest = wordHubCache.keys().next().value;
        if (oldest) wordHubCache.delete(oldest);
      }
      // Cache full AI-enriched results for 24h; cache dictionary-grounded results for 10m to avoid repeated quota retries
      wordHubCache.set(cacheKey, {
        data: sanitized,
        expiresAt: Date.now() + (aiData ? 24 * 60 * 60 * 1000 : 10 * 60 * 1000),
      });

      res.json(sanitized);
    } catch (err) {
      console.error('[word-hub] error:', err instanceof Error ? err.message : err);
      res.status(500).json({ error: 'Failed to load word learning hub.' });
    }
  });

  // Cached same-origin dictionary proxy (eliminates browser CORS / 404 console errors on api.dictionaryapi.dev)
  const dictProxyCache = new Map<string, { entries: unknown[]; expiresAt: number }>();
  app.get('/api/dictionary', async (req: Request, res: Response) => {
    const rawWord = typeof req.query.word === 'string' ? req.query.word.trim().toLowerCase() : '';
    if (!rawWord || rawWord.length > 64 || !/^[a-z0-9'\-\s]+$/i.test(rawWord)) {
      res.json([]);
      return;
    }
    const cached = dictProxyCache.get(rawWord);
    if (cached && cached.expiresAt > Date.now()) {
      res.setHeader('Cache-Control', 'public, max-age=86400');
      res.json(cached.entries);
      return;
    }
    try {
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), 4500);
      const upstream = await fetch(
        `https://api.dictionaryapi.dev/api/v2/entries/en/${encodeURIComponent(rawWord)}`,
        {
          signal: controller.signal,
          headers: { Accept: 'application/json', 'User-Agent': 'TMN-English-App/1.0' },
        }
      );
      clearTimeout(timer);
      const entries = upstream.ok ? ((await upstream.json()) as unknown[]) : [];
      const safeEntries = Array.isArray(entries) ? entries : [];
      if (dictProxyCache.size >= 4000) {
        const oldest = dictProxyCache.keys().next().value;
        if (oldest) dictProxyCache.delete(oldest);
      }
      dictProxyCache.set(rawWord, {
        entries: safeEntries,
        expiresAt: Date.now() + (safeEntries.length ? 24 * 60 * 60 * 1000 : 60 * 60 * 1000),
      });
      res.setHeader('Cache-Control', 'public, max-age=86400');
      res.json(safeEntries);
    } catch {
      res.json([]);
    }
  });

  return app;
}

let cachedApiApp: express.Express | null = null;
export function getApiApp(): express.Express {
  if (!cachedApiApp) {
    cachedApiApp = createApiApp();
  }
  return cachedApiApp;
}

async function startServer() {
  const app = getApiApp();

  // Mount Vite dev middleware in development, or serve static dist/ in production
  const mountStaticDist = () => {
    const distDir = path.resolve(__dirname, 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  };

  if (process.env.NODE_ENV !== 'production') {
    try {
      const vitePkg = 'vite';
      const { createServer: createViteServer } = await import(vitePkg);
      const vite = await createViteServer({
        server: {
          middlewareMode: true,
          hmr: false,
        },
        appType: 'spa',
      });
      // Serve a lightweight zero-WebSocket /@vite/client shim while HMR is disabled
      // so CSS injection (updateStyle/removeStyle) works with zero WebSocket errors.
      app.get('/@vite/client', (_req: Request, res: Response) => {
        res.setHeader('Content-Type', 'application/javascript; charset=utf-8');
        res.setHeader('Cache-Control', 'no-store');
        res.send(`
const sheetsMap = new Map();
export function updateStyle(id, content) {
  let style = sheetsMap.get(id);
  if (!style) {
    style = document.createElement('style');
    style.setAttribute('type', 'text/css');
    style.setAttribute('data-vite-dev-id', id);
    document.head.appendChild(style);
    sheetsMap.set(id, style);
  }
  style.textContent = content;
}
export function removeStyle(id) {
  const style = sheetsMap.get(id);
  if (style) {
    document.head.removeChild(style);
    sheetsMap.delete(id);
  }
}
export function createHotContext() {
  const noop = () => {};
  return {
    data: {},
    accept: noop,
    acceptExports: noop,
    dispose: noop,
    prune: noop,
    invalidate: noop,
    on: noop,
    off: noop,
    send: noop,
    decline: noop,
  };
}
export function injectQuery(url) {
  return url;
}
export class ErrorOverlay extends HTMLElement {}
`);
      });
      app.use(vite.middlewares);
    } catch {
      mountStaticDist();
    }
  } else {
    mountStaticDist();
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server listening on http://0.0.0.0:${PORT}`);
  });
}

if (process.env.VERCEL !== '1' && process.env.TMN_NO_LISTEN !== '1') {
  void startServer();
}

