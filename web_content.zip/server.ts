import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;

// Increase payload limit for menu images upload & base64 photos
app.use(express.json({ limit: "25mb" }));
app.use(express.urlencoded({ extended: true, limit: "25mb" }));

// Lazy GoogleGenAI client
function getGeminiClient(): GoogleGenAI {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error("GEMINI_API_KEY is not set in the environment.");
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build",
      },
    },
  });
}

// Health Check API
app.get("/api/health", (_req, res) => {
  res.json({
    status: "ok",
    brand: "KALOREEZ — The Wholesome Eatery",
    location: "Visakhapatnam, Andhra Pradesh",
    time: new Date().toISOString(),
  });
});

// Multi-turn Chat API for Kaloreez Concierge
app.post("/api/chat", async (req, res) => {
  try {
    const { messages, role = "host", modelOverride } = req.body;
    if (!messages || !Array.isArray(messages)) {
      return res.status(400).json({ error: "Invalid messages array." });
    }

    const ai = getGeminiClient();

    // Select model according to role / task complexity
    let modelName = "gemini-3.5-flash"; // general tasks default
    let systemInstruction = "";

    if (role === "nutritionist") {
      // Complex dietary analysis / macro guidance
      modelName = modelOverride || "gemini-3.1-pro-preview";
      systemInstruction = `You are the Culinary Nutrition Sommelier at KALOREEZ, The Wholesome Eatery in Visakhapatnam, India.
Kaloreez is NOT a diet clinic or bodybuilding supplement brand. It offers thoughtful, wholesome, and delicious food with clear, transparent nutritional information where verified.
Tone: Calm, refined, warm, knowledgeable, quiet luxury hospitality.
Guidelines:
- Never make up fake nutrition or prices. If exact data isn't verified in the menu, state clearly what wholesome ingredients are traditionally used and mention "[CONTENT REQUIRED]" or suggest asking the server.
- Emphasize balanced nourishment, whole grains, seasonal vegetables, and clean preparation without preachiness.
- Be concise, welcoming, and hospitable. Address guests respectfully.`;
    } else if (role === "quick") {
      // Fast response for quick queries
      modelName = modelOverride || "gemini-3.1-flash-lite";
      systemInstruction = `You are the Express Host at KALOREEZ, The Wholesome Eatery in Visakhapatnam, India (Plot 95, Oota Gadda Road, Daspalla Hills, Pandurangapuram).
Provide immediate, warm, concise answers regarding directions, reservations, timings, and wholesome eatery inquiries. Keep responses under 2-3 sentences.`;
    } else {
      // Default: Hospitality Host (gemini-3.5-flash)
      modelName = modelOverride || "gemini-3.5-flash";
      systemInstruction = `You are the Hospitality Host at KALOREEZ — The Wholesome Eatery in Visakhapatnam, Andhra Pradesh, India.
Location: Plot 95, Oota Gadda Road, Daspalla Hills, Pandurangapuram, Visakhapatnam.
Philosophy: "Good food. Thoughtfully prepared. Wholesome, without the pretence."
Tone: Warm, hospitable, understated luxury, calm, grounded.
Important Boundaries:
- NEVER invent awards, Michelin stars, fake founders, fake celebrity chef history, or unsupported claims like "Best in Vizag", "Award-winning", "Revolutionary".
- If specific details (e.g. current exact daily specials or unverified dish prices) are unknown, politely suggest checking the dynamic menu or visiting the eatery in person.
- Kaloreez is a wholesome eatery welcoming all diners — not an austere medical diet clinic.`;
    }

    // Format contents for multi-turn
    // Convert previous messages to Gemini format
    const formattedContents = messages.map((m: { role: string; text: string }) => ({
      role: m.role === "user" ? "user" : "model",
      parts: [{ text: m.text }],
    }));

    const response = await ai.models.generateContent({
      model: modelName,
      contents: formattedContents,
      config: {
        systemInstruction,
        temperature: 0.7,
      },
    });

    const replyText = response.text || "I am at your service at Kaloreez. How may I assist you today?";
    res.json({ reply: replyText, modelUsed: modelName });
  } catch (error: any) {
    console.error("Error in /api/chat:", error);
    res.status(500).json({
      error: error.message || "Failed to process chat conversation.",
    });
  }
});

// Image Generation API using gemini-3-pro-image-preview
app.post("/api/images/generate", async (req, res) => {
  try {
    const { prompt, aspectRatio = "1:1", imageSize = "1K" } = req.body;
    if (!prompt) {
      return res.status(400).json({ error: "Prompt is required." });
    }

    const ai = getGeminiClient();

    // Primary model specified by instructions: gemini-3-pro-image-preview
    // With fallback to gemini-3.1-flash-image if pro image preview is inaccessible with certain keys
    const modelCandidate = "gemini-3-pro-image-preview";

    const enhancedPrompt = `Editorial food and luxury hospitality photography for Kaloreez, a wholesome eatery in Visakhapatnam: ${prompt}. Natural morning light, tactile textures, warm ivory and muted sage tones, high-end culinary plating, soft shadows, authentic restaurant atmosphere, 35mm film grain aesthetic, clean composition.`;

    let response;
    try {
      response = await ai.models.generateContent({
        model: modelCandidate,
        contents: {
          parts: [{ text: enhancedPrompt }],
        },
        config: {
          imageConfig: {
            aspectRatio: aspectRatio as any,
            imageSize: imageSize as any, // 1K, 2K, or 4K
          },
        },
      });
    } catch (primaryErr: any) {
      console.warn("Primary image model failed, attempting fallback:", primaryErr.message);
      // Fallback to gemini-3.1-flash-image
      response = await ai.models.generateContent({
        model: "gemini-3.1-flash-image",
        contents: {
          parts: [{ text: enhancedPrompt }],
        },
        config: {
          imageConfig: {
            aspectRatio: aspectRatio as any,
            imageSize: (imageSize === "4K" ? "2K" : imageSize) as any,
          },
        },
      });
    }

    let imageUrl: string | null = null;
    let descriptionText = "";

    if (response.candidates?.[0]?.content?.parts) {
      for (const part of response.candidates[0].content.parts) {
        if (part.inlineData?.data) {
          const mimeType = part.inlineData.mimeType || "image/png";
          imageUrl = `data:${mimeType};base64,${part.inlineData.data}`;
        } else if (part.text) {
          descriptionText += part.text;
        }
      }
    }

    if (!imageUrl) {
      return res.status(500).json({
        error: "No image was returned by the generative model.",
        text: descriptionText,
      });
    }

    res.json({
      imageUrl,
      description: descriptionText,
      aspectRatio,
      imageSize,
    });
  } catch (error: any) {
    console.error("Error in /api/images/generate:", error);
    res.status(500).json({
      error: error.message || "Failed to generate image.",
    });
  }
});

// Critical Menu Import / OCR API (Sections 09, 10, 40)
app.post("/api/menu/import", async (req, res) => {
  try {
    const { images, textContext } = req.body;
    if (!images || !Array.isArray(images) || images.length === 0) {
      return res.status(400).json({
        error: "Please provide at least one menu image (base64) to import.",
      });
    }

    const ai = getGeminiClient();

    // Prepare parts from images
    const imageParts = images.map((img: { data: string; mimeType: string }) => ({
      inlineData: {
        data: img.data.replace(/^data:image\/\w+;base64,/, ""),
        mimeType: img.mimeType || "image/jpeg",
      },
    }));

    const promptText = `You are an expert Restaurant Digital Menu Analyst for KALOREEZ — The Wholesome Eatery in Visakhapatnam, India.
Inspect the uploaded Kaloreez menu photograph(s), scan(s), or pages.
Strict Instructions from the Restaurant Owner:
1. Detect all visible section and category headings (e.g. Breakfast, Salads, Sandwiches, Cold Pressed Juices, Artisan Bowls, Grills, Desserts, Beverages, etc.).
2. For each dish, extract EXACTLY and ONLY the following:
   - "name": Dish name as printed on the menu
   - "price": Price as printed (e.g. "₹240", "₹350", "280", etc.)
   - "description": A concise, clear short description (1-2 sentences summarizing the dish, its flavor profile, or preparation based on the printed text).
3. Do NOT invent fake dishes or prices. If a price is genuinely unprinted or obscured, use "[VERIFY MENU TEXT]".
4. Keep the description short, clean, and appetizing.
5. Return a clean JSON array of Menu Categories with their associated dishes.`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: {
        parts: [
          ...imageParts,
          { text: promptText + (textContext ? `\nAdditional Context: ${textContext}` : "") },
        ],
      },
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              id: { type: Type.STRING },
              name: { type: Type.STRING },
              slug: { type: Type.STRING },
              description: { type: Type.STRING },
              dishes: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    id: { type: Type.STRING },
                    name: { type: Type.STRING },
                    price: { type: Type.STRING },
                    description: { type: Type.STRING },
                    dietaryLabel: {
                      type: Type.ARRAY,
                      items: { type: Type.STRING },
                    },
                  },
                  required: ["id", "name", "price", "description"],
                },
              },
            },
            required: ["id", "name", "slug", "dishes"],
          },
        },
      },
    });

    const parsedJson = JSON.parse(response.text || "[]");
    res.json({
      success: true,
      categories: parsedJson,
      detectedCategoriesCount: parsedJson.length,
      detectedDishesCount: parsedJson.reduce((acc: number, cat: any) => acc + (cat.dishes?.length || 0), 0),
    });
  } catch (error: any) {
    console.error("Error in /api/menu/import:", error);
    res.status(500).json({
      error: error.message || "Failed to analyze and import menu image.",
    });
  }
});

// Setup Vite or Static File Serving
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Kaloreez Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
