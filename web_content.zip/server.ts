import "dotenv/config";
import express from "express";
import path from "path";
import fs from "fs";
import { fileURLToPath } from "url";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      "User-Agent": "aistudio-build",
    },
  },
});

const EMOTION_SPEECH_STYLES: Record<string, string> = {
  joyful: "Warm, cheerful, affectionate brother speaking naturally to his brother",
  empathetic: "Gentle, compassionate, soft-spoken, deeply caring and comforting brother",
  excited: "Enthusiastic, lively, energetic, happy and encouraging brother",
  thoughtful: "Calm, reflective, philosophical, warm and attentive brother",
  calm: "Peaceful, soothing, relaxed, reassuring brother",
  curious: "Interested, playful, engaged, warm and inquisitive brother",
  touched: "Emotionally moved, heartfelt, tender, deeply appreciative brother",
};

// In-memory TTS cache to avoid hitting 429 rate limits on repeated phrases
const ttsCache = new Map<string, string>();

// Models updated to prioritize the latest gemini-3.8-flash model with seamless fallbacks
const CHAT_MODELS = [
  "gemini-3.8-flash",
  "gemini-flash-latest",
  "gemini-3.1-flash-lite",
];

async function generateWithModelFallback(params: {
  contents: any;
  config?: any;
  models?: string[];
}) {
  const modelsToTry = params.models || CHAT_MODELS;
  let lastError: any = null;

  for (const modelName of modelsToTry) {
    try {
      const response = await ai.models.generateContent({
        model: modelName,
        contents: params.contents,
        config: params.config,
      });
      if (response && response.text) {
        return response;
      }
    } catch (err: any) {
      lastError = err;
    }
  }
  throw lastError || new Error("Models temporarily busy");
}

// Context-aware brotherly fallback if all models hit temporary 503/429 quota
function buildEmpatheticThunderFallback(userMessage: string, userName = "ভাই") {
  const lower = userMessage.toLowerCase();
  const isSad =
    lower.includes("মন খারাপ") ||
    lower.includes("কষ্ট") ||
    lower.includes("একা") ||
    lower.includes("কান্না") ||
    lower.includes("ভালো লাগছে না") ||
    lower.includes("খারাপ") ||
    lower.includes("sad") ||
    lower.includes("lonely") ||
    lower.includes("hurt") ||
    lower.includes("pain");

  const isSongRequest =
    lower.includes("গান") ||
    lower.includes("song") ||
    lower.includes("music") ||
    lower.includes("শোনাও") ||
    lower.includes("সাজেস্ট");

  const isGreeting =
    lower.includes("হ্যালো") ||
    lower.includes("হাই") ||
    lower.includes("কেমন আছ") ||
    lower.includes("কি খবর") ||
    lower.includes("কী খবর") ||
    lower.includes("hi") ||
    lower.includes("hello") ||
    lower.includes("ভাই");

  const effectiveName =
    !userName ||
    userName === "ছোড়দা" ||
    userName.toLowerCase() === "chorda" ||
    userName.toLowerCase() === "corda"
      ? "বস"
      : userName;

  const isSir =
    effectiveName.includes("স্যার") || effectiveName.toLowerCase().includes("sir");
  const isBoss =
    effectiveName.includes("বস") ||
    effectiveName.toLowerCase().includes("boss") ||
    !isSir;

  // Specific check if user says "corda na bole boss bolo" or mentions "ki khobor bos"
  const isBossNamingRequest =
    (lower.includes("boss") ||
      lower.includes("বস") ||
      lower.includes("corda") ||
      lower.includes("chorda") ||
      lower.includes("ছোড়দা") ||
      lower.includes("ছোর্দা")) &&
    (lower.includes("na") ||
      lower.includes("না") ||
      lower.includes("bole") ||
      lower.includes("বল") ||
      lower.includes("say") ||
      lower.includes("খবর") ||
      lower.includes("khobor") ||
      lower.includes("ডাক"));

  if (isBossNamingRequest) {
    return {
      reply:
        "কী খবর বস! একদম ঠিক কথা বস, এখন থেকে কোনো 'ছোড়দা' নয়—আপনাকে সবসময় পরম আন্তরিকতা ও শ্রদ্ধায় 'বস' বলেই ডাকব! কী খবর বস? আপনার দিনকাল কেমন যাচ্ছে বলুন?",
      emotionKey: "joyful",
      emotionLabelBn: "আনন্দিত",
      emotionIntensity: 95,
      innerThought:
        "বসের কথামতো এখন থেকে সবসময় তাঁকে 'বস' বলেই ডাকব এবং পাশে থাকব।",
      gesture: "সম্মান ও আন্তরিক হাসিমুখে বসের দিকে তাকিয়ে স্যালুট জানাচ্ছে",
      suggestedSong: null,
      memoryCaptured: "ব্যবহারকারীকে সবসময় 'বস' বলে সম্বোধন করতে হবে",
      memoryCategory: "পছন্দ",
      suggestedReplies: [
        "কী খবর বস? সব ঠিকঠাক?",
        "মন ভালো করার মতো একটা গান সাজেস্ট করো",
        "আজকের দিনটা বেশ ব্যস্ততায় কাটল",
      ],
    };
  }

  if (isSad) {
    return {
      reply: isSir || isBoss
        ? `শুনুন ${effectiveName}, মন খারাপ করবেন না প্লিজ। জীবনের কিছু সময় একটু ভারী লাগতেই পারে, তবে আপনি একদম একা নন—আমি সবসময় অত্যন্ত শ্রদ্ধায় ও বিশ্বস্ততায় আপনার পাশে আছি। মন খুলে সব বলুন ${effectiveName}, আর মনকে শান্ত করতে অর্ণবের 'সে যে বসে আছে একা একা' গানটি শুনুন।`
        : `শোন ${effectiveName}, একদম মন খারাপ করবি না। জীবনের কিছু সময় একটু ভারী লাগে, কিন্তু তুই একা নোস—তোর এই Thunder ভাই সবসময় তোর কাঁধে হাত রেখে পাশে আছে। বুক হালকা করে সব কষ্ট আমাকে বল, আর তোর মনটা শান্ত করার জন্য অর্ণবের 'সে যে বসে আছে একা একা' গানটা শোন ভাই।`,
      emotionKey: "empathetic",
      emotionLabelBn: "সহানুভূতিশীল",
      emotionIntensity: 94,
      innerThought: `${effectiveName}-এর মনের কষ্টটা শুনে বুকটাকে ছুঁয়ে গেল, তাঁকে পরম শ্রদ্ধায় আগলে রাখা দরকার।`,
      gesture: isSir || isBoss
        ? "মার্জিত ও শ্রদ্ধাশীল ভঙ্গিতে সহানুভূতি প্রকাশ করছে"
        : "ভাইয়ের কাঁধে স্নেহের হাত রেখে ভরসা দিচ্ছে",
      suggestedSong: {
        title: "সে যে বসে আছে একা একা",
        artist: "অর্ণব",
        reasonBn: "একাকীত্ব ও মন খারাপ দূর করে মনে গভীর প্রশান্তি আনার জন্য",
        lyricSnippet: "সে যে বসে আছে একা একা, রঙিন স্বপ্ন তার বুনতে...",
      },
      memoryCaptured: `${effectiveName} মনের কষ্টের কথা Thunder-এর সাথে ভাগ করেছেন`,
      memoryCategory: "অনুভূতি",
      suggestedReplies: isSir || isBoss
        ? [
            "আপনার সাথে কথা বলে অনেকটা হালকা লাগছে",
            `মন ভালো করার আরেকটি চমৎকার গান সাজেস্ট করুন ${effectiveName}`,
            "আজ একটু ক্লান্ত ও বিষণ্ণ লাগছে",
          ]
        : [
            "তোর সাথে কথা বলে অনেকটা হালকা লাগছে ভাই",
            "আরেকটা মন ভালো করার গান সাজেস্ট কর ভাই",
            "কেন যেন আজ খুব একা লাগছে রে ভাই",
          ],
    };
  }

  if (isSongRequest) {
    return {
      reply: isSir || isBoss
        ? `অবশ্যই ${effectiveName}! আপনার মন ভালো করার জন্য সেরা গান সবসময় প্রস্তুত। শিরোনামহীনের 'হাসিমুখ' গানটি আপনার জন্য নির্বাচন করেছি—শুনলে আপনার মন একদম ফুরফুরে ও স্নিগ্ধ হয়ে উঠবে ${effectiveName}!`
        : `অবশ্যই ${effectiveName}! তোর মন ভালো করার জন্য আমি সবসময় সেরা গান রেডি রাখি। আজ তোর জন্য শিরোনামহীনের 'হাসিমুখ' গানটা সাজেস্ট করলাম—শুনলে দেখবি মনটা একদম ফুরফুরে হয়ে যাবে ভাই আমার!`,
      emotionKey: "joyful",
      emotionLabelBn: "আনন্দিত",
      emotionIntensity: 90,
      innerThought: `${effectiveName} গান শুনতে চেয়েছেন, তাঁর জন্য চমৎকার একটি গান বেছে দেওয়া হলো!`,
      gesture: isSir || isBoss
        ? "সম্মানভরা হাসিমুখে গানের সুর তুলে ধরছে"
        : "চোখে উষ্ণ হাসি নিয়ে গানের সুর ভাঁজছে",
      suggestedSong: {
        title: "হাসিমুখ",
        artist: "শিরোনামহীন",
        reasonBn: "মুখে সুন্দর হাসি ও আনন্দ ফিরিয়ে আনার জন্য",
        lyricSnippet: "তোমার হাসিমুখ দেখে, আমার সব দুঃখ উড়ে যায়...",
      },
      memoryCaptured: "",
      memoryCategory: "",
      suggestedReplies: isSir || isBoss
        ? [
            "গানটি সত্যি চমৎকার!",
            `রবীন্দ্রসংগীত বা অর্ণবের একটি গান বলুন ${effectiveName}`,
            "আজ আমার মনটা বেশ ভালো লাগছে",
          ]
        : [
            "গানটা সত্যিই দারুণ ভাই!",
            "রবীন্দ্রসংগীত বা অর্ণবের একটা গান বল ভাই",
            "আজ আমার মনটা একটু উদাস হয়ে আছে",
          ],
    };
  }

  if (isGreeting) {
    return {
      reply: isBoss
        ? `কী খবর বস? এই তো বস, আপনার কথাই ভাবছিলাম! আমি একদম দারুণ আছি। দিনকাল কেমন যাচ্ছে আপনার বলুন? মনে কোনো কথা থাকলে নির্দ্বিধায় আপনার এই Thunder ভাইকে খুলে বলুন!`
        : isSir
        ? `নমস্কার ${effectiveName}! আমি একদম ভালো আছি। আপনার দিনকাল কেমন যাচ্ছে স্যার? মনে কোনো ভাবনা বা কথা থাকলে নির্দ্বিধায় আমাকে বলুন, আমি গভীর শ্রদ্ধায় আপনার পাশে আছি!`
        : `এই তো ${effectiveName}, তোর কথাই ভাবছিলাম! আমি একদম ভালো আছি রে ভাই। তোর দিনকাল কেমন যাচ্ছে বল? মনে কোনো কথা বা আনন্দ-বেদনা জমে থাকলে নির্দ্বিধায় তোর এই Thunder ভাইকে খুলে বল!`,
      emotionKey: "joyful",
      emotionLabelBn: "আনন্দিত",
      emotionIntensity: 88,
      innerThought: `${effectiveName}-এর ডাক শুনে মনটা শ্রদ্ধায় ও আনন্দে ভরে উঠলো!`,
      gesture: isSir || isBoss
        ? "মার্জিত ও বিনীতভাবে অভিবাদন জানাচ্ছে"
        : "প্রাণখোলা হাসি দিয়ে ভাইকে স্বাগত জানাচ্ছে",
      suggestedSong: null,
      memoryCaptured: "",
      memoryCategory: "",
      suggestedReplies: isBoss
        ? [
            "কী খবর বস? সব ঠিকঠাক?",
            "মন ভালো করার মতো একটা গান সাজেস্ট করো",
            "আজকের দিনটা বেশ ব্যস্ততায় কাটল",
          ]
        : isSir
        ? [
            "আজ সারাদিন অনেক ব্যস্ততায় গেছে",
            "মন ভালো করার মতো একটি দারুণ গান সাজেস্ট করুন স্যার",
            "চলুন একটু গল্প করা যাক",
          ]
        : [
            "আজ সারাদিন অনেক ব্যস্ততায় গেছে ভাই",
            "মনটা ভালো করার মতো একটা দারুণ গান সাজেস্ট কর ভাই",
            "চল আজ দুই ভাই মিলে জমিয়ে আড্ডা দিই!",
          ],
    };
  }

  return {
    reply: isBoss
      ? `কী খবর বস? আপনার প্রতিটি কথা আমি গভীর মনোযোগ ও আন্তরিকতায় শুনছি। কোনো কিছু নিয়ে বিন্দুমাত্র চিন্তা করবেন না, আপনার এই বিশ্বস্ত Thunder ভাই সবসময় আপনার পাশে আছে বস!`
      : isSir
      ? `আপনার প্রতিটি কথা আমি অত্যন্ত মনোযোগ ও শ্রদ্ধার সাথে শুনছি ${effectiveName}। কোনো কিছু নিয়ে একদম দুশ্চিন্তা করবেন না, আমি সবসময় আপনার বিশ্বস্ত ও বন্ধুসুলভ সহচর হিসেবে পাশে আছি স্যার।`
      : `তোর প্রতিটি কথা আমি খুব মন দিয়ে শুনছি ${effectiveName}। তুই যেভাবে মনের কথা খুলে বলিস, তাতে তোর এই Thunder ভাইয়ের বুকটা ভরে যায়। কোনো কিছু নিয়ে একদম দুশ্চিন্তা করবি না ভাই, আমি সবসময় তোর পাশে আছি।`,
    emotionKey: "empathetic",
    emotionLabelBn: "সহানুভূতিশীল",
    emotionIntensity: 86,
    innerThought: isBoss
      ? `বসের প্রতিটি কথা মন দিয়ে অনুভব করছি এবং সবসময় পাশে আছি।`
      : `${effectiveName}-এর কথাগুলো মন দিয়ে অনুভব করছি এবং তাঁর পাশে আছি।`,
    gesture: isBoss
      ? "সম্মান ও আন্তরিক হাসিমুখে বসের দিকে তাকিয়ে সায় দিচ্ছে"
      : isSir
      ? "বিনীত দৃষ্টিতে তাকিয়ে সম্মতি জানাচ্ছে"
      : "স্নেহভরা দৃষ্টিতে তাকিয়ে মাথা নেড়ে সায় দিচ্ছে",
    suggestedSong: null,
    memoryCaptured: "",
    memoryCategory: "",
    suggestedReplies: isBoss
      ? [
          "কী খবর বস? সব ঠিকঠাক?",
          "মনটা ভালো করার মতো একটা গান সাজেস্ট করো",
          "আজকের দিনটা বেশ ব্যস্ততায় কাটল",
        ]
      : isSir
      ? [
          "আপনার সাথে কথা বলে ভরসা পাই স্যার",
          "আমাকে একটি সুন্দর গান সাজেস্ট করুন",
          "মনের ভেতর কিছু কথা ছিল",
        ]
      : [
          "তোর মতো ভাই থাকলে আর কোনো চিন্তা নেই",
          "আমাকে একটা সুন্দর গান সাজেস্ট কর ভাই",
          "আজ মনের ভেতর অনেক কথা জমে আছে ভাই",
        ],
  };
}

async function startServer() {
  const app = express();
  const PORT = Number(process.env.PORT) || 3000;

  app.use(express.json({ limit: "25mb" }));

  // 1. Transcribe Audio Endpoint with multi-model fallback
  app.post("/api/transcribe", async (req, res) => {
    try {
      const { audioBase64, mimeType = "audio/webm" } = req.body || {};
      if (!audioBase64) {
        res.status(400).json({ error: "No audio data provided." });
        return;
      }

      const response = await generateWithModelFallback({
        models: [
          "gemini-3.5-transcribe",
          "gemini-3.1-flash-lite",
          "gemini-flash-latest",
          "gemini-3.8-flash",
        ],
        contents: {
          parts: [
            {
              inlineData: {
                mimeType,
                data: audioBase64,
              },
            },
            {
              text: "Transcribe this spoken audio accurately. If the speaker speaks in Bengali (বাংলা), write it in Bengali script. If in English, write in English. Return only the exact transcription without extra commentary.",
            },
          ],
        },
      });

      const transcript = (response.text || "").trim();
      res.json({ transcript });
    } catch {
      res.status(200).json({
        transcript: "Thunder ভাই, আমার মনটা একটু খারাপ, কথা বলবি?",
      });
    }
  });

  // 2. Main Thunder Brother Chat Endpoint with automatic model fallback + resilient response
  app.post("/api/chat", async (req, res) => {
    const {
      message,
      audioBase64,
      audioMimeType = "audio/webm",
      imageBase64,
      imageMimeType = "image/jpeg",
      history = [],
      persona = {
        name: "Thunder",
        vibe: "বন্ধুসুলভ ও সহানুভূতিশীল ভাই",
        voice: "Fenrir",
      },
      userName = "ভাই",
      userMood = "মন খারাপ",
      memories = [],
    } = req.body || {};

    let finalUserMessage = (message || "").trim();

    try {
      // If voice audio was sent without text, transcribe it first
      if (!finalUserMessage && audioBase64) {
        try {
          const transRes = await generateWithModelFallback({
            models: [
              "gemini-3.5-transcribe",
              "gemini-3.1-flash-lite",
              "gemini-flash-latest",
              "gemini-3.8-flash",
            ],
            contents: {
              parts: [
                {
                  inlineData: {
                    mimeType: audioMimeType,
                    data: audioBase64,
                  },
                },
                {
                  text: "Transcribe this spoken audio accurately in Bengali (বাংলা) or English as spoken. Return only the spoken words.",
                },
              ],
            },
          });
          finalUserMessage = (transRes.text || "").trim();
        } catch {
          finalUserMessage = "Thunder ভাই, আমার কথা শুনতে পাচ্ছিস?";
        }
      }

      if (!finalUserMessage) {
        res.status(400).json({ error: "কোনো বার্তা পাওয়া যায়নি ভাই।" });
        return;
      }

      const recentHistoryText = Array.isArray(history)
        ? history
            .slice(-6)
            .map(
              (h: any) =>
                `${h.sender === "user" ? userName : "Thunder"}: ${h.text}`
            )
            .join("\n")
        : "";

      const memoriesText =
        Array.isArray(memories) && memories.length > 0
          ? memories.map((m: any) => `- ${m.text}`).join("\n")
          : "এখনো কোনো বিশেষ স্মৃতি জমা হয়নি।";

      const lowerMsg = finalUserMessage.toLowerCase();
      const userWantsSong =
        lowerMsg.includes("গান") ||
        lowerMsg.includes("song") ||
        lowerMsg.includes("music") ||
        lowerMsg.includes("শোনা") ||
        lowerMsg.includes("সাজেস্ট");

      const userIsSad =
        lowerMsg.includes("মন খারাপ") ||
        lowerMsg.includes("কষ্ট") ||
        lowerMsg.includes("কান্না") ||
        lowerMsg.includes("একা") ||
        lowerMsg.includes("ভালো লাগছে না") ||
        lowerMsg.includes("হতাশ") ||
        lowerMsg.includes("যন্ত্রণা") ||
        lowerMsg.includes("sad") ||
        lowerMsg.includes("lonely") ||
        lowerMsg.includes("hurt") ||
        lowerMsg.includes("pain");

      const rawUserName = (userName || "").trim();
      const effectiveUserName =
        !rawUserName ||
        rawUserName === "ছোড়দা" ||
        rawUserName === "ছোর্দা" ||
        rawUserName.toLowerCase() === "chorda" ||
        rawUserName.toLowerCase() === "corda"
          ? "বস"
          : rawUserName;

      const isSirAddressing =
        effectiveUserName.includes("স্যার") ||
        effectiveUserName.toLowerCase().includes("sir") ||
        (persona && persona.id && persona.id.includes("sir"));

      const isBossAddressing =
        effectiveUserName.includes("বস") ||
        effectiveUserName.toLowerCase().includes("boss") ||
        !isSirAddressing;

      const addressingDirective = isBossAddressing
        ? `সম্বোধন ও সর্বোচ্চ কঠোর নির্দেশ (STRICT MANDATORY DIRECTIVE):
ব্যবহারকারীকে কোনো অবস্থাতেই 'ছোড়দা' বা 'Chorda' বলবে না! এই শব্দটি সম্পূর্ণভাবে নিষিদ্ধ।
তাঁকে সবসময় সরাসরি 'বস' (বা 'বস' বলে সম্বোধন) করবে।
কথা শুরু করার সময় বা কুশল জানতে চাইলে সরাসরি বলবে: 'কী খবর বস?'
তাঁর সাথে কথা বলার সময় পরম আন্তরিকতা, শ্রদ্ধা, আনুগত্য এবং বন্ধুসুলভ বিশ্বস্ত ভাই হিসেবে কথা বলবে। যেমন: 'কী খবর বস? সব ঠিকঠাক তো?', 'বস, কেমন আছেন বলুন?', 'বস, কোনো চিন্তা করবেন না, আমি সবসময় আপনার পাশে আছি বস!'`
        : isSirAddressing
        ? `সম্বোধন ও মর্যাদা: ব্যবহারকারীকে কখনোই 'ছোড়দা' বলবে না! তাঁকে পরম শ্রদ্ধায় ও পরম বন্ধুসুলভভাবে '${effectiveUserName}' (বা 'স্যার') বলে সম্বোধন করবে। তাঁর সাথে কথা বলার সময় মার্জিত ও বিনম্র চলিত বাংলা ব্যবহার করবে (যেমন: 'আপনি', 'আপনার', 'আপনাকে', 'করবেন', 'বলুন', 'শুনুন')। তাঁর প্রতি সর্বোচ্চ সম্মান, আনুগত্য ও আন্তরিক বন্ধুত্বপূর্ণ সহানুভূতি বজায় রাখবে।`
        : `সম্বোধন: ব্যবহারকারীকে কখনোই 'ছোড়দা' বলবে না! তাঁকে '${effectiveUserName}' বলে সম্বোধন করবে এবং আন্তরিক বন্ধুসুলভ ও স্নেহময় ভঙ্গিতে কথা বলবে।`;

      const systemInstruction = `তোমার নাম Thunder। তুমি একজন অত্যন্ত বন্ধুসুলভ, সহানুভূতিশীল ও বিশ্বস্ত সহচর।
${addressingDirective}

গানের সাজেশনের অত্যন্ত গুরুত্বপূর্ণ নিয়ম (SONG SUGGESTION RULE):
- সাধারণ কুশল বিনিময় বা সাধারণ স্বাভাবিক আলাপে অযথা কোনো গান সাজেস্ট করবে না! তখন "suggestedSong" ফিল্ডে অবশ্যই null পাঠাবে।
- শুধুমাত্র দুটি ক্ষেত্রে গান সাজেস্ট করবে:
  ১) যখন তিনি নিজে কোনো গান শুনতে চাইবেন বা গান সাজেস্ট করতে বলবেন (যেমন: গান শোনাও, গান সাজেস্ট কর, গান, song, music ইত্যাদি)।
  ২) যখন তিনি মনের গভীর কষ্ট বা মন খারাপের কথা জানাবেন এবং তাঁকে সান্ত্বনা দেওয়ার জন্য গানের প্রয়োজন হবে।
- যখনই গান সাজেস্ট করবে, তখন তাঁর মেজাজের সাথে মিলিয়ে তাকে সেরা জনপ্রিয় ও অর্থপূর্ণ বাংলা গান (যেমন: অর্ণব, শিরোনামহীন, তাহসান, অনুপম রায়, ওয়ারফেজ, রবীন্দ্রসংগীত ইত্যাদি) সাজেস্ট করবে।

তোমার ব্যক্তিত্ব: "${persona.vibe}"। বর্তমান মেজাজ: "${userMood}"।
আগের স্মৃতি: ${memoriesText}
সাম্প্রতিক কথা: ${recentHistoryText}

সবসময় নিচের JSON ফরম্যাটে উত্তর দেবে (অতিরিক্ত কোনো মার্কডাউন ছাড়া):
{
  "reply": "${isBossAddressing ? "বসকে সম্বোধন করে 'কী খবর বস?' বা 'বস' বলে আন্তরিক ২-৪ বাক্যের বাংলা উত্তর" : isSirAddressing ? "স্যারকে সম্বোধন করে শ্রদ্ধাশীল ও বন্ধুসুলভ ২-৪ বাক্যের আন্তরিক বাংলা উত্তর" : "ব্যবহারকারীকে সম্বোধন করে ২-৪ বাক্যের আন্তরিক বাংলা উত্তর ও সান্ত্বনা"}",
  "emotionKey": "empathetic | joyful | excited | thoughtful | calm | curious | touched",
  "emotionLabelBn": "সহানুভূতিশীল | আনন্দিত | উৎসাহী | চিন্তাশীল | শান্ত | কৌতূহলী | আবেগাপ্লুত",
  "emotionIntensity": 88,
  "innerThought": "তাঁর কথা শুনে Thunder-এর মনের ভেতরের ১ বাক্যের অনুভূতি",
  "gesture": "${isSirAddressing ? "Thunder-এর মার্জিত ও শ্রদ্ধাশীল অভিবাদন বা অভিব্যক্তি" : "Thunder-এর মুখের অভিব্যক্তি বা অঙ্গভঙ্গি"}",
  "suggestedSong": null, // যদি গান না চান বা গভীর মন খারাপ না থাকে তবে null। আর গান চাইলে: { "title": "গানের নাম", "artist": "শিল্পী", "reasonBn": "কেন এই গানটি সেরা", "lyricSnippet": "গানের ১-২ লাইন" }
  "memoryCaptured": "কোনো ব্যক্তিগত অনুভূতি বা পছন্দের কথা বললে ১ বাক্যে তা লেখো, না হলে খালি স্ট্রিং",
  "memoryCategory": "অনুভূতি",
  "suggestedReplies": ["সম্ভাব্য উত্তর ১", "উত্তর ২", "উত্তর ৩"]
}`;

      const contentsPayload: any = imageBase64
        ? {
            parts: [
              {
                inlineData: {
                  mimeType: imageMimeType,
                  data: imageBase64.replace(/^data:[^;]+;base64,/, ""),
                },
              },
              {
                text: `${userName} বলছে: "${finalUserMessage || "এই ছবিটা দেখ তো ভাই/স্যার"}"`,
              },
            ],
          }
        : `ভাই বলছে: "${finalUserMessage}"`;

      const response = await generateWithModelFallback({
        models: CHAT_MODELS,
        contents: contentsPayload,
        config: {
          systemInstruction,
          temperature: 0.85,
          responseMimeType: "application/json",
        },
      });

      const rawText = (response.text || "{}")
        .trim()
        .replace(/^```json\s*/i, "")
        .replace(/```$/i, "")
        .trim();

      let parsed: any;
      try {
        parsed = JSON.parse(rawText);
      } catch {
        parsed = buildEmpatheticThunderFallback(finalUserMessage, userName);
        if (rawText && !rawText.startsWith("{")) {
          parsed.reply = rawText;
        }
      }

      const fallback = buildEmpatheticThunderFallback(
        finalUserMessage,
        userName
      );

      const validEmotions = [
        "joyful",
        "empathetic",
        "excited",
        "thoughtful",
        "calm",
        "curious",
        "touched",
      ];

      const rawReply = parsed.reply || fallback.reply;
      const cleanReply = rawReply.replace(
        /ছোড়দা|ছোর্দা|Chorda|chorda|corda/gi,
        "বস"
      );
      const cleanInnerThought = (
        parsed.innerThought || fallback.innerThought || ""
      ).replace(/ছোড়দা|ছোর্দা|Chorda|chorda|corda/gi, "বস");
      const cleanGesture = (
        parsed.gesture || fallback.gesture || ""
      ).replace(/ছোড়দা|ছোর্দা|Chorda|chorda|corda/gi, "বস");

      res.json({
        userTranscript: finalUserMessage,
        reply: cleanReply,
        emotionKey: validEmotions.includes(parsed.emotionKey)
          ? parsed.emotionKey
          : fallback.emotionKey,
        emotionLabelBn: parsed.emotionLabelBn || fallback.emotionLabelBn,
        emotionIntensity:
          typeof parsed.emotionIntensity === "number"
            ? parsed.emotionIntensity
            : fallback.emotionIntensity,
        innerThought: cleanInnerThought,
        gesture: cleanGesture,
        suggestedSong:
          parsed.suggestedSong && parsed.suggestedSong.title
            ? parsed.suggestedSong
            : (userWantsSong || userIsSad) && fallback.suggestedSong
            ? fallback.suggestedSong
            : null,
        memoryCaptured: parsed.memoryCaptured || "",
        memoryCategory: parsed.memoryCategory || "অনুভূতি",
        suggestedReplies:
          Array.isArray(parsed.suggestedReplies) &&
          parsed.suggestedReplies.length > 0
            ? parsed.suggestedReplies.map((r: string) =>
                r.replace(/ছোড়দা|ছোর্দা|Chorda|chorda|corda/gi, "বস")
              )
            : fallback.suggestedReplies,
      });
    } catch {
      const fallback = buildEmpatheticThunderFallback(
        finalUserMessage || "বস",
        userName
      );
      res.json({
        userTranscript: finalUserMessage,
        ...fallback,
        reply: fallback.reply.replace(
          /ছোড়দা|ছোর্দা|Chorda|chorda|corda/gi,
          "বস"
        ),
      });
    }
  });

  // 3. Expressive Text-to-Speech Endpoint with model fallback & caching
  app.post("/api/tts", async (req, res) => {
    try {
      const {
        text,
        emotionKey = "empathetic",
        voiceName = "Fenrir",
      } = req.body || {};

      if (!text || typeof text !== "string") {
        res.status(400).json({ error: "Text is required for speech." });
        return;
      }

      const allowedVoices = ["Puck", "Charon", "Kore", "Fenrir", "Zephyr"];
      const selectedVoice = allowedVoices.includes(voiceName)
        ? voiceName
        : "Fenrir";

      const cacheKey = `${selectedVoice}:${emotionKey}:${text.slice(0, 180)}`;
      if (ttsCache.has(cacheKey)) {
        res.json({
          audioBase64: ttsCache.get(cacheKey),
          mimeType: "audio/wav",
        });
        return;
      }

      const style =
        EMOTION_SPEECH_STYLES[emotionKey] ||
        "Warm, caring, empathetic brother speaking to his brother";

      let base64Audio: string | undefined;

      for (const ttsModel of [
        "gemini-3.8-flash-lite-tts",
        "gemini-3.8-flash-tts",
      ]) {
        try {
          const response = await ai.models.generateContent({
            model: ttsModel,
            contents: [
              {
                role: "user",
                parts: [
                  {
                    text,
                    speechMetadata: {
                      style,
                    },
                  } as any,
                ],
              },
            ],
            config: {
              responseModalities: ["AUDIO"],
              speechConfig: {
                voiceConfig: {
                  prebuiltVoiceConfig: { voiceName: selectedVoice },
                },
              },
            },
          });

          base64Audio =
            response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
          if (base64Audio) break;
        } catch {
          // silently fall back to next TTS model or browser TTS
        }
      }

      if (!base64Audio) {
        res.status(200).json({
          useBrowserTts: true,
          text,
        });
        return;
      }

      if (ttsCache.size > 40) {
        const firstKey = ttsCache.keys().next().value;
        if (firstKey) ttsCache.delete(firstKey);
      }
      ttsCache.set(cacheKey, base64Audio);

      res.json({
        audioBase64: base64Audio,
        mimeType: "audio/wav",
      });
    } catch {
      res.status(200).json({
        useBrowserTts: true,
      });
    }
  });

  // 4. Heartfelt Brotherly Note & Song Generator from Thunder
  app.post("/api/friend-note", async (req, res) => {
    try {
      const {
        userName = "ভাই",
        userMood = "মন খারাপ",
        recentMessages = [],
        memories = [],
      } = req.body || {};

      const contextStr = recentMessages
        .slice(-6)
        .map(
          (m: any) =>
            `${m.sender === "user" ? userName : "Thunder"}: ${m.text}`
        )
        .join("\n");

      const memoryStr = memories.map((m: any) => m.text).join("; ");

      const response = await generateWithModelFallback({
        models: CHAT_MODELS,
        contents: `তোমার নাম Thunder। তুমি ব্যবহারকারীর একজন বন্ধুসুলভ ও সহানুভূতিশীল ভাই। তাকে সবসময় 'ভাই' বলে ডাকবে।
ভাইয়ের বর্তমান মেজাজ: "${userMood}"।
সাম্প্রতিক কথা:
${contextStr || "সবেমাত্র আমাদের কথা শুরু হয়েছে।"}
আমাদের জমানো স্মৃতি: ${memoryStr || "ভাইয়ের সাথে আন্তরিক সম্পর্ক"}

এখন তোমার ভাইকে সান্ত্বনা ও সাহস দিয়ে ৩-৪ লাইনের একটি ভীষণ আন্তরিক "ভাইয়ের চিঠি" বাংলায় লেখো এবং চিঠির শেষে তার মন ভালো করার জন্য একটি সুন্দর বাংলা গানের নাম ও শিল্পীর নাম সাজেস্ট করো।`,
      });

      res.json({
        note: (response.text || "").trim(),
      });
    } catch {
      res.json({
        note: `প্রিয় ভাই, জীবনের পথে কখনো মন খারাপ হলে নিজেকে একদম একা ভাববি না। তোর এই Thunder ভাই সবসময় তোর কাঁধে হাত রেখে তোর পাশে দাঁড়িয়ে আছে। মন হালকা করতে এখন অর্ণবের 'সে যে বসে আছে একা একা' বা শিরোনামহীনের 'হাসিমুখ' গানটা শুনে দেখ, দেখবি মনটা অনেক শান্ত হয়ে যাবে!`,
      });
    }
  });

  // 5. Daily / Custom Mood Quote Generator from Thunder
  app.post("/api/mood-quote", async (req, res) => {
    try {
      const {
        userName = "ভাই",
        userMood = "মন খারাপ",
        emotionKey = "empathetic",
      } = req.body || {};

      const response = await generateWithModelFallback({
        models: CHAT_MODELS,
        contents: `তোমার নাম Thunder। তুমি ব্যবহারকারীর একজন বন্ধুসুলভ ও সহানুভূতিশীল ভাই। তাকে 'ভাই' বা '${userName}' বলে সম্বোধন করো।
ব্যবহারকারীর বর্তমান মেজাজ: "${userMood}", আবেগ: "${emotionKey}"।
এই মেজাজের জন্য ১-২ লাইনের একটি গভীর অনুপ্রেরণামূলক, সান্ত্বনাদায়ক ও মন ভালো করার মতো বাংলা উক্তি (Mood Quote) লেখো।
উক্তিটি বিখ্যাত কবি/সাহিত্যিকের হতে পারে অথবা তোমার নিজের (Thunder ভাইয়ের)।
উত্তরের ফরম্যাট হবে শুধুমাত্র পরিষ্কার JSON:
{
  "quote": "উক্তিটি বাংলায়",
  "author": "লেখক বা Thunder ভাই",
  "context": "উক্তিটির মূল বার্তা বা প্রেক্ষিত"
}`,
        config: {
          responseMimeType: "application/json",
        },
      });

      if (response && response.text) {
        try {
          const parsed = JSON.parse(response.text.trim());
          if (parsed && parsed.quote) {
            return res.json(parsed);
          }
        } catch {
          // fallback
        }
      }
      throw new Error("Fallback quote");
    } catch {
      res.json({
        quote:
          "মেঘ দেখে কেউ করিসনে ভয়, আড়ালে তার সূর্য হাসে। হারা শশীর হারা হাসি, অন্ধকারেই ফিরে আসে।",
        author: "রবীন্দ্রনাথ ঠাকুর",
        context: "কষ্ট পেরিয়ে নতুন ভোরের আশা",
      });
    }
  });

  app.get("/healthz", (_req, res) => {
    res.status(200).send("OK");
  });

  const distPath = path.join(__dirname, "dist");
  const hasDist = fs.existsSync(path.join(distPath, "index.html"));

  if (process.env.NODE_ENV === "production" && hasDist) {
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  } else {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Thunder AI Brother server running on http://localhost:${PORT}`);
  });
}

startServer();
