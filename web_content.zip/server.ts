import 'dotenv/config';
import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT) || 3000;

const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

interface ChatMessageInput {
  role: 'user' | 'model';
  text: string;
}

interface GameContextInput {
  sectorName?: string;
  hp?: number;
  maxHp?: number;
  flux?: number;
  abilities?: string[];
  shards?: number;
  totalShards?: number;
  bossDefeated?: boolean;
}

function formatApiError(error: unknown): { status: number; message: string } {
  const errObj = error as { status?: number; message?: string; code?: number };
  const msg = errObj?.message || 'Unexpected Gemini API error.';
  const status = errObj?.status || errObj?.code || 500;

  if (status === 403 || msg.includes('PERMISSION_DENIED')) {
    return {
      status: 403,
      message: 'API permission denied. Please check your GEMINI_API_KEY in Settings > Secrets.',
    };
  }
  if (status === 400 || msg.includes('API_KEY_INVALID')) {
    return {
      status: 400,
      message: 'Invalid API request or API key. Please verify GEMINI_API_KEY in Settings > Secrets.',
    };
  }
  if (status === 429 || msg.includes('RESOURCE_EXHAUSTED')) {
    return {
      status: 429,
      message: 'Rate limit or quota reached. Please wait a moment or upgrade your key in Settings > Secrets.',
    };
  }
  if (status === 404 || msg.includes('NOT_FOUND')) {
    return {
      status: 404,
      message: 'Requested Gemini model was not found.',
    };
  }
  return { status: 500, message: msg };
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '15mb' }));

  app.get('/api/health', (_req, res) => {
    res.json({ ok: true });
  });

  app.post('/api/chat', async (req, res) => {
    try {
      const { messages, message, mode, gameContext } = req.body as {
        messages?: ChatMessageInput[];
        message?: string;
        mode?: 'standard' | 'fast';
        gameContext?: GameContextInput;
      };

      if (!message || typeof message !== 'string') {
        res.status(400).json({ error: 'Message text is required.' });
        return;
      }

      if (!process.env.GEMINI_API_KEY) {
        res.status(500).json({
          error: 'GEMINI_API_KEY is not configured. Please add it in Settings > Secrets.',
        });
        return;
      }

      const selectedModel = mode === 'fast' ? 'gemini-3.1-flash-lite' : 'gemini-4-hydrogen';

      const ctx = gameContext || {};
      const abilitiesList = Array.isArray(ctx.abilities) && ctx.abilities.length > 0
        ? ctx.abilities.join(', ')
        : 'Base Mobility (Run, Jump, Wall-Slide/Wall-Jump, Slide-Vault, 4-Way Katana + Down-Pogo)';

      const systemInstruction = `You are K-09, the Tactical Cartographer & Combat AI linked to the runner inside HOLLOWWIRE, a dark cyberpunk 2D Metroidvania with high-speed parkour and Hollow Knight-inspired blade-pogo combat.

Your personality: Sharp, concise, tactical, immersive cyberpunk operator tone (never verbose, max 2-4 crisp paragraphs or tight bullet points).

World Knowledge:
- Sunken Conduit (Hub): Starting metro tunnel with Uplink #1, slide-under laser gates, speed-rails, and exits West to Maglev Spire, East to Relay Skybridge, and Down to Cryo-Foundry.
- Maglev Spire (West Tower): Vertical wall-jump chimney with Hover-Sentinels (pogo off them!) and Uplink #2. Summit grants PHASE DASH (invulnerable burst through laser barriers & enemies; resets on ground, wall-slide, grapple, or pogo).
- Relay Skybridge (East): High-speed rail & chasm sector. Far east plaza grants GRAPPLE TETHER (lock-on diamond slingshot).
- Cryo-Foundry (Lower): Acid vats & mid-air Pogo-Mine chains. West chamber grants AERO-THRUSTER (Double Jump).
- Data Vault (Upper East, above Relay Skybridge): High-skill parkour gauntlet rewarding OVERDRIVE ARC (piercing energy blade waves + +25% damage) and an Integrity Cell.
- The Black Spire (Top Summit): Uplink #3 guards the Boss Sanctum of ARCHON-IX (multi-phase sentinel with crimson dash-cleaves you can jump/pogo over, plasma barrages, and shockwave slams).

Current Runner Telemetry:
- Sector: ${ctx.sectorName || 'Unknown'}
- Integrity: ${ctx.hp ?? 5}/${ctx.maxHp ?? 5}
- Flux Core: ${Math.round(ctx.flux ?? 0)}/100 (Spend 33 Flux with [E] to Focus Heal 1 pip)
- Unlocked Modules: ${abilitiesList}
- Data Shards: ${ctx.shards ?? 0}/${ctx.totalShards ?? 12}
- Archon-IX Status: ${ctx.bossDefeated ? 'Neutralized' : 'Active Threat'}

Help the runner navigate sectors, chain parkour combos (Slide -> Jump Vault -> Pogo -> Phase Dash -> Grapple), find abilities, and defeat Archon-IX.`;

      const history = (messages || []).slice(-16).map((m) => ({
        role: m.role === 'model' ? 'model' : 'user',
        parts: [{ text: m.text }],
      }));

      const chat = ai.chats.create({
        model: selectedModel,
        config: { systemInstruction },
        history,
      });

      const response = await chat.sendMessage({ message });
      res.json({
        reply: response.text ?? 'Signal weak. Repeat transmission.',
        model: selectedModel,
      });
    } catch (error) {
      const formatted = formatApiError(error);
      res.status(formatted.status).json({ error: formatted.message });
    }
  });

  app.post('/api/analyze-image', async (req, res) => {
    try {
      const { imageBase64, mimeType, prompt } = req.body as {
        imageBase64?: string;
        mimeType?: string;
        prompt?: string;
      };

      if (!imageBase64 || !mimeType) {
        res.status(400).json({ error: 'Image data and mimeType are required.' });
        return;
      }

      if (!process.env.GEMINI_API_KEY) {
        res.status(500).json({
          error: 'GEMINI_API_KEY is not configured. Please add it in Settings > Secrets.',
        });
        return;
      }

      const cleanBase64 = imageBase64.includes(',')
        ? imageBase64.split(',')[1]
        : imageBase64;

      const imagePart = {
        inlineData: {
          mimeType,
          data: cleanBase64,
        },
      };

      const textPart = {
        text:
          prompt && prompt.trim().length > 0
            ? prompt.trim()
            : 'Analyze this visual recon feed. Identify key terrain, obstacles, threats, aesthetic motifs, or tactical opportunities concisely.',
      };

      const response = await ai.models.generateContent({
        model: 'gemini-4-hydrogen',
        contents: { parts: [imagePart, textPart] },
        config: {
          systemInstruction:
            'You are K-09 Visual Recon inside HOLLOWWIRE. Analyze uploaded photos or game frames with sharp, accurate observations. If it is a gameplay screenshot, identify hazards, pogo/grapple/dash opportunities, and navigation cues. If it is a real-world photo or concept sketch, describe its key subjects, lighting, composition, and details clearly in concise bullet points.',
        },
      });

      res.json({
        analysis: response.text ?? 'No visual telemetry extracted.',
        model: 'gemini-4-hydrogen',
      });
    } catch (error) {
      const formatted = formatApiError(error);
      res.status(formatted.status).json({ error: formatted.message });
    }
  });

  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`HOLLOWWIRE server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
