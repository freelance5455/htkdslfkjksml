import express, { Request, Response, NextFunction } from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import multer from 'multer';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;
const isProduction = process.env.NODE_ENV === 'production';

// Ensure upload directories exist
const uploadBaseDir = path.resolve(__dirname, 'public/uploads');
const UPLOAD_CATEGORIES = ['avatars', 'teams', 'covers', 'chapters', 'misc'] as const;
type CategoryType = (typeof UPLOAD_CATEGORIES)[number];

UPLOAD_CATEGORIES.forEach((sub) => {
  const dir = path.join(uploadBaseDir, sub);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
});

/**
 * Intelligent category resolver that inspects query, headers, body, or filename heuristics
 */
function resolveCategory(req: Request, file?: Express.Multer.File): CategoryType {
  // 1. Query parameter (?category=covers)
  const qCat = ((req.query.category as string) || '').toLowerCase().trim();
  if (UPLOAD_CATEGORIES.includes(qCat as CategoryType)) {
    return qCat as CategoryType;
  }

  // 2. Custom header (x-upload-category: covers)
  const hCat = ((req.headers['x-upload-category'] as string) || '').toLowerCase().trim();
  if (UPLOAD_CATEGORIES.includes(hCat as CategoryType)) {
    return hCat as CategoryType;
  }

  // 3. Body category (if available)
  const bCat = ((req.body?.category as string) || '').toLowerCase().trim();
  if (UPLOAD_CATEGORIES.includes(bCat as CategoryType)) {
    return bCat as CategoryType;
  }

  // 4. Filename / fieldname heuristics
  if (file) {
    const original = (file.originalname || '').toLowerCase();
    const field = (file.fieldname || '').toLowerCase();

    if (original.includes('avatar') || field.includes('avatar') || original.includes('profile')) {
      return 'avatars';
    }
    if (original.includes('team') || original.includes('logo') || original.includes('banner') || field.includes('team')) {
      return 'teams';
    }
    if (original.includes('ch_') || original.includes('chapter') || original.includes('page') || /p\d+/.test(original)) {
      return 'chapters';
    }
    if (original.includes('cover') || field.includes('cover')) {
      return 'covers';
    }
  }

  return 'covers';
}

/**
 * Generate safe, clean filenames while preserving Arabic or English names properly
 */
function generateSafeFilename(file: Express.Multer.File, category: string): string {
  const ext = path.extname(file.originalname).toLowerCase() || '.webp';
  let original = file.originalname;
  try {
    // Correct possible Latin1 encoding issues from multipart streams
    const decoded = Buffer.from(file.originalname, 'latin1').toString('utf8');
    if (decoded && !decoded.includes('')) {
      original = decoded;
    }
  } catch (e) {
    // Keep original
  }

  let base = path.basename(original, ext).replace(/[^a-zA-Z0-9_\u0600-\u06FF-]/g, '_');
  // Strip duplicate underscores
  base = base.replace(/_+/g, '_').replace(/^_+|_+$/g, '');

  if (!base || /^_+$/.test(base) || base.length < 2) {
    base = `${category}_${Date.now()}`;
  }

  const uniqueSuffix = `${Date.now()}_${Math.random().toString(36).substring(2, 8)}`;
  return `${base}_${uniqueSuffix}${ext}`;
}

// Configure Multer storage
const diskStorage = multer.diskStorage({
  destination: (req, file, cb) => {
    const cat = resolveCategory(req, file);
    const targetDir = path.join(uploadBaseDir, cat);
    if (!fs.existsSync(targetDir)) {
      fs.mkdirSync(targetDir, { recursive: true });
    }
    cb(null, targetDir);
  },
  filename: (req, file, cb) => {
    const cat = resolveCategory(req, file);
    const finalName = generateSafeFilename(file, cat);
    cb(null, finalName);
  }
});

const upload = multer({
  storage: diskStorage,
  limits: { fileSize: 40 * 1024 * 1024 }, // 40MB limit per image
  fileFilter: (req, file, cb) => {
    const allowedMimes = ['image/jpeg', 'image/png', 'image/webp', 'image/avif', 'image/gif'];
    if (allowedMimes.includes(file.mimetype) || file.originalname.match(/\.(jpg|jpeg|png|webp|avif|gif)$/i)) {
      cb(null, true);
    } else {
      cb(new Error('صيغة الملف غير مدعومة. يرجى اختيار صورة صالحة (JPG, PNG, WebP)'));
    }
  }
});

// Body parsers
app.use(express.json({ limit: '60mb' }));
app.use(express.urlencoded({ extended: true, limit: '60mb' }));

/**
 * Smart Static Uploads Serving
 * 1. Resolves direct files
 * 2. Cross-searches other categories if a file was moved or stored under another category
 * 3. Never falls through to Vite index.html on missing images (returns proper SVG fallback or 404)
 */
app.use('/uploads', (req: Request, res: Response, next: NextFunction) => {
  try {
    const rawPath = decodeURIComponent(req.path).replace(/^\/+/, '');
    if (!rawPath) {
      return res.status(404).send('Not Found');
    }

    const segments = rawPath.split('/').filter(Boolean);
    const filename = segments[segments.length - 1];

    // 1. Direct path check
    const directPath = path.join(uploadBaseDir, rawPath);
    if (fs.existsSync(directPath) && fs.statSync(directPath).isFile()) {
      res.setHeader('Access-Control-Allow-Origin', '*');
      res.setHeader('Cache-Control', 'public, max-age=604800, immutable');
      return res.sendFile(directPath);
    }

    // 2. Cross-category search across all upload folders
    for (const cat of UPLOAD_CATEGORIES) {
      const candidate = path.join(uploadBaseDir, cat, filename);
      if (fs.existsSync(candidate) && fs.statSync(candidate).isFile()) {
        res.setHeader('Access-Control-Allow-Origin', '*');
        res.setHeader('Cache-Control', 'public, max-age=604800, immutable');
        return res.sendFile(candidate);
      }
    }

    // 3. Flat base directory check
    const flatCandidate = path.join(uploadBaseDir, filename);
    if (fs.existsSync(flatCandidate) && fs.statSync(flatCandidate).isFile()) {
      res.setHeader('Access-Control-Allow-Origin', '*');
      res.setHeader('Cache-Control', 'public, max-age=604800, immutable');
      return res.sendFile(flatCandidate);
    }

    // 4. File completely missing from disk -> Return clean themed SVG image
    // This strictly prevents Vite SPA middleware from returning index.html as an image
    res.setHeader('Content-Type', 'image/svg+xml; charset=utf-8');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Access-Control-Allow-Origin', '*');
    return res.status(404).send(
      `<svg xmlns="http://www.w3.org/2000/svg" width="400" height="550" viewBox="0 0 400 550" fill="#0f172a">
        <rect width="100%" height="100%" fill="#0d121f"/>
        <rect x="15" y="15" width="370" height="520" rx="20" fill="#141c30" stroke="#7c3aed" stroke-width="2" stroke-dasharray="6 6"/>
        <circle cx="200" cy="220" r="54" fill="#241442"/>
        <path d="M175 220 C175 195 225 195 225 220 C225 245 200 260 200 260 C200 260 175 245 175 220 Z" fill="#ec4899"/>
        <text x="200" y="320" fill="#c084fc" font-size="20" font-family="system-ui, sans-serif" font-weight="bold" text-anchor="middle">Manhwa Hart | مانهوا هارت</text>
        <text x="200" y="355" fill="#94a3b8" font-size="14" font-family="system-ui, sans-serif" text-anchor="middle">جاري معالجة أو تحديث الصورة</text>
      </svg>`
    );
  } catch (err) {
    console.error('Uploads middleware error:', err);
    res.status(500).send('Internal Server Error');
  }
});

// API: Health Check
app.get('/api/health', (req: Request, res: Response) => {
  res.json({
    status: 'ok',
    service: 'Manhwa Hart Media Engine',
    timestamp: new Date().toISOString()
  });
});

// API: Single File Upload
app.post('/api/upload', upload.single('file'), (req: Request, res: Response): void => {
  try {
    if (!req.file) {
      res.status(400).json({ success: false, message: 'لم يتم استلام أي ملف' });
      return;
    }

    const cat = resolveCategory(req, req.file);
    const publicUrl = `/uploads/${cat}/${req.file.filename}`;

    res.json({
      success: true,
      url: publicUrl,
      filename: req.file.filename,
      category: cat,
      size: req.file.size
    });
  } catch (error: any) {
    console.error('Upload error:', error);
    res.status(500).json({ success: false, message: error.message || 'فشل رفع الملف' });
  }
});

// API: Multiple Files Upload (For Chapter Pages & Bulk assets)
app.post('/api/upload-multiple', upload.array('files', 150), (req: Request, res: Response): void => {
  try {
    const files = req.files as Express.Multer.File[];
    if (!files || files.length === 0) {
      res.status(400).json({ success: false, message: 'لم يتم استلام أي صور' });
      return;
    }

    const cat = resolveCategory(req, files[0]);
    const urls = files.map((file) => `/uploads/${cat}/${file.filename}`);

    res.json({
      success: true,
      urls,
      count: urls.length,
      category: cat
    });
  } catch (error: any) {
    console.error('Multiple upload error:', error);
    res.status(500).json({ success: false, message: error.message || 'فشل رفع الملفات' });
  }
});

// API: Direct Base64 to Server File
app.post('/api/upload-base64', (req: Request, res: Response): void => {
  try {
    const { dataUrl, category = 'covers', name = 'image' } = req.body;
    if (!dataUrl || typeof dataUrl !== 'string') {
      res.status(400).json({ success: false, message: 'بيانات الصورة غير صالحة' });
      return;
    }

    const matches = dataUrl.match(/^data:([A-Za-z-+\/]+);base64,(.+)$/);
    if (!matches || matches.length !== 3) {
      res.status(400).json({ success: false, message: 'صيغة Base64 غير صالحة' });
      return;
    }

    const mime = matches[1];
    const buffer = Buffer.from(matches[2], 'base64');
    let ext = '.webp';
    if (mime.includes('png')) ext = '.png';
    else if (mime.includes('jpeg') || mime.includes('jpg')) ext = '.jpg';
    else if (mime.includes('gif')) ext = '.gif';

    const sanitizedCategory: CategoryType = UPLOAD_CATEGORIES.includes(category as CategoryType)
      ? (category as CategoryType)
      : 'covers';

    const safeName = (name || 'image')
      .replace(/[^a-zA-Z0-9_\u0600-\u06FF-]/g, '_')
      .replace(/_+/g, '_')
      .replace(/^_+|_+$/g, '') || `${sanitizedCategory}_${Date.now()}`;

    const filename = `${safeName}_${Date.now()}_${Math.random().toString(36).substring(2, 6)}${ext}`;
    const targetDir = path.join(uploadBaseDir, sanitizedCategory);
    if (!fs.existsSync(targetDir)) {
      fs.mkdirSync(targetDir, { recursive: true });
    }

    const filePath = path.join(targetDir, filename);
    fs.writeFileSync(filePath, buffer);

    res.json({
      success: true,
      url: `/uploads/${sanitizedCategory}/${filename}`,
      size: buffer.length
    });
  } catch (error: any) {
    console.error('Base64 upload error:', error);
    res.status(500).json({ success: false, message: error.message || 'فشل حفظ الصورة' });
  }
});

// Setup Vite or Static Frontend
async function startServer() {
  if (!isProduction) {
    const { createServer } = await import('vite');
    const vite = await createServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Manhwa Hart Full-Stack Server running at http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
