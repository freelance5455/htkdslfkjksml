import express, { Request, Response } from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI, Type } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = process.env.PORT || 3000;

app.use(express.json());

// Initialize server-side Gemini client
const apiKey = process.env.GEMINI_API_KEY;
let ai: GoogleGenAI | null = null;

if (apiKey) {
  ai = new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// API endpoint to generate concise study notes & 5 MCQs for Grade 9 Ethiopian curriculum
app.post('/api/generate-study-material', async (req: Request, res: Response): Promise<void> => {
  try {
    const { subject, topic, language = 'Afaan Oromoo' } = req.body;

    if (!topic || typeof topic !== 'string') {
      res.status(400).json({ error: 'Topic is required.' });
      return;
    }

    if (!ai) {
      res.status(503).json({
        error: 'Gemini API key is not configured on the server. Please check settings/secrets.',
      });
      return;
    }

    const systemInstruction = `You are a distinguished Ethiopian high school teacher and curriculum expert specializing in Grade 9 education (Ethiopian Ministry of Education & Oromia Education Bureau curriculum).
Your objective is to provide high-yield, concise, easy-to-understand study notes and exactly 5 multiple-choice review questions with answer keys and in-depth pedagogical explanations.
The target audience is Grade 9 Ethiopian students.
Preferred language is: ${language}.
When generating in Afaan Oromoo, use standard orthography (Qubee Afaan Oromoo) with clear, grammatically sound phrasing, and include English translations for key technical terms.
Ensure questions test conceptual understanding suitable for Ethiopian Grade 9 midterms and finals.`;

    const userPrompt = `Subject: ${subject || 'Afaan Oromoo'}
Grade: Grade 9 (Kutaa 9ffaa)
Topic: ${topic}
Language: ${language}

Please generate:
1. Concise, high-yield study notes divided into key concept sections with bullet points, practical examples, and memory tips.
2. 4-6 key glossary terms (flashcards).
3. Exactly 5 multiple-choice questions (MCQs), each with 4 clear choices (A, B, C, D), the index of the correct answer (0 for A, 1 for B, 2 for C, 3 for D), a clear answer key label, and a helpful pedagogical explanation (Ibsa Deebii).`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: userPrompt,
      config: {
        systemInstruction,
        temperature: 0.3,
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING, description: 'Title of the study module' },
            subject: { type: Type.STRING, description: 'Subject name' },
            grade: { type: Type.STRING, description: 'Grade level, e.g. Grade 9' },
            topicSummary: { type: Type.STRING, description: 'A 2-3 sentence overview of the topic' },
            sections: {
              type: Type.ARRAY,
              description: 'Concise study note sections',
              items: {
                type: Type.OBJECT,
                properties: {
                  heading: { type: Type.STRING },
                  summary: { type: Type.STRING },
                  bulletPoints: {
                    type: Type.ARRAY,
                    items: { type: Type.STRING },
                  },
                  examples: {
                    type: Type.ARRAY,
                    items: { type: Type.STRING },
                  },
                },
                required: ['heading', 'summary', 'bulletPoints'],
              },
            },
            keyTerms: {
              type: Type.ARRAY,
              description: 'Key vocabulary terms / flashcards',
              items: {
                type: Type.OBJECT,
                properties: {
                  term: { type: Type.STRING },
                  definition: { type: Type.STRING },
                  translation: { type: Type.STRING },
                },
                required: ['term', 'definition'],
              },
            },
            questions: {
              type: Type.ARRAY,
              description: 'Exactly 5 multiple-choice review questions',
              items: {
                type: Type.OBJECT,
                properties: {
                  id: { type: Type.INTEGER },
                  question: { type: Type.STRING },
                  questionTranslation: { type: Type.STRING },
                  options: {
                    type: Type.ARRAY,
                    items: { type: Type.STRING },
                    description: 'Four choices: A, B, C, D',
                  },
                  correctIndex: { type: Type.INTEGER, description: '0 to 3' },
                  answerKey: { type: Type.STRING, description: 'e.g. A, B, C, or D' },
                  explanation: { type: Type.STRING, description: 'Why this is the correct answer' },
                },
                required: ['id', 'question', 'options', 'correctIndex', 'answerKey', 'explanation'],
              },
            },
            examTip: { type: Type.STRING, description: 'A high-yield tip for Ethiopian Grade 9 exam' },
          },
          required: ['title', 'subject', 'grade', 'topicSummary', 'sections', 'keyTerms', 'questions'],
        },
      },
    });

    const outputText = response.text;
    if (!outputText) {
      throw new Error('Empty response received from Gemini model.');
    }

    const parsedData = JSON.parse(outputText);
    res.json(parsedData);
  } catch (error: any) {
    console.error('Error generating study materials:', error);
    res.status(500).json({
      error: error.message || 'Failed to generate study materials.',
    });
  }
});

// Health check endpoint
app.get('/api/health', (_req, res) => {
  res.json({ status: 'ok', hasGeminiKey: Boolean(apiKey) });
});

async function startServer() {
  const isProduction = process.env.NODE_ENV === 'production';

  if (!isProduction) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(Number(port), '0.0.0.0', () => {
    console.log(`Server listening on 0.0.0.0:${port} (mode: ${isProduction ? 'production' : 'development'})`);
  });
}

startServer().catch((err) => {
  console.error('Fatal server startup error:', err);
});
