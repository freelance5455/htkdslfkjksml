import express from 'express';
import { createServer } from 'http';
import { WebSocketServer, WebSocket } from 'ws';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const server = createServer(app);
const wss = new WebSocketServer({ server, path: '/ws' });

app.use(express.json());

// Interface for Visitor
export interface Visitor {
  id: string;
  name: string;
  phone?: string;
  cityOrNeighborhood?: string;
  invitedBy?: string;
  companionCount: number;
  companionsDetails?: string;
  isFirstTime: boolean;
  prayerRequest?: string;
  category: 'adulto' | 'jovem' | 'crianca' | 'melhor_idade' | 'pastor_lider';
  status: 'pending' | 'presented';
  isPinned?: boolean;
  notes?: string;
  registeredAt: string; // ISO date string
  presentedAt?: string;
  serviceId: string;
}

export interface ServiceInfo {
  id: string;
  title: string;
  leaderName: string;
  date: string;
  notes?: string;
}

// In-memory data store with file persistence
const DATA_DIR = path.join(__dirname, 'data');
const DATA_FILE = path.join(DATA_DIR, 'church_data.json');

interface AppData {
  currentService: ServiceInfo;
  visitors: Visitor[];
}

function getTodayFormatted(): string {
  const now = new Date();
  return now.toISOString().split('T')[0];
}

const defaultData: AppData = {
  currentService: {
    id: 'culto-' + getTodayFormatted(),
    title: 'Culto de Celebração',
    leaderName: 'Pastor Dirigente',
    date: getTodayFormatted(),
    notes: 'Culto da Família',
  },
  visitors: [
    {
      id: 'demo-1',
      name: 'Marcos Vinícius de Oliveira',
      phone: '(11) 98765-4321',
      cityOrNeighborhood: 'Vila Nova',
      invitedBy: 'Irmão Lucas',
      companionCount: 2,
      companionsDetails: 'Esposa e filho de 8 anos',
      isFirstTime: true,
      prayerRequest: 'Pela saúde da família e emprego',
      category: 'adulto',
      status: 'pending',
      isPinned: true,
      registeredAt: new Date(Date.now() - 15 * 60 * 1000).toISOString(),
      serviceId: 'culto-' + getTodayFormatted(),
    },
    {
      id: 'demo-2',
      name: 'Ana Paula Ferreira & Família',
      phone: '(11) 97123-9988',
      cityOrNeighborhood: 'Jardim Primavera',
      invitedBy: 'Convite das Redes Sociais',
      companionCount: 1,
      companionsDetails: 'Mãe (Dona Lurdes)',
      isFirstTime: true,
      prayerRequest: '',
      category: 'adulto',
      status: 'pending',
      isPinned: false,
      registeredAt: new Date(Date.now() - 5 * 60 * 1000).toISOString(),
      serviceId: 'culto-' + getTodayFormatted(),
    },
  ],
};

let appData: AppData = { ...defaultData };

// Load data from file if exists
try {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
  if (fs.existsSync(DATA_FILE)) {
    const raw = fs.readFileSync(DATA_FILE, 'utf-8');
    appData = JSON.parse(raw);
  } else {
    fs.writeFileSync(DATA_FILE, JSON.stringify(appData, null, 2), 'utf-8');
  }
} catch (err) {
  console.warn('Could not load persistent storage, using memory default', err);
}

function saveData() {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    fs.writeFileSync(DATA_FILE, JSON.stringify(appData, null, 2), 'utf-8');
  } catch (err) {
    console.error('Error saving data to file:', err);
  }
}

// WebSocket broadcast helper
function broadcast(message: object, excludeWs?: WebSocket) {
  const payload = JSON.stringify(message);
  wss.clients.forEach((client) => {
    if (client.readyState === WebSocket.OPEN && client !== excludeWs) {
      client.send(payload);
    }
  });
}

// Handle WebSocket connections
wss.on('connection', (ws: WebSocket) => {
  // Send initial full state to newly connected client
  ws.send(
    JSON.stringify({
      type: 'INIT_STATE',
      data: {
        service: appData.currentService,
        visitors: appData.visitors,
      },
    })
  );

  ws.on('message', (messageRaw: string) => {
    try {
      const message = JSON.parse(messageRaw.toString());
      switch (message.type) {
        case 'ADD_VISITOR': {
          const newVisitor: Visitor = {
            ...message.data,
            id: 'v_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
            registeredAt: new Date().toISOString(),
            status: 'pending',
            serviceId: appData.currentService.id,
          };
          appData.visitors.unshift(newVisitor);
          saveData();

          // Broadcast to everyone including sender so state is authoritative
          broadcast({
            type: 'VISITOR_ADDED',
            visitor: newVisitor,
          });
          ws.send(JSON.stringify({ type: 'VISITOR_ADDED_CONFIRM', visitor: newVisitor }));
          break;
        }

        case 'UPDATE_VISITOR': {
          const { id, updates } = message.data;
          const idx = appData.visitors.findIndex((v) => v.id === id);
          if (idx !== -1) {
            appData.visitors[idx] = {
              ...appData.visitors[idx],
              ...updates,
            };
            if (updates.status === 'presented' && !appData.visitors[idx].presentedAt) {
              appData.visitors[idx].presentedAt = new Date().toISOString();
            }
            saveData();
            broadcast({
              type: 'VISITOR_UPDATED',
              visitor: appData.visitors[idx],
            });
            ws.send(JSON.stringify({ type: 'VISITOR_UPDATED', visitor: appData.visitors[idx] }));
          }
          break;
        }

        case 'DELETE_VISITOR': {
          const { id } = message.data;
          appData.visitors = appData.visitors.filter((v) => v.id !== id);
          saveData();
          broadcast({
            type: 'VISITOR_DELETED',
            id,
          });
          ws.send(JSON.stringify({ type: 'VISITOR_DELETED', id }));
          break;
        }

        case 'UPDATE_SERVICE': {
          appData.currentService = {
            ...appData.currentService,
            ...message.data,
          };
          saveData();
          broadcast({
            type: 'SERVICE_UPDATED',
            service: appData.currentService,
          });
          ws.send(JSON.stringify({ type: 'SERVICE_UPDATED', service: appData.currentService }));
          break;
        }

        case 'RESET_SERVICE_VISITORS': {
          // Clear current service visitors or create new service
          const newServiceId = 'culto-' + getTodayFormatted() + '-' + Date.now().toString().slice(-4);
          appData.currentService = {
            ...appData.currentService,
            id: newServiceId,
            date: getTodayFormatted(),
          };
          // Archive or mark
          saveData();
          broadcast({
            type: 'INIT_STATE',
            data: {
              service: appData.currentService,
              visitors: appData.visitors,
            },
          });
          break;
        }

        case 'PING':
          ws.send(JSON.stringify({ type: 'PONG' }));
          break;

        default:
          break;
      }
    } catch (e) {
      console.error('Error handling WS message:', e);
    }
  });
});

// REST API Endpoints for redundancy & initial SSR/fallback
app.get('/api/state', (_req, res) => {
  res.json({
    service: appData.currentService,
    visitors: appData.visitors,
  });
});

app.post('/api/visitors', (req, res) => {
  const visitorData = req.body;
  const newVisitor: Visitor = {
    ...visitorData,
    id: 'v_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
    registeredAt: new Date().toISOString(),
    status: 'pending',
    serviceId: appData.currentService.id,
  };
  appData.visitors.unshift(newVisitor);
  saveData();
  broadcast({
    type: 'VISITOR_ADDED',
    visitor: newVisitor,
  });
  res.status(201).json(newVisitor);
});

app.patch('/api/visitors/:id', (req, res) => {
  const { id } = req.params;
  const updates = req.body;
  const idx = appData.visitors.findIndex((v) => v.id === id);
  if (idx === -1) {
    res.status(404).json({ error: 'Visitor not found' });
    return;
  }
  appData.visitors[idx] = {
    ...appData.visitors[idx],
    ...updates,
  };
  if (updates.status === 'presented' && !appData.visitors[idx].presentedAt) {
    appData.visitors[idx].presentedAt = new Date().toISOString();
  }
  saveData();
  broadcast({
    type: 'VISITOR_UPDATED',
    visitor: appData.visitors[idx],
  });
  res.json(appData.visitors[idx]);
});

app.delete('/api/visitors/:id', (req, res) => {
  const { id } = req.params;
  appData.visitors = appData.visitors.filter((v) => v.id !== id);
  saveData();
  broadcast({
    type: 'VISITOR_DELETED',
    id,
  });
  res.json({ success: true, id });
});

app.post('/api/service', (req, res) => {
  appData.currentService = {
    ...appData.currentService,
    ...req.body,
  };
  saveData();
  broadcast({
    type: 'SERVICE_UPDATED',
    service: appData.currentService,
  });
  res.json(appData.currentService);
});

// Configure Vite integration
async function startServer() {
  const port = process.env.PORT || 3000;
  const isProd = process.env.NODE_ENV === 'production';

  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  server.listen(port, () => {
    console.log(`Server listening on http://localhost:${port}`);
  });
}

startServer();
