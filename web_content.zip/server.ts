import 'dotenv/config';
import express from 'express';
import path from 'node:path';
import { GoogleGenAI, ThinkingLevel, Type } from '@google/genai';
import type { Request, Response } from 'express';
import {
  MAX_IMPORT_FILE_BYTES,
  formatExtractionError,
  formatWorkersAsBulkText,
  isTextImportMimeType,
  isTransientExtractionError,
  normalizeExtractedWorkers,
  resolveImportMimeType,
} from './src/utils/workerExtraction.ts';

interface ExtractRequestBody {
  fileName?: unknown;
  mimeType?: unknown;
  dataBase64?: unknown;
}

function getGeminiClient(): GoogleGenAI {
  const apiKey = process.env.GEMINI_API_KEY?.trim();
  if (!apiKey) {
    throw new Error(
      'GEMINI_API_KEY is missing on the server. Please configure it in Settings > Secrets.',
    );
  }

  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

async function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

const EXTRACTION_CANDIDATES: ReadonlyArray<{
  model: string;
  thinkingLevel: ThinkingLevel;
  attempts: number;
}> = [
  { model: 'gemini-4-hydrogen', thinkingLevel: ThinkingLevel.LOW, attempts: 2 },
  { model: 'gemini-3.1-flash-lite', thinkingLevel: ThinkingLevel.MINIMAL, attempts: 2 },
];

async function extractWorkersWithGemini(mimeType: string, dataBase64: string) {
  const ai = getGeminiClient();

  let lastError: unknown = null;
  for (const candidate of EXTRACTION_CANDIDATES) {
    for (let attempt = 1; attempt <= candidate.attempts; attempt += 1) {
      try {
        const response = await ai.models.generateContent({
          model: candidate.model,
          contents: {
            parts: [
              {
                inlineData: {
                  mimeType,
                  data: dataBase64,
                },
              },
              {
                text: 'Extract all worker rows (Worker ID, Full Name, Role/Designation) from this file. Return JSON matching the schema.',
              },
            ],
          },
          config: {
            thinkingConfig: { thinkingLevel: candidate.thinkingLevel },
            systemInstruction:
              'You extract worker roster entries from uploaded attendance sheets, worker lists, PDFs, photos, and screenshots. Return every distinct worker with id, name, and role. Preserve exact Worker IDs shown (e.g., WRK-101, EMP-05, token/badge codes). If no ID column exists, return an empty string for id. Preserve full names accurately. If a role/trade/designation is missing for a row, infer from section headers if obvious, otherwise use "Worker". Ignore table headers, totals, dates, signatures, and blank rows.',
            responseMimeType: 'application/json',
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                workers: {
                  type: Type.ARRAY,
                  description: 'Extracted list of workers.',
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      id: {
                        type: Type.STRING,
                        description: 'Worker ID or badge number if present, otherwise empty string.',
                      },
                      name: {
                        type: Type.STRING,
                        description: 'Full name of the worker.',
                      },
                      role: {
                        type: Type.STRING,
                        description: 'Worker role or designation.',
                      },
                    },
                    required: ['id', 'name', 'role'],
                  },
                },
              },
              required: ['workers'],
            },
          },
        });

        const jsonText = (response.text ?? '').trim();
        if (!jsonText) {
          return [];
        }
        const parsed = JSON.parse(jsonText) as { workers?: unknown };
        return normalizeExtractedWorkers(parsed.workers);
      } catch (error) {
        lastError = error;
        if (!isTransientExtractionError(error)) {
          throw error;
        }
        if (attempt < candidate.attempts) {
          await sleep(750 * attempt);
        }
      }
    }
  }

  throw lastError ?? new Error('Failed to extract workers from file.');
}

async function startServer() {
  const app = express();
  const port = Number(process.env.PORT) || 3000;

  app.use(express.json({ limit: '25mb' }));

  app.post('/api/workers/extract-from-file', async (req: Request, res: Response) => {
    try {
      const body = (req.body ?? {}) as ExtractRequestBody;
      const fileName = typeof body.fileName === 'string' ? body.fileName.trim() : 'uploaded-file';
      const rawMimeType = typeof body.mimeType === 'string' ? body.mimeType.trim() : '';
      const rawBase64 = typeof body.dataBase64 === 'string' ? body.dataBase64.trim() : '';

      if (!rawBase64) {
        res.status(400).json({ error: 'Uploaded file content is empty.' });
        return;
      }

      // Strip data URL prefix if accidentally included
      const dataBase64 = rawBase64.includes(',') ? rawBase64.slice(rawBase64.indexOf(',') + 1) : rawBase64;
      const fileBuffer = Buffer.from(dataBase64, 'base64');

      if (fileBuffer.byteLength === 0) {
        res.status(400).json({ error: 'Uploaded file could not be decoded.' });
        return;
      }

      if (fileBuffer.byteLength > MAX_IMPORT_FILE_BYTES) {
        res.status(400).json({ error: 'File is too large. Maximum supported file size is 15 MB.' });
        return;
      }

      const resolvedMime = resolveImportMimeType(fileName, rawMimeType);
      if (!resolvedMime) {
        res.status(400).json({
          error: 'Unsupported file type. Please upload a PDF, JPG, PNG screenshot, WebP, or CSV/TXT file.',
        });
        return;
      }

      if (isTextImportMimeType(resolvedMime)) {
        const text = fileBuffer.toString('utf-8').replace(/^\uFEFF/, '');
        res.json({
          workers: [],
          rawText: text.trim(),
          sourceType: 'text',
        });
        return;
      }

      const workers = await extractWorkersWithGemini(resolvedMime, dataBase64);
      if (workers.length === 0) {
        res.status(422).json({
          error:
            'No worker rows could be detected in this file. Please try a clearer PDF, photo, or screenshot.',
        });
        return;
      }

      res.json({
        workers,
        rawText: formatWorkersAsBulkText(workers),
        sourceType: resolvedMime === 'application/pdf' ? 'pdf' : 'image',
      });
    } catch (error) {
      const formatted = formatExtractionError(error);
      res.status(formatted.status).json({ error: formatted.message });
    }
  });

  const isProduction = process.env.NODE_ENV === 'production';
  if (!isProduction) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  app.listen(port, '0.0.0.0', () => {
    console.log(`Server listening on http://0.0.0.0:${port}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
