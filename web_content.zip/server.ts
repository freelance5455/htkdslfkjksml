import express from 'express';
import http from 'http';
import { createServer as createViteServer } from 'vite';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI, Modality } from '@google/genai';
import { WebSocketServer, WebSocket } from 'ws';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const server = http.createServer(app);
  const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

  app.use(express.json({ limit: '50mb' }));
  app.use(express.urlencoded({ extended: true, limit: '50mb' }));

  // Initialize Gemini API client
  const ai = new GoogleGenAI({
    apiKey: process.env.GEMINI_API_KEY,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });

  // Health check
  app.get('/api/health', (req, res) => {
    res.json({
      status: 'ok',
      hasApiKey: Boolean(process.env.GEMINI_API_KEY),
      app: 'Business Management - Jayed Ahmed',
      timestamp: new Date().toISOString(),
    });
  });

  // 1. Audio Transcription using gemini-3.5-transcribe
  app.post('/api/transcribe', async (req, res) => {
    try {
      const { audioBase64, mimeType } = req.body;
      if (!audioBase64) {
        return res.status(400).json({ error: 'Audio data is required' });
      }

      const audioMime = mimeType || 'audio/webm';
      console.log(`[Business Management] Transcribing audio with gemini-3.5-transcribe (${audioMime})`);

      const transcribeResponse = await ai.models.generateContent({
        model: 'gemini-3.5-transcribe',
        contents: {
          parts: [
            {
              inlineData: {
                mimeType: audioMime,
                data: audioBase64,
              },
            },
            {
              text: 'Transcribe this spoken voice message verbatim in the language spoken (Bengali / English). Do not add preamble.',
            },
          ],
        },
      });

      const text = transcribeResponse.text?.trim() || '';
      res.json({ success: true, text });
    } catch (err: any) {
      console.error('[Transcribe Error]:', err);
      res.status(500).json({ error: err?.message || 'Failed to transcribe audio' });
    }
  });

  // 2. Gemini Multi-Turn Chatbot using gemini-3.5-flash
  app.post('/api/chat', async (req, res) => {
    try {
      const { messages, context } = req.body;
      if (!Array.isArray(messages) || messages.length === 0) {
        return res.status(400).json({ error: 'Messages array is required' });
      }

      console.log(`[Business Management] Chat turn using gemini-3.5-flash`);

      const systemInstruction = `You are the Official AI Business Assistant for "Business Management" (মোবাইল LCD ও পার্টস ব্যবসায় পরিচালনা), an app specially created for Jayed Ahmed from Balaganj, Sylhet, Bangladesh.
Your domain expertise:
1. Mobile LCD Displays (Samsung, Xiaomi, Oppo, Vivo, Realme, Apple, Infinix, Tecno, etc.), Touch/Glass, Batteries, Charging Ribbons, ICs, OCA lamination, and Repair Tools.
2. Wholesale and Retail market pricing, common repairs, troubleshooting display issues (green line, ghost touch, black screen, flex cable damage).
3. Business management advice: inventory control, customer relations, writing polite and effective due payment reminder SMS in Bengali, calculating profit margins, and deal negotiations.
Respond politely, clearly, and practically in Bengali (বাংলা) by default (or English if the user asks in English). Use markdown for lists and bold headers where appropriate.`;

      // Transform messages into contents format
      const formattedContents = messages.map((m: any) => ({
        role: m.role === 'user' ? 'user' : 'model',
        parts: [{ text: m.text }],
      }));

      const chatResponse = await ai.models.generateContent({
        model: 'gemini-3.5-flash',
        contents: formattedContents,
        config: {
          systemInstruction,
        },
      });

      res.json({
        success: true,
        reply: chatResponse.text || '',
      });
    } catch (err: any) {
      console.error('[Chat Error]:', err);
      res.status(500).json({ error: err?.message || 'Failed to generate chat reply' });
    }
  });

  // 3. Search Grounding using gemini-3.5-flash with googleSearch tool
  app.post('/api/search-grounding', async (req, res) => {
    try {
      const { query } = req.body;
      if (!query) {
        return res.status(400).json({ error: 'Search query is required' });
      }

      console.log(`[Business Management] Google Search Grounding for: "${query}"`);

      const searchPrompt = `The user is running a mobile LCD and spare parts wholesale/retail business in Bangladesh (Jayed Ahmed, Balaganj, Sylhet).
User query: "${query}"

Use Google Search to find accurate, up-to-date information on Bangladesh market rates, wholesale sources (like Dhaka Stadium Market, Eastern Plaza, Chittagong, Sylhet), newly launched mobile models, genuine vs copy LCD display compatibility, and market trends. Provide a concise, practical answer in Bengali with key bullet points.`;

      const searchResponse = await ai.models.generateContent({
        model: 'gemini-3.5-flash',
        contents: searchPrompt,
        config: {
          tools: [{ googleSearch: {} }],
        },
      });

      // Extract search grounding metadata if available
      const groundingMetadata = searchResponse.candidates?.[0]?.groundingMetadata;
      const webSources = groundingMetadata?.groundingChunks?.map((chunk: any) => ({
        title: chunk.web?.title || 'Web Source',
        uri: chunk.web?.uri || '',
      })) || [];

      res.json({
        success: true,
        answer: searchResponse.text || '',
        sources: webSources,
      });
    } catch (err: any) {
      console.error('[Search Grounding Error]:', err);
      res.status(500).json({ error: err?.message || 'Failed to search grounding information' });
    }
  });

  // 4. Maps Grounding using gemini-3.5-flash with googleMaps tool
  app.post('/api/maps-grounding', async (req, res) => {
    try {
      const { query, location } = req.body;
      if (!query) {
        return res.status(400).json({ error: 'Location query is required' });
      }

      console.log(`[Business Management] Google Maps Grounding for: "${query}"`);

      const mapsPrompt = `Find nearby locations, mobile markets, courier services, or repair shops in Bangladesh.
User inquiry: "${query}"
Context Location: ${location || 'Balaganj, Sylhet, Bangladesh'}

Provide helpful addresses, operating tips, landmark directions, and courier branch details (Sundarban Courier, SA Paribahan, Karatoa, etc.) in Bengali.`;

      const mapsResponse = await ai.models.generateContent({
        model: 'gemini-3.5-flash',
        contents: mapsPrompt,
        config: {
          tools: [{ googleMaps: {} }],
        },
      });

      res.json({
        success: true,
        answer: mapsResponse.text || '',
      });
    } catch (err: any) {
      console.error('[Maps Grounding Error]:', err);
      res.status(500).json({ error: err?.message || 'Failed to query maps information' });
    }
  });

  // 5. Setup WebSocket for Live API (gemini-3.8-live) Real-time Voice Conversations
  const wss = new WebSocketServer({ noServer: true });

  server.on('upgrade', (request, socket, head) => {
    const url = new URL(request.url || '', `http://${request.headers.host}`);
    if (url.pathname === '/live') {
      wss.handleUpgrade(request, socket, head, (ws) => {
        wss.emit('connection', ws, request);
      });
    }
  });

  wss.on('connection', async (clientWs: WebSocket) => {
    console.log('[Live API] Client connected to live voice session');
    try {
      const session = await ai.live.connect({
        model: 'gemini-3.8-live',
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: {
              prebuiltVoiceConfig: { voiceName: 'Puck' },
            },
          },
          systemInstruction:
            'You are Jayed Ahmed\'s live audio business assistant for a mobile LCD and spare parts shop in Sylhet, Bangladesh. Answer concisely and warmly in Bengali or English.',
        },
        callbacks: {
          onmessage: (message: any) => {
            const audio = message.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
            if (audio && clientWs.readyState === WebSocket.OPEN) {
              clientWs.send(JSON.stringify({ audio }));
            }
            if (message.serverContent?.interrupted && clientWs.readyState === WebSocket.OPEN) {
              clientWs.send(JSON.stringify({ interrupted: true }));
            }
          },
        },
      });

      clientWs.on('message', (data) => {
        try {
          const parsed = JSON.parse(data.toString());
          if (parsed.audio) {
            session.sendRealtimeInput({
              audio: {
                data: parsed.audio,
                mimeType: 'audio/pcm;rate=16000',
              },
            });
          }
        } catch (e) {
          console.warn('[Live API] error parsing client message', e);
        }
      });

      clientWs.on('close', () => {
        console.log('[Live API] Client disconnected');
      });
    } catch (err) {
      console.error('[Live API] Connection error:', err);
      clientWs.send(JSON.stringify({ error: 'Failed to connect to Live API session' }));
    }
  });

  // Vite middleware in dev or static in prod
  if (process.env.NODE_ENV === 'production') {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  } else {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  server.listen(PORT, '0.0.0.0', () => {
    console.log(`[Business Management] Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('[Business Management] Server startup error:', err);
  process.exit(1);
});
