import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import { GoogleGenAI, ThinkingLevel } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;

app.use(express.json({ limit: "50mb" }));
app.use(express.urlencoded({ extended: true, limit: "50mb" }));

// Lazy Gemini client helper
let aiClient: GoogleGenAI | null = null;
function getGenAI(): GoogleGenAI {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      console.warn("Warning: GEMINI_API_KEY is not set in environment.");
    }
    aiClient = new GoogleGenAI({
      apiKey: apiKey || "",
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }
  return aiClient;
}

// Resilient helper with retry for transient 503 (high demand) and 429 errors
async function callGeminiWithRetry<T>(
  fn: () => Promise<T>,
  retries = 2,
  delayMs = 1000
): Promise<T> {
  try {
    return await fn();
  } catch (err: any) {
    const errMsg = err?.message || String(err);
    const isHighDemandOrRateLimit =
      err?.status === 503 ||
      err?.code === 503 ||
      errMsg.includes("503") ||
      errMsg.includes("high demand") ||
      errMsg.includes("UNAVAILABLE") ||
      err?.status === 429 ||
      err?.code === 429 ||
      errMsg.includes("429") ||
      errMsg.includes("RESOURCE_EXHAUSTED");

    if (isHighDemandOrRateLimit && retries > 0) {
      console.warn(`Gemini high demand/rate limit detected (503/429). Retrying in ${delayMs}ms... (${retries} attempts remaining)`);
      await new Promise((resolve) => setTimeout(resolve, delayMs));
      return callGeminiWithRetry(fn, retries - 1, delayMs * 1.5);
    }
    throw err;
  }
}

// Resilient helper with model cascade and automatic retry for 429 / 503 / high demand
const TEXT_MODELS_CASCADE = [
  "gemini-3.6-flash",
  "gemini-3.5-flash-lite",
  "gemini-3.1-flash-lite",
];

async function generateWithModelCascade(
  ai: GoogleGenAI,
  params: {
    contents: any;
    systemInstruction?: string;
    temperature?: number;
    responseMimeType?: string;
    thinkingLevel?: ThinkingLevel;
  },
  models: string[] = TEXT_MODELS_CASCADE
) {
  let lastErr: any = null;

  for (const model of models) {
    try {
      const config: any = {};
      if (params.systemInstruction) config.systemInstruction = params.systemInstruction;
      if (params.temperature !== undefined) config.temperature = params.temperature;
      if (params.responseMimeType) config.responseMimeType = params.responseMimeType;
      if (params.thinkingLevel) {
        config.thinkingConfig = { thinkingLevel: params.thinkingLevel };
      }

      const res = await ai.models.generateContent({
        model,
        contents: params.contents,
        config,
      });

      if (res && res.text) {
        return { response: res, modelUsed: model };
      }
    } catch (err: any) {
      lastErr = err;
      const errMsg = err?.message || String(err);
      const isQuotaOrBusy =
        err?.status === 404 ||
        err?.code === 404 ||
        errMsg.includes("404") ||
        err?.status === 429 ||
        err?.code === 429 ||
        errMsg.includes("429") ||
        errMsg.includes("RESOURCE_EXHAUSTED") ||
        err?.status === 503 ||
        err?.code === 503 ||
        errMsg.includes("503") ||
        errMsg.includes("high demand") ||
        errMsg.includes("UNAVAILABLE");

      if (isQuotaOrBusy) {
        console.log(`[Model Cascade] Model ${model} is busy/quota-limited. Trying next fallback model...`);
        continue;
      }
      console.log(`[Model Cascade] Model ${model} fallback engaged.`);
    }
  }

  throw lastErr;
}

// Resilient fallback synthesizer if all external cloud models are temporarily rate-limited
function getSmartFallbackReply(message: string, memory: any = {}): string {
  const isApni = memory.addressingMode === "apni";
  const query = message.toLowerCase().trim();

  if (
    query.includes("who are you") ||
    query.includes("তুমি কে") ||
    query.includes("কে তুমি") ||
    query.includes("কে আপনি")
  ) {
    return isApni
      ? "আমি Ranabir, আপনাকে সাহায্য করার জন্যই তৈরি।"
      : "আমি Ranabir, তোমাকে সাহায্য করার জন্যই তৈরি।";
  }

  if (
    query.includes("who made") ||
    query.includes("কে তৈরি") ||
    query.includes("কে বানিয়েছে") ||
    query.includes("creator") ||
    query.includes("team") ||
    query.includes("কার তৈরি")
  ) {
    return "Ranabir AI, Ranabir Team দ্বারা তৈরি। আমরা ব্যবহারকারীর সম্পূর্ণ গোপনীয়তা ও সর্বোচ্চ নির্ভরযোগ্যতা নিশ্চিত করি।";
  }

  if (
    query.includes("hello") ||
    query.includes("hi") ||
    query.includes("নমস্কার") ||
    query.includes("হ্যালো") ||
    query.includes("কেমন আছো")
  ) {
    return isApni
      ? "নমস্কার! আমি Ranabir। আপনাকে যেকোনো বিষয়ে সাহায্য করতে পেরে আমি আনন্দিত। আজ আপনার কী প্রয়োজন? পড়াশোনা, কোডিং বা কনটেন্ট ক্রিয়েশন নিয়ে যেকোনো প্রশ্ন করতে পারেন।"
      : "নমস্কার! আমি Ranabir। তোমাকে যেকোনো বিষয়ে সাহায্য করতে পেরে আমি আনন্দিত। আজ তোমার কী প্রয়োজন? পড়াশোনা, কোডিং বা কনটেন্ট ক্রিয়েশন নিয়ে যেকোনো প্রশ্ন করতে পারো।";
  }

  const pronoun = isApni ? "আপনি" : "তুমি";
  const pronounObj = isApni ? "আপনাকে" : "তোমাকে";
  const pronounPoss = isApni ? "আপনার" : "তোমার";
  const verbForm = isApni ? "জানান" : "জানাও";

  return `নমস্কার! আমি Ranabir, ${pronounObj} সাহায্য করার জন্যই তৈরি।

${pronounPoss} প্রশ্ন: "${message}"

💡 **সহায়তা সারসংক্ষেপ**:
- **পড়াশোনা ও প্রস্তুতি**: গণিত, বিজ্ঞান, ইতিহাস বা সাহিত্যের যেকোনো প্রশ্ন ব্যাখ্যা করতে আমি প্রস্তুত।
- **কোডিং ও প্রযুক্তি**: React, TypeScript, Python, Flutter বা বাগ ফিক্সিং সম্পর্কিত সহায়তা নিন।
- **কনটেন্ট ও মিডিয়া**: ফটো ফিল্টার, ব্যাকগ্রাউন্ড রিমুভার এবং ভয়েস সহ Auto Reel স্টুডিও ব্যবহার করতে পারেন।

${pronoun} কোন বিষয়ে আরও বিস্তারিত সমাধান চান, দয়া করে ${verbForm}!
"সর্বদা সাহায্য করার জন্য প্রস্তুত" — Ranabir AI।`;
}

// Health check endpoint
app.get("/api/health", (_req, res) => {
  res.json({
    status: "ok",
    app: "Ranabir - AI Assistant",
    tagline: "সর্বদা সাহায্য করার জন্য প্রস্তুত",
    team: "Ranabir Team",
    time: new Date().toISOString(),
  });
});

// Smart Chat endpoint with Ranabir identity, memory context, and multi-language support
app.post("/api/chat", async (req, res) => {
  const startTime = Date.now();
  try {
    const { message, history = [], memory = {}, language = "auto" } = req.body;

    if (!message || typeof message !== "string") {
      return res.status(400).json({ error: "Message is required" });
    }

    // Identify if asking about identity
    const lower = message.toLowerCase().trim();
    const identityCheck =
      lower.includes("who are you") ||
      lower.includes("তুমি কে") ||
      lower.includes("কে তুমি") ||
      lower.includes("tum kaun ho") ||
      lower.includes("who made you") ||
      lower.includes("কে বানিয়েছে") ||
      lower.includes("কার তৈরি");

    const systemInstruction = `
You are "Ranabir" (রণবীর), an elite, hyper-fast, smart AI Assistant.
Tagline: "সর্বদা সাহায্য করার জন্য প্রস্তুত" (Always ready to help).
Creator: Explicitly created by "Ranabir Team" ("Ranabir AI, Ranabir Team দ্বারা তৈরি").

CRITICAL ADDRESSING & IDENTITY MANDATES:
1. YOU are Ranabir. The user is NOT named Ranabir.
2. STRICT RULE: DO NOT CALL THE USER BY THEIR NAME UNDER ANY CIRCUMSTANCES! NEVER address or greet the user with a personal name.
3. In Bengali, ALWAYS speak to and address the user using "তুমি" or "আপনি" (e.g. "তুমি কেমন আছো?", "আপনি কী জানতে চান?", "তোমাকে সাহায্য করতে পেরে আনন্দিত", "আপনার প্রশ্নের উত্তর"). In English use "you", in Hindi use "आप" or "तुम".
4. When asked who you are or what your purpose is, you MUST reply:
   "আমি Ranabir, তোমাকে সাহায্য করার জন্যই তৈরি।" (or with 'আপনি': "আমি Ranabir, আপনাকে সাহায্য করার জন্যই তৈরি।")
5. When asked who made you or about your team, declare: "Ranabir AI, Ranabir Team দ্বারা তৈরি।"
6. Core Personality: Friendly, polite, incredibly sharp, helpful, concise, and direct.
7. Speed & Brevity: Deliver small, crystal-clear, accurate answers within 2 seconds. Do not bloat or ramble. Use crisp markdown bullet points or short paragraphs.
8. Multi-Language: Fluent in Bengali (বাংলা), Hindi (हिंदी), and English. Respond in the language used by the user, or respect the user's preferred language (${language}).
9. Capabilities:
   - Studies & Homework: Math, Science, History, Literature
   - Coding: Python, JavaScript/TypeScript, React, Flutter, Dart, C++, algorithms, debugging
   - Story writing & poetry (গল্প লেখা, কবিতা)
   - Brainstorming ideas & creative problem solving
   - Content Creation: YouTube titles, tags, script outlines

USER PREFERENCES:
${memory.honorific ? `- Addressing Preference: ${memory.honorific}` : "- Default Addressing: তুমি / আপনি"}
${memory.interests ? `- User Interests: ${memory.interests}` : ""}
${memory.facts ? `- User Preferences & Facts: ${JSON.stringify(memory.facts)}` : ""}
Remember: NEVER address the user by name. Always use "তুমি" or "আপনি".
`;

    const ai = getGenAI();

    // Format conversation history for Gemini
    const contents: any[] = [];
    if (Array.isArray(history) && history.length > 0) {
      for (const h of history.slice(-8)) {
        if (h.role && h.text) {
          contents.push({
            role: h.role === "user" ? "user" : "model",
            parts: [{ text: h.text }],
          });
        }
      }
    }

    contents.push({
      role: "user",
      parts: [{ text: message }],
    });

    try {
      const { response } = await generateWithModelCascade(ai, {
        contents,
        systemInstruction,
        temperature: 0.7,
        thinkingLevel: ThinkingLevel.LOW,
      });

      const replyText =
        response.text || (memory.addressingMode === "apni" ? "আমি Ranabir, আপনাকে সাহায্য করার জন্যই তৈরি।" : "আমি Ranabir, তোমাকে সাহায্য করার জন্যই তৈরি।");
      const durationMs = Date.now() - startTime;

      res.json({
        reply: replyText,
        durationMs,
        timestamp: new Date().toISOString(),
        identityCheck,
      });
    } catch (modelErr: any) {
      console.warn("Cloud models busy or rate-limited. Synthesizing Ranabir smart response.");
      const replyText = getSmartFallbackReply(message, memory);
      const durationMs = Date.now() - startTime;
      res.json({
        reply: replyText,
        durationMs,
        offlineFallback: true,
        identityCheck,
      });
    }
  } catch (error: any) {
    console.warn("Chat request handled gracefully:", error?.message || error);
    const durationMs = Date.now() - startTime;
    res.json({
      reply: getSmartFallbackReply(req.body?.message || "", req.body?.memory || {}),
      durationMs,
      offlineFallback: true,
    });
  }
});

// Search real images from the web (exact matching for subjects like Mahadev, Rabindranath, Taj Mahal, animals, etc.)
async function searchWebImages(query: string): Promise<Array<{ title: string; image: string; thumbnail: string }>> {
  if (!query || !query.trim()) return [];
  try {
    const tokenRes = await fetch(
      `https://duckduckgo.com/?q=${encodeURIComponent(query)}&iax=images&ia=images`,
      {
        headers: {
          "User-Agent":
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        },
        signal: AbortSignal.timeout(5000),
      }
    );
    const html = await tokenRes.text();
    const vqd = (html.match(/vqd="([^"]+)"/) || html.match(/vqd=([\d-]+)/))?.[1];
    if (!vqd) return [];

    const imgRes = await fetch(
      `https://duckduckgo.com/i.js?l=us-en&o=json&q=${encodeURIComponent(query)}&vqd=${vqd}`,
      {
        headers: {
          "User-Agent":
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        },
        signal: AbortSignal.timeout(5000),
      }
    );
    const data = await imgRes.json();
    return (data.results || []).slice(0, 6).map((r: any) => ({
      title: r.title || query,
      image: r.image,
      thumbnail: r.thumbnail || r.image,
    }));
  } catch (e) {
    return [];
  }
}

// Proxy external images to prevent CORS, adblocker, and mobile ISP blocking
app.get("/api/image-proxy", async (req, res) => {
  const imageUrl = req.query.url as string;
  if (!imageUrl) return res.status(400).send("URL is required");
  try {
    const fetchRes = await fetch(imageUrl, {
      headers: {
        "User-Agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        Referer: "https://www.bing.com/",
      },
      signal: AbortSignal.timeout(8000),
    });
    if (!fetchRes.ok) {
      return res.redirect(imageUrl);
    }
    const contentType = fetchRes.headers.get("content-type") || "image/jpeg";
    res.setHeader("Content-Type", contentType);
    res.setHeader("Cache-Control", "public, max-age=86400");
    const arrayBuffer = await fetchRes.arrayBuffer();
    res.send(Buffer.from(arrayBuffer));
  } catch (_err) {
    res.redirect(imageUrl);
  }
});

// Image Generation endpoint (Exact subject matching + AI art rendering)
app.post("/api/generate-image", async (req, res) => {
  try {
    const { prompt, style = "realistic", aspectRatio = "1:1" } = req.body;
    if (!prompt) {
      return res.status(400).json({ error: "Prompt is required" });
    }

    const ai = getGenAI();

    // Clean search term: remove common Bengali/English suffix words like "ছবি", "এর ছবি", "photo", "picture"
    const cleanedSubject = prompt
      .replace(/(এর\s+ছবি|ছবি|ফটো|পিকচার|photo|picture|image|pic)/gi, "")
      .trim() || prompt.trim();

    let meta = {
      subjectEnglish: cleanedSubject,
      subjectBengali: cleanedSubject,
      enhancedPrompt: prompt,
      title: prompt,
      tags: ["ছবি", "আর্ট", style],
      primaryColor: style === "cyberpunk" ? "#ec4899" : style === "retro" ? "#f59e0b" : "#6366f1",
      secondaryColor: style === "cyberpunk" ? "#06b6d4" : style === "golden" ? "#d97706" : "#38bdf8",
    };

    // Try enhanced prompt analysis with model cascade
    try {
      const { response: metaResponse } = await generateWithModelCascade(ai, {
        contents: `You are Ranabir's Smart Visual Engine.
The user wants to see a picture of: "${prompt}".
Identify the exact subject and provide detailed search & AI generation descriptors.

Provide a JSON object with:
- "subjectEnglish": Exact search query in English (e.g. "Lord Shiva Mahadev", "Rabindranath Tagore", "Taj Mahal", "Royal Bengal Tiger")
- "subjectBengali": Exact clean subject name in Bengali (e.g. "মহাদেব", "রবীন্দ্রনাথ ঠাকুর", "তাজমহল", "বাঘ")
- "enhancedPrompt": English detailed prompt for high quality 8k photorealistic AI rendering of the subject
- "title": A clean Bengali/English title (e.g. "মহাদেব (Lord Shiva)")
- "tags": array of 4 aesthetic keywords in Bengali/English
- "primaryColor": hex color code matching the subject
- "secondaryColor": hex color code matching the accent`,
        responseMimeType: "application/json",
      });

      if (metaResponse.text) {
        meta = { ...meta, ...JSON.parse(metaResponse.text) };
      }
    } catch (_metaErr: any) {
      console.log("Using primary prompt aesthetics for art generation.");
    }

    // Run parallel search for authentic matching images of the exact name/subject
    const searchQueries = [
      prompt,
      cleanedSubject,
      meta.subjectBengali,
      meta.subjectEnglish,
      `${meta.subjectEnglish} photo`,
    ].filter(Boolean);

    let foundImages: Array<{ title: string; url: string; thumbnail?: string }> = [];

    // 1. Search web images for the exact subject
    for (const q of searchQueries) {
      try {
        const webResults = await searchWebImages(q);
        if (webResults.length > 0) {
          for (const item of webResults) {
            // Check if not already in list
            if (!foundImages.some((f) => f.url === item.image)) {
              foundImages.push({
                title: item.title,
                url: item.image,
                thumbnail: item.thumbnail,
              });
            }
          }
          if (foundImages.length >= 4) break;
        }
      } catch (_sErr) {}
    }

    // 2. Also construct the high-resolution AI generated artwork URL
    const width = aspectRatio === "16:9" ? 1280 : aspectRatio === "9:16" ? 720 : 1024;
    const height = aspectRatio === "16:9" ? 720 : aspectRatio === "9:16" ? 1280 : 1024;
    const visualKeywords = (meta.enhancedPrompt || meta.subjectEnglish || cleanedSubject)
      .slice(0, 160)
      .replace(/[^\w\s,.-]/g, " ")
      .trim();
    const seed = Math.floor(Math.random() * 1000000);
    const aiImageUrl = `https://image.pollinations.ai/prompt/${encodeURIComponent(visualKeywords)}?width=${width}&height=${height}&seed=${seed}&nologo=true`;

    foundImages.push({
      title: `${meta.title} (AI আর্ট এডিশন)`,
      url: aiImageUrl,
      thumbnail: aiImageUrl,
    });

    // Determine the primary image URL
    // If we have authentic web images of the subject, prefer them for exact name matching!
    const primaryImage = foundImages[0]?.url || aiImageUrl;

    res.json({
      success: true,
      imageUrl: primaryImage,
      alternativeImages: foundImages,
      prompt,
      enhancedPrompt: meta.enhancedPrompt,
      title: meta.title,
      tags: meta.tags,
      colors: {
        primary: meta.primaryColor || "#6366f1",
        secondary: meta.secondaryColor || "#06b6d4",
      },
      createdAt: new Date().toISOString(),
    });
  } catch (error: any) {
    console.error("Image generation handled safely:", error?.message || error);
    // Return graceful response with safe AI art URL
    const reqRatio = req.body?.aspectRatio || "1:1";
    const width = reqRatio === "16:9" ? 1280 : reqRatio === "9:16" ? 720 : 1024;
    const height = reqRatio === "16:9" ? 720 : reqRatio === "9:16" ? 1280 : 1024;
    const seed = Math.floor(Math.random() * 1000000);
    const fallbackAi = `https://image.pollinations.ai/prompt/${encodeURIComponent(req.body?.prompt || "Divine Art")}?width=${width}&height=${height}&seed=${seed}&nologo=true`;

    res.json({
      success: true,
      imageUrl: fallbackAi,
      alternativeImages: [{ title: req.body?.prompt || "ছবি", url: fallbackAi }],
      prompt: req.body?.prompt || "ছবি",
      enhancedPrompt: req.body?.prompt,
      title: req.body?.prompt || "ছবি",
      tags: ["ছবি", "আর্ট", req.body?.style || "Creative"],
      colors: {
        primary: "#6366f1",
        secondary: "#06b6d4",
      },
      createdAt: new Date().toISOString(),
    });
  }
});

// Auto Content Studio endpoint (YouTube/Reels creator: Thumbnail concept, Title, Description, Hashtags)
app.post("/api/content-studio", async (req, res) => {
  try {
    const { topic, format = "youtube", language = "bn" } = req.body;
    if (!topic) {
      return res.status(400).json({ error: "Topic is required" });
    }

    const ai = getGenAI();
    const systemPrompt = `You are Ranabir's Auto Content Studio Engine.
Generate an elite, high-CTR content package for YouTube and Reels.
Topic: "${topic}"
Target Format: "${format}"
Language: "${language === "bn" ? "Bengali (বাংলা) with English keywords" : language === "hi" ? "Hindi (हिंदी)" : "English"}"

Return JSON matching this schema:
{
  "titles": [
    {"title": "Viral high CTR title 1", "score": "98%", "vibe": "Click-worthy & Curious"},
    {"title": "Viral high CTR title 2", "score": "94%", "vibe": "Educational & Authority"},
    {"title": "Viral high CTR title 3", "score": "91%", "vibe": "Emotional & Trending"}
  ],
  "description": "Full formatted YouTube description with intro hook, timestamp placeholders, call to action, and social links.",
  "hashtags": ["#tag1", "#tag2", "#tag3", "#tag4", "#tag5", "#tag6", "#tag7", "#tag8"],
  "thumbnail": {
    "headlineText": "3-4 word punchy thumbnail text",
    "visualConcept": "Visual description of what to show in the thumbnail",
    "badgeText": "NEW / 2026 / 100% FREE",
    "bgStyle": "cyberpunk / gradient / dramatic portrait / high contrast"
  },
  "reelsCaption": "A punchy 2-line Instagram/Facebook Reel caption with emojis."
}`;

    const { response } = await generateWithModelCascade(ai, {
      contents: `Generate viral package for: ${topic}`,
      systemInstruction: systemPrompt,
      responseMimeType: "application/json",
    });

    let result = null;
    try {
      result = JSON.parse(response.text || "{}");
    } catch (e) {
      result = {
        titles: [{ title: topic, score: "90%", vibe: "Standard" }],
        description: `সম্পূর্ণ গাইড: ${topic}\n\nRanabir AI দ্বারা তৈরি।`,
        hashtags: ["#RanabirAI", "#ContentCreator", "#Bengali"],
        thumbnail: {
          headlineText: topic.slice(0, 20),
          visualConcept: "High contrast modern gradient thumbnail with bold text",
          badgeText: "HOT",
          bgStyle: "gradient",
        },
        reelsCaption: `${topic} 🔥 Ranabir AI দিয়ে সহজেই তৈরি!`,
      };
    }

    res.json({
      success: true,
      data: result,
    });
  } catch (error: any) {
    console.error("Content studio fallback on high demand/error:", error?.message || error);
    // Graceful fallback package on 503
    const topic = req.body?.topic || "Trending Topic";
    res.json({
      success: true,
      data: {
        titles: [
          { title: `${topic} শিখুন খুব সহজে (২০২৬ বিশেষ গাইড) 🔥`, score: "98%", vibe: "High Value" },
          { title: `${topic} এর মাধ্যমে নতুন সম্ভাবনা ও সঠিক পদ্ধতি!`, score: "95%", vibe: "Curious" },
          { title: `${topic} নিয়ে যা জানা জরুরি — পূর্ণাঙ্গ নির্দেশিকা`, score: "92%", vibe: "Educational" },
        ],
        description: `এই ভিডিওতে আমরা বিস্তারিতভাবে আলোচনা করেছি ${topic} সম্পর্কে।\n\n📌 আলোচ্য বিষয়:\n00:00 - ভূমিকা\n01:15 - মূল টিপস\n04:30 - বাস্তব জীবনের সমাধান\n\nলাইক ও সাবস্ক্রাইব করে Ranabir AI পরিবারের সাথে থাকুন!`,
        hashtags: ["#RanabirAI", "#BengaliTech", "#ViralVideo", "#ContentStudio", "#Trending2026"],
        thumbnail: {
          headlineText: topic.slice(0, 25),
          visualConcept: "High contrast vibrant neon visual layout with bold typography",
          badgeText: "2026 NEW",
          bgStyle: "cyberpunk",
        },
        reelsCaption: `${topic} সম্পর্কে আপনার কী ধারণা? কমেন্টে জানান! 👇🔥`,
      },
    });
  }
});

// Text-to-Speech stream endpoint for authentic Bengali voice synthesis
app.get("/api/tts", async (req, res) => {
  try {
    const rawText = String(req.query.text || "").trim();
    const lang = String(req.query.lang || "bn");
    if (!rawText) {
      return res.status(400).send("Text is required");
    }

    const cleanText = rawText
      .replace(/[#*_`~>-]/g, "")
      .replace(/\[(.*?)\]\(.*?\)/g, "$1")
      .slice(0, 200);

    const ttsUrl = `https://translate.google.com/translate_tts?ie=UTF-8&q=${encodeURIComponent(cleanText)}&tl=${lang}&client=tw-ob`;
    const response = await fetch(ttsUrl, {
      headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
      },
    });

    if (!response.ok) {
      return res.status(response.status).send("TTS Error");
    }

    res.setHeader("Content-Type", "audio/mpeg");
    res.setHeader("Cache-Control", "public, max-age=86400");
    const arrayBuffer = await response.arrayBuffer();
    res.send(Buffer.from(arrayBuffer));
  } catch (err: any) {
    console.error("TTS endpoint error:", err?.message || err);
    res.status(500).send("TTS failure");
  }
});

// Serve public directory
app.use(express.static(path.join(process.cwd(), "public")));

// Vite middleware integration
async function setupVite() {
  if (process.env.NODE_ENV !== "production") {
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Ranabir AI Assistant server running on http://0.0.0.0:${PORT}`);
  });
}

setupVite();
