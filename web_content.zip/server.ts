import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { GoogleGenAI, Type } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

// Support high payload for high-res photo uploads (Snap & Solve)
app.use(express.json({ limit: '30mb' }));
app.use(express.urlencoded({ extended: true, limit: '30mb' }));

// Server-side initialization of Gemini client
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

// Helper to sanitize base64
function extractBase64(dataUriOrBase64: string): { data: string; mimeType: string } {
  if (dataUriOrBase64.startsWith('data:')) {
    const matches = dataUriOrBase64.match(/^data:([a-zA-Z0-9]+\/[a-zA-Z0-9-.+]+);base64,(.+)$/);
    if (matches && matches.length === 3) {
      return { mimeType: matches[1], data: matches[2] };
    }
  }
  return { mimeType: 'image/jpeg', data: dataUriOrBase64 };
}

// 1. SNAP AND SOLVE ENDPOINT
app.post('/api/snap-solve', async (req, res) => {
  try {
    const { image, subject = 'General', grade = '8th Grade', studentName = 'Student', followUp } = req.body;

    if (!image) {
      return res.status(400).json({ error: 'Please provide an image of the problem.' });
    }

    const { data: base64Data, mimeType } = extractBase64(image);

    const promptText = `
You are StudySnap AI, an expert, encouraging, and pedagogically sound personal tutor.
Student Profile:
- Name: ${studentName}
- Current Grade Level: ${grade}
- Selected Subject: ${subject}

TASK:
Examine the image containing a homework/study problem (which may be Math, History, Science, English, or another topic).
${followUp ? `Student follow-up question: "${followUp}"` : 'Solve the problem completely and explain it with crystal clarity.'}

CRITICAL PEDAGOGICAL INSTRUCTIONS:
1. Accurately transcribe the exact problem text and any equations/diagrams from the image.
2. Determine the exact subject and specific topic (e.g., "Math - Quadratic Equations" or "Science - Cellular Respiration" or "History - American Civil War").
3. Give a clear, direct final answer first or highlight it prominently.
4. Provide structured, numbered step-by-step reasoning. Break down calculations, logic, or historical evidence.
5. Calibrate the explanation tone and vocabulary precisely to a ${grade} student:
   - For Elementary (1st-5th): warm, simple terms, relatable everyday analogies.
   - For Middle School (6th-8th): clear fundamentals, defined terminology, step-by-step guidance.
   - For High School (9th-12th): rigorous explanations, standard scientific/mathematical notation, historical primary sources context.
   - For College/AP: deep analytical precision, theoretical grounding, alternative methods.
6. Provide "Key Formulas / Concepts", "Why This Works" intuition, "Common Pitfalls & Mistakes to Avoid", and a "Bonus Practice Question" with its answer for the student to test themselves.

Return your response in STRICT valid JSON matching this schema:
{
  "subjectDetected": "string",
  "topic": "string",
  "transcribedProblem": "string",
  "directAnswer": "string",
  "steps": [
    {
      "stepNumber": 1,
      "title": "string",
      "explanation": "string",
      "mathOrFormula": "string optional"
    }
  ],
  "gradeTailoredExplanation": "string",
  "keyConcepts": ["string"],
  "commonMistakes": ["string"],
  "similarPracticeQuestion": {
    "question": "string",
    "hint": "string",
    "answer": "string"
  }
}
`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: {
        parts: [
          {
            inlineData: {
              data: base64Data,
              mimeType: mimeType || 'image/jpeg',
            },
          },
          {
            text: promptText,
          },
        ],
      },
      config: {
        responseMimeType: 'application/json',
      },
    });

    const responseText = response.text || '{}';
    let parsedData;
    try {
      parsedData = JSON.parse(responseText);
    } catch {
      // Clean possible markdown code fences if any
      const cleaned = responseText.replace(/```json/g, '').replace(/```/g, '').trim();
      parsedData = JSON.parse(cleaned);
    }

    return res.json({ success: true, data: parsedData });
  } catch (error: any) {
    console.error('Snap & Solve Error:', error);
    return res.status(500).json({ error: error.message || 'Failed to solve image problem' });
  }
});

// 2. PARAGRAPH WRITING ENDPOINT
app.post('/api/generate-paragraph', async (req, res) => {
  try {
    const {
      topic,
      wordCount = 120,
      paragraphType = 'Expository',
      tone = 'Academic',
      grade = '8th Grade',
      studentName = 'Student',
    } = req.body;

    if (!topic || topic.trim().length === 0) {
      return res.status(400).json({ error: 'Please enter a topic for the paragraph.' });
    }

    const promptText = `
You are an expert writing coach assisting ${studentName}, a student in ${grade}.
The student requests a single, high-quality, cohesive paragraph on the topic: "${topic}".

Specifications:
- Target Word Count: approximately ${wordCount} words (stay close, between ${Math.max(30, wordCount - 25)} and ${wordCount + 25} words).
- Paragraph Type: ${paragraphType} (e.g. Expository, Persuasive, Narrative, Descriptive, Compare/Contrast, Cause/Effect).
- Tone: ${tone} (e.g. Academic, Creative, Formal, Conversational).
- Target Grade Level: ${grade}. Vocabulary, sentence structure, and nuance MUST be tailored to this grade level.

Requirements:
- Have a strong, engaging Topic Sentence.
- Include 3-5 well-developed supporting sentences with concrete details, sensory imagery, or logical evidence.
- Include smooth transition words.
- Have a memorable Concluding/Clincher Sentence.
- Identify 3-4 grade-appropriate rich vocabulary words used in the paragraph and define them.

Return your response in STRICT valid JSON format:
{
  "paragraph": "string",
  "actualWordCount": 120,
  "topicSentence": "string",
  "supportingSentences": ["string"],
  "concludingSentence": "string",
  "vocabularyHighlights": [
    {
      "word": "string",
      "definition": "string",
      "contextInParagraph": "string"
    }
  ],
  "transitionWords": ["string"],
  "gradeLevelAnalysis": "string explaining how this meets ${grade} writing standards"
}
`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: promptText,
      config: {
        responseMimeType: 'application/json',
      },
    });

    const responseText = response.text || '{}';
    let parsedData;
    try {
      parsedData = JSON.parse(responseText);
    } catch {
      const cleaned = responseText.replace(/```json/g, '').replace(/```/g, '').trim();
      parsedData = JSON.parse(cleaned);
    }

    return res.json({ success: true, data: parsedData });
  } catch (error: any) {
    console.error('Paragraph Generation Error:', error);
    return res.status(500).json({ error: error.message || 'Failed to generate paragraph' });
  }
});

// 3. ESSAY WRITING ENDPOINT
app.post('/api/generate-essay', async (req, res) => {
  try {
    const {
      topic,
      essayType = 'Argumentative',
      wordCount = 500,
      grade = '9th Grade',
      thesisGuidance,
      citationStyle = 'MLA',
      studentName = 'Student',
    } = req.body;

    if (!topic || topic.trim().length === 0) {
      return res.status(400).json({ error: 'Please enter a topic for the essay.' });
    }

    const promptText = `
You are an expert essay mentor helping ${studentName}, who is in ${grade}.
The student needs a complete, well-structured, grade-tailored essay on: "${topic}".

Parameters:
- Essay Type: ${essayType} (e.g. Argumentative, Analytical, Narrative, Expository, Compare/Contrast, DBQ)
- Target Word Count: approximately ${wordCount} words (stay within +/- 15%)
- Grade Level: ${grade} (Vocabulary, thesis complexity, and rhetoric must match this level)
- Thesis Guidance provided by student: ${thesisGuidance || 'Develop a strong, persuasive thesis automatically'}
- Citation / Bibliography style: ${citationStyle}

Structural Requirements:
1. Engaging Title.
2. Introduction with an attention-grabbing hook, context/background, and a clear, arguable Thesis Statement.
3. Multi-paragraph body with clear topic sentences, evidence/examples, analysis/commentary, and smooth transitions. For argumentative essays, include counterargument & rebuttal.
4. Conclusion that synthesizes arguments without mere repetition and leaves a thought-provoking final insight.
5. Provide a realistic Works Cited / References list appropriate for this topic in ${citationStyle} format.
6. Provide an outline summary of each section.

Return STRICT valid JSON format:
{
  "title": "string",
  "thesisStatement": "string",
  "essay": "string with standard double-newline paragraph separation",
  "actualWordCount": 520,
  "readingTimeMinutes": 3,
  "outline": [
    {
      "section": "Introduction",
      "summary": "string",
      "keyPoints": ["string"]
    },
    {
      "section": "Body Paragraph 1",
      "summary": "string",
      "keyPoints": ["string"]
    },
    {
      "section": "Body Paragraph 2",
      "summary": "string",
      "keyPoints": ["string"]
    },
    {
      "section": "Conclusion",
      "summary": "string",
      "keyPoints": ["string"]
    }
  ],
  "vocabularyList": [
    {
      "word": "string",
      "definition": "string"
    }
  ],
  "worksCited": ["string"],
  "gradeLevelAlignment": "string notes on how this essay is tailored for ${grade}"
}
`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: promptText,
      config: {
        responseMimeType: 'application/json',
      },
    });

    const responseText = response.text || '{}';
    let parsedData;
    try {
      parsedData = JSON.parse(responseText);
    } catch {
      const cleaned = responseText.replace(/```json/g, '').replace(/```/g, '').trim();
      parsedData = JSON.parse(cleaned);
    }

    return res.json({ success: true, data: parsedData });
  } catch (error: any) {
    console.error('Essay Generation Error:', error);
    return res.status(500).json({ error: error.message || 'Failed to generate essay' });
  }
});

// 4. REAL-TIME GRAMMAR CHECKER ENDPOINT
app.post('/api/check-grammar', async (req, res) => {
  try {
    const { text, grade = '8th Grade', studentName = 'Student' } = req.body;

    if (!text || text.trim().length === 0) {
      return res.status(400).json({ error: 'Please enter text to check.' });
    }

    const promptText = `
You are an expert student writing editor and grammar coach for ${studentName} (${grade}).
Analyze the following student draft:

"""
${text}
"""

TASK:
Perform a comprehensive, constructive grammar, spelling, punctuation, and style review.
Evaluate based on standard English conventions and grade-level expectations (${grade}):
1. Calculate an Overall Writing Quality Score (0 to 100).
2. Assess Flesch-Kincaid readability / estimated grade level.
3. Detect grammar errors, punctuation mistakes, misspelled words, run-on sentences, awkward phrasing, and weak word choices.
4. For each issue, provide:
   - id: unique string
   - type: "grammar" | "spelling" | "punctuation" | "clarity" | "vocabulary"
   - originalText: exact substring from student draft that needs revision
   - suggestedReplacement: exact replacement text
   - explanation: why this correction is recommended, in friendly language for a ${grade} student
5. Provide a fully revised "correctedText" where all high-confidence corrections are applied.
6. Suggest 3-5 advanced vocabulary upgrades suitable for ${grade}.
7. Note 2-3 genuine strengths of the student's writing (positive encouragement).

Return STRICT valid JSON:
{
  "overallScore": 88,
  "readabilityGrade": "string e.g. Grade 8.2",
  "toneDetected": "string",
  "wordCount": 150,
  "correctedText": "string with all fixes incorporated",
  "positiveStrengths": ["string"],
  "issues": [
    {
      "id": "issue-1",
      "type": "grammar",
      "originalText": "string",
      "suggestedReplacement": "string",
      "explanation": "string"
    }
  ],
  "vocabularyUpgrades": [
    {
      "originalWord": "string",
      "suggestedWord": "string",
      "reason": "string"
    }
  ]
}
`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: promptText,
      config: {
        responseMimeType: 'application/json',
      },
    });

    const responseText = response.text || '{}';
    let parsedData;
    try {
      parsedData = JSON.parse(responseText);
    } catch {
      const cleaned = responseText.replace(/```json/g, '').replace(/```/g, '').trim();
      parsedData = JSON.parse(cleaned);
    }

    return res.json({ success: true, data: parsedData });
  } catch (error: any) {
    console.error('Grammar Check Error:', error);
    return res.status(500).json({ error: error.message || 'Failed to check grammar' });
  }
});

// Vite middleware in dev or static files in prod
async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';

  if (!isProd) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(Number(PORT), '0.0.0.0', () => {
    console.log(`StudySnap AI server running on port ${PORT} (${isProd ? 'production' : 'development'})`);
  });
}

startServer();
