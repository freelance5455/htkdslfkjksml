import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import type {
  ChatSession,
  ChatMessage,
  WithdrawalRequest,
  SafetyIncidentReport
} from './src/types';
import {
  ALL_SERVICES,
  CATEGORIES,
  INITIAL_ADMIN_CONFIG,
  INITIAL_CHAT_MESSAGES,
  INITIAL_CHAT_SESSIONS,
  INITIAL_NOTIFICATIONS,
  INITIAL_ORDERS,
  MOCK_DELIVERY_PARTNERS,
  MOCK_PROVIDERS,
  MOCK_USERS,
  INITIAL_WITHDRAWALS,
  INITIAL_SAFETY_INCIDENTS
} from './src/data/mockData.js';

// In-memory persistent database for server lifecycle
let categories = [...CATEGORIES];
let services = [...ALL_SERVICES];
let providers = [...MOCK_PROVIDERS];
let deliveryPartners = [...MOCK_DELIVERY_PARTNERS];
let users = [...MOCK_USERS];
let orders = [...INITIAL_ORDERS];
let chatSessions = [...INITIAL_CHAT_SESSIONS];
let chatMessages = { ...INITIAL_CHAT_MESSAGES };
let adminConfig = { ...INITIAL_ADMIN_CONFIG };
let withdrawals = [...INITIAL_WITHDRAWALS];
let safetyIncidents = [...INITIAL_SAFETY_INCIDENTS];
let notifications = [...INITIAL_NOTIFICATIONS];

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Routes
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', time: new Date().toISOString() });
  });

  // Master Data Endpoint
  app.get('/api/bootstrap', (req, res) => {
    res.json({
      categories,
      services,
      providers,
      deliveryPartners,
      users,
      orders,
      chatSessions,
      chatMessages,
      adminConfig,
      withdrawals,
      safetyIncidents,
      notifications
    });
  });

  // Create Order / Booking
  app.post('/api/orders', (req, res) => {
    const orderData = req.body;
    const newOrder = {
      ...orderData,
      id: `ord_${Date.now()}`,
      orderNumber: `ALLJI-${Math.floor(10000 + Math.random() * 90000)}`,
      status: orderData.category === 'ride' ? 'assigned' : 'accepted',
      deliveryOtp: `${Math.floor(1000 + Math.random() * 9000)}`,
      createdAt: new Date().toISOString()
    };

    orders.unshift(newOrder);

    // Create linked chat session for this order
    const chatSessionId = `chat_${Date.now()}`;
    const participantName = newOrder.deliveryPartnerName || newOrder.providerName || 'AllJi Partner';
    const participantRole: 'provider' | 'delivery' = newOrder.deliveryPartnerId ? 'delivery' : 'provider';
    const participantId = newOrder.deliveryPartnerId || newOrder.providerId || 'partner_generic';

    const newChatSession: ChatSession = {
      id: chatSessionId,
      orderId: newOrder.id,
      customerId: newOrder.customerId,
      customerName: newOrder.customerName,
      participantId,
      participantName,
      participantRole,
      freeMessagesAllowed: adminConfig.chatRules.freeMessageLimit || 5,
      freeMessagesUsed: 0,
      isPaidUnlocked: false,
      paidUnlockPrice: adminConfig.chatRules.unlockFee || 29,
      lastMessage: `Order ${newOrder.orderNumber} placed. Chat is open.`,
      updatedAt: new Date().toISOString()
    };

    chatSessions.unshift(newChatSession);
    chatMessages[chatSessionId] = [
      {
        id: `msg_init_${Date.now()}`,
        sessionId: chatSessionId,
        senderId: 'system',
        senderRole: 'admin',
        senderName: 'AllJi Super App',
        text: `Welcome! Order #${newOrder.orderNumber} initiated. You have ${adminConfig.chatRules.freeMessageLimit} free chat messages with ${participantName}.`,
        timestamp: new Date().toISOString(),
        isSystem: true
      }
    ];

    // Notification
    notifications.unshift({
      id: `notif_${Date.now()}`,
      userId: newOrder.customerId,
      title: `Order Placed: ${newOrder.orderNumber}`,
      message: `Your booking for ${newOrder.items?.[0]?.title || newOrder.category} has been confirmed!`,
      type: 'order',
      read: false,
      timestamp: 'Just now',
      linkId: newOrder.id
    });

    res.status(201).json({ order: newOrder, chatSession: newChatSession });
  });

  // Update Order Status
  app.patch('/api/orders/:id/status', (req, res) => {
    const { id } = req.params;
    const { status, note } = req.body;
    const index = orders.findIndex(o => o.id === id);
    if (index === -1) return res.status(404).json({ error: 'Order not found' });

    orders[index] = {
      ...orders[index],
      status
    };

    // If completed and payment was online or cash, credit provider earnings
    if (status === 'completed' && orders[index].providerId) {
      const provIndex = providers.findIndex(p => p.id === orders[index].providerId);
      if (provIndex !== -1) {
        const prov = providers[provIndex];
        const categoryCommission = adminConfig.platformCommissionDefaults[orders[index].category] || 15;
        const providerCut = Math.round(orders[index].itemTotal * (1 - categoryCommission / 100));
        providers[provIndex] = {
          ...prov,
          earnings: {
            ...prov.earnings,
            total: prov.earnings.total + providerCut,
            pendingPayout: prov.earnings.pendingPayout + providerCut
          }
        };
      }
    }

    res.json({ order: orders[index] });
  });

  // Cancel Order and Refund
  app.post('/api/orders/:id/cancel', (req, res) => {
    const { id } = req.params;
    const { reason } = req.body;
    const index = orders.findIndex(o => o.id === id);
    if (index === -1) return res.status(404).json({ error: 'Order not found' });

    const order = orders[index];
    const refundAmount = order.paymentStatus === 'paid' ? order.grandTotal : 0;

    orders[index] = {
      ...order,
      status: 'cancelled',
      cancelledAt: new Date().toISOString(),
      cancelReason: reason || 'Cancelled by customer',
      refundAmount
    };

    // If paid online or wallet, refund to customer's wallet
    if (refundAmount > 0) {
      const userIndex = users.findIndex(u => u.id === order.customerId);
      if (userIndex !== -1) {
        users[userIndex].walletBalance += refundAmount;
      }
    }

    notifications.unshift({
      id: `notif_${Date.now()}`,
      userId: order.customerId,
      title: `Order Cancelled: ${order.orderNumber}`,
      message: refundAmount > 0 ? `₹${refundAmount} has been refunded to your AllJi Wallet instantly.` : 'Your order has been cancelled.',
      type: 'order',
      read: false,
      timestamp: 'Just now',
      linkId: order.id
    });

    res.json({ order: orders[index], refundAmount });
  });

  // Review & Rating
  app.post('/api/orders/:id/rate', (req, res) => {
    const { id } = req.params;
    const { rating, reviewComment } = req.body;
    const index = orders.findIndex(o => o.id === id);
    if (index === -1) return res.status(404).json({ error: 'Order not found' });

    orders[index].rating = rating;
    orders[index].reviewComment = reviewComment;
    res.json({ order: orders[index] });
  });

  // Chat: Send Message (Enforces Free message limit)
  app.post('/api/chat/message', (req, res) => {
    const { sessionId, senderId, senderRole, senderName, text } = req.body;
    const sessionIndex = chatSessions.findIndex(s => s.id === sessionId);
    if (sessionIndex === -1) return res.status(404).json({ error: 'Chat session not found' });

    const session = chatSessions[sessionIndex];

    // Check message quota if customer is sending and not yet unlocked
    if (senderRole === 'customer') {
      const limit = session.freeMessagesAllowed || adminConfig.chatRules.freeMessageLimit || 5;
      if (!session.isPaidUnlocked && session.freeMessagesUsed >= limit) {
        return res.status(403).json({
          error: 'Free message limit reached',
          limitExceeded: true,
          freeMessagesAllowed: limit,
          freeMessagesUsed: session.freeMessagesUsed,
          unlockPrice: session.paidUnlockPrice || adminConfig.chatRules.unlockFee
        });
      }
      chatSessions[sessionIndex].freeMessagesUsed += 1;
    }

    const newMessage = {
      id: `msg_${Date.now()}`,
      sessionId,
      senderId,
      senderRole,
      senderName,
      text,
      timestamp: new Date().toISOString()
    };

    if (!chatMessages[sessionId]) chatMessages[sessionId] = [];
    chatMessages[sessionId].push(newMessage);
    chatSessions[sessionIndex].lastMessage = text;
    chatSessions[sessionIndex].updatedAt = new Date().toISOString();

    res.json({ message: newMessage, session: chatSessions[sessionIndex] });
  });

  // Chat: Unlock Paid Chat
  app.post('/api/chat/unlock', (req, res) => {
    const { sessionId, customerId } = req.body;
    const sessionIndex = chatSessions.findIndex(s => s.id === sessionId);
    if (sessionIndex === -1) return res.status(404).json({ error: 'Chat session not found' });

    const session = chatSessions[sessionIndex];
    const fee = session.paidUnlockPrice || adminConfig.chatRules.unlockFee || 29;

    // Deduct from customer wallet if available, or confirm payment
    const userIndex = users.findIndex(u => u.id === customerId);
    if (userIndex !== -1 && users[userIndex].walletBalance >= fee) {
      users[userIndex].walletBalance -= fee;
    }

    chatSessions[sessionIndex].isPaidUnlocked = true;

    // System confirmation message
    const sysMsg: ChatMessage = {
      id: `msg_unlock_${Date.now()}`,
      sessionId,
      senderId: 'system',
      senderRole: 'admin',
      senderName: 'AllJi Security',
      text: `🎉 Paid Chat Unlocked for ₹${fee}. Unlimited direct messaging is now enabled for this order.`,
      timestamp: new Date().toISOString(),
      isSystem: true
    };
    chatMessages[sessionId].push(sysMsg);

    res.json({ session: chatSessions[sessionIndex], message: sysMsg });
  });

  // Provider: Add Custom Service
  app.post('/api/providers/services', (req, res) => {
    const { providerId, serviceData } = req.body;
    const newService = {
      ...serviceData,
      id: `custom_${Date.now()}`,
      providerId,
      rating: 5.0
    };

    services.push(newService);
    const provIndex = providers.findIndex(p => p.id === providerId);
    if (provIndex !== -1) {
      providers[provIndex].customServices.push(newService);
    }

    res.status(201).json({ service: newService });
  });

  // Provider: Update Availability & Radius
  app.patch('/api/providers/:id', (req, res) => {
    const { id } = req.params;
    const provIndex = providers.findIndex(p => p.id === id);
    if (provIndex === -1) return res.status(404).json({ error: 'Provider not found' });

    providers[provIndex] = {
      ...providers[provIndex],
      ...req.body
    };

    res.json({ provider: providers[provIndex] });
  });

  // Provider: Request Withdrawal
  app.post('/api/withdrawals', (req, res) => {
    const { providerId, providerName, amount, bankAccount, ifscOrUpi } = req.body;
    const provIndex = providers.findIndex(p => p.id === providerId);
    if (provIndex === -1) return res.status(404).json({ error: 'Provider not found' });

    if (providers[provIndex].earnings.pendingPayout < amount) {
      return res.status(400).json({ error: 'Withdrawal amount exceeds available pending earnings' });
    }

    const newWithdrawal: WithdrawalRequest = {
      id: `w_${Date.now()}`,
      providerId,
      providerName,
      amount,
      bankAccount: bankAccount || 'N/A',
      ifscOrUpi: ifscOrUpi || 'user@upi',
      status: 'pending',
      requestedAt: new Date().toISOString()
    };

    withdrawals.unshift(newWithdrawal);
    providers[provIndex].earnings.pendingPayout -= amount;

    res.status(201).json({ withdrawal: newWithdrawal });
  });

  // Admin: Approve / Reject Withdrawal
  app.patch('/api/withdrawals/:id', (req, res) => {
    const { id } = req.params;
    const { status } = req.body; // 'approved' | 'rejected'
    const index = withdrawals.findIndex(w => w.id === id);
    if (index === -1) return res.status(404).json({ error: 'Withdrawal not found' });

    withdrawals[index].status = status;
    withdrawals[index].processedAt = new Date().toISOString();

    if (status === 'approved') {
      const provIndex = providers.findIndex(p => p.id === withdrawals[index].providerId);
      if (provIndex !== -1) {
        providers[provIndex].earnings.withdrawn += withdrawals[index].amount;
      }
    } else if (status === 'rejected') {
      // Return back to pending payout
      const provIndex = providers.findIndex(p => p.id === withdrawals[index].providerId);
      if (provIndex !== -1) {
        providers[provIndex].earnings.pendingPayout += withdrawals[index].amount;
      }
    }

    res.json({ withdrawal: withdrawals[index] });
  });

  // Admin: Update Rules & Commissions
  app.post('/api/admin/config', (req, res) => {
    adminConfig = {
      ...adminConfig,
      ...req.body
    };
    res.json({ adminConfig });
  });

  // Emergency SOS Alert
  app.post('/api/safety/sos', (req, res) => {
    const { userId, userName, userPhone, location, coordinates, orderId } = req.body;
    const incident: SafetyIncidentReport = {
      id: `sos_${Date.now()}`,
      userId,
      userName,
      userPhone,
      orderId,
      location: location || 'Current GPS Location',
      coordinates,
      emergencyType: 'sos',
      status: 'active',
      timestamp: new Date().toISOString(),
      notes: 'EMERGENCY SOS TRIGGERED: Dispatching high priority safety alert to nearest police and emergency contacts.'
    };

    safetyIncidents.unshift(incident);

    notifications.unshift({
      id: `notif_sos_${Date.now()}`,
      userId,
      title: '🚨 Emergency SOS Dispatched',
      message: `Emergency response notified for ${location}. Live coordinates dispatched. Stay calm, help is on the way.`,
      type: 'safety',
      read: false,
      timestamp: 'Just now'
    });

    res.status(201).json({ incident, alertSent: true });
  });

  // Delivery Partner Location & Status update
  app.patch('/api/delivery/:id/location', (req, res) => {
    const { id } = req.params;
    const { lat, lng, locality } = req.body;
    const index = deliveryPartners.findIndex(d => d.id === id);
    if (index !== -1) {
      deliveryPartners[index].currentLocation = { lat, lng, locality };
      res.json({ deliveryPartner: deliveryPartners[index] });
    } else {
      res.status(404).json({ error: 'Delivery partner not found' });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`AllJi Server running on http://localhost:${PORT}`);
  });
}

startServer();
