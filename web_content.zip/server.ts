import 'dotenv/config';
import express from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.PORT) || 3000;

const ai = process.env.GEMINI_API_KEY
  ? new GoogleGenAI({
      apiKey: process.env.GEMINI_API_KEY,
      apiVersion: 'v1beta',
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    })
  : null;

const aiAlpha = process.env.GEMINI_API_KEY
  ? new GoogleGenAI({
      apiKey: process.env.GEMINI_API_KEY,
      apiVersion: 'v1alpha',
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    })
  : null;

type VoiceId = 'maya-us';

const VOICE_PRESETS: Record<VoiceId, { voiceName: string; style: string }> = {
  'maya-us': {
    voiceName: 'Zephyr',
    style:
      'US English, soft-voiced, calm, warm African American female accessibility screen reader, gentle reassuring studio delivery, unhurried natural articulation',
  },
};

function resolveVoicePreset(_rawVoiceId?: unknown): {
  voiceId: VoiceId;
  voiceName: string;
  style: string;
} {
  return { voiceId: 'maya-us', ...VOICE_PRESETS['maya-us'] };
}

// Lightweight bounded LRU cache keyed by voiceId + text
const ttsCache = new Map<string, string>();
const MAX_TTS_CACHE = 160;

function getCachedAudio(key: string): string | undefined {
  const existing = ttsCache.get(key);
  if (!existing) return undefined;
  ttsCache.delete(key);
  ttsCache.set(key, existing);
  return existing;
}

function setCachedAudio(key: string, audioBase64: string) {
  if (ttsCache.size >= MAX_TTS_CACHE) {
    const oldestKey = ttsCache.keys().next().value;
    if (oldestKey !== undefined) ttsCache.delete(oldestKey);
  }
  ttsCache.set(key, audioBase64);
}

type TtsStrategy = 'v1beta-meta' | 'v1alpha-meta' | 'v1beta-prompt';
let preferredStrategy: TtsStrategy | null = null;
const inFlightTts = new Map<string, Promise<string | undefined>>();

async function callStrategy(
  strategy: TtsStrategy,
  cleanText: string,
  voiceName: string,
  style: string
): Promise<string | undefined> {
  if (strategy === 'v1beta-meta' && ai) {
    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash-lite-tts',
      contents: [
        {
          role: 'user',
          parts: [
            {
              text: cleanText,
              speechMetadata: { style },
            },
          ],
        },
      ],
      config: {
        responseModalities: ['AUDIO'],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName },
          },
        },
      },
    });
    return response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
  }

  if (strategy === 'v1alpha-meta' && aiAlpha) {
    const response = await aiAlpha.models.generateContent({
      model: 'gemini-3.8-flash-lite-tts',
      contents: [
        {
          role: 'user',
          parts: [
            {
              text: cleanText,
              speechMetadata: { style },
            },
          ],
        },
      ],
      config: {
        responseModalities: ['AUDIO'],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName },
          },
        },
      },
    });
    return response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
  }

  if (ai) {
    const fallbackResp = await ai.models.generateContent({
      model: 'gemini-3.8-flash-lite-tts',
      contents: [
        {
          role: 'user',
          parts: [{ text: `Say in a ${style}: ${cleanText}` }],
        },
      ],
      config: {
        responseModalities: ['AUDIO'],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName },
          },
        },
      },
    });
    return fallbackResp.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
  }

  return undefined;
}

let rateLimitedUntil = 0;

async function generateVoiceTts(
  cacheKey: string,
  cleanText: string,
  voiceName: string,
  style: string
): Promise<{ audio?: string; error?: string; rateLimited?: boolean }> {
  if (!ai) return { error: 'TTS service not configured' };

  if (Date.now() < rateLimitedUntil) {
    return { error: 'TTS quota cooldown active', rateLimited: true };
  }

  const existing = inFlightTts.get(cacheKey);
  if (existing) {
    const audio = await existing;
    return audio
      ? { audio }
      : { error: 'Concurrent TTS request failed', rateLimited: Date.now() < rateLimitedUntil };
  }

  let lastError = 'Empty TTS audio payload';
  let hitRateLimit = false;

  const task = (async () => {
    const order: TtsStrategy[] = preferredStrategy
      ? [
          preferredStrategy,
          ...(['v1beta-meta', 'v1alpha-meta', 'v1beta-prompt'] as TtsStrategy[]).filter(
            (s) => s !== preferredStrategy
          ),
        ]
      : ['v1beta-meta', 'v1alpha-meta', 'v1beta-prompt'];

    for (const strategy of order) {
      try {
        const audio = await callStrategy(strategy, cleanText, voiceName, style);
        if (audio) {
          preferredStrategy = strategy;
          return audio;
        }
      } catch (err) {
        const msg = err instanceof Error ? err.message : String(err);
        lastError = msg;
        if (/429|RESOURCE_EXHAUSTED|403|PERMISSION_DENIED/i.test(msg)) {
          if (/429|RESOURCE_EXHAUSTED/i.test(msg)) {
            hitRateLimit = true;
            rateLimitedUntil = Date.now() + 5 * 60 * 1000;
          }
          break; // Never burn quota retrying strategies on quota/permission errors
        }
      }
    }
    return undefined;
  })();

  inFlightTts.set(cacheKey, task);
  try {
    const audio = await task;
    return audio ? { audio } : { error: lastError, rateLimited: hitRateLimit };
  } finally {
    inFlightTts.delete(cacheKey);
  }
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '64kb' }));

  app.post('/api/tts', async (req, res) => {
    const rawText = typeof req.body?.text === 'string' ? req.body.text.trim() : '';
    if (!rawText) {
      res.status(400).json({ error: 'Text is required' });
      return;
    }

    const cleanText = rawText.slice(0, 360);
    const { voiceId, voiceName, style } = resolveVoicePreset(req.body?.voiceId);
    const cacheKey = `${voiceId}::${cleanText}`;

    const cached = getCachedAudio(cacheKey);
    if (cached) {
      res.json({ audioBase64: cached, mimeType: 'audio/wav', voiceId, cached: true });
      return;
    }

    if (!ai) {
      res.status(503).json({ fallback: true, voiceId, error: 'TTS service not configured' });
      return;
    }

    try {
      const result = await generateVoiceTts(cacheKey, cleanText, voiceName, style);

      if (!result.audio) {
        res.status(result.rateLimited ? 429 : 502).json({
          fallback: true,
          rateLimited: Boolean(result.rateLimited),
          voiceId,
          error: result.error || 'Empty TTS audio payload',
        });
        return;
      }

      setCachedAudio(cacheKey, result.audio);
      res.json({ audioBase64: result.audio, mimeType: 'audio/wav', voiceId, cached: false });
    } catch (error) {
      const message = error instanceof Error ? error.message : 'TTS generation failed';
      res.status(502).json({ fallback: true, voiceId, error: message });
    }
  });

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Retro Game System running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
