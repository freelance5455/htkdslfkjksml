import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';
import { createServer as createViteServer } from 'vite';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = Number(process.env.PORT) || 3000;

app.use(express.json({ limit: '25mb' }));
app.use(express.urlencoded({ extended: true, limit: '25mb' }));

// Server-side Gemini AI client initialization
const apiKey = process.env.GEMINI_API_KEY || '';
const ai = new GoogleGenAI({
  apiKey,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

// Helper to extract base64 data and mimeType
function parseBase64Image(dataUri: string) {
  const match = dataUri.match(/^data:([^;]+);base64,(.+)$/);
  if (match) {
    return { mimeType: match[1], base64: match[2] };
  }
  return { mimeType: 'image/png', base64: dataUri };
}

// Health check
app.get('/api/health', (_req, res) => {
  res.json({
    status: 'ok',
    hasApiKey: Boolean(apiKey && apiKey !== 'MY_GEMINI_API_KEY'),
    timestamp: new Date().toISOString(),
  });
});

// Endpoint: Generate Image using text prompt
app.post('/api/image/generate', async (req, res) => {
  try {
    const { prompt, aspectRatio = '1:1', imageSize = '1K' } = req.body;

    if (!prompt || typeof prompt !== 'string') {
      res.status(400).json({ error: 'Prompt text is required' });
      return;
    }

    if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
      res.status(400).json({
        error: 'Gemini API key is not configured in environment variables. Please check the Secrets panel.',
      });
      return;
    }

    // Supported models in priority order for image generation
    const modelsToTry = [
      'gemini-3.1-flash-image',
      'gemini-3.1-flash-image-preview',
      'gemini-3.1-flash-lite-image',
    ];

    let lastError: any = null;
    let generatedImageUrl: string | null = null;
    let modelUsed = '';

    for (const modelName of modelsToTry) {
      try {
        const response = await ai.models.generateContent({
          model: modelName,
          contents: {
            parts: [{ text: prompt }],
          },
          config: {
            imageConfig: {
              aspectRatio: aspectRatio as any,
              imageSize: (imageSize as any) || '1K',
            },
          },
        });

        if (response.candidates?.[0]?.content?.parts) {
          for (const part of response.candidates[0].content.parts) {
            if (part.inlineData?.data) {
              const mime = part.inlineData.mimeType || 'image/png';
              generatedImageUrl = `data:${mime};base64,${part.inlineData.data}`;
              modelUsed = modelName;
              break;
            }
          }
        }

        if (generatedImageUrl) break;
      } catch (err: any) {
        lastError = err;
        console.warn(`Attempt with ${modelName} failed:`, err?.message || err);
      }
    }

    if (generatedImageUrl) {
      res.json({
        success: true,
        imageUrl: generatedImageUrl,
        prompt,
        modelUsed,
      });
      return;
    }

    res.status(502).json({
      error: lastError?.message || 'Failed to generate image from model. Please try again.',
      details: lastError?.statusText || 'No image data returned',
    });
  } catch (error: any) {
    console.error('Error in /api/image/generate:', error);
    res.status(500).json({
      error: error?.message || 'Internal server error while generating image',
    });
  }
});

// Endpoint: Edit existing image using text instructions
app.post('/api/image/edit', async (req, res) => {
  try {
    const { image, prompt, aspectRatio = '1:1' } = req.body;

    if (!image || !prompt) {
      res.status(400).json({ error: 'Both image data and edit prompt are required' });
      return;
    }

    if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
      res.status(400).json({
        error: 'Gemini API key is not configured in environment variables. Please check the Secrets panel.',
      });
      return;
    }

    const { mimeType, base64 } = parseBase64Image(image);

    const modelsToTry = [
      'gemini-3.1-flash-image',
      'gemini-3.1-flash-image-preview',
      'gemini-3.1-flash-lite-image',
    ];

    let lastError: any = null;
    let editedImageUrl: string | null = null;
    let modelUsed = '';

    for (const modelName of modelsToTry) {
      try {
        const response = await ai.models.generateContent({
          model: modelName,
          contents: {
            parts: [
              {
                inlineData: {
                  data: base64,
                  mimeType,
                },
              },
              {
                text: prompt,
              },
            ],
          },
          config: {
            imageConfig: {
              aspectRatio: aspectRatio as any,
            },
          },
        });

        if (response.candidates?.[0]?.content?.parts) {
          for (const part of response.candidates[0].content.parts) {
            if (part.inlineData?.data) {
              const mime = part.inlineData.mimeType || 'image/png';
              editedImageUrl = `data:${mime};base64,${part.inlineData.data}`;
              modelUsed = modelName;
              break;
            }
          }
        }

        if (editedImageUrl) break;
      } catch (err: any) {
        lastError = err;
        console.warn(`Edit attempt with ${modelName} failed:`, err?.message || err);
      }
    }

    if (editedImageUrl) {
      res.json({
        success: true,
        imageUrl: editedImageUrl,
        prompt,
        modelUsed,
      });
      return;
    }

    res.status(502).json({
      error: lastError?.message || 'Failed to edit image with model. Please try again.',
      details: lastError?.statusText || 'No edited image returned',
    });
  } catch (error: any) {
    console.error('Error in /api/image/edit:', error);
    res.status(500).json({
      error: error?.message || 'Internal server error while editing image',
    });
  }
});

// Dev server vs Production static serving
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running at http://0.0.0.0:${PORT}`);
  });
}

startServer();
