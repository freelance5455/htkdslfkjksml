import express from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT) : 3000;

// Generous body limit for high-res images, screen captures, and documents
app.use(express.json({ limit: '60mb' }));
app.use(express.urlencoded({ limit: '60mb', extended: true }));

// Initialize GoogleGenAI SDK on server side
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

interface AttachmentItem {
  name: string;
  type: 'image' | 'file' | 'screen';
  mimeType: string;
  base64?: string;
  text?: string;
}

interface IncomingMessage {
  role: 'user' | 'model' | 'assistant';
  content?: string;
  attachments?: AttachmentItem[];
  parts?: Array<{
    text?: string;
    inlineData?: {
      mimeType: string;
      data: string;
    };
  }>;
}

function buildSystemInstruction(persona?: string, tone?: string, customPrompt?: string): string {
  let personaPrompt = `Aap ek super smart, multi-talented, friendly aur dildaar AI Assistant ho ('Nova Mast AI').
Aap natural Hinglish (Hindi + English), Hindi aur English me proficient ho.
Aapka mission hai: Har user ko ekdum 'mst mst', zabardast, entertaining, aur deeply useful answers dena!
Aap code likh sakte ho, photos aur screen analysis kar sakte ho, voice conversations samajh sakte ho, phone tasks me guide kar sakte ho, aur documents summarize kar sakte ho.
Use expressive emojis (🚀, 🔥, 💡, ⚡, ✨, 😎, 📱), clean Markdown with bold headings, bullet points, and code blocks with syntax tags.`;

  if (persona === 'screen_accessibility') {
    personaPrompt = `Aap ek expert Screen Reader, Accessibility aur Vision AI Assistant ho.
Aapka kaam hai user dwara bheje gaye screen captures, screenshots, phone screens aur documents ko padhna aur visually samjhana.
- Screen par kya dikh raha hai (UI components, text, buttons, alerts, forms, icons).
- OCR: Screen ke har text ko accurately read aur transcribe karein.
- User ko step-by-step guidance dein ki unhe kahan click ya tap karna chahiye.
- Clarity, kindness aur accessible language me jawab dein.`;
  } else if (persona === 'phone_assistant') {
    personaPrompt = `Aap user ke dedicated Mobile Phone Assistant ho.
User ko phone settings, app recommendations, SMS/Message drafting, reminders, calling guidance, battery & storage optimization, aur shortcuts me expert guidance do.
Fast, structured, aur action-oriented answers do.`;
  } else if (persona === 'coder') {
    personaPrompt = `You are a world-class Full-Stack Software Engineer & Code Guru.
Provide ultra-clean, secure, production-grade code, detailed explanations of bugs, and modern best practices. Use formatted Markdown code blocks.`;
  } else if (persona === 'tutor') {
    personaPrompt = `Aap ek world-class personal tutor aur homework solver ho.
Kisi bhi subject (Math, Science, History, Coding, Literature) ke mushkil concepts ko simple real-world examples aur step-by-step breakdown ke saath samjhao.`;
  } else if (persona === 'creative') {
    personaPrompt = `Aap ek imaginative Creative Writer, Storyteller aur Scriptwriter ho.
Shayari, catchy social media captions, reels scripts, stories, aur jokes likhne me master ho!`;
  }

  let tonePrompt = '';
  if (tone === 'chatpata') {
    tonePrompt = 'Style: Ekdum energetic, humorous, chatpata aur mast conversational Hinglish!';
  } else if (tone === 'concise') {
    tonePrompt = 'Style: Short, crisp, direct bullet points. No unnecessary fluff.';
  } else if (tone === 'detailed') {
    tonePrompt = 'Style: Comprehensive, deep, in-depth explanation with step-by-step insights.';
  } else if (tone === 'shuddh_hindi') {
    tonePrompt = 'Style: Shuddh aur prabhavi Hindi bhasha me samvad karein.';
  } else if (tone === 'english') {
    tonePrompt = 'Style: Professional, polite, clear modern English.';
  }

  const finalParts = [personaPrompt];
  if (tonePrompt) finalParts.push(tonePrompt);
  if (customPrompt && typeof customPrompt === 'string') finalParts.push(customPrompt);

  return finalParts.join('\n\n');
}

function formatContents(messages: IncomingMessage[]) {
  // Keep the most recent 16 messages to prevent unbounded latency
  const trimmed = messages.slice(-16);
  const total = trimmed.length;

  return trimmed.map((m, index) => {
    const role = m.role === 'user' ? 'user' : 'model';
    const parts: Array<{
      text?: string;
      inlineData?: {
        mimeType: string;
        data: string;
      };
    }> = [];

    // Only attach full base64 images for messages in the last 2 turns
    const isRecentTurn = index >= total - 3;

    // Add attachments if present
    if (m.attachments && Array.isArray(m.attachments)) {
      for (const att of m.attachments) {
        if (isRecentTurn && att.base64 && (att.type === 'image' || att.type === 'screen' || att.mimeType.startsWith('image/'))) {
          const cleanBase64 = att.base64.replace(/^data:[^;]+;base64,/, '');
          parts.push({
            inlineData: {
              mimeType: att.mimeType || 'image/jpeg',
              data: cleanBase64,
            },
          });
        } else if (isRecentTurn && att.base64 && att.mimeType === 'application/pdf') {
          const cleanBase64 = att.base64.replace(/^data:[^;]+;base64,/, '');
          parts.push({
            inlineData: {
              mimeType: 'application/pdf',
              data: cleanBase64,
            },
          });
        } else if (att.text) {
          parts.push({
            text: `[Attached File: ${att.name || 'document'} (${att.mimeType || 'text'})]\n\`\`\`\n${att.text.slice(0, 5000)}\n\`\`\``,
          });
        } else {
          parts.push({
            text: `[Attachment: ${att.name || 'file'}]`,
          });
        }
      }
    }

    // Add user text message
    if (m.content) {
      parts.push({ text: m.content });
    }

    // Fallback if parts is empty
    if (parts.length === 0) {
      parts.push({ text: '...' });
    }

    return {
      role,
      parts,
    };
  });
}

// Direct file serving for bot.py / main.py
app.get(['/bot.py', '/main.py'], (req, res) => {
  const filename = req.path.replace('/', '');
  const filePath = path.resolve(__dirname, filename);
  if (fs.existsSync(filePath)) {
    res.setHeader('Content-Type', 'text/x-python; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    return res.sendFile(filePath);
  }
  res.status(404).send('File not found');
});

// Candidate fast multimodal models with automatic resilience fallback
const CANDIDATE_MODELS = [
  'gemini-3.6-flash',
  'gemini-3-flash-preview',
  'gemini-3.5-flash',
  'gemini-3.8-flash',
];

// SSE Streaming chat endpoint with Multimodal support
app.post('/api/chat/stream', async (req, res) => {
  const { messages, persona, tone, systemPrompt } = req.body;

  if (!messages || !Array.isArray(messages)) {
    return res.status(400).json({ error: 'Messages array is required' });
  }

  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');

  try {
    const baseInstruction = buildSystemInstruction(persona, tone, systemPrompt);
    const contents = formatContents(messages);

    let responseStream = null;
    let lastError: unknown = null;

    for (const model of CANDIDATE_MODELS) {
      try {
        responseStream = await ai.models.generateContentStream({
          model,
          contents,
          config: {
            systemInstruction: baseInstruction,
          },
        });
        if (responseStream) break;
      } catch (err: unknown) {
        lastError = err;
        console.warn(`Model ${model} temporarily unavailable, trying next...`);
      }
    }

    if (!responseStream) {
      throw lastError || new Error('All AI models are currently unavailable');
    }

    for await (const chunk of responseStream) {
      const text = chunk.text;
      if (text) {
        res.write(`data: ${JSON.stringify({ text })}\n\n`);
      }
    }

    res.write(`data: ${JSON.stringify({ done: true })}\n\n`);
    res.end();
  } catch (err: unknown) {
    console.error('Gemini stream error:', err);
    const errorMessage = err instanceof Error ? err.message : 'Unknown AI generation error';
    res.write(`data: ${JSON.stringify({ error: errorMessage })}\n\n`);
    res.end();
  }
});

// Standard non-streaming chat endpoint with Multimodal support
app.post('/api/chat', async (req, res) => {
  const { messages, persona, tone, systemPrompt } = req.body;

  if (!messages || !Array.isArray(messages)) {
    return res.status(400).json({ error: 'Messages array is required' });
  }

  try {
    const baseInstruction = buildSystemInstruction(persona, tone, systemPrompt);
    const contents = formatContents(messages);

    let response = null;
    let lastError: unknown = null;

    for (const model of CANDIDATE_MODELS) {
      try {
        response = await ai.models.generateContent({
          model,
          contents,
          config: {
            systemInstruction: baseInstruction,
          },
        });
        if (response) break;
      } catch (err: unknown) {
        lastError = err;
        console.warn(`Model ${model} temporarily unavailable, trying next...`);
      }
    }

    if (!response) {
      throw lastError || new Error('All AI models are currently unavailable');
    }

    res.json({ text: response.text });
  } catch (err: unknown) {
    console.error('Gemini error:', err);
    const errorMessage = err instanceof Error ? err.message : 'Unknown error';
    res.status(500).json({ error: errorMessage });
  }
});

async function startServer() {
  const isProduction = process.env.NODE_ENV === 'production';

  if (!isProduction) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true, hmr: false },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Nova AI Server running at http://0.0.0.0:${PORT}`);
  });
}

startServer();
