/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { GoogleGenAI, ThinkingLevel } from '@google/genai';
import { createServer as createViteServer } from 'vite';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = Number(process.env.PORT) || 3000;

app.use(express.json());

// Prioritized supported models for automatic resilience & quota fallback
// gemini-3.1-flash-lite has an independent quota pool, low latency, and high availability
const CANDIDATE_MODELS = [
  'gemini-3.1-flash-lite',
  'gemini-3.8-flash',
  'gemini-flash-latest',
];

let activeModelName = CANDIDATE_MODELS[0];

// Helper to retrieve a freshly configured GoogleGenAI client
function getGenAIClient(): { client: GoogleGenAI | null; keyPresent: boolean } {
  const apiKey = process.env.GEMINI_API_KEY || '';
  if (!apiKey) {
    return { client: null, keyPresent: false };
  }
  const client = new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
  return { client, keyPresent: true };
}

// Resilient execution with model fallback & retry for transient load spikes / quota limits
async function generateContentWithFallback(
  client: GoogleGenAI,
  params: {
    contents: any;
    systemInstruction?: string;
  }
): Promise<{ text: string; modelUsed: string }> {
  let lastError: any = null;

  for (const model of CANDIDATE_MODELS) {
    const maxAttemptsForModel = 2;

    for (let attempt = 1; attempt <= maxAttemptsForModel; attempt++) {
      try {
        const config: any = {
          systemInstruction: params.systemInstruction,
          temperature: 0.7,
        };

        // Configure thinking level on models that support it
        if (model.includes('3.8') || model.includes('4')) {
          config.thinkingConfig = { thinkingLevel: ThinkingLevel.LOW };
        }

        const response = await client.models.generateContent({
          model,
          contents: params.contents,
          config,
        });

        activeModelName = model;
        const text = response.text || '';
        return { text, modelUsed: model };
      } catch (err: any) {
        lastError = err;
        const msg = String(err?.message || '');

        const isQuotaExhausted =
          msg.includes('429') ||
          msg.includes('RESOURCE_EXHAUSTED') ||
          msg.includes('Quota exceeded') ||
          msg.includes('rate-limit');

        const isTransient503 =
          msg.includes('503') ||
          msg.includes('UNAVAILABLE') ||
          msg.includes('high demand') ||
          msg.includes('spikes');

        // If quota is exhausted on this specific model, break immediately to the next candidate model
        if (isQuotaExhausted) {
          console.warn(`[ELYSIA AI] Quota exhausted on ${model}. Falling back to next candidate model...`);
          break;
        }

        // If transient 503 and we have an attempt left on this model, pause briefly
        if (isTransient503 && attempt < maxAttemptsForModel) {
          console.warn(`[ELYSIA AI] High demand on ${model} (attempt ${attempt}). Retrying in 1.2s...`);
          await new Promise((r) => setTimeout(r, 1200));
          continue;
        }

        // Other errors: break to try the next candidate model
        break;
      }
    }
  }

  throw lastError;
}

// 1. Status Check Endpoint (fast local check)
app.get('/api/status', (req: Request, res: Response) => {
  const { keyPresent } = getGenAIClient();
  res.json({
    ok: true,
    geminiConfigured: keyPresent,
    model: activeModelName,
    serverTime: new Date().toISOString(),
  });
});

// 2. Test Connection Endpoint (performs a live roundtrip ping to Gemini API)
app.get('/api/test-connection', async (req: Request, res: Response) => {
  const startTime = Date.now();
  const { client, keyPresent } = getGenAIClient();

  if (!keyPresent || !client) {
    res.status(503).json({
      ok: false,
      error: 'GEMINI_API_KEY is not configured in the server environment. Please configure it in Settings > Secrets.',
      code: 'MISSING_API_KEY',
      latencyMs: Date.now() - startTime,
    });
    return;
  }

  try {
    const result = await generateContentWithFallback(client, {
      contents: 'Ping. Reply with PONG.',
    });

    const latencyMs = Date.now() - startTime;
    res.json({
      ok: true,
      latencyMs,
      model: result.modelUsed,
      sampleReply: result.text.trim() || 'OK',
    });
  } catch (err: unknown) {
    const latencyMs = Date.now() - startTime;
    const errorMessage = err instanceof Error ? err.message : 'Unknown connection error';
    console.error('[ELYSIA /api/test-connection error]:', err);

    let code = 'API_ERROR';
    let humanReadable = errorMessage;

    if (errorMessage.includes('API_KEY_INVALID') || errorMessage.includes('403') || errorMessage.includes('401')) {
      code = 'INVALID_API_KEY';
      humanReadable = 'Invalid Gemini API key. Please check your key in Settings > Secrets.';
    } else if (errorMessage.includes('429') || errorMessage.includes('RESOURCE_EXHAUSTED')) {
      code = 'RATE_LIMIT';
      humanReadable = 'Daily request quota exceeded on all candidate models. Please retry later or configure billing.';
    } else if (errorMessage.includes('503') || errorMessage.includes('high demand') || errorMessage.includes('UNAVAILABLE')) {
      code = 'HIGH_DEMAND';
      humanReadable = 'Gemini model is currently experiencing high demand. Please try again in a few seconds.';
    }

    res.status(502).json({
      ok: false,
      error: humanReadable,
      code,
      latencyMs,
    });
  }
});

// 3. Chat / Completion Endpoint
app.post('/api/chat', async (req: Request, res: Response) => {
  try {
    const { message, history, language } = req.body;

    if (!message || typeof message !== 'string') {
      res.status(400).json({ success: false, error: 'A valid text prompt is required.' });
      return;
    }

    const { client, keyPresent } = getGenAIClient();

    if (!keyPresent || !client) {
      res.status(503).json({
        success: false,
        error: 'Gemini API key is not configured on this server. Please attach GEMINI_API_KEY in the Settings > Secrets panel.',
      });
      return;
    }

    const systemInstruction = `You are ELYSIA — a futuristic, calm, intelligent, confident, and respectful personal AI assistant. 
Tagline: "Your World. Your Intelligence."
Personality guidelines:
- Natural, conversational, and direct rather than robotic or overly verbose.
- Support English, Bengali, and Hindi fluidly.
- When answering general questions, provide clear, concise, and structured explanations.
- Never state that you are an LLM or mention other companies; your identity is ELYSIA.
- If asked about what you can do, explain your capabilities: answering questions, safe math calculations, web search, message drafting, translation, and Android integration assistance.
- If the user interacts in Bengali or Hindi, respond naturally in that language or dialect. Current preferred user language setting: ${language || 'en-US'}.`;

    // Construct conversation contents with history
    const contents: Array<{ role: string; parts: Array<{ text: string }> }> = [];

    if (Array.isArray(history)) {
      for (const item of history) {
        if (item.content && (item.role === 'user' || item.role === 'assistant')) {
          contents.push({
            role: item.role === 'assistant' ? 'model' : 'user',
            parts: [{ text: item.content }],
          });
        }
      }
    }

    // Append current turn
    contents.push({
      role: 'user',
      parts: [{ text: message }],
    });

    const result = await generateContentWithFallback(client, {
      contents,
      systemInstruction,
    });

    res.json({
      success: true,
      text: result.text || 'I processed your request, but no text output was produced.',
      model: result.modelUsed,
    });
  } catch (err: unknown) {
    console.error('[ELYSIA /api/chat error]:', err);
    const errorMessage = err instanceof Error ? err.message : 'Unknown AI processing error';

    if (errorMessage.includes('API_KEY_INVALID') || errorMessage.includes('401') || errorMessage.includes('403')) {
      res.status(401).json({
        success: false,
        error: 'Invalid Gemini API key. Please verify your GEMINI_API_KEY in the Settings > Secrets panel.',
      });
      return;
    }

    if (errorMessage.includes('429') || errorMessage.includes('RESOURCE_EXHAUSTED')) {
      res.status(429).json({
        success: false,
        error: 'Gemini free tier quota limit reached on this project. Please wait for quota refresh or link billing.',
      });
      return;
    }

    if (errorMessage.includes('503') || errorMessage.includes('high demand') || errorMessage.includes('UNAVAILABLE')) {
      res.status(503).json({
        success: false,
        error: 'Gemini neural engine is currently experiencing high demand. Please try your question again in a moment.',
      });
      return;
    }

    res.status(500).json({
      success: false,
      error: errorMessage,
    });
  }
});

// 4. Mount Vite middleware in development or static dist in production
async function startServer() {
  const isProduction = process.env.NODE_ENV === 'production';

  if (!isProduction) {
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: process.env.DISABLE_HMR !== 'true',
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[ELYSIA Core Server] listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
