import 'dotenv/config';
import express from 'express';
import fs from 'node:fs/promises';
import http from 'node:http';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { GoogleGenAI } from '@google/genai';
import { createServer as createViteServer } from 'vite';
import { WebSocket, WebSocketServer } from 'ws';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const ALLOWED_CHAT_MODELS = new Set([
  'gemini-4-hydrogen',
  'gemini-3.1-flash-lite',
]);

type BikeModelType = 'cg_titan_160' | 'cg_fan_160' | 'bros_160';

interface StoredPlayer {
  id: string;
  name: string;
  bikeModel: BikeModelType;
  friends: string[];
  createdAt: number;
}

interface SocialStoreData {
  players: Record<string, StoredPlayer>;
}

interface RoomMember {
  playerId: string;
  name: string;
  bikeModel: BikeModelType;
  ws: WebSocket;
  state: Record<string, unknown> | null;
}

interface ActiveRoom {
  roomId: string;
  hostId: string;
  doorOpen: boolean;
  members: Map<string, RoomMember>;
  createdAt: number;
}

const DATA_DIR = path.resolve(__dirname, '.data');
const STORE_PATH = path.join(DATA_DIR, 'motowin-social.json');

const playersStore = new Map<string, StoredPlayer>();
const onlineSockets = new Map<string, WebSocket>();
const playerRoomMap = new Map<string, string>();
const activeRooms = new Map<string, ActiveRoom>();

let saveTimer: NodeJS.Timeout | null = null;

async function loadSocialStore() {
  try {
    const raw = await fs.readFile(STORE_PATH, 'utf8');
    const parsed = JSON.parse(raw) as SocialStoreData;
    if (parsed && parsed.players && typeof parsed.players === 'object') {
      for (const [id, p] of Object.entries(parsed.players)) {
        if (p && typeof p.id === 'string') {
          playersStore.set(id, {
            id: p.id,
            name: typeof p.name === 'string' && p.name.trim() ? p.name.trim().slice(0, 20) : 'Piloto 160',
            bikeModel: p.bikeModel === 'cg_fan_160' || p.bikeModel === 'bros_160' ? p.bikeModel : 'cg_titan_160',
            friends: Array.isArray(p.friends) ? p.friends.filter((f) => typeof f === 'string') : [],
            createdAt: typeof p.createdAt === 'number' ? p.createdAt : Date.now(),
          });
        }
      }
    }
  } catch {
    // First run or missing file — starts cleanly
  }
}

function scheduleSaveStore() {
  if (saveTimer) clearTimeout(saveTimer);
  saveTimer = setTimeout(async () => {
    try {
      await fs.mkdir(DATA_DIR, { recursive: true });
      const payload: SocialStoreData = {
        players: Object.fromEntries(playersStore.entries()),
      };
      await fs.writeFile(STORE_PATH, JSON.stringify(payload, null, 2), 'utf8');
    } catch (err) {
      console.error('Failed to persist social store:', err);
    }
  }, 250);
}

function normalizePlayerId(raw: string): string {
  const clean = raw.trim().toUpperCase().replace(/\s+/g, '');
  if (!clean) return '';
  if (/^\d{5}$/.test(clean)) return `MW-${clean}`;
  return clean;
}

function normalizeRoomId(raw: string): string {
  return raw.trim().toUpperCase().replace(/[^A-Z0-9]/g, '');
}

function generateUniquePlayerId(): string {
  for (let i = 0; i < 100; i++) {
    const num = Math.floor(10000 + Math.random() * 90000);
    const id = `MW-${num}`;
    if (!playersStore.has(id)) return id;
  }
  return `MW-${Date.now().toString().slice(-6)}`;
}

function generateUniqueRoomId(): string {
  for (let i = 0; i < 100; i++) {
    const code = String(Math.floor(100000 + Math.random() * 900000));
    if (!activeRooms.has(code)) return code;
  }
  return String(Date.now()).slice(-6);
}

function buildFriendsList(playerId: string) {
  const me = playersStore.get(playerId);
  if (!me) return [];
  const list = [];
  for (const fid of me.friends) {
    const fp = playersStore.get(fid);
    if (!fp) continue;
    const sock = onlineSockets.get(fid);
    const online = Boolean(sock && sock.readyState === WebSocket.OPEN);
    const roomId = online ? (playerRoomMap.get(fid) ?? null) : null;
    list.push({
      id: fp.id,
      name: fp.name,
      bikeModel: fp.bikeModel,
      online,
      roomId,
    });
  }
  return list;
}

function serializeRoom(room: ActiveRoom) {
  return {
    roomId: room.roomId,
    hostId: room.hostId,
    players: Array.from(room.members.values()).map((m) => ({
      playerId: m.playerId,
      name: m.name,
      bikeModel: m.bikeModel,
    })),
  };
}

function sendWs(ws: WebSocket | undefined, data: unknown) {
  if (ws && ws.readyState === WebSocket.OPEN) {
    ws.send(JSON.stringify(data));
  }
}

function notifyFriendsPresence(playerId: string) {
  const me = playersStore.get(playerId);
  if (!me) return;
  for (const fid of me.friends) {
    const friendWs = onlineSockets.get(fid);
    if (friendWs && friendWs.readyState === WebSocket.OPEN) {
      sendWs(friendWs, {
        type: 'friends:updated',
        friends: buildFriendsList(fid),
      });
    }
  }
}

function removePlayerFromCurrentRoom(playerId: string) {
  const roomId = playerRoomMap.get(playerId);
  if (!roomId) return;
  playerRoomMap.delete(playerId);

  const room = activeRooms.get(roomId);
  if (!room) return;
  room.members.delete(playerId);

  if (room.members.size === 0) {
    activeRooms.delete(roomId);
  } else {
    if (room.hostId === playerId) {
      const nextHost = room.members.values().next().value;
      if (nextHost) room.hostId = nextHost.playerId;
    }
    const summary = serializeRoom(room);
    for (const member of room.members.values()) {
      sendWs(member.ws, {
        type: 'room:player_left',
        playerId,
        room: summary,
      });
    }
  }
  notifyFriendsPresence(playerId);
}

function getAiClient(): GoogleGenAI {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error('GEMINI_API_KEY não configurada no ambiente do servidor.');
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

interface ChatMessageInput {
  role: 'user' | 'model';
  text: string;
}

async function startServer() {
  await loadSocialStore();

  const app = express();
  app.use(express.json({ limit: '10mb' }));

  // Social & Multiplayer REST API
  app.post('/api/social/register', (req, res) => {
    const body = req.body as {
      playerId?: string;
      name?: string;
      bikeModel?: BikeModelType;
    };
    const requestedId = typeof body.playerId === 'string' ? normalizePlayerId(body.playerId) : '';
    const cleanName =
      typeof body.name === 'string' && body.name.trim()
        ? body.name.trim().slice(0, 20)
        : 'Piloto 160';
    const bikeModel: BikeModelType =
      body.bikeModel === 'cg_fan_160' || body.bikeModel === 'bros_160'
        ? body.bikeModel
        : 'cg_titan_160';

    let player: StoredPlayer;
    if (requestedId && playersStore.has(requestedId)) {
      player = playersStore.get(requestedId)!;
      if (typeof body.name === 'string' && body.name.trim()) {
        player.name = cleanName;
      }
      player.bikeModel = bikeModel;
    } else {
      const id = requestedId && /^MW-[A-Z0-9]{4,8}$/.test(requestedId) ? requestedId : generateUniquePlayerId();
      player = {
        id,
        name: cleanName,
        bikeModel,
        friends: [],
        createdAt: Date.now(),
      };
      playersStore.set(id, player);
    }

    scheduleSaveStore();
    return res.json({
      player: {
        id: player.id,
        name: player.name,
        bikeModel: player.bikeModel,
      },
      friends: buildFriendsList(player.id),
    });
  });

  app.post('/api/social/profile', (req, res) => {
    const body = req.body as {
      playerId?: string;
      name?: string;
      bikeModel?: BikeModelType;
    };
    const playerId = normalizePlayerId(body.playerId ?? '');
    const player = playersStore.get(playerId);
    if (!player) {
      return res.status(404).json({ error: 'Jogador não registrado.' });
    }
    if (typeof body.name === 'string' && body.name.trim()) {
      player.name = body.name.trim().slice(0, 20);
    }
    if (body.bikeModel === 'cg_titan_160' || body.bikeModel === 'cg_fan_160' || body.bikeModel === 'bros_160') {
      player.bikeModel = body.bikeModel;
    }
    scheduleSaveStore();
    notifyFriendsPresence(playerId);
    return res.json({
      player: {
        id: player.id,
        name: player.name,
        bikeModel: player.bikeModel,
      },
    });
  });

  app.get('/api/social/friends', (req, res) => {
    const playerId = normalizePlayerId(String(req.query.playerId ?? ''));
    if (!playerId || !playersStore.has(playerId)) {
      return res.status(404).json({ error: 'Jogador não encontrado.' });
    }
    return res.json({ friends: buildFriendsList(playerId) });
  });

  app.post('/api/social/friends/add', (req, res) => {
    const body = req.body as { playerId?: string; friendId?: string };
    const playerId = normalizePlayerId(body.playerId ?? '');
    const friendId = normalizePlayerId(body.friendId ?? '');

    if (!playerId || !playersStore.has(playerId)) {
      return res.status(404).json({ error: 'Seu perfil ainda não foi registrado.' });
    }
    if (!friendId) {
      return res.status(400).json({ error: 'Digite o ID do seu amigo.' });
    }
    if (friendId === playerId) {
      return res.status(400).json({ error: 'Você não pode adicionar seu próprio ID.' });
    }

    const friend = playersStore.get(friendId);
    if (!friend) {
      return res.status(404).json({
        error: `ID "${friendId}" não encontrado. Peça para seu amigo abrir o Moto Win para gerar o ID dele.`,
      });
    }

    const me = playersStore.get(playerId)!;
    if (!me.friends.includes(friendId)) {
      me.friends.push(friendId);
    }
    if (!friend.friends.includes(playerId)) {
      friend.friends.push(playerId);
    }
    scheduleSaveStore();

    const friendWs = onlineSockets.get(friendId);
    if (friendWs && friendWs.readyState === WebSocket.OPEN) {
      sendWs(friendWs, {
        type: 'friends:added_you',
        byName: me.name,
        byId: me.id,
        friends: buildFriendsList(friendId),
      });
    }

    return res.json({
      added: {
        id: friend.id,
        name: friend.name,
        bikeModel: friend.bikeModel,
      },
      friends: buildFriendsList(playerId),
    });
  });

  app.post('/api/social/friends/remove', (req, res) => {
    const body = req.body as { playerId?: string; friendId?: string };
    const playerId = normalizePlayerId(body.playerId ?? '');
    const friendId = normalizePlayerId(body.friendId ?? '');
    const me = playersStore.get(playerId);
    if (!me) {
      return res.status(404).json({ error: 'Jogador não encontrado.' });
    }
    me.friends = me.friends.filter((id) => id !== friendId);
    scheduleSaveStore();
    return res.json({ friends: buildFriendsList(playerId) });
  });

  app.post('/api/chat', async (req, res) => {
    try {
      const {
        messages,
        model = 'gemini-4-hydrogen',
        telemetry,
      } = req.body as {
        messages?: ChatMessageInput[];
        model?: string;
        telemetry?: {
          speedKmh?: number;
          zone?: string;
          weather?: string;
          timePhase?: string;
          money?: number;
          xp?: number;
          bikeColor?: string;
          motorLevel?: number;
        };
      };

      if (!Array.isArray(messages) || messages.length === 0) {
        return res.status(400).json({ error: 'Envie pelo menos uma mensagem.' });
      }

      const selectedModel = ALLOWED_CHAT_MODELS.has(model) ? model : 'gemini-4-hydrogen';
      const ai = getAiClient();

      const telemetrySummary = telemetry
        ? `Estado atual do jogador no Moto Win: Zona="${telemetry.zone ?? 'Casa Principal'}", Velocidade=${Math.round(telemetry.speedKmh ?? 0)} km/h (limite 140 km/h da 160cc), Clima="${telemetry.weather ?? 'sol'}", Período="${telemetry.timePhase ?? 'dia'}", Dinheiro=R$ ${telemetry.money ?? 0}, XP=${telemetry.xp ?? 0}, Motor Nível=${telemetry.motorLevel ?? 1}.`
        : '';

      const roleDescription =
        selectedModel === 'gemini-3.1-flash-lite'
          ? 'Você é o Copiloto Rápido do Moto Win. Dê dicas curtas, diretas e práticas em no máximo 3 frases.'
          : 'Você é o Mestre Tuning, mecânico brasileiro especialista em motos 160cc e piloto instrutor de grau no jogo Moto Win. Responda em português do Brasil natural, claro e útil.';

      const systemInstruction = `${roleDescription}
Mapa do jogo: 1000x1000 metros com Casa Principal no centro-sul (0, -18), Avenida Central reta ideal para velocidade e grau, Centro da Cidade a leste/nordeste com arranha-céus, Favelas no Morro a noroeste/sudoeste com vielas e subidas íngremes, e bairros residenciais com várias casas e árvores.
A moto é uma 160cc com câmbio de 5 marchas e velocidade máxima limitada a 140 km/h.
Controles: W/Acelerar, S/Frear (modula o grau), Espaço/Empinar, A-D/Esterçar, E/Ligar Moto.
${telemetrySummary}`;

      const history = messages.slice(0, -1).map((m) => ({
        role: m.role === 'model' ? ('model' as const) : ('user' as const),
        parts: [{ text: m.text }],
      }));
      const latest = messages[messages.length - 1];

      const chat = ai.chats.create({
        model: selectedModel,
        config: {
          systemInstruction,
        },
        history,
      });

      const response = await chat.sendMessage({
        message: latest.text,
      });

      const reply = response.text?.trim();
      if (!reply) {
        return res.status(502).json({ error: 'O modelo retornou uma resposta vazia.' });
      }

      return res.json({ reply, model: selectedModel });
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Erro ao consultar o Gemini.';
      const status = message.includes('PERMISSION_DENIED') || message.includes('API_KEY') ? 403 : 500;
      return res.status(status).json({ error: message });
    }
  });

  const httpServer = http.createServer(app);
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });

  wss.on('connection', (ws) => {
    let boundPlayerId: string | null = null;

    ws.on('message', (rawBuf) => {
      let msg: Record<string, unknown>;
      try {
        msg = JSON.parse(rawBuf.toString()) as Record<string, unknown>;
      } catch {
        return;
      }

      const type = String(msg.type ?? '');

      if (type === 'auth') {
        const pid = normalizePlayerId(String(msg.playerId ?? ''));
        if (!pid) return;
        const cleanName =
          typeof msg.name === 'string' && msg.name.trim()
            ? msg.name.trim().slice(0, 20)
            : 'Piloto 160';
        const bikeModel: BikeModelType =
          msg.bikeModel === 'cg_fan_160' || msg.bikeModel === 'bros_160'
            ? msg.bikeModel
            : 'cg_titan_160';

        if (!playersStore.has(pid)) {
          playersStore.set(pid, {
            id: pid,
            name: cleanName,
            bikeModel,
            friends: [],
            createdAt: Date.now(),
          });
          scheduleSaveStore();
        } else {
          const existing = playersStore.get(pid)!;
          existing.name = cleanName;
          existing.bikeModel = bikeModel;
        }

        const prevWs = onlineSockets.get(pid);
        if (prevWs && prevWs !== ws && prevWs.readyState === WebSocket.OPEN) {
          prevWs.close(4001, 'Replaced by new connection');
        }

        boundPlayerId = pid;
        onlineSockets.set(pid, ws);
        sendWs(ws, {
          type: 'auth:ok',
          playerId: pid,
          friends: buildFriendsList(pid),
        });
        notifyFriendsPresence(pid);
        return;
      }

      if (!boundPlayerId) {
        sendWs(ws, { type: 'room:error', message: 'Conectando perfil, tente novamente.' });
        return;
      }

      const me = playersStore.get(boundPlayerId);
      if (!me) return;

      if (type === 'profile:update') {
        if (typeof msg.name === 'string' && msg.name.trim()) {
          me.name = msg.name.trim().slice(0, 20);
        }
        if (msg.bikeModel === 'cg_titan_160' || msg.bikeModel === 'cg_fan_160' || msg.bikeModel === 'bros_160') {
          me.bikeModel = msg.bikeModel;
        }
        scheduleSaveStore();
        notifyFriendsPresence(boundPlayerId);
        return;
      }

      if (type === 'room:create') {
        removePlayerFromCurrentRoom(boundPlayerId);
        const roomId = generateUniqueRoomId();
        const room: ActiveRoom = {
          roomId,
          hostId: boundPlayerId,
          doorOpen: false,
          members: new Map(),
          createdAt: Date.now(),
        };
        room.members.set(boundPlayerId, {
          playerId: boundPlayerId,
          name: me.name,
          bikeModel: me.bikeModel,
          ws,
          state: null,
        });
        activeRooms.set(roomId, room);
        playerRoomMap.set(boundPlayerId, roomId);

        sendWs(ws, {
          type: 'room:joined',
          room: serializeRoom(room),
          remoteStates: [],
          doorOpen: room.doorOpen,
        });
        notifyFriendsPresence(boundPlayerId);
        return;
      }

      if (type === 'room:join') {
        const targetRoomId = normalizeRoomId(String(msg.roomId ?? ''));
        if (!targetRoomId) {
          sendWs(ws, { type: 'room:error', message: 'Digite o ID da sala.' });
          return;
        }
        const room = activeRooms.get(targetRoomId);
        if (!room) {
          sendWs(ws, {
            type: 'room:error',
            message: `Sala "${targetRoomId}" não encontrada. Peça para seu amigo clicar em Criar Sala primeiro.`,
          });
          return;
        }

        const alreadyInSameRoom = playerRoomMap.get(boundPlayerId) === targetRoomId;
        if (!alreadyInSameRoom) {
          removePlayerFromCurrentRoom(boundPlayerId);
        }

        const member: RoomMember = {
          playerId: boundPlayerId,
          name: me.name,
          bikeModel: me.bikeModel,
          ws,
          state: null,
        };
        room.members.set(boundPlayerId, member);
        playerRoomMap.set(boundPlayerId, targetRoomId);

        const remoteStates = Array.from(room.members.values())
          .filter((m) => m.playerId !== boundPlayerId && m.state !== null)
          .map((m) => m.state);

        const summary = serializeRoom(room);
        sendWs(ws, {
          type: 'room:joined',
          room: summary,
          remoteStates,
          doorOpen: room.doorOpen,
        });

        for (const other of room.members.values()) {
          if (other.playerId !== boundPlayerId) {
            sendWs(other.ws, {
              type: 'room:player_joined',
              player: {
                playerId: boundPlayerId,
                name: me.name,
                bikeModel: me.bikeModel,
              },
              room: summary,
            });
          }
        }
        notifyFriendsPresence(boundPlayerId);
        return;
      }

      if (type === 'room:leave') {
        removePlayerFromCurrentRoom(boundPlayerId);
        sendWs(ws, { type: 'room:left' });
        return;
      }

      if (type === 'player:state') {
        const roomId = playerRoomMap.get(boundPlayerId);
        if (!roomId) return;
        const room = activeRooms.get(roomId);
        if (!room) return;
        const member = room.members.get(boundPlayerId);
        if (!member) return;

        const payload = msg.state as Record<string, unknown> | undefined;
        if (!payload || typeof payload !== 'object') return;

        const safeState = {
          ...payload,
          playerId: boundPlayerId,
          name: me.name,
          updatedAt: Date.now(),
        };
        member.state = safeState;

        for (const other of room.members.values()) {
          if (other.playerId !== boundPlayerId) {
            sendWs(other.ws, {
              type: 'room:state',
              state: safeState,
            });
          }
        }
        return;
      }

      if (type === 'world:door') {
        const roomId = playerRoomMap.get(boundPlayerId);
        if (!roomId) return;
        const room = activeRooms.get(roomId);
        if (!room) return;
        room.doorOpen = Boolean(msg.open);
        for (const other of room.members.values()) {
          if (other.playerId !== boundPlayerId) {
            sendWs(other.ws, {
              type: 'world:door',
              open: room.doorOpen,
            });
          }
        }
      }
    });

    ws.on('close', () => {
      if (!boundPlayerId) return;
      if (onlineSockets.get(boundPlayerId) === ws) {
        onlineSockets.delete(boundPlayerId);
        removePlayerFromCurrentRoom(boundPlayerId);
        notifyFriendsPresence(boundPlayerId);
      }
    });
  });

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  const port = Number(process.env.PORT ?? 3000);
  httpServer.listen(port, '0.0.0.0', () => {
    console.log(`Moto Win server running at http://0.0.0.0:${port}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
