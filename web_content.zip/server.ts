import express from 'express';
import type { Request, Response } from 'express';
import http from 'http';
import multer from 'multer';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = parseInt(process.env.PORT || '3000', 10);
const isProd = process.env.NODE_ENV === 'production';
process.env.DISABLE_HMR = 'true';

// Directory to store uploaded .jpg custom icons
const publicDir = path.resolve(__dirname, 'public');
const uploadsDir = path.resolve(publicDir, 'custom_icons');
const metadataFile = path.resolve(uploadsDir, 'icons_registry.json');

// Ensure directories exist
if (!fs.existsSync(publicDir)) {
  fs.mkdirSync(publicDir, { recursive: true });
}
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

interface CustomIconMetadata {
  id: string;
  ventureId?: string;
  guildmasterId?: string;
  url: string;
  filename: string;
  name?: string;
  size?: number;
  mimeType?: string;
  updatedAt: string;
}

interface RegistryData {
  icons: Record<string, CustomIconMetadata>;
  guildmasterIcons?: Record<string, CustomIconMetadata>;
}

// Read metadata helper with safety fallback for saved venture icons
function readRegistry(): RegistryData {
  let result: RegistryData = { icons: {}, guildmasterIcons: {} };
  try {
    if (fs.existsSync(metadataFile)) {
      const data = JSON.parse(fs.readFileSync(metadataFile, 'utf-8'));
      result.icons = data.icons || {};
      result.guildmasterIcons = data.guildmasterIcons || {};
    }
  } catch (err) {
    console.error('Failed to read icons registry', err);
  }

  // Backup restore for venture & guildmaster icons to ensure they are saved permanently
  const gmBackupDir = path.resolve(publicDir, 'saved_guildmaster_icons');
  const backupDir = path.resolve(publicDir, 'saved_venture_icons');
  const backupFile = fs.existsSync(path.resolve(gmBackupDir, 'icons_registry.json'))
    ? path.resolve(gmBackupDir, 'icons_registry.json')
    : path.resolve(backupDir, 'icons_registry.json');

  if (fs.existsSync(backupFile)) {
    try {
      const backupData = JSON.parse(fs.readFileSync(backupFile, 'utf-8'));
      if (backupData.icons) {
        Object.keys(backupData.icons).forEach((vId) => {
          if (!result.icons[vId]) {
            result.icons[vId] = backupData.icons[vId];
          }
          const icon = result.icons[vId];
          if (icon && icon.filename && !icon.url.startsWith('/src/assets')) {
            const destPath = path.resolve(uploadsDir, icon.filename);
            const srcPath = fs.existsSync(path.resolve(backupDir, icon.filename))
              ? path.resolve(backupDir, icon.filename)
              : path.resolve(gmBackupDir, icon.filename);
            if (!fs.existsSync(destPath) && fs.existsSync(srcPath)) {
              try {
                fs.copyFileSync(srcPath, destPath);
              } catch (e) {
                console.warn('Failed to copy backup icon file', e);
              }
            }
          }
        });
      }
      if (backupData.guildmasterIcons) {
        if (!result.guildmasterIcons) result.guildmasterIcons = {};
        Object.keys(backupData.guildmasterIcons).forEach((gmId) => {
          if (!result.guildmasterIcons![gmId]) {
            result.guildmasterIcons![gmId] = backupData.guildmasterIcons[gmId];
          }
          const icon = result.guildmasterIcons![gmId];
          if (icon && icon.filename && !icon.url.startsWith('/src/assets')) {
            const destPath = path.resolve(uploadsDir, icon.filename);
            const srcPath = fs.existsSync(path.resolve(gmBackupDir, icon.filename))
              ? path.resolve(gmBackupDir, icon.filename)
              : path.resolve(backupDir, icon.filename);
            if (!fs.existsSync(destPath) && fs.existsSync(srcPath)) {
              try {
                fs.copyFileSync(srcPath, destPath);
              } catch (e) {
                console.warn('Failed to copy backup guildmaster portrait file', e);
              }
            }
          }
        });
      }
    } catch {
      // ignore
    }
  }

  return result;
}

// Write metadata helper
function writeRegistry(data: RegistryData) {
  try {
    fs.writeFileSync(metadataFile, JSON.stringify(data, null, 2), 'utf-8');
  } catch (err) {
    console.error('Failed to write icons registry', err);
  }
}

// Multer storage for multipart/form-data .jpg file uploads
const storage = multer.diskStorage({
  destination: (_req, _file, cb) => {
    cb(null, uploadsDir);
  },
  filename: (req, file, cb) => {
    const rawId =
      req.query?.guildmasterId ||
      req.body?.guildmasterId ||
      req.query?.ventureId ||
      req.body?.ventureId ||
      'gm';
    const targetId = String(rawId).replace(/[^a-zA-Z0-9_-]/g, '');
    const isVenture = Boolean(
      (req.query?.ventureId || req.body?.ventureId) &&
      !req.query?.guildmasterId &&
      !req.body?.guildmasterId &&
      (req.query?.type === 'venture' || req.body?.type === 'venture')
    );
    const prefix = isVenture ? 'venture' : 'gm';
    const timestamp = Date.now();
    cb(null, `${prefix}_${targetId}_${timestamp}.jpg`);
  },
});

const upload = multer({
  storage,
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB
  fileFilter: (_req, file, cb) => {
    const original = file.originalname.toLowerCase();
    const isJpg =
      file.mimetype === 'image/jpeg' ||
      file.mimetype === 'image/jpg' ||
      original.endsWith('.jpg') ||
      original.endsWith('.jpeg');

    if (isJpg) {
      cb(null, true);
    } else {
      cb(new Error('Only .jpg or .jpeg image files are supported as icons.'));
    }
  },
});

async function main() {
  const app = express();

  // Enable JSON and URL-encoded bodies with 15MB limit for Base64 JPEG uploads
  app.use(express.json({ limit: '15mb' }));
  app.use(express.urlencoded({ extended: true, limit: '15mb' }));

  // Static serving for custom uploaded .jpg icons (aliased for backwards compatibility)
  app.use('/custom_icons', express.static(uploadsDir));
  app.use('/saved_venture_icons', express.static(uploadsDir));
  app.use('/saved_guildmaster_icons', express.static(uploadsDir));

  // ==========================================
  // BACKEND API ROUTES FOR .JPG ICONS
  // ==========================================

  // 1. GET /api/icons - List all registered .jpg icons and available presets
  app.get('/api/icons', (_req: Request, res: Response) => {
    const registry = readRegistry();
    const backupDir = path.resolve(publicDir, 'saved_venture_icons');

    // Verify all registered files still exist on disk (restoring from saved_venture_icons if needed)
    let changed = false;
    Object.keys(registry.icons).forEach((vId) => {
      const icon = registry.icons[vId];
      if (icon.url.startsWith('/src/assets/images')) {
        const assetPath = path.resolve(__dirname, icon.url.replace(/^\//, ''));
        if (!fs.existsSync(assetPath)) {
          delete registry.icons[vId];
          changed = true;
        }
      } else {
        const uploadPath = path.resolve(uploadsDir, icon.filename);
        if (!fs.existsSync(uploadPath)) {
          const backupPath = path.resolve(backupDir, icon.filename);
          if (fs.existsSync(backupPath)) {
            try {
              fs.copyFileSync(backupPath, uploadPath);
            } catch {
              // ignore
            }
          } else {
            delete registry.icons[vId];
            changed = true;
          }
        }
      }
    });

    if (registry.guildmasterIcons) {
      const gmBackupDir = path.resolve(publicDir, 'saved_guildmaster_icons');
      Object.keys(registry.guildmasterIcons).forEach((gmId) => {
        const icon = registry.guildmasterIcons![gmId];
        if (icon.url.startsWith('/src/assets/images')) {
          const assetPath = path.resolve(__dirname, icon.url.replace(/^\//, ''));
          if (!fs.existsSync(assetPath)) {
            delete registry.guildmasterIcons![gmId];
            changed = true;
          }
        } else {
          const uploadPath = path.resolve(uploadsDir, icon.filename);
          if (!fs.existsSync(uploadPath)) {
            const backupPath = fs.existsSync(path.resolve(gmBackupDir, icon.filename))
              ? path.resolve(gmBackupDir, icon.filename)
              : path.resolve(backupDir, icon.filename);
            if (fs.existsSync(backupPath)) {
              try {
                fs.copyFileSync(backupPath, uploadPath);
              } catch {
                // ignore
              }
            } else {
              delete registry.guildmasterIcons![gmId];
              changed = true;
            }
          }
        }
      });
    }

    if (changed) {
      writeRegistry(registry);
    }

    // Discover any bundled fantasy artwork .jpgs in src/assets/images
    const assetsDir = path.resolve(__dirname, 'src', 'assets', 'images');
    const presets: Array<{ name: string; url: string; filename: string }> = [];
    if (fs.existsSync(assetsDir)) {
      try {
        const files = fs.readdirSync(assetsDir);
        files.forEach((file) => {
          if (file.toLowerCase().endsWith('.jpg') || file.toLowerCase().endsWith('.jpeg')) {
            const readableName = file
              .replace(/\.[^/.]+$/, '')
              .replace(/_\d+$/, '')
              .replace(/_/g, ' ')
              .replace(/\b\w/g, (c) => c.toUpperCase());
            presets.push({
              name: readableName,
              url: `/src/assets/images/${file}`,
              filename: file,
            });
          }
        });
      } catch (e) {
        console.warn('Could not read presets directory', e);
      }
    }

    res.json({
      success: true,
      icons: registry.icons,
      ventureIcons: registry.icons,
      guildmasterIcons: registry.guildmasterIcons || {},
      presets,
      storageDirectory: '/custom_icons',
    });
  });

  // 2. POST /api/icons/upload - Upload a .jpg icon via multipart/form-data
  app.post(
    '/api/icons/upload',
    (req: Request, res: Response, next) => {
      // Check if this is a multipart upload or base64 JSON upload
      const contentType = req.headers['content-type'] || '';
      if (contentType.includes('multipart/form-data')) {
        upload.single('image')(req, res, (err) => {
          if (err) {
            return res.status(400).json({ success: false, error: err.message });
          }
          next();
        });
      } else {
        next();
      }
    },
    (req: Request, res: Response) => {
      try {
        const rawId =
          req.body?.guildmasterId ||
          req.query?.guildmasterId ||
          req.body?.ventureId ||
          req.query?.ventureId;
        if (!rawId) {
          return res.status(400).json({ success: false, error: 'guildmasterId or ventureId is required' });
        }
        const targetId = String(rawId).replace(/[^a-zA-Z0-9_-]/g, '');
        const isVenture = Boolean(req.body?.ventureId && !req.body?.guildmasterId && req.body?.type === 'venture');

        let filename = '';
        let fileSize = 0;

        // Case A: Uploaded via Multer file
        if (req.file) {
          filename = req.file.filename;
          fileSize = req.file.size;
          // If multer defaulted filename to gm_gm_... or venture_gm_..., rename it to use the exact targetId
          const prefix = isVenture ? 'venture' : 'gm';
          if ((filename.startsWith('gm_gm_') || filename.startsWith('venture_gm_')) && targetId !== 'gm') {
            const properFilename = `${prefix}_${targetId}_${Date.now()}.jpg`;
            const currentPath = path.resolve(uploadsDir, filename);
            const targetPath = path.resolve(uploadsDir, properFilename);
            if (fs.existsSync(currentPath)) {
              try {
                fs.renameSync(currentPath, targetPath);
                filename = properFilename;
              } catch (renameErr) {
                console.warn('Could not rename uploaded file', renameErr);
              }
            }
          }
        }
        // Case B: Uploaded via Base64 JSON
        else if (req.body?.imageData) {
          const rawData = String(req.body.imageData);
          // Strip data:image/jpeg;base64, prefix if present
          const base64Data = rawData.replace(/^data:image\/\w+;base64,/, '');
          const buffer = Buffer.from(base64Data, 'base64');

          // Validate buffer has JPEG magic bytes: FF D8 FF
          if (buffer.length < 3 || buffer[0] !== 0xff || buffer[1] !== 0xd8 || buffer[2] !== 0xff) {
            return res.status(400).json({
              success: false,
              error: 'Invalid file format. File must be a valid JPEG (.jpg) image.',
            });
          }

          const prefix = isVenture ? 'venture' : 'gm';
          filename = `${prefix}_${targetId}_${Date.now()}.jpg`;
          const targetPath = path.resolve(uploadsDir, filename);
          fs.writeFileSync(targetPath, buffer);
          fileSize = buffer.length;
        } else {
          return res.status(400).json({
            success: false,
            error: 'No image file or imageData base64 payload provided.',
          });
        }

        const registry = readRegistry();

        if (isVenture) {
          // Remove old custom icon file for this venture if it exists
          const prevIcon = registry.icons[targetId];
          if (prevIcon && prevIcon.filename && !prevIcon.filename.startsWith('/src/assets')) {
            const prevPath = path.resolve(uploadsDir, prevIcon.filename);
            if (fs.existsSync(prevPath) && prevIcon.filename !== filename) {
              try {
                fs.unlinkSync(prevPath);
              } catch (err) {
                console.warn('Failed to delete previous icon file', err);
              }
            }
          }

          const iconRecord: CustomIconMetadata = {
            id: targetId,
            ventureId: targetId,
            url: `/custom_icons/${filename}`,
            filename,
            name: req.body?.name || `${targetId} Custom Icon`,
            size: fileSize,
            mimeType: 'image/jpeg',
            updatedAt: new Date().toISOString(),
          };

          registry.icons[targetId] = iconRecord;
          writeRegistry(registry);

          return res.json({
            success: true,
            icon: iconRecord,
            icons: registry.icons,
            ventureIcons: registry.icons,
            message: `Successfully set .jpg icon for venture ${targetId}`,
          });
        } else {
          // Default: Guildmaster portrait upload (preserves all saved venture icons)
          if (!registry.guildmasterIcons) registry.guildmasterIcons = {};

          const prevIcon = registry.guildmasterIcons[targetId];
          if (prevIcon && prevIcon.filename && !prevIcon.filename.startsWith('/src/assets')) {
            const prevPath = path.resolve(uploadsDir, prevIcon.filename);
            if (fs.existsSync(prevPath) && prevIcon.filename !== filename) {
              try {
                fs.unlinkSync(prevPath);
              } catch (err) {
                console.warn('Failed to delete previous portrait file', err);
              }
            }
          }

          const iconRecord: CustomIconMetadata = {
            id: targetId,
            guildmasterId: targetId,
            ventureId: targetId,
            url: `/custom_icons/${filename}`,
            filename,
            name: req.body?.name || `${targetId} Guildmaster Portrait`,
            size: fileSize,
            mimeType: 'image/jpeg',
            updatedAt: new Date().toISOString(),
          };

          registry.guildmasterIcons[targetId] = iconRecord;
          writeRegistry(registry);

          return res.json({
            success: true,
            icon: iconRecord,
            guildmasterIcons: registry.guildmasterIcons,
            message: `Successfully set .jpg portrait for guildmaster ${targetId}`,
          });
        }
      } catch (err: unknown) {
        const message = err instanceof Error ? err.message : 'Unknown server error';
        console.error('Error in /api/icons/upload:', err);
        res.status(500).json({ success: false, error: message });
      }
    }
  );

  // 3. POST /api/icons/preset - Assign an existing bundled .jpg preset to a guildmaster or venture
  app.post('/api/icons/preset', (req: Request, res: Response) => {
    try {
      const { guildmasterId, ventureId, presetUrl, presetName } = req.body;
      const rawId = guildmasterId || ventureId;
      if (!rawId || !presetUrl) {
        return res.status(400).json({ success: false, error: 'guildmasterId and presetUrl are required' });
      }

      const targetId = String(rawId).replace(/[^a-zA-Z0-9_-]/g, '');
      const isVenture = Boolean(ventureId && !guildmasterId && req.body?.type === 'venture');
      const registry = readRegistry();

      if (isVenture) {
        const iconRecord: CustomIconMetadata = {
          id: targetId,
          ventureId: targetId,
          url: presetUrl,
          filename: path.basename(presetUrl),
          name: presetName || 'Preset Fantasy Artwork',
          mimeType: 'image/jpeg',
          updatedAt: new Date().toISOString(),
        };

        registry.icons[targetId] = iconRecord;
        writeRegistry(registry);

        return res.json({
          success: true,
          icon: iconRecord,
          icons: registry.icons,
          message: `Successfully applied preset .jpg icon to ${targetId}`,
        });
      } else {
        if (!registry.guildmasterIcons) registry.guildmasterIcons = {};

        const iconRecord: CustomIconMetadata = {
          id: targetId,
          guildmasterId: targetId,
          ventureId: targetId,
          url: presetUrl,
          filename: path.basename(presetUrl),
          name: presetName || 'Preset Guildmaster Artwork',
          mimeType: 'image/jpeg',
          updatedAt: new Date().toISOString(),
        };

        registry.guildmasterIcons[targetId] = iconRecord;
        writeRegistry(registry);

        return res.json({
          success: true,
          icon: iconRecord,
          guildmasterIcons: registry.guildmasterIcons,
          message: `Successfully applied preset .jpg portrait to guildmaster ${targetId}`,
        });
      }
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Unknown server error';
      res.status(500).json({ success: false, error: message });
    }
  });

  // 4. DELETE /api/icons/:id - Reset guildmaster or venture icon back to default
  app.delete('/api/icons/:id', (req: Request, res: Response) => {
    try {
      const rawId = req.params.id;
      const targetId = String(rawId).replace(/[^a-zA-Z0-9_-]/g, '');
      const registry = readRegistry();

      const isGm = req.query.type === 'guildmaster' || (registry.guildmasterIcons && targetId in registry.guildmasterIcons);

      if (isGm && registry.guildmasterIcons?.[targetId]) {
        const existing = registry.guildmasterIcons[targetId];
        if (existing.filename && !existing.url.startsWith('/src/assets')) {
          const filePath = path.resolve(uploadsDir, existing.filename);
          if (fs.existsSync(filePath)) {
            try {
              fs.unlinkSync(filePath);
            } catch (err) {
              console.warn('Failed to delete portrait file', err);
            }
          }
        }
        delete registry.guildmasterIcons[targetId];
        writeRegistry(registry);
        return res.json({
          success: true,
          message: `Reset portrait for guildmaster ${targetId} back to default RPG art.`,
        });
      } else if (registry.icons[targetId]) {
        const existing = registry.icons[targetId];
        if (existing.filename && !existing.url.startsWith('/src/assets')) {
          const filePath = path.resolve(uploadsDir, existing.filename);
          if (fs.existsSync(filePath)) {
            try {
              fs.unlinkSync(filePath);
            } catch (err) {
              console.warn('Failed to delete file on disk', err);
            }
          }
        }
        delete registry.icons[targetId];
        writeRegistry(registry);
        return res.json({
          success: true,
          message: `Reset icon for venture ${targetId} back to default vector art.`,
        });
      }

      res.json({ success: true, message: 'Done.' });
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Unknown server error';
      res.status(500).json({ success: false, error: message });
    }
  });

  // 5. DELETE /api/icons - Reset guildmaster portraits (keeps saved venture icons safe)
  app.delete('/api/icons', (req: Request, res: Response) => {
    try {
      const registry = readRegistry();

      // Only resets guildmaster portraits; protects and preserves saved venture icons!
      if (registry.guildmasterIcons) {
        Object.values(registry.guildmasterIcons).forEach((icon) => {
          if (icon.filename && !icon.url.startsWith('/src/assets')) {
            const filePath = path.resolve(uploadsDir, icon.filename);
            if (fs.existsSync(filePath)) {
              try {
                fs.unlinkSync(filePath);
              } catch {
                // ignore
              }
            }
          }
        });
        registry.guildmasterIcons = {};
        writeRegistry(registry);
      }

      res.json({
        success: true,
        message: 'All custom guildmaster portraits reset to default character portraits.',
      });
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Unknown server error';
      res.status(500).json({ success: false, error: message });
    }
  });

  // ==========================================
  // VITE DEV SERVER OR STATIC PROD SERVING
  // ==========================================
  const httpServer = http.createServer(app);

  if (!isProd) {
    const isHmrDisabled = process.env.DISABLE_HMR === 'true';
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: isHmrDisabled ? false : { server: httpServer },
        watch: isHmrDisabled ? null : {},
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  httpServer.listen(PORT, '0.0.0.0', () => {
    console.log(`[Backend Server] Ready at http://0.0.0.0:${PORT} (mode: ${isProd ? 'production' : 'development'})`);
  });
}

main().catch((err) => {
  console.error('Fatal server startup failure:', err);
  process.exit(1);
});
