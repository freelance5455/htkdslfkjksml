import express, { Request, Response } from 'express';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { INITIAL_MARKET_ITEMS } from './src/data/initialCatalog.ts';
import { MarketItem, Coupon } from './src/types.ts';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

app.use(express.json({ limit: '10mb' }));

// Persistent server data file
const DB_FILE = path.join(__dirname, 'waqti_server_db.json');

interface ServerDatabase {
  customMarketItems: MarketItem[];
  priceOverrides: Record<string, number>;
  coupons: Coupon[];
  users: Record<string, any>;
  redeemedByUsers: Record<string, string[]>; // userId -> couponCodes[]
  announcement?: string;
}

const DEFAULT_COUPONS: Coupon[] = [
  {
    code: 'WAQTI2026',
    coinsReward: 300,
    maxUses: 1000,
    usedCount: 0,
    description: 'هدية انطلاق تطبيق وقتي الرسمي',
    createdAt: new Date().toISOString()
  },
  {
    code: 'FOUNDER_GIFT',
    coinsReward: 500,
    maxUses: 500,
    usedCount: 0,
    description: 'هدية حصرية من مؤسس منصة وقتي',
    createdAt: new Date().toISOString()
  },
  {
    code: 'SUPER_FOCUS',
    coinsReward: 200,
    maxUses: 2000,
    usedCount: 0,
    description: 'بونص التركيز العميق للمنجزين',
    createdAt: new Date().toISOString()
  }
];

function loadServerDb(): ServerDatabase {
  try {
    if (fs.existsSync(DB_FILE)) {
      const data = fs.readFileSync(DB_FILE, 'utf-8');
      return JSON.parse(data);
    }
  } catch (err) {
    console.warn('Failed to load server db, re-initializing:', err);
  }
  const initialDb: ServerDatabase = {
    customMarketItems: [],
    priceOverrides: {},
    coupons: DEFAULT_COUPONS,
    users: {},
    redeemedByUsers: {},
    announcement: 'مرحباً بك في وقتي! أنجز مهامك اليوم، اكتسب النقاط، وزين بروفايلك بأفخم المقتنيات 🌟'
  };
  saveServerDb(initialDb);
  return initialDb;
}

function saveServerDb(db: ServerDatabase) {
  try {
    fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2), 'utf-8');
  } catch (err) {
    console.error('Failed to save server db:', err);
  }
}

let serverDb = loadServerDb();

// Gemini client initialization
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

const FOUNDER_EMAIL = 'am282773159@gmail.com';
const FOUNDER_PASSWORD = '282011##';

// ===================== API ROUTES =====================

// 1. Auth routes
app.post('/api/auth/login', (req: Request, res: Response) => {
  const { email, password } = req.body;
  if (!email || !password) {
    return res.status(400).json({ error: 'الرجاء إدخال البريد الإلكتروني وكلمة المرور' });
  }

  const normalizedEmail = email.trim().toLowerCase();

  // Founder credentials check
  if (normalizedEmail === FOUNDER_EMAIL.toLowerCase() && password === FOUNDER_PASSWORD) {
    let founderUser = serverDb.users[normalizedEmail];
    if (!founderUser) {
      founderUser = {
        id: 'usr-founder-waqti-01',
        email: FOUNDER_EMAIL,
        name: 'المؤسس (Founder)',
        role: 'founder',
        avatar: '👑',
        title: 'صانع المستحيل',
        frame: 'frame-royal',
        theme: 'theme-royal',
        coins: 5000,
        xp: 3500,
        level: 15,
        streak: 12,
        lastActiveDate: new Date().toISOString().split('T')[0],
        inventory: [
          'title-impossible-maker',
          'title-focus-legend',
          'frame-royal-gold',
          'frame-volcanic-flame',
          'avatar-crown',
          'avatar-dragon',
          'theme-midnight',
          'theme-royal',
          'theme-cyberpunk'
        ],
        createdAt: new Date().toISOString()
      };
      serverDb.users[normalizedEmail] = founderUser;
      saveServerDb(serverDb);
    }
    return res.json({ success: true, user: founderUser });
  }

  // Regular user check
  const existingUser = serverDb.users[normalizedEmail];
  if (existingUser) {
    if (existingUser.passwordHash && existingUser.passwordHash !== password) {
      return res.status(401).json({ error: 'كلمة المرور غير صحيحة' });
    }
    const { passwordHash: _, ...safeUser } = existingUser;
    return res.json({ success: true, user: safeUser });
  }

  return res.status(404).json({ error: 'الحساب غير مسجل. يرجى إنشاء حساب جديد أولاً' });
});

app.post('/api/auth/register', (req: Request, res: Response) => {
  const { email, password, name } = req.body;
  if (!email || !password || !name) {
    return res.status(400).json({ error: 'جميع الحقول مطلوبة' });
  }

  const normalizedEmail = email.trim().toLowerCase();

  if (serverDb.users[normalizedEmail]) {
    return res.status(409).json({ error: 'هذا البريد مسجل مسبقاً، يمكنك تسجيل الدخول' });
  }

  const isFounder = normalizedEmail === FOUNDER_EMAIL.toLowerCase();

  const newUser = {
    id: 'usr-' + Date.now().toString(36) + Math.random().toString(36).substring(2, 6),
    email: normalizedEmail,
    passwordHash: password,
    name: name.trim(),
    role: isFounder ? 'founder' : 'user',
    avatar: '🦅',
    title: 'شعلة النشاط',
    frame: 'none',
    theme: 'theme-midnight',
    coins: isFounder ? 5000 : 200, // Starter coins
    xp: 0,
    level: 1,
    streak: 1,
    lastActiveDate: new Date().toISOString().split('T')[0],
    inventory: ['theme-midnight', 'title-energy-flame', 'avatar-falcon'],
    createdAt: new Date().toISOString()
  };

  serverDb.users[normalizedEmail] = newUser;
  saveServerDb(serverDb);

  const { passwordHash: _, ...safeUser } = newUser;
  return res.status(201).json({ success: true, user: safeUser });
});

// 2. Market routes
app.get('/api/market', (_req: Request, res: Response) => {
  // Merge base items with overrides & custom items
  const items = [...INITIAL_MARKET_ITEMS, ...serverDb.customMarketItems].map(item => {
    if (serverDb.priceOverrides[item.id] !== undefined) {
      return { ...item, price: serverDb.priceOverrides[item.id] };
    }
    return item;
  });

  return res.json({
    items,
    announcement: serverDb.announcement
  });
});

app.post('/api/market/add', (req: Request, res: Response) => {
  const userRole = req.headers['x-user-role'];
  const userEmail = req.headers['x-user-email'];

  if (userRole !== 'founder' && userEmail !== FOUNDER_EMAIL) {
    return res.status(403).json({ error: 'صلاحيات المؤسس مطلوبة لتنفيذ هذا الإجراء' });
  }

  const { name, category, price, description, icon, cssClass, rarity, customDrawing, customFrameConfig, customThemePalette } = req.body;
  if (!name || !category || price === undefined) {
    return res.status(400).json({ error: 'بيانات المنتج غير مكتملة' });
  }

  const newItem: MarketItem = {
    id: `custom-${category}-${Date.now()}`,
    name,
    category,
    price: Math.max(0, parseInt(price, 10)),
    description: description || 'عنصر حصري جديد من كورنر المؤسس',
    icon: icon || (category === 'avatar' ? '⭐' : category === 'theme' ? '🎨' : '✨'),
    cssClass: cssClass || undefined,
    rarity: rarity || 'epic',
    isCustom: true,
    customDrawing: customDrawing || undefined,
    customFrameConfig: customFrameConfig || undefined,
    customThemePalette: customThemePalette || undefined,
  };

  serverDb.customMarketItems.push(newItem);
  saveServerDb(serverDb);

  return res.json({ success: true, item: newItem });
});

app.post('/api/market/update-price', (req: Request, res: Response) => {
  const userRole = req.headers['x-user-role'];
  const userEmail = req.headers['x-user-email'];

  if (userRole !== 'founder' && userEmail !== FOUNDER_EMAIL) {
    return res.status(403).json({ error: 'صلاحيات المؤسس مطلوبة' });
  }

  const { itemId, newPrice } = req.body;
  if (!itemId || newPrice === undefined) {
    return res.status(400).json({ error: 'يرجى تحديد المعرف والسعر الجديد' });
  }

  serverDb.priceOverrides[itemId] = Math.max(0, parseInt(newPrice, 10));
  saveServerDb(serverDb);

  return res.json({ success: true, itemId, newPrice: serverDb.priceOverrides[itemId] });
});

// 3. Coupons routes
app.post('/api/coupons/redeem', (req: Request, res: Response) => {
  const { code, userId } = req.body;
  if (!code || !userId) {
    return res.status(400).json({ error: 'رمز الكوبون مطلوب' });
  }

  const cleanCode = code.trim().toUpperCase();
  const coupon = serverDb.coupons.find(c => c.code.toUpperCase() === cleanCode);

  if (!coupon) {
    return res.status(404).json({ error: 'كود الكوبون غير صحيح أو منتهي الصلاحية' });
  }

  if (coupon.usedCount >= coupon.maxUses) {
    return res.status(400).json({ error: 'تم استنفاذ الحد الأقصى لاستخدام هذا الكوبون' });
  }

  const userRedeemed = serverDb.redeemedByUsers[userId] || [];
  if (userRedeemed.includes(coupon.code)) {
    return res.status(400).json({ error: 'لقد قمت باستخدام هذا الكوبون من قبل مسبقاً' });
  }

  coupon.usedCount += 1;
  userRedeemed.push(coupon.code);
  serverDb.redeemedByUsers[userId] = userRedeemed;
  saveServerDb(serverDb);

  return res.json({
    success: true,
    coinsReward: coupon.coinsReward,
    message: `تهانينا! تم تفعيل الكوبون بنجاح وإضافة ${coupon.coinsReward} نقطة إلى رصيدك 🎉`
  });
});

app.post('/api/coupons/generate', (req: Request, res: Response) => {
  const userRole = req.headers['x-user-role'];
  const userEmail = req.headers['x-user-email'];

  if (userRole !== 'founder' && userEmail !== FOUNDER_EMAIL) {
    return res.status(403).json({ error: 'صلاحيات المؤسس مطلوبة' });
  }

  const { code, coinsReward, maxUses, description } = req.body;
  if (!code || !coinsReward) {
    return res.status(400).json({ error: 'الرمز ومقدار النقاط مطلوبان' });
  }

  const cleanCode = code.trim().toUpperCase();
  const existing = serverDb.coupons.find(c => c.code.toUpperCase() === cleanCode);
  if (existing) {
    return res.status(409).json({ error: 'يوجد كوبون مسجل بهذا الرمز مسبقاً' });
  }

  const newCoupon: Coupon = {
    code: cleanCode,
    coinsReward: parseInt(coinsReward, 10),
    maxUses: maxUses ? parseInt(maxUses, 10) : 500,
    usedCount: 0,
    description: description || 'كوبون هدية خاص',
    createdAt: new Date().toISOString()
  };

  serverDb.coupons.push(newCoupon);
  saveServerDb(serverDb);

  return res.json({ success: true, coupon: newCoupon });
});

app.get('/api/coupons', (req: Request, res: Response) => {
  const userRole = req.headers['x-user-role'];
  const userEmail = req.headers['x-user-email'];

  if (userRole !== 'founder' && userEmail !== FOUNDER_EMAIL) {
    return res.status(403).json({ error: 'صلاحيات المؤسس مطلوبة' });
  }

  return res.json({ coupons: serverDb.coupons });
});

// Update announcement
app.post('/api/announcement', (req: Request, res: Response) => {
  const userRole = req.headers['x-user-role'];
  const userEmail = req.headers['x-user-email'];

  if (userRole !== 'founder' && userEmail !== FOUNDER_EMAIL) {
    return res.status(403).json({ error: 'صلاحيات المؤسس مطلوبة' });
  }

  const { message } = req.body;
  serverDb.announcement = message;
  saveServerDb(serverDb);
  return res.json({ success: true, announcement: message });
});

// 4. Hybrid Sync route
app.post('/api/sync', (req: Request, res: Response) => {
  const { user } = req.body;
  if (user && user.email) {
    const normalizedEmail = user.email.toLowerCase();
    const existing = serverDb.users[normalizedEmail] || {};
    serverDb.users[normalizedEmail] = {
      ...existing,
      ...user,
      coins: Math.max(existing.coins || 0, user.coins || 0),
      xp: Math.max(existing.xp || 0, user.xp || 0),
      level: Math.max(existing.level || 1, user.level || 1),
      inventory: Array.from(new Set([...(existing.inventory || []), ...(user.inventory || [])]))
    };
    saveServerDb(serverDb);
  }

  return res.json({
    success: true,
    serverTime: new Date().toISOString(),
    announcement: serverDb.announcement,
    marketUpdatesCount: serverDb.customMarketItems.length
  });
});

// 5. Gemini AI Productivity Coach
app.post('/api/gemini/coach', async (req: Request, res: Response) => {
  const { mode, taskTitle, prompt, currentStats } = req.body;

  // Smart heuristic productivity generator (works offline or when key is not yet set)
  const generateHeuristicAdvice = () => {
    if (mode === 'task_breakdown') {
      const subject = taskTitle || prompt || 'مهمتك';
      return `🎯 خطة تفكيك ذكية لـ «${subject}»:

1. مرحلة التحضير والعصف الذهني (15 دقيقة بومودورو):
   - تجميع المواد والمراجع وحصر المتطلبات الأساسية.
2. بناء الهيكل والمسودة الأولى (25 دقيقة بومودورو):
   - كتابة النقاط العريضة والخطوط الرئيسية دون مقاطعة.
3. التنفيذ المركز والإخراج (25 دقيقة بومودورو):
   - التركيز على إنجاز 80% من النتيجة بجودة ممتازة.
4. المراجعة والتحسين النهائي (15 دقيقة بومودورو):
   - التدقيق واللمسات الفنية الأخيرة وتثبيت الإنجاز.

💡 الخطوة الأولى للبدء خلال 60 ثانية: افتح مستنداً فارغاً الآن واكتب عنوان المهمة مع 3 نقاط رئيسية! 🚀`;
    }

    if (mode === 'productivity_advice') {
      return `⚡ استراتيجية قهر التسويف واستعادة التركيز الفوري:

1. قاعدة الدقيقتين الذهبية:
   - أي جزء من المهمة يستغرق أقل من دقيقتين، قم بإنجازه فوراً الآن لكسر حاجز البداية.
2. عزل المشتتات تماماً:
   - ضع الهاتف في غرفة أخرى أو فعّل وضع عدم الإزعاج لمدة 25 دقيقة كاملة.
3. نظام المكافأة الدوبامينية:
   - بعد إنهاء أول جلسة تركيز، ستكسب نقاطاً إضافية في ماركت وقتي وترفع مستواك!

🔥 تذكر: الدافع لا يأتي قبل العمل، بل العمل هو من يولد الدافع والشغف!`;
    }

    if (mode === 'smart_schedule') {
      return `📅 جدول التركيز المقترح لليوم:

- الجلسة الأولى (09:00 - 09:25): تركيز عميق على المهمة الأعلى أولوية.
- استراحة منعشة (09:25 - 09:30): شرب ماء، تمدد خفيف بدون شاشات.
- الجلسة الثانية (09:30 - 09:55): استكمال المهمة الرئيسية وإنجاز جوهرها.
- استراحة منعشة (09:55 - 10:00): راحة سريعة.
- الجلسة الثالثة (10:00 - 10:25): مراجعة المهام الثانوية والردود السريعة.
- راحة طويلة مستحقة (15 دقيقة): كافئ نفسك! ☕`;
    }

    return `🌟 نصيحة كابتن وقتي لليوم:
قسّم وقتك إلى فترات 25 دقيقة بتركيز تام، ولا تسمح لأي إشعار أن يسلبك لحظات إنجازك. كل دقيقة تروضها ترفعك خطوة نحو القمة! 🏆`;
  };

  try {
    if (!process.env.GEMINI_API_KEY || process.env.GEMINI_API_KEY === 'MY_GEMINI_API_KEY') {
      return res.json({ success: true, advice: generateHeuristicAdvice() });
    }

    const systemInstruction = `
أنت «كابتن وقتي» (Waqti AI Productivity Coach)، المساعد الاستراتيجي الذكي لتطبيق الإنتاجية والجيمفيكيشن "وقتي".
أسلوبك: ملهم، عملي، موجز، ذكي، ويتحدث بلغة عربية فصحى عصرية وحماسية بدون ثرثرة.
المهمة:
- إذا كان النمط "task_breakdown" (تفكيك المهام): قم بتقسيم المهمة المعقدة إلى 3 إلى 5 خطوات ذرية صغيرة، قابلة للإنجاز في جلسات بومودورو محددة (مثال: 25 دقيقة لكل خطوة)، مع نصيحة ذهبية للبدء فوراً.
- إذا كان النمط "productivity_advice" (استراتيجية الإنتاجية): قدم حلاً تكتيكياً فورياً بناءً على وضع المستخدم (التسويف، التشتت، إرهاق المهام).
- إذا كان النمط "smart_schedule" (جدول بومودورو مقترح): اقترح خطة زمنية واقعية لجلسات التركيز والاستراحة تناسب مهامه.

قدم الإجابة بتنسيق جذاب وواضح مع استخدام إيموجيات ملائمة.
`.trim();

    let userPrompt = prompt || '';
    if (mode === 'task_breakdown') {
      userPrompt = `المهمة المطلوب تفكيكها: "${taskTitle || prompt}".
فكك هذه المهمة إلى خطوات تنفيذية واضحة ومقدار دقائق البومودورو المقترح لكل خطوة، وأعطني أول خطوة أبدأ بها خلال دقيقة واحدة!`;
    } else if (mode === 'productivity_advice') {
      userPrompt = `إحصائياتي الحالية:
- المهام المنجزة اليوم: ${currentStats?.completedToday ?? 0}
- جلسات البومودورو: ${currentStats?.totalPomodoros ?? 0}
- سلسلة الأيام المستمرة: ${currentStats?.currentStreak ?? 1}
المشكلة أو التحدي الحالي: "${prompt || 'أشعر بالتشتت وأريد خطة سريعة لاستعادة التركيز الآن'}".`;
    }

    const geminiCall = ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: userPrompt,
      config: {
        systemInstruction,
      },
    });

    const timeoutPromise = new Promise<never>((_, reject) =>
      setTimeout(() => reject(new Error('TIMEOUT')), 4000)
    );

    const response = await Promise.race([geminiCall, timeoutPromise]);
    const reply = response.text || generateHeuristicAdvice();
    return res.json({ success: true, advice: reply });
  } catch (error: any) {
    console.warn('Gemini coach API call failed or timed out, using intelligent fallback:', error?.message);
    return res.json({ success: true, advice: generateHeuristicAdvice() });
  }
});

// Vite middleware in dev or static files in production
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`🚀 Waqti (وقتي) server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
