import 'dotenv/config';
import express from 'express';
import type { Request, Response, NextFunction } from 'express';
import http from 'http';
import path from 'path';
import { fileURLToPath } from 'url';
import { WebSocketServer, WebSocket } from 'ws';
import {
  GoogleGenAI,
  Modality,
  ThinkingLevel,
  Type,
} from '@google/genai';
import type {
  GenerateContentResponse,
  LiveServerMessage,
} from '@google/genai';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT) || 3000;

function getGenAIClient(apiVersion?: string): GoogleGenAI {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
    throw new Error(
      'GEMINI_API_KEY is not configured on the server. Please check the Settings > Secrets panel in AI Studio.'
    );
  }
  return new GoogleGenAI({
    apiKey,
    ...(apiVersion ? { apiVersion } : {}),
    httpOptions: {
      ...(apiVersion ? { apiVersion } : {}),
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

let cachedLiveResolution: { model: string; apiVersion: 'v1beta' | 'v1alpha' } | null = null;
let cachedTtsResolution: { model: string; apiVersion: 'v1beta' | 'v1alpha' } | null = null;

async function resolveLiveModelAndVersion(): Promise<{
  model: string;
  apiVersion: 'v1beta' | 'v1alpha';
  displayName?: string;
  availableLiveModels: string[];
}> {
  const preferredModels = [
    'gemini-3.8-live',
    'gemini-3.8-live-extended-thinking',
    'gemini-2.5-flash-native-audio-preview-12-2025',
    'gemini-2.5-flash-native-audio-preview-09-2025',
  ];

  const availableLiveModels: string[] = [];

  for (const apiVersion of ['v1beta', 'v1alpha'] as const) {
    const ai = getGenAIClient(apiVersion);
    for (const candidate of preferredModels) {
      try {
        const info = await ai.models.get({ model: candidate });
        if (info?.name) {
          cachedLiveResolution = { model: candidate, apiVersion };
          return {
            model: candidate,
            apiVersion,
            displayName: info.displayName,
            availableLiveModels: [info.name],
          };
        }
      } catch {
        // continue checking
      }
    }
    try {
      const pager = await ai.models.list();
      for await (const m of pager) {
        const name = (m.name || '').replace(/^models\//, '');
        const actions = m.supportedActions || [];
        if (
          actions.includes('bidiGenerateContent') ||
          name.includes('live') ||
          name.includes('native-audio')
        ) {
          availableLiveModels.push(`${apiVersion}:${name}`);
        }
      }
      if (availableLiveModels.length > 0) {
        const [ver, firstModel] = availableLiveModels[0].split(':') as ['v1beta' | 'v1alpha', string];
        cachedLiveResolution = { model: firstModel, apiVersion: ver };
        return {
          model: firstModel,
          apiVersion: ver,
          availableLiveModels,
        };
      }
    } catch {
      // continue to next version
    }
  }

  return {
    model: 'gemini-3.8-live',
    apiVersion: 'v1alpha',
    availableLiveModels,
  };
}

async function resolveTtsModelAndVersion(useExpressive: boolean): Promise<{
  model: string;
  apiVersion: 'v1beta' | 'v1alpha';
}> {
  if (cachedTtsResolution && !useExpressive) {
    return cachedTtsResolution;
  }
  const preferred = useExpressive
    ? ['gemini-3.8-flash-tts', 'gemini-3.8-flash-lite-tts', 'gemini-2.5-pro-preview-tts', 'gemini-2.5-flash-preview-tts']
    : ['gemini-3.8-flash-lite-tts', 'gemini-3.8-flash-tts', 'gemini-2.5-flash-preview-tts'];

  for (const apiVersion of ['v1beta', 'v1alpha'] as const) {
    const ai = getGenAIClient(apiVersion);
    for (const candidate of preferred) {
      try {
        const info = await ai.models.get({ model: candidate });
        if (info?.name) {
          const resolved = { model: candidate, apiVersion };
          if (!useExpressive) cachedTtsResolution = resolved;
          return resolved;
        }
      } catch {
        // continue checking
      }
    }
  }
  return { model: preferred[0], apiVersion: 'v1beta' };
}

// Voice profile mapping to supported prebuilt Gemini voices & style directives
export const VOICE_PROFILE_MAP: Record<
  string,
  { voiceName: 'Puck' | 'Charon' | 'Kore' | 'Fenrir' | 'Zephyr'; style: string }
> = {
  'Natural Male': {
    voiceName: 'Charon',
    style: 'Warm, articulate, calm, and natural male conversational tone',
  },
  'Natural Female': {
    voiceName: 'Kore',
    style: 'Clear, empathetic, natural, and poised female conversational tone',
  },
  'Anime Hero': {
    voiceName: 'Fenrir',
    style: 'Energetic, determined, courageous anime protagonist tone with inspiring conviction',
  },
  'Anime Girl': {
    voiceName: 'Zephyr',
    style: 'Bright, cheerful, expressive, and friendly anime companion tone',
  },
  'Japanese Teacher': {
    voiceName: 'Puck',
    style: 'Patient, encouraging, educational Japanese Sensei teaching in English, Hindi, Hinglish, and Japanese with clear pronunciation',
  },
  'My Voice': {
    voiceName: 'Puck',
    style: 'Balanced, clear personal assistant voice (Custom Voice Cloning requires explicit consent & authorized service)',
  },
};

// Simple in-memory rate limiter per IP
const rateLimitMap = new Map<string, { count: number; resetAt: number }>();
function rateLimiter(req: Request, res: Response, next: NextFunction) {
  const ip = req.ip || 'local';
  const now = Date.now();
  const windowMs = 60_000;
  const maxRequests = 60;
  const record = rateLimitMap.get(ip);
  if (!record || now > record.resetAt) {
    rateLimitMap.set(ip, { count: 1, resetAt: now + windowMs });
    return next();
  }
  if (record.count >= maxRequests) {
    return res.status(429).json({
      error: 'Rate limit exceeded (max 60 requests per minute). Please wait a moment and retry.',
    });
  }
  record.count += 1;
  next();
}

function extractSafeMessage(err: unknown): string {
  if (!err) return 'Unknown error';
  if (typeof err === 'string') return err;
  if (err instanceof Error && err.message && err.message !== '[object Object]') {
    return err.message;
  }
  if (typeof err === 'object') {
    const rec = err as Record<string, unknown>;
    for (const k of ['message', 'error', 'reason', 'detail', 'statusText']) {
      const v = rec[k];
      if (typeof v === 'string' && v.trim() && v !== '[object Object]') return v.trim();
      if (v && typeof v === 'object') {
        const nested = extractSafeMessage(v);
        if (nested && nested !== 'Unknown error') return nested;
      }
    }
    try {
      const s = JSON.stringify(rec);
      if (s && s !== '{}') return s.slice(0, 400);
    } catch {
      // ignore
    }
  }
  return 'An unexpected error occurred while communicating with Gemini.';
}

function formatGeminiError(err: unknown): { status: number; message: string; code: string } {
  const rawMessage = extractSafeMessage(err);
  if (rawMessage.includes('403') || rawMessage.includes('PERMISSION_DENIED') || rawMessage.includes('API_KEY_INVALID')) {
    return {
      status: 403,
      code: 'AUTH_ERROR',
      message:
        'Gemini API authentication failed or permission denied. Please verify your GEMINI_API_KEY in the AI Studio Settings > Secrets panel.',
    };
  }
  if (rawMessage.includes('429') || rawMessage.includes('RESOURCE_EXHAUSTED')) {
    return {
      status: 429,
      code: 'QUOTA_EXCEEDED',
      message:
        'Gemini API rate limit or quota reached (RESOURCE_EXHAUSTED). Please wait a few seconds or select a billing-enabled API key in Settings > Secrets.',
    };
  }
  if (rawMessage.includes('404') || rawMessage.includes('NOT_FOUND')) {
    return {
      status: 404,
      code: 'MODEL_NOT_FOUND',
      message: `Requested Gemini model was not found: ${rawMessage}`,
    };
  }
  return {
    status: 500,
    code: 'GEMINI_ERROR',
    message: rawMessage || 'An unexpected error occurred while communicating with Gemini.',
  };
}

async function withRetry<T>(fn: () => Promise<T>, retries = 2, delayMs = 700): Promise<T> {
  let lastError: unknown;
  for (let attempt = 0; attempt <= retries; attempt++) {
    try {
      return await fn();
    } catch (err) {
      lastError = err;
      const msg = err instanceof Error ? err.message : String(err);
      if (msg.includes('403') || msg.includes('API_KEY_INVALID') || msg.includes('not configured')) {
        throw err;
      }
      if (attempt < retries) {
        await new Promise((r) => setTimeout(r, delayMs * Math.pow(2, attempt)));
      }
    }
  }
  throw lastError;
}

async function startServer() {
  const app = express();
  const server = http.createServer(app);

  app.use(express.json({ limit: '25mb' }));
  app.use('/api', rateLimiter);

  // Health & Model verification endpoint
  app.get('/api/health', (_req, res) => {
    const hasKey = Boolean(process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY !== 'MY_GEMINI_API_KEY');
    res.json({
      status: 'ok',
      platform: 'RAJU AI',
      tagline: 'Talk • Learn • Create • Explore',
      apiConfigured: hasKey,
      models: {
        coreBrain: 'gemini-4-hydrogen',
        liveVoice: 'gemini-3.8-live',
        ttsStandard: 'gemini-3.8-flash-lite-tts',
        ttsExpressive: 'gemini-3.8-flash-tts',
      },
      supportedVoices: Object.keys(VOICE_PROFILE_MAP).filter((v) => v !== 'My Voice'),
      timestamp: new Date().toISOString(),
    });
  });

  // Verify Gemini Live model & API authentication status
  app.get('/api/live/verify', async (_req, res) => {
    try {
      const resolved = await resolveLiveModelAndVersion();
      const ai = getGenAIClient(resolved.apiVersion);
      const modelInfo = await ai.models.get({ model: resolved.model });
      return res.json({
        ok: true,
        model: modelInfo?.name || `models/${resolved.model}`,
        apiVersion: resolved.apiVersion,
        displayName: modelInfo?.displayName || resolved.displayName || resolved.model,
        supportedVoices: ['Charon', 'Kore', 'Fenrir', 'Zephyr', 'Puck'],
      });
    } catch (err) {
      const formatted = formatGeminiError(err);
      return res.status(formatted.status).json({
        ok: false,
        error: formatted.message,
        code: formatted.code,
      });
    }
  });

  // Core AI Chat endpoint (supports streaming SSE & unary JSON, multimodal attachments, memory injection)
  app.post('/api/gemini/chat', async (req: Request, res: Response) => {
    try {
      const {
        messages = [],
        prompt = '',
        language = 'English',
        memories = [],
        thinkingLevel = 'HIGH',
        stream = false,
        attachment = null,
        systemContext = '',
      } = req.body;

      if (!prompt && (!messages || messages.length === 0) && !attachment) {
        return res.status(400).json({ error: 'Prompt or conversation messages are required.' });
      }

      const ai = getGenAIClient();

      const memoryContext =
        Array.isArray(memories) && memories.length > 0
          ? `\n\nUSER-APPROVED PERSONAL MEMORIES (Use naturally to personalize responses):\n${memories
              .map((m: { title: string; content: string; category: string }) => `- [${m.category}] ${m.title}: ${m.content}`)
              .join('\n')}`
          : '';

      const sysInstruction = `You are RAJU AI ("Talk • Learn • Create • Explore"), a world-class personal AI assistant powered by Gemini 4 Hydrogen.
Respond primarily in ${language} (supports English, Hindi, Hinglish, and Japanese seamlessly).
Be accurate, structured, empathetic, and insightful. Use clean Markdown formatting for code, lists, formulas, and explanations.${memoryContext}${
        systemContext ? `\n\nMODULE CONTEXT:\n${systemContext}` : ''
      }`;

      const contents: Array<{ role: string; parts: Array<Record<string, unknown>> }> = [];

      if (Array.isArray(messages)) {
        for (const msg of messages.slice(-16)) {
          if (msg && typeof msg.content === 'string' && msg.content.trim()) {
            contents.push({
              role: msg.role === 'assistant' ? 'model' : 'user',
              parts: [{ text: msg.content }],
            });
          }
        }
      }

      const currentParts: Array<Record<string, unknown>> = [];
      if (attachment && attachment.data && attachment.mimeType) {
        currentParts.push({
          inlineData: {
            mimeType: String(attachment.mimeType),
            data: String(attachment.data),
          },
        });
      }
      if (prompt && String(prompt).trim()) {
        currentParts.push({ text: String(prompt) });
      }

      if (currentParts.length > 0) {
        contents.push({ role: 'user', parts: currentParts });
      }

      const resolvedThinking =
        thinkingLevel === 'LOW'
          ? ThinkingLevel.LOW
          : thinkingLevel === 'XHIGH'
            ? ThinkingLevel.XHIGH
            : ThinkingLevel.HIGH;

      if (stream) {
        res.setHeader('Content-Type', 'text/event-stream');
        res.setHeader('Cache-Control', 'no-cache');
        res.setHeader('Connection', 'keep-alive');

        const responseStream = await ai.models.generateContentStream({
          model: 'gemini-4-hydrogen',
          contents,
          config: {
            systemInstruction: sysInstruction,
            thinkingConfig: { thinkingLevel: resolvedThinking },
          },
        });

        let totalTokens = 0;
        for await (const chunk of responseStream) {
          const c = chunk as GenerateContentResponse;
          if (c.usageMetadata?.totalTokenCount) {
            totalTokens = c.usageMetadata.totalTokenCount;
          }
          if (c.text) {
            res.write(`data: ${JSON.stringify({ text: c.text, totalTokens })}\n\n`);
          }
        }
        res.write(`data: ${JSON.stringify({ done: true, totalTokens })}\n\n`);
        return res.end();
      }

      const response = await withRetry(() =>
        ai.models.generateContent({
          model: 'gemini-4-hydrogen',
          contents,
          config: {
            systemInstruction: sysInstruction,
            thinkingConfig: { thinkingLevel: resolvedThinking },
          },
        })
      );

      return res.json({
        text: response.text ?? '',
        model: 'gemini-4-hydrogen',
        usage: {
          promptTokens: response.usageMetadata?.promptTokenCount ?? 0,
          completionTokens: response.usageMetadata?.candidatesTokenCount ?? 0,
          totalTokens: response.usageMetadata?.totalTokenCount ?? 0,
        },
      });
    } catch (err) {
      const formatted = formatGeminiError(err);
      return res.status(formatted.status).json({ error: formatted.message, code: formatted.code });
    }
  });

  // Multimodal Image Analyzer endpoint
  app.post('/api/gemini/analyze-image', async (req: Request, res: Response) => {
    try {
      const { imageBase64, mimeType = 'image/png', prompt = 'Analyze this image in detail.', language = 'English' } = req.body;
      if (!imageBase64) {
        return res.status(400).json({ error: 'Image data (base64) is required for analysis.' });
      }

      const ai = getGenAIClient();
      const response = await withRetry(() =>
        ai.models.generateContent({
          model: 'gemini-4-hydrogen',
          contents: {
            parts: [
              {
                inlineData: {
                  mimeType: String(mimeType),
                  data: String(imageBase64),
                },
              },
              {
                text: `${prompt}\n\nProvide your analysis in ${language}. Include: 1) Visual Overview, 2) Extracted Text / OCR (if any), 3) Diagram/Chart/Concept Breakdown, and 4) Key Takeaways.`,
              },
            ],
          },
          config: {
            thinkingConfig: { thinkingLevel: ThinkingLevel.HIGH },
          },
        })
      );

      return res.json({
        text: response.text ?? '',
        model: 'gemini-4-hydrogen',
        usage: {
          totalTokens: response.usageMetadata?.totalTokenCount ?? 0,
        },
      });
    } catch (err) {
      const formatted = formatGeminiError(err);
      return res.status(formatted.status).json({ error: formatted.message, code: formatted.code });
    }
  });

  // Advanced PDF Reader & Structured Notes/MCQ Analyzer
  app.post('/api/gemini/analyze-pdf', async (req: Request, res: Response) => {
    try {
      const {
        pdfBase64,
        extractedText = '',
        fileName = 'Document.pdf',
        mode = 'full_analysis',
        question = '',
        language = 'English',
      } = req.body;

      if (!pdfBase64 && !extractedText) {
        return res.status(400).json({ error: 'PDF content or document text is required.' });
      }

      const ai = getGenAIClient();
      const parts: Array<Record<string, unknown>> = [];

      if (pdfBase64) {
        parts.push({
          inlineData: {
            mimeType: 'application/pdf',
            data: String(pdfBase64),
          },
        });
      }
      if (extractedText) {
        parts.push({
          text: `Document Title: ${fileName}\nDocument Content:\n${String(extractedText).slice(0, 60000)}`,
        });
      }

      if (mode === 'qa') {
        parts.push({
          text: `Answer the following question based strictly on the provided document (${fileName}) in ${language}:\nQuestion: ${question}`,
        });
        const qaResp = await withRetry(() =>
          ai.models.generateContent({
            model: 'gemini-4-hydrogen',
            contents: { parts },
            config: { thinkingConfig: { thinkingLevel: ThinkingLevel.HIGH } },
          })
        );
        return res.json({
          answer: qaResp.text ?? '',
          usage: { totalTokens: qaResp.usageMetadata?.totalTokenCount ?? 0 },
        });
      }

      parts.push({
        text: `Analyze this document (${fileName}) thoroughly in ${language}. Return a structured JSON object containing: executiveSummary, chapterBreakdown (array of {title, summary}), keyPoints (array of strings), studyNotes (detailed markdown string), and mcqs (array of 4 multiple-choice questions with question, options (4 strings), correctIndex (0-3), and explanation).`,
      });

      const response = await withRetry(() =>
        ai.models.generateContent({
          model: 'gemini-4-hydrogen',
          contents: { parts },
          config: {
            responseMimeType: 'application/json',
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                executiveSummary: { type: Type.STRING },
                chapterBreakdown: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      title: { type: Type.STRING },
                      summary: { type: Type.STRING },
                    },
                    required: ['title', 'summary'],
                  },
                },
                keyPoints: {
                  type: Type.ARRAY,
                  items: { type: Type.STRING },
                },
                studyNotes: { type: Type.STRING },
                mcqs: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      question: { type: Type.STRING },
                      options: { type: Type.ARRAY, items: { type: Type.STRING } },
                      correctIndex: { type: Type.INTEGER },
                      explanation: { type: Type.STRING },
                    },
                    required: ['question', 'options', 'correctIndex', 'explanation'],
                  },
                },
              },
              required: ['executiveSummary', 'chapterBreakdown', 'keyPoints', 'studyNotes', 'mcqs'],
            },
          },
        })
      );

      const parsed = JSON.parse((response.text ?? '{}').trim());
      return res.json({
        analysis: parsed,
        model: 'gemini-4-hydrogen',
        usage: { totalTokens: response.usageMetadata?.totalTokenCount ?? 0 },
      });
    } catch (err) {
      const formatted = formatGeminiError(err);
      return res.status(formatted.status).json({ error: formatted.message, code: formatted.code });
    }
  });

  // Web Research Engine with Official Google Search Grounding
  app.post('/api/gemini/research', async (req: Request, res: Response) => {
    try {
      const { query, language = 'English', depth = 'comprehensive' } = req.body;
      if (!query || !String(query).trim()) {
        return res.status(400).json({ error: 'Search query is required.' });
      }

      const ai = getGenAIClient();
      const response = await withRetry(() =>
        ai.models.generateContent({
          model: 'gemini-4-hydrogen',
          contents: `Conduct a ${depth} research report on: "${query}".
Respond in ${language}.
Structure your report with:
1. Executive Summary
2. Key Findings & Verified Facts (include dates and metrics where available)
3. Comparative Analysis / Perspectives
4. Actionable Takeaways`,
          config: {
            tools: [{ googleSearch: {} }],
          },
        })
      );

      const rawChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks ?? [];
      const sources: Array<{ title: string; uri: string }> = [];
      const seenUris = new Set<string>();

      for (const chunk of rawChunks) {
        const web = (chunk as { web?: { uri?: string; title?: string } }).web;
        if (web?.uri && !seenUris.has(web.uri)) {
          seenUris.add(web.uri);
          sources.push({
            title: web.title || new URL(web.uri).hostname,
            uri: web.uri,
          });
        }
      }

      const searchQueries = response.candidates?.[0]?.groundingMetadata?.webSearchQueries ?? [];

      return res.json({
        report: response.text ?? '',
        sources,
        searchQueries,
        grounded: sources.length > 0 || searchQueries.length > 0,
        model: 'gemini-4-hydrogen',
        usage: { totalTokens: response.usageMetadata?.totalTokenCount ?? 0 },
      });
    } catch (err) {
      const formatted = formatGeminiError(err);
      return res.status(formatted.status).json({ error: formatted.message, code: formatted.code });
    }
  });

  // Study Assistant & Japanese Quiz/Lesson Generator
  app.post('/api/gemini/study-quiz', async (req: Request, res: Response) => {
    try {
      const {
        subject = 'Biology',
        topic = 'Cell Structure and Function',
        difficulty = 'Intermediate',
        language = 'English',
        count = 5,
      } = req.body;

      const ai = getGenAIClient();
      const response = await withRetry(() =>
        ai.models.generateContent({
          model: 'gemini-4-hydrogen',
          contents: `Create a complete study module and ${count} multiple-choice questions for ${subject} — Topic: "${topic}" (Level: ${difficulty}) in ${language} (for Japanese learning, include Japanese script, Romaji, English, and Hindi explanation).`,
          config: {
            responseMimeType: 'application/json',
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                conceptExplanation: {
                  type: Type.STRING,
                  description: 'Clear beginner-to-advanced explanation in Markdown with examples and memory tricks.',
                },
                revisionPlan: {
                  type: Type.ARRAY,
                  items: { type: Type.STRING },
                  description: 'Step-by-step revision checklist.',
                },
                questions: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      question: { type: Type.STRING },
                      options: { type: Type.ARRAY, items: { type: Type.STRING } },
                      correctIndex: { type: Type.INTEGER },
                      explanation: { type: Type.STRING },
                    },
                    required: ['question', 'options', 'correctIndex', 'explanation'],
                  },
                },
              },
              required: ['conceptExplanation', 'revisionPlan', 'questions'],
            },
          },
        })
      );

      const data = JSON.parse((response.text ?? '{}').trim());
      return res.json({
        ...data,
        model: 'gemini-4-hydrogen',
        usage: { totalTokens: response.usageMetadata?.totalTokenCount ?? 0 },
      });
    } catch (err) {
      const formatted = formatGeminiError(err);
      return res.status(formatted.status).json({ error: formatted.message, code: formatted.code });
    }
  });

  // Coding Lab endpoint
  app.post('/api/gemini/coding', async (req: Request, res: Response) => {
    try {
      const { taskType = 'generate', language = 'TypeScript', code = '', instruction = '' } = req.body;
      if (!instruction && !code) {
        return res.status(400).json({ error: 'Coding instruction or source code is required.' });
      }

      const ai = getGenAIClient();
      const prompt = `Task: ${taskType.toUpperCase()}
Target Language / Stack: ${language}
User Request: ${instruction}
${code ? `\nProvided Code:\n\`\`\`${language.toLowerCase()}\n${code}\n\`\`\`` : ''}

Provide production-grade, secure code, architectural explanation, edge-case analysis, and complexity breakdown. Never suggest executing untrusted code on a production server.`;

      const response = await withRetry(() =>
        ai.models.generateContent({
          model: 'gemini-4-hydrogen',
          contents: prompt,
          config: {
            systemInstruction:
              'You are RAJU AI Coding Lab, a Principal Software Architect and Security Engineer. Write clean, modular, well-typed code with clear explanations.',
            thinkingConfig: { thinkingLevel: ThinkingLevel.HIGH },
          },
        })
      );

      return res.json({
        text: response.text ?? '',
        model: 'gemini-4-hydrogen',
        usage: { totalTokens: response.usageMetadata?.totalTokenCount ?? 0 },
      });
    } catch (err) {
      const formatted = formatGeminiError(err);
      return res.status(formatted.status).json({ error: formatted.message, code: formatted.code });
    }
  });

  // Smart Question Generator endpoint (supports MCQs, Fill-in-Blank, Translation, Descriptive + Similar Questions + Anti-Repetition)
  app.post('/api/gemini/smart-questions', async (req: Request, res: Response) => {
    try {
      const {
        topic = 'Japanese JLPT N5 & Particles',
        difficulty = 'Beginner',
        questionTypes = ['mcq', 'fill_blank', 'translation', 'descriptive'],
        count = 6,
        language = 'English',
        similarTo = null,
        excludeStems = [],
      } = req.body;

      const clampedCount = Math.max(1, Math.min(10, Number(count) || 6));
      const allowedTypes = Array.isArray(questionTypes) && questionTypes.length > 0
        ? questionTypes.join(', ')
        : 'mcq, fill_blank, translation, descriptive';

      const antiRepeatBlock =
        Array.isArray(excludeStems) && excludeStems.length > 0
          ? `\nDO NOT repeat or closely paraphrase any of these previously asked questions:\n${excludeStems
              .slice(0, 15)
              .map((s: string, i: number) => `${i + 1}. ${s}`)
              .join('\n')}`
          : '';

      const similarBlock = similarTo
        ? `\nMODE: GENERATE SIMILAR QUESTIONS (${clampedCount} VARIATIONS REQUIRED).\nBase Concept / Solved Question:\n- Topic: ${similarTo.topic || topic}\n- Concept Tag: ${similarTo.conceptTag || 'Core Concept'}\n- Original Question: "${similarTo.question}"\nYou MUST generate ${clampedCount} brand-new, distinct questions testing the EXACT SAME underlying concept using fresh scenarios, different numbers/words, and varied phrasing.`
        : `\nTopic: "${topic}"`;

      const ai = getGenAIClient();
      const generateBatch = async (needed: number, extraExclude: string[]) => {
        const mergedExclude = [...(Array.isArray(excludeStems) ? excludeStems : []), ...extraExclude];
        const dynamicAntiRepeat =
          mergedExclude.length > 0
            ? `\nDO NOT repeat or closely paraphrase any of these questions:\n${mergedExclude
                .slice(0, 20)
                .map((s: string, i: number) => `${i + 1}. ${s}`)
                .join('\n')}`
            : antiRepeatBlock;

        const resp = await withRetry(() =>
          ai.models.generateContent({
            model: 'gemini-4-hydrogen',
            contents: `You are RAJU AI Smart Question Generator.
${similarBlock}
Difficulty Level: ${difficulty}
Allowed Question Types: ${allowedTypes}
CRITICAL ARRAY LENGTH REQUIREMENT: You MUST output an array containing EXACTLY ${needed} distinct question objects in "questions". Never stop after 1 question — produce all ${needed} unique items.
Primary Explanation Language: ${language} (include helpful Hindi hints where relevant for bilingual learners).
${dynamicAntiRepeat}

Requirements for every item:
- For "mcq" type: include exactly 4 distinct options and a valid correctIndex (0-3), and put the exact correct option text in expectedAnswer.
- For "fill_blank" type: use "_____" in the question stem, put the exact missing word/phrase in expectedAnswer, and list valid synonyms/variations in acceptableAnswers.
- For "translation" type: ask user to translate between Japanese / Hindi / English, put the primary translation in expectedAnswer, and list acceptable alternative translations/romaji in acceptableAnswers.
- For "descriptive" type: ask a conceptual "why/how" question and put the model rubric answer in expectedAnswer.
- Always provide a clear, educational explanation and a short conceptTag.`,
            config: {
              responseMimeType: 'application/json',
              responseSchema: {
                type: Type.OBJECT,
                properties: {
                  questions: {
                    type: Type.ARRAY,
                    minItems: String(needed),
                    items: {
                      type: Type.OBJECT,
                      properties: {
                        type: { type: Type.STRING },
                        topic: { type: Type.STRING },
                        difficulty: { type: Type.STRING },
                        conceptTag: { type: Type.STRING },
                        question: { type: Type.STRING },
                        options: { type: Type.ARRAY, items: { type: Type.STRING } },
                        correctIndex: { type: Type.INTEGER },
                        expectedAnswer: { type: Type.STRING },
                        acceptableAnswers: { type: Type.ARRAY, items: { type: Type.STRING } },
                        explanation: { type: Type.STRING },
                        hindiHint: { type: Type.STRING },
                      },
                      required: ['type', 'topic', 'difficulty', 'conceptTag', 'question', 'expectedAnswer', 'explanation'],
                    },
                  },
                },
                required: ['questions'],
              },
            },
          })
        );
        const parsed = JSON.parse((resp.text ?? '{"questions":[]}').trim());
        const list = Array.isArray(parsed.questions)
          ? parsed.questions.map((q: Record<string, unknown>, idx: number) => ({
              id: `sq_${Date.now()}_${extraExclude.length}_${idx}`,
              type: ['mcq', 'fill_blank', 'translation', 'descriptive'].includes(String(q.type))
                ? q.type
                : 'mcq',
              topic: String(q.topic || topic),
              difficulty: String(q.difficulty || difficulty),
              conceptTag: String(q.conceptTag || topic),
              question: String(q.question || ''),
              options: Array.isArray(q.options) ? q.options.map(String) : undefined,
              correctIndex: typeof q.correctIndex === 'number' ? q.correctIndex : 0,
              expectedAnswer: String(q.expectedAnswer || ''),
              acceptableAnswers: Array.isArray(q.acceptableAnswers) ? q.acceptableAnswers.map(String) : [],
              explanation: String(q.explanation || ''),
              hindiHint: q.hindiHint ? String(q.hindiHint) : undefined,
            }))
          : [];
        return { list, tokens: resp.usageMetadata?.totalTokenCount ?? 0 };
      };

      const first = await generateBatch(clampedCount, []);
      let questions = first.list;
      let totalTokens = first.tokens;

      if (questions.length < Math.min(clampedCount, 5)) {
        const remaining = clampedCount - questions.length;
        const second = await generateBatch(
          remaining,
          questions.map((q: { question: string }) => q.question)
        );
        totalTokens += second.tokens;
        const existingStems = new Set(questions.map((q: { question: string }) => q.question.trim()));
        for (const q of second.list) {
          if (!existingStems.has(q.question.trim()) && questions.length < clampedCount) {
            questions.push(q);
            existingStems.add(q.question.trim());
          }
        }
      }

      return res.json({
        questions,
        model: 'gemini-4-hydrogen',
        usage: { totalTokens },
      });
    } catch (err) {
      const formatted = formatGeminiError(err);
      return res.status(formatted.status).json({ error: formatted.message, code: formatted.code });
    }
  });

  // Grade Descriptive / Translation Answer endpoint
  app.post('/api/gemini/grade-answer', async (req: Request, res: Response) => {
    try {
      const { question, expectedAnswer, userAnswer, language = 'English' } = req.body;
      if (!question || !userAnswer) {
        return res.status(400).json({ error: 'Question and userAnswer are required.' });
      }
      const ai = getGenAIClient();
      const response = await withRetry(() =>
        ai.models.generateContent({
          model: 'gemini-4-hydrogen',
          contents: `Evaluate this student's answer accurately and encouragingly in ${language}.
Question: ${question}
Expected Answer / Rubric: ${expectedAnswer}
Student Answer: ${userAnswer}`,
          config: {
            responseMimeType: 'application/json',
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                isCorrect: { type: Type.BOOLEAN },
                scorePercent: { type: Type.INTEGER },
                feedback: { type: Type.STRING },
              },
              required: ['isCorrect', 'scorePercent', 'feedback'],
            },
          },
        })
      );
      const result = JSON.parse((response.text ?? '{}').trim());
      return res.json({
        ...result,
        usage: { totalTokens: response.usageMetadata?.totalTokenCount ?? 0 },
      });
    } catch (err) {
      const formatted = formatGeminiError(err);
      return res.status(formatted.status).json({ error: formatted.message, code: formatted.code });
    }
  });

  // Interactive AI Japanese Tutor endpoint (Hinglish/Hindi/English + Japanese Sensei)
  app.post('/api/gemini/japanese-tutor', async (req: Request, res: Response) => {
    try {
      const {
        mode = 'lesson',
        level = 'Absolute Beginner (N5)',
        explainLanguage = 'Hinglish',
        userMessage = '',
        history = [],
      } = req.body;

      if (!userMessage || !String(userMessage).trim()) {
        return res.status(400).json({ error: 'Please enter a message or Japanese sentence for Sensei.' });
      }

      const ai = getGenAIClient();
      const systemInstruction = `You are RAJU AI Japanese Sensei (日本語の先生), a warm, patient, expert Japanese teacher for Indian and global learners.
Student Level: ${level}
Tutor Mode: ${mode} (supports: daily_lesson, grammar_check, vocabulary, conversation, pronunciation_feedback, jlpt_test).
Explanation Language: ${explainLanguage} (explain clearly in simple ${explainLanguage}, using Devanagari Hindi + easy Hinglish/English where helpful).
Rules:
1. Always display Japanese text with Furigana/Hiragana reading and Romaji.
2. When correcting grammar mistakes, explicitly show: ❌ Incorrect -> ✅ Corrected -> 💡 Why (in ${explainLanguage}).
3. When giving pronunciation feedback, break down syllable mora timing, long vowels (ー), double consonants (っ), and Hindi phonetic equivalents.
4. Never invent Kanji readings; use standard JLPT-verified readings only.`;

      const contents: Array<{ role: string; parts: Array<{ text: string }> }> = [];
      if (Array.isArray(history)) {
        for (const h of history.slice(-10)) {
          if (h?.content) {
            contents.push({
              role: h.role === 'assistant' ? 'model' : 'user',
              parts: [{ text: String(h.content) }],
            });
          }
        }
      }
      contents.push({ role: 'user', parts: [{ text: String(userMessage) }] });

      const response = await withRetry(() =>
        ai.models.generateContent({
          model: 'gemini-4-hydrogen',
          contents,
          config: {
            systemInstruction,
            thinkingConfig: { thinkingLevel: ThinkingLevel.HIGH },
          },
        })
      );

      return res.json({
        reply: response.text ?? '',
        model: 'gemini-4-hydrogen',
        usage: { totalTokens: response.usageMetadata?.totalTokenCount ?? 0 },
      });
    } catch (err) {
      const formatted = formatGeminiError(err);
      return res.status(formatted.status).json({ error: formatted.message, code: formatted.code });
    }
  });

  // Voice Studio Text-to-Speech (Gemini 3.8 TTS)
  app.post('/api/gemini/tts', async (req: Request, res: Response) => {
    try {
      const {
        text,
        voiceProfile = 'Natural Female',
        customStyle = '',
        speed = 'normal',
        useExpressiveModel = false,
      } = req.body;

      if (!text || !String(text).trim()) {
        return res.status(400).json({ error: 'Text is required for speech synthesis.' });
      }

      if (voiceProfile === 'My Voice') {
        return res.status(400).json({
          error:
            'Custom Voice Cloning ("My Voice") requires an authorized voice-cloning service and verified voice-owner consent. Please select one of the 4 active studio voice profiles (Natural Male, Natural Female, Anime Hero, or Anime Girl).',
          code: 'VOICE_CLONING_NOT_AUTHORIZED',
        });
      }

      const profile = VOICE_PROFILE_MAP[voiceProfile] || VOICE_PROFILE_MAP['Natural Female'];
      const speedInstruction =
        speed === 'slow' ? 'Speak slowly and clearly for language learners.' : speed === 'fast' ? 'Speak at a brisk, energetic pace.' : '';
      const finalStyle = [profile.style, customStyle, speedInstruction].filter(Boolean).join('. ');

      const resolvedTts = await resolveTtsModelAndVersion(Boolean(useExpressiveModel));
      const ai = getGenAIClient(resolvedTts.apiVersion);
      const ttsModel = resolvedTts.model;
      const cleanText = String(text).slice(0, 4000);
      const isGemini38Tts = ttsModel.includes('3.8');

      const response = await withRetry(() =>
        ai.models.generateContent({
          model: ttsModel,
          contents: [
            {
              role: 'user',
              parts: [
                isGemini38Tts
                  ? {
                      text: cleanText,
                      speechMetadata: {
                        style: finalStyle,
                      },
                    }
                  : {
                      text: finalStyle ? `[Style: ${finalStyle}]\n${cleanText}` : cleanText,
                    },
              ],
            },
          ],
          config: {
            responseModalities: ['AUDIO'],
            speechConfig: {
              voiceConfig: {
                prebuiltVoiceConfig: {
                  voiceName: profile.voiceName,
                },
              },
            },
          },
        })
      );

      const inlinePart = response.candidates?.[0]?.content?.parts?.[0]?.inlineData;
      const base64Audio = inlinePart?.data;
      if (!base64Audio) {
        return res.status(500).json({ error: 'No audio data returned by the Gemini TTS model.' });
      }

      // If raw PCM audio/l16 is returned by preview TTS models, wrap in 44-byte RIFF WAV header for direct browser playback
      const mime = (inlinePart?.mimeType || 'audio/wav').toLowerCase();
      let finalWavBase64 = base64Audio;
      if (mime.includes('l16') || mime.includes('pcm')) {
        const pcmBuf = Buffer.from(base64Audio, 'base64');
        const wavHeader = Buffer.alloc(44);
        wavHeader.write('RIFF', 0);
        wavHeader.writeUInt32LE(36 + pcmBuf.length, 4);
        wavHeader.write('WAVE', 8);
        wavHeader.write('fmt ', 12);
        wavHeader.writeUInt32LE(16, 16);
        wavHeader.writeUInt16LE(1, 20);
        wavHeader.writeUInt16LE(1, 22);
        wavHeader.writeUInt32LE(24000, 24);
        wavHeader.writeUInt32LE(24000 * 2, 28);
        wavHeader.writeUInt16LE(2, 32);
        wavHeader.writeUInt16LE(16, 34);
        wavHeader.write('data', 36);
        wavHeader.writeUInt32LE(pcmBuf.length, 40);
        finalWavBase64 = Buffer.concat([wavHeader, pcmBuf]).toString('base64');
      }

      return res.json({
        audioBase64: finalWavBase64,
        mimeType: 'audio/wav',
        model: ttsModel,
        apiVersion: resolvedTts.apiVersion,
        voiceName: profile.voiceName,
        voiceProfile,
      });
    } catch (err) {
      const formatted = formatGeminiError(err);
      return res.status(formatted.status).json({ error: formatted.message, code: formatted.code });
    }
  });

  // Official Gemini 3.8 Live API WebSocket Bridge (/live)
  const wss = new WebSocketServer({ noServer: true });

  server.on('upgrade', (request, socket, head) => {
    const pathname = new URL(request.url || '/', `http://${request.headers.host || 'localhost'}`).pathname;
    if (pathname === '/live') {
      wss.handleUpgrade(request, socket, head, (ws) => {
        wss.emit('connection', ws, request);
      });
    }
  });

  wss.on('connection', async (clientWs: WebSocket, req) => {
    const url = new URL(req.url || '/live', `http://${req.headers.host || 'localhost'}`);
    const voiceProfile = url.searchParams.get('voiceProfile') || 'Natural Female';
    const language = url.searchParams.get('language') || 'English';
    const mappedVoice = VOICE_PROFILE_MAP[voiceProfile] || VOICE_PROFILE_MAP['Natural Female'];

    let liveSession: Awaited<ReturnType<GoogleGenAI['live']['connect']>> | null = null;

    try {
      const resolvedLive = cachedLiveResolution || (await resolveLiveModelAndVersion());
      const ai = getGenAIClient(resolvedLive.apiVersion);
      liveSession = await ai.live.connect({
        model: resolvedLive.model,
        config: {
          responseModalities: [Modality.AUDIO],
          inputAudioTranscription: {},
          outputAudioTranscription: {},
          speechConfig: {
            voiceConfig: {
              prebuiltVoiceConfig: {
                voiceName: mappedVoice.voiceName,
              },
            },
          },
          systemInstruction: `You are RAJU AI Live Voice Assistant ("Talk • Learn • Create • Explore").
Voice persona: ${voiceProfile} (${mappedVoice.style}).
Preferred language: ${language} (you seamlessly understand and speak English, Hindi, Hinglish, and Japanese).
Keep spoken answers natural, warm, concise, and conversational.`,
        },
        callbacks: {
          onopen: () => {
            if (clientWs.readyState === WebSocket.OPEN) {
              clientWs.send(
                JSON.stringify({
                  type: 'connected',
                  model: resolvedLive.model,
                  apiVersion: resolvedLive.apiVersion,
                  voiceProfile,
                  voiceName: mappedVoice.voiceName,
                })
              );
            }
          },
          onmessage: (message: LiveServerMessage) => {
            if (clientWs.readyState !== WebSocket.OPEN) return;
            const content = message.serverContent;

            if (content?.inputTranscription?.text) {
              clientWs.send(
                JSON.stringify({
                  type: 'inputTranscript',
                  text: content.inputTranscription.text,
                })
              );
            }

            if (content?.outputTranscription?.text) {
              clientWs.send(
                JSON.stringify({
                  type: 'outputTranscript',
                  text: content.outputTranscription.text,
                })
              );
            }

            for (const part of content?.modelTurn?.parts ?? []) {
              if (part.inlineData?.data) {
                clientWs.send(
                  JSON.stringify({
                    type: 'audio',
                    audio: part.inlineData.data,
                  })
                );
              }
              if (part.text) {
                clientWs.send(
                  JSON.stringify({
                    type: 'text',
                    text: part.text,
                  })
                );
              }
            }

            if (content?.interrupted) {
              clientWs.send(JSON.stringify({ type: 'interrupted' }));
            }

            if (content?.turnComplete) {
              clientWs.send(JSON.stringify({ type: 'turnComplete' }));
            }
          },
          onerror: (err: unknown) => {
            if (clientWs.readyState === WebSocket.OPEN) {
              const formatted = formatGeminiError(err);
              clientWs.send(JSON.stringify({ type: 'error', error: formatted.message }));
            }
          },
          onclose: () => {
            if (clientWs.readyState === WebSocket.OPEN) {
              clientWs.send(JSON.stringify({ type: 'closed' }));
            }
          },
        },
      });
    } catch (err) {
      const formatted = formatGeminiError(err);
      if (clientWs.readyState === WebSocket.OPEN) {
        clientWs.send(JSON.stringify({ type: 'error', error: formatted.message }));
        clientWs.close();
      }
      return;
    }

    clientWs.on('message', (raw) => {
      if (!liveSession) return;
      try {
        const msg = JSON.parse(raw.toString());
        if (msg.audio) {
          liveSession.sendRealtimeInput({
            audio: {
              data: msg.audio,
              mimeType: 'audio/pcm;rate=16000',
            },
          });
        } else if (msg.text) {
          liveSession.sendRealtimeInput({
            text: String(msg.text),
          });
        }
      } catch (e) {
        console.error('Error forwarding Live WS message:', e);
      }
    });

    clientWs.on('close', () => {
      try {
        liveSession?.close();
      } catch {
        // ignore close error
      }
    });
  });

  // Vite middleware in development, static assets in production
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        ws: { server },
        allowedHosts: true,
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  server.listen(PORT, '0.0.0.0', () => {
    console.log(`RAJU AI Server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
