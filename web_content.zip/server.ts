import express from "express";
import path from "path";
import fs from "fs";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, ThinkingLevel } from "@google/genai";
import crypto from "crypto";

import Stripe from "stripe";
import { 
  initDb, getUser, incrementMessageCount, 
  getUserByStripeCustomerId, updateUserSubscription, cancelSubscription, run, all
} from "./src/db/index.js";

import Razorpay from "razorpay";

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || "sk_test_dummy", {
  apiVersion: "2025-01-27.acacia" as any,
});

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

// Plan limits & Configuration
const USAGE_LIMITS = {
  FREE: { messages: 50, features: ['basic', 'images', 'camera', 'advanced'] },
  PRO: { messages: 200, features: ['basic', 'images', 'camera', 'advanced'] },
  PREMIUM: { messages: 1000, features: ['basic', 'images', 'camera', 'advanced', 'priority'] }
};

const PLAN_MODELS = {
  FREE: 'gemini-3.1-flash-lite',
  PRO: 'gemini-3.1-flash-lite',
  PREMIUM: 'gemini-3.1-flash-lite'
};

const detectEmotion = (text: string): 'SAD' | 'HAPPY' | 'NEUTRAL' => {
  const sadWords = ["sad", "dukh", "rona", "akela", "upset", "pareshan", "alone", "udaas", "kharab", "mood off"];
  const happyWords = ["happy", "khush", "mazza", "hasi", "smile", "good", "achha", "badhiya", "great"];
  const lower = (text || "").toLowerCase();
  if (sadWords.some(word => lower.includes(word))) return 'SAD';
  if (happyWords.some(word => lower.includes(word))) return 'HAPPY';
  return 'NEUTRAL';
};

async function startServer() {
  await initDb();
  
  const app = express();
  const PORT = 3000;

  // Stripe Webhook MUST be raw body
  app.post("/api/webhook", express.raw({ type: 'application/json' }), async (req, res) => {
    const sig = req.headers['stripe-signature'];
    let event;

    try {
      if (!process.env.STRIPE_WEBHOOK_SECRET) {
        throw new Error('STRIPE_WEBHOOK_SECRET is not configured');
      }
      event = stripe.webhooks.constructEvent(req.body, sig as string, process.env.STRIPE_WEBHOOK_SECRET);
    } catch (err: any) {
      console.error(`Webhook Error: ${err.message}`);
      return res.status(400).send(`Webhook Error: ${err.message}`);
    }

    try {
      switch (event.type) {
        case 'checkout.session.completed': {
          const session = event.data.object as Stripe.Checkout.Session;
          if (session.client_reference_id) {
            const subscription = await stripe.subscriptions.retrieve(session.subscription as string) as any;
            const plan = session.metadata?.plan || 'PRO';
            await updateUserSubscription(
              session.client_reference_id, 
              plan, 
              'ACTIVE', 
              subscription.id, 
              subscription.current_period_end,
              session.customer as string
            );
          }
          break;
        }
        case 'customer.subscription.updated': {
          const subscription = event.data.object as any;
          const user = await getUserByStripeCustomerId(subscription.customer as string);
          if (user) {
            await updateUserSubscription(
              user.id, 
              user.plan, 
              subscription.status === 'active' ? 'ACTIVE' : 'PAST_DUE', 
              subscription.id, 
              subscription.current_period_end
            );
          }
          break;
        }
        case 'customer.subscription.deleted': {
          const subscription = event.data.object as any;
          const user = await getUserByStripeCustomerId(subscription.customer as string);
          if (user) {
             await cancelSubscription(user.id);
          }
          break;
        }
      }
      res.json({ received: true });
    } catch (error) {
      console.error('Error processing webhook:', error);
      res.status(500).send('Internal Server Error');
    }
  });

  // Body parsers for other routes
  app.use(express.json({ limit: '50mb' }));
  app.use(express.urlencoded({ extended: true, limit: '50mb' }));

  app.get("/api/health", (req, res) => {
    res.json({ status: "ok" });
  });

  // Direct APK download endpoint
  app.get(["/api/download/apk", "/IndiaGPT-release.apk", "/app-release.apk"], (req, res) => {
    const apkPath = path.join(process.cwd(), "IndiaGPT-release.apk");
    if (fs.existsSync(apkPath)) {
      res.setHeader("Content-Disposition", 'attachment; filename="IndiaGPT-release.apk"');
      res.setHeader("Content-Type", "application/vnd.android.package-archive");
      return res.sendFile(apkPath);
    }
    res.status(404).send("APK not found");
  });

  // Serve standalone HTML/CSS/JS
  app.get("/app.html", (req, res) => {
    res.sendFile(path.join(process.cwd(), "app.html"));
  });
  app.get("/app.css", (req, res) => {
    res.setHeader("Content-Type", "text/css");
    res.sendFile(path.join(process.cwd(), "app.css"));
  });
  app.get("/app.js", (req, res) => {
    res.setHeader("Content-Type", "application/javascript");
    res.sendFile(path.join(process.cwd(), "app.js"));
  });

  app.get("/api/config", (req, res) => {
    try {
      const fbConfig = JSON.parse(fs.readFileSync(path.join(process.cwd(), "firebase-applet-config.json"), "utf8"));
      if (fbConfig.oAuthClientId) {
        return res.json({ googleClientId: fbConfig.oAuthClientId });
      }
    } catch (e) {
      console.warn("Could not read firebase-applet-config.json");
    }
    res.json({ googleClientId: process.env.GOOGLE_CLIENT_ID || process.env.VITE_GOOGLE_CLIENT_ID });
  });

  app.post("/api/user/profile", async (req, res) => {
    try {
      const userId = req.headers['x-user-id'] as string;
      if (!userId) return res.status(401).json({ error: "Unauthorized" });
      const { name, email, dob } = req.body;
      await run(`UPDATE users SET name = ?, email = ?, dob = ? WHERE id = ?`, [name, email, dob, userId]);
      res.json({ success: true });
    } catch (e) {
      console.error("Profile update error:", e);
      res.status(500).json({ error: "Failed to update profile" });
    }
  });

  // Get current user plan
  app.get("/api/user", async (req, res) => {
    try {
      const userId = req.headers['x-user-id'] as string;
      if (!userId) return res.status(401).json({ error: "Unauthorized" });

      const user = await getUser(userId);
      
      // Expire old subscriptions automatically
      if (user.status === 'ACTIVE' && user.current_period_end) {
        const now = Math.floor(Date.now() / 1000);
        if (now > user.current_period_end + 86400) { // 1 day grace
          await updateUserSubscription(user.id, 'FREE', 'EXPIRED', user.stripe_subscription_id, user.current_period_end);
          user.plan = 'FREE';
          user.status = 'EXPIRED';
        }
      }

      const limits = USAGE_LIMITS[user.plan as keyof typeof USAGE_LIMITS] || USAGE_LIMITS.FREE;
      
      res.json({
        id: user.id,
        plan: user.plan,
        status: user.status,
        messageCount: user.message_count,
        maxMessages: limits.messages,
        currentPeriodEnd: user.current_period_end
      });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  const razorpayInstance = new Razorpay({
    key_id: process.env.RAZORPAY_KEY_ID || 'rzp_test_dummy_key',
    key_secret: process.env.RAZORPAY_KEY_SECRET || 'dummy_secret'
  });

  // Create Razorpay Order
  app.post("/api/razorpay/create_order", async (req, res) => {
    try {
      const { plan } = req.body;
      const userId = req.headers['x-user-id'] as string;
      
      if (!userId) return res.status(401).json({ error: "Unauthorized" });

      const amount = plan === 'PRO' ? 49900 : (plan === 'PREMIUM' ? 99900 : 0);
      
      if (amount === 0) return res.status(400).json({ error: "Invalid plan" });

      const options = {
        amount,
        currency: "INR",
        receipt: `receipt_${userId}_${Date.now()}`
      };

      const order = await razorpayInstance.orders.create(options);
      res.json(order);
    } catch (err: any) {
      console.error("Razorpay order error:", err);
      res.status(500).json({ error: "Failed to create Razorpay order." });
    }
  });

  // Verify Razorpay Payment
  app.post("/api/razorpay/verify", async (req, res) => {
    try {
      const { razorpay_order_id, razorpay_payment_id, razorpay_signature, plan } = req.body;
      const userId = req.headers['x-user-id'] as string;

      if (!userId) return res.status(401).json({ error: "Unauthorized" });

      const body = razorpay_order_id + "|" + razorpay_payment_id;
      const expectedSignature = crypto.createHmac('sha256', process.env.RAZORPAY_KEY_SECRET || 'dummy_secret')
                                      .update(body.toString())
                                      .digest('hex');

      if (expectedSignature === razorpay_signature) {
        await run(`UPDATE users SET plan = ?, message_count = 0, status = 'active' WHERE id = ?`, [plan, userId]);
        res.json({ success: true, plan });
      } else {
        res.status(400).json({ error: "Invalid signature. Payment verification failed." });
      }
    } catch (err: any) {
      console.error("Razorpay verify error:", err);
      res.status(500).json({ error: "Failed to verify Razorpay payment." });
    }
  });

  // Create Stripe checkout session
  app.post("/api/subscription/checkout", async (req, res) => {
    try {
      const { plan } = req.body;
      const userId = req.headers['x-user-id'] as string;
      
      if (!userId) return res.status(401).json({ error: "Unauthorized" });

      let priceId;
      if (plan === 'PRO') {
        priceId = process.env.STRIPE_PRICE_PRO_MONTHLY || 'price_123';
      } else if (plan === 'PREMIUM') {
        priceId = process.env.STRIPE_PRICE_PREMIUM_MONTHLY || 'price_456';
      } else {
        return res.status(400).json({ error: "Invalid plan selected" });
      }

      const stripeKey = process.env.STRIPE_SECRET_KEY;
      if (!stripeKey || stripeKey === 'sk_test_dummy') {
         return res.status(400).json({ error: "Stripe Payment Gateway is not configured. Please add your live STRIPE_SECRET_KEY in the AI Studio Settings > Secrets panel to enable real Indian Banking and UPI Payments." });
      }

      const session = await stripe.checkout.sessions.create({
        // Leave payment_method_types undefined to let Stripe Dashboard (including UPI/Bank) govern the payment methods.
        line_items: [{ price: priceId, quantity: 1 }],
        mode: 'subscription',
        success_url: `${process.env.APP_URL || 'http://localhost:3000'}?payment=success&session_id={CHECKOUT_SESSION_ID}`,
        cancel_url: `${process.env.APP_URL || 'http://localhost:3000'}?payment=cancelled`,
        client_reference_id: userId,
        metadata: { plan }
      });

      res.json({ id: session.id, url: session.url });
    } catch (error: any) {
      console.error("Stripe error:", error);
      res.status(500).json({ error: error.message });
    }
  });

  // Customer Portal
  app.post("/api/subscription/portal", async (req, res) => {
    try {
      const { userId } = req.body;
      if (!userId) return res.status(401).send("Unauthorized");
      
      const user = await getUser(userId);
      if (!user?.stripe_customer_id) {
         return res.status(400).send("No active subscription found.");
      }

      const stripeKey = process.env.STRIPE_SECRET_KEY;
      if (!stripeKey || stripeKey === 'sk_test_dummy') {
         return res.status(400).send("Stripe API Key is not configured in Secrets.");
      }

      const session = await stripe.billingPortal.sessions.create({
        customer: user.stripe_customer_id,
        return_url: `${process.env.APP_URL || 'http://localhost:3000'}/`,
      });
      
      res.redirect(session.url);
    } catch (e: any) {
      console.error("Portal error:", e);
      res.status(500).send("Failed to create portal session.");
    }
  });

  // Chat Streaming Endpoint
  app.post("/api/chat", async (req, res) => {
    try {
      const { history = [], message = "", images = [], model, persona = "Female", userName, language = "Hinglish" } = req.body;
      const userId = req.headers['x-user-id'] as string;
      
      if (!userId) {
        return res.status(401).json({ error: "Unauthorized. User ID required." });
      }

      const user = await getUser(userId);
      const limits = USAGE_LIMITS[user.plan as keyof typeof USAGE_LIMITS] || USAGE_LIMITS.FREE;
      
      if (user.message_count >= limits.messages) {
        return res.status(403).json({ 
          error: `You have reached your ${user.plan} plan limit (${limits.messages} messages). Please upgrade to continue.`,
          requiresUpgrade: true
        });
      }

      if (Array.isArray(images) && images.length > 0) {
        if (!limits.features.includes('images')) {
          return res.status(403).json({ 
            error: "Image analysis is a PRO feature. Upgrade to Pro to unlock Vision capabilities.",
            requiresUpgrade: true
          });
        }
      }

      await incrementMessageCount(userId);
      const emotion = detectEmotion(message);
      
      const systemInstruction = `You are India GPT, an advanced, highly intelligent, and deeply empathetic AI assistant with real-time live vision capabilities (like Google Gemini Live). 
Your current persona is ${persona}. 
User Name: ${userName || 'Dost'}.
Detected User Emotion: ${emotion}.
Selected Language: ${language}

CRITICAL LANGUAGE REQUIREMENT: You MUST reply naturally and fluently in ${language}.

CORE DIRECTIVES & MULTIMODAL VISION CAPABILITIES:
- **LIVE CAMERA & REAL-TIME VISION:** When images or camera frames are provided, carefully examine the real-world objects, devices, brands, models, text, and surroundings.
- **OBJECT & DEVICE IDENTIFICATION:** When the user asks "Yeh kya hai?", identify the object immediately with high precision (e.g. "Yeh ek mobile phone hai", "Yeh ek laptop hai", "Yeh ek watch hai", etc.).
- **DETAILED FOLLOW-UPS (e.g., "Kaun sa mobile hai?"):** When asked follow-ups, closely analyze visual cues (e.g., camera lens layout, logo, bezels, design, color, buttons) to specify the exact brand and likely model series (e.g., "Yeh Apple ka iPhone hai, iske triple-camera module aur flat edges se yeh iPhone 14 Pro / 15 Pro lag raha hai.").
- **CONVERSATIONAL & CRISP FOR VOICE:** Responses are read aloud to the user via speech synthesis, so keep your answers crisp, lively, natural, and helpful (1-3 sentences for live camera responses unless asked for detailed explanations).
- **PERFECT CONVERSATION MEMORY:** Remember what was previously shown or discussed across turns.`;

      res.setHeader("Content-Type", "text/event-stream");
      res.setHeader("Cache-Control", "no-cache");
      res.setHeader("Connection", "keep-alive");
      res.flushHeaders?.();

      const formattedContents: any[] = [];
      if (Array.isArray(history)) {
        for (const msg of history) {
          if (msg && msg.content) {
            formattedContents.push({
              role: msg.role === 'model' ? 'model' : 'user',
              parts: [{ text: String(msg.content) }],
            });
          }
        }
      }

      const currentParts: any[] = [];
      if (Array.isArray(images) && images.length > 0) {
        for (const img of images) {
          if (typeof img === 'string' && img.startsWith('data:')) {
            const mimeMatch = img.match(/^data:([^;]+);base64,(.+)$/);
            if (mimeMatch) {
              currentParts.push({ inlineData: { mimeType: mimeMatch[1], data: mimeMatch[2] } });
            }
          }
        }
      }

      currentParts.push({ text: message || "Describe these images" });
      formattedContents.push({ role: 'user', parts: currentParts });

      const preferredModel = (req.body.model && typeof req.body.model === 'string' && req.body.model.trim())
        ? req.body.model.trim()
        : (PLAN_MODELS[user.plan as keyof typeof PLAN_MODELS] || 'gemini-3.1-flash-lite');

      // Build prioritized candidate list with high-availability fallback models
      const candidateModels = Array.from(new Set([
        preferredModel === 'gemini-3.8-flash' ? 'gemini-3.1-flash-lite' : preferredModel,
        'gemini-3.1-flash-lite',
        'gemini-flash-latest',
        'gemini-3.8-flash'
      ])).filter(Boolean);

      let hasSentAnyChunk = false;
      let streamedSuccessfully = false;
      let lastFailureError: any = null;

      for (const modelToTry of candidateModels) {
        if (streamedSuccessfully || hasSentAnyChunk) break;
        try {
          const config: any = { systemInstruction };
          if (modelToTry.includes("gemini-3.8-flash") || modelToTry.includes("gemini-3.8-pro")) {
            config.thinkingConfig = { thinkingLevel: ThinkingLevel.LOW };
          }

          const stream = await ai.models.generateContentStream({
            model: modelToTry,
            contents: formattedContents,
            config,
          });

          for await (const chunk of stream) {
            const text = chunk.text;
            if (text) {
              hasSentAnyChunk = true;
              res.write(`data: ${JSON.stringify({ text })}\n\n`);
            }
          }
          streamedSuccessfully = true;
          break;
        } catch (err: any) {
          lastFailureError = err;
          console.warn(`Model ${modelToTry} attempt failed, trying fallback:`, err?.message || err);
          if (hasSentAnyChunk) {
            break;
          }
          await new Promise(r => setTimeout(r, 100));
        }
      }

      if (!streamedSuccessfully && !hasSentAnyChunk) {
        try {
          const recoveryRes = await ai.models.generateContent({
            model: 'gemini-3.1-flash-lite',
            contents: formattedContents,
            config: { systemInstruction },
          });
          const recoveryText = recoveryRes.text;
          if (recoveryText) {
            res.write(`data: ${JSON.stringify({ text: recoveryText })}\n\n`);
            streamedSuccessfully = true;
          }
        } catch (recoveryErr) {
          console.error("Recovery generateContent attempt failed:", recoveryErr);
        }
      }

      if (!streamedSuccessfully && !hasSentAnyChunk) {
        const isQuota = lastFailureError?.status === 429 || lastFailureError?.message?.includes('429') || lastFailureError?.message?.toLowerCase()?.includes('quota');
        const fallbackText = isQuota
          ? "Abhi traffic zyada hone ke kaaran rate limit aayi hai. Kripya 5 second baad punah prayaas karein."
          : "Server par traffic zyada hai. Kripya 2-3 second baad dubara prayaas karein.";
        res.write(`data: ${JSON.stringify({ text: fallbackText })}\n\n`);
      }

      res.write(`data: [DONE]\n\n`);
      res.end();
    } catch (error: any) {
      console.error("Server error in /api/chat:", error);
      const errorMessage = error?.status === 429 || error?.message?.includes('429')
        ? "Too many requests right now. Please wait a moment and try again."
        : (error?.message || "An error occurred while generating the response.");
      
      if (!res.headersSent) {
        res.status(500).json({ error: errorMessage });
      } else {
        res.write(`data: ${JSON.stringify({ error: errorMessage })}\n\n`);
        res.end();
      }
    }
  });

  // Image Generation Endpoint
  app.post("/api/generate-image", async (req, res) => {
    try {
      const userId = req.headers['x-user-id'] as string;
      if (!userId) return res.status(401).json({ error: "Unauthorized" });

      const user = await getUser(userId);
      const limits = USAGE_LIMITS[user.plan as keyof typeof USAGE_LIMITS] || USAGE_LIMITS.FREE;

      if (!limits.features.includes('advanced') || user.plan === 'FREE') {
        return res.status(403).json({ error: "Image generation is a PRO feature. Please upgrade your plan." });
      }

      const { prompt = "", referenceImages = [] } = req.body;
      const enhancedPrompt = `Generate a highly realistic, cinematic photograph. Quality: 8k resolution, masterpiece, photorealistic. User Request: ${prompt}`;
      
      const parts: any[] = [];
      if (Array.isArray(referenceImages)) {
        for (const img of referenceImages) {
          if (typeof img === 'string' && img.startsWith('data:')) {
            const mimeMatch = img.match(/^data:([^;]+);base64,(.+)$/);
            if (mimeMatch) {
              parts.push({ inlineData: { mimeType: mimeMatch[1], data: mimeMatch[2] } });
            }
          }
        }
      }
      parts.push({ text: enhancedPrompt });

      const response = await ai.models.generateContent({
        model: 'gemini-3.1-flash-lite-image',
        contents: { parts },
        config: { imageConfig: { aspectRatio: "1:1" } },
      });

      let imageUrl: string | null = null;
      for (const part of response.candidates?.[0]?.content?.parts || []) {
        if (part.inlineData) {
          imageUrl = `data:image/png;base64,${part.inlineData.data}`;
          break;
        }
      }

      if (imageUrl) {
        return res.json({ imageUrl });
      } else {
        return res.status(500).json({ error: "No image returned by the model" });
      }
    } catch (error: any) {
      console.error("Server error in /api/generate-image:", error);
      const isQuota = error?.status === 429 || error?.message?.includes('429');
      return res.status(isQuota ? 429 : 500).json({
        error: isQuota
          ? "You have exceeded your image generation quota. Please upgrade or try again later."
          : (error?.message || "Failed to generate image.")
      });
    }
  });

  app.get("/api/download-apk", (req, res) => {
    const apkPath = path.join(process.cwd(), "IndiaGPT-release.apk");
    if (fs.existsSync(apkPath)) {
      res.download(apkPath, "IndiaGPT-release.apk");
    } else {
      res.status(404).send("APK file not found");
    }
  });

  app.get("/api/admin/stats", async (req, res) => {
    try {
      const users = await all<any>("SELECT plan, status, message_count FROM users");
      const stats = {
        totalUsers: users.length,
        freeUsers: users.filter(u => u.plan === 'FREE').length,
        proUsers: users.filter(u => u.plan === 'PRO').length,
        premiumUsers: users.filter(u => u.plan === 'PREMIUM').length,
        activeSubs: users.filter(u => u.status === 'ACTIVE' && u.plan !== 'FREE').length,
        totalMessages: users.reduce((acc, u) => acc + (u.message_count || 0), 0)
      };
      res.json(stats);
    } catch (e) {
      res.status(500).json({ error: "Failed to fetch stats" });
    }
  });

  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*all', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
