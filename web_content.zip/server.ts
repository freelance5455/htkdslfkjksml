import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json({ limit: '10mb' }));

// Health check endpoint
app.get('/api/health', (_req: Request, res: Response) => {
  res.json({
    status: 'ok',
    app: 'Shadow Radiology – Paramedical DZ',
    hasApiKey: Boolean(process.env.GEMINI_API_KEY),
    timestamp: new Date().toISOString()
  });
});

// Proxy endpoint to download 3D GLB models from Google or public repositories safely avoiding CORS
app.get('/api/download-model', async (req: Request, res: Response) => {
  let modelUrl = req.query.url as string;

  if (!modelUrl) {
    return res.status(400).json({ error: 'Missing model URL parameter' });
  }

  // Normalize Google Drive links if provided
  const gDriveMatch = modelUrl.match(/drive\.google\.com\/(?:file\/d\/|open\?id=)([^/?&]+)/);
  if (gDriveMatch && gDriveMatch[1]) {
    modelUrl = `https://drive.google.com/uc?export=download&id=${gDriveMatch[1]}&confirm=t`;
  }

  try {
    const fetchResponse = await fetch(modelUrl, {
      redirect: 'follow',
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36 Shadow-Radiology-DZ/1.0',
        'Accept': '*/*'
      }
    });

    if (!fetchResponse.ok) {
      return res.status(fetchResponse.status).json({
        error: `Failed to fetch remote 3D model: ${fetchResponse.statusText}`
      });
    }

    const contentType = fetchResponse.headers.get('content-type') || 'model/gltf-binary';
    const contentLength = fetchResponse.headers.get('content-length');

    res.setHeader('Content-Type', contentType);
    if (contentLength) {
      res.setHeader('Content-Length', contentLength);
    }
    res.setHeader('Access-Control-Allow-Origin', '*');

    const arrayBuffer = await fetchResponse.arrayBuffer();
    const buffer = Buffer.from(arrayBuffer);
    return res.send(buffer);
  } catch (err: any) {
    console.error('Error downloading 3D model:', err);
    return res.status(500).json({
      error: 'DOWNLOAD_FAILED',
      message: err?.message || 'Error occurred while downloading remote 3D model'
    });
  }
});

// Gemini AI Medical Radiology Assistant route
app.post('/api/ai/chat', async (req: Request, res: Response) => {
  const { prompt, conversationHistory = [], language = 'ar' } = req.body;

  if (!prompt) {
    return res.status(400).json({ error: 'Missing prompt' });
  }

  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return res.status(503).json({
      error: 'API_KEY_NOT_CONFIGURED',
      message: 'Gemini API key is not configured on the server. Using local offline medical knowledge engine.'
    });
  }

  try {
    const ai = new GoogleGenAI({ apiKey });

    const systemInstruction = `You are "Shadow Radiology AI" (ظِل الأشعة), an elite medical and radiological AI tutor inspired by Solo Leveling, specifically built for Algerian paramedical students (طلبة الشبه طبي في الجزائر - تخصص تقني في الأشعة والمناورة في التصوير الطبي MIM).
Language: Respond in ${language === 'ar' ? 'clear pedagogical Arabic with medical French terms in parentheses' : language === 'fr' ? 'French with Arabic explanations where helpful' : 'English'}.
Personality: Authoritative, wise, encouraging like a Shadow Monarch mentor, strictly accurate medically.
Domains:
- Radiologie conventionnelle (X-ray, kVp, mAs, tube à rayons X, incidences, projections)
- TDM / Scanner (Hounsfield units, coupes, fenêtres osseuse/parenchyme, injection de PDC iodé)
- IRM (T1, T2, FLAIR, séquences, contre-indications)
- Échographie (ultrasons, impédance, effet Doppler, sondes)
- Radioprotection (ALARA, dosimétrie, blindage, décrets algériens de protection radiologique)
- Anatomie radiologique & repères squelettiques
- Communication soignant-soigné (instructions en français et en dialecte algérien / Darija pour rassurer le patient).

Structure your response:
1. Direct clear answer / Clinical concept explanation
2. Key anatomical or technical parameters (kV, positionnement, repères)
3. Advice for paramedical students during clinical stage / internship (Stage pratique en milieu hospitalier DZ).
4. Safety & radiation warning if applicable.

IMPORTANT: Always include a short disclaimer that this is strictly educational for paramedical training, not for clinical diagnosis of real patients.`;

    const contents = [
      ...conversationHistory.map((msg: { role: string; content: string }) => ({
        role: msg.role === 'assistant' ? 'model' : 'user',
        parts: [{ text: msg.content }]
      })),
      {
        role: 'user',
        parts: [{ text: prompt }]
      }
    ];

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents,
      config: {
        systemInstruction,
        temperature: 0.4,
      }
    });

    const reply = response.text || 'لم يتم استلام رد من نموذج الذكاء الاصطناعي.';
    return res.json({ reply, source: 'gemini-live' });
  } catch (error: any) {
    console.error('Error generating AI response:', error);
    return res.status(500).json({
      error: 'AI_GENERATION_FAILED',
      message: error?.message || 'Error occurred while contacting Gemini API.'
    });
  }
});

// Setup Vite middleware in dev or static files in production
async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';

  if (!isProd) {
    const { createServer } = await import('vite');
    const vite = await createServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, () => {
    console.log(`Shadow Radiology server running on port ${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
});
