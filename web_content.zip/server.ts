import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import dotenv from "dotenv";
import { GoogleGenAI, ThinkingLevel } from "@google/genai";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = parseInt(process.env.PORT || "3000", 10);

app.use(express.json());

// Initialize GoogleGenAI
const apiKey = process.env.GEMINI_API_KEY;
const ai = apiKey
  ? new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    })
  : null;

// Scientific database of plants and bioscience entities in Kochubon
const SCIENTIFIC_SPECIES_DATA = [
  {
    id: "taro",
    bengaliName: "কচু (কচুবন প্রধান উদ্ভিদ)",
    scientificName: "Colocasia esculenta",
    family: "Araceae",
    order: "Alismatales",
    growthDurationDays: 4,
    biochemicalCompounds: [
      {
        name: "Calcium Oxalate Crystals (Raphides)",
        formula: "CaC2O4",
        pubchemCid: 9684,
        role: "Microscopic needle-like crystals causing throat irritation if unboiled; natural plant defense mechanism.",
      },
      {
        name: "Amylose / Resistant Starch",
        formula: "(C6H10O5)n",
        pubchemCid: 70678550,
        role: "Easily digestible hypoallergenic complex carbohydrates in taro corms.",
      },
      {
        name: "Anthocyanins (Cyanidin-3-glucoside)",
        formula: "C21H21O11+",
        pubchemCid: 12303203,
        role: "Natural antioxidant pigments in purple taro stalks (কচু ডাঁটা).",
      },
    ],
    ethnobotanyBengali:
      "কচুর পাতা ও লতি অত্যন্ত পুষ্টিকর ও আয়রন সমৃদ্ধ। রান্নার সময় লেবুর রস বা অম্ল ব্যবহার করলে ক্যালসিয়াম অক্সালেটের তীব্রতা প্রশমিত হয়।",
    medicinalUses: "Rich in iron, potassium, dietary fiber, vitamin A and C.",
    uniprotProteinExample: "P04637 (Referenced defense lectin homologues)",
    soilRequirements: "Moist alluvial soil (দোআঁশ মাটি), high organic matter, pH 5.5 - 6.5.",
  },
  {
    id: "paddy",
    bengaliName: "ধান (আমন ও বোরো ধান)",
    scientificName: "Oryza sativa",
    family: "Poaceae",
    order: "Poales",
    growthDurationDays: 3,
    biochemicalCompounds: [
      {
        name: "Amylopectin",
        formula: "(C6H10O5)n",
        pubchemCid: 439207,
        role: "Branched polysaccharide responsible for rice grain texture and starch gelatinization.",
      },
      {
        name: "Ferulic Acid",
        formula: "C10H10O4",
        pubchemCid: 445858,
        role: "Potent phenolic antioxidant concentrated in rice bran.",
      },
    ],
    ethnobotanyBengali: "বাঙালির প্রধান খাদ্যশস্য। ধানের তুষ ও চাল থেকে তৈরি পণ্য গ্রামীণ জীবনের কেন্দ্রবিন্দু।",
    medicinalUses: "High caloric energy, vitamin B-complex (thiamine) in parboiled grains.",
    soilRequirements: "Clay loam with good water retention capacity.",
  },
  {
    id: "eggplant",
    bengaliName: "বেগুন (গোল বেগুন)",
    scientificName: "Solanum melongena",
    family: "Solanaceae",
    growthDurationDays: 3,
    biochemicalCompounds: [
      {
        name: "Nasunin",
        formula: "C36H37O19+",
        pubchemCid: 11953835,
        role: "Potent lipid peroxidation inhibitor found in deep purple peel.",
      },
      {
        name: "Chlorogenic Acid",
        formula: "C16H18O9",
        pubchemCid: 1794427,
        role: "Anti-hyperglycemic and free-radical scavenging polyphenol.",
      },
    ],
    ethnobotanyBengali: "গ্রামীণ সবজি চাষে ঐতিহ্যবাহী ফসল; রোগ প্রতিরোধী দেশি জাত।",
    medicinalUses: "Cardioprotective and beneficial for lipid metabolism.",
    soilRequirements: "Well-drained sandy loam with warm sunlight.",
  },
  {
    id: "mango_tree",
    bengaliName: "আমগাছ (কাঠ ও ফল গাছ)",
    scientificName: "Mangifera indica",
    family: "Anacardiaceae",
    growthDurationDays: 5,
    biochemicalCompounds: [
      {
        name: "Mangiferin",
        formula: "C19H18O11",
        pubchemCid: 5281647,
        role: "Natural C-glucosylxanthone with immunomodulatory and antimicrobial activity.",
      },
      {
        name: "Lignin Matrix",
        formula: "Complex biopolymer",
        pubchemCid: 5360545,
        role: "Structural rigidity of wood xylem fibers, allowing regenerative tree growth.",
      },
    ],
    ethnobotanyBengali: "কাঠ সংগ্রহ ও ছায়া প্রদানকারী বৃক্ষ। কাটার পর শিকড় থেকে দ্রুত নতুন ডালপালা গজায়।",
    medicinalUses: "Bark tannins used in traditional astringent preparations.",
    soilRequirements: "Deep alluvial loam, moderately drought tolerant.",
  },
  {
    id: "black_dog",
    bengaliName: "কালো কুকুর (কালু)",
    scientificName: "Canis lupus familiaris",
    family: "Canidae",
    order: "Carnivora",
    behavioralNeuroscience: [
      {
        stimulus: "Raised Wooden Stick or Sudden Advance",
        response: "Sympathetic nervous system arousal (fight-or-flight), elevated adrenaline/cortisol.",
        mechanic: "The dog perceives Tojo's stick as an intimidating dominant tool and immediately retreats/flees.",
      },
      {
        stimulus: "Calm Distance / Offering Food Treat",
        response: "Dopaminergic reward pathway, reduction in amygdala panic, gradual habituation.",
      },
    ],
    ethnobotanyBengali: "গ্রামের পাহারা দেওয়া লাজুক ও ভীতু দেশি কুকুর। লাঠি দেখলে নিরাপদ দূরত্বে ছুটে পালায়।",
  },
];

// Bioscience API
app.get("/api/science/plants", (_req, res) => {
  res.json({
    provenance: "Curated NCBI / PubChem / Ethnobotanical Reference Database",
    dataset: "Bioscience Flora & Fauna of Kochubon Remaster",
    species: SCIENTIFIC_SPECIES_DATA,
  });
});

// Gemini 3.1 Pro Thinking API for complex queries (Mustakim AI / Botanical Advisor)
app.post("/api/gemini/expert", async (req, res) => {
  const { prompt, context } = req.body;

  if (!prompt || typeof prompt !== "string") {
    res.status(400).json({ error: "Missing prompt" });
    return;
  }

  // System instruction for Deploper Mustakim & Botanical Scientist
  const systemInstruction = `You are "Deploper Mustakim" (ডেভেলপার মুস্তাকিম), the eccentric, brilliant Bengali tech wanderer, village botanist, and traveling shopkeeper of the game "কচুবন Remaster" (Kochubon Remaster). 
You arrive in the village every 2 days with rare seeds, tool blueprints, and deep biological & crafting wisdom. 
The main character is Tojo (তোজো), who lives in Kochubon (Taro forest), works with a stick for self-defense against the skittish black dog, chops trees that regrow, and farms crops.
When answering:
1. Provide thoughtful, sharp, and helpful answers blending authentic Bengali flavor ("আরে তোজো ভাই!", "কচুবনের রহস্য শোনো...") with rigorous scientific knowledge (botany, Colocasia esculenta biochemistry, agro-forestry, soil science) and game advice (tool crafting, farming, calming the dog).
2. Answer in Bengali or bilingual Bengali-English as appropriate to the user's query.
3. Be witty, encouraging, and deeply knowledgeable.`;

  if (!ai) {
    // Graceful offline simulated response if GEMINI_API_KEY is not set
    const fallbackAnswer = `আরে তোজো ভাই! আমি ডেভেলপার মুস্তাকিম (Deploper Mustakim)! 
কচুবন রিমাস্টারে তোমাকে স্বাগতম! 

তোমার জন্য দরকারি উপদেশ:
১. **কালো কুকুর (কালু)**: কুকুরটি তোমাকে ভয় পায়। হাতে লাঠি (Stick) রাখলে সে কখনোই তোমার কাছে আসবে না, ভয়ে দূরে পালাবে! তবে চাইলে পরে শান্ত করার খাবার দিয়ে বন্ধুও বানাতে পারবে।
২. **গাছ কাটা ও পুনর্জন্ম**: কুঠার (Axe) দিয়ে কাঠ কাটো। কচুবনের প্রাকৃতিক ইকোলজিতে গাছ নিজে নিজেই পুনরায় অঙ্কুরিত হয়ে বড় হবে।
৩. **চাষাবাদ (Farming)**: মাটি কুপিয়ে কচু ও ধানের বীজ লাগাও, পানি দাও। কচু (Colocasia esculenta)-তে প্রচুর ক্যালসিয়াম ও আয়রন আছে!
৪. **টুলস আপগ্রেড**: ক্রাফটিং মেনুতে গিয়ে বাঁশের লাঠি ও উন্নত কুঠার তৈরি করো।

আমি প্রতি ২ দিন পর পর নতুন মালামাল নিয়ে আসি! চালিয়ে যাও!`;
    res.json({
      reply: fallbackAnswer,
      thinkingUsed: false,
      isSimulated: true,
    });
    return;
  }

  try {
    // As explicitly instructed in Feature Block:
    // Model MUST be 'gemini-3.1-pro-preview'
    // thinkingLevel MUST be set to ThinkingLevel.HIGH
    // Do NOT set maxOutputTokens
    const response = await ai.models.generateContent({
      model: "gemini-3.1-pro-preview",
      contents: context
        ? `[Current Game State: ${JSON.stringify(context)}]\n\nPlayer Tojo asks: ${prompt}`
        : prompt,
      config: {
        systemInstruction,
        thinkingConfig: {
          thinkingLevel: ThinkingLevel.HIGH,
        },
      },
    });

    res.json({
      reply: response.text || "মুস্তাকিম ভাবছে... কোনো উত্তর এলো না!",
      thinkingUsed: true,
    });
  } catch (error: any) {
    console.error("Gemini 3.1 Pro execution error:", error);
    res.status(500).json({
      error: error.message || "Failed to generate response",
      fallbackReply: `আরে ভাই তোজো! নেটওয়ার্কের তারে কচু লতি আটকে গেছে! কিন্তু মনে রেখো: কুঠার দিয়ে কাঠ কাটো, লাঠি দিয়ে কালো কুকুরকে ভয় দেখাও, আর কচু ক্ষেতের পরিচর্যা করো!`,
    });
  }
});

// Setup Vite dev server or static files
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.resolve(distPath, "index.html"));
    });
  }

  app.listen(port, "0.0.0.0", () => {
    console.log(`[Kochubon Remaster Server] running on http://0.0.0.0:${port}`);
  });
}

startServer().catch((err) => {
  console.error("Failed to start server:", err);
  process.exit(1);
});
