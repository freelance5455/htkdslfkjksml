import express from 'express';
import { createServer as createViteServer } from 'vite';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import type {
  AppState,
  Player,
  Category,
  DailyRecord,
  Attempt,
  Season,
  Trick,
  AuditLog,
} from './src/types/index.ts';
import {
  getSaoPauloDateString,
  getSaoPauloWeekRange,
  calculateDailyBest,
  calculateWeeklyRanking,
} from './src/utils/garrafoesLogic.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const DATA_DIR = path.join(__dirname, 'data');
const DB_FILE = path.join(DATA_DIR, 'garrafoes_db.json');

// Ensure data directory exists
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

function getInitialState(): AppState {
  const currentWeek = getSaoPauloWeekRange();

  const players: Player[] = [
    {
      id: 'p-v',
      name: 'V',
      avatarUrl: '',
      color: '#10b981', // emerald
      role: 'admin',
      pin: '2026',
      createdAt: '2026-10-01T00:00:00.000Z',
    },
    {
      id: 'p-maxwell',
      name: 'Maxwell',
      avatarUrl: '',
      color: '#3b82f6', // blue
      role: 'player',
      pin: '1234',
      createdAt: '2026-10-01T00:00:00.000Z',
    },
    {
      id: 'p-nycollas',
      name: 'Nycollas',
      avatarUrl: '',
      color: '#f59e0b', // amber
      role: 'player',
      pin: '1234',
      createdAt: '2026-10-01T00:00:00.000Z',
    },
    {
      id: 'p-pedro',
      name: 'Pedro',
      avatarUrl: '',
      color: '#ec4899', // pink
      role: 'player',
      pin: '1234',
      createdAt: '2026-10-01T00:00:00.000Z',
    },
    {
      id: 'p-aguinaldo',
      name: 'Aguinaldo',
      avatarUrl: '',
      color: '#8b5cf6', // purple
      role: 'player',
      pin: '1234',
      createdAt: '2026-10-01T00:00:00.000Z',
    },
    {
      id: 'p-matheus',
      name: 'Matheus',
      avatarUrl: '',
      color: '#06b6d4', // cyan
      role: 'player',
      pin: '1234',
      createdAt: '2026-10-01T00:00:00.000Z',
    },
  ];

  const categories: Category[] = [
    {
      id: 'cat-200g',
      name: '200 g (Padrão Ágil)',
      weightGrams: 200,
      status: 'active',
      createdBy: 'p-v',
      approvedBy: 'p-v',
      isOfficialSafe: true,
      safetyNotice: 'Categoria oficial avaliada e aprovada como segura.',
    },
    {
      id: 'cat-500g',
      name: '500 g (Média Regular)',
      weightGrams: 500,
      status: 'active',
      createdBy: 'p-v',
      approvedBy: 'p-v',
      isOfficialSafe: true,
      safetyNotice: 'Categoria oficial avaliada e aprovada como segura.',
    },
    {
      id: 'cat-1kg',
      name: '1 kg (Pesada - Arquivada)',
      weightGrams: 1000,
      status: 'archived',
      createdBy: 'p-v',
      isOfficialSafe: false,
      safetyNotice:
        'Proteção de segurança: limite de peso competitivo excedido. Desativada para evitar riscos de lesões ou danos a superfícies.',
    },
    {
      id: 'cat-2kg',
      name: '2 kg (Extrema - Arquivada)',
      weightGrams: 2000,
      status: 'archived',
      createdBy: 'p-v',
      isOfficialSafe: false,
      safetyNotice:
        'Proteção de segurança: peso não permitido em disputas ativas. Mantida arquivada apenas para registro histórico.',
    },
  ];

  // Past closed season 1 (12/10 a 18/10/2026)
  const pastSeason: Season = {
    id: 'season-2026-10-12',
    name: 'Semana 12/10 a 18/10',
    startDate: '2026-10-12',
    endDate: '2026-10-18',
    status: 'closed',
    closedAt: '2026-10-18T23:59:59.000Z',
    timezone: 'America/Sao_Paulo',
    snapshots: {
      'cat-200g': [
        {
          seasonId: 'season-2026-10-12',
          categoryId: 'cat-200g',
          playerId: 'p-nycollas',
          sumStreaks: 25,
          daysTrained: 3,
          rawAverage: 8.333333333333334,
          formattedAverage: '8,33',
          maxStreak: 11,
          rank: 1,
          isChampion: true,
        },
        {
          seasonId: 'season-2026-10-12',
          categoryId: 'cat-200g',
          playerId: 'p-v',
          sumStreaks: 24,
          daysTrained: 3,
          rawAverage: 8.0,
          formattedAverage: '8,00',
          maxStreak: 9,
          rank: 2,
          isChampion: false,
        },
        {
          seasonId: 'season-2026-10-12',
          categoryId: 'cat-200g',
          playerId: 'p-maxwell',
          sumStreaks: 15,
          daysTrained: 2,
          rawAverage: 7.5,
          formattedAverage: '7,50',
          maxStreak: 8,
          rank: 3,
          isChampion: false,
        },
        {
          seasonId: 'season-2026-10-12',
          categoryId: 'cat-200g',
          playerId: 'p-pedro',
          sumStreaks: 12,
          daysTrained: 2,
          rawAverage: 6.0,
          formattedAverage: '6,00',
          maxStreak: 7,
          rank: 4,
          isChampion: false,
        },
      ],
      'cat-500g': [
        {
          seasonId: 'season-2026-10-12',
          categoryId: 'cat-500g',
          playerId: 'p-v',
          sumStreaks: 14,
          daysTrained: 2,
          rawAverage: 7.0,
          formattedAverage: '7,00',
          maxStreak: 8,
          rank: 1,
          isChampion: true,
        },
        {
          seasonId: 'season-2026-10-12',
          categoryId: 'cat-500g',
          playerId: 'p-maxwell',
          sumStreaks: 10,
          daysTrained: 2,
          rawAverage: 5.0,
          formattedAverage: '5,00',
          maxStreak: 6,
          rank: 2,
          isChampion: false,
        },
      ],
    },
  };

  // Current active season
  const currentSeason: Season = {
    id: currentWeek.seasonId,
    name: currentWeek.seasonLabel,
    startDate: currentWeek.startDate,
    endDate: currentWeek.endDate,
    status: 'active',
    timezone: 'America/Sao_Paulo',
  };

  // Pre-seed some demonstrative records matching Acceptance Criterion 3:
  // "Segunda-feira: 10 acertos. Quarta-feira: 7 acertos. Sexta-feira: 6 acertos. Total: 23, Média semanal: 7,67, 3 dias registrados."
  const mondayDate = currentWeek.startDate; // e.g. 2026-10-19
  const [y, m, d] = mondayDate.split('-').map(Number);
  const mon = new Date(Date.UTC(y, m - 1, d));
  const wed = new Date(mon);
  wed.setUTCDate(mon.getUTCDate() + 2);
  const wedDate = wed.toISOString().slice(0, 10);
  const fri = new Date(mon);
  fri.setUTCDate(mon.getUTCDate() + 4);
  const friDate = fri.toISOString().slice(0, 10);

  const dailyRecords: DailyRecord[] = [
    {
      id: `p-nycollas_cat-200g_${mondayDate}`,
      playerId: 'p-nycollas',
      categoryId: 'cat-200g',
      localDate: mondayDate,
      bestStreak: 10,
      trained: true,
      attemptsCount: 2,
      updatedAt: '2026-10-19T14:30:00.000Z',
    },
    {
      id: `p-nycollas_cat-200g_${wedDate}`,
      playerId: 'p-nycollas',
      categoryId: 'cat-200g',
      localDate: wedDate,
      bestStreak: 7,
      trained: true,
      attemptsCount: 3,
      updatedAt: '2026-10-21T18:15:00.000Z',
    },
    {
      id: `p-nycollas_cat-200g_${friDate}`,
      playerId: 'p-nycollas',
      categoryId: 'cat-200g',
      localDate: friDate,
      bestStreak: 6,
      trained: true,
      attemptsCount: 1,
      updatedAt: '2026-10-23T19:00:00.000Z',
    },
    // Maxwell records
    {
      id: `p-maxwell_cat-200g_${mondayDate}`,
      playerId: 'p-maxwell',
      categoryId: 'cat-200g',
      localDate: mondayDate,
      bestStreak: 9,
      trained: true,
      attemptsCount: 2,
      updatedAt: '2026-10-19T15:00:00.000Z',
    },
    {
      id: `p-maxwell_cat-200g_${wedDate}`,
      playerId: 'p-maxwell',
      categoryId: 'cat-200g',
      localDate: wedDate,
      bestStreak: 8,
      trained: true,
      attemptsCount: 2,
      updatedAt: '2026-10-21T17:00:00.000Z',
    },
    // V records in 500g
    {
      id: `p-v_cat-500g_${mondayDate}`,
      playerId: 'p-v',
      categoryId: 'cat-500g',
      localDate: mondayDate,
      bestStreak: 5,
      trained: true,
      attemptsCount: 2,
      updatedAt: '2026-10-19T16:00:00.000Z',
    },
  ];

  const tricks: Trick[] = [
    {
      id: 'trick-flip-simples',
      name: 'Flip 360 Clássico',
      description: 'Giro completo de 360 graus com aterrissagem estável na base.',
      authorId: 'p-v',
      categoryId: 'cat-200g',
      difficulty: 'facil',
      status: 'published',
      createdAt: '2026-10-05T10:00:00.000Z',
      publishedAt: '2026-10-05T12:00:00.000Z',
      executionsByPlayer: {
        'p-v': 14,
        'p-nycollas': 8,
        'p-maxwell': 11,
        'p-pedro': 5,
      },
    },
    {
      id: 'trick-tampa-cap',
      name: 'Pouso na Tampa (Cap Landing)',
      description: 'Lançamento com rotação controlada para aterrissar invertido sobre a tampa.',
      authorId: 'p-nycollas',
      categoryId: 'cat-200g',
      difficulty: 'lendario',
      status: 'published',
      createdAt: '2026-10-08T15:00:00.000Z',
      publishedAt: '2026-10-10T16:30:00.000Z',
      executionsByPlayer: {
        'p-nycollas': 6,
        'p-v': 2,
        'p-aguinaldo': 1,
      },
    },
    {
      id: 'trick-rascunho-pedro',
      name: 'Salto sob Mesa',
      description: 'Arremesso da garrafa passando por baixo de uma superfície antes de fixar.',
      authorId: 'p-pedro',
      categoryId: 'cat-200g',
      difficulty: 'dificil',
      status: 'draft',
      createdAt: '2026-10-19T11:00:00.000Z',
      executionsByPlayer: {
        'p-pedro': 4, // 4 executions: 1 needed to reach 5 and unlock publishing!
      },
    },
  ];

  const auditLogs: AuditLog[] = [
    {
      id: 'log-seed-1',
      userId: 'p-v',
      userName: 'V',
      recordTarget: 'Inicialização do Sistema',
      previousValue: '-',
      newValue: 'Temporada e categorias seguras ativadas',
      reason: 'Setup oficial do grupo Garrafões',
      timestamp: '2026-10-12T00:00:00.000Z',
    },
  ];

  return {
    players,
    categories,
    dailyRecords,
    attempts: [],
    seasons: [pastSeason, currentSeason],
    currentSeasonId: currentSeason.id,
    tricks,
    auditLogs,
  };
}

let appState: AppState = (() => {
  try {
    if (fs.existsSync(DB_FILE)) {
      const raw = fs.readFileSync(DB_FILE, 'utf-8');
      return JSON.parse(raw);
    }
  } catch (err) {
    console.error('Error reading garrafoes_db.json, falling back to initial state:', err);
  }
  const initial = getInitialState();
  saveDb(initial);
  return initial;
})();

function saveDb(state: AppState) {
  try {
    const tmp = `${DB_FILE}.tmp`;
    fs.writeFileSync(tmp, JSON.stringify(state, null, 2), 'utf-8');
    fs.renameSync(tmp, DB_FILE);
  } catch (err) {
    console.error('Failed to persist database:', err);
  }
}

async function startServer() {
  const app = express();
  const PORT = Number(process.env.PORT) || 3000;

  app.use(express.json({ limit: '10mb' }));

  // API Routes
  // 1. Get entire app state
  app.get('/api/state', (_req, res) => {
    // Check if season needs rollover
    const currentWeek = getSaoPauloWeekRange();
    let currentSeason = appState.seasons.find((s) => s.id === currentWeek.seasonId);
    if (!currentSeason) {
      currentSeason = {
        id: currentWeek.seasonId,
        name: currentWeek.seasonLabel,
        startDate: currentWeek.startDate,
        endDate: currentWeek.endDate,
        status: 'active',
        timezone: 'America/Sao_Paulo',
      };
      appState.seasons.push(currentSeason);
      appState.currentSeasonId = currentSeason.id;
      saveDb(appState);
    }

    res.json({
      success: true,
      state: appState,
      serverTimeSaoPaulo: getSaoPauloDateString(),
    });
  });

  // 2. Submit an attempt & update daily best
  app.post('/api/attempts', (req, res) => {
    const { playerId, categoryId, count, localDate: reqLocalDate } = req.body;

    if (!playerId || !categoryId || typeof count !== 'number') {
      res.status(400).json({ error: 'Parâmetros inválidos: playerId, categoryId e count são obrigatórios.' });
      return;
    }

    const category = appState.categories.find((c) => c.id === categoryId);
    if (!category) {
      res.status(404).json({ error: 'Categoria não encontrada.' });
      return;
    }

    if (category.status !== 'active') {
      res.status(400).json({
        error: 'Categoria desativada ou arquivada. Não é permitido registrar novas tentativas competitivas nesta categoria.',
      });
      return;
    }

    const localDate = reqLocalDate || getSaoPauloDateString();
    const attemptId = `att-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
    const newAttempt: Attempt = {
      id: attemptId,
      playerId,
      categoryId,
      localDate,
      count,
      timestamp: new Date().toISOString(),
    };
    appState.attempts.push(newAttempt);

    // Find or create daily record
    const recordId = `${playerId}_${categoryId}_${localDate}`;
    let daily = appState.dailyRecords.find((r) => r.id === recordId);

    const prevBest = daily ? daily.bestStreak : 0;
    const newBest = daily ? Math.max(daily.bestStreak, count) : count;

    if (!daily) {
      daily = {
        id: recordId,
        playerId,
        categoryId,
        localDate,
        bestStreak: newBest,
        trained: true,
        attemptsCount: 1,
        updatedAt: new Date().toISOString(),
      };
      appState.dailyRecords.push(daily);
    } else {
      daily.bestStreak = newBest;
      daily.trained = true;
      daily.attemptsCount = (daily.attemptsCount || 0) + 1;
      daily.updatedAt = new Date().toISOString();
    }

    saveDb(appState);

    res.json({
      success: true,
      dailyRecord: daily,
      attempt: newAttempt,
      improved: newBest > prevBest,
    });
  });

  // 3. Manual / Audited record correction
  app.post('/api/records/correct', (req, res) => {
    const { playerId, categoryId, localDate, newBestStreak, trained, reason, editorId } = req.body;

    if (!playerId || !categoryId || !localDate || typeof newBestStreak !== 'number' || !reason || !editorId) {
      res.status(400).json({ error: 'Campos obrigatórios ausentes para correção auditada.' });
      return;
    }

    const editor = appState.players.find((p) => p.id === editorId);
    if (!editor) {
      res.status(403).json({ error: 'Editor não identificado no grupo.' });
      return;
    }

    // Permission check: only player themselves or admin can correct
    if (editor.id !== playerId && editor.role !== 'admin') {
      res.status(403).json({ error: 'Permissão negada. Apenas o próprio jogador ou um administrador pode alterar este registro.' });
      return;
    }

    const recordId = `${playerId}_${categoryId}_${localDate}`;
    let daily = appState.dailyRecords.find((r) => r.id === recordId);
    const prevVal = daily ? `${daily.bestStreak} acertos (treinou: ${daily.trained})` : 'Sem registro';

    const isTrained = trained !== undefined ? Boolean(trained) : true;

    if (!daily) {
      daily = {
        id: recordId,
        playerId,
        categoryId,
        localDate,
        bestStreak: newBestStreak,
        trained: isTrained,
        attemptsCount: 1,
        updatedAt: new Date().toISOString(),
      };
      appState.dailyRecords.push(daily);
    } else {
      daily.bestStreak = newBestStreak;
      daily.trained = isTrained;
      daily.updatedAt = new Date().toISOString();
    }

    const newVal = `${newBestStreak} acertos (treinou: ${isTrained})`;

    // Log audit entry
    const auditLog: AuditLog = {
      id: `audit-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      userId: editor.id,
      userName: editor.name,
      recordTarget: `${daily.localDate} - Cat ${categoryId} - Jogador ${playerId}`,
      previousValue: prevVal,
      newValue: newVal,
      reason,
      timestamp: new Date().toISOString(),
    };
    appState.auditLogs.unshift(auditLog);

    saveDb(appState);

    res.json({
      success: true,
      dailyRecord: daily,
      auditLog,
    });
  });

  // 4. Categories management (with strict safety constraint <= 500g for active)
  app.post('/api/categories', (req, res) => {
    const { name, weightGrams, createdBy, safetyNotice } = req.body;
    if (!name || !weightGrams || !createdBy) {
      res.status(400).json({ error: 'Nome, peso e autor são obrigatórios.' });
      return;
    }

    // Duplicate check
    const duplicate = appState.categories.find(
      (c) =>
        c.weightGrams === Number(weightGrams) ||
        c.name.trim().toLowerCase() === name.trim().toLowerCase()
    );
    if (duplicate) {
      res.status(400).json({
        error: `Já existe uma categoria cadastrada com o peso ${weightGrams}g ou nome "${duplicate.name}".`,
      });
      return;
    }

    const isSafe = Number(weightGrams) <= 500;
    const catId = `cat-${weightGrams}g-${Date.now().toString(36)}`;
    const newCat: Category = {
      id: catId,
      name: name.trim(),
      weightGrams: Number(weightGrams),
      status: isSafe ? 'active' : 'archived',
      createdBy,
      approvedBy: isSafe ? createdBy : undefined,
      isOfficialSafe: isSafe,
      safetyNotice:
        safetyNotice ||
        (isSafe
          ? 'Categoria aprovada pelo grupo para competições ativas.'
          : 'Proteção de segurança: pesos acima de 500g são mantidos arquivados para evitar lesões.'),
    };

    appState.categories.push(newCat);
    saveDb(appState);
    res.json({ success: true, category: newCat });
  });

  // Toggle category active/archived
  app.patch('/api/categories/:id', (req, res) => {
    const { id } = req.params;
    const { status, adminId } = req.body;

    const cat = appState.categories.find((c) => c.id === id);
    if (!cat) {
      res.status(404).json({ error: 'Categoria não encontrada.' });
      return;
    }

    if (status === 'active' && cat.weightGrams > 500) {
      res.status(400).json({
        error: 'Segurança obrigatória: categorias com peso superior a 500g não podem ser ativadas para competição.',
      });
      return;
    }

    cat.status = status;
    if (status === 'active' && adminId) {
      cat.approvedBy = adminId;
    }
    saveDb(appState);
    res.json({ success: true, category: cat });
  });

  // 5. Tricks catalog
  app.post('/api/tricks', (req, res) => {
    const { name, description, authorId, categoryId, difficulty } = req.body;
    if (!name || !description || !authorId) {
      res.status(400).json({ error: 'Nome, descrição e autor são obrigatórios.' });
      return;
    }

    // Similar name check
    const existing = appState.tricks.find(
      (t) => t.name.trim().toLowerCase() === name.trim().toLowerCase()
    );
    if (existing) {
      res.status(400).json({
        error: `Já existe uma manobra com este nome: "${existing.name}". Verifique os detalhes no catálogo.`,
      });
      return;
    }

    const trickId = `trick-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
    const newTrick: Trick = {
      id: trickId,
      name: name.trim(),
      description: description.trim(),
      authorId,
      categoryId,
      difficulty: difficulty || 'medio',
      status: 'draft', // Must start as draft until 5 author validations
      createdAt: new Date().toISOString(),
      executionsByPlayer: {
        [authorId]: 0,
      },
    };

    appState.tricks.unshift(newTrick);
    saveDb(appState);
    res.json({ success: true, trick: newTrick });
  });

  // Log execution for a trick
  app.post('/api/tricks/:id/execute', (req, res) => {
    const { id } = req.params;
    const { playerId } = req.body;

    const trick = appState.tricks.find((t) => t.id === id);
    if (!trick) {
      res.status(404).json({ error: 'Manobra não encontrada.' });
      return;
    }

    if (!trick.executionsByPlayer) {
      trick.executionsByPlayer = {};
    }
    trick.executionsByPlayer[playerId] = (trick.executionsByPlayer[playerId] || 0) + 1;

    saveDb(appState);
    res.json({ success: true, trick, count: trick.executionsByPlayer[playerId] });
  });

  // Publish trick: author needs >= 5 executions
  app.post('/api/tricks/:id/publish', (req, res) => {
    const { id } = req.params;
    const { authorId } = req.body;

    const trick = appState.tricks.find((t) => t.id === id);
    if (!trick) {
      res.status(404).json({ error: 'Manobra não encontrada.' });
      return;
    }

    if (trick.authorId !== authorId) {
      res.status(403).json({ error: 'Apenas o autor pode publicar esta manobra.' });
      return;
    }

    const authorExecs = trick.executionsByPlayer[authorId] || 0;
    if (authorExecs < 5) {
      res.status(400).json({
        error: `Bloqueado para publicação: você tem ${authorExecs} de 5 acertos necessários. Registre mais ${
          5 - authorExecs
        } execuções bem-sucedidas.`,
      });
      return;
    }

    trick.status = 'published';
    trick.publishedAt = new Date().toISOString();
    saveDb(appState);

    res.json({ success: true, trick });
  });

  // Moderate / archive trick (admin)
  app.patch('/api/tricks/:id/status', (req, res) => {
    const { id } = req.params;
    const { status, adminId, reason } = req.body;

    const trick = appState.tricks.find((t) => t.id === id);
    if (!trick) {
      res.status(404).json({ error: 'Manobra não encontrada.' });
      return;
    }

    const prev = trick.status;
    trick.status = status;

    if (reason && adminId) {
      const admin = appState.players.find((p) => p.id === adminId);
      appState.auditLogs.unshift({
        id: `audit-${Date.now()}`,
        userId: adminId,
        userName: admin ? admin.name : 'Administrador',
        recordTarget: `Moderação Manobra "${trick.name}"`,
        previousValue: `Status: ${prev}`,
        newValue: `Status: ${status}`,
        reason: reason || 'Moderação de conteúdo',
        timestamp: new Date().toISOString(),
      });
    }

    saveDb(appState);
    res.json({ success: true, trick });
  });

  // 6. Close current season & snapshot results
  app.post('/api/seasons/close', (req, res) => {
    const { adminId, reason } = req.body;
    const currentSeason = appState.seasons.find((s) => s.id === appState.currentSeasonId);
    if (!currentSeason || currentSeason.status === 'closed') {
      res.status(400).json({ error: 'Não há temporada ativa para encerramento.' });
      return;
    }

    // Generate snapshots for all active categories
    const activeCats = appState.categories.filter((c) => c.status === 'active');
    const snapshots: Record<string, any[]> = {};

    for (const cat of activeCats) {
      const playersInput = appState.players.map((p) => {
        const records = appState.dailyRecords.filter(
          (r) =>
            r.playerId === p.id &&
            r.categoryId === cat.id &&
            r.localDate >= currentSeason.startDate &&
            r.localDate <= currentSeason.endDate
        );
        return {
          playerId: p.id,
          records,
        };
      });

      const ranking = calculateWeeklyRanking(currentSeason.id, cat.id, playersInput);
      snapshots[cat.id] = ranking;
    }

    currentSeason.status = 'closed';
    currentSeason.closedAt = new Date().toISOString();
    currentSeason.snapshots = snapshots;

    // Create next season starting on the following Monday
    const [y, m, d] = currentSeason.endDate.split('-').map(Number);
    const nextMon = new Date(Date.UTC(y, m - 1, d + 1));
    const nextSun = new Date(Date.UTC(y, m - 1, d + 7));
    const nextStart = nextMon.toISOString().slice(0, 10);
    const nextEnd = nextSun.toISOString().slice(0, 10);

    const sDay = nextMon.getUTCDate().toString().padStart(2, '0');
    const sMonth = (nextMon.getUTCMonth() + 1).toString().padStart(2, '0');
    const eDay = nextSun.getUTCDate().toString().padStart(2, '0');
    const eMonth = (nextSun.getUTCMonth() + 1).toString().padStart(2, '0');

    const nextSeason: Season = {
      id: `season-${nextStart}`,
      name: `Semana ${sDay}/${sMonth} a ${eDay}/${eMonth}`,
      startDate: nextStart,
      endDate: nextEnd,
      status: 'active',
      timezone: 'America/Sao_Paulo',
    };

    appState.seasons.push(nextSeason);
    appState.currentSeasonId = nextSeason.id;

    if (adminId) {
      const admin = appState.players.find((p) => p.id === adminId);
      appState.auditLogs.unshift({
        id: `audit-season-${Date.now()}`,
        userId: adminId,
        userName: admin ? admin.name : 'Administrador',
        recordTarget: `Encerramento ${currentSeason.name}`,
        previousValue: 'Status: Ativa',
        newValue: `Fechada. Criada próxima temporada: ${nextSeason.name}`,
        reason: reason || 'Encerramento oficial da temporada semanal',
        timestamp: new Date().toISOString(),
      });
    }

    saveDb(appState);
    res.json({ success: true, closedSeason: currentSeason, nextSeason });
  });

  // 7. Update player profile (name, avatar, color)
  app.patch('/api/players/:id', (req, res) => {
    const { id } = req.params;
    const { name, avatarUrl, color } = req.body;

    const player = appState.players.find((p) => p.id === id);
    if (!player) {
      res.status(404).json({ error: 'Jogador não encontrado.' });
      return;
    }

    if (name && name.trim()) player.name = name.trim();
    if (avatarUrl !== undefined) player.avatarUrl = avatarUrl;
    if (color) player.color = color;

    saveDb(appState);
    res.json({ success: true, player });
  });

  // 8. Reset to demo data
  app.post('/api/backup/reset-demo', (_req, res) => {
    appState = getInitialState();
    saveDb(appState);
    res.json({ success: true, message: 'Dados restaurados para o padrão de demonstração com sucesso.' });
  });

  // 9. Full JSON export
  app.get('/api/backup/export', (_req, res) => {
    res.setHeader('Content-Type', 'application/json');
    res.setHeader('Content-Disposition', 'attachment; filename="garrafoes-backup.json"');
    res.send(JSON.stringify(appState, null, 2));
  });

  // Vite middleware in dev or static files in production
  const isProd = process.env.NODE_ENV === 'production';
  if (!isProd) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Garrafões server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Fatal server startup error:', err);
  process.exit(1);
});
