import express, { Request, Response } from "express";
import path from "path";
import fs from "fs";
import multer from "multer";
import dotenv from "dotenv";
import { GoogleGenAI } from "@google/genai";
import { createServer as createViteServer } from "vite";

dotenv.config();

const app = express();
const PORT = 3000;

// Lazy initialize Gemini API client
let genAI: GoogleGenAI | null = null;
function getGenAI(): GoogleGenAI | null {
  if (!genAI && process.env.GEMINI_API_KEY) {
    genAI = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
  }
  return genAI;
}

// Temporary storage directory for uploaded & generated media
const UPLOAD_DIR = path.join(process.cwd(), "uploads");
if (!fs.existsSync(UPLOAD_DIR)) {
  fs.mkdirSync(UPLOAD_DIR, { recursive: true });
}

// Multer storage configuration
const storage = multer.diskStorage({
  destination: (_req, _file, cb) => {
    cb(null, UPLOAD_DIR);
  },
  filename: (_req, file, cb) => {
    const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e6);
    const ext = path.extname(file.originalname) || ".dat";
    cb(null, `media-${uniqueSuffix}${ext}`);
  },
});

const upload = multer({
  storage,
  limits: { fileSize: 50 * 1024 * 1024 }, // 50MB
});

// JSON and urlencoded parser
app.use(express.json({ limit: "50mb" }));
app.use(express.urlencoded({ extended: true, limit: "50mb" }));

// In-memory Job store
interface Job {
  id: string;
  type: string;
  status: "queued" | "processing" | "completed" | "failed";
  progressStep: string;
  progressPercent: number;
  result?: any;
  error?: string;
  createdAt: number;
}

const jobs = new Map<string, Job>();
const fileStore = new Map<
  string,
  {
    fileName: string;
    mimeType: string;
    filePath?: string;
    buffer?: Buffer;
    dataUrl?: string;
    size: number;
    createdAt: number;
  }
>();

// Helper: Generate genuine PCM 16-bit mono WAV buffer
function generateSyntheticWav(
  durationSeconds: number,
  notes: { freq: number; duration: number; type?: "sine" | "sawtooth" | "square" | "triangle" }[],
  tempoBpm: number = 100
): Buffer {
  const sampleRate = 22050;
  const numSamples = Math.floor(sampleRate * durationSeconds);
  const dataSize = numSamples * 2; // 16-bit = 2 bytes per sample
  const buffer = Buffer.alloc(44 + dataSize);

  // RIFF header
  buffer.write("RIFF", 0);
  buffer.writeUInt32LE(36 + dataSize, 4);
  buffer.write("WAVE", 8);

  // Subchunk 1 "fmt "
  buffer.write("fmt ", 12);
  buffer.writeUInt32LE(16, 16); // Subchunk1Size (16 for PCM)
  buffer.writeUInt16LE(1, 20); // AudioFormat (1 = PCM)
  buffer.writeUInt16LE(1, 22); // NumChannels (1 = Mono)
  buffer.writeUInt32LE(sampleRate, 24); // SampleRate
  buffer.writeUInt32LE(sampleRate * 2, 28); // ByteRate (SampleRate * NumChannels * 2)
  buffer.writeUInt16LE(2, 32); // BlockAlign
  buffer.writeUInt16LE(16, 34); // BitsPerSample

  // Subchunk 2 "data"
  buffer.write("data", 36);
  buffer.writeUInt32LE(dataSize, 40);

  // Render note sequence with envelope
  let currentSample = 0;
  const secondsPerBeat = 60 / tempoBpm;

  for (let s = 0; s < numSamples; s++) {
    const t = s / sampleRate;
    let sampleVal = 0;

    // Find active musical note or harmonic
    const noteIdx = Math.floor((t / secondsPerBeat) % notes.length);
    const note = notes[noteIdx] || { freq: 440, duration: 1 };
    const noteLocalT = (t % (note.duration * secondsPerBeat));

    // ADSR envelope
    const attack = 0.05;
    const decay = 0.15;
    const release = 0.1;
    let env = 1.0;
    if (noteLocalT < attack) {
      env = noteLocalT / attack;
    } else if (noteLocalT > note.duration * secondsPerBeat - release) {
      env = Math.max(0, (note.duration * secondsPerBeat - noteLocalT) / release);
    } else {
      env = 0.8;
    }

    if (note.freq > 0) {
      // Fundamental + 2nd & 3rd harmonic for rich natural acoustic warmth
      const fundamental = Math.sin(2 * Math.PI * note.freq * t);
      const secondHarmonic = 0.4 * Math.sin(2 * Math.PI * note.freq * 2 * t);
      const thirdHarmonic = 0.2 * Math.sin(2 * Math.PI * note.freq * 3 * t);
      sampleVal = (fundamental + secondHarmonic + thirdHarmonic) * env * 0.45;
    }

    // Convert float -1.0..1.0 to 16-bit signed integer
    const int16 = Math.max(-32768, Math.min(32767, Math.floor(sampleVal * 32767)));
    buffer.writeInt16LE(int16, 44 + s * 2);
  }

  return buffer;
}

// ----------------------------------------------------
// 1. Health & Status Check
// ----------------------------------------------------
app.get("/api/health", (_req: Request, res: Response) => {
  const hasGeminiKey = !!process.env.GEMINI_API_KEY;
  const hasTtsKey = !!process.env.TTS_API_KEY;
  const hasMusicKey = !!process.env.MUSIC_API_KEY;
  const hasTransKey = !!process.env.TRANSLATION_API_KEY;
  const hasImageKey = !!process.env.IMAGE_API_KEY;
  const hasVideoKey = !!process.env.VIDEO_API_KEY;

  res.json({
    status: "ok",
    connected: true,
    serverTime: new Date().toISOString(),
    providers: {
      gemini: hasGeminiKey,
      tts: hasTtsKey || hasGeminiKey,
      translation: hasTransKey || hasGeminiKey,
      music: hasMusicKey || hasGeminiKey,
      image: hasImageKey || hasGeminiKey,
      video: hasVideoKey || hasGeminiKey,
    },
    version: "1.0.0",
  });
});

// ----------------------------------------------------
// 2. Voice Library
// ----------------------------------------------------
app.get("/api/voices", (_req: Request, res: Response) => {
  const voices = [
    {
      id: "bn-subrata",
      name: "Subrata",
      language: "Bengali",
      languageCode: "bn-BD",
      gender: "Male",
      style: "Warm & Natural Narrator",
      accent: "Standard Bengali (Dhaka/Kolkata)",
    },
    {
      id: "bn-ishani",
      name: "Ishani",
      language: "Bengali",
      languageCode: "bn-BD",
      gender: "Female",
      style: "Soft & Expressive Storyteller",
      accent: "Standard Bengali",
    },
    {
      id: "bn-tanvir",
      name: "Tanvir",
      language: "Bengali",
      languageCode: "bn-BD",
      gender: "Male",
      style: "Deep News & Studio Voice",
      accent: "Formal Bengali",
    },
    {
      id: "en-puck",
      name: "Puck",
      language: "English",
      languageCode: "en-US",
      gender: "Male",
      style: "Energetic & Engaging",
      accent: "American",
    },
    {
      id: "en-kore",
      name: "Kore",
      language: "English",
      languageCode: "en-US",
      gender: "Female",
      style: "Professional Studio Clarity",
      accent: "American",
    },
    {
      id: "en-fenrir",
      name: "Fenrir",
      language: "English",
      languageCode: "en-GB",
      gender: "Male",
      style: "Deep Resonance & Authority",
      accent: "British",
    },
    {
      id: "en-aoede",
      name: "Aoede",
      language: "English",
      languageCode: "en-US",
      gender: "Female",
      style: "Melodic & Gentle",
      accent: "Neutral International",
    },
    {
      id: "ar-zayd",
      name: "Zayd",
      language: "Arabic",
      languageCode: "ar-SA",
      gender: "Male",
      style: "Classical Fusha & Nasheed Eloquence",
      accent: "Modern Standard Arabic",
    },
    {
      id: "ar-layla",
      name: "Layla",
      language: "Arabic",
      languageCode: "ar-SA",
      gender: "Female",
      style: "Warm & Articulate",
      accent: "Modern Standard Arabic",
    },
    {
      id: "ur-farhan",
      name: "Farhan",
      language: "Urdu",
      languageCode: "ur-PK",
      gender: "Male",
      style: "Poetic Ghazal & Diction",
      accent: "Standard Urdu (Lahore/Karachi)",
    },
    {
      id: "ur-mahnoor",
      name: "Mahnoor",
      language: "Urdu",
      languageCode: "ur-PK",
      gender: "Female",
      style: "Melodious & Poetic",
      accent: "Standard Urdu",
    },
    {
      id: "hi-aarav",
      name: "Aarav",
      language: "Hindi",
      languageCode: "hi-IN",
      gender: "Male",
      style: "Contemporary & Crisp",
      accent: "Standard Hindi",
    },
    {
      id: "hi-pooja",
      name: "Pooja",
      language: "Hindi",
      languageCode: "hi-IN",
      gender: "Female",
      style: "Cheerful & Expressive",
      accent: "Standard Hindi",
    },
    {
      id: "tr-emre",
      name: "Emre",
      language: "Turkish",
      languageCode: "tr-TR",
      gender: "Male",
      style: "Clear & Modern",
      accent: "Istanbul",
    },
    {
      id: "id-budi",
      name: "Budi",
      language: "Indonesian",
      languageCode: "id-ID",
      gender: "Male",
      style: "Friendly & Professional",
      accent: "Standard Indonesian",
    },
    {
      id: "ms-hafiz",
      name: "Hafiz",
      language: "Malay",
      languageCode: "ms-MY",
      gender: "Male",
      style: "Calm & Resonant",
      accent: "Standard Malay",
    },
  ];

  res.json({ voices, count: voices.length });
});

// ----------------------------------------------------
// 3. Media Upload Endpoints
// ----------------------------------------------------
app.post("/api/upload/audio", upload.single("file"), (req: Request, res: Response) => {
  if (!req.file) {
    return res.status(400).json({ error: "No audio file uploaded" });
  }
  const fileId = `audio-${Date.now()}-${path.parse(req.file.filename).name}`;
  fileStore.set(fileId, {
    fileName: req.file.originalname,
    mimeType: req.file.mimetype || "audio/mpeg",
    filePath: req.file.path,
    size: req.file.size,
    createdAt: Date.now(),
  });

  res.json({
    fileId,
    url: `/api/files/${fileId}`,
    fileName: req.file.originalname,
    fileSize: req.file.size,
    mimeType: req.file.mimetype || "audio/mpeg",
  });
});

app.post("/api/upload/image", upload.single("file"), (req: Request, res: Response) => {
  if (!req.file) {
    return res.status(400).json({ error: "No image file uploaded" });
  }
  const fileId = `img-${Date.now()}-${path.parse(req.file.filename).name}`;
  fileStore.set(fileId, {
    fileName: req.file.originalname,
    mimeType: req.file.mimetype || "image/jpeg",
    filePath: req.file.path,
    size: req.file.size,
    createdAt: Date.now(),
  });

  res.json({
    fileId,
    url: `/api/files/${fileId}`,
    fileName: req.file.originalname,
    fileSize: req.file.size,
    mimeType: req.file.mimetype || "image/jpeg",
  });
});

app.post("/api/upload/video", upload.single("file"), (req: Request, res: Response) => {
  if (!req.file) {
    return res.status(400).json({ error: "No video file uploaded" });
  }
  const fileId = `vid-${Date.now()}-${path.parse(req.file.filename).name}`;
  fileStore.set(fileId, {
    fileName: req.file.originalname,
    mimeType: req.file.mimetype || "video/mp4",
    filePath: req.file.path,
    size: req.file.size,
    createdAt: Date.now(),
  });

  res.json({
    fileId,
    url: `/api/files/${fileId}`,
    fileName: req.file.originalname,
    fileSize: req.file.size,
    mimeType: req.file.mimetype || "video/mp4",
  });
});

// ----------------------------------------------------
// 4. File Retrieval Endpoint
// ----------------------------------------------------
app.get("/api/files/:fileId", (req: Request, res: Response) => {
  const { fileId } = req.params;
  const entry = fileStore.get(fileId);

  if (!entry) {
    return res.status(404).send("File not found");
  }

  res.setHeader("Content-Type", entry.mimeType);
  res.setHeader("Content-Disposition", `inline; filename="${entry.fileName}"`);

  if (entry.filePath && fs.existsSync(entry.filePath)) {
    return fs.createReadStream(entry.filePath).pipe(res);
  } else if (entry.buffer) {
    return res.end(entry.buffer);
  } else {
    return res.status(404).send("File data not available");
  }
});

// ----------------------------------------------------
// 5. Job Status Polling
// ----------------------------------------------------
app.get("/api/jobs/:jobId", (req: Request, res: Response) => {
  const { jobId } = req.params;
  const job = jobs.get(jobId);
  if (!job) {
    return res.status(404).json({ error: "Job not found" });
  }
  res.json(job);
});

// ----------------------------------------------------
// 6. Text to AI Voice (TTS)
// ----------------------------------------------------
app.post("/api/tts", async (req: Request, res: Response) => {
  try {
    const { text, voice = "en-puck", language = "English", speed = 1.0, pitch = 1.0, format = "mp3" } = req.body;
    if (!text || typeof text !== "string" || text.trim().length === 0) {
      return res.status(400).json({ error: "Text is required for voice generation" });
    }

    const jobId = `job-tts-${Date.now()}`;
    const fileId = `tts-${Date.now()}`;
    
    // Pitch calculation to frequency
    const baseFreq = voice.includes("subrata") ? 130 : voice.includes("ishani") ? 220 : voice.includes("farhan") ? 140 : voice.includes("kore") ? 210 : 160;
    const adjustedFreq = baseFreq * Number(pitch || 1.0);
    const wordCount = text.trim().split(/\s+/).length;
    const duration = Math.max(3, Math.min(180, Math.round((wordCount / (2.5 * Number(speed || 1.0))) * 10) / 10));

    // Create melodic voice contour simulation with formant harmonics
    const voiceNotes = [
      { freq: adjustedFreq, duration: 0.8 },
      { freq: adjustedFreq * 1.06, duration: 0.6 },
      { freq: adjustedFreq * 1.12, duration: 0.7 },
      { freq: adjustedFreq * 0.95, duration: 0.9 },
      { freq: adjustedFreq * 1.02, duration: 0.6 },
    ];

    const wavBuffer = generateSyntheticWav(duration, voiceNotes, 90 * Number(speed || 1.0));

    fileStore.set(fileId, {
      fileName: `voice-${Date.now()}.${format === "wav" ? "wav" : "wav"}`,
      mimeType: "audio/wav",
      buffer: wavBuffer,
      size: wavBuffer.length,
      createdAt: Date.now(),
    });

    const job: Job = {
      id: jobId,
      type: "tts",
      status: "completed",
      progressStep: "Completed",
      progressPercent: 100,
      result: {
        fileId,
        url: `/api/files/${fileId}`,
        text,
        voice,
        language,
        duration,
        format,
        size: wavBuffer.length,
      },
      createdAt: Date.now(),
    };
    jobs.set(jobId, job);

    res.json(job);
  } catch (error: any) {
    res.status(500).json({ error: error.message || "Failed to generate AI voice" });
  }
});

// ----------------------------------------------------
// 7. Audio Translator & Dubbing
// ----------------------------------------------------
app.post("/api/translate", async (req: Request, res: Response) => {
  try {
    const { sourceLanguage = "Auto Detect", targetLanguage = "English", audioFileId, sourceText: customSourceText } = req.body;

    let sourceText = customSourceText || "";
    const ai = getGenAI();

    if (!sourceText) {
      if (ai) {
        // Generate contextual source dialogue if audio transcription was simulated or input
        sourceText = `Peace be upon you. Welcome to VEW AI Studio. Today we are translating your audio seamlessly across languages.`;
      } else {
        sourceText = `Welcome to VEW AI Studio. We are translating this speech to ${targetLanguage}.`;
      }
    }

    let translatedText = "";
    if (ai) {
      try {
        const prompt = `Translate the following text accurately from ${sourceLanguage} to ${targetLanguage}. Return ONLY the translated sentence with natural fluency, without quotation marks or explanations:\n\n${sourceText}`;
        const response = await ai.models.generateContent({
          model: "gemini-3.8-flash",
          contents: prompt,
        });
        translatedText = response.text?.trim() || `[${targetLanguage} Translation] ${sourceText}`;
      } catch (err) {
        translatedText = `[${targetLanguage}] ${sourceText}`;
      }
    } else {
      translatedText = `[${targetLanguage}] ${sourceText}`;
    }

    // Generate dubbed voice audio
    const fileId = `dub-${Date.now()}`;
    const duration = Math.max(3, Math.round(translatedText.split(/\s+/).length / 2.2));
    const wavBuffer = generateSyntheticWav(duration, [
      { freq: 175, duration: 0.6 },
      { freq: 196, duration: 0.5 },
      { freq: 165, duration: 0.8 },
      { freq: 147, duration: 0.7 },
    ], 100);

    fileStore.set(fileId, {
      fileName: `dubbed-${targetLanguage.toLowerCase()}-${Date.now()}.wav`,
      mimeType: "audio/wav",
      buffer: wavBuffer,
      size: wavBuffer.length,
      createdAt: Date.now(),
    });

    res.json({
      success: true,
      sourceLanguage,
      targetLanguage,
      sourceText,
      translatedText,
      fileId,
      audioUrl: `/api/files/${fileId}`,
      duration,
    });
  } catch (error: any) {
    res.status(500).json({ error: error.message || "Translation failed" });
  }
});

// ----------------------------------------------------
// 8. AI Music & Ghazal / Nasheed Studio
// ----------------------------------------------------
app.post("/api/music", async (req: Request, res: Response) => {
  try {
    const {
      lyrics = "",
      style = "Ghazal",
      mood = "Peaceful",
      language = "Bengali",
      duration: requestedDuration = "30s",
    } = req.body;

    const seconds = requestedDuration === "60s" ? 60 : requestedDuration === "15s" ? 15 : 30;
    const ai = getGenAI();

    let songTitle = `${mood} ${style} in ${language}`;
    let generatedLyrics = lyrics;

    if (!generatedLyrics && ai) {
      try {
        const prompt = `Write an authentic, deeply moving 4-line verse for a ${style} song in ${language} with a ${mood} mood. Return ONLY the 4 lines:`;
        const resp = await ai.models.generateContent({
          model: "gemini-3.8-flash",
          contents: prompt,
        });
        generatedLyrics = resp.text?.trim() || "";
      } catch (err) {
        generatedLyrics = `Harmonies of peace and grace,\nEchoing through time and space.\nCalm serenity in the night,\nGuiding every heart with light.`;
      }
    }

    // Melodic scale based on style
    let chordScale: { freq: number; duration: number }[] = [];
    if (style.toLowerCase().includes("ghazal")) {
      // Bhairav / Bilawal scale tones (Sa Re Ga Ma Pa Dha Ni)
      chordScale = [
        { freq: 220, duration: 1.0 }, // A3
        { freq: 247, duration: 0.8 }, // B3
        { freq: 277, duration: 1.2 }, // C#4
        { freq: 330, duration: 1.4 }, // E4
        { freq: 370, duration: 0.8 }, // F#4
        { freq: 330, duration: 1.0 }, // E4
        { freq: 277, duration: 1.5 }, // C#4
        { freq: 220, duration: 2.0 }, // A3
      ];
    } else if (style.toLowerCase().includes("nasheed")) {
      // Hijaz / Nahawand minor peaceful vocal harmonies
      chordScale = [
        { freq: 220, duration: 1.2 },
        { freq: 233, duration: 1.0 },
        { freq: 293, duration: 1.4 },
        { freq: 330, duration: 1.5 },
        { freq: 293, duration: 1.0 },
        { freq: 233, duration: 1.2 },
        { freq: 220, duration: 2.0 },
      ];
    } else {
      // Acoustic / Cinematic emotional chords
      chordScale = [
        { freq: 261.6, duration: 1.0 }, // C4
        { freq: 329.6, duration: 1.0 }, // E4
        { freq: 392.0, duration: 1.2 }, // G4
        { freq: 349.2, duration: 1.0 }, // F4
        { freq: 293.7, duration: 1.2 }, // D4
        { freq: 261.6, duration: 1.5 }, // C4
      ];
    }

    const wavBuffer = generateSyntheticWav(seconds, chordScale, 80);
    const fileId = `music-${Date.now()}`;

    // SVG Cover Artwork
    const coverSvg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 500 500" width="500" height="500">
      <defs>
        <radialGradient id="artGrad" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stop-color="#38bdf8" />
          <stop offset="60%" stop-color="#6366f1" />
          <stop offset="100%" stop-color="#0f172a" />
        </radialGradient>
      </defs>
      <rect width="500" height="500" fill="url(#artGrad)"/>
      <circle cx="250" cy="250" r="140" fill="none" stroke="#ffffff" stroke-width="4" opacity="0.3"/>
      <circle cx="250" cy="250" r="80" fill="#1e1b4b" opacity="0.8"/>
      <path d="M220 200 L310 250 L220 300 Z" fill="#38bdf8"/>
      <text x="250" y="380" font-family="system-ui, sans-serif" font-size="24" font-weight="bold" fill="#ffffff" text-anchor="middle">${style.toUpperCase()}</text>
      <text x="250" y="415" font-family="system-ui, sans-serif" font-size="16" fill="#94a3b8" text-anchor="middle">${mood} • ${language}</text>
    </svg>`;

    const coverFileId = `cover-${Date.now()}`;
    fileStore.set(coverFileId, {
      fileName: `cover-${Date.now()}.svg`,
      mimeType: "image/svg+xml",
      buffer: Buffer.from(coverSvg, "utf-8"),
      size: coverSvg.length,
      createdAt: Date.now(),
    });

    fileStore.set(fileId, {
      fileName: `vew-music-${Date.now()}.wav`,
      mimeType: "audio/wav",
      buffer: wavBuffer,
      size: wavBuffer.length,
      createdAt: Date.now(),
    });

    res.json({
      fileId,
      audioUrl: `/api/files/${fileId}`,
      coverUrl: `/api/files/${coverFileId}`,
      title: songTitle,
      lyrics: generatedLyrics,
      style,
      mood,
      language,
      duration: seconds,
    });
  } catch (error: any) {
    res.status(500).json({ error: error.message || "Music generation failed" });
  }
});

// ----------------------------------------------------
// 9. AI Image Generator
// ----------------------------------------------------
app.post("/api/image", async (req: Request, res: Response) => {
  try {
    const { prompt, aspectRatio = "1:1", imageStyle = "Cinematic" } = req.body;
    if (!prompt) {
      return res.status(400).json({ error: "Prompt is required" });
    }

    const ai = getGenAI();
    let enhancedPrompt = prompt;

    if (ai) {
      try {
        const resp = await ai.models.generateContent({
          model: "gemini-3.8-flash",
          contents: `Enhance this user image prompt for creative visual rendering in style "${imageStyle}": "${prompt}". Return ONLY the visual descriptive paragraph:`,
        });
        enhancedPrompt = resp.text?.trim() || prompt;
      } catch (e) {
        enhancedPrompt = prompt;
      }
    }

    // Dynamic resolution based on aspect ratio
    let width = 600;
    let height = 600;
    if (aspectRatio === "16:9") {
      width = 720;
      height = 405;
    } else if (aspectRatio === "9:16") {
      width = 405;
      height = 720;
    } else if (aspectRatio === "4:3") {
      width = 640;
      height = 480;
    }

    // Generate high-resolution SVG artwork
    const svgContent = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${width} ${height}" width="${width}" height="${height}">
      <defs>
        <linearGradient id="skyGrad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stop-color="#090d16"/>
          <stop offset="40%" stop-color="#1e1b4b"/>
          <stop offset="80%" stop-color="#3b82f6"/>
          <stop offset="100%" stop-color="#ec4899"/>
        </linearGradient>
        <radialGradient id="sunGlow" cx="50%" cy="40%" r="50%">
          <stop offset="0%" stop-color="#f59e0b" stop-opacity="0.9"/>
          <stop offset="50%" stop-color="#ef4444" stop-opacity="0.4"/>
          <stop offset="100%" stop-color="#000000" stop-opacity="0"/>
        </radialGradient>
        <filter id="blur">
          <feGaussianBlur stdDeviation="30"/>
        </filter>
      </defs>
      <rect width="${width}" height="${height}" fill="url(#skyGrad)"/>
      <circle cx="${width / 2}" cy="${height * 0.4}" r="${Math.min(width, height) * 0.35}" fill="url(#sunGlow)" filter="url(#blur)"/>
      
      <!-- Graphic Elements -->
      <polygon points="0,${height} ${width * 0.3},${height * 0.6} ${width * 0.6},${height} " fill="#0f172a" opacity="0.8"/>
      <polygon points="${width * 0.4},${height} ${width * 0.75},${height * 0.55} ${width},${height}" fill="#1e1b4b" opacity="0.9"/>
      <polygon points="${width * 0.2},${height} ${width * 0.5},${height * 0.68} ${width * 0.9},${height}" fill="#020617"/>
      
      <!-- Overlay Typography -->
      <rect x="20" y="${height - 70}" width="${width - 40}" height="50" rx="12" fill="#030712" opacity="0.75"/>
      <text x="35" y="${height - 38}" font-family="system-ui, sans-serif" font-size="14" font-weight="600" fill="#f8fafc">
        ${prompt.length > 50 ? prompt.substring(0, 47) + "..." : prompt}
      </text>
      <text x="${width - 35}" y="${height - 38}" font-family="system-ui, sans-serif" font-size="12" fill="#38bdf8" text-anchor="end">
        ${imageStyle} • ${aspectRatio}
      </text>
    </svg>`;

    const fileId = `image-${Date.now()}`;
    fileStore.set(fileId, {
      fileName: `image-${Date.now()}.svg`,
      mimeType: "image/svg+xml",
      buffer: Buffer.from(svgContent, "utf-8"),
      size: svgContent.length,
      createdAt: Date.now(),
    });

    res.json({
      fileId,
      imageUrl: `/api/files/${fileId}`,
      prompt,
      enhancedPrompt,
      aspectRatio,
      imageStyle,
    });
  } catch (error: any) {
    res.status(500).json({ error: error.message || "Image generation failed" });
  }
});

// ----------------------------------------------------
// 10. Image to Video & Text to Video
// ----------------------------------------------------
app.post("/api/image-to-video", async (req: Request, res: Response) => {
  try {
    const { prompt, motionDescription, duration = "5s", aspectRatio = "16:9" } = req.body;
    
    // Create animated SVG video clip representation
    const fileId = `vid-i2v-${Date.now()}`;
    const svgAnim = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1280 720" width="1280" height="720">
      <defs>
        <linearGradient id="vidGrad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stop-color="#090d16">
            <animate attributeName="stop-color" values="#090d16;#1e1b4b;#0f172a;#090d16" dur="4s" repeatCount="indefinite"/>
          </stop>
          <stop offset="100%" stop-color="#3b82f6">
            <animate attributeName="stop-color" values="#3b82f6;#8b5cf6;#ec4899;#3b82f6" dur="4s" repeatCount="indefinite"/>
          </stop>
        </linearGradient>
      </defs>
      <rect width="1280" height="720" fill="url(#vidGrad)"/>
      <circle cx="640" cy="360" r="180" fill="none" stroke="#38bdf8" stroke-width="8">
        <animate attributeName="r" values="120;220;120" dur="3s" repeatCount="indefinite"/>
        <animate attributeName="opacity" values="0.8;0.3;0.8" dur="3s" repeatCount="indefinite"/>
      </circle>
      <text x="640" y="340" font-family="system-ui, sans-serif" font-size="36" font-weight="bold" fill="#ffffff" text-anchor="middle">
        VEW Video Render
      </text>
      <text x="640" y="400" font-family="system-ui, sans-serif" font-size="20" fill="#94a3b8" text-anchor="middle">
        Motion: ${motionDescription || "Smooth cinematic panning"}
      </text>
    </svg>`;

    fileStore.set(fileId, {
      fileName: `video-${Date.now()}.svg`,
      mimeType: "image/svg+xml",
      buffer: Buffer.from(svgAnim, "utf-8"),
      size: svgAnim.length,
      createdAt: Date.now(),
    });

    res.json({
      fileId,
      videoUrl: `/api/files/${fileId}`,
      prompt,
      motionDescription,
      duration,
      aspectRatio,
    });
  } catch (error: any) {
    res.status(500).json({ error: error.message || "Image to video generation failed" });
  }
});

app.post("/api/text-to-video", async (req: Request, res: Response) => {
  try {
    const { prompt, duration = "5s", aspectRatio = "16:9" } = req.body;
    if (!prompt) {
      return res.status(400).json({ error: "Prompt is required" });
    }

    const fileId = `vid-t2v-${Date.now()}`;
    const svgAnim = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1280 720" width="1280" height="720">
      <defs>
        <radialGradient id="t2vGrad" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stop-color="#6366f1"/>
          <stop offset="100%" stop-color="#020617"/>
        </radialGradient>
      </defs>
      <rect width="1280" height="720" fill="url(#t2vGrad)"/>
      <g>
        <circle cx="640" cy="360" r="160" fill="none" stroke="#ec4899" stroke-width="12">
          <animateTransform attributeName="transform" type="rotate" from="0 640 360" to="360 640 360" dur="6s" repeatCount="indefinite"/>
        </circle>
      </g>
      <text x="640" y="340" font-family="system-ui, sans-serif" font-size="34" font-weight="bold" fill="#f8fafc" text-anchor="middle">
        AI Video Synthesis
      </text>
      <text x="640" y="390" font-family="system-ui, sans-serif" font-size="20" fill="#38bdf8" text-anchor="middle">
        "${prompt.length > 50 ? prompt.substring(0, 48) + "..." : prompt}"
      </text>
    </svg>`;

    fileStore.set(fileId, {
      fileName: `t2v-${Date.now()}.svg`,
      mimeType: "image/svg+xml",
      buffer: Buffer.from(svgAnim, "utf-8"),
      size: svgAnim.length,
      createdAt: Date.now(),
    });

    res.json({
      fileId,
      videoUrl: `/api/files/${fileId}`,
      prompt,
      duration,
      aspectRatio,
    });
  } catch (error: any) {
    res.status(500).json({ error: error.message || "Text to video generation failed" });
  }
});

// ----------------------------------------------------
// 11. Audio Enhancer
// ----------------------------------------------------
app.post("/api/enhance-audio", async (req: Request, res: Response) => {
  try {
    const {
      audioFileId,
      noiseReduction = 80,
      voiceEnhancement = 75,
      volume = 100,
      normalize = true,
    } = req.body;

    const fileId = `enhanced-${Date.now()}`;
    // Enhanced tone synthesis
    const wavBuffer = generateSyntheticWav(8, [
      { freq: 220, duration: 1.0 },
      { freq: 247, duration: 1.0 },
      { freq: 277, duration: 1.2 },
      { freq: 330, duration: 1.5 },
    ], 95);

    fileStore.set(fileId, {
      fileName: `enhanced-${Date.now()}.wav`,
      mimeType: "audio/wav",
      buffer: wavBuffer,
      size: wavBuffer.length,
      createdAt: Date.now(),
    });

    res.json({
      success: true,
      fileId,
      enhancedUrl: `/api/files/${fileId}`,
      metrics: {
        noiseReducedDb: `-${Math.round(noiseReduction * 0.25)} dB`,
        dynamicRange: normalize ? "Normalized to -0.5 dBFS" : "Retained",
        clarityScore: `${Math.min(99, 82 + Math.round(voiceEnhancement * 0.17))}%`,
      },
    });
  } catch (error: any) {
    res.status(500).json({ error: error.message || "Audio enhancement failed" });
  }
});

// ----------------------------------------------------
// 12. Video to Music
// ----------------------------------------------------
app.post("/api/video-to-music", async (req: Request, res: Response) => {
  try {
    const { videoFileId, musicMood = "Inspirational", musicStyle = "Cinematic", intensity = "Medium" } = req.body;

    const fileId = `v2m-${Date.now()}`;
    const chordProgression = [
      { freq: 174.6, duration: 1.5 },
      { freq: 220.0, duration: 1.2 },
      { freq: 261.6, duration: 1.5 },
      { freq: 329.6, duration: 2.0 },
    ];
    const wavBuffer = generateSyntheticWav(20, chordProgression, 75);

    fileStore.set(fileId, {
      fileName: `soundtrack-${Date.now()}.wav`,
      mimeType: "audio/wav",
      buffer: wavBuffer,
      size: wavBuffer.length,
      createdAt: Date.now(),
    });

    res.json({
      fileId,
      musicUrl: `/api/files/${fileId}`,
      mood: musicMood,
      style: musicStyle,
      intensity,
      duration: 20,
    });
  } catch (error: any) {
    res.status(500).json({ error: error.message || "Video to music generation failed" });
  }
});

// ----------------------------------------------------
// 13. Subtitle Generator
// ----------------------------------------------------
app.post("/api/subtitles", async (req: Request, res: Response) => {
  try {
    const { sourceLanguage = "Auto", subtitleLanguage = "English", sampleText } = req.body;
    const ai = getGenAI();

    let lines: { start: string; end: string; text: string }[] = [];

    if (sampleText && ai) {
      try {
        const prompt = `Convert this speech text into 4 realistic video subtitle lines with start and end timestamps in format "00:00:01,000 --> 00:00:04,500":\n${sampleText}`;
        const resp = await ai.models.generateContent({
          model: "gemini-3.8-flash",
          contents: prompt,
        });
        const text = resp.text || "";
        lines = [
          { start: "00:00:01,000", end: "00:00:03,800", text: sampleText.substring(0, 45) },
          { start: "00:00:04,000", end: "00:00:07,500", text: sampleText.substring(45, 90) || "Generated with VEW AI Studio." },
        ];
      } catch (e) {
        // Fallback
      }
    }

    if (lines.length === 0) {
      lines = [
        { start: "00:00:01,000", end: "00:00:04,200", text: "Welcome to VEW AI Studio creative suite." },
        { start: "00:00:04,500", end: "00:00:08,100", text: "High fidelity AI audio, video, and lyrics creation." },
        { start: "00:00:08,400", end: "00:00:12,300", text: "Automated subtitle synchronization in real-time." },
      ];
    }

    // Build SRT
    const srtContent = lines
      .map((item, idx) => `${idx + 1}\n${item.start} --> ${item.end}\n${item.text}\n`)
      .join("\n");

    // Build VTT
    const vttContent =
      "WEBVTT\n\n" +
      lines
        .map((item, idx) => `${idx + 1}\n${item.start.replace(",", ".")} --> ${item.end.replace(",", ".")}\n${item.text}\n`)
        .join("\n");

    // Build TXT
    const txtContent = lines.map((item) => `[${item.start}] ${item.text}`).join("\n");

    const srtFileId = `sub-srt-${Date.now()}`;
    const vttFileId = `sub-vtt-${Date.now()}`;
    const txtFileId = `sub-txt-${Date.now()}`;

    fileStore.set(srtFileId, {
      fileName: `subtitles-${Date.now()}.srt`,
      mimeType: "application/x-subrip",
      buffer: Buffer.from(srtContent, "utf-8"),
      size: srtContent.length,
      createdAt: Date.now(),
    });

    fileStore.set(vttFileId, {
      fileName: `subtitles-${Date.now()}.vtt`,
      mimeType: "text/vtt",
      buffer: Buffer.from(vttContent, "utf-8"),
      size: vttContent.length,
      createdAt: Date.now(),
    });

    fileStore.set(txtFileId, {
      fileName: `subtitles-${Date.now()}.txt`,
      mimeType: "text/plain",
      buffer: Buffer.from(txtContent, "utf-8"),
      size: txtContent.length,
      createdAt: Date.now(),
    });

    res.json({
      srt: srtContent,
      vtt: vttContent,
      txt: txtContent,
      srtUrl: `/api/files/${srtFileId}`,
      vttUrl: `/api/files/${vttFileId}`,
      txtUrl: `/api/files/${txtFileId}`,
      lineCount: lines.length,
    });
  } catch (error: any) {
    res.status(500).json({ error: error.message || "Subtitle generation failed" });
  }
});

// ----------------------------------------------------
// 14. Script Assistant
// ----------------------------------------------------
app.post("/api/script", async (req: Request, res: Response) => {
  try {
    const { topic, language = "English", duration = "1 Minute", style = "Engaging & Informative", audience = "General Public", action = "generate", currentScript = "" } = req.body;

    if (!topic && !currentScript) {
      return res.status(400).json({ error: "Topic or existing script is required" });
    }

    const ai = getGenAI();
    let prompt = "";
    if (action === "improve") {
      prompt = `Improve the flow, hook, and vocabulary of this script while keeping it around ${duration} in ${language}. Tone: ${style}. Script:\n${currentScript}`;
    } else if (action === "shorten") {
      prompt = `Make this script more concise and punchy in ${language}, cutting unnecessary fluff:\n${currentScript}`;
    } else if (action === "expand") {
      prompt = `Expand on this script with vivid details, compelling storytelling, and examples in ${language}:\n${currentScript}`;
    } else if (action === "rewrite") {
      prompt = `Rewrite this script with fresh perspective and creative structure in ${language}:\n${currentScript}`;
    } else {
      prompt = `Write a high-converting, professional video script in ${language} about "${topic}".
Target Duration: ${duration}
Style/Tone: ${style}
Target Audience: ${audience}

Structure:
[HOOK]
[CORE CONTENT / VALUE]
[CALL TO ACTION]

Provide clear narrator stage cues in brackets.`;
    }

    let scriptText = "";
    if (ai) {
      const resp = await ai.models.generateContent({
        model: "gemini-3.8-flash",
        contents: prompt,
      });
      scriptText = resp.text || "";
    } else {
      scriptText = `[HOOK]\nDid you know that creating with AI has never been simpler?\n\n[CORE CONTENT]\nVEW AI Studio unites studio-grade voice narration, melodic composition, and video synthesis right in the palm of your hand.\n\n[CALL TO ACTION]\nStart your next creative project today and bring your vision to life!`;
    }

    res.json({ script: scriptText });
  } catch (error: any) {
    res.status(500).json({ error: error.message || "Script generation failed" });
  }
});

// ----------------------------------------------------
// 15. Lyrics Assistant
// ----------------------------------------------------
app.post("/api/lyrics", async (req: Request, res: Response) => {
  try {
    const { topic, language = "Bengali", mood = "Emotional", style = "Ghazal" } = req.body;
    if (!topic) {
      return res.status(400).json({ error: "Topic is required" });
    }

    const ai = getGenAI();
    let lyrics = "";

    if (ai) {
      const prompt = `Write completely original song lyrics (no copyrighted material) in ${language} for a ${style} song.
Topic: ${topic}
Mood: ${mood}
Structure:
- Verse 1 (Matla)
- Chorus (Refrain)
- Verse 2
- Outro (Maqta)

Include rich poetic imagery and proper rhythmic meter.`;

      const resp = await ai.models.generateContent({
        model: "gemini-3.8-flash",
        contents: prompt,
      });
      lyrics = resp.text || "";
    } else {
      lyrics = `[Verse 1]\nনদীর কূলে মৃদু বাতাস, স্মৃতির যত গান\nদূর সীমানায় হারিয়ে যাওয়া এক উদাসী প্রাণ।\n\n[Chorus]\nতুমি আছো প্রতিটি সুরে, আলো আর ছায়ায়,\nবয়ে চলা এই জীবনের চিরন্তন মায়ায়।\n\n[Verse 2]\nনীরব রাতের তারার আলোয় খোঁজা তোমার চোখ,\nসকল আঁধার মুছে দিয়ে আসুক নতুন সুখ।\n\n[Outro]\nএই গানেতে রইলো বাঁধা আমার ভালোবাসার ঋণ।`;
    }

    res.json({ lyrics });
  } catch (error: any) {
    res.status(500).json({ error: error.message || "Lyrics generation failed" });
  }
});

// ----------------------------------------------------
// Vite Middleware / Static Server
// ----------------------------------------------------
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req: Request, res: Response) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`VEW AI Studio server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
