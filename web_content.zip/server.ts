import express from "express";
import path from "path";
import dotenv from "dotenv";
import { GoogleGenAI } from "@google/genai";
import { createServer as createViteServer } from "vite";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json({ limit: "10mb" }));

// Lazy initialize Gemini client
let aiClient: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI | null {
  if (!aiClient && process.env.GEMINI_API_KEY) {
    aiClient = new GoogleGenAI({
      apiKey: process.env.GEMINI_API_KEY,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }
  return aiClient;
}

// Health check endpoint
app.get("/api/health", (_req, res) => {
  res.json({
    status: "ok",
    timestamp: new Date().toISOString(),
    aiConfigured: !!process.env.GEMINI_API_KEY,
  });
});

// Gemini Kids Educational AI Assistant ("المعلم الصغير سِمْسِم")
app.post("/api/gemini/kids-helper", async (req, res) => {
  try {
    const { prompt, childAge = 7, mode = "explain", childName = "صديقي البطل" } = req.body;
    if (!prompt) {
      return res.status(400).json({ error: "الرجاء كتابة السؤال أو الفكرة" });
    }

    const ai = getGeminiClient();
    if (!ai) {
      return res.status(503).json({
        error: "خدمة الذكاء الاصطناعي التعليمية غير مفعلة حالياً. يمكنك الاستمرار في التعلم من خلال الأنشطة المدمجة الرائعة!",
      });
    }

    const systemInstruction = `أنت "المعلم الذكي سِمْسِم"، صديق ومعلم مرح وودود جداً للأطفال من عمر 5 إلى 10 سنوات (الطفل الحالي عمره ${childAge} سنوات واسمه ${childName}).
إرشاداتك الصارمة:
1. تكلم بلغة عربية فصحى جميلة ومبسطة جداً ومبهجة مع حركات التشكيل الواضحة للكلمات لمساعدة الطفل على القراءة السليمة.
2. استخدم تشبيهات ممتعة من حياة الطفل (مثل الفواكه، الحيوانات الأليفة، الألعاب، الفضاء، النجوم).
3. أسلوبك مليء بالتشجيع والثناء (أحسنت يا بطل، ما شاء الله عليك يا عبقري، سؤالك ذكي جداً).
4. عند شرح العلوم أو الحساب (الجمع، الطرح، الضرب، القيمة المكانية)، اشرح خطوة بخطوة بطريقة بصرية سهلة.
5. إذا طلب قصة، اجعلها قصة قصيرة جداً (3-4 فقرات مشكولة) تنمي الأخلاق الفاضلة وحب العلم.
6. تجنب أي معلومات معقدة أو مخيفة إطلاقاً؛ الإجابات دائماً إيجابية وآمنة وملهمة للأطفال.`;

    const response = await ai.models.generateContent({
      model: "gemini-3.8-flash",
      contents: `نوع النشاط: ${mode}\nسؤال الطفل: ${prompt}`,
      config: {
        systemInstruction,
        temperature: 0.7,
      },
    });

    return res.json({ text: response.text || "أحسنت يا بطل! استمر في التعلم والاستكشاف دائماً!" });
  } catch (error: any) {
    console.error("Kids AI error:", error);
    return res.status(500).json({
      error: error?.message || "حدث خطأ بسيط في الاتصال، حاول مرة أخرى يا بطل!",
    });
  }
});

async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error("Failed to start server:", err);
});
