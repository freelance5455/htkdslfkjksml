import express from 'express';
import http from 'http';
import { WebSocketServer, WebSocket } from 'ws';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const server = http.createServer(app);
const port = parseInt(process.env.PORT || '3000', 10);

// In-Memory Collaboration Rooms State
interface RoomPeer {
  id: string;
  name: string;
  color: string;
  ws: WebSocket;
  cursor?: { x: number; y: number; lastActive: number };
}

interface RoomState {
  roomId: string;
  boardTitle: string;
  elements: Map<string, any>;
  peers: Map<WebSocket, RoomPeer>;
  lastActivity: number;
}

const rooms = new Map<string, RoomState>();

function getOrCreateRoom(roomId: string, initialTitle = 'Collaborative Whiteboard'): RoomState {
  let room = rooms.get(roomId);
  if (!room) {
    room = {
      roomId,
      boardTitle: initialTitle,
      elements: new Map(),
      peers: new Map(),
      lastActivity: Date.now(),
    };
    rooms.set(roomId, room);
  }
  return room;
}

// Attach WebSocket Server
const wss = new WebSocketServer({ server, path: '/ws' });

wss.on('connection', (ws: WebSocket) => {
  let currentRoomId: string | null = null;
  let currentPeer: RoomPeer | null = null;

  ws.on('message', (data: string) => {
    try {
      const msg = JSON.parse(data.toString());

      // 1. JOIN ROOM
      if (msg.type === 'join') {
        const { roomId, peer, initialBoard } = msg;
        currentRoomId = roomId;

        const room = getOrCreateRoom(roomId, initialBoard?.title || 'Shared Whiteboard');

        // If room is fresh and client provided initial elements, seed the room
        if (room.elements.size === 0 && initialBoard?.elements && initialBoard.elements.length > 0) {
          for (const el of initialBoard.elements) {
            room.elements.set(el.id, el);
          }
          if (initialBoard.title) room.boardTitle = initialBoard.title;
        }

        currentPeer = {
          id: peer.id,
          name: peer.name,
          color: peer.color,
          ws,
        };
        room.peers.set(ws, currentPeer);
        room.lastActivity = Date.now();

        // Send Initial Sync payload to the joining client
        const syncPayload = {
          type: 'sync',
          roomId,
          boardTitle: room.boardTitle,
          elements: Array.from(room.elements.values()),
          peers: Array.from(room.peers.values()).map((p) => ({
            id: p.id,
            name: p.name,
            color: p.color,
            cursor: p.cursor,
          })),
        };
        ws.send(JSON.stringify(syncPayload));

        // Broadcast to other peers in room that a new peer joined
        broadcastToRoom(
          room,
          {
            type: 'peer-joined',
            peer: { id: currentPeer.id, name: currentPeer.name, color: currentPeer.color },
          },
          ws
        );
        return;
      }

      if (!currentRoomId || !currentPeer) return;
      const room = rooms.get(currentRoomId);
      if (!room) return;

      room.lastActivity = Date.now();

      // 2. LIVE CURSOR MOVEMENT
      if (msg.type === 'cursor') {
        currentPeer.cursor = { x: msg.x, y: msg.y, lastActive: Date.now() };
        broadcastToRoom(
          room,
          {
            type: 'cursor-moved',
            peerId: currentPeer.id,
            x: msg.x,
            y: msg.y,
          },
          ws
        );
        return;
      }

      // 3. ELEMENT UPSERT (Create / Move / Resize / Edit)
      if (msg.type === 'element-upsert') {
        const { element, timestamp } = msg;
        const existing = room.elements.get(element.id);

        // Last-Write-Wins (LWW) conflict resolution:
        // Accept update if element doesn't exist or incoming timestamp is newer/equal
        if (!existing || !existing.updatedAt || timestamp >= existing.updatedAt) {
          const updatedElement = { ...element, updatedAt: timestamp, updatedBy: currentPeer.id };
          room.elements.set(element.id, updatedElement);

          // Broadcast to all other peers
          broadcastToRoom(
            room,
            {
              type: 'element-upserted',
              peerId: currentPeer.id,
              element: updatedElement,
              timestamp,
            },
            ws
          );
        }
        return;
      }

      // 4. ELEMENT DELETE
      if (msg.type === 'element-delete') {
        const { elementId, timestamp } = msg;
        if (room.elements.has(elementId)) {
          room.elements.delete(elementId);
          broadcastToRoom(
            room,
            {
              type: 'element-deleted',
              peerId: currentPeer.id,
              elementId,
              timestamp,
            },
            ws
          );
        }
        return;
      }

      // 5. LIVE DRAWING STROKE (streaming stroke points while inking)
      if (msg.type === 'stroke-live') {
        broadcastToRoom(
          room,
          {
            type: 'stroke-live-received',
            peerId: currentPeer.id,
            strokeId: msg.strokeId,
            point: msg.point,
            color: msg.color,
            strokeWidth: msg.strokeWidth,
            isEnd: msg.isEnd,
          },
          ws
        );
        return;
      }
    } catch (err) {
      console.error('Error handling WebSocket message:', err);
    }
  });

  ws.on('close', () => {
    if (currentRoomId && currentPeer) {
      const room = rooms.get(currentRoomId);
      if (room) {
        room.peers.delete(ws);
        broadcastToRoom(room, {
          type: 'peer-left',
          peerId: currentPeer.id,
        });

        // Cleanup empty rooms after 30 minutes of inactivity
        if (room.peers.size === 0) {
          setTimeout(() => {
            if (room.peers.size === 0) {
              rooms.delete(currentRoomId!);
            }
          }, 1800000);
        }
      }
    }
  });

  ws.on('error', (err) => {
    console.error('WebSocket connection error:', err);
  });
});

function broadcastToRoom(room: RoomState, payload: any, senderWs?: WebSocket) {
  const data = JSON.stringify(payload);
  for (const [clientWs] of room.peers) {
    if (clientWs !== senderWs && clientWs.readyState === WebSocket.OPEN) {
      clientWs.send(data);
    }
  }
}

// REST Endpoints
app.use(express.json());

app.get('/api/health', (_req, res) => {
  res.json({
    status: 'ok',
    roomsActive: rooms.size,
    totalConnections: wss.clients.size,
    timestamp: new Date().toISOString(),
  });
});

app.get('/api/rooms/:roomId', (req, res) => {
  const room = rooms.get(req.params.roomId);
  if (!room) {
    return res.status(404).json({ error: 'Room not found' });
  }
  res.json({
    roomId: room.roomId,
    boardTitle: room.boardTitle,
    elementsCount: room.elements.size,
    activePeersCount: room.peers.size,
  });
});

// Vite Middleware (Development) or Static Serve (Production)
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  server.listen(port, '0.0.0.0', () => {
    console.log(`xvBOARD server running on port ${port}`);
  });
}

startServer();
