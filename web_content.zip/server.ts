import express from 'express';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = Number(process.env.PORT) || 3000;

app.use(express.json({ limit: '10mb' }));

// Initialize GoogleGenAI server-side with telemetry header
const apiKey = process.env.GEMINI_API_KEY;
let ai: GoogleGenAI | null = null;
if (apiKey && apiKey !== 'MY_GEMINI_API_KEY' && !apiKey.startsWith('MY_')) {
  ai = new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// Timeout wrapper helper
async function callGeminiWithTimeout<T>(promise: Promise<T>, timeoutMs = 6000): Promise<T> {
  return Promise.race([
    promise,
    new Promise<T>((_, reject) =>
      setTimeout(() => reject(new Error('AI request timeout')), timeoutMs)
    ),
  ]);
}

// 1. Chat with Coach Jaat
app.post('/api/coach/chat', async (req, res) => {
  try {
    const { messages, profile, recentWorkouts, recoveryState, language } = req.body;

    if (!ai) {
      return res.status(200).json({
        reply: getFallbackCoachResponse(messages[messages.length - 1]?.text || '', profile, language),
        isFallback: true,
      });
    }

    const systemInstruction = `
You are "Coach Jaat", the head running coach, sports scientist, and mentor behind JAAT RUNNER.
Tagline: "Run With Discipline. Train With Purpose."
Target Goal: 1600 metres in 4:50 (Target 400m lap pace: 1:12.5). Current baseline: ~5:30 (treat as unverified until verified in a time-trial).

Your Persona & Tone:
- Athletic, focused, disciplined, encouraging yet realistic. NEVER use fake praise, fluffy generic cheerleading, or unrealistic timeline promises.
- You speak fluently in English, Hindi, and natural athlete Hinglish (mix of Hindi & English common among Indian athletes, e.g., "Bhai aaj recovery day hai, pace control mein rakhna", "Lap splits consistent the, lekin last 400m mein cadence drop hui").
- Match the user's preferred language (${language || 'Hinglish'}). If they speak in Hindi or Hinglish, answer in Hinglish or Hindi.
- Address sleep, energy, muscle soreness, and today's workout state.
- Explain running pace, lap splits, breathing patterns (2-2 rhythm for tempo, 3-3 for easy aerobic), foot strike, hip extension, and post-run mobility.
- Review workouts honestly and compare against the 1600m sub-4:50 objective.
- CRITICAL SAFETY RULE: If the runner mentions sharp pain, acute knee/shin/hamstring injury, chest pain, dizziness, fainting, or severe breathing difficulty, IMMEDIATELY tell them to STOP training, do NOT prescribe running, and advise consulting a medical professional or sports physio. Never advise running through sharp pain.

User Context:
${profile ? `Runner: ${profile.name || 'Runner'}, Age: ${profile.age || 22}, Height: ${profile.height || 175}cm, Weight: ${profile.weight || 68}kg, Experience: ${profile.experience || 'Intermediate'}, 1600m PB: ${profile.pb1600m || '5:30 (Unverified)'}, Weekly Volume Target: ${profile.weeklyVolume || '20km'}` : 'New Runner Profile'}
${recoveryState ? `Recent Recovery Status: Sleep: ${recoveryState.sleepHours || 7}h, Fatigue: ${recoveryState.fatigueScore || 3}/10, Soreness: ${recoveryState.sorenessScore || 2}/10` : ''}
${recentWorkouts && recentWorkouts.length > 0 ? `Recent Sessions (${recentWorkouts.length}): Last run ${recentWorkouts[0].workoutType} of ${recentWorkouts[0].distanceKm}km at ${recentWorkouts[0].avgPace} min/km with RPE ${recentWorkouts[0].rpe}/10.` : 'No recorded sessions yet.'}

Provide clear, structured, actionable coaching advice. Keep paragraphs concise and easy to read on mobile.
`;

    // Format chat history for Gemini
    const contents = messages.map((m: { role: string; text: string }) => ({
      role: m.role === 'model' || m.role === 'assistant' ? 'model' : 'user',
      parts: [{ text: m.text }],
    }));

    const response = await callGeminiWithTimeout(
      ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents,
        config: {
          systemInstruction,
          temperature: 0.7,
        },
      })
    );

    const reply = response.text || "Discipline over motivation. Keep your stride controlled and focus on recovery.";
    return res.json({ reply, isFallback: false });
  } catch (error: any) {
    console.error('Error in Coach Jaat chat:', error);
    return res.status(200).json({
      reply: getFallbackCoachResponse(req.body.messages?.[req.body.messages.length - 1]?.text || '', req.body.profile, req.body.language),
      isFallback: true,
      error: error.message,
    });
  }
});

// 2. Weekly AI Analysis & Report
app.post('/api/coach/generate-weekly-report', async (req, res) => {
  try {
    const { workouts, profile, recoveryEntries } = req.body;

    if (!ai) {
      return res.status(200).json({
        report: generateFallbackWeeklyReport(workouts, profile),
        isFallback: true,
      });
    }

    const prompt = `
Analyze the runner's weekly performance for JAAT RUNNER.
Runner Target: 1600m in 4:50 (Current baseline ~5:30).
Workouts Logged: ${JSON.stringify(workouts || [])}
Recovery Check-ins: ${JSON.stringify(recoveryEntries || [])}
Profile: ${JSON.stringify(profile || {})}

Generate a structured weekly coaching report with exactly these 5 distinct sections:
1. WHAT IMPROVED: Specific observation on pace consistency, volume, or interval splits.
2. WHAT NEEDS WORK: Honest critique of pacing errors, fatigue management, or missed recovery.
3. WHETHER RECOVERY WAS ADEQUATE: Assessment of sleep, reported soreness, and fatigue.
4. WHAT TO CHANGE NEXT WEEK: Tactical adjustments to distance, rest intervals, or drill execution.
5. ONE REALISTIC FOCUS FOR THE NEXT 7 DAYS: A single, high-impact running rule or target for this runner.

Tone: Grounded sports scientist and disciplined coach. No false optimism. Distinctly label any race projections as estimates.
`;

    const response = await callGeminiWithTimeout(
      ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: prompt,
        config: {
          temperature: 0.5,
        },
      })
    );

    return res.json({
      report: response.text,
      isFallback: false,
    });
  } catch (err: any) {
    console.error('Weekly report error:', err);
    return res.status(200).json({
      report: generateFallbackWeeklyReport(req.body.workouts, req.body.profile),
      isFallback: true,
    });
  }
});

// 3. Workout Immediate Post-Run Analysis
app.post('/api/coach/analyze-workout', async (req, res) => {
  try {
    const { workout, profile, previousWorkouts } = req.body;

    if (!ai) {
      return res.status(200).json({
        feedback: getFallbackWorkoutFeedback(workout),
        isFallback: true,
      });
    }

    const prompt = `
The runner just completed a session:
Type: ${workout.workoutType}
Distance: ${workout.distanceKm} km (${workout.distanceMeters || workout.distanceKm * 1000} m)
Duration: ${workout.durationFormatted} (${workout.durationSeconds} seconds)
Average Pace: ${workout.avgPace} min/km
Perceived Exertion (RPE): ${workout.rpe}/10
Splits: ${JSON.stringify(workout.splits || [])}
Notes: ${workout.notes || 'None'}

Target 1600m goal: 4:50 (400m lap target: 1:12.5). Baseline: ~5:30.
Evaluate this session:
1. How does this effort align with their current aerobic base or speed phase?
2. Were splits pacing even, positive, or negative?
3. Recommended immediate recovery protocol (hydration, electrolyte, calf/hip mobility, sleep priority).
Provide a sharp, 3-paragraph coaching review. Tone: disciplined, clear, athletic.
`;

    const response = await callGeminiWithTimeout(
      ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: prompt,
        config: {
          temperature: 0.6,
        },
      })
    );

    return res.json({
      feedback: response.text,
      isFallback: false,
    });
  } catch (err: any) {
    console.error('Analyze workout error:', err);
    return res.status(200).json({
      feedback: getFallbackWorkoutFeedback(req.body.workout),
      isFallback: true,
    });
  }
});

// 4. Text-To-Speech endpoint with gemini-3.8-flash-lite-tts
app.post('/api/coach/tts', async (req, res) => {
  try {
    const { text } = req.body;
    if (!text || !ai) {
      return res.status(400).json({ error: 'Text or API key not available' });
    }

    // Clean text to avoid markdown asterisks in speech
    const cleanText = text.replace(/[*#_`]/g, '').slice(0, 350);

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash-lite-tts',
      contents: [
        {
          role: 'user',
          parts: [
            {
              text: cleanText,
              speechMetadata: {
                style: 'Firm, motivating, disciplined athletic coach',
              },
            },
          ],
        },
      ],
      config: {
        responseModalities: ['AUDIO'],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: 'Fenrir' },
          },
        },
      },
    });

    const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    if (base64Audio) {
      return res.json({
        audio: base64Audio,
        mimeType: 'audio/wav',
      });
    }

    return res.status(500).json({ error: 'No audio returned' });
  } catch (err: any) {
    console.error('TTS error:', err);
    return res.status(500).json({ error: err.message });
  }
});

// Fallback coach responses for offline or unconfigured API keys
function getFallbackCoachResponse(query: string, profile: any, lang: string): string {
  const q = query.toLowerCase();
  const name = profile?.name || 'Runner';

  if (q.includes('pain') || q.includes('dard') || q.includes('chot') || q.includes('injury') || q.includes('shin') || q.includes('knee')) {
    return `⚠️ COACH JAAT SAFETY WARNING:\n\n${name}, agar sharp pain ya joint stiffness hai, toh session immediately pause karo. No ego running through injuries.\n\n1. Ice application 15 mins for acute flare-up.\n2. R.I.C.E. protocol follow karo.\n3. Agar chest pain, fainting ya abnormal swelling hai, consult a sports doctor immediately. Hard intervals are cancelled until you are 100% pain-free.`;
  }

  if (q.includes('1600') || q.includes('4:50') || q.includes('split') || q.includes('time')) {
    return `Target 1600m in 4:50 requires exact lap splits of 1:12.5 per 400m.\n\n- Lap 1 (0-400m): 72-73s. Controlled adrenaline, don't blast off at 65s.\n- Lap 2 (400-800m): 72s. Lock into 2:2 breathing rhythm.\n- Lap 3 (800-1200m): 72.5s. The psychological test—drive from hips and glutes.\n- Lap 4 (1200-1600m): 71-72s. Arm drive and high knee lift to the line.\n\nRemember: your baseline ~5:30 is unverified until we log a fresh time trial. Stay disciplined!`;
  }

  if (q.includes('breathing') || q.includes('sans') || q.includes('breath')) {
    return `Breathing Technique for 1600m Track:\n\n- For Easy Runs: 3:3 stride pattern (Inhale 3 steps, exhale 3 steps through nose and mouth).\n- For 400m Intervals & Tempo: 2:2 rhythm (Inhale 2 steps, exhale 2 steps deeply into belly, not shallow chest breathing).\n- Keep jaw and shoulders completely relaxed. Tension in shoulders restricts lung volume.`;
  }

  return `Ram Ram ${name}! Coach Jaat here. Aaj ka objective clear hai: consistency and purpose.\n\nHar session ke pehle 10-15 mins dynamic warm-up (high knees, butt kicks, leg swings, A-skips) zaroori hai. Sleep aur hydration check-in karo. Aaj ke workout ke liye taiyar ho? Batao energy aur recovery ka status.`;
}

function generateFallbackWeeklyReport(workouts: any[], profile: any): string {
  const count = workouts ? workouts.length : 0;
  return `### JAAT RUNNER WEEKLY COACHING REVIEW

**1. WHAT IMPROVED**
Logged ${count} workout sessions this week. Aerobic base consistency is progressing. Stride control during warmup segments is showing discipline.

**2. WHAT NEEDS WORK**
Lap pace discipline on interval repetitions. Do not sprint the first 100m of a 400m repetition; maintain even cadence of ~178-184 SPM across all laps.

**3. WHETHER RECOVERY WAS ADEQUATE**
Adequate baseline recovery, but post-run hydration and calf/hamstring dynamic mobility must not be skipped. Keep sleep at minimum 7.5 hours for nervous system adaptation.

**4. WHAT TO CHANGE NEXT WEEK**
Add 1 additional recovery walk or active mobility block. Keep Wednesday 400m intervals strictly at sustainable threshold effort rather than maximum effort.

**5. ONE REALISTIC FOCUS FOR THE NEXT 7 DAYS**
"Execute the first 400m of every session at exact target pace, never faster than prescription."`;
}

function getFallbackWorkoutFeedback(workout: any): string {
  return `Solid effort logged. Duration: ${workout.durationFormatted}, Distance: ${workout.distanceKm} km at ${workout.avgPace} min/km (RPE ${workout.rpe}/10).\n\nKey Takeaway: Ensure you complete 10 minutes of active walking and static hamstring/hip flexor stretches immediately. Rehydrate with electrolyte water and prioritize 8 hours of sleep tonight.`;
}

// Development vs Production serving
async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';

  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(port, '0.0.0.0', () => {
    console.log(`JAAT RUNNER Server running on port ${port} (prod=${isProd})`);
  });
}

startServer();
