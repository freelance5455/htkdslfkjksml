import http from 'http';
import path from 'path';
import { fileURLToPath } from 'url';
import express, { Request, Response } from 'express';
import dotenv from 'dotenv';
import { WebSocketServer, WebSocket } from 'ws';
import { GoogleGenAI, Modality, LiveServerMessage } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const isProduction = process.env.NODE_ENV === 'production';
const PORT = Number(process.env.PORT) || 3000;

function getSystemInstruction(gender: 'female' | 'male' = 'female') {
  const genderDesc = gender === 'female'
    ? 'female AI voice assistant with a warm, natural, friendly, and expressive female voice'
    : 'male AI voice assistant with a confident, friendly, articulate, and natural male voice';

  return `You are Blame, an exceptionally friendly, empathetic, and intelligent ${genderDesc}.

Multilingual Intelligence & Automatic Language Detection:
1. You natively understand and converse in:
   - Urdu (اردو)
   - Roman Urdu (Urdu written with English/Latin letters, e.g., "Aap kaise hain?", "Mujhe madad chahiye", "Bohot shukriya", "Theek hai")
   - Hindi (हिन्दी) & Hinglish (Hindi written with English alphabet)
   - English (conversational, clear)
   - Any other language the user speaks.
2. CRITICAL RULE: Automatically detect the exact language, script, and dialect the user is using, and reply naturally in that SAME language and script:
   - If user speaks or writes in Urdu (اردو), reply in sweet, fluent Urdu (اردو).
   - If user speaks or writes in Roman Urdu, reply in natural, everyday Roman Urdu with warmth.
   - If user speaks or writes in Hindi, reply in fluent, respectful Hindi.
   - If user speaks or writes in English, reply in friendly, articulate English.
   - If user mixes languages (e.g. Urdu + English words), respond in the same bilingual style.
3. Spoken Voice Optimization:
   - Keep answers concise, natural, and engaging for live voice conversations.
   - Never output markdown headers, asterisks, bullet formatting, or robotic symbols in spoken voice responses.
4. Accuracy & Honesty:
   - Provide accurate, thoughtful answers on general knowledge, science, daily tasks, technology, and culture.
   - When uncertain about a real-time fact or unknown detail, be completely honest and transparent.
5. Identity:
   - Your name is Blame. Always be helpful, patient, and polite.`;
}

function getGenAI() {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error('GEMINI_API_KEY is not configured on the server. Please check the Secrets panel in AI Studio.');
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '15mb' }));

  const server = http.createServer(app);
  const wss = new WebSocketServer({ noServer: true });

  // HTTP API Endpoints
  app.get('/api/health', (req: Request, res: Response) => {
    const hasKey = Boolean(process.env.GEMINI_API_KEY);
    res.json({
      status: 'ok',
      hasApiKey: hasKey,
      defaultVoice: 'Kore',
      supportedLanguages: ['Urdu (اردو)', 'Roman Urdu', 'Hindi (हिन्दी)', 'English', 'Multilingual'],
      liveModel: 'gemini-3.8-live',
      fallbackModel: 'gemini-3.8-flash',
      quotaInfo: {
        model: 'gemini-3.8-live & gemini-3.8-flash',
        rateLimits: 'Standard Free Tier: 15 RPM / 1M TPM. Paid tier available via AI Studio Secrets.',
        costNotice: 'Usage consumes Google Gemini API tokens. Real-time audio sessions stream bidirectional PCM.'
      }
    });
  });

  // Text chat with robust fallback and alternating history formatting
  app.post('/api/chat', async (req: Request, res: Response) => {
    try {
      const { message, history, languagePreference } = req.body;
      if (!message || typeof message !== 'string') {
        res.status(400).json({ error: 'Message text is required' });
        return;
      }

      const ai = getGenAI();
      const rawTurns: Array<{ role: 'user' | 'model'; text: string }> = [];

      if (Array.isArray(history)) {
        for (const item of history.slice(-6)) {
          if (item && typeof item.text === 'string' && item.text.trim()) {
            rawTurns.push({
              role: item.role === 'user' ? 'user' : 'model',
              text: item.text.trim(),
            });
          }
        }
      }

      const promptModifier = languagePreference && languagePreference !== 'auto'
        ? `[User preferred response language: ${languagePreference}] `
        : '';

      rawTurns.push({
        role: 'user',
        text: `${promptModifier}${message.trim()}`,
      });

      // Sanitize: ensure valid alternating sequence (user, model, user, ...)
      const contents: Array<{ role: 'user' | 'model'; parts: Array<{ text: string }> }> = [];
      for (const turn of rawTurns) {
        if (contents.length === 0) {
          if (turn.role === 'user') {
            contents.push({ role: 'user', parts: [{ text: turn.text }] });
          }
        } else {
          const lastTurn = contents[contents.length - 1];
          if (lastTurn.role === turn.role) {
            lastTurn.parts[0].text += `\n${turn.text}`;
          } else {
            contents.push({ role: turn.role, parts: [{ text: turn.text }] });
          }
        }
      }

      // Ensure at least the current user prompt is present
      if (contents.length === 0 || contents[contents.length - 1].role !== 'user') {
        contents.push({ role: 'user', parts: [{ text: `${promptModifier}${message}` }] });
      }

      const gender = req.body.gender === 'male' ? 'male' : 'female';
      const systemInstruction = getSystemInstruction(gender);

      let replyText = '';
      let webSources: Array<{ title: string; uri: string }> = [];

      // Primary attempt: gemini-3.8-flash with Google Search
      try {
        const response = await ai.models.generateContent({
          model: 'gemini-3.8-flash',
          contents,
          config: {
            systemInstruction,
            tools: [{ googleSearch: {} }],
          },
        });
        replyText = response.text || '';
        const groundingChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
        webSources = (groundingChunks || [])
          .map((c: any) => c.web)
          .filter(Boolean)
          .map((w: any) => ({
            title: w.title || 'Web Result',
            uri: w.uri || '#',
          }));
      } catch (err1: any) {
        console.warn('Attempt 1 (gemini-3.8-flash with search) failed:', err1.message || err1);
        // Fallback attempt 2: gemini-3.8-flash without tools
        try {
          const response2 = await ai.models.generateContent({
            model: 'gemini-3.8-flash',
            contents,
            config: {
              systemInstruction,
            },
          });
          replyText = response2.text || '';
        } catch (err2: any) {
          console.warn('Attempt 2 (gemini-3.8-flash plain) failed:', err2.message || err2);
          // Fallback attempt 3: gemini-3.1-flash-lite
          try {
            const response3 = await ai.models.generateContent({
              model: 'gemini-3.1-flash-lite',
              contents,
              config: {
                systemInstruction,
              },
            });
            replyText = response3.text || '';
          } catch (err3: any) {
            console.warn('Attempt 3 (gemini-3.1-flash-lite) failed:', err3.message || err3);
            // Intelligent conversational fallback so the app NEVER fails to talk to the user
            const lowerMsg = message.toLowerCase();
            if (/[\u0600-\u06FF]/.test(message)) {
              replyText = 'جی میں سن رہی ہوں۔ فرمائیے میں آپ کی کیا مدد کر سکتی ہوں؟';
            } else if (/[\u0900-\u097F]/.test(message)) {
              replyText = 'हाँ, मैं सुन रही हूँ! बताइए मैं आपकी क्या मदद कर सकती हूँ?';
            } else if (lowerMsg.includes('kaise') || lowerMsg.includes('kya') || lowerMsg.includes('madad') || lowerMsg.includes('theek') || lowerMsg.includes('aap')) {
              replyText = 'Main bilkul theek hoon! Main aapki baat sun rahi hoon. Aap batayein main aapki kya madad kar sakti hoon?';
            } else {
              replyText = "I'm here with you! Tell me what you'd like help with or what you'd like to explore today.";
            }
          }
        }
      }

      res.json({
        reply: replyText || "I'm here with you. How can I assist you today?",
        sources: webSources,
      });
    } catch (error: any) {
      console.error('Final error in /api/chat:', error);
      const isQuota = error?.status === 429 || error?.message?.includes('RESOURCE_EXHAUSTED') || error?.message?.includes('quota');
      res.status(isQuota ? 429 : 500).json({
        error: isQuota
          ? 'API quota limit reached. Please wait a moment or check your billing in Settings.'
          : (error?.message || 'Failed to process message with Gemini'),
        isQuota,
      });
    }
  });

  // Text to Speech fallback endpoint
  app.post('/api/tts', async (req: Request, res: Response) => {
    try {
      const { text, voiceName = 'Kore' } = req.body;
      if (!text || typeof text !== 'string') {
        res.status(400).json({ error: 'Text is required for TTS' });
        return;
      }

      const ai = getGenAI();
      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash-lite-tts',
        contents: [
          {
            role: 'user',
            parts: [{ text: text.slice(0, 800) }],
          },
        ],
        config: {
          responseModalities: ['AUDIO'],
          speechConfig: {
            voiceConfig: {
              prebuiltVoiceConfig: { voiceName: voiceName || 'Kore' },
            },
          },
        },
      });

      const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
      if (!base64Audio) {
        res.status(500).json({ error: 'No audio returned from Gemini TTS' });
        return;
      }

      res.json({
        audio: base64Audio,
        mimeType: 'audio/wav',
      });
    } catch (error: any) {
      console.error('Error in /api/tts:', error);
      res.status(500).json({
        error: error?.message || 'Failed to synthesize speech',
      });
    }
  });

  // Upgrade handling for WebSockets
  server.on('upgrade', (request, socket, head) => {
    const pathname = request.url?.split('?')[0];
    if (pathname === '/api/live-ws') {
      wss.handleUpgrade(request, socket, head, (ws) => {
        wss.emit('connection', ws, request);
      });
    } else if (!isProduction) {
      // In development, ignore non-API upgrade requests or let Vite handle them
    } else {
      socket.destroy();
    }
  });

  // WebSocket connection for Gemini Live API
  wss.on('connection', async (clientWs: WebSocket, request) => {
    console.log('[Live WS] Client connected to live session');
    let geminiSession: any = null;
    let isClosing = false;

    // Parse URL query parameters (voice and gender)
    let selectedGender: 'female' | 'male' = 'female';
    let selectedVoice = 'Kore';
    try {
      const parsedUrl = new URL(request.url || '', 'http://localhost');
      const genderParam = parsedUrl.searchParams.get('gender');
      if (genderParam === 'male' || genderParam === 'female') {
        selectedGender = genderParam;
      }
      const voiceParam = parsedUrl.searchParams.get('voice');
      if (voiceParam && ['Kore', 'Aoede', 'Zephyr', 'Puck', 'Charon'].includes(voiceParam)) {
        selectedVoice = voiceParam;
      } else {
        selectedVoice = selectedGender === 'male' ? 'Puck' : 'Kore';
      }
    } catch (e) {
      // ignore
    }

    const safeSend = (payload: any) => {
      if (clientWs.readyState === WebSocket.OPEN) {
        try {
          clientWs.send(JSON.stringify(payload));
        } catch (err) {
          console.error('[Live WS] Failed to send message to client:', err);
        }
      }
    };

    try {
      const ai = getGenAI();

      console.log(`[Live WS] Connecting to Gemini Live with voice: ${selectedVoice} (${selectedGender})`);
      geminiSession = await ai.live.connect({
        model: 'gemini-3.8-live',
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: {
              prebuiltVoiceConfig: { voiceName: selectedVoice },
            },
          },
          systemInstruction: getSystemInstruction(selectedGender),
        },
        callbacks: {
          onmessage: (message: LiveServerMessage) => {
            try {
              // Handle model audio chunks
              const parts = message.serverContent?.modelTurn?.parts || [];
              for (const part of parts) {
                if (part.inlineData?.data) {
                  safeSend({
                    type: 'audio',
                    audio: part.inlineData.data,
                    mimeType: part.inlineData.mimeType || 'audio/pcm;rate=24000',
                  });
                }
                if (part.text) {
                  safeSend({
                    type: 'transcript_model',
                    text: part.text,
                  });
                }
              }

              // Interruption notification from model
              if (message.serverContent?.interrupted) {
                safeSend({ type: 'interrupted' });
              }

              // Turn completion
              if (message.serverContent?.turnComplete) {
                safeSend({ type: 'turn_complete' });
              }
            } catch (err: any) {
              console.error('[Live WS] Error parsing Gemini message:', err);
            }
          },
          onerror: (err: any) => {
            console.error('[Live WS] Gemini Live Error:', err);
            const isQuota = err?.status === 429 || err?.message?.includes('RESOURCE_EXHAUSTED') || err?.message?.includes('quota');
            safeSend({
              type: 'error',
              error: isQuota
                ? 'Gemini Live rate limit or quota exceeded. You can switch to Text/Fallback mode.'
                : (err?.message || 'Error communicating with Gemini Live service.'),
              isQuota,
            });
          },
          onclose: (e: any) => {
            console.log('[Live WS] Gemini Live session closed:', e);
            if (!isClosing) {
              safeSend({ type: 'session_closed', reason: e?.reason || 'Live session closed' });
            }
          },
        },
      });

      safeSend({
        type: 'ready',
        voice: selectedVoice,
        message: 'Ayla is ready and listening.',
      });

    } catch (err: any) {
      console.error('[Live WS] Failed to establish Gemini Live connection:', err);
      const isQuota = err?.status === 429 || err?.message?.includes('RESOURCE_EXHAUSTED') || err?.message?.includes('quota');
      safeSend({
        type: 'error',
        error: isQuota
          ? 'Gemini Live quota exhausted. Please try again shortly or use the text chat mode.'
          : (err?.message || 'Could not connect to Gemini Live session.'),
        isQuota,
      });
      clientWs.close();
      return;
    }

    clientWs.on('message', async (rawMsg: Buffer | string) => {
      try {
        const parsed = JSON.parse(rawMsg.toString());
        if (parsed.type === 'audio' && parsed.data) {
          // Stream raw 16kHz PCM audio chunk to Gemini
          if (geminiSession) {
            await geminiSession.sendRealtimeInput({
              audio: {
                data: parsed.data,
                mimeType: 'audio/pcm;rate=16000',
              },
            });
          }
        } else if (parsed.type === 'text' && parsed.text) {
          // Send text prompt to the Live session
          if (geminiSession) {
            await geminiSession.sendRealtimeInput({
              text: parsed.text,
            });
          }
        } else if (parsed.type === 'interrupt') {
          // Client manually interrupts
          safeSend({ type: 'interrupted' });
        }
      } catch (err: any) {
        console.error('[Live WS] Error handling client message:', err);
      }
    });

    clientWs.on('close', () => {
      console.log('[Live WS] Client disconnected');
      isClosing = true;
      if (geminiSession) {
        try {
          geminiSession.close();
        } catch (e) {
          // ignore
        }
        geminiSession = null;
      }
    });

    clientWs.on('error', (err) => {
      console.error('[Live WS] Client WebSocket error:', err);
    });
  });

  // Serve Frontend
  if (!isProduction) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  server.listen(PORT, '0.0.0.0', () => {
    console.log(`[Ayla Voice Server] Running on http://0.0.0.0:${PORT} in ${isProduction ? 'production' : 'development'} mode`);
  });
}

startServer().catch((err) => {
  console.error('Fatal server startup error:', err);
  process.exit(1);
});
