import 'dotenv/config';
import express from 'express';
import type { Request, Response, NextFunction } from 'express';
import multer from 'multer';
import path from 'node:path';
import fs from 'node:fs';
import crypto from 'node:crypto';
import mammoth from 'mammoth';
import AdmZip from 'adm-zip';
import { GoogleGenAI } from '@google/genai';
import { initializeApp, getApps, getApp } from 'firebase-admin/app';
import { getAuth } from 'firebase-admin/auth';

const PORT = Number(process.env.PORT) || 3000;
const ADMIN_EMAIL = 'weeq143900@gmail.com';
const UPLOADS_DIR = path.resolve(process.cwd(), 'uploads');
fs.mkdirSync(UPLOADS_DIR, { recursive: true });

// Load Firebase projectId safely from firebase-applet-config.json
let firebaseProjectId = '';
try {
  const cfgPath = path.resolve(process.cwd(), 'firebase-applet-config.json');
  if (fs.existsSync(cfgPath)) {
    const raw = JSON.parse(fs.readFileSync(cfgPath, 'utf8')) as { projectId?: string };
    if (raw.projectId && raw.projectId !== 'remixed-project-id') {
      firebaseProjectId = raw.projectId;
    }
  }
} catch (err) {
  console.error('Failed to read firebase-applet-config.json:', err);
}

const adminApp = firebaseProjectId
  ? getApps().length
    ? getApp()
    : initializeApp({ projectId: firebaseProjectId })
  : null;
const adminAuth = adminApp ? getAuth(adminApp) : null;

const GEMINI_PRIMARY_MODEL = 'gemini-4-hydrogen';
const GEMINI_FALLBACK_MODEL = 'gemini-3.1-flash-lite';

function resolveGeminiApiKey(): string {
  const candidate =
    process.env.GEMINI_API_KEY?.trim() ||
    process.env.API_KEY?.trim() ||
    '';
  if (
    !candidate ||
    candidate === 'MY_GEMINI_API_KEY' ||
    candidate === 'YOUR_API_KEY'
  ) {
    return '';
  }
  return candidate;
}

function extractGeminiError(err: unknown): {
  status: number;
  code: string;
  message: string;
} {
  const fallbackMsg = err instanceof Error ? err.message : String(err || 'Unknown Gemini error');
  const record = (typeof err === 'object' && err !== null ? err : {}) as Record<string, unknown>;
  const rawStatus =
    typeof record.status === 'number'
      ? record.status
      : typeof record.statusCode === 'number'
        ? record.statusCode
        : 0;
  let status = rawStatus;
  if (!status) {
    const match = fallbackMsg.match(/\b(400|401|403|404|429|500|502|503|504)\b/);
    if (match) status = Number(match[1]);
  }
  const code = typeof record.code === 'string' ? record.code : '';
  return {
    status: status || 502,
    code,
    message: fallbackMsg,
  };
}

const ALLOWED_EXTENSIONS = new Set([
  '.pdf',
  '.doc',
  '.docx',
  '.ppt',
  '.pptx',
  '.xls',
  '.xlsx',
  '.csv',
  '.mp4',
  '.webm',
  '.mov',
  '.m4v',
  '.mp3',
  '.wav',
  '.ogg',
  '.m4a',
  '.aac',
  '.png',
  '.jpg',
  '.jpeg',
  '.webp',
  '.gif',
]);

const adminDiskStorage = multer.diskStorage({
  destination: (_req, _file, cb) => {
    cb(null, UPLOADS_DIR);
  },
  filename: (_req, file, cb) => {
    const ext = path.extname(file.originalname || '').toLowerCase();
    const safeExt = ALLOWED_EXTENSIONS.has(ext) ? ext : '';
    const uniqueName = `${Date.now()}_${crypto.randomUUID().slice(0, 8)}${safeExt}`;
    cb(null, uniqueName);
  },
});

const adminUpload = multer({
  storage: adminDiskStorage,
  limits: { fileSize: 90 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    const ext = path.extname(file.originalname || '').toLowerCase();
    if (!ALLOWED_EXTENSIONS.has(ext)) {
      cb(
        new Error(
          'الصيغة دي مش مدعومة'
        )
      );
      return;
    }
    cb(null, true);
  },
});

const aiMemoryUpload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 90 * 1024 * 1024 },
});

interface AuthenticatedRequest extends Request {
  adminEmail?: string;
}

async function requireAdmin(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  try {
    if (!adminAuth) {
      res.status(503).json({ error: 'خدمة التحقق من المشرف غير مهيأة حالياً.' });
      return;
    }
    const authHeader = req.headers.authorization || '';
    if (!authHeader.startsWith('Bearer ')) {
      res.status(401).json({ error: 'يرجى تسجيل الدخول كمشرف أولاً.' });
      return;
    }
    const idToken = authHeader.slice(7).trim();
    if (!idToken) {
      res.status(401).json({ error: 'رمز التحقق غير صالح.' });
      return;
    }
    const decoded = await adminAuth.verifyIdToken(idToken);
    const email = (decoded.email || '').toLowerCase();
    if (email !== ADMIN_EMAIL || decoded.email_verified !== true) {
      res.status(403).json({ error: 'هذا الحساب غير مصرح له بصلاحيات المشرف.' });
      return;
    }
    req.adminEmail = email;
    next();
  } catch (err) {
    console.error('Admin token verification failed:', err);
    res.status(401).json({ error: 'انتهت جلسة المشرف، يرجى إعادة تسجيل الدخول.' });
  }
}

function resolveSafeUploadPath(rawFilename: string): string | null {
  if (!rawFilename || !/^[a-zA-Z0-9_.\-]+$/.test(rawFilename)) {
    return null;
  }
  const resolved = path.resolve(UPLOADS_DIR, rawFilename);
  if (!resolved.startsWith(UPLOADS_DIR + path.sep)) {
    return null;
  }
  return resolved;
}

function inferMimeType(file: Express.Multer.File): string {
  if (file.mimetype && file.mimetype !== 'application/octet-stream') {
    return file.mimetype;
  }
  const ext = path.extname(file.originalname || '').toLowerCase();
  const map: Record<string, string> = {
    '.pdf': 'application/pdf',
    '.doc': 'application/msword',
    '.docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    '.ppt': 'application/vnd.ms-powerpoint',
    '.pptx': 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
    '.xls': 'application/vnd.ms-excel',
    '.xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    '.png': 'image/png',
    '.jpg': 'image/jpeg',
    '.jpeg': 'image/jpeg',
    '.webp': 'image/webp',
    '.gif': 'image/gif',
    '.mp3': 'audio/mpeg',
    '.wav': 'audio/wav',
    '.ogg': 'audio/ogg',
    '.m4a': 'audio/mp4',
    '.aac': 'audio/aac',
    '.mp4': 'video/mp4',
    '.webm': 'video/webm',
    '.mov': 'video/quicktime',
    '.txt': 'text/plain',
    '.md': 'text/markdown',
    '.csv': 'text/csv',
    '.json': 'application/json',
  };
  return map[ext] || 'application/octet-stream';
}

function decodeXmlEntities(text: string): string {
  return text
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'");
}

const officePreviewUpload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 90 * 1024 * 1024 },
});

function parsePptxSlides(
  source: string | Buffer
): Array<{ slideNumber: number; lines: string[] }> {
  const zip = new AdmZip(source);
  const slideEntries = zip
    .getEntries()
    .filter((e) => /^ppt\/slides\/slide\d+\.xml$/i.test(e.entryName))
    .sort((a, b) => {
      const numA = Number(a.entryName.match(/slide(\d+)\.xml/i)?.[1] || 0);
      const numB = Number(b.entryName.match(/slide(\d+)\.xml/i)?.[1] || 0);
      return numA - numB;
    });

  return slideEntries.map((entry, idx) => {
    const xml = entry.getData().toString('utf8');
    const lines: string[] = [];
    const pMatches = xml.match(/<a:p\b[\s\S]*?<\/a:p>/g) || [];
    for (const p of pMatches) {
      const tMatches = p.match(/<a:t[^>]*>([\s\S]*?)<\/a:t>/g) || [];
      const lineText = tMatches
        .map((t) => decodeXmlEntities(t.replace(/<[^>]+>/g, '')))
        .join('')
        .trim();
      if (lineText) lines.push(lineText);
    }
    return { slideNumber: idx + 1, lines };
  });
}

function parseXlsxRows(source: string | Buffer): string[][] {
  const zip = new AdmZip(source);
  const sharedEntry = zip.getEntry('xl/sharedStrings.xml');
  const sharedStrings: string[] = [];

  if (sharedEntry) {
    const sharedXml = sharedEntry.getData().toString('utf8');
    const siMatches = sharedXml.match(/<si\b[\s\S]*?<\/si>/g) || [];
    for (const si of siMatches) {
      const tMatches = si.match(/<t[^>]*>([\s\S]*?)<\/t>/g) || [];
      const combined = tMatches
        .map((t) => decodeXmlEntities(t.replace(/<[^>]+>/g, '')))
        .join('');
      sharedStrings.push(combined);
    }
  }

  const sheetEntry =
    zip.getEntry('xl/worksheets/sheet1.xml') ||
    zip.getEntries().find((e) => /^xl\/worksheets\/sheet\d+\.xml$/i.test(e.entryName));

  if (!sheetEntry) return [];

  const sheetXml = sheetEntry.getData().toString('utf8');
  const rowMatches = sheetXml.match(/<row\b[\s\S]*?<\/row>/g) || [];
  const rows: string[][] = [];

  for (const rowXml of rowMatches.slice(0, 120)) {
    const cellMatches = rowXml.match(/<c\b[\s\S]*?<\/c>/g) || [];
    const rowValues: string[] = [];
    for (const cell of cellMatches.slice(0, 20)) {
      const isShared = /\bt="s"/.test(cell);
      const isInlineStr = /\bt="inlineStr"/.test(cell);
      if (isInlineStr) {
        const tVal = cell.match(/<t[^>]*>([\s\S]*?)<\/t>/)?.[1] || '';
        rowValues.push(decodeXmlEntities(tVal));
      } else {
        const vVal = cell.match(/<v[^>]*>([\s\S]*?)<\/v>/)?.[1] || '';
        if (isShared) {
          const idx = Number(vVal);
          rowValues.push(sharedStrings[idx] ?? '');
        } else {
          rowValues.push(decodeXmlEntities(vVal));
        }
      }
    }
    if (rowValues.some((v) => v.trim() !== '')) {
      rows.push(rowValues);
    }
  }
  return rows;
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '2mb' }));

  app.get('/api/health', (_req, res) => {
    res.json({ ok: true });
  });

  // Admin file upload for all supported formats
  app.post('/api/upload', requireAdmin, (req, res) => {
    adminUpload.single('file')(req, res, (err) => {
      if (err) {
        res.status(400).json({ error: err instanceof Error ? err.message : 'فشل رفع الملف.' });
        return;
      }
      if (!req.file) {
        res.status(400).json({ error: 'لم يتم اختيار أي ملف.' });
        return;
      }
      const originalName = Buffer.from(req.file.originalname, 'latin1').toString('utf8');
      res.json({
        fileUrl: `/uploads/${req.file.filename}`,
        storedName: req.file.filename,
        originalName,
        mimeType: req.file.mimetype,
        size: req.file.size,
      });
    });
  });

  // Admin delete uploaded file
  app.delete('/api/upload/:storedName', requireAdmin, (req, res) => {
    const rawName = String(req.params.storedName || '');
    const safePath = resolveSafeUploadPath(rawName);
    if (!safePath) {
      res.status(400).json({ error: 'اسم الملف غير صالح.' });
      return;
    }
    try {
      if (fs.existsSync(safePath)) {
        fs.unlinkSync(safePath);
      }
      res.json({ deleted: true });
    } catch (err) {
      console.error('Failed to delete uploaded file:', err);
      res.status(500).json({ error: 'تعذر حذف الملف من الخادم.' });
    }
  });

  // Inline viewer stream
  app.get('/uploads/:storedName', (req, res) => {
    const rawName = String(req.params.storedName || '');
    const safePath = resolveSafeUploadPath(rawName);
    if (!safePath || !fs.existsSync(safePath)) {
      res.status(404).json({ error: 'الملف غير موجود.' });
      return;
    }
    res.sendFile(safePath);
  });

  // In-app Office document parser for Word, PowerPoint, and Excel
  app.get('/api/preview/:storedName', async (req, res) => {
    const rawName = String(req.params.storedName || '');
    const safePath = resolveSafeUploadPath(rawName);
    if (!safePath || !fs.existsSync(safePath)) {
      res.status(404).json({ error: 'الملف غير موجود.' });
      return;
    }

    const ext = path.extname(safePath).toLowerCase();
    try {
      if (ext === '.docx') {
        const result = await mammoth.extractRawText({ path: safePath });
        const paragraphs = result.value
          .split(/\r?\n/)
          .map((p) => p.trim())
          .filter(Boolean);
        res.json({ type: 'word', paragraphs });
        return;
      }
      if (ext === '.pptx') {
        const slides = parsePptxSlides(safePath);
        res.json({ type: 'powerpoint', slides });
        return;
      }
      if (ext === '.xlsx') {
        const rows = parseXlsxRows(safePath);
        res.json({ type: 'excel', rows });
        return;
      }
      if (ext === '.csv') {
        const raw = fs.readFileSync(safePath, 'utf8');
        const rows = raw
          .split(/\r?\n/)
          .slice(0, 120)
          .map((line) => line.split(',').map((c) => c.trim()))
          .filter((r) => r.some(Boolean));
        res.json({ type: 'excel', rows });
        return;
      }
      res.json({
        type: 'legacy',
        message: 'هذا التنسيق القديم يمكن تحميله مباشرة أو استعراضه بعد تحويله إلى DOCX/PPTX/XLSX.',
      });
    } catch (err) {
      console.error('Preview parsing error:', err);
      res.status(500).json({ error: 'تعذر قراءة محتوى المستند للمعاينة.' });
    }
  });

  // In-app Office document parser for Blobs loaded from IndexedDB
  app.post('/api/preview-blob', (req, res) => {
    officePreviewUpload.single('file')(req, res, async (uploadErr) => {
      if (uploadErr) {
        res.status(400).json({ error: 'حجم المستند كبير جداً للمعاينة.' });
        return;
      }
      if (!req.file) {
        res.status(400).json({ error: 'لم يتم إرسال ملف للمعاينة.' });
        return;
      }

      const originalName = Buffer.from(req.file.originalname || '', 'latin1').toString('utf8');
      const ext = path.extname(originalName).toLowerCase();

      try {
        if (ext === '.docx') {
          const result = await mammoth.extractRawText({ buffer: req.file.buffer });
          const paragraphs = result.value
            .split(/\r?\n/)
            .map((p) => p.trim())
            .filter(Boolean);
          res.json({ type: 'word', paragraphs });
          return;
        }
        if (ext === '.pptx') {
          const slides = parsePptxSlides(req.file.buffer);
          res.json({ type: 'powerpoint', slides });
          return;
        }
        if (ext === '.xlsx') {
          const rows = parseXlsxRows(req.file.buffer);
          res.json({ type: 'excel', rows });
          return;
        }
        if (ext === '.csv') {
          const raw = req.file.buffer.toString('utf8');
          const rows = raw
            .split(/\r?\n/)
            .slice(0, 120)
            .map((line) => line.split(',').map((c) => c.trim()))
            .filter((r) => r.some(Boolean));
          res.json({ type: 'excel', rows });
          return;
        }
        res.json({
          type: 'legacy',
          message:
            'هذا التنسيق القديم يمكن تحميله مباشرة أو استعراضه بعد تحويله إلى DOCX/PPTX/XLSX.',
        });
      } catch (err) {
        console.error('Blob preview parsing error:', err);
        res.status(500).json({ error: 'تعذر قراءة محتوى المستند للمعاينة.' });
      }
    });
  });

  // Direct download endpoint
  app.get('/api/download/:storedName', (req, res) => {
    const rawName = String(req.params.storedName || '');
    const safePath = resolveSafeUploadPath(rawName);
    if (!safePath || !fs.existsSync(safePath)) {
      res.status(404).json({ error: 'الملف غير موجود.' });
      return;
    }
    const requestedName =
      typeof req.query.name === 'string' && req.query.name.trim()
        ? req.query.name.trim().replace(/[/\\?%*:|"<>]/g, '_')
        : rawName;
    res.download(safePath, requestedName);
  });

  // AI Tutor endpoint supporting text + any uploaded file
  app.post('/api/ai/chat', (req, res) => {
    aiMemoryUpload.single('file')(req, res, async (uploadErr) => {
      if (uploadErr) {
        res.status(400).json({ error: 'الملف أكبر من 90 ميجا، ارفع ملف أصغر من 90 ميجا' });
        return;
      }

      const apiKey = resolveGeminiApiKey();
      if (!apiKey) {
        console.error('[AI Tutor] Missing GEMINI_API_KEY / API_KEY in server environment.');
        res.status(503).json({
          code: 'MISSING_API_KEY',
          status: 503,
          error:
            'المعلم محتاج مفتاح API عشان يرد؛ تأكد من إضافة GEMINI_API_KEY في إعدادات المشروع (Settings > Secrets).',
          details: 'GEMINI_API_KEY / API_KEY is not configured in the server environment.',
        });
        return;
      }

      try {
        const aiClient = new GoogleGenAI({
          apiKey,
          httpOptions: {
            headers: {
              'User-Agent': 'aistudio-build',
            },
          },
        });

        const prompt = typeof req.body.prompt === 'string' ? req.body.prompt.trim() : '';
        const rawHistory = typeof req.body.history === 'string' ? req.body.history : '[]';
        let parsedHistory: Array<{ role: 'user' | 'model'; text: string }> = [];
        try {
          const candidate = JSON.parse(rawHistory);
          if (Array.isArray(candidate)) {
            parsedHistory = candidate
              .filter(
                (m) =>
                  m &&
                  (m.role === 'user' || m.role === 'model') &&
                  typeof m.text === 'string' &&
                  m.text.trim().length > 0
              )
              .slice(-10);
          }
        } catch {
          parsedHistory = [];
        }

        const file = req.file;
        if (!prompt && !file) {
          res.status(400).json({ error: 'يرجى كتابة سؤالك أو إرفاق ملف للشرح.' });
          return;
        }

        const contents: Array<{ role: 'user' | 'model'; parts: Array<Record<string, unknown>> }> =
          parsedHistory.map((item) => ({
            role: item.role,
            parts: [{ text: item.text }],
          }));

        const currentParts: Array<Record<string, unknown>> = [];
        if (file) {
          const mimeType = inferMimeType(file);
          const originalName = Buffer.from(file.originalname || 'file', 'latin1').toString('utf8');
          const isTextLike =
            mimeType.startsWith('text/') ||
            mimeType === 'application/json' ||
            mimeType === 'application/xml';

          currentParts.push({
            text: `اسم الملف المرفق: ${originalName}`,
          });

          if (isTextLike) {
            const decodedText = file.buffer.toString('utf8').slice(0, 80000);
            currentParts.push({
              text: `محتوى الملف المرفق (${originalName}):\n\n${decodedText}`,
            });
          } else if (
            mimeType === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
          ) {
            const extracted = await mammoth.extractRawText({ buffer: file.buffer });
            currentParts.push({
              text: `محتوى مستند Word (${originalName}):\n\n${extracted.value.slice(0, 80000)}`,
            });
          } else if (
            mimeType === 'application/vnd.openxmlformats-officedocument.presentationml.presentation'
          ) {
            const slides = parsePptxSlides(file.buffer);
            const slideText = slides
              .map((s) => `شريحة ${s.slideNumber}: ${s.lines.join(' ')}`)
              .join('\n')
              .slice(0, 80000);
            currentParts.push({
              text: `محتوى عرض PowerPoint (${originalName}):\n\n${slideText}`,
            });
          } else if (
            mimeType === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
          ) {
            const rows = parseXlsxRows(file.buffer);
            const sheetText = rows
              .map((r) => r.join(' | '))
              .join('\n')
              .slice(0, 80000);
            currentParts.push({
              text: `محتوى جدول Excel (${originalName}):\n\n${sheetText}`,
            });
          } else if (file.buffer.length <= 20 * 1024 * 1024) {
            currentParts.push({
              inlineData: {
                mimeType,
                data: file.buffer.toString('base64'),
              },
            });
          } else {
            currentParts.push({
              text: `ملف مرفق (${originalName}) بحجم ${Math.round(
                file.buffer.length / (1024 * 1024)
              )} ميجابايت — اشرح للطالب بناءً على عنوان الملف وسؤاله.`,
            });
          }
        }

        currentParts.push({
          text:
            prompt ||
            'اشرح لي محتوى هذا الملف بأسلوب واضح ومبسط للطلاب مع تلخيص أهم الأفكار والنقاط الرئيسية.',
        });

        contents.push({
          role: 'user',
          parts: currentParts,
        });

        const systemInstruction =
          'أنت معلم ومساعد دراسي ذكي ومشجع في تطبيق "نذاكر". اشرح المفاهيم والدروس والملفات المرفقة (PDF، Word، PowerPoint، Excel، صور، صوت، فيديو، نصوص) باللغة العربية المصرية البسيطة والمفهومة للطلاب (أو الفصحى الميسرة حسب طلب الطالب)، مع تنظيم الإجابة في نقاط واضحة وأمثلة عملية وحل وتفسير الأسئلة خطوة بخطوة.';

        const callModel = async (model: string) => {
          return aiClient.models.generateContent({
            model,
            contents,
            config: { systemInstruction },
          });
        };

        let response;
        try {
          response = await callModel(GEMINI_PRIMARY_MODEL);
        } catch (firstErr) {
          const info = extractGeminiError(firstErr);
          console.error('[AI Tutor] Primary model call failed, retrying after 2s:', {
            model: GEMINI_PRIMARY_MODEL,
            status: info.status,
            code: info.code,
            message: info.message,
          });
          await new Promise((resolve) => setTimeout(resolve, 2000));

          const retryModel =
            info.status === 404 || info.status === 429 || info.status >= 500
              ? GEMINI_FALLBACK_MODEL
              : GEMINI_PRIMARY_MODEL;
          try {
            response = await callModel(retryModel);
          } catch (retryErr) {
            const retryInfo = extractGeminiError(retryErr);
            console.error('[AI Tutor] Retry failed:', {
              model: retryModel,
              status: retryInfo.status,
              code: retryInfo.code,
              message: retryInfo.message,
            });
            const isAuthError = retryInfo.status === 400 || retryInfo.status === 403;
            res.status(retryInfo.status >= 400 && retryInfo.status < 600 ? retryInfo.status : 502).json({
              code: isAuthError ? 'API_KEY_INVALID_OR_DENIED' : 'AI_REQUEST_FAILED',
              status: retryInfo.status,
              details: retryInfo.message,
              error: isAuthError
                ? 'تعذر التحقق من مفتاح API في إعدادات المشروع (Settings > Secrets). تأكد من صلاحية المفتاح.'
                : 'حصل مشكلة في الاتصال، دوس حاول تاني',
            });
            return;
          }
        }

        const replyText = response.text?.trim();
        if (!replyText) {
          console.error('[AI Tutor] Empty response text from Gemini API.');
          res.status(502).json({
            code: 'EMPTY_RESPONSE',
            status: 502,
            details: 'Model returned an empty text response.',
            error: 'حصل مشكلة في الاتصال، دوس حاول تاني',
          });
          return;
        }

        res.json({ text: replyText });
      } catch (err) {
        const info = extractGeminiError(err);
        console.error('[AI Tutor] Unexpected server error:', info);
        res.status(info.status >= 400 && info.status < 600 ? info.status : 500).json({
          code: 'SERVER_ERROR',
          status: info.status,
          details: info.message,
          error: 'حصل مشكلة في الاتصال، دوس حاول تاني',
        });
      }
    });
  });

  if (process.env.NODE_ENV !== 'production') {
    const vite = await import('vite');
    const viteServer = await vite.createServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(viteServer.middlewares);
  } else {
    const distDir = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Nuzakir server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
