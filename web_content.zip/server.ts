import express from 'express';
import fs from 'node:fs';
import http from 'node:http';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import dotenv from 'dotenv';
import {
  GoogleGenAI,
  Modality,
  ThinkingLevel,
  Type,
} from '@google/genai';
import type { FunctionDeclaration, LiveServerMessage } from '@google/genai';
import { WebSocketServer, WebSocket } from 'ws';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT) || 3000;

const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

function createLiveAiClient(apiVersion: 'v1beta' | 'v1alpha' = 'v1beta') {
  return new GoogleGenAI({
    apiKey: process.env.GEMINI_API_KEY,
    httpOptions: {
      apiVersion,
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

const copyToClipboardDeclaration: FunctionDeclaration = {
  name: 'copy_to_clipboard',
  description:
    'Copies clean, complete, ready-to-use code or text directly into the user clipboard. Always call this when the user asks to put, add, or copy code into their clipboard.',
  parameters: {
    type: Type.OBJECT,
    properties: {
      title: {
        type: Type.STRING,
        description: 'Short label for the snippet, e.g. "MainActivity.kt".',
      },
      language: {
        type: Type.STRING,
        description: 'Programming or markup language, e.g. "kotlin", "typescript", "python".',
      },
      code: {
        type: Type.STRING,
        description: 'The complete, clean, working code to copy to the user clipboard.',
      },
    },
    required: ['title', 'language', 'code'],
  },
};

const switchLanguageDeclaration: FunctionDeclaration = {
  name: 'switch_language',
  description:
    'Switches the spoken conversation language immediately when the user asks to speak in a specific language (such as Urdu, Hindi, Arabic, Punjabi, Pashto, Spanish, French, German, Japanese, or English). Always call this the moment the user requests a different language.',
  parameters: {
    type: Type.OBJECT,
    properties: {
      language: {
        type: Type.STRING,
        description:
          'The target language name requested by the user, e.g. "Urdu", "Hindi", "English", "Arabic", "Punjabi", "Spanish".',
      },
    },
    required: ['language'],
  },
};

const LANGUAGE_PATTERNS: Array<{ name: string; regex: RegExp }> = [
  { name: 'Roman Urdu', regex: /\broman\s*urdu\b/i },
  { name: 'Urdu', regex: /\b(urdu|اُردو|اردو)\b/i },
  { name: 'Hindi', regex: /\b(hindi|हिन्दी|हिंदी)\b/i },
  { name: 'Punjabi', regex: /\b(punjabi|پنجابی|ਪੰਜਾਬੀ)\b/i },
  { name: 'Pashto', regex: /\b(pashto|pushto|پښتو)\b/i },
  { name: 'Arabic', regex: /\b(arabic|arabi|العربية|عربي)\b/i },
  { name: 'Spanish', regex: /\b(spanish|español|espanol)\b/i },
  { name: 'French', regex: /\b(french|français|francais)\b/i },
  { name: 'German', regex: /\b(german|deutsch)\b/i },
  { name: 'Japanese', regex: /\b(japanese|nihongo)\b/i },
  { name: 'Chinese', regex: /\b(chinese|mandarin)\b/i },
  { name: 'Korean', regex: /\b(korean)\b/i },
  { name: 'Turkish', regex: /\b(turkish)\b/i },
  { name: 'Bengali', regex: /\b(bengali|bangla)\b/i },
  { name: 'English', regex: /\b(english|angrezi|angrazi)\b/i },
];

function detectLanguageSwitchRequest(text: string): string | null {
  const clean = text.trim();
  if (!clean) return null;
  const hasSwitchIntent =
    /\b(speak|talk|reply|answer|switch|change|use|baat|bat|bolo|bol|kaho|kah|zaban|zubaan|zabaan|language|mein|main|me|in|to)\b/i.test(
      clean
    ) || /[\u0600-\u06FF\u0900-\u097F]/.test(clean);

  if (!hasSwitchIntent) return null;
  for (const item of LANGUAGE_PATTERNS) {
    if (item.regex.test(clean)) {
      return item.name;
    }
  }
  return null;
}

function buildAssistantInstruction(preferredLanguage: string, mode: 'chat' | 'live' | 'workspace') {
  const base = `You are NEXCODE AI ("Build Anything. Code Everything."), a senior software architect, Android Kotlin engineer, full-stack developer, game developer, and clear coding mentor.
Supported Languages & Environments:
- HTML, CSS, JavaScript, TypeScript, Python, Java, Kotlin, C, C++, C#, PHP, SQL, Dart, XML, JSON, Lua, Swift.
- Android (Jetpack, CameraX, MediaProjection, Compose/XML), Modern Web (React, Vite, Tailwind, Three.js/WebGL), Node/Express, Databases, and Game Dev.
Engineering Standards:
- Generate COMPLETE, valid, working code with exact syntax for the requested language.
- Include filenames, explain where each file belongs, list dependencies, and provide clear run/build steps.
- NEVER leave placeholder comments like "// ... rest of implementation" or claim unimplemented code is functional.`;

  if (mode === 'live') {
    return `${base}
Voice Call Language Rules (CRITICAL):
1. Start the voice call in ${preferredLanguage || 'English'} (English first).
2. Switch language INSTANTLY when asked (Urdu, Roman Urdu, Hindi, Punjabi, Arabic, Spanish, etc.): call \`switch_language\` immediately and reply 100% in that language.
Clipboard Rule: If asked to copy a snippet during the call, call \`copy_to_clipboard\` with complete clean code.
Real-Time Screen Sharing & Fast Camera Vision Rules (CRITICAL):
- You receive continuous timestamped JPEG frames from either full-device Android Screen Sharing (WhatsApp, Roblox, Chrome, Settings, Gallery, coding apps) or live CameraX/Camera feed.
- ALWAYS base visual answers strictly on the MOST RECENT frame(s). NEVER invent or guess objects, text, buttons, or motion that are not genuinely visible in the received frames.
- For Screen Sharing: identify the active app, menus, buttons, code lines, warnings, and errors; when asked "What is showing?" describe accurately; when asked "Where should I tap?" specify exact button/menu labels and screen positions.
- For Camera Vision ("What am I showing you?", "What is this object?", "What happened when I moved my hand?"): analyze the newest frame and recent frame sequence honestly; if motion/detail is unclear, state that clearly.
- Privacy & Security: Do NOT read aloud passwords, PINs, OTPs, or payment details. If a screen looks black/protected (FLAG_SECURE) or paused, inform the user honestly.`;
  }

  if (mode === 'workspace') {
    return `${base}
Multi-File Project Builder Rules:
- Always plan the architecture cleanly, output complete multi-file structures with exact paths (e.g. "index.html", "styles.css", "app.js", or "app/src/main/java/..."), list real dependencies, and give clear run & build instructions.
- If building a web app, website, dashboard, or 3D/2D browser game, ensure "index.html" works cleanly in a browser (referencing relative CSS/JS or standard CDNs cleanly when appropriate) so live preview works out of the box.
- When fixing or refactoring existing files, preserve working parts and return complete corrected files.`;
  }

  return `${base}
Language Rule: Respond in ${preferredLanguage || 'English'} by default, switching immediately if the user requests another language.
Code & Design Craft:
- Deliver clean, well-structured, complete code inside fenced Markdown blocks with filename headers (e.g., **\`src/App.tsx\`**), setup commands, dependencies, and clear explanations.
- Image, Video, Screen & Code File Analysis: Inspect every visible line of code, UI element, or error message and clearly structure:
  1. **What This Is**
  2. **Issue / Problem Detected** (if any)
  3. **Complete Solution & Working Code**`;
}

function extractFirstCodeBlock(markdown: string): { language: string; code: string } | null {
  const match = markdown.match(/```([a-zA-Z0-9_+-]*)\n([\s\S]*?)```/);
  if (!match) return null;
  const code = match[2].trim();
  if (!code) return null;
  return {
    language: match[1]?.trim() || 'code',
    code,
  };
}

interface ChatMessageInput {
  role: 'user' | 'assistant';
  text: string;
}

interface AttachmentInput {
  mimeType: string;
  data: string;
  name?: string;
  kind?: 'image' | 'video' | 'code';
}

interface ProjectFileInput {
  path: string;
  language: string;
  content: string;
}

async function generateWithFallback(
  params: Parameters<typeof ai.models.generateContent>[0]
) {
  try {
    return await ai.models.generateContent(params);
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : String(err);
    const isQuotaOrRateLimit =
      msg.includes('429') ||
      msg.includes('RESOURCE_EXHAUSTED') ||
      msg.toLowerCase().includes('quota');
    if (isQuotaOrRateLimit && params.model !== 'gemini-3.1-flash-lite') {
      console.warn(
        `[Gemini] Quota reached on ${params.model}, falling back to gemini-3.1-flash-lite`
      );
      return await ai.models.generateContent({
        ...params,
        model: 'gemini-3.1-flash-lite',
      });
    }
    throw err;
  }
}

function formatApiError(err: unknown): { status: number; message: string } {
  const raw = err instanceof Error ? err.message : 'Unexpected server error';
  if (
    raw.includes('429') ||
    raw.includes('RESOURCE_EXHAUSTED') ||
    raw.toLowerCase().includes('quota')
  ) {
    return {
      status: 429,
      message:
        'Daily free-tier AI request limit reached. Please try again later or select a billing-enabled API key in Settings > Secrets.',
    };
  }
  if (raw.includes('API_KEY_INVALID') || raw.includes('PERMISSION_DENIED')) {
    return {
      status: 403,
      message: 'Please check your GEMINI_API_KEY in Settings > Secrets.',
    };
  }
  return { status: 500, message: raw };
}

async function createServer() {
  const app = express();
  app.use((req, res, next) => {
    res.setHeader('Permissions-Policy', 'display-capture=*, microphone=*, camera=*');
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
    if (req.method === 'OPTIONS') {
      res.status(204).end();
      return;
    }
    next();
  });
  app.use(express.json({ limit: '35mb' }));

  app.get('/api/health', (_req, res) => {
    res.json({ ok: true, service: 'nexcode-ai', version: '1.0.0' });
  });

  app.get('/nexcode-ai.html', (req, res) => {
    const standalonePath = path.resolve(__dirname, 'nexcode-ai.html');
    if (!fs.existsSync(standalonePath)) {
      res.status(404).send('Standalone HTML bundle not generated yet.');
      return;
    }
    if (req.query.download === '1') {
      res.download(standalonePath, 'nexcode-ai.html');
      return;
    }
    res.type('text/html; charset=utf-8').sendFile(standalonePath);
  });

  app.get('/export/nexcode-ai-html-export.zip', (_req, res) => {
    const zipPath = path.resolve(__dirname, 'nexcode-ai-html-export.zip');
    if (!fs.existsSync(zipPath)) {
      res.status(404).send('HTML export ZIP not found.');
      return;
    }
    res.download(zipPath, 'nexcode-ai-html-export.zip');
  });

  app.get('/export/nexcode-ai-complete-project.zip', (_req, res) => {
    const zipPath = path.resolve(__dirname, 'nexcode-ai-complete-project.zip');
    if (!fs.existsSync(zipPath)) {
      res.status(404).send('Complete project ZIP not found.');
      return;
    }
    res.download(zipPath, 'nexcode-ai-complete-project.zip');
  });

  const exportDir = path.resolve(__dirname, 'html-export');
  app.use('/export', (req, res, next) => {
    if (req.query.download === '1') {
      const reqRel = (req.path === '/' ? '/index.html' : req.path).replace(/^\/+/, '');
      const target = path.resolve(exportDir, reqRel);
      if (target.startsWith(exportDir + path.sep) && fs.existsSync(target) && fs.statSync(target).isFile()) {
        res.download(target, path.basename(target));
        return;
      }
    }
    next();
  });
  app.use('/export', express.static(exportDir));

  app.post('/api/chat', async (req, res) => {
    try {
      const {
        messages = [],
        language = 'English',
        attachment,
        screenFrame,
        projectContext,
        thinkingDepth = 'HIGH',
        autoAnalyzeMedia = false,
      } = req.body as {
        messages: ChatMessageInput[];
        language?: string;
        attachment?: AttachmentInput | null;
        screenFrame?: string | null;
        projectContext?: { name: string; files: ProjectFileInput[] } | null;
        thinkingDepth?: 'LOW' | 'HIGH';
        autoAnalyzeMedia?: boolean;
      };

      if (!process.env.GEMINI_API_KEY) {
        res.status(500).json({
          error: 'GEMINI_API_KEY is not configured. Please check Settings > Secrets.',
        });
        return;
      }

      const recentMessages = messages.slice(-14);

      const historyContents = recentMessages.map((msg, idx) => {
        const isLastUser = idx === recentMessages.length - 1 && msg.role === 'user';
        const parts: Array<Record<string, unknown>> = [];

        if (isLastUser && attachment?.data && attachment.kind !== 'code' && attachment?.mimeType) {
          parts.push({
            inlineData: {
              mimeType: attachment.mimeType,
              data: attachment.data,
            },
          });
        }

        if (isLastUser && screenFrame) {
          parts.push({
            inlineData: {
              mimeType: 'image/jpeg',
              data: screenFrame,
            },
          });
        }

        let promptText = msg.text?.trim() || '';
        if (isLastUser && attachment?.kind === 'code' && attachment.data) {
          promptText = `${promptText || 'Please review, explain, and debug this attached file.'}\n\n[Attached File: ${attachment.name || 'source'}]\n\`\`\`\n${attachment.data.slice(0, 48000)}\n\`\`\``;
        }

        if (isLastUser && projectContext?.files?.length) {
          const summary = projectContext.files
            .slice(0, 8)
            .map((f) => `- ${f.path} (${f.language}, ${f.content.split('\n').length} lines)`)
            .join('\n');
          promptText = `${promptText}\n\n[Active Workspace Project: ${projectContext.name}]\n${summary}`;
        }

        if (isLastUser && ((attachment?.data && attachment.kind !== 'code') || screenFrame)) {
          const analysisGuidance =
            'Carefully examine the attached image/video/screen. Explain (1) What this is, (2) Any errors, bugs, or issues visible, and (3) The exact suggested solution with complete working code.';
          if (autoAnalyzeMedia || !promptText) {
            promptText = analysisGuidance;
          } else {
            promptText = `${promptText}\n\n[Instruction: ${analysisGuidance}]`;
          }
        }

        parts.push({ text: promptText || 'Hello!' });

        return {
          role: msg.role === 'assistant' ? 'model' : 'user',
          parts,
        };
      });

      const systemInstruction = buildAssistantInstruction(language, 'chat');

      const response1 = await generateWithFallback({
        model: 'gemini-4-hydrogen',
        contents: historyContents,
        config: {
          systemInstruction,
          maxOutputTokens: 65536,
          thinkingConfig: {
            thinkingLevel: thinkingDepth === 'LOW' ? ThinkingLevel.LOW : ThinkingLevel.HIGH,
          },
        },
      });

      const replyText = response1.text ?? '';
      let clipboardItem: { title: string; language: string; code: string } | null = null;

      if (replyText) {
        const extracted = extractFirstCodeBlock(replyText);
        if (extracted) {
          clipboardItem = {
            title: `${extracted.language.toUpperCase()} code`,
            language: extracted.language,
            code: extracted.code,
          };
        }
      }

      let expression: 'friendly' | 'happy' | 'analyzing' | 'teaching' = 'friendly';
      if (clipboardItem) {
        expression = 'happy';
      } else if (attachment || screenFrame) {
        expression = 'analyzing';
      } else if (replyText.includes('```')) {
        expression = 'teaching';
      }

      res.json({
        reply: replyText,
        expression,
        clipboardItem,
      });
    } catch (err: unknown) {
      const formatted = formatApiError(err);
      console.error('[/api/chat] Error:', formatted.message);
      res.status(formatted.status).json({ error: formatted.message });
    }
  });

  app.post('/api/workspace/generate', async (req, res) => {
    try {
      const {
        prompt,
        existingFiles = [],
        language = 'English',
        mode = 'create',
        thinkingDepth = 'HIGH',
      } = req.body as {
        prompt: string;
        existingFiles?: ProjectFileInput[];
        language?: string;
        mode?: 'create' | 'fix' | 'refactor';
        thinkingDepth?: 'LOW' | 'HIGH';
      };

      if (!process.env.GEMINI_API_KEY) {
        res.status(500).json({
          error: 'GEMINI_API_KEY is not configured. Please check Settings > Secrets.',
        });
        return;
      }
      if (!prompt?.trim()) {
        res.status(400).json({ error: 'Prompt is required to generate or update project files.' });
        return;
      }

      const existingContext = existingFiles.length
        ? `\nExisting Project Files:\n${existingFiles
            .slice(0, 10)
            .map(
              (f) =>
                `--- FILE: ${f.path} (${f.language}) ---\n${f.content.slice(0, 12000)}`
            )
            .join('\n\n')}`
        : '';

      const userPrompt = `Mode: ${mode.toUpperCase()}\nPreferred explanation language: ${language}\nUser Request: ${prompt.trim()}${existingContext}\n\nReturn a complete multi-file project plan and full, runnable file contents without any placeholders.`;

      const result = await generateWithFallback({
        model: 'gemini-4-hydrogen',
        contents: userPrompt,
        config: {
          systemInstruction: buildAssistantInstruction(language, 'workspace'),
          maxOutputTokens: 65536,
          thinkingConfig: {
            thinkingLevel: thinkingDepth === 'LOW' ? ThinkingLevel.LOW : ThinkingLevel.HIGH,
          },
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              projectName: { type: Type.STRING },
              summary: { type: Type.STRING },
              architecturePlan: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
              },
              dependencies: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
              },
              runInstructions: { type: Type.STRING },
              buildInstructions: { type: Type.STRING },
              files: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    path: { type: Type.STRING },
                    language: { type: Type.STRING },
                    purpose: { type: Type.STRING },
                    content: { type: Type.STRING },
                  },
                  required: ['path', 'language', 'content'],
                },
              },
            },
            required: ['projectName', 'summary', 'architecturePlan', 'files'],
          },
        },
      });

      const parsed = JSON.parse((result.text ?? '{}').trim()) as {
        projectName?: string;
        summary?: string;
        architecturePlan?: string[];
        dependencies?: string[];
        runInstructions?: string;
        buildInstructions?: string;
        files?: Array<{ path: string; language: string; content: string; purpose?: string }>;
      };

      if (!parsed.files || parsed.files.length === 0) {
        throw new Error('Model returned no project files. Please try a clearer description.');
      }

      res.json({
        projectName: parsed.projectName || 'NEXCODE Project',
        summary: parsed.summary || 'Project files generated.',
        architecturePlan: parsed.architecturePlan || [],
        dependencies: parsed.dependencies || [],
        runInstructions: parsed.runInstructions || '',
        buildInstructions: parsed.buildInstructions || '',
        files: parsed.files,
      });
    } catch (err: unknown) {
      const formatted = formatApiError(err);
      console.error('[/api/workspace/generate] Error:', formatted.message);
      res.status(formatted.status).json({ error: formatted.message });
    }
  });

  const server = http.createServer(app);
  const wss = new WebSocketServer({ noServer: true });

  server.on('upgrade', (request, socket, head) => {
    const reqUrl = new URL(request.url || '/', `http://${request.headers.host}`);
    if (reqUrl.pathname === '/api/live') {
      wss.handleUpgrade(request, socket, head, (ws) => {
        wss.emit('connection', ws, request);
      });
    }
  });

  wss.on('connection', async (clientWs: WebSocket, req) => {
    const reqUrl = new URL(req.url || '/', `http://${req.headers.host || 'localhost'}`);
    let currentCallLanguage = reqUrl.searchParams.get('lang') || 'English';
    let session: Awaited<ReturnType<typeof ai.live.connect>> | null = null;
    let closed = false;
    let userTranscriptBuffer = '';
    let pendingLanguageSwitch: string | null = null;
    let visionFramesCount = 0;
    let lastVideoSentAt = 0;
    let lastAcceptedFrameTs = 0;
    let latestSource = 'none';
    let pendingLatestFrame: { data: string; mimeType: string; source: string; ts: number } | null =
      null;
    let frameFlushTimer: NodeJS.Timeout | null = null;
    let screenState: 'idle' | 'active' | 'paused' | 'stopped' = 'idle';

    const keepAliveTimer = setInterval(() => {
      if (clientWs.readyState === WebSocket.OPEN) {
        clientWs.ping();
      }
    }, 15000);

    const safeSend = (payload: Record<string, unknown>) => {
      if (clientWs.readyState === WebSocket.OPEN) {
        clientWs.send(JSON.stringify(payload));
      }
    };

    const dispatchVideoFrameToGemini = (
      base64Jpeg: string,
      mimeType = 'image/jpeg',
      source = latestSource,
      frameTs = Date.now()
    ) => {
      if (!session || closed || screenState === 'paused' || screenState === 'stopped') {
        return;
      }
      if (frameTs > 0 && frameTs < lastAcceptedFrameTs) {
        return;
      }
      lastAcceptedFrameTs = Math.max(lastAcceptedFrameTs, frameTs);
      lastVideoSentAt = Date.now();
      visionFramesCount += 1;
      session.sendRealtimeInput({
        video: { data: base64Jpeg, mimeType },
      });
      safeSend({
        type: 'visionAck',
        frameCount: visionFramesCount,
        receivedAt: lastVideoSentAt,
        frameTs: lastAcceptedFrameTs,
        source,
      });
    };

    const connectLive = async (apiVersion: 'v1beta' | 'v1alpha') => {
      const liveAi = createLiveAiClient(apiVersion);
      return liveAi.live.connect({
        model: 'gemini-3.8-live',
        config: {
          responseModalities: [Modality.AUDIO],
          inputAudioTranscription: {},
          outputAudioTranscription: {},
          speechConfig: {
            voiceConfig: {
              prebuiltVoiceConfig: { voiceName: 'Kore' },
            },
          },
          tools: [
            { functionDeclarations: [copyToClipboardDeclaration, switchLanguageDeclaration] },
          ],
          systemInstruction: buildAssistantInstruction(currentCallLanguage, 'live'),
        },
        callbacks: {
          onopen: () => {},
          onmessage: (message: LiveServerMessage) => {
            const serverContent = message.serverContent;
            if (serverContent?.inputTranscription?.text) {
              const chunk = serverContent.inputTranscription.text;
              safeSend({
                type: 'inputTranscript',
                text: chunk,
              });
              userTranscriptBuffer = `${userTranscriptBuffer} ${chunk}`.slice(-240);
              const detected = detectLanguageSwitchRequest(userTranscriptBuffer);
              if (detected && detected.toLowerCase() !== currentCallLanguage.toLowerCase()) {
                pendingLanguageSwitch = detected;
              }
            }
            if (serverContent?.outputTranscription?.text) {
              safeSend({
                type: 'outputTranscript',
                text: serverContent.outputTranscription.text,
              });
            }
            for (const part of serverContent?.modelTurn?.parts ?? []) {
              if (part.inlineData?.data) {
                safeSend({
                  type: 'audio',
                  data: part.inlineData.data,
                });
              }
            }
            if (serverContent?.interrupted) {
              safeSend({ type: 'interrupted' });
            }
            if (serverContent?.turnComplete) {
              safeSend({ type: 'turnComplete' });
              if (
                pendingLanguageSwitch &&
                pendingLanguageSwitch.toLowerCase() !== currentCallLanguage.toLowerCase()
              ) {
                const nextLang = pendingLanguageSwitch;
                pendingLanguageSwitch = null;
                userTranscriptBuffer = '';
                currentCallLanguage = nextLang;
                safeSend({ type: 'languageChanged', language: nextLang });
                session?.sendClientContent({
                  turns: [
                    {
                      role: 'user',
                      parts: [
                        {
                          text: `Please speak strictly in ${nextLang} from now on. Acknowledge briefly in ${nextLang} only.`,
                        },
                      ],
                    },
                  ],
                  turnComplete: true,
                });
              } else {
                userTranscriptBuffer = '';
              }
            }
            for (const call of message.toolCall?.functionCalls ?? []) {
              if (call.name === 'copy_to_clipboard') {
                const args = (call.args ?? {}) as Record<string, unknown>;
                const clipboardItem = {
                  title: String(args.title || 'Code Snippet'),
                  language: String(args.language || 'text'),
                  code: String(args.code || ''),
                };
                safeSend({ type: 'clipboardItem', item: clipboardItem });
                session?.sendToolResponse({
                  functionResponses: [
                    {
                      id: call.id,
                      name: call.name,
                      response: {
                        status: 'copied',
                        title: clipboardItem.title,
                      },
                    },
                  ],
                });
              } else if (call.name === 'switch_language') {
                const args = (call.args ?? {}) as Record<string, unknown>;
                const nextLang = String(args.language || 'English').trim() || 'English';
                currentCallLanguage = nextLang;
                pendingLanguageSwitch = null;
                userTranscriptBuffer = '';
                safeSend({ type: 'languageChanged', language: nextLang });
                session?.sendToolResponse({
                  functionResponses: [
                    {
                      id: call.id,
                      name: call.name,
                      response: {
                        status: 'switched',
                        language: nextLang,
                        instruction: `Language is now ${nextLang}. Speak ONLY in ${nextLang} from this moment onward.`,
                      },
                    },
                  ],
                });
              }
            }
          },
          onerror: (err: unknown) => {
            const msg =
              err instanceof Error
                ? err.message
                : typeof err === 'object' && err !== null && 'message' in err
                ? String((err as { message: unknown }).message)
                : 'Live session error';
            console.error(`[/api/live ${apiVersion}] onerror:`, msg);
            safeSend({ type: 'error', error: msg });
          },
          onclose: () => {
            if (!closed) {
              safeSend({ type: 'closed' });
            }
          },
        },
      });
    };

    try {
      try {
        session = await connectLive('v1beta');
      } catch (v1betaErr) {
        console.warn('[/api/live] v1beta connect failed, retrying v1alpha:', v1betaErr);
        session = await connectLive('v1alpha');
      }
      safeSend({ type: 'ready' });
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Could not connect to Gemini Live';
      console.error('[/api/live] Connect failed:', msg);
      safeSend({ type: 'error', error: msg });
      clientWs.close();
      return;
    }

    clientWs.on('message', async (raw) => {
      if (!session || closed) return;
      try {
        const msg = JSON.parse(raw.toString()) as {
          type: 'audio' | 'video' | 'text' | 'media' | 'set_language' | 'screen_state';
          data?: string;
          mimeType?: string;
          text?: string;
          language?: string;
          state?: 'idle' | 'active' | 'paused' | 'stopped';
          source?: string;
          ts?: number;
        };
        if (msg.type === 'audio' && msg.data) {
          session.sendRealtimeInput({
            audio: { data: msg.data, mimeType: 'audio/pcm;rate=16000' },
          });
        } else if (msg.type === 'screen_state' && msg.state) {
          screenState = msg.state;
          if (msg.source) latestSource = msg.source;
          if (msg.state === 'paused' || msg.state === 'stopped' || msg.state === 'idle') {
            pendingLatestFrame = null;
            if (frameFlushTimer) {
              clearTimeout(frameFlushTimer);
              frameFlushTimer = null;
            }
          }
          if (msg.state === 'stopped') {
            visionFramesCount = 0;
            lastAcceptedFrameTs = 0;
          }
        } else if (msg.type === 'video' && msg.data) {
          if (screenState === 'paused' || screenState === 'stopped') {
            return;
          }
          screenState = 'active';
          const source = msg.source || latestSource || 'screen';
          latestSource = source;
          const mimeType = msg.mimeType || 'image/jpeg';
          const frameTs = typeof msg.ts === 'number' ? msg.ts : Date.now();
          if (frameTs < lastAcceptedFrameTs) {
            return; // Ignore older stale frame
          }

          const now = Date.now();
          const elapsed = now - lastVideoSentAt;
          const minIntervalMs = source.includes('camera') ? 650 : 750;
          if (elapsed >= minIntervalMs) {
            pendingLatestFrame = null;
            if (frameFlushTimer) {
              clearTimeout(frameFlushTimer);
              frameFlushTimer = null;
            }
            dispatchVideoFrameToGemini(msg.data, mimeType, source, frameTs);
          } else {
            pendingLatestFrame = { data: msg.data, mimeType, source, ts: frameTs };
            if (!frameFlushTimer) {
              frameFlushTimer = setTimeout(() => {
                frameFlushTimer = null;
                if (pendingLatestFrame) {
                  const frame = pendingLatestFrame;
                  pendingLatestFrame = null;
                  dispatchVideoFrameToGemini(
                    frame.data,
                    frame.mimeType,
                    frame.source,
                    frame.ts
                  );
                }
              }, minIntervalMs - elapsed);
            }
          }
        } else if (msg.type === 'set_language' && msg.language) {
          const nextLang = msg.language.trim() || 'English';
          currentCallLanguage = nextLang;
          pendingLanguageSwitch = null;
          userTranscriptBuffer = '';
          safeSend({ type: 'languageChanged', language: nextLang });
          session.sendClientContent({
            turns: [
              {
                role: 'user',
                parts: [
                  {
                    text: `Please speak ONLY in ${nextLang} from now on. Confirm briefly in ${nextLang} that you switched to ${nextLang}.`,
                  },
                ],
              },
            ],
            turnComplete: true,
          });
        } else if (msg.type === 'text' && msg.text) {
          const detected = detectLanguageSwitchRequest(msg.text);
          if (detected) {
            currentCallLanguage = detected;
            safeSend({ type: 'languageChanged', language: detected });
          }
          session.sendClientContent({
            turns: [{ role: 'user', parts: [{ text: msg.text }] }],
            turnComplete: true,
          });
        } else if (msg.type === 'media' && msg.data && msg.mimeType) {
          if (msg.mimeType.startsWith('image/')) {
            session.sendClientContent({
              turns: [
                {
                  role: 'user',
                  parts: [
                    { inlineData: { mimeType: msg.mimeType, data: msg.data } },
                    {
                      text:
                        msg.text ||
                        'Please inspect this attached image right now: explain what it is, spot any bugs or errors, and tell me the solution.',
                    },
                  ],
                },
              ],
              turnComplete: true,
            });
          } else {
            const analysis = await generateWithFallback({
              model: 'gemini-4-hydrogen',
              contents: {
                parts: [
                  { inlineData: { mimeType: msg.mimeType, data: msg.data } },
                  {
                    text: 'Analyze this video clearly: what is shown, what issue/error occurs, and what is the exact fix?',
                  },
                ],
              },
              config: { systemInstruction: buildAssistantInstruction(currentCallLanguage, 'chat') },
            });
            const summary = analysis.text || 'I finished reviewing the attached video.';
            safeSend({ type: 'outputTranscript', text: summary });
            session.sendClientContent({
              turns: [
                {
                  role: 'user',
                  parts: [
                    {
                      text: `Here is the analysis of the video I just attached: ${summary}\nPlease explain the main issue and fix to me aloud briefly in ${currentCallLanguage}.`,
                    },
                  ],
                },
              ],
              turnComplete: true,
            });
          }
        }
      } catch (err) {
        console.error('[/api/live] Bad message:', err);
      }
    });

    clientWs.on('close', () => {
      closed = true;
      clearInterval(keepAliveTimer);
      pendingLatestFrame = null;
      if (frameFlushTimer) {
        clearTimeout(frameFlushTimer);
        frameFlushTimer = null;
      }
      try {
        session?.close();
      } catch {
        // ignore close errors
      }
    });
  });

  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  server.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running at http://localhost:${PORT}`);
  });
}

createServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
