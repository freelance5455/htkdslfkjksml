import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = parseInt(process.env.PORT || '3000', 10);

app.use(express.json());
app.use(express.static(path.resolve(__dirname, 'public')));

// Initialize Gemini Client
const apiKey = process.env.GEMINI_API_KEY || '';
const ai = new GoogleGenAI({
  apiKey: apiKey,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

// Primary model for fast, rich creative generation
const GEMINI_MODEL = process.env.GEMINI_MODEL || 'gemini-3.8-flash';

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    hasApiKey: Boolean(process.env.GEMINI_API_KEY),
    model: GEMINI_MODEL,
    time: new Date().toISOString(),
  });
});

// 1. General AI Chat
app.post('/api/chat', async (req, res) => {
  try {
    const { message, history } = req.body;
    if (!message || typeof message !== 'string' || !message.trim()) {
      return res.status(400).json({ error: 'Please enter a message.' });
    }

    if (!process.env.GEMINI_API_KEY) {
      return res.status(500).json({
        error: 'Gemini API key is not configured. Please check your Settings > Secrets panel.',
      });
    }

    const contents: any[] = [];
    if (Array.isArray(history)) {
      history.forEach((item: { role?: string; text?: string }) => {
        if (item && item.text) {
          contents.push({
            role: item.role === 'user' ? 'user' : 'model',
            parts: [{ text: item.text }],
          });
        }
      });
    }
    contents.push({ role: 'user', parts: [{ text: message.trim() }] });

    const response = await ai.models.generateContent({
      model: GEMINI_MODEL,
      contents: contents,
      config: {
        systemInstruction:
          "You are Handsome AI, a charismatic, sharp, warm, and highly capable personal assistant designed for mobile users. Provide clear, direct, and well-formatted responses with markdown formatting. You have deep cultural fluency in Chichewa and English (readily welcoming with 'Muli bwanji!', 'Zikomo kwambiri', 'Mulungu akudalitseni' when appropriate, while keeping a luxury, regal, sophisticated tone). Give insightful, polished advice and creative solutions.",
      },
    });

    res.json({ reply: response.text || 'Handsome AI has prepared your response.' });
  } catch (error: any) {
    console.error('Chat API Error:', error);
    res.status(500).json({
      error:
        error?.message ||
        'Handsome AI could not complete this request. Please verify your API key or server status.',
    });
  }
});

// 2. Music & Lyrics Creator
app.post('/api/lyrics', async (req, res) => {
  try {
    const { genre, topic, language } = req.body;
    if (!topic || typeof topic !== 'string' || !topic.trim()) {
      return res.status(400).json({ error: 'Please provide a song topic or inspiration.' });
    }

    if (!process.env.GEMINI_API_KEY) {
      return res.status(500).json({
        error: 'Gemini API key is not configured. Please check your Settings > Secrets panel.',
      });
    }

    const prompt = `Write a complete, structured musical song with chords, arrangement cues, and full lyrics.
- Chosen Style: ${genre || 'Chichewa Gospel Praise & Worship'}
- Language: ${language || 'Chichewa'}
- Song Theme/Story: ${topic}

Musical guidelines to follow:
- If Chichewa Gospel: Emulate authentic, heartfelt Malawian gospel praise and worship (reminiscent of artists like Skeffa Chimoto, Gwamba, Great Angels Choir, Kamuzu Barracks, or Marvelous Deeds). Use natural, uplifting, poetic, and spiritual Chichewa expressions. Include chord progression recommendations (e.g., I - IV - V - vi or C - F - G - Am) with guitar/piano voicing tips.
- If Amapiano: Include authentic South African / African log drum drop cues, hypnotic piano riffs, intro buildup, soulful chants, percussive timing notes, whistle/shaker cues, and bilingual party or conscious lyrics.
- If Afro-Pop / Love Song: Focus on deep romantic poetry, acoustic melodies, gentle harmonies, emotional bridges, catchy hooks, and syncopated guitar strums.
- If English Pop/R&B: Keep it radio-ready, modern, vocal arrangement layers, and billboard-chart worthy hooks.

Required output structure in clean markdown:
# Song Title
- **Style / Vibe**: ${genre}
- **Recommended Tempo**: [BPM, e.g. 112 BPM]
- **Key Signature**: [e.g. G Major / E minor]
- **Time Signature & Rhythm Feel**: [e.g. 4/4 Driving praise groove or 113 BPM Amapiano swing]
- **Suggested Chords**: [Chord progression overview]

---
[Intro]
(Arrangement notes & musical cues with chords)

[Verse 1]
(Full lyrics with chord markings above or alongside key lines)

[Chorus]
(Catchy, anthemic hook with vocal harmonies)

[Verse 2]
(Narrative continuation with emotional progression)

[Chorus]
(Full energy repeat)

[Bridge / Vocal Solo / Log Drum Breakdown]
(Dynamic climax, modulations, or instrumental breakdown)

[Chorus]
(Grand final chorus with ad-libs)

[Outro]
(Fading groove, vocal tag, final resolved chord)`;

    const response = await ai.models.generateContent({
      model: GEMINI_MODEL,
      contents: prompt,
      config: {
        systemInstruction:
          'You are a multi-platinum African music producer, songwriter, and lyricist fluent in Chichewa, English, and modern music theory. You format musical charts cleanly with chords in brackets or bold text so musicians can easily perform them.',
      },
    });

    res.json({ result: response.text });
  } catch (error: any) {
    console.error('Lyrics API Error:', error);
    res.status(500).json({
      error: error?.message || 'Failed to compose lyrics. Please try again.',
    });
  }
});

// 3. Video Story Planner
app.post('/api/video-story', async (req, res) => {
  try {
    const { concept, duration, style } = req.body;
    if (!concept || typeof concept !== 'string' || !concept.trim()) {
      return res.status(400).json({ error: 'Please enter a video concept or narrative idea.' });
    }

    if (!process.env.GEMINI_API_KEY) {
      return res.status(500).json({
        error: 'Gemini API key is not configured. Please check your Settings > Secrets panel.',
      });
    }

    const prompt = `Generate a production-ready video storyboard and scene-by-scene script.
- Core Concept: ${concept}
- Target Length: ${duration || '3 Scenes (15s Reel / TikTok)'}
- Cinematic Style: ${style || 'Cinematic 4K, 35mm anamorphic lens, warm golden hour'}

Structure the output with clean markdown:
# Project Title & Cinematic Treatment
1. **Executive Logline & Mood Overview**:
   - The central narrative hook, color grading palette, and cinematic reference.
2. **Character & Visual Profiles (For Visual Consistency)**:
   - Detailed visual tokens (e.g. skin tone, hairstyle, wardrobe textures, facial attributes, lighting contrast) to keep characters identical across AI video shots.
3. **Scene-by-Scene Breakdown**:
   For each scene, provide:
   - **Scene Number & Timing** (e.g., Scene 1: 00:00 - 00:05)
   - **Visual Action & Subject Motion**
   - **Camera Framing & Movement** (e.g., Low-angle slow dolly forward, 35mm lens, f/1.8 shallow depth of field)
   - **Lighting & Atmosphere** (e.g., Warm sunset rim lighting, soft atmospheric dust particles)
   - **Audio / Dialogue / Sound FX Cue**
   - **AI Video Generator Prompt (Ready-to-Paste for Sora / Runway Gen-3 / Kling / Pika)**:
     (Provide the exact English generation prompt enclosed in a code block for 1-click copying).
4. **Director's Editing & Pacing Advice**:
   - Recommended transition styles, aspect ratio (9:16 vertical for mobile reels or 16:9 widescreen), and color LUT recommendations.`;

    const response = await ai.models.generateContent({
      model: GEMINI_MODEL,
      contents: prompt,
      config: {
        systemInstruction:
          'You are a master cinematic director and senior prompt engineer for generative AI video tools (OpenAI Sora, Runway Gen-3 Alpha, Kling AI, Luma Dream Machine, Pika). You produce vivid, photorealistic scene descriptions with precise cinematic terminology.',
      },
    });

    res.json({ result: response.text });
  } catch (error: any) {
    console.error('Video Story Error:', error);
    res.status(500).json({
      error: error?.message || 'Failed to generate video story plan.',
    });
  }
});

// 4. Face-Safe Photo Editing Prompt Helper
app.post('/api/photo-prompt', async (req, res) => {
  try {
    const { originalSubject, requestedEdits, targetEngine } = req.body;
    if (!originalSubject || !requestedEdits) {
      return res.status(400).json({
        error: 'Please describe both the original subject and the desired edits.',
      });
    }

    if (!process.env.GEMINI_API_KEY) {
      return res.status(500).json({
        error: 'Gemini API key is not configured. Please check your Settings > Secrets panel.',
      });
    }

    const prompt = `Generate a set of photo-editing prompts that strictly preserve the subject's face identity, natural skin texture, and bone structure while applying realistic transformations.

Subject's Original Appearance: ${originalSubject}
Requested Edits (Outfit, Background, Lighting, or Pose): ${requestedEdits}
Target AI Tool: ${targetEngine || 'Midjourney Vary (Region) Inpaint'}

Provide in clean markdown:
# Face-Preservation Strategy & Prompts for ${targetEngine}

### 1. Primary Inpainting / Edit Prompt
(A high-precision prompt specifying the exact new elements like tailored clothing, luxurious surroundings, or cinematic lighting, while explicitly reinforcing facial likeness anchor words: "preserving original facial features, exact bone structure, authentic skin complexion, natural skin pores, unchanged eyes and jawline"). Provide in a copyable code block.

### 2. Strict Negative Prompt
(Excludes facial drift, uncanny plastic airbrushing, AI facial distortion, mismatched skin tone, altered eyelid folds, crooked teeth, warped hands). Provide in a copyable code block.

### 3. Masking & Inpainting Geometry
(Precise guidance on where to draw the mask: whether to exclude the face entirely, edge feathering radius, and boundary buffer around collars/hairlines).

### 4. Optimal Parameters & Engine Settings
(Exact recommended Denoising Strength / Inpainting Weight, CFG Scale, ControlNet FaceID or IP-Adapter weights, and seed consistency tips for ${targetEngine}).`;

    const response = await ai.models.generateContent({
      model: GEMINI_MODEL,
      contents: prompt,
      config: {
        systemInstruction:
          'You are an expert digital retouching director and prompt engineer specializing in face-lock inpainting and generative fill across Midjourney Vary Region, FLUX.1 Fill, Adobe Photoshop Generative Fill, and Stable Diffusion ControlNet.',
      },
    });

    res.json({ result: response.text });
  } catch (error: any) {
    console.error('Photo Prompt Error:', error);
    res.status(500).json({
      error: error?.message || 'Failed to generate photo editing prompt.',
    });
  }
});

// Vite or static files mounting
const isProduction = process.env.NODE_ENV === 'production';

if (isProduction) {
  app.use(express.static(path.resolve(__dirname, 'dist')));
  app.get('*', (req, res) => {
    res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
  });
} else {
  const { createServer } = await import('vite');
  const vite = await createServer({
    server: { middlewareMode: true },
    appType: 'spa',
  });
  app.use(vite.middlewares);
}

app.listen(port, '0.0.0.0', () => {
  console.log(`Handsome AI backend server running on http://localhost:${port}`);
});
