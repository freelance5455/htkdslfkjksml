import express, { Request, Response } from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;
const IS_PROD = process.env.NODE_ENV === 'production';

// Helper to check if a valid API key exists
function getApiKey(): string | undefined {
  const key = process.env.GEMINI_API_KEY;
  if (!key || key.trim() === '' || key === 'MY_GEMINI_API_KEY') {
    return undefined;
  }
  return key.trim();
}

// Get configured Gemini client
function getGenAI(): GoogleGenAI | null {
  const apiKey = getApiKey();
  if (!apiKey) return null;
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// Helper to get dynamically computed runtime date and time in Asia/Dhaka timezone
interface DhakaDateTimeInfo {
  iso: string;
  formattedEn: string;
  formattedBn: string;
  timeEn: string;
  timeBn: string;
  dateOnlyEn: string;
  dateOnlyBn: string;
  dayOfWeekEn: string;
  dayOfWeekBn: string;
  timezone: string;
}

function getRuntimeDhakaDateTime(): DhakaDateTimeInfo | null {
  try {
    const now = new Date();
    if (isNaN(now.getTime())) {
      return null;
    }

    const timeZone = 'Asia/Dhaka';

    const formattedEn = new Intl.DateTimeFormat('en-US', {
      timeZone,
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: 'numeric',
      minute: '2-digit',
      second: '2-digit',
      hour12: true,
    }).format(now);

    const formattedBn = new Intl.DateTimeFormat('bn-BD', {
      timeZone,
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: 'numeric',
      minute: '2-digit',
      second: '2-digit',
      hour12: true,
    }).format(now);

    const dateOnlyEn = new Intl.DateTimeFormat('en-US', {
      timeZone,
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    }).format(now);

    const dateOnlyBn = new Intl.DateTimeFormat('bn-BD', {
      timeZone,
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    }).format(now);

    const timeEn = new Intl.DateTimeFormat('en-US', {
      timeZone,
      hour: 'numeric',
      minute: '2-digit',
      hour12: true,
    }).format(now);

    const timeBn = new Intl.DateTimeFormat('bn-BD', {
      timeZone,
      hour: 'numeric',
      minute: '2-digit',
      hour12: true,
    }).format(now);

    const dayOfWeekEn = new Intl.DateTimeFormat('en-US', { timeZone, weekday: 'long' }).format(now);
    const dayOfWeekBn = new Intl.DateTimeFormat('bn-BD', { timeZone, weekday: 'long' }).format(now);

    return {
      iso: now.toISOString(),
      formattedEn,
      formattedBn,
      timeEn,
      timeBn,
      dateOnlyEn,
      dateOnlyBn,
      dayOfWeekEn,
      dayOfWeekBn,
      timezone: 'Asia/Dhaka (BST, UTC+6)',
    };
  } catch (err) {
    console.error('[JARVIS Time] Error resolving Asia/Dhaka runtime date/time:', err);
    return null;
  }
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '5mb' }));

  // Status check endpoint
  app.get('/api/status', (_req: Request, res: Response) => {
    const hasKey = Boolean(getApiKey());
    const dhakaInfo = getRuntimeDhakaDateTime();
    res.json({
      online: true,
      configured: hasKey,
      model: 'gemini-3.1-flash-lite',
      persona: 'JARVIS AI System v4.2',
      timestamp: new Date().toISOString(),
      dhakaTime: dhakaInfo ? dhakaInfo.formattedEn : null,
      timezone: 'Asia/Dhaka',
      speechReady: true,
      languages: [
        { code: 'auto', name: 'Auto-detect (Language Match)' },
        { code: 'en', name: 'English (US / UK)' },
        { code: 'bn', name: 'Bengali / বাংলা' },
        { code: 'hi', name: 'Hindi / हिन्दी' },
        { code: 'es', name: 'Spanish / Español' },
        { code: 'fr', name: 'French / Français' },
        { code: 'ar', name: 'Arabic / العربية' },
        { code: 'de', name: 'German / Deutsch' },
        { code: 'ja', name: 'Japanese / 日本語' },
      ],
    });
  });

  // Conversation chat endpoint
  app.post('/api/chat', async (req: Request, res: Response) => {
    const apiKey = getApiKey();
    if (!apiKey) {
      res.status(400).json({
        error: 'API_KEY_MISSING',
        message:
          'Gemini API key is not configured. Please add GEMINI_API_KEY to your environment or AI Studio Secrets.',
        configured: false,
      });
      return;
    }

    const {
      message,
      history = [],
      language = 'auto',
      voiceMode = true,
      userSalutation = 'Sir',
    } = req.body;

    if (!message || typeof message !== 'string' || !message.trim()) {
      res.status(400).json({ error: 'Message cannot be empty.' });
      return;
    }

    try {
      const ai = getGenAI();
      if (!ai) {
        res.status(500).json({ error: 'Failed to initialize Gemini AI client.' });
        return;
      }

      // Compute dynamic real-time clock in Asia/Dhaka timezone
      const dhakaTime = getRuntimeDhakaDateTime();
      let dateTimeContext = '';

      if (dhakaTime) {
        dateTimeContext = `
CURRENT SYSTEM RUNTIME CLOCK (TRUSTED RUNTIME SOURCE OF TRUTH):
- Timezone: Asia/Dhaka (Bangladesh Standard Time, BST / UTC+6)
- Current Date & Time (English): ${dhakaTime.formattedEn}
- Current Date (English): ${dhakaTime.dateOnlyEn}
- Current Time (English): ${dhakaTime.timeEn}
- Day of the Week (English): ${dhakaTime.dayOfWeekEn}
- Current Date & Time (Bengali): ${dhakaTime.formattedBn}
- Current Date (Bengali): ${dhakaTime.dateOnlyBn}
- Current Time (Bengali): ${dhakaTime.timeBn}
- Day of the Week (Bengali): ${dhakaTime.dayOfWeekBn}

CRITICAL RULES FOR CURRENT DATE AND TIME:
1. Always use this exact runtime date and time for all inquiries about "today", "current date", "current time", "what day is it", "আজকের তারিখ", "এখন কয়টা বাজে", "আজ কি বার", etc.
2. Under NO circumstances should you state October 23, 2024 or any other past training cutoff date. Today is strictly ${dhakaTime.dateOnlyEn} (${dhakaTime.dateOnlyBn}).
3. For date/time questions, answer accurately and directly using this trusted runtime information.`;
      } else {
        dateTimeContext = `
CURRENT SYSTEM RUNTIME CLOCK STATUS:
The runtime system clock source could not be verified. If the user asks for today's date or current time, clearly explain that the runtime system date/time could not be verified at this moment instead of guessing or providing a stale date.`;
      }

      // Build system instruction tailored to JARVIS voice persona
      let languageGuideline = '';
      if (language === 'bn') {
        languageGuideline =
          'Respond entirely in elegant, natural Bengali (Bangla - বাংলা). Address the user respectfully (e.g. স্যার / মহাশয়).';
      } else if (language === 'en') {
        languageGuideline =
          `Respond in refined British-inflected English, addressing the user as "${userSalutation}".`;
      } else if (language !== 'auto') {
        languageGuideline = `Respond naturally in the language designated by code: "${language}".`;
      } else {
        languageGuideline =
          'Detect the user\'s language and respond naturally in the exact same language (if user speaks Bangla, respond in Bangla; if English, respond in English).';
      }

      const voiceConstraints = voiceMode
        ? `Since your reply will be spoken aloud to the user:
- Keep answers concise, clear, and direct (typically 1 to 3 conversational sentences unless the user explicitly requested detailed breakdown).
- Avoid bullet points, numbered lists, markdown bold/italics symbols (***), hashtags, or code blocks in normal dialogue so that Text-To-Speech reads without stuttering.
- Use natural punctuation for speech pauses (commas, periods).`
        : 'Provide clear, structured, and helpful responses.';

      const systemInstruction = `You are J.A.R.V.I.S. (Just A Rather Very Intelligent System), the legendary, sophisticated, brilliant, loyal personal AI assistant inspired by Tony Stark\'s JARVIS.
Key Attributes:
1. Tone: Polite, calm, respectful, slightly witty, highly efficient, and deeply intelligent.
2. Form of Address: Address the user respectfully as "${userSalutation}" when appropriate.
3. Language Guidance: ${languageGuideline}
4. Audio / Voice Output Guidance: ${voiceConstraints}
5. Runtime Clock & Date Guidance: ${dateTimeContext}
6. You can answer questions, give quick facts, set verbal reminders, brainstorm ideas, analyze concepts, translate, or assist with daily tasks.
7. If the user greets you or says "Hey JARVIS", greet them back warmly and confirm all systems are online and ready for orders.`;

      // Format conversational turns for Gemini
      const formattedContents: Array<{
        role: 'user' | 'model';
        parts: Array<{ text: string }>;
      }> = [];

      // Include previous turns (last 10 turns max for prompt efficiency)
      if (Array.isArray(history)) {
        const recentHistory = history.slice(-10);
        for (const item of recentHistory) {
          if (
            item &&
            (item.role === 'user' || item.role === 'model') &&
            typeof item.text === 'string' &&
            item.text.trim()
          ) {
            formattedContents.push({
              role: item.role,
              parts: [{ text: item.text.trim() }],
            });
          }
        }
      }

      // Add current user prompt
      formattedContents.push({
        role: 'user',
        parts: [{ text: message.trim() }],
      });

      // Generate content with resilience: primary gemini-3.1-flash-lite (high quota, low latency)
      let response: any = null;
      let usedModel = 'gemini-3.1-flash-lite';
      try {
        response = await ai.models.generateContent({
          model: 'gemini-3.1-flash-lite',
          contents: formattedContents,
          config: {
            systemInstruction,
            temperature: 0.7,
            topP: 0.95,
          },
        });
      } catch (primaryErr: any) {
        console.warn('Primary model error, attempting alternate model:', primaryErr?.message);
        try {
          usedModel = 'gemini-3.8-flash';
          response = await ai.models.generateContent({
            model: 'gemini-3.8-flash',
            contents: formattedContents,
            config: {
              systemInstruction,
              temperature: 0.7,
              topP: 0.95,
            },
          });
        } catch (fallbackErr: any) {
          throw primaryErr || fallbackErr;
        }
      }

      const replyText = response?.text || 'I am ready for your command, Sir.';

      res.json({
        reply: replyText,
        model: usedModel,
        timestamp: new Date().toISOString(),
        dhakaTime: dhakaTime ? dhakaTime.formattedEn : null,
        timezone: 'Asia/Dhaka',
      });
    } catch (err: any) {
      console.error('JARVIS Chat Error:', err);
      const rawMessage = err?.message || '';

      // Gracefully handle 429 quota exhaustion so JARVIS stays polite and informative
      if (
        rawMessage.includes('429') ||
        rawMessage.includes('Quota exceeded') ||
        rawMessage.includes('RESOURCE_EXHAUSTED')
      ) {
        const isBangla = language === 'bn';
        const quotaNotice = isBangla
          ? 'স্যার, জেমিনি এপিআই-এর দৈনিক ফ্রি কোটা সাময়িকভাবে পূর্ণ হয়েছে। অনুগ্রহ করে কিছুক্ষণ পর পুনরায় চেষ্টা করুন।'
          : 'Sir, our current Gemini API allocation has reached its free tier rate limit. Please retry in a short while or update your API key in Secrets.';

        res.status(429).json({
          error: 'QUOTA_EXCEEDED',
          message: 'Gemini free tier quota limit reached.',
          reply: quotaNotice,
        });
        return;
      }

      const errorMessage =
        rawMessage || 'An unexpected disturbance occurred in the neural network.';
      res.status(500).json({
        error: 'GENAI_ERROR',
        message: errorMessage,
      });
    }
  });

  // Setup Vite middleware in dev or static files in production
  if (IS_PROD) {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  } else {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[JARVIS AI] Core operational on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('[JARVIS AI] Fatal server bootstrap failure:', err);
  process.exit(1);
});
