import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { createApiMiddleware } from './src/server/apiMiddleware';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = Number(process.env.PORT) || 3000;

// Use the API middleware
app.use(createApiMiddleware() as any);

app.use((req, res, next) => {
  res.setHeader('google-site-verification', 'googlea3746a302f7f0199.html');
  res.setHeader('X-Google-Site-Verification', 'googlea3746a302f7f0199.html');
  next();
});

// Serve static frontend files from dist
const distPath = path.resolve(__dirname, 'dist');
app.use(express.static(distPath));

app.get('/googlea3746a302f7f0199.html', (req, res) => {
  res.setHeader('Content-Type', 'text/html; charset=utf-8');
  res.send('google-site-verification: googlea3746a302f7f0199.html');
});

app.get('*', (req, res) => {
  res.sendFile(path.join(distPath, 'index.html'));
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`SK text to speech server running on http://0.0.0.0:${PORT}`);
});
