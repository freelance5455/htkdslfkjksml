# TPPS Smart Attendance — prototype

A mobile-friendly prototype for The Punjab Public High School, Nursery–Class 10.

## Included
- Import `.xlsx`, `.xls`, or `.csv` student lists
- Add students manually
- Mark Present / Absent / Leave by date and class
- Daily attendance export to Excel
- Monthly report and Excel export
- Generate parent messages and open WhatsApp or SMS app for manual sending
- Save preferences for future automatic SMS/WhatsApp notifications (provider integration is not active in this prototype)
- Browser-local storage and basic PWA files

## Important limitations
- This is a working prototype, **not yet a signed Android APK**.
- Student and attendance data is stored only in the current browser/device. Export backups regularly.
- Excel import/export uses the SheetJS library from jsDelivr, so Excel features need an internet connection. A CSV import may also require the library in this prototype.
- WhatsApp/SMS actions open a pre-filled message; a person must review and tap Send. The prototype cannot verify delivery.
- Automatic SMS requires a suitable SMS gateway/provider, account credentials, a server-side integration, budget and consent/opt-out handling.
- Automatic WhatsApp delivery requires the official WhatsApp Business Platform/Cloud API or a supported provider, business setup, approved templates where applicable, recipient opt-in and provider fees. Do not automate the consumer WhatsApp app with unofficial tools.
- The automatic-notification settings in this version only save preferences locally; they do not send automatically. For production, build a secure backend integration. Never put provider API secrets in the client app.
- Before real school use, add authentication, encrypted backups, permissions, privacy controls, and reliable cloud/device backup.

## Student Excel format
The importer tries to recognize headers. Recommended first-row headers:
`Roll No | Student Name | Class | Father Name | Parent Mobile`

Use class values such as `Nursery`, `Prep`, `1`, `2`, ... `10`. Store phone numbers as text (for example `03001234567`) so leading zeros are retained.

## Test in a browser
Open `index.html` on a computer, or serve this folder over localhost/HTTPS for installable PWA behavior. Some browser features may not work when opening the file directly.

## Build an Android APK with Capacitor (developer steps)
Prerequisites: Node.js LTS, Android Studio, Android SDK, and a Java version supported by the installed Android Gradle Plugin.

1. Create a new folder and copy `index.html`, `manifest.webmanifest`, and `sw.js` into its `www` subfolder.
2. In the project folder run:
   ```
   npm init -y
   npm install @capacitor/core @capacitor/cli @capacitor/android
   npx cap init "TPPS Smart Attendance" "pk.tpps.attendance"
   ```
3. In `capacitor.config.json`, set `"webDir": "www"`.
4. Put the web files in `www/`, then run:
   ```
   npx cap add android
   npx cap sync android
   npx cap open android
   ```
5. In Android Studio choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**. For distribution, create a signed APK using **Build > Generate Signed Bundle / APK**.
6. Install the generated APK on a test phone and test import, attendance, exports and SMS/WhatsApp handoff.

The resulting APK still needs the messaging provider integration for unattended automatic sending. A plain APK cannot send WhatsApp messages to all parents automatically just by having WhatsApp installed.
