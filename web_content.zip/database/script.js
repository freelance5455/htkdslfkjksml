/* =========================================================
   SHOPMASTER - COMPLETE JAVASCRIPT
   LocalStorage Based Shop Management System
   ========================================================= */

"use strict";

/* =========================================================
   DATABASE
   ========================================================= */

const STORAGE_KEY = "SHOPMASTER_DATABASE";

let database = {
    products: [],
    categories: [],
    customers: [],
    suppliers: [],
    sales: [],
    purchases: [],
    expenses: [],
    notifications: [],
    settings: {
        shopName: "SHOPMASTER",
        currency: "AFN",
        phone: "",
        address: "",
        darkMode: false
    }
};

let cart = [];

let editingProductId = null;
let editingCustomerId = null;
let editingSupplierId = null;


/* =========================================================
   INITIALIZE DATABASE
   ========================================================= */

function loadDatabase() {

    const saved =
        localStorage.getItem(STORAGE_KEY);

    if (saved) {

        try {

            const parsed =
                JSON.parse(saved);

            database = {
                ...database,
                ...parsed,
                settings: {
                    ...database.settings,
                    ...(parsed.settings || {})
                }
            };

        } catch (error) {

            console.error(
                "Database loading error:",
                error
            );

        }
    }

    saveDatabase();
}


/* =========================================================
   SAVE DATABASE
   ========================================================= */

function saveDatabase() {

    localStorage.setItem(
        STORAGE_KEY,
        JSON.stringify(database)
    );
}


/* =========================================================
   ID GENERATOR
   ========================================================= */

function generateId(prefix = "ID") {

    return (
        prefix +
        "-" +
        Date.now() +
        "-" +
        Math.floor(
            Math.random() * 1000
        )
    );
}


/* =========================================================
   FORMAT MONEY
   ========================================================= */

function formatMoney(value) {

    const number =
        Number(value) || 0;

    return (
        number.toLocaleString(
            "en-US",
            {
                minimumFractionDigits: 0,
                maximumFractionDigits: 2
            }
        )
        +
        " "
        +
        database.settings.currency
    );
}


/* =========================================================
   FORMAT DATE
   ========================================================= */

function formatDate(date) {

    if (!date) return "-";

    const d = new Date(date);

    if (isNaN(d.getTime())) {
        return "-";
    }

    return d.toLocaleDateString(
        "en-US",
        {
            year: "numeric",
            month: "short",
            day: "numeric"
        }
    );
}


/* =========================================================
   ESCAPE HTML
   ========================================================= */

function escapeHTML(value) {

    return String(value ?? "")
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}


/* =========================================================
   SET ELEMENT TEXT
   ========================================================= */

function setElementText(id, value) {

    const element =
        document.getElementById(id);

    if (element) {
        element.textContent = value;
    }
}


/* =========================================================
   TOAST MESSAGE
   ========================================================= */

function showToast(
    message,
    type = "success"
) {

    let toast =
        document.getElementById(
            "shopmasterToast"
        );

    if (!toast) {

        toast =
            document.createElement(
                "div"
            );

        toast.id =
            "shopmasterToast";

        toast.className =
            "toast";

        document.body.appendChild(
            toast
        );
    }

    toast.textContent =
        message;

    toast.className =
        "toast " + type;

    toast.style.display =
        "block";

    clearTimeout(
        window.toastTimer
    );

    window.toastTimer =
        setTimeout(
            () => {

                toast.style.display =
                    "none";

            },
            3000
        );
}


/* =========================================================
   MODAL FUNCTIONS
   ========================================================= */

function openModal(id) {

    const modal =
        document.getElementById(id);

    if (!modal) return;

    modal.style.display =
        "flex";

    document.body.classList.add(
        "modal-open"
    );
}


function closeModal(id) {

    const modal =
        document.getElementById(id);

    if (!modal) return;

    modal.style.display =
        "none";

    document.body.classList.remove(
        "modal-open"
    );
}


/* =========================================================
   CLOSE MODAL WHEN CLICKING OUTSIDE
   ========================================================= */

document.addEventListener(
    "click",
    function(event) {

        if (
            event.target.classList.contains(
                "modal-overlay"
            )
        ) {

            event.target.style.display =
                "none";

            document.body.classList.remove(
                "modal-open"
            );
        }
    }
);


/* =========================================================
   NAVIGATION
   ========================================================= */

function showPage(pageId) {

    document
        .querySelectorAll(".page")
        .forEach(
            page => {

                page.classList.remove(
                    "active-page"
                );

            }
        );


    const page =
        document.getElementById(
            pageId
        );


    if (!page) return;


    page.classList.add(
        "active-page"
    );


    document
        .querySelectorAll(".nav-item")
        .forEach(
            item => {

                item.classList.remove(
                    "active"
                );


                if (
                    item.dataset.page ===
                    pageId
                ) {

                    item.classList.add(
                        "active"
                    );
                }

            }
        );


    const titles = {

        dashboard: "Dashboard",
        products: "Products",
        categories: "Categories",
        pos: "Point of Sale",
        sales: "Sales",
        customers: "Customers",
        suppliers: "Suppliers",
        purchases: "Purchases",
        expenses: "Expenses",
        reports: "Reports",
        settings: "Settings"

    };


    setElementText(
        "pageTitle",
        titles[pageId] ||
        "SHOPMASTER"
    );


    const pageTitle =
        document.querySelector(
            ".page-title"
        );

    if (pageTitle) {

        pageTitle.textContent =
            titles[pageId] ||
            "SHOPMASTER";
    }


    /* Mobile sidebar */

    const sidebar =
        document.getElementById(
            "sidebar"
        );

    if (sidebar) {

        sidebar.classList.remove(
            "open"
        );
    }


    refreshCurrentPage(
        pageId
    );
}


/* =========================================================
   NAVIGATION EVENTS
   ========================================================= */

document.addEventListener(
    "click",
    function(event) {

        const navItem =
            event.target.closest(
                ".nav-item"
            );

        if (!navItem) return;

        event.preventDefault();

        showPage(
            navItem.dataset.page
        );
    }
);


/* =========================================================
   REFRESH CURRENT PAGE
   ========================================================= */

function refreshCurrentPage(
    pageId
) {

    switch (pageId) {

        case "dashboard":
            updateDashboard();
            break;

        case "products":
            renderProductsTable();
            break;

        case "categories":
            renderCategories();
            break;

        case "customers":
            renderCustomersTable();
            break;

        case "suppliers":
            renderSuppliersTable();
            break;

        case "sales":
            renderSalesTable();
            break;

        case "purchases":
            renderPurchasesTable();
            break;

        case "expenses":
            renderExpensesTable();
            break;

        case "reports":
            updateReports();
            break;

        case "pos":
            renderPOSProducts();
            renderCart();
            break;

        case "settings":
            loadSettingsForm();
            break;
    }
}


/* =========================================================
   PRODUCTS
   ========================================================= */

function addProduct(data) {

    const name =
        String(data.name || "")
            .trim();

    if (!name) {

        showToast(
            "Product name is required.",
            "error"
        );

        return;
    }


    const product = {

        id: generateId("PROD"),

        sku:
            String(
                data.sku ||
                ("SKU-" +
                Date.now())
            ).trim(),

        name,

        category:
            data.category ||
            "General",

        supplier:
            data.supplier ||
            "",

        purchasePrice:
            Number(
                data.purchasePrice
            ) || 0,

        sellingPrice:
            Number(
                data.sellingPrice
            ) || 0,

        stock:
            Number(
                data.stock
            ) || 0,

        minimumStock:
            Number(
                data.minimumStock
            ) || 5,

        unit:
            data.unit ||
            "pcs",

        date:
            new Date().toISOString()

    };


    database.products.push(
        product
    );


    saveDatabase();

    populateSelects();

    renderProductsTable();

    renderPOSProducts();

    updateDashboard();

    showToast(
        "Product added successfully."
    );
}


/* =========================================================
   UPDATE PRODUCT
   ========================================================= */

function updateProduct(
    id,
    data
) {

    const product =
        database.products.find(
            p => p.id === id
        );


    if (!product) {

        showToast(
            "Product not found.",
            "error"
        );

        return;
    }


    product.sku =
        String(
            data.sku ||
            product.sku
        ).trim();

    product.name =
        String(
            data.name ||
            product.name
        ).trim();

    product.category =
        data.category ||
        "General";

    product.supplier =
        data.supplier ||
        "";

    product.purchasePrice =
        Number(
            data.purchasePrice
        ) || 0;

    product.sellingPrice =
        Number(
            data.sellingPrice
        ) || 0;

    product.stock =
        Number(
            data.stock
        ) || 0;

    product.minimumStock =
        Number(
            data.minimumStock
        ) || 0;

    product.unit =
        data.unit ||
        "pcs";


    saveDatabase();

    populateSelects();

    renderProductsTable();

    renderPOSProducts();

    updateDashboard();

    showToast(
        "Product updated successfully."
    );
}


/* =========================================================
   EDIT PRODUCT
   ========================================================= */

function editProduct(id) {

    const product =
        database.products.find(
            p => p.id === id
        );


    if (!product) return;


    editingProductId =
        id;


    document.getElementById(
        "productSku"
    ).value =
        product.sku;


    document.getElementById(
        "productName"
    ).value =
        product.name;


    document.getElementById(
        "productCategory"
    ).value =
        product.category;


    document.getElementById(
        "productSupplier"
    ).value =
        product.supplier;


    document.getElementById(
        "purchasePrice"
    ).value =
        product.purchasePrice;


    document.getElementById(
        "sellingPrice"
    ).value =
        product.sellingPrice;


    document.getElementById(
        "productStock"
    ).value =
        product.stock;


    document.getElementById(
        "minimumStock"
    ).value =
        product.minimumStock;


    document.getElementById(
        "productUnit"
    ).value =
        product.unit;


    const title =
        document.querySelector(
            "#productModal .modal-header h3"
        );

    if (title) {
        title.textContent =
            "Edit Product";
    }


    openModal(
        "productModal"
    );
}


/* =========================================================
   DELETE PRODUCT
   ========================================================= */

function deleteProduct(id) {

    const product =
        database.products.find(
            p => p.id === id
        );


    if (!product) return;


    if (
        !confirm(
            `Delete "${product.name}"?`
        )
    ) {
        return;
    }


    database.products =
        database.products.filter(
            p => p.id !== id
        );


    saveDatabase();

    populateSelects();

    renderProductsTable();

    renderPOSProducts();

    updateDashboard();

    showToast(
        "Product deleted."
    );
}


/* =========================================================
   PRODUCT TABLE
   ========================================================= */

function renderProductsTable(
    products = database.products
) {

    const tbody =
        document.querySelector(
            "#productsTable tbody"
        );


    if (!tbody) return;


    if (products.length === 0) {

        tbody.innerHTML = `

            <tr>

                <td colspan="10">

                    <div class="empty-state">

                        <p>
                            No products found.
                        </p>

                    </div>

                </td>

            </tr>

        `;

        return;
    }


    tbody.innerHTML =
        products.map(
            product => {

                const stock =
                    Number(product.stock);

                const min =
                    Number(
                        product.minimumStock
                    );


                let status =
                    "status-success";

                let statusText =
                    "In Stock";


                if (stock <= 0) {

                    status =
                        "status-danger";

                    statusText =
                        "Out of Stock";

                } else if (
                    stock <= min
                ) {

                    status =
                        "status-warning";

                    statusText =
                        "Low Stock";
                }


                return `

                <tr>

                    <td>
                        ${escapeHTML(
                            product.sku
                        )}
                    </td>

                    <td>
                        <strong>
                            ${escapeHTML(
                                product.name
                            )}
                        </strong>
                    </td>

                    <td>
                        ${escapeHTML(
                            product.category
                        )}
                    </td>

                    <td>
                        ${formatMoney(
                            product.purchasePrice
                        )}
                    </td>

                    <td>
                        ${formatMoney(
                            product.sellingPrice
                        )}
                    </td>

                    <td>
                        <strong>
                            ${stock}
                        </strong>
                    </td>

                    <td>
                        ${escapeHTML(
                            product.unit
                        )}
                    </td>

                    <td>
                        ${formatDate(
                            product.date
                        )}
                    </td>

                    <td>

                        <span
                            class="status-badge ${status}"
                        >
                            ${statusText}
                        </span>

                    </td>

                    <td>

                        <button
                            class="secondary-button"
                            type="button"
                            onclick="editProduct('${product.id}')"
                        >
                            Edit
                        </button>

                        <button
                            class="danger-text-button"
                            type="button"
                            onclick="deleteProduct('${product.id}')"
                        >
                            Delete
                        </button>

                    </td>

                </tr>

                `;

            }
        ).join("");
}


/* =========================================================
   CATEGORIES
   ========================================================= */

function addCategory(
    name
) {

    name =
        String(name || "")
            .trim();


    if (!name) {

        showToast(
            "Category name is required.",
            "error"
        );

        return;
    }


    const exists =
        database.categories.some(
            c =>
                c.name.toLowerCase() ===
                name.toLowerCase()
        );


    if (exists) {

        showToast(
            "Category already exists.",
            "error"
        );

        return;
    }


    database.categories.push({

        id: generateId("CAT"),

        name,

        date:
            new Date().toISOString()

    });


    saveDatabase();

    populateSelects();

    renderCategories();

    showToast(
        "Category added successfully."
    );
}


/* =========================================================
   DELETE CATEGORY
   ========================================================= */

function deleteCategory(id) {

    const category =
        database.categories.find(
            c => c.id === id
        );


    if (!category) return;


    if (
        !confirm(
            `Delete category "${category.name}"?`
        )
    ) {
        return;
    }


    database.categories =
        database.categories.filter(
            c => c.id !== id
        );


    saveDatabase();

    populateSelects();

    renderCategories();

    showToast(
        "Category deleted."
    );
}


/* =========================================================
   RENDER CATEGORIES
   ========================================================= */

function renderCategories() {

    const container =
        document.getElementById(
            "categoryGrid"
        );


    if (!container) return;


    if (
        database.categories.length === 0
    ) {

        container.innerHTML = `

            <div class="dashboard-card">

                <div class="empty-state">

                    <p>
                        No categories yet.
                    </p>

                </div>

            </div>

        `;

        return;
    }


    container.innerHTML =
        database.categories
            .map(
                category => {

                    const count =
                        database.products.filter(
                            product =>
                                product.category ===
                                category.name
                        ).length;


                    return `

                    <div class="category-card">

                        <div class="report-icon">
                            📂
                        </div>

                        <h3>
                            ${escapeHTML(
                                category.name
                            )}
                        </h3>

                        <p>
                            ${count} products
                        </p>

                        <button
                            class="danger-text-button"
                            type="button"
                            onclick="deleteCategory('${category.id}')"
                        >
                            Delete
                        </button>

                    </div>

                    `;

                }
            )
            .join("");
}


/* =========================================================
   CUSTOMERS
   ========================================================= */

function addCustomer(
    data
) {

    const name =
        String(data.name || "")
            .trim();


    if (!name) {

        showToast(
            "Customer name is required.",
            "error"
        );

        return;
    }


    database.customers.push({

        id:
            generateId("CUS"),

        name,

        phone:
            data.phone || "",

        address:
            data.address || "",

        totalPurchases:
            0,

        outstanding:
            0,

        date:
            new Date().toISOString()

    });


    saveDatabase();

    populateSelects();

    renderCustomersTable();

    updateDashboard();

    showToast(
        "Customer added successfully."
    );
}


/* =========================================================
   UPDATE CUSTOMER
   ========================================================= */

function updateCustomer(
    id,
    data
) {

    const customer =
        database.customers.find(
            c => c.id === id
        );


    if (!customer) return;


    customer.name =
        data.name || "";

    customer.phone =
        data.phone || "";

    customer.address =
        data.address || "";


    saveDatabase();

    populateSelects();

    renderCustomersTable();

    showToast(
        "Customer updated."
    );
}


/* =========================================================
   EDIT CUSTOMER
   ========================================================= */

function editCustomer(id) {

    const customer =
        database.customers.find(
            c => c.id === id
        );


    if (!customer) return;


    editingCustomerId =
        id;


    document.getElementById(
        "customerName"
    ).value =
        customer.name;


    document.getElementById(
        "customerPhone"
    ).value =
        customer.phone;


    document.getElementById(
        "customerAddress"
    ).value =
        customer.address;


    openModal(
        "customerModal"
    );
}


/* =========================================================
   DELETE CUSTOMER
   ========================================================= */

function deleteCustomer(id) {

    const customer =
        database.customers.find(
            c => c.id === id
        );


    if (!customer) return;


    if (
        !confirm(
            `Delete "${customer.name}"?`
        )
    ) {
        return;
    }


    database.customers =
        database.customers.filter(
            c => c.id !== id
        );


    saveDatabase();

    populateSelects();

    renderCustomersTable();

    updateDashboard();

    showToast(
        "Customer deleted."
    );
}


/* =========================================================
   CUSTOMERS TABLE
   ========================================================= */

function renderCustomersTable(
    customers = database.customers
) {

    const tbody =
        document.querySelector(
            "#customersTable tbody"
        );


    if (!tbody) return;


    if (customers.length === 0) {

        tbody.innerHTML = `

            <tr>

                <td colspan="6">

                    <div class="empty-state">

                        <p>
                            No customers yet.
                        </p>

                    </div>

                </td>

            </tr>

        `;

        return;
    }


    tbody.innerHTML =
        customers
            .map(
                customer => `

                <tr>

                    <td>
                        <strong>
                            ${escapeHTML(
                                customer.name
                            )}
                        </strong>
                    </td>

                    <td>
                        ${escapeHTML(
                            customer.phone
                        )}
                    </td>

                    <td>
                        ${escapeHTML(
                            customer.address
                        )}
                    </td>

                    <td>
                        ${formatMoney(
                            customer.totalPurchases
                        )}
                    </td>

                    <td>

                        <span
                            class="status-badge ${
                                Number(
                                    customer.outstanding
                                ) > 0
                                    ? "status-warning"
                                    : "status-success"
                            }"
                        >
                            ${formatMoney(
                                customer.outstanding
                            )}
                        </span>

                    </td>

                    <td>

                        <button
                            class="secondary-button"
                            type="button"
                            onclick="editCustomer('${customer.id}')"
                        >
                            Edit
                        </button>

                        <button
                            class="danger-text-button"
                            type="button"
                            onclick="deleteCustomer('${customer.id}')"
                        >
                            Delete
                        </button>

                    </td>

                </tr>

                `
            )
            .join("");
}


/* =========================================================
   SUPPLIERS
   ========================================================= */

function addSupplier(
    data
) {

    const name =
        String(data.name || "")
            .trim();


    if (!name) {

        showToast(
            "Supplier name is required.",
            "error"
        );

        return;
    }


    database.suppliers.push({

        id:
            generateId("SUP"),

        name,

        company:
            data.company || "",

        phone:
            data.phone || "",

        address:
            data.address || "",

        outstanding:
            0,

        date:
            new Date().toISOString()

    });


    saveDatabase();

    populateSelects();

    renderSuppliersTable();

    updateDashboard();

    showToast(
        "Supplier added successfully."
    );
}


/* =========================================================
   UPDATE SUPPLIER
   ========================================================= */

function updateSupplier(
    id,
    data
) {

    const supplier =
        database.suppliers.find(
            s => s.id === id
        );


    if (!supplier) return;


    supplier.name =
        data.name || "";

    supplier.company =
        data.company || "";

    supplier.phone =
        data.phone || "";

    supplier.address =
        data.address || "";


    saveDatabase();

    populateSelects();

    renderSuppliersTable();

    showToast(
        "Supplier updated."
    );
}


/* =========================================================
   EDIT SUPPLIER
   ========================================================= */

function editSupplier(id) {

    const supplier =
        database.suppliers.find(
            s => s.id === id
        );


    if (!supplier) return;


    editingSupplierId =
        id;


    document.getElementById(
        "supplierName"
    ).value =
        supplier.name;


    document.getElementById(
        "supplierCompany"
    ).value =
        supplier.company;


    document.getElementById(
        "supplierPhone"
    ).value =
        supplier.phone;


    document.getElementById(
        "supplierAddress"
    ).value =
        supplier.address;


    openModal(
        "supplierModal"
    );
}


/* =========================================================
   DELETE SUPPLIER
   ========================================================= */

function deleteSupplier(id) {

    const supplier =
        database.suppliers.find(
            s => s.id === id
        );


    if (!supplier) return;


    if (
        !confirm(
            `Delete "${supplier.name}"?`
        )
    ) {
        return;
    }


    database.suppliers =
        database.suppliers.filter(
            s => s.id !== id
        );


    saveDatabase();

    populateSelects();

    renderSuppliersTable();

    updateDashboard();

    showToast(
        "Supplier deleted."
    );
}


/* =========================================================
   SUPPLIERS TABLE
   ========================================================= */

function renderSuppliersTable(
    suppliers = database.suppliers
) {

    const tbody =
        document.querySelector(
            "#suppliersTable tbody"
        );


    if (!tbody) return;


    if (suppliers.length === 0) {

        tbody.innerHTML = `

            <tr>

                <td colspan="6">

                    <div class="empty-state">

                        <p>
                            No suppliers yet.
                        </p>

                    </div>

                </td>

            </tr>

        `;

        return;
    }


    tbody.innerHTML =
        suppliers
            .map(
                supplier => `

                <tr>

                    <td>
                        <strong>
                            ${escapeHTML(
                                supplier.name
                            )}
                        </strong>
                    </td>

                    <td>
                        ${escapeHTML(
                            supplier.company
                        )}
                    </td>

                    <td>
                        ${escapeHTML(
                            supplier.phone
                        )}
                    </td>

                    <td>
                        ${escapeHTML(
                            supplier.address
                        )}
                    </td>

                    <td>
                        ${formatMoney(
                            supplier.outstanding
                        )}
                    </td>

                    <td>

                        <button
                            class="secondary-button"
                            type="button"
                            onclick="editSupplier('${supplier.id}')"
                        >
                            Edit
                        </button>

                        <button
                            class="danger-text-button"
                            type="button"
                            onclick="deleteSupplier('${supplier.id}')"
                        >
                            Delete
                        </button>

                    </td>

                </tr>

                `
            )
            .join("");
}


/* =========================================================
   PURCHASES
   ========================================================= */

function addPurchase(
    data
) {

    const product =
        database.products.find(
            p =>
                p.id ===
                data.productId
        );


    if (!product) {

        showToast(
            "Please select a product.",
            "error"
        );

        return;
    }


    const quantity =
        Number(
            data.quantity
        ) || 0;


    const price =
        Number(
            data.purchasePrice
        ) || 0;


    const paid =
        Number(
            data.paid
        ) || 0;


    if (
        quantity <= 0 ||
        price < 0
    ) {

        showToast(
            "Enter valid purchase details.",
            "error"
        );

        return;
    }


    const total =
        quantity * price;


    const due =
        Math.max(
            total - paid,
            0
        );


    product.stock =
        Number(product.stock) +
        quantity;


    product.purchasePrice =
        price;


    const purchase = {

        id:
            generateId("PUR"),

        invoice:
            "PUR-" +
            Date.now(),

        date:
            new Date().toISOString(),

        productId:
            product.id,

        product:
            product.name,

        supplierId:
            data.supplierId || "",

        supplier:
            data.supplier || "",

        quantity,

        purchasePrice:
            price,

        total,

        paid,

        due

    };


    database.purchases.push(
        purchase
    );


    if (
        data.supplierId
    ) {

        const supplier =
            database.suppliers.find(
                s =>
                    s.id ===
                    data.supplierId
            );


        if (supplier) {

            supplier.outstanding =
                Number(
                    supplier.outstanding
                ) +
                due;
        }
    }


    saveDatabase();

    populateSelects();

    renderPurchasesTable();

    renderProductsTable();

    renderPOSProducts();

    updateDashboard();

    showToast(
        "Purchase added and stock updated."
    );
}


/* =========================================================
   PURCHASE TABLE
   ========================================================= */

function renderPurchasesTable() {

    const tbody =
        document.querySelector(
            "#purchasesTable tbody"
        );


    if (!tbody) return;


    if (
        database.purchases.length === 0
    ) {

        tbody.innerHTML = `

            <tr>

                <td colspan="8">

                    <div class="empty-state">

                        <p>
                            No purchases yet.
                        </p>

                    </div>

                </td>

            </tr>

        `;

        return;
    }


    const purchases =
        database.purchases
            .slice()
            .reverse();


    tbody.innerHTML =
        purchases
            .map(
                purchase => `

                <tr>

                    <td>
                        ${escapeHTML(
                            purchase.invoice
                        )}
                    </td>

                    <td>
                        ${formatDate(
                            purchase.date
                        )}
                    </td>

                    <td>
                        ${escapeHTML(
                            purchase.product
                        )}
                    </td>

                    <td>
                        ${purchase.quantity}
                    </td>

                    <td>
                        ${formatMoney(
                            purchase.purchasePrice
                        )}
                    </td>

                    <td>
                        ${formatMoney(
                            purchase.total
                        )}
                    </td>

                    <td>
                        ${formatMoney(
                            purchase.paid
                        )}
                    </td>

                    <td>
                        ${formatMoney(
                            purchase.due
                        )}
                    </td>

                </tr>

                `
            )
            .join("");
}


/* =========================================================
   EXPENSES
   ========================================================= */

function addExpense(
    data
) {

    const title =
        String(data.title || "")
            .trim();


    const amount =
        Number(
            data.amount
        ) || 0;


    if (
        !title ||
        amount <= 0
    ) {

        showToast(
            "Enter valid expense details.",
            "error"
        );

        return;
    }


    database.expenses.push({

        id:
            generateId("EXP"),

        title,

        category:
            data.category ||
            "General",

        amount,

        date:
            data.date ||
            new Date()
                .toISOString()
                .split("T")[0],

        note:
            data.note || ""

    });


    saveDatabase();

    renderExpensesTable();

    updateDashboard();

    updateReports();

    showToast(
        "Expense added successfully."
    );
}


/* =========================================================
   DELETE EXPENSE
   ========================================================= */

function deleteExpense(id) {

    if (
        !confirm(
            "Delete this expense?"
        )
    ) {
        return;
    }


    database.expenses =
        database.expenses.filter(
            e => e.id !== id
        );


    saveDatabase();

    renderExpensesTable();

    updateDashboard();

    updateReports();

    showToast(
        "Expense deleted."
    );
}


/* =========================================================
   EXPENSE TABLE
   ========================================================= */

function renderExpensesTable() {

    const tbody =
        document.querySelector(
            "#expensesTable tbody"
        );


    if (!tbody) return;


    if (
        database.expenses.length === 0
    ) {

        tbody.innerHTML = `

            <tr>

                <td colspan="6">

                    <div class="empty-state">

                        <p>
                            No expenses yet.
                        </p>

                    </div>

                </td>

            </tr>

        `;

        return;
    }


    tbody.innerHTML =
        database.expenses
            .slice()
            .reverse()
            .map(
                expense => `

                <tr>

                    <td>
                        ${escapeHTML(
                            expense.title
                        )}
                    </td>

                    <td>
                        ${escapeHTML(
                            expense.category
                        )}
                    </td>

                    <td>
                        ${formatMoney(
                            expense.amount
                        )}
                    </td>

                    <td>
                        ${formatDate(
                            expense.date
                        )}
                    </td>

                    <td>
                        ${escapeHTML(
                            expense.note
                        )}
                    </td>

                    <td>

                        <button
                            class="danger-text-button"
                            type="button"
                            onclick="deleteExpense('${expense.id}')"
                        >
                            Delete
                        </button>

                    </td>

                </tr>

                `
            )
            .join("");
}


/* =========================================================
   POS - ADD TO CART
   ========================================================= */

function addToCart(
    productId
) {

    const product =
        database.products.find(
            p =>
                p.id ===
                productId
        );


    if (!product) return;


    if (
        Number(product.stock) <= 0
    ) {

        showToast(
            "This product is out of stock.",
            "error"
        );

        return;
    }


    const existing =
        cart.find(
            item =>
                item.productId ===
                productId
        );


    if (existing) {

        if (
            existing.quantity >=
            Number(product.stock)
        ) {

            showToast(
                "Not enough stock.",
                "error"
            );

            return;
        }


        existing.quantity++;

    } else {

        cart.push({

            productId:
                product.id,

            name:
                product.name,

            price:
                Number(
                    product.sellingPrice
                ),

            quantity:
                1

        });
    }


    renderCart();
}


/* =========================================================
   CHANGE CART QUANTITY
   ========================================================= */

function changeCartQuantity(
    productId,
    change
) {

    const item =
        cart.find(
            i =>
                i.productId ===
                productId
        );


    const product =
        database.products.find(
            p =>
                p.id ===
                productId
        );


    if (!item || !product) return;


    item.quantity +=
        Number(change);


    if (
        item.quantity <= 0
    ) {

        cart =
            cart.filter(
                i =>
                    i.productId !==
                    productId
            );

    } else if (
        item.quantity >
        Number(product.stock)
    ) {

        item.quantity =
            Number(product.stock);


        showToast(
            "Stock limit reached.",
            "error"
        );
    }


    renderCart();
}


/* =========================================================
   REMOVE CART ITEM
   ========================================================= */

function removeFromCart(
    productId
) {

    cart =
        cart.filter(
            item =>
                item.productId !==
                productId
        );


    renderCart();
}


/* =========================================================
   CART TOTAL
   ========================================================= */

function getCartSubtotal() {

    return cart.reduce(
        (
            total,
            item
        ) => {

            return total +
                (
                    Number(item.price) *
                    Number(item.quantity)
                );

        },
        0
    );
}


/* =========================================================
   UPDATE CART SUMMARY
   ========================================================= */

function updateCartSummary() {

    const subtotal =
        getCartSubtotal();


    const discount =
        Number(
            document.getElementById(
                "cartDiscount"
            )?.value
        ) || 0;


    const total =
        Math.max(
            subtotal -
            discount,
            0
        );


    setElementText(
        "cartTotal",
        formatMoney(total)
    );


    return {
        subtotal,
        discount,
        total
    };
}


/* =========================================================
   RENDER CART
   ========================================================= */

function renderCart() {

    const container =
        document.getElementById(
            "cartItems"
        );


    if (!container) return;


    if (cart.length === 0) {

        container.innerHTML = `

            <div class="empty-state">

                <p>
                    Your cart is empty.
                </p>

            </div>

        `;

        updateCartSummary();

        return;
    }


    container.innerHTML =
        cart.map(
            item => `

            <div class="cart-item">

                <div>

                    <strong>
                        ${escapeHTML(
                            item.name
                        )}
                    </strong>

                    <small>
                        ${formatMoney(
                            item.price
                        )}
                    </small>

                </div>


                <div
                    class="cart-controls"
                >

                    <button
                        type="button"
                        onclick="changeCartQuantity(
                            '${item.productId}',
                            -1
                        )"
                    >
                        −
                    </button>

                    <span>
                        ${item.quantity}
                    </span>

                    <button
                        type="button"
                        onclick="changeCartQuantity(
                            '${item.productId}',
                            1
                        )"
                    >
                        +
                    </button>

                    <button
                        type="button"
                        onclick="removeFromCart(
                            '${item.productId}'
                        )"
                    >
                        ×
                    </button>

                </div>


                <strong>
                    ${formatMoney(
                        item.price *
                        item.quantity
                    )}
                </strong>

            </div>

            `
        ).join("");


    updateCartSummary();
}


/* =========================================================
   COMPLETE SALE
   ========================================================= */

function completeSale(
    data
) {

    if (
        cart.length === 0
    ) {

        showToast(
            "Cart is empty.",
            "error"
        );

        return;
    }


    const summary =
        updateCartSummary();


    const paid =
        Number(
            data.paid
        ) || 0;


    if (
        paid < 0
    ) {

        showToast(
            "Invalid paid amount.",
            "error"
        );

        return;
    }


    if (
        paid > summary.total
    ) {

        showToast(
            "Paid amount cannot be greater than total.",
            "error"
        );

        return;
    }


    /* Check stock again */

    for (
        const item of cart
    ) {

        const product =
            database.products.find(
                p =>
                    p.id ===
                    item.productId
            );


        if (
            !product ||
            Number(product.stock) <
            Number(item.quantity)
        ) {

            showToast(
                `Not enough stock for ${item.name}.`,
                "error"
            );

            return;
        }
    }


    /* Update stock */

    cart.forEach(
        item => {

            const product =
                database.products.find(
                    p =>
                        p.id ===
                        item.productId
                );


            product.stock =
                Number(product.stock) -
                Number(item.quantity);

        }
    );


    const due =
        Math.max(
            summary.total -
            paid,
            0
        );


    const sale = {

        id:
            generateId("SALE"),

        invoice:
            "INV-" +
            Date.now(),

        date:
            new Date().toISOString(),

        customerId:
            data.customerId ||
            "",

        customer:
            data.customer ||
            "Walk-in Customer",

        items:
            JSON.parse(
                JSON.stringify(cart)
            ),

        subtotal:
            summary.subtotal,

        discount:
            summary.discount,

        total:
            summary.total,

        paid,

        due,

        paymentMethod:
            data.paymentMethod ||
            "Cash"

    };


    database.sales.push(
        sale
    );


    /* Update customer */

    if (
        data.customerId
    ) {

        const customer =
            database.customers.find(
                c =>
                    c.id ===
                    data.customerId
            );


        if (customer) {

            customer.totalPurchases =
                Number(
                    customer.totalPurchases
                ) +
                summary.total;


            customer.outstanding =
                Number(
                    customer.outstanding
                ) +
                due;
        }
    }


    saveDatabase();


    /* Reset cart */

    cart = [];


    const discountInput =
        document.getElementById(
            "cartDiscount"
        );

    if (discountInput) {
        discountInput.value = "0";
    }


    const paidInput =
        document.getElementById(
            "salePaid"
        );

    if (paidInput) {
        paidInput.value = "0";
    }


    renderCart();

    renderPOSProducts();

    populateSelects();

    renderProductsTable();

    renderSalesTable();

    updateDashboard();

    updateReports();


    showToast(
        "Sale completed successfully."
    );


    showInvoice(
        sale
    );
}


/* =========================================================
   SALES TABLE
   ========================================================= */

function renderSalesTable(
    sales = database.sales
) {

    const tbody =
        document.querySelector(
            "#salesTable tbody"
        );


    if (!tbody) return;


    if (sales.length === 0) {

        tbody.innerHTML = `

            <tr>

                <td colspan="9">

                    <div class="empty-state">

                        <p>
                            No sales yet.
                        </p>

                    </div>

                </td>

            </tr>

        `;

        return;
    }


    tbody.innerHTML =
        sales
            .slice()
            .reverse()
            .map(
                sale => `

                <tr>

                    <td>
                        <strong>
                            ${escapeHTML(
                                sale.invoice
                            )}
                        </strong>
                    </td>

                    <td>
                        ${formatDate(
                            sale.date
                        )}
                    </td>

                    <td>
                        ${escapeHTML(
                            sale.customer
                        )}
                    </td>

                    <td>
                        ${sale.items.length}
                    </td>

                    <td>
                        ${formatMoney(
                            sale.total
                        )}
                    </td>

                    <td>
                        ${formatMoney(
                            sale.paid
                        )}
                    </td>

                    <td>
                        ${formatMoney(
                            sale.due
                        )}
                    </td>

                    <td>
                        ${escapeHTML(
                            sale.paymentMethod
                        )}
                    </td>

                    <td>

                        <button
                            class="secondary-button"
                            type="button"
                            onclick="showInvoiceById('${sale.id}')"
                        >
                            Invoice
                        </button>

                    </td>

                </tr>

                `
            )
            .join("");
}


/* =========================================================
   SHOW INVOICE
   ========================================================= */

function showInvoiceById(
    saleId
) {

    const sale =
        database.sales.find(
            s =>
                s.id ===
                saleId
        );


    if (!sale) return;


    showInvoice(
        sale
    );
}


function showInvoice(
    sale
) {

    const container =
        document.getElementById(
            "invoiceContent"
        );


    if (!container) return;


    container.innerHTML = `

        <div class="invoice">

            <div class="invoice-header">

                <h2>
                    ${escapeHTML(
                        database.settings.shopName
                    )}
                </h2>

                <p>
                    ${escapeHTML(
                        database.settings.address
                    )}
                </p>

                <p>
                    ${escapeHTML(
                        database.settings.phone
                    )}
                </p>

            </div>


            <hr>


            <div>

                <strong>
                    Invoice:
                </strong>

                ${escapeHTML(
                    sale.invoice
                )}

                <br>

                <strong>
                    Date:
                </strong>

                ${formatDate(
                    sale.date
                )}

                <br>

                <strong>
                    Customer:
                </strong>

                ${escapeHTML(
                    sale.customer
                )}

            </div>


            <br>


            <table>

                <thead>

                    <tr>

                        <th>
                            Product
                        </th>

                        <th>
                            Qty
                        </th>

                        <th>
                            Price
                        </th>

                        <th>
                            Total
                        </th>

                    </tr>

                </thead>

                <tbody>

                    ${sale.items
                        .map(
                            item => `

                            <tr>

                                <td>
                                    ${escapeHTML(
                                        item.name
                                    )}
                                </td>

                                <td>
                                    ${item.quantity}
                                </td>

                                <td>
                                    ${formatMoney(
                                        item.price
                                    )}
                                </td>

                                <td>
                                    ${formatMoney(
                                        item.price *
                                        item.quantity
                                    )}
                                </td>

                            </tr>

                            `
                        )
                        .join("")}

                </tbody>

            </table>


            <br>


            <div class="invoice-total">

                <p>
                    Subtotal:
                    <strong>
                        ${formatMoney(
                            sale.subtotal
                        )}
                    </strong>
                </p>

                <p>
                    Discount:
                    <strong>
                        ${formatMoney(
                            sale.discount
                        )}
                    </strong>
                </p>

                <p>
                    Total:
                    <strong>
                        ${formatMoney(
                            sale.total
                        )}
                    </strong>
                </p>

                <p>
                    Paid:
                    <strong>
                        ${formatMoney(
                            sale.paid
                        )}
                    </strong>
                </p>

                <p>
                    Due:
                    <strong>
                        ${formatMoney(
                            sale.due
                        )}
                    </strong>
                </p>

            </div>

        </div>

    `;


    openModal(
        "invoiceModal"
    );
}


/* =========================================================
   LOW STOCK
   ========================================================= */

function getLowStockProducts() {

    return database.products.filter(
        product =>

            Number(product.stock) <=
            Number(product.minimumStock)
    );
}


/* =========================================================
   DASHBOARD
   ========================================================= */

function updateDashboard() {

    const totalSales =
        database.sales.reduce(
            (
                total,
                sale
            ) =>
                total +
                Number(sale.total),
            0
        );


    const totalPurchases =
        database.purchases.reduce(
            (
                total,
                purchase
            ) =>
                total +
                Number(purchase.total),
            0
        );


    const totalExpenses =
        database.expenses.reduce(
            (
                total,
                expense
            ) =>
                total +
                Number(expense.amount),
            0
        );


    /*
       Estimated profit:
       Sales - purchase cost of sold items - expenses
    */

    let costOfGoods =
        0;


    database.sales.forEach(
        sale => {

            sale.items.forEach(
                item => {

                    const product =
                        database.products.find(
                            p =>
                                p.id ===
                                item.productId
                        );


                    if (product) {

                        costOfGoods +=
                            Number(
                                product.purchasePrice
                            ) *
                            Number(
                                item.quantity
                            );
                    }

                }
            );

        }
    );


    const profit =
        totalSales -
        costOfGoods -
        totalExpenses;


    const lowStock =
        getLowStockProducts();


    setElementText(
        "totalSales",
        formatMoney(totalSales)
    );


    setElementText(
        "totalPurchases",
        formatMoney(
            totalPurchases
        )
    );


    setElementText(
        "totalProfit",
        formatMoney(profit)
    );


    setElementText(
        "totalProducts",
        database.products.length
    );


    setElementText(
        "lowStock",
        lowStock.length
    );


    setElementText(
        "totalCustomers",
        database.customers.length
    );


    setElementText(
        "totalSuppliers",
        database.suppliers.length
    );


    renderRecentSales();

    renderLowStockList();

    updateReports();

    updateNotifications();
}


/* =========================================================
   RECENT SALES
   ========================================================= */

function renderRecentSales() {

    const container =
        document.getElementById(
            "recentSales"
        );


    if (!container) return;


    const sales =
        database.sales
            .slice()
            .reverse()
            .slice(0, 5);


    if (sales.length === 0) {

        container.innerHTML = `

            <div class="empty-state">

                <p>
                    No sales yet.
                </p>

            </div>

        `;

        return;
    }


    container.innerHTML = `

        <table>

            <thead>

                <tr>

                    <th>
                        Invoice
                    </th>

                    <th>
                        Customer
                    </th>

                    <th>
                        Total
                    </th>

                    <th>
                        Date
                    </th>

                </tr>

            </thead>

            <tbody>

                ${sales
                    .map(
                        sale => `

                        <tr>

                            <td>
                                ${escapeHTML(
                                    sale.invoice
                                )}
                            </td>

                            <td>
                                ${escapeHTML(
                                    sale.customer
                                )}
                            </td>

                            <td>
                                ${formatMoney(
                                    sale.total
                                )}
                            </td>

                            <td>
                                ${formatDate(
                                    sale.date
                                )}
                            </td>

                        </tr>

                        `
                    )
                    .join("")}

            </tbody>

        </table>

    `;
}


/* =========================================================
   LOW STOCK LIST
   ========================================================= */

function renderLowStockList() {

    const container =
        document.getElementById(
            "lowStockList"
        );


    if (!container) return;


    const products =
        getLowStockProducts();


    if (products.length === 0) {

        container.innerHTML = `

            <div class="empty-state">

                <p>
                    No low stock products.
                </p>

            </div>

        `;

        return;
    }


    container.innerHTML =
        products
            .slice(0, 8)
            .map(
                product => `

                <div class="low-stock-item">

                    <div>

                        <strong>
                            ${escapeHTML(
                                product.name
                            )}
                        </strong>

                        <small>
                            Minimum:
                            ${product.minimumStock}
                        </small>

                    </div>

                    <span class="status-badge ${
                        Number(product.stock) <= 0
                            ? "status-danger"
                            : "status-warning"
                    }">

                        ${product.stock}

                    </span>

                </div>

                `
            )
            .join("");
}


/* =========================================================
   REPORTS
   ========================================================= */

function updateReports() {

    const totalSales =
        database.sales.reduce(
            (
                total,
                sale
            ) =>
                total +
                Number(sale.total),
            0
        );


    const totalPurchases =
        database.purchases.reduce(
            (
                total,
                purchase
            ) =>
                total +
                Number(purchase.total),
            0
        );


    const totalExpenses =
        database.expenses.reduce(
            (
                total,
                expense
            ) =>
                total +
                Number(expense.amount),
            0
        );


    const profit =
        totalSales -
        totalPurchases -
        totalExpenses;


    setElementText(
        "reportSales",
        formatMoney(totalSales)
    );


    setElementText(
        "reportPurchases",
        formatMoney(
            totalPurchases
        )
    );


    setElementText(
        "reportExpenses",
        formatMoney(
            totalExpenses
        )
    );


    setElementText(
        "reportProfit",
        formatMoney(profit)
    );


    setElementText(
        "reportProducts",
        database.products.length
    );


    setElementText(
        "reportCustomers",
        database.customers.length
    );


    setElementText(
        "reportSuppliers",
        database.suppliers.length
    );


    setElementText(
        "reportLowStock",
        getLowStockProducts().length
    );
}


/* =========================================================
   NOTIFICATIONS
   ========================================================= */

function updateNotifications() {

    const lowStock =
        getLowStockProducts();


    database.notifications =
        lowStock.map(
            product => ({

                id:
                    product.id,

                message:
                    `${product.name} has only ${product.stock} ${product.unit} left.`,

                date:
                    new Date().toISOString()

            })
        );


    saveDatabase();

    renderNotifications();
}


function renderNotifications() {

    const container =
        document.getElementById(
            "notificationList"
        );


    if (!container) return;


    const notifications =
        database.notifications;


    if (
        notifications.length === 0
    ) {

        container.innerHTML = `

            <div class="empty-state">

                <p>
                    No notifications.
                </p>

            </div>

        `;

        return;
    }


    container.innerHTML =
        notifications
            .map(
                notification => `

                <div class="notification-item">

                    <div class="notification-icon">
                        ⚠️
                    </div>

                    <div>

                        <strong>
                            Low Stock
                        </strong>

                        <p>
                            ${escapeHTML(
                                notification.message
                            )}
                        </p>

                    </div>

                </div>

                `
            )
            .join("");


    const badge =
        document.querySelector(
            ".notification-badge"
        );


    if (badge) {

        badge.textContent =
            notifications.length;

        badge.style.display =
            notifications.length
                ? "block"
                : "none";
    }
}


function markNotificationsRead() {

    const panel =
        document.getElementById(
            "notificationPanel"
        );


    if (panel) {

        panel.style.display =
            "none";
    }
}


/* =========================================================
   SETTINGS
   ========================================================= */

function loadSettingsForm() {

    const name =
        document.getElementById(
            "shopName"
        );


    const currency =
        document.getElementById(
            "shopCurrency"
        );


    const phone =
        document.getElementById(
            "shopPhone"
        );


    const address =
        document.getElementById(
            "shopAddress"
        );


    if (name) {
        name.value =
            database.settings.shopName;
    }


    if (currency) {
        currency.value =
            database.settings.currency;
    }


    if (phone) {
        phone.value =
            database.settings.phone;
    }


    if (address) {
        address.value =
            database.settings.address;
    }
}


/* =========================================================
   UPDATE SETTINGS
   ========================================================= */

function updateSettings(
    data
) {

    database.settings.shopName =
        data.shopName ||
        "SHOPMASTER";


    database.settings.currency =
        data.currency ||
        "AFN";


    database.settings.phone =
        data.phone ||
        "";


    database.settings.address =
        data.address ||
        "";


    saveDatabase();

    updateShopName();

    updateDashboard();

    showToast(
        "Settings saved successfully."
    );
}


/* =========================================================
   UPDATE SHOP NAME
   ========================================================= */

function updateShopName() {

    document
        .querySelectorAll(
            "[data-shop-name]"
        )
        .forEach(
            element => {

                element.textContent =
                    database.settings.shopName;

            }
        );
}


/* =========================================================
   DARK MODE
   ========================================================= */

function toggleTheme() {

    database.settings.darkMode =
        !database.settings.darkMode;


    document.body.classList.toggle(
        "dark-mode",
        database.settings.darkMode
    );


    saveDatabase();
}


/* =========================================================
   APPLY THEME
   ========================================================= */

function applyTheme() {

    document.body.classList.toggle(
        "dark-mode",
        Boolean(
            database.settings.darkMode
        )
    );
}


/* =========================================================
   GLOBAL SEARCH
   ========================================================= */

function globalSearch(
    keyword
) {

    keyword =
        String(keyword || "")
            .toLowerCase()
            .trim();


    if (!keyword) return;


    const product =
        database.products.find(
            p =>
                p.name
                    .toLowerCase()
                    .includes(keyword)

                ||

                p.sku
                    .toLowerCase()
                    .includes(keyword)
        );


    if (product) {

        showPage(
            "products"
        );


        const input =
            document.getElementById(
                "productSearch"
            );


        if (input) {

            input.value =
                keyword;

            input.dispatchEvent(
                new Event(
                    "input"
                )
            );
        }

        return;
    }


    const customer =
        database.customers.find(
            c =>
                c.name
                    .toLowerCase()
                    .includes(keyword)

                ||

                c.phone
                    .toLowerCase()
                    .includes(keyword)
        );


    if (customer) {

        showPage(
            "customers"
        );

        const input =
            document.getElementById(
                "customerSearch"
            );


        if (input) {

            input.value =
                keyword;

            input.dispatchEvent(
                new Event(
                    "input"
                )
            );
        }

        return;
    }


    showToast(
        "No matching record found.",
        "error"
    );
}


/* =========================================================
   PRODUCT SEARCH
   ========================================================= */

function setupSearchEvents() {

    const productSearch =
        document.getElementById(
            "productSearch"
        );


    if (productSearch) {

        productSearch.addEventListener(
            "input",
            function() {

                const keyword =
                    this.value
                        .toLowerCase()
                        .trim();


                const category =
                    document.getElementById(
                        "productCategoryFilter"
                    )?.value || "";


                const stockFilter =
                    document.getElementById(
                        "productStockFilter"
                    )?.value || "";


                const filtered =
                    database.products.filter(
                        product => {

                            const matchesSearch =
                                !keyword ||

                                product.name
                                    .toLowerCase()
                                    .includes(
                                        keyword
                                    )

                                ||

                                product.sku
                                    .toLowerCase()
                                    .includes(
                                        keyword
                                    );


                            const matchesCategory =
                                !category ||
                                product.category ===
                                category;


                            let matchesStock =
                                true;


                            if (
                                stockFilter ===
                                "in"
                            ) {

                                matchesStock =
                                    Number(
                                        product.stock
                                    ) > 0;

                            } else if (
                                stockFilter ===
                                "low"
                            ) {

                                matchesStock =
                                    Number(
                                        product.stock
                                    ) > 0 &&
                                    Number(
                                        product.stock
                                    ) <=
                                    Number(
                                        product.minimumStock
                                    );

                            } else if (
                                stockFilter ===
                                "out"
                            ) {

                                matchesStock =
                                    Number(
                                        product.stock
                                    ) <= 0;
                            }


                            return (
                                matchesSearch &&
                                matchesCategory &&
                                matchesStock
                            );
                        }
                    );


                renderProductsTable(
                    filtered
                );
            }
        );
    }


    const categoryFilter =
        document.getElementById(
            "productCategoryFilter"
        );


    if (categoryFilter) {

        categoryFilter.addEventListener(
            "change",
            function() {

                if (productSearch) {

                    productSearch.dispatchEvent(
                        new Event(
                            "input"
                        )
                    );
                }

            }
        );
    }


    const stockFilter =
        document.getElementById(
            "productStockFilter"
        );


    if (stockFilter) {

        stockFilter.addEventListener(
            "change",
            function() {

                if (productSearch) {

                    productSearch.dispatchEvent(
                        new Event(
                            "input"
                        )
                    );
                }

            }
        );
    }


    const customerSearch =
        document.getElementById(
            "customerSearch"
        );


    if (customerSearch) {

        customerSearch.addEventListener(
            "input",
            function() {

                const keyword =
                    this.value
                        .toLowerCase()
                        .trim();


                const filtered =
                    database.customers.filter(
                        customer =>

                            customer.name
                                .toLowerCase()
                                .includes(
                                    keyword
                                )

                            ||

                            customer.phone
                                .toLowerCase()
                                .includes(
                                    keyword
                                )
                    );


                renderCustomersTable(
                    filtered
                );
            }
        );
    }


    const supplierSearch =
        document.getElementById(
            "supplierSearch"
        );


    if (supplierSearch) {

        supplierSearch.addEventListener(
            "input",
            function() {

                const keyword =
                    this.value
                        .toLowerCase()
                        .trim();


                const filtered =
                    database.suppliers.filter(
                        supplier =>

                            supplier.name
                                .toLowerCase()
                                .includes(
                                    keyword
                                )

                            ||

                            supplier.company
                                .toLowerCase()
                                .includes(
                                    keyword
                                )

                            ||

                            supplier.phone
                                .toLowerCase()
                                .includes(
                                    keyword
                                )
                    );


                renderSuppliersTable(
                    filtered
                );
            }
        );
    }


    const salesSearch =
        document.getElementById(
            "salesSearch"
        );


    if (salesSearch) {

        salesSearch.addEventListener(
            "input",
            function() {

                const keyword =
                    this.value
                        .toLowerCase()
                        .trim();


                const filtered =
                    database.sales.filter(
                        sale =>

                            sale.invoice
                                .toLowerCase()
                                .includes(
                                    keyword
                                )

                            ||

                            sale.customer
                                .toLowerCase()
                                .includes(
                                    keyword
                                )
                    );


                renderSalesTable(
                    filtered
                );
            }
        );
    }


    const globalSearchInput =
        document.getElementById(
            "globalSearch"
        );


    if (globalSearchInput) {

        globalSearchInput.addEventListener(
            "keydown",
            function(event) {

                if (
                    event.key ===
                    "Enter"
                ) {

                    globalSearch(
                        this.value
                    );
                }
            }
        );
    }


    const posSearch =
        document.getElementById(
            "posSearch"
        );


    if (posSearch) {

        posSearch.addEventListener(
            "input",
            function() {

                renderPOSProducts(
                    this.value
                );
            }
        );
    }
}


/* =========================================================
   EXPORT PRODUCTS CSV
   ========================================================= */

function exportProductsCSV() {

    if (
        database.products.length === 0
    ) {

        showToast(
            "No products to export.",
            "error"
        );

        return;
    }


    const headers = [

        "SKU",
        "Name",
        "Category",
        "Supplier",
        "Purchase Price",
        "Selling Price",
        "Stock",
        "Minimum Stock",
        "Unit",
        "Date"

    ];


    const rows =
        database.products.map(
            product => [

                product.sku,
                product.name,
                product.category,
                product.supplier,
                product.purchasePrice,
                product.sellingPrice,
                product.stock,
                product.minimumStock,
                product.unit,
                product.date

            ]
        );


    const csv =
        [
            headers,
            ...rows
        ]
        .map(
            row =>
                row
                    .map(
                        value =>
                            `"${String(
                                value ?? ""
                            ).replaceAll(
                                '"',
                                '""'
                            )}"`
                    )
                    .join(",")
        )
        .join("\n");


    downloadFile(
        csv,
        "shopmaster-products.csv",
        "text/csv"
    );
}


/* =========================================================
   BACKUP DATABASE
   ========================================================= */

function backupDatabase() {

    const json =
        JSON.stringify(
            database,
            null,
            2
        );


    downloadFile(
        json,
        "shopmaster-backup.json",
        "application/json"
    );


    showToast(
        "Database backup created."
    );
}


/* =========================================================
   RESTORE DATABASE
   ========================================================= */

function restoreDatabase(
    file
) {

    if (!file) return;


    const reader =
        new FileReader();


    reader.onload =
        function(event) {

            try {

                const data =
                    JSON.parse(
                        event.target.result
                    );


                if (
                    !data.products ||
                    !data.sales ||
                    !data.customers
                ) {

                    throw new Error(
                        "Invalid backup file"
                    );
                }


                if (
                    !confirm(
                        "Restore this backup? Current data will be replaced."
                    )
                ) {
                    return;
                }


                database = {

                    ...database,

                    ...data,

                    settings: {

                        ...database.settings,

                        ...(data.settings || {})

                    }

                };


                saveDatabase();

                populateSelects();

                updateShopName();

                updateDashboard();

                renderProductsTable();

                renderCustomersTable();

                renderSuppliersTable();

                renderSalesTable();

                renderPurchasesTable();

                renderExpensesTable();

                renderCategories();

                renderPOSProducts();

                loadSettingsForm();


                showToast(
                    "Database restored successfully."
                );

            } catch (error) {

                console.error(
                    error
                );

                showToast(
                    "Invalid backup file.",
                    "error"
                );
            }

        };


    reader.readAsText(
        file
    );
}


/* =========================================================
   DOWNLOAD FILE
   ========================================================= */

function downloadFile(
    content,
    filename,
    type
) {

    const blob =
        new Blob(
            [content],
            {
                type
            }
        );


    const url =
        URL.createObjectURL(
            blob
        );


    const link =
        document.createElement(
            "a"
        );


    link.href =
        url;

    link.download =
        filename;


    document.body.appendChild(
        link
    );


    link.click();


    link.remove();


    URL.revokeObjectURL(
        url
    );
}


/* =========================================================
   RESET DATABASE
   ========================================================= */

function resetDatabase() {

    const answer =
        prompt(
            'Type "DELETE" to permanently clear the database.'
        );


    if (
        answer !==
        "DELETE"
    ) {
        return;
    }


    localStorage.removeItem(
        STORAGE_KEY
    );


    location.reload();
}


/* =========================================================
   POPULATE SELECTS
   ========================================================= */

function populateSelects() {

    /* Categories */

    const categorySelect =
        document.getElementById(
            "productCategory"
        );


    if (categorySelect) {

        categorySelect.innerHTML = `

            <option value="General">
                General
            </option>

        `;


        database.categories.forEach(
            category => {

                const option =
                    document.createElement(
                        "option"
                    );

                option.value =
                    category.name;

                option.textContent =
                    category.name;

                categorySelect.appendChild(
                    option
                );
            }
        );
    }


    /* Category Filter */

    const categoryFilter =
        document.getElementById(
            "productCategoryFilter"
        );


    if (categoryFilter) {

        categoryFilter.innerHTML = `

            <option value="">
                All Categories
            </option>

        `;


        database.categories.forEach(
            category => {

                const option =
                    document.createElement(
                        "option"
                    );

                option.value =
                    category.name;

                option.textContent =
                    category.name;

                categoryFilter.appendChild(
                    option
                );
            }
        );
    }


    /* Product Supplier */

    const productSupplier =
        document.getElementById(
            "productSupplier"
        );


    if (productSupplier) {

        productSupplier.innerHTML = `

            <option value="">
                No Supplier
            </option>

        `;


        database.suppliers.forEach(
            supplier => {

                const option =
                    document.createElement(
                        "option"
                    );

                option.value =
                    supplier.name;

                option.textContent =
                    supplier.name;

                productSupplier.appendChild(
                    option
                );
            }
        );
    }


    /* Purchase Product */

    const purchaseProduct =
        document.getElementById(
            "purchaseProduct"
        );


    if (purchaseProduct) {

        purchaseProduct.innerHTML = `

            <option value="">
                Select Product
            </option>

        `;


        database.products.forEach(
            product => {

                const option =
                    document.createElement(
                        "option"
                    );

                option.value =
                    product.id;

                option.textContent =
                    `${product.name} - ${product.sku}`;

                purchaseProduct.appendChild(
                    option
                );
            }
        );
    }


    /* Purchase Supplier */

    const purchaseSupplier =
        document.getElementById(
            "purchaseSupplier"
        );


    if (purchaseSupplier) {

        purchaseSupplier.innerHTML = `

            <option value="">
                Select Supplier
            </option>

        `;


        database.suppliers.forEach(
            supplier => {

                const option =
                    document.createElement(
                        "option"
                    );

                option.value =
                    supplier.id;

                option.textContent =
                    supplier.name;

                purchaseSupplier.appendChild(
                    option
                );
            }
        );
    }


    /* Sale Customer */

    const saleCustomer =
        document.getElementById(
            "saleCustomer"
        );


    if (saleCustomer) {

        saleCustomer.innerHTML = `

            <option value="">
                Walk-in Customer
            </option>

        `;


        database.customers.forEach(
            customer => {

                const option =
                    document.createElement(
                        "option"
                    );

                option.value =
                    customer.id;

                option.textContent =
                    customer.name;

                saleCustomer.appendChild(
                    option
                );
            }
        );
    }
}


/* =========================================================
   POS PRODUCT RENDER
   ========================================================= */

function renderPOSProducts(
    keyword = ""
) {

    const container =
        document.getElementById(
            "posProductGrid"
        );


    if (!container) return;


    keyword =
        String(keyword || "")
            .toLowerCase()
            .trim();


    const products =
        database.products.filter(
            product => {

                if (!keyword) {
                    return true;
                }


                return (

                    product.name
                        .toLowerCase()
                        .includes(
                            keyword
                        )

                    ||

                    product.sku
                        .toLowerCase()
                        .includes(
                            keyword
                        )

                    ||

                    product.category
                        .toLowerCase()
                        .includes(
                            keyword
                        )

                );
            }
        );


    if (products.length === 0) {

        container.innerHTML = `

            <div class="empty-state">

                <p>
                    No products found.
                </p>

            </div>

        `;

        return;
    }


    container.innerHTML =
        products.map(
            product => `

            <button
                type="button"
                class="pos-product"
                onclick="addToCart('${product.id}')"
                ${
                    Number(product.stock) <= 0
                        ? "disabled"
                        : ""
                }
            >

                <strong>
                    ${escapeHTML(
                        product.name
                    )}
                </strong>

                <span>
                    ${formatMoney(
                        product.sellingPrice
                    )}
                </span>

                <small>
                    Stock:
                    ${product.stock}
                </small>

            </button>

            `
        ).join("");
}


/* =========================================================
   INITIALIZE
   ========================================================= */

document.addEventListener(
    "DOMContentLoaded",
    function() {

        loadDatabase();

        applyTheme();

        updateShopName();

        populateSelects();

        setupSearchEvents();

        updateDashboard();

        renderProductsTable();

        renderCategories();

        renderCustomersTable();

        renderSuppliersTable();

        renderSalesTable();

        renderPurchasesTable();

        renderExpensesTable();

        renderPOSProducts();

        renderCart();

        loadSettingsForm();

        updateReports();

        renderNotifications();


        /* Today's date */

        const dashboardDate =
            document.getElementById(
                "dashboardDate"
            );


        if (dashboardDate) {

            dashboardDate.textContent =
                new Date().toLocaleDateString(
                    "en-US",
                    {
                        weekday: "long",
                        year: "numeric",
                        month: "long",
                        day: "numeric"
                    }
                );
        }


        /* Theme button */

        const themeButton =
            document.getElementById(
                "themeButton"
            );


        if (themeButton) {

            themeButton.onclick =
                toggleTheme;
        }


        /* Product modal */

        const productForm =
            document.getElementById(
                "productForm"
            );


        if (productForm) {

            productForm.addEventListener(
                "submit",
                function(event) {

                    event.preventDefault();


                    const data = {

                        sku:
                            document.getElementById(
                                "productSku"
                            ).value,

                        name:
                            document.getElementById(
                                "productName"
                            ).value,

                        category:
                            document.getElementById(
                                "productCategory"
                            ).value,

                        supplier:
                            document.getElementById(
                                "productSupplier"
                            ).value,

                        purchasePrice:
                            document.getElementById(
                                "purchasePrice"
                            ).value,

                        sellingPrice:
                            document.getElementById(
                                "sellingPrice"
                            ).value,

                        stock:
                            document.getElementById(
                                "productStock"
                            ).value,

                        minimumStock:
                            document.getElementById(
                                "minimumStock"
                            ).value,

                        unit:
                            document.getElementById(
                                "productUnit"
                            ).value

                    };


                    if (
                        editingProductId
                    ) {

                        updateProduct(
                            editingProductId,
                            data
                        );

                    } else {

                        addProduct(
                            data
                        );
                    }


                    closeModal(
                        "productModal"
                    );


                    productForm.reset();

                    editingProductId =
                        null;


                    const title =
                        document.querySelector(
                            "#productModal .modal-header h3"
                        );

                    if (title) {

                        title.textContent =
                            "Add Product";
                    }

                }
            );
        }


        /* Customer form */

        const customerForm =
            document.getElementById(
                "customerForm"
            );


        if (customerForm) {

            customerForm.addEventListener(
                "submit",
                function(event) {

                    event.preventDefault();


                    const data = {

                        name:
                            document.getElementById(
                                "customerName"
                            ).value,

                        phone:
                            document.getElementById(
                                "customerPhone"
                            ).value,

                        address:
                            document.getElementById(
                                "customerAddress"
                            ).value

                    };


                    if (
                        editingCustomerId
                    ) {

                        updateCustomer(
                            editingCustomerId,
                            data
                        );

                    } else {

                        addCustomer(
                            data
                        );
                    }


                    closeModal(
                        "customerModal"
                    );


                    customerForm.reset();

                    editingCustomerId =
                        null;
                }
            );
        }


        /* Supplier form */

        const supplierForm =
            document.getElementById(
                "supplierForm"
            );


        if (supplierForm) {

            supplierForm.addEventListener(
                "submit",
                function(event) {

                    event.preventDefault();


                    const data = {

                        name:
                            document.getElementById(
                                "supplierName"
                            ).value,

                        company:
                            document.getElementById(
                                "supplierCompany"
                            ).value,

                        phone:
                            document.getElementById(
                                "supplierPhone"
                            ).value,

                        address:
                            document.getElementById(
                                "supplierAddress"
                            ).value

                    };


                    if (
                        editingSupplierId
                    ) {

                        updateSupplier(
                            editingSupplierId,
                            data
                        );

                    } else {

                        addSupplier(
                            data
                        );
                    }


                    closeModal(
                        "supplierModal"
                    );


                    supplierForm.reset();

                    editingSupplierId =
                        null;
                }
            );
        }


        /* Category form */

        const categoryForm =
            document.getElementById(
                "categoryForm"
            );


        if (categoryForm) {

            categoryForm.addEventListener(
                "submit",
                function(event) {

                    event.preventDefault();


                    addCategory(
                        document.getElementById(
                            "categoryName"
                        ).value
                    );


                    closeModal(
                        "categoryModal"
                    );


                    categoryForm.reset();
                }
            );
        }


        /* Purchase form */

        const purchaseForm =
            document.getElementById(
                "purchaseForm"
            );


        if (purchaseForm) {

            purchaseForm.addEventListener(
                "submit",
                function(event) {

                    event.preventDefault();


                    const supplierSelect =
                        document.getElementById(
                            "purchaseSupplier"
                        );


                    addPurchase({

                        productId:
                            document.getElementById(
                                "purchaseProduct"
                            ).value,

                        supplierId:
                            supplierSelect.value,

                        supplier:
                            supplierSelect
                                .selectedOptions[0]
                                ?.textContent ||
                            "",

                        quantity:
                            document.getElementById(
                                "purchaseQuantity"
                            ).value,

                        purchasePrice:
                            document.getElementById(
                                "purchasePrice"
                            ).value,

                        paid:
                            document.getElementById(
                                "purchasePaid"
                            ).value

                    });


                    closeModal(
                        "purchaseModal"
                    );


                    purchaseForm.reset();
                }
            );
        }


        /* Expense form */

        const expenseForm =
            document.getElementById(
                "expenseForm"
            );


        if (expenseForm) {

            expenseForm.addEventListener(
                "submit",
                function(event) {

                    event.preventDefault();


                    addExpense({

                        title:
                            document.getElementById(
                                "expenseTitle"
                            ).value,

                        category:
                            document.getElementById(
                                "expenseCategory"
                            ).value,

                        amount:
                            document.getElementById(
                                "expenseAmount"
                            ).value,

                        date:
                            document.getElementById(
                                "expenseDate"
                            ).value,

                        note:
                            document.getElementById(
                                "expenseNote"
                            ).value

                    });


                    closeModal(
                        "expenseModal"
                    );


                    expenseForm.reset();
                }
            );
        }


        /* Settings form */

        const settingsForm =
            document.getElementById(
                "settingsForm"
            );


        if (settingsForm) {

            settingsForm.addEventListener(
                "submit",
                function(event) {

                    event.preventDefault();


                    updateSettings({

                        shopName:
                            document.getElementById(
                                "shopName"
                            ).value,

                        currency:
                            document.getElementById(
                                "shopCurrency"
                            ).value,

                        phone:
                            document.getElementById(
                                "shopPhone"
                            ).value,

                        address:
                            document.getElementById(
                                "shopAddress"
                            ).value

                    });

                }
            );
        }


        /* Complete sale */

        const completeSaleButton =
            document.getElementById(
                "completeSaleButton"
            );


        if (completeSaleButton) {

            completeSaleButton.addEventListener(
                "click",
                function() {

                    const customer =
                        document.getElementById(
                            "saleCustomer"
                        );


                    const payment =
                        document.getElementById(
                            "salePaymentMethod"
                        );


                    completeSale({

                        customerId:
                            customer.value,

                        customer:
                            customer
                                .selectedOptions[0]
                                ?.textContent ||
                            "Walk-in Customer",

                        discount:
                            document.getElementById(
                                "cartDiscount"
                            ).value,

                        paid:
                            document.getElementById(
                                "salePaid"
                            ).value,

                        paymentMethod:
                            payment.value

                    });

                }
            );
        }


        /* Cart discount */

        const discount =
            document.getElementById(
                "cartDiscount"
            );


        if (discount) {

            discount.addEventListener(
                "input",
                updateCartSummary
            );
        }


        /* Modal close buttons */

        document
            .querySelectorAll(
                ".modal-close, .modal-cancel"
            )
            .forEach(
                button => {

                    button.addEventListener(
                        "click",
                        function() {

                            const modal =
                                this.closest(
                                    ".modal-overlay"
                                );


                            if (modal) {

                                closeModal(
                                    modal.id
                                );
                            }

                        }
                    );
                }
            );


        /* Mobile menu */

        const menuButton =
            document.getElementById(
                "menuButton"
            );


        if (menuButton) {

            menuButton.addEventListener(
                "click",
                function() {

                    const sidebar =
                        document.getElementById(
                            "sidebar"
                        );


                    if (sidebar) {

                        sidebar.classList.toggle(
                            "open"
                        );
                    }

                }
            );
        }


        /* Notifications */

        const notificationButton =
            document.getElementById(
                "notificationButton"
            );


        if (notificationButton) {

            notificationButton.addEventListener(
                "click",
                function() {

                    const panel =
                        document.getElementById(
                            "notificationPanel"
                        );


                    if (!panel) return;


                    panel.style.display =
                        panel.style.display ===
                        "block"
                            ? "none"
                            : "block";

                }
            );
        }


        /* Restore database */

        const restoreFile =
            document.getElementById(
                "restoreFile"
            );


        if (restoreFile) {

            restoreFile.addEventListener(
                "change",
                function() {

                    if (
                        this.files &&
                        this.files[0]
                    ) {

                        restoreDatabase(
                            this.files[0]
                        );
                    }

                }
            );
        }


        /* Default date */

        const expenseDate =
            document.getElementById(
                "expenseDate"
            );


        if (expenseDate) {

            expenseDate.value =
                new Date()
                    .toISOString()
                    .split("T")[0];
        }

    }
);


const menuButton = document.getElementById("menuButton");
const sidebar = document.getElementById("sidebar");

if (menuButton && sidebar) {
    menuButton.addEventListener("click", function () {
        sidebar.classList.toggle("open");
    });
}