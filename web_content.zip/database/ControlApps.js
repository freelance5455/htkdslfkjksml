module.exports = {
  tokens: "8484373558:AAEG3ZkEe5TX7jtrQiIJPHC2GLGbo2k7HLg", 
  owner: "6571173959", 
  port: "4000", // Ini Wajib Jangan Diubah
  ipvps: "http://tzyngentotcrot.hostingercloud.my.id" // Jangan Diubah Nanti Eror!!
};