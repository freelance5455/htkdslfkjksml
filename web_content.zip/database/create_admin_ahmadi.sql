INSERT INTO admins (email, password_hash) VALUES ('ahmadi', '$2y$12$UCnISwJdmQQ6au6fIR2td.DefnXfDFQxt4n3MYq.laBorKh0zKJZG')
ON DUPLICATE KEY UPDATE password_hash = VALUES(password_hash);
