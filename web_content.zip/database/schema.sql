create table if not exists devices (
 id uuid primary key default gen_random_uuid(),
 user_id uuid,
 device_name text not null,
 platform text not null default 'android',
 device_identifier text not null unique,
 authorized boolean not null default false,
 created_at timestamptz not null default now(),
 updated_at timestamptz not null default now()
);
create table if not exists commands (
 id uuid primary key default gen_random_uuid(),
 user_id uuid,
 device_id uuid references devices(id) on delete set null,
 command text not null,
 status text not null default 'received',
 result text,
 created_at timestamptz not null default now(),
 completed_at timestamptz
);
create table if not exists activity_logs (
 id uuid primary key default gen_random_uuid(),
 user_id uuid,
 device_id uuid references devices(id) on delete set null,
 action text not null,
 details jsonb,
 created_at timestamptz not null default now()
);