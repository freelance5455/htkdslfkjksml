CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE users (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 full_name VARCHAR(150) NOT NULL,
 email VARCHAR(255) UNIQUE,
 phone_number VARCHAR(30) UNIQUE NOT NULL,
 password_hash VARCHAR(255),
 role VARCHAR(20) NOT NULL DEFAULT 'customer' CHECK(role IN ('customer','seller','driver','admin')),
 is_verified BOOLEAN NOT NULL DEFAULT FALSE,
 is_active BOOLEAN NOT NULL DEFAULT TRUE,
 created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE otp_codes (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 user_id UUID REFERENCES users(id) ON DELETE CASCADE,
 phone_number VARCHAR(30) NOT NULL,
 code_hash VARCHAR(255) NOT NULL,
 purpose VARCHAR(30) NOT NULL CHECK(purpose IN ('registration','login','reset','payment')),
 expires_at TIMESTAMPTZ NOT NULL,
 consumed_at TIMESTAMPTZ,
 attempts INT NOT NULL DEFAULT 0,
 created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE merchants (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 user_id UUID UNIQUE NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 store_name VARCHAR(150) UNIQUE NOT NULL,
 slug VARCHAR(180) UNIQUE NOT NULL,
 description TEXT,
 logo_url TEXT,
 governorate VARCHAR(50) NOT NULL,
 fulfillment_type VARCHAR(10) NOT NULL DEFAULT 'FBM' CHECK(fulfillment_type IN ('FBN','FBM')),
 rating NUMERIC(3,2) NOT NULL DEFAULT 0,
 is_active BOOLEAN NOT NULL DEFAULT TRUE,
 created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE categories (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 parent_id UUID REFERENCES categories(id) ON DELETE SET NULL,
 name_ar VARCHAR(100) NOT NULL,
 slug VARCHAR(120) UNIQUE NOT NULL,
 commission_rate NUMERIC(5,2) NOT NULL DEFAULT 8 CHECK(commission_rate >= 0 AND commission_rate <= 100),
 image_url TEXT,
 sort_order INT NOT NULL DEFAULT 0
);

CREATE TABLE products_master (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 nsin VARCHAR(30) UNIQUE NOT NULL,
 category_id UUID NOT NULL REFERENCES categories(id),
 title VARCHAR(255) NOT NULL,
 brand VARCHAR(100),
 description TEXT,
 main_image_url TEXT,
 condition_policy VARCHAR(30) DEFAULT 'new',
 attributes JSONB NOT NULL DEFAULT '{}',
 created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE product_images (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 product_id UUID NOT NULL REFERENCES products_master(id) ON DELETE CASCADE,
 image_url TEXT NOT NULL,
 sort_order INT NOT NULL DEFAULT 0
);

CREATE TABLE product_listings (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 product_id UUID NOT NULL REFERENCES products_master(id) ON DELETE CASCADE,
 merchant_id UUID NOT NULL REFERENCES merchants(id) ON DELETE CASCADE,
 sku VARCHAR(100) NOT NULL,
 currency CHAR(3) NOT NULL DEFAULT 'ILS' CHECK(currency IN ('ILS','USD')),
 price NUMERIC(12,2) NOT NULL CHECK(price >= 0),
 sale_price NUMERIC(12,2) CHECK(sale_price IS NULL OR sale_price >= 0),
 stock_quantity INT NOT NULL DEFAULT 0 CHECK(stock_quantity >= 0),
 reserved_quantity INT NOT NULL DEFAULT 0 CHECK(reserved_quantity >= 0),
 low_stock_threshold INT NOT NULL DEFAULT 3,
 condition VARCHAR(20) NOT NULL DEFAULT 'new' CHECK(condition IN ('new','used','refurbished')),
 shipping_days_min INT DEFAULT 1,
 shipping_days_max INT DEFAULT 3,
 return_policy_days INT DEFAULT 7,
 is_active BOOLEAN NOT NULL DEFAULT TRUE,
 UNIQUE(merchant_id, sku)
);

CREATE TABLE warehouses (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 name VARCHAR(150) NOT NULL,
 governorate VARCHAR(50) NOT NULL,
 address TEXT,
 latitude NUMERIC(10,8),
 longitude NUMERIC(11,8),
 is_active BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE warehouse_stock (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 warehouse_id UUID NOT NULL REFERENCES warehouses(id) ON DELETE CASCADE,
 listing_id UUID NOT NULL REFERENCES product_listings(id) ON DELETE CASCADE,
 quantity INT NOT NULL DEFAULT 0 CHECK(quantity >= 0),
 reserved_quantity INT NOT NULL DEFAULT 0 CHECK(reserved_quantity >= 0),
 UNIQUE(warehouse_id, listing_id)
);

CREATE TABLE addresses (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 governorate VARCHAR(50) NOT NULL,
 district VARCHAR(100) NOT NULL,
 street_address TEXT NOT NULL,
 nearest_landmark TEXT,
 latitude NUMERIC(10,8),
 longitude NUMERIC(11,8),
 delivery_notes TEXT,
 is_default BOOLEAN NOT NULL DEFAULT FALSE
);

CREATE TABLE delivery_zones (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 governorate VARCHAR(50) NOT NULL,
 district VARCHAR(100) NOT NULL,
 fee_ils NUMERIC(10,2) NOT NULL DEFAULT 0,
 estimated_minutes INT,
 is_active BOOLEAN NOT NULL DEFAULT TRUE,
 UNIQUE(governorate,district)
);

CREATE TABLE carts (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 user_id UUID UNIQUE NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 currency CHAR(3) NOT NULL DEFAULT 'ILS',
 updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE cart_items (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 cart_id UUID NOT NULL REFERENCES carts(id) ON DELETE CASCADE,
 listing_id UUID NOT NULL REFERENCES product_listings(id),
 quantity INT NOT NULL CHECK(quantity > 0),
 UNIQUE(cart_id, listing_id)
);

CREATE TABLE orders (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 order_number VARCHAR(50) UNIQUE NOT NULL,
 customer_id UUID NOT NULL REFERENCES users(id),
 shipping_address_id UUID NOT NULL REFERENCES addresses(id),
 currency CHAR(3) NOT NULL DEFAULT 'ILS',
 subtotal NUMERIC(12,2) NOT NULL,
 shipping_fee NUMERIC(10,2) NOT NULL DEFAULT 0,
 total_amount NUMERIC(12,2) NOT NULL,
 payment_method VARCHAR(30) NOT NULL CHECK(payment_method IN ('COD','Jawwal_Pay','Paltel_Pay')),
 payment_status VARCHAR(30) NOT NULL DEFAULT 'unpaid',
 status VARCHAR(30) NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','processing','shipped','delivered','cancelled')),
 created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE sub_orders (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 parent_order_id UUID NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
 merchant_id UUID NOT NULL REFERENCES merchants(id),
 driver_id UUID REFERENCES users(id),
 fulfillment_type VARCHAR(10) NOT NULL DEFAULT 'FBM',
 subtotal NUMERIC(12,2) NOT NULL,
 commission_fee NUMERIC(12,2) NOT NULL DEFAULT 0,
 shipping_fee NUMERIC(10,2) NOT NULL DEFAULT 0,
 merchant_payout NUMERIC(12,2) NOT NULL DEFAULT 0,
 status VARCHAR(40) NOT NULL DEFAULT 'processing',
 tracking_code VARCHAR(100) UNIQUE,
 delivered_at TIMESTAMPTZ
);

CREATE TABLE order_items (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 sub_order_id UUID NOT NULL REFERENCES sub_orders(id) ON DELETE CASCADE,
 listing_id UUID NOT NULL REFERENCES product_listings(id),
 unit_price NUMERIC(12,2) NOT NULL,
 quantity INT NOT NULL CHECK(quantity > 0),
 line_total NUMERIC(12,2) GENERATED ALWAYS AS (unit_price * quantity) STORED
);

CREATE TABLE payments (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 order_id UUID NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
 provider VARCHAR(40) NOT NULL,
 provider_reference VARCHAR(150),
 amount NUMERIC(12,2) NOT NULL,
 currency CHAR(3) NOT NULL DEFAULT 'ILS',
 status VARCHAR(30) NOT NULL DEFAULT 'pending',
 raw_reference JSONB,
 created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 confirmed_at TIMESTAMPTZ
);

CREATE TABLE wallets (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 merchant_id UUID UNIQUE NOT NULL REFERENCES merchants(id) ON DELETE CASCADE,
 currency CHAR(3) NOT NULL DEFAULT 'ILS',
 available_balance NUMERIC(14,2) NOT NULL DEFAULT 0,
 pending_balance NUMERIC(14,2) NOT NULL DEFAULT 0,
 lifetime_earnings NUMERIC(14,2) NOT NULL DEFAULT 0,
 lifetime_withdrawn NUMERIC(14,2) NOT NULL DEFAULT 0
);

CREATE TABLE wallet_transactions (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 wallet_id UUID NOT NULL REFERENCES wallets(id),
 sub_order_id UUID REFERENCES sub_orders(id),
 transaction_type VARCHAR(40) NOT NULL,
 amount NUMERIC(14,2) NOT NULL,
 balance_after NUMERIC(14,2) NOT NULL,
 reference VARCHAR(150),
 created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE withdrawals (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 wallet_id UUID NOT NULL REFERENCES wallets(id),
 amount NUMERIC(14,2) NOT NULL CHECK(amount > 0),
 method VARCHAR(40) NOT NULL,
 destination_reference VARCHAR(150),
 status VARCHAR(30) NOT NULL DEFAULT 'pending',
 created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 processed_at TIMESTAMPTZ
);

CREATE TABLE drivers (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 user_id UUID UNIQUE NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 vehicle_type VARCHAR(50),
 vehicle_number VARCHAR(50),
 current_latitude NUMERIC(10,8),
 current_longitude NUMERIC(11,8),
 is_online BOOLEAN NOT NULL DEFAULT FALSE,
 is_active BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE shipments (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 sub_order_id UUID UNIQUE NOT NULL REFERENCES sub_orders(id) ON DELETE CASCADE,
 driver_id UUID REFERENCES drivers(id),
 pickup_latitude NUMERIC(10,8),
 pickup_longitude NUMERIC(11,8),
 dropoff_latitude NUMERIC(10,8),
 dropoff_longitude NUMERIC(11,8),
 current_latitude NUMERIC(10,8),
 current_longitude NUMERIC(11,8),
 status VARCHAR(40) NOT NULL DEFAULT 'created',
 eta_minutes INT,
 created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE shipment_events (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 shipment_id UUID NOT NULL REFERENCES shipments(id) ON DELETE CASCADE,
 status VARCHAR(40) NOT NULL,
 note TEXT,
 latitude NUMERIC(10,8),
 longitude NUMERIC(11,8),
 created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE messages (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 sender_id UUID NOT NULL REFERENCES users(id),
 receiver_id UUID NOT NULL REFERENCES users(id),
 order_id UUID REFERENCES orders(id),
 body TEXT NOT NULL,
 read_at TIMESTAMPTZ,
 created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE reviews (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 customer_id UUID NOT NULL REFERENCES users(id),
 product_id UUID NOT NULL REFERENCES products_master(id),
 order_id UUID REFERENCES orders(id),
 rating INT NOT NULL CHECK(rating BETWEEN 1 AND 5),
 comment TEXT,
 moderation_status VARCHAR(20) NOT NULL DEFAULT 'pending',
 created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 UNIQUE(customer_id, product_id, order_id)
);

CREATE TABLE favorites (
 user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 product_id UUID NOT NULL REFERENCES products_master(id) ON DELETE CASCADE,
 created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 PRIMARY KEY(user_id, product_id)
);

CREATE TABLE notifications (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 type VARCHAR(50) NOT NULL,
 title VARCHAR(200) NOT NULL,
 body TEXT,
 data JSONB NOT NULL DEFAULT '{}',
 read_at TIMESTAMPTZ,
 created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE complaints (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 user_id UUID NOT NULL REFERENCES users(id),
 order_id UUID REFERENCES orders(id),
 subject VARCHAR(200) NOT NULL,
 description TEXT NOT NULL,
 status VARCHAR(30) NOT NULL DEFAULT 'open',
 resolution TEXT,
 created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 resolved_at TIMESTAMPTZ
);

CREATE TABLE coupons (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 code VARCHAR(50) UNIQUE NOT NULL,
 discount_type VARCHAR(20) NOT NULL CHECK(discount_type IN ('fixed','percent')),
 discount_value NUMERIC(10,2) NOT NULL,
 max_uses INT,
 used_count INT NOT NULL DEFAULT 0,
 expires_at TIMESTAMPTZ,
 is_active BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE audit_logs (
 id BIGSERIAL PRIMARY KEY,
 actor_user_id UUID REFERENCES users(id),
 action VARCHAR(100) NOT NULL,
 entity_type VARCHAR(60),
 entity_id UUID,
 metadata JSONB NOT NULL DEFAULT '{}',
 ip_address INET,
 created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE platform_settings (
 key VARCHAR(100) PRIMARY KEY,
 value JSONB NOT NULL,
 updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_products_category ON products_master(category_id);
CREATE INDEX idx_listings_merchant ON product_listings(merchant_id);
CREATE INDEX idx_listings_product ON product_listings(product_id);
CREATE INDEX idx_orders_customer_status ON orders(customer_id,status);
CREATE INDEX idx_suborders_merchant_status ON sub_orders(merchant_id,status);
CREATE INDEX idx_messages_pair ON messages(sender_id,receiver_id,created_at);
CREATE INDEX idx_notifications_user ON notifications(user_id,created_at);
CREATE INDEX idx_shipments_driver ON shipments(driver_id,status);
CREATE INDEX idx_audit_created ON audit_logs(created_at);


CREATE TABLE IF NOT EXISTS services (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 name_ar VARCHAR(200) NOT NULL,
 description TEXT,
 price_ils NUMERIC(12,2) NOT NULL DEFAULT 0,
 is_active BOOLEAN NOT NULL DEFAULT TRUE,
 created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
