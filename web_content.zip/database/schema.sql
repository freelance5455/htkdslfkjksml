CREATE TABLE admins (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 email VARCHAR(190) NOT NULL UNIQUE,
 password_hash VARCHAR(255) NOT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE packages (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(120) NOT NULL,
 service_type ENUM('hotspot','pppoe','both') NOT NULL DEFAULT 'both',
 price DECIMAL(12,2) NOT NULL DEFAULT 0,
 validity_days INT UNSIGNED NOT NULL DEFAULT 30,
 speed_down_kbps INT UNSIGNED NULL,
 speed_up_kbps INT UNSIGNED NULL,
 data_limit_mb BIGINT UNSIGNED NULL,
 active TINYINT(1) NOT NULL DEFAULT 1,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE customers (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 full_name VARCHAR(160) NOT NULL,
 phone VARCHAR(40) NULL,
 username VARCHAR(100) NOT NULL UNIQUE,
 service_type ENUM('hotspot','pppoe') NOT NULL,
 package_id BIGINT UNSIGNED NULL,
 status ENUM('active','suspended','expired') NOT NULL DEFAULT 'active',
 router_comment VARCHAR(255) NULL,
 expires_at DATETIME NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 CONSTRAINT fk_customer_package FOREIGN KEY (package_id) REFERENCES packages(id) ON DELETE SET NULL
);
CREATE TABLE payments (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 customer_id BIGINT UNSIGNED NOT NULL,
 amount DECIMAL(12,2) NOT NULL,
 note VARCHAR(255) NULL,
 paid_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 CONSTRAINT fk_payment_customer FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE CASCADE
);
CREATE TABLE settings (
 setting_key VARCHAR(100) PRIMARY KEY,
 setting_value TEXT NOT NULL,
 updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
INSERT INTO packages(name,service_type,price,validity_days,speed_down_kbps,speed_up_kbps,data_limit_mb)
VALUES ('میاشتنی بنسټیز','both',200,30,2048,1024,NULL),
       ('میاشتنی چټک','both',450,30,5120,2048,NULL);
