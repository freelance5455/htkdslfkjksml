CREATE TABLE IF NOT EXISTS users(
 id BIGSERIAL PRIMARY KEY,name TEXT NOT NULL,username TEXT UNIQUE NOT NULL,
 password_hash TEXT NOT NULL,role TEXT NOT NULL CHECK(role IN('manager','cashier','kitchen','delivery')),
 created_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS menu_items(
 id BIGSERIAL PRIMARY KEY,name TEXT NOT NULL,category TEXT DEFAULT '',
 price NUMERIC(12,2) NOT NULL DEFAULT 0,cost NUMERIC(12,2) NOT NULL DEFAULT 0,
 active BOOLEAN DEFAULT TRUE,created_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS orders(
 id BIGSERIAL PRIMARY KEY,order_type TEXT NOT NULL CHECK(order_type IN('حضوری','بیرون‌بر','تلفنی','ارسال')),
 table_name TEXT DEFAULT '',customer_name TEXT DEFAULT '',phone TEXT DEFAULT '',note TEXT DEFAULT '',
 payment_method TEXT CHECK(payment_method IN('نقدی','کارت')),
 status TEXT NOT NULL DEFAULT 'جدید',total NUMERIC(12,2) NOT NULL DEFAULT 0,
 created_by BIGINT REFERENCES users(id),created_at TIMESTAMPTZ DEFAULT NOW(),updated_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS order_items(
 id BIGSERIAL PRIMARY KEY,order_id BIGINT REFERENCES orders(id) ON DELETE CASCADE,
 menu_item_id BIGINT REFERENCES menu_items(id),item_name TEXT NOT NULL,
 quantity NUMERIC(10,2) DEFAULT 1,unit_price NUMERIC(12,2) DEFAULT 0,unit_cost NUMERIC(12,2) DEFAULT 0
);
CREATE TABLE IF NOT EXISTS expenses(
 id BIGSERIAL PRIMARY KEY,title TEXT NOT NULL,amount NUMERIC(12,2) DEFAULT 0,note TEXT DEFAULT '',created_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS orders_status_idx ON orders(status);
CREATE INDEX IF NOT EXISTS orders_created_idx ON orders(created_at);
