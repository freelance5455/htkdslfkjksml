module.exports = {
  tokens: "8442075837:AAFOp8CtfFf00Z-82X8zMvKWyYXxtpxYaaw",  // Ubah Jadi Token Bot Mu !!!
  owner: "7414074179", // Ubah Jadi Id Mu !!!
  port: "1466", // Ubah Jadi Port Panel Mu !!!
  ipvps: "167.172.64.240" // Ubah Jadi Ip Vps Mu !!!
};