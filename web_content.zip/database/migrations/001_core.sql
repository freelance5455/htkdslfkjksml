-- AccoNova core schema (PostgreSQL 16). Server-side counterpart of the local-first engine.
-- Guarantees enforced by the database itself:
--   * every journal entry balances (deferred constraint trigger, per currency and in base units)
--   * posted entries/lines are immutable (no UPDATE/DELETE) – corrections are reversal entries
--   * posting into a closed fiscal period is rejected
--   * tenant isolation by Row-Level Security (app sets  SET LOCAL app.company_id / app.user_id)
--   * idempotency: unique (company_id, idempotency_key)
--   * money is BIGINT minor units – never floating point
-- Run as a privileged role; the application connects as role acconova_app (no BYPASSRLS).

BEGIN;

CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE EXTENSION IF NOT EXISTS btree_gist;

DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'acconova_app') THEN
    CREATE ROLE acconova_app NOLOGIN NOBYPASSRLS;
  END IF;
END $$;

-- ───────── helpers ─────────
CREATE FUNCTION app_company() RETURNS uuid LANGUAGE sql STABLE AS
$$ SELECT NULLIF(current_setting('app.company_id', true), '')::uuid $$;
CREATE FUNCTION app_user() RETURNS uuid LANGUAGE sql STABLE AS
$$ SELECT NULLIF(current_setting('app.user_id', true), '')::uuid $$;

-- ───────── identity, tenants, roles ─────────
CREATE TABLE users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text NOT NULL,
  name text NOT NULL CHECK (length(btrim(name)) > 0),
  password_hash text NOT NULL,              -- argon2id, produced by the app
  mfa_secret_enc bytea,                     -- encrypted TOTP secret
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX users_email_lower ON users (lower(email));

CREATE TABLE companies (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL CHECK (length(btrim(name)) > 0),
  base_currency char(3) NOT NULL,
  calendar text NOT NULL DEFAULT 'jalali' CHECK (calendar IN ('jalali','gregorian')),
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE memberships (
  company_id uuid NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  role text NOT NULL CHECK (role IN ('owner','admin','accountant','viewer')),
  PRIMARY KEY (company_id, user_id)
);

-- a company must always keep at least one owner
CREATE FUNCTION keep_last_owner() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF (TG_OP = 'DELETE' AND OLD.role = 'owner')
     OR (TG_OP = 'UPDATE' AND OLD.role = 'owner' AND NEW.role <> 'owner') THEN
    IF NOT EXISTS (SELECT 1 FROM memberships
                   WHERE company_id = OLD.company_id AND role = 'owner' AND user_id <> OLD.user_id)
       AND EXISTS (SELECT 1 FROM companies WHERE id = OLD.company_id) THEN
      RAISE EXCEPTION 'LAST_OWNER' USING ERRCODE = 'P0001';
    END IF;
  END IF;
  RETURN COALESCE(NEW, OLD);
END $$;
CREATE TRIGGER memberships_keep_owner BEFORE UPDATE OR DELETE ON memberships
  FOR EACH ROW EXECUTE FUNCTION keep_last_owner();

-- ───────── subscriptions (updated only by the verified webhook handler) ─────────
CREATE TABLE subscriptions (
  company_id uuid PRIMARY KEY REFERENCES companies(id) ON DELETE CASCADE,
  plan text NOT NULL DEFAULT 'free' CHECK (plan IN ('free','pro','business')),
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active','past_due','canceled')),
  period_end timestamptz,
  pending_plan text CHECK (pending_plan IN ('free','pro','business')),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE billing_events (               -- idempotent webhook log
  provider text NOT NULL,
  event_id text NOT NULL,
  company_id uuid REFERENCES companies(id) ON DELETE SET NULL,
  type text NOT NULL,
  payload jsonb NOT NULL,
  received_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (provider, event_id)
);

-- ───────── chart of accounts, fiscal periods ─────────
CREATE TABLE accounts (
  company_id uuid NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  id text NOT NULL,
  code text NOT NULL,
  type text NOT NULL CHECK (type IN ('asset','liability','equity','revenue','expense')),
  name_fa text NOT NULL,
  name_en text NOT NULL,
  sys_role text,
  active boolean NOT NULL DEFAULT true,
  PRIMARY KEY (company_id, id),
  UNIQUE (company_id, code)
);

CREATE TABLE fiscal_periods (
  company_id uuid NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  id text NOT NULL,                          -- e.g. 1405-07
  start_date date NOT NULL,
  end_date date NOT NULL,
  status text NOT NULL DEFAULT 'open' CHECK (status IN ('open','closed')),
  PRIMARY KEY (company_id, id),
  CHECK (end_date >= start_date),
  EXCLUDE USING gist (company_id WITH =, daterange(start_date, end_date, '[]') WITH &&)
);

-- ───────── journal (immutable) ─────────
CREATE TABLE journal_entries (
  company_id uuid NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  id text NOT NULL,
  seq bigint NOT NULL,
  entry_date date NOT NULL,
  memo text NOT NULL DEFAULT '',
  source text NOT NULL DEFAULT 'manual',
  reverses text,
  idempotency_key text,
  created_by uuid REFERENCES users(id),
  created_at timestamptz NOT NULL DEFAULT now(),
  prev_hash text NOT NULL,
  hash text NOT NULL,
  PRIMARY KEY (company_id, id),
  UNIQUE (company_id, seq),
  FOREIGN KEY (company_id, reverses) REFERENCES journal_entries (company_id, id)
);
CREATE UNIQUE INDEX journal_idem ON journal_entries (company_id, idempotency_key) WHERE idempotency_key IS NOT NULL;
-- an entry can be reversed at most once
CREATE UNIQUE INDEX journal_one_reversal ON journal_entries (company_id, reverses) WHERE reverses IS NOT NULL;

CREATE TABLE journal_lines (
  company_id uuid NOT NULL,
  entry_id text NOT NULL,
  line_no int NOT NULL,
  account_id text NOT NULL,
  currency char(3) NOT NULL,
  debit bigint NOT NULL DEFAULT 0 CHECK (debit >= 0),
  credit bigint NOT NULL DEFAULT 0 CHECK (credit >= 0),
  base_debit bigint NOT NULL DEFAULT 0 CHECK (base_debit >= 0),
  base_credit bigint NOT NULL DEFAULT 0 CHECK (base_credit >= 0),
  rate_ppm bigint NOT NULL DEFAULT 1000000 CHECK (rate_ppm > 0),
  PRIMARY KEY (company_id, entry_id, line_no),
  FOREIGN KEY (company_id, entry_id) REFERENCES journal_entries (company_id, id) ON DELETE CASCADE,
  FOREIGN KEY (company_id, account_id) REFERENCES accounts (company_id, id),
  CHECK ((debit > 0) <> (credit > 0) OR (debit = 0 AND credit = 0 AND (base_debit > 0) <> (base_credit > 0))),
  CHECK (base_debit = 0 OR base_credit = 0)
);

-- entry must balance in base units (deferred: checked at COMMIT, after all lines are inserted)
CREATE FUNCTION check_entry_balanced() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE d bigint; c bigint; n int; e_company uuid; e_id text;
BEGIN
  e_company := NEW.company_id;
  e_id := COALESCE(to_jsonb(NEW)->>'entry_id', to_jsonb(NEW)->>'id');
  SELECT COALESCE(sum(base_debit),0), COALESCE(sum(base_credit),0), count(*)
    INTO d, c, n FROM journal_lines WHERE company_id = e_company AND entry_id = e_id;
  IF n < 2 OR d <> c OR d = 0 THEN
    RAISE EXCEPTION 'UNBALANCED: entry % (debit %, credit %, lines %)', e_id, d, c, n USING ERRCODE = '23514';
  END IF;
  RETURN NULL;
END $$;
CREATE CONSTRAINT TRIGGER entry_balanced_on_line AFTER INSERT ON journal_lines
  DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION check_entry_balanced();
CREATE CONSTRAINT TRIGGER entry_has_lines AFTER INSERT ON journal_entries
  DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION check_entry_balanced();

-- per-currency balance as well: for every currency used, foreign debits = credits
-- (rounding/FX lines are booked in the company base currency, so this holds for single-currency lines)
-- (kept at base-unit level above; foreign-currency equality is checked by the application engine)

-- immutability: posted entries and lines can never change or be deleted
CREATE FUNCTION forbid_change() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  -- allow cascade deletion only when the whole company is being deleted
  IF TG_OP = 'DELETE' AND NOT EXISTS (SELECT 1 FROM companies WHERE id = OLD.company_id) THEN
    RETURN OLD;
  END IF;
  RAISE EXCEPTION 'IMMUTABLE: % on % is not allowed; post a reversal entry instead', TG_OP, TG_TABLE_NAME
    USING ERRCODE = '55000';
END $$;
CREATE TRIGGER journal_entries_immutable BEFORE UPDATE OR DELETE ON journal_entries
  FOR EACH ROW EXECUTE FUNCTION forbid_change();
CREATE TRIGGER journal_lines_immutable BEFORE UPDATE OR DELETE ON journal_lines
  FOR EACH ROW EXECUTE FUNCTION forbid_change();

-- closed period guard
CREATE FUNCTION check_period_open() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE st text;
BEGIN
  SELECT status INTO st FROM fiscal_periods
   WHERE company_id = NEW.company_id AND NEW.entry_date BETWEEN start_date AND end_date;
  IF st IS NULL THEN RAISE EXCEPTION 'NO_PERIOD: no fiscal period for %', NEW.entry_date USING ERRCODE = 'P0002'; END IF;
  IF st = 'closed' THEN RAISE EXCEPTION 'PERIOD_CLOSED: %', NEW.entry_date USING ERRCODE = 'P0003'; END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER journal_period_open BEFORE INSERT ON journal_entries
  FOR EACH ROW EXECUTE FUNCTION check_period_open();

-- append-only audit log
CREATE TABLE audit_log (
  company_id uuid NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  seq bigint GENERATED ALWAYS AS IDENTITY,
  at timestamptz NOT NULL DEFAULT now(),
  user_id uuid,
  action text NOT NULL,
  detail text NOT NULL DEFAULT '',
  PRIMARY KEY (company_id, seq)
);
CREATE TRIGGER audit_immutable BEFORE UPDATE OR DELETE ON audit_log
  FOR EACH ROW EXECUTE FUNCTION forbid_change();

-- ───────── contacts, tax codes, invoices, payments ─────────
CREATE TABLE contacts (
  company_id uuid NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  id text NOT NULL,
  kind text NOT NULL CHECK (kind IN ('customer','supplier','both')),
  name text NOT NULL CHECK (length(btrim(name)) > 0),
  email text, phone text, tax_id text,
  PRIMARY KEY (company_id, id)
);
CREATE TABLE tax_codes (
  company_id uuid NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  id text NOT NULL,
  name_fa text NOT NULL, name_en text NOT NULL,
  bps int NOT NULL CHECK (bps BETWEEN 0 AND 10000),
  PRIMARY KEY (company_id, id)
);
CREATE TABLE invoices (
  company_id uuid NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  id text NOT NULL,
  kind text NOT NULL CHECK (kind IN ('sale','bill')),
  number text,
  contact_id text NOT NULL,
  status text NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','posted','void')),
  currency char(3) NOT NULL,
  rate_ppm bigint NOT NULL DEFAULT 1000000 CHECK (rate_ppm > 0),
  issue_date date NOT NULL,
  due_date date NOT NULL CHECK (due_date >= issue_date),
  net bigint NOT NULL DEFAULT 0 CHECK (net >= 0),
  tax bigint NOT NULL DEFAULT 0 CHECK (tax >= 0),
  total bigint NOT NULL DEFAULT 0 CHECK (total = net + tax),
  entry_id text,
  PRIMARY KEY (company_id, id),
  FOREIGN KEY (company_id, contact_id) REFERENCES contacts (company_id, id),
  FOREIGN KEY (company_id, entry_id) REFERENCES journal_entries (company_id, id),
  CHECK (status = 'draft' OR number IS NOT NULL)
);
CREATE UNIQUE INDEX invoices_number ON invoices (company_id, kind, number) WHERE number IS NOT NULL;

CREATE TABLE payments (
  company_id uuid NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  id text NOT NULL,
  direction text NOT NULL CHECK (direction IN ('in','out')),
  status text NOT NULL DEFAULT 'posted' CHECK (status IN ('posted','void')),
  currency char(3) NOT NULL,
  amount bigint NOT NULL CHECK (amount > 0),
  pay_date date NOT NULL,
  entry_id text NOT NULL,
  PRIMARY KEY (company_id, id),
  FOREIGN KEY (company_id, entry_id) REFERENCES journal_entries (company_id, id)
);
CREATE TABLE payment_allocations (
  company_id uuid NOT NULL,
  payment_id text NOT NULL,
  invoice_id text NOT NULL,
  amount bigint NOT NULL CHECK (amount > 0),
  PRIMARY KEY (company_id, payment_id, invoice_id),
  FOREIGN KEY (company_id, payment_id) REFERENCES payments (company_id, id) ON DELETE CASCADE,
  FOREIGN KEY (company_id, invoice_id) REFERENCES invoices (company_id, id)
);

-- allocations of a payment may never exceed the payment amount
CREATE FUNCTION check_allocations() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE tot bigint; amt bigint;
BEGIN
  SELECT COALESCE(sum(amount),0) INTO tot FROM payment_allocations
   WHERE company_id = NEW.company_id AND payment_id = NEW.payment_id;
  SELECT amount INTO amt FROM payments WHERE company_id = NEW.company_id AND id = NEW.payment_id;
  IF tot > amt THEN RAISE EXCEPTION 'OVERPAY: allocations % exceed payment %', tot, amt USING ERRCODE = '23514'; END IF;
  RETURN NULL;
END $$;
CREATE CONSTRAINT TRIGGER allocations_within_payment AFTER INSERT OR UPDATE ON payment_allocations
  DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION check_allocations();

-- ───────── Row-Level Security: tenant isolation ─────────
DO $$
DECLARE t text;
BEGIN
  FOREACH t IN ARRAY ARRAY['accounts','fiscal_periods','journal_entries','journal_lines','audit_log',
                           'contacts','tax_codes','invoices','payments','payment_allocations','subscriptions']
  LOOP
    EXECUTE format('ALTER TABLE %I ENABLE ROW LEVEL SECURITY', t);
    EXECUTE format('ALTER TABLE %I FORCE ROW LEVEL SECURITY', t);
    EXECUTE format('CREATE POLICY tenant_isolation ON %I USING (company_id = app_company()) WITH CHECK (company_id = app_company())', t);
  END LOOP;
END $$;

ALTER TABLE companies ENABLE ROW LEVEL SECURITY; ALTER TABLE companies FORCE ROW LEVEL SECURITY;
CREATE POLICY member_read ON companies FOR SELECT USING (
  id = app_company() OR EXISTS (SELECT 1 FROM memberships m WHERE m.company_id = companies.id AND m.user_id = app_user()));
CREATE POLICY owner_write ON companies FOR UPDATE USING (id = app_company()) WITH CHECK (id = app_company());
CREATE POLICY any_insert ON companies FOR INSERT WITH CHECK (true);

ALTER TABLE memberships ENABLE ROW LEVEL SECURITY; ALTER TABLE memberships FORCE ROW LEVEL SECURITY;
CREATE POLICY own_or_company ON memberships USING (company_id = app_company() OR user_id = app_user())
  WITH CHECK (company_id = app_company());

GRANT USAGE ON SCHEMA public TO acconova_app;
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO acconova_app;
GRANT SELECT, INSERT, UPDATE, DELETE ON users, billing_events TO acconova_app;
GRANT USAGE ON ALL SEQUENCES IN SCHEMA public TO acconova_app;

COMMIT;
