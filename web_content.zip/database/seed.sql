INSERT INTO categories(name_ar,slug,commission_rate,sort_order) VALUES
('الإلكترونيات','electronics',7,1),('المنزل والمطبخ','home',8,2),('الملابس والأزياء','fashion',12,3),
('الجمال والعناية','beauty',10,4),('الرياضة','sports',9,5),('إكسسوارات','accessories',10,6)
ON CONFLICT(slug) DO UPDATE SET commission_rate=EXCLUDED.commission_rate;

INSERT INTO delivery_zones(governorate,district,fee_ils,estimated_minutes) VALUES
('غزة','الرمال',10,35),('غزة','تل الهوا',10,40),('غزة','الشجاعية',12,45),('غزة','الزيتون',12,45),
('شمال غزة','جباليا',15,55),('شمال غزة','بيت لاهيا',15,60),('شمال غزة','بيت حانون',16,65),
('الوسطى','النصيرات',15,55),('الوسطى','دير البلح',15,60),('الوسطى','البريج',15,55),
('خانيونس','خانيونس',18,70),('خانيونس','عبسان',20,80),('رفح','رفح',20,80)
ON CONFLICT(governorate,district) DO UPDATE SET fee_ils=EXCLUDED.fee_ils,estimated_minutes=EXCLUDED.estimated_minutes;

INSERT INTO platform_settings(key,value) VALUES
('platform_name','"AMAZON GAZA"'),('base_currency','"ILS"'),('supported_currencies','["ILS","USD"]'),
('payment_methods','["COD","Jawwal_Pay","Paltel_Pay"]'),('fulfillment_modes','["FBN","FBM"]'),
('internet_only','true'),('security_profile','"strict"'),('low_stock_default','3')
ON CONFLICT(key) DO UPDATE SET value=EXCLUDED.value;

INSERT INTO users(full_name,phone_number,email,role,is_verified) VALUES
('AMAZON GAZA Demo Seller','0590000001','seller@amazon-gaza.local','seller',true),
('AMAZON GAZA Demo Customer','0590000002','customer@amazon-gaza.local','customer',true),
('AMAZON GAZA Demo Driver','0590000003','driver@amazon-gaza.local','driver',true)
ON CONFLICT(phone_number) DO NOTHING;

DO $$
DECLARE seller UUID; customer UUID; driver UUID; m UUID; w UUID; addr UUID; d UUID; c UUID; p UUID; listing UUID; so UUID; o UUID; sh UUID;
BEGIN
 SELECT id INTO seller FROM users WHERE phone_number='0590000001';
 SELECT id INTO customer FROM users WHERE phone_number='0590000002';
 SELECT id INTO driver FROM users WHERE phone_number='0590000003';
 SELECT id INTO c FROM categories WHERE slug='electronics';
 INSERT INTO merchants(user_id,store_name,slug,description,governorate,fulfillment_type) VALUES(seller,'AMAZON GAZA Demo Store','amazon-gaza-demo-store','متجر تجريبي لعرض دورة البائع الكاملة','غزة','FBM') ON CONFLICT(user_id) DO UPDATE SET store_name=EXCLUDED.store_name RETURNING id INTO m;
 IF m IS NULL THEN SELECT id INTO m FROM merchants WHERE user_id=seller; END IF;
 INSERT INTO wallets(merchant_id) VALUES(m) ON CONFLICT(merchant_id) DO NOTHING;
 SELECT id INTO w FROM wallets WHERE merchant_id=m;
 INSERT INTO addresses(user_id,governorate,district,street_address,nearest_landmark,latitude,longitude,is_default) VALUES(customer,'غزة','الرمال','شارع تجريبي','بالقرب من الستيريو',31.5145,34.4558,true) ON CONFLICT DO NOTHING;
 SELECT id INTO addr FROM addresses WHERE user_id=customer LIMIT 1;
 INSERT INTO products_master(nsin,category_id,title,brand,description,main_image_url,attributes) VALUES
 ('NX-ELEC-000001',c,'سماعات لاسلكية','AMAZON GAZA','سماعات تجريبية عالية الجودة','https://placehold.co/900x900?text=AMAZON GAZA+Audio','{"color":"black","wireless":true}'),
 ('NX-ELEC-000002',c,'هاتف ذكي','AMAZON GAZA','هاتف تجريبي','https://placehold.co/900x900?text=AMAZON GAZA+Phone','{"storage":"128GB"}')
 ON CONFLICT(nsin) DO NOTHING;
 SELECT id INTO p FROM products_master WHERE nsin='NX-ELEC-000001';
 INSERT INTO product_listings(product_id,merchant_id,sku,currency,price,stock_quantity,low_stock_threshold,condition) VALUES(p,m,'NX-ELEC-000001','ILS',79,40,5,'new') ON CONFLICT(merchant_id,sku) DO UPDATE SET stock_quantity=40;
 SELECT id INTO listing FROM product_listings WHERE merchant_id=m AND sku='NX-ELEC-000001';
 SELECT id INTO p FROM products_master WHERE nsin='NX-ELEC-000002';
 INSERT INTO product_listings(product_id,merchant_id,sku,currency,price,stock_quantity,low_stock_threshold,condition) VALUES(p,m,'NX-ELEC-000002','ILS',320,12,3,'new') ON CONFLICT(merchant_id,sku) DO UPDATE SET stock_quantity=12;
 -- demo completed order for dashboards
 INSERT INTO orders(order_number,customer_id,shipping_address_id,subtotal,shipping_fee,total_amount,payment_method,payment_status,status)
 VALUES('NX-DEMO-10001',customer,addr,79,10,89,'COD','paid','delivered') ON CONFLICT(order_number) DO NOTHING;
 SELECT id INTO o FROM orders WHERE order_number='NX-DEMO-10001';
 INSERT INTO sub_orders(parent_order_id,merchant_id,driver_id,fulfillment_type,subtotal,commission_fee,shipping_fee,merchant_payout,status,tracking_code,delivered_at)
 VALUES(o,m,driver,'FBM',79,5.53,10,73.47,'delivered','NXTRK-DEMO-10001',now()) ON CONFLICT(tracking_code) DO NOTHING;
 SELECT id INTO so FROM sub_orders WHERE tracking_code='NXTRK-DEMO-10001';
 SELECT id INTO listing FROM product_listings WHERE merchant_id=m AND sku='NX-ELEC-000001';
 INSERT INTO order_items(sub_order_id,listing_id,unit_price,quantity) VALUES(so,listing,79,1) ON CONFLICT DO NOTHING;
 INSERT INTO wallet_transactions(wallet_id,sub_order_id,transaction_type,amount,balance_after,reference) VALUES(w,so,'sale_payout',73.47,3420,'DEMO-PAYOUT') ON CONFLICT DO NOTHING;
 UPDATE wallets SET available_balance=3420,pending_balance=860,lifetime_earnings=12480,lifetime_withdrawn=8200 WHERE id=w;
 INSERT INTO complaints(user_id,order_id,subject,description,status) VALUES(customer,o,'تأخر بسيط في التسليم','شكوى تجريبية لعرض لوحة المؤسس','resolved');
 INSERT INTO audit_logs(actor_user_id,action,entity_type,entity_id,metadata) VALUES(customer,'demo_seed','order',o,'{"source":"seed"}');
END $$;

-- Additional catalog records for a rich first environment.
DO $$
DECLARE ctech UUID; chome UUID; cfashion UUID; cbeauty UUID; csport UUID; cacc UUID; seller UUID; m UUID; i INT; p UUID;
BEGIN
 SELECT id INTO seller FROM users WHERE phone_number='0590000001'; SELECT id INTO m FROM merchants WHERE user_id=seller;
 SELECT id INTO ctech FROM categories WHERE slug='electronics'; SELECT id INTO chome FROM categories WHERE slug='home'; SELECT id INTO cfashion FROM categories WHERE slug='fashion'; SELECT id INTO cbeauty FROM categories WHERE slug='beauty'; SELECT id INTO csport FROM categories WHERE slug='sports'; SELECT id INTO cacc FROM categories WHERE slug='accessories';
 FOR i IN 1..30 LOOP
   INSERT INTO products_master(nsin,category_id,title,brand,description,main_image_url,attributes)
   VALUES('NX-DEMO-'||lpad(i::text,6,'0'),CASE WHEN i%6=0 THEN cacc WHEN i%5=0 THEN csport WHEN i%4=0 THEN cbeauty WHEN i%3=0 THEN cfashion WHEN i%2=0 THEN chome ELSE ctech END,'منتج تجريبي AMAZON GAZA #'||i,'AMAZON GAZA','منتج تجريبي لتعبئة الكتالوج','https://placehold.co/900x900?text=AMAZON GAZA+'||i,'{"demo":true}') ON CONFLICT(nsin) DO NOTHING;
   SELECT id INTO p FROM products_master WHERE nsin='NX-DEMO-'||lpad(i::text,6,'0');
   INSERT INTO product_listings(product_id,merchant_id,sku,currency,price,stock_quantity,low_stock_threshold,condition)
   VALUES(p,m,'NX-DEMO-SKU-'||i,'ILS',(20+i*7),CASE WHEN i%9=0 THEN 2 ELSE 15+i END,3,CASE WHEN i%11=0 THEN 'refurbished' ELSE 'new' END) ON CONFLICT(merchant_id,sku) DO NOTHING;
 END LOOP;
END $$;
