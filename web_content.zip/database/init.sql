CREATE TABLE IF NOT EXISTS videos (
  id SERIAL PRIMARY KEY,
  username VARCHAR(80) NOT NULL,
  caption TEXT NOT NULL,
  video_url TEXT,
  likes INTEGER DEFAULT 0,
  views INTEGER DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO videos (username, caption, video_url) VALUES
('@dz_creator', 'أجواء جزائرية جميلة 🇩🇿 #DZ', NULL),
('@food_dz', 'وصفة جزائرية سريعة 😋', NULL),
('@gaming_dz', 'Gaming DZ 🔥', NULL);
