SAFE COMMISSIONERS — ANDROID STUDIO PROJECT (PROTOTYPE)

Iyi ni Android app prototype ifite:
- Imigaragarire y'imitungo (sample listings)
- Form yo gutangaza umutungo (demo)
- Konti/login demo (nta credentials zibikwa)
- Umukino demo udafite amafaranga nyayo
- Android WebView ibonera HTML muri assets

UKO WAKORA APK:
1. Shyira Android Studio kuri mudasobwa.
2. Fungura Android Studio > Open.
3. Hitamo folder ya Safe_Commissioners_Android.
4. Tegereza Gradle sync (internet ishobora gukenerwa).
5. Hitamo Build > Build Bundle(s) / APK(s) > Build APK(s).
6. APK uzayibona muri app/build/outputs/apk/debug/app-debug.apk

IBYITONDERWA:
- Iyi ni prototype; ntabwo irimo production backend, Google Sheets integration, real account security, wallet, Mobile Money cyangwa payout.
- Sample listings ntabwo ari amatangazo nyayo.
- Ntukinjize amafaranga nyayo cyangwa amakuru y'ibanga muri demo.
- Kugira website/app live, uzakenera backend yizewe, authentication, Google Sheets/Apps Script integration, payment provider, server-side transaction ledger, admin tools, backups n'umutekano.
- Real-money gambling must not be enabled before checking Rwanda's licensing and compliance requirements.
