package ir.amino.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Message;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.JsPromptResult;
import android.webkit.JsResult;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.Toast;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

public class MainActivity extends Activity {

    static final String HOST = "appassets.androidplatform.net";
    static final String HOME = "https://" + HOST + "/index.html";
    static final int RC_FILE = 1, RC_PERM = 2, RC_CAM = 3;
    static final int BG = 0xFFE9EEF3;

    WebView wv;
    android.content.SharedPreferences sp;
    String bridgeJs = "";

    // internet gate: 0 = not asked yet, 1 = allowed, -1 = denied (this session)
    volatile int net;
    final Object askLock = new Object();
    volatile boolean netDialogShowing;
    boolean pendingPerms;

    ValueCallback<Uri[]> fileCb;
    WebChromeClient.FileChooserParams pendParams;
    Uri camUri;

    OutputStream out;
    String savedName = "";

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        sp = getSharedPreferences("a", 0);
        net = sp.getBoolean("net", false) ? 1 : 0;
        try {
            InputStream is = getAssets().open("bridge.js");
            byte[] d = new byte[is.available()];
            int n = is.read(d);
            is.close();
            bridgeJs = new String(d, 0, Math.max(n, 0), "UTF-8");
        } catch (Exception e) { /* ignore */ }

        wv = new WebView(this);
        wv.setBackgroundColor(BG);
        setContentView(wv);

        WebSettings s = wv.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setTextZoom(100);
        s.setMediaPlaybackRequiresUserGesture(true);
        s.setSupportMultipleWindows(true);
        s.setJavaScriptCanOpenWindowsAutomatically(true);

        wv.addJavascriptInterface(new Bridge(), "AminoBridge");
        wv.setWebViewClient(new Client());
        wv.setWebChromeClient(new Chrome());

        if (b != null) wv.restoreState(b);
        if (wv.getUrl() == null) wv.loadUrl(HOME);
    }

    // ------------------------------------------------------------------ helpers

    boolean has(String p) {
        return Build.VERSION.SDK_INT < 23 || checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED;
    }

    void toast(final String t) {
        runOnUiThread(new Runnable() {
            public void run() { Toast.makeText(MainActivity.this, t, Toast.LENGTH_LONG).show(); }
        });
    }

    void openExt(Uri u) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, u));
        } catch (ActivityNotFoundException e) {
            toast("برنامه‌ای برای باز کردن این لینک پیدا نشد");
        } catch (Exception e) { /* ignore */ }
    }

    WebResourceResponse empty(int code, String msg) {
        return new WebResourceResponse("text/plain", "utf-8", code, msg,
                new HashMap<String, String>(), new ByteArrayInputStream(new byte[0]));
    }

    // ------------------------------------------------------- internet permission

    boolean netOk() {
        if (net == 1) return true;
        if (net == -1) return false;
        synchronized (askLock) {
            if (net != 0) return net == 1;
            final CountDownLatch latch = new CountDownLatch(1);
            netDialogShowing = true;
            runOnUiThread(new Runnable() {
                public void run() {
                    if (isFinishing()) { latch.countDown(); return; }
                    new AlertDialog.Builder(MainActivity.this)
                            .setTitle("دسترسی به اینترنت")
                            .setMessage("امینو می‌خواهد برای بارگذاری فونت‌ها و موتور تشخیص متن (OCR) به اینترنت وصل شود. اجازه می‌دهید؟\n\n(لینک رهگیری پست در مرورگر گوشی باز می‌شود و به این اجازه نیاز ندارد.)")
                            .setCancelable(false)
                            .setPositiveButton("اجازه", new android.content.DialogInterface.OnClickListener() {
                                public void onClick(android.content.DialogInterface d, int w) {
                                    net = 1;
                                    sp.edit().putBoolean("net", true).apply();
                                    netDone(latch);
                                }
                            })
                            .setNegativeButton("نه", new android.content.DialogInterface.OnClickListener() {
                                public void onClick(android.content.DialogInterface d, int w) {
                                    net = -1;
                                    netDone(latch);
                                }
                            })
                            .show();
                }
            });
            try { latch.await(180, TimeUnit.SECONDS); } catch (InterruptedException e) { /* ignore */ }
            netDialogShowing = false;
            return net == 1;
        }
    }

    void netDone(CountDownLatch latch) {
        latch.countDown();
        netDialogShowing = false;
        if (pendingPerms) { pendingPerms = false; maybeAskPerms(); }
    }

    // ------------------------------------------------------- runtime permissions

    void maybeAskPerms() {
        if (sp.getBoolean("asked", false) || Build.VERSION.SDK_INT < 23) return;
        sp.edit().putBoolean("asked", true).apply();
        List<String> l = new ArrayList<String>();
        l.add(Manifest.permission.CAMERA);
        if (Build.VERSION.SDK_INT >= 33) {
            l.add("android.permission.READ_MEDIA_IMAGES");
        } else {
            l.add(Manifest.permission.READ_EXTERNAL_STORAGE);
            if (Build.VERSION.SDK_INT <= 28) l.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
        }
        l.add(Manifest.permission.READ_SMS);
        l.add(Manifest.permission.READ_CONTACTS);
        l.add(Manifest.permission.READ_CALL_LOG);
        List<String> need = new ArrayList<String>();
        for (String p : l) if (!has(p)) need.add(p);
        if (!need.isEmpty()) requestPermissions(need.toArray(new String[0]), RC_PERM);
    }

    final Runnable askRunnable = new Runnable() {
        public void run() {
            if (isFinishing() || sp.getBoolean("asked", false)) return;
            if (netDialogShowing) { pendingPerms = true; return; }
            maybeAskPerms();
        }
    };

    @Override
    public void onRequestPermissionsResult(int rc, String[] p, int[] g) {
        if (rc == RC_CAM) {
            WebChromeClient.FileChooserParams pp = pendParams;
            pendParams = null;
            if (fileCb != null && pp != null) launchChooser(pp);
        }
    }

    // ----------------------------------------------------------- web view client

    class Client extends WebViewClient {
        @Override
        public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
            Uri u = r.getUrl();
            String h = u.getHost();
            if (HOST.equals(h)) {
                String p = u.getPath();
                if (p == null || p.equals("/") || p.equals("/index.html")) {
                    try {
                        HashMap<String, String> hd = new HashMap<String, String>();
                        hd.put("Cache-Control", "no-cache");
                        return new WebResourceResponse("text/html", "utf-8", 200, "OK", hd,
                                getAssets().open("index.html"));
                    } catch (IOException e) { /* fall through */ }
                }
                return empty(404, "Not Found");
            }
            String sc = u.getScheme();
            if ("http".equals(sc) || "https".equals(sc)) {
                if (!netOk()) return empty(403, "Blocked");
            }
            return null;
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
            Uri u = r.getUrl();
            String sc = u.getScheme();
            if (HOST.equals(u.getHost()) || "blob".equals(sc) || "data".equals(sc)
                    || "about".equals(sc) || "javascript".equals(sc)) return false;
            openExt(u);
            return true;
        }

        @Override
        public void onPageStarted(WebView v, String url, android.graphics.Bitmap f) {
            v.evaluateJavascript(bridgeJs, null);
        }

        @Override
        public void onPageFinished(WebView v, String url) {
            v.evaluateJavascript(bridgeJs, null);
            if (!sp.getBoolean("asked", false)) v.postDelayed(askRunnable, 1200);
        }
    }

    // --------------------------------------------------------- chrome client

    class Chrome extends WebChromeClient {

        @Override
        public boolean onCreateWindow(WebView v, boolean dialog, boolean user, Message msg) {
            final WebView t = new WebView(MainActivity.this);
            t.setWebViewClient(new WebViewClient() {
                boolean done;
                void go(WebView w, Uri u) {
                    if (done) return;
                    done = true;
                    w.stopLoading();
                    openExt(u);
                }
                @Override
                public boolean shouldOverrideUrlLoading(WebView w, WebResourceRequest r) {
                    go(w, r.getUrl());
                    return true;
                }
                @Override
                public void onPageStarted(WebView w, String url, android.graphics.Bitmap f) {
                    if (url != null && !url.equals("about:blank")) go(w, Uri.parse(url));
                }
            });
            ((WebView.WebViewTransport) msg.obj).setWebView(t);
            msg.sendToTarget();
            t.postDelayed(new Runnable() {
                public void run() { try { t.destroy(); } catch (Exception e) { /* ignore */ } }
            }, 8000);
            return true;
        }

        @Override
        public boolean onJsAlert(WebView v, String url, String m, final JsResult r) {
            if (isFinishing()) { r.cancel(); return true; }
            new AlertDialog.Builder(MainActivity.this).setMessage(m).setCancelable(false)
                    .setPositiveButton("باشه", new android.content.DialogInterface.OnClickListener() {
                        public void onClick(android.content.DialogInterface d, int w) { r.confirm(); }
                    }).show();
            return true;
        }

        @Override
        public boolean onJsConfirm(WebView v, String url, String m, final JsResult r) {
            if (isFinishing()) { r.cancel(); return true; }
            new AlertDialog.Builder(MainActivity.this).setMessage(m).setCancelable(false)
                    .setPositiveButton("تأیید", new android.content.DialogInterface.OnClickListener() {
                        public void onClick(android.content.DialogInterface d, int w) { r.confirm(); }
                    })
                    .setNegativeButton("انصراف", new android.content.DialogInterface.OnClickListener() {
                        public void onClick(android.content.DialogInterface d, int w) { r.cancel(); }
                    }).show();
            return true;
        }

        @Override
        public boolean onJsPrompt(WebView v, String url, String m, String def, final JsPromptResult r) {
            if (isFinishing()) { r.cancel(); return true; }
            final EditText et = new EditText(MainActivity.this);
            et.setText(def == null ? "" : def);
            new AlertDialog.Builder(MainActivity.this).setMessage(m).setView(et).setCancelable(false)
                    .setPositiveButton("تأیید", new android.content.DialogInterface.OnClickListener() {
                        public void onClick(android.content.DialogInterface d, int w) { r.confirm(et.getText().toString()); }
                    })
                    .setNegativeButton("انصراف", new android.content.DialogInterface.OnClickListener() {
                        public void onClick(android.content.DialogInterface d, int w) { r.cancel(); }
                    }).show();
            return true;
        }

        @Override
        public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
            if (fileCb != null) fileCb.onReceiveValue(null);
            fileCb = cb;
            if (p.isCaptureEnabled() && !has(Manifest.permission.CAMERA) && Build.VERSION.SDK_INT >= 23) {
                pendParams = p;
                requestPermissions(new String[]{Manifest.permission.CAMERA}, RC_CAM);
                return true;
            }
            launchChooser(p);
            return true;
        }
    }

    // ------------------------------------------------------------ file chooser

    Intent camIntent() {
        camUri = null;
        try {
            ContentValues cv = new ContentValues();
            cv.put(MediaStore.Images.Media.DISPLAY_NAME, "amino_" + System.currentTimeMillis() + ".jpg");
            cv.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
            if (Build.VERSION.SDK_INT >= 29) cv.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Amino");
            camUri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv);
        } catch (Exception e) {
            camUri = null;
        }
        if (camUri == null) return null;
        Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        i.putExtra(MediaStore.EXTRA_OUTPUT, camUri);
        i.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
        return i;
    }

    void launchChooser(WebChromeClient.FileChooserParams p) {
        String[] acc = p.getAcceptTypes();
        boolean img = acc != null && acc.length > 0;
        if (img) for (String a : acc) if (a == null || !a.startsWith("image/")) img = false;

        Intent pick = new Intent(Intent.ACTION_GET_CONTENT);
        pick.addCategory(Intent.CATEGORY_OPENABLE);
        pick.setType(img ? "image/*" : "*/*");
        pick.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, p.getMode() == WebChromeClient.FileChooserParams.MODE_OPEN_MULTIPLE);

        Intent cam = null;
        if ((p.isCaptureEnabled() || img) && has(Manifest.permission.CAMERA)) cam = camIntent();

        Intent go;
        if (p.isCaptureEnabled() && cam != null) {
            go = cam;
        } else {
            go = Intent.createChooser(pick, null);
            if (cam != null) go.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{cam});
        }
        try {
            startActivityForResult(go, RC_FILE);
        } catch (Exception e) {
            finishFile(null);
        }
    }

    void finishFile(Uri[] res) {
        if (fileCb != null) fileCb.onReceiveValue(res);
        fileCb = null;
    }

    @Override
    protected void onActivityResult(int rc, int code, Intent data) {
        if (rc != RC_FILE) { super.onActivityResult(rc, code, data); return; }
        Uri[] res = WebChromeClient.FileChooserParams.parseResult(code, data);
        boolean fromCam = false;
        if (code == RESULT_OK && res == null && camUri != null) {
            res = new Uri[]{camUri};
            fromCam = true;
        }
        if (!fromCam && camUri != null) {
            try { getContentResolver().delete(camUri, null, null); } catch (Exception e) { /* ignore */ }
        }
        camUri = null;
        finishFile(res);
    }

    // ------------------------------------------------------------- JS bridge

    class Bridge {
        @JavascriptInterface
        public void begin(String name, String mime) {
            closeOut(false);
            try {
                String n = (name == null || name.length() == 0) ? "amino.bin"
                        : name.replaceAll("[\\\\/:*?\"<>|]", "_");
                if (mime == null || mime.length() == 0) mime = "application/octet-stream";
                savedName = n;
                if (Build.VERSION.SDK_INT >= 29) {
                    ContentValues cv = new ContentValues();
                    cv.put(MediaStore.Downloads.DISPLAY_NAME, n);
                    cv.put(MediaStore.Downloads.MIME_TYPE, mime);
                    cv.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                    Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                    out = getContentResolver().openOutputStream(u);
                } else {
                    File d = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                    d.mkdirs();
                    File f = new File(d, n);
                    int i = 1;
                    while (f.exists()) f = new File(d, (i++) + "_" + n);
                    out = new FileOutputStream(f);
                }
            } catch (Exception e) {
                out = null;
                toast("ذخیره فایل ممکن نشد (دسترسی حافظه را بررسی کنید)");
            }
        }

        @JavascriptInterface
        public void chunk(String b64) {
            if (out == null) return;
            try {
                out.write(Base64.decode(b64, Base64.DEFAULT));
            } catch (Exception e) {
                closeOut(false);
                toast("ذخیره فایل ناقص ماند");
            }
        }

        @JavascriptInterface
        public void end() {
            closeOut(true);
        }

        @JavascriptInterface
        public void shareText(final String title, final String text) {
            runOnUiThread(new Runnable() {
                public void run() {
                    try {
                        Intent i = new Intent(Intent.ACTION_SEND);
                        i.setType("text/plain");
                        i.putExtra(Intent.EXTRA_SUBJECT, title);
                        i.putExtra(Intent.EXTRA_TEXT, text);
                        startActivity(Intent.createChooser(i, null));
                    } catch (Exception e) { /* ignore */ }
                }
            });
        }
    }

    void closeOut(boolean ok) {
        if (out == null) return;
        try { out.flush(); out.close(); } catch (Exception e) { ok = false; }
        out = null;
        if (ok) toast("ذخیره شد در پوشه Downloads: " + savedName);
    }

    // --------------------------------------------------------------- lifecycle

    @Override
    protected void onSaveInstanceState(Bundle b) {
        super.onSaveInstanceState(b);
        wv.saveState(b);
    }

    @Override
    protected void onPause() {
        wv.evaluateJavascript("try{window.dispatchEvent(new Event('pagehide'))}catch(e){}", null);
        wv.onPause();
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        wv.onResume();
    }

    @Override
    public void onBackPressed() {
        if (wv.canGoBack()) wv.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        closeOut(false);
        wv.destroy();
        super.onDestroy();
    }
}
