package ir.amino.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.UriPermission;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Message;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.Base64;
import android.webkit.DownloadListener;
import android.webkit.JavascriptInterface;
import android.webkit.JsPromptResult;
import android.webkit.JsResult;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

public class MainActivity extends Activity {

    static final String HOST = "appassets.androidplatform.net";
    static final String HOME = "https://" + HOST + "/index.html";
    static final int RC_FILE = 1, RC_PERM = 2, RC_CAM = 3, RC_DIR = 4;
    static final int BG = 0xFFE9EEF3;

    WebView wv, printWv;
    SharedPreferences sp;
    String bridgeJs = "";
    byte[] htmlCache;
    boolean permsPosted;

    // internet gate: 0 = not asked yet, 1 = allowed, -1 = denied (this session)
    volatile int net;
    final Object askLock = new Object();
    volatile boolean netDialogShowing;
    boolean pendingPerms;

    ValueCallback<Uri[]> fileCb;
    WebChromeClient.FileChooserParams pendParams;
    Uri camUri;
    int dirReq;

    OutputStream out, wout, sOut;
    String savedName = "";
    final List<String> shNames = new ArrayList<String>();
    final List<String> shMimes = new ArrayList<String>();
    String shMime = "application/octet-stream";

    // ------------------------------------------------------------------ create

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        sp = getSharedPreferences("a", 0);
        net = sp.getBoolean("net", false) ? 1 : 0;
        try {
            bridgeJs = new String(readAll(getAssets().open("bridge.js")), StandardCharsets.UTF_8);
        } catch (Exception e) { /* ignore */ }

        wv = new WebView(this);
        wv.setBackgroundColor(BG);
        setContentView(wv);

        WebSettings s = wv.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setTextZoom(100);
        s.setMediaPlaybackRequiresUserGesture(true);
        s.setSupportMultipleWindows(true);
        s.setJavaScriptCanOpenWindowsAutomatically(true);

        wv.addJavascriptInterface(new Bridge(), "AminoBridge");
        wv.setWebViewClient(new Client());
        wv.setWebChromeClient(new Chrome());
        wv.setDownloadListener(new DownloadListener() {
            public void onDownloadStart(String url, String ua, String cd, String mime, long len) {
                if (url.startsWith("blob:")) {
                    String nm = URLUtil.guessFileName(url, cd, mime);
                    js("window.__amBlob&&window.__amBlob(" + JSONObject.quote(url) + "," + JSONObject.quote(nm) + ")");
                } else {
                    openExt(Uri.parse(url));
                }
            }
        });

        if (b != null) wv.restoreState(b);
        if (wv.getUrl() == null) wv.loadUrl(HOME);
    }

    // ------------------------------------------------------------------ helpers

    static byte[] readAll(InputStream is) throws IOException {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        byte[] b = new byte[16384];
        int n;
        while ((n = is.read(b)) > 0) o.write(b, 0, n);
        is.close();
        return o.toByteArray();
    }

    /** index.html with the bridge script inserted right after <head>, so it runs before the page's own code. */
    synchronized byte[] html() throws IOException {
        if (htmlCache != null) return htmlCache;
        byte[] raw = readAll(getAssets().open("index.html"));
        byte[] tag = "<head>".getBytes(StandardCharsets.UTF_8);
        int at = -1;
        int lim = Math.min(raw.length - tag.length, 4000);
        for (int i = 0; i <= lim && at < 0; i++) {
            boolean ok = true;
            for (int j = 0; j < tag.length; j++) if (raw[i + j] != tag[j]) { ok = false; break; }
            if (ok) at = i;
        }
        if (at < 0 || bridgeJs.length() == 0) { htmlCache = raw; return raw; }
        ByteArrayOutputStream o = new ByteArrayOutputStream(raw.length + bridgeJs.length() + 32);
        int cut = at + tag.length;
        o.write(raw, 0, cut);
        o.write("<script>".getBytes(StandardCharsets.UTF_8));
        o.write(bridgeJs.getBytes(StandardCharsets.UTF_8));
        o.write("</script>".getBytes(StandardCharsets.UTF_8));
        o.write(raw, cut, raw.length - cut);
        htmlCache = o.toByteArray();
        return htmlCache;
    }

    boolean has(String p) {
        return Build.VERSION.SDK_INT < 23 || checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED;
    }

    void toast(final String t) {
        runOnUiThread(new Runnable() {
            public void run() { Toast.makeText(MainActivity.this, t, Toast.LENGTH_LONG).show(); }
        });
    }

    void js(final String code) {
        runOnUiThread(new Runnable() {
            public void run() { if (wv != null) wv.evaluateJavascript(code, null); }
        });
    }

    void openExt(Uri u) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, u));
        } catch (ActivityNotFoundException e) {
            toast("برنامه‌ای برای باز کردن این لینک پیدا نشد");
        } catch (Exception e) { /* ignore */ }
    }

    WebResourceResponse empty(int code, String msg) {
        return new WebResourceResponse("text/plain", "utf-8", code, msg,
                new HashMap<String, String>(), new ByteArrayInputStream(new byte[0]));
    }

    static String cleanName(String name, String def) {
        String n = (name == null || name.length() == 0) ? def : name.replaceAll("[\\\\/:*?\"<>|]", "_");
        return n;
    }

    // ------------------------------------------------------- internet permission

    boolean netOk() {
        if (net == 1) return true;
        if (net == -1) return false;
        synchronized (askLock) {
            if (net != 0) return net == 1;
            final CountDownLatch latch = new CountDownLatch(1);
            netDialogShowing = true;
            runOnUiThread(new Runnable() {
                public void run() {
                    if (isFinishing()) { latch.countDown(); return; }
                    new AlertDialog.Builder(MainActivity.this)
                            .setTitle("دسترسی به اینترنت")
                            .setMessage("امینو می‌خواهد برای بارگذاری فونت‌ها و موتور تشخیص متن (OCR) به اینترنت وصل شود. اجازه می‌دهید؟\n\n(لینک رهگیری پست در مرورگر گوشی باز می‌شود و به این اجازه نیاز ندارد.)")
                            .setCancelable(false)
                            .setPositiveButton("اجازه", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface d, int w) {
                                    net = 1;
                                    sp.edit().putBoolean("net", true).apply();
                                    netDone(latch);
                                }
                            })
                            .setNegativeButton("نه", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface d, int w) {
                                    net = -1;
                                    netDone(latch);
                                }
                            })
                            .show();
                }
            });
            try { latch.await(180, TimeUnit.SECONDS); } catch (InterruptedException e) { /* ignore */ }
            netDialogShowing = false;
            return net == 1;
        }
    }

    void netDone(CountDownLatch latch) {
        latch.countDown();
        netDialogShowing = false;
        if (pendingPerms) { pendingPerms = false; askMissing(); }
    }

    // ------------------------------------------------------- runtime permissions

    List<String> wanted() {
        List<String> l = new ArrayList<String>();
        l.add(Manifest.permission.CAMERA);
        if (Build.VERSION.SDK_INT >= 33) {
            l.add("android.permission.READ_MEDIA_IMAGES");
        } else {
            l.add(Manifest.permission.READ_EXTERNAL_STORAGE);
            if (Build.VERSION.SDK_INT <= 28) l.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
        }
        l.add(Manifest.permission.READ_SMS);
        l.add(Manifest.permission.READ_CONTACTS);
        l.add(Manifest.permission.READ_CALL_LOG);
        return l;
    }

    /** Asks for every permission that is still missing; each one at most twice in total (Android stops showing it after that anyway). */
    void askMissing() {
        if (Build.VERSION.SDK_INT < 23 || isFinishing()) return;
        List<String> need = new ArrayList<String>();
        for (String p : wanted()) {
            int n = sp.getInt("n_" + p, 0);
            if (!has(p) && n < 2) {
                need.add(p);
                sp.edit().putInt("n_" + p, n + 1).apply();
            }
        }
        if (!need.isEmpty()) requestPermissions(need.toArray(new String[0]), RC_PERM);
    }

    final Runnable askRunnable = new Runnable() {
        public void run() {
            if (isFinishing()) return;
            if (netDialogShowing) { pendingPerms = true; return; }
            askMissing();
        }
    };

    @Override
    public void onRequestPermissionsResult(int rc, String[] p, int[] g) {
        if (rc == RC_CAM) {
            WebChromeClient.FileChooserParams pp = pendParams;
            pendParams = null;
            if (fileCb == null || pp == null) return;
            if (has(Manifest.permission.CAMERA)) { launchChooser(pp); return; }
            camDenied(pp);
        }
    }

    void camDenied(final WebChromeClient.FileChooserParams pp) {
        if (Build.VERSION.SDK_INT >= 23 && !shouldShowRequestPermissionRationale(Manifest.permission.CAMERA)) {
            new AlertDialog.Builder(this)
                    .setTitle("دسترسی دوربین بسته است")
                    .setMessage("برای عکس گرفتن، دسترسی دوربین را از تنظیمات برنامه روشن کن.")
                    .setCancelable(false)
                    .setPositiveButton("تنظیمات", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface d, int w) {
                            try {
                                startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                        Uri.fromParts("package", getPackageName(), null)));
                            } catch (Exception e) { /* ignore */ }
                            finishFile(null);
                        }
                    })
                    .setNegativeButton("انتخاب از گالری", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface d, int w) { launchChooser(pp); }
                    }).show();
        } else {
            launchChooser(pp);
        }
    }

    // ----------------------------------------------------------- web view client

    class Client extends WebViewClient {
        @Override
        public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
            Uri u = r.getUrl();
            String h = u.getHost();
            if (HOST.equals(h)) {
                String p = u.getPath();
                if (p == null || p.equals("/") || p.equals("/index.html")) {
                    try {
                        HashMap<String, String> hd = new HashMap<String, String>();
                        hd.put("Cache-Control", "no-cache");
                        return new WebResourceResponse("text/html", "utf-8", 200, "OK", hd,
                                new ByteArrayInputStream(html()));
                    } catch (IOException e) { /* fall through */ }
                }
                return empty(404, "Not Found");
            }
            String sc = u.getScheme();
            if ("http".equals(sc) || "https".equals(sc)) {
                if (!netOk()) return empty(403, "Blocked");
            }
            return null;
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
            Uri u = r.getUrl();
            String sc = u.getScheme();
            if (HOST.equals(u.getHost()) || "blob".equals(sc) || "data".equals(sc)
                    || "about".equals(sc) || "javascript".equals(sc)) return false;
            openExt(u);
            return true;
        }

        @Override
        public void onPageFinished(WebView v, String url) {
            // safety net: idempotent, does nothing if the script was already inserted into the page
            v.evaluateJavascript(bridgeJs, null);
            if (!permsPosted) {
                permsPosted = true;
                v.postDelayed(askRunnable, 1200);
            }
        }
    }

    // --------------------------------------------------------- chrome client

    class Chrome extends WebChromeClient {

        @Override
        public boolean onCreateWindow(WebView v, boolean dialog, boolean user, Message msg) {
            final WebView t = new WebView(MainActivity.this);
            t.setWebViewClient(new WebViewClient() {
                boolean done;
                void go(WebView w, Uri u) {
                    if (done) return;
                    done = true;
                    w.stopLoading();
                    openExt(u);
                }
                @Override
                public boolean shouldOverrideUrlLoading(WebView w, WebResourceRequest r) {
                    go(w, r.getUrl());
                    return true;
                }
                @Override
                public void onPageStarted(WebView w, String url, Bitmap f) {
                    if (url != null && !url.equals("about:blank")) go(w, Uri.parse(url));
                }
            });
            ((WebView.WebViewTransport) msg.obj).setWebView(t);
            msg.sendToTarget();
            t.postDelayed(new Runnable() {
                public void run() { try { t.destroy(); } catch (Exception e) { /* ignore */ } }
            }, 8000);
            return true;
        }

        @Override
        public boolean onJsAlert(WebView v, String url, String m, final JsResult r) {
            if (isFinishing()) { r.cancel(); return true; }
            new AlertDialog.Builder(MainActivity.this).setMessage(m).setCancelable(false)
                    .setPositiveButton("باشه", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface d, int w) { r.confirm(); }
                    }).show();
            return true;
        }

        @Override
        public boolean onJsConfirm(WebView v, String url, String m, final JsResult r) {
            if (isFinishing()) { r.cancel(); return true; }
            new AlertDialog.Builder(MainActivity.this).setMessage(m).setCancelable(false)
                    .setPositiveButton("تأیید", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface d, int w) { r.confirm(); }
                    })
                    .setNegativeButton("انصراف", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface d, int w) { r.cancel(); }
                    }).show();
            return true;
        }

        @Override
        public boolean onJsPrompt(WebView v, String url, String m, String def, final JsPromptResult r) {
            if (isFinishing()) { r.cancel(); return true; }
            final EditText et = new EditText(MainActivity.this);
            et.setText(def == null ? "" : def);
            new AlertDialog.Builder(MainActivity.this).setMessage(m).setView(et).setCancelable(false)
                    .setPositiveButton("تأیید", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface d, int w) { r.confirm(et.getText().toString()); }
                    })
                    .setNegativeButton("انصراف", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface d, int w) { r.cancel(); }
                    }).show();
            return true;
        }

        @Override
        public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
            if (fileCb != null) fileCb.onReceiveValue(null);
            fileCb = cb;
            if (p.isCaptureEnabled() && !has(Manifest.permission.CAMERA) && Build.VERSION.SDK_INT >= 23) {
                pendParams = p;
                requestPermissions(new String[]{Manifest.permission.CAMERA}, RC_CAM);
                return true;
            }
            launchChooser(p);
            return true;
        }
    }

    // ------------------------------------------------------------ file chooser

    Intent camIntent() {
        camUri = null;
        try {
            ContentValues cv = new ContentValues();
            cv.put(MediaStore.Images.Media.DISPLAY_NAME, "amino_" + System.currentTimeMillis() + ".jpg");
            cv.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
            if (Build.VERSION.SDK_INT >= 29) cv.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Amino");
            camUri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv);
        } catch (Exception e) {
            camUri = null;
        }
        if (camUri == null) return null;
        Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        i.putExtra(MediaStore.EXTRA_OUTPUT, camUri);
        i.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
        return i;
    }

    void launchChooser(WebChromeClient.FileChooserParams p) {
        String[] acc = p.getAcceptTypes();
        boolean img = acc != null && acc.length > 0;
        if (img) for (String a : acc) if (a == null || !a.startsWith("image/")) img = false;

        Intent pick = new Intent(Intent.ACTION_GET_CONTENT);
        pick.addCategory(Intent.CATEGORY_OPENABLE);
        pick.setType(img ? "image/*" : "*/*");
        pick.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, p.getMode() == WebChromeClient.FileChooserParams.MODE_OPEN_MULTIPLE);

        Intent cam = null;
        if (p.isCaptureEnabled() && has(Manifest.permission.CAMERA)) cam = camIntent();

        try {
            if (cam != null) {
                try {
                    startActivityForResult(cam, RC_FILE);
                    return;
                } catch (Exception e) {
                    // no camera app: fall back to the file picker below
                    toast("برنامه دوربین پیدا نشد؛ از فایل‌ها انتخاب کن");
                    deleteCamUri();
                }
            }
            startActivityForResult(Intent.createChooser(pick, null), RC_FILE);
        } catch (Exception e) {
            toast("باز کردن انتخاب فایل ممکن نشد: " + e.getMessage());
            finishFile(null);
        }
    }

    void deleteCamUri() {
        if (camUri != null) {
            try { getContentResolver().delete(camUri, null, null); } catch (Exception e) { /* ignore */ }
            camUri = null;
        }
    }

    void finishFile(Uri[] res) {
        ValueCallback<Uri[]> cb = fileCb;
        fileCb = null;
        if (cb != null) cb.onReceiveValue(res);
    }

    @Override
    protected void onActivityResult(int rc, int code, Intent data) {
        if (rc == RC_DIR) {
            int id = dirReq;
            if (code == RESULT_OK && data != null && data.getData() != null) {
                Uri t = data.getData();
                try {
                    getContentResolver().takePersistableUriPermission(t,
                            Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                } catch (Exception e) { /* ignore */ }
                js("window.__amR(" + id + ",1," + JSONObject.quote(t.toString()) + "," + JSONObject.quote(treeName(t)) + ")");
            } else {
                js("window.__amR(" + id + ",0,'','')");
            }
            return;
        }
        if (rc != RC_FILE) { super.onActivityResult(rc, code, data); return; }
        Uri[] res = WebChromeClient.FileChooserParams.parseResult(code, data);
        boolean fromCam = false;
        if (code == RESULT_OK && res == null && camUri != null) {
            res = new Uri[]{camUri};
            fromCam = true;
        }
        if (!fromCam) deleteCamUri();
        camUri = null;
        finishFile(res);
    }

    // ------------------------------------------------------- folder (SAF) helpers

    String treeName(Uri t) {
        Cursor c = null;
        try {
            Uri d = DocumentsContract.buildDocumentUriUsingTree(t, DocumentsContract.getTreeDocumentId(t));
            c = getContentResolver().query(d, new String[]{DocumentsContract.Document.COLUMN_DISPLAY_NAME}, null, null, null);
            if (c != null && c.moveToFirst()) return c.getString(0);
        } catch (Exception e) { /* ignore */ }
        finally { if (c != null) c.close(); }
        return "پوشه";
    }

    Uri dirDoc(String tree) {
        Uri t = Uri.parse(tree);
        return DocumentsContract.buildDocumentUriUsingTree(t, DocumentsContract.getTreeDocumentId(t));
    }

    String listTree(String tree) {
        JSONArray a = new JSONArray();
        Cursor c = null;
        try {
            Uri t = Uri.parse(tree);
            Uri ch = DocumentsContract.buildChildDocumentsUriUsingTree(t, DocumentsContract.getTreeDocumentId(t));
            c = getContentResolver().query(ch, new String[]{
                    DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                    DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                    DocumentsContract.Document.COLUMN_MIME_TYPE,
                    DocumentsContract.Document.COLUMN_LAST_MODIFIED}, null, null, null);
            while (c != null && c.moveToNext()) {
                JSONObject o = new JSONObject();
                o.put("n", c.getString(1));
                o.put("u", DocumentsContract.buildDocumentUriUsingTree(t, c.getString(0)).toString());
                o.put("d", DocumentsContract.Document.MIME_TYPE_DIR.equals(c.getString(2)));
                o.put("m", c.getLong(3));
                a.put(o);
            }
        } catch (Exception e) { /* ignore */ }
        finally { if (c != null) c.close(); }
        return a.toString();
    }

    String findInTree(String tree, String name) {
        try {
            JSONArray a = new JSONArray(listTree(tree));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                if (name.equals(o.getString("n"))) return o.getString("u");
            }
        } catch (Exception e) { /* ignore */ }
        return "";
    }

    static void closeQuiet(OutputStream o) {
        if (o == null) return;
        try { o.flush(); o.close(); } catch (Exception e) { /* ignore */ }
    }

    // ------------------------------------------------------------- JS bridge

    class Bridge {

        @JavascriptInterface
        public void msg(String t) { toast(t); }

        // ---- downloads -> Downloads folder
        @JavascriptInterface
        public void begin(String name, String mime) {
            closeOut(false);
            try {
                String n = cleanName(name, "amino.bin");
                if (mime == null || mime.length() == 0) mime = "application/octet-stream";
                savedName = n;
                if (Build.VERSION.SDK_INT >= 29) {
                    ContentValues cv = new ContentValues();
                    cv.put(MediaStore.Downloads.DISPLAY_NAME, n);
                    cv.put(MediaStore.Downloads.MIME_TYPE, mime);
                    cv.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                    Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                    out = getContentResolver().openOutputStream(u);
                } else {
                    File d = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                    d.mkdirs();
                    File f = new File(d, n);
                    int i = 1;
                    while (f.exists()) f = new File(d, (i++) + "_" + n);
                    out = new FileOutputStream(f);
                }
            } catch (Exception e) {
                out = null;
                toast("ذخیره فایل ممکن نشد (دسترسی حافظه را بررسی کنید)");
            }
        }

        @JavascriptInterface
        public void chunk(String b64) {
            if (out == null) return;
            try {
                out.write(Base64.decode(b64, Base64.DEFAULT));
            } catch (Exception e) {
                closeOut(false);
                toast("ذخیره فایل ناقص ماند");
            }
        }

        @JavascriptInterface
        public void end() { closeOut(true); }

        // ---- share
        @JavascriptInterface
        public void shareText(final String title, final String text) {
            runOnUiThread(new Runnable() {
                public void run() {
                    try {
                        Intent i = new Intent(Intent.ACTION_SEND);
                        i.setType("text/plain");
                        i.putExtra(Intent.EXTRA_SUBJECT, title);
                        i.putExtra(Intent.EXTRA_TEXT, text);
                        startActivity(Intent.createChooser(i, null));
                    } catch (Exception e) { /* ignore */ }
                }
            });
        }

        @JavascriptInterface
        public void shReset() {
            closeQuiet(sOut);
            sOut = null;
            shNames.clear();
            shMimes.clear();
            File d = new File(getCacheDir(), "share");
            File[] old = d.listFiles();
            if (old != null) for (File f : old) f.delete();
        }

        @JavascriptInterface
        public void shFile(String name, String mime) {
            closeQuiet(sOut);
            sOut = null;
            try {
                File d = new File(getCacheDir(), "share");
                d.mkdirs();
                String n = cleanName(name, "amino.bin");
                sOut = new FileOutputStream(new File(d, n));
                shNames.add(n);
                shMimes.add(mime == null || mime.length() == 0 ? "application/octet-stream" : mime);
            } catch (Exception e) {
                sOut = null;
                toast("آماده‌سازی فایل برای اشتراک‌گذاری ممکن نشد");
            }
        }

        @JavascriptInterface
        public void shChunk(String b64) {
            if (sOut == null) return;
            try { sOut.write(Base64.decode(b64, Base64.DEFAULT)); } catch (Exception e) { closeQuiet(sOut); sOut = null; }
        }

        @JavascriptInterface
        public void shEnd() {
            closeQuiet(sOut);
            sOut = null;
        }

        @JavascriptInterface
        public void shGo(final String title, final String text) {
            runOnUiThread(new Runnable() {
                public void run() {
                    try {
                        if (shNames.isEmpty()) return;
                        ArrayList<Uri> uris = new ArrayList<Uri>();
                        for (String n : shNames) {
                            uris.add(new Uri.Builder().scheme("content").authority("ir.amino.app.share").appendPath(n).build());
                        }
                        Intent i;
                        if (uris.size() == 1) {
                            i = new Intent(Intent.ACTION_SEND);
                            i.setType(shMimes.get(0));
                            i.putExtra(Intent.EXTRA_STREAM, uris.get(0));
                        } else {
                            i = new Intent(Intent.ACTION_SEND_MULTIPLE);
                            i.setType("*/*");
                            i.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris);
                        }
                        if (title != null && title.length() > 0) i.putExtra(Intent.EXTRA_SUBJECT, title);
                        if (text != null && text.length() > 0) i.putExtra(Intent.EXTRA_TEXT, text);
                        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        startActivity(Intent.createChooser(i, null));
                    } catch (Exception e) {
                        toast("اشتراک‌گذاری ممکن نشد");
                    }
                }
            });
        }

        // ---- print / save as PDF
        @JavascriptInterface
        public void printHtml(final String html, final String title) {
            runOnUiThread(new Runnable() {
                public void run() {
                    try {
                        final String jn = (title == null || title.length() == 0) ? "Amino" : title;
                        final WebView p = new WebView(MainActivity.this);
                        printWv = p;
                        p.setWebViewClient(new Client() {
                            @Override
                            public void onPageFinished(WebView v, String url) {
                                try {
                                    PrintManager pm = (PrintManager) getSystemService(Context.PRINT_SERVICE);
                                    pm.print(jn, v.createPrintDocumentAdapter(jn), new PrintAttributes.Builder().build());
                                } catch (Exception e) {
                                    toast("چاپ ممکن نشد");
                                }
                            }
                        });
                        p.loadDataWithBaseURL("https://" + HOST + "/print", html, "text/html", "utf-8", null);
                    } catch (Exception e) {
                        toast("چاپ ممکن نشد");
                    }
                }
            });
        }

        // ---- backup folder (SAF)
        @JavascriptInterface
        public void fsPick(final int id) {
            runOnUiThread(new Runnable() {
                public void run() {
                    dirReq = id;
                    Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
                    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                            | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION | Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);
                    try {
                        startActivityForResult(i, RC_DIR);
                    } catch (Exception e) {
                        toast("انتخاب پوشه در این گوشی ممکن نیست");
                        js("window.__amR(" + id + ",0,'','')");
                    }
                }
            });
        }

        @JavascriptInterface
        public boolean fsHas(String tree) {
            try {
                for (UriPermission p : getContentResolver().getPersistedUriPermissions()) {
                    if (p.getUri().toString().equals(tree) && p.isWritePermission()) return true;
                }
            } catch (Exception e) { /* ignore */ }
            return false;
        }

        @JavascriptInterface
        public String fsList(String tree) { return listTree(tree); }

        @JavascriptInterface
        public String fsFind(String tree, String name) { return findInTree(tree, name); }

        @JavascriptInterface
        public String fsCreate(String tree, String name) {
            try {
                Uri u = DocumentsContract.createDocument(getContentResolver(), dirDoc(tree),
                        "application/octet-stream", name);
                return u == null ? "" : u.toString();
            } catch (Exception e) {
                return "";
            }
        }

        @JavascriptInterface
        public void fsDel(String tree, String name) {
            try {
                String u = findInTree(tree, name);
                if (u.length() > 0) DocumentsContract.deleteDocument(getContentResolver(), Uri.parse(u));
            } catch (Exception e) { /* ignore */ }
        }

        @JavascriptInterface
        public String fsLm(String uri) {
            Cursor c = null;
            try {
                c = getContentResolver().query(Uri.parse(uri),
                        new String[]{DocumentsContract.Document.COLUMN_LAST_MODIFIED}, null, null, null);
                if (c != null && c.moveToFirst()) return String.valueOf(c.getLong(0));
            } catch (Exception e) { /* ignore */ }
            finally { if (c != null) c.close(); }
            return "0";
        }

        @JavascriptInterface
        public String fsWBegin(String uri) {
            closeQuiet(wout);
            wout = null;
            try {
                wout = getContentResolver().openOutputStream(Uri.parse(uri), "wt");
                return wout == null ? "0" : "1";
            } catch (Exception e) {
                wout = null;
                return "0";
            }
        }

        @JavascriptInterface
        public void fsWChunk(String b64) {
            if (wout == null) return;
            try { wout.write(Base64.decode(b64, Base64.DEFAULT)); } catch (Exception e) { closeQuiet(wout); wout = null; }
        }

        @JavascriptInterface
        public void fsWEnd() {
            closeQuiet(wout);
            wout = null;
        }
    }

    void closeOut(boolean ok) {
        if (out == null) return;
        try { out.flush(); out.close(); } catch (Exception e) { ok = false; }
        out = null;
        if (ok) toast("ذخیره شد در پوشه Downloads: " + savedName);
    }

    // --------------------------------------------------------------- lifecycle

    @Override
    protected void onSaveInstanceState(Bundle b) {
        super.onSaveInstanceState(b);
        wv.saveState(b);
    }

    @Override
    public void onBackPressed() {
        if (wv.canGoBack()) wv.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        closeOut(false);
        closeQuiet(wout);
        closeQuiet(sOut);
        wv.destroy();
        super.onDestroy();
    }
}
