(function(){
if(window.__am||!window.AminoBridge)return;window.__am=1;
var B=window.AminoBridge,CH=589824;
function msg(t){try{B.msg(t)}catch(e){}}
/* read a Blob/File in slices (multiple of 3 bytes) and push base64 chunks to native */
function pump(b,sink){return new Promise(function(res,rej){
 var p=0;
 function nx(){
  if(p>=b.size){try{sink.end()}catch(e){return rej(e)}return res()}
  var fr=new FileReader();
  fr.onload=function(){try{var s=String(fr.result);sink.chunk(s.slice(s.indexOf(',')+1))}catch(e){return rej(e)}p+=CH;nx()};
  fr.onerror=function(){rej(fr.error)};
  fr.readAsDataURL(b.slice(p,p+CH))}
 try{sink.begin()}catch(e){return rej(e)}
 nx()})}

/* ---------- downloads (blob links -> Downloads folder) ---------- */
function saveBlob(b,name){return pump(b,{
 begin:function(){B.begin(name,b.type||'application/octet-stream')},
 chunk:function(s){B.chunk(s)},
 end:function(){B.end()}})}
window.__amBlob=function(url,name){return fetch(url).then(function(r){return r.blob()}).then(function(b){return saveBlob(b,name||'amino')})};
var oc=HTMLElement.prototype.click;
HTMLAnchorElement.prototype.click=function(){var a=this;
 if(a.hasAttribute('download')&&/^blob:/.test(a.href)){
  window.__amBlob(a.href,a.getAttribute('download')).catch(function(){msg('ذخیره فایل ممکن نشد')});return}
 return oc.apply(this,arguments)};
document.addEventListener('click',function(e){
 var a=e.target&&e.target.closest?e.target.closest('a[download]'):null;
 if(a&&/^blob:/.test(a.href)){e.preventDefault();
  window.__amBlob(a.href,a.getAttribute('download')).catch(function(){msg('ذخیره فایل ممکن نشد')})}},true);

/* ---------- share (text + files) ---------- */
navigator.canShare=function(d){return !!d&&!!((d.files&&d.files.length)||d.text||d.url||d.title)};
navigator.share=function(d){d=d||{};
 if(d.files&&d.files.length){
  B.shReset();
  var fs=Array.prototype.slice.call(d.files),i=0;
  return (function nxt(){
   if(i>=fs.length){B.shGo(d.title||'',d.text||'');return Promise.resolve()}
   var f=fs[i++];
   return pump(f,{
    begin:function(){B.shFile(f.name,f.type||'application/octet-stream')},
    chunk:function(s){B.shChunk(s)},
    end:function(){B.shEnd()}}).then(nxt)})();
 }
 B.shareText(d.title||'',d.text||d.url||'');return Promise.resolve()};

/* ---------- print / PDF ---------- */
function html(w){return '<!doctype html>'+w.document.documentElement.outerHTML}
window.print=function(){B.printHtml(html(window),document.title||'Amino')};
try{
 var cw=Object.getOwnPropertyDescriptor(HTMLIFrameElement.prototype,'contentWindow');
 Object.defineProperty(HTMLIFrameElement.prototype,'contentWindow',{configurable:true,get:function(){
  var w=cw.get.call(this);
  try{if(w&&!w.__amp){w.__amp=1;Object.defineProperty(w,'print',{configurable:true,writable:true,value:function(){B.printHtml(html(w),w.document.title||document.title||'Amino')}})}}catch(e){}
  return w}});
}catch(e){}

/* ---------- backup folder (File System Access API on top of Android SAF) ---------- */
var P={},PN=0;
window.__amR=function(id,ok,uri,name){var p=P[id];delete P[id];if(!p)return;
 if(ok)p[0](new DH(uri,name));else p[1](new DOMException('canceled','AbortError'))};
function FH(tree,name,uri){this.kind='file';this.name=name;this.uri=uri;this.tree=tree}
FH.prototype.getFile=function(){var lm=parseInt(B.fsLm(this.uri))||0;return Promise.resolve(new File([],this.name,{lastModified:lm}))};
FH.prototype.createWritable=function(){var u=this.uri;
 if(B.fsWBegin(u)!=='1')return Promise.reject(new DOMException('cannot write','NotAllowedError'));
 return Promise.resolve({
  write:function(d){var b=(d instanceof Blob)?d:new Blob([d]);
   return pump(b,{begin:function(){},chunk:function(s){B.fsWChunk(s)},end:function(){}})},
  close:function(){B.fsWEnd();return Promise.resolve()}})};
function DH(uri,name){this.kind='directory';this.name=name;this.uri=uri;this.__saf=1}
DH.prototype.queryPermission=function(){return Promise.resolve(B.fsHas(this.uri)?'granted':'denied')};
DH.prototype.requestPermission=DH.prototype.queryPermission;
DH.prototype.getFileHandle=function(n,o){
 var u=B.fsFind(this.uri,n);
 if(!u&&o&&o.create)u=B.fsCreate(this.uri,n);
 if(!u)return Promise.reject(new DOMException('not found','NotFoundError'));
 return Promise.resolve(new FH(this.uri,n,u))};
DH.prototype.removeEntry=function(n){B.fsDel(this.uri,n);return Promise.resolve()};
DH.prototype.entries=function(){
 var l=[];try{l=JSON.parse(B.fsList(this.uri))}catch(e){}
 var t=this.uri,o={};
 o[Symbol.asyncIterator]=function(){var i=0;return{next:function(){
  if(i>=l.length)return Promise.resolve({done:true,value:undefined});
  var x=l[i++];
  return Promise.resolve({done:false,value:[x.n,x.d?{kind:'directory',name:x.n}:new FH(t,x.n,x.u)]})}}};
 return o};
window.showDirectoryPicker=function(){return new Promise(function(res,rej){var id=++PN;P[id]=[res,rej];B.fsPick(id)})};
/* handles stored in IndexedDB come back as plain objects: give them their methods again */
try{var og=IDBObjectStore.prototype.get;
 IDBObjectStore.prototype.get=function(){var r=og.apply(this,arguments);
  r.addEventListener('success',function(){var v=r.result;if(v&&v.__saf&&v.kind==='directory')Object.setPrototypeOf(v,DH.prototype)});
  return r}}catch(e){}
})();
