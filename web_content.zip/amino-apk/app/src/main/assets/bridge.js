(function(){if(window.__am)return;window.__am=1;
var oc=HTMLAnchorElement.prototype.click;
HTMLAnchorElement.prototype.click=function(){var a=this;
 if(a.hasAttribute('download')&&/^blob:/.test(a.href)){
  fetch(a.href).then(function(r){return r.blob()}).then(function(b){
   var fr=new FileReader();fr.onload=function(){
    var s=String(fr.result);s=s.slice(s.indexOf(',')+1);
    AminoBridge.begin(a.getAttribute('download')||'amino',b.type||'application/octet-stream');
    for(var p=0;p<s.length;p+=786432)AminoBridge.chunk(s.slice(p,p+786432));
    AminoBridge.end()};
   fr.readAsDataURL(b)}).catch(function(){oc.call(a)});
  return}
 return oc.apply(this,arguments)};
if(!navigator.share)navigator.share=function(d){
 if(!d||(d.files&&d.files.length))return Promise.reject(new TypeError('NotSupported'));
 AminoBridge.shareText(d.title||'',d.text||d.url||'');return Promise.resolve()};
})();
