// Run after "npx cap add android" and before "npx cap sync android".
// Each step is independent: a failure only prints a warning and the build continues.
const fs = require('fs'), path = require('path'), os = require('os');
const root = path.join(__dirname, '..');
const main = path.join(root, 'android', 'app', 'src', 'main');
const res = path.join(main, 'res');
const step = (name, fn) => { try { fn(); console.log('OK  ', name); } catch (e) { console.log('WARN', name, '-', e.message); } };

step('camera permission + turn off Google auto-backup', () => {
  const f = path.join(main, 'AndroidManifest.xml');
  let s = fs.readFileSync(f, 'utf8');
  if (!s.includes('android.permission.CAMERA')) {
    s = s.replace('</manifest>',
      '    <uses-permission android:name="android.permission.CAMERA" />\n' +
      '    <uses-feature android:name="android.hardware.camera" android:required="false" />\n</manifest>');
  }
  s = s.replace(/android:allowBackup="true"/, 'android:allowBackup="false"');
  fs.writeFileSync(f, s);
});

step('launcher icon', () => {
  const src = path.join(root, 'assets', 'icons');
  for (const d of fs.readdirSync(src)) {
    const from = path.join(src, d);
    if (!fs.statSync(from).isDirectory()) continue;
    const to = path.join(res, d);
    fs.mkdirSync(to, { recursive: true });
    for (const f of fs.readdirSync(from)) fs.copyFileSync(path.join(from, f), path.join(to, f));
  }
  const bg = fs.readFileSync(path.join(src, 'bg_color.txt'), 'utf8').trim();
  fs.mkdirSync(path.join(res, 'values'), { recursive: true });
  fs.writeFileSync(path.join(res, 'values', 'ic_launcher_background.xml'),
    '<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <color name="ic_launcher_background">' + bg + '</color>\n</resources>\n');
  const ad = () => '<?xml version="1.0" encoding="utf-8"?>\n<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">\n' +
    '    <background android:drawable="@color/ic_launcher_background"/>\n    <foreground android:drawable="@mipmap/ic_launcher_foreground"/>\n</adaptive-icon>\n';
  fs.mkdirSync(path.join(res, 'mipmap-anydpi-v26'), { recursive: true });
  fs.writeFileSync(path.join(res, 'mipmap-anydpi-v26', 'ic_launcher.xml'), ad());
  fs.writeFileSync(path.join(res, 'mipmap-anydpi-v26', 'ic_launcher_round.xml'), ad());
});

step('fixed signing key (so an update installs over the old app and keeps data)', () => {
  const dir = path.join(os.homedir(), '.android'), dest = path.join(dir, 'debug.keystore');
  if (fs.existsSync(dest)) { console.log('     (a key already exists, left untouched: ' + dest + ')'); return; }
  fs.mkdirSync(dir, { recursive: true });
  fs.copyFileSync(path.join(root, 'assets', 'debug.keystore'), dest);
});
