# امینو (APK)

ساخت APK بدون نصب چیزی روی گوشی/کامپیوتر:
1. در github.com یک مخزن (Repository) خصوصی بساز و کل محتوای این پوشه را آپلود کن.
2. تب Actions ← Build APK ← Run workflow.
3. بعد از ~۴ دقیقه، از پایین صفحه‌ی همان اجرا، فایل Amino-APK را دانلود کن (زیپ است؛ داخلش app-release.apk).

یا با Android Studio: Open ← Build ← Build APK(s) (نوع release).

نکته: برای آپدیت‌های بعدی همیشه از همین فایل amino.jks و همین applicationId استفاده کن تا اطلاعات اپ پاک نشود.
