package com.htmltoapk.goalix;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.View;
import android.widget.FrameLayout;

import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;
import com.google.android.gms.ads.rewarded.RewardItem;

public class MainActivity extends Activity {
    private static final String BANNER_ID = "ca-app-pub-8556916853607788/3184042396";
    private static final String INTERSTITIAL_ID = "ca-app-pub-8556916853607788/5907417813";
    private static final String REWARDED_ID = "ca-app-pub-3940256099942544/5224354917";
    private static final long FIVE_MINUTES = 5 * 60 * 1000L;

    private WebView webView;
    private InterstitialAd interstitialAd;
    private RewardedAd rewardedAd;
    private long lastInterstitialShown = 0L;
    private boolean interstitialLoading = false;
    private boolean rewardedLoading = false;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        MobileAds.initialize(this, status -> {});
        setupWebView();
        setupBanner();
        loadInterstitial();
        loadRewarded();
    }

    private void setupWebView() {
        webView = findViewById(R.id.webView);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new GoalixAdsBridge(), "GoalixAds");
        webView.loadUrl("file:///android_asset/www/index.html");
    }

    private void setupBanner() {
        FrameLayout box = findViewById(R.id.bannerContainer);
        AdView ad = new AdView(this);
        ad.setAdSize(AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(this, 360));
        ad.setAdUnitId(BANNER_ID);
        box.addView(ad);
        ad.loadAd(new AdRequest.Builder().build());
    }

    private void loadInterstitial() {
        if (interstitialLoading || interstitialAd != null) return;
        interstitialLoading = true;
        InterstitialAd.load(this, INTERSTITIAL_ID, new AdRequest.Builder().build(), new InterstitialAdLoadCallback() {
            @Override public void onAdLoaded(InterstitialAd ad) { interstitialLoading = false; interstitialAd = ad; }
            @Override public void onAdFailedToLoad(LoadAdError e) { interstitialLoading = false; interstitialAd = null; }
        });
    }

    private void loadRewarded() {
        if (rewardedLoading || rewardedAd != null) return;
        rewardedLoading = true;
        RewardedAd.load(this, REWARDED_ID, new AdRequest.Builder().build(), new RewardedAdLoadCallback() {
            @Override public void onAdLoaded(RewardedAd ad) { rewardedLoading = false; rewardedAd = ad; }
            @Override public void onAdFailedToLoad(LoadAdError e) { rewardedLoading = false; rewardedAd = null; }
        });
    }

    private void showInterstitialIfEligible() {
        long now = System.currentTimeMillis();
        if (now - lastInterstitialShown < FIVE_MINUTES) { loadInterstitial(); return; }
        if (interstitialAd == null) { loadInterstitial(); return; }
        InterstitialAd ad = interstitialAd;
        interstitialAd = null;
        lastInterstitialShown = now;
        ad.setFullScreenContentCallback(new FullScreenContentCallback() {
            @Override public void onAdDismissedFullScreenContent() { loadInterstitial(); }
            @Override public void onAdFailedToShowFullScreenContent(AdError e) { loadInterstitial(); }
        });
        ad.show(this);
    }

    private void showRewarded() {
        if (rewardedAd == null) { loadRewarded(); return; }
        RewardedAd ad = rewardedAd;
        rewardedAd = null;
        ad.setFullScreenContentCallback(new FullScreenContentCallback() {
            @Override public void onAdDismissedFullScreenContent() { loadRewarded(); }
            @Override public void onAdFailedToShowFullScreenContent(AdError e) { loadRewarded(); }
        });
        ad.show(this, rewardItem -> runOnUiThread(() -> webView.evaluateJavascript("window.dispatchEvent(new CustomEvent('goalixRewardedComplete',{detail:{amount:" + rewardItem.getAmount() + "}}));", null)));
    }

    private class GoalixAdsBridge {
        @JavascriptInterface public void maybeShowInterstitial() { runOnUiThread(() -> showInterstitialIfEligible()); }
        @JavascriptInterface public void showInterstitial() { runOnUiThread(() -> showInterstitialIfEligible()); }
        @JavascriptInterface public void showRewarded() { runOnUiThread(() -> showRewarded()); }
        @JavascriptInterface public boolean isNative() { return true; }
    }
}
