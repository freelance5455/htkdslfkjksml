# GOALIX + AdMob Native

ده مشروع Android wrapper جاهز يحط نسخة GOALIX HTML الحالية داخل WebView ويربطها بـ Google Mobile Ads Native.

## مهم
- المشروع يستخدم **Test Ad IDs** من Google أثناء الاختبار.
- Banner دائم أسفل WebView.
- Interstitial مؤهل كل 5 دقائق، ولا يظهر تلقائيًا فوق اللعب؛ الـHTML يستدعي `GoalixAds.maybeShowInterstitial()` في نقطة انتقال مناسبة.
- Rewarded منفصل، والمكافأة تُرسل للـHTML فقط بعد إكمال الإعلان.
- فشل الإعلان لا يوقف اللعبة.

## بعد نجاح الاختبار
استبدل IDs الموجودة في `MainActivity.java` وApp ID في `AndroidManifest.xml` بالـIDs الخاصة بحساب AdMob.

## المصادر الرسمية
Google Mobile Ads SDK: https://developers.google.com/admob/android/quick-start


## ملاحظة IDs
تم استبدال App ID وBanner وInterstitial بالـIDs الموجودة في APK الأصلي. لم يتم العثور على Rewarded production ID في الـAPK الأصلي، لذلك ظل Rewarded على Test ID إلى أن يتوفر Ad Unit حقيقي له.
