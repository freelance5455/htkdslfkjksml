package com.alpha.panel;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.view.View;
import android.graphics.Color;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(5, 10, 18));
        getWindow().setNavigationBarColor(Color.rgb(5, 10, 18));
        getWindow().getDecorView().setSystemUiVisibility(0);
        WebView webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(5, 10, 18));
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(false);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        webView.loadUrl("file:///android_asset/index.html");
        setContentView(webView);
    }
}
