ALPHA PANEL - Android project (visual demo)

මෙය HEAD SHORT කියන එකම toggle option එකක් ඇති visual demo app එකකි.
Toggle එක ON/OFF කළාම app එකේ STATUS පමණක් වෙනස් වේ.
මෙය Free Fire වෙනස් නොකරයි, headshot/cheat ක්‍රියාකාරීත්වයක් සක්‍රිය නොකරයි.

APK එක සෑදීමට:
1. AndroidIDE වැනි Android Gradle project build කරන app එකකින් මෙම folder එක open කරන්න.
2. Gradle sync/build කරන්න (අන්තර්ජාලය සහ ඉඩ අවශ්‍ය විය හැක).
3. Build > Assemble Debug තෝරන්න.
4. සාර්ථක වුණොත් app/build/outputs/apk/debug/app-debug.apk ලැබේ.

මෙය සෘජුව install කළ හැකි APK එකක් නොවේ; build source project එකකි.
