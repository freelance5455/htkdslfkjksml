ADVENTURE DRIVE — ЖЁСТКО ГОРИЗОНТАЛЬНАЯ ANDROID-СБОРКА

ЭТО НЕ ПРОСТО HTML-НАСТРОЙКА.
Ориентация закреплена на уровне Android Activity до загрузки игры.

1. AndroidManifest.xml:
   android:screenOrientation="landscape"
   android:resizeableActivity="false"

2. MainActivity.java, ДО создания WebView:
   setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);

3. При каждом возврате в приложение onResume снова принудительно задаёт LANDSCAPE.

4. В HTML оставлен Screen Orientation API как дополнительный резервный слой.

Откройте ЭТУ ПАПКУ КАК ANDROID STUDIO PROJECT и собирайте APK из неё.
Если просто взять index.html и завернуть его другим конструктором APK, конструктор может снова сделать портретную Activity и обойти эту настройку.

Сборка APK в Android Studio:
Build -> Build App Bundle(s) / APK(s) -> Build APK(s)
