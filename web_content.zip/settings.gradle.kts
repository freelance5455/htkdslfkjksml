rootProject.name = "ProCamStudio"
include(":app")
