rootProject.name = "UyduAnaliz"
include(":app")
