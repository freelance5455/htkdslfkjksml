#!/usr/bin/env bash
# Installs everything Web2App Studio needs to build real APKs (no Docker): JDK check, Gradle, Android SDK.
# Usage:  ./scripts/setup-android-sdk.sh        then:  source ~/.web2app-env.sh
set -euo pipefail

ANDROID_HOME="${ANDROID_HOME:-$HOME/android-sdk}"
GRADLE_VERSION="${GRADLE_VERSION:-8.7}"            # AGP 8.5.x needs Gradle >= 8.7
GRADLE_DIR="${GRADLE_DIR:-$HOME/gradle-$GRADLE_VERSION}"
CMDLINE_TOOLS_URL="${CMDLINE_TOOLS_URL:-https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip}"
# macOS: export CMDLINE_TOOLS_URL=https://dl.google.com/android/repository/commandlinetools-mac-11076708_latest.zip

need() { command -v "$1" >/dev/null 2>&1 || { echo "✗ missing: $1 — $2"; exit 1; }; }
need java  "install JDK 17 or 21 (e.g. sudo apt install openjdk-17-jdk)"
need keytool "install a full JDK, not only a JRE"
need curl  "sudo apt install curl"
need unzip "sudo apt install unzip"

JV=$(java -version 2>&1 | head -1 | sed -E 's/.*"([0-9]+).*/\1/')
if [ "${JV:-0}" -lt 17 ]; then echo "✗ Java $JV found, need 17+"; exit 1; fi

if [ ! -x "$GRADLE_DIR/bin/gradle" ]; then
  echo "→ Installing Gradle $GRADLE_VERSION"
  tmp=$(mktemp -d); curl -fL "https://services.gradle.org/distributions/gradle-$GRADLE_VERSION-bin.zip" -o "$tmp/g.zip"
  unzip -q "$tmp/g.zip" -d "$tmp" && rm -rf "$GRADLE_DIR" && mv "$tmp/gradle-$GRADLE_VERSION" "$GRADLE_DIR"; rm -rf "$tmp"
fi

if [ ! -x "$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" ]; then
  echo "→ Installing Android command-line tools"
  mkdir -p "$ANDROID_HOME/cmdline-tools"; tmp=$(mktemp -d)
  curl -fL "$CMDLINE_TOOLS_URL" -o "$tmp/c.zip"
  unzip -q "$tmp/c.zip" -d "$tmp" && rm -rf "$ANDROID_HOME/cmdline-tools/latest" && mv "$tmp/cmdline-tools" "$ANDROID_HOME/cmdline-tools/latest"; rm -rf "$tmp"
fi

SDKM="$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager"
echo "→ Accepting licenses and installing platform 34 + build-tools 34.0.0"
yes | "$SDKM" --sdk_root="$ANDROID_HOME" --licenses >/dev/null || true
"$SDKM" --sdk_root="$ANDROID_HOME" "platforms;android-34" "build-tools;34.0.0"

cat > "$HOME/.web2app-env.sh" <<ENV
export ANDROID_HOME="$ANDROID_HOME"
export ANDROID_SDK_ROOT="$ANDROID_HOME"
export GRADLE_BIN="$GRADLE_DIR/bin/gradle"
export PATH="$GRADLE_DIR/bin:\$PATH"
ENV
echo
echo "✓ Done. Run:  source ~/.web2app-env.sh && python3 server/app.py"
