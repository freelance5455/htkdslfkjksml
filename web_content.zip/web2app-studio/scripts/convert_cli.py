#!/usr/bin/env python3
"""Convert a web project to a real APK from the command line (same pipeline as the web UI).

  python3 scripts/convert_cli.py samples/demo-site --name "Demo App" -o demo.apk
  python3 scripts/convert_cli.py site.zip --name Site --orientation portrait --color "#0EA5E9" --icon icon.png
  python3 scripts/convert_cli.py --url https://example.com --name Example
"""
import argparse
import os
import secrets
import shutil
import sys
import tempfile
from pathlib import Path

os.environ.setdefault("W2A_DATA", str(Path(__file__).resolve().parent.parent / "data"))
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "server"))
import android_project as ap  # noqa: E402
import app as appmod  # noqa: E402


def main() -> int:
    ap_ = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap_.add_argument("source", nargs="?", help="project folder, .zip or single .html (omit with --url)")
    ap_.add_argument("--url", help="wrap a website instead of local files")
    ap_.add_argument("--name", required=True)
    ap_.add_argument("--package", default="")
    ap_.add_argument("--version", default="1.0.0")
    ap_.add_argument("--version-code", type=int, default=1)
    ap_.add_argument("--orientation", choices=["portrait", "landscape", "auto"], default="auto")
    ap_.add_argument("--color", default="#4F46E5")
    ap_.add_argument("--icon", help="square PNG/JPG icon")
    ap_.add_argument("-o", "--output", help="output .apk path")
    a = ap_.parse_args()
    if bool(a.url) == bool(a.source):
        ap_.error("give either a source path or --url")

    appmod.JOBS_DIR.mkdir(parents=True, exist_ok=True)
    job = appmod.Job(secrets.token_hex(16))
    job.dir.mkdir(parents=True)
    try:
        job.cfg = ap.validate_config({
            "app_name": a.name, "package": a.package, "version_name": a.version, "version_code": a.version_code,
            "orientation": a.orientation, "splash_color": a.color, "mode": "url" if a.url else "local", "url": a.url or "",
        }, job.id)
        if a.source:
            src = Path(a.source)
            if src.is_dir():
                for f in src.rglob("*"):
                    if f.is_file():
                        t = job.files_dir / f.relative_to(src)
                        t.parent.mkdir(parents=True, exist_ok=True)
                        shutil.copyfile(f, t)
            elif src.suffix.lower() == ".zip":
                job.zips_dir.mkdir(parents=True)
                shutil.copyfile(src, job.zips_dir / "0.zip")
            elif src.is_file():
                job.files_dir.mkdir(parents=True)
                shutil.copyfile(src, job.files_dir / src.name)
            else:
                print(f"✗ source not found: {src}")
                return 2
        if a.icon:
            tmp = Path(tempfile.mkdtemp()) / "icon"
            shutil.copyfile(a.icon, tmp)
            try:
                from PIL import Image
                Image.open(tmp).convert("RGBA").save(job.icon_path, "PNG")
            except ImportError:
                shutil.copyfile(tmp, job.icon_path)  # must already be PNG
        job.add_log = lambda line: print(line, flush=True)  # live log
        appmod.build_worker(job)
        if job.state != "done":
            e = job.error or {}
            print(f"\n✗ {e.get('message')}\n  ↳ {e.get('hint')}")
            if e.get("log_tail"):
                print("\n--- last log lines ---\n" + e["log_tail"])
            return 1
        out = Path(a.output or f"{job.apk_name}")
        shutil.copyfile(job.out_dir / job.apk_name, out)
        print(f"\n✓ APK ready: {out.resolve()} ({out.stat().st_size // 1024} KB)")
        return 0
    finally:
        shutil.rmtree(job.dir, ignore_errors=True)


if __name__ == "__main__":
    sys.exit(main())
