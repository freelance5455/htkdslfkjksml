"""Real APK build pipeline: preflight -> generate project -> Gradle assembleRelease -> verify APK."""
from __future__ import annotations

import os
import re
import secrets
import shutil
import signal
import subprocess
import threading
import zipfile
from pathlib import Path
from typing import Callable

from android_project import COMPILE_SDK

BUILD_TIMEOUT = int(os.environ.get("W2A_BUILD_TIMEOUT", "1200"))
KEY_ALIAS = "web2app"


class BuildError(Exception):
    def __init__(self, message: str, hint: str = "", log_tail: str = ""):
        super().__init__(message)
        self.message = message
        self.hint = hint
        self.log_tail = log_tail


# ------------------------------------------------------------------ environment -----------------------

def _find_sdk() -> Path | None:
    for var in ("ANDROID_HOME", "ANDROID_SDK_ROOT"):
        v = os.environ.get(var)
        if v and Path(v).is_dir():
            return Path(v)
    return None


def _find_gradle() -> str | None:
    explicit = os.environ.get("GRADLE_BIN")
    if explicit:
        return explicit if shutil.which(explicit) or Path(explicit).exists() else None
    return shutil.which("gradle")


def preflight() -> dict:
    """Describe whether this machine can really build APKs. Never raises."""
    problems: list[dict] = []
    java = shutil.which("java")
    keytool = shutil.which("keytool")
    if not java or not keytool:
        problems.append({
            "id": "java",
            "message": "JDK غير مثبّت (java/keytool غير موجودين).",
            "hint": "ثبّت JDK 17 أو 21: sudo apt install openjdk-17-jdk",
        })
    gradle = _find_gradle()
    if not gradle:
        problems.append({
            "id": "gradle",
            "message": "Gradle غير موجود.",
            "hint": "شغّل scripts/setup-android-sdk.sh أو استخدم Docker (docker compose up) فهو يثبّت Gradle تلقائيًا.",
        })
    sdk = _find_sdk()
    if not sdk:
        problems.append({
            "id": "sdk",
            "message": "Android SDK غير موجود (ANDROID_HOME غير مضبوط).",
            "hint": "شغّل scripts/setup-android-sdk.sh ثم صدّر ANDROID_HOME، أو استخدم Docker.",
        })
    else:
        if not (sdk / "platforms" / f"android-{COMPILE_SDK}").is_dir():
            problems.append({
                "id": "platform",
                "message": f"منصة Android {COMPILE_SDK} غير مثبتة داخل SDK.",
                "hint": f"sdkmanager \"platforms;android-{COMPILE_SDK}\" \"build-tools;34.0.0\"",
            })
        if not (sdk / "build-tools").is_dir() or not any((sdk / "build-tools").iterdir()):
            problems.append({
                "id": "build-tools",
                "message": "Android build-tools غير مثبتة.",
                "hint": "sdkmanager \"build-tools;34.0.0\"",
            })
        if not (sdk / "licenses").is_dir():
            problems.append({
                "id": "licenses",
                "message": "لم تُقبل تراخيص Android SDK.",
                "hint": "yes | sdkmanager --licenses",
            })
    return {"can_build": not problems, "problems": problems,
            "java": bool(java), "gradle": bool(gradle), "sdk": str(sdk) if sdk else None}


def ensure_keystore(data_dir: Path) -> tuple[Path, str]:
    """Returns (keystore, password). Honors W2A_KEYSTORE / W2A_KEYSTORE_PASS, else creates one once."""
    env_ks = os.environ.get("W2A_KEYSTORE")
    if env_ks:
        return Path(env_ks), os.environ.get("W2A_KEYSTORE_PASS", "")
    kdir = data_dir / "keystore"
    kdir.mkdir(parents=True, exist_ok=True)
    ks, pw_file = kdir / "web2app.jks", kdir / "pass.txt"
    if not ks.exists() or not pw_file.exists():
        password = secrets.token_urlsafe(24)
        for p in (ks, pw_file):
            p.unlink(missing_ok=True)
        r = subprocess.run(
            ["keytool", "-genkeypair", "-keystore", str(ks), "-storetype", "PKCS12", "-alias", KEY_ALIAS,
             "-keyalg", "RSA", "-keysize", "2048", "-validity", "10000",
             "-storepass", password, "-keypass", password, "-dname", "CN=Web2App Studio, O=Web2App, C=US"],
            capture_output=True, text=True, timeout=120)
        if r.returncode != 0:
            raise BuildError("تعذّر إنشاء مفتاح توقيع APK.", "تأكد من تثبيت JDK وصلاحية الكتابة في مجلد data/.", r.stderr[-800:])
        fd = os.open(pw_file, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "w") as f:
            f.write(password)
        os.chmod(ks, 0o600)
    return ks, pw_file.read_text().strip()


# ------------------------------------------------------------------ gradle -----------------------------

_PROGRESS_STEPS = [
    (":app:preBuild", 30), (":app:generateReleaseResValues", 36), (":app:mergeReleaseResources", 44),
    (":app:processReleaseManifest", 50), (":app:compileReleaseJavaWithJavac", 62), (":app:mergeReleaseAssets", 68),
    (":app:dexBuilderRelease", 76), (":app:mergeDexRelease", 82), (":app:packageRelease", 90),
    (":app:assembleRelease", 94),
]

_ERROR_HINTS: list[tuple[str, str, str]] = [
    (r"SDK location not found|ANDROID_HOME|sdk\.dir", "لم يتم العثور على Android SDK.", "اضبط ANDROID_HOME أو شغّل scripts/setup-android-sdk.sh."),
    (r"Failed to install the following Android SDK packages|licen[sc]e.*not been accepted|License for package", "تراخيص Android SDK لم تُقبل.", "نفّذ: yes | sdkmanager --licenses"),
    (r"UnknownHostException|Could not GET|Could not resolve|Connection (?:refused|reset)|Read timed out|PKIX path|SSLHandshake|Could not HEAD",
     "تعذّر تنزيل اعتماديات البناء من الإنترنت (Gradle/Google Maven).",
     "تأكد من اتصال الخادم بـ services.gradle.org وdl.google.com وmaven.google.com وrepo.maven.apache.org، وأعد المحاولة. خلف وكيل (Proxy) اضبط إعداداته في gradle.properties."),
    (r"OutOfMemoryError|Java heap space|GC overhead", "نفدت الذاكرة أثناء البناء.", "ارفع ذاكرة الخادم (يوصى بـ 4 جيجابايت) أو قلّل حجم ملفات المشروع."),
    (r"Unsupported class file major version|requires Java 17|Android Gradle plugin requires Java|Unsupported Java|incompatible with.*Java",
     "إصدار Java غير متوافق.", "استخدم JDK 17 أو 21."),
    (r"AAPT: error|aapt2|resource .* not found|Android resource linking failed", "فشل تجهيز الموارد (غالبًا الأيقونة أو اسم التطبيق).", "جرّب أيقونة PNG مربعة صالحة أو اسم تطبيق أبسط."),
    (r"No space left on device", "لا توجد مساحة كافية على القرص.", "امسح الملفات المؤقتة أو وسّع القرص."),
    (r"Timeout|timed out", "انتهت مهلة البناء.", "أعد المحاولة؛ أول بناء يحتاج وقتًا أطول لتنزيل الاعتماديات."),
]


def explain_failure(log_text: str) -> tuple[str, str]:
    for pattern, message, hint in _ERROR_HINTS:
        if re.search(pattern, log_text, re.I):
            return message, hint
    return "فشل بناء تطبيق Android.", "راجع سجل البناء أدناه؛ إن تكرر الخطأ أرسل السجل لمطوّر المنصة."


def run_gradle(project_dir: Path, data_dir: Path, keystore: Path, password: str,
               on_line: Callable[[str], None], on_progress: Callable[[int], None],
               cancel: threading.Event | None = None) -> Path:
    gradle = _find_gradle()
    sdk = _find_sdk()
    if not gradle or not sdk:
        raise BuildError("بيئة البناء غير جاهزة.", "راجع /api/health لمعرفة الناقص.")
    (project_dir / "local.properties").write_text(f"sdk.dir={sdk}\n", "utf-8")

    keep = ("PATH", "HOME", "LANG", "LC_ALL", "JAVA_HOME", "ANDROID_HOME", "ANDROID_SDK_ROOT", "JAVA_TOOL_OPTIONS",
            "HTTPS_PROXY", "HTTP_PROXY", "NO_PROXY", "https_proxy", "http_proxy", "no_proxy", "SSL_CERT_FILE", "SSL_CERT_DIR")
    env = {k: v for k, v in os.environ.items() if k in keep}
    env["GRADLE_USER_HOME"] = os.environ.get("GRADLE_USER_HOME", str(data_dir / "gradle-home"))
    env.update({"W2A_KEYSTORE": str(keystore), "W2A_KEYSTORE_PASS": password, "W2A_KEY_ALIAS": KEY_ALIAS})
    Path(env["GRADLE_USER_HOME"]).mkdir(parents=True, exist_ok=True)

    cmd = [gradle, "--no-daemon", "--console=plain", "--stacktrace", "-p", str(project_dir), "assembleRelease"]
    proc = subprocess.Popen(cmd, cwd=project_dir, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                            text=True, bufsize=1, start_new_session=True)
    timer = threading.Timer(BUILD_TIMEOUT, lambda: os.killpg(proc.pid, signal.SIGKILL))
    timer.start()
    tail: list[str] = []
    try:
        assert proc.stdout
        for line in proc.stdout:
            line = line.rstrip()
            tail.append(line)
            if len(tail) > 400:
                del tail[:100]
            on_line(line)
            for marker, pct in _PROGRESS_STEPS:
                if line.startswith("> Task " + marker):
                    on_progress(pct)
            if cancel is not None and cancel.is_set():
                os.killpg(proc.pid, signal.SIGKILL)
                raise BuildError("تم إلغاء البناء.")
        code = proc.wait()
    finally:
        timer.cancel()
        if proc.poll() is None:
            os.killpg(proc.pid, signal.SIGKILL)
    text = "\n".join(tail)
    if code != 0:
        msg, hint = explain_failure(text)
        raise BuildError(msg, hint, "\n".join(tail[-40:]))
    apk_dir = project_dir / "app" / "build" / "outputs" / "apk" / "release"
    apks = sorted(apk_dir.glob("*.apk"))
    if not apks:
        raise BuildError("انتهى Gradle دون إنتاج ملف APK.", "راجع سجل البناء.", "\n".join(tail[-40:]))
    return apks[0]


def verify_apk(apk: Path, package: str) -> None:
    """Structural verification that works without the Android SDK."""
    if not zipfile.is_zipfile(apk):
        raise BuildError("الملف الناتج ليس APK صالحًا.")
    with zipfile.ZipFile(apk) as z:
        names = set(z.namelist())
        if "AndroidManifest.xml" not in names or not any(n.startswith("classes") and n.endswith(".dex") for n in names):
            raise BuildError("ملف APK الناتج ناقص (لا manifest أو لا dex).")
        if not any(n.startswith("META-INF/") and n.endswith((".RSA", ".DSA", ".EC", ".SF")) for n in names):
            raise BuildError("ملف APK غير موقّع.", "تحقق من إعدادات مفتاح التوقيع.")
    # Deeper check with apksigner when available
    sdk = _find_sdk()
    if sdk:
        signers = sorted((sdk / "build-tools").glob("*/apksigner"))
        if signers:
            r = subprocess.run([str(signers[-1]), "verify", str(apk)], capture_output=True, text=True, timeout=120)
            if r.returncode != 0:
                raise BuildError("فشل التحقق من توقيع APK.", "", (r.stdout + r.stderr)[-600:])
