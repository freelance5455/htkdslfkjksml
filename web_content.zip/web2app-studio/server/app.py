#!/usr/bin/env python3
"""Web2App Studio backend (Python standard library only - no pip install needed).

  python3 server/app.py            # UI on :8080, sandboxed preview origin on :8081
"""
from __future__ import annotations

import json
import mimetypes
import os
import re
import secrets
import shutil
import sys
import threading
import time
import traceback
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, quote, unquote, urlparse

sys.path.insert(0, str(Path(__file__).resolve().parent))
import android_project as ap  # noqa: E402
import builder  # noqa: E402
import validator as vd  # noqa: E402

ROOT = Path(__file__).resolve().parent
STATIC = ROOT / "static"
DATA = Path(os.environ.get("W2A_DATA", ROOT.parent / "data")).resolve()
JOBS_DIR = DATA / "jobs"
HOST = os.environ.get("W2A_HOST", "127.0.0.1")
PORT = int(os.environ.get("W2A_PORT", "8080"))
PREVIEW_PORT = int(os.environ.get("W2A_PREVIEW_PORT", str(PORT + 1)))
PREVIEW_ORIGIN = os.environ.get("W2A_PREVIEW_ORIGIN", "")  # set when behind a reverse proxy
FINISHED_TTL = int(os.environ.get("W2A_FINISHED_TTL", "3600"))   # APK kept 1h after success
ABSOLUTE_TTL = int(os.environ.get("W2A_ABSOLUTE_TTL", "7200"))   # any job removed after 2h
MAX_ACTIVE_JOBS = int(os.environ.get("W2A_MAX_JOBS", "100"))
MAX_ICON_BYTES = 2 * 1024 * 1024
BUILD_SLOTS = threading.Semaphore(int(os.environ.get("W2A_PARALLEL_BUILDS", "1")))

JOB_ID_RE = re.compile(r"^[0-9a-f]{32}$")
JOBS: dict[str, "Job"] = {}
JOBS_LOCK = threading.Lock()

for k, v in {"js": "text/javascript", "mjs": "text/javascript", "wasm": "application/wasm",
             "webmanifest": "application/manifest+json", "svg": "image/svg+xml", "woff2": "font/woff2",
             "woff": "font/woff", "avif": "image/avif", "webp": "image/webp"}.items():
    mimetypes.add_type(v, "." + k)


class Job:
    def __init__(self, job_id: str):
        self.id = job_id
        self.dir = JOBS_DIR / job_id
        self.created = time.time()
        self.finished: float | None = None
        self.state = "created"      # created | inspected | queued | building | done | error
        self.stage = "created"
        self.progress = 0
        self.log: list[str] = []
        self.error: dict | None = None
        self.info: dict | None = None   # result of inspect
        self.apk_name: str | None = None
        self.cfg: dict | None = None
        self.lock = threading.RLock()
        self.upload_bytes = 0
        self.cancel = threading.Event()
        self.building = False

    # directories
    files_dir = property(lambda s: s.dir / "uploads" / "files")
    zips_dir = property(lambda s: s.dir / "uploads" / "zips")
    icon_path = property(lambda s: s.dir / "icon.png")
    web_dir = property(lambda s: s.dir / "web")
    out_dir = property(lambda s: s.dir / "out")

    def set(self, **kw):
        with self.lock:
            for k, v in kw.items():
                setattr(self, k, v)

    def add_log(self, line: str):
        with self.lock:
            self.log.append(line[:500])
            if len(self.log) > 300:
                del self.log[:100]

    def app_root(self) -> Path | None:
        if not self.info:
            return None
        return self.web_dir / self.info["root_rel"] if self.info["root_rel"] else self.web_dir

    def public(self) -> dict:
        with self.lock:
            d = {
                "id": self.id, "state": self.state, "stage": self.stage, "progress": self.progress,
                "log": self.log[-60:], "error": self.error,
                "info": {k: v for k, v in (self.info or {}).items() if k != "root_rel"} if self.info else None,
            }
            if self.state == "done" and self.apk_name:
                apk = self.out_dir / self.apk_name
                d["apk"] = {"name": self.apk_name, "size": apk.stat().st_size if apk.exists() else 0,
                            "url": f"/api/jobs/{self.id}/download"}
            return d


def get_job(job_id: str) -> "Job | None":
    if not JOB_ID_RE.match(job_id or ""):
        return None
    with JOBS_LOCK:
        return JOBS.get(job_id)


def destroy_job(job: Job):
    job.cancel.set()
    with JOBS_LOCK:
        JOBS.pop(job.id, None)
    shutil.rmtree(job.dir, ignore_errors=True)


def cleanup_loop():
    while True:
        time.sleep(120)
        now = time.time()
        with JOBS_LOCK:
            jobs = list(JOBS.values())
        for j in jobs:
            if j.building:
                continue
            if (j.finished and now - j.finished > FINISHED_TTL) or now - j.created > ABSOLUTE_TTL:
                destroy_job(j)
        # orphan directories (after a restart)
        if JOBS_DIR.exists():
            known = {j.id for j in jobs}
            for d in JOBS_DIR.iterdir():
                try:
                    if d.is_dir() and d.name not in known and now - d.stat().st_mtime > 600:
                        shutil.rmtree(d, ignore_errors=True)
                except OSError:
                    pass


# ------------------------------------------------------------------ build pipeline ---------------------

def fail(job: Job, message: str, hint: str = "", log_tail: str = ""):
    job.set(state="error", stage="error", error={"message": message, "hint": hint, "log_tail": log_tail},
            finished=time.time())
    job.add_log("✗ " + message)


def build_worker(job: Job):
    job.set(building=True)
    try:
        job.set(state="queued", stage="queued", progress=2)
        job.add_log("في قائمة الانتظار…")
        BUILD_SLOTS.acquire()
        try:
            if job.cancel.is_set():
                return
            run_build(job)
        finally:
            BUILD_SLOTS.release()
    except builder.BuildError as e:
        fail(job, e.message, e.hint, e.log_tail)
    except (vd.ValidationError, ap.ConfigError) as e:
        fail(job, e.message, e.hint)
    except Exception as e:  # unexpected
        traceback.print_exc()
        fail(job, "حدث خطأ داخلي غير متوقع.", f"{type(e).__name__}: {e}")
    finally:
        # always remove temp build material; keep only the finished APK (until TTL)
        shutil.rmtree(job.dir / "android", ignore_errors=True)
        shutil.rmtree(job.dir / "uploads", ignore_errors=True)
        shutil.rmtree(job.web_dir, ignore_errors=True)
        job.icon_path.unlink(missing_ok=True)
        job.set(building=False)
        if job.finished is None:
            job.set(finished=time.time())


def run_build(job: Job):
    cfg = job.cfg
    assert cfg is not None
    job.set(state="building", stage="preflight", progress=5)
    job.add_log("فحص بيئة البناء…")
    pre = builder.preflight()
    if not pre["can_build"]:
        p = pre["problems"][0]
        raise builder.BuildError(
            "لا يمكن بناء APK على هذا الخادم: " + p["message"],
            p["hint"] + (f" (مشكلات أخرى: {len(pre['problems']) - 1})" if len(pre["problems"]) > 1 else ""))

    job.set(stage="validating", progress=10)
    job.add_log("إعادة التحقق من الملفات قبل البناء…")
    if cfg["mode"] == "local":
        vd.stage_uploads(job.files_dir, job.zips_dir, job.web_dir)
        root_rel, entry = vd.locate_entry(job.web_dir)
        app_root = job.web_dir / root_rel if root_rel else job.web_dir
        analysis = vd.analyze(app_root, entry)
    else:
        app_root, entry, analysis = None, "index.html", {"needs_internet": True}

    job.set(stage="generating", progress=18)
    job.add_log("إنشاء مشروع Android…")
    project = job.dir / "android"
    icon = job.icon_path if job.icon_path.exists() else None
    ap.generate(project, app_root, entry, cfg, bool(analysis["needs_internet"]), icon)

    job.set(stage="signing-key", progress=24)
    ks, pw = builder.ensure_keystore(DATA)

    job.set(stage="building", progress=28)
    job.add_log("تشغيل Gradle (أول عملية بناء تنزّل الاعتماديات وقد تستغرق عدة دقائق)…")

    def on_progress(p: int):
        if p > job.progress:
            job.set(progress=p)

    apk = builder.run_gradle(project, DATA, ks, pw, lambda l: job.add_log(l) if l.strip() else None, on_progress, job.cancel)

    job.set(stage="verifying", progress=95)
    job.add_log("التحقق من ملف APK…")
    builder.verify_apk(apk, cfg["package"])
    job.out_dir.mkdir(parents=True, exist_ok=True)
    name = f"{ap.slugify(cfg['app_name'], 'app')}-v{cfg['version_name']}.apk"
    shutil.copyfile(apk, job.out_dir / name)
    job.set(state="done", stage="done", progress=100, apk_name=name, finished=time.time())
    job.add_log("✓ اكتمل بناء APK")


# ------------------------------------------------------------------ HTTP -------------------------------

class Handler(BaseHTTPRequestHandler):
    server_version = "Web2AppStudio/1.0"
    preview_only = False
    protocol_version = "HTTP/1.1"

    def log_message(self, fmt, *args):
        if os.environ.get("W2A_VERBOSE"):
            sys.stderr.write("%s - %s\n" % (self.address_string(), fmt % args))

    # ---- helpers
    def _send(self, code: int, body: bytes, ctype: str, extra: dict | None = None):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("X-Content-Type-Options", "nosniff")
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def _json(self, code: int, obj):
        self._send(code, json.dumps(obj, ensure_ascii=False).encode("utf-8"), "application/json; charset=utf-8",
                   {"Cache-Control": "no-store"})

    def _err(self, code: int, message: str, hint: str = ""):
        # request bodies may be unread on errors -> never reuse this connection
        self.close_connection = True
        body = json.dumps({"error": {"message": message, "hint": hint}}, ensure_ascii=False).encode("utf-8")
        self._send(code, body, "application/json; charset=utf-8", {"Cache-Control": "no-store", "Connection": "close"})

    def _read_json(self) -> dict:
        n = int(self.headers.get("Content-Length") or 0)
        if n > 64 * 1024:
            raise vd.ValidationError("طلب كبير جدًا.")
        try:
            data = json.loads(self.rfile.read(n) or b"{}")
        except json.JSONDecodeError:
            raise vd.ValidationError("JSON غير صالح.")
        if not isinstance(data, dict):
            raise vd.ValidationError("JSON غير صالح.")
        return data

    def _save_body(self, dest: Path, limit: int):
        n = int(self.headers.get("Content-Length") or -1)
        if n < 0:
            raise vd.ValidationError("Content-Length مطلوب.")
        if n > limit:
            raise vd.ValidationError(f"الملف كبير جدًا (الحد {limit // (1024 * 1024)} م.ب).")
        dest.parent.mkdir(parents=True, exist_ok=True)
        left = n
        with open(dest, "wb") as f:
            while left > 0:
                chunk = self.rfile.read(min(262144, left))
                if not chunk:
                    raise vd.ValidationError("انقطع الرفع قبل اكتماله.")
                f.write(chunk)
                left -= len(chunk)
        return n

    # ---- routing
    def do_HEAD(self):
        self.do_GET()

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, HEAD, OPTIONS")
        self.send_header("Content-Length", "0")
        self.end_headers()

    def do_GET(self):
        try:
            u = urlparse(self.path)
            path = unquote(u.path)
            if path.startswith("/preview/"):
                return self.preview(path)
            if self.preview_only:
                return self._err(404, "غير موجود")
            if path == "/api/health":
                return self._json(200, builder.preflight())
            if path == "/api/config":
                return self._json(200, {
                    "preview_origin": PREVIEW_ORIGIN or f"PORT:{PREVIEW_PORT}",
                    "limits": {"max_file_mb": vd.MAX_FILE_BYTES // 1048576, "max_total_mb": vd.MAX_TOTAL_BYTES // 1048576,
                               "max_files": vd.MAX_FILES},
                })
            m = re.fullmatch(r"/api/jobs/([0-9a-f]{32})", path)
            if m:
                j = get_job(m.group(1))
                return self._json(200, j.public()) if j else self._err(404, "المهمة غير موجودة أو انتهت صلاحيتها.")
            m = re.fullmatch(r"/api/jobs/([0-9a-f]{32})/download", path)
            if m:
                return self.download(m.group(1))
            return self.static(path)
        except (BrokenPipeError, ConnectionResetError):
            pass
        except Exception:
            traceback.print_exc()
            self._err(500, "خطأ داخلي.")

    def do_POST(self):
        try:
            path = unquote(urlparse(self.path).path)
            if self.preview_only:
                return self._err(404, "غير موجود")
            if path == "/api/jobs":
                with JOBS_LOCK:
                    if len(JOBS) >= MAX_ACTIVE_JOBS:
                        return self._err(503, "الخادم مشغول حاليًا.", "حاول بعد دقائق.")
                    jid = secrets.token_hex(16)
                    job = Job(jid)
                    JOBS[jid] = job
                job.dir.mkdir(parents=True, exist_ok=True)
                return self._json(201, {"id": jid})
            m = re.fullmatch(r"/api/jobs/([0-9a-f]{32})/(inspect|build)", path)
            if not m:
                return self._err(404, "غير موجود")
            job = get_job(m.group(1))
            if not job:
                return self._err(404, "المهمة غير موجودة أو انتهت صلاحيتها.")
            if m.group(2) == "inspect":
                return self.inspect(job)
            return self.start_build(job)
        except (vd.ValidationError, ap.ConfigError) as e:
            self._err(400, e.message, e.hint)
        except (BrokenPipeError, ConnectionResetError):
            pass
        except Exception:
            traceback.print_exc()
            self._err(500, "خطأ داخلي.")

    def do_PUT(self):
        try:
            u = urlparse(self.path)
            path = unquote(u.path)
            q = parse_qs(u.query)
            m = re.fullmatch(r"/api/jobs/([0-9a-f]{32})/(files|icon)", path)
            if self.preview_only or not m:
                return self._err(404, "غير موجود")
            job = get_job(m.group(1))
            if not job:
                return self._err(404, "المهمة غير موجودة أو انتهت صلاحيتها.")
            if job.state not in ("created", "inspected"):
                return self._err(409, "لا يمكن تعديل الملفات بعد بدء البناء.")
            if m.group(2) == "icon":
                return self.upload_icon(job)
            return self.upload_file(job, q)
        except (vd.ValidationError, ap.ConfigError) as e:
            self._err(400, e.message, e.hint)
        except (BrokenPipeError, ConnectionResetError):
            pass
        except Exception:
            traceback.print_exc()
            self._err(500, "خطأ داخلي.")

    def do_DELETE(self):
        m = re.fullmatch(r"/api/jobs/([0-9a-f]{32})", unquote(urlparse(self.path).path))
        job = get_job(m.group(1)) if m and not self.preview_only else None
        if not job:
            return self._err(404, "غير موجود")
        destroy_job(job)
        self._json(200, {"ok": True})

    # ---- endpoints
    def upload_file(self, job: Job, q: dict):
        kind = (q.get("kind") or ["file"])[0]
        rel_raw = (q.get("path") or [""])[0]
        with job.lock:
            if kind == "zip":
                name = f"{len(list(job.zips_dir.glob('*.zip')) if job.zips_dir.exists() else [])}.zip"
                dest = job.zips_dir / name
                limit = vd.MAX_TOTAL_BYTES
            else:
                rel = vd.clean_rel(rel_raw)
                if rel is None:
                    self.rfile.read(int(self.headers.get("Content-Length") or 0))
                    return self._json(200, {"ignored": True})
                if vd.ext_of(rel) not in vd.ALLOWED_EXT:
                    self.rfile.read(min(int(self.headers.get("Content-Length") or 0), 64 * 1024 * 1024))
                    raise vd.ValidationError(
                        f"نوع الملف غير مسموح: {rel}",
                        "الأنواع المسموحة: HTML/CSS/JS/JSON وصور وخطوط وصوت وفيديو.")
                dest = job.files_dir / rel
                vd._ensure_inside(job.files_dir, dest)
                limit = vd.MAX_FILE_BYTES
            if job.upload_bytes > vd.MAX_TOTAL_BYTES:
                raise vd.ValidationError("حجم الرفع الإجمالي تجاوز الحد المسموح.")
            n = self._save_body(dest, limit)
            job.upload_bytes += n
            job.state = "created"
            job.info = None
        self._json(200, {"ok": True, "bytes": n})

    def upload_icon(self, job: Job):
        tmp = job.dir / "icon.upload"
        self._save_body(tmp, MAX_ICON_BYTES)
        head = tmp.read_bytes()[:16]
        is_png = head.startswith(b"\x89PNG\r\n\x1a\n")
        try:
            from PIL import Image  # optional dependency
        except Exception:
            Image = None
        if Image is not None:
            try:
                with Image.open(tmp) as im:
                    im.verify()
                with Image.open(tmp) as im:
                    if im.width < 48 or im.height < 48 or im.width > 4096 or im.height > 4096:
                        raise ValueError("size")
                    im.convert("RGBA").save(job.icon_path, "PNG")
            except Exception:
                tmp.unlink(missing_ok=True)
                raise vd.ValidationError("الأيقونة غير صالحة.", "استخدم صورة PNG/JPG/WebP أبعادها بين 48 و4096 بكسل.")
        else:
            if not is_png:
                tmp.unlink(missing_ok=True)
                raise vd.ValidationError("الأيقونة يجب أن تكون PNG.", "حوّل الصورة إلى PNG، أو ثبّت Pillow على الخادم لدعم JPG/WebP.")
            import struct
            w, h = struct.unpack(">II", tmp.read_bytes()[16:24])
            if not (48 <= w <= 4096 and 48 <= h <= 4096):
                tmp.unlink(missing_ok=True)
                raise vd.ValidationError("أبعاد الأيقونة يجب أن تكون بين 48 و4096 بكسل.")
            shutil.move(tmp, job.icon_path)
        tmp.unlink(missing_ok=True)
        self._json(200, {"ok": True})

    def inspect(self, job: Job):
        with job.lock:
            budget = vd.stage_uploads(job.files_dir, job.zips_dir, job.web_dir)
            root_rel, entry = vd.locate_entry(job.web_dir)
            app_root = job.web_dir / root_rel if root_rel else job.web_dir
            info = vd.analyze(app_root, entry)
            info["root_rel"] = root_rel
            job.info = info
            job.state = "inspected"
        pub = {k: v for k, v in info.items() if k != "root_rel"}
        pub["preview_path"] = f"/preview/{job.id}/{quote(entry)}"
        self._json(200, pub)

    def start_build(self, job: Job):
        raw = self._read_json()
        cfg = ap.validate_config(raw, job.id)
        with job.lock:
            if job.state in ("queued", "building"):
                return self._err(409, "البناء قيد التنفيذ بالفعل.")
            if cfg["mode"] == "local" and (job.state != "inspected" or not job.info):
                return self._err(409, "افحص المشروع أولًا (ارفع الملفات ثم اضغط معاينة).")
            job.cfg = cfg
            job.error = None
            job.log = []
            job.progress = 1
            job.state = "queued"
            job.stage = "queued"
        threading.Thread(target=build_worker, args=(job,), daemon=True).start()
        self._json(202, {"ok": True})

    def download(self, job_id: str):
        job = get_job(job_id)
        if not job or job.state != "done" or not job.apk_name:
            return self._err(404, "لا يوجد ملف APK جاهز لهذه المهمة.")
        apk = job.out_dir / job.apk_name
        if not apk.exists():
            return self._err(410, "انتهت صلاحية الملف.", "أعد عملية التحويل.")
        size = apk.stat().st_size
        self.send_response(200)
        self.send_header("Content-Type", "application/vnd.android.package-archive")
        self.send_header("Content-Length", str(size))
        self.send_header("Content-Disposition", f"attachment; filename*=UTF-8''{quote(job.apk_name)}")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        if self.command != "HEAD":
            with open(apk, "rb") as f:
                shutil.copyfileobj(f, self.wfile)

    def preview(self, path: str):
        m = re.fullmatch(r"/preview/([0-9a-f]{32})/(.*)", path)
        job = get_job(m.group(1)) if m else None
        root = job.app_root() if job else None
        if not job or not root or not root.is_dir():
            return self._err(404, "لا توجد معاينة (افحص المشروع أولًا أو انتهت صلاحيتها).")
        rel = m.group(2) or job.info["entry"]
        target = (root / rel).resolve()
        if root.resolve() not in target.parents and target != root.resolve():
            return self._err(403, "ممنوع")
        if target.is_dir():
            target = target / "index.html"
        if not target.is_file():
            return self._err(404, "الملف غير موجود")
        ctype = mimetypes.guess_type(target.name)[0] or "application/octet-stream"
        if ctype.startswith("text/") or ctype in ("application/json", "image/svg+xml"):
            ctype += "; charset=utf-8" if "charset" not in ctype else ""
        self._send(200, target.read_bytes(), ctype, {
            "Cache-Control": "no-store",
            "Access-Control-Allow-Origin": "*",
            "Content-Security-Policy": "sandbox allow-scripts allow-same-origin allow-forms allow-modals allow-popups",
        })

    def static(self, path: str):
        if path in ("", "/"):
            path = "/index.html"
        target = (STATIC / path.lstrip("/")).resolve()
        if STATIC.resolve() not in target.parents or not target.is_file():
            return self._err(404, "غير موجود")
        ctype = mimetypes.guess_type(target.name)[0] or "application/octet-stream"
        if ctype.startswith("text/") or ctype in ("application/javascript", "text/javascript", "image/svg+xml"):
            ctype += "; charset=utf-8" if "charset" not in ctype else ""
        self._send(200, target.read_bytes(), ctype, {
            "Cache-Control": "no-cache",
            "Content-Security-Policy": "default-src 'self'; img-src 'self' data: blob:; style-src 'self' 'unsafe-inline'; "
                                       "frame-src *; connect-src 'self'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'",
        })


class PreviewHandler(Handler):
    preview_only = True


def main():
    sys.stdout.reconfigure(line_buffering=True)
    JOBS_DIR.mkdir(parents=True, exist_ok=True)
    shutil.rmtree(JOBS_DIR, ignore_errors=True)  # leftovers from a previous run
    JOBS_DIR.mkdir(parents=True, exist_ok=True)
    threading.Thread(target=cleanup_loop, daemon=True).start()
    main_srv = ThreadingHTTPServer((HOST, PORT), Handler)
    prev_srv = ThreadingHTTPServer((HOST, PREVIEW_PORT), PreviewHandler)
    main_srv.daemon_threads = prev_srv.daemon_threads = True
    threading.Thread(target=prev_srv.serve_forever, daemon=True).start()
    pre = builder.preflight()
    print(f"Web2App Studio  → http://{HOST}:{PORT}   (preview origin :{PREVIEW_PORT})")
    if pre["can_build"]:
        print("بيئة بناء APK: جاهزة ✓")
    else:
        print("تحذير: بيئة بناء APK غير جاهزة على هذا الجهاز:")
        for p in pre["problems"]:
            print(f"  - {p['message']}\n    ↳ {p['hint']}")
    try:
        main_srv.serve_forever()
    except KeyboardInterrupt:
        print("\nbye")


if __name__ == "__main__":
    main()
