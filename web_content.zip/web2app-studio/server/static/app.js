"use strict";
(() => {
  const $ = (id) => document.getElementById(id);
  const state = {
    mode: "files",        // files | url
    entries: [],          // {file, path, zip}
    skipped: 0,
    jobId: null,          // job whose server-side uploads match state.entries
    inspected: false,
    iconFile: null,
    iconDirty: false,
    previewOrigin: "",
    polling: null,
    building: false,
  };

  // ------------------------------------------------------------------ helpers
  const fmt = (n) => (n < 1024 ? n + " B" : n < 1048576 ? (n / 1024).toFixed(1) + " KB" : (n / 1048576).toFixed(1) + " MB");
  const show = (el, on = true) => { el.hidden = !on; };
  const IGNORE = /(^|\/)(node_modules|\.git|\.svn|__MACOSX)(\/|$)|(^|\/)\.[^/]+$|(^|\/)(thumbs\.db|desktop\.ini)$/i;

  async function api(method, url, body, headers = {}) {
    const res = await fetch(url, { method, body, headers });
    let data = null;
    try { data = await res.json(); } catch { /* non-JSON */ }
    if (!res.ok) {
      const e = new Error((data && data.error && data.error.message) || `خطأ ${res.status}`);
      e.hint = (data && data.error && data.error.hint) || "";
      throw e;
    }
    return data;
  }

  function showError(el, message, hint) {
    el.replaceChildren();
    const s = document.createElement("strong"); s.textContent = message; el.append(s);
    if (hint) { const p = document.createElement("p"); p.textContent = hint; el.append(p); }
    show(el);
  }

  // ------------------------------------------------------------------ theme
  const root = document.documentElement;
  function setTheme(t) {
    root.dataset.theme = t;
    try { localStorage.setItem("w2a-theme", t); } catch { /* storage unavailable */ }
    document.querySelector('meta[name="theme-color"]').content = t === "dark" ? "#0d0f1a" : "#4F46E5";
  }
  let saved = null;
  try { saved = localStorage.getItem("w2a-theme"); } catch { /* ignore */ }
  setTheme(saved || (matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light"));
  $("themeBtn").addEventListener("click", () => setTheme(root.dataset.theme === "dark" ? "light" : "dark"));

  // ------------------------------------------------------------------ environment status
  async function loadEnv() {
    try {
      const [cfg, health] = await Promise.all([api("GET", "/api/config"), api("GET", "/api/health")]);
      state.previewOrigin = cfg.preview_origin.startsWith("PORT:")
        ? `${location.protocol}//${location.hostname}:${cfg.preview_origin.slice(5)}` : cfg.preview_origin.replace(/\/$/, "");
      const chip = $("envChip");
      chip.hidden = false;
      chip.className = "chip " + (health.can_build ? "ok" : "bad");
      chip.textContent = health.can_build ? "● بيئة البناء جاهزة" : "● بيئة البناء غير مكتملة";
      if (!health.can_build) {
        const b = $("envBanner");
        b.replaceChildren();
        const t = document.createElement("strong"); t.textContent = "لا يمكن بناء APK على هذا الخادم حاليًا: ";
        b.append(t, document.createTextNode(health.problems.map((p) => p.message).join(" ")));
        const hint = document.createElement("div");
        hint.append(document.createTextNode("الحل: "));
        const c = document.createElement("code"); c.textContent = health.problems[0].hint; hint.append(c);
        b.append(hint);
        show(b);
      }
    } catch (e) {
      const chip = $("envChip"); chip.hidden = false; chip.className = "chip bad"; chip.textContent = "● الخادم غير متصل";
    }
  }

  // ------------------------------------------------------------------ source tabs
  function setMode(m) {
    state.mode = m;
    $("tabFiles").classList.toggle("active", m === "files");
    $("tabUrl").classList.toggle("active", m === "url");
    $("tabFiles").setAttribute("aria-selected", m === "files");
    $("tabUrl").setAttribute("aria-selected", m === "url");
    show($("paneFiles"), m === "files");
    show($("paneUrl"), m === "url");
    $("inspectBtn").textContent = m === "files" ? "فحص ومعاينة" : "معاينة الموقع";
    resetPreview();
  }
  $("tabFiles").addEventListener("click", () => setMode("files"));
  $("tabUrl").addEventListener("click", () => setMode("url"));

  // ------------------------------------------------------------------ file intake
  function addFiles(list) {
    for (const { file, path } of list) {
      const clean = path.replace(/^\/+/, "");
      if (IGNORE.test(clean)) { state.skipped++; continue; }
      const zip = /\.zip$/i.test(clean) && !clean.includes("/");
      state.entries = state.entries.filter((e) => e.path !== clean);
      state.entries.push({ file, path: clean, zip });
    }
    invalidate();
    renderSummary();
    if (state.entries.length) inspect();
  }

  function renderSummary() {
    const n = state.entries.length;
    show($("fileSummary"), n > 0);
    $("fsCount").textContent = n;
    $("fsSize").textContent = fmt(state.entries.reduce((s, e) => s + e.file.size, 0));
    $("fsSkipped").textContent = state.skipped ? ` · تم تجاهل ${state.skipped} ملف نظام/مخفي` : "";
  }

  function invalidate() {
    state.inspected = false;
    if (state.jobId) { fetch(`/api/jobs/${state.jobId}`, { method: "DELETE" }).catch(() => {}); state.jobId = null; }
  }

  $("clearFiles").addEventListener("click", () => {
    state.entries = []; state.skipped = 0; invalidate(); renderSummary(); resetPreview(); show($("srcError"), false);
  });
  $("pickFiles").addEventListener("click", (e) => { e.stopPropagation(); $("fileInput").click(); });
  $("pickFolder").addEventListener("click", (e) => { e.stopPropagation(); $("folderInput").click(); });
  $("fileInput").addEventListener("change", (e) => {
    addFiles([...e.target.files].map((f) => ({ file: f, path: f.name }))); e.target.value = "";
  });
  $("folderInput").addEventListener("change", (e) => {
    addFiles([...e.target.files].map((f) => ({ file: f, path: f.webkitRelativePath || f.name }))); e.target.value = "";
  });

  const drop = $("drop");
  drop.addEventListener("click", () => $("fileInput").click());
  drop.addEventListener("keydown", (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); $("fileInput").click(); } });
  ["dragenter", "dragover"].forEach((ev) => drop.addEventListener(ev, (e) => { e.preventDefault(); drop.classList.add("over"); }));
  ["dragleave", "drop"].forEach((ev) => drop.addEventListener(ev, (e) => { e.preventDefault(); drop.classList.remove("over"); }));

  async function walk(entry, prefix, out) {
    if (entry.isFile) {
      const file = await new Promise((res, rej) => entry.file(res, rej));
      out.push({ file, path: prefix + entry.name });
    } else if (entry.isDirectory) {
      const reader = entry.createReader();
      let batch;
      do {
        batch = await new Promise((res, rej) => reader.readEntries(res, rej));
        for (const child of batch) await walk(child, prefix + entry.name + "/", out);
      } while (batch.length);
    }
  }
  drop.addEventListener("drop", async (e) => {
    const items = [...(e.dataTransfer.items || [])];
    const out = [];
    try {
      if (items.length && items[0].webkitGetAsEntry) {
        const entries = items.map((i) => i.webkitGetAsEntry()).filter(Boolean);
        for (const en of entries) await walk(en, "", out);
      } else {
        for (const f of e.dataTransfer.files) out.push({ file: f, path: f.name });
      }
    } catch (err) {
      showError($("srcError"), "تعذّرت قراءة المجلد المُفلَت.", "جرّب زر «اختيار مجلد» بدلًا من السحب.");
      return;
    }
    addFiles(out);
  });

  // ------------------------------------------------------------------ inspect + preview
  function resetPreview() {
    show($("previewFrame"), false); $("previewFrame").removeAttribute("src");
    show($("previewEmpty"), true); show($("inspectInfo"), false); show($("warnList"), false); show($("openPreview"), false);
    $("previewEmpty").textContent = "ستظهر معاينة التطبيق هنا بعد فحص الملفات";
  }

  function isValidUrl(v) {
    try { const u = new URL(v); return (u.protocol === "https:" || u.protocol === "http:") && !!u.hostname; } catch { return false; }
  }

  async function uploadAll(jobId) {
    const queue = [...state.entries];
    let done = 0;
    const total = queue.length;
    const worker = async () => {
      while (queue.length) {
        const e = queue.shift();
        const qs = e.zip ? "kind=zip" : "path=" + encodeURIComponent(e.path);
        await api("PUT", `/api/jobs/${jobId}/files?${qs}`, e.file, { "Content-Type": "application/octet-stream" });
        done++;
        $("previewEmpty").textContent = `جارٍ رفع الملفات… ${done}/${total}`;
      }
    };
    await Promise.all([worker(), worker(), worker(), worker()]);
    if (state.iconFile) await api("PUT", `/api/jobs/${jobId}/icon`, state.iconFile, { "Content-Type": "application/octet-stream" });
  }

  let inspecting = false;
  async function inspect() {
    if (inspecting) return;
    show($("srcError"), false);
    if (state.mode === "url") {
      const url = $("siteUrl").value.trim();
      if (!isValidUrl(url)) { $("siteUrl").classList.add("bad"); showError($("srcError"), "رابط الموقع غير صالح.", "مثال: https://example.com"); return; }
      $("siteUrl").classList.remove("bad");
      const f = $("previewFrame");
      show($("previewEmpty"), false); show(f, true); f.src = url;
      const open = $("openPreview"); open.href = url; open.textContent = "فتح الموقع في تبويب جديد ↗"; show(open);
      const ul = $("inspectInfo"); ul.replaceChildren();
      const li = document.createElement("li"); li.textContent = "بعض المواقع تمنع عرضها داخل إطار؛ هذا لا يؤثر على التطبيق الناتج."; ul.append(li); show(ul);
      state.inspected = true;
      return;
    }
    if (!state.entries.length) { showError($("srcError"), "لم تُحدَّد أي ملفات بعد.", "اسحب ملف HTML أو ZIP أو مجلد المشروع."); return; }
    inspecting = true;
    $("inspectBtn").disabled = true;
    show($("previewEmpty"), true); show($("previewFrame"), false);
    $("previewEmpty").textContent = "جارٍ رفع الملفات وفحصها…";
    try {
      if (!state.jobId) state.jobId = (await api("POST", "/api/jobs")).id;
      await uploadAll(state.jobId);
      state.iconDirty = false;
      const info = await api("POST", `/api/jobs/${state.jobId}/inspect`);
      state.inspected = true;
      renderInfo(info);
    } catch (e) {
      showError($("srcError"), e.message, e.hint);
      $("previewEmpty").textContent = "تعذّرت المعاينة";
      state.inspected = false;
      if (state.jobId) { fetch(`/api/jobs/${state.jobId}`, { method: "DELETE" }).catch(() => {}); state.jobId = null; }
    } finally {
      inspecting = false;
      $("inspectBtn").disabled = false;
    }
  }
  $("inspectBtn").addEventListener("click", inspect);

  function renderInfo(info) {
    const src = state.previewOrigin + info.preview_path;
    const f = $("previewFrame");
    show($("previewEmpty"), false); show(f, true); f.src = src;
    const open = $("openPreview"); open.href = src; open.textContent = "فتح المعاينة في تبويب جديد ↗"; show(open);
    const rows = [
      ["الصفحة الرئيسية", info.entry],
      ["عدد الملفات", String(info.file_count)],
      ["الحجم", fmt(info.total_bytes)],
      ["يحتاج إنترنت", info.needs_internet ? "نعم (موارد خارجية)" : "لا — يعمل دون اتصال"],
    ];
    const ul = $("inspectInfo"); ul.replaceChildren();
    for (const [k, v] of rows) {
      const li = document.createElement("li");
      const a = document.createElement("span"); a.textContent = k;
      const b = document.createElement("b"); b.textContent = v;
      li.append(a, b); ul.append(li);
    }
    show(ul);
    const wl = $("warnList"); wl.replaceChildren();
    for (const w of info.warnings) { const li = document.createElement("li"); li.textContent = "⚠ " + w; wl.append(li); }
    show(wl, info.warnings.length > 0);
    if (!$("appName").value.trim()) { /* leave empty - user must name the app */ }
  }

  // ------------------------------------------------------------------ settings
  $("orientSeg").addEventListener("click", (e) => {
    const b = e.target.closest("button[data-v]"); if (!b) return;
    for (const x of $("orientSeg").children) { const on = x === b; x.classList.toggle("on", on); x.setAttribute("aria-checked", on); }
  });
  const orientation = () => $("orientSeg").querySelector(".on").dataset.v;

  const HEX = /^#[0-9a-fA-F]{6}$/;
  $("splashColor").addEventListener("input", (e) => { $("splashHex").value = e.target.value.toUpperCase(); drawDefaultIcon(); });
  $("splashHex").addEventListener("input", (e) => {
    const v = e.target.value.startsWith("#") ? e.target.value : "#" + e.target.value;
    if (HEX.test(v)) { $("splashColor").value = v.toLowerCase(); e.target.classList.remove("bad"); drawDefaultIcon(); }
    else e.target.classList.add("bad");
  });

  function drawDefaultIcon() {
    if (state.iconFile) return;
    const c = document.createElement("canvas"); c.width = c.height = 112;
    const x = c.getContext("2d");
    x.fillStyle = $("splashColor").value;
    x.beginPath(); x.roundRect(0, 0, 112, 112, 25); x.fill();
    x.strokeStyle = "#fff"; x.lineWidth = 8; x.beginPath(); x.arc(56, 56, 29, 0, Math.PI * 2); x.stroke();
    x.fillStyle = "#fff"; x.beginPath(); x.arc(56, 56, 10, 0, Math.PI * 2); x.fill();
    $("iconPreview").src = c.toDataURL();
  }
  drawDefaultIcon();

  $("pickIcon").addEventListener("click", () => $("iconInput").click());
  $("iconInput").addEventListener("change", (e) => {
    const f = e.target.files[0]; e.target.value = "";
    if (!f) return;
    if (!/^image\/(png|jpeg|webp)$/.test(f.type) || f.size > 2 * 1024 * 1024) {
      showError($("srcError"), "الأيقونة غير صالحة.", "استخدم PNG أو JPG أو WebP بحجم أقل من 2 م.ب.");
      return;
    }
    state.iconFile = f;
    $("iconPreview").src = URL.createObjectURL(f);
    show($("resetIcon"));
    invalidate();                 // icon is part of the job → re-upload on next inspect/build
    if (state.mode === "files" && state.entries.length) inspect();
  });
  $("resetIcon").addEventListener("click", () => {
    state.iconFile = null; show($("resetIcon"), false); drawDefaultIcon(); invalidate();
    if (state.mode === "files" && state.entries.length) inspect();
  });

  // ------------------------------------------------------------------ build
  const STAGES = [
    ["queued", "في قائمة الانتظار"], ["preflight", "فحص بيئة البناء"], ["validating", "التحقق من الملفات"],
    ["generating", "إنشاء مشروع Android"], ["signing-key", "تجهيز مفتاح التوقيع"],
    ["building", "بناء التطبيق (Gradle)"], ["verifying", "التحقق من ملف APK"], ["done", "اكتمل"],
  ];

  function renderStages(cur) {
    const ol = $("stages");
    if (!ol.children.length) {
      for (const [id, label] of STAGES) { const li = document.createElement("li"); li.dataset.id = id; li.textContent = label; ol.append(li); }
    }
    const idx = STAGES.findIndex(([id]) => id === cur);
    [...ol.children].forEach((li, i) => {
      li.className = i < idx || cur === "done" ? "done" : i === idx ? "cur" : "";
    });
    const found = STAGES[idx]; $("stageLabel").textContent = found ? found[1] : "…";
  }

  function configFromForm() {
    const cfg = {
      app_name: $("appName").value.trim(),
      package: $("pkgName").value.trim(),
      version_name: $("verName").value.trim() || "1.0.0",
      version_code: Number($("verCode").value) || 1,
      orientation: orientation(),
      splash_color: $("splashColor").value.toUpperCase(),
      mode: state.mode === "url" ? "url" : "local",
    };
    if (state.mode === "url") cfg.url = $("siteUrl").value.trim();
    return cfg;
  }

  function validateForm(cfg) {
    if (!cfg.app_name) { $("appName").classList.add("bad"); $("appName").focus(); return "أدخل اسم التطبيق أولًا."; }
    $("appName").classList.remove("bad");
    if (cfg.mode === "url" && !isValidUrl(cfg.url)) { $("siteUrl").classList.add("bad"); return "رابط الموقع غير صالح."; }
    if (cfg.mode === "local" && !state.entries.length) return "ارفع ملفات المشروع أولًا.";
    if (!HEX.test($("splashHex").value)) return "لون شاشة البداية يجب أن يكون بصيغة #RRGGBB.";
    return "";
  }

  async function startBuild() {
    if (state.building) return;
    const cfg = configFromForm();
    const problem = validateForm(cfg);
    show($("buildError"), false); show($("doneBox"), false);
    if (problem) { $("beMsg").textContent = problem; $("beHint").textContent = ""; $("beLog").textContent = ""; $("beLog").parentElement.hidden = true; show($("retryBtn"), false); show($("buildError")); return; }
    state.building = true; $("buildBtn").disabled = true;
    try {
      if (cfg.mode === "local" && !state.inspected) { await inspect(); if (!state.inspected) throw new Error("تعذّر فحص الملفات؛ صحّح الأخطاء الظاهرة في الخطوة 1."); }
      let jobId = state.jobId;
      if (cfg.mode === "url") {
        jobId = (await api("POST", "/api/jobs")).id;
        if (state.iconFile) await api("PUT", `/api/jobs/${jobId}/icon`, state.iconFile, { "Content-Type": "application/octet-stream" });
      }
      await api("POST", `/api/jobs/${jobId}/build`, JSON.stringify(cfg), { "Content-Type": "application/json" });
      show($("progress")); $("logBox").textContent = ""; $("stages").replaceChildren(); renderStages("queued");
      poll(jobId);
    } catch (e) {
      state.building = false; $("buildBtn").disabled = false;
      $("beMsg").textContent = e.message; $("beHint").textContent = e.hint || "";
      $("beLog").parentElement.hidden = true; show($("retryBtn"), false); show($("buildError"));
    }
  }
  $("buildBtn").addEventListener("click", startBuild);
  $("retryBtn").addEventListener("click", () => { show($("buildError"), false); show($("progress"), false); state.inspected = false; invalidate(); startBuild(); });

  function poll(jobId) {
    clearInterval(state.polling);
    const tick = async () => {
      let j;
      try { j = await api("GET", `/api/jobs/${jobId}`); } catch (e) {
        clearInterval(state.polling); state.building = false; $("buildBtn").disabled = false;
        $("beMsg").textContent = e.message; $("beHint").textContent = "انتهت صلاحية المهمة؛ ابدأ من جديد."; $("beLog").parentElement.hidden = true; show($("retryBtn"), false); show($("buildError")); return;
      }
      $("barFill").style.width = j.progress + "%"; $("pct").textContent = j.progress + "%";
      renderStages(j.stage);
      const box = $("logBox"); const atEnd = box.scrollTop + box.clientHeight >= box.scrollHeight - 20;
      box.textContent = j.log.join("\n"); if (atEnd) box.scrollTop = box.scrollHeight;
      if (j.state === "done") {
        clearInterval(state.polling); state.building = false; $("buildBtn").disabled = false;
        $("apkMeta").textContent = `${j.apk.name} · ${fmt(j.apk.size)}`;
        const a = $("downloadBtn"); a.href = j.apk.url; a.setAttribute("download", j.apk.name);
        show($("doneBox"));
        state.jobId = null; state.inspected = false; // server removed the sources after the build
      } else if (j.state === "error") {
        clearInterval(state.polling); state.building = false; $("buildBtn").disabled = false;
        $("beMsg").textContent = j.error.message; $("beHint").textContent = j.error.hint || "";
        $("beLog").textContent = j.error.log_tail || ""; $("beLog").parentElement.hidden = !j.error.log_tail;
        show($("retryBtn"), true); show($("buildError"));
        state.jobId = null; state.inspected = false;
      }
    };
    state.polling = setInterval(tick, 1000); tick();
  }

  $("siteUrl").addEventListener("input", () => { $("siteUrl").classList.remove("bad"); state.inspected = false; });
  $("appName").addEventListener("input", () => $("appName").classList.remove("bad"));

  loadEnv();
  setMode("files");
})();
