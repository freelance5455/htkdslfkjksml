"""Generates a real Android (Gradle) project that wraps the user's web files in a WebView.

Only the fixed template below is ever built - uploaded files are copied into
``app/src/main/assets/www`` as data and are never part of the build scripts.
"""
from __future__ import annotations

import json
import re
import shutil
import struct
import zlib
from pathlib import Path
from urllib.parse import urlparse
from xml.sax.saxutils import escape

AGP_VERSION = "8.5.2"
COMPILE_SDK = 34
MIN_SDK = 21
TARGET_SDK = 34

JAVA_KEYWORDS = set(
    """abstract assert boolean break byte case catch char class const continue default do double else enum
    extends final finally float for goto if implements import instanceof int interface long native new package
    private protected public return short static strictfp super switch synchronized this throw throws transient
    try void volatile while true false null""".split()
)


class ConfigError(Exception):
    def __init__(self, message: str, hint: str = ""):
        super().__init__(message)
        self.message = message
        self.hint = hint


def slugify(name: str, fallback: str = "app") -> str:
    s = re.sub(r"[^a-z0-9]+", "", name.lower())
    return s or fallback


def validate_config(raw: dict, job_id: str) -> dict:
    cfg: dict = {}
    name = str(raw.get("app_name", "")).strip()
    if not (1 <= len(name) <= 40) or any(ord(c) < 32 for c in name):
        raise ConfigError("اسم التطبيق مطلوب (1–40 حرفًا بدون رموز تحكم).")
    cfg["app_name"] = name

    pkg = str(raw.get("package", "")).strip().lower()
    if not pkg:
        pkg = f"com.web2app.app{job_id[:8]}"
    if not re.fullmatch(r"[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*){1,4}", pkg) or any(p in JAVA_KEYWORDS for p in pkg.split(".")):
        raise ConfigError(
            "اسم الحزمة (Package) غير صالح.",
            "استخدم حروفًا إنجليزية صغيرة وأرقامًا مفصولة بنقاط، مثل: com.example.myapp (ولا تستخدم كلمات Java المحجوزة).",
        )
    cfg["package"] = pkg

    ver = str(raw.get("version_name", "1.0.0")).strip() or "1.0.0"
    if not re.fullmatch(r"\d+(\.\d+){0,3}", ver):
        raise ConfigError("رقم الإصدار غير صالح.", "مثال صحيح: 1.0.0")
    cfg["version_name"] = ver
    try:
        vc = int(raw.get("version_code", 1) or 1)
    except (TypeError, ValueError):
        raise ConfigError("رمز الإصدار (version code) يجب أن يكون عددًا صحيحًا.")
    if not 1 <= vc <= 2_100_000_000:
        raise ConfigError("رمز الإصدار خارج النطاق المسموح.")
    cfg["version_code"] = vc

    orient = raw.get("orientation", "auto")
    if orient not in ("portrait", "landscape", "auto"):
        raise ConfigError("اتجاه الشاشة غير صالح.")
    cfg["orientation"] = orient

    color = str(raw.get("splash_color", "#4F46E5")).strip()
    if not re.fullmatch(r"#[0-9a-fA-F]{6}", color):
        raise ConfigError("لون شاشة البداية يجب أن يكون بصيغة #RRGGBB.")
    cfg["splash_color"] = color.upper()

    mode = raw.get("mode", "local")
    if mode not in ("local", "url"):
        raise ConfigError("وضع التحويل غير صالح.")
    cfg["mode"] = mode
    cfg["url"] = ""
    if mode == "url":
        url = str(raw.get("url", "")).strip()
        u = urlparse(url)
        if u.scheme not in ("http", "https") or not u.hostname or u.username or u.password or len(url) > 2048:
            raise ConfigError("رابط الموقع غير صالح.", "يجب أن يبدأ بـ https:// (أو http://) ويحتوي على اسم نطاق.")
        cfg["url"] = url
    return cfg


# ---------------------------------------------------------------- icons --------------------------------

def _png(size: int, pixel) -> bytes:
    raw = bytearray()
    for y in range(size):
        raw.append(0)
        for x in range(size):
            raw += bytes(pixel(x, y))

    def chunk(tag: bytes, data: bytes) -> bytes:
        c = struct.pack(">I", len(data)) + tag + data
        return c + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF)

    return (
        b"\x89PNG\r\n\x1a\n"
        + chunk(b"IHDR", struct.pack(">IIBBBBB", size, size, 8, 6, 0, 0, 0))
        + chunk(b"IDAT", zlib.compress(bytes(raw), 9))
        + chunk(b"IEND", b"")
    )


def default_icon(size: int, color_hex: str) -> bytes:
    r, g, b = (int(color_hex[i:i + 2], 16) for i in (1, 3, 5))
    s = float(size)
    radius = s * 0.22

    def coverage(d: float) -> float:  # signed distance -> anti-aliased alpha
        return max(0.0, min(1.0, 0.5 - d))

    def pixel(x, y):
        px, py = x + 0.5, y + 0.5
        # rounded square
        qx, qy = abs(px - s / 2) - (s / 2 - radius), abs(py - s / 2) - (s / 2 - radius)
        d = (max(qx, 0) ** 2 + max(qy, 0) ** 2) ** 0.5 + min(max(qx, qy), 0) - radius
        a = coverage(d)
        # white ring + dot (generic "app" glyph)
        dist = ((px - s / 2) ** 2 + (py - s / 2) ** 2) ** 0.5
        ring = coverage(abs(dist - s * 0.26) - s * 0.045)
        dot = coverage(dist - s * 0.09)
        w = max(ring, dot)
        rr = round(r * (1 - w) + 255 * w)
        gg = round(g * (1 - w) + 255 * w)
        bb = round(b * (1 - w) + 255 * w)
        return rr, gg, bb, round(255 * a)

    return _png(size, pixel)


DENSITIES = {"mdpi": 48, "hdpi": 72, "xhdpi": 96, "xxhdpi": 144, "xxxhdpi": 192}


def write_icons(res_dir: Path, color: str, custom_icon: Path | None):
    try:
        from PIL import Image  # optional
    except Exception:  # pragma: no cover
        Image = None
    for dens, px in DENSITIES.items():
        d = res_dir / f"mipmap-{dens}"
        d.mkdir(parents=True, exist_ok=True)
        out = d / "ic_launcher.png"
        if custom_icon and custom_icon.exists():
            if Image is not None:
                img = Image.open(custom_icon).convert("RGBA")
                side = max(img.size)
                canvas = Image.new("RGBA", (side, side), (0, 0, 0, 0))
                canvas.paste(img, ((side - img.width) // 2, (side - img.height) // 2))
                canvas.resize((px, px), Image.LANCZOS).save(out, "PNG")
            else:
                shutil.copyfile(custom_icon, out)  # already validated as PNG upstream
        else:
            out.write_bytes(default_icon(px, color))


# ---------------------------------------------------------------- templates ---------------------------

SETTINGS_GRADLE = """pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}
rootProject.name = "Web2AppGenerated"
include(":app")
"""

ROOT_BUILD_GRADLE = f"""plugins {{
    id 'com.android.application' version '{AGP_VERSION}' apply false
}}
"""

GRADLE_PROPERTIES = """org.gradle.jvmargs=-Xmx1536m -Dfile.encoding=UTF-8
android.useAndroidX=false
android.nonTransitiveRClass=true
"""

APP_BUILD_GRADLE = """plugins {
    id 'com.android.application'
}

def ksPath = System.getenv('W2A_KEYSTORE')

android {
    namespace '%(package)s'
    compileSdk %(compile_sdk)d

    defaultConfig {
        applicationId '%(package)s'
        minSdk %(min_sdk)d
        targetSdk %(target_sdk)d
        versionCode %(version_code)d
        versionName '%(version_name)s'
    }

    signingConfigs {
        release {
            if (ksPath) {
                storeFile file(ksPath)
                storePassword System.getenv('W2A_KEYSTORE_PASS')
                keyAlias System.getenv('W2A_KEY_ALIAS') ?: 'web2app'
                keyPassword System.getenv('W2A_KEYSTORE_PASS')
            }
        }
    }

    buildTypes {
        release {
            minifyEnabled false
            shrinkResources false
            signingConfig signingConfigs.release
        }
    }

    compileOptions {
        sourceCompatibility JavaVersion.VERSION_1_8
        targetCompatibility JavaVersion.VERSION_1_8
    }

    androidResources {
        noCompress 'mp3', 'mp4', 'ogg', 'webm', 'wav', 'm4a', 'wasm', 'woff2'
    }

    lint {
        abortOnError false
        checkReleaseBuilds false
    }
}
"""

MANIFEST = """<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">
%(permissions)s
    <application
        android:allowBackup="false"
        android:icon="@mipmap/ic_launcher"
        android:label="@string/app_name"
        android:supportsRtl="true"
        android:usesCleartextTraffic="%(cleartext)s"
        android:theme="@android:style/Theme.Material.Light.NoActionBar">
        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:hardwareAccelerated="true"
            android:screenOrientation="%(orientation)s"
            android:configChanges="orientation|screenSize|smallestScreenSize|screenLayout|keyboardHidden|keyboard|uiMode|layoutDirection"
            android:windowSoftInputMode="adjustResize">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>
"""

ORIENTATION_MAP = {"portrait": "portrait", "landscape": "landscape", "auto": "fullSensor"}

MAIN_ACTIVITY = r'''package %(package)s;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.JsResult;
import android.webkit.MimeTypeMap;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ImageView;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/**
 * Generated by Web2App Studio. Hosts the bundled web project inside a WebView.
 * Local files are served from assets/www through a virtual https origin so that
 * fetch(), ES modules, service-worker-free SPAs and absolute paths behave like on a real server.
 */
public class MainActivity extends Activity {
    private static final boolean REMOTE_MODE = %(remote_mode)s;
    private static final String START_URL_REMOTE = %(start_url)s;
    private static final String ENTRY = %(entry)s;
    private static final int SPLASH_COLOR = Color.parseColor(%(splash_color)s);
    private static final String HOST = "appassets.local";
    private static final String ORIGIN = "https://" + HOST;
    private static final int FILE_CHOOSER = 4711;

    private WebView web;
    private FrameLayout root;
    private View splash;
    private boolean splashGone = false;
    private long startedAt;
    private String failedUrl;
    private ValueCallback<Uri[]> pendingChooser;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private static final Map<String, String> MIME = new HashMap<>();

    static {
        MIME.put("js", "text/javascript");
        MIME.put("mjs", "text/javascript");
        MIME.put("css", "text/css");
        MIME.put("html", "text/html");
        MIME.put("htm", "text/html");
        MIME.put("json", "application/json");
        MIME.put("webmanifest", "application/manifest+json");
        MIME.put("svg", "image/svg+xml");
        MIME.put("wasm", "application/wasm");
        MIME.put("woff", "font/woff");
        MIME.put("woff2", "font/woff2");
        MIME.put("ttf", "font/ttf");
        MIME.put("otf", "font/otf");
        MIME.put("ico", "image/x-icon");
        MIME.put("webp", "image/webp");
        MIME.put("avif", "image/avif");
        MIME.put("mp4", "video/mp4");
        MIME.put("webm", "video/webm");
        MIME.put("mp3", "audio/mpeg");
        MIME.put("ogg", "audio/ogg");
        MIME.put("m4a", "audio/mp4");
        MIME.put("txt", "text/plain");
        MIME.put("xml", "application/xml");
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        startedAt = System.currentTimeMillis();
        Window w = getWindow();
        w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        w.setStatusBarColor(SPLASH_COLOR);
        w.setNavigationBarColor(SPLASH_COLOR);

        root = new FrameLayout(this);
        root.setBackgroundColor(SPLASH_COLOR);
        web = new WebView(this);
        web.setBackgroundColor(Color.WHITE);
        root.addView(web, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        FrameLayout s = new FrameLayout(this);
        s.setBackgroundColor(SPLASH_COLOR);
        ImageView icon = new ImageView(this);
        icon.setImageResource(getApplicationInfo().icon);
        int size = (int) (112 * getResources().getDisplayMetrics().density);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(size, size);
        lp.gravity = android.view.Gravity.CENTER;
        s.addView(icon, lp);
        splash = s;
        root.addView(splash, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(root);

        configureWebView();

        if (savedInstanceState != null && web.restoreState(savedInstanceState) != null) {
            // state restored
        } else {
            web.loadUrl(REMOTE_MODE ? START_URL_REMOTE : ORIGIN + "/" + ENTRY);
        }
        ui.postDelayed(this::hideSplash, 8000); // never leave the splash up forever
    }

    private void configureWebView() {
        WebSettings st = web.getSettings();
        st.setJavaScriptEnabled(true);
        st.setDomStorageEnabled(true);
        st.setDatabaseEnabled(true);
        st.setMediaPlaybackRequiresUserGesture(false);
        st.setAllowFileAccess(false);
        st.setAllowContentAccess(false);
        st.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        st.setSupportZoom(false);
        st.setBuiltInZoomControls(false);
        st.setLoadWithOverviewMode(true);
        st.setUseWideViewPort(true);

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if (HOST.equals(u.getHost()) && "https".equals(u.getScheme())) {
                    return serveAsset(u.getPath());
                }
                return null;
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                String scheme = u.getScheme() == null ? "" : u.getScheme();
                if (HOST.equals(u.getHost())) {
                    if ("/__retry".equals(u.getPath()) && failedUrl != null) {
                        view.loadUrl(failedUrl);
                        return true;
                    }
                    return false;
                }
                if (REMOTE_MODE && (scheme.equals("http") || scheme.equals("https"))
                        && sameSite(u.getHost(), Uri.parse(START_URL_REMOTE).getHost())) {
                    return false;
                }
                openExternal(u);
                return true;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                long wait = Math.max(0, 700 - (System.currentTimeMillis() - startedAt));
                ui.postDelayed(MainActivity.this::hideSplash, wait);
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, android.webkit.WebResourceError error) {
                if (request.isForMainFrame() && REMOTE_MODE) {
                    failedUrl = request.getUrl().toString();
                    view.loadDataWithBaseURL(ORIGIN + "/__offline", offlinePage(), "text/html", "UTF-8", null);
                }
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onJsAlert(WebView view, String url, String message, final JsResult result) {
                new AlertDialog.Builder(MainActivity.this).setMessage(message)
                        .setPositiveButton(android.R.string.ok, (d, i) -> result.confirm())
                        .setOnCancelListener(d -> result.cancel()).show();
                return true;
            }

            @Override
            public boolean onJsConfirm(WebView view, String url, String message, final JsResult result) {
                new AlertDialog.Builder(MainActivity.this).setMessage(message)
                        .setPositiveButton(android.R.string.ok, (d, i) -> result.confirm())
                        .setNegativeButton(android.R.string.cancel, (d, i) -> result.cancel())
                        .setOnCancelListener(d -> result.cancel()).show();
                return true;
            }

            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (pendingChooser != null) pendingChooser.onReceiveValue(null);
                pendingChooser = callback;
                try {
                    startActivityForResult(params.createIntent(), FILE_CHOOSER);
                } catch (ActivityNotFoundException e) {
                    pendingChooser = null;
                    return false;
                }
                return true;
            }
        });

        web.setDownloadListener((url, ua, cd, mime, len) -> openExternal(Uri.parse(url)));
    }

    private static boolean sameSite(String a, String b) {
        if (a == null || b == null) return false;
        a = a.toLowerCase(Locale.ROOT);
        b = b.toLowerCase(Locale.ROOT);
        return a.equals(b) || a.endsWith("." + b) || b.endsWith("." + a);
    }

    private void openExternal(Uri u) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, u));
        } catch (ActivityNotFoundException ignored) {
            // no handler installed - nothing else to do
        }
    }

    private WebResourceResponse serveAsset(String path) {
        if (path == null || path.equals("") || path.equals("/")) path = "/" + ENTRY;
        String rel = Uri.decode(path).replaceAll("^/+", "");
        if (rel.contains("..")) return notFound();
        try {
            InputStream in = getAssets().open("www/" + rel);
            return respond(rel, in);
        } catch (IOException e) {
            try { // directory-style URL -> index.html inside it
                String dir = rel.endsWith("/") ? rel : rel + "/";
                return respond(dir + "index.html", getAssets().open("www/" + dir + "index.html"));
            } catch (IOException e2) {
                return notFound();
            }
        }
    }

    private WebResourceResponse respond(String rel, InputStream in) {
        String ext = MimeTypeMap.getFileExtensionFromUrl(rel.replace(" ", "_"));
        if (ext == null || ext.isEmpty()) {
            int dot = rel.lastIndexOf('.');
            ext = dot >= 0 ? rel.substring(dot + 1) : "";
        }
        ext = ext.toLowerCase(Locale.ROOT);
        String mime = MIME.get(ext);
        if (mime == null) mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext);
        if (mime == null) mime = "application/octet-stream";
        boolean text = mime.startsWith("text/") || mime.equals("application/json") || mime.equals("application/xml")
                || mime.equals("application/manifest+json") || mime.equals("image/svg+xml") || mime.equals("text/javascript");
        WebResourceResponse r = new WebResourceResponse(mime, text ? "UTF-8" : null, in);
        Map<String, String> h = new HashMap<>();
        h.put("Access-Control-Allow-Origin", "*");
        h.put("Cache-Control", "no-cache");
        r.setResponseHeaders(h);
        return r;
    }

    private WebResourceResponse notFound() {
        WebResourceResponse r = new WebResourceResponse("text/plain", "UTF-8", new ByteArrayInputStream("Not found".getBytes()));
        r.setStatusCodeAndReasonPhrase(404, "Not Found");
        return r;
    }

    private String offlinePage() {
        return "<!doctype html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>"
                + "<style>body{font-family:sans-serif;display:flex;min-height:100vh;align-items:center;justify-content:center;margin:0;background:#f5f5f7;color:#222;text-align:center}"
                + "a{display:inline-block;margin-top:16px;padding:12px 28px;border-radius:12px;background:#4F46E5;color:#fff;text-decoration:none}</style></head>"
                + "<body><div><h2>No connection</h2><p>Check your internet connection and try again.</p>"
                + "<a href='" + ORIGIN + "/__retry'>Retry</a></div></body></html>";
    }

    private void hideSplash() {
        if (splashGone || splash == null) return;
        splashGone = true;
        splash.animate().alpha(0f).setDuration(250).withEndAction(() -> splash.setVisibility(View.GONE)).start();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == FILE_CHOOSER && pendingChooser != null) {
            pendingChooser.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data));
            pendingChooser = null;
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        web.saveState(outState);
    }

    @Override
    protected void onPause() {
        super.onPause();
        web.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        web.onResume();
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        ui.removeCallbacksAndMessages(null);
        if (web != null) {
            root.removeView(web);
            web.destroy();
        }
        super.onDestroy();
    }
}
'''


def _java_str(value: str) -> str:
    return json.dumps(value, ensure_ascii=True)  # valid Java string literal (\uXXXX escapes)


def _xml_string(value: str) -> str:
    v = escape(value).replace("'", "\\'").replace('"', '\\"')
    if v[:1] in ("@", "?"):
        v = "\\" + v
    return v


def generate(project_dir: Path, web_root: Path | None, entry: str, cfg: dict, needs_internet: bool,
             custom_icon: Path | None) -> None:
    """Write a complete Gradle project into project_dir."""
    if project_dir.exists():
        shutil.rmtree(project_dir)
    app = project_dir / "app"
    main = app / "src" / "main"
    java_dir = main / "java" / Path(*cfg["package"].split("."))
    res = main / "res"
    java_dir.mkdir(parents=True)
    (res / "values").mkdir(parents=True)

    (project_dir / "settings.gradle").write_text(SETTINGS_GRADLE, "utf-8")
    (project_dir / "build.gradle").write_text(ROOT_BUILD_GRADLE, "utf-8")
    (project_dir / "gradle.properties").write_text(GRADLE_PROPERTIES, "utf-8")
    (app / "build.gradle").write_text(
        APP_BUILD_GRADLE % {
            "package": cfg["package"], "compile_sdk": COMPILE_SDK, "min_sdk": MIN_SDK, "target_sdk": TARGET_SDK,
            "version_code": cfg["version_code"], "version_name": cfg["version_name"],
        }, "utf-8")

    remote = cfg["mode"] == "url"
    need_net = remote or needs_internet
    permissions = '    <uses-permission android:name="android.permission.INTERNET" />' if need_net else "    <!-- no permissions required: fully offline app -->"
    cleartext = "true" if (remote and cfg["url"].lower().startswith("http://")) else "false"
    (main / "AndroidManifest.xml").write_text(
        MANIFEST % {
            "permissions": permissions, "cleartext": cleartext,
            "orientation": ORIENTATION_MAP[cfg["orientation"]],
        }, "utf-8")

    (res / "values" / "strings.xml").write_text(
        '<?xml version="1.0" encoding="utf-8"?>\n<resources>\n'
        f'    <string name="app_name">{_xml_string(cfg["app_name"])}</string>\n</resources>\n', "utf-8")

    (java_dir / "MainActivity.java").write_text(
        MAIN_ACTIVITY % {
            "package": cfg["package"],
            "remote_mode": "true" if remote else "false",
            "start_url": _java_str(cfg["url"]),
            "entry": _java_str(entry),
            "splash_color": _java_str(cfg["splash_color"]),
        }, "utf-8")

    write_icons(res, cfg["splash_color"], custom_icon)

    assets = main / "assets" / "www"
    assets.mkdir(parents=True)
    if web_root is not None and not remote:
        shutil.copytree(web_root, assets, dirs_exist_ok=True)
    else:
        (assets / ".keep").write_text("", "utf-8")
