"""Safe staging and validation of user-uploaded web projects.

Nothing here ever executes uploaded content. Files are only inspected as bytes/text.
"""
from __future__ import annotations

import os
import posixpath
import re
import shutil
import stat
import zipfile
from pathlib import Path
from urllib.parse import unquote

ALLOWED_EXT = {
    # documents / code (static assets only - never executed server side)
    "html", "htm", "css", "js", "mjs", "json", "txt", "xml", "svg", "map", "md", "csv",
    "webmanifest", "wasm",
    # images
    "png", "jpg", "jpeg", "gif", "webp", "ico", "bmp", "avif",
    # fonts
    "woff", "woff2", "ttf", "otf", "eot",
    # media
    "mp3", "ogg", "wav", "m4a", "aac", "mp4", "webm", "ogv",
}
TEXT_EXT = {"html", "htm", "css", "js", "mjs", "json", "txt", "xml", "svg", "map", "md", "csv", "webmanifest"}
MAGIC = {
    "png": (b"\x89PNG\r\n\x1a\n",),
    "jpg": (b"\xff\xd8\xff",),
    "jpeg": (b"\xff\xd8\xff",),
    "gif": (b"GIF87a", b"GIF89a"),
    "ico": (b"\x00\x00\x01\x00", b"\x00\x00\x02\x00"),
    "woff": (b"wOFF",),
    "woff2": (b"wOF2",),
    "wasm": (b"\x00asm",),
    "bmp": (b"BM",),
    "ttf": (b"\x00\x01\x00\x00", b"true", b"ttcf"),
    "otf": (b"OTTO",),
}
IGNORED_NAMES = {".ds_store", "thumbs.db", "desktop.ini"}
IGNORED_PREFIXES = ("__macosx/",)

MAX_FILE_BYTES = int(os.environ.get("W2A_MAX_FILE_MB", "50")) * 1024 * 1024
MAX_TOTAL_BYTES = int(os.environ.get("W2A_MAX_TOTAL_MB", "200")) * 1024 * 1024
MAX_FILES = int(os.environ.get("W2A_MAX_FILES", "5000"))
MAX_ZIP_RATIO = 200  # per-entry compression ratio guard (zip bombs)
MAX_PATH_LEN = 240


class ValidationError(Exception):
    def __init__(self, message: str, hint: str = ""):
        super().__init__(message)
        self.message = message
        self.hint = hint


class Budget:
    """Tracks total bytes/files written to the staging dir."""

    def __init__(self):
        self.bytes = 0
        self.files = 0

    def add_file(self):
        self.files += 1
        if self.files > MAX_FILES:
            raise ValidationError(
                f"عدد الملفات يتجاوز الحد المسموح ({MAX_FILES}).",
                "احذف الملفات غير الضرورية (مثل node_modules أو ملفات المصدر) وأعد المحاولة.",
            )

    def add_bytes(self, n: int):
        self.bytes += n
        if self.bytes > MAX_TOTAL_BYTES:
            raise ValidationError(
                f"الحجم الإجمالي للمشروع يتجاوز {MAX_TOTAL_BYTES // (1024 * 1024)} م.ب.",
                "اضغط الصور والفيديوهات أو احذف الملفات غير المستخدمة.",
            )


def clean_rel(path: str) -> str | None:
    """Normalise an uploaded relative path. Returns None for ignorable junk, raises on unsafe."""
    if not isinstance(path, str) or not path:
        raise ValidationError("مسار ملف فارغ.")
    if "\x00" in path or any(ord(c) < 32 for c in path):
        raise ValidationError("اسم ملف يحتوي على رموز تحكم غير مسموحة.")
    p = path.replace("\\", "/")
    if p.startswith("/") or re.match(r"^[A-Za-z]:", p):
        raise ValidationError(f"مسار مطلق غير مسموح: {path}", "استخدم مسارات نسبية داخل المشروع فقط.")
    parts = [x for x in p.split("/") if x not in ("", ".")]
    if any(x == ".." for x in parts):
        raise ValidationError(f"محاولة تجاوز المجلد غير مسموحة: {path}")
    if not parts:
        raise ValidationError("مسار ملف فارغ.")
    norm = "/".join(parts)
    if len(norm) > MAX_PATH_LEN:
        raise ValidationError(f"مسار الملف طويل جدًا: {norm[:60]}…")
    low = norm.lower()
    if parts[-1].lower() in IGNORED_NAMES or any(low.startswith(x) for x in IGNORED_PREFIXES):
        return None
    if any(seg.startswith(".") and seg.lower() not in (".well-known",) for seg in parts):
        return None  # hidden files/dirs such as .git are dropped silently
    return norm


def ext_of(rel: str) -> str:
    return rel.rsplit(".", 1)[-1].lower() if "." in posixpath.basename(rel) else ""


def check_head(rel: str, head: bytes):
    ext = ext_of(rel)
    if ext not in ALLOWED_EXT:
        raise ValidationError(
            f"نوع الملف غير مسموح: {rel}",
            "الأنواع المسموحة: HTML/CSS/JS/JSON وصور وخطوط وصوت وفيديو. الملفات التنفيذية (exe, sh, apk, dex, so…) محظورة.",
        )
    if ext in MAGIC and not any(head.startswith(m) for m in MAGIC[ext]):
        raise ValidationError(
            f"محتوى الملف لا يطابق امتداده: {rel}",
            "تأكد أن الملف صورة/خط حقيقي وليس ملفًا أعيدت تسميته.",
        )
    if ext == "webp" and not (head[:4] == b"RIFF" and head[8:12] == b"WEBP"):
        raise ValidationError(f"محتوى الملف لا يطابق امتداده: {rel}")
    if ext in TEXT_EXT and b"\x00" in head:
        raise ValidationError(f"الملف النصي يحتوي على بيانات ثنائية: {rel}")
    if ext in ("exe", "dll") or head[:2] == b"MZ" or head[:4] == b"\x7fELF" or head[:4] == b"dex\n":
        raise ValidationError(f"ملف تنفيذي محظور: {rel}")


def _copy_limited(read, dest: Path, rel: str, budget: Budget, declared: int | None = None):
    dest.parent.mkdir(parents=True, exist_ok=True)
    first = True
    size = 0
    with open(dest, "wb") as out:
        while True:
            chunk = read(1024 * 256)
            if not chunk:
                break
            if first:
                check_head(rel, chunk[:64])
                first = False
            size += len(chunk)
            if size > MAX_FILE_BYTES:
                raise ValidationError(
                    f"الملف كبير جدًا (> {MAX_FILE_BYTES // (1024 * 1024)} م.ب): {rel}",
                    "اضغط الملف أو استبدله بنسخة أصغر.",
                )
            budget.add_bytes(len(chunk))
            out.write(chunk)
    if first:  # empty file
        check_head(rel, b"")


def extract_zip(zip_path: Path, dest: Path, budget: Budget):
    try:
        zf = zipfile.ZipFile(zip_path)
    except zipfile.BadZipFile:
        raise ValidationError("ملف ZIP تالف أو غير صالح.", "أعد ضغط المشروع بصيغة ZIP القياسية.")
    with zf:
        infos = zf.infolist()
        if len(infos) > MAX_FILES * 2:
            raise ValidationError("ملف ZIP يحتوي على عدد مبالغ فيه من العناصر.")
        declared = sum(i.file_size for i in infos)
        if declared > MAX_TOTAL_BYTES:
            raise ValidationError(
                f"الحجم بعد فك الضغط ({declared // (1024 * 1024)} م.ب) يتجاوز الحد المسموح.",
                "قد يكون الملف قنبلة ضغط أو يحتوي ملفات كبيرة غير لازمة.",
            )
        for info in infos:
            if info.is_dir():
                continue
            if info.flag_bits & 0x1:
                raise ValidationError("ملف ZIP محمي بكلمة مرور وغير مدعوم.", "أعد ضغطه بدون كلمة مرور.")
            mode = info.external_attr >> 16
            ftype = stat.S_IFMT(mode)  # 0 when the archiver stored only permission bits
            if ftype == stat.S_IFLNK:
                raise ValidationError(f"روابط رمزية غير مسموحة داخل ZIP: {info.filename}")
            if ftype not in (0, stat.S_IFREG):
                raise ValidationError(f"عنصر غير عادي داخل ZIP: {info.filename}")
            if info.compress_size > 0 and info.file_size / max(info.compress_size, 1) > MAX_ZIP_RATIO and info.file_size > 10 * 1024 * 1024:
                raise ValidationError(f"نسبة ضغط مشبوهة للملف: {info.filename}")
            rel = clean_rel(info.filename)
            if rel is None:
                continue
            budget.add_file()
            target = dest / rel
            _ensure_inside(dest, target)
            if target.exists():
                raise ValidationError(f"ملف مكرر داخل المشروع: {rel}")
            with zf.open(info) as src:
                _copy_limited(src.read, target, rel, budget, info.file_size)


def _ensure_inside(base: Path, target: Path):
    b = base.resolve()
    t = target.resolve()
    if b != t and b not in t.parents:
        raise ValidationError("محاولة الكتابة خارج مجلد المشروع.")


def stage_uploads(files_dir: Path, zips_dir: Path, web_dir: Path) -> Budget:
    """Copy validated uploads into web_dir. Originals under files_dir/zips_dir stay untouched."""
    if web_dir.exists():
        shutil.rmtree(web_dir)
    web_dir.mkdir(parents=True)
    budget = Budget()
    for z in sorted(zips_dir.glob("*.zip")) if zips_dir.exists() else []:
        extract_zip(z, web_dir, budget)
    if files_dir.exists():
        for f in sorted(p for p in files_dir.rglob("*") if p.is_file()):
            rel = clean_rel(f.relative_to(files_dir).as_posix())
            if rel is None:
                continue
            budget.add_file()
            target = web_dir / rel
            _ensure_inside(web_dir, target)
            if target.exists():
                raise ValidationError(f"ملف مكرر داخل المشروع: {rel}")
            with open(f, "rb") as src:
                _copy_limited(src.read, target, rel, budget)
    if budget.files == 0:
        raise ValidationError("لم يتم رفع أي ملفات صالحة.", "ارفع ملف HTML أو ZIP أو مجلد المشروع.")
    return budget


def _list_files(root: Path) -> list[str]:
    return sorted(p.relative_to(root).as_posix() for p in root.rglob("*") if p.is_file())


def locate_entry(web_dir: Path) -> tuple[str, str]:
    """Returns (root_rel, entry_rel). root_rel is the directory used as the app root ('' = web_dir)."""
    files = _list_files(web_dir)
    htmls = [f for f in files if ext_of(f) in ("html", "htm")]
    if not htmls:
        raise ValidationError(
            "لم يتم العثور على أي ملف HTML في المشروع.",
            "تأكد أن المشروع يحتوي على index.html (أو ملف HTML واحد على الأقل).",
        )
    indexes = sorted((f for f in htmls if posixpath.basename(f).lower() == "index.html"), key=lambda f: (f.count("/"), f))
    if indexes:
        best = indexes[0]
        root = posixpath.dirname(best)
        return root, posixpath.basename(best)
    if len(htmls) == 1:
        f = htmls[0]
        return posixpath.dirname(f), posixpath.basename(f)
    raise ValidationError(
        "لم أجد index.html وهناك عدة ملفات HTML: " + "، ".join(htmls[:6]),
        "أعد تسمية الصفحة الرئيسية إلى index.html.",
    )


_REF_RE = re.compile(r"""(?:src|href|poster|data-src)\s*=\s*["']([^"'#?][^"']*)["']""", re.I)
_URL_RE = re.compile(r"""url\(\s*["']?([^"')]+)["']?\s*\)""", re.I)
_EXT_RE = re.compile(r"https?://(?!www\.w3\.org|schemas\.|purl\.org)[A-Za-z0-9.-]+", re.I)
_A_TAG = re.compile(r"<a\b[^>]*>", re.I)


def analyze(app_root: Path, entry_rel: str) -> dict:
    files = _list_files(app_root)
    total = sum((app_root / f).stat().st_size for f in files)
    warnings: list[str] = []
    needs_internet = False
    for f in files:
        ext = ext_of(f)
        if ext not in ("html", "htm", "css", "js", "mjs"):
            continue
        try:
            text = (app_root / f).read_text("utf-8", errors="ignore")
        except OSError:
            continue
        scan_text = _A_TAG.sub("", text) if ext in ("html", "htm") else text
        if _EXT_RE.search(scan_text):
            needs_internet = True
        if ext in ("html", "htm", "css"):
            refs = _URL_RE.findall(text)
            if ext != "css":
                refs += _REF_RE.findall(text)
            for ref in refs:
                ref = ref.strip()
                if not ref or re.match(r"^(?:[a-z][a-z0-9+.-]*:|//|#|\{|<|\$)", ref, re.I):
                    continue
                clean = unquote(re.split(r"[?#]", ref)[0])
                if not clean:
                    continue
                base = "" if clean.startswith("/") else posixpath.dirname(f)
                target = posixpath.normpath(posixpath.join(base, clean.lstrip("/")))
                if target.startswith("..") or (app_root / target).exists():
                    continue
                if (app_root / target).is_dir():
                    continue
                if ext in ("html", "htm") and "." not in posixpath.basename(clean):
                    continue  # probably a route, not a file
                warnings.append(f"{f} يشير إلى ملف غير موجود: {clean}")
    warnings = list(dict.fromkeys(warnings))[:20]
    return {
        "entry": entry_rel,
        "file_count": len(files),
        "total_bytes": total,
        "needs_internet": needs_internet,
        "warnings": warnings,
        "files": files[:200],
    }
