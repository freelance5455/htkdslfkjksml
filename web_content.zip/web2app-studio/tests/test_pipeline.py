"""End-to-end tests for everything that can be verified without an Android SDK.

Run:  python3 -m unittest tests/test_pipeline.py -v
Set W2A_EXPECT_APK=1 on a machine with the SDK to additionally require a real APK.
"""
import io
import json
import os
import re
import shutil
import socket
import stat
import subprocess
import sys
import tempfile
import threading
import time
import unittest
import urllib.request
import urllib.error
import zipfile
from http.server import ThreadingHTTPServer
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "server"))
os.environ["W2A_DATA"] = tempfile.mkdtemp(prefix="w2a-test-")

import app as appmod  # noqa: E402
import android_project as ap  # noqa: E402
import builder  # noqa: E402

DEMO = ROOT / "samples" / "demo-site"


def free_port():
    s = socket.socket(); s.bind(("127.0.0.1", 0)); p = s.getsockname()[1]; s.close(); return p


class Client:
    def __init__(self, base): self.base = base

    def call(self, method, path, body=None, headers=None):
        req = urllib.request.Request(self.base + path, data=body, method=method, headers=headers or {})
        try:
            with urllib.request.urlopen(req, timeout=30) as r:
                raw = r.read()
                return r.status, raw, dict(r.headers)
        except urllib.error.HTTPError as e:
            return e.code, e.read(), dict(e.headers)

    def json(self, method, path, obj=None, body=None, headers=None):
        if obj is not None:
            body, headers = json.dumps(obj).encode(), {"Content-Type": "application/json"}
        code, raw, _ = self.call(method, path, body, headers)
        return code, json.loads(raw or b"{}")


class Base(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        appmod.JOBS_DIR.mkdir(parents=True, exist_ok=True)
        port, pport = free_port(), free_port()
        cls.srv = ThreadingHTTPServer(("127.0.0.1", port), appmod.Handler)
        cls.psrv = ThreadingHTTPServer(("127.0.0.1", pport), appmod.PreviewHandler)
        for s in (cls.srv, cls.psrv):
            s.daemon_threads = True
            threading.Thread(target=s.serve_forever, daemon=True).start()
        cls.c = Client(f"http://127.0.0.1:{port}")
        cls.p = Client(f"http://127.0.0.1:{pport}")

    @classmethod
    def tearDownClass(cls):
        cls.srv.shutdown(); cls.psrv.shutdown()
        shutil.rmtree(os.environ["W2A_DATA"], ignore_errors=True)

    def new_job(self):
        code, d = self.c.json("POST", "/api/jobs")
        self.assertEqual(code, 201)
        return d["id"]

    def put(self, jid, rel, data, kind="file"):
        from urllib.parse import quote
        qs = "kind=zip" if kind == "zip" else "path=" + quote(rel)
        return self.c.json("PUT", f"/api/jobs/{jid}/files?{qs}", body=data, headers={"Content-Type": "application/octet-stream"})

    def upload_demo(self, jid):
        for f in DEMO.rglob("*"):
            if f.is_file():
                code, d = self.put(jid, f.relative_to(DEMO).as_posix(), f.read_bytes())
                self.assertEqual(code, 200, d)


class TestUploadAndPreview(Base):
    def test_health_reports_environment_honestly(self):
        code, d = self.c.json("GET", "/api/health")
        self.assertEqual(code, 200)
        self.assertIn("can_build", d)
        if not d["can_build"]:
            self.assertTrue(d["problems"] and all(p["hint"] for p in d["problems"]))

    def test_inspect_detects_index_and_serves_preview(self):
        jid = self.new_job(); self.upload_demo(jid)
        code, info = self.c.json("POST", f"/api/jobs/{jid}/inspect")
        self.assertEqual(code, 200, info)
        self.assertEqual(info["entry"], "index.html")
        self.assertFalse(info["needs_internet"])
        self.assertEqual(info["warnings"], [])
        self.assertEqual(info["file_count"], 6)
        # preview on the isolated origin
        st, body, hdr = self.p.call("GET", info["preview_path"])
        self.assertEqual(st, 200); self.assertIn("تطبيق تجريبي".encode(), body)
        self.assertIn("sandbox", hdr.get("Content-Security-Policy", ""))
        st, body, hdr = self.p.call("GET", f"/preview/{jid}/assets/data.json")
        self.assertEqual(st, 200); self.assertIn("application/json", hdr["Content-Type"])
        # main origin must not serve previews' uploaded content paths of other kinds
        self.assertEqual(self.p.call("GET", "/api/health")[0], 404)
        st, body, _ = self.p.call("GET", f"/preview/{jid}/../../etc/passwd")
        self.assertIn(st, (403, 404)); self.assertNotIn(b"root:", body)

    def test_zip_with_nested_root_folder(self):
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w") as z:
            z.writestr("my-site/index.html", "<html><body>hi <img src='img/a.png'></body></html>")
            z.writestr("my-site/css/a.css", "body{background:url('../img/missing.png')}")
            z.writestr("__MACOSX/._index.html", "junk")
            z.writestr("my-site/.DS_Store", "junk")
        jid = self.new_job()
        self.assertEqual(self.put(jid, "x.zip", buf.getvalue(), "zip")[0], 200)
        code, info = self.c.json("POST", f"/api/jobs/{jid}/inspect")
        self.assertEqual(code, 200, info)
        self.assertEqual(info["entry"], "index.html")
        self.assertEqual(info["file_count"], 2)
        self.assertTrue(any("img/a.png" in w for w in info["warnings"]))
        self.assertTrue(any("missing.png" in w for w in info["warnings"]))

    def test_detects_external_resources_need_internet(self):
        jid = self.new_job()
        self.put(jid, "index.html", b"<html><script src='https://cdn.example.com/x.js'></script><a href='https://other.com'>x</a></html>")
        code, info = self.c.json("POST", f"/api/jobs/{jid}/inspect")
        self.assertTrue(info["needs_internet"])
        jid2 = self.new_job()
        self.put(jid2, "index.html", b"<html><a href='https://other.com'>only a link</a></html>")
        self.assertFalse(self.c.json("POST", f"/api/jobs/{jid2}/inspect")[1]["needs_internet"])

    def test_no_html_is_a_clear_error(self):
        jid = self.new_job(); self.put(jid, "style.css", b"body{}")
        code, d = self.c.json("POST", f"/api/jobs/{jid}/inspect")
        self.assertEqual(code, 400); self.assertIn("HTML", d["error"]["message"]); self.assertTrue(d["error"]["hint"])


class TestSecurity(Base):
    def zip_bytes(self, entries, symlink=None):
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w") as z:
            for name, data in entries.items():
                z.writestr(name, data)
            if symlink:
                zi = zipfile.ZipInfo(symlink[0]); zi.create_system = 3
                zi.external_attr = (stat.S_IFLNK | 0o777) << 16
                z.writestr(zi, symlink[1])
        return buf.getvalue()

    def inspect_zip(self, data):
        jid = self.new_job(); self.put(jid, "p.zip", data, "zip")
        return self.c.json("POST", f"/api/jobs/{jid}/inspect")

    def test_zip_slip_rejected(self):
        code, d = self.inspect_zip(self.zip_bytes({"index.html": "<html></html>", "../../evil.html": "x"}))
        self.assertEqual(code, 400); self.assertIn("تجاوز", d["error"]["message"])
        self.assertFalse((Path(os.environ["W2A_DATA"]) / "evil.html").exists())

    def test_absolute_path_rejected(self):
        code, d = self.inspect_zip(self.zip_bytes({"index.html": "<html></html>", "/etc/cron.d/x.html": "x"}))
        self.assertEqual(code, 400)

    def test_symlink_in_zip_rejected(self):
        code, d = self.inspect_zip(self.zip_bytes({"index.html": "<html></html>"}, symlink=("link.html", "/etc/passwd")))
        self.assertEqual(code, 400); self.assertIn("رمزية", d["error"]["message"])

    def test_executables_rejected(self):
        code, d = self.inspect_zip(self.zip_bytes({"index.html": "<html></html>", "run.sh": "rm -rf /"}))
        self.assertEqual(code, 400); self.assertIn("غير مسموح", d["error"]["message"])
        code, d = self.inspect_zip(self.zip_bytes({"index.html": "<html></html>", "a.png": b"MZ\x90\x00 not an image"}))
        self.assertEqual(code, 400)

    def test_disguised_image_rejected(self):
        jid = self.new_job()
        self.put(jid, "index.html", b"<html></html>")
        self.put(jid, "fake.png", b"<?php system($_GET[0]); ?>")
        code, d = self.c.json("POST", f"/api/jobs/{jid}/inspect")
        self.assertEqual(code, 400); self.assertIn("لا يطابق", d["error"]["message"])

    def test_zip_bomb_declared_size_rejected(self):
        # 150 MB of zeros compresses to ~150 KB -> ratio guard / size guard must stop it
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
            z.writestr("index.html", "<html></html>")
            z.writestr("big.json", b"0" * (60 * 1024 * 1024))
        code, d = self.inspect_zip(buf.getvalue())
        self.assertEqual(code, 400)

    def test_path_traversal_in_single_upload(self):
        jid = self.new_job()
        code, d = self.put(jid, "../../etc/evil.html", b"x")
        self.assertEqual(code, 400)
        code, d = self.put(jid, "/abs/evil.html", b"x")
        self.assertEqual(code, 400)

    def test_bad_extension_rejected_on_upload(self):
        jid = self.new_job()
        code, d = self.put(jid, "payload.exe", b"MZ")
        self.assertEqual(code, 400)

    def test_hidden_files_silently_ignored(self):
        jid = self.new_job()
        code, d = self.put(jid, ".git/config", b"[core]")
        self.assertEqual(code, 200); self.assertTrue(d.get("ignored"))

    def test_corrupt_zip(self):
        code, d = self.inspect_zip(b"this is not a zip")
        self.assertEqual(code, 400); self.assertIn("ZIP", d["error"]["message"])

    def test_bad_job_ids_and_state(self):
        self.assertEqual(self.c.call("GET", "/api/jobs/../../etc")[0], 404)
        self.assertEqual(self.c.call("GET", "/api/jobs/" + "0" * 32)[0], 404)
        self.assertEqual(self.c.call("GET", "/api/jobs/" + "0" * 32 + "/download")[0], 404)
        jid = self.new_job()
        self.assertEqual(self.c.call("GET", f"/api/jobs/{jid}/download")[0], 404)  # no fake download
        self.assertEqual(self.c.call("GET", "/static/../app.py")[0], 404)

    def test_invalid_icon_rejected(self):
        jid = self.new_job()
        code, raw, _ = self.c.call("PUT", f"/api/jobs/{jid}/icon", b"not an image", {"Content-Type": "application/octet-stream"})
        self.assertEqual(code, 400)


class TestConfig(unittest.TestCase):
    def v(self, **kw):
        base = {"app_name": "تطبيقي", "mode": "local"}; base.update(kw)
        return ap.validate_config(base, "a" * 32)

    def test_defaults(self):
        c = self.v()
        self.assertEqual(c["package"], "com.web2app.appaaaaaaaa"); self.assertEqual(c["orientation"], "auto")

    def test_rejects_bad_values(self):
        for kw in ({"app_name": ""}, {"package": "com.class.app"}, {"package": "Bad Pkg"}, {"package": "x"},
                   {"version_name": "1.0-beta"}, {"orientation": "diagonal"}, {"splash_color": "red"},
                   {"mode": "url", "url": "javascript:alert(1)"}, {"mode": "url", "url": "https://u:p@x.com"}, {"mode": "url", "url": "x"}):
            with self.assertRaises(ap.ConfigError, msg=str(kw)):
                self.v(**kw)


class TestAndroidProject(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def gen(self, **over):
        cfg = ap.validate_config({"app_name": over.pop("app_name", "تطبيق \"تجريبي\" <&> 'x'"), "mode": over.pop("mode", "local"),
                                  "orientation": over.pop("orientation", "landscape"), "splash_color": "#112233",
                                  "package": "com.test.demo", "url": over.pop("url", "")}, "b" * 32)
        proj = self.tmp / "android"
        ap.generate(proj, DEMO if cfg["mode"] == "local" else None, "index.html", cfg, over.pop("needs_internet", False), None)
        return proj, cfg

    def test_offline_project_structure_and_no_permissions(self):
        proj, _ = self.gen()
        m = proj / "app/src/main/AndroidManifest.xml"
        txt = m.read_text("utf-8")
        self.assertNotIn("uses-permission android:name", txt)
        self.assertIn('android:screenOrientation="landscape"', txt)
        self.assertTrue((proj / "app/src/main/assets/www/index.html").exists())
        self.assertTrue((proj / "app/src/main/assets/www/assets/data.json").exists())
        for d in ("mdpi", "hdpi", "xhdpi", "xxhdpi", "xxxhdpi"):
            png = (proj / f"app/src/main/res/mipmap-{d}/ic_launcher.png").read_bytes()
            self.assertTrue(png.startswith(b"\x89PNG"))
        # original sample must be untouched
        self.assertTrue((DEMO / "index.html").exists())

    def test_xml_wellformed_with_hostile_app_name(self):
        proj, _ = self.gen()
        for x in ("app/src/main/AndroidManifest.xml", "app/src/main/res/values/strings.xml"):
            r = subprocess.run(["xmllint", "--noout", str(proj / x)], capture_output=True, text=True)
            self.assertEqual(r.returncode, 0, r.stderr)

    def test_url_mode_internet_permission_and_cleartext(self):
        proj, _ = self.gen(mode="url", url="http://example.com/app")
        txt = (proj / "app/src/main/AndroidManifest.xml").read_text()
        self.assertIn("android.permission.INTERNET", txt); self.assertIn('usesCleartextTraffic="true"', txt)
        proj2, _ = self.gen(mode="url", url="https://example.com")
        self.assertIn('usesCleartextTraffic="false"', (proj2 / "app/src/main/AndroidManifest.xml").read_text())

    def test_needs_internet_adds_permission_for_local(self):
        proj, _ = self.gen(needs_internet=True)
        self.assertIn("android.permission.INTERNET", (proj / "app/src/main/AndroidManifest.xml").read_text())

    def test_java_has_no_syntax_errors(self):
        """No android.jar here, so ignore unresolved symbols and fail only on real syntax errors."""
        if not shutil.which("javac"):
            self.skipTest("javac missing")
        proj, _ = self.gen(app_name="x")
        java = next(proj.rglob("MainActivity.java"))
        r = subprocess.run(["javac", "-proc:none", "-d", str(self.tmp / "out"), str(java)], capture_output=True, text=True)
        errs = [l for l in r.stderr.splitlines() if ": error:" in l]
        syntax = [l for l in errs if not re.search(r"cannot find symbol|does not exist|cannot be resolved|incompatible types|package .* does not|does not override|cannot be applied|cannot be dereferenced|no suitable|unreported exception", l)]
        self.assertEqual(syntax, [], "\n".join(syntax))

    def test_gradle_files_reference_valid_values(self):
        proj, cfg = self.gen()
        g = (proj / "app/build.gradle").read_text()
        self.assertIn("namespace 'com.test.demo'", g); self.assertIn(f"compileSdk {ap.COMPILE_SDK}", g)
        self.assertIn(ap.AGP_VERSION, (proj / "build.gradle").read_text())


class TestBuildPipelineHonesty(Base):
    def test_build_requires_inspection_then_runs_real_pipeline(self):
        jid = self.new_job(); self.upload_demo(jid)
        code, d = self.c.json("POST", f"/api/jobs/{jid}/build", {"app_name": "x"})
        self.assertEqual(code, 409)  # must inspect first
        self.assertEqual(self.c.json("POST", f"/api/jobs/{jid}/inspect")[0], 200)
        code, d = self.c.json("POST", f"/api/jobs/{jid}/build", {"app_name": ""})
        self.assertEqual(code, 400)
        code, d = self.c.json("POST", f"/api/jobs/{jid}/build", {"app_name": "تطبيق تجريبي", "orientation": "portrait"})
        self.assertEqual(code, 202)
        for _ in range(900):
            time.sleep(1 if os.environ.get("W2A_EXPECT_APK") else 0.2)
            code, j = self.c.json("GET", f"/api/jobs/{jid}")
            if j["state"] in ("done", "error"):
                break
        pre = builder.preflight()
        if pre["can_build"]:
            self.assertEqual(j["state"], "done", j.get("error"))
            code, raw, hdr = self.c.call("GET", f"/api/jobs/{jid}/download")
            self.assertEqual(code, 200); self.assertTrue(zipfile.is_zipfile(io.BytesIO(raw)))
            self.assertEqual(hdr["Content-Type"], "application/vnd.android.package-archive")
            with zipfile.ZipFile(io.BytesIO(raw)) as z:
                names = z.namelist()
            self.assertIn("AndroidManifest.xml", names); self.assertIn("assets/www/index.html", names)
        else:
            # Honest failure: clear message, never a fake download
            self.assertEqual(j["state"], "error")
            self.assertIn("لا يمكن بناء APK", j["error"]["message"]); self.assertTrue(j["error"]["hint"])
            self.assertEqual(self.c.call("GET", f"/api/jobs/{jid}/download")[0], 404)
        # temp build material removed either way
        self.assertFalse((appmod.JOBS_DIR / jid / "android").exists())
        self.assertFalse((appmod.JOBS_DIR / jid / "uploads").exists())
        self.assertFalse((appmod.JOBS_DIR / jid / "web").exists())


class TestOrchestrationWithFakeGradle(Base):
    """Exercises our Python orchestration (progress parsing, error mapping, APK discovery/verification,
    cleanup, real keystore creation via keytool) using a FAKE gradle. It does NOT test Gradle/Android itself."""

    FAKE_OK = r"""#!/usr/bin/env python3
import sys, os, zipfile, pathlib
proj = pathlib.Path(sys.argv[sys.argv.index('-p') + 1])
assert os.environ.get('W2A_KEYSTORE') and pathlib.Path(os.environ['W2A_KEYSTORE']).exists()
assert (proj / 'app/src/main/assets/www/index.html').exists()
for t in (':app:preBuild', ':app:mergeReleaseResources', ':app:compileReleaseJavaWithJavac', ':app:packageRelease'):
    print('> Task ' + t, flush=True)
out = proj / 'app/build/outputs/apk/release'; out.mkdir(parents=True)
with zipfile.ZipFile(out / 'app-release.apk', 'w') as z:
    z.writestr('AndroidManifest.xml', b'x'); z.writestr('classes.dex', b'dex\n035'); z.writestr('META-INF/WEB2APP.RSA', b'sig')
    z.writestr('assets/www/index.html', (proj / 'app/src/main/assets/www/index.html').read_bytes())
print('BUILD SUCCESSFUL')
"""
    FAKE_FAIL = "#!/bin/sh\necho '> Task :app:preBuild'\necho 'Could not GET https://dl.google.com/x. java.net.UnknownHostException: dl.google.com'\nexit 1\n"

    def run_with(self, script):
        sdk = Path(tempfile.mkdtemp()); (sdk / "platforms/android-34").mkdir(parents=True)
        (sdk / "build-tools/34.0.0").mkdir(parents=True); (sdk / "licenses").mkdir()
        gradle = sdk / "fake-gradle"; gradle.write_text(script); gradle.chmod(0o755)
        old = {k: os.environ.get(k) for k in ("ANDROID_HOME", "GRADLE_BIN")}
        os.environ["ANDROID_HOME"], os.environ["GRADLE_BIN"] = str(sdk), str(gradle)
        try:
            jid = self.new_job(); self.upload_demo(jid)
            self.c.json("POST", f"/api/jobs/{jid}/inspect")
            code, _ = self.c.json("POST", f"/api/jobs/{jid}/build", {"app_name": "اختبار", "package": "com.test.fake"})
            self.assertEqual(code, 202)
            for _ in range(200):
                time.sleep(0.1)
                j = self.c.json("GET", f"/api/jobs/{jid}")[1]
                if j["state"] in ("done", "error"):
                    break
            return jid, j
        finally:
            for k, v in old.items():
                os.environ.pop(k, None) if v is None else os.environ.__setitem__(k, v)
            shutil.rmtree(sdk, ignore_errors=True)

    def test_success_path_delivers_verified_apk_and_cleans_up(self):
        jid, j = self.run_with(self.FAKE_OK)
        self.assertEqual(j["state"], "done", j.get("error")); self.assertEqual(j["progress"], 100)
        self.assertTrue(j["apk"]["name"].endswith("-v1.0.0.apk"))
        code, raw, hdr = self.c.call("GET", j["apk"]["url"])
        self.assertEqual(code, 200); self.assertEqual(hdr["Content-Type"], "application/vnd.android.package-archive")
        self.assertIn("attachment", hdr["Content-Disposition"])
        with zipfile.ZipFile(io.BytesIO(raw)) as z:
            self.assertIn("assets/www/index.html", z.namelist())
        jd = appmod.JOBS_DIR / jid
        self.assertFalse((jd / "android").exists()); self.assertFalse((jd / "uploads").exists()); self.assertFalse((jd / "web").exists())
        ks = Path(os.environ["W2A_DATA"]) / "keystore" / "web2app.jks"
        self.assertTrue(ks.exists()); self.assertEqual(oct(ks.stat().st_mode & 0o777), "0o600")
        r = subprocess.run(["keytool", "-list", "-keystore", str(ks), "-storepass",
                            (ks.parent / "pass.txt").read_text().strip()], capture_output=True, text=True)
        self.assertEqual(r.returncode, 0); self.assertIn("web2app", r.stdout)
        self.assertEqual(self.c.json("DELETE", f"/api/jobs/{jid}")[0], 200)
        self.assertEqual(self.c.call("GET", j["apk"]["url"])[0], 404)

    def test_network_failure_is_explained(self):
        jid, j = self.run_with(self.FAKE_FAIL)
        self.assertEqual(j["state"], "error")
        self.assertIn("تنزيل", j["error"]["message"]); self.assertIn("services.gradle.org", j["error"]["hint"])
        self.assertIn("UnknownHostException", j["error"]["log_tail"])
        self.assertEqual(self.c.call("GET", f"/api/jobs/{jid}/download")[0], 404)

    def test_verify_rejects_incomplete_apk(self):
        bad = Path(tempfile.mkdtemp()) / "x.apk"
        with zipfile.ZipFile(bad, "w") as z:
            z.writestr("AndroidManifest.xml", b"x")
        with self.assertRaises(builder.BuildError):
            builder.verify_apk(bad, "com.x.y")


if __name__ == "__main__":
    unittest.main(verbosity=2)
