(async () => {
  const count = document.getElementById("count");
  let n = 0;
  try { n = Number(localStorage.getItem("clicks")) || 0; } catch (e) {}
  count.textContent = n;
  document.getElementById("btn").addEventListener("click", () => {
    n++; count.textContent = n;
    try { localStorage.setItem("clicks", n); } catch (e) {}
  });
  try {
    const res = await fetch("assets/data.json");
    document.getElementById("msg").textContent = (await res.json()).message;
  } catch (e) {
    document.getElementById("msg").textContent = "تعذّر تحميل البيانات المحلية";
  }
})();
