/* radar.js — نقشه‌ی سبک (بدون کتابخانه‌ی خارجی) + رادار RainViewer + باد و بارش مدل (Open-Meteo)
   نکات RainViewer (از ۱ ژانویه ۲۰۲۶ در پلن رایگان): فقط رادار گذشته، فقط پالت Universal Blue (۲)،
   حداکثر زوم ۷ (بالاتر از آن تصویر بزرگ‌نمایی می‌شود)، سقف ۱۰۰ درخواست در دقیقه برای هر IP. */
(function (root) {
  "use strict";
  const C = root.AshnakhorCore;
  const TILE = 256, MINZ = 4, MAXZ = 15;
  const BASES = {
    map: { name: "نقشه", maxNative: 19, url: (z, x, y) => "https://tile.openstreetmap.org/" + z + "/" + x + "/" + y + ".png",
      attr: "© OpenStreetMap" },
    sat: { name: "ماهواره", maxNative: 18, url: (z, x, y) => "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/" + z + "/" + y + "/" + x,
      attr: "Esri, Maxar, Earthstar Geographics" }
  };
  const M = { el: null, pane: null, W: 0, H: 0, z: 7, clat: C.LAT, clon: C.LON, ox: 0, oy: 0, tx: 0, ty: 0,
    ptrs: {}, drag: null, pinch: null, layers: {}, base: "map", wind: false, prec: false, radar: true,
    pts: [], gridT: 0, frames: [], host: "", fi: 0, framesT: 0, playing: false, timer: null, inited: false, ui: {} };

  // ---------- ریاضی وب‌مرکاتور ----------
  const ws = z => TILE * Math.pow(2, z);
  function proj(lat, lon, z) {
    const s = ws(z), sin = Math.sin(lat * Math.PI / 180);
    return { x: (lon + 180) / 360 * s, y: (0.5 - Math.log((1 + sin) / (1 - sin)) / (4 * Math.PI)) * s };
  }
  function unproj(x, y, z) {
    const s = ws(z), n = Math.PI - 2 * Math.PI * y / s;
    return { lat: 180 / Math.PI * Math.atan(0.5 * (Math.exp(n) - Math.exp(-n))), lon: x / s * 360 - 180 };
  }
  const clampLat = l => Math.max(-80, Math.min(80, l));

  // ---------- لایه‌های کاشی ----------
  function makeLayer(id, o) {
    const wrap = document.createElement("div");
    wrap.style.cssText = "position:absolute;left:0;top:0;width:0;height:0";
    M.pane.appendChild(wrap);
    return (M.layers[id] = Object.assign({ id, wrap, tiles: {}, old: {}, on: true, opacity: 1, maxOver: 99, errors: 0 }, o));
  }
  function clearOld(L) { Object.keys(L.old).forEach(k => L.old[k].remove()); L.old = {}; }
  function dropOld(L, pos) { if (L.old[pos]) { L.old[pos].remove(); delete L.old[pos]; } }
  function swapTiles(L) { // فریم/نقشه‌ی تازه: کاشی‌های قدیمی تا لود شدن جدیدها می‌مانند
    clearOld(L); L.old = L.tiles; L.tiles = {};
    const old = L.old; setTimeout(() => { Object.keys(old).forEach(k => { if (L.old === old && old[k]) { old[k].remove(); delete old[k]; } }); }, 4000);
    renderTiles();
  }
  function drawLayer(L, vx, vy) {
    const z = M.z, nz = Math.min(z, L.maxNative), dz = z - nz, s = Math.pow(2, dz);
    const hidden = !L.on || dz > L.maxOver;
    L.wrap.style.display = hidden ? "none" : "block";
    if (hidden) return;
    const ts = TILE * s, n = Math.pow(2, nz);
    const x0 = Math.floor(vx / ts) - 1, x1 = Math.floor((vx + M.W) / ts) + 1, y0 = Math.floor(vy / ts) - 1, y1 = Math.floor((vy + M.H) / ts) + 1;
    const need = {};
    for (let ty = y0; ty <= y1; ty++) {
      if (ty < 0 || ty >= n) continue;
      for (let tx = x0; tx <= x1; tx++) {
        const wx = ((tx % n) + n) % n, pos = nz + "/" + tx + "/" + ty;
        need[pos] = 1;
        let img = L.tiles[pos];
        if (!img) {
          img = document.createElement("img");
          img.className = "t"; img.alt = ""; img.draggable = false; img.style.opacity = 0;
          img.onload = () => { img.style.opacity = L.opacity; dropOld(L, pos); };
          img.onerror = () => { img.remove(); L.errors++; if (L.onError) L.onError(L); };
          img.src = L.url(nz, wx, ty);
          L.wrap.appendChild(img); L.tiles[pos] = img;
        }
        img.style.left = (tx * ts - M.ox) + "px"; img.style.top = (ty * ts - M.oy) + "px";
        img.style.width = ts + "px"; img.style.height = ts + "px";
      }
    }
    Object.keys(L.tiles).forEach(k => { if (!need[k]) { L.tiles[k].remove(); delete L.tiles[k]; } });
  }
  function renderTiles() {
    const vx = M.ox - M.tx, vy = M.oy - M.ty;
    Object.keys(M.layers).forEach(k => drawLayer(M.layers[k], vx, vy));
  }

  // ---------- نشانگرها (مزرعه، باد، بارش مدل) ----------
  const spdColor = v => v >= 40 ? "#ef4444" : v >= 25 ? "#f59e0b" : v >= 12 ? "#22d3ee" : "#86efac";
  function renderMarkers() {
    const ov = M.overlay;
    ov.innerHTML = "";
    const f = proj(C.LAT, C.LON, M.z);
    const fm = document.createElement("div");
    fm.className = "rv-farm"; fm.style.left = (f.x - M.ox) + "px"; fm.style.top = (f.y - M.oy) + "px";
    fm.title = "مزرعه";
    ov.appendChild(fm);
    if (!(M.wind || M.prec)) return;
    M.pts.forEach((p, i) => {
      const q = proj(p.lat, p.lon, M.z), d = document.createElement("div");
      d.className = "wm"; d.style.left = (q.x - M.ox) + "px"; d.style.top = (q.y - M.oy) + "px";
      let h = "";
      if (M.prec && C.num(p.prec) && p.prec > 0.05) {
        const r = Math.min(26, 8 + p.prec * 6);
        h += '<i class="pc" style="width:' + r * 2 + "px;height:" + r * 2 + 'px"></i>';
      }
      if (M.wind && C.num(p.spd)) {
        h += '<svg class="ar" width="26" height="26" viewBox="-13 -13 26 26" style="transform:rotate(' + Math.round(((p.dir || 0) + 180) % 360) + 'deg)"><path d="M0 -11 L6 7 L0 3.5 L-6 7 Z" fill="' + spdColor(p.spd) + '" stroke="#0b1220" stroke-width="1.4" stroke-linejoin="round"/></svg>';
        h += '<b class="sp">' + Math.round(p.spd) + "</b>";
      }
      if (M.prec && !M.wind && C.num(p.prec)) h += '<b class="sp">' + (p.prec >= 0.05 ? p.prec.toFixed(1) : "۰") + "</b>";
      d.innerHTML = h;
      ov.appendChild(d);
    });
  }

  // ---------- رندر کلی / حرکت ----------
  function setBase() {
    const p = proj(M.clat, M.clon, M.z);
    M.ox = p.x - M.W / 2; M.oy = p.y - M.H / 2; M.tx = 0; M.ty = 0;
    M.pane.style.transform = "translate(0px,0px)";
    Object.keys(M.layers).forEach(k => clearOld(M.layers[k]));
  }
  function render() { setBase(); renderTiles(); renderMarkers(); updateZoomLabel(); }
  function commit() {
    if (!M.tx && !M.ty) return;
    const c = unproj(M.ox - M.tx + M.W / 2, M.oy - M.ty + M.H / 2, M.z);
    M.clat = clampLat(c.lat); M.clon = c.lon;
    render(); moved();
  }
  function setZoom(z) {
    z = Math.max(MINZ, Math.min(MAXZ, z));
    if (z === M.z) return;
    if (M.tx || M.ty) { const c = unproj(M.ox - M.tx + M.W / 2, M.oy - M.ty + M.H / 2, M.z); M.clat = clampLat(c.lat); M.clon = c.lon; }
    M.z = z; render(); moved();
  }
  function goFarm() { M.clat = C.LAT; M.clon = C.LON; M.z = Math.max(M.z, 7); render(); moved(); }
  let gridTimer = null;
  function moved() {
    if (!(M.wind || M.prec)) return;
    clearTimeout(gridTimer);
    gridTimer = setTimeout(fetchGrid, 900);
  }
  const dist = () => { const k = Object.keys(M.ptrs); if (k.length < 2) return 0; const a = M.ptrs[k[0]], b = M.ptrs[k[1]]; return Math.hypot(a.x - b.x, a.y - b.y); };
  let lastTiles = 0;
  function bind() {
    const el = M.el;
    el.addEventListener("pointerdown", e => {
      M.ptrs[e.pointerId] = { x: e.clientX, y: e.clientY };
      const n = Object.keys(M.ptrs).length;
      if (n === 1) M.drag = { sx: e.clientX, sy: e.clientY, tx: M.tx, ty: M.ty, moved: false, x: e.clientX, y: e.clientY };
      else if (n === 2) { M.pinch = { d0: dist(), d: dist() }; M.drag = null; }
    });
    window.addEventListener("pointermove", e => {
      const p = M.ptrs[e.pointerId]; if (!p) return;
      p.x = e.clientX; p.y = e.clientY;
      const n = Object.keys(M.ptrs).length;
      if (n === 2 && M.pinch) { M.pinch.d = dist(); return; }
      if (M.drag && n === 1) {
        const dx = e.clientX - M.drag.sx, dy = e.clientY - M.drag.sy;
        if (Math.abs(dx) + Math.abs(dy) > 4) M.drag.moved = true;
        if (!M.drag.moved) return;
        M.tx = M.drag.tx + dx; M.ty = M.drag.ty + dy;
        M.pane.style.transform = "translate(" + M.tx + "px," + M.ty + "px)";
        const now = Date.now();
        if (now - lastTiles > 120) { lastTiles = now; renderTiles(); }
      }
    });
    const up = e => {
      if (!M.ptrs[e.pointerId]) return;
      const wasDrag = M.drag, hadPinch = M.pinch;
      delete M.ptrs[e.pointerId];
      const n = Object.keys(M.ptrs).length;
      if (hadPinch && n < 2) {
        const r = hadPinch.d0 ? hadPinch.d / hadPinch.d0 : 1;
        M.pinch = null; M.drag = null;
        const dz = r > 2.6 ? 2 : r > 1.3 ? 1 : r < 0.38 ? -2 : r < 0.77 ? -1 : 0;
        if (dz) setZoom(M.z + dz);
        return;
      }
      if (wasDrag && n === 0) {
        M.drag = null;
        if (wasDrag.moved) commit(); else tap(e);
      }
    };
    window.addEventListener("pointerup", up);
    window.addEventListener("pointercancel", up);
    let wl = 0;
    el.addEventListener("wheel", e => { e.preventDefault(); const t = Date.now(); if (t - wl < 250) return; wl = t; setZoom(M.z + (e.deltaY < 0 ? 1 : -1)); }, { passive: false });
    el.addEventListener("dblclick", () => setZoom(M.z + 1));
    window.addEventListener("resize", () => { if (M.inited && !M.hidden) resize(); });
  }
  function tap(e) {
    const r = M.el.getBoundingClientRect(), x = e.clientX - r.left, y = e.clientY - r.top;
    let best = null, bd = 34;
    if (M.wind || M.prec) M.pts.forEach(p => {
      const q = proj(p.lat, p.lon, M.z), d = Math.hypot(q.x - M.ox - x, q.y - M.oy - y);
      if (d < bd) { bd = d; best = p; }
    });
    if (!best) return;
    const f = v => C.num(v) ? Math.round(v) : "—";
    M.ui.info.textContent = "باد " + f(best.spd) + " km/h از " + C.dirName(best.dir) + " • تندباد " + f(best.gust) + " • بارش ساعت جاری " + (C.num(best.prec) ? best.prec.toFixed(1) : "—") + " mm • دما " + f(best.temp) + "°";
  }
  function resize() {
    const r = M.el.getBoundingClientRect();
    if (!r.width) return;
    M.W = r.width; M.H = r.height; render();
  }

  // ---------- RainViewer ----------
  const rvUrl = (z, x, y) => {
    const f = M.frames[M.fi];
    return M.host + f.path + "/256/" + z + "/" + x + "/" + y + "/2/1_1.png";
  };
  async function loadFrames(force) {
    if (!force && M.frames.length && Date.now() - M.framesT < 5 * 60 * 1000) return;
    M.ui.rvmsg.textContent = "در حال دریافت رادار...";
    try {
      const j = await C.getJson("https://api.rainviewer.com/public/weather-maps.json", 15000);
      const past = (j.radar && j.radar.past) || [];
      if (!j.host || !past.length) throw new Error("no frames");
      M.host = j.host; M.frames = past; M.framesT = Date.now(); M.fi = past.length - 1;
      const sl = M.ui.slider; sl.min = 0; sl.max = past.length - 1; sl.value = M.fi;
      M.ui.rvmsg.textContent = "";
      applyFrame(true);
    } catch (e) {
      M.frames = [];
      M.ui.rvmsg.textContent = "رادار RainViewer در دسترس نیست (اینترنت/VPN را چک کنید): " + e.message;
    }
  }
  function frameLabel() {
    const f = M.frames[M.fi];
    if (!f) return "—";
    const t = new Date(f.time * 1000);
    let hm = "";
    try { hm = t.toLocaleTimeString("fa-IR", { hour: "2-digit", minute: "2-digit", timeZone: "Asia/Tehran" }); } catch (e) { hm = t.toTimeString().slice(0, 5); }
    const ago = Math.max(0, Math.round((Date.now() - t.getTime()) / 60000));
    return hm + " (" + (ago < 2 ? "الان" : ago >= 120 ? Math.round(ago / 60) + " ساعت پیش" : ago + " دقیقه پیش") + ")";
  }
  function applyFrame(first) {
    const L = M.layers.radar; if (!L || !M.frames.length) return;
    M.ui.slider.value = M.fi;
    M.ui.time.textContent = frameLabel();
    L.errors = 0;
    if (first) { clearOld(L); Object.keys(L.tiles).forEach(k => L.tiles[k].remove()); L.tiles = {}; renderTiles(); } else swapTiles(L);
  }
  function play() {
    if (!M.frames.length) return;
    if (M.playing) { stop(); return; }
    M.playing = true; M.ui.play.textContent = "⏸"; M.fi = 0; applyFrame();
    M.timer = setInterval(() => {
      if (M.fi >= M.frames.length - 1) return stop();
      M.fi++; applyFrame();
    }, 900);
  }
  function stop() { M.playing = false; clearInterval(M.timer); if (M.ui.play) M.ui.play.textContent = "▶"; }

  // ---------- شبکه‌ی باد و بارش مدل ----------
  async function fetchGrid() {
    if (!(M.wind || M.prec) || !M.inited) return;
    const cols = Math.max(4, Math.min(6, Math.round(M.W / 70))), rows = Math.max(4, Math.min(7, Math.round(M.H / 70)));
    const lats = [], lons = [];
    for (let r = 0; r < rows; r++) for (let c = 0; c < cols; c++) {
      const p = unproj(M.ox - M.tx + (c + 0.5) / cols * M.W, M.oy - M.ty + (r + 0.5) / rows * M.H, M.z);
      lats.push(clampLat(p.lat).toFixed(3)); lons.push(p.lon.toFixed(3));
    }
    M.ui.wmsg.textContent = "در حال دریافت باد/بارش مدل...";
    try {
      const j = await C.getJson("https://api.open-meteo.com/v1/forecast?latitude=" + lats.join(",") + "&longitude=" + lons.join(",") +
        "&current=wind_speed_10m,wind_direction_10m,wind_gusts_10m,precipitation,temperature_2m&wind_speed_unit=kmh&timezone=Asia%2FTehran", 20000);
      if (j && j.error) throw new Error(j.reason || "API error");
      const arr = Array.isArray(j) ? j : [j];
      M.pts = arr.map((o, i) => {
        const c = o.current || {};
        return { lat: +lats[i], lon: +lons[i], spd: c.wind_speed_10m, dir: c.wind_direction_10m, gust: c.wind_gusts_10m, prec: c.precipitation, temp: c.temperature_2m };
      });
      M.gridT = Date.now();
      M.ui.wmsg.textContent = "";
      renderMarkers();
    } catch (e) { M.ui.wmsg.textContent = "دریافت باد/بارش مدل ناموفق بود: " + e.message; }
  }

  // ---------- رابط ----------
  function updateZoomLabel() { if (M.ui.zl) M.ui.zl.textContent = M.z; }
  function chipState() {
    const set = (id, on) => { const e = document.getElementById(id); if (e) e.classList.toggle("on", !!on); };
    set("rv-c-radar", M.radar); set("rv-c-wind", M.wind); set("rv-c-prec", M.prec);
    set("rv-c-map", M.base === "map"); set("rv-c-sat", M.base === "sat");
    M.ui.ctl.style.display = M.radar ? "flex" : "none";
    M.ui.att.textContent = BASES[M.base].attr + (M.radar ? " • رادار: RainViewer.com" : "") + (M.wind || M.prec ? " • باد/بارش مدل: Open-Meteo.com" : "");
    M.ui.leg.style.display = M.radar ? "block" : "none";
  }
  function setBaseMap(b) {
    M.base = b;
    const L = M.layers.base;
    L.maxNative = BASES[b].maxNative; L.url = BASES[b].url;
    swapTiles(L); chipState();
  }
  function toggle(what) {
    if (what === "radar") { M.radar = !M.radar; M.layers.radar.on = M.radar; if (M.radar) loadFrames(); else stop(); renderTiles(); }
    if (what === "wind") M.wind = !M.wind;
    if (what === "prec") M.prec = !M.prec;
    if ((what === "wind" || what === "prec") && (M.wind || M.prec) && Date.now() - M.gridT > 60000) fetchGrid();
    if (!(M.wind || M.prec)) M.ui.wmsg.textContent = "";
    renderMarkers(); chipState();
  }
  function mount(host) {
    host.innerHTML =
      '<div class="card" style="padding:10px"><h2>🛰 رادار باران و باد</h2>' +
      '<div class="chips"><button id="rv-c-radar" class="chip on">🌧 رادار</button><button id="rv-c-wind" class="chip">💨 باد</button><button id="rv-c-prec" class="chip">☔ بارش مدل</button>' +
      '<span class="sp1"></span><button id="rv-c-map" class="chip on">نقشه</button><button id="rv-c-sat" class="chip">ماهواره</button></div>' +
      '<div id="rv-map"><div id="rv-pane"></div>' +
      '<div class="rv-zoom"><button id="rv-zi">+</button><span id="rv-zl"></span><button id="rv-zo">−</button><button id="rv-farm">🎯</button></div>' +
      '<div id="rv-att"></div></div>' +
      '<div id="rv-ctl"><button id="rv-play" class="chip">▶</button><input id="rv-slider" type="range" min="0" max="0" value="0"><span id="rv-time">—</span></div>' +
      '<div class="rv-leg" id="rv-leg"><span>کم</span><i></i><span>زیاد</span></div>' +
      '<div class="note" id="rv-rvmsg"></div><div class="note" id="rv-wmsg"></div><div class="note" id="rv-info">روی فلش باد یا دایره‌ی بارش بزنید تا جزئیات را ببینید.</div>' +
      '<div class="note">رادار فقط وضعیت تا چند دقیقه‌ی پیش را نشان می‌دهد (پیش‌بینی ندارد). اگر روی منطقه‌ی شما پوشش رادار نباشد نقشه‌ی بارش خالی می‌ماند؛ آن‌وقت «بارش مدل» را روشن کنید. فلش باد به سمتی است که باد می‌وزد؛ عدد = km/h.</div></div>';
    const g = id => host.querySelector("#" + id);
    M.el = g("rv-map"); M.pane = g("rv-pane");
    M.ui = { ctl: g("rv-ctl"), slider: g("rv-slider"), time: g("rv-time"), play: g("rv-play"), rvmsg: g("rv-rvmsg"), wmsg: g("rv-wmsg"), info: g("rv-info"), zl: g("rv-zl"), att: g("rv-att"), leg: g("rv-leg") };
    makeLayer("base", { maxNative: BASES.map.maxNative, url: BASES.map.url, opacity: 1 });
    makeLayer("radar", { maxNative: 7, maxOver: 4, opacity: 0.7, url: (z, x, y) => (M.frames.length ? rvUrl(z, x, y) : "data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw=="),
      onError: L => { if (L.errors === 12) M.ui.rvmsg.textContent = "چند کاشی رادار لود نشد (شاید محدودیت ۱۰۰ درخواست در دقیقه یا قطعی اینترنت)؛ کمی بعد دوباره امتحان کنید."; } });
    M.overlay = document.createElement("div");
    M.overlay.style.cssText = "position:absolute;left:0;top:0;width:0;height:0";
    M.pane.appendChild(M.overlay);
    g("rv-c-radar").onclick = () => toggle("radar"); g("rv-c-wind").onclick = () => toggle("wind"); g("rv-c-prec").onclick = () => toggle("prec");
    g("rv-c-map").onclick = () => setBaseMap("map"); g("rv-c-sat").onclick = () => setBaseMap("sat");
    g("rv-zi").onclick = () => setZoom(M.z + 1); g("rv-zo").onclick = () => setZoom(M.z - 1); g("rv-farm").onclick = goFarm;
    g("rv-play").onclick = play;
    M.ui.slider.oninput = () => { stop(); M.fi = +M.ui.slider.value; applyFrame(); };
    bind(); chipState();
  }
  function show() {
    M.hidden = false;
    if (!M.inited) {
      M.inited = true; resize(); loadFrames();
    } else { resize(); loadFrames(); if ((M.wind || M.prec) && Date.now() - M.gridT > 10 * 60 * 1000) fetchGrid(); }
  }
  function hide() { M.hidden = true; stop(); }

  root.AshnakhorRadar = { mount, show, hide, _M: M };
})(typeof self !== "undefined" ? self : globalThis);
