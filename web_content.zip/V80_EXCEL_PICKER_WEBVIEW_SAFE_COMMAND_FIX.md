# V80 Excel picker WebView-safe command fix

Built from V79. The custom `dpm-import://` navigation was causing some Android WebViews to show a renderer/page-not-rendered error before the WebViewClient override could consume it. Choose File now uses an HTTPS-looking local command URL (`https://dpm.local/pick`) that MainActivity intercepts before navigation. No AndroidDPM bridge or WebView file chooser callback is required.

No Supabase/SQL changes.
