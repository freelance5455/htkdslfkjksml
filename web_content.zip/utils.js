window.Utils = {
    formatSize(bytes) {
        if (!bytes || bytes === 0) return '0 B';
        const k = 1024;
        const sizes = ['B', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    },

    async calculateSHA256(buffer) {
        try {
            if (window.crypto && window.crypto.subtle) {
                const hashBuffer = await window.crypto.subtle.digest('SHA-256', buffer);
                const hashArray = Array.from(new Uint8Array(hashBuffer));
                return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
            }
        } catch (e) {
            console.warn('SHA-256 calculation fallback active', e);
        }
        return 'غير متاح حالياً';
    },

    readULEB128(dataView, offset) {
        let result = 0;
        let shift = 0;
        let size = 0;
        let byte = 0;

        do {
            byte = dataView.getUint8(offset + size);
            result |= (byte & 0x7f) << shift;
            shift += 7;
            size++;
        } while ((byte & 0x80) !== 0 && size < 5);

        return { value: result, byteLength: size };
    },

    readMUTF8(bytes) {
        let out = "";
        let i = 0;
        const len = bytes.length;

        while (i < len) {
            let c = bytes[i++];
            switch (c >> 4) {
                case 0: case 1: case 2: case 3: case 4: case 5: case 6: case 7:
                    if (c === 0) break;
                    out += String.fromCharCode(c);
                    break;
                case 12: case 13:
                    out += String.fromCharCode(((c & 0x1F) << 6) | (bytes[i++] & 0x3F));
                    break;
                case 14:
                    out += String.fromCharCode(((c & 0x0F) << 12) | ((bytes[i++] & 0x3F) << 6) | ((bytes[i++] & 0x3F) & 0x3F));
                    break;
            }
        }
        return out;
    }
};
