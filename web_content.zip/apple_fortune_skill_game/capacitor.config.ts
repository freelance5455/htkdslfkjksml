import { CapacitorConfig } from '@capacitor/cli';
const config: CapacitorConfig = {
  appId: 'com.sayed.applefortune.skill',
  appName: 'Apple Fortune Puzzle',
  webDir: 'www'
};
export default config;
