# Apple Fortune Puzzle — مشروع أندرويد

لعبة ألغاز ومهارة مستقلة: 10 صفوف × 5 دوائر، مستويات صعوبة، تفاحات وقنابل، ونظام نقاط فقط. لا يوجد رهان أو رصيد مالي أو جوائز مالية.

## البناء باستخدام Capacitor
يتطلب كمبيوتر عليه Node.js وAndroid Studio:
```bash
npm install
npx cap add android
npx cap sync android
npx cap open android
```
ثم من Android Studio اختر Build > Build Bundle(s) / APK(s) > Build APK(s).

## الملفات
- `www/index.html`: واجهة اللعبة.
- `www/style.css`: التصميم.
- `www/game.js`: منطق اللعبة.
- `capacitor.config.ts`: اسم التطبيق ومعرّفه.

بعد تعديل ملفات www شغّل `npx cap sync android` ثم أعد بناء APK.
