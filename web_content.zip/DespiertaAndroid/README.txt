DESPIERTA 1.6 — Proyecto Android

Este proyecto envuelve el prototipo HTML de Despierta 1.6 en una aplicación Android WebView.

Para generar el APK:
1. Instala Android Studio en una computadora.
2. Abre esta carpeta como proyecto.
3. Espera a que Gradle sincronice.
4. Menú Build > Build APK(s).
5. El APK de depuración quedará en app/build/outputs/apk/debug/.

Nota: esta carpeta incluye el prototipo actual y no requiere conexión a internet para ejecutar el HTML una vez compilada la app.
