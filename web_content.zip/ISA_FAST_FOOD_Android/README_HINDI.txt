ISA FAST FOOD — Android App Project

Is folder mein Android Studio project hai. Yeh abhi compiled APK nahi hai.

APK banane ke liye:
1. Computer par Android Studio install karein.
2. Android Studio mein Open par click karke ISA_FAST_FOOD_Android folder select karein.
3. Gradle sync complete hone dein (internet chahiye; SDK/platform components download ho sakte hain).
4. Build > Build Bundle(s) / APK(s) > Build APK(s) select karein.
5. Build complete hone par app/build/outputs/apk/debug/app-debug.apk milega.
6. APK ko apne Android phone par bhejkar install karein. Zarurat pade to Settings mein is source se install allow karein.

Zaroori notes:
- Menu, orders, settings aur reports abhi isi phone/app ke local browser storage mein rehte hain; yeh online shared database nahi hai.
- WhatsApp order bhejne ke liye Admin Panel mein business phone number country code ke saath save karein, jaise India ke liye 91XXXXXXXXXX.
- Menu ke starting prices 0 hain; Admin Panel mein har item ki price set karein.
- Photo input phone se photo select karne deta hai, lekin current HTML prototype photo ko server par upload nahi karta.
- Is project ko public launch se pehle real device par test karein.
