(function () {
  var A = window.App, $ = A.$, esc = A.esc;
  if (!A.init({ nav: 'profile' })) return;
  var editing = false;

  function stats() {
    var me = A.me(), fr = A.friends();
    $('#st-best').textContent = fr.filter(function (f) { return f.best; }).length;
    $('#st-loc').textContent = fr.filter(function (f) { return f.linked && A.shareOf(f.id) && A.canSee(me.id, f.id); }).length;
    var sent = 0;
    fr.forEach(function (f) { A.msgs(f.id).forEach(function (m) { if (m.from === me.id && m.type !== 'call') sent++; }); });
    $('#st-sent').textContent = sent;
    $('#friends-n').textContent = fr.length;
  }
  function fill() {
    var me = A.me();
    $('#avatar').src = A.avatar(me);
    $('#p-name').textContent = me.name;
    var j = new Date(me.joined);
    $('#p-handle').textContent = '@' + me.username + ' • Katıldı ' + ['Ocak', 'Şubat', 'Mart', 'Nisan', 'Mayıs', 'Haziran', 'Temmuz', 'Ağustos', 'Eylül', 'Ekim', 'Kasım', 'Aralık'][j.getMonth()] + ' ' + j.getFullYear();
    if (!editing) {
      $('#f-name').value = me.name; $('#f-username').value = me.username; $('#f-bio').value = me.bio || '';
    }
    A.$$('input[name="loc_privacy"]').forEach(function (r) { r.checked = r.value === me.privacy; });
    var on = !!(me.twofa && me.twofa.secret);
    var badge = $('#twofa-badge');
    badge.textContent = on ? 'Aktif' : 'Kapalı';
    badge.className = 'text-[10px] font-extrabold px-2 py-0.5 rounded-md ' + (on ? 'text-accent-foreground bg-accent/40' : 'text-muted-foreground bg-muted');
    stats();
  }

  /* ---- düzenleme ---- */
  function setEditing(on) {
    editing = on;
    ['f-name', 'f-username', 'f-bio'].forEach(function (id) {
      var el = $('#' + id); el.disabled = !on; el.classList.toggle('opacity-70', !on);
    });
    $('#edit-btn').style.display = on ? 'none' : 'flex';
    $('#edit-actions').style.display = on ? 'flex' : 'none';
    $('#uname-status').textContent = '';
    if (!on) fill(); else $('#f-name').focus();
  }
  function checkUname() {
    var me = A.me(), v = $('#f-username').value.trim().toLowerCase(), el = $('#uname-status');
    if (!editing || v === me.username) { el.textContent = ''; return; }
    if (!A.usernameValid(v)) { el.textContent = 'Geçersiz'; el.className = 'absolute right-3 top-1/2 -translate-y-1/2 text-xs font-bold text-destructive'; }
    else if (!A.usernameAvailable(v, me.id)) { el.textContent = 'Kullanımda'; el.className = 'absolute right-3 top-1/2 -translate-y-1/2 text-xs font-bold text-destructive'; }
    else { el.textContent = '✓ Kullanılabilir'; el.className = 'absolute right-3 top-1/2 -translate-y-1/2 text-xs font-bold text-accent-foreground'; }
  }
  $('#edit-btn').addEventListener('click', function () { setEditing(true); });
  $('#cancel-btn').addEventListener('click', function () { setEditing(false); });
  $('#f-username').addEventListener('input', checkUname);
  $('#save-btn').addEventListener('click', function () {
    try {
      A.updateProfile({ name: $('#f-name').value, username: $('#f-username').value, bio: $('#f-bio').value.trim().slice(0, 140) });
      setEditing(false); A.toast('Profilin güncellendi');
    } catch (e) { A.toast(e.message, 'error'); }
  });

  /* ---- avatar ---- */
  $('#avatar-btn').addEventListener('click', function () { $('#avatar-input').click(); });
  $('#avatar-input').addEventListener('change', function (e) {
    var f = e.target.files[0]; e.target.value = '';
    if (!f) return;
    if (!/^image\//.test(f.type)) { A.toast('Lütfen bir görsel seç.', 'error'); return; }
    A.cropSquare(f, 256).then(function (d) { A.updateProfile({ avatar: d }); A.toast('Profil fotoğrafın güncellendi'); })
      .catch(function (err) { A.toast(err.message, 'error'); });
  });

  /* ---- gizlilik ---- */
  A.$$('input[name="loc_privacy"]').forEach(function (r) {
    r.addEventListener('change', function () {
      A.updateProfile({ privacy: r.value });
      A.toast({ best: 'Konumunu sadece en iyi arkadaşların görür', all: 'Konumunu tüm arkadaşların görür', ghost: 'Hayalet modu açık: konumun gizli' }[r.value]);
    });
  });

  /* ---- şifre ---- */
  $('#change-pw').addEventListener('click', function () {
    var cls = 'w-full h-12 rounded-2xl bg-input border border-border px-4 text-sm font-semibold outline-none focus:ring-2 focus:ring-ring';
    var s = A.sheet(A.sheetHeader('Şifreyi değiştir') + '<form id="pw-form" class="space-y-3" novalidate>' +
      '<input id="pw-old" type="password" placeholder="Mevcut şifre" autocomplete="current-password" class="' + cls + '" />' +
      '<input id="pw-new" type="password" placeholder="Yeni şifre (en az 8 karakter)" autocomplete="new-password" class="' + cls + '" />' +
      '<input id="pw-new2" type="password" placeholder="Yeni şifre (tekrar)" autocomplete="new-password" class="' + cls + '" />' +
      '<p id="pw-err" class="hidden text-xs font-bold text-destructive"></p>' +
      '<button type="submit" class="w-full h-12 rounded-2xl bg-primary text-primary-foreground font-extrabold">Güncelle</button></form>');
    s.$('#pw-form').addEventListener('submit', function (e) {
      e.preventDefault();
      var err = s.$('#pw-err'); err.classList.add('hidden');
      function fail(m) { err.textContent = m; err.classList.remove('hidden'); }
      var n1 = s.$('#pw-new').value;
      if (n1.length < 8) return fail('Yeni şifre en az 8 karakter olmalı.');
      if (n1 !== s.$('#pw-new2').value) return fail('Yeni şifreler eşleşmiyor.');
      A.changePassword(s.$('#pw-old').value, n1).then(function () { s.close(); A.toast('Şifren değiştirildi'); }).catch(function (x) { fail(x.message); });
    });
  });

  /* ---- iki adımlı doğrulama ---- */
  $('#twofa-btn').addEventListener('click', function () {
    var me = A.me();
    if (!A.totpSupported()) { A.toast('Bu özellik için https veya localhost gerekir.', 'error'); return; }
    var cls = 'w-full h-12 rounded-2xl bg-input border border-border px-4 text-center tracking-[0.4em] text-lg font-extrabold outline-none focus:ring-2 focus:ring-ring';
    if (me.twofa && me.twofa.secret) {
      var s = A.sheet(A.sheetHeader('İki adımlı doğrulamayı kapat', 'Onaylamak için doğrulayıcı uygulamandaki kodu gir') +
        '<form id="t-form" class="space-y-3"><input id="t-code" inputmode="numeric" maxlength="6" placeholder="••••••" autocomplete="one-time-code" class="' + cls + '" /><p id="t-err" class="hidden text-xs font-bold text-destructive"></p>' +
        '<button type="submit" class="w-full h-12 rounded-2xl bg-destructive text-primary-foreground font-extrabold">Kapat</button></form>');
      s.$('#t-form').addEventListener('submit', function (e) {
        e.preventDefault();
        A.verifyTotp(me.twofa.secret, s.$('#t-code').value).then(function (ok) {
          if (!ok) { s.$('#t-err').textContent = 'Kod hatalı.'; s.$('#t-err').classList.remove('hidden'); return; }
          A.updateProfile({ twofa: null }); s.close(); A.toast('İki adımlı doğrulama kapatıldı');
        });
      });
      return;
    }
    var secret = A.newSecret(), pretty = secret.match(/.{1,4}/g).join(' ');
    var uri = 'otpauth://totp/BFF:' + encodeURIComponent(me.username) + '?secret=' + secret + '&issuer=BFF';
    var s2 = A.sheet(A.sheetHeader('İki adımlı doğrulamayı aç', 'Google Authenticator, Authy vb. bir uygulamaya ekle') +
      '<div class="rounded-2xl bg-input border border-border p-3 mb-3"><p class="text-[11px] font-bold text-muted-foreground mb-1">Gizli anahtar</p><p class="font-mono text-sm font-extrabold break-all select-all">' + pretty + '</p>' +
      '<div class="flex gap-2 mt-2"><button type="button" id="t-copy" class="h-9 px-3 rounded-xl bg-card border border-border text-xs font-extrabold">Kopyala</button><a href="' + uri + '" class="h-9 px-3 rounded-xl bg-card border border-border text-xs font-extrabold flex items-center">Uygulamada aç</a></div></div>' +
      '<form id="t-form" class="space-y-3"><input id="t-code" inputmode="numeric" maxlength="6" placeholder="••••••" autocomplete="one-time-code" class="' + cls + '" /><p id="t-err" class="hidden text-xs font-bold text-destructive"></p>' +
      '<button type="submit" class="w-full h-12 rounded-2xl bg-primary text-primary-foreground font-extrabold">Doğrula ve aç</button></form>');
    s2.$('#t-copy').addEventListener('click', function () { A.copyText(secret).then(function () { A.toast('Anahtar kopyalandı'); }); });
    s2.$('#t-form').addEventListener('submit', function (e) {
      e.preventDefault();
      A.verifyTotp(secret, s2.$('#t-code').value).then(function (ok) {
        if (!ok) { s2.$('#t-err').textContent = 'Kod hatalı. Uygulamadaki güncel kodu gir.'; s2.$('#t-err').classList.remove('hidden'); return; }
        A.updateProfile({ twofa: { secret: secret } }); s2.close(); A.toast('İki adımlı doğrulama açıldı 🔒');
      });
    });
  });

  /* ---- paylaş / geri / çıkış ---- */
  $('#share-btn').addEventListener('click', function () {
    var me = A.me(), text = 'BFF\'de beni ekle: @' + me.username;
    if (navigator.share) navigator.share({ title: 'BFF', text: text }).catch(function () {});
    else A.copyText(text).then(function () { A.toast('Kullanıcı adın kopyalandı'); });
  });
  $('#back-btn').addEventListener('click', function () {
    if (history.length > 1 && document.referrer && document.referrer.indexOf(location.host) >= 0) history.back(); else location.href = 'home.html';
  });
  $('#logout-btn').addEventListener('click', function () {
    A.confirm('Çıkış yap', 'Hesabından çıkış yapılacak.', 'Çıkış yap', true).then(function (ok) { if (ok) A.logout(); });
  });
  $('#add-friend').addEventListener('click', function () { A.openAddFriend(); });

  A.onChange(function () { if (!editing) fill(); else stats(); });
  fill(); setEditing(false);
  if (location.hash === '#privacy') { var c = $('#privacy-card'); if (c) c.scrollIntoView({ behavior: 'smooth', block: 'center' }); }
})();
