GolpoPlay বাংলা — Android-friendly starter prototype

এই ZIP-এ আছে:
- index.html: অ্যাপের কাজ করা ডেমো UI
- manifest.webmanifest: PWA ইনস্টল তথ্য
- sw.js: প্রাথমিক offline cache

বর্তমানে যা কাজ করে:
- বাংলা গল্পের কার্ড ও ক্যাটাগরি
- ডেমো গল্পের পেজ
- পয়েন্ট, দৈনিক চেক-ইন ও লোকাল হিস্ট্রি
- নাম সংরক্ষণ
- ছোট স্ক্রিনে ব্যবহারযোগ্য ডিজাইন

গুরুত্বপূর্ণ সীমাবদ্ধতা:
- এখানে বাস্তব নাটকের ভিডিও নেই; ভিডিও প্লেয়ারটি placeholder।
- পয়েন্ট localStorage-এ রাখা হয়; এগুলো নগদ টাকা নয়, অন্য ডিভাইসে সিঙ্ক হয় না এবং নিরাপদ reward ledger নয়।
- কোনো login, admin server, payment, ad network বা cash withdrawal নেই।
- PWA install/offline সুবিধার জন্য HTTPS-এ হোস্ট করতে হবে; ফোনের file manager থেকে HTML খুললেই সব PWA বৈশিষ্ট্য চালু নাও হতে পারে।
- Android APK বানাতে পরের ধাপে Android wrapper/build setup লাগবে। Play Store-এ প্রকাশের জন্য Google-এর বর্তমান নীতি ও ফি যাচাই করতে হবে।

Android-এ পরীক্ষা:
1. ZIP extract করুন।
2. index.html ব্রাউজারে খুলে সাধারণ UI পরীক্ষা করুন।
3. PWA পরীক্ষা করতে HTTPS static hosting-এ তিনটি ফাইল আপলোড করুন।
4. Android Chrome-এ সাইট খুলে browser menu-তে “Install app” বা “Add to Home screen” থাকলে ব্যবহার করুন।

পরের উন্নয়ন:
1. নিজের/লাইসেন্সপ্রাপ্ত ভিডিও যোগ করা
2. server-side login ও admin dashboard
3. নিরাপদ points ledger ও abuse prevention
4. privacy policy, terms, ad policy
5. অনুমোদিত ad network integration
6. payout budget ও Bangladesh-supported payment provider যাচাই
7. Android APK/AAB build ও release testing
