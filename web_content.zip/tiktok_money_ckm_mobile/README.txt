# TikTok Money CKM Mobile — version 2

Application web mobile de suivi et d'aide à la monétisation.

## Nouvelles fonctions
- Assistant qui propose un plan selon les abonnés, les vues, la niche et l'objectif (partenariats, affiliation, LIVE ou croissance).
- Générateur d'idées, d'accroches et d'appels à l'action pour les vidéos.
- Suivi manuel des revenus en USD et CDF, taux modifiable et historique local.

## Tester
Ouvrir `www/index.html` dans un navigateur récent.

## Limites et transparence
L'application ne se connecte pas au compte TikTok, ne peut pas activer les programmes ni garantir des revenus. Elle donne des conseils et outils de préparation. L'accès aux programmes dépend du pays, du compte et des règles TikTok; il faut vérifier les offres affichées dans TikTok Studio. Ne partagez jamais votre mot de passe TikTok dans cette application.

## APK
Ce ZIP est le code source, pas encore un APK compilé.
