package com.example.iraqlive;

// Splash Activity placeholder