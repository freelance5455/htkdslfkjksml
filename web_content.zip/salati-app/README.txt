تحويل صلاتي إلى APK (Capacitor)
================================
1) npm install
2) npx cap add android
3) npx cap sync
4) npx cap open android   (يفتح Android Studio)
5) Build > Build APK(s)

إلا بغيتي الإشعارات تخدم مزيان فـ Android 13+ زيد فـ
android/app/src/main/AndroidManifest.xml:
  <uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>
  <uses-permission android:name="android.permission.SCHEDULE_EXACT_ALARM"/>
