ColorNest Android Project

यह Android Studio प्रोजेक्ट पहले वाले ColorNest HTML ऐप को Android WebView में चलाता है।

APK बनाने के लिए:
1. Android Studio इंस्टॉल करें।
2. इस ZIP को extract करें।
3. Android Studio में extracted ColorNestAndroidProject फ़ोल्डर खोलें।
4. Gradle sync पूरा होने दें (पहली बार इंटरनेट की जरूरत हो सकती है)।
5. Build > Build Bundle(s) / APK(s) > Build APK(s) चुनें।
6. APK आमतौर पर app/build/outputs/apk/debug/app-debug.apk में बनेगा।

ध्यान दें: यह APK फ़ाइल नहीं, APK बनाने के लिए Android Studio source project है। इस वातावरण में Android SDK/Gradle build tools उपलब्ध नहीं हैं, इसलिए यहाँ सीधे installable APK compile नहीं किया जा सका।


ऑटोमैटिक APK बिल्ड (GitHub Actions):
1. ZIP को extract करें और सभी फाइलें एक GitHub repository में upload करें।
2. GitHub repository के Actions टैब में जाएँ।
3. "Build ColorNest APK" workflow चुनें और Run workflow दबाएँ (या main/master पर push करें)।
4. Build सफल होने पर run के Artifacts सेक्शन से ColorNest-debug-APK डाउनलोड करें।
5. ZIP artifact extract करें; उसमें app-debug.apk होगी।

यह तरीका भी GitHub अकाउंट और इंटरनेट वाले ब्राउज़र की माँग करता है। APK यहाँ सीधे compile नहीं हुई है।
