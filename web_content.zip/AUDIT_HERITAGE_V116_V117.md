# Inventaire patrimonial V116 → V117 — vérification du 9 novembre 2026

Cet inventaire est fondé sur l'inspection statique de `index.html` dans l'archive V116 fournie. Il distingue les éléments réellement présents dans le code des fonctions qui restent à porter et à tester. Il ne constitue pas une validation d'exécution de V116.

## Univers et structures historiques confirmés

- **24 galaxies** : Terra Unie, Mars Fédérale, Vénus Impériale, Mercure Solaire, Jupiter Majeure, Saturne des Anneaux, Neptune Abyssale, Uranus Glaciale, Pluton Lointaine, Lune Argentée, Andromède Unie, Orion Suprême, Sirius Doré, Proxima Libre, Kepler Républicaine, Nébuleuse du Crabe, Cassiopée Royale, Pégase Céleste, Centaure Alpha, Lyra Harmonieuse, Vega Éternelle, Solarys Impériale, Éclipse Noire, Astra Nova.
- **60 emplacements d'arènes de clubs** sont préprogrammés dans V116. Ils sont distincts des arènes spéciales.
- **9 arènes spéciales avec règles de jeu** : Terrestre, Néon, Cristalline, Gravitationnelle, Volcanique, Océanique, Temporelle, Dimensionnelle, Galactique Suprême.
- **11 variantes d'arènes visuelles** supplémentaires : Stellaire, Cyber Nexus, Impériale, Boréale, Désertique, Jungle, Métropole, Solaire, Obsidienne, Céleste, Nébuleuse.
- **24 damistes légendaires (13 historiques conservés + 11 nouveaux profils V117) immortels dans V116 ; catalogue V117 enrichi à 24 profils** : Driss, Oyode, Ami, P'tit, Anliou, Koro, Adams, Diak, Traoré, Ranji, Bah, Kader, Isaac.

## Catalogue économique confirmé dans V116

- 12 sponsors dans le catalogue commercial (`CAT`, type `sp`).
- 8 promoteurs/diffuseurs (`CAT`, type `pr`).
- 16 partenaires stratégiques (`CAT`, type `pa`).
- 10 banques dans le catalogue bancaire `BANKS`.
- 22 entreprises dans le catalogue `FIRMS`.

Ces catalogues sont distincts dans le code ; leurs catégories peuvent se recouper dans l'univers économique. Les quantités sont préservées séparément, sans les additionner comme s'il s'agissait d'organismes tous uniques.

## Règles de match et chronométrage relevés

- Damier 10×10 ; 20 pions par camp au départ ; dames volantes ; prises obligatoires et prises multiples ; prise maximale ; promotion.
- **Temps par tour : 10 secondes.** Dans le moteur V116 observé, un dépassement retire automatiquement la dernière pièce du camp fautif (parcours ligne/colonne), puis le tour passe à l'adversaire. Si le camp n'a plus de pièce, il perd.
- **Temps total standard : 5 minutes**, puis prolongation de 3 minutes si le nombre de pièces est égal à l'expiration du temps initial. À l'expiration finale, le résultat est décidé par le nombre de pièces.
- Arène Néon : 2 minutes ; Galactique Suprême : 2 min 30.
- Arène Temporelle : pas de chronomètre total ; limite de 40 coups par camp, puis comparaison du nombre de pièces.
- Le code V116 comprend aussi un seuil de 50 demi-coups sans prise/déplacement de pion pour déclarer la nulle.
- Règles d'arènes supplémentaires : cristaux (promotion à l'arrivée), gravité lourde (dames limitées à 3 cases hors prise), lave (pièce détruite à l'arrivée), prises de pions uniquement vers l'avant dans l'arène Océanique, promotion anticipée dans l'arène Dimensionnelle.

## Intégration déjà réalisée dans le socle V117 0.4

- Nouveau module `src/legacy-catalog.js` avec les listes et quantités historiques ci-dessus.
- Le catalogue est embarqué dans l'état de carrière initial (`world`) et ajouté aux anciennes sauvegardes lors du chargement si ce champ manque.
- Validation des quantités historiques : 24 galaxies, 60 emplacements de clubs, 9 arènes spéciales à règles, 11 variantes visuelles, 24 légendaires (13 profils historiques conservés + 11 nouveaux profils), 10 banques, 12 sponsors, 8 promoteurs, 16 partenaires, 22 entreprises.
- Le moteur refuse maintenant d'appliquer un coup qui n'appartient pas aux coups légaux.
- Le chronométrage de 10 secondes par tour est affiché dans la partie d'essai ; le dépassement applique la pénalité de retrait d'une pièce et transmet le tour.

## Éléments encore à porter / vérifier

- Le chronomètre global de 5 minutes, la prolongation de 3 minutes, les chronomètres propres aux arènes et la limite de 40 coups de l'arène Temporelle ne sont pas encore intégrés dans le moteur V117.
- Les règles d'arènes (cristaux, lave, gravité, promotion anticipée, capture avant uniquement) sont inventoriées mais ne sont pas encore toutes actives dans le moteur V117.
- Les 60 emplacements sont catalogués mais ne sont pas encore attribués aux clubs historiques importés.
- Les pouvoirs des 24 légendaires (13 profils historiques conservés + 11 nouveaux profils), leur acquisition et leurs effets de match restent à porter. Le socle conserve les 13 identités historiques et 11 profils originaux V117, sans activer les pouvoirs. Chaque légendaire est rattaché à une galaxie d’origine distincte.
- Les catalogues économiques sont préservés dans les données ; les systèmes de contrats, négociation, financement, sponsoring, revenus et dépenses restent à développer.
- Les nouvelles structures galactiques demandées restent à concevoir en complément, sans altérer les structures historiques.
- Les quantités des autres structures non énumérées ici restent à inventorier dans V116 avant intégration.

## Limites de preuve

L'inspection du code source et les tests unitaires du nouveau socle ne prouvent pas que toutes les fonctionnalités historiques s'exécutaient correctement dans V116. Aucun test navigateur complet ni partie officielle reliée au calendrier central n'est revendiqué dans ce livrable.

## Étape 0.5 — chronométrage global : module ajouté, intégration en attente
Le module `src/match-clock.js` formalise les durées globales relevées dans le code V116 : 5 min + prolongation 3 min en cas d'égalité de pièces, 2 min pour Néon, 2 min 30 pour Galactique Suprême et 40 tours par camp pour Temporelle. Les décisions à expiration sont couvertes par des tests unitaires. **Ce module n'est pas encore relié à `match-ui.js`** ; il ne faut donc pas présenter le chronométrage global comme déjà actif en match.


## Enrichissement V117 — légendaires et galaxies d'origine
- Le catalogue V117 compte désormais 24 damistes légendaires : les 13 identités historiques sont conservées et 11 nouveaux profils sont ajoutés.
- Chaque profil possède un champ `originGalaxy` et un index `originGalaxyIndex`. Les 24 origines sont distinctes et correspondent exactement aux 24 galaxies du catalogue.
- Les 11 nouveaux noms et leurs pouvoirs sont des créations V117, et non des données historiques attribuées à V116.
- Les sauvegardes antérieures sont migrées à la lecture : les profils manquants et leurs origines sont ajoutés sans perdre les champs existants des 13 légendaires historiques tout en ajoutant les 11 nouveaux profils.

### Registre des 24 légendaires et de leur galaxie d'origine

Les 13 légendaires historiques sont conservés. Les 11 profils suivants sont des créations V117. Le rattachement est individuel : chaque galaxie est l'origine d'un seul légendaire dans ce registre.

- **Driss** — Terra Unie (pouvoir : block)
- **Oyode** — Mars Fédérale (pouvoir : thunder)
- **Ami** — Vénus Impériale (pouvoir : freeze)
- **P'tit** — Mercure Solaire (pouvoir : fire)
- **Anliou** — Jupiter Majeure (pouvoir : cloak)
- **Koro** — Saturne des Anneaux (pouvoir : impossible)
- **Adams** — Neptune Abyssale (pouvoir : stop)
- **Diak** — Uranus Glaciale (pouvoir : hurricane)
- **Traoré** — Pluton Lointaine (pouvoir : magma)
- **Ranji** — Lune Argentée (pouvoir : tsunami)
- **Bah** — Andromède Unie (pouvoir : whirl)
- **Kader** — Orion Suprême (pouvoir : fog)
- **Isaac** — Sirius Doré (pouvoir : sand)
- **Terrax** — Proxima Libre (pouvoir : stone)
- **Marsa** — Kepler Républicaine (pouvoir : red-comet)
- **Vénor** — Nébuleuse du Crabe (pouvoir : solar-flare)
- **Mercurion** — Cassiopée Royale (pouvoir : speed)
- **Jovian** — Pégase Céleste (pouvoir : gravity)
- **Saturnis** — Centaure Alpha (pouvoir : rings)
- **Néptor** — Lyra Harmonieuse (pouvoir : abyss)
- **Uranis** — Vega Éternelle (pouvoir : ice)
- **Plutark** — Solarys Impériale (pouvoir : shadow)
- **Lunaris** — Éclipse Noire (pouvoir : moonlight)
- **Andromar** — Astra Nova (pouvoir : cosmic-wave)

## Étape 0.7 — intégration moteur de dames / arènes / calendrier (9 novembre 2026)

La règle de chronométrage V116 (10 secondes avec retrait d'une pièce) est conservée ci-dessus uniquement comme fait historique du code source. **Elle est remplacée dans V117 à la demande de l'utilisateur par 20 secondes par tour ; à l'échéance, le camp perd la main et l'adversaire joue, sans retrait de pièce.**

### Règles des neuf arènes désormais actives dans le moteur de dames
- Terrestre : règles classiques ; temps global standard de 5 minutes, puis 3 minutes de prolongation si égalité du nombre de pièces.
- Néon : temps global de 2 minutes, sans prolongation.
- Cristalline : quatre cases cristallines couronnent un pion qui y termine son coup.
- Gravitationnelle : dame limitée à 3 cases lors d'un déplacement simple ; les prises restent possibles selon la règle des dames volantes.
- Volcanique : quatre cases de lave détruisent la pièce qui y termine son coup.
- Océanique : les pions ne peuvent prendre que vers l'avant ; les dames gardent les prises dans toutes les directions.
- Temporelle : pas de chrono global ; après 40 coups joués par chaque camp, comparaison du nombre de pièces.
- Dimensionnelle : promotion anticipée à l'avant-dernière rangée.
- Galactique Suprême : chrono de 2 min 30, deux cases de lave et deux cases cristallines.

Les 11 variantes d'arènes visuelles et les 60 emplacements d'arènes de clubs restent des catalogues distincts : aucune règle de jeu ne leur est attribuée par défaut.

### Raccordement au calendrier central
- Une rencontre du club dirigé, encore programmée, peut être lancée depuis le tableau du calendrier.
- Le camp rouge représente le club dirigé même lorsque celui-ci joue à l'extérieur ; le camp bleu représente l'adversaire contrôlé par l'IA.
- À la fin de la partie, victoire/nulle/défaite devient un résultat de championnat 1–0 / 0–0 / 0–1 selon la position domicile/extérieur. Le détail du nombre de pièces, de l'arène et du type de fin est conservé dans `fixture.matchDetails`.
- Le résultat passe par le registre central `recordResult`, qui protège contre les doubles comptabilisations et met à jour le classement.

### Tests et limites
- Tests ajoutés sur les effets des six arènes à règles particulières et sur les quatre cas de liaison au calendrier.
- La partie manuelle utilise bien le moteur de dames et les horloges ; les rencontres des autres clubs continuent d'utiliser la simulation déterministe de carrière. L'IA du damier reste heuristique.
- Le test navigateur complet, la reprise d'une partie interrompue, les compétitions à élimination directe et l'application des arènes aux matchs simulés restent à faire.


## Extension décidée pour V117 — Coupe Fédéral

La V116 comptait sept compétitions historiques, toutes conservées dans V117. À la demande explicite de l'utilisateur, une huitième compétition indépendante est ajoutée : **Coupe Fédéral**, inspirée de la Carabao Cup. Cette nouveauté ne fait pas partie du patrimoine historique V116 et ne modifie aucun des sept règlements historiques. Son format V117 est : tous les clubs des divisions actives, élimination directe en match unique, tirs au but en cas d'égalité, finale sur terrain neutre, calendrier central et statistiques distinctes du championnat.


## Complément d’audit des compétitions V116 — Coupe Galactique

Le code V116 (`newCup`, `CUPR`, `CUPJ`) définit la Coupe Galactique comme un tableau de 8 clubs : le club dirigé et 7 clubs sélectionnés parmi les autres clubs disponibles. Le tableau comporte exactement trois tours : quarts de finale, demi-finales et finale. Les journées de disponibilité sont les journées 6, 12 et 18 du championnat. En cas de match nul, `endCupMatch` utilisait un tirage aléatoire à 50 % pour décider de la qualification. Le socle V117 1.0 conserve le format et le calendrier ; le départage est déterministe pour la reproductibilité des simulations.

**État de portage historique V117 1.0 (mis à jour au socle 1.5) :** la Coupe Galactique, la Coupe Fédéral, la Coupe des Clubs et la Champions League sont maintenant raccordées au moteur commun/calendrier central. Les deux compétitions AGD et la Coupe Lunaire restent à intégrer après audit ; la Dame d’Or reste une distinction individuelle à intégrer, avec son autorité à confirmer.

## Clarification institutionnelle et calendrier FGD / AGD — socle 1.3

L'utilisateur a précisé la répartition des organismes : la **FGD (Fédération Galactique de Dames)** organise les championnats et les coupes des clubs ; l'**AGD (Association Galactique de Dames)** organise la **Coupe Intergalactique des galaxies** et l'**Intergalactique des Clubs**. La Coupe Intergalactique des galaxies ne relève donc pas de la FGD. La Dame d'Or reste une distinction individuelle et son autorité de remise n'est pas présumée.

Le planificateur V117 adopte une semaine interne commençant le lundi : championnat le samedi, créneaux de coupes FGD le mardi, Coupe des Clubs le jeudi lunaire officiel. Les événements sont séparés d'au moins deux jours calendaires (un jour complet libre). La fin de saison régulière est fournie par la FGD ; les deux dates galactiques sont fournies par l'AGD après cette borne. Aucune date officielle n'est générée artificiellement.


## Audit V116 — Champions League Galactique (portage V117 socle 1.5)
Le code de la V116 définit une Champions League Galactique à 32 clubs. `makeGroups()` classe le vivier par points puis niveau, conserve les 32 premiers, répartit les quatre chapeaux de huit en serpentin dans huit groupes de quatre, puis génère six journées (trois aller puis trois retour). Chaque groupe compte 12 matchs ; les huit groupes totalisent donc 96 matchs. Les deux premiers de chacun des huit groupes se qualifient, soit 16 clubs. Le tableau final comporte huit huitièmes, quatre quarts, deux demi-finales et une finale, tous en match unique et sans petite finale : 15 matchs supplémentaires, soit 111 rencontres par édition. Le code V116 trie les groupes par points, différence de buts et buts marqués. Le portage V117 conserve ces critères et utilise l'ordre stable du tirage en dernier recours technique.

Le V116 simulait les rencontres de groupes par une fonction locale, et le tableau final par une probabilité aléatoire fondée sur le niveau. Le V117 raccorde au contraire toutes les rencontres au moteur commun de dames et au registre central, avec simulation reproductible, contrôle des doublons, match du club dirigé jouable et créneaux FGD protégés. Le code V116 ne spécifie pas de petite finale ni de matchs retour en phase finale.


### Point de vigilance institutionnel — Coupe Lunaire
Le code V116 rattache explicitement la Coupe Lunaire à l'AGD (`CGDAGDLunarCup`, libellés « Coupe Lunaire — AGD » et programmation annuelle en fin de saison). L'utilisateur a confirmé que cette répartition reste valable : la Coupe Lunaire demeure une compétition AGD, distincte des deux autres compétitions galactiques AGD. Son moteur et sa fenêtre historique sont intégrés au socle 1.6.


## Coupe Lunaire — précision issue du code V116 complet (socle 1.6)
Le moteur historique confirme 8 représentants galactiques, élimination directe en quarts/demi/finale (4+2+1), édition annuelle. Le scheduler tardif V92 place le match personnel au mois 12 à partir du jour lunaire 6, puis un tour tous les 7 jours ; l'interface AGD V36 décrit également une édition annuelle au mois 12. Le portage V117 retient donc les trois créneaux espacés de sept jours, soit les jours absolus 342, 349 et 356 dans la convention de 12 mois × 30 jours. Des scripts intermédiaires V85/V37 portent des fenêtres contradictoires ; ils ne sont pas repris car le scheduler tardif V92 et le panneau annuel V36 donnent explicitement le calendrier du tournoi.
Les huit représentants constituent une liste spécifique de la Coupe Lunaire et ne remplacent pas le catalogue des 24 galaxies du monde V117.
