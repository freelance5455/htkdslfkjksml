#!/usr/bin/env python3
"""
🤖 Gemini AI Telegram Bot
==========================
Personal AI Assistant for Telegram powered by Google Gemini.
Pre-configured with your Bot Token.
Deploy on Render or your Telegram Bot Hosting Bot!
"""

import os
import logging
from telegram import Update
from telegram.ext import (
    ApplicationBuilder,
    CommandHandler,
    MessageHandler,
    ContextTypes,
    filters
)
import urllib.request
import json

# Your configured Telegram Bot Token
TELEGRAM_BOT_TOKEN = "8915730979:AAFKh4Mrtkqn3IRsHALIHp3hTRQvkH24Vvg"
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "")

logging.basicConfig(format="%(asctime)s - %(name)s - %(levelname)s - %(message)s", level=logging.INFO)
logger = logging.getLogger(__name__)

async def start_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_name = update.effective_user.first_name if update.effective_user else "Friend"
    await update.message.reply_text(
        f"👋 Namaste {user_name}! Main aapka Gemini AI assistant hoon.\n\n"
        f"Mujhse koi bhi sawal puchein, coding problem share karein, ya Hindi/English me baat karein!"
    )

async def chat_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_text = update.message.text
    if not user_text:
        return
    await context.bot.send_chat_action(chat_id=update.effective_chat.id, action="typing")

    # Call Gemini AI
    try:
        url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key={GEMINI_API_KEY}"
        payload = {
            "contents": [{"parts": [{"text": user_text}]}],
            "systemInstruction": {"parts": [{"text": "You are a friendly, intelligent AI assistant fluent in Hindi, Hinglish and English."}]}
        }
        req = urllib.request.Request(
            url,
            data=json.dumps(payload).encode("utf-8"),
            headers={"Content-Type": "application/json"},
            method="POST"
        )
        with urllib.request.urlopen(req, timeout=15) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            ai_reply = data["candidates"][0]["content"]["parts"][0]["text"]
            await update.message.reply_text(ai_reply)
    except Exception as e:
        logger.error(f"AI error: {e}")
        await update.message.reply_text("Namaste! Aapka message mil gaya. Server connecting...")

def main():
    app = ApplicationBuilder().token(TELEGRAM_BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", start_handler))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, chat_handler))
    logger.info("AI Telegram Bot starting...")
    app.run_polling(drop_pending_updates=True)

if __name__ == "__main__":
    main()
