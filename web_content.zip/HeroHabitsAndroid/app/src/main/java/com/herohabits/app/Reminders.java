package com.herohabits.app;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

/** Saves the reminders sent by the web page and shows them as real Android notifications. */
public class Reminders {
    static final String CHANNEL = "habits";
    static final String PREF = "reminders";

    static void ensureChannel(Context c) {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            NotificationChannel ch = new NotificationChannel(CHANNEL, "Habit reminders", NotificationManager.IMPORTANCE_HIGH);
            ch.setDescription("Reminders for your habits");
            ch.enableVibration(true);
            nm.createNotificationChannel(ch);
        }
    }

    static void save(Context c, String json) {
        c.getSharedPreferences(PREF, 0).edit().putString("data", json).apply();
    }

    static String load(Context c) {
        return c.getSharedPreferences(PREF, 0).getString("data", "{}");
    }

    static PendingIntent pending(Context c, int id) {
        Intent i = new Intent(c, ReminderReceiver.class);
        i.setAction("com.herohabits.REMIND");
        i.putExtra("rid", id);
        return PendingIntent.getBroadcast(c, id, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    static void cancelAll(Context c) {
        SharedPreferences sp = c.getSharedPreferences(PREF, 0);
        String ids = sp.getString("ids", "");
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (!ids.isEmpty()) {
            for (String s : ids.split(",")) {
                try {
                    am.cancel(pending(c, Integer.parseInt(s)));
                } catch (Exception e) {
                    // ignore
                }
            }
        }
        sp.edit().remove("ids").apply();
    }

    static void scheduleAll(Context c) {
        cancelAll(c);
        try {
            JSONObject o = new JSONObject(load(c));
            JSONArray a = o.optJSONArray("reminders");
            if (a == null) return;
            AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
            StringBuilder ids = new StringBuilder();
            for (int k = 0; k < a.length(); k++) {
                JSONObject r = a.getJSONObject(k);
                int id = r.getInt("id");
                long t = next(r);
                if (t <= 0) continue;
                set(c, am, id, t);
                if (ids.length() > 0) ids.append(",");
                ids.append(id);
            }
            c.getSharedPreferences(PREF, 0).edit().putString("ids", ids.toString()).apply();
        } catch (Exception e) {
            // ignore
        }
    }

    static void set(Context c, AlarmManager am, int id, long t) {
        PendingIntent p = pending(c, id);
        if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, p);
        } else {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, p);
        }
    }

    /** Next time this reminder should fire (millis), or -1. Days: 0 = Sunday ... 6 = Saturday. */
    static long next(JSONObject r) throws JSONException {
        int h = r.getInt("hour");
        int m = r.getInt("minute");
        JSONArray d = r.optJSONArray("days");
        long now = System.currentTimeMillis();
        for (int add = 0; add < 8; add++) {
            Calendar cal = Calendar.getInstance();
            cal.add(Calendar.DAY_OF_YEAR, add);
            cal.set(Calendar.HOUR_OF_DAY, h);
            cal.set(Calendar.MINUTE, m);
            cal.set(Calendar.SECOND, 0);
            cal.set(Calendar.MILLISECOND, 0);
            int dow = cal.get(Calendar.DAY_OF_WEEK) - 1;
            boolean ok = (d == null);
            if (d != null) {
                for (int i = 0; i < d.length(); i++) {
                    if (d.getInt(i) == dow) ok = true;
                }
            }
            if (ok && cal.getTimeInMillis() > now + 1000) return cal.getTimeInMillis();
        }
        return -1;
    }

    /** Called when an alarm goes off. */
    static void fire(Context c, int id) {
        try {
            JSONObject o = new JSONObject(load(c));
            JSONArray a = o.optJSONArray("reminders");
            if (a == null) return;
            String today = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
            boolean sameDay = today.equals(o.optString("date"));
            JSONArray done = o.optJSONArray("done");
            for (int k = 0; k < a.length(); k++) {
                JSONObject r = a.getJSONObject(k);
                if (r.getInt("id") != id) continue;
                boolean isDone = false;
                if (sameDay && done != null) {
                    String key = r.optString("key");
                    for (int i = 0; i < done.length(); i++) {
                        if (key.equals(done.getString(i))) isDone = true;
                    }
                }
                if (!isDone) show(c, id, r.getString("title"), r.getString("body"));
                long t = next(r);
                if (t > 0) set(c, (AlarmManager) c.getSystemService(Context.ALARM_SERVICE), id, t);
                return;
            }
        } catch (Exception e) {
            // ignore
        }
    }

    static void show(Context c, int id, String title, String body) {
        ensureChannel(c);
        Intent open = new Intent(c, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(c, id, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = new Notification.Builder(c, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_popup_reminder)
                .setContentTitle(title)
                .setContentText(body)
                .setStyle(new Notification.BigTextStyle().bigText(body))
                .setContentIntent(pi)
                .setAutoCancel(true);
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        nm.notify(id, b.build());
    }
}
