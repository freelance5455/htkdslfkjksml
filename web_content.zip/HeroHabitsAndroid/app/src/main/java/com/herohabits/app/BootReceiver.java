package com.herohabits.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Puts the reminders back after the phone restarts or the app is updated. */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        Reminders.scheduleAll(context);
    }
}
