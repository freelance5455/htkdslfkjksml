HERO HABITS - Android project (WebView app with real notifications)
====================================================================
The whole app is app/src/main/assets/index.html (the Hero Habits web app).
The Java code adds: real reminder notifications (work when the app is closed),
choosing photos from the phone, sharing backup files, and normal pop-up dialogs.

BUILD THE APK
1. Install Android Studio (free): https://developer.android.com/studio
2. File > Open... and choose this folder (HeroHabitsAndroid). Wait for the Gradle sync.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Click "locate". The file is app/build/outputs/apk/debug/app-debug.apk
5. Copy it to the phone and tap it (allow "install unknown apps" if asked).
Install the same APK on every phone or tablet you want to use.

FIRST RUN ON THE PHONE
- When you add a reminder, Android asks to allow notifications. Tap Allow.
- In the app: Settings > Notifications > "Make reminders arrive on time" so Android lets
  the app use exact alarms (otherwise reminders can be a few minutes late).
- Some phone brands (Xiaomi, Huawei, Samsung "battery optimisation") may delay or block
  reminders; set the app to "No restrictions" / "Not optimised" in battery settings.

NOTE: This project was written but could not be compiled where it was created.
If Android Studio shows an error, send me the message and I will fix it.
