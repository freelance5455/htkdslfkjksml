#!/usr/bin/env bash
# Genera el instalador de Jarvis para el sistema actual (Linux .deb / macOS .dmg).
# Requisitos: JDK 21 con jpackage. En Linux además: sudo apt install fakeroot
set -e
cd "$(dirname "$0")"
rm -rf build dist release app
mkdir -p build/classes dist release
javac -encoding UTF-8 -cp lib/jna.jar -d build/classes src/jarvis/*.java
printf 'Class-Path: jna.jar\n' > build/manifest.txt
jar --create --file dist/jarvis.jar --main-class jarvis.Jarvis --manifest build/manifest.txt -C build/classes .
cp lib/jna.jar dist/

COMMON=(--name Jarvis --app-version 1.0.0 --vendor Jarvis --description "Jarvis - Centro de mando del sistema"
  --input dist --main-jar jarvis.jar --main-class jarvis.Jarvis
  --add-modules java.desktop,java.management,jdk.management,java.net.http,java.logging,jdk.unsupported
  --java-options "-Dfile.encoding=UTF-8" --java-options "--enable-native-access=ALL-UNNAMED")

if [ "$(uname -s)" = "Darwin" ]; then
  # macOS: añadir el permiso de micrófono al .app antes de crear el .dmg
  jpackage --type app-image "${COMMON[@]}" --icon icons/icon.icns --dest app
  /usr/libexec/PlistBuddy -c "Add :NSMicrophoneUsageDescription string Jarvis usa el micrófono para escuchar tus órdenes" app/Jarvis.app/Contents/Info.plist
  jpackage --type dmg --name Jarvis --app-version 1.0.0 --app-image app/Jarvis.app --dest release
else
  jpackage --type deb "${COMMON[@]}" --icon icons/icon.png --dest release --linux-shortcut --linux-menu-group Utility
fi
echo "Listo. Instalador en: $(pwd)/release"
