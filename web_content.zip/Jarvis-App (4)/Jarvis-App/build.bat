@echo off
REM Genera el instalador de Jarvis para Windows (.exe).
REM Requisitos: JDK 21 con jpackage y WiX Toolset 3.x en el PATH (https://wixtoolset.org)
cd /d "%~dp0"
rmdir /s /q build dist release 2>nul
mkdir build\classes dist release
javac -encoding UTF-8 -cp lib\jna.jar -d build\classes src\jarvis\Jarvis.java src\jarvis\Mic.java || exit /b 1
echo Class-Path: jna.jar> build\manifest.txt
jar --create --file dist\jarvis.jar --main-class jarvis.Jarvis --manifest build\manifest.txt -C build\classes . || exit /b 1
copy lib\jna.jar dist\ >nul
jpackage --type exe --name Jarvis --app-version 1.0.0 --vendor Jarvis ^
  --description "Jarvis - Centro de mando del sistema" ^
  --input dist --main-jar jarvis.jar --main-class jarvis.Jarvis ^
  --add-modules java.desktop,java.management,jdk.management,java.net.http,java.logging,jdk.unsupported ^
  --java-options "-Dfile.encoding=UTF-8" --java-options "--enable-native-access=ALL-UNNAMED" ^
  --icon icons\icon.ico --dest release --win-menu --win-shortcut --win-dir-chooser
echo Listo. Instalador en: %cd%\release
