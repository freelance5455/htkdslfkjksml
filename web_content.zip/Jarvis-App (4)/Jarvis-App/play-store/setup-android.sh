#!/usr/bin/env bash
# Genera el proyecto de Android Studio (carpeta android/) con la app empaquetada DENTRO (no usa una web pública).
# Requisitos: Node.js 20+ y npm. Para compilar después: Android Studio.
set -e
cd "$(dirname "$0")"

read -rp "Nombre de tu app (lo verán los usuarios; NO uses 'Jarvis' ni nombres de marcas): " NAME
[[ "$NAME" =~ ^[A-Za-z0-9\ ]{2,30}$ ]] || { echo "Nombre no válido (solo letras, números y espacios)."; exit 1; }
read -rp "ID del paquete, único y PERMANENTE en Google Play (ej: com.tunombre.asistente): " APPID
[[ "$APPID" =~ ^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+$ ]] || { echo "ID no válido (minúsculas, con puntos)."; exit 1; }
read -rp "Correo de soporte: " MAIL
read -rp "URL pública de tu política de privacidad (https://...): " PRIV

rm -rf www android
mkdir www
cp -r ../web/. www/
rm -f www/privacidad.html

export NAME MAIL PRIV APPID
node -e '
const fs = require("fs"), e = process.env;
let h = fs.readFileSync("www/index.html", "utf8");
h = h.replace("const APP_NAME = \x27Jarvis\x27;", "const APP_NAME = " + JSON.stringify(e.NAME) + ";")
     .replace("const SUPPORT_EMAIL = \x27tu@correo.com\x27;", "const SUPPORT_EMAIL = " + JSON.stringify(e.MAIL) + ";")
     .replace("const PRIVACY_URL = \x27\x27;", "const PRIVACY_URL = " + JSON.stringify(e.PRIV) + ";");
fs.writeFileSync("www/index.html", h);
const m = JSON.parse(fs.readFileSync("www/manifest.webmanifest", "utf8"));
m.name = e.NAME; m.short_name = e.NAME.slice(0, 12);
fs.writeFileSync("www/manifest.webmanifest", JSON.stringify(m, null, 2));
fs.writeFileSync("capacitor.config.json", JSON.stringify({ appId: e.APPID, appName: e.NAME, webDir: "www", android: { allowMixedContent: false } }, null, 2));
'

npm install
npx cap add android
npx cap sync android

echo
echo "Listo. Abre la carpeta 'android' con Android Studio y genera el paquete firmado:"
echo "  Build > Generate Signed App Bundle / APK > Android App Bundle (.aab)"
echo "Lee GUIA-GOOGLE-PLAY.md para el resto (cuenta, ficha, precio, pruebas)."
