# Textos para la ficha de Google Play (borrador)

Cambia [NOMBRE] por el nombre de tu app. No uses «Jarvis», «Iron Man» ni marcas de terceros.

**Título (máx. 30):** [NOMBRE] – Asistente IA con voz
**Descripción breve (máx. 80):** Habla o escribe y usa Claude, ChatGPT, Gemini y más con tu propia clave.
**Categoría:** Productividad · **Etiquetas:** asistente, voz, IA

## Descripción completa
[NOMBRE] es un asistente de IA con voz en un solo lugar. Conecta tu propia clave de Claude, OpenAI, Gemini, Groq u OpenRouter, pulsa el micrófono y habla.

• Dicta tus preguntas y escucha las respuestas en voz alta.
• Cambia de proveedor y de modelo cuando quieras.
• Tus claves se guardan solo en tu teléfono. Sin anuncios y sin rastreadores.
• Botón «Reportar» en cada respuesta.

Necesitas una clave de API de al menos un proveedor (algunos ofrecen plan gratuito). Las respuestas las genera una IA y pueden contener errores. No sustituye consejo médico, legal ni financiero.

## Respuestas para los formularios de Play Console
- **Política de privacidad:** URL pública de `legal/privacidad.html` (ya rellenada).
- **Seguridad de los datos:** recopila *mensajes de usuario* y *audio/voz* (se envían al proveedor de IA elegido; no se comparten con terceros distintos de ese servicio; cifrados en tránsito; no se almacenan en servidor del desarrollador). No hay datos de ubicación, contactos ni identificadores publicitarios. Revisa cada casilla según tu versión final.
- **Anuncios:** no contiene anuncios.
- **Público objetivo:** mayores de 18 años (recomendado, al ser IA generativa).
- **Contenido generado por IA:** sí; indica que hay botón de reporte dentro de la app.
- **Permisos sensibles:** micrófono (solo al pulsar el botón; sirve para dictar).
- **Clasificación de contenido:** cuestionario IARC; al ser chat con IA responde «usuarios pueden interactuar / contenido generado por usuario o IA» según pregunte.
- **Precio:** app de pago (se fija en *Monetizar → Precios*; una app gratuita no puede pasar a pago después).
- **Gráficos:** icono 512×512 (`icono-512.png`), gráfico de funciones 1024×500 (`feature-graphic-1024x500.png`, añade tu nombre) y al menos 2 capturas de teléfono (hazlas con la app instalada).
