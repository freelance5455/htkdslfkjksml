# Publicar la app de pago en Google Play

> Esta guía no es asesoramiento legal ni fiscal. Las condiciones de Google cambian: comprueba siempre las actuales en Play Console.
> No he podido compilar ni probar la app en un Android real (aquí no hay Android SDK): hazlo tú antes de publicar.

## 0. Tres decisiones antes de empezar
1. **Cambia el nombre.** «Jarvis» es un personaje y marca de Marvel/Disney. Vender una app con ese nombre, su estética de película o «la voz original» puede acabar en rechazo, retirada de la ficha o reclamaciones. `setup-android.sh` te pide un nombre propio y lo aplica. (Para uso personal en tu PC no hay problema; esto es solo para vender.)
2. **No publiques la web gratis.** La app de pago lleva los archivos *dentro* del paquete. Si activas el workflow «Publicar app móvil (PWA)», cualquiera la usaría gratis desde el navegador: no lo actives para esta app (o publica solo `legal/privacidad.html`).
3. **Piensa qué compra el usuario.** Ahora mismo la app es un chat con voz donde cada persona pone su propia clave de IA. Es legítimo, pero cobrar por eso invita a reembolsos (Google permite devolver en las primeras 2 horas) y reseñas bajas. Si quieres cobrar por «IA incluida», necesitas tu propio servidor que guarde tu clave y cobre con Google Play Billing; eso no está hecho aquí.
   El precio se decide ahora: **una app gratuita no puede pasar a pago después**.

## 1. Cuentas
- **Google Play Console:** pago único (unos 25 USD) y verificación de identidad.
- **Perfil de pagos / comerciante** para vender: datos bancarios y fiscales. Habla con un gestor sobre IVA y alta como autónomo o empresa.
- **Prueba cerrada obligatoria:** a las cuentas personales nuevas Google les ha exigido probar la app con un grupo de testers durante varias semanas antes de pasar a producción (hasta donde sé: 12 testers, 14 días). Comprueba el requisito actual en Play Console.
- Google se queda entre el 15 % y el 30 % de cada venta.

## 2. Generar el proyecto de Android
Necesitas Node.js 20+ y [Android Studio](https://developer.android.com/studio).
```bash
cd play-store
./setup-android.sh      # te pregunta nombre, ID de paquete, correo y URL de privacidad
```
El **ID de paquete** (por ejemplo `com.tunombre.asistente`) no se puede cambiar nunca en Google Play.
Antes, edita en `web/index.html` si quieres: `REPORT_URL` (formulario que recibe los avisos de contenido; si está vacío se abre el correo de soporte).

## 3. Probar en tu móvil
1. Activa *Opciones de desarrollador → Depuración USB* y conecta el móvil.
2. Abre la carpeta `android/` en Android Studio, espera a que termine «Gradle sync» y pulsa ▶ Run.
3. Comprueba: conectar una IA en Ajustes, escribir, **el micrófono** (usa el reconocimiento nativo de Android), la voz de respuesta y el botón «Reportar».

## 4. Compilar el paquete firmado
*Build → Generate Signed App Bundle / APK → Android App Bundle.* Crea un almacén de claves (keystore) y **guárdalo con su contraseña en un lugar seguro y con copia**: sin él no podrás actualizar la app. Resultado: un archivo `.aab`.
Si Play rechaza el «target SDK», actualiza Capacitor (`npm install @capacitor/android@latest …` y `npx cap sync`).

## 5. Publicar
1. Play Console → *Crear app* → tipo **de pago**, idioma, categoría Productividad.
2. Publica `legal/privacidad.html` (rellena los [corchetes]) en una dirección HTTPS pública y pon esa URL en la ficha.
3. Rellena las declaraciones con `FICHA-PLAY-STORE.md`: seguridad de los datos, anuncios, público objetivo, clasificación de contenido, **contenido generado por IA** y permiso de micrófono.
4. Sube el `.aab` a **pruebas cerradas**, invita a los testers y cumple el plazo.
5. Sube capturas (mín. 2, de teléfono), `icono-512.png` y `feature-graphic-1024x500.png` (añádele tu nombre).
6. Fija el precio en *Monetizar → Precios* y solicita acceso a producción. La revisión suele tardar de 1 a 7 días.

## Qué no incluye la app de Android
- No controla tu PC (eso lo hace el enlace de Telegram de la app de escritorio).
- iOS: para la App Store hace falta un Mac con Xcode y una cuenta de Apple Developer (99 USD/año). Con este mismo proyecto: `npm install @capacitor/ios` y `npx cap add ios`. El reconocimiento de voz nativo en iOS no está comprobado.
