# Jarvis – Centro de mando

Aplicación de escritorio en Java (Swing). Funciona en Linux, Windows y macOS.

## Instalar (usuario final)
Descarga el instalador de tu sistema (ver "Generar instaladores") y ábrelo:
- **Linux:** `sudo apt install ./jarvis_1.0.0-1_amd64.deb` → aparece en el menú de aplicaciones.
- **Windows:** ejecuta `Jarvis-1.0.0.exe`.
- **macOS:** abre `Jarvis-1.0.0.dmg` y arrastra Jarvis a Aplicaciones (la primera vez: clic derecho → Abrir).

Los instaladores llevan Java incluido: no hace falta instalarlo aparte.

## Generar instaladores
`jpackage` solo crea el instalador del sistema donde se ejecuta, así que hay dos opciones:

**A) Automático (recomendado):** sube esta carpeta a un repositorio de GitHub, ve a *Actions → Instaladores de Jarvis → Run workflow*. En unos minutos descargas los tres instaladores (.deb, .exe, .dmg) como artefactos.

**B) A mano en cada sistema** (requiere JDK 21):
- Linux / macOS: `./build.sh` (en Linux antes: `sudo apt install fakeroot`)
- Windows: `build.bat` (necesita WiX Toolset 3.x)

El resultado queda en la carpeta `release/`.

## Probar sin instalar
`java -cp build/classes jarvis.Jarvis` (tras compilar) o ejecuta `Jarvis.java` desde NetBeans.

## Inicio de sesión
La primera vez que abres Jarvis te pide crear una cuenta (usuario y contraseña de 8+ caracteres); después te pide iniciar sesión cada vez. La contraseña no se guarda: solo un hash (PBKDF2) en `~/.jarvis/config.properties`. Tras 5 fallos espera 30 s.
- `salir` (o clic en tu nombre arriba a la derecha) cierra la sesión de Jarvis y vuelve a pedir la contraseña. Mientras está bloqueado no ejecuta nada, ni por voz, ni desde Telegram, ni la IA.
- ¿Olvidaste la contraseña? Cierra Jarvis y borra las líneas `auth.user`, `auth.salt` y `auth.hash` de `~/.jarvis/config.properties`: la próxima vez te pedirá crear una cuenta nueva. Es una protección local de la aplicación, no cifra tu disco.

## Cerrar ventanas
- `cierra calculadora`, `cierra la ventana` (la última que abrió Jarvis) o `cierra todo` (todo lo que abrió Jarvis): las cierra al momento.
- Para algo que no abrió Jarvis (`cierra firefox`) cierra solo sus ventanas si tienes `wmctrl` (`sudo apt install wmctrl`) y, si no puede, te pide confirmación antes de terminar el proceso. Nunca cierra procesos del sistema. En Windows y macOS usa el cierre normal de la aplicación.

## Conectar las IA (Claude, OpenAI, Gemini, Groq, OpenRouter, Ollama)
Pulsa un proveedor en **LLM STATUS** y pega tu API key en el cuadro que aparece (la clave no se escribe en el feed). Para Ollama indica su dirección (por defecto `http://localhost:11434`).
- Con una IA conectada, **cualquier frase** que no sea un comando se la envías a ella, y puede ejecutar acciones en tu PC (por ejemplo «abre la calculadora y dime la hora»). Las acciones peligrosas siguen pidiendo confirmación en pantalla.
- Comandos: `ia` (estado), `ia usar <proveedor>`, `ia modelo <nombre>`, `ia clave <proveedor>`, `ia olvidar <proveedor>`, `ia reiniciar`.
- Las claves se guardan en `~/.jarvis/config.properties` (solo legible por tu usuario en Linux/macOS). También se leen de las variables `ANTHROPIC_API_KEY`, `OPENAI_API_KEY`, `GEMINI_API_KEY`, `GROQ_API_KEY`, `OPENROUTER_API_KEY`.
- Los nombres de modelo por defecto pueden quedarse antiguos: cámbialos con `ia modelo <nombre>`.
- Hay un tope de 10 peticiones por minuto a la IA para evitar bucles y gastos accidentales.

## Android e iOS
El programa de escritorio (Java) no puede ejecutarse en móviles, así que hay dos vías que funcionan en ambos sistemas:

**1) Controlar tu PC desde el móvil (Telegram).** En la app de escritorio escribe `telegram`, crea un bot con @BotFather y pega su token. Escribe «hola» a tu bot desde el móvil y acepta en el PC el emparejamiento. Desde ese momento lo que escribas al bot se ejecuta en tu PC y te responde por Telegram (funciona desde cualquier red, sin abrir puertos).
- Solo obedece al chat emparejado; `telegram desvincular` lo borra y `telegram off` lo apaga.
- Quien controle tu cuenta de Telegram controlaría tu PC: activa la verificación en dos pasos. Ejecutar comandos, borrar, apagar, etc. siguen pidiendo confirmación en la pantalla del PC.

**2) Jarvis como app en el móvil (PWA, carpeta `web/`).** Chat con las IA, voz de entrada y salida, instalable como app. Necesita estar en una dirección HTTPS:
1. Sube esta carpeta a un repositorio de GitHub y activa *Settings → Pages → Source: GitHub Actions*.
2. Ejecuta *Actions → Publicar app móvil (PWA)*. Te dará una dirección tipo `https://tuusuario.github.io/repositorio/`.
3. Ábrela en el móvil: **Android (Chrome)** → menú → *Instalar app*; **iOS (Safari)** → Compartir → *Añadir a pantalla de inicio*.
4. En *Ajustes* pega tu API key (queda solo en ese dispositivo). La PWA no controla el PC; para eso usa Telegram.
Para **vender** la app en Google Play, mira `play-store/GUIA-GOOGLE-PLAY.md` (empaqueta la app dentro del paquete con Capacitor, sin web pública; hay que cambiar el nombre «Jarvis» por uno propio). iOS exige Mac y cuenta de desarrollador de Apple.

## Micrófono (órdenes por voz)
Reconocimiento de voz **sin conexión** (Vosk). Pulsa el micrófono de la barra lateral o escribe `escuchar` (`escuchar off` para parar).
- La **primera vez** descarga el motor de tu sistema (~25 MB) y el modelo en español (~40 MB) a `~/.jarvis`. Después funciona sin Internet.
- Di órdenes como «abre calculadora», «estado», «clima en Barcelona» o «qué es un agujero negro». Puedes empezar con «Jarvis, …».
- Mientras Jarvis habla, el micrófono se ignora para que no se escuche a sí mismo.
- **macOS:** acepta el permiso de micrófono la primera vez. **Windows:** Configuración → Privacidad → Micrófono debe estar permitido.

## Usar desde NetBeans
Copia `src/jarvis/Jarvis.java` y `src/jarvis/Mic.java` al paquete `jarvis` y añade `lib/jna.jar` en *Proyecto → Propiedades → Libraries → Add JAR*. Sin `Mic.java` y JNA todo funciona menos el micrófono.

## Voz
Jarvis habla con la voz del sistema en español (no es la voz de la película): Linux (`espeak-ng` o `spd-say`; `sudo apt install espeak-ng`), Windows (SAPI) y macOS (`say`, voz Jorge). Comandos: `voz on`, `voz off`, `di <texto>`.

## Compatibilidad de comandos
Funcionan en todos los sistemas: abrir apps y webs, captura, ratón y teclado, apagar/reiniciar/suspender/bloquear, procesos, red, disco, memoria, clima, noticias, Wikipedia, descargas y voz.
`apt`, servicios, wifi, bluetooth, firewall, brillo y tema son solo de Linux.
