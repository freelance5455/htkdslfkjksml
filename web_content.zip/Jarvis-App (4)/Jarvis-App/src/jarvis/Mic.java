package jarvis;

import com.sun.jna.Library;
import com.sun.jna.Native;
import com.sun.jna.Pointer;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.TargetDataLine;
import java.io.*;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.*;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * Reconocimiento de voz sin conexión (Vosk) con el micrófono del sistema.
 * La primera vez descarga la librería nativa de tu sistema y el modelo en español (~40 MB) en ~/.jarvis.
 * Se usa por reflexión desde Jarvis para que Jarvis.java compile aunque falte JNA.
 */
public class Mic {
    public interface Vosk extends Library {
        Pointer vosk_model_new(String path);
        void vosk_model_free(Pointer model);
        Pointer vosk_recognizer_new(Pointer model, float sampleRate);
        void vosk_recognizer_free(Pointer rec);
        int vosk_recognizer_accept_waveform(Pointer rec, byte[] data, int length);
        String vosk_recognizer_result(Pointer rec);
        void vosk_recognizer_reset(Pointer rec);
        void vosk_set_log_level(int level);
    }

    static final String OS = System.getProperty("os.name").toLowerCase();
    static final String ARCH = System.getProperty("os.arch").toLowerCase();
    static final boolean WIN = OS.contains("win"), MAC = OS.contains("mac");
    static final File HOME = new File(System.getProperty("user.home"), ".jarvis");
    static final File NATIVE = new File(HOME, "native"), MODEL = new File(HOME, "model-es");
    static final String MODEL_URL = "https://alphacephei.com/vosk/models/vosk-model-small-es-0.42.zip";
    static final String REL = "https://github.com/alphacep/vosk-api/releases/download/";
    static volatile boolean run;

    public static boolean running() { return run; }
    public static void stop() { run = false; }

    static String nativeUrl() {
        if (WIN) return REL + "v0.3.45/vosk-win64-0.3.45.zip";
        if (MAC) return REL + "v0.3.42/vosk-osx-0.3.42.zip";
        return REL + "v0.3.45/vosk-linux-" + (ARCH.contains("aarch64") || ARCH.contains("arm64") ? "aarch64" : "x86_64") + "-0.3.45.zip";
    }

    static String libName() { return WIN ? "libvosk.dll" : MAC ? "libvosk.dylib" : "libvosk.so"; }

    /** Inicia la escucha en un hilo. say: mensajes al feed; onText: frase reconocida; onLevel: volumen 0..1; muted: ignorar audio. */
    public static synchronized void start(Consumer<String> say, Consumer<String> onText, Consumer<Double> onLevel, BooleanSupplier muted) {
        if (run) return;
        run = true;
        Thread t = new Thread(() -> loop(say, onText, onLevel, muted), "jarvis-mic");
        t.setDaemon(true);
        t.start();
    }

    static void loop(Consumer<String> say, Consumer<String> onText, Consumer<Double> onLevel, BooleanSupplier muted) {
        TargetDataLine line = null;
        Pointer model = null, rec = null;
        Vosk vosk = null;
        try {
            prepare(say);
            if (!run) return;
            if (WIN) for (String n : new String[]{"libwinpthread-1.dll", "libgcc_s_seh-1.dll", "libstdc++-6.dll"}) {
                File f = new File(NATIVE, n);
                if (f.exists()) System.load(f.getAbsolutePath());
            }
            vosk = Native.load(new File(NATIVE, libName()).getAbsolutePath(), Vosk.class);
            vosk.vosk_set_log_level(-1);
            say.accept("Cargando el modelo de voz…");
            model = vosk.vosk_model_new(MODEL.getAbsolutePath());
            if (model == null) throw new IOException("no se pudo cargar el modelo en " + MODEL + " (bórralo para volver a descargarlo)");
            rec = vosk.vosk_recognizer_new(model, 16000f);
            AudioFormat fmt = new AudioFormat(16000f, 16, 1, true, false);
            line = AudioSystem.getTargetDataLine(fmt);
            line.open(fmt);
            line.start();
            say.accept("Te escucho. Di por ejemplo: «abre calculadora» o «qué es un agujero negro».");
            byte[] buf = new byte[4000];
            while (run) {
                int n = line.read(buf, 0, buf.length);
                if (n <= 0) continue;
                long sum = 0;
                for (int i = 0; i + 1 < n; i += 2) { int v = (short) ((buf[i + 1] << 8) | (buf[i] & 0xff)); sum += (long) v * v; }
                onLevel.accept(Math.sqrt(sum / Math.max(1.0, n / 2.0)) / 32768.0);
                if (muted.getAsBoolean()) { vosk.vosk_recognizer_reset(rec); continue; }
                if (vosk.vosk_recognizer_accept_waveform(rec, buf, n) != 0) {
                    Matcher m = Pattern.compile("\"text\"\\s*:\\s*\"([^\"]*)\"").matcher(String.valueOf(vosk.vosk_recognizer_result(rec)));
                    if (m.find() && !m.group(1).isBlank()) onText.accept(m.group(1).trim());
                }
            }
        } catch (Throwable e) {
            say.accept("Error del micrófono: " + (e instanceof java.net.ConnectException || e instanceof java.nio.channels.UnresolvedAddressException
                    ? "no hay conexión con el servidor de descarga. Comprueba tu Internet e inténtalo de nuevo."
                    : e.getMessage() == null ? e.toString() : e.getMessage()));
        } finally {
            run = false;
            onLevel.accept(0.0);
            if (line != null) { line.stop(); line.close(); }
            if (vosk != null) {
                if (rec != null) vosk.vosk_recognizer_free(rec);
                if (model != null) vosk.vosk_model_free(model);
            }
        }
    }

    /** Descarga la librería nativa y el modelo si faltan. */
    static void prepare(Consumer<String> say) throws Exception {
        if (!new File(NATIVE, libName()).exists()) {
            say.accept("Primera vez: descargando el motor de voz…");
            File zip = download(nativeUrl(), "motor", say);
            NATIVE.mkdirs();
            try (ZipInputStream in = new ZipInputStream(new FileInputStream(zip))) {
                ZipEntry e;
                while ((e = in.getNextEntry()) != null) {
                    String n = new File(e.getName()).getName();
                    if (e.isDirectory() || !(n.endsWith(".so") || n.endsWith(".dll") || n.endsWith(".dylib"))) continue;
                    Files.copy(in, new File(NATIVE, n).toPath(), StandardCopyOption.REPLACE_EXISTING);
                }
            }
            zip.delete();
        }
        if (!new File(MODEL, "am").exists()) {
            say.accept("Descargando el modelo de voz en español (~40 MB)…");
            File zip = download(MODEL_URL, "modelo", say);
            Path root = MODEL.toPath().toAbsolutePath().normalize();
            try (ZipInputStream in = new ZipInputStream(new FileInputStream(zip))) {
                ZipEntry e;
                while ((e = in.getNextEntry()) != null) {
                    String name = e.getName();
                    int k = name.indexOf('/');
                    if (k < 0) continue;                       // quita la carpeta raíz del zip
                    Path dest = root.resolve(name.substring(k + 1)).normalize();
                    if (!dest.startsWith(root)) continue;      // evita rutas fuera de la carpeta
                    if (e.isDirectory()) Files.createDirectories(dest);
                    else { Files.createDirectories(dest.getParent()); Files.copy(in, dest, StandardCopyOption.REPLACE_EXISTING); }
                }
            }
            zip.delete();
        }
    }

    static File download(String url, String what, Consumer<String> say) throws Exception {
        HttpClient http = HttpClient.newBuilder().followRedirects(HttpClient.Redirect.NORMAL).build();
        HttpResponse<InputStream> r = http.send(HttpRequest.newBuilder(URI.create(url)).header("User-Agent", "JarvisAssistant/3.0").build(),
                HttpResponse.BodyHandlers.ofInputStream());
        if (r.statusCode() != 200) throw new IOException("descarga de " + what + " falló (HTTP " + r.statusCode() + ")");
        long total = r.headers().firstValueAsLong("content-length").orElse(-1);
        HOME.mkdirs();
        File out = File.createTempFile("jarvis-" + what, ".zip", HOME);
        try (InputStream in = r.body(); OutputStream o = new FileOutputStream(out)) {
            byte[] b = new byte[65536]; long got = 0; int lastPct = 0, n;
            while ((n = in.read(b)) > 0 && run) {
                o.write(b, 0, n); got += n;
                if (total > 0 && (int) (got * 100 / total) >= lastPct + 25) { lastPct = (int) (got * 100 / total); say.accept("Descargando " + what + ": " + lastPct + "%"); }
            }
        }
        return out;
    }
}
