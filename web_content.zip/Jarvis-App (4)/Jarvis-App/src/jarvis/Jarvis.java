package jarvis;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.datatransfer.StringSelection;
import java.awt.event.*;
import java.awt.geom.*;
import java.io.*;
import java.lang.management.ManagementFactory;
import java.nio.file.*;
import java.text.SimpleDateFormat;
import java.util.Date;

/** JARVIS - Centro de mando para tu PC. Requiere JDK 17+. */
public class Jarvis extends JFrame {
    static final Color BG = new Color(3, 11, 22), TXT = new Color(214, 238, 250), DIM = new Color(110, 150, 175),
            CYAN = new Color(0, 200, 255), VIOLET = new Color(124, 92, 255), RED = new Color(255, 95, 109),
            GREEN = new Color(52, 225, 150);
    static final String SANS = java.util.Arrays.asList(GraphicsEnvironment.getLocalGraphicsEnvironment()
            .getAvailableFontFamilyNames()).contains("Ubuntu") ? "Ubuntu" : "SansSerif";
    static final java.util.Map<String, String> ALIAS = java.util.Map.ofEntries(
            java.util.Map.entry("archivo", "files"), java.util.Map.entry("archivos", "files"),
            java.util.Map.entry("explorador", "files"), java.util.Map.entry("explorador de archivos", "files"),
            java.util.Map.entry("calculadora", "calculator"), java.util.Map.entry("configuracion", "settings"),
            java.util.Map.entry("ajustes", "settings"), java.util.Map.entry("editor", "text editor"),
            java.util.Map.entry("editor de texto", "text editor"), java.util.Map.entry("bloc de notas", "text editor"),
            java.util.Map.entry("consola", "terminal"), java.util.Map.entry("navegador", "firefox"),
            java.util.Map.entry("calendario", "calendar"), java.util.Map.entry("reloj", "clocks"),
            java.util.Map.entry("musica", "rhythmbox"), java.util.Map.entry("capturas", "screenshot"),
            java.util.Map.entry("monitor del sistema", "system monitor"), java.util.Map.entry("tienda", "software"));
    static String norm(String s) {
        return java.text.Normalizer.normalize(s, java.text.Normalizer.Form.NFD).replaceAll("\\p{M}", "").toLowerCase().trim();
    }
    static final Font TITLE_FONT = new Font(SANS, Font.BOLD, 11)
            .deriveFont(java.util.Map.of(java.awt.font.TextAttribute.TRACKING, 0.15));
    static final String LLM_MSG = "Aún no hay ninguna IA conectada. Puedo integrar Claude, OpenAI u Ollama cuando quieras.";
    static final String OS = System.getProperty("os.name").toLowerCase();
    static final boolean WIN = OS.contains("win"), MAC = OS.contains("mac");

    ChatPanel chat = new ChatPanel();
    JScrollPane chatScroll;
    JLabel dateL = new JLabel("", SwingConstants.CENTER), timeL = new JLabel("", SwingConstants.CENTER), status = new JLabel();
    HintField input = new HintField("TALK TO JARVIS  ·  escribe un comando (abre firefox, estado, ayuda)");
    Ring cpu = new Ring("CPU"), ram = new Ring("RAM"), disk = new Ring("DISK");
    Orb orb = new Orb();
    VoiceCard voice = new VoiceCard();
    Timeline timeline = new Timeline();
    MemPanel mem = new MemPanel();
    Item iMem, iAgents, iSys, iNet, iFocus, iVoice;
    boolean voiceOn = true, listening;
    final java.util.Properties cfg = new java.util.Properties();
    final java.util.List<String[]> hist = new java.util.ArrayList<>();
    final Item[] llmItems = new Item[6];
    Hud llmHud;
    Item iLlm, iTg;
    volatile boolean locked = true;
    JLabel opName;
    final java.util.List<String[]> opened = new java.util.ArrayList<>();   // {app, exe, pid}
    volatile boolean ollamaUp, tgRun, llmExec, hinted;
    volatile String tgChatNow;
    volatile long tgUntil;
    final java.util.Set<String> tgDenied = new java.util.HashSet<>();
    final java.util.concurrent.ExecutorService tgOut = java.util.concurrent.Executors.newSingleThreadExecutor(r -> { Thread t = new Thread(r, "jarvis-tg-out"); t.setDaemon(true); return t; });
    final java.util.concurrent.ExecutorService tts = java.util.concurrent.Executors.newSingleThreadExecutor(r -> { Thread t = new Thread(r, "jarvis-tts"); t.setDaemon(true); return t; });
    final java.util.concurrent.atomic.AtomicInteger pendingTts = new java.util.concurrent.atomic.AtomicInteger();
    Process speech;
    int tickN;
    boolean focus;
    Robot robot;

    public Jarvis() {
        super("JARVIS - Command Center");
        try { robot = new Robot(); } catch (Exception e) { /* sin control de ratón */ }
        loadCfg();
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setIconImage(icon());
        setSize(1440, 880);
        setMinimumSize(new Dimension(1100, 700));
        setLocationRelativeTo(null);
        JPanel root = new JPanel(new BorderLayout(10, 10));
        root.setBackground(BG);
        root.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        setContentPane(root);

        // ---- Barra lateral
        Hud side = new Hud(null, new BorderLayout(0, 10));
        side.setPreferredSize(new Dimension(210, 0));
        JPanel brand = new JPanel(new GridLayout(2, 1)); brand.setOpaque(false);
        brand.setBorder(BorderFactory.createEmptyBorder(8, 8, 12, 0));
        JLabel b1 = new JLabel("J A R V I S"); b1.setForeground(CYAN); b1.setFont(new Font(SANS, Font.BOLD, 22));
        JLabel b2 = new JLabel("C O M M A N D   C E N T E R"); b2.setForeground(DIM); b2.setFont(new Font(SANS, Font.BOLD, 8));
        brand.add(b1); brand.add(b2);
        side.add(brand, BorderLayout.NORTH);
        JPanel nav = new JPanel(new GridLayout(0, 1, 0, 2)); nav.setOpaque(false);
        String[][] items = {{"Command Center", "estado"}, {"AI Core", "sistema"}, {"Agents", "servicios"}, {"Tasks", "procesos"},
                {"Calendar", "hora"}, {"Memory", "memoria"}, {"Network", "red"}, {"Files", "disco"},
                {"Tools & Skills", "ayuda"}, {"Workflows", "briefing"}};
        java.util.List<Chip> chips = new java.util.ArrayList<>();
        for (String[] it : items) {
            Chip ch = new Chip(it[0]); chips.add(ch);
            ch.addActionListener(e -> {
                chips.forEach(x -> x.sel = false); ch.sel = true; chips.forEach(x -> x.repaint());
                if (it[1].equals("briefing")) briefing(); else handle(it[1]);
            });
            nav.add(ch);
        }
        chips.get(0).sel = true;
        JPanel navWrap = new JPanel(new BorderLayout()); navWrap.setOpaque(false); navWrap.add(nav, BorderLayout.NORTH);
        side.add(navWrap, BorderLayout.CENTER);
        Hud vh = new Hud("VOICE STATUS", new BorderLayout()); vh.add(voice, BorderLayout.CENTER);
        vh.setPreferredSize(new Dimension(0, 175));
        voice.act = () -> handle(listening ? "escuchar off" : "escuchar on");
        iFocus = new Item("Focus Mode", "OFF", DIM, this::toggleFocus);
        iFocus.setPreferredSize(new Dimension(0, 40));
        JPanel low = new JPanel(new BorderLayout(0, 8)); low.setOpaque(false);
        low.add(vh, BorderLayout.CENTER); low.add(iFocus, BorderLayout.SOUTH);
        side.add(low, BorderLayout.SOUTH);
        root.add(side, BorderLayout.WEST);

        // ---- Cabecera
        JPanel content = new JPanel(new BorderLayout(0, 10)); content.setOpaque(false);
        JPanel header = new JPanel(new BorderLayout(10, 0)); header.setOpaque(false);
        header.setPreferredSize(new Dimension(0, 56));
        Hud sp = new Hud(null, new BorderLayout()); sp.setBorder(BorderFactory.createEmptyBorder(4, 16, 4, 16));
        status.setFont(new Font(SANS, Font.BOLD, 11)); sp.add(status); sp.setPreferredSize(new Dimension(240, 0));
        dateL.setForeground(TXT); dateL.setFont(new Font(SANS, Font.PLAIN, 12));
        timeL.setForeground(CYAN); timeL.setFont(new Font(SANS, Font.BOLD, 22));
        JPanel clockP = new JPanel(new GridLayout(2, 1)); clockP.setOpaque(false); clockP.add(dateL); clockP.add(timeL);
        HintField search = new HintField("Search…  (buscar archivos)");
        search.setFont(new Font(SANS, Font.PLAIN, 13));
        search.addActionListener(e -> { String t = search.getText().trim(); search.setText(""); if (!t.isEmpty()) handle("encuentra " + t); });
        Hud sh = new Hud(null, new BorderLayout()); sh.setBorder(BorderFactory.createEmptyBorder(4, 12, 4, 12));
        sh.add(search); sh.setPreferredSize(new Dimension(250, 0));
        JLabel op1 = new JLabel(System.getProperty("user.name")); opName = op1; op1.setForeground(TXT); op1.setFont(new Font(SANS, Font.BOLD, 12));
        JLabel op2 = new JLabel("Cerrar sesión ›"); op2.setForeground(DIM); op2.setFont(new Font(SANS, Font.PLAIN, 10));
        JPanel opT = new JPanel(new GridLayout(2, 1)); opT.setOpaque(false); opT.add(op1); opT.add(op2);
        Hud oh = new Hud(null, new BorderLayout()); oh.setBorder(BorderFactory.createEmptyBorder(4, 14, 4, 14));
        oh.add(opT); oh.setPreferredSize(new Dimension(150, 0));
        oh.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        oh.addMouseListener(new MouseAdapter() { @Override public void mouseClicked(MouseEvent e) { handle("salir"); } });
        JPanel hr = new JPanel(new BorderLayout(10, 0)); hr.setOpaque(false); hr.add(sh, BorderLayout.CENTER); hr.add(oh, BorderLayout.EAST);
        header.add(sp, BorderLayout.WEST); header.add(clockP, BorderLayout.CENTER); header.add(hr, BorderLayout.EAST);
        content.add(header, BorderLayout.NORTH);

        // ---- Rejilla principal
        iMem = new Item("Memory", "—", CYAN, () -> handle("memoria"));
        iAgents = new Item("Processes", "—", CYAN, () -> handle("procesos"));
        iSys = new Item("System", "Optimal", GREEN, () -> handle("estado"));
        iNet = new Item("Network", "…", DIM, () -> handle("red"));
        Hud overview = new Hud("AI CORE OVERVIEW", new GridLayout(6, 1, 0, 5));
        overview.add(new Item("AI Core", "Active", GREEN, () -> handle("sistema")));
        overview.add(iMem);
        iVoice = new Item("Voice", "Out on · Mic off", GREEN, () -> handle(voiceOn ? "voz off" : "voz on"));
        overview.add(iVoice);
        overview.add(iAgents);
        iLlm = new Item("LLMs", "0 linked", DIM, () -> handle("ia"));
        overview.add(iLlm);
        overview.add(iSys);

        Hud orbH = new Hud(null, new BorderLayout()); orbH.add(orb, BorderLayout.CENTER);

        Hud feed = new Hud("LIVE INTELLIGENCE FEED", new BorderLayout());
        feed.tag = "• LIVE"; feed.tagColor = GREEN;
        feed.setBorder(BorderFactory.createEmptyBorder(30, 6, 8, 2));
        chatScroll = new JScrollPane(chat);
        chatScroll.setBorder(null); chatScroll.setOpaque(false); chatScroll.getViewport().setOpaque(false);
        chatScroll.getVerticalScrollBar().setUI(new SlimBar());
        chatScroll.getVerticalScrollBar().setPreferredSize(new Dimension(7, 0));
        chatScroll.getVerticalScrollBar().setUnitIncrement(16);
        feed.add(chatScroll, BorderLayout.CENTER);

        Hud agents = new Hud("ACTIVE AGENTS", new GridLayout(2, 3, 6, 6));
        String[][] mods = {{"Apps", "procesos"}, {"Network", "red"}, {"Files", "disco"}, {"Services", "servicios"},
                {"Power", "bateria"}, {"Firewall", "firewall"}};
        for (String[] m : mods) agents.add(new Item(m[0], "Ready", GREEN, () -> handle(m[1])));

        Hud mission = new Hud("MISSION TIMELINE", new BorderLayout()); mission.add(timeline, BorderLayout.CENTER);
        timeline.push("sesión iniciada");

        Hud quick = new Hud("QUICK COMMANDS", new GridLayout(4, 1, 0, 5));
        quick.add(new Item("Open Browser", null, DIM, () -> handle("abrir https://google.com")));
        quick.add(new Item("Open Terminal", null, DIM, () -> handle("terminal")));
        quick.add(new Item("Take Screenshot", null, DIM, () -> handle("captura")));
        quick.add(new Item("Lock Screen", null, DIM, () -> handle("bloquear")));

        Hud sysmon = new Hud("SYSTEM MONITOR", new GridLayout(1, 3, 4, 0));
        sysmon.add(cpu); sysmon.add(ram); sysmon.add(disk);
        Hud memH = new Hud("MEMORY INSIGHTS", new BorderLayout()); memH.add(mem, BorderLayout.CENTER);
        Hud llm = new Hud("LLM STATUS", new GridLayout(2, 3, 6, 6));
        llm.tag = "0 Connected"; llm.tagColor = DIM;
        llmHud = llm;
        for (int i = 0; i < 6; i++) {
            final String pv = PROVIDERS[i];
            llmItems[i] = new Item(PNAMES[i], "Not linked", DIM, () -> configIA(pv));
            llm.add(llmItems[i]);
        }

        JPanel grid = new JPanel(new GridBagLayout()); grid.setOpaque(false);
        for (int i = 0; i < 20; i++) {
            JPanel f = new JPanel(); f.setOpaque(false); f.setPreferredSize(new Dimension(1, 0));
            GridBagConstraints k = new GridBagConstraints(); k.gridx = i; k.gridy = 0; k.weightx = 1; grid.add(f, k);
        }
        cell(grid, overview, 0, 1, 4, 6);  cell(grid, orbH, 4, 1, 10, 6);  cell(grid, feed, 14, 1, 6, 6);
        cell(grid, agents, 0, 2, 10, 2.3); cell(grid, mission, 10, 2, 5, 2.3); cell(grid, quick, 15, 2, 5, 2.3);
        cell(grid, sysmon, 0, 3, 5, 2.3);  cell(grid, memH, 5, 3, 5, 2.3);  cell(grid, llm, 10, 3, 10, 2.3);
        content.add(grid, BorderLayout.CENTER);

        // ---- Barra inferior
        JPanel bottom = new JPanel(new BorderLayout(10, 0)); bottom.setOpaque(false);
        bottom.setPreferredSize(new Dimension(0, 60));
        JPanel chipsP = new JPanel(new GridLayout(1, 3, 6, 0)); chipsP.setOpaque(false);
        chipsP.add(new Item("Host", host(), TXT, null));
        iTg = new Item("Mobile", "Telegram off", DIM, () -> handle("telegram"));
        chipsP.add(iTg);
        chipsP.add(iNet);
        chipsP.setPreferredSize(new Dimension(450, 0));
        Hud pill = new Hud(null, new BorderLayout(10, 0)); pill.glow = true;
        pill.setBorder(BorderFactory.createEmptyBorder(6, 22, 6, 8));
        input.setFont(new Font(SANS, Font.PLAIN, 15));
        SendBtn send = new SendBtn();
        Runnable submit = () -> { String c = input.getText(); input.setText(""); handle(c); };
        input.addActionListener(e -> submit.run());
        send.addActionListener(e -> submit.run());
        pill.add(input, BorderLayout.CENTER); pill.add(send, BorderLayout.EAST);
        Item brief = new Item("Executive Briefing", null, DIM, this::briefing);
        brief.setPreferredSize(new Dimension(190, 0));
        bottom.add(chipsP, BorderLayout.WEST); bottom.add(pill, BorderLayout.CENTER); bottom.add(brief, BorderLayout.EAST);
        content.add(bottom, BorderLayout.SOUTH);
        root.add(content, BorderLayout.CENTER);

        refreshLlm();
        probeOllama();
        if ("true".equals(cfg.getProperty("tg.auto"))) startTelegram();
        new Timer(1000, e -> tick()).start();
        new Timer(66, e -> { if (!isActive()) return; orb.step(); voice.step(); cpu.anim(); ram.anim(); disk.anim(); }).start();
        tick();
    }

    void cell(JPanel g, JComponent c, int x, int y, int w, double wy) {
        c.setPreferredSize(new Dimension(10, 10)); c.setMinimumSize(new Dimension(0, 0));
        GridBagConstraints k = new GridBagConstraints();
        k.gridx = x; k.gridy = y; k.gridwidth = w; k.weightx = w; k.weighty = wy;
        k.fill = GridBagConstraints.BOTH; k.insets = new Insets(5, 5, 5, 5);
        g.add(c, k);
    }

    static String host() {
        try { return java.net.InetAddress.getLocalHost().getHostName(); } catch (Exception e) { return "localhost"; }
    }

    void tick() {
        Date now = new Date();
        dateL.setText(new SimpleDateFormat("EEEE, d MMMM yyyy").format(now));
        timeL.setText(new SimpleDateFormat("HH:mm:ss").format(now));
        var os = (com.sun.management.OperatingSystemMXBean) ManagementFactory.getOperatingSystemMXBean();
        double c = os.getCpuLoad();
        cpu.set(c < 0 ? 0 : c);
        double rf = ramUsage(os);
        ram.set(rf);
        File r = File.listRoots()[0];
        disk.set(1.0 - (double) r.getUsableSpace() / Math.max(1, r.getTotalSpace()));
        double tot = os.getTotalMemorySize() / 1073741824.0;
        iMem.set(String.format("%.1f / %.1f GB", rf * tot, tot), CYAN);
        mem.a = String.format("%.1f GB", rf * tot);
        mem.c = (ManagementFactory.getRuntimeMXBean().getUptime() / 60000) + " min";
        boolean hi = c > 0.9 || rf > 0.92;
        iSys.set(hi ? "High load" : "Optimal", hi ? RED : GREEN);
        status.setText("SYSTEM STATUS   • " + (hi ? "HIGH LOAD" : "OPTIMAL"));
        status.setForeground(hi ? RED : GREEN);
        if (tickN % 5 == 0) new Thread(() -> {
            long n = ProcessHandle.allProcesses().count();
            SwingUtilities.invokeLater(() -> { iAgents.set(n + " running", CYAN); mem.b = String.valueOf(n); });
        }).start();
        if (tickN % 15 == 0) new Thread(() -> {
            boolean ok;
            try (java.net.Socket sk = new java.net.Socket()) {
                sk.connect(new java.net.InetSocketAddress("1.1.1.1", 53), 800); ok = true;
            } catch (Exception ex) { ok = false; }
            boolean up = ok;
            SwingUtilities.invokeLater(() -> iNet.set(up ? "Online" : "Offline", up ? GREEN : RED));
        }).start();
        if (listening) try {
            if (!(Boolean) Class.forName("jarvis.Mic").getMethod("running").invoke(null)) { listening = false; voice.on = false; voiceStatus(); }
        } catch (Throwable ex) { listening = false; voice.on = false; voiceStatus(); }
        tickN++;
        mem.repaint();
    }

    void toggleFocus() {
        if (WIN || MAC) { out("El modo concentración solo está disponible en Linux (GNOME)."); return; }
        focus = !focus;
        exec("gsettings set org.gnome.desktop.notifications show-banners " + !focus);
        iFocus.set(focus ? "ON" : "OFF", focus ? GREEN : DIM);
        out(focus ? "Modo concentración activado." : "Modo concentración desactivado.");
    }

    void briefing() { handle("sistema"); handle("estado"); handle("disco"); }

    double ramUsage(com.sun.management.OperatingSystemMXBean os) {
        try {
            long tot = 0, av = 0;
            for (String s : Files.readAllLines(Paths.get("/proc/meminfo"))) {
                if (s.startsWith("MemTotal:")) tot = Long.parseLong(s.replaceAll("\\D+", ""));
                if (s.startsWith("MemAvailable:")) av = Long.parseLong(s.replaceAll("\\D+", ""));
            }
            if (tot > 0) return 1.0 - (double) av / tot;
        } catch (Exception e) { /* no es Linux */ }
        return 1.0 - (double) os.getFreeMemorySize() / os.getTotalMemorySize();
    }

    void out(String s) {
        String tc = tgChatNow;
        if (tc != null && !s.startsWith("▸ ") && System.currentTimeMillis() < tgUntil) {
            tgUntil = Math.max(tgUntil, System.currentTimeMillis() + 8000);
            tgSend(tc, s);
        }
        if (!locked && !s.startsWith("▸ ") && s.length() <= 220 && s.indexOf('\n') < 0)
            speak(s.startsWith("Abriendo ") && s.contains("   (") ? s.substring(0, s.indexOf("   (")) : s);
        SwingUtilities.invokeLater(() -> {
            int kind = s.startsWith("▸ ") ? 0 : (s.startsWith("Error") || s.startsWith("No encontré")
                    || s.startsWith("No entiendo") || s.startsWith("Acción no") || s.startsWith("Uso:")) ? 2 : 1;
            Bubble b = new Bubble(kind == 0 ? s.substring(2) : s, kind, Math.max(200, chat.getWidth() - 20));
            JPanel row = new JPanel(new BorderLayout()); row.setOpaque(false);
            row.setBorder(BorderFactory.createEmptyBorder(3, 2, 3, 2));
            row.add(b, BorderLayout.CENTER);
            row.setMaximumSize(new Dimension(Integer.MAX_VALUE, row.getPreferredSize().height));
            chat.add(row);
            if (chat.getComponentCount() > 300) chat.remove(0);
            chat.revalidate();
            SwingUtilities.invokeLater(() -> {
                JScrollBar sb = chatScroll.getVerticalScrollBar();
                sb.setValue(sb.getMaximum());
            });
        });
    }

    boolean confirm(String msg) {
        return JOptionPane.showConfirmDialog(this, msg, "Jarvis - confirmar", JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE) == JOptionPane.YES_OPTION;
    }

    String[] shell(String cmd) {
        return WIN ? new String[]{"cmd", "/c", cmd} : new String[]{"bash", "-c", cmd};
    }

    /** Ejecuta un comando y muestra la salida en el feed. */
    void exec(String cmd) {
        new Thread(() -> {
            try {
                Process p = new ProcessBuilder(shell(cmd)).redirectErrorStream(true).start();
                try (BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()))) {
                    String l; int n = 0;
                    while ((l = br.readLine()) != null && n++ < 60) out(l);
                }
            } catch (Exception e) { out("Error: " + e.getMessage()); }
        }).start();
    }

    /** Busca un .desktop (Linux) por nombre de app, en cualquier idioma. */
    String findDesktop(String q) {
        q = norm(q);
        String h = System.getProperty("user.home");
        String[] dirs = {"/usr/share/applications", h + "/.local/share/applications",
                "/var/lib/snapd/desktop/applications", "/var/lib/flatpak/exports/share/applications",
                h + "/.local/share/flatpak/exports/share/applications"};
        String best = null;
        for (String d : dirs) {
            File[] fs = new File(d).listFiles((x, n) -> n.endsWith(".desktop"));
            if (fs == null) continue;
            for (File f : fs) {
                try {
                    boolean match = f.getName().toLowerCase().contains(q), hidden = false;
                    for (String ln : Files.readAllLines(f.toPath())) {
                        String t = norm(ln);
                        if (t.startsWith("nodisplay=true")) hidden = true;
                        if (t.startsWith("name=") || t.startsWith("name[es]=")) {
                            String n = t.substring(t.indexOf('=') + 1).trim();
                            if (n.equals(q)) { match = true; if (!hidden) return f.getAbsolutePath(); }
                            else if (n.contains(q)) match = true;
                        }
                    }
                    if (match && !hidden && best == null) best = f.getAbsolutePath();
                } catch (Exception e) { /* ignorar */ }
            }
        }
        return best;
    }

    static String execOf(String desktopFile) {
        try {
            for (String ln : Files.readAllLines(Paths.get(desktopFile)))
                if (ln.startsWith("Exec=")) return ln.substring(5).replaceAll("%[fFuUdDnNickvm]", "").trim();
        } catch (Exception e) { /* ignorar */ }
        return null;
    }

    /** Lanza una aplicación y avisa en el feed si falla. */
    void launch(String app) {
        final boolean fromLlm = llmExec;
        new Thread(() -> {
            try {
                String run = null;
                if (WIN) run = "start \"\" " + app;
                else if (MAC) run = "open -a \"" + app + "\"";
                else {
                    String f = findDesktop(ALIAS.getOrDefault(norm(app), app));
                    if (f != null) run = execOf(f);
                    if (run == null && new ProcessBuilder("bash", "-c", "command -v " + q(app.split("\\s+")[0])).start().waitFor() == 0) run = app;
                }
                if (run == null) {
                    if (active() != null && !fromLlm) llm("abre " + app); else out("No encontré ninguna app llamada '" + app + "'.");
                    return;
                }
                out("Abriendo " + app + "   (" + run + ")");
                File log = File.createTempFile("jarvis", ".log");
                Process p = new ProcessBuilder(shell(WIN ? run : "exec " + run)).redirectErrorStream(true).redirectOutput(log).start();
                synchronized (opened) { opened.add(new String[]{app, exeOf(run), String.valueOf(p.pid())}); if (opened.size() > 30) opened.remove(0); }
                if (p.waitFor(2, java.util.concurrent.TimeUnit.SECONDS) && p.exitValue() != 0) {
                    String msg = new String(Files.readAllBytes(log.toPath())).trim();
                    out("Error al abrir " + app + ": " + (msg.isEmpty() ? "código " + p.exitValue() : msg.substring(0, Math.min(300, msg.length()))));
                }
            } catch (Exception e) { out("Error: " + e.getMessage()); }
        }).start();
    }

    /** Abre una URL, archivo o carpeta con la aplicación predeterminada. */
    void open(String target) {
        new Thread(() -> {
            try {
                new ProcessBuilder(WIN ? new String[]{"cmd", "/c", "start", "", target} : MAC ? new String[]{"open", target}
                        : new String[]{"xdg-open", target}).redirectErrorStream(true)
                        .redirectOutput(ProcessBuilder.Redirect.DISCARD).start();
                out("Abriendo " + target);
            } catch (Exception e) { out("Error: " + e.getMessage()); }
        }).start();
    }

    // ---------- Acceso a Internet ----------
    static final java.net.http.HttpClient HTTP = java.net.http.HttpClient.newBuilder()
            .connectTimeout(java.time.Duration.ofSeconds(6)).followRedirects(java.net.http.HttpClient.Redirect.NORMAL).build();

    static String enc(String s) { return java.net.URLEncoder.encode(s, java.nio.charset.StandardCharsets.UTF_8); }

    static java.net.http.HttpRequest.Builder req(String url) {
        return java.net.http.HttpRequest.newBuilder(java.net.URI.create(url)).timeout(java.time.Duration.ofSeconds(15))
                .header("User-Agent", "JarvisAssistant/3.0 (Java)");
    }

    static String get(String url) throws Exception {
        return HTTP.send(req(url).build(), java.net.http.HttpResponse.BodyHandlers.ofString()).body();
    }

    static String unjson(String s) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '\\' && i + 1 < s.length()) {
                char n = s.charAt(++i);
                if (n == 'n') b.append('\n');
                else if (n == 't') b.append(' ');
                else if (n == 'u') { b.append((char) Integer.parseInt(s.substring(i + 1, i + 5), 16)); i += 4; }
                else b.append(n);
            } else b.append(c);
        }
        return b.toString();
    }

    void wiki(String q) {
        if (q.isEmpty()) { out("Uso: wiki <tema>"); return; }
        new Thread(() -> {
            try {
                String j = get("https://es.wikipedia.org/w/api.php?action=query&format=json&generator=search&gsrlimit=1"
                        + "&prop=extracts&exintro=1&explaintext=1&redirects=1&gsrsearch=" + enc(q));
                java.util.regex.Matcher m = java.util.regex.Pattern.compile(
                        "\"title\":\"((?:[^\"\\\\]|\\\\.)*)\".*?\"extract\":\"((?:[^\"\\\\]|\\\\.)*)\"",
                        java.util.regex.Pattern.DOTALL).matcher(j);
                if (!m.find()) {
                    out("No encontré nada sobre '" + q + "'. Abro una búsqueda en el navegador.");
                    open("https://www.google.com/search?q=" + enc(q));
                    return;
                }
                String text = unjson(m.group(2)).trim();
                if (text.length() > 800) { int k = text.lastIndexOf('.', 800); text = text.substring(0, k > 200 ? k + 1 : 800); }
                out(unjson(m.group(1)) + "\n\n" + text);
                int dot = text.indexOf(". ");
                speak(dot > 0 && dot < 250 ? text.substring(0, dot + 1) : text.substring(0, Math.min(200, text.length())));
            } catch (Exception e) { out("Error de red: " + e.getMessage()); }
        }).start();
    }

    void clima(String city) {
        new Thread(() -> {
            try {
                out(get("https://wttr.in/" + enc(city) + "?lang=es&format=" + enc("%l: %C, %t (sensación %f), humedad %h, viento %w")).trim());
            } catch (Exception e) { out("Error de red: " + e.getMessage()); }
        }).start();
    }

    void noticias(String tema) {
        new Thread(() -> {
            try {
                String x = get(tema.isEmpty() ? "https://news.google.com/rss?hl=es&gl=ES&ceid=ES:es"
                        : "https://news.google.com/rss/search?q=" + enc(tema) + "&hl=es&gl=ES&ceid=ES:es");
                java.util.regex.Matcher m = java.util.regex.Pattern.compile("<item>.*?<title>(.*?)</title>",
                        java.util.regex.Pattern.DOTALL).matcher(x);
                StringBuilder sb = new StringBuilder(); int n = 0;
                while (m.find() && n < 8)
                    sb.append(++n).append(". ").append(m.group(1).replace("<![CDATA[", "").replace("]]>", "")
                            .replace("&amp;", "&").replace("&quot;", "\"").replace("&#39;", "'")).append("\n");
                out(n == 0 ? "No encontré noticias." : sb.toString().trim());
            } catch (Exception e) { out("Error de red: " + e.getMessage()); }
        }).start();
    }

    void descarga(String url) {
        new Thread(() -> {
            try {
                String name = url.replaceAll("[?#].*", "");
                name = name.substring(name.lastIndexOf('/') + 1);
                if (name.isEmpty()) name = "descarga_" + System.currentTimeMillis();
                String home = System.getProperty("user.home");
                File dir = new File(home, new File(home, "Descargas").isDirectory() ? "Descargas" : "Downloads");
                dir.mkdirs();
                Path dest = new File(dir, name).toPath();
                out("Descargando " + url + " …");
                java.net.http.HttpClient.newBuilder().followRedirects(java.net.http.HttpClient.Redirect.NORMAL).build()
                        .send(req(url).timeout(java.time.Duration.ofMinutes(10)).build(),
                                java.net.http.HttpResponse.BodyHandlers.ofFile(dest));
                out("Descarga completada: " + dest);
            } catch (Exception e) { out("Error al descargar: " + e); }
        }).start();
    }

    boolean net(String c, String l) {
        String a = c.contains(" ") ? c.substring(c.indexOf(' ') + 1).trim() : "";
        switch (l.split("\\s+")[0]) {
            case "clima": case "tiempo": clima(a.replaceAll("(?i)^en\\s+", "")); return true;
            case "noticias": noticias(a); return true;
            case "ia": case "ai": iaCmd(a); return true;
            case "telegram": case "movil": case "móvil": telegramCmd(a); return true;
            case "voz":
                voiceOn = !a.equalsIgnoreCase("off");
                if (!voiceOn && speech != null) speech.destroy();
                voiceStatus();
                out(voiceOn ? "Voz activada." : "Voz desactivada.");
                return true;
            case "di": speak(a); return true;
            case "escuchar": case "escucha": case "microfono": case "micrófono":
                listen(!a.equalsIgnoreCase("off") && !a.equalsIgnoreCase("no")); return true;
            case "wiki": case "web": wiki(a); return true;
            case "descarga": case "descargar":
                if (a.startsWith("http")) descarga(a); else out("Uso: descarga <url>");
                return true;
            case "ip":
                new Thread(() -> { try { out("IP pública: " + get("https://api.ipify.org").trim()); }
                    catch (Exception e) { out("Error de red: " + e.getMessage()); } }).start();
                return true;
            default: return false;
        }
    }

    /** Si Jarvis no reconoce el comando, lo trata como una pregunta y la busca en la web. */
    void pregunta(String c) {
        if (llmExec) { out("Comando no reconocido: " + c); return; }
        if (active() != null) { llm(c); return; }
        if (!hinted) { hinted = true; out("Consejo: pulsa Claude, OpenAI, Gemini, Groq, OpenRouter u Ollama en LLM STATUS para conectar una IA y conversar conmigo."); }
        String t = c.replaceAll("(?i)^(qu[eé] es|qu[eé] son|qui[eé]n es|qui[eé]n fue|cu[aá]l es|d[ií]me|h[aá]blame de)\\s+(el |la |los |las |un |una )?", "")
                .replaceAll("[?¿!¡]", "").trim();
        out("Buscando en la web: " + t);
        wiki(t);
    }

    void voiceStatus() {
        iVoice.set("Out " + (voiceOn ? "on" : "off") + " · Mic " + (listening ? "on" : "off"), listening || voiceOn ? GREEN : DIM);
    }

    /** Activa o desactiva el micrófono (reconocimiento de voz en el módulo Mic, vía reflexión). */
    void listen(boolean on) {
        try {
            Class<?> m = Class.forName("jarvis.Mic");
            if (!on) {
                m.getMethod("stop").invoke(null);
                listening = false; voice.on = false; voiceStatus();
                out("Micrófono desactivado.");
                return;
            }
            if (listening) { out("El micrófono ya está activo."); return; }
            java.util.function.Consumer<String> say = this::out;
            java.util.function.Consumer<String> onText = t -> SwingUtilities.invokeLater(() -> {
                String cmd = t.replaceAll("(?i)^(oye |hey )?jarvis[ ,]*", "").trim();
                if (!cmd.isEmpty()) handle(cmd);
            });
            java.util.function.Consumer<Double> onLevel = d -> voice.level = d;
            java.util.function.BooleanSupplier muted = () -> pendingTts.get() > 0;
            m.getMethod("start", java.util.function.Consumer.class, java.util.function.Consumer.class,
                    java.util.function.Consumer.class, java.util.function.BooleanSupplier.class).invoke(null, say, onText, onLevel, muted);
            listening = true; voice.on = true; voiceStatus();
        } catch (ClassNotFoundException | NoClassDefFoundError e) {
            out("Falta el módulo del micrófono (Mic.class y jna.jar). Con el instalador viene incluido.");
        } catch (Exception e) { out("Error: " + e); }
    }

    // ---------- Configuración (se guarda solo en este equipo) ----------
    static final File CFG = new File(System.getProperty("user.home"), ".jarvis/config.properties");

    void loadCfg() {
        try (InputStream in = new FileInputStream(CFG)) { cfg.load(in); } catch (Exception e) { /* primera vez */ }
    }

    synchronized void saveCfg() {
        try {
            CFG.getParentFile().mkdirs();
            if (!CFG.exists()) {
                CFG.createNewFile();
                try { Files.setPosixFilePermissions(CFG.toPath(), java.nio.file.attribute.PosixFilePermissions.fromString("rw-------")); }
                catch (Exception e) { /* Windows */ }
            }
            try (OutputStream o = new FileOutputStream(CFG)) { cfg.store(o, "Jarvis"); }
        } catch (Exception e) { out("No pude guardar la configuración: " + e.getMessage()); }
    }

    // ---------- Inteligencia artificial ----------
    static final String[] PROVIDERS = {"claude", "openai", "gemini", "groq", "openrouter", "ollama"};
    static final String[] PNAMES = {"Claude", "OpenAI", "Gemini", "Groq", "OpenRouter", "Ollama"};
    static final String[] PMODELS = {"claude-sonnet-5-5", "gpt-4o-mini", "gemini-2.0-flash", "llama-3.3-70b-versatile", "openrouter/auto", "llama3.2"};
    static final String[] PENV = {"ANTHROPIC_API_KEY", "OPENAI_API_KEY", "GEMINI_API_KEY", "GROQ_API_KEY", "OPENROUTER_API_KEY", ""};
    static final String[] PURL = {"https://api.anthropic.com/v1/messages", "https://api.openai.com/v1/chat/completions",
            "https://generativelanguage.googleapis.com/v1beta/models/", "https://api.groq.com/openai/v1/chat/completions",
            "https://openrouter.ai/api/v1/chat/completions", "http://localhost:11434"};
    static final String SYS = "Eres JARVIS, el asistente personal del ordenador del usuario, al estilo de Iron Man: educado, ingenioso y eficiente. "
            + "Responde en español (o en el idioma del usuario) con 1 a 3 frases cortas: tus respuestas se leen en voz alta. Sin markdown. "
            + "Si el usuario pide una acción en su PC, di brevemente lo que haces y añade, en líneas aparte, el comando exacto de Jarvis con el prefijo '>> '. "
            + "Máximo 3 comandos. Nunca inventes comandos. Comandos: abrir <app|url>, busca <texto>, terminal, captura, escribe <texto>, mueve <x> <y>, click, "
            + "volumen <0-100>, lista <ruta>, carpeta <ruta>, ejecuta <comando>, cierra <app> (cierra la ventana que Jarvis abrió) | cierra todo, bloquear, suspender, reiniciar, apagar, estado, procesos, red, "
            + "disco, memoria, sistema, bateria, clima [ciudad], noticias [tema], wiki <tema>, ip, descarga <url>, voz on|off; en Linux además: instalar <pkg>, "
            + "actualizar, servicio <accion> <nombre>, wifi on|off, bluetooth on|off, brillo <n>, silenciar, musica pausa|siguiente|anterior, tema oscuro|claro, "
            + "notifica <txt>, crear carpeta|archivo <ruta>, copiar <a> <b>, mover <a> <b>, encuentra <x>. "
            + "Las acciones peligrosas piden confirmación al usuario en su pantalla.";

    static int idx(String p) { for (int i = 0; i < PROVIDERS.length; i++) if (PROVIDERS[i].equals(p)) return i; return -1; }

    static int pidx(String s) {
        s = s.toLowerCase().trim();
        if (s.equals("chatgpt") || s.equals("gpt")) s = "openai";
        if (s.equals("google")) s = "gemini";
        if (s.equals("anthropic")) s = "claude";
        return idx(s);
    }

    String model(String p) { return cfg.getProperty(p + ".model", PMODELS[idx(p)]); }

    String key(String p) {
        String k = cfg.getProperty(p + ".key", "").trim();
        int i = idx(p);
        if (k.isEmpty() && i >= 0 && !PENV[i].isEmpty()) { String e = System.getenv(PENV[i]); if (e != null) k = e.trim(); }
        return k;
    }

    boolean ready(String p) { return p != null && (p.equals("ollama") ? ollamaUp : !key(p).isEmpty()); }

    String active() {
        String a = cfg.getProperty("active");
        if (a != null && ready(a)) return a;
        for (String p : PROVIDERS) if (ready(p)) return p;
        return null;
    }

    void refreshLlm() {
        SwingUtilities.invokeLater(() -> {
            String act = active(); int n = 0;
            for (int i = 0; i < PROVIDERS.length; i++) {
                String p = PROVIDERS[i]; boolean ok = ready(p); if (ok) n++;
                llmItems[i].set(p.equals(act) ? "Active" : ok ? "Connected" : p.equals("ollama") ? "Local · off" : "Not linked",
                        p.equals(act) ? GREEN : ok ? CYAN : DIM);
            }
            llmHud.tag = n + " Connected"; llmHud.tagColor = n > 0 ? GREEN : DIM; llmHud.repaint();
            iLlm.set(act == null ? "0 linked" : PNAMES[idx(act)], act == null ? DIM : GREEN);
        });
    }

    void probeOllama() {
        new Thread(() -> {
            try {
                HTTP.send(req(cfg.getProperty("ollama.url", PURL[5]) + "/api/tags").timeout(java.time.Duration.ofSeconds(2)).build(),
                        java.net.http.HttpResponse.BodyHandlers.discarding());
                ollamaUp = true;
            } catch (Exception e) { ollamaUp = false; }
            refreshLlm();
        }).start();
    }

    void clearHist() { synchronized (hist) { hist.clear(); } }

    /** Pide la clave en un cuadro de diálogo (no se muestra ni se escribe en el feed). */
    void configIA(String p) {
        final int i = idx(p);
        if (p.equals("ollama")) {
            String u = JOptionPane.showInputDialog(this, "Dirección de Ollama (debe estar ejecutándose en tu equipo o red):",
                    cfg.getProperty("ollama.url", PURL[5]));
            if (u == null || u.isBlank()) return;
            cfg.setProperty("ollama.url", u.trim()); cfg.setProperty("active", "ollama"); saveCfg(); clearHist();
            probeOllama();
            out("Ollama seleccionado (modelo " + model("ollama") + "). Cambia el modelo con: ia modelo <nombre>");
            return;
        }
        JPasswordField pf = new JPasswordField(32);
        int r = JOptionPane.showConfirmDialog(this, new Object[]{"Pega tu API key de " + PNAMES[i] + " (se guarda solo en este equipo):", pf},
                "Conectar " + PNAMES[i], JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        String k = new String(pf.getPassword()).trim();
        if (r != JOptionPane.OK_OPTION || k.isEmpty()) return;
        cfg.setProperty(p + ".key", k); cfg.setProperty("active", p); saveCfg(); clearHist(); refreshLlm();
        out("Clave de " + PNAMES[i] + " guardada. Probando la conexión…");
        new Thread(() -> {
            try {
                send(p, "Responde de forma muy breve.", java.util.Collections.singletonList(new String[]{"user", "Responde únicamente con la palabra OK."}));
                out(PNAMES[i] + " conectado. Ya puedes hablarme con frases normales.");
            } catch (Exception e) { out("Error de " + PNAMES[i] + ": " + e.getMessage() + ". Revisa la clave o el modelo (ia modelo <nombre>)."); }
        }).start();
    }

    void iaCmd(String a) {
        String[] w = a.trim().split("\\s+", 2);
        String sub = w[0].toLowerCase(), arg = w.length > 1 ? w[1].trim() : "";
        int i = pidx(arg);
        switch (sub) {
            case "": {
                String act = active();
                StringBuilder sb = new StringBuilder("IA activa: " + (act == null ? "ninguna" : PNAMES[idx(act)] + " (" + model(act) + ")") + "\n");
                for (int k = 0; k < PROVIDERS.length; k++) sb.append(PNAMES[k]).append(": ").append(ready(PROVIDERS[k]) ? "conectado" : "sin conectar").append("\n");
                out(sb.append("ia usar <p> · ia modelo <nombre> · ia clave <p> · ia olvidar <p> · ia reiniciar").toString());
                break;
            }
            case "usar":
                if (i < 0 || !ready(PROVIDERS[i])) out("Ese proveedor no está conectado.");
                else { cfg.setProperty("active", PROVIDERS[i]); saveCfg(); clearHist(); refreshLlm(); out("Ahora uso " + PNAMES[i] + "."); }
                break;
            case "modelo": {
                String act = active();
                if (act == null || arg.isEmpty()) out("Uso: ia modelo <nombre> (necesitas una IA activa)");
                else { cfg.setProperty(act + ".model", arg); saveCfg(); out("Modelo de " + PNAMES[idx(act)] + ": " + arg); }
                break;
            }
            case "clave":
                if (i < 0) out("Proveedores: " + String.join(", ", PROVIDERS)); else configIA(PROVIDERS[i]);
                break;
            case "olvidar":
                if (i < 0) out("Proveedores: " + String.join(", ", PROVIDERS));
                else {
                    cfg.remove(PROVIDERS[i] + ".key");
                    if (PROVIDERS[i].equals(cfg.getProperty("active"))) cfg.remove("active");
                    saveCfg(); refreshLlm(); out("Clave de " + PNAMES[i] + " borrada.");
                }
                break;
            case "reiniciar": clearHist(); out("Conversación reiniciada."); break;
            default: out("Uso: ia | ia usar <p> | ia modelo <m> | ia clave <p> | ia olvidar <p> | ia reiniciar");
        }
    }

    static String jq(String s) {
        StringBuilder b = new StringBuilder("\"");
        for (char c : s.toCharArray()) {
            if (c == '"') b.append("\\\""); else if (c == '\\') b.append("\\\\");
            else if (c == '\n') b.append("\\n"); else if (c == '\r') b.append("\\r"); else if (c == '\t') b.append("\\t");
            else if (c < 0x20) b.append(String.format("\\u%04x", (int) c)); else b.append(c);
        }
        return b.append('"').toString();
    }

    /** Envía la conversación al proveedor y devuelve el texto de la respuesta. */
    String send(String p, String sys, java.util.List<String[]> msgs) throws Exception {
        int pi = idx(p);
        String url = cfg.getProperty(p + ".url", PURL[pi]), m = model(p), body;
        String rx = "\"content\"\\s*:\\s*\"((?:[^\"\\\\]++|\\\\.)*+)\"";
        java.util.Map<String, String> hdr = new java.util.LinkedHashMap<>();
        StringBuilder ms = new StringBuilder();
        if (p.equals("gemini")) {
            if (!url.contains(":generateContent")) url = url + enc(m) + ":generateContent";
            hdr.put("x-goog-api-key", key(p));
            for (String[] x : msgs) ms.append(ms.length() > 0 ? "," : "").append("{\"role\":").append(jq(x[0].equals("user") ? "user" : "model"))
                    .append(",\"parts\":[{\"text\":").append(jq(x[1])).append("}]}");
            body = "{\"systemInstruction\":{\"parts\":[{\"text\":" + jq(sys) + "}]},\"contents\":[" + ms + "]}";
            rx = "\"text\"\\s*:\\s*\"((?:[^\"\\\\]++|\\\\.)*+)\"";
        } else if (p.equals("claude")) {
            hdr.put("x-api-key", key(p)); hdr.put("anthropic-version", "2023-06-01");
            for (String[] x : msgs) ms.append(ms.length() > 0 ? "," : "").append("{\"role\":").append(jq(x[0])).append(",\"content\":").append(jq(x[1])).append("}");
            body = "{\"model\":" + jq(m) + ",\"max_tokens\":700,\"system\":" + jq(sys) + ",\"messages\":[" + ms + "]}";
            rx = "\"type\"\\s*:\\s*\"text\"\\s*,\\s*\"text\"\\s*:\\s*\"((?:[^\"\\\\]++|\\\\.)*+)\"";
        } else {
            ms.append("{\"role\":\"system\",\"content\":").append(jq(sys)).append("}");
            for (String[] x : msgs) ms.append(",{\"role\":").append(jq(x[0])).append(",\"content\":").append(jq(x[1])).append("}");
            if (p.equals("ollama")) {
                url = url + "/api/chat";
                body = "{\"model\":" + jq(m) + ",\"stream\":false,\"messages\":[" + ms + "]}";
            } else {
                hdr.put("Authorization", "Bearer " + key(p));
                body = "{\"model\":" + jq(m) + ",\"messages\":[" + ms + "]}";
            }
        }
        java.net.http.HttpRequest.Builder b = req(url).timeout(java.time.Duration.ofSeconds(90)).header("Content-Type", "application/json");
        hdr.forEach(b::header);
        java.net.http.HttpResponse<String> r = HTTP.send(b.POST(java.net.http.HttpRequest.BodyPublishers.ofString(body)).build(),
                java.net.http.HttpResponse.BodyHandlers.ofString());
        if (r.statusCode() / 100 != 2) {
            java.util.regex.Matcher em = java.util.regex.Pattern.compile("\"message\"\\s*:\\s*\"((?:[^\"\\\\]++|\\\\.)*+)\"").matcher(r.body());
            throw new IOException("HTTP " + r.statusCode() + (em.find() ? ": " + unjson(em.group(1)) : ""));
        }
        java.util.regex.Matcher mm = java.util.regex.Pattern.compile(rx).matcher(r.body());
        if (!mm.find()) throw new IOException("respuesta inesperada del servidor");
        return unjson(mm.group(1)).trim();
    }

    /** Conversa con la IA activa; ejecuta los comandos que proponga (líneas que empiezan por >>). */
    final long[] llmTimes = new long[10];
    int llmPos;

    synchronized boolean llmAllowed() {
        long now = System.currentTimeMillis();
        if (now - llmTimes[llmPos] < 60000) return false;   // 10 peticiones por minuto como máximo
        llmTimes[llmPos] = now; llmPos = (llmPos + 1) % llmTimes.length;
        return true;
    }

    void llm(String prompt) {
        String p = active();
        if (p != null && !llmAllowed()) { out("Demasiadas peticiones seguidas a la IA. Espera un momento."); return; }
        if (p == null) { out("No hay ninguna IA conectada."); return; }
        new Thread(() -> {
            java.util.List<String[]> msgs;
            synchronized (hist) {
                hist.add(new String[]{"user", prompt});
                while (hist.size() > 12) hist.remove(0);
                msgs = new java.util.ArrayList<>(hist);
            }
            while (!msgs.isEmpty() && !msgs.get(0)[0].equals("user")) msgs.remove(0);
            try {
                String sys = SYS + " Sistema operativo: " + System.getProperty("os.name") + ". Fecha y hora actuales: " + new Date() + ".";
                String ans = send(p, sys, msgs);
                synchronized (hist) { hist.add(new String[]{"assistant", ans}); }
                present(ans);
            } catch (Exception e) {
                synchronized (hist) { if (!hist.isEmpty()) hist.remove(hist.size() - 1); }
                out("Error de " + PNAMES[idx(p)] + ": " + e.getMessage());
            }
        }, "jarvis-llm").start();
    }

    void present(String ans) {
        StringBuilder say = new StringBuilder();
        java.util.List<String> cmds = new java.util.ArrayList<>();
        for (String ln : ans.replace("**", "").replace("`", "").split("\\n")) {
            String t = ln.trim();
            if (t.startsWith(">>")) { if (cmds.size() < 3) cmds.add(t.substring(2).trim()); }
            else if (!t.isEmpty()) say.append(say.length() > 0 ? "\n" : "").append(t.replaceAll("^#+\\s*", ""));
        }
        String text = say.toString();
        if (!text.isEmpty()) {
            out(text);
            if (text.length() > 220 || text.contains("\n")) speak(text.length() > 300 ? text.substring(0, 300) : text);
        }
        if (!cmds.isEmpty()) SwingUtilities.invokeLater(() -> {
            llmExec = true;
            try { for (String c : cmds) handle(c); } finally { llmExec = false; }
        });
    }

    // ---------- Control desde el móvil (Android / iOS) con un bot de Telegram ----------
    String tgApi() { return cfg.getProperty("tg.api", "https://api.telegram.org") + "/bot" + cfg.getProperty("tg.token", ""); }

    void tgStatus() {
        SwingUtilities.invokeLater(() -> {
            boolean paired = !cfg.getProperty("tg.chat", "").isEmpty();
            iTg.set(!tgRun ? "Telegram off" : paired ? "Linked · on" : "Waiting pairing", !tgRun ? DIM : paired ? GREEN : CYAN);
        });
    }

    void telegramCmd(String a) {
        switch (a.trim().toLowerCase()) {
            case "off": case "apagar":
                tgRun = false; cfg.setProperty("tg.auto", "false"); saveCfg(); tgStatus(); out("Enlace con Telegram desactivado.");
                break;
            case "desvincular":
                tgRun = false; cfg.remove("tg.chat"); cfg.setProperty("tg.auto", "false"); saveCfg(); tgStatus(); out("Telegram desvinculado de este equipo.");
                break;
            case "token": askTgToken(); break;
            default:
                if (cfg.getProperty("tg.token", "").isEmpty()) askTgToken();
                else { cfg.setProperty("tg.auto", "true"); saveCfg(); startTelegram(); }
        }
    }

    void askTgToken() {
        JPasswordField pf = new JPasswordField(36);
        int r = JOptionPane.showConfirmDialog(this, new Object[]{"1) En Telegram abre @BotFather y envía /newbot.\\n2) Pega aquí el token que te da:", pf},
                "Conectar Telegram (móvil)", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        String t = new String(pf.getPassword()).trim();
        if (r != JOptionPane.OK_OPTION || t.isEmpty()) return;
        cfg.setProperty("tg.token", t); cfg.setProperty("tg.auto", "true"); saveCfg();
        startTelegram();
    }

    void startTelegram() {
        if (tgRun) { out("Telegram ya está activo."); return; }
        tgRun = true; tgStatus();
        Thread t = new Thread(this::tgLoop, "jarvis-telegram"); t.setDaemon(true); t.start();
        out(cfg.getProperty("tg.chat", "").isEmpty()
                ? "Telegram activo. Abre tu bot en el móvil y escríbele «hola»: te pediré aquí confirmar el emparejamiento."
                : "Telegram activo: puedes controlar este equipo desde el móvil.");
    }

    void tgLoop() {
        long off = 0;
        while (tgRun) {
            try {
                java.net.http.HttpResponse<String> r = HTTP.send(req(tgApi() + "/getUpdates?timeout=25&offset=" + off)
                        .timeout(java.time.Duration.ofSeconds(40)).build(), java.net.http.HttpResponse.BodyHandlers.ofString());
                if (r.statusCode() == 401 || r.statusCode() == 404) { out("Telegram: el token no es válido."); tgRun = false; tgStatus(); return; }
                if (r.statusCode() != 200) { Thread.sleep(5000); continue; }
                for (String u : r.body().split("\\{\\s*\"update_id\"\\s*:\\s*")) {
                    java.util.regex.Matcher id = java.util.regex.Pattern.compile("^(\\d+)").matcher(u);
                    if (!id.find()) continue;
                    off = Math.max(off, Long.parseLong(id.group(1)) + 1);
                    java.util.regex.Matcher ch = java.util.regex.Pattern.compile("\"chat\"\\s*:\\s*\\{\\s*\"id\"\\s*:\\s*(-?\\d+)").matcher(u);
                    java.util.regex.Matcher tx = java.util.regex.Pattern.compile("\"text\"\\s*:\\s*\"((?:[^\"\\\\]++|\\\\.)*+)\"").matcher(u);
                    java.util.regex.Matcher nm = java.util.regex.Pattern.compile("\"first_name\"\\s*:\\s*\"((?:[^\"\\\\]++|\\\\.)*+)\"").matcher(u);
                    java.util.regex.Matcher dt = java.util.regex.Pattern.compile("\"date\"\\s*:\\s*(\\d+)").matcher(u);
                    if (!ch.find() || !tx.find() || !java.util.regex.Pattern.compile("\"type\"\\s*:\\s*\"private\"").matcher(u).find()) continue;
                    if (dt.find() && System.currentTimeMillis() / 1000 - Long.parseLong(dt.group(1)) > 120) continue;  // ignora órdenes antiguas
                    tgMessage(ch.group(1), nm.find() ? unjson(nm.group(1)) : "?", unjson(tx.group(1)).trim());
                }
            } catch (Exception e) {
                if (!tgRun) return;
                try { Thread.sleep(5000); } catch (InterruptedException ie) { return; }
            }
        }
    }

    void tgMessage(String chat, String name, String text) throws Exception {
        String paired = cfg.getProperty("tg.chat", "");
        if (locked) { if (paired.equals(chat)) tgSend(chat, "Jarvis está bloqueado en el PC. Inicia sesión allí para usar el control remoto."); return; }
        if (paired.isEmpty()) {
            if (tgDenied.contains(chat)) return;
            final boolean[] ok = {false};
            SwingUtilities.invokeAndWait(() -> ok[0] = confirm("¿Autorizar el Telegram de «" + name + "» para controlar este equipo?\n\nSolo acepta si eres tú."));
            if (!ok[0]) { tgDenied.add(chat); tgSend(chat, "Emparejamiento rechazado en el equipo."); return; }
            cfg.setProperty("tg.chat", chat); saveCfg(); tgStatus();
            tgSend(chat, "Emparejado. Soy Jarvis: dime qué quieres que haga en tu equipo.");
            return;
        }
        if (!paired.equals(chat)) return;
        tgChatNow = chat; tgUntil = System.currentTimeMillis() + 15000;
        String cmd = text.replaceFirst("^/", "");
        if (cmd.equals("start")) { tgSend(chat, "Jarvis listo. Escribe una orden (ej: estado, clima, abre firefox) o habla con normalidad."); return; }
        SwingUtilities.invokeLater(() -> handle(cmd));
    }

    void tgSend(String chat, String text) {
        tgOut.submit(() -> {
            try {
                String body = "chat_id=" + chat + "&text=" + enc(text.length() > 3500 ? text.substring(0, 3500) : text);
                HTTP.send(req(tgApi() + "/sendMessage").header("Content-Type", "application/x-www-form-urlencoded")
                        .POST(java.net.http.HttpRequest.BodyPublishers.ofString(body)).build(), java.net.http.HttpResponse.BodyHandlers.discarding());
            } catch (Exception e) { /* sin red */ }
        });
    }

    // ---------- Voz (usa la voz del sistema operativo) ----------
    void speak(String text) {
        if (!voiceOn || text == null || pendingTts.get() >= 3) return;
        String t = text.replaceAll("[•▸\\n]+", ". ").replaceAll("\\s+", " ").trim();
        if (t.isEmpty()) return;
        pendingTts.incrementAndGet();
        tts.submit(() -> {
            try {
                if (!voiceOn) return;
                String[] cmd;
                if (WIN) cmd = new String[]{"powershell", "-NoProfile", "-Command",
                        "Add-Type -AssemblyName System.Speech; $s = New-Object System.Speech.Synthesis.SpeechSynthesizer; "
                        + "try { $s.SelectVoiceByHints('Male', 'NotSet', 0, [System.Globalization.CultureInfo]'es-ES') } catch {}; "
                        + "$s.Speak($env:JARVIS_TEXT)"};
                else if (MAC) cmd = new String[]{"bash", "-c", "say -v Jorge -r 175 \"$JARVIS_TEXT\" 2>/dev/null || say \"$JARVIS_TEXT\""};
                else cmd = new String[]{"bash", "-c", "if command -v espeak-ng >/dev/null; then espeak-ng -v es+m3 -s 150 -p 30 \"$JARVIS_TEXT\"; "
                        + "elif command -v spd-say >/dev/null; then spd-say -w -l es -t male1 \"$JARVIS_TEXT\"; fi"};
                ProcessBuilder pb = new ProcessBuilder(cmd).redirectErrorStream(true).redirectOutput(ProcessBuilder.Redirect.DISCARD);
                pb.environment().put("JARVIS_TEXT", t);
                speech = pb.start();
                speech.waitFor();
            } catch (Exception e) { /* sin voz disponible */ }
            finally { pendingTts.decrementAndGet(); }
        });
    }

    // ---------- Inicio de sesión (cuenta local protegida con contraseña) ----------
    static byte[] pbkdf2(char[] pw, byte[] salt) throws Exception {
        return javax.crypto.SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
                .generateSecret(new javax.crypto.spec.PBEKeySpec(pw, salt, 200000, 256)).getEncoded();
    }

    static String b64(byte[] b) { return java.util.Base64.getEncoder().encodeToString(b); }

    static class PassField extends JPasswordField {
        String hint;
        PassField(String h) { hint = h; }
        @Override protected void paintComponent(Graphics g0) {
            super.paintComponent(g0);
            if (getPassword().length == 0) {
                Graphics2D g = (Graphics2D) g0.create(); aa(g);
                g.setColor(DIM); g.setFont(getFont());
                FontMetrics fm = g.getFontMetrics();
                g.drawString(hint, getInsets().left, (getHeight() + fm.getAscent() - fm.getDescent()) / 2);
                g.dispose();
            }
        }
    }

    static JButton hudBtn(String t, boolean primary) {
        JButton b = new JButton(t);
        b.setUI(new javax.swing.plaf.basic.BasicButtonUI());
        b.setOpaque(true); b.setFocusPainted(false);
        b.setBackground(primary ? new Color(0, 110, 170) : new Color(12, 43, 77)); b.setForeground(TXT);
        b.setFont(new Font(SANS, Font.BOLD, 13));
        b.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(primary ? CYAN : new Color(0, 110, 150)),
                BorderFactory.createEmptyBorder(9, 14, 9, 14)));
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return b;
    }

    static void styleField(JTextField f) {
        f.setOpaque(true); f.setBackground(new Color(10, 34, 64)); f.setForeground(TXT); f.setCaretColor(CYAN);
        f.setFont(new Font(SANS, Font.PLAIN, 14));
        f.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(new Color(0, 110, 150)), BorderFactory.createEmptyBorder(9, 11, 9, 11)));
    }

    /** Pide iniciar sesión (o crear la cuenta la primera vez). Devuelve true si se entra. */
    boolean login() {
        final boolean create = cfg.getProperty("auth.hash") == null;
        final boolean[] ok = {false};
        final int[] fails = {0};
        JDialog dlg = new JDialog((Frame) null, "Jarvis", true);
        dlg.setUndecorated(true);
        dlg.setIconImage(icon());
        Hud box = new Hud(null, new GridLayout(0, 1, 0, 9));
        box.setBorder(BorderFactory.createEmptyBorder(22, 26, 20, 26));
        JLabel t1 = new JLabel("J A R V I S", SwingConstants.CENTER); t1.setForeground(CYAN); t1.setFont(new Font(SANS, Font.BOLD, 24));
        JLabel t2 = new JLabel(create ? "Crea tu cuenta para proteger Jarvis" : "Inicia sesión para continuar", SwingConstants.CENTER);
        t2.setForeground(DIM); t2.setFont(new Font(SANS, Font.PLAIN, 12));
        HintField user = new HintField("Usuario"); styleField(user);
        PassField pass = new PassField("Contraseña"); styleField(pass);
        PassField pass2 = new PassField("Repite la contraseña"); styleField(pass2);
        JLabel msg = new JLabel(" ", SwingConstants.CENTER); msg.setForeground(RED); msg.setFont(new Font(SANS, Font.PLAIN, 12));
        JButton enter = hudBtn(create ? "Crear cuenta y entrar" : "Entrar", true), exit = hudBtn("Salir", false);
        JPanel btns = new JPanel(new GridLayout(1, 2, 10, 0)); btns.setOpaque(false); btns.add(exit); btns.add(enter);
        box.add(t1); box.add(t2); box.add(user); box.add(pass); if (create) box.add(pass2); box.add(msg); box.add(btns);
        if (!create) user.setText(cfg.getProperty("auth.user", ""));
        Runnable submit = () -> {
            char[] pw = pass.getPassword(), pw2 = pass2.getPassword();
            try {
                String u = user.getText().trim();
                if (create) {
                    if (u.length() < 3) { msg.setText("El usuario debe tener al menos 3 caracteres."); return; }
                    if (pw.length < 8) { msg.setText("La contraseña debe tener al menos 8 caracteres."); return; }
                    if (!java.util.Arrays.equals(pw, pw2)) { msg.setText("Las contraseñas no coinciden."); return; }
                    byte[] salt = new byte[16]; new java.security.SecureRandom().nextBytes(salt);
                    cfg.setProperty("auth.user", u); cfg.setProperty("auth.salt", b64(salt)); cfg.setProperty("auth.hash", b64(pbkdf2(pw, salt)));
                    saveCfg(); ok[0] = true; dlg.dispose();
                } else {
                    java.util.Base64.Decoder d = java.util.Base64.getDecoder();
                    byte[] h = pbkdf2(pw, d.decode(cfg.getProperty("auth.salt", "")));
                    boolean good = u.equalsIgnoreCase(cfg.getProperty("auth.user", "")) && java.security.MessageDigest.isEqual(h, d.decode(cfg.getProperty("auth.hash", "")));
                    if (good) { ok[0] = true; dlg.dispose(); return; }
                    msg.setText("Usuario o contraseña incorrectos."); pass.setText("");
                    if (++fails[0] >= 5) {
                        enter.setEnabled(false); msg.setText("Demasiados intentos. Espera 30 segundos.");
                        javax.swing.Timer wait = new javax.swing.Timer(30000, ev -> { enter.setEnabled(true); fails[0] = 0; msg.setText(" "); });
                        wait.setRepeats(false); wait.start();
                    }
                }
            } catch (Exception e) { msg.setText("Error: " + e.getMessage()); }
            finally { java.util.Arrays.fill(pw, '0'); java.util.Arrays.fill(pw2, '0'); }
        };
        enter.addActionListener(e -> submit.run());
        pass.addActionListener(e -> { if (enter.isEnabled()) submit.run(); });
        pass2.addActionListener(e -> { if (enter.isEnabled()) submit.run(); });
        user.addActionListener(e -> pass.requestFocusInWindow());
        exit.addActionListener(e -> dlg.dispose());
        dlg.getContentPane().setBackground(BG);
        dlg.getContentPane().setLayout(new BorderLayout());
        dlg.getContentPane().add(box, BorderLayout.CENTER);
        dlg.setSize(400, create ? 430 : 370);
        dlg.setLocationRelativeTo(null);
        dlg.addWindowListener(new WindowAdapter() { @Override public void windowOpened(WindowEvent e) { (user.getText().isEmpty() ? user : pass).requestFocusInWindow(); } });
        dlg.setVisible(true);
        return ok[0];
    }

    void unlock(boolean greet) {
        locked = false;
        opName.setText(cfg.getProperty("auth.user", System.getProperty("user.name")));
        if (greet) {
            int hr0 = java.time.LocalTime.now().getHour();
            out((hr0 < 12 ? "Buenos días" : hr0 < 20 ? "Buenas tardes" : "Buenas noches")
                    + ", señor. Todos los sistemas en línea. Escribe 'ayuda' para ver los comandos.");
        }
    }

    /** Cierra la sesión de Jarvis: oculta la ventana y vuelve a pedir la contraseña. */
    void lock() {
        if (locked) return;
        if (listening) listen(false);
        locked = true;
        setVisible(false);
        if (login()) { unlock(false); setVisible(true); input.requestFocusInWindow(); } else System.exit(0);
    }

    // ---------- Cerrar ventanas / aplicaciones ----------
    static final java.util.Set<String> PROTECTED = java.util.Set.of("systemd", "gnome-shell", "xorg", "xwayland", "gdm", "gdm3",
            "dbus-daemon", "pipewire", "pulseaudio", "bash", "sh", "java", "init", "login", "sshd", "explorer.exe", "finder", "dock");

    static String exeOf(String run) {
        for (String t : run.trim().split("\\s+")) {
            if (t.contains("=") || t.equals("env") || t.equals("nohup") || t.equals("exec") || t.equals("start") || t.equals("\"\"")) continue;
            return new File(t.replace("\"", "").replace("'", "")).getName().toLowerCase();
        }
        return "";
    }

    static boolean sameApp(String[] o, String w) {
        String nw = norm(w), a = ALIAS.getOrDefault(nw, nw), ao = norm(o[0]), aa = ALIAS.getOrDefault(ao, ao);
        return ao.contains(nw) || nw.contains(ao) || aa.equals(a) || (!o[1].isEmpty() && (o[1].contains(a) || a.contains(o[1])));
    }

    void runArgs(String... args) {
        try {
            Process p = new ProcessBuilder(args).redirectErrorStream(true).start();
            String o = new String(p.getInputStream().readAllBytes()).trim();
            p.waitFor();
            if (!o.isEmpty()) out(o);
        } catch (Exception e) { out("Error: " + e.getMessage()); }
    }

    /** «cierra calculadora», «cierra la ventana» (la última que abrió Jarvis), «cierra todo». */
    void cerrar(String what) {
        String w = norm(what);
        while (w.matches("^(la|el|los|las|ventana|ventanas|programa|app|aplicacion|de|del)(\\s.*)?$")) w = w.contains(" ") ? w.substring(w.indexOf(' ') + 1).trim() : "";
        final String t = w;
        new Thread(() -> {
            try {
                boolean all = t.equals("todo") || t.equals("todas") || t.equals("todos");
                java.util.List<String[]> mine = new java.util.ArrayList<>();
                synchronized (opened) {
                    if (all) mine.addAll(opened);
                    else if (t.isEmpty()) { if (!opened.isEmpty()) mine.add(opened.get(opened.size() - 1)); }
                    else for (String[] o : opened) if (sameApp(o, t)) mine.add(o);
                    opened.removeAll(mine);
                }
                int closed = 0;
                for (String[] o : mine) {
                    java.util.Optional<ProcessHandle> ph = ProcessHandle.of(Long.parseLong(o[2]));
                    if (ph.isPresent() && ph.get().isAlive()) {
                        ph.get().descendants().forEach(ProcessHandle::destroy); ph.get().destroy(); closed++; out("Cerrando " + o[0] + ".");
                    }
                }
                if (closed > 0) return;
                if (all || t.isEmpty()) { out("Jarvis no tiene ninguna ventana abierta que cerrar."); return; }
                closeByName(t);
            } catch (Exception e) { out("Error: " + e); }
        }, "jarvis-close").start();
    }

    void closeByName(String t) throws Exception {
        String key = ALIAS.getOrDefault(norm(t), norm(t));
        if (WIN) {
            String n = key.replaceAll("[^\\w .-]", "");
            runArgs("powershell", "-NoProfile", "-Command", "$n='" + n + "'; $p = @(Get-Process | Where-Object { $_.MainWindowTitle -and "
                    + "($_.ProcessName -like \"*$n*\" -or $_.MainWindowTitle -like \"*$n*\") }); if ($p.Count -gt 0) { $p | ForEach-Object { $null = $_.CloseMainWindow() }; "
                    + "\"Cerradas $($p.Count) ventana(s) de $n\" } else { \"No encuentro ninguna ventana de $n\" }");
            return;
        }
        if (MAC) {
            StringBuilder sb = new StringBuilder();
            for (String x : key.replaceAll("[^\\w .-]", "").split(" ")) if (!x.isEmpty()) sb.append(sb.length() > 0 ? " " : "").append(Character.toUpperCase(x.charAt(0))).append(x.substring(1));
            runArgs("osascript", "-e", "tell application \"" + sb + "\" to quit");
            out("Cerrando " + sb + ".");
            return;
        }
        String exe = key, f = findDesktop(key);
        if (f != null) { String e = execOf(f); if (e != null && !exeOf(e).isEmpty()) exe = exeOf(e); }
        if (PROTECTED.contains(exe)) { out("Por seguridad no cierro '" + exe + "'."); return; }
        final String fe = exe, me = System.getProperty("user.name");
        final long self = ProcessHandle.current().pid();
        java.util.List<ProcessHandle> found = new java.util.ArrayList<>();
        ProcessHandle.allProcesses().filter(ph -> ph.pid() != self && ph.info().user().map(me::equals).orElse(false)
                && ph.info().command().map(c -> new File(c).getName().toLowerCase().equals(fe)).orElse(false)).forEach(found::add);
        if (found.isEmpty()) { out("No encuentro ninguna ventana de '" + t + "' abierta."); return; }
        StringBuilder pids = new StringBuilder();
        for (ProcessHandle ph : found) pids.append(ph.pid()).append(' ');
        // 1) cerrar solo las ventanas (X11/XWayland, necesita wmctrl): no se pierde nada sin avisar
        Process pr = new ProcessBuilder("bash", "-c", "command -v wmctrl >/dev/null || exit 3; n=0; for p in " + pids
                + "; do for w in $(wmctrl -lp | awk -v p=$p '$3==p{print $1}'); do wmctrl -ic $w && n=$((n+1)); done; done; "
                + "[ $n -gt 0 ] && echo \"Cerradas $n ventana(s) de " + t.replaceAll("[^\\w .-]", "") + ".\" || exit 4").redirectErrorStream(true).start();
        String o = new String(pr.getInputStream().readAllBytes()).trim();
        if (pr.waitFor() == 0) { out(o); return; }
        // 2) terminar el proceso: puede haber datos sin guardar, así que se pide confirmación
        final boolean[] ok = {false};
        SwingUtilities.invokeAndWait(() -> ok[0] = confirm("¿Cerrar " + found.size() + " proceso(s) de '" + t + "'?\n\nSe perderán los datos sin guardar."));
        if (ok[0]) { found.forEach(ProcessHandle::destroy); out("Cerrado " + t + "."); }
    }

    // ---------- Comandos equivalentes para Windows y macOS ----------
    boolean other(String c, String l) {
        if (!WIN && !MAC) return false;
        String a = c.contains(" ") ? c.substring(c.indexOf(' ') + 1).trim() : "";
        String cmd;
        switch (l.split("\\s+")[0]) {
            case "procesos": cmd = WIN ? "tasklist" : "ps aux -r | head -15 | cut -c1-150"; break;
            case "red": cmd = WIN ? "ipconfig" : "ifconfig | grep 'inet '"; break;
            case "disco": cmd = WIN ? "powershell -NoProfile -Command \"Get-PSDrive -PSProvider FileSystem | Format-Table Name,Used,Free\"" : "df -h | head"; break;
            case "memoria": cmd = WIN ? "powershell -NoProfile -Command \"Get-CimInstance Win32_OperatingSystem | Format-List FreePhysicalMemory,TotalVisibleMemorySize\"" : "vm_stat | head -8"; break;
            case "sistema": cmd = WIN ? "ver" : "sw_vers; uptime"; break;
            case "bateria": cmd = WIN ? "powershell -NoProfile -Command \"(Get-CimInstance Win32_Battery).EstimatedChargeRemaining\"" : "pmset -g batt"; break;
            case "ping": cmd = (WIN ? "ping -n 4 " : "ping -c 4 ") + a.replaceAll("[^\\w.\\-]", ""); break;
            default: return false;
        }
        exec(cmd);
        return true;
    }

    static Image icon() {
        java.awt.image.BufferedImage im = new java.awt.image.BufferedImage(64, 64, java.awt.image.BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = im.createGraphics(); aa(g);
        g.setPaint(new RadialGradientPaint(32, 32, 30, new float[]{0f, 0.7f, 1f},
                new Color[]{new Color(40, 150, 220), new Color(4, 30, 70), new Color(2, 12, 28)}));
        g.fillOval(2, 2, 60, 60);
        g.setColor(CYAN); g.setStroke(new BasicStroke(3f)); g.drawOval(3, 3, 58, 58);
        g.setStroke(new BasicStroke(1.5f)); g.drawOval(14, 8, 36, 48); g.drawOval(8, 20, 48, 24);
        g.dispose();
        return im;
    }

    // ---------- Módulo de control de Linux ----------
    String q(String s) { return "'" + s.replace("'", "'\\''") + "'"; }
    String pk(String s) { return s.replaceAll("[^\\w.+:\\- ]", ""); }
    void ask(String msg, String cmd) { if (confirm(msg)) exec(cmd); }

    boolean linux(String c, String l) {
        if (WIN || MAC) return false;
        String a = c.contains(" ") ? c.substring(c.indexOf(' ') + 1).trim() : "";
        String[] w = l.split("\\s+"), p = c.split("\\s+");
        String al = a.toLowerCase();
        switch (w[0]) {
            // Paquetes
            case "instalar": ask("¿Instalar: " + pk(a) + "?", "pkexec apt install -y " + pk(a)); return true;
            case "desinstalar": ask("¿Desinstalar: " + pk(a) + "?", "pkexec apt remove -y " + pk(a)); return true;
            case "actualizar": ask("¿Actualizar todo el sistema?", "pkexec bash -c 'apt update && apt upgrade -y'"); return true;
            case "paquete": exec("apt search " + q(a) + " 2>/dev/null | head -30"); return true;
            // Servicios y procesos
            case "servicios": exec("systemctl list-units --type=service --state=running --no-pager | head -30"); return true;
            case "servicio": {
                String[] x = al.split("\\s+");
                if (x.length < 2) { out("Uso: servicio <estado|iniciar|detener|reiniciar|activar|desactivar> <nombre>"); return true; }
                String act = switch (x[0]) { case "estado" -> "status"; case "iniciar" -> "start"; case "detener" -> "stop";
                    case "reiniciar" -> "restart"; case "activar" -> "enable"; case "desactivar" -> "disable"; default -> null; };
                if (act == null) { out("Acción no válida: " + x[0]); return true; }
                String n = pk(x[1]);
                if (act.equals("status")) exec("systemctl status " + n + " --no-pager | head -15");
                else ask("¿" + x[0] + " el servicio " + n + "?", "pkexec systemctl " + act + " " + n);
                return true;
            }
            case "procesos": exec("ps aux --sort=-%cpu | head -15 | cut -c1-150"); return true;
            // Red
            case "red": exec("ip -brief addr; echo; nmcli -t -f ACTIVE,SSID dev wifi | grep '^yes'"); return true;
            case "ping": exec("ping -c 4 " + q(a)); return true;
            case "wifi":
                if (al.equals("on") || al.equals("off")) exec("nmcli radio wifi " + al);
                else if (al.startsWith("conectar ") && p.length >= 3)
                    exec("nmcli device wifi connect " + q(p[2]) + (p.length > 3 ? " password " + q(p[3]) : ""));
                else exec("nmcli -f SSID,SIGNAL,SECURITY device wifi list | head -20");
                return true;
            case "bluetooth":
                if (al.equals("on")) exec("rfkill unblock bluetooth && bluetoothctl power on");
                else if (al.equals("off")) exec("bluetoothctl power off; rfkill block bluetooth");
                else exec("bluetoothctl devices");
                return true;
            case "firewall":
                if (al.equals("on")) ask("¿Activar el firewall?", "pkexec ufw enable");
                else if (al.equals("off")) ask("¿Desactivar el firewall?", "pkexec ufw disable");
                else exec("pkexec ufw status");
                return true;
            // Hardware y multimedia
            case "brillo": exec("brightnessctl set " + Integer.parseInt(al) + "%"); return true;
            case "silenciar": exec("pactl set-sink-mute @DEFAULT_SINK@ toggle"); return true;
            case "musica": case "música": {
                String m = al.startsWith("sig") ? "next" : al.startsWith("ant") ? "previous" : "play-pause";
                exec("playerctl " + m); return true;
            }
            case "bateria": case "batería":
                exec("cat /sys/class/power_supply/BAT*/capacity /sys/class/power_supply/BAT*/status 2>/dev/null || echo 'Sin batería'");
                return true;
            case "temperatura": exec("sensors 2>&1 | head -20"); return true;
            case "usb": exec("lsusb"); return true;
            // Información
            case "sistema": exec("uname -srm; lsb_release -ds 2>/dev/null; uptime -p"); return true;
            case "disco": exec("df -h -x tmpfs -x devtmpfs | head"); return true;
            case "memoria": exec("free -h"); return true;
            // Escritorio
            case "tema": {
                String t = al.startsWith("osc") ? "prefer-dark" : "default";
                exec("gsettings set org.gnome.desktop.interface color-scheme " + t); return true;
            }
            case "fondo":
                exec("gsettings set org.gnome.desktop.background picture-uri 'file://" + a + "'; "
                        + "gsettings set org.gnome.desktop.background picture-uri-dark 'file://" + a + "'");
                return true;
            case "notifica": exec("notify-send Jarvis " + q(a)); return true;
            case "cerrar":
                if (al.startsWith("sesi")) ask("¿Cerrar sesión?", "gnome-session-quit --logout --no-prompt");
                return true;
            case "papelera": ask("¿Vaciar la papelera?", "gio trash --empty"); return true;
            case "limpiar": SwingUtilities.invokeLater(() -> chat.clear()); return true;
            // Archivos
            case "crear":
                if (al.startsWith("carpeta ")) exec("mkdir -p " + q(c.substring(c.indexOf(' ', 7) + 1).trim()));
                else if (al.startsWith("archivo ")) exec("touch " + q(c.substring(c.indexOf(' ', 7) + 1).trim()));
                return true;
            case "copiar": if (p.length >= 3) exec("cp -r " + q(p[1]) + " " + q(p[2])); return true;
            case "mover": if (p.length >= 3) ask("¿Mover " + p[1] + " a " + p[2] + "?", "mv " + q(p[1]) + " " + q(p[2])); return true;
            case "encuentra": exec("find ~ -iname " + q("*" + a + "*") + " 2>/dev/null | head -30"); return true;
            case "ocupa": exec("du -sh " + q(a)); return true;
            case "sudo": ask("¿Ejecutar como administrador?\n\n" + a, "pkexec " + a); return true;
            default: return false;
        }
    }

    void handle(String raw) {
        String c = raw.trim(), l = c.toLowerCase();
        if (c.isEmpty()) return;
        if (locked) { out("Jarvis está bloqueado. Inicia sesión."); return; }
        if (l.matches("^(abre|lanza|inicia)\\s.*")) {
            c = "abrir " + c.substring(c.indexOf(' ') + 1).trim();
            l = c.toLowerCase();
        }
        out("▸ " + c); timeline.push(c);
        try {
            if (l.equals("salir") || l.equals("logout") || l.equals("bloquear jarvis") || l.startsWith("cerrar sesion de jarvis") || l.startsWith("cerrar sesión de jarvis")) {
                SwingUtilities.invokeLater(this::lock);
            } else if (l.equals("ayuda")) {
                out("abrir <app|url> · busca <texto> · ejecuta <comando> · terminal · captura\n"
                        + "escribe <texto> · mueve <x> <y> · click · volumen <0-100>\n"
                        + "lista <ruta> · carpeta <ruta> · borra <archivo>\n"
                        + "cierra <app> | cierra todo (cierra lo que Jarvis abrió) · salir (cerrar sesión de Jarvis)\n"
                        + "bloquear · suspender · reiniciar · apagar · estado · hora\n"
                        + "LINUX: instalar/desinstalar <pkg> · actualizar · paquete <x> · servicios · servicio <acción> <n>\n"
                        + "procesos · red · ping <host> · wifi [on|off|conectar ssid clave] · bluetooth [on|off] · firewall [on|off]\n"
                        + "brillo <n> · silenciar · musica [pausa|siguiente|anterior] · bateria · temperatura · usb\n"
                        + "sistema · disco · memoria · tema oscuro|claro · fondo <ruta> · notifica <txt> · cerrar sesion\n"
                        + "crear carpeta|archivo <ruta> · copiar <a> <b> · mover <a> <b> · encuentra <x> · ocupa <ruta>\n"
                        + "papelera · limpiar · sudo <comando>\n"
                        + "IA: ia · ia usar <p> · ia modelo <m> · ia clave <p> · ia olvidar <p> · ia reiniciar (con una IA conectada, habla con frases normales)\n"
                        + "MÓVIL: telegram on|off|token|desvincular (controla este equipo desde Android o iOS)\n"
                        + "VOZ: voz on|off · di <texto> · escuchar on|off (micrófono, di \"abre calculadora\")\n"
                        + "INTERNET: clima [ciudad] · noticias [tema] · wiki <tema> · ip · descarga <url>\n"
                        + "Cualquier otra frase se busca en la web (ej: qué es un agujero negro)");
            } else if (l.startsWith("abrir ")) {
                String a = c.substring(6).trim();
                if (a.startsWith("http") || a.matches("^[\\w-]+\\.[a-z]{2,}.*")) {
                    open(a.startsWith("http") ? a : "https://" + a);
                } else launch(a);
            } else if (l.startsWith("busca ")) {
                String q = java.net.URLEncoder.encode(c.substring(6), "UTF-8");
                open("https://www.google.com/search?q=" + q);
            } else if (l.startsWith("ejecuta ")) {
                String cmd = c.substring(8);
                if (confirm("¿Ejecutar este comando?\n\n" + cmd)) exec(cmd);
            } else if (l.equals("terminal")) {
                launch(WIN ? "cmd" : MAC ? "Terminal" : "x-terminal-emulator");
            } else if (l.startsWith("captura")) {
                Rectangle r = new Rectangle(Toolkit.getDefaultToolkit().getScreenSize());
                Path f = Paths.get(System.getProperty("user.home"), "jarvis_" + System.currentTimeMillis() + ".png");
                setState(ICONIFIED); Thread.sleep(600);
                ImageIO.write(robot.createScreenCapture(r), "png", f.toFile());
                setState(NORMAL);
                out("Captura guardada en " + f);
            } else if (l.startsWith("escribe ")) {
                Toolkit.getDefaultToolkit().getSystemClipboard().setContents(new StringSelection(c.substring(8)), null);
                int m = MAC ? KeyEvent.VK_META : KeyEvent.VK_CONTROL;
                robot.keyPress(m); robot.keyPress(KeyEvent.VK_V); robot.keyRelease(KeyEvent.VK_V); robot.keyRelease(m);
            } else if (l.startsWith("mueve ")) {
                String[] p = l.split("\\s+");
                robot.mouseMove(Integer.parseInt(p[1]), Integer.parseInt(p[2]));
            } else if (l.equals("click")) {
                robot.mousePress(InputEvent.BUTTON1_DOWN_MASK); robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
            } else if (l.startsWith("volumen ")) {
                int v = Math.max(0, Math.min(100, Integer.parseInt(l.substring(8).trim())));
                exec(WIN ? "powershell -c \"(New-Object -ComObject WScript.Shell).SendKeys([char]173)\""
                        : MAC ? "osascript -e 'set volume output volume " + v + "'"
                        : "pactl set-sink-volume @DEFAULT_SINK@ " + v + "%");
                out("Volumen " + v + "%");
            } else if (l.startsWith("lista")) {
                String ruta = c.length() > 6 ? c.substring(6).trim() : ".";
                try (var s = Files.list(Paths.get(ruta))) { s.limit(80).forEach(x -> out(x.getFileName().toString())); }
            } else if (l.startsWith("carpeta ")) {
                open(c.substring(8).trim());
            } else if (l.startsWith("borra ")) {
                Path p = Paths.get(c.substring(6).trim());
                if (confirm("¿Borrar definitivamente?\n\n" + p.toAbsolutePath())) { Files.delete(p); out("Borrado " + p); }
            } else if (l.matches("^(cierra|cerrar|cierre)(\\s.*)?$") && !l.startsWith("cerrar sesi")) {
                cerrar(c.contains(" ") ? c.substring(c.indexOf(' ') + 1).trim() : "");
            } else if (l.equals("bloquear")) {
                exec(WIN ? "rundll32.exe user32.dll,LockWorkStation" : MAC ? "pmset displaysleepnow" : "loginctl lock-session");
            } else if (l.equals("suspender")) {
                if (confirm("¿Suspender el equipo?"))
                    exec(WIN ? "rundll32.exe powrprof.dll,SetSuspendState 0,1,0" : MAC ? "pmset sleepnow" : "systemctl suspend");
            } else if (l.equals("reiniciar")) {
                if (confirm("¿Reiniciar el equipo?")) exec(WIN ? "shutdown /r /t 5" : "systemctl reboot");
            } else if (l.equals("apagar")) {
                if (confirm("¿Apagar el equipo?")) exec(WIN ? "shutdown /s /t 5" : "systemctl poweroff");
            } else if (l.equals("estado")) {
                out(String.format("CPU %.0f%% · RAM %.0f%% · Disco %.0f%%", cpu.v * 100, ram.v * 100, disk.v * 100));
            } else if (l.equals("hora")) {
                out(new SimpleDateFormat("HH:mm:ss, EEEE d MMMM yyyy").format(new Date()));
            } else {
                { if (!linux(c, l) && !other(c, l) && !net(c, l)) pregunta(c); }
            }
        } catch (Exception e) {
            out("Error: " + e);
        }
    }

    // ---------- Componentes gráficos (estilo HUD) ----------
    static void aa(Graphics2D g) {
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
    }

    static class Hud extends JPanel {
        String title, tag; Color tagColor = GREEN; boolean glow;
        Hud(String t, LayoutManager lm) {
            super(lm); title = t; setOpaque(false);
            setBorder(BorderFactory.createEmptyBorder(t == null ? 6 : 32, 10, 10, 10));
        }
        @Override protected void paintComponent(Graphics g0) {
            Graphics2D g = (Graphics2D) g0.create(); aa(g);
            int w = getWidth(), h = getHeight();
            g.setPaint(new GradientPaint(0, 0, new Color(9, 32, 60, 235), 0, h, new Color(4, 16, 32, 235)));
            g.fillRect(0, 0, w, h);
            g.setColor(glow ? new Color(0, 200, 255, 210) : new Color(0, 110, 150, 150));
            g.setStroke(new BasicStroke(glow ? 2f : 1f));
            g.drawRect(0, 0, w - 1, h - 1);
            g.setColor(CYAN); g.setStroke(new BasicStroke(2f));
            g.drawLine(0, 0, 12, 0); g.drawLine(0, 0, 0, 12); g.drawLine(w - 1, 0, w - 13, 0); g.drawLine(w - 1, 0, w - 1, 12);
            g.drawLine(0, h - 1, 12, h - 1); g.drawLine(0, h - 1, 0, h - 13);
            g.drawLine(w - 1, h - 1, w - 13, h - 1); g.drawLine(w - 1, h - 1, w - 1, h - 13);
            if (title != null) {
                g.setFont(TITLE_FONT);
                g.setColor(CYAN); g.drawString(title, 12, 21);
                if (tag != null) {
                    g.setFont(new Font(SANS, Font.BOLD, 9)); g.setColor(tagColor);
                    g.drawString(tag, w - 12 - g.getFontMetrics().stringWidth(tag), 21);
                }
            }
            g.dispose();
        }
    }

    static class HintField extends JTextField {
        String hint;
        HintField(String h) { hint = h; setOpaque(false); setBorder(null); setForeground(TXT); setCaretColor(CYAN); }
        @Override protected void paintComponent(Graphics g0) {
            super.paintComponent(g0);
            if (getText().isEmpty()) {
                Graphics2D g = (Graphics2D) g0.create(); aa(g);
                g.setColor(DIM); g.setFont(getFont());
                FontMetrics fm = g.getFontMetrics();
                g.drawString(hint, getInsets().left, (getHeight() + fm.getAscent() - fm.getDescent()) / 2);
                g.dispose();
            }
        }
    }

    static class Item extends JComponent {
        String name, status; Color sc; Runnable act; boolean hover;
        Item(String n, String s, Color sc, Runnable act) {
            name = n; status = s; this.sc = sc; this.act = act;
            if (act != null) {
                setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
                addMouseListener(new MouseAdapter() {
                    @Override public void mouseEntered(MouseEvent e) { hover = true; repaint(); }
                    @Override public void mouseExited(MouseEvent e) { hover = false; repaint(); }
                    @Override public void mouseClicked(MouseEvent e) { Item.this.act.run(); }
                });
            }
        }
        void set(String s, Color c) { status = s; sc = c; repaint(); }
        @Override protected void paintComponent(Graphics g0) {
            Graphics2D g = (Graphics2D) g0.create(); aa(g);
            int w = getWidth(), h = getHeight();
            g.setColor(hover ? new Color(14, 56, 94) : new Color(9, 32, 58)); g.fillRoundRect(0, 0, w - 1, h - 1, 6, 6);
            g.setColor(hover ? CYAN : new Color(0, 85, 120)); g.drawRoundRect(0, 0, w - 1, h - 1, 6, 6);
            int bs = Math.min(26, h - 10), by = (h - bs) / 2;
            g.setColor(new Color(0, 200, 255, 120)); g.drawRoundRect(8, by, bs, bs, 6, 6);
            g.setColor(CYAN); g.fillOval(8 + bs / 2 - 3, by + bs / 2 - 3, 6, 6);
            g.setFont(new Font(SANS, Font.BOLD, 11)); g.setColor(TXT);
            int x = 8 + bs + 8;
            if (status == null) g.drawString(name, x, h / 2 + 4);
            else {
                g.drawString(name, x, h / 2 - 1);
                g.setFont(new Font(SANS, Font.PLAIN, 9)); g.setColor(sc); g.drawString(status, x, h / 2 + 11);
            }
            g.dispose();
        }
    }

    static class Chip extends JButton {
        boolean sel;
        Chip(String t) {
            super(t);
            setContentAreaFilled(false); setBorderPainted(false); setFocusPainted(false);
            setHorizontalAlignment(LEFT); setForeground(TXT); setFont(new Font(SANS, Font.PLAIN, 13));
            setBorder(BorderFactory.createEmptyBorder(9, 16, 9, 10));
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        }
        @Override protected void paintComponent(Graphics g0) {
            Graphics2D g = (Graphics2D) g0.create(); aa(g);
            if (sel) {
                g.setColor(new Color(0, 90, 140, 120)); g.fillRect(0, 0, getWidth(), getHeight());
                g.setColor(CYAN); g.fillRect(0, 0, 3, getHeight());
            } else if (getModel().isRollover()) { g.setColor(new Color(255, 255, 255, 18)); g.fillRect(0, 0, getWidth(), getHeight()); }
            g.dispose();
            super.paintComponent(g0);
        }
    }

    static class Ring extends JComponent {
        String name; double v, shown;
        Ring(String n) { name = n; }
        void set(double x) { v = Math.max(0, Math.min(1, x)); }
        void anim() { if (Math.abs(v - shown) > 0.001) { shown += (v - shown) * 0.12; repaint(); } }
        @Override protected void paintComponent(Graphics g0) {
            Graphics2D g = (Graphics2D) g0.create(); aa(g);
            int w = getWidth(), h = getHeight(), s = Math.max(20, Math.min(w - 10, h - 20)), x = (w - s) / 2, y = 2;
            g.setStroke(new BasicStroke(6f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
            g.setColor(new Color(10, 50, 80)); g.drawArc(x, y, s, s, 0, 360);
            g.setColor(shown > 0.85 ? RED : CYAN); g.drawArc(x, y, s, s, 90, (int) (-360 * shown));
            g.setFont(new Font(SANS, Font.BOLD, 12)); g.setColor(TXT);
            String t = (int) Math.round(shown * 100) + "%";
            g.drawString(t, w / 2 - g.getFontMetrics().stringWidth(t) / 2, y + s / 2 + 4);
            g.setFont(new Font(SANS, Font.BOLD, 9)); g.setColor(DIM);
            g.drawString(name, w / 2 - g.getFontMetrics().stringWidth(name) / 2, h - 3);
            g.dispose();
        }
    }

    static class Timeline extends JComponent {
        java.util.LinkedList<String[]> items = new java.util.LinkedList<>();
        void push(String cmd) {
            items.addFirst(new String[]{new SimpleDateFormat("HH:mm").format(new Date()), cmd});
            while (items.size() > 4) items.removeLast();
            repaint();
        }
        @Override protected void paintComponent(Graphics g0) {
            Graphics2D g = (Graphics2D) g0.create(); aa(g);
            int w = getWidth(), y = 14, i = 0;
            for (String[] it : items) {
                g.setColor(i == 0 ? CYAN : new Color(0, 150, 200)); g.fillOval(2, y - 4, 7, 7);
                g.setFont(new Font(SANS, Font.PLAIN, 11)); g.setColor(TXT);
                FontMetrics fm = g.getFontMetrics();
                String t = it[1];
                while (t.length() > 3 && fm.stringWidth(t) > w - 70) t = t.substring(0, t.length() - 2) + "…";
                g.drawString(t, 18, y + 3);
                g.setColor(DIM); g.setFont(new Font(SANS, Font.PLAIN, 10));
                g.drawString(it[0], w - g.getFontMetrics().stringWidth(it[0]) - 2, y + 3);
                g.setColor(new Color(0, 150, 200, i == 0 ? 190 : 80)); g.drawLine(18, y + 10, w - 4, y + 10);
                y += 27; i++;
            }
            g.dispose();
        }
    }

    static class MemPanel extends JComponent {
        String a = "—", b = "—", c = "—";
        double[][] pts = new double[14][2];
        MemPanel() { java.util.Random r = new java.util.Random(7); for (double[] p : pts) { p[0] = r.nextDouble(); p[1] = r.nextDouble(); } }
        @Override protected void paintComponent(Graphics g0) {
            Graphics2D g = (Graphics2D) g0.create(); aa(g);
            int w = getWidth(), h = getHeight(), mw = (int) (w * 0.55);
            g.setColor(new Color(0, 160, 220, 90));
            for (int i = 1; i < pts.length; i++)
                g.drawLine((int) (pts[i - 1][0] * mw), (int) (pts[i - 1][1] * (h - 10)) + 5, (int) (pts[i][0] * mw), (int) (pts[i][1] * (h - 10)) + 5);
            g.setColor(new Color(170, 235, 255));
            for (double[] p : pts) g.fillOval((int) (p[0] * mw) - 2, (int) (p[1] * (h - 10)) + 3, 5, 5);
            String[][] st = {{"RAM usada", a}, {"Procesos", b}, {"Sesión", c}};
            int y = 12;
            for (String[] s : st) {
                g.setFont(new Font(SANS, Font.PLAIN, 9)); g.setColor(DIM); g.drawString(s[0], mw + 14, y);
                g.setFont(new Font(SANS, Font.BOLD, 14)); g.setColor(TXT); g.drawString(s[1], mw + 14, y + 16);
                y += Math.max(30, (h - 20) / 3);
            }
            g.dispose();
        }
    }

    static class VoiceCard extends JComponent {
        double a; volatile double level; boolean on; Runnable act;
        VoiceCard() {
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            addMouseListener(new MouseAdapter() { @Override public void mouseClicked(MouseEvent e) { if (act != null) act.run(); } });
        }
        void step() { a += 0.24; repaint(); }
        @Override protected void paintComponent(Graphics g0) {
            Graphics2D g = (Graphics2D) g0.create(); aa(g);
            int w = getWidth(), h = getHeight(), n = 30, bw = Math.max(3, (w - 4) / n);
            for (int i = 0; i < n; i++) {
                int hh = Math.min(36, 3 + (int) ((0.5 + 0.5 * Math.sin(a + i * 0.55)) * 16 * (0.6 + 0.4 * Math.sin(a * 0.7 + i)) * (on ? 0.15 + Math.min(1.8, level * 9) : 1)));
                g.setColor(new Color(0, 200, 255, 160)); g.fillRect(2 + i * bw, 18 - hh / 2, bw - 1, hh);
            }
            int cx = w / 2, cy = h / 2 + 12, R = 28;
            g.setColor(new Color(6, 40, 75)); g.fillOval(cx - R, cy - R, 2 * R, 2 * R);
            g.setColor(on ? GREEN : CYAN); g.setStroke(new BasicStroke(2f)); g.drawOval(cx - R, cy - R, 2 * R, 2 * R);
            g.fillRoundRect(cx - 5, cy - 13, 10, 17, 10, 10);
            g.setStroke(new BasicStroke(1.6f)); g.drawArc(cx - 9, cy - 9, 18, 18, 200, 140); g.drawLine(cx, cy + 9, cx, cy + 13);
            g.setFont(new Font(SANS, Font.PLAIN, 9)); g.setColor(DIM);
            String t = on ? "Listening…" : "Tap to listen";
            g.drawString(t, cx - g.getFontMetrics().stringWidth(t) / 2, h - 3);
            g.dispose();
        }
    }

    static class SendBtn extends JButton {
        SendBtn() {
            setContentAreaFilled(false); setBorderPainted(false); setFocusPainted(false);
            setPreferredSize(new Dimension(44, 44));
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        }
        @Override protected void paintComponent(Graphics g0) {
            Graphics2D g = (Graphics2D) g0.create(); aa(g);
            g.setPaint(new GradientPaint(0, 0, VIOLET, getWidth(), getHeight(), CYAN));
            g.fillOval(0, 0, getWidth() - 1, getHeight() - 1);
            g.setColor(Color.WHITE); g.setStroke(new BasicStroke(2.4f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
            int cx = getWidth() / 2, cy = getHeight() / 2;
            g.drawLine(cx, cy + 7, cx, cy - 7); g.drawLine(cx, cy - 7, cx - 6, cy - 1); g.drawLine(cx, cy - 7, cx + 6, cy - 1);
            g.dispose();
        }
    }

    static class Orb extends JComponent {
        double a; double[][] st = new double[45][3];
        java.awt.image.BufferedImage cache; int cw, ch;
        Orb() { java.util.Random r = new java.util.Random(3); for (double[] s : st) { s[0] = r.nextDouble() * 6.28; s[1] = r.nextDouble(); s[2] = 0.2 + r.nextDouble() * 0.8; } }
        void step() { a += 0.04; repaint(); }
        void build(int w, int h) {
            cache = new java.awt.image.BufferedImage(w, h, java.awt.image.BufferedImage.TYPE_INT_ARGB);
            Graphics2D g = cache.createGraphics(); aa(g);
            int cx = w / 2, cy = h / 2, r = Math.max(60, Math.min(cx, cy) - 30), gr = (int) (r * 1.3);
            g.setPaint(new RadialGradientPaint(cx, cy, gr, new float[]{0f, 0.6f, 1f},
                    new Color[]{new Color(0, 150, 220, 110), new Color(0, 70, 140, 60), new Color(0, 0, 0, 0)}));
            g.fillOval(cx - gr, cy - gr, 2 * gr, 2 * gr);
            g.setPaint(new RadialGradientPaint(cx - r / 3f, cy - r / 3f, r * 1.4f, new float[]{0f, 1f},
                    new Color[]{new Color(30, 120, 190, 150), new Color(2, 18, 40, 235)}));
            g.fillOval(cx - r, cy - r, 2 * r, 2 * r);
            g.setColor(CYAN); g.setStroke(new BasicStroke(1.6f)); g.drawOval(cx - r, cy - r, 2 * r, 2 * r);
            g.dispose(); cw = w; ch = h;
        }
        @Override protected void paintComponent(Graphics g0) {
            if (getWidth() < 10 || getHeight() < 10) return;
            if (cache == null || cw != getWidth() || ch != getHeight()) build(getWidth(), getHeight());
            Graphics2D g = (Graphics2D) g0.create(); aa(g);
            g.drawImage(cache, 0, 0, null);
            int cx = getWidth() / 2, cy = getHeight() / 2, r = Math.max(60, Math.min(cx, cy) - 30);
            g.setStroke(new BasicStroke(1.2f));
            for (int i = 0; i < 5; i++) {
                AffineTransform old = g.getTransform();
                g.rotate(a * (i % 2 == 0 ? 1 : -1) + i * 0.7, cx, cy);
                g.setColor(new Color(0, 200, 255, 100));
                double hh = r * (0.3 + 0.14 * i);
                g.draw(new Ellipse2D.Double(cx - r, cy - hh, 2 * r, 2 * hh));
                g.setTransform(old);
            }
            g.setColor(new Color(160, 235, 255));
            for (double[] s : st) {
                double ang = s[0] + a * s[2], rad = r * (0.35 + 0.8 * s[1]);
                g.fillOval((int) (cx + Math.cos(ang) * rad * 1.25) - 2, (int) (cy + Math.sin(ang) * rad * 0.5) - 2, 4, 4);
            }
            g.setFont(new Font(SANS, Font.BOLD, Math.max(24, r / 4))); g.setColor(CYAN);
            String t = "J A R V I S";
            g.drawString(t, cx - g.getFontMetrics().stringWidth(t) / 2, cy + 8);
            g.setFont(new Font(SANS, Font.BOLD, Math.max(11, r / 14))); g.setColor(TXT);
            t = "A I   C O R E";
            g.drawString(t, cx - g.getFontMetrics().stringWidth(t) / 2, cy + 34);
            g.setFont(new Font(SANS, Font.PLAIN, 10)); g.setColor(DIM);
            t = "v3.0";
            g.drawString(t, cx - g.getFontMetrics().stringWidth(t) / 2, cy + 52);
            g.dispose();
        }
    }

    static class ChatPanel extends JPanel implements Scrollable {
        ChatPanel() { setOpaque(false); setLayout(new BoxLayout(this, BoxLayout.Y_AXIS)); }
        void clear() { removeAll(); revalidate(); repaint(); }
        public Dimension getPreferredScrollableViewportSize() { return getPreferredSize(); }
        public int getScrollableUnitIncrement(Rectangle r, int o, int d) { return 16; }
        public int getScrollableBlockIncrement(Rectangle r, int o, int d) { return 80; }
        public boolean getScrollableTracksViewportWidth() { return true; }
        public boolean getScrollableTracksViewportHeight() { return false; }
    }

    /** kind: 0 = comando del usuario, 1 = respuesta, 2 = error */
    static class Bubble extends JPanel {
        int kind, maxW; JTextArea ta = new JTextArea();
        Bubble(String text, int kind, int maxW) {
            super(new BorderLayout()); this.kind = kind; this.maxW = maxW; setOpaque(false);
            ta.setText(text); ta.setEditable(false); ta.setOpaque(false); ta.setBorder(null);
            ta.setLineWrap(true); ta.setWrapStyleWord(true);
            ta.setForeground(kind == 2 ? new Color(255, 170, 175) : TXT);
            ta.setFont(kind == 0 ? new Font(SANS, Font.BOLD, 12) : new Font("Monospaced", Font.PLAIN, 12));
            setBorder(BorderFactory.createEmptyBorder(8, 14, 8, 40));
            add(ta);
        }
        @Override public Dimension getPreferredSize() {
            Insets in = getInsets();
            ta.setSize(maxW - in.left - in.right, Short.MAX_VALUE);
            return new Dimension(maxW, ta.getPreferredSize().height + in.top + in.bottom);
        }
        @Override protected void paintComponent(Graphics g0) {
            Graphics2D g = (Graphics2D) g0.create(); aa(g);
            Color bar = kind == 0 ? CYAN : kind == 2 ? RED : GREEN;
            g.setColor(kind == 0 ? new Color(0, 70, 105, 200) : kind == 2 ? new Color(70, 20, 30, 220) : new Color(10, 34, 60, 230));
            g.fillRect(0, 0, getWidth(), getHeight());
            g.setColor(bar); g.fillRect(0, 0, 3, getHeight());
            g.setFont(new Font(SANS, Font.BOLD, 8));
            String t = kind == 0 ? "CMD" : kind == 2 ? "WARN" : "INFO";
            g.drawString(t, getWidth() - 8 - g.getFontMetrics().stringWidth(t), 13);
            g.dispose();
        }
    }

    static class SlimBar extends javax.swing.plaf.basic.BasicScrollBarUI {
        @Override protected void configureScrollBarColors() { thumbColor = new Color(0, 200, 255, 90); }
        JButton zero() { JButton b = new JButton(); b.setPreferredSize(new Dimension(0, 0)); return b; }
        @Override protected JButton createDecreaseButton(int o) { return zero(); }
        @Override protected JButton createIncreaseButton(int o) { return zero(); }
        @Override protected void paintTrack(Graphics g, JComponent c, Rectangle r) { }
        @Override protected void paintThumb(Graphics g0, JComponent c, Rectangle r) {
            Graphics2D g = (Graphics2D) g0.create(); aa(g);
            g.setColor(thumbColor); g.fillRoundRect(r.x + 1, r.y, r.width - 2, r.height, 6, 6);
            g.dispose();
        }
    }

    public static void main(String[] args) {
        System.setProperty("awt.useSystemAAFontSettings", "on");
        System.setProperty("swing.aatext", "true");
        SwingUtilities.invokeLater(() -> {
            Jarvis j = new Jarvis();
            if (!j.login()) System.exit(0);
            j.unlock(true);
            j.setVisible(true);
            j.input.requestFocusInWindow();
        });
    }
}
