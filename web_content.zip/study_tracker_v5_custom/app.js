const USERS_KEY='studyTrackerUsersV3', SESSION_KEY='studyTrackerCurrentV3';
const classSubjects={
 "8":["English","Urdu","Mathematics","General Science","Computer Science","Islamiat","Social Studies"],
 "9":{
   "Science":["English","Urdu","Mathematics","Physics","Chemistry","Computer Science","Islamiat","Pakistan Studies"],
   "Biology":["English","Urdu","Mathematics","Physics","Chemistry","Biology","Islamiat","Pakistan Studies"],
   "Arts":["English","Urdu","General Mathematics","General Science","Computer Science","Islamiat","Pakistan Studies","Arts Elective"]
 },
 "10":{
   "Science":["English","Urdu","Mathematics","Physics","Chemistry","Computer Science","Islamiat","Pakistan Studies"],
   "Biology":["English","Urdu","Mathematics","Physics","Chemistry","Biology","Islamiat","Pakistan Studies"],
   "Arts":["English","Urdu","General Mathematics","General Science","Computer Science","Islamiat","Pakistan Studies","Arts Elective"]
 }};
let users=JSON.parse(localStorage.getItem(USERS_KEY)||'{}');
let current=localStorage.getItem(SESSION_KEY);
let state=null, remaining=1500,running=false,interval=null;

const $=id=>document.getElementById(id);
function subjectsFor(cls,stream){return cls==="8"?classSubjects["8"]:(classSubjects[cls][stream]||[])}
function saveUsers(){localStorage.setItem(USERS_KEY,JSON.stringify(users))}
function save(){if(!state)return;users[state.account].data=state;saveUsers();render()}
function updateSubjectChoices(){
 const cls=$('classSelect').value;
 $('streamBox').classList.toggle('hidden',!cls||cls==="8");
 $('subjectsBox').classList.toggle('hidden',!cls);
 const stream=$('streamSelect').value;
 const list=subjectsFor(cls,stream);
 $('subjectChoices').innerHTML=list.map((s,i)=>`<label class="choice"><input type="checkbox" value="${escapeHtml(s)}" ${i<list.length?'checked':''}>${escapeHtml(s)}</label>`).join('');
 if(cls==="8")$('subjectsBox').classList.add('hidden');
}
$('classSelect').onchange=updateSubjectChoices;
$('streamSelect').onchange=updateSubjectChoices;
let loginMode=false;
$('switchAuth').onclick=()=>{
 loginMode=!loginMode;
 $('authTitle').textContent=loginMode?'Log in':'Create your account';
 $('authSub').textContent=loginMode?'Enter your account details.':'Set up your student profile to continue.';
 $('authBtn').textContent=loginMode?'Log In':'Create Account';
 $('profileFields').classList.toggle('hidden',loginMode);
 $('switchAuth').textContent=loginMode?'New student? Create an account':'Already have an account? Log in';
};
$('authForm').onsubmit=e=>{
 e.preventDefault();
 const account=$('email').value.trim().toLowerCase(),pass=$('password').value;
 if(loginMode){
   if(!users[account]||users[account].password!==pass){alert('Wrong username/email or password.');return}
   state=users[account].data;current=account;localStorage.setItem(SESSION_KEY,current);showApp();return;
 }
 const cls=$('classSelect').value,stream=$('streamSelect').value;
 if(users[account]){alert('Account already exists. Please log in.');return}
 if(!cls||(cls!=="8"&&!stream)){alert('Please choose your class and group.');return}
 const selected=cls==="8"?classSubjects["8"]:[...document.querySelectorAll('#subjectChoices input:checked')].map(x=>x.value);
 if(!selected.length){alert('Please select at least one subject.');return}
 state={account,password:pass,profile:{class:cls,stream:cls==="8"?"":stream,subjects:selected},xp:0,tasks:[],sessions:[],theme:'light',dailyGoal:2,goals:[],notes:'',reminders:[],tests:[],mathSolved:0};
 users[account]={password:pass,data:state};saveUsers();current=account;localStorage.setItem(SESSION_KEY,current);showApp();
};
function showApp(){$('authView').classList.add('hidden');$('appView').classList.remove('hidden');render()}
function logout(){localStorage.removeItem(SESSION_KEY);current=null;state=null;running=false;clearInterval(interval);$('appView').classList.add('hidden');$('authView').classList.remove('hidden')}
$('logoutBtn').onclick=logout;
function today(){return new Date().toISOString().slice(0,10)}
function fmt(s){return `${String(Math.floor(s/60)).padStart(2,'0')}:${String(s%60).padStart(2,'0')}`}
function levelInfo(xp){
  xp=Math.max(0,Number(xp)||0);
  let level=Math.floor(xp/100)+1;
  const ranks=[
    {name:'Freshers',min:0},
    {name:'Learner',min:100},
    {name:'Scholar',min:300},
    {name:'Expert',min:700},
    {name:'Master',min:1200},
    {name:'Elite',min:2000}
  ];
  let rank=ranks[0],next=null;
  for(let i=0;i<ranks.length;i++){if(xp>=ranks[i].min){rank=ranks[i];next=ranks[i+1]||null}}
  return {level,current:xp%100,rank:rank.name,rankMin:rank.min,nextRank:next,rankPercent:next?Math.min(100,Math.round((xp-rank.min)/(next.min-rank.min)*100)):100};
}
function showToast(text){let t=document.getElementById('toast');if(!t){t=document.createElement('div');t.id='toast';document.body.appendChild(t)}t.textContent=text;t.className='toast show';clearTimeout(window.tt);window.tt=setTimeout(()=>t.className='toast',1800)}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]))}
function calcStreak(){const dates=[...new Set(state.sessions.map(x=>x.date))].sort().reverse();if(!dates.length)return 0;let d=new Date(),n=0;for(const date of dates){if(date!==d.toISOString().slice(0,10))break;n++;d.setDate(d.getDate()-1)}return n}

function changeXP(amount,reason){
  const before=state.xp;
  state.xp=Math.max(0,state.xp+amount);
  save();
  const delta=state.xp-before;
  showToast((delta>=0?'+':'')+delta+' XP — '+reason);
}
function renderRankPanel(li){
  if($('rankBadge'))$('rankBadge').textContent=li.rank;
  if($('rankProgress')){
    $('rankProgress').innerHTML='<div style="width:'+li.rankPercent+'%"></div>';
    const next=li.nextRank?('Next: '+li.nextRank.name+' at '+li.nextRank.min+' XP'):'Top rank reached — Elite 👑';
    $('rankProgress').title=next;
  }
}
function render(){
 if(!state)return;
 document.body.classList.toggle('dark',state.theme==='dark');$('themeBtn').textContent=state.theme==='dark'?'☀️':'🌙';
 const p=state.profile,li=levelInfo(state.xp);$('welcome').textContent=`Welcome back, ${state.account.split('@')[0]} 👋`;
 $('profileSummary').textContent=`Class ${p.class}${p.stream?' • '+p.stream:''}`;
 $('level').textContent=li.level;$('rank').textContent=li.rank;$('totalXP').textContent=state.xp;$('xpFill').style.width=li.current+'%';$('xpText').textContent=`${li.current} / 100 XP to Level ${li.level+1}`;renderRankPanel(li);$('timer').textContent=fmt(remaining);
 const ts=state.sessions.filter(x=>x.date===today());$('todayHours').textContent=(ts.reduce((a,x)=>a+x.minutes,0)/60).toFixed(1)+'h';$('tasksDone').textContent=state.tasks.filter(x=>x.done).length;$('streak').textContent=calcStreak()+' 🔥'; renderExtras();
 $('subjectList').innerHTML=p.subjects.map(s=>`<div class="subject"><strong>${escapeHtml(s)}</strong><small>Ready to track</small></div>`).join('');
 $('taskSubject').innerHTML=p.subjects.map(s=>`<option>${escapeHtml(s)}</option>`).join('');
 $('taskList').innerHTML=state.tasks.length?state.tasks.map((t,i)=>`<li class="task"><input type="checkbox" ${t.done?'checked':''} onchange="toggleTask(${i})"><label class="${t.done?'done':''}">${escapeHtml(t.text)} <small>• ${escapeHtml(t.subject||'General')}</small></label><button class="delete" onclick="deleteTask(${i})">✕</button></li>`).join(''):'<li class="empty">No tasks yet.</li>';
 $('logList').innerHTML=ts.length?ts.slice().reverse().map(x=>`<div class="log"><span>${x.minutes} min • ${escapeHtml(x.subject||'Study')}</span><span>${x.time}</span></div>`).join(''):'<div class="empty">No completed sessions today.</div>';
}
window.toggleTask=i=>{let t=state.tasks[i];if(!t.done){t.done=true;state.xp+=10;let count=state.tasks.filter(x=>x.done).length;if(count===5)state.xp+=50;save();showToast(count===5?'+60 XP — Task + daily bonus 🎯':'+10 XP — Task completed ✅')}else{t.done=false;save()}}
window.deleteTask=i=>{state.tasks.splice(i,1);save()};
$('taskForm').onsubmit=e=>{e.preventDefault();state.tasks.push({text:$('taskInput').value.trim(),subject:$('taskSubject').value,done:false});$('taskInput').value='';save()};
$('clearDoneBtn').onclick=()=>{state.tasks=state.tasks.filter(t=>!t.done);save()};
$('themeBtn').onclick=()=>{state.theme=state.theme==='dark'?'light':'dark';save()};
$('startBtn').onclick=()=>{if(running)return;running=true;interval=setInterval(()=>{remaining--;if(remaining<=0){state.sessions.push({date:today(),minutes:25,subject:$('taskSubject').value,time:new Date().toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'})});state.xp+=25;save();showToast('+25 XP — Study session complete 🎉');resetTimer()}render()},1000)};
$('pauseBtn').onclick=()=>{running=false;clearInterval(interval)};
$('resetBtn').onclick=resetTimer;
function resetTimer(){running=false;clearInterval(interval);remaining=1500;render()}

function dateKey(d){return new Date(d).toISOString().slice(0,10)}
function studyMinutes(date){return state.sessions.filter(x=>x.date===date).reduce((a,x)=>a+x.minutes,0)}
function renderExtras(){
  const mins=studyMinutes(today()), goal=Number(state.dailyGoal||2)*60, pct=Math.min(100,Math.round(mins/goal*100));
  $('goalHours').textContent=Number(state.dailyGoal||2).toFixed(1);$('goalFill').style.width=pct+'%';$('goalProgress').textContent=pct+'%';$('goalRemaining').textContent=Math.max(0,(goal-mins)/60).toFixed(1)+'h left';
  $('notes').value=state.notes||'';
  renderAchievements();renderCalendar();renderChart();renderGoals();renderReminders();
}
function renderAchievements(){
  const done=state.tasks.filter(x=>x.done).length, sessions=state.sessions.length, xp=state.xp, streak=calcStreak();
  const a=[['🌱','First Task',done>=1],['⏱️','First Session',sessions>=1],['⭐','100 XP',xp>=100],['🔥','3 Day Streak',streak>=3],['🏅','10 Tasks',done>=10],['🎓','500 XP',xp>=500]];
  $('achievements').innerHTML=a.map(x=>`<div class="badge ${x[2]?'':'locked'}">${x[0]} ${x[1]}</div>`).join('');
}
function renderCalendar(){
  const el=$('calendar'), now=new Date(), days=[];
  ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'].forEach(x=>days.push(`<div class="cal-head">${x}</div>`));
  const first=new Date(now.getFullYear(),now.getMonth(),1).getDay();
  for(let i=0;i<first;i++)days.push('<div></div>');
  const total=new Date(now.getFullYear(),now.getMonth()+1,0).getDate();
  for(let d=1;d<=total;d++){const dt=new Date(now.getFullYear(),now.getMonth(),d),key=dateKey(dt),m=studyMinutes(key);days.push(`<div class="cal-day ${m?'active':''} ${key===today()?'today':''}"><b>${d}</b>${m?m+'m':''}</div>`)}
  el.innerHTML=days.join('');
}
function renderChart(){
  const n=Number($('chartRange').value), el=$('analyticsChart'), rows=[];
  for(let i=n-1;i>=0;i--){const d=new Date();d.setDate(d.getDate()-i);const key=dateKey(d);rows.push({key,mins:studyMinutes(key),label:d.toLocaleDateString([], {month:'short',day:'numeric'})})}
  const max=Math.max(60,...rows.map(x=>x.mins));
  el.innerHTML=rows.map(x=>`<div class="bar-wrap"><span class="bar-value">${x.mins?Math.round(x.mins/60*10)/10+'h':''}</span><div class="bar" style="height:${Math.max(2,x.mins/max*100)}%"></div><span class="bar-label">${x.label}</span></div>`).join('');
}
function renderGoals(){
  const el=$('goalsList');el.innerHTML=state.goals.length?state.goals.map((g,i)=>`<div class="goal-item"><div><b>${escapeHtml(g.title)}</b><small>${escapeHtml(g.type)} • ${escapeHtml(g.target)}</small></div><button onclick="deleteGoal(${i})">✕</button></div>`).join(''):'<div class="empty-box">No goals yet.</div>';
}
function renderReminders(){
  const el=$('remindersList');el.innerHTML=state.reminders.length?state.reminders.map((r,i)=>`<div class="reminder"><b>${escapeHtml(r.title)}</b><small>${escapeHtml(r.time)}</small><button onclick="deleteReminder(${i})">Remove</button></div>`).join(''):'<div class="empty-box">No reminders yet.</div>';
}
$('editGoalBtn').onclick=()=>{const v=prompt('Daily study goal in hours:',state.dailyGoal||2);if(v!==null&&Number(v)>0){state.dailyGoal=Number(v);save()}};
$('addGoalBtn').onclick=()=>{const title=prompt('Goal name (e.g. Finish Algebra)');if(!title)return;const type=prompt('Goal type: Hours / Chapters / Exam','Chapters')||'Chapters';const target=prompt('Target or deadline (e.g. 8 chapters or 20 Sep)')||'';state.goals.push({title,type,target});save()};
window.deleteGoal=i=>{state.goals.splice(i,1);save()};
$('saveNotesBtn').onclick=()=>{state.notes=$('notes').value;save();showToast('Notes saved 📝')};
$('addReminderBtn').onclick=async()=>{const title=prompt('Reminder name');if(!title)return;const time=prompt('Time (e.g. 18:00)','18:00');if(!time)return;state.reminders.push({title,time});save();if('Notification' in window&&Notification.permission==='default')await Notification.requestPermission();showToast('Reminder added 🔔')};
window.deleteReminder=i=>{state.reminders.splice(i,1);save()};
$('chartRange').onchange=renderChart;


// --- Math Solver ---
function fmtNumber(n){
  if(!Number.isFinite(n)) return String(n);
  const r=Math.round(n*1000000)/1000000;
  return String(r);
}
function solveMathProblem(raw){
  let s=String(raw||'').trim().replace(/−/g,'-').replace(/×/g,'*').replace(/÷/g,'/').replace(/²/g,'^2').replace(/³/g,'^3');
  if(!s) throw new Error('Please enter a maths problem.');
  const pct=s.match(/^(.+?)%\s*(?:of|×|\*)\s*(.+)$/i);
  if(pct){
    const a=Number(pct[1].trim()), b=Number(pct[2].trim());
    if(Number.isFinite(a)&&Number.isFinite(b)) return `${a}% of ${b} = ${fmtNumber(a*b/100)}`;
  }
  const eq=s.replace(/\s+/g,'');
  // Linear equation: ax+b=c
  let m=eq.match(/^([+-]?\d*\.?\d*)x([+-]\d*\.?\d+)?=([+-]?\d*\.?\d+)$/i);
  if(m){
    let a=m[1]; a=(a===''||a==='+')?1:(a==='-'?-1:Number(a));
    const b=m[2]?Number(m[2]):0, c=Number(m[3]);
    if(a===0) throw new Error('This equation has no unique x.');
    const x=(c-b)/a;
    return `x = ${fmtNumber(x)}\nCheck: ${fmtNumber(a)}x ${b>=0?'+ ':''}${fmtNumber(b)} = ${fmtNumber(c)}`;
  }
  // Quadratic: ax^2+bx+c=0
  m=eq.match(/^([+-]?\d*\.?\d*)x\^2([+-]\d*\.?\d*)x([+-]\d*\.?\d+)=0$/i);
  if(m){
    let a=m[1]; a=(a===''||a==='+')?1:(a==='-'?-1:Number(a));
    let b=m[2]; b=(b===''||b==='+')?1:(b==='-'?-1:Number(b));
    b=Number(b); const c=Number(m[3]), d=b*b-4*a*c;
    if(d<0) return `No real roots.\nDiscriminant = ${fmtNumber(d)}`;
    const r=Math.sqrt(d), x1=(-b+r)/(2*a), x2=(-b-r)/(2*a);
    return `x₁ = ${fmtNumber(x1)}\nx₂ = ${fmtNumber(x2)}\nDiscriminant = ${fmtNumber(d)}`;
  }
  // Arithmetic expression: allow only safe mathematical characters/functions.
  let expr=eq.replace(/\^/g,'**').replace(/sqrt\(/gi,'Math.sqrt(');
  if(!/^[0-9+\-*/().\s%a-zA-Z]+$/.test(expr) || /(?:constructor|prototype|window|document|global|eval|function|=>)/i.test(expr))
    throw new Error('I could not understand this problem. Try a basic expression or equation.');
  expr=expr.replace(/%/g,'/100');
  if(!/^(?:Math\.sqrt\(|[0-9+\-*/().\s]|Math)+$/.test(expr)) throw new Error('Use numbers, +, −, ×, ÷, %, sqrt(), or an equation with x.');
  const value=Function('"use strict";return ('+expr+')')();
  if(typeof value!=='number'||!Number.isFinite(value)) throw new Error('No finite answer found.');
  return `Answer = ${fmtNumber(value)}`;
}
$('solveMathBtn').onclick=()=>{
  try{
    const ans=solveMathProblem($('mathProblem').value);
    state.mathSolved=(state.mathSolved||0)+1;
    state.xp+=5;
    save();
    $('mathAnswer').className='solver-answer success';
    $('mathAnswer').textContent=ans+'\n+5 XP for using the solver';
  }catch(err){
    $('mathAnswer').className='solver-answer error';
    $('mathAnswer').textContent='Could not solve: '+err.message;
  }
};

// --- Test Session ---
const questionBank=[
 {keys:['math','algebra','linear','equation'],q:'Solve: 2x + 5 = 15',a:['5'],e:'x = 5'},
 {keys:['math','algebra'],q:'Solve: x² - 5x + 6 = 0. Give the two roots.',a:['2,3','3,2','2 3','3 2'],e:'x = 2 or x = 3'},
 {keys:['math','percentage','percent'],q:'What is 20% of 250?',a:['50'],e:'50'},
 {keys:['math','fraction','fractions'],q:'Calculate: 3/4 + 1/2',a:['1.25','5/4','1 1/4'],e:'5/4 = 1.25'},
 {keys:['math','arithmetic'],q:'Calculate: 25 + 17 × 3',a:['76'],e:'76'},
 {keys:['math','geometry'],q:'What is the area of a rectangle with length 8 and width 5?',a:['40','40 cm2','40 cm²'],e:'40 square units'},
 {keys:['physics'],q:'What is the SI unit of force?',a:['newton','n','newtons'],e:'Newton (N)'},
 {keys:['physics'],q:'What is the approximate acceleration due to gravity on Earth?',a:['9.8','9.8 m/s2','9.8 m/s²','10'],e:'About 9.8 m/s²'},
 {keys:['chemistry'],q:'What is the chemical symbol for sodium?',a:['na'],e:'Na'},
 {keys:['chemistry'],q:'What is the pH of a neutral solution at room temperature?',a:['7'],e:'7'},
 {keys:['biology'],q:'What organ pumps blood around the human body?',a:['heart'],e:'The heart'},
 {keys:['biology'],q:'What is the basic unit of life?',a:['cell','a cell'],e:'The cell'},
 {keys:['computer','computers','cs'],q:'What does CPU stand for?',a:['central processing unit'],e:'Central Processing Unit'},
 {keys:['computer','computers','cs'],q:'What does RAM stand for?',a:['random access memory'],e:'Random Access Memory'},
 {keys:['english'],q:'What is the past tense of “go”?',a:['went'],e:'Went'},
 {keys:['english'],q:'What is a noun?',a:['a person place thing','person place thing'],e:'A word naming a person, place, thing, or idea'},
 {keys:['islam','islamiat'],q:'How many obligatory prayers are there each day in Islam?',a:['5','five'],e:'Five'},
 {keys:['pakistan','pak studies','pakistan studies'],q:'What is the capital of Pakistan?',a:['islamabad'],e:'Islamabad'}
];
let testState=null;
function normalizeAnswer(x){return String(x||'').toLowerCase().trim().replace(/[“”"']/g,'').replace(/\s+/g,' ').replace(/²/g,'2')}
function buildTestQuestions(topic,count){
  const t=topic.toLowerCase();
  let pool=questionBank.filter(x=>x.keys.some(k=>t.includes(k)||k.includes(t)));
  if(!pool.length) pool=questionBank.filter(x=>x.keys.includes('math'));
  pool=[...pool].sort(()=>Math.random()-0.5);
  const out=[];
  while(out.length<count) out.push(pool[out.length%pool.length]);
  return out;
}
function showTestQuestion(){
  if(!testState)return;
  if(testState.index>=testState.questions.length){finishTest();return}
  const q=testState.questions[testState.index];
  $('testQuestion').textContent=q.q;
  $('testAnswer').value='';
  $('testProgress').textContent=`Question ${testState.index+1} / ${testState.questions.length}`;
  $('testFeedback').textContent='';
  $('testAnswer').focus();
}
function finishTest(){
  const t=testState;
  const correct=t.correct, wrong=t.wrong, skipped=t.skipped;
  const earned=correct*20-wrong*10-skipped*5;
  state.xp=Math.max(0,state.xp+earned);
  state.tests=state.tests||[];
  state.tests.push({date:today(),topic:t.topic,total:t.questions.length,correct,wrong,skipped,xp:earned});
  save();
  $('testArea').classList.add('hidden');
  $('testResult').className='test-result';
  $('testResult').innerHTML=`<h3>Test Complete 🎓</h3><div>${correct} correct • ${wrong} wrong • ${skipped} skipped</div><div><b>${earned>=0?'+':''}${earned} XP</b> from this test</div>`;
  testState=null;
}
function answerTest(){
  if(!testState)return;
  const q=testState.questions[testState.index], raw=normalizeAnswer($('testAnswer').value);
  if(!raw){$('testFeedback').textContent='Enter an answer or use Skip.';return}
  const ok=q.a.map(normalizeAnswer).includes(raw);
  if(ok){testState.correct++;testState.last='Correct! +20 XP';$('testFeedback').textContent='✅ Correct! +20 XP';}
  else{testState.wrong++;testState.last='Wrong! -10 XP';$('testFeedback').textContent=`❌ Wrong! -10 XP • Answer: ${q.e}`;}
  testState.index++;
  setTimeout(showTestQuestion,700);
}
$('startTestBtn').onclick=()=>{
  const topic=$('testTopic').value.trim();
  if(!topic){showToast('Tell me what you studied first 📚');return}
  const count=Number($('testCount').value)||5;
  testState={topic,questions:buildTestQuestions(topic,count),index:0,correct:0,wrong:0,skipped:0};
  $('testTopicLabel').textContent='Topic: '+topic;
  $('testResult').className='hidden';
  $('testArea').classList.remove('hidden');
  showTestQuestion();
};
$('submitAnswerBtn').onclick=answerTest;
$('skipQuestionBtn').onclick=()=>{
  if(!testState)return;
  testState.skipped++;
  $('testFeedback').textContent='⏭️ Skipped! -5 XP';
  testState.index++;
  setTimeout(showTestQuestion,500);
};
$('testAnswer').addEventListener('keydown',e=>{if(e.key==='Enter')answerTest()});

if(current&&users[current]){
  state=users[current].data;
  state.dailyGoal??=2;state.goals??=[];state.notes??='';state.reminders??=[];
  state.tests??=[];state.mathSolved??=0;state.xp=Math.max(0,Number(state.xp)||0);
  saveUsers();showApp()
}

