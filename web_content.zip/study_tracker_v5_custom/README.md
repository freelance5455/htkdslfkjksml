# Study Tracker V4

Includes:
- Modern dashboard with daily goal, progress %, XP and streak
- Class 8-10 profile setup
- Class 9-10 Science/Biology/Arts streams and subjects
- Subject list and task subject tagging
- Pomodoro timer (25-minute session starter)
- Calendar with daily study activity
- Daily analytics chart (7/30 days)
- Goals (hours/chapters/exam target text)
- Tasks with subject and completion status
- XP/levels/ranks and achievements
- Notes
- Study reminders with browser notification permission prompt
- Dark/light mode
- Offline localStorage data

Important:
This is a frontend/offline prototype. The login stores credentials locally and is NOT secure production authentication. For a published app, use a secure backend, password hashing, sessions, and a real notification service.

- Math Problem Solver for arithmetic, percentages, linear equations, and quadratic equations
- XP-based rank ladder: Freshers → Learner → Scholar → Expert → Master → Elite
- Test Session: student enters what they studied and takes a generated quiz
- Test scoring: correct +20 XP, wrong -10 XP, skipped -5 XP
- Test history stored locally
- Backward-compatible migration for existing accounts
