'use strict';
/* HELP ME! 3D - script.js
   Sections: LANGUAGE · SAVE · AUDIO · 3D CORE · CHARACTERS · PROPS · ENVIRONMENT · LEVELS · GAME · SCREENS */

/* ===== LANGUAGE: add a language = add a block. Missing keys fall back to English. ===== */
const LANG = {
  en: { play: 'PLAY', language: 'LANGUAGE', settings: 'SETTINGS', achievements: 'ACHIEVEMENTS', help: 'HELP ME!', thanks: 'Thank you! ❤️', ahh: 'Ahh! Thank you!',
    oops: 'Oops!', again: 'Try again!', ohno: 'OH NO!', retry: 'TRY AGAIN', hint: 'Hint', music: 'Music', sound: 'Sound', voice: 'Voice', vib: 'Vibration',
    next: 'NEXT', back: 'BACK', super: 'SUPER HELPER! ❤️', all: '10 Levels Complete!', s_stuck: "I'm stuck!", s_thirst: "I'm thirsty!", s_wet: "I'm getting wet!",
    s_balloon: 'My balloon!', s_toy: 'My toy!', s_tangled: "I'm tangled!", s_mud: "I'm muddy!", s_cross: "I can't cross!",
    a1: 'First Helper', a2: 'Helping Hand', a3: 'Super Helper',
    ladder: 'Ladder', umbrella: 'Umbrella', ball: 'Ball', water: 'Water', book: 'Book', toy: 'Toy', camera: 'Camera', net: 'Catcher', bottle: 'Bottle',
    grabber: 'Grabber', cup: 'Cup', scissors: 'Scissors', sponge: 'Sponge', balloon: 'Balloon', pillow: 'Pillow', stones: 'Stones' },
  ur: { play: 'کھیلیں', language: 'زبان', settings: 'ترتیبات', achievements: 'کامیابیاں', help: 'میری مدد کرو!', thanks: 'شکریہ! ❤️', oops: 'اوہو!', again: 'پھر کوشش!',
    ohno: 'اوہ نہیں!', retry: 'دوبارہ', hint: 'اشارہ', next: 'آگے', back: 'واپس', ladder: 'سیڑھی', umbrella: 'چھتری', ball: 'گیند', water: 'پانی', book: 'کتاب', toy: 'کھلونا',
    camera: 'کیمرہ', scissors: 'قینچی', sponge: 'سپنج', balloon: 'غبارہ', pillow: 'تکیہ', cup: 'کپ', bottle: 'بوتل' }
};
const LANGS = { en: ['🇬🇧', 'English', 'en-US'], ur: ['🇵🇰', 'اردو', 'ur-PK'], es: ['🇪🇸', 'Español', 'es-ES'], fr: ['🇫🇷', 'Français', 'fr-FR'], de: ['🇩🇪', 'Deutsch', 'de-DE'],
  ar: ['🇸🇦', 'العربية', 'ar-SA'], hi: ['🇮🇳', 'हिन्दी', 'hi-IN'], pt: ['🇧🇷', 'Português', 'pt-BR'], zh: ['🇨🇳', '中文', 'zh-CN'], ja: ['🇯🇵', '日本語', 'ja-JP'], ko: ['🇰🇷', '한국어', 'ko-KR'] };

/* ===== SAVE ===== */
const S = Object.assign({ lang: 'en', done: [], coins: 0, score: 0, music: true, sfx: true, voice: true, vib: true }, JSON.parse(localStorage.getItem('helpme3d') || '{}'));
const save = () => localStorage.setItem('helpme3d', JSON.stringify(S));
const t = k => (LANG[S.lang] && LANG[S.lang][k]) || LANG.en[k] || k;
const $ = s => document.querySelector(s);

/* ===== AUDIO (WebAudio beeps + speechSynthesis voice) ===== */
let AC;
function tone(f, d = .15, type = 'sine', at = 0, vol = .12) {
  AC = AC || new (window.AudioContext || window.webkitAudioContext)();
  const o = AC.createOscillator(), g = AC.createGain(), T = AC.currentTime + at;
  o.type = type; o.frequency.value = f; g.gain.setValueAtTime(vol, T); g.gain.exponentialRampToValueAtTime(.001, T + d);
  o.connect(g); g.connect(AC.destination); o.start(T); o.stop(T + d);
}
function sfx(n) {
  if (!S.sfx) return;
  ({ tap: [[700, .06]], ok: [[523], [659], [784], [1046]], no: [[300, .25], [220, .3]], win: [[523], [659], [784], [1046], [1318, .4]] }[n] || []).forEach(([f, d], i) => tone(f, d || .16, n === 'no' ? 'sine' : 'triangle', i * .1));
}
function speak(x) {
  if (!S.voice || !window.speechSynthesis) return;
  speechSynthesis.cancel(); const u = new SpeechSynthesisUtterance(x); u.lang = LANGS[S.lang][2]; u.pitch = 1.3; speechSynthesis.speak(u);
}
const vib = ms => S.vib && navigator.vibrate && navigator.vibrate(ms);
let mi = 0, musicOn = false; const SC = [262, 330, 392, 440, 392, 330, 294, 349];
function startMusic() { if (musicOn) return; musicOn = true; setInterval(() => S.music && AC && tone(SC[mi++ % 8], .5, 'sine', 0, .035), 500); }

/* ===== 3D CORE ===== */
const R = new THREE.WebGLRenderer({ canvas: $('#c'), antialias: true });
R.setPixelRatio(Math.min(devicePixelRatio, 2)); R.shadowMap.enabled = true; R.shadowMap.type = THREE.PCFSoftShadowMap;
const scene = new THREE.Scene(), cam = new THREE.PerspectiveCamera(60, 1, .1, 80);
scene.add(new THREE.HemisphereLight(0xffffff, 0xffd9a8, .95));
const sun = new THREE.DirectionalLight(0xfff2d0, 1.1); sun.position.set(4, 9, 6); sun.castShadow = true; sun.shadow.mapSize.set(1024, 1024);
Object.assign(sun.shadow.camera, { left: -8, right: 8, top: 9, bottom: -4, near: 1, far: 30 }); scene.add(sun);
const env = new THREE.Group(); scene.add(env);
const camT = { p: new THREE.Vector3(0, 4, 10), l: new THREE.Vector3(0, 1.5, 0) }, look = new THREE.Vector3(0, 1.5, 0);
function resize() { R.setSize(innerWidth, innerHeight); cam.aspect = innerWidth / innerHeight; cam.fov = cam.aspect < .75 ? 66 : 50; cam.updateProjectionMatrix(); }
addEventListener('resize', resize); resize();

const M = (c, r = .55) => new THREE.MeshStandardMaterial({ color: c, roughness: r });
function mesh(geo, col, x = 0, y = 0, z = 0, sx = 1, sy = 1, sz = 1) {
  const m = new THREE.Mesh(geo, typeof col === 'number' ? M(col) : col); m.position.set(x, y, z); m.scale.set(sx, sy, sz); m.castShadow = m.receiveShadow = true; return m;
}
const SP = (r, c, ...a) => mesh(new THREE.SphereGeometry(r, 24, 16), c, ...a);
const BX = (w, h, d, c, ...a) => mesh(new THREE.BoxGeometry(w, h, d), c, ...a);
const CY = (rt, rb, h, c, ...a) => mesh(new THREE.CylinderGeometry(rt, rb, h, 20), c, ...a);
const TO = (r, tube, c, ...a) => mesh(new THREE.TorusGeometry(r, tube, 8, 24), c, ...a);

// tiny tween system (promises make level scripts read top-to-bottom)
const anims = [], ease = k => k * k * (3 - 2 * k), wait = ms => new Promise(r => setTimeout(r, ms));
const tw = (ms, fn) => new Promise(r => anims.push({ ms, fn, t: 0, r }));
function tick(dt) { for (let i = anims.length - 1; i >= 0; i--) { const a = anims[i]; a.t += dt * 1000; const k = Math.min(a.t / a.ms, 1); a.fn(k); if (k >= 1) { anims.splice(i, 1); a.r(); } } }
function moveTo(o, to, ms, hop = 0) { const s = o.position.clone(), e = new THREE.Vector3(...to); return tw(ms, k => { o.position.lerpVectors(s, e, ease(k)); o.position.y += Math.sin(k * Math.PI) * hop; }); }

/* ===== CHARACTERS (procedural 3D; swap makeChar for a GLTFLoader version when you have .glb files) ===== */
const PAL = { cat: [0xffab5e, 0xffe3c8], puppy: [0xe6b47a, 0xfff1dc], bunny: [0xffc6de, 0xffffff], panda: [0xffffff, 0x2b2b3a], chick: [0xffe45c, 0xfff4b0], bird: [0x6ec9ff, 0xdff4ff] };
function makeChar(type) {
  const [c, c2] = PAL[type], g = new THREE.Group(), k = new THREE.Group(); g.add(k);
  const u = g.userData = { type, k, mood: 'idle', ph: Math.random() * 6, eyes: [], brows: [], arms: [] };
  const dark = 0x2b2b3a, bird = type === 'chick' || type === 'bird';
  k.add(SP(1, c, 0, 1, 0, .95, 1, .85), SP(.68, c2, 0, .95, .6, 1, 1.05, .35));                 // body + belly
  const h = u.head = new THREE.Group(); h.position.set(0, 2.35, 0); k.add(h); h.add(SP(1.15, c, 0, 0, 0, 1.12, 1, 1)); // head
  [-1, 1].forEach(s => {
    if (type === 'panda') h.add(SP(.36, dark, s * .5, .08, .82, .9, 1.2, .5));                    // eye patches
    const e = new THREE.Group(); e.position.set(s * .5, .1, .92);                                  // big eyes
    e.add(SP(.32, 0xffffff, 0, 0, 0, 1, 1.15, .7), SP(.19, 0x2a2140, 0, 0, .14, 1, 1.1, .7), SP(.07, 0xffffff, .06, .08, .24)); h.add(e); u.eyes.push(e);
    const b = BX(.4, .07, .06, 0x5a4030, s * .5, .62, 1.0); h.add(b); u.brows.push(b);
    h.add(SP(.2, 0xff8fa8, s * .82, -.3, .8, 1, .7, .4));                                          // cheeks
    if (type === 'cat') { const ear = mesh(new THREE.ConeGeometry(.42, .85, 4), c, s * .75, 1.05, 0); ear.rotation.z = -s * .35; h.add(ear); }
    if (type === 'puppy') { const ear = SP(.38, 0x9a6634, s * 1.15, .1, 0, .7, 1.6, .9); ear.rotation.z = s * .25; h.add(ear); }
    if (type === 'bunny') { const ear = SP(.3, c, s * .48, 1.95, 0, .9, 2.7, .6); ear.rotation.z = -s * .12; h.add(ear, SP(.17, 0xff9ebd, s * .48, 1.95, .12, .7, 2.3, .3)); }
    if (type === 'panda') h.add(SP(.4, dark, s * .85, .9, -.1));
    const a = new THREE.Group(); a.position.set(s * .95, 1.55, .15); a.add(SP(.26, type === 'panda' ? dark : c, s * .1, -.45, 0, 1, 1.9, 1)); k.add(a); u.arms.push(a); // arms
    k.add(SP(.36, type === 'panda' ? dark : c, s * .5, .2, .4, 1, .65, 1.3));                      // feet
  });
  u.mouth = SP(.14, 0xc23b5a, 0, -.42, 1.06, 1.7, .8, .5); h.add(u.mouth);
  h.add(bird ? (() => { const b = mesh(new THREE.ConeGeometry(.2, .4, 12), 0xff9a2e, 0, -.15, 1.2); b.rotation.x = Math.PI / 2; return b; })() : SP(type === 'puppy' ? .16 : .09, type === 'puppy' ? 0x2a2140 : 0xff7d9a, 0, -.12, 1.14, 1.3, .9, .7));
  if (type === 'cat') { const tl = CY(.12, .1, 1.4, c, 0, 1, -1); tl.rotation.x = -.7; k.add(tl); }
  else k.add(SP(type === 'bunny' ? .28 : .2, type === 'bunny' ? 0xffffff : c, 0, .7, -.9, 1, 1, 1.2));
  g.scale.setScalar(.85); return g;
}
function animChar(g, tm) { // idle breathing + blinking + mood poses
  const u = g.userData, m = u.mood, p = tm + u.ph, k = u.k;
  u.head.rotation.set(m === 'drink' ? .55 + Math.sin(p * 9) * .1 : 0, Math.sin(p * .8) * .1, 0);
  const bl = (p % 3.4) > 3.3 ? .1 : 1; u.eyes.forEach(e => e.scale.y = bl);
  k.children[0].scale.y = 1 + Math.sin(p * 2) * .025;
  let hop = 0, a1 = .15 + Math.sin(p * 2) * .04, a2 = a1, mw = 1.7, mh = .8, br = 0, rz = 0;
  if (m === 'worried') { a1 = a2 = 2.1 + Math.sin(p * 11) * .25; mw = 1.1; mh = .55; br = .55; rz = Math.sin(p * 9) * .04; }
  else if (m === 'happy') { hop = Math.abs(Math.sin(p * 8)) * .7; a1 = a2 = 2.5 + Math.sin(p * 14) * .35; mw = 2.4; mh = 1.5; }
  else if (m === 'oops') { rz = Math.sin(p * 45) * .12; a1 = a2 = .6; mw = 1.3; mh = .3; br = .6; }
  else if (m === 'drink') { mw = 2; mh = 1.2; }
  else if (m === 'wave') { a2 = 2.5 + Math.sin(p * 10) * .4; mw = 2.3; mh = 1.3; hop = Math.abs(Math.sin(p * 3)) * .15; }
  u.arms[0].rotation.z = -a1; u.arms[1].rotation.z = a2; u.brows[0].rotation.z = br; u.brows[1].rotation.z = -br;
  u.mouth.scale.set(mw, mh, .5); k.position.y = hop; k.rotation.z = rz;
}

/* ===== PROPS (also rendered as 3D previews on the option buttons) ===== */
const P = {
  ladder() { const g = new THREE.Group(); [-.28, .28].forEach(x => g.add(BX(.09, 2.4, .09, 0xe59a4a, x, 0, 0))); for (let i = -4; i <= 4; i++) g.add(BX(.56, .07, .07, 0xffc978, 0, i * .26, 0)); return g; },
  umbrella() { const g = new THREE.Group(), c = new THREE.Mesh(new THREE.SphereGeometry(1.3, 28, 14, 0, Math.PI * 2, 0, Math.PI / 2), new THREE.MeshStandardMaterial({ color: 0xff6b81, side: THREE.DoubleSide, roughness: .5 })); c.castShadow = true; g.add(c, CY(.04, .04, 1.6, 0x8a5a2b, 0, -.7, 0), CY(.06, .06, .15, 0xffd93d, 0, .05, 0)); g.userData.open = c; return g; },
  ball() { const g = new THREE.Group(), r = TO(.4, .05, 0xff6b81); r.rotation.y = Math.PI / 2; g.add(SP(.4, 0x2ec4d6), TO(.4, .05, 0xffd93d), r); return g; },
  water() { const g = new THREE.Group(); g.add(CY(.55, .4, .3, 0xff6b81, 0, .15, 0), CY(.46, .46, .02, 0x4fd6ff, 0, .29, 0)); return g; },
  book() { const g = new THREE.Group(); g.add(BX(.9, .16, .65, 0xb69cff), BX(.84, .1, .6, 0xffffff, .03, 0, 0)); return g; },
  toy() { const g = new THREE.Group(), b = mesh(new THREE.ConeGeometry(.1, .2, 8), 0xff9a2e, .42, .62, 0); b.rotation.z = -Math.PI / 2; g.add(SP(.35, 0xffd93d, 0, .3, 0, 1, .85, 1), SP(.22, 0xffd93d, .22, .65, 0), b); return g; },
  camera() { const g = new THREE.Group(), l = CY(.18, .18, .2, 0x2b2b3a, 0, 0, .28); l.rotation.x = Math.PI / 2; g.add(BX(.8, .5, .4, 0x7cc7ff), l); return g; },
  net() { const g = new THREE.Group(); g.add(CY(.04, .04, 2.6, 0x8a5a2b, 0, -1.3, 0), TO(.55, .05, 0xff6b81, 0, .55, 0), SP(.55, new THREE.MeshBasicMaterial({ color: 0xffffff, wireframe: true }), 0, .55, 0, 1, .6, 1)); return g; },
  bottle() { const g = new THREE.Group(); g.add(CY(.25, .25, .9, 0x4fd6ff, 0, .45, 0), CY(.12, .12, .2, 0xffd93d, 0, 1, 0)); return g; },
  grabber() { const g = new THREE.Group(), s = CY(.04, .04, 2.2, 0x7be0ad); s.rotation.x = Math.PI / 2; g.add(s, BX(.32, .08, .22, 0xff6b81, 0, 0, -1.1), SP(.1, 0xffd93d, 0, 0, 1.1)); return g; },
  cup() { const g = new THREE.Group(); g.add(mesh(new THREE.CylinderGeometry(.35, .27, .55, 20, 1, true), new THREE.MeshStandardMaterial({ color: 0xffd93d, side: THREE.DoubleSide }), 0, .28, 0), CY(.27, .27, .03, 0xffd93d, 0, .02, 0)); return g; },
  scissors() { const g = new THREE.Group(); [-1, 1].forEach(s => { const b = BX(.08, .9, .03, 0xdde3ea, s * .06, .3, 0); b.rotation.z = -s * .15; g.add(b, TO(.14, .04, 0xff6b81, s * .14, -.28, 0)); }); return g; },
  sponge() { const g = new THREE.Group(); g.add(BX(.8, .35, .5, 0xffe45c), BX(.8, .12, .5, 0x7be0ad, 0, .24, 0)); return g; },
  balloon() { const g = new THREE.Group(); g.add(SP(.5, 0xff5a7a, 0, 0, 0, 1, 1.2, 1), CY(.012, .012, 1.4, 0xffffff, 0, -1.3, 0)); return g; },
  pillow() { const g = new THREE.Group(); g.add(SP(.55, 0xffb3d1, 0, 0, 0, 1.2, .6, 1)); return g; },
  stones() { const g = new THREE.Group(); [-.9, 0, .9].forEach(x => g.add(CY(.42, .48, .12, 0x9fb7c9, x, .06, 0))); return g; },
  mud() { const g = new THREE.Group(); g.add(SP(.25, 0x7a4b2a, 0, 0, 0, 1, .6, .5)); return g; },
  string() { const s = CY(.025, .025, 2.4, 0xff6b81); return s; },
  kite() { const k = BX(.7, .7, .03, 0xff6b81); k.rotation.z = Math.PI / 4; return k; },
  puddle() { return CY(1.3, 1.3, .04, 0x8fdcff, 0, .02, 0); }
};
const PV = {}; let PR; // cached 3D previews rendered to images
function preview(n) {
  if (PV[n]) return PV[n];
  PR = PR || new THREE.WebGLRenderer({ alpha: true, antialias: true, preserveDrawingBuffer: true }); PR.setSize(160, 160);
  const s = new THREE.Scene(), d = new THREE.DirectionalLight(0xffffff, 1); d.position.set(2, 4, 5); s.add(new THREE.HemisphereLight(0xffffff, 0xccbbaa, 1.4), d);
  const o = P[n](); o.rotation.set(.25, -.6, 0); s.add(o);
  const b = new THREE.Box3().setFromObject(o), sz = b.getSize(new THREE.Vector3()).length(), c = b.getCenter(new THREE.Vector3());
  const cm = new THREE.PerspectiveCamera(35, 1, .1, 50); cm.position.set(c.x, c.y, c.z + sz * 1.7); cm.lookAt(c); PR.render(s, cm); return PV[n] = PR.domElement.toDataURL();
}

/* ===== ENVIRONMENT (foreground flowers · midground path · background hills/sky, animated clouds/leaves/rain) ===== */
const sway = [], clouds = [], parts = [];
function particles(n, col, size, v, sp, yMax = 9) {
  const a = new Float32Array(n * 3); for (let i = 0; i < n; i++) { a[i * 3] = (Math.random() - .5) * 14; a[i * 3 + 1] = Math.random() * yMax; a[i * 3 + 2] = Math.random() * 9 - 3; }
  const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.BufferAttribute(a, 3));
  const p = new THREE.Points(g, new THREE.PointsMaterial({ color: col, size })); p.frustumCulled = false; env.add(p); parts.push({ g, v, sp, n, yMax });
}
function buildEnv(kind, f) {
  while (env.children.length) env.remove(env.children[0]); sway.length = clouds.length = parts.length = 0;
  const room = f.includes('sofa'), park = kind === 'park';
  scene.background = new THREE.Color(room ? 0xffe2cf : park ? 0xa8ecff : 0x9fdcff); scene.fog = new THREE.Fog(scene.background.getHex(), 18, 44);
  env.add(CY(12, 12.5, .6, room ? 0xf3b98a : park ? 0x7be0ad : 0x8fe07a, 0, -.3, 0), CY(2.8, 2.8, .62, room ? 0xff9fb8 : 0xf6e6b4, 0, -.3, 1));
  if (room) env.add(BX(30, 14, .3, 0xffd1dc, 0, 6, -4), BX(2, 2.2, .1, 0xbfe9ff, -3, 4, -3.8), BX(2.2, .15, .2, 0xffffff, -3, 2.9, -3.7));
  else { [-6, -1.5, 5].forEach((x, i) => env.add(SP(4 + i, [0x66d6a0, 0x7be0ad, 0x5fcf8f][i], x * 1.6, -1.5, -11 - i * 2))); env.add(SP(1.3, new THREE.MeshBasicMaterial({ color: 0xfff3a0 }), 7, 9, -14)); }
  for (let i = 0; i < 4 && !room; i++) { const c = new THREE.Group(); [[0, 0, 1.1], [1, .2, .9], [-1, .1, .8]].forEach(([x, y, r]) => c.add(SP(r, M(0xffffff, 1), x, y, 0))); c.position.set(-14 + i * 8, 6.5 + i % 2 * 2, -9); env.add(c); clouds.push(c); }
  if (f.includes('tree')) { // trunk, low branch, canopy
    env.add(CY(.35, .45, 3.2, 0x9a6634, -2, 1.6, -.4), BX(1.9, .22, .3, 0x9a6634, -1.2, 1.7, -.2));
    [[-2, 3.8, -.4, 1.5, 0x4fcf7a], [-2.9, 3.3, -.4, 1.1, 0x5fdc88], [-1.1, 3.5, -.6, 1.2, 0x44c070], [-2, 4.8, -.5, 1.1, 0x5fdc88]].forEach(([x, y, z, r, c]) => env.add(SP(r, c, x, y, z)));
  }
  if (f.includes('fence')) for (let i = -7; i <= 7; i++) env.add(BX(.35, 1.1, .12, 0xfff0d8, i * .9, .55, -3));
  if (f.includes('flowers')) for (let i = 0; i < 18; i++) {
    const x = (i % 2 ? 1 : -1) * (2.4 + Math.abs(Math.sin(i * 3.3)) * 3), z = -2 + Math.abs(Math.cos(i * 5.7)) * 4, fl = new THREE.Group();
    fl.add(CY(.03, .03, .6, 0x3fae5a, 0, .3, 0), SP(.2, [0xff6b81, 0xffd93d, 0xb69cff, 0xffb37a][i % 4], 0, .68, 0, 1, .7, 1), SP(.09, 0xffffff, 0, .74, 0)); fl.position.set(x, 0, z); env.add(fl); sway.push({ o: fl, p: i });
  }
  if (f.includes('kennel')) { const r = mesh(new THREE.ConeGeometry(1.3, .9, 4), 0xff6b81, 2.6, 1.65, -1.6); r.rotation.y = Math.PI / 4; env.add(BX(1.6, 1.2, 1.4, 0xffb37a, 2.6, .6, -1.6), r, BX(.6, .7, .05, 0x3b2a5a, 2.6, .35, -.88)); }
  if (f.includes('sofa')) { env.add(BX(4, .5, 1.3, 0xb69cff, 0, .85, -1.3), BX(4, 1.2, .3, 0xa68bf5, 0, 1.5, -1.85), BX(.4, 1, 1.3, 0xa68bf5, -2, .9, -1.3), BX(.4, 1, 1.3, 0xa68bf5, 2, .9, -1.3)); [-1.7, 1.7].forEach(x => env.add(CY(.1, .1, .6, 0x8a5a2b, x, .3, -1.3))); }
  if (f.includes('bench')) env.add(BX(1.8, .15, .6, 0xff8a5b, 2.2, .7, -1.4), BX(.12, .7, .5, 0x8a5a2b, 1.4, .35, -1.4), BX(.12, .7, .5, 0x8a5a2b, 3, .35, -1.4));
  if (f.includes('puddles')) [[-1.9, 1.8], [2, 2.3], [-2.4, .6]].forEach(([x, z]) => env.add(CY(.8, .8, .03, 0x8fdcff, x, .02, z)));
  if (f.includes('rain')) particles(260, 0x5aaeea, .1, 9, 0, 9); else if (!room) particles(24, 0xffc93d, .2, .8, 1.2, 8);
}

/* ===== LEVELS (data only). a: [type,x,y,z]  p: props [name,x,y,z,rotZ,scale]  step keys: c=correct option, o=3 options, to=where the tool goes, fx=animation, rm=hide props, mv=[prop,pos], go=character walks there ===== */
const TREE_LADDER = { to: [-.05, .85, .7], rz: .35 };
const LEVELS = [
  { kind: 'home', f: ['tree', 'fence', 'flowers'], a: [['cat', -.9, 1.7, .2]], steps: [{ who: 0, say: 's_stuck', c: 'ladder', o: ['ladder', 'umbrella', 'ball'], ...TREE_LADDER, go: [.9, 0, 1.1] }] },
  { kind: 'home', f: ['kennel', 'fence', 'flowers'], a: [['puppy', 0, 0, 0]], steps: [{ who: 0, say: 's_thirst', c: 'water', o: ['water', 'book', 'toy'], to: [0, 0, 1.6], sc: 1.4, fx: 'drink', ty: 'ahh' }] },
  { kind: 'park', f: ['rain', 'tree', 'puddles'], a: [['bunny', 0, 0, 0]], steps: [{ who: 0, say: 's_wet', c: 'umbrella', o: ['umbrella', 'camera', 'ball'], to: [0, 4.7, 0], sc: 1.6, fx: 'open' }] },
  { kind: 'park', f: ['bench', 'tree', 'flowers'], ly: 2.4, a: [['panda', .4, 0, 0]], p: [['balloon', -1.5, 3.7, .3]], steps: [{ who: 0, say: 's_balloon', c: 'net', o: ['net', 'book', 'bottle'], to: [-.9, 2.6, 1.1], rz: .5, fx: 'reach', mv: [0, [1, 2.2, 1.1]] }] },
  { kind: 'home', f: ['sofa'], a: [['cat', 0, 0, .7]], p: [['toy', .7, .25, -.85, 0, .8]], steps: [{ who: 0, say: 's_toy', c: 'grabber', o: ['grabber', 'umbrella', 'cup'], to: [.7, .5, 1.6], fx: 'reach', mv: [0, [.4, .3, 1.5]] }] },
  { kind: 'park', f: ['tree', 'flowers'], ly: 2.4, a: [['bird', .2, 0, 0]], p: [['string', -.7, 1.7, .3, 1.05], ['kite', -1.6, 3.5, .4]], steps: [{ who: 0, say: 's_tangled', c: 'scissors', o: ['scissors', 'ball', 'umbrella'], to: [-.6, 1.8, 1.3], fx: 'snip', rm: [0], go: [1.4, 3.4, 1.2] }] },
  { kind: 'park', f: ['bench', 'flowers', 'puddles'], a: [['puppy', 0, 0, 0]], p: [['mud', -.35, 2.3, 1], ['mud', .4, 1.1, .85], ['mud', -.3, .8, .85]], steps: [{ who: 0, say: 's_mud', c: 'sponge', o: ['sponge', 'balloon', 'book'], to: [0, 1.6, 1.5], fx: 'sweep', rm: [0, 1, 2] }] },
  { kind: 'park', f: ['tree', 'flowers'], ly: 2.4, a: [['bunny', .6, 0, .3]], p: [['balloon', -1.2, 2.5, .2]], steps: [{ who: 0, say: 's_balloon', c: 'ladder', o: ['ladder', 'cup', 'pillow'], ...TREE_LADDER, mv: [0, [.3, 2.3, 1.3]] }] },
  { kind: 'park', f: ['flowers'], a: [['chick', -1.9, 0, 1]], p: [['puddle', 0, 0, 1]], steps: [{ who: 0, say: 's_cross', c: 'stones', o: ['stones', 'balloon', 'book'], to: [0, 0, 1], go: [1.9, 0, 1] }] },
  { kind: 'park', f: ['tree', 'flowers', 'rain'], sc: .72, a: [['cat', -.9, 1.5, .2], ['puppy', 1.3, 0, .9], ['bunny', 3.2, 0, .3]], steps: [
    { who: 0, say: 's_stuck', c: 'ladder', o: ['water', 'ladder', 'umbrella'], ...TREE_LADDER, go: [-.4, 0, 1.2] },
    { who: 1, say: 's_thirst', c: 'water', o: ['umbrella', 'ladder', 'water'], to: [1.3, 0, 2.3], sc: 1.2, fx: 'drink', ty: 'ahh' },
    { who: 2, say: 's_wet', c: 'umbrella', o: ['ladder', 'water', 'umbrella'], to: [3.2, 4.2, .3], sc: 1.5, fx: 'open' }] }
];

/* ===== GAME ===== */
let G = {}, actors = [], props = [], temps = [], streak = 0;
const shuffle = a => a.slice().sort(() => Math.random() - .5);
function clearScene() { [...actors, ...props, ...temps].forEach(o => scene.remove(o)); actors = []; props = []; temps = []; }
function focus(a, L) { const ly = L.ly ?? a.position.y + 1; camT.p.set(a.position.x * .75, ly + 2.4, 9.6); camT.l.set(a.position.x * .85, ly - .1, 0); }
function say(main, sub) { const b = $('#bubble'); b.innerHTML = `<b>${t(main)}</b>${sub ? `<small>${t(sub)}</small>` : ''}`; b.hidden = false; }
function hud() { $('#hearts').textContent = '❤️'.repeat(G.lives) + '🤍'.repeat(3 - G.lives); $('#score').textContent = '⭐ ' + S.score; $('#coins').textContent = '🪙 ' + S.coins; }

function startLevel(i) {
  clearScene(); const L = LEVELS[i]; G = { i, step: 0, lives: 3, busy: true }; streak = 0;
  buildEnv(L.kind, L.f);
  actors = L.a.map(([ty, x, y, z]) => { const g = makeChar(ty); g.position.set(x, y, z); if (L.sc) g.scale.setScalar(L.sc); scene.add(g); return g; });
  props = (L.p || []).map(([n, x, y, z, rz, sc]) => { const o = P[n](); o.position.set(x, y, z); o.rotation.z = rz || 0; o.scale.setScalar(sc || 1); scene.add(o); return o; });
  $('#scr').hidden = true; $('#game').hidden = false; $('#opts').innerHTML = ''; $('#bubble').hidden = true;
  cam.position.set(0, 8, 17); hud(); loadStep(true);
}
async function loadStep(first) {
  const L = LEVELS[G.i], st = L.steps[G.step]; G.busy = true; $('#opts').innerHTML = '';
  actors.forEach((a, k) => a.userData.mood = k === st.who ? 'worried' : 'idle'); focus(actors[st.who], L); G.act = actors[st.who];
  await wait(first ? 1700 : 900); const my = G.i; if (G.i !== my) return;
  say('help', st.say); speak(t('help')); $('#hintBtn').textContent = '💡 ' + t('hint');
  $('#opts').innerHTML = shuffle(st.o).map(n => `<button class="opt" data-n="${n}"><img src="${preview(n)}" alt=""><span>${t(n)}</span></button>`).join('');
  G.t0 = performance.now(); G.busy = false;
}
function pick(n, btn) {
  if (G.busy) return; const st = LEVELS[G.i].steps[G.step]; sfx('tap'); speak(t(n));
  if (n === st.c) return solve(st);
  btn.classList.add('no'); G.lives--; streak = 0; sfx('no'); vib(200); hud(); say('oops', 'again'); speak(t('oops'));
  const a = G.act; a.userData.mood = 'oops'; setTimeout(() => a.userData.mood = 'worried', 900);
  if (G.lives <= 0) { G.busy = true; setTimeout(lose, 1000); }
}
async function solve(st) { // the chosen tool physically solves the problem
  G.busy = true; const a = G.act, [x, y, z] = st.to, o = P[st.c](); o.scale.setScalar(st.sc || 1); o.rotation.z = st.rz || 0; o.position.set(x * .3, y + 2.5, z + 5); scene.add(o); temps.push(o);
  if (st.fx === 'open') o.userData.open.scale.y = .05;
  const s = o.position.clone(), e = new THREE.Vector3(x, y, z);
  await tw(900, k => { o.position.lerpVectors(s, e, ease(k)); o.position.y += Math.sin(k * Math.PI) * 1.2; o.rotation.y = (1 - k) * 6; });
  if (st.fx === 'open') await tw(500, k => o.userData.open.scale.y = .05 + .95 * ease(k));
  else if (st.fx === 'sweep') await tw(1800, k => { o.position.x = x + Math.sin(k * 20) * .7; st.rm.forEach((r, j) => props[r].scale.setScalar(Math.max(0, 1 - Math.max(0, k * 1.6 - j * .4)))); });
  else if (st.fx === 'snip') await tw(800, k => { o.rotation.z = (st.rz || 0) + Math.sin(k * 30) * .3; });
  else if (st.fx === 'reach') await tw(800, k => { o.position.z = z - Math.sin(k * Math.PI) * .8; });
  else await wait(400);
  (st.rm || []).forEach(r => props[r].visible = false);
  if (st.mv) await moveTo(props[st.mv[0]], st.mv[1], 1000, .6);
  a.userData.mood = st.fx === 'drink' ? 'drink' : 'happy';
  if (st.fx === 'drink') { await wait(1600); a.userData.mood = 'happy'; }
  if (st.go) moveTo(a, st.go, 1200, st.go[1] > 1 ? 0 : .8);
  reward(st); say(st.ty || 'thanks'); speak(t(st.ty || 'thanks')); sfx('ok'); sparkle('✨⭐💖', 16); vib(60);
  await wait(2200); a.userData.mood = 'idle';
  ++G.step < LEVELS[G.i].steps.length ? loadStep() : win();
}
function reward(st) {
  const fast = performance.now() - G.t0 < 6000, sb = ++streak >= 3; let pts = 10; pop('+10');
  if (fast) { pts += 5; setTimeout(() => pop('⚡ FAST +5'), 250); } if (sb) { pts += 5; setTimeout(() => pop('🔥 STREAK +5'), 500); }
  S.score += pts; save(); hud();
}
function hint() { const b = document.querySelector(`.opt[data-n="${LEVELS[G.i].steps[G.step].c}"]`); if (!b) return; b.classList.add('glow'); setTimeout(() => b.classList.remove('glow'), 3000); }
function win() {
  const i = G.i, stars = Math.max(1, G.lives), final = i === LEVELS.length - 1; S.done[i] = Math.max(S.done[i] || 0, stars); S.coins += 5 + stars; save(); hud();
  sfx('win'); confetti(); actors.forEach((a, k) => a.userData.mood = k % 2 ? 'wave' : 'happy'); $('#bubble').hidden = true; $('#opts').innerHTML = '';
  if (final) { camT.p.set(1, 5, 15); camT.l.set(1, 1.5, 0); setTimeout(confetti, 1200); }
  setTimeout(() => screen(`<div class="stars">${'⭐'.repeat(stars)}</div><h2>${final ? t('super') : '🏆'}</h2>${final ? `<div class="badge">${t('all')}</div>` : ''}<div>🪙 +${5 + stars}</div>
    ${final ? '' : `<button class="big c2" data-a="go" data-n="${i + 1}">${t('next')} ➡️</button>`}<button class="big" data-a="map">🗺️</button>`, true), 1800);
}
function lose() { screen(`<h2>😢 ${t('ohno')}</h2><button class="big c1" data-a="go" data-n="${G.i}">🔄 ${t('retry')}</button><button class="big" data-a="map">🗺️</button>`, true); }

/* ---- effects ---- */
function pop(txt) { const s = document.createElement('span'); s.className = 's'; s.textContent = txt; s.style.cssText = `left:${35 + Math.random() * 20}%;top:${38 + Math.random() * 8}%;font-size:34px`; $('#fx').append(s); setTimeout(() => s.remove(), 1400); }
function sparkle(ch, n) { for (let i = 0; i < n; i++) { const s = document.createElement('span'); s.className = 's'; s.textContent = [...ch][i % 3]; s.style.cssText = `left:${20 + Math.random() * 60}%;top:${30 + Math.random() * 30}%;font-size:${22 + Math.random() * 22}px`; $('#fx').append(s); setTimeout(() => s.remove(), 1400); } }
function confetti() { for (let i = 0; i < 46; i++) { const s = document.createElement('span'); s.className = 'p'; s.textContent = ['🎉', '🎊', '✨', '⭐', '💖'][i % 5]; s.style.cssText = `left:${Math.random() * 100}%;font-size:${20 + Math.random() * 22}px;animation-delay:${Math.random()}s`; $('#fx').append(s); setTimeout(() => s.remove(), 3800); } }

/* ===== MAIN LOOP ===== */
let last = performance.now(); const _v = new THREE.Vector3();
R.setAnimationLoop(now => {
  const dt = Math.min((now - last) / 1000, .05), tm = now / 1000; last = now; tick(dt);
  cam.position.lerp(camT.p, dt * 2.5); look.lerp(camT.l, dt * 2.5); cam.lookAt(look);
  actors.forEach(a => animChar(a, tm));
  clouds.forEach(c => { c.position.x += dt * .4; if (c.position.x > 18) c.position.x = -18; });
  sway.forEach(s => s.o.rotation.z = Math.sin(tm * 2 + s.p) * .12);
  parts.forEach(p => { const A = p.g.attributes.position.array; for (let i = 0; i < p.n; i++) { A[i * 3 + 1] -= p.v * dt; A[i * 3] += Math.sin(tm + i) * p.sp * dt; if (A[i * 3 + 1] < 0) A[i * 3 + 1] = p.yMax; } p.g.attributes.position.needsUpdate = true; });
  const b = $('#bubble'); if (!b.hidden && G.act && !$('#game').hidden) { // keep speech bubble above the active character's head
    G.act.userData.head.getWorldPosition(_v); _v.y += 2.1 * G.act.scale.x; _v.project(cam);
    b.style.left = Math.min(Math.max((_v.x * .5 + .5) * innerWidth, 110), innerWidth - 110) + 'px'; b.style.top = Math.max((-_v.y * .5 + .5) * innerHeight, 120) + 'px';
  }
  R.render(scene, cam);
});

/* ===== SCREENS ===== */
function screen(html, top) { const s = $('#scr'); s.innerHTML = html; s.hidden = false; s.className = top ? 'top' : ''; }
function menu() { // title screen with a live 3D waving cat
  clearScene(); $('#game').hidden = true; G = {}; document.documentElement.dir = ['ar', 'ur'].includes(S.lang) ? 'rtl' : 'ltr';
  buildEnv('home', ['tree', 'fence', 'flowers']); const c = makeChar('cat'); c.scale.setScalar(1.05); c.position.set(0, 0, 1); c.userData.mood = 'wave'; scene.add(c); actors = [c];
  camT.p.set(0, 3.4, 8); camT.l.set(0, 2.4, 0);
  screen(`<h1>HELP ME! 🆘❤️</h1><button class="big c1" data-a="map">▶️ ${t('play')}</button><button class="big" data-a="lang">🌍 ${t('language')}</button>
    <button class="big c2" data-a="set">⚙️ ${t('settings')}</button><button class="big c3" data-a="ach">🏆 ${t('achievements')}</button>`);
}
const langScreen = () => screen(`<h2>🌍</h2><div class="grid">${Object.entries(LANGS).map(([k, v]) => `<button class="big ${k === S.lang ? 'c1' : ''}" data-a="setlang" data-l="${k}">${v[0]} ${v[1]}</button>`).join('')}</div>`, true);
function mapScreen() {
  $('#game').hidden = true; const icons = ['🏠', '🌳', '🏫', '🏙️', '🌈'];
  screen(icons.map((ic, w) => `<div class="world">${ic}<div class="lvls">${Array.from({ length: 10 }, (_, k) => { const n = w * 10 + k, d = S.done[n] || 0;
    return n < LEVELS.length && (n === 0 || S.done[n - 1]) ? `<button class="lvl" data-a="go" data-n="${n}">${n + 1}<small>${d ? '⭐'.repeat(d) : '▶️'}</small></button>` : `<button class="lvl" disabled>🔒</button>`; }).join('')}</div></div>`).join('') + `<button class="big" data-a="menu">🏠 ${t('back')}</button>`, true);
}
function settingsScreen() {
  const b = (k, l) => `<button class="big ${S[k] ? '' : 'off'}" data-a="tog" data-k="${k}">${S[k] ? '🔊' : '🔇'} ${t(l)}</button>`;
  screen(`<h2>⚙️</h2>` + b('music', 'music') + b('sfx', 'sound') + b('voice', 'voice') + b('vib', 'vib') + `<button class="big c3" data-a="lang">🌍 ${t('language')}</button><button class="big c2" data-a="menu">🏠 ${t('back')}</button>`, true);
}
function achScreen() {
  const n = S.done.filter(Boolean).length;
  screen(`<h2>🏆</h2>` + [[n >= 1, '🥇', 'a1'], [n >= 5, '🌟', 'a2'], [n >= 10, '🏆', 'a3']].map(([ok, e, k]) => `<div class="badge" style="opacity:${ok ? 1 : .4}">${e} ${t(k)} ${ok ? '✅' : '🔒'}</div>`).join('') + `<button class="big c2" data-a="menu">🏠 ${t('back')}</button>`, true);
}
document.addEventListener('click', e => {
  if (!AC) { try { tone(1, .01, 'sine', 0, 0); } catch (_) { } startMusic(); }
  const o = e.target.closest('.opt'); if (o) return pick(o.dataset.n, o);
  if (e.target.closest('#hintBtn')) return hint();
  if (e.target.closest('#homeBtn')) return mapScreen();
  const b = e.target.closest('[data-a]'); if (!b) return; const d = b.dataset; sfx('tap');
  ({ map: mapScreen, menu, lang: langScreen, set: settingsScreen, ach: achScreen, go: () => startLevel(+d.n),
    setlang: () => { S.lang = d.l; save(); menu(); }, tog: () => { S[d.k] = !S[d.k]; save(); settingsScreen(); } })[d.a]();
});
menu();