# Connect Finance Manager to the Internet

Your app is an HTML file. The browser uses your phone/Wi‑Fi internet automatically.
Rose’s female cloud voice and some features need a network connection.

## Option A — Open on your phone with internet (simplest)
1. Copy `FinanceManager.html` to your phone (Downloads, Drive, WhatsApp).
2. Open it in **Chrome**.
3. Turn on **Wi‑Fi or mobile data**.
4. Tap Rose — cloud voice needs internet.

Note: Some phones restrict `file://` pages from network audio. If Rose is silent, use Option B.

## Option B — Host online (recommended)
This gives the app a real https:// link so voice and internet features work reliably.

### Free hosting with Netlify Drop
1. Go to https://app.netlify.com/drop
2. Drag the `finance-app` folder (or zip) onto the page
3. Netlify gives you a link like `https://random-name.netlify.app`
4. Open that link on your phone (Chrome)

### Free hosting with Firebase
```bash
npm install -g firebase-tools
firebase login
firebase init hosting   # public folder = finance-app
firebase deploy
```

### GitHub Pages
1. Create a GitHub repo
2. Upload `index.html`, `app.js`, `styles.css`, etc.
3. Settings → Pages → deploy from main branch

## Option C — APK with internet
When you build with Capacitor, the app uses the phone’s normal internet permission.
Internet is allowed by default for https requests in Android.

## Checklist if Rose has no sound
- [ ] Wi‑Fi or mobile data ON
- [ ] Chrome browser
- [ ] Phone not on silent
- [ ] Prefer hosted https:// link over opening the file directly
- [ ] Tap **Speak** only when you are ready to talk
