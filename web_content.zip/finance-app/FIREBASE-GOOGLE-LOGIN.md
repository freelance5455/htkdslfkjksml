# Enable real Google login (Firebase)

## 1. Firebase Console
1. https://console.firebase.google.com/ → Create project
2. Build → Authentication → Sign-in method → **Google** → Enable
3. Project settings → Your apps → **Web** → Register app
4. Copy the config values

## 2. Edit `firebase-config.js`
Paste your keys and set:

```js
window.FIREBASE_ENABLED = true;
```

## 3. Authorized domains
Authentication → Settings → Authorized domains  
Add: `localhost`, your hosting domain (e.g. `yourapp.web.app`)

## 4. Test
Open the app on **http://localhost** or HTTPS (not file://).  
Tap **Sign in with Google**.

## 5. Hosting (optional, free)
```bash
npm install -g firebase-tools
firebase login
firebase init hosting
# public folder = this finance-app folder
firebase deploy
```

Until `FIREBASE_ENABLED` is true, the app still uses **demo Google** (profile form).
