# Finance Manager — Phone-Friendly + Smart Features

## Core sections
1. **Expenses** — budgets, categories (rename anytime), voice log
2. **Savings** — goals with rename + progress
3. **Full Savings Plan** — pie chart + breakdown
4. **How to Grow Your Savings** — rate & tips
5. **AI Financial Coach** — ask affordability / cash-flow questions
6. **Subscription Audit** — detects recurring charges & price hikes
7. **Income** — record money in
8. **Nudges & Reminders** — 80% budget alerts + monthly check-in

## Smart features (what was added)

### 1. Predictive Forecasting & AI Coaching
- Chat-style coach answers questions using *your* data
- Examples: “Can I afford ₦50,000 next month?”, “How is my savings rate?”, “Predict my cash flow”
- Uses averages from history + current balance (rule-based, works offline)

### 2. Voice-Command Expense Logging
- Tap **🎤 Voice log** (Chrome recommended)
- Say: “Spent 45 on groceries” → amount, description, category auto-filled
- Review and tap Add

### 3. Automated Subscription Auditing
- Scans expense history for similar repeated descriptions
- Flags recurring items and possible price hikes

### 4. Behavioral Nudging
- Warns when a category hits **80%** of budget (before you overspend)
- Monthly reminder banner (optional notifications)

## Tips applied
- **Lean MVP first**: tracking + budgets + savings still the core
- **Speed to value**: sample data loads so you see the dashboard immediately
- **Security note**: this version stores data only in the browser (localStorage). For real banking/Plaid, you’d need a backend with encryption, MFA, and biometrics.

## How to use on phone
1. Extract zip → open `index.html`
2. Chrome → Add to Home Screen for app-like use
3. Allow mic for voice logging; allow notifications for alerts

## Files
- index.html / styles.css / app.js
