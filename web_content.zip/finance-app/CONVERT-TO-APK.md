# Convert Finance Manager to Android APK

## Fastest clean path (this repo)
Use the folder **FinanceManager-Capacitor** (one level up from finance-app):

See `FinanceManager-Capacitor/README-CAPACITOR.md`.

## Google login
See `FIREBASE-GOOGLE-LOGIN.md` in this folder.

# Convert Finance Manager to Android APK

This folder is a complete **web app** (HTML / CSS / JS).  
You can wrap it into an APK with any of these free methods.

---

## Method 1 — PWA Builder (easiest, no coding)

1. Upload this whole folder to any static host (Netlify, GitHub Pages, or even open via a local server).
2. Go to: https://www.pwabuilder.com/
3. Paste your app URL → **Start** → **Package** → **Android**
4. Download the APK / Play package.

---

## Method 2 — Capacitor (best quality)

On your computer (Node.js required):

```bash
npm create @capacitor/app@latest
# Project name: FinanceManager
# Framework: blank / no framework — then replace www with these files

cd FinanceManager
# Copy index.html, styles.css, app.js, manifest.json, icons into the www/ folder

npm install @capacitor/android
npx cap add android
npx cap sync android
npx cap open android
```

In Android Studio: **Build → Build Bundle(s) / APK(s) → Build APK(s)**.

---

## Method 3 — Cordova

```bash
npm install -g cordova
cordova create FinanceApp com.yourname.finance FinanceManager
cd FinanceApp
# Replace www/ contents with the files from this folder
cordova platform add android
cordova build android
```

APK path: `platforms/android/app/build/outputs/apk/`

---

## Method 4 — Online WebView wrappers

Tools such as **WebIntoApp**, **AppsGeyser**, or **AppMaker** let you upload a ZIP of this folder or point to a URL and export an APK.

---

## Files included

| File | Role |
|------|------|
| index.html | App UI |
| styles.css | Styles |
| app.js | Logic |
| manifest.json | PWA / Android metadata |
| icon-192.png / icon-512.png | App icons |
| CONVERT-TO-APK.md | This guide |

**Note:** This app stores data in the device browser (`localStorage`). After wrapping in a WebView, data stays on the phone.
