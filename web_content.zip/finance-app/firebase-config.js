/**
 * FIREBASE CONFIG — replace values from Firebase Console → Project settings → Your apps
 * https://console.firebase.google.com/
 *
 * Steps:
 * 1. Create a project
 * 2. Authentication → Sign-in method → enable Google
 * 3. Add a Web app → copy config below
 * 4. Authentication → Settings → Authorized domains (add your domain + localhost)
 * 5. Set USE_FIREBASE_GOOGLE = true in app.js (or leave auto-detect)
 */
window.FIREBASE_CONFIG = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT.appspot.com",
  messagingSenderId: "YOUR_SENDER_ID",
  appId: "YOUR_APP_ID",
};

/** Set true after pasting real config above */
window.FIREBASE_ENABLED = false;
