// ===================== State =====================
const STORAGE_KEY = 'financeManager_v7';
const WA_SUPPORT_LINK = 'https://wa.me/2347044338143?text=Hello%2C%20I%20need%20help%20with%20Finance%20Manager';
const SUPPORT_EMAIL_LINK = 'mailto:aiyenuberunolamitangodwin@gmail.com?subject=Finance%20Manager%20Support&body=Hello%2C%20I%20need%20help%20with%20Finance%20Manager.';
const SUPPORT_EMAIL = 'aiyenuberunolamitangodwin@gmail.com';

const DEMO_MONTH = '2026-09'; // Demo stands alone as September
const DEMO_MONTH_LABEL = 'September 2026';

const EMPTY_CATEGORIES = [
  { id: 'rent', name: 'Rent', budget: 0, color: '#f59e0b', icon: '🏠' },
  { id: 'food', name: 'Foodstuff', budget: 0, color: '#22c55e', icon: '🛒' },
  { id: 'transport', name: 'Transport', budget: 0, color: '#3b82f6', icon: '🚌' },
  { id: 'utilities', name: 'Utilities', budget: 0, color: '#a855f7', icon: '💡' },
  { id: 'misc', name: 'Miscellaneous', budget: 0, color: '#64748b', icon: '📦' },
];

const DEMO_CATEGORIES = [
  { id: 'rent', name: 'Rent', budget: 150000, color: '#f59e0b', icon: '🏠', isDemo: true },
  { id: 'food', name: 'Foodstuff', budget: 80000, color: '#22c55e', icon: '🛒', isDemo: true },
  { id: 'transport', name: 'Transport', budget: 30000, color: '#3b82f6', icon: '🚌', isDemo: true },
  { id: 'utilities', name: 'Utilities', budget: 25000, color: '#a855f7', icon: '💡', isDemo: true },
  { id: 'misc', name: 'Miscellaneous', budget: 20000, color: '#64748b', icon: '📦', isDemo: true },
];

const DEFAULT_CATEGORIES = EMPTY_CATEGORIES.map(c => ({ ...c }));

function getMonthKey(date) {
  const d = new Date(date);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
}

function createSampleData() {
  const realMonth = getMonthKey(new Date());
  // Demo is fixed to September so it stands on its own
  const demoDate = DEMO_MONTH + '-15';
  return {
    currency: '₦',
    currentMonth: realMonth, // always start on the real current month
    demoActive: true,
    demoMonth: DEMO_MONTH,
    categories: DEMO_CATEGORIES.map(c => ({ ...c })),
    transactions: [
      { id: 'tx1', type: 'income', desc: 'Monthly Salary (Demo)', amount: 450000, categoryId: 'income', date: demoDate, month: DEMO_MONTH, isDemo: true },
      { id: 'tx2', type: 'expense', desc: 'House Rent (Demo)', amount: 150000, categoryId: 'rent', date: demoDate, month: DEMO_MONTH, isDemo: true },
      { id: 'tx3', type: 'expense', desc: 'Grocery shopping (Demo)', amount: 35000, categoryId: 'food', date: demoDate, month: DEMO_MONTH, isDemo: true },
      { id: 'tx4', type: 'expense', desc: 'Bus & Uber (Demo)', amount: 12000, categoryId: 'transport', date: demoDate, month: DEMO_MONTH, isDemo: true },
      { id: 'tx5', type: 'expense', desc: 'Electricity bill (Demo)', amount: 18000, categoryId: 'utilities', date: demoDate, month: DEMO_MONTH, isDemo: true },
      { id: 'tx6', type: 'saving', desc: 'Contribution to Emergency Fund (Demo)', amount: 50000, categoryId: 'goal1', date: demoDate, month: DEMO_MONTH, isDemo: true },
      { id: 'tx7', type: 'saving', desc: 'Contribution to New Laptop (Demo)', amount: 25000, categoryId: 'goal2', date: demoDate, month: DEMO_MONTH, isDemo: true },
    ],
    goals: [
      { id: 'goal1', name: 'Emergency Fund', target: 500000, current: 50000, isDemo: true },
      { id: 'goal2', name: 'New Laptop', target: 350000, current: 25000, isDemo: true },
    ],
    reminderEnabled: false,
    lastReminderMonth: null,
    primaryFocus: null,
    savingsStreak: 0,
    lastSaveMonth: null,
    celebratedGoals: [],
    debts: [],
    recurringBills: [],
    language: 'en',
    theme: 'calm-dark',
    fontSize: 'normal',
    numberFormat: 'en-NG',
    tapHints: true,
    compactMode: false,
    appTagline: 'Track · Budget · Save',
  };
}

let state = createSampleData();
let editingCategoryId = null;
let editingGoalId = null;

// ===================== Helpers =====================
function formatMonthLabel(monthKey) {
  const [y, m] = monthKey.split('-');
  const date = new Date(Number(y), Number(m) - 1, 1);
  return date.toLocaleDateString('en-US', { month: 'short', year: 'numeric' });
}

function formatMoney(amount) {
  const num = Number(amount) || 0;
  const loc = (state && state.numberFormat) || 'en-NG';
  return (state.currency || '₦') + num.toLocaleString(loc, { minimumFractionDigits: 0, maximumFractionDigits: 2 });
}

function uid() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}

function save() {
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); } catch (e) {}
}

function load() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const data = JSON.parse(raw);
      state = {
        currency: data.currency || '₦',
        currentMonth: data.currentMonth || getMonthKey(new Date()),
        categories: Array.isArray(data.categories) && data.categories.length ? data.categories : [...DEFAULT_CATEGORIES],
        transactions: Array.isArray(data.transactions) ? data.transactions : [],
        goals: Array.isArray(data.goals) ? data.goals : [],
        reminderEnabled: !!data.reminderEnabled,
        lastReminderMonth: data.lastReminderMonth || null,
        primaryFocus: data.primaryFocus || null,
        savingsStreak: data.savingsStreak || 0,
        lastSaveMonth: data.lastSaveMonth || null,
        celebratedGoals: Array.isArray(data.celebratedGoals) ? data.celebratedGoals : [],
        demoActive: !!data.demoActive,
        demoMonth: data.demoMonth || null,
        debts: Array.isArray(data.debts) ? data.debts : [],
        recurringBills: Array.isArray(data.recurringBills) ? data.recurringBills : [],
        language: data.language || 'en',
        theme: data.theme || 'calm-dark',
        fontSize: data.fontSize || 'normal',
        numberFormat: data.numberFormat || 'en-NG',
        tapHints: data.tapHints !== false,
        compactMode: !!data.compactMode,
        appTagline: data.appTagline || localStorage.getItem('financeManager_tagline') || 'Track · Budget · Save',
      };
    } else {
      state = createSampleData();
      save();
    }
  } catch (e) {
    state = createSampleData();
  }
}

function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

// ===================== Calculations =====================

function dateInViewedMonth(day) {
  const [y, m] = state.currentMonth.split('-').map(Number);
  const d = Math.min(day || 1, 28);
  return `${y}-${String(m).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
}

function syncFormDatesToViewedMonth() {
  const defaultDate = dateInViewedMonth(1);
  ['expDate', 'savDate', 'incDate'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.value = defaultDate;
  });
}

function isViewingDemoMonth() {
  const txs = getMonthTransactions();
  return txs.length > 0 && txs.every(t => t.isDemo);
}


function clearDemoData() {
  // Remove every demo-linked figure so user starts clean
  state.transactions = (state.transactions || []).filter(t => !t.isDemo);
  // Reset demo goals (or remove them)
  state.goals = (state.goals || [])
    .filter(g => !g.isDemo)
    .map(g => g);
  // If no real goals left, leave empty list for user to create
  // Zero category budgets that were demo defaults
  state.categories = (state.categories || []).map(c => {
    if (c.isDemo) {
      return { ...c, budget: 0, isDemo: false };
    }
    return c;
  });
  // Ensure core categories exist with zero budgets if cleared empty
  if (!state.categories.length) {
    state.categories = EMPTY_CATEGORIES.map(c => ({ ...c }));
  } else {
    // Force budgets to 0 when wiping demo so rent etc show zero
    const hadOnlyDemoTx = true;
    state.categories = state.categories.map(c => ({
      ...c,
      budget: c.isDemo ? 0 : (Number(c.budget) || 0),
      isDemo: false,
    }));
  }
  // After full demo clear: if no real transactions at all, zero all budgets for clean breakdown
  const hasRealTx = state.transactions.some(t => !t.isDemo);
  if (!hasRealTx) {
    state.categories = state.categories.map(c => ({ ...c, budget: 0, isDemo: false }));
    state.goals = [];
    state.debts = [];
    state.recurringBills = [];
    state.savingsStreak = 0;
    state.lastSaveMonth = null;
    state.celebratedGoals = [];
  }
  state.demoActive = false;
  state.demoMonth = null;
  // Move user to real current month for their own plan
  state.currentMonth = getMonthKey(new Date());
  save();
  syncFormDatesToViewedMonth();
  render();
  if (typeof showCelebration === 'function') {
    showCelebration('Demo cleared', 'September demo removed. Figures are zero — add your own rent, food, and income.', '✨');
  }
}


function renderDemoGuideBanner() {
  let el = document.getElementById('demoGuideBanner');
  if (!el) {
    const app = document.getElementById('mainApp') || document.querySelector('.app');
    if (!app) return;
    el = document.createElement('div');
    el.id = 'demoGuideBanner';
    el.className = 'demo-guide-banner hidden';
    const header = app.querySelector('.header');
    if (header && header.nextSibling) {
      app.insertBefore(el, header.nextSibling);
    } else {
      app.prepend(el);
    }
  }
  const realCount = getMonthTransactions().filter(t => !t.isDemo).length;
  const demoCount = getMonthTransactions().filter(t => t.isDemo).length;
  const onDemoMonth = state.currentMonth === (state.demoMonth || DEMO_MONTH);
  const anyDemo = state.transactions.some(t => t.isDemo) || state.demoActive;
  if (anyDemo && demoCount > 0 && realCount === 0) {
    el.className = 'demo-guide-banner';
    el.innerHTML = `<span class="demo-badge">GUIDE / DEMO · September</span>
      <div><strong>${DEMO_MONTH_LABEL} demo figures (guide only)</strong>
      <p>This is sample data for <strong>September</strong> so you can explore the app. Clear it to start with zeros and enter your own rent, food, and savings.</p></div>
      <button type="button" class="btn-sm" id="clearDemoBtn">Clear September demo</button>`;
    const btn = document.getElementById('clearDemoBtn');
    if (btn) {
      btn.onclick = () => {
        if (confirm('Clear all September demo figures? Rent, budgets, and sample goals will reset to zero so you can enter your own.')) {
          clearDemoData();
        }
      };
    }
  } else if (anyDemo && state.currentMonth !== (state.demoMonth || DEMO_MONTH)) {
    el.className = 'demo-guide-banner';
    el.innerHTML = `<span class="demo-badge">DEMO IN SEPTEMBER</span>
      <div><strong>Sample data lives in September only</strong>
      <p>You are viewing ${formatMonthLabel(state.currentMonth)}. Switch to Sep 2026 to see the guide, or <button type="button" class="btn-sm" id="clearDemoBtn2" style="margin-left:0.25rem">clear demo</button></p></div>`;
    const btn2 = document.getElementById('clearDemoBtn2');
    if (btn2) btn2.onclick = () => { if (confirm('Clear September demo completely?')) clearDemoData(); };
  } else if (getMonthTransactions().length === 0) {
    el.className = 'demo-guide-banner plan-month';
    el.innerHTML = `<span class="demo-badge plan">NEW MONTH</span>
      <div><strong>Plan ${formatMonthLabel(state.currentMonth)}</strong>
      <p>This month is empty. Add expected income and expenses to calculate your plan and next-month costs.</p></div>`;
  } else {
    el.className = 'demo-guide-banner hidden';
    el.innerHTML = '';
  }
}


function getMonthTransactions() {
  return state.transactions.filter(t => t.month === state.currentMonth);
}

function getCategorySpent(catId) {
  return getMonthTransactions()
    .filter(t => t.type === 'expense' && t.categoryId === catId)
    .reduce((sum, t) => sum + Number(t.amount), 0);
}

function getTotals() {
  const txs = getMonthTransactions();
  const income = txs.filter(t => t.type === 'income').reduce((s, t) => s + Number(t.amount), 0);
  const expenses = txs.filter(t => t.type === 'expense').reduce((s, t) => s + Number(t.amount), 0);
  const saved = txs.filter(t => t.type === 'saving').reduce((s, t) => s + Number(t.amount), 0);
  // Expenses come out of salary; savings also set aside from salary
  const afterExpenses = income - expenses;
  const balance = income - expenses - saved; // left after spending + saving
  return { income, expenses, saved, afterExpenses, balance };
}

function getExpenseBreakdown() {
  const breakdown = [];
  let total = 0;
  state.categories.forEach(cat => {
    const spent = getCategorySpent(cat.id);
    if (spent > 0) {
      breakdown.push({ name: cat.name, icon: cat.icon, amount: spent });
      total += spent;
    }
  });
  breakdown.sort((a, b) => b.amount - a.amount);
  return { breakdown, total };
}

function getSavingsTips() {
  const { income, expenses, saved, balance } = getTotals();
  const tips = [];
  const { breakdown } = getExpenseBreakdown();
  const savingsRate = income > 0 ? (saved / income) * 100 : 0;

  if (breakdown.length > 0) {
    const top = breakdown[0];
    const pct = income > 0 ? ((top.amount / income) * 100).toFixed(0) : 0;
    tips.push(pct > 40
      ? `Biggest expense: ${top.icon || ''} ${top.name} (${formatMoney(top.amount)} — ${pct}% of income). Try cutting 5–10%.`
      : `Top expense is ${top.icon || ''} ${top.name} at ${formatMoney(top.amount)}. Keep it under control.`);
  }

  if (income > 0) {
    if (savingsRate < 10) tips.push(`Saving only ${savingsRate.toFixed(1)}%. Aim for 20%+. Use 50/30/20 rule.`);
    else if (savingsRate < 20) tips.push(`Good! Saving ${savingsRate.toFixed(1)}%. Push to 20%+ by cutting one small expense.`);
    else tips.push(`Excellent! Saving ${savingsRate.toFixed(1)}% of income. Keep going.`);
  }

  if (balance > 0 && saved === 0) tips.push(`You have ${formatMoney(balance)} left. Move some into a savings goal now.`);
  else if (balance < 0) tips.push(`Spending is ${formatMoney(Math.abs(balance))} above income this month. A small reset next week can rebalance things.`);

  if (state.goals.length > 0) {
    const g = state.goals.find(x => Number(x.current) < Number(x.target));
    if (g) {
      const rem = Number(g.target) - Number(g.current);
      tips.push(`"${g.name}" needs ${formatMoney(rem)} more. Increase monthly contributions to finish faster.`);
    }
  } else {
    tips.push('Create a savings goal so every naira has a purpose.');
  }

  tips.push('Pay yourself first: save as soon as income arrives.');
  tips.push('Review subscriptions & food delivery — small cuts = big yearly savings.');

  return { savingsRate, tips, balance, income, expenses, saved };
}


// ===================== AI Coach (rule-based forecasting) =====================
function predictMonthlyAverage() {
  // Estimate recurring from history: average expenses & savings across months
  const byMonth = {};
  state.transactions.forEach(t => {
    if (!byMonth[t.month]) byMonth[t.month] = { expense: 0, income: 0, saving: 0 };
    byMonth[t.month][t.type === 'expense' ? 'expense' : t.type === 'income' ? 'income' : 'saving'] += Number(t.amount);
  });
  const months = Object.values(byMonth);
  if (!months.length) return { avgExpense: 0, avgIncome: 0, avgSaving: 0, months: 0 };
  const avgExpense = months.reduce((s, m) => s + m.expense, 0) / months.length;
  const avgIncome = months.reduce((s, m) => s + m.income, 0) / months.length;
  const avgSaving = months.reduce((s, m) => s + m.saving, 0) / months.length;
  return { avgExpense, avgIncome, avgSaving, months: months.length };
}

function answerCoach(question) {
  const q = (question || '').toLowerCase();
  const { income, expenses, saved, balance } = getTotals();
  const pred = predictMonthlyAverage();
  const savingsRate = income > 0 ? (saved / income) * 100 : 0;
  const { breakdown } = getExpenseBreakdown();

  // Extract amount from question if present (₦ or $ or plain number)
  const amountMatch = q.match(/(?:₦|n|\$|usd)?\s*([\d,]+(?:\.\d+)?)\s*(?:k|thousand)?/i);
  let askedAmount = null;
  if (amountMatch) {
    askedAmount = parseFloat(amountMatch[1].replace(/,/g, ''));
    if (/k|thousand/.test(q) && askedAmount < 10000) askedAmount *= 1000;
  }

  // Affordability
  if (/afford|buy|purchase|vacation|trip|can i/.test(q)) {
    const target = askedAmount || 50000;
    const projectedLeftover = Math.max(0, (pred.avgIncome || income) - (pred.avgExpense || expenses) - (pred.avgSaving || saved));
    const thisMonthRoom = Math.max(0, balance);
    const canThisMonth = thisMonthRoom >= target;
    const canNextMonth = projectedLeftover >= target;
    if (canThisMonth) {
      return `Yes — you still have ${formatMoney(thisMonthRoom)} left this month. A ${formatMoney(target)} purchase fits if you don't add other big spends.`;
    }
    if (canNextMonth) {
      return `Not comfortably this month (only ${formatMoney(thisMonthRoom)} left), but based on your average leftover of ~${formatMoney(projectedLeftover)}/month, you could afford ${formatMoney(target)} next month if habits stay the same.`;
    }
    const monthsNeeded = projectedLeftover > 0 ? Math.ceil(target / projectedLeftover) : 'many';
    return `A ${formatMoney(target)} purchase looks tight. Average monthly leftover is ~${formatMoney(projectedLeftover)}. At that pace it may take ~${monthsNeeded} month(s). Cut top expenses or raise savings first.`;
  }

  // Savings rate
  if (/saving|savings rate|how am i/.test(q)) {
    let verdict = savingsRate >= 20 ? 'Excellent' : savingsRate >= 10 ? 'Okay — room to improve' : 'Low — prioritize saving';
    return `${verdict}. You saved ${formatMoney(saved)} (${savingsRate.toFixed(1)}% of income). Target is 20%+. ${pred.months > 1 ? `Across ${pred.months} months you average ${formatMoney(pred.avgSaving)} saved.` : ''}`;
  }

  // What to cut
  if (/cut|reduce|spend less|what should/.test(q)) {
    if (!breakdown.length) return 'No expenses logged yet. Add a few purchases so I can suggest cuts.';
    const top = breakdown.slice(0, 3).map(b => `${b.icon || ''} ${b.name} (${formatMoney(b.amount)})`).join(', ');
    return `Focus on your biggest categories: ${top}. Trimming 10% from the top one frees money for goals without touching essentials.`;
  }

  // Cash flow prediction
  if (/cash flow|predict|forecast|next month/.test(q)) {
    const nextIncome = pred.avgIncome || income;
    const nextExpense = pred.avgExpense || expenses;
    const nextSave = pred.avgSaving || saved;
    const nextBal = nextIncome - nextExpense - nextSave;
    return `Based on ${pred.months || 1} month(s) of history:\n• Expected income ~${formatMoney(nextIncome)}\n• Expected expenses ~${formatMoney(nextExpense)}\n• Expected savings ~${formatMoney(nextSave)}\n• Projected leftover ~${formatMoney(nextBal)}. ${nextBal < 0 ? 'Tighten spending before next month.' : 'You are on track if habits continue.'}`;
  }

  // Default
  return `I can help with: affordability (“Can I afford ₦80,000?”), savings rate, what to cut, and cash-flow forecast. Your balance this month is ${formatMoney(balance)}.`;
}

function appendCoachMessage(text, who) {
  const chat = document.getElementById('coachChat');
  if (!chat) return;
  const div = document.createElement('div');
  div.className = 'coach-msg ' + (who === 'user' ? 'user' : 'bot');
  div.innerHTML = (who === 'user' ? '<strong>You:</strong> ' : '<strong>Coach:</strong> ') + escapeHtml(text).replace(/\n/g, '<br>');
  chat.appendChild(div);
  chat.scrollTop = chat.scrollHeight;
}

// ===================== Voice logging (Web Speech API) =====================
function parseVoiceExpense(transcript) {
  const t = transcript.toLowerCase();
  // patterns: "spent 45 on groceries", "spent $45 on food at costco", "45 naira for transport"
  const amountMatch = t.match(/(?:spent|paid|pay|cost)?\s*(?:₦|naira|\$)?\s*([\d,]+(?:\.\d+)?)/i)
    || t.match(/([\d,]+(?:\.\d+)?)\s*(?:naira|naira|dollars|bucks)?/);
  let amount = amountMatch ? parseFloat(amountMatch[1].replace(/,/g, '')) : null;

  let desc = transcript;
  // try extract "on X" or "for X"
  const onMatch = t.match(/(?:on|for)\s+(.+?)(?:\s+at\s+|$)/i);
  if (onMatch) desc = onMatch[1].trim();

  // auto category by keywords
  let categoryId = state.categories[0]?.id || '';
  const map = [
    { keys: ['food', 'grocery', 'groceries', 'market', 'costco', 'supermarket', 'restaurant', 'lunch', 'dinner'], id: 'food' },
    { keys: ['rent', 'house', 'landlord'], id: 'rent' },
    { keys: ['uber', 'bus', 'transport', 'fuel', 'petrol', 'taxi'], id: 'transport' },
    { keys: ['light', 'electric', 'water', 'utility', 'utilities', 'internet', 'data'], id: 'utilities' },
  ];
  for (const m of map) {
    if (m.keys.some(k => t.includes(k))) {
      const cat = state.categories.find(c => c.id === m.id) || state.categories.find(c => m.keys.some(k => c.name.toLowerCase().includes(k)));
      if (cat) { categoryId = cat.id; break; }
    }
  }

  return { amount, desc: desc.slice(0, 80), categoryId };
}

function startVoiceLog() {
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  const status = document.getElementById('voiceStatus');
  const btn = document.getElementById('voiceBtn');
  if (!SR) {
    if (status) status.textContent = 'Voice not supported in this browser (try Chrome).';
    return;
  }
  const rec = new SR();
  rec.lang = 'en-US';
  rec.interimResults = false;
  rec.maxAlternatives = 1;
  if (btn) btn.classList.add('listening');
  if (status) status.textContent = 'Listening… speak now';
  rec.onresult = (e) => {
    const text = e.results[0][0].transcript;
    if (status) status.textContent = 'Heard: “' + text + '”';
    const parsed = parseVoiceExpense(text);
    if (parsed.amount) document.getElementById('expAmount').value = parsed.amount;
    if (parsed.desc) document.getElementById('expDesc').value = parsed.desc;
    if (parsed.categoryId) {
      const sel = document.getElementById('expCategory');
      if (sel) sel.value = parsed.categoryId;
    }
    if (!parsed.amount) {
      if (status) status.textContent += ' — could not detect amount, please fix fields';
    } else {
      if (status) status.textContent += ' — review & tap Add';
    }
  };
  rec.onerror = () => {
    if (status) status.textContent = 'Could not hear you. Try again.';
    if (btn) btn.classList.remove('listening');
  };
  rec.onend = () => { if (btn) btn.classList.remove('listening'); };
  rec.start();
}

// ===================== Subscription auditing =====================
function detectSubscriptions() {
  // Group expense transactions by normalized description
  const map = {};
  state.transactions.filter(t => t.type === 'expense').forEach(t => {
    const key = (t.desc || '').toLowerCase().replace(/[^a-z0-9\s]/g, '').replace(/\s+/g, ' ').trim();
    if (!key || key.length < 3) return;
    if (!map[key]) map[key] = [];
    map[key].push(t);
  });

  const subs = [];
  Object.entries(map).forEach(([key, list]) => {
    if (list.length < 2) return; // need at least 2 occurrences
    const amounts = list.map(t => Number(t.amount));
    const avg = amounts.reduce((a, b) => a + b, 0) / amounts.length;
    const months = new Set(list.map(t => t.month));
    const last = list.slice().sort((a, b) => new Date(b.date) - new Date(a.date))[0];
    // price hike if latest amount > avg * 1.1
    const hike = Number(last.amount) > avg * 1.1;
    subs.push({
      name: list[0].desc,
      count: list.length,
      months: months.size,
      avg,
      lastAmount: Number(last.amount),
      lastDate: last.date,
      hike,
      flagged: hike || list.length >= 3,
    });
  });
  subs.sort((a, b) => b.avg - a.avg);
  return subs;
}

function renderSubscriptions() {
  const list = document.getElementById('subsList');
  if (!list) return;
  const subs = detectSubscriptions();
  if (!subs.length) {
    list.innerHTML = `<div class="empty-state">No recurring charges detected yet. Log similar expenses over multiple months (e.g. “Netflix”, “Gym”) and they will appear here.</div>`;
    return;
  }
  list.innerHTML = subs.map(s => `
    <div class="sub-item ${s.flagged ? 'flagged' : ''}">
      <div class="sub-left">
        <div class="sub-name">${escapeHtml(s.name)} ${s.hike ? '<span class="sub-badge">PRICE HIKE?</span>' : s.flagged ? '<span class="sub-badge">RECURRING</span>' : ''}</div>
        <div class="sub-meta">${s.count} times · ${s.months} month(s) · last ${s.lastDate}</div>
      </div>
      <div class="sub-amount">${formatMoney(s.lastAmount)} <span style="color:var(--text-muted);font-size:0.75rem">avg ${formatMoney(s.avg)}</span></div>
    </div>
  `).join('');
}

// ===================== Behavioral nudges (80% budget) =====================
function checkBudgetNudges() {
  const banner = document.getElementById('nudgeBanner');
  if (!banner) return;
  const alerts = [];
  state.categories.forEach(cat => {
    const budget = Number(cat.budget) || 0;
    if (budget <= 0) return;
    const spent = getCategorySpent(cat.id);
    const pct = (spent / budget) * 100;
    if (pct >= 100) {
      alerts.push({ title: `${cat.icon || ''} ${cat.name} over budget`, text: `You've used ${formatMoney(spent)} of ${formatMoney(budget)} (${pct.toFixed(0)}%). A gentle pause here protects your goals.` });
    } else if (pct >= 80) {
      alerts.push({ title: `${cat.icon || ''} ${cat.name} at ${pct.toFixed(0)}%`, text: `You've used ${formatMoney(spent)} of ${formatMoney(budget)}. ${formatMoney(budget - spent)} still available in this category — you're staying aware.` });
    }
  });
  if (alerts.length) {
    const a = alerts[0];
    document.getElementById('nudgeTitle').textContent = a.title;
    document.getElementById('nudgeText').textContent = a.text;
    banner.classList.remove('hidden');
  } else {
    banner.classList.add('hidden');
  }
}


// ===================== Render =====================
function renderSummary() {
  const { income, expenses, saved, afterExpenses, balance } = getTotals();
  const incEl = document.getElementById('totalIncome');
  const expEl = document.getElementById('totalExpenses');
  const savEl = document.getElementById('totalSaved');
  if (incEl) incEl.textContent = formatMoney(income);
  if (expEl) expEl.textContent = formatMoney(expenses);
  if (savEl) savEl.textContent = formatMoney(saved);
  const balEl = document.getElementById('balance');
  if (balEl) {
    balEl.textContent = formatMoney(balance);
    balEl.style.color = balance >= 0 ? 'var(--primary)' : 'var(--danger)';
  }
  const hint = document.getElementById('salaryLeftHint');
  if (hint) {
    if (income <= 0) {
      hint.textContent = 'Add income to see your balance';
    } else {
      hint.textContent = expenses > 0 || saved > 0
        ? `Income ${formatMoney(income)} − spent ${formatMoney(expenses)} − saved ${formatMoney(saved)}`
        : 'Income minus expenses and savings';
    }
  }
  // Keep balance card label in sync with language if needed
  const balLabel = document.querySelector('.summary-card.balance .card-label');
  if (balLabel && !balLabel.dataset.custom) {
    balLabel.textContent = typeof t === 'function' ? (t('balance') || 'Balance') : 'Balance';
  }
}



// ===================== Salary-linked pie chart (new) =====================
function getSalaryPieData() {
  const { income, expenses, saved, balance } = getTotals();
  const salary = Number(income) || 0;

  // Empty state — no salary yet
  if (salary <= 0) {
    return {
      salary: 0,
      slices: [],
      empty: true,
      message: 'Add your salary to see the chart',
    };
  }

  // Everything is a share of salary
  const spent = Math.max(0, Number(expenses) || 0);
  const saveAmt = Math.max(0, Number(saved) || 0);
  let left = salary - spent - saveAmt;

  const slices = [];
  if (spent > 0) {
    slices.push({ key: 'expenses', name: 'Expenses', amount: spent, color: '#f87171', icon: '💸' });
  }
  if (saveAmt > 0) {
    slices.push({ key: 'saved', name: 'Saved', amount: saveAmt, color: '#38bdf8', icon: '🏦' });
  }
  if (left > 0.009) {
    slices.push({ key: 'remaining', name: 'Remaining', amount: left, color: '#22c55e', icon: '✅' });
  } else if (left < -0.009) {
    slices.push({ key: 'over', name: 'Over salary', amount: Math.abs(left), color: '#ef4444', icon: '📌' });
  }

  // If salary added but nothing spent/saved yet — full green ring
  if (slices.length === 0) {
    slices.push({ key: 'remaining', name: 'Remaining', amount: salary, color: '#22c55e', icon: '✅' });
  }

  return { salary, slices, empty: false, message: '' };
}

function polarToCartesian(cx, cy, r, angleDeg) {
  const rad = ((angleDeg - 90) * Math.PI) / 180;
  return { x: cx + r * Math.cos(rad), y: cy + r * Math.sin(rad) };
}

function describeDonutSlice(cx, cy, rOuter, rInner, startAngle, endAngle) {
  const large = endAngle - startAngle > 180 ? 1 : 0;
  const p1 = polarToCartesian(cx, cy, rOuter, endAngle);
  const p2 = polarToCartesian(cx, cy, rOuter, startAngle);
  const p3 = polarToCartesian(cx, cy, rInner, startAngle);
  const p4 = polarToCartesian(cx, cy, rInner, endAngle);
  return [
    'M', p1.x, p1.y,
    'A', rOuter, rOuter, 0, large, 0, p2.x, p2.y,
    'L', p3.x, p3.y,
    'A', rInner, rInner, 0, large, 1, p4.x, p4.y,
    'Z',
  ].join(' ');
}

function renderPieChart() {
  const svg = document.getElementById('pieChart');
  const legend = document.getElementById('pieLegend');
  const breakdown = document.getElementById('planBreakdown');
  const pieTotalEl = document.getElementById('pieTotal');
  const hint = document.getElementById('salaryPieHint');
  if (!svg) return;

  const data = getSalaryPieData();
  const cx = 100, cy = 100, rOuter = 84, rInner = 52;

  // Center = total salary
  if (pieTotalEl) {
    pieTotalEl.textContent = data.salary > 0 ? formatMoney(data.salary) : '—';
  }
  if (hint) {
    hint.textContent = data.empty
      ? 'Add your salary to see the chart'
      : 'Updates when you add salary, expenses or savings';
  }

  if (data.empty) {
    // Empty ring
    svg.innerHTML = `<circle cx="${cx}" cy="${cy}" r="${(rOuter + rInner) / 2}" fill="none" stroke="#2a3344" stroke-width="${rOuter - rInner}" />`;
    if (legend) legend.innerHTML = '<div class="plan-empty">No salary yet — add income first</div>';
    if (breakdown) breakdown.innerHTML = '';
    return;
  }

  const sum = data.slices.reduce((s, x) => s + x.amount, 0) || 1;
  let angle = 0;
  const paths = [];

  // Full single colour if only one slice
  if (data.slices.length === 1) {
    const s = data.slices[0];
    paths.push(`<circle cx="${cx}" cy="${cy}" r="${(rOuter + rInner) / 2}" fill="none" stroke="${s.color}" stroke-width="${rOuter - rInner}" />`);
  } else {
    data.slices.forEach((s) => {
      const sweep = (s.amount / sum) * 360;
      // Avoid zero-length arcs
      const end = angle + Math.max(sweep, 0.3);
      const d = describeDonutSlice(cx, cy, rOuter, rInner, angle, end >= angle + 360 ? angle + 359.99 : end);
      paths.push(`<path d="${d}" fill="${s.color}" stroke="#0f1419" stroke-width="1"></path>`);
      angle += sweep;
    });
  }

  // Inner disc so center text sits cleanly
  paths.push(`<circle cx="${cx}" cy="${cy}" r="${rInner - 1}" fill="#1a1d27" />`);
  svg.innerHTML = paths.join('');

  if (legend) {
    legend.innerHTML = data.slices.map(s => {
      const pct = Math.round((s.amount / data.salary) * 100);
      return `<div class="legend-item">
        <span class="legend-dot" style="background:${s.color}"></span>
        <span class="legend-name">${s.icon || ''} ${s.name}</span>
        <span class="legend-amount">${formatMoney(s.amount)}</span>
        <span class="legend-pct">${pct}%</span>
      </div>`;
    }).join('');
  }

  if (breakdown) {
    breakdown.innerHTML =
      `<div class="plan-row plan-row-salary">
        <div class="plan-row-left"><span>💼</span><span>Total salary</span></div>
        <div><strong>${formatMoney(data.salary)}</strong></div>
      </div>` +
      data.slices.map(s => {
        const pct = Math.round((s.amount / data.salary) * 100);
        return `<div class="plan-row">
          <div class="plan-row-left"><span>${s.icon || ''}</span><span>${s.name}</span></div>
          <div><strong>${formatMoney(s.amount)}</strong> <span class="hint">${pct}%</span></div>
        </div>`;
      }).join('');
  }
}


function renderInsights() {
  const container = document.getElementById('insightsContent');
  if (!container) return;
  const { income, expenses, saved } = getTotals();
  const { breakdown, total } = getExpenseBreakdown();
  const { savingsRate, tips } = getSavingsTips();

  let breakdownHtml = breakdown.length === 0
    ? '<p class="insight-desc">No expenses this month yet.</p>'
    : breakdown.map(b => {
        const pct = total > 0 ? ((b.amount / total) * 100).toFixed(0) : 0;
        return `<div style="display:flex;justify-content:space-between;font-size:0.82rem;margin:0.2rem 0">
          <span>${b.icon || ''} ${b.name}</span>
          <span style="font-family:'JetBrains Mono',monospace">${formatMoney(b.amount)} <span style="color:var(--text-muted)">(${pct}%)</span></span>
        </div>`;
      }).join('');

  const suggestedSave = income > 0 ? Math.max(Math.round(income * 0.2), 0) : 0;

  container.innerHTML = `
    <div class="insight-card calc">
      <h4>Monthly Expense Breakdown</h4>
      <div class="insight-value">${formatMoney(expenses)}</div>
      <div class="insight-desc">Total spent this month</div>
      <div style="margin-top:0.5rem">${breakdownHtml}</div>
    </div>
    <div class="insight-card ${savingsRate >= 20 ? 'good' : savingsRate >= 10 ? 'tip' : 'warning'}">
      <h4>Savings Rate</h4>
      <div class="insight-value">${savingsRate.toFixed(1)}%</div>
      <div class="insight-desc">
        Saved ${formatMoney(saved)} of ${formatMoney(income)} income.
        <div class="savings-rate">Target: <span>20%+</span> of income</div>
      </div>
    </div>
    <div class="insight-card tip">
      <h4>How to Grow Your Savings</h4>
      <div class="insight-desc">Suggested to save this month:</div>
      <div class="insight-value" style="font-size:1.1rem;color:var(--saving)">${formatMoney(suggestedSave)}</div>
      <ul class="tip-list">${tips.slice(0, 5).map(t => `<li>${t}</li>`).join('')}</ul>
    </div>
  `;
}

function renderCategories() {
  const list = document.getElementById('categoriesList');
  if (!state.categories.length) {
    list.innerHTML = `<div class="empty-state">No categories. Tap + Category</div>`;
    updateSelects();
    return;
  }

  list.innerHTML = state.categories.map(cat => {
    const spent = getCategorySpent(cat.id);
    const budget = Number(cat.budget) || 0;
    const pct = budget > 0 ? Math.min(100, (spent / budget) * 100) : 0;
    const over = budget > 0 && spent > budget;
    const fillColor = over ? 'var(--danger)' : cat.color;
    return `
      <div class="category-item" data-id="${cat.id}">
        <div class="cat-header">
          <div class="cat-name">
            <span class="cat-icon">${cat.icon || '📁'}</span>
            <span class="cat-name-text">${escapeHtml(cat.name)}</span>
            <button class="cat-name-edit rename-cat" title="Rename">✎ rename</button>
          </div>
          <div class="cat-actions">
            <button class="cat-action-btn edit-cat" title="Edit budget">⚙</button>
            <button class="cat-action-btn delete-cat" title="Delete">✕</button>
          </div>
        </div>
        <div class="cat-amounts">
          <span class="spent">${formatMoney(spent)}</span>
          ${budget > 0 ? ` / ${formatMoney(budget)}` : ' (no budget)'}
          ${over ? ' <span style="color:var(--warning)">above plan</span>' : ''}
        </div>
        ${budget > 0 ? `<div class="progress-bar"><div class="progress-fill" style="width:${pct}%;background:${fillColor}"></div></div>` : ''}
      </div>`;
  }).join('');

  list.querySelectorAll('.rename-cat').forEach(btn => {
    btn.addEventListener('click', e => {
      const id = e.target.closest('.category-item').dataset.id;
      const cat = state.categories.find(c => c.id === id);
      if (!cat) return;
      const newName = prompt('New name for this category:', cat.name);
      if (newName && newName.trim()) {
        cat.name = newName.trim();
        save();
        render();
      }
    });
  });

  list.querySelectorAll('.edit-cat').forEach(btn => {
    btn.addEventListener('click', e => {
      openCategoryModal(e.target.closest('.category-item').dataset.id);
    });
  });

  list.querySelectorAll('.delete-cat').forEach(btn => {
    btn.addEventListener('click', e => {
      const id = e.target.closest('.category-item').dataset.id;
      if (confirm('Delete this category?')) {
        state.categories = state.categories.filter(c => c.id !== id);
        save();
        render();
      }
    });
  });

  updateSelects();
}

function updateSelects() {
  const expSelect = document.getElementById('expCategory');
  const savSelect = document.getElementById('savGoal');
  if (expSelect) {
    expSelect.innerHTML = state.categories.length
      ? state.categories.map(c => `<option value="${c.id}">${c.icon || ''} ${c.name}</option>`).join('')
      : '<option value="">No categories</option>';
  }
  if (savSelect) {
    savSelect.innerHTML = state.goals.length
      ? state.goals.map(g => `<option value="${g.id}">${g.name}</option>`).join('')
      : '<option value="">Create a goal first</option>';
  }
}

function renderExpenseList() {
  const list = document.getElementById('expenseList');
  if (!list) return;
  let txs = getMonthTransactions().filter(t => t.type === 'expense').sort((a, b) => new Date(b.date) - new Date(a.date));
  if (typeof _expenseSearch === 'string' && _expenseSearch) {
    txs = txs.filter(t => (t.desc || '').toLowerCase().includes(_expenseSearch) || (categoryName(t.categoryId) || '').toLowerCase().includes(_expenseSearch));
  }
  if (typeof _expenseFilterCat === 'string' && _expenseFilterCat) {
    txs = txs.filter(t => t.categoryId === _expenseFilterCat);
  }
  if (!txs.length) {
    list.innerHTML = `<div class="empty-state">No expenses this month · tap an item later to edit</div>`;
    return;
  }
  list.innerHTML = txs.map(t => {
    const cat = state.categories.find(c => c.id === t.categoryId);
    const meta = cat ? `${cat.icon || ''} ${cat.name}` : 'Uncategorized';
    return `
      <div class="tx-item tx-tappable" data-id="${t.id}" role="button" tabindex="0" title="Tap to edit">
        <div class="tx-left">
          <div class="tx-desc">${escapeHtml(t.desc)}</div>
          <div class="tx-meta">${meta} · ${t.date}${t.wallet ? ` · ${t.wallet}` : ""}${t.receipt ? " · 📎" : ""} · tap to edit</div>
        </div>
        <div style="display:flex;align-items:center">
          <div class="tx-amount expense">−${formatMoney(t.amount)}</div>
          <button type="button" class="tx-delete" title="Delete" aria-label="Delete">✕</button>
        </div>
      </div>`;
  }).join('');
  attachTransactionShortcuts(list);
}

function renderIncomeList() {
  const list = document.getElementById('incomeList');
  if (!list) return;
  let txs = getMonthTransactions().filter(t => t.type === 'income').sort((a, b) => new Date(b.date) - new Date(a.date));
  const iq = (document.getElementById('incomeSearch') || {}).value || '';
  if (iq.trim()) {
    const q = iq.trim().toLowerCase();
    txs = txs.filter(t => (t.desc || '').toLowerCase().includes(q));
  }
  if (!txs.length) {
    list.innerHTML = `<div class="empty-state">No income recorded · tap an item later to edit</div>`;
    return;
  }
  list.innerHTML = txs.map(t => `
    <div class="tx-item tx-tappable" data-id="${t.id}" role="button" tabindex="0" title="Tap to edit">
      <div class="tx-left">
        <div class="tx-desc">${escapeHtml(t.desc)}</div>
        <div class="tx-meta">${t.date} · tap to edit</div>
      </div>
      <div style="display:flex;align-items:center">
        <div class="tx-amount income">+${formatMoney(t.amount)}</div>
        <button type="button" class="tx-delete" title="Delete" aria-label="Delete">✕</button>
      </div>
    </div>`).join('');
  attachTransactionShortcuts(list);
}

function openTxEditor(id) {
  const tx = state.transactions.find(t => t.id === id);
  if (!tx || (tx.type !== 'expense' && tx.type !== 'income')) return;
  const modal = document.getElementById('txEditModal');
  if (!modal) return;
  document.getElementById('txEditId').value = tx.id;
  document.getElementById('txEditTitle').textContent = tx.type === 'income' ? 'Edit income' : 'Edit expense';
  document.getElementById('txEditDesc').value = tx.desc || '';
  document.getElementById('txEditAmount').value = tx.amount;
  document.getElementById('txEditDate').value = tx.date || dateInViewedMonth(1);
  const rw = document.getElementById('txEditReceiptWrap');
  const ri = document.getElementById('txEditReceiptImg');
  if (rw && ri) {
    if (tx.receipt) { rw.classList.remove('hidden'); ri.src = tx.receipt; }
    else { rw.classList.add('hidden'); ri.removeAttribute('src'); }
  }
  const catLabel = document.getElementById('txEditCatLabel');
  const catSel = document.getElementById('txEditCategory');
  if (tx.type === 'income') {
    catLabel.style.display = 'none';
    catSel.style.display = 'none';
    catSel.innerHTML = '<option value="income">Income</option>';
    catSel.value = 'income';
  } else {
    catLabel.style.display = '';
    catSel.style.display = '';
    catSel.innerHTML = state.categories.map(c =>
      `<option value="${c.id}">${c.icon || ''} ${c.name}</option>`
    ).join('') || '<option value="">No categories</option>';
    catSel.value = tx.categoryId || '';
  }
  modal.classList.remove('hidden');
}

function attachTransactionShortcuts(list) {
  list.querySelectorAll('.tx-tappable').forEach(row => {
    row.addEventListener('click', e => {
      if (e.target.closest('.tx-delete')) return;
      openTxEditor(row.dataset.id);
    });
    row.addEventListener('keydown', e => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        openTxEditor(row.dataset.id);
      }
    });
  });
  list.querySelectorAll('.tx-delete').forEach(btn => {
    btn.addEventListener('click', e => {
      e.preventDefault();
      e.stopPropagation();
      const id = e.target.closest('.tx-item').dataset.id;
      const tx = state.transactions.find(t => t.id === id);
      if (!tx) return;
      if (!confirm('Delete this entry?')) return;
      if (tx.type === 'saving') {
        const goal = state.goals.find(g => g.id === tx.categoryId);
        if (goal) goal.current = Math.max(0, Number(goal.current) - Number(tx.amount));
      }
      state.transactions = state.transactions.filter(t => t.id !== id);
      save();
      render();
    });
  });
}

function setupTxEditor() {
  const form = document.getElementById('txEditForm');
  const modal = document.getElementById('txEditModal');
  const cancel = document.getElementById('txEditCancel');
  const del = document.getElementById('txEditDelete');
  if (!form || !modal) return;

  if (cancel) {
    cancel.addEventListener('click', () => modal.classList.add('hidden'));
  }
  if (del) {
    del.addEventListener('click', () => {
      const id = document.getElementById('txEditId').value;
      const tx = state.transactions.find(t => t.id === id);
      if (!tx) return;
      if (!confirm('Delete this entry?')) return;
      state.transactions = state.transactions.filter(t => t.id !== id);
      save();
      modal.classList.add('hidden');
      render();
    });
  }
  form.addEventListener('submit', e => {
    e.preventDefault();
    const id = document.getElementById('txEditId').value;
    const tx = state.transactions.find(t => t.id === id);
    if (!tx) return;
    const desc = document.getElementById('txEditDesc').value.trim();
    const amount = Number(document.getElementById('txEditAmount').value);
    const date = document.getElementById('txEditDate').value;
    const categoryId = document.getElementById('txEditCategory').value;
    if (!desc || !amount || amount <= 0 || !date) {
      alert('Fill description, amount and date');
      return;
    }
    tx.desc = desc;
    tx.amount = amount;
    tx.date = date;
    tx.month = getMonthKey(date);
    if (tx.type === 'expense') tx.categoryId = categoryId;
    if (tx.type === 'income') tx.categoryId = 'income';
    save();
    modal.classList.add('hidden');
    // Stay on the month of the edited entry
    state.currentMonth = tx.month;
    save();
    syncFormDatesToViewedMonth();
    render();
  });
}

function attachDeleteHandlers(list) {
  // legacy alias — prefer attachTransactionShortcuts
  attachTransactionShortcuts(list);
}

function renderGoals() {
  const list = document.getElementById('goalsList');
  if (!state.goals.length) {
    list.innerHTML = `<div class="empty-state">No savings goals yet. Tap + New Goal</div>`;
    updateSelects();
    return;
  }

  list.innerHTML = state.goals.map(g => {
    const current = Number(g.current) || 0;
    const target = Number(g.target) || 1;
    const pct = Math.min(100, (current / target) * 100);
    return `
      <div class="goal-card" data-id="${g.id}">
        <div class="goal-header">
          <div class="goal-name-wrap">
            <span class="goal-name">${escapeHtml(g.name)}</span>
            <button class="goal-rename rename-goal">✎ rename</button>
          </div>
          <div class="goal-pct">${pct.toFixed(0)}%</div>
        </div>
        <div class="goal-amounts">${formatMoney(current)} / ${formatMoney(target)}</div>
        <div class="progress-bar">
          <div class="progress-fill" style="width:${pct}%;background:var(--saving)"></div>
        </div>
        <div class="goal-actions">
          <button class="btn-sm add-to-goal">+ Add Money</button>
          <button class="btn-sm edit-goal">Edit</button>
          <button class="btn-sm delete-goal">Delete</button>
        </div>
      </div>`;
  }).join('');

  list.querySelectorAll('.rename-goal').forEach(btn => {
    btn.addEventListener('click', e => {
      const id = e.target.closest('.goal-card').dataset.id;
      const goal = state.goals.find(g => g.id === id);
      if (!goal) return;
      const newName = prompt('Rename this goal:', goal.name);
      if (newName && newName.trim()) {
        goal.name = newName.trim();
        save();
        render();
      }
    });
  });

  list.querySelectorAll('.add-to-goal').forEach(btn => {
    btn.addEventListener('click', e => {
      const id = e.target.closest('.goal-card').dataset.id;
      const amountStr = prompt('How much to add?');
      if (amountStr === null) return;
      const amount = Number(amountStr);
      if (isNaN(amount) || amount <= 0) { alert('Enter a valid amount'); return; }
      const goal = state.goals.find(g => g.id === id);
      if (!goal) return;
      goal.current = Number(goal.current) + amount;
      state.transactions.push({
        id: uid(), type: 'saving', desc: `Contribution to ${goal.name}`,
        amount, categoryId: id, date: new Date().toISOString().slice(0, 10), month: state.currentMonth,
      });
      save();
      render();
    });
  });

  list.querySelectorAll('.edit-goal').forEach(btn => {
    btn.addEventListener('click', e => {
      openGoalModal(e.target.closest('.goal-card').dataset.id);
    });
  });

  list.querySelectorAll('.delete-goal').forEach(btn => {
    btn.addEventListener('click', e => {
      const id = e.target.closest('.goal-card').dataset.id;
      if (confirm('Delete this goal?')) {
        state.goals = state.goals.filter(g => g.id !== id);
        save();
        render();
      }
    });
  });

  updateSelects();
}

function renderMonthLabel() {
  document.getElementById('currentMonthLabel').textContent = formatMonthLabel(state.currentMonth);
}

function renderReminderStatus() {
  const statusEl = document.getElementById('reminderStatus');
  const btn = document.getElementById('toggleReminderBtn');
  if (!statusEl || !btn) return;
  if (state.reminderEnabled) {
    statusEl.textContent = '✅ Reminder ON — banner + sound at start of each month.';
    btn.textContent = 'Disable Monthly Reminder';
  } else {
    statusEl.textContent = 'Reminders are off.';
    btn.textContent = 'Enable Monthly Reminder';
  }
}

function checkAndShowReminder() {
  const banner = document.getElementById('reminderBanner');
  if (!banner) return;
  const thisMonth = getMonthKey(new Date());
  const day = new Date().getDate();
  const shouldShow = state.reminderEnabled && state.lastReminderMonth !== thisMonth && day <= 7;
  if (shouldShow) {
    const wasHidden = banner.classList.contains('hidden');
    const { savingsRate } = getSavingsTips();
    document.getElementById('reminderText').textContent =
      `New month! Review expenses, aim for 20%+ savings. Current rate: ${savingsRate.toFixed(1)}%.`;
    banner.classList.remove('hidden');
    // Play sound when the reminder first appears
    if (wasHidden) {
      playReminderSound();
      sendTestNotification();
    }
  } else {
    banner.classList.add('hidden');
  }
}

function render() {
  renderMonthLabel();
  renderDemoGuideBanner();
  renderSummary();
  if (typeof renderBudgetHealth === 'function') renderBudgetHealth();
  if (typeof renderUpcomingBills === 'function') renderUpcomingBills();
  if (typeof renderBalanceTrend === 'function') renderBalanceTrend();
  if (typeof populateExpenseFilter === 'function') populateExpenseFilter();
  renderPieChart();
  renderInsights();
  renderIncomeSavingsPlan();
  renderMonthCompare();
  renderDebts();
  renderRecurring();
  renderSubscriptions();
  checkBudgetNudges();
  checkPositiveReinforcement();
  applyFocusLayout();
  renderCategories();
  renderExpenseList();
  renderIncomeList();
  renderGoals();
  renderReminderStatus();
  checkAndShowReminder();
}

// ===================== Modals =====================
function openCategoryModal(id = null) {
  editingCategoryId = id;
  const modal = document.getElementById('categoryModal');
  const title = document.getElementById('categoryModalTitle');
  if (id) {
    const cat = state.categories.find(c => c.id === id);
    if (!cat) return;
    title.textContent = 'Edit Category';
    document.getElementById('catName').value = cat.name;
    document.getElementById('catBudget').value = cat.budget;
    document.getElementById('catColor').value = cat.color;
    document.getElementById('catIcon').value = cat.icon || '';
  } else {
    title.textContent = 'Add Category';
    document.getElementById('catName').value = '';
    document.getElementById('catBudget').value = '';
    document.getElementById('catColor').value = '#6366f1';
    document.getElementById('catIcon').value = '';
  }
  modal.classList.remove('hidden');
}

function openGoalModal(id = null) {
  editingGoalId = id;
  const modal = document.getElementById('goalModal');
  const title = document.getElementById('goalModalTitle');
  if (id) {
    const g = state.goals.find(x => x.id === id);
    if (!g) return;
    title.textContent = 'Edit Goal';
    document.getElementById('goalName').value = g.name;
    document.getElementById('goalTarget').value = g.target;
    document.getElementById('goalCurrent').value = g.current;
  } else {
    title.textContent = 'New Savings Goal';
    document.getElementById('goalName').value = '';
    document.getElementById('goalTarget').value = '';
    document.getElementById('goalCurrent').value = '0';
  }
  modal.classList.remove('hidden');
}


// ===================== Reminder sound =====================
let _audioCtx = null;

function getAudioContext() {
  if (!_audioCtx) {
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return null;
    _audioCtx = new AC();
  }
  return _audioCtx;
}

function playReminderSound() {
  if (state && state.reminderSound === false) return;
  try {
    const ctx = getAudioContext();
    if (!ctx) return;
    if (ctx.state === 'suspended') ctx.resume();

    const now = ctx.currentTime;
    // Soft two-tone chime (pleasant, not alarm-like)
    const tones = [523.25, 659.25, 783.99]; // C5 E5 G5
    tones.forEach((freq, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.value = freq;
      const start = now + i * 0.12;
      gain.gain.setValueAtTime(0, start);
      gain.gain.linearRampToValueAtTime(0.18, start + 0.03);
      gain.gain.exponentialRampToValueAtTime(0.001, start + 0.55);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(start);
      osc.stop(start + 0.6);
    });
  } catch (e) {
    console.warn('Reminder sound failed', e);
  }
}


// ===================== Notifications =====================
async function requestNotificationPermission() {
  if (!('Notification' in window)) { alert('Notifications not supported'); return false; }
  if (Notification.permission === 'granted') return true;
  if (Notification.permission !== 'denied') {
    return (await Notification.requestPermission()) === 'granted';
  }
  return false;
}

function sendTestNotification() {
  playReminderSound();
  if (typeof Notification !== 'undefined' && Notification.permission === 'granted') {
    try {
      new Notification('Finance Manager', {
        body: 'Monthly reminder: review expenses and savings for this month.',
        silent: false,
      });
    } catch (e) {}
  }
}

// ===================== Events =====================
function setupEventListeners() {
  const clearDemo1 = document.getElementById('clearDemoBtn');
  const clearDemo2 = document.getElementById('clearDemoBtn2');
  if (clearDemo1 && typeof clearDemoData === 'function') clearDemo1.addEventListener('click', () => clearDemoData());
  if (clearDemo2 && typeof clearDemoData === 'function') clearDemo2.addEventListener('click', () => clearDemoData());

  const applySaveTargetBtn = document.getElementById('applySaveTarget');
  if (applySaveTargetBtn) {
    applySaveTargetBtn.addEventListener('click', () => {
      if (typeof applySalaryPlanToApp === 'function') applySalaryPlanToApp();
    });
  }

  document.getElementById('prevMonth').addEventListener('click', () => {
    const [y, m] = state.currentMonth.split('-').map(Number);
    state.currentMonth = getMonthKey(new Date(y, m - 2, 1));
    save();
    syncFormDatesToViewedMonth();
    render();
  });
  document.getElementById('nextMonth').addEventListener('click', () => {
    const [y, m] = state.currentMonth.split('-').map(Number);
    state.currentMonth = getMonthKey(new Date(y, m, 1));
    save();
    syncFormDatesToViewedMonth();
    render();
  });

  document.getElementById('addCategoryBtn').addEventListener('click', () => openCategoryModal());
  document.getElementById('cancelCat').addEventListener('click', () => {
    document.getElementById('categoryModal').classList.add('hidden');
    editingCategoryId = null;
  });

  document.getElementById('categoryForm').addEventListener('submit', e => {
    e.preventDefault();
    const name = document.getElementById('catName').value.trim();
    const budget = Number(document.getElementById('catBudget').value) || 0;
    const color = document.getElementById('catColor').value;
    const icon = document.getElementById('catIcon').value.trim() || '📁';
    if (!name) return alert('Enter a name');
    if (editingCategoryId) {
      const cat = state.categories.find(c => c.id === editingCategoryId);
      if (cat) { cat.name = name; cat.budget = budget; cat.color = color; cat.icon = icon; }
    } else {
      state.categories.push({ id: uid(), name, budget, color, icon });
    }
    save();
    document.getElementById('categoryModal').classList.add('hidden');
    editingCategoryId = null;
    render();
  });

  // Expense form
  document.getElementById('expenseForm').addEventListener('submit', e => {
    e.preventDefault();
    const desc = document.getElementById('expDesc').value.trim();
    const amount = Number(document.getElementById('expAmount').value);
    const categoryId = document.getElementById('expCategory').value;
    let date = document.getElementById('expDate').value;
    const wallet = (document.getElementById('expWallet') || {}).value || 'bank';
    const receiptInput = document.getElementById('expReceipt');
    if (!desc || !amount || amount <= 0 || !categoryId) return alert('Fill description, amount and category');
    if (!date || getMonthKey(date) !== state.currentMonth) {
      date = dateInViewedMonth(1);
      document.getElementById('expDate').value = date;
    }

    const finish = (receiptData) => {
      state.transactions.push({
        id: uid(), type: 'expense', desc, amount, categoryId, date,
        month: state.currentMonth, isDemo: false, wallet, receipt: receiptData || null,
      });
      save();
      document.getElementById('expDesc').value = '';
      document.getElementById('expAmount').value = '';
      if (receiptInput) receiptInput.value = '';
      document.getElementById('expDate').value = dateInViewedMonth(1);
      render();
      const { balance, income, expenses } = getTotals();
      if (income > 0 && typeof showCelebration === 'function') {
        showCelebration(
          'Expense logged',
          `Balance: ${formatMoney(balance)} (spent ${formatMoney(expenses)} of ${formatMoney(income)})`,
          '💸'
        );
      }
    };

    const file = receiptInput && receiptInput.files && receiptInput.files[0];
    if (file) {
      if (file.size > 1.5 * 1024 * 1024) {
        alert('Receipt image is large; saving without photo. Use under 1.5MB.');
        finish(null);
        return;
      }
      const reader = new FileReader();
      reader.onload = () => finish(reader.result);
      reader.onerror = () => finish(null);
      reader.readAsDataURL(file);
    } else {
      finish(null);
    }
  });

  // Saving form
  document.getElementById('savingForm').addEventListener('submit', e => {
    e.preventDefault();
    const desc = document.getElementById('savDesc').value.trim() || 'Savings contribution';
    const amount = Number(document.getElementById('savAmount').value);
    const categoryId = document.getElementById('savGoal').value;
    let date = document.getElementById('savDate').value;
    if (!amount || amount <= 0 || !categoryId) return alert('Fill amount and goal');
    const goal = state.goals.find(g => g.id === categoryId);
    if (goal) goal.current = Number(goal.current) + amount;
    if (!date || getMonthKey(date) !== state.currentMonth) {
      date = dateInViewedMonth(1);
      document.getElementById('savDate').value = date;
    }
    state.transactions.push({
      id: uid(), type: 'saving', desc, amount, categoryId, date, month: state.currentMonth, isDemo: false,
    });
    save();
    document.getElementById('savDesc').value = '';
    document.getElementById('savAmount').value = '';
    document.getElementById('savDate').value = dateInViewedMonth(1);
    render();
  });

  // Income form
  document.getElementById('incomeForm').addEventListener('submit', e => {
    e.preventDefault();
    const desc = document.getElementById('incDesc').value.trim();
    const amount = Number(document.getElementById('incAmount').value);
    let date = document.getElementById('incDate').value;
    if (!desc || !amount || amount <= 0) return alert('Fill description and amount');
    if (!date || getMonthKey(date) !== state.currentMonth) {
      date = dateInViewedMonth(1);
      document.getElementById('incDate').value = date;
    }
    state.transactions.push({
      id: uid(), type: 'income', desc, amount, categoryId: 'income', date, month: state.currentMonth, isDemo: false,
    });
    save();
    document.getElementById('incDesc').value = '';
    document.getElementById('incAmount').value = '';
    document.getElementById('incDate').value = dateInViewedMonth(1);
    render();
    showSalaryPlan(getTotals().income);
  });

  // Goals
  document.getElementById('addGoalBtn').addEventListener('click', () => openGoalModal());
  document.getElementById('cancelGoal').addEventListener('click', () => {
    document.getElementById('goalModal').classList.add('hidden');
    editingGoalId = null;
  });
  document.getElementById('goalForm').addEventListener('submit', e => {
    e.preventDefault();
    const name = document.getElementById('goalName').value.trim();
    const target = Number(document.getElementById('goalTarget').value);
    const current = Number(document.getElementById('goalCurrent').value) || 0;
    if (!name || !target || target <= 0) return alert('Enter valid name and target');
    if (editingGoalId) {
      const g = state.goals.find(x => x.id === editingGoalId);
      if (g) { g.name = name; g.target = target; g.current = current; }
    } else {
      state.goals.push({ id: uid(), name, target, current });
    }
    save();
    document.getElementById('goalModal').classList.add('hidden');
    editingGoalId = null;
    render();
  });

  // Settings
  const settingsBtn = document.getElementById('settingsBtn');
  if (settingsBtn) {
    settingsBtn.addEventListener('click', () => {
      if (typeof setDashboardView === 'function') setDashboardView('settings');
    });
  }
  // closeSettings removed — settings is a dashboard page
  document.getElementById('saveSettings').addEventListener('click', () => {
    saveSettingsFromForm();
    render();
    if (typeof showCelebration === 'function') {
      showCelebration('Settings saved', 'Your language, theme and preferences are updated.', '⚙');
    }
  });
  const currencyPreset = document.getElementById('currencyPreset');
  if (currencyPreset) {
    currencyPreset.addEventListener('change', () => {
      if (currencyPreset.value) {
        document.getElementById('currencyInput').value = currencyPreset.value;
      }
    });
  }
  
  const logoutBtn = document.getElementById('logoutBtn');
  if (logoutBtn) {
    logoutBtn.addEventListener('click', () => {
      if (confirm('Log out of your account?')) {
        clearSession();
        /* settings is page */
        const chip = document.getElementById('userChip');
        if (chip) chip.remove();
        showAuth();
      }
    });
  }

  document.getElementById('clearDataBtn').addEventListener('click', () => {
    if (confirm('Clear all data and restore sample?')) {
      localStorage.removeItem(STORAGE_KEY);
      state = createSampleData();
      save();
      /* settings is page */
      render();
    }
  });

  const testSoundBtn = document.getElementById('testReminderSoundBtn');
  if (testSoundBtn) {
    testSoundBtn.addEventListener('click', () => {
      // unlock audio on user gesture
      const ctx = getAudioContext();
      if (ctx && ctx.state === 'suspended') ctx.resume();
      playReminderSound();
    });
  }
  document.getElementById('toggleReminderBtn').addEventListener('click', async () => {
    if (state.reminderEnabled) {
      state.reminderEnabled = false;
    } else {
      await requestNotificationPermission();
      state.reminderEnabled = true;
      state.lastReminderMonth = null;
      sendTestNotification();
    }
    save();
    renderReminderStatus();
    checkAndShowReminder();
  });

  document.getElementById('dismissReminder').addEventListener('click', () => {
    state.lastReminderMonth = getMonthKey(new Date());
    save();
    document.getElementById('reminderBanner').classList.add('hidden');
  });

  document.getElementById('enableNotifBtn').addEventListener('click', async () => {
    if (await requestNotificationPermission()) {
      sendTestNotification();
      alert('Notifications enabled!');
    } else {
      alert('Allow notifications in browser settings.');
    }
  });


  // AI Coach
  const coachForm = document.getElementById('coachForm');
  if (coachForm) {
    coachForm.addEventListener('submit', e => {
      e.preventDefault();
      const input = document.getElementById('coachInput');
      const q = (input.value || '').trim();
      if (!q) return;
      appendCoachMessage(q, 'user');
      input.value = '';
      const answer = answerCoach(q);
      setTimeout(() => appendCoachMessage(answer, 'bot'), 200);
    });
  }
  document.querySelectorAll('.coach-q').forEach(btn => {
    btn.addEventListener('click', () => {
      const q = btn.dataset.q;
      appendCoachMessage(q, 'user');
      setTimeout(() => appendCoachMessage(answerCoach(q), 'bot'), 200);
    });
  });

  // Voice
  const voiceBtn = document.getElementById('voiceBtn');
  if (voiceBtn) voiceBtn.addEventListener('click', startVoiceLog);

  // Nudge dismiss
  const dismissNudge = document.getElementById('dismissNudge');
  if (dismissNudge) {
    dismissNudge.addEventListener('click', () => {
      document.getElementById('nudgeBanner').classList.add('hidden');
    });
  }

  document.querySelectorAll('.modal').forEach(modal => {
    modal.addEventListener('click', e => {
      if (e.target === modal) modal.classList.add('hidden');
    });
  });
}





// ===================== Auto salary → full spend/save breakdown =====================
function buildSalaryBreakdown(income) {
  const amount = Number(income) || 0;
  const tier = getTierForIncome(amount);
  const needs = Math.round(amount * tier.needsPct);
  const wants = Math.round(amount * tier.wantsPct);
  const savings = Math.round(amount * tier.savePct);
  const needWeights = { rent: 0.40, food: 0.28, transport: 0.14, utilities: 0.10, misc: 0.08 };
  const categoryBudgets = {};
  Object.keys(needWeights).forEach(id => {
    categoryBudgets[id] = Math.round(needs * needWeights[id]);
  });
  const saveEmergency = Math.round(savings * 0.6);
  const saveGoals = savings - saveEmergency;
  return {
    income: amount,
    tier,
    needs,
    wants,
    savings,
    categoryBudgets,
    saveEmergency,
    saveGoals,
    tips: [
      'Move savings out on payday before you spend anything else.',
      'Needs first: rent, food, transport, utilities — stay near the amounts below.',
      'Wants are flexible: data extras, outings, small treats only from that pot.',
      tier.note || 'Review weekly so small leaks do not eat your savings.',
    ],
  };
}

function renderSalaryBreakdownHtml(plan) {
  const cats = plan.categoryBudgets;
  const catRows = Object.keys(cats).map(id => {
    const cat = state.categories.find(c => c.id === id);
    const name = cat ? `${cat.icon || ''} ${cat.name}` : id;
    return `<div class="salary-row"><span>${name}</span><strong>${formatMoney(cats[id])}</strong></div>`;
  }).join('');
  return `
    <div class="salary-hero">
      <div class="lbl">Salary / income</div>
      <div class="val">${formatMoney(plan.income)}</div>
      <div class="lbl">Plan: ${plan.tier.label} · ${plan.tier.tag}</div>
    </div>
    <div class="plan-split" style="margin:0.85rem 0">
      <div class="plan-split-item needs"><div class="lbl">Needs</div><div class="val">${formatMoney(plan.needs)}</div></div>
      <div class="plan-split-item wants"><div class="lbl">Wants</div><div class="val">${formatMoney(plan.wants)}</div></div>
      <div class="plan-split-item savings"><div class="lbl">Save</div><div class="val">${formatMoney(plan.savings)}</div></div>
    </div>
    <h4 class="compare-subhead">How to spend (needs)</h4>
    <div class="salary-box">${catRows}</div>
    <h4 class="compare-subhead">How to manage & save</h4>
    <div class="salary-box">
      <div class="salary-row"><span>Emergency / buffer</span><strong>${formatMoney(plan.saveEmergency)}</strong></div>
      <div class="salary-row"><span>Goals (laptop, business, etc.)</span><strong>${formatMoney(plan.saveGoals)}</strong></div>
      <div class="salary-row"><span>Wants pot (fun / extras)</span><strong>${formatMoney(plan.wants)}</strong></div>
    </div>
    <ul class="tip-list" style="margin-top:0.75rem">
      ${plan.tips.map(t => `<li>${t}</li>`).join('')}
    </ul>
    <p class="hint" style="margin-top:0.65rem">Emergency milestone for your tier: <strong>${plan.tier.emergency}</strong></p>
  `;
}

let _lastSalaryPlan = null;

function showSalaryPlan(income) {
  const plan = buildSalaryBreakdown(income);
  _lastSalaryPlan = plan;
  const modal = document.getElementById('salaryPlanModal');
  const body = document.getElementById('salaryPlanBody');
  const lead = document.getElementById('salaryPlanLead');
  if (!modal || !body) return;
  if (lead) lead.textContent = `Automatic breakdown from ${formatMoney(plan.income)} income this month`;
  body.innerHTML = renderSalaryBreakdownHtml(plan);
  modal.classList.remove('hidden');
  if (typeof renderIncomeSavingsPlan === 'function') renderIncomeSavingsPlan();
}

function applySalaryPlanToApp(plan) {
  if (!plan) return;
  Object.keys(plan.categoryBudgets).forEach(id => {
    let cat = state.categories.find(c => c.id === id);
    if (!cat) {
      const colors = { rent: '#f59e0b', food: '#22c55e', transport: '#3b82f6', utilities: '#a855f7', misc: '#64748b' };
      const icons = { rent: '🏠', food: '🛒', transport: '🚌', utilities: '💡', misc: '📦' };
      const names = { rent: 'Rent', food: 'Foodstuff', transport: 'Transport', utilities: 'Utilities', misc: 'Miscellaneous' };
      cat = { id, name: names[id] || id, budget: 0, color: colors[id] || '#64748b', icon: icons[id] || '📁' };
      state.categories.push(cat);
    }
    cat.budget = plan.categoryBudgets[id];
    cat.isDemo = false;
  });
  if (!state.goals.length) {
    state.goals.push({
      id: uid(),
      name: 'Emergency Fund',
      target: Math.max(plan.savings * 6, plan.saveEmergency * 3, 50000),
      current: 0,
      isDemo: false,
    });
  }
  state.lastAutoPlan = {
    income: plan.income,
    needs: plan.needs,
    wants: plan.wants,
    savings: plan.savings,
    at: new Date().toISOString(),
    month: state.currentMonth,
  };
  save();
  render();
  if (typeof showCelebration === 'function') {
    showCelebration(
      'Budgets set from your salary',
      `Needs ${formatMoney(plan.needs)} · Wants ${formatMoney(plan.wants)} · Save ${formatMoney(plan.savings)}`,
      '📋'
    );
  }
}

function setupSalaryPlanModal() {
  const close = document.getElementById('salaryPlanClose');
  const apply = document.getElementById('salaryPlanApply');
  const openPlans = document.getElementById('salaryPlanOpenPlans');
  const modal = document.getElementById('salaryPlanModal');
  if (close) close.addEventListener('click', () => modal && modal.classList.add('hidden'));
  if (apply) {
    apply.addEventListener('click', () => {
      if (_lastSalaryPlan) applySalaryPlanToApp(_lastSalaryPlan);
      if (modal) modal.classList.add('hidden');
      if (typeof setDashboardView === 'function') setDashboardView('expenses');
    });
  }
  if (openPlans) {
    openPlans.addEventListener('click', () => {
      if (modal) modal.classList.add('hidden');
      if (typeof setDashboardView === 'function') setDashboardView('plan');
    });
  }
}


// ===================== Savings Plan by Income (₦30k+) =====================
const INCOME_TIERS = [
  {
    id: 't30',
    min: 30000,
    max: 49999,
    label: '₦30,000 – ₦49,000',
    tag: 'Start the habit',
    goal: 'Build the habit + small emergency buffer',
    savePct: 0.18,
    needsPct: 0.65,
    wantsPct: 0.17,
    exampleIncome: 30000,
    emergency: '₦30,000 – ₦50,000',
    note: 'Save at least ₦5,000 on payday. Cut wants first if rent is high.',
  },
  {
    id: 't50',
    min: 50000,
    max: 79999,
    label: '₦50,000 – ₦79,000',
    tag: 'Emergency + 1 goal',
    goal: 'Emergency fund + one clear goal',
    savePct: 0.22,
    needsPct: 0.58,
    wantsPct: 0.20,
    exampleIncome: 50000,
    emergency: '₦100,000 – ₦150,000',
    note: 'Split savings: 60% emergency, 40% goal (phone, course, business float).',
  },
  {
    id: 't80',
    min: 80000,
    max: 119999,
    label: '₦80,000 – ₦119,000',
    tag: '3-month buffer',
    goal: '3 months emergency + named goals',
    savePct: 0.25,
    needsPct: 0.55,
    wantsPct: 0.20,
    exampleIncome: 100000,
    emergency: '₦250,000 – ₦400,000',
    note: 'Example on ₦100k: save ₦25k–₦30k (emergency + main goal + skills).',
  },
  {
    id: 't120',
    min: 120000,
    max: 199999,
    label: '₦120,000 – ₦199,000',
    tag: 'Parallel goals',
    goal: 'Full emergency + parallel goals',
    savePct: 0.27,
    needsPct: 0.53,
    wantsPct: 0.20,
    exampleIncome: 150000,
    emergency: '3–6 months of expenses',
    note: '40% emergency · 40% big goal · 20% growth/skills after safety net.',
  },
  {
    id: 't200',
    min: 200000,
    max: Infinity,
    label: '₦200,000+',
    tag: 'Wealth building',
    goal: 'Safety first, then invest',
    savePct: 0.30,
    needsPct: 0.50,
    wantsPct: 0.20,
    exampleIncome: 200000,
    emergency: '6 months of expenses',
    note: 'Order: emergency → high-interest debt → goals → long-term investing.',
  },
];

function getTierForIncome(income) {
  const n = Number(income) || 0;
  if (n > 0 && n < 30000) {
    return {
      id: 'below',
      min: 0,
      max: 29999,
      label: 'Under ₦30,000',
      tag: 'Starter',
      goal: 'Save something every month — even ₦2,000–₦5,000',
      savePct: 0.12,
      needsPct: 0.70,
      wantsPct: 0.18,
      exampleIncome: n,
      emergency: '₦15,000 – ₦30,000',
      note: 'Focus on habit. Increase % when income rises to ₦30k+.',
    };
  }
  return INCOME_TIERS.find(t => n >= t.min && n <= t.max) || INCOME_TIERS[0];
}

function renderIncomeSavingsPlan() {
  const personal = document.getElementById('incomePlanPersonal');
  const tiersEl = document.getElementById('incomePlanTiers');
  if (!personal || !tiersEl) return;

  const { income } = getTotals();
  const useIncome = income > 0 ? income : 0;
  const tier = getTierForIncome(useIncome || 30000);
  const base = useIncome > 0 ? useIncome : tier.exampleIncome;
  const needs = Math.round(base * tier.needsPct);
  const wants = Math.round(base * tier.wantsPct);
  const savings = Math.round(base * tier.savePct);

  if (useIncome > 0) {
    personal.innerHTML = `
      <h3>Your plan this month</h3>
      <p class="plan-lead">Based on logged income of <strong>${formatMoney(useIncome)}</strong> · Tier: ${tier.label}</p>
      <div class="plan-split">
        <div class="plan-split-item needs"><div class="lbl">Needs</div><div class="val">${formatMoney(needs)}</div></div>
        <div class="plan-split-item wants"><div class="lbl">Wants</div><div class="val">${formatMoney(wants)}</div></div>
        <div class="plan-split-item savings"><div class="lbl">Save</div><div class="val">${formatMoney(savings)}</div></div>
      </div>
      <p class="tier-note"><strong>Target:</strong> ${tier.goal}. Emergency milestone: ${tier.emergency}.</p>
      <p class="tier-note">${tier.note}</p>
      <div class="plan-actions-row">
        <button type="button" class="btn-sm btn-primary" id="applySaveTarget">Add ${formatMoney(savings)} to savings goal</button>
      </div>
    `;
    const btn = document.getElementById('applySaveTarget');
    if (btn) {
      btn.onclick = () => {
        if (!state.goals.length) {
          alert('Create a savings goal first in the Savings section.');
          return;
        }
        const goal = state.goals[0];
        const amount = savings;
        goal.current = Number(goal.current) + amount;
        state.transactions.push({
          id: uid(),
          type: 'saving',
          desc: `Planned savings (${tier.tag})`,
          amount,
          categoryId: goal.id,
          date: dateInViewedMonth(1),
          month: state.currentMonth,
          isDemo: false,
        });
        save();
        render();
        if (typeof showCelebration === 'function') {
          showCelebration('Savings logged', `${formatMoney(amount)} added toward ${goal.name}.`, '💪');
        }
      };
    }
  } else {
    personal.innerHTML = `
      <h3>Your personalized plan</h3>
      <p class="plan-lead">Log your <strong>income</strong> this month to see exact Needs / Wants / Save amounts. Below are guides from ₦30,000 upward.</p>
    `;
  }

  tiersEl.innerHTML = INCOME_TIERS.map(t => {
    const active = useIncome > 0 && useIncome >= t.min && useIncome <= t.max;
    const ex = t.exampleIncome;
    return `
      <div class="tier-card ${active ? 'active-tier' : ''}">
        <div class="tier-head">
          <span class="tier-range">${t.label}</span>
          <span class="tier-tag">${active ? 'YOUR TIER' : t.tag}</span>
        </div>
        <div class="tier-goal">${t.goal}</div>
        <div class="tier-grid">
          <span>Example income</span><span>${formatMoney(ex)}</span>
          <span>Needs (~${Math.round(t.needsPct*100)}%)</span><span>${formatMoney(Math.round(ex * t.needsPct))}</span>
          <span>Wants (~${Math.round(t.wantsPct*100)}%)</span><span>${formatMoney(Math.round(ex * t.wantsPct))}</span>
          <span>Save (~${Math.round(t.savePct*100)}%)</span><span>${formatMoney(Math.round(ex * t.savePct))}</span>
          <span>Emergency target</span><span>${t.emergency}</span>
        </div>
        <p class="tier-note">${t.note}</p>
      </div>`;
  }).join('');
}


// ===================== Anxiety-free UX: streaks, celebrate, personalization =====================
const FOCUS_LABELS = {
  emergency: '🛟 Emergency fund',
  debt: '📉 Pay down debt',
  house: '🏠 Save for a home',
  growth: '📈 Grow & invest',
  calm: '🌊 Stay on track',
};

function updateSavingsStreak() {
  const { saved } = getTotals();
  const thisMonth = state.currentMonth;
  if (saved > 0) {
    if (state.lastSaveMonth !== thisMonth) {
      // new month with savings
      const prev = state.lastSaveMonth;
      if (prev) {
        const [y, m] = thisMonth.split('-').map(Number);
        const [py, pm] = prev.split('-').map(Number);
        const consecutive = (y === py && m === pm + 1) || (y === py + 1 && pm === 12 && m === 1);
        state.savingsStreak = consecutive ? (state.savingsStreak || 0) + 1 : 1;
      } else {
        state.savingsStreak = Math.max(1, state.savingsStreak || 1);
      }
      state.lastSaveMonth = thisMonth;
      save();
    }
  }
}

function showCelebration(title, text, icon) {
  const banner = document.getElementById('celebrateBanner');
  if (!banner) return;
  document.getElementById('celebrateIcon').textContent = icon || '🎉';
  document.getElementById('celebrateTitle').textContent = title;
  document.getElementById('celebrateText').textContent = text;
  banner.classList.remove('hidden');
  clearTimeout(showCelebration._t);
  showCelebration._t = setTimeout(() => banner.classList.add('hidden'), 8000);
}

function checkPositiveReinforcement() {
  updateSavingsStreak();
  const { saved, balance, income, expenses } = getTotals();
  const rate = income > 0 ? (saved / income) * 100 : 0;

  // Streak pill
  const pill = document.getElementById('streakPill');
  const streakText = document.getElementById('streakText');
  if (pill && streakText) {
    if ((state.savingsStreak || 0) >= 1 && saved > 0) {
      streakText.textContent = state.savingsStreak === 1
        ? 'Savings on track this month'
        : `${state.savingsStreak}-month savings streak — keep it going`;
      pill.classList.remove('hidden');
    } else {
      pill.classList.add('hidden');
    }
  }

  // Goal completed celebrations
  state.goals.forEach(g => {
    const done = Number(g.current) >= Number(g.target) && Number(g.target) > 0;
    if (done && !(state.celebratedGoals || []).includes(g.id)) {
      state.celebratedGoals = [...(state.celebratedGoals || []), g.id];
      save();
      showCelebration(
        `Goal reached: ${g.name}!`,
        `You hit ${formatMoney(g.target)}. That's real progress — celebrate it.`,
        '🏆'
      );
    }
  });

  // Soft positive for healthy savings rate (once per session feel via random light touch)
  if (rate >= 20 && saved > 0) {
    // only show if celebrate banner currently hidden
    const b = document.getElementById('celebrateBanner');
    if (b && b.classList.contains('hidden') && !checkPositiveReinforcement._rateShown) {
      checkPositiveReinforcement._rateShown = true;
      showCelebration(
        'Strong savings rate',
        `You're saving ${rate.toFixed(0)}% of income — above the 20% target. Well done.`,
        '🌱'
      );
    }
  }
}

function applyFocusLayout() {
  const focus = state.primaryFocus;
  const badge = document.getElementById('focusBadge');
  const label = document.getElementById('focusLabel');
  if (badge && label) {
    if (focus && FOCUS_LABELS[focus]) {
      label.textContent = FOCUS_LABELS[focus];
      badge.classList.remove('hidden');
    } else {
      badge.classList.add('hidden');
    }
  }

  // Reorder visual priority by moving sections (CSS order)
  const plan = document.querySelector('.section-plan');
  const savings = document.querySelector('.section-savings');
  const expenses = document.querySelector('.section-expenses');
  const growth = document.querySelector('.section-growth');
  const coach = document.querySelector('.section-coach');
  [plan, savings, expenses, growth, coach].forEach(el => { if (el) el.style.order = ''; });

  // parent needs flex column for order to work - app is not flex; set order via dataset and sort isn't trivial
  // Instead highlight section titles / scroll hint via border intensity
  document.querySelectorAll('.panel').forEach(p => p.style.boxShadow = '');
  const highlight = (el) => { if (el) el.style.boxShadow = '0 0 0 1px rgba(91,141,239,0.45), 0 8px 28px rgba(0,0,0,0.25)'; };

  if (focus === 'emergency' || focus === 'house' || focus === 'growth') {
    highlight(savings);
    highlight(plan);
  } else if (focus === 'debt') {
    highlight(expenses);
    highlight(growth);
  } else if (focus === 'calm') {
    highlight(plan);
  }
}

function showOnboardingIfNeeded() {
  const overlay = document.getElementById('onboardOverlay');
  if (!overlay) return;
  if (!state.primaryFocus) {
    overlay.classList.remove('hidden');
  } else {
    overlay.classList.add('hidden');
  }
}

function setupPersonalization() {
  document.querySelectorAll('.focus-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      state.primaryFocus = btn.dataset.focus;
      save();
      document.getElementById('onboardOverlay').classList.add('hidden');
      applyFocusLayout();
      const name = FOCUS_LABELS[state.primaryFocus] || 'your focus';
      showCelebration('Dashboard personalized', `We'll emphasize ${name}. You can change this in Settings anytime.`, '✨');
      render();
    });
  });
  const changeBtn = document.getElementById('changeFocusBtn');
  if (changeBtn) {
    changeBtn.addEventListener('click', () => {
      /* settings is page */
      document.getElementById('onboardOverlay').classList.remove('hidden');
    });
  }
}


// ===================== Customer Support =====================
function getSupportReplies(msg) {
  const m = (msg || '').toLowerCase();
  if (/bug|error|broken|not work|crash/.test(m)) {
    return "Thanks for reporting this. We've logged your bug report on this device. Please describe what you tapped and what went wrong — an agent will follow up if you leave more detail.";
  }
  if (/complain|complaint|angry|refund|bad/.test(m)) {
    return "We're sorry for the trouble. Your complaint has been recorded. Tell us more about what happened and what resolution you prefer (fix, guide, or feature request).";
  }
  if (/human|agent|person|talk|call/.test(m)) {
    return "Connecting you to support… Tap **Open WhatsApp** or **Open Gmail / Email** below the chat, or message +234 704 433 8143 / aiyenuberunolamitangodwin@gmail.com";
  }
  if (/goal|saving|how/.test(m)) {
    return "Tip: Open the Savings section → + New Goal. You can rename any goal with ✎ rename. Add money with + Add Money or the savings form.";
  }
  if (/voice|mic|speak/.test(m)) {
    return "Voice log works best in Chrome. Tap 🎤 Voice log under Expenses, allow the microphone, then say e.g. “Spent 5000 on groceries”.";
  }
  return "Thanks for your message. An agent has received it. Reply with more details if needed, or use the quick buttons above for common issues.";
}

function appendSupportMsg(text, who) {
  const chat = document.getElementById('supportChat');
  if (!chat) return;
  const div = document.createElement('div');
  div.className = 'support-msg ' + (who === 'user' ? 'user' : 'agent');
  div.innerHTML = (who === 'user' ? '<strong>You:</strong> ' : '<strong>Agent:</strong> ') + escapeHtml(text);
  chat.appendChild(div);
  chat.scrollTop = chat.scrollHeight;
}

function saveSupportTicket(message) {
  try {
    const key = 'financeManager_supportTickets';
    const raw = localStorage.getItem(key);
    const list = raw ? JSON.parse(raw) : [];
    list.push({ id: uid(), message, at: new Date().toISOString() });
    localStorage.setItem(key, JSON.stringify(list.slice(-50)));
  } catch (e) {}
}

function setupSupportUI() {
  const fab = document.getElementById('supportFab');
  const panel = document.getElementById('supportPanel');
  const closeBtn = document.getElementById('closeSupport');
  const form = document.getElementById('supportForm');
  if (!fab || !panel) return;

  fab.addEventListener('click', () => {
    panel.classList.toggle('hidden');
  });
  if (closeBtn) {
    closeBtn.addEventListener('click', () => panel.classList.add('hidden'));
  }

  document.querySelectorAll('.support-q').forEach(btn => {
    btn.addEventListener('click', () => {
      const msg = btn.dataset.msg || '';
      appendSupportMsg(msg, 'user');
      saveSupportTicket(msg);
      setTimeout(() => appendSupportMsg(getSupportReplies(msg), 'agent'), 400);
    });
  });

  if (form) {
    form.addEventListener('submit', e => {
      e.preventDefault();
      const input = document.getElementById('supportInput');
      const msg = (input.value || '').trim();
      if (!msg) return;
      appendSupportMsg(msg, 'user');
      saveSupportTicket(msg);
      input.value = '';
      setTimeout(() => appendSupportMsg(getSupportReplies(msg), 'agent'), 450);
    });
  }
}





// ===================== Month comparison =====================
function getMonthKeyOffset(monthKey, offset) {
  const [y, m] = monthKey.split('-').map(Number);
  const d = new Date(y, m - 1 + offset, 1);
  return getMonthKey(d);
}

function totalsForMonth(monthKey) {
  const txs = state.transactions.filter(t => t.month === monthKey);
  const income = txs.filter(t => t.type === 'income').reduce((s, t) => s + Number(t.amount), 0);
  const expenses = txs.filter(t => t.type === 'expense').reduce((s, t) => s + Number(t.amount), 0);
  const saved = txs.filter(t => t.type === 'saving').reduce((s, t) => s + Number(t.amount), 0);
  return { income, expenses, saved, balance: income - expenses - saved };
}

function renderMonthCompare() {
  const el = document.getElementById('compareContent');
  if (!el) return;
  const cur = state.currentMonth;
  const prev = getMonthKeyOffset(cur, -1);
  const a = totalsForMonth(cur);
  const b = totalsForMonth(prev);
  const expDiff = a.expenses - b.expenses;
  const savDiff = a.saved - b.saved;
  const expClass = expDiff > 0 ? 'up' : expDiff < 0 ? 'down' : 'same';
  const savClass = savDiff > 0 ? 'down' : savDiff < 0 ? 'up' : 'same';
  const expWord = expDiff > 0 ? 'more' : expDiff < 0 ? 'less' : 'the same as';
  const rateA = a.income > 0 ? (a.saved / a.income) * 100 : 0;
  const rateB = b.income > 0 ? (b.saved / b.income) * 100 : 0;
  const rateDiff = rateA - rateB;
  const hasPrev = b.income > 0 || b.expenses > 0 || b.saved > 0;
  const hasCur = a.income > 0 || a.expenses > 0 || a.saved > 0;

  // Savings journey status
  let journeyStatus = 'neutral';
  let journeyTitle = 'Keep building the habit';
  let journeyMsg = 'Log income and savings this month to track your journey.';
  let journeyIcon = '🌱';

  if (!hasCur && !hasPrev) {
    journeyStatus = 'neutral';
    journeyTitle = 'Your savings journey starts here';
    journeyMsg = 'Add income and savings for this month. Next month you will see clear progress.';
    journeyIcon = '🌱';
  } else if (!hasPrev) {
    if (a.saved > 0) {
      journeyStatus = 'good';
      journeyTitle = 'Strong start this month';
      journeyMsg = `You have saved ${formatMoney(a.saved)} so far. Keep it up — next month we will compare progress.`;
      journeyIcon = '✨';
    } else {
      journeyStatus = 'warn';
      journeyTitle = 'No savings logged yet this month';
      journeyMsg = 'Even a small amount counts. Use the Savings section or your income plan target.';
      journeyIcon = '💡';
    }
  } else if (savDiff > 0 && a.saved > 0) {
    journeyStatus = 'good';
    journeyTitle = 'You are making progress';
    journeyMsg = `You saved ${formatMoney(savDiff)} more than last month (${formatMoney(b.saved)} → ${formatMoney(a.saved)}). That is real movement on your journey.`;
    journeyIcon = '🚀';
  } else if (savDiff === 0 && a.saved > 0) {
    journeyStatus = 'ok';
    journeyTitle = 'Steady savings';
    journeyMsg = `You matched last month at ${formatMoney(a.saved)}. Consistency matters — try a small increase next month.`;
    journeyIcon = '💪';
  } else if (a.saved > 0 && savDiff < 0) {
    journeyStatus = 'warn';
    journeyTitle = 'Saved less than last month';
    journeyMsg = `Last month ${formatMoney(b.saved)} · This month ${formatMoney(a.saved)}. Progress dipped, not failed — one good payday can reset the trend.`;
    journeyIcon = '📌';
  } else if (a.saved <= 0 && b.saved > 0) {
    journeyStatus = 'warn';
    journeyTitle = 'Savings paused this month';
    journeyMsg = `You saved ${formatMoney(b.saved)} last month but nothing yet this month. Restart with any amount toward a goal.`;
    journeyIcon = '🔄';
  } else {
    journeyStatus = 'warn';
    journeyTitle = 'Savings not moving yet';
    journeyMsg = 'Neither month shows savings. Open Savings Plan by Income and set a target you can keep.';
    journeyIcon = '🎯';
  }

  const maxSave = Math.max(a.saved, b.saved, 1);
  const barA = Math.min(100, (a.saved / maxSave) * 100);
  const barB = Math.min(100, (b.saved / maxSave) * 100);

  el.innerHTML = `
    <div class="journey-card journey-${journeyStatus}">
      <div class="journey-icon">${journeyIcon}</div>
      <div>
        <strong class="journey-title">${journeyTitle}</strong>
        <p class="journey-msg">${journeyMsg}</p>
      </div>
    </div>

    <h4 class="compare-subhead">Savings comparison</h4>
    <div class="compare-grid">
      <div class="compare-card save-focus">
        <div class="lbl">${formatMonthLabel(cur)} (this month)</div>
        <div class="val" style="color:var(--saving)">${formatMoney(a.saved)}</div>
        <div class="plan-row-bar" style="margin-top:0.45rem"><div class="plan-row-fill" style="width:${barA}%;background:var(--saving)"></div></div>
        <div class="lbl" style="margin-top:0.4rem">Rate: ${rateA.toFixed(1)}% of income</div>
      </div>
      <div class="compare-card save-focus">
        <div class="lbl">${formatMonthLabel(prev)} (last month)</div>
        <div class="val" style="color:var(--saving)">${formatMoney(b.saved)}</div>
        <div class="plan-row-bar" style="margin-top:0.45rem"><div class="plan-row-fill" style="width:${barB}%;background:#5b8def"></div></div>
        <div class="lbl" style="margin-top:0.4rem">Rate: ${rateB.toFixed(1)}% of income</div>
      </div>
    </div>

    <div class="savings-diff-line">
      ${savDiff > 0
        ? `Difference: <span class="down">+${formatMoney(savDiff)}</span> more saved than last month`
        : savDiff < 0
          ? `Difference: <span class="up">${formatMoney(savDiff)}</span> vs last month`
          : `Difference: <span class="same">₦0</span> — same as last month`}
      ${hasPrev ? ` · Savings rate change: <strong>${rateDiff >= 0 ? '+' : ''}${rateDiff.toFixed(1)} pts</strong>` : ''}
    </div>

    <h4 class="compare-subhead">Also compared</h4>
    <div class="compare-grid">
      <div class="compare-card">
        <div class="lbl">Expenses this month</div>
        <div class="val">${formatMoney(a.expenses)}</div>
      </div>
      <div class="compare-card">
        <div class="lbl">Expenses last month</div>
        <div class="val">${formatMoney(b.expenses)}</div>
      </div>
    </div>
    <div class="compare-delta">
      Spending: <span class="${expClass}">${formatMoney(Math.abs(expDiff))}</span> ${expWord} last month.
      Income this month ${formatMoney(a.income)} · last month ${formatMoney(b.income)}.
    </div>
  `;
}


// ===================== Debt tracker =====================
let editingDebtId = null;

function renderDebts() {
  const list = document.getElementById('debtsList');
  if (!list) return;
  if (!state.debts) state.debts = [];
  if (!state.debts.length) {
    list.innerHTML = `<div class="empty-state">No debts tracked. Add a loan or balance to pay down.</div>`;
    return;
  }
  list.innerHTML = state.debts.map(d => {
    const total = Number(d.total) || 0;
    const paid = Number(d.paid) || 0;
    const remaining = Math.max(0, total - paid);
    const pct = total > 0 ? Math.min(100, (paid / total) * 100) : 0;
    return `
      <div class="debt-card" data-id="${d.id}">
        <div class="debt-card-head">
          <div class="debt-name">${escapeHtml(d.name)}</div>
          <div class="debt-remaining">${formatMoney(remaining)} left</div>
        </div>
        <div class="debt-meta">Paid ${formatMoney(paid)} of ${formatMoney(total)}
          ${d.minPay ? ` · Min pay ${formatMoney(d.minPay)}/mo` : ''}</div>
        <div class="progress-bar"><div class="progress-fill" style="width:${pct}%;background:#e07a7a"></div></div>
        <div class="debt-actions">
          <button class="btn-sm debt-pay">+ Payment</button>
          <button class="btn-sm debt-edit">Edit</button>
          <button class="btn-sm debt-del">Delete</button>
        </div>
      </div>`;
  }).join('');

  list.querySelectorAll('.debt-pay').forEach(btn => {
    btn.addEventListener('click', e => {
      const id = e.target.closest('.debt-card').dataset.id;
      const debt = state.debts.find(x => x.id === id);
      if (!debt) return;
      const amtStr = prompt('Payment amount?', debt.minPay || '');
      if (amtStr === null) return;
      const amt = Number(amtStr);
      if (!amt || amt <= 0) return alert('Enter a valid amount');
      debt.paid = Math.min(Number(debt.total), Number(debt.paid) + amt);
      // log as expense under misc if exists
      const misc = state.categories.find(c => c.id === 'misc') || state.categories[0];
      state.transactions.push({
        id: uid(), type: 'expense', desc: `Debt payment: ${debt.name}`,
        amount: amt, categoryId: misc ? misc.id : '', date: dateInViewedMonth(1),
        month: state.currentMonth, isDemo: false,
      });
      save();
      render();
    });
  });
  list.querySelectorAll('.debt-edit').forEach(btn => {
    btn.addEventListener('click', e => openDebtModal(e.target.closest('.debt-card').dataset.id));
  });
  list.querySelectorAll('.debt-del').forEach(btn => {
    btn.addEventListener('click', e => {
      const id = e.target.closest('.debt-card').dataset.id;
      if (confirm('Remove this debt?')) {
        state.debts = state.debts.filter(d => d.id !== id);
        save();
        render();
      }
    });
  });
}

function openDebtModal(id) {
  editingDebtId = id || null;
  const modal = document.getElementById('debtModal');
  if (!modal) return;
  document.getElementById('debtModalTitle').textContent = id ? 'Edit Debt' : 'Add Debt';
  if (id) {
    const d = state.debts.find(x => x.id === id);
    if (!d) return;
    document.getElementById('debtName').value = d.name;
    document.getElementById('debtTotal').value = d.total;
    document.getElementById('debtPaid').value = d.paid;
    document.getElementById('debtMinPay').value = d.minPay || 0;
  } else {
    document.getElementById('debtName').value = '';
    document.getElementById('debtTotal').value = '';
    document.getElementById('debtPaid').value = '0';
    document.getElementById('debtMinPay').value = '0';
  }
  modal.classList.remove('hidden');
}

// ===================== Recurring bills =====================
let editingRecId = null;

function renderRecurring() {
  const list = document.getElementById('recurringList');
  if (!list) return;
  if (!state.recurringBills) state.recurringBills = [];
  if (!state.recurringBills.length) {
    list.innerHTML = `<div class="empty-state">No recurring bills yet. Add rent, data, power, etc.</div>`;
    return;
  }
  list.innerHTML = state.recurringBills.map(r => {
    const cat = state.categories.find(c => c.id === r.categoryId);
    return `
      <div class="rec-card" data-id="${r.id}">
        <div class="rec-card-head">
          <div class="rec-name">${escapeHtml(r.name)}</div>
          <div style="font-family:'JetBrains Mono',monospace;font-weight:700">${formatMoney(r.amount)}</div>
        </div>
        <div class="rec-meta">${cat ? (cat.icon || '') + ' ' + cat.name : 'Uncategorized'} · Due day ${r.dueDay || 1}</div>
        <div class="rec-actions">
          <button class="btn-sm rec-edit">Edit</button>
          <button class="btn-sm rec-del">Delete</button>
        </div>
      </div>`;
  }).join('');

  list.querySelectorAll('.rec-edit').forEach(btn => {
    btn.addEventListener('click', e => openRecurringModal(e.target.closest('.rec-card').dataset.id));
  });
  list.querySelectorAll('.rec-del').forEach(btn => {
    btn.addEventListener('click', e => {
      const id = e.target.closest('.rec-card').dataset.id;
      if (confirm('Delete this recurring bill?')) {
        state.recurringBills = state.recurringBills.filter(r => r.id !== id);
        save();
        render();
      }
    });
  });
}

function openRecurringModal(id) {
  editingRecId = id || null;
  const modal = document.getElementById('recurringModal');
  if (!modal) return;
  const sel = document.getElementById('recCategory');
  if (sel) {
    sel.innerHTML = state.categories.map(c =>
      `<option value="${c.id}">${c.icon || ''} ${c.name}</option>`
    ).join('') || '<option value="">No categories</option>';
  }
  document.getElementById('recurringModalTitle').textContent = id ? 'Edit Bill' : 'Add Recurring Bill';
  if (id) {
    const r = state.recurringBills.find(x => x.id === id);
    if (!r) return;
    document.getElementById('recName').value = r.name;
    document.getElementById('recAmount').value = r.amount;
    document.getElementById('recCategory').value = r.categoryId;
    document.getElementById('recDueDay').value = r.dueDay || 1;
  } else {
    document.getElementById('recName').value = '';
    document.getElementById('recAmount').value = '';
    document.getElementById('recDueDay').value = '1';
  }
  modal.classList.remove('hidden');
}

function applyRecurringToCurrentMonth() {
  if (!state.recurringBills || !state.recurringBills.length) {
    alert('Add at least one recurring bill first.');
    return;
  }
  let added = 0;
  state.recurringBills.forEach(r => {
    const marker = `recurring:${r.id}:${state.currentMonth}`;
    const exists = state.transactions.some(t => t.recurringKey === marker);
    if (exists) return;
    const day = Math.min(Math.max(1, Number(r.dueDay) || 1), 28);
    const date = dateInViewedMonth(day);
    state.transactions.push({
      id: uid(),
      type: 'expense',
      desc: r.name,
      amount: Number(r.amount),
      categoryId: r.categoryId,
      date,
      month: state.currentMonth,
      isDemo: false,
      recurringKey: marker,
    });
    added++;
  });
  save();
  render();
  if (added === 0) alert('Bills already applied for this month.');
  else if (typeof showCelebration === 'function') {
    showCelebration('Bills applied', `${added} recurring bill(s) added to ${formatMonthLabel(state.currentMonth)}.`, '📅');
  } else {
    alert(`${added} bill(s) added to this month.`);
  }
}

// ===================== JSON Backup / Restore =====================
function exportJsonBackup() {
  const payload = {
    version: 6,
    exportedAt: new Date().toISOString(),
    state: state,
  };
  const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `finance-backup-${new Date().toISOString().slice(0, 10)}.json`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

function importJsonBackup(file) {
  const reader = new FileReader();
  reader.onload = () => {
    try {
      const data = JSON.parse(reader.result);
      const incoming = data.state || data;
      if (!incoming || typeof incoming !== 'object') throw new Error('Invalid file');
      if (!confirm('Restore will replace your current app data on this device. Continue?')) return;
      state = {
        currency: incoming.currency || '₦',
        currentMonth: incoming.currentMonth || getMonthKey(new Date()),
        categories: Array.isArray(incoming.categories) ? incoming.categories : state.categories,
        transactions: Array.isArray(incoming.transactions) ? incoming.transactions : [],
        goals: Array.isArray(incoming.goals) ? incoming.goals : [],
        reminderEnabled: !!incoming.reminderEnabled,
        lastReminderMonth: incoming.lastReminderMonth || null,
        primaryFocus: incoming.primaryFocus || null,
        savingsStreak: incoming.savingsStreak || 0,
        lastSaveMonth: incoming.lastSaveMonth || null,
        celebratedGoals: Array.isArray(incoming.celebratedGoals) ? incoming.celebratedGoals : [],
        debts: Array.isArray(incoming.debts) ? incoming.debts : [],
        recurringBills: Array.isArray(incoming.recurringBills) ? incoming.recurringBills : [],
      };
      save();
      syncFormDatesToViewedMonth();
      render();
      alert('Backup restored successfully.');
    } catch (err) {
      alert('Could not restore backup. Use a valid JSON file from this app.');
    }
  };
  reader.readAsText(file);
}

function setupDebtRecurringCompare() {
  const addDebt = document.getElementById('addDebtBtn');
  if (addDebt) addDebt.addEventListener('click', () => openDebtModal());
  const cancelDebt = document.getElementById('cancelDebt');
  if (cancelDebt) cancelDebt.addEventListener('click', () => {
    document.getElementById('debtModal').classList.add('hidden');
    editingDebtId = null;
  });
  const debtForm = document.getElementById('debtForm');
  if (debtForm) {
    debtForm.addEventListener('submit', e => {
      e.preventDefault();
      const name = document.getElementById('debtName').value.trim();
      const total = Number(document.getElementById('debtTotal').value);
      const paid = Number(document.getElementById('debtPaid').value) || 0;
      const minPay = Number(document.getElementById('debtMinPay').value) || 0;
      if (!name || !total || total <= 0) return alert('Enter name and total owed');
      if (!state.debts) state.debts = [];
      if (editingDebtId) {
        const d = state.debts.find(x => x.id === editingDebtId);
        if (d) { d.name = name; d.total = total; d.paid = paid; d.minPay = minPay; }
      } else {
        state.debts.push({ id: uid(), name, total, paid, minPay });
      }
      save();
      document.getElementById('debtModal').classList.add('hidden');
      editingDebtId = null;
      render();
    });
  }

  const addRec = document.getElementById('addRecurringBtn');
  if (addRec) addRec.addEventListener('click', () => openRecurringModal());
  const cancelRec = document.getElementById('cancelRecurring');
  if (cancelRec) cancelRec.addEventListener('click', () => {
    document.getElementById('recurringModal').classList.add('hidden');
    editingRecId = null;
  });
  const recForm = document.getElementById('recurringForm');
  if (recForm) {
    recForm.addEventListener('submit', e => {
      e.preventDefault();
      const name = document.getElementById('recName').value.trim();
      const amount = Number(document.getElementById('recAmount').value);
      const categoryId = document.getElementById('recCategory').value;
      const dueDay = Number(document.getElementById('recDueDay').value) || 1;
      if (!name || !amount || amount <= 0) return alert('Enter name and amount');
      if (!state.recurringBills) state.recurringBills = [];
      if (editingRecId) {
        const r = state.recurringBills.find(x => x.id === editingRecId);
        if (r) { r.name = name; r.amount = amount; r.categoryId = categoryId; r.dueDay = dueDay; }
      } else {
        state.recurringBills.push({ id: uid(), name, amount, categoryId, dueDay });
      }
      save();
      document.getElementById('recurringModal').classList.add('hidden');
      editingRecId = null;
      render();
    });
  }
  const applyBtn = document.getElementById('applyRecurringBtn');
  if (applyBtn) applyBtn.addEventListener('click', applyRecurringToCurrentMonth);

  const jsonBtn = document.getElementById('exportJsonBtn');
  if (jsonBtn) jsonBtn.addEventListener('click', exportJsonBackup);
  const importBtn = document.getElementById('importBackupBtn');
  const importFile = document.getElementById('importBackupFile');
  if (importBtn && importFile) {
    importBtn.addEventListener('click', () => importFile.click());
    importFile.addEventListener('change', () => {
      if (importFile.files && importFile.files[0]) {
        importJsonBackup(importFile.files[0]);
        importFile.value = '';
      }
    });
  }
}


// ===================== CSV Export =====================
function csvEscape(value) {
  const s = value == null ? '' : String(value);
  if (/[",\n\r]/.test(s)) {
    return '"' + s.replace(/"/g, '""') + '"';
  }
  return s;
}

function toCsv(rows) {
  return rows.map(row => row.map(csvEscape).join(',')).join('\r\n');
}

function downloadCsv(filename, csvText) {
  // BOM helps Excel open UTF-8 (₦) correctly
  const blob = new Blob(['\ufeff' + csvText], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

function categoryName(id) {
  if (id === 'income') return 'Income';
  const cat = state.categories.find(c => c.id === id);
  if (cat) return cat.name;
  const goal = state.goals.find(g => g.id === id);
  if (goal) return goal.name;
  return id || '';
}

function buildTransactionsCsv(transactions) {
  const header = ['Date', 'Month', 'Type', 'Description', 'Category', 'Amount', 'Currency', 'Demo'];
  const rows = [header];
  const sorted = (transactions || []).slice().sort((a, b) => String(a.date).localeCompare(String(b.date)));
  sorted.forEach(t => {
    rows.push([
      t.date || '',
      t.month || '',
      t.type || '',
      t.desc || '',
      categoryName(t.categoryId),
      Number(t.amount) || 0,
      state.currency || '₦',
      t.isDemo ? 'yes' : 'no',
    ]);
  });
  return toCsv(rows);
}

function buildCategoriesCsv() {
  const header = ['Name', 'Budget', 'Spent_This_Month', 'Color', 'Icon'];
  const rows = [header];
  state.categories.forEach(c => {
    rows.push([
      c.name || '',
      Number(c.budget) || 0,
      getCategorySpent(c.id),
      c.color || '',
      c.icon || '',
    ]);
  });
  return toCsv(rows);
}

function buildGoalsCsv() {
  const header = ['Goal', 'Current', 'Target', 'Progress_Percent'];
  const rows = [header];
  state.goals.forEach(g => {
    const cur = Number(g.current) || 0;
    const tgt = Number(g.target) || 0;
    const pct = tgt > 0 ? ((cur / tgt) * 100).toFixed(1) : '0';
    rows.push([g.name || '', cur, tgt, pct]);
  });
  return toCsv(rows);
}

function buildMonthSummaryCsv() {
  const { income, expenses, saved, balance } = getTotals();
  const header = ['Field', 'Value'];
  const rows = [
    header,
    ['Month', state.currentMonth],
    ['Month_Label', formatMonthLabel(state.currentMonth)],
    ['Currency', state.currency || '₦'],
    ['Income', income],
    ['Expenses', expenses],
    ['Saved', saved],
    ['Balance', balance],
    [],
    ['Type', 'Description', 'Category', 'Amount', 'Date'],
  ];
  getMonthTransactions()
    .slice()
    .sort((a, b) => String(a.date).localeCompare(String(b.date)))
    .forEach(t => {
      rows.push([t.type, t.desc || '', categoryName(t.categoryId), Number(t.amount) || 0, t.date || '']);
    });
  return toCsv(rows);
}

function buildFullBackupCsv() {
  // Multi-section CSV-style export in one file
  const parts = [];
  parts.push('=== TRANSACTIONS ===');
  parts.push(buildTransactionsCsv(state.transactions));
  parts.push('');
  parts.push('=== CATEGORIES ===');
  parts.push(buildCategoriesCsv());
  parts.push('');
  parts.push('=== GOALS ===');
  parts.push(buildGoalsCsv());
  parts.push('');
  parts.push('=== THIS_MONTH_SUMMARY ===');
  parts.push(buildMonthSummaryCsv());
  return parts.join('\r\n');
}

function exportTransactionsCsv() {
  if (!state.transactions.length) {
    alert('No transactions to export yet.');
    return;
  }
  const name = `finance-transactions-${state.currentMonth || 'all'}.csv`;
  downloadCsv(name, buildTransactionsCsv(state.transactions));
}

function exportThisMonthCsv() {
  const txs = getMonthTransactions();
  if (!txs.length) {
    alert('No transactions this month to export.');
    return;
  }
  downloadCsv(`finance-${state.currentMonth}.csv`, buildMonthSummaryCsv());
}

function exportFullCsv() {
  downloadCsv(`finance-full-backup-${new Date().toISOString().slice(0, 10)}.csv`, buildFullBackupCsv());
}

function setupCsvExport() {

  const headerExportBtn = document.getElementById('headerExportBtn');
  if (headerExportBtn) {
    headerExportBtn.addEventListener('click', () => {
      // Quick export: this month if it has data, else all transactions
      const monthTx = typeof getMonthTransactions === 'function' ? getMonthTransactions() : [];
      if (monthTx.length) exportThisMonthCsv();
      else exportTransactionsCsv();
    });
  }

  const txBtn = document.getElementById('exportTxCsvBtn');
  const monthBtn = document.getElementById('exportMonthCsvBtn');
  const fullBtn = document.getElementById('exportFullCsvBtn');
  if (txBtn) txBtn.addEventListener('click', exportTransactionsCsv);
  if (monthBtn) monthBtn.addEventListener('click', exportThisMonthCsv);
  if (fullBtn) fullBtn.addEventListener('click', exportFullCsv);
}





// ===================== Biometric / PIN app lock =====================
const BIO_KEY = 'financeManager_bio';

function detectBiometricType() {
  const ua = navigator.userAgent || '';
  const isIOS = /iPhone|iPad|iPod/i.test(ua);
  const isAndroid = /Android/i.test(ua);
  const isMac = /Mac/i.test(ua) && !isIOS;
  if (isIOS) return { id: 'face', label: 'Face ID', verb: 'Use Face ID', icon: '👤' };
  if (isAndroid) return { id: 'fingerprint', label: 'Fingerprint', verb: 'Use fingerprint', icon: '👆' };
  if (isMac) return { id: 'touch', label: 'Touch ID', verb: 'Use Touch ID', icon: '👆' };
  return { id: 'biometric', label: 'Biometrics', verb: 'Use biometrics', icon: '🔒' };
}

// Fix Android icon to emoji fingerprint
function detectBiometricTypeFixed() {
  const ua = navigator.userAgent || '';
  const isIOS = /iPhone|iPad|iPod/i.test(ua);
  const isAndroid = /Android/i.test(ua);
  const isMac = /Macintosh/i.test(ua) && !isIOS;
  if (isIOS) return { id: 'face', label: 'Face ID', verb: 'Use Face ID', icon: '👤' };
  if (isAndroid) return { id: 'fingerprint', label: 'Fingerprint', verb: 'Use fingerprint', icon: '👆' };
  if (isMac) return { id: 'touch', label: 'Touch ID', verb: 'Use Touch ID', icon: '👆' };
  return { id: 'biometric', label: 'Device unlock', verb: 'Unlock with device', icon: '🔒' };
}

function getBioSettings() {
  try {
    return JSON.parse(localStorage.getItem(BIO_KEY) || '{}');
  } catch (e) {
    return {};
  }
}

function saveBioSettings(obj) {
  try { localStorage.setItem(BIO_KEY, JSON.stringify(obj)); } catch (e) {}
}

function bufferToBase64(buf) {
  const bytes = new Uint8Array(buf);
  let s = '';
  bytes.forEach(b => { s += String.fromCharCode(b); });
  return btoa(s);
}

function base64ToBuffer(b64) {
  const s = atob(b64);
  const bytes = new Uint8Array(s.length);
  for (let i = 0; i < s.length; i++) bytes[i] = s.charCodeAt(i);
  return bytes.buffer;
}

async function platformAuthAvailable() {
  try {
    if (!window.PublicKeyCredential) return false;
    if (typeof PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable === 'function') {
      return await PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable();
    }
  } catch (e) {}
  return false;
}

async function registerBiometric() {
  const available = await platformAuthAvailable();
  if (!available) return { ok: false, reason: 'unavailable' };
  const challenge = crypto.getRandomValues(new Uint8Array(32));
  const userId = crypto.getRandomValues(new Uint8Array(16));
  try {
    const cred = await navigator.credentials.create({
      publicKey: {
        challenge,
        rp: { name: 'Finance Manager', id: location.hostname || 'localhost' },
        user: {
          id: userId,
          name: 'finance-user',
          displayName: 'Finance Manager User',
        },
        pubKeyCredParams: [
          { type: 'public-key', alg: -7 },
          { type: 'public-key', alg: -257 },
        ],
        authenticatorSelection: {
          authenticatorAttachment: 'platform',
          userVerification: 'required',
          residentKey: 'preferred',
        },
        timeout: 60000,
      },
    });
    if (!cred) return { ok: false, reason: 'cancelled' };
    const id = bufferToBase64(cred.rawId);
    const bio = getBioSettings();
    bio.enabled = true;
    bio.credentialId = id;
    bio.method = detectBiometricTypeFixed().id;
    saveBioSettings(bio);
    return { ok: true };
  } catch (e) {
    console.warn('WebAuthn register failed', e);
    return { ok: false, reason: e.name || 'error' };
  }
}

async function verifyBiometric() {
  const bio = getBioSettings();
  if (!bio.credentialId) return { ok: false, reason: 'not_registered' };
  const available = await platformAuthAvailable();
  if (!available) return { ok: false, reason: 'unavailable' };
  try {
    const challenge = crypto.getRandomValues(new Uint8Array(32));
    const assertion = await navigator.credentials.get({
      publicKey: {
        challenge,
        timeout: 60000,
        userVerification: 'required',
        allowCredentials: [{
          type: 'public-key',
          id: base64ToBuffer(bio.credentialId),
          transports: ['internal'],
        }],
      },
    });
    return { ok: !!assertion };
  } catch (e) {
    console.warn('WebAuthn verify failed', e);
    return { ok: false, reason: e.name || 'error' };
  }
}

function hashPin(pin) {
  // simple non-crypto visual obfuscation + salt for local-only PIN
  let h = 2166136261;
  const s = 'fm-pin-' + pin;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return (h >>> 0).toString(16);
}

function setBioPin(pin) {
  const bio = getBioSettings();
  bio.pinHash = hashPin(String(pin));
  bio.enabled = true;
  saveBioSettings(bio);
}

function checkBioPin(pin) {
  const bio = getBioSettings();
  if (!bio.pinHash) return false;
  return bio.pinHash === hashPin(String(pin));
}

function isBioLockEnabled() {
  const bio = getBioSettings();
  return !!(bio.enabled && (bio.credentialId || bio.pinHash));
}

function applyBioLabels() {
  const type = detectBiometricTypeFixed();
  // fix fingerprint emoji
  const icon = type.id === 'fingerprint' ? '👆' : type.icon;
  const logo = document.getElementById('bioLogoIcon');
  const hint = document.getElementById('bioLockHint');
  const btn = document.getElementById('bioUnlockBtn');
  const toggleLabel = document.getElementById('bioLockToggleLabel');
  const setupHint = document.getElementById('bioLockSetupHint');
  if (logo) logo.textContent = icon;
  if (hint) hint.textContent = type.id === 'face'
    ? 'Confirm with Face ID to open your finances'
    : type.id === 'fingerprint'
      ? 'Confirm with fingerprint to open your finances'
      : 'Confirm with device biometrics to continue';
  if (btn) btn.textContent = type.verb;
  if (toggleLabel) {
    toggleLabel.textContent = type.id === 'face'
      ? 'Unlock with Face ID'
      : type.id === 'fingerprint'
        ? 'Unlock with fingerprint'
        : 'Unlock with biometrics';
  }
  if (setupHint) {
    setupHint.textContent = type.id === 'face'
      ? 'Uses Face ID on this iPhone/iPad when available. You can also set a PIN.'
      : type.id === 'fingerprint'
        ? 'Uses fingerprint on this Android phone when available. You can also set a PIN.'
        : 'Uses your device biometrics when available. You can also set a PIN.';
  }
}

function showBioLock(onSuccess) {
  applyBioLabels();
  const screen = document.getElementById('bioLockScreen');
  const auth = document.getElementById('authScreen');
  const splash = document.getElementById('appSplashScreen');
  const app = document.getElementById('mainApp');
  if (screen) screen.classList.remove('hidden');
  if (auth) auth.classList.add('hidden');
  if (splash) splash.classList.add('hidden');
  if (app) app.style.display = 'none';
  window._bioUnlockSuccess = onSuccess;
  const note = document.getElementById('bioStatusNote');
  if (note) note.textContent = '';
}

function hideBioLock() {
  const screen = document.getElementById('bioLockScreen');
  if (screen) screen.classList.add('hidden');
}

async function tryBiometricUnlock() {
  const note = document.getElementById('bioStatusNote');
  if (note) note.textContent = 'Waiting for biometrics…';
  const bio = getBioSettings();
  if (bio.credentialId) {
    const res = await verifyBiometric();
    if (res.ok) {
      hideBioLock();
      if (typeof window._bioUnlockSuccess === 'function') window._bioUnlockSuccess();
      return;
    }
    if (note) note.textContent = 'Biometric failed or cancelled. Try again or use PIN.';
  } else if (note) {
    note.textContent = 'Biometrics not set up yet. Use PIN or enable in Settings.';
  }
}

function setupTaglineLivePreview() {
  const input = document.getElementById('appTaglineInput');
  if (!input) return;
  input.addEventListener('input', () => {
    const t = input.value.trim() || DEFAULT_APP_TAGLINE;
    const splash = document.getElementById('splashTagline');
    const auth = document.getElementById('authTagline');
    if (splash) splash.textContent = t;
    if (auth) auth.textContent = t;
  });
}

function setupBiometricUI() {
  if (typeof setupTaglineLivePreview === 'function') setupTaglineLivePreview();

  applyBioLabels();
  const unlockBtn = document.getElementById('bioUnlockBtn');
  const pinBtn = document.getElementById('bioUsePinBtn');
  const pinPanel = document.getElementById('bioPinPanel');
  const pinSubmit = document.getElementById('bioPinSubmit');
  const pinInput = document.getElementById('bioPinInput');
  const toggle = document.getElementById('bioLockToggle');
  const pinSetupRow = document.getElementById('bioPinSetupRow');
  const pinSetupInput = document.getElementById('bioPinSetupInput');

  if (unlockBtn) unlockBtn.addEventListener('click', () => tryBiometricUnlock());
  if (pinBtn) {
    pinBtn.addEventListener('click', () => {
      if (pinPanel) pinPanel.classList.toggle('hidden');
      if (pinInput) pinInput.focus();
    });
  }
  if (pinSubmit) {
    pinSubmit.addEventListener('click', () => {
      const pin = (pinInput && pinInput.value) || '';
      if (!pin || pin.length < 4) {
        alert('Enter your PIN');
        return;
      }
      if (checkBioPin(pin)) {
        hideBioLock();
        if (typeof window._bioUnlockSuccess === 'function') window._bioUnlockSuccess();
      } else {
        alert('Incorrect PIN');
      }
    });
  }
  if (toggle) {
    const bio = getBioSettings();
    toggle.checked = !!bio.enabled;
    if (pinSetupRow) pinSetupRow.style.display = toggle.checked ? 'block' : 'none';
    toggle.addEventListener('change', async () => {
      if (toggle.checked) {
        if (pinSetupRow) pinSetupRow.style.display = 'block';
        const avail = await platformAuthAvailable();
        if (avail) {
          const reg = await registerBiometric();
          if (!reg.ok) {
            // still allow PIN-only
            const note = document.getElementById('bioLockSetupHint');
            if (note) note.textContent = 'Biometrics unavailable in this browser. Set a PIN below to lock the app.';
          }
        } else {
          const note = document.getElementById('bioLockSetupHint');
          if (note) note.textContent = 'Biometrics not available here (need HTTPS or supported browser). Set a PIN to lock the app.';
        }
        const b = getBioSettings();
        b.enabled = true;
        saveBioSettings(b);
      } else {
        if (pinSetupRow) pinSetupRow.style.display = 'none';
        saveBioSettings({ enabled: false });
      }
    });
  }

  // Persist PIN on settings save is handled in saveSettingsFromForm patch below
}



// ===================== App tagline (sync everywhere) =====================
const TAGLINE_KEY = 'financeManager_tagline';
const DEFAULT_APP_TAGLINE = 'Track · Budget · Save';

function getAppTagline() {
  try {
    const t = localStorage.getItem(TAGLINE_KEY);
    if (t && t.trim()) return t.trim();
  } catch (e) {}
  if (state && state.appTagline && String(state.appTagline).trim()) return String(state.appTagline).trim();
  return DEFAULT_APP_TAGLINE;
}

function setAppTagline(tagline) {
  const t = (tagline || '').trim() || DEFAULT_APP_TAGLINE;
  try { localStorage.setItem(TAGLINE_KEY, t); } catch (e) {}
  if (typeof state === 'object' && state) state.appTagline = t;
  applyAppTagline();
  return t;
}

function applyAppTagline() {
  const t = getAppTagline();
  const ids = ['splashTagline', 'authTagline', 'headerTagline'];
  ids.forEach(id => {
    const el = document.getElementById(id);
    if (el) el.textContent = t;
  });
  document.querySelectorAll('[data-app-tagline]').forEach(el => {
    el.textContent = t;
  });
  const input = document.getElementById('appTaglineInput');
  if (input && document.activeElement !== input) input.value = t;
}



// ===================== First-time permissions =====================
const PERM_KEY = 'financeManager_perms_v1';

function hasAcceptedPermissions() {
  try { return localStorage.getItem(PERM_KEY) === '1'; } catch (e) { return false; }
}

function markPermissionsAccepted() {
  try { localStorage.setItem(PERM_KEY, '1'); } catch (e) {}
}

function showPermScreen() {
  const el = document.getElementById('permScreen');
  const auth = document.getElementById('authScreen');
  const splash = document.getElementById('appSplashScreen');
  const bio = document.getElementById('bioLockScreen');
  const app = document.getElementById('mainApp');
  if (el) el.classList.remove('hidden');
  if (auth) auth.classList.add('hidden');
  if (splash) splash.classList.add('hidden');
  if (bio) bio.classList.add('hidden');
  if (app) app.style.display = 'none';
}

function hidePermScreen() {
  const el = document.getElementById('permScreen');
  if (el) el.classList.add('hidden');
}

async function requestFirstTimePermissions() {
  // Notifications
  try {
    if (typeof Notification !== 'undefined' && Notification.permission === 'default') {
      await Notification.requestPermission();
    }
  } catch (e) {}
  // Microphone (optional — soft request via getUserMedia if available)
  try {
    if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
      // Don't force mic on first open; user grants when using voice log
    }
  } catch (e) {}
  markPermissionsAccepted();
}

function setupPermissionScreen(onDone) {
  const allow = document.getElementById('permAllowBtn');
  const skip = document.getElementById('permSkipBtn');
  const finish = async (request) => {
    if (request) await requestFirstTimePermissions();
    else markPermissionsAccepted();
    hidePermScreen();
    if (typeof onDone === 'function') onDone();
  };
  if (allow) allow.onclick = () => finish(true);
  if (skip) skip.onclick = () => finish(false);
}


// ===================== App name splash (before sign-in) =====================
function showAppSplash() {
  if (typeof applyAppTagline === 'function') applyAppTagline();

  const splash = document.getElementById('appSplashScreen');
  const auth = document.getElementById('authScreen');
  const gp = document.getElementById('googleProfileScreen');
  const app = document.getElementById('mainApp');
  if (splash) splash.classList.remove('hidden');
  if (auth) auth.classList.add('hidden');
  if (gp) gp.classList.add('hidden');
  if (app) app.style.display = 'none';
}

function hideAppSplash() {
  const splash = document.getElementById('appSplashScreen');
  if (splash) splash.classList.add('hidden');
}

function runAppSplashThen(next) {
  showAppSplash();
  setTimeout(() => {
    hideAppSplash();
    if (typeof next === 'function') next();
  }, 1600);
}


// ===================== Firebase Google Auth =====================
function isFirebaseReady() {
  try {
    return !!(
      window.FIREBASE_ENABLED &&
      window.FIREBASE_CONFIG &&
      window.FIREBASE_CONFIG.apiKey &&
      window.FIREBASE_CONFIG.apiKey !== 'YOUR_API_KEY' &&
      typeof firebase !== 'undefined'
    );
  } catch (e) {
    return false;
  }
}

function initFirebaseAuth() {
  if (!isFirebaseReady()) return null;
  try {
    if (!firebase.apps.length) {
      firebase.initializeApp(window.FIREBASE_CONFIG);
    }
    return firebase.auth();
  } catch (e) {
    console.warn('Firebase init failed', e);
    return null;
  }
}

async function signInWithGoogleFirebase() {
  const auth = initFirebaseAuth();
  if (!auth) throw new Error('Firebase not configured');
  const provider = new firebase.auth.GoogleAuthProvider();
  provider.setCustomParameters({ prompt: 'select_account' });
  // Popup for browser; redirect often better inside Android WebView
  const isWebView = /; wv\)|WebView/i.test(navigator.userAgent || '');
  if (isWebView) {
    await auth.signInWithRedirect(provider);
    return null; // result handled by getRedirectResult
  }
  const result = await auth.signInWithPopup(provider);
  return result.user;
}

async function handleGoogleRedirectResult() {
  const auth = initFirebaseAuth();
  if (!auth) return;
  try {
    const result = await auth.getRedirectResult();
    if (result && result.user) {
      completeLogin({
        id: result.user.uid,
        name: result.user.displayName || 'User',
        email: result.user.email,
        provider: 'google',
      });
    }
  } catch (e) {
    console.warn('Google redirect result', e);
  }
}

function listenFirebaseAuth() {
  const auth = initFirebaseAuth();
  if (!auth) return;
  auth.onAuthStateChanged(user => {
    // Optional: could auto-restore session — we keep explicit completeLogin on button
    if (user && user.email) {
      const session = typeof getSession === 'function' ? getSession() : null;
      if (!session || session.email !== user.email) {
        // soft sync session without forcing navigation during setup
        try {
          setSession({
            id: user.uid,
            name: user.displayName || (session && session.name) || 'User',
            email: user.email,
            provider: 'google',
          });
        } catch (e) {}
      }
    }
  });
}


// ===================== Auth / Account (local demo) =====================
const AUTH_KEY = 'financeManager_auth_v1';
const USERS_KEY = 'financeManager_users_v1';

function getUsers() {
  try {
    return JSON.parse(localStorage.getItem(USERS_KEY) || '{}');
  } catch (e) { return {}; }
}

function saveUsers(users) {
  localStorage.setItem(USERS_KEY, JSON.stringify(users));
}

function getSession() {
  try {
    return JSON.parse(localStorage.getItem(AUTH_KEY) || 'null');
  } catch (e) { return null; }
}

function setSession(user) {
  localStorage.setItem(AUTH_KEY, JSON.stringify(user));
}

function clearSession() {
  localStorage.removeItem(AUTH_KEY);
}

function showApp() {
  setTimeout(() => { if (typeof showTutorialIfNeeded === 'function') showTutorialIfNeeded(); }, 600);

  const auth = document.getElementById('authScreen');
  const gp = document.getElementById('googleProfileScreen');
  const app = document.getElementById('mainApp');
  if (auth) auth.classList.add('hidden');
  if (gp) gp.classList.add('hidden');
  if (app) app.style.display = '';
  if (typeof applyUiPrefs === 'function') applyUiPrefs();
  // show user in header if possible
  const session = getSession();
  let chip = document.getElementById('userChip');
  if (!chip && session) {
    const headerRight = document.querySelector('.header-right');
    if (headerRight) {
      chip = document.createElement('div');
      chip.id = 'userChip';
      chip.className = 'user-chip';
      chip.title = session.email || '';
      chip.textContent = (session.name || session.email || 'User').split(' ')[0];
      headerRight.insertBefore(chip, headerRight.firstChild);
    }
  } else if (chip && session) {
    chip.textContent = (session.name || session.email || 'User').split(' ')[0];
  }
}

function showAuth() {
  if (typeof applyAppTagline === 'function') applyAppTagline();
  const auth = document.getElementById('authScreen');
  const gp = document.getElementById('googleProfileScreen');
  const app = document.getElementById('mainApp');
  const splash = document.getElementById('appSplashScreen');
  const perm = document.getElementById('permScreen');
  const bio = document.getElementById('bioLockScreen');
  if (app) app.style.display = 'none';
  if (gp) gp.classList.add('hidden');
  if (splash) splash.classList.add('hidden');
  if (perm) perm.classList.add('hidden');
  if (bio) bio.classList.add('hidden');
  if (auth) auth.classList.remove('hidden');
  // Default to Sign in tab
  const tabSign = document.querySelector('.auth-tab[data-auth="signin"]');
  const tabUp = document.querySelector('.auth-tab[data-auth="signup"]');
  const signInForm = document.getElementById('signInForm');
  const signUpForm = document.getElementById('signUpForm');
  if (tabSign) tabSign.classList.add('active');
  if (tabUp) tabUp.classList.remove('active');
  if (signInForm) signInForm.classList.remove('hidden');
  if (signUpForm) signUpForm.classList.add('hidden');
}

function completeLogin(user) {
  setTimeout(() => { if (typeof updateUserChip === 'function') updateUserChip(); }, 0);

  setSession(user);
  // Hide auth UI
  const auth = document.getElementById('authScreen');
  const gp = document.getElementById('googleProfileScreen');
  if (auth) auth.classList.add('hidden');
  if (gp) gp.classList.add('hidden');
  // First entry after sign-in: permission screen once
  if (typeof hasAcceptedPermissions === 'function' && !hasAcceptedPermissions()) {
    showPermScreen();
    setupPermissionScreen(() => {
      showApp();
      if (typeof showOnboardingIfNeeded === 'function') showOnboardingIfNeeded();
    });
  } else {
    showApp();
    if (typeof showOnboardingIfNeeded === 'function') showOnboardingIfNeeded();
  }
}

function setupAuth() {
  if (typeof handleGoogleRedirectResult === 'function') handleGoogleRedirectResult();
  if (typeof listenFirebaseAuth === 'function') listenFirebaseAuth();
  const note = document.getElementById('firebaseGoogleNote');
  if (note) {
    note.textContent = isFirebaseReady()
      ? 'Google sign-in is connected via Firebase.'
      : 'Demo Google until you paste config into firebase-config.js and set FIREBASE_ENABLED = true.';
  }
  const signInForm = document.getElementById('signInForm');
  const signUpForm = document.getElementById('signUpForm');
  const googleBtn = document.getElementById('googleSignInBtn');
  const googleProfileForm = document.getElementById('googleProfileForm');

  // Tabs
  document.querySelectorAll('.auth-tab').forEach(tab => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('.auth-tab').forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      const mode = tab.dataset.auth;
      if (mode === 'signin') {
        signInForm.classList.remove('hidden');
        signUpForm.classList.add('hidden');
      } else {
        signInForm.classList.add('hidden');
        signUpForm.classList.remove('hidden');
      }
    });
  });

  // Create account
  if (signUpForm) {
    signUpForm.addEventListener('submit', e => {
      e.preventDefault();
      const name = document.getElementById('suName').value.trim();
      const email = document.getElementById('suEmail').value.trim().toLowerCase();
      const password = document.getElementById('suPassword').value;
      const dob = document.getElementById('suDob').value;
      const from = document.getElementById('suFrom').value.trim();
      const gender = document.getElementById('suGender').value;
      if (!name || !email || !password || !dob || !from || !gender) {
        alert('Please fill in all fields.');
        return;
      }
      if (password.length < 6) {
        alert('Password must be at least 6 characters.');
        return;
      }
      const users = getUsers();
      if (users[email]) {
        alert('An account with this email already exists. Please sign in.');
        return;
      }
      const user = {
        id: uid(),
        name,
        email,
        password, // demo only — never store plain passwords in production
        dob,
        from,
        gender,
        provider: 'email',
        createdAt: new Date().toISOString(),
      };
      users[email] = user;
      saveUsers(users);
      completeLogin({ id: user.id, name, email, dob, from, gender, provider: 'email' });
    });
  }

  // Sign in
  if (signInForm) {
    signInForm.addEventListener('submit', e => {
      e.preventDefault();
      const email = document.getElementById('siEmail').value.trim().toLowerCase();
      const password = document.getElementById('siPassword').value;
      const users = getUsers();
      const user = users[email];
      if (!user || user.password !== password) {
        alert('Incorrect email or password.');
        return;
      }
      completeLogin({
        id: user.id,
        name: user.name,
        email: user.email,
        dob: user.dob,
        from: user.from,
        gender: user.gender,
        provider: user.provider || 'email',
      });
    });
  }

  // Continue with Google (demo flow → profile form)
  if (googleBtn) {
    googleBtn.addEventListener('click', async () => {
      const note = document.getElementById('firebaseGoogleNote');
      if (isFirebaseReady()) {
        try {
          googleBtn.disabled = true;
          if (note) note.textContent = 'Opening Google…';
          const user = await signInWithGoogleFirebase();
          if (user) {
            completeLogin({
              id: user.uid,
              name: user.displayName || 'User',
              email: user.email,
              provider: 'google',
            });
          } else if (note) {
            note.textContent = 'Redirecting to Google…';
          }
        } catch (err) {
          console.warn(err);
          alert('Google sign-in failed. Check Firebase config and authorized domains.\\n\\n' + (err.message || err));
          if (note) note.textContent = 'Firebase Google failed — fix config or use email sign-in.';
        } finally {
          googleBtn.disabled = false;
        }
        return;
      }
      // Demo fallback (no Firebase yet): collect profile then continue
      if (note) note.textContent = 'Demo mode: add firebase-config.js to enable real Google login.';
      const auth = document.getElementById('authScreen');
      const gp = document.getElementById('googleProfileScreen');
      if (auth) auth.classList.add('hidden');
      if (gp) gp.classList.remove('hidden');
    });
  }

  if (googleProfileForm) {
    googleProfileForm.addEventListener('submit', e => {
      e.preventDefault();
      const name = document.getElementById('gpName').value.trim();
      const email = document.getElementById('gpEmail').value.trim().toLowerCase();
      const dob = document.getElementById('gpDob').value;
      const from = document.getElementById('gpFrom').value.trim();
      const gender = document.getElementById('gpGender').value;
      if (!name || !email || !dob || !from || !gender) {
        alert('Please complete all fields.');
        return;
      }
      const users = getUsers();
      const user = {
        id: users[email]?.id || uid(),
        name,
        email,
        password: null,
        dob,
        from,
        gender,
        provider: 'google-demo',
        createdAt: users[email]?.createdAt || new Date().toISOString(),
      };
      users[email] = user;
      saveUsers(users);
      completeLogin({ id: user.id, name, email, dob, from, gender, provider: 'google-demo' });
    });
  }
}

function initAuthGate() {
  setupAuth();
  if (typeof setupBiometricUI === 'function') setupBiometricUI();
  const session = getSession();

  const enterApp = () => {
    // First time into the app after auth: permissions once
    if (typeof hasAcceptedPermissions === 'function' && !hasAcceptedPermissions()) {
      showPermScreen();
      setupPermissionScreen(() => showApp());
    } else {
      showApp();
    }
  };

  const afterAuthPoint = () => {
    if (session && session.email) {
      // Returning user: optional bio lock, then app (perms already done or asked after login)
      if (typeof isBioLockEnabled === 'function' && isBioLockEnabled()) {
        showBioLock(enterApp);
      } else {
        enterApp();
      }
    } else {
      // Classic pattern: sign in / create account
      showAuth();
    }
  };

  if (typeof runAppSplashThen === 'function') {
    runAppSplashThen(afterAuthPoint);
  } else {
    afterAuthPoint();
  }
}




// ===================== i18n & appearance settings =====================
const I18N = {
  en: {
    settings: 'Settings', language: 'Language', theme: 'Theme', textSize: 'Text size',
    currency: 'Currency symbol', numberFormat: 'Number format', tapHints: 'Show “tap to edit” hints',
    compactMode: 'Compact lists', dashboardFocus: 'Dashboard focus', changeFocus: 'Change what matters most',
    monthlyReminder: 'Monthly reminder',
    nav_home: 'Home', nav_expenses: 'Expenses', nav_savings: 'Savings', nav_plan: 'Chart', nav_more: 'Tools',
    income: 'Income', expenses: 'Expenses', balance: 'Balance', saved: 'Saved',
    appTitle: 'Finance Manager',
  },
  ha: {
    settings: 'Saituna', language: 'Harshe', theme: 'Jigo', textSize: 'Girman rubutu',
    currency: 'Alamar kudi', numberFormat: 'Tsarin lamba', tapHints: 'Nuna “taɓa don gyara”',
    compactMode: 'Jerin ƙanana', dashboardFocus: 'Manufar dashboard', changeFocus: 'Canza abin da ya fi muhimmanci',
    monthlyReminder: 'Tunatarwa kowane wata',
    nav_home: 'Gida', nav_expenses: 'Kashewa', nav_savings: 'Ajiya', nav_plan: 'Tsare-tsare', nav_more: 'Kayan aiki',
    income: 'Kudi shiga', expenses: 'Kashewa', balance: 'Ragowa', saved: 'An ajiye',
    appTitle: 'Manajan Kudi',
  },
  yo: {
    settings: 'Ètò', language: 'Èdè', theme: 'Àwọ̀', textSize: 'Ìwọ̀n ọ̀rọ̀',
    currency: 'Àmì owó', numberFormat: 'Ọ̀nà nọ́mbà', tapHints: 'Fi “tẹ̀ láti ṣàtúnṣe” hàn',
    compactMode: 'Àtòkọ kékeré', dashboardFocus: 'Ìfojúsọ́nà', changeFocus: 'Yí ohun tó ṣe pàtàkì padà',
    monthlyReminder: 'Ìránlọ́wọ́ oṣooṣù',
    nav_home: 'Ilé', nav_expenses: 'Ináwó', nav_savings: 'Ìfowópamọ́', nav_plan: 'Ètò', nav_more: 'Irinṣẹ́',
    income: 'Owó wọlé', expenses: 'Ináwó', balance: 'Ìyókù', saved: 'Ti fipamọ́',
    appTitle: 'Alábòójútó Owó',
  },
  ig: {
    settings: 'Ntọala', language: 'Asụsụ', theme: 'Atụmatụ', textSize: 'Nha ederede',
    currency: 'Akara ego', numberFormat: 'Ụdị ọnụọgụ', tapHints: 'Gosi “kpatụ ka ị dezigharịa”',
    compactMode: 'Ndepụta nke dị mkpụmkpụ', dashboardFocus: 'Leba anya', changeFocus: 'Gbanwee ihe kacha mkpa',
    monthlyReminder: 'Ncheta kwa ọnwa',
    nav_home: 'Ụlọ', nav_expenses: 'Mmefu', nav_savings: 'Nchekwa', nav_plan: 'Atụmatụ', nav_more: 'Ngwá ọrụ',
    income: 'Ego nbata', expenses: 'Mmefu', balance: 'Nke fọdụrụ', saved: 'Echekwara',
    appTitle: 'Onye Nlekọta Ego',
  },
  fr: {
    settings: 'Paramètres', language: 'Langue', theme: 'Thème', textSize: 'Taille du texte',
    currency: 'Devise', numberFormat: 'Format des nombres', tapHints: 'Afficher « toucher pour modifier »',
    compactMode: 'Listes compactes', dashboardFocus: 'Priorité du tableau de bord', changeFocus: 'Changer la priorité',
    monthlyReminder: 'Rappel mensuel',
    nav_home: 'Accueil', nav_expenses: 'Dépenses', nav_savings: 'Épargne', nav_plan: 'Chart', nav_more: 'Outils',
    income: 'Revenus', expenses: 'Dépenses', balance: 'Solde', saved: 'Épargné',
    appTitle: 'Gestionnaire Financier',
  },
  pi: {
    settings: 'Settings', language: 'Language', theme: 'Theme', textSize: 'Text size',
    currency: 'Money sign', numberFormat: 'Number style', tapHints: 'Show “tap to edit”',
    compactMode: 'Small lists', dashboardFocus: 'Wetin matter most', changeFocus: 'Change wetin matter',
    monthlyReminder: 'Monthly reminder',
    nav_home: 'Home', nav_expenses: 'Spend', nav_savings: 'Save', nav_plan: 'Chart', nav_more: 'Tools',
    income: 'Money wey enter', expenses: 'Money wey go', balance: 'Balance', saved: 'Money wey you save',
    appTitle: 'Money Manager',
  },
};

function t(key) {
  const lang = (state && state.language) || 'en';
  return (I18N[lang] && I18N[lang][key]) || (I18N.en[key]) || key;
}

function applyLanguage() {
  if (typeof applyRoseLanguage === 'function') applyRoseLanguage();
  document.querySelectorAll('[data-i18n]').forEach(el => {
    const key = el.getAttribute('data-i18n');
    if (key) el.textContent = t(key);
  });
  // Nav labels
  const navMap = { home: 'nav_home', expenses: 'nav_expenses', savings: 'nav_savings', plan: 'nav_plan', more: 'nav_more', settings: 'settings' };
  document.querySelectorAll('.dash-nav-btn').forEach(btn => {
    const small = btn.querySelector('small');
    const key = navMap[btn.dataset.view];
    if (small && key) small.textContent = t(key);
  });
  // Summary card labels
  const map = [
    ['.summary-card.income .card-label', 'income'],
    ['.summary-card.expenses .card-label', 'expenses'],
    ['.summary-card.balance .card-label', 'balance'],
    ['.summary-card.savings .card-label', 'saved'],
  ];
  map.forEach(([sel, key]) => {
    const el = document.querySelector(sel);
    if (el) el.textContent = t(key);
  });
  const title = document.querySelector('.header h1');
  if (title) title.textContent = t('appTitle');
}

function applyTheme() {
  document.body.classList.remove('theme-deep-dark', 'theme-soft-light', 'theme-calm-dark');
  const theme = state.theme || 'calm-dark';
  if (theme === 'deep-dark') document.body.classList.add('theme-deep-dark');
  if (theme === 'soft-light') document.body.classList.add('theme-soft-light');
}

function applyFontSize() {
  document.documentElement.classList.remove('font-large', 'font-xlarge');
  if (state.fontSize === 'large') document.documentElement.classList.add('font-large');
  if (state.fontSize === 'xlarge') document.documentElement.classList.add('font-xlarge');
}

function applyUiPrefs() {
  document.body.classList.toggle('compact-mode', !!state.compactMode);
  document.body.classList.toggle('hide-tap-hints', state.tapHints === false);
  applyTheme();
  applyFontSize();
  applyLanguage();
}

function loadSettingsForm() {
  const taglineInput = document.getElementById('appTaglineInput');
  if (taglineInput) taglineInput.value = typeof getAppTagline === 'function' ? getAppTagline() : 'Track · Budget · Save';

  const cur = document.getElementById('currencyInput');
  if (cur) cur.value = state.currency || '₦';
  const lang = document.getElementById('languageSelect');
  if (lang) lang.value = state.language || 'en';
  const theme = document.getElementById('themeSelect');
  if (theme) theme.value = state.theme || 'calm-dark';
  const font = document.getElementById('fontSizeSelect');
  if (font) font.value = state.fontSize || 'normal';
  const num = document.getElementById('numberFormatSelect');
  if (num) num.value = state.numberFormat || 'en-NG';
  const tap = document.getElementById('tapHintsCheck');
  if (tap) tap.checked = state.tapHints !== false;
  const compact = document.getElementById('compactModeCheck');
  if (compact) compact.checked = !!state.compactMode;
  const remSound = document.getElementById('reminderSoundCheck');
  if (remSound) remSound.checked = state.reminderSound !== false;
  const preset = document.getElementById('currencyPreset');
  if (preset) preset.value = ['₦','$','€','£','₵','KSh'].includes(state.currency) ? state.currency : '';
}

function saveSettingsFromForm() {
  // language applied after state update below

  const taglineInput = document.getElementById('appTaglineInput');
  if (taglineInput && typeof setAppTagline === 'function') {
    setAppTagline(taglineInput.value);
  }

  state.currency = (document.getElementById('currencyInput')?.value || '₦').trim() || '₦';
  state.language = document.getElementById('languageSelect')?.value || 'en';
  state.theme = document.getElementById('themeSelect')?.value || 'calm-dark';
  state.fontSize = document.getElementById('fontSizeSelect')?.value || 'normal';
  state.numberFormat = document.getElementById('numberFormatSelect')?.value || 'en-NG';
  state.tapHints = document.getElementById('tapHintsCheck')?.checked !== false;
  state.compactMode = !!document.getElementById('compactModeCheck')?.checked;
  state.reminderSound = document.getElementById('reminderSoundCheck')?.checked !== false;
  save();
  applyUiPrefs();
  if (typeof applyLanguage === 'function') applyLanguage();
  if (typeof applyRoseLanguage === 'function') applyRoseLanguage();
}



// ===================== Swipe between dashboards =====================
const DASH_ORDER = ['home', 'expenses', 'plan', 'savings', 'more', 'settings'];

function getCurrentDashView() {
  const active = document.querySelector('.dash-nav-btn.active');
  return (active && active.dataset.view) || 'home';
}

function setupSwipeNavigation() {
  const app = document.getElementById('mainApp');
  if (!app) return;

  let startX = 0;
  let startY = 0;
  let tracking = false;
  const THRESHOLD = 55; // min horizontal px
  const MAX_VERTICAL = 80; // ignore if mostly scrolling

  app.addEventListener('touchstart', (e) => {
    if (e.touches.length !== 1) return;
    // don't steal swipes from inputs/modals
    const t = e.target;
    if (t.closest('input, textarea, select, .modal, .support-panel, .coach-chat, .transactions-list')) {
      tracking = false;
      return;
    }
    tracking = true;
    startX = e.touches[0].clientX;
    startY = e.touches[0].clientY;
  }, { passive: true });

  app.addEventListener('touchmove', (e) => {
    if (!tracking) return;
    // optional: could show edge hint later
  }, { passive: true });

  app.addEventListener('touchend', (e) => {
    if (!tracking) return;
    tracking = false;
    const touch = e.changedTouches[0];
    if (!touch) return;
    const dx = touch.clientX - startX;
    const dy = touch.clientY - startY;
    if (Math.abs(dx) < THRESHOLD) return;
    if (Math.abs(dy) > MAX_VERTICAL && Math.abs(dy) > Math.abs(dx)) return; // vertical scroll

    const cur = getCurrentDashView();
    let idx = DASH_ORDER.indexOf(cur);
    if (idx < 0) idx = 0;

    // swipe left → next (home → expenses)
    // swipe right → previous (expenses → home)
    if (dx < 0 && idx < DASH_ORDER.length - 1) {
      setDashboardView(DASH_ORDER[idx + 1]);
      flashSwipeHint('next');
    } else if (dx > 0 && idx > 0) {
      setDashboardView(DASH_ORDER[idx - 1]);
      flashSwipeHint('prev');
    }
  }, { passive: true });
}

function flashSwipeHint(dir) {
  let el = document.getElementById('swipeHint');
  if (!el) {
    el = document.createElement('div');
    el.id = 'swipeHint';
    el.className = 'swipe-hint';
    document.body.appendChild(el);
  }
  el.textContent = dir === 'next' ? '→' : '←';
  el.classList.add('show');
  clearTimeout(flashSwipeHint._t);
  flashSwipeHint._t = setTimeout(() => el.classList.remove('show'), 280);
}


// ===================== Dashboard navigation =====================
function setDashboardView(view) {
  const allowed = ['home', 'expenses', 'savings', 'plan', 'more', 'settings', 'chart'];
  if (!allowed.includes(view)) view = 'home';
  document.querySelectorAll('.dash-panel').forEach(el => {
    const v = el.getAttribute('data-view');
    if (v === view) el.classList.add('view-active');
    else el.classList.remove('view-active');
  });
  // Home-only chrome
  ['streakPill', 'focusBadge', 'demoGuideBanner', 'nudgeBanner', 'reminderBanner'].forEach(id => {
    const el = document.getElementById(id);
    if (!el) return;
    if (view === 'home') {
      // leave reminder/nudge/demo to their own render logic; only unhide streak/focus if they were meant to show
    } else {
      el.classList.add('hidden');
    }
  });
  if (view === 'home' && typeof checkAndShowReminder === 'function') checkAndShowReminder();
  if (view === 'home' && typeof checkBudgetNudges === 'function') checkBudgetNudges();
  if (view === 'home' && typeof renderDemoGuideBanner === 'function') renderDemoGuideBanner();
  if (view === 'home' && typeof checkPositiveReinforcement === 'function') checkPositiveReinforcement();
  if (view === 'settings') {
    if (typeof loadSettingsForm === 'function') loadSettingsForm();
    if (typeof renderReminderStatus === 'function') renderReminderStatus();
  }
  document.querySelectorAll('.dash-nav-btn').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.view === view);
  });
  try { sessionStorage.setItem('financeDashView', view); } catch (e) {}
  // scroll to top of app content
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

function setupDashboardNav() {

  document.querySelectorAll('.summary-tappable').forEach(card => {
    const go = () => {
      const view = card.dataset.go || 'home';
      if (typeof setDashboardView === 'function') setDashboardView(view);
      if (card.dataset.focus === 'income') {
        const form = document.getElementById('incomeForm');
        if (form) form.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
    };
    card.addEventListener('click', go);
    card.addEventListener('keydown', e => {
      if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); go(); }
    });
  });

  document.querySelectorAll('.dash-nav-btn').forEach(btn => {
    btn.addEventListener('click', () => setDashboardView(btn.dataset.view));
  });
  document.querySelectorAll('.dash-card[data-go]').forEach(card => {
    card.addEventListener('click', () => setDashboardView(card.dataset.go));
  });
  let start = 'home';
  try { start = sessionStorage.getItem('financeDashView') || 'home'; } catch (e) {}
  setDashboardView(start);
}



// ===================== Search, health, bills, undo, tutorial, wallets, report, trend =====================
let _expenseSearch = '';
let _expenseFilterCat = '';
let _lastDeleted = null;
let _undoTimer = null;

function renderBudgetHealth() {
  const fill = document.getElementById('healthFill');
  const label = document.getElementById('healthPctLabel');
  const hint = document.getElementById('healthHint');
  if (!fill || !label) return;
  const { income, expenses, saved, balance } = getTotals();
  if (income <= 0) {
    fill.style.width = '0%';
    fill.className = 'health-fill';
    label.textContent = '0% of salary used';
    if (hint) hint.textContent = 'Add your salary to track how much of the month you’ve used.';
    return;
  }
  const used = expenses + saved;
  const pct = Math.min(100, Math.round((used / income) * 100));
  fill.style.width = pct + '%';
  fill.className = 'health-fill' + (pct >= 90 ? ' danger' : pct >= 70 ? ' warn' : '');
  label.textContent = pct + '% of salary used';
  if (hint) {
    hint.textContent = balance >= 0
      ? `Spent ${formatMoney(expenses)} · Saved ${formatMoney(saved)} · Balance ${formatMoney(balance)}`
      : `Over by ${formatMoney(Math.abs(balance))} — review expenses`;
  }
}

function renderUpcomingBills() {
  const list = document.getElementById('upcomingBillsList');
  if (!list) return;
  const bills = state.recurringBills || [];
  if (!bills.length) {
    list.innerHTML = '<div class="empty-state">No recurring bills yet. Add them under Tools.</div>';
    return;
  }
  const today = new Date();
  const day = today.getDate();
  const rows = bills.map(b => {
    const due = Math.min(28, Math.max(1, Number(b.dueDay) || 1));
    let delta = due - day;
    if (delta < -3) delta += 30; // rough next month
    return { ...b, due, delta };
  }).sort((a, b) => a.delta - b.delta);
  list.innerHTML = rows.slice(0, 6).map(b => {
    const when = b.delta === 0 ? 'Due today' : b.delta > 0 ? `In ${b.delta} day(s)` : `Due ${Math.abs(b.delta)} day(s) ago`;
    return `<div class="upcoming-item"><span>${escapeHtml(b.name)} · ${when}</span><strong>${formatMoney(b.amount)}</strong></div>`;
  }).join('');
}

function renderBalanceTrend() {
  const el = document.getElementById('balanceTrend');
  if (!el) return;
  const months = [];
  let key = state.currentMonth;
  for (let i = 5; i >= 0; i--) {
    months.push(getMonthKeyOffset(key, -i));
  }
  // unique
  const seen = new Set();
  const list = [];
  months.forEach(m => { if (!seen.has(m)) { seen.add(m); list.push(m); } });
  const totals = list.map(m => {
    const t = typeof totalsForMonth === 'function' ? totalsForMonth(m) : { income: 0, expenses: 0, saved: 0, balance: 0 };
    return { month: m, balance: t.balance };
  });
  const maxAbs = Math.max(1, ...totals.map(t => Math.abs(t.balance)));
  el.innerHTML = totals.map(t => {
    const h = Math.max(6, Math.round((Math.abs(t.balance) / maxAbs) * 72));
    const cls = t.balance >= 0 ? 'pos' : 'neg';
    const label = (t.month || '').slice(5); // MM
    return `<div class="trend-bar ${cls}" style="height:${h}px" title="${t.month}: ${formatMoney(t.balance)}"><span>${label}</span></div>`;
  }).join('');
}

function populateExpenseFilter() {
  const sel = document.getElementById('expenseFilterCat');
  if (!sel) return;
  const cur = sel.value;
  sel.innerHTML = '<option value="">All categories</option>' +
    state.categories.map(c => `<option value="${c.id}">${c.icon || ''} ${c.name}</option>`).join('');
  sel.value = cur;
}

function showUndoToast(text, restoreFn) {
  const toast = document.getElementById('undoToast');
  const label = document.getElementById('undoToastText');
  const btn = document.getElementById('undoToastBtn');
  if (!toast || !btn) return;
  if (label) label.textContent = text || 'Deleted';
  toast.classList.remove('hidden');
  _lastDeleted = restoreFn;
  clearTimeout(_undoTimer);
  _undoTimer = setTimeout(() => {
    toast.classList.add('hidden');
    _lastDeleted = null;
  }, 5000);
  btn.onclick = () => {
    if (typeof _lastDeleted === 'function') _lastDeleted();
    _lastDeleted = null;
    toast.classList.add('hidden');
    clearTimeout(_undoTimer);
  };
}

const TUTORIAL_KEY = 'financeManager_tutorial_v1';
const TUTORIAL_STEPS = [
  { title: 'Add your salary', body: 'Open Tools → Income and enter this month’s salary. Balance and the chart need this first.', view: 'more' },
  { title: 'Log an expense', body: 'Open Expenses and add rent, food, or transport. It comes off your salary and updates Balance.', view: 'expenses' },
  { title: 'Check your chart', body: 'Open Chart to see how this month’s money is split — and use Settings anytime for backup.', view: 'plan' },
];
let _tutorialStep = 0;

function showTutorialIfNeeded() {
  try {
    if (localStorage.getItem(TUTORIAL_KEY) === '1') return;
  } catch (e) {}
  _tutorialStep = 0;
  const ov = document.getElementById('tutorialOverlay');
  if (!ov) return;
  ov.classList.remove('hidden');
  renderTutorialStep();
}

function renderTutorialStep() {
  const s = TUTORIAL_STEPS[_tutorialStep];
  if (!s) return finishTutorial();
  const lab = document.getElementById('tutorialStepLabel');
  const title = document.getElementById('tutorialTitle');
  const body = document.getElementById('tutorialBody');
  const next = document.getElementById('tutorialNext');
  if (lab) lab.textContent = `Step ${_tutorialStep + 1} of ${TUTORIAL_STEPS.length}`;
  if (title) title.textContent = s.title;
  if (body) body.textContent = s.body;
  if (next) next.textContent = _tutorialStep >= TUTORIAL_STEPS.length - 1 ? 'Done' : 'Next';
  if (s.view && typeof setDashboardView === 'function') setDashboardView(s.view);
}

function finishTutorial() {
  try { localStorage.setItem(TUTORIAL_KEY, '1'); } catch (e) {}
  const ov = document.getElementById('tutorialOverlay');
  if (ov) ov.classList.add('hidden');
  if (typeof setDashboardView === 'function') setDashboardView('home');
}

function setupTutorial() {
  const next = document.getElementById('tutorialNext');
  const skip = document.getElementById('tutorialSkip');
  if (next) next.onclick = () => {
    _tutorialStep += 1;
    if (_tutorialStep >= TUTORIAL_STEPS.length) finishTutorial();
    else renderTutorialStep();
  };
  if (skip) skip.onclick = () => finishTutorial();
}

function downloadMonthlyReport() {
  const { income, expenses, saved, balance } = getTotals();
  const monthLabel = typeof formatMonthLabel === 'function' ? formatMonthLabel(state.currentMonth) : state.currentMonth;
  const catRows = state.categories.map(c => {
    const spent = getCategorySpent(c.id);
    if (spent <= 0) return '';
    return `<tr><td>${escapeHtml(c.name)}</td><td style="text-align:right">${formatMoney(spent)}</td></tr>`;
  }).join('');
  const txRows = getMonthTransactions().sort((a,b)=>String(a.date).localeCompare(String(b.date))).map(t =>
    `<tr>
      <td>${escapeHtml(t.date || '')}</td>
      <td>${escapeHtml(t.type || '')}</td>
      <td>${escapeHtml(t.desc || '')}</td>
      <td>${escapeHtml(t.wallet || '')}</td>
      <td style="text-align:right">${formatMoney(t.amount)}</td>
    </tr>`
  ).join('');
  const htmlDoc = `<!DOCTYPE html><html><head><meta charset="utf-8"/><title>Report ${monthLabel}</title>
  <style>
    body{font-family:system-ui,sans-serif;padding:24px;color:#111;max-width:800px;margin:0 auto}
    h1{font-size:1.4rem;margin:0 0 0.25rem} .muted{color:#666;font-size:0.9rem}
    table{width:100%;border-collapse:collapse;margin:1rem 0}
    th,td{border-bottom:1px solid #ddd;padding:8px;text-align:left;font-size:0.9rem}
    th{font-weight:700} .sum td{font-weight:700}
    @media print{button{display:none}}
  </style></head><body>
  <button onclick="window.print()">Print / Save as PDF</button>
  <h1>Finance Manager — Monthly Report</h1>
  <p class="muted">${monthLabel} · Generated ${new Date().toLocaleString()}</p>
  <table class="sum">
    <tr><td>Income</td><td style="text-align:right">${formatMoney(income)}</td></tr>
    <tr><td>Expenses</td><td style="text-align:right">${formatMoney(expenses)}</td></tr>
    <tr><td>Saved</td><td style="text-align:right">${formatMoney(saved)}</td></tr>
    <tr><td>Balance</td><td style="text-align:right">${formatMoney(balance)}</td></tr>
  </table>
  <h2>By category</h2>
  <table><thead><tr><th>Category</th><th style="text-align:right">Amount</th></tr></thead><tbody>${catRows || '<tr><td colspan="2">No expenses</td></tr>'}</tbody></table>
  <h2>Transactions</h2>
  <table><thead><tr><th>Date</th><th>Type</th><th>Description</th><th>Wallet</th><th style="text-align:right">Amount</th></tr></thead>
  <tbody>${txRows || '<tr><td colspan="5">None</td></tr>'}</tbody></table>
  </body></html>`;
  const blob = new Blob([htmlDoc], { type: 'text/html;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const w = window.open(url, '_blank');
  if (!w) {
    const a = document.createElement('a');
    a.href = url;
    a.download = `finance-report-${state.currentMonth}.html`;
    a.click();
  }
  setTimeout(() => URL.revokeObjectURL(url), 10000);
}


function setupSearchAndExtras() {
  const incomeSearch = document.getElementById('incomeSearch');
  if (incomeSearch) incomeSearch.addEventListener('input', () => renderIncomeList());

  const search = document.getElementById('expenseSearch');
  const filter = document.getElementById('expenseFilterCat');
  if (search) search.addEventListener('input', () => { _expenseSearch = search.value.trim().toLowerCase(); renderExpenseList(); });
  if (filter) filter.addEventListener('change', () => { _expenseFilterCat = filter.value; renderExpenseList(); });
  const report = document.getElementById('monthlyReportBtn');
  if (report) report.addEventListener('click', downloadMonthlyReport);
  setupTutorial();
  // PWA service worker
  if ('serviceWorker' in navigator) {
    try {
      const swCode = `self.addEventListener('install', e => self.skipWaiting());
self.addEventListener('activate', e => e.waitUntil(clients.claim()));
self.addEventListener('fetch', e => { /* network-first, fallback offline shell not required for file */ });`;
      // Only register if not file://
      if (location.protocol.startsWith('http')) {
        const blob = new Blob([swCode], { type: 'application/javascript' });
        const swUrl = URL.createObjectURL(blob);
        navigator.serviceWorker.register('sw.js').catch(() => {
          navigator.serviceWorker.register(swUrl).catch(() => {});
        });
      }
    } catch (e) {}
  }
}



// ===================== Rose voice assistant =====================

// Rose language packs (match app language)
const ROSE_LANG = {
  en: {
    locale: 'en-NG',
    name: 'Rose',
    statusIdle: 'Tap Speak when you are ready',
    listening: 'Listening… say “Rose, spent 2000 on food”',
    heard: 'Heard',
    talk: '🎤 Talk to Rose',
    listeningBtn: 'Listening…',
    typePh: 'Or type for Rose…',
    subtitle: 'Your voice assistant',
    hi: 'My name is Rose, how may I help you?',
    help: 'I can log expenses, savings, read your balance or salary, and open tabs. Try: spent 5000 on food · how much left · open chart · add 2000 to savings.',
    empty: 'I did not catch that. Try “Rose, spent 2000 on food”.',
    open: 'Opening',
    balance0: 'Add your salary first so I can track what is left.',
    balance1: (b, inc, exp, sav) => `Your balance is ${b}. Salary ${inc}, spent ${exp}, saved ${sav}.`,
    income0: 'No salary recorded this month yet.',
    income1: (inc) => `This month's income is ${inc}.`,
    saved: (a, b) => `Saved ${a}. Balance now ${b}.`,
    logged: (a, d, b) => `Logged ${a} for ${d}. Balance ${b}.`,
    fallback: 'Sorry, I am not sure. Say “Rose, help” for ideas, or “Rose, spent 3000 on food”.',
    micUnsupported: 'Voice not supported here — type below (try Chrome).',
    micError: 'Could not hear you — try again or type.',
    micBusy: 'Mic busy — try again.',
  },
  ha: {
    locale: 'ha-NG',
    name: 'Rose',
    statusIdle: 'Taɓa Speak idan ka shirya',
    listening: 'Ina saurare… ce “Rose, na kashe 2000 a abinci”',
    heard: 'Na ji',
    talk: '🎤 Yi magana da Rose',
    listeningBtn: 'Ina saurare…',
    typePh: 'Ko rubuta wa Rose…',
    subtitle: 'Mataimakiyar murya',
    hi: 'Sannu, ni Rose. Za ka iya gaya mini in rubuta kashewa, in duba ragowarka, ko in buɗe shafi.',
    help: 'Zan iya rubuta kashewa da ajiya, in gaya maka ragowa ko albashi, in buɗe shafuka. Gwada: na kashe 5000 a abinci · nawa ya rage · buɗe chart · ajiye 2000.',
    empty: 'Ban fahimta ba. Gwada “Rose, na kashe 2000 a abinci”.',
    open: 'Ana buɗewa',
    balance0: 'Da farko shigar da albashi domin in bi diddigin ragowa.',
    balance1: (b, inc, exp, sav) => `Ragowarka ${b}. Albashi ${inc}, an kashe ${exp}, an ajiye ${sav}.`,
    income0: 'Babu albashi a wannan wata tukuna.',
    income1: (inc) => `Kudin shiga na wannan wata ${inc}.`,
    saved: (a, b) => `An ajiye ${a}. Ragowa yanzu ${b}.`,
    logged: (a, d, b) => `An rubuta ${a} don ${d}. Ragowa ${b}.`,
    fallback: 'Ban tabbata ba. Ce “Rose, help” ko “Rose, na kashe 3000 a abinci”.',
    micUnsupported: 'Murya ba ta yi aiki ba a nan — rubuta a ƙasa.',
    micError: 'Ban ji ka ba — sake gwadawa ko rubuta.',
    micBusy: 'Mic yana aiki — sake gwadawa.',
  },
  yo: {
    locale: 'yo-NG',
    name: 'Rose',
    statusIdle: 'Tẹ mic tabi sọ “Rose…”',
    listening: 'Mo ń gbọ́… sọ “Rose, mo ná 2000 lórí oúnjẹ”',
    heard: 'Mo gbọ́',
    talk: '🎤 Sọ̀rọ̀ pẹ̀lú Rose',
    listeningBtn: 'Mo ń gbọ́…',
    typePh: 'Tàbí kọ̀wé sí Rose…',
    subtitle: 'Olùrànlọ́wọ́ ohùn',
    hi: 'Pẹ̀lẹ́, èmi ni Rose. Mo lè ṣe àkọsílẹ̀ ináwó, ṣàyẹ̀wò owó tó kù, tàbí ṣí ojú-ìwé.',
    help: 'Mo lè ṣe àkọsílẹ̀ ináwó àti ìfowópamọ́, sọ owó tó kù tàbí owó-oṣù, ṣí àwọn ojú-ìwé. Wádìí: mo ná 5000 lórí oúnjẹ · mélòó ló kù · ṣí chart · fi 2000 pamọ́.',
    empty: 'Mi ò gbọ́ yé. Wádìí “Rose, mo ná 2000 lórí oúnjẹ”.',
    open: 'Ń ṣí',
    balance0: 'Kọ́kọ́ fi owó-oṣù sílẹ̀ kí n lè tọpinpin owó tó kù.',
    balance1: (b, inc, exp, sav) => `Owó tó kù jẹ́ ${b}. Owó-oṣù ${inc}, ináwó ${exp}, ìfowópamọ́ ${sav}.`,
    income0: 'Kò sí owó-oṣù fún oṣù yìí síbẹ̀.',
    income1: (inc) => `Owó wọlé oṣù yìí jẹ́ ${inc}.`,
    saved: (a, b) => `A fi ${a} pamọ́. Owó tó kù nísinsin yìí ${b}.`,
    logged: (a, d, b) => `A kọ ${a} fún ${d}. Owó tó kù ${b}.`,
    fallback: 'Mi ò dá a. Sọ “Rose, help” tàbí “Rose, mo ná 3000 lórí oúnjẹ”.',
    micUnsupported: 'Ohùn kò ṣiṣẹ́ níbí — kọ̀wé ní ìsàlẹ̀.',
    micError: 'Mi ò gbọ́ ọ — gbìyànjú lẹ́ẹ̀kan si tàbí kọ̀wé.',
    micBusy: 'Mic ń ṣiṣẹ́ — gbìyànjú lẹ́ẹ̀kan si.',
  },
  ig: {
    locale: 'en-NG',
    name: 'Rose',
    statusIdle: 'Kpatụ mic ma ọ bụ sị “Rose…”',
    listening: 'Ana m ege ntị… sị “Rose, e ji 2000 gaa nri”',
    heard: 'Anụrụ m',
    talk: '🎤 Kwuo okwu nye Rose',
    listeningBtn: 'Ana m ege ntị…',
    typePh: 'Ma ọ bụ dee nye Rose…',
    subtitle: 'Onye inyeaka olu',
    hi: 'Ndewo, a bụ m Rose. Ị nwere ike ịgwa m ka m dee mmefu, lelee ego fọdụrụ, ma ọ bụ meghee ibe.',
    help: 'Enwere m ike ide mmefu na nchekwa, gwa gị ego fọdụrụ ma ọ bụ ụgwọ ọnwa, meghee ibe. Nwaa: e ji 5000 gaa nri · ego ole fọdụrụ · meghee chart · chekwaa 2000.',
    empty: 'Aghọtaghị m. Nwaa “Rose, e ji 2000 gaa nri”.',
    open: 'Na-emeghe',
    balance0: 'Buru ụzọ tinye ụgwọ ọnwa ka m nwee ike ịgbaso ego fọdụrụ.',
    balance1: (b, inc, exp, sav) => `Ego fọdụrụ bụ ${b}. Ụgwọ ọnwa ${inc}, e mefuru ${exp}, echekwara ${sav}.`,
    income0: 'Enweghị ụgwọ ọnwa n’ọnwa a.',
    income1: (inc) => `Ego nbata n’ọnwa a bụ ${inc}.`,
    saved: (a, b) => `Echekwara ${a}. Ego fọdụrụ ugbu a ${b}.`,
    logged: (a, d, b) => `Edekọrọ ${a} maka ${d}. Ego fọdụrụ ${b}.`,
    fallback: 'Ekweghị m. Sị “Rose, help” ma ọ bụ “Rose, e ji 3000 gaa nri”.',
    micUnsupported: 'Olu adịghị arụ ọrụ ebe a — dee n’okpuru.',
    micError: 'Anụghị m gị — nwaa ọzọ ma ọ bụ dee.',
    micBusy: 'Mic na-arụ ọrụ — nwaa ọzọ.',
  },
  fr: {
    locale: 'fr-FR',
    name: 'Rose',
    statusIdle: 'Appuyez sur le micro ou dites « Rose… »',
    listening: 'J’écoute… dites « Rose, dépensé 2000 en nourriture »',
    heard: 'J’ai entendu',
    talk: '🎤 Parler à Rose',
    listeningBtn: 'Écoute…',
    typePh: 'Ou écrivez à Rose…',
    subtitle: 'Votre assistante vocale',
    hi: 'Bonjour, je suis Rose. Demandez-moi d’enregistrer une dépense, de vérifier le solde ou d’ouvrir un onglet.',
    help: 'Je peux enregistrer dépenses et épargne, lire le solde ou le salaire, ouvrir des onglets. Essayez : dépensé 5000 en nourriture · solde · ouvrir chart · épargner 2000.',
    empty: 'Je n’ai pas compris. Essayez « Rose, dépensé 2000 en nourriture ».',
    open: 'Ouverture de',
    balance0: 'Ajoutez d’abord votre salaire pour suivre le reste.',
    balance1: (b, inc, exp, sav) => `Votre solde est ${b}. Salaire ${inc}, dépensé ${exp}, épargné ${sav}.`,
    income0: 'Aucun salaire enregistré ce mois-ci.',
    income1: (inc) => `Les revenus de ce mois sont ${inc}.`,
    saved: (a, b) => `Épargné ${a}. Solde maintenant ${b}.`,
    logged: (a, d, b) => `Enregistré ${a} pour ${d}. Solde ${b}.`,
    fallback: 'Je ne suis pas sûre. Dites « Rose, help » ou « Rose, dépensé 3000 en nourriture ».',
    micUnsupported: 'Voix non prise en charge — écrivez ci-dessous.',
    micError: 'Je ne vous ai pas entendu — réessayez ou écrivez.',
    micBusy: 'Micro occupé — réessayez.',
  },
  pi: {
    locale: 'en-NG',
    name: 'Rose',
    statusIdle: 'Press mic or talk say “Rose…”',
    listening: 'I dey hear… talk “Rose, I spend 2000 for food”',
    heard: 'I hear',
    talk: '🎤 Talk to Rose',
    listeningBtn: 'I dey hear…',
    typePh: 'Or type give Rose…',
    subtitle: 'Your voice padi',
    hi: 'How far, na Rose be this. You fit tell me make I write spend, check balance, or open page.',
    help: 'I fit log spend and save, talk balance or salary, open tabs. Try: I spend 5000 for food · how much remain · open chart · save 2000.',
    empty: 'I no hear well. Try “Rose, I spend 2000 for food”.',
    open: 'I dey open',
    balance0: 'First add your salary make I fit track wetin remain.',
    balance1: (b, inc, exp, sav) => `Your balance na ${b}. Salary ${inc}, spend ${exp}, save ${sav}.`,
    income0: 'No salary for this month yet.',
    income1: (inc) => `Money wey enter this month na ${inc}.`,
    saved: (a, b) => `I don save ${a}. Balance now ${b}.`,
    logged: (a, d, b) => `I log ${a} for ${d}. Balance ${b}.`,
    fallback: 'I no sure. Talk “Rose, help” or “Rose, I spend 3000 for food”.',
    micUnsupported: 'Voice no work here — type for below.',
    micError: 'I no hear you — try again or type.',
    micBusy: 'Mic dey busy — try again.',
  },
};

function getRoseLang() {
  const code = (state && state.language) || 'en';
  return ROSE_LANG[code] || ROSE_LANG.en;
}

function applyRoseLanguage() {
  const R = getRoseLang();
  const status = document.getElementById('roseStatus');
  const listenBtn = document.getElementById('roseListenBtn');
  const sub = document.getElementById('roseSubtitle') || document.querySelector('#rosePanel .rose-panel-header p');
  const nameEl = document.querySelector('#rosePanel .rose-panel-header strong');
  const fabName = document.querySelector('.rose-fab-name');
  if (status && !status.dataset.locked) status.textContent = R.statusIdle;
  if (listenBtn) listenBtn.textContent = '🎤 Speak';
  const typeInput = document.getElementById('roseTypeInput');
  if (typeInput && typeof getRoseLang === 'function') {
    const R2 = getRoseLang();
    typeInput.placeholder = R2.typePh || 'Type for Rose…';
  }
  if (sub) sub.textContent = R.subtitle || 'Speak with me';
  if (nameEl) nameEl.textContent = R.name;
  if (fabName) fabName.textContent = R.name;
}



// ===================== Rose cloud female voice (not phone system voice) =====================
// Uses online neural-style TTS audio so Rose does not depend on device voices.
let _roseAudio = null;

function roseTtsLangCode() {
  const code = (state && state.language) || 'en';
  const map = { en: 'en', ha: 'ha', yo: 'yo', ig: 'en', fr: 'fr', pi: 'en' };
  return map[code] || 'en';
}

function roseStopAudio() {
  try {
    if (_roseAudio) {
      _roseAudio.onended = null;
      _roseAudio.onerror = null;
      _roseAudio.pause();
      _roseAudio.src = '';
      _roseAudio = null;
    }
  } catch (e) {}
  try { if (typeof roseStopAudio === 'function') roseStopAudio(); else if (window.speechSynthesis) window.speechSynthesis.cancel(); } catch (e) {}
}

function roseSpeakBrowserFallback(text, onDone) {
  try {
    if (!window.speechSynthesis) {
      if (typeof onDone === 'function') onDone();
      return;
    }
    window.speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(String(text));
    u.rate = 0.95;
    u.pitch = 1.25;
    u.volume = 1;
    u.lang = (typeof getRoseLang === 'function' && getRoseLang().locale) || 'en-US';
    const femaleRe = /female|samantha|victoria|karen|zira|hazel|susan|ava|kate|google [a-z ]*female|microsoft zira/i;
    const maleRe = /male|david|mark|daniel|fred|google [a-z ]*male/i;
    const voices = window.speechSynthesis.getVoices() || [];
    let best = null, score = -1;
    voices.forEach(v => {
      let s = 0;
      const n = v.name || '';
      if (femaleRe.test(n)) s += 50;
      if (maleRe.test(n)) s -= 40;
      if ((v.lang || '').toLowerCase().startsWith('en')) s += 5;
      if (s > score) { score = s; best = v; }
    });
    if (best) u.voice = best;
    u.onend = () => { if (typeof onDone === 'function') onDone(); };
    u.onerror = () => { if (typeof onDone === 'function') onDone(); };
    window.speechSynthesis.speak(u);
  } catch (e) {
    if (typeof onDone === 'function') onDone();
  }
}

function roseSpeakCloud(text, onDone) {
  // Stream female voice audio from Google Translate TTS (server-side voice, not phone)
  // Split long lines so requests stay under length limits
  const chunks = [];
  const raw = String(text || '').trim();
  if (!raw) {
    if (typeof onDone === 'function') onDone();
    return;
  }
  const parts = raw.match(/[^.!?]+[.!?]+|[^.!?]+$/g) || [raw];
  parts.forEach(p => {
    const s = p.trim();
    if (!s) return;
    if (s.length <= 160) chunks.push(s);
    else {
      for (let i = 0; i < s.length; i += 150) chunks.push(s.slice(i, i + 150));
    }
  });

  const tl = roseTtsLangCode();
  let i = 0;

  const playNext = () => {
    if (i >= chunks.length) {
      if (typeof onDone === 'function') onDone();
      return;
    }
    const q = chunks[i++];
    // client=tw-ob is widely used for translate_tts audio
    const url = 'https://translate.google.com/translate_tts?ie=UTF-8&client=tw-ob&tl='
      + encodeURIComponent(tl) + '&q=' + encodeURIComponent(q);
    try {
      roseStopAudio();
      const audio = new Audio();
      _roseAudio = audio;
      audio.preload = 'auto';
      // playsInline helps mobile
      audio.setAttribute('playsinline', 'true');
      audio.src = url;
      audio.onended = () => playNext();
      audio.onerror = () => {
        // Network / blocked → fall back to browser voice for remaining text
        const rest = [q].concat(chunks.slice(i)).join(' ');
        roseSpeakBrowserFallback(rest, onDone);
      };
      const p = audio.play();
      if (p && typeof p.then === 'function') {
        p.catch(() => {
          const rest = [q].concat(chunks.slice(i)).join(' ');
          roseSpeakBrowserFallback(rest, onDone);
        });
      }
    } catch (e) {
      roseSpeakBrowserFallback(chunks.slice(i - 1).join(' '), onDone);
    }
  };

  playNext();
}

function roseSpeak(text, onDone) {
  const spoken = String(text || '').trim();
  if (!spoken) {
    if (typeof onDone === 'function') onDone();
    return;
  }
  if (typeof roseAppend === 'function') roseAppend('rose', spoken);
  const orb = document.getElementById('roseOrb');
  if (orb) orb.classList.add('speaking');

  const finish = () => {
    if (orb) orb.classList.remove('speaking');
    if (typeof onDone === 'function') {
      const cb = onDone;
      onDone = null;
      try { cb(); } catch (e) {}
    }
  };

  roseStopAudio();
  const isFile = (location.protocol === 'file:');
  if (isFile) {
    roseSpeakBrowserFallback(spoken, finish);
  } else {
    roseSpeakCloud(spoken, finish);
  }
}


function roseAppend(role, text) {
  // Voice-first: show the latest line Rose (or you) said — no chat typing UI
  const spoken = document.getElementById('roseSpoken');
  if (spoken) {
    if (role === 'user') spoken.textContent = 'You: ' + text;
    else spoken.textContent = text;
  }
  const orb = document.getElementById('roseOrb');
  if (orb) {
    orb.classList.toggle('speaking', role === 'rose');
    if (role === 'rose') setTimeout(() => orb.classList.remove('speaking'), 2000);
  }
}

function roseSetStatus(text) {
  const el = document.getElementById('roseStatus');
  if (el) el.textContent = text;
}

function roseStripWake(text) {
  return String(text || '')
    .replace(/^\s*(hey\s+)?rose[,:\s]+/i, '')
    .replace(/\brosie\b[,:\s]*/i, '')
    .trim();
}

function roseGuessCategory(text) {
  const t = (text || '').toLowerCase();
  const map = [
    { keys: ['food', 'grocery', 'groceries', 'market', 'supermarket', 'restaurant', 'lunch', 'dinner', 'breakfast', 'eat'], id: 'food' },
    { keys: ['rent', 'house', 'landlord'], id: 'rent' },
    { keys: ['uber', 'bus', 'transport', 'fuel', 'petrol', 'taxi', 'bolt'], id: 'transport' },
    { keys: ['light', 'electric', 'electricity', 'water', 'utility', 'utilities', 'data', 'airtime', 'wifi'], id: 'utilities' },
  ];
  for (const m of map) {
    if (m.keys.some(k => t.includes(k))) {
      if (state.categories.some(c => c.id === m.id)) return m.id;
    }
  }
  return state.categories[0]?.id || 'food';
}

function roseHandleCommand(raw) {
  const original = String(raw || '').trim();
  if (!original) {
    const msg = 'I did not catch that. Try “Rose, spent 2000 on food”.';
    roseSpeak(msg);
    return;
  }
  roseAppend('user', original);
  const text = roseStripWake(original).toLowerCase();

  // Help
  if (/^(help|what can you do|commands)\b/.test(text) || text === '') {
    const msg = 'I can log expenses, savings, read your balance or salary, and open tabs. Try: spent 5000 on food · how much left · open chart · add 2000 to savings.';
    roseSpeak(msg);
    return;
  }

  // Navigate
  const navMap = [
    { keys: ['open home', 'go home', 'show home', 'home page', 'dashboard'], view: 'home' },
    { keys: ['open expense', 'show expense', 'go to expense', 'expenses', 'spending'], view: 'expenses' },
    { keys: ['open saving', 'show saving', 'go to saving', 'savings', 'goals'], view: 'savings' },
    { keys: ['open chart', 'show chart', 'show pie', 'open plan', 'chart', 'pie chart'], view: 'plan' },
    { keys: ['open setting', 'show setting', 'settings'], view: 'settings' },
    { keys: ['open tool', 'show tool', 'tools', 'more'], view: 'more' },
  ];
  for (const n of navMap) {
    if (n.keys.some(k => text.includes(k))) {
      if (typeof setDashboardView === 'function') setDashboardView(n.view);
      const msg = R.open + ' ' + n.view + '.';
      roseSpeak(msg);
      return;
    }
  }

  // Balance / left
  if (/how much (do i have )?left|balance|what.?s left|remaining/.test(text)) {
    const { income, expenses, saved, balance } = getTotals();
    const msg = income > 0
      ? R.balance1(formatMoney(balance), formatMoney(income), formatMoney(expenses), formatMoney(saved))
      : `${typeof formatMoney === 'function' ? formatMoney(balance) : balance}. ${R.balance0}`;
    roseSpeak(msg);
    return;
  }

  // Salary / income
  if (/salary|income|how much (do i |did i )?earn|my pay/.test(text) && !/spent|paid|expense/.test(text)) {
    const { income } = getTotals();
    const msg = income > 0 ? R.income1(formatMoney(income)) : R.income0;
    roseSpeak(msg);
    return;
  }

  // Savings contribution
  const saveMatch = text.match(/(?:add|save|put)\s*(?:₦|naira|\$)?\s*([\d,]+(?:\.\d+)?)\s*(?:to|into|in)?\s*saving/);
  if (saveMatch || (/saving/.test(text) && /([\d,]+)/.test(text) && /(add|save|put)/.test(text))) {
    const amtMatch = text.match(/([\d,]+(?:\.\d+)?)/);
    const amount = amtMatch ? parseFloat(amtMatch[1].replace(/,/g, '')) : 0;
    if (amount > 0) {
      const goal = (state.goals && state.goals[0]) || null;
      state.transactions.push({
        id: uid(),
        type: 'saving',
        desc: 'Rose: savings',
        amount,
        categoryId: goal ? goal.id : 'savings',
        date: dateInViewedMonth(1),
        month: state.currentMonth,
        isDemo: false,
      });
      if (goal) goal.current = Number(goal.current || 0) + amount;
      save();
      render();
      const { balance } = getTotals();
      const msg = R.saved(formatMoney(amount), formatMoney(balance));
      roseSpeak(msg);
      return;
    }
  }

  // Expense via existing parser
  const parsed = typeof parseVoiceExpense === 'function' ? parseVoiceExpense(roseStripWake(original)) : null;
  if (parsed && parsed.amount && parsed.amount > 0) {
    const categoryId = parsed.categoryId || roseGuessCategory(parsed.desc || original);
    state.transactions.push({
      id: uid(),
      type: 'expense',
      desc: (parsed.desc || 'Rose expense').slice(0, 80),
      amount: parsed.amount,
      categoryId,
      date: dateInViewedMonth(1),
      month: state.currentMonth,
      isDemo: false,
      wallet: 'cash',
    });
    save();
    render();
    const { balance } = getTotals();
    const cat = state.categories.find(c => c.id === categoryId);
    const msg = R.logged(formatMoney(parsed.amount), parsed.desc || (cat ? cat.name : 'expense'), formatMoney(balance));
    roseSpeak(msg);
    return;
  }

  // Generic amount + on/for
  const amt2 = original.match(/(?:₦|naira|\$)?\s*([\d,]+(?:\.\d+)?)/i);
  if (amt2 && /(spent|paid|pay|buy|bought|expense)/i.test(original)) {
    const amount = parseFloat(amt2[1].replace(/,/g, ''));
    const categoryId = roseGuessCategory(original);
    const descMatch = original.match(/(?:on|for)\s+(.+)$/i);
    const desc = descMatch ? descMatch[1].trim() : 'Rose expense';
    state.transactions.push({
      id: uid(), type: 'expense', desc: desc.slice(0, 80), amount, categoryId,
      date: dateInViewedMonth(1), month: state.currentMonth, isDemo: false, wallet: 'cash',
    });
    save();
    render();
    const { balance } = getTotals();
    const msg = R.logged(formatMoney(amount), desc, formatMoney(balance));
    roseSpeak(msg);
    return;
  }

  const fallback = R.fallback;
  roseSpeak(fallback);
}

function roseStartListening() {
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  const fab = document.getElementById('roseFab');
  const listenBtn = document.getElementById('roseListenBtn');
  if (!SR) {
    roseSetStatus(getRoseLang().micUnsupported);
    const msg = getRoseLang().micUnsupported;
    roseSpeak(msg);
    return;
  }
  const rec = new SR();
  rec.lang = (typeof getRoseLang === 'function' && getRoseLang().locale) || 'en-NG';
  rec.interimResults = false;
  rec.maxAlternatives = 1;
  if (fab) fab.classList.add('listening');
  const orb = document.getElementById('roseOrb');
  if (orb) orb.classList.add('listening');
  if (listenBtn) listenBtn.textContent = getRoseLang().listeningBtn;
  roseSetStatus(getRoseLang().listening);
  rec.onresult = (e) => {
    const text = e.results[0][0].transcript;
    roseSetStatus(getRoseLang().heard + ': “' + text + '”');
    roseHandleCommand(text);
  };
  rec.onerror = () => {
    roseSetStatus(getRoseLang().micError);
  };
  rec.onend = () => {
    if (fab) fab.classList.remove('listening');
    const orb2 = document.getElementById('roseOrb');
    if (orb2) orb2.classList.remove('listening');
    if (listenBtn) listenBtn.textContent = '🎤 ' + (getRoseLang().name || 'Rose');
  };
  try { rec.start(); } catch (e) {
    roseSetStatus(getRoseLang().micBusy);
    if (fab) fab.classList.remove('listening');
  }
}


// ===================== Rose movable FAB + type bar =====================
const ROSE_POS_KEY = 'financeManager_rosePos';

function loadRoseFabPosition() {
  const fab = document.getElementById('roseFab');
  if (!fab) return;
  try {
    const raw = localStorage.getItem(ROSE_POS_KEY);
    if (!raw) return;
    const pos = JSON.parse(raw);
    if (typeof pos.left === 'number' && typeof pos.top === 'number') {
      fab.style.left = pos.left + 'px';
      fab.style.top = pos.top + 'px';
      fab.style.right = 'auto';
      fab.style.bottom = 'auto';
    }
  } catch (e) {}
}

function saveRoseFabPosition() {
  const fab = document.getElementById('roseFab');
  if (!fab) return;
  const rect = fab.getBoundingClientRect();
  try {
    localStorage.setItem(ROSE_POS_KEY, JSON.stringify({
      left: Math.round(rect.left),
      top: Math.round(rect.top),
    }));
  } catch (e) {}
}

function clampRoseFab(left, top) {
  const fab = document.getElementById('roseFab');
  if (!fab) return { left, top };
  const w = fab.offsetWidth || 56;
  const h = fab.offsetHeight || 56;
  const maxL = Math.max(0, window.innerWidth - w - 4);
  const maxT = Math.max(0, window.innerHeight - h - 4);
  return {
    left: Math.min(maxL, Math.max(4, left)),
    top: Math.min(maxT, Math.max(4, top)),
  };
}

function positionRosePanelNearFab() {
  const fab = document.getElementById('roseFab');
  const panel = document.getElementById('rosePanel');
  if (!fab || !panel || panel.classList.contains('hidden')) return;
  const fr = fab.getBoundingClientRect();
  const panelW = panel.offsetWidth || 300;
  const panelH = panel.offsetHeight || 320;
  // Prefer above the FAB
  let left = fr.left;
  let top = fr.top - panelH - 10;
  if (top < 8) top = fr.bottom + 10;
  if (left + panelW > window.innerWidth - 8) left = window.innerWidth - panelW - 8;
  if (left < 8) left = 8;
  if (top + panelH > window.innerHeight - 8) top = Math.max(8, window.innerHeight - panelH - 8);
  panel.style.left = left + 'px';
  panel.style.top = top + 'px';
  panel.style.right = 'auto';
  panel.style.bottom = 'auto';
}

function setupRoseDrag() {
  const fab = document.getElementById('roseFab');
  if (!fab) return;
  loadRoseFabPosition();

  let dragging = false;
  let moved = false;
  let startX = 0, startY = 0, origL = 0, origT = 0;
  let pointerId = null;

  const onDown = (e) => {
    // Only primary button / touch
    if (e.type === 'mousedown' && e.button !== 0) return;
    const point = e.touches ? e.touches[0] : e;
    const rect = fab.getBoundingClientRect();
    dragging = true;
    moved = false;
    startX = point.clientX;
    startY = point.clientY;
    origL = rect.left;
    origT = rect.top;
    fab.classList.add('dragging');
    if (e.pointerId != null && fab.setPointerCapture) {
      pointerId = e.pointerId;
      try { fab.setPointerCapture(e.pointerId); } catch (err) {}
    }
  };

  const onMove = (e) => {
    if (!dragging) return;
    const point = e.touches ? e.touches[0] : e;
    const dx = point.clientX - startX;
    const dy = point.clientY - startY;
    if (Math.abs(dx) > 6 || Math.abs(dy) > 6) moved = true;
    if (!moved) return;
    e.preventDefault();
    const next = clampRoseFab(origL + dx, origT + dy);
    fab.style.left = next.left + 'px';
    fab.style.top = next.top + 'px';
    fab.style.right = 'auto';
    fab.style.bottom = 'auto';
    positionRosePanelNearFab();
  };

  const onUp = (e) => {
    if (!dragging) return;
    dragging = false;
    fab.classList.remove('dragging');
    if (pointerId != null && fab.releasePointerCapture) {
      try { fab.releasePointerCapture(pointerId); } catch (err) {}
      pointerId = null;
    }
    if (moved) {
      saveRoseFabPosition();
      // prevent click-open after drag
      fab.dataset.skipClick = '1';
      setTimeout(() => { delete fab.dataset.skipClick; }, 80);
    }
  };

  fab.addEventListener('pointerdown', onDown);
  window.addEventListener('pointermove', onMove, { passive: false });
  window.addEventListener('pointerup', onUp);
  window.addEventListener('pointercancel', onUp);
  // touch fallback
  fab.addEventListener('touchstart', onDown, { passive: true });
  window.addEventListener('touchmove', onMove, { passive: false });
  window.addEventListener('touchend', onUp);
}



function updateUserChip() {
  const chip = document.getElementById('userChip');
  if (!chip) return;
  const session = typeof getSession === 'function' ? getSession() : null;
  const name = (session && (session.name || session.email)) || 'User';
  chip.textContent = String(name).split(' ')[0].split('@')[0];
}

function setupRose() {
  if (typeof applyRoseLanguage === 'function') applyRoseLanguage();
  if (typeof setupRoseDrag === 'function') setupRoseDrag();
  const fab = document.getElementById('roseFab');
  const panel = document.getElementById('rosePanel');
  const close = document.getElementById('roseClose');
  const listenBtn = document.getElementById('roseListenBtn');
  const backdrop = document.getElementById('roseBackdrop');
  const form = document.getElementById('roseTypeForm');
  if (!fab || !panel) return;

  try {
    if (window.speechSynthesis) {
      window.speechSynthesis.getVoices();
      window.speechSynthesis.onvoiceschanged = () => window.speechSynthesis.getVoices();
    }
  } catch (e) {}

  const lockBg = (on) => {
    document.body.classList.toggle('rose-open', !!on);
    if (backdrop) {
      backdrop.classList.toggle('hidden', !on);
      backdrop.setAttribute('aria-hidden', on ? 'false' : 'true');
    }
  };

  const openPanel = () => {
    panel.classList.remove('hidden');
    lockBg(true);
    positionRosePanelNearFab();
    const R = typeof getRoseLang === 'function' ? getRoseLang() : {};
    const hi = R.hi || 'My name is Rose, how may I help you?';
    roseSetStatus(R.statusIdle || 'Tap Speak when you are ready, or type below');
    if (listenBtn) {
      listenBtn.textContent = '🎤 Speak';
      listenBtn.disabled = false;
    }
    roseSpeak(hi);
  };

  const hide = () => {
    panel.classList.add('hidden');
    lockBg(false);
    try { if (typeof roseStopAudio === 'function') roseStopAudio(); } catch (e) {}
    try { if (window.speechSynthesis) window.speechSynthesis.cancel(); } catch (e) {}
    const orb = document.getElementById('roseOrb');
    if (orb) orb.classList.remove('listening', 'speaking');
    if (fab) fab.classList.remove('listening');
  };

  fab.addEventListener('click', (e) => {
    if (fab.dataset.skipClick === '1') {
      e.preventDefault();
      e.stopPropagation();
      return;
    }
    e.preventDefault();
    e.stopPropagation();
    if (panel.classList.contains('hidden')) openPanel();
    else hide();
  });
  if (close) close.addEventListener('click', hide);
  if (backdrop) backdrop.addEventListener('click', hide);

  if (listenBtn) {
    listenBtn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      try { if (typeof roseStopAudio === 'function') roseStopAudio(); } catch (err) {}
      try { if (window.speechSynthesis) window.speechSynthesis.cancel(); } catch (err) {}
      const orb = document.getElementById('roseOrb');
      if (orb) orb.classList.remove('speaking');
      if (typeof roseStartListening === 'function') roseStartListening();
    });
  }

  if (form) {
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const input = document.getElementById('roseTypeInput');
      const val = (input && input.value || '').trim();
      if (!val) return;
      if (input) input.value = '';
      if (typeof roseHandleCommand === 'function') roseHandleCommand(val);
    });
  }

  window.addEventListener('resize', () => {
    const fabEl = document.getElementById('roseFab');
    if (!fabEl) return;
    const rect = fabEl.getBoundingClientRect();
    const next = clampRoseFab(rect.left, rect.top);
    fabEl.style.left = next.left + 'px';
    fabEl.style.top = next.top + 'px';
    fabEl.style.right = 'auto';
    fabEl.style.bottom = 'auto';
    positionRosePanelNearFab();
  });
}






// ===================== Init =====================
load();
// Always open the app on the real current month
state.currentMonth = getMonthKey(new Date());
save();
initAuthGate();
setupEventListeners();
if (typeof bindSettingsBtn === "function") bindSettingsBtn();
if (typeof setupRose === "function") setupRose();
if (typeof setupSearchAndExtras === "function") setupSearchAndExtras();
if (typeof applyAppTagline === 'function') applyAppTagline();
setupCsvExport();
setupTxEditor();
setupSalaryPlanModal();
setupDebtRecurringCompare();
setupSupportUI();
setupPersonalization();
setupDashboardNav();
setupSwipeNavigation();
showOnboardingIfNeeded();
const today = new Date().toISOString().slice(0, 10);
syncFormDatesToViewedMonth();
render();

function bindSettingsBtn() {
  const settingsBtn = document.getElementById('settingsBtn');
  if (settingsBtn) {
    settingsBtn.addEventListener('click', () => {
      if (typeof setDashboardView === 'function') setDashboardView('settings');
    });
  }
}
