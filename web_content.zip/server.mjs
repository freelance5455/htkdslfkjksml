import { createServer } from 'node:http';
import { readFile, stat } from 'node:fs/promises';
import { join, extname, normalize } from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = fileURLToPath(new URL('.', import.meta.url));
const PUBLIC = join(ROOT, 'public');
const PORT = Number(process.env.PORT || 3001);

const cityMeta = {
  Lisboa: { x: 29, y: 65, region: 'Área Metropolitana' },
  Porto: { x: 23, y: 22, region: 'Norte' },
  Braga: { x: 27, y: 12, region: 'Norte' },
  Coimbra: { x: 34, y: 42, region: 'Centro' },
  Faro: { x: 46, y: 91, region: 'Algarve' },
  Aveiro: { x: 29, y: 32, region: 'Centro' },
};

const demoWishes = [
  { id: 'w-001', item: 'Farinha de mandioca torrada', category: 'Mercado brasileiro', city: 'Lisboa', zone: 'Alameda / Arroios', place: 'Casa do Brasil Market', placeType: 'mercado', status: 'disponível', price: '€ 3,49', note: 'Corredor de produtos secos', updatedAt: 'agora', source: 'comunidade', tags: ['mandioca', 'farinha'] },
  { id: 'w-002', item: 'Guaraná Antarctica', category: 'Bebidas', city: 'Porto', zone: 'Bonfim', place: 'Sabores do Brasil', placeType: 'mercado', status: 'disponível', price: '€ 2,19', note: 'Latas e garrafas geladas', updatedAt: 'agora', source: 'comunidade', tags: ['guaraná'] },
  { id: 'w-003', item: 'Açaí sem açúcar', category: 'Alimentação', city: 'Lisboa', zone: 'Alcântara', place: 'Açaí da Vila', placeType: 'café', status: 'confirmar hoje', price: '€ 8,90', note: 'Porção de 500 ml', updatedAt: 'há 4 min', source: 'comunidade', tags: ['açaí', 'gelado'] },
  { id: 'w-004', item: 'Cabeleireiro para cabelo crespo', category: 'Serviços', city: 'Braga', zone: 'São Victor', place: 'Tranças & Raízes', placeType: 'serviço', status: 'agenda aberta', price: 'desde € 25', note: 'Atendimento com hora marcada', updatedAt: 'há 11 min', source: 'comunidade', tags: ['cabelo', 'tranças'] },
  { id: 'w-005', item: 'Bolo de rolo', category: 'Mercado brasileiro', city: 'Coimbra', zone: 'Baixa', place: 'Mercearia Tropical', placeType: 'mercado', status: 'últimas unidades', price: '€ 6,90', note: 'Produção artesanal', updatedAt: 'há 18 min', source: 'comunidade', tags: ['bolo', 'pernambuco'] },
  { id: 'w-006', item: 'Feijão preto', category: 'Mercado brasileiro', city: 'Faro', zone: 'São Pedro', place: 'Sabores Lusófonos', placeType: 'mercado', status: 'disponível', price: '€ 2,79', note: 'Pacotes de 1 kg', updatedAt: 'há 23 min', source: 'comunidade', tags: ['feijão'] },
  { id: 'w-007', item: 'Aula de forró', category: 'Comunidade', city: 'Aveiro', zone: 'Glória e Vera Cruz', place: 'Casa da Roda', placeType: 'comunidade', status: 'novas vagas', price: '€ 7 / aula', note: 'Turmas para iniciantes', updatedAt: 'há 27 min', source: 'comunidade', tags: ['forró', 'dança'] },
  { id: 'w-008', item: 'Pão de queijo congelado', category: 'Mercado brasileiro', city: 'Lisboa', zone: 'Benfica', place: 'Mercado Mineiro', placeType: 'mercado', status: 'disponível', price: '€ 5,40', note: 'Pacotes de 400 g', updatedAt: 'há 31 min', source: 'comunidade', tags: ['pão de queijo'] },
  { id: 'w-009', item: 'Dentista que atende em português', category: 'Serviços', city: 'Porto', zone: 'Cedofeita', place: 'Clínica Ponte', placeType: 'serviço', status: 'aceita marcações', price: 'consulta € 35', note: 'Primeira conversa em português', updatedAt: 'há 42 min', source: 'comunidade', tags: ['dentista', 'saúde'] },
  { id: 'w-010', item: 'Cachaça artesanal', category: 'Bebidas', city: 'Lisboa', zone: 'Campo de Ourique', place: 'Boteco Atlântico', placeType: 'bar', status: 'disponível', price: '€ 18,00', note: 'Rótulos de Minas e Bahia', updatedAt: 'há 48 min', source: 'comunidade', tags: ['cachaça'] },
];

const liveTemplates = [
  { item: 'Polvilho azedo', category: 'Mercado brasileiro', city: 'Porto', zone: 'Paranhos', place: 'Armazém do Pão de Queijo', placeType: 'mercado', status: 'confirmar hoje', price: '€ 3,80', note: 'Novo sinal da comunidade', tags: ['polvilho', 'pão de queijo'] },
  { item: 'Aula de capoeira', category: 'Comunidade', city: 'Lisboa', zone: 'Marvila', place: 'Roda do Tejo', placeType: 'comunidade', status: 'novas vagas', price: '€ 10 / aula', note: 'Turma aberta esta semana', tags: ['capoeira'] },
  { item: 'Leite condensado brasileiro', category: 'Mercado brasileiro', city: 'Faro', zone: 'Sé', place: 'Ponto Tropical', placeType: 'mercado', status: 'disponível', price: '€ 2,60', note: 'Reposição confirmada', tags: ['doce', 'leite condensado'] },
];

let wishes = [...demoWishes];
let nextId = 11;
const clients = new Set();

function json(res, status, payload) {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'Access-Control-Allow-Origin': '*' });
  res.end(JSON.stringify(payload));
}

function cityFor(wish) {
  return { ...(cityMeta[wish.city] || cityMeta.Lisboa), name: wish.city };
}

function decorate(wish) {
  return { ...wish, coordinates: cityFor(wish) };
}

function filtered(url) {
  const q = (url.searchParams.get('q') || '').trim().toLowerCase();
  const category = url.searchParams.get('category') || 'Todos';
  const city = url.searchParams.get('city') || 'Portugal inteiro';
  return wishes
    .filter((wish) => !q || [wish.item, wish.place, wish.zone, wish.category, ...wish.tags].join(' ').toLowerCase().includes(q))
    .filter((wish) => category === 'Todos' || wish.category === category)
    .filter((wish) => city === 'Portugal inteiro' || wish.city === city)
    .map(decorate);
}

function summary() {
  const available = wishes.filter((wish) => ['disponível', 'últimas unidades'].includes(wish.status)).length;
  const cities = new Set(wishes.map((wish) => wish.city)).size;
  return { wishes: wishes.length, available, cities, people: 284, liveSince: '09:00', categories: [...new Set(wishes.map((wish) => wish.category))] };
}

function broadcast(event, data) {
  const payload = `event: ${event}\ndata: ${JSON.stringify(data)}\n\n`;
  for (const client of clients) client.write(payload);
}

function addWish(input, isLive = false) {
  const wish = {
    id: `w-${String(nextId++).padStart(3, '0')}`,
    item: input.item,
    category: input.category,
    city: input.city,
    zone: input.zone,
    place: input.place || 'A descobrir pela comunidade',
    placeType: input.place ? 'mercado' : 'comunidade',
    status: input.status || 'buscando pistas',
    price: input.price || 'informar preço',
    note: input.note || 'Desejo recebido com consentimento',
    updatedAt: isLive ? 'agora' : 'agora',
    source: isLive ? 'sinal ao vivo' : 'novo desejo',
    tags: [input.item.toLowerCase()],
  };
  wishes.unshift(wish);
  broadcast(isLive ? 'wish:live' : 'wish:new', decorate(wish));
  broadcast('summary', summary());
  return wish;
}

function parseBody(req) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', (chunk) => { body += chunk; if (body.length > 100_000) req.destroy(); });
    req.on('end', () => { try { resolve(JSON.parse(body || '{}')); } catch (error) { reject(error); } });
    req.on('error', reject);
  });
}

function validNewWish(input) {
  return input && typeof input.item === 'string' && input.item.trim().length >= 2
    && typeof input.category === 'string' && cityMeta[input.city]
    && typeof input.zone === 'string' && input.zone.trim().length >= 2
    && input.consent === true;
}

async function serveStatic(req, res, pathname) {
  const requested = pathname === '/' ? '/index.html' : pathname;
  const file = normalize(join(PUBLIC, requested));
  if (!file.startsWith(PUBLIC)) return json(res, 403, { error: 'Acesso negado' });
  try {
    const info = await stat(file);
    if (!info.isFile()) return json(res, 404, { error: 'Não encontrado' });
    const body = await readFile(file);
    const mime = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.json': 'application/json; charset=utf-8', '.svg': 'image/svg+xml' }[extname(file)] || 'application/octet-stream';
    res.writeHead(200, { 'Content-Type': mime, 'Cache-Control': 'no-store' });
    res.end(body);
  } catch {
    json(res, 404, { error: 'Não encontrado' });
  }
}

const server = createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  if (req.method === 'OPTIONS') {
    res.writeHead(204, { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'Content-Type', 'Access-Control-Allow-Methods': 'GET,POST,OPTIONS' });
    return res.end();
  }
  if (url.pathname === '/api/summary' && req.method === 'GET') return json(res, 200, summary());
  if (url.pathname === '/api/wishes' && req.method === 'GET') return json(res, 200, { items: filtered(url), total: wishes.length, updatedAt: new Date().toISOString() });
  if (url.pathname === '/api/events' && req.method === 'GET') {
    res.writeHead(200, { 'Content-Type': 'text/event-stream; charset=utf-8', 'Cache-Control': 'no-cache, no-store', Connection: 'keep-alive', 'Access-Control-Allow-Origin': '*' });
    res.write(`event: connected\ndata: ${JSON.stringify({ at: new Date().toISOString() })}\n\n`);
    clients.add(res);
    req.on('close', () => clients.delete(res));
    return;
  }
  if (url.pathname === '/api/wishes' && req.method === 'POST') {
    try {
      const input = await parseBody(req);
      if (!validNewWish(input)) return json(res, 400, { error: 'Preencha item, categoria, cidade, zona aproximada e consentimento.' });
      return json(res, 201, { item: decorate(addWish(input)) });
    } catch {
      return json(res, 400, { error: 'Não foi possível ler o desejo.' });
    }
  }
  if (url.pathname === '/api/health') return json(res, 200, { ok: true, realtime: true, clients: clients.size });
  return serveStatic(req, res, url.pathname);
});

setInterval(() => {
  if (!clients.size) return;
  const template = liveTemplates[Math.floor(Math.random() * liveTemplates.length)];
  addWish(template, true);
}, 18000).unref();

server.listen(PORT, '0.0.0.0', () => {
  console.log(`Desejos PT ouvindo em http://0.0.0.0:${PORT}`);
});
