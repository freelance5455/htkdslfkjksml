import http from "node:http";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
const root=path.dirname(fileURLToPath(import.meta.url));
const port=process.env.PORT||3000;
const types={".html":"text/html; charset=utf-8",".js":"text/javascript; charset=utf-8",".css":"text/css; charset=utf-8",".json":"application/json; charset=utf-8",".webmanifest":"application/manifest+json",".svg":"image/svg+xml",".png":"image/png"};
http.createServer((req,res)=>{
  const u=new URL(req.url,"http://localhost");
  if(u.pathname==="/api/health"){res.writeHead(200,{"Content-Type":"application/json"});return res.end(JSON.stringify({ok:true,name:"BFF",time:new Date().toISOString()}));}
  let p=path.normalize(path.join(root,u.pathname==="/"?"/index.html":u.pathname));
  if(u.pathname==="/") p=path.join(root,"index.html");
  if(!p.startsWith(root)){res.writeHead(403);return res.end("Forbidden");}
  fs.stat(p,(e,st)=>{
    if(e||!st.isFile()){p=path.join(root,"index.html");}
    fs.readFile(p,(err,data)=>{if(err){res.writeHead(404);return res.end("Not found");}res.writeHead(200,{"Content-Type":types[path.extname(p)]||"application/octet-stream","Cache-Control":"no-cache"});res.end(data);});
  });
}).listen(port,()=>console.log(`BFF online: http://localhost:${port}`));
