import express from 'express';
import mysql from 'mysql2/promise';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = Number(process.env.PORT || 3000);
const isMigrateOnly = process.argv.includes('--migrate-only');
const appState = { database: 'not-configured', lastError: null };
let pool = null;
let schemaPromise = null;

app.disable('x-powered-by');
app.use(express.json({ limit: '12mb' }));

const now = () => Date.now();
const json = value => JSON.stringify(value ?? null);
const parse = value => {
  if (value == null) return null;
  if (typeof value === 'object') return value;
  try { return JSON.parse(value); } catch { return null; }
};
const stableId = (prefix, value) => prefix + '_' + crypto.createHash('sha256').update(json(value)).digest('hex').slice(0, 40);
const safeUserKey = value => String(value || '').trim().toLowerCase().slice(0, 191);

function getPool() {
  if (pool || !process.env.DATABASE_URL) return pool;
  pool = mysql.createPool({
    uri: process.env.DATABASE_URL,
    waitForConnections: true,
    connectionLimit: 5,
    maxIdle: 5,
    idleTimeout: 60000,
    enableKeepAlive: true,
    ssl: process.env.DATABASE_SSL === 'false' ? undefined : { rejectUnauthorized: false }
  });
  return pool;
}

async function ensureSchema() {
  if (schemaPromise) return schemaPromise;
  schemaPromise = (async () => {
    const db = getPool();
    if (!db) {
      appState.database = 'not-configured';
      return false;
    }
    try {
      const sql = fs.readFileSync(path.join(__dirname, 'schema.sql'), 'utf8');
      for (const statement of sql.split(';').map(x => x.trim()).filter(Boolean)) await db.query(statement);
      appState.database = 'ready';
      appState.lastError = null;
      return true;
    } catch (error) {
      appState.database = 'error';
      appState.lastError = error.message;
      console.error('[database] migration failed:', error.message);
      return false;
    }
  })();
  return schemaPromise;
}

function cleanSettings(settings) {
  const value = settings && typeof settings === 'object' ? { ...settings } : {};
  delete value.apiKey;
  value.baseUrl = '/api/ai';
  if (!value.model || value.model === 'glm-5.3') value.model = process.env.XERXES_AI_MODEL || 'gpt-5-mini';
  return value;
}

async function readSnapshot() {
  const empty = { users: {}, roles: {}, logs: [], resets: {}, appeals: [], communityMessages: [], signals: {}, settings: {} };
  const db = getPool();
  if (!db || !(await ensureSchema())) return empty;
  const [users, roles, logs, resets, appeals, messages, signals, settings] = await Promise.all([
    db.query('SELECT username, data FROM app_users'),
    db.query('SELECT role_name, data FROM app_roles'),
    db.query('SELECT data FROM app_logs ORDER BY event_time DESC LIMIT 2000'),
    db.query('SELECT username, reset_at FROM app_resets'),
    db.query('SELECT data FROM app_appeals ORDER BY updated_at DESC LIMIT 2000'),
    db.query('SELECT data FROM app_messages ORDER BY created_at DESC LIMIT 2000'),
    db.query('SELECT username, signal_id, data FROM app_signals ORDER BY updated_at DESC LIMIT 2000'),
    db.query("SELECT data FROM app_settings WHERE setting_key = 'global' LIMIT 1")
  ]);
  for (const row of users[0]) empty.users[row.username] = parse(row.data);
  for (const row of roles[0]) empty.roles[row.role_name] = parse(row.data);
  empty.logs = logs[0].map(row => parse(row.data)).filter(Boolean).reverse();
  for (const row of resets[0]) empty.resets[row.username] = Number(row.reset_at);
  empty.appeals = appeals[0].map(row => parse(row.data)).filter(Boolean).reverse();
  empty.communityMessages = messages[0].map(row => parse(row.data)).filter(Boolean).reverse();
  for (const row of signals[0]) {
    if (!empty.signals[row.username]) empty.signals[row.username] = [];
    empty.signals[row.username].push(parse(row.data));
  }
  empty.settings = cleanSettings(parse(settings[0][0]?.data) || {});
  return empty;
}

async function mergeSnapshot(input) {
  const incoming = input && typeof input === 'object' ? input : {};
  const db = getPool();
  if (!db || !(await ensureSchema())) return readSnapshot();
  const connection = await db.getConnection();
  const stamp = now();
  try {
    await connection.beginTransaction();
    for (const [key, value] of Object.entries(incoming.users || {})) {
      const username = safeUserKey(key || value?.username);
      if (!username || !value) continue;
      await connection.query('INSERT INTO app_users(username,data,updated_at) VALUES(?,?,?) ON DUPLICATE KEY UPDATE data=VALUES(data), updated_at=VALUES(updated_at)', [username, json(value), stamp]);
    }
    for (const [key, value] of Object.entries(incoming.roles || {})) {
      if (!key || !value) continue;
      await connection.query('INSERT INTO app_roles(role_name,data,updated_at) VALUES(?,?,?) ON DUPLICATE KEY UPDATE data=VALUES(data), updated_at=VALUES(updated_at)', [String(key).slice(0, 191), json(value), stamp]);
    }
    for (const value of Array.isArray(incoming.logs) ? incoming.logs.slice(-2000) : []) {
      if (!value) continue;
      const id = value.id || stableId('log', value);
      await connection.query('INSERT IGNORE INTO app_logs(log_id,username,data,event_time,updated_at) VALUES(?,?,?,?,?)', [id, safeUserKey(value.user), json(value), Number(value.time || stamp), stamp]);
    }
    for (const [key, value] of Object.entries(incoming.resets || {})) {
      const username = safeUserKey(key);
      if (!username) continue;
      await connection.query('INSERT INTO app_resets(username,reset_at,updated_at) VALUES(?,?,?) ON DUPLICATE KEY UPDATE reset_at=VALUES(reset_at), updated_at=VALUES(updated_at)', [username, Number(value) || stamp, stamp]);
    }
    for (const value of Array.isArray(incoming.appeals) ? incoming.appeals.slice(-2000) : []) {
      if (!value) continue;
      const id = String(value.id || stableId('appeal', value)).slice(0, 191);
      await connection.query('INSERT INTO app_appeals(appeal_id,username,data,updated_at) VALUES(?,?,?,?) ON DUPLICATE KEY UPDATE data=VALUES(data), updated_at=VALUES(updated_at)', [id, safeUserKey(value.user || value.username), json(value), stamp]);
    }
    for (const value of Array.isArray(incoming.communityMessages) ? incoming.communityMessages.slice(-2000) : []) {
      if (!value) continue;
      const id = String(value.id || stableId('message', value)).slice(0, 191);
      await connection.query('INSERT INTO app_messages(message_id,room_name,sender,data,created_at,updated_at) VALUES(?,?,?,?,?,?) ON DUPLICATE KEY UPDATE data=VALUES(data), updated_at=VALUES(updated_at)', [id, String(value.room || 'global').slice(0, 191), safeUserKey(value.sender), json(value), Number(value.created || stamp), stamp]);
    }
    for (const [usernameKey, values] of Object.entries(incoming.signals || {})) {
      const username = safeUserKey(usernameKey);
      for (const value of Array.isArray(values) ? values.slice(-500) : []) {
        if (!value) continue;
        const id = String(value.id || stableId('signal', value)).slice(0, 191);
        await connection.query('INSERT INTO app_signals(username,signal_id,data,updated_at) VALUES(?,?,?,?) ON DUPLICATE KEY UPDATE data=VALUES(data), updated_at=VALUES(updated_at)', [username, id, json(value), stamp]);
      }
    }
    if (incoming.settings && typeof incoming.settings === 'object') {
      await connection.query("INSERT INTO app_settings(setting_key,data,updated_at) VALUES('global',?,?) ON DUPLICATE KEY UPDATE data=VALUES(data), updated_at=VALUES(updated_at)", [json(cleanSettings(incoming.settings)), stamp]);
    }
    await connection.commit();
  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    connection.release();
  }
  return readSnapshot();
}

function upstreamConfig() {
  const customKey = process.env.XERXES_AI_API_KEY;
  const customBase = process.env.XERXES_AI_BASE_URL;
  if (customKey && customBase) return { base: customBase.replace(/\/$/, ''), key: customKey, model: process.env.XERXES_AI_MODEL || 'glm-5.3' };
  return { base: (process.env.BUILT_IN_FORGE_API_URL || process.env.MANUS_API_URL || '').replace(/\/$/, '') + (process.env.BUILT_IN_FORGE_API_URL ? '/v1' : '/v1'), key: process.env.BUILT_IN_FORGE_API_KEY || process.env.MANUS_API_KEY || '', model: process.env.XERXES_AI_MODEL || 'gpt-5-mini' };
}

async function proxyAI(req, res) {
  const cfg = upstreamConfig();
  if (!cfg.base || !cfg.key) return res.status(503).json({ error: { message: 'Layanan AI server belum tersedia.' } });
  const body = { ...(req.body || {}) };
  body.model = cfg.model;
  if (!Array.isArray(body.messages) || !body.messages.length) return res.status(400).json({ error: { message: 'messages wajib diisi.' } });
  try {
    const upstream = await fetch(cfg.base + '/chat/completions', { method: 'POST', headers: { 'content-type': 'application/json', authorization: `Bearer ${cfg.key}` }, body: JSON.stringify(body) });
    const text = await upstream.text();
    res.status(upstream.status).type('application/json').send(text || JSON.stringify({ error: { message: 'Respons AI kosong.' } }));
  } catch (error) {
    res.status(502).json({ error: { message: 'Proxy AI gagal terhubung ke provider.', detail: error.message } });
  }
}

const allowedMarketHosts = new Set(['api.binance.com', 'www.okx.com', 'api.bybit.com', 'query1.finance.yahoo.com', 'api.twelvedata.com']);
app.get('/api/health', async (_req, res) => { await ensureSchema(); res.status(200).json({ ok: true, service: 'xerxes-ai', database: appState.database, time: new Date().toISOString() }); });
app.get('/api/sync', async (_req, res) => { try { res.json({ ok: true, data: await readSnapshot() }); } catch (error) { res.status(500).json({ ok: false, error: 'sync_read_failed' }); } });
app.post('/api/sync', async (req, res) => { try { res.json({ ok: true, data: await mergeSnapshot(req.body) }); } catch (error) { console.error('[sync]', error.message); res.status(500).json({ ok: false, error: 'sync_write_failed' }); } });
app.post('/api/ai/chat/completions', proxyAI);
app.post('/api/ai/v1/chat/completions', proxyAI);
app.get('/api/public/market', async (req, res) => {
  try {
    const target = new URL(String(req.query.url || ''));
    if (target.protocol !== 'https:' || !allowedMarketHosts.has(target.hostname)) return res.status(400).json({ error: 'market_host_not_allowed' });
    const upstream = await fetch(target, { headers: { accept: 'application/json' } });
    res.status(upstream.status).type(upstream.headers.get('content-type') || 'application/json').send(await upstream.text());
  } catch { res.status(400).json({ error: 'invalid_market_url' }); }
});

app.use(express.static(path.join(__dirname, 'public'), { extensions: ['html'] }));
app.get('*', (_req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));

async function main() {
  await ensureSchema();
  if (isMigrateOnly) { if (appState.database === 'error') process.exitCode = 1; return; }
  app.listen(PORT, '0.0.0.0', () => console.log(`[xerxes-ai] listening on ${PORT}; database=${appState.database}`));
}
main().catch(error => { console.error(error); process.exitCode = 1; });
