import express from "express";
import OpenAI from "openai";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
app.use(express.json({limit:"1mb"}));
app.use(express.static(__dirname));

const PORT = process.env.PORT || 3000;
const MODEL = process.env.OPENAI_MODEL || "gpt-5.6-luna";
const client = process.env.OPENAI_API_KEY ? new OpenAI({apiKey:process.env.OPENAI_API_KEY}) : null;

app.get("/api/health", (_req,res)=>res.json({
  ok:true,
  configured:Boolean(client),
  model:MODEL
}));

app.post("/api/chat", async (req,res)=>{
  if(!client) return res.status(503).json({error:"OPENAI_API_KEY não configurada no servidor."});
  const message=String(req.body?.message||"").trim();
  if(!message) return res.status(400).json({error:"Mensagem vazia."});
  const history=Array.isArray(req.body?.history)?req.body.history.slice(-12):[];
  const input=history.map(m=>({role:m.role==="user"?"user":"assistant",content:String(m.text||"")})).filter(m=>m.content);
  if(!input.length || input.at(-1)?.content!==message) input.push({role:"user",content:message});
  try{
    const response=await client.responses.create({
      model:MODEL,
      instructions:"Você é o Nexo IA, assistente em português do Brasil. Seja útil, claro, objetivo e seguro. Ajude o usuário a encontrar soluções e organizar tarefas. Não invente fatos.",
      input
    });
    res.json({reply:response.output_text||"Não consegui gerar uma resposta."});
  }catch(err){
    console.error(err);
    res.status(500).json({error:err?.message||"Erro ao consultar a IA."});
  }
});

app.listen(PORT,()=>console.log(`Nexo rodando em http://localhost:${PORT}`));
