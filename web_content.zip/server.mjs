import express from 'express';
import 'dotenv/config';
import { GoogleGenAI } from '@google/genai';

const app = express();
const port = 3001;

if (!process.env.GEMINI_API_KEY) {
  console.error('GEMINI_API_KEY is missing from .env');
  process.exit(1);
}

const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: { apiVersion: 'v1alpha' }
});

app.get('/api/health', (_req, res) => {
  res.json({ ok: true, service: 'Hayat AI backend' });
});

app.post('/api/token', async (_req, res) => {
  try {
    const token = await ai.authTokens.create({
      config: {
        uses: 1,
        expireTime: new Date(Date.now() + 30 * 60 * 1000).toISOString(),
        newSessionExpireTime: new Date(Date.now() + 60 * 1000).toISOString(),
        liveConnectConstraints: {
          model: 'gemini-3.8-live',
          config: {
            responseModalities: ['AUDIO'],
            sessionResumption: {},
            systemInstruction: {
              parts: [{
                text: 'You are Hayat, a friendly personal AI assistant. Speak naturally and concisely.'
              }]
            }
          }
        }
      }
    });

    res.json({ token: token.name });
  } catch (error) {
    console.error('Gemini token error:', error.message);
    res.status(500).json({ error: 'Token creation failed. Check your API key and Gemini API access.' });
  }
});

app.listen(port, '127.0.0.1', () => {
  console.log(`Hayat backend ready at http://127.0.0.1:${port}`);
});
