"use strict";

const DB_KEY = "blue_memo_data_v2";
const SETTINGS_KEY = "blue_memo_settings_v2";

let notes = [];
let folders = [];
let currentNoteId = null;
let editorIsNew = false;
let saveTimer = null;
let toastTimer = null;

const $ = id => document.getElementById(id);

function uid() {
  return Date.now().toString(36) +
    Math.random().toString(36).slice(2, 9);
}

function loadData() {
  try {
    const data = JSON.parse(localStorage.getItem(DB_KEY) || "{}");
    notes = Array.isArray(data.notes) ? data.notes : [];
    folders = Array.isArray(data.folders) ? data.folders : [];
  } catch (e) {
    notes = [];
    folders = [];
  }

  try {
    const settings = JSON.parse(
      localStorage.getItem(SETTINGS_KEY) || "{}"
    );

    $("compactMode").checked = !!settings.compact;
    $("reduceMotion").checked = !!settings.reduceMotion;
  } catch (e) {}

  applySettings();
}

function saveData() {
  try {
    localStorage.setItem(DB_KEY, JSON.stringify({ notes, folders }));
    return true;
  } catch (e) {
    showToast("Stockage indisponible ou plein. Exportez vos données.");
    return false;
  }
}

function showToast(message) {
  const toast = $("toast");
  toast.textContent = message;
  toast.classList.add("show");

  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => {
    toast.classList.remove("show");
  }, 2500);
}

function showPage(pageId) {
  if (currentNoteId && $("editor").classList.contains("active")) {
    flushEditor();
  }

  document.querySelectorAll(".page").forEach(page => {
    page.classList.remove("active");
  });

  const page = $(pageId);
  if (!page) return;

  page.classList.add("active");

  document.querySelectorAll(".nav-item").forEach(button => {
    button.classList.toggle(
      "active",
      button.dataset.page === pageId
    );
  });

  if (pageId !== "editor") {
    currentNoteId = null;
    editorIsNew = false;
  }

  renderAll();
  window.scrollTo(0, 0);
}

function noteDefaults() {
  const now = new Date().toISOString();

  return {
    id: uid(),
    title: "",
    content: "",
    category: "Personnel",
    folderId: "",
    favorite: false,
    archived: false,
    deleted: false,
    createdAt: now,
    updatedAt: now
  };
}

function newNote() {
  const note = noteDefaults();
  notes.unshift(note);

  currentNoteId = note.id;
  editorIsNew = true;

  saveData();
  openEditor(note);
}

function openEditor(note) {
  currentNoteId = note.id;
  editorIsNew = false;

  $("noteTitle").value = note.title || "";
  $("noteContent").value = note.content || "";
  $("noteCategory").value = note.category || "Personnel";

  updateFolderSelect(note.folderId || "");
  updateFavoriteButton();
  updateWordCount();

  $("saveStatus").textContent = "Enregistré";

  document.querySelectorAll(".page").forEach(page => {
    page.classList.remove("active");
  });

  $("editor").classList.add("active");

  document.querySelectorAll(".nav-item").forEach(button => {
    button.classList.remove("active");
  });

  window.scrollTo(0, 0);
}

function cancelEditor() {
  flushEditor();

  const note = notes.find(n => n.id === currentNoteId);

  if (
    note &&
    editorIsNew &&
    !note.title.trim() &&
    !note.content.trim()
  ) {
    notes = notes.filter(n => n.id !== note.id);
    saveData();
  }

  currentNoteId = null;
  editorIsNew = false;
  showPage("notes");
}

function flushEditor() {
  clearTimeout(saveTimer);

  if (!currentNoteId) return;

  const note = notes.find(n => n.id === currentNoteId);
  if (!note) return;

  note.title = $("noteTitle").value.trim();
  note.content = $("noteContent").value;
  note.category = $("noteCategory").value;
  note.folderId = $("noteFolder").value;
  note.updatedAt = new Date().toISOString();

  saveData();
  $("saveStatus").textContent = "Enregistré";
  updateWordCount();
}

function scheduleSave() {
  if (!currentNoteId) return;

  $("saveStatus").textContent = "Enregistrement...";

  clearTimeout(saveTimer);

  saveTimer = setTimeout(() => {
    flushEditor();
    renderAll();
  }, 400);
}

function updateWordCount() {
  const text = $("noteContent").value.trim();
  const count = text ? text.split(/\s+/).length : 0;

  $("wordCount").textContent =
    count + (count > 1 ? " mots" : " mot");
}

function updateFavoriteButton() {
  const note = notes.find(n => n.id === currentNoteId);
  const button = $("favoriteBtn");

  if (!note) return;

  button.innerHTML = note.favorite
    ? '<img src="icons/star.png" alt=""> Retirer des favoris'
    : '<img src="icons/star.png" alt=""> Ajouter aux favoris';

  button.classList.toggle("is-favorite", note.favorite);
}

function toggleFavorite() {
  const note = notes.find(n => n.id === currentNoteId);
  if (!note) return;

  note.favorite = !note.favorite;
  note.updatedAt = new Date().toISOString();

  saveData();
  updateFavoriteButton();
  renderAll();

  showToast(
    note.favorite
      ? "Ajoutée aux favoris"
      : "Retirée des favoris"
  );
}

function insertChecklist() {
  const area = $("noteContent");
  const start = area.selectionStart;
  const end = area.selectionEnd;
  const selected = area.value.slice(start, end);

  const replacement = selected
    ? selected.split("\n").map(line => "☐ " + line).join("\n")
    : "☐ Tâche 1\n☐ Tâche 2\n☐ Tâche 3";

  area.setRangeText(replacement, start, end, "end");
  area.focus();

  updateWordCount();
  scheduleSave();
}

function duplicateCurrent() {
  flushEditor();

  const note = notes.find(n => n.id === currentNoteId);
  if (!note) return;

  const copy = {
    ...note,
    id: uid(),
    title: (note.title || "Sans titre") + " (copie)",
    favorite: false,
    archived: false,
    deleted: false,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };

  notes.unshift(copy);
  saveData();
  openEditor(copy);
  showToast("Note dupliquée");
}

function deleteCurrent() {
  flushEditor();

  const note = notes.find(n => n.id === currentNoteId);
  if (!note) return;

  note.deleted = true;
  note.archived = false;
  note.deletedAt = new Date().toISOString();

  saveData();

  currentNoteId = null;
  editorIsNew = false;

  showPage("notes");
  showToast("Note déplacée dans la corbeille");
}

function archiveCurrent() {
  const note = notes.find(n => n.id === currentNoteId);
  if (!note) return;

  flushEditor();

  note.archived = true;
  note.updatedAt = new Date().toISOString();

  saveData();

  currentNoteId = null;
  editorIsNew = false;

  showPage("notes");
  showToast("Note archivée");
}

function archiveNote(id) {
  const note = notes.find(n => n.id === id);
  if (!note) return;

  note.archived = !note.archived;
  note.updatedAt = new Date().toISOString();

  saveData();
  renderAll();

  showToast(note.archived ? "Note archivée" : "Note désarchivée");
}

function restoreNote(id) {
  const note = notes.find(n => n.id === id);
  if (!note) return;

  note.deleted = false;
  note.archived = false;
  delete note.deletedAt;
  note.updatedAt = new Date().toISOString();

  saveData();
  renderAll();
  showToast("Note restaurée");
}

function permanentlyDelete(id) {
  if (!confirm("Supprimer définitivement cette note ?")) return;

  notes = notes.filter(n => n.id !== id);
  saveData();
  renderAll();

  showToast("Note supprimée définitivement");
}

function emptyTrash() {
  if (!notes.some(n => n.deleted)) {
    showToast("La corbeille est vide");
    return;
  }

  if (!confirm("Supprimer définitivement toutes les notes supprimées ?")) {
    return;
  }

  notes = notes.filter(n => !n.deleted);
  saveData();
  renderAll();

  showToast("Corbeille vidée");
}

function quickFavorite(id) {
  const note = notes.find(n => n.id === id);
  if (!note) return;

  note.favorite = !note.favorite;
  note.updatedAt = new Date().toISOString();

  saveData();
  renderAll();

  showToast(note.favorite ? "Ajoutée aux favoris" : "Retirée des favoris");
}

function addFolder() {
  const input = $("folderName");
  const name = input.value.trim();

  if (!name) {
    showToast("Entrez un nom de dossier");
    return;
  }

  if (folders.some(f => f.name.toLowerCase() === name.toLowerCase())) {
    showToast("Ce dossier existe déjà");
    return;
  }

  folders.push({ id: uid(), name });
  input.value = "";

  saveData();
  renderAll();
  showToast("Dossier créé");
}

function renameFolder(id) {
  const folder = folders.find(f => f.id === id);
  if (!folder) return;

  const name = prompt("Nouveau nom :", folder.name);
  if (name === null) return;

  const clean = name.trim();
  if (!clean) return showToast("Nom invalide");

  if (folders.some(f =>
    f.id !== id && f.name.toLowerCase() === clean.toLowerCase()
  )) {
    return showToast("Ce dossier existe déjà");
  }

  folder.name = clean;
  saveData();
  renderAll();
}

function deleteFolder(id) {
  const folder = folders.find(f => f.id === id);
  if (!folder) return;

  if (!confirm("Supprimer ce dossier ? Les notes seront conservées.")) {
    return;
  }

  notes.forEach(note => {
    if (note.folderId === id) note.folderId = "";
  });

  folders = folders.filter(f => f.id !== id);

  saveData();
  renderAll();
  showToast("Dossier supprimé");
}

function updateFolderSelect(selectedId) {
  const select = $("noteFolder");
  select.innerHTML = '<option value="">Sans dossier</option>';

  folders.forEach(folder => {
    const option = document.createElement("option");
    option.value = folder.id;
    option.textContent = folder.name;
    select.appendChild(option);
  });

  select.value = selectedId;
}

function folderName(id) {
  const folder = folders.find(f => f.id === id);
  return folder ? folder.name : "";
}

function formatDate(value) {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "";

  return date.toLocaleDateString("fr-FR", {
    day: "2-digit",
    month: "short",
    year: "numeric"
  });
}

function escapeHTML(value) {
  return String(value).replace(/[&<>"']/g, char => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  })[char]);
}

function cardHTML(note, mode = "normal") {
  const title = escapeHTML(note.title || "Sans titre");
  const content = escapeHTML(
    note.content || "Aucun contenu pour le moment."
  );

  const folder = folderName(note.folderId);
  let actions = "";

  if (mode === "trash") {
    actions = `
      <button class="mini-btn" onclick="event.stopPropagation();restoreNote('${note.id}')">
        <img src="icons/arrow-left.png" alt="">
      </button>
      <button class="mini-btn" onclick="event.stopPropagation();permanentlyDelete('${note.id}')">
        <img src="icons/x.png" alt="">
      </button>`;
  } else if (mode === "archive") {
    actions = `
      <button class="mini-btn" onclick="event.stopPropagation();archiveNote('${note.id}')">
        <img src="icons/arrow-left.png" alt="">
      </button>`;
  } else {
    actions = `
      <button class="mini-btn ${note.favorite ? "favorite" : ""}"
        onclick="event.stopPropagation();quickFavorite('${note.id}')">
        <img src="icons/star.png" alt="">
      </button>
      <button class="mini-btn"
        onclick="event.stopPropagation();archiveNote('${note.id}')">
        <img src="icons/folder.png" alt="">
      </button>`;
  }

  return `
    <article class="note-card" onclick="editNote('${note.id}')">
      <div class="note-card-top">
        <h3>${title}</h3>
        <div class="card-actions">${actions}</div>
      </div>
      <div class="note-preview">${content}</div>
      <div class="note-footer">
        <span class="badge">${escapeHTML(note.category || "Personnel")}</span>
        ${folder ? `<span class="badge">${escapeHTML(folder)}</span>` : ""}
        <span>${formatDate(note.updatedAt)}</span>
      </div>
    </article>`;
}

function emptyHTML(title, message) {
  return `<div class="empty-state">
    <strong>${escapeHTML(title)}</strong>
    ${escapeHTML(message)}
  </div>`;
}

function activeNotes() {
  return notes.filter(n => !n.deleted && !n.archived);
}

function sortNotes(list) {
  const sort = $("sortFilter").value;

  return [...list].sort((a, b) => {
    if (sort === "title") {
      return (a.title || "").localeCompare(b.title || "", "fr");
    }

    if (sort === "created") {
      return new Date(b.createdAt) - new Date(a.createdAt);
    }

    return new Date(b.updatedAt) - new Date(a.updatedAt);
  });
}

function renderNotes() {
  const query = $("searchInput").value.trim().toLowerCase();
  const category = $("categoryFilter").value;

  const list = sortNotes(activeNotes().filter(note => {
    const matchesText =
      (note.title + " " + note.content).toLowerCase().includes(query);

    const matchesCategory =
      category === "all" || note.category === category;

    return matchesText && matchesCategory;
  }));

  $("allNotes").innerHTML = list.length
    ? list.map(note => cardHTML(note)).join("")
    : emptyHTML("Aucune note trouvée", "Créez une note ou modifiez votre recherche.");
}

function renderRecent() {
  const list = activeNotes()
    .sort((a, b) => new Date(b.updatedAt) - new Date(a.updatedAt))
    .slice(0, 4);

  $("recentNotes").innerHTML = list.length
    ? list.map(note => cardHTML(note)).join("")
    : emptyHTML("Votre espace est prêt", "Créez votre première note.");
}

function renderFavorites() {
  const list = activeNotes().filter(n => n.favorite);

  $("favoriteNotes").innerHTML = list.length
    ? list.map(note => cardHTML(note)).join("")
    : emptyHTML("Aucun favori", "Ajoutez des notes à vos favoris.");
}

function renderArchives() {
  const list = notes.filter(n => n.archived && !n.deleted);

  $("archiveNotes").innerHTML = list.length
    ? list.map(note => cardHTML(note, "archive")).join("")
    : emptyHTML("Aucune archive", "Vos notes archivées apparaîtront ici.");
}

function renderTrash() {
  const list = notes.filter(n => n.deleted);

  $("trashNotes").innerHTML = list.length
    ? list.map(note => cardHTML(note, "trash")).join("")
    : emptyHTML("Corbeille vide", "Les notes supprimées apparaîtront ici.");
}

function renderFolders() {
  $("totalFolders").textContent = folders.length;

  $("folderList").innerHTML = folders.length
    ? folders.map(folder => {
      const count = activeNotes().filter(n => n.folderId === folder.id).length;

      return `
        <div class="folder-card">
          <button class="folder-open" onclick="viewFolder('${folder.id}')">
            <img src="icons/folder.png" width="23" height="23" alt="">
            <br><br>
            <strong>${escapeHTML(folder.name)}</strong>
            <div class="folder-count">${count} note(s)</div>
          </button>
          <div class="folder-actions">
            <button class="mini-btn" onclick="renameFolder('${folder.id}')">Renommer</button>
            <button class="mini-btn" onclick="deleteFolder('${folder.id}')">
              <img src="icons/x.png" alt="">
            </button>
          </div>
        </div>`;
    }).join("")
    : emptyHTML("Aucun dossier", "Créez un dossier pour organiser vos notes.");

  const selectedId = $("folderNotes").dataset.folderId;

  if (selectedId) {
    const folder = folders.find(f => f.id === selectedId);

    if (folder) {
      const list = activeNotes().filter(n => n.folderId === selectedId);

      $("folderNotes").innerHTML =
        `<h2>${escapeHTML(folder.name)}</h2>` +
        (list.length
          ? list.map(note => cardHTML(note)).join("")
          : emptyHTML("Dossier vide", "Ajoutez-y une note."));
    } else {
      $("folderNotes").innerHTML = "";
      delete $("folderNotes").dataset.folderId;
    }
  }
}

function viewFolder(id) {
  const folder = folders.find(f => f.id === id);
  if (!folder) return;

  $("folderNotes").dataset.folderId = id;

  const list = activeNotes().filter(n => n.folderId === id);

  $("folderNotes").innerHTML =
    `<h2>${escapeHTML(folder.name)}</h2>` +
    (list.length
      ? list.map(note => cardHTML(note)).join("")
      : emptyHTML("Dossier vide", "Ajoutez-y une note."));

  $("folderNotes").scrollIntoView({ behavior: "smooth", block: "start" });
}

function renderAll() {
  $("totalNotes").textContent = activeNotes().length;
  $("totalFavorites").textContent =
    activeNotes().filter(n => n.favorite).length;

  renderRecent();
  renderNotes();
  renderFavorites();
  renderArchives();
  renderTrash();
  renderFolders();
}

function downloadFile(content, filename, mimeType) {
  const blob = new Blob(["\ufeff", content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");

  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  link.remove();

  setTimeout(() => URL.revokeObjectURL(url), 1500);
}

function exportBackup() {
  const data = {
    app: "Blue Memo",
    version: 2,
    exportedAt: new Date().toISOString(),
    notes,
    folders
  };

  downloadFile(
    JSON.stringify(data, null, 2),
    "blue-memo-sauvegarde.json",
    "application/json;charset=utf-8"
  );

  showToast("Sauvegarde préparée");
}

function importBackup(event) {
  const file = event.target.files && event.target.files[0];
  if (!file) return;

  const reader = new FileReader();

  reader.onload = function() {
    try {
      const data = JSON.parse(reader.result);

      if (!Array.isArray(data.notes) || !Array.isArray(data.folders)) {
        throw new Error("Format invalide");
      }

      if (!confirm("Remplacer les données actuelles par cette sauvegarde ?")) {
        return;
      }

      notes = data.notes;
      folders = data.folders;

      saveData();
      renderAll();
      showToast("Sauvegarde restaurée");
    } catch (e) {
      showToast("Fichier JSON invalide");
    } finally {
      event.target.value = "";
    }
  };

  reader.readAsText(file);
}

function exportText() {
  const list = activeNotes();

  if (!list.length) {
    showToast("Aucune note à exporter");
    return;
  }

  const content = list.map(note => [
    note.title || "Sans titre",
    "Catégorie : " + (note.category || "Personnel"),
    "Date : " + formatDate(note.updatedAt),
    "",
    note.content || "",
    "\n" + "=".repeat(35)
  ].join("\n")).join("\n\n");

  downloadFile(
    content,
    "blue-memo-notes.txt",
    "text/plain;charset=utf-8"
  );

  showToast("Export préparé");
}

function saveSettings() {
  const settings = {
    compact: $("compactMode").checked,
    reduceMotion: $("reduceMotion").checked
  };

  try {
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
  } catch (e) {}

  applySettings();
}

function applySettings() {
  document.body.classList.toggle(
    "compact",
    $("compactMode").checked
  );

  document.body.classList.toggle(
    "reduce-motion",
    $("reduceMotion").checked
  );
}

$("noteTitle").addEventListener("input", scheduleSave);

$("noteContent").addEventListener("input", () => {
  scheduleSave();
  updateWordCount();
});

$("noteCategory").addEventListener("change", scheduleSave);
$("noteFolder").addEventListener("change", scheduleSave);

window.addEventListener("beforeunload", flushEditor);

loadData();
renderAll();
/* ==========================================
   BLUE MEMO — BOUNCE CLICK EFFECT
   ========================================== */

document.addEventListener("click", function(event) {
  const element = event.target.closest(
    "button, .note-card, .folder-card"
  );

  if (!element) return;

  if (document.body.classList.contains("reduce-motion")) {
    return;
  }

  /* Évite d'animer les éléments de saisie */
  if (element.matches("input, textarea, select")) {
    return;
  }

  element.classList.remove("bounce-effect");

  /* Redémarre l'animation */
  void element.offsetWidth;

  element.classList.add("bounce-effect");

  element.addEventListener("animationend", function() {
    element.classList.remove("bounce-effect");
  }, { once: true });
});