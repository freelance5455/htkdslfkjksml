package com.ultron.ai

import android.Manifest
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

private val Bg = Color(0xFF05070B)
private val Panel = Color(0xFF0D121A)
private val Cyan = Color(0xFF00E5FF)
private val Magenta = Color(0xFFFF2BD6)

class MainActivity : ComponentActivity() {
    private lateinit var tts: TextToSpeech
    private lateinit var engine: UltronEngine

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this) { tts.language = Locale.US }
        engine = UltronEngine(this)
        setContent { UltronScreen(this, engine, tts) }
    }

    override fun onDestroy() {
        tts.stop(); tts.shutdown(); super.onDestroy()
    }
}

data class ChatLine(val who: String, val text: String)

class UltronEngine(private val context: Context) {
    private val ai = OpenAIResponsesClient(context)

    fun execute(input: String, onResult: (String) -> Unit) {
        val command = input.trim()
        if (command.isBlank()) return
        val lower = command.lowercase(Locale.getDefault())

        // Deterministic device commands first. AI is used for everything else.
        if (lower.startsWith("open ") || lower.startsWith("launch ") || lower.startsWith("start ")) {
            val target = command.substringAfter(' ').trim()
            if (openApp(target)) { onResult("Opening $target."); return }
        }
        if (lower.contains("flashlight") || lower.contains("torch")) {
            onResult("For reliable flashlight control, use your phone's Quick Settings. Android restricts some background device controls.")
            return
        }
        if (lower.contains("wifi") || lower.contains("bluetooth")) {
            context.startActivity(Intent(Settings.ACTION_WIRELESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            onResult("Opening wireless settings."); return
        }
        if (lower.contains("volume up")) { setVolume(+1); onResult("Volume increased."); return }
        if (lower.contains("volume down")) { setVolume(-1); onResult("Volume decreased."); return }
        if (lower.contains("camera")) {
            context.startActivity(Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            onResult("Opening camera."); return
        }
        if (lower.contains("timer")) {
            val minutes = Regex("(\\d+)\\s*(minute|min)").find(lower)?.groupValues?.get(1)?.toLongOrNull()
            if (minutes != null) {
                val intent = Intent(android.provider.AlarmClock.ACTION_SET_TIMER).apply {
                    putExtra(android.provider.AlarmClock.EXTRA_LENGTH, (minutes * 60).toInt())
                    putExtra(android.provider.AlarmClock.EXTRA_SKIP_UI, false)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent); onResult("Setting a $minutes minute timer."); return
            }
        }
        if (lower.contains("alarm")) {
            context.startActivity(Intent(android.provider.AlarmClock.ACTION_SET_ALARM).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            onResult("Opening alarm setup."); return
        }
        if (lower.contains("settings")) {
            context.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            onResult("Opening settings."); return
        }
        if (lower.startsWith("navigate to ") || lower.startsWith("directions to ")) {
            val place = command.substringAfter(" to ").trim()
            val uri = android.net.Uri.parse("google.navigation:q=" + android.net.Uri.encode(place))
            val intent = Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent); onResult("Starting navigation to $place."); return
        }
        if (lower.startsWith("search the web for ") || lower.startsWith("google ")) {
            val q = command.substringAfter("for ", command.substringAfter("google ")).trim()
            val intent = Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://www.google.com/search?q=" + android.net.Uri.encode(q))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent); onResult("Searching the web for $q."); return
        }

        CoroutineScope(Dispatchers.IO).launch {
            val answer = ai.answer(command)
            CoroutineScope(Dispatchers.Main).launch { onResult(answer) }
        }
    }

    fun saveApiKey(key: String) { ai.saveKey(key) }

    private fun setVolume(delta: Int) {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.adjustStreamVolume(AudioManager.STREAM_MUSIC, if (delta > 0) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
    }

    private fun openApp(name: String): Boolean {
        val pm = context.packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launcher, PackageManager.MATCH_ALL)
        val wanted = name.lowercase(Locale.getDefault()).replace(" ", "")
        val match = apps.firstOrNull {
            val label = it.loadLabel(pm).toString().lowercase(Locale.getDefault()).replace(" ", "")
            label == wanted || label.contains(wanted) || wanted.contains(label)
        } ?: return false
        val launch = pm.getLaunchIntentForPackage(match.activityInfo.packageName) ?: return false
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(launch)
        return true
    }
}

class OpenAIResponsesClient(private val context: Context) {
    // For a production release, put the API call behind your own server. A mobile app cannot keep a provider secret permanently.
    private val prefs = context.getSharedPreferences("ultron", Context.MODE_PRIVATE)
    private val endpoint = "https://api.openai.com/v1/responses"
    private val model = "gpt-5.6-luna"

    fun answer(question: String): String {
        val key = prefs.getString("api_key", null)
            ?: return "I need an AI API key. Open ULTRON settings and add your key, or connect ULTRON to your own secure AI backend."
        return try {
            val conn = URL(endpoint).openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.setRequestProperty("Authorization", "Bearer $key")
            conn.setRequestProperty("Content-Type", "application/json")
            conn.connectTimeout = 15000; conn.readTimeout = 30000; conn.doOutput = true
            val body = JSONObject().apply {
                put("model", model)
                put("instructions", "You are ULTRON, a concise, intelligent Android assistant. Answer questions accurately. Never claim an Android action happened unless the app actually performed it. Keep answers useful and age-appropriate.")
                put("input", question)
            }
            conn.outputStream.use { it.write(body.toString().toByteArray()) }
            val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
            val response = stream.bufferedReader().use { it.readText() }
            if (conn.responseCode !in 200..299) return "AI request failed (${conn.responseCode}). Check the API key and network connection."
            val json = JSONObject(response)
            json.optString("output_text").ifBlank { "I received an empty response." }
        } catch (e: Exception) {
            "I couldn't reach the AI service. Check your internet connection and AI configuration."
        }
    }

    fun saveKey(key: String) { prefs.edit().putString("api_key", key.trim()).apply() }
    fun hasKey(): Boolean = !prefs.getString("api_key", null).isNullOrBlank()
}

@Composable
fun UltronScreen(context: Context, engine: UltronEngine, tts: TextToSpeech) {
    var input by remember { mutableStateOf("") }
    var listening by remember { mutableStateOf(false) }
    val messages = remember { mutableStateListOf(ChatLine("ULTRON", "Systems online. Ask me anything or tell me what to open.")) }

    val speechLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val text = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!text.isNullOrBlank()) {
            input = text
            messages.add(ChatLine("YOU", text))
            engine.execute(text) { answer -> messages.add(ChatLine("ULTRON", answer)); tts.speak(answer, TextToSpeech.QUEUE_FLUSH, null, "ultron") }
        }
        listening = false
    }

    val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
                putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to ULTRON")
            }
            speechLauncher.launch(intent)
        }
    }

    Column(Modifier.fillMaxSize().background(Bg).padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Box(Modifier.size(48.dp).background(Cyan.copy(alpha=.12f), CircleShape), contentAlignment = Alignment.Center) {
                Text("U", color = Cyan, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("ULTRON", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Text("AI OPERATING LAYER • ONLINE", color = Cyan, fontSize = 11.sp)
            }
            Text("2.0", color = Magenta, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(16.dp))
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(messages) { msg ->
                Surface(color = if (msg.who == "ULTRON") Panel else Color(0xFF101A22), shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp)) {
                        Text(msg.who, color = if (msg.who == "ULTRON") Cyan else Magenta, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(4.dp))
                        Text(msg.text, color = Color.White, fontSize = 15.sp)
                    }
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f), placeholder = { Text("Command ULTRON...") }, singleLine = true)
            Spacer(Modifier.width(8.dp))
            Button(onClick = {
                if (input.isNotBlank()) {
                    val q = input.trim(); input = ""; messages.add(ChatLine("YOU", q)); engine.execute(q) { a -> messages.add(ChatLine("ULTRON", a)); tts.speak(a, TextToSpeech.QUEUE_FLUSH, null, "ultron") }
                }
            }) { Text("SEND") }
        }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = {
                if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                    val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
                        putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to ULTRON")
                    }
                    listening = true
                    speechLauncher.launch(intent)
                } else {
                    micPermission.launch(Manifest.permission.RECORD_AUDIO)
                }
            }, modifier = Modifier.weight(1f)) { Text(if (listening) "LISTENING…" else "VOICE") }
            OutlinedButton(onClick = {
                val field = android.widget.EditText(context).apply { hint = "OpenAI API key" }
                android.app.AlertDialog.Builder(context)
                    .setTitle("ULTRON AI CONFIG")
                    .setMessage("For production, use a secure backend. This personal build stores the key locally on the device.")
                    .setView(field)
                    .setPositiveButton("SAVE") { _, _ -> engine.saveApiKey(field.text.toString()); Toast.makeText(context, "AI key saved", Toast.LENGTH_SHORT).show() }
                    .setNegativeButton("CANCEL", null).show()
            }) { Text("AI KEY") }
        }
    }
}
