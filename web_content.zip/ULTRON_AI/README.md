# ULTRON AI 2.0 — Phone/Cloud Build

This is a standalone Android Studio/Gradle project for ULTRON. You do **not** need Android Studio on your phone to build it.

## Easiest phone-only build: GitHub Actions

1. On your phone, create a new GitHub repository (for example `ultron-ai`).
2. Upload the contents of this folder to the repository. Upload the files/folders themselves, not the outer ZIP.
3. Open the repository's **Actions** tab.
4. Select **Build ULTRON APK**.
5. Tap **Run workflow**.
6. Wait for the workflow to finish.
7. Open the completed workflow run and download the **ULTRON-debug-apk** artifact.
8. Extract the downloaded artifact and install `app-debug.apk` on your Android phone.

The included workflow installs Android SDK 35, Java 17, Gradle 8.9, builds the debug APK, and publishes the APK as a downloadable artifact.

## What ULTRON can do

- Answer general questions through an AI backend/API.
- Accept voice commands using Android speech recognition.
- Speak responses using Android Text-to-Speech.
- Find and launch installed launcher apps.
- Open Camera.
- Open wireless and system settings.
- Start timers and alarms through Android intents.
- Start navigation through a maps-capable app.
- Adjust media volume.
- Search the web.

## AI configuration

The current personal/test build lets you enter an AI provider key in the app. For a public release, do not ship a permanent provider secret in the APK. Use a secure backend that authenticates the user and calls the AI provider server-side.

## Important Android limitation

A normal Android app cannot silently control every part of the device. Some actions require explicit Android permissions, user confirmation, special roles, or system-level privileges. ULTRON should only report an action as completed after Android actually accepts/performs it.

## Local build

Android Studio can open this project normally. The cloud workflow is provided specifically for users who do not have Android Studio available on their phone.
