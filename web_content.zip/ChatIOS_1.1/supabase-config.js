// Isi dengan Project URL dan anon/publishable key Supabase kamu.
// JANGAN masukkan service_role key ke APK.
window.SUPABASE_URL="";
window.SUPABASE_ANON_KEY="";
