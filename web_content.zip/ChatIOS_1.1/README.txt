CHATIOS 1.1 STARTER

UI sudah dibuat bergaya aplikasi chat modern dengan:
- Chats, Calls, Updates, Kontak, Pengaturan
- Jam, hari, tanggal pada setiap pesan
- Kirim teks
- Pilih foto/video dari galeri dan preview di chat
- Dasar koneksi Supabase

Agar benar-benar antar-HP:
1. Isi supabase-config.js dengan Project URL + anon/publishable key.
2. Buat tabel messages, Auth dan Storage di Supabase.
3. Aktifkan Realtime untuk messages.
4. Tambahkan Firebase Cloud Messaging (FCM) + Edge Function/server untuk push notification Android ketika penerima tidak membuka aplikasi.

Jangan masukkan service_role key ke aplikasi.
