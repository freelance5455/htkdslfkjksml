MicrosoftHub HTML uygulaması

Kullanım:
1. ZIP'i aç.
2. index.html dosyasını Android cihazında bir tarayıcıyla aç.
3. Ana sayfadan belge/not/tablo/sunum taslağı oluştur.
4. İçerikler tarayıcının localStorage alanında saklanır. Tarayıcı verilerini temizlemek içerikleri silebilir; Hakkında sayfasından JSON yedeği alabilirsin.

Özellikler:
- Türkçe mobil uyumlu arayüz
- Belge oluşturma, düzenleme, silme
- Dosya arama ve türe göre filtreleme
- Metin paylaşımı (desteklenen tarayıcılarda paylaşım menüsü) veya TXT dışa aktarma
- JSON yedekleme ve geri yükleme
- Temel kullanımda internet gerektirmez

Not: Bu bir HTML web uygulamasıdır, APK değildir. Kayıtlar cihazdaki tarayıcıya özeldir. Tarayıcı verilerini silmeden önce yedek al.
