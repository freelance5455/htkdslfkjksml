/* JOSTECH — MANUEL 08 : ROBOTIQUE NIVEAU 1 */
registerLessonDetail(8, 1, "rob-1-1-1", {
  title: "Leçon 1 : Électronique Fondamentale, Capteurs et Actionneurs",
  duration: "40 min (Manuel complet)",
  objectives: [
    "Maîtriser Tension (U), Courant (I), Résistance (R), Puissance (P = U × I) et la Loi d'Ohm.",
    "Distinguer les capteurs (entrées de perception) et les actionneurs (sorties motrices).",
    "Comprendre pourquoi un microcontrôleur ne peut jamais alimenter directement un gros moteur (Pont en H)."
  ],
  prerequisites: ["Notions de physique et mathématiques de base."],
  sections: [
    {
      type: "definition",
      term: "Qu'est-ce qu'un Robot ? (Chaîne d'Information & d'Énergie)",
      text: "Un robot est un système mécatronique programmable qui perçoit son environnement (Capteurs), traite les données (Unité de calcul / Microcontrôleur) et agit physiquement sur le monde réel (Actionneurs).\n• Capteurs (Entrées) : ultrason HC-SR04 (distance), infrarouge (suivi de ligne), IMU/gyroscope (équilibre), caméra.\n• Actionneurs (Sorties) : moteurs DC (roues), servomoteurs (angle précis 0-180°), moteurs pas-à-pas (imprimante 3D), relais."
    },
    {
      type: "theory",
      title: "1. Lois électriques vitales : Ohm et Puissance",
      text: "La Loi d'Ohm relie tension, résistance et intensité : U = R × I (Volts = Ohms × Ampères). La puissance consommée vaut P = U × I (Watts).\n\nEn robotique, la broche d'une carte Arduino ou ESP32 ne délivre qu'un minuscule courant maximal (~20 à 40 mA). Brancher une LED sans résistance en série la fait griller immédiatement ; brancher un moteur directement sur la broche de commande grille le microcontrôleur ! On intercale donc toujours une interface de puissance (Transistor MOSFET ou driver Pont en H comme le L298N) pour piloter les moteurs depuis une batterie séparée."
    },
    {
      type: "table",
      title: "2. Choix du type de moteur en robotique",
      headers: ["Actionneur", "Contrôle", "Usage typique"],
      rows: [
        ["Moteur à courant continu (DC)", "Vitesse via PWM, sens via Pont en H", "Roues de robots mobiles rapides."],
        ["Servomoteur", "Angle exact (ex: 0° à 180°)", "Pinces, direction, bras articulés légers."],
        ["Moteur Pas-à-Pas (Stepper)", "Rotation par pas exacts sans jeu", "Imprimantes 3D, fraiseuses CNC, robots de précision."]
      ]
    },
    {
      type: "warning",
      title: "Pièges électriques dangereux sur banc d'essai",
      text: "1) Courant de retour inductif : un moteur qui s'arrête renvoie un pic de haute tension inverse capable de détruire vos puces — utilisez toujours des diodes de roue libre.\n2) Masses communes (GND) : même si la batterie moteurs (12 V) et l'Arduino (5 V) sont séparés, reliez toujours leurs fils noirs GND ensemble !"
    }
  ],
  exercises: [
    {
      title: "Exercice 1 — Calcul de résistance de protection",
      question: "Une broche Arduino délivre 5 V. Vous souhaitez allumer une LED bleue dont la tension de seuil est 3 V et le courant nominal 20 mA (0,02 A). Calculez la résistance exacte R à placer en série.",
      solution: "Tension aux bornes de la résistance : Ur = 5 V - 3 V = 2 V.\nPar la loi d'Ohm : R = Ur / I = 2 V / 0,02 A = 100 Ohms (on choisit la valeur normalisée supérieure, ex. 120 Ω ou 220 Ω)."
    },
    {
      title: "Exercice 2 — Pilotage d'un moteur 12 V",
      question: "Un étudiant branche un moteur DC 12 V (consommant 1,5 A) directement sur la broche numérique D7 de son Arduino (limite 0,04 A). Que va-t-il se passer et quel composant manque-t-il ?",
      solution: "La broche de l'Arduino va griller définitivement par surintensité ! Il faut un étage de puissance (driver Pont en H ou MOSFET) relié à une batterie externe 12 V."
    }
  ],
  summary: "La robotique unit capteurs, microcontrôleurs et actionneurs sous le contrôle strict des lois électriques (U = R·I), des diodes de protection et d'étages de puissance (Pont en H).",
  references: ["Monk, S. — Electronics Cookbook, O'Reilly.", "Craig, J. — Introduction to Robotics."]
});