PINKVENTORY V3

Versi ini memperbaiki:
1. Data contoh dan laporan memakai sumber data yang sama, jadi tidak ada laporan berisi barang yang tidak ada di inventaris.
2. Kamera langsung memakai navigator.mediaDevices.getUserMedia().
3. Galeri tetap tersedia sebagai fallback.
4. Tambah/edit barang, foto, kategori, pencarian, filter stok, laporan Chart.js, backup/restore JSON, export CSV.
5. Data disimpan di localStorage.

IZIN ANDROID:
- Jika dijadikan APK/WebView: aktifkan/izinkan CAMERA.
- Jika aplikasi meminta akses foto/media, izinkan akses foto/media untuk memilih gambar dari galeri.
- Saat pertama menekan Kamera, Android harus menampilkan prompt izin. Pilih Izinkan.
- Jika prompt pernah ditolak, buka Pengaturan > Aplikasi > Pinkventory > Izin > Kamera, lalu Izinkan.
- Untuk versi HTML yang dibuka di browser, izin kamera mengikuti browser dan situs/localhost yang menjalankan file tersebut. File HTML lokal tertentu dapat membatasi getUserMedia; versi APK/WebView HTTPS/localhost lebih cocok untuk kamera langsung.
