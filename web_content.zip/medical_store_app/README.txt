MEDICAL STORE OFFLINE APP

This is a self-contained offline-first Android-friendly web app (PWA-style).

Features:
- Local/offline product, customer, cart and invoice data
- Product pictures
- PKR currency
- Percentage or fixed PKR discounts
- Paid amount and balance
- PDF invoice generation
- Android PDF file sharing where supported
- Backup/restore to a JSON file
- Simple UI for non-technical users

USE ON ANDROID:
1. Extract the ZIP and place the folder on your phone or host it on a local/web server.
2. Open index.html in a modern Android browser.
3. For an app-like experience, use the browser's "Add to Home screen" option.
4. Normal operation does not require internet after the page is loaded.

IMPORTANT:
- Google Drive automatic OAuth backup is not included in this standalone offline build because it requires a Google Cloud project/client configuration. The app includes local backup/restore so data can be safely exported and later restored.
- For production medical/business use, have the storage and backup security reviewed before storing real customer data.
