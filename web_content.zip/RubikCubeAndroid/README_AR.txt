تطبيق مكعب روبيك - مشروع أندرويد

هذا مشروع Android Studio يغلّف ملف اللعبة HTML داخل WebView، والواجهة عربية.

لإنشاء APK:
1. ثبّت Android Studio على الكمبيوتر.
2. فك ضغط RubikCubeAndroid.zip.
3. افتح مجلد RubikCubeAndroid في Android Studio وانتظر مزامنة Gradle.
4. ثبّت Android SDK 35 إذا طلبه البرنامج.
5. من القائمة اختر Build > Build Bundle(s) / APK(s) > Build APK(s).
6. عند انتهاء البناء اضغط Locate لفتح مجلد ملف APK.

ملاحظة: ملف APK النهائي غير موجود في هذه الحزمة؛ هذه ملفات المشروع المصدرية اللازمة لبنائه في Android Studio. ملف اللعبة داخل assets ويعمل محلياً، لكن تحميل خطوط Google Fonts يتطلب اتصالاً بالإنترنت وقد يستخدم الخط الافتراضي عند عدم توفره.
