/**
 * Entry point for the single-file offline build (standalone/index.html).
 * Bundled by scripts/build-standalone.mjs with esbuild — no Next.js server,
 * no internet, everything (including the ledger) lives on the device.
 */
import React from "react";
import { createRoot } from "react-dom/client";
import App from "@/components/App";

const el = document.getElementById("root");
if (el) {
  createRoot(el).render(
    <React.StrictMode>
      <App />
    </React.StrictMode>,
  );
}
