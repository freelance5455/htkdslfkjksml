// One-time, trusted setup. Run it in Google Cloud Shell (already authenticated) or any trusted machine.
//   cd functions && npm install
//   node scripts/set-owner.js bardahawale@gmail.com          # grant owner
//   node scripts/set-owner.js bardahawale@gmail.com --revoke # revoke owner
// Never put a service-account key in the Android app or commit one to Git.
const { initializeApp } = require("firebase-admin/app");
const { getAuth } = require("firebase-admin/auth");

(async () => {
  const [email, flag] = process.argv.slice(2);
  if (!email) { console.error("Usage: node scripts/set-owner.js <email> [--revoke]"); process.exit(1); }
  initializeApp();
  const auth = getAuth();
  const user = await auth.getUserByEmail(email);
  if (flag === "--revoke") {
    await auth.setCustomUserClaims(user.uid, { owner: null });
    await auth.revokeRefreshTokens(user.uid);
    console.log(`Owner access revoked for ${email}.`);
    return;
  }
  if (!user.emailVerified) {
    console.error("Refusing: this account's email is not verified. Sign in with Google or verify the email first.");
    process.exit(1);
  }
  await auth.setCustomUserClaims(user.uid, { owner: true });
  console.log(`Owner claim set for ${email}. Sign out and back in for it to take effect.`);
})().catch((e) => { console.error(e.message); process.exit(1); });
