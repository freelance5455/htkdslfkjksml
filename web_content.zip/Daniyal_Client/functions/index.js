// Trusted server-side publishing for the owner dashboard.
const { onCall, HttpsError } = require("firebase-functions/v2/https");
const { initializeApp } = require("firebase-admin/app");
const { getFirestore, FieldValue } = require("firebase-admin/firestore");

initializeApp();
const db = getFirestore();

const LIMITS = {
  homeTitle: 80, homeSubtitle: 160, welcomeMessage: 200, bannerText: 240,
  emptyStateText: 240, aboutText: 2000, heroAlt: 160,
};
const IMAGE_PREFIX = "https://firebasestorage.googleapis.com/";

function assertOwner(request) {
  const t = request.auth && request.auth.token;
  if (!t || t.owner !== true || t.email_verified !== true) {
    throw new HttpsError("permission-denied", "Owner access required.");
  }
  return request.auth.uid;
}

// Re-validate on the server: never trust what the client wrote to the draft.
function sanitize(raw) {
  const out = {};
  for (const [key, max] of Object.entries(LIMITS)) {
    const v = raw[key];
    if (v === undefined) continue;
    if (typeof v !== "string" || v.length > max) {
      throw new HttpsError("invalid-argument", `Invalid value for ${key}.`);
    }
    out[key] = v.trim();
  }
  if (raw.bannerEnabled !== undefined) {
    if (typeof raw.bannerEnabled !== "boolean") throw new HttpsError("invalid-argument", "Invalid bannerEnabled.");
    out.bannerEnabled = raw.bannerEnabled;
  }
  if (raw.heroImageUrl !== undefined) {
    const u = raw.heroImageUrl;
    if (typeof u !== "string" || u.length > 2048 || (u && !u.startsWith(IMAGE_PREFIX))) {
      throw new HttpsError("invalid-argument", "Image must be hosted in Firebase Storage.");
    }
    out.heroImageUrl = u;
  }
  return out;
}

exports.publishContent = onCall(async (request) => {
  const uid = assertOwner(request);
  const draftSnap = await db.doc("app_content_draft/current").get();
  if (!draftSnap.exists) throw new HttpsError("failed-precondition", "There is no draft to publish.");
  const draft = sanitize(draftSnap.data());

  const publishedRef = db.doc("app_content/published");
  const previous = await publishedRef.get();
  const batch = db.batch();
  if (previous.exists) {
    batch.set(db.collection("admin_revisions").doc(), {
      content: previous.data(), savedAt: FieldValue.serverTimestamp(), by: uid, reason: "replaced by publish",
    });
  }
  batch.set(publishedRef, { ...draft, updatedAt: FieldValue.serverTimestamp(), updatedBy: uid });
  batch.set(db.collection("audit_log").doc(), { action: "publish", uid, at: FieldValue.serverTimestamp() });
  await batch.commit();
  return { ok: true };
});

exports.restoreRevision = onCall(async (request) => {
  const uid = assertOwner(request);
  const id = request.data && request.data.revisionId;
  if (typeof id !== "string" || !id || id.includes("/")) throw new HttpsError("invalid-argument", "Missing revisionId.");
  const revSnap = await db.collection("admin_revisions").doc(id).get();
  if (!revSnap.exists) throw new HttpsError("not-found", "Revision not found.");
  const content = sanitize(revSnap.data().content || {});

  const publishedRef = db.doc("app_content/published");
  const current = await publishedRef.get();
  const batch = db.batch();
  if (current.exists) {
    batch.set(db.collection("admin_revisions").doc(), {
      content: current.data(), savedAt: FieldValue.serverTimestamp(), by: uid, reason: "replaced by restore",
    });
  }
  batch.set(publishedRef, { ...content, updatedAt: FieldValue.serverTimestamp(), updatedBy: uid });
  batch.set(db.doc("app_content_draft/current"), { ...content, updatedAt: FieldValue.serverTimestamp(), updatedBy: uid });
  batch.set(db.collection("audit_log").doc(), { action: "restore", revisionId: id, uid, at: FieldValue.serverTimestamp() });
  await batch.commit();
  return { ok: true };
});
