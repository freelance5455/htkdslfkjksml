# Kept (daniyal.client.app)

Kept helps you stay in touch with people. Every person has a **warmth ring** that slowly cools as time passes. The home screen picks **who to reach today**, and **message starters** draft a note in the tone you choose. An owner-only dashboard (`index.html`) edits the app's text, banners and hero image live, with no new APK.

Kotlin, Jetpack Compose + Material 3, MVVM, Firebase Auth / Firestore / Storage / Functions. minSdk 26 (Android 8.0, adaptive icons and about 95% of devices), target/compile SDK 35.

## Honest status (read first)
| Item | Status |
|---|---|
| Source code, rules, functions, web dashboard, legal text | Written |
| Gradle build / APK | **Not compiled by the author**: the sandbox had no network or Android SDK. Expect to fix small compile errors on the first build. |
| Unit tests (`DomainTest`, `AuthErrorsTest`) | Written, **not run** |
| ViewModel / UI / navigation tests | **Not written** |
| Google Sign-In, email auth, rules, functions | **Untested** until you configure Firebase and run them |
| Firebase App Check | **Not implemented**; add it before public release |
| Owner editor inside the Android app | **Not included**; the owner dashboard is the responsive web page `index.html` (works in a phone browser) |
| Gradle wrapper | Not included (needs a download). CI uses Gradle 8.9 directly. |

## 1. Firebase setup (package `daniyal.client.app`)
The app ID is now **`daniyal.client.app`**, which matches the `google-services.json` you supplied (included at `app/google-services.json`, project `dipro-daniyal-assistant`). The Kotlin code still lives in the `com.daniyal.client` source package; that is internal and unrelated to Firebase.

That file has **no Android OAuth client yet**, so **Google Sign-In will not work until you**, in the Firebase console:
1. Project settings > Your apps > `daniyal.client.app` > **Add fingerprint**: add your **SHA-1** and **SHA-256** (for every key you sign with: debug and release).
2. Authentication > Sign-in method: enable **Google** and **Email/Password**.
3. Download the updated `google-services.json` and replace `app/google-services.json`.
Email/password sign-in does not need fingerprints.

## 2. Backend setup (from a phone: Google Cloud Shell)
Functions need the **Blaze (pay-as-you-go)** plan. Open Cloud Shell from the Google Cloud console, upload this project, then:
```
npm install -g firebase-tools && firebase login --no-localhost
firebase use dipro-daniyal-assistant
cd functions && npm install && cd ..
firebase deploy --only firestore:rules,storage,functions,hosting
```
Enable Firestore (production mode) and Storage in the console first. Nothing is deployed until you run this.

## 3. Make yourself the owner
1. Sign in once with **bardahawale@gmail.com** (Google sign-in, or email with a verified address).
2. In Cloud Shell: `cd functions && node scripts/set-owner.js bardahawale@gmail.com`
3. Sign out and back in. Revoke any time with `--revoke`.

Registering with that email grants nothing by itself: rules and functions check a server-set `owner` claim plus a verified email, and deny by default. No admin keys are in the app.

## 4. Owner dashboard (`index.html`)
Add a **Web app** in Firebase (Project settings > Add app > Web) and paste its `apiKey` and `appId` into `web/index.html` (and the root `index.html` copy, or delete the copy). `firebase deploy --only hosting` serves `web/` at `https://dipro-daniyal-assistant.web.app`. Add that domain under Authentication > Settings > Authorized domains (usually automatic).

Sections: Overview, Text & copy, Image library, Home screen, Announcements, Preview & publish, Revision history (restore + audit log), Settings. Edits stay in a **private draft** until **Publish**. Each publish stores the previous version as a revision. Image uploads are limited to JPEG/PNG/WebP under 5 MB. The app caches the last published content for offline use and falls back to bundled text.

Firestore layout: `users/{uid}/people/{id}`, `app_content/published` (public read, server write), `app_content_draft/current`, `admin_revisions/{id}`, `audit_log/{id}` (owner read only).

## 5. Build the APK from your phone (no computer)
1. Create a GitHub repository, upload this project (including `app/google-services.json`) via the GitHub website/app.
2. Actions tab > **Android build** > Run workflow. Download the `kept-apks` artifact (debug APK + unsigned release APK).
3. **Signing:** debug APKs are auto-signed with a debug key (register that key's SHA-1/256 in step 1). For release, sign `app-release-unsigned.apk` with your own keystore using any phone APK-signing tool, then register that key's fingerprints. Never commit a keystore. The Gradle file can also sign in CI from env vars `KEPT_KEYSTORE_FILE`, `KEPT_KEYSTORE_PASSWORD`, `KEPT_KEY_ALIAS`, `KEPT_KEY_PASSWORD`.

With Android Studio instead: open the folder, sync, run `gradle testDebugUnitTest assembleDebug`.

## 6. Before you publish
- Edit `domain/Legal.kt` (`LegalConfig`: operator name, contact email; `EFFECTIVE_DATE`) and the highlighted placeholders in `docs/privacy-policy.html` and `docs/terms-of-service.html`.
- Host `docs/privacy-policy.html` at a public HTTPS URL (e.g. Firebase Hosting or GitHub Pages) and enter that URL in Play Console. No URL is invented here.
- Review the legal text with a qualified professional; it is written to match this app but is not legal advice.
- Add App Check, confirm rules deployed, test sign-up, verification email, Google sign-in, password reset, and account deletion on a real device.
- Google button uses text only; follow Google's branding guidelines if you add its logo.
