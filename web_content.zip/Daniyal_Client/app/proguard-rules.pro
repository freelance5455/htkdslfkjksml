# Firestore documents are read manually (no reflection-based mapping), so no extra keep rules are required.
