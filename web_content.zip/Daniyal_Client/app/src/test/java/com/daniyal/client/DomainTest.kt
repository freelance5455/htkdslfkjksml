package com.daniyal.client

import com.daniyal.client.domain.AppContent
import com.daniyal.client.domain.ContentParser
import com.daniyal.client.domain.DraftBuilder
import com.daniyal.client.domain.Person
import com.daniyal.client.domain.Tone
import com.daniyal.client.domain.Validators
import com.daniyal.client.domain.Warmth
import java.util.concurrent.TimeUnit
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class DomainTest {
    private val now = 1_000_000_000_000L
    private fun person(daysAgo: Long, cadence: Int = 30, id: String = "x") =
        Person(id = id, name = "Sam Lee", lastContactMillis = now - TimeUnit.DAYS.toMillis(daysAgo), cadenceDays = cadence)

    @Test fun warmthIsFullWhenJustContacted() = assertEquals(1f, Warmth.of(person(0), now), 0.001f)
    @Test fun warmthHalvesAtHalfTheRhythm() = assertEquals(0.5f, Warmth.of(person(15), now), 0.001f)
    @Test fun warmthNeverGoesBelowZero() = assertEquals(0f, Warmth.of(person(400), now), 0f)
    @Test fun futureContactDoesNotExceedOne() = assertEquals(1f, Warmth.of(person(-5), now), 0f)
    @Test fun zeroCadenceIsTreatedAsOneDay() = assertEquals(0f, Warmth.of(person(3, cadence = 0), now), 0f)

    @Test fun nextToReachPicksCoolestFirstAndSkipsWarm() {
        val list = listOf(person(1, id = "warm"), person(25, id = "cool"), person(40, id = "gone"), person(20, id = "mid"))
        assertEquals(listOf("gone", "cool", "mid"), Warmth.nextToReach(list, now).map { it.id })
    }
    @Test fun nextToReachRespectsLimit() {
        val list = (1..6).map { person(29, id = "p$it") }
        assertEquals(2, Warmth.nextToReach(list, now, limit = 2).size)
    }
    @Test fun labelsMatchBands() {
        assertEquals("Warm", Warmth.label(0.9f)); assertEquals("Cooling", Warmth.label(0.5f))
        assertEquals("Fading", Warmth.label(0.1f)); assertEquals("Gone quiet", Warmth.label(0f))
    }

    @Test fun draftUsesFirstName() = assertTrue(DraftBuilder.build(person(0), Tone.Brief, 0).startsWith("Hi Sam,"))
    @Test fun longSilenceDraftAcknowledgesTheGap() =
        assertTrue(DraftBuilder.build(person(0), Tone.AfterSilence, 90).contains("far too long"))
    @Test fun shortSilenceDraftIsLighter() =
        assertTrue(DraftBuilder.build(person(0), Tone.AfterSilence, 20).contains("little while"))

    @Test fun emailValidation() {
        assertNotNull(Validators.email("")); assertNotNull(Validators.email("nope"))
        assertNull(Validators.email(" a.b+c@example.co.uk "))
    }
    @Test fun passwordValidation() {
        assertNotNull(Validators.password("short1")); assertNotNull(Validators.password("onlyletters"))
        assertNotNull(Validators.password("12345678")); assertNull(Validators.password("goodpass1"))
    }
    @Test fun confirmAndSignInPassword() {
        assertNotNull(Validators.confirm("a", "b")); assertNull(Validators.confirm("a", "a"))
        assertNotNull(Validators.signInPassword("")); assertNull(Validators.signInPassword("x"))
    }
    @Test fun nameAndNoteLimits() {
        assertNotNull(Validators.name("  ")); assertNotNull(Validators.name("a".repeat(61))); assertNull(Validators.name("Sam"))
        assertNotNull(Validators.note("a".repeat(281))); assertNull(Validators.note(""))
    }

    @Test fun contentParserFallsBackToDefaultsOnEmptyMap() = assertEquals(AppContent.Default, ContentParser.fromMap(emptyMap()))
    @Test fun contentParserRejectsNonFirebaseImageUrls() {
        assertNull(ContentParser.fromMap(mapOf("heroImageUrl" to "https://evil.example/x.png")).heroImageUrl)
        assertNull(ContentParser.fromMap(mapOf("heroImageUrl" to "http://firebasestorage.googleapis.com/x")).heroImageUrl)
    }
    @Test fun contentParserAcceptsFirebaseImageAndTrimsAndCapsText() {
        val c = ContentParser.fromMap(mapOf(
            "heroImageUrl" to "https://firebasestorage.googleapis.com/v0/b/x/o/content%2Fh.png?alt=media",
            "homeTitle" to "  " + "t".repeat(200),
            "bannerEnabled" to true, "bannerText" to "Hello",
        ))
        assertNotNull(c.heroImageUrl); assertEquals(80, c.homeTitle.length); assertTrue(c.bannerEnabled)
    }
    @Test fun contentParserIgnoresWrongTypes() {
        val c = ContentParser.fromMap(mapOf("homeTitle" to 5, "bannerEnabled" to "yes"))
        assertEquals(AppContent.Default.homeTitle, c.homeTitle); assertEquals(false, c.bannerEnabled)
    }
}
