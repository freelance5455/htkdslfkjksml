package com.daniyal.client

import com.daniyal.client.data.AuthErrors
import com.daniyal.client.data.UserFacingError
import com.google.firebase.FirebaseNetworkException
import com.google.firebase.auth.FirebaseAuthException
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class AuthErrorsTest {
    @Test fun userFacingMessageIsPassedThrough() = assertEquals("Hi", AuthErrors.message(UserFacingError("Hi")))
    @Test fun wrongPasswordAndUnknownUserShareOneMessage() {
        val a = AuthErrors.message(FirebaseAuthException("ERROR_WRONG_PASSWORD", "x"))
        val b = AuthErrors.message(FirebaseAuthException("ERROR_USER_NOT_FOUND", "x"))
        assertEquals(a, b)
    }
    @Test fun existingAccountSuggestsSignIn() =
        assertTrue(AuthErrors.message(FirebaseAuthException("ERROR_EMAIL_ALREADY_IN_USE", "x")).contains("signing in", true))
    @Test fun networkErrorIsFriendly() =
        assertTrue(AuthErrors.message(FirebaseNetworkException("x")).contains("connection", true))
    @Test fun unknownErrorsNeverLeakDetails() =
        assertEquals(AuthErrors.GENERIC, AuthErrors.message(RuntimeException("secret token abc")))
}
