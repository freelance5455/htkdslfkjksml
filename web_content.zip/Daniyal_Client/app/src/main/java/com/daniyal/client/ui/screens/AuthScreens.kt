package com.daniyal.client.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Checkbox
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.daniyal.client.domain.LegalDoc
import com.daniyal.client.domain.Validators
import com.daniyal.client.ui.AuthViewModel
import com.daniyal.client.ui.components.FormField
import com.daniyal.client.ui.components.MessageBanner
import com.daniyal.client.ui.components.PasswordField
import com.daniyal.client.ui.components.PrimaryButton
import com.daniyal.client.ui.components.WarmthRing
import com.daniyal.client.ui.theme.Space

private enum class Mode { SignIn, SignUp, Reset }

@Composable
fun AuthScreen(vm: AuthViewModel, onOpenLegal: (LegalDoc) -> Unit) {
    val form by vm.form.collectAsStateWithLifecycle()
    val context = LocalContext.current
    var mode by rememberSaveable { mutableStateOf(Mode.SignIn) }
    var name by rememberSaveable { mutableStateOf("") }
    var email by rememberSaveable { mutableStateOf("") }
    var password by rememberSaveable { mutableStateOf("") }
    var confirm by rememberSaveable { mutableStateOf("") }
    var accepted by rememberSaveable { mutableStateOf(false) }
    var showErrors by rememberSaveable { mutableStateOf(false) }

    fun switchTo(m: Mode) { mode = m; showErrors = false; vm.clearMessages() }

    val nameError = if (showErrors && mode == Mode.SignUp) Validators.name(name) else null
    val emailError = if (showErrors) Validators.email(email) else null
    val passwordError = if (showErrors) {
        if (mode == Mode.SignUp) Validators.password(password) else Validators.signInPassword(password)
    } else null
    val confirmError = if (showErrors && mode == Mode.SignUp) Validators.confirm(password, confirm) else null

    fun submit() {
        showErrors = true
        when (mode) {
            Mode.SignIn -> vm.signIn(email, password)
            Mode.SignUp -> vm.signUp(name, email, password, confirm, accepted)
            Mode.Reset -> vm.sendReset(email)
        }
    }

    Column(
        Modifier.fillMaxSize().systemBarsPadding().imePadding().verticalScroll(rememberScrollState()).padding(Space.l),
        verticalArrangement = Arrangement.spacedBy(Space.s),
    ) {
        WarmthRing(0.85f, diameter = 56.dp)
        Text(
            when (mode) { Mode.SignIn -> "Welcome back"; Mode.SignUp -> "Create your account"; Mode.Reset -> "Reset your password" },
            Modifier.padding(top = Space.s), style = MaterialTheme.typography.headlineMedium,
        )
        Text(
            when (mode) {
                Mode.SignIn -> "Sign in to see who needs a hello."
                Mode.SignUp -> "It takes a minute. We'll email you a link to verify your address."
                Mode.Reset -> "Enter your email and we'll send you a reset link."
            },
            Modifier.padding(bottom = Space.s), style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        form.error?.let { MessageBanner(it, isError = true) }
        form.info?.let { MessageBanner(it, isError = false) }

        if (mode == Mode.SignUp) FormField(name, { name = it }, "Your name", error = nameError)
        FormField(
            email, { email = it }, "Email", error = emailError, keyboardType = KeyboardType.Email,
            imeAction = if (mode == Mode.Reset) ImeAction.Done else ImeAction.Next,
        )
        if (mode != Mode.Reset) {
            PasswordField(password, { password = it }, "Password", error = passwordError,
                imeAction = if (mode == Mode.SignUp) ImeAction.Next else ImeAction.Done)
        }
        if (mode == Mode.SignUp) {
            PasswordField(confirm, { confirm = it }, "Confirm password", error = confirmError, imeAction = ImeAction.Done)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(accepted, { accepted = it })
                Text("I agree to the Terms of Service and Privacy Policy", style = MaterialTheme.typography.bodyMedium)
            }
            Row {
                TextButton(onClick = { onOpenLegal(LegalDoc.Terms) }) { Text("Read Terms") }
                TextButton(onClick = { onOpenLegal(LegalDoc.Privacy) }) { Text("Read Privacy Policy") }
            }
        }

        PrimaryButton(
            text = when (mode) { Mode.SignIn -> "Sign in"; Mode.SignUp -> "Create account"; Mode.Reset -> "Send reset link" },
            onClick = ::submit, loading = form.busy,
        )

        if (mode == Mode.SignIn) TextButton(onClick = { switchTo(Mode.Reset) }, Modifier.align(Alignment.End)) { Text("Forgot password?") }

        if (mode != Mode.Reset) {
            Row(Modifier.fillMaxWidth().padding(vertical = Space.s), verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(Space.m)) {
                HorizontalDivider(Modifier.weight(1f)); Text("or", color = MaterialTheme.colorScheme.onSurfaceVariant); HorizontalDivider(Modifier.weight(1f))
            }
            OutlinedButton(
                onClick = { vm.signInWithGoogle(context) },
                enabled = !form.busy,
                modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp),
            ) { Text("Continue with Google") }
            if (mode == Mode.SignIn) {
                Text("By continuing with Google you also agree to our Terms and Privacy Policy.",
                    style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row {
                    TextButton(onClick = { onOpenLegal(LegalDoc.Terms) }) { Text("Terms") }
                    TextButton(onClick = { onOpenLegal(LegalDoc.Privacy) }) { Text("Privacy Policy") }
                }
            }
        }

        TextButton(
            onClick = { switchTo(if (mode == Mode.SignIn) Mode.SignUp else Mode.SignIn) },
            Modifier.align(Alignment.CenterHorizontally),
        ) {
            Text(if (mode == Mode.SignIn) "New here? Create an account" else "Already have an account? Sign in")
        }
    }
}

@Composable
fun VerifyEmailScreen(email: String, vm: AuthViewModel) {
    val form by vm.form.collectAsStateWithLifecycle()
    Column(
        Modifier.fillMaxSize().systemBarsPadding().verticalScroll(rememberScrollState()).padding(Space.l),
        verticalArrangement = Arrangement.spacedBy(Space.m, Alignment.CenterVertically),
    ) {
        WarmthRing(0.5f, diameter = 56.dp)
        Text("Verify your email", style = MaterialTheme.typography.headlineMedium)
        Text("We sent a verification link to $email. Open it, then come back and tap the button below.",
            style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
        form.error?.let { MessageBanner(it, isError = true) }
        form.info?.let { MessageBanner(it, isError = false) }
        PrimaryButton("I've verified my email", onClick = vm::checkVerified, loading = form.busy)
        OutlinedButton(onClick = vm::resendVerification, enabled = !form.busy, modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp)) {
            Text("Resend email")
        }
        TextButton(onClick = vm::signOut, Modifier.align(Alignment.CenterHorizontally)) { Text("Use a different account") }
    }
}
