package com.daniyal.client.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.daniyal.client.domain.LegalDoc
import com.daniyal.client.domain.Validators
import com.daniyal.client.ui.AuthViewModel
import com.daniyal.client.ui.UserInfo
import com.daniyal.client.ui.components.FormField
import com.daniyal.client.ui.components.MessageBanner
import com.daniyal.client.ui.components.PasswordField
import com.daniyal.client.ui.components.SectionTitle
import com.daniyal.client.ui.theme.Space

@Composable
fun SettingsScreen(user: UserInfo, vm: AuthViewModel, onOpenLegal: (LegalDoc) -> Unit) {
    val form by vm.form.collectAsStateWithLifecycle()
    val context = LocalContext.current
    var editName by rememberSaveable { mutableStateOf(false) }
    var nameDraft by rememberSaveable { mutableStateOf(user.name) }
    var confirmSignOut by rememberSaveable { mutableStateOf(false) }
    var confirmDelete by rememberSaveable { mutableStateOf(false) }
    var deletePassword by rememberSaveable { mutableStateOf("") }

    // Messages from a previous screen shouldn't linger here.
    LaunchedEffect(Unit) { vm.clearMessages() }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(Space.m), verticalArrangement = Arrangement.spacedBy(Space.s)) {
        Text("Settings", style = MaterialTheme.typography.headlineMedium)
        form.error?.let { MessageBanner(it, isError = true) }
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
            Column(Modifier.padding(Space.m).fillMaxWidth()) {
                Text(user.name, style = MaterialTheme.typography.titleLarge)
                Text(user.email, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                TextButton(onClick = { nameDraft = user.name; editName = true }) { Text("Edit name") }
            }
        }
        SectionTitle("About & legal")
        LegalDoc.entries.forEach { doc ->
            TextButton(onClick = { onOpenLegal(doc) }, Modifier.fillMaxWidth()) { Text(doc.title, Modifier.fillMaxWidth()) }
        }
        HorizontalDivider(Modifier.padding(vertical = Space.s))
        OutlinedButton(onClick = { confirmSignOut = true }, Modifier.fillMaxWidth()) { Text("Sign out") }
        TextButton(onClick = { deletePassword = ""; vm.clearMessages(); confirmDelete = true }, Modifier.fillMaxWidth()) {
            Text("Delete account", color = MaterialTheme.colorScheme.error)
        }
    }

    if (editName) {
        val err = Validators.name(nameDraft)
        AlertDialog(
            onDismissRequest = { editName = false },
            title = { Text("Edit name") },
            text = { FormField(nameDraft, { nameDraft = it }, "Name", error = if (nameDraft.isNotEmpty()) err else null, imeAction = ImeAction.Done) },
            confirmButton = { TextButton(enabled = err == null && !form.busy, onClick = { vm.updateName(nameDraft); editName = false }) { Text("Save") } },
            dismissButton = { TextButton(onClick = { editName = false }) { Text("Cancel") } },
        )
    }
    if (confirmSignOut) {
        AlertDialog(
            onDismissRequest = { confirmSignOut = false },
            title = { Text("Sign out?") },
            text = { Text("You can sign back in any time. Your people stay saved to your account.") },
            confirmButton = { TextButton(onClick = { confirmSignOut = false; vm.signOut() }) { Text("Sign out") } },
            dismissButton = { TextButton(onClick = { confirmSignOut = false }) { Text("Cancel") } },
        )
    }
    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { if (!form.busy) confirmDelete = false },
            title = { Text("Delete your account?") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(Space.s)) {
                    Text("This permanently deletes your account and every person you've saved. It can't be undone. For your security you must confirm it's you.")
                    form.error?.let { MessageBanner(it, isError = true) }
                    if (user.hasPassword) PasswordField(deletePassword, { deletePassword = it }, "Password", imeAction = ImeAction.Done)
                    else Text("You'll be asked to confirm with Google.")
                }
            },
            confirmButton = {
                TextButton(enabled = !form.busy, onClick = { vm.deleteAccount(context, deletePassword) }) {
                    Text(if (form.busy) "Deleting…" else "Delete forever", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = { TextButton(enabled = !form.busy, onClick = { confirmDelete = false }) { Text("Cancel") } },
        )
    }
}
