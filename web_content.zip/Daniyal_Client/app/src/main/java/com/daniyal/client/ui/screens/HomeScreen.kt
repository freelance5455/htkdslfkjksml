package com.daniyal.client.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.clickable
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.painter.ColorPainter
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.daniyal.client.domain.AppContent
import com.daniyal.client.domain.Person
import com.daniyal.client.domain.Warmth
import com.daniyal.client.ui.MainViewModel
import com.daniyal.client.ui.PeopleState
import com.daniyal.client.ui.UserInfo
import com.daniyal.client.ui.components.DraftSheet
import com.daniyal.client.ui.components.SectionTitle
import com.daniyal.client.ui.components.StateMessage
import com.daniyal.client.ui.theme.Space

@Composable
fun HomeScreen(user: UserInfo, content: AppContent, state: PeopleState, vm: MainViewModel, onAdd: () -> Unit, onOpen: (String) -> Unit) {
    val now = System.currentTimeMillis()
    val toReach = Warmth.nextToReach(state.people, now)
    var draftFor by rememberSaveable { mutableStateOf<String?>(null) }
    val haptic = LocalHapticFeedback.current

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(Space.m), verticalArrangement = Arrangement.spacedBy(Space.s)) {
        item {
            Text("Hello, ${user.name.substringBefore(' ')}", style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(content.homeTitle, style = MaterialTheme.typography.displaySmall)
            Text(content.homeSubtitle, Modifier.padding(top = Space.xs), style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (content.bannerEnabled && content.bannerText.isNotBlank()) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
                    Text(content.bannerText, Modifier.padding(Space.m), style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSecondaryContainer)
                }
            }
        }
        if (content.heroImageUrl.isNotBlank()) {
            item {
                AsyncImage(
                    model = content.heroImageUrl,
                    contentDescription = content.heroAlt.ifBlank { null },
                    placeholder = ColorPainter(MaterialTheme.colorScheme.surfaceVariant),
                    error = ColorPainter(MaterialTheme.colorScheme.surfaceVariant),
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxWidth().height(160.dp).clip(MaterialTheme.shapes.large),
                )
            }
        }
        item { SectionTitle("To reach today") }
        when {
            state.loading -> item { Box(Modifier.fillMaxWidth().padding(Space.l), contentAlignment = Alignment.Center) { CircularProgressIndicator() } }
            state.error != null -> item {
                StateMessage("Can't reach your people", state.error) { OutlinedButton(onClick = vm::retry) { Text("Try again") } }
            }
            state.people.isEmpty() -> item {
                StateMessage("Nobody yet", content.emptyStateText) { FilledTonalButton(onClick = onAdd) { Text("Add someone") } }
            }
            toReach.isEmpty() -> item {
                StateMessage("Everyone is warm", "No one needs a nudge right now. Enjoy it.")
            }
            else -> items(toReach, key = { it.id }) { p -> ReachCard(p, now, onOpen = { onOpen(p.id) }, onDraft = { draftFor = p.id }, onReached = {
                haptic.performHapticFeedback(HapticFeedbackType.LongPress); vm.markReached(p)
            }) }
        }
    }
    state.people.firstOrNull { it.id == draftFor }?.let { DraftSheet(it) { draftFor = null } }
}

@Composable
private fun ReachCard(p: Person, now: Long, onOpen: () -> Unit, onDraft: () -> Unit, onReached: () -> Unit) {
    val w = Warmth.of(p, now)
    Card(Modifier.fillMaxWidth().clickable(onClick = onOpen), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
        Column(Modifier.padding(Space.m), verticalArrangement = Arrangement.spacedBy(Space.s)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(Space.m)) {
                PersonRing(p, now, diameter = 64.dp)
                Column(Modifier.weight(1f)) {
                    Text(p.name, style = MaterialTheme.typography.titleLarge)
                    Text("${Warmth.label(w)} · ${Warmth.daysSince(p, now)} days since you were in touch", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(Space.s)) {
                FilledTonalButton(onClick = onDraft) { Text("Draft message") }
                TextButton(onClick = onReached) { Text("I reached out") }
            }
        }
    }
}
