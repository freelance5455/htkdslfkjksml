package com.daniyal.client.data

import com.daniyal.client.domain.Person
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

/** People live at users/{uid}/people/{id}; security rules restrict access to the owning user. */
class PeopleRepository(private val db: FirebaseFirestore) {

    private fun col(uid: String) = db.collection("users").document(uid).collection("people")

    fun observe(uid: String): Flow<List<Person>> = callbackFlow {
        val registration = col(uid).addSnapshotListener { snap, err ->
            if (err != null) {
                close(err)
                return@addSnapshotListener
            }
            if (snap != null) {
                trySend(snap.documents.map { d ->
                    Person(
                        id = d.id,
                        name = d.getString("name").orEmpty(),
                        note = d.getString("note").orEmpty(),
                        lastContactMillis = d.getLong("lastContactMillis") ?: 0L,
                        cadenceDays = (d.getLong("cadenceDays") ?: 30L).toInt(),
                        createdAtMillis = d.getLong("createdAtMillis") ?: 0L,
                    )
                })
            }
        }
        awaitClose { registration.remove() }
    }

    // Writes are not awaited: Firestore applies them to the local cache immediately and syncs when online.
    fun add(uid: String, person: Person) {
        col(uid).add(
            mapOf(
                "name" to person.name.trim(),
                "note" to person.note.trim(),
                "lastContactMillis" to person.lastContactMillis,
                "cadenceDays" to person.cadenceDays.toLong(),
                "createdAtMillis" to person.createdAtMillis,
            )
        )
    }

    fun markReached(uid: String, id: String, nowMillis: Long) {
        col(uid).document(id).update("lastContactMillis", nowMillis)
    }

    fun delete(uid: String, id: String) {
        col(uid).document(id).delete()
    }

    suspend fun deleteAll(uid: String) {
        val snap = col(uid).get().await()
        snap.documents.chunked(400).forEach { chunk ->
            val batch = db.batch()
            chunk.forEach { batch.delete(it.reference) }
            batch.commit().await()
        }
    }
}
