package com.daniyal.client.data

import com.google.firebase.auth.EmailAuthProvider
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.UserProfileChangeRequest
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

class AuthRepository(private val auth: FirebaseAuth) {

    val user: Flow<FirebaseUser?> = callbackFlow {
        val listener = FirebaseAuth.AuthStateListener { trySend(it.currentUser) }
        auth.addAuthStateListener(listener)
        awaitClose { auth.removeAuthStateListener(listener) }
    }

    val current: FirebaseUser? get() = auth.currentUser

    val hasPassword: Boolean
        get() = current?.providerData?.any { it.providerId == EmailAuthProvider.PROVIDER_ID } == true

    suspend fun signIn(email: String, password: String) {
        auth.signInWithEmailAndPassword(email.trim(), password).await()
    }

    suspend fun signUp(email: String, password: String, name: String) {
        val user = auth.createUserWithEmailAndPassword(email.trim(), password).await().user
            ?: throw UserFacingError(AuthErrors.GENERIC)
        user.updateProfile(UserProfileChangeRequest.Builder().setDisplayName(name.trim()).build()).await()
        user.sendEmailVerification().await()
    }

    suspend fun signInWithGoogle(idToken: String) {
        auth.signInWithCredential(GoogleAuthProvider.getCredential(idToken, null)).await()
    }

    suspend fun sendPasswordReset(email: String) {
        auth.sendPasswordResetEmail(email.trim()).await()
    }

    suspend fun resendVerification() {
        current?.sendEmailVerification()?.await()
    }

    suspend fun reload() {
        current?.reload()?.await()
    }

    suspend fun updateName(name: String) {
        val u = current ?: throw UserFacingError("You're signed out.")
        u.updateProfile(UserProfileChangeRequest.Builder().setDisplayName(name.trim()).build()).await()
        u.reload().await()
    }

    suspend fun reauthenticateWithPassword(password: String) {
        val u = current ?: throw UserFacingError("You're signed out.")
        val email = u.email ?: throw UserFacingError(AuthErrors.GENERIC)
        u.reauthenticate(EmailAuthProvider.getCredential(email, password)).await()
    }

    suspend fun reauthenticateWithGoogle(idToken: String) {
        val u = current ?: throw UserFacingError("You're signed out.")
        u.reauthenticate(GoogleAuthProvider.getCredential(idToken, null)).await()
    }

    suspend fun deleteAccount() {
        val u = current ?: throw UserFacingError("You're signed out.")
        u.delete().await()
    }

    fun signOut() = auth.signOut()
}
