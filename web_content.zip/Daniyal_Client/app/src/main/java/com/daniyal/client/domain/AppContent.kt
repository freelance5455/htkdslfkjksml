package com.daniyal.client.domain

/** Remotely managed copy and imagery. Everything has a bundled default so the app works offline. */
data class AppContent(
    val homeTitle: String,
    val homeSubtitle: String,
    val welcomeMessage: String,
    val bannerText: String,
    val bannerEnabled: Boolean,
    val emptyStateText: String,
    val aboutText: String,
    val heroImageUrl: String?,
    val heroAlt: String,
) {
    companion object {
        val Default = AppContent(
            homeTitle = "Who needs a hello?",
            homeSubtitle = "A few people, gently nudged.",
            welcomeMessage = "Keep the people who matter within reach.",
            bannerText = "",
            bannerEnabled = false,
            emptyStateText = "Add the people you care about and Kept will show who is drifting.",
            aboutText = "",
            heroImageUrl = null,
            heroAlt = "",
        )
    }
}

object ContentParser {
    private const val IMAGE_PREFIX = "https://firebasestorage.googleapis.com/"

    /** Text is rendered as plain text only; image URLs must point at Firebase Storage over HTTPS. */
    fun fromMap(m: Map<String, Any?>): AppContent {
        val d = AppContent.Default
        fun str(key: String, max: Int, fallback: String): String =
            (m[key] as? String)?.trim()?.take(max)?.takeIf { it.isNotEmpty() } ?: fallback
        val image = (m["heroImageUrl"] as? String)?.trim()?.takeIf { it.startsWith(IMAGE_PREFIX) && it.length <= 2048 }
        return AppContent(
            homeTitle = str("homeTitle", 80, d.homeTitle),
            homeSubtitle = str("homeSubtitle", 160, d.homeSubtitle),
            welcomeMessage = str("welcomeMessage", 200, d.welcomeMessage),
            bannerText = str("bannerText", 240, ""),
            bannerEnabled = (m["bannerEnabled"] as? Boolean) ?: false,
            emptyStateText = str("emptyStateText", 240, d.emptyStateText),
            aboutText = str("aboutText", 2000, ""),
            heroImageUrl = image,
            heroAlt = str("heroAlt", 160, ""),
        )
    }
}
