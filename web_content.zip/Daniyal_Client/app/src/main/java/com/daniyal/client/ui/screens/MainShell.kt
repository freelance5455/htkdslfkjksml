package com.daniyal.client.ui.screens

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Today
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.daniyal.client.data.Prefs
import com.daniyal.client.domain.AppContent
import com.daniyal.client.domain.LegalDoc
import com.daniyal.client.ui.AuthViewModel
import com.daniyal.client.ui.MainViewModel
import com.daniyal.client.ui.UserInfo

private data class Tab(val route: String, val label: String, val icon: ImageVector)

private val Tabs = listOf(
    Tab("home", "Today", Icons.Filled.Today),
    Tab("people", "People", Icons.Filled.Group),
    Tab("settings", "Settings", Icons.Filled.Settings),
)

@Composable
fun MainShell(user: UserInfo, authVm: AuthViewModel, content: AppContent, prefs: Prefs, onOpenLegal: (LegalDoc) -> Unit) {
    val vm: MainViewModel = viewModel(key = user.uid, factory = MainViewModel.factory(user.uid))
    val state by vm.state.collectAsStateWithLifecycle()
    val nav = rememberNavController()
    val route = nav.currentBackStackEntryAsState().value?.destination?.route

    Scaffold(
        bottomBar = {
            if (Tabs.any { it.route == route }) {
                NavigationBar {
                    Tabs.forEach { tab ->
                        NavigationBarItem(
                            selected = route == tab.route,
                            onClick = {
                                nav.navigate(tab.route) {
                                    popUpTo("home") { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = { Icon(tab.icon, contentDescription = null) },
                            label = { Text(tab.label) },
                        )
                    }
                }
            }
        },
    ) { padding ->
        NavHost(nav, startDestination = "home", modifier = Modifier.padding(padding)) {
            composable("home") {
                HomeScreen(user, content, state, vm, onAdd = { nav.navigate("add") }, onOpen = { nav.navigate("person/$it") })
            }
            composable("people") {
                PeopleScreen(state, vm, onAdd = { nav.navigate("add") }, onOpen = { nav.navigate("person/$it") })
            }
            composable("add") { AddPersonScreen(prefs.defaultCadence, onSave = { n, note, c -> vm.add(n, note, c); nav.popBackStack() }, onBack = { nav.popBackStack() }) }
            composable("person/{id}") { entry ->
                PersonDetailScreen(entry.arguments?.getString("id").orEmpty(), state, vm, onBack = { nav.popBackStack() })
            }
            composable("settings") { SettingsScreen(user, authVm, onOpenLegal) }
        }
    }
}
