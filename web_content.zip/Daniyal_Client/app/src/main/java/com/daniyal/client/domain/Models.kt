package com.daniyal.client.domain

import java.util.concurrent.TimeUnit

data class Person(
    val id: String = "",
    val name: String = "",
    val note: String = "",
    val lastContactMillis: Long = 0L,
    val cadenceDays: Int = 30,
    val createdAtMillis: Long = 0L,
)

/** "Warmth" is how much of a person's chosen rhythm is left: 1.0 = just in touch, 0.0 = overdue. */
object Warmth {
    fun of(person: Person, nowMillis: Long): Float {
        val cadence = TimeUnit.DAYS.toMillis(person.cadenceDays.coerceAtLeast(1).toLong())
        val elapsed = (nowMillis - person.lastContactMillis).coerceAtLeast(0L)
        return (1f - elapsed.toFloat() / cadence.toFloat()).coerceIn(0f, 1f)
    }

    fun daysSince(person: Person, nowMillis: Long): Int =
        TimeUnit.MILLISECONDS.toDays((nowMillis - person.lastContactMillis).coerceAtLeast(0L)).toInt()

    fun label(warmth: Float): String = when {
        warmth > 0.66f -> "Warm"
        warmth > 0.33f -> "Cooling"
        warmth > 0f -> "Fading"
        else -> "Gone quiet"
    }

    /** The people most worth reaching today: the coolest first, only those below the "warm" band. */
    fun nextToReach(people: List<Person>, nowMillis: Long, limit: Int = 3): List<Person> =
        people.filter { of(it, nowMillis) <= 0.66f }
            .sortedBy { of(it, nowMillis) }
            .take(limit)

    fun cadenceLabel(days: Int): String = when (days) {
        7 -> "Weekly"
        14 -> "Every two weeks"
        30 -> "Monthly"
        90 -> "Quarterly"
        else -> "Every $days days"
    }
}

enum class Tone(val label: String) {
    Warm("Warm"),
    Brief("Brief"),
    AfterSilence("After a long silence"),
}

object DraftBuilder {
    fun build(person: Person, tone: Tone, daysSince: Int): String {
        val first = person.name.trim().substringBefore(' ').ifBlank { "there" }
        return when (tone) {
            Tone.Warm -> "Hi $first, you crossed my mind today and I wanted to say hello. How have you been?"
            Tone.Brief -> "Hi $first, quick hello. How are things with you?"
            Tone.AfterSilence ->
                if (daysSince >= 60) {
                    "Hi $first, it has been far too long, and that is on me. I would love to hear how you are. Are you free for a catch-up soon?"
                } else {
                    "Hi $first, it has been a little while. I have been meaning to reach out. How are you doing?"
                }
        }
    }
}

object Validators {
    private val EMAIL = Regex("^[A-Za-z0-9._%+-]+@[A-Za-z0-9-]+(\\.[A-Za-z0-9-]+)*\\.[A-Za-z]{2,}$")

    fun email(value: String): String? {
        val t = value.trim()
        return when {
            t.isEmpty() -> "Enter your email address."
            !EMAIL.matches(t) -> "Enter a valid email address."
            else -> null
        }
    }

    fun password(value: String): String? = when {
        value.length < 8 -> "Use at least 8 characters."
        value.none { it.isLetter() } -> "Include at least one letter."
        value.none { it.isDigit() } -> "Include at least one number."
        else -> null
    }

    fun signInPassword(value: String): String? =
        if (value.isEmpty()) "Enter your password." else null

    fun confirm(password: String, confirmation: String): String? =
        if (password != confirmation) "Passwords don't match." else null

    fun name(value: String): String? {
        val t = value.trim()
        return when {
            t.isEmpty() -> "Enter a name."
            t.length > 60 -> "Keep it under 60 characters."
            else -> null
        }
    }

    fun note(value: String): String? =
        if (value.trim().length > 280) "Keep notes under 280 characters." else null
}

fun cadenceLabel(days: Int): String = Warmth.cadenceLabel(days)
