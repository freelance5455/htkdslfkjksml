package com.daniyal.client.ui

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.daniyal.client.data.AuthErrors
import com.daniyal.client.data.AuthRepository
import com.daniyal.client.data.GoogleSignIn
import com.daniyal.client.data.PeopleRepository
import com.daniyal.client.data.UserFacingError
import com.daniyal.client.domain.Validators
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class UserInfo(val uid: String, val name: String, val email: String, val hasPassword: Boolean)

sealed interface Session {
    data object Loading : Session
    data object SignedOut : Session
    data class NeedsVerification(val email: String) : Session
    data class SignedIn(val user: UserInfo) : Session
}

data class FormState(val busy: Boolean = false, val error: String? = null, val info: String? = null)

class AuthViewModel(
    private val repo: AuthRepository,
    private val people: PeopleRepository,
) : ViewModel() {

    private val refresh = MutableStateFlow(0)

    val session: StateFlow<Session> = combine(repo.user, refresh) { user, _ -> map(user) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), Session.Loading)

    private val _form = MutableStateFlow(FormState())
    val form: StateFlow<FormState> = _form

    private fun map(u: FirebaseUser?): Session {
        if (u == null) return Session.SignedOut
        val hasPassword = u.providerData.any { it.providerId == "password" }
        val email = u.email.orEmpty()
        if (hasPassword && !u.isEmailVerified) return Session.NeedsVerification(email)
        return Session.SignedIn(
            UserInfo(u.uid, u.displayName?.takeIf { it.isNotBlank() } ?: email.substringBefore('@'), email, hasPassword)
        )
    }

    fun clearMessages() { _form.value = FormState() }

    /** Runs [block] once at a time, so a double tap can never submit twice. */
    private fun run(block: suspend () -> Unit) {
        if (_form.value.busy) return
        _form.value = FormState(busy = true)
        viewModelScope.launch {
            try {
                block()
                _form.update { it.copy(busy = false) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _form.value = FormState(error = AuthErrors.message(e))
            }
        }
    }

    private fun fail(message: String): Nothing = throw UserFacingError(message)

    fun signIn(email: String, password: String) = run {
        Validators.email(email)?.let { fail(it) }
        Validators.signInPassword(password)?.let { fail(it) }
        repo.signIn(email, password)
    }

    fun signUp(name: String, email: String, password: String, confirm: String, acceptedTerms: Boolean) = run {
        Validators.name(name)?.let { fail(it) }
        Validators.email(email)?.let { fail(it) }
        Validators.password(password)?.let { fail(it) }
        Validators.confirm(password, confirm)?.let { fail(it) }
        if (!acceptedTerms) fail("Please accept the Terms of Service and Privacy Policy to create an account.")
        repo.signUp(email, password, name)
    }

    fun signInWithGoogle(context: Context) = run {
        repo.signInWithGoogle(GoogleSignIn.fetchIdToken(context))
    }

    fun sendReset(email: String) = run {
        Validators.email(email)?.let { fail(it) }
        repo.sendPasswordReset(email)
        _form.update { it.copy(info = "If an account exists for that email, a reset link is on its way.") }
    }

    fun resendVerification() = run {
        repo.resendVerification()
        _form.update { it.copy(info = "Verification email sent. Check your inbox and spam folder.") }
    }

    fun checkVerified() = run {
        repo.reload()
        refresh.update { it + 1 }
        if (repo.current?.isEmailVerified != true) {
            _form.update { it.copy(info = "Not verified yet. Open the link in the email, then try again.") }
        }
    }

    fun updateName(name: String) = run {
        Validators.name(name)?.let { fail(it) }
        repo.updateName(name)
        refresh.update { it + 1 }
    }

    fun signOut() {
        repo.signOut()
        clearMessages()
    }

    /** Re-authenticates first, removes the user's saved people, then deletes the account. */
    fun deleteAccount(context: Context, password: String) = run {
        val uid = repo.current?.uid ?: fail("You're signed out. Please sign in again.")
        if (repo.hasPassword) {
            if (password.isEmpty()) fail("Enter your password to confirm.")
            repo.reauthenticateWithPassword(password)
        } else {
            repo.reauthenticateWithGoogle(GoogleSignIn.fetchIdToken(context))
        }
        try {
            people.deleteAll(uid)
            repo.deleteAccount()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            if (repo.current != null) {
                fail("We couldn't finish deleting your account, so it is still active. ${AuthErrors.message(e)}")
            }
        }
    }

    companion object {
        val Factory = viewModelFactory {
            initializer {
                AuthViewModel(
                    AuthRepository(FirebaseAuth.getInstance()),
                    PeopleRepository(FirebaseFirestore.getInstance()),
                )
            }
        }
    }
}
