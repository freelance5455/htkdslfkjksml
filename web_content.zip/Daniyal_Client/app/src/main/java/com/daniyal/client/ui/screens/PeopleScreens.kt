package com.daniyal.client.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.horizontalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import com.daniyal.client.domain.Person
import com.daniyal.client.domain.Validators
import com.daniyal.client.domain.Warmth
import com.daniyal.client.domain.cadenceLabel
import com.daniyal.client.ui.MainViewModel
import com.daniyal.client.ui.PeopleState
import com.daniyal.client.ui.components.DraftSheet
import com.daniyal.client.ui.components.FormField
import com.daniyal.client.ui.components.PrimaryButton
import com.daniyal.client.ui.components.StateMessage
import com.daniyal.client.ui.components.WarmthRing
import com.daniyal.client.ui.theme.Space
import java.text.DateFormat
import java.util.Date

private fun sinceText(days: Int) = when (days) { 0 -> "In touch today"; 1 -> "Last in touch yesterday"; else -> "Last in touch $days days ago" }

@Composable
fun PersonRing(person: Person, now: Long, diameter: androidx.compose.ui.unit.Dp = 56.dp) {
    WarmthRing(Warmth.of(person, now), diameter = diameter) {
        Text(person.name.trim().take(1).uppercase(), style = MaterialTheme.typography.titleMedium)
    }
}

@Composable
fun PeopleScreen(state: PeopleState, vm: MainViewModel, onAdd: () -> Unit, onOpen: (String) -> Unit) {
    val now = System.currentTimeMillis()
    Box(Modifier.fillMaxSize()) {
        when {
            state.loading -> CircularProgressIndicator(Modifier.align(Alignment.Center))
            state.error != null -> StateMessage("Can't reach your people", state.error, Modifier.align(Alignment.Center)) {
                OutlinedButton(onClick = vm::retry) { Text("Try again") }
            }
            state.people.isEmpty() -> StateMessage("No one here yet", "Add someone to start keeping in touch.", Modifier.align(Alignment.Center))
            else -> LazyColumn(contentPadding = PaddingValues(Space.m, Space.m, Space.m, 96.dp), verticalArrangement = Arrangement.spacedBy(Space.s)) {
                item { Text("People", style = MaterialTheme.typography.headlineMedium, modifier = Modifier.padding(bottom = Space.s)) }
                items(state.people.sortedBy { Warmth.of(it, now) }, key = { it.id }) { p ->
                    Card(Modifier.fillMaxWidth().clickable { onOpen(p.id) }, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                        Row(Modifier.padding(Space.m), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(Space.m)) {
                            PersonRing(p, now)
                            Column(Modifier.weight(1f)) {
                                Text(p.name, style = MaterialTheme.typography.titleMedium)
                                Text("${Warmth.label(Warmth.of(p, now))} · ${sinceText(Warmth.daysSince(p, now))}", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }
        }
        FloatingActionButton(onClick = onAdd, modifier = Modifier.align(Alignment.BottomEnd).padding(Space.m)) {
            Icon(Icons.Filled.Add, contentDescription = "Add person")
        }
    }
}

@Composable
fun AddPersonScreen(defaultCadence: Int, onSave: (String, String, Int) -> Unit, onBack: () -> Unit) {
    var name by rememberSaveable { mutableStateOf("") }
    var note by rememberSaveable { mutableStateOf("") }
    var cadence by rememberSaveable { mutableStateOf(defaultCadence) }
    var showErrors by rememberSaveable { mutableStateOf(false) }
    val nameError = if (showErrors) Validators.name(name) else null
    val noteError = Validators.note(note)

    Column(Modifier.fillMaxSize().imePadding().verticalScroll(rememberScrollState()).padding(Space.m), verticalArrangement = Arrangement.spacedBy(Space.s)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back") }
            Text("Add someone", style = MaterialTheme.typography.titleLarge)
        }
        FormField(name, { name = it }, "Name", error = nameError)
        FormField(note, { note = it }, "A note (optional)", error = noteError, singleLine = false, imeAction = ImeAction.Done)
        Text("How often would you like to be in touch?", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = Space.s))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(Space.s)) {
            listOf(7, 14, 30, 90).forEach { d -> FilterChip(selected = cadence == d, onClick = { cadence = d }, label = { Text(cadenceLabel(d)) }) }
        }
        PrimaryButton("Save", onClick = {
            showErrors = true
            if (Validators.name(name) == null && noteError == null) onSave(name.trim(), note.trim(), cadence)
        }, modifier = Modifier.padding(top = Space.m))
    }
}

@Composable
fun PersonDetailScreen(id: String, state: PeopleState, vm: MainViewModel, onBack: () -> Unit) {
    val person = state.people.firstOrNull { it.id == id }
    var showDraft by rememberSaveable { mutableStateOf(false) }
    var confirmDelete by rememberSaveable { mutableStateOf(false) }
    val haptic = LocalHapticFeedback.current

    LaunchedEffect(state.loading, person) { if (!state.loading && person == null) onBack() }
    if (person == null) { Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }; return }
    val now = System.currentTimeMillis()

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(Space.m), verticalArrangement = Arrangement.spacedBy(Space.s)) {
        IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back") }
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(Space.s)) {
            PersonRing(person, now, diameter = 140.dp)
            Text(person.name, style = MaterialTheme.typography.headlineMedium)
            Text("${Warmth.label(Warmth.of(person, now))} · ${sinceText(Warmth.daysSince(person, now))}", color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("Rhythm: ${cadenceLabel(person.cadenceDays)} · last contact ${DateFormat.getDateInstance().format(Date(person.lastContactMillis))}",
                style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (person.note.isNotBlank()) {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                Text(person.note, Modifier.padding(Space.m), style = MaterialTheme.typography.bodyLarge)
            }
        }
        PrimaryButton("I reached out", onClick = { haptic.performHapticFeedback(HapticFeedbackType.LongPress); vm.markReached(person) }, modifier = Modifier.padding(top = Space.m))
        FilledTonalButton(onClick = { showDraft = true }, Modifier.fillMaxWidth()) { Text("Draft a message") }
        TextButton(onClick = { confirmDelete = true }, Modifier.align(Alignment.CenterHorizontally)) {
            Text("Remove ${person.name}", color = MaterialTheme.colorScheme.error)
        }
    }
    if (showDraft) DraftSheet(person) { showDraft = false }
    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Remove ${person.name}?") },
            text = { Text("This permanently deletes this person and their note from your account.") },
            confirmButton = { TextButton(onClick = { confirmDelete = false; vm.delete(person) }) { Text("Remove") } },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancel") } },
        )
    }
}
