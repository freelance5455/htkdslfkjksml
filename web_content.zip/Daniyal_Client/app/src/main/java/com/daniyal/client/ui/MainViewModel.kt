package com.daniyal.client.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.daniyal.client.data.ContentRepository
import com.daniyal.client.data.PeopleRepository
import com.daniyal.client.domain.AppContent
import com.daniyal.client.domain.Person
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.onStart
import kotlinx.coroutines.flow.stateIn

data class PeopleState(
    val loading: Boolean = true,
    val people: List<Person> = emptyList(),
    val error: String? = null,
)

class ContentViewModel(repo: ContentRepository) : ViewModel() {
    val content: StateFlow<AppContent> = repo.observe()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), AppContent.Default)

    companion object {
        val Factory = viewModelFactory {
            initializer { ContentViewModel(ContentRepository(FirebaseFirestore.getInstance())) }
        }
    }
}

class MainViewModel(
    private val uid: String,
    private val people: PeopleRepository,
) : ViewModel() {

    private val retry = MutableStateFlow(0)

    @OptIn(ExperimentalCoroutinesApi::class)
    val state: StateFlow<PeopleState> = retry.flatMapLatest {
        people.observe(uid)
            .map { PeopleState(loading = false, people = it) }
            .catch { emit(PeopleState(loading = false, error = "Couldn't load your people. Check your connection and try again.")) }
            .onStart { emit(PeopleState()) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), PeopleState())

    fun retry() { retry.value += 1 }

    fun add(name: String, note: String, cadenceDays: Int) {
        val now = System.currentTimeMillis()
        people.add(uid, Person(name = name, note = note, lastContactMillis = now, cadenceDays = cadenceDays, createdAtMillis = now))
    }

    fun markReached(person: Person) = people.markReached(uid, person.id, System.currentTimeMillis())

    fun delete(person: Person) = people.delete(uid, person.id)

    companion object {
        fun factory(uid: String) = viewModelFactory {
            initializer { MainViewModel(uid, PeopleRepository(FirebaseFirestore.getInstance())) }
        }
    }
}
