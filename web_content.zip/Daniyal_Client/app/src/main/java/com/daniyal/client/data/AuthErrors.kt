package com.daniyal.client.data

import com.google.firebase.FirebaseNetworkException
import com.google.firebase.auth.FirebaseAuthException

/** An error whose message is already safe and friendly to show to the user. */
class UserFacingError(message: String) : Exception(message)

object AuthErrors {
    const val GENERIC = "Something went wrong. Please try again."

    fun message(e: Throwable): String = when {
        e is UserFacingError -> e.message ?: GENERIC
        e is FirebaseNetworkException -> "No connection. Check your internet and try again."
        e is FirebaseAuthException -> when (e.errorCode) {
            "ERROR_INVALID_EMAIL" -> "That email address doesn't look right."
            "ERROR_WRONG_PASSWORD", "ERROR_INVALID_CREDENTIAL", "ERROR_USER_NOT_FOUND" ->
                "Email or password is incorrect."
            "ERROR_EMAIL_ALREADY_IN_USE" -> "An account with this email already exists. Try signing in."
            "ERROR_WEAK_PASSWORD" -> "Choose a stronger password (8+ characters with a letter and a number)."
            "ERROR_TOO_MANY_REQUESTS" -> "Too many attempts. Wait a moment and try again."
            "ERROR_USER_DISABLED" -> "This account has been disabled."
            "ERROR_REQUIRES_RECENT_LOGIN" -> "For your security, please sign in again and retry."
            "ERROR_USER_TOKEN_EXPIRED" -> "Your session expired. Please sign in again."
            else -> GENERIC
        }
        else -> GENERIC
    }
}
