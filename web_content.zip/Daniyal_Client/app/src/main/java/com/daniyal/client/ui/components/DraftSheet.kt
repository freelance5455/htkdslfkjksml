package com.daniyal.client.ui.components

import android.content.Intent
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import com.daniyal.client.domain.DraftBuilder
import com.daniyal.client.domain.Person
import com.daniyal.client.domain.Tone
import com.daniyal.client.domain.Warmth
import com.daniyal.client.ui.theme.Space

/** Suggests a message in a chosen tone. The text is only a starting point; nothing is sent by the app. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DraftSheet(person: Person, onDismiss: () -> Unit) {
    var tone by remember { mutableStateOf(Tone.Warm) }
    val days = Warmth.daysSince(person, System.currentTimeMillis())
    val text = DraftBuilder.build(person, tone, days)
    val clipboard = LocalClipboardManager.current
    val context = LocalContext.current

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            Modifier.padding(horizontal = Space.l).padding(bottom = Space.l).navigationBarsPadding(),
            verticalArrangement = Arrangement.spacedBy(Space.m),
        ) {
            Text("Message for ${person.name}", style = MaterialTheme.typography.titleLarge)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(Space.s)) {
                Tone.entries.forEach {
                    FilterChip(selected = tone == it, onClick = { tone = it }, label = { Text(it.label) })
                }
            }
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                Text(text, Modifier.padding(Space.m), style = MaterialTheme.typography.bodyLarge)
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(Space.s)) {
                OutlinedButton(onClick = { clipboard.setText(AnnotatedString(text)) }, modifier = Modifier.weight(1f)) {
                    Text("Copy")
                }
                OutlinedButton(
                    onClick = {
                        val send = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_TEXT, text)
                        }
                        context.startActivity(Intent.createChooser(send, null))
                    },
                    modifier = Modifier.weight(1f),
                ) { Text("Share") }
            }
        }
    }
}
