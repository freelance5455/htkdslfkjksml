package com.daniyal.client.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.daniyal.client.data.Prefs
import com.daniyal.client.domain.LegalDoc
import com.daniyal.client.ui.screens.AuthScreen
import com.daniyal.client.ui.screens.LegalScreen
import com.daniyal.client.ui.screens.MainShell
import com.daniyal.client.ui.screens.OnboardingScreen
import com.daniyal.client.ui.screens.VerifyEmailScreen

@Composable
fun KeptApp() {
    val context = LocalContext.current
    val prefs = remember { Prefs(context) }
    val authVm: AuthViewModel = viewModel(factory = AuthViewModel.Factory)
    val contentVm: ContentViewModel = viewModel(factory = ContentViewModel.Factory)
    val session by authVm.session.collectAsStateWithLifecycle()
    val content by contentVm.content.collectAsStateWithLifecycle()
    var legal by rememberSaveable { mutableStateOf<LegalDoc?>(null) }
    var onboarded by rememberSaveable { mutableStateOf(prefs.onboarded) }

    Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        when (val s = session) {
            Session.Loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            Session.SignedOut ->
                if (!onboarded) {
                    OnboardingScreen(prefs, content.welcomeMessage) { prefs.onboarded = true; onboarded = true }
                } else {
                    AuthScreen(authVm) { legal = it }
                }
            is Session.NeedsVerification -> VerifyEmailScreen(s.email, authVm)
            is Session.SignedIn -> MainShell(s.user, authVm, content, prefs) { legal = it }
        }
        legal?.let { doc ->
            LegalScreen(doc, extraIntro = if (doc == LegalDoc.About) content.aboutText else "") { legal = null }
        }
    }
}

@Composable
fun ConfigMissingScreen() {
    Column(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).systemBarsPadding().padding(24.dp),
        verticalArrangement = Arrangement.Center,
    ) {
        Text("Firebase isn't configured", style = MaterialTheme.typography.headlineSmall)
        Text(
            "This build has no google-services.json for daniyal.client.app. Register the Android app in Firebase, " +
                "download the file, place it at app/google-services.json and rebuild. See the README.",
            Modifier.padding(top = 12.dp), style = MaterialTheme.typography.bodyLarge,
        )
    }
}
