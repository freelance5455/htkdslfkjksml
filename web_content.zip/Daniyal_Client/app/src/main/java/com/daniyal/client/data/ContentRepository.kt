package com.daniyal.client.data

import com.daniyal.client.domain.AppContent
import com.daniyal.client.domain.ContentParser
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow

/**
 * Streams the published remote content (app_content/published).
 * Firestore's on-device cache keeps the last published version available offline;
 * on errors the previous value is kept and bundled defaults are used if nothing was ever loaded.
 */
class ContentRepository(private val db: FirebaseFirestore) {
    fun observe(): Flow<AppContent> = callbackFlow {
        val registration = db.document("app_content/published").addSnapshotListener { snap, err ->
            if (err != null || snap == null) return@addSnapshotListener
            trySend(if (snap.exists()) ContentParser.fromMap(snap.data.orEmpty()) else AppContent.Default)
        }
        awaitClose { registration.remove() }
    }
}
