package com.daniyal.client.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Light = lightColorScheme(
    primary = Color(0xFF1F4E4A), onPrimary = Color.White,
    primaryContainer = Color(0xFFCFE6E1), onPrimaryContainer = Color(0xFF0B2A27),
    secondary = Color(0xFFA84B28), onSecondary = Color.White,
    secondaryContainer = Color(0xFFFADBCB), onSecondaryContainer = Color(0xFF3B1608),
    background = Color(0xFFF8F4EC), onBackground = Color(0xFF1B1C1A),
    surface = Color(0xFFF8F4EC), onSurface = Color(0xFF1B1C1A),
    surfaceVariant = Color(0xFFE9E4D8), onSurfaceVariant = Color(0xFF4A4C47),
    outline = Color(0xFF6F726A), error = Color(0xFFB3261E),
)

private val Dark = darkColorScheme(
    primary = Color(0xFF8FCFC6), onPrimary = Color(0xFF00201D),
    primaryContainer = Color(0xFF1F4E4A), onPrimaryContainer = Color(0xFFCFE6E1),
    secondary = Color(0xFFFFB596), onSecondary = Color(0xFF561F06),
    secondaryContainer = Color(0xFF7A3517), onSecondaryContainer = Color(0xFFFADBCB),
    background = Color(0xFF121614), onBackground = Color(0xFFE4E3DD),
    surface = Color(0xFF121614), onSurface = Color(0xFFE4E3DD),
    surfaceVariant = Color(0xFF2A2F2C), onSurfaceVariant = Color(0xFFC3C8C0),
    outline = Color(0xFF8D928A), error = Color(0xFFF2B8B5),
)

private val Serif = FontFamily.Serif

private val KeptTypography = Typography(
    displaySmall = TextStyle(fontFamily = Serif, fontWeight = FontWeight.Medium, fontSize = 34.sp, lineHeight = 40.sp),
    headlineMedium = TextStyle(fontFamily = Serif, fontWeight = FontWeight.Medium, fontSize = 28.sp, lineHeight = 34.sp),
    headlineSmall = TextStyle(fontFamily = Serif, fontWeight = FontWeight.Medium, fontSize = 24.sp, lineHeight = 30.sp),
    titleLarge = TextStyle(fontFamily = Serif, fontWeight = FontWeight.Medium, fontSize = 20.sp, lineHeight = 26.sp),
    titleMedium = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 16.sp, lineHeight = 22.sp),
    bodyLarge = TextStyle(fontSize = 16.sp, lineHeight = 24.sp),
    bodyMedium = TextStyle(fontSize = 14.sp, lineHeight = 21.sp),
    labelLarge = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 14.sp, lineHeight = 20.sp),
)

private val KeptShapes = Shapes(
    small = androidx.compose.foundation.shape.RoundedCornerShape(10.dp),
    medium = androidx.compose.foundation.shape.RoundedCornerShape(16.dp),
    large = androidx.compose.foundation.shape.RoundedCornerShape(24.dp),
)

/** Spacing tokens used across the app. */
object Space {
    val xs = 4.dp
    val s = 8.dp
    val m = 16.dp
    val l = 24.dp
    val xl = 32.dp
}

@Composable
fun KeptTheme(darkTheme: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (darkTheme) Dark else Light,
        typography = KeptTypography,
        shapes = KeptShapes,
        content = content,
    )
}
