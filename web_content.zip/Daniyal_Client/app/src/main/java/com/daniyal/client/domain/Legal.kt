package com.daniyal.client.domain

/** Fill these in before release. They are shown inside the Terms and Privacy Policy. */
object LegalConfig {
    const val OPERATOR_NAME = "SET_YOUR_NAME_OR_COMPANY"
    const val CONTACT_EMAIL = "SET_YOUR_CONTACT_EMAIL"
}

enum class LegalDoc(val title: String) {
    Terms("Terms of Service"),
    Privacy("Privacy Policy"),
    About("About Kept"),
    Licenses("Open-source licenses");
}

data class LegalSection(val heading: String, val body: String)

object LegalContent {
    const val VERSION = "1.0"
    const val EFFECTIVE_DATE = "SET_EFFECTIVE_DATE"

    fun sections(doc: LegalDoc): List<LegalSection> = when (doc) {
        LegalDoc.Terms -> listOf(
            LegalSection("About these terms", """These Terms of Service govern your use of Kept (the app), provided by ${LegalConfig.OPERATOR_NAME}. By creating an account you agree to them. If you do not agree, do not create an account."""),
            LegalSection("What Kept does", """Kept helps you remember to stay in touch with people. You add people, choose how often you want to be in touch, and the app shows who is drifting and offers draft messages. Kept does not send messages for you, and it does not read your contacts, messages, or call history."""),
            LegalSection("Your account", """You can sign up with an email address and password or with your Google account. Email sign-ups must verify their email address before using the app. You are responsible for keeping your credentials secure and for activity under your account. Give accurate information and do not share your account."""),
            LegalSection("Acceptable use", """Use Kept lawfully and for personal purposes. Do not attempt to access other users' data, interfere with the service or its security, reverse engineer it to bypass protections, or use it to harass anyone. Only enter information about other people that you are comfortable storing; do not store sensitive details about them that you have no reason to keep."""),
            LegalSection("Your content", """The names, notes, and dates you enter remain yours. You give ${LegalConfig.OPERATOR_NAME} permission to store and process them solely to run the app for you."""),
            LegalSection("Remote content", """Some text and images in the app (such as headings, banners, and announcements) can be updated by the app owner without releasing a new version. Only the authorized owner can publish such changes."""),
            LegalSection("Ending your account", """You can delete your account at any time in Settings. This removes your saved people and your sign-in account. We may suspend or terminate accounts that breach these terms or put the service at risk."""),
            LegalSection("Availability and changes", """Kept is provided as is, without guarantees of uninterrupted availability. Features may change. To the extent permitted by law, ${LegalConfig.OPERATOR_NAME} is not liable for indirect or consequential loss arising from use of the app. Nothing here limits rights you have under mandatory law."""),
            LegalSection("Changes to these terms", """If these terms change materially, the version number and effective date above will change and you will be asked to review them. Continued use after the effective date means acceptance."""),
            LegalSection("Contact", """Questions about these terms: ${LegalConfig.CONTACT_EMAIL}."""),
        )
        LegalDoc.Privacy -> listOf(
            LegalSection("Who is responsible", """${LegalConfig.OPERATOR_NAME} provides Kept and decides how your data is used. Privacy questions: ${LegalConfig.CONTACT_EMAIL}."""),
            LegalSection("Data we collect and why", """Account data: your email address, display name, sign-in method, and a unique account ID. It is used to create and secure your account and, for email sign-ups, to send verification and password-reset emails.

People you add: the name, optional note, preferred rhythm, and date of last contact you enter. It is used to show warmth rings, suggest who to reach out to, and draft messages.

On your device: a setting recording that you finished onboarding and your default rhythm. This stays on your device.

We do not use advertising or analytics SDKs in this version of the app, and we do not collect your contacts, location, or messages."""),
            LegalSection("Services that process your data", """Firebase Authentication (account sign-in, including Google Sign-In), Cloud Firestore (your people and the app's published content), Firebase Storage (images shown in the app, uploaded only by the owner), and Cloud Functions (owner publishing). These are provided by Google. Google may process technical data such as IP address and device information to operate these services under its own terms and privacy policy."""),
            LegalSection("Security", """Data is sent to Firebase over encrypted connections, and Google states that it encrypts stored data in its services. Access rules ensure each signed-in user can read and write only their own people. No system is perfectly secure, so please use a strong, unique password."""),
            LegalSection("Retention and deletion", """Your data is kept while your account exists. When you delete your account in Settings, your saved people are deleted and your sign-in account is removed. If deletion cannot be completed, the app tells you and your account stays active. Routine backups and service logs held by Google may persist for a limited period before they are deleted under Google's schedules."""),
            LegalSection("Your choices and rights", """You can edit your name, change or delete any person, sign out, and delete your account in the app. Depending on where you live, you may have rights to access, correct, export, or delete your data, or to object to processing; contact ${LegalConfig.CONTACT_EMAIL} to exercise them. There are no optional analytics or marketing choices because none are collected."""),
            LegalSection("Children", """Kept is not directed at children under 13 (or the higher minimum age in your country). Do not create an account if you are below that age."""),
            LegalSection("Remote content", """Published announcements and images are public and are the same for all users. They do not contain your personal data."""),
            LegalSection("Changes to this policy", """Material changes will update the version number and effective date above and be shown in the app."""),
        )
        LegalDoc.About -> listOf(
            LegalSection("Kept", """Kept is a quiet companion for staying in touch. Each person has a warmth ring that slowly cools as time passes, so you can see at a glance who deserves a message today."""),
            LegalSection("Three ideas inside", """Warmth rings show how much of your chosen rhythm is left for each person. The reach list picks the people who need attention first. Message starters draft a gentle note in the tone you choose, which you can copy or share."""),
            LegalSection("Contact", """Feedback and privacy questions: ${LegalConfig.CONTACT_EMAIL}."""),
        )
        LegalDoc.Licenses -> listOf(
            LegalSection("Open-source components", """Kept is built with the following software. Each remains under its own license."""),
            LegalSection("Apache License 2.0", """Jetpack Compose and AndroidX libraries (Google), Kotlin and kotlinx.coroutines (JetBrains), Coil (Coil Contributors). Full text: apache.org/licenses/LICENSE-2.0"""),
            LegalSection("Google services", """Firebase SDKs, Google Play services, Credential Manager, and Google Identity libraries are provided under the Google APIs Terms of Service, the Firebase Terms, and applicable open-source licenses listed at firebase.google.com and developer.android.com."""),
        )
    }
}
