package com.daniyal.client

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.daniyal.client.ui.ConfigMissingScreen
import com.daniyal.client.ui.KeptApp
import com.daniyal.client.ui.theme.KeptTheme
import com.google.firebase.FirebaseApp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        // Firebase initialises itself from google-services.json; if that file is missing, show a setup screen instead of crashing.
        val configured = FirebaseApp.getApps(this).isNotEmpty()
        setContent {
            KeptTheme {
                if (configured) KeptApp() else ConfigMissingScreen()
            }
        }
    }
}
