package com.daniyal.client.data

import android.content.Context

class Prefs(context: Context) {
    private val sp = context.applicationContext.getSharedPreferences("kept_prefs", Context.MODE_PRIVATE)

    var onboarded: Boolean
        get() = sp.getBoolean("onboarded", false)
        set(value) { sp.edit().putBoolean("onboarded", value).apply() }

    var defaultCadence: Int
        get() = sp.getInt("default_cadence", 30)
        set(value) { sp.edit().putInt("default_cadence", value).apply() }
}
