package com.daniyal.client.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import com.daniyal.client.domain.LegalContent
import com.daniyal.client.domain.LegalDoc
import com.daniyal.client.ui.theme.Space

@Composable
fun LegalScreen(doc: LegalDoc, extraIntro: String = "", onBack: () -> Unit) {
    BackHandler(onBack = onBack)
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).systemBarsPadding()) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(horizontal = Space.xs)) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back") }
            Text(doc.title, style = MaterialTheme.typography.titleLarge)
        }
        LazyColumn(contentPadding = PaddingValues(Space.l), verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(Space.m)) {
            item {
                if (doc == LegalDoc.Terms || doc == LegalDoc.Privacy) {
                    Text("Version ${LegalContent.VERSION} · Effective ${LegalContent.EFFECTIVE_DATE}",
                        style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                if (extraIntro.isNotBlank()) Text(extraIntro, Modifier.padding(top = Space.s), style = MaterialTheme.typography.bodyLarge)
            }
            items(LegalContent.sections(doc)) { s ->
                Column {
                    Text(s.heading, style = MaterialTheme.typography.titleMedium)
                    Text(s.body, Modifier.padding(top = Space.xs), style = MaterialTheme.typography.bodyLarge)
                }
            }
        }
    }
}
