package com.daniyal.client.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.background
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.daniyal.client.data.Prefs
import com.daniyal.client.ui.components.PrimaryButton
import com.daniyal.client.ui.components.WarmthRing
import com.daniyal.client.ui.theme.Space
import kotlinx.coroutines.launch

private val Rhythms = listOf("Weekly" to 7, "Every two weeks" to 14, "Monthly" to 30, "Quarterly" to 90)

/** Three pages; the last one adapts the app: the rhythm you pick becomes the default for new people. */
@Composable
fun OnboardingScreen(prefs: Prefs, welcome: String, onDone: () -> Unit) {
    val pager = rememberPagerState(pageCount = { 3 })
    val scope = rememberCoroutineScope()
    var cadence by remember { mutableIntStateOf(prefs.defaultCadence) }

    Column(Modifier.fillMaxSize().systemBarsPadding().padding(Space.l)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            if (pager.currentPage < 2) TextButton(onClick = onDone) { Text("Skip") }
        }
        HorizontalPager(pager, Modifier.weight(1f)) { page ->
            Column(
                Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                when (page) {
                    0 -> {
                        WarmthRing(0.85f, diameter = 140.dp)
                        Text("Kept", Modifier.padding(top = Space.l), style = MaterialTheme.typography.displaySmall)
                        Text(welcome, Modifier.padding(top = Space.s), style = MaterialTheme.typography.bodyLarge,
                            textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    1 -> {
                        Row(horizontalArrangement = Arrangement.spacedBy(Space.m)) {
                            WarmthRing(0.9f, diameter = 76.dp); WarmthRing(0.5f, diameter = 76.dp); WarmthRing(0.12f, diameter = 76.dp)
                        }
                        Text("Every friendship has a warmth", Modifier.padding(top = Space.l),
                            style = MaterialTheme.typography.headlineSmall, textAlign = TextAlign.Center)
                        Text(
                            "A ring slowly empties when you haven't been in touch. Reach out, and it fills again. " +
                                "Kept shows you who is cooling so no one drifts away unnoticed.",
                            Modifier.padding(top = Space.s), style = MaterialTheme.typography.bodyLarge,
                            textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    else -> {
                        Text("How often do you like to be in touch?", style = MaterialTheme.typography.headlineSmall,
                            textAlign = TextAlign.Center)
                        Text("This sets the default rhythm for people you add. You can change it per person.",
                            Modifier.padding(top = Space.s, bottom = Space.l), style = MaterialTheme.typography.bodyLarge,
                            textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Column(verticalArrangement = Arrangement.spacedBy(Space.s), horizontalAlignment = Alignment.CenterHorizontally) {
                            Rhythms.forEach { (label, days) ->
                                FilterChip(selected = cadence == days, onClick = { cadence = days }, label = { Text(label) })
                            }
                        }
                    }
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(vertical = Space.m), horizontalArrangement = Arrangement.Center) {
            repeat(3) { i ->
                Box(
                    Modifier.padding(horizontal = 4.dp).size(if (i == pager.currentPage) 10.dp else 8.dp).background(
                        if (i == pager.currentPage) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline,
                        CircleShape,
                    )
                )
            }
        }
        PrimaryButton(
            text = if (pager.currentPage < 2) "Next" else "Set my rhythm",
            onClick = {
                if (pager.currentPage < 2) scope.launch { pager.animateScrollToPage(pager.currentPage + 1) }
                else { prefs.defaultCadence = cadence; onDone() }
            },
        )
    }
}
