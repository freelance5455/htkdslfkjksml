# TradeSignal AI — V4.6.6 + H5 A×B

## Preservação
O motor V4.6.6 permanece como referência. A nova camada é um laboratório causal separado.

## Novo botão
🧪 TESTE H5 A × B — 3K × 5K × 15K

A: janela 3 / Forte 2 de 3 / Moderado 1 de 3
B: janela 3 / Forte 2 de 3 / Moderado 2 de 3

O teste executa 3k, 5k e 15k sequencialmente e mostra:
- sinais A/B e ΔS
- Δ líquido/op
- Δ Acum.
- Δ DD
- PF Forte A→B
- PF Moderado A→B
- IC-E Forte
- IC-E Moderado
- IC-E Geral
- IC-E-G médio das três rodadas

## Importante
Este arquivo é um projeto Android pronto para compilação. O APK binário precisa ser compilado em um ambiente com Android SDK/Gradle.
