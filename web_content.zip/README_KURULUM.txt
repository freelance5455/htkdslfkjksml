TOFAS PVP - SERBEST MOD / OTOMATIK TARET

Bu ZIP web oyun dosyalarini icerir. APK olusturucunda onceki ZIP yerine bunu kullan.
Serbest Mod: genis duz alan, rampalar, ziplama platformlari ve engeller.
Taret: PVP modunda ATEŞ ET tusuna basinca en yakin bot hedeflenir; serbest modda dusman yoktur.
Not: ZIP dosyasi ve JavaScript sozdizimi kontrol edilebilir; gercek Android APK cihazinda test edilmedi.
Cok oyunculu icin ayri olarak internete acik Socket.IO sunucusu gerekir.
