TOFAŞ PVP — MULTIPLAYER + ARABA MAĞAZASI (PROTOTİP)

İÇERİK
- index.html: mevcut büyük şehir, çift taret ve uçuş iticili prototip; araba mağazası eklendi.
- server.js + package.json: internet üzerinden oyuncu bağlantısı ve oyuncu konumu paylaşımı için Socket.IO sunucusu.

ARABA MAĞAZASI
- Turkuaz Şahin başlangıçta açık.
- Kırmızı, Altın, Mor ve Neon renkli Şahin seçenekleri var.
- Yeni araç: RENAULT TOROS; köşeli sedan gövdesiyle mağazadan 1500 jetona alınabilir. Satın alma/araç seçimi cihazda saklanır.
- Bot devre dışı bırakıldığında 50 jeton kazanılır; satın alma ve seçilen araç aynı cihazdaki tarayıcıda localStorage ile saklanır.
- Şimdilik bunlar farklı renklerdir; ayrı model/performans farkları henüz yok. Arabaların özel tasarımlarını birlikte yapacağız.

MULTIPLAYER'I ÇALIŞTIRMA
1. Bilgisayarında Node.js 18 veya daha yenisi kurulu olmalı.
2. Bu klasörde terminal açıp `npm install` çalıştır.
3. `npm start` çalıştır. Sunucu varsayılan olarak 3000 portunda açılır.
4. Aynı ağda test etmek için diğer cihazda bilgisayarın yerel IP adresini ve :3000 portunu açmayı dene (güvenlik duvarı izin vermeli).
5. İnternet üzerinden farklı ağlardan oynamak için bu klasörü HTTPS destekleyen bir Node.js hostuna dağıt. Hostta `npm install` ve `npm start` kullanılsın. Host sağlayıcısının verdiği HTTPS URL'sini oyun içindeki Multiplayer ekranına yaz.

DÜRÜST DURUM RAPORU
- ZIP tek başına internette herkese açık bir sunucu başlatmaz. Gerçek internet multiplayer için server.js dosyasını çalıştırıp internete dağıtmak gerekir.
- Oda kodu sistemi eklendi: bir oyuncu oda oluşturur, 6 karakterlik kodu arkadaşına gönderir; arkadaş aynı sunucuya bağlanıp kodla katılır. En fazla 8 oyuncu/oda. Aynı odadaki oyuncuların araç konumları ve dönüşleri gösterilir.
- Oyuncuların birbirine hasar vermesi/ateş etmesi, oyuncuların birbirine hasar vermesi/ateş etmesi, hesap sistemi, güvenli sunucu tarafı fizik ve hile koruması henüz eklenmedi.
- Araba mağazası yerel cihazda kayıt tutar; satın almalar cihazlar arasında senkronize değildir.
- Oyun telefonda gerçek cihaz testi görmedi. Üç.js ve bazı istemci dosyaları internet bağlantısı gerektirir.

GÖRSEL GÜNCELLEME
- Sahne gündüz ışığı, açık mavi gökyüzü ve gündüz sisiyle güncellendi.
- Mağazaya oyun içinden erişmek için sağ üstte MAĞAZA düğmesi eklendi.
- Oda koduyla multiplayer için sunucuya bağlan, oda oluştur veya arkadaşının 6 karakterlik kodunu gir.


YENİ SÜRÜM: ROKET YAKITI VE OYUNCU ADI
- Oyuna başlamadan önce oyuncu adı girmek zorunludur (en fazla 16 karakter).
- Multiplayer ekranında da oda oluşturmadan/katılmadan önce oyuncu adı zorunludur. İsim aynı odadaki oyuncu listesi verisine sunucu tarafından aktarılır.
- Roket yakıtı 100% ile başlar. Turbo basılıyken saniyede 24 puan yakıt tüketir; yakıt bitince uçuş iticileri devreye girmez. Yerdeyken turbo kullanılmıyorsa saniyede 10 puan yenilenir. Yakıt göstergesi sol üsttedir.
- Multiplayer’da diğer oyuncuların ve kendi aracının üstünde isim etiketi gösterilir. Şahin/Toros modeli de ağ üzerinden paylaşılır. Multiplayer bağlantısı ve uçuş yakıtı gerçek telefonlarda ayrıca test edilmelidir.


WEBVIEW / APK DÜZELTMESİ (YENİ)
- Three.js kitaplığı geçerli ve eski Android WebView ile uyumlu CDN adresine alındı.
- Socket.IO istemcisi kök dizine bağlı /socket.io/... yolundan çıkarılıp CDN adresine alındı; böylece index.html dosyası WebView içinde açıldığında bozuk yerel yol kullanılmaz.
- Bu sürüm 3D motor ve korna için internet bağlantısı ister. Multiplayer için ayrıca çalışan ve internete erişilebilen server.js sunucusu gerekir.
