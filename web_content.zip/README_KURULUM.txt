TOFAS PVP - KAMERA VE MANUEL NISAN GUNCELLEMESI

Eklenenler:
- Kamera dugmesi: IC / DIS / UZAK gorunumleri arasinda gecis yapar.
- Manuel nisangah joystick'i: Ekranin sag tarafindaki kirmizi joystick ile atis yonunu yatay ve dikey ayarlayabilirsin.
- Ates tusuna basildiginda sentezlenmis kisa silah sesi efekti calar. Ses tarayici tarafindan uretilir; harici ses dosyasina veya internet baglantisina bagli degildir.

Kurulum:
1. Bu ZIP'i APK olusturucuna yukle.
2. Yeni APK olustur ve kur.
3. Oyuna girince sag ustteki KAMERA dugmesiyle gorunumu degistir.
4. Kirmizi NISAN joystick'ini surus joystick'inden ayri kullanarak atis yonunu ayarla, sonra ATEŞ ET dugmesine bas.

Not: ZIP ve JavaScript soz dizimi kontrol edildi; gercek telefonda oyun testi yapilmadi. Ic kamera gorunumu mevcut arac modelinin icine yakin bir kamera konumudur; her aracta kokpit modeli bulunmayabilir. Silah sesi gercek bir kayit degil, oyunda olusturulan kisa bir ses efektidir.
