TOFAŞ PVP — MULTIPLAYER + ARABA MAĞAZASI (PROTOTİP)

İÇERİK
- index.html: mevcut büyük şehir, çift taret ve uçuş iticili prototip; araba mağazası eklendi.
- server.js + package.json: internet üzerinden oyuncu bağlantısı ve oyuncu konumu paylaşımı için Socket.IO sunucusu.

ARABA MAĞAZASI
- Turkuaz Şahin başlangıçta açık.
- Kırmızı, Altın, Mor ve Neon renkli Şahin seçenekleri var.
- Yeni araç: RENAULT TOROS; köşeli sedan gövdesiyle mağazadan 1500 jetona alınabilir. Satın alma/araç seçimi cihazda saklanır.
- Bot devre dışı bırakıldığında 50 jeton kazanılır; satın alma ve seçilen araç aynı cihazdaki tarayıcıda localStorage ile saklanır.
- Şimdilik bunlar farklı renklerdir; ayrı model/performans farkları henüz yok. Arabaların özel tasarımlarını birlikte yapacağız.

MULTIPLAYER'I ÇALIŞTIRMA
1. Bilgisayarında Node.js 18 veya daha yenisi kurulu olmalı.
2. Bu klasörde terminal açıp `npm install` çalıştır.
3. `npm start` çalıştır. Sunucu varsayılan olarak 3000 portunda açılır.
4. Aynı ağda test etmek için diğer cihazda bilgisayarın yerel IP adresini ve :3000 portunu açmayı dene (güvenlik duvarı izin vermeli).
5. İnternet üzerinden farklı ağlardan oynamak için bu klasörü HTTPS destekleyen bir Node.js hostuna dağıt. Hostta `npm install` ve `npm start` kullanılsın. Host sağlayıcısının verdiği HTTPS URL'sini oyun içindeki Multiplayer ekranına yaz.

DÜRÜST DURUM RAPORU
- ZIP tek başına internette herkese açık bir sunucu başlatmaz. Gerçek internet multiplayer için server.js dosyasını çalıştırıp internete dağıtmak gerekir.
- Oda kodu sistemi eklendi: bir oyuncu oda oluşturur, 6 karakterlik kodu arkadaşına gönderir; arkadaş aynı sunucuya bağlanıp kodla katılır. En fazla 8 oyuncu/oda. Aynı odadaki oyuncuların araç konumları ve dönüşleri gösterilir.
- Oyuncuların birbirine hasar vermesi/ateş etmesi, oyuncuların birbirine hasar vermesi/ateş etmesi, hesap sistemi, güvenli sunucu tarafı fizik ve hile koruması henüz eklenmedi.
- Araba mağazası yerel cihazda kayıt tutar; satın almalar cihazlar arasında senkronize değildir.
- Oyun telefonda gerçek cihaz testi görmedi. Üç.js ve bazı istemci dosyaları internet bağlantısı gerektirir.

GÖRSEL GÜNCELLEME
- Sahne gündüz ışığı, açık mavi gökyüzü ve gündüz sisiyle güncellendi.
- Mağazaya oyun içinden erişmek için sağ üstte MAĞAZA düğmesi eklendi.
- Oda koduyla multiplayer için sunucuya bağlan, oda oluştur veya arkadaşının 6 karakterlik kodunu gir.


YENİ SÜRÜM: ROKET YAKITI VE OYUNCU ADI
- Oyuna başlamadan önce oyuncu adı girmek zorunludur (en fazla 16 karakter).
- Multiplayer ekranında da oda oluşturmadan/katılmadan önce oyuncu adı zorunludur. İsim aynı odadaki oyuncu listesi verisine sunucu tarafından aktarılır.
- Roket yakıtı 100% ile başlar. Turbo basılıyken saniyede 24 puan yakıt tüketir; yakıt bitince uçuş iticileri devreye girmez. Yerdeyken turbo kullanılmıyorsa saniyede 10 puan yenilenir. Yakıt göstergesi sol üsttedir.
- Multiplayer’da diğer oyuncuların ve kendi aracının üstünde isim etiketi gösterilir. Şahin/Toros modeli de ağ üzerinden paylaşılır. Multiplayer bağlantısı ve uçuş yakıtı gerçek telefonlarda ayrıca test edilmelidir.


WEBVIEW / APK DÜZELTMESİ (YENİ)
- Three.js kitaplığı geçerli ve eski Android WebView ile uyumlu CDN adresine alındı.
- Socket.IO istemcisi kök dizine bağlı /socket.io/... yolundan çıkarılıp CDN adresine alındı; böylece index.html dosyası WebView içinde açıldığında bozuk yerel yol kullanılmaz.
- Bu sürüm 3D motor ve korna için internet bağlantısı ister. Multiplayer için ayrıca çalışan ve internete erişilebilen server.js sunucusu gerekir.

HESAP / HEDİYE KODU (YEREL PROTOTİP)
- Ana menüdeki HESAP / KOD düğmesinden kullanıcı adı ve şifreyle yerel hesap oluşturabilir/giriş yapabilirsin.
- Hediye kodu alanına tofaş (veya tofas) yazınca jeton bakiyesi sınırsız olur.
- Bu hesap sistemi yalnızca aynı cihazdaki tarayıcı depolamasını kullanır; gerçek çevrim içi hesap değildir.
- Mevcut oyun modları, 3D market/araç önizlemesi, otobüs, korna ve Beethoven Virus müziği korunmuştur.

UÇAN BOTLAR VE DAHA AKILLI BOT YAPAY ZEKÂSI (YENİ)
- PVP ve zombi modlarında her üçüncü bot roket iticileriyle yükselip havada hareket eder; botların uçuş yakıtı sınırlıdır ve inişten sonra tekrar uçuşa geçebilirler.
- Botlar oyuncunun konumuna göre nişan alır, farklı mesafelerde hızlarını ayarlar, yakın mesafede çevresinde manevra yapar ve oyuncunun mermileri yaklaşınca kaçınmaya çalışır.
- Şehir modundaki botlar bina çarpışma alanlarını kontrol edip yön değiştirir; yerdeyken binaların içine girmemeleri için ek çarpışma düzeltmesi uygulanır.
- Futbol haritasında stadyum tribünlerinin dış kenarlarına araç çarpışma sınırları eklendi.
- Bu yapay zekâ güncellemesi kod/sözdizimi kontrolünden geçirildi; gerçek Android cihazda oynanış testi ayrıca yapılmalıdır.


YENI MEKANIK - ITICI MODLARI
- Oyun icindeyken sag alttaki mor "ITICI: ILERI" dugmesine dokunarak mod degistirilir.
- ILERI modu: TURBO dugmesine basili tutuldugunda mevcut hizli ileri itis ve hafif yukselme kullanilir.
- DIKEY modu: TURBO dugmesine basili tutuldugunda aracin altindaki iki motor alev cikarir ve araci yukari kaldirir.
- Her iki mod da roket yakitini tuketir; yakit kullanilmadiginda yerde yenilenir.
- Ucan AI botlarda da alta bakan motor alevleri gorunur.


Guncelleme notu: Arac modellerinin on yonu ortak hale getirildi. Motor sesi surus sirasinda otomatik calisir; turbo, carpismalar ve vites degisimi otomatik ses efektleri tetikler. Mobil tarayicilar ses icin ilk kullanici dokunusunu gerektirebilir.


YENI GUNCELLEME - TARETLER VE ATES ETME
- Tum arac modellerine iki adet cift namlulu cati tareti eklendi.
- ATEŞ ET dugmesi mermileri taretlerin onunden cikarir; ates aninda kisa bir namlu parlamasi gorunur.
- Dusman botlar da ates ettiginde atesleme noktasi taret hizasindan alinir.
- ZIP butunluk ve JavaScript sozdizimi kontrolunden gecirilmeli; Android cihaz testi ayrica yapilmalidir.


WEBVIEW + BAĞLANTI DÜZELTMESİ (2026-10-24)
- Three.js CDN adresi için alternatif CDN geri dönüşü eklendi.
- Socket.IO istemcisi için alternatif CDN geri dönüşü eklendi.
- Android WebView/file:// içinden açıldığında location.origin değerinin 'null' olması nedeniyle Multiplayer alanına hatalı varsayılan sunucu yazılması düzeltildi.
- Multiplayer sunucu adresi kontrolü ve daha açık hata mesajları eklendi. Bu değişiklikler internet sunucusu kurmaz; gerçek multiplayer için server.js internete açık bir Node.js hostunda çalışmalıdır.
- Bu ZIP, web projesinin kaynak paketidir; kurulabilir APK değildir. Android WebView ayarları uygulamanın Android kabuğunda belirlenir, bu ZIP tek başına WebView motor ayarlarını değiştiremez.


GUNCELLEME NOTU:
- Three.js ve Socket.IO CDN yüklemelerine üçüncü yedek adres eklendi.
- Multiplayer bağlantısı önce polling ile başlar, desteklenirse WebSocket'e yükselir.
- Yeniden bağlanma denemeleri eklendi.
- Gerçek internet multiplayer için çalışan, herkese açık bir Socket.IO sunucusu gerekir.
- Bu ZIP kaynak web projesidir; Android APK/WebView kabuk ayarlarını değiştirmez ve gerçek cihaz testi yapılmamıştır.


YATAY EKRAN GUNCELLEMESI
- Telefon dikey tutuldugunda oyun arayuzu ve oyun goruntusu CSS ile yatay gorunume cevrilir.
- Renderer boyutu portre ekranda genislik/yukseklik takasi yapacak sekilde ayarlandi.
- Bu degisiklik web projesi icindedir; Android APK kabugunun kendi yon kilidi ayarini degistirmez.
- ZIP ve HTML kontrol edildi; gercek telefonda test edilmemistir.


ONIZLEME DUZELTMESI:
- CSS ile ekran dondurme kaldirildi; bu yontem APK onizlemesinde kesilme/ters goruntuye neden oluyordu.
- Gercek yatay uygulama icin APK olusturucuda ekran yonu / orientation = Landscape ayari gerekir. HTML/CSS tek basina Android uygulama yon kilidini degistiremez.


EKRAN MODU GUNCELLEMESI:
- Oyuna kucuk bir Dikey/Yatay mod dugmesi eklendi.
- Dugme web oyununun gorunum sinifini degistirir ve yeniden boyutlandirma olayini tetikler.
- Bu, Android sistem ekran yonunu kilitlemez; APK olusturucudaki Landscape ayari varsa ayrica kullanilmalidir.
- ZIP butunlugu kontrol edildi; gercek cihaz testi yapilmadi.
