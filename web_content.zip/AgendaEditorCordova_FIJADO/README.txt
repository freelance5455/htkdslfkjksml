EDITOR DE AGENDA - CORRECCIÓN DE GUARDADO Y PDF

Cambios:
- Guardar proyecto JSON abre el selector de documentos de Android (ACTION_CREATE_DOCUMENT) y permite elegir carpeta y nombre, por ejemplo Descargas.
- Exportar PDF abre el diálogo nativo de impresión de Android; selecciona "Guardar como PDF" y elige destino.
- Se elimina la dependencia de cordova-plugin-printer, incompatible con AndroidX / cordova-android moderno.
- En navegador de escritorio conserva descarga JSON y ventana de impresión.

INSTALACIÓN:
1. Descomprime el proyecto y abre CMD en esta carpeta.
2. Si ya se había instalado el plugin antiguo, ejecuta:
   cordova plugin rm cordova-plugin-printer
3. Instala el plugin local:
   cordova plugin add plugins/cordova-plugin-agenda-files
4. Compila:
   cordova build android

El plugin cordova-plugin-file no es necesario para elegir el destino del JSON en esta versión.
La exportación PDF usa el diálogo de impresión nativo; en el diálogo selecciona "Guardar como PDF".
Valida en un dispositivo real. No se afirma que el APK se haya compilado aquí.


COMPILACION SIN ELIMINAR LA PLATAFORMA EXISTENTE:
Desde la carpeta raiz (donde esta config.xml), ejecutar:
  cordova platform ls
  cordova prepare android
  cordova build android

NO ejecutar cordova platform rm android si Android ya esta instalado y funciona.
El plugin local cordova-plugin-agenda-files es requerido para guardar JSON
con el selector nativo de Android y para la impresion PDF nativa.

NOTA DE VALIDACION: app.js revisado con comprobacion de sintaxis JavaScript (node --check).
La compilacion APK y las pruebas en dispositivo Android deben validarse en el equipo local.
