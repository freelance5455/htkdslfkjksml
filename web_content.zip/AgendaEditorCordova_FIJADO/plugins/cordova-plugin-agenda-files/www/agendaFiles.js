var exec = require("cordova/exec");
exports.saveJson = function(filename, content, success, error) {
  exec(success, error, "AgendaFiles", "saveJson", [filename, content]);
};
exports.printPdf = function(title, html, success, error) {
  exec(success, error, "AgendaFiles", "printPdf", [title, html]);
};
