package com.agenda.editor.files;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.print.PrintDocumentAdapter;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.util.Base64;
import org.apache.cordova.CordovaPlugin;
import org.apache.cordova.CallbackContext;
import org.json.JSONArray;
import org.json.JSONException;
import java.io.OutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;

public class AgendaFilesPlugin extends CordovaPlugin {
    private static final int CREATE_JSON_REQUEST = 4812;
    private CallbackContext pendingSave;
    private String pendingContent = "";

    @Override
    public boolean execute(String action, JSONArray args, CallbackContext callback) throws JSONException {
        if ("saveJson".equals(action)) {
            String filename = args.getString(0);
            pendingContent = args.getString(1);
            pendingSave = callback;
            cordova.getActivity().runOnUiThread(() -> {
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                intent.putExtra(Intent.EXTRA_TITLE, filename);
                intent.putExtra("android.content.extra.SHOW_ADVANCED", true);
                cordova.startActivityForResult(this, intent, CREATE_JSON_REQUEST);
            });
            return true;
        }
        if ("printPdf".equals(action)) {
            final String title = args.getString(0);
            final String html = args.getString(1);
            cordova.getActivity().runOnUiThread(() -> startPrint(title, html, callback));
            return true;
        }
        return false;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent intent) {
        if (requestCode != CREATE_JSON_REQUEST) return;
        CallbackContext callback = pendingSave;
        pendingSave = null;
        if (callback == null) return;
        if (resultCode != Activity.RESULT_OK || intent == null || intent.getData() == null) {
            callback.error("Guardado cancelado por el usuario");
            return;
        }
        Uri uri = intent.getData();
        try (OutputStream out = cordova.getActivity().getContentResolver().openOutputStream(uri, "wt")) {
            if (out == null) throw new IOException("No se pudo abrir el archivo");
            out.write(pendingContent.getBytes(StandardCharsets.UTF_8));
            out.flush();
            callback.success(uri.toString());
        } catch (Exception e) {
            callback.error("Error guardando JSON: " + e.getMessage());
        } finally {
            pendingContent = "";
        }
    }

    private void startPrint(String title, String html, CallbackContext callback) {
        Activity activity = cordova.getActivity();
        if (Build.VERSION.SDK_INT < 19) {
            callback.error("La impresión requiere Android 4.4 o posterior");
            return;
        }
        PrintManager printManager = (PrintManager) activity.getSystemService(Activity.PRINT_SERVICE);
        if (printManager == null) {
            callback.error("El servicio de impresión no está disponible");
            return;
        }
        WebView printWebView = new WebView(activity);
        printWebView.getSettings().setJavaScriptEnabled(false);
        printWebView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                try {
                    PrintDocumentAdapter adapter;
                    if (Build.VERSION.SDK_INT >= 21) adapter = view.createPrintDocumentAdapter(safeTitle(title));
                    else adapter = view.createPrintDocumentAdapter();
                    PrintAttributes attributes = new PrintAttributes.Builder()
                        .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                        .setResolution(new PrintAttributes.Resolution("agenda_pdf", "Agenda PDF", 300, 300))
                        .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                        .build();
                    printManager.print(safeTitle(title), adapter, attributes);
                    callback.success("Diálogo de impresión abierto");
                } catch (Exception e) {
                    callback.error("No se pudo generar la impresión: " + e.getMessage());
                }
            }
        });
        String encoded = Base64.encodeToString(html.getBytes(StandardCharsets.UTF_8), Base64.NO_WRAP);
        printWebView.loadDataWithBaseURL("file:///android_asset/www/", encoded, "text/html", "base64", null);
    }

    private String safeTitle(String title) {
        if (title == null || title.trim().isEmpty()) return "Documento";
        return title.replaceAll("[^A-Za-z0-9._ -]", "_");
    }
}
