(() => {
"use strict";
const $ = id => document.getElementById(id);
const state = {name:"Mi proyecto", pages:[], activePage:0, selected:null, zoom:1, undo:[], redo:[], dirty:false, cropDraft:null};
const page = $("page"), pageList = $("pageList");
const DB_NAME = "agenda_editor_web_v1", STORE = "projects";
let db = null, saveTimer = null, toastTimer = null, drag = null, suppressClick = false;

function uid(){return "o"+Date.now().toString(36)+Math.random().toString(36).slice(2,8)}
function toast(msg){const t=$("toast");t.textContent=msg;t.classList.add("show");clearTimeout(toastTimer);toastTimer=setTimeout(()=>t.classList.remove("show"),2800)}
function setStatus(msg){$("saveStatus").textContent=msg}
function current(){return state.pages[state.activePage]}
function dimensions(){const s=$("pageSize").value;if(s==="letter")return {w:816,h:1056};if(s==="custom")return {w:Math.max(200,+$("customW").value||794),h:Math.max(200,+$("customH").value||1123)};return {w:794,h:1123}}
function ensurePage(){if(!state.pages.length)state.pages.push({id:uid(),w:794,h:1123,items:[]})}
function snapshot(){return JSON.stringify({name:state.name,pages:state.pages,activePage:state.activePage})}
function checkpoint(){state.undo.push(snapshot());if(state.undo.length>60)state.undo.shift();state.redo=[]}
function markDirty(){state.dirty=true;setStatus("Cambios sin guardar");scheduleAutosave()}
function scheduleAutosave(){clearTimeout(saveTimer);saveTimer=setTimeout(saveLocal,450)}
function openDB(){return new Promise(resolve=>{if(!("indexedDB" in window)){resolve(null);return}let req=indexedDB.open(DB_NAME,1);req.onupgradeneeded=()=>{const d=req.result;if(!d.objectStoreNames.contains(STORE))d.createObjectStore(STORE,{keyPath:"id"})};req.onsuccess=()=>resolve(req.result);req.onerror=()=>resolve(null)})}
async function saveLocal(){try{if(!db)db=await openDB();if(db){await new Promise((res,rej)=>{const tx=db.transaction(STORE,"readwrite");tx.objectStore(STORE).put({id:"autosave",updated:Date.now(),data:JSON.parse(snapshot())});tx.oncomplete=res;tx.onerror=()=>rej(tx.error)})}state.dirty=false;setStatus("Guardado localmente")}catch(e){setStatus("No se pudo guardar");console.error(e)}}
async function loadLocal(){db=await openDB();if(!db)return;try{const item=await new Promise((res,rej)=>{const r=db.transaction(STORE).objectStore(STORE).get("autosave");r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error)});if(item&&item.data){restoreData(item.data,false);toast("Se recuperó el último proyecto guardado localmente")}}catch(e){console.warn(e)}}
function restoreData(data,checkpointIt=true){if(!data||!Array.isArray(data.pages))throw Error("El archivo no tiene un proyecto válido");if(checkpointIt)checkpoint();state.name=String(data.name||"Mi proyecto");state.pages=data.pages.map(p=>({id:p.id||uid(),w:+p.w||794,h:+p.h||1123,items:Array.isArray(p.items)?p.items.map(o=>({...o,id:o.id||uid()})):[]}));if(!state.pages.length)ensurePage();state.activePage=Math.min(Math.max(0,+data.activePage||0),state.pages.length-1);state.selected=null;$("projectName").value=state.name;renderAll();markDirty()}
function escapeText(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function renderAll(){ensurePage();renderPage();renderPageList();renderProperties();$("pageLabel").textContent=`Página ${state.activePage+1} de ${state.pages.length}`}
function renderPage(){const p=current();page.innerHTML="";page.style.width=p.w+"px";page.style.height=p.h+"px";page.style.transform=`scale(${state.zoom})`;page.dataset.pageId=p.id;
  p.items.forEach(o=>{let el;if(o.type==="image"){el=document.createElement("img");el.src=o.src;el.alt=o.alt||"Imagen insertada";el.draggable=false;el.className="editor-item image-item";el.style.objectFit="fill";applyCropStyle(el,o)}else if(o.type==="line"){el=document.createElement("div");el.className="editor-item line-item";el.style.width=o.w+"px";el.style.height=Math.max(2,o.h||3)+"px";el.style.transform=`rotate(${o.angle||0}deg)`;el.style.background=o.color||"#263d39"}else{el=document.createElement("div");el.className="editor-item text-item";el.textContent=o.text||"Texto";el.style.fontSize=(o.fontSize||18)+"px";el.style.color=o.color||"#203c38";el.style.background=o.bg&&o.bg!=="#ffffff"?o.bg:"transparent";el.style.fontWeight=o.bold?"700":"400";el.style.fontFamily=o.fontFamily||"Arial, sans-serif";el.style.textAlign=o.align||"left"}
    el.dataset.id=o.id;el.style.left=o.x+"px";el.style.top=o.y+"px";el.style.width=o.w+"px";el.style.height=o.h+"px";if(state.selected===o.id){el.classList.add("selected");const h=document.createElement("span");h.className="resize-handle";h.title="Arrastra para redimensionar";el.appendChild(h)}el.addEventListener("pointerdown",e=>itemPointerDown(e,o,el));el.addEventListener("click",e=>{e.stopPropagation();selectItem(o.id)});page.appendChild(el);
  });
}
function applyCropStyle(el,o){const c=o.crop||{top:0,right:0,bottom:0,left:0};el.style.clipPath=`inset(${c.top||0}% ${c.right||0}% ${c.bottom||0}% ${c.left||0}%)`}
function renderPageList(){pageList.innerHTML="";state.pages.forEach((p,i)=>{const b=document.createElement("button");b.className="page-chip"+(i===state.activePage?" active":"");b.textContent=`Página ${i+1} · ${p.items.length} elemento(s)`;b.onclick=()=>{state.activePage=i;state.selected=null;renderAll()};pageList.appendChild(b)})}
function selectedObject(){return current().items.find(o=>o.id===state.selected)||null}
function renderProperties(){const o=selectedObject();$("emptyProperties").classList.toggle("hidden",!!o);$("propertyForm").classList.toggle("hidden",!o);if(!o)return;$("propText").value=o.text||"";$("propText").disabled=o.type==="image"||o.type==="line";$("propFontSize").value=o.fontSize||18;$("propColor").value=o.color||"#203c38";$("propBg").value=o.bg||"#ffffff";$("propBold").checked=!!o.bold;$("propWidth").value=Math.round(o.w);$("propHeight").value=Math.round(o.h);$("propX").value=Math.round(o.x);$("propY").value=Math.round(o.y);const c=o.crop||{};$("cropTop").value=c.top||0;$("cropRight").value=c.right||0;$("cropBottom").value=c.bottom||0;$("cropLeft").value=c.left||0;$("applyCrop").disabled=o.type!=="image";$("resetCrop").disabled=o.type!=="image"}
function selectItem(id){state.selected=id;renderPage();renderProperties()}
function itemPointerDown(e,o,el){if(e.button!==0)return;e.stopPropagation();selectItem(o.id);const resize=e.target.classList.contains("resize-handle");drag={id:o.id,startX:e.clientX,startY:e.clientY,x:o.x,y:o.y,w:o.w,h:o.h,resize,ratio:o.w/(o.h||1),moved:false};try{el.setPointerCapture(e.pointerId)}catch(_){}window.addEventListener("pointermove",onPointerMove);window.addEventListener("pointerup",onPointerUp,{once:true})}
function scaleFactor(){return state.zoom||1}
function onPointerMove(e){if(!drag)return;const o=selectedObject();if(!o||o.id!==drag.id)return;const dx=(e.clientX-drag.startX)/scaleFactor(),dy=(e.clientY-drag.startY)/scaleFactor();if(Math.abs(dx)+Math.abs(dy)>2)drag.moved=true;if(drag.resize){let nw=Math.max(20,drag.w+dx),nh=Math.max(20,drag.h+dy);if($("keepRatio").checked){if(Math.abs(dx)>Math.abs(dy))nh=nw/drag.ratio;else nw=nh*drag.ratio}o.w=nw;o.h=nh}else{o.x=Math.max(0,drag.x+dx);o.y=Math.max(0,drag.y+dy)}renderPage();renderProperties()}
function onPointerUp(){if(drag){if(drag.moved){markDirty();suppressClick=true;setTimeout(()=>suppressClick=false,100)}drag=null}window.removeEventListener("pointermove",onPointerMove)}
page.addEventListener("pointerdown",e=>{if(e.target===page){state.selected=null;renderPage();renderProperties()}});
function addObject(obj){checkpoint();const p=current();obj.id=uid();obj.x=Math.max(0,obj.x??40);obj.y=Math.max(0,obj.y??40);obj.w=obj.w||200;obj.h=obj.h||60;p.items.push(obj);state.selected=obj.id;renderAll();markDirty()}
function addText(){const text=prompt("Escribe el texto:","Nuevo texto");if(text===null)return;addObject({type:"text",text:text||"Texto",x:45,y:45,w:280,h:70,fontSize:20,color:"#203c38",bg:"#ffffff",bold:false})}
function addLine(){addObject({type:"line",x:45,y:60,w:220,h:3,angle:0,color:"#203c38"})}
function addImageFile(file){if(!file)return;if(!file.type.startsWith("image/")){toast("Selecciona un archivo de imagen");return}const reader=new FileReader();reader.onload=()=>{const src=reader.result;const im=new Image();im.onload=()=>{const max=450,ratio=Math.min(max/im.naturalWidth,max/im.naturalHeight,1);addObject({type:"image",src,alt:file.name,x:40,y:40,w:Math.max(30,im.naturalWidth*ratio),h:Math.max(30,im.naturalHeight*ratio),crop:{top:0,right:0,bottom:0,left:0}});toast("Imagen insertada")};im.onerror=()=>toast("No se pudo leer la imagen");im.src=src};reader.readAsDataURL(file)}
function addPage(){checkpoint();const d=dimensions();state.pages.push({id:uid(),w:d.w,h:d.h,items:[]});state.activePage=state.pages.length-1;state.selected=null;renderAll();markDirty()}
function deletePage(){if(state.pages.length===1){if(!confirm("La última página se vaciará. ¿Continuar?"))return;checkpoint();current().items=[]}else{if(!confirm("¿Eliminar la página actual y su contenido?"))return;checkpoint();state.pages.splice(state.activePage,1);state.activePage=Math.max(0,state.activePage-1)}state.selected=null;renderAll();markDirty()}
function deleteSelected(){const o=selectedObject();if(!o){toast("Primero selecciona un elemento");return}checkpoint();current().items=current().items.filter(x=>x.id!==o.id);state.selected=null;renderAll();markDirty()}
function duplicateSelected(){const o=selectedObject();if(!o){toast("Primero selecciona un elemento");return}checkpoint();const c=JSON.parse(JSON.stringify(o));c.id=uid();c.x+=20;c.y+=20;current().items.push(c);state.selected=c.id;renderAll();markDirty()}
function applyProperties(){const o=selectedObject();if(!o)return;checkpoint();if(o.type==="text"){o.text=$("propText").value;o.fontSize=clamp(+$("propFontSize").value||18,6,200);o.color=$("propColor").value;o.bg=$("propBg").value;o.bold=$("propBold").checked}let w=Math.max(20,+$("propWidth").value||o.w),h=Math.max(20,+$("propHeight").value||o.h);if($("keepRatio").checked&&o.w>0&&o.h>0&&w!==o.w&&h===o.h)h=w/(o.w/o.h);o.w=w;o.h=h;o.x=Math.max(0,+$("propX").value||0);o.y=Math.max(0,+$("propY").value||0);if(o.type==="line")o.color=$("propColor").value;renderAll();markDirty();toast("Propiedades aplicadas")}
function clamp(n,min,max){return Math.max(min,Math.min(max,n))}
function applyCrop(){const o=selectedObject();if(!o||o.type!=="image"){toast("Selecciona una imagen");return}const c={top:clamp(+$("cropTop").value||0,0,95),right:clamp(+$("cropRight").value||0,0,95),bottom:clamp(+$("cropBottom").value||0,0,95),left:clamp(+$("cropLeft").value||0,0,95)};if(c.left+c.right>=100||c.top+c.bottom>=100){toast("La suma de los recortes opuestos debe ser menor de 100%");return}checkpoint();o.crop=c;renderPage();renderProperties();markDirty();toast("Recorte aplicado")}
function resetCrop(){const o=selectedObject();if(!o||o.type!=="image")return;checkpoint();o.crop={top:0,right:0,bottom:0,left:0};renderPage();renderProperties();markDirty()}
function undo(){if(!state.undo.length){toast("No hay acciones para deshacer");return}state.redo.push(snapshot());const d=JSON.parse(state.undo.pop());restoreData(d,false);toast("Acción deshecha")}
function redo(){if(!state.redo.length){toast("No hay acciones para rehacer");return}state.undo.push(snapshot());const d=JSON.parse(state.redo.pop());restoreData(d,false);toast("Acción rehecha")}
async function download(name,content,type){
  const blob=new Blob([content],{type});
  // En navegadores compatibles, abrir el selector para elegir nombre y carpeta.
  if(window.showSaveFilePicker){
    try{
      const handle=await window.showSaveFilePicker({
        suggestedName:name,
        types:[{description:"Archivo JSON",accept:{"application/json":[".json"]}}]
      });
      const writable=await handle.createWritable();
      await writable.write(blob);
      await writable.close();
      return "picked";
    }catch(e){
      if(e && e.name==="AbortError") return "cancelled";
      console.warn("Selector de destino no disponible; se usará descarga normal.",e);
    }
  }
  // Respaldo compatible con navegadores que no permiten elegir carpeta desde la web.
  const url=URL.createObjectURL(blob),a=document.createElement("a");
  a.href=url;a.download=name;a.style.display="none";document.body.appendChild(a);a.click();a.remove();
  setTimeout(()=>URL.revokeObjectURL(url),3000);
  return "download";
}
async function saveProject(){
  state.name=$("projectName").value.trim()||"Mi proyecto";
  const safeName=(state.name.replace(/[^\\w\\-]+/g,"_")||"proyecto");
  const content=JSON.stringify({format:"agenda-editor-project",version:1,name:state.name,activePage:state.activePage,pages:state.pages},null,2);
  saveLocal();
  const filename=safeName+"_Respaldo.json";
  if(window.cordova && window.cordova.plugins && window.cordova.plugins.agendaFiles){
    window.cordova.plugins.agendaFiles.saveJson(filename,content,
      path=>{setStatus("Respaldo JSON guardado");toast("Respaldo guardado correctamente: "+filename);},
      err=>{console.error(err);toast("No se pudo guardar el JSON. Intenta de nuevo.");});
  }else{
    try{
      const result=await download(filename,content,"application/json;charset=utf-8");
      if(result==="cancelled"){toast("Exportación cancelada");return}
      setStatus(result==="picked"?"Respaldo JSON guardado":"Respaldo JSON descargado");
      toast(result==="picked"?"Respaldo guardado en la ubicación elegida":"Se descargó "+filename+"; en este navegador la carpeta depende de sus descargas");
    }catch(e){console.error(e);toast("No se pudo exportar el JSON");}
  }
}
function openProject(file){const r=new FileReader();r.onload=()=>{try{const data=JSON.parse(r.result);restoreData(data,true);toast("Proyecto abierto correctamente")}catch(e){console.error(e);toast("No se pudo abrir: archivo JSON inválido")}};r.readAsText(file)}
function newProject(){if(!confirm("¿Crear un proyecto nuevo? Primero exporta una copia si quieres conservar el actual."))return;checkpoint();state.name="Mi proyecto";state.pages=[{id:uid(),w:794,h:1123,items:[]}];state.activePage=0;state.selected=null;$("projectName").value=state.name;renderAll();markDirty()}
function exportPDF(){
  state.name=$("projectName").value.trim()||"Mi proyecto";
  const pages=state.pages.map((p,i)=>{
    const items=p.items.map(o=>{
      const common=`position:absolute;left:${o.x}px;top:${o.y}px;width:${o.w}px;height:${o.h}px;box-sizing:border-box;`;
      if(o.type==="image") { const c=o.crop||{}; return `<img src="${o.src}" style="${common}object-fit:fill;clip-path:inset(${c.top||0}% ${c.right||0}% ${c.bottom||0}% ${c.left||0}%);">`; }
      if(o.type==="line") return `<div style="${common}height:${Math.max(2,o.h||3)}px;background:${o.color||"#263d39"};transform:rotate(${o.angle||0}deg);transform-origin:left center"></div>`;
      return `<div style="${common}white-space:pre-wrap;overflow-wrap:anywhere;padding:3px;font-family:${o.fontFamily||"Arial,sans-serif"};font-size:${o.fontSize||18}px;color:${o.color||"#203c38"};background:${o.bg&&o.bg!=="#ffffff"?o.bg:"transparent"};font-weight:${o.bold?700:400};text-align:${o.align||"left"}">${escapeText(o.text||"Texto")}</div>`;
    }).join("");
    return `<section class="print-page" style="position:relative;width:${p.w}px;height:${p.h}px;overflow:hidden;background:#fff;page-break-after:${i===state.pages.length-1?"auto":"always"};break-after:${i===state.pages.length-1?"auto":"page"}">${items}</section>`;
  }).join("");
  const html=`<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${escapeText(state.name)}</title><style>@page{size:auto;margin:0}html,body{margin:0;padding:0;background:#fff}.print-page{margin:0 auto;box-shadow:none}@media print{.print-page{margin:0;break-inside:avoid}}</style></head><body>${pages}</body></html>`;
  if(window.cordova && window.cordova.plugins && window.cordova.plugins.agendaFiles){
    window.cordova.plugins.agendaFiles.printPdf(state.name||"Documento",html,
      ()=>toast("Se abrió el diálogo de impresión. Elige «Guardar como PDF» y selecciona la carpeta."),
      err=>{console.error(err);toast("No se pudo abrir la exportación PDF.");});
  }else{
    const w=window.open("","_blank");
    if(!w){toast("El navegador bloqueó la ventana de impresión. Permite ventanas emergentes e inténtalo de nuevo.");return;}
    w.document.open();w.document.write(html);w.document.close();setTimeout(()=>{w.focus();w.print()},500);
  }
}
let cropperImage=null,cropStart=null,cropRect=null,cropScale=1;
function openImageCropper(){
  const o=selectedObject();
  if(!o||o.type!=="image"){toast("Selecciona primero una imagen en la página");return}
  cropperImage=new Image();
  cropperImage.onload=()=>{
    const canvas=$("cropCanvas"),ctx=canvas.getContext("2d");
    const maxW=Math.max(240,Math.min(window.innerWidth-48,900)),maxH=Math.max(220,Math.min(window.innerHeight-230,650));
    cropScale=Math.min(maxW/cropperImage.naturalWidth,maxH/cropperImage.naturalHeight,1);
    canvas.width=Math.max(1,Math.round(cropperImage.naturalWidth*cropScale));canvas.height=Math.max(1,Math.round(cropperImage.naturalHeight*cropScale));
    canvas.style.width=canvas.width+"px";canvas.style.height=canvas.height+"px";ctx.clearRect(0,0,canvas.width,canvas.height);ctx.drawImage(cropperImage,0,0,canvas.width,canvas.height);
    cropRect=null;$("cropSelection").classList.add("hidden");$("cropSelection").style.cssText="";$("cropModal").classList.remove("hidden");
  };
  cropperImage.onerror=()=>toast("No se pudo abrir esta imagen para recortarla");cropperImage.src=o.src;
}
function cropPoint(e){
  const canvas=$("cropCanvas"),r=canvas.getBoundingClientRect();
  // Guardar la selección en píxeles internos del canvas, no en píxeles CSS.
  return {x:clamp((e.clientX-r.left)*(canvas.width/(r.width||1)),0,canvas.width),
          y:clamp((e.clientY-r.top)*(canvas.height/(r.height||1)),0,canvas.height)};
}
function updateCropSelection(){
  if(!cropRect)return;
  const el=$("cropSelection"),canvas=$("cropCanvas"),viewport=$("cropViewport");
  const cr=canvas.getBoundingClientRect(),vr=viewport.getBoundingClientRect();
  const sx=cr.width/(canvas.width||1),sy=cr.height/(canvas.height||1);
  const left=cr.left-vr.left+viewport.scrollLeft,top=cr.top-vr.top+viewport.scrollTop;
  el.classList.remove("hidden");
  el.style.left=(left+Math.min(cropRect.x1,cropRect.x2)*sx)+"px";
  el.style.top=(top+Math.min(cropRect.y1,cropRect.y2)*sy)+"px";
  el.style.width=(Math.abs(cropRect.x2-cropRect.x1)*sx)+"px";
  el.style.height=(Math.abs(cropRect.y2-cropRect.y1)*sy)+"px";
}
function closeImageCropper(){$("cropModal").classList.add("hidden");cropperImage=null;cropRect=null;cropStart=null}
function applyImageCrop(){
  const o=selectedObject();if(!o||o.type!=="image"||!cropperImage||!cropRect){toast("Arrastra para seleccionar el área que deseas conservar");return}
  const x=Math.min(cropRect.x1,cropRect.x2),y=Math.min(cropRect.y1,cropRect.y2),w=Math.abs(cropRect.x2-cropRect.x1),h=Math.abs(cropRect.y2-cropRect.y1);
  if(w<8||h<8){toast("Selecciona un área de recorte más grande");return}
  const sx=Math.round(x/cropScale),sy=Math.round(y/cropScale),sw=Math.min(cropperImage.naturalWidth-sx,Math.round(w/cropScale)),sh=Math.min(cropperImage.naturalHeight-sy,Math.round(h/cropScale));
  if(sw<1||sh<1){toast("El área seleccionada no es válida");return}
  const out=document.createElement("canvas");out.width=sw;out.height=sh;out.getContext("2d").drawImage(cropperImage,sx,sy,sw,sh,0,0,sw,sh);
  let newSrc;try{newSrc=out.toDataURL("image/png")}catch(e){console.error(e);toast("No se pudo procesar la imagen");return}
  checkpoint();o.src=newSrc;o.w=Math.max(20,Math.min(o.w,sw));o.h=Math.max(20,Math.min(o.h,sh));o.crop={top:0,right:0,bottom:0,left:0};renderAll();markDirty();closeImageCropper();toast("Imagen recortada sin reducir la resolución del área seleccionada");
}
$("cropCanvas").addEventListener("pointerdown",e=>{if(!cropperImage)return;e.preventDefault();const p=cropPoint(e);cropStart=p;cropRect={x1:p.x,y1:p.y,x2:p.x,y2:p.y};$("cropCanvas").setPointerCapture?.(e.pointerId);updateCropSelection()});
$("cropCanvas").addEventListener("pointermove",e=>{if(!cropStart)return;const p=cropPoint(e);cropRect.x2=p.x;cropRect.y2=p.y;updateCropSelection()});
$("cropCanvas").addEventListener("pointerup",()=>{cropStart=null});$("cropCanvas").addEventListener("pointercancel",()=>{cropStart=null});
$("cropApply").addEventListener("click",applyImageCrop);$("cropClose").addEventListener("click",closeImageCropper);$("cropCancel").addEventListener("click",closeImageCropper);
function setZoom(n){state.zoom=clamp(n,.35,1.5);$("zoomLabel").textContent=Math.round(state.zoom*100)+"%";renderPage()}
function handleAction(a){switch(a){case"new":newProject();break;case"save":saveProject();break;case"open":$("projectInput").click();break;case"pdf":exportPDF();break;case"text":addText();break;case"image":$("imageInput").click();break;case"line":addLine();break;case"page-add":addPage();break;case"page-delete":deletePage();break;case"undo":undo();break;case"redo":redo();break;case"delete":deleteSelected();break;case"copy":duplicateSelected();break;case"crop-image":openImageCropper();break}}
document.querySelectorAll("[data-action]").forEach(b=>b.addEventListener("click",()=>{handleAction(b.dataset.action);if(innerWidth<=700)$("toolbar").classList.remove("open")}));
$("imageInput").addEventListener("change",e=>{addImageFile(e.target.files[0]);e.target.value=""});
$("projectInput").addEventListener("change",e=>{if(e.target.files[0])openProject(e.target.files[0]);e.target.value=""});
$("projectName").addEventListener("change",()=>{state.name=$("projectName").value.trim()||"Mi proyecto";markDirty()});
$("applyProps").addEventListener("click",applyProperties);$("applyCrop").addEventListener("click",applyCrop);$("resetCrop").addEventListener("click",resetCrop);
$("zoomIn").addEventListener("click",()=>setZoom(state.zoom+.1));$("zoomOut").addEventListener("click",()=>setZoom(state.zoom-.1));
$("menuToggle").addEventListener("click",()=>$("toolbar").classList.toggle("open"));
$("pageSize").addEventListener("change",()=>{$("customSize").classList.toggle("hidden",$("pageSize").value!=="custom")});
$("applyCustomSize").addEventListener("click",()=>{checkpoint();current().w=clamp(+$("customW").value||794,200,3000);current().h=clamp(+$("customH").value||1123,200,4000);renderAll();markDirty()});
document.addEventListener("keydown",e=>{const target=e.target;const editing=target&&(target.matches("input,textarea,select")||target.isContentEditable);if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==="s"){e.preventDefault();saveProject()}else if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==="z"&&!editing){e.preventDefault();undo()}else if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==="y"&&!editing){e.preventDefault();redo()}else if((e.key==="Delete"||e.key==="Backspace")&&!editing&&state.selected){e.preventDefault();deleteSelected()}else if(e.key==="Escape"){$("toolbar").classList.remove("open")}});
window.addEventListener("beforeunload",e=>{if(state.dirty){e.preventDefault();e.returnValue=""}});
async function init(){state.pages=[{id:uid(),w:794,h:1123,items:[]}];renderAll();await loadLocal();renderAll()}
init();
})();