POCKET WARZONE - sound upgrade

1. Put audio.js in the same folder as your game's index.html (next to engine.js and data.js).
2. Replace your old engine.js with the one in this folder (data.js is unchanged).
3. In your index.html add this line after the data.js line:
       <script src="audio.js"></script>
4. Open sound-demo.html to check every sound before building the APK.

Your existing Sound switch (SAVE.sound) controls everything.
Optional: SAVE.music = false turns off music only, SAVE.voice = false turns off spoken callouts.
If your menu code calls snd() when buttons are tapped, delete those calls: audio.js now adds button sounds automatically.
