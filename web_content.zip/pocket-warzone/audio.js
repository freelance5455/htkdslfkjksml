'use strict';
// ===== POCKET WARZONE — audio.js =====
// Complete sound system. Every sound (music, guns, explosions, footsteps, voices,
// button clicks) is SYNTHESIZED IN CODE, so there are no audio files to load and
// it works offline inside an APK.
//
// Add this file to your HTML (after data.js, before/after engine.js):
//     <script src="audio.js"></script>
// Button-click sounds are automatic. The existing SAVE.sound switch controls
// everything. Optional extra switches: SAVE.music = false (no music),
// SAVE.voice = false (no spoken callouts).

(function () {
  const W = typeof window !== 'undefined' ? window : globalThis;
  const USE_SPEECH = true;        // spoken callouts ("Enemy down!") where the device supports it
  const MUSIC_LEVEL = .5;         // overall music loudness (0-1)

  const SR = 44100, TAU = Math.PI * 2, PI = Math.PI;
  const { exp, sin, cos, tanh, abs, min, max, floor, round, random } = Math;
  const R = () => random() * 2 - 1;
  const rnd = (a, b) => a + random() * (b - a);
  const clamp = (v, a, b) => v < a ? a : v > b ? b : v;
  const pick = a => a[floor(random() * a.length)];
  const mtof = m => 440 * Math.pow(2, (m - 69) / 12);
  const nowMs = () => (typeof performance !== 'undefined' ? performance.now() : Date.now());

  // ================= DSP toolkit =================
  const buf = s => new Float32Array(max(1, round(s * SR)));
  const lpf = () => { let y = 0; return (x, fc) => (y += (1 - exp(-TAU * fc / SR)) * (x - y)); };
  const hpf = () => { const l = lpf(); return (x, fc) => x - l(x, fc); };
  const svf = () => { let lo = 0, bp = 0; return (x, fc, q) => { const f = 2 * sin(PI * min(fc, 9000) / SR); const hi = x - lo - bp / q; bp += f * hi; lo += f * bp; return bp / q; }; };
  const blep = (t, dt) => { if (t < dt) { t /= dt; return t + t - t * t - 1; } if (t > 1 - dt) { t = (t - 1) / dt; return t * t + t + t + 1; } return 0; };

  function norm(a, pk, loop) {
    let m = 1e-9; for (let i = 0; i < a.length; i++) { const v = abs(a[i]); if (v > m) m = v; }
    const g = (pk || .9) / m, n = a.length, fi = loop ? 0 : 40, fo = loop ? 0 : min(n >> 2, 400);
    for (let i = 0; i < n; i++) { let v = a[i] * g; if (i < fi) v *= i / fi; if (fo && i > n - fo) v *= (n - i) / fo; a[i] = v; }
    return a;
  }
  function echo(n, taps) {
    const src = n.slice();
    for (const [d, g] of taps) { const L = lpf(), o = round(d * SR); for (let i = o; i < n.length; i++) n[i] += L(src[i - o], 1800) * g; }
    return n;
  }
  // mix `src` into out ([L] mono or [L,R] stereo) at t0 seconds
  function mix(out, src, t0, g, pan) {
    const L = out[0], Rr = out[1], i0 = round(t0 * SR); g = g == null ? 1 : g; pan = pan || 0;
    const gl = Rr ? g * cos((pan + 1) * PI / 4) : g, gr = g * sin((pan + 1) * PI / 4);
    for (let k = 0; k < src.length; k++) { const i = i0 + k; if (i >= L.length) break; L[i] += src[k] * gl; if (Rr) Rr[i] += src[k] * gr; }
  }
  // one synth note (saw / sine / tri) with low-pass, vibrato, optional detuned twin
  function note(out, t0, dur, f, vol, o) {
    o = o || {};
    const L = out[0], Rr = out[1], i0 = round(t0 * SR), att = o.att || .02, rel = o.rel || .15, N = round((dur + rel) * SR);
    const a = 1 - exp(-TAU * (o.lp || 2400) / SR), vib = o.vib || 0, det = o.det || 0, wave = o.wave || 'saw';
    const pan = o.pan || 0, gl = Rr ? vol * cos((pan + 1) * PI / 4) : vol, gr = vol * sin((pan + 1) * PI / 4), f2m = Math.pow(2, det / 1200);
    let ph = 0, ph2 = 0, y = 0, y2 = 0;
    for (let k = 0; k < N; k++) {
      const i = i0 + k; if (i >= L.length) break;
      const t = k / SR, ff = f * (1 + vib * sin(TAU * 5.4 * t) * min(1, t * 2.5)), d1 = ff / SR;
      ph += d1; ph -= floor(ph);
      let s;
      if (wave === 'sine') s = sin(TAU * ph); else if (wave === 'tri') s = 4 * abs(ph - .5) - 1; else s = 2 * ph - 1 - blep(ph, d1);
      if (det) { const d2 = ff * f2m / SR; ph2 += d2; ph2 -= floor(ph2); s = (s + 2 * ph2 - 1 - blep(ph2, d2)) * .5; }
      y += a * (s - y); y2 += a * (y - y2);
      let e = t < att ? t / att : 1; if (t > dur) e *= exp(-(t - dur) / rel * 4.6); if (o.dec) e *= exp(-t * o.dec);
      const v = y2 * e; L[i] += v * gl; if (Rr) Rr[i] += v * gr;
    }
  }

  // ================= WEAPON SOUNDS =================
  const GUNS = {
    ak47:    { dur: .55, crack: 1.0, crackD: 160, body: 1.3, bodyF: 3200, bodyD: 18, thump: .8,  thumpF: 160, thumpD: 28, tail: .35, tailF: 700,  tailD: 7,   drive: 1.5, echo: [[.11, .18], [.21, .1]] },
    m4:      { dur: .45, crack: 1.2, crackD: 200, body: 1.0, bodyF: 4200, bodyD: 22, thump: .5,  thumpF: 190, thumpD: 34, tail: .3,  tailF: 900,  tailD: 8,   drive: 1.5, echo: [[.1, .15]] },
    mg:      { dur: .36, crack: .9,  crackD: 150, body: 1.4, bodyF: 2800, bodyD: 24, thump: 1.0, thumpF: 130, thumpD: 30, tail: .2,  tailF: 600,  tailD: 10,  drive: 1.6, echo: [] },
    pistol:  { dur: .4,  crack: 1.3, crackD: 260, body: .9,  bodyF: 5000, bodyD: 30, thump: .35, thumpF: 220, thumpD: 45, tail: .3,  tailF: 1200, tailD: 9,   drive: 1.4, echo: [[.08, .2]] },
    shotgun: { dur: .85, crack: 1.0, crackD: 90,  body: 2.0, bodyF: 2000, bodyD: 9,  thump: 1.4, thumpF: 90,  thumpD: 14, tail: .6,  tailF: 500,  tailD: 4.5, drive: 1.8, echo: [[.13, .2], [.26, .12]] },
    sniper:  { dur: 1.7, crack: 1.5, crackD: 60,  body: 1.5, bodyF: 3500, bodyD: 8,  thump: 1.2, thumpF: 80,  thumpD: 10, tail: .9,  tailF: 600,  tailD: 2.6, drive: 1.6, echo: [[.18, .3], [.4, .2], [.7, .12]] }
  };
  function gun(p) {
    const n = buf(p.dur), hp = hpf(), lb = lpf(), lt = lpf(); let ph = 0;
    for (let i = 0; i < n.length; i++) {
      const t = i / SR, x = R();
      const crack = hp(x, 2500) * exp(-t * p.crackD) * p.crack;
      const body = lb(x, p.bodyF * exp(-t * 12) + 200) * exp(-t * p.bodyD) * p.body;
      ph += TAU * p.thumpF * (.35 + .65 * exp(-t * 30)) / SR;
      const thump = sin(ph) * exp(-t * p.thumpD) * p.thump;
      const tail = lt(R(), p.tailF) * exp(-t * p.tailD) * p.tail;
      n[i] = tanh((crack + body + thump + tail) * p.drive);
    }
    return norm(echo(n, p.echo), .95);
  }
  function farify(a, g) {   // distant version: muffled + long echo
    const n = new Float32Array(a.length + round(.55 * SR)); n.set(a);
    const l1 = lpf(), l2 = lpf(); for (let i = 0; i < n.length; i++) n[i] = l2(l1(n[i], 1100), 1100);
    echo(n, [[.22, .35], [.43, .22]]); return norm(n, g || .8);
  }
  function rocket() {
    const n = buf(1.2), b = svf(), lo = lpf(); let ph = 0;
    for (let i = 0; i < n.length; i++) {
      const t = i / SR, x = R();
      const sweep = b(x, 250 + 1700 * min(1, t * 3), 1.2) * min(1, t * 40) * exp(-t * 2.6);
      const foomp = lo(x, 400) * exp(-t * 14) * 1.2;
      ph += TAU * (60 + 60 * exp(-t * 20)) / SR;
      n[i] = tanh((sweep * 3 + foomp + sin(ph) * exp(-t * 7) * 1.2) * 1.3);
    }
    return norm(n, .95);
  }
  function laser() {
    const n = buf(.32), hp = hpf(); let ph = 0;
    for (let i = 0; i < n.length; i++) {
      const t = i / SR; ph += TAU * (2400 * exp(-t * 9) + 320) / SR;
      const s = sin(ph) + .45 * sin(ph * 2 + sin(ph * .5)) + .25 * sin(ph * 3);
      n[i] = s * exp(-t * 8) * .8 + hp(R(), 5000) * exp(-t * 40) * .5;
    }
    return norm(n, .9);
  }
  function explosion(size) {
    const n = buf(1.6 + size), hp = hpf(), lr = lpf(), ld = lpf(); let ph = 0;
    for (let i = 0; i < n.length; i++) {
      const t = i / SR, x = R();
      const crack = hp(x, 1200) * exp(-t * 35);
      const rumble = lr(x, 1300 * exp(-t * 2.2) + 70) * min(1, t * 90) * exp(-t * 1.9 / size) * 2.2;
      ph += TAU * (28 + 55 * exp(-t * 1.6)) / SR;
      const sub = sin(ph) * exp(-t * 2.6 / size) * 1.5;
      const deb = ld(random() < .02 * exp(-t * 2.2) ? R() * 2 : 0, 1800) * 2;
      n[i] = tanh((crack + rumble + sub + deb) * 1.4);
    }
    return norm(echo(n, [[.15, .2], [.33, .12]]), .98);
  }

  // ================= VOICES (formant synthesis) =================
  const VOW = { a: [730, 1090, 2440], o: [570, 840, 2410], u: [300, 870, 2240], e: [530, 1840, 2480], i: [270, 2290, 3010], uh: [640, 1190, 2390] };
  function voice(o) {
    const n = buf(o.dur), f1 = svf(), f2 = svf(), f3 = svf(), lo = lpf(); let ph = 0;
    const A = VOW[o.a], B = VOW[o.b || o.a];
    for (let i = 0; i < n.length; i++) {
      const t = i / SR, u = t / o.dur, f0 = (o.f0 + (o.f1 - o.f0) * u) * (1 + (o.vib || 0) * sin(TAU * 5.5 * t) + .012 * R()), dt = f0 / SR;
      ph += dt; if (ph >= 1) ph -= 1;
      let g = 2 * ph - 1 - blep(ph, dt); g = g * (1 - o.breath) + R() * o.breath;
      const m = u * u * (3 - 2 * u);
      const s = f1(g, A[0] + (B[0] - A[0]) * m, 7) + .7 * f2(g, A[1] + (B[1] - A[1]) * m, 9) + .35 * f3(g, A[2] + (B[2] - A[2]) * m, 11);
      n[i] = lo(tanh(s * (o.drive || 1.5)) * min(1, t / (o.att || .02)) * exp(-t * o.dec), 4500);
    }
    return norm(n, .9);
  }
  const VOICES = {
    die: [
      { dur: .95, f0: 250, f1: 105, a: 'a',  b: 'o', att: .02,  dec: 2.2, breath: .10, vib: .02,  drive: 2.5 },
      { dur: .6,  f0: 175, f1: 88,  a: 'uh', b: 'o', att: .015, dec: 4,   breath: .18, vib: .01,  drive: 2.2 },
      { dur: 1.1, f0: 310, f1: 130, a: 'a',  b: 'u', att: .02,  dec: 1.7, breath: .08, vib: .025, drive: 2.8 }],
    hurt: [
      { dur: .22, f0: 145, f1: 105, a: 'uh',          att: .01, dec: 10, breath: .20 },
      { dur: .26, f0: 175, f1: 120, a: 'a',  b: 'uh', att: .01, dec: 9,  breath: .12 },
      { dur: .25, f0: 125, f1: 90,  a: 'o',            att: .01, dec: 10, breath: .25 }],
    exert: [
      { dur: .17, f0: 130, f1: 105, a: 'uh', att: .008, dec: 14, breath: .55 },
      { dur: .20, f0: 150, f1: 110, a: 'a',  att: .008, dec: 12, breath: .50 }]
  };
  // muffled radio chatter: speech-like syllables through a radio filter, squelch at both ends
  function radio(sec) {
    const n = buf(sec), f1 = svf(), f2 = svf(), f3 = svf(), hp = hpf(), lp = lpf(), lp2 = lpf(), hp2 = hpf(), keys = Object.keys(VOW); let ph = 0;
    const syl = []; let t = .1;
    while (t < sec - .3) {
      const words = 2 + floor(random() * 3), base = rnd(95, 135);
      for (let k = 0; k < words && t < sec - .3; k++) { const d = rnd(.08, .16); syl.push({ t0: t, d, f0: base * rnd(.9, 1.15), v: VOW[pick(keys)], cn: random() < .6 ? rnd(1800, 5000) : 0 }); t += d; }
      t += rnd(.07, .2);
    }
    let si = 0;
    for (let i = 0; i < n.length; i++) {
      const tt = i / SR; while (si < syl.length - 1 && tt >= syl[si + 1].t0) si++;
      const s = syl[si], lc = tt - s.t0; let v = 0;
      if (lc >= 0 && lc < s.d) {
        const u = lc / s.d, dt = s.f0 * (1 - .08 * u) / SR; ph += dt; if (ph >= 1) ph -= 1;
        const g = 2 * ph - 1 - blep(ph, dt) + R() * .08;
        v = (f1(g, s.v[0], 7) + .7 * f2(g, s.v[1], 9) + .35 * f3(g, s.v[2], 11)) * pow08(sin(PI * u));
        if (s.cn && lc < .03) v += hp2(R(), s.cn) * (1 - lc / .03) * .8;
      }
      if (tt < .07) v += R() * (1 - tt / .07) * .7;
      if (tt > sec - .1) v += R() * ((sec - tt) / .1) * .6;
      n[i] = tanh(lp2(hp(lp(v, 2800), 350), 2800) * 3) + R() * .03;
    }
    return norm(n, .85);
  }
  const pow08 = x => Math.pow(x, .6);

  // ================= MOVEMENT SOUNDS =================
  const SURFACES = ['concrete', 'sand', 'snow', 'grass', 'metal'];
  function stepSnd(kind) {
    const n = buf(kind === 'snow' ? .22 : .17), lp = lpf(), hp = hpf(), pv = rnd(.9, 1.12), gr = [];
    if (kind === 'snow') for (let k = 0; k < 7; k++) gr.push([rnd(0, .09), rnd(.4, 1)]);
    for (let i = 0; i < n.length; i++) {
      const t = i / SR, x = R(); let s = 0;
      if (kind === 'concrete') s = lp(x, 2600 * exp(-t * 40) + 400) * exp(-t * 55) + sin(TAU * 95 * pv * t) * exp(-t * 60) * .9 + hp(x, 3500) * exp(-t * 300) * .5;
      else if (kind === 'sand') s = lp(x, 1500) * (1 - exp(-t * 400)) * exp(-t * 24) * 1.1 + sin(TAU * 70 * pv * t) * exp(-t * 45) * .35;
      else if (kind === 'snow') { let ge = 0; for (const g of gr) { const d = t - g[0]; if (d >= 0) ge += g[1] * exp(-d * 330); } s = hp(x, 2200) * ge * .9 + sin(TAU * 80 * pv * t) * exp(-t * 50) * .3 + lp(x, 900) * exp(-t * 30) * .3; }
      else if (kind === 'grass') s = lp(x, 1100) * exp(-t * 32) * 1.1 + sin(TAU * 78 * pv * t) * exp(-t * 50) * .6 + hp(x, 3000) * exp(-t * 20) * .12;
      else s = sin(TAU * 85 * pv * t) * exp(-t * 55) * .8 + (sin(TAU * 410 * pv * t) * .5 + sin(TAU * 1130 * pv * t) * .3 + sin(TAU * 1790 * pv * t) * .15) * exp(-t * 32) * .6 + hp(x, 2500) * exp(-t * 250) * .6;
      n[i] = s;
    }
    return norm(n, .9);
  }
  function land() {
    const n = buf(.3), lp = lpf(), hp = hpf(); let ph = 0;
    for (let i = 0; i < n.length; i++) {
      const t = i / SR, x = R(); ph += TAU * (55 + 35 * exp(-t * 20)) / SR;
      n[i] = lp(x, 1400 * exp(-t * 18) + 200) * exp(-t * 28) * 1.2 + sin(ph) * exp(-t * 22) * 1.3 + hp(random() < .03 * exp(-t * 10) ? R() : 0, 2000) * .6;
    }
    return norm(n, .9);
  }
  function jump() {
    const n = buf(.15), lp = lpf(); let ph = 0;
    for (let i = 0; i < n.length; i++) { const t = i / SR; ph += TAU * 110 / SR; n[i] = lp(R(), 900) * sin(PI * t / .15) * .6 + sin(ph) * exp(-t * 40) * .5; }
    return norm(n, .8);
  }
  function loopBuf(sec, fn) {   // seamless loop via crossfade
    const L = round(sec * SR), C = round(.15 * SR), n = new Float32Array(L + C);
    for (let i = 0; i < n.length; i++) n[i] = fn(i / SR, i);
    const out = new Float32Array(L);
    for (let i = 0; i < L; i++) out[i] = i < C ? n[i] * (i / C) + n[L + i] * (1 - i / C) : n[i];
    return norm(out, .9, true);
  }
  function jetLoop() {
    const l1 = lpf(), l2 = lpf(), l3 = lpf(), T = 1.8;
    return loopBuf(T, (t) => { const x = R(); return (l1(x, 2200) * .8 + l2(x, 500) * 1.2) * (1 + .3 * sin(TAU * 31.11 * t) + .15 * sin(TAU * 7.22 * t)) + sin(TAU * 62.22 * t) * .35 + l3(x, 6000) * .12; });
  }
  function windLoop() {
    const l1 = lpf(), l2 = lpf();
    return loopBuf(4, (t) => { const x = R(); return (l1(x, 380) * (.6 + .4 * sin(TAU * .25 * t)) + l2(x, 900) * .25 * (.5 + .5 * sin(TAU * .5 * t + 1))); });
  }

  // ================= COMBAT SOUNDS =================
  function whiz() {
    const n = buf(.16), b = svf();
    for (let i = 0; i < n.length; i++) { const t = i / SR, u = t / .16; n[i] = b(R(), 5200 - 3600 * u, 2.5) * Math.pow(sin(PI * u), 2) * 6; }
    return norm(n, .8);
  }
  function hitFlesh() {
    const n = buf(.16), lp = lpf(), hp = hpf(); let ph = 0;
    for (let i = 0; i < n.length; i++) { const t = i / SR, x = R(); ph += TAU * (60 + 70 * exp(-t * 30)) / SR; n[i] = lp(x, 1500 * exp(-t * 30) + 250) * exp(-t * 45) * 1.2 + sin(ph) * exp(-t * 50) * .9 + hp(x, 2000) * exp(-t * 160) * .3; }
    return norm(n, .9);
  }
  function ricochet() {
    const n = buf(.3), hp = hpf(), f = rnd(1800, 3200);
    for (let i = 0; i < n.length; i++) { const t = i / SR; n[i] = (sin(TAU * f * t) * .7 + sin(TAU * f * 2.4 * t) * .25) * exp(-t * 16) + hp(R(), 3500) * exp(-t * 120) * .6; }
    return norm(n, .8);
  }
  function tck() {
    const n = buf(.08), b = svf(), lp = lpf();
    for (let i = 0; i < n.length; i++) { const t = i / SR, x = R(); n[i] = b(x, 1800, 2) * exp(-t * 110) * 3 + lp(x, 500) * exp(-t * 90); }
    return norm(n, .8);
  }
  function punch() {
    const n = buf(.3), b = svf(), lp = lpf(); let ph = 0;
    for (let i = 0; i < n.length; i++) {
      const t = i / SR, x = R(), h = t - .09; let s = t < .1 ? b(x, 400 + 2500 * (t / .1), 1.5) * sin(PI * min(1, t / .1)) * 1.5 : 0;
      if (h >= 0) { ph += TAU * (70 + 50 * exp(-h * 30)) / SR; s += lp(x, 700 * exp(-h * 30) + 150) * exp(-h * 35) * 1.3 + sin(ph) * exp(-h * 30) * 1.2; }
      n[i] = s;
    }
    return norm(n, .9);
  }
  // mechanical click / clack used by reloads, weapon swaps, pickups
  function mech(o) {
    const n = buf(o.dur), hp = hpf(); let ph = 0;
    for (let i = 0; i < n.length; i++) {
      const t = i / SR; let s = hp(R(), 2200) * exp(-t * (o.nd || 150)) * (o.noise || .8);
      ph += TAU * (o.th || 140) * (.6 + .4 * exp(-t * 30)) / SR; s += sin(ph) * exp(-t * (o.td || 45)) * (o.thump || .5);
      for (const f of o.ring || []) s += sin(TAU * f * t) * exp(-t * (o.rd || 45)) * .25;
      n[i] = s;
    }
    return n;
  }
  const seq = (dur, parts) => { const o = [buf(dur)]; for (const [src, t, g] of parts) mix(o, src, t, g); return norm(o[0], .9); };
  const M = {};  // cached mech parts
  const mp = k => M[k] || (M[k] = ({
    out:   () => mech({ dur: .2,  noise: .9, nd: 90,  th: 170, td: 35, thump: .8,  ring: [1900, 2600], rd: 55 }),
    in:    () => mech({ dur: .25, noise: .6, nd: 70,  th: 130, td: 28, thump: 1.1, ring: [1400, 2100], rd: 40 }),
    chk:   () => mech({ dur: .1,  noise: .9, nd: 130, th: 200, td: 60, thump: .4,  ring: [2400, 3300], rd: 70 }),
    clack: () => mech({ dur: .14, noise: .8, nd: 90,  th: 120, td: 38, thump: .9,  ring: [900, 1500],  rd: 45 }),
    shell: () => mech({ dur: .12, noise: .7, nd: 110, th: 300, td: 70, thump: .3,  ring: [2400, 3600], rd: 70 }),
    heavy: () => mech({ dur: .5,  noise: .8, nd: 50,  th: 90,  td: 20, thump: 1.1, ring: [300, 620, 980], rd: 14 })
  })[k]());
  const bolt = () => seq(.3, [[mp('chk'), 0], [mp('clack'), .09, 1]]);
  const bell = (f, t, d, g) => { const n = buf(d); for (let i = 0; i < n.length; i++) { const x = i / SR; n[i] = (sin(TAU * f * x) + .35 * sin(TAU * f * 2.76 * x)) * exp(-x * 9) * (g || 1); } return n; };

  // ================= UI + REWARD SOUNDS =================
  function uiTap() { const n = buf(.08), hp = hpf(); for (let i = 0; i < n.length; i++) { const t = i / SR; n[i] = sin(TAU * 1500 * t) * exp(-t * 140) * .5 + hp(R(), 3000) * exp(-t * 500) * .6 + sin(TAU * 260 * t) * exp(-t * 100) * .6; } return norm(n, .8); }
  function uiOk() { return seq(.45, [[uiTap(), 0], [bell(880, .06, .3, .5), .03], [bell(1320, .12, .3, .5), .09]]); }
  function uiBack() { const n = buf(.14); let ph = 0; for (let i = 0; i < n.length; i++) { const t = i / SR; ph += TAU * (700 - 280 * min(1, t / .1)) / SR; n[i] = sin(ph) * exp(-t * 40) * .8 + sin(TAU * 200 * t) * exp(-t * 60) * .6; } return norm(n, .8); }
  function uiBuy() { return seq(.7, [[bell(1568, .5, .5, .7), 0], [bell(2093, .5, .5, .6), .09], [bell(3136, .5, .4, .2), .09], [uiTap(), 0, .5]]); }
  function uiErr() { const n = buf(.3); for (let i = 0; i < n.length; i++) { const t = i / SR, ph = (130 * t) % 1, g = (t < .1 || (t > .16 && t < .26)) ? 1 : 0; n[i] = tanh((2 * ph - 1) * 3) * g * .6; } return norm(n, .7); }
  function success() { return seq(.95, [[bell(1047, .5, .4, .7), 0], [bell(1319, .5, .4, .7), .09], [bell(1568, .5, .4, .7), .18], [bell(2093, .6, .5, .8), .27]]); }
  function killConfirm() { const t = buf(.5); for (let i = 0; i < t.length; i++) { const x = i / SR; t[i] = sin(TAU * 90 * x) * exp(-x * 30) * .8; } return seq(.55, [[bell(1318, .45, .45, .8), 0], [bell(1975, .45, .45, .5), .0], [t, 0, 1]]); }
  function tickBeep() { const n = buf(.1); for (let i = 0; i < n.length; i++) { const t = i / SR; n[i] = sin(TAU * 1100 * t) * exp(-t * 40) * (t < .08 ? 1 : 0); } return norm(n, .7); }
  function spawnS() { const n = buf(.55), hp = hpf(); let ph = 0; for (let i = 0; i < n.length; i++) { const t = i / SR, u = t / .55; ph += TAU * (280 + 900 * u * u) / SR; n[i] = sin(ph) * sin(PI * u) * (.8 + .2 * sin(TAU * 18 * t)) + hp(R(), 5000) * sin(PI * u) * .15; } return norm(n, .6); }
  function heart() { const n = buf(.5); for (let i = 0; i < n.length; i++) { const t = i / SR, t2 = t - .19; n[i] = sin(TAU * 52 * t) * exp(-t * 20) + (t2 > 0 ? sin(TAU * 46 * t2) * exp(-t2 * 22) * .7 : 0); } return norm(n, .85); }
  function pickHp() { return seq(.75, [[bell(784, .5, .4, .6), 0], [bell(1175, .5, .4, .6), .08], [bell(1568, .5, .5, .7), .16]]); }
  function pickWp() { return seq(.65, [[bolt(), 0], [bell(1760, .4, .4, .4), .16]]); }
  function brass(dur, notes, lpHz, relT) {
    const o = [buf(dur)]; for (const [t0, d, m, v] of notes) { note(o, t0, d, mtof(m), v, { lp: lpHz, att: .03, rel: relT || .25, vib: .006, det: 7 }); note(o, t0, d, mtof(m - 12), v * .5, { lp: lpHz * .6, att: .04, rel: relT || .25 }); }
    return norm(o[0], .85);
  }
  const win = () => brass(2.6, [[0, .2, 60, .5], [.2, .2, 64, .5], [.4, .2, 67, .5], [.6, 1.4, 72, .6], [.6, 1.4, 67, .4], [.6, 1.4, 64, .4]], 3000, .5);
  const lose = () => brass(3.2, [[0, .35, 57, .5], [.4, .35, 55, .5], [.8, .35, 52, .5], [1.2, 1.5, 45, .6], [1.2, 1.5, 52, .4]], 1400, .6);

  // ================= SOUND REGISTRY =================
  const GEN = {}, NV = {};
  const def = (name, nv, fn) => { GEN[name] = fn; NV[name] = nv; };
  const RAW = {}, ABUF = {};
  function raws(name) { if (!RAW[name]) { const a = []; for (let i = 0; i < NV[name]; i++) a.push(GEN[name](i)); RAW[name] = a; } return RAW[name]; }

  def('uiTap', 1, uiTap); def('uiOk', 1, uiOk); def('uiBack', 1, uiBack); def('uiBuy', 1, uiBuy); def('uiErr', 1, uiErr);
  def('success', 1, success); def('killConfirm', 1, killConfirm); def('tick', 1, tickBeep); def('spawn', 1, spawnS); def('heart', 1, heart);
  def('pickHp', 1, pickHp); def('pickWp', 1, pickWp); def('win', 1, win); def('lose', 1, lose);
  for (const k in GUNS) { def('shot:' + k, 2, () => gun(GUNS[k])); def('shotFar:' + k, 1, () => farify(raws('shot:' + k)[0])); }
  def('shot:bazooka', 1, rocket); def('shotFar:bazooka', 1, () => farify(raws('shot:bazooka')[0]));
  def('shot:laser', 2, laser); def('shotFar:laser', 1, () => farify(raws('shot:laser')[0], .6));
  def('boomS', 2, () => explosion(1)); def('boomL', 1, () => explosion(1.5)); def('boomFar', 1, () => farify(raws('boomS')[0], .9));
  for (const k of SURFACES) def('step:' + k, 3, () => stepSnd(k));
  def('land', 2, land); def('jump', 1, jump); def('jetLoop', 1, jetLoop); def('windLoop', 1, windLoop);
  def('whiz', 3, whiz); def('hit', 2, hitFlesh); def('ric', 3, ricochet); def('tck', 3, tck); def('punch', 2, punch);
  def('throw', 1, () => { const o = [buf(.6)], b = svf(), hp = hpf(); mix(o, mech({ dur: .08, noise: 1, nd: 220, th: 300, td: 90, thump: .2, ring: [2900], rd: 90 }), 0); mix(o, mech({ dur: .08, noise: 1, nd: 220, th: 300, td: 90, thump: .2, ring: [3100], rd: 90 }), .07, .8); const w = buf(.45); for (let i = 0; i < w.length; i++) { const u = i / SR / .45; w[i] = b(R(), 300 + 1500 * sin(PI * u), 1.5) * sin(PI * u) * 2; } mix(o, w, .13, .8); return norm(o[0], .9); });
  def('swap', 1, () => seq(.16, [[mp('chk'), 0]]));
  def('magOut', 1, () => seq(.22, [[mp('out'), 0]])); def('magIn', 1, () => seq(.26, [[mp('in'), 0]])); def('bolt', 1, bolt);
  def('shell', 2, () => seq(.14, [[mp('shell'), 0]]));
  def('pump', 1, () => seq(.6, [[bolt(), 0], [bolt(), .24, .9]]));
  def('boltAction', 1, () => seq(.55, [[mp('chk'), 0], [mp('chk'), .12, .8], [mp('clack'), .3, 1]]));
  def('rocketLoad', 1, () => seq(.55, [[mp('heavy'), 0]]));
  VOICES_NAMES();
  function VOICES_NAMES() { for (const k in VOICES) def('voice:' + k, VOICES[k].length, i => voice(VOICES[k][i])); def('radio', 5, i => radio(1.5 + i * .45)); }

  // ================= MUSIC (rendered once, then looped) =================
  const tickAsync = () => new Promise(r => setTimeout(r, 0));
  function drums() {
    const kick = (() => { const n = buf(.4), hp = hpf(); let ph = 0; for (let i = 0; i < n.length; i++) { const t = i / SR; ph += TAU * (45 + 110 * exp(-t * 38)) / SR; n[i] = tanh((sin(ph) * exp(-t * 9) + hp(R(), 2000) * exp(-t * 300) * .3) * 1.4); } return norm(n, .95); })();
    const snare = (() => { const n = buf(.28), hp = hpf(), b = svf(); for (let i = 0; i < n.length; i++) { const t = i / SR, x = R(); n[i] = hp(x, 1200) * exp(-t * 20) * .8 + b(x, 2200, 1.5) * exp(-t * 28) * 1.8 + sin(TAU * 185 * t) * exp(-t * 32) * .5; } return norm(n, .95); })();
    const hat = (open) => { const n = buf(open ? .35 : .08), hp = hpf(); for (let i = 0; i < n.length; i++) { const t = i / SR; n[i] = hp(R(), 7000) * exp(-t * (open ? 14 : 80)); } return norm(n, .9); };
    const timp = (f) => { const n = buf(1.4), lp = lpf(); let ph = 0; for (let i = 0; i < n.length; i++) { const t = i / SR; ph += TAU * f * (1 + .06 * exp(-t * 20)) / SR; n[i] = sin(ph) * exp(-t * 3.2) + sin(ph * 1.5) * exp(-t * 5) * .35 + lp(R(), 600) * exp(-t * 60) * .5; } return norm(n, .95); };
    const crash = (() => { const n = buf(2.2), hp = hpf(), b = svf(); for (let i = 0; i < n.length; i++) { const t = i / SR, x = R(); n[i] = hp(x, 3500) * exp(-t * 2.4) + b(x, 7500, 3) * exp(-t * 3) * 1.5; } return norm(n, .9); })();
    const riser = (sec) => { const n = buf(sec), hp = hpf(); for (let i = 0; i < n.length; i++) { const u = i / n.length; n[i] = hp(R(), 2500 + 4000 * u) * u * u; } return norm(n, .9); };
    return { kick, snare, hat: hat(false), open: hat(true), timp, crash, riser };
  }
  function finish(out, N) {   // fold the ringing tail onto the start for a seamless loop, then master
    let pk = 1e-9;
    for (const c of out) { for (let i = N; i < c.length; i++) c[i - N] += c[i]; }
    const res = out.map(c => c.slice(0, N));
    for (const c of res) for (let i = 0; i < N; i++) { c[i] = tanh(c[i] * 1.25); const v = abs(c[i]); if (v > pk) pk = v; }
    const g = .85 / pk; for (const c of res) for (let i = 0; i < N; i++) c[i] *= g;
    return { L: res[0], R: res[1] };
  }
  async function renderBattle() {
    const bpm = 112, st = 60 / bpm / 4, bars = 8, N = round(bars * 16 * st * SR), out = [new Float32Array(N + round(2 * SR)), new Float32Array(N + round(2 * SR))], D = drums();
    const T = (b, s) => (b * 16 + s) * st;
    const CH = [{ r: 33, c: [57, 60, 64] }, { r: 29, c: [53, 57, 60] }, { r: 36, c: [55, 60, 64] }, { r: 31, c: [55, 59, 62] }, { r: 33, c: [57, 60, 64] }, { r: 29, c: [53, 57, 60] }, { r: 38, c: [50, 53, 57] }, { r: 40, c: [56, 59, 64] }];
    const MEL = [[[0, 6, 76], [6, 2, 74], [8, 4, 72], [12, 4, 76]], [[0, 6, 77], [6, 2, 76], [8, 4, 72], [12, 4, 69]], [[0, 6, 79], [6, 2, 76], [8, 4, 72], [12, 4, 76]], [[0, 4, 74], [4, 4, 71], [8, 4, 67], [12, 4, 74]],
      [[0, 6, 81], [6, 2, 79], [8, 4, 76], [12, 4, 72]], [[0, 4, 81], [4, 2, 79], [6, 2, 77], [8, 4, 76], [12, 4, 72]], [[0, 6, 74], [6, 2, 77], [8, 4, 81], [12, 4, 77]], [[0, 4, 71], [4, 4, 68], [8, 4, 71], [12, 4, 76]]];
    const KICK = [0, 3, 6, 8, 11, 14], ACC = [1, .55, .8, .55, .9, .55, .8, .6];
    for (let b = 0; b < bars; b++) {
      const ch = CH[b];
      ch.c.forEach((m, k) => note(out, T(b, 0), 16 * st, mtof(m), .085, { lp: 1300, att: .3, rel: .4, det: 8, pan: (k - 1) * .5 }));
      for (let k = 0; k < 8; k++) { note(out, T(b, k * 2), st * 1.7, mtof(ch.r + 12), .2 * ACC[k], { lp: 520, att: .004, rel: .05 }); note(out, T(b, k * 2), st * 1.7, mtof(ch.r), .22 * ACC[k], { wave: 'sine', att: .004, rel: .06 }); }
      await tickAsync();
      for (const [s, d, m] of MEL[b]) note(out, T(b, s), d * st * .96, mtof(m), .16, { lp: 2300, att: .03, rel: .12, vib: .006, det: 6, pan: .05 });
      await tickAsync();
      for (const s of KICK) mix(out, D.kick, T(b, s), s === 0 ? .9 : .65);
      mix(out, D.snare, T(b, 4), .8); mix(out, D.snare, T(b, 12), .8); mix(out, D.snare, T(b, 7), .16); mix(out, D.snare, T(b, 15), .16);
      if (b === 3) for (let s = 12; s < 16; s++) mix(out, D.snare, T(b, s), .3 + (s - 12) * .15);
      if (b === 7) for (let s = 8; s < 16; s++) mix(out, D.snare, T(b, s), .25 + (s - 8) * .1);
      for (let s = 0; s < 16; s += 2) mix(out, D.hat, T(b, s), s % 4 ? .26 : .16, s % 4 ? .35 : -.35);
      if (b % 2 === 0) mix(out, D.open, T(b, 10), .2, .3);
      if (b === 0 || b === 4) { mix(out, D.timp(mtof(45)), T(b, 0), .8); mix(out, D.crash, T(b, 0), .45); }
      if (b === 3 || b === 7) mix(out, D.timp(mtof(40)), T(b, 8), .7);
      if (b === 7) mix(out, D.riser(8 * st), T(b, 8), .5);
      await tickAsync();
    }
    return finish(out, N);
  }
  async function renderMenu() {
    const bpm = 84, st = 60 / bpm / 4, bars = 8, N = round(bars * 16 * st * SR), out = [new Float32Array(N + round(2.5 * SR)), new Float32Array(N + round(2.5 * SR))], D = drums();
    const T = (b, s) => (b * 16 + s) * st;
    const CH = [{ r: 38, c: [53, 57, 62] }, { r: 34, c: [53, 58, 62] }, { r: 41, c: [53, 57, 60] }, { r: 36, c: [52, 55, 60] }, { r: 38, c: [53, 57, 62] }, { r: 34, c: [53, 58, 62] }, { r: 31, c: [55, 58, 62] }, { r: 33, c: [52, 57, 61] }];
    const MEL = [[[0, 8, 74], [8, 8, 77]], [[0, 8, 74], [8, 8, 70]], [[0, 8, 69], [8, 4, 72], [12, 4, 77]], [[0, 12, 76], [12, 4, 74]],
      [[0, 8, 81], [8, 8, 77]], [[0, 4, 79], [4, 4, 77], [8, 8, 74]], [[0, 8, 70], [8, 4, 74], [12, 4, 79]], [[0, 8, 76], [8, 4, 73], [12, 4, 69]]];
    for (let b = 0; b < bars; b++) {
      const ch = CH[b];
      ch.c.forEach((m, k) => note(out, T(b, 0), 16 * st, mtof(m), .1, { lp: 1100, att: .5, rel: .6, det: 9, pan: (k - 1) * .6 }));
      note(out, T(b, 0), 16 * st * .98, mtof(ch.r), .3, { wave: 'sine', att: .05, rel: .3 }); note(out, T(b, 0), 16 * st * .98, mtof(ch.r + 12), .1, { lp: 450, att: .08, rel: .3 });
      await tickAsync();
      for (const [s, d, m] of MEL[b]) note(out, T(b, s), d * st * .97, mtof(m), .22, { lp: 1500, att: .12, rel: .3, vib: .008, det: 5, pan: -.05 });
      await tickAsync();
      mix(out, D.timp(mtof(ch.r + 12)), T(b, 0), .55); if (b % 2 === 0) mix(out, D.timp(mtof(ch.r + 12)), T(b, 8), .3);
      if (b >= 4) { mix(out, D.snare, T(b, 4), .22); mix(out, D.snare, T(b, 12), .22); }
      if (b === 3 || b === 7) for (let s = 8; s < 16; s++) mix(out, D.snare, T(b, s), .12 + (s - 8) * .07);
      if (b === 0 || b === 4) mix(out, D.crash, T(b, 0), .35);
      if (b === 7) mix(out, D.riser(8 * st), T(b, 8), .4);
      await tickAsync();
    }
    return finish(out, N);
  }

  // ================= RUNTIME =================
  let ctx = null, master, comp, busSfx, busMus, busVox, busAmb, revIn;
  let active = 0, paused = false, inGame = false, unlocked = false, lastOn = null, lastMus = null;
  const L = { x: 1200, y: 800 }, MUSBASE = MUSIC_LEVEL, MUSVOL = { menu: .9, battle: .65 };
  const MUS = {}, last = {}, AU = { sec: -1, hb: 0, whiz: 0, amb: { s: 1, b: 8, r: 10 } };
  let cur = null, musWant = 'menu', musHold = 0, wind = null, dbg = null;

  const on = () => typeof SAVE === 'undefined' || SAVE.sound !== false;
  const musOn = () => typeof SAVE === 'undefined' || SAVE.music !== false;
  const voiceOn = () => USE_SPEECH && typeof SAVE !== 'undefined' && SAVE.voice !== false && SAVE.sound !== false;
  const gm = () => (typeof G !== 'undefined' ? G : null);
  const gate = (k, ms) => { const t = nowMs(); if (last[k] && t - last[k] < ms) return false; last[k] = t; return true; };
  const hash = s => { s = String(s); let h = 0; for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0; return abs(h); };
  const vrate = id => .84 + (hash(id) % 36) / 100;

  function toAB(f) { const b = ctx.createBuffer(1, f.length, SR); b.getChannelData(0).set(f); return b; }
  function getBuf(name, v) {
    if (!GEN[name]) return null;
    const arr = ABUF[name] || (ABUF[name] = raws(name).map(toAB));
    return arr[v != null ? v % arr.length : floor(random() * arr.length)];
  }
  function makeIR() {
    const len = round(1.8 * SR), b = ctx.createBuffer(2, len, SR);
    for (let c = 0; c < 2; c++) { const d = b.getChannelData(c), l = lpf(); for (let i = 0; i < len; i++) d[i] = l(R(), 5000) * exp(-i / SR * 3.4) * .7; }
    return b;
  }
  function create() {
    if (ctx) return ctx;
    const AC_ = W.AudioContext || W.webkitAudioContext; if (!AC_) return null;
    try { ctx = new AC_({ latencyHint: 'interactive' }); } catch (e) { try { ctx = new AC_(); } catch (e2) { return null; } }
    master = ctx.createGain(); master.gain.value = on() ? 1 : 0;
    comp = ctx.createDynamicsCompressor(); comp.threshold.value = -16; comp.knee.value = 14; comp.ratio.value = 5; comp.attack.value = .004; comp.release.value = .18;
    master.connect(comp); comp.connect(ctx.destination);
    const bus = v => { const g = ctx.createGain(); g.gain.value = v; g.connect(master); return g; };
    busSfx = bus(.9); busVox = bus(.9); busAmb = bus(.6); busMus = bus(MUSBASE);
    revIn = ctx.createConvolver(); revIn.buffer = makeIR(); const rg = ctx.createGain(); rg.gain.value = .22; revIn.connect(rg); rg.connect(busMus);
    lastOn = on(); lastMus = musOn();
    ctx.onstatechange = () => { if (ctx.state === 'running') applyMusic(); };
    return ctx;
  }
  function unlock() {
    if (!ctx && !create()) return;
    if (ctx.state !== 'running' && on() && !(typeof document !== 'undefined' && document.hidden)) { try { ctx.resume().catch(() => {}); } catch (e) {} }
    if (!unlocked) {
      unlocked = true;
      try { const b = ctx.createBuffer(1, 1, 22050), s = ctx.createBufferSource(); s.buffer = b; s.connect(ctx.destination); s.start(0); } catch (e) {}
      applyMusic(); warm();
    }
  }
  let warmed = false;
  function warm() {   // pre-build sounds in the background so nothing hitches mid-battle
    if (warmed) return; warmed = true;
    const names = ['uiTap', 'uiOk', 'uiBack', 'uiBuy', 'shot:m4', 'shot:pistol', 'shot:ak47', 'hit', 'boomS', 'step:concrete', 'step:sand', 'jetLoop', 'voice:hurt', 'voice:die', 'whiz', 'land', 'throw', 'magOut', 'magIn', 'bolt'].concat(Object.keys(GEN));
    let i = 0;
    (function next() {
      const t0 = nowMs();
      while (i < names.length && nowMs() - t0 < 8) { const n = names[i++]; try { if (ctx) getBuf(n, 0); else raws(n); } catch (e) {} }
      if (i < names.length) setTimeout(next, 16); else { renderMusic('menu').then(() => renderMusic('battle')); }
    })();
  }

  function play(name, o) {
    o = o || {};
    if (!ctx || !on()) return null;
    if (ctx.state !== 'running' && !o.force) return null;
    if (active > 40 && !o.key) return null;
    let b; try { b = getBuf(name, o.v); } catch (e) { return null; }
    if (!b) return null;
    if (dbg) dbg(name);
    const src = ctx.createBufferSource(); src.buffer = b;
    if (o.rate) src.playbackRate.value = o.rate;
    const g = ctx.createGain(); g.gain.value = o.vol == null ? 1 : o.vol; src.connect(g);
    let end = g;
    if (o.pan && ctx.createStereoPanner) { const p = ctx.createStereoPanner(); p.pan.value = clamp(o.pan, -1, 1); g.connect(p); end = p; }
    end.connect(o.bus || busSfx);
    active++; src.onended = () => { active--; try { end.disconnect(); g.disconnect(); } catch (e) {} };
    src.start(o.at ? ctx.currentTime + o.at : 0);
    return src;
  }
  function sp(x, y, maxD, curve) {   // distance + stereo position relative to the player
    const dx = x - L.x, dy = (y - L.y) * 1.2, d = Math.sqrt(dx * dx + dy * dy);
    return { vol: Math.pow(clamp(1 - d / maxD, 0, 1), curve || 1.6), pan: clamp(dx / 650, -1, 1) * .85, d };
  }

  // ---------- music ----------
  function renderMusic(name) {
    const m = MUS[name] || (MUS[name] = {});
    if (m.raw) return Promise.resolve(m);
    if (!m.p) m.p = (name === 'battle' ? renderBattle() : renderMenu()).then(r => { m.raw = r; return m; }).catch(() => { m.failed = true; return m; });
    return m.p;
  }
  function music(name) { musWant = name || null; applyMusic(); }
  function applyMusic() {
    if (!ctx) return;
    const want = on() && musOn() && nowMs() >= musHold ? musWant : null;
    if (cur && cur.name === want) return;
    if (cur) { fadeOut(cur); cur = null; }
    if (!want || ctx.state !== 'running') return;
    const m = MUS[want];
    if (!m || !m.raw) { if (!(m && m.failed)) renderMusic(want).then(applyMusic); return; }
    if (!m.buf) { m.buf = ctx.createBuffer(2, m.raw.L.length, SR); m.buf.getChannelData(0).set(m.raw.L); m.buf.getChannelData(1).set(m.raw.R); }
    const src = ctx.createBufferSource(); src.buffer = m.buf; src.loop = true;
    const g = ctx.createGain(); g.gain.value = 0; src.connect(g); g.connect(busMus); g.connect(revIn);
    src.start(); g.gain.setTargetAtTime(MUSVOL[want] || .8, ctx.currentTime, .6);
    cur = { name: want, src, g };
  }
  function fadeOut(c) {
    try { c.g.gain.setTargetAtTime(0, ctx.currentTime, .3); } catch (e) {}
    setTimeout(() => { try { c.src.stop(); c.src.disconnect(); c.g.disconnect(); } catch (e) {} }, 2000);
  }
  function duck(level, secs) {
    if (!ctx || paused) return;
    const t = ctx.currentTime, p = busMus.gain; p.cancelScheduledValues(t); p.setTargetAtTime(MUSBASE * level, t, .03); p.setTargetAtTime(MUSBASE, t + secs, .5);
  }
  function setPaused(b) {
    if (!ctx || b === paused) return; paused = b; const t = ctx.currentTime;
    busMus.gain.cancelScheduledValues(t); busMus.gain.setTargetAtTime(MUSBASE * (b ? .35 : 1), t, .1); busAmb.gain.setTargetAtTime(b ? 0 : .6, t, .1);
  }
  function sync() {
    if (!ctx) return;
    const o = on(), m = musOn();
    if (o !== lastOn) {
      lastOn = o; master.gain.setTargetAtTime(o ? 1 : 0, ctx.currentTime, .04);
      if (!o) { stopSpeech(); setTimeout(() => { if (!on() && ctx.state === 'running') ctx.suspend().catch(() => {}); }, 400); }
      else if (ctx.state === 'suspended' && !(typeof document !== 'undefined' && document.hidden)) ctx.resume().catch(() => {});
      applyMusic();
    } else if (m !== lastMus) { lastMus = m; applyMusic(); }
  }

  // ---------- voices (spoken callouts) ----------
  const SAY = {
    kill: ['Enemy down!', 'Target eliminated!', 'Got him!', 'Tango down!'], grenade: ['Grenade!', 'Fire in the hole!', 'Frag out!'],
    reload: ['Reloading!', 'Changing mags!'], hit: ["I'm hit!", 'Taking fire!', 'Need cover!'], spawn: ['Moving out!', 'Ready!'],
    won: ['Mission accomplished!'], lost: ['Mission failed!']
  };
  function say(key, prob, gapMs) {
    if (!voiceOn() || !W.speechSynthesis || !ctx || ctx.state !== 'running' || (typeof document !== 'undefined' && document.hidden)) return;
    if (random() > (prob == null ? 1 : prob) || !gate('say', 1800) || !gate('say:' + key, gapMs || 4000)) return;
    try {
      const u = new W.SpeechSynthesisUtterance(pick(SAY[key])), vs = W.speechSynthesis.getVoices ? W.speechSynthesis.getVoices() : [];
      const v = vs.find(x => /^en/i.test(x.lang) && /male|david|daniel|alex|google uk english male/i.test(x.name)) || vs.find(x => /^en/i.test(x.lang));
      if (v) u.voice = v; u.lang = 'en-US'; u.rate = 1.12; u.pitch = .55; u.volume = .75;
      W.speechSynthesis.cancel(); W.speechSynthesis.speak(u);
    } catch (e) {}
  }
  function stopSpeech() { try { W.speechSynthesis && W.speechSynthesis.cancel(); } catch (e) {} }

  // ---------- game events (called by engine.js) ----------
  const RELOADS = {
    ak47: 'rifle', m4: 'rifle', mg: 'rifle', pistol: 'pistol', laser: 'laser', shotgun: 'shotgun', sniper: 'sniper', bazooka: 'bazooka'
  };
  function reloadSeq(e, mine, s) {
    const T = clamp(e.t || 1.5, .6, 3), kind = RELOADS[e.w] || 'rifle', v = (mine ? .8 : .55) * s.vol, o = (name, t, g, rate) => play(name, { vol: v * (g || 1), pan: s.pan, at: t, rate: rate || rnd(.97, 1.03), key: mine });
    if (kind === 'rifle') { o('magOut', .12 * T); o('magIn', .55 * T); o('bolt', max(.7 * T, T - .3)); }
    else if (kind === 'pistol') { o('magOut', .1 * T, .8, 1.1); o('magIn', .5 * T, .8, 1.1); o('bolt', .85 * T, .8, 1.2); }
    else if (kind === 'laser') { o('magOut', .1 * T, .6, 1.5); o('magIn', .6 * T, .6, 1.4); }
    else if (kind === 'shotgun') { const n = 4; for (let k = 0; k < n; k++) o('shell', (.15 + .5 * k / n) * T, .8); o('pump', max(.7 * T, T - .45)); }
    else if (kind === 'sniper') { o('boltAction', .08 * T); o('magIn', .6 * T); o('boltAction', max(.7 * T, T - .5)); }
    else { o('rocketLoad', .45 * T); o('bolt', .85 * T, .8, .8); }
  }
  function ev(e) {
    const g = gm(); if (!g || !ctx || ctx.state !== 'running' || !inGame) return;
    const me = e.p === g.me;
    switch (e.e) {
      case 'shot': {
        const s = me ? { vol: 1, pan: 0, d: 0 } : sp(e.x, e.y, 1500); if (s.vol < .02 || (!me && active > 30)) break;
        const far = !me && s.d > 650, nm = (far ? 'shotFar:' : 'shot:') + e.w; if (!GEN[nm]) break;
        play(nm, { vol: (me ? .95 : .85) * (far ? 1.3 : 1) * s.vol, pan: s.pan, rate: rnd(.96, 1.04) });
        break;
      }
      case 'boom': {
        if (!e.r) break;
        const s = sp(e.x, e.y, 2300, 1.2); if (s.vol < .02) break;
        const far = s.d > 900; play(far ? 'boomFar' : (e.r >= 140 ? 'boomL' : 'boomS'), { vol: clamp(s.vol * 1.25, 0, 1), pan: s.pan * .6, rate: rnd(.95, 1.05), key: 1 });
        duck(s.vol > .5 ? .45 : .7, .3 + .5 * s.vol); break;
      }
      case 'hit': {
        const s = sp(e.x, e.y, 900); if (s.vol < .05 || !gate('hit', 30)) break;
        play('hit', { vol: (e.v === g.me ? 1 : .75) * clamp(s.vol * 1.2, 0, 1), pan: s.pan, rate: rnd(.9, 1.1) }); break;
      }
      case 'hurt': {
        const s = me ? { vol: 1, pan: 0 } : sp(e.x, e.y, 800); if (s.vol < .05 || !gate('hurt' + e.p, 450)) break;
        play('voice:hurt', { bus: busVox, vol: .85 * s.vol, pan: s.pan, rate: vrate(e.p) });
        if (me) { duck(.6, .4); say('hit', .2, 9000); } break;
      }
      case 'die': {
        const s = me ? { vol: 1, pan: 0 } : sp(e.x, e.y, 1000); if (s.vol < .04) break;
        play('voice:die', { bus: busVox, vol: .95 * s.vol, pan: s.pan, rate: vrate(e.p), key: 1 });
        play('land', { vol: .6 * s.vol, pan: s.pan, rate: .75, at: .35 });
        if (me) duck(.35, 1.4); break;
      }
      case 'spark': {
        if (!gate('spark', 55)) break; const s = sp(e.x, e.y, 800); if (s.vol < .08) break;
        play(random() < .45 ? 'ric' : 'tck', { vol: .5 * s.vol, pan: s.pan, rate: rnd(.9, 1.1) }); break;
      }
      case 'punch': {
        const s = sp(e.x, e.y, 900); if (s.vol < .05) break;
        play('punch', { vol: .9 * s.vol, pan: s.pan, rate: rnd(.95, 1.05) });
        if (e.p != null) play('voice:exert', { bus: busVox, vol: .6 * s.vol, pan: s.pan, rate: vrate(e.p) }); break;
      }
      case 'pick': {
        const s = sp(e.x, e.y, 700, 1); if (s.vol < .05) break;
        play(e.k === 'hp' ? 'pickHp' : 'pickWp', { vol: .85 * s.vol, pan: s.pan }); break;
      }
      case 'kill': {
        const mine = (g.players.find(p => p.id === g.me) || {}).name;
        if (mine && e.a === mine && e.v !== mine) { play('killConfirm', { vol: .75, key: 1 }); say('kill', .7, 3500); } break;
      }
      case 'reload': {
        const s = me ? { vol: 1, pan: 0 } : sp(e.x, e.y, 700); if (s.vol < .05) break;
        reloadSeq(e, me, s); if (me) say('reload', .25, 8000); break;
      }
      case 'throw': {
        const s = me ? { vol: 1, pan: 0 } : sp(e.x, e.y, 900); if (s.vol < .05) break;
        play('throw', { vol: .85 * s.vol, pan: s.pan, rate: rnd(.95, 1.05) });
        play('voice:exert', { bus: busVox, vol: .55 * s.vol, pan: s.pan, rate: vrate(e.p), at: .06 });
        if (me) say('grenade', .5, 6000); break;
      }
      case 'swap': { const s = me ? { vol: 1, pan: 0 } : sp(e.x, e.y, 500); if (s.vol > .05) play('swap', { vol: .6 * s.vol, pan: s.pan }); break; }
      case 'jump': { const s = me ? { vol: 1, pan: 0 } : sp(e.x, e.y, 500); if (s.vol > .05) play('jump', { vol: (me ? .45 : .3) * s.vol, pan: s.pan, rate: rnd(.9, 1.1) }); break; }
      case 'spawn': {
        const s = me ? { vol: 1, pan: 0 } : sp(e.x, e.y, 700); if (s.vol < .05) break;
        play('spawn', { vol: (me ? .5 : .3) * s.vol, pan: s.pan }); if (me) say('spawn', .3, 12000); break;
      }
    }
  }

  // ---------- per-frame sounds: footsteps, jetpacks, ambience ----------
  const SURF = { desert: ['sand', 'concrete'], city: ['concrete', 'concrete'], snow: ['snow', 'snow'], jungle: ['grass', 'concrete'], port: ['concrete', 'metal'], night: ['concrete', 'metal'] };
  function footstep(g, p, mine) {
    const s = mine ? { vol: 1, pan: 0 } : sp(p.x, p.y, 650, 1.8); if (s.vol < .04) return;
    const gy = typeof GY !== 'undefined' ? GY : 900, surf = (SURF[g.M.deco] || SURF.city)[p.y < gy - 3 ? 1 : 0];
    const shoe = (typeof ITEMS !== 'undefined' && p.look && ITEMS[p.look.shoes] && ITEMS[p.look.shoes].h) || 8;
    play('step:' + surf, { vol: (mine ? .5 : .42) * s.vol * (.55 + shoe * .05), pan: s.pan, rate: (1.25 - shoe * .035) * rnd(.93, 1.07) });
  }
  function jetUpdate(p, st, dt, off, me) {
    if (!off && p.thrust) {
      const s = p === me ? { vol: 1, pan: 0 } : sp(p.x, p.y, 900, 1.5); let tg = (p === me ? .55 : .5) * s.vol; if (p.fuel < 10 && random() < .35) tg *= .25;
      if (!st.jet) {
        if (tg < .02) return;
        const src = ctx.createBufferSource(); src.buffer = getBuf('jetLoop', 0); src.loop = true;
        const js = typeof JETS !== 'undefined' && p.look && JETS[p.look.jet] ? JETS[p.look.jet].speed : 80; src.playbackRate.value = .85 + js / 450;
        const gn = ctx.createGain(); gn.gain.value = 0; src.connect(gn); let pn = null, end = gn;
        if (ctx.createStereoPanner) { pn = ctx.createStereoPanner(); gn.connect(pn); end = pn; }
        end.connect(busSfx); src.start(); st.jet = { src, gn, pn, idle: 0 };
      }
      st.jet.idle = 0; const t = ctx.currentTime; st.jet.gn.gain.setTargetAtTime(tg, t, .06); if (st.jet.pn) st.jet.pn.pan.setTargetAtTime(s.pan, t, .1);
    } else if (st.jet) {
      st.jet.gn.gain.setTargetAtTime(0, ctx.currentTime, .08); st.jet.idle += dt;
      if (st.jet.idle > .5) killJet(st);
    }
  }
  function killJet(st) { if (!st.jet) return; try { st.jet.src.stop(); st.jet.src.disconnect(); st.jet.gn.disconnect(); if (st.jet.pn) st.jet.pn.disconnect(); } catch (e) {} st.jet = null; }
  function stopLoops() { const g = gm(); if (g) for (const p of g.players) if (p._au) killJet(p._au); if (wind) { fadeOutWind(); } }
  function startWind() {
    if (!ctx || wind) return; const src = ctx.createBufferSource(); src.buffer = getBuf('windLoop', 0); src.loop = true;
    const gn = ctx.createGain(); gn.gain.value = 0; src.connect(gn); gn.connect(busAmb); src.start(); gn.gain.setTargetAtTime(.22, ctx.currentTime, 1.2); wind = { src, gn };
  }
  function fadeOutWind() { const w = wind; wind = null; try { w.gn.gain.setTargetAtTime(0, ctx.currentTime, .4); } catch (e) {} setTimeout(() => { try { w.src.stop(); w.src.disconnect(); w.gn.disconnect(); } catch (e) {} }, 1800); }

  function tick(dt) {
    const g = gm(); if (!g || !ctx) return;
    sync(); if (ctx.state !== 'running' || !inGame) return;
    const me = g.players.find(p => p.id === g.me); if (me) { L.x = me.x; L.y = me.y; }
    const ps = !!g.paused; setPaused(ps); const off = ps || g.over;
    for (const p of g.players) {
      const st = p._au || (p._au = { w: p.walk || 0, idx: floor((p.walk || 0) / PI), air: 0, jet: null });
      const dw = abs((p.walk || 0) - st.w); st.w = p.walk || 0; const idx = floor(st.w / PI);
      if (!off && p.alive) {
        if (idx !== st.idx) { st.idx = idx; if (p.onGround && dw / max(dt, .001) > 1.6) footstep(g, p, p === me); }
        if (p.onGround) { if (st.air > .3) { const s = p === me ? { vol: 1, pan: 0 } : sp(p.x, p.y, 650, 1.8); if (s.vol > .04) play('land', { vol: (p === me ? .7 : .5) * s.vol * clamp(st.air / .9, .4, 1), pan: s.pan, rate: rnd(.92, 1.08) }); } st.air = 0; } else st.air += dt;
      } else st.air = 0;
      jetUpdate(p, st, dt, off || !p.alive, me);
    }
    if (off) return;
    // bullets whizzing past the player (host / solo only)
    if (me && me.alive && g.role !== 'client') {
      AU.whiz -= dt;
      if (AU.whiz <= 0) for (const b of g.bullets) {
        if (b.own === g.me || b.k === 'r' || b.zz) continue;
        if (Math.hypot(b.x - me.x, b.y - (me.y - 28)) < 55) { b.zz = 1; AU.whiz = .09; play('whiz', { vol: .6, pan: clamp((b.x - me.x) / 80, -1, 1), rate: rnd(.9, 1.15) }); break; }
      }
    }
    if (g.training) return;
    // last-10-seconds countdown ticks
    const sec = Math.ceil(g.time); if (sec !== AU.sec) { AU.sec = sec; if (sec > 0 && sec <= 10) play('tick', { vol: .5 }); }
    // low health heartbeat
    if (me && me.alive && me.hp < 30) { AU.hb -= dt; if (AU.hb <= 0) { AU.hb = .85; play('heart', { vol: .7 * (1 - me.hp / 30) + .15 }); } }
    // distant battlefield ambience: far-off gunfire, blasts, radio chatter
    const a = AU.amb; a.s -= dt; a.b -= dt; a.r -= dt;
    if (a.s <= 0) {
      a.s = rnd(.5, 2.2); const n = random() < .25 ? 2 + floor(random() * 3) : 1, w = pick(['ak47', 'm4', 'mg', 'pistol']), pn = rnd(-1, 1), vv = rnd(.07, .17);
      for (let k = 0; k < n; k++) play('shotFar:' + w, { vol: vv, pan: pn, rate: rnd(.9, 1.05), bus: busAmb, at: k * rnd(.09, .14) });
    }
    if (a.b <= 0) { a.b = rnd(9, 22); play('boomFar', { vol: rnd(.12, .25), pan: rnd(-1, 1), rate: rnd(.8, 1), bus: busAmb }); }
    if (a.r <= 0) { a.r = rnd(12, 26); play('radio', { vol: .3, pan: rnd(-.5, .5), bus: busVox }); }
  }

  // ---------- match lifecycle ----------
  function matchStart(info) {
    inGame = true; AU.sec = -1; AU.hb = 0; AU.amb = { s: 1, b: rnd(5, 12), r: rnd(6, 14) }; musHold = 0;
    const tr = !!(info && info.training); music(tr ? 'menu' : 'battle'); if (!tr) startWind();
    if (ctx && paused) setPaused(false);
  }
  function matchEnd(won) {
    inGame = false; stopLoops(); stopSpeech(); if (!ctx) return;
    if (won === true) { play('win', { vol: .9, key: 1, force: true }); setTimeout(() => say('won', 1, 1000), 900); }
    else if (won === false) { play('lose', { vol: .9, key: 1, force: true }); setTimeout(() => say('lost', 1, 1000), 900); }
    else play('uiOk', { vol: .8, force: true });
    musHold = nowMs() + 3600; musWant = 'menu'; applyMusic(); setTimeout(applyMusic, 3700);
  }
  function leave() { inGame = false; stopLoops(); stopSpeech(); musHold = 0; if (ctx && paused) setPaused(false); music('menu'); }
  function lesson() { play('success', { vol: .8, key: 1, force: true }); }

  // ---------- button clicks (automatic) ----------
  const CLICKABLE = 'button,[role="button"],a,[onclick],.btn,.button,.tab,.item,.card,.opt,.chip,.slot,input[type=button],input[type=submit],input[type=checkbox],input[type=radio],input[type=range],select,label,summary';
  const RX_BACK = /\b(back|close|cancel|exit|quit|home|menu|no)\b|[×✕✖]/i, RX_BUY = /\b(buy|purchase|unlock|claim|collect|reward|daily|coins?)\b/i,
    RX_OK = /\b(play|start|battle|deploy|join|create|host|ready|confirm|ok|continue|next|equip|select|save|apply|resume|rematch|train(ing)?|fight)\b/i;
  function click(kind) {
    if (!ctx && !create()) return; unlock();
    play(({ tap: 'uiTap', ok: 'uiOk', back: 'uiBack', buy: 'uiBuy', err: 'uiErr' })[kind || 'tap'] || 'uiTap', { vol: .75, force: true, key: 1, rate: rnd(.97, 1.03) });
  }
  function onDown(e) {
    const el = e.target && e.target.closest ? e.target : null; if (!el) return;
    unlock();
    const t = el.closest(CLICKABLE); if (!t || t.closest('#gc') || (t.dataset && t.dataset.sfx === 'off')) return;
    if (t.disabled || t.getAttribute('aria-disabled') === 'true') return;
    const txt = (t.id + ' ' + (typeof t.className === 'string' ? t.className : '') + ' ' + ((t.textContent || '').trim().slice(0, 40))).toLowerCase();
    if (inGame && !paused && !(t.dataset && t.dataset.sfx === 'on') && !/pause|menu|exit|quit|resume|setting/.test(txt)) return;  // in-game touch controls stay silent
    click(RX_BUY.test(txt) ? 'buy' : RX_BACK.test(txt) ? 'back' : RX_OK.test(txt) ? 'ok' : 'tap');
  }

  // ---------- test-board helper ----------
  function sample(name) {
    if (!ctx && !create()) return; unlock();
    if (name.indexOf('music:') === 0) { const n = name.slice(6); musHold = 0; music(n === 'off' ? null : n); return; }
    if (name.indexOf('reload:') === 0) { const w = name.slice(7); reloadSeq({ w, t: (typeof WEAPONS !== 'undefined' && WEAPONS[w] ? WEAPONS[w].rel / 1000 : 1.6) }, true, { vol: 1, pan: 0 }); return; }
    if (name === 'jet') { const st = { jet: null }, fake = { thrust: true, fuel: 50, x: L.x, y: L.y, look: {}, alive: true }; jetUpdate(fake, st, .016, false, fake); setTimeout(() => { fake.thrust = false; jetUpdate(fake, st, .6, false, fake); }, 1800); return; }
    const vox = name.indexOf('voice:') === 0 || name === 'radio';
    play(name, { vol: 1, force: true, key: 1, bus: vox ? busVox : busSfx, rate: vox && name !== 'radio' ? vrate(random()) : 1 });
  }

  // ---------- startup ----------
  W.WZAudio = {
    ctx: create, unlock, click, music, matchStart, matchEnd, leave, lesson, ev, tick, sample, say,
    names: () => Object.keys(GEN).filter(n => n !== 'jetLoop' && n !== 'windLoop'),
    get ready() { return !!ctx && ctx.state === 'running'; },
    set debug(fn) { dbg = fn; }
  };
  if (typeof document !== 'undefined') {
    const opt = { capture: true, passive: true };
    W.addEventListener('pointerdown', onDown, opt);
    if (!W.PointerEvent) { W.addEventListener('touchstart', onDown, opt); W.addEventListener('mousedown', onDown, opt); }
    ['pointerup', 'touchend', 'mouseup', 'click', 'keydown'].forEach(n => W.addEventListener(n, () => { if (!ctx || ctx.state !== 'running') unlock(); }, opt));
    const hide = () => { if (ctx && ctx.state === 'running') ctx.suspend().catch(() => {}); stopSpeech(); };
    const show = () => { if (ctx && on() && ctx.state !== 'running') ctx.resume().catch(() => {}); };
    document.addEventListener('visibilitychange', () => (document.hidden ? hide() : show()));
    W.addEventListener('pagehide', hide); W.addEventListener('pageshow', show);
    document.addEventListener('pause', hide); document.addEventListener('resume', show);   // Cordova / APK wrappers
    setInterval(sync, 350);
  }
  if (typeof module !== 'undefined' && module.exports) module.exports = { GEN, NV, raws, renderBattle, renderMenu, SR };
})();
