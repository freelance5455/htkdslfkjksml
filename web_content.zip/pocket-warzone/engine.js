'use strict';
// ===== POCKET WARZONE — engine =====
let G = null, cv = null, cx = null, loopId = 0, lastT = 0;
let NETTICK = null, HUD = null, ONEND = null, ONLESSON = null;
const KEYS = {}, MS = { x: 0, y: 0, down: false, has: false };
const IN = { mx: 0, aiming: false, aim: 0, fire: false, jet: false, jetS: false };
const clamp = (v, a, b) => v < a ? a : v > b ? b : v;
const rnd = (a, b) => a + Math.random() * (b - a);
function hs(i) { const s = Math.sin(i * 127.1) * 43758.5453; return s - Math.floor(s); }

// ---------- sound ----------
let AC = null;
// [SFX] safe bridge to audio.js: the game keeps running even if audio.js is missing
function sfx(n, a, b) { try { const A = window.WZAudio; if (A && A[n]) A[n](a, b); } catch (e) {} }
function snd(f, d, type, v, slide) {
  if (typeof SAVE !== 'undefined' && !SAVE.sound) return;
  try {
    AC = AC || (window.WZAudio && WZAudio.ctx && WZAudio.ctx()) || new (window.AudioContext || window.webkitAudioContext)();
    const o = AC.createOscillator(), g = AC.createGain();
    o.type = type || 'square'; o.frequency.value = f;
    if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(20, f * slide), AC.currentTime + d);
    g.gain.value = v || .04; g.gain.exponentialRampToValueAtTime(.0001, AC.currentTime + d);
    o.connect(g); g.connect(AC.destination); o.start(); o.stop(AC.currentTime + d);
  } catch (e) {}
}

// ---------- drawing ----------
function rr(c, x, y, w, h, r) {
  c.beginPath(); c.moveTo(x + r, y); c.arcTo(x + w, y, x + w, y + h, r); c.arcTo(x + w, y + h, x, y + h, r);
  c.arcTo(x, y + h, x, y, r); c.arcTo(x, y, x + w, y, r); c.closePath();
}
function drawJet(c, J, flame, x, y) {
  c.save(); c.translate(x, y); c.lineWidth = 2; c.strokeStyle = '#142010';
  if (flame) {
    const fl = J.fl || ['#ff9a1f', '#fff2a0'], len = 16 + Math.random() * 12;
    for (let k = 0; k < 2; k++) { c.fillStyle = fl[k]; c.beginPath(); c.moveTo(2 + k * 2, 29); c.lineTo(5.5, 29 + len * (k ? .6 : 1)); c.lineTo(9 - k * 2, 29); c.fill(); }
  }
  c.fillStyle = J.col; rr(c, 0, 0, 11, 29, 4); c.fill(); c.stroke();
  c.fillStyle = '#333'; c.fillRect(2, 25, 7, 4);
  c.fillStyle = 'rgba(255,255,255,.35)'; c.fillRect(2, 4, 2, 14);
  c.restore();
}
function drawGun(c, k) {
  const w = WEAPONS[k || 'pistol']; if (!w || !w.len) return;
  c.lineWidth = 1.8; c.strokeStyle = '#142010'; c.fillStyle = w.col;
  if (k === 'bazooka') { rr(c, -2, -6, w.len, 11, 4); c.fill(); c.stroke(); c.fillStyle = '#2b3320'; c.fillRect(w.len - 6, -7, 5, 13); return; }
  if (w.len > 25) { c.fillRect(-4, -3, 8, 6); }
  rr(c, 4, -4, w.len, 7, 2); c.fill(); c.stroke();
  c.fillStyle = '#222'; c.fillRect(4 + w.len * .5, -2.5, w.len * .5 + 5, 3.5);
  c.fillStyle = '#333'; c.fillRect(7, 2, 4, 8);
  if (k === 'sniper') { c.fillStyle = '#222'; c.fillRect(10, -8, 12, 4); }
  if (k === 'laser') { c.fillStyle = 'rgba(160,255,255,.8)'; c.fillRect(8, -2, 8, 3); }
}
function drawChar(c, L, o) {
  const T = ITEMS[L.top] || ITEMS.camo, S = ITEMS[L.shoes] || ITEMS.army, sk = SKINS[L.skin | 0] || SKINS[0];
  const hc = o.hcol || (HELMETS[L.helmet | 0] || HELMETS[0]).col, J = JETS[L.jet] || JETS.silver, face = L.face | 0;
  const f = o.face || 1, sw = Math.sin(o.walk || 0) * 5;
  c.save(); c.scale(f, 1); c.lineJoin = 'round'; c.lineWidth = 2; c.strokeStyle = '#142010';
  drawJet(c, J, o.flame, -22, -41);
  for (let k = 0; k < 2; k++) {
    const lx = (k ? 5 : -5) + (o.air ? 0 : (k ? -sw : sw) * .6);
    c.fillStyle = T.pants; c.fillRect(lx - 4, -19, 8, 13); c.strokeRect(lx - 4, -19, 8, 13);
    c.fillStyle = S.col; rr(c, lx - 5, -S.h, 12, S.h, 3); c.fill(); c.stroke();
  }
  c.fillStyle = T.body; rr(c, -11, -35, 22, 19, 5); c.fill(); c.stroke();
  if (T.camo) { c.fillStyle = '#3e4b28'; [[-7, -30, 5, 3], [2, -26, 6, 4], [-3, -21, 5, 3], [6, -32, 4, 3]].forEach(a => { c.beginPath(); c.ellipse(a[0], a[1], a[2], a[3], 0, 0, 7); c.fill(); }); }
  if (T.vest) { c.fillStyle = T.vest; rr(c, -9, -33, 18, 13, 3); c.fill(); c.stroke(); c.fillStyle = 'rgba(255,255,255,.14)'; c.fillRect(-7, -27, 6, 6); c.fillRect(1, -27, 6, 6); }
  if (T.jacket) { c.strokeStyle = 'rgba(0,0,0,.5)'; c.beginPath(); c.moveTo(0, -35); c.lineTo(0, -16); c.stroke(); c.strokeStyle = '#142010'; if (T.patch) { c.fillStyle = T.patch; c.fillRect(4, -30, 5, 4); } }
  if (T.tie) { c.fillStyle = '#f2f2f2'; c.fillRect(-3, -35, 8, 12); c.fillStyle = '#b8202a'; c.fillRect(0, -34, 3, 12); }
  if (T.hood) { c.fillStyle = T.body; c.beginPath(); c.arc(-6, -36, 7, Math.PI, 0); c.fill(); c.stroke(); }
  // head
  if (face === 4) { c.fillStyle = '#7a4a2a'; c.beginPath(); c.ellipse(-14, -42, 6, 9, .3, 0, 7); c.fill(); c.stroke(); }
  c.fillStyle = face === 5 ? '#b8c4d0' : sk; c.beginPath(); c.arc(0, -45, 13, 0, 7); c.fill(); c.stroke();
  if (face === 3) { c.fillStyle = '#5a3a22'; c.beginPath(); c.arc(1, -43, 12, .1, Math.PI - .1); c.closePath(); c.fill(); }
  c.fillStyle = face === 5 ? '#33c4ff' : '#1a1210';
  c.beginPath(); c.ellipse(3, -45, 2, face === 5 ? 2 : 2.8, 0, 0, 7); c.ellipse(9, -45, 2, face === 5 ? 2 : 2.8, 0, 0, 7); c.fill();
  c.strokeStyle = '#1a1210'; c.lineWidth = 1.6;
  if (face === 1) { c.beginPath(); c.moveTo(0, -50); c.lineTo(5, -48); c.moveTo(12, -50); c.lineTo(7, -48); c.stroke(); }
  c.beginPath();
  if (face === 1 || face === 5 || face === 3) { c.moveTo(4, -38.5); c.lineTo(9, -38.5); } else c.arc(6.5, -40, 3, .2, Math.PI - .2);
  c.stroke(); c.lineWidth = 2; c.strokeStyle = '#142010';
  const gl = ITEMS[L.glasses];
  if (gl || face === 2) { c.fillStyle = gl ? gl.lens : '#111'; c.globalAlpha = gl && gl.lens !== '#111' ? .85 : 1; rr(c, 0, -49, 14, 7, 2); c.fill(); c.stroke(); c.globalAlpha = 1; }
  // helmet + goggles
  c.fillStyle = hc; c.beginPath(); c.arc(0, -48.5, 14.5, Math.PI, 0); c.closePath(); c.fill(); c.stroke();
  c.fillStyle = '#bcd7de'; rr(c, -13, -57, 26, 6, 3); c.fill(); c.stroke();
  c.fillStyle = 'rgba(255,255,255,.55)'; c.fillRect(2, -56, 7, 2);
  if (face === 5) { c.strokeStyle = '#142010'; c.beginPath(); c.moveTo(0, -63); c.lineTo(0, -69); c.stroke(); c.fillStyle = '#ff4d4d'; c.beginPath(); c.arc(0, -70, 2.5, 0, 7); c.fill(); }
  if (!o.nogun) {
    const ang = f > 0 ? o.aim : Math.PI - o.aim;
    c.save(); c.translate(4, -27); c.rotate(ang);
    c.fillStyle = T.body; rr(c, -3, -3.5, 14, 7, 3); c.fill(); c.stroke();
    drawGun(c, o.wp);
    c.fillStyle = sk; c.beginPath(); c.arc(10, 1, 3.5, 0, 7); c.fill(); c.stroke();
    c.restore();
  }
  c.restore();
}

function layer(c, camx, f, per, vw, fn) {
  const o = camx * f, i0 = Math.floor(o / per);
  for (let k = -1; k <= vw / per + 1; k++) fn(k * per - (o - i0 * per), i0 + k);
}
function drawBg(c, M, camx, camy, vw, vh) {
  const g = c.createLinearGradient(0, 0, 0, vh); g.addColorStop(0, M.sky[0]); g.addColorStop(1, M.sky[1]);
  c.fillStyle = g; c.fillRect(0, 0, vw, vh);
  const hy = GY - camy;
  switch (M.deco) {
    case 'desert':
      c.fillStyle = '#fff3c4'; c.beginPath(); c.arc(vw * .78, 70, 34, 0, 7); c.fill();
      layer(c, camx, .12, 520, vw, (x, i) => { c.fillStyle = '#e6b678'; c.beginPath(); c.moveTo(x, hy + 10); c.quadraticCurveTo(x + 260, hy - 90 - hs(i) * 60, x + 520, hy + 10); c.fill(); });
      layer(c, camx, .3, 360, vw, (x, i) => { c.fillStyle = '#d9a063'; c.beginPath(); c.moveTo(x, hy + 10); c.quadraticCurveTo(x + 180, hy - 40 - hs(i) * 40, x + 360, hy + 10); c.fill(); });
      layer(c, camx, .5, 700, vw, (x, i) => {
        if (hs(i) > .5) { c.fillStyle = '#8a6a45'; c.fillRect(x, hy - 60, 40, 60); c.fillRect(x - 10, hy - 70, 60, 12); }
        else { c.fillStyle = '#b59a6a'; c.beginPath(); c.moveTo(x, hy); c.lineTo(x + 50, hy - 45); c.lineTo(x + 100, hy); c.fill(); }
      });
      break;
    case 'city':
      layer(c, camx, .18, 140, vw, (x, i) => { const h = 70 + hs(i) * 150; c.fillStyle = '#7d8791'; c.fillRect(x, hy - h, 110, h + 10); c.fillStyle = 'rgba(255,255,255,.18)'; for (let y = hy - h + 10; y < hy - 10; y += 18) for (let xx = x + 10; xx < x + 100; xx += 22) c.fillRect(xx, y, 10, 10); });
      layer(c, camx, .38, 200, vw, (x, i) => { const h = 40 + hs(i + 9) * 90; c.fillStyle = '#5f6870'; c.fillRect(x, hy - h, 150, h + 10); c.fillStyle = 'rgba(0,0,0,.25)'; c.fillRect(x + 20, hy - h + 12, 20, 18); c.fillRect(x + 80, hy - h + 40, 22, 20); });
      break;
    case 'snow':
      layer(c, camx, .1, 520, vw, (x, i) => { const h = 150 + hs(i) * 120; c.fillStyle = '#b7cfe6'; c.beginPath(); c.moveTo(x, hy + 10); c.lineTo(x + 260, hy - h); c.lineTo(x + 520, hy + 10); c.fill(); c.fillStyle = '#fff'; c.beginPath(); c.moveTo(x + 260, hy - h); c.lineTo(x + 215, hy - h + 55); c.lineTo(x + 305, hy - h + 55); c.fill(); });
      layer(c, camx, .35, 150, vw, (x, i) => { if (hs(i) < .4) return; c.fillStyle = '#2f5a45'; c.beginPath(); c.moveTo(x, hy); c.lineTo(x + 25, hy - 70); c.lineTo(x + 50, hy); c.fill(); c.fillStyle = '#fff'; c.beginPath(); c.moveTo(x + 25, hy - 70); c.lineTo(x + 14, hy - 48); c.lineTo(x + 36, hy - 48); c.fill(); });
      c.fillStyle = 'rgba(255,255,255,.8)'; for (let i = 0; i < 40; i++) { const t = G ? G.t : 0; c.fillRect((hs(i) * vw + t * 20 * (1 + hs(i + 3))) % vw, (hs(i + 7) * vh + t * 50) % vh, 2, 2); }
      break;
    case 'jungle':
      layer(c, camx, .15, 260, vw, (x, i) => { const h = 120 + hs(i) * 120; c.fillStyle = '#3d6b3a'; c.fillRect(x + 100, hy - h, 18, h + 10); c.fillStyle = '#2f7a3a'; c.beginPath(); c.arc(x + 109, hy - h, 60 + hs(i + 4) * 30, 0, 7); c.fill(); });
      layer(c, camx, .4, 180, vw, (x, i) => { c.fillStyle = '#3f8c3a'; c.beginPath(); c.arc(x + 50, hy, 40 + hs(i) * 30, Math.PI, 0); c.fill(); c.fillStyle = '#7d7a6a'; if (hs(i + 2) > .6) c.fillRect(x + 100, hy - 50, 30, 50); });
      break;
    case 'port':
      c.fillStyle = '#2b86b3'; c.fillRect(0, hy - 30, vw, vh);
      layer(c, camx, .15, 420, vw, (x, i) => { c.fillStyle = '#4a5560'; c.fillRect(x + 40, hy - 160 - hs(i) * 60, 10, 160); c.fillRect(x + 40, hy - 160 - hs(i) * 60, 120, 8); c.fillRect(x + 150, hy - 160 - hs(i) * 60, 4, 40); });
      layer(c, camx, .4, 100, vw, (x, i) => { const cols = ['#c8503a', '#3a7bd5', '#e0a93a', '#3a9d6b']; c.fillStyle = cols[Math.floor(hs(i) * 4)]; c.fillRect(x, hy - 36, 80, 36); c.fillStyle = 'rgba(0,0,0,.2)'; for (let k = 8; k < 80; k += 10) c.fillRect(x + k, hy - 36, 2, 36); });
      break;
    case 'night':
      c.fillStyle = '#fff'; for (let i = 0; i < 60; i++) c.fillRect((hs(i) * vw * 1.3 - camx * .04 + vw * 2) % vw, hs(i + 9) * vh * .6, 1.6, 1.6);
      c.fillStyle = '#f3efc8'; c.beginPath(); c.arc(vw * .8, 80, 30, 0, 7); c.fill();
      c.fillStyle = g; c.beginPath(); c.arc(vw * .8 + 14, 74, 26, 0, 7); c.fill();
      layer(c, camx, .2, 130, vw, (x, i) => { const h = 70 + hs(i) * 140; c.fillStyle = '#141b36'; c.fillRect(x, hy - h, 100, h + 10); c.fillStyle = '#f2cf5a'; for (let y = hy - h + 10; y < hy - 10; y += 20) for (let xx = x + 10; xx < x + 90; xx += 20) if (hs(i * 7 + y + xx) > .55) c.fillRect(xx, y, 8, 9); });
      break;
  }
}
function drawWorld(c, G) {
  const M = G.M;
  M.rects.forEach((r, i) => {
    c.fillStyle = i ? M.plat : M.ground; c.fillRect(r.x, r.y, r.w, r.h);
    c.fillStyle = i ? M.ptop : M.gtop; c.fillRect(r.x, r.y, r.w, i ? 7 : 12);
    c.strokeStyle = 'rgba(0,0,0,.35)'; c.lineWidth = 2; c.strokeRect(r.x, r.y, r.w, r.h);
    c.fillStyle = 'rgba(0,0,0,.12)'; for (let x = r.x + 20; x < r.x + r.w - 6; x += 46) c.fillRect(x, r.y + (i ? 12 : 20), 22, 3);
  });
  for (const k of G.picks) {
    const y = k.y + Math.sin(G.t * 3 + k.id) * 3;
    c.fillStyle = k.kind === 'hp' ? '#f4f4f4' : '#d9a62b'; rr(c, k.x - 12, y - 12, 24, 24, 4); c.fill(); c.strokeStyle = '#142010'; c.lineWidth = 2; c.stroke();
    if (k.kind === 'hp') { c.fillStyle = '#d33'; c.fillRect(k.x - 3, y - 8, 6, 16); c.fillRect(k.x - 8, y - 3, 16, 6); }
    else { c.fillStyle = '#222'; c.fillRect(k.x - 8, y - 3, 16, 5); c.fillRect(k.x - 4, y + 1, 4, 6); }
  }
  for (const g of G.gren) {
    c.fillStyle = g.kind === 'bomb' ? '#111' : '#4a6b3a'; c.beginPath(); c.arc(g.x, g.y, g.kind === 'bomb' ? 9 : 6.5, 0, 7); c.fill(); c.strokeStyle = '#142010'; c.lineWidth = 2; c.stroke();
    if (g.kind === 'bomb') { c.fillStyle = Math.sin(G.t * 20) > 0 ? '#ff4' : '#f84'; c.fillRect(g.x + 2, g.y - 13, 4, 5); }
  }
  for (const p of G.players) {
    if (!p.alive) continue;
    c.save(); c.translate(p.x, p.y);
    if (p.inv > 0 && Math.floor(G.t * 12) % 2) c.globalAlpha = .45;
    const hcol = G.mode === 'team' ? (p.team ? '#d63a3a' : '#2f6fd6') : null;
    drawChar(c, p.look, { aim: p.aim, face: p.face, walk: p.walk, air: !p.onGround, flame: p.thrust, wp: p.w[p.cur], hcol });
    if (p.flash > 0) { c.globalAlpha = .5; c.fillStyle = '#f33'; c.fillRect(-12, -58, 24, 58); c.globalAlpha = 1; }
    c.restore();
    c.font = 'bold 11px sans-serif'; c.textAlign = 'center'; c.lineWidth = 3; c.strokeStyle = 'rgba(0,0,0,.6)';
    c.fillStyle = p.id === G.me ? '#9bff7a' : (G.mode === 'team' ? (p.team ? '#ff8a8a' : '#8ab8ff') : '#fff');
    c.strokeText(p.name, p.x, p.y - 80); c.fillText(p.name, p.x, p.y - 80);
    if (p.id !== G.me) { c.fillStyle = 'rgba(0,0,0,.5)'; c.fillRect(p.x - 16, p.y - 76, 32, 4); c.fillStyle = p.hp > 40 ? '#5ee33b' : '#e33'; c.fillRect(p.x - 16, p.y - 76, 32 * clamp(p.hp / 100, 0, 1), 4); }
  }
  for (const b of G.bullets) {
    if (b.k === 'r') { c.fillStyle = '#6a7a50'; c.save(); c.translate(b.x, b.y); c.rotate(Math.atan2(b.vy, b.vx)); c.fillRect(-10, -3, 16, 6); c.fillStyle = '#ffb030'; c.fillRect(-16, -2, 6, 4); c.restore(); continue; }
    c.strokeStyle = b.k === 'l' ? '#6ff' : '#ffe27a'; c.lineWidth = b.k === 'l' ? 4 : 2.5; const m = Math.hypot(b.vx, b.vy) || 1;
    c.beginPath(); c.moveTo(b.x, b.y); c.lineTo(b.x - b.vx / m * (b.k === 'l' ? 26 : 14), b.y - b.vy / m * (b.k === 'l' ? 26 : 14)); c.stroke();
  }
  for (const q of G.parts) { c.globalAlpha = clamp(q.l / q.m, 0, 1); c.fillStyle = q.c; c.beginPath(); c.arc(q.x, q.y, q.s * (q.grow ? 2 - q.l / q.m : 1), 0, 7); c.fill(); }
  c.globalAlpha = 1;
}
function render() {
  if (!G || !cv) return;
  const c = cx, dpr = cv._dpr || 1, ch = cv.height, sc = ch / 520, vw = cv.width / sc, vh = 520;
  const me = G.players.find(p => p.id === G.me);
  const tx = clamp((me ? me.x : W / 2) - vw / 2, 0, Math.max(0, W - vw)), ty = clamp((me ? me.y - 30 : GY) - vh / 2, 0, H - vh);
  if (G.camx === undefined) { G.camx = tx; G.camy = ty; }
  G.camx += (tx - G.camx) * .18; G.camy += (ty - G.camy) * .18;
  let sx = 0, sy = 0; if (G.shake > 0) { sx = rnd(-1, 1) * G.shake * 8; sy = rnd(-1, 1) * G.shake * 8; }
  c.setTransform(sc, 0, 0, sc, 0, 0); drawBg(c, G.M, G.camx, G.camy, vw, vh);
  c.setTransform(sc, 0, 0, sc, (-G.camx + sx) * sc, (-G.camy + sy) * sc); drawWorld(c, G);
  if (me) { G.psx = (me.x - G.camx) * sc / dpr; G.psy = (me.y - 30 - G.camy) * sc / dpr; }
}

// ---------- game setup ----------
function sameTeam(a, b) { return G.mode === 'team' && a.team === b.team; }
function solidAt(x, y) { for (const r of G.M.rects) if (x > r.x && x < r.x + r.w && y > r.y && y < r.y + r.h) return true; return false; }

function newGame(gc) {
  const M = Object.assign({}, MAPS.find(m => m.id === gc.map) || MAPS[0]);
  M.rects = [{ x: 0, y: GY, w: W, h: H - GY }].concat(M.pl.map(a => ({ x: a[0], y: a[1], w: a[2], h: a[3] || 22 })));
  M.spawns = M.pl.map(a => [a[0] + a[2] / 2, a[1]]).concat([[150, GY], [2250, GY], [1200, GY], [700, GY]]);
  G = { M, players: [], bullets: [], gren: [], picks: [], parts: [], feed: [], outEv: [], t: 0, time: (gc.time || 10) * 60, limit: gc.limit || 25,
    mode: gc.mode || 'ffa', role: gc.role || 'solo', training: !!gc.training, me: gc.me, over: false, paused: false, spT: 3, pid: 1, ts: [0, 0], shake: 0,
    cin: { mx: 0, aiming: false, aim: 0, fire: false, jet: false }, lesson: gc.lesson == null ? null : gc.lesson, trk: newTrk() };
  for (const r of gc.roster) {
    const p = { id: r.id, name: r.name, team: r.team || 0, bot: !!r.bot, dummy: !!r.dummy, look: r.look, x: 0, y: 0, vx: 0, vy: 0, face: 1, aim: 0, hp: 100, alive: false, respawn: 0, inv: 0,
      w: [r.look.primary, r.look.secondary], cur: 0, ammo: {}, grn: 3, fuel: 0, fuelMax: 0, kills: 0, deaths: 0, cd: 0, rel: 0, melee: 0, gcd: 0, flash: 0, walk: 0, onGround: false, thrust: false,
      input: { mx: 0, aiming: false, aim: 0, fire: false, jet: false } };
    G.players.push(p); spawnPlayer(p);
  }
  if (G.training) for (let i = 0; i < 2; i++) G.picks.push({ id: G.pid++, x: G.M.spawns[i * 3][0], y: G.M.spawns[i * 3][1] - 16, kind: i ? 'wp' : 'hp' });
  sfx('matchStart', { training: G.training, mode: G.mode, role: G.role }); // [SFX]
  return G;
}
function newTrk() { return { move: 0, aim: 0, shot: 0, jump: 0, jet: 0, gren: 0, melee: 0, reload: 0, swap: 0, kills: 0 }; }
function spawnPlayer(p) {
  let best = null, bd = -1;
  for (let n = 0; n < 4; n++) {
    const s = G.M.spawns[Math.random() * G.M.spawns.length | 0]; let md = 1e9;
    for (const q of G.players) if (q !== p && q.alive) md = Math.min(md, Math.hypot(q.x - s[0], q.y - s[1]));
    if (md > bd) { bd = md; best = s; }
  }
  p.x = best[0]; p.y = best[1] - 1; p.vx = p.vy = 0; p.hp = 100; p.alive = true; p.inv = 2; p.cur = 0;
  p.w = [p.look.primary, p.look.secondary]; p.ammo = {}; for (const k of p.w) p.ammo[k] = WEAPONS[k].mag;
  p.grn = 3; const jt = JETS[p.look.jet] || JETS.silver; p.fuelMax = jt.fuel; p.fuel = jt.fuel; p.rel = 0; p.cd = .3;
  if (G.t > .5) emit({ e: 'spawn', p: p.id, x: p.x, y: p.y - 30 }); // [SFX] respawn only
}

// ---------- events / effects ----------
function emit(e) { handleEv(e); if (G.role === 'host') G.outEv.push(e); }
function part(x, y, n, col, sp, life, size, grow) {
  for (let i = 0; i < n; i++) { const a = rnd(0, 6.283), s = rnd(.2, 1) * sp; G.parts.push({ x, y, vx: Math.cos(a) * s, vy: Math.sin(a) * s, l: life * rnd(.6, 1), m: life, c: col, s: size, grow }); }
}
function handleEv(e) {
  if (!G) return;
  switch (e.e) {
    case 'shot': part(e.x, e.y, 3, '#ffe27a', 90, .08, 3); break;
    case 'boom': if (e.r) { part(e.x, e.y, 26, '#ff9a1f', 260, .6, 6, 1); part(e.x, e.y, 14, '#555', 140, .9, 9, 1); G.shake = Math.max(G.shake, .6); } else part(e.x, e.y, 14, '#d33', 160, .6, 4); break;
    case 'hit': part(e.x, e.y, 5, '#e33', 120, .3, 2.5); break;
    case 'spark': part(e.x, e.y, 4, '#ddd', 100, .2, 2); break;
    case 'punch': part(e.x, e.y, 5, '#fff', 90, .2, 3); break;
    case 'pick': part(e.x, e.y, 14, e.k === 'hp' ? '#6f6' : '#fd4', 160, .5, 3); break;
    case 'kill': G.feed.unshift({ t: 4.5, a: e.a, v: e.v, w: e.w }); if (G.feed.length > 5) G.feed.pop(); break;
  }
  sfx('ev', e); // [SFX] play the matching sound
}
function particlesStep(dt) {
  if (!G) return;
  for (let i = G.parts.length - 1; i >= 0; i--) { const q = G.parts[i]; q.l -= dt; if (q.l <= 0) { G.parts.splice(i, 1); continue; } q.x += q.vx * dt; q.y += q.vy * dt; q.vx *= .97; q.vy *= .97; }
  if (G.shake > 0) G.shake -= dt * 1.6;
  for (let i = G.feed.length - 1; i >= 0; i--) { G.feed[i].t -= dt; if (G.feed[i].t <= 0) G.feed.splice(i, 1); }
  for (const p of G.players) if (p.thrust && Math.random() < .6) G.parts.push({ x: p.x - p.face * 16, y: p.y - 10, vx: rnd(-20, 20), vy: rnd(60, 120), l: .3, m: .3, c: 'rgba(255,200,90,.8)', s: 3 });
}

// ---------- simulation (host / solo) ----------
function step(dt) {
  const g = G; if (g.over) return;
  g.t += dt; if (!g.training) g.time -= dt;
  for (const p of g.players) { if (p.bot) botThink(p, dt); updatePlayer(p, dt); }
  updateBullets(dt); updateGren(dt); updatePicks(dt);
  if (g.training && g.lesson != null) checkLesson();
  if (!g.training && g.time <= 0) endGame();
}
function checkLesson() {
  const L = LESSONS[G.lesson]; if (!L || !L.ok(G.trk)) return;
  const done = G.lesson; G.trk = Object.assign(newTrk(), { kills: G.trk.kills });
  let nx = null; for (let i = 1; i <= LESSONS.length; i++) { const j = (done + i) % LESSONS.length; if (!SAVE.lessons.includes(j) && j !== done) { nx = j; break; } }
  G.lesson = nx; sfx('lesson'); ONLESSON && ONLESSON(done);
}
function updatePlayer(p, dt) {
  const g = G;
  if (!p.alive) { p.respawn -= dt; if (p.respawn <= 0) spawnPlayer(p); return; }
  const i = p.input, jt = JETS[p.look.jet] || JETS.silver, k = p.w[p.cur], w = WEAPONS[k], mine = p.id === g.me && g.trk;
  p.cd -= dt; p.melee -= dt; p.gcd -= dt; if (p.inv > 0) p.inv -= dt; if (p.flash > 0) p.flash -= dt;
  if (p.rel > 0) { p.rel -= dt; if (p.rel <= 0) p.ammo[k] = w.mag; }
  if (i.swap) { i.swap = false; p.cur ^= 1; p.rel = 0; p.cd = .2; if (mine) g.trk.swap++; emit({ e: 'swap', p: p.id, x: p.x, y: p.y - 30 }); }
  if (i.reload) { i.reload = false; startReload(p); }
  if (i.gren) { i.gren = false; throwGren(p); }
  if (i.melee) { i.melee = false; doMelee(p); }
  if (i.aiming) { p.aim = i.aim; p.face = Math.cos(i.aim) >= 0 ? 1 : -1; if (mine) g.trk.aim += dt; }
  else if (i.mx) { p.face = i.mx > 0 ? 1 : -1; p.aim = p.face > 0 ? 0 : Math.PI; }
  if (i.fire) tryFire(p);
  const tgt = i.mx * (p.onGround ? 230 : 210);
  p.vx += (tgt - p.vx) * Math.min(1, dt * (p.onGround ? 12 : 3.5));
  if (mine && Math.abs(i.mx) > .3) g.trk.move += dt;
  if (i.jump) { i.jump = false; if (p.onGround) { p.vy = -520; if (mine) g.trk.jump++; emit({ e: 'jump', p: p.id, x: p.x, y: p.y - 20 }); } }
  p.thrust = false;
  if (i.jet && p.fuel > 0) {
    p.vy -= (2600 + jt.speed * 5) * dt; p.fuel -= 22 * dt; p.thrust = true;
    const mu = 350 + jt.speed * 3; if (p.vy < -mu) p.vy = -mu; if (mine) g.trk.jet += dt;
  } else p.fuel = Math.min(p.fuelMax, p.fuel + (p.onGround ? 35 : 7) * dt);
  p.vy = Math.min(900, p.vy + 1500 * dt);
  p.walk += Math.abs(p.vx) * dt * .06;
  // move + collide
  const R = g.M.rects, bx = 11, bh = 50;
  p.x += p.vx * dt;
  for (const r of R) if (p.x + bx > r.x && p.x - bx < r.x + r.w && p.y > r.y && p.y - bh < r.y + r.h) { if (p.vx > 0) p.x = r.x - bx; else if (p.vx < 0) p.x = r.x + r.w + bx; p.vx = 0; }
  p.y += p.vy * dt; p.onGround = false;
  for (const r of R) if (p.x + bx > r.x && p.x - bx < r.x + r.w && p.y > r.y && p.y - bh < r.y + r.h) { if (p.vy > 0) { p.y = r.y; p.onGround = true; } else p.y = r.y + r.h + bh; p.vy = 0; }
  p.x = clamp(p.x, bx, W - bx); if (p.y < bh) { p.y = bh; p.vy = 0; }
}
function startReload(p) {
  const k = p.w[p.cur], w = WEAPONS[k]; if (p.rel > 0 || p.ammo[k] >= w.mag) return;
  p.rel = w.rel / 1000; if (p.id === G.me && G.trk) G.trk.reload++;
  emit({ e: 'reload', p: p.id, w: k, x: p.x, y: p.y - 30, t: p.rel }); // [SFX]
}
function tryFire(p) {
  const k = p.w[p.cur], w = WEAPONS[k]; if (p.cd > 0 || p.rel > 0) return;
  if ((p.ammo[k] | 0) <= 0) { startReload(p); return; }
  p.ammo[k]--; p.cd = w.rate / 1000;
  const a = p.aim, mx = p.x + p.face * 4 + Math.cos(a) * (w.len + 10), my = p.y - 27 + Math.sin(a) * (w.len + 10);
  for (let n = 0; n < w.pel; n++) {
    const aa = a + (Math.random() - .5) * 2 * w.spread;
    G.bullets.push({ x: mx, y: my, vx: Math.cos(aa) * w.spd, vy: Math.sin(aa) * w.spd, d: w.dmg * (w.kind === 'r' ? .8 : w.pel > 1 ? .2 : .42), own: p.id, l: w.life, k: w.kind, w: k });
  }
  p.vx -= Math.cos(a) * (w.pel > 1 ? 60 : 12);
  emit({ e: 'shot', x: mx, y: my, w: k, p: p.id });
  if (p.id === G.me && G.trk) G.trk.shot++;
}
function throwGren(p) {
  if (p.gcd > 0 || (p.grn <= 0 && !G.training)) return;
  p.gcd = .5; p.grn--; const kind = p.look.throwable || 'grenade', W2 = WEAPONS[kind] || WEAPONS.grenade;
  G.gren.push({ x: p.x, y: p.y - 34, vx: Math.cos(p.aim) * 520 + p.vx * .3, vy: Math.sin(p.aim) * 520 - 120, t: W2.fuse, own: p.id, kind, r: W2.r, d: W2.dmg * .8 });
  if (p.id === G.me && G.trk) G.trk.gren++;
  emit({ e: 'throw', p: p.id, x: p.x, y: p.y - 34 }); // [SFX]
}
function doMelee(p) {
  if (p.melee > 0) return; p.melee = .6; emit({ e: 'punch', x: p.x + p.face * 20, y: p.y - 30, p: p.id });
  if (p.id === G.me && G.trk) G.trk.melee++;
  for (const q of G.players) {
    if (q === p || !q.alive || q.inv > 0 || sameTeam(p, q)) continue;
    const dx = (q.x - p.x) * p.face;
    if (dx > -8 && dx < 48 && Math.abs(q.y - p.y) < 45) { hurt(q, 30, p.id, 'melee'); q.vx += p.face * 220; }
  }
}
function hurt(p, d, own, w) { if (!p.alive || p.inv > 0) return; p.hp -= d; p.flash = .12; if (p.hp <= 0) kill(p, own, w); else emit({ e: 'hurt', p: p.id, x: p.x, y: p.y - 30 }); }
function kill(p, own, w) {
  p.alive = false; p.hp = 0; p.respawn = p.dummy ? 1.5 : 2.6; p.thrust = false; p.deaths++;
  const o = G.players.find(q => q.id === own);
  if (o && o !== p) { o.kills++; if (G.mode === 'team') G.ts[o.team]++; if (G.training && o.id === G.me) G.trk.kills++; }
  const wn = WEAPONS[w] ? WEAPONS[w].n : w === 'melee' ? 'Punch' : 'Explosion';
  emit({ e: 'kill', a: o && o !== p ? o.name : '', v: p.name, w: wn });
  emit({ e: 'boom', x: p.x, y: p.y - 25, r: 0 });
  emit({ e: 'die', p: p.id, x: p.x, y: p.y - 30 }); // [SFX]
  if (!G.training && !G.over) {
    const lead = G.mode === 'team' ? Math.max(G.ts[0], G.ts[1]) : Math.max.apply(null, G.players.map(q => q.kills));
    if (lead >= G.limit) endGame();
  }
}
function boom(x, y, r, d, own, wn) {
  emit({ e: 'boom', x, y, r });
  const o = G.players.find(q => q.id === own);
  for (const p of G.players) {
    if (!p.alive || (o && o !== p && sameTeam(o, p))) continue;
    const dx = p.x - x, dy = p.y - 25 - y, dist = Math.hypot(dx, dy);
    if (dist < r) { const f = 1 - dist / r; hurt(p, d * (.35 + .65 * f) * (o === p ? .5 : 1), own, wn); p.vx += dx / (dist || 1) * 300 * f; p.vy -= 200 * f; }
  }
}
function updateBullets(dt) {
  const B = G.bullets;
  for (let n = B.length - 1; n >= 0; n--) {
    const b = B[n]; let dead = false;
    const sp = Math.hypot(b.vx, b.vy), steps = Math.max(1, Math.ceil(sp * dt / 10)), sx = b.vx * dt / steps, sy = b.vy * dt / steps;
    const o = G.players.find(q => q.id === b.own);
    for (let s = 0; s < steps && !dead; s++) {
      b.x += sx; b.y += sy;
      if (b.x < 0 || b.x > W || b.y < 0 || b.y > H + 50 || solidAt(b.x, b.y)) { dead = true; if (b.k === 'r') boom(b.x - sx, b.y - sy, 100, b.d, b.own, b.w); else emit({ e: 'spark', x: b.x, y: b.y }); break; }
      for (const p of G.players) {
        if (!p.alive || p.id === b.own || p.inv > 0 || (o && sameTeam(o, p))) continue;
        if (b.x > p.x - 12 && b.x < p.x + 12 && b.y > p.y - 54 && b.y < p.y + 2) {
          dead = true; if (b.k === 'r') boom(b.x, b.y, 100, b.d, b.own, b.w); else hurt(p, b.d, b.own, b.w);
          emit({ e: 'hit', x: b.x, y: b.y, v: p.id }); break;
        }
      }
    }
    b.l -= dt; if (b.l <= 0 && !dead) { dead = true; if (b.k === 'r') boom(b.x, b.y, 100, b.d, b.own, b.w); }
    if (!dead && b.k === 'r' && Math.random() < .6) G.parts.push({ x: b.x, y: b.y, vx: 0, vy: 0, l: .4, m: .4, c: 'rgba(200,200,200,.6)', s: 4 });
    if (dead) B.splice(n, 1);
  }
}
function updateGren(dt) {
  for (let n = G.gren.length - 1; n >= 0; n--) {
    const g = G.gren[n]; g.t -= dt; g.vy += 1500 * dt;
    g.x += g.vx * dt; if (solidAt(g.x, g.y)) { g.x -= g.vx * dt; g.vx *= -.5; }
    g.y += g.vy * dt; if (solidAt(g.x, g.y)) { g.y -= g.vy * dt; g.vy *= -.45; g.vx *= .8; if (Math.abs(g.vy) < 40) g.vy = 0; }
    g.x = clamp(g.x, 4, W - 4);
    if (g.t <= 0) { boom(g.x, g.y, g.r, g.d, g.own, g.kind); G.gren.splice(n, 1); }
  }
}
const spawnPick = () => {
  const s = G.M.spawns[Math.random() * G.M.spawns.length | 0];
  if (!G.picks.some(k => Math.hypot(k.x - s[0], k.y - s[1] + 16) < 90)) G.picks.push({ id: G.pid++, x: s[0], y: s[1] - 16, kind: Math.random() < .45 ? 'hp' : 'wp' });
};
function updatePicks(dt) {
  G.spT -= dt; if (G.spT <= 0) { G.spT = G.training ? 4 : 7; if (G.picks.length < (G.training ? 3 : 6)) spawnPick(); }
  for (let n = G.picks.length - 1; n >= 0; n--) {
    const k = G.picks[n];
    for (const p of G.players) {
      if (!p.alive || p.dummy || Math.abs(p.x - k.x) > 24 || Math.abs(p.y - 26 - k.y) > 38) continue;
      if (k.kind === 'hp') { if (p.hp >= 100) continue; p.hp = Math.min(100, p.hp + 45); }
      else { const nk = WPOOL[Math.random() * WPOOL.length | 0]; p.w[p.cur] = nk; p.ammo[nk] = WEAPONS[nk].mag; p.rel = 0; p.grn = Math.min(5, p.grn + 2); }
      emit({ e: 'pick', x: k.x, y: k.y, k: k.kind }); G.picks.splice(n, 1); break;
    }
  }
}
function endGame() {
  if (G.over) return; G.over = true;
  const rows = G.players.map(p => ({ id: p.id, name: p.name, team: p.team, kills: p.kills, deaths: p.deaths, bot: p.bot })).sort((a, b) => b.kills - a.kills || a.deaths - b.deaths);
  const win = G.mode === 'team' ? (G.ts[0] === G.ts[1] ? -1 : G.ts[0] > G.ts[1] ? 0 : 1) : rows[0].id;
  G.res = { rows, win, ts: G.ts.slice(), mode: G.mode };
  { const me = G.players.find(q => q.id === G.me); sfx('matchEnd', win === -1 || !me ? null : G.mode === 'team' ? win === me.team : win === G.me); } // [SFX]
  ONEND && ONEND(G.res);
}

// ---------- bots ----------
function botThink(p, dt) {
  const i = p.input;
  if (!p.alive || p.dummy) { i.mx = 0; i.fire = false; i.jet = false; i.aiming = false; return; }
  const a = p.ai || (p.ai = { t: 0, sx: 1, err: rnd(.08, .3), off: 0, fireOn: true });
  a.t -= dt;
  if (a.t <= 0) {
    a.t = rnd(.25, .65); a.sx = Math.random() < .5 ? -1 : 1; a.off = (Math.random() - .5) * a.err; a.fireOn = Math.random() < .85;
    let best = null, bd = 1e9;
    for (const q of G.players) { if (q === p || !q.alive || sameTeam(p, q)) continue; const d = Math.hypot(q.x - p.x, q.y - p.y); if (d < bd) { bd = d; best = q; } }
    a.tg = best; a.pk = null;
    const want = p.hp < 55 ? 'hp' : (!best || bd > 650 ? 'wp' : null);
    if (want) { let pd = 1e9; for (const k of G.picks) if (k.kind === want) { const d = Math.hypot(k.x - p.x, k.y - p.y); if (d < pd && d < 900) { pd = d; a.pk = k; } } }
  }
  const q = a.tg, chase = a.pk && G.picks.includes(a.pk);
  let tx = p.x, ty = p.y - 30;
  if (chase) { tx = a.pk.x; ty = a.pk.y; } else if (q && q.alive) { tx = q.x; ty = q.y - 30; }
  const dx = tx - p.x, dy = ty - (p.y - 30), d = Math.hypot(dx, dy);
  i.aiming = !!(q && q.alive); if (i.aiming) i.aim = Math.atan2(q.y - 30 - (p.y - 27), q.x - p.x) + a.off;
  if (chase) i.mx = Math.abs(dx) > 20 ? Math.sign(dx) : 0;
  else if (d > 380) i.mx = Math.sign(dx); else if (d < 150) i.mx = -Math.sign(dx); else i.mx = a.sx * .7;
  i.jet = p.fuel > 12 && (ty < p.y - 70 || (p.vy > 380 && p.y < GY - 200));
  if (i.mx && Math.abs(p.vx) < 20 && p.onGround) i.jump = true;
  i.fire = !!(q && q.alive && !chase && a.fireOn && d < 700 && Math.abs(dy) < 350);
  if (q && !chase && d > 180 && d < 500 && p.grn > 0 && Math.random() < dt * .12) i.gren = true;
}

// ---------- client side ----------
function buildSnap() {
  const s = { k: 'snap', tm: G.time, ts: G.ts,
    p: G.players.map(p => [p.id, p.x | 0, p.y | 0, +p.aim.toFixed(2), p.face, p.hp | 0, +p.alive, p.kills, p.deaths, p.cur, p.w[0], p.w[1], p.ammo[p.w[p.cur]] | 0, p.grn, p.fuel | 0, +p.thrust, p.inv > 0 ? 1 : 0, +(p.rel > 0)]),
    b: G.bullets.map(b => [b.x | 0, b.y | 0, b.vx | 0, b.vy | 0, b.k]), g: G.gren.map(g => [g.x | 0, g.y | 0, g.kind]), pk: G.picks.map(k => [k.id, k.x, k.y, k.kind]), ev: G.outEv };
  G.outEv = []; return s;
}
function applySnap(s) {
  if (!G || G.role !== 'client') return;
  G.time = s.tm; G.ts = s.ts;
  for (const a of s.p) {
    const p = G.players.find(q => q.id === a[0]); if (!p) continue;
    if (!p.alive && a[6]) { p.x = a[1]; p.y = a[2]; }
    p.tx = a[1]; p.ty = a[2]; p.aim = a[3]; p.face = a[4]; p.hp = a[5]; p.alive = !!a[6]; p.kills = a[7]; p.deaths = a[8]; p.cur = a[9]; p.w = [a[10], a[11]];
    p.ammo[p.w[p.cur]] = a[12]; p.grn = a[13]; p.fuel = a[14]; p.thrust = !!a[15]; p.inv = a[16] ? 1 : 0; p.rel = a[17] ? 1 : 0;
    const jt = JETS[p.look.jet] || JETS.silver; p.fuelMax = jt.fuel;
  }
  G.bullets = s.b.map(b => ({ x: b[0], y: b[1], vx: b[2], vy: b[3], k: b[4] })); G.gren = s.g.map(g => ({ x: g[0], y: g[1], kind: g[2] }));
  G.picks = s.pk.map(k => ({ id: k[0], x: k[1], y: k[2], kind: k[3] }));
  for (const e of s.ev) handleEv(e);
}
function clientStep(dt) {
  G.t += dt;
  for (const p of G.players) {
    if (p.tx === undefined) continue;
    const dx = p.tx - p.x; p.walk += Math.abs(dx) * .08; p.onGround = Math.abs(p.ty - p.y) < 1.5;
    p.x += dx * Math.min(1, dt * 16); p.y += (p.ty - p.y) * Math.min(1, dt * 16);
    if (p.flash > 0) p.flash -= dt;
  }
  for (const b of G.bullets) { b.x += b.vx * dt; b.y += b.vy * dt; }
}

// ---------- local input / loop ----------
const myInput = () => !G ? null : G.role === 'client' ? G.cin : (G.players.find(p => p.id === G.me) || {}).input;
function flag(n) { const i = myInput(); if (i) i[n] = true; }
function readLocal() {
  const i = myInput(); if (!i) return;
  let mx = IN.mx; const kx = (KEYS.d || KEYS.arrowright ? 1 : 0) - (KEYS.a || KEYS.arrowleft ? 1 : 0); if (kx && !mx) mx = kx;
  i.mx = mx; i.jet = IN.jet || IN.jetS || !!(KEYS.w || KEYS.arrowup);
  let aiming = IN.aiming, aim = IN.aim, fire = IN.fire;
  if (MS.has && G.psx !== undefined) { aim = Math.atan2(MS.y - G.psy, MS.x - G.psx); aiming = true; if (MS.down) fire = true; }
  i.aiming = aiming; i.aim = aim; i.fire = fire;
}
function frame(t) {
  loopId = requestAnimationFrame(frame);
  const dt = Math.min(.05, (t - lastT) / 1000 || 0); lastT = t; if (!G) return;
  readLocal();
  if (!G.paused) { if (G.role === 'client') clientStep(dt); else step(dt); }
  particlesStep(dt); sfx('tick', dt); NETTICK && NETTICK(dt); render(); HUD && HUD();
}
function sizeCv() {
  if (!cv) return; const dpr = Math.min(2, window.devicePixelRatio || 1);
  cv._dpr = dpr; cv.width = Math.floor(innerWidth * dpr); cv.height = Math.floor(innerHeight * dpr);
}
function startLoop() { cancelAnimationFrame(loopId); lastT = performance.now(); loopId = requestAnimationFrame(frame); }
function stopLoop() { cancelAnimationFrame(loopId); loopId = 0; sfx('leave'); }

addEventListener('keydown', e => {
  const k = e.key.toLowerCase(); KEYS[k] = true; if (!G) return;
  if (k === ' ') { flag('jump'); e.preventDefault(); } else if (k === 'g') flag('gren'); else if (k === 'f') flag('melee'); else if (k === 'r') flag('reload'); else if (k === 'q') flag('swap');
});
addEventListener('keyup', e => { KEYS[e.key.toLowerCase()] = false; });
addEventListener('mousemove', e => { MS.x = e.clientX; MS.y = e.clientY; MS.has = true; });
addEventListener('mousedown', e => { if (e.target.closest && e.target.closest('#gc')) MS.down = true; });
addEventListener('mouseup', () => { MS.down = false; });
