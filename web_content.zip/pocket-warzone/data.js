'use strict';
// ===== POCKET WARZONE — game data =====
const W = 2400, H = 1000, GY = 900;

// Each platform: [x, y, width, height?]
const MAPS = [
  { id: 'desert', name: 'Desert Outpost', sky: ['#f7d79a', '#eaa96b'], ground: '#c99a5b', gtop: '#e0b574', plat: '#8f6a3d', ptop: '#c59a58', deco: 'desert',
    pl: [[300,760,260],[700,650,300],[1150,770,220],[1500,600,300],[1900,740,260],[1000,470,240],[150,540,200],[2050,500,200],[1350,360,180],[820,830,110,70],[1650,830,120,70]] },
  { id: 'urban', name: 'Urban Ruins', sky: ['#9aa7b4', '#c9c2b6'], ground: '#5c5a58', gtop: '#7a7773', plat: '#6f6d6a', ptop: '#8e8a84', deco: 'city',
    pl: [[200,780,300],[620,680,240],[980,560,300],[1400,700,260],[1750,560,260],[2050,760,260],[500,440,220],[1250,400,240],[1900,380,200],[1100,820,120,80]] },
  { id: 'snow', name: 'Snow Base', sky: ['#cfe6f7', '#f2f8fc'], ground: '#dfe9f2', gtop: '#ffffff', plat: '#6d7f93', ptop: '#f4f9ff', deco: 'snow',
    pl: [[250,740,280],[650,600,220],[1000,740,300],[1450,640,240],[1850,520,260],[2100,760,220],[400,450,220],[1200,450,260],[800,330,200],[1650,820,140,80]] },
  { id: 'jungle', name: 'Jungle Ruins', sky: ['#6fb87a', '#c6e5a0'], ground: '#4a3a24', gtop: '#4f9a3a', plat: '#6b6b5a', ptop: '#5aa845', deco: 'jungle',
    pl: [[180,720,260],[560,610,240],[900,760,260],[1300,640,300],[1700,740,240],[2050,600,260],[400,460,200],[1000,450,260],[1600,430,220],[2100,400,200],[1500,830,120,70]] },
  { id: 'port', name: 'Port Harbor', sky: ['#8fc7e8', '#d6eef7'], ground: '#6c6f73', gtop: '#8b8f94', plat: '#c8503a', ptop: '#e3704f', deco: 'port',
    pl: [[220,800,200,100],[480,700,260],[860,600,260],[1200,740,240],[1550,600,300],[1950,720,260],[700,430,220],[1300,430,240],[1850,430,200],[1000,820,160,80]] },
  { id: 'night', name: 'Night Base', sky: ['#0b1230', '#1d2a54'], ground: '#2a2f3a', gtop: '#3d4658', plat: '#394150', ptop: '#566178', deco: 'night',
    pl: [[240,760,280],[640,640,260],[1050,780,240],[1450,620,260],[1850,740,280],[450,470,220],[1000,450,260],[1600,440,240],[2100,520,200],[1300,830,120,70]] }
];

// dmg = number shown in the catalog. Real damage is scaled in the engine.
const WEAPONS = {
  ak47:   { n: 'AK-47 Rifle',   cat: 'Rifles',     slot: 'primary',   dmg: 42,  price: 2500, rate: 135,  spd: 1000, mag: 30, rel: 1600, spread: .07, pel: 1, col: '#7a4a22', len: 30, life: 1,   kind: 'b' },
  m4:     { n: 'M4 Rifle',      cat: 'Rifles',     slot: 'primary',   dmg: 38,  price: 2200, rate: 115,  spd: 1050, mag: 30, rel: 1500, spread: .05, pel: 1, col: '#3a3f45', len: 30, life: 1,   kind: 'b' },
  sniper: { n: 'Sniper Rifle',  cat: 'Snipers',    slot: 'primary',   dmg: 95,  price: 4800, rate: 1100, spd: 2000, mag: 5,  rel: 1900, spread: 0,   pel: 1, col: '#6b4423', len: 40, life: 1.2, kind: 'b' },
  bazooka:{ n: 'Bazooka',       cat: 'Heavy',      slot: 'primary',   dmg: 120, price: 6000, rate: 1400, spd: 620,  mag: 2,  rel: 2600, spread: 0,   pel: 1, col: '#55613a', len: 38, life: 2,   kind: 'r' },
  shotgun:{ n: 'Shotgun',       cat: 'Heavy',      slot: 'primary',   dmg: 70,  price: 3500, rate: 750,  spd: 900,  mag: 6,  rel: 1800, spread: .14, pel: 6, col: '#8a5a2b', len: 28, life: .32, kind: 'b' },
  mg:     { n: 'Machine Gun',   cat: 'Heavy',      slot: 'primary',   dmg: 55,  price: 4200, rate: 85,   spd: 1050, mag: 60, rel: 2400, spread: .1,  pel: 1, col: '#4a4f55', len: 34, life: .9,  kind: 'b' },
  pistol: { n: 'Pistol',        cat: 'Pistols',    slot: 'secondary', dmg: 25,  price: 1200, rate: 340,  spd: 950,  mag: 12, rel: 900,  spread: .03, pel: 1, col: '#5b7fb8', len: 15, life: .8,  kind: 'b' },
  laser:  { n: 'Laser Gun',     cat: 'Pistols',    slot: 'secondary', dmg: 65,  price: 7000, rate: 220,  spd: 1700, mag: 20, rel: 1200, spread: .01, pel: 1, col: '#3cc8d8', len: 18, life: .9,  kind: 'l' },
  grenade:{ n: 'Grenade',       cat: 'Explosives', slot: 'throw',     dmg: 80,  price: 1800, fuse: 2.2, r: 110 },
  bomb:   { n: 'Bomb',          cat: 'Explosives', slot: 'throw',     dmg: 110, price: 5000, fuse: 2.8, r: 150 }
};
const WPOOL = ['ak47', 'm4', 'sniper', 'shotgun', 'mg', 'laser', 'bazooka', 'pistol'];

const ITEMS = {
  camo:      { n: 'Military Camo Uniform', slot: 'top', tab: 'Attire',  price: 1200, body: '#5d6e3a', pants: '#586b34', vest: '#3d4a29', camo: 1 },
  tactical:  { n: 'Black Tactical Suit',   slot: 'top', tab: 'Suits',   price: 1500, body: '#2b2b2e', pants: '#1d1d20', vest: '#141416' },
  street:    { n: 'Street Jacket',         slot: 'top', tab: 'Jackets', price: 900,  body: '#2f2f33', pants: '#3a3d44', jacket: 1, patch: '#e07a1f' },
  denim:     { n: 'Denim Jacket',          slot: 'top', tab: 'Jackets', price: 750,  body: '#3f74b8', pants: '#2b4470', jacket: 1 },
  polo:      { n: 'Polo Shirt',            slot: 'top', tab: 'Shirts',  price: 400,  body: '#6b9c3b', pants: '#5a5648' },
  tshirt:    { n: 'T-Shirt',               slot: 'top', tab: 'Shirts',  price: 250,  body: '#9a9ea3', pants: '#4f5d3a' },
  formal:    { n: 'Formal Suit',           slot: 'top', tab: 'Suits',   price: 2000, body: '#18181b', pants: '#18181b', tie: 1 },
  hoodie:    { n: 'Hoodie',                slot: 'top', tab: 'Shirts',  price: 550,  body: '#7d838c', pants: '#3f4350', hood: 1 },
  sunglasses:{ n: 'Sunglasses',            slot: 'glasses', tab: 'Glasses', price: 300, lens: '#111' },
  eyeshade:  { n: 'Eye Shade Glasses',     slot: 'glasses', tab: 'Glasses', price: 350, lens: '#e8c820' },
  boots:     { n: 'Timberland Boots',      slot: 'shoes', tab: 'Footwear', price: 1000, col: '#a0642c', h: 9 },
  sneakers:  { n: 'Sneakers',              slot: 'shoes', tab: 'Footwear', price: 600,  col: '#eef0ee', h: 6 },
  normal:    { n: 'Normal Shoes',          slot: 'shoes', tab: 'Footwear', price: 500,  col: '#6b4a30', h: 6 },
  slippers:  { n: 'Slippers',              slot: 'shoes', tab: 'Footwear', price: 150,  col: '#7fb06a', h: 4 },
  sandals:   { n: 'Sandals',               slot: 'shoes', tab: 'Footwear', price: 200,  col: '#a8683a', h: 4 },
  army:      { n: 'Army Boots',            slot: 'shoes', tab: 'Footwear', price: 0,    col: '#3b3f2a', h: 10, hide: 1 }
};

const SKINS = ['#f3c9a0', '#d8a577', '#b07a4e', '#8a8d4a', '#6f8a3e', '#e8e5cc', '#b8b27a'];
const FACES = [
  { n: 'Happy', price: 0 }, { n: 'Angry', price: 0 }, { n: 'Cool', price: 300 },
  { n: 'Bearded', price: 300 }, { n: 'Girl', price: 300 }, { n: 'Robot', price: 500 }
];
const HELMETS = [
  { n: 'Army Green', col: '#556b2f', price: 0 }, { n: 'Desert Tan', col: '#b89a62', price: 200 },
  { n: 'Night Black', col: '#2a2d30', price: 200 }, { n: 'Blue Ops', col: '#3a66a8', price: 200 }
];
const JETS = {
  silver:  { n: 'Basic Silver Jetpack', speed: 45,  fuel: 60,  price: 500,   tier: 0, col: '#b9c0c8' },
  army:    { n: 'Army Green Jetpack',   speed: 60,  fuel: 75,  price: 1200,  tier: 0, col: '#4f6b3a' },
  turbo:   { n: 'Turbo Red Jetpack',    speed: 85,  fuel: 50,  price: 2000,  tier: 1, col: '#c0392b' },
  blue:    { n: 'Blue Flame Jetpack',   speed: 95,  fuel: 70,  price: 3500,  tier: 1, col: '#5d6d5a', fl: ['#2fa8ff', '#bfe9ff'] },
  golden:  { n: 'Golden Jetpack',       speed: 110, fuel: 80,  price: 6000,  tier: 2, col: '#d9a62b' },
  neon:    { n: 'Neon Purple Jetpack',  speed: 125, fuel: 90,  price: 9000,  tier: 2, col: '#8e44d6', fl: ['#c06bff', '#f0d0ff'] },
  rocket:  { n: 'Rocket Jetpack',       speed: 140, fuel: 65,  price: 12000, tier: 3, col: '#e8e8ec' },
  diamond: { n: 'Diamond Jetpack',      speed: 160, fuel: 100, price: 25000, tier: 3, col: '#7fd6f2', fl: ['#7fe8ff', '#ffffff'] }
};
const TIERS = [['Basic', 1], ['Pro', 3], ['Elite', 6], ['Legendary', 10]];

const LESSONS = [
  { t: 'Move & Walk',            d: 'Use the left joystick to move around',        ok: k => k.move > 1.5 },
  { t: 'Aim',                    d: 'Drag the right joystick to aim',              ok: k => k.aim > 1 },
  { t: 'Shoot',                  d: 'Pull the right joystick out far to shoot',    ok: k => k.shot >= 5 },
  { t: 'Jump',                   d: 'Tap JUMP twice',                              ok: k => k.jump >= 2 },
  { t: 'Fly with Jetpack',       d: 'Hold JET to fly',                             ok: k => k.jet > 1.5 },
  { t: 'Grenade & Melee',        d: 'Throw a grenade and punch',                   ok: k => k.gren >= 1 && k.melee >= 1 },
  { t: 'Reload & Switch Weapon', d: 'Tap RELOAD, then SWAP',                       ok: k => k.reload >= 1 && k.swap >= 1 }
];

// Control pad: x/y are % of the screen, s = size scale, o = opacity
const CTLIDS = ['move', 'aim', 'jet', 'jump', 'gren', 'melee', 'reload', 'swap'];
const CTLLBL = { move: 'MOVE', aim: 'AIM / SHOOT', jet: 'JET', jump: 'JUMP', gren: 'GRENADE', melee: 'MELEE', reload: 'RELOAD', swap: 'SWAP' };
const CTLBASE = { move: 124, aim: 124, jet: 68, jump: 58, gren: 54, melee: 54, reload: 46, swap: 46 };
const CTLDEF = {
  move: { x: 14, y: 70, s: 1, o: .8 }, gren: { x: 31, y: 86, s: 1, o: .8 }, melee: { x: 39, y: 72, s: 1, o: .8 },
  reload: { x: 50, y: 90, s: 1, o: .8 }, swap: { x: 57, y: 76, s: 1, o: .8 }, jump: { x: 64, y: 86, s: 1, o: .8 },
  jet: { x: 74, y: 76, s: 1, o: .8 }, aim: { x: 88, y: 66, s: 1, o: .8 }
};

// ===== Save data =====
const DEF = {
  name: 'Rookie', coins: 5000, xp: 0, id: '',
  owned: { m4: 1, pistol: 1, grenade: 1, camo: 1, tshirt: 1, army: 1, silver: 1 },
  eq: { top: 'camo', glasses: '', shoes: 'army', face: 0, skin: 0, helmet: 0, jet: 'silver', primary: 'm4', secondary: 'pistol', throwable: 'grenade' },
  lessons: [], ctrl: null, sound: true, server: '', lastDaily: 0, stats: { kills: 0, wins: 0, games: 0 }
};
let SAVE;
try { SAVE = Object.assign({}, JSON.parse(JSON.stringify(DEF)), JSON.parse(localStorage.getItem('pw_save') || '{}')); }
catch (e) { SAVE = JSON.parse(JSON.stringify(DEF)); }
if (!SAVE.id) SAVE.id = Math.random().toString(36).slice(2, 8);
function save() { try { localStorage.setItem('pw_save', JSON.stringify(SAVE)); } catch (e) {} }
function ctlCfg(id) { return Object.assign({}, CTLDEF[id], (SAVE.ctrl || {})[id] || {}); }
