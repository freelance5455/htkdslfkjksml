# Hospital Private Data — Android APK build

This project is the existing React/Vite application prepared for Capacitor Android packaging.

## Build

```bash
npm install
npm run build:web
npx cap add android
npx cap sync android
cd android
./gradlew assembleDebug
```

The standard debug APK is produced at:

`android/app/build/outputs/apk/debug/app-debug.apk`

If an exact `app/debug.apk` file is required, from the project root run:

```bash
mkdir -p app
cp android/app/build/outputs/apk/debug/app-debug.apk app/debug.apk
```

## Important

- The Android app uses the same Supabase backend as the web app.
- Do not put Supabase service-role/secret keys into the frontend or APK.
- The Capacitor Android platform must be generated with `npx cap add android` in an environment that has the Capacitor CLI installed.
- Android SDK/Gradle are required to compile the APK.
