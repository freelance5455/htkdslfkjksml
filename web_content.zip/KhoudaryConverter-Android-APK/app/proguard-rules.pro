# Keep WebView JS interfaces
-keepattributes *Annotation*
