STUDYMAX - BỘ 600 CÂU HỎI / 6 MÔN

Cấu trúc:
- index.html: ứng dụng học tập hoàn chỉnh
- style.css: giao diện
- questions.json: 600 câu hỏi, 100 câu/môn

Môn:
1. Toán
2. Hóa học
3. Sinh học
4. Tiếng Anh
5. Ngữ văn
6. Vật lý

Cách chạy trên Acode:
1. Tạo một thư mục tên StudyMax.
2. Đặt cả 3 file vào cùng thư mục.
3. Mở index.html.
4. Bấm Preview/Chạy.
5. Chọn môn và làm bài.

Lưu ý:
- index.html đọc questions.json bằng fetch(), vì vậy Preview của Acode cần chạy trang theo chế độ web/preview có hỗ trợ file liên kết.
- Nếu Preview trên máy không đọc được questions.json, có thể dùng một local server trong Acode hoặc chuyển toàn bộ dữ liệu câu hỏi vào JavaScript ở bước tiếp theo.
