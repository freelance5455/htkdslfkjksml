const properties = [
 {name:"Villa Aurelia",type:"Villa",loc:"Vaishali Nagar · Jaipur",price:"₹4.85 Cr",meta:"4 bed · 5 bath · 4,850 sq.ft",img:"https://images.unsplash.com/photo-1600607688969-a5bfcd646154?auto=format&fit=crop&w=1000&q=80",tag:"EDITOR'S PICK"},
 {name:"The Altair Penthouse",type:"Penthouse",loc:"C-Scheme · Jaipur",price:"₹3.20 Cr",meta:"3 bed · 4 bath · 3,100 sq.ft",img:"https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&w=1000&q=80",tag:"NEW"},
 {name:"Casa Verde",type:"Apartment",loc:"Malviya Nagar · Jaipur",price:"₹1.42 Cr",meta:"3 bed · 3 bath · 2,080 sq.ft",img:"https://images.unsplash.com/photo-1600607687920-4e2a09cf159d?auto=format&fit=crop&w=1000&q=80",tag:"VERIFIED"},
 {name:"Aranya Estate",type:"Farmhouse",loc:"Ajmer Road · Jaipur",price:"₹2.75 Cr",meta:"4 bed · 4 bath · 6,400 sq.ft",img:"https://images.unsplash.com/photo-1600585154526-990dced4db0d?auto=format&fit=crop&w=1000&q=80",tag:"PRIVATE"},
 {name:"Maison Élan",type:"Villa",loc:"Jagatpura · Jaipur",price:"₹2.10 Cr",meta:"4 bed · 4 bath · 3,700 sq.ft",img:"https://images.unsplash.com/photo-1600047509807-ba8f99d2cdde?auto=format&fit=crop&w=1000&q=80",tag:"VERIFIED"},
 {name:"Skyline 41",type:"Penthouse",loc:"Tonk Road · Jaipur",price:"₹2.68 Cr",meta:"3 bed · 4 bath · 2,850 sq.ft",img:"https://images.unsplash.com/photo-1600607687920-4e2a09cf159d?auto=format&fit=crop&w=1000&q=80",tag:"LIMITED"}
];

let activeType="all";
function render(list=properties){
 const grid=document.getElementById("propertyGrid");
 grid.innerHTML=list.length?list.map((p,i)=>`
 <article class="property">
   <div class="property-img" style="background-image:url('${p.img}')">
     <span class="tag">${p.tag}</span><button class="heart" onclick="toggleHeart(this)">♡</button>
   </div>
   <div class="property-body">
     <h3>${p.name}</h3><div class="location">${p.loc}</div>
     <div class="property-meta"><span>${p.meta.split(" · ")[0]}</span><span>${p.meta.split(" · ")[1]}</span><span>${p.meta.split(" · ")[2]}</span></div>
     <div class="property-foot"><span class="price">${p.price}</span><button class="view" onclick="openProperty(${i})">VIEW RESIDENCE →</button></div>
   </div>
 </article>`).join(""):`<div style="grid-column:1/-1;padding:60px;text-align:center;color:#999">No matching residences found. Try another search.</div>`;
}
function filterChip(type){
 activeType=type;
 document.querySelectorAll(".chip").forEach(c=>c.classList.toggle("active",c.dataset.chip===type));
 applyFilters();
 document.getElementById("discover").scrollIntoView({behavior:"smooth"});
}
function applyFilters(){
 const q=document.getElementById("searchInput").value.toLowerCase().trim();
 const select=document.getElementById("typeFilter").value;
 const type=select!=="all"?select:activeType;
 render(properties.filter(p=>(type==="all"||p.type===type)&&(!q||(p.name+" "+p.loc+" "+p.type).toLowerCase().includes(q))));
}
function clearFilters(){document.getElementById("searchInput").value="";document.getElementById("typeFilter").value="all";filterChip("all")}
function toggleHeart(btn){btn.textContent=btn.textContent==="♡"?"♥":"♡";btn.style.color=btn.textContent==="♥"?"#c8a96b":"white"}
function scrollToSection(id){document.getElementById(id).scrollIntoView({behavior:"smooth"})}
function openProperty(i){
 const p=properties[i];
 showModal(`<div class="eyebrow">${p.tag}</div><h2>${p.name}</h2><p>${p.loc}<br>${p.meta}<br><br><strong style="color:#f4f1ea;font-size:20px">${p.price}</strong></p><p>This is a polished demo property page. A production version can add gallery, 360° tour, floor plan, amenities, locality intelligence, EMI tools and verified documents.</p><div class="modal-actions"><button class="outline-btn" onclick="closeModal()">Close</button><button class="gold-btn" onclick="alert('Demo: site visit request captured');closeModal()">Request a private visit</button></div>`);
}
function openModal(type){
 if(type==="ai") showModal(`<div class="eyebrow">ESTÉRA INTELLIGENCE</div><h2>Private property concierge</h2><p>Describe your ideal home and this demo will create a sample shortlist.</p><input id="aiPrompt" placeholder="e.g. 3BHK in Jaipur under ₹2 Cr, peaceful area"><div class="modal-actions"><button class="outline-btn" onclick="closeModal()">Cancel</button><button class="gold-btn" onclick="runAI()">Find my homes →</button></div>`);
 else showModal(`<div class="eyebrow">WELCOME BACK</div><h2>Sign in to your private collection.</h2><input placeholder="Email address"><input placeholder="Password" type="password"><div class="modal-actions"><button class="outline-btn" onclick="closeModal()">Cancel</button><button class="gold-btn" onclick="alert('Demo sign-in');closeModal()">Continue</button></div>`);
}
function runAI(){
 const q=(document.getElementById("aiPrompt")?.value||"").toLowerCase();
 const picks=properties.filter(p=>!q||p.type.toLowerCase().includes(q.includes("villa")?"villa":"____")||p.loc.toLowerCase().includes("jaipur")).slice(0,3);
 showModal(`<div class="eyebrow">MATCH COMPLETE</div><h2>Your shortlist is ready.</h2><p>Based on your request, ESTÉRA would prioritize these residences in a production experience:</p>${(picks.length?picks:properties.slice(0,3)).map(p=>`<div style="border-top:1px solid var(--line);padding:13px 0;display:flex;justify-content:space-between"><span>${p.name}<small style="display:block;color:#999">${p.loc}</small></span><b>${p.price}</b></div>`).join("")}<div class="modal-actions"><button class="gold-btn" onclick="closeModal()">Explore shortlist</button></div>`);
}
function showModal(html){document.getElementById("modal").innerHTML=html;document.getElementById("modalBackdrop").classList.add("show")}
function closeModal(e){if(!e||e.target===document.getElementById("modalBackdrop"))document.getElementById("modalBackdrop").classList.remove("show")}
document.querySelectorAll(".chip").forEach(c=>c.addEventListener("click",()=>filterChip(c.dataset.chip)));
document.getElementById("searchInput").addEventListener("keydown",e=>{if(e.key==="Enter")applyFilters()});
document.getElementById("themeBtn").addEventListener("click",()=>document.body.classList.toggle("light"));
render();
