# بناء APK مجانًا

أسهل مسار عملي هو استخدام Capacitor.

1. ثبّت Node.js وAndroid Studio.
2. أنشئ مجلدًا جديدًا وشغّل:
   npm init -y
   npm install @capacitor/core @capacitor/cli @capacitor/android
3. انسخ مجلد `www` إلى المشروع.
4. شغّل:
   npx cap init Runner com.example.runner --web-dir www
   npx cap add android
   npx cap copy
   npx cap open android
5. من Android Studio اختر Build > Build APK(s).

هذه الملفات توفر كود اللعبة وواجهة الويب. بناء APK النهائي يتطلب بيئة Android/Gradle على جهازك.
