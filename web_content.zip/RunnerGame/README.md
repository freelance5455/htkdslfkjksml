# Runner Game

لعبة Endless Runner عربية بسيطة.

## التشغيل على الكمبيوتر
افتح `www/index.html` في متصفح حديث.

## تحويلها إلى Android
المجلد `www` هو نسخة اللعبة الجاهزة للتغليف داخل مشروع Android/Capacitor أو WebView.
راجع `ANDROID_BUILD.md` للخطوات.

ملاحظة: هذا المشروع لا يحتوي على توقيع متجر Google Play أو مفتاح نشر.
