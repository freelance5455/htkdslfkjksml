(() => {
const canvas=document.getElementById("game"),ctx=canvas.getContext("2d");
const W=canvas.width,H=canvas.height,G=430;
const scoreEl=document.getElementById("score"),bestEl=document.getElementById("best"),speedEl=document.getElementById("speed");
const menu=document.getElementById("menu"),over=document.getElementById("gameover");
let best=Number(localStorage.getItem("runner_best")||0),score=0,speed=7,obs=[],particles=[],running=false,last=0,spawn=0;
const p={x:125,y:G-88,w:46,h:68,vy:0,ground:true,run:0};

bestEl.textContent=best;

function reset(){
 score=0;speed=7;obs=[];particles=[];spawn=45;running=true;
 p.y=G-p.h;p.vy=0;p.ground=true;p.run=0;
 menu.classList.add("hidden");over.classList.add("hidden");
 last=performance.now();requestAnimationFrame(loop);
}
function jump(){
 if(!running){reset();return}
 if(p.ground){p.vy=-15;p.ground=false}
}
function addObstacle(){
 const tall=Math.random()<Math.min(.25+score/2500,.55);
 const w=tall?40:42+Math.random()*25,h=tall?80:38+Math.random()*34;
 obs.push({x:W+20,y:G-h,w,h,type:tall?"wall":"rock"});
}
function collide(a,b){
 return a.x+7<b.x+b.w && a.x+a.w-7>b.x && a.y+8<b.y+b.h && a.y+a.h>b.y;
}
function burst(x,y){
 for(let i=0;i<18;i++) particles.push({x,y,vx:(Math.random()-.5)*6,vy:(Math.random()-1)*6,life:30});
}
function end(){
 running=false;
 best=Math.max(best,Math.floor(score));localStorage.setItem("runner_best",best);
 document.getElementById("finalScore").textContent=Math.floor(score);
 document.getElementById("finalBest").textContent=best;
 bestEl.textContent=best;over.classList.remove("hidden");
}
function draw(){
 ctx.clearRect(0,0,W,H);
 const sky=ctx.createLinearGradient(0,0,0,H);sky.addColorStop(0,"#82d3ff");sky.addColorStop(.68,"#eaf9ff");sky.addColorStop(.681,"#c8d6b9");sky.addColorStop(1,"#aebd9e");ctx.fillStyle=sky;ctx.fillRect(0,0,W,H);
 // sun
 ctx.fillStyle="#fff5b0";ctx.beginPath();ctx.arc(790,90,45,0,Math.PI*2);ctx.fill();
 // distant hills
 ctx.fillStyle="#a9c8a9";ctx.beginPath();ctx.moveTo(0,400);for(let x=0;x<=W;x+=80)ctx.quadraticCurveTo(x+40,340+Math.sin(x)*10,x+80,400);ctx.lineTo(W,H);ctx.lineTo(0,H);ctx.fill();
 // ground
 ctx.fillStyle="#879875";ctx.fillRect(0,G,W,H-G);
 ctx.fillStyle="rgba(255,255,255,.3)";for(let x=-(score*speed%80);x<W;x+=80)ctx.fillRect(x,G+35,48,4);
 // character
 const bob=p.ground?Math.sin(p.run)*3:0;
 ctx.save();ctx.translate(p.x,p.y+bob);
 ctx.fillStyle="#202d35";ctx.fillRect(10,23,27,38);
 ctx.beginPath();ctx.arc(23,15,16,0,Math.PI*2);ctx.fill();
 ctx.fillStyle="#fff";ctx.fillRect(29,10,6,6);
 ctx.fillStyle="#202d35";ctx.fillRect(10,59,10,11);ctx.fillRect(28,59,10,11);
 ctx.restore();
 // obstacles
 obs.forEach(o=>{
   if(o.type==="rock"){
     ctx.fillStyle="#6c584a";ctx.beginPath();ctx.moveTo(o.x,o.y+o.h);ctx.lineTo(o.x+8,o.y+12);ctx.lineTo(o.x+o.w*.45,o.y);ctx.lineTo(o.x+o.w-5,o.y+9);ctx.lineTo(o.x+o.w,o.y+o.h);ctx.closePath();ctx.fill();
   }else{
     ctx.fillStyle="#67504a";ctx.fillRect(o.x,o.y,o.w,o.h);
     ctx.fillStyle="rgba(255,255,255,.16)";ctx.fillRect(o.x+7,o.y+8,6,o.h-16);
   }
 });
 particles.forEach(q=>{ctx.fillStyle="rgba(255,255,255,.8)";ctx.fillRect(q.x,q.y,4,4)});
}
function loop(now){
 if(!running)return;
 const dt=Math.min((now-last)/16.67,2);last=now;
 score+=.16*dt;speed=Math.min(15,7+score/180);
 spawn-=dt;
 if(spawn<=0){addObstacle();spawn=Math.max(24,65-speed*2.4-score/100)+Math.random()*20}
 p.vy+=.7*dt;p.y+=p.vy*dt;p.run+=.25*dt;
 if(p.y>=G-p.h){p.y=G-p.h;p.vy=0;p.ground=true}
 obs.forEach(o=>o.x-=speed*dt);obs=obs.filter(o=>o.x+o.w>-20);
 particles.forEach(q=>{q.x+=q.vx*dt;q.y+=q.vy*dt;q.vy+=.2*dt;q.life-=dt});particles=particles.filter(q=>q.life>0);
 for(const o of obs)if(collide(p,o)){burst(p.x+20,p.y+25);end();break}
 scoreEl.textContent=Math.floor(score);speedEl.textContent=(speed/7).toFixed(1)+"x";bestEl.textContent=best;
 draw();if(running)requestAnimationFrame(loop);
}
document.getElementById("start").onclick=reset;
document.getElementById("again").onclick=reset;
document.getElementById("jump").onclick=jump;
document.getElementById("restart").onclick=reset;
canvas.addEventListener("pointerdown",e=>{e.preventDefault();jump()});
window.addEventListener("keydown",e=>{if(e.code==="Space"||e.code==="ArrowUp"){e.preventDefault();jump()}});
draw();
})();