package hu.muszaki.reggel

import android.content.Context
import androidx.work.Worker
import androidx.work.WorkerParameters
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

class WeatherAlertWorker(context: Context, params: WorkerParameters) : Worker(context, params) {
    override fun doWork(): Result {
        val prefs = applicationContext.getSharedPreferences("weather_alerts", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("enabled", true)) return Result.success()
        return try {
            val url = URL(
                "https://api.open-meteo.com/v1/forecast?latitude=47.426&longitude=18.589" +
                    "&current=weather_code&hourly=precipitation_probability,weather_code" +
                    "&timezone=Europe%2FBudapest&forecast_days=1"
            )
            val connection = (url.openConnection() as HttpURLConnection).apply {
                connectTimeout = 12000
                readTimeout = 12000
                requestMethod = "GET"
            }
            val json = connection.inputStream.bufferedReader().use { it.readText() }
            connection.disconnect()
            val root = JSONObject(json)
            val hourly = root.getJSONObject("hourly")
            val times = hourly.getJSONArray("time")
            val probs = hourly.getJSONArray("precipitation_probability")
            val codes = hourly.getJSONArray("weather_code")
            val formatter = SimpleDateFormat("yyyy-MM-dd'T'HH:mm", Locale.US).apply {
                timeZone = TimeZone.getTimeZone("Europe/Budapest")
            }
            val now = Date()
            var rainAt = -1
            var stormAt = -1
            for (i in 0 until times.length()) {
                val time = formatter.parse(times.optString(i)) ?: continue
                val delta = time.time - now.time
                if (delta < -30 * 60 * 1000L || delta > 3 * 60 * 60 * 1000L) continue
                val code = codes.optInt(i, 0)
                if (stormAt < 0 && (code == 95 || code == 96 || code == 99)) stormAt = i
                if (rainAt < 0 && probs.optInt(i, 0) >= 70) rainAt = i
            }
            if (stormAt >= 0) {
                maybeNotify(prefs, "storm", "Zivatarfigyelés", "Zivatar lehet Alcsútdoboz környékén a következő órákban.")
            } else if (rainAt >= 0) {
                maybeNotify(prefs, "rain", "Esőfigyelés", "Az eső valószínűsége legalább 70% a következő órák egyikében Alcsútdoboz környékén.")
            }
            Result.success()
        } catch (_: Exception) {
            Result.retry()
        }
    }

    private fun maybeNotify(
        prefs: android.content.SharedPreferences,
        type: String,
        title: String,
        message: String
    ) {
        val now = System.currentTimeMillis()
        val key = "last_${type}_notification"
        val last = prefs.getLong(key, 0L)
        if (now - last < 6 * 60 * 60 * 1000L) return
        WeatherNotifications.show(applicationContext, title, message, type)
        prefs.edit().putLong(key, now).apply()
    }
}
