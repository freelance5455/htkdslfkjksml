package hu.muszaki.reggel

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build

object WeatherNotifications {
    private const val CHANNEL_ID = "weather_alerts"

    fun createChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Időjárási figyelmeztetések",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Eső- és zivatarfigyelmeztetések Alcsútdoboz környékére"
                enableVibration(true)
            }
            manager.createNotificationChannel(channel)
        }
    }

    fun show(context: Context, title: String, message: String, type: String) {
        try {
            if (Build.VERSION.SDK_INT >= 33 &&
                context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) return
            createChannel(context)
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val notification = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                Notification.Builder(context, CHANNEL_ID)
            } else {
                @Suppress("DEPRECATION")
                Notification.Builder(context)
            }.setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle(title)
                .setContentText(message)
                .setStyle(Notification.BigTextStyle().bigText(message))
                .setAutoCancel(true)
                .setCategory(Notification.CATEGORY_EVENT)
                .build()
            manager.notify(if (type == "storm") 4202 else 4201, notification)
        } catch (_: Exception) {
            // Notification permission may be denied by the user.
        }
    }
}
