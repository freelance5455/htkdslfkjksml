package hu.muszaki.reggel

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.content.Context
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit

class MainActivity : Activity() {
    private lateinit var web: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WeatherNotifications.createChannel(this)
        requestNotificationPermissionIfNeeded()
        scheduleWeatherChecks()

        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.webChromeClient = WebChromeClient()
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(AlertsBridge(this), "AndroidAlerts")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 4102)
        }
    }

    private fun scheduleWeatherChecks() {
        val constraints = Constraints.Builder()
            .setRequiredNetworkType(NetworkType.CONNECTED)
            .build()
        val request = PeriodicWorkRequestBuilder<WeatherAlertWorker>(1, TimeUnit.HOURS)
            .setConstraints(constraints)
            .build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "muszaki-reggel-weather-alerts",
            ExistingPeriodicWorkPolicy.UPDATE,
            request
        )
    }

    @Deprecated("Deprecated in Android API")
    override fun onBackPressed() {
        if (::web.isInitialized && web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}

class AlertsBridge(private val activity: Activity) {
    @JavascriptInterface
    fun notify(title: String, message: String, type: String) {
        WeatherNotifications.show(activity, title, message, type)
    }

    @JavascriptInterface
    fun setEnabled(enabled: Boolean) {
        activity.getSharedPreferences("weather_alerts", Context.MODE_PRIVATE)
            .edit().putBoolean("enabled", enabled).apply()
    }
}
