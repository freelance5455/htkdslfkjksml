plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "hu.muszaki.reggel"
    compileSdk = 35
    defaultConfig {
        applicationId = "hu.muszaki.reggel"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
