plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "hu.muszaki.reggel"
    compileSdk = 35
    defaultConfig {
        applicationId = "hu.muszaki.reggel"
        minSdk = 23
        targetSdk = 35
        versionCode = 2
        versionName = "1.1"
    }
}

dependencies {
    implementation("androidx.work:work-runtime-ktx:2.10.1")
}
