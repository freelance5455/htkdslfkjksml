# Műszaki Reggel — Android APK projekt

Magyar nyelvű Android alkalmazás Alcsútdoboz időjárásához és autós, technológiai, illetve rendezvénytechnikai hírekhez.

## APK készítése GitHub Actions segítségével
1. Hozz létre egy GitHub repository-t, és töltsd fel a projekt összes fájlját.
2. Nyisd meg az **Actions** fület.
3. Válaszd a **Build Android APK** munkafolyamatot, majd a **Run workflow** gombot.
4. A sikeres futás után nyisd meg a futás oldalát, és töltsd le az **Artifacts → MuszakiReggel-debug-apk** csomagot.
5. Csomagold ki a letöltött ZIP-et; benne lesz az `app-debug.apk`, amit Androidon telepíthetsz. Első telepítéskor engedélyezni kell az adott forrásból származó alkalmazások telepítését.

## Helyi build
Android Studio + JDK 17 + Android SDK szükséges. A projekt könyvtárában futtasd: `gradle assembleDebug`.

A hírek betöltéséhez RSS2JSON szolgáltatást, az időjáráshoz Open-Meteo API-t használ. Ezek külső szolgáltatások; elérhetőségük változhat.
