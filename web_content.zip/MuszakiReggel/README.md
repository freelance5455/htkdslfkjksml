# Műszaki Reggel — Android APK projekt

Magyar nyelvű Android alkalmazás Alcsútdoboz időjárásához és autós, technológiai, illetve rendezvénytechnikai hírekhez.

## Új időjárási funkciók (1.1)
- Aktuális időjárás és 7 napos előrejelzés Open-Meteo adatokból.
- Óránkénti, 24 órás csapadékmennyiség-grafikon és valószínűség.
- Nagyítható, mozgatható térkép OpenStreetMap alappal és animálható korábbi RainViewer radarképekkel.
- Eső-/zivatarjelzés az előrejelzés alapján, Android értesítésekkel és időszakos háttérellenőrzéssel.
- Az értesítések az alkalmazáson belül kikapcsolhatók.

## Fontos korlátok
- A csapadékradar a RainViewer nyilvános API-ját használja; elérhetősége, lefedettsége és használati feltételei változhatnak. A szolgáltató jelenlegi API-ja korábbi radarképeket ad; a lejátszás ezek animációja, nem jövőbeli radar-előrejelzés.
- Az eső-/zivatarértesítés az Open-Meteo előrejelzési modelljéből számított jelzés, nem hivatalos HungaroMet veszélyjelzés, és nem garantál azonnali riasztást. A hivatalos veszélyjelzéseket külön is figyeld.
- Az Android háttérmunkát az operációs rendszer késleltetheti. Az értesítésekhez Androidon engedélyt kell adni.
- Az időjárási és radarfunkciókhoz internetkapcsolat kell. A hírek továbbra is a meglévő RSS2JSON szolgáltatást használják.

## APK készítése GitHub Actions segítségével
1. Töltsd fel a projekt összes fájlját a GitHub repository-ba (a ZIP-ben a `MuszakiReggel/` mappán belüli tartalmat töltsd fel a repository gyökerébe).
2. Nyisd meg az **Actions** fület.
3. Válaszd a **Build Android APK** munkafolyamatot, majd a **Run workflow** gombot.
4. A sikeres futás után nyisd meg a futás oldalát, és töltsd le az **Artifacts → MuszakiReggel-debug-apk** csomagot.
5. Csomagold ki a letöltött ZIP-et; benne lesz az `app-debug.apk`, amit Androidon telepíthetsz. Első telepítéskor engedélyezni kell az adott forrásból származó alkalmazások telepítését.

## Helyi build
Android Studio + JDK 17 + Android SDK szükséges. A projekt könyvtárában futtasd: `gradle assembleDebug`.
