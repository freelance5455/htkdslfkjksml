package de.assistent.app;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.webkit.WebViewAssetLoader;

import java.io.OutputStream;

public class MainActivity extends Activity {
    private static final int REQ_SAVE = 42;
    private WebView web;
    private volatile OutputStream saveOut;

    /** Brücke für die Web-Oberfläche: Dateien (Word, PowerPoint, Videos, Fotos) auf dem Handy speichern. */
    public class Bridge {
        @JavascriptInterface
        public void saveBegin(String name, String mime) {
            runOnUiThread(() -> {
                try {
                    closeSave();
                    Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    i.setType(mime == null || mime.isEmpty() ? "application/octet-stream" : mime);
                    i.putExtra(Intent.EXTRA_TITLE, name);
                    startActivityForResult(i, REQ_SAVE);
                } catch (Exception e) {
                    callJs(false);
                }
            });
        }

        /** Schreibt einen Datenblock (Base64). Gibt false zurück, wenn kein Speicherziel offen ist. */
        @JavascriptInterface
        public boolean saveChunk(String b64) {
            try {
                if (saveOut == null) return false;
                saveOut.write(Base64.decode(b64, Base64.DEFAULT));
                return true;
            } catch (Exception e) {
                closeSave();
                return false;
            }
        }

        @JavascriptInterface
        public boolean saveEnd() {
            try {
                if (saveOut == null) return false;
                saveOut.flush();
                saveOut.close();
                saveOut = null;
                return true;
            } catch (Exception e) {
                saveOut = null;
                return false;
            }
        }
    }

    private void closeSave() {
        try {
            if (saveOut != null) saveOut.close();
        } catch (Exception ignored) {
        }
        saveOut = null;
    }

    private void callJs(boolean ok) {
        if (web != null) web.evaluateJavascript("window.__saveReady&&window.__saveReady(" + ok + ")", null);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_SAVE) return;
        boolean ok = false;
        if (resultCode == RESULT_OK && data != null && data.getData() != null) {
            try {
                Uri u = data.getData();
                saveOut = getContentResolver().openOutputStream(u, "w");
                ok = saveOut != null;
            } catch (Exception e) {
                ok = false;
            }
        }
        callJs(ok);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED
                || checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO}, 1);
        }

        web = new WebView(this);
        setContentView(web);

        // Die App wird ueber https://appassets.androidplatform.net ausgeliefert.
        // Das ist ein "sicherer Kontext" und noetig fuer Kamera, Mikrofon und Offline-KI.
        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);

        web.addJavascriptInterface(new Bridge(), "Android");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(() -> request.grant(request.getResources()));
            }
        });

        web.loadUrl("https://appassets.androidplatform.net/assets/index.html");
    }

    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        closeSave();
        if (web != null) web.destroy();
        super.onDestroy();
    }
}
