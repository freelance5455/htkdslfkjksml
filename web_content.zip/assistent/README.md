# Lumi – dein persönlicher Assistent – Android-App

## APK bauen (ca. 5 Minuten, einmalig)
1. **Android Studio** installieren (kostenlos, developer.android.com/studio).
2. Dieses Projekt entpacken und in Android Studio mit „Open“ öffnen. Warten, bis die Synchronisierung fertig ist.
3. Menü **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
4. Die Datei liegt danach in `app/build/outputs/apk/debug/app-debug.apk`. Auf das Handy kopieren und installieren.

## Offline-KI einbauen (optional, empfohlen)
1. Auf dem PC im Projektordner: `python3 tools/fetch_offline.py` (lädt ca. 300 MB, braucht Internet).
2. APK neu bauen. Danach läuft die kleine KI komplett ohne Internet.
3. In der App: **Mehr → Offline-KI laden / testen**.

Ohne diesen Schritt nutzt die App offline ihre eingebauten Tipps und deine Notizen. Die kleine Offline-KI ist deutlich schwächer als die Online-KI (einfache Fragen, kurze Code-Hilfe, Texte).

## Online-KI aktivieren
Unter **Mehr** deinen API-Schlüssel von console.anthropic.com eintragen. Er bleibt nur auf deinem Gerät.

## Was die App kann
- **Chat** mit Modi Allgemein und Programmieren (Codeblöcke mit Kopieren-Knopf), online oder offline
- **Tipps** zu Handy, Code, Alltag, Lernen, Foto/Video, Sicherheit, durchsuchbar
- **Notizen & Aufgaben**
- **Medien**: Fotos, Videos bis 30 Minuten mit Ton (Front- oder Rückkamera), Galerie, KI-Analyse (Fotos, bei Videos einzelne Bilder)
- **Dokumente**: PowerPoint (.pptx) und Word (.docx) erstellen. Online schreibt die KI die Gliederung, du kannst sie bearbeiten oder per Änderungswunsch überarbeiten lassen. Offline schreibst du die Gliederung selbst (oder übernimmst eine Chat-Antwort) und speicherst sie trotzdem als Datei.
- **Export**: Fotos und Videos aus der Galerie auf dem Handy speichern (Knopf „Export“)
- **Clips**: bis 10 Minuten, hintereinander oder nebeneinander (Split-Screen mit bis zu 9 Videos, also mehrere Gesichter gleichzeitig, Ton gemischt)

## Grenzen
- „Ohne Limit“: Die App selbst hat keine Nutzungsgrenze. Die Online-KI läuft aber über deinen API-Schlüssel und wird nach Verbrauch abgerechnet, und es gelten die Raten-Limits von Anthropic. Die Offline-KI ist unbegrenzt, aber deutlich schwächer.
- Die App muss beim Aufnehmen und beim Clip-Erstellen im Vordergrund bleiben. Der Clip wird in Echtzeit erstellt (10 Minuten Clip = 10 Minuten Wartezeit).
- Die KI-Analyse von Videos wertet nur einzelne Bilder aus, nicht den Ton.
- KI-generierte Videos erstellt die App nicht, der Clip-Editor schneidet deine eigenen Aufnahmen.
- Nicht getestet auf einem echten Gerät, da hier kein Android verfügbar war. Melde mir Fehler, dann bessere ich nach.
