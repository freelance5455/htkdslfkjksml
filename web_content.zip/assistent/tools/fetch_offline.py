#!/usr/bin/env python3
"""
Laedt die Offline-KI einmalig auf deinen PC herunter und legt sie in die App.
Aufruf (im Projektordner):   python3 tools/fetch_offline.py

Danach die App in Android Studio neu bauen. Die APK wird dadurch ca. 300 MB gross.
Benoetigt Internet, aber nur jetzt auf dem PC. Die fertige App braucht keines mehr.
"""
import json, os, sys, urllib.request

LIB_VERSION = "3.5.1"
MODEL = "HuggingFaceTB/SmolLM2-360M-Instruct"
MODEL_FILES = [
    "config.json", "generation_config.json", "tokenizer.json", "tokenizer_config.json",
    "onnx/model_q4.onnx",
]
OUT = os.path.join(os.path.dirname(__file__), "..", "app", "src", "main", "assets", "offline")


def get(url, dest):
    os.makedirs(os.path.dirname(dest), exist_ok=True)
    print("Lade", url)
    with urllib.request.urlopen(url) as r, open(dest, "wb") as f:
        while True:
            b = r.read(1 << 20)
            if not b:
                break
            f.write(b)


def main():
    # 1) Bibliothek + WASM-Laufzeit
    api = f"https://data.jsdelivr.com/v1/packages/npm/@huggingface/transformers@{LIB_VERSION}?structure=flat"
    files = json.load(urllib.request.urlopen(api))["files"]
    wanted = [f["name"] for f in files
              if f["name"] == "/dist/transformers.min.js" or
              (f["name"].startswith("/dist/ort-wasm") and f["name"].endswith((".wasm", ".mjs")))]
    if not any(w.endswith("transformers.min.js") for w in wanted):
        sys.exit("transformers.min.js nicht gefunden, bitte LIB_VERSION pruefen.")
    for name in wanted:
        get(f"https://cdn.jsdelivr.net/npm/@huggingface/transformers@{LIB_VERSION}{name}",
            os.path.join(OUT, os.path.basename(name)))
    # 2) Modell
    for fn in MODEL_FILES:
        get(f"https://huggingface.co/{MODEL}/resolve/main/{fn}", os.path.join(OUT, "models", MODEL, fn))
    print("Fertig. Jetzt die App neu bauen.")


if __name__ == "__main__":
    main()
