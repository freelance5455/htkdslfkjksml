# Working on Imposed Entertainment Portal

## Fast project context
- Static HTML/CSS/JavaScript app deployed directly to Netlify; no build step.
- Supabase project: `zoezvthpzbeeklfjwhko` (region `eu-west-1`).
- Browser Supabase client and app config are loaded from `index.html`.
- `config.js` contains public client configuration only. Never add service-role or secret keys to browser files.
- Read `ARCHITECTURE.md` and `DATABASE.md` before editing.

## Where to change things
- `styles.css`: visual design and responsive layout.
- `index.html`: document metadata and ordered classic-script loading.
- `js/core.js`: shared state, constants, escaping and small helpers.
- `js/boot.js`: authentication and app startup.
- `js/data.js`: release/task/invite data loaders.
- `js/views.js`: screen templates.
- `js/events.js`: `data-action` event wiring.
- `js/release.js`: release creation, editing, review and files.
- `js/profiles.js`: artist discovery and public profiles.
- `js/extras.js`: notifications, earnings, announcements, bands and admin utilities.
- `js/audio.js`: audio/distributor validation.
- `js/discography.js`: Discography page, release stats, draft delete, request update, progress steps, covers.
- `js/captcha.js`: Cloudflare Turnstile helpers.
- `sw.js`: service-worker cache. Bump its cache name whenever shipped assets change.

## Safe editing rules
1. Make the smallest targeted change that solves the task; don't rewrite the whole app.
2. Keep the classic-script load order and shared global scope in mind.
3. Escape user/database text inserted into HTML templates with `esc(...)`, and add `data-no-translate` to elements that show user-entered text so the language layer never translates it.
4. Preserve existing Supabase RLS and invite-only signup assumptions.
5. Never expose Supabase `service_role`/secret keys in frontend code.
6. Do not modify production schema, RLS policies, database functions, or storage policies without first inspecting their current definitions and explaining the impact.
7. Treat Supabase `SECURITY DEFINER` advisor warnings as review items, not as proof that every function should be revoked. Some functions may be trigger functions; check grants, call paths and intended RPC access first.
8. Don't remove apparently unused indexes based only on short-term advisor output; this project/database may be new and indexes can support future queries or constraints.
9. Test JavaScript syntax after edits and manually smoke-test affected flows before deploying.

## Deployment
- Netlify publishes the project folder as-is.
- Keep `config.js` uncached by the service worker and `Cache-Control: no-store` in `netlify.toml`.
- After editing shipped assets, bump the cache name in `sw.js` so clients receive the new asset set.
- Deploy a preview first when possible; verify login, invite acceptance, release creation/editing, file upload/download, admin review, and mobile navigation.

## Known audit notes (2026-10-17)
- The setup-screen fallback had stale instructions mentioning `supabase-schema.sql` and an `admin` role; the actual database docs describe migrations and the `label_admin` role.
- Supabase security advisors report multiple exposed `SECURITY DEFINER` functions callable by `anon` and/or `authenticated`. Review each function and its grants before changing permissions.
- Supabase performance advisors report several unused indexes and multiple permissive RLS policies. Do not drop indexes or merge policies without checking query paths and policy semantics.
