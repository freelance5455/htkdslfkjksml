// ---------------------------------------------------------------------------
// src/audio.js -- music + character voices for "Waves & Wish".
//
// MUSIC: three looping MP3s (menu / battle / boss) played with crossfades.
//   There are two interchangeable playback engines, and one is chosen at load:
//     * "media" -- plain <audio> elements whose volume is ramped on a timer.
//                  It streams, so memory stays in the low megabytes. This is
//                  what the published page uses.
//     * "wa"    -- fetch + decodeAudioData into an AudioBuffer, played through
//                  GainNodes. Browsers refuse to load <audio> media in a
//                  document they consider hidden (the editor preview, a
//                  background tab), so this engine takes over there.
//   A probe picks the engine on the first load; the switch is invisible.
//
// VOICE: every hero shouts a short recorded line when their ability fires (and
//   when they swap in). The clips are pre-rendered and hosted on uploads.dev
//   (the URL table lives in index.html as VOICE_CLIPS, one clip per line), and
//   played through the Web Audio graph, so volume works everywhere -- including
//   a hidden document, where <audio> refuses to load. Each hero has their own
//   neural TTS voice, so the recordings sound human rather than robotic.
//   Animalese-style chirps are the second voice mode, and the fallback for any
//   line that has no clip (or fails to load). No device speech engine is
//   involved anywhere.
//
// The three music MP3s live at the user.uploads.dev URLs below; re-generate
// them with the agent's generate_music tool and re-upload to change the score.
// The voice clips were rendered with the open Kokoro-82M neural TTS
// (kokoro-js, q8, run locally in a worker), one voice per hero, then uploaded
// as 24 kHz mono WAV. To regenerate: run Kokoro for each line in VOICE_LINES
// (voice = a distinct Kokoro voice, speed 0.96-1.08), upload the WAV, and
// replace the matching URL in VOICE_CLIPS.
// ---------------------------------------------------------------------------

const TRACKS = {
  menu:   "https://user.uploads.dev/file/8fe45ccfeaa68fb7cbc541be01ac36f8.mp3",
  battle: "https://user.uploads.dev/file/8dc2ae7c86ecefbf6b8e96181fbca84b.mp3",
  boss:   "https://user.uploads.dev/file/de922527aee795a4b0f1e831ad3cba99.mp3",
};
const GAIN = { menu: 0.46, battle: 0.42, boss: 0.5 };
const LS_KEY = "tdrpg.audio.v1";
const VMODES = ["voice", "retro", "off"];

let lines = {};                     // { heroId: { skill: [...], enter: [...] } }
let voiceClips = {};                // { heroId: { skill: [url, ...], enter: [...] } }
const state = { music: true, mvol: 0.5, vmode: "voice", vvol: 0.9 };
let onchange = null;

// ---- shared music state ---------------------------------------------------

let engine = (typeof window !== "undefined" && window.generatorIsUnsaved) ? "wa" : "media";
let desired = "menu";
let curName = null;
let unlocked = false;
let fadeTimer = 0;

// media engine
const els = {};
let volOk = true;

// web-audio engine
let waCtx = null;
let master = null;
const wnodes = {};                  // name -> { gain, src, buf, raw, loading, failed }
let wplaying = null;               // name of the track currently audible

// voices
let actx = null;                    // voice AudioContext (separate from the music one)
let curClip = null;                 // { src, gain } of the line currently playing
const clipBufs = new Map();         // url -> decoded AudioBuffer
const clipLoads = new Map();        // url -> in-flight decode Promise

function clamp(v, a, b) { return v < a ? a : v > b ? b : v; }

function loadPrefs() {
  try {
    const raw = localStorage.getItem(LS_KEY);
    if (!raw) return;
    const p = JSON.parse(raw);
    if (typeof p.music === "boolean") state.music = p.music;
    if (typeof p.mvol === "number") state.mvol = clamp(p.mvol, 0, 1);
    if (p.vmode === "words") state.vmode = "voice";          // migrated from the speech-engine era
    else if (VMODES.indexOf(p.vmode) >= 0) state.vmode = p.vmode;
    if (typeof p.vvol === "number") state.vvol = clamp(p.vvol, 0, 1);
  } catch (err) {}
}
function savePrefs() {
  try { localStorage.setItem(LS_KEY, JSON.stringify(state)); } catch (err) {}
}

// ===========================================================================
// media engine: streaming <audio> elements, volume ramped on a timer
// ===========================================================================

function mEnsure(name) {
  if (els[name]) return els[name];
  const url = TRACKS[name];
  if (!url) return null;
  const a = new Audio();
  a.src = url;
  a.loop = true;
  a.preload = "auto";
  a.volume = 0;
  els[name] = a;
  // iOS reports volume as a read-only property, so probe once and fall back to
  // play/pause switching if the browser will not let us fade.
  if (name === "menu") {
    try {
      a.volume = 0.5;
      volOk = Math.abs(a.volume - 0.5) < 0.01;
      a.volume = 0;
    } catch (err) { volOk = false; }
  }
  try { a.load(); } catch (err) {}
  return a;
}

function mTarget(name) { return (GAIN[name] || 0.42) * state.mvol; }

function mTick() {
  if (checkMedia()) return;
  const want = state.music ? desired : null;
  let busy = false;
  for (const k in els) {
    const a = els[k];
    if (!volOk) {
      // no volume control on this browser: hard play/pause switching
      if (k === want) { if (unlocked && a.paused) a.play().catch(() => {}); }
      else if (!a.paused) { try { a.pause(); } catch (err) {} }
      continue;
    }
    const tv = k === want ? mTarget(k) : 0;
    const current = typeof a.volume === "number" ? a.volume : 0;
    if (Math.abs(tv - current) > 0.01) {
      a.volume = clamp(current + (tv > current ? 0.05 : -0.05), 0, 1);
      busy = true;
      if (unlocked && tv > 0 && a.paused) a.play().catch(() => {});
    } else {
      a.volume = tv;
      if (tv === 0 && k !== want && !a.paused) { try { a.pause(); } catch (err) {} }
    }
  }
  if (!busy && !needMediaTick()) { clearInterval(fadeTimer); fadeTimer = 0; }
}

function mStart(name) {
  if (!state.music || !unlocked) return;
  const a = mEnsure(name);
  if (!a) return;
  if (a.paused) a.play().catch(() => {});
  if (volOk && a.volume <= 0.001) a.volume = 0.001;
}

// Keep the ticker alive while the track we want has not actually started, so
// the watchdog gets a chance to notice a media stack that has stalled.
function needMediaTick() {
  if (!unlocked || !state.music) return false;
  const a = els[desired];
  if (!a) return false;
  return a.readyState === 0 || a.paused || a.currentTime === 0;
}

// ===========================================================================
// web-audio engine: fetch -> decodeAudioData -> looping BufferSource
// ===========================================================================

function wCtx() {
  if (!waCtx) {
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return null;
    try { waCtx = new AC(); } catch (err) { waCtx = null; return null; }
    master = waCtx.createGain();
    master.gain.value = state.mvol;
    master.connect(waCtx.destination);
  }
  if (waCtx.state === "suspended") waCtx.resume().catch(() => {});
  return waCtx;
}

function wNode(name) {
  if (!wnodes[name]) wnodes[name] = null;
  if (!wnodes[name]) wnodes[name] = { gain: null, src: null, buf: null, raw: null, loading: false, failed: false };
  return wnodes[name];
}

// Decoding goes through a throwaway OfflineAudioContext so that no AudioContext
// has to be built before the first user gesture (which browsers would warn
// about). AudioBuffers are portable between contexts.
function wDecode(ab) {
  return new Promise((res, rej) => {
    const OAC = window.OfflineAudioContext || window.webkitOfflineAudioContext;
    let off = null;
    if (OAC) { try { off = new OAC(2, 1, 44100); } catch (err) { off = null; } }
    if (!off) { rej(new Error("no decoder")); return; }
    try { off.decodeAudioData(ab, res, rej); } catch (err) { rej(err); }
  });
}

// Pull the whole track down now, decode later (cheap: ~4 MB while it waits).
function wPrefetch(name) {
  if (!TRACKS[name]) return;
  const n = wNode(name);
  if (n.buf || n.raw || n.loading || n.failed) return;
  n.loading = true;
  fetch(TRACKS[name]).then((r) => r.arrayBuffer())
    .then((ab) => { n.raw = ab; n.loading = false; if (name === desired && state.music && unlocked) wLoad(name); })
    .catch(() => { n.loading = false; n.failed = true; });
}

function wLoad(name) {
  if (!TRACKS[name]) return;
  const n = wNode(name);
  if (n.buf || n.loading || n.failed) return;
  n.loading = true;
  const got = n.raw ? Promise.resolve(n.raw) : fetch(TRACKS[name]).then((r) => r.arrayBuffer());
  got.then((ab) => { n.raw = null; return wDecode(ab); })
    .then((buf) => { n.buf = buf; n.loading = false; if (name === desired && state.music && unlocked) wStart(name); })
    .catch(() => { n.loading = false; n.failed = true; });
}

function wStart(name) {
  const n = wnodes[name];
  if (!n || !n.buf || n.src || !state.music || !unlocked) return;
  const c = wCtx();
  if (!c) return;
  if (!n.gain) {
    n.gain = c.createGain();
    n.gain.gain.value = 0.001;
    n.gain.connect(master);
  }
  const src = c.createBufferSource();
  src.buffer = n.buf;
  src.loop = true;
  src.connect(n.gain);
  n.src = src;
  n.gain.gain.value = 0.001;
  try { src.start(0); } catch (err) { n.src = null; return; }
  wplaying = name;
  kick();
}

function wTick() {
  if (!waCtx) return;
  const now = waCtx.currentTime;
  let busy = false;
  // If the track we want has not finished decoding, keep the previous one
  // playing so the music never drops out mid-switch.
  let live = desired;
  const d = wnodes[desired];
  if (!(d && d.src)) live = (wplaying && wplaying !== desired && wnodes[wplaying] && wnodes[wplaying].src) ? wplaying : null;
  for (const k in wnodes) {
    const n = wnodes[k];
    if (!n || !n.src) continue;
    const want = state.music && k === live ? (GAIN[k] || 0.42) : 0;
    n.gain.gain.setTargetAtTime(want, now, 0.16);
    if (Math.abs(n.gain.gain.value - want) > 0.005) { busy = true; continue; }
    if (want === 0) {
      try { n.src.stop(); } catch (err) {}
      try { n.src.disconnect(); } catch (err) {}
      n.src = null;
      if (wplaying === k) wplaying = null;
      if (k !== desired) n.buf = null;    // listening to something else: free it
    }
  }
  if (!busy) { clearInterval(fadeTimer); fadeTimer = 0; }
}

// ---- engine selection -----------------------------------------------------
// The <audio> engine is preferred: it streams, so memory stays in the low
// megabytes. A browser can, however, quietly refuse to load media at all (a
// document it considers hidden, a stalled media stack), in which case the
// element sits at readyState 0 forever. If the track we are actually trying to
// play does that, swap in the fetch+decode engine. This is checked against the
// real playback element, so it also recovers from a temporary stall.
let watchName = null, watchAt = 0, playTry = 0;

function checkMedia() {
  const name = state.music ? desired : null;
  const a = name ? els[name] : null;
  if (!a || !unlocked) { watchName = null; return false; }
  if (a.error) { switchEngine(); return true; }
  if (a.readyState === 0) {
    if (watchName !== name) { watchName = name; watchAt = Date.now(); return false; }
    if (Date.now() - watchAt > 3500) { switchEngine(); return true; }
    return false;
  }
  watchName = null;
  // loaded but not running (an autoplay promise that got dropped): nudge it
  if (a.paused && a.readyState >= 2 && Date.now() - playTry > 2000) {
    playTry = Date.now();
    a.play().catch(() => {});
  }
  return false;
}

function switchEngine() {
  if (engine === "wa") return;
  engine = "wa";
  for (const k in els) {
    try { els[k].pause(); els[k].removeAttribute("src"); els[k].load(); } catch (err) {}
    delete els[k];
  }
  clearInterval(fadeTimer); fadeTimer = 0;
  wplaying = null;
  if (state.music) { wLoad(desired); if (curName && TRACKS[curName] && curName !== desired) wPrefetch(curName); }
  kick();
}

function tickFade() { if (engine === "wa") wTick(); else mTick(); }
function kick() { if (!fadeTimer) fadeTimer = setInterval(tickFade, 90); }

function scene(name) {
  if (!TRACKS[name]) return;
  desired = name;
  curName = name;
  if (engine === "wa") {
    if (state.music) { wLoad(name); wStart(name); }
  } else if (unlocked) {
    mStart(name);
    if (name === "battle" && state.music) mEnsure("boss");   // warm wave 5
  }
  if (name === "battle" && state.music && engine === "wa") wPrefetch("boss");
  kick();
}

function setMusic(on) {
  state.music = !!on;
  savePrefs();
  if (state.music) {
    if (engine === "wa") { wLoad(desired); wStart(desired); }
    else mStart(desired);
  }
  if (engine === "wa" && waCtx) master.gain.setTargetAtTime(state.mvol, waCtx.currentTime, 0.1);
  kick();
  if (onchange) onchange();
}

function setMusicVol(v) {
  state.mvol = clamp(v, 0, 1);
  savePrefs();
  if (engine === "wa" && waCtx) master.gain.setTargetAtTime(state.mvol, waCtx.currentTime, 0.1);
  kick();
  if (onchange) onchange();
}

// Prime: start the probe, and unlock playback on the first user gesture. A real
// click counts too (pointerdown is not the only way a button gets hit).
function armGestures() {
  const arm = () => {
    unlocked = true;
    ctx();
    if (state.music) {
      if (engine === "wa") { wLoad(desired); wStart(desired); }
      else { mStart(desired); curName = desired; }
      kick();
    }
  };
  window.addEventListener("pointerdown", arm, { once: true, capture: true });
  window.addEventListener("keydown", arm, { once: true, capture: true });
  window.addEventListener("touchstart", arm, { once: true, capture: true });
  window.addEventListener("click", arm, { once: true, capture: true });
}

// ===========================================================================
// voices
// ===========================================================================

function ctx() {
  if (!actx) {
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return null;
    try { actx = new AC(); } catch (err) { actx = null; }
  }
  if (actx && actx.state === "suspended") actx.resume().catch(() => {});
  return actx;
}

function hash(str) {
  let h = 2166136261;
  for (let i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 16777619); }
  return h >>> 0;
}

// Stable per-hero voice: a pitch (used by the chirp) and a clip playback rate.
function profileFor(id) {
  const h = hash(String(id || "hero"));
  return {
    pitch: 0.7 + ((h % 7) / 6) * 0.82,        // 0.70 - 1.52
    rate: 0.92 + (((h >> 4) % 7) / 6) * 0.16, // 0.92 - 1.08
  };
}

function hasClips() {
  for (const id in voiceClips) {
    const bag = voiceClips[id];
    for (const k in bag) if (bag[k] && bag[k].length) return true;
  }
  return false;
}

// Fetch + decode one clip, once. AudioBufferSources need no media element, so
// this works in a hidden document where an <audio>.load() never fires.
function loadClip(url) {
  if (clipBufs.has(url)) return Promise.resolve(clipBufs.get(url));
  if (clipLoads.has(url)) return clipLoads.get(url);
  const p = fetch(url).then((r) => r.arrayBuffer()).then(wDecode)
    .then((buf) => { clipBufs.set(url, buf); clipLoads.delete(url); return buf; })
    .catch(() => { clipLoads.delete(url); return null; });
  clipLoads.set(url, p);
  return p;
}

// Quietly warm one hero's buffers so their first shout is not late.
function prewarm(id) {
  const bag = voiceClips[id];
  if (!bag) return;
  for (const k in bag) for (const url of bag[k]) if (url) loadClip(url);
}

// Each clip is voiced by a real speaker at the right pitch, so it plays at its
// natural rate. An explicit `r` on the line is a deliberate nudge; the legacy
// `p` is ignored here (it only shapes the retro chirp now).
function clipRate(pr, pick) {
  if (pick && typeof pick.r === "number") return clamp(pick.r, 0.85, 1.25);
  return 1;
}

function playClip(url, rate) {
  const c = ctx();
  if (!c || !url) return false;
  const go = (buf) => {
    if (!buf) return false;
    if (curClip) {
      try { curClip.src.stop(); } catch (err) {}
      try { curClip.src.disconnect(); } catch (err) {}
      curClip = null;
    }
    const src = c.createBufferSource();
    src.buffer = buf;
    src.playbackRate.value = clamp(rate, 0.7, 1.4);
    const g = c.createGain();
    g.gain.value = clamp(state.vvol, 0, 1) * 0.95;
    src.connect(g); g.connect(c.destination);
    try { src.start(); } catch (err) { return false; }
    curClip = { src, gain: g };
    src.onended = () => { if (curClip && curClip.src === src) curClip = null; };
    return true;
  };
  if (clipBufs.has(url)) return go(clipBufs.get(url));
  loadClip(url).then(go);   // a hero's first shout may arrive a beat late
  return true;
}

// Animalese-style syllable chirp: one square blip per syllable. `pr.speed`
// stretches (or hurries) the rhythm so the same text can read calm or frantic.
function chirp(text, pr) {
  const c = ctx();
  if (!c) return;
  const sp = pr.speed || 1;
  const step = 0.062 / sp, tail = 0.05 / sp, rise = 0.05 / sp, blip = 0.052 / sp;
  const words = String(text).toUpperCase().replace(/[^A-Z0-9 ]/g, "").split(" ").filter(Boolean);
  let t = c.currentTime + 0.02;
  let n = 0;
  for (const w of words) {
    const chunks = Math.max(1, Math.min(4, Math.round(w.length / 2)));
    for (let i = 0; i < chunks && n < 20; i++, n++) {
      const base = 190 + pr.pitch * 300 + ((w.charCodeAt(i % w.length) * 41) % 130);
      const o = c.createOscillator();
      const g = c.createGain();
      o.type = "square";
      o.frequency.setValueAtTime(base, t);
      o.frequency.linearRampToValueAtTime(base * (0.86 + ((i * 37) % 30) / 100), t + rise);
      g.gain.setValueAtTime(0.0001, t);
      g.gain.exponentialRampToValueAtTime(0.08 * state.vvol * (pr.gain || 1), t + 0.008);
      g.gain.exponentialRampToValueAtTime(0.0001, t + blip);
      o.connect(g); g.connect(c.destination);
      o.start(t); o.stop(t + 0.07);
      t += step;
    }
    t += tail;
  }
}

// Emotion presets. A line spoken in a given moment is pitched and paced
// differently: hurt lines drop and drag, kill/victory lines lift and hurry,
// boss and defeat lines sink low. Only applied when the line has no explicit
// override, and only to whichever voice mode is active.
const EMO = {
  skill:   { rate: 1,    pitch: 1,    speed: 1,    gain: 1 },
  enter:   { rate: 1,    pitch: 1,    speed: 1,    gain: 1 },
  hurt:    { rate: 0.93, pitch: 0.84, speed: 0.88, gain: 0.95 },
  low:     { rate: 0.9,  pitch: 0.78, speed: 0.82, gain: 0.95 },
  kill:    { rate: 1.06, pitch: 1.12, speed: 1.08, gain: 1 },
  clear:   { rate: 1.04, pitch: 1.1,  speed: 1.06, gain: 1 },
  boss:    { rate: 0.87, pitch: 0.74, speed: 0.82, gain: 1 },
  victory: { rate: 1.08, pitch: 1.22, speed: 1.14, gain: 1 },
  defeat:  { rate: 0.85, pitch: 0.68, speed: 0.76, gain: 0.95 },
};

// Any recorded clip this hero owns -- used so an emotion with no bespoke
// recording still plays in the hero's real voice, just pitched for the moment.
function anyClip(id) {
  const bag = voiceClips[id];
  if (!bag) return null;
  const all = [];
  for (const k in bag) for (const url of bag[k]) if (url) all.push(url);
  return all.length ? all[Math.floor(Math.random() * all.length)] : null;
}

function say(id, kind) {
  if (state.vmode === "off") return;
  const bag = lines[id];
  if (!bag) return;
  let arr = bag[kind];
  if (!arr || !arr.length) {
    // no line authored for this moment: borrow the skill shout so the hero still
    // speaks (rare -- every hero has emotion lines, this covers future kinds)
    arr = bag.skill;
    if (!arr || !arr.length) return;
  }
  const idx = Math.floor(Math.random() * arr.length);
  const pick = arr[idx];
  const text = typeof pick === "string" ? pick : (pick && pick.text) || "";
  if (!text) return;
  const emo = EMO[kind] || EMO.skill;
  const pr = profileFor(id);
  let pitchMul = emo.pitch, speedMul = emo.speed, rateMul = emo.rate, gainMul = emo.gain;
  if (typeof pick === "object" && pick) {
    if (typeof pick.p === "number") pitchMul = pick.p;      // legacy per-line pitch
    if (typeof pick.r === "number") rateMul = pick.r;       // per-line clip nudge
    if (pick.emo) { const e = EMO[pick.emo]; if (e) { pitchMul *= e.pitch; speedMul *= e.speed; rateMul *= e.rate; } }
  }
  if (state.vmode === "retro") { chirp(text, { pitch: pr.pitch * pitchMul, speed: speedMul, gain: gainMul }); return; }
  const dedicated = voiceClips[id] && voiceClips[id][kind] && voiceClips[id][kind][idx];
  const clip = dedicated || anyClip(id);
  if (clip && playClip(clip, clipRate(pr, pick) * rateMul)) return;
  chirp(text, { pitch: pr.pitch * pitchMul, speed: speedMul, gain: gainMul });
}

function stopVoices() {
  if (curClip) {
    try { curClip.src.stop(); } catch (err) {}
    try { curClip.src.disconnect(); } catch (err) {}
    curClip = null;
  }
}

// ===========================================================================
// public surface
// ===========================================================================

export const sound = {
  state,
  init(opts) {
    if (opts && opts.lines) lines = opts.lines;
    if (opts && opts.clips) voiceClips = opts.clips;
    loadPrefs();
    armGestures();
    if (engine === "wa") wLoad(desired);
    scene("menu");
    if (onchange) onchange();
  },
  scene,
  say,
  stopVoices,
  setMusic,
  setMusicVol,
  setVoiceMode(m) {
    if (VMODES.indexOf(m) < 0) return;
    state.vmode = m;
    savePrefs();
    if (m === "off") stopVoices();
    if (onchange) onchange();
  },
  cycleVoiceMode() {
    const i = VMODES.indexOf(state.vmode);
    sound.setVoiceMode(VMODES[(i + 1) % VMODES.length]);
  },
  setVoiceVol(v) { state.vvol = clamp(v, 0, 1); savePrefs(); if (onchange) onchange(); },
  voicesAvailable() { return hasClips(); },
  prewarm,
  volumeSupported() { return volOk; },
  onChange(fn) { onchange = fn; },
};
