// Procedural synthwave soundtrack + SFX via Web Audio (no audio files needed)
const mtof = m => 440 * Math.pow(2, (m - 69) / 12);

// ---------------------------------------------------------------------
// Tracks. Chords are MIDI notes, one chord per bar (16 steps).
// pattern strings: 16 chars, 'x' = hit, 'o' = accent/octave, '.' = rest
// ---------------------------------------------------------------------
export const TRACKS = [
  {
    id: 'solar', name: 'SOLAR DRIVE', tempo: 124,
    bars: [[57, 60, 64], [53, 57, 60], [48, 52, 55], [55, 59, 62]],
    bass: 'x.x.x.o.x.x.x.o.', arp: [0, 1, 2, 3, 2, 1, 3, 4], arpRate: 1, arpWave: 'triangle',
    kick: 'x...x...x...x...', snare: '....x.......x...', hat: '..x...x...x...x.', ghost: '.x.x.x.x.x.x.x.x',
    padCut: 900, lead: true, leadWave: 'square',
  },
  {
    id: 'neon', name: 'NEON PULSE', tempo: 118,
    bars: [[53, 56, 60], [49, 53, 56], [56, 60, 63], [51, 55, 58]],
    bass: '..x...x...x...x.', arp: [0, 2, 1, 3, 0, 2, 4, 3], arpRate: 2, arpWave: 'sawtooth',
    kick: 'x...x...x...x...', snare: '....x.......x...', hat: '..x...x...x...x.', ghost: '...x.......x....',
    padCut: 1200, lead: true, leadWave: 'sawtooth',
  },
  {
    id: 'tides', name: 'AZURE TIDES', tempo: 92,
    bars: [[48, 52, 55, 59], [45, 48, 52, 55], [41, 45, 48, 52], [43, 47, 50, 57]],
    bass: 'x.......x..x....', arp: [0, 2, 4, 3, 1, 3, 2, 4], arpRate: 2, arpWave: 'sine',
    kick: 'x.........x.....', snare: '........x.......', hat: '....x.......x...', ghost: '................',
    padCut: 700, lead: true, leadWave: 'triangle', soft: true,
  },
  {
    id: 'crystal', name: 'CRYSTAL DRIFT', tempo: 108,
    bars: [[50, 53, 57], [46, 50, 53], [53, 57, 60], [48, 52, 55]],
    bass: 'x..x..x...x..x..', arp: [0, 1, 2, 4, 3, 2, 1, 4], arpRate: 1, arpWave: 'triangle',
    kick: 'x.....x...x.....', snare: '....x.......x...', hat: 'x.x.x.x.x.x.x.x.', ghost: '................',
    padCut: 1500, lead: false, soft: true,
  },
  {
    id: 'crimson', name: 'CRIMSON RUSH', tempo: 138,
    bars: [[52, 55, 59], [48, 52, 55], [50, 54, 57], [47, 51, 54]],
    bass: 'xxoxxxoxxxoxxxox', arp: [0, 2, 3, 2, 1, 2, 4, 2], arpRate: 1, arpWave: 'square',
    kick: 'x...x...x...x..x', snare: '....x.......x...', hat: '..x...x...x...x.', ghost: '.x.x.x.x.x.x.x.x',
    padCut: 800, lead: true, leadWave: 'sawtooth',
  },
  {
    id: 'aurora', name: 'AURORA RISE', tempo: 112,
    bars: [[55, 59, 62], [52, 55, 59], [48, 52, 55], [50, 54, 57]],
    bass: 'x.x...x.x.x...x.', arp: [0, 1, 2, 3, 4, 3, 2, 1], arpRate: 1, arpWave: 'triangle',
    kick: 'x...x...x...x...', snare: '....x.......x...', hat: '..x...x...x...x.', ghost: '.......x.......x',
    padCut: 1100, lead: true, leadWave: 'square',
  },
  {
    id: 'lounge', name: 'HANGAR LOUNGE', tempo: 84, menuOnly: true,
    bars: [[51, 55, 58, 62], [48, 51, 55, 58], [44, 48, 51, 55], [46, 50, 53, 57]],
    bass: 'x.......x.......', arp: [0, 2, 1, 3, 2, 4, 3, 1], arpRate: 2, arpWave: 'sine',
    kick: '................', snare: '................', hat: '................', ghost: '................',
    padCut: 650, lead: false, soft: true,
  },
];

// tiny seeded RNG for repeatable melodies
function rng(seed) { let s = seed >>> 0; return () => ((s = (s * 1664525 + 1013904223) >>> 0) / 4294967296); }
function makeMelody(track, seed) {
  const r = rng(seed);
  const notes = [];
  for (let bar = 0; bar < 4; bar++) {
    const ch = track.bars[bar];
    for (let st = 0; st < 16; st++) {
      const onBeat = st % 4 === 0, half = st % 2 === 0;
      const p = onBeat ? 0.7 : half ? 0.35 : 0.08;
      if (r() < p) {
        const pool = [...ch.map(n => n + 12), ch[0] + 24];
        const len = onBeat && r() < 0.5 ? 4 : 2;
        notes.push({ s: bar * 16 + st, n: pool[Math.floor(r() * pool.length)], len });
        st += len - 1;
      }
    }
  }
  return notes;
}
TRACKS.forEach((t, i) => { t.melody = makeMelody(t, 1234 + i * 777); });

export class SynthAudio {
  constructor() {
    this.ctx = null;
    this.muted = false;
    this.musicVol = 0.55;
    this.sfxVol = 0.7;
    this.intensity = 0;      // 0 menu, 1 run
    this.step = 0;
    this.nextTime = 0;
    this.timer = null;
    this.track = TRACKS[0];
    this.pendingTrack = null;
    this.menuTrack = TRACKS.find(t => t.id === 'lounge');
    this.hold = new Set();   // reasons audio is held (hidden, blur, stalled)
    this.lastFrame = performance.now();
    this.onTrack = null;     // callback(name)
  }

  get running() { return this.ctx && this.ctx.state === 'running'; }

  init() {
    if (this.ctx) { this.tryResume(); return; }
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    let ctx;
    try { ctx = this.ctx = new AC({ latencyHint: 'playback' }); } catch (e) { ctx = this.ctx = new AC(); }

    this.master = ctx.createGain();
    this.master.gain.value = this.muted ? 0 : 0.9;
    // brick-wall-ish limiter to prevent clipping crackle
    const lim = ctx.createDynamicsCompressor();
    lim.threshold.value = -10; lim.knee.value = 4; lim.ratio.value = 14; lim.attack.value = 0.003; lim.release.value = 0.18;
    this.master.connect(lim).connect(ctx.destination);

    this.music = ctx.createGain(); this.music.gain.value = this.musicVol * 0.55;
    this.music.connect(this.master);
    this.sfx = ctx.createGain(); this.sfx.gain.value = this.sfxVol * 0.8;
    this.sfx.connect(this.master);

    // echo bus
    this.echo = ctx.createDelay(1); this.echo.delayTime.value = 0.36;
    const fb = ctx.createGain(); fb.gain.value = 0.32;
    const ef = ctx.createBiquadFilter(); ef.type = 'lowpass'; ef.frequency.value = 2200;
    this.echo.connect(ef).connect(fb).connect(this.echo);
    const eOut = ctx.createGain(); eOut.gain.value = 0.45;
    ef.connect(eOut).connect(this.music);

    // shared drum buses (fewer nodes per note = no crackle on phones)
    this.hatBus = ctx.createBiquadFilter(); this.hatBus.type = 'highpass'; this.hatBus.frequency.value = 7500;
    this.hatBus.connect(this.music);
    this.snareBus = ctx.createBiquadFilter(); this.snareBus.type = 'bandpass'; this.snareBus.frequency.value = 1800; this.snareBus.Q.value = 0.8;
    this.snareBus.connect(this.music);
    this.padBus = ctx.createBiquadFilter(); this.padBus.type = 'lowpass'; this.padBus.frequency.value = 900; this.padBus.Q.value = 0.7;
    this.padBus.connect(this.music);

    const len = Math.floor(ctx.sampleRate * 1.5);
    this.noiseBuf = ctx.createBuffer(1, len, ctx.sampleRate);
    const d = this.noiseBuf.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;

    // engine drone
    this.engFilter = ctx.createBiquadFilter(); this.engFilter.type = 'lowpass'; this.engFilter.frequency.value = 300; this.engFilter.Q.value = 5;
    this.engGain = ctx.createGain(); this.engGain.gain.value = 0;
    this.engFilter.connect(this.engGain).connect(this.sfx);
    this.eng1 = ctx.createOscillator(); this.eng1.type = 'sawtooth'; this.eng1.frequency.value = 55;
    this.eng2 = ctx.createOscillator(); this.eng2.type = 'sawtooth'; this.eng2.frequency.value = 55.7;
    this.eng1.connect(this.engFilter); this.eng2.connect(this.engFilter);
    this.eng1.start(); this.eng2.start();
    const ns = ctx.createBufferSource(); ns.buffer = this.noiseBuf; ns.loop = true;
    this.windFilter = ctx.createBiquadFilter(); this.windFilter.type = 'bandpass'; this.windFilter.frequency.value = 800; this.windFilter.Q.value = 0.7;
    this.windGain = ctx.createGain(); this.windGain.gain.value = 0;
    ns.connect(this.windFilter).connect(this.windGain).connect(this.sfx); ns.start();

    this.nextTime = ctx.currentTime + 0.1;
    this.timer = setInterval(() => this.schedule(), 40);
    ctx.onstatechange = () => { if (ctx.state !== 'running') this.nextTime = 0; };
  }

  // --- lifecycle: pause audio whenever the game isn't being looked at ---
  holdOn(reason) {
    this.hold.add(reason);
    if (this.ctx && this.ctx.state === 'running') { this.ctx.suspend().catch(() => {}); }
  }
  holdOff(reason) {
    this.hold.delete(reason);
    this.tryResume();
  }
  tryResume() {
    if (!this.ctx || this.hold.size) return;
    if (this.ctx.state !== 'running') {
      this.ctx.resume().then(() => { this.nextTime = this.ctx.currentTime + 0.08; }).catch(() => {});
    }
  }
  // called every animation frame by the game
  tick() {
    this.lastFrame = performance.now();
    if (this.hold.has('stalled')) this.holdOff('stalled');
  }
  shutdown() {
    if (this.timer) clearInterval(this.timer);
    this.timer = null;
    if (this.ctx) { try { this.ctx.close(); } catch (e) { /* ignore */ } }
    this.ctx = null;
  }

  setMuted(m) {
    this.muted = m;
    if (this.master) this.master.gain.setTargetAtTime(m ? 0 : 0.9, this.ctx.currentTime, 0.05);
  }
  setMusicVolume(v) {
    this.musicVol = v;
    if (this.music) this.music.gain.setTargetAtTime(v * 0.55, this.ctx.currentTime, 0.05);
  }
  setSfxVolume(v) {
    this.sfxVol = v;
    if (this.sfx) this.sfx.gain.setTargetAtTime(v * 0.8, this.ctx.currentTime, 0.05);
  }
  setTrack(id) {
    const t = TRACKS.find(x => x.id === id) || TRACKS[0];
    if (t === this.track && !this.pendingTrack) return;
    if (!this.ctx) { this.track = t; this.onTrack && this.onTrack(t.name); return; }
    this.pendingTrack = t;
  }

  setEngine(level, speedNorm) {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    this.engGain.gain.setTargetAtTime(level * 0.16, t, 0.1);
    this.windGain.gain.setTargetAtTime(level * (0.04 + speedNorm * 0.1), t, 0.1);
    const f = 45 + speedNorm * 40;
    this.eng1.frequency.setTargetAtTime(f, t, 0.1);
    this.eng2.frequency.setTargetAtTime(f * 1.012, t, 0.1);
    this.engFilter.frequency.setTargetAtTime(220 + speedNorm * 900, t, 0.1);
    this.windFilter.frequency.setTargetAtTime(600 + speedNorm * 1800, t, 0.1);
  }

  // ---------- music scheduler ----------
  schedule() {
    const ctx = this.ctx;
    if (!ctx) return;
    // watchdog: if the game stopped drawing frames (tab hidden, preview closed), silence it
    if (performance.now() - this.lastFrame > 1500 && !this.hold.has('stalled')) { this.holdOn('stalled'); return; }
    if (ctx.state !== 'running') return;
    const now = ctx.currentTime;
    // if we fell behind (throttled timer, heavy frame), skip ahead instead of bursting notes
    if (this.nextTime < now + 0.02) this.nextTime = now + 0.06;
    let guard = 0;
    while (this.nextTime < now + 0.3 && guard++ < 32) {
      const sd = 60 / this.track.tempo / 4;
      if (this.step % 16 === 0 && this.pendingTrack) {
        this.track = this.pendingTrack; this.pendingTrack = null; this.step = 0;
        this.onTrack && this.onTrack(this.track.name);
      }
      try { this.playStep(this.step, this.nextTime, 60 / this.track.tempo / 4); } catch (e) { /* never let one note kill the loop */ }
      this.nextTime += sd;
      this.step = (this.step + 1) % 256;
    }
  }

  playStep(s, t, sd) {
    const T = this.track;
    const bar = Math.floor(s / 16) % T.bars.length;
    const chord = T.bars[bar];
    const st = s % 16;
    const I = this.intensity;
    const full = I > 0.3;
    const section = Math.floor(s / 64) % 4; // 4-bar sections
    if (st === 0) {
      this.padBus.frequency.setTargetAtTime(T.padCut * (full ? 1 : 0.8), t, 0.5);
      for (const n of chord.slice(0, 3)) this.pad(mtof(n), t, sd * 16, T.soft ? 0.032 : 0.036);
      if (chord[3]) this.pad(mtof(chord[3]), t, sd * 16, 0.02);
    }
    // bass
    const bc = T.bass[st];
    if (full && bc !== '.') this.bass(mtof(chord[0] - 24 + (bc === 'o' ? 12 : 0)), t, sd * 1.7, T.soft ? 0.11 : 0.14);
    else if (!full && st === 0) this.bass(mtof(chord[0] - 24), t, sd * 8, 0.07);
    // arp
    const tones = [chord[0], chord[1], chord[2], chord[0] + 12, chord[1] + 12];
    const rate = full ? T.arpRate : 2;
    if (st % rate === 0 && section !== 3 || st % 4 === 0) {
      const n = tones[T.arp[st % 8] % tones.length] + 12;
      this.arp(mtof(n), t, sd * (rate === 2 ? 1.6 : 0.9), (full ? 0.05 : 0.035) * (T.soft ? 0.9 : 1), T.arpWave);
    }
    // lead melody on alternating sections
    if (full && T.lead && (section === 1 || section === 2)) {
      const local = s % 64;
      for (const m of T.melody) if (m.s === local) this.lead(mtof(m.n), t, sd * m.len, T.leadWave);
    }
    // drums
    if (full) {
      if (T.kick[st] === 'x') this.kick(t, T.soft ? 0.36 : 0.45);
      if (T.snare[st] === 'x') this.snare(t, T.soft ? 0.07 : 0.11);
      if (T.hat[st] === 'x') this.hat(t, 0.045);
      if (T.ghost[st] === 'x') this.hat(t, 0.016);
      if (section === 3 && st === 15) this.snare(t, 0.06);
    }
  }

  pad(f, t, dur, vol) {
    const c = this.ctx;
    const o1 = c.createOscillator(), o2 = c.createOscillator();
    o1.type = 'sawtooth'; o2.type = 'sawtooth';
    o1.frequency.value = f; o2.frequency.value = f * 1.006;
    const g = c.createGain();
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(vol, t + 0.5);
    g.gain.linearRampToValueAtTime(vol * 0.7, t + dur - 0.2);
    g.gain.linearRampToValueAtTime(0, t + dur + 0.3);
    o1.connect(g); o2.connect(g); g.connect(this.padBus);
    o1.start(t); o2.start(t); o1.stop(t + dur + 0.35); o2.stop(t + dur + 0.35);
  }

  bass(f, t, dur, vol) {
    const c = this.ctx;
    const o = c.createOscillator(); o.type = 'square'; o.frequency.value = f;
    const fl = c.createBiquadFilter(); fl.type = 'lowpass'; fl.Q.value = 6;
    fl.frequency.setValueAtTime(1100, t); fl.frequency.exponentialRampToValueAtTime(170, t + dur);
    const g = c.createGain();
    g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(vol, t + 0.008); g.gain.exponentialRampToValueAtTime(0.0008, t + dur);
    o.connect(fl).connect(g).connect(this.music);
    o.start(t); o.stop(t + dur + 0.03);
  }

  arp(f, t, dur, vol, wave = 'triangle') {
    const c = this.ctx;
    const o = c.createOscillator(); o.type = wave; o.frequency.value = f;
    const g = c.createGain();
    const v = wave === 'sawtooth' || wave === 'square' ? vol * 0.55 : vol;
    g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(v, t + 0.006); g.gain.exponentialRampToValueAtTime(0.0008, t + dur);
    o.connect(g); g.connect(this.music); g.connect(this.echo);
    o.start(t); o.stop(t + dur + 0.03);
  }

  lead(f, t, dur, wave = 'square') {
    const c = this.ctx;
    const o = c.createOscillator(); o.type = wave; o.frequency.value = f;
    const vib = c.createOscillator(); vib.frequency.value = 5.5;
    const vg = c.createGain(); vg.gain.value = f * 0.006;
    vib.connect(vg).connect(o.frequency);
    const fl = c.createBiquadFilter(); fl.type = 'lowpass'; fl.frequency.value = 2400;
    const g = c.createGain();
    g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(0.035, t + 0.02);
    g.gain.setValueAtTime(0.03, t + dur * 0.7); g.gain.exponentialRampToValueAtTime(0.0008, t + dur + 0.1);
    o.connect(fl).connect(g); g.connect(this.music); g.connect(this.echo);
    o.start(t); vib.start(t); o.stop(t + dur + 0.15); vib.stop(t + dur + 0.15);
  }

  kick(t, vol = 0.45) {
    const c = this.ctx;
    const o = c.createOscillator(); o.type = 'sine';
    o.frequency.setValueAtTime(140, t); o.frequency.exponentialRampToValueAtTime(42, t + 0.15);
    const g = c.createGain(); g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(vol, t + 0.004); g.gain.exponentialRampToValueAtTime(0.0008, t + 0.3);
    o.connect(g).connect(this.music); o.start(t); o.stop(t + 0.32);
  }

  hat(t, vol) {
    const c = this.ctx;
    const s = c.createBufferSource(); s.buffer = this.noiseBuf;
    const g = c.createGain(); g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.0008, t + 0.05);
    s.connect(g).connect(this.hatBus); s.start(t, Math.random()); s.stop(t + 0.06);
  }

  snare(t, vol = 0.11) {
    const c = this.ctx;
    const s = c.createBufferSource(); s.buffer = this.noiseBuf;
    const g = c.createGain(); g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.0008, t + 0.18);
    s.connect(g); g.connect(this.snareBus); g.connect(this.echo); s.start(t, Math.random()); s.stop(t + 0.2);
  }

  // ---------- sfx ----------
  tone(f, dur, type = 'sine', vol = 0.2, slide = null, delay = 0) {
    if (!this.running) return;
    const c = this.ctx, t = c.currentTime + delay;
    const o = c.createOscillator(); o.type = type; o.frequency.setValueAtTime(f, t);
    if (slide) o.frequency.exponentialRampToValueAtTime(slide, t + dur);
    const g = c.createGain(); g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(vol, t + 0.005); g.gain.exponentialRampToValueAtTime(0.0008, t + dur);
    o.connect(g).connect(this.sfx); o.start(t); o.stop(t + dur + 0.02);
  }

  noise(dur, freq, vol = 0.3, type = 'lowpass', sweepTo = null) {
    if (!this.running) return;
    const c = this.ctx, t = c.currentTime;
    const s = c.createBufferSource(); s.buffer = this.noiseBuf;
    const f = c.createBiquadFilter(); f.type = type; f.frequency.setValueAtTime(freq, t);
    if (sweepTo) f.frequency.exponentialRampToValueAtTime(sweepTo, t + dur);
    const g = c.createGain(); g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.0008, t + dur);
    s.connect(f).connect(g).connect(this.sfx); s.start(t, Math.random() * 0.3); s.stop(t + Math.min(dur + 0.02, 1.4));
  }

  sun() { this.tone(660, 0.25, 'sine', 0.16, 1320); this.tone(990, 0.3, 'triangle', 0.07, 1980, 0.05); }
  prism(mult) { const f = 880 * Math.pow(2, Math.min(mult, 24) / 24); this.tone(f, 0.18, 'triangle', 0.12); this.tone(f * 1.5, 0.22, 'sine', 0.06, null, 0.04); }
  power() { [0, 4, 7, 12].forEach((n, i) => this.tone(mtof(72 + n), 0.2, 'square', 0.05, null, i * 0.05)); }
  jump() { this.noise(0.4, 400, 0.22, 'bandpass', 3000); this.tone(220, 0.3, 'sawtooth', 0.05, 660); }
  dash() { this.noise(0.25, 2500, 0.18, 'bandpass', 600); }
  near() { this.tone(1500, 0.12, 'square', 0.04, 700); this.noise(0.15, 5000, 0.1, 'highpass'); }
  crash() { this.noise(1.3, 3000, 0.6, 'lowpass', 60); this.tone(120, 1.0, 'sawtooth', 0.2, 30); }
  smash() { this.noise(0.5, 2000, 0.38, 'lowpass', 120); this.tone(90, 0.4, 'square', 0.12, 40); }
  shieldHit() { this.tone(400, 0.5, 'sawtooth', 0.13, 100); this.noise(0.4, 1500, 0.25, 'bandpass'); }
  click() { this.tone(1200, 0.05, 'square', 0.04); }
  hover() { this.tone(1800, 0.03, 'sine', 0.025); }
  buy() { [0, 7, 12, 19].forEach((n, i) => this.tone(mtof(76 + n), 0.15, 'triangle', 0.09, null, i * 0.06)); }
  deny() { this.tone(200, 0.2, 'square', 0.07, 120); }
  portal() { this.noise(1.2, 200, 0.3, 'bandpass', 6000); [0, 3, 7, 10, 14].forEach((n, i) => this.tone(mtof(64 + n), 0.5, 'sawtooth', 0.035, null, i * 0.08)); }
  sunset() { this.tone(440, 2.2, 'sawtooth', 0.1, 55); }
  warn() { this.tone(980, 0.08, 'square', 0.03); }
  splash() { this.noise(0.5, 1800, 0.12, 'bandpass', 400); }
  // supernatural abilities
  nova() { this.noise(1.4, 6000, 0.6, 'lowpass', 50); this.tone(60, 1.4, 'sawtooth', 0.3, 25); [0, 7, 12, 19, 24].forEach((n, i) => this.tone(mtof(60 + n), 1.0, 'triangle', 0.06, null, 0.05 + i * 0.04)); }
  warp() { this.noise(1.2, 200, 0.4, 'bandpass', 8000); this.tone(110, 1.1, 'sawtooth', 0.12, 1760); }
  rebirth() { [0, 4, 7, 11, 14, 19].forEach((n, i) => this.tone(mtof(60 + n), 1.4, 'sine', 0.08, null, i * 0.07)); this.noise(1.0, 600, 0.2, 'bandpass', 5000); }
  sunheart() { [0, 4, 7, 12].forEach((n, i) => this.tone(mtof(69 + n), 0.8, 'triangle', 0.09, null, i * 0.05)); }
  ghost() { this.tone(300, 1.2, 'sine', 0.12, 900); this.tone(303, 1.2, 'sine', 0.1, 600); }
}
