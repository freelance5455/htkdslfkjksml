// MAFIA MYSTERY - Audio Synthesizer, Dynamic Music Engine & Haptics
// Developed by Siddharth Tiwari
class SoundEngine {
  constructor() {
    this.ctx = null;
    let sfx = true, bgm = true, haptics = true;
    try {
      if (typeof localStorage !== 'undefined') {
        if (localStorage.getItem('mm_sfx') === 'false') sfx = false;
        if (localStorage.getItem('mm_bgm') === 'false') bgm = false;
        if (localStorage.getItem('mm_haptics') === 'false') haptics = false;
      }
    } catch (e) {}
    this.sfxEnabled = sfx;
    this.bgmEnabled = bgm;
    this.hapticsEnabled = haptics;
    this.masterVolume = 0.5;
    this.currentTrack = null;
    this.musicTimer = null;
    this.stepCount = 0;
  }

  init() {
    if (!this.ctx) {
      const AC = window.AudioContext || window.webkitAudioContext;
      if (AC) this.ctx = new AC();
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  vibrate(pattern) {
    if (this.hapticsEnabled && typeof navigator !== 'undefined' && navigator.vibrate) {
      try { navigator.vibrate(pattern); } catch (e) {}
    }
  }

  // Generic tone builder
  tone(type, startF, endF, startT, dur, peakGain = 0.4) {
    if (!this.ctx) return;
    const o = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    o.type = type;
    o.frequency.setValueAtTime(startF, startT);
    if (endF !== startF) o.frequency.exponentialRampToValueAtTime(Math.max(1, endF), startT + dur);
    g.gain.setValueAtTime(this.masterVolume * peakGain, startT);
    g.gain.exponentialRampToValueAtTime(0.0001, startT + dur);
    o.connect(g);
    g.connect(this.ctx.destination);
    o.start(startT);
    o.stop(startT + dur + 0.02);
  }

  // ==========================================
  // BACKGROUND MUSIC ENGINE (PROCEDURAL LOOPS)
  // ==========================================
  startMenuMusic() {
    if (this.currentTrack === 'menu') return;
    this.stopMusic();
    this.currentTrack = 'menu';
    if (!this.bgmEnabled) return;
    this.init();
    if (!this.ctx) return;

    // Atmospheric Noir / Mystery Menu Loop
    // Chords: Dm -> Bb -> Gm -> A
    const chords = [
      [146.83, 174.61, 220.00], // Dm (D3, F3, A3)
      [116.54, 146.83, 174.61], // Bb (Bb2, D3, F3)
      [98.00, 116.54, 146.83],  // Gm (G2, Bb2, D3)
      [110.00, 138.59, 164.81]  // A (A2, C#3, E3)
    ];
    let chordIdx = 0;
    this.stepCount = 0;

    const playMenuStep = () => {
      if (this.currentTrack !== 'menu' || !this.bgmEnabled || !this.ctx) return;
      const now = this.ctx.currentTime;
      const chord = chords[chordIdx % chords.length];

      // Warm pad chord
      chord.forEach(f => {
        const o = this.ctx.createOscillator();
        const g = this.ctx.createGain();
        const filter = this.ctx.createBiquadFilter();

        o.type = 'sawtooth';
        o.frequency.setValueAtTime(f, now);

        filter.type = 'lowpass';
        filter.frequency.setValueAtTime(400, now);
        filter.frequency.linearRampToValueAtTime(650, now + 1.2);
        filter.frequency.linearRampToValueAtTime(350, now + 2.4);

        g.gain.setValueAtTime(0.001, now);
        g.gain.linearRampToValueAtTime(this.masterVolume * 0.08, now + 0.4);
        g.gain.exponentialRampToValueAtTime(0.0001, now + 2.38);

        o.connect(filter);
        filter.connect(g);
        g.connect(this.ctx.destination);
        o.start(now);
        o.stop(now + 2.4);
      });

      // Subtle heartbeat pulse
      this.tone('sine', 55, 35, now, 0.3, 0.15);

      chordIdx++;
    };

    playMenuStep();
    this.musicTimer = setInterval(playMenuStep, 2400);
  }

  startGameplayMusic(isDaytime = false) {
    if (this.currentTrack === 'gameplay') return;
    this.stopMusic();
    this.currentTrack = 'gameplay';
    if (!this.bgmEnabled) return;
    this.init();
    if (!this.ctx) return;

    // Tense investigative stealth / deliberation groove
    const bassNotes = [73.42, 73.42, 87.31, 65.41, 73.42, 82.41, 65.41, 55.00]; // D2 progression
    let step = 0;

    const playGameplayStep = () => {
      if (this.currentTrack !== 'gameplay' || !this.bgmEnabled || !this.ctx) return;
      const now = this.ctx.currentTime;
      const f = bassNotes[step % bassNotes.length];

      // Subtle tactical bass pulse
      const o = this.ctx.createOscillator();
      const g = this.ctx.createGain();
      const filter = this.ctx.createBiquadFilter();

      o.type = 'triangle';
      o.frequency.setValueAtTime(f, now);

      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(260, now);

      g.gain.setValueAtTime(0.001, now);
      g.gain.linearRampToValueAtTime(this.masterVolume * 0.12, now + 0.05);
      g.gain.exponentialRampToValueAtTime(0.0001, now + 0.55);

      o.connect(filter);
      filter.connect(g);
      g.connect(this.ctx.destination);
      o.start(now);
      o.stop(now + 0.58);

      // Ticking stealth clock every second beat
      if (step % 2 === 0) {
        this.tone('triangle', 900, 450, now, 0.03, 0.03);
      }

      step++;
    };

    playGameplayStep();
    this.musicTimer = setInterval(playGameplayStep, 600);
  }

  stopMusic() {
    this.currentTrack = null;
    if (this.musicTimer) {
      clearInterval(this.musicTimer);
      this.musicTimer = null;
    }
  }

  setBgmEnabled(enabled) {
    this.bgmEnabled = enabled;
    try { if (typeof localStorage !== 'undefined') localStorage.setItem('mm_bgm', enabled ? 'true' : 'false'); } catch (e) {}
    if (!enabled) this.stopMusic();
    else if (this.currentTrack === 'menu') this.startMenuMusic();
    else if (this.currentTrack === 'gameplay') this.startGameplayMusic();
  }

  setSfxEnabled(enabled) {
    this.sfxEnabled = enabled;
    try { if (typeof localStorage !== 'undefined') localStorage.setItem('mm_sfx', enabled ? 'true' : 'false'); } catch (e) {}
  }

  setHapticsEnabled(enabled) {
    this.hapticsEnabled = enabled;
    try { if (typeof localStorage !== 'undefined') localStorage.setItem('mm_haptics', enabled ? 'true' : 'false'); } catch (e) {}
  }

  // ==========================================
  // SOUND EFFECTS
  // ==========================================
  playCardFlip() {
    if (!this.sfxEnabled) return;
    this.init(); if (!this.ctx) return;
    this.vibrate(20);
    this.tone('sine', 750, 1300, this.ctx.currentTime, 0.04, 0.28);
  }

  playDiceRoll() {
    if (!this.sfxEnabled) return;
    this.init(); if (!this.ctx) return;
    this.vibrate([15, 30, 15, 30, 15]);
    const now = this.ctx.currentTime;
    for (let i = 0; i < 7; i++) {
      this.tone('triangle', 550 + i * 85, 1050 + i * 75, now + i * 0.11, 0.04, 0.22);
    }
  }

  playDiceLanding() {
    if (!this.sfxEnabled) return;
    this.init(); if (!this.ctx) return;
    this.vibrate([60, 40, 80]);
    this.tone('sine', 260, 55, this.ctx.currentTime, 0.24, 0.55);
  }

  playNightBell() {
    if (!this.sfxEnabled) return;
    this.init(); if (!this.ctx) return;
    this.vibrate(50);
    this.tone('sine', 310, 105, this.ctx.currentTime, 0.85, 0.35);
  }

  playKill() {
    if (!this.sfxEnabled) return;
    this.init(); if (!this.ctx) return;
    this.vibrate([80, 40, 120]);
    this.tone('sawtooth', 340, 40, this.ctx.currentTime, 0.3, 0.65);
  }

  playHeal() {
    if (!this.sfxEnabled) return;
    this.init(); if (!this.ctx) return;
    this.vibrate(40);
    const now = this.ctx.currentTime;
    [440, 554.37, 659.25, 880].forEach((f, i) => {
      this.tone('sine', f, f, now + i * 0.07, 1.05, 0.3);
    });
  }

  playMagic() {
    if (!this.sfxEnabled) return;
    this.init(); if (!this.ctx) return;
    this.vibrate(35);
    const now = this.ctx.currentTime;
    [659.25, 880, 1046.5, 1318.51].forEach((f, i) => {
      this.tone('triangle', f, f, now + i * 0.06, 0.42, 0.32);
    });
  }

  playDayDawn() {
    if (!this.sfxEnabled) return;
    this.init(); if (!this.ctx) return;
    this.vibrate([40, 40, 80]);
    const now = this.ctx.currentTime;
    [329.63, 440, 554.37, 659.25].forEach((f, i) => {
      this.tone('sine', f, f, now + i * 0.08, 0.65, 0.3);
    });
  }

  playEmergencySiren() {
    if (!this.sfxEnabled) return;
    this.init(); if (!this.ctx) return;
    this.vibrate([100, 50, 100, 50, 150]);
    const now = this.ctx.currentTime;
    [0, 0.28, 0.56].forEach(delay => {
      const o = this.ctx.createOscillator();
      const g = this.ctx.createGain();
      const t = now + delay;
      o.type = 'sawtooth';
      o.frequency.setValueAtTime(440, t);
      o.frequency.linearRampToValueAtTime(740, t + 0.14);
      o.frequency.linearRampToValueAtTime(440, t + 0.26);
      g.gain.setValueAtTime(0.01, t);
      g.gain.linearRampToValueAtTime(this.masterVolume * 0.38, t + 0.04);
      g.gain.exponentialRampToValueAtTime(0.001, t + 0.26);
      o.connect(g);
      g.connect(this.ctx.destination);
      o.start(t);
      o.stop(t + 0.27);
    });
  }

  playGavel() {
    if (!this.sfxEnabled) return;
    this.init(); if (!this.ctx) return;
    this.vibrate(30);
    this.tone('triangle', 480, 150, this.ctx.currentTime, 0.15, 0.45);
  }

  playVictory() {
    if (!this.sfxEnabled) return;
    this.init(); if (!this.ctx) return;
    this.vibrate([100, 50, 100, 50, 200]);
    const now = this.ctx.currentTime;
    [261.63, 329.63, 392, 523.25, 659.25].forEach((f, i) => {
      this.tone('triangle', f, f, now + i * 0.1, 1.05, 0.4);
    });
  }

  playDefeat() {
    if (!this.sfxEnabled) return;
    this.init(); if (!this.ctx) return;
    this.vibrate([150, 80, 200]);
    const now = this.ctx.currentTime;
    [240, 210, 180, 130].forEach((f, i) => {
      this.tone('sawtooth', f, f, now + i * 0.18, 0.45, 0.38);
    });
  }
}

window.soundEngine = new SoundEngine();
