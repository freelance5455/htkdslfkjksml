// Procedural synthwave soundtrack + SFX via Web Audio (no files needed)
const mtof = m => 440 * Math.pow(2, (m - 69) / 12);

export class SynthAudio {
  constructor() {
    this.ctx = null;
    this.muted = false;
    this.intensity = 0; // 0 menu, 1 run
    this.step = 0;
    this.nextTime = 0;
    this.timer = null;
  }

  init() {
    if (this.ctx) { this.ctx.resume(); return; }
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    const ctx = this.ctx = new AC();
    this.master = ctx.createGain();
    this.master.gain.value = this.muted ? 0 : 0.8;
    const comp = ctx.createDynamicsCompressor();
    comp.threshold.value = -14; comp.ratio.value = 4;
    this.master.connect(comp).connect(ctx.destination);

    this.music = ctx.createGain(); this.music.gain.value = 0.32;
    this.music.connect(this.master);
    this.sfx = ctx.createGain(); this.sfx.gain.value = 0.7;
    this.sfx.connect(this.master);

    // echo bus
    this.echo = ctx.createDelay(1); this.echo.delayTime.value = 0.351;
    const fb = ctx.createGain(); fb.gain.value = 0.38;
    const ef = ctx.createBiquadFilter(); ef.type = 'lowpass'; ef.frequency.value = 2400;
    this.echo.connect(ef).connect(fb).connect(this.echo);
    const eOut = ctx.createGain(); eOut.gain.value = 0.5;
    ef.connect(eOut).connect(this.music);

    // noise buffer
    const len = ctx.sampleRate * 1.5;
    this.noiseBuf = ctx.createBuffer(1, len, ctx.sampleRate);
    const d = this.noiseBuf.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;

    // engine drone
    this.engFilter = ctx.createBiquadFilter(); this.engFilter.type = 'lowpass'; this.engFilter.frequency.value = 300; this.engFilter.Q.value = 6;
    this.engGain = ctx.createGain(); this.engGain.gain.value = 0;
    this.engFilter.connect(this.engGain).connect(this.sfx);
    this.eng1 = ctx.createOscillator(); this.eng1.type = 'sawtooth'; this.eng1.frequency.value = 55;
    this.eng2 = ctx.createOscillator(); this.eng2.type = 'sawtooth'; this.eng2.frequency.value = 55.7;
    this.eng1.connect(this.engFilter); this.eng2.connect(this.engFilter);
    this.eng1.start(); this.eng2.start();
    const ns = ctx.createBufferSource(); ns.buffer = this.noiseBuf; ns.loop = true;
    this.windFilter = ctx.createBiquadFilter(); this.windFilter.type = 'bandpass'; this.windFilter.frequency.value = 800; this.windFilter.Q.value = 0.7;
    this.windGain = ctx.createGain(); this.windGain.gain.value = 0;
    ns.connect(this.windFilter).connect(this.windGain).connect(this.sfx); ns.start();

    this.tempo = 128;
    this.nextTime = ctx.currentTime + 0.1;
    this.timer = setInterval(() => this.schedule(), 25);
  }

  setMuted(m) {
    this.muted = m;
    if (this.master) this.master.gain.setTargetAtTime(m ? 0 : 0.8, this.ctx.currentTime, 0.05);
  }

  setEngine(level, speedNorm) {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    this.engGain.gain.setTargetAtTime(level * 0.22, t, 0.1);
    this.windGain.gain.setTargetAtTime(level * (0.05 + speedNorm * 0.12), t, 0.1);
    const f = 45 + speedNorm * 40;
    this.eng1.frequency.setTargetAtTime(f, t, 0.1);
    this.eng2.frequency.setTargetAtTime(f * 1.012, t, 0.1);
    this.engFilter.frequency.setTargetAtTime(220 + speedNorm * 900, t, 0.1);
    this.windFilter.frequency.setTargetAtTime(600 + speedNorm * 1800, t, 0.1);
  }

  // ---------- music ----------
  schedule() {
    const ctx = this.ctx;
    const stepDur = 60 / this.tempo / 4;
    while (this.nextTime < ctx.currentTime + 0.12) {
      this.playStep(this.step, this.nextTime, stepDur);
      this.nextTime += stepDur;
      this.step = (this.step + 1) % 256;
    }
  }

  playStep(s, t, sd) {
    // progression Am - F - C - G (each 1 bar = 16 steps)
    const prog = [[57, 60, 64], [53, 57, 60], [48, 52, 55], [55, 59, 62]];
    const bar = Math.floor(s / 16) % 4;
    const chord = prog[bar];
    const st = s % 16;
    const I = this.intensity;
    // pad on bar start
    if (st === 0) for (const n of chord) this.pad(mtof(n), t, sd * 16);
    // bass 8ths
    if (I > 0.3 && st % 2 === 0) this.bass(mtof(chord[0] - 24 + (st % 8 === 6 ? 12 : 0)), t, sd * 1.6);
    // arp 16ths
    const arpNotes = [chord[0], chord[1], chord[2], chord[0] + 12, chord[2], chord[1] + 12, chord[0] + 12, chord[2] + 12];
    if (st % (I > 0.3 ? 1 : 2) === 0) this.arp(mtof(arpNotes[st % 8] + 12), t, sd * 0.9, I > 0.3 ? 0.07 : 0.05);
    // drums
    if (I > 0.3) {
      if (st % 4 === 0) this.kick(t);
      if (st % 4 === 2) this.hat(t, 0.06);
      if (st % 2 === 1) this.hat(t, 0.02);
      if (st === 4 || st === 12) this.snare(t);
    }
  }

  pad(f, t, dur) {
    const c = this.ctx;
    const o1 = c.createOscillator(), o2 = c.createOscillator();
    o1.type = 'sawtooth'; o2.type = 'sawtooth';
    o1.frequency.value = f; o2.frequency.value = f * 1.006;
    const fl = c.createBiquadFilter(); fl.type = 'lowpass'; fl.frequency.value = 900; fl.Q.value = 1;
    const g = c.createGain();
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(0.045, t + 0.4);
    g.gain.linearRampToValueAtTime(0.03, t + dur - 0.2);
    g.gain.linearRampToValueAtTime(0, t + dur + 0.3);
    o1.connect(fl); o2.connect(fl); fl.connect(g).connect(this.music);
    o1.start(t); o2.start(t); o1.stop(t + dur + 0.4); o2.stop(t + dur + 0.4);
  }

  bass(f, t, dur) {
    const c = this.ctx;
    const o = c.createOscillator(); o.type = 'square'; o.frequency.value = f;
    const fl = c.createBiquadFilter(); fl.type = 'lowpass'; fl.Q.value = 8;
    fl.frequency.setValueAtTime(1200, t); fl.frequency.exponentialRampToValueAtTime(180, t + dur);
    const g = c.createGain();
    g.gain.setValueAtTime(0.16, t); g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    o.connect(fl).connect(g).connect(this.music);
    o.start(t); o.stop(t + dur + 0.05);
  }

  arp(f, t, dur, vol) {
    const c = this.ctx;
    const o = c.createOscillator(); o.type = 'triangle'; o.frequency.value = f;
    const g = c.createGain();
    g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    o.connect(g); g.connect(this.music); g.connect(this.echo);
    o.start(t); o.stop(t + dur + 0.05);
  }

  kick(t) {
    const c = this.ctx;
    const o = c.createOscillator(); o.type = 'sine';
    o.frequency.setValueAtTime(140, t); o.frequency.exponentialRampToValueAtTime(42, t + 0.15);
    const g = c.createGain(); g.gain.setValueAtTime(0.55, t); g.gain.exponentialRampToValueAtTime(0.001, t + 0.3);
    o.connect(g).connect(this.music); o.start(t); o.stop(t + 0.32);
  }

  hat(t, vol) {
    const c = this.ctx;
    const s = c.createBufferSource(); s.buffer = this.noiseBuf;
    const f = c.createBiquadFilter(); f.type = 'highpass'; f.frequency.value = 8000;
    const g = c.createGain(); g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.001, t + 0.05);
    s.connect(f).connect(g).connect(this.music); s.start(t, Math.random()); s.stop(t + 0.06);
  }

  snare(t) {
    const c = this.ctx;
    const s = c.createBufferSource(); s.buffer = this.noiseBuf;
    const f = c.createBiquadFilter(); f.type = 'bandpass'; f.frequency.value = 1800; f.Q.value = 0.8;
    const g = c.createGain(); g.gain.setValueAtTime(0.14, t); g.gain.exponentialRampToValueAtTime(0.001, t + 0.18);
    s.connect(f).connect(g).connect(this.music); g.connect(this.echo); s.start(t, Math.random()); s.stop(t + 0.2);
  }

  // ---------- sfx ----------
  tone(f, dur, type = 'sine', vol = 0.2, slide = null, delay = 0) {
    if (!this.ctx) return;
    const c = this.ctx, t = c.currentTime + delay;
    const o = c.createOscillator(); o.type = type; o.frequency.setValueAtTime(f, t);
    if (slide) o.frequency.exponentialRampToValueAtTime(slide, t + dur);
    const g = c.createGain(); g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    o.connect(g).connect(this.sfx); o.start(t); o.stop(t + dur + 0.02);
  }

  noise(dur, freq, vol = 0.3, type = 'lowpass', sweepTo = null) {
    if (!this.ctx) return;
    const c = this.ctx, t = c.currentTime;
    const s = c.createBufferSource(); s.buffer = this.noiseBuf;
    const f = c.createBiquadFilter(); f.type = type; f.frequency.setValueAtTime(freq, t);
    if (sweepTo) f.frequency.exponentialRampToValueAtTime(sweepTo, t + dur);
    const g = c.createGain(); g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    s.connect(f).connect(g).connect(this.sfx); s.start(t, Math.random() * 0.5); s.stop(t + dur + 0.02);
  }

  sun() { this.tone(660, 0.25, 'sine', 0.18, 1320); this.tone(990, 0.3, 'triangle', 0.08, 1980, 0.05); }
  prism(mult) { const f = 880 * Math.pow(2, Math.min(mult, 24) / 24); this.tone(f, 0.18, 'triangle', 0.14); this.tone(f * 1.5, 0.22, 'sine', 0.07, null, 0.04); }
  power() { [0, 4, 7, 12].forEach((n, i) => this.tone(mtof(72 + n), 0.2, 'square', 0.06, null, i * 0.05)); }
  jump() { this.noise(0.4, 400, 0.25, 'bandpass', 3000); this.tone(220, 0.3, 'sawtooth', 0.06, 660); }
  dash() { this.noise(0.25, 2500, 0.2, 'bandpass', 600); }
  near() { this.tone(1500, 0.12, 'square', 0.05, 700); this.noise(0.15, 5000, 0.12, 'highpass'); }
  crash() { this.noise(1.4, 3000, 0.7, 'lowpass', 60); this.tone(120, 1.0, 'sawtooth', 0.25, 30); }
  smash() { this.noise(0.5, 2000, 0.45, 'lowpass', 120); this.tone(90, 0.4, 'square', 0.15, 40); }
  shieldHit() { this.tone(400, 0.5, 'sawtooth', 0.15, 100); this.noise(0.4, 1500, 0.3, 'bandpass'); }
  click() { this.tone(1200, 0.05, 'square', 0.05); }
  hover() { this.tone(1800, 0.03, 'sine', 0.03); }
  buy() { [0, 7, 12, 19].forEach((n, i) => this.tone(mtof(76 + n), 0.15, 'triangle', 0.1, null, i * 0.06)); }
  deny() { this.tone(200, 0.2, 'square', 0.08, 120); }
  portal() { this.noise(1.2, 200, 0.35, 'bandpass', 6000); [0, 3, 7, 10, 14].forEach((n, i) => this.tone(mtof(64 + n), 0.5, 'sawtooth', 0.04, null, i * 0.08)); }
  sunset() { this.tone(440, 2.2, 'sawtooth', 0.12, 55); }
  warn() { this.tone(980, 0.08, 'square', 0.04); }
}
