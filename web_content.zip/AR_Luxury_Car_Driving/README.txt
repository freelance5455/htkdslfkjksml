AR LUXURY CAR DRIVE — PROTOTYPE V2

FILES
- index.html: updated mobile prototype with live camera request, camera error messages, touch controls, speed/gear HUD, selectable car styles:
  Rolls-Royce Phantom, Bentley Continental GT, Lamborghini Aventador, Ferrari SF90, Bugatti Chiron, Mercedes-AMG GT, BMW M4, Audi R8, Porsche 911, McLaren 720S, Nissan GT-R, Toyota Supra.
- README.txt: setup notes.

IMPORTANT
This is a visual prototype. The selectable cars are stylized vector illustrations, not licensed/manufacturer 3D models. The live camera feature needs a secure origin (HTTPS) or an Android WebView/HTML-to-APK builder that grants CAMERA permission. If you open index.html directly as file://, camera access may be blocked. In the APK builder, enable camera permission and use the local HTML as the start page.

This is NOT yet a true ARCore game. The car is drawn over the live camera feed and does not stay anchored to a real road. True road tracking requires a native ARCore/Unity project and a device supported by ARCore. An APK has not been built or device-tested.
