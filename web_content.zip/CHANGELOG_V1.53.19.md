# v1.53.19 — Correção da quota ao criar carreira

- Corrigida a preparação dos calendários brasileiros ao iniciar uma carreira nova: os caches globais de calendário são removidos antes de gravar as versões compactas, evitando acumular temporariamente versões antigas e novas e estourar a quota no calendário da Série C.
- Remove somente caches antigos e reconstruíveis de ligas; não apaga o armazenamento principal das carreiras nem os saves do jogador.
- Mantidos os calendários compactos por divisão e o fluxo das partidas.
- Atualizada a versão do cache do service worker.
