SADDAM DIGGA PHARMACY — v10.30 DASHBOARD QA CONSISTENCY FIX

Kun Android WebView source project dha; APK install-ready miti.
Dashboard: metric/KPI cards, quick actions horizontal, mobile responsive. Legacy profile strip Dashboard irratti CSS dhaan dhokfame; profile edit Settings keessa qofa. Calendar Dashboard irratti showPage() logic dhaan dhokata.
HTML copy lamaan synchronized; title/versionName/versionCode fi backup/export appVersion wal-simsiifame (10.30 / 83).
Static QA performed: ZIP integrity, inline JavaScript syntax, Android Manifest XML parsing, duplicate HTML IDs scan, version consistency checks.
Android runtime, login, POS, stock, reports, backup/restore fi permissions bilbila irratti guutumaan hin testamne.
