import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;
import 'package:webview_flutter/webview_flutter.dart';

// Android emulator -> host machine. On a real phone use your server's address.
const kApi = 'http://10.0.2.2:8000';
const kSymbols = {'XAUUSD': 'Gold XAU/USD', 'EURUSD': 'EUR/USD', 'BTCUSD': 'BTC/USD', 'NQ': 'NQ', 'ES': 'ES'};

const kText = {
  'en': {'title': 'ICT Signals', 'analyze': 'Analyze current market', 'capital': 'Capital', 'risk': 'Risk %',
         'why': 'Trade rationale', 'lots': 'Lot size', 'rr': 'Risk/Reward', 'score': 'Confluence',
         'none': 'No setup: confluence is below 80% or no 1:2 target exists.',
         'news': 'High-impact news window: signals are paused.', 'error': 'Could not reach the server.'},
  'ar': {'title': 'إشارات ICT', 'analyze': 'تحليل السوق الحالي', 'capital': 'رأس المال', 'risk': 'نسبة المخاطرة %',
         'why': 'سبب الدخول', 'lots': 'حجم اللوت', 'rr': 'المخاطرة/العائد', 'score': 'نسبة التوافق',
         'none': 'لا توجد صفقة: التوافق أقل من 80% أو لا يوجد هدف بنسبة 1:2.',
         'news': 'نافذة أخبار قوية: تم إيقاف الإشارات.', 'error': 'تعذر الاتصال بالخادم.'},
};

void main() => runApp(const App());

class App extends StatefulWidget {
  const App({super.key});
  @override
  State<App> createState() => _AppState();
}

class _AppState extends State<App> {
  Locale locale = const Locale('ar');
  void toggle() => setState(() => locale = locale.languageCode == 'ar' ? const Locale('en') : const Locale('ar'));

  @override
  Widget build(BuildContext context) {
    final base = ThemeData.dark(useMaterial3: true).copyWith(
      scaffoldBackgroundColor: const Color(0xFF0E1116),
      colorScheme: const ColorScheme.dark(primary: Color(0xFFD4A84B), surface: Color(0xFF171B22)),
    );
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      locale: locale, // Arabic locale => automatic RTL layout
      supportedLocales: const [Locale('ar'), Locale('en')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate, GlobalWidgetsLocalizations.delegate, GlobalCupertinoLocalizations.delegate],
      theme: base.copyWith(textTheme: GoogleFonts.cairoTextTheme(base.textTheme)),
      home: Home(onToggleLang: toggle),
    );
  }
}

class Home extends StatefulWidget {
  final VoidCallback onToggleLang;
  const Home({super.key, required this.onToggleLang});
  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  late final WebViewController web;
  bool pageReady = false, loading = false;
  String symbol = 'XAUUSD';
  final capital = TextEditingController(text: '1000');
  final risk = TextEditingController(text: '1');
  Map<String, dynamic>? result;
  String? error;

  @override
  void initState() {
    super.initState();
    web = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(const Color(0xFF0E1116))
      ..setNavigationDelegate(NavigationDelegate(onPageFinished: (_) {
        pageReady = true;
        if (result != null) _push();
      }))
      ..loadFlutterAsset('assets/chart.html');
  }

  void _push() => web.runJavaScript('render(${jsonEncode({'candles': result!['candles'], 'signal': result!['signal']})})');

  Future<void> run() async {
    setState(() { loading = true; error = null; });
    try {
      final uri = Uri.parse('$kApi/analyze').replace(queryParameters: {
        'symbol': symbol, 'capital': capital.text, 'risk_pct': risk.text});
      final r = await http.get(uri).timeout(const Duration(seconds: 60));
      result = jsonDecode(utf8.decode(r.bodyBytes)); // utf8 keeps Arabic text intact
      if (pageReady) _push();
    } catch (_) {
      error = 'error';
    }
    if (mounted) setState(() => loading = false);
  }

  @override
  Widget build(BuildContext context) {
    final lang = Localizations.localeOf(context).languageCode;
    String t(String k) => kText[lang]![k]!;
    final sig = result?['signal'];
    return Scaffold(
      appBar: AppBar(
        title: Text(t('title')), backgroundColor: Colors.transparent,
        actions: [TextButton(onPressed: widget.onToggleLang, child: Text(lang == 'ar' ? 'EN' : 'ع'))],
      ),
      body: Column(children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Row(children: [
            Expanded(flex: 3, child: DropdownButtonFormField<String>(
              value: symbol,
              items: kSymbols.entries.map((e) => DropdownMenuItem(value: e.key, child: Text(e.value))).toList(),
              onChanged: (v) => setState(() => symbol = v!),
            )),
            const SizedBox(width: 8),
            Expanded(flex: 2, child: TextField(controller: capital, keyboardType: TextInputType.number,
                decoration: InputDecoration(labelText: t('capital')))),
            const SizedBox(width: 8),
            Expanded(flex: 2, child: TextField(controller: risk, keyboardType: TextInputType.number,
                decoration: InputDecoration(labelText: t('risk')))),
          ]),
        ),
        Padding(
          padding: const EdgeInsets.all(16),
          child: SizedBox(width: double.infinity, height: 52, child: FilledButton(
            onPressed: loading ? null : run,
            child: loading ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2))
                           : Text(t('analyze'), style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700)),
          )),
        ),
        Expanded(flex: 5, child: WebViewWidget(controller: web)),
        Expanded(flex: 3, child: ListView(padding: const EdgeInsets.all(16), children: [
          if (error != null) Text(t('error'), style: const TextStyle(color: Color(0xFFE5575B))),
          if (result != null && sig == null)
            Text(result!['reason'] == 'news_block' ? t('news') : t('none')),
          if (sig != null) ...[
            Text('${t('score')}: ${result!['score']}%   •   ${t('rr')}: 1:${sig['rr']}',
                style: const TextStyle(fontWeight: FontWeight.w700)),
            Text('${t('lots')}: ${result!['lot']['lots']}  (\$${result!['lot']['risk_amount']})'),
            const SizedBox(height: 12),
            Text(t('why'), style: const TextStyle(fontWeight: FontWeight.w700, color: Color(0xFFD4A84B))),
            Text(result!['rationale'][lang], style: const TextStyle(height: 1.6)),
          ],
        ])),
      ]),
    );
  }
}
