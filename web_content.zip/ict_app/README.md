# ICT Signals — Project Structure

```
ict_app/
├── backend/
│   ├── requirements.txt
│   └── app/
│       ├── main.py          # FastAPI: GET /analyze
│       └── ict/
│           ├── structure.py # swings, sweeps, MSS/BOS, FVG, OB, premium/discount
│           ├── mtf.py       # 4H bias -> 15M confirm -> 5M entry, confluence score, SL/TP/RR
│           ├── news.py      # red-folder filter (-30 / +15 min)
│           ├── risk.py      # lot size calculator
│           └── data.py      # yfinance loader + synthetic demo data
└── flutter/
    ├── pubspec.yaml
    ├── assets/chart.html    # Lightweight Charts + zone overlay
    └── lib/main.dart        # UI (AR/EN, dark), API + chart bridge
```

## Run
1. `cd backend && pip install -r requirements.txt && uvicorn app.main:app --host 0.0.0.0 --port 8000`
2. Test without internet: `http://localhost:8000/analyze?demo=true`
3. `cd flutter && flutter create . --platforms=android,ios` (generates native folders; keeps lib/ and assets/)
4. Download `lightweight-charts.standalone.production.js` (v4.x, from the npm package `lightweight-charts`) and save it as `flutter/assets/lightweight-charts.js`
5. Edit `kApi` in `lib/main.dart` (emulator: `10.0.2.2`; phone: your server IP), then `flutter pub get && flutter build apk --release`
   - Android needs `<uses-permission android:name="android.permission.INTERNET"/>` and, for plain-HTTP dev servers, `android:usesCleartextTraffic="true"` in AndroidManifest.xml.

## How the bridge works
`/analyze` returns `{score, signal{entry,sl,tp,rr,zone}, candles, rationale{ar,en}, lot, news}`.
Flutter decodes it (UTF-8, so Arabic is preserved) and calls `render(json)` inside the WebView.
`chart.html` draws candles, Entry/SL/TP price lines, and a shaded box for the FVG/OB.

## Push notifications (not included)
Add `firebase_messaging` in Flutter and `firebase-admin` in the backend; run a scheduler (APScheduler) that
calls `generate_signal` per symbol every few minutes and sends an FCM message when `signal` is not None and news is clear.

## Tested / not tested
Backend logic ran on synthetic data (no crashes; signal path, RR and lot math verified). Flutter, yfinance and
the news feed were NOT run here. Treat the thresholds as a starting point and backtest before trading.
