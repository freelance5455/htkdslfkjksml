"""ICT core: swings, liquidity sweeps, MSS/BOS, FVG, Order Blocks, Premium/Discount."""
from __future__ import annotations
from dataclasses import dataclass, field
import numpy as np
import pandas as pd


@dataclass
class Zone:
    kind: str            # "FVG" | "OB"
    side: str            # "bull" | "bear"
    top: float
    bottom: float
    t0: int              # candle index where the zone starts
    form_idx: int        # candle index when the zone became known
    invalid: bool = False
    swept: bool = False  # OB backed by a prior liquidity sweep


@dataclass
class Analysis:
    trend: int = 0                       # 1 bull, -1 bear, 0 unknown
    events: list = field(default_factory=list)   # MSS / BOS
    sweeps: list = field(default_factory=list)   # liquidity sweeps
    zones: list = field(default_factory=list)    # FVG + OB
    swing_highs: dict = field(default_factory=dict)
    swing_lows: dict = field(default_factory=dict)
    range_high: float | None = None
    range_low: float | None = None
    atr: float = 0.0


def atr(df: pd.DataFrame, p: int = 14) -> pd.Series:
    pc = df["close"].shift()
    tr = pd.concat([df["high"] - df["low"], (df["high"] - pc).abs(),
                    (df["low"] - pc).abs()], axis=1).max(axis=1)
    return tr.rolling(p, min_periods=1).mean()


def find_swings(df: pd.DataFrame, n: int = 3):
    h, l = df["high"].values, df["low"].values
    sh, sl = {}, {}
    for i in range(n, len(df) - n):
        if h[i] > h[i - n:i].max() and h[i] >= h[i + 1:i + n + 1].max():
            sh[i] = float(h[i])
        if l[i] < l[i - n:i].min() and l[i] <= l[i + 1:i + n + 1].min():
            sl[i] = float(l[i])
    return sh, sl


def find_fvgs(df: pd.DataFrame, min_gap_atr: float = 0.1) -> list[Zone]:
    h, l = df["high"].values, df["low"].values
    a = atr(df).values
    zones = []
    for i in range(2, len(df)):
        if l[i] > h[i - 2] and (l[i] - h[i - 2]) >= min_gap_atr * a[i]:
            zones.append(Zone("FVG", "bull", float(l[i]), float(h[i - 2]), i - 1, i))
        elif h[i] < l[i - 2] and (l[i - 2] - h[i]) >= min_gap_atr * a[i]:
            zones.append(Zone("FVG", "bear", float(l[i - 2]), float(h[i]), i - 1, i))
    return zones


def _order_block(df, origin: int, side: str, lookback: int = 10) -> Zone | None:
    """Last opposite-colour candle at/before the origin of the displacement leg."""
    o, c, h, l = (df[k].values for k in ("open", "close", "high", "low"))
    for j in range(origin, max(origin - lookback, -1), -1):
        if (side == "bull" and c[j] < o[j]) or (side == "bear" and c[j] > o[j]):
            return Zone("OB", side, float(h[j]), float(l[j]), j, origin)
    return None


def analyze(df: pd.DataFrame, n: int = 3) -> Analysis:
    df = df.reset_index(drop=True)
    sh, sl = find_swings(df, n)
    o, h, l, c = (df[k].values for k in ("open", "high", "low", "close"))
    A = Analysis(swing_highs=sh, swing_lows=sl, atr=float(atr(df).iloc[-1]))
    last_sh = last_sl = None            # [idx, price, swept_flag]
    trend = 0
    obs: list[Zone] = []

    for i in range(len(df)):
        s = i - n                       # swing at s is confirmed at i
        if s in sh: last_sh = [s, sh[s], False]
        if s in sl: last_sl = [s, sl[s], False]

        if last_sh:
            idx, px, swept = last_sh
            if c[i] > px:               # bullish break
                kind = "MSS" if trend == -1 else "BOS"
                A.events.append(dict(type=kind, dir="bull", idx=i, level=px, swing_idx=idx))
                origin = idx + int(np.argmin(l[idx:i + 1]))
                ob = _order_block(df, origin, "bull")
                if ob:
                    ob.form_idx = i
                    ob.swept = any(w["kind"] == "sell" and origin - 5 <= w["idx"] <= origin + n + 1
                                   for w in A.sweeps)
                    obs.append(ob)
                trend, last_sh = 1, None
            elif h[i] > px and not swept:   # wick above, close back below
                A.sweeps.append(dict(kind="buy", idx=i, level=px)); last_sh[2] = True

        if last_sl:
            idx, px, swept = last_sl
            if c[i] < px:               # bearish break
                kind = "MSS" if trend == 1 else "BOS"
                A.events.append(dict(type=kind, dir="bear", idx=i, level=px, swing_idx=idx))
                origin = idx + int(np.argmax(h[idx:i + 1]))
                ob = _order_block(df, origin, "bear")
                if ob:
                    ob.form_idx = i
                    ob.swept = any(w["kind"] == "buy" and origin - 5 <= w["idx"] <= origin + n + 1
                                   for w in A.sweeps)
                    obs.append(ob)
                trend, last_sl = -1, None
            elif l[i] < px and not swept:
                A.sweeps.append(dict(kind="sell", idx=i, level=px)); last_sl[2] = True

    A.trend = trend
    A.zones = find_fvgs(df) + obs
    for z in A.zones:                   # invalidated = later close through the far side
        seg = c[z.form_idx + 1:]
        if len(seg) and ((z.side == "bull" and seg.min() < z.bottom) or
                         (z.side == "bear" and seg.max() > z.top)):
            z.invalid = True
    if sh and sl:
        A.range_high, A.range_low = sh[max(sh)], sl[max(sl)]
    return A
