import numpy as np, pandas as pd

YF = {"XAUUSD": "GC=F", "EURUSD": "EURUSD=X", "BTCUSD": "BTC-USD", "NQ": "NQ=F", "ES": "ES=F"}

def _fetch(sym, interval, period):
    import yfinance as yf
    df = yf.download(YF[sym], interval=interval, period=period, progress=False, auto_adjust=False)
    df.columns = [(c[0] if isinstance(c, tuple) else c).lower() for c in df.columns]
    return df[["open", "high", "low", "close"]].dropna()

def load(sym: str):
    """HTF 4H (from 1H) / MID 15M / LTF 5M."""
    h1 = _fetch(sym, "1h", "60d")
    htf = h1.resample("4h").agg({"open": "first", "high": "max", "low": "min", "close": "last"}).dropna()
    return htf, _fetch(sym, "15m", "30d"), _fetch(sym, "5m", "7d")

def synthetic(seed=0, n=600, start=2000.0, step="5min"):
    rng = np.random.default_rng(seed)
    trend = np.sin(np.linspace(0, 12, n)) * 0.6
    c = start + np.cumsum(rng.normal(trend, 1.2))
    o = np.r_[start, c[:-1]]
    h = np.maximum(o, c) + rng.random(n) * 1.2
    l = np.minimum(o, c) - rng.random(n) * 1.2
    idx = pd.date_range("2026-01-01", periods=n, freq=step, tz="UTC")
    return pd.DataFrame({"open": o, "high": h, "low": l, "close": c}, index=idx)

def load_demo(seed=0):
    ltf = synthetic(seed, 900, step="5min")
    mid = ltf.resample("15min").agg({"open": "first", "high": "max", "low": "min", "close": "last"}).dropna()
    htf = ltf.resample("4h").agg({"open": "first", "high": "max", "low": "min", "close": "last"}).dropna()
    return htf, mid, ltf
