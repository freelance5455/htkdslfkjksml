"""Multi-timeframe confluence + signal generation (HTF bias -> MID confirmation -> LTF entry)."""
from .structure import analyze

WEIGHTS = {"htf_bias": 25, "htf_pd": 15, "sweep": 20, "mid_structure": 20, "ltf_entry": 20}

def _ts(df, i):
    return int(df.index[min(i, len(df) - 1)].timestamp())

def generate_signal(htf, mid, ltf, min_rr=2.0, threshold=80):
    H, M, L = analyze(htf), analyze(mid), analyze(ltf)
    if H.trend == 0:
        return {"signal": None, "score": 0, "reason": "no_htf_bias"}
    long = H.trend == 1
    side = "bull" if long else "bear"
    price = float(ltf["close"].iloc[-1])
    flags, score = {"htf_bias": True}, WEIGHTS["htf_bias"]

    if H.range_high and H.range_low:
        eq = (H.range_high + H.range_low) / 2
        if (long and price < eq) or (not long and price > eq):
            flags["htf_pd"] = True; score += WEIGHTS["htf_pd"]

    need = "sell" if long else "buy"
    if any(s["kind"] == need and s["idx"] >= len(mid) - 40 for s in M.sweeps) or \
       any(s["kind"] == need and s["idx"] >= len(htf) - 10 for s in H.sweeps):
        flags["sweep"] = True; score += WEIGHTS["sweep"]

    ev = [e for e in M.events if e["dir"] == side and e["idx"] >= len(mid) - 40]
    if ev:
        flags["mid_structure"] = ev[-1]["type"]; score += WEIGHTS["mid_structure"]

    buf = 0.25 * L.atr
    cands = [z for z in L.zones if z.side == side and not z.invalid
             and z.form_idx >= len(ltf) - 60 and z.bottom - buf <= price <= z.top + buf]
    zone = None
    if cands:
        zone = sorted(cands, key=lambda z: (z.kind != "OB" or not z.swept, z.kind != "OB", -z.form_idx))[0]
        flags["ltf_entry"] = zone.kind; score += WEIGHTS["ltf_entry"]

    out = {"score": score, "flags": flags, "signal": None}
    if score <= threshold or zone is None:
        out["reason"] = "low_confluence"; return out

    entry = (zone.top + zone.bottom) / 2
    pad = 0.1 * L.atr
    sl = zone.bottom - pad if long else zone.top + pad
    risk = abs(entry - sl)
    levels = sorted({*M.swing_highs.values(), *H.swing_highs.values()} if long
                    else {*M.swing_lows.values(), *H.swing_lows.values()}, reverse=not long)
    tp = next((p for p in levels if (p > entry if long else p < entry)
               and abs(p - entry) / risk >= min_rr), None)
    if tp is None:
        out["reason"] = "no_target_rr"; return out

    out["signal"] = {
        "direction": "buy" if long else "sell",
        "entry": round(entry, 5), "entry_zone": [round(zone.bottom, 5), round(zone.top, 5)],
        "sl": round(sl, 5), "tp": round(tp, 5), "rr": round(abs(tp - entry) / risk, 2),
        "zone": {"kind": zone.kind, "side": zone.side, "top": zone.top, "bottom": zone.bottom,
                 "t0": _ts(ltf, zone.t0)},
    }
    return out
