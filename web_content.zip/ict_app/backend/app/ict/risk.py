"""Lot size calculator. value = account-currency P&L per 1.0 price move per 1 lot."""
SPECS = {
    "XAUUSD": {"value": 100.0,    "min_lot": 0.01, "step": 0.01},   # 100 oz
    "EURUSD": {"value": 100000.0, "min_lot": 0.01, "step": 0.01},
    "BTCUSD": {"value": 1.0,      "min_lot": 0.001, "step": 0.001},
    "NQ":     {"value": 20.0,     "min_lot": 1, "step": 1},         # $20/pt (E-mini)
    "ES":     {"value": 50.0,     "min_lot": 1, "step": 1},         # $50/pt (E-mini)
}

def lot_size(symbol: str, capital: float, risk_pct: float, entry: float, sl: float) -> dict:
    spec = SPECS[symbol]
    risk_amount = capital * risk_pct / 100.0
    dist = abs(entry - sl)
    raw = risk_amount / (dist * spec["value"]) if dist else 0.0
    step = spec["step"]
    lots = max(int(raw / step) * step, 0.0)
    return {"risk_amount": round(risk_amount, 2), "lots": round(lots, 3),
            "below_min_lot": lots < spec["min_lot"]}
