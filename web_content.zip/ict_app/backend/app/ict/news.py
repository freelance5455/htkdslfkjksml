"""High-impact news filter: block 30 min before .. 15 min after red-folder events."""
import time, datetime as dt, requests

FEED = "https://nfs.faireconomy.media/ff_calendar_thisweek.json"  # public ForexFactory mirror; swap if it changes
CCY = {"XAUUSD": {"USD"}, "EURUSD": {"USD", "EUR"}, "BTCUSD": {"USD"}, "NQ": {"USD"}, "ES": {"USD"}}
BEFORE, AFTER = dt.timedelta(minutes=30), dt.timedelta(minutes=15)
_cache = {"t": 0, "data": None}

def _events():
    if time.time() - _cache["t"] > 900:
        r = requests.get(FEED, timeout=8); r.raise_for_status()
        _cache.update(t=time.time(), data=r.json())
    return _cache["data"]

def check(symbol: str, now: dt.datetime | None = None) -> dict:
    now = now or dt.datetime.now(dt.timezone.utc)
    try:
        for e in _events():
            if e.get("impact") != "High" or e.get("country") not in CCY[symbol]:
                continue
            t = dt.datetime.fromisoformat(e["date"]).astimezone(dt.timezone.utc)
            if t - BEFORE <= now <= t + AFTER:
                return {"blocked": True, "event": e.get("title"), "time": t.isoformat(), "known": True}
        return {"blocked": False, "known": True}
    except Exception:
        return {"blocked": False, "known": False}   # feed down: warn, don't silently pass
