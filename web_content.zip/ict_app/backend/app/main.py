from fastapi import FastAPI, HTTPException
from .ict import data, mtf, news, risk

app = FastAPI(title="ICT Signals")

def rationale(flags, sig, news_info, lang_zone):
    d = sig["direction"]
    ar = [f"{'شراء' if d == 'buy' else 'بيع'}: الاتجاه العام على 4H {'صاعد' if d == 'buy' else 'هابط'}."]
    en = [f"{d.upper()}: 4H bias is {'bullish' if d == 'buy' else 'bearish'}."]
    if flags.get("htf_pd"):
        ar.append("السعر في منطقة " + ("الخصم (Discount)." if d == "buy" else "العلاوة (Premium)."))
        en.append("Price sits in " + ("discount." if d == "buy" else "premium."))
    if flags.get("sweep"):
        ar.append("حدث سحب سيولة " + ("قاع" if d == "buy" else "قمة") + " سابق.")
        en.append("Prior " + ("sellside" if d == "buy" else "buyside") + " liquidity was swept.")
    if flags.get("mid_structure"):
        ar.append(f"تأكيد {flags['mid_structure']} على 15m."); en.append(f"{flags['mid_structure']} confirmed on 15m.")
    ar.append(f"الدخول عند {lang_zone} على 5m، RR = 1:{sig['rr']}.")
    en.append(f"Entry at a 5m {lang_zone}, RR = 1:{sig['rr']}.")
    if news_info.get("known"):
        ar.append("لا أخبار قوية قريبة."); en.append("No high-impact news nearby.")
    else:
        ar.append("تعذر التحقق من الأخبار — تحقق يدوياً."); en.append("News feed unavailable — check manually.")
    return {"ar": " ".join(ar), "en": " ".join(en)}

@app.get("/analyze")
def analyze(symbol: str = "XAUUSD", capital: float = 1000, risk_pct: float = 1.0, demo: bool = False, seed: int = 0):
    if symbol not in risk.SPECS:
        raise HTTPException(400, "unknown symbol")
    htf, mid, ltf = data.load_demo(seed) if demo else data.load(symbol)
    candles = [{"time": int(t.timestamp()), "open": r.open, "high": r.high, "low": r.low, "close": r.close}
               for t, r in ltf.tail(250).iterrows()]
    n = news.check(symbol)
    res = mtf.generate_signal(htf, mid, ltf)
    res["candles"], res["news"] = candles, n
    sig = res["signal"]
    if n["blocked"]:
        res["signal"], res["reason"] = None, "news_block"
    elif sig:
        res["lot"] = risk.lot_size(symbol, capital, risk_pct, sig["entry"], sig["sl"])
        res["rationale"] = rationale(res["flags"], sig, n, sig["zone"]["kind"])
    return res
