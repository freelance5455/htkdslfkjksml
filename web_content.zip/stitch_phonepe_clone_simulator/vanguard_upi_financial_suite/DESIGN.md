---
name: Vanguard UPI & Financial Suite
colors:
  surface: '#13121b'
  surface-dim: '#13121b'
  surface-bright: '#3a3842'
  surface-container-lowest: '#0e0d16'
  surface-container-low: '#1c1a24'
  surface-container: '#201e28'
  surface-container-high: '#2a2933'
  surface-container-highest: '#35333e'
  on-surface: '#e5e0ee'
  on-surface-variant: '#ccc3d8'
  inverse-surface: '#e5e0ee'
  inverse-on-surface: '#312f39'
  outline: '#958da1'
  outline-variant: '#4a4455'
  surface-tint: '#d2bbff'
  primary: '#d2bbff'
  on-primary: '#3f008e'
  primary-container: '#7c3aed'
  on-primary-container: '#ede0ff'
  inverse-primary: '#732ee4'
  secondary: '#4cd7f6'
  on-secondary: '#003640'
  secondary-container: '#03b5d3'
  on-secondary-container: '#00424e'
  tertiary: '#4edea3'
  on-tertiary: '#003824'
  tertiary-container: '#007650'
  on-tertiary-container: '#76ffc2'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#eaddff'
  primary-fixed-dim: '#d2bbff'
  on-primary-fixed: '#25005a'
  on-primary-fixed-variant: '#5a00c6'
  secondary-fixed: '#acedff'
  secondary-fixed-dim: '#4cd7f6'
  on-secondary-fixed: '#001f26'
  on-secondary-fixed-variant: '#004e5c'
  tertiary-fixed: '#6ffbbe'
  tertiary-fixed-dim: '#4edea3'
  on-tertiary-fixed: '#002113'
  on-tertiary-fixed-variant: '#005236'
  background: '#13121b'
  on-background: '#e5e0ee'
  surface-variant: '#35333e'
typography:
  display-currency:
    fontFamily: Plus Jakarta Sans
    fontSize: 40px
    fontWeight: '800'
    lineHeight: 48px
    letterSpacing: -0.03em
  display-currency-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '800'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 30px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
  label-mono-lg:
    fontFamily: JetBrains Mono
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: -0.01em
  label-mono-sm:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-action:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  space-2xs: 0.25rem
  space-xs: 0.5rem
  space-sm: 0.75rem
  space-md: 1rem
  space-lg: 1.25rem
  space-xl: 1.5rem
  space-2xl: 2rem
  space-3xl: 2.5rem
  gutter-mobile: 1rem
  margin-mobile: 1rem
  screen-max-width: 480px
---

## Brand & Style

The visual identity embodies institutional security, instantaneous velocity, and refined consumer luxury tailored for modern Indian digital payments. It targets discerning mobile-first users managing high-frequency UPI transfers, split bills, multi-bank accounts, and wealth micro-investments.

The aesthetic fuses modern high-density corporate fintech with subdued dark glassmorphism. It leverages deep obsidian and imperial indigo-purple foundations balanced with crisp, luminous slate strokes and high-visibility status indicators. Key emotional pillars:
- **Absolute Trust:** Bank-grade verification signals, crisp biometric badges, structured transaction summaries, and verifiable audit trails.
- **Effortless Precision:** Instant recognition of VPA (Virtual Payment Address) tags, QR targeting reticles, structured numeric keypads, and clear monetary data hierarchy.
- **Refined Contemporary Edge:** Subtle backdrop-filtered surface tiers, tactile dark mode depth without visual noise, and glowing semantic accents that eliminate ambiguous transaction states.

## Colors

The palette is engineered specifically for dark surfaces to ensure strict AAA contrast ratings across variable outdoor ambient conditions and OLED displays.

### Palette Architecture
- **Primary (`#7C3AED` - Royal Electric Violet):** The operational core used for primary CTAs, active payment methods, dynamic focus rings, and UPI transfer confirmations.
- **Secondary (`#06B6D4` - Cyan Bright):** Secondary telemetry, QR targeting reticles, contactless NFC wave indicators, and auto-pay mandates.
- **Tertiary (`#10B981` - Emerald Settle):** Dedicated transaction settlement green, positive cash inflows, and certified NPCI / RBI compliance badges.
- **Neutral (`#0F0E17` - Obsidian Base):** Deep, warm violet-tinted black for primary surfaces, paired with layered slates for elevated cards and modals.

### Semantic Status Tokens
- **Success (`#10B981`):** "Payment Sent", "Money Added", "Bank Linked".
- **Pending / In Progress (`#F59E0B` - Deep Amber):** "Awaiting Bank Approval", "UPI Mandate Scheduled", "Processing at Clearing House".
- **Failure / Alert (`#EF4444` - Crimson Guard):** "VPA Invalid", "Insufficient Funds", "Transaction Expired".
- **Info / Neutral Alert (`#38BDF8` - Slate Sky):** "Daily UPI Limit Info", "Scheduled Maintenance".

### Surface & Border Hierarchy
- **Canvas Base:** `#0A0910`
- **Surface 01 (Card/Container):** `#141221` with `rgba(255, 255, 255, 0.05)` inset border.
- **Surface Glass (Elevated Overlays):** `rgba(26, 23, 44, 0.72)` with 20px blur and `rgba(167, 139, 250, 0.15)` border.
- **Text Primary:** `#F8FAFC`
- **Text Secondary:** `#94A3B8`
- **Text Muted / Currency Meta:** `#64748B`

## Typography

The type system prioritizes instantaneous parsing of financial records and dense balance displays. 

- **Primary Font (Plus Jakarta Sans):** Selected for its crisp geometric terminals, open apertures, and modern balance. Numbers and English currency descriptors render with clean baseline metrics without glyph collision.
- **Monospace Font (JetBrains Mono):** Dedicated to UPI Ref IDs, Bank UTR numbers, IFSC codes, masked account numbers (`•••• 4092`), and timestamps. This enforces spatial clarity and prevents reading errors during audit lookups.

### Rules & Applications
- **Currency Typography:** Indian Rupee amounts (`₹`) use tabular figures (`tnum`) wherever values sit in lists or ledger cards to prevent horizontal jitter during real-time balance polling.
- **VPA Format:** Handles and recipient IDs (`username@okaxis`, `merchant.upi`) adopt `label-mono-sm` with a secondary slate color to clearly differentiate user names from system addresses.

## Layout & Spacing

A mobile-first system constrained to a strict 4px grid. Primary views are contained within a responsive column bounded at `480px` maximum width to preserve optimal thumb reach and avoid oversized hit areas on foldables or tablets.

### Grid & Reach Zones
- **Columns:** 4-column system for mobile viewports with `16px` (`space-md`) external margins and `12px` (`space-sm`) gutters.
- **Bottom Navigation Clearance:** All scrollable content incorporates a minimum dynamic safe bottom inset of `88px` + system safe-area-inset to clear the floating frosted glass navigation bar.
- **Thumb Zone Anchor:** High-intent touchpoints (QR Scanner trigger, "Pay Now", Send Money CTA) are anchored within the bottom 35% of the viewport.

## Elevation & Depth

Visual hierarchy uses controlled luminosity layers and structural borders rather than heavy, muddy drop shadows. Dark backgrounds gain separation through translucent fills and spectral rim highlights.

### Elevation Levels
- **Level 0 (Canvas):** Pure `#0A0910` base canvas. No shadow.
- **Level 1 (Inline Surfaces & List Items):** `#141221` solid background with a hairline border: `1px solid rgba(255, 255, 255, 0.06)`.
- **Level 2 (Bank Cards & Primary Containers):** Linear gradient from `#1F1A3A` to `#131124`, bordered by `1px solid rgba(167, 139, 250, 0.18)`, ambient shadow: `0 8px 24px -4px rgba(0, 0, 0, 0.5)`.
- **Level 3 (Interactive Modals & Payment Sheets):** Backdrop blur of `24px` with surface fill `rgba(20, 18, 33, 0.85)` and top border `1px solid rgba(255, 255, 255, 0.12)`. Ambient glow: `0 16px 40px -8px rgba(124, 58, 237, 0.15)`.
- **Level 4 (Floating QR / Bottom Navigation Dock):** `rgba(15, 14, 23, 0.88)` with `backdrop-filter: blur(16px)`, enclosed by `1px solid rgba(255, 255, 255, 0.08)`, elevated by `0 10px 30px rgba(0, 0, 0, 0.6)`.

## Shapes

The geometric signature uses confident, structural curves (`roundedness: 2`). This translates to:
- **Base Components (Badges, Buttons, Inputs):** `0.5rem` (8px)
- **Cards, Account Containers, Receipts:** `1rem` (16px)
- **Modals, Action Sheets, Prominent Hero Surfaces:** `1.5rem` (24px)
- **Pills / Quick Filters / Biometric Tags:** Fully rounded pill (`9999px`) to visually separate transient status labels from persistent content surfaces.

## Components

### 1. Primary & Action Buttons
- **Primary ("Pay", "Authenticate"):** Full-width, `48px` or `56px` height. Solid `#7C3AED` fill, text `#FFFFFF` (`label-action`), corner radius `12px`. Hover/Active states trigger an electric purple glow `0 0 16px rgba(124, 58, 237, 0.5)`.
- **Secondary / Ghost ("Split Bill", "Share Receipt"):** `rgba(255, 255, 255, 0.05)` fill with `1px solid rgba(255, 255, 255, 0.12)` border. On press: `rgba(255, 255, 255, 0.09)`.

### 2. Bank Cards & Account Switcher
- **Visual Spec:** Ratio roughly 1.58:1 or stacked dynamic height card. Dark violet-to-slate gradient with a micro-grid wire texture overlay (`rgba(255, 255, 255, 0.02)`).
- **Elements:**
  - Bank Logo slot (top-right, `32x32px` rounded slate box).
  - Masked account identifier: `label-mono-lg` (`HDFC Bank •••• 8831`).
  - Primary UPI handle chip: `username@okhdfcbank` with a green shield verification tick.
  - Balance visibility toggle (`₹ ••••••` tap to reveal).

### 3. Transaction Receipts
- **Design Metaphor:** Digital ledger card with micro-perforation scalloped cutouts at the fold line.
- **Top Section:** Big numeric status (`+ ₹2,400.00` or `- ₹450.00`), followed immediately by the semantic state pill (e.g., green "Completed", amber "Processing").
- **Audit Detail Block:** JetBrains Mono key-value pairs for `UPI Ref ID`, `Bank Reference No`, and `Timestamp (IST)` with one-tap copy icons.

### 4. Status & Security Badges
- **NPCI / Verified Merchant Badge:** Pill style, `rgba(16, 185, 129, 0.12)` fill with `1px solid rgba(16, 185, 129, 0.35)` border. Green shield glyph + `11px` uppercase tracking.
- **Pending Mandate Badge:** Amber tint `rgba(245, 158, 11, 0.12)` with amber pulse dot for non-finalized states.

### 5. Input Fields & Amount Entry
- **Amount Field:** Zero-border transparent canvas, font `display-currency`, centered. Rupee prefix symbol `₹` locked at `#94A3B8` weight.
- **VPA / Phone Input:** `#141221` fill, `1px solid rgba(255, 255, 255, 0.12)`, height `52px`, `rounded-lg`. Focus state transitions to `1px solid #7C3AED` with an outer ring glow of `rgba(124, 58, 237, 0.2)`.

### 6. Bottom Navigation Dock
- **Architecture:** Floating dock suspended `16px` above the bottom screen boundary, with `16px` margins. Height `64px`.
- **Styling:** Frosted dark slate glass (`rgba(15, 14, 23, 0.88)` + `20px` blur).
- **QR Action Button:** Centered circular item (`52px` diameter) elevated `-18px` above the dock frame, saturated in `#7C3AED` with a high-contrast scanning reticle icon.