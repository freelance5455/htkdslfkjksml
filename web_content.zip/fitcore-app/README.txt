FITCORE GYM MANAGEMENT — PREVIEW BUILD

Files:
- index.html: responsive application UI and local demo logic
- manifest.json: installable PWA metadata
- sw.js: offline cache for static app files

Run locally:
1. Open index.html in a modern browser. Most functions work locally.
2. For install/offline service worker, serve this folder via localhost or HTTPS (e.g. `npx serve .`).
3. First launch lets you register the first local account as Owner. Maximum 10 local accounts.
4. Use Settings to configure Gemini API key (optional) and export JSON backup regularly.

IMPORTANT LIMITATIONS / PRODUCTION CHECKLIST:
- This is a local-first prototype, not a secure production app. Login credentials are stored in browser local storage and are NOT safe for real accounts.
- Google OAuth is a placeholder and does not authenticate users. Configure Google OAuth and verify tokens on a backend.
- User cap, role access, branch permissions and owner-only changes are client-side demo controls, not server-enforced security.
- Data does not sync between devices. Local storage can be cleared by browser/device; keep backups.
- Gemini key stored in browser is exposed to that browser. Use a server-side proxy for production.
- UPI payments are manual records only; no payment gateway verification or money transfer is integrated.
- Browser notifications, email/SMS/WhatsApp reminders, secure photo cloud storage, and real Excel XLSX workbook are not yet integrated. CSV files open in Excel.
- APK not included. Android APK requires Android SDK/Gradle build environment and packaging/configuration. This PWA can be opened in mobile browsers and installed where supported; it is not an iOS App Store package or signed Windows installer.
