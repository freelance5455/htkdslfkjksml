# SMAPS WebView bridge rules - no custom shrinking rules required.
