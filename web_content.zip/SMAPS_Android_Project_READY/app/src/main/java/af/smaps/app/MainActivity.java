package af.smaps.app;

import android.app.Activity;
import android.Manifest;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.content.pm.PackageManager;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.print.PageRange;
import android.print.PrintDocumentInfo;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.content.ContentValues;
import android.text.TextUtils;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import android.telephony.SmsManager;
import java.util.ArrayList;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final String APP_BASE_URL = "https://smaps.local/";
    private WebView webView;
    private boolean triedFallback = false;
    private static final int REQ_SEND_SMS = 4107;
    private String pendingSmsNumbers = null;
    private String pendingSmsBody = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(18, 59, 120));
        getWindow().setNavigationBarColor(Color.WHITE);

        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setAllowFileAccessFromFileURLs(true);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setSupportZoom(false);
        settings.setLoadWithOverviewMode(false);
        settings.setUseWideViewPort(false);
        settings.setMediaPlaybackRequiresUserGesture(true);
        settings.setDefaultTextEncodingName("utf-8");

        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return handleSpecialUrl(request.getUrl().toString());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return handleSpecialUrl(url);
            }

            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return serveLocalAsset(request.getUrl().toString());
            }

            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, String url) {
                return serveLocalAsset(url);
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request != null && request.isForMainFrame() && !triedFallback) {
                    triedFallback = true;
                    loadLocalIndex(true);
                }
            }
        });

        webView.addJavascriptInterface(new AndroidBridge(this), "AndroidBridge");
        webView.addJavascriptInterface(new PrintBridge(this), "AndroidPrint");
        webView.setBackgroundColor(Color.WHITE);

        loadLocalIndex(false);
    }

    private void loadLocalIndex(boolean retry) {
        triedFallback = retry;
        try (InputStream input = getAssets().open("index.html")) {
            byte[] bytes = readAll(input);
            String html = new String(bytes, StandardCharsets.UTF_8);
            // The web app is self-contained. Keep it offline and give it a stable local origin
            // so localStorage and other browser APIs continue to work inside the APK.
            webView.loadDataWithBaseURL(
                    APP_BASE_URL,
                    html,
                    "text/html",
                    "UTF-8",
                    APP_BASE_URL
            );
        } catch (IOException e) {
            String safe = escapeHtml("SMAPS د اپ دننه فایل لوستل کې ستونزه: " + e.getMessage());
            webView.loadDataWithBaseURL(APP_BASE_URL,
                    "<html><body dir='rtl' style='font-family:sans-serif;padding:24px'>"
                            + "<h2>SMAPS</h2><p>" + safe + "</p></body></html>",
                    "text/html", "UTF-8", APP_BASE_URL);
        }
    }

    private byte[] readAll(InputStream input) throws IOException {
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        byte[] buffer = new byte[8192];
        int count;
        while ((count = input.read(buffer)) != -1) {
            output.write(buffer, 0, count);
        }
        return output.toByteArray();
    }

    private WebResourceResponse serveLocalAsset(String url) {
        if (url == null || !url.startsWith(APP_BASE_URL)) return null;
        String path = url.substring(APP_BASE_URL.length());
        if (path.isEmpty() || path.contains("..")) return null;

        String mime = "text/plain";
        String lower = path.toLowerCase(Locale.ROOT);
        if (lower.endsWith(".json")) mime = "application/json";
        else if (lower.endsWith(".js")) mime = "application/javascript";
        else if (lower.endsWith(".css")) mime = "text/css";
        else if (lower.endsWith(".svg")) mime = "image/svg+xml";
        else if (lower.endsWith(".png")) mime = "image/png";
        else if (lower.endsWith(".jpg") || lower.endsWith(".jpeg")) mime = "image/jpeg";
        else if (lower.endsWith(".webp")) mime = "image/webp";

        try {
            InputStream input = getAssets().open(path);
            return new WebResourceResponse(mime, "UTF-8", input);
        } catch (IOException ignored) {
            return null;
        }
    }

    private String escapeHtml(String value) {
        return value.replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace("\"", "&quot;");
    }

    private boolean handleSpecialUrl(String url) {
        if (url == null) return false;
        if (url.startsWith("sms:") || url.startsWith("smsto:")) {
            try {
                Intent intent = new Intent(Intent.ACTION_SENDTO, Uri.parse(url));
                startActivity(intent);
            } catch (ActivityNotFoundException e) {
                Toast.makeText(this, "په موبایل کې SMS اپ ونه موندل شو.", Toast.LENGTH_LONG).show();
            }
            return true;
        }
        if (url.startsWith(APP_BASE_URL) || url.startsWith("about:")) {
            return false;
        }
        if (url.startsWith("http://") || url.startsWith("https://")) {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                return true;
            } catch (ActivityNotFoundException ignored) { }
        }
        return false;
    }

    public void openSms(String number, String body) {
        String cleanNumber = number == null ? "" : number.trim();
        Intent intent = new Intent(Intent.ACTION_SENDTO);
        intent.setData(Uri.parse("smsto:" + Uri.encode(cleanNumber)));
        intent.putExtra("sms_body", body == null ? "" : body);
        try {
            startActivity(intent);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "په موبایل کې SMS اپ ونه موندل شو.", Toast.LENGTH_LONG).show();
        }
    }

    public void openBulkSms(String numbers, String body) {
        String raw = numbers == null ? "" : numbers;
        String[] parts = raw.split("[,;\\s]+");
        ArrayList<String> cleaned = new ArrayList<>();
        java.util.HashSet<String> seen = new java.util.HashSet<>();
        for (String part : parts) {
            String number = part == null ? "" : part.trim();
            if (!number.isEmpty() && seen.add(number)) cleaned.add(number);
        }
        if (cleaned.isEmpty()) {
            Toast.makeText(this, "د SMS لپاره د ولي/پلار شمېره نشته.", Toast.LENGTH_LONG).show();
            return;
        }

        // Send directly through the phone SIM so every recipient is handled individually.
        // This avoids Android Messages' small multi-recipient composer limit.
        if (android.os.Build.VERSION.SDK_INT >= 23 &&
                checkSelfPermission(Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            pendingSmsNumbers = TextUtils.join(",", cleaned);
            pendingSmsBody = body == null ? "" : body;
            requestPermissions(new String[]{Manifest.permission.SEND_SMS}, REQ_SEND_SMS);
            return;
        }
        sendBulkSmsDirect(cleaned, body == null ? "" : body);
    }

    private void sendBulkSmsDirect(ArrayList<String> numbers, String body) {
        try {
            SmsManager smsManager = SmsManager.getDefault();
            int sent = 0;
            for (String number : numbers) {
                if (number == null || number.trim().isEmpty()) continue;
                ArrayList<String> parts = smsManager.divideMessage(body);
                ArrayList<android.app.PendingIntent> sentIntents = new ArrayList<>();
                ArrayList<android.app.PendingIntent> deliveryIntents = new ArrayList<>();
                if (parts.size() == 1) {
                    smsManager.sendTextMessage(number, null, body, null, null);
                } else {
                    smsManager.sendMultipartTextMessage(number, null, parts, sentIntents, deliveryIntents);
                }
                sent++;
            }
            Toast.makeText(this,
                    "SMS ټولو " + sent + " والدینو ته د موبایل SIM له لارې واستول شول.",
                    Toast.LENGTH_LONG).show();
        } catch (SecurityException e) {
            Toast.makeText(this, "د SMS اجازه نشته. مهرباني وکړئ اجازه ورکړئ.", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "د SMS لېږلو پر مهال ستونزه رامنځته شوه: " + e.getMessage(),
                    Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_SEND_SMS) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                ArrayList<String> list = new ArrayList<>();
                if (pendingSmsNumbers != null) {
                    for (String n : pendingSmsNumbers.split(",")) {
                        if (n != null && !n.trim().isEmpty()) list.add(n.trim());
                    }
                }
                String body = pendingSmsBody == null ? "" : pendingSmsBody;
                pendingSmsNumbers = null;
                pendingSmsBody = null;
                sendBulkSmsDirect(list, body);
            } else {
                pendingSmsNumbers = null;
                pendingSmsBody = null;
                Toast.makeText(this, "د SMS اجازه رد شوه؛ پیغامونه ونه لېږل شول.", Toast.LENGTH_LONG).show();
            }
        }
    }

    public void printWebPage() {
        runOnUiThread(() -> {
            if (webView == null) {
                Toast.makeText(this, "د راپور پاڼه چمتو نه ده.", Toast.LENGTH_LONG).show();
                return;
            }
            PrintManager printManager = (PrintManager) getSystemService(Context.PRINT_SERVICE);
            if (printManager == null) {
                Toast.makeText(this, "د چاپ خدمت فعال نه دی؛ PDF جوړېږي...", Toast.LENGTH_LONG).show();
                saveWebPageAsPdf();
                return;
            }
            try {
                // Give the WebView a moment to finish the report DOM/layout before Android captures it.
                webView.postDelayed(() -> {
                    try {
                        PrintDocumentAdapter adapter = webView.createPrintDocumentAdapter("SMAPS راپور");
                        PrintAttributes attrs = new PrintAttributes.Builder()
                                .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                                .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                                .build();
                        printManager.print("SMAPS راپور", adapter, attrs);
                    } catch (Exception e) {
                        Toast.makeText(this, "د چاپ پرانیستل ونه شول: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    }
                }, 700);
            } catch (Exception e) {
                Toast.makeText(this, "د چاپ ستونزه: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }

    public void saveWebPageAsPdf() {
        runOnUiThread(() -> {
            if (webView == null) {
                Toast.makeText(this, "د راپور پاڼه چمتو نه ده.", Toast.LENGTH_LONG).show();
                return;
            }
            webView.postDelayed(() -> {
                Uri outputUri = null;
                ParcelFileDescriptor pfd = null;
                try {
                    final String fileName = "SMAPS_Report_" + new java.text.SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new java.util.Date()) + ".pdf";
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        ContentValues values = new ContentValues();
                        values.put(MediaStore.Downloads.DISPLAY_NAME, fileName);
                        values.put(MediaStore.Downloads.MIME_TYPE, "application/pdf");
                        values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/SMAPS Reports");
                        values.put(MediaStore.Downloads.IS_PENDING, 1);
                        outputUri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                        if (outputUri == null) throw new IOException("PDF فایل جوړ نه شو");
                        pfd = getContentResolver().openFileDescriptor(outputUri, "w");
                    } else {
                        java.io.File dir = new java.io.File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "SMAPS Reports");
                        if (!dir.exists() && !dir.mkdirs()) throw new IOException("د PDF فولډر جوړ نه شو");
                        java.io.File file = new java.io.File(dir, fileName);
                        outputUri = Uri.fromFile(file);
                        pfd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_CREATE | ParcelFileDescriptor.MODE_TRUNCATE | ParcelFileDescriptor.MODE_READ_WRITE);
                    }
                    if (pfd == null) throw new IOException("PDF فایل پرانیستل نه شو");

                    PrintDocumentAdapter adapter = webView.createPrintDocumentAdapter("SMAPS راپور");
                    PrintAttributes attrs = new PrintAttributes.Builder()
                            .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                            .setResolution(new PrintAttributes.Resolution("smaps", "SMAPS PDF", 300, 300))
                            .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                            .build();
                    final ParcelFileDescriptor finalPfd = pfd;
                    final Uri finalUri = outputUri;
                    adapter.onLayout(null, attrs, new CancellationSignal(), new PrintDocumentAdapter.LayoutResultCallback() {
                        @Override public void onLayoutFinished(PrintDocumentInfo info, boolean changed) {
                            try {
                                adapter.onWrite(new PageRange[]{PageRange.ALL_PAGES}, finalPfd, new CancellationSignal(), new PrintDocumentAdapter.WriteResultCallback() {
                                    @Override public void onWriteFinished(PageRange[] pages) {
                                        try {
                                            finalPfd.close();
                                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                                                ContentValues done = new ContentValues();
                                                done.put(MediaStore.Downloads.IS_PENDING, 0);
                                                getContentResolver().update(finalUri, done, null, null);
                                            }
                                            Toast.makeText(MainActivity.this, "PDF خوندي شو: Downloads/SMAPS Reports", Toast.LENGTH_LONG).show();
                                        } catch (Exception e) {
                                            Toast.makeText(MainActivity.this, "PDF خوندي نه شو: " + e.getMessage(), Toast.LENGTH_LONG).show();
                                        }
                                    }
                                    @Override public void onWriteFailed(CharSequence error) {
                                        try { finalPfd.close(); } catch (Exception ignored) {}
                                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) getContentResolver().delete(finalUri, null, null);
                                        Toast.makeText(MainActivity.this, "PDF جوړ نه شو: " + error, Toast.LENGTH_LONG).show();
                                    }
                                });
                            } catch (Exception e) {
                                try { finalPfd.close(); } catch (Exception ignored) {}
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) getContentResolver().delete(finalUri, null, null);
                                Toast.makeText(MainActivity.this, "PDF جوړ نه شو: " + e.getMessage(), Toast.LENGTH_LONG).show();
                            }
                        }
                        @Override public void onLayoutFailed(CharSequence error) {
                            try { finalPfd.close(); } catch (Exception ignored) {}
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) getContentResolver().delete(finalUri, null, null);
                            Toast.makeText(MainActivity.this, "PDF جوړ نه شو: " + error, Toast.LENGTH_LONG).show();
                        }
                    }, null);
                } catch (Exception e) {
                    if (pfd != null) try { pfd.close(); } catch (Exception ignored) {}
                    if (outputUri != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) getContentResolver().delete(outputUri, null, null);
                    Toast.makeText(this, "PDF جوړولو ستونزه: " + e.getMessage(), Toast.LENGTH_LONG).show();
                }
            }, 700);
        });
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    public static class AndroidBridge {
        private final MainActivity activity;
        AndroidBridge(MainActivity activity) { this.activity = activity; }

        @JavascriptInterface
        public void openSms(final String number, final String body) {
            activity.runOnUiThread(() -> activity.openSms(number, body));
        }

        @JavascriptInterface
        public void openBulkSms(final String numbers, final String body) {
            activity.runOnUiThread(() -> activity.openBulkSms(numbers, body));
        }
    }

    public static class PrintBridge {
        private final MainActivity activity;
        PrintBridge(MainActivity activity) { this.activity = activity; }

        @JavascriptInterface
        public void printPage() {
            activity.printWebPage();
        }

        @JavascriptInterface
        public void savePdf() {
            activity.saveWebPageAsPdf();
        }
    }
}
