159 REPORTS - versione HTML per HTML to APK

IMPORTANTE: caricare questo ZIP nell'app HTML to APK e indicare:
Index file: index.html

La cartella index.html deve restare nella root dello ZIP.

La versione salva i dati localmente tramite localStorage del WebView.
Include la foto reale della 159 in images/.
