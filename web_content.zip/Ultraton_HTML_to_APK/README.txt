Ultraton by Divyansh - HTML to APK package

Import this ZIP into HTML to APK Builder.
The main app file is index.html.

Note: This packages the web app in an Android WebView. The on-device AI model may not work if the app's WebView does not support WebGPU. The app may also need internet access to download the model the first time.
