"use strict";

/* =========================================================
   SNAKE WILD V5
   100 % HORS CONNEXION
   AUCUNE VIBRATION
   ========================================================= */


/* ================= CANVAS ================= */

const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

const W = canvas.width;
const H = canvas.height;

const CELL = 20;
const COLS = W / CELL;
const ROWS = H / CELL;


/* ================= INTERFACE ================= */

const menu = document.getElementById("menu");
const gameScreen = document.getElementById("gameScreen");
const gameOver = document.getElementById("gameOver");
const pauseScreen = document.getElementById("pauseScreen");

const worldList = document.getElementById("worldList");

const startBtn = document.getElementById("startBtn");
const restartBtn = document.getElementById("restartBtn");
const homeBtn = document.getElementById("homeBtn");

const playAgainBtn = document.getElementById("playAgainBtn");
const gameOverHomeBtn = document.getElementById("gameOverHomeBtn");

const pauseBtn = document.getElementById("pauseBtn");
const resumeBtn = document.getElementById("resumeBtn");

const scoreElement = document.getElementById("score");
const highScoreElement = document.getElementById("highScore");

const finalScoreElement = document.getElementById("finalScore");
const finalHighScoreElement =
    document.getElementById("finalHighScore");

const unlockMessage =
    document.getElementById("unlockMessage");

const worldNameElement =
    document.getElementById("worldName");

const worldIconElement =
    document.getElementById("worldIcon");

const powerFill =
    document.getElementById("powerFill");

const music = document.getElementById("backgroundMusic");
const musicBtn = document.getElementById("musicBtn");
const volumeSlider = document.getElementById("volumeSlider");


/* ================= MONDES ================= */

const worlds = [

    {
        id: 0,
        name: "Jungle",
        icon: "🌴",
        difficulty: "Facile",
        unlock: 0,
        speed: 145,
        obstacleCount: 7,
        type: "jungle"
    },

    {
        id: 1,
        name: "Désert",
        icon: "🏜️",
        difficulty: "Normal",
        unlock: 10,
        speed: 130,
        obstacleCount: 10,
        type: "desert"
    },

    {
        id: 2,
        name: "Volcan",
        icon: "🌋",
        difficulty: "Difficile",
        unlock: 20,
        speed: 112,
        obstacleCount: 13,
        type: "volcano"
    },

    {
        id: 3,
        name: "Glacier",
        icon: "🧊",
        difficulty: "Très difficile",
        unlock: 35,
        speed: 98,
        obstacleCount: 15,
        type: "glacier"
    },

    {
        id: 4,
        name: "Espace",
        icon: "🌌",
        difficulty: "Extrême",
        unlock: 50,
        speed: 85,
        obstacleCount: 18,
        type: "space"
    },

    {
        id: 5,
        name: "Donjon",
        icon: "🏰",
        difficulty: "Légendaire",
        unlock: 70,
        speed: 78,
        obstacleCount: 22,
        type: "dungeon"
    }

];


/* ================= VARIABLES ================= */

let selectedWorld = 0;

let snake = [];
let direction = { x: 1, y: 0 };
let nextDirection = { x: 1, y: 0 };

let food = null;
let bonus = null;

let obstacles = [];

let score = 0;

let highScore =
    Number(localStorage.getItem("snakeWildHighScore")) || 0;

let gameTimer = null;

let running = false;
let paused = false;

let power = 0;

let animationId = null;

let particles = [];


/* ================= MUSIQUE ================= */

let musicEnabled =
    localStorage.getItem("snakeWildMusic") !== "off";

music.volume = 0.5;

function updateMusicButton() {

    musicBtn.textContent =
        musicEnabled
            ? "🎵 MUSIQUE ON"
            : "🔇 MUSIQUE OFF";
}

updateMusicButton();


function startMusic() {

    if (!musicEnabled) return;

    music.play().catch(() => {
        /*
          Android peut bloquer la musique
          jusqu'à une interaction.
        */
    });
}


function stopMusic() {

    music.pause();
    music.currentTime = 0;
}


musicBtn.addEventListener("click", () => {

    musicEnabled = !musicEnabled;

    localStorage.setItem(
        "snakeWildMusic",
        musicEnabled ? "on" : "off"
    );

    updateMusicButton();

    if (musicEnabled) {
        startMusic();
    } else {
        stopMusic();
    }

});


volumeSlider.addEventListener("input", () => {

    music.volume =
        Number(volumeSlider.value) / 100;

});


/* ================= SON AVEC WEB AUDIO ================= */

let audioContext = null;

function initAudio() {

    if (!audioContext) {

        const AudioCtx =
            window.AudioContext ||
            window.webkitAudioContext;

        if (AudioCtx) {
            audioContext = new AudioCtx();
        }
    }

    if (
        audioContext &&
        audioContext.state === "suspended"
    ) {
        audioContext.resume();
    }
}


function sound(
    frequency,
    duration,
    type = "sine",
    volume = 0.05
) {

    if (!audioContext) return;

    const oscillator =
        audioContext.createOscillator();

    const gain =
        audioContext.createGain();

    oscillator.type = type;
    oscillator.frequency.value = frequency;

    gain.gain.setValueAtTime(
        volume,
        audioContext.currentTime
    );

    gain.gain.exponentialRampToValueAtTime(
        0.001,
        audioContext.currentTime + duration
    );

    oscillator.connect(gain);
    gain.connect(audioContext.destination);

    oscillator.start();

    oscillator.stop(
        audioContext.currentTime + duration
    );
}


function eatSound() {

    sound(550, 0.08, "square", 0.05);

    setTimeout(() => {
        sound(750, 0.08, "square", 0.04);
    }, 60);

}


function bonusSound() {

    sound(500, 0.1, "sine", 0.06);

    setTimeout(() => {
        sound(750, 0.1, "sine", 0.06);
    }, 80);

    setTimeout(() => {
        sound(1000, 0.15, "sine", 0.06);
    }, 160);

}


function gameOverSound() {

    sound(260, 0.2, "sawtooth", 0.07);

    setTimeout(() => {
        sound(150, 0.35, "sawtooth", 0.06);
    }, 160);

}


/* ================= MONDES ================= */

function isUnlocked(world) {

    return highScore >= world.unlock;

}


function renderWorlds() {

    worldList.innerHTML = "";

    worlds.forEach((world, index) => {

        const button =
            document.createElement("button");

        button.className = "world-button";

        if (index === selectedWorld) {
            button.classList.add("selected");
        }

        const unlocked =
            isUnlocked(world);

        button.innerHTML = `
            <span class="world-icon">
                ${world.icon}
            </span>

            <span class="world-name">
                ${world.name}
            </span>

            <span class="world-difficulty">
                ${unlocked
                    ? world.difficulty
                    : "Score " + world.unlock
                }
            </span>

            ${
                unlocked
                    ? ""
                    : '<span class="lock">🔒</span>'
            }
        `;

        button.addEventListener("click", () => {

            if (!unlocked) {

                initAudio();

                sound(
                    160,
                    0.15,
                    "square",
                    0.04
                );

                return;
            }

            selectedWorld = index;

            renderWorlds();

        });

        worldList.appendChild(button);

    });

}


renderWorlds();


/* ================= POSITION ================= */

function samePosition(a, b) {

    return (
        a &&
        b &&
        a.x === b.x &&
        a.y === b.y
    );

}


function positionIsFree(pos) {

    if (!pos) return false;

    for (const part of snake) {

        if (samePosition(pos, part)) {
            return false;
        }

    }

    for (const obstacle of obstacles) {

        if (samePosition(pos, obstacle)) {
            return false;
        }

    }

    if (samePosition(pos, food)) {
        return false;
    }

    if (samePosition(pos, bonus)) {
        return false;
    }

    return true;

}


function randomFreePosition() {

    for (let i = 0; i < 500; i++) {

        const position = {

            x: Math.floor(Math.random() * COLS),
            y: Math.floor(Math.random() * ROWS)

        };

        if (positionIsFree(position)) {
            return position;
        }

    }

    return {
        x: COLS - 2,
        y: ROWS - 2
    };

}


/* ================= OBSTACLES ================= */

function createObstacles() {

    obstacles = [];

    const world = worlds[selectedWorld];

    let attempts = 0;

    while (
        obstacles.length <
            world.obstacleCount &&
        attempts < 3000
    ) {

        attempts++;

        const position = {

            x: Math.floor(Math.random() * COLS),
            y: Math.floor(Math.random() * ROWS)

        };

        /*
          Zone de départ protégée.
        */

        if (
            position.x >= 10 &&
            position.x <= 18 &&
            position.y >= 13 &&
            position.y <= 17
        ) {
            continue;
        }

        if (!positionIsFree(position)) {
            continue;
        }

        obstacles.push(position);

    }

}


/* ================= NOURRITURE ================= */

function createFood() {

    food = randomFreePosition();

}


function createBonus() {

    if (Math.random() > 0.30) {

        bonus = null;
        return;

    }

    bonus = randomFreePosition();

}


/* ================= DÉMARRAGE ================= */

function startGame() {

    initAudio();

    clearInterval(gameTimer);

    const world = worlds[selectedWorld];

    snake = [

        { x: 14, y: 15 },
        { x: 13, y: 15 },
        { x: 12, y: 15 },
        { x: 11, y: 15 }

    ];

    direction = {
        x: 1,
        y: 0
    };

    nextDirection = {
        x: 1,
        y: 0
    };

    score = 0;
    power = 0;

    bonus = null;

    paused = false;
    running = true;

    particles = [];

    createObstacles();
    createFood();

    updateInterface();

    menu.classList.remove("active");
    gameOver.classList.remove("active");
    pauseScreen.classList.remove("active");

    gameScreen.classList.add("active");

    startMusic();

    draw();

    gameTimer =
        setInterval(
            update,
            world.speed
        );

}


startBtn.addEventListener(
    "click",
    startGame
);

restartBtn.addEventListener(
    "click",
    startGame
);

playAgainBtn.addEventListener(
    "click",
    startGame
);


/* ================= MOUVEMENT ================= */

function changeDirection(x, y) {

    /*
      Empêche le serpent de faire demi-tour.
    */

    if (
        direction.x === -x &&
        direction.y === -y
    ) {
        return;
    }

    nextDirection = {
        x: x,
        y: y
    };

}


document
    .querySelectorAll("[data-direction]")
    .forEach(button => {

        button.addEventListener(
            "pointerdown",
            event => {

                event.preventDefault();

                const d =
                    button.dataset.direction;

                if (d === "up") {
                    changeDirection(0, -1);
                }

                if (d === "down") {
                    changeDirection(0, 1);
                }

                if (d === "left") {
                    changeDirection(-1, 0);
                }

                if (d === "right") {
                    changeDirection(1, 0);
                }

            }
        );

    });


document.addEventListener(
    "keydown",
    event => {

        if (!running) return;

        if (event.key === "ArrowUp") {
            changeDirection(0, -1);
        }

        if (event.key === "ArrowDown") {
            changeDirection(0, 1);
        }

        if (event.key === "ArrowLeft") {
            changeDirection(-1, 0);
        }

        if (event.key === "ArrowRight") {
            changeDirection(1, 0);
        }

        if (event.key === " ") {
            togglePause();
        }

    }
);


/* ================= SWIPE ================= */

let touchStartX = 0;
let touchStartY = 0;

canvas.addEventListener(
    "touchstart",
    event => {

        const touch =
            event.changedTouches[0];

        touchStartX = touch.clientX;
        touchStartY = touch.clientY;

    },
    { passive: true }
);


canvas.addEventListener(
    "touchend",
    event => {

        const touch =
            event.changedTouches[0];

        const dx =
            touch.clientX - touchStartX;

        const dy =
            touch.clientY - touchStartY;

        const distance =
            Math.max(
                Math.abs(dx),
                Math.abs(dy)
            );

        if (distance < 25) return;

        if (Math.abs(dx) > Math.abs(dy)) {

            if (dx > 0) {
                changeDirection(1, 0);
            } else {
                changeDirection(-1, 0);
            }

        } else {

            if (dy > 0) {
                changeDirection(0, 1);
            } else {
                changeDirection(0, -1);
            }

        }

    },
    { passive: true }
);


/* ================= MISE À JOUR ================= */

function update() {

    if (!running || paused) return;

    direction = {
        ...nextDirection
    };

    const head = snake[0];

    const newHead = {

        x: head.x + direction.x,
        y: head.y + direction.y

    };


    /* COLLISION MURS */

    if (
        newHead.x < 0 ||
        newHead.x >= COLS ||
        newHead.y < 0 ||
        newHead.y >= ROWS
    ) {

        endGame();
        return;

    }


    /* COLLISION OBSTACLES */

    for (const obstacle of obstacles) {

        if (
            samePosition(
                newHead,
                obstacle
            )
        ) {

            endGame();
            return;

        }

    }


    /* COLLISION CORPS */

    for (
        let i = 0;
        i < snake.length - 1;
        i++
    ) {

        if (
            samePosition(
                newHead,
                snake[i]
            )
        ) {

            endGame();
            return;

        }

    }


    snake.unshift(newHead);


    /* NOURRITURE */

    if (
        samePosition(
            newHead,
            food
        )
    ) {

        score++;

        power =
            Math.min(
                100,
                power + 10
            );

        eatSound();

        createFood();

        if (Math.random() < 0.30) {
            createBonus();
        }

        createEatParticles(
            newHead.x,
            newHead.y
        );

    } else {

        snake.pop();

    }


    /* BONUS */

    if (
        bonus &&
        samePosition(
            newHead,
            bonus
        )
    ) {

        score += 3;

        power =
            Math.min(
                100,
                power + 25
            );

        bonusSound();

        createBonusParticles(
            newHead.x,
            newHead.y
        );

        bonus = null;

    }


    /*
      Le score accélère progressivement
      légèrement le jeu.
    */

    const world = worlds[selectedWorld];

    const speed =
        Math.max(
            48,
            world.speed -
            Math.floor(score / 5) * 3
        );

    clearInterval(gameTimer);

    gameTimer =
        setInterval(
            update,
            speed
        );


    power =
        Math.max(
            0,
            power - 0.4
        );

    updateInterface();

}


/* ================= INTERFACE ================= */

function updateInterface() {

    scoreElement.textContent = score;

    highScoreElement.textContent =
        highScore;

    powerFill.style.width =
        power + "%";

    const world =
        worlds[selectedWorld];

    worldNameElement.textContent =
        world.name;

    worldIconElement.textContent =
        world.icon;

}


/* ================= FIN DE PARTIE ================= */

function endGame() {

    running = false;

    clearInterval(gameTimer);

    gameOverSound();

    let newRecord = false;

    if (score > highScore) {

        highScore = score;

        localStorage.setItem(
            "snakeWildHighScore",
            highScore
        );

        newRecord = true;

    }


    finalScoreElement.textContent =
        score;

    finalHighScoreElement.textContent =
        highScore;


    if (newRecord) {

        unlockMessage.textContent =
            "🏆 NOUVEAU RECORD !";

    } else {

        const next =
            getNextLockedWorld();

        if (next) {

            const remaining =
                next.unlock - highScore;

            unlockMessage.textContent =
                "🔒 " +
                next.name +
                " : encore " +
                remaining +
                " point(s) pour débloquer.";

        } else {

            unlockMessage.textContent =
                "👑 TOUS LES MONDES SONT DÉBLOQUÉS !";

        }

    }


    renderWorlds();

    gameOver.classList.add("active");

}


function getNextLockedWorld() {

    for (const world of worlds) {

        if (highScore < world.unlock) {
            return world;
        }

    }

    return null;

}


/* ================= PAUSE ================= */

function togglePause() {

    if (!running) return;

    paused = !paused;

    if (paused) {

        pauseScreen.classList.add(
            "active"
        );

    } else {

        pauseScreen.classList.remove(
            "active"
        );

    }

}


pauseBtn.addEventListener(
    "click",
    togglePause
);

resumeBtn.addEventListener(
    "click",
    togglePause
);


/* ================= MENU ================= */

function goHome() {

    running = false;

    paused = false;

    clearInterval(gameTimer);

    stopMusic();

    gameScreen.classList.remove(
        "active"
    );

    gameOver.classList.remove(
        "active"
    );

    pauseScreen.classList.remove(
        "active"
    );

    menu.classList.add("active");

    renderWorlds();

}


homeBtn.addEventListener(
    "click",
    goHome
);

gameOverHomeBtn.addEventListener(
    "click",
    goHome
);


/* =========================================================
   RENDU DU MONDE
   ========================================================= */

function draw() {

    drawBackground();

    drawObstacles();

    drawFood();

    drawBonus();

    drawSnake();

    updateParticles();

    drawParticles();

    /*
      Animation continue du décor.
    */

    if (running) {

        animationId =
            requestAnimationFrame(draw);

    }

}


/* ================= FOND ================= */

function drawBackground() {

    const world =
        worlds[selectedWorld];

    const gradient =
        ctx.createLinearGradient(
            0,
            0,
            0,
            H
        );


    if (world.type === "jungle") {

        gradient.addColorStop(
            0,
            "#193d27"
        );

        gradient.addColorStop(
            0.5,
            "#10291b"
        );

        gradient.addColorStop(
            1,
            "#07130c"
        );

    }


    if (world.type === "desert") {

        gradient.addColorStop(
            0,
            "#e6b96c"
        );

        gradient.addColorStop(
            0.55,
            "#c98b3e"
        );

        gradient.addColorStop(
            1,
            "#70451f"
        );

    }


    if (world.type === "volcano") {

        gradient.addColorStop(
            0,
            "#331514"
        );

        gradient.addColorStop(
            0.5,
            "#180b0a"
        );

        gradient.addColorStop(
            1,
            "#070303"
        );

    }


    if (world.type === "glacier") {

        gradient.addColorStop(
            0,
            "#c8efff"
        );

        gradient.addColorStop(
            0.5,
            "#5ba6c9"
        );

        gradient.addColorStop(
            1,
            "#153a59"
        );

    }


    if (world.type === "space") {

        gradient.addColorStop(
            0,
            "#090d2b"
        );

        gradient.addColorStop(
            0.5,
            "#040719"
        );

        gradient.addColorStop(
            1,
            "#010207"
        );

    }


    if (world.type === "dungeon") {

        gradient.addColorStop(
            0,
            "#34302b"
        );

        gradient.addColorStop(
            0.5,
            "#1a1715"
        );

        gradient.addColorStop(
            1,
            "#080706"
        );

    }


    ctx.fillStyle = gradient;

    ctx.fillRect(
        0,
        0,
        W,
        H
    );


    drawWorldDetails(
        world.type
    );


    /* grille discrète */

    ctx.strokeStyle =
        "rgba(255,255,255,0.035)";

    ctx.lineWidth = 1;

    for (
        let x = 0;
        x <= W;
        x += CELL
    ) {

        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, H);
        ctx.stroke();

    }

    for (
        let y = 0;
        y <= H;
        y += CELL
    ) {

        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(W, y);
        ctx.stroke();

    }

}


/* ================= DÉTAILS DES MONDES ================= */

function drawWorldDetails(type) {

    if (type === "jungle") {

        drawJungleDetails();

    }

    if (type === "desert") {

        drawDesertDetails();

    }

    if (type === "volcano") {

        drawVolcanoDetails();

    }

    if (type === "glacier") {

        drawGlacierDetails();

    }

    if (type === "space") {

        drawSpaceDetails();

    }

    if (type === "dungeon") {

        drawDungeonDetails();

    }

}


/* ================= JUNGLE ================= */

function drawJungleDetails() {

    /*
      Feuilles et plantes.
    */

    for (let i = 0; i < 30; i++) {

        const x =
            (i * 83) % W;

        const y =
            (i * 137) % H;

        ctx.fillStyle =
            "rgba(55,130,55,0.20)";

        ctx.beginPath();

        ctx.ellipse(
            x,
            y,
            18,
            8,
            i,
            0,
            Math.PI * 2
        );

        ctx.fill();

    }


    /* rayons de lumière */

    ctx.fillStyle =
        "rgba(150,255,150,0.035)";

    ctx.beginPath();

    ctx.moveTo(70, 0);
    ctx.lineTo(220, 0);
    ctx.lineTo(400, H);
    ctx.lineTo(300, H);

    ctx.closePath();
    ctx.fill();

}


/* ================= DÉSERT ================= */

function drawDesertDetails() {

    /* dunes */

    for (let i = 0; i < 5; i++) {

        ctx.strokeStyle =
            "rgba(255,220,140,0.18)";

        ctx.lineWidth = 15;

        ctx.beginPath();

        ctx.moveTo(
            0,
            80 + i * 115
        );

        ctx.bezierCurveTo(
            160,
            10 + i * 115,
            350,
            150 + i * 115,
            W,
            60 + i * 115
        );

        ctx.stroke();

    }


    /* soleil */

    const gradient =
        ctx.createRadialGradient(
            500,
            70,
            5,
            500,
            70,
            80
        );

    gradient.addColorStop(
        0,
        "rgba(255,245,180,0.6)"
    );

    gradient.addColorStop(
        1,
        "rgba(255,245,180,0)"
    );

    ctx.fillStyle = gradient;

    ctx.fillRect(
        420,
        0,
        160,
        160
    );

}


/* ================= VOLCAN ================= */

function drawVolcanoDetails() {

    /* coulées de lave */

    ctx.strokeStyle =
        "rgba(255,75,20,0.25)";

    ctx.lineWidth = 7;

    for (let i = 0; i < 5; i++) {

        ctx.beginPath();

        ctx.moveTo(
            i * 140,
            0
        );

        ctx.bezierCurveTo(
            i * 140 + 40,
            150,
            i * 140 - 30,
            300,
            i * 140 + 60,
            H
        );

        ctx.stroke();

    }


    /* braises */

    for (let i = 0; i < 35; i++) {

        const x =
            (i * 97) % W;

        const y =
            (i * 61) % H;

        ctx.fillStyle =
            "rgba(255,100,30,0.35)";

        ctx.beginPath();

        ctx.arc(
            x,
            y,
            1.5,
            0,
            Math.PI * 2
        );

        ctx.fill();

    }

}


/* ================= GLACIER ================= */

function drawGlacierDetails() {

    /* montagnes */

    ctx.fillStyle =
        "rgba(235,250,255,0.28)";

    ctx.beginPath();

    ctx.moveTo(0, 230);
    ctx.lineTo(120, 80);
    ctx.lineTo(210, 230);
    ctx.lineTo(330, 60);
    ctx.lineTo(480, 240);
    ctx.lineTo(W, 100);
    ctx.lineTo(W, 350);
    ctx.lineTo(0, 350);

    ctx.closePath();

    ctx.fill();


    /* reflets de glace */

    ctx.strokeStyle =
        "rgba(230,250,255,0.25)";

    ctx.lineWidth = 2;

    for (let i = 0; i < 15; i++) {

        const x =
            (i * 97) % W;

        ctx.beginPath();

        ctx.moveTo(
            x,
            0
        );

        ctx.lineTo(
            x + 30,
            H
        );

        ctx.stroke();

    }

}


/* ================= ESPACE ================= */

function drawSpaceDetails() {

    /* étoiles */

    for (let i = 0; i < 100; i++) {

        const x =
            (i * 83) % W;

        const y =
            (i * 47) % H;

        const size =
            i % 5 === 0 ? 2 : 1;

        ctx.fillStyle =
            i % 7 === 0
                ? "rgba(160,210,255,0.9)"
                : "rgba(255,255,255,0.7)";

        ctx.fillRect(
            x,
            y,
            size,
            size
        );

    }


    /* planète */

    const planet =
        ctx.createRadialGradient(
            80,
            100,
            10,
            80,
            100,
            60
        );

    planet.addColorStop(
        0,
        "#8a92e8"
    );

    planet.addColorStop(
        0.7,
        "#393e8a"
    );

    planet.addColorStop(
        1,
        "#101330"
    );

    ctx.fillStyle = planet;

    ctx.beginPath();

    ctx.arc(
        80,
        100,
        60,
        0,
        Math.PI * 2
    );

    ctx.fill();

}


/* ================= DONJON ================= */

function drawDungeonDetails() {

    /* briques */

    ctx.strokeStyle =
        "rgba(0,0,0,0.3)";

    ctx.lineWidth = 2;

    for (
        let y = 0;
        y < H;
        y += 40
    ) {

        for (
            let x = 0;
            x < W;
            x += 60
        ) {

            ctx.strokeRect(
                x + ((y / 40) % 2) * 30,
                y,
                60,
                40
            );

        }

    }


    /* torches */

    for (let i = 0; i < 4; i++) {

        const x =
            50 + i * 165;

        const y = 45;

        const glow =
            ctx.createRadialGradient(
                x,
                y,
                2,
                x,
                y,
                35
            );

        glow.addColorStop(
            0,
            "rgba(255,180,60,0.5)"
        );

        glow.addColorStop(
            1,
            "rgba(255,80,20,0)"
        );

        ctx.fillStyle = glow;

        ctx.beginPath();

        ctx.arc(
            x,
            y,
            35,
            0,
            Math.PI * 2
        );

        ctx.fill();

    }

}


/* =========================================================
   OBSTACLES RÉALISTES
   ========================================================= */

function drawObstacles() {

    const type =
        worlds[selectedWorld].type;

    obstacles.forEach(obstacle => {

        const x =
            obstacle.x * CELL;

        const y =
            obstacle.y * CELL;

        if (type === "jungle") {

            drawTree(
                x,
                y
            );

        }

        if (type === "desert") {

            drawCactus(
                x,
                y
            );

        }

        if (type === "volcano") {

            drawVolcanicRock(
                x,
                y
            );

        }

        if (type === "glacier") {

            drawIceBlock(
                x,
                y
            );

        }

        if (type === "space") {

            drawAsteroid(
                x,
                y
            );

        }

        if (type === "dungeon") {

            drawStoneBlock(
                x,
                y
            );

        }

    });

}


/* ================= ARBRE ================= */

function drawTree(x, y) {

    ctx.fillStyle =
        "rgba(0,0,0,0.25)";

    ctx.fillRect(
        x + 4,
        y + 7,
        15,
        14
    );


    ctx.fillStyle = "#5c321d";

    ctx.fillRect(
        x + 7,
        y + 8,
        7,
        13
    );


    ctx.fillStyle = "#173f20";

    ctx.beginPath();

    ctx.arc(
        x + 10,
        y + 6,
        10,
        0,
        Math.PI * 2
    );

    ctx.fill();


    ctx.fillStyle = "#286b32";

    ctx.beginPath();

    ctx.arc(
        x + 5,
        y + 8,
        6,
        0,
        Math.PI * 2
    );

    ctx.fill();

}


/* ================= CACTUS ================= */

function drawCactus(x, y) {

    ctx.fillStyle =
        "rgba(0,0,0,0.2)";

    ctx.fillRect(
        x + 3,
        y + 4,
        14,
        17
    );


    ctx.fillStyle = "#387a42";

    ctx.fillRect(
        x + 7,
        y + 3,
        6,
        17
    );

    ctx.fillRect(
        x + 3,
        y + 8,
        5,
        4
    );

    ctx.fillRect(
        x + 12,
        y + 12,
        5,
        4
    );

}


/* ================= ROCHE VOLCANIQUE ================= */

function drawVolcanicRock(x, y) {

    ctx.fillStyle =
        "rgba(0,0,0,0.35)";

    ctx.beginPath();

    ctx.arc(
        x + 10,
        y + 11,
        9,
        0,
        Math.PI * 2
    );

    ctx.fill();


    const gradient =
        ctx.createLinearGradient(
            x,
            y,
            x + 20,
            y + 20
        );

    gradient.addColorStop(
        0,
        "#51403a"
    );

    gradient.addColorStop(
        1,
        "#181211"
    );

    ctx.fillStyle = gradient;

    ctx.beginPath();

    ctx.moveTo(x + 2, y + 15);
    ctx.lineTo(x + 5, y + 5);
    ctx.lineTo(x + 12, y + 2);
    ctx.lineTo(x + 18, y + 8);
    ctx.lineTo(x + 16, y + 18);
    ctx.lineTo(x + 5, y + 19);

    ctx.closePath();

    ctx.fill();

}


/* ================= GLACE ================= */

function drawIceBlock(x, y) {

    const gradient =
        ctx.createLinearGradient(
            x,
            y,
            x + 20,
            y + 20
        );

    gradient.addColorStop(
        0,
        "#e7fbff"
    );

    gradient.addColorStop(
        0.5,
        "#7fd0ef"
    );

    gradient.addColorStop(
        1,
        "#367aa1"
    );

    ctx.fillStyle = gradient;

    ctx.beginPath();

    ctx.moveTo(x + 2, y + 17);
    ctx.lineTo(x + 4, y + 4);
    ctx.lineTo(x + 13, y + 2);
    ctx.lineTo(x + 19, y + 8);
    ctx.lineTo(x + 17, y + 18);

    ctx.closePath();

    ctx.fill();


    ctx.strokeStyle =
        "rgba(255,255,255,0.5)";

    ctx.stroke();

}


/* ================= ASTÉROÏDE ================= */

function drawAsteroid(x, y) {

    ctx.fillStyle =
        "rgba(0,0,0,0.35)";

    ctx.beginPath();

    ctx.arc(
        x + 11,
        y + 12,
        9,
        0,
        Math.PI * 2
    );

    ctx.fill();


    ctx.fillStyle = "#656875";

    ctx.beginPath();

    ctx.moveTo(x + 2, y + 13);
    ctx.lineTo(x + 5, y + 4);
    ctx.lineTo(x + 14, y + 2);
    ctx.lineTo(x + 19, y + 8);
    ctx.lineTo(x + 16, y + 17);
    ctx.lineTo(x + 7, y + 19);

    ctx.closePath();

    ctx.fill();


    ctx.fillStyle =
        "rgba(0,0,0,0.25)";

    ctx.beginPath();

    ctx.arc(
        x + 8,
        y + 8,
        2,
        0,
        Math.PI * 2
    );

    ctx.fill();

}


/* ================= PIERRE DONJON ================= */

function drawStoneBlock(x, y) {

    const gradient =
        ctx.createLinearGradient(
            x,
            y,
            x + 20,
            y + 20
        );

    gradient.addColorStop(
        0,
        "#77736d"
    );

    gradient.addColorStop(
        1,
        "#302e2a"
    );

    ctx.fillStyle = gradient;

    ctx.fillRect(
        x + 1,
        y + 1,
        18,
        18
    );

    ctx.strokeStyle =
        "rgba(0,0,0,0.5)";

    ctx.strokeRect(
        x + 1,
        y + 1,
        18,
        18
    );

}


/* =========================================================
   NOURRITURE
   ========================================================= */

function drawFood() {

    if (!food) return;

    const x =
        food.x * CELL + CELL / 2;

    const y =
        food.y * CELL + CELL / 2;


    const glow =
        ctx.createRadialGradient(
            x,
            y,
            2,
            x,
            y,
            14
        );

    glow.addColorStop(
        0,
        "rgba(255,80,80,0.55)"
    );

    glow.addColorStop(
        1,
        "rgba(255,80,80,0)"
    );

    ctx.fillStyle = glow;

    ctx.beginPath();

    ctx.arc(
        x,
        y,
        14,
        0,
        Math.PI * 2
    );

    ctx.fill();


    const apple =
        ctx.createRadialGradient(
            x - 3,
            y - 4,
            1,
            x,
            y,
            8
        );

    apple.addColorStop(
        0,
        "#ff7a7a"
    );

    apple.addColorStop(
        0.5,
        "#e52f35"
    );

    apple.addColorStop(
        1,
        "#82151a"
    );

    ctx.fillStyle = apple;

    ctx.beginPath();

    ctx.arc(
        x,
        y + 2,
        7,
        0,
        Math.PI * 2
    );

    ctx.fill();


    ctx.fillStyle = "#65a844";

    ctx.beginPath();

    ctx.ellipse(
        x + 5,
        y - 7,
        5,
        2.5,
        -0.5,
        0,
        Math.PI * 2
    );

    ctx.fill();

}


/* ================= BONUS ================= */

function drawBonus() {

    if (!bonus) return;

    const x =
        bonus.x * CELL + CELL / 2;

    const y =
        bonus.y * CELL + CELL / 2;

    const time =
        Date.now() / 300;

    const size =
        8 + Math.sin(time) * 2;


    ctx.save();

    ctx.translate(
        x,
        y
    );

    ctx.rotate(time);

    ctx.shadowBlur = 15;
    ctx.shadowColor = "#ffe15c";

    ctx.fillStyle = "#ffd83d";

    ctx.beginPath();

    for (let i = 0; i < 10; i++) {

        const angle =
            -Math.PI / 2 +
            i * Math.PI / 5;

        const radius =
            i % 2 === 0
                ? size
                : size * 0.45;

        const px =
            Math.cos(angle) * radius;

        const py =
            Math.sin(angle) * radius;

        if (i === 0) {
            ctx.moveTo(px, py);
        } else {
            ctx.lineTo(px, py);
        }

    }

    ctx.closePath();
    ctx.fill();

    ctx.restore();

}


/* =========================================================
   SERPENT PLUS RÉALISTE
   ========================================================= */

function drawSnake() {

    /*
      Ombre du serpent.
    */

    for (const part of snake) {

        const x =
            part.x * CELL + CELL / 2;

        const y =
            part.y * CELL + CELL / 2;

        ctx.fillStyle =
            "rgba(0,0,0,0.25)";

        ctx.beginPath();

        ctx.ellipse(
            x + 2,
            y + 4,
            8,
            5,
            0,
            0,
            Math.PI * 2
        );

        ctx.fill();

    }


    /*
      Corps.
    */

    for (
        let i = snake.length - 1;
        i >= 0;
        i--
    ) {

        const part = snake[i];

        const x =
            part.x * CELL;

        const y =
            part.y * CELL;

        const isHead =
            i === 0;

        const size =
            isHead ? 19 : 17;

        const cx =
            x + CELL / 2;

        const cy =
            y + CELL / 2;


        const gradient =
            ctx.createRadialGradient(
                x + 7,
                y + 5,
                1,
                cx,
                cy,
                12
            );

        if (isHead) {

            gradient.addColorStop(
                0,
                "#b5ff72"
            );

            gradient.addColorStop(
                0.5,
                "#43c94e"
            );

            gradient.addColorStop(
                1,
                "#12652b"
            );

        } else {

            gradient.addColorStop(
                0,
                "#75dd61"
            );

            gradient.addColorStop(
                0.55,
                "#35a943"
            );

            gradient.addColorStop(
                1,
                "#0e5526"
            );

        }


        ctx.fillStyle = gradient;

        ctx.beginPath();

        ctx.arc(
            cx,
            cy,
            size / 2,
            0,
            Math.PI * 2
        );

        ctx.fill();


        /*
          Motif d'écailles.
        */

        if (!isHead) {

            ctx.strokeStyle =
                "rgba(5,70,20,0.4)";

            ctx.lineWidth = 1;

            ctx.beginPath();

            ctx.arc(
                cx,
                cy + 1,
                5,
                0,
                Math.PI
            );

            ctx.stroke();

        }

    }


    drawSnakeHead();

}


/* ================= TÊTE ================= */

function drawSnakeHead() {

    if (!snake.length) return;

    const head =
        snake[0];

    const cx =
        head.x * CELL + CELL / 2;

    const cy =
        head.y * CELL + CELL / 2;


    /*
      Yeux.
    */

    let eyeOffsetX = 5;
    let eyeOffsetY = 5;

    if (direction.x !== 0) {

        eyeOffsetX = 5;
        eyeOffsetY = 5;

    } else {

        eyeOffsetX = 5;
        eyeOffsetY = 5;

    }


    let ex1 = cx - 4;
    let ex2 = cx + 4;
    let ey = cy - 5;


    if (direction.x < 0) {

        ex1 = cx - 5;
        ex2 = cx - 5;

        ey = cy - 4;

    }

    if (direction.x > 0) {

        ex1 = cx + 5;
        ex2 = cx + 5;

        ey = cy - 4;

    }

    if (direction.y > 0) {

        ex1 = cx - 4;
        ex2 = cx + 4;

        ey = cy + 5;

    }

    if (direction.y < 0) {

        ex1 = cx - 4;
        ex2 = cx + 4;

        ey = cy - 5;

    }


    ctx.fillStyle = "#eaffd8";

    ctx.beginPath();

    ctx.arc(
        ex1,
        ey,
        2.8,
        0,
        Math.PI * 2
    );

    ctx.fill();

    ctx.beginPath();

    ctx.arc(
        ex2,
        ey,
        2.8,
        0,
        Math.PI * 2
    );

    ctx.fill();


    ctx.fillStyle = "#071006";

    ctx.beginPath();

    ctx.arc(
        ex1,
        ey,
        1.4,
        0,
        Math.PI * 2
    );

    ctx.fill();

    ctx.beginPath();

    ctx.arc(
        ex2,
        ey,
        1.4,
        0,
        Math.PI * 2
    );

    ctx.fill();


    /*
      Langue.
    */

    if (Math.floor(Date.now() / 350) % 2 === 0) {

        ctx.strokeStyle =
            "#e87582";

        ctx.lineWidth = 1.2;

        ctx.beginPath();

        let tx = cx;
        let ty = cy;

        if (direction.x > 0) tx += 11;
        if (direction.x < 0) tx -= 11;
        if (direction.y > 0) ty += 11;
        if (direction.y < 0) ty -= 11;

        ctx.moveTo(
            cx,
            cy
        );

        ctx.lineTo(
            tx,
            ty
        );

        ctx.stroke();

    }

}


/* =========================================================
   PARTICULES
   ========================================================= */

function createEatParticles(x, y) {

    for (let i = 0; i < 10; i++) {

        particles.push({

            x: x * CELL + CELL / 2,
            y: y * CELL + CELL / 2,

            vx:
                (Math.random() - 0.5) * 2,

            vy:
                (Math.random() - 0.5) * 2,

            life: 1

        });

    }

}


function createBonusParticles(x, y) {

    for (let i = 0; i < 20; i++) {

        particles.push({

            x: x * CELL + CELL / 2,
            y: y * CELL + CELL / 2,

            vx:
                (Math.random() - 0.5) * 4,

            vy:
                (Math.random() - 0.5) * 4,

            life: 1

        });

    }

}


function updateParticles() {

    particles.forEach(p => {

        p.x += p.vx;
        p.y += p.vy;

        p.life -= 0.035;

    });

    particles =
        particles.filter(
            p => p.life > 0
        );

}


function drawParticles() {

    particles.forEach(p => {

        ctx.globalAlpha =
            Math.max(0, p.life);

        ctx.fillStyle =
            "#b7ff75";

        ctx.beginPath();

        ctx.arc(
            p.x,
            p.y,
            2,
            0,
            Math.PI * 2
        );

        ctx.fill();

    });

    ctx.globalAlpha = 1;

}


/* ================= INITIALISATION ================= */

updateInterface();

/*
  Premier rendu même avant
  de commencer une partie.
*/

draw();


/*
  Aucun navigator.vibrate()
  dans cette version.
*/