const sampleResults=[
 {platform:"Instagram",name:"Henok Girma",handle:"@henokgirma",icon:"◎",match:"High",bio:"Public profile with matching name and username.",location:"Publicly listed: Addis Ababa",type:"Social"},
 {platform:"LinkedIn",name:"Henok Girma",handle:"henok-girma",icon:"in",match:"High",bio:"Public professional profile.",location:"Public location: Ethiopia",type:"Social"},
 {platform:"TikTok",name:"Henok G.",handle:"@henokg",icon:"♪",match:"Medium",bio:"Public creator profile.",location:"Not publicly listed",type:"Social"},
 {platform:"Facebook",name:"Henok Girma",handle:"henok.girma",icon:"f",match:"Medium",bio:"Public profile. Identity should be verified manually.",location:"Public location unavailable",type:"Social"},
 {platform:"YouTube",name:"Henok Girma",handle:"@henokgirma",icon:"▶",match:"Medium",bio:"Public channel/profile.",location:"Not publicly listed",type:"Social"},
 {platform:"Web",name:"Henok Girma — public listing",handle:"example.org/public",icon:"⌁",match:"Low",bio:"Public web result associated with the searched terms.",location:"Public source",type:"Web"}
];

let currentQuery="";
let currentProfile=null;

function showScreen(id){
 document.querySelectorAll(".screen").forEach(s=>s.classList.remove("active"));
 document.getElementById(id).classList.add("active");
 document.querySelectorAll(".nav").forEach(n=>n.classList.toggle("active",n.dataset.screen===id));
 window.scrollTo({top:0,behavior:"smooth"});
}
function setType(type){
 showScreen("search");
 document.getElementById("searchQuery").focus();
 document.getElementById("searchQuery").placeholder = type==="photo" ? "Photo selected — add optional context" : "Enter "+type+"...";
}
function startSearch(fromSearch=false){
 const q=(fromSearch?document.getElementById("searchQuery"):document.getElementById("homeQuery")).value.trim();
 currentQuery=q||"Example public search";
 document.getElementById("resultQuery").textContent=currentQuery;
 localStorage.setItem("traceai_history",JSON.stringify([currentQuery,...getHistory()].slice(0,5)));
 renderHistory();
 renderResults();
 showScreen("results");
}
function getHistory(){try{return JSON.parse(localStorage.getItem("traceai_history")||"[]")}catch(e){return[]}}
function renderHistory(){
 const el=document.getElementById("historyList"),h=getHistory();
 el.innerHTML=h.length?h.map(x=>`<button class="result" style="width:100%;text-align:left" onclick="reuseSearch(${JSON.stringify(x)})">⌕ ${escapeHtml(x)} <span style="float:right;color:#777">›</span></button>`).join(""):'<div class="empty">No searches yet.</div>';
}
function reuseSearch(q){document.getElementById("homeQuery").value=q;startSearch()}
function clearHistory(){localStorage.removeItem("traceai_history");renderHistory()}
function escapeHtml(s){return s.replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]))}
function renderResults(){
 const el=document.getElementById("resultsList");
 el.innerHTML=sampleResults.map((r,i)=>`<article class="result">
 <div class="result-top"><div class="avatar">${r.icon}</div><div><h3>${r.name}</h3><p>${r.platform} · ${r.handle}</p></div><span class="badge">${r.match}</span></div>
 <p style="margin-top:12px">${r.bio}</p><div class="result-actions"><button onclick="openProfile(${i})">View Public Profile</button><button onclick="openAnalysis(${i})">AI Match Analysis</button></div>
 </article>`).join("");
}
function openProfile(i){
 currentProfile=sampleResults[i];
 document.getElementById("profileBody").innerHTML=`<div class="profile-card"><div class="big-avatar">${currentProfile.icon}</div><h1>${currentProfile.name}</h1><div class="handle">${currentProfile.handle}</div><span class="platform">${currentProfile.platform}</span><p class="bio">${currentProfile.bio}</p><div class="public-data"><div><span>Source</span><b>${currentProfile.platform}</b></div><div><span>Public location</span><b>${currentProfile.location.replace("Publicly listed: ","")}</b></div><div><span>Match level</span><b>${currentProfile.match}</b></div></div><button class="primary" onclick="openAnalysis(${sampleResults.indexOf(currentProfile)})">✦ View AI Analysis</button></div>`;
 showScreen("profile");
}
function openAnalysis(i){
 currentProfile=sampleResults[i];
 document.getElementById("analysisBody").innerHTML=`<div class="analysis-box"><div class="eyebrow">POSSIBLE MATCH</div><div class="score">82%</div><div class="meter"><i></i></div><p class="warning">This is an estimate based on public signals. It is not proof that the account belongs to the searched person.</p></div><div class="analysis-box"><div class="eyebrow">MATCHING SIGNALS</div><div class="signal"><span>Name similarity</span><b>Strong</b></div><div class="signal"><span>Username similarity</span><b>Strong</b></div><div class="signal"><span>Public profile information</span><b>Available</b></div><div class="signal"><span>Private information</span><b>Not accessed</b></div></div><div class="analysis-box"><div class="eyebrow">AI EXPLANATION</div><p class="warning">The result was surfaced because public profile information overlaps with the search terms. Always verify identity directly through the public profile before taking action.</p></div>`;
 showScreen("analysis");
}
document.querySelectorAll(".chip").forEach(c=>c.addEventListener("click",()=>c.classList.toggle("on")));
renderHistory();