# TraceAI Android

A Capacitor Android wrapper for the TraceAI public-information search prototype.

## Included
- Home screen
- Search screen
- Results screen
- Public profile screen
- AI analysis screen
- Local search history
- Capacitor Android configuration
- Existing `app.js` prototype logic

## Important
The supplied prototype uses `sampleResults`; it does NOT perform live searches. To make it a real service, connect `app.js` to a backend API that only returns information you are legally permitted to access. Do not implement private-address lookup, password/account access, stalking, doxxing, or non-public personal-data retrieval.

## Build prerequisites
- Node.js 20+
- Android Studio
- Android SDK
- Java/JDK supported by the installed Capacitor version

## Setup
```bash
npm install
npx cap add android
npx cap sync android
npx cap open android
```

Then build/run from Android Studio.

For a debug APK from a configured Android project:
```bash
npm run build:android
```

The generated APK will normally be under `android/app/build/outputs/apk/debug/`.

## Next backend step
Create a server API such as:
- `POST /search` — public search terms
- `POST /analyze` — compare public signals and return uncertainty
- `POST /photo-search` — only where the image/search provider permits it

Keep API keys on the server, never inside the Android JavaScript bundle.
