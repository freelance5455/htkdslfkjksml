package br.com.preparacaotaf

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import org.json.JSONArray

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getLongExtra("id", 0L)
        val title = intent.getStringExtra("title") ?: "Hora do TAF 💪"
        val repeat = intent.getStringExtra("repeat") ?: "once"
        val prefs = context.getSharedPreferences("taf_native_alarms", Context.MODE_PRIVATE)
        val raw = prefs.getString("reminders", "[]") ?: "[]"
        var date = ""; var time = ""; var stillActive = false
        val list = JSONArray(raw)
        for (i in 0 until list.length()) {
            val item = list.optJSONObject(i) ?: continue
            if (item.optLong("id") == id && item.optBoolean("active")) {
                date = item.optString("date"); time = item.optString("time"); stillActive = true; break
            }
        }
        if (!stillActive) return

        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channelId = "taf_training_reminders"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            manager.createNotificationChannel(NotificationChannel(channelId, "Lembretes de treino", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Avisos dos horários de treino do PREPARAÇÃO TAF"
                enableVibration(true)
            })
        }
        val openApp = PendingIntent.getActivity(context, 0, Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notification = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("Hora do TAF 💪")
            .setContentText(title)
            .setStyle(NotificationCompat.BigTextStyle().bigText("$title • horário programado"))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setAutoCancel(true)
            .setContentIntent(openApp)
            .build()
        try { manager.notify(id.toInt(), notification) } catch (_: SecurityException) { }

        if (repeat == "once") {
            val updated = JSONArray()
            for (i in 0 until list.length()) {
                val item = list.optJSONObject(i) ?: continue
                if (item.optLong("id") == id) item.put("active", false)
                updated.put(item)
            }
            prefs.edit().putString("reminders", updated.toString()).apply()
        } else {
            AlarmScheduler.scheduleNext(context, id, title, date, time, repeat)
        }
    }
}
