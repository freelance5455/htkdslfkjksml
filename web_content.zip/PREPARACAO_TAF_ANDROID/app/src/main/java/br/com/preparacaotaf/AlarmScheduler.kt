package br.com.preparacaotaf

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import org.json.JSONArray
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

object AlarmScheduler {
    private const val PREFS = "taf_native_alarms"
    private const val KEY = "reminders"

    fun saveAndSchedule(context: Context, json: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, json).apply()
        scheduleAll(context, JSONArray(json))
    }

    fun rescheduleSaved(context: Context) {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "[]") ?: "[]"
        scheduleAll(context, JSONArray(raw))
    }

    fun scheduleAll(context: Context, reminders: JSONArray) {
        val manager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        for (i in 0 until reminders.length()) {
            val item = reminders.optJSONObject(i) ?: continue
            val id = item.optLong("id", 0L)
            val active = item.optBoolean("active", false)
            val title = item.optString("title", "Lembrete do TAF")
            val date = item.optString("date", "")
            val time = item.optString("time", "")
            val repeat = item.optString("repeat", "once")
            if (id == 0L) continue
            val pi = pendingIntent(context, id, title, repeat)
            manager.cancel(pi)
            if (!active) continue
            val whenMillis = nextOccurrence(date, time, repeat) ?: continue
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && manager.canScheduleExactAlarms()) {
                    manager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, whenMillis, pi)
                } else {
                    manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, whenMillis, pi)
                }
            } catch (_: SecurityException) {
                manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, whenMillis, pi)
            }
        }
    }

    fun scheduleNext(context: Context, id: Long, title: String, date: String, time: String, repeat: String) {
        if (repeat == "once") return
        val next = nextOccurrence(date, time, repeat) ?: return
        val manager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = pendingIntent(context, id, title, repeat)
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && manager.canScheduleExactAlarms()) {
                manager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next, pi)
            } else manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next, pi)
        } catch (_: SecurityException) { manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next, pi) }
    }

    private fun pendingIntent(context: Context, id: Long, title: String, repeat: String): PendingIntent {
        val intent = Intent(context, AlarmReceiver::class.java).apply {
            putExtra("id", id); putExtra("title", title); putExtra("repeat", repeat)
        }
        return PendingIntent.getBroadcast(context, id.toInt(), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    private fun nextOccurrence(date: String, time: String, repeat: String): Long? {
        return try {
            val parser = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).apply { isLenient = false }
            val base = parser.parse("$date $time") ?: return null
            val cal = Calendar.getInstance().apply { time = base }
            val now = System.currentTimeMillis()
            when (repeat) {
                "once" -> if (base.time > now) base.time else null
                "daily" -> {
                    while (cal.timeInMillis <= now) cal.add(Calendar.DAY_OF_YEAR, 1)
                    cal.timeInMillis
                }
                "weekly" -> {
                    while (cal.timeInMillis <= now) cal.add(Calendar.DAY_OF_YEAR, 7)
                    cal.timeInMillis
                }
                else -> if (base.time > now) base.time else null
            }
        } catch (_: Exception) { null }
    }
}
