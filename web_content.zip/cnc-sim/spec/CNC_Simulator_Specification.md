# LatheLab — CNC Simulator Software Specification

Version 0.1 · Prototype architecture and functional specification for a mobile and web CNC turning simulator with a Fanuc-style control.

---

## 1. Product overview

### 1.1 Purpose
LatheLab lets machinists, CNC students and programmers write, check and "run" G-code on a virtual 2-axis lathe (X/Z) from a phone, tablet or browser. The screen and controls work like a Fanuc 0i-TF controller, so the skills carry over to a real machine: mode selector, MDI keypad, soft keys, offset pages, cycle start and feed hold.

### 1.2 Goals
| # | Goal | Measure of success |
|---|------|--------------------|
| G1 | Correct ISO/Fanuc lathe interpretation of G0/G1/G2/G3/G70/G71/G72 and core M-codes | Golden-file tests match the reference controller's toolpath within 0.001 mm |
| G2 | Real-time 2D and 3D material removal on mid-range phones | Steady 60 fps on a 2021-class mid-range Android; at least 30 fps in split view |
| G3 | Operator training that feels like the real control | Works the same way as a Fanuc panel in EDIT, MEM, MDI, JOG, HANDLE and REF modes |
| G4 | Offline first | Full function with no network; programs, tools and offsets sync when a connection is available |
| G5 | Safe mistakes | Crashes, overtravel and bad offsets raise alarms, just as a real machine would |

### 1.3 Scope
- **In v1:** 2-axis turning (G18 ZX plane), diameter programming, the Fanuc 0i-T G-code system A, tool/offset management, a 12-station turret, stock and chuck setup, 2D section and 3D solid views, and alarms.
- **Roadmap:** threading (G32/G76/G92), G73/G74/G75, subprograms (M98/M99) and macro B (#vars), tool-nose radius compensation geometry (G41/G42), C-axis and live tooling, 3-axis mill mode, Haas and Siemens dialects, and a classroom/instructor portal.

### 1.4 Personas
- **Student / apprentice** uses a phone and needs guided exercises and forgiving alarms.
- **Setter/operator** uses a tablet at the machine to rehearse offsets, touch-off and single-block proving.
- **CAM/NC programmer** uses a desktop browser to import `.nc` files, backplot them, estimate cycle time and check for gouges or rapids into stock.
- **Instructor** assigns programs and reviews session logs, including alarms and offset history.

---

## 2. System architecture

### 2.1 Layered view
```
┌──────────────────────────────────────────────────────────────────────────┐
│ PRESENTATION   Web (React + Vite PWA)          Mobile (React Native/Expo)│
│   Fanuc panel UI · CRT screens · keypad · operator panel · viewports     │
├──────────────────────────────────────────────────────────────────────────┤
│ RENDERING      Renderer2D (Canvas2D / Skia)   Renderer3D (Three.js/WebGL2 │
│                                                 · expo-gl on mobile)      │
├──────────────────────────────────────────────────────────────────────────┤
│ SIMULATION CORE  (@lathelab/core — pure TypeScript, no DOM; runs in a Web │
│                   Worker on web, a JSI/Hermes thread on mobile)          │
│   Lexer → Parser → Interpreter/Motion planner → Runtime (real-time)       │
│   Material model (radial dexel / tri-dexel)   Alarm engine               │
├──────────────────────────────────────────────────────────────────────────┤
│ DATA           Repository interfaces: ProgramRepo · ToolRepo · OffsetRepo │
│   SQLite (op-sqlite on mobile, wa-sqlite + OPFS on web) ⇄ Sync service   │
├──────────────────────────────────────────────────────────────────────────┤
│ CLOUD (optional)  REST/GraphQL API · Postgres · object storage · auth     │
└──────────────────────────────────────────────────────────────────────────┘
```

### 2.2 Design principles
1. **One core, many shells.** The parser, interpreter, runtime and material model form one dependency-free TypeScript package. The web and mobile apps both import it, and the same test suite covers it for both.
2. **Unidirectional data flow.** The UI sends intents such as `cycleStart`, `jog(+X)` or `setOffset`. The runtime owns machine state and emits events. Renderers read state snapshots and never change them.
3. **Compile, then execute.** A program is compiled once into a flat list of executable *steps*: polylines, dwells, stops and state changes. Canned cycles are expanded when the program is compiled, so renderers only ever draw polylines.
4. **Deterministic.** Given the same inputs, the simulation gives the same output. Wall-clock time only scales the timing, which allows headless CI runs and replayable sessions.
5. **Controller dialect as data.** G-code tables, modal groups, alarm catalogues and parameters (for example decimal-point mode) are configuration, so new dialects can be added without forking the core.

### 2.3 Module map (implemented in the prototype)
| Module | File | Responsibility |
|---|---|---|
| Lexer + Parser | `app/js/parser.js` | Tokenises words, comments, `/` block delete, `%` and EOB. Validates addresses, digits, decimal points, modal-group conflicts and duplicate words. Builds the Block AST and a sequence-number index. |
| Interpreter | `app/js/interpreter.js` | Tracks modal state and resolves X/Z (absolute) against U/W (incremental). Tessellates arcs (R or I/K), expands G70/G71/G72, handles the G28/G50/G04 one-shots and orders M-codes around motion. Emits steps. |
| Runtime | `app/js/runtime.js` | Real-time executor. Handles overrides, single block, feed hold, dry run, optional stop and block skip. Supports jog, MPG and reference return, soft limits, and chuck and rapid-into-stock collision checks. Keeps the cycle timer and part counter. |
| Material model | `app/js/material.js` | Radial height field r(z) with insert-edge footprint sweep and removed-volume calculation. |
| Tool DB | `app/js/tooldb.js` | Turret, tools, geometry and wear offsets, work offsets and history. Uses a repository interface behind a storage adapter. |
| 2D renderer | `app/js/render2d.js` | ZX half-section with mirrored stock, planned and executed paths, insert glyph, pan, zoom and pinch. |
| 3D renderer | `app/js/render3d.js` | Three.js scene with a lathe-revolved workpiece, rotating spindle, chuck, turret and path lines. |
| App shell | `app/js/app.js` | CRT screens, soft keys, key-in buffer, keypad, operator panel bindings, program library and the render loop. |
| Tests | `tests/*.test.js` | 17 Node tests covering the parser, arcs, cycles, offsets, full program runs and finished-diameter accuracy. |

---

## 3. G-code parser specification

### 3.1 Lexical grammar (EBNF)
```
program      = { line } ;
line         = [ "/" ] { word | comment | ws } [ ";" ] NEWLINE | "%" ;
word         = address ws* number ;
address      = "A" … "Z" ;                        (* case-insensitive *)
number       = [ "+" | "-" ] ( digits [ "." digits? ] | "." digits ) ;
comment      = "(" { any-char - ")" } ")" ;
```
- **Block delete:** a leading `/` marks the block. It is skipped when BLOCK SKIP is on.
- **Program number:** `O` plus 1–4 digits. The first comment on that line becomes the program title.
- **Decimal-point mode** (like Fanuc parameter 3401#0):
  - `CALCULATOR` (the default): `X10` = 10.000 mm.
  - `STANDARD`: `X10` = 0.010 mm. Integer addresses (G M N O T P Q L D H) are never scaled.
- **Digit limit:** 8 significant digits, otherwise PS0003.

### 3.2 Block AST
```ts
interface Block {
  line: number;            // 1-based source line (for highlight + alarms)
  n: number | null;        // sequence number
  g: number[];             // G-codes in this block (validated by modal group)
  m: number[];             // M-codes (max 1 per block by default)
  words: Partial<Record<'X'|'Z'|'U'|'W'|'I'|'K'|'R'|'F'|'S'|'T'|'P'|'Q'|string, number>>;
  comment: string | null;
  blockDelete: boolean;
  raw: string;
}
interface ParseResult {
  programNumber: number | null; programName: string | null;
  blocks: Block[]; errors: Diagnostic[]; warnings: Diagnostic[];
  index: Map<number, number>;  // N → block index (G70–G72 P/Q lookup)
}
```

### 3.3 Supported G-codes and modal groups (Fanuc lathe, G-code system A)
| Group | Codes | Meaning | Modal? |
|---|---|---|---|
| 01 Motion | **G00**, **G01**, **G02**, **G03** | Rapid, linear, CW arc, CCW arc | Yes |
| 00 One-shot | G04, G28, G50, **G70**, **G71**, **G72** | Dwell, ref return, coordinate set / max-RPM clamp, finish, OD/ID rough, face rough | No |
| 16 Plane | G18 | ZX plane (the only one on a 2-axis lathe) | Yes |
| 06 Units | G20, G21 | Inch / metric | Yes |
| 07 TNRC | G40, G41, G42 | Nose-radius compensation (tracked in v1; geometry on the roadmap) | Yes |
| 14 WCS | G54–G59 | Work coordinate systems | Yes |
| 02 Spindle | G96, G97 | Constant surface speed / constant RPM | Yes |
| 05 Feed | G98, G99 | mm/min / mm/rev | Yes |

**Validation rules:**
- Two codes from the same group in one block raise PS0035.
- An unknown G-code raises PS0010.
- Two one-shot codes in one block raise PS0035.
- X with U, or Z with W, on the same axis raises PS0034 (allowed inside G71/G72, where U/W have cycle meanings).

### 3.4 M-codes
| Code | Action | Timing relative to motion |
|---|---|---|
| M00 / M01 | Program stop / optional stop (only when OPT STOP is on) | After |
| M02 / M30 | End / end and rewind. Spindle and coolant turn off; part counter +1 | After |
| M03 / M04 | Spindle CW / CCW | Before |
| M05 | Spindle stop | After |
| M08 / M09 | Coolant on / off | Before / after |
| M98 / M99 | Subprogram call / return (parsed; execution on the roadmap, PS0078) | — |
| Others | Passed to a virtual PMC with warning W002 | — |

### 3.5 Execution order inside one block
1. Modal G-codes.
2. F and S.
3. T (tool index and offset).
4. Pre-motion M-codes (M03, M04, M08).
5. Motion or one-shot.
6. Post-motion M-codes (M05, M09, M00, M01, M02, M30).

### 3.6 Motion semantics
- **Coordinates:** X is a diameter value and Z is axial. U/W are incremental. Arcs and distances are computed in radius space.
- **G00 rapid:** interpolated in a straight line at the rapid rate × rapid override (F0/25/50/100 %).
- **G01 linear:** cutting feed.
  - G98: F in mm/min.
  - G99: F in mm/rev × actual RPM. PS0011 is raised if F is not set.
- **G02 / G03 arcs:** in the standard view (+Z right, +X up, looking from +Y), G02 runs clockwise.
  - **R form:** R > 0 gives the minor arc and R < 0 the major arc. The centre is found from the chord midpoint and the perpendicular. PS0020 is raised if |R| is smaller than half the chord.
  - **I/K form:** the centre is found from incremental offsets (I is a radius value). PS0020 is raised if the start and end radii differ by more than 0.01 mm.
  - **Tessellation:** chord tolerance 0.01 mm, with the last point snapped exactly to the programmed end.
- **G96 CSS:** RPM = 1000·Vc / (π·D), limited by the G50 S clamp. The value is recomputed continuously as the diameter changes, so feed per revolution tracks correctly while facing.
- **G28:** rapids through an intermediate point to the machine reference.
- **G04:** P in milliseconds, or X/U in seconds.

### 3.7 Canned cycles

#### G71 — stock removal in turning (Type I)
```
G71 U(Δd) R(e) ;                         Δd = depth of cut (radius), e = retract
G71 P(ns) Q(nf) U(Δu) W(Δw) F S ;         Δu = X finish allowance (diameter), Δw = Z allowance
N(ns) G00/G01 X… ;                        shape program (first block must be G00/G01, else PS0065)
…
N(nf) … ;
```
**How the cycle is expanded:**
1. Extract the shape program from N(ns) to N(nf) by running it through the same motion evaluator (lines and arcs), starting from the cycle start point S. PS0063 is raised if P or Q is not found.
2. Offset the profile by Δu/2 in X and Δw in Z.
3. Check that the profile is monotonic in X, as Type I requires (PS0064).
4. For each level L = S.x − k·Δd while L has not yet reached the profile start:
   1. Find where the profile first crosses L to get Z<sub>end</sub>. If it never crosses, use the profile's end.
   2. `G00` to (L, S.z).
   3. `G01` to (L, Z<sub>end</sub>) at the cycle F.
   4. Retract `G00` at 45° by e.
   5. `G00` back to S.z.
5. Make a semi-finish pass along the offset profile. This leaves Δu and Δw for G70.
6. Return to S (X first, then Z).
7. **Resume at the block after N(nf)**, as a Fanuc control does.

#### G72 — stock removal in facing
The same algorithm with the roles of the axes swapped. Levels step in Z by Δd (from `G72 W(Δd) R(e)`), and each pass cuts along X.

#### G70 — finishing
Replays the moves from N(ns) to N(nf) with no allowance, using the F/S in the shape blocks (or the modal values), then returns to S. Execution continues after the G70 block.

**Implemented as a generic `roughCycle(kind, …)`:** the "level axis" is X for G71 and Z for G72. The prototype's tests check the expected roughing pass counts for G71 and G72, and that O1001 finishes to Ø20 / Ø40 / Ø50 ±0.02 mm.

### 3.8 Diagnostics (Fanuc-style alarm catalogue)
| Code | Message | Raised by |
|---|---|---|
| PS0003 | TOO MANY DIGITS | Lexer |
| PS0005 | NO DATA AFTER ADDRESS | Lexer |
| PS0007 | ILLEGAL USE OF DECIMAL POINT | Lexer |
| PS0009 | IMPROPER NC-ADDRESS | Lexer |
| PS0010 | IMPROPER G-CODE | Parser |
| PS0011 | FEED ZERO | Interpreter |
| PS0020 | OVER TOLERANCE OF RADIUS | Arc solver |
| PS0030 | ILLEGAL OFFSET NUMBER | Parser / OFS |
| PS0034 / PS0035 / PS0036 | Duplicate address / same-group G / too many M | Parser |
| PS0061 / PS0062 / PS0063 / PS0064 / PS0065 | Cycle P/Q, illegal command, sequence not found, not monotonic, first block not G00/G01 | Cycles |
| PS0070 | UNTERMINATED COMMENT | Lexer |
| SIM001 | RAPID MOVE INTO STOCK (tolerance 0.05 mm) | Runtime |
| SIM002 | SPINDLE STOPPED DURING CUTTING FEED | Runtime |
| SIM003 | OVERTRAVEL (soft limits, machine coords) | Runtime |
| SIM004 | CHUCK COLLISION | Runtime |

Every diagnostic records `{line, col, code, message}`.
- **EDIT mode:** diagnostics are marked in the editor gutter (`!13`) and listed under the editor.
- **Execution:** diagnostics become alarms that light the alarm lamp and put the machine into feed hold. RESET clears them.

### 3.9 Parser performance targets
- 100k-line programs parse in under 150 ms in a web worker. The lexer is a single pass with no regex backtracking in the hot loop.
- Incremental re-parse runs on every edit (debounced 350 ms in the prototype). The production target is line-level incremental parsing that reuses the previous AST.

---

## 4. Coordinate systems and offset mathematics

```
machine = absolute(work) + workShift[G5x] + geometry[oo] + wear[oo]
tool tip (physical, ideal tool) = absolute + wear
home (absolute) = −(workShift + geometry + wear)
```
- **Tnnoo:** nn = turret station (tool index), oo = offset number. On a T-command, the absolute position is re-expressed so the machine position stays the same (the tool indexes where it is): `abs' = abs + off_old − off_new`.
- **Wear sign:** `wearX = −0.05` gives a diameter 0.05 mm smaller. A test checks Ø19.95 against Ø20 nominal.
- **MEASUR touch-off:** on the OFS › GEOM page, key in `X49.82` (the measured diameter) or `Z0` and press INPUT. The control sets `geometry = machine − measured − wear − workShift`. Because this keeps the physical position, the POS screen then reads exactly the measured value.
- **Guard rails:**
  - Wear entries larger than ±1.000 per input are rejected (configurable `max_wear_input`).
  - Tip direction must be 0–9.
  - Offset numbers are range-checked (PS0030).

---

## 5. Toolpath visualization engine

### 5.1 Pipeline
```
ParseResult ─► compile() ─► Step[] ─┬─► Planned path (static, preview + backplot)
                                    └─► Runtime.tick(dt)
                                           ├─ interpolated tool position
                                           ├─ Stock.sweep(prev, next, edge)  ◄─ material model
                                           ├─ executed trail
                                           └─ events → CRT / HUD
Renderers pull each frame (requestAnimationFrame):  Renderer2D.draw(), Renderer3D.draw(dt)
```

### 5.2 Timing model
- **Feed:** each move step stores its feed spec `{F, mode, S, css, clamp}` instead of a fixed speed. The runtime computes the live feed from the current diameter, the spindle override and the feed override. This matters in G96 facing, where feed rises as X falls, up to the RPM clamp.
- **Other modes:**
  - Rapid uses the rapid rate × rapid override.
  - Dry run uses 3000 mm/min × feed override.
  - Dwell counts down.
- **Speed control:**
  - The simulation speed multiplier (1–25×) scales `dt` for program execution only. Jogging always runs in real time.
- **Accuracy:**
  - Each move keeps its cumulative arc length, so interpolation is exact at any frame rate.
  - Every vertex passed within one frame is swept through the material model, so fast playback never skips geometry.

### 5.3 2D engine (Canvas 2D on web, react-native-skia on mobile)
- **Layers**, drawn back to front:
  1. Grid (adaptive 1-2-5 spacing)
  2. Chuck jaws
  3. Original stock outline
  4. Live stock, a mirrored r(z) polygon with metallic gradient
  5. Centreline and work zero
  6. Planned path (G00 dashed red, feed cyan)
  7. Executed trail (green)
  8. Insert glyph for the tool type, with holder and coolant
- **View transform:** `screen = centre + (world − c)·scale` with +X up. Wheel zoom stays anchored at the cursor, drag pans, two-finger pinch zooms, and double-click fits the view.
- **Budget:** under 2 ms per frame for 5k path vertices. The production build moves the path into a `Path2D` cache per segment batch and redraws it only when it changes.

### 5.4 Material removal model
- **Turning (v1): radial height field.** Stock is sampled into slices every Δz (0.05 mm by default, 1,601 slices for 80 mm). Each slice stores r(z).
  - A lathe part is axisymmetric, so this representation is exact.
  - Sweeps are O(length/Δz).
  - The *trailing cutting edge* of the insert is included: an edge running toward +Z at `45° − included/2` over a 4 mm length. Without it, a point tool would leave slivers between G72 facing levels.
  - Grooving tools use a flat 3 mm edge.
- **Removed volume:** Σ π(R² − r²)Δz, shown in cm³ on the GRAPH screen.
- **Milling (roadmap): tri-dexel.** Three orthogonal ray grids, each storing intervals. Tool swept volumes are subtracted with a signed-distance function per tool shape. The mesh is rebuilt per dirty tile with dual contouring, and compute runs in a WASM (Rust) module with SIMD.
- **Collision:**
  - A rapid that engages material by more than 0.05 mm raises SIM001.
  - Cutting while the spindle is stopped raises SIM002.
  - The tip entering the chuck envelope raises SIM004.
  - Machine coordinates beyond the soft limits raise SIM003.
  - **Roadmap:** holder/turret-body collision using capsule-vs-surface-of-revolution tests.

### 5.5 3D engine (Three.js r160 / WebGL2; expo-gl + three on mobile)
- **Scene graph:** `spindle` (chuck body + 3 jaws + workpiece) · `plannedLine` · `trailLine` · `turret` (holder + extruded insert).
- **Axis mapping:** machine Z maps to world +X and machine X (radius) to world +Y.
- **Workpiece:** a `LatheGeometry` with 96 segments built from a 500-point down-sample of r(z). It is rebuilt only when `stock.version` changes. At high sim speeds the rebuild is throttled to about 10 Hz and uses geometry double-buffering.
- **Materials:** PBR metal (metalness 0.85, roughness 0.32) lit by a PMREM `RoomEnvironment` with ACES tone mapping. The spindle rotates at live RPM (visually slowed).
- **Controls:** OrbitControls with damping. On mobile, one-finger drag orbits, two fingers pan and pinch zooms.
- **Path lines:** built as LineSegments with the batched vertices of each group.
- **Performance targets:** under 40k triangles for the workpiece and under 3 draw calls for the paths. `setPixelRatio` is capped at 2 and the view falls back to 1.5 when the frame time exceeds 20 ms.
- **Lazy loading:** the 3D module loads only when 3D or Split is first selected. If WebGL fails, the 2D view stays usable (graceful fallback).

### 5.6 Threading model (production)
| Platform | Simulation core | Rendering |
|---|---|---|
| Web | Dedicated Web Worker (the core is DOM-free). Steps and state are sent with `postMessage`; stock r(z) is shared through a `SharedArrayBuffer` when cross-origin isolation is available, otherwise a transferable ArrayBuffer is sent each frame. | Main thread with OffscreenCanvas for 2D where supported |
| iOS/Android | Hermes worklet (react-native-worklets-core) or a JSI C++ core | Skia (2D) and expo-gl (3D) on the UI thread |

---

## 6. Tool and offset management database

The full DDL is in `spec/schema.sql`. It has been validated on SQLite 3 and ports to Postgres 15 with the changes noted inline.

### 6.1 Entity-relationship summary
```
machine 1───* turret_station *───1 tool
   │ 1                 │ 1
   │                   └──1 tool_life
   ├──* tool_offset (offset_no: geom_x, geom_z, wear_x, wear_z, nose_radius, wear_radius, tip_direction, version)
   ├──* work_offset (EXT, G54…G59: x, z)
   ├──* offset_history (every INPUT / +INPUT / MEASURE / SYNC / UNDO)
   └──* sim_session ───1 nc_program
view v_effective_offset = geometry + wear joined to the turret tool
```

### 6.2 Key tables
| Table | Key columns | Notes |
|---|---|---|
| `tool` | tool_type, insert_shape, included_angle, nose_radius, cutting_width, **diameter**, tip_direction, holder, mesh_uri | Physical catalogue, independent of where a tool is mounted. `diameter` is used for drills and boring bars. |
| `turret_station` | (machine_id, **station**), tool_id, default_offset, orientation_deg, is_live | The `nn` of Tnnoo. A tool can only be mounted in one station per machine (unique partial index). |
| `tool_offset` | (machine_id, **offset_no**), **geom_x/z, wear_x/z**, nose_radius, wear_radius, tip_direction, version | Fanuc "memory C": geometry and wear are stored separately. X values are diameters. |
| `work_offset` | (machine_id, code) x, z | G54–G59 plus the EXT shift. |
| `offset_history` | field, old/new value, method, user, session | The audit trigger `trg_offset_audit` fills this automatically. It drives MESSAGE › OFS LOG and undo. |
| `tool_life` | life_unit, limit, used, alarm_at_pct | Fanuc TLM-style life counting. |

### 6.3 Repository interface (shared by web and mobile)
```ts
interface OffsetRepo {
  get(machineId: string, n: number): Promise<ToolOffset | null>;
  set(machineId: string, n: number, field: OffsetField, value: number,
      mode: 'INPUT' | 'PLUS_INPUT' | 'MEASURE'): Promise<Result<ToolOffset, OffsetError>>;
  history(machineId: string, limit?: number): Promise<OffsetHistory[]>;
  subscribe(machineId: string, cb: (o: ToolOffset) => void): Unsubscribe;
}
interface ToolRepo { listTurret(machineId): Promise<TurretStation[]>; mount(machineId, station, toolId): Promise<void>; … }
```
- **Adapters:** `MemoryStorage` in the prototype, `op-sqlite` on mobile, `wa-sqlite` + OPFS on web, and a REST adapter for the cloud.
- **Sync:**
  - Last-writer-wins per row, based on `version` and `updated_at`.
  - Offsets use **field-level merge** with conflict prompts. A wear change made on the tablet at the machine should never be silently overwritten by an old desktop edit.
  - Deletes become tombstones through `deleted_at`.

---

## 7. Frontend UI and wireframe plan

### 7.1 Design language
- **Style:** industrial and dark, based on the Fanuc 0i look.
  - Charcoal bezel with a dark CRT screen and a navy header bar.
  - Cream address and number keys, grey edit keys and a yellow INPUT key.
  - Green CYCLE START, amber FEED HOLD, and a red mushroom E-STOP on a yellow collar.
  - Accent colour: Fanuc-ish yellow `#FFC400`, reserved for state (active mode LEDs, the selected soft key, the current block).
- **Type:** Archivo for UI labels and JetBrains Mono for the CRT, positions and G-code.
- **Touch targets:** at least 34 px on desktop and 44 px on mobile. The jog keys respond to press-and-hold using pointer events.

### 7.2 Desktop / tablet landscape (≥ 961 px)
```
┌───────────────────────────────────────────────────────────────────────────────────────┐
│ [logo] LatheLab   ● MEM │ O1001 │ CYCLE │ ● NO ALARM                     Sim speed [5×]│
├──────────────────────────────────────────────────────┬────────────────────────────────┤
│ [2D Section|3D Solid|Split]   ☑Planned ☑Executed Fit │┌ PROGRAM ─────── O1001 N00007 ┐│
│┌────────────────────────────────────────────────────┐││ N6 G71 U1.5 R0.5              ││
││ X 40.230  Z -25.230  F 387  S 1549  T 0101  (HUD)   │││▓N7 G71 P8 Q19 U0.4 W0.1 F0.25▓││
││                                                    │││ N8 G00 X16.0                  ││
││   ███ chuck      ▒▒▒▒▒ stock r(z)  ◆ insert         │││ …                             ││
││   ███──────────────────────────────⊕ work zero ──── │││> key-in buffer_               ││
││                                                    │││ MEM  STRT  18:14:16           ││
││                      legend: --- G00  ─ feed  ─ done│││[PROGRAM][DIR][CHECK][REWIND][ ]││ ← soft keys
│└────────────────────────────────────────────────────┘│└───────────────────────────────┘│
├──────────────────────────────────────────────────────┤ [POS][PROG][OFS/SET][GRAPH][MSG]│ ← function keys
│ MODE        PROGRAM RUN        OVERRIDES   JOG/MPG   │ ┌O N G P Q R┐ ┌7 8 9┐          │
│ [EDIT][MEM] [SBK][BDT][OPT][DRN] Feed ▬▬●  [+X]  ◎MPG │ │X Z U W I K│ │4 5 6│          │ ← MDI keypad
│ [MDI][JOG]  [CYCLE START][HOLD] Spdl ▬▬●[-Z][RAP][+Z]│ │M S T F EOB│ │1 2 3│          │
│ [HND][REF]                      Rapid F0 25 50 100 [-X] │ ALTER INSERT DELETE CAN INPUT│          │
│                                     SPINDLE CW STOP CCW  (E-STOP)  │ ▲ ▼ RESET   │- 0 .│          │
└──────────────────────────────────────────────────────┴────────────────────────────────┘
```

### 7.3 Phone portrait (≤ 960 px)
```
┌──────────────────────────┐
│ LatheLab        [5× ▾]   │
│ ● EDIT │ O1001 │ STOP     │
├──────────────────────────┤
│[2D][3D][Split] [Fit][Ø50]│
│ X… Z… F… S… T…            │   44 dvh viewport, always visible
│   (2D / 3D canvas)        │
├──────────────────────────┤
│  Tab A: Screen & keys    │   CRT (380 px) + soft keys + function keys + keypad
│  Tab B: Operator panel   │   modes (6-up) · run toggles · start/hold · overrides ·
│                          │   jog pad · MPG · spindle · E-STOP
├──────────────────────────┤
│ [Screen & keys][Operator]│   fixed bottom tab bar (safe-area aware)
└──────────────────────────┘
```
In a real device build, **tablet landscape** uses the desktop layout. **Phone landscape** puts the viewport on the left and a swipeable CRT/panel on the right.

### 7.4 Mode behaviour
| Mode | What the user can do | Screen auto-selected | Cycle start |
|---|---|---|---|
| **EDIT** | Full-screen editor with gutter line numbers, live syntax diagnostics and uppercase normalisation. Keypad editing works the Fanuc way: build a block in the key-in buffer (`EOB` = `;`), then **INSERT** (after the cursor line), **ALTER** (replace the line) or **DELETE** (the line, or the program when the buffer holds `O1234`). `O1234` + ▼ searches for a program. DIR / NEW / CHECK / EXPORT / IMPORT (.nc). | PROG | Disabled (message) |
| **MEM** (AUTO) | Runs the stored program: current block highlighted and auto-scrolled, SINGLE BLOCK, BLOCK SKIP, OPT STOP, DRY RUN, FEED HOLD, REWIND, cycle timer and part counter. | PROG | Starts or resumes |
| **MDI** | Type or key in one or more blocks. CYCLE START compiles them from the *current* modal state and position and runs them. The buffer clears on completion, and the active modal line is shown. | PROG (MDI) | Runs the MDI buffer |
| **JOG** | Hold ±X/±Z to move at the jog feed × feed override. RAPID toggles rapid traverse. Spindle CW/STOP/CCW. Material is cut if the spindle is running; alarms fire on crashes. | POS | — |
| **HANDLE** (MPG) | 100-detent handwheel you drag in a circle, with an axis selector (X/Z) and ×1/×10/×100/×1k (0.001–1.000 mm). Arrow keys give fine steps. | POS | — |
| **REF** (ZRN) | +X / +Z return each axis to the machine reference (machine 0,0). | POS | — |

### 7.5 CRT screens (function key → soft keys)
| Function key | Soft keys | Content |
|---|---|---|
| **POS** | ALL · PT-CNT 0 · RUN-T 0 | Large ABSOLUTE X/Z, MACHINE, DISTANCE TO GO, actual F and S, T, spindle, coolant, part count, run time, cycle estimate, modal G line |
| **PROG** | PROGRAM · DIR · CHECK · NEW · EXPORT / REWIND / CLEAR (varies by mode) | Editor, execution listing, MDI buffer, program directory, decoded block check |
| **OFS/SET** | WEAR · GEOM · TURRET · WORK · MEASUR | Offset tables with a yellow cell cursor. INPUT (set), +INPUT (add), ▲▼. The turret list shows the ▶ active station. Work offsets G54–G59. Touch-off with MEASUR. |
| **GRAPH** | 2D · 3D · SPLIT · CLR PATH · NEW STOCK | Stock parameters, resolution, removed volume, segment count, cycle estimate |
| **MESSAGE** | ALARM · HISTORY · OFS LOG · CLEAR | Active alarms, message history, offset audit log |

The header shows the program number and the executing N-number. The footer shows the key-in buffer (`>`), the mode, the run state (`****` / STRT / HOLD / STOP / ALM) and a clock. A physical keyboard types into the key-in buffer whenever the CRT has focus: Enter = INPUT or INSERT, Backspace = CAN.

### 7.6 Machine operator panel
- **Mode** keys have LEDs.
- **Program-run toggles:** SINGLE BLOCK, BLOCK SKIP, OPT STOP, DRY RUN.
- **CYCLE START / FEED HOLD:** each lights up when active.
- **Overrides:**
  - Feed 0–150 % in 10 % steps.
  - Spindle 50–120 %.
  - Rapid F0/25/50/100.
- **Jog, MPG and spindle:** jog pad with a RAPID centre key, the MPG with its axis and increment selectors, and spindle keys.
- **E-STOP:** latches EMG, stops everything and turns the spindle off. Press it again to release, then press RESET.

### 7.7 Accessibility and responsiveness
- Every control has an `aria-label`. The status strip is an `aria-live` region, and focus rings are visible.
- `prefers-reduced-motion` disables the blinking caret and the alarm lamp animation.
- The CRT colour contrast is at least 7:1 for body text.

---

## 7A. SINUMERIK 808D control panel (second controller)

A top-bar switch toggles between **FANUC 0i-TF** and **SINUMERIK 808D**. Both drive the same runtime, tool database, material model and renderers; only the operator interface and the program dialect change (`js/siemens.js`, `js/dialect.js`).

### PPU (panel processing unit)
```
+-------------------------------------------------+------+
| Machine | JOG |              /NC/MPF/TURN_SHAFT |  VSK |
| Channel reset   Program aborted       SBL ROV   |  x8  |
| [alarm line: 10720 Software limit switch +X ]   |      |
|  WCS   Position [mm]  Dist-to-go  | T  T1 D1    |      |
|  X     201.250        0.000       | F  0.000    |      |
|  Z     150.800        0.000       | S1 0  100%  |      |
|  G0 G18 G71 G95 G97 G40 G54 DIAMON LIMS=4000    |      |
|  [mode window: block display / MDA / REF / JOG] |      |
| [HSK1][HSK2]...[HSK8]                           |      |
+-------------------------------------------------+------+
[POSITION][OFFSET][PROGRAM][PROG MGR][ALARM][SYSTEM]
[ alpha keys O N G X Z F D T S M I K R P Q L U W = ( ) , " : ; SPACE ] [ 7 8 9 / 4 5 6 / 1 2 3 / - 0 . ]
[ALARM CANCEL][BACKSP][DEL][PAGE UP][▲][PAGE DOWN][SELECT][◀][▼][▶][END][INPUT]
```

| Operating area | Horizontal soft keys | Vertical soft keys |
|---|---|---|
| Machine (POSITION) | 2D section, 3D solid, Split view, Clear path, Blank | Act. val. MCS/WCS, G funct., Prog. ctrl (DRY/SKP/M01/SBL), Delete MDA prog., Handwheel X/Z, Program select; in JOG/HANDWHEEL: **T, S, M**, **Set WO**, **Facing**, Meas. tool |
| Program | Edit, Stock rem. CYCLE95, Groove CYCLE93, Contour labels, Simulation | Execute, Check syntax, CYCLE95 form, CYCLE93 form, Insert contour, Close |
| Offset | Tool list, Tool wear, Work offset, Measure tool, R variables | Activate tool / Set length X, Set length Z, Input X Ø, Input Z / Delete all R |
| Program manager | NC | Execute, Open, New, Copy, Delete, Export, Import |
| Alarm | Alarm list, Messages | Clear messages |
| System | Machine data | Blank setup, Switch to FANUC, Reset tool data |

Siemens tool list shows **Length X / Length Z** as positive values (internally `-geomX / -geomZ`); wear is entered as **Δ Length X / Δ Length Z** (±1.000 mm limit). Editing is direct (no key-in buffer): keypad keys type into the editor or MDA window; in tables they fill the selected cell and **INPUT** commits.

### MCP (machine control panel)
E-STOP · user keys (COOLANT, TOOL INDEX) · SINGLE BLOCK · ROV (feed override also applies to rapid) · modes **AUTO / MDA / JOG / REF POINT / HANDWHEEL** · increments **[VAR] 1 10 100 1000** (×0.001 mm; [VAR] = continuous jog while held) · axis keys ±X ±Z + RAPID · handwheel · spindle LEFT / STOP / RIGHT, SPDL −/100 %/+ · 0–120 % feed override rotary switch · RESET / CYCLE STOP / CYCLE START. There is no EDIT mode on the 808D; programs are edited in the Program area whenever the channel is not running.

### Siemens dialect → ISO translation
| SINUMERIK | Internal ISO | Note |
|---|---|---|
| `G71` / `G710`, `G70` / `G700` | `G21`, `G20` | In Siemens mode G71 = **metric**, not roughing |
| `G94`, `G95` | `G98`, `G99` | feed per minute / per revolution |
| `G90` / `G91` + `X Z` | `X Z` / `U W` | incremental mode handled by translator state |
| `CR=5` | `R5` | arc radius |
| `G96 S180 LIMS=2500` | `G96 S180 L2500` | spindle speed limit |
| `T1 D1` | `T0101` | tool + cutting edge (D0 cancels offset) |
| `G4 F1.5` | `G04 X1.5` | dwell seconds |
| `; text` | `(text)` | comments |
| `LABEL:` | `N9000n` | contour labels |
| `CYCLE95("S:E",MID,FALZ,FALX,FAL,FF1,FF2,FF3,VARI,DT,DAM,_VRT)` | `G71/G72 U.. R..` + `G71/G72 P Q U W F E1`, `G70 P Q F E1` | VARI 1–4 rough, 5–8 finish, 9–12 complete; odd = longitudinal, even = facing; 3/4 internal. FALX is a radius value (U = 2·FALX). `E1` = continue after the call, not after the contour |
| `G291` … `G290` | pass-through | ISO dialect section |
| `R1=…`, `X=R1+2` | evaluated values | see R variables |
| `CYCLE93(SPD,SPL,WIDG,DIAG,…)` | G0/G1/G4 plunge sequence | rectangular OD groove only |
| `GOTOF`, `IF`, other `CYCLExx` | alarm 12080 | not simulated yet |


### Parameter screens, JOG functions and R variables
- **Cycle parameter screens (programGUIDE style).** CYCLE95 and CYCLE93 open a field list with units, per-field hint text and a sketch. ▲▼ select a field, digits fill it, INPUT confirms, SELECT / ◀ ▶ toggle option fields (VARI). Accept writes the call at the cursor. With the cursor on an existing CYCLE95 line, the screen is prefilled from it and Accept **recompiles** that line (N-number and comment kept).
- **JOG functions.** T, S, M (tool, edge, spindle speed/direction, coolant, work offset) and Facing (X0, X1, Z0, Z1, DZ, F, V) generate a block sequence that runs in JOG on CYCLE START (`Runtime.runJogCycle`). Set WO writes the active G54–G59 shift so the current tool position reads the entered X Ø / Z.
- **R variables R0–R99.** Editable table in Offset. Programs may assign (`R1=20 R2=R1/2`) and use them in addresses (`X=R1+2`, `Z=-R2`, `CR=R3`) and cycle arguments. Operators + − × ÷ ( ), functions SIN COS TAN (degrees), ATAN2, SQRT, ABS, POT, TRUNC, ROUND. Division by zero raises 14051. Expressions are evaluated when the program is translated (no loops/jumps yet), and the final values are written back to the table after M30, so `R10=R10+1` acts as a part counter.
- **CYCLE93 (simplified).** Rectangular outside groove, VARI=1: SPD start Ø, SPL face-side groove edge, WIDG width, DIAG depth (radius), FAL1/FAL2 allowances, IDEP peck depth, DTB dwell, _VRT retract. Expands to plunges stepped by 0.9 × tool width (tool reference = chuck-side corner), pecks with 0.5 mm chip-break retract, then a finishing pass along both flanks and the base. Tool width comes from the tool data (grooving tools only): 61602 if no width or the groove is narrower than the tool, 61603 for flank angles, radii, chamfers or other VARI values.
- **Keys.** HELP shows context help for the active area/field. ^ RECALL closes help, parameter screens and Prog. ctrl, or returns to the Machine area.

Sample `GROOVE_R.MPF` uses R parameters, CYCLE95 VARI=9 (complete) and CYCLE93. Automated tests confirm Ø44 turned, a groove 6 wide and 3 deep (Ø38) at Z−20…−26, and R10 = 1 after the run.

A line map keeps every translated block attached to its original Siemens line, so block display, single block and editor error markers use the source line numbers. Alarm numbers are shown in 808D style (for example 12080 syntax error, 14040 circle end point, 10720 software limit switch, 3000 emergency stop, 14080 jump destination not found, 10930/10931 stock-removal contour); simulator-only checks use the 700xxx PLC-alarm range. `TURN_SHAFT.MPF` produces the same part as `O1001` within 0.02 mm (automated test).

## 8. Mobile and web delivery stack (production recommendation)
| Concern | Web | Mobile |
|---|---|---|
| Framework | React 18 + Vite, installable PWA (offline via Workbox) | React Native 0.76 (New Architecture) + Expo |
| Core | `@lathelab/core` (TypeScript) in a Web Worker | Same package, run in a worklet thread |
| 2D | Canvas 2D / OffscreenCanvas | `@shopify/react-native-skia` |
| 3D | Three.js r160, WebGL2 (WebGPU renderer flag) | `expo-gl` + three |
| Storage | wa-sqlite on OPFS | op-sqlite |
| Editor | CodeMirror 6 with a G-code Lezer grammar built from the same token tables | Custom virtualized editor with the same diagnostics |
| Haptics | — | Detent haptic on each MPG click, and heavy haptic on alarms |
| Sync / API | REST (`/programs`, `/machines/:id/offsets`, `/sessions`) + WebSocket for classroom live view | Same |
| Telemetry | Anonymous alarm-type counts and performance frames (opt-in) | Same |

---

## 9. Quality strategy
- **Unit tests** (implemented, 17 passing on Node 20):
  - Lexer: comments, block delete, decimal modes.
  - Parser errors: PS0010, PS0034, PS0035, PS0063.
  - Arc centre side and PS0020 tolerance.
  - G71 roughing pass count and resume-after-Q.
  - G72 level expansion.
  - T-code re-expression.
  - Complete runs of all three sample programs with no alarms.
  - O1001 finished diameters within 0.02 mm.
  - Wear offset shifting the diameter to 19.95.
  - Single block and feed hold.
- **Golden-file toolpath tests:** export step polylines as JSON and diff them against reference captures from a real controller or a known-good simulator, with 0.001 mm tolerance.
- **Property tests:** random monotonic profiles checking that G71 cuts never pass the offset profile and that roughing plus G70 equals the finished profile.
- **Visual regression:** Playwright screenshots of 2D and 3D at 1600×900, 1366×768 and 390×844, using SwiftShader in CI.
- **Performance CI:** a 100k-block program must parse in under 150 ms, and a 60-second simulated run must keep frame times under 16.7 ms at p95 on a reference device.

---

## 10. Prototype — how to run
```
cd cnc-sim
node --test tests/                        # 17 core tests
python3 -m http.server 8765 -d app        # open http://localhost:8765
```
**Quick tour:**
1. Choose **MEM**, then press **CYCLE START**. O1001 roughs with G71 using T01, changes to T02 and finishes with G70.
2. Switch to **Split** to watch the 3D part being cut.
3. On **OFS/SET › WEAR**, key in `-0.02` and press **INPUT**, then re-run.
4. Load O1002 (G72 facing) with `O1002` + ▼.
5. In **MDI**, try `G00 X30 Z-10` to see the SIM001 rapid-into-stock alarm, then press **RESET**.
6. In **HANDLE**, turn the MPG.

---

## 11. Roadmap
| Phase | Scope |
|---|---|
| 0.2 | G41/G42 nose-radius compensation (offset curves + imaginary tip 0–9); G73/G74/G75; threading G32/G92/G76 with a spindle-synchronised helix in 3D |
| 0.3 | M98/M99 subprograms, macro B variables and `IF/GOTO/WHILE`, program restart from N |
| 0.4 | Holder/turret collision, tool-life management, instructor classroom mode with assignments and grading |
| 0.5 | Mill mode: G17/G18/G19, G43 length compensation, G81–G89 drilling cycles, tri-dexel WASM material engine |
| 1.0 | Haas and Siemens dialect packs, CAM post-processor import, marketplace for exercises |
