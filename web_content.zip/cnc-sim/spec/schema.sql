-- ============================================================================
-- LatheLab — Tool & Offset Management schema
-- Target: SQLite 3.38+ (on-device, mobile & desktop web via wa-sqlite/OPFS)
--         PostgreSQL 15+ (cloud sync) — differences noted inline.
-- Units: all lengths stored in millimetres (REAL, 4 decimal places at the
--        application layer). X values follow the controller convention:
--        X geometry/wear are DIAMETER values, R (nose radius) is radius.
-- ============================================================================
PRAGMA foreign_keys = ON;

-- ---------------------------------------------------------------------------
-- 1. Machine profile (one row per simulated machine / controller)
-- ---------------------------------------------------------------------------
CREATE TABLE machine (
  machine_id        TEXT PRIMARY KEY,                 -- UUID v7
  name              TEXT NOT NULL,                    -- "2-axis slant bed, 8\" chuck"
  controller        TEXT NOT NULL DEFAULT 'FANUC_0I_TF'
                    CHECK (controller IN ('FANUC_0I_TF','FANUC_0I_MF','HAAS_NGC','SIEMENS_828D')),
  kinematics        TEXT NOT NULL DEFAULT 'LATHE_XZ'
                    CHECK (kinematics IN ('LATHE_XZ','LATHE_XZC','MILL_XYZ')),
  turret_stations   INTEGER NOT NULL DEFAULT 12 CHECK (turret_stations BETWEEN 1 AND 24),
  offset_count      INTEGER NOT NULL DEFAULT 64 CHECK (offset_count BETWEEN 1 AND 400),
  diameter_prog     INTEGER NOT NULL DEFAULT 1,       -- 1 = X is diameter (param 1006#3)
  decimal_mode      TEXT NOT NULL DEFAULT 'CALCULATOR'
                    CHECK (decimal_mode IN ('CALCULATOR','STANDARD')), -- param 3401#0
  max_wear_input    REAL NOT NULL DEFAULT 1.0,        -- max |Δwear| per entry (param 5013-style)
  x_limit_neg       REAL NOT NULL DEFAULT -420.0,     -- soft limits, machine coords
  z_limit_neg       REAL NOT NULL DEFAULT -600.0,
  rapid_x_mm_min    REAL NOT NULL DEFAULT 12000,
  rapid_z_mm_min    REAL NOT NULL DEFAULT 12000,
  max_rpm           INTEGER NOT NULL DEFAULT 4000,
  created_at        TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  updated_at        TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);

-- ---------------------------------------------------------------------------
-- 2. Tool catalogue (physical tools, independent of where they are mounted)
-- ---------------------------------------------------------------------------
CREATE TABLE tool (
  tool_id           TEXT PRIMARY KEY,                 -- UUID v7
  owner_id          TEXT,                             -- user/org; NULL = built-in library
  name              TEXT NOT NULL,                    -- "CNMG 120408 OD ROUGH"
  tool_type         TEXT NOT NULL CHECK (tool_type IN
                    ('OD_ROUGH','OD_FINISH','FACE','GROOVE','PART_OFF','THREAD','BORE','DRILL','TAP','CENTER_DRILL')),
  hand              TEXT NOT NULL DEFAULT 'R' CHECK (hand IN ('R','L','N')),
  iso_insert        TEXT,                             -- "CNMG 120408-PM"
  insert_shape      TEXT CHECK (insert_shape IN ('C','D','V','T','W','S','R','GROOVE','THREAD','ROUND')),
  included_angle    REAL CHECK (included_angle BETWEEN 0 AND 180),   -- 80 for C, 55 for D, 35 for V
  inscribed_circle  REAL,                             -- IC, mm
  nose_radius       REAL NOT NULL DEFAULT 0 CHECK (nose_radius >= 0),
  cutting_width     REAL,                             -- groove / part-off width
  diameter          REAL,                             -- drills, boring-bar min bore
  tip_direction     INTEGER NOT NULL DEFAULT 3 CHECK (tip_direction BETWEEN 0 AND 9), -- Fanuc imaginary tip 0-9
  holder            TEXT,                             -- "PCLNR 2525M12"
  overhang          REAL,                             -- stick-out, for 3D model & collision
  max_depth_of_cut  REAL,
  material_grade    TEXT,                             -- "GC4325"
  mesh_uri          TEXT,                             -- optional glTF for 3D renderer
  created_at        TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  updated_at        TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  deleted_at        TEXT                              -- soft delete for sync tombstones
);
CREATE INDEX idx_tool_owner_type ON tool(owner_id, tool_type) WHERE deleted_at IS NULL;

-- ---------------------------------------------------------------------------
-- 3. Turret stations — which tool is mounted at which pocket of which machine
-- ---------------------------------------------------------------------------
CREATE TABLE turret_station (
  machine_id        TEXT NOT NULL REFERENCES machine(machine_id) ON DELETE CASCADE,
  station           INTEGER NOT NULL CHECK (station >= 1),        -- the "nn" of Tnnoo
  tool_id           TEXT REFERENCES tool(tool_id) ON DELETE SET NULL,
  default_offset    INTEGER,                                      -- usual "oo" for this pocket
  orientation_deg   REAL NOT NULL DEFAULT 0,                      -- holder rotation on turret face
  is_live           INTEGER NOT NULL DEFAULT 0,                   -- driven tool (C-axis roadmap)
  updated_at        TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  PRIMARY KEY (machine_id, station)
);
CREATE UNIQUE INDEX uq_turret_tool ON turret_station(machine_id, tool_id) WHERE tool_id IS NOT NULL;

-- ---------------------------------------------------------------------------
-- 4. Tool offsets — Fanuc "memory C": geometry and wear kept separately.
--    Effective offset = geometry + wear. One row per offset number.
-- ---------------------------------------------------------------------------
CREATE TABLE tool_offset (
  machine_id        TEXT NOT NULL REFERENCES machine(machine_id) ON DELETE CASCADE,
  offset_no         INTEGER NOT NULL CHECK (offset_no >= 1),      -- the "oo" of Tnnoo
  geom_x            REAL NOT NULL DEFAULT 0,                      -- diameter value
  geom_z            REAL NOT NULL DEFAULT 0,
  wear_x            REAL NOT NULL DEFAULT 0,                      -- diameter value
  wear_z            REAL NOT NULL DEFAULT 0,
  nose_radius       REAL NOT NULL DEFAULT 0 CHECK (nose_radius >= 0),   -- R (geometry)
  wear_radius       REAL NOT NULL DEFAULT 0,                             -- R (wear)
  tip_direction     INTEGER NOT NULL DEFAULT 0 CHECK (tip_direction BETWEEN 0 AND 9), -- T
  comment           TEXT,
  version           INTEGER NOT NULL DEFAULT 1,                   -- optimistic concurrency / sync
  updated_at        TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  PRIMARY KEY (machine_id, offset_no),
  CHECK (abs(wear_x) <= 5.0 AND abs(wear_z) <= 5.0)               -- cumulative wear sanity
);

-- ---------------------------------------------------------------------------
-- 5. Work coordinate systems (G54–G59 + EXT shift "00")
-- ---------------------------------------------------------------------------
CREATE TABLE work_offset (
  machine_id        TEXT NOT NULL REFERENCES machine(machine_id) ON DELETE CASCADE,
  code              TEXT NOT NULL CHECK (code IN ('EXT','G54','G55','G56','G57','G58','G59')),
  x                 REAL NOT NULL DEFAULT 0,
  z                 REAL NOT NULL DEFAULT 0,
  updated_at        TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  PRIMARY KEY (machine_id, code)
);

-- ---------------------------------------------------------------------------
-- 6. Tool life management (optional, Fanuc TLM-style)
-- ---------------------------------------------------------------------------
CREATE TABLE tool_life (
  machine_id        TEXT NOT NULL REFERENCES machine(machine_id) ON DELETE CASCADE,
  station           INTEGER NOT NULL,
  life_unit         TEXT NOT NULL DEFAULT 'PARTS' CHECK (life_unit IN ('PARTS','MINUTES','METRES')),
  life_limit        REAL NOT NULL,
  life_used         REAL NOT NULL DEFAULT 0,
  alarm_at_pct      REAL NOT NULL DEFAULT 90,
  PRIMARY KEY (machine_id, station),
  FOREIGN KEY (machine_id, station) REFERENCES turret_station(machine_id, station) ON DELETE CASCADE
);

-- ---------------------------------------------------------------------------
-- 7. Audit trail — every INPUT / +INPUT / MEASUR on the OFS/SET screen
--    (drives the MESSAGE › OFS LOG screen, instructor review, and undo)
-- ---------------------------------------------------------------------------
CREATE TABLE offset_history (
  history_id        INTEGER PRIMARY KEY AUTOINCREMENT,            -- BIGSERIAL in Postgres
  machine_id        TEXT NOT NULL REFERENCES machine(machine_id) ON DELETE CASCADE,
  target            TEXT NOT NULL CHECK (target IN ('TOOL_OFFSET','WORK_OFFSET','TURRET')),
  key_no            TEXT NOT NULL,                                -- offset_no, 'G54', station
  field             TEXT NOT NULL,                                -- 'wear_x', 'geom_z', ...
  old_value         REAL,
  new_value         REAL,
  method            TEXT NOT NULL CHECK (method IN ('INPUT','PLUS_INPUT','MEASURE','IMPORT','SYNC','UNDO')),
  user_id           TEXT,
  session_id        TEXT,                                         -- simulation session
  at                TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE INDEX idx_hist_machine_at ON offset_history(machine_id, at DESC);

-- Trigger: bump version + updated_at and write audit row automatically
CREATE TRIGGER trg_offset_audit AFTER UPDATE ON tool_offset
FOR EACH ROW WHEN OLD.wear_x IS NOT NEW.wear_x OR OLD.wear_z IS NOT NEW.wear_z
               OR OLD.geom_x IS NOT NEW.geom_x OR OLD.geom_z IS NOT NEW.geom_z
BEGIN
  UPDATE tool_offset SET version = OLD.version + 1,
         updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now')
   WHERE machine_id = NEW.machine_id AND offset_no = NEW.offset_no;
  INSERT INTO offset_history(machine_id, target, key_no, field, old_value, new_value, method)
  SELECT NEW.machine_id, 'TOOL_OFFSET', NEW.offset_no, f, o, n, 'INPUT' FROM (
    SELECT 'wear_x' f, OLD.wear_x o, NEW.wear_x n WHERE OLD.wear_x IS NOT NEW.wear_x UNION ALL
    SELECT 'wear_z',   OLD.wear_z,   NEW.wear_z   WHERE OLD.wear_z IS NOT NEW.wear_z UNION ALL
    SELECT 'geom_x',   OLD.geom_x,   NEW.geom_x   WHERE OLD.geom_x IS NOT NEW.geom_x UNION ALL
    SELECT 'geom_z',   OLD.geom_z,   NEW.geom_z   WHERE OLD.geom_z IS NOT NEW.geom_z);
END;

-- ---------------------------------------------------------------------------
-- 8. NC programs + simulation sessions (context for offsets)
-- ---------------------------------------------------------------------------
CREATE TABLE nc_program (
  program_id        TEXT PRIMARY KEY,
  owner_id          TEXT,
  o_number          INTEGER NOT NULL CHECK (o_number BETWEEN 1 AND 9999),
  title             TEXT,
  source            TEXT NOT NULL,                                -- raw G-code
  dialect           TEXT NOT NULL DEFAULT 'FANUC_0I_TF',
  checksum          TEXT NOT NULL,                                -- sha256(source) for cache keys
  updated_at        TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  UNIQUE (owner_id, o_number)
);
CREATE TABLE sim_session (
  session_id        TEXT PRIMARY KEY,
  machine_id        TEXT NOT NULL REFERENCES machine(machine_id),
  program_id        TEXT REFERENCES nc_program(program_id),
  stock_dia         REAL NOT NULL, stock_len REAL NOT NULL, face_stock REAL NOT NULL DEFAULT 1,
  started_at        TEXT NOT NULL, ended_at TEXT,
  cycle_time_s      REAL, alarms_json TEXT,                        -- JSON array of alarms raised
  removed_cm3       REAL
);

-- ---------------------------------------------------------------------------
-- 9. Convenience view — what the controller actually applies for Tnnoo
-- ---------------------------------------------------------------------------
CREATE VIEW v_effective_offset AS
SELECT o.machine_id, o.offset_no,
       o.geom_x + o.wear_x         AS eff_x,
       o.geom_z + o.wear_z         AS eff_z,
       o.nose_radius + o.wear_radius AS eff_r,
       o.tip_direction,
       ts.station, t.name AS tool_name, t.tool_type
  FROM tool_offset o
  LEFT JOIN turret_station ts ON ts.machine_id = o.machine_id AND ts.default_offset = o.offset_no
  LEFT JOIN tool t ON t.tool_id = ts.tool_id;

-- ---------------------------------------------------------------------------
-- Example: T0101 on a new machine
-- ---------------------------------------------------------------------------
-- INSERT INTO machine(machine_id, name) VALUES ('m1', 'Demo 2-axis lathe');
-- INSERT INTO tool(tool_id, name, tool_type, insert_shape, included_angle, nose_radius, tip_direction)
--   VALUES ('t1', 'CNMG 120408 OD ROUGH', 'OD_ROUGH', 'C', 80, 0.8, 3);
-- INSERT INTO turret_station(machine_id, station, tool_id, default_offset) VALUES ('m1', 1, 't1', 1);
-- INSERT INTO tool_offset(machine_id, offset_no, geom_x, geom_z, nose_radius, tip_direction)
--   VALUES ('m1', 1, -201.25, -150.80, 0.8, 3);
-- UPDATE tool_offset SET wear_x = wear_x - 0.02 WHERE machine_id='m1' AND offset_no=1;  -- "+INPUT -0.02"
