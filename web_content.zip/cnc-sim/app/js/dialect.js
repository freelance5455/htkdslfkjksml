// ============================================================================
// Dialect layer. The core parser/interpreter speak the ISO / Fanuc 0i-T
// dialect. SINUMERIK 808D (native "Siemens mode") programs are translated
// here into equivalent ISO blocks, with a line map so highlighting, alarms
// and single-block still refer to the original Siemens source lines.
//
// Supported Siemens constructs (808D turning):
//   ; comments, %_N_..._MPF headers, labels (NAME:), N-numbers
//   G0 G1 G2 G3 (CR= / I K), G4 F<s>, G90/G91, G94/G95, G96 S.. LIMS=, G97,
//   G71/G710 (metric!) G70/G700 (inch!), G40-G42, G54-G59, G500, DIAMON
//   T<n> D<n> tool + cutting edge, M3 M4 M5 M8 M9 M0 M1 M2 M30 M17
//   CYCLE95("START:END", MID, FALZ, FALX, FAL, FF1, FF2, FF3, VARI, DT, DAM, _VRT)
//   G291 (switch to ISO dialect) / G290 (back to Siemens)
// ============================================================================
import { parseProgram } from './parser.js';

export const detectDialect = (name = '') => (/\.(MPF|SPF)$/i.test(name) ? 'siemens' : 'fanuc');

const IGNORE = new Set(['DIAMON', 'DIAMOF', 'DIAM90', 'SUPA', 'G500', 'G18', 'CFC', 'CFTCP', 'SOFT', 'BRISK', 'G64', 'G60', 'G601']);
const UNSUPPORTED = /\b(GOTOF|GOTOB|GOTO|IF|WHILE|ENDIF|ENDWHILE|REPEAT|UNTIL|DEF)\b|\bCYCLE(?!9[35]\b)\d+|\bLCYC/;
const G_MAP = { 71: 21, 710: 21, 70: 20, 700: 20, 94: 98, 95: 99 };

// ---- R-parameter arithmetic (808D: R0..R99, + - * / ( ), SIN COS TAN ATAN2 SQRT ABS POT TRUNC ROUND) ----
const FUNCS = {
  SIN: (a) => Math.sin((a * Math.PI) / 180), COS: (a) => Math.cos((a * Math.PI) / 180), TAN: (a) => Math.tan((a * Math.PI) / 180),
  ATAN2: (a, b) => (Math.atan2(a, b) * 180) / Math.PI, SQRT: Math.sqrt, ABS: Math.abs, POT: (a) => a * a, TRUNC: Math.trunc, ROUND: Math.round,
};
export function evalExpr(src, R) {
  const toks = []; const re = /\s*(\d+\.?\d*|\.\d+|R\d+|[A-Z]+|[-+*/(),])/y; let m; re.lastIndex = 0;
  const s = src.trim();
  while (re.lastIndex < s.length) { m = re.exec(s); if (!m) throw { code: '12080', message: `SYNTAX ERROR IN TEXT (${s})` }; toks.push(m[1]); }
  let i = 0; const peek = () => toks[i], next = () => toks[i++];
  const expr = () => { let v = term(); while (peek() === '+' || peek() === '-') v = next() === '+' ? v + term() : v - term(); return v; };
  const term = () => {
    let v = factor();
    while (peek() === '*' || peek() === '/') { const op = next(); const r = factor(); if (op === '/' && r === 0) throw { code: '14051', message: 'ARITHMETIC ERROR IN PART PROGRAM (DIVISION BY 0)' }; v = op === '*' ? v * r : v / r; }
    return v;
  };
  const factor = () => {
    const t = next();
    if (t === '-') return -factor(); if (t === '+') return factor();
    if (t === '(') { const v = expr(); if (next() !== ')') throw { code: '12080', message: 'SYNTAX ERROR IN TEXT (MISSING ")")' }; return v; }
    if (t && /^R\d+$/.test(t)) { const n = +t.slice(1); if (n > 99) throw { code: '12080', message: `SYNTAX ERROR IN TEXT (${t})` }; return R[n]; }
    if (t && FUNCS[t]) {
      if (next() !== '(') throw { code: '12080', message: `SYNTAX ERROR IN TEXT (${t})` };
      const args = [expr()]; while (peek() === ',') { next(); args.push(expr()); }
      if (next() !== ')') throw { code: '12080', message: 'SYNTAX ERROR IN TEXT (MISSING ")")' };
      const v = FUNCS[t](...args); if (!Number.isFinite(v)) throw { code: '14051', message: `ARITHMETIC ERROR IN PART PROGRAM (${t})` }; return v;
    }
    if (t !== undefined && /^[\d.]/.test(t)) return parseFloat(t);
    throw { code: '12080', message: `SYNTAX ERROR IN TEXT (${t ?? 'EXPRESSION'})` };
  };
  const v = expr(); if (i < toks.length) throw { code: '12080', message: `SYNTAX ERROR IN TEXT (${toks[i]})` };
  return v;
}
const isNum = (s) => /^[+-]?(\d+\.?\d*|\.\d+)$/.test(s);

export function translateSiemens(src, opts = {}) {
  const R = Array.from({ length: 100 }, (_, k) => +(opts.R?.[k] ?? 0));
  const srcLines = src.replace(/\r/g, '').split('\n');
  const out = []; const lineMap = []; const errors = [];
  const labels = new Map();
  // pass 1 — labels → synthetic sequence numbers
  srcLines.forEach((l) => {
    const m = /^\s*(?:N\d+\s+)?([A-Z_][A-Z0-9_]{1,31}):(?!=)/i.exec(l);
    if (m) labels.set(m[1].toUpperCase(), 90000 + labels.size);
  });
  let inc = false, iso = false, curTool = 1;
  const push = (text, ln) => { out.push(text); lineMap.push(ln); };
  const fmt = (v) => String(+(+v).toFixed(4));

  srcLines.forEach((raw, i) => {
    const ln = i + 1;
    let line = raw;
    if (iso) { if (/\bG290\b/i.test(line)) { iso = false; push('', ln); } else push(line, ln); return; }
    if (/\bG291\b/i.test(line)) { iso = true; push('', ln); return; }
    if (/^\s*%_N_/i.test(line)) { push(`(${line.trim().replace(/[()]/g, '')})`, ln); return; }
    // comment
    let comment = '';
    const sc = line.indexOf(';');
    if (sc >= 0) { comment = line.slice(sc + 1).replace(/[()]/g, '').trim(); line = line.slice(0, sc); }
    line = line.toUpperCase();
    // label
    let prefix = '';
    const lm = /^\s*(N\d+\s+)?([A-Z_][A-Z0-9_]{1,31}):(?!=)/.exec(line);
    if (lm) { prefix = `N${labels.get(lm[2])} `; line = line.slice(lm[0].length); }
    const cm = comment ? ` (${comment})` : '';
    // R parameters: assignments R1=.. and address values X=R1+2 / CR=R3 / cycle arguments
    try {
      const cyc = /(CYCLE9[35])\s*\(([^)]*)\)/.exec(line);
      if (cyc) {
        const args = cyc[2].split(',').map((a) => { const t = a.trim(); return !t || t.startsWith('"') || isNum(t) ? t : String(+evalExpr(t, R).toFixed(4)); });
        line = line.slice(0, cyc.index) + `${cyc[1]}(${args.join(',')})` + line.slice(cyc.index + cyc[0].length);
      } else if (line.includes('=')) {
        line = line.trim().split(/\s+/).map((tok) => {
          const ra = /^R(\d+)=(.+)$/.exec(tok);
          if (ra) { const n = +ra[1]; if (n > 99) throw { code: '12080', message: `SYNTAX ERROR IN TEXT (R${n})` }; R[n] = evalExpr(ra[2], R); return ''; }
          const aa = /^([A-Z]{1,4})=(.+)$/.exec(tok);
          if (aa && !isNum(aa[2])) return `${aa[1]}=${+evalExpr(aa[2], R).toFixed(4)}`;
          return tok;
        }).filter(Boolean).join(' ');
      }
    } catch (err) {
      errors.push({ line: ln, col: 1, code: err.code || '12080', message: err.message || 'SYNTAX ERROR IN TEXT' });
      push(cm.trim(), ln); return;
    }
    if (UNSUPPORTED.test(line)) {
      errors.push({ line: ln, col: 1, code: '12080', message: `SYNTAX ERROR IN TEXT (${line.trim().split(/\s+/)[0]} NOT SUPPORTED IN SIMULATOR)` });
      push(cm.trim(), ln); return;
    }
    // CYCLE95
    const cy = /CYCLE95\s*\(([^)]*)\)/.exec(line);
    if (cy) {
      const a = cy[1].split(',').map((s) => s.trim());
      const npp = (a[0] || '').replace(/"/g, '');
      const [l1, l2] = npp.split(':');
      const n1 = labels.get(l1), n2 = labels.get(l2);
      const pre = line.slice(0, cy.index).trim();
      if (n1 === undefined || n2 === undefined) {
        errors.push({ line: ln, col: 1, code: '14080', message: `JUMP DESTINATION NOT FOUND (${npp || 'CONTOUR'})` });
        push(cm.trim(), ln); return;
      }
      const num = (k, d = 0) => (a[k] === undefined || a[k] === '' ? d : parseFloat(a[k]));
      const MID = num(1), FAL = num(4), FALZ = num(2) || FAL, FALX = num(3) || FAL;
      const FF1 = num(5), FF3 = num(7) || FF1, VARI = num(8, 1), VRT = num(11, 0.5) || 0.5;
      const type = (VARI - 1) % 4;               // 0 long-ext, 1 face-ext, 2 long-int, 3 face-int
      const phase = Math.ceil(VARI / 4);         // 1 rough, 2 finish, 3 complete
      const internal = type >= 2, face = type % 2 === 1;
      const U = (internal ? -2 : 2) * FALX;
      const G = face ? 72 : 71;
      if (pre) push(pre, ln);
      if (phase === 1 || phase === 3) {
        if (!(MID > 0)) errors.push({ line: ln, col: 1, code: '61101', message: 'CYCLE95: DEPTH OF CUT MID MUST BE > 0' });
        push(`${prefix}G${G} ${face ? 'W' : 'U'}${fmt(MID)} R${fmt(VRT)}`, ln);
        push(`G${G} P${n1} Q${n2} U${fmt(U)} W${fmt(FALZ)} F${fmt(FF1)} E1${cm}`, ln);
      }
      if (phase === 2 || phase === 3) push(`${phase === 2 ? prefix : ''}G70 P${n1} Q${n2} F${fmt(FF3)} E1`, ln);
      return;
    }
    // CYCLE93 — rectangular outside groove (simplified subset, see spec 7A)
    const g93 = /CYCLE93\s*\(([^)]*)\)/.exec(line);
    if (g93) {
      const a = g93[1].split(',').map((x) => x.trim());
      const num = (k, d = 0) => (a[k] === undefined || a[k] === '' ? d : parseFloat(a[k]));
      const SPD = num(0), SPL = num(1), WIDG = num(2), DIAG = num(3);
      const shape = [4, 5, 6, 7, 8, 9, 10].some((k) => num(k) !== 0);
      const FAL1 = num(11), FAL2 = num(12), IDEP = num(13), DTB = num(14), VARI = num(15, 1), VRT = num(16, 1) || 1;
      const w = opts.toolWidth?.(curTool) || 0;
      const err = (code, message) => { errors.push({ line: ln, col: 1, code, message }); push(cm.trim(), ln); };
      if (!(WIDG > 0) || !(DIAG > 0) || shape || VARI !== 1) return err('61603', 'GROOVE FORM DEFINED INCORRECTLY (SIMULATOR: RECTANGULAR OD GROOVE, VARI=1)');
      if (!(w > 0) || w > WIDG - 2 * FAL2 + 1e-9) return err('61602', `TOOL WIDTH DEFINED INCORRECTLY (T${curTool} WIDTH ${w || 0})`);
      const xs = SPD + 2 * VRT, xB = SPD - 2 * DIAG, xR = xB + 2 * FAL1;
      const zFirst = SPL - FAL2 - w, zLast = SPL - WIDG + FAL2;
      const span = zFirst - zLast; const nSteps = span > 1e-9 ? Math.ceil(span / (0.9 * w)) : 0;
      const pos = Array.from({ length: nSteps + 1 }, (_, k) => (nSteps ? zFirst - (span * k) / nSteps : zFirst));
      const pre = line.slice(0, g93.index).trim();
      if (pre) push(pre, ln);
      push(`${prefix}G0 X${fmt(xs)}`, ln);
      const depth = (SPD - xR) / 2; const step = IDEP > 0 ? IDEP : depth;
      for (const z of pos) {
        push(`G0 Z${fmt(z)}`, ln); push(`G0 X${fmt(SPD + 1)}`, ln);
        for (let d = step; d < depth - 1e-6; d += step) { push(`G1 X${fmt(SPD - 2 * d)}`, ln); push(`G0 X${fmt(SPD - 2 * d + 1)}`, ln); }
        push(`G1 X${fmt(xR)}`, ln);
        if (DTB > 0) push(`G4 X${fmt(DTB)}`, ln);
        push(`G0 X${fmt(xs)}`, ln);
      }
      if (FAL1 > 0 || FAL2 > 0) {
        push(`G0 Z${fmt(SPL - WIDG)}`, ln); push(`G0 X${fmt(SPD + 1)}`, ln);
        push(`G1 X${fmt(xB)}`, ln); push(`G1 Z${fmt(SPL - w)}`, ln); push(`G1 X${fmt(SPD)}`, ln); push(`G0 X${fmt(xs)}`, ln);
      }
      return;
    }
    // words
    const words = [];
    let T = null, D = null, isG4 = false;
    const re = /([A-Z_]+)\s*(=)?\s*([+-]?(?:\d+\.?\d*|\.\d+))?/g;
    let m;
    const toks = [];
    while ((m = re.exec(line))) { if (m[0].trim()) toks.push({ k: m[1], v: m[3] }); }
    if (toks.some((t) => t.k === 'G' && +t.v === 4)) isG4 = true;
    for (const t of toks) {
      const { k, v } = t;
      if (IGNORE.has(k) || IGNORE.has(k + (v ?? ''))) continue;
      if (v === undefined) { errors.push({ line: ln, col: 1, code: '12080', message: `SYNTAX ERROR IN TEXT (${k})` }); continue; }
      const n = parseFloat(v);
      if (k === 'G') {
        if (n === 90) { inc = false; continue; }
        if (n === 91) { inc = true; continue; }
        if (n === 500) continue;
        words.push(`G${G_MAP[n] ?? v}`); continue;
      }
      if (k === 'CR') { words.push(`R${v}`); continue; }
      if (k === 'LIMS') { words.push(`L${v}`); continue; }
      if (k === 'T') { T = n; continue; }
      if (k === 'D') { D = n; continue; }
      if (k === 'F' && isG4) { words.push(`X${v}`); continue; }
      if (k === 'S' && isG4) continue;
      if (k === 'M' && (n === 17)) { words.push('M99'); continue; }
      if ((k === 'X' || k === 'Z') && inc) { words.push(`${k === 'X' ? 'U' : 'W'}${v}`); continue; }
      if (k.length > 1) { errors.push({ line: ln, col: 1, code: '12080', message: `SYNTAX ERROR IN TEXT (${k})` }); continue; }
      words.push(`${k}${v}`);
    }
    if (T !== null || D !== null) {
      const tool = T ?? curTool; curTool = tool;
      const off = D === 0 ? 0 : D === null || D === 1 ? tool : D;
      words.push(`T${String(tool).padStart(2, '0')}${String(off).padStart(2, '0')}`);
    }
    push(`${prefix}${words.join(' ')}${cm}`.trim(), ln);
  });
  return { text: out.join('\n'), lineMap, errors, R };
}

/** Parse a program in either dialect; returns a normal ParseResult (lines = source lines). */
export function parseAny(src, dialect = 'fanuc', opts = {}) {
  if (dialect !== 'siemens') return parseProgram(src);
  const t = translateSiemens(src, opts);
  const p = parseProgram(t.text, { lineMap: t.lineMap });
  p.errors = [...t.errors, ...p.errors];
  p.translated = t.text;
  p.dialect = 'siemens'; p.rFinal = t.R;
  return p;
}

/** Siemens 808D-style alarm numbers for the shared alarm codes. */
export const SIEMENS_ALARMS = {
  PS0003: ['12080', 'Syntax error in text'], PS0004: ['12080', 'Syntax error in text'], PS0005: ['12080', 'Syntax error in text'],
  PS0006: ['12080', 'Syntax error in text'], PS0007: ['12080', 'Syntax error in text'], PS0009: ['12080', 'Syntax error in text'],
  PS0010: ['12470', 'G function unknown'], PS0011: ['10860', 'Feedrate not programmed'], PS0020: ['14040', 'Error in end point of circle'],
  PS0029: ['17180', 'Illegal D number'], PS0030: ['17190', 'Illegal T number'], PS0034: ['12080', 'Syntax error in text'],
  PS0035: ['12080', 'Syntax error in text'], PS0036: ['12080', 'Syntax error in text'], PS0061: ['14080', 'Jump destination not found'],
  PS0062: ['10930', 'Illegal interpolation type in stock removal contour'], PS0063: ['14080', 'Jump destination not found'],
  PS0064: ['10931', 'Error in stock removal contour'], PS0065: ['10930', 'Illegal interpolation type in stock removal contour'],
  PS0070: ['12080', 'Syntax error in text'], PS0071: ['14011', 'Program not available'], PS0078: ['14011', 'Program not available'],
  SIM001: ['700001', 'Rapid traverse into workpiece'], SIM002: ['700002', 'Spindle not running during feed'],
  SIM003: ['10720', 'Software limit switch'], 12080: ['12080', 'Syntax error in text'], 14051: ['14051', 'Arithmetic error in part program'],
  61602: ['61602', 'Tool width defined incorrectly'], 61603: ['61603', 'Groove form defined incorrectly'], 61101: ['61101', 'Cycle parameter defined incorrectly'], 14080: ['14080', 'Jump destination not found'], SIM004: ['700004', 'Collision with chuck'], EMG: ['3000', 'Emergency stop'],
};
export function siemensAlarm(code, message = '') {
  const m = SIEMENS_ALARMS[code];
  if (m) {
    const ctx = /@L(\d+)/.exec(message); const detail = /\(([^)]*)\)/.exec(message);
    const ax = code === 'SIM003' ? /[+-][XZ]/.exec(message) : null;
    return { num: m[0], text: m[1] + (ax ? ` ${ax[0]}` : '') + (detail ? ` (${detail[1]})` : '') + (ctx ? `  Block L${ctx[1]}` : '') };
  }
  return { num: code, text: message };
}
