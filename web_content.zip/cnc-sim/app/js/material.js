// ============================================================================
// Material-removal model for turning: a 1-D radial height-field r(z).
// Because a lathe part is axisymmetric, a radius per Z-slice is an exact
// representation (a "dexel" per slice). Milling mode would use a tri-dexel /
// sparse voxel grid — see spec §5.4.
// ============================================================================
export class Stock {
  constructor({ dia = 50, length = 80, face = 1, chuck = 25, dz = 0.05 } = {}) {
    Object.assign(this, { dia, length, face, chuck, dz });
    this.z0 = face;                          // front face Z (work coordinates)
    this.n = Math.ceil((length) / dz) + 1;
    this.r = new Float32Array(this.n).fill(dia / 2);
    this.version = 0;
  }
  idx(z) { return Math.round((this.z0 - z) / this.dz); }
  zAt(i) { return this.z0 - i * this.dz; }
  /** Sweep tool tip from a to b (diameter coords). Returns 'collision' if a rapid engaged material. */
  /**
   * @param edge optional trailing cutting edge of the insert: {tan, len}. The edge runs from the
   *        tip toward +Z at angle atan(tan) above the Z axis, so points (z + d, r + d*tan) are
   *        also inside the tool. Without it a point tool would leave slivers between facing levels.
   */
  sweep(a, b, rapid, tol = 0.05, edge = null) {
    const ra = a.x / 2, rb = b.x / 2;
    const len = Math.hypot(b.z - a.z, rb - ra);
    const steps = Math.max(1, Math.ceil(len / (this.dz * 0.5)));
    let changed = false, collision = false;
    for (let s = 0; s <= steps; s++) {
      const t = s / steps;
      const z = a.z + (b.z - a.z) * t, r = Math.max(0, ra + (rb - ra) * t);
      const i = this.idx(z);
      const m = edge ? Math.ceil(edge.len / this.dz) : 0;
      for (let j = 0; j <= m; j++) {
        const ii = i - j;                         // +Z direction = lower index
        if (ii < 0 || ii >= this.n) continue;
        const rr = r + j * this.dz * (edge ? edge.tan : 0);
        if (this.r[ii] > rr + 1e-6) {
          if (rapid && this.r[ii] - rr > tol) collision = true;
          this.r[ii] = rr; changed = true;
        }
      }
    }
    if (changed) this.version++;
    return collision ? 'collision' : changed ? 'cut' : null;
  }
  /** Down-sampled profile for rendering: [{z, r}] */
  profile(maxPts = 600) {
    const stride = Math.max(1, Math.floor(this.n / maxPts));
    const out = [];
    for (let i = 0; i < this.n; i += stride) {
      let m = this.r[i];
      for (let j = i; j < Math.min(this.n, i + stride); j++) m = Math.min(m, this.r[j]);
      out.push({ z: this.zAt(i), r: m });
    }
    out.push({ z: this.zAt(this.n - 1), r: this.r[this.n - 1] });
    return out;
  }
  removedVolume() {
    let v = 0; const R = this.dia / 2;
    for (let i = 0; i < this.n; i++) v += Math.PI * (R * R - this.r[i] * this.r[i]) * this.dz;
    return v / 1000; // cm³
  }
}
