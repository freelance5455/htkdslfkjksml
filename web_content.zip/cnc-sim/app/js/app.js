// ============================================================================
// App shell / UI controller. Wires: ToolDB + Stock + Runtime (core) to the
// Fanuc-style CRT, MDI keypad, machine operator panel and 2D/3D renderers.
// ============================================================================
import { ToolDB, TOOL_TYPES, kv } from './tooldb.js';
import { Stock } from './material.js';
import { Runtime, fmtTime } from './runtime.js';
import { Renderer2D } from './render2d.js';
import { PROGRAMS, SIEMENS_PROGRAMS } from './programs.js';
import { detectDialect, siemensAlarm } from './dialect.js';
import { initSiemens } from './siemens.js';
import { parseProgram, describeBlock } from './parser.js';
import { compile, feedMmMin, RAPID_MM_MIN } from './interpreter.js';

const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const f3 = (v) => (v < 0 ? '-' : ' ') + Math.abs(v).toFixed(3).padStart(8, ' ');
const f4 = (v) => (v < 0 ? '-' : ' ') + Math.abs(v).toFixed(3);

// ---------------- program library (key/value adapter) ----------------
const LIB_KEY = 'cncsim.programs.v2';
const lib = (() => { try { return JSON.parse(kv.getItem(LIB_KEY)) || { ...PROGRAMS, ...SIEMENS_PROGRAMS }; } catch { return { ...PROGRAMS, ...SIEMENS_PROGRAMS }; } })();
const saveLib = () => { try { kv.setItem(LIB_KEY, JSON.stringify(lib)); } catch {} };

// ---------------- core objects ----------------
const db = new ToolDB();
let stockCfg = { dia: 50, length: 80, face: 1, chuck: 25 };
const rt = new Runtime({ db, stock: new Stock(stockCfg) });
let activeProg = Object.keys(lib)[0];
rt.load(lib[activeProg], detectDialect(activeProg));
let ctrl = 'fanuc';

// ---------------- UI state ----------------
const ui = { fn: 'PROG', sub: { POS: 'ALL', PROG: 'PRG', OFS: 'WEAR', GRAPH: 'PARAM', MSG: 'ALARM' }, keyin: '', ofsSel: { row: 0, field: 'wearX' }, memCursor: 0, mdi: '', mpgAxis: 'x', estimate: 0 };
const c2d = new Renderer2D($('#c2d'), rt);
let r3d = null;
async function ensure3D() {
  if (r3d) return r3d;
  try { const { Renderer3D } = await import('./render3d.js'); r3d = new Renderer3D($('#c3d'), rt); r3d.resize(); }
  catch (e) { $('#c3d').innerHTML = `<p style="padding:20px;color:#ff8a8a">3D engine failed to load (${e.message}). 2D view remains available.</p>`; }
  return r3d;
}

// ---------------- estimate cycle time ----------------
function estimate() {
  if (!rt.parsed || rt.parsed.errors.length) return 0;
  const r = compile(rt.parsed, rt.state, rt.ctx());
  let t = 0;
  for (const s of r.steps) {
    if (s.k === 'dwell') t += s.sec;
    if (s.k !== 'move') continue;
    let len = 0; for (let i = 1; i < s.pts.length; i++) len += Math.hypot(s.pts[i].z - s.pts[i - 1].z, (s.pts[i].x - s.pts[i - 1].x) / 2);
    const f = s.rapid ? RAPID_MM_MIN : feedMmMin(s.feed, s.pts[0].x);
    if (f > 0) t += (len / f) * 60;
  }
  return t;
}
function loadProgram(key) {
  activeProg = key; rt.load(lib[key], detectDialect(key)); ui.estimate = estimate(); ui.memCursor = 0;
  renderScreen(); updateStatus(); sie?.render();
}

// ================= CRT SCREENS =================
const SOFTKEYS = {
  POS: [['ALL', 'ALL'], ['PTCNT', 'PT-CNT 0'], ['RUNTM', 'RUN-T 0'], ['', ''], ['', '']],
  PROG: {
    EDIT: [['PRG', 'PROGRAM'], ['DIR', 'DIR'], ['CHECK', 'CHECK'], ['NEW', 'NEW'], ['EXPORT', 'EXPORT']],
    MEM: [['PRG', 'PROGRAM'], ['DIR', 'DIR'], ['CHECK', 'CHECK'], ['REWIND', 'REWIND'], ['', '']],
    MDI: [['PRG', 'MDI'], ['CHECK', 'CHECK'], ['CLEAR', 'CLEAR'], ['', ''], ['', '']],
    OTHER: [['PRG', 'PROGRAM'], ['DIR', 'DIR'], ['CHECK', 'CHECK'], ['', ''], ['', '']],
  },
  OFS: [['WEAR', 'WEAR'], ['GEOM', 'GEOM'], ['TOOLS', 'TURRET'], ['WORK', 'WORK'], ['MEASUR', 'MEASUR']],
  GRAPH: [['2d', '2D'], ['3d', '3D'], ['split', 'SPLIT'], ['CLRTRAIL', 'CLR PATH'], ['RESTOCK', 'NEW STOCK']],
  MSG: [['ALARM', 'ALARM'], ['HIST', 'HISTORY'], ['OFSLOG', 'OFS LOG'], ['CLEAR', 'CLEAR'], ['', '']],
};
function softkeys() {
  let keys = SOFTKEYS[ui.fn];
  if (ui.fn === 'PROG') keys = keys[rt.mode] || keys.OTHER;
  const sub = ui.sub[ui.fn];
  $('#softkeys').innerHTML = keys.map(([id, label]) => `<button data-sk="${id}" class="${id && id === sub ? 'on' : ''}">${label}</button>`).join('');
}
const TITLES = { POS: 'ACTUAL POSITION', PROG: 'PROGRAM', OFS: 'TOOL OFFSET', GRAPH: 'GRAPHIC PARAMETER', MSG: 'ALARM MESSAGE' };

function renderScreen() {
  $$('#fkeys button').forEach((b) => b.classList.toggle('on', b.dataset.fn === ui.fn));
  const body = $('#crtBody');
  let title = TITLES[ui.fn];
  if (ui.fn === 'OFS') title = { WEAR: 'TOOL OFFSET (WEAR)', GEOM: 'TOOL OFFSET (GEOMETRY)', TOOLS: 'TURRET / TOOL LIST', WORK: 'WORK COORDINATES', MEASUR: 'TOOL OFFSET (GEOMETRY)' }[ui.sub.OFS];
  if (ui.fn === 'PROG' && ui.sub.PROG === 'DIR') title = 'PROGRAM DIRECTORY';
  if (ui.fn === 'PROG' && rt.mode === 'MDI') title = 'PROGRAM (MDI)';
  $('#crtTitle').textContent = title;
  softkeys();
  if (ui.fn === 'POS') body.innerHTML = posHTML();
  else if (ui.fn === 'PROG') renderProg(body);
  else if (ui.fn === 'OFS') body.innerHTML = ofsHTML();
  else if (ui.fn === 'GRAPH') body.innerHTML = graphHTML();
  else if (ui.fn === 'MSG') body.innerHTML = msgHTML();
  updateLive();
}

function modalLine() {
  const s = rt.state;
  return `G${String(s.motion).padStart(2, '0')} G18 G${s.feedMode} G${s.css ? 96 : 97} G${s.units} G${s.tnrc} G${s.wcs}`;
}
function posHTML() {
  return `<div class="pos-grid">
    <div class="pos-big"><span>X</span><span id="pX"></span><span>Z</span><span id="pZ"></span></div>
    <div class="pos-sec"><h4>MACHINE</h4><div><span>X</span><span id="mX"></span></div><div><span>Z</span><span id="mZ"></span></div></div>
    <div class="pos-sec"><h4>DISTANCE TO GO</h4><div><span>X</span><span id="dX"></span></div><div><span>Z</span><span id="dZ"></span></div></div>
  </div>
  <div class="kv">
    <span>ACT.F</span><span id="pF"></span><span>ACT.S</span><span id="pS"></span>
    <span>T</span><span id="pT"></span><span>SPDL</span><span id="pSp"></span>
    <span>PART</span><span id="pPart"></span><span>RUN</span><span id="pRun"></span>
    <span>CYC.EST</span><span>${fmtTime(ui.estimate)}</span><span>COOL</span><span id="pCool"></span>
  </div>
  <div class="modal-line" id="pModal"></div>`;
}

function renderProg(body) {
  const sub = ui.sub.PROG;
  if (sub === 'DIR') {
    const rows = Object.keys(lib).filter((k) => detectDialect(k) === 'fanuc').sort().map((k) => {
      const p = parseProgram(lib[k]);
      return `<tr data-prog="${k}" class="${k === activeProg ? 'active' : ''}"><td>${k}</td><td style="text-align:left">${(p.programName || '').slice(0, 30)}</td><td>${lib[k].length}</td></tr>`;
    }).join('');
    body.innerHTML = `<table class="ofs-table"><tr><th>O-NO.</th><th style="text-align:left">COMMENT</th><th>SIZE</th></tr>${rows}</table>
      <p class="ofs-note">Tap a program to select it. Key in <b>O1234</b> then ▼ to search, or <b>O1234</b> + DELETE to remove.</p>
      <p class="ofs-note"><label class="ghost" style="display:inline-block;cursor:pointer">IMPORT .NC <input type="file" id="importNc" accept=".nc,.txt,.tap,.gcode,.ngc" hidden></label></p>`;
    return;
  }
  if (sub === 'CHECK') { body.innerHTML = checkHTML(); return; }
  if (rt.mode === 'MDI') {
    body.innerHTML = `<div class="mdi-hint">MDI: key in blocks (EOB = ;) then INSERT, or type directly. CYCLE START executes. Modal: <span id="mdiModal"></span></div>
      <div class="editor"><div class="gutter" id="gutter"></div><textarea id="mdiText" spellcheck="false" aria-label="MDI program">${ui.mdi}</textarea></div>`;
    const ta = $('#mdiText');
    ta.addEventListener('input', () => { ui.mdi = ta.value.toUpperCase(); gutter(ta, parseProgram(ui.mdi)); });
    gutter(ta, parseProgram(ui.mdi));
    $('#mdiModal').textContent = modalLine();
    return;
  }
  if (rt.mode === 'EDIT') {
    body.innerHTML = `<div class="editor"><div class="gutter" id="gutter"></div><textarea id="editor" spellcheck="false" aria-label="Program editor"></textarea></div><div id="errs"></div>`;
    const ta = $('#editor'); ta.value = lib[activeProg];
    let tmr;
    ta.addEventListener('input', () => {
      const pos = ta.selectionStart; ta.value = ta.value.toUpperCase(); ta.selectionStart = ta.selectionEnd = pos;
      gutter(ta, parseProgram(ta.value));
      clearTimeout(tmr); tmr = setTimeout(() => commitEditor(), 350);
    });
    ta.addEventListener('scroll', () => { $('#gutter').scrollTop = ta.scrollTop; });
    gutter(ta, rt.parsed);
    errList(rt.parsed);
    return;
  }
  // MEM / other: read-only listing with execution highlight
  const lines = lib[activeProg].split('\n');
  body.innerHTML = `<div class="proglist" id="plist">${lines.map((l, i) => {
    const html = esc(l).replace(/(\([^)]*\))/g, '<span class="cm">$1</span>');
    return `<span class="ln" data-l="${i + 1}">${html || ' '}</span>`;
  }).join('')}</div>`;
}
function commitEditor() {
  const ta = $('#editor'); if (!ta) return;
  lib[activeProg] = ta.value; saveLib(); rt.load(ta.value, detectDialect(activeProg)); ui.estimate = estimate(); errList(rt.parsed); updateStatus();
}
function gutter(ta, parsed) {
  const n = ta.value.split('\n').length;
  const bad = new Set(parsed.errors.map((e) => e.line));
  $('#gutter').innerHTML = Array.from({ length: n }, (_, i) => bad.has(i + 1) ? `<span class="err">!${i + 1}</span>` : `${i + 1}`).join('\n');
  $('#gutter').scrollTop = ta.scrollTop;
}
function errList(parsed) {
  const el = $('#errs'); if (!el) return;
  const all = [...parsed.errors, ...(rt.previewAlarms || [])];
  el.innerHTML = all.length
    ? `<div class="errlist">${all.slice(0, 6).map((e) => `L${e.line} ${e.code} ${esc(e.message)}`).join('<br>')}</div>`
    : `<div class="okline">✓ ${parsed.blocks.length} BLOCKS · NO ALARMS · EST ${fmtTime(ui.estimate)}</div>`;
}
function checkHTML() {
  const p = rt.mode === 'MDI' ? parseProgram(ui.mdi) : rt.parsed;
  const rows = p.blocks.slice(0, 200).map((b) => `<tr><td>${b.line}</td><td style="text-align:left">${b.n != null ? 'N' + b.n : ''}</td><td style="text-align:left">${esc(describeBlock(b) || Object.entries(b.words).map(([k, v]) => k + v).join(' '))}</td></tr>`).join('');
  return `<div class="${p.errors.length ? 'errlist' : 'okline'}">${p.errors.length ? p.errors.length + ' ERROR(S)' : 'SYNTAX OK'} · ${p.warnings.length} WARNING(S)</div>
    <table class="ofs-table"><tr><th>LINE</th><th style="text-align:left">SEQ</th><th style="text-align:left">DECODED</th></tr>${rows}</table>`;
}

const OFS_FIELDS = { WEAR: [['wearX', 'X'], ['wearZ', 'Z'], ['radius', 'R'], ['tip', 'T']], GEOM: [['geomX', 'X'], ['geomZ', 'Z'], ['radius', 'R'], ['tip', 'T']] };
function ofsHTML() {
  const sub = ui.sub.OFS === 'MEASUR' ? 'GEOM' : ui.sub.OFS;
  if (sub === 'TOOLS') {
    return `<table class="ofs-table"><tr><th>ST</th><th style="text-align:left">TYPE</th><th style="text-align:left">DESCRIPTION</th><th>Ø</th><th>R</th></tr>${db.data.tools.map((t) =>
      `<tr class="${t.station === rt.state.tool ? 'active' : ''}"><td>${t.station === rt.state.tool ? '▶' : ' '}T${String(t.station).padStart(2, '0')}</td><td style="text-align:left">${TOOL_TYPES[t.type]?.label ?? t.type}</td><td style="text-align:left">${esc(t.name)}</td><td>${t.diameter || '—'}</td><td>${t.noseRadius.toFixed(1)}</td></tr>`).join('')}</table>
      <p class="ofs-note">12-station turret (8 populated). Active station ▶. Command Tnnoo: nn = station, oo = offset number.</p>`;
  }
  if (sub === 'WORK') {
    return `<table class="ofs-table"><tr><th>WCS</th><th>X</th><th>Z</th></tr>${db.data.work.map((w, i) =>
      `<tr class="${'G' + rt.state.wcs === w.code ? 'active' : ''}"><td>${w.code}</td>${['x', 'z'].map((f) => `<td data-w="${i}" data-f="${f}" class="${ui.ofsSel.work === i && ui.ofsSel.wf === f ? 'sel' : ''}">${f4(w[f])}</td>`).join('')}</tr>`).join('')}</table>
      <p class="ofs-note">Work shift added to machine position. Select a cell, key in a value, INPUT.</p>`;
  }
  const fields = OFS_FIELDS[sub];
  const rows = db.data.offsets.map((o, i) => `<tr class="${o.n === rt.state.offset ? 'active' : ''}"><td>${o.n === rt.state.offset ? '▶' : ' '}${sub === 'WEAR' ? 'W' : 'G'}${String(o.n).padStart(3, '0')}</td>${fields.map(([f]) =>
    `<td data-row="${i}" data-f="${f}" class="${ui.ofsSel.row === i && ui.ofsSel.field === f ? 'sel' : ''}">${f === 'tip' ? o[f] : f4(o[f])}</td>`).join('')}</tr>`).join('');
  const m = rt.machinePos();
  const note = ui.sub.OFS === 'MEASUR'
    ? `<p class="ofs-note"><b style="color:#ffd43b">MEASURE:</b> touch the part, key in the measured value (e.g. X49.82 or Z0) and press INPUT. Geometry = machine − measured − wear. MACHINE X${m.x.toFixed(3)} Z${m.z.toFixed(3)}</p>`
    : `<p class="ofs-note">INPUT = set · +INPUT = add. ${sub === 'WEAR' ? 'Wear inputs limited to ±1.000 per entry.' : 'Use MEASUR to touch off.'} ▲▼ move cursor.</p>`;
  return `<table class="ofs-table"><tr><th>NO.</th>${fields.map(([, l]) => `<th>${l}</th>`).join('')}</tr>${rows}</table>${note}`;
}
function graphHTML() {
  const s = rt.stock;
  return `<div class="graph-info">
    STOCK       Ø${s.dia.toFixed(3)} × ${s.length.toFixed(3)}<br>
    FACE STOCK  ${s.face.toFixed(3)}   CHUCK GRIP ${s.chuck.toFixed(3)}<br>
    RESOLUTION  ΔZ ${s.dz.toFixed(3)} (${s.n} SLICES)<br>
    REMOVED     <span id="gVol"></span> cm³<br>
    PLANNED     ${rt.planned.length} SEGMENTS<br>
    CYCLE EST.  ${fmtTime(ui.estimate)}<br><br>
    VIEW: ${$('#stage').dataset.view.toUpperCase()} — drag to pan, wheel/pinch to zoom, double-click to fit.
    </div>`;
}
function msgHTML() {
  const sub = ui.sub.MSG;
  if (sub === 'OFSLOG') return `<div class="msg-list">${db.data.history.slice(0, 60).map((h) => `<div>${h.at.slice(11, 19)} OFS ${h.n} ${h.field} ${h.from} → ${h.to}</div>`).join('') || 'NO OFFSET CHANGES'}</div>`;
  const list = sub === 'ALARM' ? rt.alarms : rt.messages.slice(0, 80);
  if (!list.length) return `<div class="okline">${sub === 'ALARM' ? 'NO ALARM' : 'NO MESSAGES'}</div>`;
  return `<div class="msg-list">${list.map((m) => `<div class="${m.kind === 'alarm' || sub === 'ALARM' ? 'a' : ''}">${m.at.toTimeString().slice(0, 8)} ${m.code ? m.code + ' ' : ''}${esc(m.message)}</div>`).join('')}</div>`;
}
const esc = (s) => String(s).replace(/[&<>]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c]));

// ---------- live updates (10 Hz) ----------
function updateLive() {
  const s = rt.state, m = rt.machinePos();
  const set = (id, v) => { const el = document.getElementById(id); if (el) el.textContent = v; };
  set('pX', f3(s.x)); set('pZ', f3(s.z)); set('mX', f3(m.x)); set('mZ', f3(m.z));
  set('dX', f3(rt.running ? rt.dtg.x : 0)); set('dZ', f3(rt.running ? rt.dtg.z : 0));
  set('pF', Math.round(rt.liveFeed) + ' MM/MIN'); set('pS', Math.round(rt.liveRpm) + ' RPM');
  set('pT', `T${String(s.tool).padStart(2, '0')}${String(s.offset).padStart(2, '0')}`);
  set('pSp', s.spindle === 1 ? 'CW M03' : s.spindle === -1 ? 'CCW M04' : 'STOP'); set('pCool', s.coolant ? 'ON' : 'OFF');
  set('pPart', rt.parts); set('pRun', fmtTime(rt.cycleTime)); set('pModal', modalLine());
  set('gVol', rt.stock.removedVolume().toFixed(2));
  set('hudX', s.x.toFixed(3)); set('hudZ', s.z.toFixed(3)); set('hudF', Math.round(rt.liveFeed));
  set('hudS', Math.round(rt.liveRpm)); set('hudT', ctrl === 'siemens' ? `${s.tool} D${s.offset ? 1 : 0}` : `${String(s.tool).padStart(2, '0')}${String(s.offset).padStart(2, '0')}`);
  const blk = rt.parsed?.blocks.find((b) => b.line === rt.currentLine);
  set('crtProg', `${activeProg} N${String(blk?.n ?? 0).padStart(5, '0')}`);
  set('crtMode', rt.mode); set('crtClock', new Date().toTimeString().slice(0, 8));
  set('crtRun', rt.alarms.length ? 'ALM' : rt.running ? (rt.hold ? 'HOLD' : rt.stopped ? 'STOP' : 'STRT') : '****');
  // MEM listing highlight
  const pl = $('#plist');
  if (pl) {
    const cur = rt.running ? rt.currentLine : 0;
    if (pl.dataset.cur !== String(cur)) {
      pl.querySelector('.ln.cur')?.classList.remove('cur');
      const el = pl.querySelector(`.ln[data-l="${cur}"]`);
      if (el) { el.classList.add('cur'); el.scrollIntoView({ block: 'nearest' }); }
      pl.dataset.cur = String(cur);
    }
  }
  $('#keyin').textContent = ui.keyin;
}
function updateStatus() {
  $('#stMode').textContent = ctrl === 'siemens' ? ({ MEM: 'AUTO', MDI: 'MDA', ZRN: 'REF POINT', HND: 'HANDWHEEL' }[rt.mode] || rt.mode) : rt.mode;
  $('#stProg').textContent = activeProg;
  $('#stState').textContent = rt.estop ? 'EMG' : rt.running ? (rt.hold ? 'FEED HOLD' : rt.stopped ? 'BLOCK STOP' : 'CYCLE') : 'STOP';
  $('#lampRun').classList.toggle('on', rt.running && !rt.hold && !rt.stopped);
  const al = rt.alarms.length;
  $('#lampAlarm').classList.toggle('on', al > 0);
  const a0 = al && (ctrl === 'siemens' ? siemensAlarm(rt.alarms[0].code, rt.alarms[0].message) : { num: rt.alarms[0].code, text: rt.alarms[0].message });
  $('#stAlarm').textContent = al ? `${a0.num} ${a0.text}` : 'NO ALARM';
  $('#stAlarm').classList.toggle('on', al > 0);
  $('#btnStart').classList.toggle('lit', rt.running && !rt.hold && !rt.stopped);
  $('#btnHold').classList.toggle('lit', rt.running && (rt.hold || rt.stopped));
  $$('#modeGrid button').forEach((b) => b.classList.toggle('on', b.dataset.mode === rt.mode));
  $$('[data-tog]').forEach((b) => b.classList.toggle('on', !!rt[b.dataset.tog]));
  $$('[data-sp]').forEach((b) => b.classList.toggle('on', +b.dataset.sp === rt.state.spindle));
  $('#btnEstop').classList.toggle('on', rt.estop);
  $('.jog-pad .rap').classList.toggle('on', rt.jogRapid);
}

// ================= KEY HANDLING =================
function key(k) {
  if (k === 'CAN') { ui.keyin = ui.keyin.slice(0, -1); return updateLive(); }
  if (k === 'RESET') { rt.reset(); ui.keyin = ''; renderScreen(); return updateStatus(); }
  if (k === 'EOB') { ui.keyin += ';'; return updateLive(); }
  if (k === '(') { ui.keyin += ui.keyin.includes('(') && !ui.keyin.endsWith(')') ? ')' : '('; return updateLive(); }
  if (k.length === 1) { ui.keyin += k; return updateLive(); }
  if (ui.fn === 'OFS') return ofsKey(k);
  if (ui.fn === 'PROG') return progKey(k);
  if (k === 'UP' || k === 'DOWN') return;
}
function progKey(k) {
  const buf = ui.keyin.trim();
  // O-number search / delete
  if (/^O\d{1,4}$/.test(buf) && (k === 'DOWN' || k === 'DELETE')) {
    const key = 'O' + buf.slice(1).padStart(4, '0');
    if (k === 'DOWN') { if (lib[key]) { loadProgram(key); ui.keyin = ''; } else rt.alarm('PS0071', `DATA NOT FOUND ${key}`); }
    else if (lib[key] && Object.keys(lib).length > 1) { delete lib[key]; saveLib(); if (key === activeProg) loadProgram(Object.keys(lib)[0]); ui.keyin = ''; renderScreen(); }
    updateStatus(); return updateLive();
  }
  const ta = $('#editor') || $('#mdiText');
  if (!ta) return;
  const text = ta.value; const lines = text.split('\n');
  const caretLine = text.slice(0, ta.selectionStart).split('\n').length - 1;
  const newLines = buf.split(';').map((s) => s.trim()).filter(Boolean);
  if (k === 'UP' || k === 'DOWN') {
    const ln = Math.max(0, Math.min(lines.length - 1, caretLine + (k === 'UP' ? -1 : 1)));
    const pos = lines.slice(0, ln).join('\n').length + (ln ? 1 : 0);
    ta.focus(); ta.selectionStart = ta.selectionEnd = pos; return;
  }
  if (k === 'INSERT' && newLines.length) lines.splice(ta.id === 'mdiText' ? lines.length : caretLine + 1, 0, ...newLines);
  else if (k === 'ALTER' && newLines.length) lines.splice(caretLine, 1, ...newLines);
  else if (k === 'DELETE' && !buf) lines.splice(caretLine, 1);
  else if (k === 'INPUT' && ta.id === 'mdiText' && newLines.length) lines.push(...newLines);
  else return;
  ta.value = lines.filter((l, i) => l !== '' || i < lines.length - 1).join('\n');
  const keepLine = k === 'INSERT' ? caretLine + 1 : Math.min(caretLine, lines.length - 1);
  const caret = lines.slice(0, keepLine).join('\n').length + (keepLine ? 1 : 0);
  ta.selectionStart = ta.selectionEnd = Math.min(caret, ta.value.length);
  ui.keyin = '';
  ta.dispatchEvent(new Event('input'));
  updateLive();
}
function ofsKey(k) {
  const sub = ui.sub.OFS;
  if (sub === 'TOOLS') return;
  if (sub === 'WORK') {
    const w = ui.ofsSel.work ?? 0, f = ui.ofsSel.wf ?? 'z';
    if (k === 'UP' || k === 'DOWN') { ui.ofsSel.work = Math.max(0, Math.min(5, w + (k === 'UP' ? -1 : 1))); ui.ofsSel.wf = f; return renderScreen(); }
    if (k === 'INPUT' || k === '+INPUT') {
      const v = parseFloat(ui.keyin.replace(/^[XZ]/, ''));
      const pm = rt.machinePos();
      const e = db.setWork(db.data.work[w].code, f, v, k === '+INPUT');
      if (e) rt.message(e); else { rt.offsetsChanged(pm); ui.keyin = ''; }
      renderScreen(); rt.preview();
    }
    return;
  }
  const fields = OFS_FIELDS[sub === 'MEASUR' ? 'GEOM' : sub].map(([f]) => f);
  const { row } = ui.ofsSel;
  if (k === 'UP' || k === 'DOWN') { ui.ofsSel.row = Math.max(0, Math.min(db.data.offsets.length - 1, row + (k === 'UP' ? -1 : 1))); return renderScreen(); }
  if (k !== 'INPUT' && k !== '+INPUT') return;
  const o = db.data.offsets[row];
  const pm = rt.machinePos();
  let err;
  if (sub === 'MEASUR') {
    const mm = /^([XZ])(-?[\d.]+)$/.exec(ui.keyin.trim());
    if (!mm) { rt.message('MEASUR: KEY IN X<dia> OR Z<pos>'); return; }
    if (o.n !== rt.state.offset) { rt.message(`MEASUR: SELECT ACTIVE OFFSET ${rt.state.offset}`); return; }
    const ax = mm[1], val = parseFloat(mm[2]);
    const shift = db.workShift(rt.state.wcs);
    const machine = ax === 'X' ? pm.x : pm.z;
    const geom = machine - val - (ax === 'X' ? o.wearX + shift.x : o.wearZ + shift.z);
    err = db.setOffset(o.n, ax === 'X' ? 'geomX' : 'geomZ', geom, false);
    if (!err) rt.message(`MEASURED ${ax}${val.toFixed(3)} → GEOM ${ax} ${geom.toFixed(3)}`);
  } else {
    const field = fields.includes(ui.ofsSel.field) ? ui.ofsSel.field : fields[0];
    const v = parseFloat(ui.keyin.replace(/^[XZRT]/, ''));
    err = db.setOffset(o.n, field, v, k === '+INPUT');
  }
  if (err) rt.message(err); else { ui.keyin = ''; if (o.n === rt.state.offset) rt.offsetsChanged(pm); rt.preview(); ui.estimate = estimate(); }
  renderScreen(); updateStatus();
}

// runtime helper: keep machine (physical) position constant when offsets change
rt.offsetsChanged = function (prevMachine) {
  const o = this.off(), s = this.db.workShift(this.state.wcs);
  this.state.x = prevMachine.x - s.x - o.geomX - o.wearX;
  this.state.z = prevMachine.z - s.z - o.geomZ - o.wearZ;
};

function softkey(id) {
  if (!id) return;
  if (ui.fn === 'POS') { if (id === 'PTCNT') rt.parts = 0; if (id === 'RUNTM') rt.cycleTime = 0; return renderScreen(); }
  if (ui.fn === 'PROG') {
    if (id === 'NEW') {
      let n = 1004; while (lib['O' + n]) n++;
      lib['O' + n] = `%\nO${n} (NEW PROGRAM)\nG21 G99 G40\nT0101\nG97 S1000 M03\nG00 X54.0 Z2.0\nM30\n%`; saveLib(); loadProgram('O' + n); ui.sub.PROG = 'PRG'; return renderScreen();
    }
    if (id === 'EXPORT') { const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([lib[activeProg]], { type: 'text/plain' })); a.download = `${activeProg}.nc`; a.click(); return; }
    if (id === 'REWIND') { rt.abortExecution(); rt.message('PROGRAM REWOUND'); return renderScreen(); }
    if (id === 'CLEAR') { ui.mdi = ''; return renderScreen(); }
    ui.sub.PROG = id; return renderScreen();
  }
  if (ui.fn === 'OFS') { ui.sub.OFS = id; if (id === 'MEASUR') { ui.ofsSel.row = rt.state.offset - 1; } return renderScreen(); }
  if (ui.fn === 'GRAPH') {
    if (['2d', '3d', 'split'].includes(id)) { setView(id); ui.sub.GRAPH = id; }
    if (id === 'CLRTRAIL') rt.trail = [];
    if (id === 'RESTOCK') newStock();
    return renderScreen();
  }
  if (ui.fn === 'MSG') { if (id === 'CLEAR') rt.messages = []; else ui.sub.MSG = id; return renderScreen(); }
}
function newStock(cfg = stockCfg) {
  stockCfg = cfg; rt.stock = new Stock(cfg); rt.trail = [];
  $('#stockLbl').textContent = `${cfg.dia}×${cfg.length}`;
  if (r3d) { r3d.buildChuck(); r3d.lastVersion = -1; }
  c2d.fit();
}

// ================= EVENT BINDINGS =================
$('#fkeys').addEventListener('click', (e) => {
  const b = e.target.closest('button'); if (!b) return;
  ui.fn = b.dataset.fn;
  if (ui.fn === 'GRAPH' && innerWidth <= 960) window.scrollTo({ top: 0, behavior: 'smooth' });
  renderScreen();
});
$('#softkeys').addEventListener('click', (e) => { const b = e.target.closest('button'); if (b) softkey(b.dataset.sk); });
$('#keypad').addEventListener('click', (e) => { const b = e.target.closest('button'); if (!b) return; key(b.dataset.k || b.textContent.trim()); });
$('#crtBody').addEventListener('click', (e) => {
  const td = e.target.closest('td[data-f]');
  if (td && td.dataset.row !== undefined) { ui.ofsSel = { ...ui.ofsSel, row: +td.dataset.row, field: td.dataset.f }; renderScreen(); return; }
  if (td && td.dataset.w !== undefined) { ui.ofsSel.work = +td.dataset.w; ui.ofsSel.wf = td.dataset.f; renderScreen(); return; }
  const tr = e.target.closest('tr[data-prog]');
  if (tr) { if (rt.running) return rt.message('PROGRAM RUNNING'); loadProgram(tr.dataset.prog); ui.sub.PROG = 'PRG'; renderScreen(); }
});
$('#crtBody').addEventListener('change', (e) => {
  if (e.target.id !== 'importNc') return;
  const file = e.target.files[0]; if (!file) return;
  file.text().then((txt) => {
    const p = parseProgram(txt.toUpperCase());
    let key = p.programNumber ? 'O' + String(p.programNumber).padStart(4, '0') : 'O' + (9000 + Object.keys(lib).length);
    lib[key] = txt.toUpperCase().replace(/\r/g, ''); saveLib(); loadProgram(key); ui.sub.PROG = 'PRG'; renderScreen();
  });
});
// physical keyboard → key-in buffer when CRT focused (outside textareas)
$('#crt').addEventListener('keydown', (e) => {
  if (e.target.tagName === 'TEXTAREA') return;
  const k = e.key;
  if (/^[a-zA-Z0-9.\-]$/.test(k)) { key(k.toUpperCase()); e.preventDefault(); }
  else if (k === ';') key('EOB');
  else if (k === 'Backspace') { key('CAN'); e.preventDefault(); }
  else if (k === 'Enter') key(ui.fn === 'PROG' ? 'INSERT' : 'INPUT');
  else if (k === 'ArrowUp') { key('UP'); e.preventDefault(); } else if (k === 'ArrowDown') { key('DOWN'); e.preventDefault(); }
});

$('#modeGrid').addEventListener('click', (e) => {
  const b = e.target.closest('button'); if (!b) return;
  rt.setMode(b.dataset.mode);
  if (['EDIT', 'MEM', 'MDI'].includes(rt.mode)) { ui.fn = 'PROG'; ui.sub.PROG = 'PRG'; } else ui.fn = 'POS';
  if (rt.mode === 'EDIT') commitEditor();
  renderScreen(); updateStatus();
});
$$('[data-tog]').forEach((b) => b.addEventListener('click', () => { rt[b.dataset.tog] = !rt[b.dataset.tog]; if (b.dataset.tog === 'blockSkip') rt.preview(); updateStatus(); }));
$('#btnStart').addEventListener('click', () => {
  if (rt.mode === 'MDI' && !rt.running) { const ta = $('#mdiText'); if (ta) ui.mdi = ta.value; }
  rt.cycleStart(ui.mdi); updateStatus();
});
$('#btnHold').addEventListener('click', () => { rt.feedHold(); updateStatus(); });
$('#btnEstop').addEventListener('click', () => { if (rt.estop) { rt.estop = false; rt.message('E-STOP RELEASED — PRESS RESET'); } else rt.emergency(); updateStatus(); });
$('#ovFeed').addEventListener('input', (e) => { rt.feedOv = e.target.value / 100; $('#ovFeedV').textContent = e.target.value + '%'; });
$('#ovSp').addEventListener('input', (e) => { rt.spindleOv = e.target.value / 100; $('#ovSpV').textContent = e.target.value + '%'; });
$('#rapidOv').addEventListener('click', (e) => { const b = e.target.closest('button'); if (!b) return; rt.rapidOv = +b.dataset.r; $$('#rapidOv button').forEach((x) => x.classList.toggle('on', x === b)); });
$('#simSpeed').addEventListener('change', (e) => { rt.simSpeed = +e.target.value; });
rt.simSpeed = 5;
$$('[data-sp]').forEach((b) => b.addEventListener('click', () => { if (rt.mode !== 'JOG' && rt.mode !== 'HND' && +b.dataset.sp !== 0) return rt.message('SPINDLE KEYS: JOG/HANDLE MODE'); rt.spindle(+b.dataset.sp); updateStatus(); }));
$('#incSel').addEventListener('click', (e) => { const b = e.target.closest('button'); if (!b) return; rt.increment = +b.dataset.i; $$('#incSel button').forEach((x) => x.classList.toggle('on', x === b)); });
$('#mpgAxis').addEventListener('click', (e) => { const b = e.target.closest('button'); if (!b) return; ui.mpgAxis = b.dataset.a; $$('#mpgAxis button').forEach((x) => x.classList.toggle('on', x === b)); });

// jog pad: press-and-hold
$$('[data-jog]').forEach((b) => {
  const j = b.dataset.jog;
  if (j === 'rapid') { b.addEventListener('click', () => { rt.jogRapid = !rt.jogRapid; updateStatus(); }); return; }
  const axis = j[0], dir = j[1] === '+' ? 1 : -1;
  const down = (e) => {
    e.preventDefault(); b.classList.add('press');
    if (rt.mode === 'JOG') rt.startJog(axis, dir);
    else if (rt.mode === 'HND') { rt.handleClick(axis, dir); }
    else if (rt.mode === 'ZRN') { if (dir > 0) rt.referenceReturn(axis); }
    else rt.message('JOG KEYS: SELECT JOG, HANDLE OR REF MODE');
    updateStatus();
  };
  const up = () => { b.classList.remove('press'); rt.stopJog(); };
  b.addEventListener('pointerdown', down); b.addEventListener('pointerup', up); b.addEventListener('pointerleave', up); b.addEventListener('pointercancel', up);
});
// MPG handwheel: 100 detents / rev
(() => {
  const mpg = $('#mpg'), knob = $('#mpgKnob'); let last = null, rot = 0, acc = 0;
  const ang = (e) => { const r = mpg.getBoundingClientRect(); return Math.atan2(e.clientY - (r.top + r.height / 2), e.clientX - (r.left + r.width / 2)); };
  mpg.addEventListener('pointerdown', (e) => { mpg.setPointerCapture(e.pointerId); last = ang(e); });
  mpg.addEventListener('pointermove', (e) => {
    if (last === null) return;
    const a = ang(e); let d = a - last; if (d > Math.PI) d -= 2 * Math.PI; if (d < -Math.PI) d += 2 * Math.PI; last = a;
    rot += d; acc += d; knob.style.transform = `rotate(${rot}rad)`;
    const step = (2 * Math.PI) / 100; const clicks = Math.trunc(acc / step);
    if (clicks) { acc -= clicks * step; if (rt.mode === 'HND') rt.handleClick(ui.mpgAxis, clicks); else if (Math.abs(clicks) > 0 && !mpg._warned) { rt.message('MPG ACTIVE IN HANDLE MODE ONLY'); mpg._warned = true; } }
  });
  const up = () => { last = null; }; mpg.addEventListener('pointerup', up); mpg.addEventListener('pointercancel', up);
  mpg.addEventListener('keydown', (e) => { if (e.key === 'ArrowRight' || e.key === 'ArrowUp') rt.handleClick(ui.mpgAxis, 1); if (e.key === 'ArrowLeft' || e.key === 'ArrowDown') rt.handleClick(ui.mpgAxis, -1); });
})();

// viewport
function setView(v) {
  $('#stage').dataset.view = v;
  $$('.vp-toolbar .seg button').forEach((b) => b.classList.toggle('on', b.dataset.view === v));
  if (v !== '2d') ensure3D().then(() => requestAnimationFrame(() => { r3d?.resize(); c2d.resize(); }));
  requestAnimationFrame(() => c2d.fit());
}
$$('.vp-toolbar .seg button').forEach((b) => b.addEventListener('click', () => setView(b.dataset.view)));
$('#optPlanned').addEventListener('change', (e) => { c2d.show.planned = e.target.checked; if (r3d) r3d.plannedLine.visible = e.target.checked; });
$('#optTrail').addEventListener('change', (e) => { c2d.show.trail = e.target.checked; if (r3d) r3d.trailLine.visible = e.target.checked; });
$('#btnFit').addEventListener('click', () => c2d.fit());
$('#btnStock').addEventListener('click', () => { const d = $('#stockDlg'); const f = d.querySelector('form'); f.dia.value = stockCfg.dia; f.len.value = stockCfg.length; f.face.value = stockCfg.face; f.chuck.value = stockCfg.chuck; d.showModal(); });
$('#stockDlg').addEventListener('close', () => {
  const d = $('#stockDlg'); if (d.returnValue !== 'ok') return; const f = d.querySelector('form');
  newStock({ dia: +f.dia.value || 50, length: +f.len.value || 80, face: +f.face.value || 0, chuck: +f.chuck.value || 20 });
});
$('#mtabs').addEventListener('click', (e) => {
  const b = e.target.closest('button'); if (!b) return;
  $('#machine').dataset.mt = b.dataset.mt; $$('#mtabs button').forEach((x) => x.classList.toggle('on', x === b));
});
$('#machine').dataset.mt = 'cnc';

// ================= CONTROLLER SWITCH (FANUC 0i-TF / SINUMERIK 808D) =================
let sie = null;
const api = {
  rt, db, lib, saveLib, loadProgram, setView, active: () => activeProg,
  openStock: () => $('#btnStock').click(), refreshEstimate: () => { ui.estimate = estimate(); },
  switchController: (c) => switchController(c),
};
let sieFirst = true;
function switchController(c) {
  if (rt.running) { rt.message('STOP THE PROGRAM BEFORE SWITCHING CONTROL'); return; }
  ctrl = c; document.body.dataset.ctrl = c;
  $$('#ctrlSwitch button').forEach((b) => b.classList.toggle('on', b.dataset.ctrl === c));
  $('#brandSub').textContent = c === 'siemens' ? '2-axis turning · SINUMERIK 808D dialect' : '2-axis turning · Fanuc 0i-T dialect';
  if (c === 'siemens') {
    if (!sie) sie = initSiemens(api);
    if (sieFirst && detectDialect(activeProg) !== 'siemens') { const k = Object.keys(lib).find((x) => detectDialect(x) === 'siemens'); if (k) loadProgram(k); }
    sieFirst = false; sie.activate();
  } else {
    rt.mdiDialect = 'fanuc';
    if (detectDialect(activeProg) === 'siemens') loadProgram(Object.keys(lib).find((x) => detectDialect(x) === 'fanuc') || activeProg);
    renderScreen();
  }
  updateStatus(); requestAnimationFrame(() => { c2d.resize(); r3d?.resize(); c2d.fit(); });
}
$('#ctrlSwitch').addEventListener('click', (e) => { const b = e.target.closest('button'); if (b) switchController(b.dataset.ctrl); });

rt.on((type, data) => {
  if (ctrl === 'siemens') { sie?.onEvent(type, data); updateStatus(); return; }
  if (type === 'finish' && rt.mode === 'MDI') { ui.mdi = ''; if (ui.fn === 'PROG') renderScreen(); }
  if (type === 'alarm') { if (ui.fn === 'MSG') renderScreen(); }
  if (type === 'program' && ui.fn === 'GRAPH') renderScreen();
  updateStatus();
});
window.addEventListener('resize', () => { c2d.resize(); r3d?.resize(); });
new ResizeObserver(() => { c2d.resize(); r3d?.resize(); }).observe($('#stage'));

// ================= MAIN LOOP =================
let lastT = performance.now(), lastUi = 0;
function frame(t) {
  const dt = Math.min(0.05, (t - lastT) / 1000); lastT = t;
  rt.tick(dt);
  const view = $('#stage').dataset.view;
  if (view !== '3d') c2d.draw();
  if (view !== '2d' && r3d) { r3d.draw(dt); }
  if (t - lastUi > 100) { updateLive(); if (ctrl === 'siemens') sie?.update(); updateStatus(); lastUi = t; }
  requestAnimationFrame(frame);
}
ui.estimate = estimate();
renderScreen(); updateStatus();
requestAnimationFrame(frame);
window.__sim = { rt, db, ui, lib, switchController, get sie() { return sie; } };
if (/siemens|808d/i.test(location.hash)) switchController('siemens'); // debugging / automated QA hook
