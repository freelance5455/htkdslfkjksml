// ============================================================================
// Machine Runtime — the "CNC kernel" of the simulator.
// Owns live machine state, executes compiled steps in real time with
// overrides, single block, feed hold, dry run, jog / MPG, alarms, and feeds
// the material model. UI and renderers subscribe to events; they never
// mutate machine state directly (unidirectional data flow).
// ============================================================================
import { parseAny } from './dialect.js';
import { TOOL_TYPES } from './tooldb.js';
import { compile, createState, feedMmMin, rpmAt, RAPID_MM_MIN, toolpathOf } from './interpreter.js';

export const MODES = ['EDIT', 'MEM', 'MDI', 'JOG', 'HND', 'ZRN'];
const LIMITS = { xMin: -420, xMax: 0, zMin: -600, zMax: 0 }; // machine coordinates

export class Runtime {
  constructor({ db, stock }) {
    this.db = db; this.stock = stock;
    this.mode = 'EDIT';
    this.state = createState({ offset: 1, tool: 1 });
    const h = this.homeAbs(); this.state.x = h.x; this.state.z = h.z;
    this.steps = []; this.si = 0; this.segProg = 0; this.dwellLeft = 0;
    this.running = false; this.hold = false; this.stopped = false;
    this.singleBlock = false; this.dryRun = false; this.optStop = false; this.blockSkip = false;
    this.feedOv = 1; this.rapidOv = 1; this.spindleOv = 1; this.simSpeed = 1;
    this.jogFeed = 1200; this.jogRapid = false; this.increment = 0.1; this.jogging = null;
    this.alarms = []; this.messages = [];
    this.trail = []; this.planned = [];
    this.currentLine = 0; this.cycleTime = 0; this.parts = 0;
    this.source = ''; this.parsed = null;
    this.listeners = new Set();
    this.liveFeed = 0; this.liveRpm = 0; this.dtg = { x: 0, z: 0 };
    this.estop = false;
  }
  on(f) { this.listeners.add(f); return () => this.listeners.delete(f); }
  emit(type, data) { this.listeners.forEach((f) => f(type, data)); }

  // ---- coordinates -------------------------------------------------------
  off() { return this.db.getOffset(this.state.offset) || { geomX: 0, geomZ: 0, wearX: 0, wearZ: 0 }; }
  machinePos() {
    const o = this.off(), s = this.db.workShift(this.state.wcs);
    return { x: this.state.x + s.x + o.geomX + o.wearX, z: this.state.z + s.z + o.geomZ + o.wearZ };
  }
  homeAbs() {
    const o = this.off(), s = this.db.workShift(this.state.wcs);
    return { x: -(s.x + o.geomX + o.wearX), z: -(s.z + o.geomZ + o.wearZ) };
  }
  /** trailing cutting-edge footprint of the active insert (see Stock.sweep) */
  edge() {
    const t = this.db.tool(this.state.tool); const type = TOOL_TYPES[t?.type];
    if (!type || t.type === 'DRILL' || t.type === 'THREAD') return null;
    if (t.type === 'GROOVE') return { tan: 0, len: t.width || 3.0 };
    const deg = Math.max(0, 45 - type.angle / 2);
    return { tan: Math.tan((deg * Math.PI) / 180), len: 4.0 };
  }
  /** physical cutting point of an ideal tool = programmed + wear */
  tipPos(p = this.state) { const o = this.off(); return { x: p.x + o.wearX, z: p.z + o.wearZ }; }

  // ---- program management -----------------------------------------------
  load(source, dialect = 'fanuc') {
    this.source = source; this.dialect = dialect;
    this.parsed = parseAny(source, dialect, this.dialectOpts());
    this.preview();
    this.emit('program', this.parsed);
    return this.parsed;
  }
  /** options for the Siemens translator: R parameters + tool widths (CYCLE93) */
  dialectOpts() {
    const d = this.db.data; if (!d.rparams) d.rparams = Array(100).fill(0);
    return { R: d.rparams, toolWidth: (t) => { const tl = this.db.tool(t); return tl?.type === 'GROOVE' ? (tl.width || 3) : 0; } };
  }
  preview() {
    if (!this.parsed) return;
    const r = compile(this.parsed, this.state, this.ctx());
    this.planned = toolpathOf(r.steps);
    this.previewAlarms = r.alarms;
  }
  ctx() {
    return { getOffset: (n) => this.db.getOffset(n), workShift: (w) => this.db.workShift(w), blockSkip: this.blockSkip };
  }

  setMode(m) {
    if (this.running && !this.hold && !this.stopped) { this.message('STOP PROGRAM BEFORE CHANGING MODE'); return; }
    this.mode = m;
    if (m !== 'MEM' && m !== 'MDI') this.abortExecution();
    this.emit('mode', m);
  }

  // ---- execution ----------------------------------------------------------
  cycleStart(mdiSource) {
    if (this.estop) return this.alarm('EMG', 'EMERGENCY STOP');
    if (this.alarms.length) return this.message('RESET ALARM FIRST');
    if (this.running && (this.hold || this.stopped)) { this.pendingSnippet = null; this.hold = false; this.stopped = false; this.emit('run'); return; }
    const snippet = this.pendingSnippet; this.pendingSnippet = null;
    if (!snippet && this.mode !== 'MEM' && this.mode !== 'MDI') return this.message('CYCLE START: SELECT MEM OR MDI MODE');
    if (this.running) return;
    const parsed = snippet ? parseAny(snippet.src, snippet.dialect, this.dialectOpts())
      : this.mode === 'MDI' ? parseAny(mdiSource || '', this.mdiDialect || 'fanuc', this.dialectOpts()) : this.parsed;
    if (!parsed) return this.message('NO PROGRAM');
    if (parsed.errors.length) { parsed.errors.slice(0, 3).forEach((e) => this.alarm(e.code, `${e.message} @L${e.line}`)); return; }
    const r = compile(parsed, this.state, this.ctx());
    if (r.alarms.length) { r.alarms.forEach((a) => this.alarm(a.code, `${a.message} @L${a.line}`)); return; }
    this.steps = r.steps; this.si = 0; this.segProg = 0; this.dwellLeft = 0;
    this.running = true; this.hold = false; this.stopped = false;
    if (this.mode === 'MEM') { this.trail = []; this.planned = toolpathOf(r.steps); this.cycleTime = 0; }
    this.execSource = snippet ? 'JOGCYC' : this.mode;
    this.emit('run');
  }
  feedHold() { if (this.running) { this.hold = true; this.emit('hold'); } }
  reset() {
    this.abortExecution();
    this.alarms = []; this.state.spindle = 0; this.state.coolant = false; this.estop = false;
    this.emit('reset');
  }
  abortExecution() { this.running = false; this.hold = false; this.stopped = false; this.steps = []; this.si = 0; this.segProg = 0; this.currentLine = 0; this.emit('state'); }
  emergency() { this.estop = true; this.abortExecution(); this.state.spindle = 0; this.alarm('EMG', 'EMERGENCY STOP — RELEASE & RESET'); }

  alarm(code, message) {
    if (!this.alarms.some((a) => a.code === code && a.message === message)) this.alarms.push({ code, message, at: new Date() });
    this.messages.unshift({ kind: 'alarm', code, message, at: new Date() });
    this.hold = true;
    this.emit('alarm');
  }
  message(text) { this.messages.unshift({ kind: 'msg', message: text, at: new Date() }); this.emit('message', text); }

  // ---- jog / handle / reference return -----------------------------------
  startJog(axis, dir) { if (this.mode !== 'JOG' || this.estop || this.running) return; this.jogging = { axis, dir }; }
  stopJog() { this.jogging = null; this.liveFeed = 0; }
  handleClick(axis, clicks) {
    if (this.mode !== 'HND' || this.estop || this.running) return;
    const to = { ...this.state }; to[axis] += clicks * this.increment * (axis === 'x' ? 1 : 1);
    this.directMove(to, false);
  }
  /** run a generated block sequence from JOG (Siemens JOG cycles: T,S,M / facing) */
  runJogCycle(src, dialect = 'siemens') {
    if (this.mode !== 'JOG' && this.mode !== 'HND') return this.message('JOG CYCLES: SELECT JOG MODE');
    if (this.running) return this.message('CHANNEL ACTIVE');
    this.pendingSnippet = { src, dialect }; this.cycleStart();
  }
  /** Siemens-style incremental jog (JOG mode with 1/10/100/1000 increment selected) */
  jogIncrement(axis, dir) {
    if ((this.mode !== 'JOG' && this.mode !== 'HND') || this.estop || this.running) return;
    const to = { ...this.state }; to[axis] += dir * this.increment;
    this.directMove(to, false);
  }
  /** manual turret index (MCP tool key / T,S,M window): same offset maths as a T-word */
  indexTool(station, offset = station) {
    if (this.running || this.estop) return this.message('TURRET INDEX NOT ALLOWED NOW');
    const o0 = this.off(), o1 = this.db.getOffset(offset) || { geomX: 0, geomZ: 0, wearX: 0, wearZ: 0 };
    this.state.x += o0.geomX + o0.wearX - (o1.geomX + o1.wearX);
    this.state.z += o0.geomZ + o0.wearZ - (o1.geomZ + o1.wearZ);
    this.state.tool = station; this.state.offset = offset;
    this.emit('tool', { tool: station, offset }); this.emit('state');
  }
  referenceReturn(axis) {
    if (this.mode !== 'ZRN') return;
    const h = this.homeAbs();
    const to = { x: axis === 'z' ? this.state.x : h.x, z: axis === 'x' ? this.state.z : h.z };
    this.directMove(to, true);
    this.message(`REFERENCE RETURN ${axis.toUpperCase()} COMPLETE`);
  }
  spindle(dir) { if (this.mode === 'JOG' || this.mode === 'HND' || dir === 0) { this.state.spindle = dir; if (dir && !this.state.S) this.state.S = 800; this.emit('state'); } }

  /** immediate move with limit + collision checks (jog/handle) */
  directMove(to, rapid) {
    const from = { x: this.state.x, z: this.state.z };
    const lim = this.limitCheck(to);
    if (lim) { this.alarm('SIM003', `OVERTRAVEL ${lim}`); return false; }
    if (this.chuckCheck(to)) { this.alarm('SIM004', 'CHUCK COLLISION'); return false; }
    const res = this.stock.sweep(this.tipPos(from), this.tipPos(to), rapid, 0.05, this.edge());
    if (res === 'collision') this.alarm('SIM001', 'RAPID MOVE INTO STOCK');
    if (res && !rapid && this.state.spindle === 0) this.alarm('SIM002', 'SPINDLE STOPPED — TOOL CRASHED INTO STOCK');
    this.state.x = to.x; this.state.z = to.z;
    this.pushTrail(from, to, rapid);
    return true;
  }
  /** chuck-jaw envelope collision (tip inside jaw zone) */
  chuckCheck(p) {
    const s = this.stock, t = this.tipPos(p);
    const face = s.z0 - s.length + s.chuck;
    return t.z < face - 1e-6 && t.x / 2 < s.dia / 2 + 12 + 18;
  }
  limitCheck(p) {
    const o = this.off(), s = this.db.workShift(this.state.wcs);
    const mx = p.x + s.x + o.geomX + o.wearX, mz = p.z + s.z + o.geomZ + o.wearZ;
    if (mx > LIMITS.xMax + 1e-6) return '+X'; if (mx < LIMITS.xMin) return '-X';
    if (mz > LIMITS.zMax + 1e-6) return '+Z'; if (mz < LIMITS.zMin) return '-Z';
    return null;
  }
  pushTrail(a, b, rapid) {
    const last = this.trail[this.trail.length - 1];
    if (last && last.rapid === rapid && last.pts.length < 4000) last.pts.push({ ...b });
    else this.trail.push({ rapid, pts: [{ ...a }, { ...b }] });
    if (this.trail.length > 3000) this.trail.shift();
  }

  // ---- real-time loop ----------------------------------------------------
  tick(dtReal) {
    const dt = dtReal * this.simSpeed;
    this.liveRpm = this.state.spindle ? rpmAt({ S: this.state.S, css: this.state.css, clamp: this.state.clamp }, this.state.x, this.spindleOv) : 0;
    if (this.jogging && this.mode === 'JOG') {
      const { axis, dir } = this.jogging;
      const f = this.jogRapid ? RAPID_MM_MIN * this.rapidOv : this.jogFeed * this.feedOv;
      const to = { ...this.state }; to[axis] += dir * (f / 60) * dtReal * (axis === 'x' ? 2 : 1); // jog is real-time
      this.liveFeed = f;
      if (!this.directMove(to, this.jogRapid)) this.stopJog();
      return;
    }
    if (!this.running || this.hold || this.stopped) { this.liveFeed = 0; return; }
    let budget = dt;
    this.cycleTime += dt;
    let guard = 0;
    while (budget > 1e-9 && this.si < this.steps.length && guard++ < 5000) {
      const step = this.steps[this.si];
      this.currentLine = step.line;
      if (step.k === 'move') {
        const done = this.advanceMove(step, budget);
        budget = done.left;
        if (!done.finished) break;
      } else if (step.k === 'dwell') {
        if (this.dwellLeft <= 0) this.dwellLeft = step.sec;
        const used = Math.min(this.dwellLeft, budget); this.dwellLeft -= used; budget -= used;
        if (this.dwellLeft > 1e-9) break;
      }
      // step complete
      Object.assign(this.state, { ...step.st });
      this.segProg = 0; this.dwellLeft = 0; this.si++;
      if (step.k === 'tool') this.emit('tool', step);
      if (step.k === 'stop' && (!step.optional || this.optStop)) { this.stopped = true; this.message(step.optional ? 'M01 OPTIONAL STOP' : 'M00 PROGRAM STOP'); break; }
      if (step.k === 'end') { this.finish(); return; }
      if (step.blockEnd && this.singleBlock) { this.stopped = true; break; }
      if (this.hold) break;
    }
    if (this.si >= this.steps.length && this.running) this.finish();
  }
  finish() {
    const wasMem = this.execSource === 'MEM';
    this.running = false; this.steps = []; this.si = 0; this.liveFeed = 0; this.dtg = { x: 0, z: 0 };
    if (wasMem) { this.parts++; this.message(`PROGRAM END — CYCLE ${fmtTime(this.cycleTime)}`); }
    this.emit('finish', { mdi: !wasMem });
  }
  advanceMove(step, budget) {
    const pts = step.pts;
    // speed
    let f;
    if (step.rapid) f = RAPID_MM_MIN * this.rapidOv;
    else if (this.dryRun) f = 3000 * this.feedOv;
    else {
      if (step.feed.mode === 99 && this.state.spindle === 0 && step.st.spindle === 0) {
        this.alarm('SIM002', `SPINDLE STOPPED DURING CUTTING FEED @L${step.line}`);
        return { left: 0, finished: false };
      }
      f = feedMmMin(step.feed, this.state.x, this.spindleOv) * this.feedOv;
    }
    this.liveFeed = f;
    if (f <= 0) return { left: 0, finished: false };
    // polyline lengths (true distance, radius units)
    if (!step._len) {
      step._seg = []; let acc = 0;
      for (let i = 1; i < pts.length; i++) { const l = Math.hypot(pts[i].z - pts[i - 1].z, (pts[i].x - pts[i - 1].x) / 2); step._seg.push(l); acc += l; }
      step._len = acc || 1e-9;
    }
    const dist = (f / 60) * budget;
    const target = Math.min(step._len, this.segProg + dist);
    const used = ((target - this.segProg) / (f / 60));
    const p = pointAt(pts, step._seg, target);
    const from = { x: this.state.x, z: this.state.z };
    const lim = this.limitCheck(p);
    if (lim) { this.alarm('SIM003', `OVERTRAVEL ${lim} @L${step.line}`); return { left: 0, finished: false }; }
    if (this.chuckCheck(p)) { this.alarm('SIM004', `CHUCK COLLISION @L${step.line}`); return { left: 0, finished: false }; }
    // sweep material along every vertex passed
    const pass = [from, ...verticesBetween(pts, step._seg, this.segProg, target), p];
    for (let i = 1; i < pass.length; i++) {
      const res = this.stock.sweep(this.tipPos(pass[i - 1]), this.tipPos(pass[i]), step.rapid, 0.05, this.edge());
      if (res === 'collision') { this.alarm('SIM001', `RAPID MOVE INTO STOCK @L${step.line}`); }
      this.pushTrail(pass[i - 1], pass[i], step.rapid);
    }
    this.state.x = p.x; this.state.z = p.z;
    this.segProg = target;
    const end = pts[pts.length - 1];
    this.dtg = { x: end.x - p.x, z: end.z - p.z };
    if (this.hold) return { left: 0, finished: false };
    return { left: budget - used, finished: target >= step._len - 1e-9 };
  }
}

function pointAt(pts, seg, s) {
  let acc = 0;
  for (let i = 0; i < seg.length; i++) {
    if (acc + seg[i] >= s || i === seg.length - 1) {
      const t = seg[i] ? Math.min(1, Math.max(0, (s - acc) / seg[i])) : 1;
      return { x: pts[i].x + (pts[i + 1].x - pts[i].x) * t, z: pts[i].z + (pts[i + 1].z - pts[i].z) * t };
    }
    acc += seg[i];
  }
  return { ...pts[pts.length - 1] };
}
function verticesBetween(pts, seg, s0, s1) {
  const out = []; let acc = 0;
  for (let i = 0; i < seg.length; i++) { acc += seg[i]; if (acc > s0 + 1e-9 && acc < s1 - 1e-9) out.push(pts[i + 1]); }
  return out;
}
export function fmtTime(sec) {
  const h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60), s = Math.floor(sec % 60);
  return `${h}H${String(m).padStart(2, '0')}M${String(s).padStart(2, '0')}S`;
}
