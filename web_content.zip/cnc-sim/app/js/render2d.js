// ============================================================================
// 2D Renderer (Canvas 2D) — ZX half-section view, +Z right, +X up.
// Layers (painter's order): grid → chuck → stock (live r(z) profile, mirrored)
// → planned toolpath → executed trail → tool insert → HUD.
// World units are mm in radius space; the view transform handles pan/zoom.
// ============================================================================
import { TOOL_TYPES } from './tooldb.js';

export class Renderer2D {
  constructor(canvas, rt) {
    this.c = canvas; this.g = canvas.getContext('2d'); this.rt = rt;
    this.view = { cx: -30, cy: 10, scale: 6 };
    this.show = { planned: true, trail: true, grid: true };
    this.follow = false;
    this.bind();
    this.fit();
  }
  resize() {
    const r = this.c.getBoundingClientRect(), d = devicePixelRatio || 1;
    this.w = r.width; this.h = r.height;
    this.c.width = Math.max(1, r.width * d); this.c.height = Math.max(1, r.height * d);
    this.g.setTransform(d, 0, 0, d, 0, 0);
  }
  fit() {
    this.resize();
    const s = this.rt.stock;
    const tip = this.rt.tipPos();
    const inView = Math.abs(tip.z) < 260 && Math.abs(tip.x) < 400;
    const zMin = s.z0 - s.length - 6, zMax = Math.max(s.z0 + 30, 40, inView ? tip.z + 25 : 0);
    const rMax = Math.max(s.dia / 2 + 20, 40, inView ? tip.x / 2 + 20 : 0);
    const sc = Math.min(this.w / (zMax - zMin), this.h / (rMax * 2 + 8));
    this.view = { cx: (zMin + zMax) / 2, cy: 0, scale: Math.max(0.5, sc * 0.95) };
  }
  toScreen(z, r) { return [this.w / 2 + (z - this.view.cx) * this.view.scale, this.h / 2 - (r - this.view.cy) * this.view.scale]; }
  toWorld(px, py) { return [this.view.cx + (px - this.w / 2) / this.view.scale, this.view.cy - (py - this.h / 2) / this.view.scale]; }
  bind() {
    const c = this.c; let drag = null; const pointers = new Map(); let pinch = null;
    c.addEventListener('wheel', (e) => { e.preventDefault(); this.zoomAt(e.offsetX, e.offsetY, Math.exp(-e.deltaY * 0.0015)); }, { passive: false });
    c.addEventListener('pointerdown', (e) => { c.setPointerCapture(e.pointerId); pointers.set(e.pointerId, [e.offsetX, e.offsetY]); drag = [e.offsetX, e.offsetY]; });
    c.addEventListener('pointermove', (e) => {
      if (!pointers.has(e.pointerId)) return;
      pointers.set(e.pointerId, [e.offsetX, e.offsetY]);
      if (pointers.size === 2) {
        const [a, b] = [...pointers.values()]; const d = Math.hypot(a[0] - b[0], a[1] - b[1]);
        if (pinch) this.zoomAt((a[0] + b[0]) / 2, (a[1] + b[1]) / 2, d / pinch); pinch = d; return;
      }
      if (drag) { this.view.cx -= (e.offsetX - drag[0]) / this.view.scale; this.view.cy += (e.offsetY - drag[1]) / this.view.scale; drag = [e.offsetX, e.offsetY]; }
    });
    const up = (e) => { pointers.delete(e.pointerId); if (pointers.size < 2) pinch = null; if (!pointers.size) drag = null; };
    c.addEventListener('pointerup', up); c.addEventListener('pointercancel', up);
    c.addEventListener('dblclick', () => this.fit());
  }
  zoomAt(px, py, k) {
    const [wz, wr] = this.toWorld(px, py);
    this.view.scale = Math.min(200, Math.max(0.3, this.view.scale * k));
    const [nz, nr] = this.toWorld(px, py);
    this.view.cx += wz - nz; this.view.cy += wr - nr;
  }
  draw() {
    const g = this.g, rt = this.rt, s = rt.stock;
    if (!this.w) this.resize();
    g.clearRect(0, 0, this.w, this.h);
    g.fillStyle = '#0d1114'; g.fillRect(0, 0, this.w, this.h);
    if (this.show.grid) this.grid();
    // chuck jaws
    const chuckZ = s.z0 - s.length + s.chuck;
    const jawR = s.dia / 2 + 12;
    g.fillStyle = '#2a3036'; g.strokeStyle = '#48525b';
    for (const sgn of [1, -1]) {
      const [x0, y0] = this.toScreen(s.z0 - s.length - 20, sgn * (jawR + 18));
      const [x1, y1] = this.toScreen(chuckZ, sgn * s.dia / 2);
      g.fillRect(Math.min(x0, x1), Math.min(y0, y1), Math.abs(x1 - x0), Math.abs(y1 - y0));
      g.strokeRect(Math.min(x0, x1), Math.min(y0, y1), Math.abs(x1 - x0), Math.abs(y1 - y0));
    }
    // original stock outline
    g.setLineDash([4, 4]); g.strokeStyle = 'rgba(160,175,190,.35)'; g.lineWidth = 1;
    const [a0, b0] = this.toScreen(s.z0, s.dia / 2), [a1, b1] = this.toScreen(s.z0 - s.length, -s.dia / 2);
    g.strokeRect(a1, b0, a0 - a1, b1 - b0); g.setLineDash([]);
    // live stock profile (mirrored)
    const prof = s.profile(900);
    const grad = g.createLinearGradient(0, this.toScreen(0, s.dia / 2)[1], 0, this.toScreen(0, -s.dia / 2)[1]);
    grad.addColorStop(0, '#9aa6b1'); grad.addColorStop(0.35, '#dfe6ec'); grad.addColorStop(0.5, '#b8c2cb'); grad.addColorStop(0.65, '#dfe6ec'); grad.addColorStop(1, '#7d8893');
    g.beginPath();
    prof.forEach((p, i) => { const [x, y] = this.toScreen(p.z, p.r); i ? g.lineTo(x, y) : g.moveTo(x, y); });
    for (let i = prof.length - 1; i >= 0; i--) { const [x, y] = this.toScreen(prof[i].z, -prof[i].r); g.lineTo(x, y); }
    g.closePath(); g.fillStyle = grad; g.fill();
    g.strokeStyle = '#eef3f7'; g.lineWidth = 1; g.stroke();
    // centerline
    g.setLineDash([12, 4, 2, 4]); g.strokeStyle = 'rgba(255,196,0,.55)';
    g.beginPath(); g.moveTo(0, this.toScreen(0, 0)[1]); g.lineTo(this.w, this.toScreen(0, 0)[1]); g.stroke(); g.setLineDash([]);
    // work zero marker
    const [zx, zy] = this.toScreen(0, 0);
    g.strokeStyle = '#ffc400'; g.lineWidth = 1.5; g.beginPath(); g.arc(zx, zy, 6, 0, Math.PI * 2); g.stroke();
    g.beginPath(); g.moveTo(zx - 9, zy); g.lineTo(zx + 9, zy); g.moveTo(zx, zy - 9); g.lineTo(zx, zy + 9); g.stroke();
    // paths
    if (this.show.planned) this.paths(rt.planned, 'rgba(255,90,90,.45)', 'rgba(94,200,229,.45)', 1, true);
    if (this.show.trail) this.paths(rt.trail, 'rgba(255,120,120,.95)', '#62f0a0', 1.6, true);
    this.tool();
  }
  grid() {
    const g = this.g; const step = niceStep(40 / this.view.scale);
    const [z0, r1] = this.toWorld(0, 0), [z1, r0] = this.toWorld(this.w, this.h);
    g.lineWidth = 1;
    for (let z = Math.floor(z0 / step) * step; z <= z1; z += step) {
      const [x] = this.toScreen(z, 0); g.strokeStyle = Math.abs(z % (step * 5)) < 1e-6 ? '#1d252b' : '#151b20';
      g.beginPath(); g.moveTo(x, 0); g.lineTo(x, this.h); g.stroke();
    }
    for (let r = Math.floor(r0 / step) * step; r <= r1; r += step) {
      const [, y] = this.toScreen(0, r); g.strokeStyle = Math.abs(r % (step * 5)) < 1e-6 ? '#1d252b' : '#151b20';
      g.beginPath(); g.moveTo(0, y); g.lineTo(this.w, y); g.stroke();
    }
    g.fillStyle = '#56616b'; g.font = '11px "JetBrains Mono", monospace';
    for (let z = Math.floor(z0 / (step * 5)) * step * 5; z <= z1; z += step * 5) { const [x] = this.toScreen(z, 0); g.fillText(`Z${+z.toFixed(2)}`, x + 3, this.h - 6); }
  }
  paths(list, rapidCol, feedCol, width, dashRapid) {
    const g = this.g; g.lineWidth = width;
    for (const p of list) {
      g.strokeStyle = p.rapid ? rapidCol : feedCol;
      g.setLineDash(p.rapid && dashRapid ? [5, 4] : []);
      g.beginPath();
      p.pts.forEach((q, i) => { const [x, y] = this.toScreen(q.z, q.x / 2); i ? g.lineTo(x, y) : g.moveTo(x, y); });
      g.stroke();
    }
    g.setLineDash([]);
  }
  tool() {
    const g = this.g, rt = this.rt;
    const tip = rt.tipPos();
    const [x, y] = this.toScreen(tip.z, tip.x / 2);
    const tdef = rt.db.tool(rt.state.tool);
    const type = TOOL_TYPES[tdef?.type] || TOOL_TYPES.OD_ROUGH;
    const sc = Math.max(this.view.scale, 2.2);
    const L = Math.min(60, 6 * sc); // insert size on screen (mm-scaled)
    g.save(); g.translate(x, y);
    // holder shank
    g.fillStyle = '#39424a'; g.strokeStyle = '#6b7883';
    g.fillRect(L * 0.35, -L * 0.2 - L * 2.8, L * 1.1, L * 2.6); g.strokeRect(L * 0.35, -L * 0.2 - L * 2.8, L * 1.1, L * 2.6);
    // insert polygon: tip at origin, pointing down-left (tool tip direction 3)
    g.beginPath();
    if (type === TOOL_TYPES.GROOVE) { g.rect(0, -L * 1.2, L * 0.35, L * 1.2); }
    else if (type === TOOL_TYPES.DRILL) { g.moveTo(0, 0); g.lineTo(L * 1.2, -L * 0.4); g.lineTo(L * 1.2, L * 0.4); g.closePath(); }
    else {
      const ang = (type.angle * Math.PI) / 180, tb = -Math.PI / 4; // bisector up-right (screen)
      const t1 = tb + ang / 2, t2 = tb - ang / 2, far = 2 * L * Math.cos(ang / 2);
      g.moveTo(0, 0);
      g.lineTo(Math.cos(t1) * L, Math.sin(t1) * L);
      g.lineTo(Math.cos(tb) * far, Math.sin(tb) * far);
      g.lineTo(Math.cos(t2) * L, Math.sin(t2) * L);
      g.closePath();
    }
    g.fillStyle = type.color; g.globalAlpha = 0.92; g.fill(); g.globalAlpha = 1;
    g.strokeStyle = '#111'; g.lineWidth = 1; g.stroke();
    // spindle / coolant hint
    if (rt.state.coolant) { g.strokeStyle = 'rgba(80,170,255,.7)'; g.lineWidth = 2; g.beginPath(); g.moveTo(L * 1.6, -L * 1.6); g.quadraticCurveTo(L * 0.6, -L * 0.5, 2, -2); g.stroke(); }
    g.restore();
    g.fillStyle = '#ffc400'; g.beginPath(); g.arc(x, y, 2.5, 0, Math.PI * 2); g.fill();
  }
}
function niceStep(raw) { const p = Math.pow(10, Math.floor(Math.log10(raw))); const n = raw / p; return (n < 2 ? 1 : n < 5 ? 2 : 5) * p; }
