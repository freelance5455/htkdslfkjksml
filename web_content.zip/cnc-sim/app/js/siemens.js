// ============================================================================
// SINUMERIK 808D (turning) — PPU (HMI screen + soft keys + keypad) and MCP.
// Drives the same Runtime / ToolDB / program library as the Fanuc panel;
// only the operator interface and the program dialect differ.
// Operating areas: POSITION (Machine) · OFFSET · PROGRAM · PROGRAM MANAGER ·
// ALARM · SYSTEM.  Modes (MCP): AUTO · MDA · JOG · REF POINT · HANDWHEEL.
// ============================================================================
import { TOOL_TYPES } from './tooldb.js';
import { parseAny, detectDialect, siemensAlarm } from './dialect.js';

const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const n3 = (v) => (Math.abs(v) < 5e-4 ? 0 : v).toFixed(3);
const MODE_NAME = { MEM: 'AUTO', MDI: 'MDA', JOG: 'JOG', HND: 'JOG  HANDWHEEL', ZRN: 'REF POINT', EDIT: 'JOG' };
const FEED_STEPS = [0, 2, 4, 6, 8, 10, 20, 30, 40, 50, 60, 70, 75, 80, 85, 90, 95, 100, 105, 110, 115, 120];
const AREA_TITLE = { MACHINE: 'Machine', PROGRAM: 'Program', OFFSET: 'Offset', PM: 'Program manager', ALARM: 'Alarm', SYSTEM: 'System' };

export function initSiemens(api) {
  const { rt, db, lib } = api;
  const S = {
    area: 'MACHINE', offSub: 'LIST', mcs: false, showG: true, progCtrl: false,
    sel: { r: 0, c: 'lenX' }, buf: '', pmSel: 0, inc: 0, rov: false, hwAxis: 'x',
    mda: 'G0 X60 Z5 ; MDA BLOCK\n', form: null, help: false, rpSel: 0, ref: { x: false, z: false }, feedIdx: FEED_STEPS.indexOf(100), measField: 'X', log: false,
  };

  // ------------------------------------------------------------------ PPU ---
  $('#sieUnit').innerHTML = `
  <div class="s-ppu">
    <div class="s-badge"><b>SIEMENS</b><span>SINUMERIK 808D</span></div>
    <div class="s-screenrow">
      <div class="s-screen" id="sScreen" tabindex="0">
        <div class="s-top"><span id="sArea">Machine</span><span id="sMode">JOG</span><span id="sPath"></span></div>
        <div class="s-chan"><span id="sChan">Channel reset</span><span id="sProgSt">Program aborted</span><span id="sFlags"></span></div>
        <div class="s-alarm" id="sAlarm"></div>
        <div class="s-body" id="sBody"></div>
        <div class="s-hsk" id="sHsk"></div>
      </div>
      <div class="s-vsk" id="sVsk"></div>
    </div>
    <div class="s-keys">
      <div class="s-areas" id="sAreas">
        <button data-area="MACHINE" title="Position / Machine"><i>⌖</i>POSITION</button>
        <button data-area="OFFSET"><i>⊿</i>OFFSET</button>
        <button data-area="PROGRAM"><i>✎</i>PROGRAM</button>
        <button data-area="PM"><i>☰</i>PROG MGR</button>
        <button data-area="ALARM"><i>⚠</i>ALARM</button>
        <button data-area="SYSTEM"><i>⚙</i>SYSTEM</button>
      </div>
      <div class="s-pad" id="sPad">
        <div class="s-alpha">
          ${'O N G X Z F D T S M I K R P Q L U W = ( ) , " : ;'.split(' ').map((k) => `<button data-ch="${esc(k)}">${esc(k)}</button>`).join('')}
          <button data-ch=" " class="wide">SPACE</button>
          <button data-k="END">END</button>
        </div>
        <div class="s-num">${'7 8 9 4 5 6 1 2 3 - 0 .'.split(' ').map((k) => `<button data-ch="${k}">${k}</button>`).join('')}</div>
        <div class="s-nav">
          <button data-k="ALMCAN" class="s-ac" title="Alarm cancel">ALARM<br>CANCEL</button>
          <button data-k="HELP" class="s-help" title="Help for the current screen">HELP</button>
          <button data-k="BACK">⌫<br>BACKSP</button>
          <button data-k="INPUT" class="s-input">INPUT<br>⏎</button>
          <button data-k="PGUP">PAGE<br>UP</button>
          <button data-k="UP" aria-label="Up">▲</button>
          <button data-k="PGDN">PAGE<br>DOWN</button>
          <button data-k="RECALL" title="Recall: back / close window">^<br>RECALL</button>
          <button data-k="DEL">DEL</button>
          <button data-k="SELECT">SELECT</button>
          <button data-k="LEFT" aria-label="Left">◀</button>
          <button data-k="DOWN" aria-label="Down">▼</button>
          <button data-k="RIGHT" aria-label="Right">▶</button>
        </div>
      </div>
    </div>
  </div>`;

  // ------------------------------------------------------------------ MCP ---
  $('#sieMcp').innerHTML = `
  <div class="s-mcp">
    <div class="s-g s-estop"><button id="sEstop" aria-label="Emergency stop"><span>EMERGENCY<br>STOP</span></button></div>
    <div class="s-g">
      <h4>User keys</h4>
      <div class="s-row2"><button data-u="cool"><i></i>COOLANT</button><button data-u="tool"><i></i>TOOL<br>INDEX</button></div>
      <h4>Program</h4>
      <div class="s-row2"><button data-t="singleBlock"><i></i>SINGLE<br>BLOCK</button><button data-u="rov"><i></i>ROV</button></div>
    </div>
    <div class="s-g">
      <h4>Mode</h4>
      <div class="s-modes">
        <button data-m="MEM"><i></i>AUTO</button><button data-m="MDI"><i></i>MDA</button>
        <button data-m="JOG"><i></i>JOG</button><button data-m="ZRN"><i></i>REF<br>POINT</button>
        <button data-m="HND"><i></i>HAND<br>WHEEL</button>
      </div>
    </div>
    <div class="s-g">
      <h4>Increment</h4>
      <div class="s-inc">
        <button data-i="0"><i></i>[VAR]</button><button data-i="0.001"><i></i>1</button><button data-i="0.01"><i></i>10</button>
        <button data-i="0.1"><i></i>100</button><button data-i="1"><i></i>1000</button>
      </div>
    </div>
    <div class="s-g">
      <h4>Axes</h4>
      <div class="s-axes">
        <span></span><button data-j="x+">+X</button><span></span>
        <button data-j="z-">−Z</button><button data-j="rapid" class="s-rap"><i></i>⇶<br>RAPID</button><button data-j="z+">+Z</button>
        <span></span><button data-j="x-">−X</button><span></span>
      </div>
    </div>
    <div class="s-g s-hw">
      <h4>Handwheel <span id="sHwAx">X</span></h4>
      <div class="s-mpg" id="sMpg" role="slider" tabindex="0" aria-label="Handwheel"><div class="s-mpg-k" id="sMpgK"><span></span></div></div>
    </div>
    <div class="s-g">
      <h4>Spindle <output id="sSpOv">100%</output></h4>
      <div class="s-sp">
        <button data-sp="-1" title="Spindle left (CCW)">⟲<br>LEFT</button><button data-sp="0" class="stop">◯<br>STOP</button><button data-sp="1" title="Spindle right (CW)">⟳<br>RIGHT</button>
        <button data-so="-1">SPDL<br>−</button><button data-so="0">100<br>%</button><button data-so="1">SPDL<br>+</button>
      </div>
    </div>
    <div class="s-g s-feed">
      <h4>Feed override</h4>
      <div class="s-knob" id="sKnob" role="slider" tabindex="0" aria-label="Feed override" aria-valuemin="0" aria-valuemax="120">
        <div class="s-knob-in" id="sKnobIn"><span></span></div>
      </div>
      <output id="sFeedOv">100%</output>
    </div>
    <div class="s-g s-cyc">
      <button id="sReset" class="reset">⟳<br>RESET</button>
      <button id="sStop" class="stop">◼<br>CYCLE STOP</button>
      <button id="sStart" class="start">◆<br>CYCLE START</button>
    </div>
  </div>`;

  // ------------------------------------------------------------- helpers ---
  const active = () => api.active();
  const dialectOf = (k) => detectDialect(k);
  const textTarget = () => $('#sEd') || $('#sMdaTa');
  const alarms = () => rt.alarms.map((a) => ({ ...siemensAlarm(a.code, a.message), at: a.at }));
  const softkeys = (el, list, n) => {
    const l = [...list]; while (l.length < n) l.push(null);
    el.innerHTML = l.slice(0, n).map((k) => k ? `<button data-sk="${k.id}" class="${k.on ? 'on' : ''}" ${k.dis ? 'disabled' : ''}>${k.label}</button>` : '<button class="empty" tabindex="-1" aria-hidden="true"></button>').join('');
  };

  // -------------------------------------------------------------- screens ---
  function render() {
    $$('#sAreas button').forEach((b) => b.classList.toggle('on', b.dataset.area === S.area));
    $('#sArea').textContent = AREA_TITLE[S.area];
    const body = $('#sBody');
    let h = [], v = [];
    if (S.help) {
      body.innerHTML = helpHTML();
      softkeys($('#sHsk'), [], 8); softkeys($('#sVsk'), [...Array(7).fill(null), { id: 'hclose', label: 'Close<br>help' }], 8);
      return update(true);
    }
    if (S.form) {
      body.innerHTML = formHTML();
      softkeys($('#sHsk'), [], 8);
      softkeys($('#sVsk'), [{ id: 'fok', label: S.form.run ? 'Execute<br>⟐ START' : 'Accept' }, null, null, null, null, null, null, { id: 'fcancel', label: 'Cancel' }], 8);
      return update(true);
    }
    if (S.area === 'MACHINE') {
      body.innerHTML = machineHTML();
      h = [{ id: 'v2d', label: '2D<br>section' }, { id: 'v3d', label: '3D<br>solid' }, { id: 'vsplit', label: 'Split<br>view' }, { id: 'clr', label: 'Clear<br>path' }, { id: 'stock', label: 'Blank<br>(stock)' }];
      if (S.progCtrl) v = [{ id: 'dry', label: 'DRY<br>dry run', on: rt.dryRun }, { id: 'skp', label: 'SKP<br>skip', on: rt.blockSkip }, { id: 'm01', label: 'M01<br>opt. stop', on: rt.optStop }, { id: 'sbl', label: 'SBL<br>single blk', on: rt.singleBlock }, null, null, null, { id: 'back', label: '<<<br>Back' }];
      else {
        v = [{ id: 'mcs', label: S.mcs ? 'Act. val.<br>WCS' : 'Act. val.<br>MCS', on: S.mcs }, { id: 'gf', label: 'G funct.', on: S.showG }, { id: 'pctl', label: 'Prog.<br>ctrl' }];
        if (rt.mode === 'MDI') v.push({ id: 'mdadel', label: 'Delete<br>MDA prog.' });
        if (rt.mode === 'HND') v.push({ id: 'hwx', label: 'Handwheel<br>X', on: S.hwAxis === 'x' }, { id: 'hwz', label: 'Handwheel<br>Z', on: S.hwAxis === 'z' });
        if (rt.mode === 'MEM') v.push({ id: 'pm', label: 'Program<br>select' });
        if (rt.mode === 'JOG' || rt.mode === 'HND') v.push({ id: 'tsm', label: 'T, S, M' }, { id: 'setwo', label: 'Set<br>WO' }, { id: 'face', label: 'Facing' }, { id: 'meast', label: 'Meas.<br>tool' });
      }
      if (rt.mode === 'MDI') { const ta = $('#sMdaTa'); ta.value = S.mda; ta.addEventListener('input', () => { S.mda = ta.value.toUpperCase(); }); }
    } else if (S.area === 'PROGRAM') {
      body.innerHTML = progHTML();
      const ta = $('#sEd'); ta.value = lib[active()]; let t;
      ta.readOnly = rt.running;
      const sync = () => { $('#sGut').scrollTop = ta.scrollTop; };
      ta.addEventListener('scroll', sync);
      ta.addEventListener('input', () => {
        const p = ta.selectionStart; ta.value = ta.value.toUpperCase(); ta.selectionStart = ta.selectionEnd = p;
        gutter(); clearTimeout(t); t = setTimeout(commitEditor, 350);
      });
      gutter();
      h = [{ id: 'edit', label: 'Edit', on: true }, { id: 'turn', label: 'Stock rem.<br>CYCLE95' }, { id: 'grv', label: 'Groove<br>CYCLE93' }, { id: 'cont', label: 'Contour<br>labels' }, { id: 'sim', label: 'Simu-<br>lation' }];
      v = [{ id: 'exec', label: 'Execute' }, { id: 'check', label: 'Check<br>syntax' }, { id: 'turn', label: 'CYCLE95<br>form' }, { id: 'grv', label: 'CYCLE93<br>form' }, { id: 'lbl', label: 'Insert<br>contour' }, null, null, { id: 'close', label: 'Close' }];
    } else if (S.area === 'OFFSET') {
      body.innerHTML = offsetHTML();
      h = [{ id: 'LIST', label: 'Tool<br>list', on: S.offSub === 'LIST' }, { id: 'WEAR', label: 'Tool<br>wear', on: S.offSub === 'WEAR' }, { id: 'WORK', label: 'Work<br>offset', on: S.offSub === 'WORK' }, { id: 'MEAS', label: 'Measure<br>tool', on: S.offSub === 'MEAS' }, { id: 'RPAR', label: 'R<br>variables', on: S.offSub === 'RPAR' }];
      if (S.offSub === 'MEAS') v = [{ id: 'mx', label: 'Set<br>length X' }, { id: 'mz', label: 'Set<br>length Z' }, { id: 'mfx', label: 'Input<br>X Ø', on: S.measField === 'X' }, { id: 'mfz', label: 'Input<br>Z', on: S.measField === 'Z' }];
      else if (S.offSub === 'LIST' || S.offSub === 'WEAR') v = [{ id: 'act', label: 'Activate<br>tool' }];
      else if (S.offSub === 'RPAR') v = [{ id: 'rclr', label: 'Delete<br>all R' }];
    } else if (S.area === 'PM') {
      body.innerHTML = pmHTML();
      v = [{ id: 'pexec', label: 'Execute' }, { id: 'popen', label: 'Open' }, { id: 'pnew', label: 'New' }, { id: 'pcopy', label: 'Copy' }, { id: 'pdel', label: 'Delete' }, { id: 'pexp', label: 'Export' }, { id: 'pimp', label: 'Import' }];
      h = [{ id: 'nc', label: 'NC', on: true }];
    } else if (S.area === 'ALARM') {
      body.innerHTML = alarmHTML();
      h = [{ id: 'alist', label: 'Alarm<br>list', on: !S.log }, { id: 'alog', label: 'Messages', on: S.log }];
      v = [{ id: 'aclr', label: 'Clear<br>messages' }];
    } else if (S.area === 'SYSTEM') {
      body.innerHTML = systemHTML();
      h = [{ id: 'md', label: 'Machine<br>data', on: true }];
      v = [{ id: 'stock', label: 'Blank<br>setup' }, { id: 'tofanuc', label: 'Switch to<br>FANUC' }, { id: 'rstdb', label: 'Reset<br>tool data' }];
    }
    softkeys($('#sHsk'), h, 8); softkeys($('#sVsk'), v, 8);
    update(true);
  }

  function machineHTML() {
    const lower = (() => {
      if (rt.mode === 'MDI') return `<div class="s-sub">MDA <small>— SINUMERIK syntax, CYCLE START executes</small></div><textarea id="sMdaTa" class="s-ta" spellcheck="false" aria-label="MDA program"></textarea>`;
      if (rt.mode === 'MEM') return `<div class="s-sub">Block display <small id="sProgName"></small></div><div class="s-blocks" id="sBlocks"></div>`;
      if (rt.mode === 'ZRN') return `<div class="s-sub">Reference point</div><div class="s-ref">${['x', 'z'].map((a) => `<span class="${S.ref[a] ? 'ok' : ''}">${S.ref[a] ? '●' : '○'} ${a.toUpperCase()}</span>`).join('')}<small>Press +X / +Z to approach the reference point</small></div>`;
      return `<div class="s-sub">${rt.mode === 'HND' ? `Handwheel ${S.hwAxis.toUpperCase()} · increment ${S.inc ? S.inc.toFixed(3) : '0.001'} mm` : `JOG · ${S.inc ? `increment ${S.inc.toFixed(3)} mm` : '[VAR] continuous'} · feed ${rt.jogFeed} mm/min`}</div>`;
    })();
    return `<div class="s-mgrid">
      <table class="s-pos">
        <tr><th id="sCs">${S.mcs ? 'MCS' : 'WCS'}</th><th>Position [mm]</th><th>Dist-to-go</th></tr>
        <tr><td class="ax">X</td><td class="big" id="sX"></td><td id="sdX"></td></tr>
        <tr><td class="ax">Z</td><td class="big" id="sZ"></td><td id="sdZ"></td></tr>
      </table>
      <div class="s-tfs">
        <div class="s-box"><h5>T</h5><b id="sT"></b><span id="sTn"></span></div>
        <div class="s-box"><h5>F <span id="sFo"></span></h5><b id="sF"></b><span>mm/min</span></div>
        <div class="s-box"><h5>S1 <span id="sSo"></span></h5><b id="sS"></b><span id="sSd"></span></div>
      </div>
    </div>
    ${S.showG ? '<div class="s-gfun" id="sG"></div>' : ''}
    <div class="s-lower">${lower}</div>`;
  }
  function progHTML() {
    const k = active();
    return `<div class="s-sub">${esc(k)} <small>${dialectOf(k) === 'siemens' ? 'SINUMERIK' : 'ISO dialect (G291)'}${rt.running ? ' · read-only while running' : ''}</small></div>
      <div class="s-editor"><div class="s-gut" id="sGut"></div><textarea id="sEd" class="s-ta" spellcheck="false" aria-label="Program editor"></textarea></div>
      <div class="s-errs" id="sErrs"></div>`;
  }
  function gutter() {
    const ta = $('#sEd'); if (!ta) return;
    const p = parseAny(ta.value, dialectOf(active()), rt.dialectOpts());
    const bad = new Set(p.errors.map((e) => e.line));
    $('#sGut').innerHTML = ta.value.split('\n').map((_, i) => bad.has(i + 1) ? `<span class="err">${i + 1}</span>` : i + 1).join('\n');
    $('#sGut').scrollTop = ta.scrollTop;
    const e = $('#sErrs');
    e.innerHTML = p.errors.length
      ? p.errors.slice(0, 3).map((x) => { const a = siemensAlarm(x.code, x.message); return `<div class="bad">Line ${x.line}: ${a.num} ${esc(a.num === x.code ? x.message : a.text)}</div>`; }).join('')
      : `<div class="good">✓ ${p.blocks.length} blocks — no syntax errors</div>`;
  }
  function commitEditor() {
    const ta = $('#sEd'); if (!ta || rt.running) return;
    lib[active()] = ta.value; api.saveLib(); rt.load(ta.value, dialectOf(active())); api.refreshEstimate();
  }
  function offsetHTML() {
    const ss = S.sel;
    const cell = (r, c, val, editable = true) => {
      const sel = ss.r === r && ss.c === c;
      return `<td data-r="${r}" data-c="${c}" class="${editable ? 'ed' : ''} ${sel ? 'sel' : ''}">${sel && S.buf ? esc(S.buf) + '<i class="cur">_</i>' : val}</td>`;
    };
    if (S.offSub === 'RPAR') {
      const R = rt.dialectOpts().R;
      const c = (n) => { const sel = S.rpSel === n; return `<td>R${n}</td><td data-rp="${n}" class="ed ${sel ? 'sel' : ''}">${sel && S.buf ? esc(S.buf) + '<i class="cur">_</i>' : +R[n].toFixed(4)}</td>`; };
      return `<div class="s-sub">R variables <small>R0…R99 · used as X=R1+2, CR=R3, CYCLE args · persist after M30</small></div>
        <table class="s-tab s-rp"><tr><th>R</th><th>Value</th><th>R</th><th>Value</th></tr>${Array.from({ length: 50 }, (_, i) => `<tr>${c(i)}${c(i + 50)}</tr>`).join('')}</table>`;
    }
    if (S.offSub === 'WORK') {
      return `<div class="s-sub">Work offset — settable zero offset</div><table class="s-tab"><tr><th></th><th>X [mm]</th><th>Z [mm]</th></tr>
        ${db.data.work.map((w, i) => `<tr class="${'G' + rt.state.wcs === w.code ? 'act' : ''}"><td>${w.code}</td>${cell(i, 'wx', n3(w.x))}${cell(i, 'wz', n3(w.z))}</tr>`).join('')}</table>`;
    }
    if (S.offSub === 'MEAS') {
      const o = db.getOffset(rt.state.offset) || {};
      const m = rt.machinePos();
      return `<div class="s-sub">Measure tool — manual (scratch / touch)</div>
        <div class="s-meas">
          <div>Active tool <b>T${rt.state.tool} D1</b> ${esc(db.tool(rt.state.tool)?.name || '')}</div>
          <div>MCS X <b>${n3(m.x)}</b> &nbsp; Z <b>${n3(m.z)}</b></div>
          <div>Length X <b>${n3(-(o.geomX ?? 0))}</b> &nbsp; Length Z <b>${n3(-(o.geomZ ?? 0))}</b></div>
          <label class="${S.measField === 'X' ? 'sel' : ''}">X Ø (measured) <span>${S.measField === 'X' ? esc(S.buf) + '<i class="cur">_</i>' : ''}</span></label>
          <label class="${S.measField === 'Z' ? 'sel' : ''}">Z (face position) <span>${S.measField === 'Z' ? esc(S.buf) + '<i class="cur">_</i>' : ''}</span></label>
          <small>Touch the part in JOG/HANDWHEEL, key in the measured value, then "Set length X/Z".</small>
        </div>`;
    }
    const rows = db.data.tools.map((t, i) => {
      const o = db.getOffset(t.station) || {};
      const ty = TOOL_TYPES[t.type]; const act = t.station === rt.state.tool;
      if (S.offSub === 'WEAR')
        return `<tr class="${act ? 'act' : ''}"><td>${t.station}</td><td class="nm" title="${esc(t.name)}">${esc(t.name)}</td><td>1</td>${cell(i, 'wearX', n3(o.wearX))}${cell(i, 'wearZ', n3(o.wearZ))}</tr>`;
      return `<tr class="${act ? 'act' : ''}"><td>${t.station}</td><td title="${esc(ty?.label ?? '')}"><i class="s-ty" style="background:${ty?.color}"></i></td><td class="nm" title="${esc(t.name)}">${esc(t.name)}</td><td>1</td>${cell(i, 'lenX', n3(-o.geomX))}${cell(i, 'lenZ', n3(-o.geomZ))}${cell(i, 'radius', n3(o.radius))}${cell(i, 'tip', o.tip)}</tr>`;
    }).join('');
    return S.offSub === 'WEAR'
      ? `<div class="s-sub">Tool wear <small>max. input ±1.000 mm · −ΔX = smaller Ø</small></div><table class="s-tab"><tr><th>Loc</th><th style="text-align:left">Tool name</th><th>D</th><th>Δ Length X</th><th>Δ Length Z</th></tr>${rows}</table>`
      : `<div class="s-sub">Tool list <small>turret 12 locations · D = cutting edge</small></div><table class="s-tab"><tr><th>Loc</th><th></th><th style="text-align:left">Tool name</th><th>D</th><th>Len. X</th><th>Len. Z</th><th>Rad.</th><th>Tip</th></tr>${rows}</table>`;
  }
  function pmHTML() {
    const keys = Object.keys(lib).sort((a, b) => (dialectOf(b) === 'siemens') - (dialectOf(a) === 'siemens') || a.localeCompare(b));
    S.pmKeys = keys; S.pmSel = Math.min(S.pmSel, keys.length - 1);
    return `<div class="s-sub">NC / MPF <small>${keys.length} programs</small></div><table class="s-tab s-pm"><tr><th style="text-align:left">Name</th><th>Type</th><th>Size</th><th></th></tr>
      ${keys.map((k, i) => `<tr data-pm="${i}" class="${i === S.pmSel ? 'selrow' : ''}"><td style="text-align:left">${esc(k)}</td><td>${dialectOf(k) === 'siemens' ? 'MPF' : 'ISO'}</td><td>${lib[k].length} B</td><td>${k === active() ? '◀ selected' : ''}</td></tr>`).join('')}</table>
      <input type="file" id="sImport" accept=".mpf,.spf,.nc,.txt,.tap" hidden>`;
  }
  function alarmHTML() {
    if (S.log) return `<div class="s-sub">Messages</div><div class="s-alist">${rt.messages.slice(0, 60).map((m) => `<div><span>${m.at.toTimeString().slice(0, 8)}</span>${m.code ? `<b>${siemensAlarm(m.code, m.message).num}</b>` : ''}${esc(m.message)}</div>`).join('') || '<div>No messages</div>'}</div>`;
    const a = alarms();
    return `<div class="s-sub">Alarm list <small>${a.length} active</small></div><div class="s-alist">${a.map((x) => `<div class="bad"><span>${x.at.toTimeString().slice(0, 8)}</span><b>${x.num}</b>${esc(x.text)}</div>`).join('') || '<div class="good">No alarms</div>'}</div>
      <small class="s-hint">RESET on the MCP clears machine alarms · ALARM CANCEL clears cancel alarms.</small>`;
  }
  function systemHTML() {
    const s = rt.stock;
    return `<div class="s-sub">Machine data <small>simulated</small></div><table class="s-tab s-md">
      <tr><td>Control</td><td>SINUMERIK 808D Turning (ISO dialect via G291)</td></tr>
      <tr><td>Axes</td><td>X (diameter, DIAMON) · Z · spindle S1</td></tr>
      <tr><td>Rapid traverse</td><td>12000 mm/min</td></tr>
      <tr><td>Software limits (MCS)</td><td>X −420 … 0 · Z −600 … 0</td></tr>
      <tr><td>Turret</td><td>12 locations, D1 per tool</td></tr>
      <tr><td>Blank</td><td>Ø${s.dia} × ${s.length} mm · chuck grip ${s.chuck} mm</td></tr>
      <tr><td>Removed volume</td><td id="sVol"></td></tr></table>`;
  }

  // ---------------------------------------------------------- live update ---
  function update(force) {
    const st = rt.state, m = rt.machinePos();
    const set = (id, v) => { const el = document.getElementById(id); if (el && el.textContent !== String(v)) el.textContent = v; };
    $('#sMode').textContent = MODE_NAME[rt.mode] || rt.mode;
    $('#sPath').textContent = `/NC/MPF/${active()}`;
    $('#sChan').textContent = rt.estop ? 'Emergency stop' : rt.running ? (rt.hold || rt.stopped ? 'Channel interrupted' : 'Channel active') : 'Channel reset';
    $('#sChan').className = rt.running && !rt.hold && !rt.stopped ? 'on' : rt.alarms.length || rt.estop ? 'bad' : '';
    $('#sProgSt').textContent = rt.running ? (rt.hold || rt.stopped ? 'Program stopped' : 'Program running') : 'Program aborted';
    $('#sFlags').textContent = [rt.singleBlock && 'SBL', rt.dryRun && 'DRY', rt.blockSkip && 'SKP', rt.optStop && 'M01', S.rov && 'ROV'].filter(Boolean).join('  ');
    const a = alarms();
    const al = $('#sAlarm');
    if (a.length) { al.className = 's-alarm bad'; al.textContent = `⚠ ${a[0].num}  ${a[0].text}`; }
    else { al.className = 's-alarm'; al.textContent = rt.messages[0] && Date.now() - rt.messages[0].at < 8000 ? rt.messages[0].message : ''; }
    const px = S.mcs ? m.x : st.x, pz = S.mcs ? m.z : st.z;
    set('sX', n3(px)); set('sZ', n3(pz));
    set('sdX', n3(rt.running ? rt.dtg.x : 0)); set('sdZ', n3(rt.running ? rt.dtg.z : 0));
    set('sT', `T${st.tool} D${st.offset ? 1 : 0}`); set('sTn', db.tool(st.tool)?.name || '');
    set('sF', rt.liveFeed.toFixed(3)); set('sFo', `${Math.round(rt.feedOv * 100)}%`);
    set('sS', Math.round(rt.liveRpm)); set('sSo', `${Math.round(rt.spindleOv * 100)}%`);
    set('sSd', st.spindle === 1 ? 'M3 ⟳' : st.spindle === -1 ? 'M4 ⟲' : 'M5 stop');
    set('sG', `G${String(st.motion).padStart(1, '0')}  G18  ${st.units === 21 ? 'G71' : 'G70'}  ${st.feedMode === 99 ? 'G95' : 'G94'}  ${st.css ? 'G96' : 'G97'}  G${st.tnrc}  G${st.wcs}  DIAMON  LIMS=${st.clamp}`);
    set('sVol', `${rt.stock.removedVolume().toFixed(2)} cm³`);
    set('sProgName', active());
    const bl = $('#sBlocks');
    if (bl && (force || bl.dataset.l !== String(rt.currentLine))) {
      const lines = lib[active()].split('\n'); const cur = rt.running ? rt.currentLine : 0;
      const from = Math.max(1, (cur || 1) - 2);
      bl.innerHTML = lines.slice(from - 1, from + 5).map((l, i) => `<div class="${from + i === cur ? 'cur' : ''}"><span>${from + i}</span>${esc(l) || ' '}</div>`).join('');
      bl.dataset.l = String(rt.currentLine);
    }
    // MCP LEDs
    $$('[data-m]', $('#sieMcp')).forEach((b) => b.classList.toggle('on', b.dataset.m === rt.mode));
    $$('[data-i]', $('#sieMcp')).forEach((b) => b.classList.toggle('on', +b.dataset.i === S.inc));
    $('[data-t="singleBlock"]').classList.toggle('on', rt.singleBlock);
    $('[data-u="rov"]').classList.toggle('on', S.rov);
    $('[data-u="cool"]').classList.toggle('on', st.coolant);
    $('[data-j="rapid"]').classList.toggle('on', rt.jogRapid);
    $$('[data-sp]', $('#sieMcp')).forEach((b) => b.classList.toggle('on', +b.dataset.sp === st.spindle));
    $('#sStart').classList.toggle('lit', rt.running && !rt.hold && !rt.stopped);
    $('#sStop').classList.toggle('lit', rt.running && (rt.hold || rt.stopped));
    $('#sEstop').classList.toggle('on', rt.estop);
    $('#sHwAx').textContent = S.hwAxis.toUpperCase();
    $('#sSpOv').textContent = `${Math.round(rt.spindleOv * 100)}%`;
  }

  // ------------------------------------------------------------- softkeys ---
  function softkey(id) {
    const go = (area) => { S.area = area; S.buf = ''; render(); };
    switch (id) {
      case 'v2d': case 'v3d': case 'vsplit': api.setView(id.slice(1)); break;
      case 'clr': rt.trail = []; break;
      case 'stock': api.openStock(); break;
      case 'mcs': S.mcs = !S.mcs; break;
      case 'gf': S.showG = !S.showG; break;
      case 'pctl': S.progCtrl = true; break;
      case 'back': S.progCtrl = false; break;
      case 'dry': rt.dryRun = !rt.dryRun; break;
      case 'skp': rt.blockSkip = !rt.blockSkip; rt.preview(); break;
      case 'm01': rt.optStop = !rt.optStop; break;
      case 'sbl': rt.singleBlock = !rt.singleBlock; break;
      case 'mdadel': S.mda = ''; break;
      case 'hwx': S.hwAxis = 'x'; break;
      case 'hwz': S.hwAxis = 'z'; break;
      case 'pm': return go('PM');
      // program
      case 'exec': commitEditor(); rt.setMode('MEM'); return go('MACHINE');
      case 'check': { const p = parseAny(lib[active()], dialectOf(active()), rt.dialectOpts()); rt.message(p.errors.length ? `${p.errors.length} syntax error(s) — see editor` : `Syntax check OK — ${p.blocks.length} blocks`); gutter(); break; }
      case 'cyc': case 'turn': return openForm('C95');
      case 'grv': return openForm('C93');
      case 'tsm': case 'setwo': case 'face': return openForm({ tsm: 'TSM', setwo: 'WO', face: 'FACE' }[id]);
      case 'meast': S.area = 'OFFSET'; S.offSub = 'MEAS'; S.buf = ''; break;
      case 'fok': return formOk();
      case 'fcancel': S.form = null; S.buf = ''; break;
      case 'hclose': S.help = false; break;
      case 'rclr': rt.dialectOpts().R.fill(0); reloadProgram(); break;
      case 'lbl': case 'cont': insertText('CONT_S: G1 X20 Z0\nZ-20\nCONT_E: X54\n'); return;
      case 'sim': api.setView('split'); break;
      case 'close': return go('MACHINE');
      // offset
      case 'LIST': case 'WEAR': case 'WORK': case 'MEAS': case 'RPAR':
        S.offSub = id; S.buf = ''; S.sel = { r: 0, c: id === 'WEAR' ? 'wearX' : id === 'WORK' ? 'wx' : 'lenX' }; break;
      case 'act': { const t = db.data.tools[S.sel.r]; if (t) rt.indexTool(t.station); break; }
      case 'mfx': S.measField = 'X'; S.buf = ''; break;
      case 'mfz': S.measField = 'Z'; S.buf = ''; break;
      case 'mx': case 'mz': measure(id === 'mx' ? 'X' : 'Z'); break;
      // program manager
      case 'pexec': case 'popen': {
        if (rt.running) { rt.message('Program running — stop first'); break; }
        const k = S.pmKeys[S.pmSel]; api.loadProgram(k);
        if (id === 'pexec') { rt.setMode('MEM'); return go('MACHINE'); } return go('PROGRAM');
      }
      case 'pnew': { let n = 1; while (lib[`PART_${n}.MPF`]) n++; const k = `PART_${n}.MPF`; lib[k] = `; ${k}\nN10 G71 G95 G90 DIAMON\nN20 T1 D1\nN30 G96 S180 LIMS=2500 M3\nN40 G0 X54 Z2 M8\nN50 M30\n`; api.saveLib(); api.loadProgram(k); return go('PROGRAM'); }
      case 'pcopy': { const k = S.pmKeys[S.pmSel]; const nk = k.replace(/(\.\w+)?$/, (e) => `_COPY${e || ''}`); lib[nk] = lib[k]; api.saveLib(); break; }
      case 'pdel': { const k = S.pmKeys[S.pmSel]; if (Object.keys(lib).length < 2 || k === active() && rt.running) break; delete lib[k]; api.saveLib(); if (k === active()) api.loadProgram(Object.keys(lib).find((x) => dialectOf(x) === 'siemens') || Object.keys(lib)[0]); break; }
      case 'pexp': { const k = S.pmKeys[S.pmSel]; const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([lib[k]], { type: 'text/plain' })); a.download = /\./.test(k) ? k : `${k}.nc`; a.click(); break; }
      case 'pimp': $('#sImport').click(); return;
      // alarm / system
      case 'alist': S.log = false; break;
      case 'alog': S.log = true; break;
      case 'aclr': rt.messages = []; break;
      case 'tofanuc': api.switchController('fanuc'); return;
      case 'rstdb': db.resetAll(); rt.message('Tool data reset to defaults'); break;
    }
    render();
  }
  function measure(ax) {
    const v = parseFloat(S.buf); if (!Number.isFinite(v)) return rt.message('Enter the measured value first');
    const o = db.getOffset(rt.state.offset); if (!o) return rt.message('17180 Illegal D number');
    const pm = rt.machinePos(), sh = db.workShift(rt.state.wcs);
    const geom = ax === 'X' ? pm.x - v - o.wearX - sh.x : pm.z - v - o.wearZ - sh.z;
    const e = db.setOffset(o.n, ax === 'X' ? 'geomX' : 'geomZ', geom, false);
    if (e) return rt.message(e);
    rt.offsetsChanged(pm); rt.preview(); S.buf = '';
    rt.message(`Length ${ax} set to ${(-geom).toFixed(3)} (measured ${ax}${v.toFixed(3)})`);
  }
  function commitCell() {
    const v = parseFloat(S.buf); if (!Number.isFinite(v)) { S.buf = ''; return render(); }
    const pm = rt.machinePos(); let e = null; const c = S.sel.c;
    if (S.offSub === 'WORK') e = db.setWork(db.data.work[S.sel.r].code, c === 'wx' ? 'x' : 'z', v, false);
    else {
      const t = db.data.tools[S.sel.r]; const n = t.station;
      const map = { lenX: ['geomX', -v], lenZ: ['geomZ', -v], radius: ['radius', v], tip: ['tip', v], wearX: ['wearX', v], wearZ: ['wearZ', v] }[c];
      e = db.setOffset(n, map[0], map[1], false);
    }
    if (e) rt.message(e); else { rt.offsetsChanged(pm); rt.preview(); api.refreshEstimate(); }
    S.buf = ''; render();
  }
  function insertText(txt) {
    const ta = textTarget(); if (!ta || ta.readOnly) return rt.message('Open the program editor first');
    const p = ta.selectionStart;
    ta.setRangeText(txt, p, ta.selectionEnd, 'end'); ta.focus(); ta.dispatchEvent(new Event('input'));
  }

  // ------------------------------------------------------ cycle / JOG forms ---
  function reloadProgram() { rt.load(lib[active()], dialectOf(active())); api.refreshEstimate(); }
  const VARI95 = ['1 Long. outside rough', '2 Face outside rough', '3 Long. inside rough', '4 Face inside rough', '5 Long. outside finish', '6 Face outside finish', '7 Long. inside finish', '8 Face inside finish', '9 Long. outside complete', '10 Face outside complete', '11 Long. inside complete', '12 Face inside complete'];
  function caretLine() {
    const ta = $('#sEd'); const v = lib[active()];
    const p = S.caret ?? (ta ? ta.selectionStart : 0); const ln = v.slice(0, p).split('\n').length - 1;
    return { ln, text: v.split('\n')[ln] || '' };
  }
  function openForm(id) {
    if ((id === 'C95' || id === 'C93') && dialectOf(active()) !== 'siemens') { rt.message('Cycle screens need a SINUMERIK (.MPF) program'); return; }
    if ((id === 'C95' || id === 'C93') && rt.running) { rt.message('Program running — stop first'); return; }
    S.caret = undefined;
    if (S.area === 'PROGRAM') { const ta = $('#sEd'); if (ta) S.caret = ta.selectionStart; commitEditor(); }
    const st = rt.state;
    const F = (k, l, v, u = '', h = '', t = 'n', o) => ({ k, l, v, u, h, t, o });
    let f;
    if (id === 'C95') {
      const cur = /CYCLE95\s*\(([^)]*)\)/.exec(caretLine().text); const a = cur ? cur[1].split(',').map((x) => x.trim()) : [];
      const g = (i, d) => (a[i] !== undefined && a[i] !== '' ? a[i].replace(/"/g, '') : d);
      f = { id, title: `Stock removal CYCLE95${cur ? ' — recompile line ' + (caretLine().ln + 1) : ''}`, replace: !!cur, fields: [
        F('NPP', 'Contour (labels)', g(0, 'CONT_S:CONT_E'), '', 'Start and end label of the contour, e.g. CONT_S:CONT_E', 'x'),
        F('MID', 'Infeed depth MID', g(1, '1.5'), 'mm', 'Max. depth of cut per roughing pass (radius)'),
        F('FALZ', 'Allowance Z  FALZ', g(2, '0.1'), 'mm', 'Finishing allowance in Z'),
        F('FALX', 'Allowance X  FALX', g(3, '0.2'), 'mm', 'Finishing allowance in X (radius)'),
        F('FAL', 'Allowance FAL', g(4, ''), 'mm', 'Contour-parallel allowance — used when FALZ/FALX are empty'),
        F('FF1', 'Feed rough FF1', g(5, '0.25'), 'mm/rev', 'Roughing feed'),
        F('FF2', 'Feed undercut FF2', g(6, '0.2'), 'mm/rev', 'Feed for undercut elements (not used by the simulator)'),
        F('FF3', 'Feed finish FF3', g(7, '0.12'), 'mm/rev', 'Finishing feed'),
        F('VARI', 'Machining VARI', VARI95[(+g(8, 1) || 1) - 1], '', 'Machining type: rough / finish / complete, longitudinal / face, outside / inside', 's', VARI95),
        F('VRT', 'Lift-off _VRT', g(11, '0.5'), 'mm', 'Lift-off distance after each roughing pass'),
      ] };
    } else if (id === 'C93') {
      f = { id, title: 'Grooving CYCLE93 — rectangular OD groove', fields: [
        F('SPD', 'Start point Ø  SPD', '40', 'mm', 'Diameter on which the groove starts (part diameter)'),
        F('SPL', 'Start point Z  SPL', '-20', 'mm', 'Groove edge on the face side; groove extends toward the chuck'),
        F('WIDG', 'Groove width WIDG', '6', 'mm', 'Must be ≥ tool width (tool data)'),
        F('DIAG', 'Groove depth DIAG', '2', 'mm', 'Depth, radius value, without sign'),
        F('FAL1', 'Allowance base FAL1', '0.1', 'mm', 'Finishing allowance at the groove base'),
        F('FAL2', 'Allowance flank FAL2', '0.1', 'mm', 'Finishing allowance at the flanks'),
        F('IDEP', 'Infeed IDEP', '1', 'mm', 'Peck depth (chip breaking); 0 = single plunge'),
        F('DTB', 'Dwell DTB', '0.2', 's', 'Dwell at the groove base'),
        F('VRT', 'Retract _VRT', '1', 'mm', 'Retraction above SPD between plunges'),
      ] };
    } else if (id === 'TSM') {
      f = { id, run: true, title: 'T, S, M — manual technology functions', fields: [
        F('T', 'Tool T', String(st.tool), '', 'Turret location 1…8'),
        F('D', 'Cutting edge D', '1', '', 'D1 = tool offset, D0 = no offset'),
        F('S', 'Spindle S', String(st.S || 800), 'rpm', 'Constant spindle speed (G97)'),
        F('DIR', 'Spindle direction', st.spindle === -1 ? 'M4 ⟲ left' : st.spindle === 1 ? 'M3 ⟳ right' : 'M5 stop', '', 'SELECT toggles', 's', ['M3 ⟳ right', 'M4 ⟲ left', 'M5 stop']),
        F('M', 'Other M function', '—', '', 'Coolant', 's', ['—', 'M8 coolant on', 'M9 coolant off']),
        F('WO', 'Work offset', `G${st.wcs}`, '', 'Active settable zero offset', 's', ['G54', 'G55', 'G56', 'G57', 'G58', 'G59']),
      ] };
    } else if (id === 'WO') {
      const pos = rt.state;
      f = { id, title: `Set WO — G${st.wcs} so the tool reads:`, fields: [
        F('X', 'X Ø', '', 'mm', `Current WCS X ${n3(pos.x)} — leave empty to keep`),
        F('Z', 'Z', '0', 'mm', `Current WCS Z ${n3(pos.z)} — touch the face and set Z0`),
      ] };
    } else if (id === 'FACE') {
      const sd = rt.stock.dia;
      f = { id, run: true, title: 'Facing (JOG) — stock removal on the face', fields: [
        F('X0', 'Start Ø  X0', String(sd + 4), 'mm', 'Outside the blank'),
        F('X1', 'End Ø  X1', '-1.6', 'mm', 'Below centre to remove the pip (≈ −2 × nose radius)'),
        F('Z0', 'Start Z0', String(rt.stock.face ?? 1), 'mm', 'Current face position'),
        F('Z1', 'Final Z1', '0', 'mm', 'Finished face'),
        F('DZ', 'Max. infeed DZ', '0.5', 'mm', 'Depth per pass'),
        F('F', 'Feed F', '0.15', 'mm/rev', ''),
        F('S', 'Cutting speed V', '150', 'm/min', 'G96 constant surface speed, LIMS=2500'),
      ] };
    }
    f.sel = 0; S.form = f; S.buf = ''; render();
  }
  function formHTML() {
    const f = S.form;
    return `<div class="s-sub">${esc(f.title)}</div>
      <div class="s-form">${f.fields.map((x, i) => { const sel = f.sel === i; const val = sel && S.buf ? esc(S.buf) + '<i class="cur">_</i>' : esc(x.v || '—');
        return `<div class="s-frow ${sel ? 'sel' : ''}" data-fi="${i}"><span>${esc(x.l)}</span><b>${x.t === 's' ? '◂ ' : ''}${val}${x.t === 's' ? ' ▸' : ''}</b><em>${esc(x.u)}</em></div>`; }).join('')}</div>
      <div class="s-fhint">${esc(f.fields[f.sel].h || '')}${f.run ? ' · CYCLE START executes in JOG' : ' · Accept writes the block at the cursor'}</div>
      ${f.id === 'C93' ? grooveSketch() : f.id === 'C95' ? stockSketch() : ''}`;
  }
  const grooveSketch = () => `<svg class="s-sk" viewBox="0 0 220 70" aria-hidden="true"><path d="M5 18 H70 V52 H118 V18 H215" fill="none" stroke="#24323d" stroke-width="2"/><path d="M5 62 H215" stroke="#8a96a0" stroke-dasharray="6 3"/><text x="72" y="12">WIDG</text><path d="M70 14 H118" stroke="#f08a00"/><text x="124" y="40">DIAG</text><path d="M121 18 V52" stroke="#f08a00"/><circle cx="118" cy="18" r="3" fill="#009999"/><text x="122" y="14">SPL / SPD</text></svg>`;
  const stockSketch = () => `<svg class="s-sk" viewBox="0 0 220 70" aria-hidden="true"><path d="M5 64 H215" stroke="#8a96a0" stroke-dasharray="6 3"/><path d="M5 12 H210 V64" fill="none" stroke="#b8c0c7"/>${[[17, 15], [27, 100], [32, 105], [40, 170], [46, 177]].map(([y, x]) => `<path d="M210 ${y} H${x}" stroke="#f08a00"/>`).join('')}<path d="M15 22 H95 L110 36 H165 L185 52 H210" fill="none" stroke="#24323d" stroke-width="2"/><text x="20" y="42">MID passes</text><text x="120" y="60">CONT_S … CONT_E</text></svg>`;
  function commitField() {
    const f = S.form; if (!f || !S.buf) return; const x = f.fields[f.sel];
    if (x.t === 'n') { const v = parseFloat(S.buf); if (Number.isFinite(v)) x.v = String(v); else rt.message('Invalid number'); }
    else if (x.t === 'x') x.v = S.buf;
    S.buf = '';
  }
  function cycleOpt(d) { const x = S.form.fields[S.form.sel]; if (x.t !== 's') return; const i = x.o.indexOf(x.v); x.v = x.o[(i + d + x.o.length) % x.o.length]; }
  function formKey(k, ch) {
    const f = S.form; const x = f.fields[f.sel];
    if (ch !== undefined) { if (x.t === 's') return; if (x.t === 'n' && !/[0-9.\-+]/.test(ch)) return; S.buf += ch; return render(); }
    if (k === 'BACK') S.buf = S.buf.slice(0, -1);
    else if (k === 'DEL') { if (S.buf) S.buf = ''; else if (x.t !== 's') x.v = ''; }
    else if (k === 'SELECT' || ((k === 'LEFT' || k === 'RIGHT') && x.t === 's')) cycleOpt(k === 'LEFT' ? -1 : 1);
    else if (k === 'INPUT' || k === 'DOWN') { commitField(); f.sel = Math.min(f.fields.length - 1, f.sel + 1); }
    else if (k === 'UP') { commitField(); f.sel = Math.max(0, f.sel - 1); }
    else if (k === 'END') { commitField(); f.sel = f.fields.length - 1; }
    render();
  }
  function formOk() {
    commitField(); const f = S.form; const v = Object.fromEntries(f.fields.map((x) => [x.k, x.v]));
    const num = (k) => parseFloat(v[k]);
    if (f.id === 'C95' || f.id === 'C93') {
      const vari = f.id === 'C95' ? VARI95.indexOf(v.VARI) + 1 : 1;
      const blk = f.id === 'C95'
        ? `CYCLE95("${v.NPP}",${v.MID},${v.FALZ},${v.FALX},${v.FAL},${v.FF1},${v.FF2},${v.FF3},${vari},,,${v.VRT})`
        : `CYCLE93(${v.SPD},${v.SPL},${v.WIDG},${v.DIAG},0,0,0,0,0,0,0,${v.FAL1},${v.FAL2},${v.IDEP},${v.DTB},1,${v.VRT})`;
      const lines = lib[active()].split('\n'); const { ln } = caretLine();
      if (f.replace) { const m = /^(\s*N\d+\s+)?/.exec(lines[ln]); const tail = lines[ln].includes(';') ? ' ' + lines[ln].slice(lines[ln].indexOf(';')) : ''; lines[ln] = `${m[0]}${blk}${tail}`; }
      else lines.splice(ln, 0, blk);
      lib[active()] = lines.join('\n'); api.saveLib(); reloadProgram();
      S.form = null; S.buf = ''; rt.message(`${f.id === 'C95' ? 'CYCLE95' : 'CYCLE93'} ${f.replace ? 'recompiled' : 'inserted'} at line ${ln + 1}`);
      const pos = lines.slice(0, ln).join('\n').length + (ln ? 1 : 0); S.caret = undefined;
      render(); const ta = $('#sEd'); if (ta) { ta.focus(); ta.selectionStart = ta.selectionEnd = pos; } return;
    }
    if (f.id === 'WO') {
      const pm = rt.machinePos(); const o = rt.off(); const code = `G${rt.state.wcs}`;
      if (v.X !== '' && Number.isFinite(num('X'))) db.setWork(code, 'x', pm.x - o.geomX - o.wearX - num('X'), false);
      if (v.Z !== '' && Number.isFinite(num('Z'))) db.setWork(code, 'z', pm.z - o.geomZ - o.wearZ - num('Z'), false);
      rt.offsetsChanged(pm); rt.preview(); api.refreshEstimate();
      rt.message(`${code} set — X ${n3(rt.state.x)}  Z ${n3(rt.state.z)}`);
      S.form = null; return render();
    }
    if (rt.mode !== 'JOG' && rt.mode !== 'HND') { rt.message('Select JOG mode'); return; }
    let src = '';
    if (f.id === 'TSM') {
      const dir = v.DIR.slice(0, 2); const m = v.M.startsWith('M') ? v.M.slice(0, 2) : '';
      src = `T${num('T')} D${num('D')}\nG97 S${num('S')} ${dir}\n${m}\n${v.WO}`;
    } else if (f.id === 'FACE') {
      const X0 = num('X0'), X1 = num('X1'), Z0 = num('Z0'), Z1 = num('Z1'), DZ = Math.max(0.05, num('DZ'));
      if (!(Z0 > Z1)) { rt.message('Facing: Z0 must be greater than Z1'); return; }
      const n = Math.ceil((Z0 - Z1) / DZ - 1e-9); const L = [`G96 S${num('S')} LIMS=2500 M3`, 'G95', `G0 X${X0}`, `G0 Z${+(Z0 + 1).toFixed(3)}`];
      for (let k = 1; k <= n; k++) { const z = +(Z0 - ((Z0 - Z1) * k) / n).toFixed(3); L.push(`G0 Z${z}`, `G1 X${X1} F${num('F')}`, `G0 Z${+(z + 1).toFixed(3)}`, `G0 X${X0}`); }
      src = L.join('\n');
    }
    S.form = null; render(); rt.runJogCycle(src, 'siemens');
  }
  const HELP = {
    MACHINE: 'Machine area. Actual values in WCS/MCS, distance-to-go, T/F/S. MCP modes: AUTO runs the selected program, MDA runs the MDA window, JOG moves axes ([VAR] = hold key, 1…1000 = increments ×0.001 mm), REF POINT approaches + direction, HANDWHEEL uses the MPG. JOG soft keys: T,S,M (tool, spindle, coolant, work offset — CYCLE START executes), Set WO (zero the work offset on the current position), Facing (JOG facing cycle), Meas. tool.',
    PROGRAM: 'Program editor (no EDIT mode on the 808D — edit whenever the channel is reset). CYCLE95 / CYCLE93 open parameter screens; with the cursor on an existing CYCLE95 line the screen is prefilled and Accept recompiles that line. Check syntax runs the translator; errors are marked in the gutter. Execute selects the program for AUTO.',
    OFFSET: 'Tool list: Length X/Z (positive), radius, tip position. Tool wear: Δ Length X/Z (±1 mm per input). Work offset: G54–G59. Measure tool: scratch the part, key in the measured value, Set length X/Z. R variables: R0–R99, used in programs as X=R1+2, CR=R3 or as cycle parameters; values persist after M30. Select a cell, type the value, INPUT.',
    PM: 'Program manager: ▲▼ select, SELECT/INPUT opens. .MPF = SINUMERIK dialect, ISO = Fanuc-compatible (G291). Execute selects for AUTO and switches to the Machine area.',
    ALARM: 'Alarm list with 808D-style numbers. RESET (MCP) clears machine alarms; ALARM CANCEL clears cancel alarms. Messages shows the operator log.',
    SYSTEM: 'Simulated machine data, blank setup and controller switch.',
  };
  function helpHTML() {
    const ff = S.form ? S.form.fields[S.form.sel] : null;
    return `<div class="s-sub">Help — ${AREA_TITLE[S.area]}</div><div class="s-helpt">${esc(HELP[S.area])}</div>
      <div class="s-helpt"><b>Keys:</b> ^ RECALL closes windows / goes back · HELP toggles this page · INPUT confirms · SELECT toggles options · ALARM CANCEL clears cancel alarms.</div>${ff ? `<div class="s-helpt"><b>${esc(ff.l)}:</b> ${esc(ff.h)}</div>` : ''}`;
  }

  // --------------------------------------------------------------- keypad ---
  function key(k, ch) {
    const ta = textTarget();
    if (k === 'ALMCAN') { if (!rt.estop) { rt.alarms = []; rt.emit('alarm'); } return update(); }
    if (k === 'HELP') { S.help = !S.help; return render(); }
    if (k === 'RECALL') {
      if (S.help) S.help = false; else if (S.form) { S.form = null; S.buf = ''; } else if (S.progCtrl) S.progCtrl = false; else if (S.area !== 'MACHINE') S.area = 'MACHINE';
      return render();
    }
    if (S.help) return;
    if (S.form) return formKey(k, ch);
    if (ta && !ta.readOnly && document.body.contains(ta)) {
      const p = ta.selectionStart, e = ta.selectionEnd, v = ta.value;
      const lineStart = v.lastIndexOf('\n', p - 1) + 1; const col = p - lineStart;
      const move = (pos) => { ta.selectionStart = ta.selectionEnd = Math.max(0, Math.min(v.length, pos)); };
      if (ch !== undefined) ta.setRangeText(ch, p, e, 'end');
      else if (k === 'INPUT') ta.setRangeText('\n', p, e, 'end');
      else if (k === 'BACK') { if (p === e && p > 0) ta.setRangeText('', p - 1, p, 'end'); else ta.setRangeText('', p, e, 'end'); }
      else if (k === 'DEL') { ta.setRangeText('', p, p === e ? p + 1 : e, 'end'); }
      else if (k === 'LEFT') move(p - 1);
      else if (k === 'RIGHT') move(p + 1);
      else if (k === 'END') { const le = v.indexOf('\n', p); move(le < 0 ? v.length : le); }
      else if (k === 'UP' || k === 'DOWN' || k === 'PGUP' || k === 'PGDN') {
        const lines = v.split('\n'); const cur = v.slice(0, p).split('\n').length - 1;
        const tgt = Math.max(0, Math.min(lines.length - 1, cur + ({ UP: -1, DOWN: 1, PGUP: -10, PGDN: 10 }[k])));
        move(lines.slice(0, tgt).join('\n').length + (tgt ? 1 : 0) + Math.min(col, lines[tgt].length));
      }
      if (ch !== undefined || ['INPUT', 'BACK', 'DEL'].includes(k)) ta.dispatchEvent(new Event('input'));
      ta.focus();
      return;
    }
    if (S.area === 'OFFSET' && S.offSub === 'RPAR') {
      if (ch !== undefined) { if (/[0-9.\-+]/.test(ch)) S.buf += ch; return render(); }
      if (k === 'BACK') S.buf = S.buf.slice(0, -1); else if (k === 'DEL') S.buf = '';
      else if (k === 'INPUT') { const v = parseFloat(S.buf); if (Number.isFinite(v)) { rt.dialectOpts().R[S.rpSel] = v; reloadProgram(); } S.buf = ''; S.rpSel = Math.min(99, S.rpSel + 1); }
      else { const d = { UP: -1, DOWN: 1, LEFT: -50, RIGHT: 50, PGUP: -10, PGDN: 10 }[k]; if (d) { S.rpSel = Math.max(0, Math.min(99, S.rpSel + d)); S.buf = ''; } }
      return render();
    }
    if (S.area === 'OFFSET') {
      if (ch !== undefined) { if (/[0-9.\-+]/.test(ch)) { S.buf += ch; } return render(); }
      if (k === 'BACK') { S.buf = S.buf.slice(0, -1); return render(); }
      if (k === 'DEL') { S.buf = ''; return render(); }
      if (S.offSub === 'MEAS') { if (k === 'INPUT') measure(S.measField); else if (k === 'UP' || k === 'DOWN') S.measField = S.measField === 'X' ? 'Z' : 'X'; return render(); }
      if (k === 'INPUT') return commitCell();
      const cols = S.offSub === 'WORK' ? ['wx', 'wz'] : S.offSub === 'WEAR' ? ['wearX', 'wearZ'] : ['lenX', 'lenZ', 'radius', 'tip'];
      const rows = S.offSub === 'WORK' ? db.data.work.length : db.data.tools.length;
      let ci = Math.max(0, cols.indexOf(S.sel.c));
      if (k === 'UP') S.sel.r = Math.max(0, S.sel.r - 1);
      if (k === 'DOWN') S.sel.r = Math.min(rows - 1, S.sel.r + 1);
      if (k === 'LEFT') ci = Math.max(0, ci - 1);
      if (k === 'RIGHT' || k === 'SELECT') ci = Math.min(cols.length - 1, ci + 1);
      S.sel.c = cols[ci]; S.buf = '';
      return render();
    }
    if (S.area === 'PM') {
      if (k === 'UP') S.pmSel = Math.max(0, S.pmSel - 1);
      if (k === 'DOWN') S.pmSel = Math.min(S.pmKeys.length - 1, S.pmSel + 1);
      if (k === 'INPUT' || k === 'SELECT') return softkey('popen');
      return render();
    }
  }

  // ------------------------------------------------------------- bindings ---
  const unit = $('#sieUnit'), mcp = $('#sieMcp');
  // keep focus in the editor while clicking PPU keys
  unit.addEventListener('pointerdown', (e) => { if (e.target.closest('.s-pad button')) e.preventDefault(); });
  unit.addEventListener('click', (e) => {
    const b = e.target.closest('button');
    if (b?.dataset.area) { S.area = b.dataset.area; S.buf = ''; S.progCtrl = false; return render(); }
    if (b?.dataset.sk) return softkey(b.dataset.sk);
    if (b?.dataset.ch !== undefined) return key(null, b.dataset.ch);
    if (b?.dataset.k) return key(b.dataset.k);
    const rp = e.target.closest('td[data-rp]');
    if (rp) { S.rpSel = +rp.dataset.rp; S.buf = ''; return render(); }
    const fr = e.target.closest('[data-fi]');
    if (fr && S.form) { const i = +fr.dataset.fi; if (S.form.sel === i && S.form.fields[i].t === 's') cycleOpt(1); else { commitField(); S.form.sel = i; } return render(); }
    const td = e.target.closest('td.ed');
    if (td) { S.sel = { r: +td.dataset.r, c: td.dataset.c }; S.buf = ''; return render(); }
    const tr = e.target.closest('tr[data-pm]');
    if (tr) { if (S.pmSel === +tr.dataset.pm && e.detail > 1) return softkey('popen'); S.pmSel = +tr.dataset.pm; return render(); }
  });
  unit.addEventListener('dblclick', (e) => { if (e.target.closest('tr[data-pm]')) softkey('popen'); });
  unit.addEventListener('change', (e) => {
    if (e.target.id !== 'sImport') return; const f = e.target.files[0]; if (!f) return;
    f.text().then((t) => { const k = f.name.toUpperCase(); lib[k] = t.toUpperCase().replace(/\r/g, ''); api.saveLib(); api.loadProgram(k); S.area = 'PROGRAM'; render(); });
  });
  $('#sScreen').addEventListener('keydown', (e) => {
    if (e.target.tagName === 'TEXTAREA') return;
    if (/^[0-9.\-]$/.test(e.key)) { key(null, e.key); e.preventDefault(); }
    else if (e.key === 'Enter') key('INPUT'); else if (e.key === 'Backspace') { key('BACK'); e.preventDefault(); }
    else if (e.key.startsWith('Arrow')) { key(e.key.slice(5).toUpperCase()); e.preventDefault(); }
  });

  mcp.addEventListener('click', (e) => {
    const b = e.target.closest('button'); if (!b) return;
    if (b.dataset.m) {
      if (rt.running && !rt.hold && !rt.stopped) return rt.message('Stop the program before changing mode');
      rt.setMode(b.dataset.m); S.area = 'MACHINE'; S.progCtrl = false; return render();
    }
    if (b.dataset.i !== undefined) { S.inc = +b.dataset.i; rt.increment = S.inc || 0.001; return render(); }
    if (b.dataset.t) { rt[b.dataset.t] = !rt[b.dataset.t]; return update(); }
    if (b.dataset.u === 'rov') { S.rov = !S.rov; applyFeed(); return update(); }
    if (b.dataset.u === 'cool') { if (rt.mode === 'JOG' || rt.mode === 'HND' || rt.mode === 'MDI') rt.state.coolant = !rt.state.coolant; else rt.message('Coolant key: JOG/HANDWHEEL/MDA'); return update(); }
    if (b.dataset.u === 'tool') {
      if (rt.mode !== 'JOG' && rt.mode !== 'HND') return rt.message('Turret index: JOG mode');
      const n = (rt.state.tool % db.data.tools.length) + 1; rt.indexTool(n); rt.message(`Turret indexed to T${n} D1`); return render();
    }
    if (b.dataset.sp !== undefined) {
      const d = +b.dataset.sp;
      if (d !== 0 && rt.mode !== 'JOG' && rt.mode !== 'HND') return rt.message('Spindle keys: JOG mode');
      rt.spindle(d); return update();
    }
    if (b.dataset.so !== undefined) { const d = +b.dataset.so; rt.spindleOv = d === 0 ? 1 : Math.min(1.2, Math.max(0.5, Math.round((rt.spindleOv + d * 0.05) * 100) / 100)); return update(); }
    if (b.dataset.j === 'rapid') { rt.jogRapid = !rt.jogRapid; return update(); }
  });
  $('#sStart').addEventListener('click', () => {
    if (S.form?.run && !rt.running) return formOk();
    if (rt.mode === 'MDI') { const ta = $('#sMdaTa'); if (ta) S.mda = ta.value; }
    rt.mdiDialect = 'siemens'; rt.cycleStart(S.mda); update();
  });
  $('#sStop').addEventListener('click', () => { rt.feedHold(); update(); });
  $('#sReset').addEventListener('click', () => { rt.reset(); S.buf = ''; render(); });
  $('#sEstop').addEventListener('click', () => { if (rt.estop) { rt.estop = false; rt.message('Emergency stop released — press RESET'); } else rt.emergency(); update(); });
  // axis keys: hold for [VAR], press for increments, + for REF POINT
  $$('[data-j]', mcp).forEach((b) => {
    if (b.dataset.j === 'rapid') return;
    const axis = b.dataset.j[0], dir = b.dataset.j[1] === '+' ? 1 : -1;
    const down = (e) => {
      e.preventDefault(); b.classList.add('press');
      if (rt.mode === 'JOG') { if (S.inc) rt.jogIncrement(axis, dir); else rt.startJog(axis, dir); }
      else if (rt.mode === 'HND') { S.hwAxis = axis; rt.jogIncrement(axis, dir); render(); }
      else if (rt.mode === 'ZRN') { if (dir > 0) { rt.referenceReturn(axis); S.ref[axis] = true; render(); } else rt.message('Reference point approach in + direction'); }
      else rt.message('Axis keys: JOG, HANDWHEEL or REF POINT');
    };
    const up = () => { b.classList.remove('press'); rt.stopJog(); };
    b.addEventListener('pointerdown', down); b.addEventListener('pointerup', up); b.addEventListener('pointerleave', up); b.addEventListener('pointercancel', up);
  });
  // feed override rotary switch
  function applyFeed() {
    const pct = FEED_STEPS[S.feedIdx];
    rt.feedOv = pct / 100; rt.rapidOv = S.rov ? Math.max(0.01, Math.min(1, pct / 100)) : 1;
    $('#sFeedOv').textContent = `${pct}%`; $('#sKnob').setAttribute('aria-valuenow', pct);
    $('#sKnobIn').style.transform = `rotate(${-135 + (S.feedIdx / (FEED_STEPS.length - 1)) * 270}deg)`;
  }
  (() => {
    const kn = $('#sKnob'); let last = null, acc = 0;
    const ang = (e) => { const r = kn.getBoundingClientRect(); return Math.atan2(e.clientY - (r.top + r.height / 2), e.clientX - (r.left + r.width / 2)); };
    kn.addEventListener('pointerdown', (e) => { kn.setPointerCapture(e.pointerId); last = ang(e); acc = 0; kn._moved = false; });
    kn.addEventListener('pointermove', (e) => {
      if (last === null) return; const a = ang(e); let d = a - last; if (d > Math.PI) d -= 2 * Math.PI; if (d < -Math.PI) d += 2 * Math.PI; last = a; acc += d;
      const step = (270 / (FEED_STEPS.length - 1)) * Math.PI / 180;
      while (Math.abs(acc) >= step) { S.feedIdx = Math.max(0, Math.min(FEED_STEPS.length - 1, S.feedIdx + Math.sign(acc))); acc -= Math.sign(acc) * step; kn._moved = true; applyFeed(); }
    });
    kn.addEventListener('pointerup', (e) => {
      if (!kn._moved) { const r = kn.getBoundingClientRect(); S.feedIdx = Math.max(0, Math.min(FEED_STEPS.length - 1, S.feedIdx + (e.clientX < r.left + r.width / 2 ? -1 : 1))); applyFeed(); }
      last = null;
    });
    kn.addEventListener('wheel', (e) => { e.preventDefault(); S.feedIdx = Math.max(0, Math.min(FEED_STEPS.length - 1, S.feedIdx + (e.deltaY < 0 ? 1 : -1))); applyFeed(); }, { passive: false });
    kn.addEventListener('keydown', (e) => { if (e.key === 'ArrowRight' || e.key === 'ArrowUp') S.feedIdx = Math.min(FEED_STEPS.length - 1, S.feedIdx + 1); if (e.key === 'ArrowLeft' || e.key === 'ArrowDown') S.feedIdx = Math.max(0, S.feedIdx - 1); applyFeed(); });
  })();
  // handwheel
  (() => {
    const mpg = $('#sMpg'), k = $('#sMpgK'); let last = null, rot = 0, acc = 0;
    const ang = (e) => { const r = mpg.getBoundingClientRect(); return Math.atan2(e.clientY - (r.top + r.height / 2), e.clientX - (r.left + r.width / 2)); };
    mpg.addEventListener('pointerdown', (e) => { mpg.setPointerCapture(e.pointerId); last = ang(e); });
    mpg.addEventListener('pointermove', (e) => {
      if (last === null) return; const a = ang(e); let d = a - last; if (d > Math.PI) d -= 2 * Math.PI; if (d < -Math.PI) d += 2 * Math.PI; last = a;
      rot += d; acc += d; k.style.transform = `rotate(${rot}rad)`;
      const step = (2 * Math.PI) / 100; const c = Math.trunc(acc / step);
      if (c) { acc -= c * step; if (rt.mode === 'HND') { rt.increment = S.inc || 0.001; rt.handleClick(S.hwAxis, c); } }
    });
    const up = () => { last = null; }; mpg.addEventListener('pointerup', up); mpg.addEventListener('pointercancel', up);
    mpg.addEventListener('keydown', (e) => { if (rt.mode !== 'HND') return; rt.increment = S.inc || 0.001; if (e.key === 'ArrowRight' || e.key === 'ArrowUp') rt.handleClick(S.hwAxis, 1); if (e.key === 'ArrowLeft' || e.key === 'ArrowDown') rt.handleClick(S.hwAxis, -1); });
  })();

  return {
    activate() {
      if (rt.mode === 'EDIT') rt.setMode('JOG');
      rt.mdiDialect = 'siemens'; rt.increment = S.inc || 0.001; applyFeed(); render();
    },
    render, update: () => update(false),
    onEvent(type, data) {
      if (type === 'program' && S.area === 'PROGRAM' && !S.form && !S.help && $('#sEd')) { gutter(); return; }
      if (type === 'finish' && !data?.mdi && rt.dialect === 'siemens' && rt.parsed?.rFinal) { const R = rt.dialectOpts().R; rt.parsed.rFinal.forEach((v, i) => { R[i] = v; }); reloadProgram(); } if (type === 'alarm' && S.area === 'ALARM') render(); if (type === 'mode' || type === 'program' || type === 'finish' || type === 'reset') render(); },
  };
}
