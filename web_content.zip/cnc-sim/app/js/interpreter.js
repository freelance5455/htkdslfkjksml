// ============================================================================
// Interpreter / Motion Planner
// Block AST  ->  ordered list of executable "steps" (moves, dwells, stops,
// state changes). Canned cycles G70/G71/G72 are expanded here into plain
// rapid/feed moves, so the renderer and animator only ever see polylines.
//
// Coordinate conventions (Fanuc lathe, G18, rear tool-post view):
//   X = diameter value (programmed), Z = axial. Internally geometry that needs
//   true distances converts X to radius (x/2) and back.
//   machine = absolute(work) + workShift + geometryOffset + wearOffset
//   physical tool tip (ideal tool) = absolute + wearOffset
// ============================================================================
import { ALARMS, G_CODES } from './parser.js';

export const RAPID_MM_MIN = 12000;
const ARC_CHORD_TOL = 0.01; // mm chord deviation for tessellation

export function createState(o = {}) {
  return {
    x: 200, z: 150, motion: 0, feedMode: 99, F: 0, S: 0, css: false, clamp: 4000,
    units: 21, tnrc: 40, wcs: 54, spindle: 0, coolant: false, tool: 1, offset: 1,
    cyc71: { d: 1.0, e: 0.5 }, cyc72: { d: 1.0, e: 0.5 }, ended: false, ...o,
  };
}

const snap = (s) => ({
  x: s.x, z: s.z, motion: s.motion, feedMode: s.feedMode, F: s.F, S: s.S, css: s.css, clamp: s.clamp,
  units: s.units, tnrc: s.tnrc, wcs: s.wcs, spindle: s.spindle, coolant: s.coolant, tool: s.tool, offset: s.offset,
});
const feedSpec = (s) => ({ F: s.F, mode: s.feedMode, S: s.S, css: s.css, clamp: s.clamp });

/** Actual feed in mm/min for a given diameter (handles G96 CSS + G50 clamp + G99). */
export function rpmAt(spec, dia, spindleOverride = 1) {
  if (!spec.css) return spec.S * spindleOverride;
  const d = Math.max(Math.abs(dia), 0.5);
  return Math.min(spec.clamp || 99999, (1000 * spec.S) / (Math.PI * d)) * spindleOverride;
}
export function feedMmMin(spec, dia, spindleOverride = 1) {
  if (spec.mode === 98) return spec.F;
  return spec.F * rpmAt(spec, dia, spindleOverride);
}

/**
 * Tessellate a ZX-plane arc. Points are {x: diameter, z}.
 * Screen orientation: +Z right, +X up; G02 = clockwise (viewed from +Y).
 */
export function arcPoints(from, to, cw, w, err) {
  const a = { u: from.z, v: from.x / 2 };
  const b = { u: to.z, v: to.x / 2 };
  let c;
  if ('R' in w) {
    const R = w.R;
    const du = b.u - a.u, dv = b.v - a.v;
    const chord = Math.hypot(du, dv);
    if (chord < 1e-9) { err('PS0020', 'zero-length arc'); return [to]; }
    const half = chord / 2;
    if (Math.abs(R) < half - 1e-4) { err('PS0020', `R${R} < chord/2 ${half.toFixed(4)}`); return [to]; }
    const h = Math.sqrt(Math.max(R * R - half * half, 0));
    const s = (cw ? -1 : 1) * (R > 0 ? 1 : -1);
    c = { u: (a.u + b.u) / 2 + (s * h * -dv) / chord, v: (a.v + b.v) / 2 + (s * h * du) / chord };
  } else {
    // I = X-direction (radius) and K = Z-direction incremental from start to centre
    c = { u: a.u + (w.K ?? 0), v: a.v + (w.I ?? 0) };
    const r1 = Math.hypot(a.u - c.u, a.v - c.v), r2 = Math.hypot(b.u - c.u, b.v - c.v);
    if (Math.abs(r1 - r2) > 0.01) { err('PS0020', `start R${r1.toFixed(3)} end R${r2.toFixed(3)}`); }
  }
  const r = Math.hypot(a.u - c.u, a.v - c.v);
  let a0 = Math.atan2(a.v - c.v, a.u - c.u);
  let a1 = Math.atan2(b.v - c.v, b.u - c.u);
  if (cw) { while (a1 >= a0 - 1e-12) a1 -= 2 * Math.PI; } else { while (a1 <= a0 + 1e-12) a1 += 2 * Math.PI; }
  const sweep = Math.abs(a1 - a0);
  const maxStep = r > ARC_CHORD_TOL ? 2 * Math.acos(1 - ARC_CHORD_TOL / r) : sweep;
  const n = Math.max(2, Math.ceil(sweep / Math.max(maxStep, 0.01)));
  const pts = [];
  for (let i = 1; i <= n; i++) {
    const t = a0 + ((a1 - a0) * i) / n;
    pts.push({ z: c.u + r * Math.cos(t), x: 2 * (c.v + r * Math.sin(t)) });
  }
  pts[pts.length - 1] = { x: to.x, z: to.z }; // snap exactly to programmed end point
  return pts;
}

/** Resolve target point from X/Z (absolute) or U/W (incremental) words. */
function target(st, w, k) {
  return {
    x: 'X' in w ? w.X * k : 'U' in w ? st.x + w.U * k : st.x,
    z: 'Z' in w ? w.Z * k : 'W' in w ? st.z + w.W * k : st.z,
  };
}

/**
 * Compile a parsed program into executable steps.
 * @param parsed  output of parseProgram()
 * @param init    machine state (createState())
 * @param ctx     { getOffset(n)->{geomX,geomZ,wearX,wearZ}, workShift(wcs)->{x,z}, blockSkip, startIndex }
 */
export function compile(parsed, init, ctx = {}) {
  const st = createState(init);
  const steps = [];
  const alarms = [];
  const blocks = parsed.blocks;
  const getOff = (n) => (n ? ctx.getOffset?.(n) : null) || { geomX: 0, geomZ: 0, wearX: 0, wearZ: 0 };
  const shift = (w) => ctx.workShift?.(w) || { x: 0, z: 0 };
  let pc = ctx.startIndex ?? 0;
  let guard = 0;
  let curLine = 0;

  const alarm = (code, extra) => alarms.push({ line: curLine, code, message: (ALARMS[code] || code) + (extra ? ` (${extra})` : '') });
  const emit = (step) => { steps.push({ ...step, line: curLine, st: snap(st) }); };
  const move = (to, rapid, spec) => {
    const from = { x: st.x, z: st.z };
    st.x = to.x; st.z = to.z;
    emit({ k: 'move', rapid, pts: [from, { x: to.x, z: to.z }], feed: spec ?? feedSpec(st) });
  };
  const movePts = (pts, rapid, spec) => {
    const from = { x: st.x, z: st.z };
    const last = pts[pts.length - 1];
    st.x = last.x; st.z = last.z;
    emit({ k: 'move', rapid, pts: [from, ...pts], feed: spec ?? feedSpec(st) });
  };
  const homeAbs = () => {
    const o = getOff(st.offset), s = shift(st.wcs);
    return { x: -(s.x + o.geomX + o.wearX), z: -(s.z + o.geomZ + o.wearZ) };
  };

  // --- shape program extraction for G70/G71/G72 -----------------------------
  function extractShape(P, Q, startPt, k) {
    const iP = parsed.index.get(P), iQ = parsed.index.get(Q);
    if (iP === undefined || iQ === undefined) { alarm('PS0063', `P${P} Q${Q}`); return null; }
    const moves = []; // {rapid, pts, F}
    let pos = { ...startPt }, motion = st.motion, F = st.F;
    for (let i = iP; i <= iQ; i++) {
      const b = blocks[i];
      const m = b.g.find((g) => G_CODES[g]?.group === 1);
      if (m !== undefined) motion = m;
      if (b.g.some((g) => g === 70 || g === 71 || g === 72 || g === 28)) { alarm('PS0062', `line ${b.line}`); return null; }
      if ('F' in b.words) F = b.words.F * (st.feedMode === 98 ? k : 1);
      const w = b.words;
      if (!['X', 'Z', 'U', 'W'].some((a) => a in w)) continue;
      const to = target(pos, w, k);
      let pts;
      if (motion === 2 || motion === 3) {
        const ww = { ...w }; ['R', 'I', 'K'].forEach((a) => { if (a in ww) ww[a] *= k; });
        pts = arcPoints(pos, to, motion === 2, ww, (c, e) => alarm(c, e));
      } else pts = [to];
      moves.push({ rapid: motion === 0, pts, F, line: b.line });
      pos = to;
    }
    const profile = [];
    moves.forEach((mv) => mv.pts.forEach((p) => profile.push(p)));
    return { moves, profile, iQ };
  }

  // --- G71/G72 rough stock-removal expansion (Type I, monotonic profile) ------
  function roughCycle(kind, S, profile, d, e, du, dw, spec) {
    const L = kind === 71 ? 'x' : 'z';
    const C = kind === 71 ? 'z' : 'x';
    const R = (p) => ({ x: p.x / 2, z: p.z });                 // to radius space
    const D = (p) => ({ x: p.x * 2, z: p.z });                 // back to diameter
    const s = R(S);
    const P = profile.map((p) => ({ x: p.x / 2 + du / 2, z: p.z + dw }));
    const first = P[0];
    const sign = Math.sign(first[L] - s[L]);
    if (sign === 0 || d <= 0) { alarm('PS0062', 'depth or start point'); return; }
    // monotonicity check on level axis (Type I requirement)
    for (let i = 1; i < P.length; i++) {
      if ((P[i][L] - P[i - 1][L]) * sign > 1e-6) { alarm('PS0064', `at point ${i}`); return; }
    }
    const f = (p, lv) => (p[L] - lv) * sign;
    for (let kx = 1; kx < 10000; kx++) {
      const lv = s[L] + sign * kx * d;
      if ((lv - first[L]) * sign >= -1e-6) break;
      let cutEnd = P[P.length - 1][C];
      for (let i = 0; i < P.length - 1; i++) {
        const a = P[i], b = P[i + 1];
        if (f(a, lv) > 0 && f(b, lv) <= 0) {
          const t = (lv - a[L]) / (b[L] - a[L] || 1e-12);
          cutEnd = a[C] + t * (b[C] - a[C]);
          break;
        }
      }
      const cdir = Math.sign(cutEnd - s[C]) || -1;
      const mk = (lvv, cc) => D(L === 'x' ? { x: lvv, z: cc } : { x: cc, z: lvv });
      move(mk(lv, s[C]), true);
      move(mk(lv, cutEnd), false, spec);
      move(mk(lv - sign * e, cutEnd - cdir * e), true);
      move(mk(lv - sign * e, s[C]), true);
    }
    // semi-finish pass along the offset profile (leaves Δu/Δw for G70)
    move(D(first), true);
    movePts(P.slice(1).map(D), false, spec);
    // return to cycle start point: level axis first, then cut axis
    const ret = L === 'x' ? { x: S.x, z: st.z } : { x: st.x, z: S.z };
    move(ret, true);
    move({ x: S.x, z: S.z }, true);
  }

  while (pc < blocks.length && guard++ < 200000) {
    const b = blocks[pc];
    let next = pc + 1;
    curLine = b.line;
    if (b.blockDelete && ctx.blockSkip) { pc = next; continue; }
    const w = b.words;
    const g = b.g;
    const k = st.units === 20 || g.includes(20) ? 25.4 : 1;
    const before = steps.length;

    // 1. modal settings
    for (const code of g) {
      const grp = G_CODES[code]?.group;
      if (grp === 1) st.motion = code;
      else if (grp === 6) st.units = code;
      else if (grp === 7) st.tnrc = code;
      else if (grp === 14) st.wcs = code;
      else if (grp === 2) st.css = code === 96;
      else if (grp === 5) st.feedMode = code;
    }
    const oneShot = g.find((c) => G_CODES[c]?.group === 0);
    if ('F' in w && oneShot !== 71 && oneShot !== 72) st.F = w.F * (st.feedMode === 98 ? k : 1);
    if ('S' in w && oneShot !== 50) st.S = w.S;
    if ('L' in w && !b.m.includes(98)) st.clamp = w.L; // Siemens LIMS= (translated) — spindle clamp

    // 2. T-code: tool index + offset (position re-expressed so machine pos is constant)
    if ('T' in w) {
      const tool = Math.floor(w.T / 100), off = w.T % 100;
      const o0 = getOff(st.offset), o1 = getOff(off);
      st.x += o0.geomX + o0.wearX - (o1.geomX + o1.wearX);
      st.z += o0.geomZ + o0.wearZ - (o1.geomZ + o1.wearZ);
      if (tool) st.tool = tool;
      st.offset = off;
      emit({ k: 'tool', tool: st.tool, offset: off });
    }
    // 3. pre-motion M-codes
    for (const m of b.m) {
      if (m === 3) st.spindle = 1;
      if (m === 4) st.spindle = -1;
      if (m === 8) st.coolant = true;
    }

    // 4. motion / one-shot
    if (oneShot === 4) {
      const sec = 'P' in w ? w.P / 1000 : 'X' in w ? w.X : 'U' in w ? w.U : 0;
      emit({ k: 'dwell', sec });
    } else if (oneShot === 28) {
      const mid = target(st, w, k);
      move(mid, true);
      move(homeAbs(), true);
    } else if (oneShot === 50) {
      if ('S' in w) st.clamp = w.S;
      if ('X' in w || 'Z' in w) { if ('X' in w) st.x = w.X * k; if ('Z' in w) st.z = w.Z * k; }
    } else if (oneShot === 71 || oneShot === 72) {
      const hasPQ = 'P' in w && 'Q' in w;
      if (!hasPQ) {
        // first block: depth of cut + retract (modal cycle parameters)
        const cp = oneShot === 71 ? st.cyc71 : st.cyc72;
        const dWord = oneShot === 71 ? 'U' : 'W';
        if (dWord in w) cp.d = Math.abs(w[dWord]) * k;
        if ('R' in w) cp.e = Math.abs(w.R) * k;
      } else {
        const S = { x: st.x, z: st.z };
        const shape = extractShape(w.P, w.Q, S, k);
        if (shape) {
          const spec = { ...feedSpec(st), F: 'F' in w ? w.F * (st.feedMode === 98 ? k : 1) : st.F };
          if ('S' in w) spec.S = w.S;
          const cp = oneShot === 71 ? st.cyc71 : st.cyc72;
          roughCycle(oneShot, S, shape.profile, cp.d, cp.e, (w.U ?? 0) * k, (w.W ?? 0) * k, spec);
          if ('F' in w) st.F = spec.F;
          // Fanuc resumes after the shape program; Siemens CYCLE95 (E1) continues after the call
          next = 'E' in w ? pc + 1 : shape.iQ + 1;
        }
      }
    } else if (oneShot === 70) {
      const S = { x: st.x, z: st.z };
      const shape = extractShape(w.P, w.Q, S, k);
      if (shape) {
        shape.moves.forEach((mv) => movePts(mv.pts, mv.rapid, { ...feedSpec(st), F: mv.F }));
        move({ x: S.x, z: st.z }, true);
        move(S, true);
      }
    } else if (['X', 'Z', 'U', 'W'].some((a) => a in w)) {
      const to = target(st, w, k);
      if (st.motion === 0) move(to, true);
      else {
        if (!st.F && st.motion !== 0) alarm('PS0011');
        if (st.motion === 1) move(to, false);
        else {
          const ww = { ...w }; ['R', 'I', 'K'].forEach((a) => { if (a in ww) ww[a] *= k; });
          movePts(arcPoints({ x: st.x, z: st.z }, to, st.motion === 2, ww, (c, e) => alarm(c, e)), false);
        }
      }
    }

    // 5. post-motion M-codes
    let end = false;
    for (const m of b.m) {
      if (m === 5) st.spindle = 0;
      if (m === 9) st.coolant = false;
      if (m === 0 || m === 1) emit({ k: 'stop', optional: m === 1 });
      if (m === 2 || m === 30) { st.spindle = 0; st.coolant = false; emit({ k: 'end', rewind: m === 30 }); end = true; }
      if (m === 98) alarm('PS0078', `P${w.P ?? ''} — subprograms: roadmap`);
    }
    if (steps.length === before) emit({ k: 'state' });
    steps[steps.length - 1].blockEnd = true;
    if (end) { st.ended = true; break; }
    pc = next;
  }
  return { steps, state: st, alarms };
}

/** Collect every move polyline (for the static preview / backplot). */
export function toolpathOf(steps) {
  return steps.filter((s) => s.k === 'move').map((s) => ({ rapid: s.rapid, pts: s.pts, line: s.line }));
}
