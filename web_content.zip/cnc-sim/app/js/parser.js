// ============================================================================
// G-code Parser — ISO 6983 / Fanuc Series 0i-T (lathe) dialect
// Stage 1: Lexer  (characters -> words)
// Stage 2: Parser (words -> Block AST with modal-group validation)
// Pure, dependency-free, deterministic: runs identically in browser, Node,
// React Native (Hermes) or a Web Worker.
// ============================================================================

/** Fanuc-style alarm catalogue (numbers modelled on 0i-T "PS" program alarms). */
export const ALARMS = {
  PS0003: 'TOO MANY DIGITS',
  PS0004: 'ADDRESS NOT FOUND',
  PS0005: 'NO DATA AFTER ADDRESS',
  PS0006: 'ILLEGAL USE OF NEGATIVE SIGN',
  PS0007: 'ILLEGAL USE OF DECIMAL POINT',
  PS0009: 'IMPROPER NC-ADDRESS',
  PS0010: 'IMPROPER G-CODE',
  PS0011: 'FEED ZERO (COMMAND)',
  PS0020: 'OVER TOLERANCE OF RADIUS',
  PS0021: 'ILLEGAL PLANE SELECT',
  PS0029: 'ILLEGAL OFFSET VALUE',
  PS0030: 'ILLEGAL OFFSET NUMBER',
  PS0033: 'NO SOLUTION AT CRC',
  PS0034: 'DUPLICATE ADDRESS',
  PS0035: 'MULTIPLE G-CODES OF SAME GROUP',
  PS0036: 'TOO MANY M-CODES',
  PS0061: 'P OR Q NOT COMMANDED IN CYCLE',
  PS0062: 'ILLEGAL COMMAND IN G71-G76',
  PS0063: 'SEQUENCE NUMBER NOT FOUND',
  PS0064: 'SHAPE PROGRAM NOT MONOTONOUS',
  PS0065: 'G00/G01 NOT IN FIRST SHAPE BLOCK',
  PS0070: 'UNTERMINATED COMMENT',
  PS0078: 'SUBPROGRAM NOT FOUND',
  SIM001: 'RAPID MOVE INTO STOCK',
  SIM002: 'SPINDLE STOPPED DURING CUTTING FEED',
  SIM003: 'OVERTRAVEL',
  SIM004: 'CHUCK COLLISION',
};

/**
 * Modal groups (Fanuc lathe, G-code system A).
 * Group 0 = non-modal (one-shot) codes; at most one of these per block.
 */
export const G_CODES = {
  // group 01 — interpolation (motion)
  0: { group: 1, name: 'Rapid positioning' },
  1: { group: 1, name: 'Linear interpolation' },
  2: { group: 1, name: 'Circular interpolation CW' },
  3: { group: 1, name: 'Circular interpolation CCW' },
  // group 00 — one-shot
  4: { group: 0, name: 'Dwell' },
  28: { group: 0, name: 'Reference position return' },
  50: { group: 0, name: 'Coordinate set / max spindle speed clamp' },
  70: { group: 0, name: 'Finishing cycle' },
  71: { group: 0, name: 'Stock removal in turning (OD/ID)' },
  72: { group: 0, name: 'Stock removal in facing' },
  // group 16 — plane
  18: { group: 16, name: 'ZX plane' },
  // group 06 — units
  20: { group: 6, name: 'Inch input' },
  21: { group: 6, name: 'Metric input' },
  // group 07 — tool-nose radius compensation
  40: { group: 7, name: 'TNRC cancel' },
  41: { group: 7, name: 'TNRC left' },
  42: { group: 7, name: 'TNRC right' },
  // group 14 — work coordinate systems
  54: { group: 14, name: 'Work offset 1' }, 55: { group: 14, name: 'Work offset 2' },
  56: { group: 14, name: 'Work offset 3' }, 57: { group: 14, name: 'Work offset 4' },
  58: { group: 14, name: 'Work offset 5' }, 59: { group: 14, name: 'Work offset 6' },
  // group 02 — spindle speed mode
  96: { group: 2, name: 'Constant surface speed' },
  97: { group: 2, name: 'Constant RPM' },
  // group 05 — feed mode
  98: { group: 5, name: 'Feed per minute' },
  99: { group: 5, name: 'Feed per revolution' },
};

export const M_CODES = {
  0: 'Program stop', 1: 'Optional stop', 2: 'Program end',
  3: 'Spindle CW', 4: 'Spindle CCW', 5: 'Spindle stop',
  6: 'Tool change (mill compat.)', 8: 'Coolant ON', 9: 'Coolant OFF',
  30: 'Program end & rewind', 98: 'Subprogram call', 99: 'Subprogram return',
};

/** Addresses the lexer accepts. Letters not in this set raise PS0009. */
const ADDRESSES = new Set('ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split(''));
/** Addresses whose value must be an integer (no decimal point). */
const INTEGER_ADDRESSES = new Set(['G', 'M', 'N', 'O', 'T', 'P', 'Q', 'L', 'D', 'H']);
/** Max digits (Fanuc: 8 significant digits for dimension words). */
const MAX_DIGITS = 8;

/**
 * Stage 1 — Lexer. Converts one source line into a flat list of tokens.
 * Handles: block delete "/", parenthesised comments, ";" EOB, "%" tape marks.
 * @returns {{tokens: Array, comment: string|null, blockDelete: boolean, errors: Array, tapeMark: boolean}}
 */
export function lexLine(src, lineNo = 1, opts = {}) {
  const tokens = [];
  const errors = [];
  let comment = null;
  let blockDelete = false;
  let tapeMark = false;
  let i = 0;
  const s = src;
  const err = (code, col, extra = '') =>
    errors.push({ line: lineNo, col: col + 1, code, message: ALARMS[code] + (extra ? ` (${extra})` : '') });

  while (i < s.length) {
    const ch = s[i];
    if (ch === ' ' || ch === '\t' || ch === '\r') { i++; continue; }
    if (ch === '%') { tapeMark = true; i++; continue; }
    if (ch === ';' || ch === '\n') { i++; continue; }            // EOB
    if (ch === '/' && tokens.length === 0) { blockDelete = true; i++; continue; }
    if (ch === '(') {
      const end = s.indexOf(')', i);
      if (end < 0) { err('PS0070', i); comment = s.slice(i + 1).trim(); break; }
      const text = s.slice(i + 1, end).trim();
      comment = comment ? `${comment} ${text}` : text;
      i = end + 1; continue;
    }
    const letter = ch.toUpperCase();
    if (!/[A-Z]/.test(letter)) { err('PS0004', i, `'${ch}'`); i++; continue; }
    if (!ADDRESSES.has(letter)) { err('PS0009', i, letter); i++; continue; }
    const col = i;
    i++;
    // number: [+-]? digits [. digits]
    let j = i;
    while (j < s.length && (s[j] === ' ')) j++;               // Fanuc tolerates "X 10."
    let numStr = '';
    if (s[j] === '+' || s[j] === '-') numStr += s[j++];
    while (j < s.length && /[0-9.]/.test(s[j])) numStr += s[j++];
    if (numStr === '' || numStr === '+' || numStr === '-') { err('PS0005', col, letter); i = j; continue; }
    if ((numStr.match(/\./g) || []).length > 1) { err('PS0007', col, letter + numStr); i = j; continue; }
    const digitCount = numStr.replace(/[^0-9]/g, '').replace(/^0+/, '').length;
    if (digitCount > MAX_DIGITS) err('PS0003', col, letter + numStr);
    const hasDecimal = numStr.includes('.');
    if (hasDecimal && INTEGER_ADDRESSES.has(letter) && letter !== 'G') err('PS0007', col, letter + numStr);
    if (numStr.startsWith('-') && (letter === 'N' || letter === 'O' || letter === 'T')) err('PS0006', col, letter + numStr);
    let value = parseFloat(numStr);
    // Decimal-point programming: Fanuc param 3401#0 (DPI). calculator mode: X10 = 10.0 mm;
    // standard mode: X10 = 0.010 mm (least input increment).
    if (!hasDecimal && !INTEGER_ADDRESSES.has(letter) && opts.decimalMode === 'standard') value = value / 1000;
    tokens.push({ letter, value, raw: letter + numStr, col: col + 1, hasDecimal });
    i = j;
  }
  return { tokens, comment, blockDelete, errors, tapeMark };
}

/**
 * Stage 2 — Parse a full program into a list of Block AST nodes.
 * @param {string} source
 * @param {{decimalMode?: 'calculator'|'standard'}} opts
 * @returns {{programNumber: number|null, programName: string|null, blocks: Block[], errors: Array, warnings: Array, index: Map<number, number>}}
 *
 * Block = { line, n, g: number[], m: number[], words: {X,Z,U,W,I,K,R,F,S,T,P,Q,...}, comment, blockDelete, raw }
 */
export function parseProgram(source, opts = {}) {
  const lines = source.split('\n');
  const blocks = [];
  const errors = [];
  const warnings = [];
  const seqIndex = new Map(); // N number -> block index (for G70/G71/G72 P/Q and GOTO)
  let programNumber = null;
  let programName = null;

  lines.forEach((raw, idx) => {
    const lineNo = opts.lineMap ? opts.lineMap[idx] : idx + 1; // dialect translation keeps source lines
    const lx = lexLine(raw, lineNo, opts);
    errors.push(...lx.errors);
    if (lx.tokens.length === 0 && !lx.comment) return;

    const block = {
      line: lineNo, n: null, g: [], m: [], words: {}, comment: lx.comment,
      blockDelete: lx.blockDelete, raw: raw.trim(),
    };
    const groupsSeen = new Map();
    const err = (code, col, extra) => errors.push({ line: lineNo, col, code, message: ALARMS[code] + (extra ? ` (${extra})` : '') });

    for (const t of lx.tokens) {
      switch (t.letter) {
        case 'O':
          programNumber = t.value;
          if (lx.comment && !programName) programName = lx.comment;
          break;
        case 'N':
          block.n = t.value;
          if (seqIndex.has(t.value)) warnings.push({ line: lineNo, code: 'W001', message: `DUPLICATE SEQUENCE N${t.value}` });
          else seqIndex.set(t.value, blocks.length);
          break;
        case 'G': {
          const code = Math.round(t.value * 10) / 10;
          const def = G_CODES[code];
          if (!def) { err('PS0010', t.col, `G${t.value}`); break; }
          const prev = groupsSeen.get(def.group);
          if (prev !== undefined && def.group !== 0) err('PS0035', t.col, `G${prev} & G${code}`);
          if (prev !== undefined && def.group === 0) err('PS0035', t.col, `G${prev} & G${code}`);
          groupsSeen.set(def.group, code);
          block.g.push(code);
          break;
        }
        case 'M': {
          if (!(t.value in M_CODES)) warnings.push({ line: lineNo, code: 'W002', message: `UNKNOWN M${t.value} (passed to PMC)` });
          if (block.m.length >= 1) err('PS0036', t.col, `M${block.m[0]} & M${t.value}`);
          block.m.push(t.value);
          break;
        }
        default:
          if (t.letter in block.words) err('PS0034', t.col, t.letter);
          block.words[t.letter] = t.value;
      }
    }

    // --- semantic checks that need the whole block ---
    const w = block.words;
    const isArc = block.g.includes(2) || block.g.includes(3);
    if (isArc) {
      const hasEnd = ['X', 'Z', 'U', 'W'].some((a) => a in w);
      const hasCenter = 'R' in w || 'I' in w || 'K' in w;
      if (!hasCenter) err('PS0020', 1, 'arc needs R or I/K');
      if (!hasEnd) warnings.push({ line: lineNo, code: 'W003', message: 'ARC WITHOUT END POINT (full circle not supported on lathe)' });
    }
    if (('X' in w && 'U' in w) || ('Z' in w && 'W' in w)) {
      const cycle = block.g.some((g) => g === 71 || g === 72);
      if (!cycle) err('PS0034', 1, 'absolute & incremental on same axis');
    }
    if ('T' in w) {
      const tNum = Math.floor(w.T / 100), off = w.T % 100;
      if (tNum > 12 || tNum < 0) err('PS0030', 1, `T${w.T}`);
      if (off > 64) err('PS0030', 1, `offset ${off}`);
    }
    blocks.push(block);
  });

  // Cycle-level validation (P/Q sequence lookups)
  blocks.forEach((b) => {
    const cyc = b.g.find((g) => g === 70 || g === 71 || g === 72);
    if (cyc === undefined) return;
    const hasPQ = 'P' in b.words || 'Q' in b.words;
    if (cyc === 70 && !hasPQ) errors.push({ line: b.line, col: 1, code: 'PS0061', message: ALARMS.PS0061 });
    if (hasPQ) {
      for (const k of ['P', 'Q']) {
        if (!(k in b.words)) errors.push({ line: b.line, col: 1, code: 'PS0061', message: ALARMS.PS0061 });
        else if (!seqIndex.has(b.words[k])) errors.push({ line: b.line, col: 1, code: 'PS0063', message: `${ALARMS.PS0063} (N${b.words[k]})` });
      }
      const pi = seqIndex.get(b.words.P);
      if (pi !== undefined) {
        const first = blocks[pi];
        const motion = first.g.find((g) => G_CODES[g]?.group === 1);
        if (motion !== undefined && motion !== 0 && motion !== 1)
          errors.push({ line: first.line, col: 1, code: 'PS0065', message: ALARMS.PS0065 });
      }
    }
  });

  return { programNumber, programName, blocks, errors, warnings, index: seqIndex };
}

/** Human-readable block summary, used by the CRT "PROGRAM CHECK" screen. */
export function describeBlock(b) {
  const parts = [];
  b.g.forEach((g) => parts.push(`G${String(g).padStart(2, '0')} ${G_CODES[g]?.name ?? ''}`));
  b.m.forEach((m) => parts.push(`M${String(m).padStart(2, '0')} ${M_CODES[m] ?? ''}`));
  return parts.join(' · ');
}
