// ============================================================================
// 3D Renderer (Three.js / WebGL2). Scene graph:
//   world
//   ├─ spindle group (rotates with live RPM)
//   │   ├─ chuck body + 3 jaws
//   │   └─ workpiece  (LatheGeometry rebuilt from Stock.r(z) when version changes)
//   ├─ toolpath (planned: LineSegments, executed: Line — ZX plane, y = 0)
//   └─ turret  (tool holder + insert, follows tool tip)
// World mapping: machine Z -> world +X, machine X(radius) -> world +Y.
// ============================================================================
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { TOOL_TYPES } from './tooldb.js';

export class Renderer3D {
  constructor(host, rt) {
    this.host = host; this.rt = rt;
    this.renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false });
    this.renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
    this.renderer.setClearColor(0x0d1114);
    host.appendChild(this.renderer.domElement);
    this.scene = new THREE.Scene();
    const pm = new THREE.PMREMGenerator(this.renderer);
    this.scene.environment = pm.fromScene(new RoomEnvironment(), 0.04).texture;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.camera = new THREE.PerspectiveCamera(40, 1, 0.5, 5000);
    this.camera.position.set(40, 85, 200);
    this.controls = new OrbitControls(this.camera, this.renderer.domElement);
    this.controls.target.set(-25, 5, 0); this.controls.enableDamping = true;
    this.scene.add(new THREE.HemisphereLight(0xdfe8f0, 0x20262c, 1.1));
    const key = new THREE.DirectionalLight(0xffffff, 1.6); key.position.set(60, 120, 90); this.scene.add(key);
    const rim = new THREE.DirectionalLight(0x88bbff, 0.6); rim.position.set(-120, -40, -80); this.scene.add(rim);
    const grid = new THREE.GridHelper(400, 40, 0x243038, 0x182026); grid.position.y = -60; this.scene.add(grid);

    this.spindle = new THREE.Group(); this.scene.add(this.spindle);
    this.metal = new THREE.MeshStandardMaterial({ color: 0xc9d2da, metalness: 0.85, roughness: 0.32, side: THREE.DoubleSide });
    this.buildChuck();
    this.work = new THREE.Mesh(new THREE.BufferGeometry(), this.metal); this.spindle.add(this.work);
    this.plannedLine = new THREE.Group(); this.scene.add(this.plannedLine);
    this.trailLine = new THREE.Group(); this.scene.add(this.trailLine);
    this.turret = new THREE.Group(); this.scene.add(this.turret);
    this.buildTool();
    this.lastVersion = -1; this.lastPlanned = null; this.lastTrailLen = -1; this.lastTool = -1;
    this.angle = 0;
  }
  buildChuck() {
    const s = this.rt.stock;
    if (this.chuck) this.spindle.remove(this.chuck);
    const grp = new THREE.Group();
    const bodyMat = new THREE.MeshStandardMaterial({ color: 0x3a434b, metalness: 0.6, roughness: 0.5 });
    const R = s.dia / 2 + 40;
    const body = new THREE.Mesh(new THREE.CylinderGeometry(R, R, 40, 64), bodyMat);
    body.rotation.z = Math.PI / 2; body.position.x = s.z0 - s.length - 20; grp.add(body);
    const jawMat = new THREE.MeshStandardMaterial({ color: 0x59636c, metalness: 0.7, roughness: 0.4 });
    for (let i = 0; i < 3; i++) {
      const jaw = new THREE.Mesh(new THREE.BoxGeometry(s.chuck, 14, 18), jawMat);
      const a = (i * 2 * Math.PI) / 3;
      jaw.position.set(s.z0 - s.length + s.chuck / 2, Math.cos(a) * (s.dia / 2 + 7), Math.sin(a) * (s.dia / 2 + 7));
      jaw.rotation.x = -a; grp.add(jaw);
    }
    this.chuck = grp; this.spindle.add(grp);
  }
  buildTool() {
    this.turret.clear();
    const tdef = this.rt.db.tool(this.rt.state.tool);
    const type = TOOL_TYPES[tdef?.type] || TOOL_TYPES.OD_ROUGH;
    const holder = new THREE.Mesh(new THREE.BoxGeometry(20, 60, 20), new THREE.MeshStandardMaterial({ color: 0x3b454d, metalness: 0.5, roughness: 0.5 }));
    holder.position.set(12, 36, 0); this.turret.add(holder);
    const shape = new THREE.Shape();
    const L = 10, ang = (type.angle * Math.PI) / 180, tb = Math.PI / 4;
    if (type === TOOL_TYPES.GROOVE) { shape.moveTo(0, 0); shape.lineTo(3, 0); shape.lineTo(3, 14); shape.lineTo(0, 14); }
    else {
      const a = Math.max(ang, 0.4), far = 2 * L * Math.cos(a / 2);
      shape.moveTo(0, 0); shape.lineTo(Math.cos(tb + a / 2) * L, Math.sin(tb + a / 2) * L);
      shape.lineTo(Math.cos(tb) * far, Math.sin(tb) * far); shape.lineTo(Math.cos(tb - a / 2) * L, Math.sin(tb - a / 2) * L);
    }
    const insert = new THREE.Mesh(new THREE.ExtrudeGeometry(shape, { depth: 4.8, bevelEnabled: false }), new THREE.MeshStandardMaterial({ color: new THREE.Color(type.color), metalness: 0.4, roughness: 0.35 }));
    insert.position.z = -2.4; this.turret.add(insert);
    this.lastTool = this.rt.state.tool;
  }
  resize() {
    const r = this.host.getBoundingClientRect();
    if (!r.width || !r.height) return;
    this.renderer.setSize(r.width, r.height, false);
    this.renderer.domElement.style.width = '100%'; this.renderer.domElement.style.height = '100%';
    this.camera.aspect = r.width / r.height; this.camera.updateProjectionMatrix();
  }
  rebuildWork() {
    const s = this.rt.stock; const prof = s.profile(500);
    const pts = [new THREE.Vector2(0.0001, prof[0].z)];
    prof.forEach((p) => pts.push(new THREE.Vector2(Math.max(p.r, 0.0001), p.z)));
    pts.push(new THREE.Vector2(0.0001, prof[prof.length - 1].z));
    // LatheGeometry revolves around +Y; points (r, z) -> rotate so axis = world X
    const geo = new THREE.LatheGeometry(pts.reverse(), 96);
    geo.rotateZ(-Math.PI / 2); // (r, z, 0) -> (z, -r, 0)
    geo.computeVertexNormals();
    this.work.geometry.dispose(); this.work.geometry = geo;
    this.lastVersion = s.version;
  }
  lines(group, list, rapidCol, feedCol, opacity) {
    group.children.forEach((c) => c.geometry.dispose()); group.clear();
    const rapid = [], feed = [];
    for (const p of list) {
      const arr = p.rapid ? rapid : feed;
      for (let i = 1; i < p.pts.length; i++) arr.push(p.pts[i - 1].z, p.pts[i - 1].x / 2, 0, p.pts[i].z, p.pts[i].x / 2, 0);
    }
    const mk = (arr, col, dashed) => {
      if (!arr.length) return;
      const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.Float32BufferAttribute(arr, 3));
      const m = dashed ? new THREE.LineDashedMaterial({ color: col, dashSize: 2, gapSize: 1.5, transparent: true, opacity }) : new THREE.LineBasicMaterial({ color: col, transparent: true, opacity });
      const l = new THREE.LineSegments(g, m); if (dashed) l.computeLineDistances(); group.add(l);
    };
    mk(rapid, rapidCol, true); mk(feed, feedCol, false);
  }
  draw(dt) {
    const rt = this.rt, s = rt.stock;
    if (s.version !== this.lastVersion) this.rebuildWork();
    if (rt.planned !== this.lastPlanned) { this.lines(this.plannedLine, rt.planned, 0xff5a5a, 0x5ec8e5, 0.45); this.lastPlanned = rt.planned; }
    const tl = rt.trail.reduce((a, p) => a + p.pts.length, 0);
    if (tl !== this.lastTrailLen) { this.lines(this.trailLine, rt.trail, 0xff7878, 0x62f0a0, 0.95); this.lastTrailLen = tl; }
    if (rt.state.tool !== this.lastTool) this.buildTool();
    const tip = rt.tipPos();
    this.turret.position.set(tip.z, tip.x / 2, 0);
    const rpm = rt.liveRpm * (rt.state.spindle || 0);
    this.angle += (rpm / 60) * 2 * Math.PI * dt * rt.simSpeed * 0.02; // visually slowed
    this.spindle.rotation.x = this.angle;
    this.controls.update();
    this.renderer.render(this.scene, this.camera);
  }
  dispose() { this.renderer.dispose(); }
}
