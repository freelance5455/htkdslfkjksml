// ============================================================================
// Tool & Offset repository. Mirrors spec/schema.sql (turret_station, tool,
// tool_offset, work_offset, offset_history). The prototype persists to
// an in-memory key/value adapter; production swaps this adapter for SQLite (mobile) or
// IndexedDB + REST sync (web) behind the same interface.
// ============================================================================
const KEY = 'cncsim.tooldb.v1';
/** Minimal key/value adapter (same surface as Web Storage). Swap for SQLite / IndexedDB adapters. */
export class MemoryStorage {
  constructor() { this.m = new Map(); }
  getItem(k) { return this.m.has(k) ? this.m.get(k) : null; }
  setItem(k, v) { this.m.set(k, String(v)); }
  removeItem(k) { this.m.delete(k); }
}
export const kv = new MemoryStorage();
export const TOOL_TYPES = {
  OD_ROUGH: { label: 'OD rough', angle: 80, color: '#f5b83d' },
  OD_FINISH: { label: 'OD finish', angle: 35, color: '#5ec8e5' },
  FACE: { label: 'Facing', angle: 80, color: '#b48cf2' },
  GROOVE: { label: 'Grooving', angle: 0, color: '#7ee07e' },
  THREAD: { label: 'Threading', angle: 60, color: '#f07a7a' },
  BORE: { label: 'Boring bar', angle: 55, color: '#e59a5e' },
  DRILL: { label: 'Drill', angle: 118, color: '#cfcfcf' },
};
export const WEAR_LIMIT = 1.0; // max |wear| per input (Fanuc param 5013-style)

function seed() {
  const tools = [
    { station: 1, name: 'CNMG 120408 OD ROUGH', type: 'OD_ROUGH', diameter: 0, noseRadius: 0.8, tip: 3, holder: 'PCLNR 2525M12' },
    { station: 2, name: 'VNMG 160404 OD FINISH', type: 'OD_FINISH', diameter: 0, noseRadius: 0.4, tip: 3, holder: 'PVJNR 2525M16' },
    { station: 3, name: 'CNMG 120408 FACING', type: 'FACE', diameter: 0, noseRadius: 0.8, tip: 3, holder: 'PCLNL 2525M12' },
    { station: 4, name: 'GROOVE 3.0mm', type: 'GROOVE', width: 3, diameter: 0, noseRadius: 0.2, tip: 3, holder: 'MGEHR 2525-3' },
    { station: 5, name: 'THREAD 16ER 1.5ISO', type: 'THREAD', diameter: 0, noseRadius: 0.1, tip: 8, holder: 'SER 2525M16' },
    { station: 6, name: 'BORING BAR S16', type: 'BORE', diameter: 16, noseRadius: 0.4, tip: 2, holder: 'S16Q-SCLCR09' },
    { station: 7, name: 'DRILL 12.0 HSS', type: 'DRILL', diameter: 12, noseRadius: 0, tip: 0, holder: 'ER32 collet' },
    { station: 8, name: '(EMPTY)', type: 'OD_ROUGH', diameter: 0, noseRadius: 0, tip: 0, holder: '' },
  ];
  const offsets = [];
  for (let n = 1; n <= 16; n++) {
    const base = n <= 8 ? n : 0;
    offsets.push({ n, geomX: base ? -(200 + base * 1.25) : 0, geomZ: base ? -(150 + base * 0.8) : 0, wearX: 0, wearZ: 0, radius: tools[n - 1]?.noseRadius ?? 0, tip: tools[n - 1]?.tip ?? 0 });
  }
  const work = ['G54', 'G55', 'G56', 'G57', 'G58', 'G59'].map((code) => ({ code, x: 0, z: 0 }));
  return { tools, offsets, work, history: [], rparams: Array(100).fill(0) };
}

export class ToolDB {
  constructor(storage = kv) {
    this.storage = storage;
    try { this.data = JSON.parse(storage?.getItem(KEY)) || seed(); } catch { this.data = seed(); }
    this.listeners = new Set();
  }
  save() { try { this.storage?.setItem(KEY, JSON.stringify(this.data)); } catch {} this.listeners.forEach((f) => f()); }
  onChange(f) { this.listeners.add(f); return () => this.listeners.delete(f); }
  resetAll() { this.data = seed(); this.save(); }
  tool(station) { return this.data.tools.find((t) => t.station === station); }
  getOffset(n) { return this.data.offsets.find((o) => o.n === n) || null; }
  workShift(g) { const w = this.data.work.find((w) => w.code === `G${g}`); return w ? { x: w.x, z: w.z } : { x: 0, z: 0 }; }
  /** Fanuc INPUT (absolute) / +INPUT (incremental). Returns error string or null. */
  setOffset(n, field, value, incremental = false) {
    const o = this.getOffset(n);
    if (!o) return 'PS0030 ILLEGAL OFFSET NUMBER';
    if (!Number.isFinite(value)) return 'FORMAT ERROR';
    const next = incremental ? o[field] + value : value;
    if ((field === 'wearX' || field === 'wearZ') && Math.abs(incremental ? value : next - o[field]) > WEAR_LIMIT)
      return `WARNING: WEAR INPUT > ${WEAR_LIMIT.toFixed(3)} (INPUT REJECTED)`;
    if (field === 'tip' && (next < 0 || next > 9 || !Number.isInteger(next))) return 'TIP MUST BE 0-9';
    this.data.history.unshift({ at: new Date().toISOString(), n, field, from: o[field], to: +next.toFixed(4) });
    this.data.history = this.data.history.slice(0, 200);
    o[field] = +next.toFixed(4);
    this.save();
    return null;
  }
  setWork(code, field, value, incremental) {
    const w = this.data.work.find((x) => x.code === code); if (!w) return 'NO WORK OFFSET';
    w[field] = +((incremental ? w[field] : 0) + value).toFixed(4); this.save(); return null;
  }
  updateTool(station, patch) { Object.assign(this.tool(station), patch); this.save(); }
}
