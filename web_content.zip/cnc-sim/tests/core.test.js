import test from 'node:test';
import assert from 'node:assert/strict';
import { parseProgram, lexLine } from '../app/js/parser.js';
import { compile, arcPoints, toolpathOf } from '../app/js/interpreter.js';
import { PROGRAMS } from '../app/js/programs.js';

const OFF = { 1: { geomX: -200, geomZ: -150, wearX: 0, wearZ: 0 }, 2: { geomX: -195, geomZ: -148, wearX: 0, wearZ: 0 }, 3: { geomX: -198, geomZ: -152, wearX: 0, wearZ: 0 } };
const ctx = { getOffset: (n) => OFF[n] };

test('lexer: words, comments, block delete', () => {
  const r = lexLine('/N10 G01 X20.5 Z-3 F0.2 (FINISH) ;', 1);
  assert.equal(r.blockDelete, true);
  assert.equal(r.comment, 'FINISH');
  assert.deepEqual(r.tokens.map((t) => t.raw), ['N10', 'G01', 'X20.5', 'Z-3', 'F0.2']);
});
test('lexer: standard decimal mode X10 = 0.010', () => {
  const r = lexLine('X10 Z10.', 1, { decimalMode: 'standard' });
  assert.equal(r.tokens[0].value, 0.01); assert.equal(r.tokens[1].value, 10);
});
test('parser: modal group conflict + unknown G + duplicate address', () => {
  const p = parseProgram('G00 G01 X10\nG65 X1\nX1 X2');
  const codes = p.errors.map((e) => e.code);
  assert.ok(codes.includes('PS0035')); assert.ok(codes.includes('PS0010')); assert.ok(codes.includes('PS0034'));
});
test('parser: G70 missing sequence -> PS0063', () => {
  const p = parseProgram('G70 P100 Q200');
  assert.ok(p.errors.some((e) => e.code === 'PS0063'));
});
test('all sample programs parse clean', () => {
  for (const [k, src] of Object.entries(PROGRAMS)) {
    const p = parseProgram(src);
    assert.deepEqual(p.errors, [], k);
  }
});
test('arc G02 R: concave fillet centre on air side, ends exactly', () => {
  const pts = arcPoints({ x: 20, z: -20 }, { x: 30, z: -25 }, true, { R: 5 }, () => assert.fail());
  const mid = pts[Math.floor(pts.length / 2)];
  // centre (z=-20, r=15): midpoint of CW arc lies at 45deg lower-left of centre
  assert.ok(Math.abs(Math.hypot(mid.z + 20, mid.x / 2 - 15) - 5) < 1e-6);
  assert.ok(mid.z < -20 && mid.x / 2 < 15);
  assert.deepEqual(pts.at(-1), { x: 30, z: -25 });
});
test('arc radius tolerance alarm PS0020', () => {
  let code = null; arcPoints({ x: 0, z: 0 }, { x: 20, z: -10 }, false, { I: 0, K: -12 }, (c) => (code = c));
  assert.equal(code, 'PS0020');
});
test('G71 expands into roughing passes and resumes after Q', () => {
  const p = parseProgram(PROGRAMS.O1001);
  const r = compile(p, { x: 200, z: 150 }, ctx);
  assert.deepEqual(r.alarms, []);
  const L = (n) => p.blocks[p.index.get(n)].line;
  const g71Moves = r.steps.filter((s) => s.k === 'move' && s.line === L(7));
  const cuts = g71Moves.filter((s) => !s.rapid && s.pts.length === 2 && Math.abs(s.pts[0].x - s.pts[1].x) < 1e-9);
  // (54 - 16.4)/2 = 18.8 mm radial / 1.5 = 12 full levels
  assert.equal(cuts.length, 12);
  // no roughing cut may go below finish allowance: every cut end must be outside the offset profile
  assert.ok(cuts.every((c) => c.pts[1].z >= -48.1 - 1e-6));
  // shape blocks N8..N19 must not run again as standalone moves (resume at N20)
  assert.ok(!r.steps.some((s) => s.line >= L(8) && s.line <= L(19)));
  assert.equal(r.steps.at(-1).k, 'end');
});
test('G72 facing expands level cuts in Z', () => {
  const p = parseProgram(PROGRAMS.O1002);
  const r = compile(p, { x: 200, z: 150 }, ctx);
  assert.deepEqual(r.alarms, []);
  const cuts = r.steps.filter((s) => s.k === 'move' && s.line === p.blocks[p.index.get(7)].line && !s.rapid && s.pts.length === 2 && Math.abs(s.pts[0].z - s.pts[1].z) < 1e-9);
  assert.ok(cuts.length >= 13, `levels=${cuts.length}`);
});
test('T-code re-expresses position via offsets', () => {
  const p = parseProgram('T0101\nT0202');
  const r = compile(p, { x: 0, z: 0, offset: 0 }, ctx);
  assert.equal(r.state.x, 195); assert.equal(r.state.z, 148);
});
test('toolpath extraction', () => {
  const r = compile(parseProgram(PROGRAMS.O1003), {}, ctx);
  assert.deepEqual(r.alarms, []);
  assert.ok(toolpathOf(r.steps).length > 10);
});
