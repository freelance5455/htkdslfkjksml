import test from 'node:test';
import assert from 'node:assert/strict';
import { translateSiemens, parseAny, detectDialect, siemensAlarm } from '../app/js/dialect.js';
import { ToolDB } from '../app/js/tooldb.js';
import { Stock } from '../app/js/material.js';
import { Runtime } from '../app/js/runtime.js';
import { SIEMENS_PROGRAMS, PROGRAMS } from '../app/js/programs.js';

test('dialect detection by file type', () => {
  assert.equal(detectDialect('TURN_SHAFT.MPF'), 'siemens'); assert.equal(detectDialect('O1001'), 'fanuc');
});
test('Siemens words: G71=metric, G95=feed/rev, CR=, LIMS=, T1 D1, G91, G4 F, comments', () => {
  const t = translateSiemens('N10 G71 G95 G90 DIAMON ; SETUP\nT2 D1\nG96 S180 LIMS=2500 M3\nG2 X30 Z-23 CR=5\nG91 G1 X2 Z-1\nG4 F1.5');
  const l = t.text.split('\n');
  assert.equal(l[0], 'N10 G21 G99 (SETUP)');
  assert.equal(l[1], 'T0202');
  assert.equal(l[2], 'G96 S180 L2500 M3');
  assert.equal(l[3], 'G2 X30 Z-23 R5');
  assert.equal(l[4], 'G1 U2 W-1');
  assert.equal(l[5], 'G4 X1.5');
  assert.deepEqual(t.errors, []);
});
test('CYCLE95 → G71 rough / G70 finish with line map', () => {
  const t = translateSiemens(SIEMENS_PROGRAMS['TURN_SHAFT.MPF']);
  assert.ok(t.text.includes('G71 U1.5 R0.5'));
  assert.ok(t.text.includes('G71 P90000 Q90001 U0.4 W0.1 F0.25 E1'));
  assert.ok(t.text.includes('G70 P90000 Q90001 F0.12 E1'));
  const i = t.text.split('\n').findIndex((x) => x.startsWith('G71 P'));
  assert.equal(t.lineMap[i], 10); // still points at the CYCLE95 source line
});
test('unsupported constructs raise 12080, missing labels 14080', () => {
  const p = parseAny('GOTOF END\nCYCLE95("A:B",1,0,0,,0.2,0,0,1,,,0.5)', 'siemens');
  const c = p.errors.map((e) => e.code);
  assert.ok(c.includes('12080')); assert.ok(c.includes('14080'));
});
test('alarm number mapping', () => {
  assert.equal(siemensAlarm('SIM003', 'OVERTRAVEL +Z').num, '10720');
  assert.equal(siemensAlarm('EMG').num, '3000');
});
function run(src, dialect) {
  const rt = new Runtime({ db: new ToolDB(null), stock: new Stock({ dia: 50, length: 80, face: 1, chuck: 25 }) });
  rt.load(src, dialect); rt.setMode('MEM'); rt.cycleStart();
  let t = 0; while (rt.running && !rt.alarms.length && t < 3600) { rt.tick(0.02); t += 0.02; }
  return rt;
}
for (const [k, src] of Object.entries(SIEMENS_PROGRAMS)) {
  test(`${k} runs clean on the 808D dialect`, () => {
    const rt = run(src, 'siemens');
    assert.deepEqual(rt.parsed.errors, []);
    assert.deepEqual(rt.alarms.map((a) => a.code + ' ' + a.message), []);
    assert.equal(rt.parts, 1);
  });
}
test('TURN_SHAFT.MPF produces the same part as Fanuc O1001', () => {
  const a = run(SIEMENS_PROGRAMS['TURN_SHAFT.MPF'], 'siemens'), b = run(PROGRAMS.O1001, 'fanuc');
  for (const z of [-10, -20, -24, -33, -41, -45]) {
    const da = a.stock.r[a.stock.idx(z)] * 2, db = b.stock.r[b.stock.idx(z)] * 2;
    assert.ok(Math.abs(da - db) < 0.02, `z${z}: ${da} vs ${db}`);
  }
  assert.ok(Math.abs(a.stock.r[a.stock.idx(-10)] * 2 - 20) < 0.02);
});
test('Siemens MDA uses Siemens syntax', () => {
  const rt = new Runtime({ db: new ToolDB(null), stock: new Stock() });
  rt.mdiDialect = 'siemens'; rt.setMode('MDI'); rt.cycleStart('G0 X100 Z60 ; MDA');
  for (let i = 0; i < 300; i++) rt.tick(0.02);
  assert.equal(rt.state.x, 100); assert.equal(rt.state.z, 60);
});

test('R parameters: assignments, expressions, functions', async () => {
  const { evalExpr } = await import('../app/js/dialect.js');
  const R = Array(100).fill(0); R[1] = 5;
  assert.equal(evalExpr('2*(R1+3)/SQRT(4)-SIN(30)', R), 7.5);
  const t = translateSiemens('R1=20 R2=R1/2\nG1 X=R1+2 Z=-R2 F0.2\nG2 X=R1 Z-12 CR=R2/5\nR3=1/0');
  assert.deepEqual(t.text.split('\n').slice(1, 3), ['G1 X22 Z-10 F0.2', 'G2 X20 Z-12 R2']);
  assert.equal(t.errors[0].code, '14051');
});
test('CYCLE93 needs a grooving tool (61602) and a rectangular form (61603)', () => {
  const a = translateSiemens('T1 D1\nCYCLE93(40,-30,6,2,0,0,0,0,0,0,0,0,0,1,0,1,1)', { toolWidth: () => 0 });
  assert.equal(a.errors[0].code, '61602');
  const b = translateSiemens('T4 D1\nCYCLE93(40,-30,6,2,0,30,0,0,0,0,0,0,0,1,0,1,1)', { toolWidth: () => 3 });
  assert.equal(b.errors[0].code, '61603');
});
test('GROOVE_R.MPF: Ø44 shaft with a 6 wide × 3 deep groove at Z-20, R10 counts parts', () => {
  const rt = run(SIEMENS_PROGRAMS['GROOVE_R.MPF'], 'siemens');
  assert.deepEqual(rt.alarms.map((a) => a.code + ' ' + a.message), []);
  const d = (z) => rt.stock.r[rt.stock.idx(z)] * 2;
  assert.ok(Math.abs(d(-10) - 44) < 0.02, `Ø at Z-10 = ${d(-10)}`);
  assert.ok(Math.abs(d(-23) - 38) < 0.05, `groove Ø = ${d(-23)}`);
  assert.ok(Math.abs(d(-20.5) - 38) < 0.05 && Math.abs(d(-25.5) - 38) < 0.05, `flanks ${d(-20.5)} ${d(-25.5)}`);
  assert.ok(Math.abs(d(-30) - 44) < 0.02);
  assert.equal(rt.parsed.rFinal[10], 1);
});
test('JOG facing cycle runs from JOG mode without leaving it', () => {
  const rt = new Runtime({ db: new ToolDB(null), stock: new Stock({ dia: 50, length: 80, face: 1, chuck: 25 }) });
  rt.setMode('JOG');
  rt.runJogCycle('G96 S150 LIMS=2500 M3\nG95\nG0 X54\nG0 Z2\nG0 Z0.5\nG1 X-1.6 F0.15\nG0 Z1.5\nG0 X54\nG0 Z0\nG1 X-1.6\nG0 Z1\nG0 X54');
  let t = 0; while (rt.running && t < 600) { rt.tick(0.02); t += 0.02; }
  assert.deepEqual(rt.alarms, []); assert.equal(rt.mode, 'JOG');
  assert.ok(rt.stock.r[rt.stock.idx(0.6)] < 0.01, 'face stock removed');
});
