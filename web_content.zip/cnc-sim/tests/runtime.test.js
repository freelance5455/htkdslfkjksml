import test from 'node:test';
import assert from 'node:assert/strict';
import { ToolDB } from '../app/js/tooldb.js';
import { Stock } from '../app/js/material.js';
import { Runtime } from '../app/js/runtime.js';
import { PROGRAMS } from '../app/js/programs.js';

function runProgram(src) {
  const rt = new Runtime({ db: new ToolDB(null), stock: new Stock({ dia: 50, length: 80, face: 1, chuck: 25 }) });
  rt.load(src); rt.setMode('MEM'); rt.simSpeed = 1; rt.cycleStart();
  let t = 0;
  while (rt.running && !rt.alarms.length && t < 3600) { rt.tick(0.02); t += 0.02; }
  return rt;
}
for (const key of Object.keys(PROGRAMS)) {
  test(`${key} runs to M30 with no alarms`, () => {
    const rt = runProgram(PROGRAMS[key]);
    assert.deepEqual(rt.alarms.map((a) => a.code + ' ' + a.message), []);
    assert.equal(rt.parts, 1);
    assert.ok(rt.stock.removedVolume() > 1);
  });
}
test('O1001 finished diameters match drawing', () => {
  const rt = runProgram(PROGRAMS.O1001);
  const r = (z) => rt.stock.r[rt.stock.idx(z)] * 2;
  assert.ok(Math.abs(r(-10) - 20) < 0.02, `Ø20 got ${r(-10)}`);
  assert.ok(Math.abs(r(-33) - 40) < 0.02, `Ø40 got ${r(-33)}`);
  assert.ok(Math.abs(r(-45) - 50) < 0.02, `Ø50 got ${r(-45)}`);
});
test('wear offset shifts finished diameter', () => {
  const db = new ToolDB(null); db.setOffset(2, 'wearX', -0.05);
  const rt = new Runtime({ db, stock: new Stock({ dia: 50, length: 80 }) });
  rt.load(PROGRAMS.O1001); rt.setMode('MEM'); rt.cycleStart();
  let t = 0; while (rt.running && !rt.alarms.length && t < 3600) { rt.tick(0.02); t += 0.02; }
  const d = rt.stock.r[rt.stock.idx(-10)] * 2;
  assert.ok(Math.abs(d - 19.95) < 0.02, `expected Ø19.95 got ${d}`);
});
test('feed hold and single block stop motion', () => {
  const rt = new Runtime({ db: new ToolDB(null), stock: new Stock() });
  rt.load(PROGRAMS.O1003); rt.setMode('MEM'); rt.singleBlock = true; rt.cycleStart();
  for (let i = 0; i < 200; i++) rt.tick(0.02);
  assert.equal(rt.stopped, true);
  const line = rt.currentLine; rt.cycleStart(); for (let i = 0; i < 400; i++) rt.tick(0.02);
  assert.ok(rt.currentLine > line);
});
