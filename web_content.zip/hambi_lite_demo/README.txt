Hambi Lite — abonentlar uchun yangilangan demo

Bu prototip Hambi/Beeline abonentlari uchun yengil mobil ilova g‘oyasini namoyish qiladi:
- Asosiy ekranda demo telefon raqami va balans
- Hisobni to‘ldirish
- Mobil tariflar, internet paketlari, daqiqa/SMS paketlari (demo tanlovlar)
- Uy interneti/Wi-Fi uchun provayder, hudud, tuman, shartnoma raqami va ixtiyoriy Wi-Fi nomi
- Elektr, gaz va suv to‘lovlarida hudud, tuman/shahar va shaxsiy hisob raqami
- Mobil raqam to‘ldirishda operator va telefon raqami

Ochish: ZIPni oching va hambi_lite_demo/index.html faylini Chrome’da oching.

Muhim: bu mustaqil demo. Balans, tariflar va paketlar namuna; provayderlar, Beeline/Hambi abonent bazasi, haqiqiy hisob tekshiruvi va to‘lov tizimlariga ulanmagan. Haqiqiy mijoz ma’lumotlarini kiritmang.
