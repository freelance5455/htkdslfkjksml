ANONYMOUX Studio — APK WebView wrapper

File: index.html

Purpose:
- Entry page for an Android WebView / website-to-APK builder.
- Redirects the app to the hosted ANONYMOUX Studio website.
- Uses HTTPS and a mobile viewport.

Before building:
1. Open apk-wrapper/index.html.
2. Confirm APP_URL points to your final deployed HTTPS domain.
3. In your APK builder, use this HTML as the start page if it supports an uploaded HTML entry point,
   or enter the same APP_URL as the website URL when the builder asks for a URL.
4. Enable JavaScript, DOM storage/cookies, file upload support, and camera/microphone permissions
   only if the corresponding ANONYMOUX Studio features need them.
5. Build and test the APK on a real Android device.

Important:
This wrapper does NOT convert PHP into standalone Android code and does not bundle/run PHP.
ANONYMOUX Studio's PHP backend, database, APIs, and generation providers must remain deployed
on a PHP-capable HTTPS host. The APK is an Android WebView client and requires internet access.
Do not upload private configuration files, API keys, or database credentials into an APK.
