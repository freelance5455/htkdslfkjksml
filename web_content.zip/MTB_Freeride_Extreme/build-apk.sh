#!/usr/bin/env bash
set -euo pipefail
: "${ANDROID_HOME:=${ANDROID_SDK_ROOT:-}}"
if [[ -z "$ANDROID_HOME" ]]; then echo "Set ANDROID_HOME to your Android SDK root."; exit 1; fi
if [[ ! -x "$ANDROID_HOME/platform-tools/adb" ]]; then echo "Android SDK platform-tools not found."; fi
if command -v gradle >/dev/null 2>&1; then gradle :app:assembleDebug; else echo "Gradle is required. Open this project in Android Studio or install Gradle."; exit 2; fi
