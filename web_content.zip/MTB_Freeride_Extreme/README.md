# MTB FREERIDE: EXTREME

Landscape Android 2D/2.5D MTB freeride simulator built as a dependency-free HTML5 gameplay layer inside a native Android WebView.

## Included gameplay
- Real-time two-wheel bicycle model: gravity, inertia, traction, braking, wheel rotation, air rotation, pitch control, landing impact, drag and speed limits.
- Surface model: dirt, wet, snow, sand, concrete and rock with tire-dependent grip/rolling behavior.
- Suspension tuning data: fork travel/preload/compression/rebound/LSC/HSC/spring and rear shock spring/sag/compression/rebound/pressure/volume.
- 30 bikes across DH, Enduro, Freeride, Trail, Dirt Jump, Slopestyle, Trial, Hardtail and Full Suspension archetypes.
- 24 tire setups, 18 forks and 18 rear shocks, plus data-driven component categories.
- 15 spots with unlock progression, open-route terrain generation and biome variations.
- Trick scoring: manuals, tabletop, whip, X-up, barspin, tailwhip, no-hand, superman, 360/540/720-style rotation, flips and clean landings.
- Combo multiplier up to x20, speed/airtime/style scoring and crash reset.
- Rider cosmetic loadout and 30 bikes with persistent unlocks.
- Career, challenges, garage, rider, spots, settings and local save.
- Touch controls + keyboard fallback; landscape orientation.
- Weather modes and weather-linked grip changes.

## Build
Open the project folder in current Android Studio with an Android SDK installed, then run the `assembleDebug` task. The APK will be under `app/build/outputs/apk/debug/`.

The provided runtime in this workspace does not contain the Android SDK/DEX build chain, so a final APK binary cannot be produced here. The project is structured to build as a normal Android application once the SDK/Gradle tooling is available.
