#!/usr/bin/env python3
"""Serve o My Fan A List para acesso no telefone pela rede local."""
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
import os
import socket

ROOT = Path(__file__).resolve().parent
PORT = 4173

class AppHandler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(ROOT), **kwargs)

    def end_headers(self):
        self.send_header("Cache-Control", "no-cache")
        super().end_headers()


def local_lan_ips():
    ips = set()
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            ip = info[4][0]
            if not ip.startswith("127."):
                ips.add(ip)
    except OSError:
        pass
    try:
        probe = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        probe.connect(("8.8.8.8", 80))
        ip = probe.getsockname()[0]
        probe.close()
        if not ip.startswith("127."):
            ips.add(ip)
    except OSError:
        pass
    return sorted(ips)


if __name__ == "__main__":
    os.chdir(ROOT)
    # O servidor escuta na rede local para permitir o acesso do telefone
    # abrir o app pelo IP do PC, desde que ambos estejam na mesma rede Wi-Fi.
    server = ThreadingHTTPServer(("0.0.0.0", PORT), AppHandler)
    print(f"My Fan A List no servidor local: http://localhost:{PORT}/")
    for ip in local_lan_ips():
        print(f"My Fan A List no telefone: http://{ip}:{PORT}/")
    print("O telefone e o servidor devem estar na mesma rede local.")
    print("Mantenha esta janela aberta enquanto utilizar a aplicação.")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nServidor encerrado.")
    finally:
        server.server_close()
