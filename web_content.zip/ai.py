import requests
from config import GEMINI_API_KEY, GEMINI_MODEL, LANGUAGE_HINT

SYSTEM_PROMPT = (
    "You are AppsFuture AI, a friendly JARVIS-style Android assistant. "
    "Be concise, useful, and beginner-friendly. " + LANGUAGE_HINT +
    " For coding questions, provide correct code and explain how to run it. "
    "You cannot directly operate the phone; use the app's approved action buttons for that."
)

def ask_gemini(message, history=None):
    if not GEMINI_API_KEY or GEMINI_API_KEY == "PASTE_YOUR_KEY_HERE":
        return "Gemini API key missing. Add your key in the .env file and restart AppsFuture AI."
    url = f"https://generativelanguage.googleapis.com/v1beta/models/{GEMINI_MODEL}:generateContent"
    contents = []
    for item in (history or [])[-8:]:
        role = "model" if item.get("role") == "assistant" else "user"
        contents.append({"role": role, "parts": [{"text": item.get("text", "")}]})
    contents.append({"role": "user", "parts": [{"text": message}]})
    payload = {
        "systemInstruction": {"parts": [{"text": SYSTEM_PROMPT}]},
        "contents": contents,
        "generationConfig": {"temperature": 0.65, "maxOutputTokens": 1200}
    }
    try:
        response = requests.post(
            url, params={"key": GEMINI_API_KEY}, json=payload, timeout=45
        )
        if response.status_code >= 400:
            try:
                detail = response.json().get("error", {}).get("message", response.text)
            except Exception:
                detail = response.text
            return f"Gemini API error ({response.status_code}): {detail}"
        data = response.json()
        return data["candidates"][0]["content"]["parts"][0]["text"].strip()
    except requests.RequestException as exc:
        return f"Network error connecting to Gemini: {exc}"
    except (KeyError, IndexError, TypeError):
        return "Gemini returned an unexpected response. Check your model name and API quota."
