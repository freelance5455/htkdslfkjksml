Smart Calculator HTML project

Entry point: index.html

Note: this is a corrected HTML project, not an APK. Use your HTML-to-APK converter to package index.html into an Android APK. The source HTML did not contain Markdown fences, so if literal ```html / ``` still appears after conversion, check the converter's HTML input field/template and ensure you paste/upload the raw HTML file rather than a Markdown-formatted code block.

This HTML references Tailwind CSS and Font Awesome from CDNs, so internet may be needed for all styling/icons unless the converter supports downloading/caching those assets.
