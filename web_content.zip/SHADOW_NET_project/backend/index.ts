import { router, json, error, db, storage, requireAuth, invites, isInviteError } from '@appdeploy/sdk';
import { notifySubscribers, realtimeSubscriptionRoutes } from './realtime-subscribers';

const ROOM = 'shadow-main';
const MAX_MEMBERS = 50;
type Member = { roomId: string; userId: string; displayName: string; joinedAt: number };
type Message = { roomId: string; userId: string; name: string; text: string; createdAt: number; attachmentUrl?: string; attachmentName?: string };
type Note = { roomId: string; userId: string; title: string; body: string; updatedAt: number };

async function members() {
  const result = await db.list<Member>('shadow_members', { limit: 100 });
  return result.items.filter(x => x.roomId === ROOM);
}
async function isMember(userId: string) { return (await members()).some(x => x.userId === userId); }
async function ensureMember(userId: string, displayName: string) {
  if (await isMember(userId)) return members();
  const current = await members();
  if (current.length >= MAX_MEMBERS) throw new Error('This private space is full (50 members maximum).');
  const [id] = await db.add('shadow_members', [{ roomId: ROOM, userId, displayName: displayName.slice(0, 32), joinedAt: Date.now() }]);
  if (!id) throw new Error('Could not add member. Please try again.');
  return members();
}

export const handler = router({
  'POST /api/initialize': [requireAuth(), async ({ body, user }) => {
    const existing = await members();
    if (existing.some(member => member.userId === user!.userId)) return json({ ok: true, members: existing.length, joined: true });
    if (existing.length > 0) return error('This private space already exists. Join with an invitation link.', 403);
    const input = (body || {}) as { displayName?: string };
    const created = await ensureMember(user!.userId, input.displayName || user!.name || 'Member');
    return json({ ok: true, members: created.length, joined: true });
  }],
  'GET /api/room': [requireAuth(), async ({ user }) => {
    const list = await members();
    return json({ members: list.length, joined: list.some(m => m.userId === user!.userId) });
  }],
  'POST /api/join': [requireAuth(), async ({ body, user }) => {
    const input = (body || {}) as { code?: string; displayName?: string };
    if (!input.code) return error('An invitation code is required.', 400);
    try {
      const joined = await invites.join({ code: input.code, actor: user! });
      if (joined.resourceType !== 'shadow_room') return error('That invitation is for a different space.', 400);
      const list = await ensureMember(user!.userId, input.displayName || user!.name || 'Member');
      return json({ ok: true, members: list.length });
    } catch (err) {
      if (isInviteError(err)) return error(err.code, 400);
      return error(err instanceof Error ? err.message : 'Could not join.', 400);
    }
  }],
  'POST /api/invites': [requireAuth(), async ({ user }) => {
    const list = await members();
    if (!list.some(m => m.userId === user!.userId)) return error('Join the space before inviting someone.', 403);
    if (list.length >= MAX_MEMBERS) return error('All 50 member spots are filled.', 400);
    try {
      const created = await invites.create({ resourceType: 'shadow_room', authMode: 'required', actor: user!, expiresInSec: 60 * 60 * 24 * 7 });
      return json({ code: created.code });
    } catch (err) {
      if (isInviteError(err)) return error(err.code, 400);
      throw err;
    }
  }],
  'GET /api/messages': [requireAuth(), async ({ user }) => {
    if (!(await isMember(user!.userId))) return error('Join this private space first.', 403);
    const history: Message[] = [];
    let nextToken: string | undefined;
    let pagesRead = 0;
    do {
      const page = await db.list<Message>('shadow_messages', { limit: 100, ...(nextToken ? { nextToken } : {}) });
      history.push(...page.items.filter(message => message.roomId === ROOM));
      nextToken = page.nextToken;
      pagesRead += 1;
    } while (nextToken && pagesRead < 10);
    return json({ items: history.sort((a, b) => a.createdAt - b.createdAt), hasMoreHistory: Boolean(nextToken) });
  }],
  'POST /api/messages': [requireAuth(), async ({ body, user }) => {
    if (!(await isMember(user!.userId))) return error('Join this private space first.', 403);
    const input = (body || {}) as { text?: string; name?: string; attachmentUrl?: string; attachmentName?: string };
    if (!input.text?.trim() && !input.attachmentUrl) return error('Write a message or attach a file.', 400);
    const [id] = await db.add('shadow_messages', [{
      roomId: ROOM, userId: user!.userId, name: (input.name || user!.name || 'Member').slice(0, 32),
      text: (input.text || '').slice(0, 4000), createdAt: Date.now(),
      attachmentUrl: input.attachmentUrl, attachmentName: input.attachmentName,
    }]);
    if (!id) return error('Message could not be saved.', 500);
    const message = {
      id, roomId: ROOM, userId: user!.userId, name: (input.name || user!.name || 'Member').slice(0, 32),
      text: (input.text || '').slice(0, 4000), createdAt: Date.now(),
      attachmentUrl: input.attachmentUrl, attachmentName: input.attachmentName,
    };
    await notifySubscribers('shadow-room', ROOM, { kind: 'message', message });
    return json({ message });
  }],
  'POST /api/upload': [requireAuth(), async ({ body, user }) => {
    if (!(await isMember(user!.userId))) return error('Join this private space first.', 403);
    const input = (body || {}) as { name?: string; contentType?: string; content?: string };
    if (!input.content || input.content.length > 7_000_000) return error('File is empty or too large (maximum about 5 MB).', 400);
    const safeName = (input.name || 'attachment').replace(/[^a-zA-Z0-9._-]/g, '_').slice(0, 80);
    const path = 'shadow-files/' + user!.userId + '/' + Date.now() + '-' + safeName;
    const [ok] = await storage.write([{ path, content: input.content, contentType: input.contentType || 'application/octet-stream' }]);
    if (!ok) return error('Upload failed.', 500);
    const [signed] = await storage.url([path]);
    return json({ url: signed.url, name: safeName });
  }],
  'GET /api/notes': [requireAuth(), async ({ user }) => {
    if (!(await isMember(user!.userId))) return error('Join this private space first.', 403);
    const result = await db.list<Note>('shadow_notes', { limit: 100 });
    return json({ items: result.items.filter(n => n.roomId === ROOM).sort((a, b) => b.updatedAt - a.updatedAt) });
  }],
  'POST /api/notes': [requireAuth(), async ({ body, user }) => {
    if (!(await isMember(user!.userId))) return error('Join this private space first.', 403);
    const input = (body || {}) as { title?: string; body?: string };
    if (!input.title?.trim() || !input.body?.trim()) return error('A title and note body are required.', 400);
    const [id] = await db.add('shadow_notes', [{
      roomId: ROOM, userId: user!.userId, title: input.title.slice(0, 100),
      body: input.body.slice(0, 10000), updatedAt: Date.now(),
    }]);
    if (!id) return error('Note could not be saved.', 500);
    const note = { id, roomId: ROOM, userId: user!.userId, title: input.title.slice(0, 100), body: input.body.slice(0, 10000), updatedAt: Date.now() };
    await notifySubscribers('shadow-room', ROOM, { kind: 'note', note });
    return json({ note });
  }],
  'PUT /api/profile': [requireAuth(), async ({ body, user }) => {
    const input = (body || {}) as { displayName?: string };
    const list = await members();
    const member = list.find(m => m.userId === user!.userId);
    if (!member) return error('Join the space first.', 403);
    await db.update('shadow_members', [{
      id: member.id,
      record: { roomId: ROOM, userId: user!.userId, displayName: (input.displayName || 'Member').slice(0, 32), joinedAt: member.joinedAt },
    }]);
    return json({ ok: true });
  }],
  ...realtimeSubscriptionRoutes,
});
