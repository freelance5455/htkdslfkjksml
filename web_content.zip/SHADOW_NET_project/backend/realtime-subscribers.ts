import { db, ws, json, error } from '@appdeploy/sdk';

type Subscription = { id: string; entity_type: string; entity_id: string; connection_id: string; created_at: number };
async function allSubscriptions() {
  const { items } = await db.list<Subscription>('entity_subscriptions', { limit: 1000 });
  return items;
}
export async function removeSubscriptionsByConnection(connectionId: string) {
  const items = await allSubscriptions();
  const ids = items.filter(x => x.connection_id === connectionId).map(x => x.id);
  if (ids.length) await db.delete('entity_subscriptions', ids);
}
export async function notifySubscribers(entityType: string, entityId: string, payload: unknown, excludeConnectionId?: string) {
  const items = await allSubscriptions();
  const targets = Array.from(new Set(items.filter(x => x.entity_type === entityType && x.entity_id === entityId && x.connection_id !== excludeConnectionId).map(x => x.connection_id)));
  if (targets.length) await ws.send(targets, {
    v: 1, type: 'entity.update',
    payload: { entity_type: entityType, entity_id: entityId, data: payload },
  });
}
export const realtimeSubscriptionRoutes = {
  'POST /api/subscriptions': [async ({ body }) => {
    const input = (body || {}) as { entity_type?: string; entity_id?: string; connection_id?: string };
    if (!input.entity_type || !input.entity_id || !input.connection_id) return error('Missing subscription fields.', 400);
    await db.add('entity_subscriptions', [{ entity_type: input.entity_type, entity_id: input.entity_id, connection_id: input.connection_id, created_at: Date.now() }]);
    return json({ ok: true });
  }],
  'POST /api/subscriptions/remove': [async ({ body }) => {
    const input = (body || {}) as { entity_type?: string; entity_id?: string; connection_id?: string };
    if (!input.entity_type || !input.entity_id || !input.connection_id) return error('Missing subscription fields.', 400);
    const { items } = await db.list<Subscription>('entity_subscriptions', { limit: 1000 });
    const ids = items.filter(x => x.entity_type === input.entity_type && x.entity_id === input.entity_id && x.connection_id === input.connection_id).map(x => x.id);
    if (ids.length) await db.delete('entity_subscriptions', ids);
    return json({ ok: true });
  }],
};
