import { useEffect, useMemo, useRef, useState } from 'react';
import { auth, api, ws, invitesClient } from '@appdeploy/client';
import {
  MessageCircle, BookOpen, Settings, Paperclip, Send, Users, Image as ImageIcon,
  LogOut, Copy, Plus, Sparkles,
} from 'lucide-react';

type User = { userId: string; name?: string; email?: string };
type Message = {
  id: string; roomId: string; userId: string; name: string; text: string;
  createdAt: number; attachmentUrl?: string; attachmentName?: string;
};
type Note = { id: string; roomId: string; userId: string; title: string; body: string; updatedAt: number };
const ROOM = 'shadow-main';

function App() {
  const [user, setUser] = useState<User | null>(null);
  const [booting, setBooting] = useState(true);
  const [section, setSection] = useState<'chat' | 'study' | 'settings'>('chat');
  const [messages, setMessages] = useState<Message[]>([]);
  const [notes, setNotes] = useState<Note[]>([]);
  const [text, setText] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [accent, setAccent] = useState('#55a7ff');
  const [font, setFont] = useState('Space Grotesk');
  const [members, setMembers] = useState(0);
  const [joined, setJoined] = useState(false);
  const [inviteCode, setInviteCode] = useState('');
  const [joinCode, setJoinCode] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newBody, setNewBody] = useState('');
  const [filter, setFilter] = useState('');
  const connRef = useRef<ReturnType<typeof ws.connect> | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const themeStyle = useMemo(() => ({ '--accent': accent, fontFamily: `${font}, sans-serif` }) as React.CSSProperties, [accent, font]);

  useEffect(() => {
    let active = true;
    auth.getUser().then(async u => {
      if (!active) return;
      setUser(u);
      if (u) {
        setDisplayName(u.name || u.email?.split('@')[0] || 'Member');
        await loadRoom();
      }
      setBooting(false);
    }).catch(() => {
      if (active) {
        setError('Could not restore your sign-in. Please reload and try again.');
        setBooting(false);
      }
    });
    return () => { active = false; };
  }, []);

  async function loadRoom() {
    try {
      const info = await api.get('/api/room');
      setMembers(info.data.members || 0);
      setJoined(Boolean(info.data.joined));
      if (!info.data.joined) { setMessages([]); setNotes([]); return; }
      const [m, n] = await Promise.all([api.get('/api/messages'), api.get('/api/notes')]);
      setMessages(m.data.items || []);
      setNotes(n.data.items || []);
      const c = ws.connect();
      connRef.current = c;
      c.onMessage(event => {
        if (event?.type === 'entity.update' && event.payload?.entity_type === 'shadow-room') {
          const data = event.payload.data;
          if (data?.kind === 'message' && data.message)
            setMessages(old => old.some(x => x.id === data.message.id) ? old : [...old, data.message]);
          if (data?.kind === 'note' && data.note)
            setNotes(old => [data.note, ...old.filter(x => x.id !== data.note.id)]);
        }
      });
      await c.ready;
      if (c.connectionId) await api.post('/api/subscriptions', {
        entity_type: 'shadow-room', entity_id: ROOM, connection_id: c.connectionId,
      });
    } catch (e) { setError(messageOf(e)); }
  }

  useEffect(() => () => { connRef.current?.disconnect(); }, []);

  async function signIn() {
    setError('');
    try { await auth.signInWithRedirect(); } catch (e) { setError(messageOf(e)); }
  }

  async function initializeRoom() {
    setBusy(true); setError('');
    try {
      const result = await api.post('/api/initialize', { displayName: displayName.trim() || user?.name || 'Member' });
      setMembers(result.data.members || 1); setJoined(true); await loadRoom();
    } catch (e) { setError(messageOf(e)); } finally { setBusy(false); }
  }

  async function joinRoom(code?: string) {
    setBusy(true); setError('');
    try {
      const result = await api.post('/api/join', { code: code || joinCode.trim(), displayName: displayName.trim() || 'Member' });
      setMembers(result.data.members || 1); setJoined(true);
      invitesClient.clearPendingCode(); setJoinCode(''); await loadRoom();
    } catch (e) { setError(messageOf(e)); } finally { setBusy(false); }
  }

  async function makeInvite() {
    setBusy(true); setError('');
    try {
      const result = await api.post('/api/invites', {});
      const url = invitesClient.buildJoinUrl(result.data.code, { path: '#/join' });
      setInviteCode(url);
    } catch (e) { setError(messageOf(e)); } finally { setBusy(false); }
  }

  async function sendMessage(attachment?: File) {
    if (!text.trim() && !attachment) return;
    setBusy(true); setError('');
    try {
      let file;
      if (attachment) {
        const base64 = await toBase64(attachment);
        const uploaded = await api.post('/api/upload', {
          name: attachment.name, contentType: attachment.type || 'application/octet-stream', content: base64,
        });
        file = { attachmentUrl: uploaded.data.url, attachmentName: attachment.name };
      }
      const result = await api.post('/api/messages', { text: text.trim(), ...file, name: displayName || 'Member' });
      setMessages(old => [...old, result.data.message]); setText('');
    } catch (e) { setError(messageOf(e)); } finally { setBusy(false); }
  }

  async function saveNote() {
    if (!newTitle.trim() || !newBody.trim()) return;
    setBusy(true); setError('');
    try {
      const result = await api.post('/api/notes', { title: newTitle.trim(), body: newBody.trim() });
      setNotes(old => [result.data.note, ...old]); setNewTitle(''); setNewBody('');
    } catch (e) { setError(messageOf(e)); } finally { setBusy(false); }
  }

  if (booting) return <div className="splash"><div className="brand-mark">S</div><p>Opening your space…</p></div>;

  if (!user) return (
    <main className="login-screen" style={themeStyle}>
      <div className="login-card">
        <div className="brand-mark">S</div>
        <div className="eyebrow">A SMALL SPACE FOR YOUR CREW</div>
        <h1>SHADOW<span>NET</span></h1>
        <p className="muted">Private messages, shared study notes and useful files — all in one little corner of the internet.</p>
        <button className="primary wide" onClick={signIn}>Continue to sign in</button>
        <p className="tiny">Only share access with people you know and intend to invite.</p>
        {error && <p className="error">{error}</p>}
      </div>
    </main>
  );

  const pending = invitesClient.getPendingCode();
  return (
    <div className="app-shell" style={themeStyle}>
      <aside className="sidebar">
        <div className="brand"><div className="brand-mark small">S</div><div><b>SHADOW NET</b><span>YOUR PRIVATE SPACE</span></div></div>
        <div className="space-label">WORKSPACE</div>
        <button className={section === 'chat' ? 'nav active' : 'nav'} onClick={() => setSection('chat')}><MessageCircle size={18} /> Messages</button>
        <button className={section === 'study' ? 'nav active' : 'nav'} onClick={() => setSection('study')}><BookOpen size={18} /> Study desk</button>
        <div className="side-bottom">
          <div className="member-chip"><span className="online-dot" /><div><b>{displayName || user.name || 'Member'}</b><small>Signed in</small></div></div>
          <button className={section === 'settings' ? 'nav active' : 'nav'} onClick={() => setSection('settings')}><Settings size={18} /> Appearance</button>
          <button className="nav" onClick={() => auth.signOut().then(() => location.reload())}><LogOut size={18} /> Sign out</button>
        </div>
      </aside>
      <main className="main">
        <header className="topbar">
          <div><div className="eyebrow">PRIVATE GROUP WORKSPACE</div><h2>{section === 'chat' ? 'Messages' : section === 'study' ? 'Study desk' : 'Appearance'}</h2></div>
          <div className="top-actions"><span className="member-count"><Users size={15} /> {members}/50 members</span><span className="avatar">{(displayName || 'M').slice(0, 1).toUpperCase()}</span></div>
        </header>
        {error && <div className="notice error">{error}<button onClick={() => setError('')}>×</button></div>}
        {pending && <div className="panel invite-panel"><div><b>You have an invitation</b><p className="muted">Join the private group workspace.</p></div><button className="primary" onClick={() => joinRoom(pending)} disabled={busy}>Join space</button></div>}
        {!joined && <section className="panel invite-panel onboarding-panel"><div className="brand-mark small">S</div><div><h3>Your private space is not set up yet</h3><p className="muted">Create the space first, then share invitation links with your group. If someone invited you, open their link above.</p><button className="primary" onClick={initializeRoom} disabled={busy || members > 0}>{busy ? 'Setting up…' : 'Create my private space'}</button>{members > 0 && <p className="tiny">This space already has members. Ask an existing member for an invitation link.</p>}</div></section>}
        {joined && section === 'chat' && (
          <div className="chat-layout">
            <section className="panel conversation">
              <div className="panel-head"><div><b>Group conversation</b><small>Saved history · messages stay here when you return</small></div><span className="live-tag">PRIVATE</span></div>
              <div className="message-list">
                {messages.length === 0 && <div className="empty"><MessageCircle size={28} /><b>Your conversation starts here</b><span>Share a question, a thought or a study win.</span></div>}
                {messages.map(m => <article className={m.userId === user.userId ? 'message mine' : 'message'} key={m.id}>
                  <div className="message-avatar">{m.name.slice(0, 1).toUpperCase()}</div>
                  <div className="bubble"><div className="message-meta"><b>{m.userId === user.userId ? 'You' : m.name}</b><time>{new Date(m.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</time></div>
                    {m.text && <p>{m.text}</p>}
                    {m.attachmentUrl && <a className="attachment" href={m.attachmentUrl} target="_blank" rel="noreferrer"><Paperclip size={14} />{m.attachmentName || 'Open attachment'}</a>}
                  </div>
                </article>)}
              </div>
              <form className="composer" onSubmit={e => { e.preventDefault(); void sendMessage(); }}>
                <button type="button" className="icon-btn" aria-label="Attach file" onClick={() => fileRef.current?.click()}><Paperclip size={18} /></button>
                <input ref={fileRef} type="file" hidden accept="image/*,.pdf,.txt,.doc,.docx" onChange={e => { const f = e.target.files?.[0]; if (f) void sendMessage(f); e.currentTarget.value = ''; }} />
                <input value={text} onChange={e => setText(e.target.value)} placeholder="Write a message…" maxLength={4000} />
                <button className="send-btn" disabled={busy || !text.trim()}><Send size={17} /></button>
              </form>
            </section>
            <aside className="right-rail">
              <div className="panel">
                <div className="panel-head"><b><Users size={16} /> Your crew</b></div>
                <div className="crew-stat"><strong>{members}</strong><span>of 50 members joined</span></div>
                <button className="secondary wide" onClick={makeInvite} disabled={busy || members >= 50}><Plus size={15} /> Create invite link</button>
                {inviteCode && <div className="invite-copy"><input readOnly value={inviteCode} />
                  <button className="icon-btn" aria-label="Copy invitation link" onClick={() => navigator.clipboard.writeText(inviteCode).then(() => setError('Invite link copied.'))}><Copy size={15} /></button>
                  <button className="icon-btn" aria-label="Share invitation link" onClick={() => { if (navigator.share) void navigator.share({ title: 'Join my SHADOW NET space', text: 'Join our private SHADOW NET group:', url: inviteCode }).catch(() => undefined); else void navigator.clipboard.writeText(inviteCode).then(() => setError('Invite link copied. Paste it into any chat.')); }}><Users size={15} /></button>
                </div>}
                <p className="tiny">Only invite people you know. Anyone with the link may be able to request access.</p>
              </div>
              <div className="panel tip"><Sparkles size={18} /><b>Study tip</b><p>Drop a photo of a tricky problem and work through it together.</p></div>
            </aside>
          </div>
        )}
        {joined && section === 'study' && (
          <div className="study-layout">
            <section className="panel"><div className="panel-head"><div><b>Shared study notes</b><small>Ideas and explanations for your group</small></div><BookOpen size={18} /></div>
              <div className="note-form"><input value={newTitle} onChange={e => setNewTitle(e.target.value)} placeholder="Note title" /><textarea value={newBody} onChange={e => setNewBody(e.target.value)} placeholder="Write a summary, formula, question or revision note…" rows={5} />
                <button className="primary" onClick={saveNote} disabled={busy || !newTitle.trim() || !newBody.trim()}>Save study note</button>
              </div>
            </section>
            <section className="notes-list"><div className="list-heading"><b>Saved notes</b><input value={filter} onChange={e => setFilter(e.target.value)} placeholder="Search notes…" /></div>
              {notes.filter(n => (n.title + ' ' + n.body).toLowerCase().includes(filter.toLowerCase())).map(n => <article className="panel note-card" key={n.id}><div className="note-icon"><BookOpen size={17} /></div><div><h3>{n.title}</h3><p>{n.body}</p><small>Updated {new Date(n.updatedAt).toLocaleString()}</small></div></article>)}
              {notes.length === 0 && <div className="panel empty"><ImageIcon size={25} /><b>No notes yet</b><span>Create your first shared study note.</span></div>}
            </section>
          </div>
        )}
        {joined && section === 'settings' && (
          <section className="panel settings-panel">
            <div className="panel-head"><div><b>Make it yours</b><small>Appearance is saved on this device for this signed-in profile.</small></div><Settings size={18} /></div>
            <label>Display name<input value={displayName} onChange={e => setDisplayName(e.target.value)} onBlur={() => api.put('/api/profile', { displayName }).catch(e => setError(messageOf(e)))} /></label>
            <label>Accent colour<div className="color-row"><input type="color" value={accent} onChange={e => setAccent(e.target.value)} /><code>{accent.toUpperCase()}</code><button className="secondary" onClick={() => setAccent('#55a7ff')}>Reset</button></div></label>
            <label>Font family<select value={font} onChange={e => setFont(e.target.value)}><option>Space Grotesk</option><option>Inter</option><option>IBM Plex Sans</option><option>Rajdhani</option></select></label>
            <p className="tiny">Your accent colour and font preference stay local to your browser. Each member can choose their own look.</p>
            <div className="preview-card"><span>PREVIEW</span><h2>Think together.</h2><p>One private space. Up to 50 people. Shared progress.</p><button className="primary">Accent preview</button></div>
          </section>
        )}
        <footer>SHADOW NET <span>·</span> A small space to learn together</footer>
      </main>
    </div>
  );
}

function messageOf(e: unknown) { return e instanceof Error ? e.message : 'Something went wrong. Please try again.'; }
function toBase64(file: File) {
  return new Promise<string>((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(String(r.result).split(',')[1] || '');
    r.onerror = () => reject(new Error('Could not read that file'));
    r.readAsDataURL(file);
  });
}
export default App;
