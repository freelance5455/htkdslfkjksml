# SHADOW NET source project

This is the editable React + Vite project source for SHADOW NET, including the existing AppDeploy backend routes and realtime handlers.

## Included
- Private sign-in flow through AppDeploy authentication
- Invitation-only membership
- Shared group chat and persisted message history
- Realtime message and note updates
- File attachments through AppDeploy storage
- Shared study notes
- Display-name and appearance controls
- 50-member room limit

## Important: backend dependency
This is **not a standalone offline HTML app**. The browser UI depends on `@appdeploy/client`, and the server routes depend on `@appdeploy/sdk`. The backend database, authentication, invitation service, storage and WebSocket service are hosted by AppDeploy.

Opening `index.html` directly or deploying only the `dist/` folder to a generic static host will not provide working accounts, shared chat, invitations, uploads or shared notes. Keep this project deployed in its AppDeploy environment, or migrate the backend to another hosted service before moving it elsewhere.

## Run in the matching AppDeploy development environment
1. Extract this folder.
2. Restore/install dependencies in an environment that provides the AppDeploy SDK packages.
3. Run `npm run dev`.
4. Deploy the frontend **and** backend source through AppDeploy.

The AppDeploy-managed logo resource is not embedded in this archive. The live deployment retains it at `public/resources/shadow-net-mark.png`; add that PNG to this path if recreating the deployment from the archive.

## Project structure
- `src/` React UI and styles
- `backend/` API and realtime handlers
- `appdeploy.auth-login.json` sign-in screen configuration
- `tests/tests.json` app QA scenarios
