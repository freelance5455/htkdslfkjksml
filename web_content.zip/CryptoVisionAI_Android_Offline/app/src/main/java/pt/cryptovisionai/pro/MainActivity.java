package pt.cryptovisionai.pro;

import android.app.Activity;
import android.os.Bundle;
import android.os.Build;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.content.Context;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.graphics.Color;
import android.view.ViewGroup;
import java.net.URL;
import java.net.HttpURLConnection;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;

public class MainActivity extends Activity {
  WebView web;
  boolean online(){
    ConnectivityManager cm=(ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
    if(cm==null)return false;
    if(Build.VERSION.SDK_INT>=23){NetworkCapabilities nc=cm.getNetworkCapabilities(cm.getActiveNetwork());return nc!=null&&nc.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET);}
    android.net.NetworkInfo ni=cm.getActiveNetworkInfo();return ni!=null&&ni.isConnected();
  }
  void showStatus(){if(web!=null)web.evaluateJavascript("cvNativeConnectivity("+online()+")",null);}
  @Override public void onCreate(Bundle b){super.onCreate(b);
    web=new WebView(this);web.setBackgroundColor(Color.rgb(10,17,28));
    setContentView(web,new ViewGroup.LayoutParams(-1,-1));
    WebSettings s=web.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);
    s.setDatabaseEnabled(true);s.setCacheMode(WebSettings.LOAD_DEFAULT);
    s.setAllowFileAccess(true);s.setAllowContentAccess(true);
    s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
    web.setWebViewClient(new WebViewClient(){
      @Override public void onPageFinished(WebView v,String u){showStatus();}
      @Override public WebResourceResponse shouldInterceptRequest(WebView view,WebResourceRequest req){
        String url=req.getUrl().toString();
        if(!"GET".equalsIgnoreCase(req.getMethod()))return null;
        // Cache only market-data GET requests, never account/private requests.
        if(!(url.startsWith("https://fapi.binance.com/fapi/v1/") || url.startsWith("https://api.binance.com/api/v3/") || url.startsWith("https://data-api.binance.vision/api/v3/")))return null;
        if(url.contains("/order") || url.contains("/account") || url.contains("/listenKey"))return null;
        try{
          File dir=new File(getCacheDir(),"marketdata");dir.mkdirs();
          MessageDigest digest=MessageDigest.getInstance("SHA-256");byte[] hash=digest.digest(url.getBytes(StandardCharsets.UTF_8));
          StringBuilder key=new StringBuilder();for(byte x:hash)key.append(String.format("%02x",x&255));
          File cache=new File(dir,key.toString()+".json");
          if(online()){
            HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();c.setConnectTimeout(4500);c.setReadTimeout(6000);c.setRequestProperty("User-Agent","CryptoVisionAI/1.0");
            int status=c.getResponseCode();
            if(status>=200&&status<300){
              ByteArrayOutputStream out=new ByteArrayOutputStream();try(InputStream in=c.getInputStream()){byte[] buf=new byte[8192];int n;while((n=in.read(buf))!=-1){out.write(buf,0,n);if(out.size()>2500000)throw new IOException("response too large");}}
              byte[] bytes=out.toByteArray();try(FileOutputStream f=new FileOutputStream(cache)){f.write(bytes);}
              return json(bytes);
            }
          }
          if(cache.isFile())return json(read(cache));
        }catch(Exception ex){ /* Let WebView report an unavailable endpoint if no cached response. */ }
        return null;
      }
    });
    web.loadUrl("file:///android_asset/index.html");
  }
  static byte[] read(File f)throws IOException{ByteArrayOutputStream b=new ByteArrayOutputStream();try(InputStream i=new FileInputStream(f)){byte[] t=new byte[8192];int n;while((n=i.read(t))!=-1)b.write(t,0,n);}return b.toByteArray();}
  static WebResourceResponse json(byte[] data){WebResourceResponse r=new WebResourceResponse("application/json","UTF-8",new ByteArrayInputStream(data));r.setResponseHeaders(java.util.Collections.singletonMap("Access-Control-Allow-Origin","*"));return r;}
  @Override public void onResume(){super.onResume();if(web!=null)showStatus();}
  @Override public void onBackPressed(){if(web!=null&&web.canGoBack())web.goBack();else super.onBackPressed();}
}
