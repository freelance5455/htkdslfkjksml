CRYPTO VISION AI PRO — Projeto Android Studio

1. Abrir esta pasta no Android Studio.
2. Aguardar sincronização Gradle com acesso à internet.
3. Build > Build APK(s).
4. Instalar app/build/outputs/apk/debug/app-debug.apk no Android.

Modo offline: interface HTML incluída no APK; cache nativa das respostas públicas de mercado Binance previamente consultadas online. A biblioteca gráfica e alguns widgets externos são carregados pela internet e podem não funcionar offline, especialmente na primeira abertura. Dados guardados são históricos e NÃO devem ser usados como preços atuais para trading.

Este pacote é CÓDIGO-FONTE, NÃO é um APK compilado.
