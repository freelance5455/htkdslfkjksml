VDX VXOS 1.0 ALPHA
==================

PROJE
-----
VXOS; Android WebView üzerinde çalışan, çevrimdışı öncelikli bir üretim alanı prototipidir.
Bu paket HTML/CSS/JavaScript prototipini ve Android Studio kaynak projesini içerir.

GEREKSİNİMLER
-------------
- Android Studio (Koala veya daha yeni)
- JDK 17
- Android SDK Platform 35
- Android Gradle Plugin 8.7.3 / Gradle 8.9
- Minimum cihaz: Android 6.0 (API 23)

ANDROID STUDIO'DA AÇMA
----------------------
1. ZIP'i çıkar.
2. Android Studio > Open ile VXOS_1.0_ALPHA klasörünü aç.
3. Gradle senkronizasyonunun tamamlanmasını bekle. İlk derlemede internet gerekir.
4. SDK 35 ve JDK 17 kurulu olmalı.
5. Run ile Android cihazda veya emülatörde çalıştır.

APK OLUŞTURMA
-------------
Android Studio: Build > Build Bundle(s) / APK(s) > Build APK(s)
APK genellikle app/build/outputs/apk/debug/app-debug.apk konumunda oluşur.

Komut satırı (Gradle kuruluysa):
  gradle assembleDebug

HTML PROTOTİP
-------------
Android Studio olmadan app/src/main/assets/index.html dosyasını modern bir tarayıcıda
açmayı deneyebilirsin. ES module ve IndexedDB kullanıldığı için bazı tarayıcılarda
file:// kısıtları nedeniyle yerel HTTP sunucusu gerekebilir. Android uygulamasında
dosyalar WebView içinden yüklenir.

MODÜLLER / İŞLEVLER
-------------------
- VXOS Home ve modül gezinmesi
- VDX Notes: oluşturma, düzenleme, silme, arama, kategori/etiket alanları
- Project Hub: proje kayıtları
- Task Manager: görev kayıtları ve öncelik alanı
- Working Components: kod parçaları kaydetme ve yönetme
- Code Lab: HTML/CSS/JS editörleri, izole sandbox iframe önizlemesi, console aktarımı
- MATE CALC: güvenli parser, temel ve bilimsel fonksiyonlar, hafıza, işlem geçmişi, görsel arka plan
- VX Search: Google/Bing resmi arama URL'leri, geçmiş ve favori altyapısı
- VX Unit: uzunluk, ağırlık, sıcaklık, hız, veri dönüştürme
- VX Time: kronometre ve geri sayım
- VX Files: JSON yedek dışa/içe aktarma, veri temizleme
- Asset Manager: Android belge seçici üzerinden görsel alma, duvar kâğıdı
- VDX_BASE: yerel kayıtların merkezi görünümü
- Vexa AI: yapılandırılabilir endpoint/model alanı ve hata yönetimi
- Development Lab ve System Center

VERİ / GİZLİLİK
---------------
Kullanıcı verileri IndexedDB'de cihaz üzerinde tutulur. JSON yedekleme kullanıcı eylemiyle
başlatılır. Vexa AI endpoint'i yapılandırılırsa mesaj ve API anahtarı ilgili harici servise
gönderilir. İstemci içinde saklanan API anahtarı güçlü bir sunucu kasası koruması sağlamaz.
Üretim sürümünde anahtarın backend proxy üzerinde tutulması önerilir.

ANDROID İZİNLERİ
----------------
INTERNET izni ağ arama ve kullanıcı tarafından yapılandırılan AI bağlantısı içindir.
Görsel seçimi ACTION_OPEN_DOCUMENT ile yapılır; geniş depolama izni istenmez.

BİLİNEN EKSİKLİKLER / ALPHA SINIRLARI
-------------------------------------
- VDX CLOUD, Watch bağlantısı, gerçek otomasyon motoru, Analytics ve çevrimiçi senkronizasyon
  için backend/servis henüz yoktur.
- VX Search kendi crawler/index altyapısına sahip değildir; resmi sağlayıcı arama sayfalarını açar.
- Google/Bing araması için internet ve harici tarayıcı gerekir.
- AI bağlantısı sağlayıcının OpenAI-uyumlu Chat Completions biçimini ve CORS iznini
  gerektirir; bazı sağlayıcılarda doğrudan tarayıcı bağlantısı çalışmayabilir.
- AI anahtarını istemci tarafında saklamak üretim güvenliği için uygun değildir.
- Android'de gerçek cihaz depolama kotası ve pil/arka plan ölçümleri bu prototipte gösterilmez.
- Görsel verisi alpha sürümünde IndexedDB içinde Data URL olarak tutulur; büyük dosyalarda
  tarayıcı kotası sınırlayıcı olabilir.
- Module Manager yalnızca paket içindeki yerel modüllerin durumunu gösterir. Sonradan
  indirilen HTML/CSS/JS paketleri için imza/doğrulama ve güvenli güncelleme servisi
  henüz uygulanmamıştır. Android çalıştırılabilir kodu dinamik yüklenmez.
- VDX_BASE ve VXOS aynı uygulama içindeki ortak IndexedDB depolarını kullanır; ayrı
  uygulamalar arası aktarım JSON yedek üzerinden yapılır.
- UI Designer, Version Control, VDX Watch ve VDX CLOUD sonraki sürüm modülleridir.

GÜVENLİK NOTLARI
---------------
Code Lab iframe'i sandbox="allow-scripts" ile çalışır; allow-same-origin verilmez.
Kullanıcı kodunun uygulamanın IndexedDB alanına doğrudan erişmesi engellenir.
Kullanıcı kodu yine de iframe içinde çalışır; bilinmeyen kodu çalıştırırken dikkatli ol.
Arama URL'leri encodeURIComponent ile oluşturulur. Arama sonuçları kazınmaz.
Harici bağlantılar WebView dışına yönlendirilir.

TEST RAPORU
-----------
Paket oluşturulurken aşağıdaki statik kontroller yapılmıştır:
- Zorunlu Android/asset dosyalarının varlığı
- Namespace, applicationId, minSdk ve compileSdk değerleri
- HTML'deki modül gezinme hedefleri
- JavaScript modül import yollarının varlığı
- ZIP arşivinin açılabilirliği ve boyutu

Bu ortamda Android SDK/Gradle derlemesi ve gerçek cihaz/emülatör testi yapılmadı.
Bu nedenle APK'nın derlendiği veya cihazda uçtan uca test edildiği iddia edilmez.
