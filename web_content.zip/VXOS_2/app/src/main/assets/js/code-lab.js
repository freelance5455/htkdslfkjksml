export function buildPreview(html,css,js){
 const safeJs=String(js).replace(/<\/script/gi,"<\\/script");
 const bridge=`<script>
 const send=(type,args)=>parent.postMessage({vxosConsole:true,type,args:Array.from(args).map(x=>{try{return typeof x==='object'?JSON.stringify(x):String(x)}catch(e){return String(x)}})},'*');
 ['log','warn','error','info'].forEach(k=>{const old=console[k];console[k]=function(){send(k,arguments);old.apply(console,arguments)}});
 window.addEventListener('error',e=>send('error',[e.message+' ('+e.lineno+':'+e.colno+')']));
 window.addEventListener('unhandledrejection',e=>send('error',[String(e.reason)]));
 <\/script>`;
 return `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><style>${css}</style></head><body>${html}${bridge}<script>${safeJs}<\/script></body></html>`;
}
