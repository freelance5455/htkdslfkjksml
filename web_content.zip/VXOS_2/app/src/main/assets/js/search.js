import {all,put,remove,uid} from "./storage.js";
export async function searchWeb(q,provider="google"){
 const clean=String(q).trim();if(!clean)throw new Error("Arama metni gir.");
 const url=provider==="bing"?"https://www.bing.com/search?q="+encodeURIComponent(clean):"https://www.google.com/search?q="+encodeURIComponent(clean);
 await put("history",{id:uid(),query:clean,url,createdAt:Date.now()});
 return url;
}
export async function history(){return (await all("history")).sort((a,b)=>b.createdAt-a.createdAt);}
export async function favorites(){return all("favorites");}
export async function toggleFavorite(item){const list=await favorites();const old=list.find(x=>x.url===item.url);if(old)await remove("favorites",old.id);else await put("favorites",{...item,id:uid(),savedAt:Date.now()});}
