export function convertUnit(value,kind,from,to){
 const v=Number(value);if(!Number.isFinite(v))throw new Error("Geçerli bir sayı gir.");
 const tables={
 length:{m:1,km:1000,cm:.01,mm:.001,mi:1609.344,ft:.3048},
 mass:{kg:1,g:.001,mg:.000001,lb:.45359237},
 speed:{'m/s':1,'km/h':1/3.6,mph:.44704},
 data:{B:1,KB:1024,MB:1048576,GB:1073741824}
 };
 if(kind==="temperature"){let c=from==="C"?v:from==="F"?(v-32)*5/9:v-273.15;return to==="C"?c:to==="F"?c*9/5+32:c+273.15;}
 const t=tables[kind];if(!t||!(from in t)||!(to in t))throw new Error("Birim eşleşmesi bulunamadı.");return v*t[from]/t[to];
}
