// Recursive-descent parser: deliberately avoids eval() and validates every token.
export function calculate(source, degree=true){
 const s=String(source).replace(/\s+/g,"").replace(/×/g,"*").replace(/÷/g,"/");
 if(!s) throw new Error("İfade boş.");
 let i=0;
 const peek=()=>s[i]||"", eat=c=>{if(s[i]===c){i++;return true}return false};
 function expr(){let v=term();while(true){if(eat("+"))v+=term();else if(eat("-"))v-=term();else return v;}}
 function term(){let v=power();while(true){if(eat("*"))v*=power();else if(eat("/")){const d=power();if(d===0)throw new Error("Sıfıra bölme yapılamaz.");v/=d;}else return v;}}
 function power(){let v=unary();if(eat("^"))v=Math.pow(v,power());while(eat("%"))v/=100;return v;}
 function unary(){if(eat("+"))return unary();if(eat("-"))return -unary();return atom();}
 function atom(){
  if(eat("(")){const v=expr();if(!eat(")"))throw new Error("Kapanmayan parantez.");return v;}
  const start=i;while(/[0-9.]/.test(peek())&&peek())i++;
  if(i>start){const raw=s.slice(start,i);if((raw.match(/\./g)||[]).length>1)throw new Error("Geçersiz sayı.");return Number(raw);}
  if(s.slice(i,i+2).toLowerCase()==="pi"){i+=2;return Math.PI;}
  const startFn=i;while(/[a-z]/i.test(peek())&&peek())i++;
  if(i>startFn){const fn=s.slice(startFn,i).toLowerCase();if(!eat("("))throw new Error(`${fn} için parantez gerekli.`);const x=expr();if(!eat(")"))throw new Error("Kapanmayan fonksiyon parantezi.");const a=degree?Math.PI/180:1;
   const fns={sin:Math.sin(x*a),cos:Math.cos(x*a),tan:Math.tan(x*a),sqrt:Math.sqrt(x),log:Math.log10(x),ln:Math.log(x),abs:Math.abs(x)};
   if(!(fn in fns))throw new Error("Bilinmeyen fonksiyon: "+fn);if((fn==="sqrt"&&x<0)||((fn==="log"||fn==="ln")&&x<=0))throw new Error("Fonksiyon tanım aralığı dışında.");return fns[fn];}
  throw new Error("Beklenmeyen karakter: "+(peek()||"son"));
 }
 const result=expr();if(i!==s.length)throw new Error("Geçersiz ifade: "+s.slice(i));if(!Number.isFinite(result))throw new Error("Sonuç sonlu bir sayı değil.");return Number(result.toPrecision(12));
}
