const DB_NAME = "vxos-local";
const DB_VERSION = 1;
const STORES = ["notes","projects","tasks","components","assets","settings","history","favorites","snippets"];
let dbPromise;
function openDB(){
  if(dbPromise) return dbPromise;
  dbPromise = new Promise((resolve,reject)=>{
    const req=indexedDB.open(DB_NAME,DB_VERSION);
    req.onupgradeneeded=()=>{const db=req.result; STORES.forEach(s=>{if(!db.objectStoreNames.contains(s)) db.createObjectStore(s,{keyPath:"id"});});};
    req.onsuccess=()=>resolve(req.result); req.onerror=()=>reject(req.error);
  });
  return dbPromise;
}
export async function all(store){const db=await openDB();return new Promise((res,rej)=>{const r=db.transaction(store).objectStore(store).getAll();r.onsuccess=()=>res(r.result||[]);r.onerror=()=>rej(r.error);});}
export async function put(store,value){const db=await openDB();return new Promise((res,rej)=>{const r=db.transaction(store,"readwrite").objectStore(store).put(value);r.onsuccess=()=>res(value);r.onerror=()=>rej(r.error);});}
export async function remove(store,id){const db=await openDB();return new Promise((res,rej)=>{const r=db.transaction(store,"readwrite").objectStore(store).delete(id);r.onsuccess=()=>res();r.onerror=()=>rej(r.error);});}
export async function get(store,id){const db=await openDB();return new Promise((res,rej)=>{const r=db.transaction(store).objectStore(store).get(id);r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error);});}
export async function exportAll(){
 const out={format:"VXOS_BACKUP",version:1,createdAt:new Date().toISOString(),data:{}};
 for(const s of STORES) out.data[s]=await all(s);
 return out;
}
export async function importAll(payload){
 if(!payload||payload.format!=="VXOS_BACKUP"||payload.version!==1||!payload.data) throw new Error("Geçersiz VXOS yedeği.");
 for(const s of STORES){if(!Array.isArray(payload.data[s])) continue; for(const item of payload.data[s]){if(!item||typeof item.id!=="string") throw new Error("Yedekte geçersiz kayıt var."); await put(s,item);}}
}
export async function clearAll(){const db=await openDB();for(const s of STORES) await new Promise((res,rej)=>{const r=db.transaction(s,"readwrite").objectStore(s).clear();r.onsuccess=res;r.onerror=()=>rej(r.error);});}
export const uid=()=>`${Date.now().toString(36)}-${Math.random().toString(36).slice(2,9)}`;
