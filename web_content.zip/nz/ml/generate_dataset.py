"""Generate labelled windows from the physics model (SYNTHETIC: validates the pipeline; retrain on real labelled data for production)."""
import random, numpy as np
from physics import Motor, feat, W, CLASSES
def make(runs=400, stride=10, seed=0):
    random.seed(seed); X, yc, yw, rid = [], [], [], []
    for r in range(runs):
        m = Motor(load=random.uniform(40, 95), V=random.uniform(390, 410), Ta=random.uniform(15, 35), U=random.uniform(.2, 1), wear=random.uniform(2, 15))
        fault = random.randrange(len(CLASSES)); onset = random.randint(500, 1000); rows = []; lab = []
        for t in range(1800):
            sev = min(1, max(0, (t - onset) / 600)) if fault else 0
            m.apply(fault, sev); rows.append(feat(m.sample()))
            lab.append((fault if sev >= .5 else 0, 1 if (fault and 0 < sev < .5) else 0))
        for e in range(W, 1800, stride):
            X.append(rows[e - W:e]); yc.append(lab[e - 1][0]); yw.append(lab[e - 1][1]); rid.append(r)
    return np.array(X, np.float32), np.array(yc), np.array(yw, np.float32), np.array(rid)
if __name__ == "__main__":
    X, yc, yw, rid = make(40); print(X.shape, np.bincount(yc), yw.mean())
