"""Train the TCN (8-class fault classifier) and BiLSTM (5-minute early warning); export ONNX into ../backend/models.
pip install torch numpy onnx   then:  python train.py"""
import os, numpy as np, torch, torch.nn as nn, torch.nn.functional as F
from physics import CLASSES, W
from generate_dataset import make
torch.manual_seed(0)
class Blk(nn.Module):
    def __init__(s, ci, co, d):
        super().__init__(); s.p = 2 * d; s.a = nn.Conv1d(ci, co, 3, dilation=d); s.b = nn.Conv1d(co, co, 3, dilation=d)
        s.r = nn.Conv1d(ci, co, 1) if ci != co else nn.Identity()
    def forward(s, x):
        y = F.relu(s.a(F.pad(x, (s.p, 0)))); y = F.relu(s.b(F.pad(y, (s.p, 0)))); return F.relu(y + s.r(x))
class TCN(nn.Module):
    def __init__(s, nf=12, nc=len(CLASSES)):
        super().__init__(); s.n = nn.Sequential(Blk(nf, 32, 1), Blk(32, 32, 2), Blk(32, 32, 4)); s.o = nn.Linear(32, nc)
    def forward(s, x): return s.o(s.n(x.transpose(1, 2)).mean(2))
class BiLSTM(nn.Module):
    def __init__(s, nf=12):
        super().__init__(); s.l = nn.LSTM(nf, 64, batch_first=True, bidirectional=True); s.o = nn.Linear(128, 1)
    def forward(s, x): return s.o(s.l(x)[0].mean(1))
def fit(m, X, y, loss, ep=12):
    opt = torch.optim.Adam(m.parameters(), 2e-3)
    for e in range(ep):
        p = torch.randperm(len(X)); m.train()
        for i in range(0, len(X), 256):
            b = p[i:i + 256]; opt.zero_grad(); l = loss(m(X[b]), y[b]); l.backward(); opt.step()
        print(" epoch", e + 1, "loss", round(float(l), 4))
if __name__ == "__main__":
    X, yc, yw, rid = make(400); tr = rid < 320; te = ~tr
    Xt, Xe = torch.tensor(X[tr]), torch.tensor(X[te]); out = os.path.join("..", "backend", "models"); os.makedirs(out, exist_ok=True)
    t = TCN(); fit(t, Xt, torch.tensor(yc[tr]), lambda o, y: F.cross_entropy(o, y)); t.eval()
    pr = t(Xe).argmax(1).numpy(); print("TCN accuracy", (pr == yc[te]).mean().round(3))
    for c, n in enumerate(CLASSES): print(f"  {n:18s} recall {((pr == c) & (yc[te] == c)).sum() / max(1, (yc[te] == c).sum()):.2f}")
    b = BiLSTM(); fit(b, Xt, torch.tensor(yw[tr]).unsqueeze(1), lambda o, y: F.binary_cross_entropy_with_logits(o, y)); b.eval()
    pw = (torch.sigmoid(b(Xe)).squeeze(1).detach().numpy() > .5); yt = yw[te] > .5
    print("EWS precision", ((pw & yt).sum() / max(1, pw.sum())).round(3), "recall", ((pw & yt).sum() / max(1, yt.sum())).round(3))
    d = torch.zeros(1, W, 12)
    for n, m in (("tcn", t), ("bilstm", b)):
        torch.onnx.export(m, d, os.path.join(out, n + ".onnx"), input_names=["x"], output_names=["y"], dynamic_axes={"x": {0: "b"}}, opset_version=17)
    print("exported to", out)
