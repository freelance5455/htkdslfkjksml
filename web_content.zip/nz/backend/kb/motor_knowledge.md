# Electric motor troubleshooting knowledge base (15 kW, 400 V, class F induction motor)

## Cooling blockage or fan failure
Symptom: winding temperature rises above what the physics twin expects (dT above 10 K) while current and load are normal. Causes: clogged fins or ducts, broken fan, high ambient. Actions: stop if winding passes 145 C, clean fins, check the fan, verify ambient. Every 10 C above the reference temperature roughly halves insulation life.

## Bearing wear
Symptom: vibration RMS rises (ISO 20816-3: above 4.5 mm/s unsatisfactory, above 7.1 mm/s unacceptable) and bearing temperature climbs, often DE first. Actions: check lubrication, alignment, shaft currents; plan bearing replacement; stop above 7.1 mm/s.

## Overload
Symptom: current above 110 percent of rated (28.5 A) and speed falling below 1470 rpm. Causes: process jam, wrong sizing, low voltage. Actions: reduce load, check the driven machine; sustained overload heats the winding quickly.

## Voltage sag and out-of-range supply
Symptom: voltage below 95 percent of 400 V, current rising, speed slightly lower. Actions: check feeder, transformer tap and upstream loads. Below 360 V expect derating; trip protection is an electrician task.

## Phase unbalance
Symptom: voltage unbalance above 2 percent with current unbalance several times larger. NEMA guidance: derate above 1 percent and avoid above 5 percent; temperature rise grows about 2 percent per percent squared. Actions: check fuses, loose terminals, single-phase loads.

## Winding turn-to-turn short
Symptom: current higher than twin expectation (dI), unbalanced currents, winding hotter than expected, vibration slightly up. Actions: stop the motor, measure winding resistance and insulation resistance (megger, minimum 1 MOhm plus 1 MOhm per kV). Do not restart before testing.

## Insulation ageing
Class F insulation limit is 155 C. NEZORA estimates consumed life with an Arrhenius rule of thumb (life halves per 10 C above 130 C, 20000 h reference). It is an estimate, not a measurement; confirm with insulation resistance and polarization index tests.

## Sensor fault
Symptom: a temperature reading frozen for a long time while the load changes, or readings jumping. Actions: compare with the physics twin, check wiring and the PT100 transmitter, swap the sensor. Do not trust alerts based on a suspect sensor.

## Trip procedure
When status is TRIPPED: stop the motor, lock out, identify the root cause from the alert log, fix it, test insulation, then restart at reduced load while watching temperature and vibration.
