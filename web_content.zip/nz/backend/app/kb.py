"""Tiny retrieval over the motor knowledge base (TF-IDF) + optional Claude answer (needs ANTHROPIC_API_KEY)."""
import glob, math, os, re, httpx
def load(d):
    docs = []
    for f in sorted(glob.glob(os.path.join(d, "*.md"))):
        for sec in re.split(r"\n(?=## )", open(f, encoding="utf-8").read()):
            if sec.strip(): docs.append((sec.strip().split("\n")[0].lstrip("# "), sec.strip()))
    return docs
tok = lambda t: re.findall(r"[a-z0-9]+", t.lower())
def search(q, docs, k=3):
    N = len(docs); df = {}
    for _, b in docs:
        for w in set(tok(b)): df[w] = df.get(w, 0) + 1
    sc = []
    for t, b in docs:
        ws = tok(b); s = sum(ws.count(w) / (len(ws) or 1) * math.log(1 + N / df[w]) for w in set(tok(q)) if w in df); sc.append((s, t, b))
    return [(t, b) for s, t, b in sorted(sc, reverse=True)[:k] if s > 0]
async def ask(q, docs, ctx):
    hits = search(q, docs); key = os.getenv("ANTHROPIC_API_KEY", "")
    if not key: return dict(answer="(No ANTHROPIC_API_KEY set - showing the most relevant knowledge-base sections.)\n\n" + "\n\n".join(b for _, b in hits), sources=[t for t, _ in hits])
    system = "You are the NEZORA motor maintenance assistant. Answer concisely using the knowledge base excerpts and the live motor status. Say so when the information is not covered; never invent measurements."
    prompt = f"Live status: {ctx}\n\nKnowledge base:\n" + "\n\n".join(b for _, b in hits) + f"\n\nQuestion: {q}"
    try:
        async with httpx.AsyncClient(timeout=40) as c:
            r = await c.post("https://api.anthropic.com/v1/messages", headers={"x-api-key": key, "anthropic-version": "2023-06-01"},
                             json=dict(model=os.getenv("ANTHROPIC_MODEL", "claude-sonnet-5-5"), max_tokens=700, system=system, messages=[dict(role="user", content=prompt)]))
        r.raise_for_status(); return dict(answer=r.json()["content"][0]["text"], sources=[t for t, _ in hits])
    except Exception as e: return dict(answer=f"Assistant error: {e}", sources=[t for t, _ in hits])
