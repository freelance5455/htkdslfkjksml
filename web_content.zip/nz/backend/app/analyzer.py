"""Server-side diagnosis: physics twin residuals, ISO/NEMA rules, health score, insulation life, ML (ONNX) diagnosis."""
import math, os
from collections import deque
from physics import NP, CLASSES, W, feat, iexp, lof, step

def cl(x, a, b): return max(a, min(b, x))
def sc(x, g, b): return 100 * cl((b - x) / (b - g), 0, 1)
RULES = [
 ("vib", lambda s: s["vib"], 4.5, 7.1, "Vibration high (ISO 20816-3 zone C/D)", "Check bearings, alignment and mounting; schedule a stop if it keeps rising."),
 ("Tw", lambda s: s["Tw"], 130, 145, "Winding temperature high", "Check cooling fan and airflow; reduce load."),
 ("Tb", lambda s: max(s["Tde"], s["Tnde"]), 85, 95, "Bearing temperature high", "Check lubrication and bearing condition."),
 ("U", lambda s: s["U"], 2, 5, "Voltage unbalance", "Check supply phases, fuses and connections; derate above 5%."),
 ("Vd", lambda s: abs(s["V"] - NP["V"]) / NP["V"] * 100, 5, 10, "Supply voltage out of range", "Check the feeder and transformer tap."),
 ("I", lambda s: s["I"] / NP["Ir"] * 100, 110, 130, "Overcurrent", "Reduce mechanical load; check for a jam or low voltage."),
 ("IU", lambda s: s["IU"], 10, 20, "Current unbalance", "Inspect winding and supply connections."),
 ("dT", lambda s: s["dT"], 10, 20, "Winding hotter than the physics twin expects", "Likely cooling loss or winding fault; inspect fan and ducts."),
 ("dI", lambda s: abs(s["dI"]), 15, 30, "Current differs from twin expectation", "Possible mechanical or electrical fault.")]
DEF = dict(Va=NP["V"], Vb=NP["V"], Vc=NP["V"], Ia=NP["Ir"] * .75, Ib=NP["Ir"] * .75, Ic=NP["Ir"] * .75, rpm=NP["n"], Tw=65, Tde=50, Tnde=48, vib=1.5, Tamb=NP["Tamb"])

def fill(x):
    x = dict(x)
    for k, v in DEF.items():
        if x.get(k) is None: x[k] = x.get("Ia") if k in ("Ib", "Ic") and x.get("Ia") is not None else v
        x[k] = float(x[k])
    return x

class Monitor:
    def __init__(s, models_dir="models"):
        s.last = None; s.twin = None; s.life = 0.0; s.act = {}; s.win = deque(maxlen=W); s.n = 0; s.mlc = {"cls": 0, "ews": 0}
        s.tcn = s.ews = None
        try:
            import onnxruntime as ort
            s.tcn = ort.InferenceSession(os.path.join(models_dir, "tcn.onnx")); s.ews = ort.InferenceSession(os.path.join(models_dir, "bilstm.onnx"))
        except Exception: pass
    def process(s, x):
        x = fill(x); t = x.get("t"); t = float(t) if t is not None else (s.last or 0) + 1
        dt = 1.0 if s.last is None else cl(t - s.last, .05, 60); s.last = t
        V = (x["Va"] + x["Vb"] + x["Vc"]) / 3; U = (V - min(x["Va"], x["Vb"], x["Vc"])) / V * 100
        I = (x["Ia"] + x["Ib"] + x["Ic"]) / 3; IU = (max(x["Ia"], x["Ib"], x["Ic"]) - I) / I * 100
        if s.twin is None: s.twin = x["Tw"]
        s.twin = step(s.twin, dt, x["rpm"], V, U, x["Tamb"], 1.0); Ie = iexp(x["rpm"], V)
        d = dict(x, V=V, U=U, I=I, IU=IU, dT=x["Tw"] - s.twin, dI=(I - Ie) / Ie * 100)
        aaf = 2 ** ((x["Tw"] - 130) / 10); s.life += aaf * dt / 3600 / 20000 * 100
        sev = 0; alerts = []
        for k, f, w, c, msg, act in RULES:
            v = f(d); lv = 2 if v >= c else 1 if v >= w else 0; prev = s.act.get(k, 0)
            if lv < prev and v >= (w if prev == 1 else c) * .9: lv = prev  # hysteresis: avoid alert chatter
            if lv > prev: alerts.append((lv, k, msg, round(v, 2), act))
            s.act[k] = lv; sev = max(sev, lv)
        if x["Tw"] >= NP["Tlim"] and not s.act.get("trip"): s.act["trip"] = 1; alerts.append((3, "trip", "Winding reached the insulation limit", round(x["Tw"], 1), "Stop the motor now."))
        if x["Tw"] < NP["Tlim"] - 10: s.act["trip"] = 0
        Se = .5 * sc(abs(V - NP["V"]) / NP["V"] * 100, 0, 10) + .3 * sc(U, 0, 5) + .2 * sc(I / NP["Ir"] * 100, 100, 130)
        Sm = .4 * sc(x["Tw"], 100, NP["Tlim"]) + .35 * sc(x["vib"], 2.8, 7.1) + .25 * sc(max(x["Tde"], x["Tnde"]), 70, 95)
        Sr = .5 * sc(abs(d["dT"]), 0, 20) + .5 * sc(abs(d["dI"]), 0, 30); hs = .35 * Se + .35 * Sm + .3 * Sr
        s.win.append(feat(x)); s.n += 1; ml = None
        if s.tcn and len(s.win) == W and s.n % 5 == 0:
            try:
                import numpy as np
                a = np.array(s.win, dtype=np.float32)[None]; lg = s.tcn.run(None, {"x": a})[0][0]; e = np.exp(lg - lg.max()); p = e / e.sum(); c = int(p.argmax())
                pe = float(1 / (1 + np.exp(-s.ews.run(None, {"x": a})[0][0][0]))); ml = dict(cls=CLASSES[c], p=float(p[c]), ews=pe)
                s.mlc["cls"] = s.mlc["cls"] + 1 if (c != 0 and p[c] > .8) else 0; s.mlc["ews"] = s.mlc["ews"] + 1 if pe > .7 else 0
                if s.mlc["cls"] == 3: alerts.append((2, "ml", f"ML diagnosis: {CLASSES[c]} ({p[c]:.0%})", round(float(p[c]), 2), "Confirm with the rule alerts and inspect the motor."))
                if s.mlc["ews"] == 3: alerts.append((1, "ml_ews", "ML early warning: a fault is expected within about 5 minutes", round(pe, 2), "Plan an inspection now."))
                s.ml = ml
            except Exception: pass
        status = ["NORMAL", "WARNING", "CRITICAL", "TRIPPED"][3 if s.act.get("trip") else sev]
        return dict(hs=round(hs, 1), status=status, V=round(V, 1), U=round(U, 2), I=round(I, 2), IU=round(IU, 1), dT=round(d["dT"], 1), dI=round(d["dI"], 1),
                    twin=round(s.twin, 1), life=round(s.life, 4), aaf=round(aaf, 2), ml=getattr(s, "ml", None)), alerts
