"""Shared induction-motor physics: nameplate model, lumped thermal model, fault injection, ML features."""
import math, random
NP = dict(P=15000, V=400, f=50, Ir=28.5, n=1470, p=4, eff=.91, Tamb=25, rise=80, tau=1800, Tlim=155)
ns = 120 * NP["f"] / NP["p"]; sr = (ns - NP["n"]) / ns
Qr = NP["P"] * (1 / NP["eff"] - 1); Rth = NP["rise"] / Qr; C = NP["tau"] / Rth; I0 = .35 * NP["Ir"]
CLASSES = ["normal", "cooling_blockage", "bearing_wear", "overload", "voltage_sag", "phase_unbalance", "winding_short", "sensor_fault"]
FEATS = ["Ia", "Ib", "Ic", "Va", "Vb", "Vc", "rpm", "Tw", "Tde", "Tnde", "vib", "Tamb"]
W = 60  # ML window length (samples, 1 Hz)

def g(): return (random.random() + random.random() + random.random() - 1.5) * .8
def lof(rpm): return min(1.8, max(0.0, (ns - rpm) / ns / sr))
def iexp(rpm, V): L = lof(rpm); return math.sqrt(I0 ** 2 + (NP["Ir"] ** 2 - I0 ** 2) * L * L) * (NP["V"] / V) ** .6
def step(T, dt, rpm, V, U, Ta, fan, extra=0.0):
    L = lof(rpm); Q = Qr * (.3 + .7 * L * L) * (1 + .02 * U * U) * (1 + extra); R = Rth / max(.15, fan)
    n = max(1, math.ceil(dt / 5)); h = dt / n
    for _ in range(n): T += (Q - (T - Ta) / R) / C * h
    return T
def feat(s):
    return [s["Ia"] / NP["Ir"], s["Ib"] / NP["Ir"], s["Ic"] / NP["Ir"], s["Va"] / NP["V"], s["Vb"] / NP["V"], s["Vc"] / NP["V"],
            s["rpm"] / ns, s["Tw"] / 100, s["Tde"] / 100, s["Tnde"] / 100, s["vib"] / 10, s["Tamb"] / 50]

class Motor:
    """Physics-based motor with fault injection (severity 0..1)."""
    def __init__(s, load=75, V=400, Ta=25, U=.5, wear=5):
        s.B = dict(load=load, V=V, U=U, Ta=Ta, fan=1., wear=wear, short=0., stuck=False); s.P = dict(s.B)
        s.t = 0; s.Ts = None; s.stuckv = None
    def apply(s, fault, sev):
        P, B = s.P, s.B; P.update(B)
        if fault == 1: P["fan"] = 1 - .65 * sev
        elif fault == 2: P["wear"] = B["wear"] + 70 * sev
        elif fault == 3: P["load"] = B["load"] + (125 - B["load"]) * sev
        elif fault == 4: P["V"] = B["V"] - 70 * sev
        elif fault == 5: P["U"] = B["U"] + 6 * sev
        elif fault == 6: P["short"] = sev
        elif fault == 7: P["stuck"] = sev >= .5
    def sample(s):
        P = s.P; L = P["load"] / 100; rpm = ns * (1 - sr * L) + g()
        if s.Ts is None: s.Ts = P["Ta"] + Rth * Qr * (.3 + .7 * L * L)
        s.Ts = step(s.Ts, 1, rpm, P["V"], P["U"], P["Ta"], P["fan"], 2 * P["short"]); s.t += 1
        I = iexp(rpm, P["V"]) * (1 + .4 * P["short"]); u = P["U"] / 100
        Tb = P["Ta"] + 8 + 14 * L + .35 * (s.Ts - P["Ta"]) + P["wear"] * .35
        tw = s.Ts + g() * .3
        if P["stuck"]:
            if s.stuckv is None: s.stuckv = tw
            tw = s.stuckv
        else: s.stuckv = None
        return dict(motor="M-101", t=s.t, Va=P["V"] * (1 - u) + g(), Vb=P["V"] * (1 + .5 * u) + g(), Vc=P["V"] * (1 + .5 * u) + g(),
                    Ia=I * (1 + 6 * u) + g() * .1, Ib=I * (1 - 3 * u) + g() * .1, Ic=I * (1 - 3 * u) + g() * .1, rpm=rpm, Tw=tw,
                    Tde=Tb + 2 + g() * .3, Tnde=Tb + g() * .3, vib=.7 + .7 * L + .12 * P["U"] + P["wear"] / 100 * 9 + 1.5 * P["short"] + g() * .08, Tamb=P["Ta"])
