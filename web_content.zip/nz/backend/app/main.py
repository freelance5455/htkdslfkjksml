"""NEZORA backend: ingestion (HTTP / Kafka) -> physics-twin + ML diagnosis -> storage -> live WebSocket, alerts, reports, assistant."""
import asyncio, csv, html, io, json, os, sqlite3, sys, threading, time
sys.path.insert(0, os.path.dirname(__file__))
from fastapi import FastAPI, Header, HTTPException, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse, HTMLResponse, PlainTextResponse
from fastapi.staticfiles import StaticFiles
from analyzer import Monitor
import kb

HERE = os.path.dirname(__file__); STATIC = os.path.join(HERE, "static")
DB_PATH = os.getenv("DB_PATH", "data/nezora.db"); API_KEY = os.getenv("API_KEY", ""); KAFKA = os.getenv("KAFKA_BROKERS", "")
MODELS = os.getenv("MODELS_DIR", os.path.join(HERE, "..", "models")); KB = kb.load(os.getenv("KB_DIR", os.path.join(HERE, "..", "kb")))
os.makedirs(os.path.dirname(DB_PATH) or ".", exist_ok=True)
db = sqlite3.connect(DB_PATH, check_same_thread=False); lock = threading.Lock()
db.execute("CREATE TABLE IF NOT EXISTS samples(id INTEGER PRIMARY KEY, ts REAL, motor TEXT, data TEXT)")
db.execute("CREATE TABLE IF NOT EXISTS alerts(id INTEGER PRIMARY KEY, ts REAL, motor TEXT, level INT, rule TEXT, msg TEXT, value REAL, action TEXT, ack INT DEFAULT 0)")
clients, monitors, latest, producer = set(), {}, {}, None
app = FastAPI(title="NEZORA", version="2.0")

def q(sql, a=()):
    with lock: return db.execute(sql, a).fetchall()
def ex(sql, a=()):
    with lock: db.execute(sql, a); db.commit()

async def handle(items):
    out = []
    for d in items:
        m = str(d.get("motor", "M-101")); mon = monitors.setdefault(m, Monitor(MODELS)); res, al = mon.process(d)
        ex("INSERT INTO samples(ts,motor,data) VALUES(?,?,?)", (time.time(), m, json.dumps(d)))
        for lv, rule, msg, val, act in al: ex("INSERT INTO alerts(ts,motor,level,rule,msg,value,action) VALUES(?,?,?,?,?,?,?)", (time.time(), m, lv, rule, msg, val, act))
        latest[m] = dict(res, sample=d); out.append(dict(d, result=res))
    for ws in list(clients):
        try: await ws.send_text(json.dumps(out))
        except Exception: clients.discard(ws)

async def consume():
    from aiokafka import AIOKafkaConsumer
    c = AIOKafkaConsumer("nezora.telemetry", bootstrap_servers=KAFKA, group_id="nezora"); await c.start()
    async for msg in c: await handle(json.loads(msg.value))

@app.on_event("startup")
async def startup():
    global producer
    if not KAFKA: return
    from aiokafka import AIOKafkaProducer
    for _ in range(40):
        try:
            producer = AIOKafkaProducer(bootstrap_servers=KAFKA); await producer.start(); asyncio.create_task(consume()); return
        except Exception: await asyncio.sleep(3)

@app.post("/api/v1/telemetry")
async def telemetry(body: dict | list, x_api_key: str = Header(default="")):
    if API_KEY and x_api_key != API_KEY: raise HTTPException(401, "bad API key")
    items = body if isinstance(body, list) else [body]
    if producer: await producer.send_and_wait("nezora.telemetry", json.dumps(items).encode())
    else: await handle(items)
    return {"accepted": len(items), "via": "kafka" if producer else "direct"}

@app.get("/health")
def health(): return {"status": "ok", "samples": q("SELECT COUNT(*) FROM samples")[0][0], "clients": len(clients), "kafka": bool(producer), "ml": any(m.tcn for m in monitors.values()) or os.path.exists(os.path.join(MODELS, "tcn.onnx"))}
@app.get("/api/v1/latest")
def get_latest(): return latest
@app.get("/api/v1/history")
def history(limit: int = 500, motor: str | None = None):
    r = q("SELECT data FROM samples" + (" WHERE motor=?" if motor else "") + " ORDER BY id DESC LIMIT ?", ((motor,) if motor else ()) + (min(limit, 20000),))
    return [json.loads(x[0]) for x in reversed(r)]
@app.get("/api/v1/export.csv")
def export(limit: int = 20000):
    rows = history(limit); cols = sorted({k for r in rows for k in r}); b = io.StringIO(); w = csv.DictWriter(b, fieldnames=cols); w.writeheader(); w.writerows(rows)
    return PlainTextResponse(b.getvalue(), media_type="text/csv")
@app.get("/api/v1/alerts")
def alerts(limit: int = 100, open_only: bool = False):
    r = q("SELECT id,ts,motor,level,rule,msg,value,action,ack FROM alerts" + (" WHERE ack=0" if open_only else "") + " ORDER BY id DESC LIMIT ?", (limit,))
    return [dict(zip("id ts motor level rule msg value action ack".split(), x)) for x in r]
@app.post("/api/v1/alerts/{aid}/ack")
def ack(aid: int): ex("UPDATE alerts SET ack=1 WHERE id=?", (aid,)); return {"ok": True}
@app.post("/api/v1/assistant")
async def assistant(body: dict):
    ctx = json.dumps({k: {x: v[x] for x in ("status", "hs", "V", "U", "I", "dT", "dI", "life", "ml") if x in v} for k, v in latest.items()})
    return await kb.ask(str(body.get("question", "")), KB, ctx)
@app.get("/api/v1/report", response_class=HTMLResponse)
def report():
    r = history(20000); al = alerts(50); e = html.escape; mx = lambda k: max((x.get(k) or 0) for x in r) if r else 0
    L = latest.get("M-101", {}); rows = "".join(f"<tr><td>{time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(a['ts']))}</td><td>{['','WARNING','CRITICAL','TRIP'][a['level']]}</td><td>{e(a['msg'])}</td><td>{a['value']}</td><td>{e(a['action'])}</td></tr>" for a in al)
    return f"""<!doctype html><meta charset=utf-8><title>NEZORA report</title><style>body{{font:15px Arial;margin:30px;max-width:900px}}td,th{{border:1px solid #bbb;padding:4px 8px;text-align:left}}table{{border-collapse:collapse;width:100%}}</style>
<h1>NEZORA motor report</h1><p>Generated {time.strftime('%Y-%m-%d %H:%M:%S')} · Motor M-101 · {len(r)} samples in window</p>
<h2>Current state</h2><p>Status <b>{e(str(L.get('status','–')))}</b> · health {L.get('hs','–')}% · insulation life used {L.get('life','–')}% · winding Δ vs twin {L.get('dT','–')} K</p>
<h2>Maxima</h2><p>Winding {mx('Tw'):.1f} °C · bearing DE {mx('Tde'):.1f} °C · vibration {mx('vib'):.2f} mm/s · current {mx('Ia'):.1f} A</p>
<h2>Alerts (last 50)</h2><table><tr><th>Time<th>Level<th>Message<th>Value<th>Recommended action</tr>{rows}</table><p><button onclick=print()>Print / save as PDF</button></p>"""
@app.websocket("/ws")
async def ws_endpoint(ws: WebSocket):
    await ws.accept(); clients.add(ws)
    try:
        h = history(300)
        if h: await ws.send_text(json.dumps(h))
        while True: await ws.receive_text()
    except WebSocketDisconnect: pass
    finally: clients.discard(ws)
@app.get("/")
def index(): return FileResponse(os.path.join(STATIC, "index.html"))
app.mount("/", StaticFiles(directory=STATIC, html=True), name="static")
