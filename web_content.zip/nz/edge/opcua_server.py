"""OPC UA server that mimics the motor PLC (physics-based). Write FaultCode (0-7) and Severity (0-1) to inject faults.
Replace with your real PLC's OPC UA endpoint in production - the bridge only needs the node names."""
import asyncio
from asyncua import Server
from physics import Motor
FIELDS = ["Va", "Vb", "Vc", "Ia", "Ib", "Ic", "rpm", "Tw", "Tde", "Tnde", "vib", "Tamb"]
async def main():
    s = Server(); await s.init(); s.set_endpoint("opc.tcp://0.0.0.0:4840/nezora"); idx = await s.register_namespace("http://nezora.local")
    obj = await s.nodes.objects.add_object(idx, "Motor_M101"); v = {f: await obj.add_variable(idx, f, 0.0) for f in FIELDS}
    fc = await obj.add_variable(idx, "FaultCode", 0); sv = await obj.add_variable(idx, "Severity", 0.0); await fc.set_writable(); await sv.set_writable()
    m = Motor()
    async with s:
        while True:
            m.apply(int(await fc.read_value()), float(await sv.read_value())); x = m.sample()
            for f in FIELDS: await v[f].write_value(float(x[f]))
            await asyncio.sleep(1)
asyncio.run(main())
