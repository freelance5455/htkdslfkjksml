"""HTTP simulator (no OPC UA): python simulator.py --fault 1 --after 120   (fault codes: see physics.CLASSES)"""
import argparse, json, time, urllib.request
from physics import Motor
a = argparse.ArgumentParser(); a.add_argument("--url", default="http://localhost:8000"); a.add_argument("--key", default=""); a.add_argument("--fault", type=int, default=0); a.add_argument("--after", type=int, default=120); a.add_argument("--ramp", type=int, default=600); a = a.parse_args()
m = Motor(); t = 0
while True:
    m.apply(a.fault, min(1, max(0, (t - a.after) / a.ramp))); t += 1
    try: urllib.request.urlopen(urllib.request.Request(a.url + "/api/v1/telemetry", json.dumps(m.sample()).encode(), {"Content-Type": "application/json", "X-API-Key": a.key}), timeout=5)
    except Exception as e: print("send failed:", e)
    time.sleep(1)
