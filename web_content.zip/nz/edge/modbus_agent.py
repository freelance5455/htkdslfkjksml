"""Real motor over Modbus TCP. pip install pymodbus. EDIT REGISTERS from your devices' manuals (addresses below are placeholders)."""
import json, time, urllib.request
from pymodbus.client import ModbusTcpClient
HOST, PORT, URL, KEY = "192.168.1.50", 502, "http://localhost:8000", ""
REGISTERS = {"Va": (1, 100, .1), "Vb": (1, 101, .1), "Vc": (1, 102, .1), "Ia": (1, 110, .01), "Ib": (1, 111, .01), "Ic": (1, 112, .01),
             "rpm": (1, 120, 1), "Tw": (2, 0, .1), "Tde": (2, 1, .1), "Tnde": (2, 2, .1), "vib": (3, 0, .01)}
cli = ModbusTcpClient(HOST, port=PORT); t0 = time.time()
def read(u, a):
    try: r = cli.read_holding_registers(a, count=1, slave=u)
    except TypeError: r = cli.read_holding_registers(a, count=1, device_id=u)
    if r.isError(): raise IOError(str(r))
    v = r.registers[0]; return v - 65536 if v > 32767 else v
while True:
    s = {"motor": "M-101", "t": time.time() - t0}
    for k, (u, a, sc) in REGISTERS.items():
        try: s[k] = read(u, a) * sc
        except Exception as e: print("read", k, "failed:", e)
    try: urllib.request.urlopen(urllib.request.Request(URL + "/api/v1/telemetry", json.dumps(s).encode(), {"Content-Type": "application/json", "X-API-Key": KEY}), timeout=5)
    except Exception as e: print("send failed:", e)
    time.sleep(1)
