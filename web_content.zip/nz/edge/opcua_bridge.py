"""Reads the motor's OPC UA variables every second and forwards them to NEZORA (HTTP -> Kafka -> analysis)."""
import asyncio, json, os, time, urllib.request
from asyncua import Client
URL = os.getenv("OPCUA_URL", "opc.tcp://localhost:4840/nezora"); API = os.getenv("API_URL", "http://localhost:8000"); KEY = os.getenv("API_KEY", "")
def post(s):
    try: urllib.request.urlopen(urllib.request.Request(API + "/api/v1/telemetry", json.dumps(s).encode(), {"Content-Type": "application/json", "X-API-Key": KEY}), timeout=5)
    except Exception as e: print("send failed:", e)
async def main():
    while True:
        try:
            async with Client(URL) as c:
                idx = await c.get_namespace_index("http://nezora.local"); obj = await c.nodes.objects.get_child([f"{idx}:Motor_M101"]); nodes = {}
                for n in await obj.get_children(): nodes[(await n.read_browse_name()).Name] = n
                t0 = time.time()
                while True:
                    s = {"motor": "M-101", "t": time.time() - t0}
                    for k, n in nodes.items():
                        if k not in ("FaultCode", "Severity"): s[k] = float(await n.read_value())
                    await asyncio.to_thread(post, s); await asyncio.sleep(1)
        except Exception as e: print("opcua:", e); await asyncio.sleep(3)
asyncio.run(main())
