# NEZORA full platform — electric motor digital twin (adapted from the NEXORA thesis architecture)

## Run
1. (Optional but recommended) train the models:  `cd ml && pip install torch numpy onnx && python train.py`  -> writes backend/models/tcn.onnx and bilstm.onnx
   (without models the platform runs with the physics twin + rules; ML diagnosis simply stays off)
2. `docker compose up --build`  -> open http://localhost:8000
   Chain: motor PLC (OPC UA) -> bridge -> HTTP -> Kafka (Redpanda) -> backend (twin + rules + ONNX models) -> SQLite -> WebSocket -> dashboards.

Pages: `/` dashboard & physics simulation · `/twin3d.html` 3D twin · `/analytics.html` history + alert centre (acknowledge) · `/assistant.html` AI assistant · `/api/v1/report` printable report.

## Inject a test fault (stand-in PLC)
Use any OPC UA client (e.g. UaExpert) on opc.tcp://localhost:4840/nezora: write FaultCode (1 cooling, 2 bearing, 3 overload, 4 voltage sag, 5 unbalance, 6 winding short, 7 sensor) and Severity 0..1.
Or: `python edge/simulator.py --fault 1 --after 120`.

## Connect the real motor
Point the bridge at your PLC (`OPCUA_URL`, and map node names), or use `edge/modbus_agent.py` (edit REGISTERS), or POST JSON to `/api/v1/telemetry`.
Remove the `opcua-server` service. Set `API_KEY`, put HTTPS in front, and enter your nameplate values in the dashboard panel and in `physics.py` (NP).

## Honest limits
- ML models trained by `ml/train.py` use SYNTHETIC data from the physics model: they prove the pipeline and detect the injected fault types, not your real motor. Retrain with labelled real faults (replace `generate_dataset.make`).
- Thresholds are ISO 20816-3 / NEMA / class F rules of thumb; calibrate on ~2 weeks of normal data.
- Control/write-back to the PLC is deliberately NOT implemented (safety): the platform advises, a person acts. No protection function should depend on it.
- Storage is SQLite; swap for TimescaleDB/InfluxDB for large fleets. Auth is a single API key.
- Never-run-on-hardware: only the physics/analyzer/dataset code was executed in testing; the web pages, Docker, Kafka, OPC UA and training were not.
