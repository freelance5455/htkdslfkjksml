OfflineReels v10
================
This build is prepared for HTML-to-APK wrappers.

Important:
- The core application does not require a Service Worker to display its interface.
- Imported videos are intended to remain in local browser/app storage.
- The APK wrapper must package the HTML locally rather than loading a remote URL.
- In FreeWebsiteToApp, choose the uploaded/local website option and upload this ZIP/site
  rather than entering a public website URL.

If the wrapper still requires internet, that is a limitation of the wrapper configuration,
not the HTML project itself.
