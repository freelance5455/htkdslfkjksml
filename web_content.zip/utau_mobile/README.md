# Utau Pocket Studio — versão experimental

Um protótipo independente, pensado para telas Android, que roda no navegador e pode ser empacotado como aplicativo.

## O que funciona nesta versão

- Piano roll de três oitavas: tocar numa célula cria uma nota; tocar numa nota seleciona-a.
- Edição de letra/sílaba, tom MIDI, duração e posição.
- Configuração de BPM e grade.
- Importação básica de `.ust`, `.ustx` simples e `.mid/.midi`.
- Importação de áudio de acompanhamento compatível com o navegador.
- Carregamento local de voicebank `.zip/.uar` com `oto.ini` e amostras WAV/OGG/MP3.
- Prévia com sintetizador guia; tenta tocar amostras que correspondam exatamente ao alias do OTO.
- Exportação de `.ustx`, `.ust`, `.mid` e `.wav`.
- Salvamento automático básico do projeto no armazenamento local do navegador.

## Limitações importantes

Isto **não é uma versão completa do OpenUtau**. O renderizador vocal usa amostras do OTO quando o alias coincide e faz mudança de tom por velocidade de reprodução, o que altera também a duração. Quando não encontra uma amostra, toca uma nota-guia. Não há motor completo de resampling, fonemizadores por idioma, pitch bends avançados, múltiplas trilhas, VSQX, MusicXML ou fidelidade garantida de todos os USTX. Projetos USTX complexos podem não ser importados corretamente. O resultado WAV serve como prévia/guia e não equivale ao renderizador do OpenUtau.

## Testar no Android sem compilar

1. Baixe `index.html` e abra-o no Chrome ou em um navegador moderno que permita abrir arquivos locais. A edição e a prévia funcionam sem internet.
2. Para uma instalação como PWA com ícone e funcionamento offline, os arquivos `index.html`, `manifest.webmanifest`, `sw.js` e os ícones precisam ser colocados juntos em um site HTTPS. Depois, abra o site no Chrome e use **Adicionar à tela inicial / Instalar app**.

## Gerar um APK pelo Android Studio

O projeto WebView Android incluído na pasta `android-wrapper` é o invólucro nativo para gerar um APK. Abra essa pasta no Android Studio, deixe-o instalar as ferramentas SDK/Gradle solicitadas e escolha **Build > Build APK(s)**. O APK não foi compilado neste ambiente porque não há Android SDK/Gradle instalados e este ambiente não conseguiu baixar as ferramentas de compilação.

## Formatos

- UST é exportado como uma faixa monofônica simples.
- USTX é gerado com a estrutura de notas básica documentada pelo OpenUtau; recursos avançados podem ser omitidos.
- MIDI exporta as notas como uma faixa MIDI monofônica.

Os voicebanks são carregados localmente. Use bancos para os quais você tenha autorização.
