# Compilar o APK

1. Abra **a pasta `android-wrapper`** no Android Studio.
2. Use JDK 17 e aceite instalar Android SDK Platform 35 / Build Tools quando solicitado.
3. Aguarde a sincronização do Gradle.
4. No menu **Build**, selecione **Build APK(s)**. O APK de debug aparecerá em `app/build/outputs/apk/debug/app-debug.apk`.

Este diretório contém o código-fonte do invólucro Android. O APK ainda não foi compilado neste ambiente porque o Android SDK e o Gradle não estavam disponíveis e o download das ferramentas foi bloqueado por ausência de acesso DNS à fonte de download.
