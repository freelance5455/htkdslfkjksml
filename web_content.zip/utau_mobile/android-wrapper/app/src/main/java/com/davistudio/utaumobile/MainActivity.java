package com.davistudio.utaumobile;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import java.io.OutputStream;
import java.io.IOException;

public class MainActivity extends Activity {
    private static final int FILE_OPEN_REQUEST = 4101;
    private static final int FILE_SAVE_REQUEST = 4102;
    private WebView webView;
    private ValueCallback<Uri[]> uploadCallback;
    private String pendingBase64;
    private String pendingMime;
    private String pendingFilename;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(0xFF11131C);
        getWindow().setNavigationBarColor(0xFF10121A);
        webView = new WebView(this);
        webView.setBackgroundColor(0xFF10121A);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        webView.addJavascriptInterface(new FileBridge(), "Android");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> filePathCallback, FileChooserParams params) {
                if (uploadCallback != null) uploadCallback.onReceiveValue(null);
                uploadCallback = filePathCallback;
                Intent intent = params.createIntent();
                if (params.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE) {
                    intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                }
                try {
                    startActivityForResult(intent, FILE_OPEN_REQUEST);
                    return true;
                } catch (Exception ex) {
                    uploadCallback = null;
                    Toast.makeText(MainActivity.this, "Não foi possível abrir o seletor de arquivos.", Toast.LENGTH_LONG).show();
                    return false;
                }
            }
        });
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private class FileBridge {
        @JavascriptInterface public void saveFile(String base64, String mime, String filename) {
            runOnUiThread(() -> {
                pendingBase64 = base64;
                pendingMime = (mime == null || mime.trim().isEmpty()) ? "application/octet-stream" : mime.split(";")[0];
                pendingFilename = (filename == null || filename.trim().isEmpty()) ? "utau-export.bin" : filename.replaceAll("[\\\\/:*?\"<>|]", "_");
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType(pendingMime.contains("/") ? pendingMime : "application/octet-stream");
                intent.putExtra(Intent.EXTRA_TITLE, pendingFilename);
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                startActivityForResult(intent, FILE_SAVE_REQUEST);
            });
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_OPEN_REQUEST) {
            if (uploadCallback != null) {
                Uri[] results = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
                uploadCallback.onReceiveValue(results);
                uploadCallback = null;
            }
            return;
        }
        if (requestCode == FILE_SAVE_REQUEST) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null && pendingBase64 != null) {
                try (OutputStream out = getContentResolver().openOutputStream(data.getData())) {
                    byte[] bytes = Base64.decode(pendingBase64, Base64.DEFAULT);
                    if (out != null) out.write(bytes);
                    Toast.makeText(this, "Arquivo salvo.", Toast.LENGTH_SHORT).show();
                } catch (IOException | IllegalArgumentException ex) {
                    Toast.makeText(this, "Falha ao salvar o arquivo.", Toast.LENGTH_LONG).show();
                }
            }
            pendingBase64 = null;
            pendingMime = null;
            pendingFilename = null;
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if (webView != null) {
            webView.removeJavascriptInterface("Android");
            webView.destroy();
        }
        super.onDestroy();
    }
}
