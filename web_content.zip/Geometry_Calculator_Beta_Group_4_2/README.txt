GEOMETRY CALCULATOR - BETA GROUP 4.2
===================================

ISI FOLDER
- index.html : struktur halaman
- style.css  : desain dan tampilan
- app.js     : kalkulator, menu, dan penyimpanan sesi

FITUR
- Setiap menu dibuka sebagai scene/halaman penuh.
- Kolom ukuran memiliki label satuan cm yang permanen dan tidak bisa diedit.
- Hasil luas dan riwayat menggunakan satuan cm².
- Riwayat memakai sessionStorage dan bertahan saat refresh pada tab/sesi yang sama.

CARA MENJALANKAN DI ANDROID
1. Ekstrak ZIP ke sebuah folder.
2. Buka index.html menggunakan Chrome/browser.
3. Jika memakai editor kode, pastikan fitur Preview menjalankan JavaScript.

SATUAN
Semua ukuran masukan dianggap sentimeter (cm).
Hasil luas ditampilkan dalam sentimeter persegi (cm²).
