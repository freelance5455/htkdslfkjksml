"use strict";

    const shapes = {
      "1": { name: "Persegi", symbol: "□", formula: "Sisi × Sisi", fields: ["Sisi"], calculate: ([s]) => s * s },
      "2": { name: "Persegi Panjang", symbol: "▭", formula: "Panjang × Lebar", fields: ["Panjang", "Lebar"], calculate: ([p, l]) => p * l },
      "3": { name: "Segitiga", symbol: "△", formula: "½ × Alas × Tinggi", fields: ["Alas", "Tinggi"], calculate: ([a, t]) => 0.5 * a * t },
      "4": { name: "Lingkaran", symbol: "○", formula: "3,14 × r × r", fields: ["Jari-jari"], calculate: ([r]) => 3.14 * r * r },
      "5": { name: "Jajar Genjang", symbol: "▱", formula: "Alas × Tinggi", fields: ["Alas", "Tinggi"], calculate: ([a, t]) => a * t },
      "6": { name: "Trapesium", symbol: "⏢", formula: "½ × (A + B) × Tinggi", fields: ["Sisi sejajar A", "Sisi sejajar B", "Tinggi"], calculate: ([a, b, t]) => 0.5 * (a + b) * t },
      "7": { name: "Belah Ketupat", symbol: "◇", formula: "½ × D1 × D2", fields: ["Diagonal 1", "Diagonal 2"], calculate: ([d1, d2]) => 0.5 * d1 * d2 },
      "8": { name: "Layang-layang", symbol: "◈", formula: "½ × D1 × D2", fields: ["Diagonal 1", "Diagonal 2"], calculate: ([d1, d2]) => 0.5 * d1 * d2 }
    };

    const layer = document.getElementById("layer");
    const layerIcon = document.getElementById("layerIcon");
    const layerTitle = document.getElementById("layerTitle");
    const layerDescription = document.getElementById("layerDescription");
    const layerContent = document.getElementById("layerContent");
    const backButton = document.getElementById("backButton");
    const SESSION_KEY = "geometryCalculatorHistory_v1";
    let historyData = loadHistory();
    let activeShape = null;

    function loadHistory() {
      try {
        const saved = sessionStorage.getItem(SESSION_KEY);
        const parsed = saved ? JSON.parse(saved) : [];
        return Array.isArray(parsed) ? parsed : [];
      } catch (error) {
        console.warn("Penyimpanan sesi tidak tersedia:", error);
        return [];
      }
    }

    function saveHistory() {
      try {
        sessionStorage.setItem(SESSION_KEY, JSON.stringify(historyData));
      } catch (error) {
        showStorageWarning();
        console.warn("Riwayat tidak dapat disimpan:", error);
      }
    }

    function showStorageWarning() {
      const message = document.getElementById("messageBox");
      if (message) {
        message.textContent = "Browser membatasi penyimpanan sesi. Coba buka file melalui Chrome.";
        message.className = "message show info";
      }
    }
    let lastFocusedElement = null;

    function formatNumber(value) {
      return new Intl.NumberFormat("id-ID", {
        maximumFractionDigits: 8
      }).format(value);
    }

    function showLayer({ icon = "∑", title, description = "", content = "" }) {
      lastFocusedElement = document.activeElement;
      layerIcon.textContent = icon;
      layerTitle.textContent = title;
      layerDescription.textContent = description;
      layerContent.innerHTML = content;
      layer.classList.add("show");
      document.body.style.overflow = "hidden";
      backButton.focus();
    }

    function closeLayer() {
      layer.classList.remove("show");
      document.body.style.overflow = "";
      activeShape = null;
      if (lastFocusedElement && typeof lastFocusedElement.focus === "function") {
        lastFocusedElement.focus();
      }
    }

    function showMessage(text, type = "error") {
      const box = document.getElementById("messageBox");
      if (!box) return;
      box.textContent = text;
      box.className = "message show " + type;
    }

    function openCalculator(key) {
      const shape = shapes[key];
      if (!shape) return;
      activeShape = key;

      const fields = shape.fields.map((field, index) => `
        <div class="field">
          <label for="measure-${index}">${field}</label>
          <div class="input-unit">
            <input id="measure-${index}" type="text" inputmode="decimal"
              autocomplete="off" placeholder="Masukkan ${field.toLowerCase()}">
            <span class="unit-suffix" aria-label="satuan sentimeter">cm</span>
          </div>
        </div>
      `).join("");

      showLayer({
        icon: shape.symbol,
        title: "Perhitungan " + shape.name,
        description: "Masukkan ukuran untuk menghitung luas bangun datar.",
        content: `
          <div class="formula">Rumus: ${shape.formula}</div>
          <form id="calcForm" novalidate>
            ${fields}
            <div id="messageBox" class="message" role="alert"></div>
            <div class="actions">
              <button class="btn btn-primary" type="submit">Hitung Luas</button>
              <button class="btn btn-secondary" type="button" id="resetButton">Reset</button>
            </div>
          </form>
          <div id="resultCard" class="result-card" aria-live="polite">
            <div class="result-label">HASIL PERHITUNGAN</div>
            <div class="result-value" id="resultValue"></div>
            <div class="result-detail" id="resultDetail"></div>
          </div>
        `
      });

      document.getElementById("calcForm").addEventListener("submit", calculateArea);
      document.getElementById("resetButton").addEventListener("click", () => {
        document.getElementById("calcForm").reset();
        document.getElementById("messageBox").className = "message";
        document.getElementById("resultCard").classList.remove("show");
      });
      // Jangan otomatis fokus ke input: keyboard HP tidak langsung terbuka.
    }

    function calculateArea(event) {
      event.preventDefault();
      const shape = shapes[activeShape];
      const values = [];

      for (let i = 0; i < shape.fields.length; i++) {
        const input = document.getElementById("measure-" + i);
        const raw = input.value.trim().replace(",", ".");
        if (raw === "") {
          showMessage("Input " + shape.fields[i] + " tidak boleh kosong.");
          input.focus();
          return;
        }
        // Hanya menerima angka positif, termasuk desimal dengan titik/koma.
        if (!/^(?:\d+(?:\.\d+)?|\.\d+)$/.test(raw)) {
          showMessage("Input " + shape.fields[i] + " tidak valid. Gunakan angka, contoh: 5 atau 2,5.");
          input.focus();
          return;
        }
        const number = Number(raw);
        if (!Number.isFinite(number)) {
          showMessage("Angka terlalu besar atau tidak valid.");
          input.focus();
          return;
        }
        if (number <= 0) {
          showMessage("Nilai " + shape.fields[i] + " harus lebih besar dari nol.");
          input.focus();
          return;
        }
        values.push(number);
      }

      const result = shape.calculate(values);
      if (!Number.isFinite(result)) {
        showMessage("Hasil terlalu besar untuk ditampilkan.");
        return;
      }

      const measurementText = shape.fields.map((field, i) =>
        field + ": " + formatNumber(values[i]) + " cm"
      ).join(" · ");

      document.getElementById("resultValue").textContent =
        formatNumber(result) + " cm²";
      document.getElementById("resultDetail").textContent =
        measurementText + " | Rumus: " + shape.formula;
      document.getElementById("resultCard").classList.add("show");

      historyData.unshift({
        time: new Date().toLocaleString("id-ID"),
        name: shape.name,
        measurements: shape.fields.map((field, i) => [field, values[i]]),
        formula: shape.formula,
        result
      });
      saveHistory();

      const message = document.getElementById("messageBox");
      message.textContent = "Perhitungan berhasil. Hasil otomatis disimpan ke riwayat.";
      message.className = "message show success";
    }

    function openHistory() {
      let content = "";
      if (historyData.length === 0) {
        content = '<div class="message show info">Belum ada perhitungan. Silakan hitung salah satu bangun datar terlebih dahulu.</div>';
      } else {
        content = historyData.map((item, index) => `
          <article class="history-item">
            <strong>DATA PERHITUNGAN #${index + 1} · ${escapeHTML(item.name)}</strong><br>
            <span>Waktu: ${escapeHTML(item.time)}</span><br>
            ${item.measurements.map(([name, value]) =>
              `<span>${escapeHTML(name)}: ${formatNumber(value)} cm</span><br>`
            ).join("")}
            <span>Rumus: ${escapeHTML(item.formula)}</span><br>
            <span class="history-result">Hasil: ${formatNumber(item.result)} cm²</span>
          </article>
        `).join("");
      }

      showLayer({
        icon: "≡",
        title: "Riwayat Perhitungan",
        description: "Riwayat tersimpan selama sesi tab browser ini berlangsung.",
        content
      });
    }

    function openGuide() {
      showLayer({
        icon: "ⓘ",
        title: "Panduan Penggunaan",
        description: "Ikuti langkah sederhana berikut untuk menggunakan kalkulator.",
        content: `
          <ol class="guide-list">
            <li>Pilih salah satu bangun datar pada menu utama.</li>
            <li>Masukkan ukuran sesuai kolom yang tersedia.</li>
            <li>Gunakan angka positif, lebih besar dari nol.</li>
            <li>Angka desimal boleh menggunakan titik atau koma, misalnya 2,5.</li>
            <li>Tekan tombol Hitung Luas untuk melihat hasil.</li>
            <li>Jika input salah, perbaiki kolom yang ditandai lalu hitung kembali.</li>
            <li>Hasil perhitungan otomatis tersimpan di menu Riwayat.</li>
            <li>Gunakan menu Hapus Riwayat untuk mengosongkan daftar.</li>
          </ol>
          <div class="formula">Catatan: Semua ukuran menggunakan sentimeter (cm). Hasil luas ditampilkan dalam sentimeter persegi (cm²).</div>
        `
      });
    }

    function openClearHistory() {
      if (historyData.length === 0) {
        showLayer({
          icon: "⌫",
          title: "Hapus Riwayat",
          description: "Belum ada data yang tersimpan.",
          content: '<div class="message show info">Riwayat masih kosong, tidak ada yang perlu dihapus.</div>'
        });
        return;
      }

      showLayer({
        icon: "⌫",
        title: "Hapus Riwayat",
        description: "Pastikan kembali sebelum menghapus seluruh data.",
        content: `
          <div class="confirm-box">
            Kamu akan menghapus <strong>${historyData.length} data perhitungan</strong> dari riwayat.
            Tindakan ini tidak dapat dibatalkan.
          </div>
          <div class="actions">
            <button class="btn btn-danger" id="confirmClear" type="button">Ya, Hapus Semua</button>
            <button class="btn btn-secondary" id="cancelClear" type="button">Batalkan</button>
          </div>
        `
      });

      document.getElementById("confirmClear").addEventListener("click", () => {
        historyData = [];
        saveHistory();
        showLayer({
          icon: "✓",
          title: "Riwayat Dihapus",
          description: "Penghapusan berhasil.",
          content: '<div class="message show success">Seluruh riwayat perhitungan berhasil dihapus.</div>'
        });
      });
      document.getElementById("cancelClear").addEventListener("click", openHistory);
    }

    function openExit() {
      showLayer({
        icon: "×",
        title: "Keluar Program",
        description: "Terima kasih telah menggunakan Geometry Calculator.",
        content: `
          <div class="confirm-box">
            Jumlah perhitungan pada sesi ini: <strong>${historyData.length}</strong><br>
            Kamu dapat menutup tab browser ini untuk mengakhiri program.
          </div>
          <div class="actions">
            <button class="btn btn-primary" id="finishButton" type="button">Selesai</button>
            <button class="btn btn-secondary" id="stayButton" type="button">Kembali</button>
          </div>
        `
      });
      document.getElementById("finishButton").addEventListener("click", () => {
        showLayer({
          icon: "✓",
          title: "Terima Kasih!",
          description: "Geometry Calculator · Beta Group 4.2",
          content: `<div class="message show success">Program selesai. Kamu boleh menutup tab browser ini.</div>`
        });
      });
      document.getElementById("stayButton").addEventListener("click", closeLayer);
    }

    function escapeHTML(value) {
      return String(value).replace(/[&<>"']/g, char => ({
        "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
      })[char]);
    }

    // Satu event listener untuk semua menu: lebih konsisten pada browser mobile.
    document.addEventListener("click", event => {
      const shapeButton = event.target.closest("[data-shape]");
      if (shapeButton) {
        event.preventDefault();
        openCalculator(shapeButton.dataset.shape);
        return;
      }

      const actionButton = event.target.closest("[data-action]");
      if (!actionButton) return;
      event.preventDefault();
      const action = actionButton.dataset.action;
      if (action === "history") openHistory();
      else if (action === "guide") openGuide();
      else if (action === "clear") openClearHistory();
      else if (action === "exit") openExit();
    });

    backButton.addEventListener("click", closeLayer);

    // Klik area gelap di luar panel juga menutup layer.
    layer.addEventListener("click", event => {
      if (event.target === layer) closeLayer();
    });

    // Tombol Escape menutup layer aktif.
    document.addEventListener("keydown", event => {
      if (event.key === "Escape" && layer.classList.contains("show")) closeLayer();
    });
