# QuickMake Android-friendly prototype

This is a working, mobile-first web prototype for previewing the QuickMake app flow.

## Open it
- Open `index.html` in a browser to preview it on a computer.
- To install it as a home-screen web app on Android, the files must be hosted over HTTPS; open the hosted URL in Chrome and choose **Add to Home screen** / **Install app** when available.
- This ZIP is not an APK and is not ready for Google Play publication.

## Prototype screens
Welcome, registration, login, home dashboard, application details, application preview, local demo applications, payment-flow preview, simulated confirmation, profile, and support.

## Safety and limitations
- No real lending, credit assessment, identity verification, payment collection, SMS, or disbursement is implemented.
- Any example amounts and statuses are illustrative only.
- The demo does not send entered data to a server; application records are kept in the current page session.
- Do not enter real PAN, bank details, passwords, or sensitive personal information.
- Before any public loan service, arrange a legitimate lending partner as applicable, verify all regulatory and Google Play requirements, publish accurate fee/refund terms, and add production-grade security, privacy disclosures, support, and backend systems.
