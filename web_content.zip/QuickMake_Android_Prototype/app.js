const screens=[...document.querySelectorAll('.screen')];
const bottomNav=document.getElementById('bottomNav');
const toastEl=document.getElementById('toast');
let toastTimer, user={name:'Demo user',email:'',mobile:''}, saved=[];
function toast(msg){toastEl.textContent=msg;toastEl.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>toastEl.classList.remove('show'),2600)}
function go(id){screens.forEach(s=>s.classList.toggle('active',s.id===id));bottomNav.hidden=!['home','applications','payments','profile'].includes(id);window.scrollTo({top:0,behavior:'smooth'});if(id==='applications')renderApps();if(id==='profile'){document.getElementById('profileName').textContent=user.name;document.getElementById('profileEmail').textContent=user.email||'No email saved'}}
document.querySelectorAll('[data-go]').forEach(b=>b.addEventListener('click',()=>go(b.dataset.go)));
document.getElementById('registerBtn').addEventListener('click',()=>{
 const name=document.getElementById('regName').value.trim(),mobile=document.getElementById('regMobile').value.trim(),email=document.getElementById('regEmail').value.trim(),password=document.getElementById('regPassword').value;
 if(!name||!/^\d{10}$/.test(mobile)||!email.includes('@')||password.length<8){toast('Enter a name, 10-digit demo number, valid email and 8+ character password.');return}
 user={name,email,mobile};document.getElementById('helloName').textContent='Hello, '+name.split(' ')[0]+' 👋';toast('Demo account created in this session.');go('home');
});
document.getElementById('loginBtn').addEventListener('click',()=>{const mobile=document.getElementById('loginMobile').value.trim();if(!/^\d{10}$/.test(mobile)){toast('Enter a 10-digit demo mobile number.');return}user.mobile=mobile;toast('Demo login successful.');go('home')});
document.getElementById('submitApplication').addEventListener('click',()=>{
 const income=Number(document.getElementById('income').value),amount=Number(document.getElementById('amount').value);
 document.getElementById('previewAmount').textContent=money(amount);document.getElementById('previewEmployment').textContent=document.getElementById('employment').value;document.getElementById('previewIncome').textContent=income>0?money(income):'Not provided';go('eligibility');
});
document.getElementById('saveApplication').addEventListener('click',()=>{
 const app={id:'QM-DEMO-'+String(Date.now()).slice(-6),amount:Number(document.getElementById('amount').value),employment:document.getElementById('employment').value,date:new Date().toLocaleDateString('en-IN'),status:'Draft preview'};
 saved.unshift(app);toast('Demo record saved in this session only.');go('applications');
});
function money(n){return '₹'+Number(n).toLocaleString('en-IN')}
function renderApps(){const el=document.getElementById('applicationList');if(!saved.length){el.className='empty card';el.textContent='No demo applications saved yet.';return}el.className='';el.innerHTML=saved.map(a=>`<div class="card"><div class="summary-row"><span>Reference</span><b>${a.id}</b></div><div class="summary-row"><span>Requested amount</span><b>${money(a.amount)}</b></div><div class="summary-row"><span>Submitted</span><b>${a.date}</b></div><div class="summary-row"><span>Status</span><b class="green">${a.status}</b></div></div>`).join('')}
document.getElementById('demoPayment').addEventListener('click',()=>go('paymentSuccess'));
document.getElementById('logoutBtn').addEventListener('click',()=>{user={name:'Demo user',email:'',mobile:''};toast('Logged out of demo.');go('welcome')});
if('serviceWorker' in navigator && location.protocol.startsWith('http')) navigator.serviceWorker.register('sw.js').catch(()=>{});
