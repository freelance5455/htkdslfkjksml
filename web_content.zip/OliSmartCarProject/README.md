# Oli Smart Car – Android Studio Projekt

Eigenständige Android-App für den Škoda Enyaq iV (2022), dunkles Design mit blauen Akzenten.

## Enthalten
- Native Android-Hülle mit WebView-Oberfläche (`app/src/main/assets/index.html`)
- Eingabe von FIN und MyŠkoda API-Key in der App
- API-Key-Verschlüsselung mit Android Keystore (AES-GCM)
- Abruf des offiziellen Fahrzeug-Endpunkts
- Lade- und Klimatisierungs-Steueroberfläche
- Lokaler Akku-Verlauf (max. 120 Messpunkte)
- WorkManager-Hintergrundabruf alle 30 Minuten
- Lokale Benachrichtigung beim Erreichen des gespeicherten Ladeziels
- Android-Startbildschirm-Widget
- Kartenübergabe an eine installierte Karten-App, falls die API Parkkoordinaten liefert

## Bauen
1. Android Studio installieren (aktueller stabiler Stand).
2. `OliSmartCarProject` als Projekt öffnen.
3. Gradle-Synchronisierung zulassen. Android SDK Platform 35 installieren, falls Android Studio danach fragt.
4. Über **Build > Build Bundle(s) / APK(s) > Build APK(s)** die APK bauen.
5. Die APK liegt danach unter `app/build/outputs/apk/debug/app-debug.apk`.

## Einrichtung in der App
1. In der MyŠkoda-App einen API-Key für den Enyaq erzeugen.
2. FIN (17 Zeichen) und API-Key in Oli Smart Car eingeben und speichern.
3. Auf „Aktualisieren“ tippen.
4. Android-Berechtigung für Benachrichtigungen erlauben.
5. Widget über den Android-Startbildschirm > Widgets > Oli Smart Car hinzufügen.

## Wichtige API-Hinweise
- Basis: `https://public.api.connect.skoda-auto.cz/api/v1`
- Authentifizierung: Header `X-API-Key`.
- Fahrzeugabruf: `GET /vehicles/{VIN}`.
- Škoda dokumentiert derzeit ein Limit von 20 Requests pro Stunde und VIN. Die Hintergrundabfrage ist daher auf 30 Minuten eingestellt; manuelle Aktualisierungen zählen ebenfalls.
- API-Keys laufen ab. Bei HTTP 401 muss in MyŠkoda ein neuer Key erstellt werden.
- Welche Felder und Funktionen verfügbar sind, hängt vom Fahrzeug und den aktiven Škoda-Diensten ab.
- Die offiziellen API-Dokumente sind unter https://public.api.connect.skoda-auto.cz/docs zu finden.

## Ehrlicher Entwicklungsstand / Einschränkung
In der bereitgestellten Arbeitsumgebung ist kein Android SDK, kein Android Build-Tools-Paket und kein Gradle installiert; außerdem ist kein Download der Build-Tools möglich. Deshalb konnte hier **keine signierte/installierbare APK kompiliert oder auf einem Gerät getestet werden**. Dieses Paket ist das vollständige Android-Studio-Quellprojekt, nicht die APK.

Die GET-Verbindung zum offiziellen Fahrzeug-Endpunkt ist implementiert. Die Schreibbefehle für Klimatisierung und Ladeziel sind an die dokumentierte Ressourcenstruktur angelehnt, müssen vor einer realen Fahrzeugsteuerung gegen die aktuell veröffentlichte Swagger-API und anschließend mit dem eigenen Enyaq geprüft werden. Die App zeigt API-Fehler an und behauptet nicht, dass ein Befehl erfolgreich ausgeführt wurde, wenn die API ihn ablehnt.

Die Hintergrundaufgabe ist eine lokale Abfrage und keine echte Hersteller-Push-Verbindung. Android kann Hintergrundausführungen abhängig von Energiesparregeln verzögern.
