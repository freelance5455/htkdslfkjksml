package de.olismartcar;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

final class CarApi {
    static final String BASE = "https://public.api.connect.skoda-auto.cz/api/v1";
    static String request(Context c, String path, String method, JSONObject body) throws Exception {
        SecureStore secure = new SecureStore(c);
        String key = secure.get("api_key");
        String vin = c.getSharedPreferences("car", Context.MODE_PRIVATE).getString("vin", "");
        if (key.isEmpty() || vin.isEmpty()) throw new Exception("Bitte zuerst API-Key und FIN in den Einstellungen speichern.");
        if (!path.startsWith("/")) path = "/" + path;
        URL url = new URL(BASE + "/vehicles/" + vin + (path.equals("/") ? "" : path));
        HttpURLConnection con = (HttpURLConnection) url.openConnection();
        con.setRequestMethod(method);
        con.setConnectTimeout(15000); con.setReadTimeout(20000);
        con.setRequestProperty("X-API-Key", key);
        con.setRequestProperty("Accept", "application/json");
        con.setRequestProperty("Content-Type", "application/json");
        if (body != null && (method.equals("POST") || method.equals("PUT"))) {
            con.setDoOutput(true);
            try (OutputStream os = con.getOutputStream()) { os.write(body.toString().getBytes(StandardCharsets.UTF_8)); }
        }
        int code = con.getResponseCode();
        InputStream stream = code >= 200 && code < 400 ? con.getInputStream() : con.getErrorStream();
        StringBuilder out = new StringBuilder();
        if (stream != null) try (BufferedReader br = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
            String line; while ((line = br.readLine()) != null) out.append(line);
        }
        String response = out.toString();
        if (code < 200 || code >= 300) {
            String detail = response;
            try { detail = new JSONObject(response).optString("detail", new JSONObject(response).optString("title", response)); } catch (Exception ignored) {}
            if (code == 401) detail = "API-Key abgelaufen oder ungültig. Bitte in MyŠkoda erneuern.";
            if (code == 403) detail = "API-Key ist für diese FIN/Funktion nicht freigegeben.";
            if (code == 429) detail = "Limit erreicht oder Fahrzeug nimmt den Befehl gerade nicht an. Bitte später erneut versuchen.";
            throw new Exception("Škoda API (" + code + "): " + detail);
        }
        String expiry = con.getHeaderField("X-API-Key-Expires-At");
        if (expiry != null) c.getSharedPreferences("car", Context.MODE_PRIVATE).edit().putString("key_expiry", expiry).apply();
        String remaining = con.getHeaderField("RateLimit-Remaining");
        if (remaining != null) c.getSharedPreferences("car", Context.MODE_PRIVATE).edit().putString("rate_remaining", remaining).apply();
        return response.isEmpty() ? "{}" : response;
    }

    static String vehicle(Context c) throws Exception { return request(c, "", "GET", null); }
    static String command(Context c, String action, JSONObject body) throws Exception {
        // Command routes follow the official MyŠkoda API resource structure.
        return request(c, action, "POST", body == null ? new JSONObject() : body);
    }
}
