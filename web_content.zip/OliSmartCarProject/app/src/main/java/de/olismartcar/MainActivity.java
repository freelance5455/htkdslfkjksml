package de.olismartcar;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;
import java.util.concurrent.TimeUnit;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private WebView web;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(0xFF070D18); getWindow().setNavigationBarColor(0xFF070D18);
        web = new WebView(this); setContentView(web);
        web.getSettings().setJavaScriptEnabled(true); web.getSettings().setDomStorageEnabled(true);
        web.setWebViewClient(new WebViewClient()); web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new Bridge(), "Android");
        web.loadUrl("file:///android_asset/index.html");
        PeriodicWorkRequest work = new PeriodicWorkRequest.Builder(CarSyncWorker.class, 30, TimeUnit.MINUTES).build();
        WorkManager.getInstance(this).enqueueUniquePeriodicWork("oli_car_sync", ExistingPeriodicWorkPolicy.UPDATE, work);
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.POST_NOTIFICATIONS}, 77);
    }
    private void js(String fn, String value) {
        String safe = JSONObject.quote(value == null ? "" : value);
        runOnUiThread(() -> web.evaluateJavascript("window." + fn + " && window." + fn + "(" + safe + ")", null));
    }
    class Bridge {
        @JavascriptInterface public void saveConfig(String vin, String key) {
            new Thread(() -> {
                try {
                    if (vin == null || !vin.matches("[A-HJ-NPR-Z0-9]{17}")) throw new Exception("Die FIN muss aus genau 17 Zeichen bestehen.");
                    new SecureStore(MainActivity.this).put("api_key", key.trim());
                    getSharedPreferences("car", MODE_PRIVATE).edit().putString("vin", vin.trim().toUpperCase()).apply();
                    js("onStatus", "Einstellungen sicher gespeichert.");
                } catch (Exception e) { js("onStatus", e.getMessage()); }
            }).start();
        }
        @JavascriptInterface public void hasConfig() {
            boolean ready = !new SecureStore(MainActivity.this).get("api_key").isEmpty() && !getSharedPreferences("car", MODE_PRIVATE).getString("vin", "").isEmpty();
            js("onConfig", ready ? "yes" : "no");
        }
        @JavascriptInterface public void refresh() {
            new Thread(() -> { try { String data = CarApi.vehicle(MainActivity.this); saveHistory(data); js("onVehicleData", data); js("onStatus", "Fahrzeugdaten aktualisiert."); }
                catch (Exception e) { js("onStatus", e.getMessage()); } }).start();
        }
        @JavascriptInterface public void command(String action, String value) {
            new Thread(() -> { try {
                JSONObject body = new JSONObject();
                if (action.equals("air-conditioning/start")) body.put("targetTemperature", value == null || value.isEmpty() ? 21 : Double.parseDouble(value));
                if (action.equals("charging/target-state-of-charge")) body.put("targetStateOfCharge", Integer.parseInt(value));
                String result = CarApi.command(MainActivity.this, action, body);
                js("onStatus", "Befehl übermittelt. " + (result.equals("{}") ? "" : result));
            } catch (Exception e) { js("onStatus", e.getMessage()); } }).start();
        }
        @JavascriptInterface public void openMap(double lat, double lon) {
            try { Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("geo:" + lat + "," + lon + "?q=" + lat + "," + lon + "(Škoda Enyaq)")); startActivity(i); }
            catch (Exception e) { js("onStatus", "Karte konnte nicht geöffnet werden."); }
        }
        @JavascriptInterface public void loadHistory() {
            String history = getSharedPreferences("car", MODE_PRIVATE).getString("history", "[]");
            js("onHistory", history);
        }
        @JavascriptInterface public void setChargeTarget(int target) { getSharedPreferences("car", MODE_PRIVATE).edit().putInt("charge_target", target).apply(); }
    }
    private void saveHistory(String data) {
        try {
            JSONObject root = new JSONObject(data); JSONObject v = root.optJSONObject("vehicle"); if (v == null) return;
            JSONObject charging = v.optJSONObject("charging"); if (charging == null) return;
            int soc = findNumber(charging, new String[]{"stateOfChargeInPercent", "currentStateOfChargeInPercent", "batteryStateOfChargeInPercent", "currentSoC"});
            if (soc >= 0) {
                String old = getSharedPreferences("car", MODE_PRIVATE).getString("history", "[]"); org.json.JSONArray a = new org.json.JSONArray(old);
                a.put(new JSONObject().put("t", System.currentTimeMillis()).put("soc", soc)); while (a.length() > 120) a.remove(0);
                getSharedPreferences("car", MODE_PRIVATE).edit().putString("history", a.toString()).putInt("last_soc", soc).apply();
                CarWidgetProvider.update(this, soc, findNumber(charging, new String[]{"remainingRangeInKm", "rangeInKm", "electricRangeInKm"}));
            }
        } catch (Exception ignored) {}
    }
    static int findNumber(JSONObject o, String[] keys) {
        for (String k : keys) { Object x = o.opt(k); if (x instanceof Number) return ((Number)x).intValue(); }
        java.util.Iterator<String> it = o.keys(); while (it.hasNext()) { Object x = o.opt(it.next()); if (x instanceof JSONObject) { int n = findNumber((JSONObject)x, keys); if (n >= 0) return n; } }
        return -1;
    }
    @Override public void onBackPressed() { if (web.canGoBack()) web.goBack(); else super.onBackPressed(); }
}
