package de.olismartcar;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.os.Build;
import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;
import androidx.work.Worker;
import androidx.work.WorkerParameters;
import org.json.JSONObject;

public class CarSyncWorker extends Worker {
    private static final String CHANNEL = "oli_car_events";
    public CarSyncWorker(@NonNull Context c, @NonNull WorkerParameters p) { super(c, p); }
    @NonNull @Override public Result doWork() {
        Context c = getApplicationContext();
        try {
            if (new SecureStore(c).get("api_key").isEmpty()) return Result.success();
            String json = CarApi.vehicle(c); JSONObject root = new JSONObject(json); JSONObject vehicle = root.optJSONObject("vehicle");
            if (vehicle == null) return Result.success();
            JSONObject charging = vehicle.optJSONObject("charging");
            if (charging != null) {
                int soc = MainActivity.findNumber(charging, new String[]{"stateOfChargeInPercent", "currentStateOfChargeInPercent", "batteryStateOfChargeInPercent", "currentSoC"});
                int range = MainActivity.findNumber(charging, new String[]{"remainingRangeInKm", "rangeInKm", "electricRangeInKm"});
                int old = c.getSharedPreferences("car", Context.MODE_PRIVATE).getInt("last_soc", -1);
                c.getSharedPreferences("car", Context.MODE_PRIVATE).edit().putInt("last_soc", soc).apply();
                CarWidgetProvider.update(c, soc, range);
                int target = c.getSharedPreferences("car", Context.MODE_PRIVATE).getInt("charge_target", 80);
                if (soc >= target && old >= 0 && old < target) notify(c, "Ladeziel erreicht", "Dein Enyaq hat " + soc + " % Akku erreicht.");
            }
            return Result.success();
        } catch (Exception e) { return Result.retry(); }
    }
    private void notify(Context c, String title, String message) {
        NotificationManager nm = (NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Oli Smart Car", NotificationManager.IMPORTANCE_DEFAULT));
        NotificationCompat.Builder b = new NotificationCompat.Builder(c, CHANNEL).setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(title).setContentText(message).setAutoCancel(true).setPriority(NotificationCompat.PRIORITY_DEFAULT);
        try { nm.notify(1001, b.build()); } catch (SecurityException ignored) {}
    }
}
