package de.olismartcar;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;

public class CarWidgetProvider extends AppWidgetProvider {
    @Override public void onUpdate(Context c, AppWidgetManager manager, int[] ids) {
        int soc = c.getSharedPreferences("car", Context.MODE_PRIVATE).getInt("last_soc", -1);
        update(c, soc, -1);
    }
    static void update(Context c, int soc, int range) {
        AppWidgetManager manager = AppWidgetManager.getInstance(c);
        int[] ids = manager.getAppWidgetIds(new ComponentName(c, CarWidgetProvider.class));
        for (int id : ids) {
            RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget_placeholder);
            v.setTextViewText(R.id.widget_soc, soc >= 0 ? soc + " % Akku" : "-- % Akku");
            String r = range >= 0 ? "Reichweite: " + range + " km" : "Reichweite: in Fahrzeugdaten nicht verfügbar";
            v.setTextViewText(R.id.widget_range, r + "  ·  Tippen zum Öffnen");
            Intent i = new Intent(c, MainActivity.class);
            PendingIntent pi = PendingIntent.getActivity(c, 0, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            v.setOnClickPendingIntent(R.id.widget_title, pi); v.setOnClickPendingIntent(R.id.widget_soc, pi); v.setOnClickPendingIntent(R.id.widget_range, pi);
            manager.updateAppWidget(id, v);
        }
    }
}
