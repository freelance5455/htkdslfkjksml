# ONYX 360 Android frontend wrapper

This is an Android Studio project that packages the ONYX 360 HTML frontend into
an installable Android app shell. It includes a native Android document picker
for selecting local game files and cover images.

## Important limitation

This APK is **not an Xbox 360 emulator**. The HTML frontend cannot execute ISO,
XEX, GOD, or other Xbox 360 game data. The file picker only gives the web frontend
access to document URIs for cataloguing. Actual game execution requires a separate,
compatible native Xenia-based Android emulator core. No emulator core or proprietary
game firmware is bundled here.

## Build the APK

1. Install Android Studio (current stable) and Android SDK Platform 35.
2. Install JDK 17 (Android Studio's bundled JBR is suitable).
3. Open this folder (`ONYX360`) in Android Studio.
4. Let Gradle sync complete.
5. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Android Studio writes the debug APK under `app/build/outputs/apk/debug/app-debug.apk`.
7. Transfer that APK to your Android device and install it. You may need to allow
   installation from the file manager you use.

## Included

- Offline ONYX 360 web interface in `app/src/main/assets/index.html`
- Kotlin WebView host activity
- Native Android document picker for multiple files
- LocalStorage-backed UI preferences
- Graphics, performance, controller, library and system screens

## Notes

- Uses AndroidX Activity 1.9.3, AGP 8.7.3, Kotlin 2.0.21, compile SDK 35, min SDK 26.
- Vulkan settings in the UI are configuration labels only; this wrapper does not
  create a Vulkan device or install GPU drivers.
- Selecting an ISO here does not launch it. Add and launch games inside a compatible
  native emulator app.
