BAKERY BUDDY — MINI ANDROID GAME

Files:
- app/src/main/assets/index.html : complete game (HTML/CSS/Vanilla JS)
- app/src/main/java/com/cremecrumb/bakery/MainActivity.java : Android WebView launcher
- app/src/main/AndroidManifest.xml
- Gradle project files

BUILD APK:
1. Install Android Studio and a compatible JDK (Android Studio's bundled JDK is recommended).
2. Open this folder as an existing Android Studio project.
3. Allow Gradle sync to complete; install Android SDK Platform 35 if prompted.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. The debug APK is normally created at app/build/outputs/apk/debug/app-debug.apk.

This ZIP contains the source project, not a prebuilt APK. An Android SDK/Gradle build environment is required to compile the installable APK.
The game works offline because all game logic and visuals use local HTML/CSS/emoji. No account or payments.
