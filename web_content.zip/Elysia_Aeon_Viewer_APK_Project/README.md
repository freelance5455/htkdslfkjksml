# Project Elysia — Aeon Viewer Android project

This is an Android Studio project wrapping the supplied mobile Aeon Viewer HTML in an Android WebView.

## Build an APK
1. Install Android Studio (current stable) and the Android SDK Platform 35.
2. Extract this ZIP.
3. In Android Studio choose **Open**, then select the extracted `Elysia_Aeon_Viewer_APK_Project` folder.
4. Allow Gradle sync to finish.
5. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Android Studio will show the generated APK location (usually `app/build/outputs/apk/debug/app-debug.apk`).

## Important runtime note
The viewer's HTML imports React, Three.js, React Three Fiber, and the TypeScript compiler from public CDNs. The APK therefore requires an internet connection to load those libraries and compile TSX files. The HTML itself and app shell are bundled locally. This package does not bundle the CDN libraries for fully offline use.

## Included
- `app/src/main/assets/index.html` — supplied viewer, with icon references updated
- `manifest.webmanifest`, icons, and service worker
- Android WebView wrapper with JavaScript enabled and Android file chooser support for TSX selection

## Updating the viewer
Replace `app/src/main/assets/index.html` with your updated viewer HTML, keeping the filename `index.html`, then rebuild the APK.
