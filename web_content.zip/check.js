
(function () {
'use strict';
/* SHARED START */
const PALOS = ['espada', 'basto', 'oro', 'copa'];
const NUMS = [1, 2, 3, 4, 5, 6, 7, 10, 11, 12];
const other = w => (w === 'p' ? 'c' : 'p');
function shuffle(a) {
  a = a.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    const t = a[i]; a[i] = a[j]; a[j] = t;
  }
  return a;
}
/* SHARED END */

/* TRUCO ENGINE START */
const STR = { '1espada': 14, '1basto': 13, '7espada': 12, '7oro': 11, '3': 10, '2': 9, '1copa': 8, '1oro': 8, '12': 7, '11': 6, '10': 5, '7copa': 4, '7basto': 4, '6': 3, '5': 2, '4': 1 };
const fuerza = c => (STR[c.n + c.p] !== undefined ? STR[c.n + c.p] : STR[c.n]);
const cid = c => c.n + '-' + c.p;
const cname = c => c.n + ' de ' + c.p;
const ptsTruco = l => [1, 2, 3, 4][l];
const TRUCO_NAMES = ['truco', 'retruco', 'vale cuatro'];

function tNew() {
  return {
    started: false, score: { p: 0, c: 0 }, goal: 30, over: false, winner: null, hn: 0, mano: 'p',
    log: [], dealt: { p: [], c: [] }, hand: { p: [], c: [] }, played: { p: [], c: [] }, bazas: [],
    turn: 'p', trucoLevel: 0, trucoRaiser: null, envido: { done: false }, q: null, stash: null,
    handOver: false, result: null
  };
}
function say(G, who, text, meta) { G.log.push({ h: G.hn, who: who, text: text, meta: !!meta }); }

function dealHand(G, mano) {
  const deck = shuffle(PALOS.flatMap(p => NUMS.map(n => ({ n: n, p: p }))));
  G.hn++;
  G.mano = mano; G.turn = mano;
  G.dealt = { p: deck.slice(0, 3), c: deck.slice(3, 6) };
  G.hand = { p: deck.slice(0, 3), c: deck.slice(3, 6) };
  G.played = { p: [], c: [] };
  G.bazas = [];
  G.trucoLevel = 0; G.trucoRaiser = null;
  G.envido = { done: false };
  G.q = null; G.stash = null;
  G.handOver = false; G.result = null;
  say(G, null, 'Mano ' + G.hn + ': arranca ' + (mano === 'p' ? 'vos' : 'Manolo') + ' (es mano).');
}

function envidoPts(cards) {
  let best = 0;
  for (const p of PALOS) {
    const v = cards.filter(c => c.p === p).map(c => (c.n <= 7 ? c.n : 0)).sort((a, b) => b - a);
    if (v.length >= 2) best = Math.max(best, 20 + v[0] + v[1]);
    else if (v.length === 1) best = Math.max(best, v[0]);
  }
  return best;
}

function resultado(b, mano) {
  if (!b.length) return null;
  if (b[0] !== 'parda') {
    if (b.length < 2) return null;
    if (b[1] === 'parda' || b[1] === b[0]) return b[0];
    if (b.length < 3) return null;
    return b[2] !== 'parda' ? b[2] : b[0];
  }
  if (b.length < 2) return null;
  if (b[1] !== 'parda') return b[1];
  if (b.length < 3) return null;
  return b[2] !== 'parda' ? b[2] : mano;
}

function envidoValue(G, calls, rejected) {
  const val = { envido: 2, real: 3 };
  if (!rejected) {
    if (calls.includes('falta')) return G.goal - Math.max(G.score.p, G.score.c);
    return calls.reduce((s, c) => s + val[c], 0);
  }
  const prev = calls.slice(0, -1);
  if (!prev.length) return 1;
  return prev.reduce((s, c) => s + (val[c] || 0), 0);
}

function addScore(G, who, n) {
  G.score[who] += n;
  if (G.score[who] >= G.goal) { G.over = true; G.winner = who; G.handOver = true; }
}

function finishHand(G, winner, pts, why) {
  G.handOver = true; G.q = null; G.stash = null;
  say(G, null, (winner === 'p' ? 'Vos ganás' : 'Manolo gana') + ' la mano: +' + pts + ' (' + why + ').');
  G.result = { winner: winner, pts: pts, why: why };
  addScore(G, winner, pts);
}

function afterEnvido(G) {
  G.envido.done = true;
  if (G.over) { G.q = null; G.stash = null; return; }
  G.q = G.stash || null;
  G.stash = null;
}

function settleEnvido(G, winner, extra) {
  const pts = envidoValue(G, G.q.calls, false);
  say(G, null, 'Envido: +' + pts + (extra ? ' y +' + extra + ' de castigo' : '') + ' para ' + (winner === 'p' ? 'vos' : 'Manolo') + '.');
  addScore(G, winner, pts);
  if (extra && !G.over) addScore(G, winner, extra);
  afterEnvido(G);
}

function A(id) { return { id: id }; }

function legal(G, who) {
  const out = [], q = G.q;
  if (!G.started || G.over || G.handOver) return out;
  if (q) {
    if (q.responder !== who) return out;
    if (q.kind === 'tantos') {
      if (q.phase === 'mano') { for (let n = 0; n <= 33; n++) out.push(A('tantos:' + n)); }
      else if (q.phase === 'pie') {
        out.push(A('buenas'), A('dudo'));
        for (let n = q.N1 + 1; n <= 33; n++) out.push(A('tantos:' + n));
      } else out.push(A('buenas'), A('dudo'));
      return out;
    }
    out.push(A('quiero'), A('noquiero'));
    if (q.kind === 'envido') {
      const last = q.calls[q.calls.length - 1];
      if (last === 'envido') {
        if (q.calls.filter(x => x === 'envido').length < 2) out.push(A('envido'));
        out.push(A('real'), A('falta'));
      } else if (last === 'real') out.push(A('falta'));
    } else {
      if (q.level < 3) out.push(A(['truco', 'retruco', 'vale4'][q.level]));
      if (G.bazas.length === 0 && !G.envido.done) out.push(A('envido'), A('real'), A('falta'));
    }
    return out;
  }
  if (G.turn !== who) return out;
  G.hand[who].forEach(c => out.push(A('card:' + cid(c))));
  out.push(A('mazo'));
  if (G.bazas.length === 0 && !G.envido.done && G.trucoLevel === 0 && G.played[who].length === 0) out.push(A('envido'), A('real'), A('falta'));
  if (G.trucoLevel === 0) out.push(A('truco'));
  else if (G.trucoRaiser === who && G.trucoLevel < 3) out.push(A(['retruco', 'vale4'][G.trucoLevel - 1]));
  return out;
}

function actor(G) {
  if (!G.started || G.over || G.handOver) return null;
  return G.q ? G.q.responder : G.turn;
}

function act(G, who, id) {
  if (!legal(G, who).some(a => a.id === id)) throw new Error('ilegal ' + who + ' ' + id);
  const op = other(who), q = G.q;
  if (id.indexOf('card:') === 0) {
    const cardId = id.slice(5);
    const c = G.hand[who].find(x => cid(x) === cardId);
    G.hand[who] = G.hand[who].filter(x => x !== c);
    G.played[who].push(c);
    say(G, who, 'jugó ' + cname(c) + '.');
    const i = G.bazas.length;
    if (G.played.p.length > i && G.played.c.length > i) {
      const a = fuerza(G.played.p[i]), b = fuerza(G.played.c[i]);
      const w = a > b ? 'p' : b > a ? 'c' : 'parda';
      G.bazas.push(w);
      say(G, null, 'Baza ' + (i + 1) + ': ' + (w === 'p' ? 'vos' : w === 'c' ? 'Manolo' : 'parda') + '.');
      const r = resultado(G.bazas, G.mano);
      if (r) { finishHand(G, r, ptsTruco(G.trucoLevel), 'ganó las bazas'); return; }
      G.turn = w === 'parda' ? G.mano : w;
    } else G.turn = op;
  } else if (id === 'mazo') {
    say(G, who, 'se fue al mazo.');
    finishHand(G, op, ptsTruco(G.trucoLevel), 'se fue al mazo');
  } else if (id === 'envido' || id === 'real' || id === 'falta') {
    say(G, who, { envido: '¡Envido!', real: '¡Real envido!', falta: '¡Falta envido!' }[id]);
    if (q && q.kind === 'envido') { q.calls.push(id); q.caller = who; q.responder = op; }
    else if (q && q.kind === 'truco') { G.stash = q; G.q = { kind: 'envido', caller: who, responder: op, calls: [id] }; }
    else G.q = { kind: 'envido', caller: who, responder: op, calls: [id] };
  } else if (id === 'truco' || id === 'retruco' || id === 'vale4') {
    const lv = { truco: 1, retruco: 2, vale4: 3 }[id];
    say(G, who, { truco: '¡Truco!', retruco: '¡Retruco!', vale4: '¡Vale cuatro!' }[id]);
    if (q && q.kind === 'truco') G.trucoLevel = q.level;
    G.q = { kind: 'truco', caller: who, responder: op, level: lv };
  } else if (id === 'quiero') {
    say(G, who, '¡Quiero!');
    if (q.kind === 'envido') G.q = { kind: 'tantos', phase: 'mano', responder: G.mano, calls: q.calls, N1: null, N2: null };
    else { G.trucoLevel = q.level; G.trucoRaiser = who; G.q = null; }
  } else if (id === 'noquiero') {
    say(G, who, 'No quiero.');
    if (q.kind === 'envido') {
      const pts = envidoValue(G, q.calls, true);
      say(G, null, 'Envido: +' + pts + ' para ' + (q.caller === 'p' ? 'vos' : 'Manolo') + '.');
      addScore(G, q.caller, pts);
      afterEnvido(G);
    } else finishHand(G, q.caller, ptsTruco(G.trucoLevel), 'no se quiso el ' + TRUCO_NAMES[q.level - 1]);
  } else if (id.indexOf('tantos:') === 0) {
    const n = parseInt(id.slice(7), 10);
    say(G, who, 'Tengo ' + n + '.');
    if (q.phase === 'mano') { q.N1 = n; q.phase = 'pie'; }
    else { q.N2 = n; q.phase = 'mano2'; }
    q.responder = op;
  } else if (id === 'buenas') {
    say(G, who, 'Son buenas.');
    settleEnvido(G, q.phase === 'pie' ? G.mano : other(G.mano), 0);
  } else if (id === 'dudo') {
    const doubted = q.phase === 'pie' ? G.mano : other(G.mano);
    const claim = q.phase === 'pie' ? q.N1 : q.N2;
    const real = envidoPts(G.dealt[doubted]);
    say(G, who, '¡Dudo! Mostrá las cartas.');
    say(G, doubted, 'mostró ' + G.dealt[doubted].map(cname).join(', ') + ': ' + real + ' de envido.');
    if (real === claim) {
      say(G, null, (doubted === 'p' ? 'Vos decías la verdad' : 'Manolo decía la verdad') + '.');
      settleEnvido(G, doubted, 1);
    } else {
      say(G, null, (doubted === 'p' ? 'Mentiste' : 'Manolo mintió') + ': dijo ' + claim + ' y tenía ' + real + '.');
      settleEnvido(G, who, 0);
    }
  }
}

function botDecide(G, me, ids) {
  const op = other(me), all = G.dealt[me], rem = G.hand[me];
  const ep = envidoPts(all);
  const rs = rem.map(fuerza).sort((a, b) => b - a);
  const s1 = rs[0] || 0, s2 = rs[1] || 0;
  const has = x => ids.includes(x);
  const q = G.q;
  const wonFirst = G.bazas[0] === me, lostFirst = G.bazas[0] === op;
  if (q && q.responder === me) {
    if (q.kind === 'tantos') {
      if (q.phase === 'mano') {
        let n = ep;
        if (ep < 30 && Math.random() < 0.12) n = Math.min(33, ep + 2 + Math.floor(Math.random() * 5));
        return 'tantos:' + n;
      }
      if (q.phase === 'pie') {
        if (q.N1 >= 30 && ep < q.N1 && Math.random() < 0.3) return 'dudo';
        if (ep > q.N1) return 'tantos:' + ep;
        if (q.N1 < 33 && ep >= q.N1 - 3 && Math.random() < 0.08) return 'tantos:' + (q.N1 + 1);
        return 'buenas';
      }
      if (q.N2 >= 31 && Math.random() < 0.3) return 'dudo';
      if (q.N2 >= 28 && ep < 26 && Math.random() < 0.12) return 'dudo';
      return 'buenas';
    }
    if (q.kind === 'envido') {
      let thr = q.calls.includes('falta') ? 31 : q.calls.includes('real') ? 29 : q.calls.length > 1 ? 28 : 26;
      if (G.mano === me) thr -= 1;
      if (ep >= thr) {
        if (ep >= 32 && has('falta')) return 'falta';
        if (ep >= 30 && has('real')) return 'real';
        return 'quiero';
      }
      return (ep >= 22 && Math.random() < 0.07) ? 'quiero' : 'noquiero';
    }
    if (has('envido') && ep >= 28 && Math.random() < 0.6) return 'envido';
    let need = q.level === 1 ? 12 : q.level === 2 ? 13 : 14;
    if (wonFirst) need -= 3;
    if (lostFirst) need += 1;
    const strong = s1 >= need || (s1 >= need - 3 && s2 >= 10);
    const next = ['retruco', 'vale4'][q.level - 1];
    if (strong && next && has(next) && s1 >= 13 && s2 >= 11 && Math.random() < 0.5) return next;
    if (strong || (q.level === 1 && s1 >= 9 && Math.random() < 0.12)) return 'quiero';
    return 'noquiero';
  }
  if (has('envido')) {
    if (ep >= 31 && Math.random() < 0.96) return has('real') ? 'real' : 'envido';
    if (ep >= 27 && Math.random() < 0.88) return 'envido';
    if (ep >= 24 && Math.random() < 0.22) return 'envido';
  }
  if (has('truco') && s1 >= 12 && s2 >= 9 && Math.random() < 0.72) return 'truco';
  const next2 = G.trucoLevel > 0 ? ['retruco', 'vale4'][G.trucoLevel - 1] : null;
  if (next2 && has(next2) && s1 >= 13 && s2 >= 10 && Math.random() < 0.48) return next2;
  const i = G.bazas.length;
  const oc = G.played[op][i];
  const sorted = rem.slice().sort((a, b) => fuerza(a) - fuerza(b));
  let pick;
  if (oc) {
    const beat = sorted.filter(c => fuerza(c) > fuerza(oc));
    pick = beat[0] || sorted[0];
  } else if (i === 0 && sorted.length === 3) pick = sorted[1];
  else pick = sorted[sorted.length - 1];
  return 'card:' + cid(pick);
}
/* TRUCO ENGINE END */
/* CHIN ENGINE START */
const isJ = c => c.p === 'comodin';
const ccid = c => (isJ(c) ? 'J' + c.k : c.n + '-' + c.p);
const ccname = c => (isJ(c) ? 'comodín' : c.n + ' de ' + c.p);
const cval = c => (isJ(c) ? 25 : c.n >= 10 ? 10 : c.n);

function isMeld(cs) {
  if (cs.length < 3) return false;
  const js = cs.filter(isJ).length;
  const rs = cs.filter(c => !isJ(c));
  if (!rs.length) return false;
  if (rs.every(c => c.n === rs[0].n)) {
    const suits = new Set(rs.map(c => c.p));
    if (suits.size === rs.length && cs.length <= 4) return true;
  }
  if (rs.every(c => c.p === rs[0].p)) {
    const ns = rs.map(c => c.n).sort((a, b) => a - b);
    for (let i = 1; i < ns.length; i++) if (ns[i] === ns[i - 1]) return false;
    const span = ns[ns.length - 1] - ns[0] + 1;
    if (span - ns.length <= js && cs.length <= 12) return true;
  }
  return false;
}

function orderMeld(cs) {
  const js = cs.filter(isJ), rs = cs.filter(c => !isJ(c));
  if (rs.every(c => c.n === rs[0].n)) return rs.concat(js);
  rs.sort((a, b) => a.n - b.n);
  const out = [rs[0]], left = js.slice();
  for (let i = 1; i < rs.length; i++) {
    for (let g = rs[i - 1].n + 1; g < rs[i].n; g++) out.push(left.shift());
    out.push(rs[i]);
  }
  if (left.length) {
    if (rs[rs.length - 1].n + left.length <= 12) return out.concat(left);
    return left.concat(out);
  }
  return out;
}

function arrange(cards) {
  const n = cards.length, full = (1 << n) - 1, melds = [];
  for (let m = 1; m <= full; m++) {
    let k = 0;
    for (let i = 0; i < n; i++) if ((m >> i) & 1) k++;
    if (k < 3) continue;
    const sub = [];
    for (let i = 0; i < n; i++) if ((m >> i) & 1) sub.push(cards[i]);
    if (isMeld(sub)) melds.push(m);
  }
  const memo = new Array(full + 1);
  memo[0] = { d: 0, take: 0 };
  const f = mask => {
    if (memo[mask]) return memo[mask];
    const low = mask & -mask, i = 31 - Math.clz32(low);
    let bestD = cval(cards[i]) + f(mask ^ low).d, take = 0;
    for (const m of melds) {
      if ((m & mask) === m && (m & low)) {
        const d = f(mask ^ m).d;
        if (d < bestD) { bestD = d; take = m; }
      }
    }
    memo[mask] = { d: bestD, take: take };
    return memo[mask];
  };
  const res = f(full);
  const groups = [], loose = [];
  let mask = full;
  while (mask) {
    const st = f(mask);
    if (st.take) {
      const t = st.take;
      groups.push(orderMeld(cards.filter((c, i) => (t >> i) & 1)));
      mask ^= t;
    } else {
      const low = mask & -mask;
      loose.push(cards[31 - Math.clz32(low)]);
      mask ^= low;
    }
  }
  loose.sort((a, b) => cval(b) - cval(a));
  return { dead: res.d, groups: groups, loose: loose };
}

function cNew() {
  return {
    started: false, score: { p: 0, c: 0 }, limit: 100, over: false, winner: null, hn: 0, mano: 'p',
    turn: 'p', phase: 'draw', hands: { p: [], c: [] }, mazo: [], desc: [], fromDesc: null, drawn: null,
    handOver: false, result: null, log: []
  };
}
function cSay(C, who, text, meta) { C.log.push({ h: C.hn, who: who, text: text, meta: !!meta }); }

function cDeal(C, mano) {
  const deck = [];
  for (const p of PALOS) for (let n = 1; n <= 12; n++) deck.push({ n: n, p: p });
  deck.push({ n: 0, p: 'comodin', k: 1 }, { n: 0, p: 'comodin', k: 2 });
  const d = shuffle(deck);
  C.hn++; C.mano = mano; C.turn = mano; C.phase = 'draw'; C.drawn = null; C.fromDesc = null;
  C.hands = { p: d.slice(0, 7), c: d.slice(7, 14) };
  C.desc = [d[14]]; C.mazo = d.slice(15);
  C.handOver = false; C.result = null;
  cSay(C, null, 'Mano ' + C.hn + ': arranca ' + (mano === 'p' ? 'vos' : 'Manolo') + '. Descarte: ' + ccname(C.desc[0]) + '.');
}

function cActor(C) { return (!C.started || C.over || C.handOver) ? null : C.turn; }

function cLegal(C, who) {
  const out = [];
  if (!C.started || C.over || C.handOver || C.turn !== who) return out;
  if (C.phase === 'draw') {
    if (C.mazo.length || C.desc.length > 1) out.push('draw:mazo');
    if (C.desc.length) out.push('draw:descarte');
    return out;
  }
  const hand = C.hands[who];
  for (const c of hand) {
    if (C.fromDesc && ccid(c) === C.fromDesc) continue;
    out.push('discard:' + ccid(c));
    if (arrange(hand.filter(x => x !== c)).dead <= 5) out.push('cut:' + ccid(c));
  }
  return out;
}

function cRoundEnd(C, cutter, card) {
  const op = other(cutter);
  C.hands[cutter] = C.hands[cutter].filter(x => x !== card);
  C.desc.push(card);
  const mine = arrange(C.hands[cutter]), theirs = arrange(C.hands[op]);
  const chin = C.hands[cutter].length === 7 && isMeld(C.hands[cutter]);
  const cutPts = mine.dead === 0 ? -10 : mine.dead;
  C.handOver = true;
  C.result = { cutter: cutter, chin: chin, mine: mine, theirs: theirs, cutPts: cutPts, otherPts: theirs.dead };
  if (chin) {
    cSay(C, cutter, '¡CHINCHÓN!');
    C.over = true; C.winner = cutter;
    return;
  }
  cSay(C, cutter, 'cortó tirando ' + ccname(card) + ': ' + (mine.dead === 0 ? '-10' : '+' + mine.dead) + '.');
  cSay(C, op, 'le sobran ' + theirs.dead + ' puntos.');
  C.score[cutter] = Math.max(0, C.score[cutter] + cutPts);
  C.score[op] += theirs.dead;
  if (C.score.p > C.limit || C.score.c > C.limit) {
    C.over = true;
    C.winner = C.score.p === C.score.c ? cutter : (C.score.p > C.score.c ? 'c' : 'p');
  }
}

function cAct(C, who, id) {
  if (!cLegal(C, who).includes(id)) throw new Error('ilegal ' + who + ' ' + id);
  const op = other(who);
  if (id === 'draw:mazo') {
    if (!C.mazo.length) {
      const top = C.desc.pop();
      C.mazo = shuffle(C.desc); C.desc = [top];
      cSay(C, null, 'Se mezcló el descarte para formar un mazo nuevo.', true);
    }
    const c = C.mazo.pop();
    C.hands[who].push(c); C.drawn = ccid(c); C.fromDesc = null; C.phase = 'discard';
    cSay(C, who, 'levantó del mazo.');
  } else if (id === 'draw:descarte') {
    const c = C.desc.pop();
    C.hands[who].push(c); C.drawn = ccid(c); C.fromDesc = ccid(c); C.phase = 'discard';
    cSay(C, who, 'levantó el ' + ccname(c) + ' del descarte.');
  } else if (id.indexOf('discard:') === 0) {
    const key = id.slice(8);
    const c = C.hands[who].find(x => ccid(x) === key);
    C.hands[who] = C.hands[who].filter(x => x !== c);
    C.desc.push(c);
    cSay(C, who, 'descartó ' + ccname(c) + '.');
    C.turn = op; C.phase = 'draw'; C.drawn = null; C.fromDesc = null;
  } else if (id.indexOf('cut:') === 0) {
    const key = id.slice(4);
    cRoundEnd(C, who, C.hands[who].find(x => ccid(x) === key));
  }
}

function cBot(C, me, ids) {
  const hand = C.hands[me];
  if (C.phase === 'draw') {
    if (ids.includes('draw:descarte')) {
      const top = C.desc[C.desc.length - 1];
      const base = arrange(hand).dead;
      const w8 = hand.concat([top]);
      let best = 1e9;
      for (const c of hand) best = Math.min(best, arrange(w8.filter(x => x !== c)).dead);
      if (best <= base - 4 || isJ(top)) return 'draw:descarte';
    }
    return 'draw:mazo';
  }
  const find = key => hand.find(x => ccid(x) === key);
  const cuts = ids.filter(i => i.indexOf('cut:') === 0);
  if (cuts.length) {
    let cb = null, cd = 1e9;
    for (const id of cuts) { const d = arrange(hand.filter(x => x !== find(id.slice(4)))).dead; if (d < cd) { cd = d; cb = id; } }
    if (cd <= 2 || Math.random() < 0.85) return cb;
  }
  let bestId = null, bestD = 1e9, bestV = -1;
  for (const id of ids.filter(i => i.indexOf('discard:') === 0)) {
    const c = find(id.slice(8));
    const d = arrange(hand.filter(x => x !== c)).dead, v = cval(c);
    if (d < bestD || (d === bestD && v > bestV)) { bestD = d; bestV = v; bestId = id; }
  }
  return bestId;
}
/* CHIN ENGINE END */

/* SOL ENGINE START */
const SOL_ROWS = ['espada', 'oro', 'copa', 'basto'];
const rankOf = n => (n <= 7 ? n : n - 2);
const slotIndex = c => SOL_ROWS.indexOf(c.p) * 9 + (rankOf(c.n) - 1);

function sNew() {
  const deck = shuffle(PALOS.flatMap(p => NUMS.map(n => ({ n: n, p: p }))));
  const S = { slots: deck.slice(0, 36).map(c => ({ card: c, up: false })), aside: deck.slice(36), hand: null, moves: 0, over: false, win: false, log: [] };
  sCheck(S);
  return S;
}
function sCheck(S) {
  if (S.slots.every(s => s.up)) { S.over = true; S.win = true; return; }
  if (!S.hand && !S.aside.some(c => rankOf(c.n) < 10)) S.over = true;
}
function sPick(S, i) {
  const c = S.aside[i];
  if (S.over || S.hand || !c || rankOf(c.n) >= 10) return false;
  S.aside.splice(i, 1);
  S.hand = c;
  S.log.push('Empezás con el ' + c.n + ' de ' + c.p + '.');
  return true;
}
function sPlace(S) {
  if (S.over || !S.hand) return false;
  const slot = S.slots[slotIndex(S.hand)];
  const placed = S.hand, got = slot.card;
  slot.card = placed; slot.up = true; S.moves++;
  S.log.push('El ' + placed.n + ' de ' + placed.p + ' va a su lugar y levantás el ' + got.n + ' de ' + got.p + '.');
  if (rankOf(got.n) === 10) {
    S.aside.push(got); S.hand = null;
    S.log.push('Salió un rey: se corta la cadena.');
  } else S.hand = got;
  sCheck(S);
  return true;
}
/* SOL ENGINE END */
/* ---------- Utilidades de interfaz ---------- */
const $ = id => document.getElementById(id);
const esc = s => String(s).replace(/[&<>"']/g, m => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[m]));
function setHTML(el, html) { if (el._h !== html) { el._h = html; el.innerHTML = html; return true; } return false; }
const sleep = ms => new Promise(r => setTimeout(r, ms));

let sample = null;
let rivalMode = 'quick';
let drag = null;

/* ---------- Diseño de las cartas (baraja española) ---------- */
const PIPS = {
  2: [[50, 40, 24], [50, 108, 24]],
  3: [[50, 38, 24], [50, 74, 24], [50, 110, 24]],
  4: [[33, 42, 22], [67, 42, 22], [33, 106, 22], [67, 106, 22]],
  5: [[33, 42, 22], [67, 42, 22], [50, 74, 22], [33, 106, 22], [67, 106, 22]],
  6: [[33, 40, 22], [67, 40, 22], [33, 74, 22], [67, 74, 22], [33, 108, 22], [67, 108, 22]],
  7: [[33, 40, 21], [67, 40, 21], [50, 57, 21], [33, 74, 21], [67, 74, 21], [33, 108, 21], [67, 108, 21]],
  8: [[33, 40, 20], [67, 40, 20], [50, 57, 20], [33, 74, 20], [67, 74, 20], [50, 91, 20], [33, 108, 20], [67, 108, 20]],
  9: [[31, 38, 18], [69, 38, 18], [31, 62, 18], [69, 62, 18], [50, 74, 18], [31, 86, 18], [69, 86, 18], [31, 110, 18], [69, 110, 18]]
};

function useSym(p, x, y, w, color) {
  return '<use href="#s-' + p + '" x="' + x + '" y="' + y + '" width="' + w + '" height="' + w + '"' + (color ? ' style="color:' + color + '"' : '') + '/>';
}

function figure(n, p) {
  const panel = '<rect x="27" y="30" width="46" height="88" rx="6" fill="currentColor" fill-opacity=".13" stroke="currentColor" stroke-width="1.2"/>';
  const emblem = useSym(p, 43, 90, 14, '#f6f3eb');
  if (n === 10) {
    return panel +
      '<path d="M42 112l2-22h12l2 22z" fill="currentColor" opacity=".85"/>' +
      '<path d="M35 92l4-26q11-6 22 0l4 26z" fill="currentColor"/>' +
      '<circle cx="50" cy="55" r="8" fill="#f1d3b0" stroke="#7a5230" stroke-width=".8"/>' +
      '<path d="M40 52q10-18 23-4-5 3-11 2-6 0-12 2z" fill="currentColor"/>' +
      '<path d="M62 47q8-9 6-15-4 8-10 13z" fill="#c9a24a"/>' + emblem;
  }
  if (n === 11) {
    return panel +
      '<path d="M36 114c0-16 4-24 8-32-6-4-8-12-4-20l-2-14 8 6c8-10 20-6 20 6 0 6-3 10-6 12 4 10 6 24 6 42z" fill="currentColor"/>' +
      '<path d="M46 54c-2 12-4 22-2 30" stroke="#c9a24a" stroke-width="3" fill="none" stroke-linecap="round"/>' +
      '<path d="M60 68l-8-2" stroke="#c9a24a" stroke-width="2" stroke-linecap="round"/>' +
      '<circle cx="55" cy="60" r="1.8" fill="#f6f3eb"/>' + emblem;
  }
  return panel +
    '<path d="M31 114q0-32 19-36 19 4 19 36z" fill="currentColor"/>' +
    '<path d="M42 62q8 22 16 0-8 8-16 0z" fill="#d8d2c4"/>' +
    '<circle cx="50" cy="59" r="8.5" fill="#f1d3b0" stroke="#7a5230" stroke-width=".8"/>' +
    '<path d="M42 64q8 20 16 0-8 6-16 0z" fill="#d8d2c4"/>' +
    '<path d="M37 50l2-14 6 8 5-12 5 12 6-8 2 14z" fill="#c9a24a" stroke="#7a5a12" stroke-width=".8"/>' +
    '<path d="M40 82q10 9 20 0" stroke="#f6f3eb" stroke-width="3" fill="none"/>' + emblem;
}

function jokerFace() {
  const star = '<path d="M16 8l2 5 5 .5-4 3.500 1.300 5L16 19.300 11.700 22l1.300-5-4-3.500 5-.5z" fill="#6b3fa0" transform="translate(-6 -3) scale(.9)"/>';
  return '<g style="color:#6b3fa0">' +
    '<rect x="4.5" y="4.5" width="91" height="139" rx="6" fill="none" stroke="currentColor" stroke-opacity=".5" stroke-width="1.2"/>' +
    star + '<g transform="rotate(180 50 74)">' + star + '</g>' +
    '<path d="M26 74Q18 44 30 30q8 22 20 6 12 16 20-6 12 14 4 44z" fill="#6b3fa0"/>' +
    '<circle cx="30" cy="30" r="4" fill="#d9a63a"/><circle cx="70" cy="30" r="4" fill="#d9a63a"/><circle cx="50" cy="36" r="4" fill="#d9a63a"/>' +
    '<path d="M26 74q24-8 48 0l-2 6q-22-8-44 0z" fill="#2f8f83"/>' +
    '<circle cx="50" cy="92" r="15" fill="#f1d3b0" stroke="#7a5230" stroke-width=".8"/>' +
    '<circle cx="44" cy="89" r="1.8" fill="#1c2b24"/><circle cx="56" cy="89" r="1.8" fill="#1c2b24"/>' +
    '<path d="M42 97q8 8 16 0" stroke="#b4352d" stroke-width="2" fill="none" stroke-linecap="round"/>' +
    '<path d="M32 112l6-8 6 8 6-8 6 8 6-8 6 8v8H32z" fill="#2f8f83"/>' +
    '<text x="50" y="134" text-anchor="middle" class="ix" style="font-size:9px;letter-spacing:1px;fill:#6b3fa0">COMODÍN</text>' +
    '</g>';
}

function cardFace(c) {
  if (c.p === 'comodin') return jokerFace();
  const n = c.n, p = c.p;
  const fs = n >= 10 ? 'font-size:16px' : '';
  const corner = '<text x="10" y="26" class="ix" style="' + fs + '">' + n + '</text>' + useSym(p, 9, 30, 13);
  let s = '<g class="sc">' +
    '<rect x="4.5" y="4.5" width="91" height="139" rx="6" fill="none" stroke="currentColor" stroke-opacity=".45" stroke-width="1.2"/>' +
    '<rect x="8" y="8" width="84" height="132" rx="4" fill="none" stroke="currentColor" stroke-opacity=".18" stroke-width=".8"/>' +
    corner + '<g transform="rotate(180 50 74)">' + corner + '</g>';
  if (n === 1) s += '<circle cx="50" cy="74" r="31" fill="none" stroke="currentColor" stroke-opacity=".3" stroke-width="1"/>' + useSym(p, 24, 48, 52);
  else if (n >= 10) s += figure(n, p);
  else for (const q of PIPS[n]) s += useSym(p, q[0] - q[2] / 2, q[1] - q[2] / 2, q[2]);
  return s + '</g>';
}

function cardHTML(c, o) {
  o = o || {};
  const tag = o.tag || 'div';
  const label = c.p === 'comodin' ? 'comodín' : c.n + ' de ' + c.p;
  return '<' + tag + ' class="card s-' + c.p + (o.cls ? ' ' + o.cls : '') + '"' + (o.attrs || '') + ' aria-label="' + label + '">' +
    '<svg viewBox="0 0 100 148" aria-hidden="true" focusable="false">' + cardFace(c) + '</svg></' + tag + '>';
}

function backHTML(o) {
  o = o || {};
  const tag = o.tag || 'div';
  return '<' + tag + ' class="card back' + (o.cls ? ' ' + o.cls : '') + '"' + (o.attrs || '') + ' aria-label="carta boca abajo">' +
    '<svg viewBox="0 0 100 148" aria-hidden="true" focusable="false">' +
    '<rect width="100" height="148" fill="#f6f3eb"/>' +
    '<rect x="6" y="6" width="88" height="136" rx="4" fill="url(#bk)" stroke="#e7b9b9" stroke-width="1"/>' +
    '<circle cx="50" cy="74" r="17" fill="#5c1b27" stroke="#f6f3eb" stroke-width="2"/>' +
    '<use href="#s-oro" x="40" y="64" width="20" height="20" style="color:#d9b27a"/></svg></' + tag + '>';
}

function pileHTML(n, label) {
  return '<div class="pile">' + backHTML() + backHTML() + backHTML() + '</div><div class="cnt">' + label + (n === null ? '' : ' · ' + n) + '</div>';
}

/* ---------- Marcador con palitos ---------- */
function palitos(pts) {
  pts = Math.max(0, Math.min(30, pts));
  let s = '<svg class="palitos" viewBox="0 0 122 92" role="img" aria-label="' + pts + ' puntos en palitos">' +
    '<text x="2" y="8" class="pl">MALAS</text><text x="2" y="52" class="pl">BUENAS</text>';
  for (let g = 0; g < 6; g++) {
    const x = 6 + (g % 3) * 38, y = g < 3 ? 12 : 56;
    const k = Math.max(0, Math.min(5, pts - g * 5));
    const seg = [[x, y, x + 28, y], [x + 28, y, x + 28, y + 28], [x + 28, y + 28, x, y + 28], [x, y + 28, x, y], [x, y + 28, x + 28, y]];
    for (let i = 0; i < 5; i++) {
      const a = seg[i];
      if (i < k) {
        s += '<line x1="' + a[0] + '" y1="' + a[1] + '" x2="' + a[2] + '" y2="' + a[3] + '" stroke="#e2bd86" stroke-width="3.2" stroke-linecap="round"/>' +
          '<circle cx="' + a[0] + '" cy="' + a[1] + '" r="2.7" fill="#c4402b"/>';
      } else {
        s += '<line x1="' + a[0] + '" y1="' + a[1] + '" x2="' + a[2] + '" y2="' + a[3] + '" stroke="#2f6551" stroke-width="1" stroke-dasharray="2 3" opacity=".7"/>';
      }
    }
  }
  return s + '</svg>';
}

/* ---------- Arrastrar cartas a la mesa ---------- */
const dragCfg = {};

function overZone(e, zone) {
  if (!zone) return false;
  const r = zone.getBoundingClientRect();
  return e.clientX > r.left - 24 && e.clientX < r.right + 24 && e.clientY > r.top - 40 && e.clientY < r.bottom + 40;
}

function endDrag() {
  document.removeEventListener('pointermove', onMove);
  document.removeEventListener('pointerup', onUp);
  document.removeEventListener('pointercancel', endDrag);
  if (drag) {
    if (drag.ghost) drag.ghost.remove();
    drag.el.classList.remove('lifted');
    const z = drag.cfg.zone();
    if (z) z.classList.remove('drop');
  }
  drag = null;
}

function onMove(e) {
  if (!drag || e.pointerId !== drag.pid) return;
  const dx = e.clientX - drag.x0, dy = e.clientY - drag.y0;
  if (!drag.moved && Math.hypot(dx, dy) > 8) {
    drag.moved = true;
    const g = document.createElement('div');
    g.className = 'ghost';
    g.innerHTML = drag.el.outerHTML.replace(/^<button/, '<div').replace(/<\/button>$/, '</div>');
    g.firstChild.style.setProperty('--cw', drag.w + 'px');
    g.firstChild.classList.remove('sel', 'lifted');
    document.body.appendChild(g);
    drag.ghost = g;
    drag.el.classList.add('lifted');
  }
  if (drag.moved) {
    const tilt = Math.max(-12, Math.min(12, dx / 10));
    drag.ghost.style.transform = 'translate(' + (e.clientX - drag.ox) + 'px,' + (e.clientY - drag.oy) + 'px) rotate(' + tilt + 'deg)';
    const z = drag.cfg.zone();
    if (z) z.classList.toggle('drop', overZone(e, z));
    e.preventDefault();
  }
}

function onUp(e) {
  if (!drag || e.pointerId !== drag.pid) return;
  const d = drag;
  const dropped = d.moved && overZone(e, d.cfg.zone());
  endDrag();
  if (d.moved) { if (dropped) d.cfg.drop(d.id); }
  else if (d.cfg.can()) d.cfg.tap(d.id);
}

function attachDrag(containerId) {
  $(containerId).addEventListener('pointerdown', e => {
    const b = e.target.closest('button.card');
    const cfg = dragCfg[containerId];
    if (!b || b.disabled || !cfg || drag || (e.button !== undefined && e.button > 0)) return;
    const r = b.getBoundingClientRect();
    drag = { id: b.dataset.card, el: b, cfg: cfg, x0: e.clientX, y0: e.clientY, ox: e.clientX - r.left, oy: e.clientY - r.top, w: r.width, moved: false, ghost: null, pid: e.pointerId };
    document.addEventListener('pointermove', onMove, { passive: false });
    document.addEventListener('pointerup', onUp);
    document.addEventListener('pointercancel', endDrag);
  });
}

/* ---------- Manolo como rival (truco y chinchón) ---------- */
async function pickMove(prompt, ids, fallback, noteFn) {
  let id = null, frase = '';
  if (rivalMode !== 'bot' && sample) {
    try {
      const r = await sample.json(prompt, { modelTier: rivalMode === 'think' ? 'default' : 'quick', cache: false });
      if (r && typeof r.accion === 'string' && ids.includes(r.accion)) {
        id = r.accion;
        if (typeof r.frase === 'string') frase = r.frase.slice(0, 70);
      } else noteFn('Manolo contestó algo que no se puede jugar. Esta jugada la hizo el bot local.');
    } catch (e) {
      const code = e && e.code;
      if (['not_granted', 'sampling_disabled', 'not_declared', 'capability_disabled', 'capability_removed'].includes(code)) {
        sample = null; rivalMode = 'bot'; $('rival').value = 'bot';
        $('rival').querySelectorAll('option').forEach(o => { if (o.value !== 'bot') o.disabled = true; });
        noteFn('Manolo no está habilitado en esta vista. Sigue el bot local.');
      } else if (code === 'rate_limited') noteFn('Demasiadas consultas a Manolo. Esta jugada la hizo el bot local.');
      else noteFn('Manolo no respondió. Esta jugada la hizo el bot local.');
    }
  }
  if (!id) id = fallback();
  return { id: id, frase: frase };
}

function logHTML(items) {
  if (!items.length) return '<div class="ln meta">Las jugadas aparecen acá.</div>';
  return items.slice(-40).map(e => {
    const cls = e.meta ? 'meta' : (e.who || 'm');
    const who = e.meta ? '' : '<b>' + (e.who === 'p' ? 'Vos' : e.who === 'c' ? 'Manolo' : '·') + '</b>';
    return '<div class="ln ' + cls + '">' + who + esc(e.text) + '</div>';
  }).join('');
}
function renderLogTo(id, items) {
  const el = $(id);
  if (setHTML(el, logHTML(items))) el.scrollTop = el.scrollHeight;
}
function evLines(log, hn) {
  return log.filter(e => e.h === hn && !e.meta).map(e => (e.who === 'c' ? 'Yo: ' : e.who === 'p' ? 'Rival: ' : 'Mesa: ') + e.text).join('\n');
}
/* ---------- TRUCO: Manolo ---------- */
function tPending(G) {
  const q = G.q;
  if (q && q.responder === 'c') {
    if (q.kind === 'truco') return 'El rival cantó ' + TRUCO_NAMES[q.level - 1] + ' y tenés que responder.';
    if (q.kind === 'envido') return 'El rival cantó ' + q.calls.join(' + ') + ' (envido) y tenés que responder.';
    if (q.phase === 'mano') return 'Se aceptó el envido y sos el mano: tenés que decir cuántos tantos tenés (podés mentir).';
    if (q.phase === 'pie') return 'Se aceptó el envido. El rival (mano) dijo que tiene ' + q.N1 + '. Podés decir son buenas, dudar o decir un número mayor.';
    return 'Dijiste que tenías ' + q.N1 + ' y el rival dijo ' + q.N2 + ' (mayor). Podés decir son buenas o dudar.';
  }
  return 'Es tu turno de jugar y nadie espera una respuesta tuya.';
}

function tPrompt(G, ids) {
  const bz = [];
  for (let i = 0; i < 3; i++) {
    const r = G.played.p[i], y = G.played.c[i];
    if (!r && !y) break;
    let t = 'Baza ' + (i + 1) + ': rival ' + (r ? cname(r) : 'todavía no jugó') + ', vos ' + (y ? cname(y) : 'todavía no jugaste');
    if (G.bazas[i]) t += ' -> ' + (G.bazas[i] === 'c' ? 'ganaste vos' : G.bazas[i] === 'p' ? 'ganó el rival' : 'parda');
    bz.push(t);
  }
  const tIds = ids.filter(i => i.indexOf('tantos:') === 0).map(i => parseInt(i.slice(7), 10));
  const rest = ids.filter(i => i.indexOf('tantos:') !== 0).map(id => id.indexOf('card:') === 0 ? id + '  (jugar ' + cname({ n: id.slice(5).split('-')[0], p: id.slice(5).split('-')[1] }) + ')' : id);
  if (tIds.length) rest.push('tantos:<N>  (decir que tenés N puntos de envido; N entero entre ' + Math.min.apply(null, tIds) + ' y ' + Math.max.apply(null, tIds) + ', por ejemplo tantos:' + Math.min.apply(null, tIds) + ')');
  const nivel = G.trucoLevel === 0 ? 'ninguno' : TRUCO_NAMES[G.trucoLevel - 1] + ' (vale ' + ptsTruco(G.trucoLevel) + ')';
  return [
    'Sos Manolo y estás jugando al truco argentino 1 contra 1, baraja española de 40 cartas, a ' + G.goal + ' puntos, sin flor. Tenés que elegir tu próxima acción. No ves las cartas del rival. Jugá para ganar; podés hacer faroles y mentir con los tantos.',
    '',
    'FUERZA DE LAS CARTAS, de mayor a menor: 1 de espada, 1 de basto, 7 de espada, 7 de oro, los 3, los 2, 1 de copa y 1 de oro, los 12, los 11, los 10, 7 de copa y 7 de basto, los 6, los 5, los 4.',
    'MANO: se juegan hasta 3 bazas y gana quien gana 2. Si la primera es parda decide la segunda; si la primera la gana alguien y la segunda es parda, gana el de la primera; si las tres son pardas gana el mano.',
    'ENVIDO: solo en la primera baza y antes de que haya truco aceptado. Puntos reales: con 2 o 3 cartas del mismo palo, 20 + las dos más altas (10, 11 y 12 valen 0); si no, la carta más alta (10, 11 y 12 valen 0). Valen: envido 2, real envido 3, falta envido (lo que le falta al que va ganando para llegar a ' + G.goal + '). Si no se quiere, el que cantó se lleva lo cantado antes (1 punto si era el primer canto).',
    'DECIR LOS TANTOS: tras un quiero, el mano dice cuántos tantos tiene (puede mentir). El otro puede decir "buenas" (gana el mano), "dudo", o decir un número mayor (entonces el mano puede decir "buenas" o "dudo"). Si dudan, el que dijo el número muestra las cartas: si no coincide con sus tantos reales, pierde el envido; si coincide, gana el envido y se lleva 1 punto extra.',
    'TRUCO: truco vale 2, retruco 3, vale cuatro 4. Quien dice quiero puede subir después. Si no se quiere, el que cantó se lleva el nivel anterior (1 punto si era el primer truco). Irse al mazo regala los puntos vigentes.',
    '',
    'ESTADO:',
    '- Puntos: vos ' + G.score.c + ', rival ' + G.score.p + '.',
    '- El mano de esta mano es ' + (G.mano === 'c' ? 'vos' : 'el rival') + '.',
    '- Tus cartas sin jugar: ' + (G.hand.c.map(cname).join(', ') || 'ninguna') + '.',
    '- Tus tres cartas repartidas: ' + G.dealt.c.map(cname).join(', ') + '. Tus puntos reales de envido: ' + envidoPts(G.dealt.c) + ' (' + (G.envido.done ? 'el envido ya se resolvió' : 'el envido todavía no se resolvió') + ').',
    '- Truco aceptado hasta ahora: ' + nivel + '.',
    bz.length ? bz.map(x => '- ' + x).join('\n') : '- Todavía no se jugó ninguna carta.',
    '- Qué pasa ahora: ' + tPending(G),
    '',
    'LO QUE PASÓ EN ESTA MANO, EN ORDEN:',
    evLines(G.log, G.hn) || '(nada todavía)',
    '',
    'ACCIONES LEGALES (copiá el id exacto):',
    rest.join('\n'),
    '',
    'Respondé SOLO con un JSON como este: {"accion":"<id de la lista>","frase":"<opcional, hasta 8 palabras, en español rioplatense, como diría un jugador de truco>"}'
  ].join('\n');
}

/* ---------- TRUCO: pantalla ---------- */
let G = tNew();
let tBusy = false;
let tDealTime = -1e9;
let tSel = null;
let tantosKey = '', tantosVal = 0;
const dealing = t => performance.now() - t < 1100;
const T_LABEL = { envido: 'Envido', real: 'Real envido', falta: 'Falta envido', truco: '¡Truco!', retruco: '¡Retruco!', vale4: '¡Vale cuatro!', quiero: 'Quiero', noquiero: 'No quiero', mazo: 'Me voy al mazo', buenas: 'Son buenas', dudo: 'Dudo' };

function tRenderScore() {
  const side = (w, name) => {
    const s = G.score[w];
    return '<div class="side"><div class="nm"><span>' + name + '</span><span>' + (G.started && G.mano === w ? '<span class="badge">mano</span>' : '') + '</span></div>' +
      '<div class="pt">' + s + '<small>de ' + G.goal + '</small></div>' + palitos(s) + '</div>';
  };
  setHTML($('t-score'), side('p', 'Vos') + side('c', 'Manolo'));
}

function tRenderStatus() {
  const q = G.q;
  let h = '';
  if (G.started) {
    h += '<span class="pill">Mano ' + G.hn + '</span>';
    const t = ['Sin truco', 'Truco · vale 2', 'Retruco · vale 3', 'Vale cuatro · vale 4'][G.trucoLevel];
    h += '<span class="pill' + (G.trucoLevel ? ' hot' : '') + '">' + t + '</span>';
    if (q) h += '<span class="pill hot">' + (q.kind === 'truco' ? 'Cantado: ' + TRUCO_NAMES[q.level - 1] : q.kind === 'tantos' ? 'Envido: diciendo tantos' : 'Cantado: ' + q.calls.join(' + ')) + '</span>';
    h += '<span class="pill">' + (G.envido.done ? 'Envido jugado' : 'Envido abierto') + '</span>';
  }
  setHTML($('t-status'), h);
}

function tRenderTable() {
  const dl = dealing(tDealTime);
  let b = '';
  const n = G.started ? G.hand.c.length : 0;
  for (let i = 0; i < n; i++) b += backHTML({ cls: dl ? 'deal' : '', attrs: ' style="--d:' + (0.1 + i * 0.12) + 's"' });
  setHTML($('t-backs'), b);
  $('t-think').hidden = !(tBusy && actor(G) === 'c');
  setHTML($('t-mazo'), '<button class="pilebtn" style="--cw:46px;padding:2px" data-a="t:' + (!G.started || G.over ? 'start' : G.handOver ? 'next' : 'deck') + '" aria-label="' + (!G.started || G.over ? 'Repartir' : G.handOver ? 'Siguiente mano' : 'Mazo') + '">' + pileHTML(G.started ? 34 : 40, 'Mazo') + '</button>');
  let h = '';
  for (let i = 0; i < 3; i++) {
    const c = G.played.c[i], p = G.played.p[i], w = G.bazas[i];
    const label = w ? (w === 'parda' ? 'Parda' : (w === 'p' ? 'Para vos' : 'Para Manolo')) : 'Baza ' + (i + 1);
    h += '<div class="baza">' +
      (c ? cardHTML(c, { cls: w === 'c' ? 'win' : '' }) : '<div class="ph"></div>') +
      (p ? cardHTML(p, { cls: w === 'p' ? 'win' : '' }) : '<div class="ph"></div>') +
      '<div class="bz' + (w && w !== 'parda' ? ' w' : '') + '">' + label + '</div></div>';
  }
  setHTML($('t-table'), h);
}

function tCanPlay() { return G.started && actor(G) === 'p' && !G.q && !tBusy; }

function tRenderMine() {
  const dl = dealing(tDealTime);
  const mine = G.started ? G.hand.p : [];
  setHTML($('t-mine'), mine.map((c, i) => cardHTML(c, { tag: 'button', cls: dl ? 'deal' : '', attrs: ' data-card="' + cid(c) + '" style="--d:' + (0.2 + i * 0.12) + 's"' })).join(''));
  const can = tCanPlay();
  if (!can || !mine.some(c => cid(c) === tSel)) tSel = null;
  $('t-mine').querySelectorAll('button.card').forEach(b => { b.disabled = !can; b.classList.toggle('sel', can && b.dataset.card === tSel); });
  $('t-hint').textContent = can ? (tSel ? 'tocala de nuevo o arrastrala a la mesa' : 'tocá o arrastrá una carta a la mesa') : 'solo las ves vos';
}

function tRenderActions() {
  const el = $('t-actions');
  if (!G.started) { setHTML(el, '<p class="hint">Se juega a 30, uno contra uno, sin flor. Al repartir, el código sortea las cartas y tus cartas aparecen solo en esta pantalla.</p><button class="btn primary" data-a="t:start">Repartir</button>'); return; }
  if (G.over) { setHTML(el, '<div class="result"><p class="big">' + (G.winner === 'p' ? 'Ganaste la partida' : 'Ganó Manolo la partida') + '</p><p>' + G.score.p + ' a ' + G.score.c + '.</p><button class="btn primary" data-a="t:start">Jugar de nuevo</button></div>'); return; }
  if (G.handOver) { const r = G.result; setHTML(el, '<div class="result"><p class="big">' + (r.winner === 'p' ? 'Ganaste la mano' : 'Ganó Manolo la mano') + ' · +' + r.pts + '</p><p>' + esc(r.why) + '.</p><button class="btn primary" data-a="t:next">Siguiente mano</button></div>'); return; }
  if (actor(G) !== 'p') { setHTML(el, '<p class="hint">' + (tBusy ? 'Manolo está decidiendo.' : '') + '</p>'); return; }
  const q = G.q;
  if (q && q.kind === 'tantos') {
    const real = envidoPts(G.dealt.p);
    const key = G.hn + ':' + q.phase;
    const lo = q.phase === 'pie' ? q.N1 + 1 : 0, hi = 33;
    if (key !== tantosKey) { tantosKey = key; tantosVal = Math.max(lo, Math.min(hi, real)); }
    tantosVal = Math.max(lo, Math.min(hi, tantosVal));
    let ask;
    if (q.phase === 'mano') ask = 'Se quiso el envido. Decí tus tantos. Podés decir la verdad o mentir.';
    else if (q.phase === 'pie') ask = 'Manolo dice que tiene ' + q.N1 + '. ¿Son buenas, dudás o decís más?';
    else ask = 'Manolo dice que tiene ' + q.N2 + '. ¿Son buenas o dudás?';
    const dud = q.phase === 'mano' ? '' : '<div class="btns"><button class="btn" data-a="t:act:buenas">Son buenas</button><button class="btn danger" data-a="t:act:dudo">Dudo</button></div>';
    const stepper = (q.phase !== 'mano2' && lo <= hi) ? '<div class="stepper"><button data-a="t:step:-1" aria-label="Uno menos">−</button><output>' + tantosVal + '</output><button data-a="t:step:1" aria-label="Uno más">+</button></div><button class="btn primary" data-a="t:tantos">' + (q.phase === 'mano' ? 'Digo ' + tantosVal : 'Tengo ' + tantosVal) + '</button>' : '';
    setHTML(el, '<div class="tantos"><p class="speech">' + ask + '</p><p class="real">Tus tantos reales: ' + real + '</p>' + stepper + '</div>' + dud);
    return;
  }
  const ask = (q && q.responder === 'p') ? (q.kind === 'truco' ? 'Manolo canta ' + TRUCO_NAMES[q.level - 1] + '. ¿Qué hacés?' : 'Manolo canta ' + q.calls.join(' + ') + '. ¿Qué hacés?') : 'Tu turno: tirá una carta a la mesa o cantá.';
  const order = ['quiero', 'noquiero', 'truco', 'retruco', 'vale4', 'envido', 'real', 'falta', 'mazo'];
  const acts = legal(G, 'p').filter(x => x.id.indexOf('card:') !== 0).sort((x, y) => order.indexOf(x.id) - order.indexOf(y.id));
  setHTML(el, '<p class="speech">' + ask + '</p><div class="btns">' + acts.map(x => {
    const cls = (x.id === 'quiero' || x.id === 'truco' || x.id === 'retruco' || x.id === 'vale4') ? 'primary' : (x.id === 'mazo' || x.id === 'noquiero') ? 'danger' : '';
    return '<button class="btn ' + cls + '" data-a="t:act:' + x.id + '">' + T_LABEL[x.id] + '</button>';
  }).join('') + '</div>');
}

function tRender() { tRenderScore(); tRenderStatus(); tRenderTable(); renderLogTo('t-log', G.log); tRenderMine(); tRenderActions(); }

async function tOpponent() {
  const ids = legal(G, 'c').map(a => a.id);
  const r = await pickMove(tPrompt(G, ids), ids, () => botDecide(G, 'c', ids), t => say(G, null, t, true));
  if (r.frase) say(G, 'c', '«' + r.frase + '»');
  try { act(G, 'c', r.id); } catch (e) { act(G, 'c', ids[0]); }
}

async function tLoop() {
  if (tBusy) return;
  tBusy = true;
  try { for (;;) { tRender(); if (actor(G) !== 'c') break; await tOpponent(); } }
  finally { tBusy = false; tRender(); }
}

function tUserAct(id) {
  if (tBusy || actor(G) !== 'p') return;
  tSel = null;
  try { act(G, 'p', id); } catch (e) { return; }
  tLoop();
}
function tStart() { if (tBusy) return; G = tNew(); G.started = true; tSel = null; tantosKey = ''; tDealTime = performance.now(); dealHand(G, Math.random() < 0.5 ? 'p' : 'c'); tLoop(); }
function tNext() { if (tBusy || G.over || !G.handOver) return; tSel = null; tantosKey = ''; tDealTime = performance.now(); dealHand(G, other(G.mano)); tLoop(); }

dragCfg['t-mine'] = {
  zone: () => $('t-centro'), can: tCanPlay,
  drop: id => tUserAct('card:' + id),
  tap: id => { if (tSel === id) tUserAct('card:' + id); else { tSel = id; tRenderMine(); } }
};
/* ---------- CHINCHÓN: Manolo ---------- */
function cGroupText(arr) {
  const g = arr.groups.map(m => {
    const rs = m.filter(x => !isJ(x));
    const isSet = rs.every(x => x.n === rs[0].n);
    return (isSet ? 'pierna' : 'escalera') + ' [' + m.map(ccname).join(', ') + ']';
  });
  return (g.join('; ') || 'ninguna combinación') + '. Sueltas: ' + (arr.loose.map(ccname).join(', ') || 'ninguna') + ' (' + arr.dead + ' puntos).';
}

function cPrompt(C, ids) {
  const hand = C.hands.c;
  const top = C.desc[C.desc.length - 1];
  let opts;
  if (C.phase === 'draw') {
    opts = ['draw:mazo  (levantar una carta desconocida del mazo)'];
    if (ids.includes('draw:descarte')) opts.push('draw:descarte  (levantar ' + ccname(top) + ' del descarte)');
  } else {
    opts = ids.map(id => {
      const key = id.slice(id.indexOf(':') + 1);
      const c = hand.find(x => ccid(x) === key);
      const d = arrange(hand.filter(x => x !== c)).dead;
      return id + '  (' + (id.indexOf('cut:') === 0 ? 'cortás tirando ' : 'tirás ') + ccname(c) + '; te quedan ' + d + ' puntos sueltos)';
    });
  }
  return [
    'Sos Manolo y jugás al chinchón argentino 1 contra 1 con baraja española de 48 cartas (1 al 12 en cuatro palos) más 2 comodines, que valen como cualquier carta (50 cartas en total). Tenés que elegir tu próxima acción. No ves las cartas del rival.',
    '',
    'REGLAS: cada uno tiene 7 cartas. En tu turno levantás una carta del mazo (boca abajo) o la de arriba del descarte (boca arriba) y después tirás una al descarte o cortás. Combinaciones: escalera = 3 o más cartas seguidas del mismo palo (del 1 al 12, sin dar la vuelta); pierna = 3 o 4 cartas del mismo número en palos distintos. Los comodines reemplazan cualquier carta. Valor de las cartas sueltas: 1 a 9 valen su número, 10, 11 y 12 valen 10, el comodín vale 25. Cortar: al tirar tu última carta, las 7 que quedan deben formar combinaciones dejando como mucho 5 puntos sueltos; si no sobra nada cobrás -10. Chinchón: las 7 cartas forman una sola escalera del mismo palo (vale con comodines) y ganás la partida. Al cortar, el rival suma los puntos de sus cartas sueltas. Pierde quien pasa de ' + C.limit + ' puntos.',
    '',
    'ESTADO:',
    '- Puntos: vos ' + C.score.c + ', rival ' + C.score.p + '.',
    '- Tus cartas (' + hand.length + '): ' + hand.map(ccname).join(', ') + '.',
    '- Tu mejor armado ahora: ' + cGroupText(arrange(hand)),
    '- Carta de arriba del descarte: ' + (top ? ccname(top) : 'ninguna (el descarte está vacío)') + '. Mazo: ' + C.mazo.length + ' cartas.',
    '- Fase: ' + (C.phase === 'draw' ? 'tenés que levantar una carta.' : 'ya levantaste; tenés que tirar una carta o cortar.'),
    '',
    'LO QUE PASÓ EN ESTA MANO, EN ORDEN:',
    evLines(C.log, C.hn) || '(nada todavía)',
    '',
    'ACCIONES LEGALES (copiá el id exacto, sin la parte entre paréntesis):',
    opts.join('\n'),
    '',
    'Respondé SOLO con un JSON como este: {"accion":"<id de la lista>","frase":"<opcional, hasta 8 palabras, en español rioplatense>"}'
  ].join('\n');
}

/* ---------- CHINCHÓN: pantalla ---------- */
let C = cNew();
let cBusy = false;
let cDealTime = -1e9;
let cSel = null;

function cCanDraw() { return C.started && !C.over && !C.handOver && C.turn === 'p' && C.phase === 'draw' && !cBusy; }
function cCanDiscard() { return C.started && !C.over && !C.handOver && C.turn === 'p' && C.phase === 'discard' && !cBusy; }

function cRenderScore() {
  const side = (w, name) => {
    const s = C.score[w], pct = Math.min(100, s / C.limit * 100);
    return '<div class="side"><div class="nm"><span>' + name + '</span><span>' + (C.started && C.mano === w ? '<span class="badge">mano</span>' : '') + '</span></div>' +
      '<div class="pt">' + s + '<small>de ' + C.limit + '</small></div><div class="bar" role="img" aria-label="' + s + ' puntos"><i style="width:' + pct + '%"></i></div></div>';
  };
  setHTML($('c-score'), side('p', 'Vos') + side('c', 'Manolo'));
}

function cRenderStatus() {
  let h = '';
  if (C.started) {
    h += '<span class="pill">Mano ' + C.hn + '</span><span class="pill">Pierde quien pasa de ' + C.limit + '</span>';
    if (!C.handOver) h += '<span class="pill hot">' + (C.turn === 'p' ? 'Tu turno' : 'Turno de Manolo') + '</span>';
  }
  setHTML($('c-status'), h);
}

function cRenderTable() {
  const dl = dealing(cDealTime);
  let b = '';
  const n = C.started ? C.hands.c.length : 0;
  for (let i = 0; i < n; i++) b += backHTML({ cls: dl ? 'deal' : '', attrs: ' style="--d:' + (0.1 + i * 0.1) + 's"' });
  setHTML($('c-backs'), b);
  $('c-think').hidden = !(cBusy && cActor(C) === 'c');
  const go = cCanDraw();
  const mz = C.started ? C.mazo.length : 0;
  let desc = '<div class="pile">' + (C.started && C.desc.length ? '' : '<div class="ph" style="--cw:58px"></div>');
  if (C.started && C.desc.length > 1) desc += cardHTML(C.desc[C.desc.length - 2], { attrs: ' style="left:0;top:6px;position:absolute;opacity:.85"' });
  if (C.started && C.desc.length) desc += cardHTML(C.desc[C.desc.length - 1], { attrs: ' style="left:6px;top:0;position:absolute"' });
  desc += '</div><div class="cnt">Descarte</div>';
  setHTML($('c-piles'),
    '<button class="pilebtn' + (go ? ' go' : '') + '" data-a="c:draw:mazo"' + (go && (C.mazo.length || C.desc.length > 1) ? '' : ' disabled') + ' aria-label="Levantar del mazo">' + pileHTML(C.started ? mz : null, 'Mazo') + '</button>' +
    '<button class="pilebtn' + (go ? ' go' : '') + '" id="c-descbtn" data-a="c:draw:descarte"' + (go && C.desc.length ? '' : ' disabled') + ' aria-label="Levantar del descarte">' + desc + '</button>');
}

function cGroupsHTML() {
  const hand = C.hands.p;
  const arr = arrange(hand);
  const cut = (C.phase === 'discard' && cCanDiscard()) ? new Set(hand.filter(c => arrange(hand.filter(x => x !== c)).dead <= 5 && ccid(c) !== C.fromDesc).map(ccid)) : new Set();
  const dl = dealing(cDealTime);
  const one = (c, i) => cardHTML(c, { tag: 'button', cls: (dl ? 'deal ' : '') + (ccid(c) === C.drawn && !dl ? 'new ' : '') + (cut.has(ccid(c)) ? 'cutok' : ''), attrs: ' data-card="' + ccid(c) + '" style="--d:' + (0.2 + i * 0.1) + 's"' });
  let i = 0, h = '';
  for (const g of arr.groups) h += '<div class="grp">' + g.map(c => one(c, i++)).join('') + '</div>';
  if (arr.loose.length) h += '<div class="grp">' + arr.loose.map(c => one(c, i++)).join('') + '</div>';
  return { html: h, arr: arr, cut: cut };
}

function cRenderMine() {
  const el = $('c-mine');
  if (!C.started) { setHTML(el, ''); $('c-hint').textContent = 'solo las ves vos'; return; }
  const g = cGroupsHTML();
  setHTML(el, g.html);
  const can = cCanDiscard();
  if (!can || !C.hands.p.some(c => ccid(c) === cSel)) cSel = null;
  el.querySelectorAll('button.card').forEach(b => { b.disabled = !can; b.classList.toggle('sel', can && b.dataset.card === cSel); });
  $('c-hint').textContent = can ? (g.cut.size ? 'las tijeras marcan dónde podés cortar' : 'elegí una carta y tirala al descarte') : (cCanDraw() ? 'levantá del mazo o del descarte' : 'solo las ves vos');
}

function cRevealHTML(label, arr) {
  const grp = arr.groups.map(m => '<div class="grp">' + m.map(c => cardHTML(c)).join('') + '</div>').join('') +
    (arr.loose.length ? '<div class="grp">' + arr.loose.map(c => cardHTML(c)).join('') + '</div>' : '');
  return '<div class="rev"><span class="lbl">' + label + ' · sobran ' + arr.dead + '</span><div class="grps">' + grp + '</div></div>';
}

function cRenderActions() {
  const el = $('c-actions');
  if (!C.started) { setHTML(el, '<p class="hint">Cada uno juega con 7 cartas. Levantás, armás escaleras y piernas, y cortás cuando te sobran 5 puntos o menos. Los comodines valen como cualquier carta.</p><button class="btn primary" data-a="c:start">Repartir</button>'); return; }
  if (C.handOver) {
    const r = C.result, who = r.cutter === 'p' ? 'Cortaste' : 'Cortó Manolo';
    let title, body;
    if (r.chin) { title = r.cutter === 'p' ? '¡Chinchón! Ganaste' : 'Chinchón de Manolo'; body = 'Siete cartas seguidas del mismo palo: se termina la partida.'; }
    else { title = C.over ? (C.winner === 'p' ? 'Ganaste la partida' : 'Ganó Manolo la partida') : who; body = (r.cutter === 'p' ? 'Vos' : 'Manolo') + ' ' + (r.cutPts < 0 ? 'cobra -10' : 'suma ' + r.cutPts) + '. ' + (r.cutter === 'p' ? 'Manolo' : 'Vos') + ' suma ' + r.otherPts + '.'; }
    const mineArr = r.cutter === 'p' ? r.mine : r.theirs, theirArr = r.cutter === 'p' ? r.theirs : r.mine;
    setHTML(el, '<div class="result"><p class="big">' + title + '</p><p>' + body + '</p>' + cRevealHTML('Tus cartas', mineArr) + cRevealHTML('Cartas de Manolo', theirArr) +
      '<button class="btn primary" data-a="' + (C.over ? 'c:start' : 'c:next') + '">' + (C.over ? 'Jugar de nuevo' : 'Siguiente mano') + '</button></div>');
    return;
  }
  if (C.turn !== 'p') { setHTML(el, '<p class="hint">' + (cBusy ? 'Manolo está decidiendo.' : '') + '</p>'); return; }
  if (C.phase === 'draw') {
    const top = C.desc[C.desc.length - 1];
    setHTML(el, '<p class="ask">Tu turno: tocá el mazo' + (top ? ' o el descarte (' + ccname(top) + ')' : '') + ' para levantar.</p>');
    return;
  }
  const sel = cSel ? C.hands.p.find(c => ccid(c) === cSel) : null;
  if (!sel) { setHTML(el, '<p class="ask">Elegí la carta que tirás. Tocala y usá el botón, o arrastrala al descarte.</p>'); return; }
  const rest = arrange(C.hands.p.filter(x => x !== sel));
  const canCut = rest.dead <= 5 && ccid(sel) !== C.fromDesc;
  setHTML(el, '<p class="ask">Tirar ' + esc(ccname(sel)) + ': te quedan ' + rest.dead + ' puntos sueltos.</p><div class="btns"><button class="btn primary" data-a="c:discard">Descartar</button><button class="btn' + (canCut ? ' primary' : '') + '" data-a="c:cut"' + (canCut ? '' : ' disabled') + '>' + (rest.dead === 0 ? 'Cortar con -10' : 'Cortar') + '</button></div>');
}

function cRender() { cRenderScore(); cRenderStatus(); cRenderTable(); renderLogTo('c-log', C.log); cRenderMine(); cRenderActions(); }

async function cOpponent() {
  const ids = cLegal(C, 'c');
  const r = await pickMove(cPrompt(C, ids), ids, () => cBot(C, 'c', ids), t => cSay(C, null, t, true));
  if (r.frase) cSay(C, 'c', '«' + r.frase + '»');
  try { cAct(C, 'c', r.id); } catch (e) { cAct(C, 'c', ids[0]); }
}

async function cLoop() {
  if (cBusy) return;
  cBusy = true;
  try { for (;;) { cRender(); if (cActor(C) !== 'c') break; await cOpponent(); } }
  finally { cBusy = false; cRender(); }
}

function cUserAct(id) {
  if (cBusy || cActor(C) !== 'p') return;
  cSel = null;
  try { cAct(C, 'p', id); } catch (e) { return; }
  cLoop();
}
function cStart() { if (cBusy) return; C = cNew(); C.started = true; cSel = null; cDealTime = performance.now(); cDeal(C, Math.random() < 0.5 ? 'p' : 'c'); cLoop(); }
function cNext() { if (cBusy || C.over || !C.handOver) return; cSel = null; cDealTime = performance.now(); cDeal(C, other(C.mano)); cLoop(); }

dragCfg['c-mine'] = {
  zone: () => $('c-descbtn'), can: cCanDiscard,
  drop: id => cUserAct('discard:' + id),
  tap: id => { cSel = (cSel === id) ? null : id; cRenderMine(); cRenderActions(); }
};
/* ---------- SOLITARIO ---------- */
let S = sNew();
let sAuto = false;
let sTimer = null;
let sDealPulse = false;
function sAnimateDeal() { const el = $('s-grid'); el.classList.remove('dealing'); void el.offsetWidth; el.classList.add('dealing'); setTimeout(() => el.classList.remove('dealing'), 1100); }

function sStopAuto() { sAuto = false; if (sTimer) { clearTimeout(sTimer); sTimer = null; } }

function sRender() {
  setHTML($('s-deck'), pileHTML(S.aside.length + S.slots.filter(x => !x.up).length, 'Tocar'));
  const up = S.slots.filter(s => s.up).length;
  const kings = S.aside.filter(c => rankOf(c.n) === 10).length;
  setHTML($('s-status'), '<span class="pill">Reveladas ' + up + ' de 36</span><span class="pill' + (kings ? ' hot' : '') + '">Reyes afuera ' + kings + ' de 4</span><span class="pill">Pasos ' + S.moves + '</span>');

  const target = S.hand && !S.over ? slotIndex(S.hand) : -1;
  let g = '<span></span>';
  for (let c = 1; c <= 9; c++) g += '<span class="cn">' + c + '</span>';
  for (let r = 0; r < 4; r++) {
    g += '<span class="rl" style="color:var(--' + SOL_ROWS[r] + ')"><svg aria-hidden="true"><use href="#s-' + SOL_ROWS[r] + '"/></svg></span>';
    for (let c = 0; c < 9; c++) {
      const i = r * 9 + c, s = S.slots[i];
      if (s.up) g += cardHTML(s.card, { cls: 'slot', attrs: ' style="--i:' + i + '"' });
      else g += backHTML({ tag: 'button', cls: 'slot' + (i === target ? ' target' : ''), attrs: ' style="--i:' + i + '" data-a="s:slot:' + i + '"' + (i === target ? '' : ' disabled') });
    }
  }
  setHTML($('s-grid'), g);

  setHTML($('s-aside'), S.aside.map((c, i) => {
    const king = rankOf(c.n) === 10;
    return cardHTML(c, { tag: 'button', attrs: ' data-a="s:pick:' + i + '"' + ((S.hand || S.over || king) ? ' disabled' : '') });
  }).join('') || '<span class="hint">Ninguna</span>');

  setHTML($('s-hand'), S.hand ? cardHTML(S.hand, { tag: 'button', cls: 'new', attrs: ' data-a="s:place" aria-label="Colocar ' + S.hand.n + ' de ' + S.hand.p + ' en su lugar"' }) : '<span class="hint">Nada</span>');
  renderLogTo('s-log', S.log.map(t => ({ h: 0, who: null, text: t, meta: false })));

  let a;
  if (S.over) {
    a = '<div class="result"><p class="big">' + (S.win ? 'Ganaste' : 'Perdiste') + '</p><p>' + (S.win ? 'Las 36 cartas quedaron en su lugar en ' + S.moves + ' pasos.' : 'Salieron los cuatro reyes y quedaron ' + (36 - up) + ' cartas boca abajo.') + '</p><button class="btn primary" data-a="s:new">Repartir de nuevo</button></div>';
  } else if (S.hand) {
    a = '<p class="ask">Tocá la carta en mano o su lugar marcado para colocarla y levantar la que estaba ahí.</p><div class="btns"><button class="btn primary" data-a="s:place">Colocar</button><button class="btn' + (sAuto ? ' danger' : '') + '" data-a="s:auto">' + (sAuto ? 'Parar' : 'Jugar solo') + '</button></div>';
  } else {
    a = '<p class="ask">Elegí con cuál de las cartas apartadas empezar (los reyes no sirven para empezar).</p><div class="btns"><button class="btn' + (sAuto ? ' danger' : '') + '" data-a="s:auto">' + (sAuto ? 'Parar' : 'Jugar solo') + '</button><button class="btn" data-a="s:new">Repartir de nuevo</button></div>';
  }
  setHTML($('s-actions'), a);
}

function sStep() {
  if (S.over) return false;
  if (!S.hand) {
    const k = S.aside.findIndex(c => rankOf(c.n) < 10);
    if (k < 0) return false;
    return sPick(S, k);
  }
  return sPlace(S);
}
function sAutoTick() {
  sTimer = null;
  if (!sAuto) return;
  if (!sStep() || S.over) { sAuto = false; sRender(); return; }
  sRender();
  sTimer = setTimeout(sAutoTick, 420);
}
function sToggleAuto() {
  if (sAuto) { sStopAuto(); sRender(); return; }
  sAuto = true; sRender();
  sTimer = setTimeout(sAutoTick, 250);
}

/* ---------- Pestañas y clics ---------- */
const FOOT = {
  truco: 'A 30 puntos, uno contra uno, sin flor. En el envido cada uno dice sus tantos y se puede mentir; si dudan, hay que mostrar. Tus cartas nunca salen de esta pantalla.',
  chin: 'Chinchón con 48 cartas y 2 comodines que valen como cualquier carta. Podés cortar con 5 puntos o menos sueltos, y con siete cartas seguidas del mismo palo hacés chinchón y ganás. Tus cartas se ordenan solas con el mejor armado.',
  sol: 'Cada carta tiene su lugar fijo: el palo marca la fila y el número la columna (la sota es la 8 y el caballo la 9). El rey corta la cadena. Es casi todo suerte: se gana cerca de 1 de cada 10 partidas, elijas la carta que elijas.'
};
let game = 'truco';
function showGame(g) {
  game = g;
  ['truco', 'chin', 'sol'].forEach(k => { $('g-' + k).hidden = k !== g; });
  document.querySelectorAll('.tabs button').forEach(b => b.setAttribute('aria-selected', b.dataset.game === g ? 'true' : 'false'));
  $('rivalbox').hidden = g === 'sol' || !sample;
  $('foot').textContent = FOOT[g] + (sample && g !== 'sol' ? ' Si elegís a Manolo con IA, cada jugada suya consulta a la IA con sus cartas y lo que ya se jugó, y usa tu cuota de uso.' : '');
  try { localStorage.setItem('cartas-game', g); } catch (e) {}
  if (g === 'sol') sRender();
}

document.addEventListener('click', e => {
  const b = e.target.closest('button');
  if (!b) return;
  if (b.dataset.game) { showGame(b.dataset.game); return; }
  if (b.dataset.card) { if (e.detail === 0) { const cfg = dragCfg[b.parentElement.closest('.mine').id]; if (cfg && cfg.can()) cfg.tap(b.dataset.card); } return; }
  const a = b.dataset.a;
  if (!a || b.disabled) return;
  const p = a.split(':'), arg = p.slice(2).join(':');
  if (p[0] === 't') {
    if (p[1] === 'act') tUserAct(arg);
    else if (p[1] === 'step') { tantosVal += parseInt(arg, 10); tRenderActions(); }
    else if (p[1] === 'tantos') tUserAct('tantos:' + tantosVal);
    else if (p[1] === 'start') tStart();
    else if (p[1] === 'next') tNext();
  } else if (p[0] === 'c') {
    if (p[1] === 'draw') cUserAct('draw:' + arg);
    else if (p[1] === 'discard' && cSel) cUserAct('discard:' + cSel);
    else if (p[1] === 'cut' && cSel) cUserAct('cut:' + cSel);
    else if (p[1] === 'start') cStart();
    else if (p[1] === 'next') cNext();
  } else if (p[0] === 's') {
    if (p[1] === 'new') { sStopAuto(); S = sNew(); sRender(); }
    else if (p[1] === 'pick') { sStopAuto(); if (sPick(S, parseInt(arg, 10))) sRender(); }
    else if (p[1] === 'place' || p[1] === 'slot') { if (!sAuto && sPlace(S)) sRender(); }
    else if (p[1] === 'auto') sToggleAuto();
    else if (p[1] === 'deal') sAnimateDeal();
  }
});

$('rival').addEventListener('change', e => { rivalMode = e.target.value; });
attachDrag('t-mine');
attachDrag('c-mine');

tRender(); cRender(); sRender();
let startGame = 'truco';
try { const sv = localStorage.getItem('cartas-game'); if (sv === 'chin' || sv === 'sol' || sv === 'truco') startGame = sv; } catch (e) {}
showGame(startGame);
(async function init() {
  try { if (window.claude && window.claude.use) sample = await window.claude.use('sample'); } catch (e) { sample = null; }
  if (!sample) {
    rivalMode = 'bot'; $('rival').value = 'bot';
    $('rival').querySelectorAll('option').forEach(o => { if (o.value !== 'bot') o.disabled = true; });
  }
  showGame(game);
})();
})();

if('serviceWorker' in navigator){window.addEventListener('load',function(){navigator.serviceWorker.register('sw.js').catch(function(){});});}