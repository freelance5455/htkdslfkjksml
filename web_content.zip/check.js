
function cambiarCampo(modo){
 const campo=document.getElementById('campo'), svg=document.getElementById('lineasCampo');
 const medio=modo==='medio'; campo.classList.toggle('medio',medio); campo.classList.toggle('completo',!medio);
 svg.setAttribute('viewBox',medio?'0 0 680 525':'0 0 680 1050');
}


let numeroJugador=1,elementos=[],moviendo=null,colorFlecha="#ffeb3b",colorMaterial="#ff5722",msgTimer, flechaSeleccionada=null,elementoSeleccionado=null;
let colorJugador="#1976d2", animacionActiva=false, animacionPausada=false, animacionVelocidad=1, animacionFrame=0, animacionInicio=0, animacionTiempo=0, animacionUltimo=0, animacionTrayectorias=[], posicionesIniciales=[];
function mensaje(t){let m=document.getElementById("mensaje");m.textContent=t;m.style.opacity=1;clearTimeout(msgTimer);msgTimer=setTimeout(()=>m.style.opacity=0,1400)}
function boton(icono,titulo,fn){let b=document.createElement("button");b.className="herramienta";b.textContent=icono;b.title=titulo;b.setAttribute("aria-label",titulo);b.onclick=fn;document.getElementById("herramientas").appendChild(b);return b}
function etiquetaHerramientas(t){let x=document.createElement("div");x.className="grupo-etiqueta";x.textContent=t;document.getElementById("herramientas").appendChild(x)}
function paleta(colores,actual,alElegir){let g=document.createElement("div");g.className="colores";colores.forEach(([c,n])=>{let b=document.createElement("button");b.className="color"+(actual===c?" activo":"");b.style.background=c;b.title=n;b.setAttribute("aria-label",n);b.onclick=()=>{g.querySelectorAll(".color").forEach(x=>x.classList.remove("activo"));b.classList.add("activo");alElegir(c,n)};g.appendChild(b)});document.getElementById("herramientas").appendChild(g);return g}
const COLORES_MATERIAL=[["#ff5722","Naranja"],["#ffeb3b","Amarillo"],["#ff5252","Rojo"],["#40c4ff","Azul"],["#69f0ae","Verde"],["#fff","Blanco"],["#ff80ab","Rosa"],["#b388ff","Morado"]];
const COLORES_JUGADOR=[["#1976d2","Azul"],["#e53935","Rojo"],["#fdd835","Amarillo"],["#43a047","Verde"],["#fb8c00","Naranja"],["#8e24aa","Morado"],["#eeeeee","Blanco"],["#212121","Negro"]];
function svgIconoCampo(medio=false){
 const s=medio
 ? '<svg viewBox="0 0 40 40" aria-hidden="true"><rect x="4" y="3" width="32" height="34" rx="1.5"/><path d="M4 37h32M11 3v8h18V3M11 37V29h18v8M14 29a6 6 0 0 1 12 0"/></svg>'
 : '<svg viewBox="0 0 40 40" aria-hidden="true"><rect x="4" y="2" width="32" height="36" rx="1.5"/><path d="M4 20h32M12 2v7h16V2M12 38v-7h16v7"/><circle cx="20" cy="20" r="5"/></svg>';
 return s;
}
function botonCampo(titulo,medio,fn){let b=document.createElement("button");b.className="herramienta herramienta-campo";b.innerHTML=svgIconoCampo(medio);b.title=titulo;b.setAttribute("aria-label",titulo);b.onclick=fn;document.getElementById("herramientas").appendChild(b);return b}
function abrir(tipo){let rapido=document.getElementById("capturaFotogramaRapida");if(rapido)rapido.style.display=tipo==="animacion"?"flex":"none";let h=document.getElementById("herramientas");h.innerHTML="";document.getElementById("panel").style.display="block";
if(tipo==="jugadores"){boton("👤","Jugador",crearJugador);boton("🧤","Portero",crearPortero);boton("⚽","Balón",crearBalon)}
if(tipo==="material"){
 boton("🔶","Cono",()=>crear("cono"));boton("⭕","Aro",()=>crear("aro"));boton("●","Chino (disco plano)",()=>crear("chino"));boton("📏","Pica",()=>crear("pica"));let bv=boton("∩","Micro valla de salto",()=>crear("valla"));bv.classList.add("iconValla");boton("🪜","Escalera",crearEscalera);boton("🥅","Miniportería",()=>crear("mini"));
 etiquetaHerramientas("COLOR DEL MATERIAL");paleta(COLORES_MATERIAL,colorMaterial,(c,n)=>{colorMaterial=c;mensaje("Color: "+n)});
 }
if(tipo==="movimientos"){
boton("➜","Desplazamiento del jugador sin balón",()=>crearFlecha("recta"));
boton("┄➜","Conducción con balón en línea recta",()=>crearFlecha("discontinua"));
boton("〰➜","Conducción con balón en curva",()=>crearFlecha("conduccion-curva"));
boton("···➜","Movimiento del balón sin jugador (pase o golpeo)",()=>crearFlecha("balon"));
let g=document.createElement("div");g.className="colores";[["#ffeb3b","Amarillo"],["#ff5252","Rojo"],["#40c4ff","Azul"],["#fff","Blanco"],["#69f0ae","Verde"],["#ff80ab","Rosa"]].forEach(([c,n])=>{let b=document.createElement("button");b.className="color"+(colorFlecha===c?" activo":"");b.style.background=c;b.title=n;b.onclick=()=>{colorFlecha=c;g.querySelectorAll(".color").forEach(x=>x.classList.remove("activo"));b.classList.add("activo");if(flechaSeleccionada){flechaSeleccionada.dataset.color=c;dibujarFlecha(flechaSeleccionada,flechaSeleccionada.dataset.tipo,c)}mensaje("Color seleccionado: "+n)};g.appendChild(b)});h.appendChild(g);
let c=document.createElement("div");c.id="controlesFlecha";c.style.display="flex";
[["↶","Girar a la izquierda",()=>ajustarFlecha(-15,0)],["↷","Girar a la derecha",()=>ajustarFlecha(15,0)],["↔−","Acortar",()=>ajustarFlecha(0,-0.1)],["↔+","Alargar",()=>ajustarFlecha(0,0.1)]].forEach(([ic,tx,fn])=>{let b=document.createElement("button");b.textContent=ic;b.title=tx;b.onclick=fn;c.appendChild(b)});
h.appendChild(c)}
if(tipo==="texto")boton("✏️","Añadir texto",crearTexto);
if(tipo==="animacion"){boton("＋","Capturar fotograma",capturarFotograma);boton("▶️","Reproducir secuencia",reproducirAnimacion);boton("⏸️","Pausar",pausarAnimacion);boton("↻","Volver al inicio",reiniciarAnimacion);boton("🗑️","Borrar fotogramas",borrarFotogramas);boton("🐢","Velocidad lenta",()=>cambiarVelocidad(.5));boton("1×","Velocidad normal",()=>cambiarVelocidad(1));boton("🐇","Velocidad rápida",()=>cambiarVelocidad(2));actualizarEtiquetaFotogramas()}
if(tipo==="archivos"){boton("💾","Guardar ejercicio",abrirGuardar);boton("📂","Cargar ejercicio",abrirCargar)}
 if(tipo!=="archivos"&&tipo!=="animacion")boton("⌫","Eliminar seleccionado",borrarSeleccionado);
}
function abrirBiblioteca(){
  document.getElementById("panel").style.display="none";
  document.getElementById("biblioteca").style.display="flex";
  renderBiblioteca();renderMisEjercicios();
}
function cerrarBiblioteca(){
  document.getElementById("biblioteca").style.display="none";
}
function cargarPDFBiblioteca(inp){
  if(!inp.files||!inp.files[0])return;
  if(pdfBibliotecaUrl)URL.revokeObjectURL(pdfBibliotecaUrl);
  pdfBibliotecaUrl=URL.createObjectURL(inp.files[0]);
  document.getElementById("pdfEstado").textContent="PDF cargado: "+inp.files[0].name;
  document.getElementById("visorPDF").src=pdfBibliotecaUrl;
  document.getElementById("visorPDFWrap").style.display="block";
  mensaje("PDF de ejercicios cargado");
}
function renderBiblioteca(){
  let q=(document.getElementById("buscadorEjercicios").value||"").toLowerCase().trim();
  let cat=document.getElementById("filtroEjercicios").value;
  let lista=EJERCICIOS.filter(x=>(!cat||x.categoria===cat)&&(!q||((x.n+" "+x.nombre+" "+x.categoria).toLowerCase().includes(q))));
  let cont=document.getElementById("listaEjercicios");
  cont.innerHTML="";
  lista.forEach(x=>{
    let b=document.createElement("button");b.className="tarjeta-ejercicio";
    b.innerHTML='<span class="num-ej">'+x.n+'</span><span class="datos-ej"><strong>'+x.nombre+'</strong><small>'+x.categoria+'</small></span><span class="pagina-ej">Pág. '+x.pagina+'</span>';
    b.onclick=()=>abrirEjercicioPDF(x);
    cont.appendChild(b);
  });
  document.getElementById("contadorEjercicios").textContent=lista.length+" ejercicios";
}
let ejercicioSeleccionado=null;
function serializarPizarra(){return elementos.map(e=>({clase:e.className,texto:(e.classList.contains("jugador")?(e.childNodes[0]?.textContent||""):e.textContent),left:e.style.left,top:e.style.top,tipo:e.dataset.tipo||"",color:e.dataset.color||"",fondo:e.style.backgroundColor||"",dorsal:e.dataset.dorsal||"",nombre:e.dataset.nombre||"",angulo:e.dataset.angulo||0,longitud:e.dataset.longitud||1}));}
function restaurarPizarra(d){elementos.forEach(e=>e.remove());elementos=[];d.forEach(o=>{let e=document.createElement("div");e.className=o.clase;if((o.clase||"").includes("flecha")){e.dataset.tipo=o.tipo||"recta";e.dataset.color=o.color||"#ffeb3b";e.dataset.angulo=o.angulo||0;e.dataset.longitud=o.longitud||1;dibujarFlecha(e,e.dataset.tipo,e.dataset.color);e.style.transform="translate(-50%,-50%) rotate("+e.dataset.angulo+"deg) scaleX("+e.dataset.longitud+")"}else if((o.clase||"").includes("escalera")){for(let i=0;i<4;i++)e.appendChild(document.createElement("span"))}else e.textContent=o.texto;if(e.classList.contains("jugador")){e.dataset.dorsal=o.dorsal||o.texto||"";e.style.setProperty("--camiseta",o.color||o.fondo||"#1976d2");e.style.setProperty("--brazo",o.color||o.fondo||"#1976d2")}if(o.nombre)ponerNombre(e,o.nombre);if(o.fondo&&e.classList.contains("jugador")){e.style.backgroundColor=o.fondo;e.dataset.color=o.color||o.fondo;e.style.setProperty("--camiseta",o.color||o.fondo);e.style.setProperty("--brazo",o.color||o.fondo)}if(o.color&&e.classList.contains("chino")){e.style.backgroundColor=o.color;e.dataset.color=o.color}if(o.color&&e.classList.contains("cono")){e.style.borderBottomColor=o.color;e.dataset.color=o.color}if(o.color&&e.classList.contains("aro")){e.style.borderColor=o.color;e.dataset.color=o.color}e.style.left=o.left;e.style.top=o.top;document.getElementById("campo").appendChild(e);elementos.push(e);activarMovimiento(e)});}
function guardarCopiaEjercicio(){let nombre=prompt("Nombre para guardar este ejercicio:",ejercicioSeleccionado?"Tarea "+ejercicioSeleccionado.n+" - "+ejercicioSeleccionado.nombre:"Mi ejercicio");if(!nombre||!nombre.trim())return;let lista=[];try{lista=JSON.parse(localStorage.getItem("misEjerciciosPizarra")||"[]")}catch(e){}lista.unshift({id:Date.now(),nombre:nombre.trim(),origen:ejercicioSeleccionado?"Tarea "+ejercicioSeleccionado.n+" · "+ejercicioSeleccionado.nombre:"Creado desde pizarra",datos:serializarPizarra(),fondoEjercicio:ejercicioFondoActual,fecha:new Date().toLocaleDateString("es-ES")});localStorage.setItem("misEjerciciosPizarra",JSON.stringify(lista));mensaje("Copia guardada en Mis ejercicios");renderMisEjercicios();}
function abrirCopiaEjercicio(id){let lista=[];try{lista=JSON.parse(localStorage.getItem("misEjerciciosPizarra")||"[]")}catch(e){}let x=lista.find(a=>a.id===id);if(!x)return;restaurarPizarra(x.datos||[]);ponerFondoEjercicio(x.fondoEjercicio||null);cerrarBiblioteca();mensaje("Ejercicio cargado: "+x.nombre)}
function borrarCopiaEjercicio(id){if(!confirm("¿Borrar esta copia guardada?"))return;let lista=[];try{lista=JSON.parse(localStorage.getItem("misEjerciciosPizarra")||"[]")}catch(e){}localStorage.setItem("misEjerciciosPizarra",JSON.stringify(lista.filter(a=>a.id!==id)));renderMisEjercicios();}
function renderMisEjercicios(){let cont=document.getElementById("misEjercicios");if(!cont)return;let lista=[];try{lista=JSON.parse(localStorage.getItem("misEjerciciosPizarra")||"[]")}catch(e){}cont.innerHTML="";lista.forEach(x=>{let fila=document.createElement("div");fila.className="tarjeta-personal";let b=document.createElement("button");b.type="button";b.className="tarjeta-personal";b.style.flex="1";b.innerHTML="<span></span><small></small>";b.querySelector("span").textContent=x.nombre;b.querySelector("small").textContent=x.fecha||"";b.onclick=()=>abrirCopiaEjercicio(x.id);let del=document.createElement("button");del.className="accion-personal";del.textContent="🗑";del.onclick=()=>borrarCopiaEjercicio(x.id);fila.append(b,del);cont.appendChild(fila)});}
let ejercicioFondoActual=null;
function quitarFondoEjercicio(){let img=document.getElementById("fondoDiagramaEjercicio");if(img)img.remove();ejercicioFondoActual=null;}
function ponerFondoEjercicio(n){quitarFondoEjercicio();if(!n)return;let img=document.createElement("img");img.id="fondoDiagramaEjercicio";img.alt="Dibujo original del ejercicio";img.draggable=false;img.src="ejercicios/tarea"+n+".jpg";img.onerror=function(){mensaje("No se pudo cargar el dibujo de la tarea "+n)};document.getElementById("campo").appendChild(img);ejercicioFondoActual=n;}
function abrirEnPizarra(){if(elementos.length&&!confirm("Se limpiará el campo actual para recrear esta tarea. ¿Continuar?"))return;let x=ejercicioSeleccionado;if(!x)return;borrarTodo();ponerFondoEjercicio(x.n);cerrarBiblioteca();let t=document.createElement("div");t.className="elemento texto";t.textContent="Tarea "+x.n+" · "+x.nombre;t.style.left="50%";t.style.top="5%";añadir(t);mensaje("Dibujo original cargado: añade y mueve tus elementos encima");}
function abrirEjercicioPDF(x){
  ejercicioSeleccionado=x;
  document.getElementById("detalleEjercicio").textContent="Tarea "+x.n+" · "+x.nombre+" · "+x.categoria;
  document.getElementById("accionesDetalle").innerHTML="";let abrirBtn=document.createElement("button");abrirBtn.textContent="⚽ Abrir en pizarra";abrirBtn.onclick=abrirEnPizarra;let guardarBtn=document.createElement("button");guardarBtn.textContent="💾 Guardar mi versión";guardarBtn.onclick=guardarCopiaEjercicio;document.getElementById("accionesDetalle").append(abrirBtn,guardarBtn);
  if(pdfBibliotecaUrl){
    document.getElementById("visorPDF").src=pdfBibliotecaUrl+"#page="+x.pagina;
    document.getElementById("visorPDFWrap").style.display="block";
  }else{
    document.getElementById("visorPDFWrap").style.display="none";
    document.getElementById("pdfEstado").textContent="Dibujos originales incluidos. Puedes cargar el PDF si quieres consultar la explicación completa.";
  }
}
const EJERCICIOS=[
[1,"Macroentorno","Acciones Físicas"],[2,"Circuito Fartlek","Acciones Físicas"],[3,"Circuito condicional","Acciones Físicas"],[4,"Gana la línea","Acciones Físicas"],[5,"Llega y defiende","Acciones Físicas"],[6,"RSA de 3 acciones","Acciones Físicas"],
[7,"Desbloquea al compañero","Juegos Lúdicos"],[8,"Protege tu balón","Juegos Lúdicos"],[9,"Tiro al cono","Juegos Lúdicos"],[10,"Escalas enfrentadas","Juegos Lúdicos"],[11,"Vel. de reacción + 2x2","Juegos Lúdicos"],[12,"Vel. de reacción + 4X4","Juegos Lúdicos"],[13,"Relevos con túnel","Juegos Lúdicos"],[14,"Relevos con tiro","Juegos Lúdicos"],[15,"Aguanta el balón","Juegos Lúdicos"],[16,"Circuito de conducción","Juegos Lúdicos"],[17,"A la disputa","Juegos Lúdicos"],[18,"Encuentra el color","Juegos Lúdicos"],[19,"Activación con balón","Juegos Lúdicos"],[20,"Habilidad + 2x2","Juegos Lúdicos"],[21,"Escapa de la marca","Juegos Lúdicos"],[22,"Que no pase","Juegos Lúdicos"],[23,"El cerrojazo","Juegos Lúdicos"],[24,"Superar el 1x1","Juegos Lúdicos"],
[25,"Figura técnica 1","Acciones Técnicas"],[26,"Figura técnica 2","Acciones Técnicas"],[27,"Figura técnica 3","Acciones Técnicas"],[28,"Figura técnica 4","Acciones Técnicas"],[29,"Figura técnica 5","Acciones Técnicas"],[30,"Figura técnica 6","Acciones Técnicas"],[31,"Figura técnica 7","Acciones Técnicas"],[32,"Figura técnica 8","Acciones Técnicas"],[33,"Figura técnica 9","Acciones Técnicas"],[34,"Figura técnica 10","Acciones Técnicas"],[35,"Espacio reducido 1","Acciones Técnicas"],
[36,"Espacio reducido 2","Acciones Técnicas"],[37,"Espacio reducido 3","Acciones Técnicas"],[38,"Espacio reducido 4","Acciones Técnicas"],[39,"Espacio reducido 5","Acciones Técnicas"],
[40,"Rueda de pase 1","Ruedas de Pase"],[41,"Rueda de pase 2","Ruedas de Pase"],[42,"Rueda de pase 3","Ruedas de Pase"],[43,"Rueda de pase 4","Ruedas de Pase"],[44,"Rueda de pase 5","Ruedas de Pase"],
[45,"Posesión con carrera","Juegos de Posesión"],[46,"Posesión en 2 zonas","Juegos de Posesión"],[47,"Posesión + Comodines","Juegos de Posesión"],[48,"Posesión + Trans. 5x4","Juegos de Posesión"],[49,"Posesión 7X7","Juegos de Posesión"],[50,"Posesión 7X7+2","Juegos de Posesión"],[51,"Posesión porterías int.","Juegos de Posesión"],[52,"Posesión en 4 zonas","Juegos de Posesión"],[53,"Posesión sectorial","Juegos de Posesión"],
[54,"Rondo dinámico","Rondos"],[55,"Rondos móviles","Rondos"],[56,"Rondo con espacios","Rondos"],
[57,"1x1 con 4 apoyos","Situaciones de Juego"],[58,"Presionar al que recibe","Situaciones de Juego"],[59,"Entrar a defender","Situaciones de Juego"],[60,"Habilita al extremo","Situaciones de Juego"],[61,"Romper en conducción","Situaciones de Juego"],[62,"Ataque 3x2+1","Situaciones de Juego"],[63,"Persecución","Situaciones de Juego"],[64,"Juego directo","Situaciones de Juego"],[65,"6x6+6","Situaciones de Juego"],[66,"Defender el 2x1","Situaciones de Juego"],[67,"Jugar dentro-fuera","Situaciones de Juego"],[68,"Cinturón de seguridad","Situaciones de Juego"],[69,"Acciones defensivas","Situaciones de Juego"],[70,"Filtrar pase","Situaciones de Juego"],[71,"Ganar el medio","Situaciones de Juego"],[72,"Juego por banda","Situaciones de Juego"],[73,"Def. bloque + Presión","Situaciones de Juego"],[74,"Salida de balón","Situaciones de Juego"],[75,"Encontrar el hueco","Situaciones de Juego"],
[76,"Roba y ataca","Ataque-Defensa"],[77,"Pressing + Transición","Ataque-Defensa"],[78,"Transiciones en 5x3","Ataque-Defensa"],[79,"Transic. con despeje","Ataque-Defensa"],[80,"Transiciones 5x5+3","Ataque-Defensa"],[81,"7X4+1 con transición","Ataque-Defensa"],[82,"Doble área 1","Ataque-Defensa"],[83,"Doble área 2","Ataque-Defensa"],[84,"Doble área + Profund.","Ataque-Defensa"],
[85,"Partido a 1 portería","Partidos"],[86,"Partido 8X8","Partidos"],[87,"Partido condicionado 1","Partidos"],[88,"Partido condicionado 2","Partidos"],[89,"Partido modificado","Partidos"],
[90,"Rondos + Finalización","Finalizaciones"],[91,"Finalización en 1x1","Finalizaciones"],[92,"Doble área de finaliz.","Finalizaciones"],[93,"Finalización + velocidad","Finalizaciones"],[94,"Finalización en minis","Finalizaciones"],[95,"Finalizaciones 1","Finalizaciones"],[96,"Finalizaciones 2","Finalizaciones"],[97,"Finalizaciones 3","Finalizaciones"],[98,"Finalizaciones 4","Finalizaciones"],[99,"Finalizaciones 5","Finalizaciones"],[100,"Finalizaciones 6","Finalizaciones"]
].map(x=>({n:x[0],nombre:x[1],categoria:x[2],pagina:x[0]+3}));
let pdfBibliotecaUrl=null;
function abrirCampo(){let h=document.getElementById("herramientas");h.innerHTML="";document.getElementById("panel").style.display="block";botonCampo("Campo entero",false,()=>{cambiarCampo("completo");cerrarPanel();mensaje("Campo entero")});botonCampo("Medio campo",true,()=>{cambiarCampo("medio");cerrarPanel();mensaje("Medio campo")})}
function cerrarPanel(){document.getElementById("panel").style.display="none";let rapido=document.getElementById("capturaFotogramaRapida");if(rapido)rapido.style.display="none"}
function añadir(e){document.getElementById("campo").appendChild(e);elementos.push(e);activarMovimiento(e)}
function centro(e){e.style.left="50%";e.style.top="50%"}
function ponerNombre(e,n){e.dataset.nombre=n||"";e.title=n||"Toca para editar jugador";let viejo=e.querySelector(".nombre-jugador");if(viejo)viejo.remove();if(n){let l=document.createElement("span");l.className="nombre-jugador";l.textContent=n;e.appendChild(l)}}
function crearJugador(){let e=document.createElement("div");e.className="elemento jugador";let dorsal=numeroJugador;e.textContent=dorsal;e.dataset.dorsal=dorsal;numeroJugador=numeroJugador%11+1;e.dataset.color=colorJugador;e.style.backgroundColor=colorJugador;e.style.setProperty("--camiseta",colorJugador);e.style.setProperty("--brazo",colorJugador);ponerNombre(e,"");centro(e);añadir(e);if(document.getElementById("campo").classList.contains("modo3d"))prepararFigura3D(e);mensaje("Jugador "+dorsal+" añadido · tócalo para editar")}
function crearPortero(){let e=document.createElement("div");e.className="elemento jugador portero";e.textContent="P";e.dataset.dorsal="P";e.dataset.color="#f1c40f";e.style.setProperty("--camiseta","#f1c40f");e.style.setProperty("--brazo","#f1c40f");ponerNombre(e,"");e.style.left="50%";e.style.top="85%";añadir(e);if(document.getElementById("campo").classList.contains("modo3d"))prepararFigura3D(e);mensaje("Portero añadido · tócalo para editar")}
function editarJugador(e){seleccionarElemento(e);let h=document.getElementById("herramientas");h.innerHTML="";document.getElementById("panel").style.display="block";paleta(COLORES_JUGADOR,e.dataset.color||getComputedStyle(e).backgroundColor,(c,n)=>{e.dataset.color=c;e.style.backgroundColor=c;e.style.setProperty("--camiseta",c);e.style.setProperty("--brazo",c);if(e.classList.contains("portero"))e.classList.remove("portero");e.style.color=(["#fdd835","#eeeeee","#fff","#69f0ae"].includes(c)?"#222":"#fff");if(e.classList.contains("portero"))e.classList.remove("portero");mensaje("Jugador: "+n)});boton("✏️","Poner o cambiar nombre",()=>{let n=prompt("Nombre del jugador (déjalo vacío para quitarlo):",e.dataset.nombre||"");if(n!==null){ponerNombre(e,n.trim());mensaje(n.trim()?"Nombre añadido":"Nombre quitado")}});boton("⌫","Eliminar jugador",borrarSeleccionado);boton("✓","Terminar",cerrarPanel)}
function crearBalon(){let e=document.createElement("div");e.className="elemento balon";e.textContent="⚽";centro(e);añadir(e);mensaje("Balón añadido")}
function crear(t){let e=document.createElement("div");e.className="elemento "+t;if(t==="cono"){e.style.borderBottomColor=colorMaterial;e.dataset.color=colorMaterial}if(t==="aro"){e.style.borderColor=colorMaterial;e.dataset.color=colorMaterial}if(t==="chino"){e.style.backgroundColor=colorMaterial;e.dataset.color=colorMaterial}centro(e);añadir(e);mensaje((t==="chino"?"Chino":"Material")+" añadido") }
function crearEscalera(){let e=document.createElement("div");e.className="elemento escaleraIcono";e.textContent="🪜";centro(e);añadir(e);mensaje("Escalera añadida")}
function crearTexto(){let t=prompt("Escribe el texto:");if(t===null||!t.trim())return;let e=document.createElement("div");e.className="elemento texto";e.textContent=t.trim();centro(e);añadir(e);mensaje("Texto añadido")}
function crearFlecha(tipo){let e=document.createElement("div");e.className="elemento flecha";e.dataset.tipo=tipo;e.dataset.color=colorFlecha;dibujarFlecha(e,tipo,colorFlecha);centro(e);añadir(e);let nombres={recta:"desplazamiento sin balón",discontinua:"conducción con balón","conduccion-curva":"conducción curva con balón",balon:"movimiento del balón"};mensaje("Flecha de "+(nombres[tipo]||tipo)+" añadida")}
function dibujarFlecha(e,tipo,color){let s=document.createElementNS("http://www.w3.org/2000/svg","svg");s.setAttribute("viewBox","0 0 120 60");let p=document.createElementNS("http://www.w3.org/2000/svg","path");let curva=tipo==="conduccion-curva";p.setAttribute("d",curva?"M 8 48 Q 58 -2 104 28":"M 8 30 L 104 30");p.setAttribute("fill","none");p.setAttribute("stroke",color);p.setAttribute("stroke-width","5");p.setAttribute("stroke-linecap","round");p.setAttribute("stroke-linejoin","round");if(tipo==="discontinua"||curva)p.setAttribute("stroke-dasharray","9 8");if(tipo==="balon")p.setAttribute("stroke-dasharray","2 8");let h=document.createElementNS("http://www.w3.org/2000/svg","path");h.setAttribute("d",curva?"M 91 16 L 106 28 L 90 39":"M 91 18 L 106 30 L 91 42");h.setAttribute("fill","none");h.setAttribute("stroke",color);h.setAttribute("stroke-width","5");h.setAttribute("stroke-linecap","round");h.setAttribute("stroke-linejoin","round");s.append(p,h);e.innerHTML="";e.appendChild(s)}
function seleccionarElemento(e){if(elementoSeleccionado&&elementoSeleccionado!==e)elementoSeleccionado.classList.remove("elemento-seleccionado");elementoSeleccionado=e;e.classList.add("elemento-seleccionado");if(e.classList.contains("flecha")){if(flechaSeleccionada)flechaSeleccionada.classList.remove("seleccionada");flechaSeleccionada=e;e.classList.add("seleccionada")}}
function borrarSeleccionado(){if(!elementoSeleccionado){mensaje("Toca primero el elemento que quieres borrar");return}elementos=elementos.filter(x=>x!==elementoSeleccionado);elementoSeleccionado.remove();if(flechaSeleccionada===elementoSeleccionado)flechaSeleccionada=null;elementoSeleccionado=null;cerrarPanel();mensaje("Elemento eliminado")}
function activarMovimiento(e){
 let inicio=null,desplazado=false;
 e.addEventListener("pointerdown",ev=>{ev.preventDefault();seleccionarElemento(e);moviendo=e;inicio={x:ev.clientX,y:ev.clientY};desplazado=false;e.setPointerCapture(ev.pointerId)});
 e.addEventListener("pointermove",ev=>{if(moviendo!==e)return;if(inicio&&Math.hypot(ev.clientX-inicio.x,ev.clientY-inicio.y)>5)desplazado=true;let r=document.getElementById("campo").getBoundingClientRect(),x=Math.max(14,Math.min(r.width-14,ev.clientX-r.left)),y=Math.max(14,Math.min(r.height-14,ev.clientY-r.top));e.style.left=x+"px";e.style.top=y+"px"});
 let fin=()=>{if(moviendo===e){moviendo=null;if(!desplazado&&e.classList.contains("jugador"))editarJugador(e)}inicio=null};e.addEventListener("pointerup",fin);e.addEventListener("pointercancel",()=>{if(moviendo===e)moviendo=null;inicio=null})
}
function ajustarFlecha(grados,longitud){if(!flechaSeleccionada){mensaje("Selecciona primero una flecha");return}
 let a=(parseFloat(flechaSeleccionada.dataset.angulo)||0)+grados;
 let l=Math.max(0.45,Math.min(2.2,(parseFloat(flechaSeleccionada.dataset.longitud)||1)+longitud));
 flechaSeleccionada.dataset.angulo=a;flechaSeleccionada.dataset.longitud=l;
 flechaSeleccionada.style.transform="translate(-50%,-50%) rotate("+a+"deg) scaleX("+l+")";flechaSeleccionada.dataset.angulo=a;flechaSeleccionada.dataset.longitud=l;
}
function borrarTodo(){elementos.forEach(e=>e.remove());elementos=[];quitarFondoEjercicio();numeroJugador=1;elementoSeleccionado=null;flechaSeleccionada=null;cerrarPanel();mensaje("Pizarra borrada")}
function obtenerEjerciciosGuardados(){let lista=[];try{lista=JSON.parse(localStorage.getItem("misEjerciciosPizarra")||"[]")}catch(e){lista=[]}return Array.isArray(lista)?lista:[]}
function guardarEjerciciosGuardados(lista){localStorage.setItem("misEjerciciosPizarra",JSON.stringify(lista))}
function abrirGuardar(){document.getElementById("nombreEjercicioInput").value="";document.getElementById("guardarModal").style.display="flex";setTimeout(()=>document.getElementById("nombreEjercicioInput").focus(),50)}
function cerrarGuardar(){document.getElementById("guardarModal").style.display="none"}
function confirmarGuardar(){let nombre=(document.getElementById("nombreEjercicioInput").value||"").trim();if(!nombre){mensaje("Escribe un nombre para el ejercicio");return}let lista=obtenerEjerciciosGuardados();lista.unshift({id:Date.now(),nombre,origen:"Creado desde pizarra",datos:serializarPizarra(),fondoEjercicio:ejercicioFondoActual,fecha:new Date().toLocaleDateString("es-ES"),fotogramas:exportarFotogramas()});guardarEjerciciosGuardados(lista);cerrarGuardar();cerrarPanel();renderMisEjercicios();mensaje("Ejercicio guardado: "+nombre)}
function abrirCargar(){renderCargarLista();document.getElementById("cargarModal").style.display="flex"}
function cerrarCargar(){document.getElementById("cargarModal").style.display="none"}
function renderCargarLista(){let cont=document.getElementById("listaCargar");cont.innerHTML="";let lista=obtenerEjerciciosGuardados();if(!lista.length){let p=document.createElement("div");p.className="sinGuardados";p.textContent="No hay ejercicios guardados todavía.";cont.appendChild(p);return}lista.forEach(x=>{let fila=document.createElement("div");fila.className="filaGuardado";let b=document.createElement("button");b.className="nombreGuardado";b.innerHTML="<strong></strong><small></small>";b.querySelector("strong").textContent=x.nombre;b.querySelector("small").textContent=(x.fecha||"");b.onclick=()=>cargarEjercicioGuardado(x.id);let d=document.createElement("button");d.className="borrarGuardado";d.textContent="🗑️";d.title="Borrar ejercicio";d.onclick=(ev)=>{ev.stopPropagation();if(confirm("¿Borrar "+x.nombre+"?")){guardarEjerciciosGuardados(lista.filter(y=>y.id!==x.id));renderCargarLista();renderMisEjercicios();}};fila.append(b,d);cont.appendChild(fila)})}
function cargarEjercicioGuardado(id){let x=obtenerEjerciciosGuardados().find(a=>a.id===id);if(!x)return;restaurarPizarra(x.datos||[]);ponerFondoEjercicio(x.fondoEjercicio||null);importarFotogramas(x.fotogramas||[]);cerrarCargar();cerrarPanel();mensaje("Ejercicio cargado: "+x.nombre)}
function guardar(){abrirGuardar()}
function cargar(){abrirCargar()}

function cambiarVelocidad(v){animacionVelocidad=v;mensaje("Velocidad "+(v===.5?"lenta":v===1?"normal":"rápida"))}
function posicionPx(el){let r=el.getBoundingClientRect(),c=document.getElementById("campo").getBoundingClientRect();return {x:r.left+r.width/2-c.left,y:r.top+r.height/2-c.top}}
function puntoFlecha(f,extremo){let p=posicionPx(f),a=(parseFloat(f.dataset.angulo)||0)*Math.PI/180,esc=parseFloat(f.dataset.longitud)||1,dx=Math.cos(a)*52*esc,dy=Math.sin(a)*52*esc;return extremo==="inicio"?{x:p.x-dx,y:p.y-dy}:{x:p.x+dx,y:p.y+dy}}
function prepararTrayectorias(){let flechas=elementos.filter(e=>e.classList.contains("flecha")),jugadores=elementos.filter(e=>e.classList.contains("jugador")),bolas=elementos.filter(e=>e.classList.contains("balon")),usados=new Set(),tray=[];jugadores.forEach(j=>{let jp=posicionPx(j),mejor=null,dist=Infinity;flechas.filter(f=>["recta","discontinua","conduccion-curva"].includes(f.dataset.tipo)).forEach(f=>{if(usados.has(f))return;let ini=puntoFlecha(f,"inicio"),d=Math.hypot(jp.x-ini.x,jp.y-ini.y);if(d<dist){dist=d;mejor=f}});if(mejor){usados.add(mejor);tray.push({el:j,from:jp,to:puntoFlecha(mejor,"fin"),duration:1800,curve:mejor.dataset.tipo==="conduccion-curva"})}});if(bolas.length){let b=bolas[0],bp=posicionPx(b),bf=flechas.filter(f=>f.dataset.tipo==="balon"&& !usados.has(f)).sort((a,c)=>Math.hypot(bp.x-puntoFlecha(a,"inicio").x,bp.y-puntoFlecha(a,"inicio").y)-Math.hypot(bp.x-puntoFlecha(c,"inicio").x,bp.y-puntoFlecha(c,"inicio").y))[0];if(bf)tray.push({el:b,from:bp,to:puntoFlecha(bf,"fin"),duration:1100})}return tray}
function reproducirAnimacion(){if(animacionActiva&&animacionPausada){animacionPausada=false;animacionUltimo=performance.now();animacionFrame=requestAnimationFrame(pasoAnimacion);mensaje("Animación reanudada");return}if(animacionFrame)cancelAnimationFrame(animacionFrame);animacionTrayectorias=prepararTrayectorias();if(!animacionTrayectorias.length){mensaje("Coloca flechas junto a los jugadores para marcar sus recorridos");return}posicionesIniciales=animacionTrayectorias.map(t=>({el:t.el,left:t.el.style.left,top:t.el.style.top}));animacionActiva=true;animacionPausada=false;animacionTiempo=0;animacionUltimo=performance.now();animacionTrayectorias.forEach(t=>t.el.classList.add("animando"));animacionFrame=requestAnimationFrame(pasoAnimacion);mensaje("Reproduciendo jugada") }
function pasoAnimacion(ahora){if(!animacionActiva||animacionPausada)return;animacionTiempo+=(ahora-animacionUltimo)*animacionVelocidad;animacionUltimo=ahora;let transcurrido=animacionTiempo,terminadas=0;animacionTrayectorias.forEach(t=>{let p=Math.min(1,transcurrido/t.duration),suave=p*p*(3-2*p),x,y;if(t.curve){let cx=(t.from.x+t.to.x)/2,cy=(t.from.y+t.to.y)/2-55;x=(1-suave)*(1-suave)*t.from.x+2*(1-suave)*suave*cx+suave*suave*t.to.x;y=(1-suave)*(1-suave)*t.from.y+2*(1-suave)*suave*cy+suave*suave*t.to.y}else{x=t.from.x+(t.to.x-t.from.x)*suave;y=t.from.y+(t.to.y-t.from.y)*suave}t.el.style.left=x+"px";t.el.style.top=y+"px";if(p>=1)terminadas++});if(terminadas===animacionTrayectorias.length){animacionActiva=false;animacionTrayectorias.forEach(t=>t.el.classList.remove("animando"));mensaje("Jugada finalizada");return}animacionFrame=requestAnimationFrame(pasoAnimacion)}
function pausarAnimacion(){if(!animacionActiva){mensaje("No hay ninguna animación en marcha");return}animacionPausada=true;cancelAnimationFrame(animacionFrame);mensaje("Animación pausada")}
function reiniciarAnimacion(){if(animacionFrame)cancelAnimationFrame(animacionFrame);animacionActiva=false;animacionPausada=false;animacionTrayectorias.forEach(t=>t.el.classList.remove("animando"));posicionesIniciales.forEach(p=>{p.el.style.left=p.left;p.el.style.top=p.top});animacionTrayectorias=[];mensaje("Posiciones iniciales restauradas")}


// Animación por fotogramas clave: cada captura registra la posición conjunta de todos los elementos.
let fotogramasClave=[],reproduccionClave=null,pausaClave=false,tiempoPausaClave=0,ultimoTiempoClave=0;
function asegurarIdsClave(){elementos.forEach((e,i)=>{if(!e.dataset.claveId)e.dataset.claveId='obj-'+i+'-'+Math.random().toString(36).slice(2,7)})}
function posicionesClave(){asegurarIdsClave();const c=document.getElementById('campo').getBoundingClientRect();return elementos.map(e=>{const r=e.getBoundingClientRect();return {id:e.dataset.claveId,x:(r.left+r.width/2-c.left)/c.width,y:(r.top+r.height/2-c.top)/c.height}})}
function actualizarEtiquetaFotogramas(){const h=document.getElementById('herramientas');if(!h)return;let el=document.getElementById('contadorFotogramasClave');if(!el){el=document.createElement('div');el.id='contadorFotogramasClave';el.style.cssText='color:white;font-size:12px;padding:4px 8px;min-width:100%;text-align:center';h.appendChild(el)}el.textContent='Fotogramas: '+fotogramasClave.length;let rapido=document.getElementById('contadorFotogramasRapido');if(rapido)rapido.textContent='Fotogramas: '+fotogramasClave.length}
function capturarFotograma(){if(reproduccionClave){mensaje('Detén o reinicia la reproducción antes de capturar');return}if(!elementos.length){mensaje('Coloca primero jugadores o balón');return}const p=posicionesClave();fotogramasClave.push({posiciones:p});actualizarEtiquetaFotogramas();mensaje('Fotograma '+fotogramasClave.length+' capturado')}
function borrarFotogramas(){detenerClave();fotogramasClave=[];actualizarEtiquetaFotogramas();mensaje('Fotogramas borrados')}
function exportarFotogramas(){return fotogramasClave.map(f=>({posiciones:f.posiciones.map(p=>({...p}))}))}
function importarFotogramas(f){fotogramasClave=Array.isArray(f)?f.map(x=>({posiciones:(x.posiciones||[]).map(p=>({...p}))})):[];asegurarIdsClave();actualizarEtiquetaFotogramas()}
function mapaElementosClave(){asegurarIdsClave();return new Map(elementos.map(e=>[e.dataset.claveId,e]))}
function aplicarFotogramaClave(f){const c=document.getElementById('campo').getBoundingClientRect(),m=mapaElementosClave();(f?.posiciones||[]).forEach(p=>{const e=m.get(p.id);if(e){e.style.left=(p.x*c.width)+'px';e.style.top=(p.y*c.height)+'px'}})}
function detenerClave(){if(animacionFrame)cancelAnimationFrame(animacionFrame);reproduccionClave=null;pausaClave=false;animacionActiva=false}
function reproducirAnimacion(){if(fotogramasClave.length<2){mensaje('Captura al menos dos fotogramas con el botón +');return}detenerClave();aplicarFotogramaClave(fotogramasClave[0]);reproduccionClave={segmento:0,inicio:performance.now(),duracion:1400};animacionActiva=true;ultimoTiempoClave=performance.now();animacionFrame=requestAnimationFrame(pasoClave);mensaje('Reproduciendo secuencia')}
function pasoClave(ahora){if(!reproduccionClave||pausaClave)return;const r=reproduccionClave,delta=ahora-r.inicio,progreso=Math.min(1,delta/r.duracion),a=fotogramasClave[r.segmento],b=fotogramasClave[r.segmento+1],c=document.getElementById('campo').getBoundingClientRect(),m=mapaElementosClave(),dest=new Map((b.posiciones||[]).map(p=>[p.id,p]));(a.posiciones||[]).forEach(p=>{const q=dest.get(p.id),e=m.get(p.id);if(!q||!e)return;const t=progreso*progreso*(3-2*progreso);e.style.left=((p.x+(q.x-p.x)*t)*c.width)+'px';e.style.top=((p.y+(q.y-p.y)*t)*c.height)+'px'});if(progreso>=1){r.segmento++;if(r.segmento>=fotogramasClave.length-1){detenerClave();mensaje('Secuencia finalizada');return}r.inicio=ahora}animacionFrame=requestAnimationFrame(pasoClave)}
function pausarAnimacion(){if(!reproduccionClave){mensaje('No hay reproducción activa');return}if(!pausaClave){pausaClave=true;tiempoPausaClave=performance.now();cancelAnimationFrame(animacionFrame);mensaje('Pausado')}else{const r=reproduccionClave;r.inicio+=performance.now()-tiempoPausaClave;pausaClave=false;animacionFrame=requestAnimationFrame(pasoClave);mensaje('Continuando')}}
function reiniciarAnimacion(){detenerClave();if(fotogramasClave.length)aplicarFotogramaClave(fotogramasClave[0]);mensaje('Secuencia al inicio')}


function prepararFigura3D(j){
 if(!j||!j.classList.contains('jugador'))return;
 if(j.querySelector('.figura3d'))return;
 const dorsal=j.dataset.dorsal||(j.childNodes[0]?.textContent||'');
 j.dataset.dorsal=dorsal;
 const f=document.createElement('div');f.className='figura3d';
 f.innerHTML='<span class="sombra"></span><span class="cabeza"></span><span class="pelo"></span><span class="cuello"></span><span class="brazo izq"></span><span class="brazo der"></span><span class="mano izq"></span><span class="mano der"></span><span class="tronco"><span class="numero"></span></span><span class="pierna izq"></span><span class="pierna der"></span><span class="bota izq"></span><span class="bota der"></span>';
 f.querySelector('.numero').textContent=dorsal;
 j.appendChild(f);
}
function actualizarFiguras3D(){document.querySelectorAll('#campo .jugador').forEach(j=>{if(document.getElementById('campo').classList.contains('modo3d'))prepararFigura3D(j);else{const f=j.querySelector('.figura3d');if(f)f.remove();}})}
function alternarVista3D(){
 const campo=document.getElementById('campo'),boton=document.getElementById('toggleVista3d');if(!campo||!boton)return;
 const activa=campo.classList.toggle('modo3d');
 if(activa)actualizarFiguras3D();else actualizarFiguras3D();
 boton.classList.toggle('activo',activa);boton.textContent=activa?'2D':'3D';
 boton.setAttribute('aria-label',activa?'Volver a vista 2D':'Activar vista 3D');
 const tr=campo.style.transform||'';
 campo.style.transform=activa?tr.replace(/\s*rotateX\(24deg\)/g,'')+' rotateX(24deg)':tr.replace(/\s*rotateX\(24deg\)/g,'');
 if(typeof mensaje==='function')mensaje(activa?'Vista 3D con jugadores completos':'Vista 2D activada');
}
