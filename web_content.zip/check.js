
(()=>{
const c=document.getElementById('game'),ctx=c.getContext('2d'),$=id=>document.getElementById(id);
let W=0,H=0,player,shots,enemies,enemyShots,pickups,particles,score,lives,stage,frame,running=false,keys={left:false,right:false,fire:false},thumb={active:false,x:0,pointerId:null},lastShot=0,spawn=0,boss=null,weapon=0,weaponNames=['BLASTER','SPREAD','LASER','ROCKET','PLASMA'],weaponPower=0,audio=null,soundEnabled=true,high=0,stageKills=0,coins=+(localStorage.getItem('ssCoins')||0),upgrade=+(localStorage.getItem('ssUpgrade')||0),musicTimer=null;
try{high=+(localStorage.getItem('ssHigh')||0)}catch(e){}
const stars=Array.from({length:95},()=>({x:Math.random(),y:Math.random(),s:.5+Math.random()*2,a:Math.random()*8}));
function resize(){let d=Math.min(devicePixelRatio||1,2);W=innerWidth;H=innerHeight;c.width=W*d;c.height=H*d;ctx.setTransform(d,0,0,d,0,0);if(player){player.y=H-105;player.x=Math.min(W-25,Math.max(25,player.x));}}
addEventListener('resize',resize);addEventListener('pagehide',()=>{saveProgress();if(musicTimer)clearInterval(musicTimer)});
function sound(freq=500,dur=.07,type='square',vol=.035){if(!soundEnabled)return;try{audio=audio||new(window.AudioContext||window.webkitAudioContext)();let o=audio.createOscillator(),g=audio.createGain();o.type=type;o.frequency.value=freq;g.gain.value=vol;o.connect(g);g.connect(audio.destination);o.start();g.gain.exponentialRampToValueAtTime(.001,audio.currentTime+dur);o.stop(audio.currentTime+dur)}catch(e){}}
function saveProgress(){try{localStorage.setItem('ssCoins',coins);localStorage.setItem('ssUpgrade',upgrade);localStorage.setItem('ssProgress',JSON.stringify({stage,score,high}));}catch(e){}}
function hud(){$('score').textContent=score;$('lives').textContent=lives;$('level').textContent=stage;$('bossText').textContent=boss?'BOSS':'—';$('health').style.width=(player.hp/100*100)+'%';}
function reset(){player={x:W/2,y:H-105,r:18,speed:5.6+upgrade*.18,hp:100+upgrade*8,inv:0};shots=[];enemies=[];enemyShots=[];pickups=[];particles=[];let saved={};try{saved=JSON.parse(localStorage.getItem('ssProgress')||'{}')}catch(e){}score=+(saved.score||0);lives=3;stage=Math.max(1,Math.min(15,+(saved.stage||1)));frame=0;spawn=0;boss=null;weapon=0;weaponPower=0;stageKills=0;lastShot=0;hud();}
function circle(x,y,r,col){ctx.fillStyle=col;ctx.beginPath();ctx.arc(x,y,r,0,Math.PI*2);ctx.fill();}
function background(){
 // Deep-space base with layered nebula haze
 const base=ctx.createLinearGradient(0,0,0,H);base.addColorStop(0,'#050916');base.addColorStop(.52,'#10172d');base.addColorStop(1,'#070b19');ctx.fillStyle=base;ctx.fillRect(0,0,W,H);
 const nebula=ctx.createRadialGradient(W*.22,H*.34,2,W*.22,H*.34,Math.max(W,H)*.72);nebula.addColorStop(0,'rgba(76,75,151,.24)');nebula.addColorStop(.42,'rgba(42,63,115,.12)');nebula.addColorStop(1,'rgba(5,9,22,0)');ctx.fillStyle=nebula;ctx.fillRect(0,0,W,H);
 const haze=ctx.createRadialGradient(W*.82,H*.62,0,W*.82,H*.62,Math.max(W,H)*.48);haze.addColorStop(0,'rgba(20,116,143,.12)');haze.addColorStop(1,'rgba(5,9,22,0)');ctx.fillStyle=haze;ctx.fillRect(0,0,W,H);
 // Distant ringed planet, kept subtle behind combat
 const px=W*.82,py=H*.23,pr=Math.min(W,H)*.105;
 ctx.save();ctx.translate(px,py);ctx.rotate(-.24);ctx.strokeStyle='rgba(132,174,211,.22)';ctx.lineWidth=Math.max(3,pr*.13);ctx.beginPath();ctx.ellipse(0,0,pr*1.85,pr*.48,0,Math.PI,Math.PI*2);ctx.stroke();
 const pg=ctx.createRadialGradient(-pr*.38,-pr*.42,pr*.05,0,0,pr*1.2);pg.addColorStop(0,'#91a9b8');pg.addColorStop(.32,'#526d88');pg.addColorStop(.72,'#263d5c');pg.addColorStop(1,'#101a31');ctx.fillStyle=pg;ctx.beginPath();ctx.arc(0,0,pr,0,Math.PI*2);ctx.fill();ctx.save();ctx.beginPath();ctx.arc(0,0,pr,0,Math.PI*2);ctx.clip();ctx.globalAlpha=.2;for(let k=0;k<7;k++){ctx.fillStyle=k%2?'#b7c6c9':'#172d4b';ctx.beginPath();ctx.ellipse(-pr*.2,(-.75+k*.25)*pr,pr*(.8-k*.045),pr*.08,0,0,Math.PI*2);ctx.fill();}ctx.restore();ctx.globalAlpha=1;ctx.strokeStyle='rgba(169,211,235,.25)';ctx.lineWidth=1;ctx.beginPath();ctx.ellipse(0,0,pr*1.85,pr*.48,0,0,Math.PI);ctx.stroke();ctx.restore();
 // Three depth layers of stars
 for(let s of stars){s.y+=.00045*s.s*(1+stage*.12);if(s.y>1)s.y=0;const tw=.35+.65*Math.abs(Math.sin(frame*.018+s.a));ctx.globalAlpha=tw*(s.s>1.7?.9:.55);circle(s.x*W,s.y*H,s.s,s.s>1.7?'#ffffff':'#b9d5f5');if(s.s>1.85&&tw>.92){ctx.strokeStyle='rgba(205,231,255,.45)';ctx.lineWidth=.7;ctx.beginPath();ctx.moveTo(s.x*W-3,s.y*H);ctx.lineTo(s.x*W+3,s.y*H);ctx.moveTo(s.x*W,s.y*H-3);ctx.lineTo(s.x*W,s.y*H+3);ctx.stroke();}}
 ctx.globalAlpha=1;
 // faint atmospheric light at the bottom edge
 const rim=ctx.createLinearGradient(0,H*.78,0,H);rim.addColorStop(0,'rgba(20,55,90,0)');rim.addColorStop(1,'rgba(26,79,115,.12)');ctx.fillStyle=rim;ctx.fillRect(0,H*.78,W,H*.22);
}
// Original cinematic superhero-fleet interceptor: broad swept wings, twin engine pods and an armored central fuselage.
function ship(){
 ctx.save();ctx.translate(player.x,player.y);
 const pulse=.72+.28*Math.sin(frame*.24);
 // twin blue engine exhausts
 for(const side of [-1,1]){
  const ex=side*21;const flame=ctx.createLinearGradient(0,10,0,35);
  flame.addColorStop(0,'#eaffff');flame.addColorStop(.35,'#53eaff');flame.addColorStop(1,'rgba(40,100,255,0)');
  ctx.fillStyle=flame;ctx.beginPath();ctx.moveTo(ex-5,10);ctx.lineTo(ex,34+Math.random()*5);ctx.lineTo(ex+5,10);ctx.closePath();ctx.fill();
 }
 // swept armored wings
 const wing=ctx.createLinearGradient(-42,-8,42,18);wing.addColorStop(0,'#34445f');wing.addColorStop(.48,'#d8e4ef');wing.addColorStop(1,'#536983');
 ctx.fillStyle=wing;ctx.strokeStyle='#f0f7ff';ctx.lineWidth=1.5;ctx.beginPath();ctx.moveTo(0,-19);ctx.lineTo(39,7);ctx.lineTo(47,22);ctx.lineTo(20,16);ctx.lineTo(9,10);ctx.lineTo(0,18);ctx.lineTo(-9,10);ctx.lineTo(-20,16);ctx.lineTo(-47,22);ctx.lineTo(-39,7);ctx.closePath();ctx.fill();ctx.stroke();
 // segmented armor plating and engraved panel seams
 ctx.fillStyle='rgba(17,35,57,.62)';ctx.beginPath();ctx.moveTo(-31,8);ctx.lineTo(-18,4);ctx.lineTo(-11,10);ctx.lineTo(-27,14);ctx.closePath();ctx.fill();ctx.beginPath();ctx.moveTo(31,8);ctx.lineTo(18,4);ctx.lineTo(11,10);ctx.lineTo(27,14);ctx.closePath();ctx.fill();
 ctx.strokeStyle='rgba(255,255,255,.48)';ctx.lineWidth=.8;ctx.beginPath();ctx.moveTo(-34,5);ctx.lineTo(-22,1);ctx.moveTo(34,5);ctx.lineTo(22,1);ctx.stroke();
 // wing armor panels and illuminated trim
 ctx.strokeStyle='#70eaff';ctx.globalAlpha=.85;ctx.lineWidth=1.6;ctx.beginPath();ctx.moveTo(-36,12);ctx.lineTo(-13,8);ctx.lineTo(-5,-5);ctx.moveTo(36,12);ctx.lineTo(13,8);ctx.lineTo(5,-5);ctx.stroke();ctx.globalAlpha=1;
 // reinforced center fuselage
 const hull=ctx.createLinearGradient(-13,0,13,0);hull.addColorStop(0,'#526780');hull.addColorStop(.45,'#f4f8ff');hull.addColorStop(1,'#40546d');
 ctx.fillStyle=hull;ctx.strokeStyle='#ffffff';ctx.lineWidth=1.6;ctx.beginPath();ctx.moveTo(0,-34);ctx.lineTo(11,-10);ctx.lineTo(13,17);ctx.lineTo(0,24);ctx.lineTo(-13,17);ctx.lineTo(-11,-10);ctx.closePath();ctx.fill();ctx.stroke();
 // dark cockpit canopy with electric-blue reflection
 const glass=ctx.createLinearGradient(0,-25,0,-5);glass.addColorStop(0,'#bffaff');glass.addColorStop(.35,'#277bb4');glass.addColorStop(1,'#101d43');ctx.fillStyle=glass;ctx.beginPath();ctx.moveTo(0,-27);ctx.lineTo(7,-12);ctx.lineTo(0,-7);ctx.lineTo(-7,-12);ctx.closePath();ctx.fill();ctx.strokeStyle='#a9f7ff';ctx.lineWidth=1;ctx.stroke();
 // central reactor and small wingtip running lights
 circle(0,7,3.3,`rgba(76,238,255,${pulse})`);circle(-40,18,2.2,'#ff5b65');circle(40,18,2.2,'#55ffbf');
 ctx.restore();
}
function burst(x,y,color,n=12){for(let i=0;i<n;i++){const a=Math.random()*Math.PI*2,sp=1+Math.random()*6;particles.push({x,y,vx:Math.cos(a)*sp,vy:Math.sin(a)*sp,life:18+Math.random()*24,max:42,size:1.2+Math.random()*3.4,color});}particles.push({x,y,vx:0,vy:0,life:9,max:9,size:8,color:'#fff4cf'});}
function fire(){if(frame-lastShot< (weapon===2?20:12))return;lastShot=frame;sound(weapon===2?900:weapon===1?350:600,.05,weapon===2?'sawtooth':'square',.02);
 if(weapon===0)shots.push({x:player.x,y:player.y-25,vx:0,vy:-9,damage:1,color:'#ffe66d'});
 if(weapon===1){[-.22,0,.22].forEach(a=>shots.push({x:player.x,y:player.y-20,vx:a*9,vy:-8,damage:1,color:'#ff9cde'}));}
 if(weapon===2)shots.push({x:player.x,y:player.y-28,vx:0,vy:-13,damage:3,color:'#75f7ff'});if(weapon===3)shots.push({x:player.x,y:player.y-24,vx:0,vy:-7,damage:5,color:'#ff8a45'});if(weapon===4){[-.16,0,.16].forEach(a=>shots.push({x:player.x,y:player.y-24,vx:a*10,vy:-10,damage:2,color:'#c18bff'}));}}
function spawnEnemy(){let kind=Math.floor(Math.random()*Math.min(4,1+Math.floor(stage/3))),r=kind===2?23:14+Math.random()*9;enemies.push({kind,x:25+Math.random()*(W-50),y:-30,r,v:1.25+Math.random()*1.2+stage*.12,hp:(kind===2?4:kind===1?2:1)+Math.floor(stage/5),phase:Math.random()*8,shoot:Math.floor(Math.random()*70)+40});}
function spawnBoss(){boss={x:W/2,y:92,hp:65+stage*21,max:65+stage*21,dir:1,shot:0};sound(130,.55,'sawtooth',.06);hud();}
// Original heavy sci-fi warships: angular armor, layered hulls, engines and glowing weapon ports.
function drawEnemyShip(kind,r,x,y){
 const palettes=[['#aeb8c8','#53647d','#ff596f'],['#8da9b8','#304d65','#55e6ff'],['#c5a36b','#59432f','#ffb34d'],['#a18acb','#44345f','#d18bff']];
 const [hull,shade,glow]=palettes[kind%4];ctx.save();ctx.translate(x,y);ctx.lineJoin='round';ctx.shadowBlur=10;ctx.shadowColor=glow;
 // swept wing silhouette
 ctx.fillStyle=shade;ctx.strokeStyle=hull;ctx.lineWidth=2;
 ctx.beginPath();ctx.moveTo(0,-r*1.55);ctx.lineTo(r*.48,-r*.68);ctx.lineTo(r*1.72,-r*.18);ctx.lineTo(r*1.18,r*.58);ctx.lineTo(r*.42,r*.35);ctx.lineTo(0,r*.9);ctx.lineTo(-r*.42,r*.35);ctx.lineTo(-r*1.18,r*.58);ctx.lineTo(-r*1.72,-r*.18);ctx.lineTo(-r*.48,-r*.68);ctx.closePath();ctx.fill();ctx.stroke();
 // armored center spine and plating
 ctx.shadowBlur=0;ctx.fillStyle=hull;ctx.beginPath();ctx.moveTo(0,-r*1.28);ctx.lineTo(r*.38,-r*.2);ctx.lineTo(r*.27,r*.62);ctx.lineTo(0,r*.78);ctx.lineTo(-r*.27,r*.62);ctx.lineTo(-r*.38,-r*.2);ctx.closePath();ctx.fill();
 ctx.fillStyle=glow;ctx.globalAlpha=.9;ctx.fillRect(-r*.13,-r*.68,r*.26,r*.88);ctx.globalAlpha=1;
 // engine pods and side cannons
 for(const side of [-1,1]){ctx.fillStyle='#18263c';ctx.fillRect(side*r*.94,-r*.05,r*.32,r*.55);ctx.fillStyle=glow;ctx.fillRect(side*r*1.05,r*.26,r*.17,r*.27);ctx.fillStyle='#d8e4ef';ctx.fillRect(side*r*.57,-r*.25,r*.13,r*.55);}
 ctx.fillStyle='#e8f5ff';ctx.beginPath();ctx.ellipse(0,-r*.18,r*.18,r*.28,0,0,Math.PI*2);ctx.fill();ctx.fillStyle=glow;ctx.beginPath();ctx.arc(0,-r*.18,r*.095,0,Math.PI*2);ctx.fill();
 // rear exhaust
 ctx.fillStyle=glow;ctx.globalAlpha=.7;ctx.beginPath();ctx.moveTo(-r*.22,r*.72);ctx.lineTo(0,r*(1.35+Math.random()*.25));ctx.lineTo(r*.22,r*.72);ctx.closePath();ctx.fill();ctx.restore();
}
function bossDraw(){if(!boss)return;const pulse=1+Math.sin(frame*.08)*.035;ctx.save();ctx.translate(boss.x,boss.y);ctx.scale(pulse,pulse);
 const hull=['#7d8498','#8d5360','#477e83','#a56c39','#496a9b'][(stage-1)%5],glow=['#b6dfff','#ff647e','#5fffe0','#ffc06a','#75b9ff'][(stage-1)%5];
 ctx.shadowBlur=22;ctx.shadowColor=glow;ctx.fillStyle='#202a40';ctx.strokeStyle=hull;ctx.lineWidth=4;
 // colossal titan-class dreadnought silhouette
 ctx.beginPath();ctx.moveTo(0,-61);ctx.lineTo(27,-42);ctx.lineTo(53,-35);ctx.lineTo(112,-9);ctx.lineTo(76,14);ctx.lineTo(64,43);ctx.lineTo(25,34);ctx.lineTo(0,58);ctx.lineTo(-25,34);ctx.lineTo(-64,43);ctx.lineTo(-76,14);ctx.lineTo(-112,-9);ctx.lineTo(-53,-35);ctx.lineTo(-27,-42);ctx.closePath();ctx.fill();ctx.stroke();
 ctx.shadowBlur=0;ctx.fillStyle=hull;ctx.beginPath();ctx.moveTo(0,-53);ctx.lineTo(18,-25);ctx.lineTo(28,25);ctx.lineTo(0,47);ctx.lineTo(-28,25);ctx.lineTo(-18,-25);ctx.closePath();ctx.fill();
 for(const side of [-1,1]){ctx.fillStyle='#111b2c';ctx.fillRect(side*68-7,-12,14,48);ctx.fillStyle=glow;ctx.fillRect(side*69-4,8,8,24);ctx.fillStyle='#c5d3e5';ctx.fillRect(side*42,-31,8,34);ctx.fillRect(side*88,-12,15,8);}
 ctx.fillStyle='#f0f6ff';ctx.beginPath();ctx.arc(0,-16,13,0,Math.PI*2);ctx.fill();ctx.fillStyle=glow;ctx.beginPath();ctx.arc(0,-16,8,0,Math.PI*2);ctx.fill();
 ctx.strokeStyle=glow;ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(-34,18);ctx.lineTo(0,32);ctx.lineTo(34,18);ctx.stroke();ctx.restore();
 const bw=Math.min(W-44,220),bx=(W-bw)/2;ctx.fillStyle='#17243b';ctx.fillRect(bx,160,bw,10);ctx.fillStyle=glow;ctx.fillRect(bx,160,bw*(boss.hp/boss.max),10);ctx.strokeStyle='#d9e8ff';ctx.strokeRect(bx,160,bw,10);ctx.fillStyle='#fff';ctx.font='bold 10px system-ui';ctx.textAlign='center';ctx.fillText('TITAN-CLASS WARSHIP',W/2,153);
}
function end(win){running=false;let title=win?'GALAXY SAVED!':'DO NOT PLAY LIKE BABLI';let extra=win?'You defeated every boss!':'Final score: '+score;try{if(score>high){high=score;localStorage.setItem('ssHigh',high)}saveProgress();}catch(e){}$('overlay').style.display='flex';$('overlay').innerHTML=`<div class="panel"><h1>${title}</h1><p>${extra}</p><p class="small">High score: ${high}</p><button class="start" id="again">PLAY AGAIN</button></div>`;$('again').onclick=start;}
function damage(){if(player.inv>0)return;player.hp-=35;player.inv=55;sound(100,.2,'sawtooth',.05);burst(player.x,player.y,'#67eaff',18);if(player.hp<=0){lives--;if(lives>0){player.hp=100;player.inv=100;}else end(false);}hud();}
function update(){
 frame++;background();
 if(thumb.active){player.x+=(thumb.x-player.x)*.32;keys.fire=true;}else{keys.fire=false;if(keys.left)player.x-=player.speed;if(keys.right)player.x+=player.speed;}player.x=Math.max(22,Math.min(W-22,player.x));if(keys.fire)fire();if(player.inv>0)player.inv--;
 if(stageKills>=8+Math.floor(stage/3)&&!boss)spawnBoss();
 if(!boss&&++spawn>Math.max(25,62-stage*6)){spawn=0;spawnEnemy();}
 for(let i=shots.length-1;i>=0;i--){let b=shots[i];b.x+=b.vx;b.y+=b.vy;ctx.save();ctx.shadowBlur=13;ctx.shadowColor=b.color;const beam=ctx.createLinearGradient(b.x,b.y-18,b.x,b.y+5);beam.addColorStop(0,'rgba(255,255,255,0)');beam.addColorStop(.35,b.color);beam.addColorStop(1,'#ffffff');ctx.fillStyle=beam;ctx.beginPath();ctx.moveTo(b.x-2.4,b.y+5);ctx.lineTo(b.x-1.2,b.y-17);ctx.quadraticCurveTo(b.x,b.y-21,b.x+1.2,b.y-17);ctx.lineTo(b.x+2.4,b.y+5);ctx.closePath();ctx.fill();ctx.restore();if(b.y<-24||b.x<0||b.x>W)shots.splice(i,1);}
 for(let i=enemies.length-1;i>=0;i--){let e=enemies[i];e.y+=e.v;e.x+=Math.sin(frame*.035+e.phase)*.8;e.shoot--;drawEnemyShip(e.kind||0,e.r,e.x,e.y);
 if(e.shoot<0&&e.y>0){enemyShots.push({x:e.x,y:e.y+e.r,vx:(player.x-e.x)*.003,vy:3+stage*.25});e.shoot=100+Math.random()*65;}
 for(let j=shots.length-1;j>=0;j--){let b=shots[j];if(Math.hypot(e.x-b.x,e.y-b.y)<e.r+7){shots.splice(j,1);e.hp-=b.damage;burst(e.x,e.y,b.color,4);if(e.hp<=0){score+=10;coins+=2;saveProgress();stageKills++;burst(e.x,e.y,'#ffe66d');if(Math.random()<.14)pickups.push({x:e.x,y:e.y,type:Math.random()<.5?'heal':'weapon'});enemies.splice(i,1);hud();}break;}}
 if(i<enemies.length&&Math.hypot(e.x-player.x,e.y-player.y)<e.r+15){enemies.splice(i,1);damage();}else if(e.y>H+25){enemies.splice(i,1);damage();}
 }
 if(boss){boss.x+=boss.dir*(2+stage*.25);if(boss.x>W-55||boss.x<55)boss.dir*=-1;boss.shot++;if(boss.shot>48){enemyShots.push({x:boss.x-20,y:boss.y+25,vx:-1.2,vy:3.6},{x:boss.x+20,y:boss.y+25,vx:1.2,vy:3.6},{x:boss.x,y:boss.y+30,vx:0,vy:4.2});boss.shot=0;}
 for(let j=shots.length-1;j>=0;j--){let b=shots[j];if(Math.hypot(boss.x-b.x,boss.y-b.y)<48){boss.hp-=b.damage;shots.splice(j,1);burst(b.x,b.y,'#d6a5ff',3);if(boss.hp<=0){score+=100+stage*25;coins+=25+stage*3;saveProgress();burst(boss.x,boss.y,'#ffe66d',45);boss=null;stageKills=0;stage++;lives=Math.min(5,lives+1);player.hp=100;hud();if(stage>15){end(true);return;}sound(720,.4,'triangle',.07);}break;}}bossDraw();}
 for(let i=enemyShots.length-1;i>=0;i--){let b=enemyShots[i];b.x+=b.vx;b.y+=b.vy;ctx.save();ctx.shadowBlur=12;ctx.shadowColor='#ff5577';const eg=ctx.createRadialGradient(b.x-1,b.y-2,1,b.x,b.y,7);eg.addColorStop(0,'#fff4f6');eg.addColorStop(.35,'#ff9aab');eg.addColorStop(1,'#b51f54');ctx.fillStyle=eg;ctx.beginPath();ctx.arc(b.x,b.y,6,0,Math.PI*2);ctx.fill();ctx.strokeStyle='rgba(255,112,145,.45)';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(b.x,b.y-5);ctx.lineTo(b.x-b.vx*2,b.y-b.vy*2);ctx.stroke();ctx.restore();if(Math.hypot(b.x-player.x,b.y-player.y)<player.r+6){enemyShots.splice(i,1);damage();}else if(b.y>H+10)enemyShots.splice(i,1);}
 for(let i=pickups.length-1;i>=0;i--){let p=pickups[i];p.y+=2;ctx.font='23px sans-serif';ctx.fillText(p.type==='heal'?'💚':'⚡',p.x-11,p.y+8);if(Math.hypot(p.x-player.x,p.y-player.y)<28){if(p.type==='heal')player.hp=Math.min(100,player.hp+35);else weaponPower=600;score+=15;pickups.splice(i,1);sound(800,.12,'sine');hud();}else if(p.y>H)pickups.splice(i,1);}
 if(weaponPower>0){weaponPower--;if(frame%90===0)weapon=(weapon+1)%5;}
 for(let i=particles.length-1;i>=0;i--){let p=particles[i];p.x+=p.vx;p.y+=p.vy;p.life--;ctx.globalAlpha=Math.max(0,p.life/(p.max||35));ctx.shadowBlur=8;ctx.shadowColor=p.color;circle(p.x,p.y,p.size||3,p.color);ctx.shadowBlur=0;ctx.globalAlpha=1;if(p.life<=0)particles.splice(i,1);}
 if(player.inv===0||frame%8<4)ship();hud();if(running)requestAnimationFrame(update);
}
function start(){reset();$('overlay').style.display='none';running=true;if(soundEnabled&&!musicTimer)musicTimer=setInterval(()=>{if(running)sound([220,277,330,277,196,247,294,247][Math.floor(frame/38)%8],.22,'sine',.009)},420);requestAnimationFrame(update);}
$('start').onclick=start;
function showSettings(back='menu'){running=false;$('overlay').style.display='flex';$('overlay').innerHTML=`<div class="panel"><h1>SETTINGS</h1><p>Game sound</p><div class="settingRow"><button class="secondary" id="soundToggle">${soundEnabled?'🔊 SOUND ON':'🔇 MUTED'}</button></div><p class="small">Turn music and game sound effects on or off.</p><button class="start" id="settingsBack">${back==='pause'?'RESUME GAME':'BACK TO MENU'}</button></div>`;$('soundToggle').onclick=()=>{soundEnabled=!soundEnabled;if(!soundEnabled&&musicTimer){clearInterval(musicTimer);musicTimer=null;}showSettings(back);};$('settingsBack').onclick=()=>{if(back==='pause'){ $('overlay').style.display='none';running=true;requestAnimationFrame(update);}else{showMenu();}};}
function showUpgrades(){running=false;$('overlay').style.display='flex';$('overlay').innerHTML=`<div class="panel"><div style="color:#ffdf70;letter-spacing:3px;font-weight:1000">MONSTORR PRESENTS</div><h1>SHIP HANGAR</h1><p>Coins: 🪙 ${coins}</p><p class="small">Upgrade ship armor and engine. Each upgrade costs 100 coins.</p><p>Upgrade level: ${upgrade}/10</p><button class="start" id="buyUpgrade">UPGRADE · 100 🪙</button><br><button class="secondary" id="hangarBack">BACK</button></div>`;$('buyUpgrade').onclick=()=>{if(upgrade>=10||coins<100){$('buyUpgrade').textContent=upgrade>=10?'MAX LEVEL':'NOT ENOUGH COINS';return;}coins-=100;upgrade++;saveProgress();showUpgrades();};$('hangarBack').onclick=showMenu;}
function showDaily(){let today=new Date().toISOString().slice(0,10),last=localStorage.getItem('ssDaily'),msg;if(last===today)msg='Daily reward already claimed today.';else{coins+=100;localStorage.setItem('ssDaily',today);saveProgress();msg='Daily reward claimed: +100 coins!';}$('overlay').style.display='flex';$('overlay').innerHTML=`<div class="panel"><div style="color:#ffdf70;font-weight:1000;letter-spacing:3px">MONSTORR PRESENTS</div><h1>DAILY DROP</h1><p>${msg}</p><p>Wallet: 🪙 ${coins}</p><button class="start" id="dailyBack">CONTINUE</button></div>`;$('dailyBack').onclick=showMenu;}
function showLeaderboard(){let scores=JSON.parse(localStorage.getItem('ssLocalBoard')||'[]');if(score>0)scores.push(score);scores=scores.sort((a,b)=>b-a).slice(0,5);localStorage.setItem('ssLocalBoard',JSON.stringify(scores));$('overlay').style.display='flex';$('overlay').innerHTML=`<div class="panel"><div style="color:#ffdf70;font-weight:1000;letter-spacing:3px">MONSTORR PRESENTS</div><h1>LEADERBOARD</h1><p class="small">Local top scores on this device</p>${scores.map((v,i)=>`<p>${i+1}. ⭐ ${v}</p>`).join('')}<p class="small">Online leaderboard requires a server/API connection. This build does not claim local scores are online.</p><button class="start" id="boardBack">BACK</button></div>`;$('boardBack').onclick=showMenu;}
function showMenu(){running=false;$('overlay').style.display='flex';$('overlay').innerHTML=`<div class="panel"><div style="font-size:12px;letter-spacing:3px;color:#ffdf70;font-weight:1000">MONSTORR PRESENTS</div><h1>SHOOTING STAR</h1><p><b>REAL SPACE EDITION 2.5</b> · Defend the galaxy!</p><p class="small">15 stages · cinematic nebula & planet backdrop · armored fleets · dreadnought bosses · 5 weapons<br>Coins · Ship upgrades · Daily rewards · Auto-save progress</p><p>🪙 ${coins} coins · 🏆 Best ${high}</p><button class="start" id="start">PLAY</button><br><button class="secondary" id="hangar">🚀 SHIP HANGAR</button><button class="secondary" id="daily">🎁 DAILY REWARD</button><br><button class="secondary" id="board">🏆 LEADERBOARD</button><button class="secondary" id="menuSettings">⚙ SETTINGS</button></div>`;$('start').onclick=start;$('menuSettings').onclick=()=>showSettings('menu');$('hangar').onclick=showUpgrades;$('daily').onclick=showDaily;$('board').onclick=showLeaderboard;}
$('menuSettings').onclick=()=>showSettings('menu');
$('pauseBtn').onclick=()=>{if(!running)return;running=false;$('overlay').style.display='flex';$('overlay').innerHTML=`<div class="panel"><h1>PAUSED</h1><p>Take a short break, pilot!</p><button class="start" id="resume">▶ RESUME</button><br><button class="secondary" id="pauseSettings">⚙ SETTINGS</button><br><button class="secondary" id="quitMenu">MAIN MENU</button></div>`;$('resume').onclick=()=>{$('overlay').style.display='none';running=true;requestAnimationFrame(update);};$('pauseSettings').onclick=()=>showSettings('pause');$('quitMenu').onclick=showMenu;};
function thumbStart(e){if(!running)return;e.preventDefault();if(thumb.active)return;thumb.active=true;thumb.pointerId=e.pointerId;thumb.x=e.clientX;keys.fire=true;try{c.setPointerCapture(e.pointerId)}catch(_){};}
function thumbMove(e){if(!thumb.active||e.pointerId!==thumb.pointerId)return;e.preventDefault();thumb.x=e.clientX;}
function thumbEnd(e){if(!thumb.active||e.pointerId!==thumb.pointerId)return;e.preventDefault();thumb.active=false;thumb.pointerId=null;keys.fire=false;}
c.addEventListener('pointerdown',thumbStart);c.addEventListener('pointermove',thumbMove);['pointerup','pointercancel','lostpointercapture'].forEach(n=>c.addEventListener(n,thumbEnd));
resize();reset();
})();
