
/* Local Supabase REST/Auth client: avoids blank Android WebView when the CDN is unavailable. */
window.supabase={createClient:function(baseUrl,anonKey){
  const storage=window.localStorage;
  let token=storage.getItem('DPM_ACCESS_TOKEN')||null;
  let refresh=storage.getItem('DPM_REFRESH_TOKEN')||null;
  async function request(path,opts={}){
    const headers=Object.assign({'apikey':anonKey,'Content-Type':'application/json'},opts.headers||{});
    if(token) headers['Authorization']='Bearer '+token;
    const r=await fetch(baseUrl+path,Object.assign({},opts,{headers}));
    let data=null; try{data=await r.json()}catch(e){}
    if(!r.ok) return {data:null,error:{message:(data&&(data.msg||data.message||data.error_description||data.error))||('HTTP '+r.status)}};
    return {data,error:null};
  }
  const auth={
    async signInWithPassword({email,password}){
      const r=await request('/auth/v1/token?grant_type=password',{method:'POST',body:JSON.stringify({email,password})});
      if(!r.error){token=r.data.access_token;refresh=r.data.refresh_token||null;storage.setItem('DPM_ACCESS_TOKEN',token);if(refresh)storage.setItem('DPM_REFRESH_TOKEN',refresh);}
      return {data:r.data,error:r.error};
    },
    async getSession(){return {data:{session:token?{access_token:token,refresh_token:refresh}:null},error:null}},
    async getUser(){
      if(!token)return {data:{user:null},error:null};
      const r=await request('/auth/v1/user');
      return {data:{user:r.error?null:r.data},error:r.error};
    },
    async signOut(){token=null;refresh=null;storage.removeItem('DPM_ACCESS_TOKEN');storage.removeItem('DPM_REFRESH_TOKEN');return {error:null}},
    async resetPasswordForEmail(email,{redirectTo}={}){
      return await request('/auth/v1/recover',{method:'POST',body:JSON.stringify({email,redirect_to:redirectTo||location.origin})});
    }
  };
  function qbuilder(table,op,payload){
    let filters=[], orderBy=null, ascending=true, columns='*', singleRow=false;
    const q={
      select(cols='*'){op='select';columns=cols;return q},
      insert(body){op='insert';payload=body;return q},
      update(body){op='update';payload=body;return q},
      delete(){op='delete';return q},
      eq(col,val){filters.push([col,'eq',val]);return q},
      order(col,opt={}){orderBy=col;ascending=opt.ascending!==false;return q},
      single(){singleRow=true;return q},
      then(resolve,reject){return run().then(resolve,reject)}
    };
    async function run(){
      let url='/rest/v1/'+encodeURIComponent(table);
      const params=[];
      if(op==='select'){
        params.push('select='+encodeURIComponent(columns));
      } else if(op==='update'||op==='delete'){
        params.push('select='+encodeURIComponent('*'));
      }
      filters.forEach(f=>params.push(encodeURIComponent(f[0])+'='+encodeURIComponent(f[1]+'.'+String(f[2]))));
      if(orderBy)params.push('order='+encodeURIComponent(orderBy)+'.'+(ascending?'asc':'desc'));
      if(params.length)url+='?'+params.join('&');
      let opts={method:op==='select'?'GET':op==='insert'?'POST':op==='update'?'PATCH':'DELETE'};
      if(op==='insert'){opts.headers={'Prefer':'return=representation'};opts.body=JSON.stringify(payload)}
      if(op==='update'){opts.headers={'Prefer':'return=representation'};opts.body=JSON.stringify(payload)}
      const r=await request(url,opts);
      if(r.error)return r;
      if(op==='select'){const arr=Array.isArray(r.data)?r.data:(r.data?[r.data]:[]);if(singleRow){if(arr.length!==1)return {data:null,error:{message:arr.length?'Multiple rows returned':'No rows returned'}};return {data:arr[0],error:null}}return {data:arr,error:null}}
      return {data:r.data,error:null};
    }
    return q;
  }
  return {auth,from:(table)=>qbuilder(table,'select',null)};
}};
