
const months=["Janvier","Février","Mars","Avril","Mai","Juin","Juillet","Août","Septembre","Octobre","Novembre","Décembre"];
const $=id=>document.getElementById(id);
const fmt=n=>Math.round(Number(n)||0).toLocaleString("fr-FR")+" FCFA";
const profileKey=()=>localStorage.getItem("gestion-financiere:active-profile")||"";
const stateKey=()=>profileKey()?`gestion-financiere:${profileKey()}:${$("year").value}:${$("month").value}`:`gestion-financiere:guest:${$("year").value}:${$("month").value}`;
const resourceKey=()=>profileKey()?`gestion-financiere:resources:${profileKey()}`:`gestion-financiere:resources:guest`;
const resourceData=()=>{try{return JSON.parse(localStorage.getItem(resourceKey())||"{}")}catch{return {}}};
const saveResourceData=d=>localStorage.setItem(resourceKey(),JSON.stringify(d));
$("month").innerHTML=months.map(m=>`<option>${m}</option>`).join("");
$("month").selectedIndex=new Date().getMonth(); $("year").value=new Date().getFullYear();

function profiles(){try{return JSON.parse(localStorage.getItem("gestion-financiere:profiles")||"[]")}catch{return []}}
function saveProfiles(list){localStorage.setItem("gestion-financiere:profiles",JSON.stringify(list))}
async function hashPin(pin){const bytes=new TextEncoder().encode(pin);const hash=await crypto.subtle.digest("SHA-256",bytes);return Array.from(new Uint8Array(hash)).map(b=>b.toString(16).padStart(2,"0")).join("")}
function activeProfile(){return profiles().find(p=>p.id===profileKey())||null}
function fillIdentity(p){
 ["profileId","idNoms","idPrenoms","idAge","idSexe","idAdresse","idGmail","idNumeros","idNationalite","idVille","idStatut"].forEach(id=>$(id).value=p?.[id]??"");
 $("idPin").value="";
}
function renderProfiles(){
 const ps=profiles();
 $("profilesList").innerHTML=ps.length?`<div class="label">PROFILS ENREGISTRÉS</div>`+ps.map(p=>"<div class=\"profilebar\"><span><b>"+escapeHtml(p.profileId)+"</b></span><button class=\"smallbtn\" data-login=\""+escapeAttr(p.id)+"\">Ouvrir</button></div>").join(""):"<div class=\"identity-note\">Aucun profil enregistré pour le moment.</div>";
 document.querySelectorAll("[data-login]").forEach(b=>b.onclick=()=>loginProfile(b.dataset.login));
}
function escapeHtml(v){return String(v??"").replace(/[&<>'"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;","'":"&#39;","\"":"&quot;"}[c]))}
function escapeAttr(v){return escapeHtml(v).replace(/`/g,"")}
function updateProfileBar(){const p=activeProfile();$("profileBar").classList.toggle("hidden",!p);$("profileName").textContent=p?.profileId||"—";}
async function loginProfile(id){
 const p=profiles().find(x=>x.id===id); if(!p)return;
 const pin=prompt("Entrez le code d’entrée du profil « "+p.profileId+" » :"); if(pin===null)return;
 if((await hashPin(pin))!==p.pinHash){alert("Code incorrect.");return;}
 localStorage.setItem("gestion-financiere:active-profile",p.id);
 appLocked=false;
 updateProfileBar(); renderBudget(); renderSaving(); show("home");
}
let appLocked=false;
let unlockInProgress=false;
async function unlockActiveProfile(){
 if(unlockInProgress)return false;
 const p=activeProfile(); if(!p)return false;
 unlockInProgress=true;
 try{
  const pin=prompt("Entrez le code d’entrée du profil « "+p.profileId+" » :");
  if(pin===null)return false;
  if((await hashPin(pin))!==p.pinHash){alert("Code incorrect.");return false;}
  appLocked=false; updateProfileBar(); show("home"); return true;
 }finally{unlockInProgress=false;}
}
function lockForProfile(){
 const ps=profiles(); const active=activeProfile();
 if(active && !appLocked){updateProfileBar();return true;}
 if(active && appLocked){unlockActiveProfile();return false;}
 if(!ps.length){show("identity");fillIdentity(null);renderProfiles();return false;}
 show("identity");renderProfiles();alert("Choisissez un profil et entrez son code d’entrée.");return false;
}

const accounts=[
 {id:"current",cls:"account-blue",title:"Priorité 1 : Compte courant",pct:.50,color:"blue",
  rows:[
   ["Charges fixes","Loyer, Électricité, Eau, Gaz, Internet, Téléphone…"],
   ["Alimentation","Boucherie (viandes, poisson, volailles…), Riz, Spaghettis, Foufou, Huile, Sucre, Tomates, Oignons, Ail, Lait, Œufs, Eau potable, Vin, Mayonnaise, Vinaigre, Cubes, Poivre noir, Arômes, Feuilles de laurier…"],
   ["Hygiène personnelle","Savon, Gel douche, Dentifrice, Brosse, Papier toilette, Tiges de coton, Déodorant, Parfum, Lait de beauté, Rasoir, Gilette…"],
   ["Maison / entretien","Liquide vaisselle, Javel, Détergent, Balai, Serpillère, Grillages, Rideaux, Petites choses de la maison…"],
   ["Transport","Bus, Taxi…"],
   ["Vie pers. & loisirs","Habillement, Coiffure, Sorties / Loisirs, Couple, Cadeaux…"],
   ["Vie sociale","Événements & Anniversaires, Cotisations, Invitations…"],
   ["Imprévus courants","Petits imprévus du quotidien…"]
  ]},
 {id:"security",cls:"account-green",title:"Priorité 2 : Épargne sécurité",pct:.20,color:"green",
  rows:[
   ["Réserves & Urgences","Urgence médicale, Perte de revenus, Grosse réparation, Dépense exceptionnelle…"],
   ["Santé","Consultations, Médicaments, Examens, Soins…"],
   ["Aide de famille","Soutien et aides familiales d’urgence…"]
  ]},
 {id:"projects",cls:"account-orange",title:"Priorité 3 : Épargne projets",pct:.15,color:"orange",
  rows:[
   ["Projets personnels","Projet 1, Projet 2…"]
  ]},
 {id:"business",cls:"account-purple",title:"Priorité 4 : Gestion d’entreprise & investissement",pct:.15,color:"purple",
  rows:[
   ["Entreprise","Capital de lancement, Réinvestissement, Matériel, Entretien équipements, Fonds de roulement…"],
   ["Investissements","Placements financiers, Opportunités d’investissement…"]
  ]},
 {id:"debts",cls:"account-red",title:"Priorité 5 : Dettes actuelles",pct:0,color:"red",excludePercent:true,rows:[["Dettes actuelles","Remboursements, échéances…"]]}
];

const allocationOptions=[
 {label:"50 / 20 / 15 / 15",values:[.50,.20,.15,.15]},
 {label:"50 / 30 / 10 / 10",values:[.50,.30,.10,.10]},
 {label:"50 / 15 / 15 / 20",values:[.50,.15,.15,.20]},
 {label:"50 / 25 / 15 / 10",values:[.50,.25,.15,.10]},
 {label:"55 / 20 / 15 / 10",values:[.55,.20,.15,.10]}
];
let currentAllocation=allocationOptions[0].values.slice();
function applyAllocation(values){
 currentAllocation=values.slice();
 accounts.forEach((a,i)=>{if(!a.excludePercent)a.pct=currentAllocation[i];});
}

function data(){try{return JSON.parse(localStorage.getItem(stateKey())||"{}")}catch{return {}}}
function save(d){localStorage.setItem(stateKey(),JSON.stringify(d))}
const savingProgressKey=()=>profileKey()?`gestion-financiere:saving-progress:${profileKey()}`:"gestion-financiere:saving-progress:guest";
function mergeSavingState(target,source,type){if(!source)return;target[type]=target[type]||{plan:source.plan||1000,plans:{}};target[type].plans=target[type].plans||{};for(const [plan,state] of Object.entries(source.plans||{})){const old=target[type].plans[plan]||{};const merged={...old,...state};for(const k of Object.keys(state||{}))if(k.startsWith("w")||k.startsWith("c"))merged[k]=!!old[k]||!!state[k];target[type].plans[plan]=merged;}if(source.plan)target[type].plan=source.plan;}
function savingProgress(){let out;try{out=JSON.parse(localStorage.getItem(savingProgressKey())||"null")}catch{}if(out)return out;out={saving:{plan:1000,plans:{}},saving2:{plan:1000,plans:{}}};const prefix=profileKey()?`gestion-financiere:${profileKey()}:`:`gestion-financiere:guest:`;Object.keys(localStorage).filter(k=>k.startsWith(prefix)).forEach(k=>{try{const d=JSON.parse(localStorage.getItem(k)||"{}");mergeSavingState(out,d.saving,"saving");mergeSavingState(out,d.saving2,"saving2")}catch{}});localStorage.setItem(savingProgressKey(),JSON.stringify(out));return out;}
function saveSavingProgress(d){localStorage.setItem(savingProgressKey(),JSON.stringify(d));}

function buildAccounts(){
 let html="";
 accounts.forEach(a=>{
  html+=`<div class="account ${a.cls}">
    <div class="account-head"><span>${a.title} <span id="pct-${a.id}">${a.excludePercent?"(hors calcul des pourcentages)":`(${Math.round(a.pct*100)} % des ressources)`}</span></span><span>Budget affecté : <b id="budget-${a.id}">${a.excludePercent?"Hors calcul":"0 FCFA"}</b></span></div>
    <div class="budget-error" id="error-${a.id}">Dépassement : la saisie est refusée car le budget affecté est déjà atteint.</div>
    <div class="table-head"><div>RUBRIQUE</div><div>POSTES BUDGÉTAIRES ASSOCIÉS</div><div>BUDGET RÉEL</div></div>`;
  a.rows.forEach((r,i)=>{
   html+=`<div class="budget-row">
    <div class="rubric">${r[0]}</div>
    <div class="posts"><div class="default-posts">${r[1]}</div><div class="custom-posts" data-custom-posts="${a.id}|${i}"></div><div class="custom-post-add"><input type="text" maxlength="100" data-custom-post-input="${a.id}|${i}" placeholder="Ajouter un poste…"><button type="button" data-custom-post-add="${a.id}|${i}">+</button></div></div>
    <div><input class="real" data-account="${a.id}" data-row="${i}" type="number" min="0" inputmode="numeric" placeholder="FCFA"></div>
   </div>`;
  });
  html+=`</div>`;
 });
 $("accounts").innerHTML=html;
 document.querySelectorAll(".real").forEach(x=>x.addEventListener("input",()=>{updateBudget();}));
}

function normalizeBudgetDebt(d){
 d.budget=d.budget||{}; const b=d.budget; b.real=b.real||{}; b.real.debts=b.real.debts||{};
 if(b.real.current && b.real.current[8]!==undefined){if(b.real.debts[0]===undefined)b.real.debts[0]=b.real.current[8];delete b.real.current[8];}
 b.customPosts=b.customPosts||{}; b.customPosts.debts=b.customPosts.debts||{};
 if(b.customPosts.current && b.customPosts.current[8]!==undefined){if(b.customPosts.debts[0]===undefined)b.customPosts.debts[0]=b.customPosts.current[8];delete b.customPosts.current[8];}
 return d;
}
function renderBudget(){
 let d=normalizeBudgetDebt(data()),b=d.budget||{};
 const idx=Number.isInteger(Number(b.allocationIndex))&&allocationOptions[Number(b.allocationIndex)]?Number(b.allocationIndex):0;
 applyAllocation(b.allocation||allocationOptions[idx].values);
 $("allocationSelect").value=String(idx);
 $("income").value=b.income??"";
 document.querySelectorAll(".real").forEach(x=>{
   const v=b.real?.[x.dataset.account]?.[x.dataset.row];
   x.value=v??""; x.dataset.lastValid=v??""; x.classList.remove("over-limit");
 });
 updateBudget();
 renderCustomPosts(b.customPosts||{});
}
function renderCustomPosts(customPosts={}){
 document.querySelectorAll("[data-custom-posts]").forEach(box=>{
   const [account,row]=box.dataset.customPosts.split("|");
   const list=customPosts?.[account]?.[row]||[];
   box.innerHTML=list.map((post,i)=>`<span class="custom-post">${escapeHtml(post)} <button type="button" data-custom-post-remove="${escapeAttr(account)}|${escapeAttr(row)}|${i}">×</button></span>`).join("");
 });
 document.querySelectorAll("[data-custom-post-remove]").forEach(btn=>btn.onclick=()=>{
   const [account,row,index]=btn.dataset.customPostRemove.split("|");
   let d=data(); d.budget=d.budget||{}; d.budget.customPosts=d.budget.customPosts||{}; d.budget.customPosts[account]=d.budget.customPosts[account]||{};
   const list=d.budget.customPosts[account][row]||[]; list.splice(Number(index),1); d.budget.customPosts[account][row]=list; save(d); renderCustomPosts(d.budget.customPosts);
 });
}
function addCustomPost(account,row){
 const input=document.querySelector(`[data-custom-post-input="${account}|${row}"]`);
 const value=input?.value.trim(); if(!value)return;
 let d=data(); d.budget=d.budget||{}; d.budget.customPosts=d.budget.customPosts||{}; d.budget.customPosts[account]=d.budget.customPosts[account]||{}; d.budget.customPosts[account][row]=d.budget.customPosts[account][row]||[];
 d.budget.customPosts[account][row].push(value); save(d); input.value=""; renderCustomPosts(d.budget.customPosts);
}
function accountTotal(accountId, exceptEl=null){
 let total=0; document.querySelectorAll(`.real[data-account="${accountId}"]`).forEach(x=>{if(x!==exceptEl) total+=Math.max(0,Number(x.value)||0)}); return total;
}
function accountLimit(accountId){
 const a=accounts.find(x=>x.id===accountId); if(a?.excludePercent)return Infinity; const n=Math.max(0,Number($("income").value)||0); return n*(a?.pct||0);
}
function flashLimit(accountId,el){
 const account=document.querySelector(`.account-head #budget-${accountId}`)?.closest(".account");
 if(account){account.classList.add("over");setTimeout(()=>account.classList.remove("over"),1800)}
 if(el){el.classList.add("over-limit");setTimeout(()=>el.classList.remove("over-limit"),1800)}
}
function validateRealInput(el){
 const limit=accountLimit(el.dataset.account); const attempted=Math.max(0,Number(el.value)||0); const others=accountTotal(el.dataset.account,el);
 if(attempted+others>limit){
   el.value=el.dataset.lastValid??""; flashLimit(el.dataset.account,el);
   return false;
 }
 el.dataset.lastValid=el.value; return true;
}
function updateBudget(){
 const n=Math.max(0,Number($("income").value)||0);
 accounts.forEach(a=>{
   $(`budget-${a.id}`).textContent=a.excludePercent?"Hors calcul":fmt(n*a.pct);
   const pct=document.getElementById(`pct-${a.id}`); if(pct)pct.textContent=a.excludePercent?"(hors calcul des pourcentages)":`(${Math.round(a.pct*100)} % des ressources)`;
   const total=accountTotal(a.id); const limit=a.excludePercent?Infinity:n*a.pct;
   const account=document.querySelector(`#budget-${a.id}`)?.closest(".account");
   if(account) account.classList.toggle("over",total>limit);
 });
 $("p1").textContent=fmt(n*accounts[0].pct); $("p2").textContent=fmt(n*accounts[1].pct); $("p3").textContent=fmt(n*accounts[2].pct); $("p4").textContent=fmt(n*accounts[3].pct);
 document.querySelector(".a1 b").textContent="🔵 COMPTE COURANT — "+Math.round(accounts[0].pct*100)+" %";
 document.querySelector(".a2 b").textContent="🟢 ÉPARGNE SÉCURITÉ — "+Math.round(accounts[1].pct*100)+" %";
 document.querySelector(".a3 b").textContent="🟠 ÉPARGNE PROJETS — "+Math.round(accounts[2].pct*100)+" %";
 document.querySelector(".a4 b").textContent="🟣 ENTREPRISE & INVESTISSEMENT — "+Math.round(accounts[3].pct*100)+" %";
}
function saveBudget(){
 updateBudget();
 let d=normalizeBudgetDebt(data()); const idx=Number($("allocationSelect").value)||0;
 const customPosts=d.budget?.customPosts||{};
 d.budget={income:Math.max(0,Number($("income").value)||0),allocationIndex:idx,allocation:currentAllocation.slice(),real:{},customPosts};
 accounts.forEach(a=>{d.budget.real[a.id]={};});
 document.querySelectorAll(".real").forEach(x=>{
   d.budget.real[x.dataset.account][x.dataset.row]=Math.max(0,Number(x.value)||0);
 });
 save(d);
 alert("Budget enregistré pour "+$("month").value+" "+$("year").value+".");
}

const plans={500:{label:"500 FCFA / semaine",total:175500},1000:{label:"1 000 FCFA / semaine",total:351000},5000:{label:"5 000 FCFA / semaine",total:1755000}};
let currentPlan=1000;
function planSavingState(s,plan){return s?.plans?.[String(plan)]||((Number(plan)===Number(s?.plan)&&!s?.plans)?s:{week:""});}
function renderSaving(){
 let d=savingProgress(),s=d.saving||{};
 currentPlan=Number(s.plan)||1000;
 document.querySelectorAll("[data-plan]").forEach(b=>b.classList.toggle("active",Number(b.dataset.plan)===currentPlan));
 const ps=planSavingState(s,currentPlan);
 $("week").value=ps.week??"";
 $("planLabel").textContent=plans[currentPlan].label;
 $("planTotal").textContent=fmt(plans[currentPlan].total);
 buildWeeks(ps);
 calc();
 renderSaving2();
}
function buildWeeks(s={}){
 let html="";
 for(let i=1;i<=26;i++){
  const checked=!!s[`w${i}`];
  html+=`<label class="week"><span><b>S${String(i).padStart(2,"0")}</b></span><span>${fmt(i*currentPlan)}</span><input id="w${i}" type="checkbox" ${checked?"checked":""}></label>`;
 }
 $("weeks").innerHTML=html;
 document.querySelectorAll("#weeks input").forEach(x=>x.addEventListener("change",()=>{calc();persistSavingSilent();}));
}
function checkedSavingTotal(){
 return [...document.querySelectorAll("#weeks input")].filter(x=>x.checked).reduce((sum,x)=>{const i=Number(x.id.slice(1));return sum+i*currentPlan},0);
}
function persistSavingSilent(){
 let d=savingProgress();d.saving=d.saving||{plans:{}};d.saving.plan=currentPlan;d.saving.plans=d.saving.plans||{};const state={week:Number($("week").value)||0};for(let i=1;i<=26;i++)state[`w${i}`]=!!$(`w${i}`)?.checked;d.saving.plans[String(currentPlan)]=state;saveSavingProgress(d);
}
function calc(){
 const total=checkedSavingTotal();
 $("weekAmount").textContent=fmt(total);
 $("cumulated").textContent=fmt(total);
 const checked=[...document.querySelectorAll("#weeks input")].filter(x=>x.checked).map(x=>"S."+Number(x.id.slice(1)));
 $("checkedWeeks").textContent=checked.length?checked.join(", "):"Aucune semaine cochée";
}
function saveSaving(){
 let d=savingProgress(); d.saving=d.saving||{plans:{}}; d.saving.plan=currentPlan; d.saving.plans=d.saving.plans||{};
 const state={week:Number($("week").value)||0};
 for(let i=1;i<=26;i++)state[`w${i}`]=!!$(`w${i}`).checked;
 d.saving.plans[String(currentPlan)]=state;
 saveSavingProgress(d);
 alert("Épargne progressive enregistrée. Les données sont continues et indépendantes du mois.");
}

let savingMode=1;
let currentPlan2=1000;
function saving2PlanState(s,plan){return s?.plans?.[String(plan)]||((Number(plan)===Number(s?.plan)&&!s?.plans)?s:{});}
function renderSaving2(){
 const d=savingProgress(),s=d.saving2||{};
 currentPlan2=Number(s.plan)||1000;
 document.querySelectorAll("[data-plan2]").forEach(b=>b.classList.toggle("active",Number(b.dataset.plan2)===currentPlan2));
 $("plan2Label").textContent=fmt(currentPlan2);
 buildSavingCases(saving2PlanState(s,currentPlan2));
 updateSaving2Total();
}
function buildSavingCases(s={}){
 let html="";
 for(let i=1;i<=30;i++){
   const checked=!!s[`c${i}`];
   html+=`<label class="second-case"><span><b>C${String(i).padStart(2,"0")}</b></span><span>${fmt(currentPlan2)}</span><input id="c${i}" type="checkbox" ${checked?"checked":""}></label>`;
 }
 $("savingCases").innerHTML=html;
 document.querySelectorAll("#savingCases input").forEach(x=>x.addEventListener("change",()=>{updateSaving2Total();persistSaving2Silent();}));
}
function persistSaving2Silent(){
 let d=savingProgress();d.saving2=d.saving2||{plans:{}};d.saving2.plan=currentPlan2;d.saving2.plans=d.saving2.plans||{};const state={};for(let i=1;i<=30;i++)state[`c${i}`]=!!$(`c${i}`)?.checked;d.saving2.plans[String(currentPlan2)]=state;saveSavingProgress(d);
}
function updateSaving2Total(){
 const checked=[...document.querySelectorAll("#savingCases input")].filter(x=>x.checked);
 $("plan2Total").textContent=fmt(checked.length*currentPlan2);
 const labels=checked.map(x=>"C."+Number(x.id.slice(1)));
 $("checkedCases").textContent=labels.length?labels.join(", "):"Aucune case cochée";
}
function saveSaving2(){
 let d=savingProgress(); d.saving2=d.saving2||{plans:{}}; d.saving2.plan=currentPlan2; d.saving2.plans=d.saving2.plans||{};
 const state={};
 for(let i=1;i<=30;i++)state[`c${i}`]=!!$(`c${i}`).checked;
 d.saving2.plans[String(currentPlan2)]=state;
 saveSavingProgress(d); alert("Système 2 enregistré. Les données sont continues et indépendantes du mois.");
}
const resourceAccounts=[
 {id:"current",cls:"account-blue",title:"Priorité 1 : Compte courant",rows:accounts.find(a=>a.id==="current").rows},
 {id:"security",cls:"account-green",title:"Priorité 2 : Épargne sécurité",rows:accounts.find(a=>a.id==="security").rows},
 {id:"projects",cls:"account-orange",title:"Priorité 3 : Épargne projets",rows:[["Projet 1",""],["Projet 2",""],["Projet 3",""],["Projet 4",""],["Projet 5",""]],editablePosts:true},
 {id:"business",cls:"account-purple",title:"Priorité 4 : Gestion d’entreprise & investissement",rows:accounts.find(a=>a.id==="business").rows},
 {id:"children",cls:"account-purple",title:"Comptes pour enfants",rows:[["Enfant 1",""],["Enfant 2",""],["Enfant 3",""],["Enfant 4",""],["Enfant 5",""]],editablePosts:true},
 {id:"debts",cls:"account-red",title:"Priorité 5 : Dettes actuelles",rows:[["Dettes 1",""],["Dettes 2",""],["Dettes 3",""],["Dettes 4",""],["Dettes 5",""]],editablePosts:true,excludeTotal:true}
];

// Keep the original V5 resource data usable: move the old debt row out of Compte courant.
function normalizedResourceData(){
 const d=resourceData();
 d.real=d.real||{};
 if(d.real.current?.[8]!==undefined){
   d.real.debts=d.real.debts||{};
   if(d.real.debts[0]===undefined)d.real.debts[0]=d.real.current[8];
   delete d.real.current[8];
 }
 return d;
}
function buildResources(){
 let html="";
 resourceAccounts.forEach(a=>{
  html+=`<div class="account ${a.cls}">
   <div class="account-head"><span>${a.title}</span><span class="resource-account-total">Disponible : <b id="resource-account-${a.id}">0 FCFA</b></span></div>
   <div class="resource-account-note"><input class="resource-note-input" data-account-note="${a.id}" type="text" maxlength="60" placeholder="Ex. Banque BESCAM"></div>
   <div class="resource-post-head"><div>RUBRIQUE</div><div>POSTES BUDGÉTAIRES ASSOCIÉS</div><div>MONTANT</div></div>`;
  a.rows.forEach((r,i)=>{
   const post=a.editablePosts?`<input class="resource-post-input" data-post-account="${a.id}" data-post-row="${i}" type="text" maxlength="100" placeholder="Écrire le poste…">`:r[1];
   html+=`<div class="resource-row"><div class="rubric">${r[0]}</div><div class="posts">${post}</div><div><input class="resource-input" data-account="${a.id}" data-row="${i}" type="number" min="0" inputmode="numeric" placeholder="0 FCFA"></div></div>`;
  });
  html+=`</div>`;
 });
 $("resourceAccounts").innerHTML=html;
 document.querySelectorAll(".resource-input").forEach(x=>x.addEventListener("input",updateResources));
}
function renderResources(){
 const d=normalizedResourceData();
 document.querySelectorAll(".resource-input").forEach(x=>{x.value=d.real?.[x.dataset.account]?.[x.dataset.row]??""});
 document.querySelectorAll(".resource-note-input").forEach(x=>{x.value=d.notes?.[x.dataset.accountNote]??""});
 document.querySelectorAll(".resource-post-input").forEach(x=>{x.value=d.posts?.[x.dataset.postAccount]?.[x.dataset.postRow]??""});
 updateResources();
 $("resourceUpdated").textContent=d.updated||"—";
}
function updateResources(){
 let grand=0;
 resourceAccounts.forEach(a=>{
  let total=0; document.querySelectorAll(`.resource-input[data-account="${a.id}"]`).forEach(x=>total+=Math.max(0,Number(x.value)||0));
  $(`resource-account-${a.id}`).textContent=fmt(total); if(!a.excludeTotal)grand+=total;
 });
 $("resourceGrandTotal").textContent=fmt(grand);
}
function resourceSnapshot(d){
 const snap={real:{},notes:{},posts:{}};
 resourceAccounts.forEach(a=>{snap.real[a.id]={};snap.notes[a.id]=d.notes?.[a.id]||"";if(a.editablePosts)snap.posts[a.id]={}});
 resourceAccounts.forEach(a=>{
  document.querySelectorAll(`.resource-input[data-account="${a.id}"]`).forEach(x=>snap.real[a.id][x.dataset.row]=Math.max(0,Number(x.value)||0));
 });
 document.querySelectorAll(".resource-note-input").forEach(x=>{snap.notes[x.dataset.accountNote]=x.value.trim()});
 document.querySelectorAll(".resource-post-input").forEach(x=>{snap.posts[x.dataset.postAccount][x.dataset.postRow]=x.value.trim()});
 return snap;
}
function saveResources(){
 const d={real:{},notes:{},posts:{},updated:new Date().toLocaleString("fr-FR",{dateStyle:"medium",timeStyle:"short"})};
 resourceAccounts.forEach(a=>{d.real[a.id]={};d.notes[a.id]="";if(a.editablePosts)d.posts[a.id]={}});
 document.querySelectorAll(".resource-input").forEach(x=>{d.real[x.dataset.account][x.dataset.row]=Math.max(0,Number(x.value)||0)});
 document.querySelectorAll(".resource-note-input").forEach(x=>{d.notes[x.dataset.accountNote]=x.value.trim()});
 document.querySelectorAll(".resource-post-input").forEach(x=>{d.posts[x.dataset.postAccount][x.dataset.postRow]=x.value.trim()});
 saveResourceData(d); $("resourceUpdated").textContent=d.updated; updateResources();
 const key=resourceHistoryKey(); const list=resourceHistory(); list.unshift({savedAt:d.updated,snapshot:resourceSnapshot(d)}); saveResourceHistory(list.slice(0,50));
 alert("Mes ressources disponibles ont été enregistrées.");
}
function resourceHistoryKey(){return profileKey()?`gestion-financiere:resources-history:${profileKey()}`:`gestion-financiere:resources-history:guest`}
function resourceHistory(){try{return JSON.parse(localStorage.getItem(resourceHistoryKey())||"[]")}catch{return []}}
function saveResourceHistory(list){localStorage.setItem(resourceHistoryKey(),JSON.stringify(list))}
function resourceHistoryHtml(){
 const d=normalizedResourceData();
 if(!d.real && !d.notes)return "<div class=\"note\">Aucune ressource enregistrée pour ce profil pour le moment.</div>";
 let rows=[];
 resourceAccounts.forEach(a=>{
  const total=Object.values(d.real?.[a.id]||{}).reduce((s,v)=>s+(Number(v)||0),0);
  const note=d.notes?.[a.id]||"";
  const posts=a.editablePosts?Object.values(d.posts?.[a.id]||{}).filter(Boolean).map(p=>escapeHtml(p)).join(" · "):"";
  rows.push(`<div class="history-resource-account"><b>${escapeHtml(a.title)}</b><span>${fmt(total)}</span>${note?`<small>${escapeHtml(note)}</small>`:""}${posts?`<small>Postes : ${posts}</small>`:""}</div>`);
 });
 return `<div class="history-resource"><div class="history-resource-total"><b>Mes ressources disponibles</b><strong>${fmt(resourceAccounts.filter(a=>!a.excludeTotal).reduce((sum,a)=>sum+Object.values(d.real?.[a.id]||{}).reduce((v,n)=>v+(Number(n)||0),0),0))}</strong></div>${rows.join("")}<div class="note">Données intemporelles : elles ne dépendent pas du mois ni de l’année.</div></div>`;
}

let activeNotebook=1;
function historyNotebookKey(folder=activeNotebook){return profileKey()?`gestion-financiere:history-notebook:${profileKey()}:${folder}`:`gestion-financiere:history-notebook:guest:${folder}`;}
function renderHistoryNotebook(){
 const oldKey=profileKey()?`gestion-financiere:history-notebook:${profileKey()}`:"gestion-financiere:history-notebook:guest";
 if(!localStorage.getItem(historyNotebookKey(1))&&localStorage.getItem(oldKey)!==null)localStorage.setItem(historyNotebookKey(1),localStorage.getItem(oldKey));
 try{$("historyNotebook").value=localStorage.getItem(historyNotebookKey())||"";}catch{$("historyNotebook").value="";}
 document.querySelectorAll("[data-notebook]").forEach(b=>b.classList.toggle("active",Number(b.dataset.notebook)===activeNotebook));
}
function saveHistoryNotebook(){localStorage.setItem(historyNotebookKey(),$("historyNotebook").value);alert("Bloc-notes du dossier "+activeNotebook+" enregistré.");}
function deleteHistoryMonth(year,month){
 const key=profileKey()?`gestion-financiere:${profileKey()}:${year}:${month}`:`gestion-financiere:guest:${year}:${month}`;
 if(!localStorage.getItem(key))return;
 if(confirm(`Supprimer toutes les données de ${month} ${year} ?`)){localStorage.removeItem(key);renderHistory();}
}
function renderHistory(){
 const prefix=profileKey()?`gestion-financiere:${profileKey()}:`:`gestion-financiere:guest:`;
 const entries=Object.keys(localStorage).filter(k=>k.startsWith(prefix)).map(k=>{const parts=k.split(":");return {key:k,year:parts[2],month:parts[3]};}).filter(x=>x.year&&x.month&&months.includes(x.month));
 const byYear={}; entries.forEach(e=>(byYear[e.year]??=[]).push(e));
 const years=Object.keys(byYear).sort((a,b)=>Number(b)-Number(a));
 let html=resourceHistoryHtml();
 if(!years.length){html+='<div class="note">Aucune donnée mensuelle enregistrée pour ce profil pour le moment.</div>';}else{
  html+=years.map(y=>{const monthsFound=byYear[y].sort((a,b)=>months.indexOf(b.month)-months.indexOf(a.month));return `<div class="history-year"><button type="button" data-year-toggle="${escapeAttr(y)}">📅 ${escapeHtml(y)}</button><div class="history-months">${monthsFound.map(e=>`<div class="history-month"><span><b>${escapeHtml(e.month)}</b><span class="note"> — données enregistrées</span></span><div class="history-month-actions"><button type="button" data-history-open="${escapeAttr(e.year)}|${escapeAttr(e.month)}">Ouvrir</button><button type="button" data-history-delete="${escapeAttr(e.year)}|${escapeAttr(e.month)}">Supprimer</button></div></div>`).join("")}</div></div>`;}).join("");
 }
 $("historyList").innerHTML=html;
 document.querySelectorAll("[data-history-open]").forEach(btn=>btn.onclick=()=>{const [y,m]=btn.dataset.historyOpen.split("|");$("year").value=y;$("month").value=m;renderBudget();renderSaving();renderNotes();show("budget");});
 document.querySelectorAll("[data-history-delete]").forEach(btn=>btn.onclick=()=>{const [y,m]=btn.dataset.historyDelete.split("|");deleteHistoryMonth(y,m);});
 renderHistoryNotebook();
}
function renderNotes(){const d=data();$("personalNotes").value=d.notes??"";$("notesPeriod").textContent=`${$("month").value} ${$("year").value}`;}
function saveNotes(){let d=data();d.notes=$("personalNotes").value;save(d);alert("Notes enregistrées pour "+$("month").value+" "+$("year").value+".");}

function show(id){
 ["home","identity","budget","saving","history","notes","resources","commandments"].forEach(x=>$(x).classList.toggle("hidden",x!==id));
 if(id==="budget")renderBudget();
 if(id==="saving")renderSaving();
 if(id==="history"){renderHistory();renderHistoryNotebook();}
 if(id==="notes")renderNotes();
 if(id==="resources"){buildResources();renderResources();}
 if(id==="identity"){fillIdentity(activeProfile());renderProfiles();}
}
document.querySelectorAll("[data-open]").forEach(b=>b.onclick=()=>{if(lockForProfile())show(b.dataset.open)});
document.querySelectorAll("[data-home]").forEach(b=>b.onclick=()=>show("home"));
$("openIdentity").onclick=()=>show("identity");
$("switchProfile").onclick=()=>{localStorage.removeItem("gestion-financiere:active-profile");show("identity");renderProfiles()};
$("saveIdentity").onclick=async()=>{
 const profileId=$("profileId").value.trim(); const pin=$("idPin").value.trim();
 if(!profileId){alert("Donnez un identifiant au profil.");$("profileId").focus();return;}
 if(!/^\d{4,8}$/.test(pin)){alert("Le code d’entrée doit contenir 4 à 8 chiffres.");$("idPin").focus();return;}
 const ps=profiles(); let p=activeProfile();
 if(p && p.profileId!==profileId && ps.some(x=>x.profileId.toLowerCase()===profileId.toLowerCase() && x.id!==p.id)){alert("Cet identifiant existe déjà.");return;}
 if(!p){p={id:"p-"+Date.now()+"-"+Math.random().toString(36).slice(2,8)};ps.push(p);localStorage.setItem("gestion-financiere:active-profile",p.id);}
 Object.assign(p,{profileId,idNoms:$("idNoms").value.trim(),idPrenoms:$("idPrenoms").value.trim(),idAge:$("idAge").value,idSexe:$("idSexe").value.trim(),idAdresse:$("idAdresse").value.trim(),idGmail:$("idGmail").value.trim(),idNumeros:$("idNumeros").value.trim(),idNationalite:$("idNationalite").value.trim(),idVille:$("idVille").value.trim(),idStatut:$("idStatut").value.trim(),pinHash:await hashPin(pin)});
 saveProfiles(ps); updateProfileBar(); alert("Profil enregistré."); show("home");
};
$("income").oninput=()=>{
 // Revalidate existing entries if the total budget changes.
 accounts.forEach(a=>{const limit=accountLimit(a.id),total=accountTotal(a.id); if(total>limit){const inputs=[...document.querySelectorAll(`.real[data-account="${a.id}"]`)]; let running=0; inputs.forEach(x=>{const v=Math.max(0,Number(x.value)||0); if(running+v<=limit){running+=v;x.dataset.lastValid=x.value}else{x.value="";x.dataset.lastValid=""}});}});
 updateBudget();
};
$("allocationSelect").onchange=()=>{
 const idx=Number($("allocationSelect").value)||0;
 applyAllocation(allocationOptions[idx].values);
 updateBudget();
 let d=data(); d.budget=d.budget||{}; d.budget.allocationIndex=idx; d.budget.allocation=currentAllocation.slice();
 d.budget.income=Math.max(0,Number($("income").value)||0); d.budget.real=d.budget.real||{};
 save(d);
};
$("saveBudget").onclick=saveBudget;
$("week").oninput=calc;
$("calc").onclick=calc;
$("saveSaving").onclick=saveSaving;
$("saveSaving2").onclick=saveSaving2;
$("savingMode1").onclick=()=>{savingMode=1;$("savingMode1").classList.add("active");$("savingMode2").classList.remove("active");$("savingSystem1").classList.remove("hidden");$("savingSystem2").classList.add("hidden");};
$("savingMode2").onclick=()=>{savingMode=2;$("savingMode2").classList.add("active");$("savingMode1").classList.remove("active");$("savingSystem2").classList.remove("hidden");$("savingSystem1").classList.add("hidden");renderSaving2();};
document.querySelectorAll("[data-plan2]").forEach(b=>b.onclick=()=>{if(!lockForProfile())return;currentPlan2=Number(b.dataset.plan2);let d=savingProgress();d.saving2=d.saving2||{plans:{}};d.saving2.plan=currentPlan2;d.saving2.plans=d.saving2.plans||{};saveSavingProgress(d);renderSaving2();});
$("saveNotes").onclick=saveNotes;
$("saveHistoryNotebook").onclick=saveHistoryNotebook;
document.querySelectorAll("[data-notebook]").forEach(b=>b.onclick=()=>{activeNotebook=Number(b.dataset.notebook);renderHistoryNotebook();});
document.querySelectorAll("[data-custom-post-add]").forEach(b=>b.onclick=()=>{const [account,row]=b.dataset.customPostAdd.split("|");addCustomPost(account,row);});
document.querySelectorAll("[data-custom-post-input]").forEach(input=>input.addEventListener("keydown",e=>{if(e.key==="Enter"){e.preventDefault();const [account,row]=input.dataset.customPostInput.split("|");addCustomPost(account,row);}}));
$("saveResources").onclick=saveResources;
document.querySelectorAll("[data-plan]").forEach(b=>b.onclick=()=>{
 if(!lockForProfile())return;
 currentPlan=Number(b.dataset.plan);
 let d=savingProgress(); d.saving=d.saving||{plans:{}}; d.saving.plan=currentPlan; d.saving.plans=d.saving.plans||{}; saveSavingProgress(d);
 renderSaving();
});
$("month").onchange=$("year").onchange=()=>{if(lockForProfile()){renderBudget();renderSaving();renderNotes()}};
function exportAppData(){
 const keys=Object.keys(localStorage).filter(k=>k.startsWith("gestion-financiere:"));
 const dataOut={format:"GestionFinanciere-backup",version:9,exportedAt:new Date().toISOString(),entries:{}};
 keys.forEach(k=>dataOut.entries[k]=localStorage.getItem(k));
 const blob=new Blob([JSON.stringify(dataOut,null,2)],{type:"application/json"});
 const a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download=`GestionFinanciere_${new Date().toISOString().slice(0,10)}.json`;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000);
}
async function importAppData(file){
 try{const obj=JSON.parse(await file.text());if(!obj||obj.format!=="GestionFinanciere-backup"||!obj.entries)throw new Error("Format invalide");Object.entries(obj.entries).forEach(([k,v])=>{if(k.startsWith("gestion-financiere:"))localStorage.setItem(k,String(v??""));});alert("Données importées avec succès. L’application va se recharger.");location.reload();}catch(e){alert("Impossible d’importer ce fichier de sauvegarde.");}
}
$("exportData").onclick=exportAppData;
$("importDataBtn").onclick=()=>$("importDataFile").click();
$("importDataFile").onchange=e=>{const f=e.target.files?.[0];if(f)importAppData(f);};
$("clearHistory").onclick=()=>{
 if(confirm("Effacer toutes les données de cette application sur cet appareil ?")){
  Object.keys(localStorage).filter(k=>k.startsWith("gestion-financiere:") && k!=="gestion-financiere:profiles" && k!=="gestion-financiere:active-profile").forEach(k=>localStorage.removeItem(k));
  renderHistory();
 }
};
applyAllocation(allocationOptions[0].values);
buildAccounts();
document.querySelectorAll(".real").forEach(x=>x.addEventListener("input",()=>validateRealInput(x)));
document.addEventListener("visibilitychange",()=>{if(document.visibilityState==="hidden" && activeProfile()){appLocked=true;}else if(document.visibilityState==="visible" && activeProfile() && appLocked){setTimeout(()=>unlockActiveProfile(),150);}});
window.addEventListener("pageshow",()=>{if(document.visibilityState==="visible" && activeProfile() && appLocked){setTimeout(()=>unlockActiveProfile(),150);}});

updateProfileBar();
if(profiles().length){if(activeProfile()){appLocked=true;setTimeout(()=>unlockActiveProfile(),150);}else show("identity")}else{show("identity")}
