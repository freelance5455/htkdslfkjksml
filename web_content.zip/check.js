
const RAW="Thanos|94;Galactus|97;Doctor Strange|93;Scarlet Witch|96;Thor|92;Hulk|90;Iron Man|80;Captain America|65;Spider-Man|78;Wolverine|76;Deadpool|74;Black Panther|72;Captain Marvel|86;Black Widow|60;Hawkeye|58;Ant-Man|72;Wasp|70;Vision|84;Falcon|61;Winter Soldier|68;War Machine|73;Doctor Doom|91;Loki|83;Odin|96;Hela|88;Silver Surfer|94;Adam Warlock|92;Ultron|85;Magneto|90;Professor X|86;Storm|88;Jean Grey|92;Cyclops|73;Rogue|80;Gambit|74;Nightcrawler|72;Beast|68;Iceman|88;Colossus|76;Emma Frost|82;Psylocke|79;Cable|83;Mystique|65;Sabretooth|74;Juggernaut|86;Apocalypse|89;Kitty Pryde|70;Venom|84;Carnage|88;Green Goblin|72;Doctor Octopus|68;Sandman|76;Electro|75;Lizard|68;Mysterio|65;Kraven|69;Kingpin|55;Rhino|70;Vulture|62;Morbius|72;Black Cat|58;Daredevil|65;Punisher|62;Luke Cage|72;Iron Fist|73;Jessica Jones|65;Moon Knight|72;Blade|76;Ghost Rider|94;Shang-Chi|79;She-Hulk|82;Star-Lord|67;Gamora|75;Drax|70;Rocket Raccoon|69;Groot|72;Mantis|67;Nebula|69;Nova|88;Namor|85;Quicksilver|73;Red Skull|60;Mandarin|79;Red Hulk|88;Abomination|81;Taskmaster|72;Ronan the Accuser|83;Ebony Maw|86;Super-Skrull|86;America Chavez|82;Ms. Marvel|65;Squirrel Girl|78;Cloak|78;Dormammu|96;Magik|86;Legion|97;Bullseye|57;Elektra|68;Sentry|95;Mephisto|94;The One Above All|100;God Emperor Doom|99;The Living Tribunal|99;Beyonder|99;Molecule Man|98;Phoenix Force|98;Eternity|98;Rune King Thor|97;Death|97;Onslaught|96;Knull|94;Shuma-Gorath|94;World Breaker Hulk|93;Surtur|92;Zeus|91;Cassandra Nova|90;Beta Ray Bill|89;Ego|89;Blue Marvel|89;Hyperion|88;Madame Web|58;Heimdall|72;Valkyrie|70;Hobgoblin|65;Yondu|67;Killmonger|66;Scorpion|64;Yelena Belova|63;Baron Zemo|65;Kate Bishop|60";
const TEAMS=[["Avengers","#e8353a"],["X-Men","#ffd23f"],["Guardians","#8a5cff"],["Fantastic Four","#4fd1ff"],["Defenders","#2fbf71"],["Thunderbolts","#ff8a3d"],["Eternals","#e86bd0"],["Midnight Sons","#9aa4b8"]];
const PURSE=100,TIME=10;
// Base prices are independent of hidden character-strength values. Keys are character numbers (1-130).
const BASE_PRICE_OVERRIDES={1:2,7:1.5,8:1,9:1,10:1,11:.5,12:1,13:2,14:1,15:1,16:.5,18:1.5,19:.5,20:.5,21:1,22:2,23:2,25:2,48:1,55:.5,62:1.5,63:.5,67:1,70:1,72:.5,76:.5,81:.5,87:1,91:.5,100:2};
const PL=RAW.split(";").map((x,i)=>{const[n,v]=x.split("|");const r=+v;return{n,v:r,base:BASE_PRICE_OVERRIDES[i+1]??(r>=95?2:r>=90?1.5:r>=85?1:r>=75?.5:.2),fair:.3+Math.pow(Math.max(0,r-55)/45,3)*25}});
const app=document.getElementById("app");
const sh=a=>{a=a.slice();for(let i=a.length-1;i>0;i--){const j=Math.random()*(i+1)|0;[a[i],a[j]]=[a[j],a[i]]}return a};
const esc=s=>String(s).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const money=b=>b<1?Math.round(b*1000)+"K":(+b.toFixed(2))+"M";
const inc=b=>b<1?.1:b<3?.2:b<8?.5:1;
const clone=o=>JSON.parse(JSON.stringify(o));
let mq=null,hb=null,joinBeat=null,joined=false,uid=null,code=null,S=null,isHost=false,solo=false,timer=null,paused=false,lastN=0,seen={},myName="Player",notice="";
try{myName=localStorage.getItem("ma_name")||"Player";uid=localStorage.getItem("ma_uid")}catch(e){}
if(!uid){uid="u"+Math.random().toString(36).slice(2,10);try{localStorage.setItem("ma_uid",uid)}catch(e){}}
const setOf=p=>p.v>=95?"Marquee (95+)":p.v>=85?"Elite (85 to 94)":p.v>=70?"Strong (70 to 84)":"Rising (under 70)";
const can=(t,p,price)=>t.purse>=price-1e-9&&(!S?.squadLimitEnabled||t.sq.length<(S.squadLimit||15));
const nextBid=()=>{const c=S.cur;return c.leader==null?PL[c.p].base:+(c.bid+inc(c.bid)).toFixed(2)};
const meIdx=()=>S?S.T.findIndex(t=>t.h&&t.h==uid):-1;
const owner=t=>t.h?esc(t.hn||"Player"):(S.bots?"Bot":"Open");
const score=t=>t.sq.reduce((a,k)=>a+PL[k].v,0);
let snd=true,AC=null,pv=null,primed=false;
try{snd=localStorage.getItem("ma_snd")!=="0"}catch(e){}
document.getElementById("sndb").textContent=snd?"Sound on":"Sound off";
function toggleSound(){snd=!snd;try{localStorage.setItem("ma_snd",snd?"1":"0")}catch(e){}if(!snd&&window.speechSynthesis)speechSynthesis.cancel();document.getElementById("sndb").textContent=snd?"Sound on":"Sound off"}
function ac(){try{if(!AC)AC=new(window.AudioContext||window.webkitAudioContext)();if(AC.state=="suspended")AC.resume()}catch(e){}return AC}
document.addEventListener("pointerdown",()=>{ac();if(!primed&&window.speechSynthesis){primed=true;try{const u=new SpeechSynthesisUtterance(".");u.volume=0;speechSynthesis.speak(u)}catch(e){}}});
function tn(f,t,d,type,v){const a=snd&&ac();if(!a)return;try{const o=a.createOscillator(),g=a.createGain(),n=a.currentTime+t;o.type=type||"square";o.frequency.setValueAtTime(f,n);g.gain.setValueAtTime(v||.08,n);g.gain.exponentialRampToValueAtTime(.0001,n+d);o.connect(g);g.connect(a.destination);o.start(n);o.stop(n+d+.03)}catch(e){}}
const sClick=()=>tn(700,0,.05,"square",.05);
const sBid=()=>{tn(880,0,.08,"triangle",.12);tn(1320,.07,.12,"triangle",.12)};
const sNew=()=>{tn(392,0,.12,"sawtooth",.07);tn(523,.1,.12,"sawtooth",.07);tn(659,.2,.22,"sawtooth",.07)};
const sSold=()=>{tn(110,0,.2,"sine",.35);tn(80,0,.25,"square",.1);tn(784,.2,.15,"triangle",.14);tn(1047,.32,.35,"triangle",.14)};
const sUn=()=>{tn(220,0,.25,"sawtooth",.08);tn(165,.22,.4,"sawtooth",.08)};
const sTick=()=>tn(1000,0,.04,"square",.04);
const sEnd=()=>{[523,659,784,1047].forEach((f,k)=>tn(f,k*.16,.3,"triangle",.14))};
const sp=b=>b<1?Math.round(b*1000)+" thousand":(+b.toFixed(2))+" million";
let _u=null;
function say(t){if(!snd||!window.speechSynthesis)return;try{const ss=speechSynthesis;ss.resume();ss.cancel();
 const u=_u=new SpeechSynthesisUtterance(t);u.rate=1;u.volume=1;u.lang="en-US";
 const v=(ss.getVoices()||[]).find(x=>/^en/i.test(x.lang));if(v)u.voice=v;
 setTimeout(()=>{try{ss.speak(u)}catch(e){}},150)}catch(e){}}
function showSold(k,team,bid){try{const p=PL[k],t=S.T[team];const o=document.createElement("div");o.className="rar soldFX";o.innerHTML=`<div class="rt">SOLD!</div><div class="soldmeta">${esc(p.n)}<br>${esc(t?t.n:"Winning team")} · $${money(bid)}</div>`;document.body.appendChild(o);setTimeout(()=>{try{o.remove()}catch(e){}},2450)}catch(e){}}
function fx(){if(!S)return;
 if(S.phase=="done"){if(!pv||pv.ph!="done"){const w=runTeamLeague()[0];sEnd();say("Auction complete. "+w.t.n+" wins the AI battle ranking")}pv={ph:"done"};return}
 const c=S.cur;if(S.phase!="live"||!c){pv=null;return}
 const k={ph:"live",i:S.i,bid:c.bid,l:c.leader,res:c.res,t:c.t};
 if(!pv||pv.ph!="live"||pv.i!=k.i){const r=rarOf(PL[c.p]);sNew();if(r)showRarity(r);say((r==2?"Legendary! ":r==1?"Epic! ":"")+PL[c.p].n+", for "+sp(PL[c.p].base))}
 else if(k.res&&pv.res!=k.res){if(k.res=="sold"){sSold();showSold(c.p,c.leader,c.bid);say("Sold! "+S.T[c.leader].n+", "+sp(c.bid))}else{sUn();say("Unsold")}}
 else if(k.l!=null&&(k.bid!=pv.bid||k.l!=pv.l))sBid();
 else if(!k.res&&k.t<=3&&pv.t!=k.t)sTick();
 pv=k}
const LEG=new Set(["Galactus","Thanos","Scarlet Witch","Odin","Dormammu","Legion","Sentry","Captain Marvel","Doctor Doom","Loki","Hela","Mephisto","The One Above All","God Emperor Doom","The Living Tribunal","Beyonder","Molecule Man","Phoenix Force","Eternity","Rune King Thor","Death","Onslaught"]),EPIC=new Set(["Doctor Strange","Silver Surfer","Ghost Rider","Adam Warlock","Thor","Jean Grey","Hulk","Iron Man","Vision","Magneto","Daredevil","Knull","Shuma-Gorath","World Breaker Hulk","Surtur","Zeus","Cassandra Nova","Beta Ray Bill","Ego","Blue Marvel","Hyperion"]);
const rarOf=p=>LEG.has(p.n)?2:EPIC.has(p.n)?1:0;
const sLeg=()=>{[392,523,659,784,1047].forEach((f,k)=>tn(f,k*.1,.5,"sawtooth",.09));tn(110,0,.6,"sine",.35);tn(1568,.5,.9,"triangle",.1)};
const sEpic=()=>{tn(523,0,.2,"triangle",.12);tn(784,.12,.4,"triangle",.12)};
function showRarity(r){try{const o=document.createElement("div");o.className="rar r"+r;o.innerHTML='<div class="rt">'+(r==2?"LEGENDARY":"EPIC")+"</div>"+(r==2?"<i></i><i></i><i></i><i></i><i></i><i></i>":"");
 document.body.appendChild(o);setTimeout(()=>{try{o.remove()}catch(e){}},r==2?2700:1600);
 if(r==2){document.body.classList.add("shk");setTimeout(()=>document.body.classList.remove("shk"),600)}}catch(e){}
 if(r==2)sLeg();else sEpic()}
const PICS={};
function pic(k){let el=PICS[k];if(el)return el;const name=PL[k].n,ex=["jpg","png","webp","jpeg"];
 el=PICS[k]=document.createElement("div");el.className="pic";el.textContent=name.split(/[ -]/).map(w=>w[0]).join("").slice(0,3);
 const tryImg=j=>{if(j>=ex.length)return;const im=new Image();im.alt=name;im.onload=()=>{el.textContent="";el.appendChild(im)};im.onerror=()=>tryImg(j+1);im.src="images/"+(k+1)+"."+ex[j]};
 tryImg(0);return el}
const isDone=t=>t.purse<.2-1e-9;
const allDone=()=>{const a=S.T.filter(t=>t.h||S.bots);return a.length>0&&a.every(isDone)};


function homeView(){const h=(location.hash||"").slice(1).toUpperCase(),ok=typeof mqtt!=="undefined";
 app.innerHTML=`<h1>Marvel Mega Auction</h1><p>An unofficial marvel fan game. Made by a 16yo 🥸</p>
 <div class="box"><label>Your name<input type="text" id="nm" maxlength="16" value="${esc(myName)}"></label><label>Starting purse per team ($20M–$200M)<input type="number" id="purse" min="20" max="200" step="5" value="${PURSE}"></label>
 ${ok?`<label>Room type<select id="rt"><option value="0">Private (friends join with the code)</option><option value="1">Public (listed for everyone)</option></select></label><div class="box create-options"><h2>Squad limit</h2><label><input type="checkbox" id="squadLimitEnabled" onchange="document.getElementById('squadLimitWrap').style.display=this.checked?'block':'none'"> Enable maximum characters per squad</label><div id="squadLimitWrap" style="display:none"><label>Characters allowed per squad (5–30)<input id="squadLimit" type="number" min="5" max="30" step="1" value="15"></label></div></div><div class="bar" style="margin-top:10px"><button onclick="createRoom()">Create room</button></div>
 <label>Room code<input type="text" id="rc" maxlength="6" value="${esc(h)}" placeholder="ABCDE"></label><button class="alt" onclick="joinRoom()">Join room</button>`:`<p>Multiplayer could not load. Check your internet and reload.</p>`}
 <div style="margin-top:10px"><button class="g" onclick="playSolo()">Play solo vs bots</button></div></div>
 ${ok?`<div class="box"><h2>Public rooms</h2><div id="pubList">Looking for rooms…</div></div>`:""}<p>${esc(notice)}</p>
 <div class="box"><h2>Rules</h2><p>8 franchises, so up to 8 players. Choose a $20M–$200M purse when creating a room. Teams can buy characters while they have enough money; room hosts may optionally set a 5–30 character squad limit. Character appearance chances: 20% Legendary, 30% Epic, 50% others. Every character gets ${TIME} seconds. Each new bid resets the clock to ${TIME}. No bid means unsold. Final positions are decided by AI team-strength analysis and simulated battles.</p></div>`}
function home(){homeView();browse();renderPub()}
function readName(){const n=document.getElementById("nm");myName=((n&&n.value)||"Player").trim().slice(0,16)||"Player";try{localStorage.setItem("ma_name",myName)}catch(e){}}
function setHash(){try{history.replaceState(null,"","#"+code)}catch(e){try{location.hash=code}catch(x){}}}
function chosenPurse(){const el=document.getElementById("purse");const v=el?Number(el.value):PURSE;return Math.max(20,Math.min(200,Number.isFinite(v)?v:PURSE))}
function newState(startPurse=PURSE){return{host:uid,phase:"lobby",bots:true,count:40,purse:startPurse,squadLimitEnabled:false,squadLimit:15,kicked:[],members:[],T:TEAMS.map(t=>({n:t[0],c:t[1],purse:startPurse,sq:[],h:null,hn:""})),order:[],i:-1,cur:null,log:[],history:[],hallOfFame:[],endVotes:[],endT:null}}
function playSolo(){readName();stopBrowse();isHost=true;solo=true;S=newState(chosenPurse());S.T[0].h=uid;S.T[0].hn=myName;startGame()}

const BROKERS=["wss://broker.emqx.io:8084/mqtt","wss://broker.hivemq.com:8884/mqtt"];
const tS=()=>"mcauc1/"+code+"/s",tA=()=>"mcauc1/"+code+"/a";
function connect(cb,fail,k,ns){k=k||0;if(k>=BROKERS.length)return fail();let done=false;
 const c=mqtt.connect(BROKERS[k],{connectTimeout:6000,reconnectPeriod:3000,clientId:"mc"+Math.random().toString(16).slice(2,12)});
 const bad=()=>{if(done)return;done=true;clearTimeout(t);c.end(true);connect(cb,fail,k+1,ns)};
 const t=setTimeout(bad,7000);
 c.on("connect",()=>{if(!done){done=true;clearTimeout(t);if(!ns)mq=c;cb(c)}else if(joined&&!isHost)hello()});
 c.on("error",bad)}
function createRoom(){readName();stopBrowse();const startPurse=chosenPurse(),pubSel=(document.getElementById("rt")||{}).value=="1",limitOn=!!(document.getElementById("squadLimitEnabled")||{}).checked,limitValue=Math.max(5,Math.min(30,Number((document.getElementById("squadLimit")||{}).value)||15));app.innerHTML="<p>Creating room…</p>";
 code=Math.random().toString(36).slice(2,7).toUpperCase().replace(/[^A-Z0-9]/g,"X");
 connect(c=>{isHost=true;S=newState(startPurse);S.pub=pubSel;S.squadLimitEnabled=limitOn;S.squadLimit=limitValue;S.T[0].h=uid;S.T[0].hn=myName;S.members=[{u:uid,n:myName,t:Date.now()}];setHash();c.subscribe(tA());
  c.on("message",(tp,pl)=>{let m;try{m=JSON.parse(pl)}catch(e){return}if(m.kind=="hello"){registerMember(m.u,m.name);save()}else applyAct(m.u,m)});
  hb=setInterval(save,4000);render();save()},()=>{notice="Could not reach the game server. Check your internet and try again.";home()})}
function hello(){if(mq&&mq.connected)mq.publish(tA(),JSON.stringify({kind:"hello",u:uid,name:myName}))}
function registerMember(u,n){if(!u||!S||S.phase!=="lobby"||(S.kicked||[]).includes(u))return;
 if(!S.members)S.members=[];const now=Date.now();S.members=S.members.filter(m=>now-(m.t||0)<14000||m.u===uid);
 let m=S.members.find(x=>x.u===u);if(!m){if(S.members.length>=8)return;S.members.push(m={u,n:"Player",t:now})}
 m.n=String(n||m.n||"Player").slice(0,16);m.t=now}
function refreshMembers(){if(!S||!S.members)return;const now=Date.now();S.members=S.members.filter(m=>now-(m.t||0)<14000||m.u===uid);const me=S.members.find(m=>m.u===uid);if(me){me.n=myName;me.t=now}}
function joinRoom(pc){readName();const c0=(typeof pc==="string"&&pc)||(document.getElementById("rc").value||"").trim().toUpperCase();if(!c0)return;stopBrowse();
 code=c0;app.innerHTML="<p>Joining room "+esc(c0)+"…</p>";let ok=false,tries=0,iv=null;
 const t=setTimeout(()=>{if(!ok){clearInterval(iv);clearInterval(joinBeat);notice="Host is offline or the code is wrong.";home()}},12000);
 connect(c=>{joined=true;c.subscribe(tS());
  c.on("message",(tp,pl)=>{let d;try{d=JSON.parse(pl)}catch(e){return}if(!ok){ok=true;clearTimeout(t);clearInterval(iv);setHash()}
   if(d.closed||d.phase==="closed"){clearTimeout(t);clearInterval(iv);clearInterval(joinBeat);notice="The host disbanded this room.";cleanupRoom();home();return}
   if((d.kicked||[]).includes(uid)){clearTimeout(t);clearInterval(iv);clearInterval(joinBeat);notice="The host removed you from this room.";joined=false;try{if(mq)mq.end(true)}catch(e){}mq=null;home();return}
   const already=(d.members||[]).some(m=>m.u===uid);
   if(!already&&(d.members||[]).length>=8){clearTimeout(t);clearInterval(iv);clearInterval(joinBeat);notice="This room is full (8/8 players).";try{if(mq)mq.end(true)}catch(e){}mq=null;home();return}
   S=d;render()});
  hello();iv=setInterval(()=>{if(!ok&&tries++<5)hello()},2000);joinBeat=setInterval(hello,4000)},()=>{clearTimeout(t);notice="Could not reach the game server. Check your internet and try again.";home()})}
function act(kind,x){const n=Math.max(Date.now(),lastN+1);lastN=n;
 if(mq&&mq.connected)mq.publish(tA(),JSON.stringify(Object.assign({u:uid,kind,n,name:myName,lot:S?S.i:0},x||{})));else{notice="Not connected to the host."}}
function save(){if(!isHost||solo||!mq||!mq.connected)return;refreshMembers();mq.publish(tS(),JSON.stringify(S));pubBeat()}

function applyAct(u,a){if(!isHost||!S||!a||!(a.n>(seen[u]||0)))return;seen[u]=a.n;
 if(a.kind=="claim"&&S.phase=="lobby"&&!(S.kicked||[]).includes(u)&&S.T.filter(t=>t.h).length<8)claim(u,a.team,a.name);
 else if(a.kind=="kick"&&S.phase=="lobby")kickPlayer(a.target);
 else if(a.kind=="leave")removeLeaver(u);
 else if(a.kind=="endvote"&&S.phase=="live")setVote(u,!!a.v);
 else if(a.kind=="bid"&&S.phase=="live"&&S.cur&&!paused&&a.lot==S.i){const ti=S.T.findIndex(t=>t.h==u);if(ti>=0)tryBid(ti,a.nb)}}
function claim(u,i,name){if(S.phase!="lobby"||!S.T[i]||S.T[i].h)return;
 S.T.forEach(t=>{if(t.h==u){t.h=null;t.hn=""}});S.T[i].h=u;S.T[i].hn=String(name||"Player").slice(0,16);save();render()}
function pick(i){if(isHost)claim(uid,i,myName);else act("claim",{team:i})}
function kickPlayer(target){if(!isHost||!S||S.phase!=="lobby"||!target||target===uid)return;
 const t=S.T.find(x=>x.h===target);if(!t)return;
 if(!S.kicked)S.kicked=[];if(!S.kicked.includes(target))S.kicked.push(target);
 if(S.members)S.members=S.members.filter(m=>m.u!==target);t.h=null;t.hn="";S.endVotes=(S.endVotes||[]).filter(x=>x!==target);save();render()}
function kickFromLobby(target){if(!isHost||S.phase!=="lobby")return;if(confirm("Remove this player from the room?"))kickPlayer(target)}
function toggleBots(){S.bots=!S.bots;save();render()}
let openT=new Set();
function togT(k,o){if(o)openT.add(k);else openT.delete(k)}
function endTick(){const H=S.T.filter(t=>t.h).map(t=>t.h);S.endVotes=(S.endVotes||[]).filter(u=>H.includes(u));
 const all=H.length>0&&H.every(u=>S.endVotes.includes(u));
 if(!all){if(S.endT!=null){S.endT=null;save();render()}return false}
 if(S.endT==null)S.endT=5;else S.endT--;
 if(S.endT<=0){S.early=true;S.why="vote";S.phase="done";S.cur=null;S.endT=null;clearInterval(timer);save();render();return true}
 save();render();return false}
function setVote(u,v){if(!S.endVotes)S.endVotes=[];if(!S.T.some(t=>t.h==u))return;const has=S.endVotes.includes(u);
 if(v&&!has)S.endVotes.push(u);if(!v&&has)S.endVotes.splice(S.endVotes.indexOf(u),1);save();render()}
function toggleEnd(){const i=meIdx();if(i<0||!S||S.phase!="live")return;sClick();const has=(S.endVotes||[]).includes(uid);if(isHost)setVote(uid,!has);else act("endvote",{v:!has})}
function togglePub(){S.pub=!S.pub;if(!S.pub)pubClose();save();render()}
function setCount(v){S.count=Math.max(5,Math.min(PL.length,Math.round(+v)||40));save();render()}
function setSquadLimitEnabled(v){if(!isHost||S.phase!=="lobby")return;S.squadLimitEnabled=!!v;save();render()}
function setSquadLimit(v){if(!isHost||S.phase!=="lobby")return;S.squadLimit=Math.max(5,Math.min(30,Math.round(Number(v)||15)));save();render()}
function cleanupRoom(){clearInterval(hb);clearInterval(joinBeat);clearInterval(timer);hb=null;joinBeat=null;timer=null;try{if(mq)mq.end(true)}catch(e){}mq=null;joined=false;isHost=false;solo=false;S=null;code=null;try{history.replaceState(null,"",location.pathname+location.search)}catch(e){}}
function leaveRoom(){if(!S||isHost||solo)return;if(!confirm("Leave this room?"))return;let finished=false;const finish=()=>{if(finished)return;finished=true;cleanupRoom();notice="You left the room.";home()};if(mq&&mq.connected){const n=Math.max(Date.now(),lastN+1);lastN=n;mq.publish(tA(),JSON.stringify({u:uid,kind:"leave",n,name:myName,lot:S.i}),{qos:1},finish);setTimeout(finish,1800)}else finish()}
function disbandRoom(){if(!S||!isHost||solo)return;if(!confirm("Disband this room for everyone?"))return;let finished=false;const finish=()=>{if(finished)return;finished=true;cleanupRoom();notice="Room disbanded.";home()};if(mq&&mq.connected){const closed={closed:true,host:uid,phase:"closed",members:[]};mq.publish(tS(),JSON.stringify(closed),{qos:1},()=>{if(!mq||!mq.connected){finish();return}mq.publish("mcauc1/pub/"+code,JSON.stringify({c:code,x:1}),{qos:1},finish)});setTimeout(finish,2500)}else finish()}
function removeLeaver(u){if(!isHost||!S||S.phase==="closed")return;if(S.members)S.members=S.members.filter(m=>m.u!==u);const t=S.T.find(x=>x.h===u);if(t){t.h=null;t.hn=""}S.endVotes=(S.endVotes||[]).filter(x=>x!==u);save();render()}

function weightedAuctionOrder(count){
 const remaining={legendary:PL.map((p,i)=>rarOf(p)===2?i:-1).filter(i=>i>=0),epic:PL.map((p,i)=>rarOf(p)===1?i:-1).filter(i=>i>=0),other:PL.map((p,i)=>rarOf(p)===0?i:-1).filter(i=>i>=0)};
 const weights=[['legendary',20],['epic',30],['other',50]],out=[];
 while(out.length<Math.min(count,PL.length)){
  let available=weights.filter(([k])=>remaining[k].length);
  if(!available.length)break;
  let total=available.reduce((a,x)=>a+x[1],0),roll=Math.random()*total,chosen=available[available.length-1][0];
  for(const [k,w] of available){roll-=w;if(roll<0){chosen=k;break}}
  const list=remaining[chosen],at=Math.random()*list.length|0;out.push(list.splice(at,1)[0]);
 }
 return out;
}
function startGame(){if(S.pub)pubClose();S.gameId="g"+Date.now().toString(36)+Math.random().toString(36).slice(2,7);S.order=weightedAuctionOrder(S.count);S.phase="live";S.i=-1;nextLot();startLoop()}
function startLoop(){clearInterval(timer);timer=setInterval(tick,1000)}
function nextLot(){if(S.phase!="live")return;S.i++;paused=false;
 if(S.i>=S.order.length||allDone()){S.early=S.i<S.order.length;S.why="purse";S.phase="done";S.cur=null;clearInterval(timer)}
 else{const p=PL[S.order[S.i]];S.cur={p:S.order[S.i],bid:p.base,leader:null,res:"",t:TIME,f:TEAMS.map(()=>.6+Math.random()*.7)}}
 save();render()}
function log(s){S.log.unshift(s);S.log=S.log.slice(0,6)}
function tryBid(ti,nb){const c=S.cur,t=S.T[ti];if(!c||c.res||c.leader==ti)return;
 if(Math.abs(nb-nextBid())>1e-9||!can(t,PL[c.p],nb))return;
 c.bid=nb;c.leader=ti;c.t=TIME;log(`${t.hn||t.n} (${t.n}) bids $${money(nb)}`);if(!S.history)S.history=[];S.history.push({type:"bid",lot:S.i+1,character:PL[c.p].n,player:t.hn||t.n,franchise:t.n,amount:nb,at:Date.now()});save();render()}
function botWants(i){const t=S.T[i],c=S.cur,p=PL[c.p],nb=nextBid();if(!can(t,p,nb))return false;
 const mx=Math.min(p.fair*c.f[i]*(t.sq.length<4?1.1:1),t.purse*.6);
 return nb<=Math.max(mx,p.base)&&Math.random()<.5}
function tick(){if(!isHost||!S||S.phase!="live")return;if(endTick())return;if(!S.cur||paused)return;const c=S.cur;
 if(S.bots){for(const i of sh(S.T.map((_,i)=>i))){if(S.T[i].h||i==c.leader)continue;if(botWants(i)){tryBid(i,nextBid());return}}}
 c.t--;if(c.t<=0){closeLot();return}save();render()}
function closeLot(){const c=S.cur,p=PL[c.p];paused=true;
 if(c.leader==null){c.res="unsold";log(`${p.n}: unsold`);if(!S.history)S.history=[];S.history.push({type:"unsold",lot:S.i+1,character:p.n,player:"—",franchise:"—",amount:0,at:Date.now()})}
 else{const t=S.T[c.leader];t.purse=+(t.purse-c.bid).toFixed(2);t.sq.push(c.p);c.res="sold";log(`${p.n} sold to ${t.n} for $${money(c.bid)}`);if(!S.history)S.history=[];S.history.push({type:"sold",lot:S.i+1,character:p.n,player:t.hn||t.n,franchise:t.n,amount:c.bid,at:Date.now()})}
 save();render();setTimeout(nextLot,1800)}
function bid(){const i=meIdx();if(i<0||!S.cur)return;sClick();if(isHost)tryBid(i,nextBid());else act("bid",{lot:S.i,nb:nextBid()})}

function render(){if(!S)return;fx();if(S.phase=="lobby")return lobby();if(S.phase=="done")return done();live()}
function lobby(){const me=meIdx();
 app.innerHTML=`<div class="marvel-lobby"><div class="marvel-mark">MARVEL</div><h1>MEGA AUCTION</h1><p class="lobby-tagline">An unofficial marvel fan game. Made by a 16yo 🥸</p></div><div class="box lobby-room"><p>Room code</p><div class="code">${esc(code||"SOLO")}</div>
 <p>Send your friend this website’s link and this code. Up to 8 players can join, one per franchise. Keep this screen open until the auction ends.</p>
 <h2 style="margin-top:8px">Players (${(S.members||[]).length}/8)</h2>
 <div>${(S.members||[]).map(m=>{const team=S.T.find(t=>t.h===m.u);return `<div class="row" style="margin:5px 0"><span>${esc(m.n||"Player")} · ${team?esc(team.n):"Choosing franchise"}</span>${isHost&&m.u!==uid?`<button class="no" style="padding:5px 9px" onclick="kickFromLobby('${m.u}')">Remove</button>`:""}</div>`}).join("")||"<small>No players yet</small>"}</div></div>
 <h2>Pick your franchise</h2><div class="grid" style="margin-top:10px">${S.T.map((t,i)=>`<button class="team" style="border-left-color:${t.c}" ${t.h&&t.h!=uid?"disabled":""} onclick="pick(${i})">${t.n}<br><small style="color:inherit">${i==me?"You":owner(t)}</small></button>`).join("")}</div>
 ${isHost?`<div class="box"><h2>Room settings</h2><label>Characters in this auction (5 to ${PL.length})<input type="number" min="5" max="${PL.length}" value="${S.count}" onchange="setCount(this.value)"></label><p>Starting purse: $${money(S.purse||PURSE)} per team</p><label><input type="checkbox" ${S.squadLimitEnabled?"checked":""} onchange="setSquadLimitEnabled(this.checked)"> Enable maximum characters per squad</label>${S.squadLimitEnabled?`<label>Characters per squad (5–30)<input type="number" min="5" max="30" value="${S.squadLimit||15}" onchange="setSquadLimit(this.value)"></label><p>Each squad can buy up to ${S.squadLimit||15} characters.</p>`:"<p>No squad character limit.</p>"}
 <label><input type="checkbox" ${S.bots?"checked":""} onchange="toggleBots()"> Bots fill the franchises nobody picks</label>
 <label><input type="checkbox" ${S.pub?"checked":""} onchange="togglePub()"> Public room (listed for everyone)</label></div>
 <button ${me<0?"disabled":""} onclick="startGame()">Start auction</button><p>${me<0?"Pick your own franchise first.":""}</p>`:`<p>${me<0?"Pick a franchise, then wait for the host to start.":"Waiting for the host to start."} The host will auction ${S.count} characters.</p>`}${isHost&&!solo?`<button class="no" style="margin-top:10px" onclick="disbandRoom()">Disband room</button>`:`<button class="no" style="margin-top:10px" onclick="leaveRoom()">Leave room</button>`}<p>${esc(notice)}</p>`}
function live(){const c=S.cur,p=PL[c.p],i=meIdx(),me=i>=0?S.T[i]:null,nb=nextBid(),lead=c.leader==null?null:S.T[c.leader];
 const ok=me&&!c.res&&c.leader!=i&&can(me,p,nb),H=S.T.filter(t=>t.h).map(t=>t.h),vn=(S.endVotes||[]).filter(u=>H.includes(u)).length,voted=(S.endVotes||[]).includes(uid);
 const why=!me?"You are watching":(S.squadLimitEnabled&&me&&me.sq.length>=(S.squadLimit||15)?"Squad limit reached":c.res?(c.res=="sold"?"Sold":"Unsold"):c.leader==i?"You lead the bid":!can(me,p,nb)?"Not enough purse":"");
 app.innerHTML=`<div class="row"><small>Lot ${S.i+1} of ${S.order.length}</small><small>Room ${esc(code||"solo")}</small></div><div class="row" style="margin-top:6px">${isHost&&!solo?`<button class="no" onclick="disbandRoom()">Disband room</button>`:`${solo?"":"<button class=\"no\" onclick=\"leaveRoom()\">Leave room</button>"}`}</div>
 <div class="box ${rarOf(p)==2?"g2":rarOf(p)==1?"g1":""}"><div class="row" style="align-items:flex-start"><div id="pic" class="pic"></div><div style="flex:1;min-width:0"><div class="hero">${p.n}</div><div style="margin:6px 0">${rarOf(p)==2?'<span class="tag" style="background:#ffd23f">LEGENDARY</span>':rarOf(p)==1?'<span class="tag" style="background:#c9a0ff">EPIC</span>':""}<span class="tag" style="background:#fff">Base $${money(p.base)}</span></div></div><div class="big" style="color:${c.t<=3&&!c.res?"var(--r)":"var(--c)"}">${c.res?"":c.t}</div></div>
 <div class="big">$${money(c.bid)}</div>
 <div style="margin-top:4px">${c.res=="sold"?`<b class="sold">Sold to ${esc(lead.n)}</b>`:c.res=="unsold"?`<b class="un">Unsold</b>`:lead?`<span class="dot" style="background:${lead.c}"></span>${c.leader==i?"You are":esc(lead.n)+(lead.h?" ("+esc(lead.hn)+") is":" is")} leading`:"No bids yet. "+TIME+" seconds, then unsold"}</div></div>
 <div class="bar"><button ${ok?"":"disabled"} onclick="bid()">${c.leader==i&&me?"You lead":"Bid $"+money(nb)}</button></div>
 <p style="min-height:22px">${why}</p>
 ${me?`<div class="bar"><button class="${voted?"no":"g"}" onclick="toggleEnd()">${voted?"Cancel end vote":"End auction"} (${vn}/${H.length})</button></div>`:""}${S.endT!=null?`<p><b class="un">Auction ends in ${S.endT}s. Tap Cancel end vote to stop it.</b></p>`:""}
 ${me?`<div class="box"><div class="row"><b style="color:${me.c}">${me.n}</b><span>Purse $${money(me.purse)} · ${me.sq.length}${S.squadLimitEnabled?"/"+(S.squadLimit||15):""} characters</span></div><div style="margin-top:6px;font-size:13px;color:var(--m)">${me.sq.map(k=>PL[k].n).join(", ")||"No players yet"}</div></div>`:""}
 <div class="box log">${S.log.map(l=>`<div>${esc(l)}</div>`).join("")||"<div>Waiting for the first bid</div>"}</div>
 <div class="box"><h2>All teams</h2><table><tr><th>Franchise</th><th>Owner</th><th>Purse</th><th>Squad</th></tr>${S.T.map((t,k)=>`<tr class="${k==i?"me":""}"><td><span class="dot" style="background:${t.c}"></span>${t.n}</td><td>${owner(t)}</td><td>$${money(t.purse)}</td><td><details ${openT.has(k)?"open":""} ontoggle="togT(${k},this.open)"><summary>${t.sq.length} chars</summary><div style="min-width:130px;white-space:normal">${t.sq.map(x=>esc(PL[x].n)).join(", ")||"No characters yet"}</div></details></td></tr>`).join("")}</table></div>`;const sl=document.getElementById("pic");if(sl)sl.replaceWith(pic(c.p));const nx=S.order[S.i+1];if(nx!=null)pic(nx)}
// Team-strength engine: nonlinear character impact, diminishing returns, team synergy,
// then a seeded round-robin simulation. Internal strength values are never shown in the UI.
const ROLE={
 "Galactus":"cosmic", "Thor":"cosmic magic", "Thanos":"cosmic", "Silver Surfer":"cosmic", "Adam Warlock":"cosmic", "Odin":"cosmic magic", "Captain Marvel":"cosmic", "Nova":"cosmic", "Dormammu":"cosmic magic", "Mephisto":"cosmic magic", "Ghost Rider":"magic", "Sentry":"cosmic", "Legion":"mutant magic", "Jean Grey":"mutant psychic", "Professor X":"mutant psychic", "Magneto":"mutant", "Storm":"mutant", "Iceman":"mutant", "Apocalypse":"mutant", "Cable":"mutant tech", "Wolverine":"mutant", "Scarlet Witch":"magic", "Doctor Strange":"magic", "Doctor Doom":"magic tech", "Loki":"magic", "Hela":"magic", "Magik":"mutant magic", "Vision":"tech", "Ultron":"tech", "Iron Man":"tech", "War Machine":"tech", "Ant-Man":"tech", "Wasp":"tech", "Black Panther":"tech tactical", "Mister Fantastic":"tech", "Spider-Man":"street tech", "Daredevil":"street tactical", "Punisher":"street tactical", "Hawkeye":"street tactical", "Black Widow":"street tactical", "Shang-Chi":"street tactical", "Taskmaster":"street tactical", "Kingpin":"street tactical", "Bullseye":"street tactical", "Captain America":"tactical", "Winter Soldier":"tactical", "Falcon":"tactical tech", "Gamora":"cosmic tactical", "Nebula":"cosmic tech", "Rocket Raccoon":"cosmic tech", "Star-Lord":"cosmic tech", "Groot":"cosmic", "Mantis":"cosmic psychic", "Drax":"cosmic brute", "Hulk":"brute", "Red Hulk":"brute", "Abomination":"brute", "Juggernaut":"brute mutant", "Colossus":"brute mutant", "She-Hulk":"brute", "Rhino":"brute", "Sandman":"brute", "Luke Cage":"brute street", "Namor":"brute cosmic", "Venom":"brute", "Carnage":"brute", "Super-Skrull":"cosmic brute", "Ronan the Accuser":"cosmic brute", "Ebony Maw":"cosmic magic", "Mandarin":"magic tech", "Mystique":"mutant tactical", "Rogue":"mutant", "Cyclops":"mutant tactical", "Gambit":"mutant tactical", "Nightcrawler":"mutant", "Beast":"mutant tech", "Emma Frost":"mutant psychic", "Psylocke":"mutant psychic", "Kitty Pryde":"mutant", "Sabretooth":"mutant brute", "Quicksilver":"mutant", "Cloak":"magic", "America Chavez":"cosmic", "Ms. Marvel":"cosmic", "Squirrel Girl":"brute", "Elektra":"street tactical", "Blade":"street tactical", "Moon Knight":"street tactical", "Iron Fist":"street magic", "Jessica Jones":"street brute", "Morbius":"street", "Black Cat":"street tactical", "Green Goblin":"tech tactical", "Doctor Octopus":"tech tactical", "Electro":"tech", "Mysterio":"tech tactical", "Lizard":"brute", "Vulture":"tech", "Kraven":"street tactical", "Red Skull":"tactical", "Deadpool":"street tactical", "Eternals":"cosmic", "The One Above All":"cosmic", "God Emperor Doom":"cosmic magic tech", "The Living Tribunal":"cosmic magic", "Beyonder":"cosmic", "Molecule Man":"cosmic tech", "Phoenix Force":"cosmic magic psychic", "Eternity":"cosmic", "Rune King Thor":"cosmic magic", "Death":"cosmic magic", "Onslaught":"mutant psychic cosmic", "Knull":"cosmic magic", "Shuma-Gorath":"cosmic magic", "World Breaker Hulk":"brute cosmic", "Surtur":"cosmic magic brute", "Zeus":"cosmic magic", "Cassandra Nova":"mutant psychic", "Beta Ray Bill":"cosmic brute", "Ego":"cosmic", "Blue Marvel":"cosmic tech", "Hyperion":"cosmic brute", "Madame Web":"psychic", "Heimdall":"cosmic magic", "Valkyrie":"cosmic tactical", "Hobgoblin":"tech tactical", "Yondu":"cosmic tactical", "Killmonger":"street tactical", "Scorpion":"street brute", "Yelena Belova":"street tactical", "Baron Zemo":"tactical", "Kate Bishop":"street tactical"
};
const TEAM_WEIGHTS=[1,.34,.20,.13,.09,.065,.045,.03,.02,.015,.01,.007];
function tagsFor(p){return (ROLE[p.n]||"fighter").split(" ")}
function teamAnalysis(t){
 const chars=t.sq.map(k=>PL[k]).sort((a,b)=>b.v-a.v);
 // A character's impact grows non-linearly; stacking many low-tier characters has diminishing value.
 const contributions=chars.map((p,i)=>Math.pow(p.v/100,2.2)*100*(TEAM_WEIGHTS[i]||.004));
 const raw=contributions.reduce((a,b)=>a+b,0);
 const counts={};chars.forEach(p=>tagsFor(p).forEach(tag=>counts[tag]=(counts[tag]||0)+1));
 let pairs=0;Object.values(counts).forEach(n=>pairs+=n*(n-1)/2);
 const synergy=Math.min(0.14, pairs*.012 + ((counts.cosmic&&counts.magic)?0.025:0) + ((counts.mutant&&counts.psychic)?0.02:0) + ((counts.tech&&counts.tactical)?0.015:0));
 const rating=raw*(1+synergy);
 return {t,chars,raw,synergy,rating,counts};
}
function chemistryDetails(a){
 const c=a.counts||{},out=[];
 if(c.cosmic&&c.magic)out.push("Cosmic + Magic");
 if(c.mutant&&c.psychic)out.push("Mutant + Psychic");
 if(c.tech&&c.tactical)out.push("Tech + Tactical");
 Object.entries(c).filter(([k,v])=>v>=2).sort((x,y)=>y[1]-x[1]).forEach(([k,v])=>out.push(`${v} ${k[0].toUpperCase()+k.slice(1)}`));
 return out.length?out.slice(0,5):["No strong role combination yet"];
}
function matchupBonus(a,b){
 const A=a.counts,B=b.counts;let x=0;
 if(A.psychic&&B.tactical)x+=.025;
 if(A.magic&&B.tech)x+=.02;
 if(A.cosmic&&B.street)x+=.025;
 if(A.tech&&B.brute)x+=.015;
 if(A.brute&&B.psychic)x+=.01;
 return x;
}
function seeded(seed){let x=seed>>>0;return()=>{x=(x+0x6D2B79F5)|0;let z=x;z=Math.imul(z^(z>>>15),z|1);z^=z+Math.imul(z^(z>>>7),z|61);return ((z^(z>>>14))>>>0)/4294967296}}
function runTeamLeague(){
 const a=S.T.map((t,k)=>Object.assign(teamAnalysis(t),{k,wins:0,played:0}));
 for(let i=0;i<a.length;i++)for(let j=i+1;j<a.length;j++){
  const A=a[i],B=a[j],delta=(A.rating-B.rating)/Math.max(12,(A.rating+B.rating)*.20);
  const pA=1/(1+Math.exp(-delta*2.4+matchupBonus(B,A)-matchupBonus(A,B)));
  const seed=(A.t.sq.reduce((x,n)=>x*31+n+1,7)+B.t.sq.reduce((x,n)=>x*37+n+3,11)+i*101+j*997)>>>0,rng=seeded(seed);
  for(let r=0;r<100;r++){if(rng()<pA)A.wins++;else B.wins++;A.played++;B.played++;}
 }
 return a.sort((x,y)=>y.wins-x.wins||y.rating-x.rating||y.raw-x.raw);
}
function recordHallOfFame(rank,mvp){
 const gameId=S.gameId||("legacy-"+(code||"solo")+"-"+(S.i||0));
 const record={gameId,date:new Date().toLocaleDateString(),room:code||"Solo",champion:rank[0]?.t?.hn||rank[0]?.t?.n||"Unknown",franchise:rank[0]?.t?.n||"Unknown",mvp:mvp?.p?.n||"—",mvpOwner:mvp?.t?.hn||mvp?.t?.n||"—"};
 if(isHost){if(!S.hallOfFame)S.hallOfFame=[];if(!S.hallOfFame.some(x=>x.gameId===gameId)){S.hallOfFame.unshift(record);S.hallOfFame=S.hallOfFame.slice(0,20);S.hallRecorded=gameId;save()}}
 try{const key="ma_hof_v1",old=JSON.parse(localStorage.getItem(key)||"[]");if(!old.some(x=>x.gameId===gameId)){old.unshift(record);localStorage.setItem(key,JSON.stringify(old.slice(0,30)))}}catch(e){}
 const shared=S.hallOfFame||[];let local=[];try{local=JSON.parse(localStorage.getItem("ma_hof_v1")||"[]")}catch(e){}
 const all=[...shared,...local],seenIds=new Set();return all.filter(x=>{if(!x||!x.gameId||seenIds.has(x.gameId))return false;seenIds.add(x.gameId);return true}).slice(0,20);
}
function done(){const rank=runTeamLeague(),i=meIdx(),pos=rank.findIndex(r=>r.k==i)+1,me=i>=0?S.T[i]:null,w=rank[0];
 const pct=r=>r.played?Math.round(r.wins/r.played*100):0;
 const medal=n=>n===1?"🥇":n===2?"🥈":n===3?"🥉":"#"+n;
 const profiles=rank.filter(r=>r.t.h).map(r=>{const n=rank.findIndex(x=>x.k===r.k)+1,spent=+(S.purse-r.t.purse).toFixed(2);return `<div class="profile" style="border-left-color:${r.t.c}"><div class="profile-head"><div class="avatar" style="background:${r.t.c}">${esc((r.t.hn||"P").slice(0,1).toUpperCase())}</div><div style="flex:1;min-width:0"><h3 style="margin:0">${medal(n)} ${esc(r.t.hn||"Player")}</h3><p style="margin:2px 0"><span class="dot" style="background:${r.t.c}"></span>${esc(r.t.n)}</p></div><b style="color:var(--y)">${pct(r)}%</b></div><div class="stats"><div class="stat"><b>#${n}</b><small>RANK</small></div><div class="stat"><b>${r.t.sq.length}</b><small>CHARACTERS</small></div><div class="stat"><b>${r.wins}/${r.played}</b><small>BATTLE WINS</small></div><div class="stat"><b>$${money(spent)}</b><small>SPENT</small></div><div class="stat"><b>$${money(r.t.purse)}</b><small>REMAINING</small></div><div class="stat"><b>${r.rating.toFixed(1)}</b><small>TEAM SCORE</small></div><div class="stat"><b>${Math.round(r.synergy*100)}%</b><small>CHEMISTRY</small></div></div><h3 style="margin:8px 0">Squad chemistry</h3><div class="chips">${chemistryDetails(r).map(x=>`<span class="chip">⚡ ${esc(x)}</span>`).join("")}</div><h3 style="margin:8px 0">Complete squad (${r.t.sq.length})</h3><div class="chips">${r.chars.map(p=>`<span class="chip">${esc(p.n)}</span>`).join("")||'<small>No characters bought</small>'}</div></div>`}).join("")||"<p>No human players participated in this auction.</p>";
 const mvpCandidates=[];S.T.forEach((t,k)=>t.sq.forEach(ch=>mvpCandidates.push({p:PL[ch],t,k})));mvpCandidates.sort((a,b)=>b.p.v-a.p.v||rank.findIndex(r=>r.k===a.k)-rank.findIndex(r=>r.k===b.k));const mvp=mvpCandidates[0];
 const history=(S.history||[]).slice().reverse(),hall=recordHallOfFame(rank,mvp);
 app.innerHTML=`<h1>Auction complete</h1>${S.early?`<p>Ended early: ${S.why=="vote"?"everyone voted to end the auction.":"every franchise is out of money."}</p>`:""}<div class="box g2"><p>AI battle ranking · Champion</p><div class="hero" style="color:var(--y)">${esc(w.t.n)}</div><p>${w.t.h?esc(w.t.hn)+" wins":"The bot franchise wins"} · ${pct(w)}% simulated win rate</p></div>
 ${me?`<p>${pos==1?"That is you. Congratulations!":"You finish "+pos+" of "+S.T.length+"."}</p>`:""}
 ${mvp?`<div class="box mvp"><div style="font-size:32px">🏆</div><h2>FINAL MVP</h2><div class="hero" style="font-size:34px;color:var(--y)">${esc(mvp.p.n)}</div><p>Outstanding character of this auction</p><h3 style="margin:6px 0">${esc(mvp.t.hn||"Bot franchise")}</h3><p>${esc(mvp.t.n)} · Highest character rating in the final squads</p></div>`:""}
 <div class="box"><h2>Final AI rankings</h2><p>100 simulated battles against each other franchise. Rankings are based on AI team analysis and simulated matchups.</p><table><tr><th>#</th><th>Franchise</th><th>Owner</th><th>Battle wins</th><th>Win rate</th><th>Chemistry</th></tr>${rank.map((r,n)=>`<tr class="${r.k==i?"me":""}"><td>${medal(n+1)}</td><td><span class="dot" style="background:${r.t.c}"></span>${esc(r.t.n)}</td><td>${esc(r.t.hn||"Bot")}</td><td>${r.wins}/${r.played}</td><td>${pct(r)}%</td><td>${Math.round(r.synergy*100)}%</td></tr>`).join("")}</table></div>
 <div class="box"><h2>Player profile cards · full squad rankings</h2><p>Every human player who participated is ranked here. Each card shows the complete squad and auction performance.</p>${profiles}</div>
 <div class="box"><h2>Squad chemistry</h2><p>Matching character roles create a team bonus in the battle model. These combinations are calculated from each final squad.</p>${rank.filter(r=>r.t.h).map(r=>`<div style="margin:10px 0"><b>${esc(r.t.hn||r.t.n)} · ${Math.round(r.synergy*100)}% chemistry</b><div class="chips">${chemistryDetails(r).map(x=>`<span class="chip">⚡ ${esc(x)}</span>`).join("")}</div></div>`).join("")||"<small>No human squads to analyse.</small>"}</div>
 <div class="box"><h2>Hall of Fame 🏆</h2><p>Champions and MVPs from this room, including previous rematches. This history is saved on this device too.</p>${hall.length?hall.map((h,n)=>`<div class="row" style="padding:8px 0;border-bottom:1px solid #ffffff18;align-items:flex-start"><div style="min-width:0"><b>${n===0?"🏆 ":""}${esc(h.champion)}</b><small style="display:block">${esc(h.franchise)} · MVP: ${esc(h.mvp)} (${esc(h.mvpOwner)})</small><small>${esc(h.date)} · Room ${esc(h.room)}</small></div><b>#${n+1}</b></div>`).join(""):`<p>No completed auctions recorded yet.</p>`}</div>
 <div class="box"><h2>Auction history</h2><p>${history.length} recorded events · newest first</p><details><summary>Open complete auction history</summary><div class="history-table"><table><tr><th>Lot</th><th>Event</th><th>Character</th><th>Player / team</th><th>Amount</th></tr>${history.map(h=>`<tr><td>${h.lot}</td><td><span class="${h.type==="sold"?"sold":h.type==="unsold"?"un":""}">${h.type==="sold"?"SOLD":h.type==="unsold"?"UNSOLD":"BID"}</span></td><td>${esc(h.character)}</td><td>${esc(h.player)}${h.franchise&&h.franchise!==h.player?` · ${esc(h.franchise)}`:""}</td><td>${h.amount?"$"+money(h.amount):"—"}</td></tr>`).join("")||'<tr><td colspan="5">No auction events recorded.</td></tr>'}</table></div></details></div>
 <div class="box"><h2>How ranking works</h2><p>The AI evaluates character strength, diminishing returns for additional roster members, team synergy, and matchup advantages. Every franchise faces every other franchise in a seeded 100-round matchup simulation. This is a local game model, not an official Marvel power scale.</p></div>
 ${isHost?`<button onclick="rematch()">Rematch with same room</button>${solo?"":`<button class="no" onclick="disbandRoom()">Disband room</button>`}`:`<p>Waiting for the host to start a rematch.</p><button class="no" onclick="leaveRoom()">Leave room</button>`} <button class="alt" onclick="location.reload()">Back to start</button>`}
function rematch(){if(!S||S.phase!=="done"||!isHost)return;if(!confirm("Start a new auction with the same room players and settings?"))return;const old=S,purse=old.purse||PURSE;const next=newState(purse);next.count=old.count;next.bots=old.bots;next.pub=old.pub;next.squadLimitEnabled=!!old.squadLimitEnabled;next.squadLimit=old.squadLimit||15;next.members=clone(old.members||[]);next.hallOfFame=clone(old.hallOfFame||[]);next.T=TEAMS.map((t,i)=>({n:t[0],c:t[1],purse,sq:[],h:old.T[i].h||null,hn:old.T[i].hn||""}));S=next;seen={};pv=null;if(solo){startGame()}else{save();render();pubBeat()}}

let bq=null,browseGen=0,pubRooms={};
function pubBeat(){if(!isHost||solo||!S||!S.pub||S.phase!="lobby"||!mq||!mq.connected)return;mq.publish("mcauc1/pub/"+code,JSON.stringify({c:code,h:myName,n:S.T.filter(t=>t.h).length,cnt:S.count}))}
function pubClose(){if(isHost&&!solo&&mq&&mq.connected)mq.publish("mcauc1/pub/"+code,JSON.stringify({c:code,x:1}))}
function browse(){if(bq||typeof mqtt==="undefined")return;const g=++browseGen;
 connect(c=>{if(g!==browseGen){try{c.end(true)}catch(e){}return}bq=c;c.subscribe("mcauc1/pub/#");
  c.on("message",(tp,pl)=>{let m;try{m=JSON.parse(pl)}catch(e){return}if(!m)return;
   const k=String(m.c||"").replace(/[^A-Z0-9]/g,"").slice(0,6);if(!k)return;
   if(m.x)delete pubRooms[k];else pubRooms[k]={c:k,h:String(m.h||"Player").slice(0,16),n:Math.max(0,Math.min(8,+m.n||0)),cnt:+m.cnt||0,t:Date.now()};renderPub()})},()=>{},0,true)}
function stopBrowse(){browseGen++;if(bq){try{bq.end(true)}catch(e){}bq=null}pubRooms={}}
function renderPub(){const el=document.getElementById("pubList");if(!el)return;const now=Date.now();
 for(const k in pubRooms)if(now-pubRooms[k].t>12000)delete pubRooms[k];
 const l=Object.values(pubRooms).filter(r=>r.n<8).sort((a,b)=>b.n-a.n);
 el.innerHTML=l.length?l.map(r=>`<div class="row" style="margin:8px 0;gap:10px"><span>${esc(r.h)}’s room · ${r.n}/8 players · ${r.cnt} characters</span><button class="alt" onclick="joinRoom('${r.c}')">Join</button></div>`).join(""):"<p>No public rooms right now. Create one to start!</p>"}
setInterval(renderPub,3000);
home();

