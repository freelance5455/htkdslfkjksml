

        // Ethiopian calendar helpers. Dates are stored internally as Gregorian ISO dates
        // for compatibility, but entered and displayed in Ethiopian calendar (E.C.).
        var ETH_MONTHS = ['Meskerem','Tikimt','Hidar','Tahsas','Tir','Yekatit','Megabit','Miazia','Ginbot','Sene','Hamle','Nehasse','Pagume'];
        var ethFormatter = new Intl.DateTimeFormat('en-u-ca-ethiopic', { year:'numeric', month:'numeric', day:'numeric', timeZone:'UTC' });
        function gregorianToEth(iso) {
            if (!iso) return '';
            var p = iso.split('-').map(Number);
            var d = new Date(Date.UTC(p[0], p[1]-1, p[2]));
            var parts = ethFormatter.formatToParts(d), out = {};
            parts.forEach(function(x){ if(x.type==='year'||x.type==='month'||x.type==='day') out[x.type]=Number(x.value); });
            return String(out.day).padStart(2,'0')+'/'+String(out.month).padStart(2,'0')+'/'+out.year;
        }
        function ethToGregorian(value) {
            if (!value) return '';
            var m = String(value).trim().match(/^(\d{1,2})[\/.-](\d{1,2})[\/.-](\d{4})$/);
            if (!m) return '';
            var day=Number(m[1]), month=Number(m[2]), year=Number(m[3]);
            if(month<1||month>13||day<1||day>(month===13?6:30)) return '';
            var startYear = year + 7;
            var start = Date.UTC(startYear, 8, 5), end = Date.UTC(startYear, 9, 20);
            for(var t=start;t<=end;t+=86400000){
                var parts=ethFormatter.formatToParts(new Date(t)), o={};
                parts.forEach(function(x){if(x.type==='year'||x.type==='month'||x.type==='day')o[x.type]=Number(x.value);});
                if(o.year===year&&o.month===month&&o.day===day){
                    var d=new Date(t);
                    return d.getUTCFullYear()+'-'+String(d.getUTCMonth()+1).padStart(2,'0')+'-'+String(d.getUTCDate()).padStart(2,'0');
                }
            }
            return '';
        }
        function formatEthiopianDateInput(input) {
            // Keep DD/MM/YYYY with exactly two automatic slashes; preserve cursor while editing.
            var oldValue = String(input.value || '');
            var oldCursor = typeof input.selectionStart === 'number' ? input.selectionStart : oldValue.length;
            var digitsBeforeCursor = oldValue.slice(0, oldCursor).replace(/\D/g, '').length;
            var digits = oldValue.replace(/\D/g, '').slice(0, 8);
            var formatted = digits.slice(0, 2);
            if (digits.length > 2) formatted += '/' + digits.slice(2, 4);
            if (digits.length > 4) formatted += '/' + digits.slice(4, 8);
            input.value = formatted;
            var newCursor = digitsBeforeCursor;
            if (digitsBeforeCursor > 2) newCursor += 1;
            if (digitsBeforeCursor > 4) newCursor += 1;
            newCursor = Math.min(newCursor, formatted.length);
            if (typeof input.setSelectionRange === 'function') {
                try { input.setSelectionRange(newCursor, newCursor); } catch (e) {}
            }
        }
        function ethDateForInput(iso){
            if (!iso) return '';
            // Keep a manually entered Ethiopian date visible when conversion is unavailable.
            if (/^\d{1,2}\/\d{1,2}\/\d{4}$/.test(String(iso).trim())) return String(iso).trim();
            return gregorianToEth(iso);
        }
        function ethMonthIndex(name){ return ETH_MONTHS.indexOf(name); }
        function ethMonthStartIso(year, monthIndex){
            var value='01/'+String(monthIndex+1).padStart(2,'0')+'/'+year;
            return ethToGregorian(value);
        }

        // PERSISTENCE STATE & DATA REPOSITORY
        var students = JSON.parse(localStorage.getItem('kor_students_data')) || [
            { id: '1', seriesNo: 1, name: 'Abebech Tadesse', gender: 'EF', phone: '+251 91 123 4567', labourId: 'EF-8849', batchMonth: 'November', registerYear: '2026', course: 'Housekeeping', paymentStatus: 'Paid', amountPaid: 3500, registerDate: '2026-10-01', finishingDate: '2026-11-15', passports: [], paymentSlip: null, attendance: [{ date: '2026-11-09', status: 'Present' }] },
            { id: '2', seriesNo: 2, name: 'Mulugeta Assefa', gender: 'EM', phone: '+251 92 345 6789', labourId: 'EM-9921', batchMonth: 'November', registerYear: '2026', course: 'Care Giving', paymentStatus: 'Unpaid', amountPaid: 0, registerDate: '2026-10-10', finishingDate: '2026-11-25', passports: [], paymentSlip: null, attendance: [] }
        ];

        var inventory = JSON.parse(localStorage.getItem('kor_inventory_data')) || [
            { id: 'inv-1', code: 'INV-101', name: 'Steam Iron', category: 'Housekeeping Lab', quantity: 15, unit: 'Pcs', condition: 'Good' },
            { id: 'inv-2', code: 'INV-102', name: 'Practical Sewing Machine', category: 'Garment & Sewing', quantity: 8, unit: 'Pcs', condition: 'Good' }
        ];

        var uploadedPassports = [];
        var uploadedPaymentSlip = null;
        var cameraStream = null;
        var activeScannerSource = 'camera';
        var currentScannerTarget = 'passport';
        var tempHwScanData = null;

        window.persistStudentsData = function() {
            try {
                localStorage.setItem('kor_students_data', JSON.stringify(students));
            } catch (err) {
                console.warn("Storage warning: batching student data");
            }
        };

        window.executeMonthlyBatchGeneration = function() {
            var month = document.getElementById('genBatchMonth').value;
            var year = document.getElementById('genBatchYear').value;
            var count = Number(document.getElementById('genBatchCount').value) || 300;
            
            generate300TraineesForMonth(month, year, count);
            closeModal('generateBatchModal');
        };

        window.generate300TraineesForMonth = function(targetMonth, targetYear, count) {
            targetMonth = targetMonth || 'Meskerem';
            targetYear = targetYear || '2026';
            count = count || 300;

            var firstNamesFemale = ['Abebech', 'Tigist', 'Hana', 'Hiwot', 'Genet', 'Meskrem', 'Aster', 'Birtukan', 'Selam', 'Frehiwot', 'Helen', 'Worknesh', 'Meron', 'Kedija', 'Fatuma'];
            var firstNamesMale = ['Mulugeta', 'Dawit', 'Yonas', 'Tewodros', 'Kassahun', 'Biniyam', 'Ermias', 'Girma', 'Solomon', 'Getachew', 'Henok', 'Alemayehu'];
            var lastNames = ['Tadesse', 'Assefa', 'Girma', 'Worku', 'Bekele', 'Tekle', 'Haile', 'Megersa', 'Alemu', 'Kebede', 'Mengistu', 'Dibaba', 'Tolossa', 'Fikre'];
            var courses = ['Housekeeping', 'Care Giving', 'Laundry Operation', 'Preparation of Food & Beverage', 'Life Skill', 'Entrepreneurship', 'Garment & Sewing'];

            var startSeries = students.length > 0 ? Math.max(...students.map(function(s) { return Number(s.seriesNo) || 0; })) + 1 : 1;
            var monthIndex = ethMonthIndex(targetMonth);
            if (monthIndex < 0) monthIndex = 0;
            var monthNumber = String(monthIndex + 1).padStart(2, '0');
            var lastDay = monthIndex === 12 ? ((Number(targetYear) % 4 === 3) ? 6 : 5) : 30;
            var batchStartIso = ethMonthStartIso(Number(targetYear), monthIndex);
            var batchEndIso = ethToGregorian(String(lastDay).padStart(2,'0')+'/'+monthNumber+'/'+targetYear);
            var newStudents = [];

            for (var i = 0; i < count; i++) {
                var isFemale = Math.random() > 0.3;
                var gender = isFemale ? 'EF' : 'EM';
                var fnList = isFemale ? firstNamesFemale : firstNamesMale;
                var fname = fnList[Math.floor(Math.random() * fnList.length)];
                var lname = lastNames[Math.floor(Math.random() * lastNames.length)];
                var course = courses[Math.floor(Math.random() * courses.length)];
                var isPaid = Math.random() > 0.25;

                var seriesNo = startSeries + i;
                var labourId = '';
                var phone = '+251 9' + Math.floor(Math.random() * 89999999 + 10000000);

                var attRecords = [];
                var numLogs = Math.floor(Math.random() * 5);
                for (var k = 0; k < numLogs; k++) {
                    var day = (k + 1) < 10 ? '0' + (k + 1) : (k + 1);
                    attRecords.push({
                        date: ethToGregorian(day + '/' + monthNumber + '/' + targetYear),
                        status: Math.random() > 0.15 ? 'Present' : (Math.random() > 0.5 ? 'Absent' : 'Late')
                    });
                }

                newStudents.push({
                    id: String(Date.now() + i),
                    seriesNo: seriesNo,
                    gender: gender,
                    name: fname + ' ' + lname,
                    phone: phone,
                    labourId: labourId,
                    batchMonth: targetMonth,
                    registerYear: targetYear,
                    course: course,
                    paymentStatus: isPaid ? 'Paid' : 'Unpaid',
                    amountPaid: isPaid ? 3500 : 0,
                    registerDate: batchStartIso,
                    finishingDate: batchEndIso,
                    passports: [],
                    paymentSlip: null,
                    attendance: attRecords
                });
            }

            students = students.concat(newStudents);
            persistStudentsData();

            var batchFilter = document.getElementById('batchMonthFilter');
            if (batchFilter) batchFilter.value = targetMonth;
            
            filterStudents();
            showToast("Successfully generated " + count + " trainees for " + targetMonth + " " + targetYear + "!");
        };

        window.generate300Trainees = function() {
            generate300TraineesForMonth('Meskerem', '2019', 300);
        };

        window.persistInventoryData = function() {
            localStorage.setItem('kor_inventory_data', JSON.stringify(inventory));
        };

        window.generateSeriesNumber = function() {
            if (!students || students.length === 0) return 1;
            var maxSeries = Math.max(...students.map(function(s) { return Number(s.seriesNo) || 0; }));
            return maxSeries + 1;
        };

        window.ensureEthiopiaPhonePrefix = function(inputEl) {
            if (!inputEl.value || !inputEl.value.startsWith('+251')) {
                inputEl.value = '+251 ';
            }
        };

        // Labour ID is entered manually. Never generate, rewrite, or truncate it.
        window.updateLabourIdPrefix = function() {
            return;
        };

        window.openModal = function(id) {
            var el = document.getElementById(id);
            if (el) {
                el.classList.remove('hidden');
                if (id === 'studentModal' && !document.getElementById('editingStudentId').value) {
                    var seriesInput = document.getElementById('inputSeriesNo');
                    if (seriesInput) seriesInput.value = generateSeriesNumber();
                    
                    var today = new Date(Date.now() - new Date().getTimezoneOffset() * 60000).toISOString().split('T')[0];
                    var regDateInput = document.getElementById('inputRegisterDate');
                    if (regDateInput && !regDateInput.value) regDateInput.value = ethDateForInput(today);
                    
                    var yearMonthInput = document.getElementById('inputYearMonth');
                    if (yearMonthInput && !yearMonthInput.value) yearMonthInput.value = new Date().toISOString().slice(0,7);
                    
                    updateLabourIdPrefix();
                }
            }
        };

        window.renderStudentTable = function(dataList) {
            var list = dataList || students;
            var tbody = document.getElementById('studentTableBody');
            if(!tbody) return;

            if (!list || list.length === 0) {
                tbody.innerHTML = '<tr><td colspan="10" class="py-12 text-center text-slate-400 dark:text-slate-500"><i data-lucide="inbox" class="w-8 h-8 mx-auto mb-2 opacity-50"></i><p class="text-xs font-medium">No registered trainees found.</p></td></tr>';
                if(window.lucide) window.lucide.createIcons();
                return;
            }

            tbody.innerHTML = list.map(function(s) {
                var photosCount = (s.passports && s.passports.length) ? s.passports.length : 0;
                var hasSlip = s.paymentSlip ? true : false;
                var payBadge = s.paymentStatus === 'Paid' 
                    ? '<span class="px-2 py-0.5 rounded-md bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300 font-bold text-[10px]">Paid</span>' 
                    : '<span class="px-2 py-0.5 rounded-md bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-300 font-bold text-[10px]">Unpaid</span>';

                var slipBtn = hasSlip 
                    ? '<button type="button" onclick="previewImageModal(\'' + s.paymentSlip + '\')" class="px-2 py-1 bg-blue-100 dark:bg-blue-950 hover:bg-blue-200 text-blue-700 dark:text-blue-300 rounded-lg text-[10px] font-semibold flex items-center space-x-1 cursor-pointer"><i data-lucide="receipt" class="w-3 h-3"></i><span>Slip</span></button>'
                    : '<span class="text-[10px] text-slate-400 italic">No Slip</span>';

                var genderTag = s.gender === 'EM' 
                    ? '<span class="px-1.5 py-0.5 bg-blue-100 text-blue-700 dark:bg-blue-950 dark:text-blue-300 rounded text-[9px] font-extrabold ml-1">EM</span>'
                    : '<span class="px-1.5 py-0.5 bg-pink-100 text-pink-700 dark:bg-pink-950 dark:text-pink-300 rounded text-[9px] font-extrabold ml-1">EF</span>';

                return '<tr class="hover:bg-slate-50/80 dark:hover:bg-slate-700/40 transition cursor-pointer" onclick="editStudent(\'' + s.id + '\')">' +
                    '<td class="py-3 px-4 font-mono font-bold text-slate-900 dark:text-white"><span class="px-2 py-0.5 bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 rounded text-[11px]">' + s.seriesNo + '</span></td>' +
                    '<td class="py-3 px-4 font-semibold text-slate-900 dark:text-white"><div class="hover:underline font-bold flex items-center">' + s.name + genderTag + '</div><div class="text-[10px] font-normal text-slate-400 mt-0.5">' + (s.course || 'Housekeeping') + ' • ' + (s.batchMonth || 'Batch') + '</div></td>' +
                    '<td class="py-3 px-4 font-mono text-slate-700 dark:text-slate-300 font-bold">' + (s.labourId || 'EF-000') + '</td>' +
                    '<td class="py-3 px-4 font-mono text-slate-700 dark:text-slate-300 font-medium text-[11px]">' + (s.phone || '+251 900000000') + '</td>' +
                    '<td class="py-3 px-4 font-medium"><div class="flex items-center space-x-1.5">' + payBadge + '<span class="text-slate-600 dark:text-slate-400 font-mono text-[11px]">' + (s.amountPaid || 0) + ' ETB</span></div></td>' +
                    '<td class="py-3 px-4 font-mono text-slate-600 dark:text-slate-400 text-[11px]">' + (ethDateForInput(s.registerDate) || 'N/A') + '</td>' +
                    '<td class="py-3 px-4 font-mono text-slate-600 dark:text-slate-400 text-[11px]">' + (ethDateForInput(s.finishingDate) || 'N/A') + '</td>' +
                    '<td class="py-3 px-4" onclick="event.stopPropagation()"><button type="button" onclick="openAttendanceModal(\'' + s.id + '\')" class="px-2.5 py-1 bg-emerald-50 dark:bg-emerald-950/60 hover:bg-emerald-100 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 rounded-lg text-[11px] font-semibold flex items-center space-x-1 cursor-pointer transition"><i data-lucide="calendar-check" class="w-3.5 h-3.5"></i><span>Log (' + (s.attendance ? s.attendance.length : 0) + ')</span></button></td>' +
                    '<td class="py-3 px-4 text-center" onclick="event.stopPropagation()"><div class="flex items-center justify-center space-x-1"><button type="button" onclick="editStudent(\'' + s.id + '\')" class="p-1.5 text-slate-400 hover:text-blue-600 dark:hover:text-blue-400 rounded-lg transition cursor-pointer"><i data-lucide="edit-3" class="w-4 h-4"></i></button><button type="button" onclick="deleteStudent(\'' + s.id + '\')" class="p-1.5 text-slate-400 hover:text-red-600 dark:hover:text-red-400 rounded-lg transition cursor-pointer"><i data-lucide="trash-2" class="w-4 h-4"></i></button></div></td>' +
                    '<td class="py-3 px-4 text-right" onclick="event.stopPropagation()">' +
                        '<div class="flex items-center justify-end space-x-2">' +
                            '<button type="button" onclick="previewTraineePhotos(\'' + s.id + '\')" class="px-2 py-1 bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 rounded-lg text-[10px] font-semibold text-slate-700 dark:text-slate-300 flex items-center space-x-1 cursor-pointer"><i data-lucide="image" class="w-3 h-3"></i><span>' + photosCount + ' Photos</span></button>' +
                            slipBtn +
                        '</div>' +
                    '</td>' +
                '</tr>';
            }).join('');

            updateStatsCounters();
            if(window.lucide) window.lucide.createIcons();
        };

        window.filterStudents = function(payFilter) {
            var query = (document.getElementById('searchInput')?.value || '').toLowerCase();
            var course = document.getElementById('courseFilter')?.value || 'all';
            var batchMonth = document.getElementById('batchMonthFilter')?.value || 'all';

            var filtered = students.filter(function(s) {
                var matchesQuery = !query || 
                    s.name.toLowerCase().includes(query) || 
                    (s.phone && s.phone.toLowerCase().includes(query)) ||
                    (s.labourId && s.labourId.toLowerCase().includes(query)) ||
                    String(s.seriesNo).includes(query);

                var matchesCourse = course === 'all' || s.course === course;
                var matchesBatch = batchMonth === 'all' || s.batchMonth === batchMonth;
                var matchesPay = !payFilter || payFilter === 'all' || 
                    (payFilter === 'paid' && s.paymentStatus === 'Paid') ||
                    (payFilter === 'unpaid' && s.paymentStatus !== 'Paid');

                return matchesQuery && matchesCourse && matchesBatch && matchesPay;
            });

            renderStudentTable(filtered);
        };

        window.saveStudent = function(e) {
            e.preventDefault();
            var editId = document.getElementById('editingStudentId').value;
            var seriesNo = Number(document.getElementById('inputSeriesNo').value) || generateSeriesNumber();
            var gender = document.getElementById('inputGender').value;
            var name = document.getElementById('inputName').value.trim();
            var phone = document.getElementById('inputPhone').value.trim();
            var labourId = document.getElementById('inputLabourId').value.trim();
            if (/^EM/i.test(labourId)) gender = 'EM';
            else if (/^EF/i.test(labourId)) gender = 'EF';
            var batchMonth = document.getElementById('inputBatchMonth').value;
            var registerYear = document.getElementById('inputRegisterYear').value;
            var registerDateInput = document.getElementById('inputRegisterDate').value.trim();
            var finishingDateInput = document.getElementById('inputFinishingDate').value.trim();
            // Save the entered date as-is if calendar conversion cannot parse it; never block Save for date validation.
            var registerDate = ethToGregorian(registerDateInput) || registerDateInput;
            var finishingDate = ethToGregorian(finishingDateInput) || finishingDateInput;
            var course = document.getElementById('inputCourse').value;
            var paymentStatus = document.getElementById('inputPaymentStatus').value;
            var amountPaid = Number(document.getElementById('inputAmountPaid').value) || 0;


            if (editId) {
                var idx = students.findIndex(function(s) { return s.id === editId; });
                if (idx !== -1) {
                    students[idx] = {
                        id: editId,
                        seriesNo: seriesNo,
                        gender: gender,
                        name: name,
                        phone: phone,
                        labourId: labourId,
                        batchMonth: batchMonth,
                        registerYear: registerYear,
                        registerDate: registerDate,
                        finishingDate: finishingDate,
                        course: course,
                        paymentStatus: paymentStatus,
                        amountPaid: amountPaid,
                        passports: [...uploadedPassports],
                        paymentSlip: uploadedPaymentSlip,
                        attendance: students[idx].attendance || []
                    };
                }
            } else {
                students.push({
                    id: String(Date.now()),
                    seriesNo: seriesNo,
                    gender: gender,
                    name: name,
                    phone: phone,
                    labourId: labourId,
                    batchMonth: batchMonth,
                    registerYear: registerYear,
                    registerDate: registerDate,
                    finishingDate: finishingDate,
                    course: course,
                    paymentStatus: paymentStatus,
                    amountPaid: amountPaid,
                    passports: [...uploadedPassports],
                    paymentSlip: uploadedPaymentSlip,
                    attendance: []
                });
            }

            persistStudentsData();
            renderStudentTable();
            closeModal('studentModal');
            showToast("Trainee saved successfully!");
        };

        window.editStudent = function(id) {
            var student = students.find(function(s) { return s.id === id; });
            if (!student) return;

            document.getElementById('editingStudentId').value = student.id;
            document.getElementById('inputSeriesNo').value = student.seriesNo;
            document.getElementById('inputGender').value = student.gender || 'EF';
            document.getElementById('inputName').value = student.name;
            document.getElementById('inputPhone').value = student.phone || '+251 ';
            document.getElementById('inputLabourId').value = student.labourId || '';
            document.getElementById('inputBatchMonth').value = student.batchMonth || 'Meskerem';
            document.getElementById('inputRegisterYear').value = student.registerYear || '2026';
            document.getElementById('inputRegisterDate').value = ethDateForInput(student.registerDate || '');
            document.getElementById('inputFinishingDate').value = ethDateForInput(student.finishingDate || '');
            document.getElementById('inputCourse').value = student.course || 'Housekeeping';
            document.getElementById('inputPaymentStatus').value = student.paymentStatus || 'Paid';
            document.getElementById('inputAmountPaid').value = student.amountPaid || 0;

            uploadedPassports = student.passports ? [...student.passports] : [];
            uploadedPaymentSlip = student.paymentSlip || null;

            renderPassportThumbnails();
            renderPaymentSlipThumbnail();

            document.getElementById('studentModalTitle').textContent = 'Edit Trainee Details';
            openModal('studentModal');
        };

        window.renderAttendanceHistory = function(student) {
            var container = document.getElementById('attendanceHistoryList');
            if(!container) return;
            var history = student.attendance || [];

            if (history.length === 0) {
                container.innerHTML = '<p class="text-xs text-slate-400 italic">No attendance recorded yet.</p>';
                return;
            }

            container.innerHTML = history.map(function(att, idx) {
                var badgeClass = att.status === 'Present' ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300' :
                    att.status === 'Absent' ? 'bg-red-100 text-red-700 dark:bg-red-950 dark:text-red-300' : 'bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-300';

                return '<div class="flex items-center justify-between p-2 bg-slate-50 dark:bg-slate-900 rounded-xl text-xs border border-slate-200 dark:border-slate-700">' +
                    '<span class="font-mono font-bold text-slate-700 dark:text-slate-300">' + ethDateForInput(att.date) + '</span>' +
                    '<div class="flex items-center space-x-2">' +
                        '<span class="px-2 py-0.5 rounded-md text-[10px] font-extrabold ' + badgeClass + '">' + att.status + '</span>' +
                        '<button type="button" onclick="editAttendanceEntry(\'' + student.id + '\', ' + idx + ')" class="text-blue-600 hover:text-blue-800 dark:text-blue-400 p-1 cursor-pointer"><i data-lucide="edit-2" class="w-3.5 h-3.5"></i></button>' +
                        '<button type="button" onclick="deleteAttendanceEntry(\'' + student.id + '\', ' + idx + ')" class="text-red-600 hover:text-red-800 dark:text-red-400 p-1 cursor-pointer"><i data-lucide="trash-2" class="w-3.5 h-3.5"></i></button>' +
                    '</div>' +
                '</div>';
            }).join('');
            if(window.lucide) window.lucide.createIcons();
        };

        window.editAttendanceEntry = function(studentId, idx) {
            var student = students.find(function(s) { return s.id === studentId; });
            if (!student || !student.attendance[idx]) return;

            var entry = student.attendance[idx];
            document.getElementById('attDate').value = ethDateForInput(entry.date);
            document.getElementById('attStatus').value = entry.status;

            student.attendance.splice(idx, 1);
            renderAttendanceHistory(student);
        };

        window.deleteAttendanceEntry = function(studentId, idx) {
            var student = students.find(function(s) { return s.id === studentId; });
            if (!student) return;

            student.attendance.splice(idx, 1);
            persistStudentsData();
            renderAttendanceHistory(student);
            renderStudentTable();
            showToast("Attendance record removed.");
        };

        window.deleteStudent = function(id) {
            students = students.filter(function(s) { return s.id !== id; });
            persistStudentsData();
            renderStudentTable();
            showToast("Trainee removed.");
        };

        window.updateStatsCounters = function() {
            var total = students.length;
            var paid = students.filter(function(s) { return s.paymentStatus === 'Paid'; }).length;
            var unpaid = students.filter(function(s) { return s.paymentStatus !== 'Paid'; }).length;
            var invTotal = inventory.reduce(function(sum, item) { return sum + (Number(item.quantity) || 0); }, 0);

            var elTotal = document.getElementById('statTotalEnrolled');
            var elPaid = document.getElementById('statPaidTrainees');
            var elUnpaid = document.getElementById('statUnpaidTrainees');
            var elInv = document.getElementById('statInventoryCount');

            if (elTotal) elTotal.textContent = total;
            if (elPaid) elPaid.textContent = paid;
            if (elUnpaid) elUnpaid.textContent = unpaid;
            if (elInv) elInv.textContent = invTotal;
        };

        window.closeModal = function(id) {
            var el = document.getElementById(id);
            if (el) el.classList.add('hidden');
        };

        window.handleBackdropClick = function(event, modalId) {
            if (event.target === document.getElementById(modalId)) {
                closeModal(modalId);
            }
        };

        window.showToast = function(msg) {
            var toast = document.createElement('div');
            toast.className = 'fixed bottom-5 right-5 bg-slate-900 text-white text-xs px-4 py-2.5 rounded-xl shadow-xl z-50 transition-opacity duration-300';
            toast.textContent = msg;
            document.body.appendChild(toast);
            setTimeout(function() {
                toast.style.opacity = '0';
                setTimeout(function() { toast.remove(); }, 300);
            }, 2500);
        };

        window.switchMainTab = function(tabName) {
            var tabRegistrar = document.getElementById('tabRegistrar');
            var tabInventory = document.getElementById('tabInventory');
            var navReg = document.getElementById('navBtnRegistrar');
            var navInv = document.getElementById('navBtnInventory');

            if (tabName === 'registrar') {
                if(tabRegistrar) tabRegistrar.classList.remove('hidden');
                if(tabInventory) tabInventory.classList.add('hidden');
                if(navReg) navReg.className = "px-4 py-2 rounded-xl text-xs font-bold bg-emerald-600 text-white shadow-md transition cursor-pointer flex items-center space-x-2";
                if(navInv) navInv.className = "px-4 py-2 rounded-xl text-xs font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 transition cursor-pointer flex items-center space-x-2";
            } else if (tabName === 'inventory') {
                if(tabRegistrar) tabRegistrar.classList.add('hidden');
                if(tabInventory) tabInventory.classList.remove('hidden');
                if(navReg) navReg.className = "px-4 py-2 rounded-xl text-xs font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 transition cursor-pointer flex items-center space-x-2";
                if(navInv) navInv.className = "px-4 py-2 rounded-xl text-xs font-bold bg-purple-600 text-white shadow-md transition cursor-pointer flex items-center space-x-2";
            }
            if(window.lucide) window.lucide.createIcons();
        };

        window.renderInventoryTable = function(invList) {
            var list = invList || inventory;
            var tbody = document.getElementById('inventoryTableBody');
            if(!tbody) return;

            if (!list || list.length === 0) {
                tbody.innerHTML = '<tr><td colspan="5" class="py-12 text-center text-slate-400 dark:text-slate-500"><i data-lucide="package-open" class="w-8 h-8 mx-auto mb-2 opacity-50"></i><p class="text-xs font-medium">No inventory equipment found.</p></td></tr>';
                if(window.lucide) window.lucide.createIcons();
                return;
            }

            tbody.innerHTML = list.map(function(item) {
                var condBadge = item.condition === 'Good' 
                    ? '<span class="px-2 py-0.5 bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300 rounded font-bold text-[10px]">Good</span>'
                    : '<span class="px-2 py-0.5 bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-300 rounded font-bold text-[10px]">' + item.condition + '</span>';

                return '<tr class="hover:bg-slate-50/80 dark:hover:bg-slate-700/40 transition cursor-pointer" onclick="editInventoryItem(\'' + item.id + '\')">' +
                    '<td class="py-3 px-4 font-semibold text-slate-900 dark:text-white"><div class="font-bold">' + item.name + '</div><div class="text-[10px] text-slate-400 font-mono">CODE: ' + (item.code || 'INV-00') + '</div></td>' +
                    '<td class="py-3 px-4 text-slate-600 dark:text-slate-300 font-medium">' + (item.category || 'Practical Lab') + '</td>' +
                    '<td class="py-3 px-4 font-mono font-bold text-slate-800 dark:text-slate-200"><span class="text-sm">' + (item.quantity || 0) + '</span> ' + (item.unit || 'Pcs') + '</td>' +
                    '<td class="py-3 px-4">' + condBadge + '</td>' +
                    '<td class="py-3 px-4 text-right" onclick="event.stopPropagation()">' +
                        '<div class="flex items-center justify-end space-x-1">' +
                            '<button type="button" onclick="adjustInventoryQty(\'' + item.id + '\', 1)" class="px-2 py-1 bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 hover:bg-emerald-200 rounded font-bold text-[11px] transition cursor-pointer">+1</button>' +
                            '<button type="button" onclick="adjustInventoryQty(\'' + item.id + '\', -1)" class="px-2 py-1 bg-amber-100 dark:bg-amber-950 text-amber-700 dark:text-amber-300 hover:bg-amber-200 rounded font-bold text-[11px] transition cursor-pointer">-1</button>' +
                            '<button type="button" onclick="editInventoryItem(\'' + item.id + '\')" class="p-1.5 text-slate-400 hover:text-blue-600 dark:hover:text-blue-400 rounded-lg transition cursor-pointer"><i data-lucide="edit-3" class="w-4 h-4"></i></button>' +
                            '<button type="button" onclick="deleteInventoryItem(\'' + item.id + '\')" class="p-1.5 text-slate-400 hover:text-red-600 dark:hover:text-red-400 rounded-lg transition cursor-pointer"><i data-lucide="trash-2" class="w-4 h-4"></i></button>' +
                        '</div>' +
                    '</td>' +
                '</tr>';
            }).join('');

            updateStatsCounters();
            if(window.lucide) window.lucide.createIcons();
        };

        window.filterInventory = function() {
            var query = (document.getElementById('searchInventoryInput')?.value || '').toLowerCase();
            var filtered = inventory.filter(function(i) {
                return i.name.toLowerCase().includes(query) || 
                    (i.code && i.code.toLowerCase().includes(query)) ||
                    (i.category && i.category.toLowerCase().includes(query));
            });
            renderInventoryTable(filtered);
        };

        window.saveInventoryItem = function(e) {
            e.preventDefault();
            var editId = document.getElementById('editingInventoryId').value;
            var name = document.getElementById('inputInvName').value.trim();
            var code = document.getElementById('inputInvCode').value.trim() || 'INV-' + Math.floor(Math.random()*900 + 100);
            var quantity = Number(document.getElementById('inputInvQty').value) || 0;
            var category = document.getElementById('inputInvCategory').value.trim() || 'General';
            var condition = document.getElementById('inputInvCondition').value;

            if (editId) {
                var idx = inventory.findIndex(function(i) { return i.id === editId; });
                if (idx !== -1) {
                    inventory[idx] = { id: editId, name: name, code: code, quantity: quantity, unit: 'Pcs', category: category, condition: condition };
                }
            } else {
                inventory.push({ id: 'inv-' + Date.now(), name: name, code: code, quantity: quantity, unit: 'Pcs', category: category, condition: condition });
            }

            persistInventoryData();
            renderInventoryTable();
            closeModal('inventoryModal');
            showToast("Equipment item saved!");
        };

        window.adjustInventoryQty = function(id, delta) {
            var item = inventory.find(function(i) { return i.id === id; });
            if (item) {
                item.quantity = Math.max(0, (Number(item.quantity) || 0) + delta);
                persistInventoryData();
                renderInventoryTable();
            }
        };

        window.editInventoryItem = function(id) {
            var item = inventory.find(function(i) { return i.id === id; });
            if (!item) return;

            document.getElementById('editingInventoryId').value = item.id;
            document.getElementById('inputInvName').value = item.name;
            document.getElementById('inputInvCode').value = item.code || '';
            document.getElementById('inputInvQty').value = item.quantity || 0;
            document.getElementById('inputInvCategory').value = item.category || '';
            document.getElementById('inputInvCondition').value = item.condition || 'Good';

            document.getElementById('inventoryModalTitle').textContent = 'Edit Equipment';
            openModal('inventoryModal');
        };

        window.deleteInventoryItem = function(id) {
            inventory = inventory.filter(function(i) { return i.id !== id; });
            persistInventoryData();
            renderInventoryTable();
            showToast("Equipment deleted.");
        };

        window.openAttendanceModal = function(studentId) {
            var student = students.find(function(s) { return s.id === studentId; });
            if (!student) return;

            document.getElementById('attendanceStudentId').value = student.id;
            document.getElementById('attendanceModalTitle').textContent = 'Attendance: ' + student.name;
            document.getElementById('attDate').value = ethDateForInput(new Date().toISOString().slice(0,10));

            renderAttendanceHistory(student);
            openModal('attendanceModal');
        };

        window.saveAttendanceRecord = function() {
            var studentId = document.getElementById('attendanceStudentId').value;
            var date = ethToGregorian(document.getElementById('attDate').value);
            if (!date) { showToast('Enter a valid Ethiopian attendance date (DD/MM/YYYY).'); return; }
            var status = document.getElementById('attStatus').value;

            var student = students.find(function(s) { return s.id === studentId; });
            if (student) {
                if (!student.attendance) student.attendance = [];
                student.attendance.unshift({ date: date, status: status });
                persistStudentsData();
                renderAttendanceHistory(student);
                renderStudentTable();
                showToast("Attendance logged!");
            }
        };

        window.previewImageModal = function(src) {
            var img = document.getElementById('previewModalImage');
            if (img) {
                img.src = src;
                openModal('imagePreviewModal');
            }
        };

        window.previewTraineePhotos = function(studentId) {
            var student = students.find(function(s) { return s.id === studentId; });
            if (student && student.passports && student.passports.length > 0) {
                previewImageModal(student.passports[0]);
            } else {
                showToast("No photos uploaded for this trainee.");
            }
        };

        window.openScannerModal = function(targetType) {
            currentScannerTarget = targetType;
            openModal('scannerModal');
            switchScannerSource('camera');
        };

        window.switchScannerSource = function(source) {
            activeScannerSource = source;
            var camView = document.getElementById('scannerCamView');
            var hwView = document.getElementById('scannerHwView');
            var fileView = document.getElementById('scannerFileView');

            var tabCam = document.getElementById('scanTabCam');
            var tabHw = document.getElementById('scanTabHw');
            var tabFile = document.getElementById('scanTabFile');

            [tabCam, tabHw, tabFile].forEach(function(t) {
                if(t) t.className = "flex-1 py-1.5 rounded-lg text-xs font-semibold text-slate-600 dark:text-slate-400 transition cursor-pointer flex items-center justify-center space-x-1.5 hover:text-slate-900 dark:hover:text-white";
            });

            if (source === 'camera') {
                if(tabCam) tabCam.className = "flex-1 py-1.5 rounded-lg text-xs font-semibold text-emerald-700 dark:text-emerald-400 bg-white dark:bg-slate-800 shadow-sm transition cursor-pointer flex items-center justify-center space-x-1.5";
                if(camView) camView.classList.remove('hidden');
                if(hwView) hwView.classList.add('hidden');
                if(fileView) fileView.classList.add('hidden');
                startScannerCamera();
            } else if (source === 'hardware') {
                if(tabHw) tabHw.className = "flex-1 py-1.5 rounded-lg text-xs font-semibold text-emerald-700 dark:text-emerald-400 bg-white dark:bg-slate-800 shadow-sm transition cursor-pointer flex items-center justify-center space-x-1.5";
                if(camView) camView.classList.add('hidden');
                if(hwView) hwView.classList.remove('hidden');
                if(fileView) fileView.classList.add('hidden');
                stopScannerCamera();
            } else if (source === 'file') {
                if(tabFile) tabFile.className = "flex-1 py-1.5 rounded-lg text-xs font-semibold text-blue-700 dark:text-blue-400 bg-white dark:bg-slate-800 shadow-sm transition cursor-pointer flex items-center justify-center space-x-1.5";
                if(camView) camView.classList.add('hidden');
                if(hwView) hwView.classList.add('hidden');
                if(fileView) fileView.classList.remove('hidden');
                stopScannerCamera();
            }
        };

        window.startScannerCamera = function() {
            var video = document.getElementById('scannerVideo');
            if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
                navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } })
                    .then(function(stream) {
                        cameraStream = stream;
                        if (video) video.srcObject = stream;
                    })
                    .catch(function() {
                        showToast("Camera access unavailable.");
                    });
            }
        };

        window.stopScannerCamera = function() {
            if (cameraStream) {
                cameraStream.getTracks().forEach(function(track) { track.stop(); });
                cameraStream = null;
            }
        };

        window.closeScannerModal = function() {
            stopScannerCamera();
            closeModal('scannerModal');
        };

        window.handleHwScanSelect = function(e) {
            var file = e.target.files[0];
            if (!file) return;
            var reader = new FileReader();
            reader.onload = function(evt) {
                tempHwScanData = evt.target.result;
                var hwImg = document.getElementById('hwScanImg');
                var hwPrev = document.getElementById('hwScanPreview');
                if (hwImg && hwPrev) {
                    hwImg.src = tempHwScanData;
                    hwPrev.classList.remove('hidden');
                }
            };
            reader.readAsDataURL(file);
        };

        window.handleModalFileSelect = function(e) {
            var file = e.target.files[0];
            if (!file) return;
            var reader = new FileReader();
            reader.onload = function(evt) {
                tempHwScanData = evt.target.result;
                attachScannedResult(tempHwScanData);
                closeScannerModal();
            };
            reader.readAsDataURL(file);
        };

        window.captureScannerFrame = function() {
            if (activeScannerSource === 'camera') {
                var video = document.getElementById('scannerVideo');
                var canvas = document.getElementById('scannerCanvas');
                if (!video || !canvas) return;

                canvas.width = video.videoWidth || 640;
                canvas.height = video.videoHeight || 480;
                var ctx = canvas.getContext('2d');
                ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

                var dataUrl = canvas.toDataURL('image/jpeg');
                attachScannedResult(dataUrl);
                closeScannerModal();
            } else if (activeScannerSource === 'hardware' || activeScannerSource === 'file') {
                if (!tempHwScanData) {
                    showToast("Please acquire scan or select file first!");
                    return;
                }
                attachScannedResult(tempHwScanData);
                closeScannerModal();
            }
        };

        window.attachScannedResult = function(imageData) {
            if (currentScannerTarget === 'passport') {
                uploadedPassports.push(imageData);
                renderPassportThumbnails();
                showToast("Passport photo attached!");
            } else if (currentScannerTarget === 'paymentSlip') {
                uploadedPaymentSlip = imageData;
                renderPaymentSlipThumbnail();
                showToast("Payment slip attached!");
            }
        };

        window.renderPassportThumbnails = function() {
            var container = document.getElementById('passportThumbnailsContainer');
            if(!container) return;
            container.innerHTML = uploadedPassports.map(function(img, idx) {
                return '<div class="relative w-16 h-16 rounded-xl overflow-hidden border border-slate-200 dark:border-slate-700 shadow-sm group">' +
                    '<img src="' + img + '" class="w-full h-full object-cover">' +
                    '<button type="button" onclick="removePassportPhoto(' + idx + ')" class="absolute top-1 right-1 w-5 h-5 bg-red-600 text-white rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition cursor-pointer"><i data-lucide="x" class="w-3 h-3"></i></button>' +
                '</div>';
            }).join('');
            if(window.lucide) window.lucide.createIcons();
        };

        window.removePassportPhoto = function(idx) {
            uploadedPassports.splice(idx, 1);
            renderPassportThumbnails();
        };

        window.renderPaymentSlipThumbnail = function() {
            var container = document.getElementById('slipThumbnailContainer');
            if(!container) return;
            if(uploadedPaymentSlip) {
                container.innerHTML = '<div class="relative w-20 h-20 rounded-xl overflow-hidden border border-slate-200 dark:border-slate-700 shadow-sm group">' +
                    '<img src="' + uploadedPaymentSlip + '" class="w-full h-full object-cover">' +
                    '<button type="button" onclick="removePaymentSlip()" class="absolute top-1 right-1 w-5 h-5 bg-red-600 text-white rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition cursor-pointer"><i data-lucide="x" class="w-3 h-3"></i></button>' +
                '</div>';
            } else {
                container.innerHTML = '<span class="text-xs text-slate-400 italic">No slip uploaded</span>';
            }
            if(window.lucide) window.lucide.createIcons();
        };

        window.removePaymentSlip = function() {
            uploadedPaymentSlip = null;
            renderPaymentSlipThumbnail();
        };

        window.exportToExcel = function() {
            if (typeof XLSX === 'undefined') {
                showToast("Excel library loading...");
                return;
            }
            var exportData = students.map(function(s) {
                return {
                    'S.Number': s.seriesNo,
                    'Name': s.name,
                    'Labour ID': s.labourId || '',
                    'Phone Number': s.phone || '',
                    'Payment Status': s.paymentStatus,
                    'Amount Paid (ETB)': s.amountPaid || 0,
                    'Register Day': s.registerDate || '',
                    'Finishing Day': s.finishingDate || '',
                    'Photos Attached': (s.passports && s.passports.length) ? s.passports.length : 0,
                    'Attendance Logs': (s.attendance && s.attendance.length) ? s.attendance.length : 0
                };
            });

            var ws = XLSX.utils.json_to_sheet(exportData);
            var wb = XLSX.utils.book_new();
            XLSX.utils.book_append_sheet(wb, ws, "Trainees");
            XLSX.writeFile(wb, 'KOR_Institute_Trainees_' + new Date(Date.now() - new Date().getTimezoneOffset() * 60000).toISOString().split('T')[0] + '.xlsx');
            showToast("Exported to Excel!");
        };

        window.shareToSocial = function(platform) {
            var total = students.length;
            var paid = students.filter(function(s) { return s.paymentStatus === 'Paid'; }).length;
            var text = encodeURIComponent('KOR Overseas Institute Summary:\nTotal Trainees: ' + total + '\nPaid Enrolments: ' + paid);

            if (platform === 'telegram') window.open('https://t.me/share/url?url=' + encodeURIComponent(location.href) + '&text=' + text);
            if (platform === 'whatsapp') window.open('https://api.whatsapp.com/send?text=' + text);
        };

        window.copyShareSummary = function() {
            var total = students.length;
            var paid = students.filter(function(s) { return s.paymentStatus === 'Paid'; }).length;
            var text = 'KOR Overseas Employment Institute Summary\nTotal Enrolled: ' + total + '\nPaid Trainees: ' + paid + '\nGenerated: ' + new Date().toLocaleDateString();
            
            navigator.clipboard.writeText(text);
            showToast("Summary copied to clipboard!");
            closeModal('shareModal');
        };

        // INITIAL EXECUTION WRAPPER
        window.addEventListener('DOMContentLoaded', function() {
            switchMainTab('registrar');
            renderStudentTable(students);
            renderInventoryTable(inventory);
            if(window.lucide) window.lucide.createIcons();
            if ('serviceWorker' in navigator && location.protocol !== 'file:') {
                window.addEventListener('load', function() {
                    navigator.serviceWorker.register('./service-worker.js').catch(function(err) {
                        console.warn('Offline support registration failed:', err);
                    });
                });
            }
        });
    