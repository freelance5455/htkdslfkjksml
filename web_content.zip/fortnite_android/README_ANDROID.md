# Fortnite C++ – Android Studio Projekt
1. Android Studio oeffnen -> Open -> diesen Ordner waehlen (Internet noetig).
2. SDK Manager: "NDK (Side by side)" und "CMake" installieren.
3. Warten bis Gradle Sync fertig ist.
4. Build > Build Bundle(s) / APK(s) > Build APK(s). Die APK liegt dann in app/build/outputs/apk/debug/
5. APK aufs Handy kopieren und installieren (unbekannte Quellen erlauben).

Steuerung: linker Daumen = Joystick, rechter Daumen irgendwo = Zielen + Schiessen,
BAUEN = Wand (10 Holz), ITEM = Spitzhacke/Gewehr. Antippen = Spiel starten.
