#pragma once
#include "raylib.h"
#include <vector>
#include "bullet.h"
class World;
class Fighter {
public:
    static constexpr float RADIUS = 16.f;
    int id = 0;
    Vector2 pos{};
    float angle = 0, hp = 100, shield = 0, cooldown = 0;
    int wood = 50, ammo = 90, kills = 0;
    bool alive = true;
    Color color = BLUE;
    virtual ~Fighter() = default;
    void tick(float dt) { if (cooldown > 0) cooldown -= dt; }
    void move(Vector2 dir, float dt, const World& w);
    bool shoot(std::vector<Bullet>& b, float spread = 0.f);
    void takeDamage(float d);
    void draw() const;
};
