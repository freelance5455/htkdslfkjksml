#pragma once
#include "raylib.h"
class Storm {
public:
    Vector2 center{};
    float radius = 0, startR = 0, targetR = 0, timer = 0;
    Vector2 startC{}, targetC{};
    int phase = 0;
    bool shrinking = false;
    void reset();
    void update(float dt);
    bool outside(Vector2 p) const;
    float dps() const;
    void draw() const;
};
