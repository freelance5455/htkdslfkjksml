#include "storm.h"
#include "config.h"
#include "raymath.h"
#include <cmath>
void Storm::reset() {
    center = {cfg::WORLD / 2, cfg::WORLD / 2};
    radius = cfg::WORLD * 0.75f;
    phase = 0; shrinking = false; timer = 30.f;
}
void Storm::update(float dt) {
    timer -= dt;
    if (!shrinking) {
        if (timer <= 0) {
            shrinking = true; timer = 25.f;
            startR = radius; startC = center;
            targetR = fmaxf(radius * 0.6f, 60.f);
            float a = (float)GetRandomValue(0, 628) / 100.f;
            float off = (radius - targetR) * (GetRandomValue(0, 100) / 100.f);
            targetC = {center.x + cosf(a) * off, center.y + sinf(a) * off};
        }
    } else {
        float t = 1.f - fmaxf(timer, 0.f) / 25.f;
        radius = Lerp(startR, targetR, t);
        center = Vector2Lerp(startC, targetC, t);
        if (timer <= 0) { shrinking = false; timer = 20.f; phase++; }
    }
}
bool Storm::outside(Vector2 p) const { return Vector2Distance(p, center) > radius; }
float Storm::dps() const { return 2.f + phase * 2.f; }
void Storm::draw() const {
    DrawRing(center, radius, radius + 8000.f, 0, 360, 128, Fade(PURPLE, 0.35f));
    DrawCircleLines((int)center.x, (int)center.y, radius, VIOLET);
}
