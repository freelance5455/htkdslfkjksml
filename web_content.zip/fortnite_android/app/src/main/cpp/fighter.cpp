#include "fighter.h"
#include "world.h"
#include "config.h"
#include "raymath.h"
#include <cmath>
#include <algorithm>
void Fighter::move(Vector2 dir, float dt, const World& w) {
    pos = Vector2Add(pos, Vector2Scale(dir, cfg::SPEED * dt));
    pos = w.resolve(pos, RADIUS);
    pos.x = Clamp(pos.x, RADIUS, cfg::WORLD - RADIUS);
    pos.y = Clamp(pos.y, RADIUS, cfg::WORLD - RADIUS);
}
bool Fighter::shoot(std::vector<Bullet>& b, float spread) {
    if (cooldown > 0 || ammo <= 0) return false;
    cooldown = cfg::FIRE_RATE; ammo--;
    float a = angle + ((GetRandomValue(-100, 100) / 100.f) * spread);
    Vector2 dir{cosf(a), sinf(a)};
    Bullet bl;
    bl.pos = Vector2Add(pos, Vector2Scale(dir, RADIUS + 6));
    bl.vel = Vector2Scale(dir, cfg::BULLET_SPEED);
    bl.owner = id;
    b.push_back(bl);
    return true;
}
void Fighter::takeDamage(float d) {
    float s = std::min(shield, d);
    shield -= s; d -= s;
    hp -= d;
    if (hp <= 0) { hp = 0; alive = false; }
}
void Fighter::draw() const {
    if (!alive) return;
    Vector2 tip{pos.x + cosf(angle) * (RADIUS + 14), pos.y + sinf(angle) * (RADIUS + 14)};
    DrawLineEx(pos, tip, 6, DARKGRAY);
    DrawCircleV(pos, RADIUS, color);
    DrawCircleLines((int)pos.x, (int)pos.y, RADIUS, BLACK);
}
