#pragma once
#include "raylib.h"
struct Bullet {
    Vector2 pos{}, vel{};
    int owner = -1;
    float life = 1.2f, dmg = 18.f;
    bool dead = false;
    void update(float dt);
    void draw() const;
};
