#include "raylib.h"
#include "config.h"
#include "game.h"
#include <cstring>
int main(int argc, char** argv) {
    InitWindow(cfg::SCREEN_W, cfg::SCREEN_H, "Fortnite C++");
    SetTargetFPS(60);
    Game game;
    if (argc > 1 && std::strcmp(argv[1], "--start") == 0) game.start();
    while (!WindowShouldClose()) {
        game.update(GetFrameTime());
        game.draw();
    }
    CloseWindow();
    return 0;
}
