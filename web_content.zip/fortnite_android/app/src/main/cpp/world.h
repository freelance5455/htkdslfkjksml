#pragma once
#include "raylib.h"
#include <vector>
#include <unordered_map>
struct Tree { Vector2 pos; float hp = 3; };
enum class PickupType { Health, Shield, Ammo };
struct Pickup { Vector2 pos; PickupType type; bool taken = false; };

class World {
public:
    std::vector<Tree> trees;
    std::vector<Pickup> pickups;
    std::unordered_map<long long, float> walls;

    void generate();
    static long long key(int cx, int cy);
    bool hasWall(int cx, int cy) const;
    bool addWall(int cx, int cy);
    void damageWall(int cx, int cy, float d);
    Vector2 resolve(Vector2 p, float r) const;
    Tree* treeInRange(Vector2 p, float range);
    void draw(Rectangle view) const;
};
