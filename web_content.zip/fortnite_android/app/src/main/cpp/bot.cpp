#include "bot.h"
#include "world.h"
#include "config.h"
#include "raymath.h"
#include <cmath>
Bot::Bot(int id_, Vector2 p) {
    id = id_; pos = p; wander = p;
    color = ColorFromHSV((float)GetRandomValue(0, 360), 0.6f, 0.9f);
}
void Bot::update(float dt, World& w, std::vector<Bullet>& b, const std::vector<Fighter*>& all, const Storm& s) {
    tick(dt);
    retarget -= dt; strafeTimer -= dt;
    if (strafeTimer <= 0) { strafe = GetRandomValue(0, 1) ? 1.f : -1.f; strafeTimer = 0.5f + GetRandomValue(0, 100) / 100.f; }

    Fighter* tgt = nullptr; float best = 650;
    for (auto f : all) {
        if (f == this || !f->alive) continue;
        float d = Vector2Distance(pos, f->pos);
        if (d < best) { best = d; tgt = f; }
    }
    Vector2 dir{0, 0};
    if (Vector2Distance(pos, s.center) > s.radius - 120) {
        dir = Vector2Normalize(Vector2Subtract(s.center, pos));
        angle = atan2f(dir.y, dir.x);
    } else if (tgt) {
        Vector2 to = Vector2Subtract(tgt->pos, pos);
        angle = atan2f(to.y, to.x);
        Vector2 n = Vector2Normalize(to);
        if (best > 280) dir = n;
        else dir = {-n.y * strafe, n.x * strafe};
        shoot(b, 0.18f);
    } else {
        if (retarget <= 0 || Vector2Distance(pos, wander) < 40) {
            wander = {Clamp(pos.x + GetRandomValue(-700, 700), 100.f, cfg::WORLD - 100),
                      Clamp(pos.y + GetRandomValue(-700, 700), 100.f, cfg::WORLD - 100)};
            retarget = 4.f;
        }
        dir = Vector2Normalize(Vector2Subtract(wander, pos));
        angle = atan2f(dir.y, dir.x);
    }
    move(Vector2Scale(dir, 0.75f), dt, w);
}
