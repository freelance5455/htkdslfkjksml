#include "touch.h"
#include "raymath.h"
#include <cmath>
static const float BTN_R = 70.f, JOY_R = 120.f;
static Vector2 joyBase() { return {170.f, GetScreenHeight() - 170.f}; }
static Vector2 buildBtn() { return {GetScreenWidth() - 110.f, GetScreenHeight() - 110.f}; }
static Vector2 swapBtn() { return {GetScreenWidth() - 110.f, GetScreenHeight() - 270.f}; }

TouchInput readTouch() {
    static bool prevBuild = false, prevSwap = false;
    TouchInput t;
    bool b = false, s = false;
    float w = (float)GetScreenWidth(), h = (float)GetScreenHeight();
    int n = GetTouchPointCount();
    for (int i = 0; i < n; i++) {
        Vector2 p = GetTouchPosition(i);
        if (Vector2Distance(p, buildBtn()) < BTN_R) { b = true; continue; }
        if (Vector2Distance(p, swapBtn()) < BTN_R) { s = true; continue; }
        if (p.x < w * 0.4f) {
            Vector2 d = Vector2Subtract(p, joyBase());
            float len = Vector2Length(d);
            if (len > 15.f) t.move = Vector2Scale(d, 1.f / fmaxf(len, JOY_R));
        } else {
            t.hasAim = true; t.fire = true;
            t.aimAngle = atan2f(p.y - h / 2, p.x - w / 2);
        }
    }
    t.build = b && !prevBuild;
    t.switchItem = s && !prevSwap;
    prevBuild = b; prevSwap = s;
    return t;
}

void drawTouchControls() {
    Vector2 jb = joyBase();
    DrawCircleV(jb, JOY_R, Fade(WHITE, 0.15f));
    DrawCircleLines((int)jb.x, (int)jb.y, JOY_R, Fade(WHITE, 0.5f));
    Vector2 bb = buildBtn(), sb = swapBtn();
    DrawCircleV(bb, BTN_R, Fade(ORANGE, 0.45f));
    DrawText("BAUEN", (int)bb.x - 38, (int)bb.y - 10, 22, WHITE);
    DrawCircleV(sb, BTN_R, Fade(SKYBLUE, 0.45f));
    DrawText("ITEM", (int)sb.x - 26, (int)sb.y - 10, 22, WHITE);
}
