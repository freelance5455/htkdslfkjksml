#pragma once
#include "raylib.h"
struct TouchInput {
    Vector2 move{0, 0};
    bool hasAim = false;
    float aimAngle = 0;
    bool fire = false, build = false, switchItem = false;
};
TouchInput readTouch();
void drawTouchControls();
