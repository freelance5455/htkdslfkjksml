#pragma once
#include "fighter.h"
#include "storm.h"
class Bot : public Fighter {
public:
    Bot(int id_, Vector2 p);
    void update(float dt, World& w, std::vector<Bullet>& b, const std::vector<Fighter*>& all, const Storm& s);
private:
    Vector2 wander{};
    float retarget = 0, strafe = 1, strafeTimer = 0;
};
