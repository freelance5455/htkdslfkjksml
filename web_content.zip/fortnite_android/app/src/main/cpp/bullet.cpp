#include "bullet.h"
#include "raymath.h"
void Bullet::update(float dt) {
    pos = Vector2Add(pos, Vector2Scale(vel, dt));
    life -= dt;
    if (life <= 0) dead = true;
}
void Bullet::draw() const {
    Vector2 tail = Vector2Subtract(pos, Vector2Scale(Vector2Normalize(vel), 14));
    DrawLineEx(tail, pos, 3, YELLOW);
}
