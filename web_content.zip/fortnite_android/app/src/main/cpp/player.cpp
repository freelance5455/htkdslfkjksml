#include "player.h"
#include "world.h"
#include "config.h"
#include "touch.h"
#include "raymath.h"
#include <cmath>
void Player::init(int id_, Vector2 p) {
    *static_cast<Fighter*>(this) = Fighter();
    id = id_; pos = p; color = SKYBLUE; slot = 1;
}
void Player::update(float dt, World& w, std::vector<Bullet>& b, const Camera2D& cam) {
    tick(dt);
    Vector2 d{0, 0};
    bool fire = false, build = false;

#ifdef PLATFORM_ANDROID
    TouchInput t = readTouch();
    d = t.move;
    if (t.hasAim) angle = t.aimAngle;
    if (t.switchItem) slot = 1 - slot;
    fire = t.fire; build = t.build;
#else
    if (IsKeyDown(KEY_W)) d.y -= 1;
    if (IsKeyDown(KEY_S)) d.y += 1;
    if (IsKeyDown(KEY_A)) d.x -= 1;
    if (IsKeyDown(KEY_D)) d.x += 1;
    if (Vector2Length(d) > 0) d = Vector2Normalize(d);
    Vector2 m = GetScreenToWorld2D(GetMousePosition(), cam);
    angle = atan2f(m.y - pos.y, m.x - pos.x);
    if (IsKeyPressed(KEY_ONE)) slot = 0;
    if (IsKeyPressed(KEY_TWO)) slot = 1;
    fire = IsMouseButtonDown(MOUSE_BUTTON_LEFT);
    build = IsKeyPressed(KEY_Q) || IsMouseButtonPressed(MOUSE_BUTTON_RIGHT);
#endif
    (void)cam;
    move(d, dt, w);

    if (fire) {
        if (slot == 1) shoot(b, 0.03f);
        else if (cooldown <= 0) {
            cooldown = 0.4f;
            Vector2 reach{pos.x + cosf(angle) * 40, pos.y + sinf(angle) * 40};
            if (Tree* t2 = w.treeInRange(reach, 45)) {
                wood += 10; t2->hp -= 1;
                if (t2->hp <= 0) w.trees.erase(w.trees.begin() + (t2 - &w.trees[0]));
            }
        }
    }
    if (build && wood >= 10) {
        float dist = RADIUS + cfg::GRID * 0.6f;
        int cx = (int)floorf((pos.x + cosf(angle) * dist) / cfg::GRID);
        int cy = (int)floorf((pos.y + sinf(angle) * dist) / cfg::GRID);
        if (w.addWall(cx, cy)) wood -= 10;
    }
}
