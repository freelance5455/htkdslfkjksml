#include "game.h"
#include "config.h"
#include "raymath.h"
#include "touch.h"
#include <cmath>

Game::Game() { cam.zoom = 1.f; }
static Vector2 randPos() {
    return {(float)GetRandomValue(300, (int)cfg::WORLD - 300), (float)GetRandomValue(300, (int)cfg::WORLD - 300)};
}
void Game::reset() {
    world.generate(); storm.reset(); bullets.clear();
    player.init(0, randPos());
    bots.clear(); bots.reserve(cfg::BOT_COUNT);
    for (int i = 0; i < cfg::BOT_COUNT; i++) bots.emplace_back(i + 1, randPos());
    all.clear(); all.push_back(&player);
    for (auto& b : bots) all.push_back(&b);
    won = false; state = State::Playing;
}
Fighter* Game::byId(int id) {
    for (auto f : all) if (f->id == id) return f;
    return nullptr;
}
void Game::updatePickups() {
    for (auto& pk : world.pickups) {
        if (pk.taken) continue;
        for (auto f : all) {
            if (!f->alive || Vector2Distance(f->pos, pk.pos) > 26) continue;
            if (pk.type == PickupType::Health) f->hp = fminf(100, f->hp + 35);
            else if (pk.type == PickupType::Shield) f->shield = fminf(100, f->shield + 50);
            else f->ammo += 40;
            pk.taken = true; break;
        }
    }
}
void Game::updateBullets(float dt) {
    for (auto& bl : bullets) {
        bl.update(dt);
        if (bl.dead) continue;
        int cx = (int)floorf(bl.pos.x / cfg::GRID), cy = (int)floorf(bl.pos.y / cfg::GRID);
        if (world.hasWall(cx, cy)) { world.damageWall(cx, cy, bl.dmg * 2); bl.dead = true; continue; }
        for (auto f : all) {
            if (!f->alive || f->id == bl.owner) continue;
            if (Vector2Distance(f->pos, bl.pos) < Fighter::RADIUS + 3) {
                f->takeDamage(bl.dmg);
                if (!f->alive) if (Fighter* k = byId(bl.owner)) k->kills++;
                bl.dead = true; break;
            }
        }
    }
    for (size_t i = 0; i < bullets.size();) {
        if (bullets[i].dead) { bullets[i] = bullets.back(); bullets.pop_back(); } else i++;
    }
}
void Game::update(float dt) {
    cam.offset = {GetScreenWidth() / 2.f, GetScreenHeight() / 2.f};
    cam.zoom = GetScreenHeight() / 720.f;
    if (state == State::Menu) { if (IsKeyPressed(KEY_ENTER) || IsMouseButtonPressed(MOUSE_BUTTON_LEFT)) reset(); return; }
    if (state == State::Over) { if (IsKeyPressed(KEY_ENTER) || IsMouseButtonPressed(MOUSE_BUTTON_LEFT)) state = State::Menu; return; }

    storm.update(dt);
    if (player.alive) player.update(dt, world, bullets, cam);
    for (auto& b : bots) if (b.alive) b.update(dt, world, bullets, all, storm);
    updateBullets(dt);
    updatePickups();
    for (auto f : all) if (f->alive && storm.outside(f->pos)) f->takeDamage(storm.dps() * dt);

    aliveCount = 0;
    for (auto f : all) if (f->alive) aliveCount++;
    if (!player.alive) { won = false; state = State::Over; }
    else if (aliveCount == 1) { won = true; state = State::Over; }
    cam.target = player.pos;
}
void Game::drawHud() const {
    int hx = GetScreenWidth() / 2 - 130;
    DrawRectangle(hx, GetScreenHeight() - 60, 260, 18, Fade(BLACK, 0.5f));
    DrawRectangle(hx, GetScreenHeight() - 60, (int)(2.6f * player.hp), 18, GREEN);
    DrawRectangle(hx, GetScreenHeight() - 84, 260, 18, Fade(BLACK, 0.5f));
    DrawRectangle(hx, GetScreenHeight() - 84, (int)(2.6f * player.shield), 18, SKYBLUE);
    DrawText(TextFormat("Wood: %d   Ammo: %d   [%s]", player.wood, player.ammo, player.slot ? "Rifle" : "Pickaxe"),
             hx, GetScreenHeight() - 36, 20, WHITE);
    DrawText(TextFormat("Alive: %d   Kills: %d", aliveCount, player.kills), 20, 20, 24, WHITE);
    DrawText(TextFormat("Storm %s: %ds  (%.0f dmg/s)", storm.shrinking ? "closing" : "next", (int)fmaxf(storm.timer, 0), storm.dps()),
             20, 50, 20, VIOLET);
    // minimap
    int mm = 150, mx = GetScreenWidth() - mm - 20, my = 20;
    float k = mm / cfg::WORLD;
    DrawRectangle(mx, my, mm, mm, Fade(BLACK, 0.5f));
    DrawCircleLines((int)(mx + storm.center.x * k), (int)(my + storm.center.y * k), storm.radius * k, VIOLET);
    for (auto f : all) if (f->alive) DrawCircle((int)(mx + f->pos.x * k), (int)(my + f->pos.y * k), f == &player ? 3.f : 1.5f, f == &player ? SKYBLUE : RED);
}
void Game::draw() {
    BeginDrawing();
    ClearBackground({70, 140, 70, 255});
    if (state == State::Menu) {
        DrawText("FORTNITE C++", GetScreenWidth() / 2 - 220, 200, 70, WHITE);
        DrawText("ENTER / Tippen = Start", GetScreenWidth() / 2 - 100, 320, 30, YELLOW);
        DrawText("WASD move | Mouse aim | LMB shoot/harvest | 1/2 items | Q or RMB build", GetScreenWidth() / 2 - 330, 400, 20, LIGHTGRAY);
        EndDrawing(); return;
    }
    BeginMode2D(cam);
    float vw = GetScreenWidth() / cam.zoom, vh = GetScreenHeight() / cam.zoom;
    Rectangle view{cam.target.x - vw / 2.f, cam.target.y - vh / 2.f, vw, vh};
    world.draw(view);
    for (auto f : all) f->draw();
    for (const auto& b : bullets) b.draw();
    storm.draw();
    EndMode2D();
    drawHud();
#ifdef PLATFORM_ANDROID
    if (state == State::Playing) drawTouchControls();
#endif
    if (state == State::Over) {
        DrawRectangle(0, 0, GetScreenWidth(), GetScreenHeight(), Fade(BLACK, 0.55f));
        DrawText(won ? "VICTORY ROYALE!" : "ELIMINATED", GetScreenWidth() / 2 - 230, 260, 60, won ? GOLD : RED);
        DrawText("ENTER / Tippen = Menu", GetScreenWidth() / 2 - 90, 350, 28, WHITE);
    }
    EndDrawing();
}
