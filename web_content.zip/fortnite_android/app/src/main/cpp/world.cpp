#include "world.h"
#include "config.h"
#include "raymath.h"
#include <cmath>

long long World::key(int cx, int cy) { return (long long)(cx + 10000) * 100000LL + (cy + 10000); }
bool World::hasWall(int cx, int cy) const { return walls.count(key(cx, cy)) > 0; }
bool World::addWall(int cx, int cy) {
    if (hasWall(cx, cy)) return false;
    walls[key(cx, cy)] = 100.f;
    return true;
}
void World::damageWall(int cx, int cy, float d) {
    auto it = walls.find(key(cx, cy));
    if (it == walls.end()) return;
    it->second -= d;
    if (it->second <= 0) walls.erase(it);
}

void World::generate() {
    trees.clear(); pickups.clear(); walls.clear();
    for (int i = 0; i < cfg::TREES; i++)
        trees.push_back({{(float)GetRandomValue(100, (int)cfg::WORLD - 100), (float)GetRandomValue(100, (int)cfg::WORLD - 100)}, 3});
    for (int i = 0; i < cfg::PICKUPS; i++)
        pickups.push_back({{(float)GetRandomValue(100, (int)cfg::WORLD - 100), (float)GetRandomValue(100, (int)cfg::WORLD - 100)},
                           (PickupType)GetRandomValue(0, 2), false});
    // a few small houses
    for (int h = 0; h < 14; h++) {
        int bx = GetRandomValue(5, (int)(cfg::WORLD / cfg::GRID) - 10);
        int by = GetRandomValue(5, (int)(cfg::WORLD / cfg::GRID) - 10);
        for (int x = 0; x < 5; x++) for (int y = 0; y < 4; y++) {
            bool edge = x == 0 || x == 4 || y == 0 || y == 3;
            bool door = (x == 2 && y == 3);
            if (edge && !door) addWall(bx + x, by + y);
        }
        pickups.push_back({{(bx + 2.5f) * cfg::GRID, (by + 2.f) * cfg::GRID}, PickupType::Shield, false});
    }
}

Vector2 World::resolve(Vector2 p, float r) const {
    for (const auto& kv : walls) {
        int cx = (int)(kv.first / 100000LL) - 10000;
        int cy = (int)(kv.first % 100000LL) - 10000;
        float rx = (float)cx * cfg::GRID, ry = (float)cy * cfg::GRID;
        if (std::fabs(p.x - rx - cfg::GRID / 2) > cfg::GRID + r) continue;
        if (std::fabs(p.y - ry - cfg::GRID / 2) > cfg::GRID + r) continue;
        Vector2 c{Clamp(p.x, rx, rx + cfg::GRID), Clamp(p.y, ry, ry + cfg::GRID)};
        Vector2 d = Vector2Subtract(p, c);
        float len = Vector2Length(d);
        if (len < r) {
            if (len < 0.001f) { p.y -= r; continue; }
            p = Vector2Add(c, Vector2Scale(d, r / len));
        }
    }
    for (const auto& t : trees) {
        Vector2 d = Vector2Subtract(p, t.pos);
        float len = Vector2Length(d), min = r + 10;
        if (len < min && len > 0.001f) p = Vector2Add(t.pos, Vector2Scale(d, min / len));
    }
    return p;
}

Tree* World::treeInRange(Vector2 p, float range) {
    Tree* best = nullptr; float bd = range;
    for (auto& t : trees) {
        float d = Vector2Distance(p, t.pos);
        if (d < bd) { bd = d; best = &t; }
    }
    return best;
}

void World::draw(Rectangle v) const {
    DrawRectangleLines(0, 0, (int)cfg::WORLD, (int)cfg::WORLD, RED);
    int g = 256;
    for (int x = (int)(v.x / g) * g; x < v.x + v.width; x += g) DrawLine(x, (int)v.y, x, (int)(v.y + v.height), Fade(DARKGREEN, 0.4f));
    for (int y = (int)(v.y / g) * g; y < v.y + v.height; y += g) DrawLine((int)v.x, y, (int)(v.x + v.width), y, Fade(DARKGREEN, 0.4f));
    for (const auto& pk : pickups) {
        if (pk.taken || !CheckCollisionPointRec(pk.pos, v)) continue;
        Color c = pk.type == PickupType::Health ? RED : pk.type == PickupType::Shield ? SKYBLUE : ORANGE;
        DrawRectangle((int)pk.pos.x - 8, (int)pk.pos.y - 8, 16, 16, c);
        DrawRectangleLines((int)pk.pos.x - 8, (int)pk.pos.y - 8, 16, 16, WHITE);
    }
    for (const auto& kv : walls) {
        int cx = (int)(kv.first / 100000LL) - 10000, cy = (int)(kv.first % 100000LL) - 10000;
        Rectangle r{(float)cx * cfg::GRID, (float)cy * cfg::GRID, (float)cfg::GRID, (float)cfg::GRID};
        if (!CheckCollisionRecs(r, v)) continue;
        float f = kv.second / 100.f;
        DrawRectangleRec(r, ColorFromHSV(30, 0.6f, 0.35f + 0.4f * f));
        DrawRectangleLinesEx(r, 2, BROWN);
    }
    for (const auto& t : trees) {
        if (!CheckCollisionPointRec(t.pos, v)) continue;
        DrawCircleV(t.pos, 10, BROWN);
        DrawCircleV(t.pos, 30, Fade(DARKGREEN, 0.8f));
    }
}
