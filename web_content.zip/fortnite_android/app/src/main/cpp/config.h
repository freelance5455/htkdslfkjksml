#pragma once
namespace cfg {
constexpr int SCREEN_W = 1280, SCREEN_H = 720;
constexpr float WORLD = 4000.f;
constexpr int GRID = 64;
constexpr int BOT_COUNT = 24;
constexpr float SPEED = 230.f;
constexpr float BULLET_SPEED = 900.f;
constexpr float FIRE_RATE = 0.18f;
constexpr int TREES = 260;
constexpr int PICKUPS = 140;
}
