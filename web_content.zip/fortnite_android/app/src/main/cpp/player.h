#pragma once
#include "fighter.h"
class Player : public Fighter {
public:
    int slot = 1; // 0 pickaxe, 1 rifle
    void init(int id_, Vector2 p);
    void update(float dt, World& w, std::vector<Bullet>& b, const Camera2D& cam);
};
