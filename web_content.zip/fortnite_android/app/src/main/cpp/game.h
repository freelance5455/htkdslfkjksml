#pragma once
#include "player.h"
#include "bot.h"
#include "world.h"
#include "storm.h"
#include "bullet.h"
#include <vector>
class Game {
public:
    Game();
    void update(float dt);
    void draw();
    void start() { reset(); }
private:
    enum class State { Menu, Playing, Over } state = State::Menu;
    World world;
    Storm storm;
    Player player;
    std::vector<Bot> bots;
    std::vector<Fighter*> all;
    std::vector<Bullet> bullets;
    Camera2D cam{};
    bool won = false;
    int aliveCount = 0;
    void reset();
    void updateBullets(float dt);
    void updatePickups();
    Fighter* byId(int id);
    void drawHud() const;
};
