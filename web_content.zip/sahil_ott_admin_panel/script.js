const ADMIN_PIN = "1234";

const pinScreen = document.getElementById("pinScreen");
const adminApp = document.getElementById("adminApp");
const pinInput = document.getElementById("pinInput");
const unlockBtn = document.getElementById("unlockBtn");
const pinError = document.getElementById("pinError");

const movieForm = document.getElementById("movieForm");
const formHeading = document.getElementById("formHeading");
const editIdInput = document.getElementById("editId");
const titleInput = document.getElementById("title");
const categoryInput = document.getElementById("category");
const yearInput = document.getElementById("year");
const ratingInput = document.getElementById("rating");
const posterUrlInput = document.getElementById("posterUrl");
const posterPreviewWrap = document.getElementById("posterPreviewWrap");
const posterPreview = document.getElementById("posterPreview");
const videoUrlInput = document.getElementById("videoUrl");
const descriptionInput = document.getElementById("description");
const saveBtn = document.getElementById("saveBtn");
const cancelEditBtn = document.getElementById("cancelEditBtn");
const formStatus = document.getElementById("formStatus");
const movieList = document.getElementById("movieList");
const totalCount = document.getElementById("totalCount");

function unlock() {
  if (pinInput.value.trim() === ADMIN_PIN) {
    pinScreen.classList.add("hidden");
    adminApp.classList.remove("hidden");
    loadMovies();
  } else {
    pinError.textContent = "Galat PIN! Default PIN 1234 hai.";
  }
}

unlockBtn.addEventListener("click", unlock);
pinInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter") unlock();
});

posterUrlInput.addEventListener("input", () => {
  const url = posterUrlInput.value.trim();
  if (url) {
    posterPreview.src = url;
    posterPreviewWrap.classList.remove("hidden");
  } else {
    posterPreviewWrap.classList.add("hidden");
  }
});

function resetForm() {
  movieForm.reset();
  editIdInput.value = "";
  yearInput.value = "2026";
  ratingInput.value = "8.5";
  posterPreviewWrap.classList.add("hidden");
  formHeading.textContent = "Add New Movie";
  saveBtn.textContent = "ADD MOVIE";
  cancelEditBtn.classList.add("hidden");
}

cancelEditBtn.addEventListener("click", resetForm);

movieForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  saveBtn.disabled = true;
  formStatus.style.color = "#8b95b3";
  formStatus.textContent = "Saving to Firebase...";

  const data = {
    title: titleInput.value.trim(),
    category: categoryInput.value,
    year: yearInput.value.trim() || "2026",
    rating: ratingInput.value.trim() || "8.0",
    posterUrl: posterUrlInput.value.trim(),
    videoUrl: videoUrlInput.value.trim(),
    description: descriptionInput.value.trim(),
    updatedAt: firebase.firestore.FieldValue.serverTimestamp()
  };

  try {
    const editId = editIdInput.value;
    if (editId) {
      await db.collection("movies").doc(editId).update(data);
      formStatus.style.color = "#22c55e";
      formStatus.textContent = "✅ Movie updated live!";
    } else {
      data.createdAt = firebase.firestore.FieldValue.serverTimestamp();
      await db.collection("movies").add(data);
      formStatus.style.color = "#22c55e";
      formStatus.textContent = "✅ Movie added live!";
    }
    resetForm();
  } catch (err) {
    console.error(err);
    formStatus.style.color = "#ff3b5c";
    formStatus.textContent = "Error: " + err.message;
  } finally {
    saveBtn.disabled = false;
  }
});

function loadMovies() {
  db.collection("movies")
    .orderBy("createdAt", "desc")
    .onSnapshot(
      (snapshot) => {
        totalCount.textContent = snapshot.size;
        if (snapshot.empty) {
          movieList.innerHTML = "<p style='color:#8b95b3;font-size:0.88rem;'>Abhi koi movie nahi hai. Upar form se add karo!</p>";
          return;
        }
        movieList.innerHTML = "";
        snapshot.forEach((doc) => {
          const m = doc.data();
          const item = document.createElement("div");
          item.className = "movie-item";
          item.innerHTML = `
            <img src="${m.posterUrl || ""}" alt="" />
            <div class="movie-meta">
              <h3>${m.title || "Untitled"}</h3>
              <p>${m.category || "Movie"} • ${m.year || "2026"} • ★ ${m.rating || "8.0"}</p>
            </div>
            <div class="item-actions">
              <button class="mini-btn edit">Edit</button>
              <button class="mini-btn del">Delete</button>
            </div>
          `;

          item.querySelector(".edit").addEventListener("click", () => {
            editIdInput.value = doc.id;
            titleInput.value = m.title || "";
            categoryInput.value = m.category || "Action";
            yearInput.value = m.year || "2026";
            ratingInput.value = m.rating || "8.5";
            posterUrlInput.value = m.posterUrl || "";
            videoUrlInput.value = m.videoUrl || "";
            descriptionInput.value = m.description || "";
            if (m.posterUrl) {
              posterPreview.src = m.posterUrl;
              posterPreviewWrap.classList.remove("hidden");
            }
            formHeading.textContent = "Edit Movie";
            saveBtn.textContent = "UPDATE MOVIE";
            cancelEditBtn.classList.remove("hidden");
            window.scrollTo({ top: 0, behavior: "smooth" });
          });

          item.querySelector(".del").addEventListener("click", async () => {
            if (confirm(`"${m.title}" ko delete karna hai?`)) {
              await db.collection("movies").doc(doc.id).delete();
            }
          });

          movieList.appendChild(item);
        });
      },
      (err) => {
        movieList.innerHTML = `<p style='color:#ff3b5c;font-size:0.86rem;'>Firestore Error: ${err.message}</p>`;
      }
    );
}
