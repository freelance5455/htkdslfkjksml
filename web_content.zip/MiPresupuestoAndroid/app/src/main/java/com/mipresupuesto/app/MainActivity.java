package com.mipresupuesto.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Handler;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.Window;
import android.widget.Toast;

public class MainActivity extends Activity {
    private WebView webView;
    private boolean exitPromptShown = false;
    private long lastBackPress = 0;
    private final Handler handler = new Handler();

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);

        webView = new WebView(this);
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);

        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new ExitBridge(), "AndroidExit");
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void confirmExit() {
        if (isFinishing() || exitPromptShown) return;

        exitPromptShown = true;
        new AlertDialog.Builder(this)
                .setTitle("Salir de Mi Presupuesto")
                .setMessage("¿Está seguro que desea salir de la aplicación?\n\nPuede elegir Aceptar para salir o Cancelar para continuar usando la aplicación.")
                .setNegativeButton("Cancelar", (dialog, which) -> {
                    exitPromptShown = false;
                    dialog.dismiss();
                })
                .setPositiveButton("Aceptar", (dialog, which) -> {
                    exitPromptShown = false;
                    saveBeforeExitAndFinish();
                })
                .setOnCancelListener(dialog -> exitPromptShown = false)
                .show();
    }

    private void saveBeforeExitAndFinish() {
        try {
            webView.evaluateJavascript(
                    "try{if(typeof saveData==='function'){saveData();}}catch(e){}",
                    value -> {
                        webView.postDelayed(() -> {
                            finish();
                        }, 100);
                    }
            );
        } catch (Exception e) {
            finish();
        }
    }

    @Override public void onBackPressed() {
        // Si el usuario está dentro de una navegación interna del WebView,
        // primero vuelve a la pantalla anterior. Si está en la pantalla principal,
        // se solicita confirmación para salir.
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
            return;
        }

        long now = System.currentTimeMillis();
        if (now - lastBackPress < 2000) {
            // Segunda pulsación de Atrás dentro de 2 segundos: salir directamente.
            saveBeforeExitAndFinish();
            return;
        }

        lastBackPress = now;
        Toast.makeText(this, "Presiona Atrás nuevamente para salir o espera y usa Aceptar.", Toast.LENGTH_LONG).show();
        confirmExit();
    }

    private class ExitBridge {
        @JavascriptInterface
        public void requestExit() {
            runOnUiThread(() -> confirmExit());
        }
    }
}
