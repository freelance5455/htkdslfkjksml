# Mi Presupuesto - Android

Proyecto Android que empaqueta la demo HTML actual en una aplicación Android mediante WebView.

## Compilación

Abrir la carpeta en Android Studio o un IDE Android compatible y ejecutar:

`./gradlew assembleDebug`

El APK se genera en:

`app/build/outputs/apk/debug/app-debug.apk`

El proyecto requiere Android SDK con API 35 y Gradle/Android Gradle Plugin 8.6.1.


Versión 0.4: movimientos de ingresos y gastos modificables y eliminables individualmente, con actualización de saldos y categorías.


## Versión 5
- Confirmación antes de salir de la aplicación mediante el botón Atrás del celular.
- Se puede cancelar la salida o aceptar para cerrar.
- Una segunda pulsación de Atrás dentro de 2 segundos permite salir directamente.
- Se agregó el botón "Salir de la aplicación" en la sección Usuario.
- Se guardan los datos antes de cerrar la aplicación.
