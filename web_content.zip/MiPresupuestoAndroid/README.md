# Mi Presupuesto - Android

Proyecto Android que empaqueta la demo HTML actual en una aplicación Android mediante WebView.

## Compilación

Abrir la carpeta en Android Studio o un IDE Android compatible y ejecutar:

`./gradlew assembleDebug`

El APK se genera en:

`app/build/outputs/apk/debug/app-debug.apk`

El proyecto requiere Android SDK con API 35 y Gradle/Android Gradle Plugin 8.6.1.
