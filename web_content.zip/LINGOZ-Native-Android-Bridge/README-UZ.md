# LINGOZ — Native Android API Bridge

Bu loyiha avvalgi LINGOZ HTML ilovasini Android Studio orqali APK qilish uchun tayyorlangan. `Convert HTML to APK` dasturidagi `file://` WebView CORS muammosini chetlab o‘tish uchun Speaking API so‘rovlari Android native HTTPS (`HttpURLConnection`) orqali yuboriladi. Brauzer xavfsizligini global o‘chirmaydi.

## Nima o‘zgardi
- Sayt `file://` o‘rniga AndroidX `WebViewAssetLoader` bilan `https://appassets.androidplatform.net/assets/index.html` da ochiladi.
- `fetch()` faqat `https://dbvirtualeducation.com/ielts/api/` ostidagi GET so‘rovlarini native bridge orqali bajaradi.
- Windows’da `BOSHLASH.bat` va localhost proxy ishlash mantig‘i asl web loyihada saqlangan; APK assets nusxasi esa native bridge mavjud bo‘lganda rasmiy API’ga ulanadi.
- Internet va audio yozish permissionlari manifestga kiritilgan.
- Boshqa domenlarga so‘rovlar native bridge orqali yuborilmaydi.

## APK yaratish
1. Android Studio o‘rnating (JDK/Android SDK bilan).
2. Android Studio → **Open** → shu papkani tanlang (`settings.gradle` turgan asosiy papka).
3. Gradle sync tugashini kuting.
4. **Build → Build APK(s)** ni tanlang.
5. APK odatda `app/build/outputs/apk/debug/app-debug.apk` ichida paydo bo‘ladi.
6. Telefonda internetni yoqing, APKni o‘rnating va Speaking → Refresh database ni bosing.

## Muhim cheklov
Bu yerda Android SDK/Gradle bilan APK build va real qurilmada API tekshiruvi bajarilmagan. Loyiha Android Studio’da build qilinishi kerak. Agar API host Android qurilmadan javob bermasa yoki autentifikatsiya talab qilsa, native bridge ham ma’lumot ola olmaydi; xato Speaking statusida ko‘rsatiladi.
