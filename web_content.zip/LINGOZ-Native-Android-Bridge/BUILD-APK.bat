@echo off
cd /d "%~dp0"
echo LINGOZ Android APK build
where gradle >nul 2>nul
if errorlevel 1 (
  echo Gradle command not found. Open this folder in Android Studio and choose Build ^> Build APK(s).
  pause
  exit /b 1
)
gradle assembleDebug
if errorlevel 1 pause
