sheeProfile — Offline-first portfolio app

CONTENTS
- index.html: complete app
- manifest.json: installable web-app metadata
- sw.js: offline cache service worker (requires localhost or HTTPS for browser installation)
- icon.svg: app icon

ANDROID SETUP
1. Extract the ZIP on your Android phone.
2. Open the extracted folder using a local web server / offline HTML app that serves the folder, or upload the folder to your own HTTPS hosting once to install it.
3. Open index.html in a supported browser. For the best app-like installation and offline caching, serve it from HTTPS and use the browser menu > Add to Home screen / Install app.
4. Keep a backup JSON file in a separate safe location.

IMPORTANT
This ZIP is the complete offline-first web app package, not a signed native APK. Browser-based local storage is device/browser-specific. Export backups regularly.
Automatic market prices are optional, require internet and depend on ticker/API availability and browser CORS support. Manual price entry is always available.
Starter FX rates are placeholders: USD 130, EUR 140, GBP 165 KES. Replace them with current rates before relying on converted totals.
PIN is a convenience lock only; it is not encryption.
