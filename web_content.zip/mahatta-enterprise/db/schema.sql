CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS users (
  id BIGSERIAL PRIMARY KEY,
  username VARCHAR(80) UNIQUE NOT NULL,
  full_name VARCHAR(160) NOT NULL,
  password_hash TEXT NOT NULL,
  role VARCHAR(20) NOT NULL CHECK (role IN ('manager','accountant','cashier')),
  active BOOLEAN NOT NULL DEFAULT TRUE,
  must_change_password BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS tanks (
  id BIGSERIAL PRIMARY KEY,
  name VARCHAR(120) NOT NULL UNIQUE,
  fuel_type VARCHAR(40) NOT NULL,
  capacity_liters NUMERIC(14,3) NOT NULL CHECK (capacity_liters > 0),
  current_liters NUMERIC(14,3) NOT NULL DEFAULT 0 CHECK (current_liters >= 0),
  low_level_liters NUMERIC(14,3) NOT NULL DEFAULT 0,
  active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK (current_liters <= capacity_liters)
);

CREATE TABLE IF NOT EXISTS pumps (
  id BIGSERIAL PRIMARY KEY,
  name VARCHAR(120) NOT NULL UNIQUE,
  fuel_type VARCHAR(40) NOT NULL,
  tank_id BIGINT NOT NULL REFERENCES tanks(id),
  meter_reading NUMERIC(16,3) NOT NULL DEFAULT 0 CHECK (meter_reading >= 0),
  active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS suppliers (
  id BIGSERIAL PRIMARY KEY,
  name VARCHAR(180) NOT NULL,
  phone VARCHAR(60),
  opening_balance NUMERIC(16,2) NOT NULL DEFAULT 0,
  active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS cash_accounts (
  id BIGSERIAL PRIMARY KEY,
  name VARCHAR(120) NOT NULL UNIQUE,
  account_type VARCHAR(30) NOT NULL CHECK (account_type IN ('cash','bank','wallet')),
  opening_balance NUMERIC(16,2) NOT NULL DEFAULT 0,
  current_balance NUMERIC(16,2) NOT NULL DEFAULT 0,
  active BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE IF NOT EXISTS accounts (
  id BIGSERIAL PRIMARY KEY,
  code VARCHAR(20) UNIQUE NOT NULL,
  name VARCHAR(160) NOT NULL,
  account_type VARCHAR(20) NOT NULL CHECK (account_type IN ('asset','liability','equity','revenue','expense')),
  parent_id BIGINT REFERENCES accounts(id),
  active BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE IF NOT EXISTS journal_entries (
  id BIGSERIAL PRIMARY KEY,
  entry_date DATE NOT NULL DEFAULT CURRENT_DATE,
  reference_type VARCHAR(40) NOT NULL,
  reference_id BIGINT,
  memo TEXT NOT NULL,
  created_by BIGINT REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  posted BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE IF NOT EXISTS journal_lines (
  id BIGSERIAL PRIMARY KEY,
  entry_id BIGINT NOT NULL REFERENCES journal_entries(id),
  account_id BIGINT NOT NULL REFERENCES accounts(id),
  debit NUMERIC(16,2) NOT NULL DEFAULT 0 CHECK (debit >= 0),
  credit NUMERIC(16,2) NOT NULL DEFAULT 0 CHECK (credit >= 0),
  memo TEXT,
  CHECK (NOT (debit > 0 AND credit > 0)),
  CHECK (debit > 0 OR credit > 0)
);

CREATE TABLE IF NOT EXISTS sales (
  id BIGSERIAL PRIMARY KEY,
  sale_date TIMESTAMPTZ NOT NULL DEFAULT now(),
  pump_id BIGINT REFERENCES pumps(id),
  tank_id BIGINT NOT NULL REFERENCES tanks(id),
  fuel_type VARCHAR(40) NOT NULL,
  liters NUMERIC(14,3) NOT NULL CHECK (liters > 0),
  unit_price NUMERIC(14,3) NOT NULL CHECK (unit_price >= 0),
  total NUMERIC(16,2) NOT NULL CHECK (total >= 0),
  payment_method VARCHAR(20) NOT NULL CHECK (payment_method IN ('cash','credit','bank')),
  cash_account_id BIGINT REFERENCES cash_accounts(id),
  created_by BIGINT NOT NULL REFERENCES users(id),
  voided BOOLEAN NOT NULL DEFAULT FALSE,
  void_reason TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS tank_movements (
  id BIGSERIAL PRIMARY KEY,
  tank_id BIGINT NOT NULL REFERENCES tanks(id),
  movement_type VARCHAR(30) NOT NULL CHECK (movement_type IN ('opening','purchase_receipt','sale','adjustment_in','adjustment_out','return')),
  quantity_liters NUMERIC(14,3) NOT NULL CHECK (quantity_liters > 0),
  before_liters NUMERIC(14,3) NOT NULL,
  after_liters NUMERIC(14,3) NOT NULL,
  reference_type VARCHAR(40),
  reference_id BIGINT,
  note TEXT,
  created_by BIGINT REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS purchases (
  id BIGSERIAL PRIMARY KEY,
  purchase_date TIMESTAMPTZ NOT NULL DEFAULT now(),
  supplier_id BIGINT REFERENCES suppliers(id),
  tank_id BIGINT NOT NULL REFERENCES tanks(id),
  fuel_type VARCHAR(40) NOT NULL,
  liters NUMERIC(14,3) NOT NULL CHECK (liters > 0),
  unit_cost NUMERIC(14,3) NOT NULL CHECK (unit_cost >= 0),
  total NUMERIC(16,2) NOT NULL CHECK (total >= 0),
  payment_method VARCHAR(20) NOT NULL CHECK (payment_method IN ('cash','credit','bank')),
  cash_account_id BIGINT REFERENCES cash_accounts(id),
  created_by BIGINT NOT NULL REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS cash_shifts (
  id BIGSERIAL PRIMARY KEY,
  user_id BIGINT NOT NULL REFERENCES users(id),
  cash_account_id BIGINT NOT NULL REFERENCES cash_accounts(id),
  opened_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  opening_cash NUMERIC(16,2) NOT NULL DEFAULT 0,
  expected_cash NUMERIC(16,2),
  counted_cash NUMERIC(16,2),
  variance NUMERIC(16,2),
  closing_note TEXT,
  closed_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS pump_reconciliations (
  id BIGSERIAL PRIMARY KEY,
  pump_id BIGINT NOT NULL REFERENCES pumps(id),
  opening_reading NUMERIC(16,3) NOT NULL,
  closing_reading NUMERIC(16,3) NOT NULL,
  measured_liters NUMERIC(14,3) NOT NULL,
  recorded_liters NUMERIC(14,3) NOT NULL,
  variance_liters NUMERIC(14,3) NOT NULL,
  note TEXT,
  created_by BIGINT NOT NULL REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK (closing_reading >= opening_reading)
);

CREATE TABLE IF NOT EXISTS audit_logs (
  id BIGSERIAL PRIMARY KEY,
  actor_id BIGINT REFERENCES users(id),
  action VARCHAR(100) NOT NULL,
  entity_type VARCHAR(80) NOT NULL,
  entity_id VARCHAR(100),
  details JSONB NOT NULL DEFAULT '{}'::jsonb,
  previous_hash TEXT,
  entry_hash TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- A minimal chart of accounts. Codes are stable API contracts.
INSERT INTO accounts(code,name,account_type) VALUES
('1000','النقدية والصناديق','asset'),
('1010','البنوك','asset'),
('1100','مخزون الوقود','asset'),
('1200','ذمم العملاء','asset'),
('2000','ذمم الموردين','liability'),
('3000','رأس المال','equity'),
('4000','إيرادات مبيعات الوقود','revenue'),
('5000','تكلفة الوقود المباع','expense'),
('5100','مصروفات تشغيلية','expense'),
('5200','فروقات جرد وتسويات','expense')
ON CONFLICT(code) DO NOTHING;

-- Prevent edits/deletions to posted journal rows and audit events.
CREATE OR REPLACE FUNCTION reject_immutable_change() RETURNS trigger AS $$
BEGIN
  RAISE EXCEPTION 'This record is immutable; create a reversal/correction instead.';
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS audit_no_update ON audit_logs;
CREATE TRIGGER audit_no_update BEFORE UPDATE OR DELETE ON audit_logs FOR EACH ROW EXECUTE FUNCTION reject_immutable_change();
DROP TRIGGER IF EXISTS journal_entry_no_update ON journal_entries;
CREATE TRIGGER journal_entry_no_update BEFORE UPDATE OR DELETE ON journal_entries FOR EACH ROW EXECUTE FUNCTION reject_immutable_change();
DROP TRIGGER IF EXISTS journal_line_no_update ON journal_lines;
CREATE TRIGGER journal_line_no_update BEFORE UPDATE OR DELETE ON journal_lines FOR EACH ROW EXECUTE FUNCTION reject_immutable_change();
