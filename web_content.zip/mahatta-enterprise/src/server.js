const express = require('express');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const crypto = require('crypto');
const { Pool } = require('pg');
const path = require('path');

const app = express();
const pool = new Pool({ connectionString: process.env.DATABASE_URL, max: 15, ssl: process.env.PGSSL === 'true' ? { rejectUnauthorized: true } : undefined });
const PORT = Number(process.env.PORT || 3000);
if (!process.env.JWT_SECRET || process.env.JWT_SECRET.length < 32) throw new Error('JWT_SECRET must be at least 32 characters');
app.disable('x-powered-by');
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: '1mb' }));
app.use(express.static(path.join(__dirname, '..', 'public')));
app.use('/api/auth/login', rateLimit({ windowMs: 15 * 60 * 1000, limit: 10, standardHeaders: true, legacyHeaders: false }));

const roles = {
  manager: ['*'],
  accountant: ['dashboard','sales:read','tanks:read','suppliers:read','cash:read','purchases:read','purchases:create','reports:read','accounting:read','reconcile:create'],
  cashier: ['dashboard','sales:read','sales:create','tanks:read','cash:read','shifts:own','reports:read']
};
const can = (user, permission) => roles[user.role]?.includes('*') || roles[user.role]?.includes(permission);
const safeUser = u => ({ id:u.id, username:u.username, full_name:u.full_name, role:u.role, must_change_password:u.must_change_password });
function auth(req,res,next) {
  const token = (req.headers.authorization || '').replace(/^Bearer\s+/i,'');
  if (!token) return res.status(401).json({error:'يلزم تسجيل الدخول'});
  try { req.user = jwt.verify(token, process.env.JWT_SECRET); next(); }
  catch { return res.status(401).json({error:'جلسة غير صالحة، سجّل الدخول مجدداً'}); }
}
function permit(permission) {
  return (req,res,next) => {
    if (!can(req.user, permission)) return res.status(403).json({error:'ليس لديك صلاحية لتنفيذ هذه العملية'});
    next();
  };
}
async function audit(client, actorId, action, entityType, entityId, details={}) {
  await client.query('SELECT pg_advisory_xact_lock(72619421)');
  const prev = await client.query('SELECT entry_hash FROM audit_logs ORDER BY id DESC LIMIT 1');
  const previousHash = prev.rows[0]?.entry_hash || 'GENESIS';
  const payload = JSON.stringify({actorId,action,entityType,entityId:String(entityId ?? ''),details,previousHash});
  const hash = crypto.createHash('sha256').update(payload).digest('hex');
  await client.query(`INSERT INTO audit_logs(actor_id,action,entity_type,entity_id,details,previous_hash,entry_hash)
    VALUES($1,$2,$3,$4,$5,$6,$7)`, [actorId,action,entityType,String(entityId ?? ''),details,previousHash,hash]);
}
async function transaction(fn) {
  const client = await pool.connect();
  try { await client.query('BEGIN'); const result = await fn(client); await client.query('COMMIT'); return result; }
  catch(e) { await client.query('ROLLBACK'); throw e; }
  finally { client.release(); }
}
const asyncRoute = fn => (req,res,next) => Promise.resolve(fn(req,res,next)).catch(next);
function num(v, name, {min=0, positive=false}={}) {
  const n = Number(v);
  if (!Number.isFinite(n) || (positive ? n <= min : n < min)) throw Object.assign(new Error(`قيمة غير صالحة للحقل: ${name}`),{status:400});
  return n;
}
async function postJournal(client, {date, type, refId, memo, actorId, lines}) {
  const debit = lines.reduce((s,l)=>s+Number(l.debit||0),0);
  const credit = lines.reduce((s,l)=>s+Number(l.credit||0),0);
  if (Math.abs(debit-credit) > 0.011) throw new Error('القيد المحاسبي غير متوازن');
  const entry = await client.query(`INSERT INTO journal_entries(entry_date,reference_type,reference_id,memo,created_by)
    VALUES(COALESCE($1::date,CURRENT_DATE),$2,$3,$4,$5) RETURNING id`,[date||null,type,refId,memo,actorId]);
  for (const line of lines) await client.query(`INSERT INTO journal_lines(entry_id,account_id,debit,credit,memo)
    SELECT $1,id,$3,$4,$5 FROM accounts WHERE code=$2`,[entry.rows[0].id,line.code,line.debit||0,line.credit||0,line.memo||null]);
  const count = await client.query('SELECT count(*)::int AS n FROM journal_lines WHERE entry_id=$1',[entry.rows[0].id]);
  if (count.rows[0].n !== lines.length) throw new Error('حساب محاسبي غير موجود في دليل الحسابات');
  return entry.rows[0].id;
}
async function bootstrap() {
  const username = process.env.ADMIN_USERNAME || 'admin';
  const password = process.env.ADMIN_PASSWORD;
  if (!password || password.length < 12) throw new Error('ADMIN_PASSWORD must be at least 12 characters');
  const exists = await pool.query('SELECT id FROM users WHERE username=$1',[username]);
  if (!exists.rowCount) {
    const hash = await bcrypt.hash(password,12);
    await pool.query(`INSERT INTO users(username,full_name,password_hash,role,must_change_password)
      VALUES($1,$2,$3,'manager',TRUE)`,[username,process.env.ADMIN_NAME||'مدير المحطة',hash]);
    console.log(`Created first manager account: ${username}. Change password immediately.`);
  }
}
app.post('/api/auth/login', asyncRoute(async(req,res)=>{
  const {username,password}=req.body||{};
  if(typeof username!=='string'||typeof password!=='string') return res.status(400).json({error:'أدخل اسم المستخدم وكلمة المرور'});
  const q=await pool.query('SELECT * FROM users WHERE username=$1 AND active=true',[username]);
  const u=q.rows[0];
  if(!u || !(await bcrypt.compare(password,u.password_hash))) return res.status(401).json({error:'بيانات الدخول غير صحيحة'});
  const token=jwt.sign({id:u.id,username:u.username,role:u.role},process.env.JWT_SECRET,{expiresIn:'8h',issuer:'mahatta'});
  await transaction(client=>audit(client,u.id,'login','user',u.id,{username:u.username}));
  res.json({token,user:safeUser(u)});
}));
app.get('/api/me',auth,asyncRoute(async(req,res)=>{
  const q=await pool.query('SELECT id,username,full_name,role,must_change_password FROM users WHERE id=$1 AND active=true',[req.user.id]);
  if(!q.rowCount)return res.status(401).json({error:'المستخدم غير نشط'});
  res.json(q.rows[0]);
}));
app.post('/api/auth/change-password',auth,asyncRoute(async(req,res)=>{
  const {currentPassword,newPassword}=req.body||{};
  if(typeof newPassword!=='string'||newPassword.length<12)return res.status(400).json({error:'كلمة المرور الجديدة يجب أن تكون 12 حرفاً على الأقل'});
  const q=await pool.query('SELECT password_hash FROM users WHERE id=$1',[req.user.id]);
  if(!q.rowCount||!(await bcrypt.compare(currentPassword||'',q.rows[0].password_hash)))return res.status(400).json({error:'كلمة المرور الحالية غير صحيحة'});
  const hash=await bcrypt.hash(newPassword,12);
  await transaction(async c=>{await c.query('UPDATE users SET password_hash=$1,must_change_password=false WHERE id=$2',[hash,req.user.id]);await audit(c,req.user.id,'change_password','user',req.user.id,{});});
  res.json({ok:true});
}));
app.post('/api/users',auth,permit('*'),asyncRoute(async(req,res)=>{
  const {username,full_name,password,role}=req.body||{};
  if(!username||!full_name||!password||password.length<12||!['manager','accountant','cashier'].includes(role))return res.status(400).json({error:'تحقق من اسم المستخدم والاسم وكلمة المرور والدور'});
  const hash=await bcrypt.hash(password,12);
  const u=await transaction(async c=>{const r=await c.query(`INSERT INTO users(username,full_name,password_hash,role) VALUES($1,$2,$3,$4) RETURNING id,username,full_name,role,active`,[username,full_name,hash,role]);await audit(c,req.user.id,'create','user',r.rows[0].id,{username,role});return r.rows[0]});
  res.status(201).json(u);
}));
app.get('/api/users',auth,permit('*'),asyncRoute(async(req,res)=>res.json((await pool.query('SELECT id,username,full_name,role,active,created_at FROM users ORDER BY id')).rows)));
app.patch('/api/users/:id/active',auth,permit('*'),asyncRoute(async(req,res)=>{
  if(Number(req.params.id)===Number(req.user.id))return res.status(400).json({error:'لا يمكنك تعطيل حسابك الحالي'});
  const active=!!req.body.active;
  await transaction(async c=>{await c.query('UPDATE users SET active=$1 WHERE id=$2',[active,req.params.id]);await audit(c,req.user.id,active?'activate':'deactivate','user',req.params.id,{active});});
  res.json({ok:true});
}));

app.get('/api/dashboard',auth,permit('dashboard'),asyncRoute(async(req,res)=>{
 const [s,t,c,d,p]=await Promise.all([
  pool.query(`SELECT COALESCE(sum(total),0) total,count(*) count FROM sales WHERE NOT voided AND sale_date::date=CURRENT_DATE`),
  pool.query('SELECT COALESCE(sum(current_liters),0) liters,count(*) count FROM tanks WHERE active'),
  pool.query('SELECT COALESCE(sum(current_balance),0) balance FROM cash_accounts WHERE active'),
  pool.query(`SELECT COALESCE(sum(s.opening_balance),0) opening FROM suppliers s WHERE active`),
  pool.query(`SELECT COALESCE(sum(total),0) total FROM purchases WHERE purchase_date::date=CURRENT_DATE`)
 ]);
 res.json({today_sales:s.rows[0],tanks:t.rows[0],cash_accounts:c.rows[0],supplier_opening_balances:d.rows[0],today_purchases:p.rows[0]});
}));
app.get('/api/tanks',auth,permit('tanks:read'),asyncRoute(async(req,res)=>res.json((await pool.query('SELECT * FROM tanks ORDER BY id')).rows)));
app.post('/api/tanks',auth,permit('*'),asyncRoute(async(req,res)=>{
 const {name,fuel_type,capacity_liters,current_liters=0,low_level_liters=0}=req.body||{};
 if(!name||!fuel_type)return res.status(400).json({error:'اسم الخزان ونوع الوقود مطلوبان'});
 const cap=num(capacity_liters,'السعة',{positive:true}), bal=num(current_liters,'الرصيد');
 if(bal>cap)return res.status(400).json({error:'الرصيد يتجاوز سعة الخزان'});
 const row=await transaction(async c=>{
  const r=await c.query(`INSERT INTO tanks(name,fuel_type,capacity_liters,current_liters,low_level_liters) VALUES($1,$2,$3,$4,$5) RETURNING *`,[name,fuel_type,cap,bal,num(low_level_liters,'حد التنبيه')]);
  if(bal>0)await c.query(`INSERT INTO tank_movements(tank_id,movement_type,quantity_liters,before_liters,after_liters,note,created_by) VALUES($1,'opening',$2,0,$2,'رصيد افتتاحي',$3)`,[r.rows[0].id,bal,req.user.id]);
  await audit(c,req.user.id,'create','tank',r.rows[0].id,{name,fuel_type,capacity_liters:cap,current_liters:bal});return r.rows[0];
 });
 res.status(201).json(row);
}));
app.post('/api/pumps',auth,permit('*'),asyncRoute(async(req,res)=>{
 const {name,fuel_type,tank_id,meter_reading=0}=req.body||{};
 const row=await transaction(async c=>{const r=await c.query('INSERT INTO pumps(name,fuel_type,tank_id,meter_reading) VALUES($1,$2,$3,$4) RETURNING *',[name,fuel_type,tank_id,num(meter_reading,'قراءة العداد')]);await audit(c,req.user.id,'create','pump',r.rows[0].id,{name,tank_id});return r.rows[0]});
 res.status(201).json(row);
}));
app.get('/api/pumps',auth,permit('tanks:read'),asyncRoute(async(req,res)=>res.json((await pool.query('SELECT p.*,t.name tank_name FROM pumps p JOIN tanks t ON t.id=p.tank_id ORDER BY p.id')).rows)));

app.get('/api/sales',auth,permit('sales:read'),asyncRoute(async(req,res)=>{
 const {from,to}=req.query; const args=[]; let where='WHERE NOT s.voided';
 if(from){args.push(from);where+=` AND s.sale_date >= $${args.length}::date`;}
 if(to){args.push(to);where+=` AND s.sale_date < ($${args.length}::date + INTERVAL '1 day')`;}
 res.json((await pool.query(`SELECT s.*,p.name pump_name,t.name tank_name,u.full_name cashier FROM sales s LEFT JOIN pumps p ON p.id=s.pump_id JOIN tanks t ON t.id=s.tank_id JOIN users u ON u.id=s.created_by ${where} ORDER BY s.sale_date DESC LIMIT 500`,args)).rows);
}));
app.post('/api/sales',auth,permit('sales:create'),asyncRoute(async(req,res)=>{
 const {pump_id=null,tank_id,fuel_type,liters,unit_price,payment_method='cash',cash_account_id=null}=req.body||{};
 const qty=num(liters,'اللترات',{positive:true}),price=num(unit_price,'سعر اللتر');
 if(!['cash','credit','bank'].includes(payment_method))return res.status(400).json({error:'طريقة دفع غير صالحة'});
 const result=await transaction(async c=>{
  const tq=await c.query('SELECT * FROM tanks WHERE id=$1 AND active=true FOR UPDATE',[tank_id]);
  if(!tq.rowCount)throw Object.assign(new Error('الخزان غير موجود'),{status:400});
  const tank=tq.rows[0]; if(tank.fuel_type!==fuel_type)throw Object.assign(new Error('نوع الوقود لا يطابق نوع الخزان'),{status:400});
  if(Number(tank.current_liters)<qty)throw Object.assign(new Error('رصيد الخزان لا يكفي لهذه المبيعة'),{status:409});
  if(pump_id){const pq=await c.query('SELECT * FROM pumps WHERE id=$1 AND active=true FOR UPDATE',[pump_id]);if(!pq.rowCount||Number(pq.rows[0].tank_id)!==Number(tank_id))throw Object.assign(new Error('المضخة غير مرتبطة بالخزان المحدد'),{status:400});}
  if(payment_method!=='credit'&&!cash_account_id)throw Object.assign(new Error('اختر الصندوق أو الحساب الذي استلم المبلغ'),{status:400});
  const total=Number((qty*price).toFixed(2));
  const s=await c.query(`INSERT INTO sales(pump_id,tank_id,fuel_type,liters,unit_price,total,payment_method,cash_account_id,created_by) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING *`,[pump_id,tank_id,fuel_type,qty,price,total,payment_method,cash_account_id,req.user.id]);
  const after=Number(tank.current_liters)-qty;
  await c.query('UPDATE tanks SET current_liters=$1 WHERE id=$2',[after,tank_id]);
  await c.query(`INSERT INTO tank_movements(tank_id,movement_type,quantity_liters,before_liters,after_liters,reference_type,reference_id,created_by) VALUES($1,'sale',$2,$3,$4,'sale',$5,$6)`,[tank_id,qty,tank.current_liters,after,s.rows[0].id,req.user.id]);
  if(payment_method!=='credit') await c.query('UPDATE cash_accounts SET current_balance=current_balance+$1 WHERE id=$2',[total,cash_account_id]);
  if(pump_id) await c.query('UPDATE pumps SET meter_reading=meter_reading+$1 WHERE id=$2',[qty,pump_id]);
  const debitCode=payment_method==='credit'?'1200':payment_method==='bank'?'1010':'1000';
  const lines=[{code:debitCode,debit:total},{code:'4000',credit:total}];
  await postJournal(c,{type:'sale',refId:s.rows[0].id,memo:`مبيعات ${fuel_type}، ${qty} لتر`,actorId:req.user.id,lines});
  await audit(c,req.user.id,'create','sale',s.rows[0].id,{liters:qty,total,payment_method,tank_id,pump_id});
  return s.rows[0];
 });
 res.status(201).json(result);
}));

app.get('/api/suppliers',auth,permit('suppliers:read'),asyncRoute(async(req,res)=>res.json((await pool.query('SELECT * FROM suppliers ORDER BY name')).rows)));
app.post('/api/suppliers',auth,permit('*'),asyncRoute(async(req,res)=>{
 const {name,phone=null,opening_balance=0}=req.body||{};if(!name)return res.status(400).json({error:'اسم المورد مطلوب'});
 const r=await transaction(async c=>{const x=await c.query('INSERT INTO suppliers(name,phone,opening_balance) VALUES($1,$2,$3) RETURNING *',[name,phone,num(opening_balance,'الرصيد')]);await audit(c,req.user.id,'create','supplier',x.rows[0].id,{name});return x.rows[0]});
 res.status(201).json(r);
}));
app.get('/api/cash-accounts',auth,permit('cash:read'),asyncRoute(async(req,res)=>res.json((await pool.query('SELECT * FROM cash_accounts ORDER BY id')).rows)));
app.post('/api/cash-accounts',auth,permit('*'),asyncRoute(async(req,res)=>{
 const {name,account_type,opening_balance=0}=req.body||{};if(!name||!['cash','bank','wallet'].includes(account_type))return res.status(400).json({error:'بيانات الحساب غير صحيحة'});
 const r=await transaction(async c=>{const x=await c.query('INSERT INTO cash_accounts(name,account_type,opening_balance,current_balance) VALUES($1,$2,$3,$3) RETURNING *',[name,account_type,num(opening_balance,'الرصيد')]);await audit(c,req.user.id,'create','cash_account',x.rows[0].id,{name,account_type});return x.rows[0]});
 res.status(201).json(r);
}));
app.get('/api/purchases',auth,permit('purchases:read'),asyncRoute(async(req,res)=>res.json((await pool.query('SELECT p.*,s.name supplier_name,t.name tank_name FROM purchases p LEFT JOIN suppliers s ON s.id=p.supplier_id JOIN tanks t ON t.id=p.tank_id ORDER BY purchase_date DESC LIMIT 500')).rows)));
app.post('/api/purchases',auth,permit('purchases:create'),asyncRoute(async(req,res)=>{
 const {supplier_id=null,tank_id,fuel_type,liters,unit_cost,payment_method='credit',cash_account_id=null}=req.body||{};
 const qty=num(liters,'اللترات',{positive:true}),cost=num(unit_cost,'تكلفة اللتر'),total=Number((qty*cost).toFixed(2));
 if(!['cash','credit','bank'].includes(payment_method))return res.status(400).json({error:'طريقة الدفع غير صحيحة'});
 const result=await transaction(async c=>{
  const tq=await c.query('SELECT * FROM tanks WHERE id=$1 AND active=true FOR UPDATE',[tank_id]);if(!tq.rowCount)throw Object.assign(new Error('الخزان غير موجود'),{status:400});
  const t=tq.rows[0];if(t.fuel_type!==fuel_type)throw Object.assign(new Error('نوع الوقود لا يطابق الخزان'),{status:400});
  if(Number(t.current_liters)+qty>Number(t.capacity_liters))throw Object.assign(new Error('الكمية ستتجاوز سعة الخزان'),{status:409});
  if(payment_method!=='credit'&&!cash_account_id)throw Object.assign(new Error('اختر حساب الدفع'),{status:400});
  const p=await c.query(`INSERT INTO purchases(supplier_id,tank_id,fuel_type,liters,unit_cost,total,payment_method,cash_account_id,created_by) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING *`,[supplier_id,tank_id,fuel_type,qty,cost,total,payment_method,cash_account_id,req.user.id]);
  await c.query('UPDATE tanks SET current_liters=current_liters+$1 WHERE id=$2',[qty,tank_id]);
  await c.query(`INSERT INTO tank_movements(tank_id,movement_type,quantity_liters,before_liters,after_liters,reference_type,reference_id,created_by) VALUES($1,'purchase_receipt',$2,$3,$4,'purchase',$5,$6)`,[tank_id,qty,t.current_liters,Number(t.current_liters)+qty,p.rows[0].id,req.user.id]);
  if(payment_method!=='credit') await c.query('UPDATE cash_accounts SET current_balance=current_balance-$1 WHERE id=$2',[total,cash_account_id]);
  const debitCode='1100',creditCode=payment_method==='credit'?'2000':payment_method==='bank'?'1010':'1000';
  await postJournal(c,{type:'purchase',refId:p.rows[0].id,memo:`شراء ${fuel_type}، ${qty} لتر`,actorId:req.user.id,lines:[{code:debitCode,debit:total},{code:creditCode,credit:total}]});
  await audit(c,req.user.id,'create','purchase',p.rows[0].id,{liters:qty,total,tank_id,supplier_id});
  return p.rows[0];
 });
 res.status(201).json(result);
}));

app.get('/api/pump-reconciliation',auth,permit('reports:read'),asyncRoute(async(req,res)=>res.json((await pool.query(`SELECT r.*,p.name pump_name,u.full_name created_by_name FROM pump_reconciliations r JOIN pumps p ON p.id=r.pump_id JOIN users u ON u.id=r.created_by ORDER BY r.created_at DESC LIMIT 300`)).rows)));
app.post('/api/pump-reconciliation',auth,permit('reconcile:create'),asyncRoute(async(req,res)=>{
 const {pump_id,opening_reading,closing_reading,note=''}=req.body||{};
 const open=num(opening_reading,'قراءة البداية'),close=num(closing_reading,'قراءة النهاية');if(close<open)return res.status(400).json({error:'قراءة النهاية يجب ألا تقل عن قراءة البداية'});
 const result=await transaction(async c=>{
  const pq=await c.query('SELECT * FROM pumps WHERE id=$1 FOR UPDATE',[pump_id]);if(!pq.rowCount)throw Object.assign(new Error('المضخة غير موجودة'),{status:400});
  const measured=Number((close-open).toFixed(3));
  const sold=await c.query(`SELECT COALESCE(sum(liters),0) n FROM sales WHERE pump_id=$1 AND NOT voided AND created_at >= (SELECT COALESCE(max(created_at),'1970-01-01'::timestamptz) FROM pump_reconciliations WHERE pump_id=$1)`,[pump_id]);
  const recorded=Number(sold.rows[0].n),variance=Number((measured-recorded).toFixed(3));
  const r=await c.query(`INSERT INTO pump_reconciliations(pump_id,opening_reading,closing_reading,measured_liters,recorded_liters,variance_liters,note,created_by) VALUES($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`,[pump_id,open,close,measured,recorded,variance,note,req.user.id]);
  await c.query('UPDATE pumps SET meter_reading=$1 WHERE id=$2',[close,pump_id]);
  await audit(c,req.user.id,'reconcile','pump',pump_id,{measured,recorded,variance});
  return r.rows[0];
 });
 res.status(201).json(result);
}));

app.post('/api/tank-adjustments',auth,permit('*'),asyncRoute(async(req,res)=>{
 const {tank_id,direction,liters,note}=req.body||{};const qty=num(liters,'الكمية',{positive:true});
 if(!['in','out'].includes(direction)||!note||note.trim().length<5)return res.status(400).json({error:'حدد اتجاه التسوية وسبباً واضحاً من 5 أحرف على الأقل'});
 const result=await transaction(async c=>{
  const q=await c.query('SELECT * FROM tanks WHERE id=$1 FOR UPDATE',[tank_id]);if(!q.rowCount)throw Object.assign(new Error('الخزان غير موجود'),{status:400});
  const t=q.rows[0],after=Number(t.current_liters)+(direction==='in'?qty:-qty);
  if(after<0||after>Number(t.capacity_liters))throw Object.assign(new Error('التسوية ستتجاوز حدود الخزان'),{status:409});
  await c.query('UPDATE tanks SET current_liters=$1 WHERE id=$2',[after,tank_id]);
  const m=await c.query(`INSERT INTO tank_movements(tank_id,movement_type,quantity_liters,before_liters,after_liters,note,created_by) VALUES($1,$2,$3,$4,$5,$6,$7) RETURNING *`,[tank_id,direction==='in'?'adjustment_in':'adjustment_out',qty,t.current_liters,after,note,req.user.id]);
  if(direction==='out') await postJournal(c,{type:'tank_adjustment',refId:m.rows[0].id,memo:`تسوية نقص مخزون: ${note}`,actorId:req.user.id,lines:[{code:'5200',debit:0.01},{code:'1100',credit:0.01}]});
  await audit(c,req.user.id,'adjust','tank',tank_id,{direction,liters:qty,note,before:t.current_liters,after});
  return m.rows[0];
 });
 res.status(201).json(result);
}));

app.get('/api/ledger',auth,permit('accounting:read'),asyncRoute(async(req,res)=>{
 const {from,to,account_id}=req.query;const args=[];let where='WHERE je.posted=true';
 if(from){args.push(from);where+=` AND je.entry_date >= $${args.length}::date`;}
 if(to){args.push(to);where+=` AND je.entry_date <= $${args.length}::date`;}
 if(account_id){args.push(account_id);where+=` AND a.id=$${args.length}`;}
 const q=await pool.query(`SELECT je.id entry_id,je.entry_date,je.reference_type,je.reference_id,je.memo, a.code account_code,a.name account_name,jl.debit,jl.credit,u.full_name created_by FROM journal_entries je JOIN journal_lines jl ON jl.entry_id=je.id JOIN accounts a ON a.id=jl.account_id LEFT JOIN users u ON u.id=je.created_by ${where} ORDER BY je.entry_date DESC,je.id DESC,jl.id`,args);
 res.json(q.rows);
}));
app.get('/api/reports/profit-loss',auth,permit('accounting:read'),asyncRoute(async(req,res)=>{
 const from=req.query.from||new Date(new Date().getFullYear(),new Date().getMonth(),1).toISOString().slice(0,10);
 const to=req.query.to||new Date().toISOString().slice(0,10);
 const q=await pool.query(`SELECT a.code,a.name,a.account_type,COALESCE(SUM(jl.credit-jl.debit),0) net FROM accounts a JOIN journal_lines jl ON jl.account_id=a.id JOIN journal_entries je ON je.id=jl.entry_id WHERE je.posted=true AND je.entry_date BETWEEN $1::date AND $2::date AND a.account_type IN ('revenue','expense') GROUP BY a.id ORDER BY a.code`,[from,to]);
 const revenue=q.rows.filter(x=>x.account_type==='revenue').reduce((s,x)=>s+Number(x.net),0);
 const expenses=q.rows.filter(x=>x.account_type==='expense').reduce((s,x)=>s+Math.abs(Number(x.net)),0);
 res.json({from,to,accounts:q.rows,revenue,expenses,net_profit:revenue-expenses});
}));
app.get('/api/reports/trial-balance',auth,permit('accounting:read'),asyncRoute(async(req,res)=>{
 const q=await pool.query(`SELECT a.code,a.name,a.account_type,COALESCE(sum(jl.debit),0) debit,COALESCE(sum(jl.credit),0) credit FROM accounts a LEFT JOIN journal_lines jl ON jl.account_id=a.id LEFT JOIN journal_entries je ON je.id=jl.entry_id AND je.posted=true GROUP BY a.id ORDER BY a.code`);
 res.json(q.rows.map(x=>({...x,balance:Number(x.debit)-Number(x.credit)})));
}));
app.get('/api/tank-movements',auth,permit('tanks:read'),asyncRoute(async(req,res)=>res.json((await pool.query(`SELECT m.*,t.name tank_name,u.full_name actor FROM tank_movements m JOIN tanks t ON t.id=m.tank_id LEFT JOIN users u ON u.id=m.created_by ORDER BY m.created_at DESC LIMIT 500`)).rows)));
app.get('/api/audit',auth,permit('*'),asyncRoute(async(req,res)=>res.json((await pool.query('SELECT id,actor_id,action,entity_type,entity_id,details,previous_hash,entry_hash,created_at FROM audit_logs ORDER BY id DESC LIMIT 500')).rows)));
app.get('/api/accounts',auth,permit('accounting:read'),asyncRoute(async(req,res)=>res.json((await pool.query('SELECT * FROM accounts ORDER BY code')).rows)));
app.get('/api/cash-shifts',auth,asyncRoute(async(req,res)=>{
 const own= req.user.role==='cashier' ? 'WHERE cs.user_id=$1' : '';
 const args=own?[req.user.id]:[];
 if(!can(req.user,'cash:read'))return res.status(403).json({error:'ليس لديك صلاحية'});
 res.json((await pool.query(`SELECT cs.*,u.full_name,c.name account_name FROM cash_shifts cs JOIN users u ON u.id=cs.user_id JOIN cash_accounts c ON c.id=cs.cash_account_id ${own} ORDER BY cs.opened_at DESC LIMIT 200`,args)).rows);
}));
app.post('/api/cash-shifts/open',auth,permit('shifts:own'),asyncRoute(async(req,res)=>{
 const {cash_account_id,opening_cash=0}=req.body||{};
 const result=await transaction(async c=>{
  const active=await c.query('SELECT id FROM cash_shifts WHERE user_id=$1 AND closed_at IS NULL',[req.user.id]);if(active.rowCount)throw Object.assign(new Error('لديك وردية مفتوحة بالفعل'),{status:409});
  const r=await c.query('INSERT INTO cash_shifts(user_id,cash_account_id,opening_cash) VALUES($1,$2,$3) RETURNING *',[req.user.id,cash_account_id,num(opening_cash,'النقد الافتتاحي')]);
  await audit(c,req.user.id,'open_shift','cash_shift',r.rows[0].id,{opening_cash});return r.rows[0];
 });
 res.status(201).json(result);
}));
app.post('/api/cash-shifts/:id/close',auth,asyncRoute(async(req,res)=>{
 const {counted_cash,closing_note=''}=req.body||{};const counted=num(counted_cash,'النقد المعدود');
 const result=await transaction(async c=>{
  const q=await c.query('SELECT * FROM cash_shifts WHERE id=$1 FOR UPDATE',[req.params.id]);if(!q.rowCount)throw Object.assign(new Error('الوردية غير موجودة'),{status:404});
  const s=q.rows[0];if(req.user.role==='cashier'&&Number(s.user_id)!==Number(req.user.id))throw Object.assign(new Error('لا يمكنك إغلاق وردية مستخدم آخر'),{status:403});
  if(s.closed_at)throw Object.assign(new Error('الوردية مغلقة بالفعل'),{status:409});
  const totals=await c.query(`SELECT
    COALESCE((SELECT sum(total) FROM sales WHERE created_by=$1 AND payment_method='cash' AND sale_date BETWEEN $2 AND now() AND NOT voided),0) sales,
    COALESCE((SELECT sum(total) FROM purchases WHERE created_by=$1 AND payment_method='cash' AND purchase_date BETWEEN $2 AND now()),0) purchases`,
    [s.user_id,s.opened_at]);
  const expected=Number(s.opening_cash)+Number(totals.rows[0].sales)-Number(totals.rows[0].purchases),variance=counted-expected;
  const r=await c.query('UPDATE cash_shifts SET expected_cash=$1,counted_cash=$2,variance=$3,closing_note=$4,closed_at=now() WHERE id=$5 RETURNING *',[expected,counted,variance,closing_note,req.params.id]);
  await audit(c,req.user.id,'close_shift','cash_shift',req.params.id,{expected,counted,variance});return r.rows[0];
 });
 res.json(result);
}));

app.use('/api', (err,req,res,next)=>{
 console.error(err);
 res.status(err.status||500).json({error:err.status?err.message:'حدث خطأ داخلي. راجع سجل الخادم.'});
});
app.get('*',(req,res)=>res.sendFile(path.join(__dirname,'..','public','index.html')));
bootstrap().then(()=>app.listen(PORT,'0.0.0.0',()=>console.log(`Mahattta app listening on ${PORT}`))).catch(e=>{console.error(e);process.exit(1)});
