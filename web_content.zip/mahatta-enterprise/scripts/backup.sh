#!/bin/sh
set -eu
# Run on the host after configuring .env. Keep backups encrypted/offsite in production.
set -a
. ./.env
set +a
mkdir -p backups
stamp="$(date +%Y%m%d_%H%M%S)"
docker compose exec -T db pg_dump -U "${POSTGRES_USER:-mahatta}" -d "${POSTGRES_DB:-mahatta}" --format=custom > "backups/mahatta_${stamp}.dump"
echo "Backup created: backups/mahatta_${stamp}.dump"
