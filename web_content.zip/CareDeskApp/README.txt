CareDesk - Hospital Management (Android app project)

Build the APK:
1. Install Android Studio (free): https://developer.android.com/studio
2. Unzip this folder. In Android Studio choose File > Open and select the CareDeskApp folder.
3. Wait for "Gradle sync" to finish (needs internet the first time).
4. Menu: Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Click "locate" in the popup. The file is app/build/outputs/apk/debug/app-debug.apk
6. Copy app-debug.apk to your phone and tap it to install
   (allow "Install unknown apps" if Android asks).

To test straight away: plug in your phone (USB debugging on) or start an emulator and press the green Run button.

QR scanner:
- Open any patient to see their ID card (Patient ID + QR code).
- Go to the Scan tab and tap "Scan QR with camera", then point the phone at a patient's QR code
  (shown on another screen or printed). The full patient record opens.
- The scanner uses Google Play services. The phone needs Google Play services, and the first scan
  may download the scanner module. If scanning is not available, type the Patient ID in the Scan tab instead.

The whole app lives in app/src/main/assets/index.html.
Data is stored on the phone itself.
