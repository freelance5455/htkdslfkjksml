plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.caredesk.hospital"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.caredesk.hospital"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }
    buildTypes {
        release { isMinifyEnabled = false }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    // Google code scanner: opens a ready-made QR scanner screen (no camera permission needed)
    implementation("com.google.android.gms:play-services-code-scanner:16.1.0")
}
