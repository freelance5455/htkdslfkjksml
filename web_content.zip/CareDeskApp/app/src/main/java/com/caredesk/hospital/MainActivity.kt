package com.caredesk.hospital

import android.annotation.SuppressLint
import android.app.Activity
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.codescanner.GmsBarcodeScannerOptions
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var web: WebView

    /** Called from the web page as Android.scan(); opens Google's QR scanner screen. */
    inner class Bridge {
        @JavascriptInterface
        fun scan() {
            runOnUiThread {
                val options = GmsBarcodeScannerOptions.Builder()
                    .setBarcodeFormats(Barcode.FORMAT_QR_CODE)
                    .build()
                GmsBarcodeScanning.getClient(this@MainActivity, options)
                    .startScan()
                    .addOnSuccessListener { barcode ->
                        js("onScanResult(" + JSONObject.quote(barcode.rawValue ?: "") + ")")
                    }
                    .addOnCanceledListener { js("onScanError('Scan cancelled')") }
                    .addOnFailureListener { js("onScanError('Scanner not available. Use the ID box instead.')") }
            }
        }
    }

    private fun js(code: String) = web.evaluateJavascript(code, null)

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true   // keeps patient data saved on the phone
        web.addJavascriptInterface(Bridge(), "Android")
        web.webViewClient = WebViewClient()
        setContentView(web)
        if (savedInstanceState != null) web.restoreState(savedInstanceState)
        else web.loadUrl("file:///android_asset/index.html")
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        web.saveState(outState)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}
