#!/data/data/com.termux/files/usr/bin/bash
cd "$(dirname "$0")"
export PORT="${PORT:-8787}"
python run.py
