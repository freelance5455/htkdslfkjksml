"""Dijo Business OS - Android/Termux launcher."""
import os
from server import app

if __name__ == "__main__":
    port = int(os.environ.get("PORT", "8787"))
    print("\n╔══════════════════════════════════════╗")
    print("║       DIJO BUSINESS OS 3.0.0         ║")
    print("║       http://127.0.0.1:%s          ║" % port)
    print("╚══════════════════════════════════════╝\n")
    app.run(host="0.0.0.0", port=port, debug=False, threaded=True, use_reloader=False)
