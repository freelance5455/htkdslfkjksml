# ============================================================
# DIJO BUSINESS DATABASE v3 - PostgreSQL Edition
# ============================================================

import os
import threading
import logging
import secrets
import hashlib
from datetime import datetime, timedelta

import sqlite3

logger = logging.getLogger("dijo.db")

DATABASE_PATH = os.environ.get("DIJO_DB_PATH", os.path.join(os.path.dirname(os.path.abspath(__file__)), "dijo.db"))
DB_PATH = DATABASE_PATH  # سازگاری با ابزارهای پشتیبان‌گیری قدیمی

def get_db_path():
    return DATABASE_PATH
_tenant = threading.local()


def get_pg_conn():
    """SQLite connection kept under the old function name for compatibility."""
    conn = sqlite3.connect(DATABASE_PATH, timeout=30, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn


def get_conn():
    return get_pg_conn()


def get_master_conn():
    return get_pg_conn()


def _uid():
    return getattr(_tenant, "user_id", None)

def _bid():
    return getattr(_tenant, "business_id", 1)


def set_current_user(user_id, business_id=1):
    try:
        uid = int(user_id)
    except (TypeError, ValueError):
        raise ValueError("شناسه کاربر نامعتبر است.")
    if uid <= 0:
        raise ValueError("شناسه کاربر نامعتبر است.")
    try:
        bid = int(business_id or 1)
    except (TypeError, ValueError):
        raise ValueError("شناسه کسب‌وکار نامعتبر است.")
    _tenant.user_id = uid
    _tenant.business_id = bid


def clear_current_user():
    for attr in ("user_id", "business_id"):
        if hasattr(_tenant, attr):
            delattr(_tenant, attr)


def row_to_dict(row):
    return dict(row) if row else None


def rows_to_list(rows):
    return [dict(r) for r in rows] if rows else []


def _fetch_one(cur):
    row = cur.fetchone()
    return dict(row) if row else None


def _fetch_all(cur):
    rows = cur.fetchall()
    return [dict(r) for r in rows] if rows else []


def _ensure_column(conn, table, column, coltype):
    cur = conn.cursor()
    # از PRAGMA استفاده می‌کنیم چون information_schema در SQLite وجود ندارد
    cur.execute(f"PRAGMA table_info({table})")
    cols = [row[1] for row in cur.fetchall()]
    if column not in cols:
        conn.cursor().execute(f"ALTER TABLE {table} ADD COLUMN {column} {coltype}")


def init_db():
    conn = get_pg_conn()
    cur = conn.cursor()

    # Users & Auth
    cur.execute("""CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT NOT NULL UNIQUE,
        password_hash TEXT NOT NULL,
        phone TEXT,
        first_name TEXT,
        last_name TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )""")

    cur.execute("""CREATE TABLE IF NOT EXISTS businesses (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        name TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )""")

    cur.execute("""CREATE TABLE IF NOT EXISTS api_keys (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        name TEXT NOT NULL,
        key_hash TEXT NOT NULL UNIQUE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        last_used_at TIMESTAMP
    )""")

    cur.execute("""CREATE TABLE IF NOT EXISTS auth_otps (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        phone TEXT NOT NULL,
        code_hash TEXT NOT NULL,
        expires_at BIGINT NOT NULL,
        attempts INTEGER NOT NULL DEFAULT 0,
        used INTEGER NOT NULL DEFAULT 0,
        created_at BIGINT NOT NULL
    )""")

    # Business tables (multi-tenant with user_id + business_id)
    cur.execute("""CREATE TABLE IF NOT EXISTS customers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        business_id INTEGER NOT NULL DEFAULT 1,
        name TEXT NOT NULL,
        phone TEXT,
        address TEXT,
        note TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )""")

    cur.execute("""CREATE TABLE IF NOT EXISTS products (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        business_id INTEGER NOT NULL DEFAULT 1,
        name TEXT NOT NULL,
        price REAL NOT NULL DEFAULT 0,
        cost_price REAL NOT NULL DEFAULT 0,
        stock REAL NOT NULL DEFAULT 0,
        note TEXT,
        barcode TEXT,
        category TEXT,
        unit TEXT NOT NULL DEFAULT 'عدد',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )""")

    cur.execute("""CREATE TABLE IF NOT EXISTS orders (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        business_id INTEGER NOT NULL DEFAULT 1,
        customer_id INTEGER,
        total REAL NOT NULL DEFAULT 0,
        discount REAL NOT NULL DEFAULT 0,
        status TEXT DEFAULT 'تکمیل‌شده',
        note TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )""")

    cur.execute("""CREATE TABLE IF NOT EXISTS order_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        business_id INTEGER NOT NULL DEFAULT 1,
        order_id INTEGER NOT NULL,
        product_id INTEGER,
        product_name TEXT,
        qty REAL NOT NULL DEFAULT 1,
        price REAL NOT NULL DEFAULT 0,
        cost_price REAL NOT NULL DEFAULT 0
    )""")

    cur.execute("""CREATE TABLE IF NOT EXISTS payments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        business_id INTEGER NOT NULL DEFAULT 1,
        order_id INTEGER,
        customer_id INTEGER NOT NULL,
        amount REAL NOT NULL,
        method TEXT DEFAULT 'نقدی',
        note TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )""")

    cur.execute("""CREATE TABLE IF NOT EXISTS customer_ledger (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        business_id INTEGER NOT NULL DEFAULT 1,
        customer_id INTEGER NOT NULL,
        kind TEXT NOT NULL,
        amount REAL NOT NULL,
        note TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )""")

    cur.execute("""CREATE TABLE IF NOT EXISTS stock_movements (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        business_id INTEGER NOT NULL DEFAULT 1,
        product_id INTEGER,
        product_name TEXT,
        movement_type TEXT NOT NULL,
        quantity REAL NOT NULL,
        reference_type TEXT,
        reference_id INTEGER,
        note TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )""")

    cur.execute("""CREATE TABLE IF NOT EXISTS transactions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        business_id INTEGER NOT NULL DEFAULT 1,
        title TEXT NOT NULL,
        amount REAL NOT NULL,
        kind TEXT NOT NULL,
        category TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )""")

    cur.execute("""CREATE TABLE IF NOT EXISTS tasks (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        business_id INTEGER NOT NULL DEFAULT 1,
        title TEXT NOT NULL,
        due_date TEXT,
        done INTEGER NOT NULL DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )""")

    cur.execute("""CREATE TABLE IF NOT EXISTS suppliers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        business_id INTEGER NOT NULL DEFAULT 1,
        name TEXT NOT NULL,
        phone TEXT,
        note TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )""")

    cur.execute("""CREATE TABLE IF NOT EXISTS purchases (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        business_id INTEGER NOT NULL DEFAULT 1,
        supplier_id INTEGER,
        total REAL NOT NULL DEFAULT 0,
        note TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )""")

    cur.execute("""CREATE TABLE IF NOT EXISTS purchase_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        business_id INTEGER NOT NULL DEFAULT 1,
        purchase_id INTEGER NOT NULL,
        product_id INTEGER,
        product_name TEXT,
        qty REAL NOT NULL DEFAULT 1,
        cost_price REAL NOT NULL DEFAULT 0
    )""")

    cur.execute("""CREATE TABLE IF NOT EXISTS notifications (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        business_id INTEGER NOT NULL DEFAULT 1,
        kind TEXT NOT NULL,
        title TEXT NOT NULL,
        body TEXT NOT NULL,
        is_read INTEGER NOT NULL DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )""")

    cur.execute("""CREATE TABLE IF NOT EXISTS chat_messages (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        business_id INTEGER NOT NULL DEFAULT 1,
        session_id TEXT NOT NULL,
        role TEXT NOT NULL,
        content TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )""")

    conn.commit()
    conn.close()
    logger.info("Database initialized.")


# ------------------------- CUSTOMERS -------------------------

def add_customer(name, phone=None, address=None, note=None):
    name = (name or "").strip()
    if not name:
        raise ValueError("نام مشتری الزامی است.")
    conn = get_conn()
    cur = conn.cursor()
    cur.execute(
        "INSERT INTO customers(user_id,business_id,name,phone,address,note) VALUES(?,?,?,?,?,?) RETURNING id",
        (_uid(), _bid(), name, phone, address, note)
    )
    new_id = cur.fetchone()["id"]
    conn.commit(); conn.close()
    return new_id


def list_customers(query=None):
    conn = get_conn()
    cur = conn.cursor()
    base = """SELECT c.*,
        COALESCE((SELECT SUM(CASE WHEN kind='debt' THEN amount ELSE -amount END)
                  FROM customer_ledger WHERE customer_id=c.id AND user_id=? AND business_id=?),0) AS balance
        FROM customers c WHERE c.user_id=? AND c.business_id=?"""
    args = [_uid(), _bid(), _uid(), _bid()]
    if query:
        base += " AND (c.name LIKE ? OR c.phone LIKE ?)"
        args += [f"%{query}%", f"%{query}%"]
    base += " ORDER BY c.id DESC"
    cur.execute(base, args)
    rows = _fetch_all(cur); conn.close()
    return rows


def find_customer_by_name(name):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute(
        "SELECT * FROM customers WHERE user_id=? AND business_id=? AND name LIKE ? ORDER BY id DESC LIMIT 1",
        (_uid(), _bid(), f"%{(name or '').strip()}%")
    )
    row = _fetch_one(cur); conn.close()
    return row


def update_customer(customer_id, name=None, phone=None, address=None, note=None):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT * FROM customers WHERE id=? AND user_id=? AND business_id=?", (customer_id, _uid(), _bid()))
    old = _fetch_one(cur)
    if not old:
        conn.close(); return False
    cur.execute("UPDATE customers SET name=?,phone=?,address=?,note=? WHERE id=?",
                (name or old["name"], phone or old["phone"], address or old["address"], note or old["note"], customer_id))
    conn.commit(); conn.close()
    return True


def delete_customer(customer_id):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT COUNT(*) c FROM orders WHERE customer_id=? AND user_id=? AND business_id=?", (customer_id, _uid(), _bid()))
    if cur.fetchone()["c"]:
        conn.close(); raise ValueError("این مشتری سابقه فروش دارد و قابل حذف نیست.")
    cur.execute("DELETE FROM customer_ledger WHERE customer_id=? AND user_id=? AND business_id=?", (customer_id, _uid(), _bid()))
    cur.execute("DELETE FROM payments WHERE customer_id=? AND user_id=? AND business_id=?", (customer_id, _uid(), _bid()))
    cur.execute("DELETE FROM customers WHERE id=? AND user_id=? AND business_id=?", (customer_id, _uid(), _bid()))
    conn.commit(); conn.close()


# ------------------------- CUSTOMER LEDGER -------------------------

def add_customer_debt(customer_id, amount, note=None):
    amount = float(amount)
    if amount <= 0: raise ValueError("مبلغ بدهی باید بیشتر از صفر باشد.")
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("INSERT INTO customer_ledger(user_id,business_id,customer_id,kind,amount,note) VALUES(?,?,?,'debt',?,?) RETURNING id",
                (_uid(), _bid(), customer_id, amount, note))
    lid = cur.fetchone()["id"]; conn.commit(); conn.close()
    return lid


def add_customer_payment(customer_id, amount, note=None):
    amount = float(amount)
    if amount <= 0: raise ValueError("مبلغ پرداخت باید بیشتر از صفر باشد.")
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("INSERT INTO customer_ledger(user_id,business_id,customer_id,kind,amount,note) VALUES(?,?,?,'payment',?,?) RETURNING id",
                (_uid(), _bid(), customer_id, amount, note))
    lid = cur.fetchone()["id"]; conn.commit(); conn.close()
    return lid


def get_customer_balance(customer_id):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("""SELECT COALESCE(SUM(CASE WHEN kind='debt' THEN amount ELSE -amount END),0) balance
        FROM customer_ledger WHERE customer_id=? AND user_id=? AND business_id=?""",
                (customer_id, _uid(), _bid()))
    row = cur.fetchone(); conn.close()
    return float(row["balance"] or 0)


def customer_ledger_history(customer_id, limit=50):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT * FROM customer_ledger WHERE customer_id=? AND user_id=? AND business_id=? ORDER BY id DESC LIMIT ?",
                (customer_id, _uid(), _bid(), limit))
    rows = _fetch_all(cur); conn.close()
    return rows


def delete_ledger_entry(entry_id):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("DELETE FROM customer_ledger WHERE id=? AND user_id=? AND business_id=?", (entry_id, _uid(), _bid()))
    conn.commit(); conn.close()


def list_customer_balances(min_abs=0):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("""SELECT c.id customer_id,c.name customer_name,c.phone,
        COALESCE(SUM(CASE WHEN l.kind='debt' THEN l.amount ELSE -l.amount END),0) balance,
        MAX(l.created_at) last_activity
        FROM customers c LEFT JOIN customer_ledger l ON l.customer_id=c.id AND l.user_id=? AND l.business_id=?
        WHERE c.user_id=? AND c.business_id=?
        GROUP BY c.id,c.name,c.phone HAVING ABS(COALESCE(SUM(CASE WHEN l.kind='debt' THEN l.amount ELSE -l.amount END),0))>?
        ORDER BY balance DESC""", (_uid(), _bid(), _uid(), _bid(), min_abs))
    rows = _fetch_all(cur); conn.close()
    return rows


def list_old_debts(days=30):
    cutoff = (datetime.now()-timedelta(days=days)).strftime("%Y-%m-%d %H:%M:%S")
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("""SELECT c.id customer_id,c.name customer_name,c.phone,
        COALESCE(SUM(CASE WHEN l.kind='debt' THEN l.amount ELSE -l.amount END),0) balance,
        MAX(l.created_at) last_activity
        FROM customers c JOIN customer_ledger l ON l.customer_id=c.id AND l.user_id=? AND l.business_id=?
        WHERE c.user_id=? AND c.business_id=?
        GROUP BY c.id,c.name,c.phone HAVING SUM(CASE WHEN l.kind='debt' THEN l.amount ELSE -l.amount END)>0
        AND MAX(l.created_at)<=? ORDER BY last_activity ASC""",
                (_uid(), _bid(), _uid(), _bid(), cutoff))
    rows = _fetch_all(cur); conn.close()
    return rows


def total_outstanding_debt():
    return sum(max(0, float(r["balance"])) for r in list_customer_balances(0))


# ------------------------- PRODUCTS -------------------------

def add_product(name, price=0, stock=0, note=None, cost_price=0, barcode=None, category=None, unit="عدد"):
    name = (name or "").strip()
    price = float(price or 0); stock = float(stock or 0); cost_price = float(cost_price or 0)
    if not name: raise ValueError("نام محصول الزامی است.")
    if price < 0 or stock < 0 or cost_price < 0: raise ValueError("قیمت و موجودی نمی‌توانند منفی باشند.")
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("INSERT INTO products(user_id,business_id,name,price,stock,note,cost_price,barcode,category,unit) VALUES(?,?,?,?,?,?,?,?,?,?) RETURNING id",
                (_uid(), _bid(), name, price, stock, note, cost_price, barcode, category, unit or "عدد"))
    pid = cur.fetchone()["id"]
    if stock:
        cur.execute("INSERT INTO stock_movements(user_id,business_id,product_id,product_name,movement_type,quantity,reference_type,reference_id,note) VALUES(?,?,?,?,'initial',?,'product',?,'موجودی اولیه')",
                    (_uid(), _bid(), pid, name, stock, pid))
    conn.commit(); conn.close()
    return pid


def list_products(query=None):
    conn = get_conn()
    cur = conn.cursor()
    if query:
        cur.execute("SELECT * FROM products WHERE user_id=? AND business_id=? AND (name LIKE ? OR barcode LIKE ? OR category LIKE ?) ORDER BY id DESC",
                    (_uid(), _bid(), f"%{query}%", f"%{query}%", f"%{query}%"))
    else:
        cur.execute("SELECT * FROM products WHERE user_id=? AND business_id=? ORDER BY id DESC", (_uid(), _bid()))
    rows = _fetch_all(cur); conn.close()
    return rows


def find_product_by_name(name):
    conn = get_conn()
    cur = conn.cursor()
    name_clean = (name or "").strip()
    # FIX: اول exact match روی نام، سپس barcode، سپس LIKE — جلوگیری از match اشتباه
    cur.execute("SELECT * FROM products WHERE user_id=? AND business_id=? AND name=? ORDER BY id DESC LIMIT 1",
                (_uid(), _bid(), name_clean))
    row = _fetch_one(cur)
    if not row:
        cur.execute("SELECT * FROM products WHERE user_id=? AND business_id=? AND barcode=? ORDER BY id DESC LIMIT 1",
                    (_uid(), _bid(), name_clean))
        row = _fetch_one(cur)
    if not row:
        q = f"%{name_clean}%"
        cur.execute("SELECT * FROM products WHERE user_id=? AND business_id=? AND (name LIKE ? OR barcode LIKE ? OR category LIKE ?) ORDER BY id DESC LIMIT 1",
                    (_uid(), _bid(), q, q, q))
        row = _fetch_one(cur)
    conn.close()
    return row


def update_product(product_id, name=None, price=None, cost_price=None, stock=None, note=None):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT * FROM products WHERE id=? AND user_id=? AND business_id=?", (product_id, _uid(), _bid()))
    old = _fetch_one(cur)
    if not old:
        conn.close(); return False
    old_stock = float(old["stock"] or 0)
    new_stock = old_stock if stock is None else float(stock)
    if new_stock < 0:
        conn.close(); raise ValueError("موجودی نمی‌تواند منفی باشد.")
    cur.execute("UPDATE products SET name=?,price=?,cost_price=?,stock=?,note=? WHERE id=? AND user_id=? AND business_id=?",
                (name or old["name"], float(price) if price is not None else old["price"],
                 float(cost_price) if cost_price is not None else old["cost_price"],
                 new_stock, note or old["note"], product_id, _uid(), _bid()))
    if new_stock != old_stock:
        cur.execute("INSERT INTO stock_movements(user_id,business_id,product_id,product_name,movement_type,quantity,reference_type,reference_id,note) VALUES(?,?,?,?,'adjustment',?,'manual',?,'اصلاح دستی موجودی')",
                    (_uid(), _bid(), product_id, old["name"], new_stock-old_stock, product_id))
    conn.commit(); conn.close()
    return True


def update_stock(product_id, change, movement_type="adjustment", reference_type=None, reference_id=None, note=None, conn=None):
    own = conn is None
    if own:
        conn = get_conn()
    change = float(change)
    cur = conn.cursor()
    cur.execute("SELECT id,name,stock FROM products WHERE id=? AND user_id=? AND business_id=?", (product_id, _uid(), _bid()))
    row = _fetch_one(cur)
    if not row:
        if own: conn.close()
        raise ValueError("محصول پیدا نشد.")
    new_stock = float(row["stock"] or 0) + change
    if new_stock < 0:
        if own: conn.close()
        raise ValueError(f"موجودی «{row['name']}» کافی نیست.")
    cur.execute("UPDATE products SET stock=? WHERE id=? AND user_id=? AND business_id=?", (new_stock, product_id, _uid(), _bid()))
    cur.execute("INSERT INTO stock_movements(user_id,business_id,product_id,product_name,movement_type,quantity,reference_type,reference_id,note) VALUES(?,?,?,?,?,?,?,?,?)",
                (_uid(), _bid(), product_id, row["name"], movement_type, change, reference_type, reference_id, note))
    if own:
        conn.commit(); conn.close()
    return new_stock


def delete_product(product_id):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT COUNT(*) c FROM order_items WHERE product_id=? AND user_id=? AND business_id=?", (product_id, _uid(), _bid()))
    if cur.fetchone()["c"]:
        conn.close(); raise ValueError("این محصول سابقه فروش دارد و قابل حذف نیست.")
    cur.execute("DELETE FROM stock_movements WHERE product_id=? AND user_id=? AND business_id=?", (product_id, _uid(), _bid()))
    cur.execute("DELETE FROM products WHERE id=? AND user_id=? AND business_id=?", (product_id, _uid(), _bid()))
    conn.commit(); conn.close()


def low_stock_products(threshold=5):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT * FROM products WHERE user_id=? AND business_id=? AND stock<=? ORDER BY stock ASC", (_uid(), _bid(), threshold))
    rows = _fetch_all(cur); conn.close()
    return rows


def stock_history(product_id, limit=100):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT * FROM stock_movements WHERE product_id=? AND user_id=? AND business_id=? ORDER BY id DESC LIMIT ?",
                (product_id, _uid(), _bid(), limit))
    rows = _fetch_all(cur); conn.close()
    return rows


# ------------------------- SUPPLIERS / PURCHASES -------------------------

def add_supplier(name, phone=None, note=None):
    name = (name or "").strip()
    if not name: raise ValueError("نام تأمین‌کننده الزامی است.")
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("INSERT INTO suppliers(user_id,business_id,name,phone,note) VALUES(?,?,?,?,?) RETURNING id",
                (_uid(), _bid(), name, phone, note))
    sid = cur.fetchone()["id"]; conn.commit(); conn.close()
    return sid


def list_suppliers(query=None):
    conn = get_conn()
    cur = conn.cursor()
    if query:
        cur.execute("SELECT * FROM suppliers WHERE user_id=? AND business_id=? AND name LIKE ? ORDER BY id DESC",
                    (_uid(), _bid(), f"%{query}%"))
    else:
        cur.execute("SELECT * FROM suppliers WHERE user_id=? AND business_id=? ORDER BY id DESC", (_uid(), _bid()))
    rows = _fetch_all(cur); conn.close()
    return rows


def find_supplier_by_name(name):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT * FROM suppliers WHERE user_id=? AND business_id=? AND name LIKE ? ORDER BY id DESC LIMIT 1",
                (_uid(), _bid(), f"%{(name or '').strip()}%"))
    row = _fetch_one(cur); conn.close()
    return row


def delete_supplier(supplier_id):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT COUNT(*) c FROM purchases WHERE supplier_id=? AND user_id=? AND business_id=?", (supplier_id, _uid(), _bid()))
    if cur.fetchone()["c"]:
        conn.close(); raise ValueError("این تأمین‌کننده سابقه خرید دارد و قابل حذف نیست.")
    cur.execute("DELETE FROM suppliers WHERE id=? AND user_id=? AND business_id=?", (supplier_id, _uid(), _bid()))
    conn.commit(); conn.close()


def add_purchase(supplier_id, items, note=None):
    if not items: raise ValueError("حداقل یک قلم برای خرید لازم است.")
    conn = get_conn()
    cur = conn.cursor()
    try:
        total = sum(float(i["qty"])*float(i["cost_price"]) for i in items)
        cur.execute("INSERT INTO purchases(user_id,business_id,supplier_id,total,note) VALUES(?,?,?,?,?) RETURNING id",
                    (_uid(), _bid(), supplier_id, total, note))
        purchase_id = cur.fetchone()["id"]
        for i in items:
            qty = float(i["qty"]); cost = float(i["cost_price"])
            if qty <= 0 or cost < 0: raise ValueError("تعداد/قیمت خرید نامعتبر است.")
            pid = i.get("product_id")
            if pid:
                cur.execute("SELECT stock,cost_price,name FROM products WHERE id=? AND user_id=? AND business_id=?", (pid, _uid(), _bid()))
                row = _fetch_one(cur)
                if not row: raise ValueError("محصول خرید پیدا نشد.")
                old_stock = float(row["stock"] or 0); old_cost = float(row["cost_price"] or 0)
                total_qty = old_stock + qty
                weighted = ((old_stock*old_cost)+(qty*cost))/total_qty if total_qty else cost
                cur.execute("UPDATE products SET stock=stock+?,cost_price=? WHERE id=? AND user_id=? AND business_id=?",
                            (qty, weighted, pid, _uid(), _bid()))
                cur.execute("INSERT INTO stock_movements(user_id,business_id,product_id,product_name,movement_type,quantity,reference_type,reference_id,note) VALUES(?,?,?,?,'purchase',?,'purchase',?,?)",
                            (_uid(), _bid(), pid, row["name"], qty, purchase_id, note))
            cur.execute("INSERT INTO purchase_items(user_id,business_id,purchase_id,product_id,product_name,qty,cost_price) VALUES(?,?,?,?,?,?,?)",
                        (_uid(), _bid(), purchase_id, pid, i.get("product_name"), qty, cost))
        conn.commit()
        return purchase_id, total
    except Exception as e:
        conn.rollback(); raise
    finally:
        conn.close()


def list_purchases(limit=20):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("""SELECT p.*,s.name supplier_name FROM purchases p
        LEFT JOIN suppliers s ON s.id=p.supplier_id
        WHERE p.user_id=? AND p.business_id=? ORDER BY p.id DESC LIMIT ?""",
                (_uid(), _bid(), limit))
    rows = _fetch_all(cur); conn.close()
    return rows


def purchase_items_for(purchase_id):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT * FROM purchase_items WHERE purchase_id=? AND user_id=? AND business_id=?", (purchase_id, _uid(), _bid()))
    rows = _fetch_all(cur); conn.close()
    return rows


def delete_purchase(purchase_id):
    raise ValueError("حذف خرید غیرفعال است.")


# ------------------------- ORDERS / PAYMENTS -------------------------

def add_order(customer_id, items, note=None, status="تکمیل‌شده",
              paid_amount=0, payment_method="نقدی", payment_note=None, discount=0):
    if not customer_id: raise ValueError("شناسه مشتری مشخص نیست.")
    if not items: raise ValueError("حداقل یک قلم برای فروش لازم است.")
    paid = float(paid_amount or 0); discount = float(discount or 0)
    if discount < 0: raise ValueError("تخفیف نمی‌تواند منفی باشد.")
    if paid < 0: raise ValueError("مبلغ پرداختی نمی‌تواند منفی باشد.")
    conn = get_conn()
    cur = conn.cursor()
    try:
        validated = []; total = 0.0
        for item in items:
            pid = item.get("product_id")
            qty = float(item.get("qty", 0))
            price = float(item.get("price", 0))
            cost = float(item.get("cost_price", 0) or 0)
            if qty <= 0: raise ValueError("تعداد کالا باید بیشتر از صفر باشد.")
            if price < 0 or cost < 0: raise ValueError("قیمت نمی‌تواند منفی باشد.")
            name = item.get("product_name") or ""
            if pid:
                cur.execute("SELECT id,name,stock,cost_price,price FROM products WHERE id=? AND user_id=? AND business_id=?", (pid, _uid(), _bid()))
                row = _fetch_one(cur)
                if not row: raise ValueError(f"محصول با شناسه {pid} پیدا نشد.")
                if float(row["stock"] or 0) < qty:
                    raise ValueError(f"موجودی «{row['name']}» کافی نیست.")
                name = row["name"]
                if cost <= 0: cost = float(row["cost_price"] or 0)
            elif not name:
                raise ValueError("نام محصول مشخص نیست.")
            total += qty*price
            validated.append((pid, name, qty, price, cost))
        if discount > total: raise ValueError("تخفیف نمی‌تواند از مبلغ کل فروش بیشتر باشد.")
        final_total = total - discount
        if paid > final_total: raise ValueError("مبلغ پرداختی نمی‌تواند از مبلغ نهایی فروش بیشتر باشد.")
        cur.execute("INSERT INTO orders(user_id,business_id,customer_id,total,status,note,discount) VALUES(?,?,?,?,?,?,?) RETURNING id",
                    (_uid(), _bid(), customer_id, final_total, status, note, discount))
        order_id = cur.fetchone()["id"]
        for pid, name, qty, price, cost in validated:
            cur.execute("INSERT INTO order_items(user_id,business_id,order_id,product_id,product_name,qty,price,cost_price) VALUES(?,?,?,?,?,?,?,?)",
                        (_uid(), _bid(), order_id, pid, name, qty, price, cost))
            if pid:
                cur.execute("UPDATE products SET stock=stock-? WHERE id=? AND user_id=? AND business_id=? AND stock>=?",
                            (qty, pid, _uid(), _bid(), qty))
                cur.execute("INSERT INTO stock_movements(user_id,business_id,product_id,product_name,movement_type,quantity,reference_type,reference_id,note) VALUES(?,?,?,?,'sale',?,'order',?,?)",
                            (_uid(), _bid(), pid, name, -qty, order_id, note))
        remaining = final_total - paid
        if paid > 0:
            cur.execute("INSERT INTO payments(user_id,business_id,order_id,customer_id,amount,method,note) VALUES(?,?,?,?,?,?,?)",
                        (_uid(), _bid(), order_id, customer_id, paid, payment_method or "نقدی", payment_note))
            cur.execute("INSERT INTO customer_ledger(user_id,business_id,customer_id,kind,amount,note) VALUES(?,?,?,'payment',?,?)",
                        (_uid(), _bid(), customer_id, paid, payment_note or f"پرداخت بابت فروش #{order_id}"))
        if remaining > 0:
            cur.execute("INSERT INTO customer_ledger(user_id,business_id,customer_id,kind,amount,note) VALUES(?,?,?,'debt',?,?)",
                        (_uid(), _bid(), customer_id, remaining, f"بدهی بابت فروش #{order_id}"))
        conn.commit()
        return {"order_id": order_id, "subtotal": total, "discount": discount, "total": final_total, "paid_amount": paid, "remaining": remaining}
    except Exception as e:
        conn.rollback(); raise
    finally:
        conn.close()


def list_orders(limit=20):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("""SELECT o.*,c.name customer_name,
        COALESCE((SELECT SUM(p.amount) FROM payments p WHERE p.order_id=o.id),0) paid_amount
        FROM orders o LEFT JOIN customers c ON c.id=o.customer_id
        WHERE o.user_id=? AND o.business_id=? ORDER BY o.id DESC LIMIT ?""",
                (_uid(), _bid(), limit))
    result = _fetch_all(cur); conn.close()
    for r in result:
        r["remaining"] = max(0, float(r["total"] or 0)-float(r["paid_amount"] or 0))
    return result


def order_items_for(order_id):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT * FROM order_items WHERE order_id=? AND user_id=? AND business_id=?", (order_id, _uid(), _bid()))
    rows = _fetch_all(cur); conn.close()
    return rows


def get_order_details(order_id):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("""SELECT o.*,c.name customer_name,c.phone customer_phone
        FROM orders o LEFT JOIN customers c ON c.id=o.customer_id
        WHERE o.id=? AND o.user_id=? AND o.business_id=?""", (order_id, _uid(), _bid()))
    order = _fetch_one(cur)
    if not order:
        conn.close(); return None
    cur.execute("SELECT * FROM order_items WHERE order_id=? AND user_id=? AND business_id=? ORDER BY id", (order_id, _uid(), _bid()))
    items = _fetch_all(cur)
    cur.execute("SELECT * FROM payments WHERE order_id=? AND user_id=? AND business_id=? ORDER BY id", (order_id, _uid(), _bid()))
    payments = _fetch_all(cur)
    conn.close()
    order["items"] = items; order["payments"] = payments
    order["paid_amount"] = sum(float(x["amount"] or 0) for x in payments)
    order["remaining"] = max(0, float(order["total"] or 0)-order["paid_amount"])
    return order


def add_order_payment(order_id, amount, method="نقدی", note=None):
    amount = float(amount)
    if amount <= 0: raise ValueError("مبلغ پرداخت باید بیشتر از صفر باشد.")
    conn = get_conn()
    cur = conn.cursor()
    try:
        cur.execute("SELECT id,customer_id,total,status FROM orders WHERE id=? AND user_id=? AND business_id=?", (order_id, _uid(), _bid()))
        order = _fetch_one(cur)
        if not order: raise ValueError("سفارش پیدا نشد.")
        cur.execute("SELECT COALESCE(SUM(amount),0) x FROM payments WHERE order_id=? AND user_id=? AND business_id=?", (order_id, _uid(), _bid()))
        paid = float(cur.fetchone()["x"] or 0)
        remaining = float(order["total"])-paid
        if amount > remaining: raise ValueError("پرداخت بیشتر از مانده سفارش است.")
        cur.execute("INSERT INTO payments(user_id,business_id,order_id,customer_id,amount,method,note) VALUES(?,?,?,?,?,?,?)",
                    (_uid(), _bid(), order_id, order["customer_id"], amount, method or "نقدی", note))
        cur.execute("INSERT INTO customer_ledger(user_id,business_id,customer_id,kind,amount,note) VALUES(?,?,?,'payment',?,?)",
                    (_uid(), _bid(), order["customer_id"], amount, note or f"پرداخت بابت فروش #{order_id}"))
        conn.commit()
        return {"order_id": order_id, "paid_amount": paid+amount, "remaining": remaining-amount}
    except Exception as e:
        conn.rollback(); raise
    finally:
        conn.close()


def cancel_order(order_id, reason=None):
    conn = get_conn()
    cur = conn.cursor()
    try:
        cur.execute("SELECT * FROM orders WHERE id=? AND user_id=? AND business_id=?", (order_id, _uid(), _bid()))
        order = _fetch_one(cur)
        if not order: raise ValueError("سفارش پیدا نشد.")
        if order["status"] == "لغوشده": raise ValueError("این سفارش قبلاً لغو شده است.")
        cur.execute("SELECT * FROM order_items WHERE order_id=? AND user_id=? AND business_id=?", (order_id, _uid(), _bid()))
        items = _fetch_all(cur)
        for item in items:
            if item["product_id"]:
                cur.execute("UPDATE products SET stock=stock+? WHERE id=? AND user_id=? AND business_id=?",
                            (item["qty"], item["product_id"], _uid(), _bid()))
                cur.execute("INSERT INTO stock_movements(user_id,business_id,product_id,product_name,movement_type,quantity,reference_type,reference_id,note) VALUES(?,?,?,?,'sale_return',?,'order_cancel',?,?)",
                            (_uid(), _bid(), item["product_id"], item["product_name"], item["qty"], order_id, reason or "لغو فروش"))
        debt_note = f"بدهی بابت فروش #{order_id}"
        cur.execute("SELECT id,amount FROM customer_ledger WHERE customer_id=? AND user_id=? AND business_id=? AND kind='debt' AND note=?",
                    (order["customer_id"], _uid(), _bid(), debt_note))
        debt_rows = _fetch_all(cur)
        for row in debt_rows:
            cur.execute("INSERT INTO customer_ledger(user_id,business_id,customer_id,kind,amount,note) VALUES(?,?,?,'payment',?,?)",
                        (_uid(), _bid(), order["customer_id"], row["amount"], f"برگشت بدهی فروش #{order_id}"))
        cur.execute("SELECT amount FROM payments WHERE order_id=? AND user_id=? AND business_id=?", (order_id, _uid(), _bid()))
        payment_rows = _fetch_all(cur)
        for row in payment_rows:
            cur.execute("INSERT INTO customer_ledger(user_id,business_id,customer_id,kind,amount,note) VALUES(?,?,?,'debt',?,?)",
                        (_uid(), _bid(), order["customer_id"], row["amount"], f"برگشت پرداخت فروش #{order_id} (لغو)"))
        cur.execute("UPDATE orders SET status='لغوشده' WHERE id=? AND user_id=? AND business_id=?", (order_id, _uid(), _bid()))
        conn.commit()
        return True
    except Exception as e:
        conn.rollback(); raise
    finally:
        conn.close()


def delete_order(order_id):
    raise ValueError("حذف مستقیم فروش غیرفعال است؛ از «لغو فروش» استفاده کنید.")


# ------------------------- TRANSACTIONS -------------------------

def add_transaction(title, amount, kind, category=None):
    if kind not in ("income", "expense"): raise ValueError("نوع تراکنش نامعتبر است.")
    amount = float(amount)
    if amount <= 0: raise ValueError("مبلغ باید بیشتر از صفر باشد.")
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("INSERT INTO transactions(user_id,business_id,title,amount,kind,category) VALUES(?,?,?,?,?,?) RETURNING id",
                (_uid(), _bid(), title, amount, kind, category))
    tid = cur.fetchone()["id"]; conn.commit(); conn.close()
    return tid


def list_transactions(limit=50):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT * FROM transactions WHERE user_id=? AND business_id=? ORDER BY id DESC LIMIT ?", (_uid(), _bid(), limit))
    rows = _fetch_all(cur); conn.close()
    return rows


def delete_transaction(t_id):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("DELETE FROM transactions WHERE id=? AND user_id=? AND business_id=?", (t_id, _uid(), _bid()))
    conn.commit(); conn.close()


# ------------------------- TASKS -------------------------

def add_task(title, due_date=None):
    if not (title or "").strip(): raise ValueError("عنوان وظیفه الزامی است.")
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("INSERT INTO tasks(user_id,business_id,title,due_date) VALUES(?,?,?,?) RETURNING id",
                (_uid(), _bid(), title.strip(), due_date))
    tid = cur.fetchone()["id"]; conn.commit(); conn.close()
    return tid


def list_tasks(only_open=False):
    conn = get_conn()
    cur = conn.cursor()
    if only_open:
        cur.execute("SELECT * FROM tasks WHERE user_id=? AND business_id=? AND done=0 ORDER BY id DESC", (_uid(), _bid()))
    else:
        cur.execute("SELECT * FROM tasks WHERE user_id=? AND business_id=? ORDER BY id DESC", (_uid(), _bid()))
    rows = _fetch_all(cur); conn.close()
    return rows


def set_task_done(task_id, done=True):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("UPDATE tasks SET done=? WHERE id=? AND user_id=? AND business_id=?", (1 if done else 0, task_id, _uid(), _bid()))
    conn.commit(); conn.close()


def delete_task(task_id):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("DELETE FROM tasks WHERE id=? AND user_id=? AND business_id=?", (task_id, _uid(), _bid()))
    conn.commit(); conn.close()


# ------------------------- REPORTS -------------------------

def _cogs_since(since_iso):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("""SELECT COALESCE(SUM(oi.qty*oi.cost_price),0) total
        FROM order_items oi JOIN orders o ON o.id=oi.order_id
        WHERE o.user_id=? AND o.business_id=? AND o.created_at>=? AND o.status!='لغوشده'""",
                (_uid(), _bid(), since_iso))
    row = cur.fetchone(); conn.close()
    return float(row["total"] or 0)


def product_profit_report(days=30, limit=10):
    since = (datetime.now()-timedelta(days=days)).strftime("%Y-%m-%d %H:%M:%S")
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("""SELECT oi.product_name,SUM(oi.qty) qty_sold,
        SUM(oi.qty*oi.price) revenue,SUM(oi.qty*oi.cost_price) cost,
        SUM(oi.qty*(oi.price-oi.cost_price)) profit
        FROM order_items oi JOIN orders o ON o.id=oi.order_id
        WHERE o.user_id=? AND o.business_id=? AND o.created_at>=? AND o.status!='لغوشده'
        GROUP BY oi.product_name ORDER BY profit DESC LIMIT ?""",
                (_uid(), _bid(), since, limit))
    rows = _fetch_all(cur); conn.close()
    return rows


def get_summary():
    now = datetime.now()
    today = now.strftime("%Y-%m-%d 00:00:00")
    week = (now-timedelta(days=7)).strftime("%Y-%m-%d %H:%M:%S")
    month = (now-timedelta(days=30)).strftime("%Y-%m-%d %H:%M:%S")
    conn = get_conn()
    cur = conn.cursor()
    def s(sql, args):
        cur.execute(sql, args)
        return float(cur.fetchone()["x"] or 0)
    sales_today = s("SELECT COALESCE(SUM(total),0) x FROM orders WHERE user_id=? AND business_id=? AND created_at>=? AND status!='لغوشده'", (_uid(), _bid(), today))
    sales_week = s("SELECT COALESCE(SUM(total),0) x FROM orders WHERE user_id=? AND business_id=? AND created_at>=? AND status!='لغوشده'", (_uid(), _bid(), week))
    sales_month = s("SELECT COALESCE(SUM(total),0) x FROM orders WHERE user_id=? AND business_id=? AND created_at>=? AND status!='لغوشده'", (_uid(), _bid(), month))
    income = s("SELECT COALESCE(SUM(amount),0) x FROM transactions WHERE user_id=? AND business_id=? AND created_at>=? AND kind='income'", (_uid(), _bid(), month))
    expense = s("SELECT COALESCE(SUM(amount),0) x FROM transactions WHERE user_id=? AND business_id=? AND created_at>=? AND kind='expense'", (_uid(), _bid(), month))
    cur.execute("SELECT COUNT(*) c FROM customers WHERE user_id=? AND business_id=?", (_uid(), _bid()))
    customers_count = cur.fetchone()["c"]
    cur.execute("SELECT COUNT(*) c FROM products WHERE user_id=? AND business_id=?", (_uid(), _bid()))
    products_count = cur.fetchone()["c"]
    cur.execute("SELECT COUNT(*) c FROM orders WHERE user_id=? AND business_id=? AND status!='لغوشده'", (_uid(), _bid()))
    orders_count = cur.fetchone()["c"]
    trend = []
    for i in range(6, -1, -1):
        d = (now-timedelta(days=i)).strftime("%Y-%m-%d")
        cur.execute("SELECT COALESCE(SUM(total),0) x FROM orders WHERE user_id=? AND business_id=? AND DATE(created_at)=? AND status!='لغوشده'", (_uid(), _bid(), d))
        trend.append({"date": d, "total": float(cur.fetchone()["x"] or 0)})
    conn.close()
    cogs = _cogs_since(month)
    debtors = [r for r in list_customer_balances(0) if r["balance"] > 0]
    open_tasks = list_tasks(True)
    old = list_old_debts(30)
    return {
        "sales_today": sales_today, "sales_week": sales_week, "sales_month": sales_month,
        "income_month": income, "expense_month": expense, "cogs_month": cogs,
        "profit_month": sales_month-cogs+income-expense,
        "top_products_month": product_profit_report(30, 5),
        "low_stock": low_stock_products(5), "open_tasks_count": len(open_tasks),
        "open_tasks": open_tasks[:5], "customers_count": customers_count,
        "products_count": products_count, "orders_count": orders_count,
        "trend_7d": trend, "total_debt": total_outstanding_debt(),
        "debtors_count": len(debtors), "top_debtors": debtors[:5],
        "old_debts_count": len(old), "old_debts": old[:5]
    }


def customer_purchase_report(days=30, limit=10):
    days = max(1, int(days or 30)); limit = max(1, min(int(limit or 10), 100))
    since = (datetime.now()-timedelta(days=days)).strftime("%Y-%m-%d %H:%M:%S")
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("""SELECT c.id customer_id,c.name customer_name,
        COUNT(o.id) orders_count,COALESCE(SUM(o.total),0) total_spent,MAX(o.created_at) last_purchase
        FROM customers c JOIN orders o ON o.customer_id=c.id
        WHERE c.user_id=? AND c.business_id=? AND o.status!='لغوشده' AND o.created_at>=?
        GROUP BY c.id,c.name ORDER BY total_spent DESC LIMIT ?""",
                (_uid(), _bid(), since, limit))
    rows = _fetch_all(cur); conn.close()
    return rows


def payment_method_report(days=30):
    days = max(1, int(days or 30))
    since = (datetime.now()-timedelta(days=days)).strftime("%Y-%m-%d %H:%M:%S")
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("""SELECT p.method,COALESCE(SUM(p.amount),0) total,COUNT(*) count
        FROM payments p JOIN orders o ON o.id=p.order_id
        WHERE p.user_id=? AND p.business_id=? AND o.status!='لغوشده' AND p.created_at>=?
        GROUP BY p.method ORDER BY total DESC""", (_uid(), _bid(), since))
    rows = _fetch_all(cur); conn.close()
    return rows


def sales_stats(days=30):
    days = max(1, int(days or 30))
    since = (datetime.now()-timedelta(days=days)).strftime("%Y-%m-%d %H:%M:%S")
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("""SELECT COUNT(*) orders_count,COALESCE(SUM(total),0) sales,
        COALESCE(SUM(discount),0) discounts,COALESCE(AVG(total),0) average_order
        FROM orders WHERE user_id=? AND business_id=? AND status!='لغوشده' AND created_at>=?""",
                (_uid(), _bid(), since))
    row = _fetch_one(cur); conn.close()
    return row


# ------------------------- LIMITS -------------------------

def count_user_records(table: str) -> int:
    """Return how many rows the current user+business has in `table`."""
    allowed = {"customers", "products", "orders", "transactions", "tasks"}
    if table not in allowed:
        return 0
    conn = get_conn()
    cur = conn.cursor()
    cur.execute(f"SELECT COUNT(*) c FROM {table} WHERE user_id=? AND business_id=?", (_uid(), _bid()))
    n = cur.fetchone()["c"]
    conn.close()
    return int(n)


# ------------------------- USERS -------------------------

def user_count():
    conn = get_master_conn()
    cur = conn.cursor()
    cur.execute("SELECT COUNT(*) c FROM users")
    n = cur.fetchone()["c"]; conn.close()
    return n


def add_user(username, password_hash, phone=None, first_name=None, last_name=None):
    conn = get_master_conn()
    cur = conn.cursor()
    cur.execute("INSERT INTO users(username,password_hash,phone,first_name,last_name) VALUES(?,?,?,?,?) RETURNING id",
                (username, password_hash, phone, first_name, last_name))
    uid = cur.fetchone()["id"]; conn.commit(); conn.close()
    return uid


def get_user_by_username(username):
    conn = get_master_conn()
    cur = conn.cursor()
    cur.execute("SELECT * FROM users WHERE username=?", (username,))
    row = _fetch_one(cur); conn.close()
    return row


def get_user_by_phone(phone):
    conn = get_master_conn()
    cur = conn.cursor()
    cur.execute("SELECT * FROM users WHERE phone=?", (phone,))
    row = _fetch_one(cur); conn.close()
    return row


def create_auth_otp(phone, code_hash, expires_at, created_at):
    conn = get_master_conn()
    cur = conn.cursor()
    cur.execute("UPDATE auth_otps SET used=1 WHERE phone=? AND used=0", (phone,))
    cur.execute("INSERT INTO auth_otps(phone,code_hash,expires_at,created_at) VALUES(?,?,?,?) RETURNING id",
                (phone, code_hash, int(expires_at), int(created_at)))
    oid = cur.fetchone()["id"]; conn.commit(); conn.close()
    return oid


def get_latest_auth_otp(phone):
    conn = get_master_conn()
    cur = conn.cursor()
    cur.execute("SELECT * FROM auth_otps WHERE phone=? AND used=0 ORDER BY id DESC LIMIT 1", (phone,))
    row = _fetch_one(cur); conn.close()
    return row


def update_auth_otp_attempts(otp_id, attempts):
    conn = get_master_conn()
    cur = conn.cursor()
    cur.execute("UPDATE auth_otps SET attempts=? WHERE id=?", (int(attempts), int(otp_id)))
    conn.commit(); conn.close()


def consume_auth_otp(otp_id):
    conn = get_master_conn()
    cur = conn.cursor()
    cur.execute("UPDATE auth_otps SET used=1 WHERE id=?", (int(otp_id),))
    conn.commit(); conn.close()


def count_recent_auth_otps(phone, since_ts):
    conn = get_master_conn()
    cur = conn.cursor()
    cur.execute("SELECT COUNT(*) c FROM auth_otps WHERE phone=? AND created_at>=?", (phone, int(since_ts)))
    n = cur.fetchone()["c"]; conn.close()
    return int(n)


def create_phone_user(phone, first_name, last_name, password_hash):
    username = "user_" + phone.replace("+", "")
    conn = get_master_conn()
    cur = conn.cursor()
    cur.execute("INSERT INTO users(username,password_hash,phone,first_name,last_name) VALUES(?,?,?,?,?) RETURNING id",
                (username, password_hash, phone, first_name, last_name))
    uid = cur.fetchone()["id"]; conn.commit(); conn.close()
    return uid


# ------------------------- NOTIFICATIONS -------------------------

def create_notification(kind, title, body):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("INSERT INTO notifications(user_id,business_id,kind,title,body) VALUES(?,?,?,?,?) RETURNING id",
                (_uid(), _bid(), kind, title, body))
    nid = cur.fetchone()["id"]; conn.commit(); conn.close()
    return nid


def list_notifications(unread_only=False, limit=50):
    conn = get_conn()
    cur = conn.cursor()
    q = "SELECT * FROM notifications WHERE user_id=? AND business_id=?"
    args = [_uid(), _bid()]
    if unread_only:
        q += " AND is_read=0"
    q += " ORDER BY id DESC LIMIT ?"
    args.append(max(1, min(int(limit or 50), 200)))
    cur.execute(q, args)
    rows = _fetch_all(cur); conn.close()
    return rows


def mark_notification_read(notification_id):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("UPDATE notifications SET is_read=1 WHERE id=? AND user_id=? AND business_id=?", (notification_id, _uid(), _bid()))
    conn.commit(); conn.close()


def generate_notifications():
    created = []
    for p in low_stock_products(5):
        title = f"موجودی کم: {p['name']}"
        existing = list_notifications(False, 200)
        if not any(x["kind"]=="low_stock" and x["title"]==title and x["is_read"]==0 for x in existing):
            created.append(create_notification("low_stock", title, f"موجودی فعلی: {p['stock']} {p.get('unit') or 'عدد'}"))
    for d in list_old_debts(30):
        title = f"بدهی قدیمی: {d['customer_name']}"
        existing = list_notifications(False, 200)
        if not any(x["kind"]=="old_debt" and x["title"]==title and x["is_read"]==0 for x in existing):
            created.append(create_notification("old_debt", title, f"مانده بدهی: {d['balance']}"))
    return created


# ------------------------- MULTI BUSINESS -------------------------

def ensure_user_db(user_id, business_id=1):
    pass  # No file-based DBs in PostgreSQL mode


def ensure_default_business(user_id):
    conn = get_master_conn()
    cur = conn.cursor()
    cur.execute("SELECT id FROM businesses WHERE user_id=? ORDER BY id LIMIT 1", (user_id,))
    row = _fetch_one(cur)
    if row:
        conn.close(); return int(row["id"])
    cur.execute("INSERT INTO businesses(user_id,name) VALUES(?,'کسب‌وکار اصلی') RETURNING id", (user_id,))
    bid = cur.fetchone()["id"]; conn.commit(); conn.close()
    return bid


def list_businesses(user_id):
    conn = get_master_conn()
    cur = conn.cursor()
    cur.execute("SELECT id,name,created_at FROM businesses WHERE user_id=? ORDER BY id", (user_id,))
    rows = _fetch_all(cur); conn.close()
    return rows


def create_business(user_id, name):
    name = (name or "").strip()
    if not name: raise ValueError("نام کسب‌وکار الزامی است.")
    conn = get_master_conn()
    cur = conn.cursor()
    cur.execute("INSERT INTO businesses(user_id,name) VALUES(?,?) RETURNING id", (user_id, name))
    bid = cur.fetchone()["id"]; conn.commit(); conn.close()
    return {"id": bid, "name": name}


def valid_business(user_id, business_id):
    conn = get_master_conn()
    cur = conn.cursor()
    cur.execute("SELECT id,name FROM businesses WHERE id=? AND user_id=?", (business_id, user_id))
    row = _fetch_one(cur); conn.close()
    return row


# ------------------------- API KEYS -------------------------

def create_api_key(user_id, name):
    raw = "dijo_" + secrets.token_urlsafe(32)
    h = hashlib.sha256(raw.encode()).hexdigest()
    conn = get_master_conn()
    cur = conn.cursor()
    cur.execute("INSERT INTO api_keys(user_id,name,key_hash) VALUES(?,?,?) RETURNING id", (user_id, name or "API Key", h))
    kid = cur.fetchone()["id"]; conn.commit(); conn.close()
    return {"id": kid, "name": name or "API Key", "key": raw}


def get_user_by_api_key(raw):
    if not raw: return None
    h = hashlib.sha256(raw.encode()).hexdigest()
    conn = get_master_conn()
    cur = conn.cursor()
    cur.execute("SELECT * FROM api_keys WHERE key_hash=?", (h,))
    row = _fetch_one(cur)
    if row:
        # FIX: از همان cursor استفاده می‌کنیم تا resource leak نداشته باشیم
        cur.execute("UPDATE api_keys SET last_used_at=CURRENT_TIMESTAMP WHERE id=?", (row["id"],))
        conn.commit()
    conn.close()
    return row


# ------------------------- CHAT PERSISTENCE -------------------------

def load_chat_history(session_id, limit=24):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT role,content FROM chat_messages WHERE user_id=? AND business_id=? AND session_id=? ORDER BY id DESC LIMIT ?",
                (_uid(), _bid(), session_id, limit))
    rows = _fetch_all(cur); conn.close()
    return list(reversed(rows))


def save_chat_message(session_id, role, content):
    if role not in ("user", "assistant", "system", "tool"): return
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("INSERT INTO chat_messages(user_id,business_id,session_id,role,content) VALUES(?,?,?,?,?)",
                (_uid(), _bid(), session_id, role, str(content)))
    conn.commit(); conn.close()


def list_chat_sessions(limit=30):
    """Return recent chat sessions for the current user/business."""
    try:
        limit = max(1, min(int(limit or 30), 100))
    except (TypeError, ValueError):
        limit = 30
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("""
        SELECT session_id, MIN(id) AS first_id, MAX(id) AS last_id,
               MAX(created_at) AS last_at, COUNT(*) AS message_count,
               (SELECT content FROM chat_messages m2
                WHERE m2.user_id=cm.user_id AND m2.business_id=cm.business_id
                  AND m2.session_id=cm.session_id AND m2.role='user'
                ORDER BY m2.id ASC LIMIT 1) AS title
        FROM chat_messages cm
        WHERE user_id=? AND business_id=?
        GROUP BY session_id
        ORDER BY last_id DESC
        LIMIT ?
    """, (_uid(), _bid(), limit))
    rows = _fetch_all(cur)
    conn.close()
    return rows


def load_chat_messages(session_id, limit=100):
    """Load persisted messages including timestamps for displaying a conversation."""
    try:
        limit = max(1, min(int(limit or 100), 200))
    except (TypeError, ValueError):
        limit = 100
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("""
        SELECT role, content, created_at
        FROM chat_messages
        WHERE user_id=? AND business_id=? AND session_id=?
        ORDER BY id ASC
        LIMIT ?
    """, (_uid(), _bid(), session_id, limit))
    rows = _fetch_all(cur)
    conn.close()
    return rows


def clear_chat_history(session_id):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("DELETE FROM chat_messages WHERE user_id=? AND business_id=? AND session_id=?", (_uid(), _bid(), session_id))
    conn.commit(); conn.close()


# FIX: init_db() از server.py صدا زده می‌شه — این صدا زدن تکراری حذف شد
