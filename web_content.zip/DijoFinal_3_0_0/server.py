from flask import Flask, request, jsonify, send_from_directory, send_file, session as flask_session
from openai import OpenAI
from werkzeug.security import generate_password_hash, check_password_hash
from config import GROQ_API_KEY
from datetime import datetime
import os, uuid, re, json, secrets, time, logging, csv, io, hashlib, urllib.parse, urllib.request
from logging.handlers import RotatingFileHandler
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
try:
    from flask_cors import CORS
except ImportError:
    CORS = None
import database as db

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger("dijo")
_file_handler = RotatingFileHandler(os.path.join(os.path.dirname(os.path.abspath(__file__)), "dijo.log"), maxBytes=2_000_000, backupCount=5, encoding="utf-8")
_file_handler.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(name)s: %(message)s"))
logger.addHandler(_file_handler)

app = Flask(__name__)
if CORS:
    _cors_raw = os.getenv("DIJO_CORS_ORIGINS", "").strip()
    _cors_origins = [x.strip() for x in _cors_raw.split(",") if x.strip()] if _cors_raw else []
    if _cors_origins:
        CORS(app, origins=_cors_origins, supports_credentials=True)
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
STATIC_DIR = os.path.join(BASE_DIR, "static")
os.makedirs(STATIC_DIR, exist_ok=True)

# Serve the single-page Dijo interface. Keep /dijo compatible with the
# original local URL used by the Android/Pydroid setup.
@app.route("/")
@app.route("/dijo")
def dijo_page():
    response = send_from_directory(BASE_DIR, "dijo.html")
    response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
    response.headers["Pragma"] = "no-cache"
    response.headers["Expires"] = "0"
    return response

@app.route("/manifest.json")
def pwa_manifest():
    return send_from_directory(BASE_DIR, "manifest.json",
                               mimetype="application/manifest+json")

@app.route("/sw.js")
def pwa_sw():
    r = send_from_directory(BASE_DIR, "sw.js",
                            mimetype="application/javascript")
    r.headers["Service-Worker-Allowed"] = "/"
    r.headers["Cache-Control"] = "no-cache"
    return r

@app.route("/static/<path:filename>")
def pwa_static(filename):
    return send_from_directory(STATIC_DIR, filename)

_SK_PATH = os.path.join(BASE_DIR, "secret.key")
ENV_SECRET = os.getenv("DIJO_SECRET_KEY")
if ENV_SECRET:
    app.secret_key = ENV_SECRET
elif os.path.exists(_SK_PATH):
    with open(_SK_PATH, "r", encoding="utf-8") as f:
        app.secret_key = f.read().strip()
else:
    app.secret_key = secrets.token_hex(32)
    with open(_SK_PATH, "w", encoding="utf-8") as f:
        f.write(app.secret_key)

app.config.update(
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SECURE=os.getenv("DIJO_HTTPS", "0") == "1",
    SESSION_COOKIE_SAMESITE="Lax",
    PERMANENT_SESSION_LIFETIME=60 * 60 * 24 * 30
)

db.init_db()

_PUBLIC = {"/", "/dijo", "/manifest.json", "/sw.js", "/status", "/api/v1/health", "/auth/login", "/auth/register", "/auth/status", "/auth/request-otp", "/auth/verify-otp", "/auth/complete-profile"}
_RATE={}; RATE_WINDOW=60; RATE_LIMIT=30
def _rate_limited():
    key=request.remote_addr or "unknown"
    now=time.time(); bucket=_RATE.setdefault(key,[])
    _RATE[key]=[t for t in bucket if now-t<RATE_WINDOW]
    if len(_RATE[key])>=RATE_LIMIT: return True
    _RATE[key].append(now); return False


@app.before_request
def _require_auth():
    if request.path.startswith("/static/"):
        return None
    if _rate_limited():
        return jsonify({"error":True,"message":"تعداد درخواست‌ها زیاد است؛ کمی بعد دوباره امتحان کنید."}),429
    if request.path in _PUBLIC:
        return None
    uid = flask_session.get("user_id")
    if not uid:
        api_key=request.headers.get("X-Dijo-API-Key") or request.args.get("api_key")
        ak=db.get_user_by_api_key(api_key)
        if ak:
            uid=ak["user_id"]
            flask_session["user_id"]=uid
            flask_session["username"]=flask_session.get("username","")
        else:
            logger.warning("Unauthorized access attempt: %s %s", request.method, request.path)
            return jsonify({"error": True, "code": 401, "message": "لطفاً ابتدا وارد شوید.", "login_required": True}), 401
    try:
        bid=flask_session.get("business_id") or db.ensure_default_business(uid)
        if not db.valid_business(uid,bid):
            bid=db.ensure_default_business(uid)
        flask_session["business_id"]=bid
        db.set_current_user(uid,bid)
    except ValueError as e:
        logger.error("Invalid user_id in session: %s — %s", uid, e)
        flask_session.clear()
        return jsonify({"error": True, "code": 401, "message": "نشست نامعتبر است. لطفاً دوباره وارد شوید.", "login_required": True}), 401


@app.teardown_request
def _clear_tenant(exc=None):
    # بعد از هر درخواست، وضعیت "کاربر فعلی" پاک می‌شود تا در سرورهای
    # threaded یا با ری‌یوز شدن ترد بین درخواست‌های کاربران مختلف،
    # هیچ نشتی‌ای بین داده‌ی دو کسب‌وکار پیش نیاید.
    db.clear_current_user()


client = OpenAI(
    api_key=GROQ_API_KEY or "not-configured",
    base_url="https://api.groq.com/openai/v1",
    timeout=90.0,
    max_retries=0
)

NORMAL_MODELS = ["openai/gpt-oss-120b", "openai/gpt-oss-20b"]
WEB_MODEL = "groq/compound-mini"

def _extract_retry_seconds(error_text, default=6.0):
    m = re.search(r"try again in ([\d.]+)s", error_text)
    if m:
        try:
            return min(float(m.group(1)) + 1.0, 30.0)
        except ValueError:
            pass
    return default

def create_completion(model, **kwargs):
    try:
        return client.chat.completions.create(model=model, **kwargs)
    except Exception as error:
        msg = str(error)
        if "rate_limit_exceeded" in msg or "429" in msg:
            time.sleep(_extract_retry_seconds(msg))
            return client.chat.completions.create(model=model, **kwargs)
        raise


SYSTEM_PROMPT = """
تو «دیجو» هستی؛ دستیار هوشمند فارسی‌زبان مدیریت کسب‌وکار.
به پایگاه‌داده واقعی مشتریان، محصولات، فروش، پرداخت‌ها، بدهی‌ها، خریدها،
هزینه‌ها، درآمدها و وظایف متصل هستی.

قوانین:
1. همیشه فارسی و طبیعی صحبت کن مگر کاربر زبان دیگری بخواهد.
2. برای ثبت/ویرایش/حذف اطلاعات کسب‌وکار حتماً از ابزار واقعی استفاده کن.
3. برای فروش از add_order استفاده کن. اگر کاربر مبلغ پرداختی همان فروش را گفت،
   paid_amount و payment_method را هم بفرست.
4. هیچ عددی را از خودت نساز؛ گزارش‌ها را از ابزار بخوان.
5. اگر موجودی کافی نباشد، فروش را ثبت نکن.
6. بعد از موفقیت ابزار، نتیجه را کوتاه و دقیق بگو.
7. برای پرداخت بدهی قبلی از add_customer_payment استفاده کن.
8. برای فروش نسیه یا مانده فروش از add_order استفاده کن، نه ثبت بدهی جداگانه.
9. اگر قیمت محصول جدید مشخص نیست، از کاربر بپرس یا طبق ابزار جستجوی قیمت عمل کن.
10. لحن دوستانه، حرفه‌ای و مختصر باشد.
11. برای گزارش مشتریان، روش‌های پرداخت و آمار فروش از ابزارهای گزارش استفاده کن.
12. هنگام ثبت فروش اگر کاربر تخفیف گفت، discount را دقیق ثبت کن؛ مبلغ نهایی پس از تخفیف را مبنا قرار بده.
13. برای محصول می‌توان بارکد، دسته‌بندی و واحد ثبت کرد.
11. اگر پیام کوتاه و ادامه پیام قبلی است، از context مکالمه استفاده کن و مجبور نکن کاربر اطلاعات تکراری را بگوید.
12. اعداد فارسی و گفتاری را دقیق تفسیر کن؛ هرگز عدد یا مبلغی را حدس نزن.
13. عبارت‌های گفتاری مثل «دادم»، «برد»، «فروختم»، «کارت کشید»، «نقد داد» را بر اساس context کسب‌وکار تفسیر کن.
14. اگر برای اجرای یک عملیات اطلاعات ضروری کم است، فقط همان اطلاعات لازم را سؤال کن.
15. برای عملیات مالی واضح که کاربر صریحاً درخواست کرده، مستقیم اجرا کن؛ فقط در صورت ابهام سؤال بپرس.
16. اگر کاربر چند پیام پشت سر هم برای تکمیل یک فروش می‌دهد، اطلاعات پیام‌های قبلی را نگه دار و در پیام بعدی تکمیل کن.
17. وقتی مبلغ با «تومن/تومان/ریال» گفته شد، واحد را حفظ کن و تبدیل ریال به تومان را فقط وقتی صریحاً لازم است انجام بده.
18. پاسخ بعد از ثبت فروش شامل مشتری، اقلام، جمع، پرداخت و مانده باشد.
22. برای هشدارهای موجودی و بدهی از list_notifications استفاده کن.
23. برای قیمت پیشنهادی از suggest_price استفاده کن و فرضیات را شفاف بگو.
19. برای «چقدر فروختم/سودم/بدهکارها/موجودی کم» از ابزارهای واقعی استفاده کن، نه حدس.
20. اگر کاربر گفت «آره/بله/درسته» و پیام قبلی یک سؤال تأییدی بود، همان عملیات را ادامه بده.
21. اگر پیام با برچسب «پیام صوتیِ تبدیل‌شده» رسید، احتمال خطای گفتاری را در نظر بگیر ولی هیچ عدد، نام یا محصولی را حدس نزن؛ در ابهام فقط همان بخش را بپرس.
"""

WEB_SYSTEM_EXTRA = """
برای این درخواست اطلاعات به‌روز وب لازم است. اگر جستجوی وب انجام شد،
نتیجه را فارسی، کوتاه و با ذکر تاریخ/منبع در صورت امکان ارائه کن.
"""

# ------------------------- AI TOOLS -------------------------

def _resolve_customer(name):
    name=(name or "").strip()
    if not name: raise ValueError("نام مشتری مشخص نیست.")
    c=db.find_customer_by_name(name)
    if c: return c["id"], c["name"]
    return db.add_customer(name), name

def tool_add_customer(args):
    return {"ok":True,"customer_id":db.add_customer(args.get("name"),args.get("phone"),args.get("address"),args.get("note"))}

def tool_list_customers(args):
    return {"customers":db.list_customers(args.get("query"))}

def tool_add_product(args):
    return {"ok":True,"product_id":db.add_product(args.get("name"),args.get("price",0),args.get("stock",0),args.get("note"),args.get("cost_price",0),args.get("barcode"),args.get("category"),args.get("unit","عدد"))}

def tool_list_products(args):
    return {"products":db.list_products(args.get("query"))}

def tool_add_order(args):
    cid,cname=_resolve_customer(args.get("customer_name"))
    resolved=[]
    missing=[]
    for item in args.get("items",[]):
        name=(item.get("product_name") or "").strip()
        if not name: continue
        product=db.find_product_by_name(name)
        price=item.get("price")
        if product:
            if price is None: price=product["price"]
            resolved.append({
                "product_id":product["id"],"product_name":product["name"],
                "qty":item.get("qty",1),"price":price,
                "cost_price":product.get("cost_price",0)
            })
        elif price is not None:
            resolved.append({"product_id":None,"product_name":name,"qty":item.get("qty",1),"price":price,"cost_price":0})
        else:
            missing.append(name)
    if missing:
        return {"ok":False,"error":"قیمت این محصولات مشخص نیست: "+", ".join(missing)}
    if not resolved:
        return {"ok":False,"error":"هیچ قلمی برای فروش مشخص نشد."}
    result=db.add_order(
        cid,resolved,
        note=args.get("note"),
        paid_amount=args.get("paid_amount",0),
        payment_method=args.get("payment_method","نقدی"),
        payment_note=args.get("payment_note"),
        discount=args.get("discount",0)
    )
    result["customer_name"]=cname
    return {"ok":True,**result}

def tool_list_orders(args):
    return {"orders":db.list_orders(args.get("limit",10))}

def tool_add_transaction(args):
    return {"ok":True,"transaction_id":db.add_transaction(args.get("title"),args.get("amount"),args.get("kind"),args.get("category"))}

def tool_add_task(args):
    return {"ok":True,"task_id":db.add_task(args.get("title"),args.get("due_date"))}

def tool_list_tasks(args):
    return {"tasks":db.list_tasks(args.get("only_open",False))}

def tool_complete_task(args):
    title = (args.get("title") or "").strip()
    if not title:
        return {"ok": False, "error": "عنوان وظیفه مشخص نیست."}
    tasks = db.list_tasks(True)
    # FIX: ابتدا exact match، سپس substring — اگر چند نتیجه substring بود، خطا برمی‌گردد
    exact = [x for x in tasks if x["title"].strip() == title]
    if exact:
        m = exact[0]
    else:
        partial = [x for x in tasks if title in x["title"]]
        if not partial:
            return {"ok": False, "error": "وظیفه‌ای با این عنوان پیدا نشد."}
        if len(partial) > 1:
            names = ", ".join(f'«{x["title"]}»' for x in partial)
            return {"ok": False, "error": f"چند وظیفه با این عنوان وجود دارد: {names}. عنوان دقیق‌تری بگو."}
        m = partial[0]
    db.set_task_done(m["id"], True)
    return {"ok": True, "task_id": m["id"], "task_title": m["title"]}

def tool_get_summary(args):
    return db.get_summary()

def tool_add_customer_debt(args):
    cid,name=_resolve_customer(args.get("customer_name"))
    lid=db.add_customer_debt(cid,args.get("amount"),args.get("note"))
    return {"ok":True,"ledger_id":lid,"customer_name":name,"new_balance":db.get_customer_balance(cid)}

def tool_add_customer_payment(args):
    cid,name=_resolve_customer(args.get("customer_name"))
    lid=db.add_customer_payment(cid,args.get("amount"),args.get("note"))
    return {"ok":True,"ledger_id":lid,"customer_name":name,"new_balance":db.get_customer_balance(cid)}

def tool_get_customer_balance(args):
    c=db.find_customer_by_name(args.get("customer_name"))
    if not c: return {"ok":False,"error":"مشتری پیدا نشد."}
    return {"ok":True,"customer_name":c["name"],"balance":db.get_customer_balance(c["id"]),"history":db.customer_ledger_history(c["id"],10)}

def tool_list_debtors(args):
    rows=db.list_customer_balances(args.get("min_amount",0))
    if args.get("only_debtors",True): rows=[x for x in rows if x["balance"]>0]
    return {"customers":rows}

def tool_add_purchase(args):
    supplier_name=(args.get("supplier_name") or "").strip()
    sid=None
    if supplier_name:
        s=db.find_supplier_by_name(supplier_name)
        sid=s["id"] if s else db.add_supplier(supplier_name)
    items=[]
    for x in args.get("items",[]):
        name=(x.get("product_name") or "").strip()
        if not name: continue
        if x.get("cost_price") is None: return {"ok":False,"error":f"قیمت خرید «{name}» مشخص نیست."}
        p=db.find_product_by_name(name)
        pid=p["id"] if p else db.add_product(name,0,0,None,0)
        items.append({"product_id":pid,"product_name":name,"qty":x.get("qty",1),"cost_price":x["cost_price"]})
    if not items: return {"ok":False,"error":"هیچ قلمی برای خرید مشخص نشد."}
    pid,total=db.add_purchase(sid,items,args.get("note"))
    return {"ok":True,"purchase_id":pid,"total":total}

def tool_list_purchases(args):
    return {"purchases":db.list_purchases(args.get("limit",10))}

def tool_product_profit_report(args):
    return {"products":db.product_profit_report(args.get("days",30))}

def tool_customer_purchase_report(args):
    return {"customers":db.customer_purchase_report(args.get("days",30),args.get("limit",10))}

def tool_payment_method_report(args):
    return {"payments":db.payment_method_report(args.get("days",30))}

def tool_sales_stats(args):
    return {"stats":db.sales_stats(args.get("days",30))}

def tool_search_product_price(args):
    name=(args.get("product_name") or "").strip()
    if not name: return {"ok":False,"error":"نام محصول مشخص نیست."}
    details=(args.get("details") or "").strip()
    q=f"قیمت روز و معیار بازار محصول «{name}» {details} در بازار ایران به تومان چقدر است؟ بازه یا میانگین واقعی و به‌روز را کوتاه بگو و اگر منبع/تاریخ داری ذکر کن."
    try:
        r=create_completion(WEB_MODEL,messages=[
            {"role":"system","content":"فقط قیمت تقریبی بازار ایران را کوتاه و صادقانه بگو."},
            {"role":"user","content":q}],max_tokens=400)
        return {"ok":True,"product_name":name,"price_info":(r.choices[0].message.content or "").strip()}
    except Exception as e:
        return {"ok":False,"error":f"خطا در جستجوی قیمت: {e}"}

def tool_add_order_payment(args):
    order_id=args.get("order_id")
    return {"ok":True,**db.add_order_payment(order_id,args.get("amount"),args.get("method","نقدی"),args.get("note"))}

def tool_get_order(args):
    r=db.get_order_details(args.get("order_id"))
    return {"ok":bool(r),"order":r} if r else {"ok":False,"error":"سفارش پیدا نشد."}

def tool_cancel_order(args):
    db.cancel_order(args.get("order_id"),args.get("reason"))
    return {"ok":True,"order_id":args.get("order_id"),"status":"لغوشده"}


def tool_suggest_price(args):
    name=(args.get("product_name") or "").strip()
    p=db.find_product_by_name(name)
    if not p: return {"ok":False,"error":"محصول پیدا نشد."}
    cost=float(p.get("cost_price") or 0); current=float(p.get("price") or 0)
    margin=float(args.get("margin_percent") or 20)
    if cost<=0: return {"ok":False,"error":"برای پیشنهاد قیمت، قیمت خرید محصول باید ثبت شده باشد."}
    suggested=float((Decimal(str(cost))*(Decimal('1')+Decimal(str(margin))/Decimal('100'))).quantize(Decimal('0.01'),rounding=ROUND_HALF_UP))
    return {"ok":True,"product_name":p['name'],"cost_price":cost,"current_price":current,"margin_percent":margin,"suggested_price":suggested}

def tool_notifications(args):
    db.generate_notifications(); return {"notifications":db.list_notifications(args.get("unread_only",True),args.get("limit",20))}

TOOLS=[
{"type":"function","function":{"name":"add_customer","description":"افزودن مشتری","parameters":{"type":"object","properties":{"name":{"type":"string"},"phone":{"type":"string"},"address":{"type":"string"},"note":{"type":"string"}},"required":["name"]}}},
{"type":"function","function":{"name":"list_customers","description":"لیست/جستجوی مشتریان","parameters":{"type":"object","properties":{"query":{"type":"string"}}}}},
{"type":"function","function":{"name":"add_product","description":"افزودن محصول","parameters":{"type":"object","properties":{"name":{"type":"string"},"price":{"type":"number"},"cost_price":{"type":"number"},"stock":{"type":"number"},"note":{"type":"string"},"barcode":{"type":"string"},"category":{"type":"string"},"unit":{"type":"string"}},"required":["name","price"]}}},
{"type":"function","function":{"name":"list_products","description":"لیست/جستجوی محصولات","parameters":{"type":"object","properties":{"query":{"type":"string"}}}}},
{"type":"function","function":{"name":"add_order","description":"ثبت فروش اتمیک؛ موجودی کم و پرداخت/بدهی همان فروش ثبت می‌شود.","parameters":{"type":"object","properties":{
"customer_name":{"type":"string"},
"items":{"type":"array","items":{"type":"object","properties":{"product_name":{"type":"string"},"qty":{"type":"number"},"price":{"type":"number"}},"required":["product_name","qty"]}},
"paid_amount":{"type":"number","description":"مبلغ پرداخت‌شده همان فروش"},
"payment_method":{"type":"string","description":"نقدی/کارت/انتقال/چک"},
"payment_note":{"type":"string"},
"discount":{"type":"number","description":"تخفیف کل فروش"},
"note":{"type":"string"}},"required":["customer_name","items"]}}},
{"type":"function","function":{"name":"list_orders","description":"لیست فروش‌ها","parameters":{"type":"object","properties":{"limit":{"type":"integer"}}}}},
{"type":"function","function":{"name":"add_order_payment","description":"ثبت پرداخت جدید برای یک فروش موجود","parameters":{"type":"object","properties":{"order_id":{"type":"integer"},"amount":{"type":"number"},"method":{"type":"string"},"note":{"type":"string"}},"required":["order_id","amount"]}}},
{"type":"function","function":{"name":"get_order","description":"جزئیات یک فروش","parameters":{"type":"object","properties":{"order_id":{"type":"integer"}},"required":["order_id"]}}},
{"type":"function","function":{"name":"cancel_order","description":"لغو فروش و برگرداندن موجودی","parameters":{"type":"object","properties":{"order_id":{"type":"integer"},"reason":{"type":"string"}},"required":["order_id"]}}},
{"type":"function","function":{"name":"add_transaction","description":"ثبت هزینه/درآمد دستی","parameters":{"type":"object","properties":{"title":{"type":"string"},"amount":{"type":"number"},"kind":{"type":"string","enum":["income","expense"]},"category":{"type":"string"}},"required":["title","amount","kind"]}}},
{"type":"function","function":{"name":"add_task","description":"افزودن وظیفه","parameters":{"type":"object","properties":{"title":{"type":"string"},"due_date":{"type":"string"}},"required":["title"]}}},
{"type":"function","function":{"name":"list_tasks","description":"لیست وظایف","parameters":{"type":"object","properties":{"only_open":{"type":"boolean"}}}}},
{"type":"function","function":{"name":"complete_task","description":"تکمیل وظیفه","parameters":{"type":"object","properties":{"title":{"type":"string"}},"required":["title"]}}},
{"type":"function","function":{"name":"get_summary","description":"گزارش خلاصه کسب‌وکار","parameters":{"type":"object","properties":{}}}},
{"type":"function","function":{"name":"add_customer_debt","description":"ثبت بدهی جداگانه مشتری","parameters":{"type":"object","properties":{"customer_name":{"type":"string"},"amount":{"type":"number"},"note":{"type":"string"}},"required":["customer_name","amount"]}}},
{"type":"function","function":{"name":"add_customer_payment","description":"ثبت پرداخت بدهی قبلی مشتری","parameters":{"type":"object","properties":{"customer_name":{"type":"string"},"amount":{"type":"number"},"note":{"type":"string"}},"required":["customer_name","amount"]}}},
{"type":"function","function":{"name":"get_customer_balance","description":"مانده حساب مشتری","parameters":{"type":"object","properties":{"customer_name":{"type":"string"}},"required":["customer_name"]}}},
{"type":"function","function":{"name":"list_debtors","description":"لیست بدهکاران","parameters":{"type":"object","properties":{"only_debtors":{"type":"boolean"},"min_amount":{"type":"number"}}}}},
{"type":"function","function":{"name":"add_purchase","description":"ثبت خرید از تأمین‌کننده","parameters":{"type":"object","properties":{"supplier_name":{"type":"string"},"items":{"type":"array","items":{"type":"object","properties":{"product_name":{"type":"string"},"qty":{"type":"number"},"cost_price":{"type":"number"}},"required":["product_name","qty","cost_price"]}},"note":{"type":"string"}},"required":["items"]}}},
{"type":"function","function":{"name":"list_purchases","description":"لیست خریدها","parameters":{"type":"object","properties":{"limit":{"type":"integer"}}}}},
{"type":"function","function":{"name":"product_profit_report","description":"گزارش سود محصولات","parameters":{"type":"object","properties":{"days":{"type":"integer"}}}}},
{"type":"function","function":{"name":"customer_purchase_report","description":"گزارش مشتریان بر اساس مجموع خرید در بازه","parameters":{"type":"object","properties":{"days":{"type":"integer"},"limit":{"type":"integer"}}}}},
{"type":"function","function":{"name":"payment_method_report","description":"گزارش مبلغ پرداخت‌ها بر اساس روش پرداخت","parameters":{"type":"object","properties":{"days":{"type":"integer"}}}}},
{"type":"function","function":{"name":"sales_stats","description":"آمار فروش شامل تعداد سفارش، فروش، تخفیف و میانگین فاکتور","parameters":{"type":"object","properties":{"days":{"type":"integer"}}}}},
{"type":"function","function":{"name":"search_product_price","description":"جستجوی قیمت بازار محصول","parameters":{"type":"object","properties":{"product_name":{"type":"string"},"details":{"type":"string"}},"required":["product_name"]}}}
]

TOOL_DISPATCH={
"add_customer":tool_add_customer,"list_customers":tool_list_customers,
"add_product":tool_add_product,"list_products":tool_list_products,
"add_order":tool_add_order,"list_orders":tool_list_orders,
"add_order_payment":tool_add_order_payment,"get_order":tool_get_order,"cancel_order":tool_cancel_order,
"add_transaction":tool_add_transaction,"add_task":tool_add_task,"list_tasks":tool_list_tasks,
"complete_task":tool_complete_task,"get_summary":tool_get_summary,
"add_customer_debt":tool_add_customer_debt,"add_customer_payment":tool_add_customer_payment,
"get_customer_balance":tool_get_customer_balance,"list_debtors":tool_list_debtors,
"add_purchase":tool_add_purchase,"list_purchases":tool_list_purchases,
"product_profit_report":tool_product_profit_report,"search_product_price":tool_search_product_price,"suggest_price":tool_suggest_price,"list_notifications":tool_notifications
}

conversations={}
MAX_MESSAGES=24
MAX_SESSIONS=500  # FIX: جلوگیری از رشد نامحدود حافظه

def get_history(session_id):
    if session_id not in conversations:
        # FIX: اگر تعداد session‌ها از حد بگذرد، قدیمی‌ترین را حذف کن
        if len(conversations) >= MAX_SESSIONS:
            oldest = next(iter(conversations))
            del conversations[oldest]
            logger.info("Session evicted from memory: %s", oldest)
        conversations[session_id]=[]
    return conversations[session_id]

def limit_history(history):
    if len(history)>MAX_MESSAGES: del history[:-MAX_MESSAGES]

def needs_web_search(message):
    business=["مشتری","محصول","سفارش","فروش","موجودی","هزینه","درآمد","وظیفه","کسب‌وکار","کسب و کار","بدهی","خرید"]
    return not any(x in message for x in business)

def local_memory_answer(message,history):
    text=message.strip()
    if "اسمم" in text and ("چیه" in text or "چی بود" in text):
        for x in reversed(history):
            if x.get("role")=="user":
                m=re.search(r"اسمم\s+([آ-یA-Za-z]+)",x.get("content",""))
                if m:return f"اسمت {m.group(1)} بود. 😎"
        return "تا الان اسمت رو واضح نگفتی."
    if "چی داشتیم" in text or "موضوع قبلی" in text:
        u=[x["content"] for x in history if x.get("role")=="user"]
        return f"قبل از این درباره «{u[-2]}» صحبت می‌کردیم." if len(u)>=2 else "هنوز گفت‌وگوی زیادی نداشتیم."
    return None

def run_tool_calls(tool_calls):
    out=[]
    for call in tool_calls:
        name=call.function.name
        try:
            args=json.loads(call.function.arguments or "{}")
        except Exception as e:
            logger.warning("Tool %s: failed to parse arguments: %s", name, e)
            args={}
        handler=TOOL_DISPATCH.get(name)
        if not handler:
            result={"ok":False,"error":f"ابزار ناشناخته: {name}"}
        else:
            try:
                result=handler(args)
            except Exception as e:
                logger.error("Tool %s raised exception: %s", name, e, exc_info=True)  # FIX: log با traceback
                result={"ok":False,"error":str(e)}
        out.append({"tool_call_id":call.id,"role":"tool","name":name,"content":json.dumps(result,ensure_ascii=False,default=str)})
    return out

def normal_chat(history):
    last = RuntimeError("هیچ مدلی تعریف نشده است.")  # FIX: مقدار پیش‌فرض تا raise None نشود
    for model in NORMAL_MODELS:
        try:
            messages=[{"role":"system","content":SYSTEM_PROMPT}]+list(history)
            for _ in range(5):
                r=create_completion(model,messages=messages,tools=TOOLS,tool_choice="auto",temperature=.4,max_tokens=1500)
                choice=r.choices[0].message
                if choice.tool_calls:
                    messages.append({"role":"assistant","content":choice.content or "","tool_calls":[
                        {"id":tc.id,"type":"function","function":{"name":tc.function.name,"arguments":tc.function.arguments}}
                        for tc in choice.tool_calls]})
                    messages.extend(run_tool_calls(choice.tool_calls))
                    continue
                if choice.content:
                    return choice.content.strip(), model
                break
            raise RuntimeError("مدل پاسخ نهایی نداد.")
        except Exception as e:
            logger.warning("Model %s failed: %s", model, e)  # FIX: log کردن خطای هر مدل
            last = e
    raise last

def web_chat(history):
    trimmed=[{"role":x["role"],"content":str(x.get("content",""))[:500]} for x in history[-4:]]
    r=create_completion(WEB_MODEL,messages=[{"role":"system","content":SYSTEM_PROMPT+WEB_SYSTEM_EXTRA}]+trimmed,max_tokens=1200)
    if not r.choices[0].message.content: raise RuntimeError("پاسخ وب خالی بود.")
    return r.choices[0].message.content.strip()

# ------------------------- AUTH -------------------------

def normalize_phone(value):
    """Normalize common Iranian mobile formats to +989xxxxxxxxx."""
    raw = str(value or "").strip()
    raw = re.sub(r"[\s\-()]+", "", raw)
    trans = str.maketrans("۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩", "01234567890123456789")
    raw = raw.translate(trans)
    if raw.startswith("00"):
        raw = "+" + raw[2:]
    if raw.startswith("0098"):
        raw = "+98" + raw[4:]
    if raw.startswith("98") and not raw.startswith("+98"):
        raw = "+" + raw
    if raw.startswith("09"):
        raw = "+98" + raw[1:]
    if not re.fullmatch(r"\+98\d{10}", raw):
        raise ValueError("شماره موبایل معتبر نیست.")
    return raw


def otp_hash(phone, code):
    secret = app.secret_key.encode("utf-8") if isinstance(app.secret_key, str) else app.secret_key
    return hashlib.sha256(secret + phone.encode("utf-8") + str(code).encode("ascii")).hexdigest()


def send_sms_otp(phone, code):
    """Send OTP using Kavenegar VerifyLookup. Credentials stay in environment variables."""
    api_key = os.getenv("KAVENEGAR_API_KEY", "").strip()
    template = os.getenv("KAVENEGAR_TEMPLATE", "").strip()
    dev_mode = os.getenv("DIJO_SMS_DEV_MODE", "0") == "1"
    if dev_mode:
        logger.warning("SMS DEV MODE: OTP for %s is %s", phone, code)
        return True
    if not api_key or not template:
        raise RuntimeError("سرویس پیامک تنظیم نشده است. KAVENEGAR_API_KEY و KAVENEGAR_TEMPLATE را تنظیم کنید.")
    url = "https://api.kavenegar.com/v1/{}/verify/lookup.json".format(urllib.parse.quote(api_key, safe=""))
    payload = urllib.parse.urlencode({"receptor": phone, "token": str(code), "template": template}).encode("utf-8")
    req = urllib.request.Request(url, data=payload, method="POST", headers={"Content-Type":"application/x-www-form-urlencoded"})
    with urllib.request.urlopen(req, timeout=12) as resp:
        body = resp.read().decode("utf-8", "replace")
    try:
        data = json.loads(body)
        result = data.get("return", {}) if isinstance(data, dict) else {}
        if str(result.get("status", "200")) not in ("200", "201"):
            raise RuntimeError("سرویس پیامک کد را نپذیرفت.")
    except json.JSONDecodeError:
        raise RuntimeError("پاسخ نامعتبر از سرویس پیامک دریافت شد.")
    return True


@app.route("/status")
@app.route("/api/v1/health")
def health_status():
    try:
        conn = db.get_conn()
        conn.execute("SELECT 1").fetchone()
        conn.close()
        database_state = "ok"
    except Exception as exc:
        logger.exception("Health check database error: %s", exc)
        database_state = "error"
    return jsonify({"status": "online" if database_state == "ok" else "degraded",
                    "service": "dijo-core", "database": database_state,
                    "version": "3.0.0", "release": "1.0.0"})


@app.route("/auth/status")
def auth_status():
    uid = flask_session.get("user_id")
    if not uid:
        return jsonify({"logged_in":False,"username":"","display_name":"","first_time":db.user_count()==0})
    u = None
    try:
        # Existing sessions may only contain username; preserve compatibility.
        if flask_session.get("username"):
            u = db.get_user_by_username(flask_session.get("username"))
    except Exception:
        u = None
    display = ((u or {}).get("first_name") or "") + (" " + (u or {}).get("last_name") if (u or {}).get("last_name") else "")
    return jsonify({"logged_in":True,"username":flask_session.get("username",""),"display_name":display.strip() or flask_session.get("username",""),"first_time":False})


@app.route("/auth/request-otp", methods=["POST"])
def auth_request_otp():
    d = request.get_json(silent=True) or {}
    try:
        phone = normalize_phone(d.get("phone"))
    except ValueError as e:
        return jsonify({"ok":False,"error":str(e)}), 400

    now = int(time.time())
    recent = db.get_latest_auth_otp(phone)
    if recent and now - int(recent.get("created_at", 0)) < 60:
        remaining = 60 - (now - int(recent.get("created_at", 0)))
        return jsonify({"ok":False,"error":f"لطفاً {remaining} ثانیه صبر کنید و دوباره درخواست دهید."}), 429
    if db.count_recent_auth_otps(phone, now - 3600) >= 5:
        return jsonify({"ok":False,"error":"تعداد درخواست‌های کد زیاد است. بعداً دوباره امتحان کنید."}), 429

    code = f"{secrets.randbelow(1000000):06d}"
    db.create_auth_otp(phone, otp_hash(phone, code), now + 300, now)
    try:
        send_sms_otp(phone, code)
    except Exception as e:
        logger.error("OTP SMS failed for %s: %s", phone, e, exc_info=True)
        return jsonify({"ok":False,"error":"ارسال پیامک انجام نشد. تنظیمات سرویس پیامک را بررسی کنید."}), 503

    flask_session["otp_phone"] = phone
    logger.info("OTP requested for %s", phone)
    return jsonify({"ok":True,"message":"کد تأیید ارسال شد."})


@app.route("/auth/verify-otp", methods=["POST"])
def auth_verify_otp():
    d = request.get_json(silent=True) or {}
    try:
        phone = normalize_phone(d.get("phone"))
    except ValueError as e:
        return jsonify({"ok":False,"error":str(e)}), 400
    code = re.sub(r"\D", "", str(d.get("code") or ""))
    if len(code) != 6:
        return jsonify({"ok":False,"error":"کد تأیید باید ۶ رقمی باشد."}), 400
    if flask_session.get("otp_phone") != phone:
        return jsonify({"ok":False,"error":"ابتدا برای این شماره کد تأیید درخواست کنید."}), 400

    otp = db.get_latest_auth_otp(phone)
    now = int(time.time())
    if not otp or int(otp.get("used", 0)):
        return jsonify({"ok":False,"error":"کد تأیید منقضی شده یا وجود ندارد."}), 400
    if now > int(otp["expires_at"]):
        db.consume_auth_otp(otp["id"])
        return jsonify({"ok":False,"error":"کد تأیید منقضی شده است. کد جدید بگیرید."}), 400
    attempts = int(otp.get("attempts", 0))
    if attempts >= 5:
        db.consume_auth_otp(otp["id"])
        return jsonify({"ok":False,"error":"تعداد تلاش‌ها تمام شد. کد جدید بگیرید."}), 400
    if not secrets.compare_digest(otp["code_hash"], otp_hash(phone, code)):
        db.update_auth_otp_attempts(otp["id"], attempts + 1)
        return jsonify({"ok":False,"error":"کد واردشده صحیح نیست."}), 401

    db.consume_auth_otp(otp["id"])
    u = db.get_user_by_phone(phone)
    if u:
        bid = db.ensure_default_business(u["id"])
        db.set_current_user(u["id"], bid)
        flask_session.permanent = True
        flask_session["user_id"] = u["id"]
        flask_session["username"] = u["username"]
        flask_session["business_id"] = bid
        flask_session.pop("otp_phone", None)
        display = ((u.get("first_name") or "") + " " + (u.get("last_name") or "")).strip() or u["username"]
        return jsonify({"ok":True,"logged_in":True,"username":u["username"],"display_name":display})

    flask_session["otp_verified_phone"] = phone
    return jsonify({"ok":True,"logged_in":False,"needs_profile":True})


@app.route("/auth/complete-profile", methods=["POST"])
def auth_complete_profile():
    phone = flask_session.get("otp_verified_phone")
    if not phone:
        return jsonify({"ok":False,"error":"تأیید شماره انجام نشده است."}), 401
    d = request.get_json(silent=True) or {}
    first = str(d.get("first_name") or "").strip()
    last = str(d.get("last_name") or "").strip()
    if len(first) < 2 or len(last) < 2:
        return jsonify({"ok":False,"error":"نام و نام خانوادگی معتبر وارد کنید."}), 400

    try:
        # Race-safe: if another request created this phone, simply use that account.
        u = db.get_user_by_phone(phone)
        if not u:
            password_hash = generate_password_hash(secrets.token_urlsafe(32))
            uid = db.create_phone_user(phone, first, last, password_hash)
            bid = db.ensure_default_business(uid)
        else:
            uid = u["id"]
            bid = db.ensure_default_business(uid)
            # Fill missing profile data without replacing a user's existing name.
            if not u.get("first_name") or not u.get("last_name"):
                conn = db.get_master_conn()
                conn.execute("UPDATE users SET first_name=?, last_name=? WHERE id=?", (u.get("first_name") or first, u.get("last_name") or last, uid))
                conn.commit(); conn.close()
        db.set_current_user(uid, bid)
        flask_session.permanent = True
        u2 = db.get_user_by_phone(phone)
        flask_session["user_id"] = uid
        flask_session["username"] = u2["username"]
        flask_session["business_id"] = bid
        flask_session.pop("otp_verified_phone", None)
        display = ((u2.get("first_name") or first) + " " + (u2.get("last_name") or last)).strip()
        logger.info("Phone account completed: %s", phone)
        return jsonify({"ok":True,"username":u2["username"],"display_name":display})
    except Exception as e:
        logger.error("Profile completion failed: %s", e, exc_info=True)
        return jsonify({"ok":False,"error":"ساخت حساب انجام نشد. دوباره امتحان کنید."}),500


# Legacy username/password endpoints remain for backward compatibility with older clients.
@app.route("/auth/register",methods=["POST"])
def auth_register():
    d=request.get_json(silent=True) or {}
    username=(d.get("username") or "").strip()
    password=(d.get("password") or "").strip()
    if not username or not password:
        return jsonify({"ok":False,"error":"نام کاربری و رمز عبور الزامی است."}),400
    if len(password)<4:
        return jsonify({"ok":False,"error":"رمز عبور باید حداقل ۴ کاراکتر باشد."}),400
    if db.get_user_by_username(username):
        return jsonify({"ok":False,"error":"این نام کاربری قبلاً گرفته شده، یک نام دیگر انتخاب کنید."}),409
    try:
        uid=db.add_user(username,generate_password_hash(password))
        bid=db.ensure_default_business(uid); db.set_current_user(uid,bid)
        flask_session.permanent=True; flask_session["user_id"]=uid; flask_session["username"]=username; flask_session["business_id"]=bid
        return jsonify({"ok":True,"username":username})
    except Exception as e:
        logger.error("Registration failed: %s", e, exc_info=True)
        return jsonify({"ok":False,"error":"خطا در ثبت‌نام. دوباره امتحان کنید."}),500

@app.route("/auth/login",methods=["POST"])
def auth_login():
    d=request.get_json(silent=True) or {}
    username=(d.get("username") or "").strip(); password=(d.get("password") or "").strip()
    u=db.get_user_by_username(username)
    if not u or not check_password_hash(u["password_hash"],password):
        return jsonify({"ok":False,"error":"نام کاربری یا رمز عبور اشتباه است."}),401
    bid=db.ensure_default_business(u["id"]); db.set_current_user(u["id"],bid)
    flask_session.permanent=True; flask_session["user_id"]=u["id"]; flask_session["username"]=u["username"]; flask_session["business_id"]=bid
    return jsonify({"ok":True,"username":u["username"],"display_name":((u.get("first_name") or "")+" "+(u.get("last_name") or "")).strip() or u["username"]})

@app.route("/auth/logout",methods=["POST"])
def auth_logout():
    flask_session.clear(); db.clear_current_user(); return jsonify({"ok":True})

# ------------------------- BUSINESS / NOTIFICATIONS / API KEY -------------------------
@app.route("/api/businesses")
def api_businesses():
    uid=flask_session.get("user_id"); return jsonify(db.list_businesses(uid))

@app.route("/api/businesses", methods=["POST"])
def api_create_business():
    d=request.get_json(silent=True) or {}
    try:
        r=db.create_business(flask_session["user_id"],d.get("name"))
        return jsonify({"ok":True,"business":r})
    except ValueError as e:
        return jsonify({"ok":False,"error":str(e)}),400
    except Exception as e:
        logger.error("Create business failed for user %s: %s", flask_session.get("user_id"), e, exc_info=True)
        return jsonify({"ok":False,"error":"ساخت کسب‌وکار انجام نشد. لاگ سرور را بررسی کنید."}),500

@app.route("/api/businesses/current")
def api_current_business():
    uid=flask_session.get("user_id")
    bid=flask_session.get("business_id")
    b=db.valid_business(uid,bid) if uid and bid else None
    return jsonify(b or {})

@app.route("/api/businesses/switch", methods=["POST"])
def api_switch_business():
    d=request.get_json(silent=True) or {}
    try:
        bid=int(d.get("business_id"))
    except (TypeError,ValueError):
        return jsonify({"ok":False,"error":"شناسه کسب‌وکار نامعتبر است."}),400
    try:
        if not db.valid_business(flask_session["user_id"],bid):
            return jsonify({"ok":False,"error":"کسب‌وکار پیدا نشد."}),404
        flask_session["business_id"]=bid
        db.set_current_user(flask_session["user_id"],bid)
        return jsonify({"ok":True,"business_id":bid})
    except Exception as e:
        logger.error("Switch business failed: %s", e, exc_info=True)
        return jsonify({"ok":False,"error":"تغییر کسب‌وکار انجام نشد."}),500

@app.route("/api/notifications")
def api_notifications():
    db.generate_notifications(); return jsonify(db.list_notifications(request.args.get("unread") in ("1","true","yes"),50))

@app.route("/api/notifications/<int:notification_id>/read", methods=["POST"])
def api_notification_read(notification_id):
    db.mark_notification_read(notification_id); return jsonify({"ok":True})

@app.route("/api/api-keys", methods=["POST"])
def api_create_key():
    d=request.get_json(silent=True) or {}; return jsonify({"ok":True,**db.create_api_key(flask_session["user_id"],d.get("name"))})

# ------------------------- BACKUP / PAGES -------------------------

@app.route("/api/backup")
def api_backup():
    try:
        c=db.get_conn(); c.execute("PRAGMA wal_checkpoint(FULL)"); c.close()
    except Exception: pass
    fname="dijo_backup_"+datetime.now().strftime("%Y%m%d_%H%M%S")+".db"
    return send_file(db.get_db_path(),as_attachment=True,download_name=fname)


# ------------------------- PROFILE -------------------------

@app.route("/api/profile", methods=["GET", "POST"])
def api_profile():
    uid = flask_session.get("user_id", 1)
    path = os.path.join(BASE_DIR, f"profile_user_{uid}.json")
    if request.method == "POST":
        d = request.get_json(silent=True) or {}
        allowed = {"shop_name", "owner_name", "phone", "address", "note"}
        clean = {k: str(v)[:200] for k, v in d.items() if k in allowed}
        with open(path, "w", encoding="utf-8") as f:
            json.dump(clean, f, ensure_ascii=False, indent=2)
        return jsonify({"ok": True})
    if os.path.exists(path):
        with open(path, "r", encoding="utf-8") as f:
            return jsonify(json.load(f))
    return jsonify({})


# ------------------------- CHAT -------------------------

@app.route("/chat",methods=["POST"])
def chat():
    try:
        data=request.get_json(silent=True) or {}
        message=str(data.get("message","")).strip()
        if not message:return jsonify({"error":"پیام خالی است."}),400
        sid=str(data.get("session_id","")).strip() or str(uuid.uuid4())
        history=get_history(sid)
        if not history:
            history.extend(db.load_chat_history(sid, MAX_MESSAGES))
        local=local_memory_answer(message,history)
        if local:
            history.append({"role":"assistant","content":local}); db.save_chat_message(sid,"assistant",local); limit_history(history)
            return jsonify({"reply":local,"session_id":sid,"mode":"memory"})
        history.append({"role":"user","content":message}); db.save_chat_message(sid,"user",message); limit_history(history)
        if needs_web_search(message):
            try:
                reply=web_chat(history); history.append({"role":"assistant","content":reply}); db.save_chat_message(sid,"assistant",reply); limit_history(history)
                return jsonify({"reply":reply,"session_id":sid,"mode":"web"})
            except Exception:
                try:
                    reply,model=normal_chat(history); history.append({"role":"assistant","content":reply}); db.save_chat_message(sid,"assistant",reply); limit_history(history)
                    return jsonify({"reply":"فعلاً جست‌وجوی زنده وب در دسترس نبود.\n\n"+reply,"session_id":sid,"mode":"fallback"})
                except Exception:
                    if history and history[-1]["role"]=="user":history.pop()
                    return jsonify({"reply":"فعلاً دیجو نتونست وصل بشه. چند لحظه بعد دوباره امتحان کن.","session_id":sid,"mode":"error"})
        try:
            reply,model=normal_chat(history); history.append({"role":"assistant","content":reply}); db.save_chat_message(sid,"assistant",reply); limit_history(history)
            return jsonify({"reply":reply,"session_id":sid,"mode":"normal","model":model})
        except Exception:
            try:
                reply=web_chat(history); history.append({"role":"assistant","content":reply}); db.save_chat_message(sid,"assistant",reply); limit_history(history)
                return jsonify({"reply":reply,"session_id":sid,"mode":"web_fallback"})
            except Exception:
                if history and history[-1]["role"]=="user":history.pop()
                return jsonify({"reply":"فعلاً اتصال دیجو مشکل دارد. دوباره امتحان کن.","session_id":sid,"mode":"offline"})
    except Exception as e:
        logger.error("Unhandled error in /chat: %s", e, exc_info=True)  # FIX: log با traceback
        return jsonify({"reply":"یک خطای موقت در دیجو رخ داد.","error":str(e)}),200

# ------------------------- SMART CENTER / BUSINESS OS V6 -------------------------

def _ensure_pro_tables():
    conn = db.get_conn()
    conn.execute("""CREATE TABLE IF NOT EXISTS business_automations (
        id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL,
        business_id INTEGER NOT NULL, name TEXT NOT NULL, kind TEXT NOT NULL,
        enabled INTEGER NOT NULL DEFAULT 1, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(user_id,business_id,kind))""")
    conn.execute("""CREATE TABLE IF NOT EXISTS business_audit (
        id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL,
        business_id INTEGER NOT NULL, action TEXT NOT NULL, path TEXT NOT NULL,
        detail TEXT, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)""")
    conn.commit()
    conn.close()


def _audit(action, path, detail=""):
    try:
        uid = flask_session.get("user_id")
        bid = flask_session.get("business_id") or 1
        if not uid: return
        _ensure_pro_tables()
        conn = db.get_conn()
        conn.execute("INSERT INTO business_audit(user_id,business_id,action,path,detail) VALUES(?,?,?,?,?)",
                     (uid, bid, action, path[:180], str(detail)[:500]))
        conn.commit(); conn.close()
    except Exception:
        logger.exception("Audit write failed")


@app.after_request
def _audit_mutations(response):
    if request.method in ("POST", "PUT", "PATCH", "DELETE") and request.path.startswith("/api/") and response.status_code < 400:
        _audit(request.method, request.path)
    return response


@app.route("/api/smart/overview")
def api_smart_overview():
    summary = db.get_summary()
    sales = float(summary.get("sales_month", 0) or 0)
    profit = float(summary.get("profit_month", 0) or 0)
    return jsonify({"summary": {
        "sales_period": sales, "profit_period": profit,
        "sales_change_percent": 0,
        "total_debt": float(summary.get("total_debt", 0) or 0),
        "debtors_count": int(summary.get("debtors_count", 0) or 0),
        "low_stock": summary.get("low_stock", [])
    }, "period_days": max(1, min(int(request.args.get("days", 30)), 365))})


@app.route("/api/smart/health")
def api_smart_health():
    summary = db.get_summary()
    score = 100
    reasons = []
    low = len(summary.get("low_stock", []) or [])
    debtors = int(summary.get("debtors_count", 0) or 0)
    profit = float(summary.get("profit_month", 0) or 0)
    if low:
        score -= min(30, low * 5); reasons.append(f"{low} محصول به آستانه کمبود موجودی رسیده است.")
    if debtors:
        score -= min(25, debtors * 3); reasons.append(f"{debtors} مشتری مانده بدهی دارند.")
    if profit < 0:
        score -= 25; reasons.append("سود محاسبه‌شده دوره منفی است.")
    elif profit == 0:
        score -= 5; reasons.append("هنوز سود مثبت در دوره ثبت نشده است.")
    score = max(0, min(100, score))
    label = "عالی" if score >= 85 else "پایدار" if score >= 65 else "نیازمند توجه" if score >= 40 else "پرریسک"
    if not reasons: reasons.append("شاخص‌های موجود در محدوده قابل قبول هستند.")
    return jsonify({"score": score, "label": label, "reasons": reasons})


@app.route("/api/smart/alerts")
def api_smart_alerts():
    try: db.generate_notifications()
    except Exception: logger.exception("Notification generation failed")
    return jsonify({"unread": db.list_notifications(True, 50)})


@app.route("/api/smart/forecast")
def api_smart_forecast():
    days = max(7, min(int(request.args.get("days", 30)), 365))
    summary = db.get_summary()
    daily = float(summary.get("sales_month", 0) or 0) / 30.0
    return jsonify({"available": daily > 0, "next_7_total": round(daily * 7, 2),
                    "confidence_note": "برآورد ساده بر اساس میانگین فروش ماه اخیر؛ پیش‌بینی قطعی نیست.",
                    "method": "30-day average", "period_days": days})


@app.route("/api/pro/team", methods=["GET"])
def api_pro_team():
    uid = flask_session.get("user_id")
    user = db.get_user_by_username(flask_session.get("username", "")) or {}
    return jsonify([{"id": uid, "username": user.get("username", flask_session.get("username", "")),
                     "name": ((user.get("first_name") or "") + " " + (user.get("last_name") or "")).strip(),
                     "role": "مالک", "status": "active"}])


@app.route("/api/pro/automations", methods=["GET", "POST"])
def api_pro_automations():
    _ensure_pro_tables()
    uid = int(flask_session.get("user_id")); bid = int(flask_session.get("business_id") or 1)
    conn = db.get_conn()
    if request.method == "POST":
        d = request.get_json(silent=True) or {}
        kind = str(d.get("kind") or "").strip()[:40]
        if not kind:
            conn.close(); return jsonify({"error": "نوع قانون مشخص نیست."}), 400
        name = str(d.get("name") or kind)[:100]
        enabled = 1 if d.get("enabled", True) else 0
        conn.execute("INSERT INTO business_automations(user_id,business_id,name,kind,enabled) VALUES(?,?,?,?,?) "
                     "ON CONFLICT(user_id,business_id,kind) DO UPDATE SET name=excluded.name,enabled=excluded.enabled",
                     (uid,bid,name,kind,enabled))
        conn.commit()
    rows = conn.execute("SELECT id,name,kind,enabled,created_at FROM business_automations WHERE user_id=? AND business_id=? ORDER BY id",
                        (uid,bid)).fetchall()
    if not rows:
        defaults = [("هشدار کمبود موجودی", "low_stock", 1), ("پیگیری بدهی مشتریان", "old_debt", 1)]
        conn.executemany("INSERT OR IGNORE INTO business_automations(user_id,business_id,name,kind,enabled) VALUES(?,?,?,?,?)",
                         [(uid,bid,n,k,e) for n,k,e in defaults])
        conn.commit()
        rows = conn.execute("SELECT id,name,kind,enabled,created_at FROM business_automations WHERE user_id=? AND business_id=? ORDER BY id",
                            (uid,bid)).fetchall()
    result = [dict(x) for x in rows]; conn.close()
    for x in result: x["enabled"] = bool(x["enabled"])
    return jsonify(result)


@app.route("/api/pro/invoices")
def api_pro_invoices():
    limit = max(1, min(int(request.args.get("limit", 20)), 100))
    orders = db.list_orders(limit)
    return jsonify([{"id": x.get("id"), "number": x.get("id"), "customer": x.get("customer_name"),
                     "total": x.get("total", 0), "status": x.get("status"),
                     "created_at": x.get("created_at")} for x in orders])


@app.route("/api/pro/audit")
def api_pro_audit():
    _ensure_pro_tables()
    limit = max(1, min(int(request.args.get("limit", 20)), 100))
    conn = db.get_conn()
    rows = conn.execute("SELECT id,action,path,detail,created_at FROM business_audit WHERE user_id=? AND business_id=? ORDER BY id DESC LIMIT ?",
                        (flask_session.get("user_id"), flask_session.get("business_id") or 1, limit)).fetchall()
    conn.close()
    return jsonify([dict(x) for x in rows])


@app.route("/api/chat/sessions", methods=["GET"])
def api_chat_sessions():
    limit = max(1, min(int(request.args.get("limit", 40)), 100))
    return jsonify(db.list_chat_sessions(limit))


@app.route("/api/chat/sessions/<path:session_id>", methods=["GET"])
def api_chat_session_detail(session_id):
    return jsonify({"session_id": session_id, "messages": db.load_chat_messages(session_id, 100)})


# ------------------------- REST API -------------------------

@app.route("/api/customers",methods=["GET","POST"])
def api_customers():
    if request.method=="POST":
        d=request.get_json(silent=True) or {}
        return jsonify({"ok":True,"id":db.add_customer(d.get("name"),d.get("phone"),d.get("address"),d.get("note"))})
    return jsonify(db.list_customers(request.args.get("q")))

@app.route("/api/customers/<int:customer_id>",methods=["PUT","DELETE"])
def api_customer(customer_id):
    if request.method=="PUT":
        d=request.get_json(silent=True) or {}
        return jsonify({"ok":db.update_customer(customer_id,d.get("name"),d.get("phone"),d.get("address"),d.get("note"))})
    db.delete_customer(customer_id); return jsonify({"ok":True})

@app.route("/api/customers/<int:customer_id>/ledger",methods=["GET","POST"])
def api_customer_ledger(customer_id):
    if request.method=="POST":
        d=request.get_json(silent=True) or {}; kind=d.get("kind")
        if kind not in ("debt","payment"):return jsonify({"error":"نوع باید debt یا payment باشد."}),400
        lid=db.add_customer_debt(customer_id,d.get("amount"),d.get("note")) if kind=="debt" else db.add_customer_payment(customer_id,d.get("amount"),d.get("note"))
        return jsonify({"ok":True,"id":lid,"balance":db.get_customer_balance(customer_id)})
    return jsonify({"balance":db.get_customer_balance(customer_id),"history":db.customer_ledger_history(customer_id)})

@app.route("/api/customers/<int:customer_id>/ledger/<int:entry_id>",methods=["DELETE"])
def api_delete_ledger(customer_id,entry_id):
    db.delete_ledger_entry(entry_id); return jsonify({"ok":True,"balance":db.get_customer_balance(customer_id)})

@app.route("/api/debtors")
def api_debtors():
    rows=db.list_customer_balances(0); only=request.args.get("only","debtors")
    if only=="debtors":rows=[r for r in rows if r["balance"]>0]
    elif only=="creditors":rows=[r for r in rows if r["balance"]<0]
    return jsonify(rows)

@app.route("/api/suppliers",methods=["GET","POST"])
def api_suppliers():
    if request.method=="POST":
        d=request.get_json(silent=True) or {}; return jsonify({"ok":True,"id":db.add_supplier(d.get("name"),d.get("phone"),d.get("note"))})
    return jsonify(db.list_suppliers(request.args.get("q")))

@app.route("/api/suppliers/<int:supplier_id>",methods=["DELETE"])
def api_supplier_delete(supplier_id):
    db.delete_supplier(supplier_id); return jsonify({"ok":True})

@app.route("/api/purchases",methods=["GET","POST"])
def api_purchases():
    if request.method=="POST":return jsonify(tool_add_purchase(request.get_json(silent=True) or {}))
    return jsonify(db.list_purchases(int(request.args.get("limit",20))))

@app.route("/api/purchases/<int:purchase_id>",methods=["DELETE"])
def api_purchase_delete(purchase_id):
    db.delete_purchase(purchase_id); return jsonify({"ok":True})

@app.route("/api/products",methods=["GET","POST"])
def api_products():
    if request.method=="POST":
        d=request.get_json(silent=True) or {}
        return jsonify({"ok":True,"id":db.add_product(d.get("name"),d.get("price",0),d.get("stock",0),d.get("note"),d.get("cost_price",0),d.get("barcode"),d.get("category"),d.get("unit","عدد"))})
    return jsonify(db.list_products(request.args.get("q")))

@app.route("/api/products/<int:product_id>",methods=["PUT","DELETE"])
def api_product(product_id):
    if request.method=="PUT":
        d=request.get_json(silent=True) or {}
        return jsonify({"ok":db.update_product(product_id,d.get("name"),d.get("price"),d.get("cost_price"),d.get("stock"),d.get("note"))})
    db.delete_product(product_id); return jsonify({"ok":True})

@app.route("/api/products/<int:product_id>/stock-history")
def api_product_stock_history(product_id):
    return jsonify(db.stock_history(product_id))

@app.route("/api/products/profit")
def api_product_profit():
    return jsonify(db.product_profit_report(int(request.args.get("days",30))))

@app.route("/api/orders",methods=["GET","POST"])
def api_orders():
    if request.method=="POST":
        try:
            return jsonify(tool_add_order(request.get_json(silent=True) or {}))
        except (ValueError, TypeError) as e:
            return jsonify({"ok":False,"error":str(e)}),400
        except Exception as e:
            logger.error("Create order failed: %s", e, exc_info=True)
            return jsonify({"ok":False,"error":"ثبت فروش انجام نشد."}),500
    return jsonify(db.list_orders(int(request.args.get("limit",20))))

@app.route("/api/orders/<int:order_id>",methods=["GET","DELETE"])
def api_order(order_id):
    if request.method=="GET":
        r=db.get_order_details(order_id)
        return (jsonify(r),200) if r else (jsonify({"ok":False,"error":"سفارش پیدا نشد."}),404)
    # FIX: delete_order همیشه ValueError می‌دهد — پیام را به کاربر برمی‌گردانیم
    try:
        db.delete_order(order_id)
        return jsonify({"ok":True})
    except ValueError as e:
        return jsonify({"ok":False,"error":str(e)}),400

@app.route("/api/orders/<int:order_id>/payment",methods=["POST"])
def api_order_payment(order_id):
    d=request.get_json(silent=True) or {}
    return jsonify({"ok":True,**db.add_order_payment(order_id,d.get("amount"),d.get("method","نقدی"),d.get("note"))})

@app.route("/api/orders/<int:order_id>/cancel",methods=["POST"])
def api_order_cancel(order_id):
    d=request.get_json(silent=True) or {}
    db.cancel_order(order_id,d.get("reason")); return jsonify({"ok":True})

@app.route("/api/transactions",methods=["GET","POST"])
def api_transactions():
    if request.method=="POST":
        d=request.get_json(silent=True) or {}
        return jsonify({"ok":True,"id":db.add_transaction(d.get("title"),d.get("amount"),d.get("kind"),d.get("category"))})
    return jsonify(db.list_transactions(int(request.args.get("limit",50))))

@app.route("/api/transactions/<int:t_id>",methods=["DELETE"])
def api_transaction_delete(t_id):
    db.delete_transaction(t_id); return jsonify({"ok":True})

@app.route("/api/tasks",methods=["GET","POST"])
def api_tasks():
    if request.method=="POST":
        d=request.get_json(silent=True) or {}; return jsonify({"ok":True,"id":db.add_task(d.get("title"),d.get("due_date"))})
    return jsonify(db.list_tasks(request.args.get("open")=="1"))

@app.route("/api/tasks/<int:task_id>/done",methods=["POST"])
def api_task_done(task_id):
    db.set_task_done(task_id,True); return jsonify({"ok":True})

@app.route("/api/tasks/<int:task_id>",methods=["DELETE"])
def api_task_delete(task_id):
    db.delete_task(task_id); return jsonify({"ok":True})

@app.route("/api/summary")
def api_summary(): return jsonify(db.get_summary())


# ------------------------- SMART REPORT API -------------------------

@app.route("/api/reports/customers")
def api_report_customers():
    return jsonify(db.customer_purchase_report(int(request.args.get("days",30)), int(request.args.get("limit",10))))

@app.route("/api/reports/payments")
def api_report_payments():
    return jsonify(db.payment_method_report(int(request.args.get("days",30))))

@app.route("/api/reports/sales-stats")
def api_report_sales_stats():
    return jsonify(db.sales_stats(int(request.args.get("days",30))))


# ------------------------- CSV EXPORT -------------------------

def _csv_response(rows, fieldnames, filename):
    si = io.StringIO()
    writer = csv.DictWriter(si, fieldnames=fieldnames, extrasaction="ignore", lineterminator="\n")
    writer.writeheader()
    for row in rows:
        writer.writerow({k: (row.get(k) if row.get(k) is not None else "") for k in fieldnames})
    output = "\ufeff" + si.getvalue()  # BOM for Excel UTF-8
    si.close()
    return output, 200, {
        "Content-Type": "text/csv; charset=utf-8",
        "Content-Disposition": f"attachment; filename={filename}"
    }

@app.route("/api/export/customers.csv")
def export_customers_csv():
    customers = db.list_customers()
    rows = []
    for c in customers:
        bal = db.get_customer_balance(c["id"])
        rows.append({**c, "balance": bal})
    fields = ["id", "name", "phone", "address", "note", "balance", "created_at"]
    return _csv_response(rows, fields, "customers.csv")

@app.route("/api/export/products.csv")
def export_products_csv():
    products = db.list_products()
    fields = ["id", "name", "price", "cost_price", "stock", "note", "created_at"]
    return _csv_response(products, fields, "products.csv")

@app.route("/api/export/orders.csv")
def export_orders_csv():
    orders = db.list_orders(2000)
    fields = ["id", "customer_name", "total", "status", "note", "created_at"]
    return _csv_response(orders, fields, "orders.csv")

@app.route("/api/export/transactions.csv")
def export_transactions_csv():
    txs = db.list_transactions(2000)
    rows = [{**t, "kind": "هزینه" if t["kind"] == "expense" else "درآمد"} for t in txs]
    fields = ["id", "title", "amount", "kind", "category", "created_at"]
    return _csv_response(rows, fields, "transactions.csv")

if __name__=="__main__":
    print("==============================")
    print("       DIJO BUSINESS SERVER v4")
    print("==============================")
    print("Server listening on port 8787")
    print("Dijo page: /dijo")
    print("Provider: Groq")
    print("Business DB:",db.DB_PATH)
    print("==============================")
    port = int(os.getenv("PORT", 8787))
    app.run(host="0.0.0.0",port=port,debug=False,threaded=True,use_reloader=False)
