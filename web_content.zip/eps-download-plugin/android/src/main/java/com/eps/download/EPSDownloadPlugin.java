package com.eps.download;

import android.Manifest;
import android.content.ContentValues;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

@CapacitorPlugin(
    name = "EPSDownload",
    permissions = { @Permission(alias = "storage", strings = { Manifest.permission.WRITE_EXTERNAL_STORAGE }) }
)
public class EPSDownloadPlugin extends Plugin {

    @PluginMethod
    public void saveToDownloads(PluginCall call) {
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P && !getPermissionState("storage").equals(com.getcapacitor.PermissionState.GRANTED)) {
            requestPermissionForAlias("storage", call, "storagePermissionResult");
            return;
        }
        saveNow(call);
    }

    @PermissionCallback
    private void storagePermissionResult(PluginCall call) {
        if (getPermissionState("storage").equals(com.getcapacitor.PermissionState.GRANTED)) {
            saveNow(call);
        } else {
            call.reject("إذن حفظ الملفات غير متاح");
        }
    }

    private void saveNow(PluginCall call) {
        String name = call.getString("fileName", "EPS_file");
        String mime = call.getString("mimeType", "application/octet-stream");
        String b64 = call.getString("dataBase64");
        if (b64 == null || b64.isEmpty()) { call.reject("بيانات الملف فارغة"); return; }
        name = name.replaceAll("[\\\\/:*?\"<>|]", "_");
        byte[] bytes;
        try { bytes = Base64.decode(b64, Base64.DEFAULT); }
        catch (Exception e) { call.reject("تعذر قراءة بيانات الملف", e); return; }

        try {
            String relative = Environment.DIRECTORY_DOWNLOADS;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                ContentValues values = new ContentValues();
                values.put(MediaStore.Downloads.DISPLAY_NAME, name);
                values.put(MediaStore.Downloads.MIME_TYPE, mime);
                values.put(MediaStore.Downloads.RELATIVE_PATH, relative);
                values.put(MediaStore.Downloads.IS_PENDING, 1);
                Uri uri = getContext().getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                if (uri == null) throw new Exception("تعذر إنشاء الملف في مجلد التنزيلات");
                try (OutputStream stream = getContext().getContentResolver().openOutputStream(uri)) {
                    if (stream == null) throw new Exception("تعذر فتح الملف للكتابة");
                    stream.write(bytes); stream.flush();
                } catch (Exception e) {
                    getContext().getContentResolver().delete(uri, null, null);
                    throw e;
                }
                ContentValues done = new ContentValues(); done.put(MediaStore.Downloads.IS_PENDING, 0);
                getContext().getContentResolver().update(uri, done, null, null);
                JSObject ret = new JSObject(); ret.put("uri", uri.toString()); ret.put("path", "Download/" + name); ret.put("fileName", name); call.resolve(ret);
            } else {
                File folder = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                if (!folder.exists() && !folder.mkdirs()) throw new Exception("تعذر إنشاء مجلد التنزيلات");
                File file = new File(folder, name);
                try (FileOutputStream stream = new FileOutputStream(file)) { stream.write(bytes); stream.flush(); }
                JSObject ret = new JSObject(); ret.put("uri", Uri.fromFile(file).toString()); ret.put("path", "Download/" + name); ret.put("fileName", name); call.resolve(ret);
            }
        } catch (Exception e) { call.reject("فشل حفظ الملف في Download: " + e.getMessage(), e); }
    }
}
