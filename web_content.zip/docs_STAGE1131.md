# CPLS V2 — Stage 1131

## Live Candle Integrity
- Rebuilt Futures OHLC aggregation from timestamp-sorted samples.
- Open/close now follow chronological samples deterministically.
- High/low are normalized against all OHLC values to prevent malformed candles.
- Duplicate/out-of-order candle buckets are rejected before drawing.
- Candle timing/end marker is derived from the timeframe bucket instead of `Date.now()` jitter for closed candles.
- Existing live continuity, zoom/pan, selected candle, OHLC panel, native REST feed and WS diagnostic are preserved.
- No undocumented Futures WebSocket subscription was invented.
- Source ZIP only; APK build was not performed.
