/**
 * Vynox Camera X — Filter Creator (Phase 3)
 * Create custom filters, save to localStorage
 */

const CUSTOM_KEY = 'vynox_custom_filters';

function loadCustomFilters() {
  try {
    const raw = localStorage.getItem(CUSTOM_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch (_) {
    return [];
  }
}

function saveCustomFilters(list) {
  try {
    localStorage.setItem(CUSTOM_KEY, JSON.stringify(list));
  } catch (_) {}
}

/**
 * Apply a custom filter definition to ImageData
 * def: { brightness, contrast, saturation, temperature, tint, vignette, grain }
 * values typically -100..100 except vignette/grain 0..100
 */
function applyCustomFilter(imageData, def, intensity = 100) {
  const data = imageData.data;
  const w = imageData.width;
  const h = imageData.height;
  const t = intensity / 100;

  const brightness = (def.brightness || 0) * t;
  const contrast = (def.contrast || 0) * t;
  const saturation = (def.saturation || 0) * t;
  const temperature = (def.temperature || 0) * t;
  const tint = (def.tint || 0) * t;
  const vignette = (def.vignette || 0) * t;
  const grain = (def.grain || 0) * t;

  const contrastFactor = (259 * (contrast + 255)) / (255 * (259 - contrast));

  for (let i = 0; i < data.length; i += 4) {
    let r = data[i], g = data[i + 1], b = data[i + 2];

    // brightness
    r += brightness;
    g += brightness;
    b += brightness;

    // contrast
    r = contrastFactor * (r - 128) + 128;
    g = contrastFactor * (g - 128) + 128;
    b = contrastFactor * (b - 128) + 128;

    // saturation
    const gray = 0.299 * r + 0.587 * g + 0.114 * b;
    r = gray + (r - gray) * (1 + saturation / 100);
    g = gray + (g - gray) * (1 + saturation / 100);
    b = gray + (b - gray) * (1 + saturation / 100);

    // temperature (warm/cool)
    r += temperature * 0.4;
    b -= temperature * 0.4;

    // tint (green/magenta)
    g += tint * 0.35;
    r -= tint * 0.15;
    b -= tint * 0.15;

    data[i] = r < 0 ? 0 : r > 255 ? 255 : r;
    data[i + 1] = g < 0 ? 0 : g > 255 ? 255 : g;
    data[i + 2] = b < 0 ? 0 : b > 255 ? 255 : b;
  }

  // vignette
  if (vignette > 0) {
    const cx = w / 2, cy = h / 2;
    const maxD = Math.sqrt(cx * cx + cy * cy);
    const strength = vignette / 100;
    for (let y = 0; y < h; y++) {
      for (let x = 0; x < w; x++) {
        const i = (y * w + x) * 4;
        const d = Math.sqrt((x - cx) * (x - cx) + (y - cy) * (y - cy)) / maxD;
        const f = 1 - strength * Math.pow(d, 1.6);
        data[i] *= f;
        data[i + 1] *= f;
        data[i + 2] *= f;
      }
    }
  }

  // grain
  if (grain > 0) {
    const amount = (grain / 100) * 24;
    for (let i = 0; i < data.length; i += 4) {
      const n = (Math.random() - 0.5) * amount;
      data[i] = Math.min(255, Math.max(0, data[i] + n));
      data[i + 1] = Math.min(255, Math.max(0, data[i + 1] + n));
      data[i + 2] = Math.min(255, Math.max(0, data[i + 2] + n));
    }
  }

  return imageData;
}

function createCustomFilter(name, def) {
  const list = loadCustomFilters();
  const id = 'custom_' + Date.now();
  const item = {
    id,
    name: name || 'My Filter',
    cat: 'custom',
    def: { ...def },
    created: Date.now()
  };
  list.unshift(item);
  saveCustomFilters(list);
  return item;
}

function deleteCustomFilter(id) {
  const list = loadCustomFilters().filter(f => f.id !== id);
  saveCustomFilters(list);
}

function getCustomFilter(id) {
  return loadCustomFilters().find(f => f.id === id);
}

window.VynoxCreator = {
  loadCustomFilters,
  saveCustomFilters,
  applyCustomFilter,
  createCustomFilter,
  deleteCustomFilter,
  getCustomFilter
};
