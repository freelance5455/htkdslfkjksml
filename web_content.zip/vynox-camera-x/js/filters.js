/**
 * Vynox Camera X — 108 Unique Photo Filters (poster set)
 * Offline Canvas parameter + effect processing
 */

function clamp(v) { return v < 0 ? 0 : v > 255 ? 255 : (v|0); }
function lerp(a, b, t) { return a + (b - a) * t; }

function applyParams(data, p, intensity) {
  const t = Math.max(0, Math.min(1, (intensity == null ? 100 : intensity) / 100));
  if (t < 0.01) return;
  const amp = 1.35;
  const brightness = (p.brightness || 0) * t * amp;
  const contrast = 1 + ((p.contrast || 0) / 100) * t * amp;
  const saturation = 1 + ((p.saturation || 0) / 100) * t * 1.3;
  const temperature = (p.temperature || 0) * t * 1.25;
  const rGain = 1 + ((p.rGain || 0) / 100) * t * 1.25;
  const gGain = 1 + ((p.gGain || 0) / 100) * t * 1.25;
  const bGain = 1 + ((p.bGain || 0) / 100) * t * 1.25;
  const fade = (p.fade || 0) * t;
  const vignette = (p.vignette || 0) * t;
  const grain = (p.grain || 0) * t;
  const mono = p.mono || false;
  const bwC = p.bwContrast || 0;
  const posterize = p.posterize || 0;
  const invert = p.invert || false;
  const solarize = p.solarize || false;
  const threshold = p.threshold;
  const overlay = p.overlay || null;

  const w = data.width || 0, h = data.height || 0;
  const px = data.data, len = px.length;
  const cx = w / 2, cy = h / 2, maxD = Math.sqrt(cx * cx + cy * cy) || 1;

  for (let i = 0, idx = 0; i < len; i += 4, idx++) {
    let r = px[i], g = px[i+1], b = px[i+2];

    if (temperature) { r += temperature * 0.7; b -= temperature * 0.55; }
    r *= rGain; g *= gGain; b *= bGain;
    if (brightness) { r += brightness * 1.3; g += brightness * 1.3; b += brightness * 1.3; }
    if (contrast !== 1) {
      r = (r - 128) * contrast + 128;
      g = (g - 128) * contrast + 128;
      b = (b - 128) * contrast + 128;
    }
    if (saturation !== 1) {
      const gray = 0.299 * r + 0.587 * g + 0.114 * b;
      r = gray + (r - gray) * saturation;
      g = gray + (g - gray) * saturation;
      b = gray + (b - gray) * saturation;
    }
    if (mono) {
      let gray = 0.299 * r + 0.587 * g + 0.114 * b;
      if (bwC) gray = (gray - 128) * (1 + bwC / 80) + 128;
      r = g = b = gray;
    }
    if (invert) { r = 255 - r; g = 255 - g; b = 255 - b; }
    if (solarize) {
      if (r > 128) r = 255 - r;
      if (g > 128) g = 255 - g;
      if (b > 128) b = 255 - b;
    }
    if (threshold != null) {
      const gray = 0.299 * r + 0.587 * g + 0.114 * b;
      const v = gray > threshold ? 255 : 0;
      r = g = b = v;
    }
    if (posterize > 1) {
      const levels = posterize;
      const step = 255 / (levels - 1);
      r = Math.round(r / step) * step;
      g = Math.round(g / step) * step;
      b = Math.round(b / step) * step;
    }
    if (fade) {
      const lift = fade * 1.0;
      r = r * (1 - fade / 170) + lift;
      g = g * (1 - fade / 170) + lift;
      b = b * (1 - fade / 170) + lift;
    }

    const x = w ? (idx % w) : 0;
    const y = w ? ((idx / w) | 0) : 0;
    const nx = w ? x / w : 0.5, ny = h ? y / h : 0.5;
    const d = Math.sqrt((x - cx) * (x - cx) + (y - cy) * (y - cy)) / maxD;

    if (vignette && w) {
      const vig = 1 - Math.max(0, d - 0.28) * (vignette / 48);
      r *= vig; g *= vig; b *= vig;
    }

    if (overlay && t > 0.15) {
      const ot = t * 0.5;
      if (overlay === 'warmglow') {
        const c = Math.max(0, 1 - (nx + ny) * 0.65);
        r += 85 * c * ot; g += 40 * c * ot;
      } else if (overlay === 'fireedge') {
        const bot = Math.max(0, ny - 0.4) * 2;
        r += 110 * bot * ot; g += 45 * bot * ot; b -= 25 * bot * ot;
      } else if (overlay === 'oceanwash') {
        b += 50 * (0.3 + 0.7 * ny) * ot; g += 15 * ot; r -= 12 * ot;
      } else if (overlay === 'leaf') {
        const edge = Math.max(nx, 1 - nx, ny, 1 - ny);
        const e = Math.max(0, edge - 0.5) * 2;
        g += 65 * e * ot; r -= 12 * e * ot;
      } else if (overlay === 'neonedge') {
        const e = Math.max(0, d - 0.5) * 2;
        r += 70 * e * ot; b += 90 * e * ot;
      } else if (overlay === 'pinkbloom') {
        r += 55 * (1 - d * 0.7) * ot; b += 35 * (1 - d * 0.7) * ot;
      } else if (overlay === 'coldblue') {
        b += 55 * ot; g += 12 * ot; r -= 18 * ot;
      } else if (overlay === 'leak') {
        const leak = Math.sin(nx * 5 + ny * 3) * 0.5 + 0.5;
        r += 65 * leak * ot; g += 20 * leak * ot;
      } else if (overlay === 'mist') {
        r = lerp(r, 195, 0.28 * ot); g = lerp(g, 205, 0.28 * ot); b = lerp(b, 215, 0.3 * ot);
      } else if (overlay === 'thermal') {
        const gray = 0.299 * r + 0.587 * g + 0.114 * b;
        if (gray < 64) { r = 0; g = 0; b = gray * 2; }
        else if (gray < 128) { r = 0; g = (gray - 64) * 4; b = 255 - (gray - 64) * 2; }
        else if (gray < 192) { r = (gray - 128) * 4; g = 255; b = 0; }
        else { r = 255; g = 255 - (gray - 192) * 3; b = 0; }
      } else if (overlay === 'xray') {
        const gray = 255 - (0.299 * r + 0.587 * g + 0.114 * b);
        r = gray * 0.7; g = gray * 0.85; b = gray;
      } else if (overlay === 'nightvision') {
        const gray = 0.299 * r + 0.587 * g + 0.114 * b;
        r = gray * 0.2; g = gray * 1.3; b = gray * 0.2;
      } else if (overlay === 'rainbow') {
        const hue = (nx + ny) * 0.5;
        r += Math.sin(hue * 6.28) * 40 * ot;
        g += Math.sin(hue * 6.28 + 2) * 40 * ot;
        b += Math.sin(hue * 6.28 + 4) * 40 * ot;
      } else if (overlay === 'galaxy') {
        b += 40 * ot; r += 25 * (1 - ny) * ot; g += 10 * ot;
        if (Math.random() < 0.002 * t) { r = g = b = 255; }
      } else if (overlay === 'horror') {
        r = (r * 1.2 + 20) * (1 - d * 0.3); g *= 0.5; b *= 0.45;
      } else if (overlay === 'scanline') {
        if ((y % 3) === 0) { r *= 0.7; g *= 0.7; b *= 0.7; }
      }
    }

    if (grain) {
      const n = (Math.random() - 0.5) * grain * 1.05;
      r += n; g += n; b += n;
    }

    px[i] = clamp(r); px[i+1] = clamp(g); px[i+2] = clamp(b);
  }
}

/** Lightweight spatial effects (operate in-place, approx for live) */
function applySpatial(data, kind, intensity) {
  const t = Math.max(0, Math.min(1, intensity / 100));
  if (!data.width || t < 0.05) return;
  const w = data.width, h = data.height, px = data.data;
  // copy source
  const src = new Uint8ClampedArray(px);
  const get = (x, y) => {
    x = Math.max(0, Math.min(w - 1, x|0));
    y = Math.max(0, Math.min(h - 1, y|0));
    const i = (y * w + x) * 4;
    return [src[i], src[i+1], src[i+2]];
  };

  if (kind === 'blur' || kind === 'motion' || kind === 'bokeh') {
    const radius = kind === 'bokeh' ? Math.max(1, (3 * t)|0) : Math.max(1, (2 * t)|0);
    for (let y = 0; y < h; y++) {
      for (let x = 0; x < w; x++) {
        let r = 0, g = 0, b = 0, c = 0;
        for (let dy = -radius; dy <= radius; dy++) {
          for (let dx = -radius; dx <= radius; dx++) {
            if (kind === 'motion' && dy !== 0) continue;
            const p = get(x + dx, y + dy);
            r += p[0]; g += p[1]; b += p[2]; c++;
          }
        }
        const i = (y * w + x) * 4;
        px[i] = r / c; px[i+1] = g / c; px[i+2] = b / c;
      }
    }
  } else if (kind === 'sharpen') {
    for (let y = 1; y < h - 1; y++) {
      for (let x = 1; x < w - 1; x++) {
        const i = (y * w + x) * 4;
        for (let c = 0; c < 3; c++) {
          const v = 5 * src[i+c] - src[i-4+c] - src[i+4+c] - src[i-w*4+c] - src[i+w*4+c];
          px[i+c] = clamp(lerp(src[i+c], v, t * 0.6));
        }
      }
    }
  } else if (kind === 'edge' || kind === 'sketch' || kind === 'pencil') {
    for (let y = 1; y < h - 1; y++) {
      for (let x = 1; x < w - 1; x++) {
        const i = (y * w + x) * 4;
        const gx = Math.abs(src[i-4] - src[i+4]) + Math.abs(src[i-3] - src[i+5]) + Math.abs(src[i-2] - src[i+6]);
        const gy = Math.abs(src[i-w*4] - src[i+w*4]) + Math.abs(src[i-w*4+1] - src[i+w*4+1]);
        let v = clamp((gx + gy) * (0.8 + t));
        if (kind === 'sketch' || kind === 'pencil') v = 255 - v;
        if (kind === 'pencil') { px[i]=px[i+1]=px[i+2]=v; }
        else if (kind === 'sketch') { px[i]=px[i+1]=px[i+2]=v; }
        else { px[i]=v; px[i+1]=v; px[i+2]=v; }
      }
    }
  } else if (kind === 'emboss') {
    for (let y = 1; y < h - 1; y++) {
      for (let x = 1; x < w - 1; x++) {
        const i = (y * w + x) * 4;
        for (let c = 0; c < 3; c++) {
          px[i+c] = clamp(src[i+c] * 2 - src[i+4+c] - src[i+w*4+c] + 128);
        }
      }
    }
  } else if (kind === 'pixel') {
    const block = Math.max(2, (6 * t)|0 + 2);
    for (let y = 0; y < h; y += block) {
      for (let x = 0; x < w; x += block) {
        const p = get(x, y);
        for (let dy = 0; dy < block && y+dy < h; dy++) {
          for (let dx = 0; dx < block && x+dx < w; dx++) {
            const i = ((y+dy)*w + x+dx)*4;
            px[i]=p[0]; px[i+1]=p[1]; px[i+2]=p[2];
          }
        }
      }
    }
  } else if (kind === 'mirror') {
    for (let y = 0; y < h; y++) {
      for (let x = 0; x < w / 2; x++) {
        const i = (y * w + x) * 4;
        const j = (y * w + (w - 1 - x)) * 4;
        px[j]=src[i]; px[j+1]=src[i+1]; px[j+2]=src[i+2];
      }
    }
  } else if (kind === 'fisheye') {
    const strength = 0.35 * t;
    for (let y = 0; y < h; y++) {
      for (let x = 0; x < w; x++) {
        const nx = (x / w) * 2 - 1, ny = (y / h) * 2 - 1;
        const r2 = nx * nx + ny * ny;
        const f = 1 + strength * r2;
        const sx = ((nx / f + 1) * 0.5 * w)|0;
        const sy = ((ny / f + 1) * 0.5 * h)|0;
        const p = get(sx, sy);
        const i = (y * w + x) * 4;
        px[i]=p[0]; px[i+1]=p[1]; px[i+2]=p[2];
      }
    }
  }
}

function F(id, name, cat, emoji, desc, params, spatial) {
  return { id, name, cat, emoji, desc, params: params || {}, spatial: spatial || null };
}

const FILTERS = [
  F('normal','Natural','basic','✨','Clean natural look',{}),
  F('bright','Bright','basic','☀️','Bright and airy',{brightness:22,contrast:8,highlights:10}),
  F('warm','Warm','basic','🧡','Warm golden tone',{temperature:42,rGain:15,saturation:8}),
  F('cool','Cool','basic','💙','Cool blue tone',{temperature:-35,bGain:15,saturation:-5}),
  F('vintage','Vintage','basic','📷','Classic vintage',{temperature:25,fade:22,grain:16,saturation:-15,vignette:28}),
  F('retro','Retro','basic','📺','Retro color shift',{temperature:18,rGain:14,fade:14,grain:12,saturation:-8}),
  F('cinematic','Cinematic','basic','🎬','Movie cinematic grade',{contrast:22,saturation:-10,vignette:30,temperature:10}),
  F('bw','B&W','basic','🖤','Classic black & white',{mono:true,contrast:10}),
  F('sepia','Sepia','basic','🟤','Warm sepia',{temperature:48,rGain:22,bGain:-28,saturation:-28,fade:8}),
  F('moody','Moody','basic','🌑','Dark moody vibe',{brightness:-12,contrast:22,saturation:-18,vignette:38}),
  F('dramatic','Dramatic','basic','🎭','High drama contrast',{contrast:35,saturation:-8,vignette:32,brightness:-5}),
  F('romantic','Romantic','basic','💕','Soft romantic glow',{temperature:22,contrast:-10,fade:12,rGain:12,saturation:5}),
  F('golden','Golden','basic','🌟','Golden hour glow',{temperature:50,rGain:25,brightness:8,saturation:12,overlay:'warmglow'}),
  F('sunset','Sunset','basic','🌇','Rich sunset',{temperature:55,rGain:30,bGain:-22,saturation:20,overlay:'fireedge'}),
  F('sunrise','Sunrise','basic','🌄','Soft sunrise',{temperature:35,brightness:14,highlights:15,overlay:'warmglow'}),
  F('night','Night','basic','🌙','Night mood',{brightness:-18,contrast:18,temperature:-25,bGain:12,vignette:40}),
  F('bluetone','Blue Tone','basic','💠','Blue tone wash',{temperature:-30,bGain:28,saturation:5}),
  F('tealorange','Teal & Orange','basic','🎨','Hollywood teal-orange',{temperature:18,rGain:26,bGain:20,gGain:-8,contrast:18,saturation:15}),
  F('soft','Soft','basic','🫧','Soft gentle',{contrast:-18,fade:16,brightness:8,saturation:-8}),
  F('sharp','Sharp','basic','🔪','Extra crisp',{contrast:20,saturation:8},'sharpen'),
  F('matte','Matte','basic','📉','Matte flat look',{contrast:-12,fade:28,saturation:-15}),
  F('film','Film','basic','🎞️','Film stock',{contrast:12,grain:20,fade:10,temperature:12,saturation:-10,vignette:20}),
  F('grainy','Grainy','basic','Grain','Heavy grain',{grain:40,contrast:8,fade:6}),
  F('vignette','Vignette','basic','⭕','Strong vignette',{vignette:55,contrast:8}),
  F('hdr','HDR','basic','📡','HDR punch',{contrast:28,saturation:22,brightness:5}),
  F('lowlight','Low Light','basic','🕯️','Low light lift',{brightness:18,shadows:25,contrast:-5,grain:8}),
  F('highcontrast','High Contrast','basic','◼️','Max contrast',{contrast:42,saturation:5}),
  F('pastel','Pastel','basic','🎀','Pastel soft',{contrast:-22,fade:28,saturation:-5,brightness:12,rGain:8,bGain:8}),
  F('pink','Pink','basic','💗','Pink wash',{rGain:28,bGain:15,saturation:15,overlay:'pinkbloom'}),
  F('purple','Purple','basic','💜','Purple mood',{bGain:25,rGain:15,temperature:-8,saturation:12}),
  F('neon','Neon','basic','neon','Neon pop',{saturation:48,contrast:22,bGain:25,rGain:18,overlay:'neonedge'}),
  F('cyberpunk','Cyberpunk','basic','🤖','Cyberpunk teal',{bGain:38,gGain:12,rGain:-12,contrast:26,saturation:32,temperature:-25,overlay:'neonedge'}),
  F('urban','Urban','basic','🏙️','Urban street',{contrast:20,saturation:-12,temperature:-8,vignette:25}),
  F('blackgold','Black Gold','basic','🏆','Black & gold',{temperature:30,rGain:20,contrast:25,saturation:-20,vignette:30}),
  F('aqua','Aqua','basic','💧','Aqua blue',{bGain:30,gGain:15,temperature:-20,saturation:18,overlay:'oceanwash'}),
  F('forest','Forest','basic','🌲','Deep forest',{gGain:32,rGain:-12,bGain:-15,contrast:14,saturation:22,overlay:'leaf'}),
  F('autumn','Autumn','basic','🍂','Autumn leaves',{temperature:38,rGain:22,gGain:8,bGain:-18,saturation:15}),
  F('spring','Spring','basic','🌷','Fresh spring',{saturation:22,brightness:10,gGain:12,temperature:8}),
  F('summer','Summer','basic','☀️','Bright summer',{brightness:14,saturation:32,contrast:12,temperature:15}),
  F('winter','Winter','basic','❄️','Cold winter',{temperature:-32,saturation:-18,brightness:6,bGain:15,contrast:10}),
  F('rainy','Rainy','basic','🌧️','Rainy day',{temperature:-22,saturation:-28,contrast:10,brightness:-5,overlay:'mist'}),
  F('foggy','Foggy','basic','🌫️','Fog wash',{contrast:-32,fade:38,brightness:12,saturation:-35,overlay:'mist'}),
  F('cloudy','Cloudy','basic','☁️','Overcast',{contrast:-15,saturation:-22,brightness:5,fade:12}),
  F('dreamy','Dreamy','basic','💭','Dreamy haze',{contrast:-20,fade:24,brightness:10,saturation:5,overlay:'mist'}),
  F('glitch','Glitch','basic','📺','Digital glitch',{contrast:32,saturation:38,rGain:25,grain:18}),
  F('sketch','Sketch','art','✏️','Sketch lines',{mono:true},'sketch'),
  F('pencil','Pencil','art','✒️','Pencil drawing',{mono:true,contrast:10},'pencil'),
  F('cartoon','Cartoon','art','🎨','Cartoon flat',{posterize:5,saturation:35,contrast:20}),
  F('anime','Anime','art','anime','Anime style',{saturation:40,contrast:18,brightness:8,rGain:8}),
  F('watercolor','Watercolor','art','watercolor','Watercolor soft',{contrast:-15,saturation:20,fade:15,brightness:5}),
  F('oilpaint','Oil Paint','art','🖌️','Oil paint feel',{saturation:15,contrast:12,posterize:8}),
  F('popart','Pop Art','art','🎈','Pop art punch',{contrast:40,saturation:50,posterize:4}),
  F('comic','Comic','art','💥','Comic book',{contrast:35,saturation:25,posterize:6},'edge'),
  F('retrofilm','Retro Film','basic','📽️','Retro film',{temperature:20,grain:24,fade:18,vignette:28,saturation:-12}),
  F('lomography','Lomography','basic','📷','Lomo look',{saturation:30,contrast:18,vignette:45,temperature:15,rGain:10}),
  F('duotone','Duotone','basic','Duo','Two-tone grade',{temperature:25,rGain:20,bGain:15,saturation:-25,contrast:15}),
  F('tritone','Tri-tone','basic','Tri','Tri-tone mood',{temperature:15,rGain:12,gGain:8,bGain:12,contrast:12,saturation:-10}),
  F('pixel','Pixel','fx','👾','Pixelate',{},'pixel'),
  F('mosaic','Mosaic','fx','🧩','Mosaic blocks',{},'pixel'),
  F('blur','Blur','fx','Blur','Soft blur',{},'blur'),
  F('tiltshift','Tilt Shift','fx','Tilt','Mini tilt-shift',{contrast:12,saturation:15},'blur'),
  F('fisheye','Fish Eye','fx','🐟','Fish-eye lens',{},'fisheye'),
  F('wideangle','Wide Angle','fx','Wide','Wide feel',{contrast:8},'fisheye'),
  F('mirror','Mirror','fx','🪞','Mirror split',{},'mirror'),
  F('kaleidoscope','Kaleidoscope','fx','Kaleido','Mirror kaleidoscope',{saturation:30},'mirror'),
  F('invert','Invert','fx','Invert','Color invert',{invert:true}),
  F('solarize','Solarize','fx','Solar','Solarize',{solarize:true,contrast:10}),
  F('thermal','Thermal','fx','🌡️','Thermal cam',{overlay:'thermal'}),
  F('xray','X-ray','fx','☢️','X-ray look',{overlay:'xray'}),
  F('neonsketch','Neon Sketch','fx','NeonSketch','Neon edges',{saturation:40},'edge'),
  F('emboss','Emboss','fx','Emboss','Embossed',{},'emboss'),
  F('engrave','Engrave','fx','Engrave','Engraved look',{mono:true},'emboss'),
  F('silhouette','Silhouette','fx','Silhouette','Dark silhouette',{brightness:-25,contrast:40,vignette:50,threshold:90}),
  F('doubleexposure','Double Exposure','fx','Double','Soft double feel',{fade:20,contrast:-8,opacity:0.5}),
  F('lightleak','Light Leak','fx','Leak','Light leak',{overlay:'leak',temperature:25,brightness:5}),
  F('bokeh','Bokeh','fx','Bokeh','Bokeh blur',{},'bokeh'),
  F('lensflare','Lens Flare','fx','Flare','Flare glow',{brightness:12,overlay:'warmglow',contrast:-5}),
  F('starburst','Starburst','fx','Star','Star burst glow',{brightness:10,contrast:15,overlay:'warmglow'}),
  F('motionblur','Motion Blur','fx','Motion','Motion blur',{},'motion'),
  F('zoomblur','Zoom Blur','fx','Zoom','Radial soft',{},'blur'),
  F('radialblur','Radial Blur','fx','Radial','Radial blur',{},'blur'),
  F('swirl','Swirl','fx','Swirl','Color swirl',{saturation:35,rGain:15,bGain:15}),
  F('wave','Wave','fx','Wave','Wave distortion tint',{bGain:18,gGain:10,overlay:'oceanwash'}),
  F('glass','Glass','fx','Glass','Frosted glass',{contrast:-10,fade:10},'blur'),
  F('prism','Prism','fx','Prism','Prism split',{rGain:22,gGain:-5,bGain:22,saturation:30}),
  F('tvscan','TV Scan','fx','TV','TV scanlines',{contrast:15,grain:10,overlay:'scanline'}),
  F('oldtv','Old TV','fx','OldTV','Old TV',{mono:true,grain:25,contrast:15,overlay:'scanline'}),
  F('vhs','VHS','fx','📼','VHS tape',{saturation:-10,temperature:12,grain:22,contrast:12,rGain:8,overlay:'scanline'}),
  F('retrotv','Retro TV','fx','RetroTV','Retro TV',{saturation:20,contrast:18,grain:15,overlay:'scanline'}),
  F('noise','Noise','fx','Noise','Heavy noise',{grain:50,contrast:5}),
  F('halftone','Halftone','fx','Halftone','Halftone dots',{mono:true,posterize:4,contrast:20}),
  F('screenprint','Screen Print','fx','Print','Screen print',{posterize:5,saturation:30,contrast:25}),
  F('posterize','Posterize','fx','Poster','Posterize',{posterize:6,saturation:15,contrast:12}),
  F('threshold','Threshold','fx','Thresh','Hard threshold',{threshold:128,mono:true}),
  F('neonglow','Neon Glow','fx','Glow','Neon glow',{saturation:40,brightness:8,overlay:'neonedge',contrast:15}),
  F('edgedetect','Edge Detect','fx','Edge','Edge detect',{},'edge'),
  F('liquid','Liquid','fx','Liquid','Liquid color',{saturation:25,bGain:15,gGain:10,contrast:-8}),
  F('fire','Fire','fx','🔥','Fire tones',{temperature:65,rGain:42,bGain:-35,saturation:28,overlay:'fireedge'}),
  F('ice','Ice','fx','🧊','Ice cold',{temperature:-40,bGain:30,saturation:-10,brightness:8,overlay:'coldblue'}),
  F('sand','Sand','fx','🏜️','Desert sand',{temperature:40,rGain:25,gGain:12,bGain:-20,saturation:-5}),
  F('rust','Rust','fx','Rust','Rust metal',{temperature:30,rGain:28,gGain:5,bGain:-25,contrast:15,grain:12}),
  F('marble','Marble','fx','Marble','Marble soft',{contrast:-8,fade:18,saturation:-20,brightness:10}),
  F('galaxy','Galaxy','fx','🌌','Galaxy space',{overlay:'galaxy',bGain:25,contrast:12,saturation:15}),
  F('fantasy','Fantasy','fx','Fairy','Fantasy glow',{saturation:25,rGain:12,bGain:18,brightness:8,overlay:'pinkbloom'}),
  F('horror','Horror','fx','Horror','Horror dark',{overlay:'horror',contrast:30,vignette:45}),
  F('nightvision','Night Vision','fx','NV','Night vision',{overlay:'nightvision',contrast:15}),
  F('rainbow','Rainbow','fx','🌈','Rainbow wash',{overlay:'rainbow',saturation:30}),
  F('antique','Antique','fx','Antique','Antique photo',{temperature:28,fade:30,grain:20,saturation:-22,vignette:32}),
  F('bliss','Bliss','fx','Bliss','Soft bliss',{brightness:14,contrast:-12,fade:14,temperature:15,saturation:8,overlay:'warmglow'}),
];

// Fix emoji placeholders that are words
FILTERS.forEach(f => {
  const map = {Grain:'🌾',neon:'💜',anime:'🎌',watercolor:'🎨',Duo:'🎨',Tri:'🎨',Blur:'🌫️',Tilt:'📷',Wide:'📐',Kaleido:'🔮',Invert:'🔄',Solar:'☀️',NeonSketch:'💜',Emboss:'⬜',Engrave:'✒️',Silhouette:'🖤',Double:'👥',Leak:'🌅',Bokeh:'✨',Flare:'☀️',Star:'⭐',Motion:'💨',Zoom:'🔍',Radial:'🌀',Swirl:'🌀',Wave:'🌊',Glass:'🪟',Prism:'💎',TV:'📺',OldTV:'📺',RetroTV:'📺',Noise:'📶',Halftone:'⚪',Print:'🖨️',Poster:'📰',Thresh:'⬛',Glow:'💡',Edge:'📐',Liquid:'💧',Rust:'🧱',Marble:'⬜',Fairy:'✨',Horror:'😈',NV:'🟢',Antique:'📜',Bliss:'😇'};
  if (map[f.emoji]) f.emoji = map[f.emoji];
});

const CATEGORIES = [
  { id: 'all', label: 'All', emoji: '✨' },
  { id: 'basic', label: 'Photo', emoji: '📷' },
  { id: 'art', label: 'Art', emoji: '🎨' },
  { id: 'fx', label: 'FX', emoji: '⚡' },
  { id: 'face', label: 'Face', emoji: '🐰' },
  { id: 'custom', label: 'My Filters', emoji: '⭐' },
];

function applyFilter(imageData, filterId, intensity) {
  if (!filterId || filterId === 'normal') return imageData;
  const f = FILTERS.find(x => x.id === filterId);
  if (!f) return imageData;
  if (f.params && Object.keys(f.params).length) applyParams(imageData, f.params, intensity);
  if (f.spatial) {
    // spatial is expensive — skip on very low intensity
    if ((intensity == null ? 100 : intensity) > 15) applySpatial(imageData, f.spatial, intensity);
  }
  return imageData;
}

function getFilterPreviewStyle(f) {
  if (!f) return 'linear-gradient(145deg,#333,#111)';
  const cat = { basic:'linear-gradient(145deg,#6c757d,#343a40)', art:'linear-gradient(145deg,#f72585,#7209b7)', fx:'linear-gradient(145deg,#4cc9f0,#4361ee)' };
  return cat[f.cat] || 'linear-gradient(145deg,#444,#222)';
}

window.VynoxFilters = { FILTERS, CATEGORIES, applyFilter, applyParams, getFilterPreviewStyle };
