/**
 * Vynox Camera X — Face Stickers (Phase 4)
 * Center overlay by default. Optional MediaPipe Face Landmarker when available (CDN).
 * Fully offline fallback always works.
 */

const FACE_STICKERS = [
  { id: 'none', name: 'None', emoji: '🚫' },
  { id: 'dog', name: 'Dog Ears', emoji: '🐶' },
  { id: 'cat', name: 'Cat Ears', emoji: '🐱' },
  { id: 'glasses', name: 'Glasses', emoji: '👓' },
  { id: 'sunglasses', name: 'Sunglasses', emoji: '🕶️' },
  { id: 'hat', name: 'Hat', emoji: '🎩' },
  { id: 'crown', name: 'Crown', emoji: '👑' },
  { id: 'beard', name: 'Beard', emoji: '🧔' },
  { id: 'mustache', name: 'Mustache', emoji: '🥸' },
  { id: 'joker', name: 'Joker', emoji: '🃏' },
  { id: 'hearts', name: 'Hearts', emoji: '😍' },
  { id: 'fire', name: 'Fire', emoji: '🔥' },
  { id: 'star', name: 'Stars', emoji: '🤩' },
  { id: 'party', name: 'Party', emoji: '🥳' },
  { id: 'cool', name: 'Cool', emoji: '😎' },
  { id: 'rabbit', name: 'Rabbit', emoji: '🐰' },
  { id: 'flower', name: 'Flower', emoji: '🌸' },
  { id: 'rainbow', name: 'Rainbow', emoji: '🌈' },
];

class FaceStickerEngine {
  constructor() {
    this.activeId = 'none';
    this.scale = 1;
    this.landmarks = null; // {x,y} normalized 0-1 center of face if tracked
    this.faceWidth = 0.35;
    this.mpReady = false;
    this.mpLandmarker = null;
    this._lastDetect = 0;
  }

  setSticker(id) {
    this.activeId = id || 'none';
  }

  setScale(s) {
    this.scale = Math.max(0.5, Math.min(2.5, s));
  }

  setLandmarks(centerX, centerY, faceW) {
    this.landmarks = { x: centerX, y: centerY };
    if (faceW) this.faceWidth = faceW;
  }

  clearLandmarks() {
    this.landmarks = null;
  }

  /**
   * Try load MediaPipe Face Landmarker from CDN (optional).
   * If offline / fail → silent fallback to center placement.
   */
  async tryInitMediaPipe() {
    if (this.mpReady || this._mpTried) return this.mpReady;
    this._mpTried = true;
    try {
      const vision = await import('https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14/+esm');
      const { FaceLandmarker, FilesetResolver } = vision;
      const fileset = await FilesetResolver.forVisionTasks(
        'https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14/wasm'
      );
      this.mpLandmarker = await FaceLandmarker.createFromOptions(fileset, {
        baseOptions: {
          modelAssetPath: 'https://storage.googleapis.com/mediapipe-models/face_landmarker/face_landmarker/float16/1/face_landmarker.task',
          delegate: 'GPU'
        },
        runningMode: 'VIDEO',
        numFaces: 1
      });
      this.mpReady = true;
      console.log('MediaPipe Face Landmarker ready');
      return true;
    } catch (e) {
      console.warn('MediaPipe unavailable, using center fallback', e);
      this.mpReady = false;
      return false;
    }
  }

  detectFromVideo(video, timestampMs) {
    if (!this.mpReady || !this.mpLandmarker || !video) return;
    const now = timestampMs || performance.now();
    if (now - this._lastDetect < 66) return; // ~15fps detect
    this._lastDetect = now;
    try {
      const result = this.mpLandmarker.detectForVideo(video, now);
      if (result && result.faceLandmarks && result.faceLandmarks[0]) {
        const lm = result.faceLandmarks[0];
        // nose tip approx landmark 1, or average of key points
        let sx = 0, sy = 0, n = 0;
        // use a subset: forehead/chin/cheeks for bbox
        const indices = [10, 152, 234, 454, 1]; // face oval samples
        indices.forEach(i => {
          if (lm[i]) { sx += lm[i].x; sy += lm[i].y; n++; }
        });
        if (n > 0) {
          this.landmarks = { x: sx / n, y: sy / n };
          // width estimate from cheeks
          if (lm[234] && lm[454]) {
            this.faceWidth = Math.abs(lm[454].x - lm[234].x);
          }
        }
      } else {
        this.landmarks = null;
      }
    } catch (_) {}
  }

  draw(ctx, canvasW, canvasH) {
    if (!this.activeId || this.activeId === 'none') return;

    const sticker = FACE_STICKERS.find(s => s.id === this.activeId);
    if (!sticker) return;

    let fx, fy, fw, fh;
    if (this.landmarks) {
      fw = canvasW * Math.max(0.2, this.faceWidth) * this.scale * 1.2;
      fh = fw * 0.9;
      fx = this.landmarks.x * canvasW - fw / 2;
      fy = this.landmarks.y * canvasH - fh / 2;
    } else {
      fw = canvasW * 0.35 * this.scale;
      fh = canvasH * 0.28 * this.scale;
      fx = (canvasW - fw) / 2;
      fy = canvasH * 0.18;
    }

    ctx.save();
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    const emoji = sticker.emoji;
    const fontSize = Math.max(24, fw * 0.5);

    switch (this.activeId) {
      case 'dog':
      case 'cat':
      case 'rabbit':
        ctx.font = fontSize + 'px serif';
        ctx.fillText(emoji, fx + fw * 0.12, fy - fh * 0.1);
        ctx.fillText(emoji, fx + fw * 0.88, fy - fh * 0.1);
        break;
      case 'glasses':
      case 'sunglasses':
        ctx.font = (fontSize * 1.15) + 'px serif';
        ctx.fillText(emoji, fx + fw / 2, fy + fh * 0.42);
        break;
      case 'hat':
      case 'crown':
        ctx.font = (fontSize * 1.25) + 'px serif';
        ctx.fillText(emoji, fx + fw / 2, fy - fh * 0.05);
        break;
      case 'beard':
      case 'mustache':
        ctx.font = fontSize + 'px serif';
        ctx.fillText(emoji, fx + fw / 2, fy + fh * 0.78);
        break;
      case 'flower':
      case 'rainbow':
        ctx.font = (fontSize * 0.9) + 'px serif';
        ctx.fillText(emoji, fx + fw * 0.2, fy - fh * 0.05);
        ctx.fillText(emoji, fx + fw * 0.8, fy - fh * 0.05);
        break;
      default:
        ctx.font = (fontSize * 1.2) + 'px serif';
        ctx.fillText(emoji, fx + fw / 2, fy + fh * 0.4);
    }
    ctx.restore();
  }
}

window.VynoxFace = { FACE_STICKERS, FaceStickerEngine };
