/**
 * Vynox Camera X — Effects Engine (Phase 2)
 * Real post-processing effects with intensity 0–100
 */

function lerp(a, b, t) { return a + (b - a) * t; }
function clamp(v) { return v < 0 ? 0 : v > 255 ? 255 : v | 0; }

const EFFECTS = [
  { id: 'none', name: 'None', fn: null },
  { id: 'grain', name: 'Film Grain', fn: applyGrain },
  { id: 'vignette', name: 'Vignette', fn: applyVignette },
  { id: 'scanlines', name: 'Scanlines', fn: applyScanlines },
  { id: 'rgbsplit', name: 'RGB Split', fn: applyRGBSplit },
  { id: 'glitch', name: 'Glitch', fn: applyGlitch },
  { id: 'noise', name: 'Noise', fn: applyNoise },
  { id: 'vhs', name: 'VHS', fn: applyVHS },
  { id: 'fade', name: 'Fade', fn: applyFade },
  { id: 'bloom', name: 'Soft Bloom', fn: applyBloom },
  { id: 'poster', name: 'Posterize', fn: applyPosterize },
  { id: 'invert', name: 'Invert', fn: applyInvert },
  { id: 'chromatic', name: 'Chromatic', fn: applyChromatic },
];

function applyGrain(data, w, h, intensity) {
  const amount = (intensity / 100) * 28;
  for (let i = 0; i < data.length; i += 4) {
    const n = (Math.random() - 0.5) * amount;
    data[i] = clamp(data[i] + n);
    data[i + 1] = clamp(data[i + 1] + n);
    data[i + 2] = clamp(data[i + 2] + n);
  }
}

function applyVignette(data, w, h, intensity) {
  const strength = intensity / 100;
  const cx = w / 2, cy = h / 2;
  const maxD = Math.sqrt(cx * cx + cy * cy);
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const i = (y * w + x) * 4;
      const d = Math.sqrt((x - cx) * (x - cx) + (y - cy) * (y - cy)) / maxD;
      const f = 1 - strength * Math.pow(d, 1.8);
      data[i] = clamp(data[i] * f);
      data[i + 1] = clamp(data[i + 1] * f);
      data[i + 2] = clamp(data[i + 2] * f);
    }
  }
}

function applyScanlines(data, w, h, intensity) {
  const dark = 1 - (intensity / 100) * 0.55;
  for (let y = 0; y < h; y += 2) {
    for (let x = 0; x < w; x++) {
      const i = (y * w + x) * 4;
      data[i] = clamp(data[i] * dark);
      data[i + 1] = clamp(data[i + 1] * dark);
      data[i + 2] = clamp(data[i + 2] * dark);
    }
  }
}

function applyRGBSplit(data, w, h, intensity) {
  const shift = Math.max(1, Math.round((intensity / 100) * 6));
  const copy = new Uint8ClampedArray(data);
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const i = (y * w + x) * 4;
      const xr = Math.min(w - 1, x + shift);
      const xb = Math.max(0, x - shift);
      data[i] = copy[(y * w + xr) * 4];         // R from right
      data[i + 2] = copy[(y * w + xb) * 4 + 2]; // B from left
    }
  }
}

function applyGlitch(data, w, h, intensity) {
  const rows = Math.floor((intensity / 100) * 12);
  for (let r = 0; r < rows; r++) {
    const y = Math.floor(Math.random() * h);
    const shift = Math.floor((Math.random() - 0.5) * (intensity / 100) * 40);
    const rowStart = y * w * 4;
    const temp = data.slice(rowStart, rowStart + w * 4);
    for (let x = 0; x < w; x++) {
      const src = ((x - shift + w) % w) * 4;
      const dst = rowStart + x * 4;
      data[dst] = temp[src];
      data[dst + 1] = temp[src + 1];
      data[dst + 2] = temp[src + 2];
    }
  }
}

function applyNoise(data, w, h, intensity) {
  const amount = (intensity / 100) * 40;
  for (let i = 0; i < data.length; i += 4) {
    if (Math.random() < intensity / 300) {
      const n = (Math.random() - 0.5) * amount;
      data[i] = clamp(data[i] + n);
      data[i + 1] = clamp(data[i + 1] + n);
      data[i + 2] = clamp(data[i + 2] + n);
    }
  }
}

function applyVHS(data, w, h, intensity) {
  applyScanlines(data, w, h, intensity * 0.7);
  applyRGBSplit(data, w, h, intensity * 0.5);
  applyGrain(data, w, h, intensity * 0.4);
  // slight color wash
  const t = intensity / 100;
  for (let i = 0; i < data.length; i += 4) {
    data[i] = clamp(data[i] * (1 + t * 0.08));
    data[i + 2] = clamp(data[i + 2] * (1 - t * 0.05));
  }
}

function applyFade(data, w, h, intensity) {
  const t = intensity / 100;
  for (let i = 0; i < data.length; i += 4) {
    data[i] = clamp(lerp(data[i], 200, t * 0.35));
    data[i + 1] = clamp(lerp(data[i + 1], 195, t * 0.35));
    data[i + 2] = clamp(lerp(data[i + 2], 190, t * 0.35));
  }
}

function applyBloom(data, w, h, intensity) {
  const t = intensity / 100;
  for (let i = 0; i < data.length; i += 4) {
    const lum = 0.299 * data[i] + 0.587 * data[i + 1] + 0.114 * data[i + 2];
    if (lum > 160) {
      const boost = 1 + t * 0.35;
      data[i] = clamp(data[i] * boost);
      data[i + 1] = clamp(data[i + 1] * boost);
      data[i + 2] = clamp(data[i + 2] * boost);
    }
  }
}

function applyPosterize(data, w, h, intensity) {
  const levels = Math.max(2, Math.round(8 - (intensity / 100) * 6));
  const step = 255 / levels;
  for (let i = 0; i < data.length; i += 4) {
    data[i] = clamp(Math.round(data[i] / step) * step);
    data[i + 1] = clamp(Math.round(data[i + 1] / step) * step);
    data[i + 2] = clamp(Math.round(data[i + 2] / step) * step);
  }
}

function applyInvert(data, w, h, intensity) {
  const t = intensity / 100;
  for (let i = 0; i < data.length; i += 4) {
    data[i] = clamp(lerp(data[i], 255 - data[i], t));
    data[i + 1] = clamp(lerp(data[i + 1], 255 - data[i + 1], t));
    data[i + 2] = clamp(lerp(data[i + 2], 255 - data[i + 2], t));
  }
}

function applyChromatic(data, w, h, intensity) {
  const shift = Math.max(1, Math.round((intensity / 100) * 5));
  const copy = new Uint8ClampedArray(data);
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const i = (y * w + x) * 4;
      const xr = Math.min(w - 1, x + shift);
      const xb = Math.max(0, x - shift);
      data[i] = copy[(y * w + xr) * 4];
      data[i + 1] = copy[i + 1];
      data[i + 2] = copy[(y * w + xb) * 4 + 2];
    }
  }
}

/**
 * Apply effect to ImageData
 */
function applyEffect(imageData, effectId, intensity = 50) {
  const effect = EFFECTS.find(e => e.id === effectId);
  if (!effect || !effect.fn || intensity <= 0) return imageData;
  effect.fn(imageData.data, imageData.width, imageData.height, intensity);
  return imageData;
}

window.VynoxEffects = { EFFECTS, applyEffect };
