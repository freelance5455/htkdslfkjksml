/**
 * Vynox Camera X — Photo Editor (Phase 3)
 * Rotate, flip, color, text, stickers, basic crop, undo/redo, export
 */

class VynoxEditor {
  constructor() {
    this.canvas = null;
    this.ctx = null;
    this.sourceImage = null;
    this.history = [];
    this.historyIndex = -1;
    this.adjustments = {
      brightness: 0,
      contrast: 0,
      saturation: 0,
      rotation: 0,
      flipH: false,
      flipV: false
    };
    this.textOverlays = [];
    this.stickerOverlays = [];
    this.crop = null;
    this.frameStyle = 'none';
    this.brushing = false;
    this.brushColor = '#ff3344';
    this.brushSize = 4;
    this.onUpdate = null;
  }

  init(canvasEl) {
    this.canvas = canvasEl;
    this.ctx = canvasEl.getContext('2d');
  }

  loadFromUrl(url) {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.onload = () => {
        this.sourceImage = img;
        this.adjustments = { brightness: 0, contrast: 0, saturation: 0, rotation: 0, flipH: false, flipV: false };
        this.textOverlays = [];
        this.stickerOverlays = [];
        this.crop = null;
        this.history = [];
        this.historyIndex = -1;
        this.render();
        this._pushHistory();
        resolve(true);
      };
      img.onerror = reject;
      img.src = url;
    });
  }

  loadFromBlob(blob) {
    return this.loadFromUrl(URL.createObjectURL(blob));
  }

  setAdjustment(key, value) {
    this.adjustments[key] = value;
    this.render();
  }

  rotate(deg) {
    this.adjustments.rotation = (this.adjustments.rotation + deg + 360) % 360;
    this.render();
    this._pushHistory();
  }

  flip(axis) {
    if (axis === 'h') this.adjustments.flipH = !this.adjustments.flipH;
    else this.adjustments.flipV = !this.adjustments.flipV;
    this.render();
    this._pushHistory();
  }

  addText(text, color, size) {
    if (!text) return;
    color = color || '#ffffff';
    size = size || 36;
    const x = (this.canvas.width || 400) / 2;
    const y = (this.canvas.height || 400) * 0.85;
    this.textOverlays.push({ text: text, x: x, y: y, size: size, color: color });
    this.render();
    this._pushHistory();
  }

  addSticker(emoji, size) {
    size = size || 64;
    const x = (this.canvas.width || 400) / 2;
    const y = (this.canvas.height || 400) / 2;
    this.stickerOverlays.push({ emoji: emoji, x: x, y: y, size: size });
    this.render();
    this._pushHistory();
  }

  applyCenterCrop(ratio) {
    ratio = ratio || 0.8;
    if (!this.sourceImage) return;
    const w = this.sourceImage.width;
    const h = this.sourceImage.height;
    const cw = w * ratio;
    const ch = h * ratio;
    this.crop = { x: (w - cw) / 2, y: (h - ch) / 2, w: cw, h: ch };
    this.render();
    this._pushHistory();
  }

  clearCrop() {
    this.crop = null;
    this.render();
    this._pushHistory();
  }

  reset() {
    this.adjustments = { brightness: 0, contrast: 0, saturation: 0, rotation: 0, flipH: false, flipV: false };
    this.textOverlays = [];
    this.stickerOverlays = [];
    this.crop = null;
    this.render();
    this._pushHistory();
  }

  undo() {
    if (this.historyIndex > 0) {
      this.historyIndex--;
      this._restoreState(this.history[this.historyIndex]);
      this.render();
    }
  }

  redo() {
    if (this.historyIndex < this.history.length - 1) {
      this.historyIndex++;
      this._restoreState(this.history[this.historyIndex]);
      this.render();
    }
  }

  _snapshot() {
    return {
      adjustments: JSON.parse(JSON.stringify(this.adjustments)),
      textOverlays: JSON.parse(JSON.stringify(this.textOverlays)),
      stickerOverlays: JSON.parse(JSON.stringify(this.stickerOverlays)),
      crop: this.crop ? Object.assign({}, this.crop) : null
    };
  }

  _restoreState(snap) {
    this.adjustments = JSON.parse(JSON.stringify(snap.adjustments));
    this.textOverlays = JSON.parse(JSON.stringify(snap.textOverlays || []));
    this.stickerOverlays = JSON.parse(JSON.stringify(snap.stickerOverlays || []));
    this.crop = snap.crop ? Object.assign({}, snap.crop) : null;
  }

  _pushHistory() {
    this.history = this.history.slice(0, this.historyIndex + 1);
    this.history.push(this._snapshot());
    this.historyIndex = this.history.length - 1;
    if (this.history.length > 25) {
      this.history.shift();
      this.historyIndex--;
    }
  }

  commitAdjustments() {
    this._pushHistory();
  }

  render() {
    if (!this.sourceImage || !this.canvas) return;
    const img = this.sourceImage;
    const rot = this.adjustments.rotation;
    const swap = rot === 90 || rot === 270;

    var srcX = 0, srcY = 0, srcW = img.width, srcH = img.height;
    if (this.crop) {
      srcX = this.crop.x;
      srcY = this.crop.y;
      srcW = this.crop.w;
      srcH = this.crop.h;
    }

    const w = swap ? srcH : srcW;
    const h = swap ? srcW : srcH;
    this.canvas.width = w;
    this.canvas.height = h;

    this.ctx.save();
    this.ctx.translate(w / 2, h / 2);
    this.ctx.rotate((rot * Math.PI) / 180);
    if (this.adjustments.flipH) this.ctx.scale(-1, 1);
    if (this.adjustments.flipV) this.ctx.scale(1, -1);
    this.ctx.drawImage(img, srcX, srcY, srcW, srcH, -srcW / 2, -srcH / 2, srcW, srcH);
    this.ctx.restore();

    const b = this.adjustments.brightness;
    const c = this.adjustments.contrast;
    const s = this.adjustments.saturation;
    if (b !== 0 || c !== 0 || s !== 0) {
      const imageData = this.ctx.getImageData(0, 0, w, h);
      const data = imageData.data;
      const contrastFactor = (259 * (c + 255)) / (255 * (259 - c));
      for (var i = 0; i < data.length; i += 4) {
        var r = data[i], g = data[i + 1], bl = data[i + 2];
        r += b; g += b; bl += b;
        r = contrastFactor * (r - 128) + 128;
        g = contrastFactor * (g - 128) + 128;
        bl = contrastFactor * (bl - 128) + 128;
        var gray = 0.299 * r + 0.587 * g + 0.114 * bl;
        r = gray + (r - gray) * (1 + s / 100);
        g = gray + (g - gray) * (1 + s / 100);
        bl = gray + (bl - gray) * (1 + s / 100);
        data[i] = r < 0 ? 0 : r > 255 ? 255 : r;
        data[i + 1] = g < 0 ? 0 : g > 255 ? 255 : g;
        data[i + 2] = bl < 0 ? 0 : bl > 255 ? 255 : bl;
      }
      this.ctx.putImageData(imageData, 0, 0);
    }

    var self = this;
    this.stickerOverlays.forEach(function(st) {
      self.ctx.font = st.size + 'px serif';
      self.ctx.textAlign = 'center';
      self.ctx.textBaseline = 'middle';
      self.ctx.fillText(st.emoji, st.x, st.y);
    });

    this.textOverlays.forEach(function(t) {
      self.ctx.font = 'bold ' + t.size + 'px Inter, sans-serif';
      self.ctx.textAlign = 'center';
      self.ctx.textBaseline = 'middle';
      self.ctx.strokeStyle = 'rgba(0,0,0,0.5)';
      self.ctx.lineWidth = 3;
      self.ctx.strokeText(t.text, t.x, t.y);
      self.ctx.fillStyle = t.color || '#fff';
      self.ctx.fillText(t.text, t.x, t.y);
    });

    // frame overlay
    if (this.frameStyle && this.frameStyle !== 'none') {
      const w = this.canvas.width, h = this.canvas.height;
      const ctx = this.ctx;
      if (this.frameStyle === 'white') {
        ctx.strokeStyle = '#fff'; ctx.lineWidth = Math.max(8, w * 0.02);
        ctx.strokeRect(4, 4, w - 8, h - 8);
      } else if (this.frameStyle === 'black') {
        ctx.strokeStyle = '#111'; ctx.lineWidth = Math.max(10, w * 0.025);
        ctx.strokeRect(4, 4, w - 8, h - 8);
      } else if (this.frameStyle === 'polaroid') {
        const m = Math.max(12, w * 0.04);
        const bottom = Math.max(28, h * 0.1);
        ctx.fillStyle = '#f5f5f0';
        ctx.fillRect(0, 0, w, m);
        ctx.fillRect(0, 0, m, h);
        ctx.fillRect(w - m, 0, m, h);
        ctx.fillRect(0, h - bottom, w, bottom);
      }
    }

    if (this.onUpdate) this.onUpdate();
  }


  applyFrame(style) {
    // style: 'white' | 'black' | 'polaroid' | 'none'
    this.frameStyle = style || 'none';
    this.render();
    this._pushHistory();
  }

  startBrush(color, size) {
    this.brushColor = color || '#ff3344';
    this.brushSize = size || 4;
    this.brushing = true;
  }

  stopBrush() {
    this.brushing = false;
    this._pushHistory();
  }

  brushStroke(x1, y1, x2, y2) {
    if (!this.ctx) return;
    this.ctx.strokeStyle = this.brushColor || '#ff3344';
    this.ctx.lineWidth = this.brushSize || 4;
    this.ctx.lineCap = 'round';
    this.ctx.beginPath();
    this.ctx.moveTo(x1, y1);
    this.ctx.lineTo(x2, y2);
    this.ctx.stroke();
  }

  exportBlob(quality) {
    quality = quality || 0.92;
    var self = this;
    return new Promise(function(resolve) {
      self.canvas.toBlob(function(blob) { resolve(blob); }, 'image/jpeg', quality);
    });
  }
}

window.VynoxEditor = VynoxEditor;
