/**
 * Vynox Camera X — IndexedDB Storage (Phase 2)
 * Persistent local gallery. No server.
 */

const DB_NAME = 'vynox_camera_x';
const DB_VERSION = 1;
const STORE_MEDIA = 'media';

let dbPromise = null;

function openDB() {
  if (dbPromise) return dbPromise;
  dbPromise = new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onerror = () => reject(req.error);
    req.onsuccess = () => resolve(req.result);
    req.onupgradeneeded = (e) => {
      const db = e.target.result;
      if (!db.objectStoreNames.contains(STORE_MEDIA)) {
        const store = db.createObjectStore(STORE_MEDIA, { keyPath: 'id' });
        store.createIndex('created', 'created', { unique: false });
        store.createIndex('type', 'type', { unique: false });
        store.createIndex('favorite', 'favorite', { unique: false });
      }
    };
  });
  return dbPromise;
}

async function saveMediaItem(item) {
  // item: { id, type, blob, filter?, created, favorite }
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_MEDIA, 'readwrite');
    const store = tx.objectStore(STORE_MEDIA);
    // Store blob directly
    store.put({
      id: item.id,
      type: item.type,
      blob: item.blob,
      filter: item.filter || null,
      created: item.created || Date.now(),
      favorite: !!item.favorite
    });
    tx.oncomplete = () => resolve(true);
    tx.onerror = () => reject(tx.error);
  });
}

async function loadAllMedia() {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_MEDIA, 'readonly');
    const store = tx.objectStore(STORE_MEDIA);
    const req = store.getAll();
    req.onsuccess = () => {
      const rows = req.result || [];
      // newest first
      rows.sort((a, b) => (b.created || 0) - (a.created || 0));
      const items = rows.map(row => {
        const url = URL.createObjectURL(row.blob);
        return {
          id: row.id,
          type: row.type,
          blob: row.blob,
          url,
          filter: row.filter,
          created: row.created,
          favorite: row.favorite
        };
      });
      resolve(items);
    };
    req.onerror = () => reject(req.error);
  });
}

async function deleteMediaItem(id) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_MEDIA, 'readwrite');
    tx.objectStore(STORE_MEDIA).delete(id);
    tx.oncomplete = () => resolve(true);
    tx.onerror = () => reject(tx.error);
  });
}

async function toggleFavorite(id, value) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_MEDIA, 'readwrite');
    const store = tx.objectStore(STORE_MEDIA);
    const req = store.get(id);
    req.onsuccess = () => {
      const row = req.result;
      if (!row) { resolve(false); return; }
      row.favorite = value;
      store.put(row);
    };
    tx.oncomplete = () => resolve(true);
    tx.onerror = () => reject(tx.error);
  });
}

async function clearAllMedia() {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_MEDIA, 'readwrite');
    tx.objectStore(STORE_MEDIA).clear();
    tx.oncomplete = () => resolve(true);
    tx.onerror = () => reject(tx.error);
  });
}

window.VynoxStorage = {
  saveMediaItem,
  loadAllMedia,
  deleteMediaItem,
  toggleFavorite,
  clearAllMedia
};
