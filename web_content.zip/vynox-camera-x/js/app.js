/**
 * Vynox Camera X — Main Application (Phase 2)
 * Offline-first camera + filters + effects + editor + IndexedDB gallery
 */

(function () {
  'use strict';

  const state = {
    firstLaunch: true,
    theme: 'obsidian',
    currentView: 'camera',
    currentFilter: 'normal',
    filterIntensity: 80,
    currentEffect: 'none',
    effectIntensity: 50,
    filterCategory: 'all',
    media: [],
    cameraReady: false,
    permissions: { camera: false, mic: false },
    editingItemId: null
  };

  let camera = null;
  let editor = null;
  let faceEngine = null;
  let onboardSlide = 0;

  const $ = (sel) => document.querySelector(sel);
  const $$ = (sel) => document.querySelectorAll(sel);

  // ---------- Storage helpers ----------
  function loadState() {
    try {
      const raw = localStorage.getItem('vynox_p2');
      if (raw) {
        const saved = JSON.parse(raw);
        state.firstLaunch = saved.firstLaunch !== false;
        state.theme = saved.theme || 'obsidian';
        state.filterIntensity = saved.filterIntensity ?? 80;
        state.effectIntensity = saved.effectIntensity ?? 50;
      }
    } catch (_) {}
  }

  function saveState() {
    try {
      localStorage.setItem('vynox_p2', JSON.stringify({
        firstLaunch: state.firstLaunch,
        theme: state.theme,
        filterIntensity: state.filterIntensity,
        effectIntensity: state.effectIntensity
      }));
    } catch (_) {}
  }

  // ---------- Toast ----------
  let toastTimer = null;
  function toast(msg, ms = 2200) {
    const el = $('#toast');
    if (!el) return;
    el.textContent = msg;
    el.classList.remove('hidden');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => el.classList.add('hidden'), ms);
  }

  // ---------- Theme ----------
  function applyTheme(name) {
    document.body.className = 'theme-' + name;
    state.theme = name;
    $$('.theme-opt').forEach(b => b.classList.toggle('active', b.dataset.theme === name));
    saveState();
  }

  // ---------- Navigation ----------
  function showScreen(id) {
    $$('.screen').forEach(s => s.classList.add('hidden'));
    const el = document.getElementById(id);
    if (el) el.classList.remove('hidden');
  }

  function switchView(view) {
    state.currentView = view;
    $$('.view').forEach(v => v.classList.remove('active'));
    const target = document.getElementById('view-' + view);
    if (target) target.classList.add('active');
    $$('.nav-btn').forEach(b => b.classList.toggle('active', b.dataset.view === view));

    if (view === 'camera') {
      if (camera && !camera.isRunning) camera.start();
    }
    if (view === 'filters') renderFilters();
    if (view === 'gallery') renderGallery();
  }

  // ---------- Splash → Onboarding → Permissions → App ----------
  function startFlow() {
    loadState();
    applyTheme(state.theme);
    showScreen('splash');
    setTimeout(() => {
      if (state.firstLaunch) {
        showScreen('onboarding');
        setupOnboarding();
      } else {
        enterApp();
      }
    }, 1500);
  }

  function setupOnboarding() {
    onboardSlide = 0;
    updateOnboardUI();
    $('#btn-next').onclick = () => {
      if (onboardSlide < 2) {
        onboardSlide++;
        updateOnboardUI();
        if (onboardSlide === 2) $('#btn-next').textContent = 'Get Started';
      } else finishOnboarding();
    };
    $('#btn-skip').onclick = finishOnboarding;

    let startX = 0;
    const slides = $('.onboard-slides');
    if (slides) {
      slides.addEventListener('touchstart', e => { startX = e.touches[0].clientX; }, { passive: true });
      slides.addEventListener('touchend', e => {
        const dx = e.changedTouches[0].clientX - startX;
        if (dx < -50 && onboardSlide < 2) {
          onboardSlide++;
          updateOnboardUI();
          if (onboardSlide === 2) $('#btn-next').textContent = 'Get Started';
        } else if (dx > 50 && onboardSlide > 0) {
          onboardSlide--;
          updateOnboardUI();
          $('#btn-next').textContent = 'आगे';
        }
      }, { passive: true });
    }
  }

  function updateOnboardUI() {
    $$('.onboard-slide').forEach((s, i) => s.classList.toggle('active', i === onboardSlide));
    $$('.dot').forEach((d, i) => d.classList.toggle('active', i === onboardSlide));
  }

  function finishOnboarding() {
    state.firstLaunch = false;
    saveState();
    showScreen('permissions');
    setupPermissions();
  }

  function setupPermissions() {
    const status = $('#perm-status');
    const btnContinue = $('#btn-perm-continue');

    $$('.btn-perm').forEach(btn => {
      btn.onclick = async () => {
        const type = btn.dataset.perm;
        if (type === 'camera') {
          try {
            const stream = await navigator.mediaDevices.getUserMedia({ video: true });
            stream.getTracks().forEach(t => t.stop());
            state.permissions.camera = true;
            btn.classList.add('granted');
            btn.textContent = '✓ मिल गई';
            status.textContent = 'कैमरा अनुमति मिल गई';
            checkPermsDone();
          } catch (err) {
            status.textContent = 'कैमरा अनुमति नहीं मिली। Settings से चालू करें।';
            toast('कैमरा अनुमति आवश्यक है');
          }
        } else if (type === 'mic') {
          try {
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            stream.getTracks().forEach(t => t.stop());
            state.permissions.mic = true;
            btn.classList.add('granted');
            btn.textContent = '✓ मिल गई';
            status.textContent = 'माइक अनुमति मिल गई';
            checkPermsDone();
          } catch (err) {
            status.textContent = 'माइक अनुमति नहीं मिली (वीडियो के लिए वैकल्पिक)';
            checkPermsDone();
          }
        }
      };
    });

    function checkPermsDone() {
      if (state.permissions.camera) btnContinue.classList.remove('hidden');
    }
    btnContinue.onclick = enterApp;
    $('#btn-perm-later').onclick = enterApp;
  }

  async function enterApp() {
    showScreen('app');
    switchView('camera');
    await loadGalleryFromDB();
    initCamera();
    initEditor();
    renderFilters();
    renderGallery();
    setupMainUI();
  }

  // ---------- IndexedDB Gallery ----------
  async function loadGalleryFromDB() {
    try {
      if (window.VynoxStorage) {
        state.media = await window.VynoxStorage.loadAllMedia();
      }
    } catch (e) {
      console.warn('Gallery load failed', e);
      state.media = [];
    }
  }

  async function persistMedia(item) {
    try {
      if (window.VynoxStorage) await window.VynoxStorage.saveMediaItem(item);
    } catch (e) {
      console.warn('Save failed', e);
    }
  }

  // ---------- Camera ----------
  async function initCamera() {
    camera = new VynoxCamera();
    camera.init($('#camera-video'), $('#camera-canvas'));

    // Apply effect after filter in render — patch via setFilter wrapper
    const origSetFilter = camera.setFilter.bind(camera);
    camera.setFilter = (id, intensity) => {
      origSetFilter(id, intensity);
    };

    camera.onPhotoCaptured = async (item) => {
      // apply current effect if any
      if (state.currentEffect && state.currentEffect !== 'none' && item.blob) {
        try {
          item = await applyEffectToBlob(item, state.currentEffect, state.effectIntensity);
        } catch (_) {}
      }
      // apply custom filter definition if selected
      if (state._customDef && item.blob && window.VynoxCreator) {
        try {
          item = await applyCustomToBlob(item, state._customDef);
        } catch (_) {}
      }
      state.media.unshift(item);
      await persistMedia(item);
      renderGallery();
      toast('फोटो सेव हो गई');
      updateGalleryThumb(item);
    };

    camera.onVideoRecorded = async (item) => {
      state.media.unshift(item);
      await persistMedia(item);
      renderGallery();
      toast('वीडियो सेव हो गई');
    };

    if (window.VynoxFace) {
      faceEngine = new window.VynoxFace.FaceStickerEngine();
      camera.setFaceEngine(faceEngine);
      // optional MediaPipe (needs network once; then may cache)
      faceEngine.tryInitMediaPipe().then(ok => {
        if (ok) toast('Face tracking चालू');
      }).catch(() => {});
    }
    const ok = await camera.start();
    state.cameraReady = ok;
    if (!ok) {
      const insecure = !(window.isSecureContext);
      const proto = location.protocol || '';
      if (insecure || proto === 'file:' || proto.startsWith('content:')) {
        toast('कैमरा file/content URL पर नहीं चलता। HTTP सर्वर से खोलें (localhost)', 4500);
      } else if (camera.lastError && /NotAllowed|Permission/i.test(camera.lastError)) {
        toast('कैमरा अनुमति नहीं मिली। Settings से Allow करें', 4000);
      } else if (camera.lastError && /NotFound|DevicesNotFound/i.test(camera.lastError)) {
        toast('कोई कैमरा नहीं मिला', 3500);
      } else {
        toast('कैमरा शुरू नहीं हो सका। अनुमति / HTTPS जाँचें', 4000);
      }
    }
  }

  function updateGalleryThumb(item) {
    const thumb = $('#btn-gallery-thumb .thumb-placeholder');
    if (thumb && item.url && item.type === 'photo') {
      thumb.innerHTML = '';
      const img = document.createElement('img');
      img.src = item.url;
      img.style.cssText = 'width:100%;height:100%;object-fit:cover;border-radius:50%;';
      thumb.appendChild(img);
    }
  }

  
  async function applyCustomToBlob(item, def) {
    return new Promise((resolve) => {
      const img = new Image();
      img.onload = () => {
        const c = document.createElement('canvas');
        c.width = img.width;
        c.height = img.height;
        const ctx = c.getContext('2d');
        ctx.drawImage(img, 0, 0);
        const imageData = ctx.getImageData(0, 0, c.width, c.height);
        window.VynoxCreator.applyCustomFilter(imageData, def, 100);
        ctx.putImageData(imageData, 0, 0);
        c.toBlob(blob => {
          if (item.url) URL.revokeObjectURL(item.url);
          const url = URL.createObjectURL(blob);
          resolve(Object.assign({}, item, { blob: blob, url: url, filter: 'custom' }));
        }, 'image/jpeg', 0.92);
      };
      img.onerror = () => resolve(item);
      img.src = item.url;
    });
  }

  async function applyEffectToBlob(item, effectId, intensity) {
    return new Promise((resolve) => {
      const img = new Image();
      img.onload = () => {
        const c = document.createElement('canvas');
        c.width = img.width;
        c.height = img.height;
        const ctx = c.getContext('2d');
        ctx.drawImage(img, 0, 0);
        const imageData = ctx.getImageData(0, 0, c.width, c.height);
        window.VynoxEffects.applyEffect(imageData, effectId, intensity);
        ctx.putImageData(imageData, 0, 0);
        c.toBlob(blob => {
          if (item.url) URL.revokeObjectURL(item.url);
          const url = URL.createObjectURL(blob);
          resolve({ ...item, blob, url });
        }, 'image/jpeg', 0.92);
      };
      img.src = item.url;
    });
  }

  // ---------- Filters + Effects UI ----------
  function renderFilters() {
    const list = $('#filter-list');
    if (!list || !window.VynoxFilters) return;
    list.innerHTML = '';

    const cat = state.filterCategory || 'all';
    const q = (state.filterSearch || '').trim().toLowerCase();

    // Face category → stickers
    if (cat === 'face') {
      const stickers = (window.VynoxFace && window.VynoxFace.FACE_STICKERS) || [];
      stickers.forEach(s => {
        if (s.id === 'none') return;
        if (q && !(s.name + s.id).toLowerCase().includes(q)) return;
        const el = document.createElement('button');
        el.className = 'filter-item' + (faceEngine && faceEngine.activeId === s.id ? ' active' : '');
        el.innerHTML = '<span class="filter-emoji">' + (s.emoji || '😊') + '</span>' +
          '<span class="filter-name">' + s.name + '</span>' +
          '<span class="filter-desc">Face sticker</span>';
        el.onclick = () => {
          if (faceEngine) faceEngine.setSticker(s.id);
          $$('.filter-item').forEach(i => i.classList.remove('active'));
          el.classList.add('active');
          toast(s.name);
        };
        list.appendChild(el);
      });
      return;
    }

    // Custom filters
    if (cat === 'custom') {
      const customs = (window.VynoxCreator && window.VynoxCreator.listSaved) ? window.VynoxCreator.listSaved() : [];
      if (!customs.length) {
        list.innerHTML = '<div class="gallery-empty" style="grid-column:1/-1"><p>कोई custom filter नहीं</p><small>Studio → Creator से बनाएँ</small></div>';
        return;
      }
      customs.forEach(f => {
        if (q && !(f.name || '').toLowerCase().includes(q)) return;
        const el = document.createElement('button');
        el.className = 'filter-item' + (f.id === state.currentFilter ? ' active' : '');
        el.innerHTML = '<span class="filter-emoji">⭐</span><span class="filter-name">' + f.name + '</span><span class="filter-desc">My filter</span>';
        el.onclick = () => {
          state.currentFilter = f.id;
          state._customDef = f.def;
          if (camera) camera.setFilter('normal', state.filterIntensity);
          $$('.filter-item').forEach(i => i.classList.remove('active'));
          el.classList.add('active');
          toast(f.name);
        };
        list.appendChild(el);
      });
      return;
    }

    let items = window.VynoxFilters.FILTERS || [];
    if (cat !== 'all') items = items.filter(f => f.cat === cat);
    if (q) {
      items = items.filter(f =>
        (f.name + ' ' + (f.desc || '') + ' ' + f.id + ' ' + (f.cat || '')).toLowerCase().includes(q)
      );
    }

    // Always show Normal first in All
    items.forEach(f => {
      if (f.id === 'normal' && cat !== 'all' && cat !== 'human') return;
      const el = document.createElement('button');
      el.className = 'filter-item' + (f.id === state.currentFilter ? ' active' : '');
      const thumb = (typeof VYNOX_FILTER_THUMBS !== 'undefined' && VYNOX_FILTER_THUMBS[f.id]) ? VYNOX_FILTER_THUMBS[f.id] : null;
      el.innerHTML =
        (thumb
          ? '<img class="filter-thumb-img" src="' + thumb + '" alt="" loading="lazy">'
          : '<span class="filter-emoji">' + (f.emoji || '✨') + '</span>') +
        '<span class="filter-name">' + f.name + '</span>' +
        '<span class="filter-desc">' + (f.desc || '') + '</span>';
      el.onclick = () => {
        state.currentFilter = f.id;
        state._customDef = null;
        if (camera) camera.setFilter(f.id, state.filterIntensity);
        // clear face sticker when picking color filter
        if (faceEngine && f.id !== 'normal') {
          /* keep sticker optional — don't auto clear */
        }
        $$('.filter-item').forEach(i => i.classList.remove('active'));
        el.classList.add('active');
        toast(f.name);
        saveState();
        renderSnapFilterStrip();
      };
      list.appendChild(el);
    });

    if (!list.children.length) {
      list.innerHTML = '<div class="gallery-empty" style="grid-column:1/-1"><p>कोई filter नहीं मिला</p></div>';
    }
  }


  // ---------- Gallery ----------
  function renderGallery() {
    const grid = $('#gallery-grid');
    if (!grid) return;

    const activeTab = document.querySelector('.gtab.active');
    const tab = activeTab ? activeTab.dataset.gtab : 'all';

    let items = state.media;
    if (tab === 'photos') items = items.filter(m => m.type === 'photo');
    else if (tab === 'videos') items = items.filter(m => m.type === 'video');
    else if (tab === 'fav') items = items.filter(m => m.favorite);

    if (!items.length) {
      grid.innerHTML = `<div class="gallery-empty"><p>अभी कोई मीडिया नहीं</p><small>कैमरा से फोटो लें</small></div>`;
      return;
    }

    grid.innerHTML = '';
    items.forEach(item => {
      const div = document.createElement('div');
      div.className = 'gallery-item';
      if (item.type === 'photo') {
        const img = document.createElement('img');
        img.src = item.url;
        img.alt = 'Photo';
        div.appendChild(img);
      } else {
        const vid = document.createElement('video');
        vid.src = item.url;
        vid.muted = true;
        div.appendChild(vid);
      }
      if (item.favorite) {
        const badge = document.createElement('span');
        badge.className = 'fav-badge';
        badge.textContent = '♥';
        div.appendChild(badge);
      }

      const actions = document.createElement('div');
      actions.className = 'g-actions';
      const favBtn = document.createElement('button');
      favBtn.textContent = item.favorite ? '♥' : '♡';
      favBtn.onclick = async (e) => {
        e.stopPropagation();
        item.favorite = !item.favorite;
        if (window.VynoxStorage) await window.VynoxStorage.toggleFavorite(item.id, item.favorite);
        renderGallery();
      };
      const delBtn = document.createElement('button');
      delBtn.textContent = '✕';
      delBtn.onclick = async (e) => {
        e.stopPropagation();
        if (!confirm('डिलीट करें?')) return;
        if (item.url) URL.revokeObjectURL(item.url);
        state.media = state.media.filter(m => m.id !== item.id);
        if (window.VynoxStorage) await window.VynoxStorage.deleteMediaItem(item.id);
        renderGallery();
        toast('डिलीट हो गया');
      };
      const editBtn = document.createElement('button');
      editBtn.textContent = '✎';
      editBtn.onclick = (e) => {
        e.stopPropagation();
        if (item.type !== 'photo') {
          toast('एडिटर सिर्फ फोटो के लिए');
          return;
        }
        openEditor(item);
      };
      actions.appendChild(favBtn);
      actions.appendChild(editBtn);
      actions.appendChild(delBtn);
      div.appendChild(actions);

      div.onclick = () => {
        if (item.type === 'photo') window.open(item.url, '_blank');
        else {
          const v = document.createElement('video');
          v.src = item.url;
          v.controls = true;
          v.style.cssText = 'position:fixed;inset:0;z-index:100;width:100%;height:100%;background:#000;object-fit:contain';
          v.onclick = () => v.remove();
          document.body.appendChild(v);
          v.play();
        }
      };
      grid.appendChild(div);
    });
  }

  // ---------- Editor ----------
  function initEditor() {
    editor = new VynoxEditor();
    editor.init($('#editor-canvas'));
  }

  async function openEditor(item) {
    state.editingItemId = item.id;
    $('#studio-grid').classList.add('hidden');
    $('#ailab-panel').classList.add('hidden');
    $('#editor-panel').classList.remove('hidden');
    $('#btn-editor-back').classList.remove('hidden');
    switchView('studio');
    await editor.loadFromUrl(item.url);
    // reset sliders
    $('#ed-brightness').value = 0;
    $('#ed-contrast').value = 0;
    $('#ed-saturation').value = 0;
    $('#ed-b-val').textContent = '0';
    $('#ed-c-val').textContent = '0';
    $('#ed-s-val').textContent = '0';
  }

  function closeEditor() {
    ['editor-panel','ailab-panel','creator-panel','face-panel'].forEach(id => {
      const el = document.getElementById(id);
      if (el) el.classList.add('hidden');
    });
    $('#studio-grid').classList.remove('hidden');
    $('#btn-editor-back').classList.add('hidden');
    state.editingItemId = null;
  }

  // ---------- AI Lab (simple local auto enhance) ----------
  async function autoEnhanceLastPhoto() {
    const photo = state.media.find(m => m.type === 'photo');
    if (!photo) {
      toast('पहले कोई फोटो लें');
      return;
    }
    $('#ailab-status').textContent = 'प्रोसेसिंग...';
    try {
      const img = new Image();
      await new Promise((res, rej) => { img.onload = res; img.onerror = rej; img.src = photo.url; });
      const c = document.createElement('canvas');
      c.width = img.width;
      c.height = img.height;
      const ctx = c.getContext('2d');
      ctx.drawImage(img, 0, 0);
      const imageData = ctx.getImageData(0, 0, c.width, c.height);
      const d = imageData.data;

      // simple auto: mild contrast + slight brightness + saturation
      for (let i = 0; i < d.length; i += 4) {
        let r = d[i], g = d[i+1], b = d[i+2];
        r = (r - 128) * 1.15 + 128 + 8;
        g = (g - 128) * 1.15 + 128 + 8;
        b = (b - 128) * 1.15 + 128 + 8;
        const gray = 0.299 * r + 0.587 * g + 0.114 * b;
        r = gray + (r - gray) * 1.12;
        g = gray + (g - gray) * 1.12;
        b = gray + (b - gray) * 1.12;
        d[i] = r < 0 ? 0 : r > 255 ? 255 : r;
        d[i+1] = g < 0 ? 0 : g > 255 ? 255 : g;
        d[i+2] = b < 0 ? 0 : b > 255 ? 255 : b;
      }
      ctx.putImageData(imageData, 0, 0);
      const blob = await new Promise(r => c.toBlob(r, 'image/jpeg', 0.92));
      if (photo.url) URL.revokeObjectURL(photo.url);
      const url = URL.createObjectURL(blob);
      const newItem = {
        id: 'img_' + Date.now(),
        type: 'photo',
        blob,
        url,
        filter: 'auto-enhance',
        created: Date.now(),
        favorite: false
      };
      state.media.unshift(newItem);
      await persistMedia(newItem);
      renderGallery();
      $('#ailab-status').textContent = 'Auto Enhance पूरा — गैलरी में सेव।';
      toast('Auto Enhance हो गया');
    } catch (e) {
      $('#ailab-status').textContent = 'त्रुटि: ' + (e.message || 'failed');
    }
  }

  // ---------- Main UI ----------

  // ---------- Snapchat-style camera filter strip ----------
  const SNAP_FILTER_IDS = [
    'normal', 'bright', 'warm', 'cool', 'vintage', 'cinematic', 'golden', 'sunset',
    'neon', 'cyberpunk', 'tealorange', 'film', 'soft', 'dramatic', 'fire', 'ice',
    'galaxy', 'rainbow', 'bw', 'bliss'
  ];

  function renderSnapFilterStrip() {
    const strip = $('#snap-filter-strip');
    if (!strip || !window.VynoxFilters) return;
    strip.innerHTML = '';
    const all = window.VynoxFilters.FILTERS || [];
    const list = SNAP_FILTER_IDS.map(id => all.find(f => f.id === id)).filter(Boolean);
    // ensure normal first
    list.forEach(f => {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'snap-filter-chip' + (f.id === (state.currentFilter || 'normal') ? ' active' : '');
      btn.dataset.filterId = f.id;
      const th = (typeof VYNOX_FILTER_THUMBS !== 'undefined' && VYNOX_FILTER_THUMBS[f.id]) ? VYNOX_FILTER_THUMBS[f.id] : null;
      btn.innerHTML = th
        ? '<div class="snap-ring"><img class="snap-thumb-img" src="' + th + '" alt=""></div><span class="snap-label">' + f.name + '</span>'
        : '<div class="snap-ring">' + (f.emoji || '✨') + '</div><span class="snap-label">' + f.name + '</span>';
      btn.onclick = () => selectSnapFilter(f.id, btn);
      strip.appendChild(btn);
    });
    // scroll active into center
    requestAnimationFrame(() => {
      const active = strip.querySelector('.snap-filter-chip.active');
      if (active) active.scrollIntoView({ inline: 'center', block: 'nearest', behavior: 'instant' });
    });
  }

  function selectSnapFilter(id, btnEl) {
    state.currentFilter = id;
    state._customDef = null;
    if (camera) camera.setFilter(id, state.filterIntensity);
    const strip = $('#snap-filter-strip');
    if (strip) {
      strip.querySelectorAll('.snap-filter-chip').forEach(c => c.classList.remove('active'));
      if (btnEl) btnEl.classList.add('active');
      else {
        const b = strip.querySelector('[data-filter-id="' + id + '"]');
        if (b) b.classList.add('active');
      }
    }
    // sync filters tab list if open
    try { renderFilters(); } catch (_) {}
    saveState();
  }

  function setupSnapFilterScroll() {
    const strip = $('#snap-filter-strip');
    if (!strip) return;
    let scrollTimer = null;
    strip.addEventListener('scroll', () => {
      if (scrollTimer) clearTimeout(scrollTimer);
      scrollTimer = setTimeout(() => {
        // pick chip closest to center
        const rect = strip.getBoundingClientRect();
        const centerX = rect.left + rect.width / 2;
        let best = null, bestDist = Infinity;
        strip.querySelectorAll('.snap-filter-chip').forEach(chip => {
          const r = chip.getBoundingClientRect();
          const cx = r.left + r.width / 2;
          const d = Math.abs(cx - centerX);
          if (d < bestDist) { bestDist = d; best = chip; }
        });
        if (best && best.dataset.filterId && best.dataset.filterId !== state.currentFilter) {
          selectSnapFilter(best.dataset.filterId, best);
        } else if (best) {
          strip.querySelectorAll('.snap-filter-chip').forEach(c => c.classList.remove('active'));
          best.classList.add('active');
        }
      }, 80);
    }, { passive: true });
  }


  function setupMainUI() {
    renderSnapFilterStrip();
    setupSnapFilterScroll();
    $$('.nav-btn').forEach(btn => {
      btn.onclick = () => switchView(btn.dataset.view);
    });

    const captureBtn = $('#btn-capture');
    captureBtn.onclick = async () => {
      if (!camera || !camera.isRunning) {
        toast(window.isSecureContext ? 'कैमरा तैयार नहीं — अनुमति दें' : 'कैमरा के लिए HTTP सर्वर ज़रूरी (file:// नहीं)');
        return;
      }
      if (camera.mode === 'photo') {
        captureBtn.style.transform = 'scale(0.9)';
        setTimeout(() => captureBtn.style.transform = '', 150);
        await camera.capturePhoto();
      } else {
        if (!camera.isRecording) {
          const ok = await camera.startRecording();
          if (ok) {
            captureBtn.classList.add('recording');
            toast('रिकॉर्डिंग शुरू');
          } else toast((camera && camera.lastError) ? ('रिकॉर्ड फेल: ' + camera.lastError) : 'वीडियो रिकॉर्डिंग सपोर्ट नहीं');
        } else {
          camera.stopRecording();
          captureBtn.classList.remove('recording');
          toast('रिकॉर्डिंग बंद');
        }
      }
    };

    $$('.mode-btn').forEach(btn => {
      btn.onclick = () => {
        $$('.mode-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        const mode = btn.dataset.mode;
        if (camera) {
          camera.setMode(mode);
          captureBtn.classList.toggle('video-mode', mode === 'video');
          $('#camera-mode-label').textContent = mode.toUpperCase();
        }
      };
    });

    $('#btn-flip').onclick = async () => {
      if (!camera) return;
      toast('कैमरा बदल रहा है...');
      await camera.flip();
    };

    $('#btn-filter-quick').onclick = () => switchView('filters');
    $('#btn-gallery-thumb').onclick = () => switchView('gallery');

    // Grid + Level indicator (single handler)
    let levelOn = false;
    const levelEl = $('#level-indicator');
    const horizon = $('#level-horizon');
    function onOrient(e) {
      if (!levelOn || !horizon) return;
      const gamma = e.gamma || 0;
      const clamped = Math.max(-45, Math.min(45, gamma));
      horizon.style.transform = 'rotate(' + clamped + 'deg)';
      horizon.classList.toggle('tilted', Math.abs(gamma) > 3);
    }
    if ($('#btn-grid')) {
      $('#btn-grid').onclick = () => {
        const grid = $('#grid-overlay');
        if (!grid) return;
        const willShow = grid.classList.contains('hidden');
        grid.classList.toggle('hidden', !willShow);
        $('#btn-grid').classList.toggle('active', willShow);
        if (camera) camera.setGrid(willShow);
        levelOn = willShow;
        if (levelEl) levelEl.classList.toggle('hidden', !levelOn);
        if (levelOn && window.DeviceOrientationEvent) {
          window.addEventListener('deviceorientation', onOrient, true);
        }
      };
    }


    let timerIdx = 0;
    const timerValues = [0, 3, 5, 10];
    $('#btn-timer').onclick = () => {
      timerIdx = (timerIdx + 1) % timerValues.length;
      const val = timerValues[timerIdx];
      if (camera) camera.setTimer(val);
      $('#btn-timer').classList.toggle('active', val > 0);
      toast(val === 0 ? 'Timer Off' : `Timer ${val}s`);
    };

    function updateFlashBtn() {
      const btn = $('#btn-flash');
      if (!btn || !camera) return;
      const ok = camera.hasTorch && camera.hasTorch();
      btn.disabled = !ok;
      btn.classList.toggle('active', !!(camera.torchOn));
      btn.title = ok ? (camera.torchOn ? 'Flash ON' : 'Flash OFF') : 'Flash not supported';
    }
    updateFlashBtn();
    // re-check after camera ready
    setTimeout(updateFlashBtn, 800);

    $('#btn-flash').onclick = async () => {
      if (!camera) return;
      if (!camera.hasTorch || !camera.hasTorch()) {
        toast('इस कैमरा/ब्राउज़र पर टॉर्च उपलब्ध नहीं');
        return;
      }
      const ok = await camera.toggleTorch();
      updateFlashBtn();
      toast(ok ? (camera.torchOn ? 'Flash ON' : 'Flash OFF') : 'Flash चालू नहीं हो सका');
    };
    let zoomLv = 1;
    function updateZoom() {
      if (camera && camera.setZoom) camera.setZoom(zoomLv);
      const lab = $('#zoom-label');
      if (lab) lab.textContent = zoomLv.toFixed(1) + 'x';
    }
    if ($('#btn-zoom-in')) {
      $('#btn-zoom-in').onclick = () => { zoomLv = Math.min(3, zoomLv + 0.25); updateZoom(); };
    }
    if ($('#btn-zoom-out')) {
      $('#btn-zoom-out').onclick = () => { zoomLv = Math.max(1, zoomLv - 0.25); updateZoom(); };
    }

    $('#btn-settings').onclick = () => $('#settings-sheet').classList.remove('hidden');
    $('#btn-close-settings').onclick = () => $('#settings-sheet').classList.add('hidden');

    $$('.theme-opt').forEach(btn => {
      btn.onclick = () => applyTheme(btn.dataset.theme);
    });

        state.filterSearch = '';
    const searchEl = $('#filter-search');
    if (searchEl) {
      searchEl.oninput = () => {
        state.filterSearch = searchEl.value || '';
        renderFilters();
      };
    }

    $$('.cat-btn').forEach(btn => {
      btn.onclick = () => {
        $$('.cat-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        state.filterCategory = btn.dataset.cat;
        renderFilters();
      };
    });

    const intensitySlider = $('#filter-intensity');
    if (intensitySlider) {
      intensitySlider.value = state.filterIntensity;
      $('#intensity-value').textContent = state.filterIntensity;
      intensitySlider.oninput = () => {
        state.filterIntensity = +intensitySlider.value;
        $('#intensity-value').textContent = state.filterIntensity;
        if (camera) camera.setIntensity(state.filterIntensity);
        saveState();
      };
    }

    const effectIntensity = $('#effect-intensity');
    if (effectIntensity) {
      effectIntensity.value = state.effectIntensity;
      $('#effect-intensity-value').textContent = state.effectIntensity;
      effectIntensity.oninput = () => {
        state.effectIntensity = +effectIntensity.value;
        $('#effect-intensity-value').textContent = state.effectIntensity;
        saveState();
      };
    }

    $('#btn-filter-reset').onclick = () => {
      state.currentFilter = 'normal';
      state.currentEffect = 'none';
      state.filterIntensity = 80;
      if (intensitySlider) {
        intensitySlider.value = 80;
        $('#intensity-value').textContent = '80';
      }
      if (camera) camera.setFilter('normal', 80);
      renderFilters();
      toast('फ़िल्टर/इफेक्ट रीसेट');
    };

    // Gallery tabs
    $$('.gtab').forEach(tab => {
      tab.onclick = () => {
        $$('.gtab').forEach(t => t.classList.remove('active'));
        tab.classList.add('active');
        renderGallery();
      };
    });

    // Studio cards
    function hideAllStudioPanels() {
      $('#studio-grid').classList.add('hidden');
      ['editor-panel','ailab-panel','creator-panel','face-panel'].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.classList.add('hidden');
      });
      $('#btn-editor-back').classList.remove('hidden');
    }

    $$('.studio-card').forEach(card => {
      card.onclick = () => {
        const action = card.dataset.action;
        if (action === 'themes') {
          $('#settings-sheet').classList.remove('hidden');
        } else if (action === 'editor') {
          hideAllStudioPanels();
          $('#editor-panel').classList.remove('hidden');
          const lastPhoto = state.media.find(m => m.type === 'photo');
          if (lastPhoto) openEditor(lastPhoto);
          else toast('पहले कोई फोटो लें, फिर Gallery से Edit करें');
        } else if (action === 'ailab') {
          hideAllStudioPanels();
          $('#ailab-panel').classList.remove('hidden');
        } else if (action === 'creator') {
          hideAllStudioPanels();
          $('#creator-panel').classList.remove('hidden');
          renderCreatorList();
        } else if (action === 'face') {
          hideAllStudioPanels();
          $('#face-panel').classList.remove('hidden');
          renderFaceStickers();
        }
      };
    });

    // Face stickers panel
    function renderFaceStickers() {
      const list = $('#face-sticker-list');
      if (!list || !window.VynoxFace) return;
      list.innerHTML = '';
      window.VynoxFace.FACE_STICKERS.forEach(s => {
        const el = document.createElement('button');
        el.className = 'filter-item' + (faceEngine && faceEngine.activeId === s.id ? ' active' : '');
        el.innerHTML = '<div class="filter-thumb" style="display:flex;align-items:center;justify-content:center;font-size:28px">' + s.emoji + '</div><span class="filter-name">' + s.name + '</span>';
        el.onclick = () => {
          if (faceEngine) faceEngine.setSticker(s.id);
          renderFaceStickers();
          toast(s.name);
        };
        list.appendChild(el);
      });
    }
    const faceScale = $('#face-scale');
    if (faceScale) {
      faceScale.oninput = () => {
        const v = +faceScale.value;
        $('#face-scale-val').textContent = v + '%';
        if (faceEngine) faceEngine.setScale(v / 100);
      };
    }
    if ($('#face-clear')) {
      $('#face-clear').onclick = () => {
        if (faceEngine) faceEngine.setSticker('none');
        renderFaceStickers();
        toast('Sticker हटाया');
      };
    }

    // Filter Creator
    function crVal(id) { return +($(id).value || 0); }
    function bindCr(id, spanId) {
      const el = $(id);
      if (!el) return;
      el.oninput = () => { $(spanId).textContent = el.value; };
    }
    ['brightness','contrast','saturation'].forEach((k,i) => {
      const map = {brightness:['#cr-brightness','#cr-b'],contrast:['#cr-contrast','#cr-c'],saturation:['#cr-saturation','#cr-s']};
    });
    bindCr('#cr-brightness','#cr-b');
    bindCr('#cr-contrast','#cr-c');
    bindCr('#cr-saturation','#cr-s');
    bindCr('#cr-temp','#cr-t');
    bindCr('#cr-tint','#cr-ti');
    bindCr('#cr-vignette','#cr-v');
    bindCr('#cr-grain','#cr-g');

    function renderCreatorList() {
      const box = $('#cr-list');
      if (!box || !window.VynoxCreator) return;
      const list = window.VynoxCreator.loadCustomFilters();
      if (!list.length) { box.innerHTML = '<p style="color:var(--text-muted);font-size:13px">कोई सेव्ड फ़िल्टर नहीं</p>'; return; }
      box.innerHTML = list.map(f => '<div style="display:flex;justify-content:space-between;align-items:center;padding:8px 0;border-bottom:1px solid var(--border)"><span>' + f.name + '</span><button data-del="' + f.id + '" class="btn-text" style="color:#f66">Delete</button></div>').join('');
      box.querySelectorAll('[data-del]').forEach(btn => {
        btn.onclick = () => {
          window.VynoxCreator.deleteCustomFilter(btn.dataset.del);
          renderCreatorList();
          toast('डिलीट');
        };
      });
    }

    if ($('#cr-save')) {
      $('#cr-save').onclick = () => {
        const name = ($('#cr-name').value || '').trim() || 'My Filter';
        const def = {
          brightness: crVal('#cr-brightness'),
          contrast: crVal('#cr-contrast'),
          saturation: crVal('#cr-saturation'),
          temperature: crVal('#cr-temp'),
          tint: crVal('#cr-tint'),
          vignette: crVal('#cr-vignette'),
          grain: crVal('#cr-grain')
        };
        window.VynoxCreator.createCustomFilter(name, def);
        renderCreatorList();
        toast('फ़िल्टर सेव: ' + name);
        $('#cr-name').value = '';
      };
    }

    $('#btn-editor-back').onclick = closeEditor;

    // Editor controls
    $('#ed-rotate').onclick = () => editor && editor.rotate(90);
    $('#ed-flip-h').onclick = () => editor && editor.flip('h');
    $('#ed-flip-v').onclick = () => editor && editor.flip('v');
    $('#ed-undo').onclick = () => editor && editor.undo();
    $('#ed-redo').onclick = () => editor && editor.redo();
    $('#ed-reset').onclick = () => {
      if (!editor) return;
      editor.reset();
      $('#ed-brightness').value = 0;
      $('#ed-contrast').value = 0;
      $('#ed-saturation').value = 0;
      $('#ed-b-val').textContent = '0';
      $('#ed-c-val').textContent = '0';
      $('#ed-s-val').textContent = '0';
    };

    function bindSlider(id, key, valId) {
      const el = $(id);
      if (!el) return;
      el.oninput = () => {
        const v = +el.value;
        $(valId).textContent = v;
        if (editor) editor.setAdjustment(key, v);
      };
      el.onchange = () => editor && editor.commitAdjustments();
    }
    bindSlider('#ed-brightness', 'brightness', '#ed-b-val');
    bindSlider('#ed-contrast', 'contrast', '#ed-c-val');
    bindSlider('#ed-saturation', 'saturation', '#ed-s-val');

    $('#ed-save').onclick = async () => {
      if (!editor) return;
      const blob = await editor.exportBlob();
      if (!blob) { toast('सेव फेल'); return; }
      const url = URL.createObjectURL(blob);
      const newItem = {
        id: 'img_' + Date.now(),
        type: 'photo',
        blob,
        url,
        filter: 'edited',
        created: Date.now(),
        favorite: false
      };
      state.media.unshift(newItem);
      await persistMedia(newItem);
      renderGallery();
      toast('एडिटेड फोटो सेव हो गई');
      closeEditor();
      switchView('gallery');
    };

    
    // Editor Phase 3 tools

    let frameIdx = 0;
    const frames = ['none', 'white', 'black', 'polaroid'];
    if ($('#ed-frame')) {
      $('#ed-frame').onclick = () => {
        frameIdx = (frameIdx + 1) % frames.length;
        if (editor && editor.applyFrame) editor.applyFrame(frames[frameIdx]);
        toast('Frame: ' + frames[frameIdx]);
      };
    }
    let brushMode = false;
    let lastBrush = null;
    if ($('#ed-brush')) {
      $('#ed-brush').onclick = () => {
        brushMode = !brushMode;
        $('#ed-brush').classList.toggle('active', brushMode);
        toast(brushMode ? 'Brush ON — खींचकर ड्रॉ करें' : 'Brush OFF');
      };
    }
    const edCanvas = $('#editor-canvas');
    if (edCanvas) {
      edCanvas.addEventListener('pointerdown', (e) => {
        if (!brushMode || !editor) return;
        const rect = edCanvas.getBoundingClientRect();
        const scaleX = edCanvas.width / rect.width;
        const scaleY = edCanvas.height / rect.height;
        lastBrush = { x: (e.clientX - rect.left) * scaleX, y: (e.clientY - rect.top) * scaleY };
        edCanvas.setPointerCapture(e.pointerId);
      });
      edCanvas.addEventListener('pointermove', (e) => {
        if (!brushMode || !editor || !lastBrush) return;
        const rect = edCanvas.getBoundingClientRect();
        const scaleX = edCanvas.width / rect.width;
        const scaleY = edCanvas.height / rect.height;
        const x = (e.clientX - rect.left) * scaleX;
        const y = (e.clientY - rect.top) * scaleY;
        editor.brushStroke(lastBrush.x, lastBrush.y, x, y);
        lastBrush = { x, y };
      });
      edCanvas.addEventListener('pointerup', () => {
        if (brushMode && editor && editor.stopBrush) editor.stopBrush();
        lastBrush = null;
      });
    }


    if ($('#ed-add-text')) {
      $('#ed-add-text').onclick = () => {
        const t = ($('#ed-text-input').value || '').trim();
        if (!t) { toast('टेक्स्ट लिखें'); return; }
        if (editor) editor.addText(t);
        $('#ed-text-input').value = '';
        toast('टेक्स्ट जोड़ा');
      };
    }
    if ($('#ed-crop')) {
      $('#ed-crop').onclick = () => {
        if (editor) editor.applyCenterCrop(0.85);
        toast('Center crop');
      };
    }
    // Editor stickers row
    (function() {
      const row = $('#ed-sticker-row');
      if (!row) return;
      const emojis = ['😀','🔥','❤️','⭐','✨','🎉','👍','🌸'];
      emojis.forEach(em => {
        const b = document.createElement('button');
        b.className = 'tool-btn';
        b.textContent = em;
        b.style.fontSize = '18px';
        b.onclick = () => { if (editor) editor.addSticker(em); toast(em); };
        row.appendChild(b);
      });
    })();

    
    // Performance mode
    if ($('#set-perf')) {
      $('#set-perf').onchange = (e) => {
        if (camera && camera.setPerformance) camera.setPerformance(e.target.value);
        toast('Performance: ' + e.target.value);
      };
    }

// AI Lab
    $('#btn-auto-enhance').onclick = autoEnhanceLastPhoto;
    $('#btn-auto-contrast').onclick = async () => {
      // reuse similar logic with stronger contrast
      const photo = state.media.find(m => m.type === 'photo');
      if (!photo) { toast('पहले फोटो लें'); return; }
      try {
        const img = new Image();
        await new Promise((res, rej) => { img.onload = res; img.onerror = rej; img.src = photo.url; });
        const c = document.createElement('canvas');
        c.width = img.width; c.height = img.height;
        const ctx = c.getContext('2d');
        ctx.drawImage(img, 0, 0);
        const imageData = ctx.getImageData(0, 0, c.width, c.height);
        const d = imageData.data;
        for (let i = 0; i < d.length; i += 4) {
          d[i] = Math.min(255, Math.max(0, (d[i] - 128) * 1.35 + 128));
          d[i+1] = Math.min(255, Math.max(0, (d[i+1] - 128) * 1.35 + 128));
          d[i+2] = Math.min(255, Math.max(0, (d[i+2] - 128) * 1.35 + 128));
        }
        ctx.putImageData(imageData, 0, 0);
        const blob = await new Promise(r => c.toBlob(r, 'image/jpeg', 0.92));
        const url = URL.createObjectURL(blob);
        const newItem = { id: 'img_' + Date.now(), type: 'photo', blob, url, filter: 'auto-contrast', created: Date.now(), favorite: false };
        state.media.unshift(newItem);
        await persistMedia(newItem);
        renderGallery();
        toast('Auto Contrast हो गया');
        $('#ailab-status').textContent = 'Contrast अपडेट सेव हो गया।';
      } catch (e) {
        toast('त्रुटि');
      }
    };

    // Settings
    $('#set-grid').onchange = (e) => {
      const on = e.target.checked;
      const grid = $('#grid-overlay');
      if (on) grid.classList.remove('hidden');
      else grid.classList.add('hidden');
      $('#btn-grid').classList.toggle('active', on);
    };
    $('#set-timer').onchange = (e) => {
      const val = +e.target.value;
      if (camera) camera.setTimer(val);
      timerIdx = timerValues.indexOf(val);
      if (timerIdx < 0) timerIdx = 0;
    };
  }

  // ---------- Boot ----------
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', startFlow);
  } else {
    startFlow();
  }
})();
