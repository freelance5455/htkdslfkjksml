/**
 * Vynox Camera X — Camera Module (Phase 1)
 * Real getUserMedia + canvas processing
 */

class VynoxCamera {
  constructor() {
    this.video = null;
    this.canvas = null;
    this.ctx = null;
    this.stream = null;
    this.facingMode = 'environment';
    this.isRunning = false;
    this.isRecording = false;
    this.mediaRecorder = null;
    this.recordedChunks = [];
    this.currentFilter = 'normal';
    this.filterIntensity = 80;
    this.animationId = null;
    this.mode = 'photo'; // photo | video
    this.timerSeconds = 0;
    this.gridEnabled = false;
    this.recStartTime = 0;
    this.recTimerInterval = null;
    this.onPhotoCaptured = null;
    this.onVideoRecorded = null;
    this.faceEngine = null;
    this.performanceMode = 'balanced';
    this.zoomLevel = 1;
    this._videoTrack = null;
  }

  init(videoEl, canvasEl) {
    this.video = videoEl;
    this.canvas = canvasEl;
    this.ctx = canvasEl.getContext('2d', { willReadFrequently: true });
  }

  async start() {
    if (this.isRunning) return true;
    try {
      const constraints = {
        video: {
          facingMode: this.facingMode,
          width: { ideal: 1280 },
          height: { ideal: 720 }
        },
        // always request audio so video recording can include mic
        audio: true
      };
      try {
        this.stream = await navigator.mediaDevices.getUserMedia(constraints);
      } catch (e) {
        // fallback without audio
        constraints.audio = false;
        this.stream = await navigator.mediaDevices.getUserMedia(constraints);
      }
      this._videoTrack = this.stream.getVideoTracks()[0] || null;
      this.torchOn = false;
      this._updateTorchSupport();
      this.video.srcObject = this.stream;
      await this.video.play();
      this.isRunning = true;
      this._resizeCanvas();
      this._renderLoop();
      return true;
    } catch (err) {
      console.error('Camera start error:', err);
      this.lastError = err && (err.name || err.message) ? (err.name + ': ' + (err.message || '')) : String(err);
      return false;
    }
  }

  stop() {
    this.isRunning = false;
    if (this.animationId) {
      cancelAnimationFrame(this.animationId);
      this.animationId = null;
    }
    if (this.stream) {
      this.stream.getTracks().forEach(t => t.stop());
      this.stream = null;
    }
    if (this.video) this.video.srcObject = null;
    this._stopRecordingInternal();
  }

  async flip() {
    this.facingMode = this.facingMode === 'environment' ? 'user' : 'environment';
    this.stop();
    return this.start();
  }

  setMode(mode) {
    this.mode = mode;
  }

  setFilter(id, intensity = 80) {
    this.currentFilter = id;
    this.filterIntensity = intensity;
  }

  setIntensity(val) {
    this.filterIntensity = val;
  }

  setGrid(enabled) {
    this.gridEnabled = enabled;
  }

  setTimer(seconds) {
    this.timerSeconds = seconds;
  }


  _drawVideoFrame() {
    const vw = this.video.videoWidth || this.canvas.width;
    const vh = this.video.videoHeight || this.canvas.height;
    const z = this.zoomLevel || 1;
    const sw = vw / z, sh = vh / z;
    const sx = (vw - sw) / 2, sy = (vh - sh) / 2;
    if (this.facingMode === 'user') {
      this.ctx.save();
      this.ctx.translate(this.canvas.width, 0);
      this.ctx.scale(-1, 1);
      this.ctx.drawImage(this.video, sx, sy, sw, sh, 0, 0, this.canvas.width, this.canvas.height);
      this.ctx.restore();
    } else {
      this.ctx.drawImage(this.video, sx, sy, sw, sh, 0, 0, this.canvas.width, this.canvas.height);
    }
  }

  _resizeCanvas() {
    if (!this.video || !this.canvas) return;
    const w = this.video.videoWidth || 1280;
    const h = this.video.videoHeight || 720;
    if (this.canvas.width !== w || this.canvas.height !== h) {
      this.canvas.width = w;
      this.canvas.height = h;
    }
  }

  _renderLoop() {
    if (!this.isRunning) return;
    this._resizeCanvas();
    if (this.video.readyState >= 2) {
      // performance: process at lower res in low mode
      let procW = this.canvas.width;
      let procH = this.canvas.height;
      if (this.performanceMode === 'low') {
        procW = Math.min(this.canvas.width, 640);
        procH = Math.round(procW * (this.canvas.height / this.canvas.width));
      }
      this._drawVideoFrame();
      // MediaPipe detect
      if (this.faceEngine && this.faceEngine.detectFromVideo) {
        this.faceEngine.detectFromVideo(this.video, performance.now());
      }
      if (this.currentFilter && this.currentFilter !== 'normal') {
        try {
          // for low mode, filter on smaller offscreen then upscale would be better;
          // keep simple: still filter full if possible
          const imageData = this.ctx.getImageData(0, 0, this.canvas.width, this.canvas.height);
          window.VynoxFilters.applyFilter(imageData, this.currentFilter, this.filterIntensity);
          this.ctx.putImageData(imageData, 0, 0);
        } catch (e) {}
      }
      // Face stickers overlay
      if (this.faceEngine) {
        this.faceEngine.draw(this.ctx, this.canvas.width, this.canvas.height);
      }
    }
    this.animationId = requestAnimationFrame(() => this._renderLoop());
  }

  async capturePhoto() {
    if (!this.isRunning) return null;

    const doCapture = () => {
      // ensure latest frame
      this._drawVideoFrame();
      // MediaPipe detect
      if (this.faceEngine && this.faceEngine.detectFromVideo) {
        this.faceEngine.detectFromVideo(this.video, performance.now());
      }
      if (this.currentFilter && this.currentFilter !== 'normal') {
        const imageData = this.ctx.getImageData(0, 0, this.canvas.width, this.canvas.height);
        window.VynoxFilters.applyFilter(imageData, this.currentFilter, this.filterIntensity);
        this.ctx.putImageData(imageData, 0, 0);
      }
      if (this.faceEngine) {
        this.faceEngine.draw(this.ctx, this.canvas.width, this.canvas.height);
      }
      return new Promise(resolve => {
        this.canvas.toBlob(blob => {
          if (!blob) { resolve(null); return; }
          const url = URL.createObjectURL(blob);
          const item = {
            id: 'img_' + Date.now(),
            type: 'photo',
            blob,
            url,
            filter: this.currentFilter,
            created: Date.now(),
            favorite: false
          };
          if (this.onPhotoCaptured) this.onPhotoCaptured(item);
          resolve(item);
        }, 'image/jpeg', 0.92);
      });
    };

    if (this.timerSeconds > 0) {
      return this._runTimer().then(doCapture);
    }
    return doCapture();
  }

  _runTimer() {
    return new Promise(resolve => {
      const overlay = document.getElementById('timer-overlay');
      const countEl = document.getElementById('timer-count');
      let remaining = this.timerSeconds;
      overlay.classList.remove('hidden');
      countEl.textContent = remaining;

      const tick = () => {
        remaining--;
        if (remaining <= 0) {
          overlay.classList.add('hidden');
          resolve();
          return;
        }
        countEl.textContent = remaining;
        countEl.style.animation = 'none';
        countEl.offsetHeight; // reflow
        countEl.style.animation = '';
        setTimeout(tick, 1000);
      };
      setTimeout(tick, 1000);
    });
  }

  async startRecording() {
    if (!this.stream || !this.canvas || this.isRecording) return false;
    if (!window.MediaRecorder) return false;
    try {
      this.recordedChunks = [];
      // Record CANVAS so live filters + face stickers are in the video
      let recordStream;
      if (this.canvas.captureStream) {
        const canvasStream = this.canvas.captureStream(30);
        const tracks = [...canvasStream.getVideoTracks()];
        const audioTracks = this.stream.getAudioTracks();
        if (audioTracks.length) tracks.push(audioTracks[0]);
        recordStream = new MediaStream(tracks);
      } else {
        // fallback: raw camera (no filter on video)
        recordStream = this.stream;
      }

      const candidates = [
        'video/webm;codecs=vp9,opus',
        'video/webm;codecs=vp8,opus',
        'video/webm',
        'video/mp4'
      ];
      let mimeType = '';
      for (const m of candidates) {
        if (MediaRecorder.isTypeSupported(m)) { mimeType = m; break; }
      }
      const options = mimeType ? { mimeType } : {};
      this.mediaRecorder = new MediaRecorder(recordStream, options);
      this.mediaRecorder.ondataavailable = (e) => {
        if (e.data && e.data.size > 0) this.recordedChunks.push(e.data);
      };
      this.mediaRecorder.onstop = () => {
        const type = (this.mediaRecorder && this.mediaRecorder.mimeType) || 'video/webm';
        const blob = new Blob(this.recordedChunks, { type });
        const url = URL.createObjectURL(blob);
        const item = {
          id: 'vid_' + Date.now(),
          type: 'video',
          blob,
          url,
          created: Date.now(),
          favorite: false,
          filter: this.currentFilter
        };
        if (this.onVideoRecorded) this.onVideoRecorded(item);
      };
      this.mediaRecorder.start(250);
      this.isRecording = true;
      this.recStartTime = Date.now();
      this._startRecTimer();
      return true;
    } catch (err) {
      console.error('Record error:', err);
      this.lastError = String(err && err.message || err);
      return false;
    }
  }

  stopRecording() {
    this._stopRecordingInternal();
  }

  _stopRecordingInternal() {
    if (this.mediaRecorder && this.isRecording) {
      try { this.mediaRecorder.stop(); } catch (_) {}
    }
    this.isRecording = false;
    this._stopRecTimer();
  }

  _startRecTimer() {
    const el = document.getElementById('rec-timer');
    const indicator = document.getElementById('recording-indicator');
    if (indicator) indicator.classList.remove('hidden');
    this.recTimerInterval = setInterval(() => {
      const sec = Math.floor((Date.now() - this.recStartTime) / 1000);
      const m = String(Math.floor(sec / 60)).padStart(2, '0');
      const s = String(sec % 60).padStart(2, '0');
      if (el) el.textContent = `${m}:${s}`;
    }, 250);
  }

  _stopRecTimer() {
    if (this.recTimerInterval) {
      clearInterval(this.recTimerInterval);
      this.recTimerInterval = null;
    }
    const indicator = document.getElementById('recording-indicator');
    if (indicator) indicator.classList.add('hidden');
  }


  _updateTorchSupport() {
    this.torchSupported = false;
    try {
      if (this._videoTrack && this._videoTrack.getCapabilities) {
        const caps = this._videoTrack.getCapabilities();
        this.torchSupported = !!(caps && ('torch' in caps) && caps.torch);
      }
    } catch (_) {}
    return this.torchSupported;
  }

  async toggleTorch() {
    if (!this._videoTrack) return false;
    if (!this._updateTorchSupport()) return false;
    try {
      this.torchOn = !this.torchOn;
      await this._videoTrack.applyConstraints({ advanced: [{ torch: this.torchOn }] });
      return true;
    } catch (e) {
      this.torchOn = false;
      console.warn('Torch failed', e);
      return false;
    }
  }

  hasTorch() {
    return this._updateTorchSupport();
  }

  setZoom(level) {
    this.zoomLevel = Math.max(1, Math.min(3, level));
    // try native zoom capability
    if (this._videoTrack) {
      const caps = this._videoTrack.getCapabilities && this._videoTrack.getCapabilities();
      if (caps && caps.zoom) {
        const z = caps.zoom.min + (caps.zoom.max - caps.zoom.min) * ((this.zoomLevel - 1) / 2);
        this._videoTrack.applyConstraints({ advanced: [{ zoom: z }] }).catch(() => {});
      }
    }
  }

  setPerformance(mode) {
    this.performanceMode = mode || 'balanced';
  }

  setFaceEngine(engine) {
    this.faceEngine = engine;
  }

  // Check support
  static async checkSupport() {
    const result = {
      camera: false,
      mic: false,
      mediaRecorder: !!window.MediaRecorder
    };
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      return result;
    }
    try {
      const devices = await navigator.mediaDevices.enumerateDevices();
      result.camera = devices.some(d => d.kind === 'videoinput');
      result.mic = devices.some(d => d.kind === 'audioinput');
    } catch (_) {}
    return result;
  }
}

window.VynoxCamera = VynoxCamera;
