# Vynox Camera X

Premium offline-first camera & creative filter studio (Phase 1–5).

## How to run

1. Unzip the folder.
2. Start a local server (required for camera access):

```bash
cd vynox-camera-x
python3 -m http.server 8080
```

3. Open in browser: **http://localhost:8080**
4. Allow camera (and mic for video).

Chrome / Edge / Safari recommended. Camera needs **localhost** or **HTTPS**.

## Features

- Splash, Onboarding, Permissions
- Live camera (front/back), Photo + Video, Timer, Grid, Level, Zoom 1x–3x
- **~70 real filters** + intensity (Natural, Cinematic, Film, Vintage, B&W, Mood, Experimental)
- **Effects**: Grain, Vignette, VHS, Glitch, RGB Split, Scanlines, etc.
- **Face stickers** (center overlay; optional MediaPipe when online once)
- **Filter Creator** — save custom filters locally
- **Photo Editor** — rotate, flip, crop, text, stickers, brush, frames, color, undo/redo
- **AI Lab** — offline Auto Enhance / Auto Contrast
- **Gallery** — IndexedDB persistent, favorites, delete, edit
- **4 themes**: Obsidian, Aurora, Pearl, Nocturne
- No server, no login, no cloud upload

## Privacy

All media stays on your device. Optional MediaPipe face model loads from CDN only if network is available; core app works fully offline without it.

## Phase 5 QA fixes

- Removed Google Fonts dependency (system fonts, true offline)
- Fixed Grid + Level indicator single handler
- Front camera mirrored preview/capture draw
- Custom filters apply on capture
- Video element hidden under canvas (cleaner preview)
- All JS syntax verified
