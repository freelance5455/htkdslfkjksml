# Build Snake 4.7 APK using GitHub Actions (phone-only workflow)

1. Create/sign in to a GitHub account in your mobile browser.
2. Create a new repository (private is fine).
3. Upload the contents of this ZIP to the repository root. Keep the `.github/workflows/build-apk.yml` path intact. If the mobile upload UI hides dot-folders, use GitHub's web editor to create `.github/workflows/build-apk.yml` with the file from this project.
4. Open the repository's **Actions** tab. If prompted, enable Actions.
5. Choose **Build Snake 4.7 APK** and tap **Run workflow** (or push to `main`). Wait until the run is green.
6. Open the completed run and scroll to **Artifacts**. Download `Snake-4.7-APK`. GitHub downloads artifacts as a ZIP.
7. Open Files/Downloads, extract that ZIP, then tap `app-debug.apk` to install. Android may ask to allow installs from your browser/file manager; only allow this for the file source you intentionally used.

This creates a debug APK for personal installation. The workflow is configured to compile the Android project with Gradle 8.9 and Java 17 in GitHub's cloud runner.
