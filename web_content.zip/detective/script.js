(function(){
"use strict";

/* ============================================================
   0. UTILITIES — seeded RNG, storage, audio
   ============================================================ */
function mulberry32(seed){
  let a = seed >>> 0;
  return function(){
    a |= 0; a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
function makeRng(seed){
  const rand = mulberry32(seed);
  return {
    next: () => rand(),
    int: (min, max) => Math.floor(rand() * (max - min + 1)) + min,
    pick: (arr) => arr[Math.floor(rand() * arr.length)],
    shuffle: (arr) => {
      const a = arr.slice();
      for (let i = a.length - 1; i > 0; i--){
        const j = Math.floor(rand() * (i + 1));
        [a[i], a[j]] = [a[j], a[i]];
      }
      return a;
    },
    sample: (arr, n) => {
      const pool = arr.slice(); const out = [];
      n = Math.min(n, pool.length);
      for (let i=0;i<n;i++){ const idx = Math.floor(rand()*pool.length); out.push(pool.splice(idx,1)[0]); }
      return out;
    }
  };
}

const STORAGE_KEY = "who_is_lying_save_v2";
function defaultSave(){
  return {
    score: 0, coins: 60, casesSolved: 0, correctAccusations: 0, wrongAccusations: 0,
    currentStreak: 0, bestStreak: 0, unlockedCase: 1, caseStars: {}, achievements: {},
    settings: { sound: true }, endless: { played: 0, wins: 0, bestStreak: 0, streak: 0 }
  };
}
let SAVE = loadSave();
function loadSave(){
  try{
    const raw = localStorage.getItem(STORAGE_KEY);
    if(!raw) return defaultSave();
    const parsed = JSON.parse(raw);
    return Object.assign(defaultSave(), parsed, {
      caseStars: Object.assign({}, parsed.caseStars),
      achievements: Object.assign({}, parsed.achievements),
      settings: Object.assign({sound:true}, parsed.settings),
      endless: Object.assign({played:0,wins:0,bestStreak:0,streak:0}, parsed.endless)
    });
  }catch(e){ return defaultSave(); }
}
function persist(){ try{ localStorage.setItem(STORAGE_KEY, JSON.stringify(SAVE)); }catch(e){} }

let actx = null;
function ensureAudio(){ if(!actx){ try{ actx = new (window.AudioContext||window.webkitAudioContext)(); }catch(e){ actx=null; } } if(actx && actx.state==="suspended") actx.resume(); }
function tone(freq, dur, type, delay, vol){
  if(!SAVE.settings.sound || !actx) return;
  const t0 = actx.currentTime + (delay||0);
  const osc = actx.createOscillator(); const gain = actx.createGain();
  osc.type = type||"sine"; osc.frequency.setValueAtTime(freq,t0);
  gain.gain.setValueAtTime(0,t0); gain.gain.linearRampToValueAtTime(vol||0.08,t0+0.01);
  gain.gain.exponentialRampToValueAtTime(0.0001,t0+dur);
  osc.connect(gain).connect(actx.destination); osc.start(t0); osc.stop(t0+dur+0.02);
}
const SFX = {
  click: () => tone(720,0.06,"triangle"),
  clue: () => { tone(500,0.08,"sine"); tone(760,0.09,"sine",0.06); },
  correct: () => { tone(520,0.12,"triangle"); tone(660,0.14,"triangle",0.1); tone(880,0.22,"triangle",0.22); },
  wrong: () => { tone(220,0.18,"sawtooth"); tone(160,0.24,"sawtooth",0.1); },
  complete: () => { tone(523,0.12,"triangle"); tone(659,0.12,"triangle",0.12); tone(784,0.12,"triangle",0.24); tone(1046,0.28,"triangle",0.36); },
  talk: () => tone(440,0.05,"square",0,0.03)
};

/* ============================================================
   1. CASE GENERATOR (with interactive facts + interview data)
   ============================================================ */
const NAMES = ["Emma","Ryan","Sofia","Liam","Ava","Noah","Mia","Ethan","Grace","Lucas",
  "Zoe","Mason","Chloe","Owen","Ella","Caleb","Ruby","Jonah","Nora","Felix",
  "Ivy","Leo","Willa","Theo","Sadie","Miles","June","Arlo","Nina","Dexter"];
const ROLES = ["the butler","the housekeeper","the gardener","the chef","a guest",
  "the niece","the nephew","the business partner","the assistant","the neighbor",
  "the driver","the tutor","the curator","the security guard","the art dealer"];
const LOCATIONS = ["the library","the kitchen","the garden","the study","the ballroom",
  "the hallway","the attic","the office","the lounge","the rooftop terrace",
  "the wine cellar","the conservatory","the dining room","the parlor","the courtyard"];
const ITEMS = ["necklace","painting","antique vase","gold watch","diary","safe","trophy",
  "spare key","sealed letter","ruby ring","laptop","wallet","marble sculpture",
  "old manuscript","coin collection"];
const ADJ = ["Missing","Stolen","Vanishing","Secret","Cursed","Hidden","Broken","Priceless","Forgotten","Silent"];
const TIMES = ["8:45","9:00","9:10","9:15","9:20","9:30","9:40","9:50","10:00","10:15"];
const EVIDENCE = [
  {label:"Security footage", obj:"🎥 Security Camera"},
  {label:"the night guard's log", obj:"📒 Guard's Logbook"},
  {label:"a phone record", obj:"📱 Phone Records"},
  {label:"the housekeeper's account", obj:"🧹 Housekeeper"},
  {label:"a muddy footprint", obj:"👣 Muddy Footprint"},
  {label:"a torn scrap of fabric", obj:"🧵 Torn Fabric"},
  {label:"the guest book", obj:"📖 Guest Registry"},
  {label:"a cracked pocket watch found at the scene", obj:"⏱️ Cracked Pocket Watch"},
  {label:"rain-soaked shoe prints", obj:"👞 Shoe Prints"},
  {label:"the delivery log", obj:"📦 Delivery Log"},
  {label:"a smudged photograph", obj:"🖼️ Smudged Photograph"},
  {label:"an overheard phone call", obj:"☎️ Overheard Call"}
];
const ACTIVITIES = ["sorting old letters","polishing the silverware","watering the plants",
  "reading a novel by the window","tuning the piano","organizing the bookshelf","writing in a notebook"];
const AVATAR_COLORS = ["#F5C542","#7C3AED","#2563EB","#22C55E","#EF4444","#F59E0B","#06B6D4","#EC4899"];
const PERSONAL_ITEMS = ["📱 Phone","👜 Bag","🔑 Keys","📄 Documents","⌚ Watch","🧥 Coat Pocket","📓 Notebook"];
const FLAVOR_LINES = ["Nothing unusual here.","Just everyday items — nothing out of place.","You find nothing that helps the case.","Looks completely ordinary.","Nothing worth noting, but you check anyway."];
const JEWELRY_ITEMS = ["necklace","ruby ring","gold watch","coin collection"];
const OFFICE_ITEMS = ["laptop","sealed letter","safe","old manuscript","wallet"];

function themeSceneLabels(item){
  if(JEWELRY_ITEMS.includes(item)) return ["💍 Jewelry Box","🛏️ Bedroom Window"];
  if(OFFICE_ITEMS.includes(item)) return ["💻 Computer Desk","🚪 Office Door"];
  return ["🖼️ Display Case","📖 Guest Book"];
}

function chapterConfig(caseNum){
  if(caseNum<=10) return {chapter:1,name:"Easy Cases",difficulty:"Easy",dot:"var(--success)",suspects:3,clues:3};
  if(caseNum<=20) return {chapter:2,name:"Hidden Clues",difficulty:"Medium",dot:"var(--gold)",suspects:4,clues:4};
  if(caseNum<=30) return {chapter:3,name:"The Perfect Lie",difficulty:"Hard",dot:"#F59E0B",suspects:4,clues:5};
  if(caseNum<=40) return {chapter:4,name:"Twisted Stories",difficulty:"Hard",dot:"#F59E0B",suspects:5,clues:6};
  return {chapter:5,name:"Master Detective",difficulty:"Expert",dot:"var(--danger)",suspects:5,clues:7};
}
const CHAPTER_NAMES = ["Easy Cases","Hidden Clues","The Perfect Lie","Twisted Stories","Master Detective"];

function genFillerClue(rng, ctx){
  const templates = [
    () => `The window in ${rng.pick(LOCATIONS)} was left open, letting in the cold night air.`,
    () => `A half-finished cup of tea was found in ${rng.pick(LOCATIONS)}.`,
    () => `The clock in ${rng.pick(LOCATIONS)} was running a few minutes fast.`,
    () => `Faint muddy footprints led toward ${rng.pick(LOCATIONS)}, but they matched the gardener's boots.`,
    () => `${rng.pick(ctx.names)}'s scarf was found draped over a chair, right where they said they'd been sitting.`,
    () => `The lights in ${rng.pick(LOCATIONS)} flickered briefly, according to the housekeeper.`,
    () => `${rng.pick(ctx.names)} was seen arguing earlier that evening — but it turned out to be over an unrelated matter.`,
    () => `A pair of gloves turned up near ${rng.pick(LOCATIONS)}, though their owner explained they'd dropped them hours earlier.`,
    () => `An anonymous note pointed fingers at someone in the house, but the handwriting didn't match anyone present.`,
    () => `A dog was heard barking near ${rng.pick(LOCATIONS)} sometime after ${rng.pick(TIMES)}, though nothing seemed amiss.`
  ];
  return rng.pick(templates)();
}

// Builds statements, structured Q&A facts, and interview metadata.
function buildCaseCore(rng, ctx){
  const n = ctx.count;
  const statements = new Array(n).fill(null);
  const facts = new Array(n).fill(null); // {location, timeText, companion, activity}
  const usedFillerLoc = new Set();
  const types = ["TIME","ALIBI","KNOWLEDGE","OBJECT","SEQUENCE"];
  const type = ctx.forcedType || rng.pick(types);

  const locA = rng.pick(LOCATIONS);
  let locB = rng.pick(LOCATIONS.filter(l=>l!==locA));
  let locC = rng.pick(LOCATIONS.filter(l=>l!==locA && l!==locB));
  const t1 = rng.pick(TIMES);
  let t2 = rng.pick(TIMES.filter(t=>t!==t1));
  const evidence = rng.pick(EVIDENCE);
  const liarName = ctx.names[ctx.liarIndex];
  const others = [...Array(n).keys()].filter(i=>i!==ctx.liarIndex);
  let smokingGun = "", explanation = "", hints = [];
  let partnerIdx = -1, otherIdx = -1;

  if(type === "TIME"){
    statements[ctx.liarIndex] = `"I was in ${locA} the whole time, from about ${t1} to ${t2}."`;
    facts[ctx.liarIndex] = { location: locA, timeText: `from ${t1} to ${t2}`, companion: null, activity: `keeping to myself in ${locA}` };
    smokingGun = `${evidence.label.charAt(0).toUpperCase()+evidence.label.slice(1)} shows ${liarName} entering ${locB} at ${t1} — a place ${liarName} claimed never to have visited that night.`;
    explanation = `${liarName} claimed to be in ${locA} the entire time, but ${evidence.label} places ${liarName} in ${locB} at ${t1} instead. The two accounts can't both be true — ${liarName} is lying.`;
    hints = [
      "Check the timeline carefully — someone's account of where they were doesn't add up.",
      "Compare each suspect's claimed location against the physical evidence.",
      `Take a closer look at ${liarName}'s statement — it doesn't match the evidence.`
    ];
  } else if(type === "OBJECT"){
    statements[ctx.liarIndex] = `"I never touched the ${ctx.item} — I didn't even go near it."`;
    facts[ctx.liarIndex] = { location: "around the house", timeText: null, companion: null, activity: "minding my own business" };
    smokingGun = `${evidence.label.charAt(0).toUpperCase()+evidence.label.slice(1)} reveals ${liarName}'s fingerprints directly on the ${ctx.item}.`;
    explanation = `${liarName} denied ever touching the ${ctx.item}, yet ${evidence.label} places ${liarName}'s fingerprints right on it. That's impossible if ${liarName} were telling the truth.`;
    hints = [
      "Physical evidence often tells a different story than words do.",
      `Check who's actually connected to the ${ctx.item} — not just who says they aren't.`,
      `Take a closer look at ${liarName}'s statement — it doesn't match the evidence.`
    ];
  } else if(type === "KNOWLEDGE"){
    statements[ctx.liarIndex] = `"I had no idea the ${ctx.item} was even kept in ${locA}."`;
    facts[ctx.liarIndex] = { location: "around the house", timeText: null, companion: null, activity: "keeping busy with small tasks" };
    smokingGun = `${evidence.label.charAt(0).toUpperCase()+evidence.label.slice(1)} reveals ${liarName} was overheard describing exactly where the ${ctx.item} was hidden — days before it disappeared.`;
    explanation = `${liarName} claimed not to know where the ${ctx.item} was kept, but ${evidence.label} shows ${liarName} already knew its exact hiding place. Someone with no knowledge of it couldn't have known that.`;
    hints = [
      "Someone in this case seems to know more than they're letting on.",
      "Pay attention to details a suspect shouldn't have known — if they claim otherwise.",
      `Take a closer look at ${liarName}'s statement — it doesn't match the evidence.`
    ];
  } else if(type === "SEQUENCE"){
    otherIdx = rng.pick(others);
    const otherName = ctx.names[otherIdx];
    statements[ctx.liarIndex] = `"I saw ${otherName} leave ${locA} well before the ${ctx.item} went missing, around ${t1}."`;
    statements[otherIdx] = `"I was in ${locA} until about ${t2}, tidying up before I finally left."`;
    facts[ctx.liarIndex] = { location: locC, timeText: null, companion: null, activity: rng.pick(ACTIVITIES) };
    facts[otherIdx] = { location: locA, timeText: `until ${t2}`, companion: null, activity: "tidying up before leaving" };
    smokingGun = `${evidence.label.charAt(0).toUpperCase()+evidence.label.slice(1)} shows ${otherName} was still inside ${locA} until ${t2} — after the ${ctx.item} disappeared at ${t1}.`;
    explanation = `${liarName} claimed ${otherName} left ${locA} before ${t1}, but ${evidence.label} confirms ${otherName} was there until ${t2}, after the ${ctx.item} went missing. ${liarName}'s timeline doesn't hold up.`;
    hints = [
      "Pay close attention to when people say others came and went.",
      `Compare the claimed order of events against what ${evidence.label} shows.`,
      `Take a closer look at ${liarName}'s statement — it doesn't match the evidence.`
    ];
  } else { // ALIBI
    partnerIdx = rng.pick(others);
    const partnerName = ctx.names[partnerIdx];
    statements[ctx.liarIndex] = `"I was with ${partnerName} in ${locA} the entire time, from ${t1} to ${t2}."`;
    statements[partnerIdx] = `"Actually, I was alone in ${locB} between ${t1} and ${t2}. I wasn't with anyone."`;
    facts[ctx.liarIndex] = { location: locA, timeText: `from ${t1} to ${t2}`, companion: partnerName, activity: `talking with ${partnerName}` };
    facts[partnerIdx] = { location: locB, timeText: `from ${t1} to ${t2}`, companion: null, activity: "on my own" };
    smokingGun = `${evidence.label.charAt(0).toUpperCase()+evidence.label.slice(1)} confirms ${partnerName} was alone in ${locB} during that window, with no sign of ${liarName} anywhere nearby.`;
    explanation = `${liarName} claimed to have been with ${partnerName} in ${locA}, but ${partnerName} says they were alone in ${locB} the entire time — confirmed by ${evidence.label}. Their stories directly conflict, and the evidence backs ${partnerName}. ${liarName} is lying.`;
    hints = [
      "Not everyone who claims to be together was actually together.",
      "Compare the two halves of a shared alibi — do they really match?",
      `Take a closer look at ${liarName}'s statement — it doesn't match the evidence.`
    ];
  }

  for(let i=0;i<n;i++){
    if(statements[i]) continue;
    let loc2 = rng.pick(LOCATIONS);
    let tries=0;
    while(usedFillerLoc.has(loc2) && tries<5){ loc2 = rng.pick(LOCATIONS); tries++; }
    usedFillerLoc.add(loc2);
    const activity = rng.pick(ACTIVITIES);
    const variants = [
      `"I was in ${loc2} the whole time and didn't notice anything strange."`,
      `"I stepped out for some air near ${loc2} and came straight back."`,
      `"Honestly, I didn't see much — I was busy ${activity}."`,
      `"I was in ${loc2}, mostly on my own, until things got noisy."`
    ];
    statements[i] = rng.pick(variants);
    facts[i] = { location: loc2, timeText: null, companion: null, activity };
  }

  // compare-question targets (mutual for the meaningful pair, else neighbor)
  const compareTarget = [];
  for(let i=0;i<n;i++) compareTarget.push((i+1)%n);
  if(type==="ALIBI"){ compareTarget[ctx.liarIndex]=partnerIdx; compareTarget[partnerIdx]=ctx.liarIndex; }
  if(type==="SEQUENCE"){ compareTarget[ctx.liarIndex]=otherIdx; compareTarget[otherIdx]=ctx.liarIndex; }

  return { statements, facts, smokingGun, explanation, hints, type, partnerIdx, otherIdx, compareTarget, evidenceObj: evidence.obj };
}

function generateCase(caseNum, opts){
  opts = opts || {};
  const seed = opts.seed !== undefined ? opts.seed : (caseNum * 7919 + 13);
  const rng = makeRng(seed);
  const cfg = opts.config || chapterConfig(caseNum);

  const numSuspects = cfg.suspects;
  const numClues = cfg.clues;
  const names = rng.sample(NAMES, numSuspects);
  const roles = rng.sample(ROLES, numSuspects);
  const item = rng.pick(ITEMS);
  const loc = rng.pick(LOCATIONS);
  const adj = rng.pick(ADJ);
  const liarIndex = rng.int(0, numSuspects-1);

  const core = buildCaseCore(rng, { names, roles, liarIndex, count: numSuspects, item, forcedType: opts.forcedType });

  // filler clue pool for discovery distribution
  const fillerCount = Math.max(0, numClues - 1);
  const fillerClues = [];
  for(let i=0;i<fillerCount;i++) fillerClues.push(genFillerClue(rng, {names}));
  const fillerQueue = fillerClues.slice();

  // scene items: 2 theme-flavored + 1 evidence-named (holds the smoking gun)
  const themeLabels = themeSceneLabels(item);
  const sceneRaw = [
    { label: themeLabels[0], isEvidence:false },
    { label: themeLabels[1], isEvidence:false },
    { label: core.evidenceObj, isEvidence:true }
  ];
  const sceneItems = rng.shuffle(sceneRaw).map(s=>{
    if(s.isEvidence) return { label:s.label, revealed:false, clue: core.smokingGun, isEvidence:true };
    const clue = fillerQueue.length ? fillerQueue.shift() : null;
    return { label:s.label, revealed:false, clue, isEvidence:false };
  });

  // personal items: 2 per suspect, remaining fillers distributed randomly among them
  const suspects = names.map((name,i)=>{
    const items = rng.sample(PERSONAL_ITEMS, 2).map(label=>({ label, revealed:false, clue:null }));
    return {
      name, role: roles[i],
      avatarColor: AVATAR_COLORS[i % AVATAR_COLORS.length],
      statement: core.statements[i],
      facts: core.facts[i],
      personalItems: items,
      asked: {}, expression: "neutral", confronted:false
    };
  });
  const allSlots = [];
  suspects.forEach((s,si)=>s.personalItems.forEach((it,ii)=>allSlots.push([si,ii])));
  const slotPicks = rng.sample(allSlots, Math.min(fillerQueue.length, allSlots.length));
  slotPicks.forEach(([si,ii])=>{ suspects[si].personalItems[ii].clue = fillerQueue.shift(); });

  const timeStart = TIMES[0], timeEnd = TIMES[TIMES.length-1];
  const story = `Late last night, a ${item} went missing from ${loc}. ` +
    `${numSuspects} people were in the house between ${timeStart} and ${timeEnd}. ` +
    `Detective — question the suspects, inspect the scene, and find the inconsistency in someone's story.`;

  return {
    id: caseNum,
    chapter: cfg.chapter,
    difficulty: cfg.difficulty,
    title: `The ${adj} ${item.charAt(0).toUpperCase()+item.slice(1)}`,
    story, item, loc,
    suspects,
    sceneItems,
    liarIndex,
    type: core.type,
    partnerIdx: core.partnerIdx,
    otherIdx: core.otherIdx,
    compareTarget: core.compareTarget,
    smokingGun: core.smokingGun,
    explanation: core.explanation,
    hints: core.hints,
    totalClueCount: numClues,
    allCluesForReview: [core.smokingGun, ...fillerClues],
    discoveredLog: []
  };
}

/* ============================================================
   2. GAME STATE
   ============================================================ */
let state = {
  screen: "menu",
  currentCase: null,
  isEndless: false,
  endlessCounter: 0,
  lives: 3,
  mistakes: 0,
  hintsUsed: 0,
  selectedSuspect: null,
  activeInterview: null, // suspect index whose panel is open
  interviewTab: "ask"
};

const ACHIEVEMENTS = [
  {id:"first_case", icon:"🔎", name:"First Lead", desc:"Solve your first case.", check: s=>s.casesSolved>=1},
  {id:"perfect_case", icon:"⭐", name:"Flawless Deduction", desc:"Earn 3 stars on a case.", check: s=>Object.values(s.caseStars).some(v=>v>=3)},
  {id:"streak5", icon:"🔥", name:"On a Roll", desc:"Reach a streak of 5.", check: s=>s.bestStreak>=5},
  {id:"chapter1", icon:"📗", name:"Chapter One Closed", desc:"Complete Chapter 1.", check: s=>!!s.caseStars[10]},
  {id:"ten_cases", icon:"🧩", name:"Getting Sharp", desc:"Solve 10 cases.", check: s=>s.casesSolved>=10},
  {id:"twentyfive_cases", icon:"🗂️", name:"Seasoned Sleuth", desc:"Solve 25 cases.", check: s=>s.casesSolved>=25},
  {id:"fifty_cases", icon:"🏅", name:"Case Files Closed", desc:"Solve all 50 story cases.", check: s=>!!s.caseStars[50]},
  {id:"endless_ten", icon:"♾️", name:"Endless Explorer", desc:"Win 10 endless cases.", check: s=>s.endless.wins>=10},
  {id:"master_detective", icon:"🕵️", name:"Master Detective", desc:"Reach 3 stars on Case 50.", check: s=>s.caseStars[50]>=3}
];
function checkAchievements(){
  const unlocked = [];
  ACHIEVEMENTS.forEach(a=>{ if(!SAVE.achievements[a.id] && a.check(SAVE)){ SAVE.achievements[a.id]=true; unlocked.push(a); } });
  if(unlocked.length) persist();
  return unlocked;
}

/* ============================================================
   3. DIALOGUE / ANSWER ENGINE
   ============================================================ */
const QUESTIONS = [
  {id:"time", label:"Where were you when it happened?"},
  {id:"companion", label:"Who were you with?"},
  {id:"activity", label:"What were you doing?"},
  {id:"item", label:"Did you see the missing item?"},
  {id:"compare", label:"Why does your story differ from someone else's?"}
];

function relevantQid(type){
  if(type==="TIME") return "time";
  if(type==="OBJECT" || type==="KNOWLEDGE") return "item";
  if(type==="ALIBI") return "companion";
  if(type==="SEQUENCE") return "compare";
  return null;
}

function answerQuestion(c, i, qid){
  const s = c.suspects[i];
  if(s.asked[qid]){
    return { text: "You already asked me that.", expr: "bored" };
  }
  s.asked[qid] = true;
  const f = s.facts;
  const isLiar = i === c.liarIndex;
  const isRelevant = relevantQid(c.type) === qid &&
    (isLiar || (c.type==="ALIBI" && i===c.partnerIdx) || (c.type==="SEQUENCE" && i===c.otherIdx));

  let text, expr = isRelevant ? "nervous" : "neutral";

  if(qid==="time"){
    text = f.timeText ? `"I was in ${f.location}, ${f.timeText}."` : `"I was in ${f.location} for a while."`;
  } else if(qid==="companion"){
    text = f.companion ? `"I was with ${f.companion}."` : `"I was alone the whole time."`;
  } else if(qid==="activity"){
    text = `"I was ${f.activity}."`;
  } else if(qid==="item"){
    if(isLiar && c.type==="KNOWLEDGE"){ text = s.statement; expr="nervous"; }
    else { text = `"No, I didn't see the ${c.item} at all."`; }
  } else if(qid==="compare"){
    const targetIdx = c.compareTarget[i];
    const targetName = c.suspects[targetIdx].name;
    const isPair = (c.type==="ALIBI" && (i===c.liarIndex||i===c.partnerIdx) && (targetIdx===c.liarIndex||targetIdx===c.partnerIdx)) ||
                   (c.type==="SEQUENCE" && (i===c.liarIndex||i===c.otherIdx) && (targetIdx===c.liarIndex||targetIdx===c.otherIdx));
    if(isPair && isLiar){ text = `"W-what? No, I'm sure it happened just like I said."`; expr="nervous"; }
    else if(isPair){ text = `"I don't know why our stories don't line up. I told the truth."`; expr="suspicious"; }
    else { text = `"I don't know anything about ${targetName}'s story. Ask them yourself."`; expr="neutral"; }
  }
  return { text, expr };
}

function confrontSuspect(c, i){
  const gunFound = c.discoveredLog.includes(c.smokingGun);
  if(!gunFound){
    return { text: "You don't have enough evidence to confront anyone yet. Keep investigating.", expr: c.suspects[i].expression, blocked:true };
  }
  const s = c.suspects[i];
  s.confronted = true;
  if(i === c.liarIndex){
    return { text: `You lay out the evidence. "${c.explanation}"\n\n${s.name} falls silent for a moment.\n"...Alright. Maybe I wasn't completely honest."`, expr: "guilty" };
  }
  return { text: `"What? I have no idea what you're talking about. You've got the wrong person."`, expr: "surprised" };
}

const EXPR_EMOJI = { neutral:"😐", nervous:"😰", angry:"😠", surprised:"😲", suspicious:"🤨", guilty:"😓", bored:"😑" };

/* ============================================================
   4. RENDERING / SCREENS
   ============================================================ */
const $ = (sel)=>document.querySelector(sel);
const $$ = (sel)=>Array.from(document.querySelectorAll(sel));

function showScreen(id){
  $$(".screen").forEach(s=>s.classList.remove("active"));
  $("#"+id).classList.add("active");
  state.screen = id;
  window.scrollTo(0,0);
}

function renderMenu(){
  $("#m-score").textContent = SAVE.score;
  $("#m-solved").textContent = SAVE.casesSolved;
  $("#m-streak").textContent = SAVE.currentStreak;
}

let activeChapterFilter = 1;
function renderCaseSelect(){
  $("#cs-coins").textContent = SAVE.coins;
  const tabsEl = $("#chapter-tabs");
  tabsEl.innerHTML = "";
  CHAPTER_NAMES.forEach((name,i)=>{
    const num = i+1;
    const tab = document.createElement("button");
    tab.className = "chapter-tab" + (activeChapterFilter===num ? " active" : "");
    tab.textContent = `Ch.${num} · ${name}`;
    tab.onclick = ()=>{ SFX.click(); activeChapterFilter = num; renderCaseSelect(); };
    tabsEl.appendChild(tab);
  });

  const grid = $("#case-grid");
  grid.innerHTML = "";
  const startCase = (activeChapterFilter-1)*10 + 1;
  for(let c=startCase; c<startCase+10; c++){
    const cfg = chapterConfig(c);
    const locked = c > SAVE.unlockedCase;
    const stars = SAVE.caseStars[c] || 0;
    const card = document.createElement("button");
    card.className = "card case-card" + (locked ? " locked" : "");
    card.style.animationDelay = ((c-startCase)*35)+"ms";
    const preview = locked ? "???" : generateCase(c).title;
    card.innerHTML = `
      <div class="cnum"><span class="diff-dot" style="background:${cfg.dot}"></span>CASE ${String(c).padStart(2,'0')}</div>
      <div class="ctitle">${locked ? "Locked Case" : preview}</div>
      <div class="stars">${locked ? "" : "⭐".repeat(stars) + "☆".repeat(3-stars)}</div>
      ${locked ? '<div class="lock">🔒</div>' : ''}
    `;
    if(!locked) card.onclick = ()=>{ SFX.click(); startCase_(c, false); };
    grid.appendChild(card);
  }
}

function heartsHtml(lives){
  let h = "";
  for(let i=0;i<3;i++) h += i < lives ? "❤️" : `<span class="lost">🤍</span>`;
  return h;
}

function renderInvestigation(){
  const c = state.currentCase;
  $("#inv-num").textContent = state.isEndless ? `∞-${state.endlessCounter}` : `#${String(c.id).padStart(3,'0')}`;
  $("#inv-title").textContent = c.title;
  $("#inv-lives").innerHTML = heartsHtml(state.lives);
  $("#inv-coins").textContent = SAVE.coins;
  $("#inv-story").textContent = c.story;

  const susEl = $("#inv-suspects");
  susEl.innerHTML = "";
  c.suspects.forEach((s,i)=>{
    const initials = s.name.slice(0,2).toUpperCase();
    const card = document.createElement("div");
    card.className = "card suspect-card" + (state.selectedSuspect===i ? " selected" : "");
    card.style.animationDelay = (i*60)+"ms";
    card.innerHTML = `
      <div class="suspect-top">
        <div class="avatar idle" style="background:${s.avatarColor}">${initials}<span class="expr-badge">${EXPR_EMOJI[s.expression]||""}</span></div>
        <div class="suspect-info">
          <div class="sname">${s.name}</div>
          <div class="srole">${s.role.charAt(0).toUpperCase()+s.role.slice(1)}</div>
          <div class="sstatement">${s.statement}</div>
        </div>
      </div>
      <div class="suspect-actions">
        <button class="btn btn-sm talk-btn">💬 Talk</button>
      </div>
    `;
    card.querySelector(".talk-btn").onclick = (e)=>{ e.stopPropagation(); SFX.click(); openInterview(i); };
    card.onclick = ()=>{ SFX.click(); state.selectedSuspect = (state.selectedSuspect===i) ? null : i; renderInvestigation(); };
    susEl.appendChild(card);
  });

  const cluesEl = $("#inv-clues");
  cluesEl.innerHTML = "";
  if(c.discoveredLog.length===0){
    cluesEl.innerHTML = `<div class="clue locked">No clues discovered yet. Talk to suspects and inspect the scene to find evidence.</div>`;
  } else {
    c.discoveredLog.forEach((clue,idx)=>{
      const div = document.createElement("div");
      div.className = "clue revealed";
      div.style.animationDelay = (idx*40)+"ms";
      div.innerHTML = `<span>🗒️</span><span>${clue}</span>`;
      cluesEl.appendChild(div);
    });
  }
  $("#inv-clue-count").textContent = `${c.discoveredLog.length} / ${c.totalClueCount} found`;
  $("#btn-accuse").disabled = state.selectedSuspect===null;
}

function renderAchievements(){
  const grid = $("#ach-grid");
  grid.innerHTML = "";
  ACHIEVEMENTS.forEach(a=>{
    const unlocked = !!SAVE.achievements[a.id];
    const div = document.createElement("div");
    div.className = "card ach-card" + (unlocked ? "" : " locked");
    div.innerHTML = `<div class="aicon">${unlocked ? a.icon : "🔒"}</div><div><div class="aname">${a.name}</div><div class="adesc">${a.desc}</div></div>`;
    grid.appendChild(div);
  });
}
function renderSettings(){ $("#toggle-sound").checked = !!SAVE.settings.sound; }

/* ============================================================
   5. INTERVIEW PANEL
   ============================================================ */
function discoverClue(c, clueText){
  if(!clueText) return false;
  if(c.discoveredLog.includes(clueText)) return false;
  c.discoveredLog.push(clueText);
  SFX.clue();
  return true;
}

function openInterview(i){
  state.activeInterview = i;
  state.interviewTab = "ask";
  renderInterviewOverlay();
}

function closeInterview(){
  const ov = document.querySelector(".iv-overlay");
  if(ov) ov.remove();
  state.activeInterview = null;
  renderInvestigation();
}

function renderInterviewOverlay(msg){
  const c = state.currentCase;
  const i = state.activeInterview;
  if(i===null) return;
  const s = c.suspects[i];
  const initials = s.name.slice(0,2).toUpperCase();

  let ov = document.querySelector(".iv-overlay");
  const isNew = !ov;
  if(isNew){
    ov = document.createElement("div");
    ov.className = "overlay iv-overlay";
    document.body.appendChild(ov);
  }
  const gunFound = c.discoveredLog.includes(c.smokingGun);
  const dialogue = msg !== undefined ? msg : `"Ask me something, detective."`;

  ov.innerHTML = `
    <div class="card interview-modal">
      <div class="iv-header">
        <div class="iv-portrait avatar-portrait" style="background:${s.avatarColor}" id="iv-portrait">${initials}<span class="expr-badge" id="iv-expr">${EXPR_EMOJI[s.expression]||"😐"}</span></div>
        <div>
          <div class="iv-name">${s.name}</div>
          <div class="iv-role">${s.role.charAt(0).toUpperCase()+s.role.slice(1)}</div>
        </div>
        <button class="btn-icon iv-close" id="iv-close-btn">✕</button>
      </div>
      <div class="iv-dialogue" id="iv-dialogue" style="white-space:pre-line;">${dialogue}</div>
      <div class="iv-tabs">
        <button class="iv-tab ${state.interviewTab==='ask'?'active':''}" id="iv-tab-ask">💬 Ask</button>
        <button class="iv-tab ${state.interviewTab==='inspect'?'active':''}" id="iv-tab-inspect">🔎 Inspect</button>
      </div>
      <div class="iv-list" id="iv-list"></div>
      <div class="iv-footer">
        <button class="btn btn-danger btn-block" id="iv-confront">⚠️ Confront ${gunFound ? "" : "(need evidence)"}</button>
      </div>
    </div>
  `;
  document.body.appendChild(ov); // ensure at end

  $("#iv-close-btn").onclick = ()=>{ SFX.click(); closeInterview(); };
  $("#iv-tab-ask").onclick = ()=>{ SFX.click(); state.interviewTab="ask"; renderInterviewOverlay(dialogue); };
  $("#iv-tab-inspect").onclick = ()=>{ SFX.click(); state.interviewTab="inspect"; renderInterviewOverlay(dialogue); };
  $("#iv-confront").onclick = ()=>{
    SFX.click();
    const res = confrontSuspect(c, i);
    s.expression = res.expr;
    playTalk();
    renderInterviewOverlay(res.text);
  };

  const listEl = $("#iv-list");
  listEl.innerHTML = "";
  if(state.interviewTab==="ask"){
    QUESTIONS.forEach(q=>{
      const btn = document.createElement("button");
      btn.className = "iv-option";
      btn.innerHTML = `<span>${q.label}</span>${s.asked[q.id] ? '<span class="tag">asked</span>' : ""}`;
      btn.onclick = ()=>{
        SFX.click();
        const res = answerQuestion(c, i, q.id);
        s.expression = res.expr;
        playTalk();
        renderInterviewOverlay(res.text);
      };
      listEl.appendChild(btn);
    });
  } else {
    s.personalItems.forEach((item,ii)=>{
      const btn = document.createElement("button");
      btn.className = "iv-option";
      btn.innerHTML = `<span>${item.label}</span>${item.revealed ? '<span class="tag">checked</span>' : ""}`;
      btn.onclick = ()=>{
        SFX.click();
        if(item.revealed){
          renderInterviewOverlay(`You've already checked the ${item.label.replace(/^\S+\s/,'')}.`);
          return;
        }
        item.revealed = true;
        let text;
        if(item.clue){
          const isNewClue = discoverClue(c, item.clue);
          text = `🔍 You find something: ${item.clue}`;
        } else {
          text = rngFlavor();
        }
        renderInvestigationClueCountOnly();
        renderInterviewOverlay(text);
      };
      listEl.appendChild(btn);
    });
  }
}

function rngFlavor(){ return FLAVOR_LINES[Math.floor(Math.random()*FLAVOR_LINES.length)]; }
function playTalk(){
  const p = document.getElementById("iv-portrait");
  if(p){ p.classList.remove("talking"); void p.offsetWidth; p.classList.add("talking"); }
  SFX.talk();
}
function renderInvestigationClueCountOnly(){
  // keep the underlying investigation screen's clue log in sync without closing the modal
  if(state.screen === "screen-investigation"){
    const c = state.currentCase;
    const cluesEl = $("#inv-clues");
    if(!cluesEl) return;
    cluesEl.innerHTML = "";
    if(c.discoveredLog.length===0){
      cluesEl.innerHTML = `<div class="clue locked">No clues discovered yet. Talk to suspects and inspect the scene to find evidence.</div>`;
    } else {
      c.discoveredLog.forEach((clue,idx)=>{
        const div = document.createElement("div");
        div.className = "clue revealed";
        div.innerHTML = `<span>🗒️</span><span>${clue}</span>`;
        cluesEl.appendChild(div);
      });
    }
    $("#inv-clue-count").textContent = `${c.discoveredLog.length} / ${c.totalClueCount} found`;
  }
}

/* ============================================================
   6. SCENE PANEL
   ============================================================ */
function openScenePanel(){
  const c = state.currentCase;
  const ov = document.createElement("div");
  ov.className = "overlay scene-overlay";
  ov.innerHTML = `
    <div class="card scene-modal">
      <div class="iv-header">
        <div><div class="iv-name">🔎 Inspect the Scene</div><div class="iv-role">Tap an object to examine it</div></div>
        <button class="btn-icon iv-close" id="scene-close">✕</button>
      </div>
      <div class="scene-grid" id="scene-grid"></div>
    </div>
  `;
  document.body.appendChild(ov);
  ov.querySelector("#scene-close").onclick = ()=>{ SFX.click(); ov.remove(); renderInvestigation(); };

  function renderGrid(){
    const grid = ov.querySelector("#scene-grid");
    grid.innerHTML = "";
    c.sceneItems.forEach((item,idx)=>{
      const parts = item.label.split(" ");
      const icon = parts[0];
      const name = parts.slice(1).join(" ");
      const div = document.createElement("button");
      div.className = "scene-item" + (item.revealed ? " done" : "");
      div.innerHTML = `<span class="icon">${icon}</span>${name}`;
      div.onclick = ()=>{
        SFX.click();
        if(item.revealed){ showToast(`Already searched: ${name}`); return; }
        item.revealed = true;
        if(item.clue){
          discoverClue(c, item.clue);
          showToast(`🔍 ${item.clue}`, 4500);
        } else {
          showToast(rngFlavor());
        }
        renderGrid();
        renderInvestigationClueCountOnly();
      };
      grid.appendChild(div);
    });
  }
  renderGrid();
}

/* ============================================================
   7. GAME FLOW
   ============================================================ */
let toastTimer = null;
function showToast(msg, duration){
  const old = document.querySelector(".toast");
  if(old) old.remove();
  const t = document.createElement("div");
  t.className = "toast";
  t.textContent = msg;
  document.body.appendChild(t);
  clearTimeout(toastTimer);
  toastTimer = setTimeout(()=>t.remove(), duration || 2200);
}

function startCase_(caseNum, isEndless){
  state.isEndless = isEndless;
  state.selectedSuspect = null;
  state.activeInterview = null;
  state.lives = 3;
  state.mistakes = 0;
  state.hintsUsed = 0;

  if(isEndless){
    state.endlessCounter++;
    const cfgPool = [
      {suspects:3,clues:3},{suspects:4,clues:4},{suspects:4,clues:5},{suspects:5,clues:6},{suspects:5,clues:7}
    ];
    const pick = cfgPool[Math.floor(Math.random()*cfgPool.length)];
    state.currentCase = generateCase(1000000 + Math.floor(Math.random()*999999), { seed: (Date.now()+Math.random()*1e9)|0, config: Object.assign({chapter:0}, pick) });
    state.currentCase.title = "Endless Case #" + state.endlessCounter;
    state.currentCase.difficulty = "Random";
  } else {
    state.currentCase = generateCase(caseNum);
  }
  showScreen("screen-investigation");
  renderInvestigation();
}

function doHint(){
  const c = state.currentCase;
  if(state.hintsUsed >= 3){ showToast("No more hints for this case."); return; }
  const costs = [0, 15, 25];
  const cost = costs[state.hintsUsed];
  if(SAVE.coins < cost){ showToast(`Not enough coins — need 💰${cost}`); return; }
  SAVE.coins -= cost;
  const hintText = c.hints[state.hintsUsed];
  state.hintsUsed++;
  persist();
  SFX.click();
  renderInvestigation();
  showToast(`💡 Hint ${state.hintsUsed}/3: ${hintText}`, 4200);
}

function doAccuse(){
  if(state.selectedSuspect===null) return;
  const c = state.currentCase;
  const name = c.suspects[state.selectedSuspect].name;
  const overlay = document.createElement("div");
  overlay.className = "overlay";
  overlay.innerHTML = `
    <div class="card modal">
      <div class="big-icon">⚖️</div>
      <h2>Accuse ${name}?</h2>
      <p style="color:var(--text-dim);font-size:14px;margin:10px 0 18px;">This decision is final for this round of questioning.</p>
      <div class="btn-row">
        <button class="btn" id="cancel-accuse" style="flex:1;">Cancel</button>
        <button class="btn btn-primary" id="confirm-accuse" style="flex:1;">Confirm</button>
      </div>
    </div>`;
  document.body.appendChild(overlay);
  overlay.querySelector("#cancel-accuse").onclick = ()=>{ SFX.click(); overlay.remove(); };
  overlay.querySelector("#confirm-accuse").onclick = ()=>{ overlay.remove(); resolveAccusation(); };
}

function resolveAccusation(){
  const c = state.currentCase;
  const correct = state.selectedSuspect === c.liarIndex;
  if(correct){
    handleWin();
  } else {
    state.mistakes++;
    state.lives--;
    SFX.wrong();
    $("#screen-investigation").classList.add("shake");
    setTimeout(()=>$("#screen-investigation").classList.remove("shake"), 450);
    if(!state.isEndless){ SAVE.wrongAccusations++; }
    state.selectedSuspect = null;
    renderInvestigation();
    if(state.lives<=0){ persist(); handleFail(); }
    else { showToast("❌ Wrong Accusation! A life was lost."); }
  }
}

function computeStars(){
  if(state.mistakes===0 && state.hintsUsed===0) return 3;
  if(state.mistakes<=1 && state.hintsUsed<=1) return 2;
  return 1;
}

function handleWin(){
  const c = state.currentCase;
  SFX.correct();
  const stars = computeStars();
  const coinsEarned = 10 + stars*5;
  const scoreEarned = 100 + stars*40 - state.mistakes*15;

  if(state.isEndless){
    SAVE.endless.played++; SAVE.endless.wins++; SAVE.endless.streak++;
    SAVE.endless.bestStreak = Math.max(SAVE.endless.bestStreak, SAVE.endless.streak);
  } else {
    SAVE.casesSolved++; SAVE.correctAccusations++; SAVE.currentStreak++;
    SAVE.bestStreak = Math.max(SAVE.bestStreak, SAVE.currentStreak);
    SAVE.caseStars[c.id] = Math.max(SAVE.caseStars[c.id]||0, stars);
    SAVE.unlockedCase = Math.max(SAVE.unlockedCase, Math.min(c.id+1, 51));
  }
  SAVE.coins += coinsEarned;
  SAVE.score += Math.max(20, scoreEarned);
  persist();
  const newAch = checkAchievements();
  setTimeout(()=>SFX.complete(), 150);

  const overlay = document.createElement("div");
  overlay.className = "overlay";
  overlay.innerHTML = `
    <div class="card modal success">
      <div class="big-icon">🕵️‍♀️</div>
      <h2>CASE SOLVED</h2>
      <div class="stars-earned">${"⭐".repeat(stars)}${"☆".repeat(3-stars)}</div>
      <div class="explain">${c.explanation}</div>
      <div class="reward-row"><span>💰 +${coinsEarned}</span><span>📈 +${Math.max(20,scoreEarned)}</span></div>
      ${newAch.length ? `<div class="explain" style="border-color:var(--gold);">🏆 Achievement unlocked: <b>${newAch.map(a=>a.name).join(", ")}</b></div>` : ""}
      <div class="btn-row" style="margin-top:6px;">
        <button class="btn" id="btn-back-cases">Back to Cases</button>
        <button class="btn btn-primary" id="btn-next-case">Next Case →</button>
      </div>
    </div>`;
  document.body.appendChild(overlay);
  overlay.querySelector("#btn-back-cases").onclick = ()=>{
    overlay.remove();
    if(state.isEndless){ goHome(); } else { showScreen("screen-cases"); renderCaseSelect(); }
  };
  overlay.querySelector("#btn-next-case").onclick = ()=>{
    overlay.remove();
    if(state.isEndless){ startCase_(null, true); }
    else if(c.id < 50){ startCase_(c.id+1, false); }
    else { showScreen("screen-cases"); renderCaseSelect(); }
  };
}

function handleFail(){
  if(!state.isEndless){ SAVE.currentStreak = 0; }
  else { SAVE.endless.streak = 0; SAVE.endless.played++; }
  persist();
  const c = state.currentCase;
  const overlay = document.createElement("div");
  overlay.className = "overlay";
  overlay.innerHTML = `
    <div class="card modal fail">
      <div class="big-icon">🚫</div>
      <h2>CASE FAILED</h2>
      <p style="color:var(--text-dim);font-size:14px;margin:8px 0 16px;">You've run out of investigation attempts.</p>
      <div class="btn-row">
        <button class="btn" id="btn-review">Review Clues</button>
        <button class="btn" id="btn-back">Back to Cases</button>
        <button class="btn btn-primary" id="btn-retry">Try Again</button>
      </div>
    </div>`;
  document.body.appendChild(overlay);
  overlay.querySelector("#btn-retry").onclick = ()=>{ overlay.remove(); startCase_(state.isEndless ? null : c.id, state.isEndless); };
  overlay.querySelector("#btn-back").onclick = ()=>{
    overlay.remove();
    if(state.isEndless){ goHome(); } else { showScreen("screen-cases"); renderCaseSelect(); }
  };
  overlay.querySelector("#btn-review").onclick = ()=>{
    overlay.remove();
    c.allCluesForReview.forEach(cl=>discoverClue(c, cl));
    renderInvestigation();
    showToast("💡 " + c.explanation, 5500);
  };
}

function goHome(){ showScreen("screen-menu"); renderMenu(); }

/* ============================================================
   8. PARTICLES (decorative)
   ============================================================ */
function initParticles(){
  const wrap = $("#particles");
  const count = window.innerWidth < 640 ? 10 : 18;
  for(let i=0;i<count;i++){
    const p = document.createElement("div");
    p.className = "particle";
    const size = 2 + Math.random()*3;
    p.style.width = size+"px"; p.style.height = size+"px";
    p.style.left = (Math.random()*100)+"%";
    p.style.setProperty("--drift", (Math.random()*60-30)+"px");
    p.style.animationDuration = (14 + Math.random()*14)+"s";
    p.style.animationDelay = (Math.random()*14)+"s";
    wrap.appendChild(p);
  }
}

/* ============================================================
   9. WIRE UP EVENTS
   ============================================================ */
function wireEvents(){
  document.body.addEventListener("pointerdown", ensureAudio, {once:true});

  $("#btn-play").onclick = ()=>{ SFX.click(); startCase_(Math.min(SAVE.unlockedCase,50), false); };
  $("#btn-cases").onclick = ()=>{ SFX.click(); activeChapterFilter = Math.min(5, Math.ceil(SAVE.unlockedCase/10) || 1); showScreen("screen-cases"); renderCaseSelect(); };
  $("#btn-endless").onclick = ()=>{ SFX.click(); state.endlessCounter = 0; startCase_(null, true); };
  $("#btn-achievements").onclick = ()=>{ SFX.click(); showScreen("screen-achievements"); renderAchievements(); };
  $("#btn-settings").onclick = ()=>{ SFX.click(); showScreen("screen-settings"); renderSettings(); };

  $("#back-from-cases").onclick = ()=>{ SFX.click(); goHome(); };
  $("#back-from-inv").onclick = ()=>{ SFX.click(); if(state.isEndless){ goHome(); } else { showScreen("screen-cases"); renderCaseSelect(); } };
  $("#back-from-ach").onclick = ()=>{ SFX.click(); goHome(); };
  $("#back-from-settings").onclick = ()=>{ SFX.click(); goHome(); };

  $("#btn-inspect-scene").onclick = ()=>{ SFX.click(); openScenePanel(); };
  $("#btn-hint").onclick = doHint;
  $("#btn-accuse").onclick = doAccuse;

  $("#toggle-sound").onchange = (e)=>{ SAVE.settings.sound = e.target.checked; persist(); if(e.target.checked){ ensureAudio(); SFX.click(); } };
  $("#btn-reset").onclick = ()=>{
    if(confirm("Reset all progress? This cannot be undone.")){
      SAVE = defaultSave(); persist(); goHome(); showToast("Progress reset.");
    }
  };
}

/* ============================================================
   10. INIT
   ============================================================ */
function init(){ initParticles(); wireEvents(); goHome(); }
document.addEventListener("DOMContentLoaded", init);
})();