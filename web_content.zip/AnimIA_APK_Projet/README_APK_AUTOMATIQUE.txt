AnimIA - Générer un APK Android via GitHub Actions (sans Android Studio)

Cette archive contient le code de l'application et un workflow de compilation.
Le fichier APK n'est pas encore généré dans cette archive.


ÉTAPES
1) Sur GitHub, connecte-toi ou crée un compte, puis crée un nouveau dépôt (Repository).
2) Dézippe cette archive sur un ordinateur. Si tu n'as qu'un téléphone, il faut un outil permettant d'envoyer les fichiers du projet sur GitHub.
3) Envoie (upload) tous les fichiers et dossiers du projet dézippé dans le dépôt GitHub, y compris le dossier caché .github/workflows.
4) Dans GitHub, ouvre l'onglet Actions. Choisis "Build AnimIA APK".
5) Appuie sur "Run workflow". Attends que le job soit terminé (vert).
6) Dans les détails du run, récupère l'artefact "AnimIA-debug-apk". Il contient app-debug.apk.
7) Télécharge l'artefact, dézippe-le, puis installe app-debug.apk sur ton Android.

NOTES
- Le workflow compile une APK debug, destinée à l'installation/test.
- L'application utilise Gemini : ajoute ta clé API dans Réglages (⚙️) de l'application après installation.
- Ne partage pas ta clé API et ne la mets pas dans les fichiers du dépôt.
- Si la compilation échoue, ouvre le log GitHub Actions et partage-le pour dépannage.
