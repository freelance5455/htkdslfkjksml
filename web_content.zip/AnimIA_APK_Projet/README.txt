AnimIA Android - projet Capacitor

Le fichier www/index.html contient l'application web.

Pour préparer le projet Android :
1. Installe Node.js et Android Studio.
2. Dans ce dossier, ouvre un terminal.
3. Lance : npm install
4. Lance : npx cap add android (une seule fois)
5. Lance : npx cap sync android
6. Lance : npx cap open android
7. Dans Android Studio : Build > Build Bundle(s) / APK(s) > Build APK(s)

Attention : la clé Gemini est enregistrée dans le stockage local du navigateur de l'app.
Ne partage pas ton APK avec une clé API déjà enregistrée. Pour une app distribuée, utilise un serveur relais sécurisé.
