LA CONQUISTA — BETA 0.6.1

Cambios principales:
- Escala temporal global: 1 día real = 1 año de juego.
- Temporadas de 35 años = 35 días reales.
- Semana de entrenamiento ≈ 28 minutos reales.
- Construcciones/procesos usan años de juego para mantener la misma escala.
- Castillo y edificios especializados tienen niveles.
- Mejoras de tropas y tecnologías exigen requisitos de Castillo/edificios.
- El ejército actual se usa en el motor de batalla.
- Avisos de retos, bonus diario, Espionaje I y mensajería predefinida incluidos.

IMPORTANTE: este paquete es un proyecto Android WebView de prototipo. Para generar el APK abre la carpeta en Android Studio y ejecuta Build > Build APK(s), o usa un compilador online compatible con proyectos Android.
