LA CONQUISTA — BETA 0.5

Proyecto Android de prueba que empaqueta el prototipo HTML de La Conquista en una app WebView.

Cómo abrirlo:
1. Instala Android Studio.
2. Abre esta carpeta como proyecto.
3. Espera a que Gradle sincronice.
4. Pulsa Run para instalarlo en un móvil Android conectado o en un emulador.
5. Para generar un APK: Build > Build APK(s).

ID de aplicación: com.laconquista.beta
Versión: 0.5-beta

La partida se guarda localmente en el dispositivo mediante localStorage.
