PAN SHOP KHATA - FINAL ANDROID PROJECT

Package: com.panshop.khata
Web app asset: app/src/main/assets/index.html

Build in Android Studio:
1. Open this folder as a project.
2. Let Android Studio sync Gradle.
3. Build > Generate App Bundles or APKs > Generate APKs > Generate Signed Bundle/APK.
4. The included release keystore is configured in app/build.gradle.

Release keystore:
Alias: panshop
Store/key password: PanShop@2026

The app requests INTERNET permission and loads the supplied HTML from Android assets inside a WebView. This avoids treating the HTML file itself as an APK and ensures the launcher opens the app UI.
