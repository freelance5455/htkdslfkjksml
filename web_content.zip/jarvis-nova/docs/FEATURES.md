# J.A.R.V.I.S. NOVA — Features: Implemented vs Planned vs Not Possible

## Implemented (in this source)

### Core & navigation
- [x] Boot screen with animated reactor + real system-check lines
- [x] Bottom navigation (Command, Voice, Chat, Workspace, More) — one-hand friendly
- [x] All 18 screens from the brief (see README screen map)
- [x] Original HTML HUD preserved unmodified in the Command Center WebView

### AI (Gemini)
- [x] Official REST integration: `generateContent` + `streamGenerateContent?alt=sse`, `x-goog-api-key` header
- [x] Models: `gemini-2.5-flash` (default), `gemini-2.5-flash-lite`, `gemini-2.5-pro`
- [x] Streaming with cancellation (coroutine cancel cancels the OkHttp call)
- [x] Retry after failure; typed errors (invalid key, rate limit 429, unsupported model 404, network, server)
- [x] Test-connection button that makes a real API call
- [x] Multi-turn history (last 24 turns), per-conversation system prompts
- [x] Image input: attach a photo in Chat → sent as inline base64 JPEG part
- [x] Temperature + max-output-tokens settings; streaming toggle

### Voice
- [x] Android TextToSpeech: device voice list, pitch/rate/volume, personality presets, preview
- [x] Speech queue discipline: QUEUE_FLUSH — new speech supersedes, "Stop speaking" interrupts instantly
- [x] Auto-speak toggle; text fallback whenever TTS is unavailable
- [x] Android SpeechRecognizer push-to-talk with partial results, visible LISTENING state, error mapping
- [x] No background listening, ever

### Commands & device integration
- [x] 5-tier command router (local / AI / Android action / external-confirm / unsupported) + 20 unit tests
- [x] Focus timer (real countdown, notification + spoken completion, presets)
- [x] YouTube/web search intents, focus-playlist intent, open-URL with scheme check
- [x] Share intents (conversation export, bridge share), clipboard copy
- [x] Document picker (SAF) for text files → Gemini summarize
- [x] Notes & tasks with WorkManager reminders; haptics via bridge; app/system settings intents
- [x] Battery + network status via public APIs (Diagnostics)

### Data & privacy
- [x] Room DB: conversations, messages, notes, tasks, shortcuts
- [x] DataStore preferences (theme, accent, motion/power, voice, model, memory)
- [x] API key AES-256/GCM encrypted via Android Keystore; never logged/exported
- [x] History: search, rename, favorite, archive, export, delete (confirmed)
- [x] Privacy screen: delete all conversations / wipe everything (confirmed)
- [x] Backups disabled (`allowBackup=false`, extraction rules exclude everything)
- [x] Permissions: INTERNET, RECORD_AUDIO, POST_NOTIFICATIONS, VIBRATE — only

### Templates
- [x] 15 templates (14 from the brief + Custom), each with system prompt + 3–4 quick actions
- [x] Selecting a template or quick action starts a real chat with its prompt

### Hologram workspace (honest scope)
- [x] Compose Canvas reactor: rotating tick ring, counter-rotating arcs, circular visualizer bars, glowing core
- [x] Full-screen visualizer screen; reduced-motion + low-power respected app-wide
- [x] Workspace hub with floating-panel cards and persisted appearance settings

## Planned (not in this version — with reasons)

- **3D model import/preview in the workspace** — needs a renderer decision
  (SceneView/Filament adds ~10 MB+ and real GPU cost). The reactor workspace
  ships first for performance; add behind the low-power toggle later.
- **Save/restore multiple workspace layouts** — appearance persists today;
  named multi-layout snapshots are a small DataStore extension away.
- **Gemini Live / native audio conversation** — model/account availability
  varies; the TTS+STT loop covers voice conversation reliably today.
- **PDF text extraction** — needs a parser dependency (e.g. PdfBox-Android);
  `PdfRenderer` only renders. Document screen is scoped to text files and
  says so in its UI.
- **MediaSession playback controls for other apps** — only legitimate for
  the app's own playback or a NotificationListener (a sensitive permission
  this app deliberately does not request).
- **Quick Settings tile / launcher shortcuts** — straightforward additions
  once the core is proven on-device.
- **Release-signed APK** — signing needs *your* keystore; README documents
  the keytool/Gradle steps. Never commit a shared signing key.

## Not possible / will not be claimed

- **Always-on background wake word** ("Hey JARVIS" with the app closed):
  Android restricts background microphone use; a foreground-service
  hotword is battery-heavy and Play-policy sensitive. NOVA is
  push-to-talk with a visible indicator — by design, not omission.
- **Arbitrary control of other apps** (auto-taps, reading other apps'
  private messages, unlocking content): blocked by Android security and
  accessibility policy. NOVA uses official intents and user confirmation.
- **A real hologram**: phone screens display 2D visuals. The visualizer is
  an on-screen effect and is labelled as such.
- **Guaranteed Gemini-generated speech**: audio output depends on the
  selected model and account. NOVA's voice is device TTS (tuned), and the
  Voice Studio says so plainly instead of pretending otherwise.
- **Playback control/status for every media app**: apps expose this
  inconsistently; NOVA opens media apps and never guesses playback state.
