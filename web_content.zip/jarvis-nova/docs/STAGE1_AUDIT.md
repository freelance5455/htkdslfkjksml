# Stage 1 Audit — Existing HTML Project

Source inspected: `~/workspace/your_files/jarvis/index.html`
(preserved byte-for-byte at `app/src/main/assets/jarvis/index.html` in this project)

## What it is

- **Single self-contained HTML file**: 124,229 bytes, 2,158 lines, zero external
  dependencies, boots from `file://` and fully offline.
- **Title**: "J.A.R.V.I.S. — Personal AI Assistant".
- **Structure**: inline CSS (custom properties, deep-navy/cyan HUD theme) +
  inline JS (~79 functions). No framework.
- **Screens** (show/hide divs, side nav on desktop, bottom nav on mobile):
  Command, Chat, Missions (tasks), Notes, Files, Automations, History,
  Diagnostics, Settings, Help, plus a palette/command console.
- **Visuals**: canvas-based animated reactor (state-reactive: idle / listening /
  speaking / thinking), boot sequence with system-check log lines, HUD chips
  for AI/system/voice status.

## AI layer (as built — NOT Gemini)

- Provider presets: **Pollinations** (default, `https://text.pollinations.ai/openai`,
  model `openai`, free, no key), **OpenRouter**
  (`https://openrouter.ai/api/v1/chat/completions`, model `openai/gpt-4o-mini`,
  sends `Authorization` + `HTTP-Referer` + `X-Title`), and a generic
  OpenAI-compatible "custom" endpoint.
- Streaming via SSE against OpenAI-compatible chat completions.
- API key held **in memory only** (`AI.key`) — never in localStorage, never
  logged — but consequently **lost on every reload**.

## Voice (as built — browser-only)

- Input: Web Speech API `SpeechRecognition` (push-to-talk default), with a
  **7-second watchdog** if the speech service never responds ("VOICE SERVICE
  UNREACHABLE — TYPE INSTEAD"), because a denied/unavailable mic otherwise
  hangs silently.
- Output: `speechSynthesis` wrapper, every call guarded; voice list, pitch and
  rate from Settings.

## Storage

- `localStorage` wrapper (`jarvis.*` keys), JSON, try/catch, quota-safe.
- Holds prefs, tasks/missions, notes, automations, conversation history.
  Files screen stores metadata/previews, not real file contents.

## Bugs & limits found (why the Android migration is necessary)

1. **No Gemini anywhere.** The brief's "Gemini integration" does not exist in
   the HTML; Pollinations/OpenRouter are the only providers. → NOVA implements
   a real Gemini REST client (`data/GeminiClient.kt`).
2. **Pollinations is slow and shared**: ~38 s observed response latency from
   the sandbox, public rate limits, no SLA. Acceptable as a demo default,
   unacceptable as the core AI.
3. **Web Speech does not work reliably in Android WebView**: `SpeechRecognition`
   is unavailable there, and Chrome's web speech service requires network +
   browser context. → NOVA uses native `SpeechRecognizer` + `TextToSpeech`
   behind a JS bridge (`voice/VoiceManager.kt`, `web/JarvisBridge.kt`).
4. **Mic access is environment-dependent**: in sandboxed/embedded contexts the
   user may be unable to grant mic permission at all; the HTML degrades to
   typing (by design) but can do nothing better. → Native permission flow +
   Permissions dashboard in NOVA.
5. **Key lost on reload** (memory-only). Secure on paper, annoying in
   practice. → NOVA stores the key AES/GCM-encrypted via Android Keystore.
6. **No native capabilities**: no real notifications, share sheet, clipboard
   integration, document picker, haptics, or background reminders — the HTML
   is honest about the browser-vs-native boundary in its Help/Diagnostics
   screens, but the boundary is the limit.
7. **No push/install story on Android** beyond "open the file / add to home
   screen"; service-worker support varies by context.
8. Duplicate provider-header logic (OpenRouter headers assembled in two
   places) and provider switching by string-matching — fragile if presets
   change.

## What was preserved

- The **entire HTML file, unmodified**, as the Command Center HUD.
- Its local command ideas (allowlist-style actions, safe fallbacks) informed
  the native `CommandRouter` tiers.
- Its honesty rules: never claim an action succeeded without performing it;
  typed fallback for voice; keys never stored in plain text.
