# J.A.R.V.I.S. NOVA — Android AI Assistant

A Kotlin + Jetpack Compose Android app that wraps a real Gemini AI core,
a native voice engine, and a 5-tier command router inside a cinematic
holographic interface — with the original single-file HTML HUD preserved
unmodified as the Command Center's WebView layer.

- **Package**: `com.nuraid.jarvisnova`
- **minSdk 26 · targetSdk / compileSdk 35**
- **Permissions**: INTERNET, RECORD_AUDIO, POST_NOTIFICATIONS, VIBRATE — nothing else

---

## Architecture

```
┌──────────────────────────────────────────────────────────────┐
│  UI (Jetpack Compose, Material 3)                            │
│  18 screens · NavHost · bottom nav (Command/Voice/Chat/      │
│  Workspace/More) · Reactor = Compose Canvas                  │
├──────────────────────────────────────────────────────────────┤
│  AppViewModel (single shared ViewModel, StateFlow)           │
│  chat state · generation job · focus timer · settings        │
├───────────────┬──────────────────┬───────────────────────────┤
│ CommandRouter │  VoiceManager    │  JarvisBridge (WebView)   │
│ 5-tier, pure  │  TTS + STT       │  window.AndroidNova       │
│ Kotlin, tested│  push-to-talk    │  → native capabilities    │
├───────────────┴──────────────────┴───────────────────────────┤
│  Repository                                                  │
│  ├─ Room DB: conversations/messages/notes/tasks/shortcuts    │
│  ├─ DataStore: preferences                                   │
│  ├─ KeyStoreManager: API key, AES-256/GCM in Android Keystore│
│  └─ GeminiClient: OkHttp → generativelanguage.googleapis.com │
│       v1beta generateContent / streamGenerateContent (SSE)   │
├──────────────────────────────────────────────────────────────┤
│  WorkManager: task reminder notifications                    │
│  Assets: jarvis/index.html (original HUD, byte-identical)    │
│          jarvis/nova_bridge.js (injected shim, HUD untouched) │
└──────────────────────────────────────────────────────────────┘
```

### Screen map (18)

| # | Screen | Route | Notes |
|---|--------|-------|-------|
| 1 | Boot / initialization | `boot` | Reactor + real system-check lines |
| 2 | Command Center | `command` | Original HUD (WebView + bridge) + native command bar |
| 3 | Voice Conversation | `voice` | Push-to-talk, visible listening state |
| 4 | AI Chat | `chat` | Streaming Gemini, cancel/retry, image attach, copy |
| 5 | Holographic Visualizer | `visualizer` | Full-screen reactor (on-screen effect) |
| 6 | Media Launcher | `media` | YouTube/web intents, favorites |
| 7 | Workspace | `workspace` | Panel hub + appearance |
| 8 | Notes & Tasks | `notes_tasks` | Room-backed, WorkManager reminders |
| 9 | Focus Timer | `focus` | Real countdown + notification |
| 10 | Document Assistant | `document` | SAF picker, .txt/.md → Gemini (PDF scoped out, in-app note explains why) |
| 11 | AI Model Settings | `model_settings` | Encrypted key, model picker, test connection |
| 12 | Voice Studio | `voice_studio` | Device voices, pitch/rate/volume, presets |
| 13 | Automation & Shortcuts | `automation` | Prompt/URL shortcuts CRUD |
| 14 | Permissions Dashboard | `permissions` | Live states + rationales |
| 15 | Privacy & Security | `privacy` | Disclosures, delete/wipe with confirmation |
| 16 | Conversation History | `history` | Search/rename/archive/favorite/export/delete |
| 17 | Template Library | `templates` | 15 templates with system prompts + quick actions |
| 18 | About & Diagnostics | `about` | Battery/network/device, key-free report |

Plus a bottom-bar **More** hub that links the settings/utility screens.

---

## Setup

### 1. Open the project

Open this folder in **Android Studio** (Ladybug or newer). It will sync
Gradle (AGP 8.7.3, Kotlin 2.0.21, Gradle 8.9 wrapper config).

> **Wrapper note (honest):** this repo ships `gradle/wrapper/gradle-wrapper.properties`
> but the `gradle-wrapper.jar` binary is not fabricated/checked in. On first
> open, Android Studio offers to generate the wrapper — accept it, or run
> `gradle wrapper --gradle-version 8.9` once with any local Gradle, or use
> Android Studio's built-in Gradle. After that, `./gradlew` works normally.

### 2. Add your Gemini API key

No key is — or ever should be — hardcoded. At runtime:

**More → AI Model Settings → paste your key → Save key.**

Get a key at <https://aistudio.google.com/apikey>. The key is encrypted
on-device (Android Keystore, AES/GCM) and never leaves the device except
as the `x-goog-api-key` header on Gemini requests. API usage may incur
charges or hit free-tier quotas on your Google account.

**Production note:** for a public release, do not ship an app that holds
a shared key — route requests through your own backend proxy that holds
the key server-side. The in-app key flow is for personal/prototype use.

### 3. Build a debug APK

In Android Studio: **Build → Build App Bundle(s) / APK(s) → Build APK(s)**,
or from a terminal once the wrapper exists:

```bash
./gradlew assembleDebug
# Output: app/build/outputs/apk/debug/app-debug.apk
```

### 4. Install

- **USB**: enable Developer Options + USB debugging on the phone, connect,
  and use Android Studio's Run button, or:
  ```bash
  adb install -r app/build/outputs/apk/debug/app-debug.apk
  ```
- **Manual**: copy the APK to the phone and open it (allow "install from
  this source" when Android asks).

### 5. Build a release APK (signing)

```bash
# One-time: create YOUR keystore (keep the file + passwords private, never commit)
keytool -genkeypair -v -keystore ~/jarvis-nova-release.jks -alias nova \
  -keyalg RSA -keysize 2048 -validity 10000

# Then either use Android Studio: Build → Generate Signed App Bundle / APK
# (point it at that keystore), or add a signingConfigs block in
# app/build.gradle.kts reading the credentials from ~/.gradle/gradle.properties:
#   NOVA_STORE_FILE=/path/jarvis-nova-release.jks
#   NOVA_STORE_PASSWORD=…  NOVA_KEY_ALIAS=nova  NOVA_KEY_PASSWORD=…

./gradlew assembleRelease
# Output: app/build/outputs/apk/release/app-release.apk
```

---

## Privacy

- Microphone: push-to-talk only, visible indicator, no background listening, no wake word.
- The API key never appears in logs, screenshots, exports, or diagnostics.
- Conversations/notes/tasks stay on-device; Android backup is disabled for the app.
- Chat text is sent to Google's Gemini API (your key, your account, Google's API terms).
- Full disclosures live in the app's Privacy & Security screen.

## Testing

```bash
./gradlew testDebugUnitTest        # CommandRouter (20 cases) + templates/settings
./gradlew connectedDebugAndroidTest # UI smoke test — needs an emulator/device
```

**Verification status of this delivery:** this source was produced in an
environment **without a JDK/Android SDK**, so it has been checked
statically (route/symbol consistency, asset integrity, brace balance)
but **not compiled and no tests were executed**. First step in Android
Studio: let Gradle sync and fix anything the compiler flags. See
`docs/FEATURES.md` for exactly what is implemented vs planned.

### Manual test checklist

- [ ] Mic: deny permission → voice screen explains + typing still works; grant → one push-to-talk round trip
- [ ] Audio: preview voice in Voice Studio; start a long reply, tap "Stop speaking" → speech stops immediately; new reply never overlaps the old one
- [ ] Permissions: each request button works; revoked notification permission → timer still completes in-app
- [ ] API failures: wrong key → "key rejected" message; airplane mode → network error + Retry; quota → 429 message
- [ ] Lifecycle: start streaming, background the app, return → state sane; rotate during focus timer → countdown survives
- [ ] WebView HUD: boots offline from assets; HUD buttons work; bridge `NovaNative.available === true` in console
- [ ] Data: kill + relaunch → conversations/notes/tasks/shortcuts intact; Privacy wipe → everything gone, key removed

## Docs

- `docs/STAGE1_AUDIT.md` — what the original HTML was, and its bugs/limits
- `docs/FEATURES.md` — implemented vs planned vs not-possible (with reasons)
