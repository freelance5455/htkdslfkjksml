package com.nuraid.jarvisnova

import com.nuraid.jarvisnova.domain.CommandRouter
import com.nuraid.jarvisnova.domain.CommandRouter.CommandResult
import com.nuraid.jarvisnova.domain.CommandRouter.IntentKind
import com.nuraid.jarvisnova.domain.CommandRouter.LocalAction
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class CommandRouterTest {

    private fun local(result: CommandResult): CommandResult.LocalHandled {
        assertTrue("expected LocalHandled, got $result", result is CommandResult.LocalHandled)
        return result as CommandResult.LocalHandled
    }

    @Test
    fun `stop speaking is local`() {
        val r = local(CommandRouter.route("stop speaking"))
        assertEquals(LocalAction.StopSpeaking, r.action)
    }

    @Test
    fun `cancel that is local cancel`() {
        val r = local(CommandRouter.route("cancel that action"))
        assertEquals(LocalAction.CancelCurrent, r.action)
    }

    @Test
    fun `25 minute focus session parses duration`() {
        val r = local(CommandRouter.route("Start a 25-minute focus session"))
        assertEquals(LocalAction.StartFocus(25), r.action)
    }

    @Test
    fun `one hour focus parses to 60 minutes`() {
        val r = local(CommandRouter.route("start a 1 hour focus session"))
        assertEquals(LocalAction.StartFocus(60), r.action)
    }

    @Test
    fun `bare focus defaults to 25 minutes`() {
        val r = local(CommandRouter.route("start focus"))
        assertEquals(LocalAction.StartFocus(25), r.action)
    }

    @Test
    fun `focus playlist is an android action`() {
        val r = CommandRouter.route("Play my focus playlist")
        assertTrue(r is CommandResult.AndroidAction)
        assertEquals(IntentKind.PLAY_FOCUS_PLAYLIST, (r as CommandResult.AndroidAction).intent)
    }

    @Test
    fun `find tutorial searches youtube`() {
        val r = CommandRouter.route("Find a tutorial about Blender")
        assertTrue(r is CommandResult.AndroidAction)
        val action = r as CommandResult.AndroidAction
        assertEquals(IntentKind.YOUTUBE_SEARCH, action.intent)
        assertTrue(action.payload.contains("Blender"))
    }

    @Test
    fun `summarize goes to AI`() {
        val r = CommandRouter.route("Summarize this text: the quick brown fox")
        assertTrue(r is CommandResult.AiRequest)
    }

    @Test
    fun `explain code goes to AI`() {
        val r = CommandRouter.route("Explain this code")
        assertTrue(r is CommandResult.AiRequest)
    }

    @Test
    fun `study plan goes to AI`() {
        val r = CommandRouter.route("Create a study plan for physics")
        assertTrue(r is CommandResult.AiRequest)
    }

    @Test
    fun `save idea saves a note`() {
        val r = local(CommandRouter.route("Save this idea: a floating desk lamp"))
        assertTrue(r.action is LocalAction.SaveNote)
        assertTrue((r.action as LocalAction.SaveNote).text.contains("floating desk lamp"))
    }

    @Test
    fun `open notes is local`() {
        val r = local(CommandRouter.route("Open my notes"))
        assertEquals(LocalAction.OpenNotes, r.action)
    }

    @Test
    fun `recent tasks is local`() {
        val r = local(CommandRouter.route("Show my recent tasks"))
        assertEquals(LocalAction.ShowRecentTasks, r.action)
    }

    @Test
    fun `dark mode on and off`() {
        assertEquals(
            LocalAction.SetDarkMode(true),
            local(CommandRouter.route("Turn on dark mode")).action
        )
        assertEquals(
            LocalAction.SetDarkMode(false),
            local(CommandRouter.route("Turn off dark mode")).action
        )
    }

    @Test
    fun `remember preference is local`() {
        val r = local(CommandRouter.route("Remember my preferred response style is short"))
        assertTrue(r.action is LocalAction.RememberPreference)
    }

    @Test
    fun `read aloud with explicit text`() {
        val r = local(CommandRouter.route("Read this: the reactor is online and stable"))
        assertTrue(r.action is LocalAction.ReadAloud)
    }

    @Test
    fun `blank input is unsupported`() {
        assertTrue(CommandRouter.route("   ") is CommandResult.Unsupported)
    }

    @Test
    fun `arbitrary question defaults to AI`() {
        val r = CommandRouter.route("What is the capital of Norway?")
        assertTrue(r is CommandResult.AiRequest)
    }

    @Test
    fun `parseDurationMinutes handles forms`() {
        assertEquals(25, CommandRouter.parseDurationMinutes("25 minutes"))
        assertEquals(45, CommandRouter.parseDurationMinutes("45 min"))
        assertEquals(120, CommandRouter.parseDurationMinutes("2 hours"))
        assertEquals(null, CommandRouter.parseDurationMinutes("no duration here"))
    }
}
