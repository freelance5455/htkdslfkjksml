package com.nuraid.jarvisnova

import com.nuraid.jarvisnova.data.GeminiModels
import com.nuraid.jarvisnova.data.NovaSettings
import com.nuraid.jarvisnova.data.Templates
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class TemplatesAndSettingsTest {

    @Test
    fun `library has 14 presets plus custom`() {
        assertEquals(15, Templates.ALL.size)
        assertNotNull(Templates.byId("custom"))
        assertNotNull(Templates.byId("focus_cockpit"))
        assertNotNull(Templates.byId("developer_studio"))
    }

    @Test
    fun `template ids are unique`() {
        val ids = Templates.ALL.map { it.id }
        assertEquals(ids.size, ids.toSet().size)
    }

    @Test
    fun `every template has a system prompt and quick actions`() {
        Templates.ALL.forEach { template ->
            assertTrue("prompt blank in ${template.id}", template.systemPrompt.isNotBlank())
            assertTrue("actions missing in ${template.id}", template.quickActions.size in 3..4)
        }
    }

    @Test
    fun `default settings use the default gemini model`() {
        val settings = NovaSettings()
        assertEquals(GeminiModels.FLASH, settings.geminiModel)
        assertTrue(GeminiModels.ALL.contains(settings.geminiModel))
        assertTrue(settings.darkTheme)
        assertTrue(settings.autoSpeak)
    }

    @Test
    fun `model list contains the documented models`() {
        assertEquals(
            listOf("gemini-2.5-flash", "gemini-2.5-flash-lite", "gemini-2.5-pro"),
            GeminiModels.ALL
        )
    }
}
