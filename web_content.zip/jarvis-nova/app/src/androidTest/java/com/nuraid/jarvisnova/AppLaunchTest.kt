package com.nuraid.jarvisnova

import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithText
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

/**
 * Core-flow UI test: the app launches, shows the boot screen, and the
 * boot system-check lines appear. Requires an emulator/device:
 *   ./gradlew connectedDebugAndroidTest
 */
@RunWith(AndroidJUnit4::class)
class AppLaunchTest {

    @get:Rule
    val composeRule = createAndroidComposeRule<MainActivity>()

    @Test
    fun bootScreenShowsBranding() {
        composeRule.onNodeWithText("J.A.R.V.I.S. NOVA").assertIsDisplayed()
    }
}
