package com.nuraid.jarvisnova.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.nuraid.jarvisnova.ui.AppViewModel
import com.nuraid.jarvisnova.ui.Routes
import com.nuraid.jarvisnova.ui.components.NovaCard
import com.nuraid.jarvisnova.ui.components.ScreenTitle

private data class MoreEntry(val title: String, val description: String, val route: String)

private val ENTRIES = listOf(
    MoreEntry("Focus Timer", "Pomodoro-style focus sessions with a completion notification", Routes.FOCUS),
    MoreEntry("AI Model Settings", "Gemini key, model, temperature, streaming, test connection", Routes.MODEL_SETTINGS),
    MoreEntry("Voice Studio", "Voice, pitch, rate, volume, preview", Routes.VOICE_STUDIO),
    MoreEntry("Permissions Dashboard", "What each permission is for, and its live state", Routes.PERMISSIONS),
    MoreEntry("Privacy & Security", "Data disclosures, delete history, clear everything", Routes.PRIVACY),
    MoreEntry("About & Diagnostics", "Device, battery, network, feature status", Routes.ABOUT)
)

/** Bottom-bar "More" tab: the settings/utility half of the app. */
@Composable
fun MoreScreen(vm: AppViewModel, navigate: (String) -> Unit) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { ScreenTitle("More", "Settings, privacy and system tools") }
        items(ENTRIES) { entry ->
            NovaCard(modifier = Modifier.clickable { navigate(entry.route) }) {
                Text(entry.title, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
                Text(entry.description, style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}
