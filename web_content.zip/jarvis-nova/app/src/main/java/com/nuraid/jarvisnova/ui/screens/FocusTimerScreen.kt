package com.nuraid.jarvisnova.ui.screens

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.nuraid.jarvisnova.ui.AppViewModel
import com.nuraid.jarvisnova.ui.components.ScreenTitle

/** Focus timer: real countdown in the ViewModel, presets, haptic-friendly
 * big controls, completion notification + spoken confirmation. */
@Composable
fun FocusTimerScreen(vm: AppViewModel, navigate: (String) -> Unit) {
    val context = LocalContext.current
    val total by vm.focusTotalSeconds.collectAsState()
    val remaining by vm.focusRemainingSeconds.collectAsState()
    val running by vm.focusRunning.collectAsState()

    val notificationPermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { /* If denied, the timer still works — only the end notification is skipped. */ }

    fun start(minutes: Int) {
        if (Build.VERSION.SDK_INT >= 33) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        vm.startFocus(minutes, context)
        vm.speakIfEnabled("Focus session started, $minutes minutes.")
    }

    val progress = if (total > 0) remaining.toFloat() / total.toFloat() else 0f
    val mm = remaining / 60
    val ss = remaining % 60

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        ScreenTitle("Focus Timer", "One session at a time. Runs even if you switch screens.")
        CircularProgressIndicator(
            progress = { progress },
            modifier = Modifier.padding(12.dp),
            strokeWidth = 8.dp
        )
        Text(
            text = if (total == 0) "Ready" else "%02d:%02d".format(mm, ss),
            style = MaterialTheme.typography.displayMedium,
            color = MaterialTheme.colorScheme.primary
        )
        Text(
            text = when {
                running -> "Focusing…"
                total > 0 && remaining == 0 -> "Session complete"
                total > 0 -> "Paused / stopped"
                else -> "Pick a duration"
            }
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { start(15) }) { Text("15m") }
            Button(onClick = { start(25) }) { Text("25m") }
            OutlinedButton(onClick = { start(50) }) { Text("50m") }
            OutlinedButton(onClick = { start(90) }) { Text("90m") }
        }
        if (running) {
            OutlinedButton(
                onClick = { vm.stopFocus() },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Stop session") }
        }
        Text(
            text = "You'll get a notification and a spoken confirmation when the session ends (notification needs the Notifications permission on Android 13+).",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
