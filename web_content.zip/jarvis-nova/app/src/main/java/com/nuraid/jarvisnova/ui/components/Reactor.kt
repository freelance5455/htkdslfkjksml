package com.nuraid.jarvisnova.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.dp
import com.nuraid.jarvisnova.ui.theme.NovaColors
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * The reactor: layered Canvas rings, a tick ring, counter-rotating arcs
 * and a glowing core. Pure Compose Canvas — no heavy 3D, so it stays at
 * 60fps on mid-range phones.
 *
 * [level] (0f..1f) drives the audio-visualizer bars; callers pass a
 * changing level while speaking/listening, or a gentle idle value.
 * When [reduceMotion] or [lowPower] is set, the reactor renders as a
 * static frame (rotation/pulse frozen).
 */
@Composable
fun Reactor(
    modifier: Modifier = Modifier,
    level: Float = 0.25f,
    active: Boolean = false,
    reduceMotion: Boolean = false,
    lowPower: Boolean = false,
    accent: Color = NovaColors.Cyan
) {
    val animated = !reduceMotion && !lowPower
    val transition = rememberInfiniteTransition(label = "reactor")
    val rotation by transition.animateFloat(
        initialValue = 0f,
        targetValue = if (animated) 360f else 0f,
        animationSpec = infiniteRepeatable(tween(24_000, easing = LinearEasing)),
        label = "rotation"
    )
    val pulse by transition.animateFloat(
        initialValue = 0.9f,
        targetValue = if (animated) 1.1f else 1.0f,
        animationSpec = infiniteRepeatable(tween(1200, easing = LinearEasing), RepeatMode.Reverse),
        label = "pulse"
    )
    val clampedLevel = level.coerceIn(0f, 1f)
    val coreColor = MaterialTheme.colorScheme.primary

    Canvas(modifier = modifier.size(220.dp)) {
        val cx = size.width / 2
        val cy = size.height / 2
        val center = Offset(cx, cy)
        val maxR = size.minDimension / 2

        // Outer tick ring
        for (i in 0 until 60) {
            val angle = (i * 6f + rotation * 0.25f) * (PI / 180f).toFloat()
            val long = i % 5 == 0
            val r1 = maxR * 0.97f
            val r2 = maxR * (if (long) 0.90f else 0.94f)
            drawLine(
                color = accent.copy(alpha = if (long) 0.8f else 0.35f),
                start = Offset(cx + r1 * cos(angle), cy + r1 * sin(angle)),
                end = Offset(cx + r2 * cos(angle), cy + r2 * sin(angle)),
                strokeWidth = if (long) 3f else 1.5f
            )
        }

        // Counter-rotating dashed arc ring
        rotate(degrees = -rotation, pivot = center) {
            drawArc(
                color = accent.copy(alpha = 0.7f),
                startAngle = 0f, sweepAngle = 90f, useCenter = false,
                topLeft = Offset(cx - maxR * 0.82f, cy - maxR * 0.82f),
                size = androidx.compose.ui.geometry.Size(maxR * 1.64f, maxR * 1.64f),
                style = Stroke(width = 5f)
            )
            drawArc(
                color = NovaColors.Violet.copy(alpha = 0.6f),
                startAngle = 180f, sweepAngle = 90f, useCenter = false,
                topLeft = Offset(cx - maxR * 0.82f, cy - maxR * 0.82f),
                size = androidx.compose.ui.geometry.Size(maxR * 1.64f, maxR * 1.64f),
                style = Stroke(width = 5f)
            )
        }

        // Audio visualizer bars (circular)
        val bars = 36
        for (i in 0 until bars) {
            val angle = (i * (360f / bars) + rotation * 0.5f) * (PI / 180f).toFloat()
            val wave = 0.5f + 0.5f * sin(i * 1.7f + rotation * 0.12f)
            val magnitude = if (active) (0.25f + clampedLevel * wave) else (0.12f + 0.08f * wave)
            val r1 = maxR * 0.62f
            val r2 = maxR * (0.62f + 0.22f * magnitude)
            drawLine(
                color = accent.copy(alpha = 0.85f),
                start = Offset(cx + r1 * cos(angle), cy + r1 * sin(angle)),
                end = Offset(cx + r2 * cos(angle), cy + r2 * sin(angle)),
                strokeWidth = 4f
            )
        }

        // Inner ring
        drawCircle(
            color = accent.copy(alpha = 0.9f),
            radius = maxR * 0.58f,
            center = center,
            style = Stroke(width = 3f)
        )

        // Glowing core
        val coreRadius = maxR * 0.30f * pulse * (1f + if (active) clampedLevel * 0.25f else 0f)
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color.White, coreColor, accent.copy(alpha = 0.15f)),
                center = center,
                radius = coreRadius
            ),
            radius = coreRadius,
            center = center
        )
    }
}
