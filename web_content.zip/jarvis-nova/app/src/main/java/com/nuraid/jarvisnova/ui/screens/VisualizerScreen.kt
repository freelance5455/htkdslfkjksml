package com.nuraid.jarvisnova.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.nuraid.jarvisnova.ui.AppViewModel
import com.nuraid.jarvisnova.ui.components.Reactor
import com.nuraid.jarvisnova.ui.components.SettingRow
import com.nuraid.jarvisnova.ui.components.NovaCard
import com.nuraid.jarvisnova.ui.theme.NovaColors
import kotlinx.coroutines.delay

/**
 * Holographic visualizer: full-screen reactor with circular visualizer.
 * This is an ON-SCREEN visual effect — the phone does not project a
 * real hologram, and the level animation is a visual pulse, not
 * microphone amplitude.
 */
@Composable
fun VisualizerScreen(vm: AppViewModel, navigate: (String) -> Unit) {
    val settings by vm.settings.collectAsState()
    val isSpeaking by vm.voice.isSpeaking.collectAsState()
    val isListening by vm.voice.isListening.collectAsState()
    var level by remember { mutableStateOf(0.3f) }

    LaunchedEffect(isSpeaking, isListening) {
        while (true) {
            level = if (isSpeaking || isListening) (30..95).random() / 100f else (15..35).random() / 100f
            delay(if (settings.lowPower) 400 else 160)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(NovaColors.Navy)
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "Holographic Visualizer",
            style = MaterialTheme.typography.headlineSmall,
            color = NovaColors.Cyan
        )
        Reactor(
            level = level,
            active = isSpeaking || isListening,
            reduceMotion = settings.reduceMotion,
            lowPower = settings.lowPower
        )
        Text(
            text = when {
                isListening -> "Listening…"
                isSpeaking -> "Speaking…"
                else -> "Reactor idle"
            },
            color = NovaColors.TextPrimary
        )
        NovaCard {
            SettingRow("Reduced motion", "Freezes reactor animation") {
                androidx.compose.material3.Switch(
                    checked = settings.reduceMotion,
                    onCheckedChange = { vm.updateSettings { s -> s.copy(reduceMotion = it) } }
                )
            }
            SettingRow("Low-power mode", "Slower animation, less battery use") {
                androidx.compose.material3.Switch(
                    checked = settings.lowPower,
                    onCheckedChange = { vm.updateSettings { s -> s.copy(lowPower = it) } }
                )
            }
            Text(
                text = "Graphics quality follows these toggles everywhere in the app. The workspace's floating panels live in Workspace; this screen is the full-screen reactor view.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
