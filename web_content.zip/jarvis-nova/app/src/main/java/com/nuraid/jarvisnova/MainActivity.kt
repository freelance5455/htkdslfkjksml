package com.nuraid.jarvisnova

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import com.nuraid.jarvisnova.ui.AppViewModel
import com.nuraid.jarvisnova.ui.JarvisNovaRoot

/**
 * The single activity. Everything else is Compose screens behind a
 * NavHost (see ui/Navigation.kt). The Command Center screen additionally
 * hosts the preserved HTML HUD in a WebView.
 */
class MainActivity : ComponentActivity() {

    private val viewModel: AppViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            JarvisNovaRoot(vm = viewModel)
        }
    }
}
