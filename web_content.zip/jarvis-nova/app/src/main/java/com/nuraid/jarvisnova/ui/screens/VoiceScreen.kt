package com.nuraid.jarvisnova.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.nuraid.jarvisnova.ui.AppViewModel
import com.nuraid.jarvisnova.ui.Routes
import com.nuraid.jarvisnova.ui.components.Reactor
import com.nuraid.jarvisnova.ui.components.ScreenTitle
import kotlinx.coroutines.delay

/**
 * Voice conversation screen.
 *
 * Push-to-talk only: recording starts on the button, a visible
 * "LISTENING" indicator is shown the whole time, and recognition
 * auto-stops on result/error. Heard text is routed through the
 * command router; AI replies are spoken when auto-speak is on, and
 * voice mode continues the conversation in Chat.
 */
@Composable
fun VoiceScreen(vm: AppViewModel, navigate: (String) -> Unit) {
    val context = LocalContext.current
    val settings by vm.settings.collectAsState()
    val isListening by vm.voice.isListening.collectAsState()
    val isSpeaking by vm.voice.isSpeaking.collectAsState()
    val partial by vm.voice.partialResult.collectAsState()
    val speechError by vm.voice.speechError.collectAsState()
    val messages by vm.currentMessages.collectAsState()

    var lastHeard by remember { mutableStateOf<String?>(null) }
    var lastReply by remember { mutableStateOf<String?>(null) }
    var fakeLevel by remember { mutableStateOf(0.3f) }
    var pendingConfirm by remember { mutableStateOf<com.nuraid.jarvisnova.domain.CommandRouter.CommandResult.ExternalConfirm?>(null) }

    // Fake-but-labelled visualizer level while listening/speaking:
    // it animates the reactor; it is NOT real microphone amplitude.
    LaunchedEffect(isListening, isSpeaking) {
        while (isListening || isSpeaking) {
            fakeLevel = (20..90).random() / 100f
            delay(140)
        }
        fakeLevel = 0.25f
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            startListening(vm) { heard ->
                lastHeard = heard
                lastReply = vm.handleCommand(
                    heard, context,
                    onAndroidAction = { vm.executeAndroidAction(it, context) },
                    onExternalConfirm = { pendingConfirm = it }
                )
            }
        }
    }

    fun micTapped() {
        if (isListening) {
            vm.voice.stopListening()
            return
        }
        val granted = ContextCompat.checkSelfPermission(
            context, Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
        if (granted) {
            startListening(vm) { heard ->
                lastHeard = heard
                lastReply = vm.handleCommand(
                    heard, context,
                    onAndroidAction = { vm.executeAndroidAction(it, context) },
                    onExternalConfirm = { pendingConfirm = it }
                )
            }
        } else {
            permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        ScreenTitle("Voice Conversation", "Push to talk. Nothing is recorded until you tap.")
        Reactor(
            level = fakeLevel,
            active = isListening || isSpeaking,
            reduceMotion = settings.reduceMotion,
            lowPower = settings.lowPower
        )
        Text(
            text = when {
                isListening -> "● LISTENING"
                isSpeaking -> "● SPEAKING"
                else -> "○ IDLE"
            },
            color = if (isListening) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
            style = MaterialTheme.typography.titleMedium
        )
        if (partial.isNotBlank()) {
            Text(text = "\"$partial\"", style = MaterialTheme.typography.bodyLarge)
        }
        if (lastHeard != null) {
            Text(text = "You: ${lastHeard!!}", style = MaterialTheme.typography.bodyMedium)
        }
        if (lastReply != null) {
            Text(text = "NOVA: ${lastReply!!}", style = MaterialTheme.typography.bodyMedium)
        }
        messages.lastOrNull { it.role == "model" }?.let { lastModel ->
            Text(
                text = lastModel.text.take(400),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        if (speechError != null) {
            Text(
                text = speechError!!,
                color = MaterialTheme.colorScheme.error,
                style = MaterialTheme.typography.bodyMedium
            )
        }
        Button(
            onClick = { micTapped() },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(if (isListening) "Stop listening" else "Tap to talk")
        }
        OutlinedButton(
            onClick = { vm.stopSpeaking() },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Stop speaking") }
        OutlinedButton(
            onClick = { navigate(Routes.VOICE_STUDIO) },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Voice personality studio") }
        Text(
            text = "Tip: say \"start a 25-minute focus session\", \"save this idea: …\", or ask anything.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }

    pendingConfirm?.let { confirm ->
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { pendingConfirm = null },
            title = { Text("Confirm action") },
            text = { Text(confirm.description) },
            confirmButton = {
                androidx.compose.material3.TextButton(onClick = {
                    vm.executeAndroidAction(
                        com.nuraid.jarvisnova.domain.CommandRouter.CommandResult.AndroidAction(
                            confirm.description, confirm.intent, confirm.payload
                        ),
                        context
                    )
                    pendingConfirm = null
                }) { Text("Confirm") }
            },
            dismissButton = {
                androidx.compose.material3.TextButton(onClick = { pendingConfirm = null }) { Text("Cancel") }
            }
        )
    }
}

private fun startListening(vm: AppViewModel, onHeard: (String) -> Unit) {
    vm.voice.startListening(onResult = onHeard)
}
