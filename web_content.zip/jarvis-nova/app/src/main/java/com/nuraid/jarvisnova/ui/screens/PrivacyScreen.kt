package com.nuraid.jarvisnova.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.nuraid.jarvisnova.ui.AppViewModel
import com.nuraid.jarvisnova.ui.components.NovaCard
import com.nuraid.jarvisnova.ui.components.ScreenTitle

/**
 * Privacy & security center: what data goes where, and destructive
 * actions that always ask first.
 */
@Composable
fun PrivacyScreen(vm: AppViewModel, navigate: (String) -> Unit) {
    var confirmDeleteHistory by remember { mutableStateOf(false) }
    var confirmWipe by remember { mutableStateOf(false) }
    var doneMessage by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ScreenTitle("Privacy & Security", "Plain language, no dark patterns")
        NovaCard {
            Text("What leaves this device", style = MaterialTheme.typography.titleMedium)
            Text("• Chat messages you send, plus recent turns for context, go to Google's Gemini API using your key — subject to Google's API terms.")
            Text("• Voice input: Android's speech service may process audio on Google servers depending on your device settings. NOVA never records in the background.")
            Text("• Nothing else. No analytics, no ads, no tracking SDKs, no account system.")
        }
        NovaCard {
            Text("What stays on this device", style = MaterialTheme.typography.titleMedium)
            Text("• Conversations, notes, tasks and shortcuts: local database, excluded from Android backup.")
            Text("• Your Gemini key: encrypted with an Android Keystore AES key. It is never logged, never shown, and never included in diagnostics or exports.")
            Text("• Settings: local DataStore preferences.")
        }
        NovaCard {
            Text("Danger zone", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.error)
            OutlinedButton(onClick = { confirmDeleteHistory = true }) {
                Text("Delete all conversations")
            }
            Button(onClick = { confirmWipe = true }) {
                Text("Clear ALL local data (including the API key)")
            }
            if (doneMessage != null) {
                Text(doneMessage!!, color = MaterialTheme.colorScheme.primary)
            }
        }
    }

    if (confirmDeleteHistory) {
        AlertDialog(
            onDismissRequest = { confirmDeleteHistory = false },
            title = { Text("Delete all conversations?") },
            text = { Text("Every chat and its messages will be permanently removed from this device. Notes, tasks and settings stay.") },
            confirmButton = {
                TextButton(onClick = {
                    vm.deleteAllConversations()
                    confirmDeleteHistory = false
                    doneMessage = "All conversations deleted."
                }) { Text("Delete") }
            },
            dismissButton = {
                TextButton(onClick = { confirmDeleteHistory = false }) { Text("Cancel") }
            }
        )
    }
    if (confirmWipe) {
        AlertDialog(
            onDismissRequest = { confirmWipe = false },
            title = { Text("Clear ALL local data?") },
            text = { Text("This deletes conversations, notes, tasks, shortcuts, settings AND your encrypted API key from this device. This cannot be undone.") },
            confirmButton = {
                TextButton(onClick = {
                    vm.wipeAllData()
                    confirmWipe = false
                    doneMessage = "All local data cleared."
                }) { Text("Clear everything") }
            },
            dismissButton = {
                TextButton(onClick = { confirmWipe = false }) { Text("Cancel") }
            }
        )
    }
}
