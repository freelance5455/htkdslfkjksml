package com.nuraid.jarvisnova.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.nuraid.jarvisnova.ui.screens.AboutScreen
import com.nuraid.jarvisnova.ui.screens.AutomationScreen
import com.nuraid.jarvisnova.ui.screens.BootScreen
import com.nuraid.jarvisnova.ui.screens.ChatScreen
import com.nuraid.jarvisnova.ui.screens.CommandCenterScreen
import com.nuraid.jarvisnova.ui.screens.DocumentScreen
import com.nuraid.jarvisnova.ui.screens.FocusTimerScreen
import com.nuraid.jarvisnova.ui.screens.HistoryScreen
import com.nuraid.jarvisnova.ui.screens.MediaScreen
import com.nuraid.jarvisnova.ui.screens.ModelSettingsScreen
import com.nuraid.jarvisnova.ui.screens.MoreScreen
import com.nuraid.jarvisnova.ui.screens.NotesTasksScreen
import com.nuraid.jarvisnova.ui.screens.PermissionsScreen
import com.nuraid.jarvisnova.ui.screens.PrivacyScreen
import com.nuraid.jarvisnova.ui.screens.TemplatesScreen
import com.nuraid.jarvisnova.ui.screens.VisualizerScreen
import com.nuraid.jarvisnova.ui.screens.VoiceScreen
import com.nuraid.jarvisnova.ui.screens.VoiceStudioScreen
import com.nuraid.jarvisnova.ui.screens.WorkspaceScreen
import com.nuraid.jarvisnova.ui.theme.JarvisNovaTheme

/** Every destination in the app, in one place. */
object Routes {
    const val BOOT = "boot"
    const val COMMAND = "command"
    const val VOICE = "voice"
    const val CHAT = "chat"
    const val VISUALIZER = "visualizer"
    const val MEDIA = "media"
    const val WORKSPACE = "workspace"
    const val NOTES_TASKS = "notes_tasks"
    const val FOCUS = "focus"
    const val DOCUMENT = "document"
    const val MODEL_SETTINGS = "model_settings"
    const val VOICE_STUDIO = "voice_studio"
    const val AUTOMATION = "automation"
    const val PERMISSIONS = "permissions"
    const val PRIVACY = "privacy"
    const val HISTORY = "history"
    const val TEMPLATES = "templates"
    const val ABOUT = "about"
    const val MORE = "more"

    /** Routes reachable from the bottom bar. */
    val BOTTOM = listOf(COMMAND, VOICE, CHAT, WORKSPACE, MORE)

    /** Routes that hide the bottom bar (boot only). */
    val NO_CHROME = setOf(BOOT)
}

private data class BottomItem(val route: String, val label: String, val icon: androidx.compose.ui.graphics.vector.ImageVector)

private val BOTTOM_ITEMS = listOf(
    BottomItem(Routes.COMMAND, "Command", Icons.Filled.Home),
    BottomItem(Routes.VOICE, "Voice", Icons.Filled.Mic),
    BottomItem(Routes.CHAT, "Chat", Icons.Filled.Chat),
    BottomItem(Routes.WORKSPACE, "Workspace", Icons.Filled.Dashboard),
    BottomItem(Routes.MORE, "More", Icons.Filled.MoreHoriz)
)

@Composable
fun JarvisNovaRoot(vm: AppViewModel) {
    val settings by vm.settings.collectAsState()
    JarvisNovaTheme(darkTheme = settings.darkTheme, accentName = settings.accentName) {
        val navController = rememberNavController()
        val backStack by navController.currentBackStackEntryAsState()
        val currentRoute = backStack?.destination?.route ?: Routes.BOOT
        val showChrome = currentRoute !in Routes.NO_CHROME

        Scaffold(
            bottomBar = {
                if (showChrome) {
                    NavigationBar {
                        BOTTOM_ITEMS.forEach { item ->
                            NavigationBarItem(
                                selected = currentRoute == item.route,
                                onClick = { navigateTopLevel(navController, item.route) },
                                icon = { Icon(item.icon, contentDescription = item.label) },
                                label = { Text(item.label) }
                            )
                        }
                    }
                }
            }
        ) { padding ->
            JarvisNavHost(
                navController = navController,
                vm = vm,
                modifier = Modifier.padding(padding)
            )
        }
    }
}

private fun navigateTopLevel(navController: NavHostController, route: String) {
    navController.navigate(route) {
        popUpTo(navController.graph.findStartDestination().id) { saveState = true }
        launchSingleTop = true
        restoreState = true
    }
}

@Composable
fun JarvisNavHost(navController: NavHostController, vm: AppViewModel, modifier: Modifier = Modifier) {
    val navigate: (String) -> Unit = { route -> navController.navigate(route) }
    NavHost(
        navController = navController,
        startDestination = Routes.BOOT,
        modifier = modifier
    ) {
        composable(Routes.BOOT) {
            BootScreen(vm = vm, onFinished = {
                navController.navigate(Routes.COMMAND) {
                    popUpTo(Routes.BOOT) { inclusive = true }
                }
            })
        }
        composable(Routes.COMMAND) { CommandCenterScreen(vm, navigate) }
        composable(Routes.VOICE) { VoiceScreen(vm, navigate) }
        composable(Routes.CHAT) { ChatScreen(vm, navigate) }
        composable(Routes.VISUALIZER) { VisualizerScreen(vm, navigate) }
        composable(Routes.MEDIA) { MediaScreen(vm, navigate) }
        composable(Routes.WORKSPACE) { WorkspaceScreen(vm, navigate) }
        composable(Routes.NOTES_TASKS) { NotesTasksScreen(vm, navigate) }
        composable(Routes.FOCUS) { FocusTimerScreen(vm, navigate) }
        composable(Routes.DOCUMENT) { DocumentScreen(vm, navigate) }
        composable(Routes.MODEL_SETTINGS) { ModelSettingsScreen(vm, navigate) }
        composable(Routes.VOICE_STUDIO) { VoiceStudioScreen(vm, navigate) }
        composable(Routes.AUTOMATION) { AutomationScreen(vm, navigate) }
        composable(Routes.PERMISSIONS) { PermissionsScreen(vm, navigate) }
        composable(Routes.PRIVACY) { PrivacyScreen(vm, navigate) }
        composable(Routes.HISTORY) { HistoryScreen(vm, navigate) }
        composable(Routes.TEMPLATES) { TemplatesScreen(vm, navigate) }
        composable(Routes.ABOUT) { AboutScreen(vm, navigate) }
        composable(Routes.MORE) { MoreScreen(vm, navigate) }
    }
}
