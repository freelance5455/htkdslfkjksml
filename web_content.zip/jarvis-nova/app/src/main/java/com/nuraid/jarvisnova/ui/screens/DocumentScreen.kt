package com.nuraid.jarvisnova.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.nuraid.jarvisnova.ui.AppViewModel
import com.nuraid.jarvisnova.ui.components.NovaCard
import com.nuraid.jarvisnova.ui.components.ScreenTitle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Document assistant.
 *
 * Scope, stated plainly: reads PLAIN TEXT files (.txt, .md, and other
 * text-based files) via the system document picker and sends their
 * content to Gemini. PDF support is intentionally limited: Android's
 * PdfRenderer renders page images, it does not extract text, and this
 * app does not bundle a PDF text parser — so .pdf files are not
 * accepted here. Copy text out of the PDF and save as .txt, or paste
 * it into Chat.
 */
@Composable
fun DocumentScreen(vm: AppViewModel, navigate: (String) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var fileName by remember { mutableStateOf<String?>(null) }
    var content by remember { mutableStateOf("") }
    var readError by remember { mutableStateOf<String?>(null) }
    var question by remember { mutableStateOf("Summarize this document: key points, decisions, and action items.") }

    val messages by vm.currentMessages.collectAsState()
    val latestAnswer = messages.lastOrNull { it.role == "model" }?.text

    val picker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            scope.launch {
                val result = withContext(Dispatchers.IO) {
                    try {
                        val name = uri.lastPathSegment ?: "document"
                        val text = context.contentResolver.openInputStream(uri)
                            ?.bufferedReader()?.use { it.readText() }
                        if (text.isNullOrBlank()) {
                            Result.failure<String>(IllegalStateException("That file appears empty or is not plain text. PDFs are not supported here — see the note on this screen."))
                        } else {
                            Result.success(name to text)
                        }
                    } catch (e: Exception) {
                        Result.failure(e)
                    }
                }
                result.onSuccess { (name, text) ->
                    fileName = name
                    content = text.take(MAX_CHARS)
                    readError = null
                }.onFailure { e ->
                    readError = e.message
                }
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ScreenTitle("Document Assistant", "Pick a .txt / .md file. PDFs are not supported — PdfRenderer renders pages, it doesn't extract text.")
        Button(
            onClick = { picker.launch(arrayOf("text/plain", "text/markdown", "text/*")) },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Pick a document") }

        if (readError != null) {
            Text(readError!!, color = MaterialTheme.colorScheme.error)
        }
        if (fileName != null) {
            NovaCard {
                Text(fileName!!, style = MaterialTheme.typography.titleMedium)
                Text(
                    text = content.take(600) + if (content.length > 600) "…" else "",
                    style = MaterialTheme.typography.bodySmall
                )
                Text("${content.length} characters loaded (max $MAX_CHARS sent).")
            }
            androidx.compose.material3.OutlinedTextField(
                value = question,
                onValueChange = { question = it },
                label = { Text("What should NOVA do with it?") },
                modifier = Modifier.fillMaxWidth(),
                maxLines = 3
            )
            RowButtons(
                onSummarize = {
                    vm.sendChat("$question\n\n--- DOCUMENT ---\n$content")
                },
                onReadAloud = {
                    if (latestAnswer != null) vm.speakAlways(latestAnswer)
                },
                hasAnswer = latestAnswer != null
            )
        }
        if (latestAnswer != null) {
            NovaCard {
                Text("Latest answer", style = MaterialTheme.typography.titleMedium)
                Text(latestAnswer)
            }
        }
    }
}

@Composable
private fun RowButtons(onSummarize: () -> Unit, onReadAloud: () -> Unit, hasAnswer: Boolean) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(onClick = onSummarize, modifier = Modifier.fillMaxWidth()) { Text("Send to Gemini") }
        OutlinedButton(onClick = onReadAloud, enabled = hasAnswer, modifier = Modifier.fillMaxWidth()) {
            Text("Read latest answer aloud")
        }
    }
}

private const val MAX_CHARS = 12000
