package com.nuraid.jarvisnova.util

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Build
import com.nuraid.jarvisnova.BuildConfig
import com.nuraid.jarvisnova.data.NovaSettings

/**
 * Builds a human-readable diagnostics report using only public APIs.
 *
 * SECURITY: this report NEVER includes the API key, conversation
 * contents, notes, or any user text — only device/app status.
 */
object Diagnostics {

    fun batteryPercent(context: Context): Int {
        val intent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = intent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = intent?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        return if (level >= 0 && scale > 0) (level * 100) / scale else -1
    }

    fun isCharging(context: Context): Boolean {
        val intent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val status = intent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        return status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
    }

    fun networkDescription(context: Context): String {
        val cm = context.getSystemService(ConnectivityManager::class.java)
        val network = cm.activeNetwork ?: return "Offline (no active network)"
        val caps = cm.getNetworkCapabilities(network) ?: return "Unknown"
        val transport = when {
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Cellular"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
            else -> "Other"
        }
        val validated = if (caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)) "validated" else "not validated"
        return "$transport ($validated)"
    }

    fun buildReport(context: Context, settings: NovaSettings, geminiKeyConfigured: Boolean, ttsReady: Boolean): String {
        val battery = batteryPercent(context)
        return buildString {
            appendLine("J.A.R.V.I.S. NOVA — Diagnostics")
            appendLine("App version: ${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE})")
            appendLine("Device: ${Build.MANUFACTURER} ${Build.MODEL}")
            appendLine("Android: ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
            appendLine("Battery: ${if (battery >= 0) "$battery%" else "unknown"}${if (isCharging(context)) " (charging)" else ""}")
            appendLine("Network: ${networkDescription(context)}")
            appendLine("Gemini model: ${settings.geminiModel}")
            appendLine("Gemini key configured: $geminiKeyConfigured (value never shown)")
            appendLine("Streaming: ${settings.streamingEnabled}")
            appendLine("Text-to-speech ready: $ttsReady")
            appendLine("Auto-speak: ${settings.autoSpeak}")
            appendLine("Reduce motion: ${settings.reduceMotion} · Low power: ${settings.lowPower}")
            appendLine("Memory enabled: ${settings.memoryEnabled}")
        }
    }
}
