package com.nuraid.jarvisnova.data

import android.content.Context
import com.nuraid.jarvisnova.data.db.Conversation
import com.nuraid.jarvisnova.data.db.ConversationDao
import com.nuraid.jarvisnova.data.db.Message
import com.nuraid.jarvisnova.data.db.MessageDao
import com.nuraid.jarvisnova.data.db.Note
import com.nuraid.jarvisnova.data.db.NoteDao
import com.nuraid.jarvisnova.data.db.Shortcut
import com.nuraid.jarvisnova.data.db.ShortcutDao
import com.nuraid.jarvisnova.data.db.TaskDao
import com.nuraid.jarvisnova.data.db.TaskItem
import kotlinx.coroutines.flow.Flow

/**
 * Single access point for local data: Room tables + preferences + the
 * encrypted API key. UI and ViewModels never touch DAOs directly.
 */
class Repository(
    context: Context,
    private val conversationDao: ConversationDao,
    private val messageDao: MessageDao,
    private val noteDao: NoteDao,
    private val taskDao: TaskDao,
    private val shortcutDao: ShortcutDao
) {
    val preferences = PreferencesManager(context.applicationContext)
    val keyStore = KeyStoreManager(context.applicationContext)
    val gemini = GeminiClient()

    // --- Conversations -------------------------------------------------
    val activeConversations: Flow<List<Conversation>> = conversationDao.observeActive()
    val archivedConversations: Flow<List<Conversation>> = conversationDao.observeArchived()
    fun searchConversations(query: String): Flow<List<Conversation>> = conversationDao.search(query)

    suspend fun createConversation(title: String, systemPrompt: String = "", templateId: String? = null): Long =
        conversationDao.insert(
            Conversation(title = title, systemPrompt = systemPrompt, templateId = templateId)
        )

    suspend fun getConversation(id: Long): Conversation? = conversationDao.getById(id)

    suspend fun renameConversation(conversation: Conversation, newTitle: String) =
        conversationDao.update(conversation.copy(title = newTitle, updatedAt = System.currentTimeMillis()))

    suspend fun setArchived(conversation: Conversation, archived: Boolean) =
        conversationDao.update(conversation.copy(archived = archived, updatedAt = System.currentTimeMillis()))

    suspend fun setFavorite(conversation: Conversation, favorite: Boolean) =
        conversationDao.update(conversation.copy(favorite = favorite))

    suspend fun deleteConversation(conversation: Conversation) {
        messageDao.deleteForConversation(conversation.id)
        conversationDao.delete(conversation)
    }

    // --- Messages --------------------------------------------------------
    fun messagesFor(conversationId: Long): Flow<List<Message>> =
        messageDao.observeForConversation(conversationId)

    suspend fun historyFor(conversationId: Long): List<Message> =
        messageDao.getForConversation(conversationId)

    suspend fun addMessage(conversationId: Long, role: String, text: String): Long {
        val id = messageDao.insert(Message(conversationId = conversationId, role = role, text = text))
        conversationDao.getById(conversationId)?.let {
            conversationDao.update(it.copy(updatedAt = System.currentTimeMillis()))
        }
        return id
    }

    /** Plain-text export of one conversation, for share/save. */
    suspend fun exportConversation(conversation: Conversation): String {
        val messages = messageDao.getForConversation(conversation.id)
        val sb = StringBuilder()
        sb.appendLine("# ${conversation.title}")
        sb.appendLine()
        for (m in messages) {
            val who = when (m.role) {
                "user" -> "You"
                "model" -> "J.A.R.V.I.S. NOVA"
                else -> "System"
            }
            sb.appendLine("**$who:** ${m.text}")
            sb.appendLine()
        }
        return sb.toString()
    }

    // --- Notes -----------------------------------------------------------
    val notes: Flow<List<Note>> = noteDao.observeAll()
    suspend fun addNote(text: String): Long = noteDao.insert(Note(text = text))
    suspend fun updateNote(note: Note) = noteDao.update(note)
    suspend fun deleteNote(note: Note) = noteDao.delete(note)

    // --- Tasks -----------------------------------------------------------
    val tasks: Flow<List<TaskItem>> = taskDao.observeAll()
    suspend fun pendingTasks(limit: Int = 10): List<TaskItem> = taskDao.getPending(limit)
    suspend fun addTask(title: String, remindAt: Long? = null): Long =
        taskDao.insert(TaskItem(title = title, remindAt = remindAt))
    suspend fun updateTask(task: TaskItem) = taskDao.update(task)
    suspend fun deleteTask(task: TaskItem) = taskDao.delete(task)

    // --- Shortcuts ---------------------------------------------------------
    val shortcuts: Flow<List<Shortcut>> = shortcutDao.observeAll()
    suspend fun addShortcut(name: String, prompt: String, url: String? = null): Long =
        shortcutDao.insert(Shortcut(name = name, prompt = prompt, url = url))
    suspend fun updateShortcut(shortcut: Shortcut) = shortcutDao.update(shortcut)
    suspend fun deleteShortcut(shortcut: Shortcut) = shortcutDao.delete(shortcut)

    // --- Media favorites (stored as shortcuts with url set) ----------------
    // Media screen reuses the shortcuts table: name = title, prompt = "",
    // url = video/page URL. No extra table needed.

    // --- Wipe --------------------------------------------------------------
    /** Deletes ALL local user data. Caller must confirm with the user first. */
    suspend fun wipeAllData() {
        messageDao.deleteAll()
        conversationDao.deleteAll()
        noteDao.deleteAll()
        taskDao.deleteAll()
        shortcutDao.deleteAll()
        preferences.clearAll()
        keyStore.clearApiKey()
    }

    suspend fun deleteAllConversations() {
        messageDao.deleteAll()
        conversationDao.deleteAll()
    }
}
