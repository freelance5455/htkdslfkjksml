package com.nuraid.jarvisnova.work

import android.content.Context
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.CoroutineWorker
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import com.nuraid.jarvisnova.JarvisNovaApp
import java.util.concurrent.TimeUnit

/**
 * Fires a task reminder notification. Scheduled from the Notes & Tasks
 * screen when a task is given a reminder time; unique work per task id
 * so editing a task replaces (never duplicates) its reminder.
 */
class ReminderWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        val title = inputData.getString(KEY_TITLE) ?: return Result.failure()
        val notification = NotificationCompat.Builder(applicationContext, JarvisNovaApp.CHANNEL_REMINDERS)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Reminder")
            .setContentText(title)
            .setStyle(NotificationCompat.BigTextStyle().bigText(title))
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .build()
        return try {
            NotificationManagerCompat.from(applicationContext)
                .notify(title.hashCode(), notification)
            Result.success()
        } catch (e: SecurityException) {
            // Notification permission revoked after scheduling — nothing
            // sensible to retry; report success so WorkManager drops it.
            Result.success()
        }
    }

    companion object {
        private const val KEY_TITLE = "task_title"

        fun schedule(context: Context, taskId: Long, title: String, remindAtMillis: Long) {
            val delay = (remindAtMillis - System.currentTimeMillis()).coerceAtLeast(0)
            val request = OneTimeWorkRequestBuilder<ReminderWorker>()
                .setInitialDelay(delay, TimeUnit.MILLISECONDS)
                .setInputData(workDataOf(KEY_TITLE to title))
                .build()
            WorkManager.getInstance(context).enqueueUniqueWork(
                "task_reminder_$taskId",
                ExistingWorkPolicy.REPLACE,
                request
            )
        }

        fun cancel(context: Context, taskId: Long) {
            WorkManager.getInstance(context).cancelUniqueWork("task_reminder_$taskId")
        }
    }
}
