package com.nuraid.jarvisnova.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

/** Typed Gemini failures so the UI can show an honest, specific message. */
sealed class GeminiException(message: String) : Exception(message) {
    class NoKey : GeminiException("No Gemini API key configured. Add one in AI Model Settings.")
    class InvalidKey(detail: String) : GeminiException("The API key was rejected ($detail). Check it in AI Model Settings.")
    class RateLimit : GeminiException("Gemini rate limit / quota reached (HTTP 429). Wait a moment and retry.")
    class UnsupportedModel(model: String) : GeminiException("Model '$model' was not found (HTTP 404). Pick a different model in AI Model Settings.")
    class Network(detail: String) : GeminiException("Network error: $detail")
    class Server(code: Int, detail: String) : GeminiException("Gemini server error (HTTP $code): $detail")
    class EmptyResponse : GeminiException("Gemini returned an empty response. Try rephrasing.")
}

/** One turn of chat history sent to Gemini. Role is "user" or "model". */
data class GeminiTurn(val role: String, val text: String)

/** Optional image attachment (JPEG/PNG bytes + MIME type). */
data class GeminiImage(val mimeType: String, val base64Data: String)

/**
 * Minimal, dependency-light client for the official Gemini REST API:
 *
 *   POST https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent
 *   POST https://generativelanguage.googleapis.com/v1beta/models/{model}:streamGenerateContent?alt=sse
 *
 * Auth uses the `x-goog-api-key` header. The key is passed in by the
 * caller for each request and is never stored, logged, or printed here.
 *
 * Docs: https://ai.google.dev/api/generate-content
 */
class GeminiClient(
    private val http: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()
) {

    /** Non-streaming generation. Throws a [GeminiException] subtype on failure. */
    suspend fun generate(
        apiKey: String,
        model: String,
        systemPrompt: String,
        history: List<GeminiTurn>,
        temperature: Float = 0.7f,
        maxOutputTokens: Int = 1024,
        image: GeminiImage? = null
    ): String = withContext(Dispatchers.IO) {
        val body = buildRequestBody(systemPrompt, history, temperature, maxOutputTokens, image)
        val request = buildRequest(apiKey, model, streaming = false, body)
        http.newCall(request).execute().use { response ->
            val text = response.body?.string().orEmpty()
            if (!response.isSuccessful) throw mapError(response.code, model, text)
            extractText(JSONObject(text)) ?: throw GeminiException.EmptyResponse()
        }
    }

    /**
     * Streaming generation. Emits cumulative text as chunks arrive.
     * Cancelling the collecting coroutine cancels the OkHttp call.
     */
    fun generateStreaming(
        apiKey: String,
        model: String,
        systemPrompt: String,
        history: List<GeminiTurn>,
        temperature: Float = 0.7f,
        maxOutputTokens: Int = 1024,
        image: GeminiImage? = null
    ): Flow<String> = flow {
        if (apiKey.isBlank()) throw GeminiException.NoKey()
        val body = buildRequestBody(systemPrompt, history, temperature, maxOutputTokens, image)
        val request = buildRequest(apiKey, model, streaming = true, body)
        val call = http.newCall(request)
        try {
            val response = call.execute()
            response.use {
                if (!it.isSuccessful) {
                    throw mapError(it.code, model, it.body?.string().orEmpty())
                }
                val source = it.body?.source() ?: throw GeminiException.EmptyResponse()
                val full = StringBuilder()
                var emittedAny = false
                while (!source.exhausted()) {
                    if (!currentCoroutineContext().isActive) {
                        call.cancel()
                        break
                    }
                    val line = source.readUtf8Line() ?: break
                    if (!line.startsWith("data:")) continue
                    val payload = line.removePrefix("data:").trim()
                    if (payload.isEmpty() || payload == "[DONE]") continue
                    val chunk = try {
                        extractText(JSONObject(payload))
                    } catch (e: Exception) {
                        null // partial JSON line — skip, next chunk carries more
                    }
                    if (!chunk.isNullOrEmpty()) {
                        full.append(chunk)
                        emittedAny = true
                        emit(full.toString())
                    }
                }
                if (!emittedAny && full.isEmpty()) throw GeminiException.EmptyResponse()
            }
        } catch (e: IOException) {
            if (call.isCanceled()) throw kotlinx.coroutines.CancellationException("Request cancelled")
            throw GeminiException.Network(e.message ?: "connection failed")
        }
    }.flowOn(Dispatchers.IO)

    /** Small ping used by the "Test connection" button in Model Settings. */
    suspend fun testConnection(apiKey: String, model: String): String =
        generate(
            apiKey = apiKey,
            model = model,
            systemPrompt = "",
            history = listOf(GeminiTurn("user", "Reply with exactly: ONLINE")),
            temperature = 0.0f,
            maxOutputTokens = 16
        )

    // -------------------------------------------------------------------

    private fun buildRequest(apiKey: String, model: String, streaming: Boolean, body: JSONObject): Request {
        if (apiKey.isBlank()) throw GeminiException.NoKey()
        val url = if (streaming) {
            "$BASE_URL/$model:streamGenerateContent?alt=sse"
        } else {
            "$BASE_URL/$model:generateContent"
        }
        return Request.Builder()
            .url(url)
            .header("x-goog-api-key", apiKey)
            .header("Content-Type", "application/json")
            .post(body.toString().toRequestBody(JSON_MEDIA_TYPE))
            .build()
    }

    private fun buildRequestBody(
        systemPrompt: String,
        history: List<GeminiTurn>,
        temperature: Float,
        maxOutputTokens: Int,
        image: GeminiImage?
    ): JSONObject {
        val contents = JSONArray()
        history.forEachIndexed { index, turn ->
            val parts = JSONArray()
            parts.put(JSONObject().put("text", turn.text))
            // Attach the image to the most recent user turn only.
            if (image != null && index == history.lastIndex && turn.role == "user") {
                parts.put(
                    JSONObject()
                        .put("inline_data", JSONObject()
                            .put("mime_type", image.mimeType)
                            .put("data", image.base64Data))
                )
            }
            contents.put(
                JSONObject()
                    .put("role", turn.role)
                    .put("parts", parts)
            )
        }

        val generationConfig = JSONObject()
            .put("temperature", temperature.toDouble())
            .put("maxOutputTokens", maxOutputTokens)

        val root = JSONObject()
            .put("contents", contents)
            .put("generationConfig", generationConfig)
        if (systemPrompt.isNotBlank()) {
            root.put(
                "systemInstruction",
                JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemPrompt)))
            )
        }
        return root
    }

    /** Pulls candidates[0].content.parts[*].text out of a response/chunk. */
    private fun extractText(json: JSONObject): String? {
        val candidates = json.optJSONArray("candidates") ?: return null
        if (candidates.length() == 0) return null
        val content = candidates.optJSONObject(0)?.optJSONObject("content") ?: return null
        val parts = content.optJSONArray("parts") ?: return null
        val sb = StringBuilder()
        for (i in 0 until parts.length()) {
            parts.optJSONObject(i)?.optString("text")?.let { sb.append(it) }
        }
        return sb.toString().ifEmpty { null }
    }

    private fun mapError(code: Int, model: String, body: String): GeminiException {
        val detail = try {
            JSONObject(body).optJSONObject("error")?.optString("message")?.take(160) ?: "HTTP $code"
        } catch (e: Exception) {
            "HTTP $code"
        }
        return when (code) {
            400, 401, 403 -> GeminiException.InvalidKey(detail)
            404 -> GeminiException.UnsupportedModel(model)
            429 -> GeminiException.RateLimit()
            else -> GeminiException.Server(code, detail)
        }
    }

    companion object {
        private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models"
        private val JSON_MEDIA_TYPE = "application/json; charset=utf-8".toMediaType()
    }
}
