package com.nuraid.jarvisnova

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import com.nuraid.jarvisnova.data.Repository
import com.nuraid.jarvisnova.data.db.JarvisDatabase

/**
 * Application entry point. Holds the single [Repository] instance
 * (simple manual DI — no framework needed at this scale) and creates
 * the two notification channels the app uses.
 */
class JarvisNovaApp : Application() {

    lateinit var repository: Repository
        private set

    override fun onCreate() {
        super.onCreate()
        val db = JarvisDatabase.getInstance(this)
        repository = Repository(
            context = this,
            conversationDao = db.conversationDao(),
            messageDao = db.messageDao(),
            noteDao = db.noteDao(),
            taskDao = db.taskDao(),
            shortcutDao = db.shortcutDao()
        )
        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(
            NotificationChannel(
                CHANNEL_FOCUS,
                getString(R.string.notification_channel_focus),
                NotificationManager.IMPORTANCE_DEFAULT
            )
        )
        manager.createNotificationChannel(
            NotificationChannel(
                CHANNEL_REMINDERS,
                getString(R.string.notification_channel_reminders),
                NotificationManager.IMPORTANCE_DEFAULT
            )
        )
    }

    companion object {
        const val CHANNEL_FOCUS = "focus_sessions"
        const val CHANNEL_REMINDERS = "task_reminders"
    }
}
