package com.nuraid.jarvisnova.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.nuraid.jarvisnova.ui.AppViewModel
import com.nuraid.jarvisnova.ui.components.NovaCard
import com.nuraid.jarvisnova.ui.components.ScreenTitle
import com.nuraid.jarvisnova.ui.components.SettingRow

/**
 * Voice personality studio.
 *
 * Android TTS voices differ per device, so the voice list shown here
 * is read live from the device's TTS engine — nothing is faked.
 * Persona presets set pitch/rate pairings; everything is adjustable.
 */
@Composable
fun VoiceStudioScreen(vm: AppViewModel, navigate: (String) -> Unit) {
    val settings by vm.settings.collectAsState()
    val voices by vm.voice.availableVoices.collectAsState()
    val ttsReady by vm.voice.ttsReady.collectAsState()
    val isSpeaking by vm.voice.isSpeaking.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ScreenTitle("Voice Personality Studio", if (ttsReady) "Speech engine ready" else "Speech engine starting…")
        NovaCard {
            SettingRow("Speak responses aloud", "Off = text only, always") {
                Switch(
                    checked = settings.autoSpeak,
                    onCheckedChange = { enabled -> vm.updateSettings { s -> s.copy(autoSpeak = enabled) } }
                )
            }
            RowButtons(
                onPreview = {
                    vm.speakAlways("At your service. All systems are functioning within normal parameters.")
                },
                onStop = { vm.stopSpeaking() },
                speaking = isSpeaking
            )
            Text(
                text = "Personality presets",
                style = MaterialTheme.typography.titleMedium
            )
            PersonaPreset("Cinema JARVIS — calm, low, measured") {
                vm.updateSettings { it.copy(ttsPitch = 0.85f, ttsRate = 0.92f) }
            }
            PersonaPreset("Professional — neutral and clear") {
                vm.updateSettings { it.copy(ttsPitch = 1.0f, ttsRate = 1.0f) }
            }
            PersonaPreset("Brisk — fast briefings") {
                vm.updateSettings { it.copy(ttsPitch = 1.05f, ttsRate = 1.2f) }
            }
        }
        NovaCard {
            Text("Pitch: ${"%.2f".format(settings.ttsPitch)}")
            Slider(
                value = settings.ttsPitch,
                onValueChange = { vm.updateSettings { s -> s.copy(ttsPitch = it) } },
                valueRange = 0.5f..2.0f
            )
            Text("Speed: ${"%.2f".format(settings.ttsRate)}")
            Slider(
                value = settings.ttsRate,
                onValueChange = { vm.updateSettings { s -> s.copy(ttsRate = it) } },
                valueRange = 0.5f..2.0f
            )
            Text("Volume: ${"%.0f".format(settings.ttsVolume * 100)}%")
            Slider(
                value = settings.ttsVolume,
                onValueChange = { vm.updateSettings { s -> s.copy(ttsVolume = it) } },
                valueRange = 0f..1f
            )
        }
        NovaCard {
            Text("Device voices (${voices.size})", style = MaterialTheme.typography.titleMedium)
            if (voices.isEmpty()) {
                Text(
                    "No voices reported by the TTS engine yet. If this stays empty, install a voice pack in Android Settings → Accessibility → Text-to-speech.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
            voices.take(24).forEach { voice ->
                val selected = settings.ttsVoiceName == voice.name
                Text(
                    text = (if (selected) "● " else "○ ") + voice.name + " — " + voice.locale.displayName,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { vm.updateSettings { it.copy(ttsVoiceName = voice.name) } }
                        .padding(vertical = 6.dp)
                )
            }
            if (voices.size > 24) {
                Text("…and ${voices.size - 24} more. The list is capped for readability.", style = MaterialTheme.typography.bodySmall)
            }
        }
        Text(
            text = "Note: this is your device's TTS engine, tuned — not a cloned JARVIS voice actor. Gemini audio-output models vary by model and account, so NOVA does not pretend its TTS is Gemini-generated audio.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun PersonaPreset(label: String, onClick: () -> Unit) {
    Text(
        text = label,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(vertical = 6.dp)
    )
}

@Composable
private fun RowButtons(onPreview: () -> Unit, onStop: () -> Unit, speaking: Boolean) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Button(onClick = onPreview, modifier = Modifier.fillMaxWidth()) { Text("Preview voice") }
        OutlinedButton(onClick = onStop, enabled = speaking, modifier = Modifier.fillMaxWidth()) {
            Text("Interrupt speech")
        }
    }
}
