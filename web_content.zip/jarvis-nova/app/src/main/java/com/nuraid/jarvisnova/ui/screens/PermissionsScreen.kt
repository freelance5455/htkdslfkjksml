package com.nuraid.jarvisnova.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.nuraid.jarvisnova.ui.AppViewModel
import com.nuraid.jarvisnova.ui.components.NovaCard
import com.nuraid.jarvisnova.ui.components.ScreenTitle
import com.nuraid.jarvisnova.util.Intents

private data class PermissionInfo(
    val permission: String?,
    val title: String,
    val why: String
)

/**
 * Permissions dashboard: live states, honest rationales, and request
 * buttons. This app requests only four permissions, all explainable.
 */
@Composable
fun PermissionsScreen(vm: AppViewModel, navigate: (String) -> Unit) {
    val context = LocalContext.current
    // Bump to re-read permission states after a request returns.
    var refreshTick by remember { mutableStateOf(0) }

    val launcher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { refreshTick++ }

    val infos = buildList {
        add(
            PermissionInfo(
                Manifest.permission.RECORD_AUDIO,
                "Microphone",
                "Only for push-to-talk voice input, while the listening indicator is on screen. Never in the background."
            )
        )
        if (Build.VERSION.SDK_INT >= 33) {
            add(
                PermissionInfo(
                    Manifest.permission.POST_NOTIFICATIONS,
                    "Notifications",
                    "Focus-session completion and task reminders you schedule yourself."
                )
            )
        }
        add(
            PermissionInfo(
                null,
                "Internet",
                "Normal (install-time) permission. Used only to call the Gemini API with your key."
            )
        )
        add(
            PermissionInfo(
                null,
                "Vibrate",
                "Normal (install-time) permission. Small haptic confirmation on key actions."
            )
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ScreenTitle("Permissions Dashboard", "Four permissions total. No contacts, no location, no camera, no file access beyond the picker you open.")
        // refreshTick read here so states recompute after requests.
        Text("Status refresh: $refreshTick", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        infos.forEach { info ->
            NovaCard {
                Text(info.title, style = MaterialTheme.typography.titleMedium)
                Text(info.why, style = MaterialTheme.typography.bodyMedium)
                if (info.permission == null) {
                    Text("Granted at install (normal permission)", color = MaterialTheme.colorScheme.primary)
                } else {
                    val granted = ContextCompat.checkSelfPermission(
                        context, info.permission
                    ) == PackageManager.PERMISSION_GRANTED
                    Text(
                        text = if (granted) "Granted" else "Not granted",
                        color = if (granted) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                    )
                    if (!granted) {
                        Button(onClick = { launcher.launch(info.permission) }) { Text("Request permission") }
                    }
                }
            }
        }
        OutlinedButton(onClick = { Intents.openAppSettings(context) }) {
            Text("Open Android app settings")
        }
        Text(
            text = "Denying a permission only disables its feature — the rest of NOVA keeps working, and voice features always degrade to typing.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
