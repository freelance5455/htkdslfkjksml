package com.nuraid.jarvisnova.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.nuraid.jarvisnova.ui.AppViewModel
import com.nuraid.jarvisnova.ui.Routes
import com.nuraid.jarvisnova.ui.components.NovaCard
import com.nuraid.jarvisnova.ui.components.ScreenTitle

private data class HubEntry(val title: String, val description: String, val route: String)

/**
 * Personal workspace hub: floating-panel style index of the working
 * screens (notes, tasks, documents, templates, automations) plus a
 * status strip. Layout choices persist via the settings DataStore
 * (theme / accent below).
 */
@Composable
fun WorkspaceScreen(vm: AppViewModel, navigate: (String) -> Unit) {
    val settings by vm.settings.collectAsState()
    val notes by vm.notes.collectAsState()
    val tasks by vm.tasks.collectAsState()
    val conversations by vm.conversations.collectAsState()

    val entries = listOf(
        HubEntry("Notes & Tasks", "${notes.size} notes · ${tasks.count { !it.done }} open tasks", Routes.NOTES_TASKS),
        HubEntry("Document Assistant", "Summarize a .txt / .md file with Gemini", Routes.DOCUMENT),
        HubEntry("Template Library", "15 ready-made workspaces", Routes.TEMPLATES),
        HubEntry("Automation & Shortcuts", "Reusable prompts and quick actions", Routes.AUTOMATION),
        HubEntry("Conversation History", "${conversations.size} active conversations", Routes.HISTORY),
        HubEntry("Holographic Visualizer", "Full-screen reactor view", Routes.VISUALIZER),
        HubEntry("Media Launcher", "YouTube & web search, favorites", Routes.MEDIA)
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            ScreenTitle("Workspace", "Your panels, ${settings.displayName}. Everything here is stored on-device.")
        }
        items(entries) { entry ->
            NovaCard(modifier = Modifier.clickable { navigate(entry.route) }) {
                Text(entry.title, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
                Text(entry.description, style = MaterialTheme.typography.bodyMedium)
            }
        }
        item {
            NovaCard {
                Text("Appearance", style = MaterialTheme.typography.titleMedium)
                Text(
                    text = "Theme: ${if (settings.darkTheme) "Dark holographic" else "Light"} · Accent: ${settings.accentName}",
                    style = MaterialTheme.typography.bodyMedium
                )
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    com.nuraid.jarvisnova.ui.theme.NovaColors.ACCENTS.forEach { accent ->
                        Text(
                            text = if (accent == settings.accentName) "● $accent" else "○ $accent",
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { vm.updateSettings { it.copy(accentName = accent) } }
                                .padding(vertical = 6.dp)
                        )
                    }
                }
                Text(
                    text = if (settings.darkTheme) "Switch to light theme" else "Switch to dark theme",
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier
                        .clickable { vm.updateSettings { it.copy(darkTheme = !settings.darkTheme) } }
                        .padding(vertical = 6.dp)
                )
            }
        }
    }
}
