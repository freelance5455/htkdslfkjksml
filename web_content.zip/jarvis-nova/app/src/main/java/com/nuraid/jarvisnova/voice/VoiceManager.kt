package com.nuraid.jarvisnova.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

/**
 * Native voice engine.
 *
 * TTS: [TextToSpeech] with a single queue — every [speak] call uses
 * QUEUE_FLUSH, so a new response can never overlap the previous one, and
 * [stopSpeaking] interrupts immediately. Speech only happens when the
 * caller's `enabled` flag (auto-speak setting) is true.
 *
 * STT: [SpeechRecognizer], push-to-talk ONLY. There is no background
 * listening and no wake word in this app: recognition starts on an
 * explicit user action, [isListening] drives a visible indicator in the
 * UI, and recognition stops on result, error, or [stopListening].
 */
class VoiceManager(context: Context) : TextToSpeech.OnInitListener {

    private val appContext = context.applicationContext

    // --- TTS -------------------------------------------------------------
    private var tts: TextToSpeech? = null

    private val _ttsReady = MutableStateFlow(false)
    val ttsReady: StateFlow<Boolean> = _ttsReady.asStateFlow()

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    private val _availableVoices = MutableStateFlow<List<Voice>>(emptyList())
    val availableVoices: StateFlow<List<Voice>> = _availableVoices.asStateFlow()

    private var utteranceCounter = 0

    init {
        tts = TextToSpeech(appContext, this)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale.UK
            _availableVoices.value = try {
                tts?.voices?.sortedBy { it.name } ?: emptyList()
            } catch (e: Exception) {
                emptyList()
            }
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) { _isSpeaking.value = true }
                override fun onDone(utteranceId: String?) { _isSpeaking.value = false }
                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) { _isSpeaking.value = false }
            })
            _ttsReady.value = true
        }
    }

    /** Apply voice settings. Call whenever settings change. */
    fun applySettings(voiceName: String, pitch: Float, rate: Float) {
        val engine = tts ?: return
        if (voiceName.isNotBlank()) {
            _availableVoices.value.firstOrNull { it.name == voiceName }?.let { engine.voice = it }
        }
        engine.setPitch(pitch.coerceIn(0.5f, 2.0f))
        engine.setSpeechRate(rate.coerceIn(0.5f, 2.0f))
    }

    /**
     * Speak [text]. Returns false (and speaks nothing) when [enabled] is
     * false or TTS isn't ready — the caller then just shows the text.
     * [volume] is a 0..1 multiplier sent via utterance params.
     */
    fun speak(text: String, enabled: Boolean, volume: Float = 1.0f): Boolean {
        if (!enabled) return false
        val engine = tts ?: return false
        if (!_ttsReady.value) return false
        val clean = text
            .replace(Regex("[#>*_`]"), "")       // strip markdown noise
            .replace(Regex("\\s+"), " ")
            .trim()
        if (clean.isBlank()) return false
        val params = Bundle().apply {
            putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, volume.coerceIn(0f, 1f))
        }
        val result = engine.speak(
            clean.take(MAX_UTTERANCE_CHARS),
            TextToSpeech.QUEUE_FLUSH, // supersedes anything already speaking
            params,
            "nova_${utteranceCounter++}"
        )
        return result == TextToSpeech.SUCCESS
    }

    fun stopSpeaking() {
        tts?.stop()
        _isSpeaking.value = false
    }

    // --- STT ---------------------------------------------------------------
    private var recognizer: SpeechRecognizer? = null

    private val _isListening = MutableStateFlow(false)
    val isListening: StateFlow<Boolean> = _isListening.asStateFlow()

    private val _partialResult = MutableStateFlow("")
    val partialResult: StateFlow<String> = _partialResult.asStateFlow()

    private val _speechError = MutableStateFlow<String?>(null)
    val speechError: StateFlow<String?> = _speechError.asStateFlow()

    /**
     * Start one push-to-talk recognition session.
     * The caller MUST hold RECORD_AUDIO permission first (see
     * Permissions screen / Voice screen request flow).
     * [onResult] fires once with the final transcript.
     */
    fun startListening(onResult: (String) -> Unit) {
        if (!SpeechRecognizer.isRecognitionAvailable(appContext)) {
            _speechError.value = "Speech recognition is not available on this device. Type instead."
            return
        }
        stopListening()
        _speechError.value = null
        _partialResult.value = ""

        val sr = SpeechRecognizer.createSpeechRecognizer(appContext)
        recognizer = sr
        sr.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { _isListening.value = true }
            override fun onBeginningOfSpeech() { _isListening.value = true }
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { _isListening.value = false }
            override fun onPartialResults(partialResults: Bundle?) {
                val text = partialResults
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                if (text != null) _partialResult.value = text
            }
            override fun onResults(results: Bundle?) {
                _isListening.value = false
                val text = results
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                if (!text.isNullOrBlank()) onResult(text) else {
                    _speechError.value = "I didn't catch that. Try again or type."
                }
            }
            override fun onError(error: Int) {
                _isListening.value = false
                _speechError.value = mapSpeechError(error)
            }
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        try {
            sr.startListening(intent)
            _isListening.value = true
        } catch (e: Exception) {
            _isListening.value = false
            _speechError.value = "Microphone could not be started: ${e.message}"
        }
    }

    fun stopListening() {
        try {
            recognizer?.stopListening()
            recognizer?.destroy()
        } catch (e: Exception) {
            // Already released — nothing to do.
        }
        recognizer = null
        _isListening.value = false
    }

    private fun mapSpeechError(error: Int): String = when (error) {
        SpeechRecognizer.ERROR_AUDIO -> "Audio recording error. Check the microphone and try again."
        SpeechRecognizer.ERROR_CLIENT -> "Speech client error. Try again."
        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission is required for voice input. Grant it in Permissions."
        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Speech service network error. Check your connection or type instead."
        SpeechRecognizer.ERROR_NO_MATCH -> "I didn't catch that. Try again or type."
        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "The recognizer is busy. Wait a moment and try again."
        SpeechRecognizer.ERROR_SERVER -> "Speech service error. Type instead or try later."
        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "No speech heard. The mic has been released."
        else -> "Speech error ($error). Type instead if this keeps happening."
    }

    fun release() {
        stopListening()
        tts?.stop()
        tts?.shutdown()
        tts = null
    }

    companion object {
        private const val MAX_UTTERANCE_CHARS = 1500
    }
}
