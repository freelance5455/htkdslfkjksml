package com.nuraid.jarvisnova.ui.screens

import android.annotation.SuppressLint
import android.view.ViewGroup
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.NoteAlt
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.nuraid.jarvisnova.ui.AppViewModel
import com.nuraid.jarvisnova.ui.Routes
import com.nuraid.jarvisnova.web.JarvisBridge

/**
 * Main command center.
 *
 * Top: native quick bar (typed command box routed through
 * [CommandRouter] via the ViewModel + one-tap destinations).
 * Below: the ORIGINAL, unmodified HTML HUD in a WebView, with the
 * native bridge exposed as `window.AndroidNova` and the
 * nova_bridge.js shim injected after page load.
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun CommandCenterScreen(vm: AppViewModel, navigate: (String) -> Unit) {
    val context = LocalContext.current
    val status by vm.statusMessage.collectAsState()
    var command by remember { mutableStateOf("") }
    var lastReply by remember { mutableStateOf<String?>(null) }
    var pendingConfirm by remember { mutableStateOf<com.nuraid.jarvisnova.domain.CommandRouter.CommandResult.ExternalConfirm?>(null) }

    val bridge = remember {
        JarvisBridge(
            context = context,
            voice = vm.voice,
            autoSpeakEnabled = { vm.settings.value.autoSpeak },
            geminiConfigured = { vm.geminiConfigured() },
            attachWebView = {}
        )
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                text = "Command Center",
                style = androidx.compose.material3.MaterialTheme.typography.headlineSmall,
                color = androidx.compose.material3.MaterialTheme.colorScheme.primary
            )
            Text(
                text = status,
                style = androidx.compose.material3.MaterialTheme.typography.bodySmall,
                color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AssistChip(
                    onClick = { navigate(Routes.VOICE) },
                    label = { Text("Voice") },
                    leadingIcon = { Icon(Icons.Filled.Mic, contentDescription = null) }
                )
                AssistChip(
                    onClick = { navigate(Routes.CHAT) },
                    label = { Text("Chat") },
                    leadingIcon = { Icon(Icons.Filled.Chat, contentDescription = null) }
                )
                AssistChip(
                    onClick = { navigate(Routes.FOCUS) },
                    label = { Text("Focus 25m") },
                    leadingIcon = { Icon(Icons.Filled.Timer, contentDescription = null) }
                )
                AssistChip(
                    onClick = { navigate(Routes.NOTES_TASKS) },
                    label = { Text("Notes") },
                    leadingIcon = { Icon(Icons.Filled.NoteAlt, contentDescription = null) }
                )
            }
            OutlinedTextField(
                value = command,
                onValueChange = { command = it },
                label = { Text("Type a command — e.g. \"Start a 25-minute focus session\"") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TextButton(onClick = {
                    if (command.isNotBlank()) {
                        lastReply = vm.handleCommand(
                            input = command,
                            context = context,
                            onAndroidAction = { action -> vm.executeAndroidAction(action, context) },
                            onExternalConfirm = { pendingConfirm = it }
                        )
                        command = ""
                    }
                }) { Text("Execute") }
                TextButton(onClick = { vm.stopSpeaking() }) { Text("Stop speaking") }
            }
            if (lastReply != null) {
                Text(
                    text = lastReply!!,
                    style = androidx.compose.material3.MaterialTheme.typography.bodyMedium
                )
            }
        }

        // --- Original HUD (preserved byte-for-byte as an asset) ----------
        AndroidView(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            factory = { ctx ->
                WebView(ctx).apply {
                    layoutParams = ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.allowFileAccess = true
                    bridge.bind(this)
                    addJavascriptInterface(bridge, "AndroidNova")
                    webViewClient = object : WebViewClient() {
                        override fun onPageFinished(view: WebView?, url: String?) {
                            super.onPageFinished(view, url)
                            // Inject the bridge shim (kept as an asset so the
                            // original HUD file itself stays untouched).
                            try {
                                val js = ctx.assets.open("jarvis/nova_bridge.js")
                                    .bufferedReader().use { it.readText() }
                                view?.evaluateJavascript(js, null)
                            } catch (e: Exception) {
                                // Shim is optional — HUD still works without it.
                            }
                        }
                    }
                    loadUrl("file:///android_asset/jarvis/index.html")
                }
            }
        )
    }

    // Confirmation dialog for external actions.
    pendingConfirm?.let { confirm ->
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { pendingConfirm = null },
            title = { Text("Confirm action") },
            text = { Text(confirm.description) },
            confirmButton = {
                TextButton(onClick = {
                    vm.executeAndroidAction(
                        com.nuraid.jarvisnova.domain.CommandRouter.CommandResult.AndroidAction(
                            description = confirm.description,
                            intent = confirm.intent,
                            payload = confirm.payload
                        ),
                        context
                    )
                    pendingConfirm = null
                }) { Text("Confirm") }
            },
            dismissButton = {
                TextButton(onClick = { pendingConfirm = null }) { Text("Cancel") }
            }
        )
    }
}
