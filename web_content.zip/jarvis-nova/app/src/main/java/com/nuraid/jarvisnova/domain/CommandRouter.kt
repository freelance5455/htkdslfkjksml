package com.nuraid.jarvisnova.domain

/**
 * Natural-language command router.
 *
 * Pure Kotlin — no Android imports — so it is fully unit-testable.
 * It separates five kinds of outcome:
 *
 *  1. [CommandResult.LocalHandled]   — instant local actions (focus timer,
 *     notes, stop speaking, preferences the app applies itself).
 *  2. [CommandResult.AiRequest]      — the prompt should go to Gemini.
 *  3. [CommandResult.AndroidAction]  — an Android intent/action; may need
 *     a runtime permission the UI must request first.
 *  4. [CommandResult.ExternalConfirm]— leaves the app / has side effects;
 *     the UI must show a confirmation before running it.
 *  5. [CommandResult.Unsupported]    — honest explanation instead of
 *     pretending the action happened.
 *
 * The router NEVER claims success: [CommandResult.LocalHandled.action]
 * describes what the caller should do, and the caller reports the real
 * outcome after doing it.
 */
object CommandRouter {

    sealed class CommandResult {
        /** Local action the caller can perform immediately. */
        data class LocalHandled(val reply: String, val action: LocalAction) : CommandResult()

        /** Send [prompt] to Gemini (with [original] kept for display). */
        data class AiRequest(val prompt: String, val original: String) : CommandResult()

        /** Fire an Android intent/action. [permission] if one is required. */
        data class AndroidAction(
            val description: String,
            val intent: IntentKind,
            val payload: String = "",
            val permission: String? = null
        ) : CommandResult()

        /** Needs an explicit user confirmation in the UI first. */
        data class ExternalConfirm(val description: String, val intent: IntentKind, val payload: String = "") : CommandResult()

        /** Cannot be done — say why, honestly. */
        data class Unsupported(val reason: String) : CommandResult()
    }

    /** Kinds of device actions the UI layer knows how to execute. */
    enum class IntentKind {
        PLAY_FOCUS_PLAYLIST,
        YOUTUBE_SEARCH,
        WEB_SEARCH,
        OPEN_URL,
        OPEN_APP_SETTINGS,
        OPEN_NOTES,
        OPEN_TASKS,
        START_FOCUS_TIMER,
        NONE
    }

    /** Side-effect descriptions for local actions. */
    sealed class LocalAction {
        data class StartFocus(val minutes: Int) : LocalAction()
        data class SaveNote(val text: String) : LocalAction()
        data class ReadAloud(val text: String?) : LocalAction()
        data object StopSpeaking : LocalAction()
        data object CancelCurrent : LocalAction()
        data class SetDarkMode(val enabled: Boolean) : LocalAction()
        data class RememberPreference(val preference: String) : LocalAction()
        data object ShowRecentTasks : LocalAction()
        data object OpenNotes : LocalAction()
    }

    fun route(rawInput: String): CommandResult {
        val input = rawInput.trim()
        val text = input.lowercase()
        if (text.isBlank()) return CommandResult.Unsupported("I didn't catch a command. Type or tap the mic and try again.")

        // --- Stop / cancel take priority over everything else -----------
        if (matchesAny(text, "stop speaking", "stop talking", "be quiet", "silence", "shut up")) {
            return CommandResult.LocalHandled("Stopping speech.", LocalAction.StopSpeaking)
        }
        if (matchesAny(text, "cancel that", "cancel", "never mind", "nevermind", "forget it", "stop that")) {
            return CommandResult.LocalHandled("Cancelled.", LocalAction.CancelCurrent)
        }

        // --- Focus timer -------------------------------------------------
        parseDurationMinutes(text)?.let { minutes ->
            if (text.contains("focus") || text.contains("timer") || text.contains("session") || text.contains("pomodoro")) {
                return CommandResult.LocalHandled(
                    "Starting a $minutes-minute focus session.",
                    LocalAction.StartFocus(minutes)
                )
            }
        }
        if (text.contains("focus session") || text.contains("start focus") || text.startsWith("focus")) {
            return CommandResult.LocalHandled("Starting a 25-minute focus session.", LocalAction.StartFocus(25))
        }

        // --- Media ---------------------------------------------------------
        if (text.contains("focus playlist") || (text.contains("play") && text.contains("playlist"))) {
            return CommandResult.AndroidAction(
                description = "Open your focus playlist in your music/YouTube app",
                intent = IntentKind.PLAY_FOCUS_PLAYLIST,
                payload = "focus playlist"
            )
        }
        if (text.contains("tutorial") || text.startsWith("find ") || text.startsWith("search youtube")) {
            val query = input
                .replace(Regex("(?i)find (a |me a )?tutorial about"), "")
                .replace(Regex("(?i)search youtube for"), "")
                .replace(Regex("(?i)find "), "")
                .trim()
                .ifBlank { input }
            return CommandResult.AndroidAction(
                description = "Search YouTube for \"$query\"",
                intent = IntentKind.YOUTUBE_SEARCH,
                payload = query
            )
        }
        if (text.contains("blocked") && text.contains("control")) {
            return CommandResult.Unsupported("I can't control other apps directly — Android doesn't allow that. I can open them for you instead.")
        }

        // --- Notes / tasks --------------------------------------------------
        if (text.startsWith("save this idea") || text.startsWith("save idea") || text.startsWith("note this")) {
            val note = input.substringAfter(":", "")
                .ifBlank { input.replace(Regex("(?i)save (this )?idea"), "").trim() }
                .ifBlank { "Idea (saved from voice command)" }
            return CommandResult.LocalHandled("Saving that to your notes.", LocalAction.SaveNote(note))
        }
        if (text.contains("remember my") || text.startsWith("remember ")) {
            val pref = input.replace(Regex("(?i)^remember\\s+"), "").trim()
            return CommandResult.LocalHandled("I'll remember: $pref", LocalAction.RememberPreference(pref))
        }
        if (text.contains("open my notes") || text == "open notes" || text.contains("show my notes")) {
            return CommandResult.LocalHandled("Opening your notes.", LocalAction.OpenNotes)
        }
        if (text.contains("recent tasks") || text.contains("my tasks") || text.contains("show tasks")) {
            return CommandResult.LocalHandled("Here are your recent tasks.", LocalAction.ShowRecentTasks)
        }

        // --- Reading aloud --------------------------------------------------
        if (text.startsWith("read this") || text.startsWith("read aloud") || text.contains("read this page")) {
            val payload = input.substringAfter(":", "").trim().ifBlank { null }
            return CommandResult.LocalHandled("Reading aloud.", LocalAction.ReadAloud(payload))
        }
        if (text.startsWith("read ")) {
            val payload = input.removePrefix("read ").removePrefix("Read ").trim()
            if (payload.length > 12) {
                return CommandResult.LocalHandled("Reading aloud.", LocalAction.ReadAloud(payload))
            }
        }

        // --- Theme -----------------------------------------------------------
        if (text.contains("dark mode")) {
            val off = text.contains("off") || text.contains("disable") || text.contains("light")
            return CommandResult.LocalHandled(
                if (off) "Switching dark mode off." else "Dark mode on.",
                LocalAction.SetDarkMode(!off)
            )
        }
        if (text.contains("light mode") || text.contains("light theme")) {
            return CommandResult.LocalHandled("Switching to light theme.", LocalAction.SetDarkMode(false))
        }

        // --- AI tasks ---------------------------------------------------------
        if (startsWithAny(text, "summarize", "summarise", "explain", "rewrite", "translate", "brainstorm")) {
            return CommandResult.AiRequest(prompt = input, original = input)
        }
        if (text.contains("study plan") || text.contains("create a plan") || text.startsWith("plan ")) {
            return CommandResult.AiRequest(prompt = input, original = input)
        }
        if (text.contains("open settings") && text.contains("android")) {
            return CommandResult.ExternalConfirm(
                description = "Open Android system settings",
                intent = IntentKind.OPEN_APP_SETTINGS
            )
        }
        if (text.contains("hack") || text.contains("bypass") || text.contains("unlock") && text.contains("phone")) {
            return CommandResult.Unsupported("I can't bypass Android security or unlock protected content. I can only use official APIs and actions you confirm.")
        }

        // --- Default: it's a question / chat → Gemini -------------------------
        return CommandResult.AiRequest(prompt = input, original = input)
    }

    /** "25-minute", "25 minutes", "25 min", "1 hour" → minutes, or null. */
    fun parseDurationMinutes(text: String): Int? {
        val lower = text.lowercase()
        Regex("""(\d+)\s*(?:hour|hr)s?""").find(lower)?.let {
            return it.groupValues[1].toIntOrNull()?.times(60)
        }
        Regex("""(\d+)\s*(?:minute|min)s?""").find(lower)?.let {
            return it.groupValues[1].toIntOrNull()
        }
        Regex("""(\d+)\s*-\s*(?:minute|min)""").find(lower)?.let {
            return it.groupValues[1].toIntOrNull()
        }
        return null
    }

    private fun matchesAny(text: String, vararg phrases: String): Boolean =
        phrases.any { text == it || text.contains(it) }

    private fun startsWithAny(text: String, vararg prefixes: String): Boolean =
        prefixes.any { text.startsWith(it) }
}
