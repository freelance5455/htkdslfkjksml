package com.nuraid.jarvisnova.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "nova_settings")

/** Immutable snapshot of every user preference the app exposes. */
data class NovaSettings(
    val darkTheme: Boolean = true,
    val accentName: String = "Cyan",
    val reduceMotion: Boolean = false,
    val lowPower: Boolean = false,
    val autoSpeak: Boolean = true,
    val ttsVoiceName: String = "",
    val ttsPitch: Float = 0.9f,
    val ttsRate: Float = 1.0f,
    val ttsVolume: Float = 1.0f,
    val geminiModel: String = GeminiModels.DEFAULT,
    val temperature: Float = 0.7f,
    val maxOutputTokens: Int = 1024,
    val streamingEnabled: Boolean = true,
    val displayName: String = "Sir",
    val memoryEnabled: Boolean = true,
    val preferredStyle: String = ""
)

object GeminiModels {
    const val FLASH = "gemini-2.5-flash"
    const val FLASH_LITE = "gemini-2.5-flash-lite"
    const val PRO = "gemini-2.5-pro"
    const val DEFAULT = FLASH
    val ALL: List<String> = listOf(FLASH, FLASH_LITE, PRO)
}

/**
 * DataStore-backed preferences. The API key is deliberately NOT here —
 * it lives encrypted in [KeyStoreManager].
 */
class PreferencesManager(private val context: Context) {

    val settings: Flow<NovaSettings> = context.dataStore.data.map { p ->
        NovaSettings(
            darkTheme = p[Keys.DARK_THEME] ?: true,
            accentName = p[Keys.ACCENT] ?: "Cyan",
            reduceMotion = p[Keys.REDUCE_MOTION] ?: false,
            lowPower = p[Keys.LOW_POWER] ?: false,
            autoSpeak = p[Keys.AUTO_SPEAK] ?: true,
            ttsVoiceName = p[Keys.TTS_VOICE] ?: "",
            ttsPitch = p[Keys.TTS_PITCH] ?: 0.9f,
            ttsRate = p[Keys.TTS_RATE] ?: 1.0f,
            ttsVolume = p[Keys.TTS_VOLUME] ?: 1.0f,
            geminiModel = p[Keys.MODEL] ?: GeminiModels.DEFAULT,
            temperature = p[Keys.TEMPERATURE] ?: 0.7f,
            maxOutputTokens = p[Keys.MAX_TOKENS] ?: 1024,
            streamingEnabled = p[Keys.STREAMING] ?: true,
            displayName = p[Keys.DISPLAY_NAME] ?: "Sir",
            memoryEnabled = p[Keys.MEMORY] ?: true,
            preferredStyle = p[Keys.STYLE] ?: ""
        )
    }

    suspend fun update(transform: (NovaSettings) -> NovaSettings) {
        // Read-modify-write via edit{} with current values reconstructed
        // from the same keys, so partial updates stay consistent.
        context.dataStore.edit { p ->
            val current = NovaSettings(
                darkTheme = p[Keys.DARK_THEME] ?: true,
                accentName = p[Keys.ACCENT] ?: "Cyan",
                reduceMotion = p[Keys.REDUCE_MOTION] ?: false,
                lowPower = p[Keys.LOW_POWER] ?: false,
                autoSpeak = p[Keys.AUTO_SPEAK] ?: true,
                ttsVoiceName = p[Keys.TTS_VOICE] ?: "",
                ttsPitch = p[Keys.TTS_PITCH] ?: 0.9f,
                ttsRate = p[Keys.TTS_RATE] ?: 1.0f,
                ttsVolume = p[Keys.TTS_VOLUME] ?: 1.0f,
                geminiModel = p[Keys.MODEL] ?: GeminiModels.DEFAULT,
                temperature = p[Keys.TEMPERATURE] ?: 0.7f,
                maxOutputTokens = p[Keys.MAX_TOKENS] ?: 1024,
                streamingEnabled = p[Keys.STREAMING] ?: true,
                displayName = p[Keys.DISPLAY_NAME] ?: "Sir",
                memoryEnabled = p[Keys.MEMORY] ?: true,
                preferredStyle = p[Keys.STYLE] ?: ""
            )
            val next = transform(current)
            p[Keys.DARK_THEME] = next.darkTheme
            p[Keys.ACCENT] = next.accentName
            p[Keys.REDUCE_MOTION] = next.reduceMotion
            p[Keys.LOW_POWER] = next.lowPower
            p[Keys.AUTO_SPEAK] = next.autoSpeak
            p[Keys.TTS_VOICE] = next.ttsVoiceName
            p[Keys.TTS_PITCH] = next.ttsPitch
            p[Keys.TTS_RATE] = next.ttsRate
            p[Keys.TTS_VOLUME] = next.ttsVolume
            p[Keys.MODEL] = next.geminiModel
            p[Keys.TEMPERATURE] = next.temperature
            p[Keys.MAX_TOKENS] = next.maxOutputTokens
            p[Keys.STREAMING] = next.streamingEnabled
            p[Keys.DISPLAY_NAME] = next.displayName
            p[Keys.MEMORY] = next.memoryEnabled
            p[Keys.STYLE] = next.preferredStyle
        }
    }

    suspend fun clearAll() {
        context.dataStore.edit { it.clear() }
    }

    private object Keys {
        val DARK_THEME = booleanPreferencesKey("dark_theme")
        val ACCENT = stringPreferencesKey("accent")
        val REDUCE_MOTION = booleanPreferencesKey("reduce_motion")
        val LOW_POWER = booleanPreferencesKey("low_power")
        val AUTO_SPEAK = booleanPreferencesKey("auto_speak")
        val TTS_VOICE = stringPreferencesKey("tts_voice")
        val TTS_PITCH = floatPreferencesKey("tts_pitch")
        val TTS_RATE = floatPreferencesKey("tts_rate")
        val TTS_VOLUME = floatPreferencesKey("tts_volume")
        val MODEL = stringPreferencesKey("gemini_model")
        val TEMPERATURE = floatPreferencesKey("temperature")
        val MAX_TOKENS = intPreferencesKey("max_tokens")
        val STREAMING = booleanPreferencesKey("streaming")
        val DISPLAY_NAME = stringPreferencesKey("display_name")
        val MEMORY = booleanPreferencesKey("memory_enabled")
        val STYLE = stringPreferencesKey("preferred_style")
    }
}
