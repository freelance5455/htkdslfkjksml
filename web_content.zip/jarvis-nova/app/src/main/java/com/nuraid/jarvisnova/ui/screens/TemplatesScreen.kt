package com.nuraid.jarvisnova.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.nuraid.jarvisnova.data.NovaTemplate
import com.nuraid.jarvisnova.data.Templates
import com.nuraid.jarvisnova.ui.AppViewModel
import com.nuraid.jarvisnova.ui.Routes
import com.nuraid.jarvisnova.ui.components.NovaCard
import com.nuraid.jarvisnova.ui.components.ScreenTitle

/**
 * Template library: the 14 preset workspaces from the brief plus a
 * blank Custom template. Selecting one starts a fresh chat carrying
 * the template's system prompt; its quick actions send immediately.
 */
@Composable
fun TemplatesScreen(vm: AppViewModel, navigate: (String) -> Unit) {
    var expandedId by remember { mutableStateOf<String?>(null) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item { ScreenTitle("Template Library", "Tap a template to preview it, then start a workspace chat") }
        items(Templates.ALL) { template ->
            TemplateCard(
                template = template,
                expanded = expandedId == template.id,
                onToggle = { expandedId = if (expandedId == template.id) null else template.id },
                onStart = { action ->
                    vm.startFromTemplate(
                        systemPrompt = template.systemPrompt,
                        templateId = template.id,
                        title = template.name,
                        firstPrompt = action
                    )
                    navigate(Routes.CHAT)
                }
            )
        }
    }
}

@Composable
private fun TemplateCard(
    template: NovaTemplate,
    expanded: Boolean,
    onToggle: () -> Unit,
    onStart: (String?) -> Unit
) {
    NovaCard(modifier = Modifier.clickable { onToggle() }) {
        Text(template.name, style = MaterialTheme.typography.titleMedium, color = template.accent)
        Text(template.description, style = MaterialTheme.typography.bodyMedium)
        if (expanded) {
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                TextButton(
                    onClick = { onStart(null) },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Start empty ${template.name} chat") }
                template.quickActions.forEach { action ->
                    TextButton(
                        onClick = { onStart(action) },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("▸ $action") }
                }
            }
        }
    }
}
