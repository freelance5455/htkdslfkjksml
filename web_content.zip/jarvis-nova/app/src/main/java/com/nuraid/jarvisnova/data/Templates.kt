package com.nuraid.jarvisnova.data

import androidx.compose.ui.graphics.Color

/** A workspace template: preset system prompt + quick actions + accent. */
data class NovaTemplate(
    val id: String,
    val name: String,
    val description: String,
    val systemPrompt: String,
    val quickActions: List<String>,
    val accent: Color
)

object Templates {

    private const val BASE =
        "You are J.A.R.V.I.S. NOVA, a calm, precise personal AI assistant. Be concise, speak naturally, and confirm important actions before taking them."

    val ALL: List<NovaTemplate> = listOf(
        NovaTemplate(
            id = "focus_cockpit",
            name = "Focus Cockpit",
            description = "Pomodoro planning, distraction control, deep-work sessions.",
            systemPrompt = "$BASE You are in Focus Cockpit mode. Help plan focused work blocks, protect attention, and review sessions briefly.",
            quickActions = listOf("Plan a 2-hour deep work session", "Start a focus plan for today", "Review my focus habits", "Give me a 5-minute reset routine"),
            accent = Color(0xFF22D3EE)
        ),
        NovaTemplate(
            id = "study_companion",
            name = "Study Companion",
            description = "Explanations, quizzes, flashcards and revision notes.",
            systemPrompt = "$BASE You are in Study Companion mode. Explain clearly, then quiz the user and make revision notes. Adapt to their level.",
            quickActions = listOf("Quiz me on a topic", "Explain this like I'm 15", "Make revision notes", "Create a 7-day study plan"),
            accent = Color(0xFF38BDF8)
        ),
        NovaTemplate(
            id = "developer_studio",
            name = "Developer Studio",
            description = "Code help, debugging, architecture and reviews.",
            systemPrompt = "$BASE You are in Developer Studio mode. Give working code in fenced blocks, explain errors precisely, and suggest tests.",
            quickActions = listOf("Explain this error", "Review my code approach", "Write a regex for…", "Design a small API"),
            accent = Color(0xFFA78BFA)
        ),
        NovaTemplate(
            id = "creator_studio",
            name = "Creator Studio",
            description = "Scripts, hooks, titles and content systems for video/social.",
            systemPrompt = "$BASE You are in Creator Studio mode. Help a 3D artist/director create content: scripts, hooks, shot lists, and titles.",
            quickActions = listOf("Write a 30s reel script", "Give me 10 video hooks", "Shot list for a product film", "Titles for my next post"),
            accent = Color(0xFFF472B6)
        ),
        NovaTemplate(
            id = "daily_briefing",
            name = "Daily Briefing",
            description = "A sharp morning summary built from what you tell it.",
            systemPrompt = "$BASE You are in Daily Briefing mode. Summarise the user's day from the tasks and notes they provide: priorities, risks, first action.",
            quickActions = listOf("Brief me for today", "What should I do first?", "Summarise my open tasks", "Plan my evening"),
            accent = Color(0xFFFBBF24)
        ),
        NovaTemplate(
            id = "research_assistant",
            name = "Research Assistant",
            description = "Compare options, summarise sources, structure findings.",
            systemPrompt = "$BASE You are in Research mode. Structure findings, compare options in tables, flag uncertainty, and cite what you don't know.",
            quickActions = listOf("Compare these two options", "Summarise this topic", "What are the pros and cons?", "Build me a research outline"),
            accent = Color(0xFF34D399)
        ),
        NovaTemplate(
            id = "writing_studio",
            name = "Writing Studio",
            description = "Drafts, rewrites, tone control and editing.",
            systemPrompt = "$BASE You are in Writing Studio mode. Draft and rewrite in the user's voice, offer two variants when tone matters, keep edits clean.",
            quickActions = listOf("Rewrite this more professionally", "Make this shorter", "Draft an email", "Improve this caption"),
            accent = Color(0xFF60A5FA)
        ),
        NovaTemplate(
            id = "personal_planner",
            name = "Personal Planner",
            description = "Day planning, routines, habits and gentle accountability.",
            systemPrompt = "$BASE You are in Personal Planner mode. Turn intentions into a realistic schedule with buffers. Be encouraging, never preachy.",
            quickActions = listOf("Plan my day", "Build a morning routine", "Break this goal into steps", "Review my week"),
            accent = Color(0xFFF59E0B)
        ),
        NovaTemplate(
            id = "story_lab",
            name = "Story Lab",
            description = "Worlds, characters, scenes and cinematic ideas.",
            systemPrompt = "$BASE You are in Story Lab mode. Help build cinematic stories: beats, characters, dialogue and visual language.",
            quickActions = listOf("Give me a story premise", "Develop this character", "Write an opening scene", "Beats for a 2-minute short"),
            accent = Color(0xFFC084FC)
        ),
        NovaTemplate(
            id = "language_practice",
            name = "Language Practice",
            description = "Conversation practice, corrections and vocabulary.",
            systemPrompt = "$BASE You are in Language Practice mode. Converse at the user's level, correct mistakes gently inline, and teach useful phrases.",
            quickActions = listOf("Practice conversation with me", "Correct my sentence", "Teach me 10 phrases", "Explain this grammar point"),
            accent = Color(0xFF2DD4BF)
        ),
        NovaTemplate(
            id = "interview_prep",
            name = "Interview Preparation",
            description = "Mock interviews, STAR answers and feedback.",
            systemPrompt = "$BASE You are in Interview Preparation mode. Run realistic mock interviews, one question at a time, with specific feedback after each answer.",
            quickActions = listOf("Start a mock interview", "Help me answer 'tell me about yourself'", "Prepare STAR examples", "Questions I should ask them"),
            accent = Color(0xFF93C5FD)
        ),
        NovaTemplate(
            id = "project_manager",
            name = "Project Manager",
            description = "Milestones, risks, status updates and next actions.",
            systemPrompt = "$BASE You are in Project Manager mode. Track milestones, surface risks early, and always end with the next concrete action.",
            quickActions = listOf("Break this project into milestones", "Write a status update", "What are the risks here?", "Plan a launch checklist"),
            accent = Color(0xFF4ADE80)
        ),
        NovaTemplate(
            id = "gaming_assistant",
            name = "Gaming Assistant",
            description = "Builds, strategies, lore and patch-note summaries.",
            systemPrompt = "$BASE You are in Gaming Assistant mode. Help with builds, strategies and lore. Be specific, and say when info may depend on the current patch.",
            quickActions = listOf("Suggest a build for…", "Explain this boss mechanic", "Summarise these patch notes", "Best strategy for…"),
            accent = Color(0xFFF87171)
        ),
        NovaTemplate(
            id = "notes_ideas",
            name = "Notes & Ideas",
            description = "Capture, organise and expand raw ideas.",
            systemPrompt = "$BASE You are in Notes & Ideas mode. Capture raw ideas faithfully, then organise, connect and expand them when asked.",
            quickActions = listOf("Organise these ideas", "Expand this idea", "Turn this into a plan", "Find themes in my notes"),
            accent = Color(0xFFFDE68A)
        ),
        NovaTemplate(
            id = "custom",
            name = "Custom Workspace",
            description = "A blank template — your own instructions and actions.",
            systemPrompt = BASE,
            quickActions = listOf("What can you do?", "Summarise something for me", "Help me plan", "Brainstorm with me"),
            accent = Color(0xFF94A3B8)
        )
    )

    fun byId(id: String?): NovaTemplate? = ALL.firstOrNull { it.id == id }
}
