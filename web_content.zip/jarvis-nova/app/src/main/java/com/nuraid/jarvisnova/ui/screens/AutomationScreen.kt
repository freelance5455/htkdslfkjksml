package com.nuraid.jarvisnova.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.nuraid.jarvisnova.ui.AppViewModel
import com.nuraid.jarvisnova.ui.Routes
import com.nuraid.jarvisnova.ui.components.EmptyState
import com.nuraid.jarvisnova.ui.components.NovaCard
import com.nuraid.jarvisnova.ui.components.ScreenTitle
import com.nuraid.jarvisnova.util.Intents

/**
 * Automation & shortcuts: reusable prompt shortcuts (CRUD).
 * Running a prompt shortcut sends it to Gemini in Chat; a URL shortcut
 * opens its link. No background triggers are promised — shortcuts run
 * when you tap them.
 */
@Composable
fun AutomationScreen(vm: AppViewModel, navigate: (String) -> Unit) {
    val context = LocalContext.current
    val shortcuts by vm.shortcuts.collectAsState()
    val promptShortcuts = shortcuts.filter { it.prompt.isNotBlank() }
    var name by remember { mutableStateOf("") }
    var prompt by remember { mutableStateOf("") }
    var url by remember { mutableStateOf("") }
    var editingId by remember { mutableStateOf<Long?>(null) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { ScreenTitle("Automation & Shortcuts", "One-tap prompts. They run when you tap — nothing runs secretly in the background.") }
        item {
            NovaCard {
                Text(if (editingId == null) "New shortcut" else "Edit shortcut", style = androidx.compose.material3.MaterialTheme.typography.titleMedium)
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = prompt,
                    onValueChange = { prompt = it },
                    label = { Text("Prompt sent to Gemini") },
                    modifier = Modifier.fillMaxWidth(),
                    maxLines = 3
                )
                OutlinedTextField(
                    value = url,
                    onValueChange = { url = it },
                    label = { Text("Optional URL to open instead") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = {
                        if (name.isNotBlank() && (prompt.isNotBlank() || url.isNotBlank())) {
                            val existing = promptShortcuts.firstOrNull { it.id == editingId }
                            if (existing != null) {
                                vm.deleteShortcut(existing)
                            }
                            vm.addShortcut(name.trim(), prompt.trim(), url.trim().ifBlank { null })
                            name = ""; prompt = ""; url = ""; editingId = null
                        }
                    }) { Text(if (editingId == null) "Add shortcut" else "Save changes") }
                    if (editingId != null) {
                        TextButton(onClick = { name = ""; prompt = ""; url = ""; editingId = null }) { Text("Cancel edit") }
                    }
                }
            }
        }
        if (promptShortcuts.isEmpty()) {
            item { EmptyState("No shortcuts yet. Try: \"Morning brief\" → \"Brief me: my tasks, one priority, one risk.\"") }
        } else {
            items(promptShortcuts) { shortcut ->
                NovaCard {
                    Text(shortcut.name, style = androidx.compose.material3.MaterialTheme.typography.titleMedium)
                    if (shortcut.prompt.isNotBlank()) Text(shortcut.prompt)
                    if (!shortcut.url.isNullOrBlank()) Text(shortcut.url!!)
                    Row {
                        TextButton(onClick = {
                            if (!shortcut.url.isNullOrBlank()) {
                                Intents.openUrl(context, shortcut.url!!)
                            } else {
                                vm.sendChat(shortcut.prompt)
                                navigate(Routes.CHAT)
                            }
                        }) { Text("Run") }
                        TextButton(onClick = {
                            editingId = shortcut.id
                            name = shortcut.name
                            prompt = shortcut.prompt
                            url = shortcut.url ?: ""
                        }) { Text("Edit") }
                        TextButton(onClick = { vm.deleteShortcut(shortcut) }) { Text("Delete") }
                    }
                }
            }
        }
    }
}
