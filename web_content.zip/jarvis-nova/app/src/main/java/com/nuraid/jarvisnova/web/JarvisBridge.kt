package com.nuraid.jarvisnova.web

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.nuraid.jarvisnova.JarvisNovaApp
import com.nuraid.jarvisnova.voice.VoiceManager

/**
 * Bridge exposed to the preserved HTML HUD as `window.AndroidNova`.
 *
 * The original index.html works standalone in a browser; inside NOVA it
 * can additionally call these native capabilities. Every method is
 * small, synchronous-safe, and does exactly what its name says — no
 * hidden behaviour. See assets/jarvis/nova_bridge.js for the JS shim
 * that forwards results back into the page.
 */
class JarvisBridge(
    private val context: Context,
    private val voice: VoiceManager,
    private val autoSpeakEnabled: () -> Boolean,
    private val geminiConfigured: () -> Boolean,
    private val attachWebView: (WebView) -> Unit
) {
    private var webView: WebView? = null

    /** Called by the WebView screen so listen() can deliver results back. */
    fun bind(webView: WebView) {
        this.webView = webView
        attachWebView(webView)
    }

    @JavascriptInterface
    fun isNative(): Boolean = true

    @JavascriptInterface
    fun speak(text: String) {
        voice.speak(text, enabled = autoSpeakEnabled())
    }

    @JavascriptInterface
    fun stopSpeaking() {
        voice.stopSpeaking()
    }

    /**
     * Starts native speech recognition. The final transcript is sent
     * back to the page via `window.__novaOnListenResult(text)` (defined
     * by nova_bridge.js / the HUD if it chooses to implement it).
     * RECORD_AUDIO must already be granted — the HUD's mic button goes
     * through the native Voice screen when it is not.
     */
    @JavascriptInterface
    fun listen() {
        voice.startListening { transcript ->
            val escaped = transcript
                .replace("\\", "\\\\")
                .replace("'", "\\'")
                .replace("\n", " ")
            webView?.post {
                webView?.evaluateJavascript(
                    "window.__novaOnListenResult && window.__novaOnListenResult('$escaped')",
                    null
                )
            }
        }
    }

    @JavascriptInterface
    fun shareText(text: String) {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, text)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(Intent.createChooser(intent, "Share via").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    @JavascriptInterface
    fun copyToClipboard(text: String) {
        val clipboard = context.getSystemService(ClipboardManager::class.java)
        clipboard.setPrimaryClip(ClipData.newPlainText("J.A.R.V.I.S. NOVA", text))
        Toast.makeText(context, "Copied to clipboard", Toast.LENGTH_SHORT).show()
    }

    @JavascriptInterface
    fun openUrl(url: String) {
        val uri = Uri.parse(url)
        if (uri.scheme != "https" && uri.scheme != "http") return // refuse unsafe schemes
        val intent = Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
    }

    @JavascriptInterface
    fun notify(title: String, body: String) {
        val notification = NotificationCompat.Builder(context, JarvisNovaApp.CHANNEL_REMINDERS)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .build()
        try {
            NotificationManagerCompat.from(context).notify((System.currentTimeMillis() % 100000).toInt(), notification)
        } catch (e: SecurityException) {
            // POST_NOTIFICATIONS not granted — surface honestly in-page instead.
            Toast.makeText(context, "Notifications permission not granted", Toast.LENGTH_SHORT).show()
        }
    }

    @JavascriptInterface
    fun haptic() {
        val vibrator: Vibrator? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            context.getSystemService(VibratorManager::class.java)?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }
        vibrator?.vibrate(VibrationEffect.createOneShot(30, VibrationEffect.DEFAULT_AMPLITUDE))
    }

    @JavascriptInterface
    fun geminiConfigured(): Boolean = geminiConfigured.invoke()
}
