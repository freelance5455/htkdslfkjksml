package com.nuraid.jarvisnova.data.db

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface ConversationDao {
    @Query("SELECT * FROM conversations WHERE archived = 0 ORDER BY updatedAt DESC")
    fun observeActive(): Flow<List<Conversation>>

    @Query("SELECT * FROM conversations WHERE archived = 1 ORDER BY updatedAt DESC")
    fun observeArchived(): Flow<List<Conversation>>

    @Query("SELECT * FROM conversations WHERE title LIKE '%' || :query || '%' ORDER BY updatedAt DESC")
    fun search(query: String): Flow<List<Conversation>>

    @Query("SELECT * FROM conversations WHERE id = :id")
    suspend fun getById(id: Long): Conversation?

    @Insert suspend fun insert(conversation: Conversation): Long
    @Update suspend fun update(conversation: Conversation)
    @Delete suspend fun delete(conversation: Conversation)

    @Query("DELETE FROM conversations")
    suspend fun deleteAll()
}

@Dao
interface MessageDao {
    @Query("SELECT * FROM messages WHERE conversationId = :conversationId ORDER BY createdAt ASC")
    fun observeForConversation(conversationId: Long): Flow<List<Message>>

    @Query("SELECT * FROM messages WHERE conversationId = :conversationId ORDER BY createdAt ASC")
    suspend fun getForConversation(conversationId: Long): List<Message>

    @Insert suspend fun insert(message: Message): Long

    @Query("DELETE FROM messages WHERE conversationId = :conversationId")
    suspend fun deleteForConversation(conversationId: Long)

    @Query("DELETE FROM messages")
    suspend fun deleteAll()
}

@Dao
interface NoteDao {
    @Query("SELECT * FROM notes ORDER BY pinned DESC, createdAt DESC")
    fun observeAll(): Flow<List<Note>>

    @Insert suspend fun insert(note: Note): Long
    @Update suspend fun update(note: Note)
    @Delete suspend fun delete(note: Note)

    @Query("DELETE FROM notes")
    suspend fun deleteAll()
}

@Dao
interface TaskDao {
    @Query("SELECT * FROM tasks ORDER BY done ASC, createdAt DESC")
    fun observeAll(): Flow<List<TaskItem>>

    @Query("SELECT * FROM tasks WHERE done = 0 ORDER BY createdAt DESC LIMIT :limit")
    suspend fun getPending(limit: Int): List<TaskItem>

    @Insert suspend fun insert(task: TaskItem): Long
    @Update suspend fun update(task: TaskItem)
    @Delete suspend fun delete(task: TaskItem)

    @Query("DELETE FROM tasks")
    suspend fun deleteAll()
}

@Dao
interface ShortcutDao {
    @Query("SELECT * FROM shortcuts ORDER BY createdAt ASC")
    fun observeAll(): Flow<List<Shortcut>>

    @Insert suspend fun insert(shortcut: Shortcut): Long
    @Update suspend fun update(shortcut: Shortcut)
    @Delete suspend fun delete(shortcut: Shortcut)

    @Query("DELETE FROM shortcuts")
    suspend fun deleteAll()
}
