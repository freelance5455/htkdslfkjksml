package com.nuraid.jarvisnova.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import com.nuraid.jarvisnova.BuildConfig
import com.nuraid.jarvisnova.ui.AppViewModel
import com.nuraid.jarvisnova.ui.components.NovaCard
import com.nuraid.jarvisnova.ui.components.ScreenTitle
import com.nuraid.jarvisnova.util.Diagnostics

/**
 * App information & diagnostics. The report contains device/app status
 * only — never the API key or conversation content.
 */
@Composable
fun AboutScreen(vm: AppViewModel, navigate: (String) -> Unit) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val settings by vm.settings.collectAsState()
    val ttsReady by vm.voice.ttsReady.collectAsState()

    val battery = Diagnostics.batteryPercent(context)
    val report = Diagnostics.buildReport(context, settings, vm.geminiConfigured(), ttsReady)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ScreenTitle("About & Diagnostics", "J.A.R.V.I.S. NOVA v${BuildConfig.VERSION_NAME}")
        NovaCard {
            Text("System status", style = MaterialTheme.typography.titleMedium)
            Text("Battery: ${if (battery >= 0) "$battery%" else "unknown"}${if (Diagnostics.isCharging(context)) " (charging)" else ""}")
            Text("Network: ${Diagnostics.networkDescription(context)}")
            Text("Gemini: ${settings.geminiModel} · key ${if (vm.geminiConfigured()) "configured" else "NOT configured"}")
            Text("Speech engine: ${if (ttsReady) "ready" else "starting"}")
        }
        NovaCard {
            Text("Feature status", style = MaterialTheme.typography.titleMedium)
            FEATURE_LINES.forEach { Text("• $it") }
        }
        NovaCard {
            Text("Diagnostics report", style = MaterialTheme.typography.titleMedium)
            Text(report, style = MaterialTheme.typography.bodySmall)
            Button(
                onClick = { clipboard.setText(AnnotatedString(report)) },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Copy diagnostics (no API key included)") }
        }
        Text(
            text = "J.A.R.V.I.S. NOVA is an original, Iron Man-inspired interface built for personal use. It does not project real holograms and does not control other apps beyond official Android intents.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

private val FEATURE_LINES = listOf(
    "Working: Gemini chat (streaming), native TTS/STT, command router, notes, tasks + reminders, focus timer, templates, document text summarizer, WebView HUD with native bridge",
    "Needs your Gemini key: all AI chat, study/coding/document features",
    "Needs microphone permission: voice input only",
    "Needs notification permission (Android 13+): focus/reminder alerts",
    "Not included by design: background wake-word listening, arbitrary control of other apps, real hologram projection"
)
