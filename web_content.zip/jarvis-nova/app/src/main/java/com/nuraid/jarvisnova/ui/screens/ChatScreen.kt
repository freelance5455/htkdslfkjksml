package com.nuraid.jarvisnova.ui.screens

import android.graphics.BitmapFactory
import android.util.Base64
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import com.nuraid.jarvisnova.data.GeminiImage
import com.nuraid.jarvisnova.ui.AppViewModel
import com.nuraid.jarvisnova.ui.Routes
import com.nuraid.jarvisnova.ui.components.EmptyState
import com.nuraid.jarvisnova.ui.components.ScreenTitle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream

/**
 * AI chat: multi-turn Gemini conversation with streaming, cancel,
 * retry, per-message copy, and optional image attachment (sent as an
 * inline base64 part on the latest user turn).
 */
@Composable
fun ChatScreen(vm: AppViewModel, navigate: (String) -> Unit) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val scope = rememberCoroutineScope()
    val messages by vm.currentMessages.collectAsState()
    val isGenerating by vm.isGenerating.collectAsState()
    val streamingText by vm.streamingText.collectAsState()
    val chatError by vm.chatError.collectAsState()

    var input by remember { mutableStateOf("") }
    var attachedImage by remember { mutableStateOf<GeminiImage?>(null) }
    var attachedName by remember { mutableStateOf<String?>(null) }
    val listState = rememberLazyListState()

    val imagePicker = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            scope.launch {
                val encoded = withContext(Dispatchers.IO) {
                    try {
                        val bytes = context.contentResolver.openInputStream(uri)?.readBytes()
                        val bitmap = bytes?.let { BitmapFactory.decodeByteArray(it, 0, it.size) }
                        if (bitmap != null) {
                            val out = ByteArrayOutputStream()
                            bitmap.compress(android.graphics.Bitmap.CompressFormat.JPEG, 80, out)
                            GeminiImage("image/jpeg", Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP))
                        } else null
                    } catch (e: Exception) {
                        null
                    }
                }
                attachedImage = encoded
                attachedName = if (encoded != null) "Image attached" else "Could not read that image"
            }
        }
    }

    LaunchedEffect(messages.size, streamingText) {
        val count = messages.size + if (streamingText.isNotBlank()) 1 else 0
        if (count > 0) listState.animateScrollToItem(count - 1)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            ScreenTitle("AI Chat", if (vm.geminiConfigured()) "Gemini connected" else "Add a Gemini key in Model Settings")
            TextButton(onClick = { vm.startNewConversation() }) { Text("New chat") }
        }

        if (!vm.geminiConfigured()) {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("No Gemini API key configured. Chat can't run yet.")
                    TextButton(onClick = { navigate(Routes.MODEL_SETTINGS) }) { Text("Open AI Model Settings") }
                }
            }
        }

        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (messages.isEmpty() && streamingText.isBlank()) {
                item { EmptyState("No messages yet. Ask anything, or open the Template Library for a ready-made workspace.") }
            }
            items(messages) { message ->
                val isUser = message.role == "user"
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (isUser) {
                            MaterialTheme.colorScheme.primaryContainer
                        } else {
                            MaterialTheme.colorScheme.surfaceVariant
                        }
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = if (isUser) "You" else "J.A.R.V.I.S. NOVA",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(text = message.text, style = MaterialTheme.typography.bodyMedium)
                        Row {
                            TextButton(onClick = { clipboard.setText(AnnotatedString(message.text)) }) {
                                Icon(Icons.Filled.ContentCopy, contentDescription = "Copy")
                                Text(" Copy")
                            }
                            if (!isUser) {
                                TextButton(onClick = { vm.speakAlways(message.text) }) { Text("Read aloud") }
                            }
                        }
                    }
                }
            }
            if (streamingText.isNotBlank()) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text("J.A.R.V.I.S. NOVA — responding…", style = MaterialTheme.typography.labelMedium)
                            Text(text = streamingText, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            }
            if (chatError != null) {
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(text = chatError!!, color = MaterialTheme.colorScheme.onErrorContainer)
                            Row {
                                TextButton(onClick = { vm.retryLast() }) { Text("Retry") }
                                TextButton(onClick = { vm.clearChatError() }) { Text("Dismiss") }
                            }
                        }
                    }
                }
            }
        }

        if (attachedName != null) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(attachedName!!, style = MaterialTheme.typography.bodySmall)
                TextButton(onClick = { attachedImage = null; attachedName = null }) { Text("Remove") }
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            IconButton(onClick = { imagePicker.launch("image/*") }) {
                Icon(Icons.Filled.AttachFile, contentDescription = "Attach image")
            }
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                label = { Text("Message NOVA…") },
                modifier = Modifier.weight(1f),
                maxLines = 4
            )
            if (isGenerating) {
                IconButton(onClick = { vm.cancelGeneration() }) {
                    Icon(Icons.Filled.Stop, contentDescription = "Cancel response")
                }
            } else {
                IconButton(onClick = {
                    if (input.isNotBlank()) {
                        vm.sendChat(input, attachedImage)
                        input = ""
                        attachedImage = null
                        attachedName = null
                    }
                }) {
                    Icon(Icons.Filled.Send, contentDescription = "Send")
                }
            }
        }
        OutlinedButton(
            onClick = { navigate(Routes.HISTORY) },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Conversation history") }
        Button(
            onClick = { navigate(Routes.TEMPLATES) },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Start from a template") }
    }
}
