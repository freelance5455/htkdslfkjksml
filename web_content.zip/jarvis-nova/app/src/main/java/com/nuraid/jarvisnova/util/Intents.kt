package com.nuraid.jarvisnova.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.widget.Toast

/** Small, honest intent helpers. Each one reports failure via Toast. */
object Intents {

    fun openUrl(context: Context, url: String) {
        val uri = Uri.parse(url)
        if (uri.scheme != "https" && uri.scheme != "http") {
            toast(context, "Refused unsafe link")
            return
        }
        launch(context, Intent(Intent.ACTION_VIEW, uri), "No app can open that link")
    }

    fun youtubeSearch(context: Context, query: String) {
        val appIntent = Intent(Intent.ACTION_SEARCH).apply {
            setPackage("com.google.android.youtube")
            putExtra("query", query)
        }
        if (appIntent.resolveActivity(context.packageManager) != null) {
            launch(context, appIntent, null)
        } else {
            openUrl(context, "https://www.youtube.com/results?search_query=" + Uri.encode(query))
        }
    }

    fun webSearch(context: Context, query: String) {
        val intent = Intent(Intent.ACTION_WEB_SEARCH).putExtra("query", query)
        if (intent.resolveActivity(context.packageManager) != null) {
            launch(context, intent, null)
        } else {
            openUrl(context, "https://www.google.com/search?q=" + Uri.encode(query))
        }
    }

    fun playFocusPlaylist(context: Context) {
        // Honest scope: we open a focus-playlist search in YouTube / the
        // browser. We do NOT claim playback started — the user presses
        // play in their own app, which handles its own licensing/login.
        youtubeSearch(context, "focus playlist lofi deep work")
    }

    fun shareText(context: Context, text: String, chooserTitle: String = "Share via") {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, text)
        }
        launch(context, Intent.createChooser(intent, chooserTitle), "No app available to share with")
    }

    fun openAppSettings(context: Context) {
        launch(
            context,
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + context.packageName)),
            "Could not open settings"
        )
    }

    fun openSystemSettings(context: Context) {
        launch(context, Intent(Settings.ACTION_SETTINGS), "Could not open settings")
    }

    private fun launch(context: Context, intent: Intent, errorMessage: String?) {
        try {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
        } catch (e: Exception) {
            if (errorMessage != null) toast(context, errorMessage)
        }
    }

    fun toast(context: Context, message: String) {
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
    }
}
