package com.nuraid.jarvisnova.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.nuraid.jarvisnova.ui.AppViewModel
import com.nuraid.jarvisnova.ui.components.EmptyState
import com.nuraid.jarvisnova.ui.components.NovaCard
import com.nuraid.jarvisnova.ui.components.ScreenTitle
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Notes & Tasks manager. Task reminders are scheduled with WorkManager. */
@Composable
fun NotesTasksScreen(vm: AppViewModel, navigate: (String) -> Unit) {
    val context = LocalContext.current
    val notes by vm.notes.collectAsState()
    val tasks by vm.tasks.collectAsState()
    var tab by remember { mutableIntStateOf(0) }
    var noteText by remember { mutableStateOf("") }
    var taskText by remember { mutableStateOf("") }
    var remindInHours by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        ScreenTitle("Notes & Tasks", "Stored on-device in the local database")
        TabRow(selectedTabIndex = tab) {
            Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Notes (${notes.size})") })
            Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("Tasks (${tasks.count { !it.done }})") })
        }

        if (tab == 0) {
            OutlinedTextField(
                value = noteText,
                onValueChange = { noteText = it },
                label = { Text("Write a note or idea…") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                maxLines = 4
            )
            Button(
                onClick = { if (noteText.isNotBlank()) { vm.addNote(noteText.trim()); noteText = "" } },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Save note") }
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .padding(top = 12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (notes.isEmpty()) {
                    item { EmptyState("No notes yet. Voice shortcut: \"Save this idea: …\"") }
                }
                items(notes) { note ->
                    NovaCard {
                        Text(note.text)
                        Row {
                            TextButton(onClick = { vm.togglePin(note) }) {
                                Text(if (note.pinned) "Unpin" else "Pin")
                            }
                            TextButton(onClick = { vm.speakAlways(note.text) }) { Text("Read aloud") }
                            TextButton(onClick = { vm.deleteNote(note) }) { Text("Delete") }
                        }
                    }
                }
            }
        } else {
            OutlinedTextField(
                value = taskText,
                onValueChange = { taskText = it },
                label = { Text("New task…") },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp)
            )
            OutlinedTextField(
                value = remindInHours,
                onValueChange = { remindInHours = it.filter { c -> c.isDigit() } },
                label = { Text("Remind me in (hours, optional)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Button(
                onClick = {
                    if (taskText.isNotBlank()) {
                        val hours = remindInHours.toLongOrNull()
                        val remindAt = hours?.let { System.currentTimeMillis() + it * 3_600_000L }
                        vm.addTask(taskText.trim(), remindAt, context)
                        taskText = ""
                        remindInHours = ""
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp)
            ) { Text("Add task") }
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .padding(top = 12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (tasks.isEmpty()) {
                    item { EmptyState("No tasks. Add one above, or ask NOVA for your recent tasks.") }
                }
                items(tasks) { task ->
                    NovaCard {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = task.done, onCheckedChange = { vm.toggleTask(task) })
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = task.title,
                                    textDecoration = if (task.done) {
                                        androidx.compose.ui.text.style.TextDecoration.LineThrough
                                    } else null
                                )
                                if (task.remindAt != null) {
                                    Text(
                                        text = "Reminder: " + SimpleDateFormat("d MMM, h:mm a", Locale.getDefault()).format(Date(task.remindAt)),
                                        style = androidx.compose.material3.MaterialTheme.typography.bodySmall,
                                        color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                            TextButton(onClick = { vm.deleteTask(task, context) }) { Text("Delete") }
                        }
                    }
                }
            }
        }
    }
}
