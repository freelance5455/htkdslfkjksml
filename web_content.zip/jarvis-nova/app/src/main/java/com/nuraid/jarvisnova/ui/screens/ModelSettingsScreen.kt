package com.nuraid.jarvisnova.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.nuraid.jarvisnova.data.GeminiModels
import com.nuraid.jarvisnova.ui.AppViewModel
import com.nuraid.jarvisnova.ui.components.NovaCard
import com.nuraid.jarvisnova.ui.components.ScreenTitle
import com.nuraid.jarvisnova.ui.components.SettingRow
import kotlinx.coroutines.launch

/**
 * AI model settings: Gemini API key (stored encrypted via Android
 * Keystore — never in plain preferences, never logged), model picker,
 * generation settings, and a real test-connection call.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ModelSettingsScreen(vm: AppViewModel, navigate: (String) -> Unit) {
    val settings by vm.settings.collectAsState()
    val scope = rememberCoroutineScope()
    var keyInput by remember { mutableStateOf("") }
    var keySaved by remember { mutableStateOf(vm.geminiConfigured()) }
    var testState by remember { mutableStateOf<String?>(null) }
    var testing by remember { mutableStateOf(false) }
    var modelMenuOpen by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ScreenTitle("AI Model Settings", "Google Gemini via the official REST API")
        NovaCard {
            Text("API key", style = MaterialTheme.typography.titleMedium)
            Text(
                text = if (keySaved) "A key is saved (encrypted on this device)." else "No key saved yet.",
                style = MaterialTheme.typography.bodyMedium
            )
            OutlinedTextField(
                value = keyInput,
                onValueChange = { keyInput = it },
                label = { Text("Gemini API key") },
                visualTransformation = PasswordVisualTransformation(),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = {
                    vm.repository.keyStore.saveApiKey(keyInput.trim())
                    keySaved = vm.geminiConfigured()
                    keyInput = ""
                    testState = if (keySaved) "Key saved." else "Key field was empty — nothing saved."
                }) { Text("Save key") }
                OutlinedButton(onClick = {
                    vm.repository.keyStore.clearApiKey()
                    keySaved = false
                    testState = "Key removed from this device."
                }) { Text("Remove key") }
            }
            Text(
                text = "Get a key at aistudio.google.com/apikey. Personal-prototype use: your key stays on this device, encrypted. For a public release, route requests through your own backend instead of shipping any shared key.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                text = "API usage may incur charges or hit free-tier quotas, depending on your Google account.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        NovaCard {
            Text("Model", style = MaterialTheme.typography.titleMedium)
            ExposedDropdownMenuBox(
                expanded = modelMenuOpen,
                onExpandedChange = { modelMenuOpen = it }
            ) {
                OutlinedTextField(
                    value = settings.geminiModel,
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("Gemini model") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = modelMenuOpen) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .menuAnchor()
                )
                androidx.compose.material3.ExposedDropdownMenu(
                    expanded = modelMenuOpen,
                    onDismissRequest = { modelMenuOpen = false }
                ) {
                    GeminiModels.ALL.forEach { model ->
                        DropdownMenuItem(
                            text = { Text(model) },
                            onClick = {
                                vm.updateSettings { it.copy(geminiModel = model) }
                                modelMenuOpen = false
                            }
                        )
                    }
                }
            }
            SettingRow("Streaming responses", "Text appears as it is generated") {
                Switch(
                    checked = settings.streamingEnabled,
                    onCheckedChange = { vm.updateSettings { s -> s.copy(streamingEnabled = it) } }
                )
            }
            Text("Temperature: ${"%.1f".format(settings.temperature)}")
            Slider(
                value = settings.temperature,
                onValueChange = { vm.updateSettings { s -> s.copy(temperature = it) } },
                valueRange = 0f..1.5f
            )
            Text("Max output tokens: ${settings.maxOutputTokens}")
            Slider(
                value = settings.maxOutputTokens.toFloat(),
                onValueChange = { vm.updateSettings { s -> s.copy(maxOutputTokens = it.toInt()) } },
                valueRange = 128f..4096f,
                steps = 30
            )
            Button(
                onClick = {
                    val key = vm.repository.keyStore.getApiKey()
                    if (key.isNullOrBlank()) {
                        testState = "No key saved — save one first."
                        return@Button
                    }
                    testing = true
                    testState = "Testing…"
                    scope.launch {
                        testState = try {
                            val reply = vm.repository.gemini.testConnection(key, settings.geminiModel)
                            "Connected. Model replied: \"$reply\""
                        } catch (e: Exception) {
                            "Failed: ${e.message}"
                        }
                        testing = false
                    }
                },
                enabled = !testing,
                modifier = Modifier.fillMaxWidth()
            ) { Text(if (testing) "Testing…" else "Test connection") }
            if (testState != null) {
                Text(testState!!, style = MaterialTheme.typography.bodyMedium)
            }
        }

        NovaCard {
            Text("Assistant identity", style = MaterialTheme.typography.titleMedium)
            var name by remember(settings.displayName) { mutableStateOf(settings.displayName) }
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("How NOVA addresses you") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Button(onClick = { vm.updateSettings { it.copy(displayName = name.ifBlank { "Sir" }) } }) {
                Text("Save")
            }
            SettingRow("Conversation memory", "Lets NOVA use your saved preference in prompts") {
                Switch(
                    checked = settings.memoryEnabled,
                    onCheckedChange = { vm.updateSettings { s -> s.copy(memoryEnabled = it) } }
                )
            }
            if (settings.preferredStyle.isNotBlank()) {
                Text("Remembered preference: ${settings.preferredStyle}", style = MaterialTheme.typography.bodySmall)
                OutlinedButton(onClick = { vm.updateSettings { it.copy(preferredStyle = "") } }) {
                    Text("Forget preference")
                }
            }
        }
    }
}
