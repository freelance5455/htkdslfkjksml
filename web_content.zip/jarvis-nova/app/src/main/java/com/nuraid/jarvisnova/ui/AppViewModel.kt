package com.nuraid.jarvisnova.ui

import android.app.Application
import android.content.Context
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.nuraid.jarvisnova.JarvisNovaApp
import com.nuraid.jarvisnova.data.GeminiException
import com.nuraid.jarvisnova.data.GeminiImage
import com.nuraid.jarvisnova.data.GeminiTurn
import com.nuraid.jarvisnova.data.NovaSettings
import com.nuraid.jarvisnova.data.Repository
import com.nuraid.jarvisnova.data.db.Conversation
import com.nuraid.jarvisnova.data.db.Message
import com.nuraid.jarvisnova.data.db.Note
import com.nuraid.jarvisnova.data.db.Shortcut
import com.nuraid.jarvisnova.data.db.TaskItem
import com.nuraid.jarvisnova.domain.CommandRouter
import com.nuraid.jarvisnova.util.Intents
import com.nuraid.jarvisnova.voice.VoiceManager
import com.nuraid.jarvisnova.work.ReminderWorker
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/**
 * Single shared ViewModel for the whole app. Keeps screens thin and
 * guarantees the chat, voice, focus timer and command router all act on
 * the same state.
 */
@OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
class AppViewModel(application: Application) : AndroidViewModel(application) {

    private val app: JarvisNovaApp = application as JarvisNovaApp
    val repository: Repository = app.repository
    val voice: VoiceManager = VoiceManager(application)

    // --- Settings ---------------------------------------------------------
    val settings: StateFlow<NovaSettings> = repository.preferences.settings
        .stateIn(viewModelScope, SharingStarted.Eagerly, NovaSettings())

    fun updateSettings(transform: (NovaSettings) -> NovaSettings) {
        viewModelScope.launch {
            repository.preferences.update(transform)
            val s = settings.value
            voice.applySettings(s.ttsVoiceName, s.ttsPitch, s.ttsRate)
        }
    }

    // --- Data flows ---------------------------------------------------------
    val conversations: StateFlow<List<Conversation>> = repository.activeConversations
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val archivedConversations: StateFlow<List<Conversation>> = repository.archivedConversations
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val notes: StateFlow<List<Note>> = repository.notes
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val tasks: StateFlow<List<TaskItem>> = repository.tasks
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val shortcuts: StateFlow<List<Shortcut>> = repository.shortcuts
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    fun searchConversations(query: String): Flow<List<Conversation>> =
        repository.searchConversations(query)

    // --- Chat state -----------------------------------------------------------
    private val _currentConversationId = MutableStateFlow<Long?>(null)
    val currentConversationId: StateFlow<Long?> = _currentConversationId.asStateFlow()

    val currentMessages: StateFlow<List<Message>> = _currentConversationId
        .flatMapLatest { id -> if (id == null) flowOf(emptyList()) else repository.messagesFor(id) }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    private val _isGenerating = MutableStateFlow(false)
    val isGenerating: StateFlow<Boolean> = _isGenerating.asStateFlow()

    private val _streamingText = MutableStateFlow("")
    val streamingText: StateFlow<String> = _streamingText.asStateFlow()

    private val _chatError = MutableStateFlow<String?>(null)
    val chatError: StateFlow<String?> = _chatError.asStateFlow()

    private val _statusMessage = MutableStateFlow("Systems ready.")
    val statusMessage: StateFlow<String> = _statusMessage.asStateFlow()

    private var generationJob: Job? = null
    private var lastUserText: String? = null
    private var activeSystemPrompt: String = DEFAULT_SYSTEM_PROMPT
    private var activeTemplateId: String? = null

    init {
        viewModelScope.launch {
            settings.collect { s -> voice.applySettings(s.ttsVoiceName, s.ttsPitch, s.ttsRate) }
        }
    }

    fun geminiConfigured(): Boolean = repository.keyStore.hasApiKey()

    suspend fun ensureConversation(): Long {
        _currentConversationId.value?.let { return it }
        val id = repository.createConversation(
            title = "New conversation",
            systemPrompt = activeSystemPrompt,
            templateId = activeTemplateId
        )
        _currentConversationId.value = id
        return id
    }

    fun selectConversation(conversation: Conversation) {
        _currentConversationId.value = conversation.id
        activeSystemPrompt = conversation.systemPrompt.ifBlank { DEFAULT_SYSTEM_PROMPT }
        activeTemplateId = conversation.templateId
        _chatError.value = null
    }

    fun startNewConversation(systemPrompt: String = DEFAULT_SYSTEM_PROMPT, templateId: String? = null, title: String = "New conversation") {
        activeSystemPrompt = systemPrompt
        activeTemplateId = templateId
        viewModelScope.launch {
            val id = repository.createConversation(title, systemPrompt, templateId)
            _currentConversationId.value = id
            _chatError.value = null
            _streamingText.value = ""
        }
    }

    /** Start a template conversation and optionally fire its first prompt — atomically. */
    fun startFromTemplate(systemPrompt: String, templateId: String?, title: String, firstPrompt: String?) {
        activeSystemPrompt = systemPrompt
        activeTemplateId = templateId
        viewModelScope.launch {
            val id = repository.createConversation(title, systemPrompt, templateId)
            _currentConversationId.value = id
            _chatError.value = null
            _streamingText.value = ""
            if (!firstPrompt.isNullOrBlank()) sendChat(firstPrompt)
        }
    }

    fun clearChatError() { _chatError.value = null }

    /** Send a chat message to Gemini (or show exactly why it can't run). */
    fun sendChat(rawText: String, image: GeminiImage? = null) {
        val text = rawText.trim()
        if (text.isBlank() || _isGenerating.value) return
        lastUserText = text
        _chatError.value = null

        val apiKey = repository.keyStore.getApiKey()
        if (apiKey.isNullOrBlank()) {
            _chatError.value = GeminiException.NoKey().message
            return
        }
        val s = settings.value

        generationJob = viewModelScope.launch {
            val conversationId = ensureConversation()
            repository.addMessage(conversationId, "user", text)
            // Auto-title from the first user message.
            repository.getConversation(conversationId)?.let { conv ->
                if (conv.title == "New conversation") {
                    repository.renameConversation(conv, text.take(42))
                }
            }
            _isGenerating.value = true
            _streamingText.value = ""
            try {
                val history = repository.historyFor(conversationId)
                    .filter { it.role == "user" || it.role == "model" }
                    .takeLast(MAX_HISTORY_TURNS)
                    .map { GeminiTurn(it.role, it.text) }
                val system = buildString {
                    append(activeSystemPrompt)
                    if (s.memoryEnabled && s.preferredStyle.isNotBlank()) {
                        append("\nUser preference: ").append(s.preferredStyle)
                    }
                }
                val finalText: String
                if (s.streamingEnabled && image == null) {
                    var latest = ""
                    repository.gemini.generateStreaming(
                        apiKey, s.geminiModel, system, history, s.temperature, s.maxOutputTokens
                    ).collect { cumulative ->
                        latest = cumulative
                        _streamingText.value = cumulative
                    }
                    finalText = latest
                } else {
                    finalText = repository.gemini.generate(
                        apiKey, s.geminiModel, system, history, s.temperature, s.maxOutputTokens, image
                    )
                    _streamingText.value = finalText
                }
                if (finalText.isNotBlank()) {
                    repository.addMessage(conversationId, "model", finalText)
                    speakIfEnabled(finalText)
                }
            } catch (e: kotlinx.coroutines.CancellationException) {
                val partial = _streamingText.value
                if (partial.isNotBlank()) repository.addMessage(conversationId, "model", partial)
                _statusMessage.value = "Response cancelled."
            } catch (e: GeminiException) {
                _chatError.value = e.message
            } catch (e: Exception) {
                _chatError.value = "Unexpected error: ${e.message ?: "unknown"}"
            } finally {
                _isGenerating.value = false
                _streamingText.value = ""
            }
        }
    }

    fun cancelGeneration() {
        generationJob?.cancel()
        generationJob = null
    }

    fun retryLast() {
        val last = lastUserText ?: return
        // Remove the duplicated user message attempt is handled by simply
        // re-sending as a new turn; history stays coherent for Gemini.
        sendChat(last)
    }

    // --- Voice helpers ---------------------------------------------------------
    fun speakIfEnabled(text: String) {
        val s = settings.value
        voice.speak(text, enabled = s.autoSpeak, volume = s.ttsVolume)
    }

    fun speakAlways(text: String) {
        val s = settings.value
        voice.speak(text, enabled = true, volume = s.ttsVolume)
    }

    fun stopSpeaking() = voice.stopSpeaking()

    // --- Command router execution ------------------------------------------------
    /**
     * Routes [input] through [CommandRouter] and performs the local parts.
     * Returns a human reply describing what happened/will happen.
     * AndroidAction / ExternalConfirm results are returned via [onAction]
     * so the calling screen can fire the intent or show a confirmation.
     */
    fun handleCommand(
        input: String,
        context: Context,
        onAndroidAction: (CommandRouter.CommandResult.AndroidAction) -> Unit = {},
        onExternalConfirm: (CommandRouter.CommandResult.ExternalConfirm) -> Unit = {}
    ): String {
        return when (val result = CommandRouter.route(input)) {
            is CommandRouter.CommandResult.LocalHandled -> {
                performLocalAction(result.action, context)
                result.reply
            }
            is CommandRouter.CommandResult.AiRequest -> {
                sendChat(result.prompt)
                "Sent to Gemini."
            }
            is CommandRouter.CommandResult.AndroidAction -> {
                onAndroidAction(result)
                result.description
            }
            is CommandRouter.CommandResult.ExternalConfirm -> {
                onExternalConfirm(result)
                "Confirmation needed: ${result.description}"
            }
            is CommandRouter.CommandResult.Unsupported -> result.reason
        }
    }

    private fun performLocalAction(action: CommandRouter.LocalAction, context: Context) {
        when (action) {
            is CommandRouter.LocalAction.StartFocus -> startFocus(action.minutes, context)
            is CommandRouter.LocalAction.SaveNote -> viewModelScope.launch { repository.addNote(action.text) }
            is CommandRouter.LocalAction.ReadAloud -> {
                val text = action.text ?: currentMessages.value.lastOrNull { it.role == "model" }?.text
                if (text != null) speakAlways(text) else _statusMessage.value = "Nothing to read yet."
            }
            CommandRouter.LocalAction.StopSpeaking -> stopSpeaking()
            CommandRouter.LocalAction.CancelCurrent -> { cancelGeneration(); stopSpeaking(); stopFocus() }
            is CommandRouter.LocalAction.SetDarkMode ->
                updateSettings { it.copy(darkTheme = action.enabled) }
            is CommandRouter.LocalAction.RememberPreference ->
                updateSettings { it.copy(preferredStyle = action.preference, memoryEnabled = true) }
            CommandRouter.LocalAction.ShowRecentTasks -> _statusMessage.value = "Opening tasks."
            CommandRouter.LocalAction.OpenNotes -> _statusMessage.value = "Opening notes."
        }
    }

    /** Executes a confirmed AndroidAction (called by the UI after any permission/confirm step). */
    fun executeAndroidAction(action: CommandRouter.CommandResult.AndroidAction, context: Context) {
        when (action.intent) {
            CommandRouter.IntentKind.PLAY_FOCUS_PLAYLIST -> Intents.playFocusPlaylist(context)
            CommandRouter.IntentKind.YOUTUBE_SEARCH -> Intents.youtubeSearch(context, action.payload)
            CommandRouter.IntentKind.WEB_SEARCH -> Intents.webSearch(context, action.payload)
            CommandRouter.IntentKind.OPEN_URL -> Intents.openUrl(context, action.payload)
            CommandRouter.IntentKind.OPEN_APP_SETTINGS -> Intents.openAppSettings(context)
            CommandRouter.IntentKind.OPEN_NOTES -> _statusMessage.value = "Opening notes."
            CommandRouter.IntentKind.OPEN_TASKS -> _statusMessage.value = "Opening tasks."
            CommandRouter.IntentKind.START_FOCUS_TIMER ->
                startFocus(action.payload.toIntOrNull() ?: 25, context)
            CommandRouter.IntentKind.NONE -> Unit
        }
    }

    // --- Focus timer ---------------------------------------------------------------
    private val _focusTotalSeconds = MutableStateFlow(0)
    val focusTotalSeconds: StateFlow<Int> = _focusTotalSeconds.asStateFlow()
    private val _focusRemainingSeconds = MutableStateFlow(0)
    val focusRemainingSeconds: StateFlow<Int> = _focusRemainingSeconds.asStateFlow()
    private val _focusRunning = MutableStateFlow(false)
    val focusRunning: StateFlow<Boolean> = _focusRunning.asStateFlow()
    private var focusJob: Job? = null

    fun startFocus(minutes: Int, context: Context) {
        focusJob?.cancel()
        val total = minutes.coerceIn(1, 480) * 60
        _focusTotalSeconds.value = total
        _focusRemainingSeconds.value = total
        _focusRunning.value = true
        _statusMessage.value = "Focus session started: $minutes minutes."
        focusJob = viewModelScope.launch {
            while (_focusRemainingSeconds.value > 0) {
                delay(1000)
                _focusRemainingSeconds.value -= 1
            }
            _focusRunning.value = false
            notifyFocusComplete(context, minutes)
        }
    }

    fun stopFocus() {
        focusJob?.cancel()
        focusJob = null
        _focusRunning.value = false
    }

    private fun notifyFocusComplete(context: Context, minutes: Int) {
        val notification = NotificationCompat.Builder(context, JarvisNovaApp.CHANNEL_FOCUS)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Focus session complete")
            .setContentText("Your $minutes-minute session has finished. Well done.")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .build()
        try {
            NotificationManagerCompat.from(context).notify(2001, notification)
        } catch (e: SecurityException) {
            // Notifications permission not granted — the in-app state still shows completion.
        }
        speakIfEnabled("Focus session complete.")
        _statusMessage.value = "Focus session complete."
    }

    // --- Notes / tasks / shortcuts passthroughs ---------------------------------------
    fun addNote(text: String) { viewModelScope.launch { repository.addNote(text) } }
    fun deleteNote(note: Note) { viewModelScope.launch { repository.deleteNote(note) } }
    fun togglePin(note: Note) { viewModelScope.launch { repository.updateNote(note.copy(pinned = !note.pinned)) } }

    fun addTask(title: String, remindAt: Long?, context: Context) {
        viewModelScope.launch {
            val id = repository.addTask(title, remindAt)
            if (remindAt != null) ReminderWorker.schedule(context, id, title, remindAt)
        }
    }
    fun toggleTask(task: TaskItem) { viewModelScope.launch { repository.updateTask(task.copy(done = !task.done)) } }
    fun deleteTask(task: TaskItem, context: Context) {
        viewModelScope.launch {
            repository.deleteTask(task)
            ReminderWorker.cancel(context, task.id)
        }
    }

    fun addShortcut(name: String, prompt: String, url: String?) {
        viewModelScope.launch { repository.addShortcut(name, prompt, url?.takeIf { it.isNotBlank() }) }
    }
    fun deleteShortcut(shortcut: Shortcut) { viewModelScope.launch { repository.deleteShortcut(shortcut) } }

    fun renameConversation(conversation: Conversation, newTitle: String) {
        viewModelScope.launch { repository.renameConversation(conversation, newTitle) }
    }
    fun archiveConversation(conversation: Conversation, archived: Boolean) {
        viewModelScope.launch { repository.setArchived(conversation, archived) }
    }
    fun favoriteConversation(conversation: Conversation, favorite: Boolean) {
        viewModelScope.launch { repository.setFavorite(conversation, favorite) }
    }
    fun deleteConversation(conversation: Conversation) {
        viewModelScope.launch {
            if (_currentConversationId.value == conversation.id) _currentConversationId.value = null
            repository.deleteConversation(conversation)
        }
    }
    fun deleteAllConversations() { viewModelScope.launch { repository.deleteAllConversations(); _currentConversationId.value = null } }

    fun wipeAllData() {
        viewModelScope.launch {
            repository.wipeAllData()
            _currentConversationId.value = null
            _statusMessage.value = "All local data cleared."
        }
    }

    override fun onCleared() {
        super.onCleared()
        voice.release()
    }

    companion object {
        const val DEFAULT_SYSTEM_PROMPT =
            "You are J.A.R.V.I.S. NOVA, a personal AI assistant with a calm, precise, professional manner. " +
            "Address the user respectfully, be concise unless asked for depth, use markdown when it helps, " +
            "and never claim to have performed an action you did not perform."
        private const val MAX_HISTORY_TURNS = 24
    }
}
