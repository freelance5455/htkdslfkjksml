package com.nuraid.jarvisnova.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.nuraid.jarvisnova.ui.AppViewModel
import com.nuraid.jarvisnova.ui.components.Reactor
import com.nuraid.jarvisnova.ui.theme.NovaColors
import kotlinx.coroutines.delay

/**
 * Boot / initialization: animated reactor + honest system-check lines
 * that reflect real state (key configured, voice engine, network), then
 * hands over to the Command Center.
 */
@Composable
fun BootScreen(vm: AppViewModel, onFinished: () -> Unit) {
    val settings by vm.settings.collectAsState()
    val ttsReady by vm.voice.ttsReady.collectAsState()
    var step by remember { mutableIntStateOf(0) }

    val checks = listOf(
        "Core systems" to "online",
        "Voice engine" to if (ttsReady) "ready" else "initializing",
        "Gemini link" to if (vm.geminiConfigured()) "key configured" else "no key — add one in AI Model Settings",
        "Local vault" to "encrypted storage ready",
        "Command router" to "armed"
    )

    LaunchedEffect(Unit) {
        val perStep = if (settings.reduceMotion || settings.lowPower) 120L else 420L
        while (step < checks.size) {
            delay(perStep)
            step++
        }
        delay(perStep)
        onFinished()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(NovaColors.Navy)
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Reactor(
            level = 0.4f,
            active = true,
            reduceMotion = settings.reduceMotion,
            lowPower = settings.lowPower
        )
        Text(
            text = "J.A.R.V.I.S. NOVA",
            style = MaterialTheme.typography.headlineMedium,
            color = NovaColors.Cyan,
            modifier = Modifier.padding(top = 24.dp)
        )
        Text(
            text = "Initializing personal intelligence systems…",
            style = MaterialTheme.typography.bodyMedium,
            color = NovaColors.TextMuted,
            modifier = Modifier.padding(bottom = 24.dp)
        )
        Column(
            modifier = Modifier.padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            checks.take(step).forEach { (name, state) ->
                Text(
                    text = "▸ $name — $state",
                    style = MaterialTheme.typography.bodyMedium,
                    color = NovaColors.TextPrimary
                )
            }
        }
    }
}
