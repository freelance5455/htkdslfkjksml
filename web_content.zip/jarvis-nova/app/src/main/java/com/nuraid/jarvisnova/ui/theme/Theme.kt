package com.nuraid.jarvisnova.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object NovaColors {
    val Navy = Color(0xFF04070D)
    val Panel = Color(0xFF0A1622)
    val PanelLight = Color(0xFF10202F)
    val Cyan = Color(0xFF22D3EE)
    val ElectricBlue = Color(0xFF38BDF8)
    val Violet = Color(0xFFA78BFA)
    val TextPrimary = Color(0xFFE6F4FA)
    val TextMuted = Color(0xFF8FB3C7)
    val Danger = Color(0xFFF87171)
    val Success = Color(0xFF4ADE80)

    fun accentFor(name: String): Color = when (name) {
        "Violet" -> Violet
        "Blue" -> ElectricBlue
        "Emerald" -> Color(0xFF34D399)
        "Amber" -> Color(0xFFFBBF24)
        else -> Cyan
    }
    val ACCENTS = listOf("Cyan", "Blue", "Violet", "Emerald", "Amber")
}

private fun darkScheme(accent: Color) = darkColorScheme(
    primary = accent,
    secondary = NovaColors.ElectricBlue,
    tertiary = NovaColors.Violet,
    background = NovaColors.Navy,
    surface = NovaColors.Panel,
    surfaceVariant = NovaColors.PanelLight,
    onBackground = NovaColors.TextPrimary,
    onSurface = NovaColors.TextPrimary,
    onSurfaceVariant = NovaColors.TextMuted,
    error = NovaColors.Danger
)

private fun lightScheme(accent: Color) = lightColorScheme(
    primary = accent,
    secondary = NovaColors.ElectricBlue,
    tertiary = NovaColors.Violet
)

@Composable
fun JarvisNovaTheme(
    darkTheme: Boolean = true,
    accentName: String = "Cyan",
    content: @Composable () -> Unit
) {
    val accent = NovaColors.accentFor(accentName)
    MaterialTheme(
        colorScheme = if (darkTheme) darkScheme(accent) else lightScheme(accent),
        content = content
    )
}
