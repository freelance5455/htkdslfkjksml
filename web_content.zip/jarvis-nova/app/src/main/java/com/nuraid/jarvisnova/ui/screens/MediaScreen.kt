package com.nuraid.jarvisnova.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.nuraid.jarvisnova.ui.AppViewModel
import com.nuraid.jarvisnova.ui.components.EmptyState
import com.nuraid.jarvisnova.ui.components.NovaCard
import com.nuraid.jarvisnova.ui.components.ScreenTitle
import com.nuraid.jarvisnova.util.Intents

/**
 * Media launcher. Everything here opens official apps/pages via
 * intents — playback itself happens in YouTube/your music app, under
 * its own login, subscription and licensing. Favorites are persisted
 * as shortcut rows with a URL.
 */
@Composable
fun MediaScreen(vm: AppViewModel, navigate: (String) -> Unit) {
    val context = LocalContext.current
    val shortcuts by vm.shortcuts.collectAsState()
    val favorites = shortcuts.filter { !it.url.isNullOrBlank() && it.prompt.isBlank() }
    var query by remember { mutableStateOf("") }
    var favTitle by remember { mutableStateOf("") }
    var favUrl by remember { mutableStateOf("") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            ScreenTitle("Media Launcher", "Search opens YouTube or the web. NOVA doesn't play or download media itself.")
        }
        item {
            NovaCard {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    label = { Text("Search music, videos, tutorials…") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { if (query.isNotBlank()) Intents.youtubeSearch(context, query) }) {
                        Text("YouTube")
                    }
                    OutlinedButton(onClick = { if (query.isNotBlank()) Intents.webSearch(context, query) }) {
                        Text("Web")
                    }
                    OutlinedButton(onClick = { Intents.playFocusPlaylist(context) }) {
                        Text("Focus playlist")
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TextButton(onClick = { Intents.youtubeSearch(context, "Blender tutorial") }) { Text("Blender tutorials") }
                    TextButton(onClick = { Intents.youtubeSearch(context, "lofi beats to focus") }) { Text("Lo-fi focus") }
                    TextButton(onClick = { Intents.youtubeSearch(context, "cinematic music playlist") }) { Text("Cinematic") }
                }
            }
        }
        item {
            NovaCard {
                Text("Save a favorite shortcut", style = androidx.compose.material3.MaterialTheme.typography.titleMedium)
                OutlinedTextField(
                    value = favTitle,
                    onValueChange = { favTitle = it },
                    label = { Text("Title") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = favUrl,
                    onValueChange = { favUrl = it },
                    label = { Text("URL (https://…)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Button(onClick = {
                    if (favTitle.isNotBlank() && favUrl.startsWith("http")) {
                        vm.addShortcut(favTitle, "", favUrl)
                        favTitle = ""
                        favUrl = ""
                    }
                }) { Text("Save favorite") }
            }
        }
        item {
            Text("Favorites", style = androidx.compose.material3.MaterialTheme.typography.titleMedium)
        }
        if (favorites.isEmpty()) {
            item { EmptyState("No favorites yet. Save a YouTube playlist or channel above.") }
        } else {
            items(favorites) { fav ->
                NovaCard {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(fav.name)
                        Row {
                            TextButton(onClick = { Intents.openUrl(context, fav.url!!) }) { Text("Open") }
                            TextButton(onClick = { vm.deleteShortcut(fav) }) { Text("Delete") }
                        }
                    }
                }
            }
        }
        item {
            Text(
                text = "Playback status from other apps can't be read reliably without their own integrations, so NOVA doesn't guess it.",
                style = androidx.compose.material3.MaterialTheme.typography.bodySmall,
                color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
