package com.nuraid.jarvisnova.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.nuraid.jarvisnova.data.db.Conversation
import com.nuraid.jarvisnova.ui.AppViewModel
import com.nuraid.jarvisnova.ui.Routes
import com.nuraid.jarvisnova.ui.components.EmptyState
import com.nuraid.jarvisnova.ui.components.NovaCard
import com.nuraid.jarvisnova.ui.components.ScreenTitle
import com.nuraid.jarvisnova.util.Intents
import kotlinx.coroutines.launch

/**
 * Conversation history: search, open, rename, favorite, archive,
 * export (share intent), delete (with confirmation).
 */
@Composable
fun HistoryScreen(vm: AppViewModel, navigate: (String) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var query by remember { mutableStateOf("") }
    var showArchived by remember { mutableStateOf(false) }

    val active by vm.conversations.collectAsState()
    val archived by vm.archivedConversations.collectAsState()
    val searchResults by vm.searchConversations(query).collectAsState(initial = emptyList())

    val shown: List<Conversation> = when {
        query.isNotBlank() -> searchResults.filter { it.archived == showArchived }
        showArchived -> archived
        else -> active
    }

    var renameTarget by remember { mutableStateOf<Conversation?>(null) }
    var renameText by remember { mutableStateOf("") }
    var deleteTarget by remember { mutableStateOf<Conversation?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        ScreenTitle("Conversation History", "${active.size} active · ${archived.size} archived")
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            label = { Text("Search by title…") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
        ) {
            Text("Show archived")
            Switch(checked = showArchived, onCheckedChange = { showArchived = it })
        }
        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (shown.isEmpty()) {
                item { EmptyState("Nothing here yet. Start a chat and it will appear in this list.") }
            }
            items(shown) { conversation ->
                NovaCard {
                    Text(
                        text = (if (conversation.favorite) "★ " else "") + conversation.title,
                        style = androidx.compose.material3.MaterialTheme.typography.titleMedium
                    )
                    if (!conversation.templateId.isNullOrBlank()) {
                        Text("Template: ${conversation.templateId}", style = androidx.compose.material3.MaterialTheme.typography.bodySmall)
                    }
                    Row {
                        TextButton(onClick = {
                            vm.selectConversation(conversation)
                            navigate(Routes.CHAT)
                        }) { Text("Open") }
                        TextButton(onClick = {
                            renameTarget = conversation
                            renameText = conversation.title
                        }) { Text("Rename") }
                        TextButton(onClick = {
                            scope.launch {
                                val exported = vm.repository.exportConversation(conversation)
                                Intents.shareText(context, exported, "Export conversation")
                            }
                        }) { Text("Export") }
                    }
                    Row {
                        TextButton(onClick = {
                            vm.favoriteConversation(conversation, !conversation.favorite)
                        }) { Text(if (conversation.favorite) "Unfavorite" else "Favorite") }
                        TextButton(onClick = {
                            vm.archiveConversation(conversation, !conversation.archived)
                        }) { Text(if (conversation.archived) "Unarchive" else "Archive") }
                        TextButton(onClick = { deleteTarget = conversation }) { Text("Delete") }
                    }
                }
            }
        }
    }

    renameTarget?.let { target ->
        AlertDialog(
            onDismissRequest = { renameTarget = null },
            title = { Text("Rename conversation") },
            text = {
                OutlinedTextField(
                    value = renameText,
                    onValueChange = { renameText = it },
                    singleLine = true,
                    label = { Text("Title") }
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    if (renameText.isNotBlank()) vm.renameConversation(target, renameText.trim())
                    renameTarget = null
                }) { Text("Save") }
            },
            dismissButton = {
                TextButton(onClick = { renameTarget = null }) { Text("Cancel") }
            }
        )
    }
    deleteTarget?.let { target ->
        AlertDialog(
            onDismissRequest = { deleteTarget = null },
            title = { Text("Delete conversation?") },
            text = { Text("\"${target.title}\" and all its messages will be permanently deleted.") },
            confirmButton = {
                TextButton(onClick = {
                    vm.deleteConversation(target)
                    deleteTarget = null
                }) { Text("Delete") }
            },
            dismissButton = {
                TextButton(onClick = { deleteTarget = null }) { Text("Cancel") }
            }
        )
    }
}
