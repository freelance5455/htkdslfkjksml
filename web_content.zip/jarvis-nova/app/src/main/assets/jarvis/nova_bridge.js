// J.A.R.V.I.S. NOVA — native bridge shim.
// Injected into the preserved HUD by the Android app after page load.
// It does NOT modify the original index.html. Everything here is opt-in:
// the HUD keeps working 100% in a plain browser where AndroidNova is absent.
(function () {
  'use strict';
  var native = window.AndroidNova || null;

  // Public helpers the HUD (or future HUD updates) can call safely anywhere.
  window.NovaNative = {
    available: !!native,
    isNative: function () { return !!(native && native.isNative()); },
    speak: function (text) { if (native) native.speak(String(text || '')); },
    stopSpeaking: function () { if (native) native.stopSpeaking(); },
    listen: function () { if (native) native.listen(); },
    shareText: function (text) { if (native) native.shareText(String(text || '')); },
    copy: function (text) { if (native) native.copyToClipboard(String(text || '')); },
    openUrl: function (url) { if (native) native.openUrl(String(url || '')); },
    notify: function (title, body) { if (native) native.notify(String(title || ''), String(body || '')); },
    haptic: function () { if (native) native.haptic(); },
    geminiConfigured: function () { return native ? !!native.geminiConfigured() : false; }
  };

  // Native speech results land here. If the HUD defines its own handler
  // (window.__novaHandleTranscript) we forward to it; otherwise we drop the
  // transcript into the command input, if present, without submitting it.
  window.__novaOnListenResult = function (text) {
    if (typeof window.__novaHandleTranscript === 'function') {
      window.__novaHandleTranscript(text);
      return;
    }
    var input = document.getElementById('cmdInput') || document.getElementById('chatInput');
    if (input) {
      input.value = text;
      input.dispatchEvent(new Event('input', { bubbles: true }));
      input.focus();
    }
  };

  if (native) {
    document.documentElement.classList.add('nova-native');
    console.log('[NOVA] Native bridge connected.');
  }
})();
