# J.A.R.V.I.S. NOVA release rules
-keep class com.nuraid.jarvisnova.data.db.** { *; }
-keepclassmembers class * extends androidx.room.RoomDatabase { *; }
# JavascriptInterface methods must survive minification (WebView bridge).
-keepclassmembers class com.nuraid.jarvisnova.web.JarvisBridge {
    @android.webkit.JavascriptInterface <methods>;
}
-keepattributes *Annotation*, InnerClasses
-dontnote kotlinx.serialization.**
