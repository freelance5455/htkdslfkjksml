(()=>{'use strict';
const $=i=>document.getElementById(i);
const A=3.5,R=A/.866,Y0=A-.55,SEG=10,NSEG=24,COL=[0x00f3ff,0xff007f];
const SK=[{n:'CORE',c:0,g:()=>new THREE.OctahedronGeometry(.5)},{n:'CUBE',c:60,g:()=>new THREE.BoxGeometry(.7,.7,.7)},{n:'SPIKE',c:150,g:()=>new THREE.TetrahedronGeometry(.65)},{n:'NOVA',c:300,g:()=>new THREE.IcosahedronGeometry(.55)},{n:'HALO',c:600,g:()=>new THREE.TorusGeometry(.4,.14,6,12)}];
// ---------- save ----------
let save={hi:0,shards:0,own:[0],skin:0};
try{Object.assign(save,JSON.parse(localStorage.getItem('ngs3')||'{}'))}catch(e){}
const persist=()=>{try{localStorage.setItem('ngs3',JSON.stringify(save))}catch(e){}};
// ---------- audio (procedural) ----------
let AC,MG;
function initAudio(){if(!AC){try{AC=new(window.AudioContext||window.webkitAudioContext)();MG=AC.createGain();MG.gain.value=.5;MG.connect(AC.destination)}catch(e){}}if(AC&&AC.state==='suspended')AC.resume()}
function tone(f,d,t,v,to,dl){if(!AC)return;const o=AC.createOscillator(),g=AC.createGain(),s=AC.currentTime+(dl||0);o.type=t||'sine';o.frequency.setValueAtTime(f,s);if(to)o.frequency.exponentialRampToValueAtTime(to,s+d);g.gain.setValueAtTime(v||.15,s);g.gain.exponentialRampToValueAtTime(.001,s+d);o.connect(g);g.connect(MG);o.start(s);o.stop(s+d+.03)}
function noise(d,v){if(!AC)return;const n=AC.sampleRate*d|0,b=AC.createBuffer(1,n,AC.sampleRate),a=b.getChannelData(0);for(let i=0;i<n;i++)a[i]=(Math.random()*2-1)*(1-i/n);const s=AC.createBufferSource(),g=AC.createGain();s.buffer=b;g.gain.value=v;s.connect(g);g.connect(MG);s.start()}
const sfx={chime(){[523,659,784,1047,1568].forEach((f,i)=>tone(f,.55,'triangle',.14,0,i*.09))},flip(){tone(300,.16,'sawtooth',.07,900)},col(){tone(900,.09,'square',.05,1500)},gate(){tone(880,.1,'triangle',.14);tone(1320,.16,'triangle',.12,0,.07)},dodge(){tone(660,.05,'sine',.07)},shard(){tone(1500,.09,'sine',.1,2300)},od(){tone(200,.9,'sawtooth',.12,1800)},shatter(){noise(.25,.25);tone(1800,.2,'square',.07,300)},crash(){tone(140,.9,'sawtooth',.35,28);tone(60,1,'sine',.5,25);noise(.5,.4)}};
const vib=ms=>{try{navigator.vibrate&&navigator.vibrate(ms)}catch(e){}};
// ---------- three setup ----------
const cv=$('c'),rd=new THREE.WebGLRenderer({canvas:cv,antialias:false,powerPreference:'high-performance'});
rd.setPixelRatio(Math.min(window.devicePixelRatio||1,1.5));
const scene=new THREE.Scene();scene.background=new THREE.Color(0x05060f);scene.fog=new THREE.Fog(0x05060f,30,230);
const cam=new THREE.PerspectiveCamera(78,1,.1,300);
function rs(){rd.setSize(innerWidth,innerHeight,false);cam.aspect=innerWidth/innerHeight;cam.updateProjectionMatrix()}
addEventListener('resize',rs);rs();
// ---------- path ----------
const sm=(d,a,b)=>{const t=Math.min(1,Math.max(0,(d-a)/(b-a)));return t*t*(3-2*t)};
const PX=d=>7*sm(d,450,900)*Math.sin(d*.011)+4*sm(d,1500,1900)*Math.sin(d*.023);
const PY=d=>4*sm(d,1500,1900)*Math.sin(d*.017);
// ---------- tunnel segments ----------
const hg=new THREE.CylinderGeometry(R,R,SEG+.4,6,1,true);hg.rotateX(Math.PI/2);hg.rotateZ(Math.PI/6);
const eg=new THREE.EdgesGeometry(hg),faceM=new THREE.MeshBasicMaterial({color:0x0a2a3a,transparent:true,opacity:.35,side:THREE.BackSide,depthWrite:false});
const segs=[];let maxK=0;
for(let i=0;i<NSEG;i++){const g=new THREE.Group(),l=new THREE.LineSegments(eg,new THREE.LineBasicMaterial({color:COL[0]}));g.add(new THREE.Mesh(hg,faceM),l);g.rotation.order='YXZ';scene.add(g);segs.push({g,l,k:i})}
function placeSeg(s,k){const d=k*SEG+SEG/2;s.k=k;s.g.position.set(PX(d),PY(d),-d);s.g.rotation.y=-Math.atan((PX(d+1)-PX(d-1))/2);s.g.rotation.x=Math.atan((PY(d+1)-PY(d-1))/2);s.l.material.color.setHex(d<500?0x00f3ff:d<1500?0xb44bff:(k%2?0x00f3ff:0xff007f))}
// ---------- player ----------
const P=new THREE.Group();scene.add(P);
const bodyM=new THREE.MeshBasicMaterial({color:COL[0]}),auraM=new THREE.MeshBasicMaterial({color:COL[0],transparent:true,opacity:.28,blending:THREE.AdditiveBlending,depthWrite:false});
const aura=new THREE.Mesh(new THREE.SphereGeometry(.95,8,6),auraM);P.add(aura);let body;
function setSkin(){if(body)P.remove(body);const g=SK[save.skin].g();body=new THREE.Mesh(g,bodyM);body.add(new THREE.LineSegments(new THREE.EdgesGeometry(g),new THREE.LineBasicMaterial({color:0xffffff})));P.add(body)}
// ---------- obstacles & shards ----------
const slabG=new THREE.BoxGeometry(R*.9,2.6,.7),slabE=new THREE.EdgesGeometry(slabG),edgeM=new THREE.LineBasicMaterial({color:0xffffff});
const slabM=COL.map(c=>new THREE.MeshBasicMaterial({color:c,transparent:true,opacity:.7}));
const obs=[];for(let i=0;i<14;i++){const g=new THREE.Group(),m=[0,1].map(s=>{const x=new THREE.Mesh(slabG,slabM[0]);x.add(new THREE.LineSegments(slabE,edgeM));x.position.y=(s?1:-1)*(A-1.3);g.add(x);return x});g.rotation.order='YXZ';g.visible=false;scene.add(g);obs.push({g,m,on:false,d:0,sl:[null,null],done:false})}
const shG=new THREE.OctahedronGeometry(.45),shM=new THREE.MeshBasicMaterial({color:0xfff27a});
const shs=[];for(let i=0;i<16;i++){const m=new THREE.Mesh(shG,shM);m.visible=false;scene.add(m);shs.push({m,on:false,d:0,side:0})}
// ---------- particles ----------
const NP=420,pp=new Float32Array(NP*3).fill(-9999),pc=new Float32Array(NP*3),pv=new Float32Array(NP*3),pb=new Float32Array(NP*3),pl=new Float32Array(NP),pm=new Float32Array(NP);
const pg=new THREE.BufferGeometry();pg.setAttribute('position',new THREE.BufferAttribute(pp,3));pg.setAttribute('color',new THREE.BufferAttribute(pc,3));
const pts=new THREE.Points(pg,new THREE.PointsMaterial({size:.3,vertexColors:true,transparent:true,blending:THREE.AdditiveBlending,depthWrite:false}));pts.frustumCulled=false;scene.add(pts);
let pi=0;const tc=new THREE.Color();
function emit(x,y,z,vx,vy,vz,life,hex){const i=pi,j=i*3;pi=(pi+1)%NP;pp[j]=x;pp[j+1]=y;pp[j+2]=z;pv[j]=vx;pv[j+1]=vy;pv[j+2]=vz;pl[i]=pm[i]=life;tc.setHex(hex);pb[j]=tc.r;pb[j+1]=tc.g;pb[j+2]=tc.b}
function burst(x,y,z,n,hex,sp){for(let k=0;k<n;k++){const th=Math.random()*6.283,u=Math.random()*2-1,s=Math.sqrt(1-u*u),v=sp*(.3+Math.random());emit(x,y,z,s*Math.cos(th)*v,u*v,s*Math.sin(th)*v,.5+Math.random()*.6,hex)}}
function updP(dt){for(let i=0;i<NP;i++){if(pl[i]>0){const j=i*3,f=pl[i]-dt;pl[i]=f;if(f<=0){pp[j+1]=-9999;pc[j]=pc[j+1]=pc[j+2]=0;continue}const k=f/pm[i];pp[j]+=pv[j]*dt;pp[j+1]+=pv[j+1]*dt;pp[j+2]+=pv[j+2]*dt;pc[j]=pb[j]*k;pc[j+1]=pb[j+1]*k;pc[j+2]=pb[j+2]*k}}pg.attributes.position.needsUpdate=true;pg.attributes.color.needsUpdate=true}
// ---------- state ----------
let seed=1;const rnd=()=>{seed|=0;seed=seed+0x6D2B79F5|0;let t=Math.imul(seed^seed>>>15,1|seed);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296};
let st='menu',pd=0,spd=16,ang=0,tgt=0,col=0,score=0,combo=0,mult=1,meter=0,od=0,shRun=0,shake=0,nextObs=90,py=-Y0,fovT=78;
function applyCol(){bodyM.color.setHex(COL[col]);auraM.color.setHex(COL[col]);const b=$('colbtn'),c='#'+COL[col].toString(16).padStart(6,'0');b.style.borderColor=c;b.style.boxShadow='0 0 18px '+c;b.style.background=col?'rgba(255,0,127,.2)':'rgba(0,243,255,.12)'}
function resetWorld(){pd=0;maxK=NSEG-1;segs.forEach((s,i)=>placeSeg(s,i));obs.forEach(o=>{o.on=false;o.g.visible=false});shs.forEach(s=>{s.on=false;s.m.visible=false});ang=0;tgt=0;col=0;score=0;combo=0;mult=1;meter=0;od=0;shRun=0;shake=0;nextObs=90;cv.classList.remove('od');applyCol()}
function startGame(){seed=(Date.now()&0x7fffffff)||7;resetWorld();st='play';$('start').classList.add('hide');$('over').classList.add('hide');$('hud').classList.remove('hide');P.visible=true}
function flip(){if(st!=='play')return;tgt=1-tgt;sfx.flip();vib(8);const x=PX(pd),y=PY(pd)+py;burst(x,y,-pd,14,COL[col],6)}
function toggleCol(){if(st!=='play')return;col=1-col;applyCol();sfx.col();vib(6)}
function spawnObs(){const o=obs.find(x=>!x.on);if(!o){nextObs+=20;return}
 const d=nextObs,r=rnd(),ty=pd<150?0:r<.45?0:r<.75?1:2,s0=rnd()<.5?0:1,c0=rnd()<.5?0:1,sl=[null,null];
 if(ty===0)sl[s0]=c0;else if(ty===1){sl[0]=c0;sl[1]=c0}else{sl[0]=c0;sl[1]=1-c0}
 o.sl=sl;o.d=d;o.on=true;o.done=false;const g=o.g;g.visible=true;g.position.set(PX(d),PY(d),-d);g.rotation.y=-Math.atan((PX(d+1)-PX(d-1))/2);g.rotation.x=Math.atan((PY(d+1)-PY(d-1))/2);
 for(let s=0;s<2;s++){o.m[s].visible=sl[s]!==null;if(sl[s]!==null)o.m[s].material=slabM[sl[s]]}
 const gap=Math.max(26,44-pd*.01)*(.9+rnd()*.3);nextObs+=gap;
 if(rnd()<.55){const h=shs.find(x=>!x.on);if(h){h.on=true;h.d=d+gap/2;h.side=rnd()<.5?0:1;h.m.visible=true;h.m.position.set(PX(h.d),PY(h.d)+(h.side?1:-1)*Y0,-h.d)}}}
function startOD(){od=5;meter=100;cv.classList.add('od');sfx.od();$('odl').textContent='OVERDRIVE!'}
function evalObs(o){let hit=false,gate=false;
 for(let s=0;s<2;s++){const c=o.sl[s];if(c===null)continue;const inside=s===0?py<-(A-3.1):py>(A-3.1);if(inside){if(c===col)gate=true;else hit=true}}
 const x=PX(pd),y=PY(pd)+py;
 if(hit&&od<=0){crash(x,y);return}
 o.done=true;combo++;mult=Math.min(16,1+combo*.5);
 if(hit){score+=500*mult;sfx.shatter();burst(x,y,-pd,40,0xffffff,14);o.m.forEach(m=>m.visible=false)}
 else if(gate){score+=350*mult;sfx.gate();burst(x,y,-pd,26,COL[col],12);o.m.forEach(m=>m.visible=false)}
 else{score+=100*mult;sfx.dodge()}
 if(od<=0){meter+=gate?18:9;if(meter>=100)startOD()}}
function crash(x,y){st='over';P.visible=false;shake=1;sfx.crash();vib([60,40,120]);cv.classList.remove('od');
 burst(x,y,-pd,70,0xffffff,18);burst(x,y,-pd,40,COL[0],14);burst(x,y,-pd,40,COL[1],14);
 setTimeout(showOver,700)}
function showOver(){const nh=Math.floor(score)>save.hi;if(nh)save.hi=Math.floor(score);save.shards+=shRun;persist();
 $('od1').textContent=Math.floor(pd)+' m';$('os').textContent=Math.floor(score).toLocaleString();$('osh').textContent=shRun;$('nh').classList.toggle('hide',!nh);
 $('hud').classList.add('hide');$('over').classList.remove('hide');buildMenu()}
// ---------- HUD ----------
const H={};function setT(i,v){if(H[i]!==v){H[i]=v;$(i).textContent=v}}
function hud(){const d=pd;setT('sc',Math.floor(score).toLocaleString());setT('ds',Math.floor(d)+' m');setT('sh',shRun);setT('mult','x'+mult.toFixed(1));
 setT('sec',d<500?'SECTOR 1':d<1500?'SECTOR 2':'SECTOR 3');if(od<=0)setT('odl','COMBO');
 $('odbar').style.width=Math.min(100,meter)+'%';$('pg').style.width=(d<500?d/5:d<1500?(d-500)/10:((d-1500)%1000)/10)+'%'}
// ---------- loop ----------
let last=0;
function update(dt){
 const play=st==='play';let ts=1;
 if(play&&od>0){od-=dt;ts=.45;meter=Math.max(0,od/5*100);if(od<=0){od=0;meter=0;cv.classList.remove('od')}}
 spd=st==='over'?0:play?Math.min(52,24+pd*.012):16;const gd=dt*ts;pd+=spd*gd;
 const T=tgt*Math.PI;if(ang!==T){const s=dt/.18*Math.PI;ang=ang<T?Math.min(T,ang+s):Math.max(T,ang-s)}
 const u=ang/Math.PI,ae=u*u*(3-2*u);py=-Y0*(1-2*ae);const roll=ae*Math.PI;
 for(const s of segs)if(s.k*SEG+SEG<pd-30)placeSeg(s,++maxK);
 if(play){score+=spd*gd*.5*mult;if(combo>0&&od<=0)meter=Math.max(0,meter-dt*1.5);
  while(nextObs<pd+230)spawnObs();
  for(const o of obs)if(o.on){if(o.d<pd-12){o.on=false;o.g.visible=false}else if(!o.done&&pd>=o.d-.35){evalObs(o);if(st!=='play')break}}
  for(const h of shs)if(h.on){if(h.d<pd-10){h.on=false;h.m.visible=false}else if(Math.abs(h.d-pd)<1.3&&(h.side?py>1.2:py<-1.2)){h.on=false;h.m.visible=false;shRun++;score+=50*mult;sfx.shard();burst(PX(pd),PY(pd)+py,-pd,10,0xfff27a,7)}}
  const x=PX(pd),y=PY(pd)+py;for(let i=0;i<2;i++)emit(x,y,-pd,(Math.random()-.5)*2,(Math.random()-.5)*2,3+Math.random()*3,.5,COL[col])}
 for(const h of shs)if(h.on)h.m.rotation.y+=dt*3;
 updP(dt);
 P.position.set(PX(pd),PY(pd)+py,-pd);P.visible=st==='play';if(body){body.rotation.x+=dt*4;body.rotation.y+=dt*3}aura.scale.setScalar(1+.12*Math.sin(performance.now()/120));
 // camera
 const cd=pd-6,off=Y0-2.4,sr=Math.sin(roll),cr=Math.cos(roll);
 let sx=0,sy=0;if(shake>0){shake=Math.max(0,shake-dt*2.2);sx=(Math.random()-.5)*shake*1.2;sy=(Math.random()-.5)*shake*1.2}
 cam.position.set(PX(cd)+sr*off+sx,PY(cd)-cr*off+sy,-cd);cam.up.set(-sr,cr,0);cam.lookAt(PX(pd+30),PY(pd+30),-(pd+30));
 const ft=78+(spd-16)*.25+(od>0?14:0);fovT+=(ft-fovT)*Math.min(1,dt*4);if(Math.abs(cam.fov-fovT)>.3){cam.fov=fovT;cam.updateProjectionMatrix()}
 if(play)hud()}
function frame(t){requestAnimationFrame(frame);const dt=Math.min(.05,(t-last)/1000||.016);last=t;update(dt);rd.render(scene,cam)}
// ---------- input ----------
let sx0=0,down=false,swiped=false;
addEventListener('pointerdown',e=>{if(st!=='play'||e.target.closest('button'))return;if(!e.isPrimary){toggleCol();return}down=true;swiped=false;sx0=e.clientX;flip()},{passive:true});
addEventListener('pointermove',e=>{if(down&&!swiped&&Math.abs(e.clientX-sx0)>45){swiped=true;toggleCol();flip()}},{passive:true});
addEventListener('pointerup',()=>{down=false},{passive:true});addEventListener('pointercancel',()=>{down=false},{passive:true});
addEventListener('keydown',e=>{if(e.repeat)return;if(e.code==='Space'||e.code==='ArrowUp'||e.code==='ArrowDown')flip();else if(e.code==='KeyC'||e.code==='ArrowLeft'||e.code==='ArrowRight')toggleCol()});
$('colbtn').addEventListener('pointerdown',e=>{e.preventDefault();toggleCol()});
$('go').addEventListener('click',()=>{initAudio();sfx.chime();$('start').classList.add('fade');setTimeout(startGame,900);setTimeout(()=>{$('start').classList.remove('fade')},1500)});
$('again').addEventListener('click',()=>{initAudio();startGame()});
document.addEventListener('contextmenu',e=>e.preventDefault());
// ---------- skins menu ----------
function buildMenu(){$('hi').textContent=save.hi.toLocaleString();$('tsh').textContent=save.shards;
 $('skins').innerHTML=SK.map((s,i)=>{const own=save.own.includes(i);return'<button data-i="'+i+'" class="'+(save.skin===i?'sel':own?'':'lock')+'">'+s.n+(own?'':'<br>'+s.c+' \u25C6')+'</button>'}).join('')}
$('skins').addEventListener('click',e=>{const b=e.target.closest('button');if(!b)return;const i=+b.dataset.i,s=SK[i];
 if(!save.own.includes(i)){if(save.shards<s.c){b.animate([{transform:'translateX(-4px)'},{transform:'translateX(4px)'},{transform:'none'}],150);return}save.shards-=s.c;save.own.push(i)}
 save.skin=i;persist();setSkin();buildMenu()});
// ---------- boot ----------
setSkin();resetWorld();buildMenu();requestAnimationFrame(frame);
})();
